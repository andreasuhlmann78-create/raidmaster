if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - SniperTest.lua
-- SN1951-ABNAHME (Entscheid des Nutzers 13.11. 20:31): "/ahs testroutine sniper" prüft den Sniper am OFFENEN
-- Auktionshaus im echten Spiel - was die Sandbox nicht kann:
--   S4 echter Mausrad-Kauf von 1 Stück bis 5c - NUR nach "Ja" des Spielers in einem eigenen Fenster, gekauft wird nur
--      durch die Raste/Taste des Spielers (Tastendruck). Läuft VOR der Testroutine (ausserhalb der Sandbox), damit der
--      echte Kauf echt gebucht bleibt. Ohne Ja (oder ohne Angebot <= 5c) wird S4 übersprungen.
--   danach die Testroutine, Teil "sniper" (Sandbox, Kaufen gesperrt):
--   S1 Treffer bleiben stehen (Ziel Leinenstoff o. ä., 2 Min. beobachten, nichts verschwindet ohne Grund)
--   S2 Zähler/Budget nur bestätigte Käufe (gesendet -> Fehler -> Bestätigung, an einem Testziel in der echten Anzeige)
--   S3 Pause sichtbar in Zielzeile und Status, "fortsetzen" wirkt sofort
--   S5 Ruckeln: Bilder/s, längster Frame, Sync-Warteschlange während der Beobachtung
--   S6 Reaktionszeit: Abstand der Suchen je Ziel + Suchdauer = spätestens sichtbar nach
-- SN-TEST2 (Auftrag 18:54): beobachtet die Ziele des Spielers (ohne eigene Ziele ein Testziel) und misst dazu
--   S7 Takt, S8 reihum, S9 Treffer richtig, S10 Geld-Sicherheit, S11 Pausen, S12 verpasst, S13 Ruckeln (≤ 33 ms);
--   oben im Bericht das Ergebnis in 3–4 einfachen Sätzen. Nachbildung T735–T742.
-- Keine Spielernamen, kein Chat-Eingabefeld, keine ersetzte Blizzard-Funktion.
-- ============================================================
local A = AHAnalyzerPro
local L = A.L
local SPT = {}
A.SniperTest = SPT

SPT.OBSERVE = 120          -- Sekunden Beobachtung (S1, S5, S6)
SPT.CHEAP_MAX = 5          -- S4: Höchstpreis in Kupfer
SPT.S4_WAIT = 120          -- S4: so lange wartet der Testkauf auf die Raste
SPT.ITEMS = { 2589, 2592, 4306, 2996, 2840 }   -- S1: günstige, viel gehandelte Waren (Leinen-, Wollstoff …)

local function Now() return GetTime() end

-- ------------------------------------------------------------
-- Einstieg: /ahs testroutine sniper
-- ------------------------------------------------------------
function SPT:Begin()
    if not A:IsAHOpen() then A:Print(L["Sniper-Abnahme: bitte zuerst das Auktionshaus öffnen."]); return false end
    if A:InCombat() then A:Print(L["Im Kampf kann die Testroutine nicht starten."]); return false end
    local TR = A.TestRoutine
    if TR and TR.running then A:Print(L["Selbsttest läuft schon ..."]); return false end
    self.s4 = nil
    self:AskS4()
    return true
end

-- eigenes kleines Fenster (kein Blizzard-Popup verändert)
function SPT:AskS4()
    local f = self.ask
    if not f then
        f = CreateFrame("Frame", nil, UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
        f:SetSize(420, 130)
        f:SetPoint("CENTER", 0, 120)
        f:SetFrameStrata("DIALOG")
        if f.SetBackdrop then
            f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
            f:SetBackdropColor(0.06, 0.06, 0.08, 0.95)
            f:SetBackdropBorderColor(0, 0.82, 0.82, 1)
        end
        f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        f.text:SetPoint("TOP", 0, -16)
        f.text:SetWidth(390)
        f.text:SetText(string.format(L["Sniper-Abnahme S4: echter Testkauf von 1 Stück bis %s erlaubt? Gekauft wird nur mit deiner Mausrad-Raste bzw. Taste."],
            A:FormatMoney(self.CHEAP_MAX)))
        local UI = A.UI
        f.yes = UI:Button(f, L["Ja"], 120, 24, function() f:Hide(); SPT:S4Answer(true) end, "primary")
        f.yes:SetPoint("BOTTOMLEFT", 70, 14)
        f.no = UI:Button(f, L["Nein"], 120, 24, function() f:Hide(); SPT:S4Answer(false) end)
        f.no:SetPoint("BOTTOMRIGHT", -70, 14)
        self.ask = f
    end
    f:Show()
end

-- günstigstes frisches Angebot <= CHEAP_MAX aus dem letzten Scan
function SPT:CheapItem()
    local best, bestP
    local maxAge = (A.PRICE_OLD_HOURS or 6) * 3600
    for id in pairs(A.db and A.db.marketData or {}) do
        local p, _, t = A:GetCurrent(id)
        if p and p > 0 and p <= self.CHEAP_MAX and t and time() - t <= maxAge and (not bestP or p < bestP) then best, bestP = id, p end
    end
    return best, bestP
end

function SPT:S4Answer(yes)
    if not yes then
        self.s4 = { status = "SKIP", detail = L["Spieler hat den Testkauf nicht erlaubt (Nein)"] }
        return self:StartRoutine()
    end
    local Sn = A.Sniper
    local id, p = self:CheapItem()
    if not (Sn and id) then
        self.s4 = { status = "SKIP", detail = string.format(L["kein Angebot bis %s im letzten Scan"], A:FormatMoney(self.CHEAP_MAX)) }
        return self:StartRoutine()
    end
    local key = "i:" .. id
    local db = A.db.sniper
    local prev = db.targets[key]
    local wasArmed = db.armed
    local ok = Sn:SetTarget(tostring(id), self.CHEAP_MAX, 1, self.CHEAP_MAX)
    if not ok then
        self.s4 = { status = "SKIP", detail = "Testziel ließ sich nicht anlegen" }
        return self:StartRoutine()
    end
    local t = db.targets[key]
    local sent0 = self.sendCount or 0
    self.s4run = { id = id, key = key, prev = prev, wasArmed = wasArmed, t = t, t0 = Now(), price = p, sent0 = sent0,
        money0 = GetMoney and GetMoney() or nil }       -- SN-TEST2 S10: Gold vorher
    if not wasArmed then Sn:SetArmed(true) end
    A:Print(string.format(L["Sniper-Abnahme S4: Ziel %s bis %s, 1 Stück. Sobald „Treffer“ erscheint: EINE Mausrad-Raste bzw. Taste (höchstens %d s)."],
        A:GetItemName(id), A:FormatMoney(self.CHEAP_MAX), self.S4_WAIT))
    self:PollS4()
    return true
end

-- Sendungen zählen (Einzelkauf und Warenkauf), nur gelesen über die Sniper-Felder
function SPT:Sends()
    local Sn = A.Sniper
    local n = 0
    for _ in ipairs(Sn.itemBuys or {}) do n = n + 1 end
    if Sn.inFlight then n = n + 1 end
    return n
end

function SPT:PollS4()
    local r = self.s4run
    if not r then return end
    local t = r.t
    local done = t and (t.bought or 0) >= 1
    local timeout = Now() - r.t0 > self.S4_WAIT
    local Sn0 = A.Sniper
    -- SN-TEST2 S12: Treffer sichtbar -> Zeit bis zum bestätigten Kauf (Reaktion des Spielers)
    if not r.hitAt and Sn0 and Sn0.HitMarked and Sn0:HitMarked(r.key) then r.hitAt = Now() end
    if done and not r.doneAt then r.doneAt = Now() end
    -- SN-TEST2 S10: nach dem Kauf 1,5 s warten, dann Gold nachher lesen
    if not (done or timeout) or (done and Now() - r.doneAt < 1.5) then
        if not done then r.maxOpen = math.max(r.maxOpen or 0, self:Sends()) end
        C_Timer.After(0.5, function() SPT:PollS4() end)
        return
    end
    -- Bestätigung abwarten, dann aufräumen
    local Sn = A.Sniper
    local bought, spent = t and t.bought or 0, t and t.spent or 0
    if done then
        local okOne = bought == 1 and spent <= self.CHEAP_MAX and (r.maxOpen or 0) <= 1
        self.s4 = { status = okOne and "PASS" or "FAIL", detail = string.format("gekauft %d für %s · höchstens %d gleichzeitig gesendet · nach %.0f s",
            bought, A:FormatMoney(spent), r.maxOpen or 0, Now() - r.t0) }
        self.s4.bought, self.s4.hit = bought, true
        self.s4.react = r.hitAt and (r.doneAt - r.hitAt) or nil
        self.s4.gold = { m0 = r.money0, m1 = GetMoney and GetMoney() or nil, spent = spent }
    else
        self.s4 = { status = "SKIP", detail = string.format("kein Kauf in %d s (keine Raste oder kein Treffer)", self.S4_WAIT), bought = 0, hit = r.hitAt ~= nil }
    end
    local db = A.db.sniper
    if r.prev then db.targets[r.key] = r.prev else db.targets[r.key] = nil end
    if not r.wasArmed then Sn:SetArmed(false) end
    if Sn.result and Sn.result.key == r.key then Sn.result = nil end
    A:Fire("SNIPER_CHANGED")
    self.s4run = nil
    A:Print(L["Sniper-Abnahme S4: "] .. self.s4.status .. " – " .. self.s4.detail)
    C_Timer.After(1, function() SPT:StartRoutine() end)
end

function SPT:StartRoutine()
    local TR = A.TestRoutine
    if TR then TR:Start("sniper") end
end

-- ------------------------------------------------------------
-- Testroutine Teil "sniper" (Sandbox: Kaufen gesperrt, Daten danach zurück)
-- ------------------------------------------------------------
-- Beobachtung: je Änderung der Sniper-Anzeige die sichtbaren Treffer; verschwindet einer, obwohl die neueste Antwort
-- des Servers ihn noch enthält (und er nicht gekauft/weg ist), ist das ein Fehler (S1)
function SPT:Visible(Sn, t)
    local r = Sn.result
    local set = {}
    if not (r and t and r.key == t.key) then return set, r end
    for _, l in ipairs(r.listings or {}) do
        -- Waren haben keine auctionID: Preis und Menge als Schlüssel
        local k = l.auctionID or (tostring(l.price) .. "x" .. tostring(l.qty))
        if not l.gone and not l.own and not l.bait and l.price and l.price <= (t.maxPrice or 0) then set[k] = l end
    end
    return set, r
end

-- ------------------------------------------------------------
-- SN-TEST2 (Auftrag 18:54): Messungen S7–S13 während der Beobachtung. Alle Auswertungen sind reine Funktionen auf dem
-- Beobachtungs-Protokoll o (dieselben Funktionen prüft die Nachbildung T735–T742).
-- ------------------------------------------------------------
SPT.FRAME_MAX = 33          -- S13: kein Frame länger als 33 ms
SPT.RESUME_MAX = 5          -- S11: nach einer Pause spätestens 5 s bis zur nächsten Suche
SPT.ROUND_FACTOR = 1.5      -- S8: jedes Ziel spätestens nach Ziele × Ø Abstand × 1,5
SPT.PAUSE_WHY = { scan = true, vollscan = true, buy = true, seller = true }
SPT.S_IDS = { { "S1", "T613" }, { "S2", "T614" }, { "S3", "T615" }, { "S4", "T616" }, { "S5", "T617" }, { "S6", "T618" }, { "S7", "T728" },
    { "S8", "T729" }, { "S9", "T730" }, { "S10", "T731" }, { "S11", "T732" }, { "S12", "T733" }, { "S13", "T734" } }

local function OfferKey(l, commodity)
    if l.auctionID then return l.auctionID end
    if commodity then return tostring(l.price) end                 -- Waren: je Preis eine Zeile (Menge ändert sich)
    return tostring(l.price) .. "x" .. tostring(l.qty)
end

-- S7/S8/S11: eine Suche des Snipers beginnt
function SPT:NoteSearch(o, key, now)
    o.all[#o.all + 1] = { k = key, t = now, a = o.act or 0 }
    if key == o.key then o.searches[#o.searches + 1] = now end
    for _, p in ipairs(o.pauses or {}) do
        if p.t1 and not p.resume then p.resume = math.max(0, now - p.t1) end
    end
end

-- S9/S12: neue Antwort des Servers für Ziel t. Treffer = Angebot ≤ Max (Stückpreis); verpasst = Treffer, der in einer
-- späteren Antwort fehlt (von anderen gekauft), mit der Zeit vom Erkennen bis weg. Rückgabe: Antwort hat einen Kauf geplant
function SPT:NoteResult(o, t, r, now)
    o.hit9 = o.hit9 or { n = 0, checked = 0, bad = 0, gold = 0 }
    o.hitSeen, o.missed, o.hitNew = o.hitSeen or {}, o.missed or {}, o.hitNew or 0
    local seen = o.hitSeen[t.key] or {}
    local cur, planned = {}, false
    local max = t.maxPrice or 0
    for _, l in ipairs(r.listings or {}) do
        local k = OfferKey(l, r.commodity)
        if not l.gone then cur[k] = true end
        if l.planned and l.planned > 0 and not l.bait then
            planned = true
            o.hit9.checked = o.hit9.checked + 1
            local per = (not r.commodity and l.buyout and l.qty and l.qty > 0) and (l.buyout / l.qty) or l.price
            if not per or per > max + 0.5 then
                o.hit9.bad = o.hit9.bad + 1
                o.hit9.badTxt = string.format("%s Stückpreis %s > Max %s", tostring(k), tostring(per), tostring(max))
            end
        end
        if not l.gone and not l.own and not l.bait and l.pass ~= false and l.price and l.price <= max and not seen[k] then
            seen[k] = now
            o.hitNew = o.hitNew + 1
        end
    end
    for k, t0 in pairs(seen) do
        if not cur[k] then o.missed[#o.missed + 1] = now - t0; seen[k] = nil end
    end
    o.hitSeen[t.key] = seen
    if planned then o.hit9.n = o.hit9.n + 1 end
    return planned
end

-- S13 (und S5): ein Bild
function SPT:NoteFrame(o, ms, fps)
    o.frames = (o.frames or 0) + 1
    if o.frames > 5 then
        if ms > (o.frameMax or 0) then o.frameMax = ms end
        if ms > self.FRAME_MAX then o.over33 = (o.over33 or 0) + 1 end
    end
    if fps then
        o.fpsSum, o.fpsN = (o.fpsSum or 0) + fps, (o.fpsN or 0) + 1
        if not o.fpsMin or fps < o.fpsMin then o.fpsMin = fps end
    end
end

-- S7 Takt: Suchen je Minute (Ø und höchste in 60 s), Abstand (Ø/max), Anteil Warten auf den Server, Vergleich mit H2
function SPT:Takt(o, tEnd)
    local ts = {}
    for _, s in ipairs(o.all or {}) do ts[#ts + 1] = s.t end
    local n = #ts
    local dur = math.max(1, (tEnd or Now()) - (o.t0 or 0))
    local mx, j = 0, 1
    for i = 1, n do
        while ts[i] - ts[j] >= 60 do j = j + 1 end
        if i - j + 1 > mx then mx = i - j + 1 end
    end
    local gs, gMax = 0, 0
    for i = 2, n do
        local g = ts[i] - ts[i - 1]
        gs = gs + g
        if g > gMax then gMax = g end
    end
    local limit = A.QUERY_LIMIT or 90
    local ans, thr = (o.waitAns or 0) / dur * 100, (o.waitThr or 0) / dur * 100
    local allMax = o.qMax
    local ok = n >= 2 and mx <= limit and (allMax == nil or allMax <= limit)
    return { n = n, dur = dur, avg = n / (dur / 60), max = mx, gapAvg = n > 1 and gs / (n - 1) or nil, gapMax = gMax,
        ansPct = ans, thrPct = thr, waitPct = ans + thr, limit = limit, allMax = allMax, ok = ok }
end

-- S8 reihum: je Ziel Suchen und längste Lücke (Spielzeit ohne Pausen, inkl. Beginn und Ende der Beobachtung)
function SPT:Reihum(o)
    local per, keys = {}, o.keyList or {}
    for _, k in ipairs(keys) do per[k] = { n = 0, last = 0, maxGap = 0 } end
    local gs, gn, prevA = 0, 0, nil
    for _, s in ipairs(o.all or {}) do
        local p = per[s.k]
        if p then
            p.n = p.n + 1
            if s.a - p.last > p.maxGap then p.maxGap = s.a - p.last end
            p.last = s.a
        end
        if prevA then gs, gn = gs + (s.a - prevA), gn + 1 end
        prevA = s.a
    end
    local aEnd = o.actEnd or o.act or 0
    local worst, ok, parts = 0, true, {}
    for _, k in ipairs(keys) do
        local p = per[k]
        if aEnd - p.last > p.maxGap then p.maxGap = aEnd - p.last end
        if p.maxGap > worst then worst = p.maxGap end
        if p.n == 0 then ok = false end
        parts[#parts + 1] = string.format("%s %d×/%.1f s", tostring(k), p.n, p.maxGap)
    end
    local gAvg = gn > 0 and gs / gn or nil
    local limit = gAvg and #keys * gAvg * self.ROUND_FACTOR or nil
    if not limit or worst > limit then ok = false end
    return { nKeys = #keys, per = per, gapAvg = gAvg, limit = limit, worst = worst, ok = ok and #keys > 0, text = table.concat(parts, " · ") }
end

-- S11 Pausen: jede beendete Pause muss in RESUME_MAX s zur nächsten Suche führen; Drossel -> langsamer, dann wieder schnell
function SPT:Pauses(o, tEnd)
    local n, bad, worst, list = 0, 0, 0, {}
    for _, p in ipairs(o.pauses or {}) do
        if p.t1 then
            local r = p.resume
            if not r and tEnd - p.t1 > self.RESUME_MAX then r = tEnd - p.t1 end
            if r then
                n = n + 1
                if not p.resume or r > self.RESUME_MAX then bad = bad + 1 end
                if r > worst then worst = r end
                list[#list + 1] = string.format("%s %.0f s -> %s %.1f s", p.why, p.t1 - p.t0, p.resume and "weiter nach" or "KEINE Suche seit", r)
            end
        end
    end
    local throttled = (o.err1 or 0) > (o.err0 or 0)
    local fastAgain = (o.gap1 or 0) <= math.max(o.gap0 or 0, A.GAP_MIN_FIXED or 0.2) * 1.5 + 0.05
    return { n = n, bad = bad, worst = worst, list = list, throttled = throttled, fastAgain = fastAgain,
        ok = bad == 0 and (not throttled or fastAgain) }
end

-- S12 verpasst
function SPT:Missed(o)
    local m = o.missed or {}
    local s, mn = 0, nil
    for _, v in ipairs(m) do s = s + v; if not mn or v < mn then mn = v end end
    return { n = #m, avg = #m > 0 and s / #m or nil, min = mn }
end

-- S13 Ruckeln
function SPT:Smooth(o)
    local avg = (o.fpsN or 0) > 0 and o.fpsSum / o.fpsN or nil
    return { fpsAvg = avg, fpsMin = o.fpsMin, frameMax = o.frameMax or 0, over = o.over33 or 0, ok = (o.frameMax or 0) <= self.FRAME_MAX }
end

-- S10/S4: Gold vorher − nachher = gebuchter Preis
function SPT:GoldCheck(m0, m1, spent)
    return m0 ~= nil and m1 ~= nil and spent ~= nil and (m0 - m1) == spent
end

-- ERGEBNIS OBEN: 3–4 einfache Sätze, danach S1–S13 mit OK/FEHLER
function SPT:TopLines(rows, last, s4)
    last, s4 = last or self.last, s4 or self.s4
    local st = {}
    for _, r in ipairs(rows or {}) do
        local id = tostring(r.group or ""):match("(T%d+)$")
        if id then st[id] = r.status end
    end
    local fails, parts = {}, {}
    for _, m in ipairs(self.S_IDS) do
        local s = st[m[2]]
        local txt = (s == "PASS" and "OK") or (s == "FAIL" and "FEHLER") or (s == "SKIP" and "SKIP") or (s and tostring(s)) or "-"
        if s == "FAIL" then fails[#fails + 1] = m[1] end
        parts[#parts + 1] = m[1] .. " " .. txt
    end
    local out = { "ERGEBNIS Sniper-Abnahme:" }
    local tail = #fails == 0 and "Alles OK." or ("FEHLER bei: " .. table.concat(fails, ", ") .. ".")
    if not last then
        out[#out + 1] = "Beobachtung nicht gelaufen (Auktionshaus nicht offen oder kein Ziel mit Preis). " .. tail
    else
        local tk, rr = last.takt, last.reihum
        out[#out + 1] = string.format("Der Sniper prüfte %d %s reihum, Ø %.0f Suchen/Min. (Server erlaubt %d).", rr.nKeys, rr.nKeys == 1 and "Ziel" or "Ziele", tk.avg, tk.limit)
        out[#out + 1] = string.format("Jedes Ziel spätestens alle %.0f s.", rr.worst or 0)
        local bought = s4 and s4.bought or 0
        local hits = (last.hitsN or 0) + (s4 and s4.hit and 1 or 0)
        out[#out + 1] = string.format("%d Treffer, %d gekauft, %d verpasst.", hits, bought, last.missedN or 0)
        local sm = last.smooth
        local ruck = (sm.frameMax or 0) <= self.FRAME_MAX and "Kein Ruckeln." or string.format("Ruckeln: längster Frame %.0f ms (Ziel ≤ %d ms).", sm.frameMax, self.FRAME_MAX)
        out[#out + 1] = ruck .. " " .. tail
    end
    out[#out + 1] = "Einzeln: " .. table.concat(parts, " · ")
    return out
end

-- Ziele der Beobachtung: offene eigene Ziele des Spielers; ohne eigene Ziele ein Testziel aus SPT.ITEMS
function SPT:PlayerTargets()
    local Sn, db = A.Sniper, A.db.sniper
    local list = {}
    for key, t in pairs(db.targets or {}) do
        if type(t) == "table" and not t.watch and not Sn:IsDone(t) and not Sn:ItemPaused(t.itemID) then list[#list + 1] = key end
    end
    table.sort(list)
    return list
end

function SPT:StartObserve(TR)
    local Sn = A.Sniper
    local db = A.db.sniper
    local keys = self:PlayerTargets()
    local created, key, prevT
    if #keys == 0 then
        -- Testziel: erste Ware aus SPT.ITEMS mit aktuellem Preis; Höchstpreis = günstigstes Angebot (Treffer erwartet)
        local id, p
        for _, x in ipairs(self.ITEMS) do
            local cur = A:GetCurrent(x)
            if cur and cur > 0 then id, p = x, cur; break end
        end
        if not id then return false, "kein eigenes Ziel und kein Preis für die Test-Waren (erst scannen)" end
        key = "i:" .. id
        prevT = db.targets[key]
        local ok = Sn:SetTarget(tostring(id), p, 1000, p * 1000)
        if not ok then return false, "Testziel ließ sich nicht anlegen" end
        keys, created = { key }, true
    else
        key = keys[1]
    end
    local tByKey, before = {}, {}
    for _, k in ipairs(keys) do
        local t = db.targets[k]
        if t and not t.key then t.key = k end
        tByKey[k] = t
        before[k] = { t and t.bought or 0, t and t.spent or 0 }
    end
    local t = tByKey[key]
    local prevArmed = db.armed
    db.armed = true
    Sn.lastSearch = -100
    local pace = A.pace or {}
    local o = { id = t and t.itemID, t = t, t0 = Now(), seen = {}, vanished = 0, vanishedIDs = {}, shownN = 0, searches = {}, searchDur = {},
        fpsSum = 0, fpsN = 0, fpsMin = nil, frameMax = 0, queueMax = 0, frames = 0, key = key, prevT = prevT, prevArmed = prevArmed,
        created = created, keyList = keys, tByKey = tByKey, before = before, all = {}, pauses = {}, act = 0, waitAns = 0, waitThr = 0,
        qMax = A:QueryLimit() and 0 or nil, err0 = pace.errors or 0, gap0 = A:QueryGap(), gapMax = A:QueryGap(), sendsMax = 0, sends0 = SPT:Sends() }
    self.obs = o
    local prevBy, lastKey = {}, nil
    o.onChange = function()
        local r = Sn.result
        local now = Now()
        local rt = r and tByKey[r.key]
        if rt and r ~= o.lastR then
            o.lastR = r
            o.checked = (o.checked or 0) + #(r.listings or {})
            for _, l in ipairs(r.listings or {}) do
                if l.price and l.price > (rt.maxPrice or 0) then o.tooDear = (o.tooDear or 0) + 1
                elseif l.own then o.ownN = (o.ownN or 0) + 1
                elseif l.bait then o.baitN = (o.baitN or 0) + 1
                elseif l.gone then o.goneN = (o.goneN or 0) + 1 end
            end
            local planned = SPT:NoteResult(o, rt, r, now)
            if planned and Sn:HitMarked(r.key) then o.hit9.gold = o.hit9.gold + 1 end
        end
        -- S1 je Ziel: verschwindet ein sichtbarer Treffer, obwohl die neueste Antwort ihn noch enthält -> Fehler
        if r == nil and lastKey and next(prevBy[lastKey] or {}) ~= nil then
            -- Liste geleert, bevor neue Ergebnisse da sind (SN1951c) - zählt als ohne Grund verschwunden
            for aid in pairs(prevBy[lastKey]) do o.vanished = o.vanished + 1; o.vanishedIDs[#o.vanishedIDs + 1] = tostring(aid) .. "(geleert)" end
            prevBy[lastKey] = {}
        end
        if not rt then return end
        local vis = SPT:Visible(Sn, rt)
        for aid in pairs(vis) do
            local sk = r.key .. ":" .. tostring(aid)
            if not o.seen[sk] then o.seen[sk] = now; o.shownN = o.shownN + 1 end
        end
        for aid in pairs(prevBy[r.key] or {}) do
            if not vis[aid] then
                for _, l in ipairs(r.listings or {}) do
                    local k = l.auctionID or (tostring(l.price) .. "x" .. tostring(l.qty))
                    if k == aid and not l.gone and not (l.used and l.used > 0) then
                        o.vanished = o.vanished + 1
                        o.vanishedIDs[#o.vanishedIDs + 1] = tostring(aid)
                    end
                end
            end
        end
        prevBy[r.key], lastKey = vis, r.key
    end
    A:On("SNIPER_CHANGED", function() if SPT.obs == o and o.onChange then pcall(o.onChange) end end)
    local lastStart
    o.frame = o.frame or CreateFrame("Frame")
    -- S11: eigene Suche des Spielers im Auktionshaus (Ergebnis kommt, ohne dass ein Modul von uns sucht) = Pause "AH-Klick"
    for _, ev in ipairs({ "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED", "COMMODITY_SEARCH_RESULTS_UPDATED", "ITEM_SEARCH_RESULTS_UPDATED" }) do
        pcall(o.frame.RegisterEvent, o.frame, ev)
    end
    o.frame:SetScript("OnEvent", function()
        if SPT.obs ~= o then return end
        local now = Now()
        if Sn.search or now - (o.lastSearchEnd or o.t0) < 2 or now - (o.lastClick or -100) < 1 then return end
        if A:IsScanning(true) or (A.Watcher and A.Watcher:IsBusy()) or (A.Seller and A.Seller:IsBusy()) or (A.Buy and A.Buy:Blocks()) then return end
        o.lastClick = now
        o.pauses[#o.pauses + 1] = { why = "AH-Klick", t0 = now, t1 = now }
    end)
    o.frame:SetScript("OnUpdate", function(_, elapsed)
        if SPT.obs ~= o then o.frame:SetScript("OnUpdate", nil); return end
        local now = Now()
        local dt = now - (o.lastT or now)
        o.lastT = now
        local ms = (elapsed or 0) * 1000
        local gf = _G.GetFramerate
        SPT:NoteFrame(o, ms, gf and gf() or nil)
        local GSS = _G.GoldSentinelSync
        local q = GSS and GSS.queue and #GSS.queue or 0
        if q > o.queueMax then
            o.queueMax = q
            if A.Sync and A.Sync.QueueMix then local okQ, mix = pcall(A.Sync.QueueMix, A.Sync); if okQ then o.queueMixMax = mix end end
        end
        local ls = A.longStep
        if ls and ms > o.frameMax - 0.001 and ms > 16 then o.slowAt = string.format("%.0f ms bis %s (%s)", ls.ms, tostring(ls.at), tostring(ls.job)) end
        -- S11: Pausen (Markt-Scan, Vollscan, Einkauf, Preisprüfung) und Spielzeit ohne Pausen
        local why = Sn.waitReason
        local pause = why and SPT.PAUSE_WHY[why] and why or nil
        if pause and not o.curPause then
            o.curPause = { why = pause, t0 = now }
            o.pauses[#o.pauses + 1] = o.curPause
        elseif not pause and o.curPause then
            o.curPause.t1, o.curPause = now, nil
        end
        if not pause then o.act = o.act + dt end
        -- S7: Warten auf die Antwort bzw. auf die Freigabe des Servers (Drossel, H2)
        if Sn.search then o.waitAns = o.waitAns + dt
        elseif not A:CanQueryNow("sniper") then o.waitThr = o.waitThr + dt end
        if o.qMax then local nq = A:QueriesLastMinute(); if nq > o.qMax then o.qMax = nq end end
        local g = A:QueryGap()
        if g > o.gapMax then o.gapMax = g end
        -- S10: in der Beobachtung wird nichts gesendet (Kaufen gesperrt)
        local sn = SPT:Sends() - o.sends0
        if sn > o.sendsMax then o.sendsMax = sn end
        local s = Sn.search
        if s and s ~= lastStart then
            lastStart = s
            SPT:NoteSearch(o, s.targetKey, now)
            s.__sptStart = now
        end
        if lastStart and not Sn.search and lastStart.__sptStart and not lastStart.__sptDone then
            lastStart.__sptDone = true
            o.searchDur[#o.searchDur + 1] = now - lastStart.__sptStart
            o.lastSearchEnd = now
        end
    end)
    return true
end

function SPT:StopObserve()
    local o = self.obs
    if o and o.frame then
        o.frame:SetScript("OnUpdate", nil)
        o.frame:SetScript("OnEvent", nil)
        pcall(o.frame.UnregisterAllEvents, o.frame)
    end
    self.obs = nil
    if o then
        local db, Sn = A.db.sniper, A.Sniper
        o.tEnd, o.actEnd = Now(), o.act
        if o.curPause then o.curPause.t1, o.curPause = o.tEnd, nil end
        local pace = A.pace or {}
        o.err1, o.gap1 = pace.errors or 0, A:QueryGap()
        -- S10: Zähler der Ziele unverändert (in der Beobachtung wird nichts gekauft)
        o.changed = {}
        for k, b in pairs(o.before or {}) do
            local t = db.targets[k]
            if t and ((t.bought or 0) ~= b[1] or (t.spent or 0) ~= b[2]) then o.changed[#o.changed + 1] = k end
        end
        -- Testziel und Modus selbst zurück (Teil "sniper" erlaubt Änderungen unter db.sniper, die echte Suchen machen)
        if o.created then db.targets[o.key] = o.prevT end
        db.armed = o.prevArmed
        if Sn.result and o.tByKey and o.tByKey[Sn.result.key] then Sn.result = nil end
        if Sn.search and o.tByKey and o.tByKey[Sn.search.targetKey] then Sn.search = nil end
        A:Fire("SNIPER_CHANGED")
    end
    return o
end

-- Reaktionszeit (S6): ein neues Angebot ist spätestens nach "Abstand zweier Suchen + Suchdauer" sichtbar
function SPT:Reaction(o)
    local gaps = {}
    for i = 2, #o.searches do gaps[#gaps + 1] = o.searches[i] - o.searches[i - 1] end
    local function avg(t) local s = 0; for _, v in ipairs(t) do s = s + v end; return #t > 0 and s / #t or nil end
    local g, d = avg(gaps), avg(o.searchDur)
    if not g then return nil, g, d end
    return g + (d or 0), g, d
end

SPT.OBS_IDS = { { "T613", "S1 Treffer bleiben stehen" }, { "T617", "S5 Ruckeln und Sync-Warteschlange" }, { "T618", "S6 Reaktionszeit" },
    { "T728", "S7 Takt" }, { "T729", "S8 reihum" }, { "T730", "S9 Treffer richtig" }, { "T731", "S10 Geld-Sicherheit" },
    { "T732", "S11 Pausen" }, { "T733", "S12 verpasst" }, { "T734", "S13 Ruckeln" } }

-- S7–S13 nach der Beobachtung (echtes Spiel)
function SPT:ObsChecks(o, Chk, Skp)
    local tk, rr, pz, ms, sm = self:Takt(o, o.tEnd), self:Reihum(o), self:Pauses(o, o.tEnd), self:Missed(o), self:Smooth(o)
    local h9 = o.hit9 or { n = 0, checked = 0, bad = 0, gold = 0 }
    self.last = { takt = tk, reihum = rr, hitsN = o.hitNew or 0, missedN = ms.n, smooth = sm }
    Chk("T728", "J", "SN-TEST2-S7 Takt: Suchen/Min. (Ø, höchste in 60 s) ≤ Server-Grenze 90, Abstand, Anteil Warten auf den Server", function()
        return tk.ok, string.format("%d Suchen in %.0f s · Ø %.1f/Min. · höchste %d in 60 s%s · Abstand Ø %s / max %.1f s · Warten auf Server %.0f %% (Antwort %.0f %%, Freigabe/Drossel %.0f %%)",
            tk.n, tk.dur, tk.avg, tk.max, tk.allMax and string.format(" (alle Module zusammen %d)", tk.allMax) or "",
            tk.gapAvg and string.format("%.1f", tk.gapAvg) or "?", tk.gapMax, tk.waitPct, tk.ansPct, tk.thrPct), string.format("höchstens %d/Min.", tk.limit)
    end)
    Chk("T729", "J", "SN-TEST2-S8 reihum: jedes Ziel gesucht, längste Lücke ≤ Ziele × Ø Abstand × 1,5 (ohne Pausen)", function()
        return rr.ok, string.format("%d Ziele · %s · Ø Abstand %s s · Grenze %s s", rr.nKeys, rr.text, rr.gapAvg and string.format("%.1f", rr.gapAvg) or "?",
            rr.limit and string.format("%.1f", rr.limit) or "?"), "jedes Ziel ≥ 1× · Lücke ≤ Grenze"
    end)
    Chk("T730", "J", "SN-TEST2-S9 Treffer richtig: geplanter Kauf nur bei Stückpreis ≤ Max, Treffer golden markiert", function()
        if h9.n == 0 then
            return "SKIP", string.format("kein Treffer in der Beobachtung (%d Angebote geprüft, über Max %d) – Nachbildung T737", o.checked or 0, o.tooDear or 0)
        end
        return h9.bad == 0 and h9.gold == h9.n, string.format("%d Antworten mit Treffer · %d geplante Angebote geprüft · über Max %d%s · golden markiert %d/%d",
            h9.n, h9.checked, h9.bad, h9.badTxt and (" (" .. h9.badTxt .. ")") or "", h9.gold, h9.n), "über Max 0 · golden = Treffer"
    end)
    Chk("T731", "J", "SN-TEST2-S10 Geld-Sicherheit: Beobachtung sendet nichts, Zähler unverändert; S4 Gold vorher − nachher = gebuchter Preis", function()
        local s4 = self.s4 or {}
        local g = s4.gold
        local goldTxt, goldOK = "S4 ohne Kauf", true
        if g then
            goldOK = self:GoldCheck(g.m0, g.m1, g.spent)
            goldTxt = string.format("S4 Gold %s -> %s (−%s) · gebucht %s", tostring(g.m0), tostring(g.m1), tostring(g.m0 and g.m1 and g.m0 - g.m1), tostring(g.spent))
        end
        local ok = o.sendsMax == 0 and #o.changed == 0 and goldOK
        return ok, string.format("gesendet %d · Zähler geändert %d%s · %s", o.sendsMax, #o.changed, #o.changed > 0 and (" (" .. table.concat(o.changed, ",") .. ")") or "", goldTxt),
            "gesendet 0 · geändert 0 · Gold = gebucht"
    end)
    Chk("T732", "J", "SN-TEST2-S11 Pausen: nach Markt-Scan/Vollscan/Einkauf/AH-Klick sucht der Sniper von selbst weiter (≤ 5 s); Drossel -> langsamer, dann wieder schnell", function()
        local drossel = pz.throttled and string.format("Drossel: Abstand %.2f -> höchstens %.2f -> %.2f s (%s)", o.gap0 or 0, o.gapMax or 0, o.gap1 or 0,
            pz.fastAgain and "wieder schnell" or "NICHT wieder schnell") or "keine Drossel"
        if pz.n == 0 and not pz.throttled then
            return "SKIP", "keine Pause und keine Drossel während der Beobachtung (Nachbildung T739)"
        end
        return pz.ok, string.format("%d Pausen%s · längste bis zur nächsten Suche %.1f s · %s", pz.n, #pz.list > 0 and (" (" .. table.concat(pz.list, "; ", 1, math.min(4, #pz.list)) .. ")") or "",
            pz.worst, drossel), "weiter nach ≤ 5 s · wieder schnell"
    end)
    Chk("T733", "J", "SN-TEST2-S12 verpasst: Treffer, die vor dem Kauf weg waren, Zeit vom Erkennen bis weg; Ø Reaktion des Spielers", function()
        local st = A.Sniper:Stats()
        local react = (st.reactN or 0) > 0 and string.format("%.1f s (heute, %d Käufe)", st.reactSum / st.reactN, st.reactN) or "-"
        local s4 = self.s4 or {}
        local s4r = s4.react and string.format(" · S4 Treffer bis Kauf %.1f s", s4.react) or ""
        if (o.hitNew or 0) == 0 then return "SKIP", "kein Treffer in der Beobachtung · Ø Reaktion " .. react .. s4r end
        return true, string.format("%d Treffer · %d verpasst (Kaufen in der Beobachtung gesperrt)%s · Ø Reaktion %s%s", o.hitNew, ms.n,
            ms.n > 0 and string.format(" · weg nach Ø %.1f s, schnellstens %.1f s", ms.avg, ms.min) or "", react, s4r), "gemessen"
    end)
    Chk("T734", "J", "SN-TEST2-S13 Ruckeln: Bilder/s und längster Frame über die ganze Beobachtung, kein Frame > 33 ms", function()
        return sm.ok, string.format("Ø %s / min %s Bilder/s · längster Frame %.0f ms · Frames > %d ms: %d%s", sm.fpsAvg and string.format("%.0f", sm.fpsAvg) or "?",
            sm.fpsMin and string.format("%.0f", sm.fpsMin) or "?", sm.frameMax, self.FRAME_MAX, sm.over, o.slowAt and (" · längster Schritt " .. o.slowAt) or ""),
            "kein Frame > 33 ms"
    end)
end

-- ------------------------------------------------------------
-- Nachbildung S7–S13 und Ergebnis oben (läuft in der normalen Testroutine und im Teil "sniper"; ändert nichts Echtes)
-- ------------------------------------------------------------
function SPT:SimChecks(Chk)
    local Sn = A.Sniper
    Chk("T735", "M", "T-SN-TEST2-S7 Takt (Nachbildung): 90 Suchen in 2 Min. -> Ø 45/Min., höchste 60 in 60 s, OK; 100 in 1 Min. -> FEHLER", function()
        local o = { t0 = 0, all = {}, waitAns = 30, waitThr = 12 }
        for i = 0, 59 do o.all[#o.all + 1] = { k = "a", t = i, a = i } end
        for i = 0, 29 do o.all[#o.all + 1] = { k = "a", t = 60 + i * 2, a = 60 + i * 2 } end
        local a = SPT:Takt(o, 120)
        local o2 = { t0 = 0, all = {} }
        for i = 0, 99 do o2.all[#o2.all + 1] = { k = "a", t = i * 0.5, a = i * 0.5 } end
        local b = SPT:Takt(o2, 60)
        local got = string.format("Ø %.0f · höchste %d · Abstand %.1f/%.1f · Warten %.0f %% · %s | höchste %d · %s", a.avg, a.max, a.gapAvg, a.gapMax, a.waitPct, tostring(a.ok), b.max, tostring(b.ok))
        local want = "Ø 45 · höchste 60 · Abstand 1.3/2.0 · Warten 35 % · true | höchste 100 · false"
        return got == want, got, want
    end)
    Chk("T736", "M", "T-SN-TEST2-S8 reihum (Nachbildung): 3 Ziele abwechselnd -> Lücke 3 s ≤ 4,5 s OK; ein Ziel nur einmal -> FEHLER", function()
        local keys = { "a", "b", "c" }
        local o = { keyList = keys, all = {}, actEnd = 30 }
        for i = 0, 29 do o.all[#o.all + 1] = { k = keys[i % 3 + 1], t = i, a = i } end
        local r = SPT:Reihum(o)
        local o2 = { keyList = keys, all = {}, actEnd = 30 }
        for i = 0, 29 do
            local k = keys[i % 3 + 1]
            if k ~= "c" or i == 2 then o2.all[#o2.all + 1] = { k = k, t = i, a = i } end
        end
        local r2 = SPT:Reihum(o2)
        local got = string.format("%d/%d/%d · Lücke %.0f · Grenze %.1f · %s | c-Lücke %.0f · %s", r.per.a.n, r.per.b.n, r.per.c.n, r.worst, r.limit, tostring(r.ok), r2.per.c.maxGap, tostring(r2.ok))
        local want = "10/10/10 · Lücke 3 · Grenze 4.5 · true | c-Lücke 28 · false"
        return got == want, got, want
    end)
    Chk("T737", "M", "T-SN-TEST2-S9 Treffer richtig (Nachbildung): nur Stückpreis ≤ Max geplant, \"22\" = 22c, Ausrüstung 1 Stück, Standard 5g/1000, golden markiert", function()
        local key, ID = "i:990197301", 990197301
        local t = { key = key, kind = "item", itemID = ID, maxPrice = 100, qty = 10, budget = 10000, bought = 0, spent = 0 }
        local sv = { getT = Sn.GetTarget, des = Sn.DEStale, buys = Sn.itemBuys, fl = Sn.inFlight, res = Sn.result, hp = Sn.hasPlan, ic = A.IsCommodityItem }
        local res = { pcall(function()
            Sn.GetTarget = function(self, k) if k == key then return t end return sv.getT(self, k) end
            Sn.DEStale = function() return false end
            Sn.itemBuys, Sn.inFlight = {}, nil
            local r = { key = key, itemID = ID, commodity = false, time = Now(), listings = {
                { auctionID = 1, price = 110, qty = 1, buyout = 110, pass = true }, { auctionID = 2, price = 90, qty = 1, buyout = 90, pass = true } } }
            Sn.result = r
            local plan = Sn:PlanNext()
            Sn.hasPlan = plan ~= nil
            local o = {}
            SPT:NoteResult(o, t, r, 0)
            local marked = Sn:HitMarked(key)
            local o2 = {}
            SPT:NoteResult(o2, t, { key = key, listings = { { auctionID = 3, price = 120, qty = 1, buyout = 120, pass = true, planned = 1 } } }, 0)
            A.IsCommodityItem = function() return false end
            local qEquip = Sn:DefaultQty(ID, "", 100, 50000)
            A.IsCommodityItem = function() return true end
            local qWare = Sn:DefaultQty(ID, "", 100, 50000)
            local dq, db = Sn:NewTargetDefaults(nil, nil, nil)
            return string.format("Plan %s %s · geprüft %d, über Max %d · golden %s · falsch geplant erkannt %d · 22 -> %s · Ausrüstung %d, Ware %d · Standard %d/%d",
                tostring(plan and plan.listing and plan.listing.auctionID), tostring(plan and plan.total), o.hit9.checked, o.hit9.bad, tostring(marked), o2.hit9.bad,
                tostring(A:ParseMoney("22", "copper")), qEquip, qWare, dq, db)
        end) }
        Sn.GetTarget, Sn.DEStale, Sn.itemBuys, Sn.inFlight, Sn.result, Sn.hasPlan, A.IsCommodityItem = sv.getT, sv.des, sv.buys, sv.fl, sv.res, sv.hp, sv.ic
        if not res[1] then error(res[2], 0) end
        local want = "Plan 2 90 · geprüft 1, über Max 0 · golden true · falsch geplant erkannt 1 · 22 -> 22 · Ausrüstung 1, Ware 500 · Standard 1000/50000"
        return res[2] == want, res[2], want
    end)
    Chk("T738", "M", "T-SN-TEST2-S10 Geld-Sicherheit (Nachbildung): Menge und Budget stoppen genau, kein Kauf ohne Raste/Taste, nie über Max, Gold-Abgleich", function()
        if (GetMoney and GetMoney() or 0) < 1000 then return "SKIP", "weniger als 10s Gold – Planung durch das Gold begrenzt" end
        local key, ID = "i:990197302", 990197302
        local t = { key = key, kind = "item", itemID = ID, maxPrice = 12, qty = 7, budget = 1000, bought = 0, spent = 0 }
        local sv = { getT = Sn.GetTarget, des = Sn.DEStale, buys = Sn.itemBuys, fl = Sn.inFlight, res = Sn.result, trig = Sn.inTrigger }
        local res = { pcall(function()
            Sn.GetTarget = function(self, k) if k == key then return t end return sv.getT(self, k) end
            Sn.DEStale = function() return false end
            Sn.itemBuys, Sn.inFlight, Sn.inTrigger = {}, nil, nil
            local function R() return { key = key, itemID = ID, commodity = true, time = Now(), listings = {
                { price = 10, qty = 5, pass = true }, { price = 12, qty = 10, pass = true }, { price = 13, qty = 50, pass = true } } } end
            Sn.result = R()
            local p1 = Sn:PlanNext()
            t.qty, t.budget = 100, 70
            Sn.result = R()
            local p2 = Sn:PlanNext()
            local okBuy = Sn:Buy({ kind = "commodity", key = key, itemID = ID, qty = 1, total = 10 })
            return string.format("Menge %d/%d · Budget %d/%d · ohne Taste %s · über Max %s, = Max %s · Gold %s/%s",
                p1 and p1.qty or -1, p1 and p1.total or -1, p2 and p2.qty or -1, p2 and p2.total or -1, tostring(okBuy),
                tostring((Sn:PriceOK({ maxPrice = 100 }, 2, 202))), tostring((Sn:PriceOK({ maxPrice = 100 }, 1, 100))),
                tostring(SPT:GoldCheck(1000, 995, 5)), tostring(SPT:GoldCheck(1000, 990, 5)))
        end) }
        Sn.GetTarget, Sn.DEStale, Sn.itemBuys, Sn.inFlight, Sn.result, Sn.inTrigger = sv.getT, sv.des, sv.buys, sv.fl, sv.res, sv.trig
        if not res[1] then error(res[2], 0) end
        local want = "Menge 7/74 · Budget 6/62 · ohne Taste false · über Max false, = Max true · Gold true/false"
        return res[2] == want, res[2], want
    end)
    Chk("T739", "M", "T-SN-TEST2-S11 Pausen (Nachbildung): Markt-Scan und Vollscan pausieren, danach sucht der Sniper von selbst weiter; Drossel -> langsamer, dann wieder schnell", function()
        local pace = A.pace
        local sv = { sc = A.IsScanning, fs = Sn.FullScanRunning, cn = Sn.CheckNext, ia = Sn.IsArmed, hw = Sn.HitWaiting, mr = Sn.MaybeRemind, mf = Sn.MeterFlush,
            hot = Sn.HasOwnTargets, s = Sn.search, p = Sn.pending, ls = Sn.lastSearch, wr = Sn.waitReason, ws = Sn.waitSince, nsa = Sn.nextSearchAt, bn = Sn.blockNoted,
            bb = A.Buy and A.Buy.Blocks, sh = A.Seller and A.Seller.HasWork, wb = A.Watcher and A.Watcher.IsBusy,
            gap = pace and pace.gap, err = pace and pace.errors, ans = pace and pace.answers }
        local scanning, full, calls = false, false, 0
        local res = { pcall(function()
            A.IsScanning = function() return scanning end
            Sn.FullScanRunning = function() return full end
            Sn.CheckNext = function() calls = calls + 1; Sn.lastSearch = -100; return true end
            Sn.IsArmed, Sn.HitWaiting, Sn.MaybeRemind, Sn.MeterFlush, Sn.HasOwnTargets = function() return true end, function() return false end, function() end, function() end, function() return true end
            if A.Buy then A.Buy.Blocks = function() return false end end
            if A.Seller then A.Seller.HasWork = function() return false end end
            if A.Watcher then A.Watcher.IsBusy = function() return false end end
            Sn.search, Sn.pending, Sn.lastSearch = nil, nil, -100
            local steps = {}
            scanning = true; Sn:Tick(); steps[#steps + 1] = tostring(Sn.waitReason) .. " " .. calls
            scanning = false; Sn:Tick(); steps[#steps + 1] = "weiter " .. calls
            full = true; Sn:Tick(); steps[#steps + 1] = tostring(Sn.waitReason) .. " " .. calls
            full = false; Sn:Tick(); steps[#steps + 1] = "weiter " .. calls
            local o = { pauses = { { why = "scan", t0 = 0, t1 = 10, resume = 0.4 }, { why = "AH-Klick", t0 = 20, t1 = 20, resume = 1.2 } } }
            local pa = SPT:Pauses(o, 60)
            o.pauses[#o.pauses + 1] = { why = "vollscan", t0 = 30, t1 = 40 }
            local pb = SPT:Pauses(o, 60)
            local drossel = "-"
            if pace then
                pace.gap = nil
                local g0 = A:QueryGap()
                A:QueryError()
                local g1 = A:QueryGap()
                for _ = 1, 40 do A:QueryAnswered() end
                local g2 = A:QueryGap()
                drossel = string.format("langsamer %s, wieder schnell %s", tostring(g1 > g0), tostring(g2 <= math.max(g0, A.GAP_MIN_FIXED or 0.2) * 1.5 + 0.05))
            end
            return table.concat(steps, " · ") .. string.format(" · Pausen ok %s, ohne Suche erkannt %d · %s", tostring(pa.ok), pb.bad, drossel)
        end) }
        A.IsScanning, Sn.FullScanRunning, Sn.CheckNext, Sn.IsArmed, Sn.HitWaiting, Sn.MaybeRemind, Sn.MeterFlush, Sn.HasOwnTargets = sv.sc, sv.fs, sv.cn, sv.ia, sv.hw, sv.mr, sv.mf, sv.hot
        Sn.search, Sn.pending, Sn.lastSearch, Sn.waitReason, Sn.waitSince, Sn.nextSearchAt, Sn.blockNoted = sv.s, sv.p, sv.ls, sv.wr, sv.ws, sv.nsa, sv.bn
        if A.Buy then A.Buy.Blocks = sv.bb end
        if A.Seller then A.Seller.HasWork = sv.sh end
        if A.Watcher then A.Watcher.IsBusy = sv.wb end
        if pace then pace.gap, pace.errors, pace.answers = sv.gap, sv.err, sv.ans end
        if not res[1] then error(res[2], 0) end
        local want = "scan 0 · weiter 1 · vollscan 1 · weiter 2 · Pausen ok true, ohne Suche erkannt 1 · langsamer true, wieder schnell true"
        return res[2] == want, res[2], want
    end)
    Chk("T740", "M", "T-SN-TEST2-S12 verpasst (Nachbildung): Treffer verschwindet nach 2 s bzw. 5 s -> 2 verpasst, Ø 3,5 s, schnellstens 2 s", function()
        local t = { key = "i:990197303", maxPrice = 100 }
        local o = {}
        SPT:NoteResult(o, t, { key = t.key, listings = { { auctionID = 1, price = 90, qty = 1 }, { auctionID = 2, price = 95, qty = 1 }, { auctionID = 3, price = 120, qty = 1 } } }, 0)
        SPT:NoteResult(o, t, { key = t.key, listings = { { auctionID = 2, price = 95, qty = 1 }, { auctionID = 3, price = 120, qty = 1 } } }, 2)
        SPT:NoteResult(o, t, { key = t.key, listings = { { auctionID = 3, price = 120, qty = 1 } } }, 5)
        local m = SPT:Missed(o)
        local got = string.format("Treffer %d · verpasst %d · Ø %.1f s · schnellstens %.1f s", o.hitNew, m.n, m.avg or -1, m.min or -1)
        local want = "Treffer 2 · verpasst 2 · Ø 3.5 s · schnellstens 2.0 s"
        return got == want, got, want
    end)
    Chk("T741", "M", "T-SN-TEST2-S13 Ruckeln (Nachbildung): ein Frame 40 ms -> FEHLER, alle ≤ 20 ms -> OK (erste 5 Bilder zählen nicht)", function()
        local a, b = {}, {}
        for _ = 1, 10 do SPT:NoteFrame(a, 16, 60); SPT:NoteFrame(b, 20, 50) end
        SPT:NoteFrame(a, 40, 25)
        local sa, sb = SPT:Smooth(a), SPT:Smooth(b)
        local got = string.format("%.0f ms, über 33: %d, %s | %.0f ms, %s", sa.frameMax, sa.over, tostring(sa.ok), sb.frameMax, tostring(sb.ok))
        local want = "40 ms, über 33: 1, false | 20 ms, true"
        return got == want, got, want
    end)
    Chk("T742", "M", "T-SN-TEST2 Ergebnis oben: 3–4 einfache Sätze (Ziele, Takt, Lücke, Treffer/gekauft/verpasst, Ruckeln), danach S1–S13 mit OK/FEHLER", function()
        local last = { takt = { avg = 45, limit = 90 }, reihum = { nKeys = 3, worst = 5 }, hitsN = 3, missedN = 3, smooth = { frameMax = 20 } }
        local s4 = { bought = 1, hit = true }
        local a = SPT:TopLines({ { group = "J T613", status = "PASS" } }, last, s4)
        local b = SPT:TopLines({ { group = "J T734", status = "FAIL" } }, { takt = { avg = 45, limit = 90 }, reihum = { nKeys = 1, worst = 2 }, hitsN = 0, missedN = 0, smooth = { frameMax = 48 } }, {})
        local got = table.concat({ a[2], a[3], a[4], a[5], b[5], a[6]:sub(1, 22) }, " | ")
        local want = "Der Sniper prüfte 3 Ziele reihum, Ø 45 Suchen/Min. (Server erlaubt 90). | Jedes Ziel spätestens alle 5 s. | 4 Treffer, 1 gekauft, 3 verpasst. | Kein Ruckeln. Alles OK. | Ruckeln: längster Frame 48 ms (Ziel ≤ 33 ms). FEHLER bei: S13. | Einzeln: S1 OK · S2 -"
        return got == want, got, want
    end)
end

function SPT:BuildSteps(TR, B, Chk, Skp)
    local Sn = A.Sniper
    local o
    self.last = nil
    -- S4 (vorher, ausserhalb der Sandbox)
    B(function()
        local s4 = self.s4 or { status = "SKIP", detail = "Teil ohne vorherige Abfrage gestartet (/ahs testroutine sniper)" }
        if s4.status == "SKIP" then return Skp("T616", "J", "SN1951-S4 echter Mausrad-Kauf: eine Raste = genau 1 Stück (≤ 5c, nur nach Ja)", s4.detail) end
        Chk("T616", "J", "SN1951-S4 echter Mausrad-Kauf: eine Raste = genau 1 Stück (≤ 5c, nur nach Ja)", function()
            return s4.status == "PASS", s4.detail, "gekauft 1 · höchstens 1 gesendet"
        end)
    end)
    -- S1/S5–S13: beobachten
    B(function()
        if not A:IsAHOpen() then
            for _, x in ipairs(SPT.OBS_IDS) do Skp(x[1], "J", "SN1951-" .. x[2], "Auktionshaus nicht offen") end
            return
        end
        local ok, why = self:StartObserve(TR)
        if not ok then
            for _, x in ipairs(SPT.OBS_IDS) do Skp(x[1], "J", "SN1951-" .. x[2], why) end
            return
        end
        A:Print(string.format(L["Sniper-Abnahme: beobachte den Sniper %d s (Kaufen ist gesperrt) ..."], self.OBSERVE))
        local t0 = Now()
        return "WAIT", function() return Now() - t0 >= SPT.OBSERVE or not A:IsAHOpen() end, self.OBSERVE + 10, function()
            o = SPT:StopObserve()
            if not o then return end
            Chk("T613", "J", "SN1951-S1 Treffer bleiben stehen, bis gekauft oder vom Server als weg gemeldet", function()
                -- TB119-3: 0 passende Angebote ist kein Fehler (Markt hatte nichts) -> SKIP mit Gründen
                if o.shownN == 0 and o.vanished == 0 then
                    return "SKIP", string.format("Markt hatte nichts Passendes: %d Angebote geprüft · über Max %d · eigene %d · Lockangebot %d · weg %d · Suchen %d",
                        o.checked or 0, o.tooDear or 0, o.ownN or 0, o.baitN or 0, o.goneN or 0, #o.all)
                end
                return o.shownN > 0 and o.vanished == 0, string.format("%d Treffer angezeigt · ohne Grund verschwunden %d%s · Suchen %d", o.shownN, o.vanished,
                    #o.vanishedIDs > 0 and (" (" .. table.concat(o.vanishedIDs, ",", 1, math.min(5, #o.vanishedIDs)) .. ")") or "", #o.all),
                    "≥ 1 Treffer · 0 ohne Grund verschwunden"
            end)
            Chk("T617", "J", "SN1951-S5 Ruckeln: Ø ≥ 30 Bilder/s, kein Frame > 50 ms, Sync-Warteschlange ≤ 10", function()
                local avg = o.fpsN > 0 and o.fpsSum / o.fpsN or nil
                local ok2 = (avg == nil or avg >= 30) and o.frameMax <= 50 and o.queueMax <= 10
                local mix = (A.Sync and A.Sync.QueueMix) and select(2, pcall(A.Sync.QueueMix, A.Sync)) or "-"
                return ok2, string.format("Ø %s / min %s Bilder/s · längster Frame %.0f ms · Sync-Warteschlange max %d (%s)%s", avg and string.format("%.0f", avg) or "?",
                    o.fpsMin and string.format("%.0f", o.fpsMin) or "?", o.frameMax, o.queueMax, tostring(o.queueMixMax or mix),
                    o.slowAt and (" · längster Schritt " .. o.slowAt) or ""), "≥ 30 · ≤ 50 ms · ≤ 10"
            end)
            Chk("T618", "J", "SN1951-S6 Reaktionszeit: neues Angebot spätestens nach < 5 s sichtbar (Abstand der Suchen + Suchdauer)", function()
                local r, g, d = SPT:Reaction(o)
                SPT.lastReaction = r                                   -- PS: für "/ahs testroutine tempo"
                if not r then return false, string.format("zu wenige Suchen (%d)", #o.searches), "< 5 s" end
                return r < 5, string.format("spätestens nach %.1f s (Abstand %.1f s + Suche %.1f s, %d Suchen)", r, g, d or 0, #o.searches), "< 5 s"
            end)
            SPT:ObsChecks(o, Chk, Skp)
        end
    end)
    -- S2/S3: an einem Testziel in der echten Anzeige (Ereignisse nachgespielt, Kaufen bleibt gesperrt)
    B(function()
        Chk("T614", "J", "SN1951-S2 Zielzeile = bestätigte Käufe: gesendet -> Fehler zählt nicht, Bestätigung zählt", function()
            local key = "i:990196501"
            local t = { key = key, kind = "item", itemID = 990196501, maxPrice = 100, qty = 10, budget = 1000, bought = 0, spent = 0 }
            local saved = { buys = Sn.itemBuys, getT = Sn.GetTarget, md = Sn.MarkDead, rf = Sn.ReportFail, pn = Sn.PlanNext, pr = A.Print, after = Sn.AfterPurchase,
                lbe = A.AH.lastBuyError, ls = Sn.lastSearch, lp = Sn.lastPurchase }
            local res = { pcall(function()
                Sn.itemBuys = {}
                Sn.GetTarget = function(self, k) if k == key then return t end return saved.getT(self, k) end
                Sn.MarkDead, Sn.ReportFail, Sn.PlanNext, A.Print, Sn.AfterPurchase = function() end, function() end, function() return nil end, function() end, function() end
                table.insert(Sn.itemBuys, { key = key, tgt = t, itemID = t.itemID, qty = 1, cost = 90, time = Now(), auctionID = 1 })
                table.insert(Sn.itemBuys, { key = key, tgt = t, itemID = t.itemID, qty = 1, cost = 95, time = Now(), auctionID = 2 })
                local p0 = Sn:ProgressText(t)
                A.AH.lastBuyError = { id = 1, msg = "Test", time = Now() }
                Sn:OnEvent("AUCTION_HOUSE_SHOW_ERROR", 1)
                Sn:OnEvent("AUCTION_HOUSE_PURCHASE_COMPLETED", 2)
                return A:PlainText(p0), A:PlainText(Sn:ProgressText(t)), t.bought, t.spent
            end) }
            Sn.itemBuys, Sn.GetTarget, Sn.MarkDead, Sn.ReportFail, Sn.PlanNext, A.Print, Sn.AfterPurchase = saved.buys, saved.getT, saved.md, saved.rf, saved.pn, saved.pr, saved.after
            A.AH.lastBuyError, Sn.lastSearch, Sn.lastPurchase = saved.lbe, saved.ls, saved.lp
            if not res[1] then error(res[2], 0) end
            local ok = res[4] == 1 and res[5] == 95 and tostring(res[2]):find("+2", 1, true) ~= nil
            return ok, string.format("gesendet: \"%s\" · danach \"%s\"", tostring(res[2]), tostring(res[3])), "0/10 (+2 gesendet) · danach 1/10, 95c"
        end)
        Chk("T615", "J", "SN1951-S3 Pause sichtbar (Zielzeile, Status) und \"fortsetzen\" wirkt sofort", function()
            local id = 990196502
            local saved = { ip = Sn.itemPause[id], pw = Sn.pauseWhy[id], fi = Sn.failIDs[id], hide = A.HideDeadOffer, nf = Sn.NoteFail, pr = A.Print, dead = Sn.dead, ls = Sn.lastSearch }
            local res = { pcall(function()
                A.HideDeadOffer, Sn.NoteFail, A.Print, Sn.dead = function() end, function() return false end, function() end, {}
                for i = 1, 3 do Sn:MarkDead({ auctionID = 99019650 + i, price = 1, qty = 1 }, id, "Test") end
                local txt = Sn:PauseText(id) or "-"
                local listed = false
                for _, x in ipairs(Sn:PausedItems()) do if x == id then listed = true end end
                Sn:ResumeItem(id)
                return txt, listed, Sn:ItemPaused(id)
            end) }
            A.HideDeadOffer, Sn.NoteFail, A.Print, Sn.dead, Sn.lastSearch = saved.hide, saved.nf, saved.pr, saved.dead, saved.ls
            Sn.itemPause[id], Sn.pauseWhy[id], Sn.failIDs[id] = saved.ip, saved.pw, saved.fi
            if not res[1] then error(res[2], 0) end
            local ok = res[2] ~= "-" and res[3] == true and res[4] == false
            return ok, string.format("\"%s\" · im Status %s · nach fortsetzen pausiert %s", res[2], tostring(res[3]), tostring(res[4])), "pausiert bis … · im Status · nicht mehr pausiert"
        end)
    end)
    -- SN-TEST2: Nachbildung S7–S13 und Ergebnis oben
    B(function() SPT:SimChecks(Chk) end)
end
