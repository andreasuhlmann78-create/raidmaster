if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.9 - Kern
-- Datenbank, Markt-Scan, Preisverlauf, Trends, Marktwert (Median),
-- Händlerpreise, Export, Befehle
--
-- WICHTIG: Alle Dateien des Addons benutzen NUR die globale
-- Tabelle "AHAnalyzerPro". Keine weiteren Namensräume.
-- ============================================================

local ADDON_NAME = ...

AHAnalyzerPro = AHAnalyzerPro or {}
-- Retail 12.x: die alten Item-/Zauber-Funktionen gibt es nur noch in C_Item / C_Spell
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local GetItemIcon = GetItemIcon or (C_Item and C_Item.GetItemIconByID)
local A = AHAnalyzerPro
local L = A.L

A.version = "0.65.37"
A.DONATE_URL = "https://www.paypal.com/ncp/payment/46R68N2BF7BTY"   -- Spenden (PayPal)
A.ICON = "Interface\\AddOns\\AHSentinel\\Media\\Icon"     -- eigenes Icon (Waage)
A.ADDON_NAME = ADDON_NAME or "AHSentinel"
A.SCAN_COOLDOWN = 900          -- Server erlaubt nur alle 15 Minuten einen Scan
A.DB_VERSION = 4
A.MAX_HISTORY = 300            -- max. Preis-Einträge pro Item
A.HISTORY_DAYS = 90            -- ältere Einträge werden gelöscht
A.MARKET_DAYS = 14             -- Marktwert = Median der Preise dieser Tage
A.FRESH_SECONDS = 2 * 3600     -- so lange gilt ein Preis als aktuell (für Händler-Schnäppchen)

-- ------------------------------------------------------------
-- Ausgabe
-- ------------------------------------------------------------
-- Test- und Entwicklerfunktionen (Selbsttest, Testmodus) nur für den Entwickler (GoldSentinelDev.lua)
function A:IsDev()
    local D = _G.GoldSentinelDev
    return D and D.IsDev and D:IsDev() or false
end
function A:RequireDev()
    local D = _G.GoldSentinelDev
    if not (D and D.Require) then return false end
    return D:Require("AHSentinel")
end

function A:Print(msg)
    print("|cff00d1d1[AHSentinel]|r " .. tostring(msg))
end

-- Abgefangene Fehler zusätzlich an die Prüfung melden (GoldSentinelTest.lua); die Chat-Ausgabe bleibt, wie sie ist.
function A:ReportError(where, msg)
    local GT = _G.GoldSentinelTest
    if GT and GT.Error then pcall(GT.Error, "AHSentinel", where, msg) end
end

-- Erwartete Fehler (SafeCall-Hilfen der Module): nur melden, wenn eine vorhandene Funktion einen Lua-Fehler wirft,
-- und dann höchstens einmal je Funktion und Sitzung.
A.reportedOnce = {}
function A:ReportOnce(key, where, msg)
    if key == nil or self.reportedOnce[key] then return end
    self.reportedOnce[key] = true
    self:ReportError(where, msg)
end

-- Simulation: Testmodus oder Testroutine. Aktionen mit Folgen (Händler, Post, Preis-Sync) werden dann nur protokolliert.
function A:Simulated()
    return (self.TestMode and self.TestMode.active) or (self.TestRoutine and self.TestRoutine.running) or false
end

-- Kampf: die Testroutine schaltet A.testCombat um (statt InCombatLockdown zu ersetzen - kein Taint)
function A:InCombat()
    if self.testCombat ~= nil then return self.testCombat and true or false end
    local G = _G.GoldSentinelGame
    if G and G.InCombat then return G.InCombat() and true or false end
    return (InCombatLockdown and InCombatLockdown()) and true or false
end

-- Nahtstelle für die Testroutine: A.apiOverride setzt NUR die Testroutine (false = "Funktion fehlt").
-- Ohne Test liefert A:API(name) einfach die Funktion des Spiels.
function A:API(name)
    local o = self.apiOverride
    if o then
        local v = o[name]
        if v == false then return nil end
        if v ~= nil then return v end
    end
    return _G[name]
end

-- Briefkasten: alle Zugriffe des Addons laufen hier durch. Normal direkt an WoW;
-- im Testmodus ersetzt A.TestMode diese Funktionen durch einen Test-Briefkasten.
A.Inbox = {}
for _, fn in ipairs({ "GetInboxNumItems", "GetInboxHeaderInfo", "GetInboxInvoiceInfo", "GetInboxItem",
    "GetInboxItemLink", "TakeInboxMoney", "TakeInboxItem" }) do
    A.Inbox[fn] = function(...)
        local real = A:API(fn)
        if real then return real(...) end
    end
end
function A.Inbox.Available()
    -- Test-Briefkasten (Testmodus oder Testroutine) zählt als vorhanden
    if A.TestMode and (A.TestMode.active or A.TestMode.realInbox) then return true end
    return A:API("GetInboxNumItems") ~= nil and A:API("TakeInboxMoney") ~= nil
end

-- Meldung groß in der Bildschirmmitte (wie eine Schlachtzugwarnung), mit Ton wenn erlaubt
function A:ScreenMessage(text, r, g, b, sound)
    text = "AHSentinel: " .. tostring(text)
    if self.TestMode and self.TestMode.active then text = "[Test] " .. text end
    local color = { r = r or 1, g = g or 0.82, b = b or 0 }
    local shown = false
    if RaidNotice_AddMessage and RaidWarningFrame then
        shown = pcall(RaidNotice_AddMessage, RaidWarningFrame, text, color)
    end
    if not shown and UIErrorsFrame and UIErrorsFrame.AddMessage then
        pcall(UIErrorsFrame.AddMessage, UIErrorsFrame, text, color.r, color.g, color.b)
    end
    if sound and self.db and self.db.settings.alertSound and PlaySound then
        pcall(PlaySound, 888)      -- gut hörbarer Klang (auch wenn man gerade woanders hinschaut)
    end
    self.lastScreenMessage = text
end

-- ------------------------------------------------------------
-- Internes Nachrichtensystem (Kern -> Oberfläche)
-- Ereignisse: SCAN_STARTED, SCAN_PROGRESS, SCAN_FINISHED,
--             SCAN_FAILED, DATA_CHANGED, WATCHLIST_CHANGED
-- ------------------------------------------------------------
A.listeners = A.listeners or {}

function A:On(event, fn)
    self.listeners[event] = self.listeners[event] or {}
    table.insert(self.listeners[event], fn)
end

function A:Fire(event, ...)
    local list = self.listeners[event]
    if not list then return end
    local yieldOK = self.yieldOK
    self.yieldOK = false            -- innerhalb von pcall darf eine Aufgabe nicht pausieren
    for _, fn in ipairs(list) do
        local ok, err = pcall(fn, ...)
        if not ok then
            self:Print(L["Fehler bei "] .. event .. ": " .. tostring(err))
            self:ReportError("Fire:" .. tostring(event), err)
        end
    end
    self.yieldOK = yieldOK
end

-- ------------------------------------------------------------
-- Aufgaben im Hintergrund (gegen Ruckeln)
-- Große Arbeiten (Scan auswerten, lange Listen aufbauen) laufen in kleinen
-- Portionen: pro Frame nur wenige Millisekunden, der Rest im nächsten Frame.
--   A:Job(name, fn)  - Aufgabe starten (gleicher Name ersetzt eine wartende)
--   A:Pause()        - in langen Schleifen aufrufen: gibt die Zeit ab, wenn
--                      das Frame-Budget aufgebraucht ist (außerhalb einer
--                      Aufgabe macht es nichts)
-- ------------------------------------------------------------
A.FRAME_BUDGET = 6              -- Millisekunden Rechenzeit pro Frame für Hintergrund-Aufgaben
A.jobs = {}
A.yieldOK = false
local jobStart = 0
local pauseCount = 0
local Clock = debugprofilestop

function A:Job(name, fn)
    for i = #self.jobs, 1, -1 do
        local j = self.jobs[i]
        if j.name == name and not j.started then table.remove(self.jobs, i) end
    end
    table.insert(self.jobs, { name = name, co = coroutine.create(fn) })
end

function A:HasJob(name)
    for _, j in ipairs(self.jobs) do if j.name == name then return true end end
    return false
end

function A:Pause()
    if not self.yieldOK then return end
    if Clock then
        if Clock() - jobStart < self.FRAME_BUDGET then return end
    else
        pauseCount = pauseCount + 1
        if pauseCount < 200 then return end
    end
    pauseCount = 0
    self.yieldOK = false
    coroutine.yield()
    self.yieldOK = true
end

local jobFrame = CreateFrame("Frame")
local RunJobs
jobFrame:SetScript("OnUpdate", function()
    if #A.jobs == 0 then return end
    RunJobs()
    if not Clock then return end
    local d = Clock() - jobStart
    -- Testroutine (T126): längste Rechenzeit pro Frame messen (nur wenn eingeschaltet)
    local m = A.jobMeasure
    if m then
        if d > (m.max or 0) then m.max = d end
        m.frames = (m.frames or 0) + 1
    end
    -- Diagnose-Protokoll: ein Frame Hintergrund-Arbeit über 16 ms
    if A.Diag and d > A.Diag.SLOW_MS then pcall(A.Diag.Add, A.Diag, "LANGSAM", "Hintergrund-Aufgabe " .. tostring(A.currentJob), d) end
end)
RunJobs = function()
    jobStart = Clock and Clock() or 0
    pauseCount = 0
    while #A.jobs > 0 do
        local j = A.jobs[1]
        j.started = true
        A.currentJob = j.name
        A.yieldOK = true
        local ok, err = coroutine.resume(j.co)
        A.yieldOK = false
        if not ok then
            table.remove(A.jobs, 1)
            A:Print(L["Fehler bei "] .. tostring(j.name) .. ": " .. tostring(err))
            A:ReportError("Job:" .. tostring(j.name), err)
        elseif coroutine.status(j.co) == "dead" then
            table.remove(A.jobs, 1)
        else
            return          -- Budget aufgebraucht: im nächsten Frame weiter
        end
        if Clock and Clock() - jobStart >= A.FRAME_BUDGET then return end
    end
end

-- ------------------------------------------------------------
-- Hilfsfunktionen
-- ------------------------------------------------------------
local function DeepCopy(t)
    if type(t) ~= "table" then return t end
    local c = {}
    for k, v in pairs(t) do c[k] = DeepCopy(v) end
    return c
end

local function FillDefaults(target, source)
    for k, v in pairs(source) do
        if target[k] == nil then
            target[k] = DeepCopy(v)
        elseif type(v) == "table" and type(target[k]) == "table" then
            FillDefaults(target[k], v)
        end
    end
end

function A:CountTable(t)
    local n = 0
    if type(t) == "table" then
        for _ in pairs(t) do n = n + 1 end
    end
    return n
end

-- ------------------------------------------------------------
-- WoW-Währung: Gold, Silber, Kupfer
-- 1 Gold = 100 Silber, 1 Silber = 100 Kupfer. Intern wird immer in Kupfer gerechnet.
-- Anzeige wahlweise mit den WoW-Münzsymbolen (Standard) oder mit Buchstaben.
-- ------------------------------------------------------------
local COIN_ICONS = {
    "|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:2:0|t",
    "|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t",
    "|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t",
}
local COIN_COLORS = { "ffd700", "c7c7cf", "eda55f" }

-- Kurzzeichen für Gold / Silber / Kupfer je Sprache des Addons
A.COIN_LETTERS = {
    deDE = { "g", "s", "c" },  enUS = { "g", "s", "c" },  frFR = { "po", "pa", "pc" },
    esES = { "o", "p", "c" },  esMX = { "o", "p", "c" },  ptBR = { "o", "p", "c" },
    itIT = { "o", "a", "r" },  ruRU = { "з", "с", "м" },  koKR = { "골", "실", "코" },
    zhCN = { "金", "银", "铜" }, zhTW = { "金", "銀", "銅" },
}

-- Eingabe: alle Kurzzeichen aller Sprachen -> 1 (Gold), 2 (Silber), 3 (Kupfer)
local UNIT_INDEX = {}
for _, letters in pairs(A.COIN_LETTERS) do
    for i, u in ipairs(letters) do UNIT_INDEX[u] = i end
end
-- "k" = Kupfer aus älteren Eingaben (bis 0.65.10 schrieb das Addon auf Deutsch "78k")
for u, i in pairs({ gold = 1, silber = 2, silver = 2, kupfer = 3, copper = 3, ["с"] = 2, ["c"] = 3, k = 3,
                   ["골드"] = 1, ["실버"] = 2, ["코퍼"] = 3, ["金币"] = 1, ["银币"] = 2, ["铜币"] = 3,
                   ["金幣"] = 1, ["銀幣"] = 2, ["銅幣"] = 3 }) do UNIT_INDEX[u] = i end

function A:SplitMoney(copper)
    copper = math.floor(math.abs(copper or 0) + 0.5)
    return math.floor(copper / 10000), math.floor((copper % 10000) / 100), copper % 100
end

function A:CoinUnit(i)
    if self.db and self.db.settings.moneyStyle == "letters" then
        local letters = self.COIN_LETTERS[self.uiLang or "enUS"] or self.COIN_LETTERS.enUS
        return letters[i], true
    end
    return COIN_ICONS[i], false
end

-- Kupfer -> "12 [Gold] 34 [Silber] 56 [Kupfer]"
-- compact = true für schmale Spalten: ab 100 Gold nur Gold, ab 1 Gold ohne Kupfer
function A:FormatMoney(copper, compact)
    if not copper then return "|cff888888-|r" end
    local negative = copper < 0
    local g, s, c = self:SplitMoney(copper)
    local show = { g > 0, s > 0, c > 0 }
    if compact then
        if g >= 100 then show = { true, false, false }
        elseif g > 0 then show = { true, s > 0, false } end
    end
    if not (show[1] or show[2] or show[3]) then show[3] = true end   -- 0 Kupfer
    local values = { g, s, c }
    local parts = {}
    for i = 1, 3 do
        if show[i] then
            local unit, isLetter = self:CoinUnit(i)
            if isLetter then
                table.insert(parts, "|cff" .. COIN_COLORS[i] .. values[i] .. unit .. "|r")
            else
                table.insert(parts, values[i] .. unit)
            end
        end
    end
    local text = table.concat(parts, " ")
    if negative then text = "-" .. text end
    return text
end

-- Text ohne Farben und Symbole (Münzsymbole werden zu g/s/c) - für Berichte und schmale Spalten
function A:PlainText(text)
    if type(text) ~= "string" then return text end
    local letters = self.COIN_LETTERS[self.uiLang or "enUS"] or self.COIN_LETTERS.enUS
    for i = 1, 3 do
        local icon = COIN_ICONS[i]
        local a, b = 1, nil
        while true do
            a, b = text:find(icon, 1, true)
            if not a then break end
            text = text:sub(1, a - 1) .. letters[i] .. text:sub(b + 1)
        end
    end
    text = text:gsub("|T.-|t", ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    return text
end

-- Kupfer -> Text zum Eintippen/Bearbeiten ("12g 50s 3c", ohne Farben). In allen Sprachen g/s/c, nie "k"
-- ("78k" wurde als 78 000 gelesen). Eingaben in jeder Sprache versteht ParseGold weiter.
A.INPUT_LETTERS = { "g", "s", "c" }
function A:FormatMoneyInput(copper)
    if not copper or copper <= 0 then return "" end
    local letters = self.INPUT_LETTERS
    local g, s, c = self:SplitMoney(copper)
    local parts = {}
    if g > 0 then table.insert(parts, g .. letters[1]) end
    if s > 0 then table.insert(parts, s .. letters[2]) end
    if c > 0 then table.insert(parts, c .. letters[3]) end
    return table.concat(parts, " ")
end

-- frühere Kurzform (z.B. "12.34g") -> jetzt ebenfalls Gold/Silber/Kupfer, kompakt
function A:FormatGoldShort(copper)
    if not copper then return "-" end
    return self:FormatMoney(copper, true)
end

-- Text -> Kupfer. Versteht:
--   "12.5" / "12,5"         = Gold mit Nachkommastellen
--   "12g 50s 3c", "12g50s"  = Gold, Silber, Kupfer (Kurzzeichen jeder Sprache: g/s/c, po/pa/pc, з/с/м, 金/银/铜 ...)
function A:ParseGold(text)
    if not text then return nil end
    text = string.lower(tostring(text)):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    text = text:gsub("|t[^|]*|t", ""):gsub("%s+", " ")
    if text:match("^%s*$") then return nil end
    local total, units, plain = 0, 0, nil
    for num, unit in text:gmatch("([%d%.,]+)%s*([^%d%s%.,]*)") do
        local n = tonumber((num:gsub(",", ".")))
        if not n then return nil end
        if unit == "" then
            if plain or units > 0 then return nil end
            plain = n
        else
            local i = UNIT_INDEX[unit]
            if not i then return nil end
            total = total + n * ({ 10000, 100, 1 })[i]
            units = units + 1
        end
    end
    if plain and units > 0 then return nil end
    if plain then total = plain * 10000 end
    total = math.floor(total + 0.5)
    if total <= 0 then return nil end
    return total
end

-- Zeitdifferenz lesbar
function A:FormatAgo(timestamp)
    if not timestamp or timestamp == 0 then return L["nie"] end
    local diff = time() - timestamp
    if diff < 60 then return string.format(L["vor %d Sek."], diff) end
    if diff < 3600 then return string.format(L["vor %d Min."], math.floor(diff / 60)) end
    if diff < 86400 then return string.format(L["vor %d Std."], math.floor(diff / 3600)) end
    return string.format(L["vor %d Tagen"], math.floor(diff / 86400))
end

function A:FormatDuration(seconds)
    seconds = math.max(0, math.floor(seconds or 0))
    return string.format("%d:%02d", math.floor(seconds / 60), seconds % 60)
end

-- Prozentwert farbig
function A:FormatPercent(value)
    if not value then return "|cff666666-|r" end
    if value > 0.05 then
        return string.format("|cff33dd55+%.1f%%|r", value)
    elseif value < -0.05 then
        return string.format("|cffff5544%.1f%%|r", value)
    end
    return "|cffaaaaaa0.0%|r"
end

-- ------------------------------------------------------------
-- Datenbank
-- ------------------------------------------------------------
local DEFAULTS = {
    dbVersion = 4,
    marketData = {},      -- [itemID] = { name, history = { {t, p, q}, ... } }
    watchlist = {},       -- [itemID] = { name, buyBelow, sellAbove, added }
    scanLog = {},         -- letzte Scans { t, items, duration }
    lastScanTime = 0,     -- time() des letzten Scan-Starts
    totalScans = 0,
    lastOwnScan = nil,    -- { t, data = { [itemID] = { price, qty } } }
    markets = {},         -- [Server|Fraktion] = { data, own, recv, mixed } (Preise je Auktionshaus, 0.65.30)
    names = {},           -- [Sprache][itemID] = Item-Name (alle WoW-Sprachen)
    namesSent = {},       -- [itemID] = zuletzt geteilt (time())
    vendorPrices = {},    -- [itemID] = Händlerpreis pro Stück in Kupfer (0 = nicht verkaufbar)
    vendorBuy = {},       -- [itemID] = was ein Händler pro Stück VERLANGT (beim Händler gelesen)
    vendorCost = {},      -- [itemID] = { gold, qty, costs = { { kind, id, name, amount } }, t } (Händler-Artikel gegen Währung)
    deStats = {},         -- [Gruppe] = { n = Entzauberungen, mats = { [itemID] = { times, total } } } (gelernt)
    deShared = {},        -- [Kürzel "#..."] = { t, g = { [Gruppe] = { n, mats } } } (von anderen geteilt, keine Namen)
    chars = {},           -- [Name-Realm] = { name, realm, class, money, gold = { {t, m} }, bags, bank }
    sync = {
        enabled = true,
        received = 0,     -- empfangene Preise gesamt
        lastReceived = 0,
        peers = {},       -- [Kürzel] = zuletzt gehört (time()), keine Namen
    },
    settings = {
        buttonPos = nil,
        windowPos = nil,
        alertSound = true,
        minQuantityForTrends = 1,
        theme = "classic",        -- "classic" (wie das Auktionshaus) oder "modern"
        scale = 1,                -- Fenstergröße
        helpSeen = false,         -- Willkommens-Hilfe schon gezeigt
        lastTab = nil,            -- zuletzt geöffneter Reiter
        sniperFilters = false,    -- Sniper-Filter aufgeklappt
        ahIntegration = false,    -- false = eigenes Fenster (Standard), true = im Auktionshaus-Fenster
        tooltipInfo = true,       -- Preis, Ø 7 Tage und Trend im Item-Tooltip
        tooltipChartDays = 7,     -- Preisdiagramm unter dem Item-Tooltip (0 = aus, 1 / 7 / 30 Tage)
        tooltipVendor = true,     -- Händlerpreis im Item-Tooltip
        craftPanel = true,        -- Gewinn-Fenster neben dem Berufsfenster
        tooltipChars = true,      -- Bestand deiner Twinks im Item-Tooltip
        tooltipDE = true,         -- Entzauberungswert im Item-Tooltip
        tooltipDEMode = "mats",   -- Entzaubern im Tooltip: "short" / "mats" (Standard) / "all"
        openWithAH = true,        -- Hauptfenster mit dem Auktionshaus öffnen und schliessen
        mailButtons = true,       -- Knöpfe "AH-Post abholen" am Briefkasten
        chartEMA = true,          -- EMA-Linien im Tab Charts
        ahSize = nil,             -- gemessene Größe des Auktionshaus-Fensters { w, h }
        moneyStyle = "icons",     -- Geldanzeige: "icons" (Münzsymbole) oder "letters" (g/s/c ...)
        nameLocale = "auto",      -- Sprache der angezeigten Item-Namen ("auto" = wie der Client)
        nameLocaleChosen = false, -- true, sobald der Spieler selbst eine Sprache gewählt hat
        uiLanguage = "auto",      -- Sprache des Addons ("auto" = wie der Client, sonst "deDE"/"enUS")
    },
    lists = {
        items = {},               -- [Name] = { created, entries = { [itemID] = { qty, added } } }
        tolerance = 100,          -- Max-Preis der Sniper-Ziele aus einer Liste: % vom Marktwert
    },
    ledger = {
        entries = {},             -- Buchungen { t, kind = "sale"/"buy"/"deposit", itemID, name, qty, amount, cut, refund, player, src }
        seen = {},                -- [Schlüssel] = Zeit: schon gebuchte Rechnungen aus dem Briefkasten
        period = "7",             -- zuletzt gewählter Zeitraum
    },
    seller = {
        undercut = "copper",      -- unterbieten um: "copper" (1 Kupfer), "p1" (1 %), "p5" (5 %)
        duration = 2,             -- zuletzt gewählte Dauer (1 kurz, 2 mittel, 3 lang)
        items = {},               -- [itemID] = { price, duration, qty } zuletzt benutzt
    },
    watcher = {
        enabled = false,          -- Schnäppchen-Wächter an/aus
        threshold = 50,           -- Treffer, wenn Preis <= x % vom Marktwert
        minValue = 10,            -- nur Waren mit Marktwert ab x Kupfer pro Stück
        budget = 500000,          -- höchstens so viel Kupfer pro Schnäppchen (50 Gold)
        interval = 20,            -- Sekunden zwischen zwei Runden
        mode = "combined",        -- "combined" = alle Kategorien in einer Suche, "single" = einzeln
        cats = {                  -- Kategorien (nur Handwerkswaren, keine Ausrüstung)
            herb = true, metal = true, cloth = true, leather = true, enchanting = true,
            elemental = true, gems = true, cooking = true, consumable = false,
        },
        found = 0,                -- bestätigte Schnäppchen gesamt
    },
    sniper = {
        targets = {},                                 -- [key] = Ziel (Item oder Suchbegriff, Preis, Menge, Budget, Filter)
        binds = { "MOUSEWHEELUP", "MOUSEWHEELDOWN" }, -- Kauf-Auslöser im Sniper-Modus
        armed = false,                                -- Sniper-Modus an/aus
        interval = 0,                                 -- Sekunden zwischen zwei Suchen (0 = so oft der Server erlaubt)
        instantBuy = true,                            -- Waren mit EINER Raste kaufen (Preis wird vorab geholt)
        imported = false,                             -- alte Watchlist-Ziele übernommen
    },
}
A.DEFAULTS = DEFAULTS     -- nur lesen (Diagnose-Protokoll: geänderte Einstellungen)

-- Alte Daten (Version 3.x) so weit wie möglich übernehmen
local function MigrateOldMarketData(old)
    local new = {}
    if type(old) ~= "table" then return new end
    for itemID, entry in pairs(old) do
        local id = tonumber(itemID)
        if id and type(entry) == "table" and type(entry.history) == "table" then
            local hist = {}
            for _, h in ipairs(entry.history) do
                if type(h) == "table" and h.price and (h.time or h.timestamp) then
                    table.insert(hist, { t = h.time or h.timestamp, p = h.price, q = h.quantity or h.qty or 0 })
                end
            end
            if #hist > 0 then
                table.sort(hist, function(a, b) return a.t < b.t end)
                new[id] = { name = entry.name, history = hist }
            end
        end
    end
    return new
end

-- Beschädigte Einträge entfernen (z. B. nach einem Absturz beim Speichern), damit kein Reiter und kein Tooltip
-- an einem einzelnen kaputten Wert scheitert. Gesunde Daten bleiben unverändert. Liefert die Zahl der Reparaturen.
-- Preisverläufe: nur erster und letzter Eintrag werden geprüft (schnell beim Einloggen); ist einer kaputt, wird
-- der ganze Verlauf dieses Items gefiltert.
function A:RepairDB(db)
    if type(db) ~= "table" then return 0 end
    local n = 0
    local function okPoint(e) return type(e) == "table" and type(e.t) == "number" and type(e.p) == "number" end
    if type(db.marketData) ~= "table" then db.marketData = {}; n = n + 1 end
    -- keine Namen speichern (0.65.26): Absender geteilter Entzauberungen und Sync-Mitspieler nur als Kürzel
    if type(db.sync) == "table" and type(db.sync.peers) == "table" then
        for k in pairs(db.sync.peers) do if type(k) ~= "string" or k:sub(1, 1) ~= "#" then db.sync.peers[k] = nil end end
    end
    if A.Disenchant and A.Disenchant.MigrateShared then pcall(A.Disenchant.MigrateShared, A.Disenchant, db.deShared) end
    db.depositLog, db.depositHistory = nil, nil   -- Messung der Einstellgebühr (0.65.17-0.65.20), gestrichen mit der Regel vom 9. Nov.
    for id, e in pairs(db.marketData) do
        if type(e) ~= "table" then
            db.marketData[id] = nil; n = n + 1
        elseif type(e.history) ~= "table" then
            e.history = {}; n = n + 1
        else
            local h = e.history
            if #h > 0 and not (okPoint(h[1]) and okPoint(h[#h])) then
                local keep = {}
                for _, x in ipairs(h) do if okPoint(x) then keep[#keep + 1] = x end end
                e.history = keep; n = n + 1
            end
        end
    end
    local function onlyTables(t)
        if type(t) ~= "table" then return end
        for k, v in pairs(t) do if type(v) ~= "table" then t[k] = nil; n = n + 1 end end
    end
    onlyTables(db.chars)
    onlyTables(db.vendorCost)
    if type(db.sniper) == "table" then onlyTables(db.sniper.targets) end
    if type(db.lists) == "table" then onlyTables(db.lists.items) end
    if type(db.ledger) == "table" and type(db.ledger.entries) == "table" then
        local keep = {}
        for _, e in ipairs(db.ledger.entries) do if type(e) == "table" then keep[#keep + 1] = e else n = n + 1 end end
        if #keep ~= #db.ledger.entries then db.ledger.entries = keep end
    end
    if db.recipes ~= nil and type(db.recipes) ~= "table" then db.recipes = {}; n = n + 1 end
    if type(db.recipes) == "table" then onlyTables(db.recipes) end
    if db.settings and db.settings.lastSub ~= nil and type(db.settings.lastSub) ~= "table" then db.settings.lastSub = nil; n = n + 1 end
    return n
end

function A:InitDB()
    -- Umbenennung AH Analyzer Pro -> AHSentinel (0.62.0): die alten Daten liegen in AHAnalyzerProDB,
    -- geladen vom Übergangs-Ordner "AHAnalyzerPro". Einmal übernehmen, dort nur einen Vermerk lassen.
    if type(AHSentinelDB) ~= "table" and type(AHAnalyzerProDB) == "table" and not AHAnalyzerProDB.migratedTo
        and AHAnalyzerProDB.marketData then
        AHSentinelDB = AHAnalyzerProDB
        AHAnalyzerProDB = { migratedTo = "AHSentinel", time = time() }
        self.migratedFromOld = true
    end
    if type(AHSentinelDB) ~= "table" then
        AHSentinelDB = DeepCopy(DEFAULTS)
    elseif AHSentinelDB.dbVersion ~= self.DB_VERSION then
        local old = AHSentinelDB
        AHSentinelDB = DeepCopy(DEFAULTS)
        AHSentinelDB.marketData = MigrateOldMarketData(old.marketData)
        if type(old.settings) == "table" then
            AHSentinelDB.settings.windowPos = nil
        end
        self:Print(L["Datenbank auf Version 4 umgestellt."])
    end
    FillDefaults(AHSentinelDB, DEFAULTS)
    self.repairedDB = self:RepairDB(AHSentinelDB)
    -- Vorsichtshalber: Cooldown-Zeit muss eine time()-Zeit sein, keine GetTime()-Zeit
    if (AHSentinelDB.lastScanTime or 0) > time() + 60 then
        AHSentinelDB.lastScanTime = 0
    end
    self.db = AHSentinelDB
    -- 0.59.27: Addon-Fenster ist standardmäßig vom Auktionshaus gelöst (eigenes, frei vergrößerbares Fenster)
    if not self.db.settings.detachedWindow then
        self.db.settings.ahIntegration = false
        self.db.settings.detachedWindow = true
    end
    -- 0.59.20: Sniper sucht standardmäßig so oft wie möglich (alter Standard 3 Sek.)
    local sn = self.db.sniper
    if sn and not sn.fastSearch then
        if sn.interval == 3 then sn.interval = 0 end
        sn.fastSearch = true
    end
    -- Item-Namen folgen der Client-Sprache, solange der Spieler nichts anderes gewählt hat
    if not self.db.settings.nameLocaleChosen then self.db.settings.nameLocale = "auto" end
    self:ApplyUILanguage()
    -- Fehler des Addons auch im normalen Spiel zählen (GoldSentinelTest.lua). Nach jedem InitDB neu, weil
    -- InitDB AHSentinelDB durch eine neue Tabelle ersetzen kann (Migration).
    local GT = _G.GoldSentinelTest
    if GT and GT.TrackErrors then pcall(GT.TrackErrors, "AHSentinel", self.version, self.db) end
end

-- ------------------------------------------------------------
-- Item-Infos
-- ------------------------------------------------------------
-- Name in der Sprache deines WoW-Clients (für die Suche im Auktionshaus)
function A:GetClientItemName(itemID)
    local entry = self.db and self.db.marketData[itemID]
    if entry and entry.name and not entry.name:find("^Item #") then
        return entry.name
    end
    local name = GetItemInfo and GetItemInfo(itemID)
    if name then
        if entry then entry.name = name end
        if self.Names then self.Names:Learn(itemID, name) end
        return name
    end
    -- Client kennt das Item (noch) nicht: im Hintergrund nachladen (Retail), dann erscheint der Name beim nächsten Aufbau
    self:QueueItemLoad(itemID)
    -- eingebaute Namensliste in der Client-Sprache
    local builtin = self.Names and self.Names:BuiltinGet(itemID, self.Names:ClientLocale())
    if builtin then return builtin end
    return (entry and entry.name) or ("Item #" .. tostring(itemID))
end

-- ------------------------------------------------------------
-- Retail (12.x): Item-Daten kennt der Client erst nach einer Anfrage beim Server.
-- Der Komplett-Scan liefert nur Item-IDs - ohne Nachladen stünde überall "Item #12345".
-- Gedrosselt nachladen (40 pro Sekunde), damit der Server nicht überlastet wird.
-- Classic braucht das nicht: dort lädt GetItemInfo selbst nach.
-- ------------------------------------------------------------
local LOAD_PER_TICK, LOAD_TICK = 10, 0.25
local loadQueue, loadQueued, loadHead, loadFrame = {}, {}, 1, nil
local NEED_LOAD = (_G.GetItemInfo == nil) and C_Item ~= nil and C_Item.RequestLoadItemDataByID ~= nil
A.NEED_ITEM_LOAD = NEED_LOAD

function A:QueueItemLoad(itemID)
    if not NEED_LOAD or type(itemID) ~= "number" or itemID <= 0 or loadQueued[itemID] then return end
    loadQueued[itemID] = true
    loadQueue[#loadQueue + 1] = itemID
    if not loadFrame then
        loadFrame = CreateFrame("Frame")
        local acc = 0
        loadFrame:SetScript("OnUpdate", function(f, dt)
            acc = acc + (dt or 0)
            if acc < LOAD_TICK then return end
            acc = 0
            for _ = 1, LOAD_PER_TICK do
                local id = loadQueue[loadHead]
                if not id then
                    wipe(loadQueue); loadHead = 1
                    f:Hide()
                    return
                end
                loadQueue[loadHead] = nil
                loadHead = loadHead + 1
                pcall(C_Item.RequestLoadItemDataByID, id)
            end
        end)
    end
    loadFrame:Show()
end

-- noch offene Nachlade-Anfragen (für Selbsttest/Diagnose)
function A:PendingItemLoads()
    return math.max(0, #loadQueue - loadHead + 1)
end

-- Name in der gewählten Anzeigesprache (Standard Englisch).
-- Unbekannt in dieser Sprache -> Name aus dem eigenen Client.
function A:GetItemName(itemID)
    local N = self.Names
    if N and self.db then
        local loc = N:DisplayLocale()
        if loc ~= N:ClientLocale() then
            local nm = N:Get(itemID, loc)
            if nm then return nm end
        end
    end
    local nm = self:GetClientItemName(itemID)
    -- Chinesische Schrift hat keine Umlaute: fehlt der Name in der Sprache, lesbar umschreiben (ö -> oe)
    if nm and (self.uiLang == "zhCN" or self.uiLang == "zhTW") and nm:find("[\195]") then
        nm = self:Transliterate(nm)
    end
    return nm
end

local TRANSLIT = {
    ["ä"] = "ae", ["ö"] = "oe", ["ü"] = "ue", ["Ä"] = "Ae", ["Ö"] = "Oe", ["Ü"] = "Ue", ["ß"] = "ss",
    ["é"] = "e", ["è"] = "e", ["ê"] = "e", ["à"] = "a", ["â"] = "a", ["ç"] = "c", ["î"] = "i", ["ï"] = "i",
    ["ô"] = "o", ["û"] = "u", ["ù"] = "u", ["ñ"] = "n", ["á"] = "a", ["í"] = "i", ["ó"] = "o", ["ú"] = "u",
    ["ã"] = "a", ["õ"] = "o", ["É"] = "E", ["À"] = "A", ["Ç"] = "C",
}
-- Latein-Sonderzeichen in einfache Buchstaben umschreiben (für Schriften ohne diese Zeichen)
function A:Transliterate(s)
    if type(s) ~= "string" then return s end
    return (s:gsub("\195[\128-\191]", function(c) return TRANSLIT[c] or c end))
end

function A:GetItemIcon(itemID)
    if GetItemIcon then
        local ok, icon = pcall(GetItemIcon, itemID)
        if ok and icon then return icon end
    end
    return "Interface\\Icons\\INV_Misc_QuestionMark"
end

-- Item per Name in den Marktdaten finden (exakt, sonst eindeutiger Teiltreffer)
-- Item per Name (jede Sprache), Item-ID oder Item-Link finden.
-- Rückgabe: itemID oder nil, Anzahl passender Items
function A:FindItemByName(text)
    if not text or text == "" or not self.db then return nil end
    if self.Names then return self.Names:Resolve(text) end
    return tonumber(text)
end

-- ------------------------------------------------------------
-- Gebote unter Wert: jedes Gebot, das irgendwo gelesen wird (Komplett-Scan im alten
-- Auktionshaus, Einzelsuchen im Einkauf/Sniper/Preisprüfung), wird gemerkt, wenn es
-- deutlich unter dem Marktwert liegt. Der Profit-Reiter zeigt sie ("Gebote unter Wert").
-- ------------------------------------------------------------
A.BID_PREFILTER = 0.7          -- nur merken, wenn das nächste Gebot <= 70 % des Marktwerts ist
A.BID_MAX = 600                -- höchstens so viele merken (älteste fliegen raus)

-- timeLeft: Restzeit in Sekunden (Obergrenze), mv: Marktwert pro Stück (optional, sonst berechnet)
function A:NoteBid(itemID, nextBid, qty, timeLeft, buyout, isMine, mv)
    if not (self.db and itemID and nextBid and nextBid > 0) or isMine then return false end
    qty = math.max(1, qty or 1)
    mv = mv or self:GetMarketValue(itemID)
    if not mv or mv <= 0 then return false end
    if nextBid / qty > mv * self.BID_PREFILTER then return false end
    local bids = self.db.bids
    if not bids then bids = {}; self.db.bids = bids end
    local now = time()
    local key = itemID .. ":" .. qty .. ":" .. (buyout or 0) .. ":" .. math.floor(timeLeft or 0) .. ":" .. nextBid
    local e = bids[key]
    if not e then
        e = {}
        bids[key] = e
        self.bidCount = (self.bidCount or 0) + 1
    end
    e.itemID, e.nextBid, e.qty, e.buyout = itemID, nextBid, qty, buyout
    e.seen = now
    e.endsBy = now + (timeLeft or 43200)
    -- bidCount fehlt, wenn die Gebote aus der gespeicherten Datei stammen: dann einmal zählen
    if not self.bidCount then self:PruneBids(false) end
    if (self.bidCount or 0) > (self.BID_MAX or 600) then self:PruneBids(true) end
    return true
end

function A:PruneBids(hard)
    local bids = self.db and self.db.bids
    if not bids then return end
    local now, n, list = time(), 0, {}
    for k, e in pairs(bids) do
        if (e.endsBy or 0) < now or now - (e.seen or 0) > 2 * 86400 then bids[k] = nil
        else n = n + 1; table.insert(list, { k = k, seen = e.seen or 0 }) end
    end
    if hard and n > self.BID_MAX then
        table.sort(list, function(a, b) return a.seen < b.seen end)
        for i = 1, n - self.BID_MAX do bids[list[i].k] = nil end
        n = self.BID_MAX
    end
    self.bidCount = n
end

-- Gebote, die mindestens threshold % unter dem Marktwert liegen (noch nicht abgelaufen)
function A:GetBidDeals(threshold)
    self:PruneBids()
    local out = {}
    for _, e in pairs(self.db and self.db.bids or {}) do
        local mv = self:GetMarketValue(e.itemID)
        if mv and mv > 0 then
            local unit = e.nextBid / e.qty
            local discount = (mv - unit) / mv * 100
            if discount >= (threshold or 30) then
                table.insert(out, {
                    itemID = e.itemID, name = self:GetItemName(e.itemID), price = math.floor(unit + 0.5), ref = mv,
                    -- WoW Forever: die Einstellgebühr fürs Weiterverkaufen wird nie erstattet
                    discount = discount, profit = math.floor(self:NetSale(e.itemID, self:RealPrice(e.itemID, { noCurrent = true }) or mv, 1) - unit),
                    quantity = e.qty,
                    nextBid = e.nextBid, endsBy = e.endsBy, seen = e.seen, bidDeal = true,
                })
            end
        end
    end
    return out
end

-- ------------------------------------------------------------
-- Preisverlauf und Kennzahlen
-- ------------------------------------------------------------
-- fromSync = true: Preis kam von einem Mitspieler
-- Gibt true zurück, wenn ein neuer Eintrag entstanden ist
-- unverified = true: verdächtig billiger Waren-Preis (mögliches Lockangebot), zählt erst nach Bestätigung
function A:RecordPrice(itemID, price, quantity, timestamp, fromSync, unverified)
    local db = self.db
    local entry = db.marketData[itemID]
    if not entry then
        entry = { history = {} }
        db.marketData[itemID] = entry
    end
    if not entry.name or entry.name:find("^Item #") then
        entry.name = (GetItemInfo and GetItemInfo(itemID)) or entry.name or ("Item #" .. itemID)
        if entry.name:find("^Item #") then self:QueueItemLoad(itemID) end
    end

    local h = entry.history
    -- Doppelte vermeiden: gibt es schon einen Eintrag innerhalb von 2 Minuten, nicht erneut speichern
    for i = #h, 1, -1 do
        local d = h[i].t - timestamp
        if d < 0 then d = -d end
        if d <= 120 then return false end
        if h[i].t < timestamp - 120 then break end
    end

    local newEntry = { t = timestamp, p = price, q = quantity or 0 }
    if fromSync then newEntry.s = 1 end
    if unverified then newEntry.u = 1 end
    self:InvalidateMarket(itemID)
    if self.InvalidateLiquidity then self:InvalidateLiquidity(itemID) end

    -- zeitlich sortiert einfügen (Sync-Daten können älter sein als eigene)
    local pos = #h + 1
    while pos > 1 and h[pos - 1].t > timestamp do pos = pos - 1 end
    table.insert(h, pos, newEntry)

    local cutoff = time() - self.HISTORY_DAYS * 86400
    while #entry.history > 0 and (entry.history[1].t < cutoff or #entry.history > self.MAX_HISTORY) do
        table.remove(entry.history, 1)
    end
    return true
end

function A:GetHistory(itemID)
    local entry = self.db and self.db.marketData[itemID]
    return entry and entry.history or {}
end

-- Zählt ein Eintrag für Preise und Statistik? Unbestätigte (mögliche Lockangebote) nicht.
local function Usable(e) return e and not e.u end
A.Usable = Usable

-- letzter bestätigter Eintrag (Index)
local function LastUsable(h, before)
    for i = (before or #h), 1, -1 do
        if Usable(h[i]) then return i end
    end
    return nil
end

function A:GetCurrent(itemID)
    local h = self:GetHistory(itemID)
    local i = LastUsable(h)
    if i then return h[i].p, h[i].q, h[i].t end
    return nil
end

-- Veränderung zum vorherigen Scan in %
function A:GetChangeSinceLastScan(itemID)
    local h = self:GetHistory(itemID)
    -- nur vollständige Scans vergleichen (ein Seiten-Scan sieht oft nur einen Teil der Angebote)
    local full = self.FullScanTimes and self:FullScanTimes(time() - (self.LIQ_DAYS or 14) * 86400)
    local i, j
    for k = #h, 1, -1 do
        local e = h[k]
        if Usable(e) and (not full or not next(full) or full[e.t]) then
            if not i then i = k elseif not j then j = k; break end
        end
    end
    if not j then return nil end
    local prev, cur = h[j].p, h[i].p
    if not prev or prev <= 0 then return nil end
    return (cur - prev) / prev * 100
end

-- Veränderung über einen Zeitraum in %
-- Vergleich: aktueller Preis gegen den letzten Preis, der mindestens
-- "seconds" alt ist. Gibt es so alte Daten noch nicht -> nil.
function A:GetTrend(itemID, seconds)
    local h = self:GetHistory(itemID)
    local ci = LastUsable(h)
    if not ci then return nil end
    local cur = h[ci]
    local limit = cur.t - seconds
    local ref = nil
    for i = ci - 1, 1, -1 do
        if Usable(h[i]) and h[i].t <= limit then
            ref = h[i]
            break
        end
    end
    if not ref or ref.p <= 0 then return nil end
    return (cur.p - ref.p) / ref.p * 100
end

-- Median einer Zahlenliste (die Liste wird dabei sortiert)
local function Median(values)
    local n = #values
    if n == 0 then return nil end
    table.sort(values)
    if n % 2 == 1 then return values[(n + 1) / 2] end
    return (values[n / 2] + values[n / 2 + 1]) / 2
end
A.Median = Median

-- Durchschnitt, Median und Min/Max im Zeitraum. seconds = nil -> alles
function A:GetStats(itemID, seconds)
    local h = self:GetHistory(itemID)
    if #h == 0 then return nil end
    local limit = seconds and (time() - seconds) or 0
    local sum, n, minP, maxP = 0, 0, nil, nil
    local values = {}
    for _, e in ipairs(h) do
        if e.t >= limit and Usable(e) then
            sum = sum + e.p
            n = n + 1
            values[n] = e.p
            if not minP or e.p < minP then minP = e.p end
            if not maxP or e.p > maxP then maxP = e.p end
        end
    end
    if n == 0 then return nil end
    return { avg = sum / n, median = Median(values), min = minP, max = maxP, count = n }
end

-- ------------------------------------------------------------
-- Marktwert: gewichteter Median der Preise der letzten 14 Tage.
-- Der Median ist robust: ein einzelnes Wucher- oder Lockangebot verschiebt ihn kaum.
-- Neuere Preise zählen stärker (Halbwertszeit MARKET_HALFLIFE Tage), damit der Wert einem
-- Preissturz nicht tagelang hinterherhinkt. Mondpreise (…99s 99c), die mehr als das
-- Dreifache des normalen Medians betragen, zählen gar nicht.
-- Gibt es weniger als 3 Preise in 14 Tagen, zählen die letzten 3.
-- ------------------------------------------------------------
A.MARKET_HALFLIFE = 3
local marketCache = {}
function A:ClearMarketCache() wipe(marketCache) end

function A:InvalidateMarket(itemID)
    if itemID then marketCache[itemID] = nil else wipe(marketCache) end
end

-- Median mit Gewichten: list = { {v=, w=}, ... }
local function WeightedMedian(list)
    if #list == 0 then return nil end
    table.sort(list, function(a, b) return a.v < b.v end)
    local total = 0
    for _, e in ipairs(list) do total = total + e.w end
    local acc, half = 0, total / 2
    for i, e in ipairs(list) do
        acc = acc + e.w
        if acc > half + 1e-9 then return e.v end
        if math.abs(acc - half) <= 1e-9 then
            local nx = list[i + 1]
            return nx and (e.v + nx.v) / 2 or e.v
        end
    end
    return list[#list].v
end
A.WeightedMedian = WeightedMedian

function A:GetMarketValue(itemID)
    local h = self:GetHistory(itemID)
    local n = #h
    if n == 0 then return nil end
    local first, last = h[1], h[n]
    local hour = math.floor(time() / 3600)
    local c = marketCache[itemID]
    if c and c.n == n and c.last == last.t and c.first == first.t and c.hour == hour then
        return c.v
    end
    local now = time()
    local limit = now - self.MARKET_DAYS * 86400
    local list = {}
    for i = n, 1, -1 do
        if h[i].t < limit then break end
        if Usable(h[i]) then list[#list + 1] = { v = h[i].p, t = h[i].t } end
    end
    if #list < 3 then
        list = {}
        for i = n, 1, -1 do
            if Usable(h[i]) then list[#list + 1] = { v = h[i].p, t = h[i].t } end
            if #list >= 3 then break end
        end
    end
    if #list == 0 then
        marketCache[itemID] = { n = n, last = last.t, first = first.t, hour = hour, v = nil }
        return nil
    end
    -- Mondpreise entfernen (nur wenn deutlich über dem normalen Median und noch etwas übrig bleibt)
    -- Vergleichswert: Median der normalen Preise (ohne Schnapszahlen)
    local plain = {}
    for _, e in ipairs(list) do if not self:IsOddPrice(e.v) then plain[#plain + 1] = e.v end end
    local med = Median(plain)
    local kept = {}
    for _, e in ipairs(list) do
        if not (self:IsOddPrice(e.v) and med and e.v > med * 3) then kept[#kept + 1] = e end
    end
    if #kept > 0 then list = kept end
    -- neuere Preise stärker gewichten (bezogen auf den neuesten Eintrag)
    local newest = list[1].t
    for _, e in ipairs(list) do if e.t > newest then newest = e.t end end
    local hl = (self.MARKET_HALFLIFE or 3) * 86400
    for _, e in ipairs(list) do e.w = 0.5 ^ ((newest - e.t) / hl) end
    local v = WeightedMedian(list)
    if v then v = math.floor(v + 0.5) end
    marketCache[itemID] = { n = n, last = last.t, first = first.t, hour = hour, v = v }
    return v
end

-- Preis eingebrochen? Die letzten zwei Preise (mind. 6 Std. auseinander, beide aus den letzten
-- 4 Tagen) liegen unter 60 % des Marktwerts. Ein einzelnes billiges Angebot gilt noch nicht als Einbruch.
A.CRASH_FACTOR = 0.6
function A:IsCrashed(itemID)
    local mv = self:GetMarketValue(itemID)
    if not mv or mv <= 0 then return false end
    local h = self:GetHistory(itemID)
    local i = LastUsable(h)
    if not i then return false end
    local cur = h[i]
    if cur.t < time() - 4 * 86400 or cur.p >= mv * self.CRASH_FACTOR then return false end
    for k = i - 1, 1, -1 do
        local e = h[k]
        if Usable(e) and e.t <= cur.t - 6 * 3600 then
            if e.t < time() - 4 * 86400 then return false end
            return e.p < mv * self.CRASH_FACTOR
        end
    end
    return false
end

-- Was ein Verkauf heute realistisch bringt (pro Stück, vor Gebühr): höchstens Marktwert, und
-- höchstens 5 % über dem günstigsten aktuellen Angebot (letzte 3 Tage) - teurer kauft keiner.
-- ------------------------------------------------------------
-- Realer Wert eines Items (Anweisung "Werte stimmen", 9. Nov.): Quellen in dieser Reihenfolge
--   1. eigene echte Verkäufe der letzten 14 Tage (Buchhaltung)          source "sale"
--   2. Sofortpreis = knapp unter dem günstigsten aktuellen Angebot, höchstens der Median   source "ah"
--   3. Median der Angebote (Marktwert, 14 Tage)                          source "market"
-- Ausreisser: aktuelles Angebot unter 10 % oder über 300 % des Medians zählt nicht (unsure = true).
-- Preis älter als PRICE_OLD_HOURS -> old = true ("Preis alt").
-- ------------------------------------------------------------
A.PRICE_OLD_HOURS = 6
A.OUTLIER_LOW, A.OUTLIER_HIGH = 0.10, 3.00
A.SALE_DAYS = 14
-- opts.noCurrent = true: das aktuelle günstigste Angebot NICHT als Wert nehmen (z. B. Schnäppchen/Flips: genau dieses
-- Angebot kauft man ja - der Wiederverkauf richtet sich nach eigenen Verkäufen bzw. dem Median)
function A:PriceInfo(itemID, opts)
    if not itemID then return nil end
    local median = self:GetMarketValue(itemID)
    local cur, _, t = self:GetCurrent(itemID)
    local info = { median = median, current = cur, currentTime = t }
    local age = t and (time() - t) or nil
    info.old = age ~= nil and age > self.PRICE_OLD_HOURS * 3600
    local sale = self.Ledger and self.Ledger.AverageSalePrice and self.Ledger:AverageSalePrice(itemID, self.SALE_DAYS)
    local curOK = cur and cur > 0
    if curOK and median and median > 0 and (cur < median * self.OUTLIER_LOW or cur > median * self.OUTLIER_HIGH) then
        curOK, info.unsure = false, true
    end
    if sale and sale > 0 then
        info.value, info.source, info.sale = sale, "sale", sale
    elseif curOK and not info.old and not (opts and opts.noCurrent) then
        local v = math.max(1, cur - 1)
        if median and median > 0 then v = math.min(v, median) end
        info.value, info.source = v, "ah"
    elseif median then
        info.value, info.source = median, "market"
    elseif curOK and not (opts and opts.noCurrent) then
        info.value, info.source = cur, "ah"
    end
    if not info.value then return nil end
    return info
end
-- ------------------------------------------------------------
-- EINE Preisfunktion für alles (Anweisung "Werte stimmen" Punkt 8): Tooltip, Gewinn-Fenster, Schnäppchen, Flips,
-- Heute tun, Entzaubern (Block und Summe), Inventarwert, Vergleich mit dem Händler. Kein Fenster rechnet selbst.
-- Andere Addons (ProfessionSentinel): AHAnalyzerPro:RealPrice(itemID) / AHAnalyzerPro:RealValue(itemID, qty)
-- ------------------------------------------------------------
-- Wert pro Stück (brutto, vor Gebühren); ohne Daten nil. Zweiter Rückgabewert: PriceInfo (Quelle, Median ...)
function A:RealPrice(itemID, opts)
    local i = self:PriceInfo(itemID, opts)
    return i and i.value, i
end

-- Wert von qty Stück NACH Gebühren, mindestens der Händlerpreis (Punkt 7: was man sicher bekommt)
-- zurück: Gesamtwert, Wert pro Stück (brutto), PriceInfo, true wenn der Händler mehr zahlt
function A:RealValue(itemID, qty, opts)
    qty = qty or 1
    local price, info = self:RealPrice(itemID, opts)
    local vendor = self:GetVendorPrice(itemID)
    vendor = (type(vendor) == "number" and vendor > 0) and vendor * qty or 0
    if not price then
        if vendor > 0 then return vendor, nil, nil, true end
        return nil
    end
    local net = self:NetSale(itemID, price, qty, opts and opts.auctions)
    if vendor > net then return vendor, price, info, true end
    return net, price, info, false
end

-- alte Schnittstelle (auch für andere Addons): Verkaufspreis pro Stück = realer Wert
function A:GetSalePrice(itemID)
    local v, info = self:RealPrice(itemID)
    if not v then return nil end
    return v, info and info.current or nil
end

-- ------------------------------------------------------------
-- Lockangebote bei Waren: ganz unten Angebote über genau 1 Stück.
-- Sie zählen nirgends für Preise, Statistik, Sniper oder Vorschläge.
-- ------------------------------------------------------------
A.BAIT_FACTOR = 0.7     -- Scan-Preis unter 70 % des Marktwerts -> nachprüfen

-- Waren (stapelbar) oder Einzelstück?
function A:IsCommodityItem(itemID)
    if not (GetItemInfo and itemID) then return false end
    local stack = select(8, GetItemInfo(itemID))
    return (stack or 1) > 1
end

-- Angebote (aufsteigend nach Preis): führende fremde 1-Stück-Angebote als Lockangebot markieren
function A:MarkBait(listings)
    local n = 0
    for _, l in ipairs(listings) do
        if l.qty == 1 and not l.own and n < 5 then l.bait = true; n = n + 1 else break end
    end
    return n
end

-- Angebotsliste ohne Lockangebote (1 Stück ganz unten) - für die Anzeige
function A:NoBait(listings)
    local out = {}
    for _, l in ipairs(listings or {}) do if not l.bait then table.insert(out, l) end end
    return out
end

-- erstes echtes (fremdes, kein Lockangebot) Angebot
function A:FirstReal(listings)
    for _, l in ipairs(listings) do
        if not l.bait and not l.own then return l end
    end
    return nil
end

-- Preis nachgeprüft (Einzelsuche): den unbestätigten Scan-Eintrag korrigieren, sonst neu eintragen
function A:VerifyPrice(itemID, price, quantity)
    local h = self:GetHistory(itemID)
    local now = time()
    for i = #h, 1, -1 do
        local e = h[i]
        if now - e.t > 1800 then break end
        if e.u then
            e.p, e.q, e.u, e.v = price, quantity or e.q, nil, 1
            self:InvalidateMarket(itemID)
            return true
        end
    end
    return self:RecordPrice(itemID, price, quantity, now)
end

-- verdächtig billig (nur Waren)?
function A:IsSuspicious(itemID, price)
    if not self:IsCommodityItem(itemID) then return false end
    local mv = self:GetMarketValue(itemID)
    return mv ~= nil and price < mv * self.BAIT_FACTOR
end

-- ------------------------------------------------------------
-- Zeitbasierte EMAs (exponentiell geglättet über eine Zeitspanne, nicht über
-- eine Anzahl Punkte - die Scans kommen unregelmäßig). Nur bestätigte Preise.
-- ------------------------------------------------------------
A.EMA = {
    { key = "6h", tau = 6 * 3600, label = "EMA 6 Std.", color = { 0.40, 0.75, 1.00 } },
    { key = "1d", tau = 86400, label = "EMA 1 Tag", color = { 1.00, 0.60, 0.20 } },
    { key = "7d", tau = 7 * 86400, label = "EMA 7 Tage", color = { 0.78, 0.45, 1.00 } },
}
A.EMA_MIN_POINTS = 10

function A:GetEMASeries(itemID, tau)
    local out, ema, lastT = {}, nil, nil
    for _, e in ipairs(self:GetHistory(itemID)) do
        if Usable(e) then
            if not ema then
                ema = e.p
            else
                local dt = math.max(0, e.t - lastT)
                ema = ema + (1 - math.exp(-dt / tau)) * (e.p - ema)
            end
            lastT = e.t
            out[#out + 1] = { t = e.t, v = ema }
        end
    end
    return out
end

function A:GetEMA(itemID, tau)
    local s = self:GetEMASeries(itemID, tau)
    if #s < self.EMA_MIN_POINTS then return nil end
    return s[#s].v
end

-- Kreuzungen der schnellen über/unter die langsame EMA: { {t, v, up = true/false}, ... }
function A:GetEMACrossings(itemID, fastTau, slowTau)
    local f, s = self:GetEMASeries(itemID, fastTau), self:GetEMASeries(itemID, slowTau)
    local out = {}
    if #f < self.EMA_MIN_POINTS then return out end
    local prev
    for i = 2, #f do
        local d = f[i].v - s[i].v
        if prev and d ~= 0 and (prev > 0) ~= (d > 0) then
            table.insert(out, { t = f[i].t, v = s[i].v, up = d > 0 })
        end
        if d ~= 0 then prev = d end
    end
    return out
end

-- Preis im Verhältnis zum Marktwert in Prozent (100 = üblicher Preis)
function A:GetMarketPercent(itemID, price)
    price = price or self:GetCurrent(itemID)
    local mv = self:GetMarketValue(itemID)
    if not price or not mv or mv <= 0 then return nil end
    return price / mv * 100
end

-- Prozent vom Marktwert farbig: grün = günstig, weiß = normal, orange/rot = teuer
function A:FormatMarketPercent(pct)
    if not pct then return "|cff666666-|r" end
    local color
    if pct <= 80 then color = "33dd55"
    elseif pct < 95 then color = "aadd88"
    elseif pct <= 110 then color = "dddddd"
    elseif pct <= 130 then color = "ffaa33"
    else color = "ff5544" end
    return string.format("|cff%s%d%%|r", color, math.floor(pct + 0.5))
end

-- ------------------------------------------------------------
-- Händlerpreis (Verkauf an einen NPC-Händler) pro Stück in Kupfer.
-- nil = noch unbekannt (Client kennt das Item noch nicht), 0 = nicht verkaufbar.
-- Einmal bekannt, bleibt er gespeichert.
-- ------------------------------------------------------------
function A:GetVendorPrice(itemID)
    local db = self.db
    local known = db and db.vendorPrices[itemID]
    if known then return known end
    if not GetItemInfo or not itemID then return nil end
    local info = { pcall(GetItemInfo, itemID) }
    if info[1] and info[2] and type(info[12]) == "number" then
        if db then db.vendorPrices[itemID] = info[12] end
        return info[12]
    end
    return nil
end

-- ------------------------------------------------------------
-- Händler-Einkaufspreis: was ein Händler pro Stück VERLANGT.
-- Wird automatisch gelesen, sobald du ein Händlerfenster öffnest.
-- ------------------------------------------------------------
function A:GetVendorBuyPrice(itemID)
    return self.db and itemID and self.db.vendorBuy[itemID] or nil
end

-- Was kostet ein Händler-Artikel? Moderner Client: C_MerchantFrame.GetItemInfo (Tabelle),
-- sonst das alte GetMerchantItemInfo. Rückgabe: price, stackCount, numAvailable, hasExtendedCost
-- (alle Funktionen über A:API: ohne Testroutine sind das genau die Funktionen des Spiels)
local function MerchantItem(i)
    local CMF = A:API("C_MerchantFrame")
    if CMF and CMF.GetItemInfo then
        local ok, info = pcall(CMF.GetItemInfo, i)
        if ok and type(info) == "table" then
            return info.price, info.stackCount, info.numAvailable, info.hasExtendedCost
        end
    end
    local getInfo = A:API("GetMerchantItemInfo")
    if getInfo then
        local ok, _, _, price, quantity, numAvailable, _, _, extendedCost = pcall(getInfo, i)
        if ok then return price, quantity, numAvailable, extendedCost end
    end
    return nil
end

-- Kosten in Marken/Währungen/Gegenständen (z. B. Merchant's Favor): { { kind, id, name, amount }, ... }
local function MerchantCosts(i)
    local costInfo, costItem = A:API("GetMerchantItemCostInfo"), A:API("GetMerchantItemCostItem")
    if not (costInfo and costItem) then return nil end
    local ok, n = pcall(costInfo, i)
    if not ok or not n or n < 1 then return nil end
    local out = {}
    for k = 1, n do
        local ok2, _, amount, link, currencyName = pcall(costItem, i, k)
        if ok2 and amount and amount > 0 then
            local itemID = type(link) == "string" and tonumber(link:match("item:(%d+)"))
            local curID = type(link) == "string" and tonumber(link:match("currency:(%d+)"))
            local name = currencyName or (itemID and A:GetItemName(itemID)) or (type(link) == "string" and link:match("%[(.-)%]")) or "?"
            table.insert(out, { kind = itemID and "item" or "currency", id = itemID or curID, name = name, amount = amount })
        end
    end
    return #out > 0 and out or nil
end

-- Händler-Kosten eines Items: { gold = Kupfer (kann 0 sein), qty = Stück je Kauf, costs = {...}, t = Zeit } oder nil
-- (für Artikel, die (auch) Währung kosten, z. B. Merchant's Favor auf WoW Forever; ProfessionSentinel nutzt das)
function A:GetVendorCost(itemID)
    return self.db and self.db.vendorCost and itemID and self.db.vendorCost[itemID] or nil
end

function A:ScanMerchant()
    local CMF = self:API("C_MerchantFrame")
    local count = self:API("GetMerchantNumItems") or (CMF and CMF.GetNumItems)
    if not (self.db and count) then return 0 end
    local getLink, getID = self:API("GetMerchantItemLink"), self:API("GetMerchantItemID")
    self.db.vendorCost = self.db.vendorCost or {}
    local okN, n = pcall(count)
    n = okN and n or 0
    local found = 0
    for i = 1, n do
        local price, quantity, numAvailable, extendedCost = MerchantItem(i)
        local link = getLink and getLink(i)
        local id = type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil
        if not id and getID then id = tonumber((select(2, pcall(getID, i)))) end
        local unlimited = (numAvailable == nil or numAvailable < 0)
        -- nur Gold-Preise (keine Marken/Abzeichen), nur unbegrenzt verfügbare Waren
        if id and price and price > 0 and not extendedCost and unlimited then
            local unit = math.max(1, math.floor(price / math.max(1, quantity or 1) + 0.5))
            local old = self.db.vendorBuy[id]
            if not old or unit < old then self.db.vendorBuy[id] = unit end
            found = found + 1
        end
        -- Währungskosten merken (der Gold-Preis zählt dafür nicht als Händlerpreis)
        if id and extendedCost then
            local costs = MerchantCosts(i)
            if costs then
                self.db.vendorCost[id] = { gold = price or 0, qty = math.max(1, quantity or 1), costs = costs, t = time() }
                found = found + 1
            end
        end
    end
    if found > 0 then self:Fire("DATA_CHANGED") end
    return found
end

-- Unglaubwürdiger Gewinn: ab 1000 % (Vergleichswert mehr als 11x so hoch wie der Preis).
-- Das sind fast immer Fehldaten (falscher Marktwert, Ausreißer, Platzhalter-Preise) - solche Items zeigen wir nicht als Schnäppchen.
A.ABSURD_PCT = 1000
function A:IsAbsurdProfit(price, ref)
    if not (price and ref) then return false end
    if price <= 0 then return ref > 0 end
    return (ref - price) / price * 100 >= self.ABSURD_PCT
end

-- ------------------------------------------------------------
-- Verkaufbarkeit (geschätzt aus der Scan-Historie)
-- Wir sehen keine Verkäufe, nur Angebote. Sinkt die angebotene Menge zwischen zwei Scans,
-- ist Ware verschwunden - meist verkauft (manchmal abgelaufen oder zurückgezogen).
-- Daraus: Abgänge pro Tag, wie oft das Item überhaupt da ist, und ein Vertrauen in den Marktwert.
-- ------------------------------------------------------------
A.LIQ_DAYS = 14
local liqCache = {}
function A:InvalidateLiquidity(itemID) if itemID then liqCache[itemID] = nil else wipe(liqCache) end end
-- Preisliste gewechselt (anderes Auktionshaus): alle Zwischenspeicher leeren
function A:ClearPriceCaches()
    wipe(liqCache)
    if self.ClearMarketCache then self:ClearMarketCache() end
end

-- Schnapszahl wie 1299g 99s 99c oder 2499g 99s 99c: typischer Mondpreis
-- (Endung …99s 9xc oder genau …99s 00c)
function A:IsOddPrice(copper)
    if not copper or copper < 10000 then return false end
    local r = copper % 10000
    return r >= 9990 or r == 9900
end

-- Vollständige Scans: mind. 80 % der Items des größten Scans im Zeitraum. Seiten-Scans erfassen oft
-- nur einen Teil des Auktionshauses - fehlt dort Ware, sähe das wie ein riesiger Abverkauf aus.
local fullCache = { key = nil, set = nil, n = 0 }
function A:FullScanTimes(limit)
    local log = self.db and self.db.scanLog or {}
    local key = #log .. ":" .. tostring(log[#log] and log[#log].t) .. ":" .. math.floor(limit / 3600)
    if fullCache.key == key then return fullCache.set, fullCache.n end
    local maxItems = 0
    for _, s in ipairs(log) do if (s.t or 0) >= limit and (s.items or 0) > maxItems then maxItems = s.items end end
    local set, n = {}, 0
    for _, s in ipairs(log) do
        if (s.t or 0) >= limit and maxItems > 0 and (s.items or 0) >= maxItems * 0.8 then set[s.t] = true; n = n + 1 end
    end
    fullCache.key, fullCache.set, fullCache.n = key, set, n
    return set, n
end

-- liefert { scans, presence (0-1), perDay (Verkäufe/Tag, vorsichtig geschätzt), avgQty, conf, odd }
-- Nur Einträge aus vollständigen Scans zählen. Ein Rückgang der Menge zählt nur zur Hälfte als Verkauf
-- (der Rest ist abgelaufen oder zurückgezogen), und mehr als die Hälfte der üblichen Angebotsmenge
-- pro Tag wird nie angenommen.
function A:GetLiquidity(itemID)
    local h = self:GetHistory(itemID)
    local n = #h
    local c = liqCache[itemID]
    local hour = math.floor(time() / 3600)
    if c and c.n == n and c.hour == hour then return c.v end
    local now = time()
    local limit = now - self.LIQ_DAYS * 86400
    local full, fullN = self:FullScanTimes(limit)
    -- noch kein Scan im Protokoll (z. B. nur Preise von Mitspielern): alle Einträge zählen
    local useAll = fullN == 0
    local scans, drops, qsum, first, last, prev = 0, 0, 0, nil, nil, nil
    for i = 1, n do
        local e = h[i]
        if e.t >= limit and Usable(e) and (useAll or full[e.t]) then
            scans = scans + 1
            qsum = qsum + (e.q or 0)
            first = first or e.t
            last = e.t
            if prev and prev.q and e.q and e.q < prev.q then drops = drops + (prev.q - e.q) end
            prev = e
        end
    end
    local span = (first and last and last > first) and math.max(1, (last - first) / 86400) or nil
    local avgQty = scans > 0 and qsum / scans or 0
    local perDay = span and (drops * 0.5) / span or nil
    if perDay then perDay = math.min(perDay, avgQty * 0.5) end
    local v = {
        scans = scans,
        presence = useAll and (scans > 0 and 1 or 0) or math.min(1, scans / fullN),
        perDay = perDay,
        avgQty = avgQty,
    }
    local mv = self:GetMarketValue(itemID)
    v.odd = self:IsOddPrice(mv) or false
    v.crashed = self:IsCrashed(itemID)
    -- selten da, Mondpreis, Preis gerade eingebrochen, oder kaum angeboten und kaum verkauft UND nicht regelmäßig im AH
    if scans < 3 or v.presence < 0.3 or v.odd or v.crashed or (avgQty <= 2 and (perDay or 0) < 0.3 and v.presence < 0.6) then
        v.conf = "gering"
    elseif scans >= 6 and v.presence >= 0.6 and (perDay or 0) >= 1 then
        v.conf = "hoch"
    else
        v.conf = "mittel"
    end
    liqCache[itemID] = { n = n, hour = hour, v = v }
    return v
end

-- Kann man dem Marktwert für Kauf-/Verkaufsentscheidungen trauen?
function A:IsReliable(itemID)
    local l = self:GetLiquidity(itemID)
    return l.conf ~= "gering", l
end

-- erwarteter Gewinn pro Tag: Gewinn pro Stück x was man selbst davon pro Tag verkauft.
-- Man ist nicht der einzige Verkäufer: höchstens MARKET_SHARE der geschätzten Tagesverkäufe,
-- höchstens die verfügbare Menge und höchstens so viel, wie 20 % des eigenen Golds kaufen (price).
A.MARKET_SHARE = 0.25
function A:ProfitPerDay(itemID, unitProfit, available, price)
    if not unitProfit or unitProfit <= 0 then return 0 end
    local l = self:GetLiquidity(itemID)
    local rate = (l.perDay or 0) * self.MARKET_SHARE
    if rate <= 0 then rate = 0.1 end
    if available and available > 0 then rate = math.min(rate, available) end
    if price and price > 0 and GetMoney then
        local share = self.Comfort and self.Comfort.TODAY_ITEM_SHARE or 0.2
        local afford = math.floor(GetMoney() * share / price)
        rate = math.min(rate, math.max(afford, 0.1))
    end
    return unitProfit * rate
end

-- Text für Tooltip und Listen: "~3/Tag" und Vertrauen
function A:LiquidityText(itemID)
    local l = self:GetLiquidity(itemID)
    local conf = (l.conf == "hoch" and "|cff33dd55" .. L["sicher"] .. "|r") or (l.conf == "mittel" and "|cffffcc33" .. L["mittel"] .. "|r")
        or "|cffff5544" .. L["unsicher"] .. "|r"
    local rate = l.perDay and (l.perDay >= 10 and string.format("~%d", math.floor(l.perDay + 0.5)) or string.format("~%.1f", l.perDay)) or "?"
    local text = string.format(L["%s/Tag verkauft (geschätzt), Marktwert %s"], rate, conf)
    if l.crashed then text = text .. " |cffff5544(" .. L["Preis gerade eingebrochen"] .. ")|r" end
    return text, l
end

-- ------------------------------------------------------------
-- Gebühren
-- WoW Forever (Regel vom 9. Nov. 2026): es gibt NUR EINE Gebühr, die AH-Gebühr
--   = max(5 % vom Verkaufspreis der Auktion, 1 Silber) PRO AUKTION (pro Stapel), bezahlt beim Einstellen.
--   Keine separate Einstellgebühr, kein Abzug beim Verkauf.
-- Andere Spielversionen (Era/TBC/Retail) unverändert: 5 % beim Verkauf, Einstellgebühr kommt beim Verkauf zurück.
-- Erkennung Forever: Interface 16000-19999 oder WOW_PROJECT_CAMELOT
-- ------------------------------------------------------------
A.FOREVER_MIN_FEE = 100
A.AH_FEE_PCT = 0.05
function A:IsForever()
    if self.forceForever ~= nil then return self.forceForever end      -- Selbsttest
    -- gemeinsame Erkennung aller GoldSentinel-Addons (GoldSentinelGame.lua); eigene Erkennung nur als Rückfall
    local G = _G.GoldSentinelGame
    if type(G) == "table" and G.flavor then return G.IsForever == true end
    if self._isForever == nil then
        local toc = GetBuildInfo and tonumber((select(4, GetBuildInfo()))) or 0
        local camelot = WOW_PROJECT_ID and WOW_PROJECT_CAMELOT and WOW_PROJECT_ID == WOW_PROJECT_CAMELOT
        self._isForever = (toc >= 16000 and toc < 20000) or camelot or false
    end
    return self._isForever
end
-- true = die Einstellgebühr kommt beim Verkauf zurück (Forever: es gibt keine)
function A:DepositRefunded() return not self:IsForever() end

-- Stück pro Auktion für die Gebühr: ein voller Stapel (nicht stapelbar: 1)
function A:StackSize(itemID)
    if not itemID or not GetItemInfo then return 1 end
    local ok, _, _, _, _, _, _, _, stack = pcall(GetItemInfo, itemID)
    if ok and type(stack) == "number" and stack > 0 then return stack end
    return 1
end

-- Forever: AH-Gebühr EINER Auktion mit diesem Gesamtpreis = max(5 %, 1 Silber)
--   390c -> 100c, 200c -> 100c, 10000c -> 500c, Stapel 20 x 1c (20c) -> 100c
function A:ForeverAuctionFee(auctionTotal)
    return math.max(math.floor((auctionTotal or 0) * self.AH_FEE_PCT + 0.5), self.FOREVER_MIN_FEE)
end

-- AH-Gebühr für qty Stück zum Stückpreis unitPrice
--   auctions bekannt (Verkaufen-Fenster): genau, qty gleichmässig auf die Auktionen verteilt
--   sonst: verkauft wird in vollen Stapeln -> Gebühr eines vollen Stapels anteilig pro Stück
-- Andere Versionen: 5 % vom Verkaufspreis
function A:SaleFee(itemID, unitPrice, qty, auctions)
    qty = qty or 1
    unitPrice = unitPrice or 0
    if not self:IsForever() then return math.floor(unitPrice * qty * self.AH_FEE_PCT + 0.5) end
    if auctions and auctions >= 1 then
        return auctions * self:ForeverAuctionFee(unitPrice * qty / auctions)
    end
    return math.floor(self:FeePerPiece(itemID, unitPrice) * qty + 0.5)
end

-- Erlös nach der AH-Gebühr (ohne die Einstellgebühr anderer Versionen, siehe ExpectedDepositLoss)
function A:NetSale(itemID, unitPrice, qty, auctions)
    local gross = (unitPrice or 0) * (qty or 1)
    return gross - self:SaleFee(itemID, unitPrice, qty, auctions)
end

-- Forever: AH-Gebühr pro Stück = max(5 % vom Stapelpreis, 1 Silber) / Stapelgröße
-- (ohne Stückpreis: nur die Mindestgebühr). Andere Versionen: 0 (dort gilt die 5 % beim Verkauf)
-- Stück je Auktion für die Gebühr (Befund im Spiel 9. Nov. 11:28: 1 Wollstoffballen zu 3s 98c kostet 1s, nicht 20c):
-- so viele, wie du dieses Item zuletzt auf einmal eingestellt hast; ohne Erfahrung 1 Stück (die Mindestgebühr 1s
-- trifft dann voll). Nie mehr als ein voller Stapel.
-- Befund 11:31/11:32 (HOCH): EINE feste, sichtbare Annahme, kein Wechsel ohne Hinweis:
--   1. selbst gewählt im Gewinn-Fenster (1 / 5 / 20 = Stapel), gemerkt je Item: A.db.settings.auctionSize[itemID]
--   2. gelernt: Median der letzten 10 eigenen Einstellungen (Buchhaltung, "deposit"-Buchungen: Stück je Auktion)
--   3. ohne Daten: 1 Stück (vorsichtig)
-- Nie mehr als ein voller Stapel - aber nur, wenn die Stapelgrösse wirklich bekannt ist (sonst kein Wechsel, sobald
-- GetItemInfo die Daten nachlädt). Zweiter Rückgabewert: Quelle "own" / "learned" / "default".
function A:AuctionSize(itemID)
    local n, src
    local own = self.db and self.db.settings and self.db.settings.auctionSize
    if own and itemID and own[itemID] then n, src = own[itemID], "own" end
    if not n and itemID and self.Ledger and self.Ledger.PostSizes then
        local list = self.Ledger:PostSizes(itemID, 10)
        if #list > 0 then
            table.sort(list)
            n, src = list[math.floor((#list + 1) / 2)], "learned"
        end
    end
    n, src = math.max(1, math.floor(tonumber(n) or 1)), src or "default"
    if itemID and GetItemInfo then
        local ok, name, _, _, _, _, _, _, stack = pcall(GetItemInfo, itemID)
        if ok and name and type(stack) == "number" and stack >= 1 then n = math.min(n, stack) end
    end
    return n, src
end
-- Umschalter im Gewinn-Fenster: 1 -> 5 -> 20 (bzw. voller Stapel) -> wieder gelernt/1
function A:CycleAuctionSize(itemID)
    if not (self.db and itemID) then return end
    self.db.settings.auctionSize = self.db.settings.auctionSize or {}
    local own = self.db.settings.auctionSize
    local stack = self:StackSize(itemID)
    local steps = { 1, 5, math.max(1, math.min(20, stack)) }
    local cur = own[itemID]
    local nextV
    if not cur then nextV = steps[1]
    else
        for i, v in ipairs(steps) do if v == cur then nextV = steps[i + 1] end end
        if not nextV and cur ~= steps[#steps] then nextV = steps[1] end
    end
    own[itemID] = nextV            -- nil = wieder automatisch (gelernt bzw. 1)
    return nextV
end

function A:FeePerPiece(itemID, unitPrice)
    if not self:IsForever() then return 0 end
    local per = itemID and self:AuctionSize(itemID) or 1
    return self:ForeverAuctionFee((unitPrice or 0) * per) / per
end

-- Alt (bis 0.65.17): Mindestgebühr auf eine Einstellgebühr anwenden. Forever hat keine Einstellgebühr mehr,
-- bleibt nur für alte Aufrufe erhalten (gibt die Gebühr unverändert zurück).
function A:ApplyMinFee(deposit)
    return deposit
end

-- erwartete Einstellgebühr, die verloren geht (pro Verkauf), Dauer 24 Std.
--   Forever: 0 - es gibt keine Einstellgebühr, die AH-Gebühr steckt in SaleFee/NetSale
--   sonst:   nur bei Rücklauf verloren -> Gebühr x (1 - Verkaufsquote) / Verkaufsquote
function A:ExpectedDepositLoss(itemID, qty)
    if self:IsForever() then
        return 0
    end
    local Se = self.Seller
    if not (Se and Se.Deposit) then return 0 end
    local ok, dep = pcall(Se.Deposit, Se, itemID, 2, qty or 1, true, nil)
    if not ok or not dep or dep <= 0 then return 0 end
    local p = 0.5
    local r = self.Comfort and self.Comfort.SellChance and self.Comfort:SellChance(itemID)
    if r and r.rate then p = math.max(0.1, math.min(1, r.rate / 100)) end
    return math.floor(dep * (1 - p) / p + 0.5)
end

-- Liste ohne unglaubwürdige Gewinne (Felder price und ref)
function A:WithoutAbsurd(list, keepUnsure)
    local out = {}
    for _, d in ipairs(list or {}) do
        if not self:IsAbsurdProfit(d.price, d.ref) and not self:IsOddPrice(d.ref)
            and (keepUnsure or d.vendorDeal or d.deDeal or not d.itemID or self:IsReliable(d.itemID)) then
            table.insert(out, d)
        end
    end
    return out
end

-- Items, die im Auktionshaus gerade billiger sind als beim Händler.
-- Nur aktuelle Preise (letzte 2 Std.), damit keine alten Angebote auftauchen.
function A:FindVendorDeals()
    local out = {}
    if not self.db then return out end
    local fresh = time() - self.FRESH_SECONDS
    for itemID in pairs(self.db.marketData) do
        self:Pause()
        local price, qty, t = self:GetCurrent(itemID)
        if price and t and t >= fresh then
            local vendor = self:GetVendorPrice(itemID)
            if vendor and vendor > price then
                table.insert(out, {
                    itemID = itemID, name = self:GetItemName(itemID),
                    price = price, vendor = vendor, quantity = qty or 0,
                    profit = vendor - price, pct = (vendor - price) / vendor * 100,
                })
            end
        end
    end
    return out
end

-- "Heute tun": Angebote UNTER dem Händlerverkaufspreis (kaufen und beim Händler verkaufen, kein AH-Anteil).
-- Quellen: letzter Scan, letzte Suche im Einkauf, aktuelle Angebote des gewählten Items (genau, je Angebot).
-- Nur Items mit Händlerpreis, nur frische Preise. Gewinn = (Händlerpreis - Kaufpreis) x Menge.
-- Ohne genaue Angebote ist nur der günstigste Preis bekannt: dann höchstens 10 Stück (wie bisher, vorsichtig).
A.VENDOR_FLIP_MIN = 1000      -- Standard-Mindestgewinn je Angebot: 10 Silber
function A:VendorFlipMin()
    local v = self.db and self.db.settings and self.db.settings.vendorFlipMin
    if v == nil then return self.VENDOR_FLIP_MIN end
    return v
end
function A:VendorFlipOffers(minProfit, max)
    minProfit = minProfit or self:VendorFlipMin()
    local cand = {}
    local fresh = time() - self.FRESH_SECONDS
    local function vendorOf(id)
        local v = self:GetVendorPrice(id)
        if type(v) == "number" and v > 0 then return v end
    end
    local function put(id, price, qty, source)
        local v = vendorOf(id)
        if not v or not price or price <= 0 or price >= v then cand[id] = nil; return end
        qty = math.max(1, math.min(qty or 1, 10))
        cand[id] = { itemID = id, price = price, vendor = v, qty = qty, profit = (v - price) * qty, source = source }
    end
    -- 1) letzter Scan
    if self.db and self.db.marketData then
        for itemID in pairs(self.db.marketData) do
            self:Pause()
            local price, qty, t = self:GetCurrent(itemID)
            if price and t and t >= fresh then put(itemID, price, qty, "scan") end
        end
    end
    -- 2) letzte Suche (neuer als der Scan)
    local B = self.Buy
    if B and B.results and (B.resultsTime or 0) >= fresh then
        for _, r in ipairs(B.results) do
            if r.itemID and r.price then put(r.itemID, r.price, r.qty, "suche") end
        end
    end
    -- 3) aktuelle Angebote eines Items: genau je Angebot (fremd, kein Lockangebot, Sofortkauf)
    local d = B and B.detail
    if d and d.itemID and d.listings and not d.loading and (d.time or 0) >= fresh then
        local v = vendorOf(d.itemID)
        local qty, profit, cheapest = 0, 0, nil
        if v then
            for _, l in ipairs(d.listings) do
                local free = math.max(0, (l.qty or 1) - (l.ownQty or 0))
                if l.own and not l.ownQty then free = 0 end
                if not l.bait and l.price and l.price > 0 and l.price < v and free > 0 then
                    qty = qty + free
                    profit = profit + (v - l.price) * free
                    cheapest = cheapest and math.min(cheapest, l.price) or l.price
                end
            end
        end
        if qty > 0 then
            cand[d.itemID] = { itemID = d.itemID, price = cheapest, vendor = v, qty = qty, profit = profit, source = "angebote" }
        else
            cand[d.itemID] = nil          -- veraltet: gerade gibt es nichts mehr unter dem Händlerpreis
        end
    end
    local out = {}
    for _, c in pairs(cand) do
        if c.profit >= minProfit and c.profit > 0 then
            c.name = self:GetItemName(c.itemID)
            table.insert(out, c)
        end
    end
    table.sort(out, function(a, b)
        if a.profit ~= b.profit then return a.profit > b.profit end
        return a.itemID < b.itemID
    end)
    for i = #out, (max or 10) + 1, -1 do out[i] = nil end
    return out
end

-- Alle Items als Liste mit Kennzahlen (für Tabellen)
function A:BuildItemList(filterText)
    local list = {}
    if not self.db then return list end
    local pq = self.Names and self.Names:PrepareQuery(filterText) or nil
    for itemID in pairs(self.db.marketData) do
        self:Pause()
        local name = self:GetItemName(itemID)
        if not pq or self.Names:Matches(itemID, pq) then
            local price, qty, t = self:GetCurrent(itemID)
            if price then
                table.insert(list, {
                    itemID = itemID,
                    name = name,
                    price = price,
                    quantity = qty or 0,
                    seen = t,
                    change = self:GetChangeSinceLastScan(itemID),
                    day = self:GetTrend(itemID, 86400),
                    week = self:GetTrend(itemID, 7 * 86400),
                    month = self:GetTrend(itemID, 30 * 86400),
                    points = #self:GetHistory(itemID),
                    market = self:GetMarketValue(itemID),
                    pct = self:GetMarketPercent(itemID, price),
                    vendor = self:GetVendorPrice(itemID),
                })
            end
        end
    end
    return list
end

-- ------------------------------------------------------------
-- Auktionshaus-Schnittstelle (abgesichert für Custom-Clients)
-- ------------------------------------------------------------
A.ahOpen = false

function A:IsAHOpen()
    -- Ereignisse (AUCTION_HOUSE_SHOW/CLOSED bzw. Öffnen/Schließen des Fensters) sind maßgeblich
    if self.ahOpen then return true end
    -- Rückfall, falls kein Ereignis kam: Auktionshaus-Fenster sichtbar
    -- (direkt nach dem Schließen ist es oft noch kurz sichtbar -> 1 Sek. ignorieren)
    local ah = (type(AuctionHouseFrame) == "table" and AuctionHouseFrame) or (type(AuctionFrame) == "table" and AuctionFrame)
    if ah and ah.IsShown and ah:IsShown() then
        return not self.ahClosedAt or (GetTime() - self.ahClosedAt) > 1
    end
    return false
end


function A:CheckAPI()
    local C = A.AH
    self.api = {
        C_AuctionHouse = C ~= nil,
        SendBrowseQuery = C ~= nil and C.SendBrowseQuery ~= nil,
        GetBrowseResults = C ~= nil and C.GetBrowseResults ~= nil,
        HasFullBrowseResults = C ~= nil and C.HasFullBrowseResults ~= nil,
        RequestMoreBrowseResults = C ~= nil and C.RequestMoreBrowseResults ~= nil,
        GetNumBrowseResults = C ~= nil and C.GetNumBrowseResults ~= nil,
    }
    return self.api
end

-- nur die Anzahl (billig) - die ganze Liste wird erst am Ende einmal abgeholt
local function SafeCountResults()
    if A.AH and A.AH.GetNumBrowseResults then
        local ok, n = pcall(A.AH.GetNumBrowseResults)
        if ok and type(n) == "number" then return n end
    end
    if not (A.AH and A.AH.GetBrowseResults) then return 0 end
    local ok, results = pcall(A.AH.GetBrowseResults)
    return (ok and type(results) == "table") and #results or 0
end

local function SafeGetResults()
    if not (A.AH and A.AH.GetBrowseResults) then return {} end
    local ok, results = pcall(A.AH.GetBrowseResults)
    if ok and type(results) == "table" then return results end
    return {}
end

local function SafeHasFull()
    if not (A.AH and A.AH.HasFullBrowseResults) then return nil end
    local ok, full = pcall(A.AH.HasFullBrowseResults)
    if ok then return full end
    return nil
end

local function SafeRequestMore()
    if not (A.AH and A.AH.RequestMoreBrowseResults) then return false end
    return (pcall(A.AH.RequestMoreBrowseResults))
end

-- ------------------------------------------------------------
-- Cooldown (15 Minuten, gespeichert mit time(), übersteht /reload und Neustart)
-- ------------------------------------------------------------
function A:GetCooldownRemaining()
    if not self.db then return 0 end
    local remaining = self.SCAN_COOLDOWN - (time() - (self.db.lastScanTime or 0))
    if remaining < 0 then remaining = 0 end
    return remaining
end

function A:IsScanReady()
    return self:GetCooldownRemaining() <= 0
end

-- ------------------------------------------------------------
-- Anfrage-Drossel des Servers: "bereit" für die nächste Anfrage?
-- (gibt es den Client-Aufruf nicht, gilt immer "bereit")
-- ------------------------------------------------------------
function A:QueryReady()
    local C = A.AH
    if C and C.IsThrottledMessageSystemReady then
        local ok, ready = pcall(C.IsThrottledMessageSystemReady)
        if ok then return ready and true or false end
    end
    return true
end

-- ------------------------------------------------------------
-- Gemeinsames Tempo für alle Suchen (Sniper, Wächter, Einkauf, Verkaufen):
-- immer an die Grenze, die der Server zulässt - und zwar selbst anpassend:
-- * Server meldet seine Drossel (modernes AH, Classic: CanSendAuctionQuery)
--   -> kein eigener Abstand, gesucht wird, sobald der Server "bereit" sagt
-- * sonst: Abstand wird nach jeder Antwort ein Stück kleiner (tastet sich an die
--   Grenze heran) und bei verworfenen Anfragen/Fehlern verdoppelt
-- So läuft es in jeder WoW-Version so schnell, wie der jeweilige Server es erlaubt.
-- ------------------------------------------------------------
local pace = { last = -100, errors = 0, answers = 0 }
A.pace = pace
A.GAP_MIN_THROTTLED = 0      -- Server sagt selbst, wann er bereit ist
A.GAP_MIN_FIXED = 0.2        -- ohne Drossel-Meldung: so knapp darf es höchstens werden
A.GAP_START_FIXED = 1.0      -- Startwert ohne Drossel-Meldung
A.GAP_MAX = 8                -- mehr Bremse gibt es nicht
A.GAP_SHRINK = 0.85          -- nach jeder Antwort: Abstand x 0,85
A.GAP_GROW = 2               -- nach einem Fehler: Abstand x 2

function A:HasThrottleAPI()
    return A.AH ~= nil and A.AH.IsThrottledMessageSystemReady ~= nil
end

local function MinGap()
    return A:HasThrottleAPI() and A.GAP_MIN_THROTTLED or A.GAP_MIN_FIXED
end

function A:QueryGap()
    if not pace.gap then pace.gap = self:HasThrottleAPI() and self.GAP_MIN_THROTTLED or self.GAP_START_FIXED end
    return pace.gap
end

function A:CanQueryNow()
    return GetTime() - pace.last >= self:QueryGap() and self:QueryReady()
end

function A:NoteQuery() pace.last = GetTime() end

-- Server hat eine Anfrage verworfen oder gemeckert: langsamer
function A:QueryError()
    pace.errors = pace.errors + 1
    local g = self:QueryGap()
    pace.gap = math.min(self.GAP_MAX, math.max(g * self.GAP_GROW, 0.3))
end

-- Antwort kam: wieder ein Stück schneller, bis zur Grenze
function A:QueryAnswered()
    pace.answers = pace.answers + 1
    local g = self:QueryGap() * self.GAP_SHRINK
    local min = MinGap()
    if g < min + 0.02 then g = min end
    pace.gap = g
end

function A:GetSpeedText()
    return string.format(L["Tempo: %s, Abstand %.2f Sek. (passt sich an), Antworten %d, Fehler %d"],
        self:HasThrottleAPI() and L["Server-Drossel"] or L["selbst ermittelt"], self:QueryGap(), pace.answers, pace.errors)
end

-- ------------------------------------------------------------
-- Vollständiger Markt-Scan
-- Seiten werden nachgeladen, sobald der Server "Ergebnisse da" meldet
-- (und die Drossel bereit ist) - ohne feste Wartezeiten. Zur Sicherheit
-- gibt es weiterhin den Rückfall "Anzahl ändert sich nicht mehr".
-- ------------------------------------------------------------
local scan = { running = false }
A.scanState = scan
A.SCAN_MAX_PAGES = 400

-- läuft der Scan noch (oder wird er gerade ausgewertet)?
function A:IsScanning()
    return scan.running or scan.processing or false
end

-- silent = true: Ablehnung durch den Server nicht im Chat melden (Neuversuch aus dem Scan-Wunsch, TryWantedScan)
function A:StartFullScan(silent)
    if not self.db then
        self:Print(L["Datenbank ist noch nicht bereit. Bitte kurz warten."])
        return false
    end
    if self:IsScanning() then
        self:Print(L["Es läuft bereits ein Scan."])
        return false
    end
    if not self:IsAHOpen() then
        self:Print(L["Bitte zuerst das Auktionshaus öffnen."])
        return false
    end
    if not (A.AH and A.AH.SendBrowseQuery) then
        self:Print(L["Dein Client unterstützt die Auktionshaus-Suche nicht (SendBrowseQuery fehlt)."])
        return false
    end
    if not self:IsScanReady() then
        self:Print(L["Scan noch gesperrt (Server-Limit). Wieder möglich in "] .. self:FormatDuration(self:GetCooldownRemaining()) .. L[" Min."])
        return false
    end
    -- Moderne API (WoW Forever, Retail): Ist der Server gerade mit anderen Anfragen ausgelastet oder läuft noch
    -- eine Wächter-Runde, wartet der Scan kurz und der Wächter pausiert - der Komplett-Scan hat Vorrang.
    if not A.AH_LEGACY and (not self:QueryReady() or (self.Watcher and self.Watcher.round)) then
        self:WantScan(nil, silent)
        return false
    end

    local ok, err = pcall(A.AH.SendBrowseQuery, {
        searchString = "",
        minLevel = 0,
        maxLevel = 0,
        filters = {},
        sorts = {},
    })
    if not ok then
        -- nur beim ersten Fehlschlag melden; Neuversuche (silent) bleiben still, sonst flutet ein bleibender Fehler den Chat
        if not silent or (self.scanWishRejects or 0) == 0 then self:Print(L["Scan konnte nicht gestartet werden: "] .. tostring(err)) end
        self.scanStartError = tostring(err)
        -- moderne API: abgelehnter Scan-Start -> Wächter pausieren und (begrenzt) nochmal versuchen
        if not A.AH_LEGACY then self:WantScan(true) end
        return false
    end

    self.scanWanted = nil
    self.scanWishRejects, self.scanWishNext, self.scanStartError = nil, nil, nil
    scan.running = true
    scan.startedAt = GetTime()
    scan.lastCount = -1
    scan.lastChange = GetTime()
    scan.pages = 0
    scan.waitingMore = false
    scan.dirty = false

    self.db.lastScanTime = time()
    self:Print(L["Scan gestartet ..."])
    self:Fire("SCAN_STARTED")

    scan.ticker = C_Timer.NewTicker(0.1, function()
        local okPoll, errPoll = pcall(A.PollScan, A)
        if not okPoll then
            A:Print(L["Fehler während des Scans: "] .. tostring(errPoll))
            A:FinishScan(false)
        end
    end)
    return true
end

-- Scan-Wunsch (nur moderne API): Der Wächter pausiert, bis der Scan gestartet ist; sobald der Server bereit
-- ist und keine Wächter-Runde mehr läuft, startet der Scan von selbst. Höchstens 2 Minuten, dann verworfen.
-- Lehnt der Server den Scan-Start ab (Fehler in SendBrowseQuery), gibt es höchstens SCAN_WISH_RETRIES Neuversuche
-- mit mindestens SCAN_WISH_RETRY_GAP Sek. Abstand; danach eine Meldung, der Wunsch wird verworfen, der Wächter läuft weiter.
A.SCAN_WISH_SECONDS = 120
A.SCAN_WISH_RETRIES = 3
A.SCAN_WISH_RETRY_GAP = 2
function A:WantScan(rejected, quiet)
    local W = self.Watcher
    if W and W.HoldForScan then W:HoldForScan(self.SCAN_WISH_SECONDS) end
    if rejected then
        self.scanWishRejects = (self.scanWishRejects or 0) + 1
        self.scanWishNext = GetTime() + self.SCAN_WISH_RETRY_GAP
    end
    if self.scanWanted then return end
    self.scanWanted = GetTime()
    if not rejected and not quiet then self:Print(L["Server ist gerade ausgelastet - der Scan startet gleich von selbst (Wächter pausiert)."]) end
    if self.scanWishTicker then self.scanWishTicker:Cancel() end
    self.scanWishTicker = C_Timer.NewTicker(0.5, function(t) A:TryWantedScan() end)
end

-- Scan-Wunsch verwerfen; released = true: auch die 2-Minuten-Pause des Wächters aufheben
function A:DropScanWish(released)
    self.scanWanted = nil
    self.scanWishRejects, self.scanWishNext = nil, nil
    if self.scanWishTicker then self.scanWishTicker:Cancel(); self.scanWishTicker = nil end
    if released and self.Watcher and self.Watcher.ReleaseScanHold then self.Watcher:ReleaseScanHold() end
end

function A:TryWantedScan()
    local function stop() self:DropScanWish(false) end
    if not self.scanWanted then return stop() end
    if GetTime() - self.scanWanted > self.SCAN_WISH_SECONDS or not self:IsAHOpen() or self:IsScanning() then return stop() end
    -- Server lehnt den Start dauerhaft ab: einmal melden, Wunsch verwerfen, Wächter wieder laufen lassen
    if (self.scanWishRejects or 0) > self.SCAN_WISH_RETRIES then
        self:Print(string.format(L["Der Scan konnte nach %d Versuchen nicht gestartet werden - bitte später erneut versuchen (/ahs scan)."],
            self.SCAN_WISH_RETRIES + 1))
        return self:DropScanWish(true)
    end
    if self.scanWishNext and GetTime() < self.scanWishNext then return end
    if not self:QueryReady() or (self.Watcher and self.Watcher.round) then return end
    local wanted = self.scanWanted
    self.scanWanted = nil                       -- StartFullScan darf bei Ablehnung neu wünschen
    if self:StartFullScan(true) then return stop() end
    if self.scanWanted then
        self.scanWanted = wanted                -- erneut abgelehnt: die Frist läuft weiter
    else
        stop()                                  -- aus anderem Grund nicht gestartet (Meldung kam schon)
    end
end

-- Server meldet neue Ergebnisse
A:On("QUERY_READY", function()
    if scan.running then pcall(A.PollScan, A) end
    if A.scanWanted and not scan.running then pcall(A.TryWantedScan, A) end
end)

function A:OnBrowseResults(added)
    if scan.running then
        scan.dirty = true
        if added then scan.waitingMore = false end
    end
end

function A:PollScan()
    if not scan.running then return end
    local now = GetTime()
    local count = SafeCountResults()          -- nur zählen: die ganze Liste abzuholen kostet viel
    local elapsed = now - scan.startedAt

    if count ~= scan.lastCount then
        scan.lastCount = count
        scan.lastChange = now
        scan.waitingMore = false
        self:Fire("SCAN_PROGRESS", count, elapsed)
    end
    local full = SafeHasFull()

    -- 1) Client meldet: alles geladen
    if full == true and count > 0 then
        self:FinishScan(true)
        return
    end

    -- 2) weitere Seite anfordern, sobald möglich
    if count > 0 and full == false and not scan.waitingMore and scan.pages < self.SCAN_MAX_PAGES and self:QueryReady() then
        if SafeRequestMore() then
            scan.pages = scan.pages + 1
            scan.waitingMore = true
            scan.requestedAt = now
            return
        end
    end

    -- 3) Rückfall: Anzahl ändert sich länger nicht mehr
    local still = now - scan.lastChange
    if count > 0 and still >= 2 then
        if scan.waitingMore and still < 4 then return end
        if full ~= false or scan.pages >= self.SCAN_MAX_PAGES or still >= 4 then
            self:FinishScan(true)
            return
        end
    end

    -- 4) Sicherheits-Timeout
    if elapsed > (A.AH_LEGACY and 900 or 120) then
        self:FinishScan(count > 0)
    end
end

function A:FinishScan(success)
    if not scan.running then return end
    scan.running = false
    if scan.ticker then
        scan.ticker:Cancel()
        scan.ticker = nil
    end

    if not success then
        self:Print(L["Scan ohne Ergebnis beendet."])
        self:ScreenMessage(L["Scan ohne Ergebnis beendet."], 1, 0.33, 0.27, false)
        self:Fire("SCAN_FAILED")
        return
    end

    -- Ergebnisse jetzt einmal abholen (danach darf das Auktionshaus auch zu sein),
    -- ausgewertet wird in Portionen über mehrere Frames - das Spiel ruckelt nicht
    local results = SafeGetResults()
    scan.processing = true
    scan.duration = GetTime() - scan.startedAt
    self:Job("scan", function() A:ProcessScan(results) end)
end

function A:ProcessScan(results)
    local now = time()
    local best = {}   -- pro Item den günstigsten Preis und die Gesamtmenge

    for i, r in ipairs(results) do
        local itemID = (type(r.itemKey) == "table" and r.itemKey.itemID) or r.itemID
        local price = r.minPrice or r.buyoutPrice
        if itemID and price and price > 0 then
            local qty = r.totalQuantity or r.quantity or 0
            local b = best[itemID]
            if not b then
                best[itemID] = { price = price, qty = qty }
            else
                if price < b.price then b.price = price end
                b.qty = b.qty + qty
            end
        end
        if i % 50 == 0 then self:Pause() end
    end

    -- verdächtig billige Waren (mögliche Lockangebote): unbestätigt speichern und nachprüfen
    local suspicious = {}
    local itemCount = 0
    for itemID, b in pairs(best) do
        if self:IsSuspicious(itemID, b.price) then
            b.u = true
            local mv = self:GetMarketValue(itemID)
            table.insert(suspicious, { itemID = itemID, ratio = b.price / mv })
        end
        self:RecordPrice(itemID, b.price, b.qty, now, false, b.u)
        itemCount = itemCount + 1
        self:Pause()
    end

    local duration = scan.duration or 0
    self.db.totalScans = (self.db.totalScans or 0) + 1
    table.insert(self.db.scanLog, { t = now, items = itemCount, entries = #results, duration = duration, pages = scan.pages })
    while #self.db.scanLog > 50 do table.remove(self.db.scanLog, 1) end

    -- eigenen Scan merken (für Mitspieler, die später online kommen)
    self.db.lastOwnScan = { t = now, data = best }
    scan.processing = false

    self:Print(string.format(L["Scan fertig: %d Einträge, %d verschiedene Items (%.1f Sek.)."], #results, itemCount, duration))
    self:ScreenMessage(string.format(L["AH-Scan fertig: %d Items"], itemCount), 0.2, 0.87, 0.33, true)
    -- Nachprüfung: die auffälligsten zuerst, höchstens 60
    if #suspicious > 0 and self.Seller then
        table.sort(suspicious, function(x, y) return x.ratio < y.ratio end)
        local n = math.min(#suspicious, 60)
        for k = 1, n do self.Seller:CheckPrice(suspicious[k].itemID) end
        self:Print(string.format(L["%d auffällig billige Waren werden nachgeprüft (Lockangebote zählen nicht)."], n))
    end
    local deals = self:FindVendorDeals()
    self.vendorDeals = deals
    if #deals > 0 then
        self:Print(string.format(L["|cff33dd55%d Items unter Händlerpreis|r - sicherer Gewinn, siehe Tab Profit"], #deals))
    end
    self:Fire("SCAN_FINISHED", itemCount, best, now)
    self:Fire("DATA_CHANGED")

    if self.Watchlist and self.Watchlist.CheckAlerts then
        self.Watchlist:CheckAlerts(true)
    end
end

function A:ResetScanState()
    if scan.ticker then scan.ticker:Cancel() end
    scan.ticker = nil
    scan.running = false
    scan.processing = false
    self:Print(L["Scan-Status zurückgesetzt."])
    self:Fire("SCAN_FAILED")
end

-- ------------------------------------------------------------
-- CSV-Export
-- ------------------------------------------------------------
function A:BuildCSV()
    local lines = { "ItemID;Name;Preis_Kupfer;Preis_Gold;Menge;Aenderung_Scan_%;Trend_24h_%;Trend_7T_%;Trend_30T_%;Zuletzt_gesehen;Marktwert_Kupfer;Prozent_vom_Marktwert;Haendlerpreis_Kupfer" }
    local list = self:BuildItemList()
    table.sort(list, function(a, b) return a.name < b.name end)
    local function pct(v) return v and string.format("%.2f", v) or "" end
    for _, it in ipairs(list) do
        table.insert(lines, string.format("%d;%s;%d;%.2f;%d;%s;%s;%s;%s;%s;%s;%s;%s",
            it.itemID, (it.name:gsub(";", ",")), it.price, it.price / 10000, it.quantity,
            pct(it.change), pct(it.day), pct(it.week), pct(it.month),
            it.seen and date("%Y-%m-%d %H:%M", it.seen) or "",
            it.market and tostring(it.market) or "", pct(it.pct), it.vendor and tostring(it.vendor) or ""))
    end
    return table.concat(lines, "\n"), #list
end

function A:ExportCSV()
    local text, count = self:BuildCSV()
    if count == 0 then
        self:Print(L["Noch keine Daten zum Exportieren. Erst einen Scan machen."])
        return
    end
    if self.UI and self.UI.ShowTextWindow then
        self.UI:ShowTextWindow(L["CSV-Export ("] .. count .. L[" Items)  -  Strg+A, Strg+C zum Kopieren"], text)
    else
        self:Print(L["Export-Fenster nicht verfügbar."])
    end
end

-- ------------------------------------------------------------
-- Diagnose
-- ------------------------------------------------------------
function A:PrintDebug()
    self:Print(L["Version "] .. self.version .. L["  |  Interface "] .. tostring(select(4, GetBuildInfo())))
    local G = _G.GoldSentinelGame
    if type(G) == "table" and G.Status then self:Print(G.Status()) end
    if not self.db then
        self:Print(L["Datenbank: NICHT geladen"])
        return
    end
    -- Fehler des Addons (GoldSentinelTest.lua): seit dem letzten Bericht gezählt, Berichte noch nicht gemeldet
    local GT = _G.GoldSentinelTest
    if GT and GT.Pending then
        local nErr = 0
        for _, e in pairs(self.db.gsTest and self.db.gsTest.errors or {}) do if type(e) == "table" then nErr = nErr + (e.count or 1) end end
        self:Print(string.format(L["Fehler seit Login: %d · Berichte offen: %d"], nErr, GT.Pending(self.db)))
    end
    self:Print(L["Items in Datenbank: "] .. self:CountTable(self.db.marketData) .. L["  |  Scans gesamt: "] .. (self.db.totalScans or 0))
    self:Print(L["Letzter Scan: "] .. self:FormatAgo(self.db.lastScanTime) .. L["  |  Nächster Scan: "] ..
        (self:IsScanReady() and L["jetzt möglich"] or (L["in "] .. self:FormatDuration(self:GetCooldownRemaining()))))
    self:Print(L["Auktionshaus offen: "] .. tostring(self:IsAHOpen()) .. L["  |  Scan läuft: "] .. tostring(scan.running))
    local api = self:CheckAPI()
    local parts = {}
    for _, key in ipairs({ "C_AuctionHouse", "SendBrowseQuery", "GetBrowseResults", "HasFullBrowseResults", "RequestMoreBrowseResults", "GetNumBrowseResults" }) do
        table.insert(parts, key .. "=" .. (api[key] and L["|cff33dd55ja|r"] or L["|cffff5544nein|r"]))
    end
    self:Print(L["API: "] .. table.concat(parts, ", ") .. (A.AH_LEGACY and L[" (klassisches Auktionshaus)"] or ""))
    -- Händler-Kosten in Währung (z. B. Merchant's Favor) - braucht GetMerchantItemCostInfo/-Item
    local costOK = (GetMerchantItemCostInfo and GetMerchantItemCostItem) and true or false
    self:Print(L["Händler-Kosten lesbar: "] .. (costOK and L["|cff33dd55ja|r"] or L["|cffff5544nein|r"]))
    if self.UI and self.UI.GetTabDebug then
        self:Print(L["Tabs: "] .. self.UI:GetTabDebug())
    end
    self:Print(L["Button vorhanden: "] .. tostring(self.FloatingButton ~= nil and self.FloatingButton:IsShown()))
    if self.Sync and self.Sync.GetDebugText then
        self:Print(L["Sync: "] .. self.Sync:GetDebugText())
    end
    if self.Names then
        self:Print(L["Namen: "] .. self.Names:GetDebugText())
    end
    if self.Tooltip then
        self:Print("Tooltip: " .. self.Tooltip:GetDebugText())
    end
    if self.Sniper and self.Sniper.GetDebugText then
        self:Print(L["Sniper: "] .. self.Sniper:GetDebugText())
    end
    if self.Seller and self.Seller.GetDebugText then
        self:Print(L["Verkaufen: "] .. self.Seller:GetDebugText())
    end
    if self.Ledger and self.Ledger.GetDebugText then
        self:Print(L["Buchhaltung: "] .. self.Ledger:GetDebugText())
    end
    if self.Buy and self.Buy.GetDebugText then
        self:Print(L["Einkauf: "] .. self.Buy:GetDebugText())
    end
    if self.Watcher and self.Watcher.GetDebugText then
        self:Print(L["Wächter: "] .. self.Watcher:GetDebugText())
    end
    self:Print(self:GetSpeedText())
end

-- Auktionshaus geöffnet/geschlossen (aus Ereignis oder vom Fenster selbst)
function A:SetAHOpenState(open)
    open = open and true or false
    if self.ahOpen == open then return end
    self.ahOpen = open
    if open then
        -- Preise gehören zum Auktionshaus dieses Servers und dieser Fraktion (neutral: eigenes)
        pcall(self.ActivateMarket, self, self:MarketKey(true))
    else
        self.ahClosedAt = GetTime()
        if scan.running then
            self:FinishScan(SafeCountResults() > 0)
        end
        pcall(self.ActivateMarket, self, self:MarketKey(false))
    end
    self:Fire("AH_STATE")
end

-- ------------------------------------------------------------
-- Preise je Server und Fraktion/Auktionshaus (Anweisung "Werte stimmen" Punkt 1, 9. Nov.)
--   A.db.markets[Schlüssel] = { data = marketData, own = lastOwnScan, recv = lastScanTimeReceived, mixed }
--   Schlüssel = "Server|Horde" / "Server|Alliance" / "Server|Neutral" (neutrales AH: Beutebucht, Gadgetzan, Ewige Warte)
-- A.db.marketData / lastOwnScan zeigen auf den aktiven Teil; beim Ausloggen wandern sie zurück (keine doppelten
-- Tabellen in den SavedVariables).
-- ------------------------------------------------------------
A.NEUTRAL_MAPS = { [1446] = true, [1434] = true, [1452] = true }   -- Tanaris, Schlingendorntal, Winterquell (Classic-Karten)
-- über A:API (die Testroutine ersetzt nie Blizzard-Funktionen)
-- Ist das Addon Disenchantry geladen? (dann zeigt AHSentinel keinen zweiten Materialblock)
function A:DisenchantryLoaded()
    if self.apiOverride and self.apiOverride.DisenchantryLoaded ~= nil then return self.apiOverride.DisenchantryLoaded end
    local CA = _G.C_AddOns
    local f = (CA and CA.IsAddOnLoaded) or _G.IsAddOnLoaded
    if not f then return false end
    local ok, loaded = pcall(f, "Disenchantry")
    return ok and loaded and true or false
end

function A:PlayerFaction()
    local ufg = self:API("UnitFactionGroup")
    local f = ufg and ufg("player")
    if f == "Horde" or f == "Alliance" then return f end
    return nil
end
-- atAH = true: beim Öffnen des Auktionshauses (neutraler Auktionator -> "Neutral")
function A:MarketKey(atAH)
    local grn = self:API("GetRealmName")
    local realm = (grn and grn()) or "?"
    local f = self:PlayerFaction() or "?"
    if atAH then
        local ufg = self:API("UnitFactionGroup")
        local npc = ufg and ufg("npc")
        local CM = self:API("C_Map")
        local map = CM and CM.GetBestMapForUnit and CM.GetBestMapForUnit("player")
        if npc == "Neutral" or (npc == nil and map and self.NEUTRAL_MAPS[map]) then f = "Neutral" end
    end
    return realm .. "|" .. f
end
-- kurze Kennung für Sync-Nachrichten (nur Zahlen/Buchstaben, keine Namen)
function A:MarketTag(key)
    local s = tostring(key or self.marketKey or self:MarketKey(false)):lower()
    local h = 5381
    for i = 1, #s do h = (h * 33 + s:byte(i)) % 4294967296 end
    return self.Sync and self.Sync.Enc and self.Sync.Enc(h) or tostring(h)
end

function A:StoreMarket()
    local db, k = self.db, self.marketKey
    if not (db and k) then return end
    db.markets = db.markets or {}
    local m = db.markets[k] or {}
    m.data, m.own = db.marketData or {}, db.lastOwnScan
    m.recv = db.sync and db.sync.lastScanTimeReceived or nil
    db.markets[k] = m
end

function A:ActivateMarket(key)
    local db = self.db
    if not (db and key) then return false end
    db.markets = db.markets or {}
    -- erste Verwendung (bis 0.65.29 gab es nur EINE Preisliste): bestehende Daten prüfen und zuordnen
    if not db.marketsMigrated then
        db.marketsMigrated = true
        if type(db.marketData) == "table" and next(db.marketData) ~= nil then
            local seen, n = {}, 0
            for _, c in pairs(db.chars or {}) do
                if type(c) == "table" and c.realm and c.faction then
                    local ck = c.realm .. "|" .. c.faction
                    if not seen[ck] then seen[ck] = true; n = n + 1 end
                end
            end
            local m = { data = db.marketData, own = db.lastOwnScan, recv = db.sync and db.sync.lastScanTimeReceived }
            -- Charaktere auf mehreren Servern/Fraktionen: die alten Preise können gemischt sein
            if n > 1 then m.mixed = true; self.marketsMixed = true end
            db.markets[key] = m
            self.marketKey = key
            return true
        end
    end
    if self.marketKey == key then return true end
    self:StoreMarket()
    local m = db.markets[key]
    if not m then m = { data = {} }; db.markets[key] = m end
    db.marketData = m.data or {}
    m.data = db.marketData
    db.lastOwnScan = m.own
    if db.sync then db.sync.lastScanTimeReceived = m.recv end
    self.marketKey = key
    if self.ClearPriceCaches then self:ClearPriceCaches() end
    self:Fire("DATA_CHANGED")
    return true
end

-- beim Ausloggen: aktiven Teil zurücklegen, damit die Preise nicht doppelt gespeichert werden
function A:ParkMarket()
    local db = self.db
    if not (db and self.marketKey) then return end
    self:StoreMarket()
    -- leere Tabelle statt nil: andere Module dürfen beim Ausloggen noch lesen
    db.marketData, db.lastOwnScan = {}, nil
    self.marketKey = nil
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
local eventFrame = CreateFrame("Frame")
A.eventFrame = eventFrame      -- für die Testroutine

local function SafeRegister(event)
    return A:RegisterAHEvent(eventFrame, event)
end

SafeRegister("ADDON_LOADED")
SafeRegister("PLAYER_LOGIN")
SafeRegister("AUCTION_HOUSE_SHOW")
SafeRegister("AUCTION_HOUSE_CLOSED")
SafeRegister("MERCHANT_SHOW")
SafeRegister("AUCTION_HOUSE_BROWSE_RESULTS_UPDATED")
SafeRegister("AUCTION_HOUSE_BROWSE_RESULTS_ADDED")
SafeRegister("MERCHANT_UPDATE")
SafeRegister("COMMODITY_SEARCH_RESULTS_UPDATED")
SafeRegister("ITEM_SEARCH_RESULTS_UPDATED")
SafeRegister("AUCTION_HOUSE_THROTTLED_SYSTEM_READY")
SafeRegister("AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED")
SafeRegister("AUCTION_HOUSE_SHOW_ERROR")
SafeRegister("PLAYER_LOGOUT")

eventFrame:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" and arg1 == A.ADDON_NAME then
        A:InitDB()
        A:CheckAPI()
    elseif event == "PLAYER_LOGIN" then
        if not A.db then A:InitDB() end
        pcall(A.ActivateMarket, A, A:MarketKey(false))
        if A.marketsMixed then
            A:Print(L["Hinweis: Deine bisherigen Preise stammen evtl. von mehreren Servern oder Fraktionen. Ab jetzt trennt AHSentinel die Preise je Server und Fraktion; der nächste Scan ersetzt sie."])
        end
        A:Fire("READY")
        A:Print(L["Version "] .. A.version .. L[" geladen. Öffnen über den Münz-Button oder /ahs"] .. "  |cffaaaaaa(" .. L["/ahs help = alle Befehle"] .. ")|r")
        if A.migratedFromOld then
            A:Print(L["|cff33dd55AH Analyzer Pro heißt jetzt AHSentinel.|r Alle deine Daten wurden übernommen. Den Ordner 'AHAnalyzerPro' im AddOns-Ordner brauchst du nicht mehr und kannst ihn löschen."])
        elseif type(AHAnalyzerProDB) == "table" and AHAnalyzerProDB.migratedTo then
            -- Übergangs-Ordner noch da: kurz erinnern (einmal pro Sitzung)
            A:Print(L["Hinweis: Den alten Ordner 'AHAnalyzerPro' im AddOns-Ordner kannst du löschen - deine Daten sind in AHSentinel."])
        end
    elseif event == "PLAYER_LOGOUT" then
        pcall(A.ParkMarket, A)
    elseif event == "AUCTION_HOUSE_SHOW" then
        A:SetAHOpenState(true)
    elseif event == "AUCTION_HOUSE_CLOSED" then
        A:SetAHOpenState(false)
    elseif event == "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED" or event == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED" then
        A:QueryAnswered()
        A:OnBrowseResults(event == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED")
        A:Fire("BROWSE_RESULTS", event == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED")
    elseif event == "COMMODITY_SEARCH_RESULTS_UPDATED" or event == "ITEM_SEARCH_RESULTS_UPDATED" then
        A:QueryAnswered()
        A:Fire("SEARCH_RESULTS", arg1)
    elseif event == "AUCTION_HOUSE_THROTTLED_SYSTEM_READY" then
        A:Fire("QUERY_READY")
    elseif event == "AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED" then
        A.lastThrottleDrop = GetTime()
        A:QueryError()
        if A.Watcher and A.Watcher.OnThrottleDrop then pcall(A.Watcher.OnThrottleDrop, A.Watcher) end
    elseif event == "AUCTION_HOUSE_SHOW_ERROR" then
        -- nur als Bremse werten, wenn gerade eine Suche lief
        if GetTime() - pace.last < 3 then A:QueryError() end
    elseif event == "MERCHANT_SHOW" or event == "MERCHANT_UPDATE" then
        -- kurz warten, bis der Händler seine Liste geladen hat
        C_Timer.After(0.3, function() pcall(A.ScanMerchant, A) end)
    end
end)

-- ------------------------------------------------------------
-- Chat-Befehle (alles ist auch per Maus bedienbar)
-- ------------------------------------------------------------
-- Befehlsliste für den Chat (/ahs help): Befehl auf Deutsch / Englisch, Beschreibung
A.COMMANDS = {
    { "", "", "Fenster öffnen / schließen" },
    { "scan", "scan", "Komplett-Scan des Marktes starten" },
    { "sniper", "sniper", "Sniper-Modus an / aus" },
    { "listen", "lists", "Einkaufslisten" },
    { "optionen", "options", "Optionen" },
    { "bilanz", "summary", "Tagesbilanz im Chat" },
    { "twinks", "alts", "Regeln für die Post an Twinks" },
    { "ziel 5000", "goal 5000", "Gold-Ziel setzen (ohne Zahl: Stand, 'aus': löschen)" },
    { "raid", "raid", "Raid-Vorrat als Einkaufsliste" },
    { "minikarte", "minimap", "Knopf an der Minikarte an / aus" },
    { "testroutine", "testroutine", "Testroutine (alle Prüfungen, Bericht an die Prüfung)" },
    { "test", "test", "Selbsttest aller Funktionen (Auktionshaus offen)" },
    { "test daten", "test saved", "Selbsttest mit gespeicherten Daten (ohne Scan)" },
    { "heute", "today", "Heute tun: was jetzt am meisten Gold bringt" },
    { "entzaubern", "disenchant", "Entzauber-Fenster: ein Klick = ein Teil entzaubern" },
    { "testmodus", "testmode", "Testmodus an / aus (alles ausprobieren, Handel nur simuliert)" },
    { "sync", "sync", "Preise mit Mitspielern teilen an / aus" },
    { "design", "design", "Design wechseln (Klassisch / Modern)" },
    { "sprache", "language", "Sprache des Addons wechseln" },
    { "export", "export", "Alle Preise als CSV (zum Kopieren)" },
    { "spenden", "donate", "Addon unterstützen (PayPal-Link)" },
    { "reset", "reset", "Fenster- und Knopf-Positionen zurücksetzen" },
    { "handbuch", "manual", "Hilfe-Fenster mit Anleitung" },
    { "debug", "debug", "Diagnose (für Fehlermeldungen)" },
    { "protokoll", "log", "Diagnose-Protokoll (zum Kopieren, geht automatisch an die Prüfung)" },
    { "spieltest an", "playtest on", "Spieltest: prüft die Checkliste im Spiel selbst (an / aus / bericht)" },
    { "hilfe", "help", "Diese Liste" },
}

function A:PrintCommands()
    local german = (self.uiLang or (GetLocale and GetLocale())) == "deDE"
    self:Print("|cffffd100" .. L["Befehle"] .. "|r  (" .. L["auch /ahanalyzer"] .. ")")
    local dev = self:IsDev()
    for _, c in ipairs(self.COMMANDS) do
        if c[1]:find("^test") and not dev then
            -- Testbefehle nur für den Entwickler
        else
        local word = german and c[1] or c[2]
        local cmd = (word == "") and "/ahs" or ("/ahs " .. word)
        print(string.format("   |cff33dd55%s|r  -  %s", cmd, L[c[3]]))
        end
    end
end

SLASH_AHANALYZERPRO1 = "/ahs"
SLASH_AHANALYZERPRO2 = "/ahsentinel"
SLASH_AHANALYZERPRO3 = "/ahp"            -- alter Name (AH Analyzer Pro) geht weiter
SLASH_AHANALYZERPRO4 = "/ahanalyzer"
SlashCmdList["AHANALYZERPRO"] = function(msg)
    msg = string.lower(msg or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if msg == "" or msg == "show" then
        if A.UI then A.UI:Toggle() end
    elseif msg == "scan" then
        A:StartFullScan()
    elseif msg == "export" then
        A:ExportCSV()
    elseif msg == "protokoll" or msg == "log" or msg == "diag" or msg == "protocol" then
        if A.Diag then A.Diag:Show() end
    elseif msg:match("^spieltest") or msg:match("^playtest") then
        if A.Spieltest then A.Spieltest:Command(msg:match("^%a+%s*(.*)$")) end
    elseif msg == "debug" then
        A:PrintDebug()
    elseif msg == "reset" then
        if A.ResetButtonPosition then A:ResetButtonPosition() end
        if A.UI then A.UI:ResetPosition() end
    elseif msg == "resetscan" then
        A:ResetScanState()
    elseif msg == "sync" then
        if A.Sync then A.Sync:Toggle() end
    elseif msg == "ahdebug" then
        if A.UI then A.UI:PrintAHDebug() end
    elseif msg == "ah" then
        if A.UI then A.UI:ForceAH() end
    elseif msg == "sniper" then
        if A.Sniper then A.Sniper:ToggleArmed() end
    elseif msg == "design" then
        if A.UI then A.UI:ToggleTheme() end
    elseif msg == "optionen" or msg == "options" then
        if A.UI then A.UI:ShowOptions() end
    elseif msg == "donate" or msg == "spenden" or msg == "support" then
        if A.UI then A.UI:ShowDonate() end
    elseif msg == "bilanz" or msg == "summary" or msg == "daily" then
        if A.Extras then A.Extras:ShowDailySummary(true) end
    elseif msg == "ziel" or msg == "goal" or msg:match("^ziel%s") or msg:match("^goal%s") then
        if A.Comfort then A.Comfort:GoalCommand(msg:match("^%a+%s+(.*)$")) end
    elseif msg == "entzaubern" or msg == "disenchant" or msg == "de" then
        if A.DEWindow then A.DEWindow:Toggle() end
    elseif msg == "heute" or msg == "today" then
        if A.UI and A.UI.ShowToday then A.UI:ShowToday() end
    elseif (msg == "testmodus" or msg == "testmode" or msg:match("^test") or msg == "selbsttest" or msg == "selftest")
        and not A:RequireDev() then
        -- Testfunktionen nur für den Entwickler (Hinweis kommt von GoldSentinelDev)
    elseif msg == "testmodus" or msg == "testmode" then
        if A.TestMode then A.TestMode:Toggle(); if A.SelfTest then A.SelfTest:ShowWindow() end end
    elseif msg == "testroutine" or msg:match("^testroutine%s") then
        -- Testroutine (GoldSentinelTest): /ahs testroutine [a-j|server|haendler|berufe|post|gildenbank|kampf]
        if A.TestRoutine then A.TestRoutine:Start(msg:match("^testroutine%s+(%S+)")) end
    elseif msg == "test daten" or msg == "test saved" or msg == "test gespeichert" then
        -- Kurzform: Testroutine ohne Auktionshaus (gespeicherte Daten)
        if A.TestRoutine then A.TestRoutine:Start("auto") end
    elseif msg == "test" or msg == "selbsttest" or msg == "selftest" then
        -- Kurzform: Testroutine-Teil "server" (Auktionshaus offen)
        if A.TestRoutine then
            if A:IsAHOpen() then A.TestRoutine:Start("server") else
                if A.SelfTest then A.SelfTest:ShowWindow() end
                A:Print(L["Für den Selbsttest erst das Auktionshaus öffnen (oder /ahs test daten für gespeicherte Daten)."])
            end
        end
    elseif msg == "minimap" or msg == "minikarte" or msg == "knopf" then
        A:ToggleMinimapButton()
    elseif msg == "raid" then
        if A.Comfort then
            local ok, m, name = A.Comfort:CreateRaidList()
            A:Print(m)
            if ok and A.UI and A.UI.ShowLists then A.UI:ShowLists(name) end
        end
    elseif msg == "twinks" or msg == "alts" or msg == "mailrules" then
        if A.UI and A.UI.ShowMailRules then A.UI:ShowMailRules() end
    elseif msg == "sprache" or msg == "language" or msg == "lang" then
        A:CycleUILanguage(1)
        A:Print(L["Sprache des Addons: %s"]:format(A:UILanguageLabel()))
    elseif msg == "listen" or msg == "lists" then
        if A.UI then A.UI:ToggleLists() end
    elseif msg == "hilfe" or msg == "help" or msg == "?" or msg == "befehle" or msg == "commands" then
        A:PrintCommands()
    elseif msg == "handbuch" or msg == "manual" or msg == "anleitung" then
        if A.UI then A.UI:ShowHelp("start") end
    else
        A:Print(string.format(L["Unbekannter Befehl: %s"], msg))
        A:PrintCommands()
    end
end
