if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Testroutine (ab 0.65.6)
-- Prüft das Addon "auf Herz und Nieren" nach auftraege/AHSentinel/testroutine-ahsentinel.txt und schreibt den
-- Bericht über GoldSentinelTest.lua in AHSentinelDB.gsTest (der RaidMasterUploader meldet ihn an die Prüfung).
--   /ahs testroutine            alles, was ohne Spieler-Handlung geht (Auktionshaus darf zu sein)
--   /ahs testroutine a ... j    nur ein Bereich
--   /ahs testroutine server     Auktionshaus offen: Scan, Suchen, simulierter Handel (bisheriger Selbsttest)
--   /ahs testroutine haendler | berufe | post | gildenbank | kampf   halbautomatische Teile
--   Kurzform: /ahs test = testroutine server, /ahs test daten = testroutine
-- Nur für den Entwickler (GoldSentinelDev). Sicher:
--   * echte Daten (AHSentinelDB) werden vorher gesichert, nachher verglichen und wiederhergestellt
--   * Kaufen, Bieten, Einstellen, Abbrechen, Post, Händler-Verkauf und Preis-Sync sind nur simuliert (A:Simulated)
--   * keine Blizzard-Funktion wird ersetzt: Simulationen laufen über eigene Nahtstellen
--     (A.apiOverride / A:API, A.testCombat / A:InCombat, A.AH-Proxy, Test-Briefkasten A.Inbox)
--   * im Kampf startet sie nicht; beginnt ein Kampf, bricht sie ab und stellt alles zurück
-- Testfall-IDs bleiben über alle Versionen gleich (T01 ... T152, neue ab T153).
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local ST, TM = A.SelfTest, A.TestMode

local TR = { running = false, rows = {}, log = {} }
A.TestRoutine = TR

local FAKE = 990000001                 -- Test-Item-IDs ab hier (SelfTest FAKE_ID0 + 1)
local LINEN = 2589                     -- Leinenstoff
local SLICE_MS = 40                    -- Retail: "script ran too long" vermeiden
local clock = debugprofilestop

local function G() return _G.GoldSentinelGame end
local function GTest() return _G.GoldSentinelTest end
local function Ms() return clock and clock() or (GetTime() * 1000) end

-- ------------------------------------------------------------
-- Hilfen
-- ------------------------------------------------------------
local function Copy(v)
    if type(v) ~= "table" then return v end
    local c = {}
    for k, x in pairs(v) do c[k] = Copy(x) end
    return c
end

local function Replace(target, source)
    if type(target) ~= "table" or type(source) ~= "table" then return end
    for k in pairs(target) do target[k] = nil end
    for k, v in pairs(source) do target[k] = v end
end

-- A.Print für die Dauer von fn abfangen; liefert die Zeilen (ohne Farbcodes)
local function Capture(fn, ...)
    local lines = {}
    local real = A.Print
    A.Print = function(_, msg) table.insert(lines, A:PlainText(tostring(msg))) end
    local res = { pcall(fn, ...) }
    A.Print = real
    if not res[1] then error(res[2], 0) end
    return lines, unpack(res, 2)
end
TR.Capture = Capture

-- Testwert, der wie ein geschützter Wert ("secret value") bei Vergleich, Verketten, Index und Länge einen Fehler wirft
local function Boom() error("geschützter Testwert benutzt", 2) end
local SECRET = setmetatable({}, { __index = Boom, __newindex = Boom, __concat = Boom, __lt = Boom, __le = Boom,
    __len = Boom, __call = Boom, __unm = Boom, __add = Boom, __sub = Boom, __mul = Boom, __div = Boom,
    __tostring = function() return "<geschützt>" end })
TR.SECRET = SECRET

-- fn mit simuliertem geschützten Wert ausführen: GoldSentinelGame.IsSecret (Addon-Tabelle, kein Blizzard-Global)
-- erkennt SECRET nur für die Dauer dieses einen synchronen Aufrufs.
local function WithSecret(fn, ...)
    local g = G()
    if not (g and g.IsSecret) then return pcall(fn, ...) end
    local real = g.IsSecret
    g.IsSecret = function(v) if v == SECRET then return true end return real(v) end
    local res = { pcall(fn, ...) }
    g.IsSecret = real
    return unpack(res)
end

local function Count(t) return A:CountTable(t) end

-- Prüfsumme grosser, nur gelesener Tabellen (statt einer Kopie)
local function Checksum(t)
    local n, h, newest = 0, 0, 0
    for id, e in pairs(t or {}) do
        n = n + 1
        if type(e) == "table" and type(e.history) == "table" then
            h = h + #e.history
            local last = e.history[#e.history]
            if type(last) == "table" and type(last.t) == "number" and last.t > newest then newest = last.t end
        end
    end
    return { n = n, h = h, newest = newest }
end

local function HasFakeIDs(t)
    for id in pairs(t or {}) do if type(id) == "number" and id >= 990000000 then return id end end
    return nil
end

-- ------------------------------------------------------------
-- Sandbox: echte Daten sichern, vergleichen, wiederherstellen
-- ------------------------------------------------------------
local NO_COPY = { marketData = true, names = true, gsTest = true, testRoutine = true }
-- Änderungen aus echten Spiel-Ereignissen (während der Routine läuft das Spiel weiter)
local ALLOWED = { "gsTest", "testRoutine", "marketData", "names", "namesSent", "vendorPrices", "selftest",
    "sync.received", "sync.peers", "sync.lastReceived", "sync.lastScanTimeReceived", "sync.namesReceived" }
local ALLOWED_PART = {
    server = { "lastScanTime", "totalScans", "scanLog", "lastOwnScan" },
    haendler = { "vendorBuy", "vendorCost" },
}
-- beim ersten Lesen mit Standardwerten angelegt (normales Verhalten, keine Testdaten): nil -> Tabelle ist erlaubt
local LAZY = { ["watcher.binds"] = true, ["settings.lastSub"] = true, recipes = true, buyFavorites = true }
local function HasTestMarker(v)
    if type(v) == "string" then return v:find("AHS%-Test") ~= nil end
    if type(v) == "number" then return v >= 990000000 end
    if type(v) == "table" then
        for k, x in pairs(v) do if HasTestMarker(k) or HasTestMarker(x) then return true end end
    end
    return false
end
-- Schlüssel, die Namen tragen: im Bericht nur als Platzhalter
local NAME_KEYS = { chars = "<Charakter>", recipes = "<Charakter>", guildBank = "<Gilde>", deShared = "<Spieler>",
    peers = "<Spieler>" }

local function OwnCharKey()
    local Ch = A.Chars
    if Ch and Ch.Key then local ok, k = pcall(Ch.Key, Ch); if ok then return k end end
    return nil
end

local function PathText(segs)
    local out = {}
    for i, s in ipairs(segs) do
        local prev = segs[i - 1]
        if prev and NAME_KEYS[prev] then out[i] = NAME_KEYS[prev] else out[i] = tostring(s) end
    end
    return table.concat(out, ".")
end

function TR:IsAllowed(segs)
    local p = table.concat({ unpack(segs, 1, math.min(#segs, 2)) }, ".")
    local function match(list)
        for _, a in ipairs(list or {}) do
            if p == a or segs[1] == a then return true end
        end
        return false
    end
    if match(ALLOWED) or match(ALLOWED_PART[self.part]) then return true end
    -- eigener Charakter: Gold, Taschen, Bank kommen aus echten Spiel-Ereignissen
    if segs[1] == "chars" and segs[2] ~= nil and segs[2] == self.ownChar then return true end
    return false
end

local function Diff(a, b, segs, out, self)
    if #out >= 200 then return end
    if #segs > 0 and self:IsAllowed(segs) then return end
    if type(a) == "table" and type(b) == "table" then
        for k, v in pairs(a) do
            local s = { unpack(segs) }; s[#s + 1] = k
            Diff(v, b[k], s, out, self)
        end
        for k, v in pairs(b) do
            if a[k] == nil then
                local s = { unpack(segs) }; s[#s + 1] = k
                local lazy = LAZY[table.concat(s, ".")] and type(v) == "table" and not HasTestMarker(v)
                if not self:IsAllowed(s) and not lazy then table.insert(out, s) end
            end
        end
    elseif a ~= b then
        table.insert(out, { unpack(segs) })
    end
end

function TR:Backup()
    local db = A.db
    local b = { __missing = {} }
    for k, v in pairs(db) do
        if not NO_COPY[k] then b[k] = Copy(v) end
    end
    self.ownChar = OwnCharKey()
    self.sums = { market = Checksum(db.marketData), names = Count(db.names) }
    db.testRoutine = { backup = b, part = self.part, started = time() }
end

local function SetPath(root, segs, value)
    local t = root
    for i = 1, #segs - 1 do
        if type(t[segs[i]]) ~= "table" then t[segs[i]] = {} end
        t = t[segs[i]]
    end
    t[segs[#segs]] = value
end

local function GetPath(root, segs)
    local t = root
    for i = 1, #segs do
        if type(t) ~= "table" then return nil end
        t = t[segs[i]]
    end
    return t
end

-- vergleicht mit der Sicherung, schreibt Unterschiede zurück; liefert die Pfade (Text) der Unterschiede
function TR:CompareAndRestore()
    local db = A.db
    local tr = db and db.testRoutine
    local b = tr and tr.backup
    if not b then return { "Sicherung fehlt" } end
    local cur = {}
    for k, v in pairs(db) do if not NO_COPY[k] then cur[k] = v end end
    local diffs = {}
    Diff(b, cur, {}, diffs, self)
    local paths = {}
    for _, segs in ipairs(diffs) do
        if segs[1] ~= "__missing" then
            table.insert(paths, PathText(segs))
            local orig = GetPath(b, segs)
            if #segs == 1 and type(db[segs[1]]) == "table" and type(orig) == "table" then
                Replace(db[segs[1]], Copy(orig))     -- Tabellen nicht tauschen: Module halten Verweise
            else
                SetPath(db, segs, Copy(orig))
            end
        end
    end
    -- Testdaten dürfen auch in den erlaubten Teilen nicht landen
    local fake = HasFakeIDs(db.marketData)
    if fake then table.insert(paths, "marketData.<Test-ID>"); db.marketData[fake] = nil end
    return paths
end

-- nach /reload oder Absturz mitten in der Routine: Sicherung zurückschreiben
function TR:RecoverAfterReload()
    local db = A.db
    local tr = db and db.testRoutine
    if not (tr and tr.backup) then return false end
    self.part = tr.part
    self.ownChar = OwnCharKey()
    for k, v in pairs(tr.backup) do
        if k ~= "__missing" and not NO_COPY[k] then
            if type(db[k]) == "table" and type(v) == "table" then Replace(db[k], v) else db[k] = v end
        end
    end
    for k in pairs(db) do
        if not NO_COPY[k] and tr.backup[k] == nil then db[k] = nil end
    end
    local fake = HasFakeIDs(db.marketData)
    while fake do db.marketData[fake] = nil; fake = HasFakeIDs(db.marketData) end
    db.testRoutine = nil
    return true
end

A:On("READY", function()
    if A.db and A.db.testRoutine then
        local ok = pcall(TR.RecoverAfterReload, TR)
        if ok then A:Print(L["Testroutine vom letzten Mal abgebrochen - deine echten Daten sind wiederhergestellt."]) end
    end
end)

-- ------------------------------------------------------------
-- Laufzeit-Zustand (nicht in den SavedVariables)
-- ------------------------------------------------------------
function TR:SaveRuntime()
    local Sn, W, B, Se, Td, S = A.Sniper, A.Watcher, A.Buy, A.Seller, A.Today, A.Sync
    self.rt = {
        forceForever = A.forceForever, print = A.Print,
        snInstantFailed = Sn and Sn.instantFailed, snPending = Sn and Sn.pending, snExtra = Sn and Sn.extra,
        hold = W and W.holdForScan, opps = W and Copy(W.opps),
        bDetail = B and B.detail, sePendingPost = Se and Se.pendingPost,
        todayState = Td and Copy(Td.state), todayExtra = Td and Copy(Td.extra),
        syncChannel = S and S.channelId, syncQueue = S and S.queue and #S.queue or 0,
        syncStatus = S and S.status, heard = S and S.heardScanTime,
        aahLegacy = A.AH_LEGACY,
    }
end

function TR:RestoreRuntime()
    local r = self.rt
    if not r then return {} end
    self.rt = nil
    local problems = {}
    local function part(name, fn)
        local ok, err = pcall(fn)
        if not ok then table.insert(problems, name .. ": " .. tostring(err)) end
    end
    part("Flags", function()
        A.forceForever = r.forceForever
        A.apiOverride, A.testCombat = nil, nil
        A.AH_LEGACY = r.aahLegacy
        if A.Extras then A.Extras.testMyName = nil end
        local g = G()
        if g and g.SetTestFlavor then g.SetTestFlavor(nil) end
        A.Print = r.print
    end)
    part("Sniper", function()
        local Sn = A.Sniper
        if not Sn then return end
        Sn.instantFailed, Sn.pending, Sn.extra = r.snInstantFailed, r.snPending, r.snExtra
        Sn.result = nil
    end)
    part("Wächter", function()
        local W = A.Watcher
        if not W then return end
        W.holdForScan = r.hold
        if type(W.opps) == "table" and type(r.opps) == "table" then Replace(W.opps, r.opps) end
    end)
    part("Einkauf/Verkaufen", function()
        if A.Buy then A.Buy.detail = r.bDetail end
        if A.Seller then A.Seller.pendingPost = r.sePendingPost end
    end)
    part("Heute tun", function()
        local Td = A.Today
        if not Td then return end
        if type(r.todayState) == "table" then Replace(Td.state, r.todayState) end
        if type(r.todayExtra) == "table" then Replace(Td.extra, r.todayExtra) end
    end)
    part("Sync", function()
        local S = A.Sync
        if not S then return end
        S.channelId, S.status, S.heardScanTime = r.syncChannel, r.syncStatus, r.heard
        if S.queue and #S.queue > r.syncQueue then for i = #S.queue, r.syncQueue + 1, -1 do table.remove(S.queue, i) end end
    end)
    part("Scan-Wunsch", function() if A.DropScanWish and A.scanWanted then A:DropScanWish(false) end end)
    return problems
end

-- ------------------------------------------------------------
-- Nachweis "nichts wirklich ausgeführt": Zähler über hooksecurefunc (taint-frei, nur während der Routine)
-- ------------------------------------------------------------
TR.real = {}
local function Hook(tbl, name, label, cond)
    if not hooksecurefunc then return end
    local target = tbl and tbl[name] or (not tbl and _G[name])
    if type(target) ~= "function" then return end
    local ok = pcall(function()
        local fn = function(...)
            if not TR.running then return end
            if cond and not cond(...) then return end
            TR.real[label] = (TR.real[label] or 0) + 1
        end
        if tbl then hooksecurefunc(tbl, name, fn) else hooksecurefunc(name, fn) end
    end)
    return ok
end
local function MerchantOpen() return MerchantFrame and MerchantFrame.IsShown and MerchantFrame:IsShown() end
local function SyncPrefix(prefix) return prefix == "AHAP1" end
function TR:InstallCounters()
    if self.countersInstalled then return end
    self.countersInstalled = true
    Hook(nil, "SendMail", "SendMail")
    Hook(nil, "TakeInboxMoney", "TakeInboxMoney")
    Hook(nil, "TakeInboxItem", "TakeInboxItem")
    Hook(nil, "JoinTemporaryChannel", "JoinTemporaryChannel")
    Hook(nil, "LeaveChannelByName", "LeaveChannelByName")
    Hook(nil, "SetOverrideBindingClick", "SetOverrideBindingClick")
    if C_Container then Hook(C_Container, "UseContainerItem", "UseContainerItem", MerchantOpen)
    else Hook(nil, "UseContainerItem", "UseContainerItem", MerchantOpen) end
    if C_ChatInfo and C_ChatInfo.SendAddonMessage then Hook(C_ChatInfo, "SendAddonMessage", "SendAddonMessage", SyncPrefix)
    else Hook(nil, "SendAddonMessage", "SendAddonMessage", SyncPrefix) end
end

-- ------------------------------------------------------------
-- Ergebnisse (alle über GoldSentinelTest: T:Check / T:Skip / T:Client)
-- ------------------------------------------------------------
function TR:Row(status, id, area, name, detail)
    table.insert(self.rows, { group = tostring(area) .. " " .. tostring(id), name = name, status = status,
        detail = detail and A:PlainText(tostring(detail)) or "" })
    if ST and ST.window and ST.window:IsShown() then ST.window:Refresh() end
end

local function LastDetail(T, id)
    local e = T.results[#T.results]
    if not (e and e.id == id) then return "" end
    if e.lua then return "Lua: " .. e.lua end
    local d = e.ergebnis and ("ist: " .. e.ergebnis) or ""
    if e.erwartet then d = d .. " | soll: " .. e.erwartet end
    return d
end

function TR:Check(id, area, name, fn)
    local ok = self.T:Check(id, area, name, fn)
    self:Row(ok and "PASS" or "FAIL", id, area, name, LastDetail(self.T, id))
    return ok
end
function TR:Skip(id, area, name, reason)
    self.T:Skip(id, area, name, reason)
    self:Row("SKIP", id, area, name, reason)
end
function TR:Client(id, area, name, how)
    self.T:Client(id, area, name, how)
    self:Row("CLIENT", id, area, name, how)
end

-- Absichtlich erzeugte Fehler-Einträge wieder aus db.gsTest.errors entfernen (keine echten Fehler)
function TR:ClearTestErrors()
    local s = A.db and A.db.gsTest and A.db.gsTest.errors
    if type(s) ~= "table" then return end
    for k, e in pairs(s) do
        if type(k) == "string" and (k:find("AHS%-Test") or k:find("geschützter Testwert")) then s[k] = nil end
    end
end
local function ErrorEntry(where)
    local s = A.db and A.db.gsTest and A.db.gsTest.errors
    for k, e in pairs(s or {}) do
        if type(e) == "table" and e.wo == where and tostring(e.msg):find("AHS%-Test") then return e end
    end
    return nil
end

-- ------------------------------------------------------------
-- Ablauf
-- ------------------------------------------------------------
TR.PARTS = { auto = true, a = true, b = true, c = true, d = true, e = true, f = true, g = true, h = true, i = true, j = true,
    server = true, haendler = true, berufe = true, post = true, gildenbank = true, kampf = true }

function TR:Step(fn) table.insert(self.steps, fn) end

function TR:Start(part)
    if not A:RequireDev() then return false end
    part = (part == nil or part == "") and "auto" or tostring(part):lower()
    part = ({ ["händler"] = "haendler", haendler = "haendler", merchant = "haendler", professions = "berufe",
        mail = "post", guildbank = "gildenbank", combat = "kampf" })[part] or part
    if not self.PARTS[part] then
        A:Print(string.format(L["Unbekannter Teil der Testroutine: %s (a-j, server, haendler, berufe, post, gildenbank, kampf)"], part))
        return false
    end
    if self.running or (ST and ST.running) then A:Print(L["Selbsttest läuft schon ..."]); return false end
    if TM and TM.active then A:Print(L["Erst den Testmodus beenden."]); return false end
    if not A.db then return false end
    if A:InCombat() then A:Print(L["Im Kampf kann die Testroutine nicht starten."]); return false end
    local GT = GTest()
    if not (GT and GT.Begin) then A:Print(L["GoldSentinelTest.lua fehlt - Testroutine nicht möglich."]); return false end

    self.part = part
    self.rows = {}
    self.real = {}
    self.T = GT.Begin("AHSentinel", A.version, A.db)
    self.memBefore = collectgarbage("count")
    self.money0 = GetMoney and GetMoney() or 0
    self:InstallCounters()
    self:Backup()
    self:SaveRuntime()
    ST:SaveState()
    -- Schutz für die GANZE Routine: Handels-Proxy, Sperren der Kauf-Knöpfe, Test-Briefkasten, A:Simulated()
    ST:Lock()
    TM:InstallInbox()
    self.running = true
    self.wasArmed = A.Sniper and A.Sniper:IsArmed()
    if self.wasArmed then A.Sniper:SetArmed(false) end
    if A.Watcher and A.Watcher:IsEnabled() then A.Watcher:SetEnabled(false) end

    self.steps, self.pos, self.wait = {}, 0, nil
    self:BuildSteps(part)
    ST.results = self.rows
    if ST.ShowWindow then ST:ShowWindow() end
    A:Print(string.format(L["Testroutine gestartet (%s) - Kaufen, Einstellen, Post, Händler und Preis-Sync sind solange nur simuliert."], part))
    self:Next()
    return true
end

function TR:Next()
    local t0 = Ms()
    while self.running do
        if Ms() - t0 > SLICE_MS then
            C_Timer.After(0, function() if TR.running and not TR.wait then TR:Next() end end)
            return
        end
        self.pos = self.pos + 1
        local s = self.steps[self.pos]
        if not s then return self:Finish() end
        local ok, status, waitFn, timeout, checkFn = pcall(s, self)
        if not ok then
            self:Check("T000", "-", "Ablauf der Routine", function() error(status, 0) end)
        elseif status == "WAIT" then
            self.wait = { fn = waitFn, untilT = GetTime() + (timeout or 30), check = checkFn }
            return
        end
    end
end

function TR:Poll()
    local w = self.wait
    if not w then return end
    local okW, done = pcall(w.fn)
    if (okW and done) or not okW or GetTime() > w.untilT then
        self.wait = nil
        local timedOut = not (okW and done)
        local ok, err = pcall(w.check, timedOut, not okW and done or nil)
        if not ok then self:Check("T000", "-", "Ablauf der Routine (Warten)", function() error(err, 0) end) end
        return self:Next()
    end
end

-- Kampf begonnen: abbrechen, alles zurück
function TR:Abort(reason)
    if not self.running then return end
    self.wait = nil
    if reason == "Kampf begonnen" then self:Skip("T95", "C", "Routine und Kampf", reason)
    else self:Skip("T000", "-", "Abbruch", reason) end
    self.steps = {}
    self:Finish(true)
end

function TR:Finish(aborted)
    if not self.running then return end
    self.wait = nil
    local T = self.T
    -- Nachweis "nichts wirklich ausgeführt" (2.5)
    if not aborted then
        self:Check("T157", "I", "Nichts wirklich ausgeführt (Gold, Post, Händler, Sync, Kanal)", function()
            local parts, bad = {}, 0
            for k, n in pairs(self.real) do
                if k ~= "SetOverrideBindingClick" then parts[#parts + 1] = k .. "=" .. n; bad = bad + n end
            end
            local m = GetMoney and GetMoney() or 0
            if m < self.money0 then parts[#parts + 1] = "Gold weniger"; bad = bad + 1 end
            return bad == 0, string.format("%d Befehle nur protokolliert, echte Aktionen: %s", ST.tradeLog and #ST.tradeLog or 0,
                #parts > 0 and table.concat(parts, ", ") or "0"), "0"
        end)
    end
    self.running = false
    -- Schutz und Zustand zurück
    local problems = {}
    local function part(name, fn)
        local ok, err = pcall(fn)
        if not ok then table.insert(problems, name .. ": " .. tostring(err)) end
    end
    part("Schutz", function() ST:Unlock() end)
    part("Briefkasten", function() TM:RemoveInbox(); wipe(TM.fakeMail); wipe(TM.fakeOwned); TM.mailMoney = 0 end)
    for _, p in ipairs(self:RestoreRuntime()) do table.insert(problems, p) end
    part("Zustand", function() ST:RestoreState() end)
    part("Sniper", function() if self.wasArmed and A.Sniper and not A.Sniper:IsArmed() then A.Sniper:SetArmed(true) end end)
    self:ClearTestErrors()
    local paths = self:CompareAndRestore()
    local again = #paths > 0 and self:CompareAndRestore() or {}
    if A.db then A.db.testRoutine = nil end
    if #problems > 0 then A:ReportError("Test:Wiederherstellen", table.concat(problems, "; ")) end
    local sandbox = "OK"
    if #paths > 0 then
        sandbox = string.format("FEHLER: %d Pfade, wiederhergestellt%s: %s", #paths, #again > 0 and " (nicht vollständig)" or "",
            table.concat(paths, ", ", 1, math.min(#paths, 12)))
    end
    collectgarbage("collect")
    local memKB = math.floor(collectgarbage("count") - (self.memBefore or 0))
    local text = T:Finish({ sandbox = sandbox, teil = self.part, speicher_kb = tostring(memKB) })
    text = text .. "\n" .. string.format("Sprache: %s · Addon-Sprache: %s · Auktionshaus: %s",
        tostring(GetLocale and GetLocale()), tostring(A.uiLang), A.AH_LEGACY and "klassisch" or "modern")
    if #problems > 0 then text = text .. "\nWiederherstellen: " .. table.concat(problems, "; ") end
    self.lastText = text
    local c = T.counts
    self.lastSummary = string.format(L["Testroutine fertig: %d OK, %d FEHLER, %d übersprungen, %d im Client prüfen."],
        c.ok, c.fehler, c.uebersprungen, c.client)
    A:Print((c.fehler == 0 and "|cff33dd55" or "|cffff5544") .. self.lastSummary .. "|r")
    A:Print(L["Bericht gespeichert – wird beim nächsten /reload oder Ausloggen an die Prüfung gemeldet."])
    A:Print(L["Bitte jetzt /reload."])
    if A.UI and A.UI.ShowTextWindow then pcall(A.UI.ShowTextWindow, A.UI, L["Testbericht"], text) end
    if ST.window then ST.window:Refresh() end
end

function TR:ReportText()
    return self.lastText or L["Noch kein Selbsttest gelaufen."]
end

local frame = CreateFrame("Frame")
TR.frame = frame
pcall(frame.RegisterEvent, frame, "PLAYER_REGEN_DISABLED")
frame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_REGEN_DISABLED" and TR.running then
        TR:Abort("Kampf begonnen")
        A:Print(L["Testroutine abgebrochen: Kampf begonnen. Deine Daten sind wiederhergestellt."])
    end
end)
local acc = 0
frame:SetScript("OnUpdate", function(_, dt)
    if not TR.running then return end
    acc = acc + (dt or 0)
    if acc < 0.25 then return end
    acc = 0
    TR:Poll()
end)

-- ============================================================
-- Testfälle
-- ============================================================
local function want(part, area)
    return part == "auto" or part == area
end

-- bisherige Selbsttest-Schritte über GoldSentinelTest laufen lassen (Adapter, testroutine 2.2)
local OLD_IDS = {
    ["Grundlagen/Einstellgebühr WoW Forever"] = { "T16", "B" },
    ["Scan/Markt-Scan"] = { "T20", "B" }, ["Scan/Marktdaten plausibel"] = { "T21", "B" },
    ["Oberfläche/Preisverlauf-Fenster"] = { "T26a", "B" }, ["Oberfläche/Optionen, Hilfe, Einkaufslisten"] = { "T26b", "B" },
    ["Oberfläche/Sprachwechsel (alle Sprachen, mehrfach)"] = { "T112", "F" },
    ["Auswertungen/Suche nach Namen"] = { "T15", "B" }, ["Auswertungen/Verkaufbarkeit"] = { "T14", "B" },
    ["Auswertungen/Heute tun"] = { "T72", "B" }, ["Auswertungen/Tooltip"] = { "T73", "B" },
    ["Auswertungen/Vermögen"] = { "T60", "B" },
    ["Server/Einkauf: Kategorie-Suche"] = { "T32", "B" }, ["Server/Einkauf: Angebote eines Items"] = { "T33", "B" },
    ["Server/Verkaufen: Preisprüfung"] = { "T48", "B" }, ["Server/Sniper: Suche (kauft nichts)"] = { "T40", "B" },
    ["Server/Wächter: eine Runde (kauft nichts)"] = { "T45", "B" }, ["Server/Eigene Auktionen"] = { "T51", "B" },
    ["Handel (simuliert)/Sofortkauf"] = { "T35", "B" }, ["Handel (simuliert)/Gebot"] = { "T36", "B" },
    ["Handel (simuliert)/Sniper-Kauf"] = { "T41", "B" }, ["Handel (simuliert)/Einstellen"] = { "T49", "B" },
    ["Handel (simuliert)/Abbrechen"] = { "T51b", "B" },
}
local TAB_LETTERS = "abcdefghijklmnop"

function TR:AddOldSteps(savedMode)
    ST.savedMode = savedMode
    local old = ST:Steps()
    local tabN = 0
    for idx, s in ipairs(old) do
        local key = s.group .. "/" .. s.name
        local map = OLD_IDS[key]
        local id, area
        if map then id, area = map[1], map[2]
        elseif s.group == "Oberfläche" and s.name:find("^Reiter") then
            tabN = tabN + 1
            id, area = "T25" .. TAB_LETTERS:sub(tabN, tabN), "B"
        else
            id, area = string.format("S%02d", idx), "B"
        end
        local name = s.group .. ": " .. s.name
        if s.name ~= "Übersetzungen" then        -- konnte nie fehlschlagen, ersetzt durch T113
            local function adapt(status, detail, expect)
                if status == "SKIP" then return self:Skip(id, area, name, detail or "") end
                return self:Check(id, area, name, function()
                    return status ~= "FAIL", detail ~= "" and detail or nil, status == "FAIL" and "bestanden" or nil
                end)
            end
            self:Step(function()
                if ST.ctx and ST.ctx.abort then return self:Skip(id, area, name, "früherer Schritt hat den alten Selbsttest beendet") end
                local ok, status, detail, waitFn, timeout, checkFn = pcall(s.run)
                if not ok then return self:Check(id, area, name, function() error(status, 0) end) end
                if status == "WAIT" then
                    return "WAIT", waitFn, timeout, function(timedOut, werr)
                        if timedOut then
                            return self:Check(id, area, name, function()
                                return false, werr and tostring(werr) or "keine Antwort", "Antwort in " .. tostring(timeout) .. " s"
                            end)
                        end
                        local ok2, st2, d2 = pcall(checkFn)
                        if not ok2 then return self:Check(id, area, name, function() error(st2, 0) end) end
                        return adapt(st2 or "PASS", d2)
                    end
                end
                return adapt(status or "PASS", detail)
            end)
        end
    end
end

function TR:BuildSteps(part)
    local B = function(fn) self:Step(fn) end
    local Chk = function(...) return self:Check(...) end
    local Skp = function(...) return self:Skip(...) end
    local Cli = function(...) return self:Client(...) end
    local g = G()
    local modern = not A.AH_LEGACY

    -- ---------------- A. Laden und Erkennung ----------------
    if want(part, "a") then B(function()
        Chk("T01", "A", "alle Module geladen", function()
            local miss = {}
            for _, k in ipairs({ "Sniper", "Watcher", "Buy", "Seller", "Ledger", "Lists", "Watchlist", "Crafting", "Disenchant",
                "Chars", "Mailer", "Extras", "Comfort", "Today", "Sync", "Names", "Tooltip", "UI", "SelfTest", "TestMode",
                "Inbox", "AH", "TestRoutine" }) do
                if A[k] == nil then miss[#miss + 1] = k end
            end
            for _, l in ipairs({ "frFR", "esES", "esMX", "ptBR", "itIT", "ruRU", "koKR", "zhCN", "zhTW", "enUS" }) do
                if type(A.T[l]) ~= "table" then miss[#miss + 1] = "Locale " .. l end
            end
            if A.Names and A.Names.HasBuiltin then
                for _, l in ipairs({ "enUS", "deDE", "frFR", "esES", "esMX", "ptBR", "ruRU", "koKR", "zhCN", "zhTW" }) do
                    if not A.Names:HasBuiltin(l) then miss[#miss + 1] = "Names " .. l end
                end
            end
            return #miss == 0, #miss == 0 and "alle da" or table.concat(miss, ", "), "keine fehlen"
        end)
        Chk("T02", "A", "Version .toc = Code", function()
            local get = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
            local v = get and get("AHSentinel", "Version")
            return v == A.version, tostring(v), A.version
        end)
        Chk("T03", "A", "Addon nicht veraltet", function()
            local info = (C_AddOns and C_AddOns.GetAddOnInfo) or GetAddOnInfo
            local iface = GetBuildInfo and select(4, GetBuildInfo())
            if not info then return true, "GetAddOnInfo fehlt, Interface " .. tostring(iface) end
            local _, _, _, loadable, reason = info("AHSentinel")
            return reason ~= "INTERFACE_VERSION", "Interface " .. tostring(iface) .. ", Grund " .. tostring(reason), "kein INTERFACE_VERSION"
        end)
        Chk("T04", "A", "gemeinsame Dateien", function()
            local D, T = _G.GoldSentinelDev, GTest()
            local bad = {}
            if not (g and g.version and g.version >= 2 and g.apiVersion) then bad[#bad + 1] = "GoldSentinelGame" end
            if g and type(g.Status) == "function" and type(g.Status()) ~= "string" then bad[#bad + 1] = "Status" end
            if g and g.IsForever and not g.IsModern then bad[#bad + 1] = "Forever nicht modern" end
            if not (D and (D.version or 0) >= 1) then bad[#bad + 1] = "GoldSentinelDev" end
            if not (T and T.version >= 1 and T.registry and T.registry["AHSentinel"]) then bad[#bad + 1] = "GoldSentinelTest/TrackErrors" end
            return #bad == 0, #bad == 0 and (g and g.Status() or "") or table.concat(bad, ", "), "alles erfüllt"
        end)
        Chk("T05", "A", "Weichen je Client simuliert", function()
            if not (g and g.SetTestFlavor) then return false, "SetTestFlavor fehlt" end
            local prevForce, before = A.forceForever, A:IsForever()
            A.forceForever = nil
            local bad = {}
            local ok, err = pcall(function()
                for _, f in ipairs({ "forever", "era", "tbc", "retail" }) do
                    g.SetTestFlavor(f)
                    if A:IsForever() ~= (f == "forever") then bad[#bad + 1] = f .. ": IsForever" end
                    if A:DepositRefunded() ~= (f ~= "forever") then bad[#bad + 1] = f .. ": DepositRefunded" end
                    if A:ApplyMinFee(50, 2) ~= (f == "forever" and 200 or 50) then bad[#bad + 1] = f .. ": ApplyMinFee" end
                    if f == "forever" and A.Comfort:RaidSetKey() ~= "classic" then bad[#bad + 1] = "forever: RaidSetKey" end
                end
            end)
            g.SetTestFlavor(nil)
            A.forceForever = prevForce
            if not ok then error(err, 0) end
            if A:IsForever() ~= before then bad[#bad + 1] = "nach dem Test andere Erkennung" end
            if tostring(g.Status()):find("%[") then bad[#bad + 1] = "Status zeigt noch [Test]" end
            return #bad == 0, #bad == 0 and "RaidSetKey für era/tbc folgt WOW_PROJECT_ID" or table.concat(bad, "; "), "alles erfüllt"
        end)
        Chk("T06", "A", "Ladereihenfolge", function()
            local T = GTest()
            return T ~= nil and _G.GoldSentinelDev ~= nil and g ~= nil, nil, "Dev, Game, Test vor Locale.lua geladen"
        end)
        Chk("T07", "A", "AH-Weiche", function()
            local expectLegacy = (not (C_AuctionHouse and C_AuctionHouse.SendBrowseQuery)) and QueryAuctionItems ~= nil
            local realAH = ST.realAH or A.AH
            local ok = (A.AH_LEGACY and true or false) == (expectLegacy and true or false)
            if A.AH_LEGACY then ok = ok and realAH ~= C_AuctionHouse and realAH.SendBrowseQuery ~= nil
            else ok = ok and realAH == C_AuctionHouse end
            return ok, A.AH_LEGACY and "klassisch" or "modern", expectLegacy and "klassisch" or "modern"
        end)
        Chk("T08", "A", "Berufe-Weiche", function()
            local k = A.Crafting:TradeKind()
            local expect = GetNumTradeSkills and "trade" or "modern"
            return k == expect, k, expect
        end)
        if modern then Cli("T08", "A", "Berufe-Weiche (Forever)", "/dump GetNumTradeSkills – muss nil sein, sonst liest das Addon die alte Liste") end
        Chk("T09", "A", "Tooltip-Weg", function()
            local m = A.Tooltip and A.Tooltip.mode
            local expect = TooltipDataProcessor and "TooltipDataProcessor" or "OnTooltipSetItem"
            return type(m) == "string" and m:find(expect, 1, true) ~= nil, tostring(m), expect
        end)
        Chk("T10", "A", "Chat-Befehle registriert", function()
            local ok = SLASH_AHANALYZERPRO1 == "/ahs" and SLASH_AHANALYZERPRO2 == "/ahsentinel" and SLASH_AHANALYZERPRO3 == "/ahp"
                and SLASH_AHANALYZERPRO4 == "/ahanalyzer" and type(SlashCmdList.AHANALYZERPRO) == "function"
                and SlashCmdList.GOLDSENTINELGAME ~= nil
            return ok, nil, "/ahs, /ahsentinel, /ahp, /ahanalyzer, /gsgame"
        end)
    end) end

    -- ---------------- B. Jede Funktion (Auswahl ohne Spieler-Handlung) ----------------
    if want(part, "b") then
        -- bisheriger Selbsttest mit gespeicherten Daten (Server-Teile werden übersprungen)
        if part == "auto" or part == "b" then
            if Count(A.db.marketData) > 0 then self:AddOldSteps(true)
            else B(function() Skp("S00", "B", "bisheriger Selbsttest", "keine gespeicherten Marktdaten - erst einmal scannen") end) end
        end
        B(function()
        Chk("T11", "B", "Geld anzeigen und lesen", function()
            local bad = {}
            for _, x in ipairs({ 1, 99, 10000, 1234567 }) do
                if A:ParseGold(A:FormatMoneyInput(x)) ~= x then bad[#bad + 1] = tostring(x) end
            end
            local s = A:FormatMoney(123456)
            if not (s:find("12") and s:find("34") and s:find("56")) then bad[#bad + 1] = "FormatMoney" end
            if A:PlainText("|cffff0000a|r|Tx:0|tb") ~= "ab" then bad[#bad + 1] = "PlainText" end
            return #bad == 0, table.concat(bad, ", "), "alle Rundläufe gleich"
        end)
        Chk("T12", "B", "Ereignis-Bus", function()
            local got
            A:On("AHS_TEST", function() error("AHS-Test Zuhörer") end)
            A:On("AHS_TEST", function(v) got = v end)
            Capture(function() A:Fire("AHS_TEST", 1) end)
            A.listeners["AHS_TEST"] = nil
            self:ClearTestErrors()
            return got == 1, tostring(got), "1 (zweiter Zuhörer läuft trotz Fehler im ersten)"
        end)
        Chk("T13", "B", "Preis-Kern mit Testdaten", function()
            local id, now = FAKE, time()
            local ok, err = pcall(function()
                A:RecordPrice(id, 100, 1, now - 1000)
                A:RecordPrice(id, 200, 1, now - 500)
                A:RecordPrice(id, 300, 1, now)
            end)
            local cur, n, mv = A:GetCurrent(id), #A:GetHistory(id), A:GetMarketValue(id)
            A.db.marketData[id] = nil
            if A.InvalidateMarket then pcall(A.InvalidateMarket, A, id) end
            if not ok then error(err, 0) end
            local good = cur == 300 and n == 3 and mv and mv >= 100 and mv <= 300
            return good and A.db.marketData[id] == nil, string.format("aktuell %s, Einträge %d, Marktwert %s", tostring(cur), n, tostring(mv)),
                "300, 3, 100–300"
        end)
        Chk("T17", "B", "Händler-Verkaufspreis", function()
            local p = A:GetVendorPrice(LINEN)
            return p == nil or (type(p) == "number" and p >= 0), tostring(p), "Zahl >= 0"
        end)
        Chk("T18", "B", "Händler-Scan mit Testhändler (moderner und alter Weg)", function()
            local db = A.db
            local items = {
                { id = FAKE + 10, price = 100, stack = 5, avail = -1 },
                { id = FAKE + 11, price = 100, stack = 1, avail = 3 },
                { id = FAKE + 12, price = 0, stack = 1, avail = -1, ext = true },
            }
            local cmf = { GetNumItems = function() return #items end,
                GetItemInfo = function(i) local e = items[i]; return e and { price = e.price, stackCount = e.stack, numAvailable = e.avail, hasExtendedCost = e.ext } end }
            local common = {
                GetMerchantItemLink = function(i) return items[i] and ("item:" .. items[i].id) end,
                GetMerchantItemCostInfo = function(i) return items[i] and items[i].ext and 1 or 0 end,
                GetMerchantItemCostItem = function(i) return nil, 2, "currency:3001", "Testwährung" end,
            }
            local results = {}
            for _, way in ipairs({ "modern", "alt" }) do
                local o = {}
                for k, v in pairs(common) do o[k] = v end
                if way == "modern" then o.C_MerchantFrame = cmf; o.GetMerchantNumItems = false; o.GetMerchantItemInfo = false
                else
                    o.C_MerchantFrame = false
                    o.GetMerchantNumItems = function() return #items end
                    o.GetMerchantItemInfo = function(i) local e = items[i]; return "x", nil, e.price, e.stack, e.avail, true, nil, e.ext end
                end
                A.apiOverride = o
                local ok, n = pcall(A.ScanMerchant, A)
                A.apiOverride = nil
                local c = db.vendorCost and db.vendorCost[FAKE + 12]
                results[way] = string.format("%s/%s/%s/%s", tostring(ok and n), tostring(db.vendorBuy[FAKE + 10]),
                    tostring(db.vendorBuy[FAKE + 11]), c and c.costs and c.costs[1] and (c.costs[1].kind .. ":" .. tostring(c.costs[1].id) .. "x" .. tostring(c.costs[1].amount)) or "nil")
                for k = 10, 12 do db.vendorBuy[FAKE + k] = nil; if db.vendorCost then db.vendorCost[FAKE + k] = nil end end
            end
            local want = "2/20/nil/currency:3001x2"
            return results.modern == want and results.alt == want, "modern " .. results.modern .. ", alt " .. results.alt, want
        end)
        Chk("T22", "B", "15-Minuten-Sperre", function()
            local saved = A.db.lastScanTime
            A.db.lastScanTime = time() - 100
            local rem, ready = A:GetCooldownRemaining(), A:IsScanReady()
            A.db.lastScanTime = saved
            return A.SCAN_COOLDOWN == 900 and rem >= 799 and rem <= 800 and not ready, tostring(rem), "800, gesperrt"
        end)
        Chk("T23", "B", "Anfrage-Drossel", function()
            local p = A.pace
            local errs, gap = p.errors, p.gap
            local r = A:QueryReady()
            A:QueryError()
            local grew = p.errors == errs + 1
            p.errors, p.gap = errs, gap
            return type(r) == "boolean" and A:QueryGap() >= 0 and grew, nil, "boolean, Abstand >= 0, Fehlerzähler +1"
        end)
        Chk("T29", "B", "Minikarten-Winkel", function()
            local st = A.db.settings
            local before = st.minimapAngle
            if not A.SetMinimapAngle then return true, "kein Minikarten-Knopf" end
            A:SetMinimapAngle(90)
            local v = st.minimapAngle
            A:SetMinimapAngle(before or 225)
            st.minimapAngle = before
            return v == 90, tostring(v), "90"
        end)
        Chk("T38", "B", "Einkauf-Favoriten", function()
            local K = A.Comfort
            local favs = K.FavDB()
            if #favs >= K.MAX_FAVS - 1 then return true, "Favoriten fast voll - übersprungen" end
            local saved = Copy(favs)
            local ok1 = K:AddFavorite({ text = "AHS-Test" })
            local ok2 = K:AddFavorite({ text = "AHS-Test" })
            Replace(favs, saved)
            return ok1 and not ok2, string.format("erst %s, doppelt %s", tostring(ok1), tostring(ok2)), "erst true, doppelt false"
        end)
        Chk("T47", "B", "Verkaufen rechnen", function()
            local Se = A.Seller
            if not (Se and Se.Undercut) then return true, "Undercut fehlt" end
            local u = Se:Undercut(1000)
            return type(u) == "number" and u < 1000 and u > 0 and Se:Undercut(1) >= 1, tostring(u), "< 1000, Undercut(1) >= 1"
        end)
        Chk("T61", "B", "Einkaufslisten", function()
            local Li = A.Lists
            local name = "AHS-Test"
            local existed = Li:Exists(name)
            if existed then return true, "Liste AHS-Test gab es schon - übersprungen" end
            Li:Create(name)
            Li:AddItem(name, tostring(LINEN), 5)
            local n = Li:Count(name)
            Li:Delete(name)
            return n == 1 and not Li:Exists(name), tostring(n), "1, danach weg"
        end)
        Chk("T68", "B", "Gold-Ziel", function()
            local K = A.Comfort
            local before = K:GoldGoal()
            Capture(function() K:GoalCommand("5000") end)
            local v = K:GoldGoal()
            Capture(function() K:GoalCommand("aus") end)
            local off = K:GoldGoal()
            K:SetGoldGoal(before)
            return v == 50000000 and off == nil, tostring(v) .. " / " .. tostring(off), "50000000 / nil"
        end)
        Chk("T70", "B", "Raid-Vorrat", function()
            local K, Li = A.Comfort, A.Lists
            local name = L["Raid-Vorrat"]
            local existed = Li:Exists(name)
            local key = K:RaidSetKey()
            if not key then
                local ok, msg = K:CreateRaidList(1)
                return ok == false, "keine Vorlage für diesen Client", "Meldung statt Liste"
            end
            local ok = K:CreateRaidList(1)
            local n = Li:Count(name)
            if not existed then Li:Delete(name) end
            return ok and n == #K.RAID_SETS[key], tostring(n), tostring(#K.RAID_SETS[key])
        end)
        Chk("T74", "B", "Item-Namen und Suche", function()
            local N = A.Names
            local de = N:Get(LINEN, "deDE")
            return de == "Leinenstoff" and N:ParseID("item:" .. LINEN) == LINEN and N:Resolve(tostring(LINEN)) == LINEN,
                tostring(de), "Leinenstoff, 2589"
        end)
        Chk("T75", "B", "Sync-Empfang (Testnachricht)", function()
            local S = A.Sync
            local sdb = A.db.sync
            if not (S and S.OnMessage and sdb) then return true, "Sync fehlt" end
            local saved = Copy(sdb)
            local heard = S.heardScanTime or 0
            sdb.enabled = true
            local ok, err = pcall(function()
                S:OnMessage("AHAP1", "H:" .. S.Enc(heard + 1), S:GuildOnly() and "GUILD" or "CHANNEL", "AHS-Testpeer-Realm")
            end)
            local after = S.heardScanTime or 0
            Replace(sdb, saved)
            S.heardScanTime = heard
            if not ok then error(err, 0) end
            return after == heard + 1, "heardScanTime +" .. tostring(after - heard), "+1, Daten danach wie vorher"
        end)
        Chk("T76", "B", "Sync senden nur simuliert, Kodierung", function()
            local S = A.Sync
            local bad = {}
            for _, n in ipairs({ 0, 1, 35, 36, 123456789 }) do
                if S.Dec(S.Enc(n)) ~= n then bad[#bad + 1] = tostring(n) end
            end
            return #bad == 0 and A:Simulated(), #bad == 0 and "Rundlauf ok, A:Simulated() = true" or table.concat(bad, ", "), "alle gleich"
        end)
        Chk("T78", "B", "Testmodus während der Routine abgelehnt", function()
            local lines, ok = Capture(function() return TM:Start() end)
            return ok == false and not TM.active, tostring(ok), "false"
        end)
        Chk("T79", "B", "Diagnose", function()
            local lines = Capture(function() A:PrintDebug() end)
            local all = table.concat(lines, "\n")
            local need = (g and g.Status and A:PlainText(g.Status())) or ""
            local errLine = A:PlainText(L["Fehler seit Login: %d · Berichte offen: %d"]):match("^[^%%]+") or "?"
            local good = all:find(A.version, 1, true) ~= nil and all:find(need, 1, true) ~= nil and all:find(errLine, 1, true) ~= nil
            return good, string.format("%d Zeilen", #lines), "Version, Spielversion, Fehlerzeile"
        end)
        end)
    end

    -- ---------------- B. Oberfläche, Optionen, Befehle, Rechnen (0.65.7) ----------------
    if want(part, "b") then
        local UI = A.UI
        local function Shown(f) return f and f.IsShown and f:IsShown() or false end
        local function Click(b, button)
            if not b then error("Knopf fehlt", 0) end
            local f = b:GetScript("OnClick")
            if not f then error("Knopf ohne OnClick", 0) end
            return f(b, button or "LeftButton")
        end
        local function Opt() UI:ShowOptions(); return UI.options end
        local function Eff(v) return v ~= false end          -- nil = Standard "an"
        local function HideAll()
            for _, k in ipairs({ "options", "helpWindow", "textWindow", "donateWindow", "listsWindow", "todayWin",
                "mailRulesWindow", "chartWin" }) do
                if UI[k] then UI[k]:Hide() end
            end
            if UI.HideMenu then UI:HideMenu() end
        end
        B(function()
        Chk("T24", "B", "Hauptfenster und Designs", function()
            local theme = A.db.settings.theme
            UI:Show(); local v1 = UI:IsVisible()
            UI:Hide(); local v2 = UI:IsVisible()
            UI:Toggle(); local v3 = UI:IsVisible()
            UI:SetTheme("modern"); UI:SetTheme("classic"); UI:SetTheme(theme or "classic")
            return v1 and not v2 and v3 and A.db.settings.theme == theme,
                string.format("%s/%s/%s, Design %s", tostring(v1), tostring(not v2), tostring(v3), tostring(A.db.settings.theme)),
                "zeigen/verstecken/umschalten, Design wie vorher"
        end)
        local extra = {
            { "T26c", "Hilfe (jede Seite)", function()
                local help = (A.uiLang == "deDE" and UI.HELP_DE) or A.HELP[A.uiLang] or UI.HELP_EN
                local n = 0
                for id in pairs(help or {}) do UI:ShowHelp(id); n = n + 1 end
                return Shown(UI.helpWindow) and n > 0, n .. " Seiten"
            end },
            { "T26d", "Einkaufslisten", function() UI:ShowLists(); local s = Shown(UI.listsWindow); UI:ToggleLists(); return s end },
            { "T26e", "Heute tun", function() UI:ShowToday(); return Shown(UI.todayWin) end },
            { "T26f", "Post-Regeln", function() UI:ShowMailRules(); return Shown(UI.mailRulesWindow) end },
            { "T26g", "Unterstützen", function() UI:ShowDonate(); return Shown(UI.donateWindow) end },
            { "T26h", "Textfenster", function() UI:ShowTextWindow("Test", "Test"); return Shown(UI.textWindow) end },
            { "T26i", "Item-Menü", function()
                local inList = A.Watchlist:Contains(LINEN)
                Capture(function()
                    for _, act in ipairs({ "chart", "watch", "watch", "sniper", "list" }) do
                        UI:ShowItemMenu(LINEN, UIParent); UI:OnMenuClick(act)
                    end
                    if A:IsAHOpen() then UI:ShowItemMenu(LINEN, UIParent); UI:OnMenuClick("ah") end
                end)
                return A.Watchlist:Contains(LINEN) == inList, "Watchlist danach wie vorher"
            end },
        }
        for _, w in ipairs(extra) do
            Chk(w[1], "B", "Zusatzfenster " .. w[2], function()
                local ok, detail = w[3]()
                HideAll()
                return ok and true or false, detail or (ok and "öffnet und schließt" or "nicht offen"), "öffnet und schließt"
            end)
        end
        Chk("T28", "B", "Größe, Zoom, Position", function()
            local st = A.db.settings
            local saved = { scale = st.scale, windowPos = Copy(st.windowPos), buttonPos = Copy(st.buttonPos), ahZoom = st.ahZoom,
                windowSize = Copy(st.windowSize), minimapAngle = st.minimapAngle, minimapHide = st.minimapHide }
            UI:SetScale((st.scale or 1) + 0.05); UI:SetScale((saved.scale or 1))
            if UI.SetAHZoom and UI.AHZoom then UI:SetAHZoom(UI:AHZoom()) end
            if UI.ResetWindowSize then UI:ResetWindowSize() end
            UI:ResetPosition()
            if A.ResetButtonPosition then Capture(A.ResetButtonPosition, A) end
            for k, v in pairs(saved) do st[k] = v end
            if A.SetMinimapButtonShown then A:SetMinimapButtonShown(not st.minimapHide) end
            if st.minimapAngle then A:SetMinimapAngle(st.minimapAngle) end
            return true, "ohne Fehler, Werte zurück"
        end)
        end)

        -- T30.xx: jede Option einmal an und aus (wie ein Klick im Optionsfenster)
        local OPTIONS = {
            { "01", "Design", function()
                local theme = A.db.settings.theme
                Click(Opt().modernBtn); local m = A.db.settings.theme
                Click(Opt().classicBtn); local c = A.db.settings.theme
                UI:SetTheme(theme or "classic")
                return m == "modern" and c == "classic", m .. "/" .. c
            end },
            { "02", "Im AH anzeigen", "ahBtn", "ahIntegration" },
            { "03", "Preis im Tooltip", "ttInfoBtn", "tooltipInfo" },
            { "04", "Preisverlauf im Tooltip", function()
                local before, steps = A.Tooltip:ChartDays(), {}
                for _ = 1, 8 do
                    Click(Opt().ttChartBtn)
                    steps[#steps + 1] = tostring(A.Tooltip:ChartDays())
                    if A.Tooltip:ChartDays() == before then break end
                end
                return A.Tooltip:ChartDays() == before and #steps > 1, table.concat(steps, ",")
            end },
            { "05", "Händlerpreis im Tooltip", "ttVendorBtn", "tooltipVendor" },
            { "06", "Twinks im Tooltip", "ttCharsBtn", "tooltipChars" },
            { "07", "Entzauberwert im Tooltip", "ttDEBtn", "tooltipDE" },
            { "08", "Entzaubern zurücksetzen (Sandbox)", function()
                local stats, shared = Copy(A.db.deStats), Copy(A.db.deShared)
                local w = Opt()
                Click(w.deReset); local asked = w.deConfirm
                Click(w.deReset)
                local cleared = next(A.db.deStats or {}) == nil
                A.db.deStats, A.db.deShared = stats, shared
                return asked and cleared, "Rückfrage " .. tostring(asked) .. ", geleert " .. tostring(cleared)
            end },
            { "09", "Knöpfe am Briefkasten", "mailBtn", "mailButtons" },
            { "10", "Meldung bei Verkauf", "saleBtn", "saleAlert" },
            { "11", "Preisschutz", function()
                local before, seen = A.Seller:GuardPercent(), {}
                for _ = 1, #A.Seller.GUARD_STEPS do Click(Opt().guardBtn); seen[#seen + 1] = A.Seller:GuardPercent() end
                return A.Seller:GuardPercent() == before, table.concat(seen, ",")
            end },
            { "12", "Gewinn im Berufsfenster", "craftBtn", "craftPanel" },
            { "13", "Sprache des Addons", function() return Opt().uiLangBtn ~= nil, "Knopf da, Wechsel aller Sprachen siehe T112" end },
            { "14", "Item-Namen-Sprache", function()
                local before, n = A.db.settings.nameLocale, 0
                repeat Click(Opt().langBtn); n = n + 1 until A.db.settings.nameLocale == before or n > 20
                return A.db.settings.nameLocale == before, n .. " Klicks bis zurück"
            end },
            { "15", "Geldanzeige", "moneyBtn", "moneyStyle", function(v) return v == "letters" end },
            { "16", "Fenstergröße", function()
                local sc = A.db.settings.scale or 1
                Click(Opt().scaleUp); Click(Opt().scaleDown)
                return math.abs((A.db.settings.scale or 1) - sc) < 0.001, tostring(A.db.settings.scale)
            end },
            { "17", "Schrift- und Inhaltsgröße", function()
                local z = A.db.settings.ahZoom
                Click(Opt().zoomUp); Click(Opt().zoomDown)
                A.db.settings.ahZoom = z
                return true, "ohne Fehler"
            end },
            { "18", "Ton", "soundBtn", "alertSound", function(v) return v and true or false end },
            { "19", "Preise teilen (nur simuliert)", function()
                local j, l = self.real.JoinTemporaryChannel or 0, self.real.LeaveChannelByName or 0
                local on = A.Sync:IsEnabled() and true or false
                Click(Opt().syncBtn); local mid = A.Sync:IsEnabled() and true or false
                Click(Opt().syncBtn)
                return mid ~= on and (self.real.JoinTemporaryChannel or 0) == j and (self.real.LeaveChannelByName or 0) == l,
                    "an/aus, Kanal-Beitritt/-Austritt 0"
            end },
            { "20", "nur Gilde", function()
                local gOnly = A.Sync:GuildOnly()
                Click(Opt().syncGuildBtn); local mid = A.Sync:GuildOnly()
                Click(Opt().syncGuildBtn)
                return mid ~= gOnly and A.Sync:GuildOnly() == gOnly, tostring(mid)
            end },
            { "21", "Sniper-Intervall", function()
                local v = A.db.sniper.interval
                Click(Opt().snipeUp); Click(Opt().snipeDown)
                A.db.sniper.interval = v
                return true, "ohne Fehler"
            end },
            { "22", "Sniper-Taste (Mausrad)", function()
                local binds = Copy(A.db.sniper.binds)
                A.Sniper:UseMouseWheel("sniper")
                local wheel = A.Sniper:IsMouseWheelBind("sniper")
                A.db.sniper.binds = binds
                return wheel, A.Sniper:GetBindsText("sniper")
            end },
            { "23", "Wächter-Taste (Mausrad)", function()
                local binds = Copy(A.db.watcher.binds)
                A.Sniper:UseMouseWheel("watcher")
                local wheel = A.Sniper:IsMouseWheelBind("watcher")
                A.db.watcher.binds = binds
                return wheel, A.Sniper:GetBindsText("watcher")
            end },
            { "24", "Tagesbilanz + Jetzt zeigen", function()
                local v = A.db.settings.dailySummary
                Click(Opt().dailyBtn); local mid = A.db.settings.dailySummary
                Click(Opt().dailyBtn)
                Capture(Click, Opt().dailyNow)
                return Eff(mid) ~= Eff(v), "umgeschaltet"
            end },
            { "25", "Knopf beim Händler", "vendorBtn", "vendorButton" },
            { "26", "Post an Twinks (Regeln)", function()
                Click(Opt().rulesBtn)
                return Shown(UI.mailRulesWindow), "Regeln-Fenster"
            end },
            { "27", "Minikarte", function()
                local hide = A.db.settings.minimapHide and true or false
                Click(Opt().minimapBtn); local mid = A.db.settings.minimapHide and true or false
                Click(Opt().minimapBtn)
                return mid ~= hide and (A.db.settings.minimapHide and true or false) == hide, "aus/an"
            end },
            { "28", "Post automatisch abholen", "autoMailBtn", "autoCollect" },
            { "29", "Alt-Klick", "altClickBtn", "altClick" },
            { "30", "Verkaufschance im Tooltip", "chanceBtn", "tooltipChance" },
            { "31", "Ablauf-Erinnerung", "expiryBtn", "expiryReminder" },
            { "32", "Gold-Ziel setzen/löschen", function()
                Capture(function() A.Comfort:SetGoldGoal(5000 * 10000); A.Comfort:SetGoldGoal(nil) end)
                return A.Comfort:GoldGoal() == nil, "gesetzt und gelöscht"
            end },
            { "33", "Zeile Selbsttest nur für Dev", function()
                local b = Opt().selfTestBtn
                return b:IsShown() == (A:IsDev() and true or false), "sichtbar " .. tostring(b:IsShown())
            end },
            { "34", "CSV-Export", function() Capture(Click, Opt().exportBtn); return true, "ohne Fehler" end },
            { "35", "Positionen", function()
                local st = A.db.settings
                local saved = { windowPos = Copy(st.windowPos), windowSize = Copy(st.windowSize), buttonPos = Copy(st.buttonPos),
                    minimapAngle = st.minimapAngle, minimapHide = st.minimapHide }
                Capture(Click, Opt().resetBtn)
                for k, v in pairs(saved) do st[k] = v end
                return true, "ohne Fehler, Werte zurück"
            end },
            { "36", "Unterstützen", function() Click(Opt().donateBtn); return Shown(UI.donateWindow), "Fenster" end },
        }
        B(function()
        for _, o in ipairs(OPTIONS) do
            Chk("T30." .. o[1], "B", "Option " .. o[2], function()
                local st = A.db.settings
                local snap = Copy(st)
                local res = { pcall(function()
                    if type(o[3]) == "function" then return o[3]() end
                    local field, key, eff = o[3], o[4], o[5] or Eff
                    local v0 = eff(st[key])
                    Click(Opt()[field]); local v1 = eff(st[key])
                    Click(Opt()[field]); local v2 = eff(st[key])
                    return (v1 ~= v0) and (v2 == v0), string.format("%s: %s -> %s -> %s", key, tostring(v0), tostring(v1), tostring(v2))
                end) }
                -- Einstellungen genau wie vorher (nil/true-Unterschiede der Umschalter), Fenster zu
                for k, v in pairs(snap) do if k ~= "theme" and k ~= "uiLanguage" then st[k] = Copy(v) end end
                for k in pairs(st) do if snap[k] == nil then st[k] = nil end end
                HideAll()
                if not res[1] then error(res[2], 0) end
                return res[2] and true or false, res[3], "umgeschaltet und zurück"
            end)
        end
        end)

        -- T31.xx: jeder Chat-Befehl (A:Print abgefangen)
        local function Has(lines, text) return table.concat(lines, "\n"):find(A:PlainText(text), 1, true) ~= nil end
        local CMDS = {
            { "01", "" }, { "02", "show" },
            { "03", "scan", function(out)
                if A:IsAHOpen() then return true end
                return Has(out, L["Bitte zuerst das Auktionshaus öffnen."]) and not A:IsScanning()
            end },
            { "04", "export" }, { "05", "debug", function(out) return Has(out, g.Status()) end },
            { "06", "reset" }, { "07", "resetscan" }, { "08", "sync" }, { "09", "sync" }, { "10", "ahdebug" }, { "11", "ah" },
            { "12", "sniper" }, { "13", "sniper" }, { "14", "design" }, { "15", "design" }, { "16", "optionen" },
            { "17", "options" }, { "18", "spenden" }, { "19", "donate" }, { "20", "bilanz" }, { "21", "summary" },
            { "22", "ziel 5000", function() return A.Comfort:GoldGoal() == 50000000 end }, { "23", "ziel" },
            { "24", "ziel aus", function() return A.Comfort:GoldGoal() == nil end },
            { "25", "heute" }, { "26", "today" }, { "27", "minikarte" }, { "28", "minikarte" }, { "29", "raid" },
            { "30", "twinks" }, { "31", "sprache" }, { "32", "listen" }, { "33", "hilfe" }, { "34", "handbuch" },
            { "35", "xyz", function(out) return Has(out, string.format(L["Unbekannter Befehl: %s"], "xyz")) end },
        }
        B(function()
        for _, cmd in ipairs(CMDS) do
            if cmd[2] == "resetscan" and A:IsScanning() then
                Skp("T31." .. cmd[1], "B", "Befehl /ahs resetscan", "Markt-Scan läuft - würde ihn abbrechen")
            else
            Chk("T31." .. cmd[1], "B", "Befehl /ahs " .. cmd[2], function()
                local st = A.db.settings
                local snap = { goal = st.goldGoal, reached = st.goldGoalReached, ui = UI:IsVisible(), lang = st.uiLanguage or "auto",
                    theme = st.theme, raid = A.Lists:Exists(L["Raid-Vorrat"]), windowPos = Copy(st.windowPos),
                    windowSize = Copy(st.windowSize), buttonPos = Copy(st.buttonPos), minimapAngle = st.minimapAngle,
                    minimapHide = st.minimapHide, armed = A.Sniper:IsArmed() }
                local res = { pcall(Capture, SlashCmdList.AHANALYZERPRO, cmd[2]) }
                local ok = res[1] and (not cmd[3] or cmd[3](res[2]) and true or false)
                -- Folgen zurück
                if cmd[2] == "sprache" then
                    local n = 0
                    while A:UILanguageSetting() ~= snap.lang and n < 20 do A:CycleUILanguage(1); n = n + 1 end
                end
                if cmd[2] == "raid" and not snap.raid and A.Lists:Exists(L["Raid-Vorrat"]) then A.Lists:Delete(L["Raid-Vorrat"]) end
                if (A.Sniper:IsArmed() and true or false) ~= (snap.armed and true or false) then A.Sniper:SetArmed(snap.armed and true or false) end
                st.goldGoal, st.goldGoalReached = snap.goal, snap.reached
                for _, k in ipairs({ "windowPos", "windowSize", "buttonPos", "minimapAngle", "minimapHide" }) do st[k] = snap[k] end
                if A.SetMinimapButtonShown then A:SetMinimapButtonShown(not st.minimapHide) end
                if st.theme ~= snap.theme then UI:SetTheme(snap.theme) end
                HideAll()
                if snap.ui then UI:Show() else UI:Hide() end
                if not res[1] then error(res[2], 0) end
                return ok, ok and "ohne Fehler" or (table.concat(res[2], " / "):sub(1, 120)), "erwartete Meldung"
            end)
            end
        end
        Skp("T31.36", "B", "Befehle test*/testmodus", "würde die laufende Routine stören")
        end)

        B(function()
        Chk("T34", "B", "Einkauf rechnen", function()
            local Bu = A.Buy
            local saved, savedP = Bu.detail, Bu.pending
            Bu.pending = nil
            Bu.detail = { itemID = FAKE, commodity = true, qty = 1,
                listings = { { qty = 5, price = 100 }, { qty = 10, price = 150 } } }
            local res = { pcall(function()
                local t8 = Bu:Quote(8)
                local t20 = Bu:Quote(20)
                local av = Bu:Available()
                Bu:SetQuantity(99)
                local q = Bu.detail.qty
                local m1, m2 = Bu:MinBid({ bid = 1000 }), Bu:MinBid({ minBid = 77 })
                local own = Bu.BuyItem(Bu, { own = true, auctionID = 1, buyout = 1 })
                return t8 == 950 and t20 == nil and av == 15 and q == 15 and m1 == 1050 and m2 == 77 and not own,
                    string.format("%s/%s/%d/%d/%s/%s", tostring(t8), tostring(t20), av, q, tostring(m1), tostring(m2))
            end) }
            Bu.detail, Bu.pending = saved, savedP
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "950/nil/15/15/1050/77"
        end)
        Chk("T39", "B", "Sniper-Ziele", function()
            local Sn = A.Sniper
            local targets = Copy(A.db.sniper.targets)
            local res = { pcall(function()
                local ok = Sn:SetTarget(tostring(LINEN), 500, 3, 2000)
                local t = Sn:GetTarget("i:" .. LINEN)
                local q = t and Sn:Remaining(t)
                local done = t and Sn:IsDone(t)
                if t then Sn:FilterText(t) end
                Sn:RemoveTarget("i:" .. LINEN)
                return ok and t ~= nil and q == 3 and done == false and Sn:GetTarget("i:" .. LINEN) == nil,
                    string.format("gesetzt %s, Rest %s, fertig %s", tostring(ok), tostring(q), tostring(done))
            end) }
            A.db.sniper.targets = targets
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "gesetzt, Rest 3, nicht fertig, entfernt"
        end)
        Chk("T43", "B", "Sniper-Tasten", function()
            local Sn = A.Sniper
            local name = Sn:KeyName("SHIFT-BUTTON4")
            local before = self.real.SetOverrideBindingClick or 0
            if not A:IsAHOpen() then Sn:ApplyBindings() end
            local set = (self.real.SetOverrideBindingClick or 0) - before
            return name == "Shift+" .. L["Maustaste 4"] and (A:IsAHOpen() or set == 0),
                string.format("%s, Tasten bei geschlossenem AH: %d", tostring(name), set), "Shift+" .. L["Maustaste 4"] .. ", 0"
        end)
        Chk("T44", "B", "Wächter-Einstellungen", function()
            local W = A.Watcher
            local saved = Copy(A.db.watcher)
            local res = { pcall(function()
                W:SetThreshold(40); W:SetMinValue(20); W:SetBudget(1000)
                for _, c in ipairs(W.CATS or {}) do W:ToggleCategory(c.key or c[1] or c); W:CategoryLabel(c.key or c[1] or c) end
                W:ModeLabel(); W:ActiveCategories()
                local why = W:WhyWaiting()
                return A:IsAHOpen() or why == L["wartet auf das Auktionshaus"], tostring(why)
            end) }
            Replace(A.db.watcher, saved)
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], A:IsAHOpen() and "ohne Fehler" or L["wartet auf das Auktionshaus"]
        end)
        Chk("T54", "B", "Buchhaltung rechnen", function()
            local Le = A.Ledger
            local entries = Copy(A.db.ledger.entries)
            local res = { pcall(function()
                local s0 = Le:Summary("all").sales
                Le:Add({ kind = "buy", itemID = FAKE, qty = 2, amount = 200 })
                Le:Add({ kind = "sale", itemID = FAKE, qty = 1, amount = 300, cut = 15 })
                local s1 = Le:Summary("all").sales
                local sold, avg = Le:SoldCount(FAKE, 30), Le:AverageBuyPrice(FAKE, 30)
                Le:Stats("all"); Le:ByItem("all"); Le:PeriodStart("7")
                return s1 == s0 + 1 and sold == 1 and avg == 100, string.format("Verkäufe +%d, verkauft %d, Ø Kauf %s",
                    s1 - s0, sold, tostring(avg))
            end) }
            A.db.ledger.entries = entries
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "+1, 1, 100"
        end)
        Chk("T62", "B", "Watchlist", function()
            local Wl = A.Watchlist
            local had = Copy(A.db.watchlist[LINEN])
            local res = { pcall(function()
                local ok = Wl:Add(tostring(LINEN), 100, 500)
                local has = Wl:Contains(LINEN)
                Wl:SetBuyBelow(tostring(LINEN), 120); Wl:GetStatus(LINEN); Wl:CountAlerts()
                Capture(Wl.CheckAlerts, Wl, false)
                return ok and has, "hinzugefügt " .. tostring(ok)
            end) }
            A.db.watchlist[LINEN] = had
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "hinzugefügt und wieder wie vorher"
        end)
        end)
    end

    -- ---------------- C. Taschen, Addon-Info, Esc im Kampf (0.65.7) ----------------
    if want(part, "c") then B(function()
        Chk("T89", "C", "Taschen ohne alte Funktionen", function()
            local Se, X, M = A.Seller, A.Extras, A.Mailer
            local function run()
                if Se.InvalidateBags then Se:InvalidateBags() end
                local items = Se:GetBagItems()
                local cand = X:VendorCandidates()
                local free = M.FreeSlots and M.FreeSlots() or 0
                return #items, #cand, free
            end
            -- 1) alte Funktionen fehlen, C_Container da (moderner Weg)
            A.apiOverride = { GetContainerNumSlots = false, GetContainerItemInfo = false, GetContainerNumFreeSlots = false }
            local ok1, n1, c1, f1 = pcall(run)
            -- 2) gar nichts da (nur simuliert): leere Liste, kein Fehler
            A.apiOverride = { C_Container = false, GetContainerNumSlots = false, GetContainerItemInfo = false,
                GetContainerNumFreeSlots = false }
            local ok2, n2, c2, f2 = pcall(run)
            A.apiOverride = nil
            if Se.InvalidateBags then Se:InvalidateBags() end
            if not ok1 then error(n1, 0) end
            if not ok2 then error(n2, 0) end
            local modernOK = (C_Container == nil) or n1 > 0 or f1 > 0
            return modernOK and n2 == 0 and c2 == 0 and f2 == 0,
                string.format("C_Container: %d Items, %d frei · ohne alles: %d/%d/%d", n1, f1, n2, c2, f2), "Taschen gelesen; ohne alles 0/0/0"
        end)
        Chk("T92", "C", "Addon-Info und Chat-Hilfen", function()
            local S = A.Sync
            local f = S.GetSendFunction and S.GetSendFunction()      -- nur nachsehen, nie senden
            A.apiOverride = { C_ChatInfo = false }
            local f2 = S.GetSendFunction and S.GetSendFunction()
            A.apiOverride = { ChatFrame_RemoveChannel = false }
            local hid = S.HideChannelFromChat and S.HideChannelFromChat()
            A.apiOverride = nil
            local meta = ((C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata)
            local okMeta = meta and meta("AHSentinel", "Version") == A.version
            return f ~= nil and (f2 == SendAddonMessage) and hid == false and okMeta,
                string.format("Senden %s, ohne C_ChatInfo %s, ohne RemoveChannel %s, Metadaten %s", tostring(f ~= nil),
                    f2 and "SendAddonMessage" or "nil", tostring(hid), tostring(okMeta)),
                "Rückfall SendAddonMessage, HideChannelFromChat kehrt zurück"
        end)
        Chk("T94", "C", "Esc-Fenster im Kampf", function()
            local f = CreateFrame("Frame", nil, UIParent)
            if not (f.SetPropagateKeyboardInput and f.EnableKeyboard) then return true, "Client ohne SetPropagateKeyboardInput" end
            local n = 0
            hooksecurefunc(f, "SetPropagateKeyboardInput", function() if A.testCombat then n = n + 1 end end)
            A.testCombat = true
            A.UI:EscCloses(f)
            f:Show(); f:Hide(); f:Show()
            local key = f:GetScript("OnKeyDown")
            if key then key(f, "A"); key(f, "ESCAPE") end
            A.testCombat = nil
            f:Hide()
            return n == 0, n .. " Aufrufe im Kampf", "0"
        end)
    end) end

    -- ---------------- I/J. Ergänzungen (0.65.7) ----------------
    if want(part, "i") then B(function()
        self.wantJobError = true
        A:Job("ahs-test-error", function() error("AHS-Test T129", 0) end)
    end)
    B(function()
        if not self.wantJobError then return end
        return "WAIT", function() return not A:HasJob("ahs-test-error") end, 5, function(timedOut)
            local e = ErrorEntry("Job:ahs-test-error")
            self.wantJobError = nil
            Chk("T129", "I", "Fehler in Hintergrund-Aufgabe wird gemeldet", function()
                return e ~= nil, e and "Eintrag da" or "kein Eintrag", "Eintrag wo = Job:ahs-test-error"
            end)
            self:ClearTestErrors()
        end
    end) end
    if want(part, "j") then B(function()
        Chk("T143", "J", "Übergang vom alten AH Analyzer Pro", function()
            local get = C_AddOns and C_AddOns.GetAddOnOptionalDependencies
            if not get then return true, "GetAddOnOptionalDependencies fehlt - nur _G.AHAnalyzerPro geprüft" end
            local deps = { get("AHSentinel") }
            for _, d in ipairs(deps) do if d == "AHAnalyzerPro" then return false, "OptionalDeps enthält AHAnalyzerPro", "nicht enthalten" end end
            return _G.AHAnalyzerPro == A and A.version ~= nil, #deps .. " OptionalDeps, AHAnalyzerPro = AHSentinel", "kein AHAnalyzerPro"
        end)
        Cli("T143b", "J", "Alter Ordner AHAnalyzerPro zusätzlich vorhanden",
            "Ordner AddOns\\AHAnalyzerPro (bis 0.61) zusätzlich aktivieren: genau eine Meldung 'Bitte den alten Ordner ... löschen', keine doppelten /ahs-Befehle, keine Lua-Fehler")
    end) end

    -- ---------------- C. Forever-Sonderfälle (simuliert) ----------------
    if want(part, "c") then B(function()
        local function secretCheck(id, name, fn, verify)
            Chk(id, "C", name, function()
                local ok, err = WithSecret(fn)
                self:ClearTestErrors()
                if not ok then return false, tostring(err), "kein Lua-Fehler" end
                if verify then return verify() end
                return true
            end)
        end
        local Se, S, D, M, Sn = A.Seller, A.Sync, A.Disenchant, A.Mailer, A.Sniper
        local lastSale = Se and Se.lastSale
        secretCheck("T80", "Systemmeldung \"verkauft\" geschützt", function()
            Se.saleFrame:GetScript("OnEvent")(Se.saleFrame, "CHAT_MSG_SYSTEM", SECRET)
        end, function() return Se.lastSale == lastSale, nil, "lastSale unverändert" end)
        local peers = Count(A.db.sync and A.db.sync.peers)
        secretCheck("T81", "Addon-Nachricht Sync geschützt", function()
            local f = S.frame:GetScript("OnEvent")
            f(S.frame, "CHAT_MSG_ADDON", "AHAP1", SECRET, "CHANNEL", "Testpeer")
            f(S.frame, "CHAT_MSG_ADDON", "AHAP1", "H:1", "CHANNEL", SECRET)
        end, function()
            local e = A.db.gsTest and A.db.gsTest.errors
            for k in pairs(e or {}) do if k:find("^Sync|") and k:find("geschützt") then return false, "Sync-Fehler", "keiner" end end
            return Count(A.db.sync and A.db.sync.peers) == peers, nil, "peers unverändert"
        end)
        secretCheck("T82", "Zauber-Ereignis Entzaubern geschützt", function()
            D.evt:GetScript("OnEvent")(D.evt, "UNIT_SPELLCAST_SUCCEEDED", "player", "x", SECRET)
        end)
        secretCheck("T83", "Tooltip-Daten geschützt", function()
            local tip = { AddLine = function() error("Zeile hinzugefügt") end, NumLines = function() return 0 end }
            A.Tooltip:Handle(tip, { id = SECRET })
        end)
        secretCheck("T84", "Fehlermeldung am Briefkasten geschützt", function()
            local was = M.running
            M.running = true
            local ok, err = pcall(M.evt:GetScript("OnEvent"), M.evt, "UI_ERROR_MESSAGE", SECRET, SECRET)
            M.running = was
            if not ok then error(err, 0) end
        end)
        local inst = Sn and Sn.instantFailed
        secretCheck("T85", "Blockierte Aktion geschützt", function()
            Sn:OnEvent("ADDON_ACTION_BLOCKED", SECRET, SECRET)
        end, function() return Sn.instantFailed == inst, nil, "instantFailed unverändert" end)
        Chk("T86", "C", "Forever-Namen: Post-Regel an sich selbst", function()
            local X = A.Extras
            if not (X and X.IsMyself and g and g.SetTestFlavor) then return true, "nicht prüfbar" end
            g.SetTestFlavor("forever")
            X.testMyName = "Rokan Steinwacht"
            local ok, me = pcall(X.IsMyself, "Rokan")
            local ok2, other = pcall(X.IsMyself, "Brakka")
            X.testMyName = nil
            g.SetTestFlavor(nil)
            return ok and ok2 and me == true and other == false, tostring(me) .. "/" .. tostring(other), "true/false"
        end)
        Chk("T87", "C", "Händler ohne alte Funktionen", function()
            A.apiOverride = { GetMerchantNumItems = false, GetMerchantItemInfo = false, GetMerchantItemLink = false,
                GetMerchantItemID = false, C_MerchantFrame = false, GetMerchantItemCostInfo = false }
            local ok, n = pcall(A.ScanMerchant, A)
            A.apiOverride = nil
            return ok and n == 0, tostring(n), "0 ohne Fehler"
        end)
        Chk("T88", "C", "Berufe ohne alte Funktionen", function()
            A.apiOverride = { GetNumTradeSkills = false }
            local k1 = A.Crafting:TradeKind()
            A.apiOverride = { GetNumTradeSkills = false, C_TradeSkillUI = false }
            local k2 = A.Crafting:TradeKind()
            A.apiOverride = nil
            local ts = C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs
            return k1 == (ts and "modern" or "trade") and k2 == "trade", k1 .. "/" .. k2, (ts and "modern" or "trade") .. "/trade"
        end)
        Chk("T90", "C", "Item-Aliase beim Laden", function()
            return A:StackSize(LINEN) >= 1 and A:GetItemIcon(LINEN) ~= nil, tostring(A:StackSize(LINEN)), "Stapel >= 1, Symbol da"
        end)
        Chk("T91", "C", "Post ohne Funktionen", function()
            A.apiOverride = { SendMail = false, ClickSendMailItemButton = false }
            local open = MailFrame and MailFrame:IsShown()
            local ok, r, msg = pcall(A.Extras.MailStep, A.Extras)
            A.apiOverride = nil
            if not ok then error(r, 0) end
            if not open then return r == false, tostring(msg), "Briefkasten zu -> false" end
            return r == false and msg == L["Dein Client unterstützt das Verschicken nicht."], tostring(msg), "Dein Client unterstützt ..."
        end)
        Chk("T93", "C", "Sniper-Tasten im Kampf", function()
            local Sn = A.Sniper
            local before = self.real.SetOverrideBindingClick or 0
            A.testCombat = true
            Sn:ApplyBindings()
            local pend = Sn.pendingBindings
            A.testCombat = false
            Sn.evt:GetScript("OnEvent")(Sn.evt, "PLAYER_REGEN_ENABLED")
            local after = Sn.pendingBindings
            A.testCombat = nil
            local set = (self.real.SetOverrideBindingClick or 0) - before
            return (SetOverrideBindingClick == nil) or (pend == true and after == false), string.format("im Kampf %s, danach %s, Tasten %d",
                tostring(pend), tostring(after), set), "true, false"
        end)
        Chk("T95", "C", "Routine-Start im Kampf abgelehnt", function()
            A.testCombat = true
            self.running = false
            local lines, ok = Capture(function() return TR.Start(TR, "a") end)
            self.running = true
            A.testCombat = nil
            return ok == false, tostring(ok), "false"
        end)
        Chk("T96", "C", "Kampflog nicht benutzt", function()
            local bad = {}
            for name, f in pairs({ Crafting = A.Crafting.evt, Extras = A.Extras.evt, Seller = A.Seller.saleFrame, Sniper = A.Sniper.evt,
                Disenchant = A.Disenchant.evt, Mailer = A.Mailer.evt, Comfort = A.Comfort.evt, Chars = A.Chars.evt,
                Sync = A.Sync.frame, Kern = A.eventFrame, Test = TR.frame }) do
                if f and f.IsEventRegistered and f:IsEventRegistered("COMBAT_LOG_EVENT_UNFILTERED") then bad[#bad + 1] = name end
            end
            return #bad == 0, #bad == 0 and "keiner" or table.concat(bad, ", "), "keiner"
        end)
    end) end

    -- ---------------- D. Alte Clients ----------------
    if want(part, "d") then B(function()
        if not A.AH_LEGACY then
            Skp("T97", "D", "Nachbildung altes AH", "nur im alten Client")
        else
            Chk("T97", "D", "Nachbildung altes AH", function()
                local AH = ST.realAH or A.AH
                local k = AH.MakeItemKey and AH.MakeItemKey(LINEN)
                return k and k.itemID == LINEN, tostring(k and k.itemID), tostring(LINEN)
            end)
        end
        Chk("T102", "D", "Raid-Vorrat je Version", function()
            local key = A.Comfort:RaidSetKey()
            local p = WOW_PROJECT_ID
            local expect
            if A:IsForever() then expect = "classic"
            elseif p == (WOW_PROJECT_CLASSIC or 2) then expect = "classic"
            elseif p == (WOW_PROJECT_BURNING_CRUSADE_CLASSIC or 5) then expect = "tbc"
            elseif p == (WOW_PROJECT_WRATH_CLASSIC or 11) then expect = "wrath" end
            return key == expect, tostring(key), tostring(expect)
        end)
        Chk("T103", "D", "keine Rückschritte zum letzten Bericht", function()
            local reps = A.db.gsTest and A.db.gsTest.reports
            return true, string.format("%d frühere Berichte (Vergleich macht die Prüf-Sitzung)", reps and #reps or 0)
        end)
    end) end

    -- ---------------- E. Daten ----------------
    if want(part, "e") then B(function()
        Chk("T104", "E", "Neuinstallation", function()
            local orig, origOld, migrated = AHSentinelDB, AHAnalyzerProDB, A.migratedFromOld
            local ok, err, res
            AHSentinelDB, AHAnalyzerProDB = nil, nil
            local lines
            ok, err = pcall(function()
                lines = Capture(function() A:InitDB() end)
                local d = A.db
                res = { d.dbVersion, d.settings.detachedWindow, d.sniper.fastSearch, d.settings.nameLocale }
            end)
            AHSentinelDB, AHAnalyzerProDB, A.db, A.migratedFromOld = orig, origOld, orig, migrated
            A:ApplyUILanguage()
            local GT = GTest()
            if GT then GT.TrackErrors("AHSentinel", A.version, A.db) end
            if not ok then error(err, 0) end
            return res[1] == 4 and res[2] == true and res[3] == true and res[4] == "auto",
                string.format("%s/%s/%s/%s", tostring(res[1]), tostring(res[2]), tostring(res[3]), tostring(res[4])), "4/true/true/auto"
        end)
        Chk("T105", "E", "Migration Datenbank 3 -> 4", function()
            local orig, migrated = AHSentinelDB, A.migratedFromOld
            local t1, t2 = time() - 2000, time() - 1000
            AHSentinelDB = { dbVersion = 3, marketData = { [LINEN] = { history = { { price = 100, time = t2, quantity = 1 },
                { price = 90, timestamp = t1, qty = 2 } } } } }
            local lines, h
            local ok, err = pcall(function()
                lines = Capture(function() A:InitDB() end)
                h = A.db.marketData[LINEN] and A.db.marketData[LINEN].history
            end)
            AHSentinelDB, A.db, A.migratedFromOld = orig, orig, migrated
            A:ApplyUILanguage()
            local GT = GTest()
            if GT then GT.TrackErrors("AHSentinel", A.version, A.db) end
            if not ok then error(err, 0) end
            local good = h and #h == 2 and h[1].t == t1 and h[1].p == 90 and h[1].q == 2 and h[2].p == 100
            return good and table.concat(lines, " "):find(A:PlainText(L["Datenbank auf Version 4 umgestellt."]), 1, true) ~= nil,
                h and (#h .. " Einträge") or "nil", "2 Einträge sortiert, Meldung"
        end)
        Chk("T109", "E", "Abbruch mitten im Test (Wiederherstellung)", function()
            return type(TR.RecoverAfterReload) == "function" and A.db.testRoutine and A.db.testRoutine.backup ~= nil, nil,
                "Sicherung liegt in AHSentinelDB.testRoutine"
        end)
    end) end

    -- ---------------- F. Sprachen ----------------
    if want(part, "f") then B(function()
        local LANGS = { "frFR", "esES", "esMX", "ptBR", "itIT", "ruRU", "koKR", "zhCN", "zhTW" }
        Chk("T110", "F", "Text-Schlüssel vollständig", function()
            local miss, parts = 0, {}
            for _, l in ipairs(LANGS) do
                local n = 0
                for k in pairs(A.EN) do if A.T[l][k] == nil then n = n + 1 end end
                miss = miss + n
                if n > 0 then parts[#parts + 1] = l .. " " .. n end
            end
            return miss == 0, miss == 0 and (Count(A.EN) .. " Schlüssel je Sprache") or table.concat(parts, ", "), "0 fehlend"
        end)
        Chk("T111", "F", "Formatplatzhalter", function()
            local function marks(s)
                local out = {}
                for m in tostring(s):gsub("%%%%", ""):gmatch("%%[%-%d%.]*[sdfi]") do out[#out + 1] = m:sub(-1) end
                return table.concat(out)
            end
            local bad = {}
            for k, en in pairs(A.EN) do
                local want = marks(k)
                if marks(en) ~= want then bad[#bad + 1] = "enUS: " .. k:sub(1, 30) end
                for _, l in ipairs(LANGS) do
                    local v = A.T[l][k]
                    if v and marks(v) ~= want then bad[#bad + 1] = l .. ": " .. k:sub(1, 30) end
                end
                if #bad > 10 then break end
            end
            return #bad == 0, #bad == 0 and "0 Abweichungen" or table.concat(bad, " | "), "0 Abweichungen"
        end)
        Chk("T113", "F", "Text-Werte gültig, Hilfeseiten", function()
            local bad = {}
            for k, v in pairs(A.EN) do if type(v) ~= "string" then bad[#bad + 1] = "enUS" end end
            for _, l in ipairs(LANGS) do
                for k, v in pairs(A.T[l]) do if type(v) ~= "string" then bad[#bad + 1] = l; break end end
            end
            local ref = A.HELP.deDE or A.HELP.enUS
            if type(ref) == "table" then
                for _, l in ipairs(LANGS) do
                    local h = A.HELP[l]
                    if type(h) == "table" and #h ~= #ref then bad[#bad + 1] = "Hilfe " .. l end
                end
            end
            return #bad == 0, table.concat(bad, ", "), "alles Text, gleiche Hilfeseiten"
        end)
        Chk("T114", "F", "Texte der gemeinsamen Dateien", function()
            local D = _G.GoldSentinelDev
            local a = g and g.Text("game")
            local b = D and D.Text and D:Text("blocked")
            return a ~= "game" and (b == nil or b ~= "blocked"), tostring(a), "übersetzter Text"
        end)
    end) end

    -- ---------------- G. Zusammenspiel ----------------
    if want(part, "g") then B(function()
        Chk("T115", "G", "gemeinsame Dateien nach Simulation wieder echt", function()
            if not (g and g.SetTestFlavor) then return true, "SetTestFlavor fehlt" end
            local f = g.flavor
            g.SetTestFlavor(f == "forever" and "era" or "forever")
            g.SetTestFlavor(nil)
            return g.flavor == f, tostring(g.flavor), tostring(f)
        end)
        Chk("T116", "G", "globale Namen", function()
            return _G.AHAnalyzerPro == A and A.version ~= nil and _G.AHSentinelDB == A.db, nil, "AHAnalyzerPro = A, AHSentinelDB = A.db"
        end)
        Chk("T117", "G", "ProfessionSentinel liest AHSentinel (QuickBuy/QuickSell, Händler-Kosten)", function()
            local Td = A.Today
            local ok1 = Td:QuickBuy(LINEN, 2, 100, "Test")
            local found
            for _, r in ipairs(Td.extra) do if r.key == "quick:" .. LINEN and r.pin then found = true end end
            local ok0 = Td:QuickBuy(LINEN, 2, 0, "Test")
            local lines, ok2 = Capture(function() return Td:QuickSell(LINEN) end)
            for i = #Td.extra, 1, -1 do
                local k = Td.extra[i].key
                if k == "quick:" .. LINEN or k == "quicksell:" .. LINEN then table.remove(Td.extra, i) end
            end
            Td.state["quick:" .. LINEN], Td.state["quicksell:" .. LINEN] = nil, nil
            if A.UI and A.UI.todayWin then A.UI.todayWin:Hide() end
            return ok1 and found and ok0 == false and ok2, nil, "Zeile mit pin, maxPrice 0 abgelehnt"
        end)
        Chk("T118", "G", "AHSentinel liest ProfessionSentinel (Stub, Fehler abgefangen)", function()
            local real = _G.ProfessionSentinelAPI
            local okA, okB
            _G.ProfessionSentinelAPI = { version = 1, TodayCrafts = function() error("AHS-Test PS") end }
            okA = pcall(A.Comfort.TodayActions, A.Comfort, 10)
            _G.ProfessionSentinelAPI = { version = 2 }
            okB = pcall(A.Comfort.TodayActions, A.Comfort, 10)
            _G.ProfessionSentinelAPI = real
            self:ClearTestErrors()
            return okA and okB and _G.ProfessionSentinelAPI == real, nil, "kein Fehler in TodayActions, echte API zurück"
        end)
    end) end

    -- ---------------- H. Leistung ----------------
    if want(part, "h") then B(function()
        local function measure(id, name, fn, n, limit)
            Chk(id, "H", name, function()
                local sum, max = 0, 0
                for i = 1, n do
                    local t = Ms()
                    fn()
                    local d = Ms() - t
                    sum = sum + d
                    if d > max then max = d end
                end
                local avg = sum / n
                return avg < limit, string.format("Mittel %.3f ms, höchstens %.2f ms (%d Items)", avg, max, Count(A.db.marketData)),
                    string.format("< %.2f ms", limit)
            end)
        end
        measure("T121", "Takt-Funktionen (Sniper, Wächter)", function() A.Sniper:Tick(); A.Watcher:Tick() end, 100, 0.4)
        measure("T123", "Heute tun (10)", function() A.Comfort:TodayActions(10) end, 3, 16)
        measure("T123b", "Marktliste", function() A:BuildItemList() end, 3, 16)
        measure("T125", "Zauber-Ereignis im Raid", function()
            A.Disenchant.evt:GetScript("OnEvent")(A.Disenchant.evt, "UNIT_SPELLCAST_SUCCEEDED", "raid5", "x", 1)
        end, 1000, 0.02)
        Chk("T127", "H", "Speicher", function()
            local kb = 0
            if UpdateAddOnMemoryUsage and GetAddOnMemoryUsage then
                UpdateAddOnMemoryUsage()
                kb = GetAddOnMemoryUsage("AHSentinel") or 0
            end
            return true, string.format("AHSentinel %.0f KB", kb)
        end)
    end) end

    -- ---------------- I. Fehlerzählung ----------------
    if want(part, "i") then B(function()
        Chk("T128", "I", "Fehler in Ereignis-Zuhörer wird gemeldet", function()
            A:On("AHS_TEST_ERROR", function() error("AHS-Test T128") end)
            Capture(function() A:Fire("AHS_TEST_ERROR") end)
            A.listeners["AHS_TEST_ERROR"] = nil
            local e = ErrorEntry("Fire:AHS_TEST_ERROR")
            self:ClearTestErrors()
            return e ~= nil, e and "Eintrag da" or "kein Eintrag", "Eintrag in gsTest.errors"
        end)
        Chk("T130", "I", "Verkaufs-Meldung: Fehler gemeldet statt verschluckt", function()
            local Se = A.Seller
            local real = Se.OnSold
            Se.OnSold = function() error("AHS-Test T130") end
            local pat = ERR_AUCTION_SOLD_S and ERR_AUCTION_SOLD_S:gsub("%%s", "Leinenstoff")
            if pat then pcall(Se.saleFrame:GetScript("OnEvent"), Se.saleFrame, "CHAT_MSG_SYSTEM", pat) end
            Se.OnSold = real
            local e = ErrorEntry("Verkauft")
            self:ClearTestErrors()
            if not pat then return true, "ERR_AUCTION_SOLD_S fehlt" end
            return e ~= nil, e and "Eintrag da" or "kein Eintrag", "Eintrag \"Verkauft\""
        end)
        Chk("T132", "I", "blockierte Aktion wird gemeldet", function()
            local f = _G.GoldSentinelTestFrame
            if not f then return false, "GoldSentinelTestFrame fehlt" end
            f:GetScript("OnEvent")(f, "ADDON_ACTION_BLOCKED", "AHSentinel", "AHS-Test()")
            local okS = pcall(A.Sniper.OnEvent, A.Sniper, "ADDON_ACTION_BLOCKED", "AHSentinel", "AHS-Test()")
            local s = A.db.gsTest.errors
            local found
            for k in pairs(s) do if k:find("ADDON_ACTION_BLOCKED", 1, true) and k:find("AHS-Test", 1, true) then found = true end end
            self:ClearTestErrors()
            return found and okS, nil, "Eintrag, Sniper ohne Fehler"
        end)
    end)
        if want(part, "i") then
            -- unbehandelter Lua-Fehler: wartet auf den Fehler-Abgriff von GoldSentinelTest
            B(function()
                C_Timer.After(0, function() error("AHS-Test T131") end)
                return "WAIT", function() return ErrorEntry("Lua") ~= nil end, 3, function(timedOut)
                    local found = ErrorEntry("Lua") ~= nil
                    self:ClearTestErrors()
                    self:Check("T131", "I", "unbehandelter Lua-Fehler wird gezählt", function()
                        return found, found and "gezählt" or "nicht gezählt", "Eintrag \"Lua\" (BugSack/Fehler-Abgriff)"
                    end)
                end
            end)
        end
    end

    -- ---------------- J. Regressionstests ----------------
    if want(part, "j") then B(function()
        Chk("T133", "J", "Raid-Vorrat in Forever", function()
            if not (g and g.SetTestFlavor) then return true, "SetTestFlavor fehlt" end
            g.SetTestFlavor("forever")
            local k = A.Comfort:RaidSetKey()
            g.SetTestFlavor(nil)
            return k == "classic", tostring(k), "classic"
        end)
        Chk("T136", "J", "Favor-Kosten: Format stabil", function()
            for id, c in pairs(A.db.vendorCost or {}) do
                if type(c) ~= "table" or type(c.costs) ~= "table" or c.gold == nil or c.qty == nil then
                    return false, "Eintrag " .. tostring(id), "{ gold, qty, costs, t }"
                end
                return A:GetVendorCost(id) == c, nil, "GetVendorCost = gespeicherte Tabelle"
            end
            return true, "keine Favor-Kosten gespeichert (Format über T18 geprüft)"
        end)
        Chk("T137", "J", "Artikelanzahl über C_MerchantFrame", function()
            local cmf = { GetNumItems = function() return 1 end, GetItemInfo = function() return { price = 50, stackCount = 1, numAvailable = -1 } end }
            A.apiOverride = { GetMerchantNumItems = false, C_MerchantFrame = cmf, GetMerchantItemLink = function() return "item:" .. (FAKE + 20) end }
            local ok, n = pcall(A.ScanMerchant, A)
            A.apiOverride = nil
            local v = A.db.vendorBuy[FAKE + 20]
            A.db.vendorBuy[FAKE + 20] = nil
            return ok and n == 1 and v == 50, tostring(n) .. "/" .. tostring(v), "1/50"
        end)
        Chk("T139", "J", "Sniper ADDON_ACTION_BLOCKED", function()
            local Sn = A.Sniper
            local inst, pend = Sn.instantFailed, Sn.pending
            local db = A.db.sniper
            local instantSetting = db and db.instantBuy
            Sn.pending = { auto = true, itemID = FAKE }
            local ok, err = pcall(Sn.OnEvent, Sn, "ADDON_ACTION_BLOCKED", "AHSentinel", "C_AuctionHouse.StartCommoditiesPurchase()")
            local p = Sn.pending
            Sn.instantFailed, Sn.pending = inst, pend
            if db then db.instantBuy = instantSetting end
            if not ok then error(err, 0) end
            return p == nil, tostring(p), "pending nil"
        end)
        Chk("T140", "J", "Wächter-Pause wirkt (moderner Weg)", function()
            local W = A.Watcher
            local saved, legacy, drop, hold = A.db.lastScanTime, A.AH_LEGACY, A.lastThrottleDrop, W.holdForScan
            A.AH_LEGACY = false
            A.db.lastScanTime = 0
            W.holdForScan = nil
            W:OnThrottleDrop()
            local h1 = W:HoldingForScan()
            A.db.lastScanTime = time()
            local h2 = W:HoldingForScan()
            A.AH_LEGACY, A.db.lastScanTime, A.lastThrottleDrop, W.holdForScan = legacy, saved, drop, hold
            return h1 == true and h2 == false, tostring(h1) .. "/" .. tostring(h2), "true/false"
        end)
        Chk("T141", "J", "Pause ändert altes AH nicht", function()
            local W = A.Watcher
            local saved, legacy, hold = A.db.lastScanTime, A.AH_LEGACY, W.holdForScan
            A.AH_LEGACY = true
            A.db.lastScanTime = 0
            W.holdForScan = nil
            W:OnThrottleDrop()
            local h = W.holdForScan
            A.AH_LEGACY, A.db.lastScanTime, W.holdForScan = legacy, saved, hold
            return h == nil, tostring(h ~= nil), "keine Pause"
        end)
        if not A.AH_LEGACY then
            Cli("T142", "J", "Scan nicht vom Wächter blockiert", "Forever: Wächter an, Scan fällig -> /ahs scan startet den Scan")
            Cli("T138", "J", "Wächter und Server-Limit", "Forever: Wächter 2–3 Runden, dann /ahs scan: startet der Scan?")
        else
            Skp("T142", "J", "Scan nicht vom Wächter blockiert", "nur moderner Client")
        end
        Skp("T144", "J", "CurseForge Forever-Tag", "betrifft curseforge/upload.py im raidmaster-Repo, nicht das Addon – prüft die Prüf-Sitzung im Workflow")
        Chk("T145", "J", "Raid-Liste: alle Item-IDs vorhanden", function()
            local miss = {}
            local exists = (C_Item and C_Item.DoesItemExistByID) or (GetItemInfoInstant and function(id) return GetItemInfoInstant(id) ~= nil end)
            if not exists then return true, "keine Prüffunktion im Client" end
            for _, e in ipairs(A.Comfort.RAID_SETS.classic) do
                if not exists(e[1]) then miss[#miss + 1] = tostring(e[1]) end
            end
            return #miss == 0, #miss == 0 and "alle vorhanden" or table.concat(miss, ", "), "alle vorhanden"
        end)
        if A:IsForever() then
            Cli("T145", "J", "Raid-Vorrat passt zu Forever", "Passen die Schutztränke zu Barrow Deeps, Hyjalgipfel, Onyxia? (Punkt 5 nach dem Launch)")
            Cli("T149", "J", "Händler-Währungsfunktionen", "/dump GetMerchantItemCostInfo, /dump GetMerchantItemCostItem – fehlen sie, liest das Addon keine Favor-Kosten")
            Cli("T151", "J", "Interface-Nummer", "/dump select(4, GetBuildInfo()) – ist es nicht 16001, neue Nummer in AHSentinel.toc ergänzen")
        end
        Chk("T150", "J", "Erkennung über GoldSentinelGame", function()
            local prev = A.forceForever
            A.forceForever = nil
            local follows = (A:IsForever() == (g and g.IsForever == true))
            A.forceForever = true; local t = A:IsForever()
            A.forceForever = false; local f = A:IsForever()
            A.forceForever = prev
            return follows and t == true and f == false, nil, "folgt G.IsForever, Schalter gewinnt"
        end)
        -- neu ab 0.65.6
        Chk("T153", "J", "Scan-Start scheitert dauerhaft: höchstens 2 Chatzeilen, Wächter läuft weiter", function()
            local proxy = A.AH
            if not (ST.realAH and getmetatable(proxy)) then return false, "Handels-Proxy fehlt" end
            local W = A.Watcher
            local saved = { last = A.db.lastScanTime, legacy = A.AH_LEGACY, open = A.ahOpen, hold = W.holdForScan, round = W.round,
                start = A.StartFullScan, lastQ = A.pace.last, errs = A.pace.errors, gap = A.pace.gap }
            proxy.SendBrowseQuery = function() error("AHS-Test SendBrowseQuery") end
            proxy.IsThrottledMessageSystemReady = function() return true end
            A.AH_LEGACY, A.ahOpen, A.db.lastScanTime, W.holdForScan, W.round = false, true, 0, nil, nil
            A.StartFullScan = ST.origScan or A.StartFullScan
            local lines, res = {}, {}
            local ok, err = pcall(function()
                lines = Capture(function()
                    A:StartFullScan()
                    if A.scanWishTicker then A.scanWishTicker:Cancel(); A.scanWishTicker = nil end
                    for i = 1, 10 do
                        A.scanWishNext = 0
                        if A.scanWanted then A:TryWantedScan() end
                        if A.scanWishTicker then A.scanWishTicker:Cancel(); A.scanWishTicker = nil end
                    end
                end)
                res.wanted, res.hold = A.scanWanted, W:HoldingForScan()
            end)
            if A.DropScanWish then A:DropScanWish(false) end
            proxy.SendBrowseQuery, proxy.IsThrottledMessageSystemReady = nil, nil
            A.db.lastScanTime, A.AH_LEGACY, A.ahOpen, W.holdForScan, W.round = saved.last, saved.legacy, saved.open, saved.hold, saved.round
            A.StartFullScan = saved.start
            A.pace.last, A.pace.errors, A.pace.gap = saved.lastQ, saved.errs, saved.gap
            if not ok then error(err, 0) end
            return #lines <= 2 and res.wanted == nil and res.hold == false,
                string.format("%d Chatzeilen, Wunsch %s, Wächter-Pause %s", #lines, tostring(res.wanted ~= nil), tostring(res.hold)),
                "<= 2 Zeilen, Wunsch verworfen, keine Pause"
        end)
        Chk("T154", "J", "15-Minuten-Pause während eines Scan-Wunschs", function()
            local W = A.Watcher
            local hold = W.holdForScan
            W.holdForScan = nil
            W:HoldForScan(120)
            local m1 = W.holdForScan and W.holdForScan.max
            W:HoldForScan()
            local m2 = W.holdForScan and W.holdForScan.max
            W.holdForScan = hold
            return m1 == 120 and m2 == nil, tostring(m1) .. " -> " .. tostring(m2), "120 -> nil (15 Min.)"
        end)
        Chk("T155", "J", "Rezept-Auswahl im Berufsfenster: Ereignisname", function()
            local Cr = A.Crafting
            local nameOK = Cr.RECIPE_SELECTED_EVENT == "ProfessionsRecipeListMixin.Event.OnRecipeSelected"
            local hooked = (not (EventRegistry and EventRegistry.RegisterCallback)) or Cr.selectionHooked == true
            local before = Cr.lastModernRecipe
            Cr:OnRecipeSelected({ recipeID = 123456 })
            local got = Cr.lastModernRecipe
            Cr.lastModernRecipe = before
            return nameOK and hooked and got == 123456, string.format("Name %s, angemeldet %s", tostring(nameOK), tostring(hooked)), "ja, ja"
        end)
        if modern then
            Cli("T155", "J", "Rezept-Auswahl (Forever)", "Rezept im Blizzard-Berufsfenster wählen -> /dump AHAnalyzerPro.Crafting.lastModernRecipe zeigt dessen ID")
        end
    end) end

    -- ---------------- Halbautomatische Teile ----------------
    if part == "server" then
        if not A:IsAHOpen() then
            B(function() Skp("S00", "B", "Teil server", "Auktionshaus nicht offen - erst öffnen, dann /ahs testroutine server") end)
        else
            self:AddOldSteps(false)
        end
    elseif part == "haendler" then
        B(function()
            if not MerchantOpen() then return Skp("T19", "B", "Händler echt", "Händlerfenster nicht offen") end
            Chk("T19", "B", "Händler echt", function()
                local n = A:ScanMerchant()
                return n > 0, tostring(n), "> 0"
            end)
            Chk("T135", "J", "Händler-Einkaufspreise", function()
                return Count(A.db.vendorBuy) > 0, tostring(Count(A.db.vendorBuy)), "> 0"
            end)
        end)
    elseif part == "berufe" then
        B(function()
            local Cr = A.Crafting
            if not Cr.kind then return Skp("T64", "B", "Berufsfenster echt", "Berufsfenster nicht offen") end
            Chk("T64", "B", "Berufsfenster echt", function()
                local n = Cr:Remember(Cr.kind)
                return (n or 0) > 0, tostring(Cr.kind) .. ", " .. tostring(n) .. " Rezepte", "> 0"
            end)
            if modern then
                Chk("T134", "J", "Berufsfenster in Forever nicht leer", function()
                    return Cr:TradeKind() == "modern", Cr:TradeKind(), "modern"
                end)
            end
        end)
    elseif part == "post" then
        B(function()
            if not (MailFrame and MailFrame:IsShown()) then return Skp("T56", "B", "Post abholen", "Briefkasten nicht offen") end
            TM:SeedMail()
            Chk("T56", "B", "Post abholen (Test-Briefkasten)", function()
                return A.Mailer:HasAHMail() == true, nil, "Test-Post erkannt"
            end)
            Chk("T58", "B", "Post an Twinks simuliert", function()
                local ok = pcall(A.Extras.MailPlan, A.Extras)
                return ok and (self.real.SendMail or 0) == 0, nil, "Plan ohne Fehler, SendMail 0"
            end)
        end)
    elseif part == "gildenbank" then
        B(function()
            local K = A.Comfort
            if not (K.GuildBankSupported and K:GuildBankSupported()) then return Skp("T67", "B", "Gildenbank", "nicht unterstützt") end
            Chk("T67", "B", "Gildenbank", function()
                local ok = K:ScanGuildBank()
                return ok, nil, "gelesen"
            end)
        end)
    elseif part == "kampf" then
        B(function()
            local s = A.db.gsTest and A.db.gsTest.errors
            local n = 0
            for _ in pairs(s or {}) do n = n + 1 end
            Chk("T158", "C", "Fehler aus dem letzten Kampf", function()
                return n == 0, n .. " Fehlerarten seit dem letzten Bericht", "0"
            end)
        end)
    end
end
