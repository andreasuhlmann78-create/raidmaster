-- ============================================================
-- AH Analyzer Pro 0.60.2 - Selbsttest im Spiel
-- Prüft alle Funktionen mit echten Daten aus dem Auktionshaus:
--   Scan (falls nötig), Marktdaten, alle Reiter, Auswertungen, echte Suchen
--   (Einkauf, Preisprüfung, Sniper, Wächter, eigene Auktionen).
-- Sicher: Während des Tests sind Kaufen, Bieten, Einstellen und Abbrechen gesperrt.
-- Einstellungen, Sniper-Ziele und Schalter werden danach wiederhergestellt.
-- Start: Optionen -> Selbsttest, oder /ahp test
-- Ergebnis: Fenster mit allen Prüfungen, Chat-Zusammenfassung, gespeichert in
--   AHAnalyzerProDB.selftest (WTF\Account\...\SavedVariables\AHAnalyzerPro.lua)
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local ST = {}
A.SelfTest = ST

ST.SCAN_FRESH = 20 * 60        -- jüngerer Scan wird wiederverwendet
ST.SCAN_TIMEOUT = 15 * 60      -- so lange höchstens auf den Scan warten
ST.QUERY_TIMEOUT = 45          -- Server-Suchen
ST.running = false

local function Now() return GetTime() end
local function short(v) local s = tostring(v); if #s > 300 then s = s:sub(1, 297) .. "..." end return s end

-- ------------------------------------------------------------
-- Schutz: Kaufen, Bieten, Einstellen, Abbrechen während des Tests sperren
-- ------------------------------------------------------------
local BLOCK = {
    { "Sniper", "Buy" }, { "Sniper", "Reserve" }, { "Sniper", "Confirm" },
    { "Buy", "BuyItem" }, { "Buy", "PlaceBid" }, { "Buy", "StartCommodity" }, { "Buy", "ConfirmCommodity" },
    { "Seller", "Post" }, { "Seller", "Cancel" }, { "Seller", "BatchStep" }, { "Seller", "CancelNextUndercut" },
}

function ST:Lock()
    self.saved = {}
    for _, b in ipairs(BLOCK) do
        local mod = A[b[1]]
        if mod and type(mod[b[2]]) == "function" then
            self.saved[b] = mod[b[2]]
            mod[b[2]] = function() return false, L["Selbsttest läuft - Kaufen und Einstellen sind gesperrt."] end
        end
    end
end

function ST:Unlock()
    for b, fn in pairs(self.saved or {}) do A[b[1]][b[2]] = fn end
    self.saved = nil
end

-- Zustand sichern / wiederherstellen
function ST:SaveState()
    local s = {}
    s.armed = A.Sniper and A.Sniper:IsArmed()
    s.watcher = A.Watcher and A.Watcher:IsEnabled()
    s.targets = {}
    for k, v in pairs(A.db.sniper and A.db.sniper.targets or {}) do s.targets[k] = v end
    s.tab = A.UI.activeTab
    s.uiShown = A.UI:IsVisible()
    s.lastSub = {}
    for k, v in pairs(A.db.settings.lastSub or {}) do s.lastSub[k] = v end
    s.lastTab = A.db.settings.lastTab
    self.state = s
end

function ST:RestoreState()
    local s = self.state
    if not s then return end
    pcall(function()
        if A.Sniper then
            A.db.sniper.targets = s.targets
            A.Sniper.result = nil
            if A.Sniper:IsArmed() ~= s.armed then A.Sniper:SetArmed(s.armed) end
        end
        if A.Watcher and A.Watcher:IsEnabled() ~= s.watcher then A.Watcher:SetEnabled(s.watcher) end
        if A.Buy and A.Buy.detail then A.Buy:Back() end
        A.db.settings.lastSub = s.lastSub
        A.db.settings.lastTab = s.lastTab
        if A.UI.chartWin then A.UI.chartWin:Hide() end
        if A.UI.listsWindow then A.UI.listsWindow:Hide() end
        if A.UI.options then A.UI.options:Hide() end
        if A.UI.helpWindow then A.UI.helpWindow:Hide() end
        if s.tab then A.UI:SelectTab(s.tab) end
        A:Fire("SNIPER_CHANGED")
    end)
    self.state = nil
end

-- ------------------------------------------------------------
-- Ergebnisse
-- ------------------------------------------------------------
function ST:Add(group, name, status, detail)
    table.insert(self.results, { group = group, name = name, status = status, detail = detail and short(detail) or "" })
    if self.window and self.window:IsShown() then self.window:Refresh() end
end

local function pass(detail) return "PASS", detail end
local function fail(detail) return "FAIL", detail end
local function skip(detail) return "SKIP", detail end

-- ------------------------------------------------------------
-- Hilfen für die Prüfungen
-- ------------------------------------------------------------
local function ScannedItems(n, filter)
    local out = {}
    for id in pairs(A.db.marketData) do
        local p, q = A:GetCurrent(id)
        if p and p > 0 and (not filter or filter(id, p, q)) then table.insert(out, id) end
    end
    table.sort(out, function(a, b) return (select(2, A:GetCurrent(a)) or 0) > (select(2, A:GetCurrent(b)) or 0) end)
    local res = {}
    for i = 1, math.min(n or #out, #out) do res[i] = out[i] end
    return res
end

local function SellableBagItem()
    local items = A.Seller and A.Seller:GetBagItems() or {}
    for _, e in ipairs(items) do
        if A:GetCurrent(e.itemID) then return e end
    end
    return items[1]
end

-- ------------------------------------------------------------
-- Schritte: { group, name, run = function() -> status, detail[, waitFn, timeout, checkFn] }
-- Liefert run eine Wartefunktion, wartet der Test darauf (höchstens timeout Sek.)
-- und ruft danach checkFn() -> status, detail auf.
-- ------------------------------------------------------------
function ST:Steps()
    local S = {}
    local function step(group, name, run) table.insert(S, { group = group, name = name, run = run }) end
    local ctx = {}
    self.ctx = ctx

    -- ---------- Grundlagen ----------
    step("Grundlagen", "Version und Client", function()
        local build = GetBuildInfo and select(4, GetBuildInfo()) or "?"
        return pass("v" .. A.version .. ", Interface " .. tostring(build) .. (A.AH_LEGACY and ", klassisches AH" or ", modernes AH")
            .. ", Sprache " .. tostring(GetLocale and GetLocale()))
    end)
    step("Grundlagen", "Auktionshaus offen", function()
        if A:IsAHOpen() then return pass() end
        if self.savedMode then
            ctx.noAH = true
            return skip("nicht offen - Test mit gespeicherten Daten, Server-Suchen werden übersprungen")
        end
        ctx.abort = true
        return fail("Auktionshaus ist nicht offen - Test abgebrochen. Erst beim Auktionator das AH öffnen.")
    end)
    step("Grundlagen", "Server-Funktionen vorhanden", function()
        local need = { "SendBrowseQuery", "SendSearchQuery", "GetBrowseResults" }
        local miss = {}
        for _, f in ipairs(need) do if not (A.AH and A.AH[f]) then table.insert(miss, f) end end
        if #miss > 0 then return fail("fehlt: " .. table.concat(miss, ", ")) end
        return pass()
    end)

    -- ---------- Scan ----------
    step("Scan", "Markt-Scan", function()
        local age = A.db.lastScanTime and (time() - A.db.lastScanTime) or math.huge
        if self.savedMode then
            local n = A:CountTable(A.db.marketData)
            if n == 0 then
                ctx.abort = true
                return fail("keine gespeicherten Daten - erst einmal im Auktionshaus scannen")
            end
            return pass(string.format("gespeicherte Daten: %d Items, letzter Scan vor %s (kein neuer Scan)", n,
                A.db.lastScanTime and A:FormatDuration(age) or "?"))
        end
        if age <= self.SCAN_FRESH and A:CountTable(A.db.marketData) > 0 then
            return pass(string.format("vorhandener Scan von vor %d Min. wird benutzt", math.floor(age / 60)))
        end
        if not A:IsScanReady() then
            if A:CountTable(A.db.marketData) > 0 then
                return skip("Scan gesperrt (noch " .. A:FormatDuration(A:GetCooldownRemaining()) .. ") - ältere Daten werden benutzt")
            end
            ctx.abort = true
            return fail("Scan gesperrt und keine Daten - später nochmal testen")
        end
        local before = A.db.lastScanTime or 0
        if not A:StartFullScan() then return fail("Scan ließ sich nicht starten") end
        ctx.scanStart = Now()
        return "WAIT", nil, function() return not A:IsScanning() and (A.db.lastScanTime or 0) > before end, self.SCAN_TIMEOUT,
            function()
                local n = A:CountTable(A.db.marketData)
                return n > 0 and pass(string.format("%d Items in %d Sek.", n, math.floor(Now() - ctx.scanStart))) or fail("Scan ohne Ergebnis")
            end
    end)
    step("Scan", "Marktdaten plausibel", function()
        local n, withMV, neg, absurd = 0, 0, 0, 0
        for id in pairs(A.db.marketData) do
            n = n + 1
            local mv = A:GetMarketValue(id)
            local cur = A:GetCurrent(id)
            if mv then withMV = withMV + 1; if mv <= 0 then neg = neg + 1 end end
            if mv and cur and A:IsAbsurdProfit(cur, mv) then absurd = absurd + 1 end
        end
        if n == 0 then return fail("keine Items") end
        local d = string.format("%d Items, %d mit Marktwert, %d auffällig billig (werden ausgeblendet)", n, withMV, absurd)
        if neg > 0 then return fail(d .. ", " .. neg .. " Marktwerte <= 0") end
        if withMV == 0 then return fail(d) end
        return pass(d)
    end)

    -- ---------- Oberfläche ----------
    step("Oberfläche", "Fenster öffnen", function()
        A.UI:Show()
        return A.UI:IsVisible() and pass() or fail("Fenster nicht sichtbar")
    end)
    for _, g in ipairs(A.UI:Groups()) do
        for _, id in ipairs(g.tabs) do
            local tab = A.UI:GetTab(id)
            step("Oberfläche", "Reiter " .. L[g.label] .. (#g.tabs > 1 and (" -> " .. L[A.UI.SUBLABELS[id] or tab.label]) or ""), function()
                local panel = A.UI:SelectTab(id)
                if not panel then return fail("lädt nicht") end
                if A.UI.activeTab ~= id then return fail("anderer Reiter aktiv: " .. tostring(A.UI.activeTab)) end
                if panel.Refresh then
                    local ok, err = pcall(panel.Refresh, panel)
                    if not ok then return fail(err) end
                end
                return pass()
            end)
        end
    end
    step("Oberfläche", "Preisverlauf-Fenster", function()
        local id = ScannedItems(1)[1]
        if not id then return skip("kein Item") end
        local p = A.UI:OpenChart(id)
        if not (A.UI.chartWin and A.UI.chartWin:IsShown()) then return fail("Fenster nicht offen") end
        if p and p.selected ~= id then return fail("falsches Item") end
        A.UI.chartWin:Hide()
        return pass(A:GetItemName(id))
    end)
    step("Oberfläche", "Optionen, Hilfe, Einkaufslisten", function()
        A.UI:ShowOptions(); local o = A.UI.options and A.UI.options:IsShown(); if A.UI.options then A.UI.options:Hide() end
        A.UI:ShowHelp("start"); local h = A.UI.helpWindow and A.UI.helpWindow:IsShown(); if A.UI.helpWindow then A.UI.helpWindow:Hide() end
        A.UI:ShowLists(); local l = A.UI.listsWindow and A.UI.listsWindow:IsShown(); if A.UI.listsWindow then A.UI.listsWindow:Hide() end
        if o and h and l then return pass() end
        return fail(string.format("Optionen %s, Hilfe %s, Listen %s", tostring(o), tostring(h), tostring(l)))
    end)
    step("Oberfläche", "Knopf an der Minikarte", function()
        local b = A.FloatingButton
        if not b then return fail("fehlt") end
        if A.db.settings.minimapHide then return skip("ausgeblendet (Option)") end
        return b:IsShown() and pass() or fail("nicht sichtbar")
    end)

    -- ---------- Auswertungen ----------
    local function calc(name, fn)
        step("Auswertungen", name, function()
            local ok, a, b = pcall(fn)
            if not ok then return fail(a) end
            return pass(a)
        end)
    end
    calc("Marktliste", function() return #A:BuildItemList() .. " Einträge" end)
    calc("Suche nach Namen", function()
        local id = ScannedItems(1)[1]
        local name = id and A:GetClientItemName(id)
        if not name then return "kein Name" end
        local found = A:FindItemByName(name)
        if found ~= id then error("'" .. name .. "' -> " .. tostring(found)) end
        return name
    end)
    calc("Unter Händlerpreis", function() return #A:FindVendorDeals() .. " Funde" end)
    calc("Unter Entzauberwert", function() return #A.Disenchant:FindDeals() .. " Funde" end)
    calc("Gebote", function() return #A:GetBidDeals(30) .. " Funde" end)
    calc("Flips", function() return #A.Extras:GetFlipDeals(20) .. " Funde" end)
    calc("Vermögen", function() local r, t = A.Extras:InventoryValue(); return #r .. " Items, " .. A:FormatMoney(t.market) end)
    calc("Tagesbilanz", function() return A.Extras:DailyText():gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", "") end)
    calc("Buchhaltung", function() local s = A.Ledger:Summary("all"); local st = A.Ledger:Stats("all"); return (s.sales or 0) .. " Verkäufe, " .. #st.items .. " Items in der Statistik" end)
    calc("Händler-Verkauf (nur Liste)", function() local l, t = A.Extras:VendorCandidates(); return #l .. " Items, " .. A:FormatMoney(t) end)
    calc("Tooltip", function()
        local id = ScannedItems(1)[1]
        if not id then return "kein Item" end
        GameTooltip:SetOwner(UIParent, "ANCHOR_NONE")
        GameTooltip:ClearLines()
        A.Tooltip:AddLines(GameTooltip, id)
        local n = GameTooltip:NumLines()
        GameTooltip:Hide()
        if n < 2 then error("nur " .. n .. " Zeilen") end
        return n .. " Zeilen"
    end)
    calc("Übersetzungen", function()
        local miss = 0
        for k, v in pairs(A.L) do if type(v) ~= "string" then miss = miss + 1 end end
        return "Sprache " .. tostring(A.uiLang)
    end)

    -- ---------- Echte Suchen beim Server (nur bei offenem Auktionshaus) ----------
    local realStep = step
    local function step(group, name, run)
        realStep(group, name, function()
            if ctx.noAH or not A:IsAHOpen() then return skip("Auktionshaus nicht offen") end
            return run()
        end)
    end
    step("Server", "Einkauf: Kategorie-Suche", function()
        local B = A.Buy
        local ok, msg = B:Search({ text = "", cat = "trade" }, true)
        if not ok then return fail(msg) end
        ctx.buyStart = Now()
        return "WAIT", nil, function() return not B.search and not B.wanted end, self.QUERY_TIMEOUT,
            function()
                local n = #(B.results or {})
                return n > 0 and pass(string.format("%d Items in %.1f Sek.", n, Now() - ctx.buyStart)) or fail("keine Ergebnisse")
            end
    end)
    step("Server", "Einkauf: Angebote eines Items", function()
        local B = A.Buy
        local first = B.results and B.results[1]
        if not first then return skip("kein Item aus der Suche") end
        local ok, msg = B:Open(first.itemKey, first.name)
        if not ok then return fail(msg) end
        ctx.openStart = Now()
        return "WAIT", nil, function() return B.detail and not B.detail.loading end, self.QUERY_TIMEOUT,
            function()
                local d = B.detail
                local n = d and #(d.listings or {}) or 0
                B:Back()
                return n > 0 and pass(string.format("%s: %d Angebote in %.1f Sek.", first.name, n, Now() - ctx.openStart)) or fail("keine Angebote")
            end
    end)
    step("Server", "Verkaufen: Preisprüfung", function()
        local e = SellableBagItem()
        if not e then return skip("nichts Verkaufbares in den Taschen") end
        local Se = A.Seller
        ctx.sellItem = e
        ctx.sellStart = Now()
        Se:CheckPrice(e.itemID, true)
        return "WAIT", nil, function() return Se:IsPriceFresh(e.itemID) and Se:GetPriceInfo(e.itemID).time >= ctx.sellStart - 0.1 end, self.QUERY_TIMEOUT,
            function()
                local pr = Se:GetPriceInfo(e.itemID)
                local sug = Se:Suggest(e.itemID)
                return pass(string.format("%s: %d Angebote, Vorschlag %s (%.1f Sek.)", e.name or A:GetItemName(e.itemID),
                    #(pr.listings or {}), sug and A:FormatMoney(sug) or "-", Now() - ctx.sellStart))
            end
    end)
    step("Server", "Sniper: Suche (kauft nichts)", function()
        local Sn = A.Sniper
        local id = ScannedItems(1)[1]
        if not id then return skip("kein Item") end
        -- Ziel mit Max-Preis 1 Kupfer: findet Angebote, kauft aber nie
        local ok, msg = Sn:SetTarget(tostring(id), 1, 1, 1)
        if not ok then return fail(msg) end
        ctx.snKey = "i:" .. id
        ctx.snStart = Now()
        return "WAIT", nil, function()
            if Sn.result and Sn.result.key == ctx.snKey then return true end
            if not Sn:IsBusy() and not ctx.snSent then
                local okS = Sn:Search(ctx.snKey)
                if okS then ctx.snSent = true end
            end
            return false
        end, self.QUERY_TIMEOUT, function()
            local r = Sn.result
            local n = r and #(r.listings or {}) or 0
            local hit = Sn:HitWaiting()
            Sn:RemoveTarget(ctx.snKey)
            if hit then return fail("Treffer bei Max-Preis 1 Kupfer - darf nicht sein") end
            return pass(string.format("%s: %d Angebote gelesen, kein Treffer (%.1f Sek.)", A:GetItemName(id), n, Now() - ctx.snStart))
        end
    end)
    step("Server", "Wächter: eine Runde (kauft nichts)", function()
        local W = A.Watcher
        if #W:ActiveCategories() == 0 then return skip("keine Kategorie gewählt") end
        ctx.wRound = W.lastRound or 0
        ctx.wStart = Now()
        if not W:IsEnabled() then W:SetEnabled(true) end
        return "WAIT", nil, function() return (W.lastRound or 0) > ctx.wRound end, 120,
            function()
                local n = #(W:GetOpportunities() or {})
                return pass(string.format("Runde fertig in %.1f Sek., %d Schnäppchen gefunden", Now() - ctx.wStart, n))
            end
    end)
    step("Server", "Eigene Auktionen", function()
        local Se = A.Seller
        local before = Se.ownedTime or 0
        local ok, msg = Se:QueryOwned()
        if not ok then return fail(msg) end
        return "WAIT", nil, function() return (Se.ownedTime or 0) > before end, self.QUERY_TIMEOUT,
            function() return pass(#Se.owned .. " eigene Auktionen") end
    end)
    return S
end

-- ------------------------------------------------------------
-- Ablauf
-- ------------------------------------------------------------
-- saved = true: nur gespeicherte Daten (kein neuer Scan, Auktionshaus darf zu sein)
function ST:Start(saved)
    if self.running then A:Print(L["Selbsttest läuft schon ..."]); return false end
    if not A.db then return false end
    self.savedMode = saved and true or false
    self.running = true
    self.results = {}
    self.startTime = Now()
    self.startStamp = time()
    self:SaveState()
    self:Lock()
    -- Sniper-Modus und Wächter nicht dazwischenfunken lassen (Wächter wird gezielt getestet)
    if A.Sniper:IsArmed() then A.Sniper:SetArmed(false) end
    if A.Watcher:IsEnabled() then A.Watcher:SetEnabled(false) end
    self.steps = self:Steps()
    self.pos = 0
    self.wait = nil
    self:ShowWindow()
    if self.savedMode then
        A:Print(L["|cffffd100Selbsttest mit gespeicherten Daten gestartet|r - kein neuer Scan. Kaufen und Einstellen sind solange gesperrt."])
    else
        A:Print(L["|cffffd100Selbsttest gestartet|r - bitte das Auktionshaus offen lassen. Kaufen und Einstellen sind solange gesperrt."])
    end
    self:Next()
    return true
end

function ST:Next()
    while true do
        if self.ctx and self.ctx.abort then return self:Finish() end
        self.pos = self.pos + 1
        local s = self.steps[self.pos]
        if not s then return self:Finish() end
        self.current = s
        local ok, status, detail, waitFn, timeout, checkFn = pcall(s.run)
        if not ok then
            self:Add(s.group, s.name, "FAIL", status)
        elseif status == "WAIT" then
            self.wait = { fn = waitFn, untilT = Now() + (timeout or 30), check = checkFn, step = s }
            if self.window and self.window:IsShown() then self.window:Refresh() end
            return
        else
            self:Add(s.group, s.name, status or "PASS", detail)
        end
    end
end

function ST:Poll()
    local w = self.wait
    if not w then return end
    if not A:IsAHOpen() and (not self.savedMode or w.step.group == "Server") then
        self.wait = nil
        self:Add(w.step.group, w.step.name, "FAIL", "Auktionshaus wurde geschlossen")
        self.ctx.abort = true
        return self:Next()
    end
    local okW, done = pcall(w.fn)
    if okW and done then
        self.wait = nil
        local ok, status, detail = pcall(w.check)
        if ok then self:Add(w.step.group, w.step.name, status or "PASS", detail)
        else self:Add(w.step.group, w.step.name, "FAIL", status) end
        return self:Next()
    end
    if not okW or Now() > w.untilT then
        self.wait = nil
        self:Add(w.step.group, w.step.name, "FAIL", okW and "Zeitüberschreitung" or done)
        return self:Next()
    end
end

function ST:Counts()
    local c = { PASS = 0, FAIL = 0, SKIP = 0 }
    for _, r in ipairs(self.results or {}) do c[r.status] = (c[r.status] or 0) + 1 end
    return c
end

function ST:Finish()
    self.wait = nil
    self.running = false
    self:Unlock()
    self:RestoreState()
    local c = self:Counts()
    local secs = math.floor(Now() - (self.startTime or Now()))
    A.db.selftest = {
        time = self.startStamp, date = date("%Y-%m-%d %H:%M"), version = A.version,
        interface = GetBuildInfo and select(4, GetBuildInfo()) or nil, legacy = A.AH_LEGACY and true or false,
        locale = GetLocale and GetLocale(), seconds = secs, savedData = self.savedMode,
        pass = c.PASS, fail = c.FAIL, skip = c.SKIP, results = self.results,
    }
    local color = c.FAIL == 0 and "|cff33dd55" or "|cffff5544"
    A:Print(string.format(L["%sSelbsttest fertig:|r %d bestanden, %d fehlgeschlagen, %d übersprungen (%d Sek.)"], color, c.PASS, c.FAIL, c.SKIP, secs))
    for _, r in ipairs(self.results) do
        if r.status == "FAIL" then A:Print("|cffff5544FAIL|r " .. r.group .. " / " .. r.name .. ": " .. r.detail) end
    end
    if self.window then self.window:Refresh() end
end

function ST:Cancel()
    if not self.running then return end
    self:Add("Ablauf", "Abbruch", "SKIP", "von Hand abgebrochen")
    self.ctx.abort = true
    self:Finish()
end

-- Bericht als Text (zum Kopieren)
function ST:Report()
    local t = A.db.selftest
    if not t then return L["Noch kein Selbsttest gelaufen."] end
    local lines = {
        "AH Analyzer Pro - Selbsttest",
        string.format("Datum: %s   Version: %s   Interface: %s   %s   Sprache: %s   Dauer: %d Sek.",
            t.date or "?", t.version or "?", tostring(t.interface), t.legacy and "klassisches AH" or "modernes AH", tostring(t.locale), t.seconds or 0),
        string.format("Ergebnis: %d bestanden, %d fehlgeschlagen, %d übersprungen", t.pass or 0, t.fail or 0, t.skip or 0),
        t.savedData and "Modus: gespeicherte Daten (kein neuer Scan)" or "Modus: mit Scan / Live-Daten",
        "",
    }
    for _, r in ipairs(t.results or {}) do
        table.insert(lines, string.format("[%s] %s / %s%s", r.status, r.group, r.name, (r.detail ~= "" and (" - " .. r.detail) or "")))
    end
    return table.concat(lines, "\n")
end

-- ------------------------------------------------------------
-- Fenster
-- ------------------------------------------------------------
function ST:ShowWindow()
    local UI = A.UI
    local C = UI.C
    if not self.window then
        local w = UI:Dialog("AHAnalyzerProSelfTest", 840, 470, L["Selbsttest"])
        w.status = UI:Label(w, "", "GameFontHighlight", C.text)
        w.status:SetPoint("TOPLEFT", 16, -40)
        w.status:SetWidth(800)
        w.table = UI:Table(w, {
            columns = {
                { key = "status", title = L["Ergebnis"], width = 70 },
                { key = "name", title = L["Prüfung"], width = 260 },
                { key = "detail", title = L["Details"], width = 460 },
            },
            rows = 14, rowHeight = 20, noMenu = true, itemTooltip = false,
            cell = function(r, key)
                if key == "status" then
                    if r.status == "PASS" then return "|cff33dd55" .. L["bestanden"] .. "|r" end
                    if r.status == "FAIL" then return "|cffff5544" .. L["FEHLER"] .. "|r" end
                    if r.status == "RUN" then return "|cffffcc33" .. L["läuft ..."] .. "|r" end
                    return "|cff999999" .. L["übersprungen"] .. "|r"
                end
                if key == "name" then return r.group .. " / " .. r.name end
                return r.detail or ""
            end,
            -- Maus drüber: ganzer Text (falls die Spalte zu schmal ist)
            onHover = function(r)
                GameTooltip:SetOwner(UIParent, "ANCHOR_CURSOR")
                GameTooltip:SetText(r.group .. " / " .. r.name, 1, 1, 1, 1, true)
                if r.detail and r.detail ~= "" then GameTooltip:AddLine(r.detail, 0.9, 0.9, 0.9, true) end
                GameTooltip:Show()
            end,
            emptyText = L["Noch keine Ergebnisse."],
        })
        w.table:SetPoint("TOPLEFT", 14, -64)
        w.startBtn = UI:Button(w, L["Test starten"], 140, 26, function() ST:Start() end, "primary")
        w.startBtn:SetPoint("BOTTOMLEFT", 16, 14)
        w.savedBtn = UI:Button(w, L["Mit gespeicherten Daten"], 200, 26, function() ST:Start(true) end)
        w.savedBtn:SetPoint("LEFT", w.startBtn, "RIGHT", 6, 0)
        w.savedBtn.tooltip = L["Testet mit den schon gespeicherten Auktionshaus-Daten: kein neuer Scan,\ndas Auktionshaus darf zu sein (Server-Suchen werden dann übersprungen)."]
        w.stopBtn = UI:Button(w, L["Abbrechen"], 110, 26, function() ST:Cancel() end, "danger")
        w.stopBtn:SetPoint("LEFT", w.savedBtn, "RIGHT", 6, 0)
        w.copyBtn = UI:Button(w, L["Bericht kopieren"], 150, 26, function() UI:ShowTextWindow(L["Selbsttest"], ST:Report()) end)
        w.copyBtn:SetPoint("LEFT", w.stopBtn, "RIGHT", 6, 0)
        function w:Refresh()
            local rows = {}
            for _, r in ipairs(ST.results or {}) do table.insert(rows, r) end
            if ST.running and ST.current then
                table.insert(rows, { group = ST.current.group, name = ST.current.name, status = "RUN",
                                     detail = ST.wait and L["wartet auf den Server ..."] or "" })
            end
            self.table:SetData(rows, true)
            if #rows > self.table.numRows then
                self.table.offset = math.max(0, #rows - self.table.numRows)
                self.table:Render()
            end
            local c = ST:Counts()
            if ST.running then
                self.status:SetText(string.format(L["|cffffcc33Läuft ...|r  %d bestanden, %d Fehler, %d übersprungen - Auktionshaus offen lassen."], c.PASS, c.FAIL, c.SKIP))
            elseif A.db.selftest then
                local t = A.db.selftest
                self.status:SetText(string.format(L["Letzter Test %s: %s%d bestanden, %d Fehler|r, %d übersprungen (%d Sek.)"], t.date or "?",
                    (t.fail or 0) == 0 and "|cff33dd55" or "|cffff5544", t.pass or 0, t.fail or 0, t.skip or 0, t.seconds or 0))
            else
                self.status:SetText(L["Prüft alle Funktionen mit echten Daten. Auktionshaus öffnen, dann 'Test starten'.\nKaufen und Einstellen sind während des Tests gesperrt."])
            end
            self.startBtn:SetActive(not ST.running)
            self.savedBtn:SetActive(not ST.running)
            self.stopBtn:SetActive(ST.running)
        end
        w:SetScript("OnShow", function(self) self:Refresh() end)
        self.window = w
    end
    if not self.results and A.db.selftest then self.results = A.db.selftest.results end
    self.window:Show()
    self.window:Refresh()
    return self.window
end

local ticker = CreateFrame("Frame")
local acc = 0
ticker:SetScript("OnUpdate", function(_, dt)
    if not ST.running then return end
    acc = acc + (dt or 0)
    if acc < 0.25 then return end
    acc = 0
    ST:Poll()
    if ST.window and ST.window:IsShown() and ST.wait then ST.window:Refresh() end
end)
