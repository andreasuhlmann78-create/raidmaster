if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - MarketCore.lua (anweisung-markt-reiter, Teil F Stufe 1 "Vertrauen": MA2, MA1, MA3, Ü1–Ü3)
--
-- MA2 Empfehlungs-Protokoll: jede gezeigte Kauf-Empfehlung (Weg, Item, Preis, Vorhersage, Zeit) wird gespeichert und
--     nach Ablauf (24 Std.) mit dem Scan nachgeprüft: Treffer = Preis danach >= Kaufpreis (Kauf war nicht zu teuer),
--     Fehler = |Preis danach - Vorhersage| / Vorhersage. Je Weg: Fälle, Trefferquote, mittlerer Fehler (letzte 50).
--     Speicher klein: Zähler + letzte 200 offene Fälle. Freigabe (Teil D): >= 20 Fälle und >= 60 % -> frei, darunter
--     gesperrt (Protokoll "WEG GESPERRT"), < 20 Fälle -> "lernt noch".
-- MA1 Verkauf vs. Abbruch an den EIGENEN Auktionen (Wahrheit): verschwindet eine eigene Auktion mit langer Restzeit,
--     rät die Erkennung "verkauft", ausser dasselbe Item mit derselben Menge ist neu da ("neu eingestellt"). Die echte
--     Ursache (Verkauf / eigener Abbruch) kommt aus der Buchhaltung bzw. dem Abbrechen -> Fehlerquote.
-- MA3 Händlerpreis: Tabelle gegen das Spiel (A:GetVendorPrice zählt Abweichungen; Händler-Weg nur mit bestätigtem Preis).
-- Ü1 Testbericht-Abschnitt "MARKT-KERN"; Ü2 Grenzwerte; Ü3 Plausibilität.
-- Neue Tabelle db.core (ändert keine anderen Daten). Testroutine: MK.testDB.
-- ============================================================
AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local MK = {}
A.Core = MK

MK.CHECK_AFTER = 24 * 3600
MK.NOTE_GAP = 6 * 3600
MK.MAX_RECS = 200
MK.LAST = 50
MK.FREE_MIN = 20
MK.FREE_PCT = 0.60
MK.WAYS = { "flip", "snipe", "de", "craft", "vendor" }
MK.LONG = 2 * 3600

local function NewDB() return { v = 1, recs = {}, res = {}, err = {}, ma1 = { n = 0, wrong = 0 }, locked = {} } end
MK.NewDB = NewDB
local function Now() return MK.now or time() end
function MK:Store()
    if self.testDB then return self.testDB end
    if not A.db or A:Simulated() then return nil end
    if A.TestRoutine and A.TestRoutine.running then return nil end
    A.db.core = A.db.core or NewDB()
    local d = A.db.core
    d.recs, d.res, d.err, d.ma1, d.locked = d.recs or {}, d.res or {}, d.err or {}, d.ma1 or { n = 0, wrong = 0 }, d.locked or {}
    return d
end
function MK:Data() if self.testDB then return self.testDB end return A.db and A.db.core end

-- ------------------------------------------------------------
-- MA2
-- ------------------------------------------------------------
MK.notedAt = MK.notedAt or {}
function MK:Note(way, itemID, price, pred)
    local db = self:Store()
    if not (db and way and itemID and price and price > 0 and pred and pred > 0) then return false end
    local now = Now()
    local key = way .. ":" .. itemID
    if self.notedAt[key] and now - self.notedAt[key] < self.NOTE_GAP then return false end
    self.notedAt[key] = now
    db.recs[#db.recs + 1] = string.format("%s;%d;%d;%d;%d", way, itemID, now, math.floor(price), math.floor(pred))
    while #db.recs > self.MAX_RECS do table.remove(db.recs, 1) end
    return true
end
local function PriceBetween(itemID, from, to)
    for _, e in ipairs(A:GetHistory(itemID)) do
        if e.t >= from and e.t <= to and (not A.Usable or A.Usable(e)) and e.p and e.p > 0 then return e.p end
        if e.t > to then break end
    end
end
function MK:Resolve(now)
    local db = self:Store()
    if not db then return 0 end
    now = now or Now()
    local keep, n = {}, 0
    for _, s in ipairs(db.recs) do
        local way, id, t, price, pred = s:match("^(%a+);(%d+);(%d+);(%d+);(%d+)$")
        id, t, price, pred = tonumber(id), tonumber(t), tonumber(price), tonumber(pred)
        local done = false
        if t and now >= t + self.CHECK_AFTER then
            local q = PriceBetween(id, t + self.CHECK_AFTER - 3600, t + self.CHECK_AFTER + 6 * 3600)
            if q then
                local hit = q >= price
                local e = math.min(9.99, math.abs(q - pred) / pred)
                local r = (db.res[way] or "") .. (hit and "1" or "0")
                if #r > self.LAST then r = r:sub(-self.LAST) end
                db.res[way] = r
                local el = db.err[way] or {}
                el[#el + 1] = math.floor(e * 1000 + 0.5)
                while #el > self.LAST do table.remove(el, 1) end
                db.err[way] = el
                n, done = n + 1, true
            elseif now >= t + 2 * self.CHECK_AFTER then done = true end
        end
        if not done then keep[#keep + 1] = s end
    end
    db.recs = keep
    for _, w in ipairs(self.WAYS) do self:WayState(w) end
    return n
end
-- Fälle, Quote, mittlerer Fehler (Anteil)
function MK:Quote(way)
    local db = self:Data()
    local r = db and db.res and db.res[way] or ""
    local hit = 0
    for i = 1, #r do if r:sub(i, i) == "1" then hit = hit + 1 end end
    local el, sum = db and db.err and db.err[way] or {}, 0
    for _, v in ipairs(el) do sum = sum + v end
    return #r, #r > 0 and hit / #r or nil, #el > 0 and sum / #el / 1000 or nil
end
-- Teil D: "frei" / "gesperrt" / "lernt" (n von 20)
function MK:WayState(way)
    local n, q = self:Quote(way)
    if n < self.FREE_MIN then return "lernt", n end
    local db = self:Store() or self:Data()
    if q < self.FREE_PCT then
        if db and not db.locked[way] then
            db.locked[way] = true
            if A.Diag and not self.testDB then pcall(A.Diag.Add, A.Diag, "WEG GESPERRT", string.format("%s %d %%", way, math.floor(q * 100 + 0.5))) end
        end
        return "gesperrt", n
    end
    if db then db.locked[way] = nil end
    return "frei", n
end

-- Empfehlungen aus dem Markt-Reiter und dem Sniper notieren (nur gezeigte, je Item und Weg höchstens 1-mal je 6 Std.)
local VIEW_WAY = { flip = "flip", vendor = "vendor", de = "de", gaps = "flip", crowded = "flip" }
function MK:NoteRows(view, rows)
    local way = VIEW_WAY[view]
    if not way then return 0 end
    local n = 0
    for _, r in ipairs(rows or {}) do
        local buy = r.price or r.buy
        local pred = r.upto and (r.net or r.value or r.sell) or (r.sell or r.sellPrice or r.value or r.vendor)
        if r.itemID and buy and pred and self:Note(way, r.itemID, buy, pred) then n = n + 1 end
    end
    return n
end

-- ------------------------------------------------------------
-- MA1 (eigene Auktionen als Wahrheit)
-- ------------------------------------------------------------
MK.ownPrev, MK.guess = MK.ownPrev or {}, MK.guess or {}
local function Long(o)
    local tl = o.timeLeft
    if type(tl) ~= "number" then return false end
    if tl <= 4 then return tl >= 3 end              -- Blizzard-Stufen 1..4 (3 = 2–12 Std., 4 = > 12 Std.)
    return tl > MK.LONG                             -- Sekunden
end
function MK:OnOwned(list)
    local now, cur, newSig = Now(), {}, {}
    for _, o in ipairs(list or {}) do
        if o.auctionID and not o.sold then
            cur[o.auctionID] = o
            newSig[tostring(o.itemID) .. ":" .. tostring(o.qty)] = (newSig[tostring(o.itemID) .. ":" .. tostring(o.qty)] or 0) + 1
        end
    end
    for aid, o in pairs(self.ownPrev) do
        if not cur[aid] and Long(o) and not self.guess[aid] then
            local sig = tostring(o.itemID) .. ":" .. tostring(o.qty)
            local relist = (newSig[sig] or 0) > 0 and not self.ownPrev[aid].seenNew
            self.guess[aid] = { g = relist and "neu" or "verkauft", t = now }
        end
    end
    self.ownPrev = cur
end
function MK:Truth(aid, truth)
    local g = aid and self.guess[aid]
    local db = self:Store()
    if not (g and db) then return false end
    self.guess[aid] = nil
    local right = (g.g == "verkauft" and truth == "verkauft") or (g.g == "neu" and truth == "abgebrochen")
    db.ma1.n = db.ma1.n + 1
    if not right then db.ma1.wrong = db.ma1.wrong + 1 end
    return right
end
function MK:MA1Rate()
    local db = self:Data()
    local m = db and db.ma1
    if not (m and m.n > 0) then return 0, nil end
    return m.n, m.wrong / m.n
end
-- Absatz-Freigabe (Teil D): >= 30 eigene Fälle und Fehlerquote <= 20 %
function MK:SalesReleased()
    local n, r = self:MA1Rate()
    return n >= 30 and r and r <= 0.20 or false, n
end
A:On("OWN_AUCTION_SOLD", function(o) if o and o.auctionID then pcall(MK.Truth, MK, o.auctionID, "verkauft") end end)
A:On("AUCTION_CANCELLED", function(c) if c and c.auctionID then pcall(MK.Truth, MK, c.auctionID, "abgebrochen") end end)

-- ------------------------------------------------------------
-- Ü3 Plausibilität: Rückgabe nil oder Grund
-- ------------------------------------------------------------
function MK:Implausible(profitPct, salesPerHour, offerQty, productOffers)
    if profitPct and profitPct > 300 then return "Gewinn > 300 % – Daten prüfen" end
    if salesPerHour and offerQty and offerQty > 0 and salesPerHour > offerQty * 0.25 then return "Absatz > 25 % des Angebots je Stunde – unplausibel" end
    if productOffers and productOffers < 5 then return "dünner Markt (< 5 Angebote)" end
    return nil
end

-- ------------------------------------------------------------
-- Ü1/Ü2: Testbericht-Abschnitt "MARKT-KERN"
-- ------------------------------------------------------------
function MK:Report()
    local out = { "MARKT-KERN (Ü1):" }
    for _, w in ipairs(self.WAYS) do
        local n, q, e = self:Quote(w)
        local st = self:WayState(w)
        out[#out + 1] = string.format("  Weg %s: Fälle %d · Treffer %s · mittlerer Fehler %s · %s%s", w, n, q and string.format("%d %%", math.floor(q * 100 + 0.5)) or "-",
            e and string.format("%d %%", math.floor(e * 100 + 0.5)) or "-", st, (st == "frei" and q and q < 0.70) and " (unter Ziel 70 %)" or "")
        if st == "gesperrt" then out[#out + 1] = string.format("  Ü2 VERFEHLT: Weg %s Trefferquote unter 60 %%", w) end
        if st == "frei" and e and e > 0.15 then out[#out + 1] = string.format("  Ü2 VERFEHLT: Weg %s mittlerer Fehler über 15 %%", w) end
    end
    local n1, r1 = self:MA1Rate()
    out[#out + 1] = string.format("  MA1 eigene Auktionen geprüft %d · Fehlerquote %s%s", n1, r1 and string.format("%d %%", math.floor(r1 * 100 + 0.5)) or "-",
        (r1 and n1 >= 30 and r1 > 0.20) and " · Ü2 VERFEHLT (> 20 %)" or "")
    out[#out + 1] = string.format("  MA3 Händlerpreise vom Spiel bestätigt %d · abweichend von der Tabelle %d", A.vendorCheckedCount or 0, A.vendorDiffCount or 0)
    out[#out + 1] = "  MA4 Stufenbänder: messe noch (kommt mit dem Rechenkern)"
    local last = A.db and A.db.lastScanTime
    out[#out + 1] = string.format("  letzter Vollscan/Scan: %s", last and date("%d.%m. %H:%M", last) or "-")
    local db = self:Data()
    out[#out + 1] = string.format("  offene Empfehlungen %d", db and #(db.recs or {}) or 0)
    return out
end

-- Nachprüfen nach jedem Scan (klein, ohne Pause nötig: höchstens 200 Fälle)
A:On("SCAN_FINISHED", function()
    if (A.TestRoutine and A.TestRoutine.running) or not MK:Store() then return end
    pcall(MK.Resolve, MK)
end)
