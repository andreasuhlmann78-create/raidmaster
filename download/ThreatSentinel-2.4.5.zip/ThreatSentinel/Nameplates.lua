-- ThreatSentinel - Nameplates.lua
-- Darstellung an den Namensplaketten: gehaltene Mobs ausblenden (nur Lebensbalken),
-- lose Mobs mit leuchtendem, pulsierendem Rahmen hervorheben.
-- Funktioniert mit echten Plaketten und mit den Vorschau-Plaketten der Testzentrale.

local ADDON, ns = ...
local API = ns.API   -- Blizzard-Funktionen nur über ns.API (API.lua)
local L = ns.L

local P = {}
ns.Plates = P

local WHITE = "Interface\\Buttons\\WHITE8X8"
local overlays = {}   -- UnitFrame -> Overlay

-- Teile der Blizzard-Plakette, die bei gehaltenen Mobs abgeschwächt werden.
-- Raidmarkierung und Zauberbalken bleiben IMMER voll sichtbar (nicht in dieser Liste).
local HIDE_KEYS = {
	"name", "LevelFrame", "levelText", "BuffFrame",
	"ClassificationFrame", "classificationIndicator", "selectionHighlight",
	"aggroHighlight", "WidgetContainer", "eliteIcon",
}
local KEEP_KEYS = { "RaidTargetFrame", "castBar", "CastBar" }

local QUIET_GREY = { 0.6, 0.6, 0.6, 1 }

local function GetUF(unit)
	if not unit then return end
	local plate = API.C_NamePlate.GetNamePlateForUnit(unit)
	if not plate or (plate.IsForbidden and plate:IsForbidden()) then return end
	local uf = plate.UnitFrame
	if not uf or (uf.IsForbidden and uf:IsForbidden()) then return end
	-- neuere Clients: Lebensbalken im HealthBarsContainer
	if not uf.healthBar and uf.HealthBarsContainer and uf.HealthBarsContainer.healthBar then
		uf.healthBar = uf.HealthBarsContainer.healthBar
	end
	if not uf.healthBar then return end
	return uf
end

local function NewBorder(parent)
	local b = CreateFrame("Frame", nil, parent)
	b.t = {}
	for i = 1, 4 do
		local tx = b:CreateTexture(nil, "OVERLAY")
		tx:SetTexture(WHITE)
		b.t[i] = tx
	end
	return b
end

local function LayoutBorder(b, target, size)
	if b.size == size and b.target == target then return end
	b.size, b.target = size, target
	b:ClearAllPoints()
	b:SetPoint("TOPLEFT", target, "TOPLEFT", -size, size)
	b:SetPoint("BOTTOMRIGHT", target, "BOTTOMRIGHT", size, -size)
	local t = b.t
	t[1]:ClearAllPoints(); t[1]:SetPoint("TOPLEFT"); t[1]:SetPoint("TOPRIGHT"); t[1]:SetHeight(size)
	t[2]:ClearAllPoints(); t[2]:SetPoint("BOTTOMLEFT"); t[2]:SetPoint("BOTTOMRIGHT"); t[2]:SetHeight(size)
	t[3]:ClearAllPoints(); t[3]:SetPoint("TOPLEFT"); t[3]:SetPoint("BOTTOMLEFT"); t[3]:SetWidth(size)
	t[4]:ClearAllPoints(); t[4]:SetPoint("TOPRIGHT"); t[4]:SetPoint("BOTTOMRIGHT"); t[4]:SetWidth(size)
end

------------------------------------------------------------
-- Flammen um lose Plaketten (eigene Textur: 4 Bilder untereinander, abwechselnd gezeigt)
------------------------------------------------------------
local FIRE_TEX = "Interface\\AddOns\\" .. ADDON .. "\\Media\\fire"
local FIRE_FRAMES = 4
local fireSet = {}
local fireDriver = CreateFrame("Frame")
fireDriver:Hide()
local fireAcc, fireStep = 0, 0
fireDriver:SetScript("OnUpdate", function(_, elapsed)
	fireAcc = fireAcc + elapsed
	if fireAcc < 0.08 then return end
	fireAcc = 0
	fireStep = fireStep + 1
	for tex in pairs(fireSet) do
		local f = (fireStep + (tex.fireOffset or 0)) % FIRE_FRAMES
		tex:SetTexCoord(0, 1, f / FIRE_FRAMES, (f + 1) / FIRE_FRAMES)
		tex:SetAlpha((tex.baseAlpha or 1) * (0.8 + math.random() * 0.2))
	end
end)

-- Stärke der Effekte (Einstellung, 50-200 %, Standard 150 %)
local function Strength()
	return math.max(0.5, math.min(2, (ns.db and ns.db.effectStrength or 150) / 100))
end

local function BarSize(target)
	local ok, w, h = pcall(function() return target:GetWidth(), target:GetHeight() end)
	if not ok or type(w) ~= "number" or type(h) ~= "number" or ns.IsSecret(w) or ns.IsSecret(h) or w <= 0 or h <= 0 then
		return 110, 10
	end
	return w, h
end

-- Textur-Ränder (in Pixeln der Vorlage 256x64): links/rechts 24, oben 30, unten 14, Innenfläche 208x20
local function LayoutFire(tex, target)
	local w, h = BarSize(target)
	local k = Strength()
	if tex.fireW == w and tex.fireH == h and tex.fireK == k then return end
	tex.fireW, tex.fireH, tex.fireK = w, h, k
	local mx = w * 24 / 208 * k
	local top = math.max(12, h * 30 / 20) * k * 1.2
	local bot = math.max(5, h * 14 / 20) * k
	tex:ClearAllPoints()
	tex:SetPoint("TOPLEFT", target, "TOPLEFT", -mx, top)
	tex:SetPoint("BOTTOMRIGHT", target, "BOTTOMRIGHT", mx, -bot)
end

-- zwei Flammenschichten: normal + aufgehellt (ADD), gegeneinander versetzt
local function SetFire(o, target, on)
	for _, tex in ipairs(o.fires) do
		if on then
			LayoutFire(tex, target)
			if not fireSet[tex] then
				tex.fireOffset = math.random(0, FIRE_FRAMES - 1)
				fireSet[tex] = true
			end
			tex:Show()
		else
			tex:Hide()
			fireSet[tex] = nil
		end
	end
	if next(fireSet) then fireDriver:Show() else fireDriver:Hide() end
end

-- Leuchtrahmen (Vorlage 256x64, Innenfläche 192x16, Rand links/rechts 32, oben/unten 24)
local GLOW_TEX = "Interface\\AddOns\\" .. ADDON .. "\\Media\\glow"
local function LayoutGlow(tex, target, extra)
	local w, h = BarSize(target)
	local k = Strength() * (extra or 1)
	local key = w .. ":" .. h .. ":" .. k
	if tex.glowKey == key then return end
	tex.glowKey = key
	local mx = w * 32 / 192 * k
	local my = math.max(8, h * 24 / 16) * k
	tex:ClearAllPoints()
	tex:SetPoint("TOPLEFT", target, "TOPLEFT", -mx, my)
	tex:SetPoint("BOTTOMRIGHT", target, "BOTTOMRIGHT", mx, -my)
end

local function ColorBorder(b, c)
	for i = 1, 4 do b.t[i]:SetVertexColor(c[1], c[2], c[3], c[4] or 1) end
end

function P:SetElementsAlpha(uf, aOther, aHealth)
	for _, k in ipairs(HIDE_KEYS) do
		local r = uf[k]
		if type(r) == "table" and r.SetAlpha then r:SetAlpha(aOther) end
	end
	uf.healthBar:SetAlpha(aHealth)
	for _, k in ipairs(KEEP_KEYS) do
		local r = uf[k]
		if type(r) == "table" and r.SetAlpha then r:SetAlpha(1) end
	end
end

-- Erster Buchstabe eines Namens (auch bei Umlauten)
local function Initial(name)
	if ns.IsSecret(name) or not name or name == "" then return "" end
	local c = name:match("^[%z\1-\127\194-\244][\128-\191]*") or name:sub(1, 1)
	return c:upper()
end
P._Initial = Initial   -- Test-Zugang (Testroutine)

function P:GetOverlay(uf)
	local o = overlays[uf]
	if o then return o end
	o = CreateFrame("Frame", nil, uf)
	o:SetAllPoints(uf.healthBar)
	o:SetFrameLevel(uf.healthBar:GetFrameLevel() + 5)

	-- Leuchten (orange = bald Aggro, rot = Aggro bei einem Spieler), blinkt / pulsiert
	o.glow = o:CreateTexture(nil, "BACKGROUND", nil, -2)
	o.glow:SetTexture(GLOW_TEX)
	o.glow:SetBlendMode("ADD")
	o.glow:Hide()
	o.glowAG = o.glow:CreateAnimationGroup()
	o.glowAG:SetLooping("BOUNCE")
	o.glowAnim = o.glowAG:CreateAnimation("Alpha")
	o.glowAnim:SetFromAlpha(1)
	o.glowAnim:SetToAlpha(0.2)
	o.glowAnim:SetDuration(0.4)

	-- Flammen: zwei Schichten
	o.fires = {}
	for i = 1, 2 do
		local f = o:CreateTexture(nil, "BACKGROUND", nil, i == 1 and -1 or 0)
		f:SetTexture(FIRE_TEX)
		f:SetTexCoord(0, 1, 0, 1 / FIRE_FRAMES)
		f:SetBlendMode(i == 1 and "BLEND" or "ADD")
		f.baseAlpha = (i == 1) and 1 or 0.7
		f:Hide()
		o.fires[i] = f
	end
	o.fire = o.fires[1]

	-- Druckwelle beim Wechsel auf bald Aggro / Aggro weg
	o.burst = o:CreateTexture(nil, "OVERLAY", nil, 7)
	o.burst:SetTexture(GLOW_TEX)
	o.burst:SetBlendMode("ADD")
	o.burst:SetAlpha(0)
	o.burstAG = o.burst:CreateAnimationGroup()
	local bs = o.burstAG:CreateAnimation("Scale")
	if bs.SetScaleFrom then bs:SetScaleFrom(1, 1); bs:SetScaleTo(1.9, 2.6) else bs:SetScale(1.9, 2.6) end
	bs:SetDuration(0.55)
	if bs.SetOrigin then bs:SetOrigin("CENTER", 0, 0) end
	local ba = o.burstAG:CreateAnimation("Alpha")
	ba:SetFromAlpha(1)
	ba:SetToAlpha(0)
	ba:SetDuration(0.55)
	o.burstAG:SetScript("OnFinished", function() o.burst:SetAlpha(0) end)

	o.border = NewBorder(o)
	o.pulse = o.border:CreateAnimationGroup()
	o.pulse:SetLooping("BOUNCE")
	o.pulseAnim = o.pulse:CreateAnimation("Alpha")
	o.pulseAnim:SetFromAlpha(1)
	o.pulseAnim:SetToAlpha(0.25)
	o.pulseAnim:SetDuration(0.5)

	o.flash = o:CreateTexture(nil, "OVERLAY")
	o.flash:SetTexture(WHITE)
	o.flash:SetAllPoints(uf.healthBar)
	o.flash:SetAlpha(0)
	o.flashAG = o.flash:CreateAnimationGroup()
	local fa = o.flashAG:CreateAnimation("Alpha")
	fa:SetFromAlpha(0.8)
	fa:SetToAlpha(0)
	fa:SetDuration(0.7)
	o.flashAG:SetScript("OnFinished", function() o.flash:SetAlpha(0) end)

	o.text1 = o:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	o.text1:SetPoint("TOP", uf.healthBar, "BOTTOM", 0, -3)
	o.text2 = o:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	o.text2:SetPoint("TOP", o.text1, "BOTTOM", 0, -1)

	o.stripe = o:CreateTexture(nil, "OVERLAY")
	o.stripe:SetTexture(WHITE)
	o.stripe:SetWidth(4)
	o.stripe:SetPoint("TOPRIGHT", uf.healthBar, "TOPLEFT", -2, 0)
	o.stripe:SetPoint("BOTTOMRIGHT", uf.healthBar, "BOTTOMLEFT", -2, 0)
	o.stripe:Hide()

	-- Kürzel des zuständigen Tanks (Tank-Sync), z. B. "G" für Grimbar
	o.tag = o:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	o.tag:SetPoint("RIGHT", uf.healthBar, "LEFT", -8, 0)
	o.tag:Hide()

	o.sunderIcon = o:CreateTexture(nil, "OVERLAY")
	o.sunderIcon:SetSize(12, 12)
	o.sunderIcon:SetPoint("LEFT", uf.healthBar, "RIGHT", 3, 0)
	o.sunderIcon:SetTexture(ns.SpellIcon(7386) or "Interface\\Icons\\Ability_Warrior_Sunder")
	o.sunderIcon:Hide()
	o.sunderText = o:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall")
	o.sunderText:SetPoint("LEFT", o.sunderIcon, "RIGHT", 1, 0)
	o.sunderText:Hide()

	overlays[uf] = o
	return o
end

------------------------------------------------------------
-- Zurücksetzen / Aufblinken
------------------------------------------------------------
function P:RestoreFrame(uf)
	if not uf then return end
	-- nie veränderte Plaketten nicht anfassen
	local o = overlays[uf]
	if not o then return end
	self:SetElementsAlpha(uf, 1, 1)
	o.pulse:Stop()
	o.pulseDur, o.pulseTo = nil, nil
	SetFire(o, uf.healthBar, false)
	o.glowAG:Stop(); o.glow:Hide(); o.glowDur = nil
	o.lastSt = nil
	o:Hide()
	if o.scaled then uf:SetScale(o.origScale or 1); o.scaled = false; o.scaleFactor = nil end
	if o.raised then
		if o.origStrata then uf:SetFrameStrata(o.origStrata) end
		o.raised = false
	end
end

function P:Restore(unit)
	-- moderne API, Modus ANZEIGE / AUS, im Kampf: Blizzards Plakette nicht anfassen
	if ns.isModern and ns:ThreatMode() ~= "FULL" and (API.InCombatLockdown() or API.UnitAffectingCombat("player")) then
		return self:Detach(unit)
	end
	self:RestoreFrame(GetUF(unit))
end

-- Modus ANZEIGE / AUS (WoW Forever): nur die eigenen Anzeigen ausblenden. Blizzards Plaketten werden im
-- Kampf nicht angefasst (kein SetAlpha / SetScale / SetFrameStrata) - erst nach dem Kampf zurückgesetzt.
P.pendingRestore = {}
function P:Detach(unit)
	local uf = GetUF(unit)
	if not uf then return end
	if not API.InCombatLockdown() and not API.UnitAffectingCombat("player") then
		self:RestoreFrame(uf)
		return
	end
	local o = overlays[uf]
	if o then
		o.pulse:Stop()
		o.pulseDur, o.pulseTo = nil, nil
		SetFire(o, uf.healthBar, false)
		o.glowAG:Stop(); o.glow:Hide(); o.glowDur = nil
		o.lastSt = nil
		o:Hide()
	end
	self.pendingRestore[uf] = true
end

ns:On("PLAYER_REGEN_ENABLED", function()
	for uf in pairs(P.pendingRestore) do
		local ok, err = pcall(P.RestoreFrame, P, uf)
		if not ok then ns:TestError("Nameplates.RestoreFrame", err) end
	end
	wipe(P.pendingRestore)
end)

function P:FlashFrame(uf)
	if not uf then return end
	local o = self:GetOverlay(uf)
	local c = ns.db.colorRegain
	o.flash:SetVertexColor(c[1], c[2], c[3], 1)
	o.flashAG:Stop()
	o.flash:SetAlpha(0.8)
	o.flashAG:Play()
	o:Show()
end

function P:Flash(unit)
	self:FlashFrame(GetUF(unit))
end

------------------------------------------------------------
-- Tatsächlicher Zustand einer Plakette (für das Testprotokoll; liest nur)
------------------------------------------------------------
function P:Inspect(unit)
	local uf = GetUF(unit)
	if not uf then return nil end
	local o = overlays[uf]
	local info = {}
	local function g(fn) local ok, v = pcall(fn) if ok then return v end end
	info.alpha = uf.name and g(function() return uf.name:GetAlpha() end)
	info.hpAlpha = g(function() return uf.healthBar:GetAlpha() end)
	info.scale = g(function() return uf:GetScale() end)
	info.effScale = g(function() return uf:GetEffectiveScale() end)
	info.strata = g(function() return uf:GetFrameStrata() end)
	info.shown = g(function() return uf:IsShown() end)
	info.visible = g(function() return uf:IsVisible() end)
	local rt = uf.RaidTargetFrame
	info.markAlpha = rt and g(function() return rt:GetAlpha() end)
	local mk = API.GetRaidTargetIndex and g(function() return API.GetRaidTargetIndex(unit) end)
	info.mark = mk
	local cb = uf.castBar or uf.CastBar
	info.castAlpha = cb and g(function() return cb:GetAlpha() end)
	if o and o:IsShown() then
		info.border = o.border:IsShown()
		if info.border then
			local r, gg, b = o.border.t[1]:GetVertexColor()
			info.borderRGB = { r, gg, b }
		end
		info.pulse = o.pulse:IsPlaying()
		info.fire = o.fire:IsShown()
		info.glow = o.glow:IsShown()
		if o.scaled then info.want = (o.origScale or 1) * (o.scaleFactor or 1) end
		info.flash = o.flashAG:IsPlaying()
		info.hint = o.text2:GetText()
		info.tag = o.tag:IsShown() and o.tag:GetText() or nil
	else
		info.border, info.pulse, info.flash = false, false, false
	end
	return info
end

------------------------------------------------------------
-- Darstellung
------------------------------------------------------------
function P:Update(unit, m)
	local uf = GetUF(unit)
	if uf then self:Apply(uf, m) end
end

function P:Apply(uf, m)
	local db = ns.db
	local o = self:GetOverlay(uf)
	local st = m.state

	local borderColor, borderSize, pulseDur
	local pulseTo = 0.25
	local fire = false
	local glowColor, glowDur
	local wantScale, wantRaise = false, false
	local text1, text1Color, text2 = "", nil, ""
	local stripeColor
	local tagName
	local overlayAlpha = 1
	local scaleFactor = 1

	-- Gruppen-Ansicht (DD / Heiler): Mobs beim Tank bleiben normal (man muss sie anvisieren können),
	-- nur Gefahr wird hervorgehoben (bald Aggro = orange, Aggro bei einem Spieler = rot)
	local member = ns.memberNow and (st == "HELD" or st == "OTHERTANK" or st == "PETHELD" or st == "CC")
	if member then
		self:SetElementsAlpha(uf, 1, 1)
	elseif st == "HELD" or st == "WARN" or st == "OTHERTANK" or st == "PETHELD" or st == "CC" then
		self:SetElementsAlpha(uf, db.heldPlateAlpha, db.heldHealthAlpha)
		scaleFactor = db.heldScale or 1
		if st == "OTHERTANK" and (ns.Sync:NumTanks() >= 2 or ns.testMode) then tagName = m.otherTank end
		if st == "WARN" then
			-- bald Aggro: Plakette voll sichtbar, oranger Rahmen blinkt schnell
			self:SetElementsAlpha(uf, 1, 1)
			scaleFactor = db.warnScale or 1.1
			borderColor = db.colorWarn
			borderSize = db.borderSize + 1
			glowColor, glowDur = db.colorWarn, 0.2
			wantRaise = true
			if db.warnBlink then pulseDur, pulseTo = 0.2, 0 end
		end
		if db.showTankStripe and not ns.memberNow and (st == "HELD" or st == "WARN" or st == "OTHERTANK")
			and (ns.Sync:NumTanks() >= 2 or ns.testMode) then
			stripeColor = ns.Sync:TankColor(st == "OTHERTANK" and m.otherTank or ns.playerName)
		end
	elseif st == "LOOSE" then
		self:SetElementsAlpha(uf, 1, 1)
		local quiet = m.claimedBy or m.muted
		local c
		if m.claimedBy then c = db.colorClaimed
		elseif m.muted then c = QUIET_GREY
		elseif m.victimRole == "HEALER" then c = db.colorHealer
		else c = db.colorDD end
		borderColor = c
		borderSize = quiet and 1 or db.borderSize
		if m.claimedBy then tagName = m.claimedBy end
		if not tagName and m.tankOnIt then tagName = m.tankOnIt end
		if not quiet then
			wantScale, wantRaise = true, true
			scaleFactor = db.looseScale
			fire = db.looseFire
			glowColor, glowDur = c, (m.victimRole == "HEALER") and 0.25 or 0.4
			if db.loosePulse then
				pulseTo = 0.1
				if m.tauntCD and m.tauntCD > 0 then pulseDur = 1.0
				elseif m.victimRole == "HEALER" then pulseDur = 0.25
				else pulseDur = 0.4 end
			end
		end
		text1 = string.format(L.ARROW, m.victim or "?", L[m.victimRole or "DAMAGER"])
		text1Color = c
		if db.showHints and m.hint and not m.claimedBy then text2 = m.hint end
		if m.far then overlayAlpha = 0.55 end
	else
		local a = (db.outOfCombatMode == "faded") and 0.4 or 1
		self:SetElementsAlpha(uf, a, a)
	end

	o:Show()
	o:SetAlpha(overlayAlpha)

	-- Rahmen
	if borderColor then
		LayoutBorder(o.border, uf.healthBar, borderSize)
		ColorBorder(o.border, borderColor)
		o.border:Show()
	else
		o.border:Hide()
	end

	-- Flammen (lose Mobs: ein Spieler hat Aggro)
	SetFire(o, uf.healthBar, fire)

	-- Leuchten
	if glowColor and db.effectGlow then
		LayoutGlow(o.glow, uf.healthBar, st == "LOOSE" and 1.25 or 1)
		o.glow:SetVertexColor(glowColor[1], glowColor[2], glowColor[3], 1)
		o.glow:Show()
		if o.glowDur ~= glowDur then
			o.glowAG:Stop()
			o.glowAnim:SetDuration(glowDur)
			o.glowDur = glowDur
		end
		if not o.glowAG:IsPlaying() then o.glowAG:Play() end
	elseif o.glow:IsShown() then
		o.glowAG:Stop()
		o.glow:Hide()
		o.glowDur = nil
	end

	-- Druckwelle beim Wechsel auf bald Aggro / Aggro weg (nicht für gemeldete / übernommene Mobs)
	if db.effectGlow and (st == "LOOSE" or st == "WARN") and glowColor and o.lastSt ~= st then
		LayoutGlow(o.burst, uf.healthBar, 1)
		o.burst:SetVertexColor(glowColor[1], glowColor[2], glowColor[3], 1)
		o.burstAG:Stop()
		o.burst:SetAlpha(1)
		o.burstAG:Play()
	end
	o.lastSt = st

	-- Pulsieren
	if pulseDur then
		if o.pulseDur ~= pulseDur or o.pulseTo ~= pulseTo then
			o.pulse:Stop()
			o.pulseAnim:SetDuration(pulseDur)
			o.pulseAnim:SetToAlpha(pulseTo)
			o.pulseDur, o.pulseTo = pulseDur, pulseTo
		end
		if not o.pulse:IsPlaying() then o.pulse:Play() end
	elseif o.pulseDur then
		o.pulse:Stop()
		o.pulseDur, o.pulseTo = nil, nil
		o.border:SetAlpha(1)
	end

	-- Texte
	o.text1:SetText(text1)
	if text1Color then o.text1:SetTextColor(text1Color[1], text1Color[2], text1Color[3]) end
	o.text2:SetText(text2)

	-- Tank-Farbstrich
	if stripeColor then
		o.stripe:SetVertexColor(stripeColor[1], stripeColor[2], stripeColor[3], 1)
		o.stripe:Show()
	else
		o.stripe:Hide()
	end

	-- Kürzel des zuständigen Tanks
	if tagName then
		local c = ns.Sync:TankColor(tagName) or db.colorClaimed
		o.tag:SetText(Initial(tagName))
		o.tag:SetTextColor(c[1], c[2], c[3])
		o.tag:Show()
	else
		o.tag:Hide()
	end

	-- Rüstung zerreissen
	if db.showSunder and ns.class == "WARRIOR" and st ~= "IDLE" and (m.sunder or 0) > 0 then
		o.sunderText:SetText(m.sunder)
		o.sunderIcon:Show()
		o.sunderText:Show()
	else
		o.sunderIcon:Hide()
		o.sunderText:Hide()
	end

	-- Grösse: lose Plaketten grösser, gehaltene kleiner
	if member or (not wantScale and st ~= "HELD" and st ~= "WARN" and st ~= "OTHERTANK" and st ~= "PETHELD" and st ~= "CC") then
		scaleFactor = 1
	end
	if math.abs(scaleFactor - 1) > 0.01 then
		if not o.scaled then
			o.origScale = ns.Safe(uf:GetScale(), 1)
			o.scaled = true
		end
		if o.scaleFactor ~= scaleFactor then
			uf:SetScale(o.origScale * scaleFactor)
			o.scaleFactor = scaleFactor
		end
	elseif o.scaled then
		uf:SetScale(o.origScale or 1)
		o.scaled = false
		o.scaleFactor = nil
	end
	-- In den Vordergrund. Ist die Ebene geschützt (Forever), nur innerhalb der Ebene nach oben holen.
	if wantRaise then
		if not o.raised then
			local strata = uf:GetFrameStrata()
			if ns.IsSecret(strata, "strata") then
				ns:Compat("strata", "fallback")
				o.origStrata = nil
				if uf.Raise then uf:Raise() end
			else
				ns:Compat("strata", "ok")
				o.origStrata = strata
				uf:SetFrameStrata("HIGH")
			end
			o.raised = true
		end
	elseif o.raised then
		if o.origStrata then uf:SetFrameStrata(o.origStrata) end
		o.raised = false
	end
end
