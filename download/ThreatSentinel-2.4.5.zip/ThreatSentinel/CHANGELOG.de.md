# ThreatSentinel – Änderungen

## 2.4.5
- **Wichtig: Die Versionen 2.0.0 bis 2.4.3 luden überhaupt nicht** (Lua-Fehler gleich am Anfang von `Core.lua`, danach lief kein Modul). 2.4.4 hat das behoben – wer noch 2.0.0–2.4.3 hat, bitte unbedingt aktualisieren. Alles, was seit 2.0.0 dazukam (Gruppen-Ansicht, Schadens-/Heilmeter, Skillungsprüfung, WoW-Forever-Erkennung), wirkt erst ab 2.4.4
- Intern: Jede Blizzard-Funktion, die ThreatSentinel braucht, wird einmal in der neuen Datei `API.lua` (`ns.API`) ausgewählt und von dort aufgerufen. Keine Blizzard-Funktion wird ersetzt; die Testroutine prüft geschützte Werte, fehlende Funktionen und die Kampfsperre jetzt gefahrlos über diese Tabelle
- Testroutine: viele bisher übersprungene Fälle laufen jetzt (Abklingzeiten, Reichweite, Auren alter und moderner Weg, Mob-Schlüssel, geschützte Namen, fehlende Bedrohungsfunktionen, Sync-Kampfsperre, „unbekannt“ + geschützte Werte -> ANZEIGE, Reihenfolge im Aggrometer bei ANZEIGE, Plaketten-Auskunft, Sichtbarkeit von Aggrometer und DD-Ansicht, jede Option an/aus); neu „keine neuen Globals“ (T131) und „Fehlerzahl in der Diagnose“ (T161)
- Testroutine: Geht beim Zurücksetzen etwas schief, bricht die Routine immer sauber ab (nichts bleibt angehalten, alle Aktionen laufen wieder normal) und meldet den Fehler
- Bisher still abgefangene Fehler (Protokoll, Plaketten zurücksetzen, Anzeigen verschieben, CVars setzen, Notfall-Kurve) gehen jetzt auch an die Prüfung (`GoldSentinelTest`), ohne den Fehlerzähler im Spiel zu ändern
- Bildschirmfotos des Testprotokolls laufen über die zentrale Aktionsfunktion (während der Testroutine nur mitgeschrieben)
- Die Knöpfe der Testroutine in der Testzentrale sieht nur noch der Entwickler

## 2.4.4
- Behoben: Lua-Fehler beim Laden von `Core.lua` („attempt to call method 'On'“): Zwei Kampf-Ereignisse wurden angemeldet, bevor es die Ereignis-Funktion gab. Sie werden jetzt danach angemeldet; sonst unverändert
- Neue Testroutine für den Entwickler (`/ts testroutine`, `/ts testroutine a`–`j`, `halb`, `letzte`; Knopf „Alles testen“ und je Bereich ein Knopf in der Testzentrale). Ergebnisse und abgefangene Lua-Fehler gehen über die gemeinsame Datei `GoldSentinelTest.lua` an die Prüfung. Die Routine ersetzt keine Blizzard-Funktion, läuft nur ausserhalb des Kampfs, schickt nichts in den Chat oder an die Gruppe und stellt danach alle Einstellungen wieder her
- Intern: Aktionen mit Folgen (Chat, Addon-Nachrichten, CVars, Tastenbelegung, Neuladen, Betrachten, Töne) laufen über eine Stelle, damit die Testroutine sie nur mitschreibt statt ausführt

## 2.4.3
Korrekturen aus der Prüfung (WoW Forever):
- Erster Kampf nach dem Login: Solange noch nicht erkannt ist, ob die Bedrohungswerte lesbar sind, greift ThreatSentinel im Kampf nicht an den Plaketten ein (Modus ANZEIGE bis zum Ergebnis); geschützte Werte führen auch dann sofort zu ANZEIGE; liefert ein Kampf gar keine Daten, gilt AUS nur für diesen Kampf
- Modus ANZEIGE: Aggrometer und DD-Ansicht treffen keine eigenen Entscheidungen mehr – feste Reihenfolge (Tank, dann Gruppe), kein Vorsprung-Text, neutrale Balkenfarbe
- Blizzards Bedrohungsanzeigen auch bei „Immer nur Anzeige“, und sofort, wenn ThreatSentinel eingeschaltet wird (ausserhalb des Kampfs); Hinweis in den Einstellungen, dass es für Plaketten-Farben keine Blizzard-Einstellung gibt
- Testzentrale: Knopf „Client simulieren: Forever“ (Selbsttest mit GoldSentinelGame)

## 2.4.2
Korrekturen aus der Prüfung:
- Der Hinweis „Bedrohungsdaten sind geschützt“ und das Einschalten von Blizzards Bedrohungsanzeigen erscheinen nur noch, wenn ThreatSentinel eingeschaltet ist
- Testzentrale: Die Simulation „lesbar“ übersteuert keine echte Sperre mehr; der Knopf zeigt dann „echt gesperrt“
- Moderne API: Vergleiche von Einheiten (UnitIsUnit) laufen geschützt über eine sichere Prüfung
- Interne Prüfung geschützter Werte überall über GoldSentinelGame

## 2.4.1
- `GoldSentinelGame.lua` auf Version 2 aktualisiert (setzt sich gegen frühe, zurückgenommene Fassungen in anderen GoldSentinel-Addons durch; keine Lua-Fehler, wenn mehrere Addons gleichzeitig geladen sind)

## 2.4.0
- **Gemeinsame Versionserkennung aller GoldSentinel-Addons** (`GoldSentinelGame.lua`, `/gsgame`): WoW Forever und Retail gelten überall als moderne API, Classic Era, TBC, Wrath, Cata und MoP Classic als alte API. ThreatSentinel nutzt sie für die moderne API, die Namen (ohne Realm, geschützte Namen nie verarbeiten) und die Erkennung geschützter Werte; die Diagnose und „Bedrohung prüfen“ zeigen die erkannte Spielversion.
- Kampflog nur noch auf der modernen API gesperrt: Damit laufen **Schadens- und Heilmeter in TBC Anniversary** (bisher fälschlich aus), und widerstandener Spott wird in TBC wieder direkt erkannt.

## 2.2.0
- **WoW Forever: Bedrohungs-Erkennung im Spiel**. ThreatSentinel nimmt nicht mehr an, dass Bedrohungswerte gesperrt sind, sondern prüft es einmal pro Kampf selbst (moderne API) und wählt den passenden Modus:
  - **VOLL** (Werte lesbar, sowie Classic Era und TBC): alles wie bisher
  - **ANZEIGE** (Werte im Kampf geschützt): keine eigene Entscheidung mehr – kein Leuchten oder Ausblenden der Plaketten, keine Töne nach Schwellwerten; Aggrometer und DD-Ansicht zeigen die geschützten Werte als Balken; Blizzards Bedrohungsanzeigen (Prozent am Zielfenster, Bedrohungswarnung) werden ausserhalb des Kampfs eingeschaltet. Hinweis einmal pro Kampf.
  - **AUS** (keine Bedrohungsdaten): Bedrohungsanzeigen ausgeblendet; Tank-Sync, Rollen und Spott-Abklingzeiten bleiben
- Neu: **„Bedrohung prüfen“** (`/ts bedrohung` oder Knopf unter Allgemein) zeigt Modus, Status, Prozent (oder „geschützt“), den zuletzt erkannten Zustand mit Datum und Build sowie abgefangene Fehler
- Neue Einstellung **Bedrohungsmodus**: Automatisch (Standard) oder Immer nur Anzeige
- Testzentrale: Bedrohungszugriff simulierbar (lesbar / geschützt / nicht verfügbar)
- Moderne API: Der Ersatz über das Ziel des Mobs entfällt; im Kampf keine Eingriffe in Blizzards Plaketten, wenn die Werte geschützt sind; geschützte Namen und Zahlen werden nie mehr selbst verarbeitet; leere Aurenlisten im Kampf gelten als „unbekannt“; Tank-Sync sendet im Kampf nicht
- Abgefangene Fehler werden (moderne API) einmal pro Sitzung im Chat gemeldet und in der Diagnose sowie bei „Bedrohung prüfen“ gezählt
- Modus ANZEIGE merkt sich die eigenen Blizzard-Einstellungen und stellt sie im Modus VOLL wieder her (abschaltbar)
- Classic Era und TBC: unverändert

## 2.1.0
- **Skillung der Mitspieler**: ThreatSentinel prüft die Talente aller Spieler in Gruppe und Schlachtzug und leitet die Rolle daraus ab – Schutz-Krieger und Schutz-Paladin = Tank, Wilder-Kampf-Druide in Bärengestalt = Tank, Heilig-/Disziplin-Priester, Heilig-Paladin, Wiederherstellungs-Druide und -Schamane = Heiler, alle anderen = DD. Danach richten sich Plaketten, Warnungen (Frosch / Engelsgesang), Aggrometer und Schadens-/Heilmeter.
  - Eigene Talente werden direkt gelesen (auch für den eigenen Meter: Schatten-Priester bekommt den Schadensmeter, Heilig-Priester den Heilmeter)
  - Andere Spieler werden ausserhalb des Kampfs und in Reichweite nacheinander betrachtet; wer ThreatSentinel hat, meldet seine Rolle selbst
  - Ein zweiter Tank ohne Addon wird so zuverlässig erkannt (keine Fehlalarme für seine Mobs)
- Einstellungen › Gruppe zeigt die **erkannten Rollen** mit Quelle (ThreatSentinel, Talente x/y/z, geschätzt); die Prüfung lässt sich dort abschalten

## 2.0.0
- **ThreatSentinel für die ganze Gruppe**: Jeder mit dem Addon bekommt die Anzeigen seiner Rolle.
  - **Tank**: alles wie bisher
  - **DD**: Aggrometer + neuer **Schadensmeter** (Rangliste der Gruppe, Kampf / Gesamt, DPS)
  - **Heiler**: Aggrometer + neuer **Heilmeter** (Rangliste, HPS, ohne Überheilung)
- **Plaketten für DDs und Heiler**: Mobs beim Tank bleiben normal sichtbar; hervorgehoben wird nur Gefahr: **bald Aggro** (orange, blinkt) und **Aggro bei einem Spieler** (rot, brennt)
- **Warnton**: Der Tank hört Frosch (DD) bzw. Engelsgesang (Heiler). Wer selbst Aggro zieht, hört seinen Ton und sieht „Du hast Aggro – zurück zum Tank!“. Alle anderen bleiben ruhig. Töne unter Einstellungen › Töne.
- Tanks ohne Addon werden erkannt (Bärengestalt / Rechtschaffener Zorn sichtbar, sonst wer die meisten Mobs hält)
- Neuer Reiter **Gruppe** in den Einstellungen; Meter verschieb- und skalierbar (`/ts verschieben`)
- Schadens- und Heilmeter brauchen das Kampflog und gibt es deshalb nur in Classic / TBC, nicht in WoW Forever
- Hinweis: Wer bisher als Nicht-Tank „nur als Tank aktiv“ abgeschaltet hatte, bekommt jetzt die Gruppen-Ansicht (abschaltbar unter Gruppe)

## 1.8.1
- Neue Töne **Engelsgesang** und **Frosch**. Standard jetzt: Heiler hat Aggro = Engelsgesang, DD hat Aggro = Frosch. Hupe, Alarmhupe und alle anderen Töne bleiben wählbar; selbst gewählte Töne bleiben erhalten.

## 1.8.0
- **Viel stärkere Effekte**:
  - **Bald Aggro (orange)**: voll sichtbar, etwas grösser, dicker Rahmen, schnell blinkend, oranges Leuchten und eine Druckwelle beim Wechsel
  - **Aggro bei einem Spieler (rot)**: grössere, hellere Flammen (zwei Schichten), rotes pulsierendes Leuchten, Druckwelle beim Wechsel, Plakette grösser (140 %), dickerer Rahmen
  - Neue Einstellungen unter Plaketten › Effekte: Leuchten und Druckwelle an/aus, Stärke der Effekte (50–200 %)
- **Eigener Ton für den Heiler**: neue **Alarmhupe** (drei steigende Hupstösse) – der DD hat die einfache Hupe. So hört man ohne Hinschauen, wer die Aggro hat.
- **Testbericht in TBC und Classic: nur Sichtprüfung** – geprüft wird ausschliesslich, was man sieht: gehaltene Plaketten, Lebensbalken, bald Aggro (voll sichtbar, orange, blinkt, leuchtet), lose Plaketten (Rahmen, Farbe, Pulsieren, Flammen, Leuchten), Grösse der Plaketten, Raidmarkierung und Zauberbalken, Aufblitzen, HUD, Aggrometer, DD-Ansicht, Meldungen. Auf WoW Forever bleibt der volle Bericht mit allen Funktionsprüfungen.

## 1.7.4
- **Aggro bei einem Spieler**: Die Plakette **brennt** (animierte Flammen rundherum) und der Rahmen ist **rot** – auch bei DDs (bisher orange; orange heisst jetzt „bald Aggro“). Flammen unter Plaketten abschaltbar, Farben wählbar.

## 1.7.3
- Verliert der Tank die Aggro an einen Spieler (DD oder Heiler), ertönt standardmässig eine **Hupe**. Selbst gewählte Töne bleiben erhalten; unter „Töne“ frei änderbar.

## 1.7.2
- **Bald Aggro** (Vorwarnung): Die Plakette ist jetzt voll sichtbar, mit **orangem, schnell blinkendem Rahmen** (abschaltbar unter Plaketten; Farbe wählbar)
- **Töne standardmässig nur bei Aggroverlust** (an DD / Heiler). Aggro zurück, widerstanden, Notfall und die Warnung der DD-Ansicht sind standardmässig stumm und lassen sich unter Töne wieder einschalten. Selbst geänderte Töne bleiben, wie sie sind.

## 1.7.1
- Test- und Entwicklerfunktionen (Testzentrale, Testassistent, Testprotokoll `/ts log`, Ini-Prüfung) sind nur noch für den Entwickler sichtbar (gemeinsame Erkennung `GoldSentinelDev.lua` aller GoldSentinel-Addons, `/gsdev` zeigt den Status). Für alle anderen bleibt das Addon aufgeräumt.

## 1.7.0
- **Töne frei wählbar**: Jeder Ton (Aggroverlust an DD / Heiler, Vorwarnung, widerstanden, Aggro zurück, Notfall, DD-Ansicht) hat ein Auswahlfenster mit drei Gruppen: eigene ThreatSentinel-Töne, **Geräusche** (Hupe, Doppelhupe, Nebelhorn, Sirene, Alarmklingel, Glocke, Gong, Pfiff, Trommel, Doppelpiep, Ping) und **WoW-Töne** (Schlachtzugswarnung, Bereitschaftscheck, Alarm, Boss-Flüstern, Flüstern, Kartensignal …). Linksklick wählt und spielt ab, Rechtsklick spielt nur ab.
- **Eigener Ton**: eine WoW-Sound-ID (Zahl, z. B. von wowhead.com/sounds) oder eine eigene .ogg-/.mp3-Datei im Ordner `Interface\AddOns\ThreatSentinel_Sounds` (bleibt bei Updates erhalten; nach dem Hineinlegen das Spiel einmal neu starten)
- Neu: eigener Ton für die **Vorwarnung** (gelber Rand, Standard aus) und für die Warnung der DD-Ansicht (bisher derselbe Ton wie „Aggroverlust an DD“)
- **Ini-Prüfung**: Betrittst du als Tank einen Dungeon, läuft das Testprotokoll automatisch mit. Verlässt du die Instanz, erscheint der Bericht (Aggroverluste und Rückholungen, Plaketten, Töne, Meldungen, HUD, Aggrometer, Spott, Fehler, dazu Kämpfe in Tankhaltung und an wen die Aggro verloren ging). Sterben und Zurücklaufen als Geist oder /reload unterbrechen die Prüfung nicht. Hast du nicht getankt, gibt es keinen Bericht. Einstellungen unter „Allgemein“ (auch im Schlachtzug, Bilder, letzten Bericht zeigen).
- **Aggrometer und DD-Ansicht** (eigene Aggro) frei verschiebbar und in Grösse und Breite einstellbar – ebenso das kleine HUD. Neuer Knopf „Fenster verschieben / Grösse ändern“ (Anzeige-Reiter) oder `/ts verschieben`: Fenster ziehen, Mausrad ändert die Grösse, Rechtsklick setzt sie auf 100 %. Die Fenster bleiben dabei an ihrer Stelle.
- Testbericht: Die DD-Ansicht gilt als Tank nicht mehr als Fehler (sie ist dann absichtlich ausgeblendet); Spott über die Aktionsleiste zählt auch ohne Spott-Taste; nach /reload zählt die Auswertung die ganze Sitzung

## 1.6.1
- Testbericht: „Lose Plakette hervorgehoben“ meldet in Classic Era keinen falschen Fehler mehr (der Rahmen war da; die Prüfung verlangte zusätzlich einen Sichtbarkeitswert, den Classic anders meldet). Das Protokoll hält jetzt `shown` und `visible` getrennt fest.
- Testassistent: Der HUD-Schritt wird automatisch geprüft (Testmobs sterben oft, bevor man die Frage beantworten kann)
- Klarere Beschriftung der Zeile „Aggroverlust“ im Bericht

## 1.6.0
- Neues **Testprotokoll** für Tests ohne Zuschauer: `/ts log an | aus | leeren | status | bericht | bilder` oder Knopf in der Testzentrale. Schreibt maschinenlesbare Zeilen in die SavedVariables (`ThreatSentinelDB.testlog`): Sitzungsangaben (Client, Klasse, Gestalt, Pet, alle Einstellungen) und Ereignisse – Kampf, Mobs, Zustandswechsel, Bedrohung, der **tatsächliche** Zustand der Plaketten (Deckkraft, Grösse, Rahmen, Pulsieren, Aufblitzen, Hinweis, Raidmarkierung, Zauberbalken), Meldungen, Töne, HUD, Aggrometer, DD-Ansicht, Spott, Widerstand, Kontrolle, Sync, Tasten-Hinweis, Fehler, geblockte Aktionen und die Schritte des Testassistenten. Ringpuffer mit 5000 Einträgen, nur Änderungen, geschützte Werte stehen als SECRET. Standard aus; ausgeschaltet tut es nichts.
- **Testbericht im Spiel**: Wird das Testprotokoll ausgeschaltet (oder ist der Testassistent fertig), wertet ThreatSentinel das Protokoll selbst aus und zeigt einen Bericht: Aggroverluste und Rückholungen (mit Durchschnittszeit), Aussehen und Farbe gehaltener / loser Plaketten, Aufblitzen, HUD, Aggrometer, DD-Ansicht, Meldungen, Töne, Spott-Taste, Fehler. `/ts log bericht` oder „Auswertung“ in der Testzentrale zeigt ihn erneut; er steht auch im kopierbaren Bericht.
- Der Testassistent schaltet das Testprotokoll am Anfang ein und am Ende aus
- Automatische Bilder, solange das Protokoll läuft (loser Mob, Aggro zurück, jede neue Meldungsart, erstes Aggrometer im Kampf), höchstens 1 alle 2 s (Testmobs leben oft nur ~10 s) und 25 pro Sitzung; `/ts log bilder` schaltet sie um

## 1.5.0
- Neuer **Testassistent** (`/ts guide` oder Knopf in der Testzentrale): führt dich im Spiel Schritt für Schritt durch alle Funktionen, erkennt die meisten Schritte selbst, fragt mit Ja/Nein nach, was nur du sehen kannst, behält den Fortschritt über /reload hinweg und schreibt die Ergebnisse in den Bericht
- Live-Test-Option „Pet ist der Tank“ (Jäger / Hexer): Dein Pet tankt, du bist der DD, der Aggro zieht; die Spott-Taste lässt das Pet Knurren / Qual wirken
- Classic Era: Interface-Nummern 11509 / 11510 ergänzt

## 1.4.5
- Eingabefelder der Regler markieren beim Anklicken ihren Inhalt – Tippen ersetzt den Wert
- Testmeldungen bekommen während Tests einen dunklen Hintergrund und sind auf der Testzentrale lesbar
- Der Bericht nennt die aktive Gestalt / Haltung beim Namen statt nur als Nummer
- Die Einstellung „… reicht“ ist je Klasse beschriftet (Krieger: Zerreissen, sonst: Bedrohung)

## 1.4.4
- Retail: Ein Wächter-Druide gilt nur in Bärengestalt als Tank (nicht in Katzen-, Reise- oder Menschengestalt)
- Beim Belegen der Spott-Taste fragt das Addon nach, bevor es eine bestehende Belegung ersetzt
- Optionen anderer Klassen werden ausgeblendet (z. B. Rüstung-zerreissen-Stapel nur beim Krieger)
- Regler haben -/+-Knöpfe und ein Eingabefeld für exakte Werte
- Testzentrale: Meldungen erscheinen vor dem Fenster; neuer Knopf „Alle Meldungen nacheinander“; jede Zeile im „WoW-Forever-Schutz“ erklärt per Maus, wie man sie prüft; der Bericht enthält jetzt Datum, Spezialisierung, Gestalt, Umgebung (offene Welt / Dungeon / Raid) und Gruppe
- Klarere Wortwahl: Im Live-Test zählen Pets und NPC-Begleiter als DD

## 1.4.3
- Kleines HUD und Aggrometer stehen standardmässig am rechten Bildschirmrand statt neben deiner Figur und überdecken keine Namensplaketten mehr. Selbst verschobene Fenster bleiben, wo sie sind.

## 1.4.2
- Behoben: In Retail (und WoW Forever) erschien bei jedem Einloggen „ThreatSentinel wurde geblockt“. Das Kampflog wird in Clients mit geschützten Werten nicht mehr angemeldet; widerstandener Spott wird dort über die Bedrohung erkannt.
- Geblockte Aktionen werden mitgezählt und im Bericht der Testzentrale aufgeführt
- Demo: Vorschau-Mobs erscheinen immer im HUD (auch mit echten Plaketten in der Nähe); kein Flächenspott-Hinweis bei Klassen ohne Flächenspott
- Testmeldungen („Beispiel zeigen“) erscheinen jetzt vor dem Einstellungsfenster
- Aggrometer: Titel und Vorsprung laufen nicht mehr ineinander
- Der Wechsel zwischen Demo und Live-Test wird jetzt auf dem Bildschirm angezeigt

## 1.4.1
- Lädt jetzt auch in Retail (Midnight) als Testumgebung: Retail hat die Addon-Sperren, die WoW Forever übernimmt, schon heute. Tank-Erkennung dort über die Tank-Spezialisierung; Spott für Todesritter, Dämonenjäger, Mönch und Paladin (Hand der Abrechnung) ergänzt.

## 1.4.0
- Vorbereitet für WoW Forever: Das Spiel kann im Kampf Werte schützen („Secrets“). ThreatSentinel rechnet nie mit geschützten Werten, sondern schaltet auf einen Ersatzweg um, statt Lua-Fehler zu werfen:
  - Aggro: Bedrohungsstatus statt Prozente; Aggrometer und DD-Ansicht lassen die Werte vom Spiel anzeigen
  - Abklingzeiten: vom Addon ab dem eigenen Wirken gemessen (lernt die echte Dauer)
  - Spott widerstanden ohne Kampflog: Prüfung über die Bedrohung direkt nach dem Spott
  - Siegel der Wut, Rechtschaffener Zorn, Rüstung-zerreissen-Stapel und kontrollierte Mobs: aus den eigenen bzw. den Zaubern der Gruppe mitgezählt
  - Mob-Zuordnung ohne GUID: über die Plakette; Tank-Sync: andere Tanks an ihrem Ziel erkannt
  - Notfall-Hinweis: wenn möglich über die Lebensanzeige des Spiels
- Fehler in einem Teil halten nicht mehr das ganze Addon an
- Testzentrale: neue Spalte „WoW-Forever-Schutz“ (grün / gelb / rot je Funktion), „Forever-Sperren simulieren“ zum Ausprobieren aller Ersatzwege auf anderen Clients und „Bericht kopieren“

## 1.3.0
- Gehaltene Plaketten standardmässig mit 35 % Deckkraft und 80 % Grösse (einstellbar). Raidmarkierungen und Zauberbalken bleiben immer voll sichtbar.
- „Spott widerstanden“ nennt jetzt den bereiten Ersatz, z. B. „Spott widerstanden » Spöttischer Schlag!“ (Krieger: Spöttischer Schlag, danach Herausforderungsruf; Druide: Herausforderndes Gebrüll)
- Einmaliger Hinweis beim ersten Betreten einer Instanz, wenn die Spott-Taste noch nicht belegt ist
- Meldung in der Mitte: kleiner, Grösse und Höhe einstellbar, nach Wichtigkeit geordnet (eine wichtige Meldung wird nicht mehr von einer unwichtigeren verdrängt). „Aggro zurück“ standardmässig nur als Aufblitzen der Plakette.
- Neue eigene, kurze Töne – nicht mehr verwechselbar mit DBM/BigWigs oder dem Bereitschaftscheck
- Chat-Meldungen gehen standardmässig nur noch an die anderen Tanks (per Sync). Neu: Gruppe/Raid nur bei Bossen.
- Aggrometer: 100 % heisst jetzt immer „zieht jetzt die Aggro“ (110-%-Nahkampf- / 130-%-Fernkampf-Regel eingerechnet); „Gleich weg!“ statt „Vorsprung 0 %“
- Raidmarkierungen: Totenkopf vor Kreuz in der Lose-Liste, mit Symbol
- Voreinstellungen: Dezent, Standard, Laut
- Tank-Sync: kurzes Kürzel (z. B. „G“ für Grimbar) statt „übernommen von Grimbar“

## 1.2.3
- Paladin-Spott überarbeitet (Erkennung über Spell-IDs statt Namen):
  - TBC: Rechtschaffene Verteidigung wird auf den Mitspieler gewirkt, den der Mob angreift (Mob unter der Maus, sonst Ziel deines Ziels)
  - WoW Forever: Richturteil zählt nur mit aktivem Siegel der Wut als Spott, sonst zeigt die Plakette „Siegel der Wut fehlt“
  - Hand der Abrechnung entfernt (gibt es erst ab Wotlk)
- Diagnose zeigt die Spott-Art des Paladins und ob das Siegel der Wut aktiv ist

## 1.2.2
- Behoben: Das Addon lud in TBC Classic Anniversary 2.5.6 nicht (ein unbekanntes Ereignis brach das Laden ab – /ts und der Minimap-Knopf fehlten). Unbekannte Ereignisse werden jetzt übersprungen.
- Interface 20506 (TBC Classic Anniversary 2.5.6) ergänzt – das Addon gilt nicht mehr als veraltet
- Der Pfeil in „» Name (Rolle)“ wird jetzt richtig angezeigt (das alte Zeichen fehlte in der WoW-Schrift)
- Testzentrale: Vorschau-Plaketten in zwei Reihen, sie überlappen sich nicht mehr
- Testmeldungen bleiben stehen, wenn die Demo beendet wird

## 1.2.1
- Neuer Knopf **Unterstützen** (PayPal) in der Titelleiste des Einstellungsfensters und „Addon unterstützen“ auf der Seite Allgemein. Auch mit `/ts spenden`. Öffnet sich nie von selbst.

## 1.2.0
- Neue **Testzentrale** (Rechtsklick auf den Minimap-Knopf oder `/ts test`): Demo mit Vorschau-Plaketten, Live-Test solo, jede Meldung einzeln, Tank-Sync-Simulation und Diagnose
- Läuft auf Classic Era / Anniversary und TBC Anniversary sowie WoW Forever

## 1.1.0
- Erste Version: lose Mobs leuchten, gehaltene werden ausgeblendet, Spott auf Mauszeiger, Aggrometer, Tank-Sync
