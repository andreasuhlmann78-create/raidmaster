-- GuildSentinel - Pages.lua
-- Die Seiten im Fenster: Mitglieder, Rekrutierung, Berufe, Gildenbank, Einstellungen.

local ADDON, ns = ...
local L = ns.L
local UI = ns.UI
local A = ns.ACCENT

local GREEN, GRAY, GOLD, ORANGE = "|cff40d860", "|cff8a8f99", "|cffffd100", "|cffff9933"

local function Gray(t) return GRAY .. tostring(t) .. "|r" end

-- Seite neu zeichnen, wenn sie sichtbar ist
local function WhenShown(key, fn)
	return function(...)
		if UI:IsPageShown(key) then fn(...) end
	end
end

------------------------------------------------------------
-- Seite: Mitglieder
------------------------------------------------------------
local M = { key = "members", icon = "Interface\\Icons\\Spell_Holy_PrayerOfFortitude" }
M.title = L["Mitglieder"]
M.filter = { text = "", online = false, alts = true, sort = "seen", desc = true }
M.view = "list"
M.inactiveDays = 30

local LOG_TEXT = {
	join = { GREEN, L["beigetreten"] },
	leave = { ORANGE, L["hat die Gilde verlassen"] },
	kick = { "|cffff5555", L["wurde entfernt"] },
	promote = { "|cff66b3ff", L["befördert"] },
	demote = { ORANGE, L["degradiert"] },
	maxlevel = { GOLD, L["hat die Maximalstufe erreicht"] },
}

function M.build(p)
	M.panel = p
	M.tabs = UI:Tabs(p, {
		{ key = "list", text = L["Liste"] },
		{ key = "log", text = L["Verlauf"] },
		{ key = "inactive", text = L["Inaktiv"] },
	}, function(key) M.view = key; M:Refresh() end)
	M.tabs:SetPoint("TOPLEFT")
	M.tabs:SetPoint("TOPRIGHT")

	-- Liste ------------------------------------------------
	local v = CreateFrame("Frame", nil, p)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	M.listView = v

	local search = UI:Edit(v, 200, 24, L["Suchen (Name, Notiz, Zone)"])
	search:SetPoint("TOPLEFT")
	search.onChange = function(t) M.filter.text = t; M:Refresh() end

	local classDD = UI:Dropdown(v, 130, function()
		local items = { { value = false, text = L["Alle Klassen"] } }
		for _, c in ipairs(ns.Roster:Classes()) do items[#items + 1] = { value = c, text = ns.Colored(ns.ClassName(c), c) } end
		return items
	end, function() return M.filter.class or false end, function(val) M.filter.class = val or nil; M:Refresh() end)
	classDD:SetPoint("LEFT", search, "RIGHT", 8, 0)

	local rankDD = UI:Dropdown(v, 140, function()
		local items = { { value = false, text = L["Alle Ränge"] } }
		for _, r in ipairs(ns.Roster:Ranks()) do items[#items + 1] = { value = r.ri, text = r.name } end
		return items
	end, function() if M.filter.ri == nil then return false end return M.filter.ri end, function(val)
		if val == false then M.filter.ri = nil else M.filter.ri = val end
		M:Refresh()
	end)
	rankDD:SetPoint("LEFT", classDD, "RIGHT", 8, 0)

	local onl = UI:Check(v, L["Nur online"], function() return M.filter.online end, function(val) M.filter.online = val; M:Refresh() end)
	onl:SetPoint("LEFT", rankDD, "RIGHT", 12, 0)
	local alts = UI:Check(v, L["Twinks zeigen"], function() return M.filter.alts end, function(val) M.filter.alts = val; M:Refresh() end)
	alts:SetPoint("LEFT", onl, "RIGHT", 90, 0)

	M.stats = UI:Label(v, "", "GameFontHighlightSmall")
	M.stats:SetPoint("TOPRIGHT", 0, -6)
	M.stats:SetJustifyH("RIGHT")

	M.list = UI:List(v, {
		{ key = "name", title = L["Name"], width = 190, sort = "name" },
		{ key = "level", title = L["Stufe"], width = 40, align = "CENTER", sort = "level" },
		{ key = "class", title = L["Klasse"], width = 90, sort = "class" },
		{ key = "rank", title = L["Rang"], width = 110, sort = "rank" },
		{ key = "seen", title = L["Online / Zone"], width = 150, sort = "seen" },
		{ key = "note", title = L["Notiz"] },
	}, {
		key = function(e) return e.name end,
		render = function(e)
			local main = ns.Roster:MainOf(e.name)
			local name = ns.Colored(e.name, e.class)
			if main then name = "  " .. name .. " " .. Gray("(" .. main .. ")") end
			local seen = e.online and (GREEN .. (e.zone or L["online"]) .. "|r") or Gray(ns.Ago(e.seen))
			local note = e.note or ""
			local own = ns.G().notes[e.name]
			if own and own ~= "" then note = (note ~= "" and (note .. "  ") or "") .. GOLD .. own .. "|r" end
			return { name, tostring(e.level), ns.ClassName(e.class), e.rank or "", seen, note }
		end,
		onClick = function(e, button)
			M:ShowDetail(e)
			if button == "RightButton" then M:Menu(e) end
		end,
		onEnter = function(row, e)
			GameTooltip:SetOwner(row, "ANCHOR_CURSOR")
			GameTooltip:AddLine(ns.Colored(e.name, e.class))
			GameTooltip:AddLine(string.format("%s %d %s", L["Stufe"], e.level, ns.ClassName(e.class)), 1, 1, 1)
			if e.onote and e.onote ~= "" then GameTooltip:AddLine(L["Offiziersnotiz: "] .. e.onote, 0.8, 0.8, 0.8, true) end
			local alts = ns.Roster:AltsOf(e.name)
			if #alts > 0 then GameTooltip:AddLine(L["Twinks: "] .. table.concat(alts, ", "), 0.8, 0.8, 0.8, true) end
			local pr = ns.Prof:Of(e.name)
			if pr then
				for prof, x in pairs(pr.p or {}) do GameTooltip:AddDoubleLine(prof, tostring(x.r or "?"), 0.8, 0.8, 0.8, 1, 1, 1) end
			end
			GameTooltip:AddLine(L["Rechtsklick: Aktionen"], 0.5, 0.5, 0.5)
			GameTooltip:Show()
		end,
		onSort = function(key)
			if M.filter.sort == key then M.filter.desc = not M.filter.desc else M.filter.sort, M.filter.desc = key, (key == "level" or key == "seen") end
			M:Refresh()
		end,
		empty = L["Noch keine Gildendaten – kurz warten oder die Gildenliste (J) einmal öffnen."],
	})
	M.list:SetPoint("TOPLEFT", 0, -32)
	M.list:SetPoint("BOTTOMRIGHT", 0, 128)

	-- Details unten
	local d = CreateFrame("Frame", nil, v, UI.BACKDROP)
	d:SetPoint("BOTTOMLEFT")
	d:SetPoint("BOTTOMRIGHT")
	d:SetHeight(120)
	UI.Box(d, 0.07, 0.08, 0.11, 1, 0.18, 0.2, 0.25, 1)
	M.detail = d
	d.title = UI:Label(d, "", "GameFontNormalLarge")
	d.title:SetPoint("TOPLEFT", 12, -10)
	d.info = UI:Label(d, "", "GameFontHighlightSmall")
	d.info:SetPoint("TOPLEFT", d.title, "BOTTOMLEFT", 0, -6)
	d.info:SetWidth(440)
	d.info:SetJustifyV("TOP")
	d.note = UI:Edit(d, 300, 24, L["Eigene Notiz (nur für dich)"])
	d.note:SetPoint("BOTTOMLEFT", 12, 10)
	d.note.onCommit = function(t)
		if not M.selected or not ns.guild then return end
		t = ns.Trim(t)
		ns.guild.notes[M.selected] = (t ~= "") and t or nil
		M.list:Draw()
	end
	d.note.onEnter = d.note.onCommit

	local bx = -10
	local function Btn(text, fn)
		local b = UI:Button(d, text, 130, 24, fn)
		b:SetPoint("TOPRIGHT", bx, -10)
		return b
	end
	d.whisper = Btn(L["Anflüstern"], function() if M.selected then ns.Recruit:Whisper(M.selected) end end)
	bx = -146
	d.invite = Btn(L["In Gruppe einladen"], function()
		if not M.selected then return end
		local fn = (C_PartyInfo and C_PartyInfo.InviteUnit) or InviteUnit
		if fn then fn(M.selected) end
	end)
	bx = -10
	d.setMain = UI:Button(d, L["Twink von …"], 130, 24, function()
		if not M.selected then return end
		local name = M.selected
		UI:Ask(string.format(L["Wessen Twink ist %s? (Name des Mains)"], name), ns.Roster:MainOf(name) or "", function(main)
			main = ns.Trim(main)
			if main == "" then return end
			ns.Roster:SetMain(name, main)
		end)
	end)
	d.setMain:SetPoint("TOPRIGHT", -10, -40)
	d.isMain = UI:Button(d, L["Ist ein Main"], 130, 24, function()
		if M.selected then ns.Roster:SetMain(M.selected, "") end
	end)
	d.isMain:SetPoint("TOPRIGHT", -146, -40)
	UI.Tip(d.setMain, L["Twink festlegen"], L["Gilt für alle in der Gilde mit GuildSentinel. Steht in der Notiz 'Twink von Name', erkennt GuildSentinel das auch selbst."])
	M:ShowDetail(nil)

	-- Verlauf ---------------------------------------------
	M.logList = UI:List(p, {
		{ key = "t", title = L["Zeit"], width = 110 },
		{ key = "n", title = L["Name"], width = 160 },
		{ key = "k", title = L["Ereignis"], width = 220 },
		{ key = "x", title = L["Details"] },
	}, {
		render = function(e)
			local info = LOG_TEXT[e.k] or { "", e.k }
			local r = ns.G().roster[e.n]
			local x = e.x
			if e.k == "kick" and x then x = L["von "] .. x end
			if e.k == "maxlevel" and x then x = L["Stufe "] .. x end
			return { ns.Date(e.t), ns.Colored(e.n or "?", r and r.c), info[1] .. info[2] .. "|r", x and tostring(x) or "" }
		end,
		empty = L["Noch keine Ereignisse. GuildSentinel merkt sich ab jetzt, wer kommt und geht."],
	})
	M.logList:SetPoint("TOPLEFT", 0, -34)
	M.logList:SetPoint("BOTTOMRIGHT")

	-- Inaktiv ---------------------------------------------
	local iv = CreateFrame("Frame", nil, p)
	iv:SetPoint("TOPLEFT", 0, -34)
	iv:SetPoint("BOTTOMRIGHT")
	M.inactiveView = iv
	local lbl = UI:Label(iv, L["Nicht online seit mindestens"])
	lbl:SetPoint("TOPLEFT", 0, -5)
	local dd = UI:Dropdown(iv, 120, function()
		return {
			{ value = 14, text = L["14 Tagen"] }, { value = 30, text = L["30 Tagen"] },
			{ value = 60, text = L["60 Tagen"] }, { value = 90, text = L["90 Tagen"] },
		}
	end, function() return M.inactiveDays end, function(val) M.inactiveDays = val; M:Refresh() end)
	dd:SetPoint("LEFT", lbl, "RIGHT", 8, 0)
	local hint = UI:Label(iv, L["Zählt nur, wenn auch kein Twink des Spielers online war."], "GameFontDisableSmall")
	hint:SetPoint("LEFT", dd, "RIGHT", 12, 0)
	M.inactiveList = UI:List(iv, {
		{ key = "name", title = L["Name"], width = 160 },
		{ key = "level", title = L["Stufe"], width = 40, align = "CENTER" },
		{ key = "rank", title = L["Rang"], width = 120 },
		{ key = "seen", title = L["Zuletzt online"], width = 130 },
		{ key = "note", title = L["Notiz"] },
	}, {
		key = function(e) return e.name end,
		render = function(e)
			return { ns.Colored(e.name, e.class), tostring(e.level), e.rank or "", Gray(ns.Ago(e.seen)), e.note or "" }
		end,
		onClick = function(e, button) if button == "RightButton" then M:Menu(e) end end,
		empty = L["Niemand – alle waren in letzter Zeit online."],
	})
	M.inactiveList:SetPoint("TOPLEFT", 0, -32)
	M.inactiveList:SetPoint("BOTTOMRIGHT")

	M.tabs:Select("list")
end

function M:ShowDetail(e)
	local d = self.detail
	if not d then return end
	self.selected = e and e.name or nil
	local on = e ~= nil
	for _, b in ipairs({ d.whisper, d.invite, d.setMain, d.isMain }) do b:SetEnabled(on) end
	d.note:SetEnabled(on)
	if not e then
		d.title:SetText(Gray(L["Wähle ein Mitglied aus der Liste."]))
		d.info:SetText("")
		d.note:SetText("")
		return
	end
	d.title:SetText(ns.Colored(e.name, e.class) .. "  " .. Gray(string.format("%s %d %s · %s", L["Stufe"], e.level, ns.ClassName(e.class), e.rank or "")))
	local lines = {}
	local main = ns.Roster:MainOf(e.name)
	if main then
		lines[#lines + 1] = L["Twink von "] .. ns.Colored(main, ns.G().roster[main] and ns.G().roster[main].c)
	else
		local alts = ns.Roster:AltsOf(e.name)
		if #alts > 0 then
			local t = {}
			for _, a in ipairs(alts) do t[#t + 1] = ns.Colored(a, ns.G().roster[a] and ns.G().roster[a].c) end
			lines[#lines + 1] = L["Twinks: "] .. table.concat(t, ", ")
		end
	end
	local pr = ns.Prof:Of(e.name)
	if pr and pr.p then
		local t = {}
		for prof, x in pairs(pr.p) do t[#t + 1] = prof .. " " .. (x.r or "?") end
		table.sort(t)
		lines[#lines + 1] = L["Berufe: "] .. table.concat(t, ", ")
	end
	if e.online then
		lines[#lines + 1] = GREEN .. L["online"] .. "|r – " .. (e.zone or "")
	else
		lines[#lines + 1] = L["Zuletzt online: "] .. ns.Ago(e.seen)
	end
	local r = ns.G().roster[e.name]
	if r and r.first and r.first > 0 then lines[#lines + 1] = L["In der Gilde seit: "] .. date(L["%d.%m.%Y"], r.first) end
	d.info:SetText(table.concat(lines, "\n"))
	d.note:SetText(ns.G().notes[e.name] or "")
end

function M:Menu(e)
	-- kleines Aktionsmenü an der Maus
	if not M.menuAnchor then
		M.menuAnchor = CreateFrame("Frame", nil, UIParent)
		M.menuAnchor:SetSize(170, 1)
	end
	local x, y = GetCursorPosition()
	local sc = UIParent:GetEffectiveScale()
	M.menuAnchor:ClearAllPoints()
	M.menuAnchor:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", x / sc, y / sc)
	local name = e.name
	UI:PopupMenu(M.menuAnchor, {
		{ value = "whisper", text = L["Anflüstern"] },
		{ value = "invite", text = L["In Gruppe einladen"] },
		{ value = "main", text = L["Twink von …"] },
		{ value = "ismain", text = L["Ist ein Main"] },
	}, function(val)
		if val == "whisper" then ns.Recruit:Whisper(name)
		elseif val == "invite" then
			local fn = (C_PartyInfo and C_PartyInfo.InviteUnit) or InviteUnit
			if fn then fn(name) end
		elseif val == "main" then
			UI:Ask(string.format(L["Wessen Twink ist %s? (Name des Mains)"], name), ns.Roster:MainOf(name) or "", function(main)
				main = ns.Trim(main)
				if main ~= "" then ns.Roster:SetMain(name, main) end
			end)
		elseif val == "ismain" then ns.Roster:SetMain(name, "")
		end
	end)
end

function M:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	self.listView:SetShown(self.view == "list")
	self.logList:SetShown(self.view == "log")
	self.inactiveView:SetShown(self.view == "inactive")
	if self.view == "list" then
		local f = self.filter
		local data = ns.Roster:Filtered({ text = f.text, online = f.online, class = f.class, ri = f.ri, alts = f.alts, sort = f.sort, desc = f.desc })
		self.list:SetData(data, f.sort, f.desc)
		local total, online, mains, mainsOnline, max = ns.Roster:Stats()
		self.stats:SetText(string.format(L["%d Charaktere · %d Spieler · %d online · %d auf Maximalstufe"], total, mains, online, max))
		if self.selected and ns.Roster.byName[self.selected] then self:ShowDetail(ns.Roster.byName[self.selected]) end
	elseif self.view == "log" then
		self.logList:SetData(ns.G().log)
	else
		self.inactiveList:SetData(ns.Roster:Inactive(self.inactiveDays))
	end
end

M.onShow = function() M:Refresh() end
ns:Listen("GS_ROSTER", WhenShown("members", function() M:Refresh() end))
ns:Listen("GS_LOG", WhenShown("members", function() M:Refresh() end))
ns:Listen("GS_PROF", WhenShown("members", function() M:Refresh() end))
UI:AddPage(M)

------------------------------------------------------------
-- Seite: Rekrutierung
------------------------------------------------------------
local R = { key = "recruit", icon = "Interface\\Icons\\Ability_Warrior_BattleShout" }
R.title = L["Rekrutierung"]
R.view = "ad"
R.showAll = false
R.badge = function()
	local n = #ns.Recruit:Applicants()
	return n > 0 and (GREEN .. n .. "|r") or ""
end

local function DbText(key)
	return function() return ns.db[key] or "" end
end

function R.build(p)
	R.panel = p
	R.tabs = UI:Tabs(p, {
		{ key = "ad", text = L["Werbung"] },
		{ key = "apps", text = L["Bewerber"] },
		{ key = "texts", text = L["Antworten & Begrüßung"] },
	}, function(key) R.view = key; R:Refresh() end)
	R.tabs:SetPoint("TOPLEFT")
	R.tabs:SetPoint("TOPRIGHT")

	-- Werbung ---------------------------------------------
	local ad = CreateFrame("Frame", nil, p)
	ad:SetPoint("TOPLEFT", 0, -34)
	ad:SetPoint("BOTTOMRIGHT")
	R.adView = ad

	local h1 = UI:Header(ad, L["Werbetext"])
	h1:SetPoint("TOPLEFT", 0, 0)
	R.adEdit = UI:Edit(ad, 520, 76, ns.Recruit:DefaultAd(), true, 255)
	R.adEdit:SetPoint("TOPLEFT", h1, "BOTTOMLEFT", 0, -6)
	R.adEdit.onChange = function(t, user) if user then ns.db.adText = t; R:Preview() end end
	local ph = UI:Label(ad, L["Platzhalter:"] .. "\n{gilde}  {name}  {discord}\n{mitglieder}  {online}\n\n" .. Gray(L["Leer lassen = Standardtext"]), "GameFontHighlightSmall")
	ph:SetPoint("TOPLEFT", R.adEdit, "TOPRIGHT", 14, 0)
	ph:SetJustifyV("TOP")

	local h2 = UI:Header(ad, L["Vorschau"])
	h2:SetPoint("TOPLEFT", R.adEdit, "BOTTOMLEFT", 0, -14)
	R.preview = UI:Label(ad, "", "GameFontHighlight")
	R.preview:SetPoint("TOPLEFT", h2, "BOTTOMLEFT", 0, -6)
	R.preview:SetWidth(740)
	R.preview:SetJustifyV("TOP")
	R.length = UI:Label(ad, "", "GameFontDisableSmall")
	R.length:SetPoint("LEFT", h2, "RIGHT", 10, 0)

	local h3 = UI:Header(ad, L["Discord-Einladung"])
	h3:SetPoint("TOPLEFT", h2, "BOTTOMLEFT", 0, -48)
	R.discord = UI:Edit(ad, 320, 24, "discord.gg/…")
	R.discord:SetPoint("TOPLEFT", h3, "BOTTOMLEFT", 0, -6)
	R.discord.onChange = function(t, user) if user then ns.db.discord = ns.Trim(t); R:Preview() end end

	local h4 = UI:Header(ad, L["Kanäle"])
	h4:SetPoint("TOPLEFT", R.discord, "BOTTOMLEFT", 0, -16)
	R.chanHint = UI:Label(ad, Gray(L["Jeder Klick postet in einen Kanal, der nächste Klick in den nächsten."]), "GameFontHighlightSmall")
	R.chanHint:SetPoint("LEFT", h4, "RIGHT", 10, 0)
	R.chanHolder = CreateFrame("Frame", nil, ad)
	R.chanHolder:SetPoint("TOPLEFT", h4, "BOTTOMLEFT", 0, -4)
	R.chanHolder:SetSize(740, 50)
	R.chanChecks = {}

	local remind = UI:Check(ad, L["Erinnern, wenn die Werbung wieder fällig ist – alle"], function() return ns.db.adRemind end, function(v) ns.db.adRemind = v end)
	remind:SetPoint("TOPLEFT", R.chanHolder, "BOTTOMLEFT", 0, -8)
	local mins = UI:Dropdown(ad, 110, function()
		local out = {}
		for _, m in ipairs({ 10, 15, 20, 30, 45, 60 }) do out[#out + 1] = { value = m, text = string.format(L["%d Minuten"], m) } end
		return out
	end, function() return ns.db.adInterval end, function(v) ns.db.adInterval = v end)
	mins:SetPoint("LEFT", remind.text, "RIGHT", 8, 0)

	R.postBtn = UI:Button(ad, L["Werbung posten"], 300, 36, function() ns.Recruit:Post(); R:Refresh() end, true)
	R.postBtn:SetPoint("BOTTOMLEFT", 0, 4)
	R.postStatus = UI:Label(ad, "", "GameFontHighlight")
	R.postStatus:SetPoint("LEFT", R.postBtn, "RIGHT", 14, 0)
	R.postStatus:SetWidth(440)

	-- Bewerber --------------------------------------------
	local apps = CreateFrame("Frame", nil, p)
	apps:SetPoint("TOPLEFT", 0, -34)
	apps:SetPoint("BOTTOMRIGHT")
	R.appsView = apps
	local STATUS = {
		new = GREEN .. L["neu"] .. "|r", invited = "|cff66b3ff" .. L["eingeladen"] .. "|r",
		declined = Gray(L["abgelehnt"]), joined = GOLD .. L["beigetreten"] .. "|r",
	}
	R.appList = UI:List(apps, {
		{ key = "name", title = L["Name"], width = 130 },
		{ key = "class", title = L["Klasse"], width = 90 },
		{ key = "msg", title = L["Nachricht"] },
		{ key = "t", title = L["Wann"], width = 90 },
		{ key = "st", title = L["Status"], width = 90 },
	}, {
		key = function(x) return x.name end,
		render = function(x)
			local a = x.a
			return { ns.Colored(x.name, a.c), a.c and ns.ClassName(a.c) or Gray("?"), a.msg or "", Gray(ns.Ago(a.last or a.t)), STATUS[a.st] or a.st or "" }
		end,
		onClick = function() R:UpdateAppButtons() end,
		onEnter = function(row, x)
			GameTooltip:SetOwner(row, "ANCHOR_CURSOR")
			GameTooltip:AddLine(ns.Colored(x.name, x.a.c))
			if x.a.msg then GameTooltip:AddLine(x.a.msg, 1, 1, 1, true) end
			GameTooltip:AddLine(L["Erstmals: "] .. ns.Date(x.a.t), 0.7, 0.7, 0.7)
			GameTooltip:Show()
		end,
		empty = L["Noch keine Bewerber. Wer dich mit einem Stichwort (z. B. 'gilde') anflüstert, landet hier."],
	})
	R.appList:SetPoint("TOPLEFT")
	R.appList:SetPoint("BOTTOMRIGHT", 0, 40)
	local function Sel() local x = R.appList:Selected(); return x and x.name end
	R.appInvite = UI:Button(apps, L["In die Gilde einladen"], 170, 28, function() local n = Sel(); if n then ns.Recruit:Invite(n) end end, true)
	R.appInvite:SetPoint("BOTTOMLEFT", 0, 4)
	R.appWhisper = UI:Button(apps, L["Anflüstern"], 120, 28, function() local n = Sel(); if n then ns.Recruit:Whisper(n) end end)
	R.appWhisper:SetPoint("LEFT", R.appInvite, "RIGHT", 8, 0)
	R.appDecline = UI:Button(apps, L["Ablehnen"], 110, 28, function() local n = Sel(); if n then ns.Recruit:SetStatus(n, "declined") end end)
	R.appDecline:SetPoint("LEFT", R.appWhisper, "RIGHT", 8, 0)
	R.appRemove = UI:Button(apps, L["Entfernen"], 110, 28, function()
		local n = Sel()
		if n then ns.Recruit:Remove(n); R.appList:ClearSelection() end
	end)
	R.appRemove:SetPoint("LEFT", R.appDecline, "RIGHT", 8, 0)
	local all = UI:Check(apps, L["Erledigte zeigen"], function() return R.showAll end, function(v) R.showAll = v; R:Refresh() end)
	all:SetPoint("BOTTOMRIGHT", -110, 8)

	-- Texte -----------------------------------------------
	local tx = CreateFrame("Frame", nil, p)
	tx:SetPoint("TOPLEFT", 0, -34)
	tx:SetPoint("BOTTOMRIGHT")
	R.textView = tx

	local c1 = UI:Check(tx, L["Bewerbern automatisch antworten"], function() return ns.db.autoReply end, function(v) ns.db.autoReply = v end)
	c1:SetPoint("TOPLEFT", 0, 0)
	R.replyEdit = UI:Edit(tx, 560, 60, ns.Recruit:DefaultReply(), true, 255)
	R.replyEdit:SetPoint("TOPLEFT", c1, "BOTTOMLEFT", 2, -4)
	R.replyEdit.onChange = function(t, user) if user then ns.db.replyText = t; R:TextPreviews() end end
	R.replyPrev = UI:Label(tx, "", "GameFontHighlightSmall")
	R.replyPrev:SetPoint("TOPLEFT", R.replyEdit, "BOTTOMLEFT", 0, -4)
	R.replyPrev:SetWidth(740)

	local h5 = UI:Header(tx, L["Stichwörter für Bewerbungen (mit Komma getrennt)"])
	h5:SetPoint("TOPLEFT", R.replyPrev, "BOTTOMLEFT", -2, -18)
	R.kwEdit = UI:Edit(tx, 560, 24, ns.Recruit:DefaultKeywords())
	R.kwEdit:SetPoint("TOPLEFT", h5, "BOTTOMLEFT", 2, -6)
	R.kwEdit.onChange = function(t, user) if user then ns.db.keywords = t end end

	local c2 = UI:Check(tx, L["Neue Mitglieder im Gildenchat begrüßen"], function() return ns.db.welcome end, function(v) ns.db.welcome = v end)
	c2:SetPoint("TOPLEFT", R.kwEdit, "BOTTOMLEFT", -2, -22)
	R.welEdit = UI:Edit(tx, 560, 60, ns.Recruit:DefaultWelcome(), true, 255)
	R.welEdit:SetPoint("TOPLEFT", c2, "BOTTOMLEFT", 2, -4)
	R.welEdit.onChange = function(t, user) if user then ns.db.welcomeText = t; R:TextPreviews() end end
	R.welPrev = UI:Label(tx, "", "GameFontHighlightSmall")
	R.welPrev:SetPoint("TOPLEFT", R.welEdit, "BOTTOMLEFT", 0, -4)
	R.welPrev:SetWidth(740)
	local wh = UI:Label(tx, Gray(L["Haben mehrere das Addon, begrüßt nur einer. Platzhalter: {spieler}, {gilde}, {discord}"]), "GameFontHighlightSmall")
	wh:SetPoint("TOPLEFT", R.welPrev, "BOTTOMLEFT", 0, -8)
	wh:SetWidth(740)

	R.tabs:Select("ad")
end

function R:Preview()
	local text = ns.Recruit:AdText()
	self.preview:SetText(text)
	self.length:SetText(string.format("(%d/255)", #text))
end

function R:TextPreviews()
	self.replyPrev:SetText(Gray(L["Vorschau: "]) .. ns.Recruit:ReplyPreview())
	self.welPrev:SetText(Gray(L["Vorschau: "]) .. ns.Recruit:WelcomePreview())
end

function R:BuildChannels()
	for _, c in ipairs(self.chanChecks) do c:Hide() end
	local list = ns.Recruit:Joined()
	if #list == 0 then
		self.noChan = self.noChan or UI:Label(self.chanHolder, Gray(L["Du bist in keinem Chatkanal."]), "GameFontHighlightSmall")
		self.noChan:SetPoint("TOPLEFT", 0, -6)
		self.noChan:Show()
		return
	end
	if self.noChan then self.noChan:Hide() end
	for i, ch in ipairs(list) do
		local c = self.chanChecks[i]
		if not c then
			c = UI:Check(self.chanHolder, "", function() return c and c.short and ns.Recruit:IsTarget(c.short) end, function(v) if c and c.short then ns.Recruit:SetTarget(c.short, v) end end)
			self.chanChecks[i] = c
		end
		c.short = ch.short
		c.text:SetText(ch.id .. ". " .. ch.short)
		c:SetHitRectInsets(0, -(c.text:GetStringWidth() + 10), 0, 0)
		c:ClearAllPoints()
		local col, row = (i - 1) % 4, math.floor((i - 1) / 4)
		c:SetPoint("TOPLEFT", col * 185, -row * 24)
		c.Refresh()
		c:Show()
	end
end

function R:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	self.adView:SetShown(self.view == "ad")
	self.appsView:SetShown(self.view == "apps")
	self.textView:SetShown(self.view == "texts")
	local n = #ns.Recruit:Applicants()
	self.tabs:SetLabel("apps", n > 0 and string.format(L["Bewerber (%d)"], n) or L["Bewerber"])
	if self.view == "ad" then
		if not self.adEdit.edit:HasFocus() then self.adEdit:SetText(ns.db.adText or "") end
		if not self.discord.edit:HasFocus() then self.discord:SetText(ns.db.discord or "") end
		self:Preview()
		ns.Recruit:EnsureTargets()
		self:BuildChannels()
		self:UpdatePost()
	elseif self.view == "apps" then
		self.appList:SetData(ns.Recruit:Applicants(self.showAll))
		self:UpdateAppButtons()
	else
		if not self.replyEdit.edit:HasFocus() then self.replyEdit:SetText(ns.db.replyText or "") end
		if not self.welEdit.edit:HasFocus() then self.welEdit:SetText(ns.db.welcomeText or "") end
		if not self.kwEdit.edit:HasFocus() then self.kwEdit:SetText(ns.db.keywords or "") end
		self:TextPreviews()
	end
end

function R:UpdatePost()
	local Rc = ns.Recruit
	local c, wait, soonest = Rc:NextTarget()
	local gw = Rc:GlobalWait()
	if #Rc:Targets() == 0 then
		self.postBtn:SetText(L["Werbung posten"])
		self.postBtn:Disable()
		self.postStatus:SetText(ORANGE .. L["Wähle oben mindestens einen Kanal."] .. "|r")
		return
	end
	if c and gw == 0 then
		self.postBtn:SetText(string.format(L["Posten in %s"], c.short))
		self.postBtn:Enable()
	else
		self.postBtn:SetText(L["Werbung posten"])
		self.postBtn:Disable()
	end
	local last = ns.db.lastAdTime or 0
	local status = last > 0 and (L["Zuletzt gepostet: "] .. ns.Ago(last)) or L["Heute noch nicht gepostet."]
	if not c and wait then status = status .. "  " .. string.format(L["Nächster Kanal in %d s"], wait)
	elseif gw > 0 then status = status .. "  " .. string.format(L["Bitte %d s warten"], gw) end
	if Rc:Due() then status = GOLD .. L["Wieder fällig! "] .. "|r" .. status end
	self.postStatus:SetText(status)
end

function R:UpdateAppButtons()
	local x = self.appList:Selected()
	local has = x ~= nil
	self.appInvite:SetEnabled(has and ns.CanInvite() and x.a.st ~= "joined")
	self.appWhisper:SetEnabled(has)
	self.appDecline:SetEnabled(has and x.a.st ~= "declined")
	self.appRemove:SetEnabled(has)
end

R.onShow = function(_, arg)
	if arg == "apps" then R.tabs:Select("apps") else R:Refresh() end
end
ns:Listen("GS_APPS", WhenShown("recruit", function() R:Refresh() end))
ns:Listen("GS_RECRUIT", WhenShown("recruit", function() R:Refresh() end))
-- Countdown aktualisieren
C_Timer.NewTicker(1, function()
	if UI:IsPageShown("recruit") and R.view == "ad" then R:UpdatePost() end
end)
UI:AddPage(R)

------------------------------------------------------------
-- Seite: Berufe
------------------------------------------------------------
local P = { key = "prof", icon = "Interface\\Icons\\Trade_BlackSmithing" }
P.title = L["Berufe"]
P.query = ""
P.selProf = nil

function P.build(p)
	P.panel = p
	local search = UI:Edit(p, 320, 26, L["Rezept oder Item suchen, z. B. 'Feuerwiderstand'"])
	search:SetPoint("TOPLEFT")
	search.onChange = function(t) P.query = t; P:Refresh() end
	P.search = search

	P.mine = UI:Label(p, "", "GameFontHighlightSmall")
	P.mine:SetPoint("TOPLEFT", search, "BOTTOMLEFT", 0, -8)
	P.mine:SetWidth(520)
	P.mine:SetJustifyV("TOP")

	-- Platz für den sicheren Knopf "Nächsten Beruf einlesen" (liegt auf UIParent, siehe unten)
	P.slot = CreateFrame("Frame", nil, p)
	P.slot:SetSize(240, 28)
	P.slot:SetPoint("TOPRIGHT", 0, 0)
	P.slotHint = UI:Label(p, Gray(L["Oder: jedes Berufsfenster einmal selbst öffnen."]), "GameFontHighlightSmall")
	P.slotHint:SetPoint("TOPRIGHT", P.slot, "BOTTOMRIGHT", 0, -6)

	P.profList = UI:List(p, {
		{ key = "name", title = L["Beruf"] },
		{ key = "count", title = L["Wer"], width = 40, align = "RIGHT" },
	}, {
		key = function(x) return x.name end,
		render = function(x) return { x.name, tostring(x.count) } end,
		onClick = function(x)
			P.selProf = x.name
			P.query = ""
			P.search:SetText("")
			P:Refresh()
		end,
		empty = L["Noch keine Berufe bekannt."],
	})
	P.profList:SetPoint("TOPLEFT", 0, -62)
	P.profList:SetPoint("BOTTOMLEFT", 0, 40)
	P.profList:SetWidth(210)

	P.results = UI:List(p, {
		{ key = "a", title = L["Rezept"] },
		{ key = "b", title = L["Wer"], width = 150 },
		{ key = "c", title = L["Beruf"], width = 120 },
		{ key = "d", title = L["Stufe"], width = 50, align = "CENTER" },
		{ key = "e", title = L["Status"], width = 90 },
	}, {
		key = function(x) return (x.recipe or "") .. "|" .. x.name end,
		render = function(x)
			local onlineChar = ns.Roster:OnlineChar(x.name)
			local status = onlineChar and (GREEN .. (onlineChar == x.name and L["online"] or (L["als "] .. onlineChar)) .. "|r") or Gray(L["offline"])
			if P.query ~= "" then
				return { x.recipe, ns.Colored(x.name, x.class), x.prof, tostring(x.rank or ""), status }
			end
			return { string.format(L["%d Rezepte"], x.n or 0), ns.Colored(x.name, x.class), P.selProf or "", tostring(x.r or ""), status }
		end,
		onClick = function() P:UpdateButtons() end,
		onEnter = function(row, x)
			if x.id and x.id > 0 then
				GameTooltip:SetOwner(row, "ANCHOR_CURSOR")
				GameTooltip:SetHyperlink("item:" .. x.id)
				GameTooltip:Show()
			end
		end,
		empty = L["Suche oben nach einem Rezept oder wähle links einen Beruf."],
	})
	P.results:SetPoint("TOPLEFT", P.profList, "TOPRIGHT", 10, 0)
	P.results:SetPoint("BOTTOMRIGHT", 0, 40)

	P.ask = UI:Button(p, L["Herstellen anfragen"], 180, 28, function()
		local x = P.results:Selected()
		if not x then return end
		if x.recipe then ns.Prof:AskCraft(x) else ns.Recruit:Whisper(ns.Roster:OnlineChar(x.name) or x.name) end
	end, true)
	P.ask:SetPoint("BOTTOMRIGHT", 0, 4)
	P.info = UI:Label(p, Gray(L["Die Liste füllt sich, wenn Gildenmitglieder mit GuildSentinel ihre Berufsfenster öffnen."]), "GameFontHighlightSmall")
	P.info:SetPoint("BOTTOMLEFT", 0, 12)
	P.info:SetPoint("RIGHT", P.ask, "LEFT", -12, 0)
end

-- sicherer Knopf: öffnet per Klick das nächste Berufsfenster (CastSpellByName dürfen Addons nicht)
function P:SecureButton()
	if self.sb then return self.sb end
	local tpl = "SecureActionButtonTemplate" .. (UI.BACKDROP and ("," .. UI.BACKDROP) or "")
	local b = CreateFrame("Button", "GuildSentinelProfButton", UIParent, tpl)
	b:SetSize(240, 28)
	b:SetFrameStrata("DIALOG")
	UI.Box(b, A[1] * 0.45, A[2] * 0.45, A[3] * 0.45, 1, A[1], A[2], A[3], 0.9)
	b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	b.text:SetPoint("CENTER")
	local hl = b:CreateTexture(nil, "HIGHLIGHT")
	hl:SetPoint("TOPLEFT", 1, -1)
	hl:SetPoint("BOTTOMRIGHT", -1, 1)
	hl:SetTexture(UI.WHITE)
	hl:SetVertexColor(1, 1, 1, 0.08)
	b:RegisterForClicks("AnyUp", "AnyDown")
	b:SetAttribute("type", "spell")
	b:SetScript("PreClick", function(self)
		if InCombatLockdown() then return end
		local nxt = ns.Prof:NextToOpen()
		if not nxt then
			ns.Prof.scanned = {}
			nxt = ns.Prof:NextToOpen()
		end
		self:SetAttribute("spell", nxt)
		ns.Prof.announce = true
	end)
	b:SetScript("PostClick", function() C_Timer.After(1, function() P:UpdateSecure() end) end)
	b:Hide()
	self.sb = b
	return b
end

function P:UpdateSecure()
	if InCombatLockdown() then return end
	local b = self:SecureButton()
	local shown = self.panel and self.panel:IsVisible() and UI:IsPageShown("prof")
	if not shown then
		b:Hide()
		b:ClearAllPoints()
		return
	end
	local list = ns.Prof:Openable()
	if #list == 0 then
		b:Hide()
		self.slotHint:SetText(Gray(L["Keine Berufe mit Rezeptfenster gelernt."]))
		return
	end
	local nxt = ns.Prof:NextToOpen() or list[1]
	b.text:SetText(string.format(L["%s einlesen"], nxt))
	b:ClearAllPoints()
	b:SetPoint("TOPRIGHT", self.slot, "TOPRIGHT")
	b:Show()
	self.slotHint:SetText(Gray(L["Oder: jedes Berufsfenster einmal selbst öffnen."]))
end

ns:On("PLAYER_REGEN_DISABLED", function()
	-- vor dem Kampf verstecken (im Kampf dürfte man sichere Knöpfe nicht mehr anfassen)
	if P.sb then P.sb:Hide(); P.sb:ClearAllPoints() end
end)
ns:On("PLAYER_REGEN_ENABLED", function() P:UpdateSecure() end)

function P:MineText()
	local me = ns.Prof:Of(ns.Me())
	if not me or not me.p or not next(me.p) then
		return ORANGE .. L["Deine Berufe sind noch nicht eingelesen."] .. "|r"
	end
	local t = {}
	for prof, x in pairs(me.p) do
		local n = x.n and #x.n or 0
		t[#t + 1] = prof .. " " .. (x.r or "?") .. (n > 0 and Gray(" (" .. n .. ")") or "")
	end
	table.sort(t)
	return L["Deine Berufe: "] .. table.concat(t, ", ")
end

function P:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	self.mine:SetText(self:MineText())
	local profs = ns.Prof:ProfNames()
	self.profList:SetData(profs)
	if self.query ~= "" then
		self.profList:ClearSelection()
		self.results:SetData(ns.Prof:Find(self.query))
		self.ask:SetText(L["Herstellen anfragen"])
	elseif self.selProf then
		self.results:SetData(ns.Prof:Overview()[self.selProf] or {})
		self.ask:SetText(L["Anflüstern"])
	else
		self.results:SetData({})
	end
	self:UpdateButtons()
	self:UpdateSecure()
end

function P:UpdateButtons()
	self.ask:SetEnabled(self.results:Selected() ~= nil)
end

P.onShow = function(_, arg)
	if type(arg) == "string" and arg ~= "" then P.search:SetText(arg); P.query = arg end
	P:Refresh()
end
P.onHide = function() P:UpdateSecure() end
ns:Listen("GS_HIDE", function() P:UpdateSecure() end)
ns:Listen("GS_PROF", WhenShown("prof", function() P:Refresh() end))
ns:Listen("GS_ROSTER", WhenShown("prof", function() P.results:Draw() end))
UI:AddPage(P)

------------------------------------------------------------
-- Seite: Gildenbank
------------------------------------------------------------
local B = { key = "bank", icon = "Interface\\Icons\\INV_Misc_Coin_02" }
B.title = L["Gildenbank"]
B.view = "stock"
B.query = ""
B.donDays = 30

local function ItemText(id, fallback)
	local name, _, q = ns.Item(id)
	if not name then return fallback or ("item:" .. tostring(id)) end
	local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q or 1]
	return (c and c.hex or "|cffffffff") .. name .. "|r"
end

local function DonText(e)
	local parts = {}
	if (e.i or 0) > 0 then parts[#parts + 1] = ItemText(e.i, e.nm) .. ((e.c or 1) > 1 and (" ×" .. e.c) or "") end
	if (e.m or 0) > 0 then parts[#parts + 1] = ns.Money(e.m) end
	return table.concat(parts, " + ")
end

function B.build(p)
	B.panel = p
	B.tabs = UI:Tabs(p, {
		{ key = "stock", text = L["Bestand"] },
		{ key = "wish", text = L["Wunschliste"] },
		{ key = "don", text = L["Spenden"] },
	}, function(key) B.view = key; B:Refresh() end)
	B.tabs:SetPoint("TOPLEFT")
	B.tabs:SetPoint("TOPRIGHT")

	-- Bestand ---------------------------------------------
	local st = CreateFrame("Frame", nil, p)
	st:SetPoint("TOPLEFT", 0, -34)
	st:SetPoint("BOTTOMRIGHT")
	B.stockView = st
	local search = UI:Edit(st, 260, 24, L["Item suchen"])
	search:SetPoint("TOPLEFT")
	search.onChange = function(t) B.query = t; B:Refresh() end
	B.search = search
	B.stockInfo = UI:Label(st, "", "GameFontHighlightSmall")
	B.stockInfo:SetPoint("TOPRIGHT", 0, -6)
	B.stockInfo:SetJustifyH("RIGHT")
	B.stockList = UI:List(st, {
		{ key = "item", title = L["Item"], icon = true },
		{ key = "c", title = L["Anzahl"], width = 70, align = "RIGHT" },
		{ key = "per", title = L["Bei"], width = 200 },
	}, {
		rowH = 22,
		key = function(x) return x.id end,
		icon = function(x) return ns.ItemIcon(x.id) end,
		render = function(x)
			local per = {}
			for char, c in pairs(x.per) do per[#per + 1] = char .. (ns.Count(x.per) > 1 and (" " .. c) or "") end
			table.sort(per)
			return { ItemText(x.id, x.name), tostring(x.c), Gray(table.concat(per, ", ")) }
		end,
		onClick = function() B:UpdateButtons() end,
		onEnter = function(row, x)
			GameTooltip:SetOwner(row, "ANCHOR_CURSOR")
			GameTooltip:SetHyperlink("item:" .. x.id)
			GameTooltip:Show()
		end,
		empty = L["Noch kein Bestand bekannt. Er erscheint, sobald ein Bank-Charakter mit GuildSentinel online ist."],
	})
	B.stockList:SetPoint("TOPLEFT", 0, -32)
	B.stockList:SetPoint("BOTTOMRIGHT", 0, 40)
	B.askCount = UI:Edit(st, 50, 28, "1")
	B.askCount:SetPoint("BOTTOMRIGHT", -190, 4)
	B.askBtn = UI:Button(st, L["Beim Bank-Charakter anfragen"], 180, 28, function()
		local x = B.stockList:Selected()
		if x then ns.Bank:Ask(x.id, tonumber(B.askCount:GetText()) or 1) end
	end, true)
	B.askBtn:SetPoint("BOTTOMRIGHT", 0, 4)
	B.bankChars = UI:Label(st, "", "GameFontHighlightSmall")
	B.bankChars:SetPoint("BOTTOMLEFT", 0, 12)
	B.bankChars:SetPoint("RIGHT", B.askCount, "LEFT", -12, 0)

	-- Wunschliste -----------------------------------------
	local wv = CreateFrame("Frame", nil, p)
	wv:SetPoint("TOPLEFT", 0, -34)
	wv:SetPoint("BOTTOMRIGHT")
	B.wishView = wv
	B.wItem = UI:Edit(wv, 280, 24, L["Item-Name oder Shift-Klick auf ein Item"])
	B.wItem:SetPoint("TOPLEFT")
	UI:AcceptLinks(B.wItem)
	B.wCount = UI:Edit(wv, 50, 24, L["Anz."])
	B.wCount:SetPoint("LEFT", B.wItem, "RIGHT", 6, 0)
	B.wNote = UI:Edit(wv, 220, 24, L["Wofür? (optional)"])
	B.wNote:SetPoint("LEFT", B.wCount, "RIGHT", 6, 0)
	local add = UI:Button(wv, L["Wunsch hinzufügen"], 150, 24, function() B:AddWish() end, true)
	add:SetPoint("LEFT", B.wNote, "RIGHT", 8, 0)
	B.wItem.onEnter = function() B:AddWish() end
	B.wishList = UI:List(wv, {
		{ key = "item", title = L["Item"], icon = true },
		{ key = "c", title = L["Gewünscht"], width = 70, align = "RIGHT" },
		{ key = "have", title = L["In der Bank"], width = 80, align = "RIGHT" },
		{ key = "by", title = L["Von"], width = 110 },
		{ key = "note", title = L["Wofür"], width = 170 },
	}, {
		rowH = 22,
		key = function(x) return x.id end,
		icon = function(x) return (x.w.i or 0) > 0 and ns.ItemIcon(x.w.i) or nil end,
		render = function(x)
			local w = x.w
			local name = (w.i or 0) > 0 and ItemText(w.i, w.n) or w.n
			local have = (w.i or 0) > 0 and ((x.done and GREEN or ORANGE) .. x.have .. "|r") or Gray("?")
			return { x.done and (name .. " " .. GREEN .. L["erfüllt"] .. "|r") or name, tostring(w.c), have, w.by or "", w.note or "" }
		end,
		onClick = function() B:UpdateButtons() end,
		onEnter = function(row, x)
			if (x.w.i or 0) > 0 then
				GameTooltip:SetOwner(row, "ANCHOR_CURSOR")
				GameTooltip:SetHyperlink("item:" .. x.w.i)
				GameTooltip:Show()
			end
		end,
		empty = L["Die Wunschliste ist leer. Trag ein, was die Gilde braucht (z. B. Tränke, Feuerwiderstand-Materialien)."],
	})
	B.wishList:SetPoint("TOPLEFT", 0, -32)
	B.wishList:SetPoint("BOTTOMRIGHT", 0, 40)
	B.wRemove = UI:Button(wv, L["Entfernen"], 120, 28, function()
		local x = B.wishList:Selected()
		if x then ns.Bank:RemoveWish(x.id); B.wishList:ClearSelection() end
	end)
	B.wRemove:SetPoint("BOTTOMRIGHT", 0, 4)
	B.wGive = UI:Button(wv, L["Ich spende das"], 150, 28, function()
		local x = B.wishList:Selected()
		if not x then return end
		local char = ns.Bank:OnlineChar() or ns.Bank:Chars()[1]
		if not char then ns:Print(L["Es ist kein Bank-Charakter festgelegt."]) return end
		local _, link = ns.Item(x.w.i)
		local text = string.format(L["Hallo! Ich hätte %s für die Gildenbank. Per Post oder Handel?"], link or x.w.n)
		if ChatFrame_OpenChat then ChatFrame_OpenChat("/w " .. char .. " " .. text) end
	end, true)
	B.wGive:SetPoint("RIGHT", B.wRemove, "LEFT", -8, 0)

	-- Spenden ---------------------------------------------
	local dv = CreateFrame("Frame", nil, p)
	dv:SetPoint("TOPLEFT", 0, -34)
	dv:SetPoint("BOTTOMRIGHT")
	B.donView = dv
	local h = UI:Header(dv, L["Fleißigste Spender"])
	h:SetPoint("TOPLEFT", 0, -4)
	local dd = UI:Dropdown(dv, 120, function()
		return { { value = 7, text = L["7 Tage"] }, { value = 30, text = L["30 Tage"] }, { value = 0, text = L["Immer"] } }
	end, function() return B.donDays end, function(v) B.donDays = v; B:Refresh() end)
	dd:SetPoint("TOPLEFT", 180, 0)
	B.topList = UI:List(dv, {
		{ key = "n", title = "#", width = 22, align = "RIGHT" },
		{ key = "name", title = L["Name"] },
		{ key = "c", title = L["Spenden"], width = 60, align = "RIGHT" },
		{ key = "g", title = L["Gold"], width = 70, align = "RIGHT" },
	}, {
		render = function(x)
			local r = ns.G().roster[x.name]
			return { tostring(x.rank), ns.Colored(x.name, r and r.c), tostring(x.n), x.gold > 0 and (math.floor(x.gold / 10000) .. "|TInterface\\MoneyFrame\\UI-GoldIcon:0|t") or "" }
		end,
		empty = L["Noch keine Spenden."],
	})
	B.topList:SetPoint("TOPLEFT", 0, -32)
	B.topList:SetPoint("BOTTOMLEFT", 0, 40)
	B.topList:SetWidth(300)

	B.donList = UI:List(dv, {
		{ key = "t", title = L["Zeit"], width = 85 },
		{ key = "n", title = L["Wer"], width = 110 },
		{ key = "what", title = L["Was"] },
		{ key = "k", title = L["Art"], width = 70 },
	}, {
		render = function(e)
			local r = ns.G().roster[e.n]
			local kind = e.k == "in" and (GREEN .. L["Spende"] .. "|r") or (ORANGE .. L["Ausgabe"] .. "|r")
			return { Gray(ns.Date(e.t)), ns.Colored(e.n or "?", r and r.c), DonText(e), kind }
		end,
		onEnter = function(row, e)
			GameTooltip:SetOwner(row, "ANCHOR_CURSOR")
			if (e.i or 0) > 0 then GameTooltip:SetHyperlink("item:" .. e.i) else GameTooltip:AddLine(DonText(e)) end
			GameTooltip:AddLine(L["Bank-Charakter: "] .. tostring(e.b or "?"), 0.7, 0.7, 0.7)
			GameTooltip:Show()
		end,
		empty = L["Handel und Post mit dem Bank-Charakter werden hier automatisch eingetragen."],
	})
	B.donList:SetPoint("TOPLEFT", B.topList, "TOPRIGHT", 10, 0)
	B.donList:SetPoint("BOTTOMRIGHT", 0, 40)

	-- von Hand eintragen (Bank-Charakter oder Offizier)
	B.manName = UI:Edit(dv, 150, 26, L["Name"])
	B.manName:SetPoint("BOTTOMLEFT", 0, 4)
	B.manGold = UI:Edit(dv, 80, 26, L["Gold"])
	B.manGold:SetPoint("LEFT", B.manName, "RIGHT", 6, 0)
	B.manBtn = UI:Button(dv, L["Gold-Spende eintragen"], 170, 26, function()
		local name = ns.Trim(B.manName:GetText())
		local gtext = (B.manGold:GetText() or ""):gsub(",", ".")
		local gold = tonumber(gtext)
		if name == "" or not gold or gold <= 0 then ns:Print(L["Bitte Name und Gold angeben."]) return end
		ns.Bank:AddManual(name, 0, 0, math.floor(gold * 10000), "in")
		B.manName:SetText("")
		B.manGold:SetText("")
	end)
	B.manBtn:SetPoint("LEFT", B.manGold, "RIGHT", 8, 0)
	B.manHint = UI:Label(dv, Gray(L["Nur für Bank-Charakter und Offiziere, z. B. für Gold, das anders übergeben wurde."]), "GameFontHighlightSmall")
	B.manHint:SetPoint("LEFT", B.manBtn, "RIGHT", 12, 0)
	B.manHint:SetPoint("RIGHT", 0, 0)

	B.tabs:Select("stock")
end

function B:AddWish()
	local text = ns.Trim(self.wItem:GetText())
	if text == "" then return end
	local id = ns.ItemID(text)
	local name = text:match("%[(.-)%]")
	if not id then
		local _, link = ns.GetItemInfo(text)
		id = ns.ItemID(link)
		name = text
	end
	if id and not name then name = ns.Item(id) end
	ns.Bank:AddWish(id or 0, name or text, tonumber(self.wCount:GetText()) or 1, ns.Trim(self.wNote:GetText()))
	self.wItem:SetText("")
	self.wCount:SetText("")
	self.wNote:SetText("")
	self.wItem:ClearFocus()
end

function B:UpdateButtons()
	if self.view == "stock" then
		self.askBtn:SetEnabled(self.stockList:Selected() ~= nil and #ns.Bank:Chars() > 0)
	elseif self.view == "wish" then
		local x = self.wishList:Selected()
		self.wRemove:SetEnabled(x ~= nil and ns.Bank:CanEditWish(x.w))
		self.wGive:SetEnabled(x ~= nil)
	end
end

function B:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	self.stockView:SetShown(self.view == "stock")
	self.wishView:SetShown(self.view == "wish")
	self.donView:SetShown(self.view == "don")
	local wishes = ns.Bank:Wishes()
	local open = 0
	for _, x in ipairs(wishes) do if not x.done then open = open + 1 end end
	self.tabs:SetLabel("wish", open > 0 and string.format(L["Wunschliste (%d)"], open) or L["Wunschliste"])
	if self.view == "stock" then
		local items = ns.Bank:Items(self.query)
		self.stockList:SetData(items)
		local last = ns.Bank:LastUpdate()
		self.stockInfo:SetText(string.format(L["%d verschiedene Items · Gold: %s · Stand: %s"], #items, ns.Money(ns.Bank:Gold()), last > 0 and ns.Ago(last) or L["unbekannt"]))
		local chars = ns.Bank:Chars()
		if #chars == 0 then
			self.bankChars:SetText(ORANGE .. L["Kein Bank-Charakter. Ein Offizier legt ihn unter Einstellungen fest."] .. "|r")
		else
			local t = {}
			for _, c in ipairs(chars) do
				local e = ns.Roster.byName[c]
				t[#t + 1] = (e and e.online) and (GREEN .. c .. "|r") or Gray(c)
			end
			self.bankChars:SetText(L["Bank-Charakter: "] .. table.concat(t, ", ") .. ((ns.Bank:Configured() or #ns.RMI:BankChars() > 0) and "" or Gray(L[" (erkannt an Rang/Notiz)"])))
		end
	elseif self.view == "wish" then
		self.wishList:SetData(wishes)
	else
		local top = ns.Bank:TopDonors(self.donDays > 0 and self.donDays or nil)
		for i, x in ipairs(top) do x.rank = i end
		self.topList:SetData(top)
		self.donList:SetData(ns.Bank:Log())
		local can = ns.Bank:IsBankChar() or ns.IsOfficer()
		self.manName:SetShown(can)
		self.manGold:SetShown(can)
		self.manBtn:SetShown(can)
		self.manHint:SetShown(can)
	end
	self:UpdateButtons()
end

B.onShow = function(_, arg)
	if type(arg) == "string" and arg ~= "" then
		B.tabs:Select("stock")
		B.search:SetText(arg)
		B.query = arg
	end
	B:Refresh()
end
ns:Listen("GS_BANK", WhenShown("bank", function() B:Refresh() end))
ns:Listen("GS_ITEMS", WhenShown("bank", function() B:Refresh() end))
ns:Listen("GS_ROSTER", WhenShown("bank", function() B:Refresh() end))
UI:AddPage(B)

------------------------------------------------------------
-- Seite: Einstellungen
------------------------------------------------------------
local S = { key = "settings", icon = "Interface\\Icons\\INV_Misc_Gear_01" }
S.title = L["Einstellungen"]

function S.build(p)
	S.panel = p
	-- linke Spalte
	local h1 = UI:Header(p, L["Mein Main"])
	h1:SetPoint("TOPLEFT", 0, 0)
	S.mainDD = UI:Dropdown(p, 200, function()
		local out = { { value = false, text = Gray(L["nicht festgelegt"]) } }
		local list = {}
		for name in pairs(ns.G().mine) do list[#list + 1] = name end
		table.sort(list)
		for _, n in ipairs(list) do out[#out + 1] = { value = n, text = ns.Colored(n, ns.G().mine[n].c) } end
		return out
	end, function() return ns.G().myMain or false end, function(v)
		if v then ns.Roster:SetMyMain(v) end
	end)
	S.mainDD:SetPoint("TOPLEFT", h1, "BOTTOMLEFT", 0, -6)
	local mh = UI:Label(p, Gray(L["Alle deine Charaktere in dieser Gilde, mit denen du GuildSentinel geladen hast, werden als Twinks dieses Mains angezeigt – bei allen in der Gilde."]), "GameFontHighlightSmall")
	mh:SetPoint("TOPLEFT", S.mainDD, "BOTTOMLEFT", 0, -6)
	mh:SetWidth(360)

	local h2 = UI:Header(p, L["Bank-Charaktere der Gilde"])
	h2:SetPoint("TOPLEFT", mh, "BOTTOMLEFT", 0, -22)
	S.bankEdit = UI:Edit(p, 260, 24, L["Namen, mit Komma getrennt"])
	S.bankEdit:SetPoint("TOPLEFT", h2, "BOTTOMLEFT", 0, -6)
	S.bankSave = UI:Button(p, L["Speichern"], 92, 24, function()
		local list = {}
		for n in (S.bankEdit:GetText() or ""):gmatch("[^,;%s]+") do list[#list + 1] = n end
		ns.Bank:SetChars(list)
		S:Refresh()
	end, true)
	S.bankSave:SetPoint("LEFT", S.bankEdit, "RIGHT", 8, 0)
	S.bankInfo = UI:Label(p, "", "GameFontHighlightSmall")
	S.bankInfo:SetPoint("TOPLEFT", S.bankEdit, "BOTTOMLEFT", 0, -6)
	S.bankInfo:SetWidth(360)

	local h3 = UI:Header(p, L["Anzeige"])
	h3:SetPoint("TOPLEFT", S.bankInfo, "BOTTOMLEFT", 0, -22)
	local mm = UI:Check(p, L["Minimap-Knopf anzeigen"], function() return ns.db.minimapShow end, function(v) ns.db.minimapShow = v; UI:UpdateMinimap() end)
	mm:SetPoint("TOPLEFT", h3, "BOTTOMLEFT", -2, -4)

	local h6 = UI:Header(p, L["Zusammenarbeit mit RaidMaster"])
	h6:SetPoint("TOPLEFT", mm, "BOTTOMLEFT", 2, -22)
	S.rmInfo = UI:Label(p, "", "GameFontHighlightSmall")
	S.rmInfo:SetPoint("TOPLEFT", h6, "BOTTOMLEFT", 0, -6)
	S.rmInfo:SetWidth(360)
	S.rmInfo:SetJustifyV("TOP")

	-- rechte Spalte
	local h4 = UI:Header(p, L["Abgleich in der Gilde"])
	h4:SetPoint("TOPLEFT", 410, 0)
	S.users = UI:Label(p, "", "GameFontHighlightSmall")
	S.users:SetPoint("TOPLEFT", h4, "BOTTOMLEFT", 0, -6)
	S.users:SetWidth(360)
	S.users:SetJustifyV("TOP")
	S.syncBtn = UI:Button(p, L["Jetzt abgleichen"], 150, 26, function() ns.Sync:Request(); ns:Print(L["Abgleich angefragt."]) end)
	S.syncBtn:SetPoint("TOPLEFT", h4, "BOTTOMLEFT", 0, -120)

	local h5 = UI:Header(p, L["So funktioniert's"])
	h5:SetPoint("TOPLEFT", S.syncBtn, "BOTTOMLEFT", 0, -22)
	local help = UI:Label(p, table.concat({
		L["- Mitglieder: Twinks erkennt GuildSentinel an der Notiz ('Twink von Name') oder ihr legt sie fest."],
		L["- Rekrutierung: Rechtsklick auf den Minimap-Knopf postet die Werbung im nächsten Kanal."],
		L["- Berufe: Jeder öffnet seine Berufsfenster einmal, danach weiß die ganze Gilde Bescheid."],
		L["- Gildenbank: Handel und Post mit dem Bank-Charakter werden automatisch als Spende eingetragen."],
		L["- Discord: Der RaidMaster-Uploader nimmt Wunschliste, Spenden, Bankbestand und Verlauf mit."],
		L["- Befehle: /gs, /gs suche <Rezept>, /gs bank <Item>, /gs werbung"],
	}, "\n"), "GameFontHighlightSmall")
	help:SetPoint("TOPLEFT", h5, "BOTTOMLEFT", 0, -6)
	help:SetWidth(360)
	help:SetJustifyV("TOP")
	help:SetSpacing(4)
end

function S:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	self.mainDD.Refresh()
	local cfg = ns.G().cfg
	if not self.bankEdit.edit:HasFocus() then self.bankEdit:SetText(table.concat(cfg.bank or {}, ", ")) end
	local officer = ns.IsOfficer()
	self.bankEdit:SetEnabled(officer)
	self.bankSave:SetEnabled(officer)
	local info
	if ns.Bank:Configured() then
		info = string.format(L["Festgelegt von %s, %s."], cfg.by or "?", ns.Ago(cfg.t))
	elseif #ns.RMI:BankChars() > 0 then
		info = L["Aus RaidMaster übernommen: "] .. table.concat(ns.RMI:BankChars(), ", ")
	else
		local auto = ns.Bank:Chars()
		info = #auto > 0 and (L["Automatisch erkannt (Rang/Notiz mit 'Bank'): "] .. table.concat(auto, ", ")) or L["Noch keiner festgelegt."]
	end
	if not officer then info = info .. "\n" .. L["Nur Offiziere können das ändern."] end
	self.bankInfo:SetText(Gray(info))
	if ns.RMI:Active() then
		self.rmInfo:SetText(GREEN .. string.format(L["RaidMaster %s erkannt."], tostring(ns.RMI:Version() or "")) .. "|r\n"
			.. Gray(L["Berufe und Twinks kommen aus RaidMaster und werden nicht doppelt verschickt. Twinks, die ein Offizier hier festlegt, landen auch in RaidMaster."]))
	else
		self.rmInfo:SetText(Gray(L["RaidMaster ist nicht installiert. GuildSentinel liest und teilt Berufe und Twinks selbst."]))
	end

	local lines = {}
	local list = {}
	for name, u in pairs(ns.Comm.users) do list[#list + 1] = { name = name, v = u.v } end
	table.sort(list, function(a, b) return a.name < b.name end)
	for i, u in ipairs(list) do
		if i > 8 then lines[#lines + 1] = string.format(L["… und %d weitere"], #list - 8) break end
		local r = ns.G().roster[u.name]
		lines[#lines + 1] = ns.Colored(u.name, r and r.c) .. Gray(" v" .. tostring(u.v or "?"))
	end
	if #lines == 0 then lines[1] = Gray(L["Gerade niemand sonst mit GuildSentinel online."]) end
	local best, newer = ns.Comm:NewestVersion()
	if newer then lines[#lines + 1] = "\n" .. GOLD .. string.format(L["Neue Version %s verfügbar!"], best) .. "|r" end
	self.users:SetText(table.concat(lines, "\n"))
end

S.onShow = function() S:Refresh() end
ns:Listen("GS_USERS", WhenShown("settings", function() S:Refresh() end))
ns:Listen("GS_BANK", WhenShown("settings", function() S:Refresh() end))
UI:AddPage(S)
