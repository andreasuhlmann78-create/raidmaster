-- GuildSentinel - Bank.lua
-- Gildenbank: Bestand der Bank-Charaktere, Wunschliste und Spendenprotokoll.
--
-- Bank-Charaktere legt ein Offizier fest (Seite Einstellungen). Ohne Festlegung gilt der Gildenbank-Charakter
-- aus RaidMaster, sonst ein Mitglied, dessen Rang oder öffentliche Notiz "Bank" enthält.
-- Auf dem Bank-Charakter liest GuildSentinel Taschen, Bank (wenn geöffnet) und Briefkasten und schickt
-- den Bestand an die Gilde. Handel und Post mit dem Bank-Charakter landen automatisch im Spendenprotokoll:
-- was er bekommt als Spende, was er abgibt als Ausgabe.
--
--   G.bank[Bank-Char] = { t, g = Gold (Kupfer), i = { [Item-ID] = Anzahl } }
--   G.bankLocal[Item-ID] = { b = Taschen, k = Bank, m = Post }   (nur auf dem Bank-Charakter)
--   G.wishes[id] = { i = Item-ID, n = Name, c = Anzahl, by, t, note, del }
--   G.don = { { id, t, n = Spieler, i = Item-ID, nm = Itemname, q = Qualität, c = Anzahl, m = Kupfer,
--             k = "in"/"out", b = Bank-Char } }
--   G.names[Item-ID] = { n = Name, q = Qualität }   (für den Discord-Bot: der Bestand kommt nur mit IDs)

local ADDON, ns = ...
local L = ns.L
local B = {}
ns.Bank = B

B.DON_MAX = 1000

------------------------------------------------------------
-- Bank-Charaktere
------------------------------------------------------------
function B:Configured()
	local cfg = ns.G().cfg
	return cfg and cfg.bank and #cfg.bank > 0
end

function B:Chars()
	local cfg = ns.G().cfg
	if cfg and cfg.bank and #cfg.bank > 0 then return cfg.bank end
	-- aus RaidMaster (Loot > Gildenbank-Charakter bzw. Einstellungen > Bank-Charakter)
	local rm = ns.RMI:BankChars()
	if #rm > 0 then return rm end
	-- automatisch: Rang oder Notiz enthält "Bank"
	local out = {}
	for _, e in ipairs(ns.Roster.list) do
		local hay = ((e.rank or "") .. " " .. (e.note or "")):lower()
		if hay:find("bank", 1, true) then out[#out + 1] = e.name end
	end
	table.sort(out)
	return out
end

function B:IsBankChar(name)
	name = name or ns.Me()
	for _, n in ipairs(self:Chars()) do
		if ns.Same(n, name) then return true end
	end
	return false
end

function B:SetChars(list)
	local g = ns.guild
	if not g then return end
	local clean = {}
	for _, n in ipairs(list) do
		n = ns.Proper(ns.Trim(n))
		if n and n ~= "" then clean[#clean + 1] = n end
	end
	g.cfg = { t = ns.Now(), bank = clean, by = ns.Me() }
	ns.Comm:Send("CFG", g.cfg)
	ns:Fire("GS_BANK")
	if self:IsBankChar() then self:ScanBags() end
end

ns.Comm:Register("CFG", function(sender, d)
	local g = ns.guild
	if not g or type(d.bank) ~= "table" or type(d.t) ~= "number" then return end
	if (g.cfg.t or 0) >= d.t then return end
	local list = {}
	for _, n in ipairs(d.bank) do if type(n) == "string" then list[#list + 1] = n end end
	g.cfg = { t = d.t, bank = list, by = d.by or sender }
	ns:Fire("GS_BANK")
end)

------------------------------------------------------------
-- Bestand lesen (nur auf dem Bank-Charakter)
------------------------------------------------------------
local function NumSlots(bag)
	if C_Container and C_Container.GetContainerNumSlots then return C_Container.GetContainerNumSlots(bag) or 0 end
	return GetContainerNumSlots and GetContainerNumSlots(bag) or 0
end

local function SlotInfo(bag, slot)
	if C_Container and C_Container.GetContainerItemInfo then
		local info = C_Container.GetContainerItemInfo(bag, slot)
		if info then return info.hyperlink, info.stackCount or 1 end
		return nil
	end
	if GetContainerItemInfo then
		local _, count, _, _, _, _, link = GetContainerItemInfo(bag, slot)
		link = link or (GetContainerItemLink and GetContainerItemLink(bag, slot))
		return link, count or 1
	end
end

local function Collect(from, to, out)
	for bag = from, to do
		for slot = 1, NumSlots(bag) do
			local link, count = SlotInfo(bag, slot)
			local id = ns.ItemID(link)
			if id then out[id] = (out[id] or 0) + (count or 1) end
		end
	end
	return out
end

-- where: "b" (Taschen), "k" (Bank), "m" (Post)
local function Replace(where, counts)
	local loc = ns.G().bankLocal
	for id, e in pairs(loc) do
		e[where] = nil
		if not e.b and not e.k and not e.m then loc[id] = nil end
	end
	for id, c in pairs(counts) do
		loc[id] = loc[id] or {}
		loc[id][where] = c
	end
end

function B:Publish()
	local g = ns.guild
	if not g or not self:IsBankChar() then return end
	local items = {}
	for id, e in pairs(g.bankLocal) do
		local c = (e.b or 0) + (e.k or 0) + (e.m or 0)
		if c > 0 then items[id] = c end
	end
	local me = ns.Me()
	local snap = { t = ns.Now(), g = GetMoney and GetMoney() or 0, i = items }
	g.bank[me] = snap
	ns:Fire("GS_BANK")
	-- an die Gilde (gebündelt)
	if self.sendPending then return end
	self.sendPending = true
	C_Timer.After(45, function()
		self.sendPending = false
		self:SendBank(me)
	end)
end

function B:SendBank(char, channel, target)
	local snap = ns.G().bank[char]
	if not snap then return end
	ns.Comm:Send("BANK", { c = char, t = snap.t, g = snap.g, i = snap.i }, channel or "GUILD", target)
end

ns.Comm:Register("BANK", function(sender, d)
	local g = ns.guild
	if not g or type(d.c) ~= "string" or type(d.i) ~= "table" or type(d.t) ~= "number" then return end
	if ns.Same(d.c, ns.Me()) then return end
	local old = g.bank[d.c]
	if old and (old.t or 0) >= d.t then return end
	local items = {}
	for id, c in pairs(d.i) do
		id, c = tonumber(id), tonumber(c)
		if id and c then items[id] = c end
	end
	g.bank[d.c] = { t = d.t, g = tonumber(d.g) or 0, i = items }
	ns:Fire("GS_BANK")
end)

function B:ScanBags()
	if not ns.guild or not self:IsBankChar() then return end
	Replace("b", Collect(0, NUM_BAG_SLOTS or 4, {}))
	self:Publish()
end

function B:ScanBank()
	if not ns.guild or not self:IsBankChar() or not self.bankOpen then return end
	local counts = Collect(BANK_CONTAINER or -1, BANK_CONTAINER or -1, {})
	local first = (NUM_BAG_SLOTS or 4) + 1
	Collect(first, first + (NUM_BANKBAGSLOTS or 6) - 1, counts)
	Replace("k", counts)
	self:Publish()
end

function B:ScanMailbox()
	if not ns.guild or not self:IsBankChar() or not GetInboxNumItems then return end
	local counts = {}
	for i = 1, GetInboxNumItems() do
		for j = 1, (ATTACHMENTS_MAX_RECEIVE or 12) do
			local link = GetInboxItemLink and GetInboxItemLink(i, j)
			local id = ns.ItemID(link)
			if id then
				local _, _, _, count = GetInboxItem(i, j)
				counts[id] = (counts[id] or 0) + (count or 1)
			end
		end
	end
	Replace("m", counts)
	self:Publish()
end

local function Throttle(key, delay, fn)
	B.timers = B.timers or {}
	if B.timers[key] then return end
	B.timers[key] = true
	C_Timer.After(delay, function() B.timers[key] = nil; fn() end)
end

ns:On("BAG_UPDATE_DELAYED", function() Throttle("bags", 1, function() B:ScanBags(); B:ScanBank() end) end)
ns:On("BAG_UPDATE", function() Throttle("bags", 2, function() B:ScanBags(); B:ScanBank() end) end)
ns:On("PLAYERBANKSLOTS_CHANGED", function() Throttle("bank", 1, function() B:ScanBank() end) end)
ns:On("BANKFRAME_OPENED", function() B.bankOpen = true; C_Timer.After(0.5, function() B:ScanBank() end) end)
ns:On("BANKFRAME_CLOSED", function() B.bankOpen = false end)
ns:On("PLAYER_MONEY", function() Throttle("money", 3, function() if B:IsBankChar() then B:Publish() end end) end)
ns:Listen("GS_ROSTER", function()
	-- Bank-Charakter erst nach dem Lesen der Gilde sicher erkennbar
	if not B.firstScan and next(ns.Roster.byName) then
		B.firstScan = true
		if B:IsBankChar() then B:ScanBags() end
	end
end)

------------------------------------------------------------
-- Spendenprotokoll: Handel
------------------------------------------------------------
local trade

local function TradeSnapshot()
	if not trade then return end
	trade.recv, trade.give = {}, {}
	for i = 1, 6 do
		local link = GetTradeTargetItemLink and GetTradeTargetItemLink(i)
		local id = ns.ItemID(link)
		if id then
			local _, _, count = GetTradeTargetItemInfo(i)
			trade.recv[#trade.recv + 1] = { i = id, c = count or 1 }
		end
		link = GetTradePlayerItemLink and GetTradePlayerItemLink(i)
		id = ns.ItemID(link)
		if id then
			local _, _, count = GetTradePlayerItemInfo(i)
			trade.give[#trade.give + 1] = { i = id, c = count or 1 }
		end
	end
	trade.mRecv = GetTargetTradeMoney and GetTargetTradeMoney() or 0
	trade.mGive = GetPlayerTradeMoney and GetPlayerTradeMoney() or 0
end

ns:On("TRADE_SHOW", function()
	if not B:IsBankChar() then trade = nil return end
	trade = { who = ns.Short(UnitName("NPC")) }
end)
for _, ev in ipairs({ "TRADE_TARGET_ITEM_CHANGED", "TRADE_PLAYER_ITEM_CHANGED", "TRADE_MONEY_CHANGED", "TRADE_ACCEPT_UPDATE" }) do
	ns:On(ev, TradeSnapshot)
end

ns:On("UI_INFO_MESSAGE", function(a, b)
	if not trade then return end
	if a ~= ERR_TRADE_COMPLETE and b ~= ERR_TRADE_COMPLETE then return end
	local t = trade
	trade = nil
	if not t.who or t.who == "" then return end
	local list = {}
	for _, x in ipairs(t.recv or {}) do list[#list + 1] = { n = t.who, i = x.i, c = x.c, k = "in" } end
	if (t.mRecv or 0) > 0 then list[#list + 1] = { n = t.who, m = t.mRecv, k = "in" } end
	for _, x in ipairs(t.give or {}) do list[#list + 1] = { n = t.who, i = x.i, c = x.c, k = "out" } end
	if (t.mGive or 0) > 0 then list[#list + 1] = { n = t.who, m = t.mGive, k = "out" } end
	B:AddEntries(list)
end)
ns:On("TRADE_CLOSED", function()
	-- Abschluss kommt vor TRADE_CLOSED; abgebrochener Handel bleibt so ohne Eintrag
	C_Timer.After(1, function() trade = nil end)
end)

------------------------------------------------------------
-- Spendenprotokoll: Post
------------------------------------------------------------
local inbox = {}

local function SkipSender(sender)
	if not sender or sender == "" then return true end
	sender = ns.Short(sender)
	if ns.G().mine[sender] then return true end       -- eigene Charaktere
	if B:IsBankChar(sender) then return true end
	return false
end

local function SnapshotInbox()
	wipe(inbox)
	if not GetInboxNumItems then return end
	for i = 1, GetInboxNumItems() do
		local _, _, sender, _, money, cod, _, hasItem, _, _, _, _, isGM = GetInboxHeaderInfo(i)
		local invoice = GetInboxInvoiceInfo and GetInboxInvoiceInfo(i)
		local m = { who = ns.Short(sender), money = money or 0, cod = cod or 0, skip = (invoice ~= nil) or isGM or SkipSender(sender), items = {} }
		if hasItem then
			for j = 1, (ATTACHMENTS_MAX_RECEIVE or 12) do
				local id = ns.ItemID(GetInboxItemLink and GetInboxItemLink(i, j))
				if id then
					local _, _, _, count = GetInboxItem(i, j)
					m.items[j] = { i = id, c = count or 1 }
				end
			end
		end
		inbox[i] = m
	end
end

ns:On("MAIL_INBOX_UPDATE", function()
	if not B:IsBankChar() then return end
	SnapshotInbox()
	Throttle("mail", 1, function() B:ScanMailbox() end)
end)

local function TookItem(i, j)
	local m = inbox[i]
	if not m or m.skip or (m.cod or 0) > 0 then return end
	local it = m.items[j]
	if it then
		m.items[j] = nil
		B:AddEntries({ { n = m.who, i = it.i, c = it.c, k = "in" } })
	end
end

local function TookMoney(i)
	local m = inbox[i]
	if not m or m.skip or (m.money or 0) <= 0 then return end
	local money = m.money
	m.money = 0
	B:AddEntries({ { n = m.who, m = money, k = "in" } })
end

if hooksecurefunc then
	if TakeInboxItem then hooksecurefunc("TakeInboxItem", function(i, j) if B:IsBankChar() then TookItem(i, j) end end) end
	if TakeInboxMoney then hooksecurefunc("TakeInboxMoney", function(i) if B:IsBankChar() then TookMoney(i) end end) end
	if AutoLootMailItem then
		hooksecurefunc("AutoLootMailItem", function(i)
			if not B:IsBankChar() then return end
			for j = 1, (ATTACHMENTS_MAX_RECEIVE or 12) do TookItem(i, j) end
			TookMoney(i)
		end)
	end
	-- Post verschicken = Ausgabe
	if SendMail then
		hooksecurefunc("SendMail", function(recipient)
			if not B:IsBankChar() then return end
			local to = ns.Short(recipient)
			if SkipSender(to) then B.outgoing = nil return end
			local list = {}
			for j = 1, (ATTACHMENTS_MAX_SEND or 12) do
				local id = ns.ItemID(GetSendMailItemLink and GetSendMailItemLink(j))
				if id then
					local _, _, _, count = GetSendMailItem(j)
					list[#list + 1] = { n = to, i = id, c = count or 1, k = "out" }
				end
			end
			local money = GetSendMailMoney and GetSendMailMoney() or 0
			if money > 0 then list[#list + 1] = { n = to, m = money, k = "out" } end
			B.outgoing = list
		end)
	end
end

ns:On("MAIL_SEND_SUCCESS", function()
	if B.outgoing and #B.outgoing > 0 then B:AddEntries(B.outgoing) end
	B.outgoing = nil
end)
ns:On("MAIL_FAILED", function() B.outgoing = nil end)

------------------------------------------------------------
-- Einträge speichern und teilen
------------------------------------------------------------
local counter = 0

local function Insert(e)
	local don = ns.G().don
	for _, x in ipairs(don) do
		if x.id == e.id then return false end
	end
	-- nach Zeit einsortieren (neueste zuerst)
	local pos = #don + 1
	for k, x in ipairs(don) do
		if (x.t or 0) <= (e.t or 0) then pos = k break end
	end
	table.insert(don, pos, e)
	while #don > B.DON_MAX do table.remove(don) end
	return true
end

function B:AddEntries(list)
	if not ns.guild or #list == 0 then return end
	local out = {}
	local now = ns.Now()
	for _, x in ipairs(list) do
		counter = counter + 1
		local e = { id = ns.Me() .. now .. counter, t = now, n = x.n, i = x.i or 0, c = x.c or 0, m = x.m or 0, k = x.k, b = ns.Me() }
		if e.i > 0 then
			local name, _, q = ns.Item(e.i)
			e.nm, e.q = name, q
		end
		if Insert(e) then out[#out + 1] = e end
	end
	if #out == 0 then return end
	local gave, took = 0, 0
	for _, e in ipairs(out) do if e.k == "in" then gave = gave + 1 else took = took + 1 end end
	if gave > 0 then ns:Print(string.format(L["Spende von %s eingetragen. Danke!"], out[1].n)) end
	ns.Comm:Send("DON", { e = out })
	ns:Fire("GS_BANK")
end

-- von Hand: Spende oder Ausgabe (z. B. Gold, das bar übergeben wurde)
function B:AddManual(name, itemID, count, copper, kind)
	if not name or ns.Trim(name) == "" then return end
	self:AddEntries({ { n = ns.Proper(name), i = itemID or 0, c = count or 0, m = copper or 0, k = kind or "in" } })
end

ns.Comm:Register("DON", function(sender, d)
	if type(d.e) ~= "table" then return end
	local any
	for _, e in ipairs(d.e) do
		if type(e) == "table" and type(e.id) == "string" and type(e.t) == "number" and (e.k == "in" or e.k == "out") then
			if Insert({ id = e.id, t = e.t, n = e.n, i = tonumber(e.i) or 0, c = tonumber(e.c) or 0, m = tonumber(e.m) or 0, k = e.k, b = e.b or sender,
				nm = type(e.nm) == "string" and e.nm or nil, q = tonumber(e.q) }) then any = true end
		end
	end
	if any then ns:Fire("GS_BANK") end
end)

------------------------------------------------------------
-- Wunschliste
------------------------------------------------------------
function B:AddWish(itemID, name, count, note)
	local g = ns.guild
	if not g then return end
	counter = counter + 1
	local id = ns.Me() .. ns.Now() .. counter
	local w = { i = itemID or 0, n = name or "", c = math.max(1, tonumber(count) or 1), by = ns.Me(), t = ns.Now(), note = note or "" }
	g.wishes[id] = w
	ns.Comm:Send("WISH", { e = { [id] = w } })
	ns:Fire("GS_BANK")
end

function B:RemoveWish(id)
	local g = ns.guild
	local w = g and g.wishes[id]
	if not w then return end
	w.del = true
	w.t = ns.Now()
	ns.Comm:Send("WISH", { e = { [id] = w } })
	ns:Fire("GS_BANK")
end

function B:CanEditWish(w)
	return ns.IsOfficer() or ns.Same(w.by, ns.Me()) or self:IsBankChar()
end

ns.Comm:Register("WISH", function(sender, d)
	local g = ns.guild
	if not g or type(d.e) ~= "table" then return end
	local any
	for id, w in pairs(d.e) do
		if type(id) == "string" and type(w) == "table" and type(w.t) == "number" then
			local old = g.wishes[id]
			if not old or (old.t or 0) < w.t then
				g.wishes[id] = { i = tonumber(w.i) or 0, n = w.n or "", c = tonumber(w.c) or 1, by = w.by or sender, t = w.t, note = w.note or "", del = w.del and true or nil }
				any = true
			end
		end
	end
	if any then ns:Fire("GS_BANK") end
end)

function B:Wishes()
	local out = {}
	for id, w in pairs(ns.G().wishes) do
		if not w.del then
			local have = (w.i and w.i > 0) and self:Count(w.i) or 0
			out[#out + 1] = { id = id, w = w, have = have, done = have >= (w.c or 1) }
		end
	end
	table.sort(out, function(a, b)
		if a.done ~= b.done then return not a.done end
		return (a.w.t or 0) > (b.w.t or 0)
	end)
	return out
end

-- alte, gelöschte Wünsche nach 30 Tagen vergessen
ns:Listen("GS_LOGIN", function()
	local g = ns.guild
	if not g then return end
	local limit = ns.Now() - 30 * 86400
	for id, w in pairs(g.wishes) do
		if w.del and (w.t or 0) < limit then g.wishes[id] = nil end
	end
end)

------------------------------------------------------------
-- Abfragen
------------------------------------------------------------
-- Anzahl eines Items über alle Bank-Charaktere
function B:Count(id)
	local n = 0
	for _, snap in pairs(ns.G().bank) do n = n + ((snap.i and snap.i[id]) or 0) end
	return n
end

function B:Gold()
	local g = 0
	for _, snap in pairs(ns.G().bank) do g = g + (snap.g or 0) end
	return g
end

function B:LastUpdate()
	local t = 0
	for _, snap in pairs(ns.G().bank) do if (snap.t or 0) > t then t = snap.t end end
	return t
end

-- Bestand: { { id, c, name, q, per = { [Char] = Anzahl } } }
function B:Items(query)
	query = ns.Trim(query):lower()
	local merged = {}
	for char, snap in pairs(ns.G().bank) do
		for id, c in pairs(snap.i or {}) do
			local m = merged[id]
			if not m then
				m = { id = id, c = 0, per = {} }
				merged[id] = m
			end
			m.c = m.c + c
			m.per[char] = (m.per[char] or 0) + c
		end
	end
	local out = {}
	for id, m in pairs(merged) do
		local name, _, q = ns.Item(id)
		m.name, m.q = name or ("item:" .. id), q or 1
		if query == "" or m.name:lower():find(query, 1, true) then out[#out + 1] = m end
	end
	table.sort(out, function(a, b)
		if a.q ~= b.q then return a.q > b.q end
		return a.name < b.name
	end)
	return out
end

-- Spender-Rangliste: { { name, items, gold, n } } (nur Spenden, keine Ausgaben)
function B:TopDonors(days)
	local limit = days and (ns.Now() - days * 86400) or 0
	local by = {}
	for _, e in ipairs(ns.G().don) do
		if e.k == "in" and (e.t or 0) >= limit and e.n then
			local main = ns.Roster:MainOf(e.n) or e.n
			local d = by[main]
			if not d then d = { name = main, items = 0, gold = 0, n = 0 }; by[main] = d end
			d.items = d.items + (e.c or 0)
			d.gold = d.gold + (e.m or 0)
			d.n = d.n + 1
		end
	end
	local out = {}
	for _, d in pairs(by) do out[#out + 1] = d end
	table.sort(out, function(a, b)
		if a.n ~= b.n then return a.n > b.n end
		return a.gold > b.gold
	end)
	return out
end

function B:Log(kind)
	local out = {}
	for _, e in ipairs(ns.G().don) do
		if not kind or e.k == kind then out[#out + 1] = e end
	end
	return out
end

-- Bank-Charakter, der gerade online ist (für Anfragen)
function B:OnlineChar()
	for _, n in ipairs(self:Chars()) do
		local e = ns.Roster.byName[n]
		if e and e.online then return n end
	end
	return nil
end

function B:Ask(id, count)
	local char = self:OnlineChar() or self:Chars()[1]
	if not char then ns:Print(L["Es ist kein Bank-Charakter festgelegt."]) return end
	local _, link = ns.Item(id)
	local text = string.format(L["Hallo! Könnte ich %s ×%d aus der Gildenbank bekommen? Wofür: "], link or ("item:" .. id), count or 1)
	if ChatFrame_OpenChat then ChatFrame_OpenChat("/w " .. char .. " " .. text) end
end

------------------------------------------------------------
-- Itemnamen merken (der Bestand reist nur mit IDs; der Discord-Bot braucht die Namen)
------------------------------------------------------------
function B:CacheNames()
	local g = ns.guild
	if not g then return end
	g.names = g.names or {}
	local missing = 0
	local function Want(id)
		id = tonumber(id)
		if not id or id <= 0 or g.names[id] then return end
		local name, _, q = ns.Item(id)     -- fragt das Item beim Server an, falls unbekannt
		if name then g.names[id] = { n = name, q = q } else missing = missing + 1 end
	end
	for _, snap in pairs(g.bank) do
		for id in pairs(snap.i or {}) do Want(id) end
	end
	for _, w in pairs(g.wishes) do if not w.del then Want(w.i) end end
	for _, e in ipairs(g.don) do Want(e.i) end
	return missing
end

ns:Listen("GS_BANK", function()
	if B.namePending then return end
	B.namePending = true
	C_Timer.After(3, function() B.namePending = false; B:CacheNames() end)
end)
ns:Listen("GS_ITEMS", function() B:CacheNames() end)
ns:Listen("GS_LOGIN", function() C_Timer.After(30, function() B:CacheNames() end) end)
