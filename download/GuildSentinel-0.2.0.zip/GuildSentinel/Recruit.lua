-- GuildSentinel - Recruit.lua
-- Rekrutierung: Werbetext in öffentlichen Kanälen posten, Bewerber aus Flüsternachrichten sammeln,
-- automatisch antworten und neue Mitglieder im Gildenchat begrüßen.
--
-- Öffentliche Kanäle erlauben Addon-Nachrichten nur direkt nach einem Mausklick. Darum postet jeder
-- Klick auf "Werbung posten" in genau einen Kanal (der nächste kommt beim nächsten Klick dran).

local ADDON, ns = ...
local L = ns.L
local Rc = {}
ns.Recruit = Rc

Rc.CHANNEL_COOLDOWN = 60      -- Sekunden je Kanal
Rc.GLOBAL_COOLDOWN = 8        -- Sekunden zwischen zwei Klicks
Rc.lastPost = {}              -- [Kanal] = GetTime()
Rc.lastAny = 0
Rc.lastAdTime = 0             -- Serverzeit der letzten Werbung (für die Erinnerung)

------------------------------------------------------------
-- Texte
------------------------------------------------------------
function Rc:DefaultAd()
	return L["<{gilde}> sucht Mitstreiter! Raids, Dungeons und eine entspannte Gemeinschaft. {discord} Flüstert mich an: /w {name} gilde"]
end

function Rc:DefaultReply()
	return L["Hallo {spieler}! Danke für dein Interesse an <{gilde}>. Ein Offizier meldet sich gleich bei dir. {discord}"]
end

function Rc:DefaultWelcome()
	return L["Willkommen bei <{gilde}>, {spieler}! Schön, dass du da bist. {discord}"]
end

function Rc:DefaultKeywords()
	return L["gilde, guild, beitreten, join, ginv, bewerbung"]
end

local function Value(key, default)
	local v = ns.db[key]
	if not v or ns.Trim(v) == "" then return default end
	return v
end

-- Platzhalter füllen und Leerstellen sauber machen
function Rc:Build(text, extra)
	local discord = ns.Trim(ns.db.discord)
	local total, online = ns.Roster:Stats()
	local vars = {
		gilde = ns.GuildName() or "",
		name = ns.Me() or "",
		discord = discord ~= "" and (L["Discord: "] .. discord) or "",
		mitglieder = total or 0,
		online = online or 0,
	}
	for k, v in pairs(extra or {}) do vars[k] = v end
	local s = ns.Fill(text, vars)
	s = s:gsub("%s+", " "):gsub("%s+([%.,!%?])", "%1"):gsub("<>", "")
	s = ns.Trim(s)
	if #s > 255 then s = s:sub(1, 252) .. "..." end
	return s
end

function Rc:AdText()
	return self:Build(Value("adText", self:DefaultAd()))
end

------------------------------------------------------------
-- Kanäle
------------------------------------------------------------
-- beigetretene Kanäle: { { name, id } }
function Rc:Joined()
	local out = {}
	if not GetChannelName then return out end
	for i = 1, 20 do
		local id, name = GetChannelName(i)
		if id and id > 0 and name and name ~= "" then
			out[#out + 1] = { name = name, id = id, short = name:match("^([^%-]+)") and ns.Trim(name:match("^([^%-]+)")) or name }
		end
	end
	return out
end

local function Kind(name)
	local n = name:lower()
	if n:find("^world") or n:find("^welt") or n:find("global") then return 1 end
	if n:find("looking") or n:find("suche") or n:find("lfg") then return 2 end
	if n:find("^trade") or n:find("^handel") then return 3 end
	if n:find("^general") or n:find("^allgemein") then return 4 end
	return 5
end

-- Beim ersten Mal sinnvolle Kanäle vorwählen (Welt, Gruppensuche, Handel)
function Rc:EnsureTargets()
	if ns.db.adTargetsInit then return end
	local list = self:Joined()
	if #list == 0 then return end
	ns.db.adTargets = ns.db.adTargets or {}
	for _, c in ipairs(list) do
		if Kind(c.name) <= 3 then ns.db.adTargets[c.short:lower()] = true end
	end
	ns.db.adTargetsInit = true
end

function Rc:IsTarget(short)
	return ns.db.adTargets and ns.db.adTargets[short:lower()] and true or false
end

function Rc:SetTarget(short, on)
	ns.db.adTargets = ns.db.adTargets or {}
	ns.db.adTargets[short:lower()] = on and true or nil
	ns.db.adTargetsInit = true
	ns:Fire("GS_RECRUIT")
end

-- gewählte, beigetretene Kanäle in sinnvoller Reihenfolge
function Rc:Targets()
	local out = {}
	for _, c in ipairs(self:Joined()) do
		if self:IsTarget(c.short) then out[#out + 1] = c end
	end
	table.sort(out, function(a, b)
		local ka, kb = Kind(a.name), Kind(b.name)
		if ka == kb then return a.id < b.id end
		return ka < kb
	end)
	return out
end

-- nächster Kanal, der wieder dran ist (nil, Sekunden bis frei)
function Rc:NextTarget()
	local now = GetTime()
	local best, wait = nil, math.huge
	for _, c in ipairs(self:Targets()) do
		local left = (self.lastPost[c.short] or -1000) + self.CHANNEL_COOLDOWN - now
		if left <= 0 then return c, 0 end
		if left < wait then best, wait = c, left end
	end
	return nil, (wait < math.huge) and math.ceil(wait) or nil, best
end

function Rc:GlobalWait()
	return math.max(0, math.ceil(self.lastAny + self.GLOBAL_COOLDOWN - GetTime()))
end

------------------------------------------------------------
-- Posten (nur aus einem Klick)
------------------------------------------------------------
function Rc:Post()
	if not IsInGuild() then ns:Print(L["Du bist in keiner Gilde."]) return false end
	local gw = self:GlobalWait()
	if gw > 0 then
		ns:Print(string.format(L["Bitte noch %d Sekunden warten."], gw))
		return false
	end
	local targets = self:Targets()
	if #targets == 0 then
		ns:Print(L["Kein Kanal gewählt oder keinem gewählten Kanal beigetreten. Wähle die Kanäle auf der Seite Rekrutierung."])
		return false
	end
	local c, wait = self:NextTarget()
	if not c then
		ns:Print(string.format(L["Alle gewählten Kanäle hatten gerade Werbung. Nächster in %d Sekunden."], wait or 0))
		return false
	end
	local text = self:AdText()
	if text == "" then return false end
	SendChatMessage(text, "CHANNEL", nil, c.id)
	self.lastPost[c.short] = GetTime()
	self.lastAny = GetTime()
	self.lastAdTime = ns.Now()
	ns.db.lastAdTime = self.lastAdTime
	self.reminded = false
	ns:Fire("GS_RECRUIT")
	return true
end

-- Erinnerung, wenn die Werbung wieder fällig ist
C_Timer.NewTicker(30, function()
	if not ns.db or not ns.db.adRemind or not IsInGuild() then return end
	local last = ns.db.lastAdTime or 0
	if last == 0 or Rc.reminded then return end
	if ns.Now() - last >= (ns.db.adInterval or 15) * 60 then
		Rc.reminded = true
		ns:Print(L["Die Gildenwerbung ist wieder fällig. Minimap-Knopf: Rechtsklick postet sie."])
		ns:Fire("GS_RECRUIT")
	end
end)

function Rc:Due()
	local last = ns.db and ns.db.lastAdTime or 0
	return last > 0 and ns.Now() - last >= (ns.db.adInterval or 15) * 60
end

------------------------------------------------------------
-- Bewerber
------------------------------------------------------------
-- st: new, invited, declined, joined
function Rc:Keywords()
	local list = {}
	for w in Value("keywords", self:DefaultKeywords()):gmatch("[^,;]+") do
		w = ns.Trim(w):lower()
		if w ~= "" then list[#list + 1] = w end
	end
	return list
end

function Rc:Matches(msg)
	msg = (msg or ""):lower()
	for _, w in ipairs(self:Keywords()) do
		if msg:find(w, 1, true) then return true end
	end
	return false
end

function Rc:AddApplicant(name, msg, classFile, race)
	local g = ns.guild
	if not g then return end
	name = ns.Short(name)
	local a = g.apps[name] or { t = ns.Now(), st = "new" }
	a.msg = msg or a.msg
	a.last = ns.Now()
	a.c = classFile or a.c
	a.race = race or a.race
	if a.st == "declined" then a.st = "new" end
	g.apps[name] = a
	ns:Fire("GS_APPS")
	return a
end

function Rc:Applicants(showAll)
	local out = {}
	for name, a in pairs(ns.G().apps) do
		if showAll or (a.st ~= "joined" and a.st ~= "declined") then
			out[#out + 1] = { name = name, a = a }
		end
	end
	table.sort(out, function(x, y) return (x.a.last or x.a.t or 0) > (y.a.last or y.a.t or 0) end)
	return out
end

function Rc:Invite(name)
	if not ns.CanInvite() then ns:Print(L["Dein Rang darf niemanden in die Gilde einladen."]) return end
	GuildInvite(name)
	local a = ns.G().apps[name]
	if a then a.st = "invited"; a.ti = ns.Now() end
	ns:Fire("GS_APPS")
end

function Rc:SetStatus(name, st)
	local a = ns.G().apps[name]
	if not a then return end
	a.st = st
	ns:Fire("GS_APPS")
end

function Rc:Remove(name)
	ns.G().apps[name] = nil
	ns:Fire("GS_APPS")
end

function Rc:Whisper(name)
	if ChatFrame_SendTell then ChatFrame_SendTell(name) end
end

local replied = {}

ns:On("CHAT_MSG_WHISPER", function(msg, sender, _, _, _, _, _, _, _, _, _, guid)
	if not ns.guild or not ns.db then return end
	local name = ns.Short(sender)
	if not name or ns.Roster.byName[name] then return end      -- schon in der Gilde
	local known = ns.guild.apps[name]
	if not known and not Rc:Matches(msg) then return end
	local classFile, race
	if guid and GetPlayerInfoByGUID then
		local _, cf, _, rc = GetPlayerInfoByGUID(guid)
		classFile, race = cf, rc
	end
	Rc:AddApplicant(name, msg, classFile, race)
	if not known then ns:Print(string.format(L["Neuer Bewerber: %s – siehe Seite Rekrutierung."], name)) end
	-- automatisch antworten (einmal je 10 Minuten)
	if ns.db.autoReply and (not replied[name] or GetTime() - replied[name] > 600) then
		replied[name] = GetTime()
		local text = Rc:Build(Value("replyText", Rc:DefaultReply()), { spieler = name })
		if text ~= "" then
			C_Timer.After(1.5, function() SendChatMessage(text, "WHISPER", nil, sender) end)
		end
	end
end)

------------------------------------------------------------
-- Begrüßung neuer Mitglieder (nur einer begrüßt: wer zuerst Bescheid gibt)
------------------------------------------------------------
Rc.claimed = {}

Rc.claimBy = {}

ns.Comm:Register("WEL", function(sender, d)
	if type(d.n) ~= "string" then return end
	Rc.claimed[d.n] = GetTime()
	-- bei gleichzeitigem Anspruch gewinnt der alphabetisch erste Name
	local cur = Rc.claimBy[d.n]
	if not cur or sender < cur then Rc.claimBy[d.n] = sender end
end)

ns:Listen("GS_JOINED", function(name)
	if not ns.db or not ns.db.welcome or ns.Same(name, ns.Me()) then return end
	C_Timer.After(1 + math.random() * 4, function()
		local c = Rc.claimed[name]
		if c and GetTime() - c < 60 then return end
		Rc.claimed[name] = GetTime()
		Rc.claimBy[name] = ns.Me()
		ns.Comm:Send("WEL", { n = name }, "GUILD", nil, true)
		C_Timer.After(2, function()
			if Rc.claimBy[name] ~= ns.Me() then return end
			local text = Rc:Build(Value("welcomeText", Rc:DefaultWelcome()), { spieler = name })
			if text ~= "" then SendChatMessage(text, "GUILD") end
		end)
	end)
end)

-- Vorschau der Begrüßung
function Rc:WelcomePreview()
	return self:Build(Value("welcomeText", self:DefaultWelcome()), { spieler = L["Neuling"] })
end

function Rc:ReplyPreview()
	return self:Build(Value("replyText", self:DefaultReply()), { spieler = L["Bewerber"] })
end

ns:Listen("GS_LOGIN", function()
	Rc.lastAdTime = ns.db.lastAdTime or 0
	C_Timer.After(5, function() Rc:EnsureTargets() end)
end)
ns:On("CHANNEL_UI_UPDATE", function() Rc:EnsureTargets(); ns:Fire("GS_RECRUIT") end)
