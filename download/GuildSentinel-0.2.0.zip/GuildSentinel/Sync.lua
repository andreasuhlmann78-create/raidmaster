-- GuildSentinel - Sync.lua
-- Abgleich beim Einloggen: Ich sage der Gilde, welchen Stand ich habe. Einer, der online ist, schickt mir
-- per Flüstern, was mir fehlt (Berufe, Bankbestand, Wunschliste, Spenden, Twinks, Bank-Charaktere).

local ADDON, ns = ...
local L = ns.L
local S = {}
ns.Sync = S

S.claimed = {}        -- [Anfragender] = GetTime()
S.lastSync = 0

local function MaxT(t, field)
	local m = 0
	for _, v in pairs(t or {}) do
		local x = type(v) == "table" and v[field or "t"] or nil
		if type(x) == "number" and x > m then m = x end
	end
	return m
end

function S:Digest()
	local g = ns.G()
	local p, b = {}, {}
	for name, e in pairs(ns.Prof:All()) do p[name] = e.t or 0 end
	for char, snap in pairs(g.bank) do b[char] = snap.t or 0 end
	local d = 0
	for _, e in ipairs(g.don) do if (e.t or 0) > d then d = e.t end end
	return { p = p, b = b, w = MaxT(g.wishes), a = MaxT(g.alts), d = d, c = g.cfg.t or 0 }
end

function S:Request()
	if not ns.guild or not IsInGuild() then return end
	self.lastSync = GetTime()
	ns.Comm:Send("SREQ", self:Digest())
	ns:Fire("GS_SYNC")
end

-- Antwort an einen Anfragenden (per Flüstern)
function S:Answer(to, d)
	local g = ns.guild
	if not g then return end
	local sent = 0
	-- kleine Dinge zuerst (die Leitung ist gedrosselt), Berufe zum Schluss
	-- Bank-Charaktere
	if (g.cfg.t or 0) > (tonumber(d.c) or 0) then ns.Comm:Send("CFG", g.cfg, "WHISPER", to); sent = sent + 1 end
	-- Twinks
	local at = tonumber(d.a) or 0
	local alts = {}
	for ch, a in pairs(g.alts) do if (a.t or 0) > at then alts[ch] = a end end
	if next(alts) then ns.Comm:Send("ALT", { e = alts }, "WHISPER", to); sent = sent + 1 end
	-- Wunschliste
	local wt = tonumber(d.w) or 0
	local wishes = {}
	for id, w in pairs(g.wishes) do if (w.t or 0) > wt then wishes[id] = w end end
	if next(wishes) then ns.Comm:Send("WISH", { e = wishes }, "WHISPER", to); sent = sent + 1 end
	-- Bankbestand
	local b = type(d.b) == "table" and d.b or {}
	for char, snap in pairs(g.bank) do
		if (snap.t or 0) > (tonumber(b[char]) or 0) then
			ns.Bank:SendBank(char, "WHISPER", to)
			sent = sent + 1
		end
	end
	-- Spenden (die neuesten 100, in Paketen)
	local dt = tonumber(d.d) or 0
	local batch, n = {}, 0
	for _, e in ipairs(g.don) do
		if (e.t or 0) <= dt or n >= 100 then break end
		batch[#batch + 1] = e
		n = n + 1
		if #batch >= 20 then
			ns.Comm:Send("DON", { e = batch }, "WHISPER", to)
			batch = {}
			sent = sent + 1
		end
	end
	if #batch > 0 then ns.Comm:Send("DON", { e = batch }, "WHISPER", to); sent = sent + 1 end
	-- Berufe (nur von Mitgliedern, neueste zuerst)
	local p = type(d.p) == "table" and d.p or {}
	local list = {}
	local all = ns.Prof:All()
	for name, e in pairs(all) do
		if not ns.Same(name, to) and (e.t or 0) > (tonumber(p[name]) or 0) and type(e.p) == "table"
			and (ns.Roster.byName[name] or not next(ns.Roster.byName)) then
			list[#list + 1] = name
		end
	end
	table.sort(list, function(x, y) return (all[x].t or 0) > (all[y].t or 0) end)
	for _, name in ipairs(list) do
		local e = all[name]
		ns.Comm:Send("PROF", { n = name, c = e.c, t = e.t, p = e.p }, "WHISPER", to)
		sent = sent + 1
	end
	if ns.debug then ns:Print(string.format("sync -> %s: %d", to, sent)) end
end

ns.Comm:Register("SREQ", function(sender, d, channel)
	if channel ~= "GUILD" or not ns.guild then return end
	ns.Comm:Seen(sender)
	-- kurz warten: Wer zuerst "ich mach's" sagt, antwortet
	C_Timer.After(1 + math.random() * 5, function()
		local c = S.claimed[sender]
		if c and GetTime() - c < 30 then return end
		S.claimed[sender] = GetTime()
		ns.Comm:Send("SCLAIM", { to = sender }, "GUILD", nil, true)
		C_Timer.After(0.5, function() S:Answer(sender, d) end)
	end)
end)

ns.Comm:Register("SCLAIM", function(sender, d)
	if type(d.to) == "string" then S.claimed[d.to] = GetTime() end
end)

ns:Listen("GS_LOGIN", function()
	C_Timer.After(25, function() S:Request() end)
end)
