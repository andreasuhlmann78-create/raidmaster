-- ============================================================
-- AH Analyzer Pro 4.0 - Schwebender Button
-- Linksklick: Fenster   Rechtsklick: Scan   Ziehen: verschieben
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local C = A.UI.C

local SIZE = 38

local function SavePosition(btn)
    local point, _, relPoint, x, y = btn:GetPoint()
    if A.db then
        A.db.settings.buttonPos = { point = point, relPoint = relPoint, x = x, y = y }
    end
end

local function ApplyPosition(btn)
    btn:ClearAllPoints()
    local pos = A.db and A.db.settings.buttonPos
    if pos and pos.point and pos.x and pos.y then
        btn:SetPoint(pos.point, UIParent, pos.relPoint or pos.point, pos.x, pos.y)
    else
        btn:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -230, -40)
    end
end

local function CreateButton()
    if A.FloatingButton then return A.FloatingButton end

    local btn = CreateFrame("Button", "AHAnalyzerProFloatingButton", UIParent)
    btn:SetSize(SIZE, SIZE)
    btn:SetFrameStrata("MEDIUM")
    btn:SetFrameLevel(50)
    btn:SetClampedToScreen(true)
    btn:SetMovable(true)
    btn:EnableMouse(true)
    btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    btn:RegisterForDrag("LeftButton")

    local bg = btn:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.05, 0.05, 0.07, 0.95)

    local icon = btn:CreateTexture(nil, "ARTWORK")
    icon:SetPoint("TOPLEFT", 3, -3)
    icon:SetPoint("BOTTOMRIGHT", -3, 3)
    icon:SetTexture("Interface\\Icons\\INV_Misc_Coin_02")
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    btn.icon = icon

    -- Rahmen (Farbe zeigt den Status)
    btn.edges = {}
    for i = 1, 4 do btn.edges[i] = btn:CreateTexture(nil, "OVERLAY") end
    local t, b, l, r = unpack(btn.edges)
    t:SetPoint("TOPLEFT"); t:SetPoint("TOPRIGHT"); t:SetHeight(2)
    b:SetPoint("BOTTOMLEFT"); b:SetPoint("BOTTOMRIGHT"); b:SetHeight(2)
    l:SetPoint("TOPLEFT"); l:SetPoint("BOTTOMLEFT"); l:SetWidth(2)
    r:SetPoint("TOPRIGHT"); r:SetPoint("BOTTOMRIGHT"); r:SetWidth(2)
    function btn:SetBorderColor(c)
        for _, e in ipairs(self.edges) do e:SetColorTexture(c[1], c[2], c[3], c[4] or 1) end
    end

    -- Abdunklung während der Sperrzeit
    btn.shade = btn:CreateTexture(nil, "OVERLAY")
    btn.shade:SetPoint("BOTTOMLEFT", 3, 3)
    btn.shade:SetPoint("BOTTOMRIGHT", -3, 3)
    btn.shade:SetColorTexture(0, 0, 0, 0.6)
    btn.shade:Hide()

    -- Restzeit unter dem Button
    btn.timer = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    btn.timer:SetPoint("TOP", btn, "BOTTOM", 0, -2)

    local hl = btn:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints(icon)
    hl:SetColorTexture(1, 1, 1, 0.15)

    -- Ziehen ohne versehentlichen Klick
    btn:SetScript("OnDragStart", function(self)
        self.dragging = true
        self:StartMoving()
    end)
    btn:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        SavePosition(self)
        self.dragEnded = GetTime()
        self.dragging = false
    end)

    btn:SetScript("OnClick", function(self, mouseButton)
        if self.dragEnded and GetTime() - self.dragEnded < 0.2 then return end
        if mouseButton == "RightButton" then
            A:StartFullScan()
        else
            A.UI:Toggle()
        end
    end)

    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("AH Analyzer Pro", C.accent[1], C.accent[2], C.accent[3])
        GameTooltip:AddLine(" ")
        if A.db then
            GameTooltip:AddDoubleLine(L["Items in der Datenbank:"], tostring(A:CountTable(A.db.marketData)), 0.8, 0.8, 0.8, 1, 1, 1)
            GameTooltip:AddDoubleLine(L["Letzter Scan:"], A:FormatAgo(A.db.lastScanTime), 0.8, 0.8, 0.8, 1, 1, 1)
            if A:IsScanning() then
                GameTooltip:AddDoubleLine(L["Scan:"], L["läuft gerade"], 0.8, 0.8, 0.8, 1, 0.8, 0.2)
            elseif A:IsScanReady() then
                GameTooltip:AddDoubleLine(L["Scan:"], L["bereit"], 0.8, 0.8, 0.8, 0.2, 0.9, 0.3)
            else
                GameTooltip:AddDoubleLine(L["Scan möglich in:"], A:FormatDuration(A:GetCooldownRemaining()), 0.8, 0.8, 0.8, 1, 0.4, 0.3)
            end
            if A.Watchlist and A.Watchlist:CountAlerts() > 0 then
                GameTooltip:AddDoubleLine(L["Watchlist-Alarme:"], tostring(A.Watchlist:CountAlerts()), 0.8, 0.8, 0.8, 0.2, 0.9, 0.3)
            end
        end
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine(L["Linksklick: Fenster öffnen/schließen"], 0.6, 0.6, 0.6)
        GameTooltip:AddLine(L["Rechtsklick: Markt scannen"], 0.6, 0.6, 0.6)
        GameTooltip:AddLine(L["Ziehen: Button verschieben"], 0.6, 0.6, 0.6)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Status jede halbe Sekunde
    local elapsed = 1
    btn:SetScript("OnUpdate", function(self, dt)
        elapsed = elapsed + dt
        if elapsed < 0.5 then return end
        elapsed = 0
        if A:IsScanning() then
            self:SetBorderColor(C.yellow)
            self.shade:Hide()
            self.timer:SetText(L["|cffffcc33Scan|r"])
        elseif A:IsScanReady() then
            self:SetBorderColor(A:IsAHOpen() and C.green or C.accent)
            self.shade:Hide()
            self.timer:SetText("")
        else
            local remaining = A:GetCooldownRemaining()
            self:SetBorderColor(C.red)
            self.shade:SetHeight(math.max(1, (SIZE - 6) * remaining / A.SCAN_COOLDOWN))
            self.shade:Show()
            self.timer:SetText(A:FormatDuration(remaining))
        end
    end)

    ApplyPosition(btn)
    btn:Show()
    A.FloatingButton = btn
    return btn
end

function A:ResetButtonPosition()
    if self.db then self.db.settings.buttonPos = nil end
    if self.FloatingButton then
        ApplyPosition(self.FloatingButton)
        self.FloatingButton:Show()
    end
    self:Print(L["Positionen zurückgesetzt."])
end

-- Button erst erstellen, wenn die gespeicherten Daten geladen sind
A:On("READY", function()
    CreateButton()
end)
