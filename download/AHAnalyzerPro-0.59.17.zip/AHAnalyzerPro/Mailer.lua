-- ============================================================
-- AH Analyzer Pro 5.7 - Briefkasten: Post abholen
--
-- Am Briefkasten erscheinen zwei Knöpfe:
--   "AH-Post abholen" - Gold und Items aus Auktionspost (verkauft,
--                        gekauft, abgelaufen, abgebrochen, überboten)
--   "Alles"           - jede Post (außer Nachnahme)
-- Vorher werden alle Rechnungen für die Buchhaltung gelesen.
-- Abgeholt wird eins nach dem anderen (der Server braucht kurz),
-- bei vollen Taschen wird angehalten. Nachnahme (COD) wird nie bezahlt.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local M = {}
A.Mailer = M

local STEP = 0.35          -- Sekunden zwischen zwei Aktionen
local WAIT_MAX = 3         -- so lange auf die Antwort des Servers warten

M.running = false

-- Betreff-Muster der Auktionspost aus Blizzards eigenen Texten (jede Sprache)
local function SubjectPatterns()
    local out = {}
    for _, g in ipairs({ "AUCTION_SOLD_MAIL_SUBJECT", "AUCTION_WON_MAIL_SUBJECT", "AUCTION_EXPIRED_MAIL_SUBJECT",
                         "AUCTION_REMOVED_MAIL_SUBJECT", "AUCTION_OUTBID_MAIL_SUBJECT" }) do
        local fmt = _G[g]
        if type(fmt) == "string" and fmt ~= "" then
            local esc = fmt:gsub("([%(%)%.%+%-%*%?%[%]%^%$])", "%%%1")
            esc = esc:gsub("%%s", ".+")
            esc = esc:gsub("%%d", "%%d+")
            local pat = "^" .. esc
            table.insert(out, pat)
        end
    end
    return out
end

function M:IsAuctionMail(i)
    local okI, invoiceType = pcall(GetInboxInvoiceInfo, i)
    if okI and invoiceType then return true end
    local ok, _, _, sender, subject = pcall(GetInboxHeaderInfo, i)
    if not ok then return false end
    for _, pat in ipairs(self.patterns or {}) do
        if type(subject) == "string" and subject:find(pat) then return true end
    end
    return false
end

local function FreeSlots()
    local n = 0
    for bag = 0, (NUM_BAG_SLOTS or 4) do
        if C_Container and C_Container.GetContainerNumFreeSlots then
            n = n + (select(1, C_Container.GetContainerNumFreeSlots(bag)) or 0)
        elseif GetContainerNumFreeSlots then
            n = n + (select(1, GetContainerNumFreeSlots(bag)) or 0)
        end
    end
    return n
end

local function FirstAttachment(i)
    if not GetInboxItem then return nil end
    for a = 1, (ATTACHMENTS_MAX_RECEIVE or 16) do
        local ok, name, itemID = pcall(GetInboxItem, i, a)
        if ok and (name or itemID) then return a, itemID end
    end
    return nil
end

-- nächste Post mit etwas zum Abholen
function M:NextMail()
    local n = GetInboxNumItems and GetInboxNumItems() or 0
    for i = 1, n do
        local ok, _, _, sender, subject, money, cod, _, itemCount = pcall(GetInboxHeaderInfo, i)
        if ok and (not cod or cod == 0) and ((money or 0) > 0 or (itemCount or 0) > 0) then
            if not self.onlyAH or self:IsAuctionMail(i) then
                return i, money or 0, itemCount or 0
            end
        end
    end
    return nil
end

function M:Start(onlyAH)
    if self.running then return false, L["Läuft schon ..."] end
    if not (GetInboxNumItems and TakeInboxMoney) then return false, L["Dein Client unterstützt das Abholen der Post nicht."] end
    self.patterns = SubjectPatterns()
    self.onlyAH = onlyAH and true or false
    -- erst die Rechnungen buchen, bevor die Post verschwindet
    if A.Ledger then pcall(A.Ledger.ScanInbox, A.Ledger) end
    self.running = true
    self.money, self.items, self.mails = 0, 0, 0
    self.waiting, self.lastAction = nil, 0
    self.startMoney = GetMoney and GetMoney() or 0
    A:Fire("MAILER_CHANGED")
    return true, onlyAH and L["Hole Auktionspost ab ..."] or L["Hole alle Post ab ..."]
end

function M:Stop(reason)
    if not self.running then return end
    self.running = false
    local gained = (GetMoney and GetMoney() or 0) - (self.startMoney or 0)
    local msg = string.format(L["Post abgeholt: %s, %d Items"], A:FormatMoney(math.max(0, gained)), self.items)
    if reason then msg = msg .. " - " .. reason end
    A:Print(msg)
    A:Fire("MAILER_CHANGED")
end

function M:Step()
    if not self.running then return end
    if not (MailFrame and MailFrame.IsShown and MailFrame:IsShown()) then return self:Stop(L["Briefkasten geschlossen"]) end
    local now = GetTime()
    if self.waiting and now - self.lastAction < WAIT_MAX then return end
    if now - self.lastAction < STEP then return end
    self.waiting = nil
    local i, money, itemCount = self:NextMail()
    if not i then return self:Stop() end
    if money > 0 then
        pcall(TakeInboxMoney, i)
    else
        if FreeSlots() == 0 then return self:Stop(L["|cffff5544Taschen voll|r"]) end
        local a = FirstAttachment(i)
        if not a then
            -- Anzahl gemeldet, aber kein Anhang lesbar: Post überspringen
            self.skip = (self.skip or 0) + 1
            if self.skip > 5 then return self:Stop() end
            return
        end
        pcall(TakeInboxItem, i, a)
        self.items = self.items + 1
    end
    self.waiting = true
    self.lastAction = now
end

local evt = CreateFrame("Frame")
for _, e in ipairs({ "MAIL_SHOW", "MAIL_CLOSED", "MAIL_INBOX_UPDATE", "UI_ERROR_MESSAGE" }) do pcall(evt.RegisterEvent, evt, e) end
evt:SetScript("OnEvent", function(_, event, a1, a2)
    if event == "MAIL_SHOW" then
        M:EnsureButtons()
    elseif event == "MAIL_CLOSED" then
        if M.running then M:Stop(L["Briefkasten geschlossen"]) end
    elseif event == "MAIL_INBOX_UPDATE" then
        M.waiting = nil      -- Server hat geantwortet
    elseif event == "UI_ERROR_MESSAGE" and M.running then
        local msg = tostring(a2 or a1 or "")
        if ERR_INV_FULL and msg == ERR_INV_FULL or msg:lower():find("voll") or msg:lower():find("full") then
            M:Stop(L["|cffff5544Taschen voll|r"])
        end
    end
end)
local acc = 0
evt:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    if acc < 0.1 then return end
    acc = 0
    if M.running then M:Step() end
end)

-- Knöpfe am Briefkasten
function M:EnsureButtons()
    if self.buttons or not (A.db and A.db.settings.mailButtons ~= false) then
        if self.buttons then self.buttons:Show() end
        return
    end
    local parent = (type(InboxFrame) == "table" and InboxFrame) or (type(MailFrame) == "table" and MailFrame)
    if not parent then return end
    local UI = A.UI
    local f = CreateFrame("Frame", "AHAnalyzerProMailButtons", parent)
    f:SetSize(250, 24)
    f:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -60, -32)
    f:SetFrameLevel((parent.GetFrameLevel and parent:GetFrameLevel() or 1) + 10)
    f.ah = UI:Button(f, L["AH-Post abholen"], 140, 22, function()
        local ok, msg = M:Start(true)
        if msg then A:Print(msg) end
    end, "primary")
    f.ah:SetPoint("LEFT", 0, 0)
    f.ah.tooltip = L["Holt Gold und Items aus der Auktionspost ab (nacheinander).\nRechnungen werden vorher für die Buchhaltung gelesen."]
    f.all = UI:Button(f, L["Alles"], 60, 22, function()
        local ok, msg = M:Start(false)
        if msg then A:Print(msg) end
    end)
    f.all:SetPoint("LEFT", f.ah, "RIGHT", 4, 0)
    f.all.tooltip = L["Holt jede Post ab (Nachnahme wird nie bezahlt)"]
    f.stop = UI:Button(f, "X", 24, 22, function() M:Stop(L["angehalten"]) end, "danger")
    f.stop:SetPoint("LEFT", f.all, "RIGHT", 4, 0)
    f.stop.tooltip = L["Anhalten"]
    self.buttons = f
end

A:On("THEME_CHANGED", function()
    if M.buttons then M.buttons:Hide(); M.buttons = nil end
end)
