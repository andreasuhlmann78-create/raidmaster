-- ============================================================
-- AH Analyzer Pro 5.7 - Berufe: Gewinn pro Rezept
--
-- Neben dem Berufsfenster (Alchemie, Schmiedekunst, ... und
-- Verzauberkunst) erscheint ein kleines Fenster:
--   * gewähltes Rezept: Materialkosten, Wert des Ergebnisses, Gewinn
--     nach AH-Gebühr
--   * die besten Rezepte nach Gewinn (Klick wählt das Rezept)
--   * Materialien für N-mal herstellen als Einkaufsliste anlegen
-- Preise: Marktwert (Median 14 Tage) aus deinen Scans.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local Cr = {}
A.Crafting = Cr

local AH_CUT = 0.05

local function IDFromLink(link)
    return type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil
end

local function SafeCall(fn, ...)
    if not fn then return nil end
    local r = { pcall(fn, ...) }
    if not r[1] then return nil end
    return unpack(r, 2)
end

-- ------------------------------------------------------------
-- Zwei Arten von Berufsfenstern in Classic:
--   "trade" = Handwerk (TradeSkill-API), "craft" = Verzauberkunst (Craft-API)
-- ------------------------------------------------------------
local API = {
    trade = {
        num = function() return GetNumTradeSkills and SafeCall(GetNumTradeSkills) or 0 end,
        info = function(i)
            local name, kind = SafeCall(GetTradeSkillInfo, i)
            return name, kind
        end,
        link = function(i) return GetTradeSkillItemLink and SafeCall(GetTradeSkillItemLink, i) end,
        made = function(i)
            if not GetTradeSkillNumMade then return 1, 1 end
            local lo, hi = SafeCall(GetTradeSkillNumMade, i)
            return lo or 1, hi or lo or 1
        end,
        numReagents = function(i) return GetTradeSkillNumReagents and SafeCall(GetTradeSkillNumReagents, i) or 0 end,
        reagent = function(i, r)
            local name, _, count, have = SafeCall(GetTradeSkillReagentInfo, i, r)
            local link = GetTradeSkillReagentItemLink and SafeCall(GetTradeSkillReagentItemLink, i, r)
            return name, count, have, link
        end,
        selected = function() return GetTradeSkillSelectionIndex and SafeCall(GetTradeSkillSelectionIndex) end,
        select = function(i)
            if TradeSkillFrame_SetSelection then pcall(TradeSkillFrame_SetSelection, i) end
            if TradeSkillFrame_Update then pcall(TradeSkillFrame_Update) end
        end,
        title = function() return GetTradeSkillLine and SafeCall(GetTradeSkillLine) end,
        frame = function() return type(TradeSkillFrame) == "table" and TradeSkillFrame or nil end,
    },
    craft = {
        num = function() return GetNumCrafts and SafeCall(GetNumCrafts) or 0 end,
        info = function(i)
            local name, _, kind = SafeCall(GetCraftInfo, i)
            return name, kind
        end,
        link = function(i) return GetCraftItemLink and SafeCall(GetCraftItemLink, i) end,
        made = function(i) return 1, 1 end,
        numReagents = function(i) return GetCraftNumReagents and SafeCall(GetCraftNumReagents, i) or 0 end,
        reagent = function(i, r)
            local name, _, count, have = SafeCall(GetCraftReagentInfo, i, r)
            local link = GetCraftReagentItemLink and SafeCall(GetCraftReagentItemLink, i, r)
            return name, count, have, link
        end,
        selected = function() return GetCraftSelectionIndex and SafeCall(GetCraftSelectionIndex) end,
        select = function(i)
            if CraftFrame_SetSelection then pcall(CraftFrame_SetSelection, i) end
            if CraftFrame_Update then pcall(CraftFrame_Update) end
        end,
        title = function() return GetCraftDisplaySkillLine and SafeCall(GetCraftDisplaySkillLine) end,
        frame = function() return type(CraftFrame) == "table" and CraftFrame or nil end,
    },
}
Cr.API = API
Cr.kind = nil          -- gerade offenes Berufsfenster: "trade" / "craft" / nil

-- Preis eines Materials/Ergebnisses: Marktwert, sonst aktuelles Angebot
-- Materialien: beim Händler kaufen, wenn das billiger ist (Preis wird beim Händler gelesen)
function Cr:UnitPrice(itemID, isReagent)
    if not itemID then return nil end
    local mv = A:GetMarketValue(itemID)
    if not mv then
        local pr = A.Seller and A.Seller:GetPriceInfo(itemID)
        mv = pr and pr.lowestOther or nil
    end
    if isReagent then
        local buy = A:GetVendorBuyPrice(itemID)
        if buy and (not mv or buy < mv) then return buy, true end
    end
    return mv
end

-- ein Rezept vollständig lesen und bewerten
function Cr:ReadRecipe(kind, i)
    local api = API[kind]
    local name, skillType = api.info(i)
    if not name or skillType == "header" then return nil end
    local productID = IDFromLink(api.link(i))
    local lo, hi = api.made(i)
    local made = ((lo or 1) + (hi or lo or 1)) / 2
    local r = { index = i, name = name, productID = productID, made = made, reagents = {}, cost = 0, missing = 0, kind = kind }
    for k = 1, api.numReagents(i) do
        local rname, count, have, link = api.reagent(i, k)
        local id = IDFromLink(link)
        local unit, atVendor = self:UnitPrice(id, true)
        table.insert(r.reagents, { itemID = id, name = rname or (id and A:GetItemName(id)) or "?", count = count or 1,
                                   have = have or 0, unit = unit, atVendor = atVendor })
        if unit then r.cost = r.cost + unit * (count or 1) else r.missing = r.missing + 1 end
    end
    local unitValue = productID and self:UnitPrice(productID)
    if unitValue then
        r.value = math.floor(unitValue * made + 0.5)
        r.net = math.floor(r.value * (1 - AH_CUT) + 0.5)
        if r.missing == 0 then r.profit = r.net - r.cost end
    end
    return r
end

function Cr:ReadAll(kind)
    kind = kind or self.kind
    local out = {}
    if not kind then return out end
    for i = 1, API[kind].num() do
        local r = self:ReadRecipe(kind, i)
        if r then table.insert(out, r) end
    end
    return out
end

-- die besten Rezepte (mit bekanntem Gewinn)
function Cr:Top(kind, n)
    local list = {}
    for _, r in ipairs(self:ReadAll(kind)) do
        if r.profit then table.insert(list, r) end
    end
    table.sort(list, function(a, b) return a.profit > b.profit end)
    local out = {}
    for k = 1, math.min(n or 10, #list) do out[k] = list[k] end
    return out, #list
end

-- Materialien für "times"-mal herstellen auf eine Einkaufsliste (Name = Beruf)
function Cr:ReagentsToList(kind, index, times)
    local r = self:ReadRecipe(kind, index)
    if not r then return false, L["Kein Rezept gewählt."] end
    times = math.max(1, math.floor(tonumber(times) or 1))
    local listName = API[kind].title() or L["Berufe"]
    if not A.Lists:Exists(listName) then A.Lists:Create(listName) end
    local added = 0
    for _, re in ipairs(r.reagents) do
        if re.itemID then
            A.Lists:AddItem(listName, tostring(re.itemID), re.count * times)
            added = added + 1
        end
    end
    if added == 0 then return false, L["Keine Materialien mit bekanntem Item gefunden."] end
    return true, string.format(L["Materialien für %dx %s auf die Liste '%s' gesetzt."], times, r.name, listName), listName
end

-- ------------------------------------------------------------
-- Fenster neben dem Berufsfenster
-- ------------------------------------------------------------
function Cr:Enabled()
    return not (A.db and A.db.settings.craftPanel == false)
end

function Cr:EnsurePanel()
    if self.panel then return self.panel end
    local UI = A.UI
    local C = UI.C
    local f = CreateFrame("Frame", "AHAnalyzerProCraftPanel", UIParent)
    f:SetSize(300, 430)
    f:SetFrameStrata("HIGH")
    f:EnableMouse(true)
    UI:Box(f, C.bg, C.frameEdge, UI:IsClassic() and 2 or 1)
    f:Hide()

    f.title = UI:Label(f, "|cff00d1d1AH Analyzer|r  " .. L["Gewinn"], "GameFontNormal", C.accent)
    f.title:SetPoint("TOPLEFT", 12, -10)
    f.close = UI:CloseButton(f, function() f:Hide(); Cr.closedByUser = true end)
    f.close:SetPoint("TOPRIGHT", -4, -4)

    f.recipe = UI:Label(f, "", "GameFontNormalSmall", C.text)
    f.recipe:SetPoint("TOPLEFT", 12, -34)
    f.recipe:SetWidth(276)
    if f.recipe.SetWordWrap then f.recipe:SetWordWrap(false) end

    local function row(label, y)
        local l = UI:Label(f, label, "GameFontHighlightSmall", C.textDim)
        l:SetPoint("TOPLEFT", 12, y)
        local v = UI:Label(f, "-", "GameFontHighlightSmall", C.text)
        v:SetPoint("TOPRIGHT", -12, y)
        v:SetJustifyH("RIGHT")
        v:SetWidth(150)
        return v
    end
    f.cost = row(L["Materialkosten"], -54)
    f.value = row(L["Wert des Ergebnisses"], -70)
    f.cut = row(L["AH-Gebühr (5 %)"], -86)
    f.profit = row(L["Gewinn"], -104)
    f.note = UI:Label(f, "", "GameFontDisableSmall", C.textDim)
    f.note:SetPoint("TOPLEFT", 12, -122)
    f.note:SetWidth(276)

    f.times = UI:EditBox(f, 44, 22, "1")
    f.times:SetPoint("TOPLEFT", 12, -142)
    f.times:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    f.listBtn = UI:Button(f, L["Materialien als Einkaufsliste"], 226, 22, function()
        local idx = API[Cr.kind or "trade"].selected()
        local ok, msg, listName = Cr:ReagentsToList(Cr.kind, idx, tonumber(f.times:GetText()) or 1)
        A:Print(msg)
        if ok and A.UI.ShowLists then A.UI:ShowLists(listName) end
    end)
    f.listBtn:SetPoint("LEFT", f.times, "RIGHT", 6, 0)
    f.listBtn.tooltip = L["Legt die Materialien (x Anzahl links) als Einkaufsliste an.\nDort: Preise prüfen und als Sniper-Ziele kaufen."]

    local th = UI:Label(f, L["Beste Rezepte (Gewinn)"], "GameFontNormalSmall", C.accent)
    th:SetPoint("TOPLEFT", 12, -176)
    f.top = UI:Table(f, {
        columns = {
            { key = "name", title = L["Rezept"], width = 150 },
            { key = "profit", title = L["Gewinn"], width = 98, align = "RIGHT" },
        },
        rows = 9,
        rowHeight = 20,
        itemTooltip = false,
        noMenu = true,
        idKey = "index",
        cell = function(r, key)
            if key == "name" then return r.name end
            local v = r.profit
            return v >= 0 and ("|cff33dd55" .. A:FormatMoney(v, true) .. "|r") or ("|cffff5544-" .. A:FormatMoney(-v, true) .. "|r")
        end,
        onClick = function(r)
            API[r.kind].select(r.index)
            Cr:Refresh()
        end,
        emptyText = L["Noch keine Preise.\nErst im Auktionshaus scannen."],
    })
    f.top:SetPoint("TOPLEFT", 10, -192)
    self.panel = f

    -- Auswahl im Berufsfenster verfolgen
    local last, acc = nil, 0
    f:SetScript("OnUpdate", function(_, dt)
        acc = acc + (dt or 0)
        if acc < 0.3 then return end
        acc = 0
        local idx = Cr.kind and API[Cr.kind].selected()
        if idx ~= last then last = idx; Cr:Refresh() end
    end)
    return f
end

function Cr:Refresh()
    local f = self.panel
    if not f or not f:IsShown() or not self.kind then return end
    local api = API[self.kind]
    local idx = api.selected()
    local r = idx and self:ReadRecipe(self.kind, idx)
    if r then
        f.recipe:SetText(r.name .. ((r.made ~= 1) and string.format("  (x%g)", r.made) or ""))
        f.cost:SetText(r.missing > 0 and (A:FormatMoney(r.cost) .. " |cffff5544+?|r") or A:FormatMoney(r.cost))
        f.value:SetText(r.value and A:FormatMoney(r.value) or "-")
        f.cut:SetText(r.value and A:FormatMoney(r.value - r.net) or "-")
        if r.profit then
            f.profit:SetText(r.profit >= 0 and ("|cff33dd55" .. A:FormatMoney(r.profit) .. "|r") or ("|cffff5544-" .. A:FormatMoney(-r.profit) .. "|r"))
        else
            f.profit:SetText("-")
        end
        local notes = {}
        if not r.productID then table.insert(notes, L["Ergebnis ist kein Item (z.B. Verzauberung) - nur Kosten."])
        elseif not r.value then table.insert(notes, L["Für das Ergebnis gibt es noch keinen Preis."]) end
        if r.missing > 0 then table.insert(notes, string.format(L["%d Materialien ohne Preis (z.B. nur beim Händler)."], r.missing)) end
        f.note:SetText(table.concat(notes, "\n"))
    else
        f.recipe:SetText(L["Kein Rezept gewählt."])
        for _, v in ipairs({ f.cost, f.value, f.cut, f.profit }) do v:SetText("-") end
        f.note:SetText("")
    end
    local top = self:Top(self.kind, 9)
    f.top.selectedID = idx
    f.top:SetData(top, true)
end

function Cr:Open(kind)
    self.kind = kind
    if not self:Enabled() or self.closedByUser then return end
    local f = self:EnsurePanel()
    local parent = API[kind].frame()
    f:ClearAllPoints()
    if parent then f:SetPoint("TOPLEFT", parent, "TOPRIGHT", -30, -12) else f:SetPoint("CENTER", 300, 0) end
    f:Show()
    self:Refresh()
end

function Cr:Close(kind)
    if kind and self.kind ~= kind then return end
    self.kind = nil
    self.closedByUser = nil
    if self.panel then self.panel:Hide() end
end

local evt = CreateFrame("Frame")
for _, e in ipairs({ "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE", "TRADE_SKILL_CLOSE", "CRAFT_SHOW", "CRAFT_UPDATE", "CRAFT_CLOSE" }) do
    pcall(evt.RegisterEvent, evt, e)
end
evt:SetScript("OnEvent", function(_, event)
    if event == "TRADE_SKILL_SHOW" then Cr:Open("trade")
    elseif event == "CRAFT_SHOW" then Cr:Open("craft")
    elseif event == "TRADE_SKILL_CLOSE" then Cr:Close("trade")
    elseif event == "CRAFT_CLOSE" then Cr:Close("craft")
    else Cr:Refresh() end
end)

A:On("DATA_CHANGED", function() Cr:Refresh() end)
A:On("THEME_CHANGED", function()
    if Cr.panel then Cr.panel:Hide(); Cr.panel = nil end
    if Cr.kind then Cr:Open(Cr.kind) end
end)
