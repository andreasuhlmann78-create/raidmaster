-- ============================================================
-- AH Analyzer Pro 5.7 - Fenster "Einkaufslisten"
--   links:  Listen (neu, umbenennen, löschen)
--   rechts: Items der Liste mit Menge, in den Taschen, günstigstem
--           Angebot und % vom Marktwert; Preise prüfen; als Sniper-Ziele
-- Öffnen: Knopf im Tab Sniper, Rechtsklick auf ein Item, /ahp listen,
--         oder aus dem Berufsfenster ("Materialien als Einkaufsliste").
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

function UI:ShowLists(selectName)
    local Li = A.Lists
    if not self.listsWindow then
        local w = self:Dialog("AHAnalyzerProLists", 810, 470, L["Einkaufslisten"])

        local function setMessage(ok, msg)
            if not msg then return end
            w.message:SetText(msg)
            w.message:SetTextColor(unpack(ok and C.textDim or C.red))
        end

        -- ---------- Listen ----------
        w.newName = UI:EditBox(w, 150, 22, L["Name der Liste"])
        w.newName:SetPoint("TOPLEFT", 14, -40)
        w.newName:SetMaxLetters(40)
        local function create()
            local ok, msg, name = Li:Create(w.newName:GetText())
            setMessage(ok, msg)
            if ok then
                w.newName:SetText(""); w.newName:ClearFocus(); w.newName:UpdatePlaceholder()
                w.selected = name
                w:Refresh()
            end
        end
        w.newName:SetScript("OnEnterPressed", create)
        w.newBtn = UI:Button(w, L["Neu"], 56, 22, create, "primary")
        w.newBtn:SetPoint("LEFT", w.newName, "RIGHT", 4, 0)

        w.lists = UI:Table(w, {
            columns = {
                { key = "name", title = L["Liste"], width = 150 },
                { key = "count", title = L["Items"], width = 50, align = "RIGHT" },
            },
            rows = 13,
            rowHeight = 22,
            idKey = "name",
            sortKey = "name",
            noMenu = true,
            itemTooltip = false,
            cell = function(e, key) return key == "count" and tostring(e.count) or e.name end,
            sortValue = function(e, key) return key == "count" and e.count or string.lower(e.name) end,
            onClick = function(e) w.selected = e.name; w:Refresh() end,
            emptyText = L["Noch keine Listen.\nOben einen Namen eingeben."],
        })
        w.lists:SetPoint("TOPLEFT", 14, -70)

        w.renameBtn = UI:Button(w, L["Umbenennen"], 110, 22, function()
            if not w.selected then return setMessage(false, L["Erst eine Liste wählen."]) end
            local ok, msg, name = Li:Rename(w.selected, w.newName:GetText())
            setMessage(ok, msg)
            if ok then w.selected = name; w.newName:SetText(""); w.newName:UpdatePlaceholder(); w:Refresh() end
        end)
        w.renameBtn:SetPoint("TOPLEFT", w.lists, "BOTTOMLEFT", 0, -6)
        w.renameBtn.tooltip = L["Gewählte Liste umbenennen: neuen Namen oben eintragen, dann hier klicken"]
        w.deleteBtn = UI:Button(w, L["Löschen"], 110, 22, function()
            if not w.selected then return setMessage(false, L["Erst eine Liste wählen."]) end
            -- zweiter Klick nötig
            if w.confirmDelete ~= w.selected then
                w.confirmDelete = w.selected
                w.deleteBtn:SetText(L["Wirklich löschen?"])
                return setMessage(false, L["Nochmal klicken, um die Liste zu löschen."])
            end
            w.confirmDelete = nil
            setMessage(Li:Delete(w.selected))
            w.selected = nil
            w:Refresh()
        end, "danger")
        w.deleteBtn:SetPoint("LEFT", w.renameBtn, "RIGHT", 6, 0)

        -- ---------- Inhalt ----------
        local x0 = 256
        w.listTitle = UI:Label(w, "", "GameFontNormalLarge", C.accent)
        w.listTitle:SetPoint("TOPLEFT", x0, -40)
        w.listTitle:SetWidth(500)

        w.item = UI:EditBox(w, 220, 22, L["Item: Name, ID oder Shift-Klick"])
        w.item:SetPoint("TOPLEFT", x0, -68)
        UI:AttachItemSearch(w.item, { onPick = function() w.qty:SetFocus() end })
        w.qty = UI:EditBox(w, 56, 22, L["Menge"])
        w.qty:SetPoint("LEFT", w.item, "RIGHT", 4, 0)
        local function add()
            if not w.selected then return setMessage(false, L["Erst links eine Liste wählen oder anlegen."]) end
            local ok, msg = Li:AddItem(w.selected, UI:GetItemInput(w.item), tonumber(w.qty:GetText()) or 1)
            setMessage(ok, msg)
            if ok then
                w.item:SetText(""); w.item.itemID = nil; w.qty:SetText("")
                w.item:UpdatePlaceholder(); w.qty:UpdatePlaceholder()
                w.item:SetFocus()
                w:Refresh()
            end
        end
        w.item:SetScript("OnEnterPressed", add)
        w.qty:SetScript("OnEnterPressed", add)
        w.addBtn = UI:Button(w, L["Hinzufügen"], 100, 22, add, "primary")
        w.addBtn:SetPoint("LEFT", w.qty, "RIGHT", 4, 0)
        UI:ChainEdits({ w.item, w.qty })

        w.items = UI:Table(w, {
            columns = {
                { key = "name", title = L["Item"], width = 150 },
                { key = "qty", title = L["Menge"], width = 46, align = "RIGHT" },
                { key = "have", title = L["Taschen"], width = 54, align = "RIGHT",
                  tooltip = L["So viele hast du schon - die werden nicht mehr gekauft"] },
                { key = "lowest", title = L["Günstigstes"], width = 96, align = "RIGHT" },
                { key = "pct", title = L["% Markt"], width = 54, align = "RIGHT" },
                { key = "cost", title = L["Kosten"], width = 86, align = "RIGHT",
                  tooltip = L["Noch fehlende Menge x günstigstes Angebot (sonst Marktwert)"] },
            },
            rows = 11,
            rowHeight = 22,
            sortKey = "name",
            cell = function(e, key)
                if key == "name" then return e.name end
                if key == "qty" then return tostring(e.qty) end
                if key == "have" then
                    return e.need == 0 and ("|cff33dd55" .. e.have .. "|r") or tostring(e.have)
                end
                if key == "pct" then return A:FormatMarketPercent(e.pct) end
                if key == "lowest" and e.atVendor then return "|cff00d1d1" .. A:FormatMoney(e.vendorBuy) .. " " .. L["(Händler)"] .. "|r" end
                if key == "cost" then return e.need == 0 and ("|cff33dd55" .. L["fertig"] .. "|r") or A:FormatMoney(e.cost) end
                return A:FormatMoney(e[key])
            end,
            sortValue = function(e, key)
                if key == "name" then return string.lower(e.name) end
                return e[key]
            end,
            onClick = function(e)
                UI:SetItemInput(w.item, e.itemID)
                w.qty:SetText(tostring(e.qty))
            end,
            action = {
                text = "X", width = 26,
                tooltip = L["Von der Liste entfernen"],
                onClick = function(e) setMessage(Li:RemoveItem(w.selected, e.itemID)); w:Refresh() end,
            },
            emptyText = L["Die Liste ist leer.\nOben Item und Menge eintragen."],
        })
        w.items:SetPoint("TOPLEFT", x0, -100)

        w.total = UI:Label(w, "", "GameFontHighlightSmall", C.text)
        w.total:SetPoint("TOPLEFT", w.items, "BOTTOMLEFT", 0, -6)
        w.total:SetWidth(500)

        w.checkBtn = UI:Button(w, L["Preise prüfen"], 120, 24, function()
            if not w.selected then return setMessage(false, L["Erst links eine Liste wählen oder anlegen."]) end
            setMessage(Li:CheckPrices(w.selected))
        end)
        w.checkBtn:SetPoint("TOPLEFT", w.items, "BOTTOMLEFT", 0, -26)
        w.checkBtn.tooltip = L["Lädt die aktuellen Angebote aller Items der Liste (Auktionshaus muss offen sein)"]
        w.tolBtn = UI:Button(w, "", 120, 24, function() Li:CycleTolerance(); w:Refresh() end)
        w.tolBtn:SetPoint("LEFT", w.checkBtn, "RIGHT", 6, 0)
        w.tolBtn.tooltip = L["Max-Preis der Sniper-Ziele in % vom Marktwert (Klick: wechseln)"]
        w.sniperBtn = UI:Button(w, L["Als Sniper-Ziele"], 150, 24, function()
            if not w.selected then return setMessage(false, L["Erst links eine Liste wählen oder anlegen."]) end
            local ok, msg = Li:ToSniper(w.selected)
            setMessage(ok, msg)
            A:Print(msg)
        end, "primary")
        w.sniperBtn:SetPoint("LEFT", w.tolBtn, "RIGHT", 6, 0)
        w.sniperBtn.tooltip = L["Legt für jedes fehlende Item ein Sniper-Ziel an.\nDann im Tab Sniper den Sniper-Modus einschalten und per Mausrad kaufen."]
        w.openSniperBtn = UI:Button(w, L["Zum Sniper"], 100, 24, function()
            w:Hide()
            UI:Show()
            UI:SelectTab("sniper")
        end)
        w.openSniperBtn:SetPoint("LEFT", w.sniperBtn, "RIGHT", 6, 0)

        w.message = UI:Label(w, "", "GameFontHighlightSmall", C.textDim)
        w.message:SetPoint("BOTTOMLEFT", 14, 14)
        w.message:SetWidth(750)

        function w:Refresh()
            local names = Li:GetNames()
            if self.selected and not Li:Exists(self.selected) then self.selected = nil end
            if not self.selected and names[1] then self.selected = names[1] end
            if self.confirmDelete ~= self.selected then
                self.confirmDelete = nil
            end
            self.deleteBtn:SetText(self.confirmDelete and L["Wirklich löschen?"] or L["Löschen"])
            local rows = {}
            for _, n in ipairs(names) do table.insert(rows, { name = n, count = Li:Count(n) }) end
            self.lists.selectedID = self.selected
            self.lists:SetData(rows, true)
            self.tolBtn:SetText(string.format(L["bis %d %% Markt"], Li:Tolerance()))
            if not self.selected then
                self.listTitle:SetText(L["Keine Liste gewählt"])
                self.items:SetData({})
                self.total:SetText("")
                return
            end
            self.listTitle:SetText(self.selected)
            self.items:SetData(Li:GetItems(self.selected), true)
            local total, unknown = Li:TotalCost(self.selected)
            local text = L["Noch zu kaufen: "] .. A:FormatMoney(total)
            if unknown > 0 then text = text .. string.format(L["  (+ %d Items ohne Preis)"], unknown) end
            if A.Seller and (#A.Seller.queue > 0 or A.Seller.search) then
                text = text .. "   " .. string.format(L["|cffffcc33prüfe Preise ... (%d offen)|r"], #A.Seller.queue + (A.Seller.search and 1 or 0))
            end
            self.total:SetText(text)
        end
        w:SetScript("OnShow", function(self) self:Refresh() end)
        self.listsWindow = w
    end
    local w = self.listsWindow
    if selectName then w.selected = selectName end
    w:Show()
    w:Refresh()
    return w
end

function UI:ToggleLists()
    if self.listsWindow and self.listsWindow:IsShown() then self.listsWindow:Hide() else self:ShowLists() end
end

local function RefreshLists()
    local w = UI.listsWindow
    if w and w:IsShown() then w:Refresh() end
end
A:On("LISTS_CHANGED", RefreshLists)
A:On("SELLER_CHANGED", RefreshLists)
A:On("THEME_CHANGED", function()
    if UI.listsWindow then UI.listsWindow:Hide(); UI.listsWindow = nil end
end)
