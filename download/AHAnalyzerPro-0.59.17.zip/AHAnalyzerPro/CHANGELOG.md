# AH Analyzer Pro – Changelog

## 0.59.17
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- In every item list (Buy, Market, Overview, Watchlist, Sell, Auctions, Profit, Charts,
  Ledger ...) clicking the **Item** column now sorts by **rarity first, then by name**
  (epic, rare, uncommon, common, poor - click again for the reverse order).
- New **iLvl** column in all item lists (item level of weapons and armor), sortable.

## 0.59.16
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Buy tab shows results **instantly**: clicking a category (e.g. Metal & Stone) immediately lists
  every item of that category from your last market scan (price and quantity in grey = not yet
  confirmed). The live search runs in the background and replaces them page by page with the
  real current offers - on the classic auction house that takes a few seconds per page.
- Clicking an item while a category search is still running now opens its offers right away
  instead of waiting for the category search to finish.

## 0.59.15
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Buy tab is much faster when switching categories (e.g. Herbs <-> Cooking):
  - a new search now cancels the running one immediately - before, it waited until the old
    search had read all its pages (several seconds each on the classic auction house);
  - results are remembered for 3 minutes, so switching back shows them instantly.
    The *Search* button (or Enter) always loads fresh data from the server.

## 0.59.14
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Classic Era / classic auction house:** "Your client does not support auction house search
  (SendBrowseQuery missing)" is gone - the classic auction house (Classic Era, TBC Anniversary,
  Wrath) is supported since 5.9.12; this is the first public release that includes it.
- **Size:** new option *Options -> Size in auction house* (100-160 %). Above 100 % the addon
  extends past the auction house to the right and down and everything (text included) gets
  bigger. A "<" button at the top leads back to the auction house. The separate window grows too.
- **Works next to TSM, Auctionator & co.:** the "AH Analyzer" tab now moves next to the
  right-most tab, including tabs that other addons add later - no more overlapping tabs.
  Clicking another addon's tab now closes the AH Analyzer view.
- Buy tab (classic auction house) now reads all result pages - before, it often showed only
  epic items.
- Tables: the scrollbar can be dragged with the mouse.

> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Fix (Classic auction house): the Buy tab only showed epic items - it stopped after the
  first result page. It now reads all pages (with a "page x of y" progress) and shows
  results while it is still searching.
- Tables: the scrollbar can now be dragged with the left mouse button, and clicking into
  the bar jumps there.
- Charts: tiny price changes no longer look like a crash; axis labels show silver/copper
  when needed.
- New tab **Buy** (right next to Overview) - works like the auction house's own Buy tab:
  - Search by name (part is enough) and/or category on the left (weapons, armor,
    containers, consumables, trade goods with cloth/leather/metal/herbs/cooking/
    elemental/enchanting, gems, recipes, miscellaneous), level from/to, rarity.
  - Results with available quantity, cheapest price per unit and % of market value.
  - Click an item to see all listings. Commodities: enter a quantity or click a price
    tier, "Buy now" gets the price from the server, "Confirm purchase" buys.
    Bait offers are marked. Gear: buyout (second click confirms) or place a bid.
  - Purchases are booked in the ledger right away. Sniper, price checks and the watcher
    wait while you search in the Buy tab.
- The addon window is now exactly as large as the auction house window (measured every
  time the auction house opens, also with UI scaling). Options > Window size: "like AH"
  switches it back on, - / + sets the size by hand.
- The addon window is always exactly as wide and as high as the auction house window
  (measured every time the auction house opens, UI scaling included; also the wide classic
  auction house). Options > Window size now only
  changes options, help and lists.
- Better use of space in every tab: lists and tables now stretch to the full width and
  height of the window (more rows, wider name column) - in the auction house and in the
  separate window. Fixed: the watchlist button and the chart item list reached past the
  bottom edge.
- No more stutter when scanning a big auction house: the scan only counts results while
  it runs, the evaluation afterwards (prices, bait check, names, price sync) runs in small
  portions over several frames, long lists are built and sorted in the background and at
  most once per second. In a test with 12,000 items the longest frame dropped from about
  660 ms to under 50 ms. Classic auction house: the full list is read in time slices too.
- Auction house view fills the whole auction house window (also the wider classic auction
  house in Classic Era / Anniversary), covers the classic search row and is no longer
  see-through.
- Nicer lists: every item list shows the item icon and the name in its rarity color;
  the cards in Overview and Ledger have icons and use the full width.
- Rarity is now a drop-down menu with check boxes (Poor, Common, Uncommon, Rare, Epic -
  any combination, e.g. only Uncommon and Epic) in the Buy tab and for sniper targets;
  older sniper targets keep their range. The sniper filter row (rarity, item level, level) is
  always visible now. New: rarity filter for the item list in Charts.
- Fresh look: every tab has its own icon in the title with a fading gold line; tables have
  a gradient header with a gold rule, a soft hover glow and a gold bar on the selected row;
  panels and cards get a subtle sheen and an inlaid border; charts show a soft gold area
  under the price line and highlight the current price.
- The separate addon window takes exactly the width and height of the auction house window.
- The sniper filter row (rarity, item level, level) is always visible.
- Auction house view: slightly narrower scan button so all eleven tabs fit in every language.

## 5.9.12
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Classic Era, TBC Anniversary and Wrath Classic:** the addon now works with the classic
  auction house. Fixes "Your client does not support the auction house search
  (SendBrowseQuery missing)".
  - Market scan reads the whole auction house at once (when the server allows it every
    15 minutes), otherwise page by page.
  - Price check, sniper (items and search terms), bargain watcher, buying, posting,
    your auctions and cancelling use the classic auction house functions.
  - Stackable goods are posted as full stacks (e.g. 35 linen cloth = one stack of 20,
    the rest with the next click). The deposit is not shown in the classic auction house.
- WoW Forever, Cataclysm Classic, Mists of Pandaria Classic and Retail are unchanged.

## 5.9.11
> ⚠️ **This is a beta version.** It may still contain bugs.
> If you run into any errors or unexpected behavior in-game, please report them in the comments on CurseForge, ideally with the Lua error message (if any) and the WoW version you play on.

- Updated version number to 5.9.11.
- Supports all WoW versions: Classic Era, WoW Forever, TBC Anniversary, Wrath Classic, Wrath Titan Reforged, Cataclysm Classic, Mists of Pandaria Classic and Retail.

## 5.9.1
- TOC: interface numbers for every WoW version (Classic Era, WoW Forever, TBC Anniversary,
  Wrath, Wrath Titan Reforged, Cataclysm, Mists of Pandaria Classic, Retail) - the addon
  is no longer listed as "out of date" there.

## 5.9
- Bait offers: a single unit at the very bottom of a commodity (linen cloth,
  copper bars ...) is treated as bait and ignored everywhere - sniper (no hit,
  status "bait offer"), sell suggestion and undercut check, market value,
  trends, bargains, EMAs and price sync. Gear is not affected.
- After every scan, suspiciously cheap commodities (below 70 % of market value)
  are stored as "unverified" and re-checked with a single search; the real
  price replaces them. Unverified prices never count and are not shared.
- Note: when buying commodities the server always sells the cheapest units
  first, so on a real hit the bait unit is bought along (and included in the
  planned cost).
- Charts: time-based EMAs over 6 hours, 1 day and 7 days (real prices only,
  from 10 prices on), markers where the 1-day EMA crosses the 7-day EMA,
  grey points for unverified prices. On/off button.
- New tab "Watcher" (bargain watcher) next to the sniper: searches trade goods
  (herbs, metal & stone, cloth, leather, enchanting, elemental, gems, cooking,
  optional consumables - never weapons/armor) for prices at or below x % of
  market value (default 50 %, minimum value per unit 10 copper). All categories
  run in one search, with automatic fallback to one category at a time. Every
  hit is verified (bait offers don't count), announced with sound and chat,
  and bought with the same mouse wheel / key as the sniper.
- Speed: search results are evaluated as soon as the server reports them,
  the server's own throttle is used instead of fixed waits (0.3 s instead of
  1.5-2 s between searches), automatic slow-down on errors. /ahp debug shows
  the speed.
- Sniper and watcher buy commodities with ONE mouse wheel notch: on a hit the
  price is fetched from the server in advance (and refreshed while the hit
  waits), the first notch buys right away. If the price has risen meanwhile,
  nothing is bought and a new search starts. If the server gives no price
  confirmation, it switches back to two notches by itself.
- In the auction house the options button is now a gear icon, so all ten tabs
  fit in every language.

## 5.8
- Disenchant values learn: every disenchant you do is recognised (spell + loot
  window) and remembered per group (quality, item level band, armor/weapon).
  The table values count as 10 imaginary disenchants; with each real one your
  results weigh more (50 % after 10, 83 % after 50, 91 % after 100), so chances
  and amounts move towards the reality on your server.
- The tooltip shows how many of your own results went into the value; the
  options show the total and can reset it.
- Starting values for green items as observed in the WoW Forever beta:
  70 % dust, 25 % essence, 5 % shards on every item level band (weapons
  mirrored: 70 % essence, 25 % dust).

## 5.7
- Mailbox: "Collect AH mail" takes gold and items from all auction mail with one
  click ("All" for every mail, COD is never paid). Invoices are booked first,
  stops when your bags are full.
- Sell tab: "Series" posts every bag item with a remembered price, one click per
  auction. Fresh prices are loaded at the start; items are skipped if the price
  falls below 70 % of your last price or a vendor pays more.
- Vendor buy prices are read automatically at every merchant: used for profession
  material costs, shopping lists (items cheaper at a vendor are not sniped) and
  shown in the tooltip.
- Alts & gold: gold, bags and bank of every character (account-wide). The tooltip
  shows how many your alts have; the Ledger tab has a "Gold" view with all
  characters and the gold of the last 30 days.
- Ledger "Statistics": sell-through per item, sales by time of day and weekday,
  best selling hours.
- Disenchant value (Classic table, estimates) in the tooltip and a new Profit view
  "Below disenchant value".

## 5.6
- Shopping lists: named lists of items and quantities. "Check prices" loads all
  listings at once, "As sniper targets" creates a target for every missing item
  (max price = 100/110/125/150 % of the market value). Items already in your bags
  are subtracted. Open via the Sniper tab, right-click on an item or `/ahp lists`.
- Professions: a window next to the profession frame (incl. Enchanting) shows
  material cost, value of the result and profit after the AH cut, plus the best
  recipes. "Materials as shopping list" puts the reagents for N crafts on a list.
- Help pages for all new tabs in all languages.

## 5.5
- New tab "Ledger": income (after the 5 % AH cut), spending, deposits and profit
  for today / 7 days / 30 days / all, per item or as a history.
  Sales and purchases are read from the invoices in your mailbox (just open it),
  sniper purchases and deposits are booked right away - nothing is counted twice.
- Sell tab warns when the price is below your average purchase price.

## 5.4
- New tab "Sell": items from your bags, price check, suggestion that undercuts the
  lowest listing (by 1 copper, 1 % or 5 %), quantity, duration, deposit, AH cut and
  proceeds. Warns (and asks for a second click) when a vendor pays more.
- New tab "Auctions": your auctions with status (lowest / tied / undercut / sold),
  "Check undercuts" and cancel with one click per auction.
- Tabs inside the auction house window shrink to fit in every language.

## 5.3
- Market value = median of the last 14 days (single outliers barely count).
- New column "% market" in the Market and Sniper tabs, coloured green to red.
- Vendor price in the item tooltip (can be turned off in the options).
- Profit tab: bargains below market value or below vendor price; a vendor bargain
  becomes a sniper target with one click. After every scan the chat shows how
  many items are listed below vendor price.
- Column headers explain themselves on mouse-over. CSV export has market value
  and vendor price.

## 4.9 – 5.2
- Prices and a small price chart in every item tooltip.
- The addon as its own tab inside the auction house window.
- Money shown with coin icons or letters.

## 4.8
- The addon now speaks the language of your WoW client: English, German, French,
  Spanish (EU/LA), Portuguese, Italian, Russian, Korean, Chinese (simplified/traditional).
- Language can be changed manually in the options or with `/ahp language`.

## 4.7
- German/English interface, item names follow the client language automatically.

## 4.6
- Built-in item name list for ~23,000 items in 10 languages (source: QuestieDB, wow-classic-items).

## 4.5
- Search items by name in any language, by item ID or by shift-clicking an item.
- Suggestions while typing, accents and upper/lower case don't matter.

## 4.4
- Two designs: "Classic" (looks like the WoW auction house) and "Modern".
- Options window, help for every tab, right-click menu on every item.

## 4.3
- Sniper: targets with max price per item, quantity, budget, rarity, item level and level filters.
- Searches targets on its own while the auction house is open; buy with the mouse wheel or your own key.

## 4.0 – 4.2
- Market scan, price history, trends, watchlist with alerts, charts, flipping calculator.
- Price sync between all players using the addon.
