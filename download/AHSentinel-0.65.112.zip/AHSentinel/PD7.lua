-- AHSentinel - PD7: kompaktes Speicherformat für den Preisverlauf (Entscheid des Nutzers 13.11. 14:04, Variante a)
--
-- Nur das GESPEICHERTE Format ändert sich: Einträge älter als 48 Std. stehen in der SavedVariables-Datei als eine
-- Zeichenkette je Item (md[id].hz). Beim Laden werden sie sofort wieder zu normalen Einträgen - im Spiel ist der
-- Preisverlauf genau wie vorher (Marktwert, Rhythmus, Trends, Grafik unverändert).
--
-- Ablauf und Sicherung (Frage des Nutzers 14:05):
--   1. Im Hintergrund (Portionen <= Bild-Budget) wird je Item der alte Teil verpackt, sofort wieder entpackt und
--      verglichen. Nur geprüfte Pakete werden verwendet.
--   2. Erstes Ausloggen ("pending"): Pakete werden ZUSÄTZLICH gespeichert, die alten Einträge bleiben als Sicherung.
--   3. Nächstes Einloggen: Pakete entpacken und mit der Sicherung vergleichen. OK -> "active" (ab jetzt ersetzt das
--      Paket die alten Einträge beim Ausloggen). Fehler -> Pakete weg, "failed", Protokoll "PD7 zurückgesetzt",
--      Meldung an den Spieler. "/ahs pd7 zurück" schaltet es ab, solange die Sicherung da ist.
--   4. "active": beim Einloggen Paket entpacken, Anzahl und Prüfsumme vergleichen, Einträge wieder vorne einsetzen.
-- Ältere AHSentinel-Versionen lesen md[id].hz nicht (Versionsvermerk db.pd7.v).
local ADDON_NAME, ns = ...
local A = AHAnalyzerPro
if not (A and A.On) then return end          -- AHSentinel nicht geladen (z. B. blockiert durch ein altes Addon)
local L = A.L

local P = {}
A.PD7 = P
P.OLD_AFTER = 48 * 3600       -- älter als 48 Std. -> kompakt speichern
P.VERSION = 1
P.cache = {}                  -- itemID-Schlüssel -> { s, n, sum, tLast }, je Markt (nicht gespeichert)

local floor = math.floor
local function Int(v) return type(v) == "number" and v >= 0 and v == floor(v) and v < 2 ^ 53 end
-- Preise/Mengen können durch die Verdichtung (Median) halbe Kupfer haben -> als Zahl erlaubt, exakt geschrieben
local function Num(v) return type(v) == "number" and v >= 0 and v < 2 ^ 53 and v == v end
local function W(v) if v == floor(v) then return tostring(floor(v)) end return string.format("%.14g", v) end

-- Prüfsumme über die Felder (für den Vergleich vorher/nachher)
local function Sum(h, n)
    local s = 0
    for i = 1, n do
        local e = h[i]
        s = (s + (e.t or 0) * 7 + floor((e.p or 0) + 0.5) * 3 + floor((e.q or 0) + 0.5) + (e.c or 0) * 11 + (e.u and 1 or 0) + (e.s and 2 or 0)) % 2147483647
    end
    return s
end
P.Sum = Sum

-- Eintrag verpackbar? (nur bekannte Felder, ganze Zahlen) - sonst bleibt das Item in Tabellenform
local KNOWN = { t = true, p = true, q = true, c = true, u = true, s = true }
local function Packable(e)
    if type(e) ~= "table" or not Int(e.t) or not Num(e.p) then return false end
    if e.q ~= nil and not Num(e.q) then return false end
    if e.c ~= nil and not Int(e.c) then return false end
    for k in pairs(e) do if not KNOWN[k] then return false end end
    return true
end

-- Teil 1..n verpacken: "dt,p,q,c,f;" (dt = Abstand zum vorherigen Eintrag, f: 1 = unbestätigt, 2 = Sync)
function P:Encode(h, n)
    local parts, prev = {}, 0
    for i = 1, n do
        local e = h[i]
        if not Packable(e) or e.t < prev then return nil end
        local f = (e.u and 1 or 0) + (e.s and 2 or 0)
        parts[i] = (e.t - prev) .. "," .. W(e.p) .. "," .. (e.q and W(e.q) or "") .. "," .. (e.c or "") .. "," .. (f > 0 and f or "")
        prev = e.t
    end
    return table.concat(parts, ";")
end
function P:Decode(s)
    local out, prev = {}, 0
    if type(s) ~= "string" or s == "" then return out end
    for dt, p, q, c, f in s:gmatch("(%d+),([%d%.e%+%-]+),([%d%.e%+%-]*),(%d*),(%d*)") do
        prev = prev + tonumber(dt)
        local e = { t = prev, p = tonumber(p) }
        if q ~= "" then e.q = tonumber(q) end
        if c ~= "" then e.c = tonumber(c) end
        local fl = tonumber(f) or 0
        if fl % 2 == 1 then e.u = 1 end
        if fl >= 2 then e.s = 1 end
        out[#out + 1] = e
    end
    return out
end
-- gleich? (alle Felder; ±1 Kupfer erlaubt laut Auftrag, gespeichert wird aber exakt)
function P:Same(a, b)
    if type(a) ~= "table" or type(b) ~= "table" then return false end
    if a.t ~= b.t or math.abs((a.p or 0) - (b.p or 0)) > 1 or math.abs((a.q or 0) - (b.q or 0)) > 0.01 or (a.c or 0) ~= (b.c or 0) then return false end
    if (a.u and 1 or 0) ~= (b.u and 1 or 0) or (a.s and 1 or 0) ~= (b.s and 1 or 0) then return false end
    return true
end
-- alter Teil eines Verlaufs: Anzahl der Einträge älter als cut
local function OldCount(h, cut)
    local n = 0
    for i = 1, #h do if (h[i].t or 0) < cut then n = i else break end end
    return n
end

-- ein Item verpacken und sofort prüfen; zurück: Paket { s, n, sum, tLast } oder nil
function P:PackItem(h, now)
    if type(h) ~= "table" or #h < 2 then return nil end
    local n = OldCount(h, (now or time()) - self.OLD_AFTER)
    if n < 2 then return nil end
    local s = self:Encode(h, n)
    if not s then return nil end
    local back = self:Decode(s)
    if #back ~= n then return nil end
    for i = 1, n do if not self:Same(back[i], h[i]) then return nil end end
    return { s = s, n = n, sum = Sum(h, n), tLast = h[n].t }
end

local function Markets(db)
    local out = {}
    if type(db.markets) == "table" then
        for k, m in pairs(db.markets) do if type(m) == "table" and type(m.data) == "table" then out[k] = m.data end end
    end
    if type(db.marketData) == "table" and next(db.marketData) and not (A.marketKey and out[A.marketKey] == db.marketData) then
        out["_aktiv"] = db.marketData
    end
    return out
end
P.Markets = Markets

-- Pakete für alle Märkte rechnen (pause = in einer Hintergrund-Aufgabe je Item eine Portion)
function P:PrepareLoop(db, now, pause)
    now = now or time()
    local nItems, nOld, bytes = 0, 0, 0
    for mk, md in pairs(Markets(db)) do
        local c = self.cache[mk] or {}
        self.cache[mk] = c
        for id, entry in pairs(md) do
            if pause then A:Pause() end
            local pk = type(entry) == "table" and self:PackItem(entry.history, now) or nil
            c[id] = pk
            if pk then nItems, nOld, bytes = nItems + 1, nOld + pk.n, bytes + #pk.s end
        end
    end
    self.prepared = { t = time(), items = nItems, old = nOld, bytes = bytes }
    return nItems, nOld, bytes
end
-- 1. Hintergrund: Pakete vorbereiten (Portionen)
function P:Prepare(db, now)
    db = db or A.db
    if not db or self.preparing then return false end
    local st = db.pd7 or {}
    if st.state == "off" or st.state == "failed" then return false end
    self.preparing = true
    A:Job("pd7:prepare", function()
        local okP, err = A:PCall(function() self:PrepareLoop(db, now, true) end)
        self.preparing = nil
        if not okP and A.Diag then pcall(A.Diag.Add, A.Diag, "FEHLER", "PD7 vorbereiten: " .. tostring(err)) end
    end)
    return true
end

-- 2./4. Ausloggen: geprüfte Pakete schreiben (pending: zusätzlich; active: ersetzt die alten Einträge)
function P:OnLogout(db)
    db = db or A.db
    if not db then return 0 end
    db.pd7 = db.pd7 or {}
    local st = db.pd7
    if st.state == "off" or st.state == "failed" then return 0 end
    if not st.state then st.state = "pending"; st.v, st.t = A.version, time() end
    local n, before, after = 0, 0, 0
    for mk, md in pairs(Markets(db)) do
        local c = self.cache[mk] or {}
        for id, entry in pairs(md) do
            local pk = c[id]
            local h = type(entry) == "table" and entry.history
            entry.hz, entry.hzN, entry.hzS = nil, nil, nil
            -- Paket nur, wenn der alte Teil seit dem Vorbereiten unverändert ist (Anzahl, letzter Zeitpunkt, Prüfsumme)
            if pk and h and #h >= pk.n and h[pk.n].t == pk.tLast and (#h == pk.n or h[pk.n + 1].t > pk.tLast) and Sum(h, pk.n) == pk.sum then
                entry.hz, entry.hzN, entry.hzS = pk.s, pk.n, pk.sum
                before = before + pk.n * 48
                after = after + #pk.s
                if st.state == "active" then
                    local keep = {}
                    for i = pk.n + 1, #h do keep[#keep + 1] = h[i] end
                    entry.history = keep
                end
                n = n + 1
            end
        end
    end
    st.lastOut = { t = time(), items = n, beforeKB = floor(before / 1024), afterKB = floor(after / 1024) }
    return n
end

-- 3./4. Laden: Pakete entpacken und prüfen (vor allem anderen, gleich nach InitDB)
function P:OnLoad(db)
    db = db or A.db
    if not db or not db.pd7 then return "-" end
    local st = db.pd7
    local items, entries, bad = 0, 0, 0
    local markets = Markets(db)
    -- pending: Sicherung (alte Einträge) ist noch da -> Pakete nur vergleichen
    for _, md in pairs(markets) do
        for id, entry in pairs(md) do
            if type(entry) == "table" and entry.hz then
                local back = self:Decode(entry.hz)
                local nOld = #back
                local h = entry.history or {}
                local ok = #back == (entry.hzN or -1) and Sum(back, #back) == entry.hzS
                if ok and st.state == "pending" then
                    for i = 1, #back do if not self:Same(back[i], h[i]) then ok = false; break end end
                end
                if not ok then bad = bad + 1 end
                if st.state == "active" and ok then
                    -- Einträge wieder vorne einsetzen (im Spiel ist der Verlauf vollständig)
                    for i = 1, #h do back[#back + 1] = h[i] end
                    entry.history = back
                end
                if ok or st.state == "pending" then entry.hz, entry.hzN, entry.hzS = nil, nil, nil end
                items, entries = items + 1, entries + nOld
            end
        end
    end
    local result
    if bad > 0 and st.state == "pending" then
        st.state, result = "failed", "zurückgesetzt"
        self.message = L["PD7: Prüfung des kompakten Preisverlaufs fehlgeschlagen – deine Daten sind unverändert (Sicherung genutzt)."]
    elseif bad > 0 then
        result = "FEHLER"
        self.message = L["PD7: Teile des Preisverlaufs konnten nicht gelesen werden – siehe Diagnose-Protokoll."]
    elseif st.state == "pending" and items > 0 then
        st.state, result = "active", "OK"
    else
        result = items > 0 and "OK" or "-"
    end
    st.lastIn = { t = time(), items = items, entries = entries, bad = bad, result = result }
    self.loadNote = string.format("PD7 %s: %d Items, %d Einträge geprüft, %d Fehler · Zustand %s",
        result == "zurückgesetzt" and "zurückgesetzt" or "geladen", items, entries, bad, tostring(st.state))
    return result
end

-- "/ahs pd7 zurück": solange die Sicherung da ist (pending) abschalten
function P:Undo(db)
    db = db or A.db
    local st = db and db.pd7
    if not st or st.state ~= "pending" then return false, L["PD7: keine Sicherung mehr vorhanden (nur bis zum nächsten erfolgreichen Login)."] end
    st.state = "off"
    for _, md in pairs(Markets(db)) do
        for _, entry in pairs(md) do if type(entry) == "table" then entry.hz, entry.hzN, entry.hzS = nil, nil, nil end end
    end
    if A.Diag then pcall(A.Diag.Add, A.Diag, "PD7", "zurück auf Wunsch des Spielers – kompaktes Format abgeschaltet") end
    return true, L["PD7: kompaktes Format abgeschaltet, dein Preisverlauf bleibt wie bisher."]
end

function P:Status(db)
    db = db or A.db
    local st = db and db.pd7 or {}
    local o, i = st.lastOut, st.lastIn
    return string.format("PD7 Zustand %s · zuletzt gespeichert %s · zuletzt geladen %s", tostring(st.state or "aus (noch nie)"),
        o and string.format("%d Items, ~%d KB -> %d KB", o.items, o.beforeKB, o.afterKB) or "-",
        i and string.format("%d Items, %d Einträge, %d Fehler, %s", i.items, i.entries, i.bad, i.result) or "-")
end

-- Ereignisse
A:On("READY", function()
    if P.loadNote and A.Diag then pcall(A.Diag.Add, A.Diag, "PD7", P.loadNote) end
    if P.message then A:Print(P.message); if A.Diag then pcall(A.Diag.Add, A.Diag, "PD7", P.message) end end
    if C_Timer and C_Timer.After then C_Timer.After(120, function() P:Prepare() end) end
end)
A:On("SCAN_FINISHED", function()
    if A.TestRoutine and A.TestRoutine.running then return end
    if C_Timer and C_Timer.After then C_Timer.After(60, function() P:Prepare() end) end
end)
