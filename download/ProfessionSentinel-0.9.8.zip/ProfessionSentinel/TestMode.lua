local _, ns = ...
local L = ns.L

-- Test mode (/ps test): diagnostics, simulation (skill, learned state, profession without
-- profession window) and a self-test of data, lifeline maths and the game APIs the addon uses.
-- Nothing here changes saved data: the simulation lives in ns.Sim and is cleared by "Reset".

local TM = {}
ns.TestMode = TM

local win, diagText, resultText, skillSlider, skillValue, skillActive, profLabel, knownButtons
local profIndex = 1

local function Sim()
    ns.Sim = ns.Sim or {}
    return ns.Sim
end

local function Clean()
    if ns.Sim and not ns.Sim.rank and not ns.Sim.known and not ns.Sim.prof and not ns.Sim.prices
        and ns.Sim.enchanter == nil and not ns.Sim.de and not ns.Sim.goal then ns.Sim = nil end
end

local function RefreshAll()
    Clean()
    if ns.RefreshAll then ns.RefreshAll() end
end

local function OK(b) return b and "|cff40c040OK|r" or "|cffff4040--|r" end

---------------------------------------------------------------------------
-- Diagnostics
---------------------------------------------------------------------------
local function TemplateExists(name)
    if C_XMLUtil and C_XMLUtil.GetTemplateInfo then
        return C_XMLUtil.GetTemplateInfo(name) ~= nil
    end
    return nil
end

function TM:Diagnostics()
    local lines = {}
    local function add(s) lines[#lines + 1] = s end
    add("|cffffd100" .. L.TEST_DIAG .. "|r")
    add(string.format("Spielversion/Game: |cffffffff%s|r  (Interface %d, Client %s, Build %s)",
        ns.FlavorName(), ns.Interface or 0, ns.ClientVersion or "?", ns.ClientBuild or "?"))
    if _G.GoldSentinelGame and _G.GoldSentinelGame.Status then add(_G.GoldSentinelGame.Status()) end
    add(string.format("Daten/Data: |cffffffff%d|r Rezepte · %s · Build %s · Questie %s", #ns.Recipes,
        tostring(ns.DataMeta.flavor), tostring(ns.DataMeta.build), tostring(ns.DataMeta.questie)))
    local tCount, npcCount, withCoords = 0, 0, 0
    for _, list in pairs(ns.Trainers or {}) do tCount = tCount + #list end
    for _, n in pairs(ns.NPCs) do npcCount = npcCount + 1; if n[6] and n[7] then withCoords = withCoords + 1 end end
    add(string.format("Lehrer/Trainers: |cffffffff%d|r · NPCs mit Koordinaten / with coordinates: |cffffffff%d|r von %d",
        tCount, withCoords, npcCount))
    local c = ns.Char()
    if c then
        local profs = {}
        for id, p in pairs(c.profs) do profs[#profs + 1] = ns.ProfName(id) .. " " .. (p.rank or 0) .. "/" .. (p.max or 0) end
        local n = 0
        for _ in pairs(c.known) do n = n + 1 end
        add("Charakter: " .. ns.CharKey() .. " · " .. (#profs > 0 and table.concat(profs, ", ") or "keine Berufe erkannt") .. " · " .. n .. " " .. L.KNOWN)
    end
    add(" ")
    add("|cffffd100API|r")
    local checks
    if ns.UsesModernProfessions then
        checks = {
            { "ProfessionsFrame (geladen/loaded)", ProfessionsFrame ~= nil },
            { "C_TradeSkillUI.GetChildProfessionInfo", C_TradeSkillUI and C_TradeSkillUI.GetChildProfessionInfo ~= nil },
            { "C_TradeSkillUI.GetRecipeInfo", C_TradeSkillUI and C_TradeSkillUI.GetRecipeInfo ~= nil },
            { "C_TradeSkillUI.GetAllRecipeIDs", C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs ~= nil },
            { "C_TradeSkillUI.OpenRecipe", C_TradeSkillUI and C_TradeSkillUI.OpenRecipe ~= nil },
            { "Lebenslinie in Blizzard-Liste / lifeline hook", ns.Lifeline and ns.Lifeline.foreverHooked },
        }
    else
        checks = {
            { "TradeSkillFrame (geladen/loaded)", TradeSkillFrame ~= nil },
            { "CraftFrame (geladen/loaded)", CraftFrame ~= nil },
            { "GetTradeSkillLine / GetTradeSkillInfo", GetTradeSkillLine ~= nil and GetTradeSkillInfo ~= nil },
            { "GetTradeSkillRecipeLink", GetTradeSkillRecipeLink ~= nil },
            { "GetCraftDisplaySkillLine", GetCraftDisplaySkillLine ~= nil },
            { "Lebenslinie Handwerk / lifeline hook", ns.Lifeline and ns.Lifeline.tsHooked },
            { "Lebenslinie Verzauberkunst / lifeline hook", ns.Lifeline and ns.Lifeline.craftHooked },
        }
    end
    local common = {
        { "ScrollUtil / ScrollBox", ScrollUtil ~= nil and CreateScrollBoxListTreeListView ~= nil },
        { "CreateTreeDataProvider", CreateTreeDataProvider ~= nil },
        { "ButtonFrameTemplate", TemplateExists("ButtonFrameTemplate") ~= false },
        { "SearchBoxTemplate", TemplateExists("SearchBoxTemplate") ~= false },
        { "MinimalScrollBar", TemplateExists("MinimalScrollBar") ~= false },
        { "TooltipDataProcessor / OnTooltipSetItem", TooltipDataProcessor ~= nil or GameTooltip:HasScript("OnTooltipSetItem") },
        { "IsPlayerSpell", IsPlayerSpell ~= nil },
        { "Wegpunkt / waypoint: " .. (ns.Waypoint and ns.Waypoint.Available() or "nur Chat / chat only"), ns.Waypoint and ns.Waypoint.Available() ~= nil },
        { "C_Map.GetMapInfo (Zonennamen / zone names)", C_Map ~= nil and C_Map.GetMapInfo ~= nil },
    }
    for _, ch in ipairs(checks) do add(OK(ch[2]) .. "  " .. ch[1]) end
    for _, ch in ipairs(common) do add(OK(ch[2]) .. "  " .. ch[1]) end
    add(" ")
    add(L.TEST_HELP)
    return table.concat(lines, "\n")
end

---------------------------------------------------------------------------
-- Self-test
---------------------------------------------------------------------------
function TM:RunSelfTest(toChat)
    local results, fails = {}, 0
    local function check(name, cond, detail)
        if not cond then fails = fails + 1 end
        results[#results + 1] = (cond and "|cff40c040" .. L.TEST_PASS or "|cffff4040" .. L.TEST_FAIL) .. "|r  " .. name
            .. (detail and (" |cff9d9d9d(" .. detail .. ")|r") or "")
    end
    local LL = ns.Lifeline

    -- 1. Data
    check("Spielversion erkannt / game version detected", ns.Flavor ~= nil, tostring(ns.Flavor))
    -- shared detection of all GoldSentinel addons (GoldSentinelGame.lua)
    local GG = _G.GoldSentinelGame
    check("GoldSentinelGame: gleiche Spielversion wie das Addon, Forever = moderne API",
        GG ~= nil and GG.flavor == ns.Flavor and GG.IsModern == ns.UsesModernProfessions,
        GG and (tostring(GG.flavor) .. " · " .. (GG.IsModern and "modern" or "alt")) or "fehlt")
    if GG and GG.SetTestFlavor then
        GG.SetTestFlavor("forever")
        local fOk = GG.IsForever and GG.IsModern and not GG.IsOldAPI
        GG.SetTestFlavor("era")
        local eOk = GG.IsEra and GG.IsOldAPI and not GG.IsModern
        GG.SetTestFlavor("tbc")
        local tOk = GG.IsTBC and GG.IsOldAPI
        GG.SetTestFlavor(nil)
        check("GoldSentinelGame: Test Forever = modern, Era/TBC = alte API, danach wieder echt",
            fOk and eOk and tOk and GG.flavor == ns.Flavor, tostring(GG.flavor))
    end
    check("Passende Daten geladen / matching data loaded", ns.DataMeta.flavor == ns.Flavor and #ns.Recipes > 0,
        tostring(ns.DataMeta.flavor) .. ", " .. #ns.Recipes)
    local bad, profsOk = 0, true
    for _, r in ipairs(ns.Recipes) do
        if r.yellow > 0 and not (r.yellow <= r.green and r.green <= r.grey) then bad = bad + 1 end
        if not ns.ByProf[r.prof] then profsOk = false end
    end
    check("Farbstufen geordnet / thresholds ordered (gelb<=grün<=grau)", bad == 0, bad .. " Abweichungen")
    check("Jedes Rezept hat einen Beruf / every recipe has a profession", profsOk)

    -- 2. Version-specific thresholds (Feine Lederstiefel / Fine Leather Boots, spell 2158)
    local flb = ns.BySpell[2158]
    if ns.IsForever then
        check("Forever-Stufen aktiv (Feine Lederstiefel grau 125)", flb and flb.grey == 125, flb and (flb.yellow .. "/" .. flb.green .. "/" .. flb.grey))
    elseif ns.IsEra then
        check("Era-Stufen aktiv (Feine Lederstiefel grau 150)", flb and flb.grey == 150, flb and (flb.yellow .. "/" .. flb.green .. "/" .. flb.grey))
    end

    -- 3. Lifeline maths with fixed examples
    local A = { req = 65, yellow = 95, green = 110, grey = 125, skillUps = 1 }
    local c80 = LL.Calc(A, 80)
    check("Orange: 80 -> 15× bis Gelb (genau)", c80 and c80.state == "orange" and c80.target == "yellow" and c80.crafts == 15 and c80.exact)
    local c95 = LL.Calc(A, 95)
    check("Gelb: 95 -> ≈ bis Grün", c95 and c95.state == "yellow" and c95.target == "green" and (c95.crafts or 0) >= 15, c95 and tostring(c95.crafts))
    local c115 = LL.Calc(A, 115)
    check("Grün: 115 -> ≈ bis Grau", c115 and c115.state == "green" and c115.target == "grey", c115 and tostring(c115.crafts))
    local c125 = LL.Calc(A, 125)
    check("Grau ab 125", c125 and c125.state == "grey")
    local c50 = LL.Calc(A, 50)
    check("Zu niedrig: 50 -> 'ab 65'", c50 and c50.state == "red")
    local Z = { req = 35, yellow = 40, green = 40, grey = 40, skillUps = 1 }  -- Forever: grey after 5 points
    local z36 = LL.Calc(Z, 36)
    check("Sofort grau (35/40/40/40): 36 -> 4× bis Grau", z36 and z36.target == "grey" and z36.crafts == 4)
    local z40 = LL.Calc(Z, 40)
    check("35/40/40/40: 40 -> grau", z40 and z40.state == "grey")
    local frac, pos = LL.Layout(A, 80)
    local sum = frac[1] + frac[2] + frac[3] + frac[4]
    check("Linie: Zonen = 100 %, Marker im Bereich", math.abs(sum - 1) < 0.001 and pos and pos >= 0 and pos <= 1)
    check("Chance gelb->grau fällt / chance falls", LL.Chance(A, 95) == 1 and LL.Chance(A, 110) < 1 and LL.Chance(A, 125) == 0)

    -- 4. Ranking: reagents per skill point (fixed examples at skill 90)
    local AD = ns.Advisor
    local RA = { name = "A", req = 1, yellow = 100, green = 110, grey = 120, skillUps = 1, reagents = { 1, 4 }, src = 1, recipeItems = {} } -- orange, 4 mats -> 4.0
    local RB = { name = "B", req = 1, yellow = 95, green = 105, grey = 115, skillUps = 1, reagents = { 2, 2 }, src = 1, recipeItems = {} }  -- orange, 2 mats -> 2.0
    local RC = { name = "C", req = 1, yellow = 85, green = 100, grey = 115, skillUps = 1, reagents = { 3, 1 }, src = 1, recipeItems = {} }  -- yellow 83 %, 1 mat -> 1.2
    local RD = { name = "D", req = 1, yellow = 70, green = 80, grey = 90, skillUps = 1, reagents = { 4, 1 }, src = 1, recipeItems = {} }   -- grey -> out
    local RE = { name = "E", req = 120, yellow = 130, green = 140, grey = 150, skillUps = 1, reagents = { 5, 1 }, src = 1, recipeItems = {} } -- too high -> out
    local learnedSet = { A = true, B = true }
    local ranking = AD.Ranking({ RA, RB, RC, RD, RE }, 90, function(r) return learnedSet[r.name] end, function() return 0 end)
    local order = {}
    for _, e in ipairs(ranking) do order[#order + 1] = e.recipe.name end
    check("Rangliste sortiert nach Material/Punkt (C 1,2 · B 2,0 · A 4,0)", table.concat(order, ",") == "C,B,A", table.concat(order, ","))
    check("Grau und zu hohe Rezepte fehlen in der Rangliste", #ranking == 3)
    check("Nicht gelernte Rezepte sind dabei (C = [lernen])", ranking[1] and not ranking[1].learned)
    local bestLearned
    for _, e in ipairs(ranking) do if e.learned then bestLearned = e; break end end
    check("Bestes gelerntes Rezept = B", bestLearned and bestLearned.recipe.name == "B")
    local realOk, realN = true, 0
    local lwProf = (ns.IsRetail and flb and flb.prof) or 165      -- Retail: the Classic leatherworking line
    if ns.ByProf[lwProf] then
        local real = AD.Ranking(ns.ByProf[lwProf], 80, function() return false end, function() return 0 end, false)
        realN = #real
        for i = 2, #real do if real[i].perPoint + 1e-9 < real[i - 1].perPoint then realOk = false end end
    end
    check("Echte Daten: Rangliste Lederverarbeitung bei 80 sortiert", realOk and realN > 0, realN .. " Rezepte")

    -- 4b. Gold: vendor reagents at vendor price, others at AH value, product at the higher value (AH minus 5 % cut)
    local P = ns.Prices
    local savedSim = ns.Sim
    ns.Sim = { prices = { [2318] = 800, [4239] = 3500 } }  -- Leichtes Leder 8s, Geprägte Lederhandschuhe 35s (test values)
    local RG = { name = "G", req = 1, yellow = 100, green = 110, grey = 120, skillUps = 1, src = 1, recipeItems = {},
        reagents = { 2318, 3, 2320, 2 }, out = 4239, outMin = 1, outMax = 1 }
    local pr = P.Recipe(RG)
    local threadVendor = P.VendorBuy(2320)
    check("Händlerware zum Händlerpreis (Grober Faden 10c)", threadVendor == 10, tostring(threadVendor))
    check("Kosten 3× Leichtes Leder (AH 8s) + 2× Grober Faden = 24s 20c", pr.known and pr.cost == 2420, tostring(pr.cost))
    -- listing fee: WoW Forever 1s per auction, never refunded (other versions: refunded on a sale = 0)
    local F = P.FeePerPiece(4239)
    check(ns.IsForever and "Einstellgebühr WoW Forever: 1s pro Auktion" or "Einstellgebühr: zählt hier nicht (wird beim Verkauf erstattet)",
        F == (ns.IsForever and 100 or 0), P.MoneyPlain(F))
    check("AH-Kommission 5 %: 35s im AH, Erlös 33s 25c" .. (F > 0 and " − 1s Gebühr" or ""), pr.value == 3325 - F and pr.valueSource == "ah" and pr.ahCut == 175, tostring(pr.value))
    check("Netto pro Herstellung +9s 5c (nach Kommission)" .. (F > 0 and " − 1s Gebühr" or ""), pr.net == 905 - F, P.MoneyPlain(pr.net, true))
    ns.Sim.prices[4239] = 150   -- cheap item: 1s 50c in the AH, vendor pays 71c
    local prCheap = P.Recipe(RG)
    local vsCheap = P.VendorSell(4239) or 0
    local expectCheap = (150 * 0.95 - F >= vsCheap) and "ah" or "vendor"
    check(string.format("Günstiges Item: AH 1s 50c%s gegen Händler %s -> %s", F > 0 and " − 5 % − 1s Gebühr" or " − 5 %",
        P.MoneyPlain(vsCheap), expectCheap == "ah" and "AH" or "Händler") .. ((ns.IsForever and expectCheap == "vendor") and " (Gebühr macht den Unterschied)" or ""),
        prCheap.valueSource == expectCheap, tostring(prCheap.valueSource) .. " " .. P.MoneyPlain(prCheap.value))
    ns.Sim.prices[4239] = 3500
    local vsGloves = P.VendorSell(4239) or 0
    if vsGloves >= 40 then
        ns.Sim.prices[4239] = vsGloves + 1   -- AH barely above vendor: after the 5 % cut the vendor pays more
        local prV = P.Recipe(RG)
        check("Nach Kommission zahlt der Händler mehr -> Händlerwert", prV.valueSource == "vendor" and prV.value == vsGloves, tostring(prV.value))
        ns.Sim.prices[4239] = 3500
    end
    local RX = { name = "X", req = 1, yellow = 100, green = 110, grey = 120, skillUps = 1, src = 1, recipeItems = {},
        reagents = { 2318, 1 }, out = 4239, outMin = 1, outMax = 1 }                    -- cost 8s, value 35s -> +27s/pt
    local RY = { name = "Y", req = 1, yellow = 100, green = 110, grey = 120, skillUps = 1, src = 1, recipeItems = {},
        reagents = { 2318, 6 }, out = 2320, outMin = 1, outMax = 1 }                    -- cost 48s, value ~2c -> loss
    local RZ = { name = "Z", req = 1, yellow = 40, green = 50, grey = 60, skillUps = 1, src = 1, recipeItems = {},
        reagents = { 2318, 2 }, out = 4239, outMin = 1, outMax = 1 }                    -- grey at 90, +19s profit
    local lv = AD.Ranking({ RX, RY, RZ }, 90, function() return true end, function() return 0 end)
    local lvOrder = {}
    for _, e in ipairs(lv) do lvOrder[#lvOrder + 1] = e.recipe.name end
    check("Leveln nach Gold pro Punkt: X (Gewinn) vor Y (Verlust), graues Z fehlt", table.concat(lvOrder, ",") == "X,Y", table.concat(lvOrder, ","))
    local gd = AD.GoldRanking({ RX, RY, RZ }, 90, function() return true end, function() return 0 end)
    local gdOrder = {}
    for _, e in ipairs(gd) do gdOrder[#gdOrder + 1] = e.recipe.name end
    check("Gold verdienen enthält graue Rezepte, sortiert nach Erlös (X, Z, Y)", table.concat(gdOrder, ",") == "X,Z,Y", table.concat(gdOrder, ","))

    -- 4c. Enchanting: disenchant value (materials minus 5 % cut), goal of the enchanter, selling price
    local DE = ns.Disenchant
    ns.Sim.enchanter, ns.Sim.goal = false, nil
    ns.Sim.de = { [4239] = 5000, [2320] = false }               -- Geprägte Lederhandschuhe: entzaubert 50s (Testwert)
    check("Ohne Verzauberkunst kein Entzauberungswert", P.Recipe(RG, true).deGross == nil)
    ns.Sim.enchanter, ns.Sim.goal = true, nil
    if ns.IsRetail then
        check("Retail: Verzauberer ohne Wahl = VZ verkaufen (kein Entzaubern)", DE.Goal() == "sell" and DE.WantsSell() and not DE.WantsGold(), tostring(DE.Goal()))
    else
        check("Verzauberer ohne Wahl: Standard „Gold machen“", DE.Goal() == "gold" and DE.WantsGold() and not DE.WantsSell(), tostring(DE.Goal()))
    end
    ns.Sim.goal = "gold"
    check("Andere Berufe: Rangliste ohne Entzaubern", P.Recipe(RG).deGross == nil)
    local prD = P.Recipe(RG, true)
    check("Entzaubern: 50s Material, Erlös 47s 50c nach 5 %", prD.deGross == 5000 and prD.deValue == 4750, tostring(prD.deValue))
    check("Netto Entzaubern +23s 30c, besser als Verkauf (+9s 5c) -> DE", prD.deNet == 2330 and prD.bestVia == "de", P.MoneyPlain(prD.deNet or 0, true))
    local deList = AD.DERanking({ RX, RY, RZ }, 90, function() return true end, function() return 0 end)
    local deOrder = {}
    for _, e in ipairs(deList) do deOrder[#deOrder + 1] = e.recipe.name end
    check("Herstellen & Entzaubern: X vor Z (auch grau), Y nicht entzauberbar", table.concat(deOrder, ",") == "X,Z", table.concat(deOrder, ","))
    local gdD = AD.GoldRanking({ RX, RY, RZ }, 90, function() return true end, function() return 0 end)
    check("Gold verdienen bleibt beim Verkauf (X +25s 25c" .. (F > 0 and " − 1s" or "") .. ")", gdD[1] and gdD[1].recipe == RX and gdD[1].net == 2525 - F and gdD[1].deNet == nil,
        gdD[1] and P.MoneyPlain(gdD[1].net, true) or "-")
    -- sniper: margin 20 %
    local fd = DE.FilterDeals({ { itemID = 1, price = 3800, net = 4750 }, { itemID = 2, price = 4300, net = 4750 } }, 0.2)
    check("Schnäppchen nur mit Mindestmarge (38s ja, 43s nein bei 47s 50c)", #fd == 1 and fd[1].itemID == 1, tostring(#fd))
    local it = DE.ItemTargets({ { itemID = 4239, net = 4750, quantity = 3 } }, 0.2)
    check("Sniper Gegenstand: Max-Preis 38s (47s 50c × 80 %), 10 Stück", it[1] and it[1].maxPrice == 3800 and it[1].qty == 10, it[1] and P.MoneyPlain(it[1].maxPrice) or "-")
    -- X: 1× Leichtes Leder (AH 8s), DE nach Kommission 47s 50c -> erlaubt 38s, Faktor 1 (nie über Marktwert)
    -- RG: 3× Leder (AH 24s) + 2× Faden (Händler 20c); erlaubt 38s -> Leder bis Marktwert
    local mt, used = DE.ReagentTargets(deList, 0.2, 5, 10)
    check("Sniper Zutaten: Leichtes Leder max. 8s, 30 Stück (X 10×1 + Z 10×2)", used == 2 and mt[1] and mt[1].id == 2318 and mt[1].maxPrice == 800 and mt[1].qty == 30,
        mt[1] and (mt[1].id .. " " .. P.MoneyPlain(mt[1].maxPrice) .. " ×" .. mt[1].qty) or "-")
    local tight = DE.ReagentTargets({ { learned = true, price = { deValue = 1000, known = true,
        parts = { { id = 2318, count = 1, unit = 800, origin = "ah" }, { id = 2320, count = 2, unit = 10, origin = "vendor" } } } } }, 0.2, 5, 10)
    check("Sniper Zutaten: knappe Marge senkt den Max-Preis (Leder 7s 80c statt 8s)", tight[1] and tight[1].maxPrice == 780, tight[1] and P.MoneyPlain(tight[1].maxPrice) or "-")
    local lvD = AD.Ranking({ RX }, 90, function() return true end, function() return 0 end)
    check("Leveln rechnet weiter nur mit Verkauf", lvD[1] and lvD[1].net == 3325 - 800 - F, lvD[1] and tostring(lvD[1].net))
    ns.Sim.goal = "sell"
    check("Ziel „VZ verkaufen“: kein Entzaubern in der Rangliste", P.Recipe(RG).deGross == nil and DE.WantsSell() and not DE.WantsGold())
    local saveMarkup, saveMin = ns.db.vzMarkup, ns.db.vzMinProfit
    ns.db.vzMarkup, ns.db.vzMinProfit = 20, 0
    local sp1 = DE.SellPrice(2420)
    ns.db.vzMinProfit = 1000
    local sp2 = DE.SellPrice(2420)
    ns.db.vzMarkup, ns.db.vzMinProfit = saveMarkup, saveMin
    check("VK-Preis: 24s 20c + 20 % = 30s; mit Mindestgewinn 10s = 35s", sp1 == 3000 and sp2 == 3500, P.MoneyPlain(sp1 or 0) .. " / " .. P.MoneyPlain(sp2 or 0))
    check("Eingabe Geld: „1g 20s“, „1,5“, „50s“", DE.ParseMoney("1g 20s") == 12000 and DE.ParseMoney("1,5") == 15000 and DE.ParseMoney("50s") == 5000)

    -- 4d. Levelling plan, shopping list, reputation
    check("Leveln: Gewinn zählt pro Herstellung × Chance, Kosten pro Punkt", AD.LevelScore(1000, 0.25) == 250 and AD.LevelScore(-1000, 0.5) == -2000)
    local plan = AD.Plan({ RX }, 90, 100, function() return true end)
    check("Levelplan 90 -> 100 mit X: 1 Abschnitt, 10× (orange)", #plan.steps == 1 and plan.steps[1].crafts == 10 and plan.reagents[2318] == 10,
        #plan.steps .. " / " .. tostring(plan.steps[1] and plan.steps[1].crafts))
    local shop = AD.Shopping(plan, function() return 4 end)
    check("Einkaufsliste: braucht 10, hat 4 -> fehlt 6", shop[1] and shop[1].missing == 6, shop[1] and tostring(shop[1].missing))
    local st = ns.Plan.SniperTargets(shop, 10)
    check("Sniper aus dem Plan: Max-Preis 8s + 10 % = 8s 80c, 6 Stück", st[1] and st[1].maxPrice == 880 and st[1].qty == 6, st[1] and P.MoneyPlain(st[1].maxPrice) or "-")
    local repText = ns.RepInfo(529, 6)
    check("Ruf: Argentumdämmerung, Stufe 6 = Respektvoll", repText and repText:find(ns.Factions and ns.Factions[529] or "Argent") ~= nil
        and (repText:find(_G.FACTION_STANDING_LABEL7 or L.REP_7) ~= nil), repText)
    ns.Sim = savedSim

    -- 4e. WoW Forever: supply-camp recipes cost Merchant's Favor (guides; the vendor's real costs win)
    if ns.IsForever and ns.Favor then
        local FV = ns.Favor
        local fr = ns.ByRecipeItem[250364]
        local fri = fr and fr.recipeItems[1]
        check("Händlergunst: Elixier der Gerissenheit = 180, kein Goldpreis, Ruf Wohlwollend",
            fri ~= nil and fri.fv == 180 and fri.bp == nil and fri.fa == FV.FACTION_HORDE and fri.fr == 5, fri and tostring(fri.fv))
        check("Händlergunst: Allianz braucht die Handelskommission von Azeroth",
            FV.Faction(FV.FACTION_HORDE, "Alliance") == FV.FACTION_ALLIANCE and FV.Faction(FV.FACTION_HORDE, "Horde") == FV.FACTION_HORDE)
        local savedFavor = ns.db.favor
        ns.db.favor = { costs = { [250364] = { n = 150, c = "Test" } } }
        local c = FV.Cost(fri)
        local txt = FV.CostText(fri)
        ns.db.favor = savedFavor
        check("Händlergunst: beim Händler gelesene Kosten haben Vorrang", c ~= nil and c.n == 150 and c.learned and txt ~= nil and txt:find("150") ~= nil, txt)
        local sage = ns.ByRecipeItem[21099]
        local sri = sage and sage.recipeItems[1]
        check("Räucherfisch (auch bei normalen Händlern) behält den Goldpreis", sri ~= nil and sri.bp == 500 and sri.fv == nil)
        -- 8.3 crates: 30 Waylaid Crates; Apprentice Ore = 20 copper ore OR 20 tin ore, 5 favor
        local crate
        for _, c in ipairs(ns.Crates or {}) do if c.id == 248683 then crate = c end end
        local saveSim = ns.Sim
        ns.Sim = { prices = { [2770] = 10, [2771] = 30, [248683] = 50 } }
        local cv = crate and FV.CrateValue(crate, function() return 0 end)
        ns.Sim = saveSim
        check("Kisten: 30 Abgefangene Kisten geladen", #(ns.Crates or {}) == 30, tostring(#(ns.Crates or {})))
        check("Kiste Erz (Lehrling): Kupfererz 2s + leere Kiste 50c = 2s 50c, 5 Gunst = 50c pro Gunst",
            cv ~= nil and cv.best and cv.best.id == 2770 and cv.total == 250 and cv.perFavor == 50,
            cv and (tostring(cv.total) .. " / " .. tostring(cv.perFavor)) or "-")
        -- 8.2 planner: wish list sums the favor and leaves learned recipes out
        local savedFavor2 = ns.db.favor
        ns.db.favor = { costs = {}, wish = { [250364] = true }, goals = { kodo = true } }
        local pl = FV.Plan()
        ns.db.favor = savedFavor2
        check("Favor-Planer: Elixier der Gerissenheit 180 + Packkodo 6000 = 6180", pl.total == 6180 and #pl.items == 2, tostring(pl.total))
        -- AHSentinel read the cost at the vendor: used when we have nothing ourselves
        local saveA = _G.AHAnalyzerPro
        _G.AHAnalyzerPro = { GetVendorCost = function(_, id) if id == 250364 then return { costs = { { kind = "currency", id = 1, name = "Gunst", amount = 170 } } } end end }
        local savedFavor3 = ns.db.favor
        ns.db.favor = { costs = {} }
        local ca = FV.Cost(fri)
        ns.db.favor = savedFavor3
        _G.AHAnalyzerPro = saveA
        check("Händlergunst: Wert von AHSentinel (beim Händler gelesen) gilt vor den Guides", ca ~= nil and ca.n == 170 and ca.learned, ca and tostring(ca.n))
        _G.AHAnalyzerPro = { GetVendorCost = function(_, id) return { costs = { { kind = "currency", id = 3333, name = "Gunst", amount = 170 } } } end }
        local savedFavor4 = ns.db.favor
        ns.db.favor = { costs = {} }
        FV.Cost(fri)
        local curFromAHS = ns.db.favor.currency
        ns.db.favor = savedFavor4
        _G.AHAnalyzerPro = saveA
        check("Händlergunst: Währungs-ID von AHSentinel übernommen (Stand auch ohne eigenen Händlerbesuch)", curFromAHS == 3333, tostring(curFromAHS))
    end

    -- 5. Trainers, locations, waypoints (QuestieDB data – not for Retail)
    local WP = ns.Waypoint
    if ns.HasSourceData == false then
        local mid = ns.ProfById[2915]
        check("Retail: Erweiterungen als eigene Berufe (Lederverarbeitung von Midnight)", mid ~= nil and mid.parent == 165 and #(ns.ByProf[2915] or {}) > 10,
            mid and (mid.name .. ", " .. #(ns.ByProf[2915] or {})))
        check("Retail: Classic-Rezept liegt in der Classic-Linie (Feine Lederstiefel)", flb ~= nil and ns.ProfById[flb.prof] and ns.ProfById[flb.prof].parent == 165,
            flb and tostring(flb.prof))
        check("Retail: Lehrer-Reiter ausgeblendet, Ziel Verzauberkunst = VZ verkaufen", ns.Disenchant.Goal() == "sell")
    else
    local lw = ns.Trainers and ns.Trainers[165] or {}
    local una
    for _, e in ipairs(lw) do if e[1] == 3007 then una = e end end
    local unaN = ns.NPCs[3007]
    check("Lehrer geladen (Lederverarbeitung) / trainers loaded", #lw > 5, #lw .. " Lehrer")
    check("Una = Fachmann (bis 300) mit Koordinaten", una and una[2] == 4 and unaN and unaN[6] and unaN[7] and unaN[8],
        unaN and string.format("%s %.1f, %.1f", tostring(unaN[2]), unaN[7] or 0, unaN[8] or 0))
    local ranksOk = true
    for _, list in pairs(ns.Trainers or {}) do
        for _, e in ipairs(list) do
            if not ns.NPCs[e[1]] or e[2] < 0 or e[2] > 5 then ranksOk = false end
        end
    end
    check("Alle Lehrer haben Daten und gültigen Rang / all trainers valid", ranksOk)
    local n1 = WP.NextRank(70, 75)
    local n2 = WP.NextRank(210, 225)
    local n3 = WP.NextRank(300, 300)
    check("Nächster Rang: 70/75 -> Geselle, 210/225 -> Fachmann, 300/300 -> keiner",
        n1 and n1.key == 2 and n2 and n2.key == 4 and n3 == nil)
    local flbVendor
    for _, r in ipairs(ns.Recipes) do
        if r.nameEN == "Murloc Scale Belt" then flbVendor = WP.BestSourceNPC(r) end
    end
    check("Rezept -> Händler mit Koordinaten (Murlocschuppengürtel)", flbVendor ~= nil and WP.Has(flbVendor),
        flbVendor and WP.LocationText(flbVendor))
    end

    -- 6. Character / scan
    local c = ns.Char()
    check("Charakterdaten vorhanden / character data", c ~= nil)

    -- 7. UI building blocks
    check("Panel-Bausteine / panel building blocks", CreateTreeDataProvider ~= nil and ScrollUtil ~= nil and CreateScrollBoxListTreeListView ~= nil)

    local head = string.format("|cffffd100Selbsttest / self-test:|r %d/%d %s", #results - fails, #results, L.TEST_PASS)
    table.insert(results, 1, head)
    local text = table.concat(results, "\n")
    if resultText then resultText:SetText(text) end
    if toChat then
        ns.Print(head)
        for i = 2, #results do
            if results[i]:find(L.TEST_FAIL, 1, true) then ns.Print(results[i]) end
        end
    end
    return fails == 0, results
end

---------------------------------------------------------------------------
-- Window
---------------------------------------------------------------------------
local function ProfList()
    local list = {}
    for _, p in ipairs(ns.Professions) do
        if ns.ByProf[p.id] and #ns.ByProf[p.id] > 3 then list[#list + 1] = p end
    end
    return list
end

local function UpdateProfLabel()
    local list = ProfList()
    local p = list[profIndex]
    profLabel:SetText(p and (ns.ProfName(p.id) .. " (" .. #ns.ByProf[p.id] .. ")") or "-")
end

local function UpdateKnownButtons()
    local mode = ns.Sim and ns.Sim.known or "real"
    for key, b in pairs(knownButtons) do
        b:SetText((mode == key and "> " or "") .. b.label .. (mode == key and " <" or ""))
    end
end

local function SetSkill(v)
    v = math.max(1, math.min(375, math.floor(v + 0.5)))
    skillSlider:SetValue(v)
end

local function MakeButton(parent, text, w, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w, 22)
    b:SetText(text)
    b:SetScript("OnClick", onClick)
    return b
end

local function CreateWindow()
    win = CreateFrame("Frame", "ProfessionSentinelTestMode", UIParent, "ButtonFrameTemplate")
    win:Hide()      -- new frames start visible in the client: hidden here, so the first /ps test opens it
    win:SetSize(520, 812)
    win:SetPoint("CENTER", UIParent, "CENTER", -260, 0)
    win:SetFrameStrata("DIALOG")
    win:SetMovable(true)
    win:EnableMouse(true)
    win:RegisterForDrag("LeftButton")
    win:SetScript("OnDragStart", win.StartMoving)
    win:SetScript("OnDragStop", win.StopMovingOrSizing)
    win:SetClampedToScreen(true)
    if ButtonFrameTemplate_HidePortrait then ButtonFrameTemplate_HidePortrait(win) end
    if ButtonFrameTemplate_HideButtonBar then ButtonFrameTemplate_HideButtonBar(win) end
    win:SetTitle(L.TEST_TITLE)
    if win.Inset then win.Inset:Hide() end
    tinsert(UISpecialFrames, "ProfessionSentinelTestMode")

    local y = -32
    local function header(text)
        local fs = win:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        fs:SetPoint("TOPLEFT", 16, y)
        fs:SetText(text)
        y = y - 22
        return fs
    end

    -- Simulation ---------------------------------------------------------
    header("|cffffd100" .. L.TEST_SIM .. "|r")

    -- profession picker
    local pl = win:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    pl:SetPoint("TOPLEFT", 16, y); pl:SetText(L.TEST_PROF .. ":")
    local prev = MakeButton(win, "<", 26, function()
        local n = #ProfList(); profIndex = profIndex - 1; if profIndex < 1 then profIndex = n end; UpdateProfLabel()
        if ns.Sim and ns.Sim.prof then Sim().prof = ProfList()[profIndex].id; RefreshAll() end
    end)
    prev:SetPoint("TOPLEFT", 120, y + 4)
    profLabel = win:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    profLabel:SetPoint("LEFT", prev, "RIGHT", 8, 0)
    profLabel:SetWidth(180)
    local nextB = MakeButton(win, ">", 26, function()
        local n = #ProfList(); profIndex = profIndex + 1; if profIndex > n then profIndex = 1 end; UpdateProfLabel()
        if ns.Sim and ns.Sim.prof then Sim().prof = ProfList()[profIndex].id; RefreshAll() end
    end)
    nextB:SetPoint("LEFT", profLabel, "RIGHT", 8, 0)
    y = y - 30
    local open = MakeButton(win, L.TEST_OPEN_PANEL, 300, function()
        local p = ProfList()[profIndex]
        if not p then return end
        Sim().prof = p.id
        ns.UI:Show(nil)
        RefreshAll()
    end)
    open:SetPoint("TOPLEFT", 16, y)
    y = y - 34

    -- skill slider
    skillActive = CreateFrame("CheckButton", nil, win, "UICheckButtonTemplate")
    skillActive:SetSize(22, 22)
    skillActive:SetPoint("TOPLEFT", 12, y + 2)
    local sl = win:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    sl:SetPoint("LEFT", skillActive, "RIGHT", 2, 0)
    sl:SetText(L.TEST_SKILL)
    skillValue = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    skillValue:SetPoint("TOPRIGHT", -20, y)
    y = y - 26
    skillSlider = CreateFrame("Slider", nil, win)
    skillSlider:SetOrientation("HORIZONTAL")
    skillSlider:SetSize(380, 16)
    skillSlider:SetPoint("TOPLEFT", 50, y)
    skillSlider:SetMinMaxValues(1, 375)
    skillSlider:SetValueStep(1)
    if skillSlider.SetObeyStepOnDrag then skillSlider:SetObeyStepOnDrag(true) end
    local track = skillSlider:CreateTexture(nil, "BACKGROUND")
    track:SetPoint("LEFT"); track:SetPoint("RIGHT"); track:SetHeight(6)
    track:SetColorTexture(0.25, 0.22, 0.18, 1)
    skillSlider:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
    skillSlider:EnableMouseWheel(true)
    skillSlider:SetScript("OnMouseWheel", function(self, d) SetSkill(self:GetValue() + d) end)
    local minus = MakeButton(win, "-", 26, function() SetSkill(skillSlider:GetValue() - 1) end)
    minus:SetPoint("RIGHT", skillSlider, "LEFT", -6, 0)
    local plus = MakeButton(win, "+", 26, function() SetSkill(skillSlider:GetValue() + 1) end)
    plus:SetPoint("LEFT", skillSlider, "RIGHT", 6, 0)
    skillSlider:SetScript("OnValueChanged", function(self, v)
        v = math.floor(v + 0.5)
        skillValue:SetText(skillActive:GetChecked() and v or ("|cff9d9d9d" .. v .. " (" .. L.TEST_SKILL_OFF .. ")|r"))
        if skillActive:GetChecked() then Sim().rank = v; RefreshAll() end
    end)
    skillActive:SetScript("OnClick", function(self)
        if self:GetChecked() then Sim().rank = math.floor(skillSlider:GetValue() + 0.5)
        elseif ns.Sim then ns.Sim.rank = nil end
        skillSlider:GetScript("OnValueChanged")(skillSlider, skillSlider:GetValue())
        RefreshAll()
    end)
    y = y - 34

    -- learned state
    local kl = win:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    kl:SetPoint("TOPLEFT", 16, y); kl:SetText(L.TEST_KNOWN .. ":")
    knownButtons = {}
    local x = 150
    for _, def in ipairs({ { "real", L.TEST_KNOWN_REAL }, { "all", L.TEST_KNOWN_ALL }, { "none", L.TEST_KNOWN_NONE } }) do
        local key, label = def[1], def[2]
        local b = MakeButton(win, label, 116, function()
            Sim().known = key ~= "real" and key or nil
            UpdateKnownButtons(); RefreshAll()
        end)
        b.label = label
        b:SetPoint("TOPLEFT", x, y + 4)
        knownButtons[key] = b
        x = x + 120
    end
    y = y - 34

    -- actions
    local run = MakeButton(win, L.TEST_RUN, 200, function() TM:RunSelfTest(false) end)
    run:SetPoint("TOPLEFT", 16, y)
    local reset = MakeButton(win, L.TEST_RESET, 140, function() TM:Reset() end)
    reset:SetPoint("LEFT", run, "RIGHT", 10, 0)
    local lineToggle = MakeButton(win, L.LL_OPTION, 150, function()
        ns.db.lifeline = not ns.db.lifeline
        RefreshAll()
    end)
    lineToggle:SetPoint("LEFT", reset, "RIGHT", 10, 0)
    lineToggle:SetWidth(140)
    y = y - 30
    local wpTest = MakeButton(win, L.TEST_WAYPOINT, 300, function()
        local p = ProfList()[profIndex]
        local list = p and ns.Trainers and ns.Trainers[p.id]
        if list and list[1] then ns.Waypoint.Set(list[1][1]) end
    end)
    wpTest:SetPoint("TOPLEFT", 16, y)
    local trainerTab = MakeButton(win, L.TRAINERS, 140, function()
        local p = ProfList()[profIndex]
        if not p then return end
        Sim().prof = p.id
        ns.db.panelMode = "trainers"
        ns.UI:Show(nil)
        RefreshAll()
    end)
    trainerTab:SetPoint("LEFT", wpTest, "RIGHT", 10, 0)
    y = y - 30
    -- test prices: every item at 4× its vendor sell value (min. 1s) – only to try the gold ranking without an AH scan
    local priceBtn = MakeButton(win, L.TEST_PRICES, 300, function()
        if ns.Sim and ns.Sim.prices then
            ns.Sim.prices = nil
        else
            Sim().prices = setmetatable({}, { __index = function(_, id)
                local d = ns.Items[id]
                if not d then return nil end
                return math.max((d[3] or 0) * 4, 100)
            end })
        end
        RefreshAll()
    end)
    priceBtn:SetPoint("TOPLEFT", 16, y)
    local rankTab = MakeButton(win, L.RANKING_TAB, 140, function()
        local p = ProfList()[profIndex]
        if not p then return end
        Sim().prof = p.id
        ns.db.panelMode = "ranking"
        ns.UI:Show(nil)
        RefreshAll()
    end)
    rankTab:SetPoint("LEFT", priceBtn, "RIGHT", 10, 0)
    y = y - 30
    -- enchanter: simulate enchanting, cycle the goal gold -> sell -> both, test disenchant values
    -- (green/blue/epic items: 6× their vendor sell value, min. 5s)
    local GOALS = { "gold", "sell", "both" }
    local deBtn = MakeButton(win, L.TEST_ENCHANTER, 300, function()
        local s = Sim()
        s.enchanter = true
        local idx = 0
        for i, g in ipairs(GOALS) do if s.goal == g then idx = i end end
        s.goal = GOALS[idx % #GOALS + 1]
        s.de = s.de or setmetatable({}, { __index = function(_, id)
            local d = ns.Items[id]
            if not d or (d[2] or 0) < 2 then return nil end
            return math.max((d[3] or 0) * 6, 500)
        end })
        ns.Print(string.format(L.GOAL_SET, L["GOAL_" .. s.goal:upper()]))
        RefreshAll()
    end)
    deBtn:SetPoint("TOPLEFT", 16, y)
    local deTab = MakeButton(win, L.DE_TAB, 140, function()
        local p = ProfList()[profIndex]
        local s = Sim()
        if s.enchanter == nil then s.enchanter = true end
        if p then s.prof = p.id end
        ns.db.panelMode = "disenchant"
        ns.UI:Show(nil)
        RefreshAll()
    end)
    deTab:SetPoint("LEFT", deBtn, "RIGHT", 10, 0)
    y = y - 34

    -- result / diagnostics text
    resultText = win:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    resultText:SetPoint("TOPLEFT", 16, y)
    resultText:SetWidth(488)
    resultText:SetJustifyH("LEFT")
    resultText:SetJustifyV("TOP")
    resultText:SetSpacing(2)
    diagText = resultText

    win:SetScript("OnShow", function()
        UpdateProfLabel()
        UpdateKnownButtons()
        resultText:SetText(TM:Diagnostics())
    end)
    -- default slider position: real rank of the first profession or 1
    local c = ns.Char()
    local startRank = 1
    if c then for _, p in pairs(c.profs) do startRank = math.max(startRank, p.rank or 1) end end
    skillSlider:SetValue(startRank)
end

function TM:Reset()
    ns.Sim = nil
    if skillActive then skillActive:SetChecked(false) end
    if skillSlider then skillSlider:GetScript("OnValueChanged")(skillSlider, skillSlider:GetValue()) end
    if knownButtons then UpdateKnownButtons() end
    if ns.UI and ns.UI:IsShown() then
        local host = (ns.UsesModernProfessions and ProfessionsFrame and ProfessionsFrame:IsShown() and ProfessionsFrame)
            or (CraftFrame and CraftFrame:IsShown() and CraftFrame)
            or (TradeSkillFrame and TradeSkillFrame:IsShown() and TradeSkillFrame)
        if host then ns.UI:Show(host) else ns.UI:Hide() end
    end
    if resultText then resultText:SetText(TM:Diagnostics()) end
    RefreshAll()
end

function TM:Toggle()
    if not ns.IsDev() then return end
    if not win then CreateWindow() end
    if win:IsShown() then win:Hide() else win:Show() end
end
