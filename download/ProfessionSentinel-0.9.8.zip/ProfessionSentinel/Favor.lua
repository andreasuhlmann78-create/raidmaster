local _, ns = ...
local L = ns.L

-- WoW Forever: Merchant's Favor (Händlergunst) – supply camps, recipes, crates.
--   Horde:    Durotar Supply and Logistics (faction 2587), camp west of the Crossroads in the Barrens,
--             crates to Dokimi
--   Alliance: Azeroth Commerce Authority (faction 2586), camp at Three Corners (Redridge), crates to Marcy Baker
--
-- 1. Recipe costs: data from public guides (ri.fv = favor, ri.fe = estimated, ri.fa/ri.fr = reputation,
--    pipeline/favor_costs.json). The client tables carry no vendor costs, so the real costs win when known:
--      a) read here at the open vendor (GetMerchantItemCostInfo / GetMerchantItemCostItem), stored in
--         ProfessionSentinelDB.favor.costs
--      b) read by AHSentinel at the vendor (AHAnalyzerPro:GetVendorCost) – used when we have nothing ourselves
-- 2. Planner (8.2): favor balance, wish list (recipes + goals like the Pack Kodo), "still X favor to go".
-- 3. Crate calculator (8.3): Waylaid Crates (ns.Crates, pipeline/crates.json) – cheapest bundle per crate from
--    vendor/AH prices, favor per crate, gold per favor point.
-- 4. Guild view (8.4): which favor recipes somebody in the guild already knows (Guild.lua).
-- Everything here is WoW Forever only; the other game versions never call it.

local F = {}
ns.Favor = F

F.FACTION_HORDE = 2587
F.FACTION_ALLIANCE = 2586
F.CURRENCY_NAMES = { ["merchant's favor"] = true, ["händlergunst"] = true }

-- other things you can buy with favor (from guides, beta) – goals for the planner
F.GOALS = {
    { key = "kodo", cost = 6000, label = "FAVOR_GOAL_KODO", need = "FAVOR_GOAL_KODO_NEED" },
    { key = "minimule", cost = 1500, label = "FAVOR_GOAL_MULE", need = "FAVOR_GOAL_MULE_NEED" },
    { key = "cert", cost = 1000, label = "FAVOR_GOAL_CERT", need = "FAVOR_GOAL_CERT_NEED" },
    { key = "tabard", cost = 200, label = "FAVOR_GOAL_TABARD", need = "FAVOR_GOAL_TABARD_NEED" },
}

function F.Active()
    return ns.IsForever == true
end

-- reputation faction for this character: the data carries the Horde id, Alliance players get theirs
-- (group = "Horde" / "Alliance" for tests, otherwise the player's faction)
function F.Faction(fa, group)
    group = group or (UnitFactionGroup and UnitFactionGroup("player"))
    if fa == F.FACTION_HORDE and group == "Alliance" then
        return F.FACTION_ALLIANCE
    end
    return fa
end

local function DB()
    if not ns.db then return nil end
    ns.db.favor = ns.db.favor or { costs = {} }
    local d = ns.db.favor
    d.costs = d.costs or {}
    d.wish = d.wish or {}
    d.goals = d.goals or {}
    return d
end
F.DB = DB

-- favor cost AHSentinel read at the vendor (nil if unknown)
local function AHSentinelCost(itemID)
    local A = _G.AHAnalyzerPro
    if not (A and A.GetVendorCost) then return nil end
    local ok, vc = pcall(A.GetVendorCost, A, itemID)
    if not (ok and type(vc) == "table" and type(vc.costs) == "table") then return nil end
    for _, c in ipairs(vc.costs) do
        if c.kind == "currency" and c.amount and c.amount > 0 then
            -- remember the currency id, so F.Balance() also works when only AHSentinel saw the vendor
            local d = DB()
            if d and not d.currency and type(c.id) == "number" then d.currency = c.id end
            return { n = c.amount, name = c.name, cur = c.id }
        end
    end
    return nil
end

-- cost of a recipe item: { n = amount, name = currency name or nil, learned = true/false, estimate = true/false }
-- nil if it is not paid with favor (then ri.bp is the gold price)
function F.Cost(ri)
    if not ri then return nil end
    local db = DB()
    local seen = db and db.costs[ri.id]
    if seen and seen.n then
        return { n = seen.n, name = seen.c, learned = true }
    end
    if ri.fv then
        local ahs = AHSentinelCost(ri.id)
        if ahs then return { n = ahs.n, name = ahs.name, learned = true } end
        return { n = ri.fv, estimate = ri.fe == 1, learned = false }
    end
    return nil
end

-- what the player owns: the currency id seen at a vendor, otherwise the currency list by name
function F.Balance()
    local CI = C_CurrencyInfo
    if not CI then return nil end
    local db = DB()
    local id = db and db.currency
    if id and CI.GetCurrencyInfo then
        local ok, info = pcall(CI.GetCurrencyInfo, id)
        if ok and type(info) == "table" and info.quantity then return info.quantity end
    end
    if CI.GetCurrencyListSize and CI.GetCurrencyListInfo then
        local okN, n = pcall(CI.GetCurrencyListSize)
        for i = 1, (okN and n or 0) do
            local ok, info = pcall(CI.GetCurrencyListInfo, i)
            if ok and type(info) == "table" and type(info.name) == "string" and F.CURRENCY_NAMES[info.name:lower()] then
                return info.quantity or 0
            end
        end
    end
    return nil
end

-- tooltip text: "120 Merchant's Favor (you have 80)" – with "estimated", "guides" or "seen at the vendor"
function F.CostText(ri)
    local c = F.Cost(ri)
    if not c then return nil end
    local name = c.name or L.FAVOR_NAME
    local s = "|cff66ccff" .. c.n .. " " .. name .. "|r"
    local have = F.Balance()
    if have then
        local col = have >= c.n and "40c040" or "ff6060"
        s = s .. " |cff" .. col .. "(" .. string.format(L.FAVOR_HAVE, have) .. ")|r"
    end
    if c.learned then
        s = s .. " |cff9d9d9d" .. L.FAVOR_SEEN .. "|r"
    elseif c.estimate then
        s = s .. " |cff9d9d9d" .. L.FAVOR_ESTIMATE .. "|r"
    else
        s = s .. " |cff9d9d9d" .. L.FAVOR_GUIDE .. "|r"
    end
    return s
end

---------------------------------------------------------------------------
-- Favor recipes
---------------------------------------------------------------------------
-- all favor recipes of a profession (prof = nil: all professions): { { recipe, ri, cost } }
function F.Recipes(prof)
    local out = {}
    local list = prof and (ns.ByProf[prof] or {}) or ns.Recipes or {}
    for _, r in ipairs(list) do
        for _, ri in ipairs(r.recipeItems or {}) do
            if ri.fv then
                out[#out + 1] = { recipe = r, ri = ri, cost = F.Cost(ri) }
                break
            end
        end
    end
    table.sort(out, function(a, b)
        if (a.ri.rs or 0) ~= (b.ri.rs or 0) then return (a.ri.rs or 0) < (b.ri.rs or 0) end
        return ns.RecipeName(a.recipe) < ns.RecipeName(b.recipe)
    end)
    return out
end

-- recipe item of a recipe that costs favor (nil if none)
function F.RecipeItem(r)
    for _, ri in ipairs(r and r.recipeItems or {}) do
        if ri.fv then return ri end
    end
    return nil
end

---------------------------------------------------------------------------
-- 8.2 Planner: wish list (recipes and goals), what is still missing
---------------------------------------------------------------------------
function F.IsWished(riID) local d = DB(); return d and d.wish[riID] == true or false end
function F.ToggleWish(riID)
    local d = DB(); if not d then return end
    d.wish[riID] = (not d.wish[riID]) or nil
    if ns.RefreshAll then ns.RefreshAll() end
end
function F.IsGoal(key) local d = DB(); return d and d.goals[key] == true or false end
function F.ToggleGoal(key)
    local d = DB(); if not d then return end
    d.goals[key] = (not d.goals[key]) or nil
    if ns.RefreshAll then ns.RefreshAll() end
end

-- { total, have (nil = unknown), missing, items = { { name, n, kind = "recipe"|"goal", recipe } } }
-- learned recipes drop out of the wish list by themselves
function F.Plan()
    local d = DB()
    local res = { total = 0, items = {} }
    if not d then return res end
    for riID in pairs(d.wish) do
        local r = ns.ByRecipeItem and ns.ByRecipeItem[riID]
        local ri = r and F.RecipeItem(r)
        if ri and not ns.IsLearned(r) then
            local c = F.Cost(ri)
            local n = c and c.n or 0
            res.items[#res.items + 1] = { kind = "recipe", recipe = r, ri = ri, n = n, name = ns.RecipeName(r) }
            res.total = res.total + n
        end
    end
    for _, g in ipairs(F.GOALS) do
        if d.goals[g.key] then
            res.items[#res.items + 1] = { kind = "goal", goal = g, n = g.cost, name = L[g.label] }
            res.total = res.total + g.cost
        end
    end
    table.sort(res.items, function(a, b) return a.n < b.n end)
    res.have = F.Balance()
    res.missing = math.max(0, res.total - (res.have or 0))
    return res
end

---------------------------------------------------------------------------
-- 8.3 Crate calculator
---------------------------------------------------------------------------
local function BagCount(id)
    if C_Item and C_Item.GetItemCount then return C_Item.GetItemCount(id, false) or 0 end
    if GetItemCount then return GetItemCount(id, false) or 0 end
    return 0
end
F.BagCount = BagCount

-- one crate: { crate, favor, est, bundles = { { id, count, unit, cost, known, have } }, best, crateAH, total, perFavor, inBags }
-- best = cheapest bundle with known prices; total = bundle + empty crate from the AH (when you have none)
function F.CrateValue(c, countFn)
    countFn = countFn or BagCount
    local P = ns.Prices
    local e = { crate = c, favor = c.favor, est = c.est == 1, bundles = {}, inBags = countFn(c.id) or 0 }
    for i = 1, #(c.b or {}), 2 do
        local id, n = c.b[i], c.b[i + 1]
        local unit, origin, known = P.ReagentUnit(id)
        local have = countFn(id) or 0
        local b = { id = id, count = n, unit = unit, origin = origin, known = known, cost = unit * n, have = have,
                    enough = have >= n }
        e.bundles[#e.bundles + 1] = b
        if known and (not e.best or b.cost < e.best.cost) then e.best = b end
    end
    e.crateAH = P.AH(c.id)
    if e.best then
        e.total = e.best.cost + ((e.inBags > 0) and 0 or (e.crateAH or 0))
        e.perFavor = e.total / math.max(1, c.favor)
    end
    -- a bundle you already have in your bags (no shopping needed)
    for _, b in ipairs(e.bundles) do
        if b.enough then e.ready = b; break end
    end
    return e
end

-- all crates, cheapest gold per favor first (unknown prices last); crates in your bags on top
function F.Crates(countFn)
    local out = {}
    for _, c in ipairs(ns.Crates or {}) do out[#out + 1] = F.CrateValue(c, countFn) end
    table.sort(out, function(a, b)
        if (a.inBags > 0) ~= (b.inBags > 0) then return a.inBags > 0 end
        if (a.perFavor ~= nil) ~= (b.perFavor ~= nil) then return a.perFavor ~= nil end
        if a.perFavor and b.perFavor and a.perFavor ~= b.perFavor then return a.perFavor < b.perFavor end
        return a.crate.id < b.crate.id
    end)
    return out
end

---------------------------------------------------------------------------
-- 8.4 Guild view: favor recipes somebody in the guild already knows
---------------------------------------------------------------------------
-- nil = no guild data, otherwise the list from Guild.lua ({} = nobody knows it)
function F.GuildKnows(r)
    local GU = ns.Guild
    if not (GU and GU.Crafters) then return nil end
    local ok, list = pcall(GU.Crafters, r)
    if ok then return list end
    return nil
end

---------------------------------------------------------------------------
-- Learning at the vendor: every item of the open vendor that teaches a recipe of our data
-- Modern client (Forever, Retail): C_MerchantFrame; the old global functions only as fallback.
---------------------------------------------------------------------------
local function MerchantItemID(i)
    if GetMerchantItemID then
        local ok, id = pcall(GetMerchantItemID, i)
        if ok and id then return id end
    end
    if not GetMerchantItemLink then return nil end
    local ok, link = pcall(GetMerchantItemLink, i)
    return ok and type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil
end

local function MerchantNumItems()
    local f = GetMerchantNumItems or (C_MerchantFrame and C_MerchantFrame.GetNumItems)
    if not f then return 0 end
    local ok, n = pcall(f)
    return ok and tonumber(n) or 0
end

function F.LearnFromMerchant()
    local db = DB()
    if not (db and GetMerchantItemCostInfo and GetMerchantItemCostItem) then return 0 end
    local learned = 0
    for i = 1, MerchantNumItems() do
        local id = MerchantItemID(i)
        if id and ns.ByRecipeItem and ns.ByRecipeItem[id] then
            local okN, count = pcall(GetMerchantItemCostInfo, i)
            if okN and type(count) == "number" and count > 0 then
                for j = 1, count do
                    local okC, _, value, link, currencyName = pcall(GetMerchantItemCostItem, i, j)
                    local currencyID = okC and type(link) == "string" and tonumber(link:match("currency:(%d+)"))
                    if okC and currencyID and value and value > 0 then
                        local old = db.costs[id]
                        if not (old and old.n == value) then learned = learned + 1 end
                        db.costs[id] = { n = value, c = currencyName, cur = currencyID, t = time and time() or 0 }
                        db.currency = db.currency or currencyID
                        break
                    end
                end
            end
        end
    end
    return learned
end

local ev = CreateFrame("Frame")
pcall(ev.RegisterEvent, ev, "MERCHANT_SHOW")
pcall(ev.RegisterEvent, ev, "MERCHANT_UPDATE")
ev:SetScript("OnEvent", function()
    if not ns.IsForever then return end
    local ok, n = pcall(F.LearnFromMerchant)
    if ok and n and n > 0 and ns.RefreshAll then ns.RefreshAll() end
end)
