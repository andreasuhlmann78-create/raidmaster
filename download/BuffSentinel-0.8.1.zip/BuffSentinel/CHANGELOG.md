# BuffSentinel – Changelog

## 0.8.1
- New: size per group – procs, buffs, cooldowns and dispel 50–200 % each, on top of the overall size ("Zonen & Anzeige" page). Groups and freely placed buttons keep their screen position when resized.
- New "reset sizes" button.

## 0.8.0
- New: **automatic learning.** When BuffSentinel meets procs or abilities that are not in its data yet (e.g. new content in WoW Forever), it adds them by itself:
  - Procs: a short self-buff gained in combat that is consumed three times by casting the same spell gets a proc button for that spell. Buffs that simply expire (weapon enchants, trinkets) and buffs from other players are ignored.
  - Abilities: class spells with a cooldown of at least 10 s are added to the cooldown bar as soon as you cast them or learn them (trainer, talent point).
  - Learned entries are remembered per spec and for all characters on the account.
  - Discoveries are shared with other BuffSentinel users (spell IDs only, can be turned off).
  - Overview, removal and on/off switch on the "Aufnahme" (recording) page.
- Spells not learned yet (greyed out in the Cata/MoP spellbook) and spells of other specializations no longer count as known.

## 0.7.3
- Long compound words are split at a word boundary onto two lines (e.g. "BLITZSCHLAG-" / "SCHILD!") instead of shrinking the font; the font only gets smaller if that is not enough.
- Umlauts are now capitalised correctly in alerts ("SEELENSTÄRKE" instead of "SEELENSTäRKE").

## 0.7.2
- Priest: Surge of Light casts Smite in TBC (Flash Heal only from WotLK on).
- Hunter: Kill Command is a baseline ability in TBC – now shown for all specs.
- Warrior: Commanding Shout available from TBC; new Rampage buff reminder (TBC Fury).
- Procs from a buff are labelled with their source (e.g. "SHADOW TRANCE!") with the spell to press below.
- Long labels shrink automatically instead of being cut off.
- Dispel bar moved below/left of the buffs, cooldown and dispel titles sit above their area – no more overlaps.

## 0.7.1
- Fixed: main talent tree detection (e.g. 14/41/0 is now Fury, not Arms) – also with dual spec; the active talent group is read explicitly.
- Fixed: talents and procs are filtered by game version. WoW Forever talents (Bloodthrill, Vanguard) and WotLK procs (Sudden Death, Bloodsurge, Sword and Board, Hot Streak) no longer appear in TBC/Classic Era.
- Fixed: test mode only shows talent procs of the selected spec (e.g. Hot Streak only for Fire, Nature's Grace only for Balance).
- Settings lists no longer jump when you untick an entry; new "Auto" button resets an entry to the automatic choice.
- Fixed missing glyphs (arrow, check mark) and an outdated hint text.
- Test mode layout: two-line labels, group titles beside their area, areas grow with the number of buttons, test bar at the very top, settings window closes when test mode starts, dispel bar shows 5 sample slots and is hidden for classes without dispels.
- Warlock procs are named after their source (Shadow Trance, Backlash).
- Server sync retries joining the channel and shows a clear status.
- Fixed a tooltip that stayed visible after opening the support window.

## 0.7.0
- New "Support" button (PayPal) in the settings window header and on the "Zonen & Anzeige" page; also `/bsen donate` (or `/bsen support`). Opens only on click – no pop-ups, no chat messages.

## 0.6.3
- At least 3 seconds between alert sounds, the same sound at most every 4 seconds.
- "Test sounds" plays all alerts 3 seconds apart and shows which one is playing.

## 0.6.1
- WoW Forever: new Paladin (Seal of Fury, Light's Vigil, Voice of Truth, Swift Judgement, Templar's Bulwark, Infusion of Light) and Shaman abilities (Rage of the Farseer, Fire Nova, Totemic Projection).
- Test mode in Classic Era shows only the classes of your faction.

## 0.6.0
- Test mode with sample display for all classes and specs; buttons can be placed freely.

## 0.5.0
- Dispel bar for party/raid members and enemy dispel/purge buttons.

## 0.4.0
- First release: proc buttons, buff reminders with one-click buffing, cooldown bar, talent detection, all WoW versions.
