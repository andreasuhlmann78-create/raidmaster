-- BuffSentinel - SelfTest.lua
-- Testroutine (nur Entwickler, GoldSentinelDev): prüft das Addon im Spiel und schreibt einen Bericht über
-- GoldSentinelTest in BuffSentinelDB.gsTest (wird beim nächsten /reload oder Ausloggen an die Prüfung gemeldet).
--
--   /bsen testroutine              alles (Bereiche A bis J)
--   /bsen testroutine <bereich>    laden | funktionen | forever | alt | daten | sprache | zusammen | leistung | fehler | regression
--   /bsen testroutine kampf        halbautomatisch: beobachtet den nächsten Kampf
--   /bsen selbsttest               Versionsweiche (G.SetTestFlavor) – siehe Core.lua
--
-- Regeln: Keine Blizzard-Funktion wird ersetzt. Fehlende alte Funktionen und geschützte Werte stellt die Routine nur
-- über BS.apiOverride (eigene Tabelle BS.API) und BS.testSecrets (Köderwerte) nach. Kampfsperre über BS.testLockdown /
-- BS.testCombat. Nichts wird gesendet, kein Kanal betreten, kein Zauber gewirkt, kein Ton gespielt; echte Daten liegen
-- während des Laufs in einer Sandbox und werden danach verglichen. Testfall-IDs T01 … T138 bleiben über Versionen gleich.

local ADDON, BS = ...
local L = BS.L
local API = BS.API

local Selftest = {}
BS.Selftest = Selftest

local AREAS = {
    laden = "A", funktionen = "B", forever = "C", alt = "D", daten = "E", sprache = "F",
    zusammen = "G", leistung = "H", fehler = "I", regression = "J",
}
local AREA_ORDER = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J" }

------------------------------------------------------------------------
-- Hilfen
------------------------------------------------------------------------
local function DeepCopy(v, skipKey)
    if type(v) ~= "table" then return v end
    local o = {}
    for k, x in pairs(v) do
        if k ~= skipKey then o[k] = DeepCopy(x) end
    end
    return o
end

-- erster abweichender Pfad (oder nil)
local function FirstDiff(a, b, path, skipKey)
    path = path or ""
    if type(a) ~= type(b) then return path ~= "" and path or L.ROOT end
    if type(a) ~= "table" then
        if a ~= b then return path ~= "" and path or L.ROOT end
        return nil
    end
    for k, v in pairs(a) do
        if k ~= skipKey then
            local d = FirstDiff(v, b[k], path == "" and tostring(k) or (path .. "." .. tostring(k)))
            if d then return d end
        end
    end
    for k in pairs(b) do
        if k ~= skipKey and a[k] == nil then return path == "" and tostring(k) or (path .. "." .. tostring(k)) end
    end
    return nil
end

local function Count(t)
    local n = 0
    if type(t) == "table" then for _ in pairs(t) do n = n + 1 end end
    return n
end

local function YN(v) return v and L.YES or L.NO end

-- Ausgaben von BS.Print abfangen (nie in den Bericht übernehmen, nur prüfen)
local function Capture(fn)
    local lines, old = {}, BS.Print
    BS.Print = function(m) lines[#lines + 1] = tostring(m) end
    local ok, err = pcall(fn)
    BS.Print = old
    if not ok then error(err, 0) end
    return lines
end

local function AnyLine(lines, pattern)
    for _, l in ipairs(lines) do if l:find(pattern, 1, true) then return true end end
    return false
end

-- Felder vorübergehend setzen (BS oder eine andere eigene Tabelle) und immer zurückstellen
local function With(fields, fn, target)
    target = target or BS
    local old, keys = {}, {}
    for k, v in pairs(fields) do keys[#keys + 1] = k; old[k] = rawget(target, k); target[k] = v end
    local ok, a, b, c = pcall(fn)
    for _, k in ipairs(keys) do target[k] = old[k] end
    if not ok then error(a, 0) end
    return a, b, c
end

-- Spiel-Funktionen über BS.API nachstellen (Blizzard-Funktionen bleiben unberührt)
local function WithApi(over, fn)
    local prev = BS.apiOverride
    local merged = {}
    if prev then for k, v in pairs(prev) do merged[k] = v end end
    for k, v in pairs(over) do merged[k] = v end
    BS.apiOverride = merged
    local ok, a, b, c = pcall(fn)
    BS.apiOverride = prev
    if not ok then error(a, 0) end
    return a, b, c
end

-- Tabelle mit einzelnen Funktionen ersetzt, Rest aus dem Original (C_Spell, C_UnitAuras …) – nur lesen
local function Overlay(orig, fields)
    return setmetatable(fields, { __index = (type(orig) == "table") and orig or nil })
end

-- Geschützter Testwert: jede Rechnung, jeder Vergleich, jedes Verketten oder Indizieren wirft einen Fehler
local SECRET_MT = {}
for _, m in ipairs({ "__add", "__sub", "__mul", "__div", "__mod", "__pow", "__unm", "__lt", "__le", "__concat", "__len",
                     "__index", "__newindex", "__call" }) do
    SECRET_MT[m] = function() error(L.PROTECTED_TEST_VALUE, 2) end
end
local function NewSecret()
    local s = setmetatable({}, SECRET_MT)
    BS.testSecrets = BS.testSecrets or {}
    BS.testSecrets[s] = true
    return s
end

-- Steckt der Köderwert irgendwo als Schlüssel oder Wert?
local function Contains(t, s, seen)
    if type(t) ~= "table" then return false end
    seen = seen or {}
    if seen[t] then return false end
    seen[t] = true
    for k, v in pairs(t) do
        if rawequal(k, s) or rawequal(v, s) then return true end
        if type(v) == "table" and getmetatable(v) ~= SECRET_MT and Contains(v, s, seen) then return true end
    end
    return false
end

local function Leaked(s)
    local places = {
        playerAuras = BS.playerAuras, playerAuraInfo = BS.playerAuraInfo, groupMissing = BS.groupMissing,
        unitInfo = BS.unitInfo, dispelTypes = BS.dispelSpells and BS.dispelSpells.types,
        learned = BS.gdb and BS.gdb.learned, auto = BS.gdb and BS.gdb.auto,
    }
    for name, t in pairs(places) do if Contains(t, s) then return name end end
    return nil
end

-- Version simulieren (G.SetTestFlavor) und sicher zurückkehren
local function Sim(flavor, fn)
    local G = GoldSentinelGame
    local oldSecrets = BS.testSecrets
    G.SetTestFlavor(flavor)
    BS:DetectFlavor()
    -- Forever simuliert auf einem alten Client: wie ein Client mit geheimen Werten behandeln
    if flavor == "forever" and not G.HasSecrets and not BS.testSecrets then BS.testSecrets = {} end
    Selftest.simulated = true
    local ok, a, b, c = pcall(fn)
    G.SetTestFlavor(nil)
    BS.testSecrets = oldSecrets
    BS:DetectFlavor()
    if not ok then error(a, 0) end
    return a, b, c
end

-- Knopf-Ersatz für die Auswertungsfunktionen (kein Secure-Button, nichts wird geklickt)
local function FakeText()
    local t = { txt = "" }
    function t:SetText(x) self.txt = x end
    function t:GetText() return self.txt end
    return t
end
local function FakeButton()
    local fb = { attrs = {} }
    fb.count, fb.target, fb.timer = FakeText(), FakeText(), FakeText()
    fb.icon = { SetDesaturated = function(self, v) self.desat = v end, SetVertexColor = function(self, r) self.r = r end }
    function fb:GetAttribute(k) return self.attrs[k] end
    function fb:SetAttribute(k, v) self.attrs[k] = v end
    return fb
end

local function PoolButtons(withEntry)
    local out = {}
    for _, kind in ipairs({ "proc", "buff", "cd" }) do
        for _, b in ipairs(BS.pools[kind] or {}) do
            if not withEntry or b.entry then out[#out + 1] = b end
        end
    end
    return out
end

local function ErrCount() return (BS.errors and BS.errors.count) or 0 end

-- Texte einer Optionsseite (alle sichtbaren FontStrings)
local function PageTexts(key)
    local f = BS.optionsFrame
    if not f then return "" end
    local page = f.pages[key]
    local out = {}
    local function scan(fr)
        for _, r in ipairs({ fr:GetRegions() }) do
            if r.GetText and r:IsShown() then
                local t = r:GetText()
                if type(t) == "string" then out[#out + 1] = t end
            end
        end
        for _, c in ipairs({ fr:GetChildren() }) do scan(c) end
    end
    scan(page.child)
    return table.concat(out, "\n")
end

local function OpenPage(key)
    if not BS.optionsFrame then BS:CreateOptions() end
    if not BS.optionsFrame:IsShown() then BS.optionsFrame:Show() end
    BS.currentPage = nil
    BS:ShowPage(key)
end

local function MaxPoints()
    local lv = UnitLevel("player") or 1
    if BS.isForever then return math.max(0, lv - 9) + 20 end   -- Forever: Talentsystem ungeklärt (T74), nur grob
    return math.max(0, lv - 9)
end

------------------------------------------------------------------------
-- Sandbox
------------------------------------------------------------------------
local STATE_FIELDS = {
    "class", "mainSpec", "testClass", "testStore", "testSoundStore", "testMode", "arrangeMode", "realClass", "realSpec",
    "entries", "errors", "secretNoted", "errShownEvent", "playerAuras", "playerAuraInfo", "groupMissing", "unitInfo",
    "unitAuras", "groupUnits", "triggers", "dispelSpells", "dispelActive", "syncReady", "syncState", "hasCombatLog",
    "interface", "expansion", "flavor", "family", "isForever", "isRetail", "restricted", "currentPage", "listFreeze",
    "recPrev", "assigning", "known", "classSpells", "spellbookOK", "talents", "talentList", "allTalents", "talentByName",
    "talentByPos", "talentSig", "points", "talentsReadable", "nameIndex", "hasItemEntries", "hidePending", "pendingLayout",
    "pendingScan", "soundListCache", "soundByKey", "autoCoveredCache", "ctx", "ctxOK", "testSoundCount",
}
local MUTABLE = { "playerAuras", "playerAuraInfo", "groupMissing", "triggers", "known", "classSpells" }

function Selftest:Enter()
    local real = BuffSentinelDB
    self.real = real
    self.key = BS:ProfileKey()
    self.snap = DeepCopy(real, "gsTest")
    local test = DeepCopy(real, "gsTest")
    self.state = {}
    for _, k in ipairs(STATE_FIELDS) do self.state[k] = BS[k] end
    self.errorsCopy = DeepCopy(BS.errors)
    self.autoState = BS:AutoTestState()
    self.optionsShown = BS.optionsFrame and BS.optionsFrame:IsShown()
    self.rasterShown = BS.raster and BS.raster:IsShown()
    self.print = BS.Print
    self.chat = {}
    BS.Print = function(m) self.chat[#self.chat + 1] = tostring(m) end
    -- eigene, frische Tabellen für alles, was in place verändert wird
    for _, k in ipairs(MUTABLE) do BS[k] = DeepCopy(BS[k] or {}) end
    BS.errors = DeepCopy(BS.errors)
    BuffSentinelDB = test
    BS.gdb = test
    BS.db = test.profiles[self.key]
    BS.testCommUntil = GetTime() + 15
    BS.testSink = {}
    BS.testMute = true
    BS:AutoTestState({ active = {}, prevInfo = {}, recentCasts = {}, pendingRemove = {} })
    self.simulated = false
end

function Selftest:Leave()
    local G = GoldSentinelGame
    if G and G.SetTestFlavor then G.SetTestFlavor(nil) end
    BS.apiOverride, BS.testSecrets, BS.testLockdown, BS.testCombat, BS.testMute, BS.testNoGame = nil, nil, nil, nil, nil, nil
    if BS.testMode then pcall(BS.StopTestMode, BS, true) end
    BuffSentinelDB = self.real
    BS.gdb = self.real
    BS.db = self.real.profiles[self.key]
    for _, k in ipairs(STATE_FIELDS) do BS[k] = self.state[k] end
    BS.errors = self.errorsCopy
    BS:AutoTestState(self.autoState)
    BS:CommReset()
    BS.testSink = {}
    BS.Print = self.print
    BS:DetectFlavor()
    -- Anzeige wieder auf die echten Daten
    pcall(BS.ApplyPositions, BS)
    pcall(BS.ApplyScale, BS)
    for key in pairs(BS.windows) do pcall(BS.PlaceWindow, BS, key) end
    pcall(BS.UpdateMinimapButton, BS)
    if BS.raster and BS.raster:IsShown() and not self.rasterShown then BS.raster:Hide() end
    if Selftest.donateFrame and Selftest.donateFrame:IsShown() then Selftest.donateFrame:Hide() end
    pcall(BS.FullScan, BS)
    if BS.optionsFrame then
        if self.optionsShown then BS.optionsFrame:Show(); pcall(BS.RefreshOptions, BS) else BS.optionsFrame:Hide() end
    end
    local diff = FirstDiff(self.snap, DeepCopy(BuffSentinelDB, "gsTest"))
    if diff then
        -- Profilschlüssel enthält den Charakternamen: nie in den Bericht
        diff = diff:gsub(self.key:gsub("%p", "%%%0"), "<profil>")
        return "FEHLER: " .. diff
    end
    return "OK"
end

------------------------------------------------------------------------
-- Ablauf
------------------------------------------------------------------------
local Run = {}

local function Abort()
    return InCombatLockdown() or UnitAffectingCombat("player")
end

-- Prüfung mit Abbruch bei Kampfbeginn
local function C(R, id, area, name, fn)
    if Selftest.aborted or Abort() then
        Selftest.aborted = true
        R:Skip(id, area, name, L.COMBAT_STARTED)
        return
    end
    return R:Check(id, area, name, fn)
end

function BS:RunTestRoutine(arg)
    arg = strlower(strtrim(arg or ""))
    if not (GoldSentinelDev and GoldSentinelDev:Require("BuffSentinel")) then return end
    if not GoldSentinelTest then BS.Print(L.GOLDSENTINELTEST_LUA_IS_MISSING_TEST) return end
    if not BS.ready or not BS.db then BS.Print(L.BUFFSENTINEL_IS_NOT_READY_YET) return end
    if arg == "kampf" then Selftest:StartCombatWatch() return end
    if InCombatLockdown() or UnitAffectingCombat("player") then
        BS.Print(L.THE_TEST_ROUTINE_ONLY_WORKS)
        return
    end
    local areas = {}
    if arg == "" or arg == "alles" then
        for _, a in ipairs(AREA_ORDER) do areas[a] = true end
    elseif AREAS[arg] then
        areas[AREAS[arg]] = true
    elseif #arg == 1 and arg:upper():match("^[A-J]$") then
        areas[arg:upper()] = true
    else
        BS.Print(L.UNKNOWN_AREA_POSSIBLE_LADEN_FUNKTIONEN)
        return
    end
    if BS.testMode then BS:StopTestMode(true) end
    Selftest:InstallHooks()

    local R = GoldSentinelTest.Begin("BuffSentinel", BS.version, BuffSentinelDB)   -- echte DB, nicht die Sandbox
    Selftest.aborted = false
    Selftest.realBefore = Selftest:ReadReal()
    Selftest.realActions = 0
    Selftest.running = true
    Selftest:Enter()
    local ok, err = pcall(function()
        for _, a in ipairs(AREA_ORDER) do
            if areas[a] and Run[a] then Run[a](R) end
        end
    end)
    local sandbox = Selftest:Leave()
    Selftest.running = false
    if areas.I then
        R:Check("T136", "I", L.T_REAL_ACTIONS, function()
            return Selftest.realActions == 0 and Selftest.hookCount > 0,
                string.format(L.T_REAL_ACTIONS_COUNT, Selftest.realActions, Selftest.hookCount, Selftest.hookTotal)
        end)
    end
    if not ok then
        R:Check("T00", "-", L.TEST_ROUTINE_RAN_COMPLETELY, function() error(err, 0) end)
    end
    -- Testfehler wieder entfernen (Bereich I)
    Selftest:CleanTestErrors()
    local touched = areas.C or areas.D or areas.J
    local text = R:Finish({ sandbox = sandbox, bsFehler = BS:ErrorSummary(), echteAktionen = Selftest.realActions or 0,
        geheimSimuliert = touched and L.YES or L.NO, flavorSimuliert = Selftest.simulated and L.YES or L.NO })
    text = text .. "\n" .. string.format(L.REAL_ACTIONS_LINE, Selftest.realActions or 0)
    Selftest:ShowReport(text)
    BS.Print(L.REPORT_SAVED_IT_IS_SENT)
    -- nach jedem Lauf: /reload (Testwerte können Anzeige und Spielzustand berührt haben)
    BS.Print(L.PLEASE_RELOAD_NOW_THE_TEST)
end

function Selftest:ReadReal()
    return { flavor = BS.flavor, expansion = BS.expansion, family = BS.family, restricted = BS.restricted,
             locked = BS:Locked(), combatLog = BS.hasCombatLog, isForever = BS.isForever, isRetail = BS.isRetail }
end

function Selftest:CleanTestErrors()
    local s = BuffSentinelDB and BuffSentinelDB.gsTest
    if s and type(s.errors) == "table" then
        for k, e in pairs(s.errors) do
            local wo, msg = type(e) == "table" and tostring(e.wo) or "", type(e) == "table" and tostring(e.msg) or ""
            if wo:find("TEST", 1, true) or msg:find("TEST:", 1, true) or msg:find("absichtlich", 1, true) then s.errors[k] = nil end
        end
    end
end

-- Zähler über hooksecurefunc (nur zählen, nichts ändern; zählt nur während der Testroutine)
function Selftest:InstallHooks()
    if self.hooked then return end
    self.hooked = true
    self.sendCount = 0
    local function count(prefix)
        if BS.testCommUntil and GetTime() < BS.testCommUntil and prefix == "BuffSentinel" then
            Selftest.sendCount = Selftest.sendCount + 1
        end
    end
    if C_ChatInfo and C_ChatInfo.SendAddonMessage then
        hooksecurefunc(C_ChatInfo, "SendAddonMessage", count)
    elseif SendAddonMessage then
        hooksecurefunc("SendAddonMessage", count)
    end
    -- Endzählung: echte Aktionen mit Folgen während eines Testlaufs (erwartet 0). Nur mitzählen, nie auslösen.
    self.realActions, self.hookCount, self.hookTotal = 0, 0, 0
    local function real() if Selftest.running then Selftest.realActions = Selftest.realActions + 1 end end
    local function hook(tbl, name, fn)
        self.hookTotal = self.hookTotal + 1
        local holder = tbl or _G
        if type(holder[name]) == "function" then
            if tbl then hooksecurefunc(tbl, name, fn) else hooksecurefunc(name, fn) end
            self.hookCount = self.hookCount + 1
        end
    end
    local function addonMsg(prefix) if prefix == "BuffSentinel" then real() end end
    local function channel(name) if type(name) == "string" and name:find("BuffSentinelSync", 1, true) then real() end end
    if C_ChatInfo and C_ChatInfo.SendAddonMessage then hook(C_ChatInfo, "SendAddonMessage", addonMsg) else hook(nil, "SendAddonMessage", addonMsg) end
    if C_ChatInfo and C_ChatInfo.SendChatMessage then hook(C_ChatInfo, "SendChatMessage", real) else hook(nil, "SendChatMessage", real) end
    hook(nil, "JoinTemporaryChannel", channel)
    hook(nil, "JoinChannelByName", channel)
    hook(nil, "LeaveChannelByName", channel)
end

-- Kopierfenster für den Bericht
function Selftest:ShowReport(text)
    local f = self.reportFrame
    if not f then
        f = CreateFrame("Frame", "BuffSentinelTestReport", UIParent)
        f:SetSize(640, 420)
        f:SetPoint("CENTER")
        f:SetFrameStrata("DIALOG")
        f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", f.StartMoving)
        f:SetScript("OnDragStop", f.StopMovingOrSizing)
        local bg = f:CreateTexture(nil, "BACKGROUND"); bg:SetAllPoints(); bg:SetColorTexture(0.07, 0.08, 0.10, 0.96)
        local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOPLEFT", 12, -10)
        title:SetText(L.BUFFSENTINEL_TEST_REPORT)
        local hint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        hint:SetPoint("TOPLEFT", 12, -32)
        hint:SetText(L.CTRL_A_CTRL_C_COPIES)
        local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", -2, -2)
        local scroll = CreateFrame("ScrollFrame", "BuffSentinelTestReportScroll", f, "UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT", 12, -52)
        scroll:SetPoint("BOTTOMRIGHT", -32, 12)
        local eb = CreateFrame("EditBox", nil, scroll)
        eb:SetMultiLine(true)
        eb:SetAutoFocus(false)
        eb:SetFontObject(ChatFontNormal)
        eb:SetWidth(590)
        eb:SetScript("OnEscapePressed", function() f:Hide() end)
        scroll:SetScrollChild(eb)
        f.edit = eb
        tinsert(UISpecialFrames, "BuffSentinelTestReport")
        self.reportFrame = f
    end
    f.edit:SetText(text or "")
    f:Show()
    f.edit:SetFocus()
    f.edit:HighlightText()
end

------------------------------------------------------------------------
-- A. Laden und Erkennung
------------------------------------------------------------------------
local function Weichen()
    return string.format(L.FLAVOR_EXP_FAMILY_RESTRICTED_LOCKED,
        tostring(BS.flavor), tostring(BS.expansion), tostring(BS.family), YN(BS.restricted), YN(BS:Locked()),
        YN(BS:WantsCombatLog()))
end

Run.A = function(R)
    local G = GoldSentinelGame
    C(R, "T01", "A", L.ALL_FILES_LOADED, function()
        local n = Count(BS.ClassData)
        local miss = {}
        for name, v in pairs({ CreateDisplay = BS.CreateDisplay, RefreshGroup = BS.RefreshGroup, LayoutDispel = BS.LayoutDispel,
            RecordAuras = BS.RecordAuras, AutoEntries = BS.AutoEntries, CreateOptions = BS.CreateOptions,
            SoundList = BS.SoundList, InitNames = BS.InitNames, DonateShow = BS.Donate and BS.Donate.Show,
            GoldSentinelDev = GoldSentinelDev, GoldSentinelGame = G, GoldSentinelTest = GoldSentinelTest }) do
            if not v then miss[#miss + 1] = name end
        end
        return n == 13 and #miss == 0 and BS.ready == true, n .. L.CLASSES_MISSING .. table.concat(miss, ","), L.N13_CLASSES_NOTHING_MISSING
    end)
    C(R, "T02", "A", L.VERSION_TOC_CODE, function()
        local get = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
        local v = get and get("BuffSentinel", "Version")
        return v == BS.version, tostring(v), BS.version
    end)
    C(R, "T03", "A", L.GOLDSENTINELGAME_VERSION_2, function()
        local miss = {}
        for _, f in ipairs({ "IsSecret", "AnySecret", "Safe", "Short", "CleanName", "SameName", "Status", "SetTestFlavor", "Recalc" }) do
            if type(G[f]) ~= "function" then miss[#miss + 1] = f end
        end
        return G.version == 2 and G.apiVersion == 2 and #miss == 0, L.VERSION .. tostring(G.version) .. L.T_MISSING .. table.concat(miss, ","), "2"
    end)
    local real
    C(R, "T04", "A", L.REAL_SWITCHES, function()
        real = Weichen()
        local ok = (not BS.FLAVOR_EXP[G.flavor] or BS.flavor == G.flavor)
            and BS.expansion == BS.FLAVOR_EXP[BS.flavor]
            and BS.restricted == (G.IsModern == true)
            and BS:Locked() == (BS.restricted == true and G.HasSecrets == true)
            and BS.hasCombatLog == (not BS.restricted)
            and BS.frame:IsEventRegistered("COMBAT_LOG_EVENT_UNFILTERED") == (BS.hasCombatLog == true)
        return ok, real
    end)
    local function EA(d) return BS:EntryAvailable(d) end
    C(R, "T05", "A", L.SIMULATED_FOREVER, function()
        return Sim("forever", function()
            local ok = BS.flavor == "forever" and BS.expansion == 1 and BS.family == "classic" and BS.isForever and not BS.isRetail
                and BS.restricted and BS:Locked() and not BS:WantsCombatLog()
                and EA({ forever = true }) and not EA({ noForever = true }) and EA({ min = 2, alsoForever = true })
            return ok, Weichen()
        end)
    end)
    C(R, "T06", "A", L.SIMULATED_ERA, function()
        return Sim("era", function()
            return BS.expansion == 1 and not BS.restricted and not BS:Locked() and BS:WantsCombatLog() and not EA({ min = 2 }), Weichen()
        end)
    end)
    C(R, "T07", "A", L.SIMULATED_TBC, function()
        return Sim("tbc", function()
            return BS.expansion == 2 and BS.family == "classic" and not BS.restricted and EA({ min = 2 }) and not EA({ max = 1 }), Weichen()
        end)
    end)
    C(R, "T08", "A", L.SIMULATED_RETAIL, function()
        return Sim("retail", function()
            -- v = "all": ohne v gilt ein Eintrag als "classic" und ist in Retail (family modern) nie verfügbar
            local ok = BS.expansion == 12 and BS.family == "modern" and BS.isRetail and BS.restricted
                and not EA({ kind = "proc", v = "all" }) and not EA({ kind = "buff", v = "all" })
                and EA({ kind = "buff", retail = true, v = "all" }) and not BS:AutoActive()
            return ok, Weichen()
        end)
    end)
    C(R, "T09", "A", L.BACK_TO_REAL, function()
        local now = Weichen()
        return now == real and not G.Status():find("%[" .. G.Text("test")), now, real
    end)
    C(R, "T10", "A", L.FALLBACK_WITHOUT_GOLDSENTINELGAME, function()
        local build = select(4, GetBuildInfo()) or 0
        local res = With({ testNoGame = true }, function()
            BS:DetectFlavor()
            local w = Weichen()
            local exp = (build >= 100000 and "retail") or (build >= 50000 and "mists") or (build >= 40000 and "cata")
                or (build >= 38000 and "titan") or (build >= 30000 and "wrath") or (build >= 20000 and "tbc")
                or (build >= 16000 and "forever") or "era"
            return { ok = BS.flavor == exp and BS.restricted == (BS.isRetail or BS.isForever), w = w, exp = exp }
        end)
        BS:DetectFlavor()
        return res.ok and Weichen() == real, res.w, L.FROM_INTERFACE .. build .. ": " .. res.exp
    end)
end

------------------------------------------------------------------------
-- B. Jede Funktion
------------------------------------------------------------------------
local function TestEntry(kind, extra)
    local e = { key = "test:" .. kind, kind = kind, data = { kind = kind }, mode = "always", label = "Test", known = true }
    for k, v in pairs(extra or {}) do e[k] = v end
    return e
end

Run.B = function(R)
    C(R, "T11", "B", L.API_HELPERS_WITH_REAL_VALUES, function()
        local name = BS.SpellInfo(6603)
        local s, d = BS.GetCooldown(6603)
        local u, m = BS.IsUsable(6603)
        local r = BS.InRange(6603, "player")
        local ok = type(name) == "string" and type(s) == "number" and type(d) == "number" and type(u) == "boolean"
            and type(m) == "boolean" and (r == nil or type(r) == "boolean") and type(BS.IsReady(6603)) == "boolean"
            and BS.KnowsSpellID("x") == false and type(BS.ItemCount(6948)) == "number"
            and type(BS.HasOffhandWeapon()) == "boolean"
        BS.ItemName(6948); BS.ItemIcon(6948)
        return ok, L.NAME .. type(name) .. ", InRange " .. tostring(r)
    end)
    C(R, "T12", "B", L.SMALL_HELPERS, function()
        local ok = BS.FormatTime(75) == "1m" and BS.FormatTime(2.34) == "2.3" and BS.FormatTime(12.6) == "13"
            and BS.Upper("stärke") == "STÄRKE" and BS.Contains({ 1, 2 }, 2) and BS.HasAny({ a = 1 }, { a = true })
            and next(BS.ScanAuras("party9", {})) == nil
        return ok
    end)
    C(R, "T13", "B", L.SPELLBOOK, function()
        BS:ScanSpellbook()
        local bad = 0
        for _, id in pairs(BS.classSpells) do if type(id) ~= "number" then bad = bad + 1 end end
        return BS.spellbookOK and Count(BS.known) > 0 and bad == 0 and BS:IsKnown(nil) == false,
            Count(BS.known) .. L.SPELLS .. Count(BS.classSpells) .. L.CLASS_SPELLS
    end)
    C(R, "T14", "B", L.TALENTS_SPECIALIZATION, function()
        BS:ScanTalents()
        local sum = (BS.points[1] or 0) + (BS.points[2] or 0) + (BS.points[3] or 0)
        local ok
        if BS.family == "classic" then ok = sum <= MaxPoints() and BS.mainSpec >= 0 and BS.mainSpec <= 3
        else ok = BS.mainSpec >= 0 end
        return ok and type(BS.talentSig) == "string", L.POINTS_2 .. sum .. L.TREE_2 .. tostring(BS.mainSpec) ..
            L.READABLE .. YN(BS.talentsReadable)
    end)
    if BS.isForever then
        R:Client("T14", "B", L.TALENTS_READABLE_IN_FOREVER, L.DUMP_BUFFSENTINEL_TALENTSREADABLE_BUFFSENTINEL_MAINSPEC)
    end
    C(R, "T15", "B", L.RESOLVE_ENTRIES, function()
        BS:ResolveEntries()
        local keys, bad = {}, {}
        for _, e in ipairs(BS.entries) do
            if keys[e.key] or not (e.kind == "buff" or e.kind == "proc" or e.kind == "cd") or not e.icon
               or type(e.label) ~= "string" or type(e.status) ~= "string" or type(e.statusColor) ~= "table"
               or type(e.known) ~= "boolean" then
                bad[#bad + 1] = tostring(e.key)
            end
            keys[e.key] = true
        end
        local c = BS:CountActive()
        return #bad == 0 and c.buff + c.proc + c.cd <= #BS.entries, #BS.entries .. L.ENTRIES_FAULTY .. table.concat(bad, ",")
    end)
    C(R, "T16", "B", L.SETTINGS_PER_SPEC, function()
        local e = BS.entries[1]
        if not e then return true, L.NO_ENTRIES end
        local key = e.key
        local function find() for _, x in ipairs(BS.entries) do if x.key == key then return x end end end
        BS:SetEntrySetting(key, "enabled", false)
        local a = find().enabled == false and BS:CountOverrides() == 1
        BS:SetEntrySetting(key, "mode", "combat")
        local b = find().mode == "combat"
        BS:SetEntrySetting(key, "bell", true)
        local c = find().bell == true
        BS:SetEntrySetting(key, "enabled", nil)
        local d = find().enabled == find().recommended and BS:CountOverrides() == 0
        BS:ResetEntrySettings()
        return a and b and c and d, string.format(L.OFF_MODE_BELL_RECOMMENDATION, YN(a), YN(b), YN(c), YN(d))
    end)
    C(R, "T17", "B", L.ZONES, function()
        local ok, ctx = BS:GetContext()
        if not BS.CONTEXT_NAMES[ctx] then return false, tostring(ctx) end
        if BS.db.zones[ctx] == nil then return true, ctx .. L.NO_SWITCH end
        local before = BS.db.zones[ctx]
        BS.db.zones[ctx] = not before
        local ok2 = BS:GetContext()
        BS.db.zones[ctx] = before
        return ok2 ~= ok, ctx
    end)
    C(R, "T18", "B", L.SLASH_COMMANDS, function()
        local f = SlashCmdList.BUFFSENTINEL
        local res = {}
        if not BS.optionsFrame then BS:CreateOptions() end
        local was = BS.optionsFrame:IsShown()
        Capture(function() f("") end)
        res.leer = BS.optionsFrame:IsShown() ~= was
        Capture(function() f("xyz") end)
        res.xyz = BS.optionsFrame:IsShown() == was
        local lines = Capture(function() f("fehler") end)
        res.diag = AnyLine(lines, L.RESTRICTIONS) and AnyLine(lines, L.COMBAT_LOG_2)
        Capture(function() f("errors"); f("diag") end)
        for _, c in ipairs({ "anordnen", "move", "verschieben" }) do
            Capture(function() f(c) end)
            res[c] = BS.arrangeMode == true
            Capture(function() BS:StopTestMode() end)
        end
        Capture(function() f("test") end)
        res.test = BS.testMode == true
        Capture(function() BS:StopTestMode() end)
        for _, c in ipairs({ "spenden", "donate", "support" }) do
            Capture(function() f(c) end)
            local fr = _G["BuffSentinelDonateFrame"]
            Selftest.donateFrame = fr
            res[c] = fr and fr:IsShown() or false
            if fr then fr:Hide() end
        end
        local sl = Capture(function() f("selbsttest") end)
        res.selbsttest = AnyLine(sl, "restricted:")
        local bad = {}
        for k, v in pairs(res) do if not v then bad[#bad + 1] = k end end
        return #bad == 0, L.T_FAILED .. table.concat(bad, ",")
    end)
    C(R, "T19", "B", L.LAYOUT_DISTRIBUTES_THE_ENTRIES, function()
        BS:Layout()
        local c, n, bad = BS:CountActive(), { buff = 0, proc = 0, cd = 0 }, {}
        for _, b in ipairs(PoolButtons(true)) do
            local e = b.entry
            n[b.kind] = n[b.kind] + 1
            if e.kind == "buff" and not e.data.items and b:GetAttribute("unit") ~= "player" then bad[#bad + 1] = e.key end
            if e.data.items and e.itemID and (b:GetAttribute("type") ~= "macro" or not tostring(b:GetAttribute("macrotext")):find("/use item:" .. e.itemID, 1, true)) then bad[#bad + 1] = e.key end
            if not e.data.items and not e.formMap and e.spellName and not e.data.alertOnly
               and (b:GetAttribute("type") ~= "spell" or b:GetAttribute("spell") ~= e.spellName) then bad[#bad + 1] = e.key end
        end
        return n.buff == c.buff and n.proc == c.proc and n.cd == c.cd and #bad == 0,
            string.format(L.BUTTONS_WRONG, n.proc, n.buff, n.cd, table.concat(bad, ","))
    end)
    C(R, "T20", "B", "EvalBuff", function()
        local b, e = FakeButton(), TestEntry("buff", { auraNames = { TestBuff = true } })
        local r1 = With({ playerAuras = {} }, function() return BS:EvalBuff(b, e, false, false, false) end)
        local r2 = With({ playerAuras = { TestBuff = true } }, function() return BS:EvalBuff(b, e, false, false, false) end)
        local r3 = With({ playerAuras = {} }, function() return BS:EvalBuff(b, e, false, true, false) end)
        local ec = TestEntry("buff", { auraNames = { TestBuff = true }, mode = "combat" })
        local r4 = With({ playerAuras = {} }, function() return BS:EvalBuff(b, ec, false, false, false) end)
        local g = TestEntry("buff", { key = "test:grp", data = { kind = "buff", group = true }, auraNames = { TestBuff = true } })
        local bg = FakeButton()
        local r5 = With({ groupMissing = { ["test:grp"] = { { unit = "player", name = "Test", inRange = true, groupCount = 1 } } } },
            function() return BS:EvalBuff(bg, g, false, false, false) end)
        return r1 == true and r2 == false and r3 == false and r4 == false and r5 == true and bg.target.txt == "» Test" and bg.count.txt == "",
            string.format(L.GROUP_4, tostring(r1), tostring(r2), tostring(r3), tostring(r4), tostring(bg.target.txt))
    end)
    C(R, "T21", "B", "EvalProc", function()
        local now = GetTime()
        local e = TestEntry("proc", { procAuraNames = { TestProc = true } })
        local b = FakeButton()
        local info = { TestProc = { count = 3, expires = now + 5 } }
        local r1 = With({ playerAuraInfo = info }, function() return BS:EvalProc(b, e, now, true) end)
        local t1, c1 = b.timer.txt, b.count.txt
        local e2 = TestEntry("proc", { procAuraNames = { TestProc = true }, data = { kind = "proc", minStacks = 4 } })
        local r2 = With({ playerAuraInfo = info }, function() return BS:EvalProc(FakeButton(), e2, now, true) end)
        local r3 = With({ playerAuraInfo = info }, function() return BS:EvalProc(FakeButton(), e, now, false) end)
        local et = TestEntry("proc", { data = { kind = "proc", trigger = "dodge" } })
        local r4 = With({ hasCombatLog = true, triggers = { dodge = now } }, function() return BS:EvalProc(FakeButton(), et, now, true) end)
        et.consumedAt = now + 1
        local r5 = With({ hasCombatLog = true, triggers = { dodge = now } }, function() return BS:EvalProc(FakeButton(), et, now, true) end)
        local er = TestEntry("proc", { spellName = "Testzauber", data = { kind = "proc", reactive = true } })
        local r6 = With({ IsUsable = function() return true, false end, IsReady = function() return true end },
            function() return BS:EvalProc(FakeButton(), er, now, true) end)
        local r7 = With({ IsUsable = function() return false, false end, IsReady = function() return true end },
            function() return BS:EvalProc(FakeButton(), er, now, true) end)
        return r1 and t1 == "5" and c1 == "3" and not r2 and not r3 and r4 and not r5 and r6 and not r7,
            string.format("%s(%s,%s) %s %s %s %s %s %s", tostring(r1), t1, c1, tostring(r2), tostring(r3), tostring(r4),
                tostring(r5), tostring(r6), tostring(r7))
    end)
    C(R, "T22", "B", L.EVALCOOLDOWN_AND_FLASH, function()
        local now = GetTime()
        local e, b = TestEntry("cd", { spellName = "Testzauber" }), FakeButton()
        local cd = { 0, 0 }
        BS:SetSoundSetting("cooldown", "on", true)
        local snd0 = BS.testSoundCount or 0
        local res = With({ GetCooldown = function() return cd[1], cd[2] end }, function()
            local a = BS:EvalCooldown(b, e, now, true, "dungeon")
            local f1 = b.flashUntil
            cd = { now - 1, 30 }
            BS:EvalCooldown(b, e, now, true, "dungeon")
            cd = { 0, 0 }
            BS:EvalCooldown(b, e, now, true, "dungeon")
            return { a = a, f1 = f1, f2 = b.flashUntil }
        end)
        local snd = (BS.testSoundCount or 0) - snd0
        local w = BS:EvalCooldown(FakeButton(), e, now, false, "world")
        return res.a and res.f1 == nil and res.f2 ~= nil and snd <= 1 and (not BS.db.cdWorldCombatOnly or w == false),
            L.SOUNDS_RESOLVED .. snd
    end)
    C(R, "T23", "B", L.REFRESH_AND_PREVIEW, function()
        local e0 = ErrCount()
        BS:Refresh()
        local ok1 = ErrCount() == e0
        BS.db.locked = false
        BS:Refresh()
        local bad = 0
        for _, b in ipairs(PoolButtons(true)) do
            if not b:IsShown() or math.abs(b:GetAlpha() - 0.7) > 0.05 then bad = bad + 1 end
        end
        BS.db.locked = true
        BS:Refresh()
        return ok1 and bad == 0, L.PREVIEW_WRONG .. bad
    end)
    C(R, "T24", "B", L.LABELS_FIT, function()
        local over = 0
        for _, b in ipairs(PoolButtons(true)) do
            if b.label:IsShown() then
                local text, w = b.label:GetText() or "", b.label:GetWidth()
                local _, size = b.label:GetFont()
                for word in text:gmatch("%S+") do
                    b.label:SetText(word)
                    local ww = (b.label.GetUnboundedStringWidth and b.label:GetUnboundedStringWidth()) or b.label:GetStringWidth()
                    if ww > w + 1 and (size or 11) > 8.5 then over = over + 1 end
                end
                b.label:SetText(text)
            end
        end
        return over == 0, L.WORDS_TOO_WIDE .. over
    end)
    C(R, "T25", "B", L.SIZE_SPACING_DIRECTION_POSITIONS, function()
        for _ = 1, 20 do BS:ChangeScale("proc", 0.1) end
        local hi = BS.db.groupScale.proc
        for _ = 1, 20 do BS:ChangeScale("proc", -0.1) end
        local lo = BS.db.groupScale.proc
        for _ = 1, 20 do BS:ChangeScale(nil, 0.1) end
        local ahi = BS.db.scale
        for _ = 1, 20 do BS:ChangeScale(nil, -0.1) end
        local alo = BS.db.scale
        for _ = 1, 30 do BS:ChangeGap("buff", 4) end
        local ghi = BS.db.groupLayout.buff.gap
        local v0 = BS.db.groupLayout.cd.vertical
        BS:ToggleVertical("cd"); BS:ToggleVertical("cd")
        local v1 = BS.db.groupLayout.cd.vertical
        BS:ResetButtonPosition("x:y")
        BS:ResetArrangement()
        BS:ResetWindows()
        local ok = math.abs(hi - 2) < 0.01 and math.abs(lo - 0.5) < 0.01 and math.abs(ahi - 2) < 0.01 and math.abs(alo - 0.6) < 0.01
            and ghi == BS._test.GAP_MAX and v0 == v1 and next(BS.db.pos) == nil and next(BS.db.btnPos) == nil
            and next(BS.db.winPos) == nil and BS.db.scale == 1 and BS.db.groupScale.proc == 1 and BS.db.groupLayout.buff.gap == 0
        return ok, string.format(L.GROUP_OVERALL_SPACING_MAX, lo, hi, alo, ahi, tostring(ghi))
    end)
    C(R, "T26", "B", L.ARRANGE_MODE, function()
        local lines = Capture(function() BS:StartArrangeMode() end)
        local on = BS.arrangeMode and BS.arrangeBar and BS.arrangeBar:IsShown()
        local typed = 0
        for _, b in ipairs(PoolButtons(true)) do if b:GetAttribute("type") ~= nil then typed = typed + 1 end end
        BS:UpdateArrangeBar()
        local off = Capture(function() BS:StopTestMode() end)
        return on and typed == 0 and not BS.arrangeMode and AnyLine(off, L.ARRANGING_FINISHED), L.BUTTONS_WITH_A_SPELL_WHILE .. typed
    end)
    C(R, "T27", "B", L.TEST_MODE_ALL_CLASSES_AND, function()
        local specs0 = DeepCopy(BS.db.specs)
        local e0, typed, steps = ErrCount(), 0, 0
        Capture(function()
            BS:StartTestMode()
            for _, c in ipairs(BS._test.AvailableClasses()) do
                BS:SetTestClass(c[1], 1)
                local data = BS.ClassData[c[1]]
                local names = data and ((BS.family == "modern" and data.specNamesModern) or data.specNames)
                for _ = 1, (names and #names or 3) do
                    BS:CycleTestSpec(1)
                    BS:Refresh()
                    steps = steps + 1
                    for _, b in ipairs(PoolButtons(true)) do if b:GetAttribute("type") ~= nil then typed = typed + 1 end end
                end
            end
            BS:SetTestClass(nil)
            BS:StopTestMode()
        end)
        local same = FirstDiff(specs0, BS.db.specs) == nil
        return ErrCount() == e0 and typed == 0 and same and BS.class == Selftest.state.class,
            string.format(L.STEPS_ERRORS_BUTTONS_WITH_A, steps, ErrCount() - e0, typed, YN(same))
    end)
    C(R, "T28", "B", L.BUTTON_TOOLTIPS, function()
        local bad = 0
        for _, b in ipairs(PoolButtons(true)) do
            b:GetScript("OnEnter")(b)
            local first = _G.GameTooltipTextLeft1 and _G.GameTooltipTextLeft1:GetText()
            if not GameTooltip:IsShown() or first ~= b.entry.label then bad = bad + 1 end
            b:GetScript("OnLeave")(b)
        end
        if BS.minimapButton then
            BS.minimapButton:GetScript("OnEnter")(BS.minimapButton)
            if (_G.GameTooltipTextLeft1 and _G.GameTooltipTextLeft1:GetText()) ~= "BuffSentinel" then bad = bad + 1 end
            BS.minimapButton:GetScript("OnLeave")(BS.minimapButton)
        end
        GameTooltip:Hide()
        return bad == 0, L.WRONG_TOOLTIPS .. bad
    end)
    C(R, "T29", "B", L.EVENTS, function()
        local e0 = ErrCount()
        local missing = {}
        for _, ev in ipairs({ "SPELLS_CHANGED", "LEARNED_SPELL_IN_TAB", "CHARACTER_POINTS_CHANGED", "PLAYER_TALENT_UPDATE",
            "ACTIVE_TALENT_GROUP_CHANGED", "PLAYER_SPECIALIZATION_CHANGED", "TRAIT_CONFIG_UPDATED", "GROUP_ROSTER_UPDATE",
            "BAG_UPDATE_DELAYED", "UNIT_INVENTORY_CHANGED", "UNIT_AURA", "UNIT_SPELLCAST_SUCCEEDED", "CHAT_MSG_CHANNEL_NOTICE",
            "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "CHAT_MSG_ADDON" }) do
            if not BS[ev] or not BS.frame:IsEventRegistered(ev) then missing[#missing + 1] = ev end
        end
        local h = BS.frame:GetScript("OnEvent")
        Capture(function()
            h(BS.frame, "PLAYER_SPECIALIZATION_CHANGED", "player")
            h(BS.frame, "GROUP_ROSTER_UPDATE")
            h(BS.frame, "BAG_UPDATE_DELAYED")
            h(BS.frame, "UNIT_INVENTORY_CHANGED", "player")
            h(BS.frame, "UNIT_AURA", "player")
            h(BS.frame, "UNIT_SPELLCAST_SUCCEEDED", "player", nil, 6603)
            h(BS.frame, "CHAT_MSG_CHANNEL_NOTICE", "YOU_JOINED", nil, nil, nil, nil, nil, nil, nil, L.OTHERS)
            h(BS.frame, "PLAYER_REGEN_DISABLED")
        end)
        local shown = 0
        for _, b in ipairs(PoolButtons(true)) do if b:IsShown() then shown = shown + 1 end end
        local hiddenOK = (not BS:Locked()) or shown == 0
        Capture(function() h(BS.frame, "PLAYER_REGEN_ENABLED") end)
        BS:Layout()
        return #missing == 0 and ErrCount() == e0 and hiddenOK,
            L.T_MISSING2 .. table.concat(missing, ",") .. L.VISIBLE_AFTER_COMBAT_START .. shown
    end)
end

local DISPEL_EXPECT = {   -- alte Clients (Era/TBC), ohne Skillungs-Zusätze
    PRIEST = { "Magic", "Disease" }, SHAMAN = { "Poison", "Disease" }, MAGE = { "Curse" }, DRUID = { "Curse", "Poison" },
    PALADIN = { "Magic", "Poison", "Disease" }, WARRIOR = {}, ROGUE = {}, HUNTER = {}, WARLOCK = {},
}

local function FakeAuras(byUnitFilter)
    return { GetAuraDataByIndex = function(unit, i, filter)
        local l = byUnitFilter[unit .. ":" .. (filter or "HELPFUL")]
        return l and l[i] or nil
    end }
end

local function WithTarget(auras, fn)
    return WithApi({
        UnitExists = function(u) if u == "target" then return true end return UnitExists(u) end,
        UnitCanAttack = function() return true end,
        UnitIsDead = function() return false end,
        C_UnitAuras = FakeAuras(auras),
    }, fn)
end

Run.B2 = function(R)
    C(R, "T30", "B", L.GROUP_MEMBERS_AND_GROUP_BUFFS, function()
        local units, inRaid = BS:GetGroupUnits()
        local solo = not IsInGroup or not IsInGroup()
        local e = TestEntry("buff", { key = "test:grp", data = { kind = "buff", group = true, manaOnly = true }, auraNames = { TestBuffXYZ = true } })
        local res = With({ entries = { e } }, function()
            BS:RefreshGroup()
            return BS.groupMissing["test:grp"]
        end)
        local noMana = ({ WARRIOR = true, ROGUE = true, DEATHKNIGHT = true, DEMONHUNTER = true })[BS.class] or (BS.class == "HUNTER" and BS.expansion >= 4)
        local okMiss = res and ((noMana and #res == 0) or (not noMana and res[1] ~= nil))
        return (not solo or (#units == 1 and units[1] == "player" and not inRaid)) and okMiss,
            #units .. L.UNITS_MISSING_ON .. (res and #res or 0)
    end)
    C(R, "T31", "B", L.GROUP_GRID, function()
        local lines = With({ entries = {} }, function() return Capture(function() BS:ToggleRaster() end) end)
        local none = AnyLine(lines, L.NO_GROUP_BUFFS) and not (BS.raster and BS.raster:IsShown())
        local e = TestEntry("buff", { key = "test:grp", spellName = BS.SpellInfo(6603), icon = 134400,
            data = { kind = "buff", group = true }, auraNames = { TestBuffXYZ = true } })
        local cells, bad = With({ entries = { e } }, function()
            BS:ToggleRaster()
            BS:UpdateRaster(true)
            local n, b = 0, 0
            for _, c in ipairs(BS.raster.cells) do
                if c:IsShown() then
                    n = n + 1
                    if c:GetAttribute("type") ~= "spell" or not c:GetAttribute("unit") then b = b + 1 end
                end
            end
            BS:ToggleRaster()
            return n, b
        end)
        local units = BS:GetGroupUnits()
        return none and cells == #units and bad == 0 and not BS.raster:IsShown(), cells .. L.CELLS
    end)
    C(R, "T32", "B", L.DISPEL_SPELLS_PER_CLASS, function()
        local r = BS:ResolveDispelSpells()
        BS:LayoutDispel()
        local types = {}
        for t in pairs(r.types) do types[#types + 1] = t end
        table.sort(types)
        local got = table.concat(types, ",")
        if BS:Locked() then return #r.spells == 0 and not BS.dispelActive, got end
        local exp = DISPEL_EXPECT[BS.class]
        if BS.expansion <= 2 and exp then
            -- nicht gelernte Zauber fehlen zu Recht (niedrige Stufe): nur Arten melden, die über die Erwartung hinausgehen
            for t in pairs(r.types) do
                local found = false
                for _, x in ipairs(exp) do if x == t then found = true end end
                if not found then return false, got, table.concat(exp, ",") end
            end
        end
        return #BS:DispelSummary() == #r.spells, got
    end)
    if BS:Locked() or BS.isRetail then
        R:Skip("T33", "B", L.DISPEL_DEBUFFS_TEST_DATA, L.DISPEL_GRID_OFF_IN_FOREVER)
    else
        C(R, "T33", "B", L.DISPEL_DEBUFFS_TEST_DATA, function()
            BS:LayoutDispel()
            local r = BS.dispelSpells
            if not BS.dispelActive or not BS.dispelCells or not BS.dispelCells[1] then return true, L.CLASS_LEVEL_CANNOT_DISPEL end
            local t = r.types.Curse and "Curse" or r.types.Magic and "Magic" or r.types.Poison and "Poison" or "Disease"
            local imp = ({ Curse = 19703, Magic = 19659, Poison = 26053, Disease = 23153 })[t]
            local list = {
                { name = "Vampirberührung", icon = 135978, dispelName = "Magic", spellId = 34914 },
                { name = "Testdebuff", icon = 136139, dispelName = t, spellId = imp },
            }
            local c = BS.dispelCells[1]
            local res = WithApi({ C_UnitAuras = FakeAuras({ ["player:HARMFUL"] = list }) }, function()
                for i, cell in ipairs(BS.dispelCells) do if i > 1 then cell.unit = nil end end
                c.unit = "player"
                BS:RefreshDispel(GetTime() + 1000, true, false, false, false)
                return { name = c.debuffName, glow = c.glow:IsShown() }
            end)
            return res.name == "Testdebuff", L.T_SHOWN .. tostring(res.name) .. L.LIGHTS_UP .. YN(res.glow)
        end)
    end
    C(R, "T34", "B", L.PURGE_ENEMIES, function()
        local auras = { ["target:HELPFUL"] = {
            { name = "Magieschild", dispelName = "Magic", spellId = 1 },
            { name = "Stehlbar", isStealable = true, spellId = 2 },
            { name = "Wut", spellId = 19451 },
            { name = "Raserei", spellId = 3 },
        } }
        local m, nm = WithTarget(auras, function() return BS:FindEnemyDispel({ Magic = true }) end)
        local s, ns = WithTarget(auras, function() return BS:FindEnemyDispel({ stealable = true }) end)
        local w, nw = WithTarget(auras, function() return BS:FindEnemyDispel({ Enrage = true }) end)
        local none = WithApi({ UnitExists = function() return false end }, function() return BS:FindEnemyDispel({ Magic = true }) end)
        return m == "Magieschild" and nm == 1 and s == "Stehlbar" and w == "Wut" and nw == 2 and none == nil
            and BS._test.IsEnrage("Raserei", nil, nil), string.format(L.MAGIC_STEALABLE_ENRAGE, tostring(m), tostring(s), tostring(w), tostring(nw))
    end)
    C(R, "T35", "B", L.RECORDER, function()
        Capture(function()
            BS:SetRecorder(true)
            BS.playerAuraInfo = { TestAura = { id = 12345, icon = 134400 } }
            BS:RecordAuras()
        end)
        local r = BS.gdb.recorder
        local ok1 = r.seen.TestAura and r.seen.TestAura.count == 1
        Capture(function()
            local many = {}
            for i = 1, 101 do many["Aura" .. i] = { id = i } end
            BS.playerAuraInfo = many
            BS:RecordAuras()
        end)
        local ok2 = #r.list <= 100
        BS.playerAuraInfo = { TestAura = { id = 12345 } }
        r.seen.TestAura = r.seen.TestAura or { name = "TestAura", id = 12345, count = 1 }
        Capture(function()
            BS:AddCustomFromRecord("TestAura")
            local idx = #BS.db.custom
            BS:SetCustomSpell(idx, "  Testzauber  ")
        end)
        local idx = #BS.db.custom
        local ok3 = BS.db.custom[idx] and BS.db.custom[idx].spell == "Testzauber"
        BS:ResolveEntries()
        local found = false
        for _, e in ipairs(BS.entries) do if e.key == "custom:TestAura" and e.kind == "proc" then found = true end end
        Capture(function() BS:RemoveCustom(idx); BS:ClearRecorder(); BS:SetRecorder(false) end)
        BS:ResolveEntries()
        local gone = true
        for _, e in ipairs(BS.entries) do if e.key == "custom:TestAura" then gone = false end end
        BS.playerAuraInfo = {}
        return ok1 and ok2 and ok3 and found and gone and #r.list == 0,
            string.format(L.RECORDED_MAX100_OWN_REMOVED, YN(ok1), YN(ok2), YN(ok3), YN(found), YN(gone))
    end)
    if BS.isRetail then
        R:Skip("T36", "B", L.LEARN_PROC_AUTOMATICALLY, L.RETAIL_AUTOMATIC_LEARNING_OFF)
        R:Skip("T37", "B", L.LEARN_ABILITY_AUTOMATICALLY, L.RETAIL_AUTOMATIC_LEARNING_OFF)
    else
        C(R, "T36", "B", L.LEARN_PROC_AUTOMATICALLY, function()
            local name, id = next(BS.classSpells or {})
            if not name then return true, L.NO_CLASS_SPELLS_IN_THE end
            BS.gdb.auto.enabled = true
            BS.testSink = {}
            -- frühere Testzauber (gleicher Zeitpunkt im selben Bild) nicht mitzählen
            BS:AutoTestState({ active = {}, prevInfo = {}, recentCasts = {}, pendingRemove = {} })
            local res = With({ InCombat = function() return true end, IsClassSpell = function() return true end }, function()
                Capture(function()
                    for _ = 1, 3 do
                        local now = GetTime()
                        BS.playerAuraInfo = { TestProc = { duration = 10, expires = now + 10, count = 0, source = "player" } }
                        BS:AutoScanAuras()
                        BS:AutoOnCast(id)
                        BS.playerAuraInfo = {}
                        BS:AutoScanAuras()
                    end
                end)
                local _, c = BS:AutoDB()
                return c.procs.TestProc
            end)
            local hasP = false
            for _, m in ipairs(BS.testSink) do if m.msg:find(";P;", 1, true) then hasP = true end end
            local entry = false
            for _, d in ipairs(BS:AutoEntries()) do if d.key == "auto:p:TestProc" then entry = true end end
            return res and res.src == "self" and res.spell == name and entry and not hasP,
                L.LEARNED_ .. YN(res) .. L.ENTRY .. YN(entry) .. L.SHARED .. YN(hasP)
        end)
        C(R, "T37", "B", L.LEARN_ABILITY_AUTOMATICALLY, function()
            Capture(function() BS:AutoAddCooldown("Testfähigkeit", 6603, 30, "self") end)
            local _, c = BS:AutoDB()
            local ok1 = c.cds["Testfähigkeit"] ~= nil
            local ok2 = BS.AutoCdText(30) == "30 s" and BS.AutoCdText(120) == string.format(L.MIN, 2)
            c.procs.TestSort = c.procs.TestSort or { aura = "TestSort" }
            local list = BS:AutoList()
            local sorted = true
            local seenCd = false
            for _, it in ipairs(list) do
                if it.kind == "cd" then seenCd = true elseif seenCd then sorted = false end
            end
            Capture(function() BS:AutoRemove("cd", "Testfähigkeit") end)
            local ok3 = c.cds["Testfähigkeit"] == nil and c.ignore["Testfähigkeit"] == true
            Capture(function() BS:AutoResetIgnore() end)
            local ok4 = next(c.ignore) == nil
            c.procs.TestSort = nil
            BS.db.autoBaseDone, BS.db.autoBase = nil, {}
            local n0 = Count(c.cds)
            Capture(function() BS:AutoSpellbookCheck() end)
            local ok5 = (not BS.spellbookOK) or (BS.db.autoBaseDone == true and Count(c.cds) == n0)
            return ok1 and ok2 and sorted and ok3 and ok4 and ok5,
                string.format("%s %s %s %s %s %s", YN(ok1), YN(ok2), YN(sorted), YN(ok3), YN(ok4), YN(ok5))
        end)
    end
    C(R, "T38", "B", L.AUTOLEARN_ON_OFF_AND_SHARED, function()
        Capture(function() BS:SetAutoLearn(false) end)
        local off = BS:AutoActive() == false
        Capture(function() BS:SetAutoLearn(true) end)
        local cls = (BS.class ~= "MAGE") and "MAGE" or "PRIEST"
        BS.gdb.auto.share = true
        Capture(function()
            BS:OnAutoShare(cls, "C", "6603", "0", "1", "Testsender")
            BS:OnAutoShare(cls, "C", "x", "0", "1", "Testsender")
            BS:OnAutoShare(cls, "P", "x", "y", "z", "Testsender")
        end)
        local _, c = BS:AutoDB(cls)
        local name = BS.SpellInfo(6603)
        local got = name and c.cds[name]
        local specs = BS:AutoTestState().parseSpecs("1,5,x")
        local ok = off and ((BS.isRetail and not got) or (not BS.isRetail and (got == nil or got.src == "net")))
            and #specs == 1 and specs[1] == 1
        if got then c.cds[name] = nil end
        return ok, L.SHARED_TAKEN_OVER .. YN(got)
    end)
    C(R, "T39", "B", L.NAME_INDEX_AND_TRANSLATION, function()
        BS:BuildNameIndex()
        for n in pairs(BS.nameIndex.spells) do
            local r = BS:LocalSpellName(n)
            if r ~= nil and type(r) ~= "string" then return false, "LocalSpellName " .. n end
        end
        for _, item in ipairs(BS.nameIndex.lists[BS.class] or {}) do BS:ResolveTalentList(item.names) end
        local t0 = BS:CountLearned()
        local item = (BS.nameIndex.lists[BS.class] or {})[1]
        local pos = next(BS.talentByPos or {})
        if item and pos then
            local en = item.names[1]
            Capture(function() BS:AssignTalent(en, pos) end)
            local m = BS.gdb.learned.talents[BS.class] and BS.gdb.learned.talents[BS.class][en]
            local ok = m and m.src == "manual"
            Capture(function() BS:UnassignTalent(en) end)
            local gone = not (BS.gdb.learned.talents[BS.class] and BS.gdb.learned.talents[BS.class][en])
            return ok and gone and BS.assigning == nil, L.T_ASSIGNED .. YN(ok) .. L.REMOVED .. YN(gone)
        end
        return BS:CountLearned() == t0, L.NO_TALENT_LIST_POSITION_TO
    end)
    C(R, "T40", "B", L.SENDING_ONLY_INTO_THE_SINK, function()
        local sent0 = Selftest.sendCount or 0
        BS.gdb.shareNames, BS.gdb.shareServer = true, true
        BS.testSink = {}
        BS:SendName("X", "both")
        local on = #BS.testSink
        BS.testSink = {}
        BS.gdb.shareNames, BS.gdb.shareServer = false, false
        BS:SendName("X", "both")
        local off = #BS.testSink
        BS.gdb.shareNames, BS.gdb.shareServer = true, true
        BS.testSink = {}
        BS:SendName(string.rep("y", 260), "group")
        BS:SendName("Z", "group"); BS:SendName("Z", "group")
        local filt = #BS.testSink
        BS:PumpComm()
        local qg = BS:CommQueueSizes()
        return on == 2 and off == 0 and filt == 1 and qg == 0 and (Selftest.sendCount or 0) == sent0,
            string.format(L.ON_OFF_FILTERED_REAL_SENDS, on, off, filt, (Selftest.sendCount or 0) - sent0)
    end)
    C(R, "T41", "B", L.RECEIVING, function()
        local LN = BS.gdb.learned
        local cls = BS.class
        local talent = next((BS.nameIndex.talents or {})[cls] or {})
        local spell = next(BS.nameIndex.spells or {})
        local h = function(...) BS:CHAT_MSG_ADDON(...) end
        Capture(function()
            if talent then h("BuffSentinel", "T;" .. cls .. ";1:2:3;" .. talent, "GUILD", "Testsender-Testrealm") end
            if spell then h("BuffSentinel", "S;6603;" .. spell, "GUILD", "Testsender-Testrealm") end
            if spell then h("BuffSentinel", "Q;S;" .. spell, "GUILD", "Testsender") end
            h("BuffSentinel", "R", "GUILD", "Testsender")
            h("BuffSentinel", "A;WARRIOR;C;6603;0;1", "GUILD", "Testsender")
        end)
        local snap = DeepCopy(LN)
        Capture(function()
            h("BuffSentinel", "S;6603;Testname", "GUILD", UnitName("player"))
            h("AnderesAddon", "S;6603;" .. tostring(spell), "GUILD", "Testsender")
            BS.gdb.shareNames = false
            h("BuffSentinel", "T;" .. cls .. ";9:9:9;" .. tostring(talent), "GUILD", "Testsender2")
            BS.gdb.shareNames = true
            BS.gdb.shareServer = false
            h("BuffSentinel", "T;" .. cls .. ";8:8:8;" .. tostring(talent), "CHANNEL", "Testsender3")
            BS.gdb.shareServer = true
        end)
        return FirstDiff(snap, LN) == nil and (Selftest.sendCount or 0) == 0, L.INDEX_TALENT .. YN(talent) .. L.SPELL .. YN(spell)
    end)
    C(R, "T42", "B", L.BROKEN_MESSAGES, function()
        local snap = DeepCopy(BS.gdb.learned)
        local e0 = ErrCount()
        Capture(function()
            for _, m in ipairs({ "", ";;;;", "T;;;", "T;WARRIOR;abc;X", "S;abc;X", "A;WARRIOR;P;x;y;z", "Q", string.rep("x", 300), "R;R;R" }) do
                BS:CHAT_MSG_ADDON("BuffSentinel", m, "GUILD", "Testsender")
            end
        end)
        return FirstDiff(snap, BS.gdb.learned) == nil and ErrCount() == e0
    end)
    C(R, "T43", "B", L.SERVER_CHANNEL_WITHOUT_JOINING, function()
        local joins, leaves = 0, 0
        local texts = {}
        With({ JoinSync = function() joins = joins + 1 end, LeaveSync = function() leaves = leaves + 1 end }, function()
            BS:SetShareServer(false)
            BS:SetShareServer(true)
        end)
        BS.gdb.shareServer = false
        texts[BS:SyncStatusText()] = true
        BS.gdb.shareServer = true
        for _, st in ipairs({ "waiting", "connecting", "failed" }) do
            BS.syncReady, BS.syncState = false, st
            texts[BS:SyncStatusText()] = true
        end
        BS.syncReady = true
        texts[BS:SyncStatusText()] = true
        BS:CHAT_MSG_CHANNEL_NOTICE("YOU_LEFT", nil, nil, nil, nil, nil, nil, nil, "BuffSentinelSync")
        return joins == 1 and leaves == 1 and Count(texts) == 5 and BS.syncReady == false,
            string.format(L.JOIN_LEAVE_TEXTS, joins, leaves, Count(texts))
    end)
    C(R, "T44", "B", L.SOUND_LIST_AND_SETTINGS, function()
        local list = BS:SoundList()
        local bad = 0
        for _, k in ipairs(BS.SOUND_KINDS) do
            local on, snd = BS:SoundSetting(k.key)
            if type(on) ~= "boolean" or type(snd) ~= "string" then bad = bad + 1 end
        end
        BS:SetSoundSetting("proc", "on", true)
        local ch = (BS:SoundSetting("proc")) == true
        BS:SetSoundSetting("proc", "sound", "custom", "123")
        local nm = BS:SoundName("custom", "123") == L.CUSTOM_2 .. "123"
        Capture(function() BS:SoundApplyToAll() end)
        BS:SoundResetSpec()
        BS:SoundResetAll()
        local def = true
        for _, k in ipairs(BS.SOUND_KINDS) do
            local on, snd = BS:SoundSetting(k.key)
            if on ~= k.on or snd ~= k.sound then def = false end
        end
        local before = DeepCopy(BS.db.soundBase)
        BS:MigrateSounds(); BS:MigrateSounds()
        return #list > 0 and bad == 0 and ch and nm and def and FirstDiff(before, BS.db.soundBase) == nil,
            #list .. L.SOUNDS
    end)
    C(R, "T45", "B", L.RESOLVE_SOUNDS_MUTED, function()
        local bad = {}
        for _, k in ipairs(BS.SOUND_KINDS) do
            if k.sound:sub(1, 2) ~= "f:" and not BS:PlaySoundChoice(k.sound) then
                -- Spielton fehlt in diesem Client (wird ausgeblendet) – nur melden, wenn SOUNDKIT ihn kennt
                if type(SOUNDKIT) == "table" and SOUNDKIT[k.sound] then bad[#bad + 1] = k.key end
            end
        end
        local bell = BS:PlaySoundChoice("f:shaysbell")
        local custom = BS:PlaySoundChoice("custom", "123")
        local unknown = BS:PlaySoundChoice("gibtsnicht")
        return #bad == 0 and bell and custom and unknown == false, L.T_MISSING3 .. table.concat(bad, ",")
    end)
    R:Client("T46", "B", L.HEAR_THE_SOUNDS, L.OPTIONS_ALERT_SOUNDS_LISTEN_ON)
    C(R, "T47", "B", L.ALL_PAGES, function()
        local e0 = ErrCount()
        local bad = {}
        for _, key in ipairs({ "skill", "proc", "buff", "cd", "dispel", "opt", "rec" }) do
            OpenPage(key)
            if PageTexts(key):find(L.ERROR_3, 1, true) then bad[#bad + 1] = key end
        end
        BS:ShowPage("zones")
        local zones = BS.currentPage == "opt"
        local esc = false
        for _, n in ipairs(UISpecialFrames) do if n == "BuffSentinelOptions" then esc = true end end
        BS.optionsFrame:Hide()
        return #bad == 0 and ErrCount() == e0 and zones and esc, L.PAGES_WITH_ERRORS .. table.concat(bad, ",")
    end)
    C(R, "T48", "B", L.EACH_OPTION_ON_OFF_ONCE, function()
        local bad, n = {}, 0
        Capture(function()
            for _, key in ipairs({ "opt", "dispel", "rec" }) do
                OpenPage(key)
                local page = BS.optionsFrame.pages[key]
                local list = {}
                for _, t in ipairs(page.toggles or {}) do list[#list + 1] = t end
                for _, t in ipairs(list) do
                    local v0 = t.row.get()
                    t.row:Click()
                    local v1 = t.row.get()
                    t.row:Click()
                    local v2 = t.row.get()
                    n = n + 1
                    if v1 == v0 or v2 ~= v0 then bad[#bad + 1] = key .. ":" .. tostring(t.label) end
                end
            end
        end)
        BS.optionsFrame:Hide()
        return #bad == 0, n .. L.SWITCHES_WRONG .. table.concat(bad, ",")
    end)
    C(R, "T49", "B", L.BUTTONS_ON_THE_OPTIONS_PAGE, function()
        local seq = {}
        BS.db.hornEvery = 3
        local steps = { 3, 5, 8, 10, 15, 20, 30, 60 }
        for _ = 1, 8 do
            local nextV = steps[2]
            for i, v in ipairs(steps) do if v == BS.db.hornEvery then nextV = steps[i % #steps + 1] end end
            BS.db.hornEvery = nextV
            seq[#seq + 1] = nextV
        end
        return BS.db.hornEvery == 3 and #seq == 8, table.concat(seq, ",")
    end)
    C(R, "T50", "B", L.SPEC_PAGE, function()
        local e0 = ErrCount()
        Capture(function() BS:FullScan(); BS:ResetEntrySettings() end)
        BS.assigning = "Test"; BS.assigning = nil
        OpenPage("skill")
        BS.optionsFrame:Hide()
        return ErrCount() == e0
    end)
    C(R, "T51", "B", L.MINIMAP_BUTTON, function()
        local b = BS.minimapButton
        if not b then return false, L.NO_MINIMAP_BUTTON end
        local click = b:GetScript("OnClick")
        Capture(function() click(b, "LeftButton") end)
        local opened = BS.optionsFrame and BS.optionsFrame:IsShown()
        Capture(function() click(b, "LeftButton") end)
        BS.db.minimap.hide = true; BS:UpdateMinimapButton()
        local hidden = not b:IsShown()
        BS.db.minimap.hide = false; BS:UpdateMinimapButton()
        local shown = b:IsShown()
        local pts = {}
        for _, a in ipairs({ 0, 90, 180 }) do
            BS.db.minimap.angle = a; BS:UpdateMinimapButton()
            local _, _, _, x, y = b:GetPoint()
            pts[#pts + 1] = string.format("%.0f/%.0f", x or 0, y or 0)
        end
        return opened and hidden and shown and pts[1] ~= pts[2] and pts[2] ~= pts[3], table.concat(pts, " ")
    end)
    C(R, "T52", "B", L.DONATE_WINDOW, function()
        local D = BS.Donate
        local fr = _G["BuffSentinelDonateFrame"]
        local before = fr and fr:IsShown() or false
        fr = D.Show()
        Selftest.donateFrame = fr
        local link = fr.edit:GetText() == D.URL
        D.Toggle()
        local closed = not fr:IsShown()
        local btn = D.CreateButton(UIParent)
        btn:Hide()
        return not before and link and closed and btn ~= nil
    end)
    C(R, "T53", "B", L.WINDOW_POSITIONS, function()
        local done, bad = {}, {}
        for _, key in ipairs({ "options", "raster", "testbar", "arrangebar" }) do
            local w = BS.windows[key]
            if w then
                w.frame:GetScript("OnDragStop")(w.frame)
                local p = BS.db.winPos[key]
                if not (p and #p == 4) then bad[#bad + 1] = key end
                BS:PlaceWindow(key)
                done[#done + 1] = key
            end
        end
        return #bad == 0, L.CHECKED .. table.concat(done, ",") .. L.WRONG .. table.concat(bad, ",")
    end)
    C(R, "T54", "B", L.DATA_FORMAT_OF_ALL_CLASSES, function()
        local bad = {}
        local KIND = { buff = true, proc = true, cd = true }
        local V = { classic = true, modern = true, all = true }
        local TRIG = { dodge = true, avoid = true, parry = true }
        for class, data in pairs(BS.ClassData) do
            local keys = {}
            for _, d in ipairs(data.entries or {}) do
                local id = class .. ":" .. tostring(d.key)
                if type(d.key) ~= "string" or keys[d.key] then bad[#bad + 1] = id .. " key" end
                keys[d.key or "?"] = true
                if not KIND[d.kind] then bad[#bad + 1] = id .. " kind" end
                if d.v and not V[d.v] then bad[#bad + 1] = id .. " v" end
                for _, s in ipairs(d.specs or {}) do if type(s) ~= "number" or s < 1 or s > 4 then bad[#bad + 1] = id .. " specs" end end
                for _, t in ipairs(d.talents or {}) do if type(t) ~= "string" then bad[#bad + 1] = id .. " talents" end end
                if d.trigger and not TRIG[d.trigger] then bad[#bad + 1] = id .. " trigger" end
                if d.weapon and d.weapon ~= "main" and d.weapon ~= "off" then bad[#bad + 1] = id .. " weapon" end
                for _, it in ipairs(d.items or {}) do if type(it) ~= "number" then bad[#bad + 1] = id .. " items" end end
                for _, f in ipairs({ "minStacks", "targetBelow", "window" }) do
                    if d[f] ~= nil and type(d[f]) ~= "number" then bad[#bad + 1] = id .. " " .. f end
                end
            end
        end
        return #bad == 0, #bad .. L.VIOLATIONS .. table.concat(bad, ", ", 1, math.min(#bad, 10))
    end)
    local function Unresolved()
        local miss = {}
        for _, d in ipairs((BS.ClassData[BS.class] or {}).entries or {}) do
            if BS:EntryAvailable(d) then
                local list = type(d.spell) == "table" and d.spell or { d.spell }
                for _, id in ipairs(list) do
                    if type(id) == "number" and not BS.SpellInfo(id) then miss[#miss + 1] = d.key .. ":" .. id end
                end
            end
        end
        return miss
    end
    if BS.isForever then
        local miss = Unresolved()
        R:Client("T55", "B", L.SPELL_IDS_IN_THE_RUNNING, L.CONFIRM_IN_FOREVER_NOT_RESOLVED ..
            (#miss > 0 and table.concat(miss, ", ") or L.NONE))
    else
        C(R, "T55", "B", L.SPELL_IDS_IN_THE_RUNNING, function()
            local miss = Unresolved()
            return #miss == 0, L.NOT_RESOLVED .. table.concat(miss, ", ")
        end)
    end
end

------------------------------------------------------------------------
-- C. Forever-Sonderfälle (simuliert: Köderwerte über BS.testSecrets, Funktionen über BS.apiOverride)
------------------------------------------------------------------------
local function SpellOverlay(fields) return Overlay(C_Spell, fields) end

Run.C = function(R)
    local S = NewSecret()
    local function NoLeak() local l = Leaked(S); if l then error(L.TEST_VALUE_SAVED_IN .. l, 0) end end

    local auraList = {
        { name = S, icon = 1 },
        { name = "TestAura2", icon = 2, applications = S, expirationTime = S, spellId = S, duration = S, sourceUnit = S },
    }
    C(R, "T56", "C", L.OWN_AURAS_PROTECTED, function()
        BS.secretNoted = false
        local lines = Capture(function()
            WithApi({ C_UnitAuras = FakeAuras({ ["player:HELPFUL"] = auraList }) }, function() BS:ScanPlayerAuras() end)
        end)
        local a = BS.playerAuraInfo.TestAura2
        NoLeak()
        return a and a.count == nil and a.expires == nil and a.id == nil and Count(BS.playerAuraInfo) == 1 and #lines == 1,
            L.NOTES .. #lines
    end)
    C(R, "T57", "C", L.PROCS_WITH_PROTECTED_VALUES, function()
        local b = FakeButton()
        local e = TestEntry("proc", { procAuraNames = { TestAura2 = true } })
        BS:EvalProc(b, e, GetTime(), true)
        With({ InCombat = function() return true end }, function() BS:AutoScanAuras() end)
        NoLeak()
        return b.timer.txt == "", L.TIMER .. tostring(b.timer.txt) .. "'"
    end)
    C(R, "T58", "C", L.COOLDOWN_PROTECTED, function()
        local res = {}
        for _, cd in ipairs({ { startTime = S, duration = 10 }, { startTime = 0, duration = S } }) do
            WithApi({ C_Spell = SpellOverlay({ GetSpellCooldown = function() return cd end }) }, function()
                local s, d, sec = BS.GetCooldown("x")
                local b = FakeButton()
                local snd0 = BS.testSoundCount or 0
                local ev = BS:EvalCooldown(b, TestEntry("cd", { spellName = "x" }), GetTime(), true, "dungeon")
                res[#res + 1] = s == 0 and d == 0 and sec == true and BS.IsReady("x") == false and ev == false
                    and b.flashUntil == nil and (BS.testSoundCount or 0) == snd0
            end)
        end
        return res[1] and res[2]
    end)
    C(R, "T59", "C", L.USABLE_RANGE_PROTECTED, function()
        return WithApi({ C_Spell = SpellOverlay({ IsSpellUsable = function() return S, S end, IsSpellInRange = function() return S end }) }, function()
            local u, m = BS.IsUsable("x")
            return u == false and m == false and BS.InRange("x", "player") == nil
        end)
    end)
    local function HpCase(hp, max)
        return WithApi({ UnitExists = function() return true end, UnitCanAttack = function() return true end,
            UnitIsDead = function() return false end, UnitHealth = function() return hp end, UnitHealthMax = function() return max end },
            function() return BS:EvalProc(FakeButton(), TestEntry("proc", { data = { kind = "proc", targetBelow = 20 } }), GetTime(), true) end)
    end
    C(R, "T60", "C", L.TARGET_HEALTH_PROTECTED, function()
        local low = HpCase(10, 100)
        return HpCase(S, 100) == false and low == true, L.CROSS_CHECK_10 .. tostring(low)
    end)
    local function GroupCase()
        local e = TestEntry("buff", { key = "test:grp", data = { kind = "buff", group = true }, auraNames = { TestBuffXYZ = true } })
        return With({ entries = { e } }, function()
            return WithApi({ UnitName = function() return S end, UnitClass = function() return "x", S end }, function()
                BS:RefreshGroup()
                local info = BS.unitInfo.player
                local m = BS.groupMissing["test:grp"]
                local b = FakeButton()
                local target = With({ groupMissing = { ["test:grp"] = { { unit = "player", name = S, inRange = true } } } },
                    function() BS:EvalBuff(b, e, false, false, false); return b.target.txt end)
                return info, m, target
            end)
        end)
    end
    C(R, "T61", "C", L.GROUP_NAMES_AND_CLASSES_PROTECTED, function()
        local info, m, target = GroupCase()
        NoLeak()
        return info and info.name == "?" and info.class == nil and target == "» ?", L.TARGET_TEXT .. tostring(target)
    end)
    local secretAuras = { ["player:HARMFUL"] = { { name = "Testdebuff", dispelName = S, spellId = S } },
                          ["target:HELPFUL"] = { { name = "Testbuff", dispelName = S, spellId = S, isStealable = S } } }
    local typeHits = 0
    C(R, "T62", "C", L.DEBUFF_TYPES_PROTECTED, function()
        local got = {}
        WithApi({ C_UnitAuras = FakeAuras(secretAuras) }, function()
            BS._test.ForEachAura("player", "HARMFUL", function(_, _, dt, id, st) got[#got + 1] = (dt == nil and id == nil and st == nil) end)
        end)
        WithTarget(secretAuras, function() BS:FindEnemyDispel({ Magic = true, stealable = true, Enrage = true }) end)
        local types = setmetatable({}, { __index = function(_, k) if rawequal(k, S) then typeHits = typeHits + 1 end end })
        local cell = BS:GetDispelCell(1)
        With({ dispelActive = true, dispelSpells = { types = types, spells = { "x" }, slotOf = { x = 1 } } }, function()
            local u = cell.unit
            cell.unit = "player"
            WithApi({ C_UnitAuras = FakeAuras(secretAuras) }, function() BS:RefreshDispel(GetTime() + 2000, true, false, false, false) end)
            cell.unit = u
        end)
        return got[1] == true and typeHits == 0
    end)
    C(R, "T63", "C", L.SPELL_EVENT_PROTECTED, function()
        local n0 = #BS:AutoTestState().casts
        BS:UNIT_SPELLCAST_SUCCEEDED("player", nil, S)
        BS:AutoOnCast(S)
        local _, c = BS:AutoDB()
        local cds0 = Count(c.cds)
        WithApi({ GetSpellBaseCooldown = function() return S end }, function() BS:AutoCheckCooldown(6603, BS.SpellInfo(6603) or "x") end)
        return #BS:AutoTestState().casts == n0 and Count(c.cds) == cds0
    end)
    C(R, "T64", "C", L.ADDON_MESSAGE_WITH_PROTECTED_ARGUMENTS, function()
        local snap = DeepCopy(BS.gdb.learned)
        BS:CHAT_MSG_ADDON("BuffSentinel", S, "PARTY", "Testsender")
        BS:CHAT_MSG_ADDON("BuffSentinel", "R", "PARTY", S)
        BS:CHAT_MSG_CHANNEL_NOTICE("YOU_JOINED", nil, nil, nil, nil, nil, nil, nil, S)
        return FirstDiff(snap, BS.gdb.learned) == nil
    end)
    C(R, "T65", "C", L.TOOLTIPS_WITH_A_PROTECTED_NAME, function()
        local done = {}
        WithApi({ UnitName = function() return S end }, function()
            local b = PoolButtons(true)[1]
            if b then
                local u = b:GetAttribute("unit")
                b:SetAttribute("unit", "party1")
                b:GetScript("OnEnter")(b); b:GetScript("OnLeave")(b)
                b:SetAttribute("unit", u)
                done[#done + 1] = "Button"
            end
            local cell = BS:GetDispelCell(1)
            local u = cell.unit
            cell.unit = "player"
            cell:GetScript("OnEnter")(cell); cell:GetScript("OnLeave")(cell)
            cell.unit = u
            done[#done + 1] = L.DISPEL
            if BS.raster and BS.raster.cells[1] then
                local c = BS.raster.cells[1]
                local cu = c.unit
                c.unit = "player"
                c:GetScript("OnEnter")(c); c:GetScript("OnLeave")(c)
                c.unit = cu
                done[#done + 1] = L.GRID
            end
        end)
        GameTooltip:Hide()
        return true, L.CHECKED .. table.concat(done, ",")
    end)
    C(R, "T66", "C", L.GOLDSENTINELGAME_NAMES_PROTECTED, function()
        local G = GoldSentinelGame
        return G.Short(S) == nil and G.CleanName(S) == nil and G.SameName(S, "a") == false,
            L.SHORT_CLEANNAME_SAMENAME_CHECKED_SAFE
    end)

    -- (2) fehlende alte Funktionen
    local N = BS.NIL
    local function names(t) local o = {}; for k in pairs(t) do o[#o + 1] = tostring(k) end; table.sort(o); return table.concat(o, ",") end
    C(R, "T67", "C", L.AURAS_WITHOUT_UNITBUFF_UNITDEBUFF, function()
        local ref = names(BS.ScanAuras("player", {}))
        local a = WithApi({ UnitBuff = N, UnitDebuff = N }, function() return names(BS.ScanAuras("player", {})) end)
        local hasNew = C_UnitAuras and C_UnitAuras.GetAuraDataByIndex
        local b = WithApi({ UnitBuff = N, UnitDebuff = N, C_UnitAuras = N }, function()
            BS:ScanPlayerAuras()
            local n = 0
            BS._test.ForEachAura("player", "HARMFUL", function() n = n + 1 end)
            return names(BS.ScanAuras("player", {})) .. "|" .. n
        end)
        BS:ScanPlayerAuras()
        return (not hasNew or a == ref) and b == "|0"
    end)
    C(R, "T68", "C", L.SPELLS_WITHOUT_GETSPELLINFO_GETSPELLCOOLDOWN_ISUSABLESPELL, function()
        local ref = { BS.SpellInfo(6603) }
        local old = { GetSpellInfo = N, GetSpellCooldown = N, IsUsableSpell = N, IsSpellInRange = N }
        local a = WithApi(old, function() return BS.SpellInfo(6603) end)
        old.C_Spell = N
        local res = WithApi(old, function()
            local s, d = BS.GetCooldown(6603)
            local u, m = BS.IsUsable(6603)
            return BS.SpellInfo(6603) == nil and s == 0 and d == 0 and u == true and m == false and BS.InRange(6603, "player") == nil
        end)
        return (not C_Spell or a == ref[1]) and res
    end)
    C(R, "T69", "C", L.ITEMS_WITHOUT_GETITEMCOUNT_GETITEMICON_GETITEMINFO, function()
        local ref = BS.ItemCount(6948)
        local a = WithApi({ GetItemCount = N, GetItemIcon = N, GetItemInfo = N, GetItemInfoInstant = N }, function()
            BS.HasOffhandWeapon()
            return BS.ItemCount(6948)
        end)
        return (not (C_Item and C_Item.GetItemCount)) or a == ref
    end)
    C(R, "T70", "C", L.SPELLBOOK_WITHOUT_OLD_FUNCTIONS, function()
        local ref = Count(BS.known)
        local a = WithApi({ GetNumSpellTabs = N, GetSpellTabInfo = N, GetSpellBookItemName = N, GetSpellBookItemInfo = N, IsPassiveSpell = N },
            function() BS:ScanSpellbook(); return Count(BS.known) end)
        local b = WithApi({ GetNumSpellTabs = N, GetSpellTabInfo = N, GetSpellBookItemName = N, GetSpellBookItemInfo = N,
            IsPassiveSpell = N, C_SpellBook = N }, function() BS:ScanSpellbook(); return BS.spellbookOK == false and BS:IsKnown("x") == true end)
        BS:ScanSpellbook()
        local hasNew = C_SpellBook and C_SpellBook.GetNumSpellBookSkillLines
        return (not hasNew or a == ref) and b, L.NO_NOTICE_TO_THE_PLAYER
    end)
    C(R, "T71", "C", L.TALENTS_WITHOUT_OLD_FUNCTIONS, function()
        local ok, txt = WithApi({ GetNumTalentTabs = N, GetTalentInfo = N, GetActiveTalentGroup = N, GetPrimaryTalentTree = N }, function()
            BS:ScanTalents()
            local r = BS.talentsReadable == false and (BS.family == "modern" or BS.mainSpec == 0)
            local t = ""
            if BS.family == "classic" then OpenPage("skill"); t = PageTexts("skill"); BS.optionsFrame:Hide() end
            return r, t
        end)
        BS:ScanTalents()
        return ok and (BS.family == "modern" or txt:find(L.TALENTS_COULD_NOT_BE_READ_2, 1, true) ~= nil)
    end)
    C(R, "T72", "C", L.COMMUNICATION_WITHOUT_OLD_FUNCTIONS, function()
        local e0 = ErrCount()
        local ready = BS.syncReady
        WithApi({ RegisterAddonMessagePrefix = N, SendAddonMessage = N, JoinChannelByName = N, ChatFrame_RemoveChannel = N,
                  GetAddOnMetadata = N }, function()
            BS.syncReady = false
            Capture(function() BS:CHAT_MSG_CHANNEL_NOTICE("YOU_JOINED", nil, nil, nil, nil, nil, nil, nil, "BuffSentinelSync") end)
            BS:SendName("X", "both")
        end)
        BS.syncReady = ready
        BS:CommReset()
        return ErrCount() == e0 and (Selftest.sendCount or 0) == 0
    end)
    C(R, "T73", "C", L.OTHER_OLD_FUNCTIONS_MISSING, function()
        local e0 = ErrCount()
        local res = WithApi({ GetZonePVPInfo = N, C_PvP = N, GetNumRaidMembers = N, GetNumPartyMembers = N,
            CombatLogGetCurrentEventInfo = N, GetSpellBaseCooldown = N, GetSpecialization = N }, function()
            local _, ctx = BS:GetContext()
            local units = BS:GetGroupUnits()
            BS:COMBAT_LOG_EVENT_UNFILTERED()
            BS:ScanSpecialization()
            return ctx ~= nil and #units >= 1 and BS.mainSpec == 0
        end)
        BS:ScanTalents()
        return res and ErrCount() == e0
    end)
    R:Client("T74", "C", L.WHICH_OLD_FUNCTIONS_DOES_FOREVER,
        "/dump GetNumTalentTabs, GetTalentInfo, UnitBuff, GetSpellInfo, C_SpellBook ~= nil, ChatFrame_RemoveChannel, ChatFrameUtil, JoinTemporaryChannel")

    -- (3) Kampfsperre
    local hits, counting = 0, false
    local function hook(f)
        if f.bsTestHooked then return end
        f.bsTestHooked = true
        for _, m in ipairs({ "SetAttribute", "Show", "Hide", "SetPoint" }) do
            hooksecurefunc(f, m, function() if Selftest.countSecure then hits = hits + 1 end end)
        end
    end
    C(R, "T75", "C", L.NO_PROTECTED_ACTIONS_DURING_LOCKDOWN, function()
        for _, b in ipairs(PoolButtons(false)) do hook(b) end
        for _, c in ipairs(BS.dispelCells or {}) do hook(c) end
        for _, c in ipairs((BS.raster and BS.raster.cells) or {}) do hook(c) end
        hits = 0
        local lines = {}
        With({ testLockdown = true }, function()
            Selftest.countSecure = true
            local ok, err = pcall(function()
                lines = Capture(function()
                    BS:Refresh(); BS:Layout(); BS:Arm(); BS:ArmDispel(true); BS:LayoutDispel(); BS:UpdateRaster(true)
                    BS:SettingsChanged(); BS:ToggleRaster(); BS:StartTestMode(); BS:ChangeScale("proc", 0.1)
                    BS:ResetPositions(); BS:ApplyPositions()
                end)
            end)
            Selftest.countSecure = false
            if not ok then error(err, 0) end
        end)
        return hits == 0 and BS.pendingLayout == true and AnyLine(lines, L.NOT_POSSIBLE_IN_COMBAT_2) and AnyLine(lines, L.AFTER_COMBAT),
            L.PROTECTED_CALLS .. hits
    end)
    C(R, "T76", "C", L.FOREVER_IN_COMBAT_EVERYTHING_OFF, function()
        local evals = 0
        local function wrap(f) return function(...) evals = evals + 1; return f(...) end end
        BS.db.locked = true
        return Sim("forever", function()
            return With({ testCombat = true, EvalBuff = wrap(BS.EvalBuff), EvalProc = wrap(BS.EvalProc), EvalCooldown = wrap(BS.EvalCooldown) }, function()
                BS:Refresh()
                local shown = 0
                for _, b in ipairs(PoolButtons(true)) do if b:IsShown() and b:GetAlpha() > 0 then shown = shown + 1 end end
                return evals == 0 and shown == 0, L.EVALUATIONS .. evals .. L.VISIBLE .. shown
            end)
        end)
    end)
    C(R, "T77", "C", L.CATCHING_UP_AFTER_COMBAT, function()
        BS.pendingLayout = true
        Capture(function() BS:PLAYER_REGEN_ENABLED() end)
        return BS.pendingLayout == false and BS.pendingScan ~= true
    end)
    C(R, "T78", "C", L.COMBAT_LOG_SWITCH, function()
        local f = Sim("forever", function() return BS:WantsCombatLog() end)
        local r = Sim("retail", function() return BS:WantsCombatLog() end)
        local reg = BS.frame:IsEventRegistered("COMBAT_LOG_EVENT_UNFILTERED")
        return f == false and r == false and reg == (not Selftest.realBefore.restricted), L.REALLY_REGISTERED .. YN(reg)
    end)
    C(R, "T79", "C", L.REACTIVE_ABILITIES_WITHOUT_COMBAT_LOG, function()
        local reads = 0
        local trig = setmetatable({}, { __index = function() reads = reads + 1 end })
        local e = TestEntry("proc", { spellName = "Testzauber", data = { kind = "proc", trigger = "dodge" } })
        local a = With({ hasCombatLog = false, triggers = trig, IsUsable = function() return true, false end, IsReady = function() return true end },
            function() return BS:EvalProc(FakeButton(), e, GetTime(), true) end)
        local b = With({ hasCombatLog = false, triggers = trig, IsUsable = function() return false, false end, IsReady = function() return true end },
            function() return BS:EvalProc(FakeButton(), e, GetTime(), true) end)
        return a == true and b == false and reads == 0
    end)
    BS:ScanPlayerAuras()
end

------------------------------------------------------------------------
-- D. Alte Clients (Era/TBC)
------------------------------------------------------------------------
Run.D = function(R)
    local old = not Selftest.realBefore.restricted
    local function skipAll()
        for _, t in ipairs({ { "T80", L.AURAS_THE_OLD_WAY }, { "T81", L.SPELLS_THE_OLD_WAY }, { "T82", L.SPELLBOOK_THE_OLD_WAY },
            { "T83", L.ITEMS_THE_OLD_WAY }, { "T84", L.COMBAT_LOG_TRIGGERS }, { "T85", L.MAIN_TREE_ONLY_IN_CATA },
            { "T87", L.OLD_COMBAT_PATH_UNCHANGED } }) do
            R:Skip(t[1], "D", t[2], L.NO_UNITBUFF_MODERN_CLIENT)
        end
    end
    if not old then skipAll() else
        local N = BS.NIL
        C(R, "T80", "D", L.AURAS_THE_OLD_WAY, function()
            local function names(t) local o = {}; for k in pairs(t) do o[#o + 1] = tostring(k) end; table.sort(o); return table.concat(o, ",") end
            local ref = names(BS.ScanAuras("player", {}))
            local a = WithApi({ C_UnitAuras = N }, function()
                BS:ScanPlayerAuras()
                BS._test.ForEachAura("player", "HARMFUL", function() end)
                return names(BS.ScanAuras("player", {}))
            end)
            BS:ScanPlayerAuras()
            return a == ref
        end)
        C(R, "T81", "D", L.SPELLS_THE_OLD_WAY, function()
            local ref = { BS.SpellInfo(6603) }
            local u0 = BS.IsUsable(6603)
            return WithApi({ C_Spell = N }, function()
                local n = BS.SpellInfo(6603)
                local s, d = BS.GetCooldown(6603)
                return n == ref[1] and type(s) == "number" and type(d) == "number" and BS.IsUsable(6603) == u0
            end)
        end)
        C(R, "T82", "D", L.SPELLBOOK_THE_OLD_WAY, function()
            if not API.GetNumSpellTabs then return true, L.GETNUMSPELLTABS_MISSING end
            local ref = Count(BS.known)
            local a = WithApi({ C_SpellBook = N }, function() BS:ScanSpellbook(); return Count(BS.known) end)
            BS:ScanSpellbook()
            return a == ref, a .. " / " .. ref
        end)
        C(R, "T83", "D", L.ITEMS_THE_OLD_WAY, function()
            BS:ResolveEntries()
            local function ids() local o = {}; for _, e in ipairs(BS.entries) do if e.data.items then o[#o + 1] = tostring(e.itemID) end end; return table.concat(o, ",") end
            local ref = ids()
            local a = WithApi({ C_Item = N }, function() BS:ResolveEntries(); return ids() end)
            BS:ResolveEntries()
            return a == ref, ref
        end)
        C(R, "T84", "D", L.COMBAT_LOG_TRIGGERS, function()
            local me = BS.playerGUID
            local function fire(...) local args = { ... }
                WithApi({ CombatLogGetCurrentEventInfo = function() return unpack(args, 1, 16) end }, function() BS:COMBAT_LOG_EVENT_UNFILTERED() end)
            end
            local t = With({ triggers = {} }, function()
                fire(0, "SWING_MISSED", nil, me, nil, nil, nil, "x", nil, nil, nil, "DODGE")
                fire(0, "SPELL_MISSED", nil, "x", nil, nil, nil, me, nil, nil, nil, 1, nil, nil, "PARRY")
                local a = BS.triggers.dodge and BS.triggers.parry and BS.triggers.avoid
                BS.triggers = {}
                fire(0, "SWING_DAMAGE", nil, "x", nil, nil, nil, me, nil, nil, nil, 10, nil, nil, nil, 5)
                return a and BS.triggers.avoid ~= nil
            end)
            return t and true or false
        end)
        C(R, "T85", "D", L.MAIN_TREE_ONLY_IN_CATA, function()
            if BS.family ~= "classic" then return true, L.NO_TALENT_TREES end
            local a = WithApi({ GetPrimaryTalentTree = function() return 3 end }, function()
                local x = With({ expansion = 2 }, function() BS:ScanTalentTrees(); return BS.mainSpec end)
                local y = With({ expansion = 4 }, function() BS:ScanTalentTrees(); return BS.mainSpec end)
                return { x, y }
            end)
            BS:ScanTalents()
            return a[2] == 3 and (a[1] ~= 3 or (BS.points[3] or 0) > 0 or Count(BS.talents) == 0), "TBC " .. tostring(a[1]) .. L.CATA .. tostring(a[2])
        end)
        C(R, "T87", "D", L.OLD_COMBAT_PATH_UNCHANGED, function()
            BS:Layout()
            local ctxOK = BS:GetContext()
            BS:Arm()
            local shown = 0
            for _, b in ipairs(PoolButtons(true)) do if b:IsShown() then shown = shown + 1 end end
            local n = #PoolButtons(true)
            BS:Layout()
            return (not ctxOK) or shown == n, shown .. "/" .. n .. L.BUTTONS_ARMED
        end)
    end
    if BS.expansion == 1 and not BS.isForever then
        C(R, "T86", "D", L.FACTION_IN_ERA, function()
            local has = {}
            for _, c in ipairs(BS._test.AvailableClasses()) do has[c[1]] = true end
            local fac = UnitFactionGroup("player")
            local a = (fac == "Horde" and not has.PALADIN) or (fac == "Alliance" and not has.SHAMAN) or (fac ~= "Horde" and fac ~= "Alliance")
            local b = Sim("forever", function()
                local h = {}
                for _, c in ipairs(BS._test.AvailableClasses()) do h[c[1]] = true end
                return h.PALADIN and h.SHAMAN
            end)
            return a and b and true or false
        end)
    else
        R:Skip("T86", "D", L.FACTION_IN_ERA, L.CLASSIC_ERA_ONLY)
    end
end

------------------------------------------------------------------------
-- E. Daten
------------------------------------------------------------------------
Run.E = function(R)
    local key = Selftest.key
    local base = DeepCopy(BuffSentinelDB)
    local function Fresh(mod)
        local g = DeepCopy(base)
        if mod then mod(g) end
        BuffSentinelDB = g
        BS:InitDB()
        return g
    end
    local function Everything()
        BS:Layout(); BS:Refresh(); BS:RefreshGroup()
        for _, k in ipairs({ "skill", "proc", "buff", "cd", "dispel", "opt", "rec" }) do OpenPage(k) end
        BS.optionsFrame:Hide()
    end
    C(R, "T88", "E", L.FRESH_INSTALL, function()
        BuffSentinelDB = nil
        BS:InitDB()
        local g, db = BuffSentinelDB, BS.db
        Capture(Everything)
        return g.profiles[key] == db and db.zones.world == true and db.soundV2 == true and db.soundV3 == true and g.auto.enabled == true
            and g.auto.share == true and g.shareNames == true and g.shareServer == true and type(g.recorder.list) == "table"
    end)
    C(R, "T89", "E", L.MIGRATION_FROM_0_8_3, function()
        Fresh(function(g) g.profiles[key] = { sound = { buff = true, proc = true } } end)
        local db = BS.db
        return db.sound.buff == false and db.sound.proc == false and db.soundV2 and db.soundBase.buff and db.soundBase.buff.on == false
            and db.soundBase.proc.on == false and db.soundV3
    end)
    C(R, "T90", "E", L.MIGRATION_FROM_0_8_6, function()
        Fresh(function(g) g.profiles[key] = { soundV2 = true, hornSelfBuff = false, sound = { dispel = true } } end)
        local b = BS.db.soundBase
        return b.horn and b.horn.on == false and b.dispel.on == true and b.dispel_imp.on == true
    end)
    C(R, "T91", "E", L.MIGRATION_OF_OLDER_FIELDS, function()
        Fresh(function(g)
            local p = g.profiles[key] or {}
            p.groupScale, p.groupLayout, p.winPos, p.btnPos, p.custom = nil, nil, nil, nil, nil
            p.scale = 1.3
            g.profiles[key] = p
            g.auto, g.learned = nil, nil
            g.recorder = { enabled = false }
        end)
        local db, g = BS.db, BuffSentinelDB
        return db.scale == 1.3 and db.groupScale.proc == 1 and db.groupLayout.cd and type(db.winPos) == "table"
            and type(db.custom) == "table" and type(g.auto.classes) == "table" and type(g.learned.spells) == "table"
            and type(g.recorder.list) == "table"
    end)
    local cls = BS.class or "WARRIOR"
    local cases = {
        a = function(g) g.profiles[key] = "kaputt" end,
        b = function(g) g.profiles[key].zones = 5 end,
        c = function(g) g.profiles[key].groupScale = { proc = "gross" } end,
        d = function(g) g.profiles[key].btnPos = { [cls .. ":x"] = {} } end,
        e = function(g) g.profiles[key].pos = { proc = { "CENTER" } } end,
        f = function(g) g.profiles[key].winPos = { options = true } end,
        g = function(g) g.profiles[key].custom = { "kaputt", { aura = nil } } end,
        h = function(g) g.profiles[key].specs = { spec1 = { x = "x" } } end,
        i = function(g) g.auto = { classes = { [cls] = { procs = { X = 5 }, cds = "x" } } } end,
        j = function(g) g.learned = { talents = { [cls] = { T = "1:2:3" } }, spells = { X = 6603 } } end,
        k = function(g) g.recorder = { list = { L.UNKNOWN } } end,
        l = function(g) local p = g.profiles[key]; p.minimap = { angle = "x" }; p.hornEvery = 0; p.soundChannel = L.BROKEN; p.soundBase = { horn = "x" } end,
    }
    local bad = {}
    for _, c in ipairs({ "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l" }) do
        local ok, err = pcall(function()
            local e0 = ErrCount()
            Fresh(function(g) if type(g.profiles[key]) ~= "table" then g.profiles[key] = {} end; cases[c](g) end)
            Capture(Everything)
            if ErrCount() ~= e0 then error(BS.errors.last, 0) end
        end)
        if not ok then bad[#bad + 1] = c .. ": " .. tostring(err) end
    end
    C(R, "T92", "E", L.DAMAGED_ENTRIES, function() return #bad == 0, #bad == 0 and L.A_L_WITHOUT_ERRORS or table.concat(bad, " | ") end)
    C(R, "T93", "E", L.LIMITS, function()
        Fresh()
        local r = BS.gdb.recorder
        r.enabled = true
        BS.recPrev = {}
        Capture(function()
            local many = {}
            for i = 1, 150 do many["Grenze" .. i] = { id = i } end
            BS.playerAuraInfo = many
            BS:RecordAuras()
        end)
        local n1 = #r.list
        BS:AutoTestState({ active = {}, prevInfo = {}, recentCasts = {}, pendingRemove = {} })
        With({ InCombat = function() return true end }, function()
            local now = GetTime()
            local many = {}
            for i = 1, 50 do many["Kandidat" .. i] = { duration = 10, expires = now + 10, count = 0, source = "player" } end
            BS.playerAuraInfo = many
            BS:AutoScanAuras()
            BS.playerAuraInfo = {}
            BS:AutoScanAuras()
        end)
        local _, c = BS:AutoDB()
        local n2 = Count(c.cand)
        local q
        With({ testCommUntil = false }, function()
            BS:CommReset()
            for i = 1, 60 do BS:SendName(L.LIMIT .. i, "sync") end
            local _, qs = BS:CommQueueSizes()
            q = qs
            BS:CommReset()
        end)
        BS.playerAuraInfo = {}
        return n1 <= 100 and n2 <= BS.AUTO_MAX_CAND and q <= 40, string.format(L.RECORDER_CANDIDATES_SERVER_QUEUE, n1, n2, q)
    end)
    Fresh()
end

------------------------------------------------------------------------
-- F. Sprachen (BuffSentinel hat keine Sprachdateien – Oberfläche deutsch)
------------------------------------------------------------------------
Run.F = function(R)
    C(R, "T94", "F", L.DONATE_TEXTS_IN_ALL_LANGUAGES, function()
        local D, bad = BS.Donate, {}
        local function n(s) local _, c = tostring(s):gsub("%%s", ""); return c end
        for _, loc in ipairs({ "deDE", "enUS", "enGB", "frFR", "esES", "esMX", "ptBR", "itIT", "ruRU", "koKR", "zhCN", "zhTW" }) do
            D.locale = loc
            local ok = pcall(function()
                if n(D.Text("title")) ~= 1 or n(D.Text("thanks")) ~= 1 or n(D.Text("button")) ~= 0 or n(D.Text("hint")) ~= 0 then error("x") end
                string.format(D.Text("title"), "X"); string.format(D.Text("thanks"), "X")
            end)
            if not ok then bad[#bad + 1] = loc end
        end
        D.locale = nil
        return #bad == 0, L.T_WRONG .. table.concat(bad, ",")
    end)
    C(R, "T95", "F", L.GOLDSENTINELGAME_DEV_TEXTS_OF_THE, function()
        local G, bad = GoldSentinelGame, {}
        for _, k in ipairs({ "game", "api", "modern", "old", "secrets", "yes", "no", "test" }) do if G.Text(k) == k then bad[#bad + 1] = k end end
        if GoldSentinelDev:Text("blocked") == "blocked" then bad[#bad + 1] = "blocked" end
        G.Status()
        return #bad == 0, L.T_MISSING2 .. table.concat(bad, ",")
    end)
    C(R, "T96", "F", L.FORMATTED_MESSAGES, function()
        Capture(function()
            BS:AnnounceSpec()
            With({ errors = { count = 2, byArea = { TEST = 2 }, last = "TEST: x" } }, function() BS:ErrorSummary() end)
            BS:SpecText()
            for _, e in ipairs(BS.entries) do BS:EntryStatus(e) end
            BS:DispelSummary(); BS:SyncStatusText(); BS.AutoCdText(5); BS.AutoCdText(500)
        end)
        return true
    end)
    C(R, "T97", "F", L.UMLAUTS_AND_HYPHENATION, function()
        local up = BS.Upper("äöüéèàç") == "ÄÖÜÉÈÀÇ"
        local b = BS.pools.proc[1]
        if not b then return up, L.NO_PROC_BUTTON_FOR_THE end
        local old = b.label:GetText()
        b.label:SetText("BLITZSCHLAGSCHILD!")
        BS._test.FitLabel(b)
        local t = b.label:GetText()
        b.label:SetText(old)
        BS._test.FitLabel(b)
        return up and (t == "BLITZSCHLAGSCHILD!" or t == "BLITZSCHLAG-\nSCHILD!"), L.HYPHENATION .. tostring(t):gsub("\n", "/")
    end)
    -- Sprachen: Locales.lua (Englisch Standard, Deutsch Pflicht)
    local function Placeholders(t)
        local out = {}
        for p in tostring(t):gmatch("%%[-0-9.]*[sdf%%]") do out[#out + 1] = p end
        return table.concat(out, " ")
    end
    C(R, "T98", "F", L.T_LANG_SWITCH, function()
        if not (BS.ApplyLocale and BS.LOCALES) then return false, L.T_NO_LOCALES end
        local lines, german = {}, 0
        local ok, err = pcall(function()
            BS.ApplyLocale("enUS")
            lines = Capture(function() SlashCmdList.BUFFSENTINEL("help") end)
        end)
        BS.ApplyLocale(BS.locale)
        if not ok then error(err, 0) end
        local de = BS.LOCALES.deDE
        for _, l in ipairs(lines) do
            -- deutsch = Umlaut/ß oder genau ein deutscher Hilfetext
            local isDe = l:find("[\195][\132\150\156\164\182\188\159]") ~= nil
            for k, v in pairs(de) do if k:find("^HELP_") and l == v and v ~= BS.LOCALES.enUS[k] then isDe = true end end
            if isDe then german = german + 1 end
        end
        return #lines >= 5 and german == 0 and lines[1] == BS.LOCALES.enUS.HELP_HEADER,
            string.format(L.T_HELP_LINES, #lines, german)
    end)
    C(R, "T137", "F", L.T_LANG_KEYS, function()
        if not BS.LOCALES then return false, L.T_NO_LOCALES end
        local en, de, n, miss = BS.LOCALES.enUS, BS.LOCALES.deDE, 0, {}
        for k in pairs(en) do
            n = n + 1
            if type(de[k]) ~= "string" or de[k] == "" then miss[#miss + 1] = k end
        end
        for k in pairs(de) do if en[k] == nil then miss[#miss + 1] = "+" .. k end end
        table.sort(miss)
        return #miss == 0, string.format(L.T_KEYS_COUNT, n, table.concat(miss, ","))
    end)
    C(R, "T138", "F", L.T_LANG_PLACEHOLDERS, function()
        if not BS.LOCALES then return false, L.T_NO_LOCALES end
        local en, bad = BS.LOCALES.enUS, {}
        for code, t in pairs(BS.LOCALES) do
            if t ~= en then
                for k, v in pairs(t) do
                    if en[k] and Placeholders(v) ~= Placeholders(en[k]) then bad[#bad + 1] = code .. ":" .. k end
                end
            end
        end
        table.sort(bad)
        return #bad == 0, string.format(L.T_PLACEHOLDER_BAD, table.concat(bad, ","))
    end)
    R:Client("T99", "F", L.NON_GERMAN_CLIENT,
        L.ONCE_WITH_AN_ENUS_CLIENT)
end

------------------------------------------------------------------------
-- G. Zusammenspiel
------------------------------------------------------------------------
Run.G = function(R)
    C(R, "T100", "G", L.SHARED_FILES, function()
        local loaded = {}
        local isLoaded = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
        for _, a in ipairs({ "RaidMaster", "ThreatSentinel", "AHSentinel", "BuffSentinel", "GuildSentinel", "ProfessionSentinel", "LevelPilot" }) do
            if isLoaded and isLoaded(a) then loaded[#loaded + 1] = a end
        end
        local T = GoldSentinelTest
        return GoldSentinelGame.version == 2 and GoldSentinelDev.version == 1 and T.version >= 1 and T.registry.BuffSentinel ~= nil
            and _G.GoldSentinelTestHooked == true, L.T_LOADED .. table.concat(loaded, ",")
    end)
    C(R, "T101", "G", L.OWN_GLOBAL_NAMES, function()
        local ok = _G.BuffSentinel == BS and SLASH_BUFFSENTINEL1 == "/buffsentinel" and SLASH_BUFFSENTINEL2 == "/bsen"
            and type(SlashCmdList.BUFFSENTINEL) == "function"
        if hash_SlashCmdList and hash_SlashCmdList["/BSEN"] then ok = ok and hash_SlashCmdList["/BSEN"] == SlashCmdList.BUFFSENTINEL end
        for _, k in ipairs({ "proc", "buff", "cd", "dispel" }) do ok = ok and _G["BuffSentinelAnchor_" .. k] == BS.anchors[k] end
        ok = ok and _G.BuffSentinelMinimapButton == BS.minimapButton
        if BS.optionsFrame then ok = ok and _G.BuffSentinelOptions == BS.optionsFrame end
        return ok
    end)
    C(R, "T102", "G", L.LIBSHAREDMEDIA_WITH_AND_WITHOUT, function()
        BS.soundListCache = nil
        local a = #BS:SoundList()
        local lsm = 0
        for _, it in ipairs(BS:SoundList()) do if it.lsm then lsm = lsm + 1 end end
        BS.soundListCache = nil
        return a > 0, lsm .. L.LSM_SOUNDS
    end)
    R:Skip("T103", "G", L.OTHER_ADDONS_OF_THE_USER, L.BUFFSENTINEL_HAS_NO_INTERFACE_TO)
    R:Client("T104", "G", L.SEVERAL_GOLDSENTINEL_ADDONS_AT_ONCE,
        L.LOAD_BUFFSENTINEL_WITH_RAIDMASTER_GUILDSENTINEL)
end

------------------------------------------------------------------------
-- H. Leistung
------------------------------------------------------------------------
local function Measure(n, fn)
    local total, maxv = 0, 0
    for _ = 1, n do
        local t = debugprofilestop()
        fn()
        local d = debugprofilestop() - t
        total = total + d
        if d > maxv then maxv = d end
    end
    return total / n, maxv
end

Run.H = function(R)
    BS:Layout()
    C(R, "T105", "H", L.REFRESH_EVERY_0_1_S, function()
        local avg, mx = Measure(200, function() BS:Refresh() end)
        return avg < 2 and mx < 5, string.format(L.AVERAGE_MS_MAX_MS, avg, mx)
    end)
    C(R, "T106", "H", L.REFRESHGROUP_EVERY_0_5_S, function()
        local avg, mx = Measure(100, function() BS:RefreshGroup() end)
        return avg < 2, string.format(L.AVERAGE_MS_MAX_MS, avg, mx)
    end)
    R:Client("T106", "H", L.REFRESHGROUP_IN_A_40_PLAYER, L.IN_A_RAID_BSEN_TESTROUTINE)
    C(R, "T107", "H", "UNIT_AURA", function()
        local avg, mx = Measure(100, function() BS:ScanPlayerAuras() end)
        return avg < 1, string.format(L.AVERAGE_MS_MAX_MS, avg, mx)
    end)
    C(R, "T108", "H", L.EXPENSIVE_RECALCULATIONS, function()
        local res = {}
        local worst = 0
        for name, fn in pairs({ FullScan = function() BS:FullScan() end, Layout = function() BS:Layout() end,
                                ResolveEntries = function() BS:ResolveEntries() end, Optionen = function() OpenPage("opt") end }) do
            local avg = Measure(10, fn)
            res[#res + 1] = string.format("%s %.1f", name, avg)
            if avg > worst then worst = avg end
        end
        if BS.optionsFrame then BS.optionsFrame:Hide() end
        BS:Layout()
        return worst < 16, table.concat(res, ", ") .. " ms"
    end)
    C(R, "T109", "H", L.SMALL_PATHS, function()
        local t0 = GetTime()
        local i = 0
        local d = Measure(50, function() i = i + 1; BS:RefreshDispel(t0 + i, true, false, false, false) end)
        local c = Measure(50, function() BS:CHAT_MSG_ADDON("BuffSentinel", "Q;S;Testname", "GUILD", "Testsender") end)
        local p = Measure(50, function() BS:PumpComm() end)
        local b, e = FakeButton(), TestEntry("proc", { procAuraNames = { TestProc = true } })
        local ev = Measure(50, function() BS:EvalProc(b, e, GetTime(), true) end)
        return d < 0.5 and c < 0.5 and p < 0.5 and ev < 0.5, string.format(L.DISPEL_MESSAGE_PUMP_EVALPROC_MS, d, c, p, ev)
    end)
    C(R, "T110", "H", L.MEMORY, function()
        collectgarbage("collect")
        local a = collectgarbage("count")
        for _ = 1, 1000 do BS:Refresh() end
        for _ = 1, 200 do BS:RefreshGroup() end
        for _ = 1, 200 do BS:ScanPlayerAuras() end
        collectgarbage("collect")
        local b = collectgarbage("count")
        return b - a < 100, string.format(L.BEFORE_KB_AFTER_KB, a, b)
    end)
end

------------------------------------------------------------------------
-- I. Fehlerzählung und Diagnose
------------------------------------------------------------------------
local function GTErrors(where)
    local s = Selftest.real and Selftest.real.gsTest
    for _, e in pairs((s and s.errors) or {}) do
        if type(e) == "table" and tostring(e.wo) == where then return e end
    end
end

Run.I = function(R)
    C(R, "T111", "I", L.COUNTERROR_COUNTS_AND_REPORTS, function()
        local c0 = ErrCount()
        local lines = Capture(function() BS:CountError("TEST:Probe", "absichtlich"); BS:CountError("TEST:Probe", "absichtlich") end)
        return ErrCount() == c0 + 2 and BS.errors.byArea["TEST:Probe"] == 2 and BS:ErrorSummary():find("TEST:Probe 2x", 1, true)
            and #lines == 1 and GTErrors("TEST:Probe") ~= nil
    end)
    C(R, "T112", "I", L.ERROR_IN_THE_EVENT_HANDLER, function()
        BS.TEST_EVENT = function() error("TEST:absichtlich") end
        Capture(function() BS.frame:GetScript("OnEvent")(BS.frame, "TEST_EVENT") end)
        BS.TEST_EVENT = nil
        return (BS.errors.byArea["Event TEST_EVENT"] or 0) >= 1
    end)
    C(R, "T113", "I", L.AN_ERROR_IN_ONE_BUTTON, function()
        BS:Layout()
        local buttons = PoolButtons(true)
        if #buttons < 2 then return true, L.FEWER_THAN_TWO_BUTTONS end
        local target = buttons[1].entry
        local others = 0
        local function wrap(f) return function(self, b, e, ...) if e == target then error("TEST:absichtlich") end; others = others + 1; return f(self, b, e, ...) end end
        local k0 = (BS.errors.byArea[target.key] or 0)
        With({ GetContext = function() return true, "dungeon" end, EvalBuff = wrap(BS.EvalBuff), EvalProc = wrap(BS.EvalProc),
               EvalCooldown = wrap(BS.EvalCooldown) }, function()
            Capture(function() for _ = 1, 10 do BS:Refresh() end end)
        end)
        return (BS.errors.byArea[target.key] or 0) - k0 == 10 and others >= 10, L.OTHER_EVALUATIONS .. others
    end)
    C(R, "T114", "I", L.ERRORS_IN_SCAN_OPTIONS_COMMUNICATION, function()
        local Fill = BS._test.Fill
        local origOpt = Fill.opt
        Capture(function()
            With({ ScanTalents = function() error("TEST:absichtlich") end }, function() BS:FullScan() end)
            Fill.opt = function() error("TEST:absichtlich") end
            local ok = pcall(OpenPage, "opt")
            Fill.opt = origOpt
            if BS.optionsFrame then BS.optionsFrame:Hide() end
            With({ PumpComm = function() error("TEST:absichtlich") end }, function()
                BS.frame:GetScript("OnUpdate")(BS.frame, 0.6)
            end)
        end)
        Fill.opt = origOpt
        BS:ScanTalents()
        local A = BS.errors.byArea
        return (A["Scan"] or 0) > 0 and (A[L.OPTIONS_2 .. "opt"] or 0) > 0 and (A["Komm"] or 0) > 0
    end)
    C(R, "T115", "I", L.DIAGNOSTICS_SHOW_ERRORS, function()
        local lines = Capture(function() SlashCmdList.BUFFSENTINEL("fehler") end)
        return AnyLine(lines, "TEST:Probe") and AnyLine(lines, L.RESTRICTIONS) and AnyLine(lines, L.COMBAT_LOG_2) and AnyLine(lines, L.OPEN_REPORTS_2)
    end)
    C(R, "T116", "I", L.LUA_ERRORS_IN_NORMAL_PLAY, function()
        local h = geterrorhandler()
        pcall(h, "Interface/AddOns/BuffSentinel/SelfTest.lua:1: TEST:absichtlich (Testroutine BuffSentinel, bitte ignorieren)")
        return GTErrors("Lua") ~= nil
    end)
end

------------------------------------------------------------------------
-- J. Regressionstests (jeder Befund ein Testfall)
------------------------------------------------------------------------
Run.J = function(R)
    local S = NewSecret()
    C(R, "T117", "J", L.PB_1_AU_1_FOREVER, function()
        return Sim("forever", function()
            return With({ testCombat = true }, function()
                local info0 = BS.playerAuraInfo
                BS:ScanPlayerAuras()
                local a = BS.playerAuraInfo == info0
                local g0 = BS.unitInfo
                BS:RefreshGroup()
                local b = BS.unitInfo == g0
                local shownBefore = 0
                BS:Arm()
                for _, x in ipairs(PoolButtons(true)) do if x:IsShown() and x:GetAlpha() > 0 then shownBefore = shownBefore + 1 end end
                local r = BS:ResolveDispelSpells()
                BS:LayoutDispel()
                return a and b and #r.spells == 0 and not BS.dispelActive and not BS:WantsCombatLog() and BS:CombatLocked(),
                    L.SWITCHES_AURAS .. YN(a) .. L.GROUP_5 .. YN(b)
            end)
        end)
    end)
    C(R, "T118", "J", L.PB_2_AU_2_OWN, function()
        local notes = 0
        for _, f in ipairs({ "applications", "expirationTime", "spellId", "duration", "sourceUnit" }) do
            local a = { name = "TestAura3", icon = 1, applications = 1, expirationTime = GetTime() + 5, spellId = 1, duration = 5, sourceUnit = "player" }
            a[f] = S
            BS.secretNoted = false
            local lines = Capture(function()
                WithApi({ C_UnitAuras = FakeAuras({ ["player:HELPFUL"] = { a } }) }, function() BS:ScanPlayerAuras() end)
                BS:EvalProc(FakeButton(), TestEntry("proc", { procAuraNames = { TestAura3 = true } }), GetTime(), true)
            end)
            notes = notes + #lines
        end
        BS:ScanPlayerAuras()
        return notes == 5 and not Leaked(S), L.NOTES_2 .. notes
    end)
    C(R, "T119", "J", L.PB_2_AU_2_AUTOLEARN, function()
        With({ InCombat = function() return true end }, function()
            BS.playerAuraInfo = { TestAura4 = { count = nil, expires = nil } }
            BS:AutoScanAuras(); BS:AutoScanAuras()
        end)
        local p = BS:AutoTestState().prev.TestAura4
        BS.playerAuraInfo = {}
        return p and p.count == 0 and p.expires == 0
    end)
    C(R, "T120", "J", L.PB_3_AU_6_PROTECTED, function()
        local b, e = FakeButton(), TestEntry("cd", { spellName = "x" })
        local step = { 0, 0 }
        BS:SetSoundSetting("cooldown", "on", true)
        local snd0 = BS.testSoundCount or 0
        local r = With({ GetCooldown = function() if step == "secret" then return 0, 0, true end return step[1], step[2] end }, function()
            BS:EvalCooldown(b, e, GetTime(), true, "dungeon")
            step = "secret"
            local two = BS:EvalCooldown(b, e, GetTime(), true, "dungeon")
            step = { 0, 0 }
            BS:EvalCooldown(b, e, GetTime(), true, "dungeon")
            return two
        end)
        return r == false and b.flashUntil == nil and (BS.testSoundCount or 0) == snd0
    end)
    C(R, "T121", "J", L.PB_4_AU_3_EXECUTE, function()
        local function hp(h, m)
            return WithApi({ UnitExists = function() return true end, UnitCanAttack = function() return true end, UnitIsDead = function() return false end,
                UnitHealth = function() return h end, UnitHealthMax = function() return m end },
                function() return BS:EvalProc(FakeButton(), TestEntry("proc", { data = { kind = "proc", targetBelow = 20 } }), GetTime(), true) end)
        end
        return hp(S, 100) == false and hp(10, S) == false
    end)
    C(R, "T122", "J", L.PB_5_AU_4_GROUP, function()
        local e = TestEntry("buff", { key = "test:grp", data = { kind = "buff", group = true }, auraNames = { TestBuffXYZ = true } })
        With({ entries = { e } }, function()
            WithApi({ UnitName = function() return S end }, function() BS:RefreshGroup() end)
        end)
        return BS.unitInfo.player and BS.unitInfo.player.name == "?" and not Leaked(S)
    end)
    C(R, "T123", "J", L.PB_6_AU_5_DEBUFF, function()
        local hits = 0
        local types = setmetatable({}, { __index = function(_, k) if rawequal(k, S) then hits = hits + 1 end end })
        local cell = BS:GetDispelCell(1)
        local list = { ["player:HARMFUL"] = { { name = "Testdebuff", dispelName = S, spellId = S } } }
        With({ dispelActive = true, dispelSpells = { types = types, spells = { "x" }, slotOf = { x = 1 } } }, function()
            local u = cell.unit
            cell.unit = "player"
            WithApi({ C_UnitAuras = FakeAuras(list) }, function() BS:RefreshDispel(GetTime() + 5000, true, false, false, false) end)
            cell.unit = u
        end)
        return hits == 0, L.ACCESSES_WITH_TEST_VALUE .. hits
    end)
    C(R, "T124", "J", L.PB_7_AU_7_COMBAT, function()
        local list = {}
        for _, d in ipairs((BS.ClassData[BS.class] or {}).entries or {}) do if d.trigger then list[#list + 1] = d end end
        local ok = true
        for _, d in ipairs(list) do
            local e = TestEntry("proc", { spellName = "Testzauber", data = d })
            local a = With({ hasCombatLog = false, IsUsable = function() return true, false end, IsReady = function() return true end },
                function() return BS:EvalProc(FakeButton(), e, GetTime(), true) end)
            if a ~= true then ok = false end
        end
        local reg = BS.frame:IsEventRegistered("COMBAT_LOG_EVENT_UNFILTERED")
        return ok and reg == (not Selftest.realBefore.restricted), #list .. L.ENTRIES_WITH_A_TRIGGER
    end)
    C(R, "T125", "J", L.PB_8_AU_8_ERRORS, function()
        local buttons = PoolButtons(true)
        if #buttons < 2 then return true, L.FEWER_THAN_TWO_BUTTONS end
        local target, others = buttons[1].entry, 0
        local function wrap(f) return function(self, b, e, ...) if e == target then error("TEST:absichtlich") end; others = others + 1; return f(self, b, e, ...) end end
        local k0 = BS.errors.byArea[target.key] or 0
        local lines = With({ GetContext = function() return true, "dungeon" end, EvalBuff = wrap(BS.EvalBuff), EvalProc = wrap(BS.EvalProc),
            EvalCooldown = wrap(BS.EvalCooldown) }, function() return Capture(function() for _ = 1, 10 do BS:Refresh() end end) end)
        return (BS.errors.byArea[target.key] or 0) - k0 == 10 and #lines <= 1 and others >= 10
    end)
    C(R, "T126", "J", L.PB_9_AU_9_INVISIBLE, function()
        return Sim("forever", function()
            BS:Layout()
            Capture(function() BS:PLAYER_REGEN_DISABLED() end)
            local shown = 0
            for _, b in ipairs(PoolButtons(false)) do if b:IsShown() or b.wasShown then shown = shown + 1 end end
            for _, c in ipairs(BS.dispelCells or {}) do if c:IsShown() then shown = shown + 1 end end
            return shown == 0, L.T_VISIBLE .. shown
        end)
    end)
    BS:Layout()
    C(R, "T127", "J", L.KO_1_SELF_TEST_WITH, function()
        local lines = Capture(function() SlashCmdList.BUFFSENTINEL("selbsttest") end)
        local first, last = lines[1] or "", lines[#lines] or ""
        local old = not Selftest.realBefore.restricted
        return type(BS.DetectFlavor) == "function" and first:find("restricted: " .. L.YES, 1, true) ~= nil
            and (not old or last:find("restricted: " .. L.NO, 1, true) ~= nil), #lines .. L.LINES
    end)
    C(R, "T128", "J", L.KO_2_ERRORS_IN_EVENT, function()
        BS.errShownEvent = false
        local c0 = BS.errors.byArea["Event TEST_EVENT2"] or 0
        BS.TEST_EVENT2 = function() error("TEST:absichtlich") end
        local lines = Capture(function()
            BS.frame:GetScript("OnEvent")(BS.frame, "TEST_EVENT2")
            BS.frame:GetScript("OnEvent")(BS.frame, "TEST_EVENT2")
        end)
        BS.TEST_EVENT2 = nil
        return (BS.errors.byArea["Event TEST_EVENT2"] or 0) - c0 == 2 and #lines == 1
    end)
    C(R, "T129", "J", L.KO_3_CATCH_UP_HIDING, function()
        With({ testLockdown = true }, function() BS:HideAllForCombat() end)
        local pend = BS.hidePending == true
        Capture(function() BS:PLAYER_REGEN_ENABLED() end)
        return pend and BS.hidePending == false
    end)
    R:Client("T129", "J", L.CLICKS_AFTER_RELOAD_IN_COMBAT, L.RELOAD_IN_COMBAT_THEN_CLICK)
    C(R, "T130", "J", L.KO_4_WOW_FOREVER_NOTE, function()
        return Sim("forever", function()
            OpenPage("proc")
            local p = PageTexts("proc")
            OpenPage("dispel")
            local d = PageTexts("dispel")
            BS.optionsFrame:Hide()
            local want = BS:LockedText()
            return p:find(want, 1, true) ~= nil and d:find(want, 1, true) ~= nil
                and not d:find(L.YOUR_CLASS_SPEC_CANNOT_DISPEL, 1, true)
                and not p:find(L.BUFFSENTINEL_LEARNS_NEW_PROCS_E, 1, true)
        end)
    end)
    C(R, "T131", "J", L.GA_NO_OWN_VERSION_OF, function()
        local G = GoldSentinelGame
        return G.version == 2 and type(G.Recalc) == "function" and type(G.ProperName) == "function"
            and (not BS.FLAVOR_EXP[G.flavor] or BS.flavor == G.flavor)
    end)
    C(R, "T132", "J", L.AU_DO_NOT_CHANGE_SECURE, function()
        local bad = {}
        for _, e in ipairs(R.results) do
            if e.status == "FEHLER" and ({ T59 = 1, T67 = 1, T68 = 1, T69 = 1, T70 = 1, T71 = 1, T72 = 1, T73 = 1, T75 = 1, T77 = 1 })[e.id] then
                bad[#bad + 1] = e.id
            end
        end
        return #bad == 0, #bad == 0 and L.BASED_ON_T59_T67_T73 or table.concat(bad, ",")
    end)
    C(R, "T133", "J", L.AU_LAUNCH_INTERFACE_NUMBER, function()
        local info = C_AddOns and C_AddOns.GetAddOnInfo and { C_AddOns.GetAddOnInfo("BuffSentinel") }
        local reason = info and info[5]
        return reason ~= "INTERFACE_VERSION", L.REASON .. tostring(reason)
    end)
    R:Client("T133", "J", L.INTERFACE_NUMBER_IN_THE_CLIENT, L.DUMP_SELECT_4_GETBUILDINFO_IS)
    R:Client("T134", "J", L.RUN_IN_THE_FOREVER_CLIENT, L.BUFF_REMINDER_BEFORE_THE_PULL)
    R:Client("T135", "J", L.CROSS_CHECK_OLD_CLIENT,
        L.CLASSIC_ERA_OR_TBC_ANNIVERSARY)
end

-- Bereich B in zwei Teilen
do
    local B1, B2 = Run.B, Run.B2
    Run.B = function(R) B1(R); B2(R) end
end

------------------------------------------------------------------------
-- Halbautomatischer Teil: nächsten Kampf beobachten (nur lesen)
------------------------------------------------------------------------
function Selftest:StartCombatWatch()
    local w = self.watch
    if not w then
        w = CreateFrame("Frame")
        self.watch = w
        w:SetScript("OnEvent", function(_, event, a)
            local s = Selftest.watchState
            if not s then return end
            if event == "PLAYER_REGEN_DISABLED" then
                s.inCombat, s.started = true, true
                s.err0 = ErrCount()
                s.hiddenAtStart = 0
                for _, b in ipairs(PoolButtons(false)) do if b:IsShown() then s.hiddenAtStart = s.hiddenAtStart + 1 end end
                for _, c in ipairs(BS.dispelCells or {}) do if c:IsShown() then s.hiddenAtStart = s.hiddenAtStart + 1 end end
            elseif event == "PLAYER_REGEN_ENABLED" and s.started then
                s.inCombat = false
                Selftest:FinishCombatWatch()
            elseif (event == "ADDON_ACTION_BLOCKED" or event == "ADDON_ACTION_FORBIDDEN") and a == "BuffSentinel" then
                s.blocked = s.blocked + 1
            end
        end)
        local acc = 0
        w:SetScript("OnUpdate", function(_, dt)
            local s = Selftest.watchState
            if not s or not s.inCombat then return end
            acc = acc + dt
            if acc < 1 then return end
            acc = 0
            local n = 0
            for _, b in ipairs(PoolButtons(false)) do if b:IsShown() then n = n + 1 end end
            for _, c in ipairs(BS.dispelCells or {}) do if c:IsShown() then n = n + 1 end end
            if n > s.maxVisible then s.maxVisible = n end
        end)
    end
    for _, ev in ipairs({ "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "ADDON_ACTION_BLOCKED", "ADDON_ACTION_FORBIDDEN" }) do
        w:RegisterEvent(ev)
    end
    self.watchState = { maxVisible = 0, blocked = 0, noted0 = BS.secretNoted }
    BS.Print(L.COMBAT_WATCH_ON_FIGHT_NOW)
end

function Selftest:FinishCombatWatch()
    local s = self.watchState
    self.watchState = nil
    for _, ev in ipairs({ "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "ADDON_ACTION_BLOCKED", "ADDON_ACTION_FORBIDDEN" }) do
        self.watch:UnregisterEvent(ev)
    end
    local R = GoldSentinelTest.Begin("BuffSentinel", BS.version, BuffSentinelDB)
    local locked = BS:Locked()
    if locked then
        R:Check("T76", "C", L.FOREVER_IN_COMBAT_NO_VISIBLE, function()
            return s.maxVisible == 0, L.AT_MOST_VISIBLE .. s.maxVisible
        end)
        R:Check("T126", "J", L.BUTTONS_HIDDEN_AT_COMBAT_START, function()
            return (s.hiddenAtStart or 0) == 0, L.VISIBLE_AT_COMBAT_START .. tostring(s.hiddenAtStart)
        end)
    else
        R:Skip("T76", "C", L.FOREVER_IN_COMBAT_NO_VISIBLE, L.FOREVER_RETAIL_ONLY)
        R:Skip("T126", "J", L.BUTTONS_HIDDEN_AT_COMBAT_START, L.FOREVER_RETAIL_ONLY)
    end
    R:Check("T134", "J", L.COMBAT_WITHOUT_LUA_ERRORS_AND, function()
        local errs = ErrCount() - (s.err0 or ErrCount())
        return errs == 0 and s.blocked == 0, string.format(L.ERRORS_BLOCKED_NOTICE_IN_COMBAT, errs, s.blocked, YN(BS.secretNoted))
    end)
    -- T134 steht als "im Client prüfen" schon im automatischen Lauf – hier nur die Prüfung (kein doppelter Eintrag)
    local text = R:Finish({ sandbox = L.NOT_NEEDED_ONLY_OBSERVED, bsFehler = BS:ErrorSummary(), geheimSimuliert = L.NO, teil = "kampf",
        echteAktionen = Selftest.realActions or 0 })
    text = text .. "\n" .. string.format(L.REAL_ACTIONS_LINE, Selftest.realActions or 0)
    self:ShowReport(text)
    BS.Print(L.COMBAT_REPORT_SAVED_IT_IS)
    BS.Print(L.PLEASE_RELOAD_NOW_THE_TEST)
end
