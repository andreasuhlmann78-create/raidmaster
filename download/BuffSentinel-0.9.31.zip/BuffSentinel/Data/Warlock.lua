-- BuffSentinel - Data/Warlock.lua  (Feldbeschreibung siehe Data/Warrior.lua)

local ADDON, BS = ...
local L = BS.L
BS.ClassData = BS.ClassData or {}

BS.ClassData.WARLOCK = {
    specNames       = { L.AFFLICTION, L.DEMONOLOGY, L.DESTRUCTION },
    specNamesModern = { L.AFFLICTION, L.DEMONOLOGY, L.DESTRUCTION },
    icon = "Interface\\Icons\\Spell_Shadow_RagingScream",
    entries = {
        ----------------------------------------------------------------
        -- Classic-Familie
        ----------------------------------------------------------------
        -- Rüstung: Teufelsrüstung (ab TBC) > Dämonenrüstung > Dämonenhaut; jede zählt
        { key = "armor",      kind = "buff", spell = { 28176, 706, 687 }, auras = { 28176, 706, 687 },
          label = L.ARMOR, alert = L.ARMOR_2 },
        { key = "darkintent", kind = "buff", spell = 80398, min = 4, optional = true },
        -- Vorrat (BS-N1): Seelensplitter knapp (Gegenstand 6265, bis Wrath; ab Cata sind Splitter eine Ressource)
        { key = "shards",     kind = "buff", supply = { item = 6265, low = 3, needSpell = 1120, hint = L.SUPPLY_HINT_SHARDS }, alertOnly = true,
          max = 3, label = L.SUPPLY_SHARDS, alert = L.ALERT_SHARDS, icon = "Interface\\Icons\\INV_Misc_Gem_Amethyst_02" },
        -- Gesundheitsstein fehlt (BS-N1 Punkt 3, Spieldaten shared/wissen/daten/gesundheitssteine.md, Vereinigung aller Zweige):
        -- irgendein "Gesundheitsstein herstellen" gelernt UND kein Gesundheitsstein in den Taschen -> Warnung (auch allein)
        { key = "healthstone", kind = "buff", alertOnly = true, max = 3, iconSpell = 6201, label = L.SUPPLY_HEALTHSTONE,
          alert = L.ALERT_HEALTHSTONE, supply = { low = 1, hint = L.SUPPLY_HINT_HEALTHSTONE,
          anyOf = { 5509, 5510, 5511, 5512, 9421, 19004, 19005, 19006, 19007, 19008, 19009, 19010, 19011, 19012, 19013,
                    22103, 22104, 22105, 36889, 36890, 36891, 36892, 36893, 36894 },
          needAny = { 657, 1049, 5699, 5700, 5702, 6042, 6201, 6202, 6203, 6204, 11729, 11730, 11731, 20018, 23517, 23518,
                      23519, 23520, 23521, 23522, 23813, 23814, 23815, 23816, 23817, 23818, 23819, 23820, 23821, 27230,
                      28023, 34130, 34149, 34150, 47871, 47878, 58890, 58896, 58898 } } },
        -- Dämon fehlt (BS-N1 Punkt 2): Wichtel beschwören (688) gelernt; mit Dämonischer Opferung (18788) nie, bis Cata
        { key = "pet",        kind = "buff", pet = { need = 688, noTalent = 18788 }, alertOnly = true, max = 4,
          iconSpell = 688, label = L.PET_LABEL_WARLOCK, alert = L.ALERT_DEMON },

        -- Procs
        { key = "nightfall",  kind = "proc", spell = 686, procAuras = { 17941 }, specs = { 1 },
          talents = { "Nightfall", "Einbruch der Nacht" }, alert = L.ALERT_SHADOW_BOLT },
        { key = "backlash",   kind = "proc", spell = 686, procAuras = { 34936 }, min = 2, specs = { 3 },
          talents = { "Backlash", "Heimzahlen" }, alert = L.ALERT_SHADOW_BOLT },
        { key = "decimation", kind = "proc", spell = 6353, procAuras = { 63167 }, min = 3, specs = { 2 },
          talents = { "Decimation", "Dezimierung" }, alert = L.ALERT_SOUL_FIRE },
        { key = "moltencore", kind = "proc", spell = 29722, procAuras = { 71165 }, min = 3, specs = { 2 },
          talents = { "Molten Core", "Geschmolzener Kern" }, alert = L.ALERT_SCORCH },
        { key = "shadowburn", kind = "proc", spell = 17877, targetBelow = 20, specs = { 3 }, min = 4 },

        -- Cooldowns
        { key = "deathcoil",  kind = "cd", spell = 6789 },
        { key = "howl",       kind = "cd", spell = 5484 },
        { key = "amplify",    kind = "cd", spell = 18288, specs = { 1 }, max = 2 },
        { key = "haunt",      kind = "cd", spell = 48181, min = 3, specs = { 1 } },
        { key = "feldom",     kind = "cd", spell = 18708, specs = { 2 } },
        { key = "meta",       kind = "cd", spell = 47241, min = 3, specs = { 2 } },
        { key = "conflag",    kind = "cd", spell = 17962, specs = { 3 } },
        { key = "shadowburnc",kind = "cd", spell = 17877, specs = { 3 }, max = 3 },
        { key = "shadowfury", kind = "cd", spell = 30283, min = 2, specs = { 3 } },
        { key = "chaosbolt",  kind = "cd", spell = 50796, min = 3, specs = { 3 } },
        { key = "soulshatter",kind = "cd", spell = 29858, min = 2 },
        { key = "drainhope_f",kind = "cd", spell = "Drain Hope", forever = true, optional = true },

        ----------------------------------------------------------------
        -- Moderne Familie (MoP)
        ----------------------------------------------------------------
        { key = "m_darkintent",kind = "buff", v = "modern", max = 5, spell = 109773, group = true },

        { key = "m_backdraft", kind = "proc", v = "modern", spell = 29722, procAuras = { 117828 }, specs = { 3 } },
        { key = "m_moltencore",kind = "proc", v = "modern", spell = 6353, procAuras = { 122355 }, specs = { 2 } },
        { key = "m_shadowburn",kind = "proc", v = "modern", spell = 17877, targetBelow = 20, specs = { 3 } },
        { key = "m_drainsoul", kind = "proc", v = "modern", spell = 1120, targetBelow = 20, specs = { 1 } },

        { key = "m_dsmisery",  kind = "cd", v = "modern", spell = 113860, specs = { 1 } },
        { key = "m_dsknow",    kind = "cd", v = "modern", spell = 113861, specs = { 2 } },
        { key = "m_dsinstab",  kind = "cd", v = "modern", spell = 113858, specs = { 3 } },
        { key = "m_haunt",     kind = "cd", v = "modern", spell = 48181, specs = { 1 } },
        { key = "m_meta",      kind = "cd", v = "modern", spell = 103958, specs = { 2 } },
        { key = "m_hog",       kind = "cd", v = "modern", spell = 105174, specs = { 2 } },
        { key = "m_conflag",   kind = "cd", v = "modern", spell = 17962, specs = { 3 } },
        { key = "m_chaosbolt", kind = "cd", v = "modern", spell = 116858, specs = { 3 } },
        { key = "m_havoc",     kind = "cd", v = "modern", spell = 80240, specs = { 3 } },
        { key = "m_doomguard", kind = "cd", v = "modern", spell = 18540 },
        { key = "m_unending",  kind = "cd", v = "modern", spell = 104773 },
        { key = "m_coil",      kind = "cd", v = "modern", spell = 6789 },
        { key = "m_shadowfury",kind = "cd", v = "modern", spell = 30283 },
        { key = "m_howl",      kind = "cd", v = "modern", spell = 5484 },
    },
}
