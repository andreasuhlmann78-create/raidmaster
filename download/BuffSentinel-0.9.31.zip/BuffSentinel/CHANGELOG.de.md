# BuffSentinel – Änderungen

## 0.9.31
- **Neu: Tierfutter-Erinnerung für Jäger (WoW Forever)**: „TIERFUTTER KNAPP!“, wenn du weniger als 10 Stück Futter hast, das dein aktueller Begleiter frisst (Fleisch, Fisch, Brot, Käse, Obst, Pilze …). Welches Futter welche Art ist, stammt aus den Spieldaten – die gibt es nur für WoW Forever, darum gibt es die Erinnerung nur dort. Nur ausserhalb des Kampfes, mit Begleiter, im deutschen oder englischen Client; in den Optionen ausschaltbar.
- Neue Datendatei BuffSentinelVorratDaten.lua (Spieldaten, unverändert aus dem GoldSentinel-Prüfsystem).
- Testroutine (nur Entwickler): T225 (Futter, das der Begleiter frisst, alle Taschen, neue und alte Taschen-Schnittstelle, Sprache, ohne Begleiter, nur WoW Forever, neu zählen beim Begleiterwechsel).

## 0.9.30
- **Neu: Inneres Feuer – Aufladungen für Priester** (Classic, WoW Forever, TBC, Wrath): Hat dein Inneres Feuer nur noch 1–4 seiner 20 Aufladungen, zeigt BuffSentinel „INNERES FEUER ERNEUERN!“ mit der Restzahl – ausserhalb des Kampfes, damit du es vor dem Pull erneuerst. Ein Klick wirkt Inneres Feuer. Meldet das Spiel keine Anzahl, erscheint nichts (nichts geraten).
- Testroutine (nur Entwickler): T224 (Aufladungen 1–4, 5+, unbekannt, geschützt, Aura fehlt, Kampf, Daten je Version).

## 0.9.29
- **Neu: Managem-Erinnerung für Magier** (Classic, WoW Forever, TBC, Wrath): „KEIN MANAGEM!“, wenn du einen Managem herbeizaubern kannst, aber keinen in den Taschen hast – jeder Rang zählt. Nummern aus den Spieldaten (wago.tools). Nur ausserhalb des Kampfes, auch allein; in den Optionen ausschaltbar.
- Testroutine (nur Entwickler): T223 (Herbeizaubern-Zauber je Version, alle Managem-Ränge).

## 0.9.28
- **Neu: Gesundheitsstein-Erinnerung für Hexenmeister** (Classic, WoW Forever, TBC, Wrath): „KEIN GESUNDHEITSSTEIN!“, wenn du einen Gesundheitsstein herstellen kannst, aber keinen in den Taschen hast – Steine aller Ränge und Talentstufen zählen. Gegenstands- und Zauber-Nummern stammen aus den Spieldaten (wago.tools). Nur ausserhalb des Kampfes, auch allein; in den Optionen ausschaltbar.
- Testroutine (nur Entwickler): T219 (Herstell-Zauber je Version, Steine aller Ränge und Talentstufen, Anzeige nur bei 0); T208 sucht seine Einträge jetzt über den Namen.

## 0.9.27
- **Neu: Reagenzien-Erinnerung für Gruppenbuffs** (Classic, WoW Forever, TBC, Wrath): Magier (Arkanes Pulver), Priester (Kerzen für Gebet der Seelenstärke), Druiden (Reagenz für Gabe der Wildnis) und Paladine (Symbol der Könige) sehen „REAGENZ KNAPP!“ mit der Anzahl, wenn sie in einer Gruppe sind und weniger als 10 haben (Symbol der Könige: 20). BuffSentinel zählt das Reagenz deines HÖCHSTEN gelernten Rangs – z. B. Heilige Kerze für Rang 1, Hochheilige Kerze ab Rang 2 – so gibt es beim Leveln keinen Fehlalarm. Gegenstands- und Zauber-Nummern stammen aus den Spieldaten (wago.tools).
- **Schamanen:** „KEIN ANKH!“, wenn kein Ankh für Reinkarnation da ist (auch allein).
- Nur ausserhalb des Kampfes, gezählt nur, wenn sich die Taschen ändern; lässt sich in den Optionen ausschalten.
- Testroutine (nur Entwickler): T218 (höchster Rang je Reagenz, nur in der Gruppe, Ankh allein, Daten je Klasse und Version).

## 0.9.26
- **Neu: Zusammenfassung beim Bereitschaftscheck** (alle Spielversionen): Startet ein Bereitschaftscheck, schreibt BuffSentinel EINE Zeile in den Chat mit allem, was gerade fehlt (z. B. „Bereitschaftscheck – es fehlt: Arkane Intelligenz, Munition (150)“), oder „alles bereit“. Wo die Buff-Erinnerungen für die Zone ausgeschaltet sind, kommt keine Zeile (dort wurde nichts geprüft). Lässt sich in den Optionen ausschalten.
- Testroutine (nur Entwickler): T217 (Zeile, „alles bereit“, keine Zeile ohne Auswertung, Schalter).

## 0.9.25
- **Neu: Reparatur-Erinnerung für alle Klassen** (alle Spielversionen): In Hauptstädten, Gasthäusern und Schutzgebieten – dort, wo man reparieren kann – zeigt BuffSentinel „REPARIEREN!“ mit dem Prozentwert deines am stärksten beschädigten Gegenstands, sobald er unter 30 % liegt, und „kaputt“ bei 0 %. Das gilt auch, wenn die Buff-Erinnerungen für Städte und Gasthäuser ausgeschaltet sind. Nur ausserhalb des Kampfes; gelesen nur, wenn sich die Haltbarkeit ändert.
- Lässt sich in den Optionen wie jede andere Erinnerung ausschalten.
- Testroutine (nur Entwickler): T216 (schwächster Gegenstand, geschützte Werte, Orte, Kampf, Zonen-Einstellung).

## 0.9.24
- **Neu: Begleiter-Erinnerung für Jäger und Hexenmeister** (Classic, WoW Forever, TBC, Wrath, Cata): „BEGLEITER FEHLT!“ bzw. „DÄMON FEHLT!“, wenn kein Begleiter da ist, und „tot“, wenn er gestorben ist – nur ausserhalb des Kampfes und erst nach 3 Sekunden, damit nichts aufblinkt, wenn du absteigst, landest oder die Zone wechselst. Kommt er zurück, verschwindet die Erinnerung sofort.
- Hexenmeister mit Dämonischer Opferung bekommen keine Dämon-Erinnerung (der Dämon wird absichtlich geopfert).
- Lässt sich in den Optionen wie jede andere Erinnerung ausschalten.
- Testroutine (nur Entwickler): T209 (Daten je Klasse und Version, Dämonische Opferung, Anzeigeregeln mit 3 Sekunden Schonfrist).

## 0.9.23
- **Neu: Munitions-Erinnerung für Jäger** (Classic, WoW Forever, TBC, Wrath): Mit Bogen, Schusswaffe oder Armbrust zeigt BuffSentinel „MUNITION KNAPP!“ mit der Restmenge, sobald du weniger als 200 Schuss hast, und „leer“, wenn der Munitionsplatz leer ist. Nur ausserhalb des Kampfes und nicht beritten – so füllst du vor dem Pull auf. Wurfwaffen und Zauberstäbe werden nicht beachtet.
- **Neu: Seelensplitter-Erinnerung für Hexenmeister** (Classic bis Wrath): „SPLITTER KNAPP!“ mit der Anzahl, sobald du weniger als 3 Seelensplitter hast (sobald du Seelendieb kennst). Nur ausserhalb des Kampfes.
- Beides wird nur gezählt, wenn sich Taschen oder Ausrüstung ändern, nie in jedem Bild – keine zusätzliche Last im Kampf. Beides lässt sich in den Optionen wie jede andere Erinnerung ausschalten.
- Testroutine (nur Entwickler): T207 (Munition: Waffenarten, leerer Platz, Client ohne Munitionsplatz, Anzeigeregeln), T208 (Seelensplitter und Munition je Spielversion, Zählen beim Taschen-Ereignis); die TU1-Lagen kennen die Vorrats-Regeln.

## 0.9.22
- Gemeinsame Datei GoldSentinelMarkt auf Version 7 gebracht (unveränderte Kopie). Ohne AHSentinel entstehen beim Weitergeben eines Scans jetzt etwa 2,8 MB Zwischenspeicher statt bis zu 7,5 MB (weniger Ruckeln), mit gleichem Ergebnis. Ausschalten von „Marktdaten teilen“ stoppt jetzt auch eine schon geplante Antwort an die Gilde.
- Testroutine (nur Entwickler): T178 prüft zusätzlich, dass eine geplante Antwort an die Gilde nach dem Ausschalten nicht mehr gesendet wird (eigener Schalter und Schalter eines anderen Addons), mit Gegenprobe, dass dieser Weg bei eingeschaltetem Schalter wirklich sendet.

## 0.9.21
- Gemeinsame Datei GoldSentinelMarkt auf Version 3 gebracht (unveränderte Kopie): Der Export für den Uploader hält die letzten 6 Scans statt 2 (höchstens 1,5 MB).
- Testroutine (nur Entwickler): T178 prüft jetzt auch den Fall, dass „Marktdaten teilen“ ausgeschaltet wird, während schon etwas wartet – wartende Nachrichten und ein eingeplantes Lesen werden verworfen, nichts wird gesendet und nichts gelesen (T-MN-S). Die Portionen von TU4 sind kürzer (2 ms statt 4 ms), damit die Grenze von 8 ms je Bild auch mit Speicherbereinigung hält.

## 0.9.20
- **Schamane Waffenverzauberung + Waffen-Totem (WoW-Forever-Hotfix vom 12.11.):** Schamanen können jetzt eigene Waffenverzauberung und Waffen-Totem gleichzeitig haben. BuffSentinel schreibt die Verzauberungs-IDs (Haupt-/Nebenhand) und die aktiven Totems bei jeder Änderung ins Diagnose-Protokoll („WAFFE mh=… oh=… totem=…“), damit die echten Werte im Spiel gemessen werden können. Die Erkennung „Totem-Verzauberung ist nicht dein eigenes Imbue“ ist vorbereitet, bleibt aber aus, bis die Messung vorliegt – nichts wird geraten, die Erinnerung verhält sich wie bisher.
- Ein Proc, dessen Aura schon abgelaufen ist, wird vor dem nächsten Auren-Update nicht mehr als aktiv angezeigt.
- Optionen und Testbericht: Ist „Marktdaten teilen“ in einem anderen GoldSentinel-Addon aus, zeigt BuffSentinel jetzt „an (Netz aus: anderes Addon)“ und einen Hinweis in den Optionen – das gemeinsame Netz läuft nur, wenn es überall an ist.
- Testroutine (nur Entwickler): T205 (Schamane Imbue/Totem Fälle a/b/c, unbekannte ID, Messung), T206 (Gruppenbuff von anderem Spieler zählt als vorhanden), Proc-Lagen „0,5 s Restzeit“ und „abgelaufen“, T180 (Netz aus durch anderes Addon).

## 0.9.19
- Gemeinsame Datei GoldSentinelMarkt auf Version 2 gebracht (unveränderte Kopie): Sie liest einen Vollscan nicht mehr ein zweites Mal, wenn AHSentinel geladen ist (Version 1 konnte das Spiel beim AHSentinel-Vollscan und im Sniper ruckeln lassen), kleinere Sende-Warteschlange, Gilden-Zusammenfassung stündlich, ausverkaufte Items im Export.

## 0.9.18
- Gemeinsame Datei GoldSentinelMarkt v1 auf den aktuellen Stand gebracht (FeedStart/Feed: Addons mit eigenem Vollscan geben ihr Ergebnis weiter, ein Scan wird nie doppelt gelesen). 0.9.17 hatte noch die frühere Kopie.

## 0.9.17
- **Marktdaten-Netz (gemeinsame GoldSentinel-Datei GoldSentinelMarkt v1):** BuffSentinel fragt das Auktionshaus selbst nie ab. Die gemeinsame Datei liest nur mit, wenn ein anderes Addon oder du einen Vollscan im Auktionshaus startest, und teilt tiefste Preise und Mengen (ohne Namen) mit deiner Gilde und dem GoldSentinel-Netz – so bekommen alle GoldSentinel-Nutzer vollständige Marktdaten. Keine Abfrage beim Spieler, Standard an; Schalter „Marktdaten teilen (anonym, nur Preise)“ in den Optionen zum Ausschalten. Alte Clients ohne Auktionshaus-Schnittstelle: still aus.
- Testbericht und Diagnose-Protokoll enthalten eine Zeile „MARKT-NETZ“ (Version, an/aus, mitgelesene Scans, gesendet/empfangen, gespeicherte Items).
- Testroutine (nur Entwickler): T176–T179 (geladen und angemeldet, BuffSentinel läuft ohne die Datei, Schalter aus = kein Lesen/Senden, kein Lua-Fehler ohne Auktionshaus-Schnittstelle).

## 0.9.16
- **Neu: Befehlsliste beim Tippen.** Tippe `/bsen` (oder `/buffsentinel`) in den Chat – über dem Eingabefeld erscheint die Liste ALLER Befehle mit kurzer Beschreibung. Jeder Buchstabe filtert (z. B. `/bsen p` = Protokoll-Befehle), meistbenutzte stehen oben. Klick oder Tab wählt aus, Enter führt den gewählten Befehl aus. Das Chat-Eingabefeld selbst wird nie beschrieben (kein Taint). Ausschalten in den Optionen oder mit `/bsen befehlsliste aus`.
- Liste und Chat-Befehl benutzen ein und dieselbe Befehlstabelle – es kann nichts fehlen; deutsche und englische Befehlswörter gehen in jedem Client. `/bsen hilfe` listet alle Befehle aus dieser Tabelle. Entwickler-Befehle erscheinen nur für den Entwickler.
- Testroutine (nur Entwickler): T170–T175 (jeder Befehl in der Liste, Filtern, Klick wählt/Enter führt aus, Eingabefeld nie beschrieben, Entwickler-Befehle, alle Sprachen); TU4-Portionen jetzt etwa 4 ms je Bild.

## 0.9.15
- „Namen teilen“ (Gilde/Gruppe) ist jetzt der Hauptschalter: Ist er aus, sendet BuffSentinel gar nichts – das Flüster-Netz von GoldSentinelSync schliesst Gilde und Gruppe immer ein. Die Option „Auch über das Flüster-Netz austauschen“ ist ausgegraut, solange „Namen teilen“ aus ist.
- Das Optionsfenster zeigt „an“/„aus“ in der Spielsprache (war immer Deutsch).
- Auf dem Reittier oder im Fahrzeug: ausserhalb des Kampfes keine Buff-Erinnerung.
- Testroutine (nur Entwickler), umfassende Tests TU1–TU8:
  - L (TU1) Lagen: jede Klasse und Skillung × Procs (bereit, ausser Kampf, falsche Haltung/Gestalt, zu wenig Ressource, Abklingzeit, nicht ausgelöst, ohne Kampflog, Stapel), Buffs (fehlt, vorhanden, Reittier, im Kampf, Gruppen- und Waffenbuffs), Abklingzeiten (bereit, läuft, geschützt, offene Welt) und Kontext (tot, Geist, Flug, Fahrzeug, Forever im Kampf) – T200–T204.
  - M (TU2) Abläufe wie ein Spieler: Haltung wechseln, während ein Proc leuchtet, Klick im Kampf, Skillung wechseln, /reload im Kampf, Buff läuft aus → Hupe → nachbuffen → Hupe hört auf, Töne wählen und vorhören – T210–T215.
  - N (TU3) Standardwerte mit Liste aller Felder – T220–T222.
  - O (TU4) Grundregeln mit 1000 Zufallsfällen (fester Startwert 20261113), in Portionen unter 8 ms je Bild – T230–T232.
  - P (TU5) echte Daten (nur lesen): Kann jede eingeschaltete Warnung auslösen? Verletzungen gehen ins Diagnose-Protokoll („GRUNDREGEL VERLETZT …“).
  - Q (TU6) ein Regressionstest für jeden Befund seit Oktober (T158–T162, „Regressionen: n von m vorhanden“).
  - S (TU7) alle Lagen auf Forever, Era und TBC, Sprachen deDE/enUS, Fenster bei Skalierung ≠ 100 % – T251–T255.
  - Der Bericht zeigt je Bereich TU1–TU7 eine Zeile („OK n · FEHLER n · SKIP n“).

## 0.9.14
- **Sync ohne eigenen Chat-Kanal (WoW Forever):** In WoW Forever kommen Addon-Nachrichten in eigenen Chat-Kanälen nie an (Server: NOT_ALLOWED_IN_CHANNEL). BuffSentinel tritt dem Kanal „BuffSentinelSync“ nicht mehr bei und verlässt ihn einmal, falls er noch betreten ist (gibt einen deiner 10 Kanalplätze frei).
- Neue gemeinsame Datei **GoldSentinelSync 2** (unveränderte Kopie): Das Teilen der Namen läuft über Gilde, Gruppe/Raid und das Flüster-Netz der GoldSentinel-Addons, in allen Spielversionen (Era, TBC, Mists, Retail, Forever). Die Kennung „BuffSentinel“ bleibt, ältere BuffSentinel-Versionen anderer Spieler werden weiter verstanden. Keine eigene Sende-Warteschlange und kein eigener Takt mehr.
- Was ins Flüster-Netz geht (Option „Auch über das Flüster-Netz austauschen“): gelernte Zuordnungen von Talent- und Zaubernamen, Fragen nach fehlenden Namen und ihre Antworten (höchstens 10 Fragen auf einmal) sowie automatisch gelernte Procs/Fähigkeiten. Nur Gilde/Gruppe (nie ins Netz): der Austausch der ganzen Liste beim Einloggen und wenn die Gruppe wächst („R“).
- Namen anderer Spieler aus dem Netz erscheinen nie im Chat; bei Nachrichten aus Gilde oder Gruppe steht der Absender wie bisher.
- Neuer Befehl `/bsen sync test`: wer nutzt sonst BuffSentinel (Antworten aus Gilde, Gruppe, Flüster-Netz). Die Optionen zeigen, wie viele Spieler mit BuffSentinel in der letzten Stunde gesehen wurden.
- Diagnose-Protokoll: Sync-Weg einmal je Sitzung, alle 10 Minuten „gesendet / empfangen / verworfen“ und die Zeilen von GoldSentinelSync (mit „NETZ“, ohne Namen).
- **GoldSentinelTest 2:** Fehlerberichte an den Entwickler teilen (nur mit Zustimmung, /gstest).
- GoldSentinelGame 3 (gemeinsame Datei, nur Kommentare).
- Testroutine (nur Entwickler): neue Fälle T150–T157 (Senden nie über einen Kanal, Empfang mit unbekanntem Absender und alten Nachrichten, kein Kanal-Beitritt, /bsen sync test, Versionen der gemeinsamen Dateien, Flüster-Netz-Speicher und net=false, Diagnose ohne Namen, Fehlerberichte nur mit Zustimmung).

## 0.9.13
- Die Anzeigeflächen (Buffs, Procs, Abklingzeiten, Reinigen) stehen anderen GoldSentinel-Addons nicht mehr im Weg: Frei schwebende Anzeigen kommen nicht mehr in die gemeinsame Fensterliste, die Oberflächen-Prüfungen von ThreatSentinel und AHSentinel melden ihre Fenster deshalb nicht mehr als „überdeckt BuffSentinelAnchor_…“.
- Leere Anzeigeflächen (kein Symbol) werden ausserhalb des Verschieben-Modus auf 1 × 1 verkleinert, statt unsichtbar 340 Pixel breit auf dem Bildschirm zu liegen; im Verschieben-Modus und sobald sie Inhalt haben, bekommen sie ihre volle Grösse zurück.
- Testroutine (nur Entwickler): neuer Fall T149.

## 0.9.12
- Englische Clients: Lange Warnungen auf den Buttons (z. B. „CLEARCASTING!“) werden jetzt an der Wortfuge getrennt („CLEAR-“ / „CASTING!“), statt nur die Schrift zu verkleinern. Deutsche Clients trennen wie bisher an deutschen Wortteilen („BLITZSCHLAG-“ / „SCHILD!“).
- Testroutine (nur Entwickler): neuer Fall T148 prüft die Trennung in beiden Sprachen.

## 0.9.11
- Neues Diagnose-Protokoll (aus der GoldSentinel-Vorlage, neue Datei `Diag.lua`): BuffSentinel schreibt Fehler, verweigerten Aurenzugriff in WoW Forever/Retail und langsame Anzeige-Aktualisierungen (länger als ein Frame) mit. Gleiche Einträge hintereinander werden nur gezählt (×N). `/bsen protokoll` zeigt das Protokoll zum Kopieren. Beim Ausloggen bzw. `/reload` wird es als `BuffSentinelDB.diagExport` (beginnt mit GSDIAG1) abgelegt, damit der RaidMaster-Uploader es an die Testberichte von GoldSentinel schicken kann; `/bsen protokoll aus` schaltet das ab, `/bsen protokoll an` wieder ein. Das Protokoll enthält keine Spieler-, Charakter-, Gilden- oder Realmnamen.
- `/bsen hilfe` nennt den neuen Befehl.
- Testroutine (nur Entwickler): neuer Fall T146 (Einträge, Zähler statt Schleife, Export GSDIAG1, keine Namen) und Client-Fall T147.

## 0.9.10
- Tooltips im Optionsfenster, im Gruppen-Raster, in der Reinigungsleiste und beim PayPal-Knopf erscheinen jetzt neben dem Fenster statt darüber und verdecken so keine anderen Knöpfe mehr.
- Testroutine (nur Entwickler): neuer Bereich K „oberflaeche“ prüft die Oberfläche im echten Client (aus der GoldSentinel-Vorlage, neue Datei `UICheck.lua`): eigene Tooltips verdecken keine Knöpfe (T140), kein Überlappen mit Blizzard- oder anderen GoldSentinel-Fenstern (T141, frei schwebende Anzeigen ausgenommen), Fenster ganz im Bildschirm (T142), Knopf-Beschriftungen nicht abgeschnitten (T143), angezeigte Spielwerte plausibel – Stufe, Klasse, Spielversion, Talentpunkte, Zeilen im Gruppen-Raster, eigene Buffs (T144), keine Fehlerschleife mit derselben Meldung über 10× (T145). Ohne echten Client werden T140–T143 übersprungen, nie als OK gezählt. Bereich K läuft zuerst, bevor andere Bereiche Testwerte setzen. Nur lesen, nichts wird verändert.

## 0.9.9
- WoW Forever: neu gelernte Zauber werden wieder ohne `/reload` erkannt. Das Ereignis LEARNED_SPELL_IN_TAB gibt es in Forever nicht; BuffSentinel hört jetzt zusätzlich auf LEARNED_SPELL_IN_SKILL_LINE und meldet nur Ereignisse an, die der Client kennt (C_EventUtils.IsEventValid, wo vorhanden).
- Testroutine (nur Entwickler): T29 lässt Ereignisse zu, die der Client nicht kennt, und prüft, dass neu gelernte Zauber immer erkannt werden; der Kampf-Bericht schreibt „echte Aktionen: im Kampf-Teil nicht gezählt“ statt eines alten Werts aus dem letzten automatischen Lauf.

## 0.9.8
- **WoW Forever / Retail – behebt Lua-Fehler aus den Testberichten** („GetAuraDataByIndex(): Auras cannot be accessed when secret while tainted by 'BuffSentinel'“, bei UNIT_AURA und direkt nach dem Kampf). BuffSentinel liest Auren jetzt nur noch, wenn das Spiel es erlaubt: nicht im Kampf, nicht im ersten Moment nach dem Kampf (stattdessen eine halbe Sekunde später), nicht bei Gruppenmitgliedern oder Zielen, die selbst kämpfen, und nicht, solange das Spiel geschützte Auren meldet. Verweigert das Spiel den Zugriff trotzdem, wird der Aufruf abgefangen, die letzten bekannten Werte bleiben (keine falschen „Buff fehlt“-Warnungen) und das Lesen pausiert 2 Sekunden – kein Lua-Fehler.
- Alte Clients (Classic Era, TBC, Wrath, Cata, MoP) unverändert.
- Testroutine (nur Entwickler): neuer Fall T139 stellt den verweigerten Zugriff, das verzögerte Lesen nach dem Kampf, ein kämpfendes Gruppenmitglied und geschützte Auren nach.

## 0.9.7
- **Sprachen:** BuffSentinel richtet sich jetzt nach der Sprache des Spiel-Clients (für alle Spieler). Englisch ist der Standard, Deutsch vollständig übersetzt; alle anderen Sprachen zeigen vorerst Englisch. Alle Texte stehen in der neuen Datei `Locales.lua`: Chat-Meldungen, Optionen, Gruppen-Raster, Tooltips, Minimap-Button, Testleiste, Anordnen-Leiste, Warnungen auf den Buttons (z. B. „FREIZAUBER!“ / „CLEARCASTING!“), Skillungs- und Tonnamen sowie der Bericht der Testroutine. Zauber- und Talentnamen kommen wie bisher aus dem Spiel.
- Neuer Befehl `/bsen help` (auch `/bsen hilfe`) mit allen Befehlen; englische Kurzformen `/bsen move`, `/bsen errors`, `/bsen donate` funktionieren in jeder Sprache.
- Beschreibung in der Addon-Liste auf Englisch, im deutschen Client auf Deutsch.
- Testroutine (nur Entwickler): Sprachtests im Bereich F (jeder englische Text hat einen deutschen, Platzhalter stimmen überein, Hilfe unter einem englischen Client ohne Deutsch – T98, T137, T138); Endzählung „echte Aktionen: 0“ mit neuem Fall T136 (Senden, Chat und Kanal betreten werden nur mitgezählt, nie ausgelöst); die Bitte um `/reload` kommt nach jedem Lauf; T134 steht im Kampf-Bericht nur noch einmal.

## 0.9.6
- WoW Forever: Die Seiten Procs und Cooldowns zeigen jetzt denselben klaren Hinweis wie die übrigen Seiten – im Kampf keine Anzeige von Procs, Cooldowns und Buffs, Reinigen-Raster aus, Procs werden nicht automatisch gelernt. Die Zeile „lernt neue Procs automatisch“ erscheint in Forever nicht mehr. (Wie bisher zeigt BuffSentinel in Forever im Kampf nichts an; Buff-Erinnerungen kommen vor dem Pull und ausserhalb des Kampfes.)
- Beschädigte gespeicherte Einstellungen (falsche Werte, unvollständige Positionen) werden beim Laden repariert statt Lua-Fehler auszulösen.
- Forever/Retail: Tooltips von Gruppen-Raster, Buttons und Reinigungsleiste verketten keine geschützten Spielernamen mehr (kein Lua-Fehler im Kampf); Addon-Nachrichten und Kanal-Meldungen mit geschützten Werten werden ignoriert.
- Automatisches Lernen baut die Anzeige nicht mehr mitten im Einlesen der Auren neu auf.
- Fehler (auch beim Einlesen, auf den Optionsseiten und beim Namen-Teilen) werden gezählt, in `/bsen fehler` gezeigt und über die gemeinsame Datei `GoldSentinelTest.lua` (unverändert übernommen) an die Testberichte von GoldSentinel gemeldet. `/bsen fehler` zeigt zusätzlich die Zahl offener Berichte.
- Nur für den Entwickler: Testroutine `/bsen testroutine [bereich|kampf]`, `/bsen selbsttest` (simuliert WoW Forever über `GoldSentinelGame.SetTestFlavor`) und Knopf „Alles testen“. Sie sendet nichts, betritt keinen Kanal, wirkt keinen Zauber und lässt deine gespeicherten Einstellungen unverändert.

## 0.9.5
- Fehler in Event-Handlern werden jetzt mitgezählt und erscheinen in `/bsen fehler` (im Chat weiterhin nur der erste).
- Forever/Retail: Kann BuffSentinel die Buttons vor dem Kampf nicht mehr verstecken (Kampfsperre schon aktiv), holt es das direkt nach dem Kampf nach.
- WoW Forever – klar benannt, auch in den Optionen und auf der Seite „Reinigen“: im Kampf keine Anzeige von Procs, Cooldowns und Buffs (geheime Werte), das Reinigen-Raster ist aus (auch ausserhalb des Kampfes), Procs werden nicht automatisch gelernt. Buff-Erinnerungen kommen vor dem Pull und ausserhalb des Kampfes.

## 0.9.4
- `GoldSentinelGame.lua` auf Version 2: setzt sich gegen frühe, zurückgenommene Fassungen durch, die andere GoldSentinel-Addons evtl. noch mitbringen – keine Lua-Fehler, wenn mehrere Addons gleichzeitig geladen sind.

## 0.9.3
- Versionserkennung über die gemeinsame Datei `GoldSentinelGame.lua` aller GoldSentinel-Addons (unverändert übernommen, in der .toc direkt nach `GoldSentinelDev.lua`). WoW Forever wird auch über die Projekt-ID des Spiels erkannt, falls sich die Interface-Nummer zum Launch ändert.
- Die Sperren für den modernen Client hängen jetzt an `GoldSentinelGame.IsModern` (Forever, Retail oder ein Client mit geheimen Werten). Classic Era, TBC, Wrath, Cata und MoP Classic laufen unverändert.
- Gruppennamen laufen über `GoldSentinelGame.Short` (geheime Namen werden nie gespeichert).
- `/gsgame` zeigt die erkannte Spielversion; `/bsen fehler` zeigt dieselbe Zeile zusätzlich zur Fehler-Diagnose.

## 0.9.1 – WoW Forever fest gemacht
- WoW Forever läuft auf dem modernen Client mit denselben Addon-Sperren wie Retail (kein Kampflog, im Kampf „geheime Werte“). BuffSentinel behandelt Forever jetzt genauso: Buff-Erinnerungen vor dem Pull, im Kampf keine Auswertung von Auren, Abklingzeiten, Lebenspunkten und Namen – einmaliger Hinweis im Chat (für Procs im Kampf den Cooldown Manager des Spiels nutzen). Die Weiche prüft, ob das Spiel geheime Werte kennt; Classic Era, TBC, Wrath, Cata und MoP Classic laufen unverändert.
- Kampflog wird auf Forever und Retail nicht mehr registriert; Überwältigen, Rache und Riposte werden dort über „Fähigkeit nutzbar“ erkannt.
- Geheime Werte werden überall geprüft, bevor gerechnet oder verglichen wird: eigene Auren (Stapel, Ablauf, Zauber-ID), Ziel-Lebenspunkte (Hinrichten), Gruppennamen, Debuff-Arten beim Reinigen, Abklingzeiten. Geheime Abklingzeiten gelten nicht mehr als „bereit“ – kein falsches Aufleuchten mit Ton beim Pull.
- Forever/Retail: Vor dem Kampf werden alle Klick-Buttons versteckt, damit keine unsichtbaren Buttons im Kampf Klicks abfangen.
- Fehler frieren die Anzeige nicht mehr ein: jeder Button wird einzeln abgesichert, Fehler werden gezählt. Neuer Befehl `/bsen fehler` zeigt die Diagnose.

## 0.9.0
- Neuer Reiter „Optionen“ (ersetzt „Zonen & Anzeige“) mit allen Einstellungen an einem Ort: Warntöne, Zonen, Cooldowns & Reinigen, automatisches Lernen, Anzeige & Anordnen, Grössen, Minimap, Namen teilen.
- Warntöne frei wählbar, für jede Art einzeln (Hupe bei ausgelaufenem eigenem Buff, Gruppen-Buff fehlt, Proc, Cooldown bereit, Debuff zum Reinigen, wichtiger Raid-Debuff, Klingel):
  - Ein/Aus und Ton pro Klasse und Skillung (wechselt mit der Skillung), mit „für alle Skillungen übernehmen“ und „Skillung auf Standard“.
  - Grosse Auswahl: rund 50 Töne aus dem Spiel (nur die, die es in deiner WoW-Version gibt), Glocken, Gong, Kriegstrommel und weitere Effekte, alle Töne aus LibSharedMedia anderer Addons und eigene Dateien bzw. Sound-IDs.
  - Auswahlfenster mit Anhören (Rechtsklick nur anhören), Knopf „Anhören“ in jeder Zeile.
  - Tonkanal wählbar (Gesamt, Effekte, Dialog, Umgebung, Musik) und Abstand der Hupe 3–60 s.
- Bisherige Ton-Einstellungen werden übernommen.

## 0.8.6
- Schlachtruf hupt jetzt wie alle eigenen Buffs, bis er erneuert ist (keine Klingel mehr als Standard; die Klingel lässt sich pro Eintrag weiter einschalten).
- Druide Wilder Kampf: Der Freizauber-Button wirkt je nach Gestalt Schreddern (Katze) oder Zermalmen (Bär) und erscheint in beiden Gestalten. Die Zuordnung passt sich an, auch wenn noch nicht alle Gestalten gelernt sind.

## 0.8.5
- Läuft ein eigener Buff aus (Rüstung, Schild, Waffenverzauberung, Gift …), hupt BuffSentinel alle 5 Sekunden, bis er erneuert ist (abschaltbar, Abstand 5/10/15/30 s). Einträge mit Klingel wie Schlachtruf klingeln stattdessen.
- Procs erscheinen nur noch, wenn sie in deiner aktuellen Haltung bzw. Gestalt möglich sind (z. B. Überwältigen nur in Kampfhaltung, Schreddern nur in Katzengestalt). Fehlt nur Wut/Mana/Energie, bleibt der Proc blau getönt sichtbar.

## 0.8.4
- Töne sind standardmässig aus (auch in bestehenden Profilen einmalig ausgeschaltet; danach gilt deine eigene Wahl).
- Neu: eigene Klingel pro Eintrag (Knopf „Ton“ auf den Seiten Procs, Buffs und Cooldowns). Sie klingelt auch, wenn die allgemeinen Töne aus sind. Standardmässig hat nur Schlachtruf eine Klingel.
- „Sounds testen“ spielt auch die Klingel.

## 0.8.3
- Der Testmodus mit allen Klassen und Skillungen ist jetzt ein Entwickler-Werkzeug (GoldSentinelDev). Für alle anderen öffnen Testmodus-Aufrufe (`/bsen test`, Shift + Linksklick auf den Minimap-Button) das Anordnen.
- „Sounds testen“ gibt es jetzt in der Anordnen-Leiste.

## 0.8.2
- Neu: Knopf „Anordnen“ oben im Einstellungsfenster (auch Strg + Linksklick auf den Minimap-Button oder `/bsen anordnen`). Zeigt wie im Testmodus alle deine eigenen Buttons zum Verschieben, dazu eine Leiste mit Grösse, Abstand und Richtung (waagrecht/senkrecht) für jede Gruppe.
- Fensterpositionen werden gespeichert (Einstellungen, Gruppen-Raster, Test- und Anordnen-Leiste). „Alle Positionen zurücksetzen“ setzt auch die Fenster zurück.

## 0.8.1
- Neu: Grösse pro Gruppe einstellbar – Procs, Buffs, Cooldowns und Reinigen je 50–200 %, zusätzlich zur Gesamtgrösse (Seite „Zonen & Anzeige“). Die Gruppen und frei platzierten Buttons bleiben beim Ändern an ihrer Stelle.
- Neuer Knopf „Grössen zurücksetzen“.

## 0.8.0
- Neu: **Automatisches Lernen.** Trifft BuffSentinel auf Procs oder Fähigkeiten, die noch nicht in seinen Daten stehen (z. B. Neuheiten in WoW Forever), nimmt es sie selbst auf:
  - Procs: Ein kurzer Buff, den du dir im Kampf selbst gibst und der dreimal beim Wirken desselben Zaubers verbraucht wird, bekommt einen Proc-Button für diesen Zauber. Buffs, die nur auslaufen (Waffen-Verzauberungen, Schmuckstücke), und Buffs von anderen Spielern werden nicht aufgenommen.
  - Fähigkeiten: Klassenzauber mit mindestens 10 s Abklingzeit kommen in die Cooldown-Leiste, sobald du sie wirkst oder neu erlernst (Lehrer, Talentpunkt).
  - Gelerntes merkt sich BuffSentinel pro Skillung und für alle Charaktere des Accounts.
  - Entdeckungen werden mit anderen BuffSentinel-Nutzern geteilt (nur Zauber-IDs, abschaltbar).
  - Übersicht, Entfernen und Ein/Aus auf der Seite „Aufnahme“.
- Noch nicht erlernte Zauber (grau im Zauberbuch von Cata/MoP) und Zauber anderer Spezialisierungen gelten nicht mehr als gelernt.

## 0.7.3
- Lange zusammengesetzte Wörter werden an der Wortfuge auf zwei Zeilen getrennt (z. B. „BLITZSCHLAG-“ / „SCHILD!“), statt die Schrift zu verkleinern. Kleiner wird sie nur, wenn das nicht reicht.
- Umlaute werden in Warnungen jetzt richtig gross geschrieben („SEELENSTÄRKE“ statt „SEELENSTäRKE“).

## 0.7.2
- Priester: Woge des Lichts wirkt in TBC Göttliche Pein (Blitzheilung erst ab WotLK).
- Jäger: Fass! ist in TBC eine Grundfähigkeit – jetzt bei allen Skillungen.
- Krieger: Befehlsruf ab TBC; neue Buff-Erinnerung für Toben (TBC, Furor).
- Procs über einen Buff heissen nach ihrer Quelle (z. B. „SCHATTENTRANCE!“), darunter steht der Zauber, den der Klick wirkt.
- Lange Beschriftungen werden automatisch kleiner statt abgeschnitten.
- Reinigungsleiste sitzt jetzt links unter den Buffs, die Titel von Cooldowns und Reinigen stehen über ihrer Fläche – keine Überlappungen mehr.

## 0.7.1
- Behoben: Hauptbaum wird richtig erkannt (z. B. 14/41/0 = Furor statt Waffen), auch mit Zweitskillung – die aktive Talentgruppe wird ausdrücklich gelesen.
- Behoben: Talente und Procs werden nach WoW-Version gefiltert. WoW-Forever-Talente (Bloodthrill, Vanguard) und WotLK-Procs (Plötzlicher Tod, Schäumendes Blut, Schwert und Schild, Hot Streak) erscheinen nicht mehr in TBC/Classic Era.
- Behoben: Der Testmodus zeigt Talent-Procs nur für die gewählte Skillung (z. B. Hot Streak nur Feuer, Anmut der Natur nur Gleichgewicht).
- Die Listen in den Einstellungen springen beim Abhaken nicht mehr; neuer Knopf „Auto“ setzt einen Eintrag auf die automatische Auswahl zurück.
- Fehlende Schriftzeichen (Pfeil, Häkchen) und ein veralteter Hinweistext behoben.
- Testmodus-Layout: zweizeilige Beschriftungen, Gruppentitel neben der Fläche, Flächen wachsen mit der Anzahl Buttons, Testleiste ganz oben, Einstellungsfenster schliesst sich beim Start, Reinigungsleiste mit 5 Beispielplätzen und ausgeblendet bei Klassen ohne Reinigen.
- Hexenmeister-Procs heissen nach ihrer Quelle (Schattentrance, Heimzahlen).
- Server-Sync versucht den Kanalbeitritt mehrmals und zeigt einen klaren Status.
- Behoben: Tooltip blieb nach dem Öffnen des Spendenfensters stehen.

## 0.7.0
- Neuer Knopf „Unterstützen“ (PayPal) oben im Einstellungsfenster und auf der Seite „Zonen & Anzeige“, auch per `/bsen spenden`. Öffnet sich nur auf Klick – kein Aufpoppen, keine Chat-Meldungen.

## 0.6.3
- Mindestens 3 Sekunden zwischen Warntönen, derselbe Ton höchstens alle 4 Sekunden.
- „Sounds testen“ spielt alle Töne mit 3 Sekunden Abstand und zeigt an, welcher läuft.

## 0.6.1
- WoW Forever: neue Paladin- (Siegel der Wut, Lichtwacht, Stimme der Wahrheit, Schnelles Richturteil, Bollwerk des Templers, Lichtenergie) und Schamanen-Fähigkeiten (Wut des Weitsehers, Feuernova, Totemprojektion).
- Testmodus in Classic Era zeigt nur die Klassen deiner Fraktion.

## 0.6.0
- Testmodus mit Beispielanzeige für alle Klassen und Skillungen; Buttons frei platzierbar.

## 0.5.0
- Reinigungsleiste für Mitspieler und Entzaubern von Gegnern.

## 0.4.0
- Erste Version: Proc-Buttons, Buff-Wächter mit Ein-Klick-Buff, Cooldown-Leiste, Skillungserkennung, alle WoW-Versionen.
