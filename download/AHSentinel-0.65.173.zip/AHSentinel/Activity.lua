if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Activity.lua
-- Rendite je Geschäftsart (H7) und Gold pro Stunde (H9), Anweisung "Handel nach Regelwerk" 9. Nov. 16:00.
--
-- Zeit (nur lokal, ohne Namen), je Tätigkeit:
--   ah    AH-Arbeit: nur AKTIVE Zeit bei offenem Auktionshaus. Aktiv = Zeit zwischen eigenen Handlungen (Klick im
--         Spiel bzw. in AHSentinel, Mausrad-Kauf). Zwischen zwei Handlungen zählen höchstens 2 Min.; nach der letzten
--         Handlung höchstens 2 Min. bis zum Schliessen. Automatische Scans/Sniper-/Wächter-Läufe zählen nicht.
--   mail  Briefkasten, gleiche Regel; wird beim Anzeigen nach dem Erlös auf die Geschäftsarten verteilt.
--   craft Herstellen: vom ersten bis zum letzten Herstellen einer Serie (Pausen über 2 Min. zählen nicht).
--   de    Entzaubern: zwischen Entzauberungen einer Serie (Pausen über 2 Min. zählen nicht).
--   AFK-Markierung stoppt jede Messung sofort; die Zeit seit der letzten Handlung zählt dann nicht.
--
-- Geschäftsarten (H7): Flippen (Kauf und Verkauf desselben Items), Herstellen (Verkauf hergestellter Items gegen
-- Materialkosten), Entzaubern (Abrechnung Le:DisenchantReport), Rohstoffe (Verkauf ohne Kauf). Ein Verkauf zählt
-- zum Geschäft, aus dem das Item stammt, und zu dessen Zeitpunkt (Herstellen bzw. Kauf), nicht zum Eingang der Post.
-- ============================================================
local A = AHAnalyzerPro
local L = A.L

local Act = {}
A.Activity = Act

Act.GAP = 120                 -- Pause ohne Handlung: höchstens 2 Min. zählen
Act.MIN_SECONDS = 15 * 60     -- darunter "zu wenig Daten"
Act.KEEP_DAYS = 120
Act.TAIL = { ah = true, mail = true }   -- nach der letzten Handlung bis 2 Min. (beim Schliessen)
Act.Clock = function() return time() end
Act.sessions = {}             -- [kind] = { last = Zeitpunkt der letzten Handlung }

local function DB()
    if not A.db then return nil end
    local d = A.db.activity
    if type(d) ~= "table" then d = { days = {}, crafts = {} }; A.db.activity = d end
    d.days = d.days or {}
    d.crafts = d.crafts or {}
    return d
end
Act.DB = DB

-- Tagesbeginn ohne time(tabelle) (Befund 20:15, A1): immer eine Zahl, auch für 0/nil
local function DayKey(t)
    return A:DayStart(t)
end
Act.DayKey = DayKey

-- Sekunden einer Tätigkeit dem Tag des Zeitpunkts t gutschreiben
function Act:Add(kind, sec, t)
    if not (sec and sec > 0) then return end
    local d = DB()
    if not d then return end
    local dk = DayKey(t or self.Clock())
    local day = d.days[dk]
    if not day then day = {}; d.days[dk] = day end
    day[kind] = (day[kind] or 0) + sec
end

-- eigene Handlung: Zeit seit der letzten Handlung (höchstens GAP) zählen
function Act:Touch(kind, now)
    now = now or self.Clock()
    if self.afk then return end
    local s = self.sessions[kind]
    if s and s.last then
        local gap = now - s.last
        -- AH/Briefkasten: höchstens 2 Min. nach der letzten Handlung; Herstellen/Entzaubern: Pause über 2 Min. gar nicht
        if gap > 0 and (gap <= self.GAP or self.TAIL[kind]) then self:Add(kind, math.min(gap, self.GAP), now) end
    end
    self.sessions[kind] = { last = now }
end

-- Tätigkeit endet (AH/Briefkasten zu): nach der letzten Handlung höchstens GAP dazu (nicht bei AFK)
function Act:Stop(kind, now, noTail)
    now = now or self.Clock()
    local s = self.sessions[kind]
    self.sessions[kind] = nil
    if not (s and s.last) or noTail or self.afk or not self.TAIL[kind] then return end
    local gap = now - s.last
    if gap > 0 then self:Add(kind, math.min(gap, self.GAP), now) end
end

-- AFK: alle Messungen sofort stoppen (ohne Nachlauf); zurück: erst die nächste Handlung startet neu
function Act:SetAFK(afk, now)
    if afk and not self.afk then
        for k in pairs(self.sessions) do self.sessions[k] = nil end
    end
    self.afk = afk and true or nil
end

-- Zeit je Tätigkeit seit from (Tagesgenau)
function Act:Seconds(from)
    local d = DB()
    local out = { ah = 0, mail = 0, craft = 0, de = 0 }
    if not d then return out end
    local fromDay = DayKey(from or 0)
    for dk, day in pairs(d.days) do
        if dk >= fromDay then
            for k, v in pairs(day) do out[k] = (out[k] or 0) + v end
        end
    end
    return out
end

-- EB7 (Handel pro Stunde): eingeloggte Zeit je Tag, ohne AFK (Kennzeichen des Spiels) - jede Minute
Act.ONLINE_STEP = 60
function Act:OnlineTick()
    if self.afk or (A.Simulated and A:Simulated()) or (A.TestRoutine and A.TestRoutine.running) then return end
    self:Add("online", self.ONLINE_STEP)
end
if C_Timer and C_Timer.NewTicker then
    A:On("READY", function() C_Timer.NewTicker(Act.ONLINE_STEP, function() pcall(Act.OnlineTick, Act) end) end)
end

function Act:Prune()
    local d = DB()
    if not d then return end
    local limit = DayKey(self.Clock() - self.KEEP_DAYS * 86400)
    for dk in pairs(d.days) do if dk < limit then d.days[dk] = nil end end
    while #d.crafts > 1000 do table.remove(d.crafts, 1) end
end

-- ------------------------------------------------------------
-- Herstellen merken: { t, itemID, cost (je Stück, wenn bekannt) }
-- ------------------------------------------------------------
function Act:NoteCraft(itemID, cost, t)
    local d = DB()
    if not (d and itemID) then return end
    d.crafts[#d.crafts + 1] = { t = t or self.Clock(), itemID = itemID, cost = cost }
end

local function LastBefore(list, t)
    local best
    for _, e in ipairs(list) do
        if e.t <= t and (not best or e.t > best.t) then best = e end
    end
    return best
end

-- ------------------------------------------------------------
-- H7: Rendite je Geschäftsart im Zeitraum ab from
-- Rückgabe: rows = { flip, craft, de, raw } je { invested, revenue, profit, roi, gross }, total
-- ------------------------------------------------------------
Act.KINDS = { "flip", "craft", "de", "raw" }
function Act:Business(from)
    from = from or 0
    local Le = A.Ledger
    local db = A.db and A.db.ledger
    local rows = {}
    for _, k in ipairs(self.KINDS) do rows[k] = { kind = k, invested = 0, revenue = 0, profit = 0, gross = 0 } end
    if not (Le and db) then return rows end
    local d = DB() or { crafts = {} }
    -- Material aus Entzauberungen: sein Verkauf ist schon im Materialwert der Abrechnung enthalten
    local deMat = {}
    for _, e in ipairs(A.db.deLog or {}) do
        for _, m in ipairs(e.loot or {}) do if m[1] then deMat[m[1]] = true end end
    end
    local byItem = {}
    for _, e in ipairs(db.entries or {}) do
        if e.itemID and (e.kind == "buy" or e.kind == "sale" or e.kind == "deposit" or e.kind == "refund") then
            local b = byItem[e.itemID]
            if not b then b = { buys = {}, sales = {}, deps = {}, crafts = {} }; byItem[e.itemID] = b end
            if e.kind == "buy" then b.buys[#b.buys + 1] = e
            elseif e.kind == "sale" then b.sales[#b.sales + 1] = e
            else b.deps[#b.deps + 1] = e end
        end
    end
    for _, c in ipairs(d.crafts) do
        local b = byItem[c.itemID]
        if b then b.crafts[#b.crafts + 1] = c end
    end
    local Se = A.Seller
    for itemID, b in pairs(byItem) do
        for _, s in ipairs(b.sales) do
            local st = Le.SaleTime and Le:SaleTime(s) or s.t
            local craft = LastBefore(b.crafts, st)
            local buy = LastBefore(b.buys, st)
            local kind, when, unitCost
            if craft and (not buy or craft.t >= buy.t) then
                kind, when = "craft", craft.t
                unitCost = craft.cost
                if not unitCost and Se and Se.CostPerPiece then
                    local ok, c = pcall(Se.CostPerPiece, Se, itemID)
                    unitCost = ok and c or nil
                end
            elseif buy then
                kind, when = "flip", buy.t
                local qty, cost = 0, 0
                for _, x in ipairs(b.buys) do
                    if x.t <= st and st - x.t <= 30 * 86400 then qty = qty + (x.qty or 0); cost = cost + (x.amount or 0) end
                end
                unitCost = qty > 0 and cost / qty or nil
            elseif deMat[itemID] then
                kind = nil
            else
                kind, when = "raw", st
            end
            if kind and when >= from then
                local r = rows[kind]
                local net = (s.amount or 0) - (s.cut or 0)
                local cost = math.floor((unitCost or 0) * (s.qty or 1) + 0.5)
                r.revenue = r.revenue + net
                r.gross = r.gross + (s.amount or 0)
                r.invested = r.invested + cost
            end
        end
        -- verlorene Einzahlungen (Einzahlungen ohne Erstattung) dem Geschäft des Items zuordnen
        local kindOf = (#b.crafts > 0 and "craft") or (#b.buys > 0 and #b.sales > 0 and "flip") or (not deMat[itemID] and "raw") or nil
        if kindOf then
            local fee = 0
            for _, x in ipairs(b.deps) do
                if x.t >= from then fee = fee + (x.kind == "deposit" and (x.amount or 0) or -(x.amount or 0)) end
            end
            for _, s in ipairs(b.sales) do if s.t >= from then fee = fee - (s.refund or 0) end end
            if fee > 0 then rows[kindOf].invested = rows[kindOf].invested + fee end
        end
    end
    -- Entzaubern: vorhandene Abrechnung
    local key = self.periodKey
    if Le.DisenchantReport then
        local ok, _, t = pcall(Le.DisenchantReport, Le, key)
        if ok and t then
            rows.de.invested = t.spent or 0
            rows.de.revenue = (t.value or 0) + (t.ownValue or 0)
            rows.de.gross = rows.de.revenue
        end
    end
    local total = { kind = "total", invested = 0, revenue = 0, profit = 0, gross = 0 }
    for _, k in ipairs(self.KINDS) do
        local r = rows[k]
        r.profit = r.revenue - r.invested
        r.roi = r.invested > 0 and (r.profit / r.invested * 100) or nil
        total.invested, total.revenue, total.gross = total.invested + r.invested, total.revenue + r.revenue, total.gross + r.gross
    end
    total.profit = total.revenue - total.invested
    total.roi = total.invested > 0 and (total.profit / total.invested * 100) or nil
    return rows, total
end

-- ------------------------------------------------------------
-- H9: Gold pro Stunde je Geschäftsart. Zeit: Herstellen = craft, Entzaubern = de; AH-Arbeit und Briefkasten werden
-- nach dem Brutto-Erlös auf Flippen, Herstellen und Rohstoffe verteilt (ohne Erlös: alles zu Flippen/Rohstoffe gleich).
-- ------------------------------------------------------------
function Act:Report(periodKey)
    local Le = A.Ledger
    self.periodKey = periodKey
    local from = (Le and Le.PeriodStart) and Le:PeriodStart(periodKey) or 0
    local rows, total = self:Business(from)
    self.periodKey = nil
    local sec = self:Seconds(from)
    local shared = (sec.ah or 0) + (sec.mail or 0)
    local grossSum = rows.flip.gross + rows.craft.gross + rows.raw.gross
    for _, k in ipairs({ "flip", "craft", "raw" }) do
        local share = grossSum > 0 and (rows[k].gross / grossSum) or ((k == "craft") and 0 or 0.5)
        rows[k].seconds = shared * share
    end
    rows.craft.seconds = rows.craft.seconds + (sec.craft or 0)
    rows.de.seconds = sec.de or 0
    total.seconds = shared + (sec.craft or 0) + (sec.de or 0)
    for _, k in ipairs(self.KINDS) do
        local r = rows[k]
        r.perHour = (r.seconds or 0) >= self.MIN_SECONDS and (r.profit / r.seconds * 3600) or nil
    end
    total.perHour = total.seconds >= self.MIN_SECONDS and (total.profit / total.seconds * 3600) or nil
    return rows, total
end

-- "1g 20s/Std." bzw. rot "-30s/Std."; unter 15 Min. grau "zu wenig Daten"
function Act:PerHourText(r)
    if not r or not r.perHour then return "|cff888888" .. L["zu wenig Daten"] .. "|r" end
    local v = math.floor(math.abs(r.perHour) + 0.5)
    local s = A:FormatMoney(v) .. L["/Std."]
    if r.perHour < 0 then return "|cffff5544-" .. s .. "|r" end
    return s
end

function Act:DurationText(sec)
    sec = math.floor((sec or 0) + 0.5)
    local h, m = math.floor(sec / 3600), math.floor((sec % 3600) / 60)
    if h > 0 then return string.format(L["%d Std. %d Min."], h, m) end
    return string.format(L["%d Min."], m)
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
local evt = CreateFrame("Frame")
Act.evt = evt
for _, e in ipairs({ "GLOBAL_MOUSE_DOWN", "PLAYER_FLAGS_CHANGED", "MAIL_SHOW", "MAIL_CLOSED", "UNIT_SPELLCAST_SUCCEEDED",
                     "PLAYER_LOGOUT" }) do
    pcall(evt.RegisterEvent, evt, e)
end

local function IsAFK()
    local f = A:Global("UnitIsAFK")
    local ok, v = pcall(function() return f and f("player") end)
    local G = _G.GoldSentinelGame
    if G and G.IsSecret and G.IsSecret(v) then return false end
    return ok and v and true or false
end

-- Während der Testroutine keine echten Ereignisse mitschreiben (Sandbox, Befund 20:15 A2: activity.days)
local function Paused()
    local TR = A.TestRoutine
    return TR and TR.running and true or false
end
Act.Paused = Paused

-- eine Handlung des Spielers (Klick): zählt für das offene AH bzw. den offenen Briefkasten
function Act:PlayerAction()
    if Paused() then return end
    if A.IsAHOpen and A:IsAHOpen() then self:Touch("ah") end
    if self.mailOpen then self:Touch("mail") end
end

-- Herstellen: Produkt über den Rezeptnamen im gemerkten Rezept-Stand (ohne neues Lesen)
local function CraftProduct(spellID)
    local gsi = A:Global("GetSpellInfo")
    local name = gsi and gsi(spellID)
    if not name then
        local CS = A:Global("C_Spell")
        local info = CS and CS.GetSpellInfo and CS.GetSpellInfo(spellID)
        name = info and info.name
    end
    local Cr = A.Crafting
    if not (name and Cr and Cr.RecipeByName) then return nil end
    local pid, rec = Cr:RecipeByName(name)               -- EK-1: auch ohne Zwischenspeicher (Fenster, gemerkte Rezepte)
    if not pid then return nil end
    local sum = 0
    for _, re in ipairs(rec.reagents or {}) do
        local u = Cr.BestUnit and Cr:BestUnit(re[1], 1)
        if not u then sum = nil; break end
        sum = sum + u * re[2]
    end
    return pid, sum and (sum / math.max(rec.made or 1, 1)) or nil, rec
end
Act.CraftProduct = CraftProduct

evt:SetScript("OnEvent", function(_, event, a1, a2, a3)
    local G = _G.GoldSentinelGame
    if G and G.AnySecret and G.AnySecret(a1, a3) then return end      -- geschützte Werte nie vergleichen
    if Paused() and event ~= "PLAYER_FLAGS_CHANGED" then return end
    if event == "GLOBAL_MOUSE_DOWN" then
        Act:PlayerAction()
    elseif event == "PLAYER_FLAGS_CHANGED" then
        if a1 == "player" then Act:SetAFK(IsAFK()) end
    elseif event == "MAIL_SHOW" then
        Act.mailOpen = true
        Act:Touch("mail")
    elseif event == "MAIL_CLOSED" then
        Act.mailOpen = nil
        Act:Stop("mail")
    elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
        if a1 ~= "player" then return end
        local P = A.Spieltest
        local ok, isCraft = pcall(function() return P and P.IsCraftSpell and P:IsCraftSpell(a3) end)
        if not (ok and isCraft) then return end
        Act:Touch("craft")
        if a3 == 13262 then return end                     -- TB168-5: Entzaubern (13262) ist kein Herstellen
        local okP, pid, cost, rec = pcall(CraftProduct, a3)
        -- SK1-m (EK-1): jedes erkannte Herstellen muss gebucht werden können (Rezept gefunden)
        if A.SelfCheck and A.SelfCheck.Note then
            local gsi = A:Global("GetSpellInfo")
            local okN, sname = pcall(function() return gsi and gsi(a3) end)
            pcall(A.SelfCheck.Note, A.SelfCheck, "m", okP and pid ~= nil and rec ~= nil, string.format("Herstellen ohne Rezept: Zauber %s (%s)", tostring(a3), tostring(okN and sname or "?")))
        end
        if okP and pid then
            Act:NoteCraft(pid, cost)
            -- EB4-2: Herstellen sofort buchen (Zutaten aus dem Lager -> Kosten des Produkts), vor jedem Lager-Abgleich
            if rec then A:Fire("CRAFT_DONE", pid, math.max(1, math.floor((rec.made or 1) + 0.5)), rec.reagents) end
        end
    elseif event == "PLAYER_LOGOUT" then
        Act:Stop("ah"); Act:Stop("mail")
        pcall(Act.Prune, Act)
    end
end)

A:On("AH_STATE", function()
    if Paused() then return end
    if A:IsAHOpen() then
        Act:Touch("ah")
        pcall(Act.RaidHint, Act)
    else
        Act:Stop("ah")
    end
end)

-- ------------------------------------------------------------
-- H8: Hinweis vor dem Raid-Start 9.12.2026 (Onyxia, Hyjal-Gipfel, Barrow Deeps; Regelwerk Abschnitt 9,
-- shared/wissen/wirtschaft-forever.md). Ab 25.11. höchstens einmal am Tag beim Öffnen des AH, nach dem 9.12. aus.
-- ------------------------------------------------------------
Act.RAID_DATE = { year = 2026, month = 12, day = 9 }
Act.RAID_HINT_FROM = { year = 2026, month = 11, day = 25 }
function Act:RaidHint(now)
    if not (A.IsForever and A:IsForever()) then return false end
    now = now or self.Clock()
    -- feste Zeitpunkte (UTC 00:00; ohne time(tabelle)): 25.11.2026 = 1795564800, 9.12.2026 = 1796774400
    local from = self.RAID_HINT_FROM_T or 1795564800
    local till = self.RAID_DATE_T or 1796774400
    if now < from or now >= till then return false end
    local d = DB()
    local dk = DayKey(now)
    if not d or d.raidHintDay == dk then return false end
    d.raidHintDay = dk
    A:Print(L["Raid-Start 9.12.: Verbrauchsgüter und ihre Kräuter jetzt günstig einkaufen/herstellen."])
    return true
end
