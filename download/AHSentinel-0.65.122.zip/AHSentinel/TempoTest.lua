if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - TempoTest.lua
-- PS "pfeilschnell" (Entscheid des Nutzers 13.11. 22:08): Leistungsziele als Freigabe-Bedingung, gemessen im Client.
-- "/ahs testroutine tempo" misst jede Zeile der Tabelle und schreibt sie (mit Stelle bei Überschreitung) in den
-- Testbericht (Feld "tempo"). Nur messen, nichts ändern; Kaufen bleibt gesperrt (Sandbox der Testroutine).
--   Tooltip eines Items                 <= 5 ms Rechenzeit (ohne Zwischenspeicher)
--   Reiter wechseln, Liste aufbauen     <= 50 ms bis sichtbar
--   Sniper: neues Angebot sichtbar      <= 2 s  (aus dem letzten Sniper-Teil, Raste -> Anzeige)
--   Kauf per Raste/Taste                <= 1 Bild (Plan des nächsten Kaufs <= 16 ms)
--   AH offen: kein Bild > 16 ms durch AHSentinel (Hintergrund-Aufgaben, 20 s beobachtet)
--   Einloggen / /reload                 <= 100 ms am Stück (ADDON_LOADED, READY)
--   Speicher Vollscan                   <= 10 MB Zuwachs, <= 1 Speicherbereinigung (letzter Vollscan dieser Sitzung)
-- ============================================================
local A = AHAnalyzerPro
local TPT = {}
A.TempoTest = TPT

TPT.OBSERVE = 20
TPT.TOOLTIP_ITEMS = 30
TPT.LIMIT = { tooltip = 5, tab = 50, sniper = 2, buy = 16, frame = 16, login = 100, memKB = 10240, gc = 1 }

local function Clock() local c = _G.debugprofilestop; return c and c() or (GetTime() * 1000) end

-- Ergebnis je Zeile für das Feld "tempo" im Testbericht
TPT.results = {}
local function Note(key, txt) TPT.results[key] = txt end
function TPT:Summary()
    local out = {}
    for _, k in ipairs({ "tooltip", "tab", "sniper", "buy", "frame", "login", "memory" }) do
        if self.results[k] then out[#out + 1] = k .. " " .. self.results[k] end
    end
    return #out > 0 and table.concat(out, " · ") or nil
end

-- Tooltip: AddLines ohne Zwischenspeicher in einen stummen Empfänger, je Item gemessen
function TPT:MeasureTooltip(n)
    local TT = A.Tooltip
    if not (TT and TT.AddLines) then return nil end
    local sink = setmetatable({}, { __index = function() return function() end end })
    local worst, worstID, sum, cnt = 0, nil, 0, 0
    for id in pairs(A.db and A.db.marketData or {}) do
        if type(id) == "number" then
            local t0 = Clock()
            pcall(TT.AddLines, TT, sink, id)
            local ms = Clock() - t0
            sum, cnt = sum + ms, cnt + 1
            if ms > worst then worst, worstID = ms, id end
            if cnt >= (n or self.TOOLTIP_ITEMS) then break end
        end
    end
    if cnt == 0 then return nil end
    return worst, worstID, sum / cnt, cnt
end

-- Reiter wechseln: Zeit bis der Reiter aufgebaut ist (synchroner Teil)
function TPT:MeasureTabs()
    local UI = A.UI
    if not (UI and UI.SelectTab and UI.tabs) then return nil end
    local back = UI.activeTab
    local worst, worstID, cnt = 0, nil, 0
    for _, tab in ipairs(UI.tabs) do
        local id = tab.id
        if id and not (UI.WINDOW_TABS and UI.WINDOW_TABS[id]) then
            local t0 = Clock()
            local ok = pcall(UI.SelectTab, UI, id)
            local ms = Clock() - t0
            if ok then
                cnt = cnt + 1
                if ms > worst then worst, worstID = ms, id end
            end
        end
    end
    if back then pcall(UI.SelectTab, UI, back) end
    if cnt == 0 then return nil end
    return worst, worstID, cnt
end

-- Kauf per Raste: Plan des nächsten Kaufs (das, was zwischen Tastendruck und Senden gerechnet wird)
function TPT:MeasureBuyPlan()
    local Sn = A.Sniper
    if not (Sn and Sn.PlanNext and Sn.result) then return nil end
    local t0 = Clock()
    local ok, plan = pcall(Sn.PlanNext, Sn)
    local ms = Clock() - t0
    return ms, ok and plan ~= nil
end

function TPT:BuildSteps(TR, B, Chk, Skp)
    local L = self.LIMIT
    self.results = {}
    B(function()
        Chk("T625", "H", string.format("PS Tooltip eines Items <= %d ms Rechenzeit (ohne Zwischenspeicher, bis %d Items)", L.tooltip, self.TOOLTIP_ITEMS), function()
            local worst, id, avg, n = self:MeasureTooltip()
            if not worst then return "SKIP", "keine Marktdaten" end
            local txt = string.format("max %.1f ms (Item %s), Ø %.1f ms, %d Items", worst, tostring(id), avg, n)
            Note("tooltip", string.format("%.1f/%d ms", worst, L.tooltip))
            return worst <= L.tooltip, txt, "<= " .. L.tooltip .. " ms"
        end)
        Chk("T626", "H", string.format("PS Reiter wechseln, Liste aufbauen <= %d ms bis sichtbar", L.tab), function()
            local worst, id, n = self:MeasureTabs()
            if not worst then return "SKIP", "Reiter nicht verfügbar" end
            Note("tab", string.format("%.0f/%d ms", worst, L.tab))
            return worst <= L.tab, string.format("max %.0f ms (Reiter %s), %d Reiter", worst, tostring(id), n), "<= " .. L.tab .. " ms"
        end)
        Chk("T627", "H", string.format("PS Sniper: neues Angebot sichtbar <= %d s (aus dem letzten Teil \"sniper\")", L.sniper), function()
            local r = A.SniperTest and A.SniperTest.lastReaction
            if not r then return "SKIP", "erst /ahs testroutine sniper (mit Scrollen) ausführen" end
            Note("sniper", string.format("%.1f/%d s", r, L.sniper))
            return r <= L.sniper, string.format("%.1f s", r), "<= " .. L.sniper .. " s"
        end)
        Chk("T628", "H", "PS Kauf per Raste: Plan des Kaufs <= 1 Bild (16 ms)", function()
            local ms, has = self:MeasureBuyPlan()
            if not ms then return "SKIP", "kein Sniper-Ergebnis offen (AH öffnen, Ziel suchen)" end
            Note("buy", string.format("%.1f/%d ms", ms, L.buy))
            return ms <= L.buy, string.format("%.1f ms (%s)", ms, has and "Treffer da" or "kein Treffer"), "<= " .. L.buy .. " ms"
        end)
        Chk("T630", "H", string.format("PS Einloggen/reload: AHSentinel am Stück <= %d ms", L.login), function()
            local m = A.loadMs
            if not (m and (m.init or m.ready)) then return "SKIP", "keine Messung (debugprofilestop fehlt)" end
            local worst = math.max(m.init or 0, m.ready or 0)
            Note("login", string.format("%.0f/%d ms", worst, L.login))
            return worst <= L.login, string.format("Laden %.0f ms · Start %.0f ms", m.init or 0, m.ready or 0), "<= " .. L.login .. " ms"
        end)
        Chk("T631", "H", string.format("PS Speicher Vollscan <= %d MB Zuwachs, <= %d Speicherbereinigung", L.memKB / 1024, L.gc), function()
            local VS = A.FullScan
            local m = VS and VS.lastMeasure
            local age = ""
            if not (m and m.memBefore and (m.memAfter or m.memMax)) then
                m = A.db and A.db.vsLastMeasure                       -- TB118-4: über den Reload gerettet
                if m and m.t then age = string.format(" · Vollscan vor %d Min.", math.floor((time() - m.t) / 60)) end
            end
            if not (m and m.memBefore and (m.memAfter or m.memMax)) then return "SKIP", "noch kein Vollscan gemessen" end
            local grow = (m.memAfter or m.memMax) - m.memBefore
            Note("memory", string.format("+%.0f KB/GC %d", grow, m.gcN or 0))
            local own = (m.own and m.ownBefore) and string.format(" · AHSentinel %.0f -> %.0f MB", m.ownBefore / 1024, m.own / 1024) or ""
            return grow <= L.memKB and (m.gcN or 0) <= L.gc, string.format("Lua gesamt +%.1f MB, %d Bereinigungen%s%s", grow / 1024, m.gcN or 0, own, age), "<= 10 MB, <= 1"
        end)
    end)
    -- AH offen: 20 s Hintergrund-Aufgaben beobachten (längstes Stück je Bild, mit Stelle)
    B(function()
        if not A:IsAHOpen() then return Skp("T629", "H", "PS AH offen: kein Bild > 16 ms durch AHSentinel", "Auktionshaus nicht offen") end
        A.jobMeasure = { max = 0, frames = 0, jobs = {}, steps = {} }
        local t0 = GetTime()
        return "WAIT", function() return GetTime() - t0 >= TPT.OBSERVE end, TPT.OBSERVE + 5, function()
            local m = A.jobMeasure or { max = 0, frames = 0 }
            A.jobMeasure = nil
            Chk("T629", "H", string.format("PS AH offen: kein Bild > %d ms durch AHSentinel (%d s Hintergrund-Aufgaben)", L.frame, TPT.OBSERVE), function()
                local worstJob, worstMs = nil, 0
                for k, v in pairs(m.jobs or {}) do if v > worstMs then worstJob, worstMs = k, v end end
                local st = worstJob and m.steps and m.steps[worstJob]
                Note("frame", string.format("%.0f/%d ms", m.max or 0, L.frame))
                return (m.max or 0) <= L.frame, string.format("längstes Bild %.1f ms in %d Bildern%s%s", m.max or 0, m.frames or 0,
                    worstJob and (" · " .. worstJob) or "", st and string.format(" (längster Schritt %.0f ms bis %s)", st.ms, tostring(st.at)) or ""), "<= " .. L.frame .. " ms"
            end)
        end
    end)
end
