if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Daten von zwei Rechnern zusammenführen (Anweisung ZM1–ZM4, Entscheid des Nutzers 11.11. 15:55)
--
-- SCHNITTSTELLE MIT DEM UPLOADER (RaidMaster):
--   WoW speichert alle SavedVariables eines Addons in EINER Datei (SavedVariables\AHSentinel.lua). Der Uploader legt
--   bei einem Konflikt die ältere Fassung als eigenen, klar abgegrenzten Block in diese Datei:
--       AHSentinelMerge = { v = 1, von = "<Rechnername>", zeit = <Unix-Zeit>, grund = "...", db = <AHSentinelDB der älteren Datei> }
--   (Feldnamen des Uploaders; from/t werden ebenso gelesen)
--   (die ältere Datei beginnt mit "AHSentinelDB = {" - der Uploader ersetzt nur den Namen und hängt den Block an).
--   Kurzform ohne Hülle ist auch erlaubt: AHSentinelMerge = <Inhalt von AHSentinelDB>.
--   AHSentinelDB selbst schreibt nur AHSentinel. AHSentinelMerge steht in der TOC (SavedVariables); nach dem
--   Zusammenführen setzt AHSentinel es auf nil -> beim nächsten Speichern ist der Block weg (ZM3).
--
-- REGELN (ZM2): nichts doppelt, nie etwas verlieren
--   Entzaubern: deLog über Kennung (Zeit + Item + Beute) vereinigen; nur die FEHLENDEN Ergebnisse kommen in deStats dazu
--               (Warteschlange deMergeQueue, bis die Item-Daten geladen sind). deStats wird nur erhöht, nie gesenkt.
--               deShared: je Absender der grössere Stand. deBuys: über Kennung vereinigen. deNever/deBlock: vereinigen.
--   Prognose-Journal: Einträge über den Text vereinigen (nach Zeit sortiert).
--   Buchhaltung (Books): Buchungen über Kennung vereinigen; Kostenbasis je Charakter von der Seite mit der neueren
--               Buchung dieses Charakters; alte Buchungen (ledger.entries) über Kennung vereinigen.
--   Preise: je Item Preisverlauf vereinigt (Zeitpunkt = Kennung). Vollscan: der neuere Stand.
--   Charaktere: je Charakter der neuere Stand. Einstellungen: die des aktuellen Rechners.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local Mg = {}
A.Merge = Mg

local function LootKey(loot)
    local p = {}
    for _, l in ipairs(loot or {}) do p[#p + 1] = tostring(l[1]) .. "x" .. tostring(l[2] or 1) end
    table.sort(p)
    return table.concat(p, ",")
end
function Mg.DEKey(e) return tostring(e.t) .. ":" .. tostring(e.itemID) .. ":" .. LootKey(e.loot) end
local function ByT(a, b) return (a.t or 0) < (b.t or 0) end

-- Entzaubern: Verlauf vereinigen, fehlende Ergebnisse in die Warteschlange
function Mg:MergeDE(dst, src, c)
    dst.deLog = dst.deLog or {}
    local have = {}
    for _, e in ipairs(dst.deLog) do have[Mg.DEKey(e)] = true end
    local added = 0
    dst.deMergeQueue = dst.deMergeQueue or {}
    for _, e in ipairs(src.deLog or {}) do
        if type(e) == "table" and e.itemID then
            local k = Mg.DEKey(e)
            if not have[k] then
                have[k] = true
                table.insert(dst.deLog, e)
                added = added + 1
                if not e.rejected then table.insert(dst.deMergeQueue, { itemID = e.itemID, loot = e.loot, t = e.t }) end
            end
        end
    end
    table.sort(dst.deLog, ByT)
    c.de = added
    -- L4: Ergebnisse, die drüben nur in deStats stehen (ohne Verlauf, z. B. älter als 2000 Einträge) - nie raten, nur melden
    local statN, logN = 0, 0
    for _, st in pairs(src.deStats or {}) do statN = statN + ((type(st) == "table" and st.n) or 0) end
    for _, e in ipairs(src.deLog or {}) do if type(e) == "table" and not e.rejected then logN = logN + 1 end end
    c.deNoLog = math.max(0, statN - logN)
    -- geteilte Ergebnisse anderer Spieler: je Absender der grössere Stand
    dst.deShared = dst.deShared or {}
    for who, rec in pairs(src.deShared or {}) do
        local mine = dst.deShared[who]
        local function total(r) local n = 0; for _, x in pairs(type(r) == "table" and r.g or {}) do n = n + ((type(x) == "table" and x.n) or 0) end; return n end
        if not mine or total(rec) > total(mine) then dst.deShared[who] = rec end
    end
    -- Sammelkauf-Käufe
    dst.deBuys = dst.deBuys or {}
    local bk = {}
    for _, b in ipairs(dst.deBuys) do bk[tostring(b.t) .. ":" .. tostring(b.itemID) .. ":" .. tostring(b.paid)] = true end
    local nb = 0
    for _, b in ipairs(src.deBuys or {}) do
        local k = tostring(b.t) .. ":" .. tostring(b.itemID) .. ":" .. tostring(b.paid)
        if not bk[k] then bk[k] = true; table.insert(dst.deBuys, b); nb = nb + 1 end
    end
    table.sort(dst.deBuys, ByT)
    c.deBuys = nb
    for _, name in ipairs({ "deBlock" }) do
        if type(src[name]) == "table" then
            dst[name] = dst[name] or {}
            for k, v in pairs(src[name]) do if dst[name][k] == nil then dst[name][k] = v end end
        end
    end
    if type(src.deNever) == "table" then
        dst.deNever = dst.deNever or { items = {}, classes = {} }
        for _, part in ipairs({ "items", "classes" }) do
            dst.deNever[part] = dst.deNever[part] or {}
            for k, v in pairs(src.deNever[part] or {}) do if dst.deNever[part][k] == nil then dst.deNever[part][k] = v end end
        end
        for ck, set in pairs(src.deNever.classFails or {}) do
            dst.deNever.classFails = dst.deNever.classFails or {}
            dst.deNever.classFails[ck] = dst.deNever.classFails[ck] or {}
            for id, v in pairs(set) do dst.deNever.classFails[ck][id] = v end
        end
    end
end

-- Warteschlange abarbeiten: Ergebnis in deStats zählen (wie D:Record, ohne Teilen/Protokoll). Nur erhöhen.
-- Zurück: gezählt, noch offen
function Mg:ProcessQueue(db)
    db = db or A.db
    local q = db and db.deMergeQueue
    if not q or #q == 0 then return 0, 0 end
    local D = A.Disenchant
    if not (D and D.Prior) then return 0, #q end
    db.deStats = db.deStats or {}
    local keep, done = {}, 0
    for _, e in ipairs(q) do
        local okP, prior, key = pcall(D.Prior, D, e.itemID)
        if okP and prior and key then
            local st = db.deStats[key]
            if not st then st = { n = 0, mats = {} }; db.deStats[key] = st end
            st.n = st.n + 1
            local sums = {}
            for _, l in ipairs(e.loot or {}) do sums[l[1]] = (sums[l[1]] or 0) + (l[2] or 1) end
            for id, qty in pairs(sums) do
                local m = st.mats[id]
                if not m then m = { times = 0, total = 0 }; st.mats[id] = m end
                m.times, m.total = m.times + 1, m.total + qty
            end
            done = done + 1
        else
            keep[#keep + 1] = e
            if A.UI and A.UI.RequestItemInfo then pcall(A.UI.RequestItemInfo, A.UI, e.itemID) end
        end
    end
    db.deMergeQueue = #keep > 0 and keep or nil
    return done, #keep
end

-- Prognose-Journal: Einträge (Texte) vereinigen, nach Zeit sortiert
function Mg:MergeForecast(dst, src, c)
    local Fc = A.Forecast
    local sf, df = src.forecast, dst.forecast
    if type(sf) ~= "table" or type(sf.list) ~= "table" then c.forecast = 0; return end
    if type(df) ~= "table" then dst.forecast = sf; c.forecast = #sf.list; return end
    df.list = df.list or {}
    local have, n = {}, 0
    for _, s in ipairs(df.list) do have[s] = true end
    for _, s in ipairs(sf.list) do if not have[s] then have[s] = true; table.insert(df.list, s); n = n + 1 end end
    if Fc and Fc.Decode then
        local tOf = {}
        for _, s in ipairs(df.list) do local e = Fc:Decode(s); tOf[s] = e and e.t or 0 end
        table.sort(df.list, function(a, b) return tOf[a] < tOf[b] end)
    end
    c.forecast = n
end

-- Buchhaltung neu: Buchungen vereinigen, Kostenbasis je Charakter von der Seite mit der neueren Buchung
local function BookKey(e) return table.concat({ tostring(e.k), tostring(e.t), tostring(e.id), tostring(e.q), tostring(e.ch), tostring(e.a), tostring(e.cost) }, ":") end
function Mg:MergeBooks(dst, src, c)
    local sb, db = src.books, dst.books
    if type(sb) ~= "table" then c.books = 0; return end
    if type(db) ~= "table" then dst.books = sb; c.books = #(sb.log or {}); return end
    db.log = db.log or {}
    local have, n = {}, 0
    local lastD, lastS = {}, {}
    local newEntries, skipCh = {}, {}
    for _, e in ipairs(db.log) do have[BookKey(e)] = true; if e.ch then lastD[e.ch] = math.max(lastD[e.ch] or 0, e.t or 0) end end
    for _, e in ipairs(sb.log or {}) do
        if e.ch then lastS[e.ch] = math.max(lastS[e.ch] or 0, e.t or 0) end
        local k = BookKey(e)
        if not have[k] then
            have[k] = true
            table.insert(db.log, e)
            newEntries[#newEntries + 1] = e
            n = n + 1
        end
    end
    table.sort(db.log, ByT)
    -- L2: Kostenbasis je Charakter - die Positionen dieses Rechners bleiben, dazu kommen die Buchungen der anderen Seite,
    -- die hier fehlen (Käufe/Eingänge addieren, Verkäufe/Abgänge abziehen, in Zeitfolge). Charakter nur drüben -> dessen Stand.
    db.cb = db.cb or {}
    local onlySrc = {}
    for _, e in ipairs(newEntries) do onlySrc[#onlySrc + 1] = e end
    table.sort(onlySrc, ByT)
    for ch, pos in pairs(sb.cb or {}) do if not db.cb[ch] then db.cb[ch] = pos; skipCh[ch] = true end end
    local function P(ch, id)
        db.cb[ch] = db.cb[ch] or {}
        local p = db.cb[ch][id]
        if not p then p = { q = 0, c = 0 }; db.cb[ch][id] = p end
        return p
    end
    for _, e in ipairs(onlySrc) do
        if e.ch and not skipCh[e.ch] and e.id then
            local p = P(e.ch, e.id)
            if e.k == "buy" then p.q, p.c = p.q + (e.q or 0), p.c + (e.cost or 0)
            elseif e.k == "sale" or e.k == "de" or e.k == "xfer" then
                local known = math.min(p.q, (e.q or 1) - (e.free or 0))
                if known > 0 then p.q, p.c = p.q - known, math.max(0, p.c - (e.cost or 0)) end
                if e.k == "xfer" and e.to and not skipCh[e.to] then local p2 = P(e.to, e.id); p2.q, p2.c = p2.q + (e.q or 1), p2.c + (e.cost or 0) end
            end
        end
    end
    db.since = math.min(db.since or math.huge, sb.since or math.huge)
    db.opened = db.opened or {}
    for ch, v in pairs(sb.opened or {}) do if db.opened[ch] == nil then db.opened[ch] = v end end
    db.seenSold = db.seenSold or {}
    for id, t in pairs(sb.seenSold or {}) do if db.seenSold[id] == nil then db.seenSold[id] = t end end
    db.gold = db.gold or {}
    for ch, g in pairs(sb.gold or {}) do
        local mine = db.gold[ch]
        if not mine or (g.lastT or 0) > (mine.lastT or 0) then db.gold[ch] = g end
    end
    c.books = n
end

-- alte Buchungen (für Statistik/Absatz): über Kennung vereinigen
local function LedgerKey(e) return table.concat({ tostring(e.kind), tostring(e.t), tostring(e.itemID or e.name), tostring(e.qty), tostring(e.amount) }, ":") end
function Mg:MergeLedger(dst, src, c)
    local sl, dl = src.ledger, dst.ledger
    if type(sl) ~= "table" or type(sl.entries) ~= "table" then c.ledger, c.buys = 0, 0; return end
    dst.ledger = dl or { entries = {}, seen = {} }
    dl = dst.ledger
    dl.entries = dl.entries or {}
    local have, n, buys = {}, 0, 0
    for _, e in ipairs(dl.entries) do if type(e) == "table" then have[LedgerKey(e)] = true end end
    for _, e in ipairs(sl.entries) do
        if type(e) == "table" then
            local k = LedgerKey(e)
            if not have[k] then
                have[k] = true
                table.insert(dl.entries, e)
                n = n + 1
                if e.kind == "buy" then buys = buys + 1 end
            end
        end
    end
    table.sort(dl.entries, ByT)
    dl.seen = dl.seen or {}
    for k, v in pairs(sl.seen or {}) do if dl.seen[k] == nil then dl.seen[k] = v end end
    c.ledger, c.buys = n, buys
end

-- Preisverlauf je Item vereinigen (Zeitpunkt = Kennung); pause = Pausen in einer Hintergrund-Aufgabe
function Mg:MergeMarket(dst, src, c, pause)
    local sm = src.marketData
    if type(sm) ~= "table" then c.items = 0; return end
    dst.marketData = dst.marketData or {}
    local dm = dst.marketData
    local n, steps = 0, 0
    for id, se in pairs(sm) do
        steps = steps + 1
        if pause and steps % 50 == 0 then A:Pause() end
        if type(se) == "table" then
            local de = dm[id]
            if type(de) ~= "table" then
                dm[id] = se
                n = n + 1
            else
                if de.hz and A.PD7 and A.PD7.loading then pcall(A.PD7.LoadEntry, A.PD7, de) end   -- TB118-2
                local h = de.history or {}
                de.history = h
                local seen = {}
                for _, e in ipairs(h) do seen[e.t or 0] = true end
                local add = false
                for _, e in ipairs(se.history or {}) do
                    if type(e) == "table" and e.t and not seen[e.t] then seen[e.t] = true; table.insert(h, e); add = true end
                end
                if add then table.sort(h, ByT); n = n + 1 end
                for k, v in pairs(se) do if k ~= "history" and de[k] == nil then de[k] = v end end
            end
        end
    end
    c.items = n
end

-- Vollscan: der neuere Stand; Charaktere: je Charakter der neuere
function Mg:MergeRest(dst, src, c)
    local sf, df = src.fullScan, dst.fullScan
    local function stamp(f) return type(f) == "table" and math.max(f.lastCall or 0, f.lastScan or 0, f.updated or 0) or 0 end
    if type(sf) == "table" and stamp(sf) > stamp(df) then dst.fullScan = sf; c.fullScan = true end
    if type(src.chars) == "table" then
        dst.chars = dst.chars or {}
        for key, ch in pairs(src.chars) do
            local mine = dst.chars[key]
            if type(ch) == "table" and (type(mine) ~= "table" or (ch.updated or 0) > (mine.updated or 0)) then dst.chars[key] = ch end
        end
    end
end

-- Paket aus der SavedVariable lesen: { db = ... } oder direkt die Datenbank
function Mg:Unwrap(pkg)
    if type(pkg) ~= "table" then return nil end
    if type(pkg.db) == "table" then return pkg.db, pkg.from or pkg.von, pkg.t or pkg.zeit end      -- L3: Uploader schreibt von/zeit
    if pkg.marketData or pkg.deLog or pkg.deStats or pkg.ledger or pkg.settings then return pkg, nil, nil end
    return nil
end

-- alles zusammenführen (ohne Preise; die kommen in Portionen). Zurück: Zähler
function Mg:MergeInto(dst, src)
    local c = {}
    self:MergeDE(dst, src, c)
    self:MergeForecast(dst, src, c)
    self:MergeBooks(dst, src, c)
    self:MergeLedger(dst, src, c)
    self:MergeRest(dst, src, c)
    -- Einstellungen: die des aktuellen Rechners bleiben (src.settings wird nicht gelesen)
    return c
end

function Mg:Summary(c)
    return string.format(L["Daten vom anderen Rechner übernommen: %d Entzauberungen, %d Käufe, %d Buchungen, %d Prognose-Fälle, %d Items mit Preisen."],
        c.de or 0, c.buys or 0, c.books or 0, c.forecast or 0, c.items or 0)
end

-- beim Einloggen: Paket da? -> zusammenführen, Paket leeren (ZM3)
-- Paket holen und die SavedVariable leeren (nie zweimal, auch bei Fehlern: das Paket gilt als gelesen)
function Mg:Take()
    local pkg = _G.AHSentinelMerge
    _G.AHSentinelMerge = nil
    return pkg
end
function Mg:Run()
    if _G.AHSentinelMerge == nil or not A.db or A:Simulated() then return false end
    local pkg = self:Take()
    local src, from = self:Unwrap(pkg)
    if not src then
        if A.Diag then pcall(A.Diag.Add, A.Diag, "SYNC-ZUSAMMENGEFUEHRT", "Paket ohne Daten - ignoriert") end
        return false
    end
    local ok, c = pcall(self.MergeInto, self, A.db, src)
    if not ok then
        A:ReportError("Merge", c)
        return false
    end
    local done, open = self:ProcessQueue(A.db)
    A:Job("merge:market", function()
        local okM = A:PCall(Mg.MergeMarket, Mg, A.db, src, c, true)
        if A.ResetOutlook then pcall(A.ResetOutlook, A) end
        A.priceVersion = (A.priceVersion or 0) + 1
        local line = string.format("%d Entzauberungen (gezählt %d, warten auf Item-Daten %d, %d Ergebnisse ohne Verlauf nicht übernommen), %d Käufe, %d Buchungen, %d Prognose-Fälle, %d Items, Vollscan %s, Quelle %s",
            c.de or 0, done, open, c.deNoLog or 0, c.buys or 0, c.books or 0, c.forecast or 0, c.items or 0, c.fullScan and "übernommen" or "eigener", from and "Rechner" or "?")
        if A.Diag then pcall(A.Diag.Add, A.Diag, "SYNC-ZUSAMMENGEFUEHRT", line) end
        A:Print(Mg:Summary(c))
        A:Fire("DATA_CHANGED")
        A:Fire("LEDGER_CHANGED")
    end)
    self.lastCounts = c
    return true
end

A:On("READY", function()
    pcall(Mg.Run, Mg)
    -- Ergebnisse, die auf Item-Daten warten: nach dem Laden zählen
    if A.db and A.db.deMergeQueue then pcall(Mg.ProcessQueue, Mg, A.db) end
end)
A:On("ITEMINFO_LOADED", function()
    if A.db and A.db.deMergeQueue and not A:Simulated() then
        local done = Mg:ProcessQueue(A.db)
        if done > 0 then A:Fire("DE_LEARNED") end
    end
end)
