-- ============================================================
-- AH Analyzer Pro 5.8 - Hauptfenster, Designs, Tab-System, Bausteine
--
-- Zwei Designs, jederzeit umschaltbar (Optionen oder /ahp design):
--   "classic" - im Stil des WoW-Auktionshauses: dunkles Holz, Goldrahmen,
--               rote WoW-Knöpfe, Reiter unten am Fenster
--   "modern"  - flach und dunkel mit Cyan-Akzent
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local UI = {}
A.UI = UI

-- ------------------------------------------------------------
-- Farbpaletten
-- ------------------------------------------------------------
UI.THEMES = {
    modern = {
        label     = "Modern",
        bg        = { 0.07, 0.075, 0.09, 0.97 },
        panel     = { 0.11, 0.12, 0.145, 1 },
        panel2    = { 0.14, 0.15, 0.18, 1 },
        border    = { 0.22, 0.24, 0.29, 1 },
        frameEdge = { 0, 0, 0, 1 },
        bar       = { 0.045, 0.05, 0.06, 1 },
        input     = { 0.05, 0.055, 0.07, 1 },
        accent    = { 0.0, 0.82, 0.82, 1 },
        accentDim = { 0.0, 0.40, 0.42, 1 },
        heading   = { 0.92, 0.93, 0.96, 1 },
        text      = { 0.92, 0.93, 0.96, 1 },
        textDim   = { 0.58, 0.60, 0.66, 1 },
        green     = { 0.20, 0.87, 0.33, 1 },
        red       = { 1.00, 0.33, 0.27, 1 },
        yellow    = { 1.00, 0.80, 0.20, 1 },
    },
    classic = {
        label     = "Klassisch",
        bg        = { 0.11, 0.075, 0.04, 0.97 },     -- dunkles Holz
        panel     = { 0.035, 0.025, 0.015, 0.92 },   -- Listenhintergrund
        panel2    = { 0.20, 0.14, 0.07, 1 },         -- Kopfzeilen
        border    = { 0.58, 0.45, 0.20, 1 },         -- Goldrahmen
        frameEdge = { 0.72, 0.58, 0.28, 1 },
        bar       = { 0.17, 0.115, 0.06, 1 },
        input     = { 0.02, 0.015, 0.01, 1 },
        accent    = { 1.00, 0.82, 0.00, 1 },         -- WoW-Gold
        accentDim = { 0.55, 0.10, 0.06, 1 },
        heading   = { 1.00, 0.82, 0.00, 1 },
        text      = { 1.00, 0.97, 0.90, 1 },
        textDim   = { 0.75, 0.66, 0.50, 1 },
        green     = { 0.20, 0.87, 0.33, 1 },
        red       = { 1.00, 0.33, 0.27, 1 },
        yellow    = { 1.00, 0.80, 0.20, 1 },
    },
}

-- UI.C ist EINE Tabelle, die beim Umschalten neu befüllt wird.
-- Alle Tabs halten eine Referenz darauf und bekommen so automatisch die neuen Farben.
UI.C = {}
local C = UI.C
UI.theme = "modern"

function UI:ApplyPalette(name)
    if not self.THEMES[name] then name = "classic" end
    self.theme = name
    for k, v in pairs(self.THEMES[name]) do
        if type(v) == "table" then C[k] = { v[1], v[2], v[3], v[4] } else C[k] = v end
    end
end
UI:ApplyPalette("modern")

function UI:IsClassic()
    return self.theme == "classic"
end

local TEX = {
    btnUp       = "Interface\\Buttons\\UI-Panel-Button-Up",
    btnDown     = "Interface\\Buttons\\UI-Panel-Button-Down",
    btnDisabled = "Interface\\Buttons\\UI-Panel-Button-Disabled",
    btnHL       = "Interface\\Buttons\\UI-Panel-Button-Highlight",
    tabActive   = "Interface\\PaperDollInfoFrame\\UI-Character-ActiveTab",
    tabInactive = "Interface\\PaperDollInfoFrame\\UI-Character-InActiveTab",
    close       = "Interface\\Buttons\\UI-Panel-MinimizeButton-Up",
    closeDown   = "Interface\\Buttons\\UI-Panel-MinimizeButton-Down",
    closeHL     = "Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight",
}
UI.TEX = TEX

-- ------------------------------------------------------------
-- Grundbausteine (ohne BackdropTemplate, läuft auf jedem Client)
-- ------------------------------------------------------------
function UI:Box(frame, bg, border, thickness)
    if not frame.__bg then
        frame.__bg = frame:CreateTexture(nil, "BACKGROUND")
        frame.__bg:SetAllPoints()
    end
    frame.__bg:SetColorTexture(unpack(bg or C.panel))
    if border then
        local th = thickness or 1
        if not frame.__edges then
            frame.__edges = {}
            for i = 1, 4 do frame.__edges[i] = frame:CreateTexture(nil, "BORDER") end
            local t, b, l, r = unpack(frame.__edges)
            t:SetPoint("TOPLEFT"); t:SetPoint("TOPRIGHT"); t:SetHeight(th)
            b:SetPoint("BOTTOMLEFT"); b:SetPoint("BOTTOMRIGHT"); b:SetHeight(th)
            l:SetPoint("TOPLEFT"); l:SetPoint("BOTTOMLEFT"); l:SetWidth(th)
            r:SetPoint("TOPRIGHT"); r:SetPoint("BOTTOMRIGHT"); r:SetWidth(th)
        end
        for _, e in ipairs(frame.__edges) do e:SetColorTexture(unpack(border)) end
    end
    return frame
end

function UI:Label(parent, text, font, color)
    -- große Überschriften: im klassischen Design golden wie bei Blizzard
    if font == "GameFontNormalLarge" and (color == nil or color == C.text) then color = C.heading end
    local fs = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlight")
    fs:SetText(text or "")
    fs:SetTextColor(unpack(color or C.text))
    fs:SetJustifyH("LEFT")
    return fs
end

local function ShowTooltip(self)
    if self.tooltip then
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText(self.tooltip, 1, 1, 1, 1, true)
        GameTooltip:Show()
    end
end

-- Knopf. style: "primary" | "normal" | "danger"
-- Klassisch: roter WoW-Knopf mit Goldschrift. Modern: flacher Knopf.
function UI:Button(parent, text, width, height, onClick, style)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width or 120, height or 24)
    b.enabledState = true
    local classic = UI:IsClassic()

    b.label = b:CreateFontString(nil, "OVERLAY", classic and "GameFontNormalSmall" or "GameFontHighlightSmall")
    b.label:SetPoint("CENTER", 0, classic and 1 or 0)
    b.label:SetText(text or "")
    local textColor = (classic and style ~= "primary") and C.accent or C.text

    if classic then
        b.__tex = b:CreateTexture(nil, "BACKGROUND")
        b.__tex:SetAllPoints()
        b.__hl = b:CreateTexture(nil, "HIGHLIGHT")
        b.__hl:SetAllPoints()
        b.__hl:SetTexture(TEX.btnHL)
        b.__hl:SetTexCoord(0, 0.625, 0, 0.6875)
        if b.__hl.SetBlendMode then b.__hl:SetBlendMode("ADD") end
        function b:Paint(path)
            self.__tex:SetTexture(path)
            self.__tex:SetTexCoord(0, 0.625, 0, 0.6875)
        end
        b:Paint(TEX.btnUp)
        b:SetScript("OnMouseDown", function(self)
            if self.enabledState then self:Paint(TEX.btnDown); self.label:SetPoint("CENTER", 1, 0) end
        end)
        b:SetScript("OnMouseUp", function(self)
            if self.enabledState then self:Paint(TEX.btnUp) end
            self.label:SetPoint("CENTER", 0, 1)
        end)
        b:SetScript("OnEnter", ShowTooltip)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    else
        local base = (style == "primary" and C.accentDim) or (style == "danger" and { 0.45, 0.12, 0.10, 1 }) or C.panel2
        local hover = (style == "primary" and C.accent) or (style == "danger" and { 0.70, 0.18, 0.15, 1 }) or { 0.20, 0.22, 0.27, 1 }
        b.__base, b.__hover = base, hover
        UI:Box(b, base, C.border)
        b:SetScript("OnEnter", function(self)
            if self.enabledState then self.__bg:SetColorTexture(unpack(hover)) end
            ShowTooltip(self)
        end)
        b:SetScript("OnLeave", function(self)
            self.__bg:SetColorTexture(unpack(self.enabledState and base or { 0.12, 0.12, 0.14, 1 }))
            GameTooltip:Hide()
        end)
    end
    b.label:SetTextColor(unpack(textColor))

    b:SetScript("OnClick", function(self, ...)
        if self.enabledState and onClick then onClick(self, ...) end
    end)
    function b:SetText(t) self.label:SetText(t) end
    function b:GetText() return self.label:GetText() end
    function b:SetActive(on)
        self.enabledState = on and true or false
        if self.__tex then
            self:Paint(on and TEX.btnUp or TEX.btnDisabled)
            self.__hl:SetAlpha(on and 1 or 0)
        else
            self.__bg:SetColorTexture(unpack(on and self.__base or { 0.12, 0.12, 0.14, 1 }))
        end
        self.label:SetTextColor(unpack(on and textColor or C.textDim))
    end
    return b
end

-- Eingabefeld mit Platzhaltertext
function UI:EditBox(parent, width, height, placeholder)
    local e = CreateFrame("EditBox", nil, parent)
    e:SetSize(width or 150, height or 22)
    e:SetAutoFocus(false)
    e:SetFontObject(ChatFontNormal or GameFontHighlight)
    e:SetTextInsets(6, 6, 0, 0)
    e:SetMaxLetters(80)
    UI:Box(e, C.input, C.border)
    e.placeholder = e:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    e.placeholder:SetPoint("LEFT", 7, 0)
    e.placeholder:SetText(placeholder or "")
    local function updatePlaceholder(self)
        if self:GetText() == "" and not self:HasFocus() then self.placeholder:Show() else self.placeholder:Hide() end
    end
    e:SetScript("OnEditFocusGained", function(self)
        self.placeholder:Hide()
        for _, edge in ipairs(self.__edges) do edge:SetColorTexture(unpack(C.accent)) end
    end)
    e:SetScript("OnEditFocusLost", function(self)
        updatePlaceholder(self)
        for _, edge in ipairs(self.__edges) do edge:SetColorTexture(unpack(C.border)) end
    end)
    e:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    e:SetScript("OnTabPressed", function(self)
        if self.nextBox then self.nextBox:SetFocus() else self:ClearFocus() end
    end)
    e.UpdatePlaceholder = updatePlaceholder
    return e
end

-- ------------------------------------------------------------
-- Geld-Eingabe wie im Auktionshaus: [Gold] (G) [Silber] (S) [Kupfer] (K)
-- Gold darf Nachkommastellen haben (12.5) - eingefügter Text wie "12g 50s 3k" geht auch.
-- m:GetCopper(), m:SetCopper(kupfer), m:Clear(), m:SetFocus(), m.boxes = { gold, silber, kupfer }
-- ------------------------------------------------------------
local COIN_TEX = {
    "Interface\\MoneyFrame\\UI-GoldIcon",
    "Interface\\MoneyFrame\\UI-SilverIcon",
    "Interface\\MoneyFrame\\UI-CopperIcon",
}

function UI:MoneyInput(parent, onChange)
    local m = CreateFrame("Frame", nil, parent)
    m:SetSize(154, 24)
    m.boxes = {}
    local widths = { 50, 30, 30 }
    local x = 0
    for i = 1, 3 do
        local e = UI:EditBox(m, widths[i], 24, "")
        e:SetPoint("LEFT", x, 0)
        e:SetJustifyH("RIGHT")
        e:SetTextInsets(3, 4, 0, 0)
        if i > 1 then
            e:SetMaxLetters(2)
            if e.SetNumeric then e:SetNumeric(true) end
        else
            e:SetMaxLetters(16)
        end
        local icon = m:CreateTexture(nil, "ARTWORK")
        icon:SetTexture(COIN_TEX[i])
        icon:SetSize(13, 13)
        icon:SetPoint("LEFT", e, "RIGHT", 2, 0)
        e:SetScript("OnTextChanged", function(self, userInput)
            if onChange then onChange(m, userInput) end
        end)
        m.boxes[i] = e
        x = x + widths[i] + 17
    end

    function m:GetCopper()
        local gText = self.boxes[1]:GetText() or ""
        -- eingefügter Text mit Einheiten ("12g 50s 3k") im Gold-Feld
        if gText:find("[^%d%s%.,]") then return A:ParseGold(gText) end
        local g = tonumber((gText:gsub(",", "."))) or 0
        local sv = tonumber(self.boxes[2]:GetText() or "") or 0
        local c = tonumber(self.boxes[3]:GetText() or "") or 0
        local total = math.floor(g * 10000 + sv * 100 + c + 0.5)
        if total <= 0 then return nil end
        return total
    end

    function m:SetCopper(copper)
        if not copper or copper <= 0 then return self:Clear() end
        local g, sv, c = A:SplitMoney(copper)
        self.boxes[1]:SetText(g > 0 and tostring(g) or "")
        self.boxes[2]:SetText((sv > 0 or (g > 0 and c > 0)) and tostring(sv) or "")
        self.boxes[3]:SetText(c > 0 and tostring(c) or "")
        for _, e in ipairs(self.boxes) do e:UpdatePlaceholder() end
    end

    function m:Clear()
        for _, e in ipairs(self.boxes) do e:SetText(""); e:ClearFocus(); e:UpdatePlaceholder() end
    end

    function m:SetFocus() self.boxes[1]:SetFocus() end

    -- Enter in einem der drei Felder
    function m:SetOnEnter(fn)
        for _, e in ipairs(self.boxes) do e:SetScript("OnEnterPressed", fn) end
    end

    m.tooltip = L["Gold / Silber / Kupfer"]
    return m
end

-- Tab-Reihenfolge für mehrere Eingabefelder (Tab-Taste springt weiter)
function UI:ChainEdits(list)
    for i, e in ipairs(list) do e.nextBox = list[i + 1] or list[1] end
end

-- Kennzahl-Karte
function UI:Card(parent, width, height, title)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(width, height)
    UI:Box(f, C.panel, C.border)
    local bar = f:CreateTexture(nil, "ARTWORK")
    bar:SetColorTexture(unpack(C.accent))
    bar:SetPoint("TOPLEFT"); bar:SetPoint("BOTTOMLEFT"); bar:SetWidth(3)
    f.bar = bar
    f.title = UI:Label(f, title, "GameFontNormalSmall", C.textDim)
    f.title:SetPoint("TOPLEFT", 12, -9)
    f.value = UI:Label(f, "-", "GameFontNormalLarge", C.text)
    f.value:SetTextColor(unpack(C.text))
    f.value:SetPoint("TOPLEFT", 12, -26)
    f.sub = UI:Label(f, "", "GameFontDisableSmall", C.textDim)
    f.sub:SetPoint("BOTTOMLEFT", 12, 8)
    return f
end

-- ------------------------------------------------------------
-- Tabelle mit Kopfzeile, Sortierung, Mausrad-Blättern
-- cfg = {
--   columns = { { key, title, width, align, tooltip }, ... },
--   rows = 15, rowHeight = 22,
--   cell = function(item, key) return text end,
--   sortValue = function(item, key) return value end,
--   sortKey = "name", sortAsc = true,
--   onClick = function(item) end,
--   action = { text = "+", width = 26, tooltip = "...", onClick = function(item) end },
--   emptyText = "...",
--   idKey = "itemID",  -- Feld, an dem die markierte Zeile erkannt wird
--   noMenu = true,     -- kein Rechtsklick-Menü
-- }
-- Rechtsklick auf eine Zeile mit Item öffnet das Item-Menü.
-- ------------------------------------------------------------
function UI:Table(parent, cfg)
    local rowH = cfg.rowHeight or 22
    local numRows = cfg.rows or 12
    local headerH = 22
    local actionW = cfg.action and (cfg.action.width or 26) or 0

    local t = CreateFrame("Frame", nil, parent)
    UI:Box(t, C.panel, C.border)
    t.items = {}
    t.offset = 0
    t.sortKey = cfg.sortKey
    t.sortAsc = cfg.sortAsc ~= false
    t:EnableMouseWheel(true)

    local totalW = 0
    for _, col in ipairs(cfg.columns) do totalW = totalW + col.width end
    t:SetSize(totalW + actionW + 26, headerH + numRows * rowH + 8)

    -- Kopfzeile
    local header = CreateFrame("Frame", nil, t)
    header:SetPoint("TOPLEFT", 1, -1)
    header:SetPoint("TOPRIGHT", -1, -1)
    header:SetHeight(headerH)
    UI:Box(header, C.panel2)
    t.headerCells = {}
    local x = 6
    for _, col in ipairs(cfg.columns) do
        local hb = CreateFrame("Button", nil, header)
        hb:SetPoint("LEFT", x, 0)
        hb:SetSize(col.width, headerH)
        hb.text = hb:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        hb.text:SetPoint(col.align == "RIGHT" and "RIGHT" or "LEFT", col.align == "RIGHT" and -6 or 0, 0)
        hb.text:SetTextColor(unpack(C.textDim))
        hb.col = col
        hb:SetScript("OnClick", function()
            if cfg.sortValue == nil or col.noSort then return end
            if t.sortKey == col.key then t.sortAsc = not t.sortAsc else t.sortKey = col.key; t.sortAsc = (col.align ~= "RIGHT") end
            t:Sort(); t:Render()
        end)
        hb:SetScript("OnEnter", function(self)
            self.text:SetTextColor(unpack(C.text))
            if col.tooltip then
                GameTooltip:SetOwner(self, "ANCHOR_TOP")
                GameTooltip:SetText(col.title, 1, 1, 1)
                GameTooltip:AddLine(col.tooltip, 0.9, 0.9, 0.9, true)
                GameTooltip:Show()
            end
        end)
        hb:SetScript("OnLeave", function(self)
            t:UpdateHeader()
            if col.tooltip then GameTooltip:Hide() end
        end)
        table.insert(t.headerCells, hb)
        x = x + col.width
    end

    function t:UpdateHeader()
        for _, hb in ipairs(self.headerCells) do
            local title = hb.col.title
            if self.sortKey == hb.col.key then
                title = title .. (self.sortAsc and " ^" or " v")
                hb.text:SetTextColor(unpack(C.accent))
            else
                hb.text:SetTextColor(unpack(C.textDim))
            end
            hb.text:SetText(title)
        end
    end

    -- Zeilen
    t.rows = {}
    for i = 1, numRows do
        local r = CreateFrame("Button", nil, t)
        r:SetHeight(rowH)
        r:SetPoint("TOPLEFT", 1, -(headerH + 1 + (i - 1) * rowH))
        r:SetPoint("RIGHT", t, "RIGHT", -18, 0)
        if r.RegisterForClicks then r:RegisterForClicks("LeftButtonUp", "RightButtonUp") end
        r.bg = r:CreateTexture(nil, "BACKGROUND")
        r.bg:SetAllPoints()
        r.bg:SetColorTexture(1, 1, 1, (i % 2 == 0) and 0.025 or 0)
        local hl = r:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.12)
        r.sel = r:CreateTexture(nil, "ARTWORK")
        r.sel:SetAllPoints()
        r.sel:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.18)
        r.sel:Hide()
        r.cells = {}
        local cx = 6
        for _, col in ipairs(cfg.columns) do
            local fs = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            fs:SetWidth(col.width - 6)
            fs:SetHeight(rowH)
            fs:SetJustifyH(col.align or "LEFT")
            fs:SetPoint("LEFT", cx, 0)
            if fs.SetWordWrap then fs:SetWordWrap(false) end
            table.insert(r.cells, fs)
            cx = cx + col.width
        end
        if cfg.action then
            local ab = UI:Button(r, cfg.action.text, actionW - 4, rowH - 4, function()
                if r.item and cfg.action.onClick then cfg.action.onClick(r.item) end
            end)
            ab:SetPoint("LEFT", cx, 0)
            ab.tooltip = cfg.action.tooltip
            r.action = ab
        end
        r:SetScript("OnClick", function(self, button)
            if not self.item then return end
            if button == "RightButton" then
                if self.item.itemID and not cfg.noMenu then UI:ShowItemMenu(self.item.itemID, self) end
                return
            end
            if cfg.onClick then
                t.selectedID = self.item[cfg.idKey or "itemID"]
                cfg.onClick(self.item)
                t:Render()
            end
        end)
        r:SetScript("OnEnter", function(self)
            if self.item and self.item.itemID and cfg.itemTooltip ~= false then
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                local ok = pcall(GameTooltip.SetHyperlink, GameTooltip, "item:" .. self.item.itemID)
                if not ok then GameTooltip:SetText(self.item.name or "") end
                if not cfg.noMenu then GameTooltip:AddLine(L["Rechtsklick: Optionen"], 0.6, 0.6, 0.6) end
                GameTooltip:Show()
            end
        end)
        r:SetScript("OnLeave", function() GameTooltip:Hide() end)
        t.rows[i] = r
    end

    -- Blättern
    t.scrollText = UI:Label(t, "", "GameFontDisableSmall", C.textDim)
    t.scrollText:SetPoint("BOTTOMRIGHT", t, "TOPRIGHT", -2, 3)
    t.scrollText:SetJustifyH("RIGHT")

    local track = t:CreateTexture(nil, "ARTWORK")
    track:SetColorTexture(1, 1, 1, 0.04)
    track:SetPoint("TOPRIGHT", -5, -(headerH + 4))
    track:SetPoint("BOTTOMRIGHT", -5, 4)
    track:SetWidth(8)
    t.thumb = t:CreateTexture(nil, "OVERLAY")
    t.thumb:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.6)
    t.thumb:SetWidth(8)
    t.trackHeight = numRows * rowH - 6

    t.empty = UI:Label(t, cfg.emptyText or L["Keine Daten."], "GameFontHighlight", C.textDim)
    t.empty:SetPoint("CENTER", 0, -10)
    t.empty:SetJustifyH("CENTER")

    t:SetScript("OnMouseWheel", function(self, delta)
        local maxOffset = math.max(0, #self.items - numRows)
        self.offset = math.min(maxOffset, math.max(0, self.offset - delta * 3))
        self:Render()
    end)

    function t:Sort()
        if not cfg.sortValue or not self.sortKey then return end
        local key, asc = self.sortKey, self.sortAsc
        table.sort(self.items, function(a, b)
            local va, vb = cfg.sortValue(a, key), cfg.sortValue(b, key)
            if va == nil and vb == nil then return (a.name or "") < (b.name or "") end
            if va == nil then return false end
            if vb == nil then return true end
            if va == vb then return (a.name or "") < (b.name or "") end
            if asc then return va < vb end
            return va > vb
        end)
    end

    function t:SetData(items, keepOffset)
        self.items = items or {}
        if not keepOffset then self.offset = 0 end
        self:Sort()
        self:Render()
    end

    function t:Render()
        local count = #self.items
        local maxOffset = math.max(0, count - numRows)
        if self.offset > maxOffset then self.offset = maxOffset end
        for i, r in ipairs(self.rows) do
            local item = self.items[self.offset + i]
            r.item = item
            if item then
                for c, col in ipairs(cfg.columns) do
                    r.cells[c]:SetText(cfg.cell(item, col.key) or "")
                end
                if r.action then r.action:Show() end
                if self.selectedID and item[cfg.idKey or "itemID"] == self.selectedID then r.sel:Show() else r.sel:Hide() end
                r:Show()
            else
                r:Hide()
            end
        end
        if count == 0 then self.empty:Show() else self.empty:Hide() end
        if count > numRows then
            local h = math.max(16, self.trackHeight * numRows / count)
            local pos = (self.trackHeight - h) * (self.offset / maxOffset)
            self.thumb:SetHeight(h)
            self.thumb:ClearAllPoints()
            self.thumb:SetPoint("TOPRIGHT", self, "TOPRIGHT", -5, -(headerH + 4 + pos))
            self.thumb:Show()
            self.scrollText:SetText(string.format(L["%d-%d von %d  (Mausrad)"], self.offset + 1, math.min(count, self.offset + numRows), count))
        else
            self.thumb:Hide()
            self.scrollText:SetText(count > 0 and (count .. L[" Einträge"]) or "")
        end
        self:UpdateHeader()
    end

    t:UpdateHeader()
    return t
end

-- Fenster mit ESC schließbar machen (jeden Namen nur einmal eintragen)
function UI:RegisterSpecial(name)
    if not (name and UISpecialFrames) then return end
    for _, n in ipairs(UISpecialFrames) do if n == name then return end end
    table.insert(UISpecialFrames, name)
end

-- ------------------------------------------------------------
-- Kleines Fenster (Optionen, Hilfe, Menü) im aktuellen Design
-- ------------------------------------------------------------
function UI:Dialog(name, width, height, titleText)
    local w = CreateFrame("Frame", name, UIParent)
    w:SetSize(width, height)
    w:SetPoint("CENTER")
    w:SetFrameStrata("DIALOG")
    w:SetToplevel(true)
    w:SetClampedToScreen(true)
    w:SetMovable(true)
    w:EnableMouse(true)
    w:RegisterForDrag("LeftButton")
    w:SetScript("OnDragStart", w.StartMoving)
    w:SetScript("OnDragStop", w.StopMovingOrSizing)
    UI:Box(w, C.bg, C.frameEdge, UI:IsClassic() and 2 or 1)
    if A.db then w:SetScale(A.db.settings.scale or 1) end
    UI:RegisterSpecial(name)
    w.title = UI:Label(w, titleText or "", "GameFontNormal", C.accent)
    w.title:SetPoint("TOPLEFT", 14, -12)
    w.close = UI:CloseButton(w, function() w:Hide() end)
    w.close:SetPoint("TOPRIGHT", -6, -6)
    return w
end

function UI:CloseButton(parent, onClick)
    if UI:IsClassic() then
        local b = CreateFrame("Button", nil, parent)
        b:SetSize(28, 28)
        b:SetNormalTexture(TEX.close)
        b:SetPushedTexture(TEX.closeDown)
        b:SetHighlightTexture(TEX.closeHL)
        b:SetScript("OnClick", onClick)
        b:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:SetText(L["Schließen (ESC)"]); GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        return b
    end
    local b = UI:Button(parent, "X", 26, 22, onClick, "danger")
    b.tooltip = L["Schließen (ESC)"]
    return b
end

-- ------------------------------------------------------------
-- Item-Suche in Eingabefeldern: Vorschläge beim Tippen (jede Sprache),
-- Shift-Klick auf ein Item fügt es ein.
-- opts = { onPick = function(itemID) end, suggest = true/false }
-- ------------------------------------------------------------
local function ChainScript(frame, script, fn)
    local prev = frame:GetScript(script)
    frame:SetScript(script, function(...)
        if prev then prev(...) end
        fn(...)
    end)
end

function UI:AttachItemSearch(box, opts)
    opts = opts or {}
    box.acceptsItemLinks = true
    box.itemOpts = opts
    ChainScript(box, "OnTextChanged", function(self, userInput)
        if self.itemID and self:GetText() ~= self.itemText then self.itemID = nil end
        if userInput and opts.suggest ~= false then UI:UpdateSuggest(self) end
    end)
    ChainScript(box, "OnEditFocusLost", function(self)
        if C_Timer and C_Timer.After then
            C_Timer.After(0.3, function()
                if UI.suggest and UI.suggest.box == self then UI.suggest:Hide() end
            end)
        end
    end)
    ChainScript(box, "OnEscapePressed", function() UI:HideSuggest() end)
    return box
end

-- Text oder (wenn ein Vorschlag/Link gewählt wurde) die Item-ID
function UI:GetItemInput(box)
    if box.itemID and box:GetText() == box.itemText then return tostring(box.itemID) end
    return box:GetText()
end

function UI:SetItemInput(box, itemID)
    local name = A:GetItemName(itemID)
    box.itemText = name
    box:SetText(name)
    box.itemID = itemID
    if box.UpdatePlaceholder then box:UpdatePlaceholder() end
end

function UI:PickSuggestion(box, itemID)
    self:SetItemInput(box, itemID)
    self:HideSuggest()
    if box.itemOpts and box.itemOpts.onPick then box.itemOpts.onPick(itemID) end
end

function UI:HideSuggest()
    if self.suggest then self.suggest:Hide() end
end

function UI:UpdateSuggest(box)
    local text = box:GetText() or ""
    local results = (A.Names and string.len(text) >= 2) and A.Names:Search(text, 8) or {}
    if #results == 0 or (A.Names:ParseID(text) and #results == 1) then
        self:HideSuggest()
        return
    end
    if not self.suggest then
        local s = CreateFrame("Frame", "AHAnalyzerProSuggest", UIParent)
        s:SetFrameStrata("FULLSCREEN_DIALOG")
        s:SetClampedToScreen(true)
        s:EnableMouse(true)
        UI:Box(s, C.bg, C.frameEdge)
        s.rows = {}
        for i = 1, 8 do
            local b = CreateFrame("Button", nil, s)
            b:SetHeight(20)
            b:SetPoint("TOPLEFT", 4, -4 - (i - 1) * 20)
            b:SetPoint("RIGHT", s, "RIGHT", -4, 0)
            b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            b.text:SetPoint("LEFT", 6, 0)
            b.text:SetPoint("RIGHT", -6, 0)
            b.text:SetJustifyH("LEFT")
            if b.text.SetWordWrap then b.text:SetWordWrap(false) end
            local hl = b:CreateTexture(nil, "HIGHLIGHT")
            hl:SetAllPoints()
            hl:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.2)
            b:SetScript("OnClick", function(self)
                if self.itemID and UI.suggest.box then UI:PickSuggestion(UI.suggest.box, self.itemID) end
            end)
            s.rows[i] = b
        end
        self.suggest = s
    end
    local s = self.suggest
    s.box = box
    s:SetScale(box:GetEffectiveScale() and (box:GetEffectiveScale() / (UIParent:GetEffectiveScale() or 1)) or 1)
    s:ClearAllPoints()
    s:SetPoint("TOPLEFT", box, "BOTTOMLEFT", 0, -2)
    s:SetWidth(math.max(280, box:GetWidth() or 0))
    local display = A.Names:DisplayLocale()
    for i, b in ipairs(s.rows) do
        local r = results[i]
        if r then
            local label = r.name
            if r.matched and r.matched ~= r.name then
                label = label .. "  |cff888888(" .. r.matched .. ", " .. A.Names:LocaleLabel(r.matchedLocale) .. ")|r"
            end
            b.text:SetText(label)
            b.itemID = r.itemID
            b:Show()
        else
            b.itemID = nil
            b:Hide()
        end
    end
    s:SetHeight(8 + math.min(#results, 8) * 20)
    s:Show()
end

-- Shift-Klick auf ein Item (Taschen, Chat, Auktionshaus) fügt es in ein aktives Suchfeld ein
function UI:OnInsertLink(link)
    if type(link) ~= "string" then return end
    local box = GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus()
    if not (box and box.acceptsItemLinks) then return end
    local id = A.Names and A.Names:ParseID(link)
    if not id then return end
    local name = link:match("|h%[(.-)%]|h") or link:match("%[(.-)%]")
    if name then A.Names:Learn(id, name) end
    self:PickSuggestion(box, id)
    if box.itemOpts and box.itemOpts.onLink then box.itemOpts.onLink(id) end
end

if hooksecurefunc then
    if ChatEdit_InsertLink then
        pcall(hooksecurefunc, "ChatEdit_InsertLink", function(link) UI:OnInsertLink(link) end)
    end
    if ChatFrameUtil and ChatFrameUtil.InsertLink then
        pcall(hooksecurefunc, ChatFrameUtil, "InsertLink", function(link) UI:OnInsertLink(link) end)
    end
end

-- ------------------------------------------------------------
-- Tab-Verwaltung
-- builder(parent) muss ein Frame zurückgeben. Optional: frame:Refresh()
-- ------------------------------------------------------------
UI.tabs = {}
UI.activeTab = nil

function UI:RegisterTab(id, label, order, builder)
    for _, tab in ipairs(self.tabs) do
        if tab.id == id then return end
    end
    table.insert(self.tabs, { id = id, label = label, order = order or 99, builder = builder })
    table.sort(self.tabs, function(a, b) return a.order < b.order end)
    if self.frame then self:BuildTabBar() end
end

-- Kurzform, falls andere Dateien A:RegisterTab benutzen
function A:RegisterTab(id, label, order, builder)
    UI:RegisterTab(id, label, order, builder)
end

function UI:GetTab(id)
    for _, tab in ipairs(self.tabs) do
        if tab.id == id then return tab end
    end
end

function UI:GetTabDebug()
    local names = {}
    for _, tab in ipairs(self.tabs) do
        table.insert(names, tab.id .. (tab.panel and L["(geladen)"] or ""))
    end
    return #self.tabs .. L[" registriert: "] .. table.concat(names, ", ") .. L["  |  aktiv: "] .. tostring(self.activeTab)
        .. L["  |  Design: "] .. self.theme
end

-- Klassischer Reiter (wie unten am Auktionshaus)
local function ClassicTab(bar, label)
    local b = CreateFrame("Button", nil, bar)
    b:SetHeight(32)
    b.text = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    b.text:SetPoint("CENTER", 0, 2)
    b.text:SetText(label)
    b:SetWidth(math.max(86, (b.text:GetStringWidth() or 60) + 40))
    b.parts = {}
    local coords = { { 0, 0.15625 }, { 0.15625, 0.84375 }, { 0.84375, 1 } }
    for i = 1, 3 do
        local tex = b:CreateTexture(nil, "BACKGROUND")
        tex:SetTexCoord(coords[i][1], coords[i][2], 0, 1)
        tex:SetHeight(32)
        b.parts[i] = tex
    end
    b.parts[1]:SetPoint("TOPLEFT"); b.parts[1]:SetWidth(20)
    b.parts[3]:SetPoint("TOPRIGHT"); b.parts[3]:SetWidth(20)
    b.parts[2]:SetPoint("TOPLEFT", b.parts[1], "TOPRIGHT")
    b.parts[2]:SetPoint("TOPRIGHT", b.parts[3], "TOPLEFT")
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetPoint("TOPLEFT", 10, -4); hl:SetPoint("BOTTOMRIGHT", -10, 6)
    hl:SetColorTexture(1, 0.82, 0, 0.12)
    function b:SetSelected(on)
        for _, tex in ipairs(self.parts) do tex:SetTexture(on and TEX.tabActive or TEX.tabInactive) end
        self.text:SetTextColor(unpack(on and { 1, 1, 1, 1 } or C.accent))
    end
    return b
end

-- Moderner Reiter (oben, Linie unter dem aktiven). compact = kleinere Schrift (im Auktionshaus)
local function ModernTab(bar, label, compact)
    local b = CreateFrame("Button", nil, bar)
    b:SetHeight(30)
    b.text = b:CreateFontString(nil, "OVERLAY", compact and "GameFontHighlightSmall" or "GameFontHighlight")
    b.text:SetPoint("CENTER", 0, 1)
    b.text:SetText(label)
    b:SetWidth(math.max(compact and 60 or 90, (b.text:GetStringWidth() or 60) + (compact and 20 or 28)))
    b.line = b:CreateTexture(nil, "OVERLAY")
    b.line:SetColorTexture(unpack(C.accent))
    b.line:SetPoint("BOTTOMLEFT"); b.line:SetPoint("BOTTOMRIGHT"); b.line:SetHeight(2)
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.05)
    function b:SetSelected(on)
        if on then self.line:Show() else self.line:Hide() end
        self.text:SetTextColor(unpack(on and C.accent or C.textDim))
    end
    return b
end

-- ------------------------------------------------------------
-- Anzeigeorte: eigenes Fenster (self.frame) oder eingebettet ins
-- Auktionshaus (self.ahHost). Die Reiter-Inhalte werden umgehängt.
-- ------------------------------------------------------------
function UI:Host()
    if self.ahOverlay and self.ahOverlay:IsVisible() then return self.ahHost end
    return self.frame
end

function UI:IsVisible()
    if self.ahOverlay and self.ahOverlay:IsVisible() then return true end
    return (self.frame and self.frame:IsShown()) and true or false
end

function UI:AttachPanels(host)
    if not host then return end
    for _, tab in ipairs(self.tabs) do
        if tab.panel and tab.panel:GetParent() ~= host.content then
            tab.panel:SetParent(host.content)
            tab.panel:ClearAllPoints()
            tab.panel:SetAllPoints(host.content)
        end
    end
end

function UI:BuildTabBar(host)
    host = host or self.frame
    if not host then return end
    local bar = host.tabBar
    if bar.buttons then
        for _, b in ipairs(bar.buttons) do b:Hide() end
    end
    bar.buttons = {}
    -- eingebettet: Reiter immer oben (unten sitzen die Reiter des Auktionshauses)
    local classic = self:IsClassic() and not host.embedded
    local x0 = classic and 14 or (host.embedded and 0 or 12)
    local gap = classic and -8 or 4
    local total = 0
    for _, tab in ipairs(self.tabs) do
        local b = classic and ClassicTab(bar, L[tab.label]) or ModernTab(bar, L[tab.label], host.embedded)
        b.tabID = tab.id
        b:SetScript("OnClick", function() UI:SelectTab(tab.id) end)
        table.insert(bar.buttons, b)
        total = total + b:GetWidth() + gap
    end
    -- zu wenig Platz (z.B. im Auktionshaus, rechts sitzen Scan/Optionen/Hilfe): Reiter schmaler machen
    local avail = (host.TabSpace and host:TabSpace()) or ((host:GetWidth() or 960) - 2 * x0)
    if total > avail and #bar.buttons > 0 then
        local factor = avail / total
        for _, b in ipairs(bar.buttons) do
            local minW = (b.text and b.text.GetStringWidth and b.text:GetStringWidth() or 40) + 12
            b:SetWidth(math.max(minW, math.floor(b:GetWidth() * factor)))
        end
    end
    local x = x0
    for _, b in ipairs(bar.buttons) do
        if classic then b:SetPoint("TOPLEFT", x, 0) else b:SetPoint("BOTTOMLEFT", x, 0) end
        x = x + b:GetWidth() + gap
    end
    bar.usedWidth = x - gap
    self:UpdateTabBar()
end

function UI:UpdateTabBar()
    for _, host in ipairs({ self.frame or false, self.ahHost or false }) do
        if host and host.tabBar.buttons then
            for _, b in ipairs(host.tabBar.buttons) do
                b:SetSelected(b.tabID == self.activeTab)
            end
        end
    end
end

function UI:SelectTab(id)
    local host = self:Host() or self:EnsureFrame()
    self:AttachPanels(host)
    local target
    for _, tab in ipairs(self.tabs) do
        if tab.id == id then target = tab end
        if tab.panel then tab.panel:Hide() end
    end
    if not target then return end

    if not target.panel then
        local ok, panelOrErr = pcall(target.builder, host.content)
        if ok and panelOrErr then
            target.panel = panelOrErr
            target.panel:SetAllPoints(host.content)
        else
            local errFrame = CreateFrame("Frame", nil, host.content)
            errFrame:SetAllPoints()
            local msg = UI:Label(errFrame, L["Dieser Tab konnte nicht geladen werden:\n\n"] .. tostring(panelOrErr), "GameFontHighlight", C.red)
            msg:SetPoint("CENTER")
            msg:SetJustifyH("CENTER")
            target.panel = errFrame
            A:Print(L["Fehler im Tab '"] .. id .. "': " .. tostring(panelOrErr))
        end
    end

    self.activeTab = id
    if A.db then A.db.settings.lastTab = id end
    target.panel:Show()
    self:RefreshActive()
    self:UpdateTabBar()
    return target.panel
end

function UI:RefreshActive()
    if not self:IsVisible() then return end
    for _, tab in ipairs(self.tabs) do
        if tab.id == self.activeTab and tab.panel and tab.panel.Refresh then
            local ok, err = pcall(tab.panel.Refresh, tab.panel)
            if not ok then A:Print(L["Fehler beim Aktualisieren ('"] .. tab.id .. "'): " .. tostring(err)) end
        end
    end
    self:UpdateStatus()
end

-- ------------------------------------------------------------
-- Hauptfenster
-- ------------------------------------------------------------
function UI:EnsureFrame()
    if self.frame then return self.frame end
    if A.db then self:ApplyPalette(A.db.settings.theme or "classic") end
    local classic = self:IsClassic()

    local f = CreateFrame("Frame", "AHAnalyzerProWindow", UIParent)
    f:SetSize(960, 640)
    f:SetPoint("CENTER")
    f:SetFrameStrata("HIGH")
    f:SetToplevel(true)
    f:SetClampedToScreen(true)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:Hide()
    UI:Box(f, C.bg, C.frameEdge, classic and 3 or 1)
    UI:RegisterSpecial("AHAnalyzerProWindow")
    if A.db then f:SetScale(A.db.settings.scale or 1) end

    local pos = A.db and A.db.settings.windowPos
    if pos then
        f:ClearAllPoints()
        f:SetPoint(pos.point or "CENTER", UIParent, pos.relPoint or "CENTER", pos.x or 0, pos.y or 0)
    end

    -- Titelleiste
    local title = CreateFrame("Frame", nil, f)
    title:SetPoint("TOPLEFT", classic and 3 or 0, classic and -3 or 0)
    title:SetPoint("TOPRIGHT", classic and -3 or 0, classic and -3 or 0)
    title:SetHeight(classic and 36 or 40)
    UI:Box(title, C.bar)
    if classic then
        local line = title:CreateTexture(nil, "ARTWORK")
        line:SetColorTexture(unpack(C.border))
        line:SetPoint("BOTTOMLEFT"); line:SetPoint("BOTTOMRIGHT"); line:SetHeight(2)
    end
    title:EnableMouse(true)
    title:RegisterForDrag("LeftButton")
    title:SetScript("OnDragStart", function() f:StartMoving() end)
    title:SetScript("OnDragStop", function()
        f:StopMovingOrSizing()
        local point, _, relPoint, x, y = f:GetPoint()
        if A.db then A.db.settings.windowPos = { point = point, relPoint = relPoint, x = x, y = y } end
    end)

    local icon = title:CreateTexture(nil, "ARTWORK")
    icon:SetSize(22, 22)
    icon:SetPoint("LEFT", 12, 0)
    icon:SetTexture("Interface\\Icons\\INV_Misc_Coin_02")
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local t = UI:Label(title, "AH Analyzer Pro", classic and "GameFontNormal" or "GameFontNormalLarge", C.accent)
    if classic then t:SetPoint("CENTER", 0, 0) else t:SetPoint("LEFT", icon, "RIGHT", 10, 0) end
    local v = UI:Label(title, "v" .. A.version, "GameFontDisableSmall", C.textDim)
    v:SetPoint("LEFT", t, "RIGHT", 8, -1)

    local close = UI:CloseButton(title, function() f:Hide() end)
    close:SetPoint("RIGHT", classic and -2 or -8, 0)

    f.optionsButton = UI:Button(title, L["Optionen"], 80, 22, function() UI:ToggleOptions() end)
    f.optionsButton:SetPoint("RIGHT", close, "LEFT", classic and -4 or -6, 0)
    f.optionsButton.tooltip = L["Design (Klassisch/Modern), Fenstergröße, Ton, Preis-Sync, Sniper-Tempo, CSV-Export"]

    f.helpButton = UI:Button(title, "?", 24, 22, function() UI:ShowHelp() end)
    f.helpButton:SetPoint("RIGHT", f.optionsButton, "LEFT", -4, 0)
    f.helpButton.tooltip = L["Hilfe zu diesem Tab"]

    -- Statusleiste
    local status = CreateFrame("Frame", nil, f)
    status:SetPoint("BOTTOMLEFT", classic and 3 or 0, classic and 3 or 0)
    status:SetPoint("BOTTOMRIGHT", classic and -3 or 0, classic and 3 or 0)
    status:SetHeight(34)
    UI:Box(status, C.bar)
    if classic then
        local line = status:CreateTexture(nil, "ARTWORK")
        line:SetColorTexture(unpack(C.border))
        line:SetPoint("TOPLEFT"); line:SetPoint("TOPRIGHT"); line:SetHeight(2)
    end
    f.statusDot = status:CreateTexture(nil, "ARTWORK")
    f.statusDot:SetSize(8, 8)
    f.statusDot:SetPoint("LEFT", 14, 0)
    f.statusText = UI:Label(status, "", "GameFontHighlightSmall", C.textDim)
    f.statusText:SetPoint("LEFT", f.statusDot, "RIGHT", 8, 0)

    f.scanButton = UI:Button(status, L["Markt scannen"], 200, 24, function() A:StartFullScan() end, "primary")
    f.scanButton:SetPoint("RIGHT", -8, 0)
    f.scanButton.tooltip = L["Scannt das ganze Auktionshaus.\nDer Server erlaubt das nur alle 15 Minuten."]

    -- Tab-Leiste: klassisch unten am Fenster (wie das Auktionshaus), modern oben
    local tabBar = CreateFrame("Frame", nil, f)
    if classic then
        tabBar:SetPoint("TOPLEFT", f, "BOTTOMLEFT", 0, 2)
        tabBar:SetPoint("TOPRIGHT", f, "BOTTOMRIGHT", 0, 2)
        tabBar:SetHeight(32)
    else
        tabBar:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, 0)
        tabBar:SetPoint("TOPRIGHT", title, "BOTTOMRIGHT", 0, 0)
        tabBar:SetHeight(34)
        local tabLine = tabBar:CreateTexture(nil, "ARTWORK")
        tabLine:SetColorTexture(unpack(C.border))
        tabLine:SetPoint("BOTTOMLEFT"); tabLine:SetPoint("BOTTOMRIGHT"); tabLine:SetHeight(1)
    end
    f.tabBar = tabBar

    -- Inhaltsbereich
    local content = CreateFrame("Frame", nil, f)
    if classic then
        content:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 12, -14)
    else
        content:SetPoint("TOPLEFT", tabBar, "BOTTOMLEFT", 14, -12)
    end
    content:SetPoint("BOTTOMRIGHT", status, "TOPRIGHT", -14, 10)
    f.content = content

    -- Status regelmäßig aktualisieren (nur wenn sichtbar)
    local elapsed = 0
    f:SetScript("OnUpdate", function(_, dt)
        elapsed = elapsed + (dt or 0)
        if elapsed >= 0.5 then
            elapsed = 0
            UI:UpdateStatus()
        end
    end)
    f:SetScript("OnShow", function() UI:RefreshActive() end)
    f:SetScript("OnHide", function() UI:HideMenu(); UI:HideSuggest() end)

    self.frame = f
    self:BuildTabBar()
    return f
end

local function UpdateScanButton(b)
    if not b then return nil end
    if A:IsScanning() then
        b:SetText(L["Scan läuft ... "] .. (A.scanState.lastCount and A.scanState.lastCount > 0 and A.scanState.lastCount or ""))
        b:SetActive(false)
        return C.yellow
    elseif not A:IsScanReady() then
        b:SetText(L["Nächster Scan in "] .. A:FormatDuration(A:GetCooldownRemaining()))
        b:SetActive(false)
        return C.red
    end
    local ahOpen = A:IsAHOpen()
    b:SetText(ahOpen and L["Markt scannen"] or L["Markt scannen (AH öffnen)"])
    b:SetActive(true)
    return ahOpen and C.green or C.textDim
end

function UI:UpdateStatus()
    if not A.db then return end
    if self.ahHost then UpdateScanButton(self.ahHost.scanButton) end
    local f = self.frame
    if f then
        local ahOpen = A:IsAHOpen()
        local items = A:CountTable(A.db.marketData)
        local text = (ahOpen and L["|cff33dd55Auktionshaus offen|r"] or L["|cffff5544Auktionshaus geschlossen|r"])
            .. "   |   " .. items .. L[" Items   |   letzter Scan "] .. A:FormatAgo(A.db.lastScanTime)
        if A.Sync then
            text = text .. "   |   " .. A.Sync:GetStatusText()
        end
        if A.Sniper and A.db.sniper and A.db.sniper.armed then
            text = text .. L["   |   |cff33dd55Sniper an|r"]
        end
        f.statusText:SetText(text)
        f.statusDot:SetColorTexture(unpack(UpdateScanButton(f.scanButton)))
    end
    if self.options and self.options:IsShown() then self.options:Refresh() end
end

-- Öffnen: bei offenem Auktionshaus im Auktionshaus-Fenster, sonst im eigenen Fenster
function UI:Show()
    if self:CanIntegrate() and self:ShowInAH() then return end
    self:EnsureFrame()
    self:AttachPanels(self.frame)
    self.frame:Show()
    self:AfterShow()
end

function UI:AfterShow()
    if not self.activeTab and self.tabs[1] then
        local last = A.db and A.db.settings.lastTab
        self:SelectTab((last and self:GetTab(last)) and last or self.tabs[1].id)
    else
        self:SelectTab(self.activeTab)
    end
    -- Beim allerersten Öffnen kurz erklären, wie alles funktioniert
    if A.db and not A.db.settings.helpSeen then
        A.db.settings.helpSeen = true
        self:ShowHelp("start")
    end
end

function UI:Hide()
    if self.frame then self.frame:Hide() end
    if self.ahOverlay and self.ahOverlay:IsVisible() then self:LeaveAH() end
end

function UI:Toggle()
    if self:IsVisible() then self:Hide() else self:Show() end
end

function UI:ResetPosition()
    if A.db then A.db.settings.windowPos = nil end
    if self.frame then
        self.frame:ClearAllPoints()
        self.frame:SetPoint("CENTER")
    end
end

-- Kurzformen für Button & Befehle
function A:ToggleMainWindow() UI:Toggle() end
function A:ShowMainWindow() UI:Show() end

-- Von anderen Tabs aus zu einem Item im Chart springen
function UI:OpenChart(itemID)
    self:Show()
    self.pendingChartItem = itemID
    self:SelectTab("charts")
end

-- Item als Sniper-Ziel vorbereiten (Formular ausfüllen)
function UI:OpenSniperFor(itemID)
    self:Show()
    local panel = self:SelectTab("sniper")
    if panel and panel.Prefill then panel:Prefill(itemID) end
end

-- ------------------------------------------------------------
-- Einbindung ins Auktionshaus-Fenster
--   * zusätzlicher Reiter "AH Analyzer" unten neben Kaufen / Verkaufen / Auktionen
--   * ein Klick zeigt das ganze Addon im Auktionshaus-Fenster (über dem Blizzard-Inhalt)
--   * ein Klick auf einen Blizzard-Reiter schaltet zurück
-- Es werden keine Blizzard-Funktionen ersetzt, nur ergänzt (hooksecurefunc),
-- damit Kaufen & Co. im Auktionshaus weiter ohne Fehler funktionieren.
-- ------------------------------------------------------------
local AH_W, AH_H = 944, 544     -- Größe der eingebetteten Ansicht vor dem Einpassen

-- nur echte Fenster-Objekte (Tabellen) zählen
local function IsWidget(x) return type(x) == "table" end

-- Auktionshaus-Fenster: modern (AuctionHouseFrame) oder altes Classic-Fenster (AuctionFrame)
local function AHFrame()
    if IsWidget(AuctionHouseFrame) then return AuctionHouseFrame, "modern" end
    if IsWidget(AuctionFrame) then return AuctionFrame, "legacy" end
    return nil
end
UI.AHFrame = AHFrame

function UI:CanIntegrate()
    return A.db ~= nil and A.db.settings.ahIntegration ~= false and AHFrame() ~= nil and A:IsAHOpen()
end

-- Blizzard-Reiter des Auktionshauses (ohne unseren eigenen)
local function AHTabs(exclude)
    local ah, kind = AHFrame()
    local list = {}
    local function add(t)
        if IsWidget(t) and t ~= UI.ahTab and t ~= exclude then table.insert(list, t) end
    end
    if ah and type(ah.Tabs) == "table" then
        for _, t in ipairs(ah.Tabs) do add(t) end
    end
    if #list == 0 then
        local prefix = (kind == "legacy") and "AuctionFrameTab" or "AuctionHouseFrameTab"
        for i = 1, 8 do add(_G[prefix .. i]) end
    end
    if #list == 0 and ah then
        for _, n in ipairs({ "BuyTab", "SellTab", "AuctionsTab" }) do add(ah[n]) end
    end
    return list
end

local function AHSearchBar()
    local ah = AHFrame()
    local sb = ah and ah.SearchBar
    if IsWidget(sb) then return sb end
    return nil
end

local TAB_TEMPLATES = {
    "AuctionHouseFrameDisplayModeTabTemplate",
    "AuctionHouseFrameTabTemplate",
    "AuctionTabTemplate",
    "PanelTabButtonTemplate",
    "CharacterFrameTabButtonTemplate",
}

-- Fehler bei der Einbindung einmal melden und für /ahp ahdebug merken
function UI:ReportAHError(err)
    self.ahLastError = tostring(err)
    if not self.ahErrorShown then
        self.ahErrorShown = true
        A:Print(L["AH-Einbindung fehlgeschlagen: "] .. self.ahLastError .. "  (/ahp ahdebug)")
    end
end

function UI:EnsureAHTab()
    local ah, kind = AHFrame()
    if not ah then return nil end
    if self.ahTab then
        self.ahTab:Show()
        return self.ahTab
    end
    -- vorhandene Reiter VOR dem Erzeugen merken: manche Blizzard-Vorlagen tragen
    -- einen neuen Reiter selbst in die Reiterliste ein
    local tabs = AHTabs()
    local last = tabs[#tabs]

    local b
    for _, tpl in ipairs(TAB_TEMPLATES) do
        local ok, f = pcall(CreateFrame, "Button", "AHAnalyzerProAHTab", ah, tpl)
        if ok and f then
            b = f
            b.template = tpl
            break
        end
    end
    -- unseren Reiter wieder aus Blizzards Reiterliste nehmen, damit Blizzard ihn nicht verwaltet
    if b and type(ah.Tabs) == "table" then
        for i = #ah.Tabs, 1, -1 do
            if ah.Tabs[i] == b then table.remove(ah.Tabs, i) end
        end
    end
    if b then
        b:SetText("AH Analyzer")
        if PanelTemplates_TabResize then pcall(PanelTemplates_TabResize, b, 0) end
        if (b:GetWidth() or 0) < 40 then b:SetWidth(110) end
    else
        b = ClassicTab(ah, "AH Analyzer")      -- Rückfall: eigener Reiter im gleichen Stil
        b:SetSelected(false)
    end
    -- rechts neben den letzten Blizzard-Reiter (auch Reiter anderer Addons)
    b:ClearAllPoints()
    if last and last ~= b then
        b:SetPoint("LEFT", last, "RIGHT", 3, 0)
    else
        b:SetPoint("TOPLEFT", ah, "BOTTOMLEFT", 20, 2)
    end
    b:SetScript("OnClick", function()
        local ok, err = pcall(UI.ShowInAH, UI)
        if not ok then UI:ReportAHError(err) end
    end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("AH Analyzer Pro")
        GameTooltip:AddLine(L["Scan, Preisverlauf, Watchlist, Sniper und mehr - hier im Auktionshaus"], 1, 1, 1, true)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:Show()
    self.ahTab = b

    -- Klick auf einen Blizzard-Reiter: zurück zur Blizzard-Ansicht (nur einmal einhängen)
    if not self.ahHooked then
        self.ahHooked = true
        if ah.SetDisplayMode and hooksecurefunc then
            pcall(hooksecurefunc, ah, "SetDisplayMode", function() UI:OnBlizzardView() end)
        end
        if kind == "legacy" and AuctionFrameTab_OnClick and hooksecurefunc then
            pcall(hooksecurefunc, "AuctionFrameTab_OnClick", function() UI:OnBlizzardView() end)
        end
        for _, t in ipairs(tabs) do
            if t.HookScript then pcall(t.HookScript, t, "OnClick", function() UI:OnBlizzardView() end) end
        end
    end
    return b
end

function UI:SetAHTabSelected(on)
    local b = self.ahTab
    if not b then return end
    if b.template and PanelTemplates_SelectTab and PanelTemplates_DeselectTab then
        pcall(on and PanelTemplates_SelectTab or PanelTemplates_DeselectTab, b)
    elseif b.SetSelected then
        b:SetSelected(on)
    end
    if on and PanelTemplates_DeselectTab then
        for _, t in ipairs(AHTabs(b)) do pcall(PanelTemplates_DeselectTab, t) end
    end
end

-- Blizzard hat selbst eine Ansicht gewählt (Kaufen, Verkaufen, Auktionen)
function UI:OnBlizzardView()
    self.searchBarHidden = false          -- Blizzard kümmert sich selbst um seine Suchleiste
    if self.ahOverlay and self.ahOverlay:IsShown() then
        self.ahOverlay:Hide()
        self:SetAHTabSelected(false)
        self:HideMenu()
        self:HideSuggest()
    end
end

function UI:EnsureAHHost()
    if self.ahHost then return self.ahHost end
    local ah, kind = AHFrame()
    -- Abdeckung über dem Blizzard-Inhalt (unterhalb von Titel und Porträt)
    local o = CreateFrame("Frame", "AHAnalyzerProAHPanel", ah)
    if kind == "legacy" then
        o:SetPoint("TOPLEFT", ah, "TOPLEFT", 20, -74)
        o:SetPoint("BOTTOMRIGHT", ah, "BOTTOMRIGHT", -8, 14)
    else
        o:SetPoint("TOPLEFT", ah, "TOPLEFT", 6, -58)
        o:SetPoint("BOTTOMRIGHT", ah, "BOTTOMRIGHT", -6, 6)
    end
    if ah.GetFrameLevel then o:SetFrameLevel((ah:GetFrameLevel() or 1) + 30) end
    o:EnableMouse(true)
    o:EnableMouseWheel(true)
    UI:Box(o, C.bg, C.border)
    o:Hide()

    local h = CreateFrame("Frame", nil, o)
    h:SetSize(AH_W, AH_H)
    h:SetPoint("TOPLEFT", 0, 0)
    h.embedded = true

    -- Reiter des Addons oben, rechts daneben Scan, Optionen, Hilfe
    local tb = CreateFrame("Frame", nil, h)
    tb:SetPoint("TOPLEFT", 6, -2)
    tb:SetPoint("TOPRIGHT", -6, -2)
    tb:SetHeight(32)
    local line = tb:CreateTexture(nil, "ARTWORK")
    line:SetColorTexture(unpack(C.border))
    line:SetPoint("BOTTOMLEFT"); line:SetPoint("BOTTOMRIGHT"); line:SetHeight(1)
    h.tabBar = tb

    h.scanButton = UI:Button(tb, L["Markt scannen"], 150, 24, function() A:StartFullScan() end, "primary")
    h.scanButton:SetPoint("RIGHT", 0, 3)
    h.scanButton.tooltip = L["Scannt das ganze Auktionshaus.\nDer Server erlaubt das nur alle 15 Minuten."]
    -- Optionen als Zahnrad (spart Platz für die Reiter in allen Sprachen)
    h.optionsButton = UI:Button(tb, "", 24, 24, function() UI:ToggleOptions() end)
    h.optionsButton:SetPoint("RIGHT", h.scanButton, "LEFT", -6, 0)
    h.optionsButton.tooltip = L["Optionen"]
    h.optionsButton.icon = h.optionsButton:CreateTexture(nil, "OVERLAY")
    h.optionsButton.icon:SetTexture("Interface\\Icons\\INV_Misc_Gear_01")
    h.optionsButton.icon:SetPoint("CENTER")
    h.optionsButton.icon:SetSize(18, 18)
    if h.optionsButton.icon.SetTexCoord then h.optionsButton.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92) end
    h.helpButton = UI:Button(tb, "?", 24, 24, function() UI:ShowHelp() end)
    h.helpButton:SetPoint("RIGHT", h.optionsButton, "LEFT", -4, 0)
    h.helpButton.tooltip = L["Hilfe zu diesem Tab"]
    -- Platz für die Reiter: Breite der Leiste minus Scan, Optionen und Hilfe
    function h:TabSpace() return (AH_W - 12) - (150 + 6 + 24 + 4 + 24) - 10 end

    local content = CreateFrame("Frame", nil, h)
    content:SetPoint("TOPLEFT", tb, "BOTTOMLEFT", 0, -8)
    content:SetSize(932, 500)
    h.content = content

    -- in den verfügbaren Platz einpassen (Seitenverhältnis bleibt)
    local function fit()
        local w, hh = o:GetWidth(), o:GetHeight()
        if not w or not hh or w <= 0 or hh <= 0 then return end
        local s = math.min(w / AH_W, hh / AH_H)
        h:SetScale(s)
        h:ClearAllPoints()
        h:SetPoint("TOPLEFT", o, "TOPLEFT", math.max(0, (w / s - AH_W) / 2), 0)
    end
    o:SetScript("OnShow", function() fit(); UI:RefreshActive() end)
    o:SetScript("OnSizeChanged", fit)
    o:SetScript("OnHide", function() UI:HideMenu(); UI:HideSuggest() end)
    local elapsed = 0
    o:SetScript("OnUpdate", function(_, dt)
        elapsed = elapsed + (dt or 0)
        if elapsed >= 0.5 then
            elapsed = 0
            UI:UpdateStatus()
        end
    end)

    self.ahOverlay, self.ahHost = o, h
    self:BuildTabBar(h)
    return h
end

function UI:ShowInAH()
    if not self:CanIntegrate() then return false end
    self:EnsureAHTab()
    local host = self:EnsureAHHost()
    if self.frame and self.frame:IsShown() then self.frame:Hide() end
    -- Blizzard-Suchleiste über dem Inhalt ausblenden, solange unsere Ansicht offen ist
    local sb = AHSearchBar()
    if sb and sb:IsShown() then
        sb:Hide()
        self.searchBarHidden = true
    end
    self.ahOverlay:Show()
    self:SetAHTabSelected(true)
    self:AttachPanels(host)
    self:AfterShow()
    return true
end

-- zurück zur Blizzard-Ansicht "Kaufen"
function UI:LeaveAH()
    if not self.ahOverlay then return end
    self.ahOverlay:Hide()
    self:SetAHTabSelected(false)
    local first = AHTabs()[1]
    if first and first.Click then pcall(first.Click, first) end
    self:RestoreSearchBar()
end

function UI:RestoreSearchBar()
    local sb = AHSearchBar()
    if self.searchBarHidden and sb then sb:Show() end
    self.searchBarHidden = false
end

function UI:OnAHClosed()
    if self.ahOverlay then
        self.ahOverlay:Hide()
        self:SetAHTabSelected(false)
    end
    self:RestoreSearchBar()
end

function UI:OnAHOpened(attempt)
    if not (A.db and A.db.settings.ahIntegration ~= false) then return end
    attempt = attempt or 1
    if not AHFrame() then
        -- das Auktionshaus-Fenster lädt Blizzard erst beim Öffnen: mehrmals nachsehen
        if attempt < 20 and C_Timer and C_Timer.After then
            C_Timer.After(0.25, function() if A:IsAHOpen() then UI:OnAHOpened(attempt + 1) end end)
        end
        return
    end
    self:HookAHFrame()
    local ok, err = pcall(self.EnsureAHTab, self)
    if not ok then return self:ReportAHError(err) end
    -- eigenes Fenster war offen: direkt ins Auktionshaus umziehen
    if self.frame and self.frame:IsShown() then
        local ok2, err2 = pcall(self.ShowInAH, self)
        if not ok2 then self:ReportAHError(err2) end
    end
end

-- Öffnen/Schließen direkt am Auktionshaus-Fenster erkennen
-- (falls der Client die Auktionshaus-Ereignisse anders oder gar nicht meldet)
function UI:HookAHFrame()
    local ah = AHFrame()
    if not ah or self.ahFrameHooked == ah or not ah.HookScript then return end
    self.ahFrameHooked = ah
    pcall(ah.HookScript, ah, "OnShow", function() A:SetAHOpenState(true) end)
    pcall(ah.HookScript, ah, "OnHide", function() A:SetAHOpenState(false) end)
end

-- Diagnose: /ahp ahdebug
function UI:PrintAHDebug()
    local ah, kind = AHFrame()
    local function yn(v) return v and "ja" or "nein" end
    A:Print("AH-Einbindung: " .. yn(A.db and A.db.settings.ahIntegration ~= false) .. ", AH offen: " .. yn(A:IsAHOpen())
        .. " (Ereignis: " .. tostring(A.ahOpen) .. ")")
    if not ah then
        A:Print("Auktionshaus-Fenster: nicht gefunden (AuctionHouseFrame=" .. type(AuctionHouseFrame) .. ", AuctionFrame=" .. type(AuctionFrame) .. ")")
    else
        local w, h = ah:GetWidth(), ah:GetHeight()
        A:Print("Fenster: " .. tostring(ah.GetName and ah:GetName()) .. " (" .. kind .. "), Größe " .. math.floor(w or 0) .. "x" .. math.floor(h or 0)
            .. ", sichtbar " .. yn(ah:IsShown()) .. ", SetDisplayMode " .. yn(ah.SetDisplayMode) .. ", Suchleiste " .. yn(AHSearchBar()))
        local names = {}
        for _, t in ipairs(AHTabs()) do
            table.insert(names, tostring(t.GetName and t:GetName() or "?") .. "=" .. tostring(t.GetText and t:GetText() or "") .. (t:IsShown() and "" or "(versteckt)"))
        end
        A:Print("Reiter (" .. #names .. "): " .. table.concat(names, ", "))
        if type(ah.Tabs) == "table" then A:Print("ah.Tabs: " .. #ah.Tabs .. " Einträge") end
        local avail = {}
        for _, tpl in ipairs(TAB_TEMPLATES) do
            local ok, f = pcall(CreateFrame, "Button", nil, UIParent, tpl)
            if ok and f then
                table.insert(avail, tpl)
                f:Hide()
                if type(ah.Tabs) == "table" then
                    for i = #ah.Tabs, 1, -1 do if ah.Tabs[i] == f then table.remove(ah.Tabs, i) end end
                end
            end
        end
        A:Print("Vorlagen vorhanden: " .. (#avail > 0 and table.concat(avail, ", ") or "keine"))
    end
    local b = self.ahTab
    if b then
        local p1, rel = b:GetPoint()
        A:Print("Unser Reiter: Vorlage " .. tostring(b.template or "eigene") .. ", sichtbar " .. yn(b:IsShown()) .. ", Breite " .. math.floor(b:GetWidth() or 0)
            .. ", Anker " .. tostring(p1) .. " an " .. tostring(rel and rel.GetName and rel:GetName() or rel))
    else
        A:Print("Unser Reiter: noch nicht erstellt")
    end
    A:Print("Ansicht im AH: " .. (self.ahOverlay and (yn(self.ahOverlay:IsShown()) .. ", Breite " .. math.floor(self.ahOverlay:GetWidth() or 0)
        .. ", Höhe " .. math.floor(self.ahOverlay:GetHeight() or 0)) or "noch nicht erstellt"))
    A:Print("Letzter Fehler: " .. tostring(self.ahLastError or "keiner"))
end

-- /ahp ah: Ansicht im Auktionshaus von Hand öffnen
function UI:ForceAH()
    if not (A.db and A.db.settings.ahIntegration ~= false) then return A:Print(L["Die Einbindung ins Auktionshaus ist ausgeschaltet (Optionen)."]) end
    if not A:IsAHOpen() then return A:Print(L["Bitte zuerst das Auktionshaus öffnen."]) end
    if not AHFrame() then return A:Print(L["Auktionshaus-Fenster nicht gefunden."] .. "  (/ahp ahdebug)") end
    local ok, err = pcall(self.ShowInAH, self)
    if not ok then self:ReportAHError(err) end
end

-- Blizzard lädt das Auktionshaus-Fenster nachträglich: dann sofort einhängen
do
    local loader = CreateFrame("Frame")
    pcall(loader.RegisterEvent, loader, "ADDON_LOADED")
    loader:SetScript("OnEvent", function(_, _, name)
        if type(name) == "string" and name:find("^Blizzard_Auction") then
            UI:HookAHFrame()
            if A:IsAHOpen() then UI:OnAHOpened() end
        end
    end)
end
A:On("READY", function() UI:HookAHFrame() end)

function UI:SetIntegration(on)
    if not A.db then return end
    A.db.settings.ahIntegration = on and true or false
    if on then
        if A:IsAHOpen() then self:OnAHOpened() end
    else
        local inAH = self.ahOverlay and self.ahOverlay:IsVisible()
        if inAH then self:LeaveAH() end
        if self.ahTab then self.ahTab:Hide() end
        if inAH then self:Show() end
    end
end

-- ------------------------------------------------------------
-- Design umschalten (ohne /reload): Fenster wird neu aufgebaut
-- ------------------------------------------------------------
function UI:SetTheme(name)
    if not self.THEMES[name] then return false end
    if A.db then A.db.settings.theme = name end
    return self:Rebuild(name)
end

-- Alle Fenster neu aufbauen (nach Design- oder Sprachwechsel)
function UI:Rebuild(name)
    name = name or (A.db and A.db.settings.theme) or "classic"
    if not self.THEMES[name] then name = "classic" end
    local wasShown = self.frame and self.frame:IsShown()
    local wasInAH = self.ahOverlay and self.ahOverlay:IsVisible()
    local optionsShown = self.options and self.options:IsShown()
    local active = self.activeTab

    -- alte Fenster ausblenden und vergessen (der Reiter im Auktionshaus bleibt)
    for _, key in ipairs({ "frame", "options", "helpWindow", "textWindow", "menu", "suggest", "ahOverlay" }) do
        if self[key] then self[key]:Hide(); self[key] = nil end
    end
    self.ahHost = nil
    for _, tab in ipairs(self.tabs) do tab.panel = nil end
    self.activeTab = nil

    self:ApplyPalette(name)
    A:Fire("THEME_CHANGED", name)

    if wasShown or wasInAH then
        self:Show()
        if active then self:SelectTab(active) end
    end
    if optionsShown then self:ShowOptions() end
    return true
end

function UI:ToggleTheme()
    self:SetTheme(self.theme == "classic" and "modern" or "classic")
    A:Print(L["Design: "] .. L[self.THEMES[self.theme].label])
end

function UI:SetScale(scale)
    scale = math.floor(math.max(0.6, math.min(1.4, scale)) * 100 + 0.5) / 100
    if A.db then A.db.settings.scale = scale end
    for _, key in ipairs({ "frame", "options", "helpWindow", "textWindow", "listsWindow" }) do
        if self[key] then self[key]:SetScale(scale) end
    end
    return scale
end

-- ------------------------------------------------------------
-- Optionen (alles Wichtige an einem Ort)
-- ------------------------------------------------------------
function UI:ShowOptions()
    if not self.options then
        local w = self:Dialog("AHAnalyzerProOptions", 420, 712, L["Optionen"])
        local rows = {}
        local y = -46

        local function row(label)
            local l = UI:Label(w, label, "GameFontHighlightSmall", C.text)
            l:SetPoint("TOPLEFT", 18, y - 5)
            local r = { label = l, y = y }
            table.insert(rows, r)
            y = y - 32
            return r
        end

        -- Design
        local r = row(L["Design"])
        w.classicBtn = UI:Button(w, L["Klassisch"], 100, 24, function() UI:SetTheme("classic") end)
        w.classicBtn:SetPoint("TOPLEFT", 170, r.y)
        w.classicBtn.tooltip = L["Wie das WoW-Auktionshaus: Holz, Gold, rote Knöpfe, Reiter unten"]
        w.modernBtn = UI:Button(w, L["Modern"], 100, 24, function() UI:SetTheme("modern") end)
        w.modernBtn:SetPoint("LEFT", w.classicBtn, "RIGHT", 6, 0)
        w.modernBtn.tooltip = L["Flach und dunkel"]

        -- Im Auktionshaus-Fenster anzeigen
        r = row(L["Im Auktionshaus anzeigen"])
        w.ahBtn = UI:Button(w, "", 100, 24, function()
            UI:SetIntegration(A.db.settings.ahIntegration == false)
            if UI.options then UI.options:Refresh() end
        end)
        w.ahBtn:SetPoint("TOPLEFT", 170, r.y)
        w.ahBtn.tooltip = L["Das Addon als eigener Reiter im Auktionshaus-Fenster.\nBei geschlossenem Auktionshaus öffnet sich das eigene Fenster."]

        -- Item-Tooltip: Preiszeilen und Preisdiagramm
        r = row(L["Preis im Tooltip"])
        w.ttInfoBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.tooltipInfo = (A.db.settings.tooltipInfo == false)
            w:Refresh()
        end)
        w.ttInfoBtn:SetPoint("TOPLEFT", 170, r.y)
        w.ttInfoBtn.tooltip = L["Zeigt beim Überfahren eines Items Preis, Marktwert und Trend im Tooltip"]
        r = row(L["Preisverlauf im Tooltip"])
        w.ttChartBtn = UI:Button(w, "", 100, 24, function()
            A.Tooltip:CycleChartDays()
            w:Refresh()
        end)
        w.ttChartBtn:SetPoint("TOPLEFT", 170, r.y)
        w.ttChartBtn.tooltip = L["Zeigt beim Überfahren eines Items ein kleines Preisdiagramm unter dem Tooltip.\nKlick: Zeitraum wechseln (aus / 24 Std. / 7 Tage / 30 Tage)"]

        r = row(L["Händlerpreis im Tooltip"])
        w.ttVendorBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.tooltipVendor = (A.db.settings.tooltipVendor == false)
            w:Refresh()
        end)
        w.ttVendorBtn:SetPoint("TOPLEFT", 170, r.y)
        w.ttVendorBtn.tooltip = L["Zeigt im Item-Tooltip, was ein Händler für das Item zahlt"]

        r = row(L["Mehr im Tooltip"])
        w.ttCharsBtn = UI:Button(w, "", 112, 24, function()
            A.db.settings.tooltipChars = (A.db.settings.tooltipChars == false)
            w:Refresh()
        end)
        w.ttCharsBtn:SetPoint("TOPLEFT", 170, r.y)
        w.ttCharsBtn.tooltip = L["Wie viele Stück deine anderen Charaktere haben (Taschen und Bank)"]
        w.ttDEBtn = UI:Button(w, "", 112, 24, function()
            A.db.settings.tooltipDE = (A.db.settings.tooltipDE == false)
            w:Refresh()
        end)
        w.ttDEBtn:SetPoint("LEFT", w.ttCharsBtn, "RIGHT", 6, 0)
        w.ttDEBtn.tooltip = L["Erwarteter Wert beim Entzaubern (grüne, blaue, epische Ausrüstung)"]

        r = row(L["Entzaubern gelernt"])
        w.deText = UI:Label(w, "", "GameFontHighlightSmall", C.text)
        w.deText:SetPoint("TOPLEFT", 170, r.y - 5)
        w.deText:SetWidth(110)
        w.deReset = UI:Button(w, L["Zurücksetzen"], 110, 24, function()
            if not w.deConfirm then
                w.deConfirm = true
                w.deReset:SetText(L["Wirklich?"])
                return
            end
            w.deConfirm = nil
            A.Disenchant:Reset()
            w:Refresh()
        end, "danger")
        w.deReset:SetPoint("TOPLEFT", 286, r.y)
        w.deReset.tooltip = L["Vergisst alle eigenen Entzauberungs-Ergebnisse - danach gelten wieder die Tabellenwerte"]

        r = row(L["Knöpfe am Briefkasten"])
        w.mailBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.mailButtons = (A.db.settings.mailButtons == false)
            if A.Mailer and A.Mailer.buttons then A.Mailer.buttons:SetShown(A.db.settings.mailButtons ~= false) end
            w:Refresh()
        end)
        w.mailBtn:SetPoint("TOPLEFT", 170, r.y)
        w.mailBtn.tooltip = L["'AH-Post abholen' und 'Alles' am Briefkasten"]

        r = row(L["Gewinn im Berufsfenster"])
        w.craftBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.craftPanel = (A.db.settings.craftPanel == false)
            if A.db.settings.craftPanel == false and A.Crafting and A.Crafting.panel then A.Crafting.panel:Hide() end
            w:Refresh()
        end)
        w.craftBtn:SetPoint("TOPLEFT", 170, r.y)
        w.craftBtn.tooltip = L["Zeigt neben dem Berufsfenster Materialkosten, Wert und Gewinn der Rezepte"]

        -- Sprache des Addons (Standard: wie der Client)
        r = row(L["Sprache des Addons"])
        w.uiLangBtn = UI:Button(w, "", 206, 24, function(self, button)
            A:CycleUILanguage(button == "RightButton" and -1 or 1)
            if UI.options then UI.options:Refresh() end
        end)
        if w.uiLangBtn.RegisterForClicks then w.uiLangBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp") end
        w.uiLangBtn:SetPoint("TOPLEFT", 170, r.y)

        -- Sprache der Item-Namen
        r = row(L["Item-Namen anzeigen in"])
        w.langBtn = UI:Button(w, "", 206, 24, function(self, button)
            A.Names:CycleDisplayLocale(button == "RightButton" and -1 or 1)
            w:Refresh()
        end)
        if w.langBtn.RegisterForClicks then w.langBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp") end
        w.langBtn:SetPoint("TOPLEFT", 170, r.y)

        -- Geldanzeige: Münzsymbole oder Buchstaben
        r = row(L["Geldanzeige"])
        w.moneyBtn = UI:Button(w, "", 206, 24, function()
            local s = A.db.settings
            s.moneyStyle = (s.moneyStyle == "letters") and "icons" or "letters"
            w:Refresh()
            UI:RefreshActive()
        end)
        w.moneyBtn:SetPoint("TOPLEFT", 170, r.y)
        w.moneyBtn.tooltip = L["Gold, Silber und Kupfer als WoW-Münzsymbole oder als Buchstaben"]

        -- Fenstergröße
        r = row(L["Fenstergröße"])
        w.scaleDown = UI:Button(w, "-", 28, 24, function() UI:SetScale((A.db.settings.scale or 1) - 0.05); w:Refresh() end)
        w.scaleDown:SetPoint("TOPLEFT", 170, r.y)
        w.scaleText = UI:Label(w, "", "GameFontHighlight", C.text)
        w.scaleText:SetPoint("LEFT", w.scaleDown, "RIGHT", 10, 0)
        w.scaleText:SetWidth(50); w.scaleText:SetJustifyH("CENTER")
        w.scaleUp = UI:Button(w, "+", 28, 24, function() UI:SetScale((A.db.settings.scale or 1) + 0.05); w:Refresh() end)
        w.scaleUp:SetPoint("LEFT", w.scaleText, "RIGHT", 10, 0)

        -- Ton
        r = row(L["Ton bei Treffern und Alarmen"])
        w.soundBtn = UI:Button(w, "", 100, 24, function()
            A.db.settings.alertSound = not A.db.settings.alertSound
            w:Refresh()
        end)
        w.soundBtn:SetPoint("TOPLEFT", 170, r.y)

        -- Sync
        r = row(L["Preise mit Mitspielern teilen"])
        w.syncBtn = UI:Button(w, "", 100, 24, function()
            if A.Sync then A.Sync:Toggle() end
            w:Refresh()
        end)
        w.syncBtn:SetPoint("TOPLEFT", 170, r.y)
        w.syncBtn.tooltip = L["Nach jedem Scan werden deine Preise an alle Spieler mit diesem Addon verteilt,\nund du bekommst ihre."]

        -- Sniper-Tempo
        r = row(L["Sniper sucht alle"])
        w.snipeDown = UI:Button(w, "-", 28, 24, function()
            A.db.sniper.interval = math.max(2, (A.db.sniper.interval or 3) - 1); w:Refresh()
        end)
        w.snipeDown:SetPoint("TOPLEFT", 170, r.y)
        w.snipeText = UI:Label(w, "", "GameFontHighlight", C.text)
        w.snipeText:SetPoint("LEFT", w.snipeDown, "RIGHT", 10, 0)
        w.snipeText:SetWidth(50); w.snipeText:SetJustifyH("CENTER")
        w.snipeUp = UI:Button(w, "+", 28, 24, function()
            A.db.sniper.interval = math.min(30, (A.db.sniper.interval or 3) + 1); w:Refresh()
        end)
        w.snipeUp:SetPoint("LEFT", w.snipeText, "RIGHT", 10, 0)

        -- Daten
        r = row(L["Daten"])
        w.exportBtn = UI:Button(w, L["CSV-Export"], 100, 24, function() A:ExportCSV() end)
        w.exportBtn:SetPoint("TOPLEFT", 170, r.y)
        w.exportBtn.tooltip = L["Alle Preise als Text zum Kopieren (z.B. für Excel)"]
        w.resetBtn = UI:Button(w, L["Positionen"], 100, 24, function()
            if A.ResetButtonPosition then A:ResetButtonPosition() end
            UI:ResetPosition()
        end)
        w.resetBtn:SetPoint("LEFT", w.exportBtn, "RIGHT", 6, 0)
        w.resetBtn.tooltip = L["Fenster und Münz-Button wieder in die Bildschirmmitte"]

        local hint = UI:Label(w, L["Chat-Befehle: /ahp, /ahp scan, /ahp sniper, /ahp design, /ahp debug"], "GameFontDisableSmall", C.textDim)
        hint:SetPoint("BOTTOMLEFT", 18, 14)

        function w:Refresh()
            local s = A.db.settings
            self.classicBtn:SetText(UI.theme == "classic" and L["> Klassisch <"] or L["Klassisch"])
            self.modernBtn:SetText(UI.theme == "modern" and L["> Modern <"] or L["Modern"])
            self.scaleText:SetText(math.floor((s.scale or 1) * 100 + 0.5) .. " %")
            self.soundBtn:SetText(s.alertSound and L["an"] or L["aus"])
            self.syncBtn:SetText((A.Sync and A.Sync:IsEnabled()) and L["an"] or L["aus"])
            self.snipeText:SetText((A.db.sniper.interval or 3) .. L[" Sek."])
            local N = A.Names
            self.uiLangBtn:SetText(A:UILanguageLabel())
            self.ahBtn:SetText((s.ahIntegration ~= false) and L["an"] or L["aus"])
            self.ttInfoBtn:SetText((s.tooltipInfo ~= false) and L["an"] or L["aus"])
            self.ttChartBtn:SetText(A.Tooltip:PeriodLabel())
            self.ttVendorBtn:SetText((s.tooltipVendor ~= false) and L["an"] or L["aus"])
            self.craftBtn:SetText((s.craftPanel ~= false) and L["an"] or L["aus"])
            self.ttCharsBtn:SetText(L["Twinks: "] .. ((s.tooltipChars ~= false) and L["an"] or L["aus"]))
            self.ttDEBtn:SetText(L["Entzaub.: "] .. ((s.tooltipDE ~= false) and L["an"] or L["aus"]))
            self.mailBtn:SetText((s.mailButtons ~= false) and L["an"] or L["aus"])
            local deN, deG = A.Disenchant:TotalLearned()
            self.deText:SetText(string.format(L["%d in %d Gruppen"], deN, deG))
            if not self.deConfirm then self.deReset:SetText(L["Zurücksetzen"]) end
            self.moneyBtn:SetText(((s.moneyStyle == "letters") and L["Buchstaben"] or L["Münzsymbole"]) .. ":  " .. A:FormatMoney(123456))
            local loc = N:DisplayLocale()
            self.langBtn:SetText(N:LocaleLabel(N:DisplaySetting()) .. " (" .. N:CountNames(loc) .. ")")
            local lines = { L["Linksklick: nächste Sprache, Rechtsklick: vorige"], "",
                L["Gesucht wird immer in ALLEN Sprachen."], L["Bekannte Namen:"] }
            for _, l in ipairs(N.LOCALES) do
                local c = N:CountNames(l.code)
                local mark = (l.code == N:ClientLocale()) and L["  (dein Client)"] or ""
                table.insert(lines, "  " .. N:LocaleLabel(l.code) .. ": " .. c .. mark)
            end
            table.insert(lines, "")
            table.insert(lines, L["Eingebaute Namensliste: rund 23.000 Items (Quelle: QuestieDB,"])
            table.insert(lines, L["wow-classic-items - siehe Data/QUELLEN.txt). Fehlende Namen lernt"])
            table.insert(lines, L["das Addon aus deinem Client und über den Preis-Sync von Mitspielern."])
            table.insert(lines, L["Unbekannte Namen werden in deiner Client-Sprache gezeigt."])
            table.insert(lines, L["Russisch/Koreanisch/Chinesisch braucht passende Schriftarten im Client."])
            self.langBtn.tooltip = table.concat(lines, "\n")
        end
        w:SetScript("OnShow", function(self) self:Refresh() end)
        self.options = w
    end
    self.options:Show()
    self.options:Refresh()
end

function UI:ToggleOptions()
    if self.options and self.options:IsShown() then self.options:Hide() else self:ShowOptions() end
end

-- ------------------------------------------------------------
-- Hilfe (kurz, pro Tab)
-- ------------------------------------------------------------
UI.HELP_DE = {
    start = {
        "Willkommen bei AH Analyzer Pro",
        "So einfach geht's:\n\n"
        .. "1.  Auktionshaus öffnen und unten auf |cffffd100Markt scannen|r klicken.\n"
        .. "     (Der Server erlaubt einen Scan alle 15 Minuten.)\n\n"
        .. "2.  In den Reitern siehst du Preise, Trends und Schnäppchen.\n\n"
        .. "3.  Items findest du per |cffffd100Name in jeder Sprache|r (Teile reichen,\n"
        .. "     Umlaute egal), per Item-ID oder per |cffffd100Shift-Klick|r auf ein Item.\n\n"
        .. "4.  |cffffd100Rechtsklick auf ein Item|r: Preisverlauf, Watchlist,\n"
        .. "     Sniper-Ziel oder im Auktionshaus suchen.\n\n"
        .. "5.  Im Reiter |cffffd100Sniper|r Ziele eintragen, Sniper-Modus an -\n"
        .. "     jede Mausrad-Raste kauft das nächste passende Angebot.\n\n"
        .. "Design (Klassisch/Modern), Fenstergröße, Ton und mehr: |cffffd100Optionen|r oben.\n"
        .. "Diese Hilfe gibt es jederzeit über den Knopf |cffffd100?|r",
    },
    overview = {
        "Übersicht",
        "Die wichtigsten Zahlen auf einen Blick: Anzahl Items, letzter und nächster Scan,\n"
        .. "aktive Watchlist-Alarme sowie die größten Preisanstiege und -rückgänge.\n\n"
        .. "Trends brauchen mindestens zwei Scans.\n"
        .. "Klick auf ein Item öffnet den Preisverlauf, Rechtsklick zeigt alle Optionen.",
    },
    market = {
        "Markt",
        [[
Alle gescannten Items mit aktuellem Preis, Marktwert und Trend.

- |cffffd100Marktwert|r = Median der Preise der letzten 14 Tage
  (einzelne Ausreißer zählen kaum).
- |cffffd100% Markt|r: aktueller Preis im Verhältnis zum Marktwert.
  Grün = günstig, Orange/Rot = teuer.
- Oben suchen: Name in jeder Sprache, Teil reicht, Umlaute egal.
  Auch Item-ID oder Shift-Klick auf ein Item geht.
- Spaltenkopf anklicken = sortieren.
- |cffffd100+|r setzt das Item auf die Watchlist.
- Rechtsklick: Preisverlauf, Sniper-Ziel, Einkaufsliste, im Auktionshaus suchen.]],
    },
    watchlist = {
        "Watchlist",
        "Items beobachten und benachrichtigt werden.\n"
        .. "Item per Name (jede Sprache, Vorschläge erscheinen beim Tippen), ID\n"
        .. "oder Shift-Klick auf ein Item eintragen.\n\n"
        .. "- |cffffd100Kaufen unter|r: Meldung, wenn der Preis darunter fällt.\n"
        .. "- |cffffd100Verkaufen über|r: Meldung, wenn der Preis darüber steigt.\n"
        .. "Preise in Gold, z.B. 12.5 oder 12g 50s.\n"
        .. "Geprüft wird nach jedem Scan (auch mit Preisen von Mitspielern).",
    },
    sniper = {
        "Sniper",
        "1.  Item (Name in jeder Sprache, ID oder Shift-Klick) oder Suchwort,\n"
        .. "     |cffffd100Max-Preis pro Stück|r, |cffffd100Menge|r und\n"
        .. "     |cffffd100Budget|r eintragen. Menge leer = 1, Budget leer = Menge x Max-Preis.\n"
        .. "     Unter |cffffd100Filter|r: Seltenheit (Grau bis Episch), Itemlevel und Stufe.\n\n"
        .. "2.  Auktionshaus offen lassen und |cffffd100Sniper-Modus: AN|r.\n"
        .. "     Der Sniper sucht deine Ziele selbstständig der Reihe nach.\n\n"
        .. "3.  Bei einem Treffer: |cffffd100Mausrad drehen|r (hoch oder runter) = kaufen.\n"
        .. "     Auch Handelswaren mit einer Raste: der Preis wird beim Treffer vorab geholt.\n"
        .. "     Statt Mausrad geht auch eine eigene Taste.\n\n"
        .. "Gekauft wird nur mit deinem Mausrad / deiner Taste - nie ohne dich.\n"
        .. "Das Mausrad kauft nur, wenn die Maus über der Spielwelt ist (nicht über Fenstern).\n\n" .. "|cffffd100Einkaufslisten|r (Knopf oben): Items mit Mengen sammeln und mit einem Klick als Sniper-Ziele anlegen.",
    },
    charts = {
        "Charts",
        [[
Preisverlauf eines Items über die Zeit.

Item links auswählen oder irgendwo per Rechtsklick > Preisverlauf.
Punkte von Mitspielern (Preis-Sync) sind im Tooltip markiert.
|cffffd100Graue Punkte|r = unbestätigt (vermutlich Lockangebot) - zählen nicht.

|cffffd100EMA|r (Knopf oben) - gleitende Durchschnitte über die Zeit:
- blau = 6 Stunden, orange = 1 Tag, lila = 7 Tage
- nur echte Preise (ohne Lockangebote), ab 10 Preisen
Grüner Punkt: die 1-Tages-EMA steigt über die 7-Tages-EMA (Preis zieht an).
Roter Punkt: sie fällt darunter (Preis gibt nach).]],
    },
    profit = {
        "Profit",
        [[
Flipping-Rechner: Einkaufspreis, Verkaufspreis und Menge eintragen -
der Gewinn nach Auktionshaus-Gebühr wird sofort berechnet.

Schnäppchen in zwei Ansichten:
- |cffffd100Unter Marktwert|r: Items deutlich unter ihrem Marktwert
  (Median 14 Tage). |cffffd100+|r = auf die Watchlist.
- |cffffd100Unter Händlerpreis|r: im Auktionshaus billiger, als ein Händler zahlt.
  Kaufen und beim Händler verkaufen = sicherer Gewinn.
  |cffffd100+|r = Sniper-Ziel, das alle diese Angebote kauft.

Klick auf eine Zeile füllt den Rechner aus.
- |cffffd100Unter Entzauberwert|r: Ausrüstung billiger als ihr Entzauberungswert (Richtwerte).
  Jede eigene Entzauberung wird gemerkt - die Werte nähern sich deinem Server an.]],
    },
    sell = {
        "Verkaufen",
        [[
1.  Links ein Item aus deinen Taschen anklicken - die aktuellen
     Angebote werden geladen.
2.  Der |cffffd100Vorschlag|r unterbietet das günstigste fremde Angebot
     (um 1 Kupfer, 1 % oder 5 %). Ohne Angebote: Marktwert.
     Klick auf ein Angebot übernimmt dessen Preis.
3.  Menge und Dauer wählen, Gebühren prüfen, |cffffd100Einstellen|r klicken.

- Waren (stapelbar): eine Auktion mit der ganzen Menge.
- Einzelstücke (z.B. Ausrüstung): ein Klick = eine Auktion.
- Zahlt ein Händler mehr als das Auktionshaus netto, warnt das Addon
  und will einen zweiten Klick.
Eingestellt wird nur per Klick - so verlangt es WoW.
|cffffd100Serie|r (unten links): alle Items mit gemerktem Preis nacheinander, ein Klick pro Auktion.]],
    },
    auctions = {
        "Auktionen",
        [[
Deine eigenen Auktionen mit Status:
|cff33dd55günstigstes|r, |cffffcc33gleich|r, |cffff5544unterboten|r oder |cff00d1d1verkauft|r.

- |cffffd100Unterbietung prüfen|r lädt die aktuellen Preise all deiner Items.
- |cffffd100Nächste unterbotene abbrechen|r: jeder Klick bricht eine unterbotene
  Auktion ab. Danach im Tab Verkaufen neu und günstiger einstellen.
- |cffffd100X|r in einer Zeile bricht genau diese Auktion ab.

Beim Abbrechen ist die Einstellgebühr verloren.]],
    },
    ledger = {
        "Buchhaltung",
        [[
Was du im Auktionshaus verdienst und ausgibst.

- Verkäufe und Käufe liest das Addon aus den Rechnungen in deinem
  |cffffd100Briefkasten|r - einfach öffnen, abholen musst du nichts.
  Doppelt gezählt wird nie.
- Käufe über den Sniper und Einstellgebühren aus dem Tab Verkaufen
  werden sofort gebucht.
- Einnahmen sind nach Abzug des AH-Anteils (5 %).
  Gewinn = Einnahmen - Ausgaben - Gebühren.
- Oben den Zeitraum wählen, Ansicht |cffffd100Pro Item|r oder |cffffd100Verlauf|r.
- |cffffd100Statistik|r: Verkaufsquote je Item, beste Uhrzeit und Wochentag.
- |cffffd100Gold|r: alle Charaktere und dein Gold der letzten 30 Tage.
Am Briefkasten: |cffffd100AH-Post abholen|r holt alles mit einem Klick.]],
    },
    watcher = {
        "Schnäppchen-Wächter",
        [[
Sucht nebenbei Handwerkswaren deutlich unter dem Marktwert -
egal, was du gerade snipst.

1.  |cffffd100Wächter: AN|r und das Auktionshaus offen lassen.
2.  |cffffd100Treffer ab|r: z.B. höchstens 50 % vom Marktwert (Median 14 Tage).
     |cffffd100Mindestwert/Stück|r: Kleinkram ausblenden (Standard 10 Kupfer).
     |cffffd100Budget je Schnäppchen|r: so viel gibt ein Kauf höchstens aus.
3.  Kategorien wählen (Kräuter, Erz, Stoff, Leder, Verzauberung ...).
     Waffen und Rüstung werden nie durchsucht.

Alle Kategorien laufen in einer Suche. Lehnt der Server das ab,
sucht der Wächter von selbst Kategorie für Kategorie.
Jeder Treffer wird einzeln nachgeprüft: |cffffd100Lockangebote|r (1 Stück ganz unten) zählen nicht.
Kaufen mit |cffffd100Mausrad / eigener Taste|r wie beim Sniper
- eine Raste kauft, auch bei Waren. Nie ohne dich.
Beim Warenkauf nimmt der Server immer die günstigsten Stücke zuerst,
ein Lockstück wird also mitgekauft.]],
    },
}

UI.HELP_EN = {
    start = {
        "Welcome to AH Analyzer Pro",
        "It's this easy:\n\n"
        .. "1.  Open the auction house and click |cffffd100Scan market|r at the bottom.\n"
        .. "     (The server allows one scan every 15 minutes.)\n\n"
        .. "2.  The tabs show prices, trends and bargains.\n\n"
        .. "3.  Find items by |cffffd100name in any language|r (parts are enough,\n"
        .. "     accents don't matter), by item ID or by |cffffd100shift-clicking|r an item.\n\n"
        .. "4.  |cffffd100Right-click an item|r: price history, watchlist,\n"
        .. "     sniper target or search in the auction house.\n\n"
        .. "5.  In the |cffffd100Sniper|r tab add targets and turn sniper mode on -\n"
        .. "     every notch of the mouse wheel buys the next matching listing.\n\n"
        .. "Design (Classic/Modern), language, window size, sound and more: |cffffd100Options|r at the top.\n"
        .. "This help is always available via the |cffffd100?|r button",
    },
    overview = {
        "Overview",
        "The key figures at a glance: number of items, last and next scan,\n"
        .. "active watchlist alerts and the biggest price increases and drops.\n\n"
        .. "Trends need at least two scans.\n"
        .. "Click an item to open its price history, right-click for all options.",
    },
    market = {
        "Market",
        [[
All scanned items with current price, market value and trend.

- |cffffd100Market value|r = median of the prices of the last 14 days
  (single outliers barely count).
- |cffffd100% market|r: current price compared to the market value.
  Green = cheap, orange/red = expensive.
- Search at the top: name in any language, parts are enough, accents don't matter.
  Item ID or shift-clicking an item works too.
- Click a column header = sort.
- |cffffd100+|r puts the item on the watchlist.
- Right-click: price history, sniper target, shopping list, search in the auction house.]],
    },
    watchlist = {
        "Watchlist",
        "Watch items and get notified.\n"
        .. "Enter an item by name (any language, suggestions appear while typing), ID\n"
        .. "or by shift-clicking an item.\n\n"
        .. "- |cffffd100Buy below|r: message when the price falls below it.\n"
        .. "- |cffffd100Sell above|r: message when the price rises above it.\n"
        .. "Prices in gold, e.g. 12.5 or 12g 50s.\n"
        .. "Checked after every scan (also with prices from other players).",
    },
    sniper = {
        "Sniper",
        "1.  Enter an item (name in any language, ID or shift-click) or a search term,\n"
        .. "     the |cffffd100max price per item|r, |cffffd100quantity|r and\n"
        .. "     |cffffd100budget|r. Empty quantity = 1, empty budget = quantity x max price.\n"
        .. "     Under |cffffd100Filter|r: rarity (Poor to Epic), item level and required level.\n\n"
        .. "2.  Keep the auction house open and set |cffffd100Sniper mode: ON|r.\n"
        .. "     The sniper searches your targets one after another on its own.\n\n"
        .. "3.  On a hit: |cffffd100turn the mouse wheel|r (up or down) = buy.\n"
        .. "     Commodities too with one notch: the price is fetched in advance on a hit.\n"
        .. "     Instead of the mouse wheel you can use your own key.\n\n"
        .. "Nothing is bought without your mouse wheel / key - never without you.\n"
        .. "The mouse wheel only buys while the cursor is over the game world (not over windows).\n\n" .. "|cffffd100Shopping lists|r (button at the top): collect items with quantities and turn them into sniper targets with one click.",
    },
    charts = {
        "Charts",
        [[
Price history of an item over time.

Select an item on the left or right-click it anywhere > price history.
Points from other players (price sync) are marked in the tooltip.
|cffffd100Grey points|r = unverified (probably a bait offer) - they don't count.

|cffffd100EMA|r (button at the top) - moving averages over time:
- blue = 6 hours, orange = 1 day, purple = 7 days
- real prices only (no bait offers), from 10 prices on
Green point: the 1-day EMA rises above the 7-day EMA (price picking up).
Red point: it falls below (price easing).]],
    },
    profit = {
        "Profit",
        [[
Flipping calculator: enter buy price, sell price and quantity -
the profit after the auction house fee is calculated right away.

Bargains in two views:
- |cffffd100Below market value|r: items well below their market value
  (14-day median). |cffffd100+|r = to the watchlist.
- |cffffd100Below vendor price|r: cheaper in the auction house than a vendor pays.
  Buy and sell to a vendor = guaranteed profit.
  |cffffd100+|r = sniper target that buys all these listings.

Click a row to fill in the calculator.
- |cffffd100Below disenchant value|r: gear cheaper than its disenchant value (estimates).
  Every disenchant you do is remembered - the values move towards your server's reality.]],
    },
    sell = {
        "Sell",
        [[
1.  Click an item from your bags on the left - its current
     listings are loaded.
2.  The |cffffd100suggestion|r undercuts the lowest listing from others
     (by 1 copper, 1 % or 5 %). Without listings: market value.
     Clicking a listing takes over its price.
3.  Choose quantity and duration, check the fees, click |cffffd100Post|r.

- Commodities (stackable): one auction with the whole quantity.
- Single items (e.g. gear): one click = one auction.
- If a vendor pays more than the auction house net, the addon warns
  and asks for a second click.
Posting only happens on your click - WoW requires that.
|cffffd100Series|r (bottom left): all items with a remembered price in a row, one click per auction.]],
    },
    auctions = {
        "Auctions",
        [[
Your own auctions with their status:
|cff33dd55lowest|r, |cffffcc33tied|r, |cffff5544undercut|r or |cff00d1d1sold|r.

- |cffffd100Check undercuts|r loads the current prices of all your items.
- |cffffd100Cancel next undercut|r: every click cancels one undercut auction.
  Then repost it cheaper in the Sell tab.
- |cffffd100X|r in a row cancels exactly that auction.

When cancelling, the deposit is lost.]],
    },
    ledger = {
        "Ledger",
        [[
What you earn and spend in the auction house.

- Sales and purchases are read from the invoices in your
  |cffffd100mailbox|r - just open it, you don't have to collect anything.
  Nothing is ever counted twice.
- Purchases via the sniper and deposits from the Sell tab
  are booked right away.
- Income is after the AH cut (5 %).
  Profit = income - spending - fees.
- Pick the period at the top, view |cffffd100Per item|r or |cffffd100History|r.
- |cffffd100Statistics|r: sell-through per item, best time of day and weekday.
- |cffffd100Gold|r: all characters and your gold over the last 30 days.
At the mailbox: |cffffd100Collect AH mail|r takes everything with one click.]],
    },
    watcher = {
        "Bargain watcher",
        [[
Searches trade goods well below market value on the side -
no matter what you are sniping right now.

1.  |cffffd100Watcher: ON|r and keep the auction house open.
2.  |cffffd100Hit at|r: e.g. at most 50 % of market value (14-day median).
     |cffffd100Min. value/item|r: hide small stuff (default 10 copper).
     |cffffd100Budget per bargain|r: the most one purchase spends.
3.  Choose categories (herbs, ore, cloth, leather, enchanting ...).
     Weapons and armor are never searched.

All categories run in one search. If the server rejects that,
the watcher switches to one category at a time by itself.
Every hit is checked with a single search: |cffffd100bait offers|r (1 item at the very bottom) don't count.
Buy with the |cffffd100mouse wheel / your own key|r like the sniper
- one notch buys, commodities too. Never without you.
For commodities the server always sells the cheapest units first,
so a bait unit is bought along.]],
    },
}

function UI:ShowHelp(id)
    id = id or self.activeTab or "start"
    local help
    if A.uiLang == "deDE" then help = self.HELP_DE
    else help = A.HELP[A.uiLang] or self.HELP_EN end
    local h = help[id] or help.start
    if not self.helpWindow then
        local w = self:Dialog("AHAnalyzerProHelp", 580, 390, "")
        w.text = UI:Label(w, "", "GameFontHighlight", C.text)
        w.text:SetPoint("TOPLEFT", 20, -46)
        w.text:SetWidth(540)
        w.text:SetJustifyV("TOP")
        if w.text.SetSpacing then w.text:SetSpacing(2) end
        w.ok = UI:Button(w, L["Alles klar"], 110, 26, function() w:Hide() end, "primary")
        w.ok:SetPoint("BOTTOM", 0, 14)
        self.helpWindow = w
    end
    self.helpWindow.title:SetText(L["Hilfe: "] .. h[1])
    self.helpWindow.text:SetText(h[2])
    self.helpWindow:Show()
end

-- ------------------------------------------------------------
-- Rechtsklick-Menü für Items (überall gleich)
-- ------------------------------------------------------------
function UI:HideMenu()
    if self.menu then self.menu:Hide() end
end

function UI:ShowItemMenu(itemID, anchor)
    if not self.menu then
        local m = CreateFrame("Frame", "AHAnalyzerProItemMenu", UIParent)
        m:SetFrameStrata("FULLSCREEN_DIALOG")
        m:SetClampedToScreen(true)
        m:EnableMouse(true)
        UI:Box(m, C.bg, C.frameEdge, UI:IsClassic() and 2 or 1)
        UI:RegisterSpecial("AHAnalyzerProItemMenu")
        m.title = UI:Label(m, "", "GameFontNormalSmall", C.accent)
        m.title:SetPoint("TOPLEFT", 10, -8)
        m.title:SetWidth(180)
        if m.title.SetWordWrap then m.title:SetWordWrap(false) end
        m.entries = {}
        local labels = {
            { "chart", L["Preisverlauf anzeigen"] },
            { "watch", L["Auf die Watchlist"] },
            { "sniper", L["Als Sniper-Ziel eintragen"] },
            { "list", L["Auf eine Einkaufsliste"] },
            { "ah", L["Im Auktionshaus suchen"] },
            { "close", L["Schließen"] },
        }
        for i, def in ipairs(labels) do
            local b = CreateFrame("Button", nil, m)
            b:SetSize(184, 20)
            b:SetPoint("TOPLEFT", 8, -24 - (i - 1) * 21)
            b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            b.text:SetPoint("LEFT", 6, 0)
            b.text:SetText(def[2])
            local hl = b:CreateTexture(nil, "HIGHLIGHT")
            hl:SetAllPoints()
            hl:SetColorTexture(C.accent[1], C.accent[2], C.accent[3], 0.2)
            b.action = def[1]
            b:SetScript("OnClick", function(self) UI:OnMenuClick(self.action) end)
            m.entries[def[1]] = b
        end
        m:SetSize(200, 24 + #labels * 21 + 8)
        -- schließt sich, wenn die Maus länger weg ist
        m.away = 0
        m:SetScript("OnUpdate", function(self, dt)
            if self.IsMouseOver and self:IsMouseOver() then self.away = 0 return end
            self.away = self.away + (dt or 0)
            if self.away > 2.5 then self:Hide() end
        end)
        self.menu = m
    end
    local m = self.menu
    m.itemID = itemID
    m.away = 0
    m.title:SetText(A:GetItemName(itemID))
    local onList = A.Watchlist and A.Watchlist:Contains(itemID)
    m.entries.watch.text:SetText(onList and L["Von der Watchlist entfernen"] or L["Auf die Watchlist"])
    m:ClearAllPoints()
    if anchor and GetCursorPosition and UIParent.GetEffectiveScale then
        local x, y = GetCursorPosition()
        local s = UIParent:GetEffectiveScale() or 1
        if x and y then
            m:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", x / s - 4, y / s + 4)
        else
            m:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, 0)
        end
    elseif anchor then
        m:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, 0)
    else
        m:SetPoint("CENTER")
    end
    m:Show()
end

function UI:OnMenuClick(action)
    local m = self.menu
    local id = m and m.itemID
    if m then m:Hide() end
    if not id then return end
    if action == "chart" then
        self:OpenChart(id)
    elseif action == "watch" then
        local ok, msg
        if A.Watchlist:Contains(id) then ok, msg = A.Watchlist:Remove(id) else ok, msg = A.Watchlist:Add(tostring(id)) end
        A:Print(msg)
    elseif action == "sniper" then
        self:OpenSniperFor(id)
    elseif action == "ah" then
        local _, msg = A.Sniper:OpenInAH(id)
        A:Print(msg)
    elseif action == "list" then
        local w = self:ShowLists()
        if w then
            self:SetItemInput(w.item, id)
            w.qty:SetFocus()
        end
    end
end

-- ------------------------------------------------------------
-- Textfenster (für CSV-Export)
-- ------------------------------------------------------------
function UI:ShowTextWindow(titleText, text)
    if not self.textWindow then
        local w = self:Dialog("AHAnalyzerProTextWindow", 700, 460, "")

        local area = CreateFrame("Frame", nil, w)
        area:SetPoint("TOPLEFT", 12, -40)
        area:SetPoint("BOTTOMRIGHT", -12, 12)
        UI:Box(area, C.input, C.border)

        local sf = CreateFrame("ScrollFrame", nil, area)
        sf:SetPoint("TOPLEFT", 6, -6)
        sf:SetPoint("BOTTOMRIGHT", -6, 6)
        local eb = CreateFrame("EditBox", nil, sf)
        eb:SetMultiLine(true)
        eb:SetAutoFocus(false)
        eb:SetFontObject(ChatFontNormal or GameFontHighlightSmall)
        eb:SetWidth(650)
        eb:SetScript("OnEscapePressed", function() w:Hide() end)
        sf:SetScrollChild(eb)
        sf:EnableMouseWheel(true)
        sf:SetScript("OnMouseWheel", function(self, delta)
            local range = self:GetVerticalScrollRange() or 0
            local newPos = math.max(0, math.min(range, self:GetVerticalScroll() - delta * 40))
            self:SetVerticalScroll(newPos)
        end)
        w.edit = eb
        self.textWindow = w
    end
    local w = self.textWindow
    w.title:SetText(titleText or "")
    w.edit:SetText(text or "")
    w:Show()
    w.edit:SetFocus()
    w.edit:HighlightText()
end

-- ------------------------------------------------------------
-- Auf Kern-Ereignisse reagieren
-- ------------------------------------------------------------
A:On("READY", function()
    -- gespeichertes Design laden, bevor irgendein Fenster gebaut wird
    UI:ApplyPalette(A.db.settings.theme or "classic")
end)
A:On("SCAN_STARTED", function() UI:UpdateStatus() end)
A:On("SCAN_PROGRESS", function() UI:UpdateStatus() end)
A:On("SCAN_FAILED", function() UI:UpdateStatus() end)
A:On("DATA_CHANGED", function() UI:RefreshActive() end)
A:On("WATCHLIST_CHANGED", function() UI:RefreshActive() end)
A:On("AH_STATE", function()
    if A:IsAHOpen() then UI:OnAHOpened() else UI:OnAHClosed() end
    UI:UpdateStatus()
end)
A:On("SYNC_CHANGED", function() UI:UpdateStatus() end)
-- Sprache gewechselt: alle Fenster in der neuen Sprache neu aufbauen
A:On("LANGUAGE_CHANGED", function() UI:Rebuild() end)
