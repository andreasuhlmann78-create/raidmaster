-- ============================================================
-- AH Analyzer Pro 4.0 - Tab "Übersicht" (Dashboard)
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local function BuildOverview(parent)
    local p = CreateFrame("Frame", nil, parent)

    local head = UI:Label(p, L["Markt-Übersicht"], "GameFontNormalLarge", C.text)
    head:SetPoint("TOPLEFT", 0, 0)
    local sub = UI:Label(p, L["Kennzahlen aus deinen Scans. Trends brauchen mindestens zwei Scans."], "GameFontDisableSmall", C.textDim)
    sub:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -4)

    -- Kennzahl-Karten
    local cardW, cardH, gap = 214, 66, 10
    p.cardItems = UI:Card(p, cardW, cardH, L["Items in der Datenbank"])
    p.cardItems:SetPoint("TOPLEFT", 0, -44)
    p.cardScans = UI:Card(p, cardW, cardH, L["Letzter Scan"])
    p.cardScans:SetPoint("LEFT", p.cardItems, "RIGHT", gap, 0)
    p.cardNext = UI:Card(p, cardW, cardH, L["Nächster Scan möglich"])
    p.cardNext:SetPoint("LEFT", p.cardScans, "RIGHT", gap, 0)
    p.cardAlerts = UI:Card(p, cardW, cardH, L["Watchlist-Alarme"])
    p.cardAlerts:SetPoint("LEFT", p.cardNext, "RIGHT", gap, 0)

    -- Gewinner / Verlierer
    local columns = {
        { key = "name", title = L["Item"], width = 230 },
        { key = "price", title = L["Preis"], width = 110, align = "RIGHT" },
        { key = "change", title = L["seit Scan"], width = 75, align = "RIGHT" },
    }
    local function cell(item, key)
        if key == "name" then return item.name end
        if key == "price" then return A:FormatMoney(item.price) end
        if key == "change" then return A:FormatPercent(item.change) end
    end

    local upTitle = UI:Label(p, L["Größte Preisanstiege"], "GameFontNormal", C.green)
    upTitle:SetPoint("TOPLEFT", p.cardItems, "BOTTOMLEFT", 0, -36)
    p.upTable = UI:Table(p, {
        columns = columns, rows = 12, rowHeight = 22, cell = cell,
        onClick = function(item) UI:OpenChart(item.itemID) end,
        emptyText = L["Noch keine Vergleichsdaten.\nNach dem zweiten Scan erscheinen hier Trends."],
    })
    p.upTable:SetPoint("TOPLEFT", upTitle, "BOTTOMLEFT", 0, -6)

    local downTitle = UI:Label(p, L["Größte Preisrückgänge"], "GameFontNormal", C.red)
    downTitle:SetPoint("LEFT", upTitle, "LEFT", 456, 0)
    p.downTable = UI:Table(p, {
        columns = columns, rows = 12, rowHeight = 22, cell = cell,
        onClick = function(item) UI:OpenChart(item.itemID) end,
        emptyText = L["Noch keine Vergleichsdaten."],
    })
    p.downTable:SetPoint("TOPLEFT", downTitle, "BOTTOMLEFT", 0, -6)

    local hint = UI:Label(p, L["Tipp: Auf ein Item klicken öffnet den Preisverlauf."], "GameFontDisableSmall", C.textDim)
    hint:SetPoint("TOPLEFT", p.upTable, "BOTTOMLEFT", 0, -8)

    function p:Refresh()
        local db = A.db
        if not db then return end

        self.cardItems.value:SetText(A:CountTable(db.marketData))
        self.cardItems.sub:SetText(L["Scans insgesamt: "] .. (db.totalScans or 0))

        local lastLog = db.scanLog[#db.scanLog]
        self.cardScans.value:SetText(A:FormatAgo(db.lastScanTime))
        self.cardScans.sub:SetText(lastLog and (lastLog.items .. L[" Items erfasst"]) or "")

        if A:IsScanning() then
            self.cardNext.value:SetText(L["|cffffcc33Scan läuft|r"])
        elseif A:IsScanReady() then
            self.cardNext.value:SetText(L["|cff33dd55jetzt|r"])
        else
            self.cardNext.value:SetText(A:FormatDuration(A:GetCooldownRemaining()) .. L[" Min."])
        end
        self.cardNext.sub:SetText(A:IsAHOpen() and L["Auktionshaus ist offen"] or L["Auktionshaus öffnen zum Scannen"])

        local alerts = A.Watchlist and A.Watchlist:CountAlerts() or 0
        self.cardAlerts.value:SetText(alerts > 0 and ("|cff33dd55" .. alerts .. "|r") or "0")
        self.cardAlerts.sub:SetText((A.Watchlist and A.Watchlist:Count() or 0) .. L[" Items beobachtet"])

        local list = A:BuildItemList()
        local ups, downs = {}, {}
        for _, it in ipairs(list) do
            if it.change and it.change > 0.05 then table.insert(ups, it) end
            if it.change and it.change < -0.05 then table.insert(downs, it) end
        end
        table.sort(ups, function(a, b) return a.change > b.change end)
        table.sort(downs, function(a, b) return a.change < b.change end)
        self.upTable:SetData(ups)
        self.downTable:SetData(downs)
    end

    -- Countdown in den Karten laufen lassen
    local elapsed = 0
    p:SetScript("OnUpdate", function(self, dt)
        elapsed = elapsed + dt
        if elapsed < 1 then return end
        elapsed = 0
        if A:IsScanning() then
            self.cardNext.value:SetText(L["|cffffcc33Scan läuft|r"])
        elseif A:IsScanReady() then
            self.cardNext.value:SetText(L["|cff33dd55jetzt|r"])
        else
            self.cardNext.value:SetText(A:FormatDuration(A:GetCooldownRemaining()) .. L[" Min."])
        end
        self.cardScans.value:SetText(A:FormatAgo(A.db and A.db.lastScanTime))
    end)

    return p
end

UI:RegisterTab("overview", "Übersicht", 1, BuildOverview)
