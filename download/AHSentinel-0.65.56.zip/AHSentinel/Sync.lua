if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 4.5 - Preis- und Namens-Synchronisation zwischen allen Nutzern
--
-- Alle Spieler mit diesem Addon treten einem unsichtbaren Kanal bei.
-- Nach jedem eigenen Scan werden die Preise dort verteilt, die anderen
-- Addons tragen sie in ihren Preisverlauf ein. Wer neu einloggt, fragt
-- nach dem neuesten Scan der letzten 2 Stunden.
-- Zusätzlich werden Item-Namen in der Sprache des eigenen Clients geteilt,
-- damit jeder in jeder WoW-Sprache suchen kann.
-- Dazu die Ergebnisse beim Entzaubern (welches Material wie oft herauskam),
-- damit alle die Dropchancen schneller lernen.
-- Es werden nur Preisdaten, Item-Namen und Entzauberungs-Ergebnisse geteilt, nichts sonst.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local S = {}
A.Sync = S

local PREFIX = "AHAP1"              -- Addon-Nachrichten-Kennung (max. 16 Zeichen)
local CHANNEL_NAME = "AHAPSync"     -- alter eigener Kanal (bis 0.65.54) - wird nur noch einmal verlassen
local SEND_INTERVAL = 1.1           -- Sekunden zwischen zwei Nachrichten (Server-Drossel)
local MAX_MSG = 230                 -- Nutzlast pro Nachricht (GoldSentinelSync.MAX_PAYLOAD)
local MAX_AGE = 3 * 86400           -- ältere Daten werden nicht angenommen
local RESPOND_MAX_AGE = 2 * 3600    -- auf Anfragen nur mit Scans der letzten 2 Std. antworten
local MAX_FACTOR = 20               -- Preise, die 20x vom eigenen Wert abweichen, gelten als unplausibel

S.queue = {}                        -- alt, leer (die Warteschlange ist jetzt in GoldSentinelSync)
S.heardScanTime = 0                 -- neuester Scan-Zeitpunkt, den andere gerade senden
S.status = L["nicht verbunden"]

-- ------------------------------------------------------------
-- Zahlen kompakt kodieren (Basis 36)
-- ------------------------------------------------------------
local DIGITS = "0123456789abcdefghijklmnopqrstuvwxyz"

local function Enc(n)
    n = math.floor(tonumber(n) or 0)
    if n <= 0 then return "0" end
    local out = ""
    while n > 0 do
        local r = n % 36
        out = DIGITS:sub(r + 1, r + 1) .. out
        n = math.floor(n / 36)
    end
    return out
end

local function Dec(s)
    return s and tonumber(s, 36) or nil
end

S.Enc, S.Dec = Enc, Dec

-- ------------------------------------------------------------
-- Senden - über die gemeinsame Datei GoldSentinelSync.lua (Anweisung 18:40, shared/wissen/kommunikation-forever.md):
-- nur Gilde und Gruppe/Raid, NIE über einen eigenen Kanal (in WoW Forever kommen Kanal-Nachrichten nicht an:
-- NOT_ALLOWED_IN_CHANNEL). Kennung AHAP1 bleibt, damit alte Versionen der Mitspieler weiter verstanden werden.
-- Kein eigener Takt, keine eigene Warteschlange mehr (GoldSentinelSync drosselt für alle Addons zusammen).
-- ------------------------------------------------------------
local GSS = _G.GoldSentinelSync
S.ep = GSS and GSS.Register("AHSentinel", PREFIX, A.version) or nil
MAX_MSG = (GSS and GSS.MAX_PAYLOAD) or 230

-- nur mit der eigenen Gilde teilen?
function S:GuildOnly()
    return A.db and A.db.sync and A.db.sync.guildOnly == true
end

-- über die Nahtstelle (Testroutine ersetzt nur A.apiOverride, nie die Blizzard-Funktion)
local function InGuild()
    local f = A:Global("IsInGuild")
    return f and f() and true or false
end

-- Umfang: "nur Gilde" -> guild, sonst Gilde und Gruppe (was es gerade gibt)
function S:Scope()
    return self:GuildOnly() and { scope = "guild" } or nil
end

-- Wege, über die gerade gesendet würde (Liste "GUILD"/"PARTY"/"RAID"), leer = kein Weg
function S:Paths()
    local G2 = _G.GoldSentinelSync
    local out = {}
    if not G2 then return out end
    for _, p in ipairs(G2.Paths(self:Scope())) do out[#out + 1] = p[1] end
    return out
end

-- Testmodus / Testroutine: nichts senden, nur mitschreiben (S.simLog)
S.simLog = {}
S.sent, S.recv = 0, 0
local function SendNow(msg)
    if A:Simulated() then
        table.insert(S.simLog, msg)
        while #S.simLog > 200 do table.remove(S.simLog, 1) end
        return true
    end
    if not S.ep then return false end
    local ok = S.ep:Send(msg, S:Scope())
    if ok then S.sent = S.sent + 1 else S.noPath = (S.noPath or 0) + 1 end
    return ok
end

S.Enqueue = SendNow          -- alter Name (Disenchant, Names): reiht in die gemeinsame Warteschlange ein
S.SendNow = SendNow
S.MAX_MSG = MAX_MSG

function S:IsSending()
    local G2 = _G.GoldSentinelSync
    return G2 ~= nil and #G2.queue > 0
end

-- Einen Scan an alle verteilen
function S:BroadcastScan(scanTime, data)
    if not self:IsEnabled() or not self:IsConnected() or type(data) ~= "table" then return end
    if self.sendingScanTime == scanTime and self:IsSending() then return end
    self.sendingScanTime = scanTime

    local entries = {}
    for itemID, b in pairs(data) do
        A:Pause()
        if b.price and b.price > 0 and not b.u then      -- unbestätigte (mögliche Lockangebote) nicht weitergeben
            table.insert(entries, Enc(itemID) .. "," .. Enc(b.price) .. "," .. Enc(b.qty or 0))
        end
    end
    if #entries == 0 then return end

    local tEnc = Enc(scanTime)
    -- 0.65.30: Preise tragen die Kennung des Auktionshauses (Server/Fraktion); "G"/"P" statt "H"/"D"
    local tag = A:MarketTag()
    SendNow("G:" .. tEnc .. ":" .. tag .. ":" .. Enc(#entries))
    local head = "P:" .. tEnc .. ":" .. tag .. ":"
    local chunk = {}
    local size = #head
    for _, e in ipairs(entries) do
        A:Pause()
        if size + #e + 1 > MAX_MSG and #chunk > 0 then
            SendNow(head .. table.concat(chunk, ";"))
            chunk, size = {}, #head
        end
        table.insert(chunk, e)
        size = size + #e + 1
    end
    if #chunk > 0 then SendNow(head .. table.concat(chunk, ";")) end
    A:Fire("SYNC_CHANGED")
end

-- Item-Namen der eigenen Client-Sprache verteilen (für die Suche in allen Sprachen)
function S:BroadcastNames(loc, list)
    if not self:IsEnabled() or not self:IsConnected() or #list == 0 then return end
    local head = "N:" .. loc .. ":"
    local chunk, size = {}, #head
    for _, e in ipairs(list) do
        local part = Enc(e.id) .. "=" .. e.name
        if #head + #part <= MAX_MSG then
            if size + #part + 1 > MAX_MSG and #chunk > 0 then
                SendNow(head .. table.concat(chunk, ";"))
                chunk, size = {}, #head
            end
            table.insert(chunk, part)
            size = size + #part + 1
        end
    end
    if #chunk > 0 then SendNow(head .. table.concat(chunk, ";")) end
    A:Fire("SYNC_CHANGED")
end

-- Nach dem Einloggen: fehlende Daten anfragen
function S:RequestLatest()
    if not self:IsEnabled() or not self:IsConnected() then return end
    local since = 0
    if A.db then
        since = math.max(A.db.lastScanTime or 0, A.db.sync.lastScanTimeReceived or 0)
    end
    SendNow("S:" .. Enc(since) .. ":" .. A:MarketTag())
end

-- ------------------------------------------------------------
-- Empfangen
-- ------------------------------------------------------------
local function ShortName(sender)
    if Ambiguate then
        local ok, n = pcall(Ambiguate, sender, "none")
        if ok and n then return n end
    end
    return (sender or ""):match("^[^-]+") or sender
end


local function IsMe(sender)
    if not sender then return false end
    local me = UnitName and UnitName("player")
    return me and ShortName(sender) == me
end

local refreshPending = false
local function ScheduleRefresh()
    if refreshPending then return end
    refreshPending = true
    C_Timer.After(2, function()
        refreshPending = false
        A:Fire("DATA_CHANGED")
    end)
end

-- Werte stimmen, Punkt 4: ein Sync-Preis zählt nur, wenn er zum eigenen Bild passt (10 % bis 300 % des eigenen
-- Medians) oder - ohne eigenes Bild bzw. ausserhalb - wenn ein zweiter Absender einen ähnlichen Preis meldet
-- (höchstens 30 % Abstand, innerhalb von CONFIRM_TIME). Bis dahin wird er nur als "unbestätigt" gespeichert.
S.CONFIRM_TIME = 3600
S.CONFIRM_SPREAD = 0.30
S.pendingConfirm = S.pendingConfirm or {}   -- [itemID] = { price, key, t }

function S:Judge(itemID, price, senderKey, now)
    local own = A:GetMarketValue(itemID)
    if own and own > 0 and price >= own * A.OUTLIER_LOW and price <= own * A.OUTLIER_HIGH then return "ok" end
    local p = self.pendingConfirm[itemID]
    if p and senderKey and p.key ~= senderKey and now - p.t <= self.CONFIRM_TIME
        and math.abs(price - p.price) <= math.max(price, p.price) * self.CONFIRM_SPREAD then
        self.pendingConfirm[itemID] = nil
        return "confirmed"
    end
    self.pendingConfirm[itemID] = { price = price, key = senderKey, t = now }
    return "pending"
end

function S:HandleData(scanTime, payload, senderKey)
    local now = time()
    if not scanTime or scanTime > now + 300 or scanTime < now - MAX_AGE then return 0 end
    local added = 0
    for part in payload:gmatch("[^;]+") do
        local a, b, c = part:match("^(%w+),(%w+),(%w+)$")
        local itemID, price, qty = Dec(a), Dec(b), Dec(c)
        if itemID and price and itemID > 0 and itemID < 10000000 and price > 0 and price < 100000000000 then
            qty = qty and math.min(qty, 10000000) or 0
            local own = A:GetCurrent(itemID)
            local plausible = not own or (price <= own * MAX_FACTOR and price * MAX_FACTOR >= own)
            -- passt nicht zum eigenen Bild und noch nicht von einem zweiten Absender bestätigt: zählt nicht
            local verdict = plausible and self:Judge(itemID, price, senderKey, now) or "pending"
            -- verdächtig billige Waren nur als "unbestätigt" übernehmen (zählen nicht)
            local unverified = verdict == "pending" or A:IsSuspicious(itemID, price)
            if plausible and A:RecordPrice(itemID, price, qty, scanTime, true, unverified) then
                added = added + 1
            end
        end
    end
    if added > 0 then
        A.db.sync.received = (A.db.sync.received or 0) + added
        A.db.sync.lastReceived = now
        if scanTime > (A.db.sync.lastScanTimeReceived or 0) then
            A.db.sync.lastScanTimeReceived = scanTime
        end
        ScheduleRefresh()
    end
    return added
end

function S:HandleRequest(since)
    local own = A.db and A.db.lastOwnScan
    if not own or not own.t or not own.data then return end
    local now = time()
    if own.t <= (since or 0) or own.t < now - RESPOND_MAX_AGE then return end
    if self.pendingResponse then return end
    self.pendingResponse = true
    -- Zufällige Verzögerung, damit nicht alle gleichzeitig antworten
    C_Timer.After(2 + math.random() * 8, function()
        S.pendingResponse = false
        if S.heardScanTime >= own.t then return end   -- jemand anderes hat schon einen gleich neuen Scan geschickt
        S:BroadcastScan(own.t, own.data)
    end)
end

-- WoW Forever: geschützte Werte ("secret values") nie vergleichen, zerlegen oder als Schlüssel benutzen
local function AnySecret(...)
    local G = _G.GoldSentinelGame
    return G and G.AnySecret and G.AnySecret(...) or false
end

function S:OnMessage(prefix, msg, distType, sender)
    if AnySecret(prefix, msg, distType) then return end
    if AnySecret(sender) then sender = nil end            -- geschützter Absender: ohne Namen weiter
    if prefix ~= PREFIX or not self:IsEnabled() or not A.db or type(msg) ~= "string" then return end
    if IsMe(sender) then return end
    if self:GuildOnly() and distType ~= "GUILD" then return end
    self.recv = (self.recv or 0) + 1

    -- Mitspieler nur gezählt, nie mit Namen gespeichert (Kürzel); ohne Absender kein Eintrag
    local pk = sender and (A.Disenchant and A.Disenchant.SenderKey and A.Disenchant:SenderKey(sender) or ShortName(sender)) or nil
    if pk then A.db.sync.peers[pk] = time() end

    local kind, tEnc, rest = msg:match("^(%a):(%w+):?(.*)$")
    if kind == "N" then
        if A.Names then A.Names:HandleNames(tEnc, rest or "") end
        A:Fire("SYNC_CHANGED")
        return
    end
    if kind == "E" then
        if A.Disenchant then A.Disenchant:HandleShared(sender, Dec(tEnc), rest or "") end
        return
    elseif kind == "Q" then
        if A.Disenchant then A.Disenchant:HandleRequest() end
        return
    end
    local t = Dec(tEnc)
    -- Preise nur vom selben Server und derselben Fraktion bzw. demselben Auktionshaus (Kennung); alte Nachrichten
    -- ohne Kennung ("H", "D", "R") werden verworfen - man weiss nicht, woher sie stammen
    if kind == "G" or kind == "P" or kind == "S" then
        local tag, body = (rest or ""):match("^(%w+):?(.*)$")
        if not tag or tag ~= A:MarketTag() then
            self.foreignDropped = (self.foreignDropped or 0) + 1
            return
        end
        if kind == "G" then
            if t and t > self.heardScanTime then self.heardScanTime = t end
        elseif kind == "P" then
            if t and t > self.heardScanTime then self.heardScanTime = t end
            self:HandleData(t, body or "", pk)
        else
            self:HandleRequest(t)
        end
    elseif kind == "H" or kind == "D" or kind == "R" then
        self.untaggedDropped = (self.untaggedDropped or 0) + 1
        return
    end
    A:Fire("SYNC_CHANGED")
end

-- ------------------------------------------------------------
-- Verbinden: kein eigener Kanal mehr. Den alten Kanal AHAPSync einmal verlassen (frei werdender Kanalplatz),
-- dann über Gilde/Gruppe fragen, was es Neues gibt.
-- ------------------------------------------------------------
function S:LeaveOldChannel()
    if A:Simulated() then return false end
    local gcn, leave = A:Global("GetChannelName"), A:Global("LeaveChannelByName")
    if not (gcn and leave) then return false end
    local ok, id = pcall(gcn, CHANNEL_NAME)
    if ok and type(id) == "number" and id > 0 then
        pcall(leave, CHANNEL_NAME)
        if A.Diag then A.Diag:Add("SYNC", "alter Kanal verlassen") end
        return true
    end
    return false
end

function S:UpdateStatus()
    local paths = self:Paths()
    if #paths == 0 then
        self.status = self:GuildOnly() and L["nur Gilde - du bist in keiner Gilde"] or L["kein Weg (keine Gilde, keine Gruppe)"]
    else
        self.status = L["verbunden über "] .. table.concat(paths, "+")
    end
    if not self.wayLogged and A.Diag then
        self.wayLogged = true
        A.Diag:Add("SYNC", "Weg=" .. (#paths > 0 and table.concat(paths, "+") or "kein Weg"))
    end
end

function S:Connect()
    if not self:IsEnabled() then return end
    if A:Simulated() then          -- Testmodus / Testroutine: keinen Kanal betreten oder verlassen
        self.status = L["nicht verbunden"]
        A:Fire("SYNC_CHANGED")
        return
    end
    pcall(self.LeaveOldChannel, self)
    self:UpdateStatus()
    if self:IsConnected() then
        C_Timer.After(2, function() S:RequestLatest() end)
        if A.Disenchant and A.Disenchant.RequestShared then
            C_Timer.After(15, function() A.Disenchant:RequestShared() end)
        end
    end
    A:Fire("SYNC_CHANGED")
end

function S:Disconnect()
    self.status = L["ausgeschaltet"]
    A:Fire("SYNC_CHANGED")
end

-- /ahs sync test: Ping über Gilde/Gruppe, jede neue Version antwortet (GoldSentinelSync.Ping)
function S:Test(cb)
    local G2 = _G.GoldSentinelSync
    if not G2 then A:Print(L["Sync-Test: GoldSentinelSync fehlt."]); return false end
    local n = G2.Ping("AHSentinel", function(r)
        local text
        if r.nopath then
            text = L["Sync-Test: kein Weg (keine Gilde, keine Gruppe)."]
        else
            text = string.format(L["Sync-Test: %d Antworten (Gilde %d, Gruppe %d)"], r.total or 0, r.guild or 0, r.group or 0)
        end
        A:Print(text)
        if cb then cb(r, text) end
    end)
    if n and n > 0 then A:Print(L["Sync-Test läuft (5 Sek.) ..."]) end
    return true
end

-- Protokoll alle 10 Min.: gesendet, empfangen, verworfen
function S:LogStats()
    local G2 = _G.GoldSentinelSync
    if not (A.Diag and self.ep) then return end
    local st = self.ep:Stats()
    local dr = {}
    for k, v in pairs(st.dropped or {}) do dr[#dr + 1] = k .. " " .. v end
    table.sort(dr)
    A.Diag:Add("SYNC", string.format("gesendet %d, empfangen %d, verworfen %s · Kanal verweigert %d", st.sent or 0, st.received or 0,
        #dr > 0 and table.concat(dr, ", ") or "0", G2 and G2.stats.channelRefused or 0))
end

-- ------------------------------------------------------------
-- Status / Einstellungen
-- ------------------------------------------------------------
function S:IsEnabled()
    return A.db and A.db.sync and A.db.sync.enabled
end

function S:IsConnected()
    return #self:Paths() > 0
end

-- alle Spieler mit dem Addon <-> nur die eigene Gilde
function S:SetGuildOnly(on)
    if not A.db then return end
    A.db.sync.guildOnly = on and true or nil
    if self:IsEnabled() then
        self.status = L["verbinde ..."]
        self:Connect()
    end
    A:Fire("SYNC_CHANGED")
end

function S:Toggle()
    if not A.db then return end
    A.db.sync.enabled = not A.db.sync.enabled
    if A.db.sync.enabled then
        self.status = L["verbinde ..."]
        self:Connect()
        A:Print(L["Preis-Sync eingeschaltet."])
    else
        self:Disconnect()
        A:Print(L["Preis-Sync ausgeschaltet."])
    end
end

-- Mitspieler, die in den letzten "seconds" Sekunden etwas gesendet haben
function S:CountPeers(seconds)
    if not A.db then return 0 end
    local limit = time() - (seconds or 3600)
    local n = 0
    for name, t in pairs(A.db.sync.peers) do
        if t >= limit then n = n + 1 elseif t < time() - 30 * 86400 then A.db.sync.peers[name] = nil end
    end
    return n
end

-- ehrlich: "Sync über Gilde: N Mitspieler" bzw. "niemand mit AHSentinel online"
function S:GetStatusText()
    if not self:IsEnabled() then return L["|cff888888Sync aus|r"] end
    local paths = self:Paths()
    if #paths == 0 then return L["|cffff5544Sync: kein Weg (keine Gilde, keine Gruppe)|r"] end
    local peers = math.max(self.ep and self.ep:Peers(3600) or 0, self:CountPeers(3600))
    local way = (paths[1] == "GUILD") and L["Gilde"] or L["Gruppe"]
    local text
    if peers == 0 then
        text = string.format(L["|cff33dd55Sync über %s|r: niemand mit AHSentinel online"], way)
    else
        text = string.format(L["|cff33dd55Sync über %s|r: %d Mitspieler"], way, peers)
    end
    local G2 = _G.GoldSentinelSync
    if G2 and #G2.queue > 0 then text = text .. L[", sende ... ("] .. #G2.queue .. ")" end
    return text
end

function S:GetDebugText()
    if not A.db then return "-" end
    return string.format(L["%s, Status: %s, Mitspieler 1 Std.: %d, empfangene Preise: %d, empfangene Namen: %d, zuletzt empfangen: %s, Warteschlange: %d"],
        self:IsEnabled() and L["an"] or L["aus"], self.status, self:CountPeers(3600),
        A.db.sync.received or 0, A.db.sync.namesReceived or 0, A:FormatAgo(A.db.sync.lastReceived),
        _G.GoldSentinelSync and #_G.GoldSentinelSync.queue or 0)
end

-- ------------------------------------------------------------
-- Einrichtung
-- ------------------------------------------------------------
-- Empfang über GoldSentinelSync (auch Nachrichten alter Versionen ohne Kopf); sender kann nil sein (geschützt)
if S.ep then
    S.ep:OnMessage(function(text, sender, dist)
        local ok, err = pcall(S.OnMessage, S, PREFIX, text, dist, sender)
        if not ok then
            A:Print(L["Sync-Fehler: "] .. tostring(err))
            A:ReportError("Sync", err)
        end
    end)
end
S.frame = _G.GoldSentinelSync and _G.GoldSentinelSync.frame or nil     -- für die Testroutine (Ereignis-Liste)

A:On("READY", function()
    -- Gilde ist direkt nach dem Login oft noch nicht bekannt
    C_Timer.After(6, function() S:Connect() end)
    if C_Timer and C_Timer.NewTicker then C_Timer.NewTicker(600, function() pcall(S.LogStats, S) end) end
end)

A:On("SCAN_FINISHED", function(_, best, scanTime)
    A:Job("sync-send", function() S:BroadcastScan(scanTime, best) end)
end)
