if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - SniperTest.lua
-- SN1951-ABNAHME (Entscheid des Nutzers 13.11. 20:31): "/ahs testroutine sniper" prüft den Sniper am OFFENEN
-- Auktionshaus im echten Spiel - was die Sandbox nicht kann:
--   S4 echter Mausrad-Kauf von 1 Stück bis 5c - NUR nach "Ja" des Spielers in einem eigenen Fenster, gekauft wird nur
--      durch die Raste/Taste des Spielers (Tastendruck). Läuft VOR der Testroutine (ausserhalb der Sandbox), damit der
--      echte Kauf echt gebucht bleibt. Ohne Ja (oder ohne Angebot <= 5c) wird S4 übersprungen.
--   danach die Testroutine, Teil "sniper" (Sandbox, Kaufen gesperrt):
--   S1 Treffer bleiben stehen (Ziel Leinenstoff o. ä., 2 Min. beobachten, nichts verschwindet ohne Grund)
--   S2 Zähler/Budget nur bestätigte Käufe (gesendet -> Fehler -> Bestätigung, an einem Testziel in der echten Anzeige)
--   S3 Pause sichtbar in Zielzeile und Status, "fortsetzen" wirkt sofort
--   S5 Ruckeln: Bilder/s, längster Frame, Sync-Warteschlange während der Beobachtung
--   S6 Reaktionszeit: Abstand der Suchen je Ziel + Suchdauer = spätestens sichtbar nach
-- Keine Spielernamen, kein Chat-Eingabefeld, keine ersetzte Blizzard-Funktion.
-- ============================================================
local A = AHAnalyzerPro
local L = A.L
local SPT = {}
A.SniperTest = SPT

SPT.OBSERVE = 120          -- Sekunden Beobachtung (S1, S5, S6)
SPT.CHEAP_MAX = 5          -- S4: Höchstpreis in Kupfer
SPT.S4_WAIT = 120          -- S4: so lange wartet der Testkauf auf die Raste
SPT.ITEMS = { 2589, 2592, 4306, 2996, 2840 }   -- S1: günstige, viel gehandelte Waren (Leinen-, Wollstoff …)

local function Now() return GetTime() end

-- ------------------------------------------------------------
-- Einstieg: /ahs testroutine sniper
-- ------------------------------------------------------------
function SPT:Begin()
    if not A:IsAHOpen() then A:Print(L["Sniper-Abnahme: bitte zuerst das Auktionshaus öffnen."]); return false end
    if A:InCombat() then A:Print(L["Im Kampf kann die Testroutine nicht starten."]); return false end
    local TR = A.TestRoutine
    if TR and TR.running then A:Print(L["Selbsttest läuft schon ..."]); return false end
    self.s4 = nil
    self:AskS4()
    return true
end

-- eigenes kleines Fenster (kein Blizzard-Popup verändert)
function SPT:AskS4()
    local f = self.ask
    if not f then
        f = CreateFrame("Frame", nil, UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
        f:SetSize(420, 130)
        f:SetPoint("CENTER", 0, 120)
        f:SetFrameStrata("DIALOG")
        if f.SetBackdrop then
            f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
            f:SetBackdropColor(0.06, 0.06, 0.08, 0.95)
            f:SetBackdropBorderColor(0, 0.82, 0.82, 1)
        end
        f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        f.text:SetPoint("TOP", 0, -16)
        f.text:SetWidth(390)
        f.text:SetText(string.format(L["Sniper-Abnahme S4: echter Testkauf von 1 Stück bis %s erlaubt? Gekauft wird nur mit deiner Mausrad-Raste bzw. Taste."],
            A:FormatMoney(self.CHEAP_MAX)))
        local UI = A.UI
        f.yes = UI:Button(f, L["Ja"], 120, 24, function() f:Hide(); SPT:S4Answer(true) end, "primary")
        f.yes:SetPoint("BOTTOMLEFT", 70, 14)
        f.no = UI:Button(f, L["Nein"], 120, 24, function() f:Hide(); SPT:S4Answer(false) end)
        f.no:SetPoint("BOTTOMRIGHT", -70, 14)
        self.ask = f
    end
    f:Show()
end

-- günstigstes frisches Angebot <= CHEAP_MAX aus dem letzten Scan
function SPT:CheapItem()
    local best, bestP
    local maxAge = (A.PRICE_OLD_HOURS or 6) * 3600
    for id in pairs(A.db and A.db.marketData or {}) do
        local p, _, t = A:GetCurrent(id)
        if p and p > 0 and p <= self.CHEAP_MAX and t and time() - t <= maxAge and (not bestP or p < bestP) then best, bestP = id, p end
    end
    return best, bestP
end

function SPT:S4Answer(yes)
    if not yes then
        self.s4 = { status = "SKIP", detail = L["Spieler hat den Testkauf nicht erlaubt (Nein)"] }
        return self:StartRoutine()
    end
    local Sn = A.Sniper
    local id, p = self:CheapItem()
    if not (Sn and id) then
        self.s4 = { status = "SKIP", detail = string.format(L["kein Angebot bis %s im letzten Scan"], A:FormatMoney(self.CHEAP_MAX)) }
        return self:StartRoutine()
    end
    local key = "i:" .. id
    local db = A.db.sniper
    local prev = db.targets[key]
    local wasArmed = db.armed
    local ok = Sn:SetTarget(tostring(id), self.CHEAP_MAX, 1, self.CHEAP_MAX)
    if not ok then
        self.s4 = { status = "SKIP", detail = "Testziel ließ sich nicht anlegen" }
        return self:StartRoutine()
    end
    local t = db.targets[key]
    local sent0 = self.sendCount or 0
    self.s4run = { id = id, key = key, prev = prev, wasArmed = wasArmed, t = t, t0 = Now(), price = p, sent0 = sent0 }
    if not wasArmed then Sn:SetArmed(true) end
    A:Print(string.format(L["Sniper-Abnahme S4: Ziel %s bis %s, 1 Stück. Sobald „Treffer“ erscheint: EINE Mausrad-Raste bzw. Taste (höchstens %d s)."],
        A:GetItemName(id), A:FormatMoney(self.CHEAP_MAX), self.S4_WAIT))
    self:PollS4()
    return true
end

-- Sendungen zählen (Einzelkauf und Warenkauf), nur gelesen über die Sniper-Felder
function SPT:Sends()
    local Sn = A.Sniper
    local n = 0
    for _ in ipairs(Sn.itemBuys or {}) do n = n + 1 end
    if Sn.inFlight then n = n + 1 end
    return n
end

function SPT:PollS4()
    local r = self.s4run
    if not r then return end
    local t = r.t
    local done = t and (t.bought or 0) >= 1
    local timeout = Now() - r.t0 > self.S4_WAIT
    if not (done or timeout) then
        r.maxOpen = math.max(r.maxOpen or 0, self:Sends())
        C_Timer.After(0.5, function() SPT:PollS4() end)
        return
    end
    -- Bestätigung abwarten, dann aufräumen
    local Sn = A.Sniper
    local bought, spent = t and t.bought or 0, t and t.spent or 0
    if done then
        local okOne = bought == 1 and spent <= self.CHEAP_MAX and (r.maxOpen or 0) <= 1
        self.s4 = { status = okOne and "PASS" or "FAIL", detail = string.format("gekauft %d für %s · höchstens %d gleichzeitig gesendet · nach %.0f s",
            bought, A:FormatMoney(spent), r.maxOpen or 0, Now() - r.t0) }
    else
        self.s4 = { status = "SKIP", detail = string.format("kein Kauf in %d s (keine Raste oder kein Treffer)", self.S4_WAIT) }
    end
    local db = A.db.sniper
    if r.prev then db.targets[r.key] = r.prev else db.targets[r.key] = nil end
    if not r.wasArmed then Sn:SetArmed(false) end
    if Sn.result and Sn.result.key == r.key then Sn.result = nil end
    A:Fire("SNIPER_CHANGED")
    self.s4run = nil
    A:Print(L["Sniper-Abnahme S4: "] .. self.s4.status .. " – " .. self.s4.detail)
    C_Timer.After(1, function() SPT:StartRoutine() end)
end

function SPT:StartRoutine()
    local TR = A.TestRoutine
    if TR then TR:Start("sniper") end
end

-- ------------------------------------------------------------
-- Testroutine Teil "sniper" (Sandbox: Kaufen gesperrt, Daten danach zurück)
-- ------------------------------------------------------------
-- Beobachtung: je Änderung der Sniper-Anzeige die sichtbaren Treffer; verschwindet einer, obwohl die neueste Antwort
-- des Servers ihn noch enthält (und er nicht gekauft/weg ist), ist das ein Fehler (S1)
function SPT:Visible(Sn, t)
    local r = Sn.result
    local set = {}
    if not (r and t and r.key == t.key) then return set, r end
    for _, l in ipairs(r.listings or {}) do
        -- Waren haben keine auctionID: Preis und Menge als Schlüssel
        local k = l.auctionID or (tostring(l.price) .. "x" .. tostring(l.qty))
        if not l.gone and not l.own and not l.bait and l.price and l.price <= (t.maxPrice or 0) then set[k] = l end
    end
    return set, r
end

function SPT:StartObserve(TR)
    local Sn = A.Sniper
    local db = A.db.sniper
    -- Testziel: erste Ware aus SPT.ITEMS mit aktuellem Preis; Höchstpreis = günstigstes Angebot (Treffer erwartet)
    local id, p
    for _, x in ipairs(self.ITEMS) do
        local cur = A:GetCurrent(x)
        if cur and cur > 0 then id, p = x, cur; break end
    end
    if not id then return false, "kein Preis für die Test-Waren (erst scannen)" end
    local key = "i:" .. id
    local prevT, prevArmed = db.targets[key], db.armed
    local ok = Sn:SetTarget(tostring(id), p, 1000, p * 1000)
    if not ok then return false, "Testziel ließ sich nicht anlegen" end
    local t = db.targets[key]
    db.armed = true
    Sn.lastSearch = -100
    local o = { id = id, t = t, t0 = Now(), seen = {}, vanished = 0, vanishedIDs = {}, shownN = 0, searches = {}, searchDur = {},
        fpsSum = 0, fpsN = 0, fpsMin = nil, frameMax = 0, queueMax = 0, frames = 0, key = key, prevT = prevT, prevArmed = prevArmed }
    self.obs = o
    local prev = {}
    o.onChange = function()
        local vis, r = SPT:Visible(Sn, t)
        for aid in pairs(vis) do if not o.seen[aid] then o.seen[aid] = Now(); o.shownN = o.shownN + 1 end end
        if r == nil and next(prev) ~= nil then
            -- Liste geleert, bevor neue Ergebnisse da sind (SN1951c) - zählt als ohne Grund verschwunden
            for aid in pairs(prev) do o.vanished = o.vanished + 1; o.vanishedIDs[#o.vanishedIDs + 1] = tostring(aid) .. "(geleert)" end
        end
        for aid in pairs(prev) do
            if not vis[aid] and r and r.key == t.key then
                -- noch in der neuesten Antwort, nicht weg, nicht gekauft -> ohne Grund verschwunden
                for _, l in ipairs(r.listings or {}) do
                    local k = l.auctionID or (tostring(l.price) .. "x" .. tostring(l.qty))
                    if k == aid and not l.gone and not (l.used and l.used > 0) then
                        o.vanished = o.vanished + 1
                        o.vanishedIDs[#o.vanishedIDs + 1] = tostring(aid)
                    end
                end
            end
        end
        prev = vis
    end
    A:On("SNIPER_CHANGED", function() if SPT.obs == o and o.onChange then pcall(o.onChange) end end)
    -- Suchen je Ziel: Start und Antwort (Abstand und Dauer, S6)
    local lastStart
    o.frame = o.frame or CreateFrame("Frame")
    o.frame:SetScript("OnUpdate", function(_, elapsed)
        if SPT.obs ~= o then o.frame:SetScript("OnUpdate", nil); return end
        o.frames = o.frames + 1
        local ms = (elapsed or 0) * 1000
        if o.frames > 5 and ms > o.frameMax then o.frameMax = ms end
        local gf = _G.GetFramerate
        local fps = gf and gf() or nil
        if fps then o.fpsSum, o.fpsN = o.fpsSum + fps, o.fpsN + 1; if not o.fpsMin or fps < o.fpsMin then o.fpsMin = fps end end
        local GSS = _G.GoldSentinelSync
        local q = GSS and GSS.queue and #GSS.queue or 0
        if q > o.queueMax then o.queueMax = q end
        local s = Sn.search
        if s and s.targetKey == t.key and s ~= lastStart then
            lastStart = s
            o.searches[#o.searches + 1] = Now()
            s.__sptStart = Now()
        end
        if lastStart and not Sn.search and lastStart.__sptStart and not lastStart.__sptDone then
            lastStart.__sptDone = true
            o.searchDur[#o.searchDur + 1] = Now() - lastStart.__sptStart
        end
    end)
    return true
end

function SPT:StopObserve()
    local o = self.obs
    if o and o.frame then o.frame:SetScript("OnUpdate", nil) end
    self.obs = nil
    -- Testziel und Modus selbst zurück (Teil "sniper" erlaubt Änderungen unter db.sniper, die echte Suchen machen)
    if o then
        local db, Sn = A.db.sniper, A.Sniper
        db.targets[o.key] = o.prevT
        db.armed = o.prevArmed
        if Sn.result and Sn.result.key == o.key then Sn.result = nil end
        Sn.search = (Sn.search and Sn.search.targetKey == o.key) and nil or Sn.search
        A:Fire("SNIPER_CHANGED")
    end
    return o
end

-- Reaktionszeit (S6): ein neues Angebot ist spätestens nach "Abstand zweier Suchen + Suchdauer" sichtbar
function SPT:Reaction(o)
    local gaps = {}
    for i = 2, #o.searches do gaps[#gaps + 1] = o.searches[i] - o.searches[i - 1] end
    local function avg(t) local s = 0; for _, v in ipairs(t) do s = s + v end; return #t > 0 and s / #t or nil end
    local g, d = avg(gaps), avg(o.searchDur)
    if not g then return nil, g, d end
    return g + (d or 0), g, d
end

function SPT:BuildSteps(TR, B, Chk, Skp)
    local Sn = A.Sniper
    local o
    -- S4 (vorher, ausserhalb der Sandbox)
    B(function()
        local s4 = self.s4 or { status = "SKIP", detail = "Teil ohne vorherige Abfrage gestartet (/ahs testroutine sniper)" }
        if s4.status == "SKIP" then return Skp("T616", "J", "SN1951-S4 echter Mausrad-Kauf: eine Raste = genau 1 Stück (≤ 5c, nur nach Ja)", s4.detail) end
        Chk("T616", "J", "SN1951-S4 echter Mausrad-Kauf: eine Raste = genau 1 Stück (≤ 5c, nur nach Ja)", function()
            return s4.status == "PASS", s4.detail, "gekauft 1 · höchstens 1 gesendet"
        end)
    end)
    -- S1/S5/S6: beobachten
    B(function()
        if not A:IsAHOpen() then
            for _, x in ipairs({ { "T613", "S1 Treffer bleiben stehen" }, { "T617", "S5 Ruckeln und Sync-Warteschlange" }, { "T618", "S6 Reaktionszeit" } }) do
                Skp(x[1], "J", "SN1951-" .. x[2], "Auktionshaus nicht offen")
            end
            return
        end
        local ok, why = self:StartObserve(TR)
        if not ok then
            for _, x in ipairs({ { "T613", "S1 Treffer bleiben stehen" }, { "T617", "S5 Ruckeln und Sync-Warteschlange" }, { "T618", "S6 Reaktionszeit" } }) do
                Skp(x[1], "J", "SN1951-" .. x[2], why)
            end
            return
        end
        A:Print(string.format(L["Sniper-Abnahme: beobachte den Sniper %d s (Kaufen ist gesperrt) ..."], self.OBSERVE))
        local t0 = Now()
        return "WAIT", function() return Now() - t0 >= SPT.OBSERVE or not A:IsAHOpen() end, self.OBSERVE + 10, function()
            o = SPT:StopObserve()
            if not o then return end
            Chk("T613", "J", "SN1951-S1 Treffer bleiben stehen, bis gekauft oder vom Server als weg gemeldet", function()
                return o.shownN > 0 and o.vanished == 0, string.format("%d Treffer angezeigt · ohne Grund verschwunden %d%s · Suchen %d", o.shownN, o.vanished,
                    #o.vanishedIDs > 0 and (" (" .. table.concat(o.vanishedIDs, ",", 1, math.min(5, #o.vanishedIDs)) .. ")") or "", #o.searches),
                    "≥ 1 Treffer · 0 ohne Grund verschwunden"
            end)
            Chk("T617", "J", "SN1951-S5 Ruckeln: Ø ≥ 30 Bilder/s, kein Frame > 50 ms, Sync-Warteschlange ≤ 10", function()
                local avg = o.fpsN > 0 and o.fpsSum / o.fpsN or nil
                local ok2 = (avg == nil or avg >= 30) and o.frameMax <= 50 and o.queueMax <= 10
                return ok2, string.format("Ø %s / min %s Bilder/s · längster Frame %.0f ms · Sync-Warteschlange max %d", avg and string.format("%.0f", avg) or "?",
                    o.fpsMin and string.format("%.0f", o.fpsMin) or "?", o.frameMax, o.queueMax), "≥ 30 · ≤ 50 ms · ≤ 10"
            end)
            Chk("T618", "J", "SN1951-S6 Reaktionszeit: neues Angebot spätestens nach < 5 s sichtbar (Abstand der Suchen + Suchdauer)", function()
                local r, g, d = SPT:Reaction(o)
                if not r then return false, string.format("zu wenige Suchen (%d)", #o.searches), "< 5 s" end
                return r < 5, string.format("spätestens nach %.1f s (Abstand %.1f s + Suche %.1f s, %d Suchen)", r, g, d or 0, #o.searches), "< 5 s"
            end)
        end
    end)
    -- S2/S3: an einem Testziel in der echten Anzeige (Ereignisse nachgespielt, Kaufen bleibt gesperrt)
    B(function()
        Chk("T614", "J", "SN1951-S2 Zielzeile = bestätigte Käufe: gesendet -> Fehler zählt nicht, Bestätigung zählt", function()
            local key = "i:990196501"
            local t = { key = key, kind = "item", itemID = 990196501, maxPrice = 100, qty = 10, budget = 1000, bought = 0, spent = 0 }
            local saved = { buys = Sn.itemBuys, getT = Sn.GetTarget, md = Sn.MarkDead, rf = Sn.ReportFail, pn = Sn.PlanNext, pr = A.Print, after = Sn.AfterPurchase,
                lbe = A.AH.lastBuyError, ls = Sn.lastSearch, lp = Sn.lastPurchase }
            local res = { pcall(function()
                Sn.itemBuys = {}
                Sn.GetTarget = function(self, k) if k == key then return t end return saved.getT(self, k) end
                Sn.MarkDead, Sn.ReportFail, Sn.PlanNext, A.Print, Sn.AfterPurchase = function() end, function() end, function() return nil end, function() end, function() end
                table.insert(Sn.itemBuys, { key = key, tgt = t, itemID = t.itemID, qty = 1, cost = 90, time = Now(), auctionID = 1 })
                table.insert(Sn.itemBuys, { key = key, tgt = t, itemID = t.itemID, qty = 1, cost = 95, time = Now(), auctionID = 2 })
                local p0 = Sn:ProgressText(t)
                A.AH.lastBuyError = { id = 1, msg = "Test", time = Now() }
                Sn:OnEvent("AUCTION_HOUSE_SHOW_ERROR", 1)
                Sn:OnEvent("AUCTION_HOUSE_PURCHASE_COMPLETED", 2)
                return A:PlainText(p0), A:PlainText(Sn:ProgressText(t)), t.bought, t.spent
            end) }
            Sn.itemBuys, Sn.GetTarget, Sn.MarkDead, Sn.ReportFail, Sn.PlanNext, A.Print, Sn.AfterPurchase = saved.buys, saved.getT, saved.md, saved.rf, saved.pn, saved.pr, saved.after
            A.AH.lastBuyError, Sn.lastSearch, Sn.lastPurchase = saved.lbe, saved.ls, saved.lp
            if not res[1] then error(res[2], 0) end
            local ok = res[4] == 1 and res[5] == 95 and tostring(res[2]):find("+2", 1, true) ~= nil
            return ok, string.format("gesendet: \"%s\" · danach \"%s\"", tostring(res[2]), tostring(res[3])), "0/10 (+2 gesendet) · danach 1/10, 95c"
        end)
        Chk("T615", "J", "SN1951-S3 Pause sichtbar (Zielzeile, Status) und \"fortsetzen\" wirkt sofort", function()
            local id = 990196502
            local saved = { ip = Sn.itemPause[id], pw = Sn.pauseWhy[id], fi = Sn.failIDs[id], hide = A.HideDeadOffer, nf = Sn.NoteFail, pr = A.Print, dead = Sn.dead, ls = Sn.lastSearch }
            local res = { pcall(function()
                A.HideDeadOffer, Sn.NoteFail, A.Print, Sn.dead = function() end, function() return false end, function() end, {}
                for i = 1, 3 do Sn:MarkDead({ auctionID = 99019650 + i, price = 1, qty = 1 }, id, "Test") end
                local txt = Sn:PauseText(id) or "-"
                local listed = false
                for _, x in ipairs(Sn:PausedItems()) do if x == id then listed = true end end
                Sn:ResumeItem(id)
                return txt, listed, Sn:ItemPaused(id)
            end) }
            A.HideDeadOffer, Sn.NoteFail, A.Print, Sn.dead, Sn.lastSearch = saved.hide, saved.nf, saved.pr, saved.dead, saved.ls
            Sn.itemPause[id], Sn.pauseWhy[id], Sn.failIDs[id] = saved.ip, saved.pw, saved.fi
            if not res[1] then error(res[2], 0) end
            local ok = res[2] ~= "-" and res[3] == true and res[4] == false
            return ok, string.format("\"%s\" · im Status %s · nach fortsetzen pausiert %s", res[2], tostring(res[3]), tostring(res[4])), "pausiert bis … · im Status · nicht mehr pausiert"
        end)
    end)
end
