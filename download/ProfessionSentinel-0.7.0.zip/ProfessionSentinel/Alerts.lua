local _, ns = ...
local L = ns.L

-- Recipe alarm: a recipe that you or one of your characters (same game version, with that
-- profession) still misses is listed in the auction house.
-- Source: AHSentinel – after every scan (event SCAN_FINISHED) and from its current prices
-- (A:GetCurrent, last 2 hours) when the panel opens.

local AL = {}
ns.Alerts = AL

AL.found = {}          -- { { itemID, recipe, price, qty, who = { names } } } sorted by price
AL.FRESH = 2 * 3600

local function AHS()
    local A = _G.AHAnalyzerPro
    return A and A.GetCurrent and A or nil
end

-- recipe item -> characters that miss it: { [itemID] = { recipe, names } }
function AL.Needed()
    local out = {}
    if not ns.db then return out end
    local me = ns.CharKey and ns.CharKey()
    for key, c in pairs(ns.db.chars or {}) do
        if (c.flavor == nil or c.flavor == ns.Flavor) and c.profs then
            for prof in pairs(c.profs) do
                for _, r in ipairs(ns.ByProf[prof] or {}) do
                    local known = c.known and c.known[r.spell]
                    if key == me then known = ns.IsLearned(r) end
                    if not known and r.recipeItems and #r.recipeItems > 0 then
                        for _, ri in ipairs(r.recipeItems) do
                            local e = out[ri.id]
                            if not e then e = { recipe = r, names = {} }; out[ri.id] = e end
                            e.names[#e.names + 1] = (key:match("^[^-]+") or key)
                        end
                    end
                end
            end
        end
    end
    return out
end

-- prices: { [itemID] = { price, qty, unconfirmed } }
function AL.Match(prices)
    local needed = AL.Needed()
    local list = {}
    for itemID, e in pairs(needed) do
        local p = prices[itemID]
        if p and p.price and p.price > 0 and not p.u then
            list[#list + 1] = { itemID = itemID, recipe = e.recipe, price = p.price, qty = p.qty or 1, who = e.names }
        end
    end
    table.sort(list, function(a, b) return a.price < b.price end)
    return list
end

-- from AHSentinel's current prices (no new scan needed)
local lastCurrent = -100
function AL.FromCurrent()
    local A = AHS()
    if not A then return AL.found end
    local t0 = GetTime and GetTime() or 0
    if t0 - lastCurrent < 30 then return AL.found end      -- at most every 30 s
    lastCurrent = t0
    local prices = {}
    local now = time and time() or 0
    for itemID in pairs(AL.Needed()) do
        local ok, price, qty, t = pcall(A.GetCurrent, A, itemID)
        if ok and price and t and now - t <= AL.FRESH then prices[itemID] = { price = price, qty = qty } end
    end
    AL.found = AL.Match(prices)
    return AL.found
end

local announced = {}   -- itemID -> price already announced this session

function AL.OnScan(best)
    if not (ns.db and ns.db.recipeAlert ~= false) or type(best) ~= "table" then return end
    AL.found = AL.Match(best)
    local fresh = {}
    for _, f in ipairs(AL.found) do
        if not announced[f.itemID] or f.price < announced[f.itemID] then
            fresh[#fresh + 1] = f
            announced[f.itemID] = f.price
        end
    end
    if #fresh == 0 then return end
    if PlaySound and SOUNDKIT and SOUNDKIT.RAID_WARNING then pcall(PlaySound, SOUNDKIT.RAID_WARNING) end
    ns.Print(string.format(L.ALERT_HEAD, #fresh))
    for i, f in ipairs(fresh) do
        if i > 5 then ns.Print(string.format(L.ALERT_MORE, #fresh - 5)); break end
        ns.Print(string.format(L.ALERT_LINE, ns.ItemName(f.itemID), ns.Prices.MoneyPlain(f.price), table.concat(f.who, ", ")))
    end
    if ns.RefreshAll then ns.RefreshAll() end
end

-- one alert into the sniper: max price = current price, 1 piece
function AL.ToSniper(f)
    return ns.Disenchant.SendToSniper({ { id = f.itemID, maxPrice = f.price, qty = 1 } }, ns.ItemName(f.itemID), L.ALERT_SNIPE_DONE)
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function()
    local A = _G.AHAnalyzerPro
    if A and A.On then
        pcall(A.On, A, "SCAN_FINISHED", function(_, best) AL.OnScan(best) end)
    end
end)

---------------------------------------------------------------------------
-- Recipes in your bags: who of your characters needs it – or nobody (then: sell it)
-- { { itemID, recipe, count, who = { names }, ah, vendor } }
---------------------------------------------------------------------------
function AL.BagRecipes()
    local out = {}
    local GetSlots = (C_Container and C_Container.GetContainerNumSlots) or GetContainerNumSlots
    local GetID = (C_Container and C_Container.GetContainerItemID) or GetContainerItemID
    if not (GetSlots and GetID) then return out end
    local counts = {}
    for bag = 0, (NUM_BAG_SLOTS or 4) do
        for slot = 1, (GetSlots(bag) or 0) do
            local id = GetID(bag, slot)
            if id and ns.ByRecipeItem[id] then counts[id] = (counts[id] or 0) + 1 end
        end
    end
    if not next(counts) then return out end
    local needed = AL.Needed()
    for id, n in pairs(counts) do
        local e = needed[id]
        out[#out + 1] = { itemID = id, recipe = ns.ByRecipeItem[id], count = n, who = e and e.names or {},
                          ah = ns.Prices.AH(id), vendor = ns.Prices.VendorSell(id) }
    end
    table.sort(out, function(a, b)
        if (#a.who > 0) ~= (#b.who > 0) then return #a.who > 0 end
        return ns.ItemName(a.itemID) < ns.ItemName(b.itemID)
    end)
    return out
end
