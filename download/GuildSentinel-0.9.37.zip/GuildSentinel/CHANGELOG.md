# GuildSentinel – Changelog

## 0.9.37
- New: market data network (shared file GoldSentinelMarkt.lua, same in all GoldSentinel addons). When any addon or the player runs a full auction house scan, it is read along in small portions (never in combat, never a scan of its own) – lowest unit price, quantity and number of auctions per item, plus measured sales between two scans. No names: owners, bidders and item names are never read. Shared anonymously with the guild and the GoldSentinel network, own faction only. On by default, no question asked; Settings > "Share market data (anonymous, prices only)" turns it off (then nothing is read or sent). Without the auction house interface (Era/TBC) it stays silent.
- Diagnostic log: lines "MARKT-NETZ" (version, on/off, scans read, sent/received, memory) – no names.
- Fix: Guild management > Invite (and the member menu) now also respects the age block – applicants "declined (age)" cannot be invited from there either.
- Developer tests: T291–T293 (MN4), T289f; offline load test with and without the market file.

## 0.9.36
- New (GA1): age question "How old are you?" for applicants. With a minimum age set (Recruitment > texts, default 16, 0 = off) it is ALWAYS asked as the last question, also with your own question list. Answer "17", "I'm 17", "17 years" -> continues normally. Below the minimum age: a friendly whisper ("Thanks for your interest in <guild>! Unfortunately we only accept players aged 16 and over. Have fun in Azeroth!" – text adjustable), status "declined (age)", "Invite to guild" blocked. No number or "soon 16" -> no automatic decline, status "age unclear" for an officer.
- Privacy: the exact age and the answer text are never stored, shared or logged – only "16+" / "under 16" / "unclear".
- New (GA2): in recruitment phase Build-up the default ad says so: "<guild> (faction) is being built up and is looking for players of all classes – relaxed, helpful, raid goal …". New placeholder {phase} ("being built up" / "almost raid-ready" / "raid-ready"). An own ad text without {wanted} or {phase} gets a yellow hint with an "Apply" button (takes the phase's default text). The finished chat text is shown right above the "Prepare ad" button.
- Developer tests: T289a–e (T-GA1a–e), T290a–c (T-GA2a–c); offline flow with ages 17 / 15 / "bald 16".

## 0.9.35
- The summary for the uploader and the Discord bot (GuildSentinelDB.raidReady, written on logout) now has the field "vorschlag": the recruitment phase GuildSentinel currently suggests ("build" / "trans" / "raid", same words as "phase"); missing when no suggestion is open or it was put off with "Later". No names. The bot can then post "GuildSentinel suggests phase … – confirm in the game".
- Developer test: T288 (T-RP-V).

## 0.9.34
- New: command list while typing. Type /gs (or /guildsentinel) in chat and a list of ALL commands with a short description appears above the input box. Every letter filters ("/gs w" = where, away, ad …), German and English command words both work, commands with an argument show it ("thanks <Name>"), the most used are on top. A mouse click or Tab selects an entry, Enter runs it. The chat input is never written to. Developer commands only for the developer. Settings > "Command list while typing /gs" turns it off.
- The command list and the /gs handler use one and the same command table, so the list always has every command.
- Building block taken unchanged from AHSentinel (CmdHint).
- Developer tests: T282–T287 (T-BL1–T-BL6). TU1 situation catalogue extended by group finder, events, polls and sync and by the situations "channel refuses addon messages", "member with an old version" and "guild changed" (11 functions x 9 situations).

## 0.9.33
- Fix: the button in the "Guild action" window (promote, demote, remove, leadership) did nothing when the option "Cast action keybinds on key down" (ActionButtonUseKeyDown) was off – the press set "waiting" and the release then blocked the command, so after 6 seconds it always said "Not carried out". GuildSentinel now only reacts in the phase in which the game runs the command (press or release, depending on the option); one click = exactly one command.
- Developer tests: T281 (T-GA1, both settings) in the test routine; offline test client with the setting on and off.

## 0.9.32
- Developer test routine (/gs testroutine) extended so that errors like the blocked guild invite cannot slip through again:
  - TU1 situation catalogue: 1 / 50 / 500 members, many offline, no rights / officer / Guild Master, first and last names with equal first names, no guild – each through ad text, applicant invite, guild management, member menu, member list, promotion, line-up/raid readiness and professions (T270).
  - TU2 player-like flows: applicant -> invite -> no system message / message -> remove; promote without answer, retry, confirmation; /reload in the middle; ad without a channel (T271).
  - TU3 default values: every field empty or as shipped gives what the player means (T272).
  - TU4 basic rules with 1000 random cases (fixed seed 4711, 10 portions): never a protected guild function directly, status only after the game confirms, rank steps never above your own rank, ad without "|", nothing real sent (T273a–T273j).
  - TU5 real data read only: duplicates, alts pointing to themselves, incomplete rank history – violations go to the diagnostic log without names (T275).
  - TU6 regressions: every finding since 1 Nov has a permanent test; report "Regressions: n of m" (T276). TU8 report line per area (T279). T280 for RV7.
- Protected guild functions that would run through ns.Act are now counted as an error in the routine as well.
- No changes for players.

## 0.9.31
- New: recruitment in phases (Members > Line-up). Build-up (default for every guild): {wanted} in the ad becomes "players of all classes" – the line-up is not used. Transition: "players of all classes, especially <up to 3 gaps>". Raid: the gaps of the line-up, as before. Your own ad texts stay; {wanted} follows the phase.
- The line-up targets are never deleted, converted or overwritten; the page says "the targets above apply from phase Raid". Only the Guild Master and officers can change them, every change is logged with name and time (last 50, in the game only).
- Raid readiness for a target raid (Onyxia's Lair 40, Molten Core 40, Barrow Deeps 10, Hyjal Summit 20 and more; TBC: Karazhan 10, Gruul 25 …): active mains (level ≥ line-up minimum and online in the last 14 days; alts only with "count alts") against raid size, plus tanks and healers (from the line-up, scaled to the raid size; otherwise size/10 and size/5). Shown on Line-up, Recruitment and Overview: "Raid-ready (Onyxia's Lair): 23 of 40 active at level 55+ · Tanks 2/4 · Healers 5/10 · Phase Build-up", with an estimate from the levelling race ("at the current pace in ~x weeks", or "still measuring" with less than 7 days of data).
- From 60 % officers get the suggestion "Transition", from 100 % "Raid" (in the window and once in officer chat, said by one only) with "Confirm" / "Later". Nothing switches automatically. Back only after 7 days below the threshold of the current phase.
- Chronicle milestone "Guild is raid-ready (<raid>)", optional guild chat announcement (Settings, on by default, said by one only).
- On logout a summary without names is stored for the uploader and the Discord bot (GuildSentinelDB.raidReady).
- Developer test routine: T261–T269 (T-RP1–T-RP9) new; T244/T246 now run in phase Raid.

## 0.9.30
- New: right-click menu on members (Members list, inactive list, Who is where, Applicants, Leadership lists): Whisper, Invite to group, Promote, Demote, Set rank …, Assign alt …, Edit note, Edit officer note, Enter absence, Say thanks, Assign mentor …, Remove from guild (with confirmation), Transfer guild leadership (Guild Master only, password protected). Entries your rank may not use are shown in grey with the reason; in combat "not in combat".
- Protected guild actions are never called directly any more (lesson from the invite fix in 0.9.29): promote, demote, remove and leadership transfer – from the menu, the Guild Management window, the promotion suggestions and the bulk actions – open the new "Guild action" window. You click its button and Blizzard's own command (/gpromote, /gdemote, /gremove, /gleader) carries it out. Names with spaces work.
- Set rank: every step is its own click ("Promote – 2 steps left to Officer"), never above your own rank and never to Guild Master.
- A step counts as done only when the game confirms it (system message or new rank in the roster); without confirmation after 6 seconds: "Not carried out" and the step can be repeated. Each confirmed rank change is kept in the rank history (who, whom, from -> to, time).
- Multi-select: Shift/Ctrl-click in the member list, then right-click: promote or demote all of them – one click per member ("3 of 5 done").
- Promotion: new option "Suggest the main's rank for alts" (only a suggestion, carried out step by step).
- Leadership > Rank rights: button "Edit ranks in the game" opens Blizzard's rank window.
- Developer test routine: T254–T260 (menu by rights, no protected call, name with spaces, rank steps, confirmation, alt suggestion, multi-select) new; T64, T174, T194, T195, T213 adapted. The offline test client now rejects protected guild functions like WoW Forever.

## 0.9.29
- Fix (WoW Forever): "Invite to guild" (Recruitment > Applicants and Guild management) no longer triggers "GuildSentinel has been blocked from an action only available to the Blizzard UI". The game forbids addons to invite into the guild directly, even on a mouse click. Now "/ginvite <name>" is put into the chat input and you press Enter – Blizzard's own command sends the invite. Names with spaces work as they are.
- The applicant only shows as "invited" once the game confirms the invite ("You have invited X to join your guild."), no longer right after the click.
- Your own ad texts with {tag} but without a dash: without a tag or Discord link, "(Tag {tag})" is removed with its brackets and a sentence of its own with {tag} is removed completely; otherwise only {tag} is emptied.
- Developer test routine: T253 (invite only via the chat input, status only after the confirmation) new; T174, T194 and T251 extended.

## 0.9.28
- Recruitment page: new "Suggestion 2" button – a second ad text that names your Discord server tag ("… Discord: <link> – you'll know us by the tag XY."). The default ad text is unchanged.
- New field "Server tag" next to the Discord link and new placeholder {tag}. Without a tag or without a Discord link the tag part is left out completely.
- Tip below the Discord link: use a permanent invite (never expires, unlimited uses); whoever clicks it sees the guild's server profile before joining.
- Developer test routine: T251 (suggestion 2 with/without link and tag, DE/EN/RU) and T252 (invite tip) new.

## 0.9.27
- Russian recruitment ad: "Пишите мне" now starts with a capital letter, also when the Discord part is left out.
- Developer test routine: T250 also checks the old default text in the client's language.

## 0.9.26
- Recruitment ad without Discord: the sentence after the removed Discord part now starts with a capital letter ("… helpful. Whisper me: …").
- If you had saved the old default ad text unchanged, it is replaced once by the new default (with the new {gesucht} it would read awkwardly). Your own, different texts stay.
- Developer test routine: T249 (counter "will be shortened") and T250 new; T248 renamed.

## 0.9.25
- **New default recruitment ad**: "{gilde} ({fraktion}) is looking for {gesucht} for dungeons and raids – relaxed and helpful. Discord: {discord} – whisper me: /w {name} guild" (in every language; the German one adds "deutschsprachig"). If you saved your own ad text, it stays as it is; an empty field uses the new default.
  - New placeholder **{fraktion}** ({faction}): Horde or Alliance in the language of the game.
  - **{gesucht}** is now just the list ("Healers, Warriors and Mages"); nothing missing: "new members". If your own text used "{gesucht}" on its own, write "Wanted:" in front yourself.
  - **{discord}**: without a Discord link, the whole "Discord: … – " part disappears. Right after "Discord:" it gives only the link; anywhere else (your own texts, reply, welcome) still "Discord: <link>" as before.
- The length counter counts before shortening and turns red with "will be shortened" when the ad is longer than 251 characters.
- Developer test routine: T244–T248 new.

## 0.9.24
- Recruitment ad: a long ad no longer gets cut off by the chat input and then never counts as posted. The ad text is limited to 251 characters (room for "/<channel> "), the counter shows "(n/251)", and the text in the chat input is exactly the one that counts once it appears in the channel. Umlauts and other special characters are never cut in half.
- Developer test routine: T242–T243 new.

## 0.9.23
- **Recruitment ad no longer blocked**: WoW Forever blocks addons from writing into chat channels ("action blocked"), even from a click. The button is now "Prepare ad": it puts "/<channel> <text>" into the chat input and you send it with Enter (all game versions). The ad only counts as posted (wait times, "last posted", reminder) once your text appears in the channel.
- Group finder: a guild search can only be closed by the searcher; for "whole server" searches the searcher's name in the data is enough (they arrive passed on through the network).
- Guild profession list: the diagnostic line now says why offline members were or were not shown (already on, no function, combat, guild window open, 5-minute lock …); if the list can no longer be read on the second read, the settings are still put back.
- Developer test routine: T239–T241 new.

## 0.9.22
- **Recipes of each member**: on the Professions page, click a member to see WHICH recipes they know for that profession – with a back button, item links and tooltips, and "Request craft" for the selected recipe.
  - **Filter bar by type**, only types that occur, with counts and "All" first: Blacksmithing, Leatherworking, Tailoring by slot (Head, Chest, Hands, Weapons …), Alchemy by Healing/Mana/Rejuvenation/Protection potions, Elixirs, Flasks, Oils, Transmutes, Reagents, Engineering by Explosives, Devices, Scopes, Enchanting by target slot, Cooking/First Aid by Food and Bandages. The bar wraps when space runs out.
  - The type is worked out on your own PC from the item (slot, class) or the recipe name – nothing new has to be sent, so data from older versions works too ("Other" if unknown).
  - On WoW Forever, Blizzard's recipe category is sent along as a new optional field; older versions simply ignore it.
  - The search box also filters a member's recipes; filter and search can be combined.
- Group finder "whole server": group changes and replies to questions now go to the group only; the whisper network gets a search only when it starts and when it ends.
- Developer test routine: T231–T238 new.

## 0.9.21
- **GoldSentinelSync 2 (whisper network)**: the shared sync file now also reaches players with GoldSentinel addons outside your guild and group, by whispering through other players who have it (throttled, no chat spam; "no player named … is online" is hidden).
  - **What goes into the network**: only the group finder for the whole server (new search and closing it). Everything else stays inside the guild (professions, events, board, polls, thanks, attunements …), in the group or in a whisper to one player.
  - Group finder: "whole server" is back – your search goes to the guild, your group and the network.
  - Known players of the network are kept across /reload (GuildSentinelDB.gsSync: names, times, version only; stays on your PC).
- **GoldSentinelTest 2**: share error reports with the developer (only with your consent, /gstest).
- Diagnostic log: new line "NETZ …" (no names).
- Developer test routine: T225–T230 new.

## 0.9.20
- **Addon messages for all game versions**: GuildSentinel now uses the shared GoldSentinel sync file. It sends only through the guild, your group/raid and whispers – never through a custom chat channel (WoW Forever does not deliver addon messages there). Messages from older GuildSentinel versions of other players are still understood. Players using 0.9.19 or older will no longer receive messages from 0.9.20 – please update.
  - The custom channel "GuildSentinelLFG" is no longer joined (it is left once if you are in it) – one chat channel slot is freed.
  - Group finder: "Guild and group" replaces "whole server" – your search goes to the guild and to your current group or raid. The setting "Searches from the whole server" is gone.
  - Recruitment ads: only Blizzard channels (General, Trade, LocalDefense, LookingForGroup …) can be selected; addon and player channels are hidden.
  - "/gs sync test" shows who answers ("N replies (guild a, group b)"); the settings show the number of players with GuildSentinel in the last hour.
- **Professions**: levelling up a profession with the window open no longer sends to the guild at every skill-up (at most every 5 minutes, and when you close the window); new recipes are still sent right away. The diagnostic log is no longer filled by it.
- Guild profession list with offline members: GuildSentinel now always waits for the game before reading and switching the setting back.
- Blizzard's guild recipes: opening the guild view restarts the queries at most every 10 minutes per profession, and no recipe is asked twice a day.
- Profession data received from other players is checked in depth; broken data can no longer cause an error in tooltips or craft requests.
- Diagnostic log: lines for addon messages (ways, players, sent/received/dropped, channel refused).
- Developer test routine: T214–T224 new; test names are placeholders only.

## 0.9.19
- **Professions arrive automatically in both directions**: a member's professions could get stuck on one side. Fixed:
  - GuildSentinel now always sends your own professions itself, also when RaidMaster is installed (before, it stayed silent and relied on RaidMaster).
  - Names are matched in one way everywhere (realm suffix, upper/lower case, first name alone on WoW Forever): data is stored and shown under the name from the guild roster. Older entries under another spelling are merged once (newer data wins).
  - Every member with GuildSentinel sends their own professions 10–60 seconds after logging in when they are new or older than 24 hours – no longer only through the one member who answers the sync.
- **Fully automatic** (no option, no button, never in combat):
  - The game's guild profession list is read with offline members too (the "Show offline members" setting is switched on briefly and set back).
  - New recipes are added right away when you learn them – no need to open the profession window.
  - Recipe check without the window: recipes your guild already knows are checked with the game's spell check, only if a test check gives the right answers.
  - Blizzard's guild recipes (who in the guild knows which recipe) are queried where the game allows it, once a day per profession; otherwise they are read when you open that view yourself.
- **Professions page**: a selected profession without known data now says how many members have it ("2 guild members have Alchemy …") instead of the general hint. The "Who" column shows "1 of 4"; members known only from the game's list appear with "Recipes unknown" and can be whispered; "+2 more according to the game" below the list.
- Guild list: opening collapsed professions happens at most every 5 minutes, and the update this causes no longer starts a new read (no loop).
- Promote from the activity list and the bulk actions now use the modern game function first (like guild management).
- Diagnostic log: lines for read, sent, received, shown and filtered professions (numbers only, no player names) and a summary.
- Developer test routine: T201–T213 new.

## 0.9.18
- **Professions of all members**: the game can send its guild profession list with collapsed professions, and then GuildSentinel found no names. It now opens collapsed professions briefly, reads them and closes them again (only outside combat and while Blizzard's guild window is closed). Where the game cannot do that, the Professions page shows how many members have each profession (e.g. "2/5": 2 known to GuildSentinel, 5 according to the game).
- **Guild management**: actions and rank names now always use the right game function on every client (Classic Era, TBC Anniversary, WoW Forever). The management button moves below the guild window while Blizzard's member details or rank window are open, so it never covers them.
- Developer test routine: T190 extended (collapsed professions), new T200 (old clients without C_GuildInfo); area K also checks Blizzard's guild pop-ups.

## 0.9.17
- **New window "Guild management"** for guild leadership and officers: button "Management (GuildSentinel)" next to Blizzard's guild window (J stays as it is) and `/gs verwaltung`.
  - Invite (name or current target), promote/demote (rank before -> after, never above your own rank), remove (with confirmation).
  - Hand over guild leadership: Guild Master only, locked until the password is entered, then two confirmations.
  - Every button follows your rights in the game. The Guild Master can add characters that may open the window on this computer (local list, never sent).
  - Password: set in the game (enter twice), stored only as a salted checksum on this computer, masked input, 3 failed attempts lock it for 5 minutes, change only with the old password. It is a protection against accidental clicks – the real protection are your rights in the game.
  - Actions only from your click, never in combat; in test mode nothing is executed. Option "Management button on the guild window".

## 0.9.16
- **Professions of all members, automatically**: where the game itself knows the guild's professions (guild profession list), GuildSentinel now reads the skill levels of every member – also of members without GuildSentinel. Recipes still come only from players with GuildSentinel (or RaidMaster) who have opened their profession window once; their own data always wins over the guild list.
- **New members**: whoever joins the guild while online now shares their professions right away instead of at the next login.

## 0.9.15
- **Diagnostic log**: GuildSentinel now records problems that only happen in the real game (slow pages, blocked actions with the calling place, error loops – never player, guild or realm names). Open it with `/gs protokoll` to copy it; after a logout or /reload it is also stored for the RaidMaster uploader, which sends it to the developer.
- Developer test routine: T188 (diagnostic log) and T189 (in the game).

## 0.9.14
Fixes from the in-game test run on WoW Forever launch night:
- **Big guilds**: the Overview and Leadership pages no longer stutter with hundreds of members (main/alt lookups are now done once per page build – about 25× faster with 500 members).
- **Professions button (WoW Forever)**: no more "action blocked" message. If the profession window does not open, GuildSentinel now asks you to open it yourself once instead of calling a protected function.
- **Achievements/Chronicle**: damaged profession data no longer breaks the page.
- **Event announcement** in test mode also works for characters without a guild (only "[Test]" in your chat, nothing is sent).
- Developer test routine: new area K checks the interface in the real client (tooltips covering buttons, overlapping windows, windows off screen, cut-off texts, plausible game values, error loops); clearer results for first/last names and slow pages.

## 0.9.13
- **Language selectable for everyone**: Settings > General > "Language". On start GuildSentinel still uses the language of your game client; you can switch to German, English, French, Spanish (Spain/Mexico), Italian or Portuguese on any client (Russian, Korean and Chinese on a client in that language). GuildSentinel reloads after the change; "Same as the game client" goes back. Replaces the developer-only switch from 0.9.12.

## 0.9.12
- Developer only: under Settings > Test mode the language can be switched between German, English and the game client's language (for screenshots); GuildSentinel reloads after the change. Nothing changes for players – GuildSentinel always uses the language of the game client.

## 0.9.11
- **Bank character: stock to Discord** (optional, off by default): tick "Bank character (stock to Discord)" under Settings > General on your guild's bank character. Opening the bank, the mailbox or – where the game has one – the guild bank then reads bags, bank, mail attachments and guild bank tabs (read only, never in combat, in small steps). The RaidMaster uploader sends the stock with its next upload, and the RaidMaster bot shows it in #gildenbank and with /bank. Guilds without the RaidMaster bot notice nothing.
- **Alt notes with first and last names** (WoW Forever) on Korean and Chinese clients, where the name comes before the label ("Testa Beispiel의 부캐릭터"), are recognised again.
- **Changing the main** now removes the old alt label completely – with first and last name and in the client language ("Alt: First Last", "Reroll de …") – instead of leaving parts of it in the note.
- **Event sync**: one damaged entry no longer discards the other events of the same sync message.
- All game functions GuildSentinel needs are now chosen in one place (API.lua, modern API first, old one as fallback). Nothing changes for players.
- Developer test routine: real sends now count as an error in the report (T82), every action with consequences is checked to go through one place (T174), new cases for export, event announcements, first/last names and the bank character, and the cases that previously needed a replaced game function now run in the game too.

## 0.9.10
- **Alt notes in your client language**: notes that GuildSentinel writes itself ("Reroll de …", "… 的分身" and so on) are recognised again on French, Spanish, Italian, Portuguese, Korean and Chinese clients. Where the label would not fit into the short guild note (Russian), GuildSentinel writes the short form "Alt: Name".
- **AHSentinel** (formerly AH Analyzer Pro) is recognised under its new folder name (Addons page, market values).
- **Applicant whispers in combat** (WoW Forever): more than 30 whispers during one fight are now counted in the notice too instead of being dropped silently.
- More robust against damaged data: malformed event sync messages and broken event or thanks entries no longer cause errors.
- Test mode (developer only): no longer joins or leaves the server channel, sends nothing delayed after "Stop test mode" and leaves the real settings (last ad, free status, My week) untouched.
- New for the developer: `/gs testroutine` (button "Test everything" under Settings > Test mode) checks every feature and saves a report for the GoldSentinel review; the diagnosis shows the error counter. Nothing changes for players.

## 0.9.9
Fixes from the review:
- **Officer rights**: players who may only read officer notes no longer count as officers.
- **Applicant whispers in combat** (WoW Forever): if a message stays protected after combat, GuildSentinel reports once how many could not be read instead of losing them silently.
- **Player tooltip**: the combat lock applies to every modern client (WoW Forever, Retail).
- Absence and thanks messages from other players are only accepted when the sender matches exactly.

## 0.9.8
- Shared game-version detection (GoldSentinelGame.lua) updated to version 2: it also wins over early, withdrawn copies that other GoldSentinel addons briefly shipped, so loading several GoldSentinel addons together causes no errors. Nothing changes for players.

## 0.9.7
- Uses the shared game-version detection of all GoldSentinel addons (GoldSentinelGame.lua): Classic Era, WoW Forever and TBC are detected the same way everywhere, with the shared secret-value guard and first/last name comparison. `/gsgame` shows what was detected. Nothing changes for players.

## 0.9.5
- **WoW Forever hardening**: protection against secret values in combat (player tooltip, addon messages, cooldowns). Applicants who whisper during combat are added after combat instead of being lost.
- **First and last names** (WoW Forever): names are capitalised correctly, notes like "Alt of Testa Beispiel" are recognised, and a unique first name alone is enough for alts, thanks and mentors.
- Whispering a "First Last" name opens the whisper box for the full name.
- Modern APIs are used first (C_ChatInfo, C_GuildInfo, C_SpellBook), with the old ones as fallback.

## 0.9.4
- **Without a guild**: instead of empty pages the overview shows a hint – GuildSentinel is a guild tool, and members, events, board, polls, progress, professions, recruitment and the group finder appear once you are in a guild. My week, Addons and Settings stay available. Joining or leaving a guild takes effect right away.

## 0.9.3
- **Guild name**: the guild master can set a name for GuildSentinel under Leadership > Rank rights. It applies to everyone in the guild with the addon (ad, chronicle, rules, welcome guide, header). Empty = the name from the game. Only the guild master can change it.

## 0.9.2
- **Professions on WoW Forever**: GuildSentinel now also reads the new retail-style profession window. The game client decides the way: WoW Forever uses the new window, Classic Era and TBC the classic one as before. Linked professions, guild professions and NPC windows are not read.
- The "Open next profession" button opens the new window directly on WoW Forever if needed.

## 0.9.1
- Test mode is now developer-only: the Settings > Test mode tab and `/gs test` only appear for the developer account. Nothing else changes for players.

## 0.9.0
- **Who's free** (Group finder): one click flags you as free for dungeon, raid, quest group or PvP for 1, 2 or 4 hours. Everyone with GuildSentinel sees who is free, with level, item level and zone. Inside dungeons, raids and battlegrounds you automatically show as busy.
- After posting a group search, GuildSentinel tells you how many guild members are free for it right now.
- **Item level** with "I'll join": the searcher sees it in the replies and in chat.
- **Bulk actions** (Leadership, officers): remove inactive players by rule or promote several suggestions at once – always a checklist first, one step per click.
- **GRM import** (Leadership): alts, join dates and personal notes from Guild Roster Manager, with a preview.

## 0.8.3
- New **Support** button (PayPal link to copy) in the title bar and under Settings > General, also `/gs donate`. Opens only on click.

## 0.8.2
- Guild achievements: singular for the first weekly goal; names that are too long use a smaller font.
- Professions: old raw-material entries (e.g. Felweed as "Alchemy") are removed automatically.

## 0.8.1
- Settings > Features in three columns; probation advice follows the 40 % rule; overview counts departures like Leadership; My week markers and singulars; chronicle without duplicates; loot wishes preselect a dungeon; removing a question asks first; raw materials leave the watch list.

## 0.8.0
- All WoW client languages; Classic Era, WoW Forever and TBC Classic / Anniversary; Overview, Leadership, My week, loot wishes, questions, guild achievements, chronicle, weekly recap, welcome guide, features on/off.
