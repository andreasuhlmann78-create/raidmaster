-- GuildSentinel - TestRoutine.lua
-- Automatische Testroutine ("auf Herz und Nieren"), nur für den Entwickler (GoldSentinelDev).
--   /gs testroutine            alle Bereiche A bis J (gleich wie der Knopf "Alles testen" in Einstellungen > Testmodus)
--   /gs testroutine a … k      nur ein Bereich (k: Oberfläche im echten Client)
--   /gs testroutine whisperq   nur Anzeige: gemerkte Kampf-Flüsternachrichten und wie viele davon geschützt sind
-- IDs, Bereiche und Erwartungen wie in raidmaster/auftraege/GuildSentinel/testroutine-guildsentinel.txt (T01–T173),
-- dazu T174 (Aktionen nur über ns.Act) und T175–T181 (Bank-Charakter, anweisung-guildsentinel-gildenbank.txt).
-- Ergebnisse nur über GoldSentinelTest (Check / Skip / Client); der Bericht landet in GuildSentinelDB.gsTest.
--
-- Regeln (nachtrag-testroutinen.txt, gehen der Anweisung vor):
--   * Keine Blizzard-Funktion wird ersetzt, auch nicht vorübergehend. Ersetzt werden nur Felder eigener Tabellen
--     (ns, ns.API, Module, eigene Ersatz-Objekte) – über Swap(), immer wieder zurückgesetzt. Alte bzw. moderne
--     Clients ("Funktion fehlt") stellt die Routine über Einträge in ns.API nach (API.lua). Was sich so nicht
--     nachstellen lässt, ist ÜBERSPRUNGEN (mit Grund) oder IM CLIENT PRÜFEN.
--   * Aktionen mit Folgen laufen im Addon über ns.Act (Chat, Addon-Nachrichten, Einladen, Entfernen, Befördern,
--     Gildennotiz, Kanal, Flüsterfenster, Töne). Während der Routine ist ns.actRecorder gesetzt: nur mitschreiben.
--     Echte Aufrufe zählt ein hooksecurefunc (ersetzt nichts) – Erwartung 0.
--   * Geschützte Werte: Köderwerte in ns.testSecret, die ns.IsSecret als geschützt erkennt (issecretvalue bleibt
--     unberührt). Kampfsperre: ns.testCombat statt InCombatLockdown.
--   * Sandbox: GuildSentinelDB (ohne gsTest) und der Laufzustand werden vorher kopiert, am Ende verglichen und in
--     dieselben Tabellen zurückgeschrieben (ns.db und ns.guild bleiben mit den gespeicherten Daten verbunden).
--   * Berichte ohne Spieler-, Gilden- und Chatnamen. Erfundene Namen der Testgilde nur, wo der Fall sie braucht.

local ADDON, ns = ...
local L = ns.L

local R = {}
ns.Routine = R

R.AREAS = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K" }   -- K: Oberfläche im echten Client (0.9.14)
R.TOC_INTERFACES = { 11509, 11508, 16001, 20506, 20505 }    -- wie GuildSentinel.toc (Offline-Test vergleicht)
R.WAIT = 7.5                                                  -- Sekunden für die verzögerten Sendungen (T67, T167)

local RUN                 -- laufender Durchlauf (GoldSentinelTest-Objekt)
local ORANGE = "|cffff9933"

------------------------------------------------------------
-- Hilfen
------------------------------------------------------------
local function Ms()
	if debugprofilestop then return debugprofilestop() end
	return GetTime() * 1000
end

local function S(v)
	if v == nil then return "nil" end
	if ns.IsSecret(v) then return "<geschützt>" end
	return tostring(v)
end

local function Copy(v, seen)
	if type(v) ~= "table" then return v end
	seen = seen or {}
	if seen[v] then return seen[v] end
	local t = {}
	seen[v] = t
	for k, x in pairs(v) do t[Copy(k, seen)] = Copy(x, seen) end
	return t
end

-- dst in-place auf den Stand von src bringen (dieselben Tabellen bleiben erhalten); oben ohne gsTest
-- oben nicht vergleichen/zurücksetzen: gsTest (Bericht), gsSync (bekannte Mitspieler der gemeinsamen Sync-Datei –
-- ändert sich nebenher durch echte Nachrichten, gehört nicht zur Routine)
-- gsMarkt (Marktdaten der gemeinsamen Datei GoldSentinelMarkt.lua – ändert sich jederzeit von selbst durch fremde Scans
-- und Netz-Antworten, gehört nicht GuildSentinel) ebenso wenig
local SKIP = { gsTest = true, gsSync = true, gsMarkt = true }

local function RestoreInto(dst, src, top)
	for k in pairs(dst) do
		if src[k] == nil and not (top and SKIP[k]) then dst[k] = nil end
	end
	for k, v in pairs(src) do
		if not (top and SKIP[k]) then
			if type(v) == "table" and type(dst[k]) == "table" then RestoreInto(dst[k], v)
			else dst[k] = Copy(v) end
		end
	end
end

-- abweichende Pfade (höchstens max), Gilden-Schlüssel und Namen anonymisiert
local function Anon(k, depth)
	if type(k) ~= "string" then return tostring(k) end
	if depth == 2 then return "<gilde>" end            -- guilds.<Realm|Gilde>
	if k:find("|") then return "<schlüssel>" end
	if k:match("^%u") and not k:match("^%u+$") then return "<name>" end
	return k
end
local function Diff(a, b, path, out, max, depth, top)
	if #out >= max then return end
	if type(a) ~= type(b) then out[#out + 1] = path return end
	if type(a) ~= "table" then
		if a ~= b then out[#out + 1] = path end
		return
	end
	for k, v in pairs(a) do
		if not (top and SKIP[k]) then
			Diff(v, b[k], path .. "." .. Anon(k, depth + 1), out, max, depth + 1)
		end
	end
	for k in pairs(b) do
		if not (top and SKIP[k]) and a[k] == nil then
			if #out >= max then return end
			out[#out + 1] = path .. "." .. Anon(k, depth + 1)
		end
	end
end

local function Has(list, x)
	for _, v in ipairs(list or {}) do if v == x then return true end end
	return false
end

local function Count(t) local n = 0 for _ in pairs(t or {}) do n = n + 1 end return n end

------------------------------------------------------------
-- Ersetzen eigener Felder (nie _G, nie Blizzard-Tabellen)
------------------------------------------------------------
local swaps = {}
local BLIZZ = { C_ChatInfo = true, C_GuildInfo = true, C_PartyInfo = true, C_Container = true, C_Item = true, C_Spell = true,
	C_SpellBook = true, C_QuestLog = true, C_AddOns = true, C_TradeSkillUI = true, C_Timer = true }
local function Swap(tbl, key, value)
	assert(type(tbl) == "table" and not rawequal(tbl, _G), "Swap: nur eigene Tabellen")
	for name in pairs(BLIZZ) do assert(not rawequal(tbl, _G[name]), "Swap: keine Blizzard-Tabelle") end
	swaps[#swaps + 1] = { tbl, key, rawget(tbl, key) }
	tbl[key] = value
end
local function UnswapTo(n)
	for i = #swaps, n + 1, -1 do
		local s = swaps[i]
		s[1][s[2]] = s[3]
		swaps[i] = nil
	end
end
local function UnswapAll() UnswapTo(0) end
-- fn mit vorübergehend ersetzten Feldern ausführen; danach immer zurück
local function With(list, fn)
	local mark = #swaps
	local ok, a, b, c = pcall(function()
		for _, x in ipairs(list) do Swap(x[1], x[2], x[3]) end
		return fn()
	end)
	UnswapTo(mark)
	if not ok then error(a, 0) end
	return a, b, c
end

------------------------------------------------------------
-- Köderwerte für geschützte Werte ("secret values")
------------------------------------------------------------
-- Jeder Köder ist ein eigenes Objekt, das bei jeder Rechnung, jedem Vergleich, Zerlegen oder Zusammensetzen einen
-- Lua-Fehler wirft – wie ein geschützter Wert in WoW Forever. ns.IsSecret erkennt ihn über ns.testSecret.
local function NewBait()
	local p, mt
	if newproxy then
		p = newproxy(true)
		mt = getmetatable(p)
	else
		p, mt = {}, {}
		setmetatable(p, mt)
	end
	local function boom() error("secret value used", 2) end
	for _, k in ipairs({ "__add", "__sub", "__mul", "__div", "__mod", "__unm", "__concat", "__lt", "__le", "__len", "__index", "__newindex", "__call" }) do
		mt[k] = boom
	end
	mt.__tostring = function() return "<geschützt>" end
	return p
end
local function Bait()
	local b = NewBait()
	ns.testSecret = ns.testSecret or {}
	ns.testSecret[b] = true
	return b
end

------------------------------------------------------------
-- Recorder: was hinausginge, wird nur gezählt (ns.Act); echte Aufrufe zählt hooksecurefunc
------------------------------------------------------------
R.rec = {}
R.real = 0
R.realBy = {}
local hooked = false
local function InstallHooks()
	if hooked or not hooksecurefunc then return end
	hooked = true
	local function counter(name)
		return function() if R.running then R.real = R.real + 1; R.realBy[name] = (R.realBy[name] or 0) + 1 end end
	end
	for _, name in ipairs({ "SendChatMessage", "SendAddonMessage", "GuildInvite", "GuildUninvite", "GuildPromote", "GuildDemote", "GuildSetLeader",
		"GuildRosterSetPublicNote", "InviteUnit", "LeaveChannelByName",
		"ChatFrame_OpenChat", "ChatFrame_SendTell" }) do
		if type(_G[name]) == "function" then pcall(hooksecurefunc, name, counter(name)) end
	end
	for _, x in ipairs({ { "C_ChatInfo", "SendChatMessage" }, { "C_ChatInfo", "SendAddonMessage" }, { "C_GuildInfo", "Invite" },
		{ "C_GuildInfo", "Uninvite" }, { "C_GuildInfo", "Promote" }, { "C_GuildInfo", "Demote" }, { "C_GuildInfo", "SetLeader" },
		{ "C_PartyInfo", "InviteUnit" } }) do
		local t = _G[x[1]]
		if type(t) == "table" and type(t[x[2]]) == "function" then pcall(hooksecurefunc, t, x[2], counter(x[1] .. "." .. x[2])) end
	end
end
local function Recorded(what) return R.rec[what] or 0 end
-- geschützte Gilden-Funktionen, die über ns.Act liefen (während der Routine schreibt ns.Act nur mit, statt aufzurufen)
local PROTECTED_ACT = { "GuildInvite", "GuildUninvite", "GuildPromote", "GuildDemote", "GuildSetLeader",
	"C_GuildInvite", "C_GuildUninvite", "C_GuildPromote", "C_GuildDemote", "C_GuildSetLeader" }
local function ProtCount()
	local n = 0
	for _, k in ipairs(PROTECTED_ACT) do n = n + Recorded(k) end
	return n
end
local function RecTotal()
	local n = 0
	for _, v in pairs(R.rec) do n = n + v end
	return n
end

------------------------------------------------------------
-- Prüfungen (Bereichsfilter, Abbruch bei Kampf)
------------------------------------------------------------
local area                -- Bereich, der gerade läuft
local only                -- nur dieser Bereich (nil = alle)
local aborted

local function Want(a) return not only or only == a end

local function Check(id, a, name, fn)
	if not Want(a) then return end
	R.ranIds = R.ranIds or {}
	R.ranIds[id] = true
	if aborted then RUN:Skip(id, a, name, "Kampf begonnen") return end
	RUN:Check(id, a, name, fn)
end
local function Skip(id, a, name, why)
	if not Want(a) then return end
	R.ranIds = R.ranIds or {}
	R.ranIds[id] = true
	RUN:Skip(id, a, name, why)
end
local function Client(id, a, name, how)
	if not Want(a) then return end
	R.ranIds = R.ranIds or {}
	R.ranIds[id] = true
	RUN:Client(id, a, name, how)
end

-- kleine Erwartungs-Helfer: liefern ok, ist, soll
local function Eq(ist, soll) return ist == soll, S(ist), S(soll) end
local function True(v, what) return v and true or false, what and (what .. "=" .. S(v)) or S(v), "true" end
local function NoErr(fn, ...)
	local ok, err = pcall(fn, ...)
	if not ok then return false, "Lua: " .. tostring(err), "kein Fehler" end
	return true
end

-- Fehlerzähler: Unterschied seit einem Stand
local function ErrMark() return ns.errors and ns.errors.n or 0 end

------------------------------------------------------------
-- Testmodus kurz verlassen (reine Abfragen wie ns.IsOfficer, die im Testmodus immer true liefern)
------------------------------------------------------------
local function Outside(fn)
	local T = ns.Test
	local was = T.active
	T.active = false
	local ok, a, b, c = pcall(fn)
	T.active = was
	if not ok then error(a, 0) end
	return a, b, c
end

------------------------------------------------------------
-- Seiten und Reiter
------------------------------------------------------------
local function Pages()
	local out = {}
	for i, p in ipairs(ns.UI.pages or {}) do out[#out + 1] = { i = i, page = p, key = p.key } end
	return out
end

local function TabsOf(i)
	local list = {}
	for _, bar in ipairs(ns.UI.tabBars or {}) do
		if bar:GetParent() == ns.UI.panels[i] then
			for _, b in ipairs(bar.buttons) do list[#list + 1] = { bar = bar, key = b.key } end
		end
	end
	return list
end

local function OpenAllPages()
	local UI = ns.UI
	if not UI.frame then UI:Build() end
	UI.frame:Show()
	local n, errs = 0, {}
	for _, p in ipairs(Pages()) do
		if UI:PageOn(p.page) then
			local ok, err = pcall(UI.Select, UI, p.i)
			n = n + 1
			if not ok then errs[#errs + 1] = p.key .. ": " .. tostring(err) end
		end
	end
	return n, errs
end

local function OpenAllTabs()
	local UI = ns.UI
	local n, errs = 0, {}
	for _, p in ipairs(Pages()) do
		if UI:PageOn(p.page) then
			pcall(UI.Select, UI, p.i)
			for _, t in ipairs(TabsOf(p.i)) do
				if t.bar:IsVisible(t.key) then
					n = n + 1
					local ok, err = pcall(t.bar.Select, t.bar, t.key)
					if not ok then errs[#errs + 1] = p.key .. ">" .. tostring(t.key) .. ": " .. tostring(err) end
				end
			end
		end
	end
	return n, errs
end
R.OpenAllPages, R.OpenAllTabs = OpenAllPages, OpenAllTabs

------------------------------------------------------------
-- A. LADEN UND ERKENNUNG
------------------------------------------------------------
local function GetMeta(addon, field)
	local fn = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
	if not fn then return nil end
	local ok, v = pcall(fn, addon, field)
	return ok and v or nil
end

local function Interface() return select(4, GetBuildInfo()) end

local function Real()
	-- echte Weichen aus GoldSentinelGame (ohne Test-Flavor)
	local G = GoldSentinelGame
	return { forever = G.IsForever, tbc = G.IsTBC, modern = G.IsModern, flavor = G.flavor }
end

local function Flavor(f)
	GoldSentinelGame.SetTestFlavor(f)
	ns.Game:Refresh()
end

function R:AreaA()
	local G = GoldSentinelGame
	local Game = ns.Game
	Check("T01", "A", "alle Dateien geladen", function()
		local missing = {}
		for _, k in ipairs({ "Game", "Comm", "RMI", "Links", "Roster", "Recruit", "Prof", "Race", "Jubilee", "Attune", "Group",
			"Free", "Activity", "Promote", "Rules", "Comp", "Craft", "Poll", "Tooltip", "Social", "Board", "Events", "Cooldowns",
			"Goals", "Lead", "Bulk", "Gear", "Ask", "Chronicle", "Sync", "Test", "UI", "Donate", "MyWeek", "Health",
			"ProgressPage", "BoardPage" }) do
			if type(ns[k]) ~= "table" then missing[#missing + 1] = k end
		end
		if not (ns.L and ns.N and ns.EN) then missing[#missing + 1] = "L/N/EN" end
		local keys = {}
		for _, p in ipairs(ns.UI.pages or {}) do keys[#keys + 1] = p.key end
		for _, k in ipairs({ "home", "members", "group", "events", "poll", "board", "myweek", "progress", "prof", "recruit", "lead", "addons", "settings" }) do
			if not Has(keys, k) then missing[#missing + 1] = "Seite " .. k end
		end
		if #keys ~= 13 then missing[#missing + 1] = "Seiten " .. #keys end
		return #missing == 0, table.concat(missing, ", "), "alles vorhanden"
	end)
	Check("T02", "A", "Version .toc = Code", function()
		local v = GetMeta("GuildSentinel", "Version")
		return v == ns.version, S(v), ns.version
	end)
	Check("T03", "A", "Interface-Nummer des Clients steht in der .toc", function()
		local n = Interface()
		return Has(R.TOC_INTERFACES, n), S(n), "in .toc (" .. table.concat(R.TOC_INTERFACES, ", ") .. ")"
	end)
	Check("T04", "A", "GoldSentinelGame", function()
		local bad = {}
		if type(G.version) ~= "number" or G.version < 2 then bad[#bad + 1] = "version " .. S(G.version) end
		for _, f in ipairs({ "IsSecret", "AnySecret", "Safe", "InCombat", "Short", "CleanName", "SameName", "Status", "SetTestFlavor", "Recalc" }) do
			if type(G[f]) ~= "function" then bad[#bad + 1] = f end
		end
		if (G.Status() or "") == "" then bad[#bad + 1] = "Status leer" end
		return #bad == 0, table.concat(bad, ", "), "ja"
	end)
	Check("T05", "A", "Reihenfolge der gemeinsamen Dateien", function()
		local GT = GoldSentinelTest
		local reg = GT and GT.registry and GT.registry.GuildSentinel
		local ok = GoldSentinelDev and GoldSentinelDev.version == 1 and GT and (GT.version or 0) >= 1 and reg and reg.db == GuildSentinelDB
		return ok and true or false, "Dev " .. S(GoldSentinelDev and GoldSentinelDev.version) .. ", Test " .. S(GT and GT.version) .. ", registriert " .. S(reg ~= nil), "ja"
	end)
	local real = Real()
	Check("T06", "A", "echte Weichen", function()
		local bad = {}
		if Game.FOREVER ~= G.IsForever then bad[#bad + 1] = "FOREVER" end
		if Game.TBC ~= G.IsTBC then bad[#bad + 1] = "TBC" end
		if Game.MODERN ~= G.IsModern then bad[#bad + 1] = "MODERN" end
		if Game.MODERN_PROFESSIONS ~= Game.FOREVER then bad[#bad + 1] = "MODERN_PROFESSIONS" end
		if Game.toc ~= G.toc then bad[#bad + 1] = "toc" end
		if G.IsForever and not (G.flavor == "forever" and G.IsModern and G.HasSecrets) then bad[#bad + 1] = "Forever: flavor/modern/secrets" end
		if G.IsEra and G.IsModern then bad[#bad + 1] = "Era modern" end
		if G.IsTBC and G.IsModern then bad[#bad + 1] = "TBC modern" end
		return #bad == 0, table.concat(bad, ", ") .. " (" .. S(G.flavor) .. ")", "wie GoldSentinelGame"
	end)
	Check("T07", "A", "Simulation Forever", function()
		Flavor("forever")
		local ok = Game.FOREVER and Game.MODERN and Game.MODERN_PROFESSIONS and Game.BOTH_HYBRIDS
		local p = ns.Proper("testa beispiel")
		local st = G.Status()
		return (ok and p == "Testa Beispiel" and st:find("[", 1, true)) and true or false, "Proper=" .. S(p), "Testa Beispiel, [Test]"
	end)
	Check("T08", "A", "Simulation Era", function()
		Flavor("era")
		local p = ns.Proper("testa beispiel")
		local same = ns.Same("Testa", "Testa Beispiel")
		return (not Game.FOREVER and not Game.MODERN and p == "Testabeispiel" and same == false), "Proper=" .. S(p) .. " Same=" .. S(same), "Testabeispiel, false"
	end)
	Check("T09", "A", "Simulation TBC", function()
		Flavor("tbc")
		return (Game.TBC and not Game.MODERN and Game.BOTH_HYBRIDS) and true or false, "TBC=" .. S(Game.TBC) .. " MODERN=" .. S(Game.MODERN), "TBC, nicht modern"
	end)
	Skip("T09b", "A", "Simulation TBC: Inhalte", "beim Laden festgelegt, siehe D / offline 20505")
	Check("T10", "A", "Simulation Retail", function()
		Flavor("retail")
		local n, errs = OpenAllPages()
		return (Game.MODERN and not Game.FOREVER and #errs == 0) and true or false, n .. " Seiten, " .. table.concat(errs, "; "), "modern, keine Fehler"
	end)
	Check("T11", "A", "zurück auf echt", function()
		Flavor(nil)
		local st = G.Status()
		local ok = Game.FOREVER == real.forever and Game.TBC == real.tbc and Game.MODERN == real.modern and not st:find("[", 1, true)
		return ok and true or false, S(G.flavor), S(real.flavor)
	end)
	Flavor(nil)
end

------------------------------------------------------------
-- B. JEDE FUNKTION (Testmodus mit Testgilde)
------------------------------------------------------------
local function G() return ns.guild end
local function Me() return ns.Me() end
local function Printed(fn)
	-- zählt, was ns:Print in fn ausgibt (eigenes Feld, keine Blizzard-Funktion)
	local out = {}
	With({ { ns, "Print", function(_, msg) out[#out + 1] = tostring(msg) end } }, fn)
	return out
end
local function AnyHas(list, pat)
	for _, s in ipairs(list) do if s:find(pat, 1, true) then return true end end
	return false
end

function R:AreaB()
	local T, UI, Ro, So = ns.Test, ns.UI, ns.Roster, ns.Social
	Check("T12", "B", "T:Start/T:Stop", function()
		local was = T.active
		if was then T:Stop() end
		local before = { ns.guild, ns.guildKey, Ro.list, ns.Comm.users, ns.Free.list }
		T:Start()
		local okStart = ns.guildKey == "TEST" and #Ro.list == #T.members
		T:Stop()
		local after = { ns.guild, ns.guildKey, Ro.list, ns.Comm.users, ns.Free.list }
		local same = true
		for i = 1, 5 do if before[i] ~= after[i] then same = false end end
		T:Start()
		return (okStart and same) and true or false, "Start " .. S(okStart) .. ", Bezüge gleich " .. S(same), "ja"
	end)
	Check("T13", "B", "nur Entwickler", function()
		return With({ { GoldSentinelDev, "IsDev", function() return false end } }, function()
			local feat = ns.Feature("dev")
			local active = T.active
			SlashCmdList.GUILDSENTINEL("test")
			return (feat == false and T.active == active) and true or false, "Feature(dev)=" .. S(feat), "false, Testmodus unverändert"
		end)
	end)
	Check("T14", "B", "Test-Ereignisse (13)", function()
		local bad = {}
		for _, ev in ipairs(T.EVENTS) do
			local ok, err = pcall(T.Trigger, T, ev.key)
			if not ok then bad[#bad + 1] = ev.key .. ": " .. tostring(err) end
		end
		if Count(G().thanks) == 0 then bad[#bad + 1] = "thanks" end
		if not ns.Free.list.Mira then bad[#bad + 1] = "free" end
		if not (G().cds.Thalia) then bad[#bad + 1] = "cooldown" end
		return #bad == 0, table.concat(bad, "; "), "je Ereignis OK"
	end)
	Check("T15", "B", "Hauptfenster", function()
		if not UI.frame then UI:Build() end
		UI.frame:Hide()
		UI:Toggle(); local a = UI.frame:IsShown()
		UI:Toggle(); local b = UI.frame:IsShown()
		UI.frame:Show()
		local esc = Has(UISpecialFrames, "GuildSentinelFrame")
		return (a and not b and esc) and true or false, S(a) .. "/" .. S(b) .. " Esc " .. S(esc), "true/false Esc true"
	end)
	Check("T16", "B", "alle 13 Seiten", function()
		local n, errs = OpenAllPages()
		return n == 13 and #errs == 0, n .. " " .. table.concat(errs, "; "), "13 ohne Fehler"
	end)
	Check("T17", "B", "alle Reiter", function()
		local n, errs = OpenAllTabs()
		return n >= 30 and #errs == 0, n .. " " .. table.concat(errs, "; "), ">= 30 ohne Fehler"
	end)
	Check("T18", "B", "Dialoge", function()
		UI:Info("x", "y", true)
		local f = UI.infoFrame
		local ok = f and f:IsShown()
		if f then f:Hide() end
		UI:Confirm("x", function() end)
		UI:Ask("x", "", function() end)
		UI:SetEscTarget(true); local m = Has(UISpecialFrames, "GuildSentinelMenu")
		UI:SetEscTarget(false); local fr = Has(UISpecialFrames, "GuildSentinelFrame") and not Has(UISpecialFrames, "GuildSentinelMenu")
		return (ok and m and fr) and true or false, "Info " .. S(ok) .. " Esc " .. S(m) .. "/" .. S(fr), "ja"
	end)
	Check("T19", "B", "Minimap-Knopf", function()
		local was = ns.db.minimapShow
		local b = _G.GuildSentinelMinimapButton
		ns.db.minimapShow = false; UI:UpdateMinimap(); local off = b and not b:IsShown()
		ns.db.minimapShow = true; UI:UpdateMinimap(); local on = b and b:IsShown()
		ns.db.minimapShow = was; UI:UpdateMinimap()
		local r0 = RecTotal()
		ns.Recruit:Post()
		return (b and off and on and RecTotal() == r0) and true or false, "Knopf " .. S(b ~= nil) .. " aus " .. S(off) .. " an " .. S(on), "versteckt/sichtbar, Recorder 0"
	end)
	Check("T20", "B", "Spenden", function()
		local D = ns.Donate
		D.Show()
		local f = D.Frame()
		local ok = f and f:IsShown() and f.edit:GetText() == D.URL and Has(UISpecialFrames, f:GetName())
		D.Hide()
		D.Toggle(); local a = D.IsShown(); D.Toggle(); local b = D.IsShown()
		return (ok and a and not b) and true or false, "Fenster " .. S(ok) .. " Toggle " .. S(a) .. "/" .. S(b), "ja"
	end)
	Check("T21", "B", "Ohne Gilde", function()
		return With({ { ns, "InGuild", function() return false end } }, function()
			local on = {}
			for _, p in ipairs(Pages()) do if UI:PageOn(p.page) then on[#on + 1] = p.key end end
			table.sort(on)
			local s = table.concat(on, ",")
			local n, errs = OpenAllPages()
			return s == "addons,home,myweek,settings" and #errs == 0, s, "addons,home,myweek,settings"
		end)
	end)
	Check("T22", "B", "alle Unterbefehle", function()
		local bad = {}
		local dbg = ns.debug
		for _, c in ipairs({ { "gruppe", "group" }, { "group", "group" }, { "lfg", "group" }, { "termine", "events" }, { "events", "events" },
			{ "brett", "board" }, { "board", "board" }, { "wo", "members" }, { "umfrage", "poll" }, { "poll", "poll" },
			{ "fortschritt", "progress" }, { "zugang", "progress" }, { "werbung", "recruit" }, { "suche Fläschchen", "prof" } }) do
			local ok, err = pcall(SlashCmdList.GUILDSENTINEL, c[1])
			if not ok then bad[#bad + 1] = c[1] .. ": " .. tostring(err)
			elseif not UI:IsPageShown(c[2]) then bad[#bad + 1] = c[1] .. " -> nicht " .. c[2] end
		end
		for _, c in ipairs({ "", "", "regeln", "spenden", "berufe", "debug", "debug", "xyz" }) do
			local ok, err = pcall(SlashCmdList.GUILDSENTINEL, c)
			if not ok then bad[#bad + 1] = c .. ": " .. tostring(err) end
		end
		if _G.GuildSentinelRules then _G.GuildSentinelRules:Hide() end
		ns.Donate.Hide()
		if (not ns.debug) ~= (not dbg) then bad[#bad + 1] = "debug" end
		if UI.frame then UI.frame:Show() end
		return #bad == 0, table.concat(bad, "; "), "jede Seite offen"
	end)
	Check("T23", "B", "/gs danke", function()
		local p1 = Printed(function() SlashCmdList.GUILDSENTINEL("danke") end)
		local p2 = Printed(function() SlashCmdList.GUILDSENTINEL("danke Niemandda") end)
		local n0 = Count(G().thanks)
		for id, t in pairs(G().thanks) do if t.from == Me() and t.to == "Mira" then G().thanks[id] = nil end end
		n0 = Count(G().thanks)
		SlashCmdList.GUILDSENTINEL("danke Mira")
		local ok = #p1 > 0 and AnyHas(p2, (L["%s ist nicht in der Gilde."]:gsub("%%s.*", ""))) and Count(G().thanks) == n0 + 1
		return ok and true or false, "Hinweise " .. #p1 .. "/" .. #p2 .. ", Danke " .. (Count(G().thanks) - n0), "Hinweis, +1"
	end)
	Check("T24", "B", "/gs weg", function()
		SlashCmdList.GUILDSENTINEL("weg 3 Urlaub")
		local a = G().away[Me()]
		local ok1 = a and math.abs(a.u - (ns.Now() + 3 * 86400)) < 60 and a.note == "Urlaub"
		SlashCmdList.GUILDSENTINEL("weg")
		local b = G().away[Me()]
		return (ok1 and b and b.u == 0) and true or false, "u ok " .. S(ok1) .. ", danach " .. S(b and b.u), "jetzt+3 Tage, dann 0"
	end)
	Check("T25", "B", "Roster:Scan", function()
		local s0 = Ro.scans or 0
		Ro:Scan()
		local all = true
		for _, m in ipairs(T.members) do if m.name and not Ro.byName[m.name] then all = false end end
		return (#Ro.list == #T.members and all and (Ro.scans or 0) >= s0) and true or false, #Ro.list .. "/" .. #T.members, "alle"
	end)
	Check("T26", "B", "Twinks aus Notiz", function()
		local a, b, c = Ro:MainOf("Rokwar"), Ro:MainOf("Mirabank"), Ro:MainOf("Gromsham")
		local ok = a == "Testa" and b == "Mira" and c == "Grom" and Has(Ro:AltsOf("Testa"), "Rokwar") and not Ro:IsAlt("Testa")
		return ok, S(a) .. "," .. S(b) .. "," .. S(c), "Testa,Mira,Grom"
	end)
	Check("T27", "B", "SetMain/SetMyMain", function()
		local r0 = Recorded("SendAddonMessage")
		Ro:SetMain("Durok", "grom", true); local a = Ro:MainOf("Durok")
		Ro:SetMain("Durok", "", true); local b = Ro:MainOf("Durok")
		Ro:SetMyMain(Me())
		local c = G().alts[Me()] and G().alts[Me()].m
		return (a == "Grom" and b == nil and c == "" and Recorded("SendAddonMessage") == r0) and true or false, S(a) .. "," .. S(b) .. "," .. S(c), "Grom,nil,''"
	end)
	Check("T28", "B", "Verlauf", function()
		T:Kick("Neuling")
		local k1 = G().log[1] and G().log[1].k
		T:Promote("Durok")
		local k2 = G().log[1] and G().log[1].k
		return (k1 == "leave" and k2 == "promote" and #G().log <= Ro.LOG_MAX) and true or false, S(k1) .. "," .. S(k2), "leave,promote"
	end)
	Check("T29", "B", "Systemmeldungen live", function()
		if type(ERR_GUILD_JOIN_S) ~= "string" then return true, "ERR_GUILD_JOIN_S fehlt (kein Fehler)" end
		local f = ns.eventFrame:GetScript("OnEvent")
		f(ns.eventFrame, "CHAT_MSG_SYSTEM", string.format(ERR_GUILD_JOIN_S, "Testneu"))
		return True(Ro.liveJoin and Ro.liveJoin.Testneu, "liveJoin")
	end)
	Check("T30", "B", "Listen", function()
		Ro:Ranks(); Ro:Classes(); Ro:Stats()
		local names = {}
		for _, e in ipairs(Ro:Filtered({ text = "test" })) do names[#names + 1] = e.name end
		local inact = {}
		for _, e in ipairs(Ro:Inactive(30)) do inact[#inact + 1] = e.name end
		-- Suche findet auch den Twink (Rokwar) des Treffers
		return (Has(names, "Testa") and Has(names, "Rokwar") and Has(inact, "Brann")) and true or false,
			table.concat(names, ",") .. " | " .. table.concat(inact, ","), "Testa,Rokwar | Brann"
	end)
	Check("T31", "B", "Export", function()
		local M
		for _, p in ipairs(Pages()) do if p.key == "members" then M = p.page end end
		if not (M and M.ExportText) then return false, "Seite Mitglieder fehlt", "Export" end
		local txt, csv = M:ExportText(nil, false), M:ExportText("csv", false)
		local function Lines(t) local n = 0 for _ in t:gmatch("[^\n]+") do n = n + 1 end return n end
		local n = #Ro.list
		return (txt ~= "" and Lines(txt) >= n and Lines(csv) >= n) and true or false, "Zeilen " .. Lines(txt) .. "/" .. Lines(csv), ">= " .. n
	end)
	Check("T32", "B", "Abwesenheit", function()
		So:SetAway(nil, 3, "x")
		So:SetAway("Testa", 2, "")
		local twink = So:IsAway("Rokwar")
		So:SetAway("Testa", 0, "")
		So:SetAway(nil, 0, "")
		local blocked = Outside(function()
			return With({ { ns, "IsOfficer", function() return false end } }, function()
				local before = G().away.Ylva
				Printed(function() So:SetAway("Ylva", 2, "") end)
				return G().away.Ylva == before
			end)
		end)
		return (twink ~= nil and blocked) and true or false, "Twink " .. S(twink ~= nil) .. " gesperrt " .. S(blocked), "ja"
	end)
	Check("T33", "B", "Paten", function()
		So:SetMentor("Lowbie", "testa")
		local m = So:MentorOf("Lowbie")
		local list = {}
		for _, x in ipairs(So:Mentees("Testa") or {}) do list[#list + 1] = type(x) == "table" and x.name or x end
		return (m == "Testa" and Has(list, "Lowbie")) and true or false, S(m) .. " / " .. table.concat(list, ","), "Testa / Lowbie"
	end)
	Check("T34", "B", "Danke", function()
		for id, t in pairs(G().thanks) do if t.from == Me() and t.to == "Thalia" then G().thanks[id] = nil end end
		local n0 = Count(G().thanks)
		So:Thank("Thalia", "Hilfe")
		local n1 = Count(G().thanks)
		So:Thank("Thalia", "Hilfe")
		So:Thank(Me(), "x")
		local n2 = Count(G().thanks)
		local top = So:ThanksTop(7)
		return (n1 == n0 + 1 and n2 == n1 and top[1] ~= nil) and true or false, (n1 - n0) .. "/" .. (n2 - n1), "1/0"
	end)
	Check("T35", "B", "Gildennotiz", function()
		local s = So:NoteWithMain("", "Testa")
		local r0 = Recorded("GuildRosterSetPublicNote")
		So:WriteNote("Rokwar")
		So:WriteAllNotes()
		local want = string.format(L["Twink von %s"], "Testa")
		if #want > So.NOTE_MAX then want = "Alt: Testa" end
		return (s == want and #s <= So.NOTE_MAX and Recorded("GuildRosterSetPublicNote") == r0) and true or false, S(s), "Twink-Notiz, Recorder 0"
	end)
	Check("T36", "B", "Gildenchat mit Main", function()
		local _, text = So.ChatFilter(nil, "CHAT_MSG_GUILD", "hi", "Gromsham-Test")
		local ok1 = type(text) == "string" and text:find("[Grom]", 1, true) ~= nil
		local was = ns.db.chatMain
		ns.db.chatMain = false
		local r2 = So.ChatFilter(nil, "CHAT_MSG_GUILD", "hi", "Gromsham-Test")
		ns.db.chatMain = was
		return (ok1 and r2 == false) and true or false, S(ok1), "[Grom] davor, aus -> false"
	end)
	Check("T37", "B", "'ist online' mit Main", function()
		local fmt = ERR_FRIEND_ONLINE_SS or "|Hplayer:%s|h[%s]|h has come online."
		local _, text = So.SystemFilter(nil, "CHAT_MSG_SYSTEM", string.format(fmt, "Rokwar", "Rokwar"))
		local twinkTxt = string.format(L["Twink von %s"], "Testa")
		return (type(text) == "string" and text:find(twinkTxt, 1, true)) and true or false, S(text ~= nil), "mit Twink-Hinweis"
	end)
	Check("T38", "B", "Tooltip-Zeilen", function()
		local TT = ns.Tooltip
		local l1 = TT:Lines("Rokwar")
		local l3 = TT:Lines("Niemanddaxy")
		local added = 0
		local fake = { AddLine = function() added = added + 1 end, Show = function() end }
		TT:Add(fake, "Rokwar")
		local was = ns.db.tooltip
		ns.db.tooltip = false
		local before = added
		TT:Add(fake, "Rokwar")
		ns.db.tooltip = was
		return (l1 and l1[1] and l1[1]:find("Testa", 1, true) and l3 == nil and before > 0 and added == before) and true or false,
			"Zeilen " .. before .. ", aus +" .. (added - before), "Testa, >0, aus 0"
	end)
	Check("T39", "B", "Tooltip-Haken", function()
		local TT = ns.Tooltip
		local want = (TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Unit) and "tdp" or "script"
		if not TT.hooked then TT:Hook() end
		return Eq(TT.hookWay, want)
	end)
	Check("T40", "B", "Gruppensuche", function()
		local Gp = ns.Group
		local s = Gp:Post("quest", { dps = true }, 1, "x", "guild")
		local mine = Gp:Mine()
		local wire = Gp:Wire(s)
		Gp:RolesText(s); Gp:Joins(s)
		local r0 = Recorded("InviteUnit")
		Gp:Invite("Grom")
		Gp:Close(s.id, true)
		return (mine == s and type(wire) == "table" and Gp:Mine() == nil and Recorded("InviteUnit") == r0) and true or false, "Mine " .. S(mine == s), "ja"
	end)
	Check("T41", "B", "Server-Kanal im Testmodus", function()
		local was = ns.db.lfgServer
		local r0 = Recorded("JoinChannel") + Recorded("LeaveChannelByName")
		local real0 = R.real
		ns.db.lfgServer = false; ns.Group:LeaveChannel()
		ns.db.lfgServer = true; ns.Group:JoinChannel()
		ns.SetFeature("group", false); ns.SetFeature("group", true)
		ns.db.lfgServer = was
		local r1 = Recorded("JoinChannel") + Recorded("LeaveChannelByName")
		return (r1 == r0 and R.real == real0) and true or false, (r1 - r0) .. " aufgezeichnet, " .. (R.real - real0) .. " echt", "0"
	end)
	Check("T42", "B", "Wer ist frei", function()
		local Fr = ns.Free
		Fr:Set({ dungeon = true }, 2)
		local m = Fr:Mine()
		Fr:KindsText({ dungeon = true }); Fr:CountFor("dungeon")
		Fr:Clear()
		return (m ~= nil and Fr:Mine() == nil) and true or false, "Mine " .. S(m ~= nil), "gesetzt, danach nil"
	end)
	Check("T43", "B", "Termine", function()
		local E = ns.Events
		local e = E:Create("Test", "dungeon", ns.Now() + 86400, 60, "")
		if not e then return false, "nicht angelegt", "Termin" end
		local c1 = E:Counts(e)
		E:Reply(e.id, "no")
		local c2 = E:Counts(e)
		local up = E:Upcoming()
		local can = E:CanEdit(e)
		E:Cancel(e.id)
		return (c1.yes == 1 and c2.no == 1 and #up > 0 and can) and true or false, c1.yes .. "/" .. c2.no, "1/1"
	end)
	Check("T44", "B", "Zeiteingabe", function()
		local E = ns.Events
		local a, b, c, d = E:ParseWhen("", "20:00"), E:ParseWhen("morgen", "20.30"), E:ParseWhen("tomorrow", "9"), E:ParseWhen("", "25:00")
		return (a and b and c and d == nil) and true or false, S(a ~= nil) .. S(b ~= nil) .. S(c ~= nil) .. S(d), "Zeiten, nil"
	end)
	Check("T45", "B", "Termin ansagen", function()
		local E = ns.Events
		UI:Open("events")
		local Ev
		for _, p in ipairs(Pages()) do if p.key == "events" then Ev = p.page end end
		local btn = Ev and Ev.detail and Ev.detail.announce
		if not btn then return false, "Knopf fehlt", "Ansage-Knopf" end
		local e = E:Create("Ansage", "dungeon", ns.Now() + 86400, 60, "")
		if not e then return false, "nicht angelegt", "Termin" end
		local r0, real0 = Recorded("SendChatMessage"), R.real
		local out = With({ { Ev.list, "Selected", function() return e end } }, function()
			return Printed(function() btn:GetScript("OnClick")(btn) end)
		end)
		E:Cancel(e.id)
		local test = AnyHas(out, "[Test]")
		return (test and Recorded("SendChatMessage") == r0 and R.real == real0) and true or false, "[Test] " .. S(test) .. ", Recorder " .. (Recorded("SendChatMessage") - r0), "[Test], 0"
	end)
	Check("T46", "B", "Umfragen", function()
		local Po = ns.Poll
		local p = Po:Create("Frage?", { "1", "2", "3", "4", "5", "6", "7", "8", "9" }, 1)
		if not p then return false, "nicht angelegt", "Umfrage" end
		Po:Vote(p.id, 2)
		local counts, total = Po:Results(p)
		Po:OpenUnvoted()
		Po:Close(p.id)
		return (#p.o == Po.MAX_OPTIONS and counts[2] == 1 and total == 1) and true or false, #p.o .. " Optionen, Stimmen " .. S(total), Po.MAX_OPTIONS .. ", 1"
	end)
	Check("T47", "B", "Dienste", function()
		local B = ns.Board
		local bad = {}
		for _, s in ipairs(B.SERVICES or {}) do if not B:ServiceName(s.key) then bad[#bad + 1] = s.key end end
		B:SetOffer({}, "x"); B:MyOffer(); B:ClearOffer()
		return #bad == 0, table.concat(bad, ","), "alle mit Namen"
	end)
	Check("T48", "B", "Biete/Suche", function()
		local B = ns.Board
		local item, name = T:Item("cloth")
		local e = B:Post("offer", item, name, 20, 0, "")
		if not e then return false, "nicht angelegt", "Eintrag" end
		local listed = false
		for _, x in ipairs(B:List("offer")) do if x == e then listed = true end end
		local can = B:CanEdit(e)
		B:Contact(e)
		B:Remove(e.id)
		return (listed and can) and true or false, "Liste " .. S(listed), "ja"
	end)
	Check("T49", "B", "Beute-Wünsche", function()
		local Ge = ns.Gear
		local act = ns.Group.ACTIVITIES and ns.Group.ACTIVITIES[1] and ns.Group.ACTIVITIES[1].key
		local e
		for k in pairs(ns.Group.BY_KEY or {}) do if not act then act = k end end
		e = Ge:Add(14047, "Runenstoff", act)
		if not e then return false, "nicht angelegt (" .. S(act) .. ")", "Eintrag" end
		Ge:Counts(); Ge:Mine(); Ge:Done(e.id); Ge:Remove(e.id)
		return true
	end)
	Check("T50", "B", "Fragen", function()
		local Ak = ns.Ask
		local e = Ak:Create("Wer weiss?")
		if not e then return false, "nicht angelegt", "Frage" end
		Ak:Answer(e.id, "Ich")
		local ok = e.answers and e.answers[Me()] ~= nil
		Ak:OpenCount(); Ak:Remove(e.id)
		return True(ok, "Antwort")
	end)
	Check("T51", "B", "Berufe-Daten", function()
		local P = ns.Prof
		P:Of("Thalia"); P:Overview(); P:ProfNames(); P:Openable(); P:NextToOpen()
		local f = P:Find("a")
		local wk = P:WindowKind()
		local want = ns.Game.MODERN_PROFESSIONS and "modern" or "klassisch"
		return (type(f) == "table" and type(wk) == "string") and true or false, S(wk), want
	end)
	Client("T52", "B", "Berufsfenster einlesen", "Jedes eigene Berufsfenster einmal öffnen, dann /gs testroutine b: Seite Berufe zeigt die eigenen Rezepte")
	Check("T53", "B", "Herstellung", function()
		local Cr = ns.Craft
		local imp = Cr.IMPORTANT and Cr.IMPORTANT[1]
		Cr:Gaps(); Cr:MissingProfs(); Cr:WantedText()
		local r = Cr:Request(imp and imp.i or 14047, "x", 1, "")
		if r then Cr:Take(r.id); Cr:Done(r.id); Cr:Remove(r.id) end
		return (imp ~= nil and r ~= nil) and true or false, "IMPORTANT " .. S(imp ~= nil), "ja"
	end)
	Check("T54", "B", "Abklingzeiten", function()
		local Cd = ns.Cooldowns
		Cd:Mine()
		local list = Cd:List()
		local t1 = Cd:ReadyText({ isReady = true })
		local t2 = Cd:ReadyText({ ready = ns.Now() + 1800 })
		local t3 = Cd:ReadyText({ ready = ns.Now() + 5 * 3600 })
		local t4 = Cd:ReadyText({ ready = ns.Now() + 2 * 86400 })
		return (type(list) == "table" and t1 and t2 and t3 and t4) and true or false, #list .. " Einträge", "Texte"
	end)
	Check("T55", "B", "Leveling-Rennen", function()
		local list = ns.Race:Ranking(true)
		ns.Race:First60()
		return #list > 0, #list .. " Einträge", "> 0"
	end)
	Check("T56", "B", "Jubiläen", function()
		local j = ns.Jubilee:JoinDate("Testa")
		ns.Jubilee:Due()
		return True(j ~= nil, "Beitritt")
	end)
	Check("T57", "B", "Zugänge", function()
		local A = ns.Attune
		A:Mine(); A:Scan(true)
		local rows = A:Rows(1, true)
		A:Summary(rows); A:Groups()
		return type(rows) == "table", #rows .. " Zeilen", "Tabelle"
	end)
	Check("T58", "B", "Ziele", function()
		local Go = ns.Goals
		local ws = Go:WeekStart()
		local t0 = Go:Target()
		Go:SetTarget(30)
		local t1 = Go:Target()
		Go:WeekLevels(); Go:CheckWeek(); Go:CheckMiles()
		return (ws < ns.Now() and t1 == 30) and true or false, S(t1), "30"
	end)
	Check("T59", "B", "Chronik", function()
		local Ch = ns.Chronicle
		local tl = Ch:Timeline()
		Ch:ExportText(); Ch:Achievements(); Ch:ReviewText(Ch:WeekStats(ns.Now() - 7 * 86400, ns.Now())); Ch:CheckReview()
		return #tl > 0, #tl .. " Einträge", "> 0"
	end)
	Check("T60", "B", "Aufstellung", function()
		local C = ns.Comp
		local cls = C:Classes()
		local both = Has(cls, "PALADIN") and Has(cls, "SHAMAN")
		local r0 = Recorded("SendAddonMessage")
		C:Table(); C:Missing(); C:WantedText(3); C:ShareRole()
		local role = C:Role("Grom")
		local okH = (not ns.Game.BOTH_HYBRIDS) or both
		return (okH and role == "tank" and Recorded("SendAddonMessage") == r0) and true or false, "Hybride " .. S(both) .. " Grom " .. S(role), "tank"
	end)
	Check("T61", "B", "Online-Zeiten", function()
		local A = ns.Activity
		A:Sample(); A:Grid(); A:Best(3); A:Measurements()
		return True(type(A:ActiveDays("Durok")) == "number", "ActiveDays Zahl")
	end)
	Check("T62", "B", "Beförderung", function()
		local P = ns.Promote
		P:Rule(3)
		P:Candidates()
		local r0, real0 = Recorded("GuildPromote"), R.real
		P:Promote("Durok")
		return (Recorded("GuildPromote") == r0 and R.real == real0) and true or false, "aufgezeichnet " .. (Recorded("GuildPromote") - r0), "0 (ns.Blocked)"
	end)
	Check("T63", "B", "Leitung", function()
		local Le = ns.Lead
		Le:AddNote("Durok", "Notiz")
		local notes = Le:Notes("Durok")
		local id = notes and next(notes)
		if id then Le:DeleteNote("Durok", id) end
		Le:SetProbationDays(14); Le:Probation(); Le:SuggestMentor("Neuling")
		local r0 = Recorded("GuildControlSetRank")
		Le:RankRights()
		Le:WelcomeText()
		return (id ~= nil and Recorded("GuildControlSetRank") == r0) and true or false, "Notiz " .. S(id ~= nil), "ja, Recorder 0"
	end)
	Check("T64", "B", "Sammelaktionen", function()
		local Bk = ns.Bulk
		Bk:KickCandidates(30, 3, true); Bk:PromoteCandidates()
		local r0, real0 = Recorded("GuildUninvite"), R.real
		local n0 = #T.members
		-- RV3: Sammelaktion läuft über den sicheren Knopf; im Testmodus führt der Klick nichts aus, nur "[Test]"
		Bk:Start("kick", { "Brann" })
		Bk:Step()
		if ns.GuildAct.frame then ns.GuildAct.PostClick(ns.GuildAct.frame.btn) end
		ns.GuildAct:Cancel()
		Bk:Cancel()
		Bk:GRMLoaded(); Bk:GRMPreview()
		return (Recorded("GuildUninvite") == r0 and R.real == real0 and #T.members == n0 - 1) and true or false, "Mitglieder " .. (n0 - #T.members), "1 entfernt (Test), Recorder 0"
	end)
	Check("T65", "B", "Werbung", function()
		local Rc = ns.Recruit
		local t0 = ns.db.lastAdTime
		local txt = Rc:AdText()
		Rc:EnsureTargets(); Rc:Targets(); Rc:NextTarget(); Rc:GlobalWait()
		Rc:Post()
		return (txt ~= "" and ns.db.lastAdTime == t0) and true or false, "lastAdTime gleich " .. S(ns.db.lastAdTime == t0), "true (N4)"
	end)
	Check("T66", "B", "Bewerber", function()
		local Rc = ns.Recruit
		Rc.OnWhisper("hallo gilde guild", "Wanderer99-Test", nil)
		local a = G().apps.Wanderer99
		Rc:Invite("Wanderer99"); Rc:SetStatus("Wanderer99", "new"); Rc:Remove("Wanderer99")
		return (a ~= nil and G().apps.Wanderer99 == nil) and true or false, "Bewerber " .. S(a ~= nil), "angelegt, entfernt"
	end)
	Check("T68", "B", "Begrüssung", function()
		local Rc = ns.Recruit
		return (Rc:WelcomePreview() ~= "" and Rc:ReplyPreview() ~= "") and true or false, "Vorschau", "nicht leer"
	end)
	Check("T69", "B", "Regeln", function()
		local Ru = ns.Rules
		local v0 = Ru:Current().v or 0
		Ru:Save("Regel 1")
		local v1 = Ru:Current().v or 0
		Ru:Ack(); Ru:Status()
		Ru:ShowPopup(true)
		local f = _G.GuildSentinelRules
		local shown = f and f:IsShown()
		if f then f:Hide() end
		return (v1 == v0 + 1 and Ru:Acked() and shown) and true or false, "v " .. v0 .. "->" .. v1, "+1, bestätigt, Fenster"
	end)
	Check("T70", "B", "Addons-Liste", function()
		local K = ns.Links
		K:Mine()
		local u = K:Usage()
		K:Store("Mira", { RaidMaster = string.rep("9", 30) })
		local v = G().addons.Mira and G().addons.Mira.a.RaidMaster
		return (#u == #K.LIST and v and #v == 20) and true or false, #u .. " Einträge, Länge " .. S(v and #v), #K.LIST .. ", 20"
	end)
	Check("T71", "B", "Abgleich", function()
		local Sy = ns.Sync
		Sy:Digest(); Sy:MemData()
		local r0 = Recorded("SendAddonMessage")
		Sy:Request()
		return Eq(Recorded("SendAddonMessage") - r0, 0)
	end)
	Check("T72", "B", "Meine Woche", function()
		local MW = ns.MyWeek
		MW:Scan(); MW:Chars(); MW:Prep(); MW:PrepText(); MW:PlanText()
		return true
	end)
	Check("T73", "B", "Übersicht", function()
		local i = UI:PageIndex("home")
		UI:Select(i)
		return True(UI:IsPageShown("home"), "home")
	end)
	Check("T74", "B", "jede Option einmal an/aus", function()
		local keys = { "minimapShow", "tooltip", "rulesPopup", "chatMain", "onlineMain", "annLevels", "annFirst", "annJubilee",
			"annMiles", "annReview", "lfgNotify", "lfgSound", "lfgServer", "autoReply", "welcome", "askQuestions", "adRemind", "showOffline", "showAlts" }
		local before = {}
		for _, k in ipairs(keys) do before[k] = ns.db[k] end
		for _, k in ipairs(keys) do ns.db[k] = not before[k]; ns:Fire("GS_SETTINGS") end
		for _, k in ipairs(keys) do ns.db[k] = before[k] end
		if ns.SettingsPage and ns.SettingsPage.Refresh then ns.SettingsPage:Refresh() end
		local same = true
		for _, k in ipairs(keys) do if ns.db[k] ~= before[k] then same = false end end
		return True(same, "Werte wie vorher")
	end)
	Check("T75", "B", "jede Funktion aus/an", function()
		local bad = {}
		for _, f in ipairs(ns.FEATURES) do
			local was = ns.Feature(f.key)
			ns.SetFeature(f.key, false)
			if ns.Feature(f.key) then bad[#bad + 1] = f.key .. " bleibt an" end
			ns.SetFeature(f.key, true)
			if not ns.Feature(f.key) then bad[#bad + 1] = f.key .. " bleibt aus" end
			if not was then ns.SetFeature(f.key, false) end
		end
		return #bad == 0 and #ns.FEATURES == 24, #ns.FEATURES .. " " .. table.concat(bad, ","), "24 OK"
	end)
	-- Kommunikation
	local Comm = ns.Comm
	Check("T76", "B", "Serialize/Deserialize", function()
		local v = { a = "x\t|y~^ü", n = 1.5, t = true, f = false, e = {}, sub = { 1, 2, { z = "q" } } }
		local back = Comm.Deserialize(Comm.Serialize(v))
		local ok = back and back.a == v.a and back.n == 1.5 and back.t == true and back.f == false and type(back.e) == "table" and back.sub[3].z == "q"
		local bad = Comm.Deserialize("{s1^")
		return (ok and bad == nil) and true or false, "Rundweg " .. S(ok), "gleich, kaputt -> nil"
	end)
	Check("T77", "B", "lange Pakete", function()
		local got
		return With({ { Comm.handlers, "GSTESTLONG", function(_, d) got = d end } }, function()
			local payload = "GSTESTLONG\t" .. Comm.Serialize({ x = string.rep("a", 1200) })
			local chunks, n = {}, math.ceil(#payload / 230)
			for i = 1, n do chunks[i] = "~M\tlong1\t" .. i .. "\t" .. n .. "\t" .. payload:sub((i - 1) * 230 + 1, i * 230) end
			for i = n, 1, -1 do Comm.TestOnAddon(Comm.PREFIX, chunks[i], "GUILD", "Mira-Test") end
			local ok1 = got and #got.x == 1200
			got = nil
			Comm.TestOnAddon(Comm.PREFIX, "~M\tlong2\t1\t500\tx", "GUILD", "Mira-Test")
			return (ok1 and got == nil) and true or false, "Zusammenbau " .. S(ok1), "ja, >400 verworfen"
		end)
	end)
	Check("T78", "B", "alle Nachrichtentypen ohne Fehler", function()
		local e0 = ErrMark()
		local n = 0
		for msgType in pairs(Comm.handlers) do
			if msgType ~= "GSTESTLONG" then
				n = n + 1
				Comm.TestDispatch("Mira", msgType .. "\t" .. Comm.Serialize({}), "GUILD")
			end
		end
		return ErrMark() == e0, n .. " Typen, Fehler " .. (ErrMark() - e0), "0 Fehler"
	end)
	Check("T79", "B", "Typen über die Gruppe (auch andere Gilden): nur Gruppensuche", function()
		local hit
		return With({ { Comm.handlers, "THX", function() hit = true end } }, function()
			Comm.TestDispatch("Fremd", "THX\t" .. Comm.Serialize({}), "GROUP")
			return hit == nil, S(hit), "ignoriert"
		end)
	end)
	Check("T80", "B", "Versionen", function()
		return With({ { Comm, "users", { Mira = { v = "0.9.100" } } } }, function()
			local best, newer = Comm:NewestVersion()
			return (best == "0.9.100" and newer) and true or false, S(best), "0.9.100 neuer (Zahlenvergleich)"
		end)
	end)
	Check("T81", "B", "Ansage-Anspruch", function()
		Comm.TestDispatch("Zed", "CLM\t" .. Comm.Serialize({ k = "gstest" }), "GUILD")
		Comm.TestDispatch("Abe", "CLM\t" .. Comm.Serialize({ k = "gstest" }), "GUILD")
		local by = Comm.claims.gstest and Comm.claims.gstest.by
		Comm.claims.gstest = nil
		return Eq(by, "Abe")
	end)
	R:BankCases()
	Check("T190", "B", "Berufe aus der Gilden-Berufsliste des Spiels", function()
		-- Gildenliste über ns.API nachstellen (Testgilde); echte Angaben eines Spielers gehen vor.
		-- Zweiter Beruf zugeklappt: wird aufgeklappt, gelesen und wieder zugeklappt.
		local A = ns.API
		local Ro = ns.Roster
		local a, b = Ro.list[1] and Ro.list[1].name, Ro.list[2] and Ro.list[2].name
		if not (a and b) then return false, "Testgilde leer", "2 Mitglieder" end
		local all = {
			{ h = "GSTestBeruf", id = 901, n = 3 }, { p = a, s = 123, id = 901 }, { p = b, s = 45, id = 901 }, { p = "Niemand-XY", s = 300, id = 901 },
			{ h = "GSTestZwei", id = 902, n = 1, c = true }, { p = a, s = 77, id = 902 },
		}
		local closed = { [902] = true }
		local expanded, collapsed = 0, 0
		local function rows()
			local out = {}
			for _, r in ipairs(all) do
				if r.h or not closed[r.id] then out[#out + 1] = r end
			end
			return out
		end
		local store = ns.guild.prof
		local keepA, keepB = store[a], store[b]
		local keepCounts = ns.Prof.guildCounts
		store[a], store[b] = nil, nil
		local found = With({
			{ A, "GetNumGuildTradeSkill", function() return #rows() end },
			{ A, "GetGuildTradeSkillInfo", function(i)
				local r = rows()[i]
				if not r then return nil end
				if r.h then return r.id, closed[r.id] and true or false, "icon", r.h, 1, 1, r.n end
				return nil, false, nil, nil, 1, 1, 1, r.p, r.p, "MAGE", true, "", r.s
			end },
			{ A, "ExpandGuildTradeSkillHeader", function(id) closed[id] = nil; expanded = expanded + 1 end },
			{ A, "CollapseGuildTradeSkillHeader", function(id) closed[id] = true; collapsed = collapsed + 1 end },
			{ ns.Prof, "GuildUIOpen", function() return false end },
			-- echte Einstellungen nie anfassen; Sperre "höchstens alle 5 Minuten" für den Test aufheben
			{ A, "GetGuildRosterShowOffline", nil }, { A, "SetGuildRosterShowOffline", nil },
			{ ns.Prof, "glExpandLast", nil }, { ns.Prof, "glOfflineLast", nil }, { ns.Prof, "glSelf", nil },
			{ ns.Prof, "glExpands", nil }, { ns.Prof, "guildSkillIDs", {} },
		}, function() return ns.Prof:ReadGuildList() end)
		local ea, eb = store[a], store[b]
		local ok = found == 3 and ea and ea.g and ea.p.GSTestBeruf and ea.p.GSTestBeruf.r == 123 and eb and eb.p.GSTestBeruf.r == 45
			and ea.p.GSTestZwei and ea.p.GSTestZwei.r == 77
			and store["Niemand-XY"] == nil and store.Niemand == nil
			and expanded == 1 and collapsed == 1 and closed[902] == true
		local counts = ns.Prof.guildCounts
		ok = ok and counts and counts.GSTestZwei == 1
		store[a], store[b] = keepA, keepB
		ns.Prof.guildCounts = keepCounts
		return ok and true or false, string.format("gefunden %s, aufgeklappt %d, zugeklappt %d, Zustand %s", S(found), expanded, collapsed,
			closed[902] and "wiederhergestellt" or "offen"), "3 (Nicht-Mitglied übergangen), 1/1, wiederhergestellt"
	end)
	R:ProfSyncCases()
	R:RecipeKindCases()
	R:SyncCases()
	R:AdminCases()
	R:RaidReadyCases()
	R:TUCases()
	Client("T191", "B", "Gilden-Berufsliste im Spiel", "Mit Gilde einloggen, 5 Minuten warten, /gs protokoll: Zeile 'Gilden-Berufsliste: … Zeilen' zeigt, ob das Spiel die Berufe der Mitglieder liefert; Seite Berufe zeigt dann auch Mitglieder ohne GuildSentinel (nur Stufen)")
end

------------------------------------------------------------
-- Bank-Charakter: Bestand an Discord (Bank.lua; anweisung-guildsentinel-gildenbank.txt Punkt 4)
-- Taschen, Bank, Post und Gildenbank werden über ns.API nachgestellt (keine Blizzard-Funktion ersetzt).
------------------------------------------------------------
local LINK_CLOTH = "|cffffffff|Hitem:14047::::::::60:::::|h[Runenstoff]|h|r"
local LINK_POT = "|cffffffff|Hitem:13446::::::::60:::::|h[Erheblicher Heiltrank]|h|r"

-- Ersatz-Taschen: { [bag] = { { link, Anzahl }, … } }
local function FakeBags(bags, modern)
	local A = ns.API
	local list = {
		{ A, "GetItemInfo", function(link) local n = type(link) == "string" and link:match("%[(.-)%]") return n, link, 1 end },
		{ A, "GetMoney", function() return 12345 end },
	}
	local function Num(bag) return bags[bag] and #bags[bag] or 0 end
	if modern then
		list[#list + 1] = { A, "C_GetContainerNumSlots", Num }
		list[#list + 1] = { A, "C_GetContainerItemInfo", function(bag, slot)
			local x = bags[bag] and bags[bag][slot]
			if x then return { hyperlink = x[1], stackCount = x[2], iconFileID = 134 } end
		end }
	else
		-- alter Client (Classic Era/TBC ohne C_Container)
		list[#list + 1] = { A, "C_GetContainerNumSlots", nil }
		list[#list + 1] = { A, "C_GetContainerItemInfo", nil }
		list[#list + 1] = { A, "GetContainerNumSlots", Num }
		list[#list + 1] = { A, "GetContainerItemInfo", function(bag, slot)
			local x = bags[bag] and bags[bag][slot]
			if x then return 134, x[2], false, 1, false, false, x[1] end
		end }
	end
	return list
end

local function Join(a, b) local out = {} for _, x in ipairs(a) do out[#out + 1] = x end for _, x in ipairs(b or {}) do out[#out + 1] = x end return out end

-- Format wie RaidMasterDB.bank: nur diese Schlüssel, c = Summe aller w
local function BankFormatOK(b)
	if type(b) ~= "table" or type(b.c) ~= "string" or type(b.t) ~= "number" or type(b.g) ~= "number" or type(b.i) ~= "table" then return false, "Kopf" end
	for k in pairs(b) do
		if k ~= "c" and k ~= "t" and k ~= "g" and k ~= "gb" and k ~= "src" and k ~= "i" then return false, "Schlüssel " .. tostring(k) end
	end
	for id, e in pairs(b.i) do
		if type(id) ~= "number" or type(e) ~= "table" or type(e.c) ~= "number" or type(e.w) ~= "table" then return false, "Eintrag" end
		local sum = 0
		for where, n in pairs(e.w) do
			if where ~= "bag" and where ~= "bank" and where ~= "mail" and where ~= "guild" then return false, "Ort " .. tostring(where) end
			sum = sum + n
		end
		if sum ~= e.c then return false, "Summe " .. id end
	end
	return true
end

function R:BankCases()
	-- echte Daten (Bestand, Bank-Charakter-Häkchen) danach immer zurück – die Sandbox prüft das am Ende
	local oldBank, oldChars = GuildSentinelDB.bank, ns.db.bankChars
	local ok, err = pcall(R.BankChecks, R)
	GuildSentinelDB.bank, ns.db.bankChars = oldBank, oldChars
	ns.Bank.pending, ns.Bank.running, ns.Bank.bankOpen, ns.Bank.mailTold = {}, nil, false, nil
	if not ok then error(err, 0) end
end

function R:BankChecks()
	local Bk = ns.Bank
	local BAGS = { [0] = { { LINK_CLOTH, 20 }, { LINK_POT, 2 } }, [BANK_CONTAINER or -1] = { { LINK_CLOTH, 40 } } }
	local function Reset() Bk.pending = {}; Bk.running = nil; Bk.bankOpen = false; Bk.mailTold = nil end
	Check("T175", "B", "Bank-Charakter aus: nichts gelesen", function()
		local before = GuildSentinelDB.bank
		ns.db.bankChars = {}
		local r = Bk.Scan("bank", true)
		Reset()
		return (r == false and GuildSentinelDB.bank == before) and true or false, "gelesen " .. S(r), "false, .bank unverändert"
	end)
	Check("T176", "B", "Bank simuliert: Format wie RaidMaster", function()
		ns.db.bankChars = {}
		Bk.SetBankChar(true)
		GuildSentinelDB.bank = nil
		local out = Printed(function() With(FakeBags(BAGS, true), function() Bk.Scan("bank", true) end) end)
		Reset()
		local b = GuildSentinelDB.bank
		local ok, why = BankFormatOK(b)
		local cloth = b and b.i[14047]
		local told = AnyHas(out, (L["Gildenbank-Bestand gelesen: %d verschiedene Items. Er kommt mit dem nächsten Upload in den Discord."]):format(2))
		ok = ok and b.src == "bank" and b.g == 12345 and cloth and cloth.c == 60 and cloth.w.bag == 20 and cloth.w.bank == 40
			and cloth.n == "Runenstoff" and b.c == Me() and told
		return ok and true or false, S(why) .. " Stoff " .. S(cloth and cloth.c), "Format OK, 60 (20+40), Chatzeile"
	end)
	Check("T177", "B", "nur Post gelesen: Bankteil bleibt", function()
		local A = ns.API
		local mail = {
			{ A, "GetInboxNumItems", function() return 1 end },
			{ A, "GetInboxItemLink", function(i, j) if i == 1 and j == 1 then return LINK_CLOTH end end },
			{ A, "GetInboxItem", function() return "x", nil, 134, 3 end },
		}
		With(Join(FakeBags({}, true), mail), function() Bk.Scan("mail", true) end)
		Reset()
		local b = GuildSentinelDB.bank
		local cloth = b and b.i[14047]
		local ok = BankFormatOK(b) and b.src == "mail" and cloth and cloth.w.bank == 40 and cloth.w.bag == 20 and cloth.w.mail == 3 and cloth.c == 63
		return ok and true or false, "Stoff " .. S(cloth and cloth.c), "63 (Bank 40 bleibt)"
	end)
	Check("T178", "B", "im Kampf geöffnet: erst nach dem Kampf", function()
		local t0 = GuildSentinelDB.bank and GuildSentinelDB.bank.t
		GuildSentinelDB.bank.t = 1
		local r, during, after
		With(FakeBags(BAGS, true), function()
			Bk.bankOpen = true
			With({ { ns, "testCombat", true } }, function() r = Bk.Scan("bank") end)
			during = GuildSentinelDB.bank.t
			Bk.RunPending(true)
			after = GuildSentinelDB.bank.t
		end)
		Reset()
		return (r == true and during == 1 and after ~= 1 and GuildSentinelDB.bank.src == "bank") and true or false,
			"im Kampf " .. S(during == 1 and "nicht gelesen" or "gelesen") .. ", danach " .. S(after ~= 1), "nicht gelesen, danach gelesen"
	end)
	Check("T179", "B", "alter Client ohne C_Container", function()
		local e0 = ErrMark()
		With(FakeBags(BAGS, false), function() Bk.Scan("bank", true) end)
		Reset()
		local b = GuildSentinelDB.bank
		local cloth = b and b.i[14047]
		return (ErrMark() == e0 and BankFormatOK(b) and cloth and cloth.c == 63) and true or false, "Stoff " .. S(cloth and cloth.c) .. ", Fehler " .. (ErrMark() - e0), "63 (Post bleibt), 0"
	end)
	Check("T181", "B", "Gildenbank simuliert", function()
		local A = ns.API
		local gb = {
			{ A, "GetNumGuildBankTabs", function() return 2 end },
			{ A, "GetGuildBankItemLink", function(tab, slot) if tab == 2 and slot == 5 then return LINK_POT end end },
			{ A, "GetGuildBankItemInfo", function() return 135, 5 end },
			{ A, "GetGuildBankMoney", function() return 999 end },
		}
		With(Join(FakeBags({}, true), gb), function() Bk.Scan("guild", true) end)
		Reset()
		local b = GuildSentinelDB.bank
		local pot = b and b.i[13446]
		local cloth = b and b.i[14047]
		local ok = BankFormatOK(b) and b.src == "guild" and b.gb == 999 and pot and pot.w.guild == 5 and pot.w.bag == 2 and cloth and cloth.c == 63
		return ok and true or false, "Trank " .. S(pot and pot.c) .. ", Gold " .. S(b and b.gb), "7 (2+5), 999"
	end)
	Client("T180", "B", "Bank-Charakter im Spiel", "Einstellungen > Allgemein: 'Bank-Charakter' anhaken, Bank und Briefkasten öffnen, /reload: Bestand erscheint in #gildenbank (sobald Uploader und Bot aus dem RaidMaster-Auftrag fertig sind)")
end

------------------------------------------------------------
-- C. FOREVER-SONDERFÄLLE (Köderwerte statt geschützter Werte, ns.testCombat statt Kampfsperre)
------------------------------------------------------------
local function FireEvent(ev, ...)
	local f = ns.eventFrame:GetScript("OnEvent")
	f(ns.eventFrame, ev, ...)
end

-- Fälle, die früher eine Blizzard-Funktion ersetzt hätten, laufen jetzt über ns.API (API.lua) – im Spiel ohne Folgen.
-- Offiziersrechte nachstellen: nur Einträge in ns.API (IsInGuild, C_CanEditOfficerNote, CanEditOfficerNote, …)
local function OfficerWith(api)
	local A = ns.API
	local list = {}
	for _, k in ipairs({ "IsInGuild", "C_CanEditOfficerNote", "CanEditOfficerNote", "CanGuildRemove", "CanGuildPromote" }) do
		list[#list + 1] = { A, k, api[k] }
	end
	return With(list, function() return Outside(ns.IsOfficer) end)
end
local function Yes() return true end
local function No() return false end

-- C_GuildInfo.CanEditOfficerNote fehlt bzw. die alten Globals fehlen (T97b, T159)
local function OfficerFallbacks()
	local a = OfficerWith({ IsInGuild = Yes, C_CanEditOfficerNote = Yes })              -- alte Globals fehlen
	local b = OfficerWith({ IsInGuild = Yes, CanEditOfficerNote = Yes })                -- nur alter Weg
	local c = OfficerWith({ IsInGuild = Yes })                                         -- alles fehlt
	return (a == true and b == true and c == false) and true or false, S(a) .. "/" .. S(b) .. "/" .. S(c), "true/true/false"
end

-- nur Offiziersnotizen LESEN (C_GuildInfo.CanViewOfficerNote) ist kein Offizier (T166, T114)
local function ViewOnlyNotOfficer()
	local r = OfficerWith({ IsInGuild = Yes, C_CanEditOfficerNote = No, CanEditOfficerNote = No, CanGuildRemove = No, CanGuildPromote = No })
	-- Paten und Abwesenheit für andere werden dann abgelehnt (ohne ns.IsOfficer-Ersatz, echter Weg über ns.API)
	local A = ns.API
	local g = ns.guild
	local m0, a0 = g.mentor.Lowbie, g.away.Ylva
	With({ { A, "IsInGuild", Yes }, { A, "C_CanEditOfficerNote", No }, { A, "CanEditOfficerNote", No }, { A, "CanGuildRemove", No }, { A, "CanGuildPromote", No } }, function()
		Printed(function()
			Outside(function()
				ns.Social:SetMentor("Lowbie", "Grom")
				ns.Social:SetAway("Ylva", 2, "")
			end)
		end)
	end)
	local kept = g.mentor.Lowbie == m0 and g.away.Ylva == a0
	return (r == false and kept) and true or false, "Offizier " .. S(r) .. ", abgelehnt " .. S(kept), "false, true"
end

-- C_ChatInfo.SendChatMessage fehlt -> altes SendChatMessage; beide fehlen -> kein Fehler (T96b, T161)
local function ChatFallback()
	local A = ns.API
	local old = A.SendChatMessage
	local r0 = Recorded("SendChatMessage")
	ns.actLastFn = nil
	With({ { A, "C_SendChatMessage", nil } }, function() Outside(function() ns.Chat("x", "GUILD") end) end)
	local usedOld = old ~= nil and ns.actLastFn == old
	local r1 = Recorded("SendChatMessage")
	local ok2 = pcall(With, { { A, "C_SendChatMessage", nil }, { A, "SendChatMessage", nil } }, function() Outside(function() ns.Chat("x", "GUILD") end) end)
	local r2 = Recorded("SendChatMessage")
	if not old then
		return (ok2 and r2 == r1) and true or false, "kein altes SendChatMessage, Fehler " .. S(not ok2), "kein Fehler"
	end
	return (usedOld and r1 == r0 + 1 and ok2 and r2 == r1) and true or false, "alt " .. S(usedOld) .. ", ohne beide +" .. (r2 - r1), "alt true, +0"
end

function R:AreaC()
	local So, Rc, Comm = ns.Social, ns.Recruit, ns.Comm
	Check("T83", "C", "Tooltip, geschützter Name", function()
		local e0 = ErrMark()
		local added = 0
		local tip = { AddLine = function() added = added + 1 end, Show = function() end, GetUnit = function() return nil, Bait() end }
		ns.Tooltip:Add(tip, Bait())
		return (ErrMark() == e0 and added == 0) and true or false, "Zeilen " .. added, "0, kein Fehler"
	end)
	Check("T84", "C", "Addon-Nachricht, geschützte Argumente", function()
		local e0 = ErrMark()
		Comm.TestOnAddon(Bait(), "VER\t{}", "GUILD", "Mira-Test")
		Comm.TestOnAddon(Comm.PREFIX, Bait(), "GUILD", "Mira-Test")
		Comm.TestOnAddon(Comm.PREFIX, "VER\t{}", "GUILD", Bait())
		return Eq(ErrMark() - e0, 0)
	end)
	Check("T85", "C", "Flüstern im Kampf (Warteschlange)", function()
		local q0, d0 = Rc.combatQueue, Rc.combatDropped
		Rc.combatQueue, Rc.combatDropped = {}, 0
		local apps0 = Count(ns.guild.apps)
		for i = 1, 31 do FireEvent("CHAT_MSG_WHISPER", Bait(), "Wanderer" .. i .. "-Test", "", "", "", "", 0, 0, "", 0, i, "Player-x") end
		local n, dropped = #Rc.combatQueue, Rc.combatDropped
		local apps1 = Count(ns.guild.apps)
		Rc.combatQueue, Rc.combatDropped = q0, d0
		return (n == 30 and dropped == 1 and apps1 == apps0) and true or false, n .. " gemerkt, " .. dropped .. " gezählt", "30 + 1, keine Bewerbung"
	end)
	Check("T86", "C", "Abklingzeit, geschützte Spell-ID", function()
		local e0 = ErrMark()
		FireEvent("UNIT_SPELLCAST_SUCCEEDED", "player", Bait(), Bait())
		return Eq(ErrMark() - e0, 0)
	end)
	Check("T87", "C", "Gildenchat-Filter, geschützter Autor", function()
		local r = So.ChatFilter(nil, "CHAT_MSG_GUILD", "hi", Bait())
		return Eq(r, false)
	end)
	Check("T88", "C", "Gildenchat-Filter, geschützter Text (N5)", function()
		local r = So.ChatFilter(nil, "CHAT_MSG_GUILD", Bait(), "Gromsham-Test")
		return Eq(r, false)
	end)
	Check("T89", "C", "Systemfilter, geschützter Text (N5)", function()
		local e0 = ErrMark()
		local r = So.SystemFilter(nil, "CHAT_MSG_SYSTEM", Bait())
		FireEvent("CHAT_MSG_SYSTEM", Bait())
		return (r == false and ErrMark() == e0) and true or false, S(r) .. ", Fehler " .. (ErrMark() - e0), "false, 0"
	end)
	Check("T90", "C", "geschützte GUID", function()
		local q0 = Rc.combatQueue
		Rc.combatQueue = {}
		FireEvent("CHAT_MSG_WHISPER", "hallo", "Wanderer77-Test", "", "", "", "", 0, 0, "", 0, 1, Bait())
		local n = #Rc.combatQueue
		Rc.combatQueue = q0
		return Eq(n, 1)
	end)
	Check("T91", "C", "eigener Name geschützt (N6)", function()
		return With({ { ns, "Me", function() return nil end } }, function()
			local ok1 = pcall(ns.SetupGuild, ns)
			local ok2 = pcall(ns.Tooltip.Lines, ns.Tooltip, "Testa")
			return (ok1 and ok2) and true or false, "SetupGuild " .. S(ok1), "kein Fehler"
		end)
	end)
	Check("T92", "C", "fehlendes issecretvalue (ns.API.IsSecret nil)", function()
		return With({ { ns.API, "IsSecret", nil } }, function()
			local a = ns.IsSecret("x")
			local ok1 = pcall(ns.Tooltip.Lines, ns.Tooltip, "Rokwar")
			local ok2 = pcall(So.ChatFilter, nil, "CHAT_MSG_GUILD", "hi", "Gromsham-Test")
			local ok3 = pcall(So.SystemFilter, nil, "CHAT_MSG_SYSTEM", "x")
			local ok4 = pcall(ns.Short, "Testa-Realm")
			return (a == false and ok1 and ok2 and ok3 and ok4) and true or false, S(a) .. " " .. S(ok1 and ok2 and ok3 and ok4), "false, kein Fehler"
		end)
	end)
	Check("T93", "C", "Zaubernamen", function()
		local fn = (C_Spell and C_Spell.GetSpellName) or GetSpellInfo
		return True(fn ~= nil, "Zaubername-API")
	end)
	Check("T93b", "C", "GetSpellInfo nil (über ns.API)", function()
		local A = ns.API
		local modern = A.C_GetSpellName ~= nil
		local ok1, n1 = pcall(With, { { A, "GetSpellInfo", nil } }, function() return ns.SpellName(2259) end)
		local ok2, n2 = pcall(With, { { A, "GetSpellInfo", nil }, { A, "C_GetSpellName", nil } }, function() return ns.SpellName(2259) end)
		local ok = ok1 and ok2 and n2 == nil and (not modern or n1 ~= nil)
		return ok and true or false, "C_Spell " .. S(modern) .. ": " .. S(n1 ~= nil) .. ", beide nil: " .. S(n2), (modern and "Name" or "nil") .. ", nil"
	end)
	Check("T94", "C", "Item aus Taschen", function() return NoErr(ns.FindItemID, "Runenstoff") end)
	Check("T95", "C", "beim Laden gebundene Ersatzwege", function()
		local bad = {}
		local function want(have, modern, old, name) if have ~= (modern or old) then bad[#bad + 1] = name end end
		want(ns.GetItemInfo, C_Item and C_Item.GetItemInfo, GetItemInfo, "GetItemInfo")
		want(ns.RegisterPrefix, C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix, RegisterAddonMessagePrefix, "RegisterPrefix")
		want(ns.GuildRoster, C_GuildInfo and C_GuildInfo.GuildRoster, GuildRoster, "GuildRoster")
		if not ns.SendAddonMessage then bad[#bad + 1] = "SendAddonMessage" end
		return #bad == 0, table.concat(bad, ","), "moderner Weg zuerst"
	end)
	Check("T96", "C", "ns.Chat geht über ns.Act", function()
		local r0 = Recorded("SendChatMessage")
		Outside(function() ns.Chat("x", "GUILD") end)
		return Eq(Recorded("SendChatMessage") - r0, 1)
	end)
	Check("T96b", "C", "SendChatMessage-Rückfall (über ns.API)", ChatFallback)
	Check("T97", "C", "Offiziersrechte (echter Weg)", function()
		return NoErr(function() Outside(ns.IsOfficer) end)
	end)
	Check("T97b", "C", "Offiziers-Globals nil (über ns.API)", OfficerFallbacks)
	Check("T98", "C", "KnowsSpell", function()
		return With({ { ns.Links, "ext", { BuffSentinel = false } } }, function() return NoErr(ns.Links.KnowsSpell, ns.Links, 1) end)
	end)
	Check("T99", "C", "Quest-Global nil (über ns.API)", function()
		local A = ns.API
		local ok1, a = pcall(With, { { A, "IsQuestFlaggedCompleted", nil } }, function() return ns.QuestDone(1) end)
		local ok2, b = pcall(With, { { A, "IsQuestFlaggedCompleted", nil }, { A, "C_IsQuestFlaggedCompleted", nil } }, function() return ns.QuestDone(1) end)
		local ok3 = pcall(With, { { A, "IsQuestFlaggedCompleted", nil } }, function() ns.Attune:Scan(true) end)
		return (ok1 and ok2 and ok3 and type(a) == "boolean" and b == false) and true or false, S(a) .. "/" .. S(b), "true|false / false"
	end)
	Check("T100", "C", "Flüsterfenster über ns.Act", function()
		local r0 = Recorded("ChatFrame_SendTell") + Recorded("ChatFrame_OpenChat")
		Outside(function() ns.OpenWhisper("Testa Beispiel", "x") end)
		return Eq(Recorded("ChatFrame_SendTell") + Recorded("ChatFrame_OpenChat") - r0, 1)
	end)
	Check("T101", "C", "Chatfilter-Haken / alten Kanal verlassen (Testmodus: nur anzeigen)", function()
		return NoErr(function() ns.Group:LeaveChannel(); So:HookChat() end)
	end)
	Check("T102", "C", "Berufs-Weg passt zum Client", function()
		return NoErr(ns.Prof.WindowKind, ns.Prof)
	end)
	Check("T103", "C", "Meine Woche ohne Fehler", function() return NoErr(ns.MyWeek.Scan, ns.MyWeek) end)
	Check("T104", "C", "Addon-Metadaten", function()
		local ok = NoErr(function() ns.Links:Loaded("GibtEsNicht"); ns.Links:Version("GibtEsNicht") end)
		return ok and ns.Links:Loaded("GibtEsNicht") == false, "false", "false ohne Fehler"
	end)
	Check("T105", "C", "Kampfsperre (simuliert)", function()
		local P = ns.ProfPage
		local res
		With({ { ns, "testCombat", true } }, function()
			local added = 0
			local fake = { AddLine = function() added = added + 1 end, Show = function() end,
				GetUnit = function() return "Rokwar", "mouseover" end }
			local wasModern = ns.Game.MODERN
			ns.Game.MODERN = true
			-- OnUnit wird über den echten Haken nicht erreicht; Kampfsperre steht vor jedem Zugriff
			local rulesShown
			local f = _G.GuildSentinelRules
			if f then f:Hide() end
			ns.Rules:ShowPopup(false)
			rulesShown = _G.GuildSentinelRules and _G.GuildSentinelRules:IsShown()
			local started = R:Start("", true)
			ns.Game.MODERN = wasModern
			res = { not rulesShown, started == false }
		end)
		return (res[1] and res[2]) and true or false, "Regeln zu " .. S(res[1]) .. ", Start abgelehnt " .. S(res[2]), "ja"
	end)
	Client("T106", "C", "echte Kampfsperre", "Berufe-Seite offen, Kampf beginnen: kein ADDON_ACTION_BLOCKED für GuildSentinel, nach dem Kampf ist der Knopf wieder da")
	Check("T107", "C", "Kampflog nicht benutzt", function()
		return Eq(ns.eventFrame:IsEventRegistered("COMBAT_LOG_EVENT_UNFILTERED") and true or false, false)
	end)
end

------------------------------------------------------------
-- D. ALTE CLIENTS
------------------------------------------------------------
function R:AreaD()
	local G = GoldSentinelGame
	local old = G.IsEra or G.IsTBC
	if not old then
		for _, id in ipairs({ "T108", "T109", "T110", "T111", "T112", "T114" }) do Skip(id, "D", "alter Client", "nicht dieser Client") end
		Skip("T113", "D", "Berufe klassisch", "nicht dieser Client")
		return
	end
	Skip("T108", "D", "Bereich B auf altem Weg", "siehe Bereich B in diesem Bericht (läuft ohne Simulation)")
	Check("T109", "D", "Namen alt", function()
		local p = ns.Proper("aRTHAS-Realm")
		return (p == "Arthas" and ns.Same("Testa", "Testa Beispiel") == false) and true or false, S(p), "Arthas"
	end)
	Check("T110", "D", "Flüstern alt", function()
		local r0 = Recorded("ChatFrame_OpenChat")
		Outside(function() ns.OpenWhisper("Brakko", "Hallo!") end)
		return Eq(Recorded("ChatFrame_OpenChat") - r0, 1)
	end)
	Check("T111", "D", "Tooltip alt", function()
		local want = TooltipDataProcessor and "tdp" or "script"
		return Eq(ns.Tooltip.hookWay, want)
	end)
	Check("T112", "D", "Inhalte", function()
		local Game = ns.Game
		if G.IsTBC then
			return (Game.MAX_LEVEL == 70 and Game.RAID_SIZE == 25) and true or false, Game.MAX_LEVEL .. "/" .. Game.RAID_SIZE, "70/25"
		end
		return (Game.MAX_LEVEL == 60 and Game.RAID_SIZE == 40 and #ns.Cooldowns.LIST == 3) and true or false,
			Game.MAX_LEVEL .. "/" .. Game.RAID_SIZE .. "/" .. #ns.Cooldowns.LIST, "60/40/3"
	end)
	Client("T113", "D", "Berufe klassisch", "TradeSkillFrame (Era: auch Verzauberkunst über CraftFrame) öffnen: Seite Berufe gefüllt, Diagnose 'klassisch'")
	Check("T114", "D", "Offizier alt (Regression K1)", ViewOnlyNotOfficer)
end

------------------------------------------------------------
-- E. DATEN
------------------------------------------------------------
function R:AreaE()
	Check("T116", "E", "neue Gilde", function()
		local g = {}
		ns.MergeDefaults(g, ns.guildDefaults)
		local bad = {}
		for k in pairs(ns.guildDefaults) do if type(g[k]) ~= "table" then bad[#bad + 1] = k end end
		local r = g.rules
		if not (r.v and r.t and r.text and r.by) then bad[#bad + 1] = "rules" end
		return #bad == 0, Count(g) .. " Schlüssel " .. table.concat(bad, ","), "alle Tabellen"
	end)
	Check("T118", "E", "beschädigte Gildendaten", function()
		local g = ns.guild
		g.alts.Xbad = 5; g.away.Ybad = "x"; g.thanks.zbad = { from = nil }; g.events.bad = { t = "abc" }
		g.roster.Zbad = true; g.prof.Wbad = { p = 7 }; g.cds.Vbad = { k = "x" }; g.levels.Ubad = false
		g.polls.pbad = { o = nil }; g.market.mbad = { i = "x" }; g.mentor.Mbad = 1
		local ok0, n, errs = pcall(OpenAllPages)
		local ok1, m, errs2 = pcall(OpenAllTabs)
		local e0 = ErrMark()
		ns:Fire("GS_EVENTS"); ns:Fire("GS_POLL"); ns:Fire("GS_SOCIAL"); ns:Fire("GS_ROSTER"); ns:Fire("GS_BOARD")
		local fired = ErrMark() - e0
		if not ok0 then errs = { tostring(n) } end
		if not ok1 then errs2 = { tostring(m) } end
		for _, k in ipairs({ "alts", "away", "thanks", "roster", "prof", "cds", "levels", "polls", "market", "mentor" }) do
			for key in pairs(g[k]) do if type(key) == "string" and key:find("bad$") then g[k][key] = nil end end
		end
		g.events.bad = nil
		local all = {}
		for _, e in ipairs(errs) do all[#all + 1] = e end
		for _, e in ipairs(errs2) do all[#all + 1] = e end
		for i = 1, math.min(fired, 3) do all[#all + 1] = ns.errors.last[i].wo .. ": " .. ns.errors.last[i].msg end
		return #all == 0, table.concat(all, "; "), "0 Fehler"
	end)
	Check("T120", "E", "beschädigte Pakete", function()
		local Comm = ns.Comm
		local e0 = ErrMark()
		for msgType in pairs(Comm.handlers) do
			for _, d in ipairs({ { e = 5, n = {}, id = 7, t = "x", k = 1 }, { e = { x = 5 }, o = "x", v = {} } }) do
				Comm.TestDispatch("Mira", msgType .. "\t" .. Comm.Serialize(d), "GUILD")
			end
		end
		local list = {}
		for i = 1, math.min(ErrMark() - e0, 10) do list[#list + 1] = ns.errors.last[i].wo .. ": " .. ns.errors.last[i].msg end
		return ErrMark() == e0, (ErrMark() - e0) .. " " .. table.concat(list, " | "), "0"
	end)
	Check("T121", "E", "Grenzen", function()
		for i = 1, 450 do ns.Roster:Log("join", "Testlog" .. i) end
		local n = #ns.guild.log
		ns.Social:SetAway(nil, 1, string.rep("x", 120))
		local note = ns.guild.away[ns.Me()] and ns.guild.away[ns.Me()].note
		ns.Social:SetAway(nil, 0, "")
		return (n <= 400 and note and #note <= 80) and true or false, n .. " Log, Notiz " .. S(note and #note), "<=400, <=80"
	end)
	Skip("T115", "E", "Neuinstallation", "würde GuildSentinelDB neu anlegen; offline: jeder Lauf in test/ startet ohne GuildSentinelDB")
	Skip("T117", "E", "Migration", "offline in test/run_nilglobals.lua (Altlasten) und run_lang.lua (alte Spracheinstellung)")
	Skip("T119", "E", "beschädigte Einstellungen", "offline in test/run_nilglobals.lua")
end

------------------------------------------------------------
-- F. SPRACHEN
------------------------------------------------------------
local function Specs(s)
	local out = {}
	for x in tostring(s):gmatch("%%[-+#0-9.]*[sdifxXc%%]") do out[#out + 1] = x end
	return table.concat(out, " ")
end

function R:AreaF()
	local MAP = { deDE = "de", enUS = "en", enGB = "en" }
	local loc = GetLocale()
	Check("T122", "F", "Sprache wie Client (bzw. gewählt)", function()
		local chosen = ns.db.uiLang
		if chosen and ns.LangAvailable(chosen) then return Eq(ns.lang, chosen) end
		return Eq(ns.lang, MAP[loc] or loc)
	end)
	local tl = ns.T and ns.T[ns.lang]
	if ns.lang ~= "de" and ns.lang ~= "en" and tl then
		Check("T123", "F", "alle Schlüssel vorhanden", function()
			local miss = 0
			for k in pairs(ns.EN) do if not tl[k] then miss = miss + 1 end end
			return Eq(miss, 0)
		end)
	else
		Skip("T123", "F", "alle Schlüssel vorhanden", "Client-Sprache ist " .. S(ns.lang) .. " (Schlüssel bzw. Locales.lua)")
	end
	Check("T124", "F", "Formatplatzhalter", function()
		local bad = 0
		local first
		for k, v in pairs(ns.EN) do
			if not k:find("%%[dmYHM]") or k:find("%%d") then
				if Specs(k) ~= Specs(v) and not k:find("%%[mYHM]") then bad = bad + 1; first = first or k:sub(1, 40) end
			end
			if tl and tl[k] and Specs(tl[k]) ~= Specs(k) and not k:find("%%[mYHM]") then bad = bad + 1; first = first or k:sub(1, 40) end
		end
		return bad == 0, bad .. " " .. S(first), "0 Abweichungen"
	end)
	Check("T125", "F", "Sprache umschalten", function()
		local was = ns.lang
		local errs = {}
		for _, l in ipairs({ "de", "en", was }) do
			ns.lang = l
			local _, e = OpenAllPages()
			for _, x in ipairs(e) do errs[#errs + 1] = l .. ":" .. x end
		end
		ns.ApplyLang()
		return #errs == 0, table.concat(errs, "; "), "ohne Fehler"
	end)
	Check("T126", "F", "Merk-Schlüssel (N[...])", function()
		local miss = {}
		local function need(k) if k and not ns.EN[k] then miss[#miss + 1] = k end end
		for _, f in ipairs(ns.FEATURES) do need(f.n); need(f.d) end
		for _, e in ipairs(ns.Test.EVENTS) do need(e.n) end
		for _, s in ipairs(ns.Board.SERVICES or {}) do need(s.n) end
		for _, c in ipairs(ns.Cooldowns.LIST or {}) do need(c.n) end
		return #miss == 0, table.concat(miss, ", "), "alle in Locales.lua"
	end)
	-- seit 0.9.13 sind die Sprachen mit lateinischer Schrift immer geladen (wählbar), die übrigen nur für ihren Client
	Check("T127", "F", "übrige geladene Sprachen vollständig", function()
		local bad = {}
		for l, t in pairs(ns.T or {}) do
			local miss = 0
			for k in pairs(ns.EN) do if not t[k] then miss = miss + 1 end end
			if miss > 0 then bad[#bad + 1] = l .. " " .. miss end
		end
		local n = 0
		for _ in pairs(ns.T or {}) do n = n + 1 end
		return #bad == 0, n .. " Sprachen, fehlend: " .. (#bad > 0 and table.concat(bad, ", ") or "0"), "0 fehlend"
	end)
end

------------------------------------------------------------
-- G. ZUSAMMENSPIEL
------------------------------------------------------------
function R:AreaG()
	local K = ns.Links
	Check("T128", "G", "mehrere GoldSentinel-Addons", function()
		local list = {}
		for _, a in ipairs(K.LIST) do
			local v = K:Version(a.key)
			if v then list[#list + 1] = a.key .. " " .. v end
		end
		return ((tonumber(GoldSentinelGame.version) or 0) >= 2 and GoldSentinelDev.version == 1 and GoldSentinelTest) and true or false,
			#list > 0 and table.concat(list, ", ") or "keine weiteren", "Versionen >=2/1"
	end)
	Check("T129", "G", "keine globalen Namen überschrieben", function()
		local ok = type(SlashCmdList.GUILDSENTINEL) == "function" and SLASH_GUILDSENTINEL1 == "/gs"
		return True(ok, "/gs")
	end)
	Check("T130", "G", "RaidMaster da / nicht da", function()
		local act = ns.RMI:Active()
		return Eq(act, false)  -- im Testmodus nie aktiv
	end)
	Check("T131", "G", "AH-Preise", function()
		local fake = { GetMarketValue = function() return 12345 end }
		local bad = { GetMarketValue = function() error("x") end }
		local a = With({ { K, "ext", { AHAnalyzerPro = fake } } }, function() return K:MarketValue(14047) end)
		local b = With({ { K, "ext", { AHAnalyzerPro = bad } } }, function() return K:MarketValue(14047) end)
		local c = With({ { K, "ext", { AHAnalyzerPro = false } } }, function() return K:MarketValue(14047) end)
		return (a == 12345 and b == nil and c == nil) and true or false, S(a) .. "," .. S(b) .. "," .. S(c), "12345,nil,nil"
	end)
	Check("T132", "G", "AH-Addon unter Ordner AHSentinel erkannt (N7)", function()
		local a = With({ { K, "ext", { loaded = { AHSentinel = true } } } }, function() return K:Loaded("AHAnalyzerPro") end)
		local b = With({ { K, "ext", { loaded = { AHAnalyzerPro = true } } } }, function() return K:Loaded("AHAnalyzerPro") end)
		return (a and b) and true or false, S(a) .. "," .. S(b), "true,true"
	end)
	Check("T133", "G", "BuffSentinel", function()
		local a = With({ { K, "ext", { BuffSentinel = { KnowsSpellID = function() return true end } } } }, function() return K:KnowsSpell(1) end)
		local b = With({ { K, "ext", { BuffSentinel = { KnowsSpellID = function() error("x") end } } } }, function() return K:KnowsSpell(1) end)
		return (a == true and type(b) == "boolean") and true or false, S(a) .. "," .. S(b), "true, Rückfall"
	end)
	Check("T134", "G", "ThreatSentinel", function()
		local key = (UnitName("player") or "?") .. " - " .. (GetRealmName and GetRealmName() or "?")
		local db = { profiles = { [key] = { myRole = "HEALER" } } }
		local a = With({ { K, "ext", { ThreatSentinelDB = db, loaded = { ThreatSentinel = true } } } }, function() return K:ThreatRole() end)
		local b = With({ { K, "ext", { ThreatSentinelDB = false, loaded = { ThreatSentinel = false } } } }, function() return K:ThreatRole() end)
		return (a == "heal" and b == nil) and true or false, S(a) .. "," .. S(b), "heal,nil"
	end)
	Check("T135", "G", "LevelPilot", function()
		local lp = { Social = { MyEliteQuests = function() return { 123 } end } }
		local a = With({ { K, "ext", { LevelPilot = lp } } }, function() return K:EliteQuests() end)
		local b = With({ { K, "ext", { LevelPilot = false } } }, function() return K:EliteQuests() end)
		return (#a == 1 and #b == 0) and true or false, #a .. "," .. #b, "1,0"
	end)
	Client("T136", "G", "Guild Roster Manager", "mit installiertem GRM: Leitung > GRM-Import zeigt Zahlen; ohne: kein Fehler")
	Skip("T137", "G", "ProfessionSentinel", "GuildSentinel nutzt keine Schnittstelle von ProfessionSentinel")
end

------------------------------------------------------------
-- H. LEISTUNG
------------------------------------------------------------
local function Time(fn, n)
	n = n or 1
	local t = Ms()
	for _ = 1, n do fn() end
	return (Ms() - t) / n
end

function R:AreaH()
	local T = ns.Test
	Check("T138", "H", "Roster:Scan mit 500 Mitgliedern", function()
		local add = {}
		for i = 1, 500 - #T.members do
			local m = { name = "Perf" .. i, class = "MAGE", level = 30, ri = 4, zone = "", online = false, off = 86400, note = (i % 3 == 0) and "Twink von Testa" or "" }
			T.members[#T.members + 1] = m
			add[#add + 1] = m
		end
		local ms = Time(function() ns.Roster:Scan() end)
		R.big = true
		return ms < 16, string.format("%.1f ms", ms), "< 16 ms"
	end)
	Check("T139", "H", "Tooltip", function()
		local ms = Time(function() ns.Tooltip:Lines("Rokwar") end, 50)
		return ms < 2, string.format("%.2f ms", ms), "< 2 ms"
	end)
	Check("T140", "H", "Chatfilter", function()
		local ms = Time(function() ns.Social.ChatFilter(nil, "CHAT_MSG_GUILD", "hi", "Gromsham-Test"); ns.Social.SystemFilter(nil, "CHAT_MSG_SYSTEM", "x") end, 200)
		return ms < 2, string.format("%.3f ms", ms), "< 2 ms"
	end)
	Check("T141", "H", "Pakete", function()
		local v = { x = string.rep("a", 2000) }
		local ms = Time(function() ns.Comm.Deserialize(ns.Comm.Serialize(v)) end, 10)
		return ms < 2, string.format("%.2f ms", ms), "< 2 ms"
	end)
	Check("T142", "H", "Ticker-Arbeit", function()
		local ms = 0
		for _, fn in ipairs({ function() ns.Events:CheckReminders() end, function() ns.Activity:Sample() end,
			function() ns.Lead:SampleHours() end, function() ns.Recruit:Due() end, function() ns.Jubilee:Check() end }) do
			local t = Time(fn)
			if t > ms then ms = t end
		end
		return ms < 2, string.format("%.2f ms (höchster)", ms), "< 2 ms"
	end)
	Check("T143", "H", "Seiten mit 500 Mitgliedern", function()
		local worst, which = 0, "-"
		for _, p in ipairs(Pages()) do
			if ns.UI:PageOn(p.page) then
				local t = Time(function() ns.UI:Select(p.i) end)
				if t > worst then worst, which = t, p.key end
			end
		end
		return worst < 16, string.format("%.1f ms (langsamste: %s)", worst, which), "< 16 ms"
	end)
	Check("T144", "H", "Abgleich", function()
		local ms = Time(function() ns.Sync:Digest() end)
		return ms < 16, string.format("%.1f ms", ms), "< 16 ms"
	end)
	-- Testgilde wieder auf normale Grösse
	local keep = {}
	for _, m in ipairs(T.members) do if not tostring(m.name):find("^Perf%d") then keep[#keep + 1] = m end end
	T.members = keep
	ns.Roster:Scan()
	Skip("T145", "H", "Speicher", "Messung im Bericht unten (collectgarbage vor/nach)")
end

------------------------------------------------------------
-- I. FEHLERZÄHLUNG UND DIAGNOSE
------------------------------------------------------------
local function DropSelfTestErrors()
	local s = GuildSentinelDB and GuildSentinelDB.gsTest
	if s and type(s.errors) == "table" then
		for k, e in pairs(s.errors) do
			if type(e) == "table" and tostring(e.msg):find("GS-Selbsttest", 1, true) then s.errors[k] = nil end
		end
	end
end

function R:AreaI()
	Check("T146", "I", "Fehler in internem Ereignis", function()
		local e0 = ErrMark()
		-- nur einmal je Sitzung anmelden (sonst zählt ein zweiter Lauf jeden Fehler doppelt)
		if not R.selfListen then
			R.selfListen = true
			ns:Listen("GS_SELFTEST_ERR", function() if R.selfErr then error("GS-Selbsttest") end end)
		end
		R.selfErr = true
		ns:Fire("GS_SELFTEST_ERR")
		R.selfErr = false
		local last = ns.errors.last[1]
		local s = GuildSentinelDB.gsTest
		local inGT = false
		for _, e in pairs(s and s.errors or {}) do if type(e) == "table" and e.wo == "GS_SELFTEST_ERR" then inGT = true end end
		DropSelfTestErrors()
		return (ErrMark() == e0 + 1 and last and last.msg:find("GS-Selbsttest", 1, true) and inGT) and true or false,
			"+" .. (ErrMark() - e0) .. " GT " .. S(inGT), "+1, gemeldet"
	end)
	Check("T147", "I", "Fehler in Spiel-Ereignis und Paket", function()
		local e0 = ErrMark()
		if not R.selfOn then
			R.selfOn = true
			ns:On("GS_SELFTEST_EVT", function() if R.selfErr then error("GS-Selbsttest") end end)
		end
		R.selfErr = true
		FireEvent("GS_SELFTEST_EVT")
		With({ { ns.Comm.handlers, "GSSELF", function() error("GS-Selbsttest") end } }, function()
			ns.Comm.TestDispatch("Mira", "GSSELF\t{}", "GUILD")
		end)
		R.selfErr = false
		DropSelfTestErrors()
		return Eq(ErrMark() - e0, 2)
	end)
	Check("T148", "I", "Diagnose zeigt Fehler", function()
		local txt = ns.SettingsPage and ns.SettingsPage:DiagText() or ""
		return (txt:find(string.format(L["Fehler: %d"], ns.errors.n), 1, true) and txt:find(GoldSentinelGame.Status(), 1, true)) and true or false, "Diagnose", "mit Status und Fehlerzahl"
	end)
	Check("T174", "I", "Aktionen mit Folgen nur über ns.Act", function()
		-- jede Aktion mit Folgen ausserhalb des Testmodus auslösen: ns.Act muss sie mitschreiben, echt geht nichts hinaus
		-- (echte Aufrufe zählt hooksecurefunc; ein direkter Aufruf an ns.Act vorbei wäre hier ein FEHLER)
		local real0 = R.real
		local list = {
			{ "SendChatMessage", function() ns.Chat("x", "GUILD") end },
			{ "InviteUnit", function() ns.InviteParty("Testa") end },
			{ "ChatFrame_OpenChat", function() ns.OpenWhisper("Testa", "x") end },
			{ "ChatFrame_OpenChat", function() ns.Recruit:Invite("Wanderer98") end },
		}
		local missing = {}
		With({ { ns, "CanInvite", Yes }, { ns, "CanPromote", Yes } }, function()
			for _, x in ipairs(list) do
				local r0 = Recorded(x[1])
				Outside(x[2])
				if Recorded(x[1]) ~= r0 + 1 then missing[#missing + 1] = x[1] end
			end
		end)
		local g = ns.guild
		if g and g.apps then g.apps.Wanderer98 = nil end
		local by = {}
		for k, v in pairs(R.realBy) do by[#by + 1] = k .. " " .. v end
		return (#missing == 0 and R.real == real0) and true or false,
			"nicht über ns.Act: " .. (#missing > 0 and table.concat(missing, ",") or "-") .. ", echt " .. (R.real - real0) .. (#by > 0 and (" (" .. table.concat(by, ", ") .. ")") or ""), "alle über ns.Act, echt 0"
	end)
	Check("T188", "I", "Diagnose-Protokoll: Einträge, Zähler, Export GSDIAG1, keine Namen", function()
		if not (ns.Diag and ns.DiagText and ns.DiagExport) then return false, "Diag.lua fehlt", "ns.Diag/DiagText/DiagExport" end
		local box = { entries = {}, sessions = {} }
		return With({ { ns, "diagForce", true }, { GuildSentinelDB, "diag", box } }, function()
			ns.Diag("KLICK", "Testeintrag", 12.4)
			for _ = 1, 50 do ns.Diag("FEHLER", "gleicher Fehler") end
			ns.Diag("FEHLER", "Fehler von " .. tostring(Me()))
			ns.CountError("T188", "GS-Selbsttest " .. tostring(Me()))
			local text, exp = ns.DiagText(), ns.DiagExport()
			local loopOk = box.entries[3] and box.entries[3].n == 50
			local me = Me()
			local noName = type(me) ~= "string" or me == "" or not text:find(me, 1, true)
			local prefix = exp:sub(1, 21) == "GSDIAG1|GuildSentinel"
			local ok = #box.entries == 4 and loopOk and noName and prefix
			return ok and true or false, string.format("%d Einträge, Zähler %s, Name %s, Export %s", #box.entries,
				S(box.entries[3] and box.entries[3].n), noName and "nicht drin" or "DRIN", S(prefix)), "4 Einträge, Zähler 50, kein Name, GSDIAG1"
		end)
	end)
	Client("T189", "I", "Diagnose-Protokoll im Spiel", "/gs protokoll öffnet ein Fenster mit markierbarem Text; nach /reload liegt GuildSentinelDB.diagExport (beginnt mit GSDIAG1) in den SavedVariables und geht mit dem Uploader nach #testberichte")
	Check("T149", "I", "Fehler-Abgriff aktiv", function()
		local ok = GoldSentinelTest.registry.GuildSentinel ~= nil and (_G.GoldSentinelTestHooked == true or _G.GoldSentinelTestBG ~= nil)
		return True(ok, "registriert")
	end)
end

------------------------------------------------------------
-- J. REGRESSIONSTESTS
------------------------------------------------------------
local function MiniRoster(names, fn)
	local list, by = {}, {}
	for _, n in ipairs(names) do local e = { name = n, class = "MAGE", level = 60, ri = 3, note = "" }; list[#list + 1] = e; by[n] = e end
	return With({ { ns.Roster, "list", list }, { ns.Roster, "byName", by } }, fn)
end

------------------------------------------------------------
-- Berufe-Abgleich und vollautomatische Berufe (0.9.19): T201–T207 = T-S1–T-S7, T208–T212 = T-B1–T-B5
-- Alles in einer Ersatz-Tabelle (G.prof, Gildenliste, Senden abgefangen); Platzhalter-Namen, keine echten Spieler
------------------------------------------------------------
function R:ProfSyncCases()
	local P, A = ns.Prof, ns.API
	-- gemeinsame Hülle: leerer Berufe-Speicher, Testgilde mit zwei Namen, Senden wird nur mitgeschrieben
	local function Box(store, fn, extra)
		local sent = {}
		local list = {
			{ ns.guild or {}, "prof", store }, { ns.guild or {}, "profSent", nil }, { ns.guild or {}, "profSentT", nil },
			{ ns.guild or {}, "probeOff", nil }, { ns.guild or {}, "grDay", nil }, { ns.guild or {}, "grBlocked", nil },
			{ ns.Comm, "Send", function(_, typ, d, ch, to) sent[#sent + 1] = { typ = typ, d = d, ch = ch, to = to } end },
			{ ns.RMI, "Profs", function() return nil end },
			{ ns, "InGuild", function() return true end },
			{ P, "ScheduleSend", function() sent.scheduled = (sent.scheduled or 0) + 1 end },
			{ P, "guildCounts", nil }, { P, "guildView", nil }, { P, "rx", { n = 0, a = 0, o = 0, u = 0 } }, { P, "rxPending", true },
		}
		for _, x in ipairs(extra or {}) do list[#list + 1] = x end
		return MiniRoster({ "Testa Beispiel", "Mira Sonnenkind", Me() }, function()
			return With(list, function() return fn(sent) end)
		end)
	end
	local function Entry(t, prof, names, spells, g)
		return { t = t, c = "MAGE", g = g, p = { [prof] = { r = 150, m = 300, n = names or {}, i = {}, s = spells or {} } } }
	end

	Check("T201", "B", "T-S1: RaidMaster aktiv – eigene Berufe werden trotzdem gesendet", function()
		if not ns.guild then return false, "keine Gilde", "Gilde" end
		local store = {}
		return Box(store, function(sent)
			store[P.MyKey()] = Entry(ns.Now(), "GSTestBeruf", { "GSTestRezept" })
			local ok = P:SendMine()
			local m = sent[1]
			local good = ok and m and m.typ == "PROF" and m.ch == "GUILD" and m.d.n == P.MyKey()
			return good and true or false, string.format("gesendet %s, Typ %s, Grund %s", S(ok), S(m and m.typ), S(P.lastSent and P.lastSent.why)),
				"gesendet true, PROF an GUILD"
		end, { { ns.RMI, "Active", function() return true end } })
	end)

	Check("T202", "B", "T-S2: Empfang in anderer Schreibweise und Migration doppelter Einträge", function()
		if not ns.guild then return false, "keine Gilde", "Gilde" end
		Flavor("forever")
		local store = {}
		local r = Box(store, function()
			P:Receive("testa beispiel-WoWForever", { n = "testa beispiel-WoWForever", t = 100, p = { GSTestBeruf = { r = 150, n = { "GSTestRezept" } } } })
			local direct = store["Testa Beispiel"] ~= nil and store["testa beispiel"] == nil
			local shown = false
			for _, x in ipairs(P:Overview().GSTestBeruf or {}) do if x.name == "Testa Beispiel" then shown = true end end
			-- Migration: alter Eintrag in Kleinschreibung + Eintrag aus der Gilden-Berufsliste -> einer, neueres t gewinnt
			store["mira sonnenkind"] = Entry(50, "GSTestBeruf", { "GSTestRezept" })
			store["Mira Sonnenkind"] = { t = 0, g = true, p = { GSTestSammeln = { r = 100 } } }
			local moved = P:Rekey()
			local m = store["Mira Sonnenkind"]
			local merged = moved == 1 and store["mira sonnenkind"] == nil and m and not m.g and m.t == 50
				and m.p.GSTestBeruf and m.p.GSTestSammeln and m.p.GSTestSammeln.r == 100
			return { direct = direct, shown = shown, merged = merged and true or false }
		end)
		Flavor(nil)
		return (r.direct and r.shown and r.merged) and true or false,
			string.format("gespeichert %s, angezeigt %s, zusammengeführt %s", S(r.direct), S(r.shown), S(r.merged)), "true, true, true"
	end)

	Check("T203", "B", "T-S3: Mitglied C sendet nach dem Einloggen selbst, Anfragender hat C", function()
		if not ns.guild then return false, "keine Gilde", "Gilde" end
		local store = {}
		return Box(store, function(sent)
			-- als C: eigener Eintrag neuer als das letzte Senden -> SendLogin schickt ohne Abgleich
			store[P.MyKey()] = Entry(ns.Now(), "GSTestBeruf", { "GSTestRezept" })
			ns.guild.profSentT = 0
			ns.guild.profSent = ns.Now()            -- heute schon einmal gesendet: trotzdem, weil neu
			local ok = P:SendLogin()
			local m = sent[1]
			-- unverändert und < 24 h: nicht noch einmal
			local again = P:SendLogin()
			-- als Anfragender (ohne Daten von C): das Paket von C kommt an
			local got = false
			if m then
				local d = { n = "Testa Beispiel", c = m.d.c, t = m.d.t, p = m.d.p }
				store[P.MyKey()] = nil
				P:Receive("Testa Beispiel", d)
				got = store["Testa Beispiel"] ~= nil
			end
			return (ok and m ~= nil and not again and got) and true or false,
				string.format("gesendet %s, zweites Mal %s, angekommen %s", S(ok), S(again), S(got)), "true, false, true"
		end)
	end)

	Check("T204", "B", "T-S4: Protokoll-Zeilen ohne Spielernamen", function()
		if not (ns.guild and ns.Diag) then return false, "keine Gilde/Diag", "Gilde" end
		local box = { entries = {}, sessions = {} }
		local store = {}
		return Box(store, function()
			P:Receive("Testa Beispiel", { n = "Testa Beispiel", t = 10, p = { GSTestBeruf = { r = 1, n = { "GSTestRezept" } } } })
			P:Receive("Fremder Unbekannt", { n = "Fremder Unbekannt", t = 10, p = { GSTestBeruf = { r = 1 } } })
			P:RxFlush()
			store[P.MyKey()] = Entry(ns.Now(), "GSTestBeruf", { "GSTestRezept" })
			P:SendMine()
			P:Overview(); P.viewTold = nil; P:TellView()
			local lines, bad = {}, nil
			for _, e in ipairs(box.entries) do
				lines[#lines + 1] = e.t
				for _, nm in ipairs({ "Testa", "Mira", "Fremder", Me() }) do
					if type(nm) == "string" and nm ~= "" and tostring(e.t):find(nm, 1, true) then bad = nm end
				end
			end
			local txt = table.concat(lines, " | ")
			local has = txt:find("empfangen: 2 Einträge, angenommen 2", 1, true) and txt:find("Name unbekannt 1", 1, true)
				and txt:find("gesendet: eigene=ja", 1, true) and txt:find("Anzeige:", 1, true)
			return (has and not bad) and true or false, bad and ("Name im Protokoll") or txt:sub(1, 200), "empfangen/gesendet/Anzeige, keine Namen"
		end, { { ns, "diagForce", true }, { GuildSentinelDB, "diag", box }, { P, "viewTold", nil } })
	end)

	Check("T205", "B", "T-S5: Offline-Mitglieder erst nach dem Warten gelesen, Anzeige danach zurückgesetzt", function()
		if not ns.guild then return false, "keine Gilde", "Gilde" end
		-- das Spiel liefert die Offline-Zeile erst nach einer Antwort des Servers (ready)
		local showOff, sets, ready = false, 0, false
		local all = { { h = "GSTestBeruf", id = 903, n = 2 }, { p = "Testa Beispiel", s = 100 }, { p = "Mira Sonnenkind", s = 80, off = true } }
		local function rows()
			local out = {}
			for _, r in ipairs(all) do if not r.off or (showOff and ready) then out[#out + 1] = r end end
			return out
		end
		local store = {}
		return Box(store, function()
			local first = P:ReadGuildList()
			local stillOn = showOff == true          -- noch eingeblendet, wartet auf das Spiel
			ready = true
			local found = P:ReadGuildList(true)      -- so ruft es der Zeitgeber bzw. GUILD_TRADESKILL_UPDATE auf
			local mira = store["Mira Sonnenkind"]
			return (first == 1 and stillOn and found == 2 and mira and mira.g and showOff == false and sets == 2 and P.glToken == nil) and true or false,
				string.format("zuerst %s, wartet %s, danach %s, offline %s, Anzeige danach %s, umgeschaltet %d", S(first), S(stillOn), S(found),
					mira and "gelesen" or "fehlt", S(showOff), sets),
				"1, true, 2, gelesen, false, 2"
		end, {
			{ A, "GetNumGuildTradeSkill", function() return #rows() end },
			{ A, "GetGuildTradeSkillInfo", function(i)
				local r = rows()[i]
				if not r then return nil end
				if r.h then return r.id, false, "icon", r.h, 1, 1, r.n end
				return nil, false, nil, nil, 1, 1, 1, r.p, r.p, "MAGE", true, "", r.s
			end },
			{ A, "GetGuildRosterShowOffline", function() return showOff end },
			{ A, "SetGuildRosterShowOffline", function(v) showOff = v and true or false; sets = sets + 1 end },
			{ A, "ExpandGuildTradeSkillHeader", nil },
			{ P, "GuildUIOpen", function() return false end },
			{ P, "glExpandLast", nil }, { P, "glOfflineLast", nil }, { P, "glSelf", nil }, { P, "glOpened", nil }, { P, "glOffline", nil },
			{ P, "glToken", nil }, { P, "glBefore", nil }, { P, "guildSkillIDs", {} },
		})
	end)

	Check("T206", "B", "T-S6: NEW_RECIPE_LEARNED – Rezept sofort im eigenen Eintrag, Senden geplant", function()
		if not ns.guild then return false, "keine Gilde", "Gilde" end
		local store = {}
		return Box(store, function(sent)
			store[P.MyKey()] = Entry(1, "GSTestBeruf", { "GSTestAlt" }, { 990001 })
			local ok = P:LearnRecipe(990002)
			local v = store[P.MyKey()].p.GSTestBeruf
			local twice = P:LearnRecipe(990002)
			local good = ok and v and #v.n == 2 and v.n[2] == "GSTestNeu" and v.s[2] == 990002 and (sent.scheduled or 0) == 1 and not twice
			return good and true or false, string.format("übernommen %s, Rezepte %s, Senden %s, doppelt %s", S(ok), S(v and #v.n), S(sent.scheduled), S(twice)),
				"true, 2, 1, false"
		end, {
			{ ns, "SpellName", function(id) return id == 990002 and "GSTestNeu" or nil end },
			{ A, "GetProfessionInfoByRecipeID", function() return { professionName = "GSTestBeruf" } end },
			{ A, "GetTradeSkillLineForRecipe", nil }, { A, "GetRecipeOutputItemData", nil },
			{ P, "MyProfs", function() return { GSTestBeruf = true } end },
			{ ns, "InCombat", function() return false end },
		})
	end)

	Check("T207", "B", "T-S7: Rezeptprobe falsch – Weg abgeschaltet, nichts übernommen; Probe richtig – gefunden", function()
		if not ns.guild then return false, "keine Gilde", "Gilde" end
		local store = {}
		local answer
		return Box(store, function()
			store[P.MyKey()] = Entry(1, "GSTestBeruf", { "GSTestA" }, { 990011 })
			store["Testa Beispiel"] = Entry(5, "GSTestFremd", { "GSTestB" }, { 990012 })
			store["Mira Sonnenkind"] = Entry(5, "GSTestBeruf", { "GSTestA", "GSTestC" }, { 990011, 990013 })
			-- 1) IsPlayerSpell sagt immer "ja" -> Probe falsch
			answer = function() return true end
			local n1, why1 = P:RecipeProbe()
			local off = ns.guild.probeOff == ns.version
			local untouched = #store[P.MyKey()].p.GSTestBeruf.n == 1
			-- 2) richtige Antworten -> GSTestC wird gefunden
			ns.guild.probeOff = nil
			answer = function(id) return id == 990011 or id == 990013 end
			local n2, why2 = P:RecipeProbe()
			local v = store[P.MyKey()].p.GSTestBeruf
			local good = why1 == "falsch" and n1 == 0 and off and untouched and why2 == "ok" and n2 == 1 and v.n[2] == "GSTestC"
			return good and true or false, string.format("falsch: %s/%s/aus %s; richtig: %s/%s", S(why1), S(n1), S(off), S(why2), S(n2)),
				"falsch/0/aus true; richtig: ok/1"
		end, {
			{ A, "IsPlayerSpell", function(id) return answer(id) end },
			{ P, "MyProfs", function() return { GSTestBeruf = true } end },
			{ ns, "InCombat", function() return false end },
		})
	end)

	Check("T214", "B", "Hochleveln: 10 Stufen in 2 Minuten -> 1 Senden, neues Rezept -> sofort", function()
		if not ns.guild then return false, "keine Gilde", "Gilde" end
		local store = {}
		return Box(store, function(sent)
			store[P.MyKey()] = Entry(1, "GSTestBeruf", { "GSTestA" }, { 990021 })
			for _ = 1, 10 do P:LevelChanged() end
			local afterLevels = sent.scheduled or 0
			local pending = P.lvlPending
			local ok = P:LearnRecipe(990022)
			local afterRecipe = sent.scheduled or 0
			local flushed = P:FlushLevels()
			return (afterLevels == 1 and pending and ok and afterRecipe == 2 and flushed) and true or false,
				string.format("Stufen %d, wartet %s, Rezept %d, beim Schliessen %s", afterLevels, S(pending), afterRecipe, S(flushed)),
				"Stufen 1, wartet true, Rezept 2, beim Schliessen true"
		end, {
			{ P, "lvlSent", nil }, { P, "lvlPending", nil },
			{ ns, "SpellName", function(id) return id == 990022 and "GSTestNeu" or nil end },
			{ A, "GetProfessionInfoByRecipeID", function() return { professionName = "GSTestBeruf" } end },
			{ A, "GetTradeSkillLineForRecipe", nil }, { A, "GetRecipeOutputItemData", nil },
			{ P, "MyProfs", function() return { GSTestBeruf = true } end },
			{ ns, "InCombat", function() return false end },
		})
	end)

	Check("T215", "B", "Empfang in der Tiefe geprüft, WhoCanCraft mit kaputten Daten ohne Fehler", function()
		if not ns.guild then return false, "keine Gilde", "Gilde" end
		local store = {}
		return Box(store, function()
			P:Receive("Testa Beispiel", { n = "Testa Beispiel", t = 5, p = { X = 5, Y = { n = { 7, "GSTestRezept" }, i = { "a" } } } })
			local e = store["Testa Beispiel"]
			local clean = e and e.p.X == nil and e.p.Y and #e.p.Y.n == 1 and e.p.Y.i[1] == 0
			P:Receive("Mira Sonnenkind", { n = "Mira Sonnenkind", t = 5, p = { X = 5 } })
			local dropped = store["Mira Sonnenkind"] == nil
			store["Mira Sonnenkind"] = { t = 1, p = { X = 5, Z = { n = { 7 } } } }
			local ok, who = pcall(ns.Craft.WhoCanCraft, ns.Craft, 0, "gstestrezept")
			local found = ok and type(who) == "table" and #who == 1
			return (clean and dropped and found) and true or false,
				string.format("bereinigt %s, verworfen %s, WhoCanCraft %s", S(clean), S(dropped), ok and S(type(who) == "table" and #who) or "Fehler"),
				"bereinigt true, verworfen true, WhoCanCraft 1"
		end)
	end)

	Check("T216", "B", "Gilden-Rezepte: Gilden-Ansicht startet höchstens alle 10 Minuten, nichts doppelt gefragt", function()
		if not ns.guild then return false, "keine Gilde", "Gilde" end
		local store = {}
		local calls = 0
		return Box(store, function()
			store["Mira Sonnenkind"] = Entry(5, "GSTestBeruf", { "GSTestA", "GSTestB" }, { 990031, 990032 })
			local a1 = P:GuildRecipesStart()
			while #P.gr.queue > 0 do P:GuildRecipesNext() end
			-- gleicher Tag, Beruf schon gefragt: nichts Neues
			ns.guild.grDay = {}
			local a2 = P:GuildRecipesStart()
			return (a1 == 2 and calls == 2 and a2 == 0) and true or false,
				string.format("zuerst %s, Abfragen %d, nochmals %s", S(a1), calls, S(a2)), "zuerst 2, Abfragen 2, nochmals 0"
		end, {
			{ A, "QueryGuildMembersForRecipe", function() calls = calls + 1 end },
			{ A, "GetGuildRecipeInfoPostQuery", function() return nil end },
			{ A, "GetGuildRecipeMember", function() return nil end },
			{ P, "guildSkillIDs", { GSTestBeruf = 999 } },
			{ P, "gr", { queue = {}, profs = 0, entries = 0, running = true } },
			{ ns, "InCombat", function() return false end },
		})
	end)

	-- Seite Berufe: Leertext, Spalte "Wer", Mitglieder nur aus der Spielliste
	local function Dir(store, counts, fn)
		return Box(store, fn, { { P, "guildCounts", counts } })
	end
	Check("T208", "B", "T-B1: Beruf ohne bekannte Daten – Leertext mit Anzahl laut Spiel", function()
		local _, empty = Dir({}, { GSTestBeruf = 2 }, function() return P:DirView("GSTestBeruf") end)
		local want = string.format(L["%d Gildenmitglieder haben %s. Ihre Rezepte sind noch nicht bekannt – sie erscheinen, sobald sie mit GuildSentinel ihr Berufsfenster öffnen."], 2, "GSTestBeruf")
		return Eq(empty, want)
	end)
	Check("T209", "B", "T-B2: kein Beruf gewählt – allgemeiner Satz", function()
		local _, empty = Dir({}, { GSTestBeruf = 2 }, function() return P:DirView(nil) end)
		return Eq(empty, L["Suche oben nach einem Rezept oder wähle links einen Beruf."])
	end)
	Check("T210", "B", "T-B3: Spalte Wer – \"1 von 4\" bzw. nur die Zahl", function()
		local a = P:CountText({ count = 1, total = 4 })
		local b = P:CountText({ count = 2 })
		local want = "1 " .. string.format(L["von %d"], 4)
		return (a == want and b == "2") and true or false, S(a) .. " | " .. S(b), want .. " | 2"
	end)
	Check("T211", "B", "T-B4: Mitglied aus der Spielliste – Zeile \"Rezepte unbekannt\"", function()
		local store = { ["Testa Beispiel"] = { t = 0, g = true, p = { GSTestBeruf = { r = 150 } } } }
		local list = Dir(store, { GSTestBeruf = 1 }, function() return (P:DirView("GSTestBeruf")) end)
		local x = list and list[1]
		return (x and x.name == "Testa Beispiel" and x.g == true and x.r == 150 and L["Rezepte unbekannt"] ~= nil) and true or false,
			x and string.format("Zeile g=%s Stufe %s", S(x.g), S(x.r)) or "keine Zeile", "Zeile g=true Stufe 150"
	end)
	Check("T212", "B", "T-B5: 3 laut Spiel, 1 Name bekannt – \"+2 weitere laut Spiel\"", function()
		local store = { ["Testa Beispiel"] = { t = 0, g = true, p = { GSTestBeruf = { r = 150 } } } }
		local list, _, more = Dir(store, { GSTestBeruf = 3 }, function() return P:DirView("GSTestBeruf") end)
		local want = string.format(L["+%d weitere laut Spiel, Rezepte unbekannt"], 2)
		return (#list == 1 and more == want) and true or false, S(#list) .. " Zeile, " .. S(more), "1 Zeile, " .. want
	end)
end

------------------------------------------------------------
-- Addon-Nachrichten über die gemeinsame Datei GoldSentinelSync.lua (0.9.20): T217–T224
-- (= T-SY1–T-SY3, T-GS1–T-GS5). Ersetzt werden nur Einträge von GoldSentinelSync.api, nie Blizzard-Funktionen.
------------------------------------------------------------
function R:SyncCases()
	local Sync = _G.GoldSentinelSync
	local C = ns.Comm
	-- neue Einträge in der gemeinsamen Warteschlange (Weg je Eintrag), danach wieder entfernen
	local function Queued(fn)
		local before = {}
		for _, q in ipairs(Sync.queue) do before[q] = true end
		local ok, err = pcall(fn)
		local dists = {}
		for i = #Sync.queue, 1, -1 do
			local q = Sync.queue[i]
			if not before[q] then table.insert(dists, 1, q.dist); table.remove(Sync.queue, i) end
		end
		if not ok then error(err, 0) end
		return dists
	end
	local function Api(inGuild, inGroup, extra)
		local list = {
			{ Sync.api, "inGuild", function() return inGuild end },
			{ Sync.api, "inGroup", function() return inGroup end },
			{ Sync.api, "inRaid", function() return false end },
			{ Sync.api, "send", function() return true end },
		}
		for _, x in ipairs(extra or {}) do list[#list + 1] = x end
		return list
	end

	Check("T217", "B", "T-SY1/T-GS1: Senden über die gemeinsame Datei, nur Gilde/Gruppe (nie über einen Kanal)", function()
		if not (Sync and C.ep) then return false, "GoldSentinelSync fehlt", "geladen" end
		if not IsInGuild() then return nil, "nicht in einer Gilde" end
		local d = With(Api(true, true), function()
			return Queued(function()
				Outside(function()
					C:Send("LFG", { id = "GSTest" }, "GROUP")
					C:Send("LFGX", { id = "GSTest" }, "GUILD")
				end)
			end)
		end)
		local allowed = { GUILD = true, PARTY = true, RAID = true, WHISPER = true }
		local onlyAllowed = true
		for _, x in ipairs(d) do if not allowed[x] then onlyAllowed = false end end
		local txt = table.concat(d, ",")
		return (#d >= 2 and onlyAllowed and txt:find("GUILD", 1, true) and txt:find("PARTY", 1, true)) and true or false,
			txt, "PARTY,GUILD (nur Gilde/Gruppe)"
	end)

	Check("T218", "B", "T-SY2: Gilde -> GUILD, nur Gruppe -> PARTY, ohne beides nichts (Protokoll: kein Weg)", function()
		if not (Sync and C.ep) then return false, "GoldSentinelSync fehlt", "geladen" end
		local g = With(Api(true, false), function() return Queued(function() C.ep:Send("GSTest", C.Opts("ALL")) end) end)
		local p = With(Api(false, true), function() return Queued(function() C.ep:Send("GSTest", C.Opts("ALL")) end) end)
		local n0 = Sync.stats.dropped.nopath or 0
		local none = With(Api(false, false), function() return Queued(function() C.ep:Send("GSTest", C.Opts("ALL")) end) end)
		local counted = (Sync.stats.dropped.nopath or 0) == n0 + 1
		local line = Sync.DiagLines()[1] or ""
		local ok = table.concat(g, ",") == "GUILD" and table.concat(p, ",") == "PARTY" and #none == 0 and counted
		return ok and true or false, string.format("%s | %s | %d, gezählt %s", table.concat(g, ","), table.concat(p, ","), #none, S(counted)),
			"GUILD | PARTY | 0, gezählt true"
	end)

	Check("T219", "B", "T-SY3: NOT_ALLOWED_IN_CHANNEL -> Protokollzeile", function()
		if not ns.DiagChannelNotice then return false, "fehlt", "ns.DiagChannelNotice" end
		local box = { entries = {}, sessions = {} }
		local e = With({ { ns, "diagForce", true }, { GuildSentinelDB, "diag", box } }, function()
			ns.DiagChannelNotice("NOT_ALLOWED_IN_CHANNEL")
			ns.DiagChannelNotice("YOU_JOINED")
			return box.entries
		end)
		return (#e == 1 and e[1].k == "SYNC" and tostring(e[1].t):find("NOT_ALLOWED_IN_CHANNEL", 1, true)) and true or false,
			string.format("%d Zeile(n)", #e), "1 Zeile SYNC"
	end)

	Check("T220", "B", "T-GS2/T-GS3: Empfang über ep:OnMessage – Absender nil vertragen, alte Nachricht ohne Kopf verstanden", function()
		if not (Sync and C.ep and ns.guild) then return false, "GoldSentinelSync fehlt", "geladen" end
		local store = {}
		local e0 = ns.errors.n
		local drop0 = C.dropped.nosender or 0
		local r = MiniRoster({ "Testa Beispiel", "Mira Sonnenkind", Me() }, function()
			return With({ { ns.guild, "prof", store }, { ns.RMI, "Profs", function() return nil end }, { ns.Prof, "rx", { n = 0, a = 0, o = 0, u = 0 } }, { ns.Prof, "rxPending", true } }, function()
				return Outside(function()
					-- alte Version eines Mitspielers: ohne Kopf, mit Absender
					Sync.OnAddonMessage(C.PREFIX, "PROF\t" .. C.Serialize({ n = "Testa Beispiel", t = 5, p = { GSTestBeruf = { r = 10, n = { "GSTestRezept" } } } }), "GUILD", "Testa Beispiel")
					-- geschützter Absender (nil): PROF bringt den Namen selbst mit, HI wird ohne Fehler verworfen
					Sync.OnAddonMessage(C.PREFIX, "PROF\t" .. C.Serialize({ n = "Mira Sonnenkind", t = 5, p = { GSTestBeruf = { r = 20 } } }), "GUILD", nil)
					Sync.OnAddonMessage(C.PREFIX, "HI\t" .. C.Serialize({ v = "0" }), "GUILD", nil)
					return { old = store["Testa Beispiel"] ~= nil, nilSender = store["Mira Sonnenkind"] ~= nil }
				end)
			end)
		end)
		local dropped = (C.dropped.nosender or 0) == drop0 + 1
		local ok = r.old and r.nilSender and dropped and ns.errors.n == e0
		return ok and true or false, string.format("alt %s, ohne Absender %s, verworfen %s, Fehler %d", S(r.old), S(r.nilSender), S(dropped), ns.errors.n - e0),
			"alt true, ohne Absender true, verworfen true, Fehler 0"
	end)

	Check("T221", "B", "T-GS4: kein Beitritt zu einem eigenen Kanal mehr", function()
		local r0 = Recorded("JoinChannel")
		Outside(function() ns.Group:JoinChannel(); ns.SetFeature("group", false); ns.SetFeature("group", true) end)
		local joins = Recorded("JoinChannel") - r0
		return (joins == 0 and ns.Group.JoinChannel ~= nil) and true or false, joins .. " Beitritte", "0"
	end)

	Check("T222", "B", "T-GS5: /gs sync test gibt eine Zeile aus", function()
		if not (Sync and C.ep) then return false, "GoldSentinelSync fehlt", "geladen" end
		local out = Printed(function()
			With(Api(true, false), function()
				Queued(function()
					Outside(function() SlashCmdList.GUILDSENTINEL("sync test") end)
					Sync.FinishPings(true)
				end)
			end)
		end)
		local want = string.format(L["%d Antworten (Gilde %d, Gruppe %d)"], 0, 0, 0)
		return AnyHas(out, want), table.concat(out, " | "):sub(1, 120), want
	end)

	Check("T223", "B", "Werbung: nur Blizzard-Kanäle (Addon- und Spielerkanäle ausgeblendet)", function()
		local Rc = ns.Recruit
		local server = { allgemein = true, handel = true, suchenachgruppe = true }
		local got = {
			Rc.IsBlizzard("Handel", 1, server), Rc.IsBlizzard("SucheNachGruppe", 0, server),
			not Rc.IsBlizzard("AHAPSync", 0, server), not Rc.IsBlizzard("GuildSentinelLFG", 0, server),
			not Rc.IsBlizzard("LevelPilotNet", 0, server), not Rc.IsBlizzard("BuffSentinelSync", 0, server),
			not Rc.IsBlizzard("Welt", 0, server),
		}
		local f = {}
		for i, v in ipairs(got) do f[i] = v and "1" or "0" end
		local txt = table.concat(f)
		return txt == "1111111", txt, "1111111"
	end)

	Check("T225", "B", "T-N1: GoldSentinelSync Version 2 geladen (auch neben Version 1 anderer Addons)", function()
		local v = Sync and tonumber(Sync.VERSION) or 0
		return v >= 2, S(v), ">= 2"
	end)

	Check("T226", "B", "T-N2: bekannte Mitspieler in GuildSentinelDB.gsSync (UseStorage)", function()
		if not (Sync and Sync.Learn and C.ep and C.ep.UseStorage) then return false, "fehlt", "GoldSentinelSync 2" end
		-- Ersatz-Speicher und Ersatz-Buch (nur Felder der gemeinsamen Tabelle), danach alles zurück
		local db = {}
		local book = {}
		local found = With({ { Sync, "book", book }, { Sync, "store", nil } }, function()
			C.ep:UseStorage(db)
			Sync.Learn("Testa Beispiel", "whisper", 2)
			return type(db.gsSync) == "table" and type(db.gsSync.book) == "table" and db.gsSync.book["Testa Beispiel"] ~= nil
		end)
		return found and true or false, S(found), "true"
	end)

	Check("T227", "B", "T-N3: net = false und scope \"guild\" – keine Flüsternachricht ins Netz", function()
		if not (Sync and C.ep and Sync.NetSend) then return false, "fehlt", "GoldSentinelSync 2" end
		local book = { ["Testa Beispiel"] = { seen = (time and time() or 0), v = 2, src = "whisper", fail = 0, pause = 0 } }
		local whispers = 0
		With(Api(true, true, { { Sync, "book", book }, { Sync, "netQueue", {} } }), function()
			Queued(function()
				C.ep:Send("GSTest", { net = false })
				C.ep:Send("GSTest", { scope = "guild" })
				Outside(function() C:Send("THX", { n = "x" }, "GUILD") end)
			end)
			for _, q in ipairs(Sync.netQueue) do if q.dist == "WHISPER" or q.target then whispers = whispers + 1 end end
			-- Gegenprobe: die Gruppensuche für den ganzen Server geht ins Netz
			Queued(function() Outside(function() C:Send("LFGX", { id = "GSTest" }, "NET") end) end)
		end)
		local netted = 0
		With(Api(true, true, { { Sync, "book", book }, { Sync, "netQueue", {} } }), function()
			Queued(function() Outside(function() C:Send("LFGX", { id = "GSTest" }, "NET") end) end)
			netted = #Sync.netQueue
		end)
		local want = Sync.NET and 1 or 0
		return (whispers == 0 and netted == want) and true or false, whispers .. " Flüsternachrichten, Gruppensuche ins Netz " .. netted,
			"0, Gruppensuche ins Netz " .. want
	end)

	Check("T228", "B", "T-N4: Protokoll enthält NETZ und keinen Spielernamen", function()
		if not Sync then return false, "fehlt", "GoldSentinelSync" end
		local book = { ["Testa Beispiel"] = { seen = 1, v = 2, src = "whisper", fail = 0, pause = 0 } }
		local text = With({ { Sync, "book", book } }, function() return table.concat(Sync.DiagLines(), "\n") end)
		local net = text:find("NETZ", 1, true) ~= nil
		local name = text:find("Testa", 1, true) ~= nil or (Me() and text:find(Me(), 1, true) ~= nil)
		return (net and not name) and true or false, string.format("NETZ %s, Name %s", S(net), S(name)), "NETZ true, Name false"
	end)

	Check("T229", "B", "T-GT1: GoldSentinelTest Version 2 geladen", function()
		local v = GoldSentinelTest and tonumber(GoldSentinelTest.version) or 0
		return v >= 2, S(v), ">= 2"
	end)

	Check("T230", "B", "T-GT2: ohne Zustimmung bleibt der Ausgang nach einem Fehler leer", function()
		local GT = GoldSentinelTest
		if not (GT and GT.Outbox and GT.Setting) then return false, "fehlt", "GoldSentinelTest 2" end
		if GT.Setting("consent") == true then return nil, "Zustimmung erteilt – Fall nicht prüfbar" end
		local db = {}
		GT.Outbox(db, { kind = "errors", addon = ADDON, version = ns.version, errors = { { wo = "GSTest.lua:1", msg = "GSTest", count = 1 } }, results = {} })
		local ob = db.gsTest and db.gsTest.share and db.gsTest.share.outbox
		local n = type(ob) == "table" and #ob or 0
		return n == 0, n .. " im Ausgang", "0"
	end)

	Check("T224", "B", "Diagnose: Zeilen der gemeinsamen Datei im Protokoll", function()
		if not Sync then return false, "GoldSentinelSync fehlt", "geladen" end
		local text = ns.DiagText()
		return (text:find("SYNC GoldSentinelSync", 1, true) and text:find("SYNC gesendet", 1, true)) and true or false,
			text:match("SYNC GoldSentinelSync[^\n]*") or "fehlt", "SYNC GoldSentinelSync … / SYNC gesendet …"
	end)
end

------------------------------------------------------------
-- Rezepte je Mitglied, nach Art gefiltert (0.9.22): T231–T236 = T-RM1–T-RM6, T238 Gruppensuche nicht ins Netz
-- (T237 = R7, Filterleiste, in Bereich K). Ersatz-Speicher, Platzhalter-Namen; ersetzt werden nur ns.API-Einträge.
------------------------------------------------------------
-- Items für die Fälle (Ersatz für GetItemInfoInstant): Platz bzw. Klasse/Unterklasse
local KIND_ITEMS = {
	[990901] = { "INVTYPE_HEAD", 4, 4 }, [990902] = { "INVTYPE_CHEST", 4, 4 }, [990903] = { "INVTYPE_HAND", 4, 4 },
	[990904] = { "INVTYPE_WEAPON", 2, 7 },
}
local function FakeInstant(id)
	local x = KIND_ITEMS[id]
	if not x then return nil end
	return id, "", "", x[1], 0, x[2], x[3]
end

-- Ersatz-Speicher mit Testgilde
local function KindBox(store, fn, extra)
	local list = {
		{ ns.guild or {}, "prof", store }, { ns.RMI, "Profs", function() return nil end }, { ns.Kinds, "cache", {} },
	}
	for _, x in ipairs(extra or {}) do list[#list + 1] = x end
	return MiniRoster({ "Testa Beispiel", "Mira Sonnenkind", Me() }, function() return With(list, fn) end)
end

function R:RecipeKindCases()
	local P, A = ns.Prof, ns.API
	Check("T231", "B", "T-RM1: Schmied – Filter Kopf/Brust/Hände/Waffen, Klick Brust -> nur das Brust-Rezept", function()
		if not ns.guild then return false, "keine Gilde", "Gilde" end
		local store = { ["Mira Sonnenkind"] = { t = 5, c = "WARRIOR", p = { GSTestSchmied = { r = 300,
			n = { "GSTest Helm", "GSTest Brustplatte", "GSTest Handschuhe", "GSTest Schwert" }, i = { 990901, 990902, 990903, 990904 } } } } }
		return KindBox(store, function()
			local _, counts, kinds = P:MemberRecipes("Mira Sonnenkind", "GSTestSchmied")
			local labels = {}
			for _, k in ipairs(kinds) do labels[#labels + 1] = ns.Kinds.Label(k) .. " " .. counts[k] end
			local chest = P:MemberRecipes("Mira Sonnenkind", "GSTestSchmied", "chest")
			local txt = table.concat(labels, " · ")
			local want = L["Kopf"] .. " 1 · " .. L["Brust"] .. " 1 · " .. L["Hände"] .. " 1 · " .. L["Einhandwaffen"] .. " 1"
			return (txt == want and #chest == 1 and chest[1].recipe == "GSTest Brustplatte") and true or false,
				txt .. " | Brust: " .. S(#chest), want .. " | Brust: 1"
		end, { { A, "GetItemInfoInstant", FakeInstant } })
	end)

	Check("T232", "B", "T-RM2: Alchemie – Elixiere / Heiltränke / Erholungstränke / Transmutationen", function()
		local got = {}
		With({ { A, "GetItemInfoInstant", nil }, { ns.Kinds, "cache", {} } }, function()
			for _, n in ipairs({ "Elixier der Löwenstärke", "Geringer Heiltrank", "Erholungstrank", "Transmutieren: Arkanit" }) do
				got[#got + 1] = ns.Kinds.Of(n, 0)
			end
			for _, n in ipairs({ "Elixir of Lion's Strength", "Minor Healing Potion", "Major Rejuvenation Potion", "Transmute: Arcanite" }) do
				got[#got + 1] = ns.Kinds.Of(n, 0)
			end
		end)
		local txt = table.concat(got, ",")
		local want = "elixir,healpot,rejuv,transmute,elixir,healpot,rejuv,transmute"
		return txt == want, txt, want
	end)

	Check("T233", "B", "T-RM3: Verzauberkunst nach Platz", function()
		local got = {}
		With({ { ns.Kinds, "cache", {} } }, function()
			got[1] = ns.Kinds.Of("Verzaubern: Brust – Geringe Gesundheit", 0)
			got[2] = ns.Kinds.Of("Enchant Chest - Lesser Health", 0)
			got[3] = ns.Kinds.Of("Verzaubern: Zweihandwaffe – Geringer Einschlag", 0)
			got[4] = ns.Kinds.Of("Verzaubern: Waffe – Schlagen", 0)
			got[5] = ns.Kinds.Of("Verzaubern: Armschiene – Geringe Ausdauer", 0)
		end)
		local txt = table.concat(got, ",")
		local want = "ench_chest,ench_chest,ench_2h,ench_weapon,ench_wrist"
		return (txt == want and ns.Kinds.Label("ench_chest") == L["Brust"]) and true or false, txt, want
	end)

	Check("T234", "B", "T-RM4: Daten ohne Item-ID (alter Sender) -> Sonstiges, kein Fehler", function()
		if not ns.guild then return false, "keine Gilde", "Gilde" end
		local store = { ["Testa Beispiel"] = { t = 5, p = { GSTestBeruf = { r = 10, n = { "GSTest Ding" } } } } }
		local e0 = ns.errors.n
		local ok, rows, counts = pcall(function()
			return KindBox(store, function() return P:MemberRecipes("Testa Beispiel", "GSTestBeruf") end)
		end)
		local good = ok and rows and #rows == 1 and rows[1].kind == "other" and counts.other == 1 and ns.errors.n == e0
		return good and true or false, ok and (S(rows and rows[1] and rows[1].kind)) or "Fehler", "other"
	end)

	Check("T235", "B", "T-RM5: Feld k vorhanden -> Blizzard-Kategorie; fehlt k -> eigene Art", function()
		if not ns.guild then return false, "keine Gilde", "Gilde" end
		local store = {
			["Testa Beispiel"] = { t = 5, p = { GSTestSchmied = { r = 10, n = { "GSTest Helm" }, i = { 990901 }, k = { "GSTestKategorie" } } } },
			["Mira Sonnenkind"] = { t = 5, p = { GSTestSchmied = { r = 10, n = { "GSTest Helm" }, i = { 990901 } } } },
		}
		return KindBox(store, function()
			local a = P:MemberRecipes("Testa Beispiel", "GSTestSchmied")
			local b = P:MemberRecipes("Mira Sonnenkind", "GSTestSchmied")
			local ka, kb = a[1] and a[1].kind, b[1] and b[1].kind
			return (ka == "k:GSTestKategorie" and ns.Kinds.Label(ka) == "GSTestKategorie" and kb == "head") and true or false,
				S(ka) .. " / " .. S(kb), "k:GSTestKategorie / head"
		end, { { A, "GetItemInfoInstant", FakeInstant } })
	end)

	Check("T236", "B", "T-RM6: Daten mit k bleiben für ältere Leser unverändert (n, i, s gleich)", function()
		if not ns.guild then return false, "keine Gilde", "Gilde" end
		local d = { n = "Testa Beispiel", t = 7, p = { GSTestBeruf = { r = 10, n = { "GSTest A", "GSTest B" }, i = { 1, 2 }, s = { 3, 4 }, k = { "X", "Y" } } } }
		local back = ns.Comm.Deserialize(ns.Comm.Serialize(d))
		-- so liest eine ältere Version (bis 0.9.21): nur n, i, s
		local v = back and back.p and back.p.GSTestBeruf
		local oldOk = v and v.n[2] == "GSTest B" and v.i[2] == 2 and v.s[2] == 4
		local store = {}
		local stored = KindBox(store, function()
			With({ { P, "rx", { n = 0, a = 0, o = 0, u = 0 } }, { P, "rxPending", true } }, function() P:Receive("Testa Beispiel", back) end)
			local e = store["Testa Beispiel"]
			return e and e.p.GSTestBeruf.k and e.p.GSTestBeruf.k[2] == "Y" and e.p.GSTestBeruf.n[2] == "GSTest B"
		end)
		return (oldOk and stored) and true or false, string.format("alt lesbar %s, k übernommen %s", S(oldOk), S(stored)), "alt lesbar true, k übernommen true"
	end)

	Check("T239", "B", "Werbung (Forever): Chat-Eingabe \"/5 <Text>\" vorbereitet, nichts selbst in den Kanal gesendet", function()
		local Rc = ns.Recruit
		Flavor("forever")
		local c = { short = "GSTestKanal", id = 5, name = "5. GSTestKanal" }
		local o0, s0 = Recorded("ChatFrame_OpenChat"), Recorded("SendChatMessage")
		local t0 = ns.db.lastAdTime
		local ok = With({
			{ Rc, "Targets", function() return { c } end }, { Rc, "NextTarget", function() return c, 0 end },
			{ Rc, "GlobalWait", function() return 0 end }, { Rc, "AdText", function() return "GSTest Werbung" end },
			{ Rc, "prepared", nil },
		}, function()
			Outside(function() Rc:Post() end)
			return Rc.prepared ~= nil
		end)
		Flavor(nil)
		local opened = Recorded("ChatFrame_OpenChat") - o0
		local sent = Recorded("SendChatMessage") - s0
		local text = R.recLast.ChatFrame_OpenChat
		local good = ok and opened == 1 and sent == 0 and text == "/5 GSTest Werbung" and ns.db.lastAdTime == t0
		return good and true or false, string.format("Eingabe %d (%s), gesendet %d, vorgemerkt %s", opened, S(text), sent, S(ok)),
			"Eingabe 1 (/5 GSTest Werbung), gesendet 0, vorgemerkt true"
	end)

	Check("T242", "B", "Lange Werbung: Eingabe höchstens 255 Zeichen, gekürzter Text zählt nach dem Senden als gepostet", function()
		local Rc = ns.Recruit
		local c = { short = "GSTestKanal", id = 12, name = "12. GSTestKanal" }
		-- 300 Bytes mit Umlauten an der Schnittstelle (UTF-8 darf nicht zerschnitten werden)
		local long = ("Gilde sucht Mitstreiter für Raids und Dungeons, äöü "):rep(8)
		local posted = false
		local r = With({
			{ Rc, "Targets", function() return { c } end }, { Rc, "NextTarget", function() return c, 0 end },
			{ Rc, "GlobalWait", function() return 0 end }, { Rc, "AdText", function() return long end },
			{ Rc, "prepared", nil }, { Rc, "Posted", function() posted = true end },
		}, function()
			Outside(function() Rc:Post() end)
			local input = R.recLast.ChatFrame_OpenChat or ""
			local p = Rc.prepared
			-- der Spieler sendet mit Enter: der Server zeigt den Text ohne "/12 "
			local counted = p and Rc.OnChannel(p.text, Me(), "", "", "", "", 0, 12) or false
			return { len = #input, prefix = input:sub(1, 4) == "/12 ", same = p and input:sub(5) == p.text, counted = counted }
		end)
		local good = r.len <= 255 and r.len > 200 and r.prefix and r.same and r.counted and posted
		return good and true or false, string.format("Eingabe %d Zeichen, gleich gemerkt %s, gezählt %s", r.len, S(r.same), S(posted)),
			"Eingabe <= 255 Zeichen, gleich gemerkt true, gezählt true"
	end)

	Check("T243", "B", "ns.CutBytes zerschneidet keine UTF-8-Zeichen", function()
		local t = ("ä"):rep(200)               -- 400 Bytes, jedes Zeichen 2 Bytes
		local c = ns.CutBytes(t, 250)
		local body = c:sub(1, #c - 3)
		local ok = #c <= 250 and c:sub(-3) == "..." and (#body % 2 == 0) and body:gsub("ä", "") == ""
		return ok and true or false, #c .. " Bytes", "<= 250, ganze Zeichen"
	end)

	-- Neuer Standard-Werbetext (0.9.25): T244–T247 = T-WT1–T-WT4. Platzhalter-Werte, keine echten Namen/Links.
	local function AdBox(adText, discord, guild, fn, extra)
		local Rc = ns.Recruit
		local list = {
			{ ns.db, "adText", adText }, { ns.db, "discord", discord },
			{ ns, "DisplayGuildName", function() return guild end }, { ns, "Me", function() return "Testname" end },
			{ Rc, "Faction", function() return "Horde" end },
			{ ns.Comp, "Missing", function() return { { label = "Heiler" }, { label = "Krieger" }, { label = "Magier" } } end },
			-- Phase Raid: {gesucht} = Lücken der Aufstellung (seit 0.9.31 hängt {gesucht} von der Rekrutierungsphase ab)
			{ ns.RaidReady, "Phase", function() return "raid" end },
		}
		for _, x in ipairs(extra or {}) do list[#list + 1] = x end
		return With(list, fn)
	end
	Check("T244", "B", "T-WT1: neuer Standardtext mit allen Werten", function()
		local Rc = ns.Recruit
		local text = AdBox(nil, "https://discord.gg/test", "<Testgilde>", function() return Rc:AdText() end)
		local want = Rc:DefaultAd("raid"):gsub("{gilde}", "<Testgilde>"):gsub("{fraktion}", "Horde")
			:gsub("{gesucht}", "Heiler, Krieger " .. L["und"] .. " Magier"):gsub("{discord}", "https://discord.gg/test"):gsub("{name}", "Testname")
		return text == want, text, want
	end)
	Check("T245", "B", "T-WT2: ohne Discord kein \"Discord:\", kein doppeltes Leerzeichen/Strich", function()
		local text = AdBox(nil, "", "<Testgilde>", function() return ns.Recruit:AdText() end)
		local bad = text:find("Discord", 1, true) or text:find("  ", 1, true) or text:find("– –", 1, true) or text:find("%- %-")
			or text:find("{", 1, true) or text:find("%. –") or text:find("^%s*–")
			or text:find("[%.!%?] %l")             -- nach dem Satzende gross weiter
		return not bad, text, "ohne Discord, sauber, Satzanfang gross"
	end)
	Check("T246", "B", "T-WT3: eigener gespeicherter Text bleibt unverändert", function()
		local own = "Eigener GSTest-Text {gilde} {gesucht}"
		local text, stored = AdBox(own, "", "<Testgilde>", function() return ns.Recruit:AdText(), ns.db.adText end)
		local want = "Eigener GSTest-Text <Testgilde> Heiler, Krieger " .. L["und"] .. " Magier"
		return (stored == own and text == want) and true or false, text, want
	end)
	Check("T247", "B", "T-WT4: Länge höchstens 255 − #\"/1 \" auch mit langen Werten", function()
		local Rc = ns.Recruit
		local longGuild = "<" .. ("Testgilde"):rep(7) .. ">"
		local text, raw = AdBox(nil, "https://discord.gg/" .. ("x"):rep(80), longGuild, function() return Rc:AdText(), Rc:AdRaw() end)
		local max = 255 - #("/1 ")
		return (#text <= max and #raw > #text and text:sub(-3) == "...") and true or false,
			string.format("%d Zeichen (ungekürzt %d)", #text, #raw), "<= " .. max .. ", gekürzt mit ..."
	end)
	Check("T248", "B", "{gesucht}: Liste mit \"und\", leer -> \"neue Mitglieder\"", function()
		local a = AdBox(nil, "", "<Testgilde>", function() return ns.Comp:WantedList() end)
		local b = With({ { ns.Comp, "Missing", function() return {} end } }, function() return ns.Comp:WantedList() end)
		local wa = "Heiler, Krieger " .. L["und"] .. " Magier"
		return (a == wa and b == L["neue Mitglieder"]) and true or false, S(a) .. " | " .. S(b), wa .. " | " .. L["neue Mitglieder"]
	end)

	Check("T249", "B", "Zähler der Werbung: \"wird gekürzt\" nur bei zu langem Text", function()
		local UI = ns.UI
		local page = UI.pages[UI:PageIndex("recruit")]
		if not (page and page.Preview) then return nil, "Seite Werbung fehlt" end
		local wasShown = UI.frame and UI.frame:IsShown()
		if not page.length then UI:Open("recruit") end
		if not page.length then return false, "Seite nicht gebaut", "Zähler" end
		local function Counter(text)
			return AdBox(text, "", "<Testgilde>", function() page:Preview(); return page.length:GetText() or "" end)
		end
		local short = Counter("GSTest kurz {gilde}")
		local long = Counter(("GSTest lang "):rep(30))
		if not wasShown and UI.frame then UI.frame:Hide() end
		local mark = L["wird gekürzt"]
		local ok = not short:find(mark, 1, true) and long:find(mark, 1, true) ~= nil
		return ok and true or false, short .. " | " .. long, "ohne | mit \"" .. mark .. "\""
	end)

	Check("T250", "B", "Alter gespeicherter Standardtext wird einmalig durch den neuen ersetzt, eigener bleibt", function()
		local Rc = ns.Recruit
		local r = With({ { ns.db, "adText", Rc.OLD_DEFAULT_DE } }, function()
			local a = Rc:MigrateAdText()
			local cleared = ns.db.adText == nil
			-- alter Standard in der Sprache des Clients (mit Leerzeichen am Ende)
			ns.db.adText = L["<{gilde}> sucht Mitstreiter! {gesucht} Raids, Dungeons und eine entspannte Gemeinschaft. {discord} Flüstert mich an: /w {name} gilde"] .. " "
			local l = Rc:MigrateAdText()
			local clearedL = ns.db.adText == nil
			ns.db.adText = "GSTest eigener Text {gesucht}"
			local b = Rc:MigrateAdText()
			return { a = a, cleared = cleared, l = l and clearedL, kept = (not b) and ns.db.adText == "GSTest eigener Text {gesucht}" }
		end)
		return (r.a and r.cleared and r.l and r.kept) and true or false,
			string.format("alt (deDE) ersetzt %s, alt (Client) ersetzt %s, eigener bleibt %s", S(r.cleared), S(r.l), S(r.kept)),
			"alt (deDE) ersetzt true, alt (Client) ersetzt true, eigener bleibt true"
	end)

	-- DP2 (0.9.28): Vorschlag 2 mit Server-Tag – mit/ohne Link, mit/ohne Tag, Deutsch/Englisch/Russisch
	Check("T251", "B", "T-DP2: Vorschlag 2 mit/ohne Discord-Link und Tag (DE/EN/RU)", function()
		local Rc = ns.Recruit
		local texts = {
			de = "<{gilde}> ({fraktion}) sucht {gesucht}! Entspannte, deutschsprachige Gilde mit Raidziel. Discord: {discord} – erkennbar am Tag {tag}.",
			en = "<{gilde}> ({fraktion}) is looking for {gesucht}! Relaxed guild with raid goals. Discord: {discord} – you'll know us by the tag {tag}.",
			ru = "<{gilde}> ({fraktion}) ищет {gesucht}! Дружная гильдия с рейдовыми целями. Discord: {discord} – узнаете по тегу {tag}.",
		}
		local bad = {}
		for lang, t in pairs(texts) do
			for _, case in ipairs({ { "https://discord.gg/test", "GT" }, { "https://discord.gg/test", "" }, { "", "GT" } }) do
				local out = AdBox(t, case[1], "Testgilde", function() return Rc:AdText() end, { { ns.db, "discordTag", case[2] } })
				local hasLink, hasTag = out:find("discord.gg/test", 1, true), out:find("GT", 1, true)
				local wantLink, wantTag = case[1] ~= "", case[1] ~= "" and case[2] ~= ""
				if (hasLink ~= nil) ~= wantLink or (hasTag ~= nil) ~= wantTag or out:find("{", 1, true) or out:find("  ", 1, true)
					or out:find("..", 1, true) or out:find("– %.") or out:find("Discord:%s*$") or #out > Rc.AD_MAX then
					bad[#bad + 1] = lang .. ": " .. out
				end
			end
		end
		-- eigene Texte ohne Gedankenstrich (Nachprüfung 0.9.28, Punkt 1): Klammer, eigener Satz, Textanfang
		for _, c in ipairs({
			{ "Discord: {discord} (Tag {tag}).", "Discord: {discord} ." },
			{ "Join us! Tag: {tag}. Whisper me", "Join us!  Whisper me" },
			{ "Tag {tag}. Hallo", "Tag . Hallo" },
			{ "Heiler – Tag {tag}!", "Heiler!" },
			{ "Discord: discord.gg/x Tag {tag}", "Discord: discord.gg/x Tag " },
			{ "<{gilde}> – 태그 {tag}(으)로 알아보세요.", "<{gilde}>." },
		}) do
			local got = Rc.DropTag(c[1])
			if got ~= c[2] then bad[#bad + 1] = "DropTag " .. c[1] .. " -> " .. got end
		end
		local own = AdBox("Discord: {discord} (Tag {tag}). Join us! Tag: {tag}. Whisper me", "https://discord.gg/test", "Testgilde",
			function() return Rc:AdText() end, { { ns.db, "discordTag", "" } })
		if own ~= "Discord: https://discord.gg/test. Join us! Whisper me" then bad[#bad + 1] = "eigener Text: " .. own end
		-- Knopf-Text des Spiels ist der Vorschlag in der eigenen Sprache
		local own = Rc:Suggestion2():find("{tag}", 1, true) ~= nil
		return (#bad == 0 and own) and true or false, #bad == 0 and "9 Fälle sauber" or bad[1], "9 Fälle sauber"
	end)

	Check("T252", "B", "T-DP1: Tipp \"dauerhafte Einladung\" beim Discord-Link", function()
		local UI = ns.UI
		local page = UI.pages[UI:PageIndex("recruit")]
		if not page then return nil, "Seite Werbung fehlt" end
		local wasShown = UI.frame and UI.frame:IsShown()
		if not page.discordTip then UI:Open("recruit") end
		local t = page.discordTip and page.discordTip:GetText() or ""
		if not wasShown and UI.frame then UI.frame:Hide() end
		local want = L["Tipp: eine dauerhafte Einladung verwenden (läuft nie ab, unbegrenzte Nutzungen). Wer klickt, sieht vor dem Beitritt das Serverprofil der Gilde."]
		return t:find(want, 1, true) ~= nil, t ~= "" and "vorhanden" or "fehlt", "vorhanden"
	end)

	-- GV1 (0.9.29): Einladen in die Gilde verbietet das Spiel (WoW Forever) – nie direkt, Status erst nach Bestätigung
	Check("T253", "B", "GV1: Einladen nur über /ginvite in der Chat-Eingabe, Status erst nach der Systemmeldung", function()
		local Rc = ns.Recruit
		local g = ns.G()
		local name = "Testa Beispiel"
		local saved = g.apps[name]
		g.apps[name] = { st = "new", t = ns.Now() }
		local gi0, o0 = Recorded("GuildInvite"), Recorded("ChatFrame_OpenChat")
		local ok = false
		With({ { ns, "CanInvite", Yes } }, function() Outside(function() Printed(function() ok = Rc:Invite(name) end) end) end)
		local input = R.recLast.ChatFrame_OpenChat or ""
		local direct = Recorded("GuildInvite") - gi0
		local opened = Recorded("ChatFrame_OpenChat") - o0
		local before = g.apps[name].st
		-- Bestätigung des Spiels (ERR_GUILD_INVITE_S); ohne den Text im Spiel direkt
		local fmt = type(ERR_GUILD_INVITE_S) == "string" and ERR_GUILD_INVITE_S or nil
		if fmt then FireEvent("CHAT_MSG_SYSTEM", string.format(fmt, name)) else Rc.OnInviteConfirmed(name) end
		local after = g.apps[name].st
		g.apps[name] = saved
		Rc.inviteSent[name] = nil
		ns:Fire("GS_APPS")
		local res = string.format("direkt %d, Eingabe %d \"%s\", vorher %s, nachher %s", direct, opened, input, tostring(before), tostring(after))
		return (ok and direct == 0 and opened == 1 and input:match("^/%S+ Testa Beispiel$") and before == "new" and after == "invited") and true or false,
			res, "direkt 0, Eingabe 1 \"/ginvite Testa Beispiel\", vorher new, nachher invited"
	end)

	Check("T240", "B", "LFGX: Gildensuche schliesst nur der Suchende selbst, ganzer Server auch weitergegeben", function()
		local G = ns.Group
		local h = ns.Comm.handlers.LFGX
		if not (G and h) then return false, "fehlt", "LFGX" end
		local list = {
			GSTestG = { id = "GSTestG", by = "Testa Beispiel", scope = "guild", t = ns.Now() },
			GSTestS = { id = "GSTestS", by = "Testa Beispiel", scope = "server", t = ns.Now() },
		}
		local r = With({ { ns.G(), "lfg", list }, { ns, "Fire", function() end } }, function()
			-- fremder Absender mit dem Namen des Suchenden in den Daten
			h("Mira Sonnenkind", { id = "GSTestG", by = "Testa Beispiel" }, "GUILD")
			h("Mira Sonnenkind", { id = "GSTestS", by = "Testa Beispiel" }, "GUILD")
			local a, b = list.GSTestG.closed, list.GSTestS.closed
			h("Testa Beispiel", { id = "GSTestG" }, "GUILD")
			return { guildByOther = a, serverRelayed = b, guildBySelf = list.GSTestG.closed }
		end)
		local good = not r.guildByOther and r.serverRelayed and r.guildBySelf
		return good and true or false, string.format("Gilde fremd %s, Server weitergegeben %s, Gilde selbst %s", S(r.guildByOther), S(r.serverRelayed), S(r.guildBySelf)),
			"Gilde fremd nil, Server weitergegeben true, Gilde selbst true"
	end)

	Check("T241", "B", "Gilden-Berufsliste: zweites Lesen ohne Liste setzt trotzdem zurück", function()
		local P, A = ns.Prof, ns.API
		local restored, collapsed = false, 0
		local r = With({
			{ A, "GetNumGuildTradeSkill", nil },
			{ A, "SetGuildRosterShowOffline", function(v) if v == false then restored = true end end },
			{ A, "CollapseGuildTradeSkillHeader", function() collapsed = collapsed + 1 end },
			{ P, "glOpened", { 903 } }, { P, "glOffline", true }, { P, "glToken", {} }, { P, "glSelf", nil },
		}, function()
			P:ReadGuildList(true)
			return { token = P.glToken, opened = P.glOpened }
		end)
		local good = restored and collapsed == 1 and r.token == nil and r.opened == nil
		return good and true or false, string.format("Offline zurück %s, zugeklappt %d, Zeitgeber %s", S(restored), collapsed, r.token and "offen" or "gelöscht"),
			"Offline zurück true, zugeklappt 1, Zeitgeber gelöscht"
	end)

	Check("T238", "B", "Gruppensuche ganzer Server: Gruppenänderungen gehen nicht ins Flüster-Netz", function()
		local Sync = _G.GoldSentinelSync
		if not (Sync and ns.Group) then return false, "fehlt", "GoldSentinelSync" end
		local G = ns.Group
		local mine = { id = "GSTest1", by = Me(), scope = "server", t = ns.Now(), d = "ubrs", roles = {} }
		local sentGroup, before = 0, 0
		With({
			{ Sync, "netQueue", {} },
			{ G, "Mine", function() return mine end },
			{ G, "lastGroupSend", nil },
			{ ns.Comm, "Send", function(_, typ, d, ch) if typ == "LFG" and ch == "GROUP" then sentGroup = sentGroup + 1 end end },
			{ ns, "Later", function(_, fn) fn() end },
		}, function()
			before = #Sync.netQueue
			for _ = 1, 5 do
				G.lastGroupSend = nil                 -- jede Änderung zählt (sonst sperrt die 30-s-Pause)
				Outside(function() G:OnGroupChange() end)
			end
			before = #Sync.netQueue - before
		end)
		return (before == 0 and sentGroup == 5) and true or false, string.format("Netz %d, Gruppe %d", before, sentGroup), "Netz 0, Gruppe 5"
	end)
end

function R:AreaJ()
	local So = ns.Social
	Check("T150", "J", "P1: Tooltip mit geschütztem Namen", function()
		Flavor("forever")
		local e0 = ErrMark()
		local ok = pcall(ns.Tooltip.Add, ns.Tooltip, { AddLine = function() end, Show = function() end }, Bait())
		Flavor(nil)
		return (ok and ErrMark() == e0) and true or false, S(ok), "kein Fehler"
	end)
	Check("T151", "J", "P2: ns.Proper Vor- und Nachname", function()
		Flavor("forever")
		local a, b = ns.Proper("testa beispiel"), ns.Proper("Testa Beispiel-WoWForever")
		Flavor(nil)
		return (a == "Testa Beispiel" and b == "Testa Beispiel") and true or false, S(a) .. "|" .. S(b), "Testa Beispiel"
	end)
	Check("T152", "J", "P2: Notiz mit zwei Wörtern", function()
		Flavor("forever")
		local r = MiniRoster({ "Testa Beispiel", "Mira Sonnenkind", "Mira Dunkelfeder", "Kurztwink" }, function()
			local Ro = ns.Roster
			return { Ro:MainFromNote("Kurztwink", "Twink von Testa Beispiel"), Ro:MainFromNote("Kurztwink", "alt of testa beispiel"),
				Ro:MainFromNote("Kurztwink", "Main: Testa Beispiel"), Ro:MainFromNote("Kurztwink", "Twink von Testa"),
				Ro:MainFromNote("Kurztwink", "Twink von Mira"),
				-- Kennzeichnung in der Client-Sprache (koKR/zhCN/zhTW: Name davor), wie GuildSentinel sie schreibt
				Ro:MainFromNote("Kurztwink", string.format(L["Twink von %s"], "Testa Beispiel")) }
		end)
		Flavor(nil)
		local ok = r[1] == "Testa Beispiel" and r[2] == "Testa Beispiel" and r[3] == "Testa Beispiel" and r[4] == "Testa Beispiel" and r[5] == nil
			and r[6] == "Testa Beispiel"
		return ok, S(r[1]) .. "|" .. S(r[4]) .. "|" .. S(r[5]) .. "|" .. S(r[6]), "Testa Beispiel ×4, nil, Testa Beispiel"
	end)
	Check("T153", "J", "P2: ns.Same Vorname", function()
		Flavor("forever")
		local r = MiniRoster({ "Testa Beispiel", "Mira Sonnenkind", "Mira Dunkelfeder" }, function()
			return { ns.Same("Testa", "Testa Beispiel"), ns.Same("Mira", "Mira Sonnenkind"), ns.Same("Testa Beispiel", "Testa Felsbart") }
		end)
		Flavor("era")
		local e = ns.Same("Testa", "Testa Beispiel")
		Flavor(nil)
		return (r[1] == true and r[2] == false and r[3] == false and e == false) and true or false, S(r[1]) .. S(r[2]) .. S(r[3]) .. S(e), "true false false false"
	end)
	Check("T154", "J", "P2: Twink/Main, Danke, Pate mit Vor- und Nachname", function()
		Flavor("forever")
		local g = ns.guild
		-- unabhängig von den Einstellungen des Spielers (Funktion "Danke" aus?) und von schon vorhandenem Dank heute
		-- (Launch-Bericht 0.9.13: im echten Client kam kein Dank zustande); was GuildSentinel ausgibt, steht im Ergebnis
		local r = With({ { ns, "Feature", function() return true end }, { g, "thanks", {} }, { g, "alts", {} }, { g, "mentor", {} } }, function()
		return MiniRoster({ "Testa Beispiel", "Kurztwink", "Mira Sonnenkind" }, function()
			local out = {}
			out.said = Printed(function()
				ns.Roster:SetMain("Kurztwink", "testa", true)
				out.main = ns.Roster:MainOf("Kurztwink")
				local n0 = Count(g.thanks)
				So:Thank("testa beispiel", "x")
				for id, t in pairs(g.thanks) do
					if t.to == "Testa Beispiel" and t.why == "x" then out.thx = t.to; g.thanks[id] = nil end
				end
				out.n = Count(g.thanks) - n0
				So:SetMentor("Mira Sonnenkind", "Testa")
				out.mentor = So:MentorOf("Mira Sonnenkind")
			end)
			return out
		end)
		end)
		Flavor(nil)
		local ok = r.main == "Testa Beispiel" and r.thx == "Testa Beispiel" and r.mentor == "Testa Beispiel"
		local said = ok and "" or (" – " .. table.concat(r.said or {}, " / "))
		return ok and true or false, S(r.main) .. "|" .. S(r.thx) .. "|" .. S(r.mentor) .. said, "Testa Beispiel ×3"
	end)
	Check("T155", "J", "P3: Flüstern mit Leerzeichen", function()
		local a0, b0 = Recorded("ChatFrame_SendTell"), Recorded("ChatFrame_OpenChat")
		Outside(function() ns.OpenWhisper("Testa Beispiel", "Hallo"); ns.OpenWhisper("Testa", "Hallo") end)
		return (Recorded("ChatFrame_SendTell") == a0 + 1 and Recorded("ChatFrame_OpenChat") == b0 + 1) and true or false, "SendTell/OpenChat", "1/1"
	end)
	Skip("T156", "J", "P4a: Bewerber-Flüstern im Kampf", "wie T85")
	Skip("T157", "J", "P4b: Addon-Nachricht im Kampf", "wie T84")
	Skip("T158", "J", "P4c: Abklingzeit im Kampf", "wie T86")
	Check("T159", "J", "P5a: IsOfficer über C_GuildInfo", OfficerFallbacks)
	Skip("T160", "J", "P5b: KnowsSpell über C_SpellBook", "wie T98/T133")
	Check("T161", "J", "P6a: SendChatMessage-Rückfall", ChatFallback)
	Skip("T162", "J", "P6b: ChatFrame_RemoveChannel", "wie T101")
	Check("T163", "J", "GoldSentinelGame eingebaut", function()
		return (ns.Game.FOREVER == GoldSentinelGame.IsForever and ns.Proper("x") == GoldSentinelGame.CleanName("x")) and true or false, "gleich", "gleich"
	end)
	Skip("T164", "J", "Launch-Tag: Interface-Nummer", "wie T03")
	Check("T165", "J", "Ersatznamen der frühen Fassung", function()
		local G = GoldSentinelGame
		local ok = type(G.ProperName) == "function" and type(G.ShortName) == "function" and type(G.NormName) == "function"
			and pcall(G.SameName, "a", "b", function() return true end)
		return True(ok, "vorhanden")
	end)
	Check("T166", "J", "K1: CanViewOfficerNote allein", ViewOnlyNotOfficer)
	Client("T168", "J", "K2 im echten Kampf", "Mitspieler flüstert im Kampf 'gilde'; nach dem Kampf /gs testroutine whisperq und prüfen, ob Hinweis oder Bewerber erscheint")
	Check("T169", "J", "K3: Tooltip-Kampfsperre an MODERN", function()
		local function Lines(flavor)
			Flavor(flavor)
			local n = 0
			With({ { ns, "testCombat", true } }, function()
				local tip = { AddLine = function() n = n + 1 end, Show = function() end, GetUnit = function() return "Rokwar", "player" end }
				ns.Tooltip.OnUnit(tip)
			end)
			return n
		end
		local r = Lines("retail")
		local e = Lines("era")
		Flavor(nil)
		return (r == 0 and e > 0) and true or false, "retail " .. r .. ", era " .. e, "0, >0"
	end)
	Check("T170", "J", "K4: Absender exakt (AWAY/THX)", function()
		Flavor("forever")
		local r = MiniRoster({ "Testa Beispiel", ns.Me() }, function()
			local g = ns.guild
			g.away["Testa Beispiel"] = nil
			ns.Comm.TestDispatch("Testa", "AWAY\t" .. ns.Comm.Serialize({ n = "Testa Beispiel", e = { u = ns.Now() + 999, note = "", t = ns.Now(), by = "Testa" } }), "GUILD")
			local a = g.away["Testa Beispiel"]
			ns.Comm.TestDispatch("Testa Beispiel", "AWAY\t" .. ns.Comm.Serialize({ n = "Testa Beispiel", e = { u = ns.Now() + 999, note = "", t = ns.Now(), by = "Testa Beispiel" } }), "GUILD")
			local b = g.away["Testa Beispiel"]
			g.away["Testa Beispiel"] = nil
			return { a, b }
		end)
		Flavor(nil)
		return (r[1] == nil and r[2] ~= nil) and true or false, "Vorname " .. S(r[1] ~= nil) .. ", voll " .. S(r[2] ~= nil), "false, true"
	end)
	Skip("T171", "J", "K5: tools/luac5.1 -v", "Werkzeug im Repo (offline)")
	Skip("T172", "J", "RM2: Werkzeug nicht in der ZIP", "offline (unzip -l)")
	Skip("T173", "J", "N8: Offline-Test K2", "offline (test/run_forever95.lua)")
end

-- verzögerte Fälle (nach R.WAIT Sekunden): T67 und T167
function R:Deferred(stage)
	local Rc = ns.Recruit
	if stage == "plan" then
		R.d = {}
		if Want("B") then
			-- T67: Bewerber im Testmodus, sofort Testmodus beenden -> nach 7 s nichts gesendet
			R.d.r0 = Recorded("SendChatMessage") + Recorded("SendAddonMessage")
			ns.Test:Trigger("applicant")
			ns.Claim("gstest-later", function() ns.Chat("x", "GUILD") end, 0.1)
			ns.Test:Stop()
			ns.Test:Start()
		end
		if Want("J") then
			R.d.q0 = Rc.combatQueue
			Rc.combatQueue = { { Bait(), "A-Test", nil }, { "x", Bait(), nil }, { "gilde guild", "Wanderer55-Test", Bait() } }
			R.d.prints = {}
			Swap(ns, "Print", function(_, msg) R.d.prints[#R.d.prints + 1] = tostring(msg) end)
			R.d.swapMark = #swaps
			FireEvent("PLAYER_REGEN_ENABLED")
		end
		return
	end
	Check("T67", "B", "verzögerte Sendungen nach Stop (N3)", function()
		local n = Recorded("SendChatMessage") + Recorded("SendAddonMessage") - (R.d.r0 or 0)
		return Eq(n, 0)
	end)
	Check("T167", "J", "K2: Kampf-Flüstern bleibt geschützt", function()
		local app = ns.guild and ns.guild.apps.Wanderer55
		local hint = 0
		local want = string.format(L["%d Flüsternachricht(en) im Kampf nicht auswertbar – bitte den Chat prüfen."], 2)
		for _, p in ipairs(R.d.prints or {}) do if p:find(want, 1, true) then hint = hint + 1 end end
		Rc.combatQueue = R.d.q0 or {}
		return (app ~= nil and hint == 1) and true or false, "Bewerber " .. S(app ~= nil) .. ", Hinweise " .. hint, "true, 1"
	end)
end

------------------------------------------------------------
-- Gildenverwaltung (Admin.lua; anweisung-gildenverwaltung.txt Punkt 7). Rechte über ns.API nachgestellt, ausserhalb
-- des Testmodus (Outside) – die Aktionen schreibt ns.Act nur mit. Echte Daten (GuildSentinelDB.admin) bleiben unberührt.
------------------------------------------------------------
------------------------------------------------------------
-- Rekrutierung in Phasen (RaidReady.lua, 0.9.31): T261–T269 = T-RP1–T-RP9. Erfundene Testgilde (GSTest1 …),
-- Rollen, Aufstellung und Phase nur in Ersatz-Tabellen; nichts wird gesendet oder gespeichert.
------------------------------------------------------------
function R:RaidReadyCases()
	local RP, C = ns.RaidReady, ns.Comp
	-- Testgilde: spec = { { n, role = "tank"/"heal"/"dps", alt = true, days = Tage offline, level } }
	local function Box(spec, fn, extra)
		local names, roles, alts = {}, {}, {}
		for i, x in ipairs(spec) do names[i] = x.n end
		return MiniRoster(names, function()
			for _, x in ipairs(spec) do
				local e = ns.Roster.byName[x.n]
				e.level = x.level or 60
				if x.days then e.online, e.seen = false, ns.Now() - x.days * 86400 else e.online, e.seen = true, ns.Now() end
				roles[x.n] = x.role or "dps"
				alts[x.n] = x.alt or nil
			end
			local list = {
				{ C, "Role", function(_, n) return roles[n] or "dps" end },
				{ ns.Roster, "IsAlt", function(_, n) return alts[n] and true or false end },
				{ C, "Settings", function() return { min = 55, alts = false, want = {} } end },
				{ C, "Want", function() return 0 end },
				{ ns.G(), "recruitPhase", nil }, { ns.G(), "rpHist", nil }, { ns.G(), "compLog", {} },
				{ ns.Comm, "Send", function() end },
			}
			for _, x in ipairs(extra or {}) do list[#list + 1] = x end
			return With(list, fn)
		end)
	end
	local function Gen(n, tanks, heals, prefix)
		local out = {}
		for i = 1, n do out[i] = { n = (prefix or "GSTest") .. i, role = i <= tanks and "tank" or (i <= tanks + heals and "heal" or "dps") } end
		return out
	end
	local function Ser(t)
		local keys = {}
		for k in pairs(t) do keys[#keys + 1] = tostring(k) end
		table.sort(keys)
		local out = {}
		for _, k in ipairs(keys) do
			local v = t[k] == nil and t[tonumber(k)] or t[k]
			out[#out + 1] = k .. "=" .. (type(v) == "table" and ("{" .. Ser(v) .. "}") or tostring(v))
		end
		return table.concat(out, ",")
	end
	local R1 = RP.RAIDS[1]

	Check("T261", "B", "T-RP1: Phase Aufbau -> {gesucht} \"aller Klassen\", Vorgaben unverändert", function()
		local before = Ser(C:Settings())
		local w = RP:Wanted()
		RP:Measure(); RP:Suggestion()
		local after = Ser(C:Settings())
		return (RP:Phase() == "build" and w == L["Mitstreiter aller Klassen"] and before == after) and true or false,
			RP:Phase() .. ": " .. w .. (before == after and ", Vorgaben gleich" or ", Vorgaben verändert"), "build: " .. L["Mitstreiter aller Klassen"] .. ", Vorgaben gleich"
	end)
	Check("T262", "B", "T-RP2: Übergang mit fehlenden Rollen", function()
		local miss = function() return { { label = "Tanks" }, { label = "Heiler" }, { label = "Schamanen" }, { label = "Magier" } } end
		return Box({}, function()
			local w = RP:Wanted()
			local want = string.format(L["Mitstreiter aller Klassen, besonders %s"], C:WantedList(3))
			return (w == want and w:find("Schamanen", 1, true) and not w:find("Magier", 1, true)) and true or false, w, want
		end, { { RP, "Phase", function() return "trans" end }, { C, "Missing", miss } })
	end)
	Check("T263", "B", "T-RP3: Phase Raid wie bisher (Lücken der Aufstellung)", function()
		local miss = function() return { { label = "Tanks" }, { label = "Heiler" } } end
		return Box({}, function()
			local w = RP:Wanted()
			return w == C:WantedList(), w, C:WantedList()
		end, { { RP, "Phase", function() return "raid" end }, { C, "Missing", miss } })
	end)
	Check("T264", "B", "T-RP4: Erfüllungsgrad 59/60/100 %, Rollen-Mangel (nur Schurken) nicht raidfähig", function()
		local S = R1.size
		local t, h = RP:RoleTargets(S)
		local res = {}
		res[1] = Box(Gen(S, t, h), function() return RP:Measure(R1.key).pct end) == 100
		res[2] = Box(Gen(S, 0, 0), function() return RP:Measure(R1.key).pct end) == 0
		res[3] = Box(Gen(math.floor(S * 0.6 + 0.5), t, h), function() return RP:Measure(R1.key).pct end) == 60
		local function Sug(pct) return Box({}, function() return RP:Suggestion({ pct = pct }) end) end
		res[4] = Sug(59) == nil and Sug(60) == "trans" and Sug(100) == "raid"
		local f = {}
		for k = 1, 4 do f[k] = res[k] and "1" or "0" end
		return table.concat(f) == "1111", table.concat(f), "1111 (voll 100, nur Schaden 0, 60 %, Vorschlag ab 60/100)"
	end)
	Check("T265", "B", "T-RP5: nur Offiziere schalten um, Mitglied nicht", function()
		return Box({ { n = "GSTest1" }, { n = "GSTest2" } }, function()
			ns.Roster.byName.GSTest1.ri, ns.Roster.byName.GSTest2.ri = 1, 4
			local member = With({ { ns, "IsOfficer", function() return false end } }, function()
				local ok
				Printed(function() ok = RP:Set("raid") end)
				return ok == false and RP:Phase() == "build"
			end)
			local officer = With({ { ns, "IsOfficer", function() return true end } }, function() return RP:Set("trans") and RP:Phase() == "trans" end)
			local recv = With({ { ns, "IsOfficer", function() return false end } }, function()
				return RP.SenderIsOfficer("GSTest1") and not RP.SenderIsOfficer("GSTest2")
			end)
			return (member and officer and recv) and true or false, string.format("Mitglied gesperrt %s, Offizier %s, Empfang %s", S(member), S(officer), S(recv)),
				"Mitglied gesperrt true, Offizier true, Empfang true"
		end)
	end)
	Check("T266", "B", "T-RP6: zurück erst nach 7 Tagen unter der Schwelle (6 Tage -> nichts)", function()
		local today = math.floor(ns.Now() / 86400)
		local function Run(days)
			local h = { raid = R1.key, d = {}, n = {} }
			h.d[today - days - 1] = 100
			for d = today - days, today do h.d[d] = 90 end
			return Box({}, function()
				ns.G().recruitPhase = { p = "raid", raid = R1.key, t = 0 }
				ns.G().rpHist = h
				return RP:Suggestion({ pct = 90 })
			end)
		end
		local six, seven = Run(6), Run(7)
		return (six == nil and seven == "trans") and true or false, string.format("6 Tage %s, 7 Tage %s", tostring(six), tostring(seven)), "6 Tage nil, 7 Tage trans"
	end)
	Check("T267", "B", "T-RP7: Ziel-Raids 10/20/25/40 – Grösse und Rollen-Soll", function()
		local bad = {}
		for _, r in ipairs(RP.RAIDS) do
			local m = Box({}, function() return RP:Measure(r.key) end)
			local t, h = Box({}, function() return RP:RoleTargets(r.size) end)
			if m.size ~= r.size or t ~= math.max(1, math.ceil(r.size / 10)) or h ~= math.max(1, math.ceil(r.size / 5)) then bad[#bad + 1] = r.key end
		end
		local sizes = {}
		for _, r in ipairs(RP.RAIDS) do sizes[r.size] = true end
		local ok = #bad == 0 and sizes[10] and (sizes[20] or sizes[25]) and (sizes[40] or sizes[25])
		return ok and true or false, #bad == 0 and (#RP.RAIDS .. " Raids stimmen") or table.concat(bad, ", "), #RP.RAIDS .. " Raids stimmen"
	end)
	Check("T268", "B", "T-RP8: Inaktive (> 14 Tage) und Twinks zählen nicht", function()
		local spec = { { n = "GSTest1" }, { n = "GSTest2", days = 20 }, { n = "GSTest3", alt = true }, { n = "GSTest4", level = 30 }, { n = "GSTest5", days = 13 } }
		local a = Box(spec, function() return RP:Measure(R1.key).active end)
		return a == 2, tostring(a) .. " aktiv", "2 aktiv (online + 13 Tage)"
	end)
	Check("T288", "B", "T-RP-V: raidReady.vorschlag – offen gesetzt, bestätigt/Später fehlt", function()
		local S_ = R1.size
		local t, h = RP:RoleTargets(S_)
		local res = Box(Gen(S_, t, h), function()
			local r = {}
			r[1] = RP:Summary().vorschlag                                   -- 100 % im Aufbau -> "raid"
			With({ { ns.db, "rpLater", { ["raid:" .. RP:State().raid] = ns.Now() } } }, function() r[2] = RP:Summary().vorschlag end)
			With({ { ns, "IsOfficer", function() return true end } }, function() RP:Set("raid") end)
			r[3] = RP:Summary().vorschlag                                   -- bestätigt: Phase raid, kein Vorschlag
			return string.format("%s/%s/%s", tostring(r[1]), tostring(r[2]), tostring(r[3]))
		end)
		return res == "raid/nil/nil", res, "raid/nil/nil (offen, Später, bestätigt)"
	end)
	Check("T269", "B", "T-RP9: raidReady ohne Namen, alle Sprachen ohne Platzhalter-Fehler", function()
		local spec = Gen(5, 1, 1, "Testa Beispiel")
		local sum = Box(spec, function() return RP:Summary() end)
		local leak = false
		for k, v in pairs(sum) do
			if type(v) == "string" and (v:find("Testa", 1, true) or v:find("GSTest", 1, true)) then leak = true end
			if type(v) == "table" then leak = true end
		end
		local keys = { "raid", "phase", "aktiv", "groesse", "tanks", "tanksSoll", "heiler", "heilerSoll", "pct", "t" }
		local missing = {}
		for _, k in ipairs(keys) do if sum[k] == nil then missing[#missing + 1] = k end end
		-- Übersetzungen: gleiche Platzhalter wie Deutsch
		local fmtBad = {}
		for _, k in ipairs({ "Mitstreiter aller Klassen, besonders %s", "Raidfähig (%s): %d von %d aktiv auf Stufe %d+ · Tanks %d/%d · Heiler %d/%d · Phase %s", "beim jetzigen Tempo in ~%d Wochen", "Gilde ist raidfähig (%s)" }) do
			local de = select(2, k:gsub("%%[sd]", ""))
			local tr = L[k]
			if select(2, tr:gsub("%%[sd]", "")) ~= de then fmtBad[#fmtBad + 1] = k end
		end
		local ok = not leak and #missing == 0 and #fmtBad == 0
		return ok and true or false, (leak and "Name enthalten" or "ohne Namen") .. (#missing > 0 and (", fehlt " .. table.concat(missing, ",")) or "") .. (#fmtBad > 0 and (", Platzhalter " .. fmtBad[1]) or ""), "ohne Namen"
	end)
end

------------------------------------------------------------
-- Umfassende Tests (anweisung-tests-umfassend.txt, 0.9.32): TU1 Lagen-Katalog, TU2 Abläufe, TU3 Standardwerte,
-- TU4 Grundregeln mit Zufallsdaten, TU5 echte Daten (nur lesen), TU6 Regressionen, TU8 Testbericht je Bereich.
-- Alles mit erfundenen Namen (GSTest…, Testa Beispiel …), Rechte und Gilde über ns.API/Ersatz-Tabellen; geschützte
-- Gilden-Funktionen sind ersetzt und zählen als FEHLER, wenn sie direkt aufgerufen werden.
------------------------------------------------------------
R.TU = {}
local function TUCount(area, ok)
	local t = R.TU[area] or { ok = 0, bad = 0, skip = 0 }
	R.TU[area] = t
	if ok == nil then t.skip = t.skip + 1 elseif ok then t.ok = t.ok + 1 else t.bad = t.bad + 1 end
end

-- Regressionen (TU6): jeder Befund seit dem 1.11. -> bleibender Test (Nummern der Testroutine) oder Offline-Lauf
R.REGRESS = {
	{ "GV1", { "T253" } }, { "DP1", { "T252" } }, { "DP2", { "T251" } },
	{ "RV1", { "T254" } }, { "RV2", { "T254" } }, { "RV3", { "T213", "T255", "T256" } }, { "RV4", { "T257" } }, { "RV5", { "T258" } },
	{ "RV6", { "T259" } }, { "RV7", { "T280" } }, { "RV8", { "T260" } }, { "RV9", { "T255" } },
	{ "RP1", { "T261" } }, { "RP2", { "T262" } }, { "RP3", { "T263" } }, { "RP4", { "T264" } }, { "RP5", { "T265" } },
	{ "RP6", { "T266" } }, { "RP7", { "T267" } }, { "RP8", { "T268" } }, { "RP9", { "T269" } },
	{ "WT1", { "T244" } }, { "WT2", { "T245" } }, { "WT3", { "T246" } }, { "WT4", { "T247" } },
	{ "W1", { "T244" } }, { "W2", { "T244" } }, { "W3", { "T248" } }, { "W4", { "T245" } }, { "W5", { "T247" } }, { "W6", { "T246" } },
	{ "W7", { "T248", "T249" } },
	{ "S1", { "T201" } }, { "S2", { "T202" } }, { "S3", { "T203" } }, { "S4", { "T204" } }, { "S5", { "T205" } }, { "S6", { "T206" } }, { "S7", { "T207" } },
	{ "B1", { "T208" } }, { "B2", { "T210" } }, { "B3", { "T211", "T212" } },
	{ "V1", { "T201" } }, { "V2", { "T202", "T151" } }, { "V3", { "T203" } }, { "V4", { "T203" } },
	{ "A1", { "T205", "T241" } }, { "A2", { "T216" } }, { "A3", { "T206" } }, { "A4", { "T207" } },
	{ "SY1", { "T217" } }, { "SY2", { "T218" } }, { "SY3", { "T219" } },
	{ "GS1", { "T217" } }, { "GS2", { "T220" } }, { "GS3", { "T220" } }, { "GS4", { "T221" } }, { "GS5", { "T222" } },
	{ "N1", { "T225" } }, { "N2", { "T226" } }, { "N3", { "T227", "T67" } }, { "N4", { "T228" } }, { "N5", { "T88", "T89" } },
	{ "N6", { "T91" } }, { "N7", { "T132" } },
	{ "GT1", { "T229" } }, { "GT2", { "T230" } },
	{ "RM1", { "T231" } }, { "RM2", { "T232" } }, { "RM3", { "T233" } }, { "RM4", { "T234" } }, { "RM5", { "T235" } }, { "RM6", { "T236" } },
	{ "R1", { "T237" } }, { "R2", { "T237" } }, { "R3", { "T234" } }, { "R4", { "T235" } }, { "R7", { "T237" } },
	{ "K1", { "T166", "T114" } }, { "K2", { "T167" } }, { "K3", { "T169" } }, { "K4", { "T170" } },
	{ "P1", { "T150" } }, { "P2", { "T151", "T152", "T153", "T154" } }, { "P3", { "T155" } }, { "P5", { "T159" } }, { "P6", { "T161" } },
	{ "TU1", { "T270" } }, { "TU2", { "T271" } }, { "TU3", { "T272" } }, { "TU4", { "T273a" } }, { "TU5", { "T275" } }, { "TU6", { "T276" } },
	{ "TU8", { "T279" } }, { "GA1", { "T281" } }, { "RP-V", { "T288" } },
	{ "MN1", { "T291" } }, { "MN2", { "T292" } }, { "MN3", { "T291" } }, { "MN4", { "T291", "T292", "T293" } }, { "GA1-Sperre", { "T289f" } },
	{ "GA1-Alter", { "T289a", "T289b", "T289c", "T289d", "T289e" } }, { "GA2", { "T290a", "T290b", "T290c" } },
	{ "BL1", { "T282" } }, { "BL2", { "T283" } }, { "BL3", { "T284", "T285" } }, { "BL4", { "T282", "T283", "T284", "T285", "T286", "T287" } },
}

function R:TUCases()
	local A, Ad, GA, Rc, RPx = ns.API, ns.Admin, ns.GuildAct, ns.Recruit, ns.RaidReady
	local CommSend = ns.Comm.Send          -- echtes Senden (in den Lagen sonst ersetzt) für die Funktion "Sync"
	local Sync = _G.GoldSentinelSync
	-- geschützte Gilden-Funktionen: jeder direkte Aufruf wird gezählt (TU4/TU9)
	local forbidden = {}
	local function Guards()
		local list = {}
		for _, k in ipairs({ "GuildInvite", "GuildUninvite", "GuildPromote", "GuildDemote", "GuildSetLeader" }) do
			local f = function() forbidden[#forbidden + 1] = k end
			list[#list + 1] = { A, k, f }
			list[#list + 1] = { A, "C_" .. k, f }
		end
		return list
	end
	local function RightsList(r, myRi)
		return {
			{ A, "IsInGuild", function() return r.guild ~= false end },
			{ A, "IsGuildLeader", function() return r.leader or false end },
			{ A, "CanGuildInvite", function() return r.invite or false end },
			{ A, "CanGuildPromote", function() return r.promote or false end },
			{ A, "CanGuildDemote", function() return r.demote or false end },
			{ A, "CanGuildRemove", function() return r.remove or false end },
			{ A, "C_CanEditOfficerNote", function() return r.officer or false end },
			{ A, "CanEditOfficerNote", function() return r.officer or false end },
			{ GuildSentinelDB, "admin", {} },
			{ Ad, "NumRanks", function() return 6 end },
			{ ns.G(), "apps", {} }, { ns.G(), "rankLog", {} }, { ns.G(), "recruitPhase", nil }, { ns.G(), "rpHist", nil },
			{ ns, "GuildRoster", function() end },
			{ ns.Comm, "Send", function() end },
		}
	end
	local RIGHTS = {
		none = {}, officer = { invite = true, promote = true, demote = true, remove = true, officer = true },
		gm = { leader = true, invite = true, promote = true, demote = true, remove = true, officer = true },
	}
	local MYRI = { none = 4, officer = 1, gm = 0 }
	local function Names(n, kind)
		local out = {}
		if kind == "space" then
			local first = { "Testa", "Mira", "Testa", "Mira" }
			local last = { "Beispiel", "Sonnenkind", "Sonnenkind", "Beispiel" }
			for k = 1, n do out[k] = first[(k - 1) % 4 + 1] .. " " .. last[(k - 1) % 4 + 1] .. (k > 4 and tostring(k) or "") end
		else
			for k = 1, n do out[k] = "GSTest" .. k end
		end
		return out
	end
	-- Lage aufbauen: n Mitglieder, eigener Rang nach Rechten, Ränge verteilt, einige offline
	local function Lage(L_, fn)
		local names = Names(L_.n, L_.kind)
		names[#names + 1] = Me()
		return MiniRoster(names, function()
			for k, n in ipairs(names) do
				local e = ns.Roster.byName[n]
				e.ri = 1 + (k % 5)
				e.level = 10 + (k * 7) % 51
				e.online = (k % (L_.offline and 9 or 2)) == 0
				e.seen = ns.Now() - (k % 30) * 86400
				e.index = k
			end
			ns.Roster.byName[Me()].ri = MYRI[L_.rights]
			local list = RightsList(RIGHTS[L_.rights])
			for _, x in ipairs(Guards()) do list[#list + 1] = x end
			if L_.noGuild then list[#list + 1] = { ns, "InGuild", function() return false end } end
			-- Kanal verweigert Addon-Nachrichten: der gemeinsame Sender meldet "nicht erlaubt"
			if Sync and Sync.api then list[#list + 1] = { Sync.api, "send", function() return not L_.deny end } end
			-- Gilde gewechselt: frische, leere Gildendaten (wie nach einem Gildenwechsel)
			if L_.newGuild then
				local g = {}
				for k, v in pairs(ns.guildDefaults) do g[k] = type(v) == "table" and {} or v end
				list[#list + 1] = { ns, "guild", g }
			end
			return With(list, function() return Outside(function() return fn(names) end) end)
		end)
	end

	-- TU1: jede Lage durch alle betroffenen Funktionen
	local LAGEN = {
		{ id = "1 Mitglied, ohne Rechte", n = 1, rights = "none" },
		{ id = "50, Offizier", n = 50, rights = "officer" },
		{ id = "500, Gildenmeister", n = 500, rights = "gm" },
		{ id = "50 viele offline, Offizier", n = 50, rights = "officer", offline = true },
		{ id = "Vor- und Nachname, gleiche Vornamen, GM", n = 12, rights = "gm", kind = "space" },
		{ id = "keine Gilde", n = 0, rights = "none", noGuild = true },
		{ id = "Kanal verweigert Addon-Nachrichten, Offizier", n = 20, rights = "officer", deny = true },
		{ id = "Mitspieler mit alter Version, GM", n = 20, rights = "gm", old = true },
		{ id = "Gilde gewechselt, Offizier", n = 20, rights = "officer", newGuild = true },
	}
	local FUNCS = {
		{ "Werbung", function(names)
			local t = Rc:AdText()
			return type(t) == "string" and t ~= "" and not t:find("{", 1, true) and not t:find("|", 1, true) and #t <= Rc.AD_MAX
		end },
		{ "Bewerber einladen", function(names)
			local n = names[1] or "Testa Beispiel"
			ns.G().apps[n] = { st = "new", t = ns.Now() }
			Printed(function() Rc:Invite(n) end)
			return ns.G().apps[n].st == "new"
		end },
		{ "Verwaltung", function(names)
			local e = ns.Roster.byName[names[1] or ""]
			if not e then return true end
			for _, f in ipairs({ Ad.Promote, Ad.Demote, Ad.Remove }) do Printed(function() f(e) end); GA:Cancel() end
			return true
		end },
		{ "Mitglieder-Menü", function(names)
			local Mp = ns.MembersPage
			for k = 1, math.min(5, #names) do Mp.MenuItems(names[k]); Mp.RankItems(names[k]) end
			return true
		end },
		{ "Mitgliederliste", function() ns.Roster:Stats(); ns.Roster:Inactive(14); ns.Roster:Filtered({}) return true end },
		{ "Beförderung", function() ns.Promote:Candidates(); ns.Bulk:KickCandidates(30, 3, true); ns.Bulk:PromoteCandidates() return true end },
		{ "Aufstellung/Raidfähigkeit", function()
			ns.Comp:Table()
			local m = RPx:Measure()
			return m.pct >= 0 and m.pct <= 100 and RPx:ProgressText(m) ~= ""
		end },
		{ "Berufe", function() if ns.Craft and ns.Craft.WantedText then ns.Craft:WantedText() end return true end },
		{ "Gruppensuche", function() ns.Group:Mine(); ns.Group:MyRole(); ns.Group:MyZone() return true end },
		{ "Termine", function() ns.Events:OpenCount(); ns.Events:SyncData() return true end },
		{ "Umfragen", function() ns.Poll:List(); ns.Poll:OpenUnvoted(); ns.Poll:SyncData() return true end },
		{ "Sync", function(names, lg)
			-- senden (die Warteschlange danach leeren) und empfangen; alte Version schickt alte Nachrichtenformen
			local before = {}
			for _, q in ipairs(Sync and Sync.queue or {}) do before[q] = true end
			local ok = pcall(CommSend, ns.Comm, "PING", { t = 1 }, "GUILD")
			if Sync then for i = #Sync.queue, 1, -1 do if not before[Sync.queue[i]] then table.remove(Sync.queue, i) end end end
			local from = names[1] or "GSTest1"
			if lg.old then
				ns.Comm.TestDispatch(from, "VER\t" .. ns.Comm.Serialize({ v = "0.8.0" }), "GUILD")
				ns.Comm.TestDispatch(from, "LFG\t" .. ns.Comm.Serialize({ id = "GSTestAlt" }), "GUILD")
			end
			ns.Comm.TestDispatch(from, "GSTESTUNBEKANNT\t" .. ns.Comm.Serialize({}), "GUILD")
			return ok
		end },
	}
	Check("T270", "B", "TU1: Lagen-Katalog – jede Lage durch alle Funktionen (Tabelle Lage x Funktion)", function()
		local bad, cells = {}, 0
		for _, lg in ipairs(LAGEN) do
			local f0, r0 = #forbidden + ProtCount(), R.real
			Lage(lg, function(names)
				for _, f in ipairs(FUNCS) do
					cells = cells + 1
					local ok, res = pcall(f[2], names, lg)
					local good = ok and res ~= false
					TUCount("TU1", good)
					if not good then bad[#bad + 1] = lg.id .. " / " .. f[1] .. (ok and "" or (": " .. tostring(res):sub(1, 80))) end
				end
			end)
			if #forbidden + ProtCount() > f0 or R.real > r0 then bad[#bad + 1] = lg.id .. ": geschützt/echt " .. (#forbidden + ProtCount() - f0) .. "/" .. (R.real - r0) end
		end
		-- geheime Namen im Kampf (Forever): nur im echten Client erzeugbar, eigene Tests T150/T91
		TUCount("TU1", nil)
		return #bad == 0, #bad == 0 and string.format("%d Zellen OK (%d Lagen x %d Funktionen)", cells, #LAGEN, #FUNCS) or bad[1],
			string.format("%d Zellen OK", #LAGEN * #FUNCS)
	end)

	-- TU2: Abläufe wie ein Spieler (Antworten verzögert, Abbruch, /reload)
	Check("T271", "B", "TU2: Abläufe – Bewerber, Verwaltung mit/ohne Antwort, /reload mittendrin, Werbung ohne Kanal", function()
		local steps = {}
		local function ok(name, v) steps[#steps + 1] = (v and "1" or "0"); TUCount("TU2", v and true or false); if not v then steps.bad = steps.bad or name end end
		Lage({ n = 6, rights = "gm" }, function(names)
			local n = names[2]
			-- Bewerber: anlegen -> einladen -> keine Meldung -> Meldung -> entfernen
			ns.G().apps[n] = { st = "new", t = ns.Now() }
			Printed(function() Rc:Invite(n) end)
			ok("Einladen ohne Meldung", ns.G().apps[n].st == "new")
			Rc.OnInviteConfirmed(n)
			ok("Meldung -> eingeladen", ns.G().apps[n].st == "invited")
			Rc:Remove(n)
			ok("entfernt", ns.G().apps[n] == nil)
			-- Verwaltung: Klick, keine Antwort, Wiederholen, Antwort
			local e = ns.Roster.byName[names[3]]
			e.ri = 4
			Printed(function() Ad.Promote(e) end)
			GA.PostClick(GA.frame.btn)
			GA:TimedOut()
			ok("ohne Antwort nicht erledigt", GA.queue.done == 0 and GA.queue.failed == 1)
			GA.PostClick(GA.frame.btn)
			e.ri = 3
			GA:CheckRoster()
			ok("Gildenliste bestätigt", GA.queue.done == 1)
			GA:Cancel()
			-- /reload mitten drin: Schritt wartet, Warteschlange weg, die Meldung kommt später -> nichts passiert
			Printed(function() Ad.Promote(e) end)
			GA.PostClick(GA.frame.btn)
			GA.queue, GA.pending = nil, nil
			local log0 = #ns.G().rankLog
			local okc = pcall(GA.OnSystem, type(ERR_GUILD_PROMOTE_SSS) == "string" and string.format(ERR_GUILD_PROMOTE_SSS, Me(), e.name, "X") or "x")
			ok("/reload: keine Folgen", okc and #ns.G().rankLog == log0)
			GA:Cancel()
			-- Werbung ohne Kanal
			local said
			With({ { Rc, "Targets", function() return {} end }, { Rc, "GlobalWait", function() return 0 end } }, function()
				said = Printed(function() steps.post = Rc:Post() end)
			end)
			ok("Werbung ohne Kanal: Hinweis, nichts gesendet", steps.post == false and AnyHas(said, L["Kein Kanal gewählt oder keinem gewählten Kanal beigetreten. Wähle die Kanäle auf der Seite Rekrutierung."]))
		end)
		local f = table.concat(steps)
		return not f:find("0"), f .. (steps.bad and (" (" .. steps.bad .. ")") or ""), ("1"):rep(#steps)
	end)

	-- TU3: Standardwerte – jedes Feld leer bzw. ab Werk
	Check("T272", "B", "TU3: Standardwerte – leere Felder ergeben, was der Spieler meint", function()
		local fields, bad = {}, {}
		local function F(name, good) fields[#fields + 1] = name; TUCount("TU3", good and true or false); if not good then bad[#bad + 1] = name end end
		local list = { { ns.db, "adText", nil }, { ns.db, "discord", nil }, { ns.db, "discordTag", nil }, { ns.db, "replyText", nil },
			{ ns.db, "welcomeText", nil }, { ns.db, "questions", nil }, { ns.db, "keywords", nil }, { ns.db, "uiLang", nil },
			{ ns.db, "features", {} }, { ns.G(), "recruitPhase", nil } }
		With(list, function()
			local ad = Rc:AdText()
			F("Werbetext (Standard, ohne {}/Discord)", ad ~= "" and not ad:find("{", 1, true) and not ad:find("Discord", 1, true))
			local ad2 = With({ { ns.db, "adText", Rc:Suggestion2() } }, function() return Rc:AdText() end)
			F("Server-Tag leer: kein Tag-Satz (Vorschlag 2)", not ad2:find("{tag}", 1, true) and not ad2:find("  ", 1, true))
			F("Intervall", type(ns.db.adInterval) == "number" and ns.db.adInterval > 0)
			local rp = Rc.ReplyPreview and Rc:ReplyPreview() or ""
			F("Antwort auf Bewerbung", type(rp) == "string" and rp ~= "" and not rp:find("{", 1, true))
			local wp = Rc.WelcomePreview and Rc:WelcomePreview() or ""
			F("Begrüssung", type(wp) == "string" and wp ~= "" and not wp:find("{", 1, true))
			F("Funktionen ab Werk an", ns.Feature("recruit") and ns.Feature("thanks") ~= false)
			F("Rekrutierungsphase Aufbau", RPx:Phase() == "build")
			F("Sprache folgt dem Client", ns.ClientLang() ~= nil)
		end)
		return #bad == 0, #bad == 0 and (#fields .. " Felder: " .. table.concat(fields, ", ")) or ("falsch: " .. table.concat(bad, ", ")), #fields .. " Felder"
	end)

	-- TU4: Grundregeln mit Zufallsdaten (fester Startwert, 10 Portionen à 100 Fälle)
	local SEED = 4711
	local rnd = SEED
	local function Rand(n) rnd = (rnd * 1103515245 + 12345) % 2147483648; return 1 + math.floor(rnd / 2147483648 * n) end
	local ACTIONS = { "invite", "promote", "demote", "remove", "setrank", "leader", "menu", "multi", "ad" }
	local function OneCase(case)
		local rightsKey = ({ "none", "officer", "gm" })[Rand(3)]
		local n = Rand(20)
		local kind = Rand(2) == 1 and "space" or nil
		local act = ACTIONS[Rand(#ACTIONS)]
		local viol
		local f0, r0 = #forbidden + ProtCount(), R.real
		Lage({ n = n, rights = rightsKey, kind = kind }, function(names)
			local target = names[Rand(#names)]
			local e = ns.Roster.byName[target]
			local my = ns.Roster.byName[Me()].ri
			ns.G().apps[target] = { st = "new", t = ns.Now() }
			local ok, err = pcall(function()
				Printed(function()
					if act == "invite" then Rc:Invite(target)
					elseif act == "promote" then Ad.Promote(e)
					elseif act == "demote" then Ad.Demote(e)
					elseif act == "remove" then Ad.Remove(e)
					elseif act == "setrank" then GA:SetRank(target, Rand(7) - 1)
					elseif act == "leader" then Ad.unlocked = Rand(2) == 1; Ad.SetLeader(e)
					elseif act == "menu" then ns.MembersPage.MenuItems(target)
					elseif act == "multi" then GA:Run("promote", ns.MembersPage.MultiNames("promote"))
					else Rc:AdText() end
				end)
			end)
			Ad.unlocked = false
			if not ok then viol = "Lua: " .. tostring(err):sub(1, 60) end
			-- Schritte des sicheren Knopfs: nie über den eigenen Rang, nie Rang 0, nie unter den untersten
			for _, st in ipairs(GA.queue and GA.queue.steps or {}) do
				if st.kind == "promote" and (not st.to or st.to <= my or st.to < 1) then viol = viol or "Beförderung über den eigenen Rang" end
				if st.kind == "demote" and (not st.to or st.to > Ad.NumRanks() - 1) then viol = viol or "unter den untersten Rang" end
			end
			if ns.G().apps[target] and ns.G().apps[target].st ~= "new" then viol = viol or "Status ohne Bestätigung" end
			local ad = Rc:AdText()
			if ad:find("|", 1, true) then viol = viol or "Werbung mit |" end
			GA:Cancel()
		end)
		if #forbidden + ProtCount() > f0 then viol = viol or ("geschützte Funktion direkt: " .. (forbidden[#forbidden] or "über ns.Act")) end
		if R.real > r0 then viol = viol or "echte Aktion" end
		TUCount("TU4", viol == nil)
		return viol and string.format("Fall %d (Startwert %d): %s, Rechte %s, %d Mitglieder, %s", case, SEED, act, rightsKey, n, viol) or nil
	end
	for part = 1, 10 do
		local id = "T273" .. string.char(96 + part)
		Check(id, "B", string.format("TU4: Grundregeln mit Zufallsdaten, Portion %d/10 (Startwert %d)", part, SEED), function()
			local t0 = debugprofilestop and debugprofilestop() or 0
			local first
			for k = 1, 100 do
				local v = OneCase((part - 1) * 100 + k)
				first = first or v
			end
			local ms = (debugprofilestop and debugprofilestop() or 0) - t0
			return first == nil, first or string.format("100 Fälle OK (%.0f ms)", ms), "100 Fälle OK"
		end)
	end

	-- TU5: echte Gildendaten nur lesen; Verletzungen ins Protokoll (ohne Namen)
	Check("T275", "B", "TU5: echte Daten (nur lesen) – Bewerber, Twinks, Rang-Verlauf", function()
		local v = {}
		local function add(k) v[k] = (v[k] or 0) + 1 end
		local snap
		Outside(function()
			local g = ns.G()
			local seen = {}
			for name, a in pairs(g.apps or {}) do
				if type(a) ~= "table" then add("Bewerber ohne Daten")
				else
					local key = type(name) == "string" and name:lower() or "?"
					if seen[key] then add("Bewerber doppelt") end
					seen[key] = true
					if a.st == "invited" and type(a.ti) ~= "number" then add("eingeladen ohne Zeit") end
				end
			end
			for alt, main in pairs(g.alts or {}) do
				local m = type(main) == "table" and main.m or main
				if type(m) == "string" and ns.Same(m, alt) then add("Twink ist sein eigener Main") end
			end
			for _, x in ipairs(g.rankLog or {}) do if type(x) ~= "table" or not x.k or not x.t then add("Rang-Verlauf unvollständig") end end
			snap = true
		end)
		local parts = {}
		for k, n in pairs(v) do parts[#parts + 1] = k .. " " .. n; if ns.Diag then ns.Diag("GRUNDREGEL", "VERLETZT " .. k .. " " .. n) end end
		table.sort(parts)
		TUCount("TU5", #parts == 0)
		return snap and #parts == 0, #parts == 0 and "0 Verletzungen" or table.concat(parts, ", "), "0 Verletzungen"
	end)

	-- T-GA1 (Nachprüfung 0.9.32, Punkt 1): nur die Phase zählt, in der Blizzard den Makro-Text ausführt
	Check("T281", "B", "T-GA1: sicherer Knopf handelt nur in der Ausführungsphase (Aktion bei Tastendruck an/aus)", function()
		local res = {}
		for _, execDown in ipairs({ true, false }) do
			Lage({ n = 3, rights = "gm" }, function(names)
				With({ { GA, "ExecDown", function() return execDown end } }, function()
					local e = ns.Roster.byName[names[1]]
					e.ri = 4
					Printed(function() Ad.Promote(e) end)
					local b = GA.frame.btn
					GA.PreClick(b, "LeftButton", not execDown)
					GA.PostClick(b, "LeftButton", not execDown)
					local wrong = GA.pending == nil
					GA.PreClick(b, "LeftButton", execDown)
					local typ = b:GetAttribute("type")
					GA.PostClick(b, "LeftButton", execDown)
					local right = GA.pending ~= nil and typ == "macro"
					-- zweiter Klick derselben Phase während des Wartens führt nichts aus
					GA.PreClick(b, "LeftButton", execDown)
					local blocked = b:GetAttribute("type") == nil
					res[#res + 1] = (wrong and right and blocked) and "1" or "0"
					GA:Cancel()
				end)
			end)
		end
		local f = table.concat(res)
		return f == "11", f, "11 (Tastendruck an, aus)"
	end)

	-- BL (0.9.34): Befehlsliste beim Tippen (CmdHint.lua), Befehle aus ns.COMMANDS (Core.lua)
	local H = ns.CmdHint
	local function HintCfg(german, dev)
		return { { H, "commands", ns.COMMANDS }, { H, "german", function() return german end }, { H, "dev", function() return dev end },
			{ H, "store", function() return {} end }, { H, "selected", nil }, { H, "prefixes", { "/guildsentinel", "/gs" } } }
	end
	local function Keys(list)
		local out = {}
		for _, it in ipairs(list) do out[#out + 1] = it.key end
		table.sort(out)
		return table.concat(out, ",")
	end
	Check("T282", "B", "T-BL1: jeder Befehl, den der Handler versteht, steht in der Liste (aus derselben Tabelle)", function()
		local bad = {}
		local words = 0
		for _, c in ipairs(ns.COMMANDS) do
			for _, w in ipairs({ c[1]:match("^%S+"), c[2]:match("^%S+"), unpack(c.aliases or {}) }) do
				words = words + 1
				if ns.FindCommand(w) ~= c then bad[#bad + 1] = w end
			end
			if type(c.run) ~= "function" or type(c[3]) ~= "string" then bad[#bad + 1] = c[1] .. " ohne run/Text" end
		end
		local listed = With(HintCfg(true, true), function() return #H:List("") end)
		-- Wörter des früheren Handlers bleiben verstanden (alte Gewohnheiten der Spieler)
		for _, w in ipairs({ "berufe", "prof", "suche", "find", "gruppe", "group", "lfg", "fortschritt", "progress", "rennen", "zugang",
			"attune", "termine", "events", "termin", "brett", "board", "wo", "where", "danke", "thanks", "weg", "away", "umfrage", "poll",
			"regeln", "rules", "werbung", "ad", "spenden", "donate", "support", "test", "testroutine", "verwaltung", "admin", "sync",
			"protokoll", "log", "diag", "debug" }) do
			if not ns.FindCommand(w) then bad[#bad + 1] = "alt: " .. w end
		end
		local ok = #bad == 0 and listed == #ns.COMMANDS
		return ok, string.format("%d Befehle, %d Wörter, Liste %d", #ns.COMMANDS, words, listed) .. (#bad > 0 and (" – " .. table.concat(bad, ", ")) or ""),
			string.format("%d Befehle, Liste %d", #ns.COMMANDS, #ns.COMMANDS)
	end)
	Check("T283", "B", "T-BL2: Filter \"/gs w\" und \"/gs we\" liefern genau die passenden, meistbenutzte oben", function()
		return With(HintCfg(true, false), function()
			local w = Keys(H:List("w"))
			local we = Keys(H:List("we"))
			local all = #H:List("")
			local rest = H:Match("/gs we")
			local st = { werbung = 0, weg = 5 }
			local top = With({ { H, "store", function() return st end } }, function() return H:List("we")[1].key end)
			local ok = w == "weg,werbung,wo" and we == "weg,werbung" and rest == "we" and top == "weg" and all == #ns.COMMANDS - 2
			return ok, string.format("w: %s | we: %s | oben: %s | alle %d", w, we, tostring(top), all), "w: weg,werbung,wo | we: weg,werbung | oben: weg"
		end)
	end)
	Check("T284", "B", "T-BL3: Klick wählt aus, Enter führt den gewählten Befehl aus; alte Auswahl (> 10 s) gilt nicht", function()
		return With(HintCfg(true, false), function()
			local items = H:List("we")
			local werbung
			for _, it in ipairs(items) do if it.key == "werbung" then werbung = it end end
			H:Select(werbung, true)
			local r1 = H:Resolve("we")
			H:Select(werbung, true)
			H.selected.t = H.selected.t - 11
			local r2 = H:Resolve("we")
			H:Select(werbung, true)
			local r3 = H:Resolve("wo")                    -- anderer Anfang -> getippter Text gilt
			H:Hide()
			local ok = r1 == "werbung" and r2 == "we" and r3 == "wo"
			return ok, string.format("%s / %s / %s", tostring(r1), tostring(r2), tostring(r3)), "werbung / we / wo"
		end)
	end)
	Check("T285", "B", "T-BL4: Chatfeld wird nie beschrieben (nur HookScript lesen, SetFocus)", function()
		local writes, focus = 0, 0
		local box = { h = {}, text = "/gs we", shown = true }
		function box:HookScript(ev, fn) self.h[ev] = fn end
		function box:GetText() return self.text end
		function box:SetText() writes = writes + 1 end
		function box:Insert() writes = writes + 1 end
		function box:SetScript() writes = writes + 1 end
		function box:SetFocus() focus = focus + 1 end
		function box:IsShown() return self.shown end
		function box:GetWidth() return 400 end
		return With(HintCfg(true, false), function()
			return With({ { H, "hooked", {} }, { H, "editBox", nil }, { H, "lastBox", nil }, { ns.db, "cmdHint", true } }, function()
				H:HookBox(box)
				if box.h.OnTextChanged then box.h.OnTextChanged(box) end
				local shown = H.frame and H.frame:IsShown()
				if box.h.OnTabPressed then box.h.OnTabPressed(box) end
				if H.items and H.items[1] then H:Select(H.items[1], true) end
				box.shown = false
				if box.h.OnHide then box.h.OnHide(box) end
				H:Hide()
				local ok = writes == 0 and shown and focus >= 1
				return ok and true or false, string.format("geschrieben %d, Liste %s, Fokus %d", writes, S(shown), focus), "geschrieben 0, Liste true, Fokus >= 1"
			end)
		end)
	end)
	Check("T286", "B", "T-BL5: Entwickler-Befehle nur für den Entwickler", function()
		local no = With(HintCfg(true, false), function() return Keys(H:List("t")) end)
		local yes = With(HintCfg(true, true), function() return Keys(H:List("t")) end)
		-- "danke" passt über das englische Wort "thanks"
		local ok = no == "danke,termine" and yes == "danke,termine,test,testroutine"
		return ok, "ohne: " .. no .. " | mit: " .. yes, "ohne: danke,termine | mit: danke,termine,test,testroutine"
	end)
	Check("T287", "B", "T-BL6: alle Sprachen – Beschreibungen vorhanden, Platzhalter gleich", function()
		local bad = {}
		for _, c in ipairs(ns.COMMANDS) do
			for lang, t in pairs(ns.T or {}) do
				if type(t) == "table" and lang ~= "de" and t[c[3]] == nil then bad[#bad + 1] = lang .. ": " .. c[3] end
			end
		end
		for lang, t in pairs(ns.T or {}) do
			local e = type(t) == "table" and t["Enter = %s"]
			if e and select(2, e:gsub("%%s", "")) ~= 1 then bad[#bad + 1] = lang .. ": Enter = %s" end
		end
		return #bad == 0, #bad == 0 and (#ns.COMMANDS .. " Beschreibungen in allen geladenen Sprachen") or bad[1], #ns.COMMANDS .. " Beschreibungen in allen geladenen Sprachen"
	end)

	-- GA (0.9.36): Altersfrage (GA1) und Werbetext je Phase (GA2)
	local function AgeRun(age, minAge, fn)
		local sent = {}
		return Lage({ n = 2, rights = "gm" }, function()
			local list = { { ns.db, "minAge", minAge }, { ns.db, "askQuestions", true }, { ns.db, "questions", nil },
				{ ns, "Later", function(_, f) f() end }, { ns, "Chat", function(t) sent[#sent + 1] = t end } }
			return With(list, function()
				local name = "Testa Beispiel"
				ns.G().apps[name] = { t = ns.Now(), st = "new" }
				Printed(function()
					Rc:StartQuestions(name, name, 0)
					local qs = Rc:Questions()
					for k = 1, #qs do
						local ans = (qs.age and k == qs.age) and age or ("GSTest Antwort " .. k)
						Rc:TakeAnswer(name, ans, name)
					end
				end)
				return fn(ns.G().apps[name], sent, Rc:Questions())
			end)
		end)
	end
	Check("T289a", "B", "T-GA1a: Alter 17 -> weiter (Ergebnis 16+)", function()
		return AgeRun("ich bin 17", 16, function(a)
			return (a.age == "ok" and a.st == "new" and a.qdone ~= nil) and true or false, tostring(a.age) .. "/" .. tostring(a.st), "ok/new"
		end)
	end)
	Check("T289b", "B", "T-GA1b: Alter 15 -> nette Absage, Status abgelehnt (Alter), Einladen gesperrt", function()
		return AgeRun("15", 16, function(a, sent)
			local last = sent[#sent] or ""
			local inv
			Printed(function() inv = Rc:Invite("Testa Beispiel") end)
			local ok = a.age == "young" and a.st == "agedecl" and last:find("16", 1, true) and inv == false
			-- ohne den Absage-Text selbst (enthält den Gildennamen)
			return ok and true or false, tostring(a.st) .. " | " .. (last:find("16", 1, true) and "Absage mit 16" or "keine Absage"), "agedecl | Absage mit 16"
		end)
	end)
	Check("T289c", "B", "T-GA1c: \"bald 16\" -> unklar, keine automatische Absage", function()
		return AgeRun("bald 16", 16, function(a)
			return (a.age == "unclear" and a.st == "new") and true or false, tostring(a.age) .. "/" .. tostring(a.st), "unclear/new"
		end)
	end)
	Check("T289d", "B", "T-GA1d: Mindestalter 0 -> keine Altersfrage", function()
		return AgeRun("15", 0, function(a, _, qs)
			return (qs.age == nil and a.age == nil and a.st == "new") and true or false, "Fragen " .. #qs .. ", Alter " .. tostring(a.age), "keine Altersfrage"
		end)
	end)
	Check("T289f", "B", "T-GA1f: Gildenverwaltung > Einladen umgeht die Alters-Sperre nicht", function()
		return AgeRun("15", 16, function(a)
			local o0 = Recorded("ChatFrame_OpenChat")
			local r1, r2
			Printed(function() r1 = Ad.Invite("Testa Beispiel"); r2 = Ad.Invite("testa beispiel") end)
			local ok = a.st == "agedecl" and r1 == false and r2 == false and Recorded("ChatFrame_OpenChat") == o0
			return ok and true or false, string.format("%s, Einladen %s/%s", tostring(a.st), tostring(r1), tostring(r2)), "agedecl, Einladen false/false"
		end)
	end)
	Check("T289e", "B", "T-GA1e: genaues Alter nirgends gespeichert", function()
		local function Has(t, needle, depth)
			if (depth or 0) > 6 then return false end
			for k, v in pairs(t) do
				if (type(v) == "string" and v:find(needle, 1, true)) or (type(k) == "string" and k:find(needle, 1, true)) then return true end
				if type(v) == "table" and Has(v, needle, (depth or 0) + 1) then return true end
			end
			return false
		end
		local bad = AgeRun("ich bin 37 Jahre", 16, function(a) return Has(a, "37") end)
		return not bad, bad and "37 gespeichert" or "nur Ergebnis gespeichert", "nur Ergebnis gespeichert"
	end)
	local function AdPhase(phase, adText, fn)
		local miss = function() return { { label = "Heiler" }, { label = "Krieger" } } end
		return With({ { RPx, "Phase", function() return phase end }, { ns.db, "adText", adText }, { ns.db, "discord", "" },
			{ ns.Comp, "Missing", miss } }, fn)
	end
	Check("T290a", "B", "T-GA2a: Phase Aufbau, Standardtext -> \"im Aufbau … aller Klassen\"", function()
		return AdPhase("build", nil, function()
			local t = Rc:AdText()
			local want = Rc:Build(Rc:DefaultAd("build"))
			local ok = t == want and t:find(L["Mitstreiter aller Klassen"], 1, true) and Rc:DefaultAd("build") ~= Rc:DefaultAd("raid")
			-- ohne den Text selbst (enthält den eigenen Namen)
			return ok and true or false, ok and "Standardtext Aufbau, alle Klassen" or "anderer Text", "Standardtext Aufbau, alle Klassen"
		end)
	end)
	Check("T290b", "B", "T-GA2b: eigener Text ohne {gesucht}/{phase} -> Hinweis", function()
		local a = AdPhase("build", "GSTest eigener Text {gilde}", function() return Rc:OwnAdWithoutWanted() end)
		local b = AdPhase("build", "GSTest eigener Text {gesucht}", function() return Rc:OwnAdWithoutWanted() end)
		local c = AdPhase("build", "GSTest {phase} eigener Text", function() return Rc:OwnAdWithoutWanted() end)
		local d = AdPhase("build", nil, function() return Rc:OwnAdWithoutWanted() end)
		local f = (a and "1" or "0") .. (b and "1" or "0") .. (c and "1" or "0") .. (d and "1" or "0")
		return f == "1000", f, "1000 (ohne -> Hinweis; mit {gesucht}/{phase}/Standard -> keiner)"
	end)
	Check("T290c", "B", "T-GA2c: Phase Raid -> gezielte Klassen", function()
		return AdPhase("raid", nil, function()
			local t = Rc:AdText()
			local ok = t:find("Heiler", 1, true) and t:find("Krieger", 1, true) and not t:find(L["Mitstreiter aller Klassen"], 1, true)
			return ok and true or false, ok and "gezielt: Heiler, Krieger" or "nicht gezielt", "gezielt: Heiler, Krieger"
		end)
	end)

	-- MN4 (0.9.37): Marktdaten-Netz – geladen, Schalter aus = kein Lesen/Senden, ohne Auktionshaus-Schnittstelle kein Fehler
	local GM = _G.GoldSentinelMarkt
	Check("T291", "B", "MN4: GoldSentinelMarkt geladen und mit GuildSentinel verbunden (MN1/MN3)", function()
		if not GM then return false, "Datei nicht geladen", "geladen" end
		local lines = GM.DiagLines and GM.DiagLines() or {}
		local ok = GM.hosts and GM.hosts.GuildSentinel == GuildSentinelDB and type(lines[1]) == "string" and lines[1]:find("MARKT-NETZ", 1, true)
		return ok and true or false, ok and ("v" .. tostring(GM.VERSION) .. ", " .. (GM.IsShareOn() and "an" or "aus")) or "nicht verbunden", "v1, verbunden"
	end)
	Check("T292", "B", "MN4: Schalter aus -> kein Lesen, kein Senden", function()
		if not GM then return nil, "Datei nicht geladen" end
		local sent = 0
		return With({ { GuildSentinelDB, "gsMarktAus", true }, { GM, "lastEv", nil }, { GM, "readAt", nil }, { GM, "askAt", 0 },
			{ GM, "ep", { Send = function() sent = sent + 1 end } }, { GM.api, "ah", function() return nil end } }, function()
			local off = not GM.IsShareOn()
			GM.OnReplicate()
			local noRead = GM.readAt == nil
			pcall(GM.Tick)
			local ok = off and noRead and sent == 0
			return ok and true or false, string.format("aus %s, Lesen %s, gesendet %d", S(off), noRead and "nein" or "ja", sent), "aus true, Lesen nein, gesendet 0"
		end)
	end)
	Check("T293", "B", "MN4: ohne Auktionshaus-Schnittstelle (Era/TBC) kein Lua-Fehler", function()
		if not GM then return nil, "Datei nicht geladen" end
		return With({ { GM.api, "ah", function() return nil end }, { GM, "lastEv", nil }, { GM, "readAt", nil }, { GM, "reader", nil },
			{ GM, "askAt", nil }, { GM, "answerAt", nil } }, function()
			local ok1 = pcall(GM.OnReplicate)
			GM.readAt = 0
			local ok2 = pcall(GM.Tick)
			local ok3 = pcall(GM.Get, 2589)
			local ok = ok1 and ok2 and ok3 and GM.reader == nil
			return ok and true or false, ok and "kein Fehler" or "Fehler", "kein Fehler"
		end)
	end)

	Check("T280", "B", "T-RV7: Rangrechte nur anzeigen, Knopf öffnet das Rang-Fenster des Spiels", function()
		local UI = ns.UI
		local Le = UI.pages and UI.pages[UI:PageIndex("lead")]
		local has = Le and type(Le.OpenRankEditor) == "function"
		return has and true or false, has and "Knopf vorhanden" or "fehlt", "Knopf vorhanden"
	end)
end

-- TU6/TU8: am Ende der Routine (nach allen Bereichen)
function R:TUReport()
	-- nur bei einem vollständigen Lauf (Bereich B mit den TU-Fällen); "testroutine i" allein prüft das nicht
	if not Want("B") then return end
	local ran = R.ranIds or {}
	Check("T276", "I", "TU6: Regressionen – jeder Befund seit 1.11. hat einen bleibenden Test", function()
		local have, missing = 0, {}
		for _, x in ipairs(R.REGRESS) do
			local any = false
			for _, t in ipairs(x[2]) do if ran[t] ~= nil or t == "T276" or t == "T279" then any = true end end
			if any then have = have + 1 else missing[#missing + 1] = x[1] end
			TUCount("TU6", any)
		end
		return #missing == 0, string.format("Regressionen: %d von %d vorhanden", have, #R.REGRESS) .. (#missing > 0 and (" – fehlt: " .. table.concat(missing, ", ")) or ""),
			string.format("Regressionen: %d von %d vorhanden", #R.REGRESS, #R.REGRESS)
	end)
	Check("T279", "I", "TU8: Testbericht je Bereich", function()
		local lines = {}
		for _, a in ipairs({ "TU1", "TU2", "TU3", "TU4", "TU5", "TU6" }) do
			local t = R.TU[a] or { ok = 0, bad = 0, skip = 0 }
			lines[#lines + 1] = string.format("%s OK %d · FEHLER %d · SKIP %d", a, t.ok, t.bad, t.skip)
		end
		lines[#lines + 1] = "TU7 3 Clients x 5 Sprachen (offline), Skalierung T184"
		local bad = 0
		for _, a in ipairs({ "TU1", "TU2", "TU3", "TU4", "TU5", "TU6" }) do bad = bad + ((R.TU[a] or {}).bad or 0) + (((R.TU[a] or {}).ok or 0) == 0 and 1 or 0) end
		return bad == 0, table.concat(lines, " | "), "alle Bereiche ohne FEHLER und nicht nur SKIP"
	end)
end

function R:AdminCases()
	local Ad, A = ns.Admin, ns.API
	local function Rights(r)
		return {
			{ A, "IsInGuild", function() return true end },
			{ A, "IsGuildLeader", function() return r.leader or false end },
			{ A, "CanGuildInvite", function() return r.invite or false end },
			{ A, "CanGuildPromote", function() return r.promote or false end },
			{ A, "CanGuildDemote", function() return r.demote or false end },
			{ A, "CanGuildRemove", function() return r.remove or false end },
			{ A, "C_CanEditOfficerNote", function() return false end },
			{ A, "CanEditOfficerNote", function() return false end },
			{ GuildSentinelDB, "admin", {} },
			{ ns, "guildKey", ns.guildKey or "Testrealm|Testgilde" },
		}
	end
	local ALL = { leader = true, invite = true, promote = true, demote = true, remove = true }
	-- Testmitglieder: ich Rang 0, ein Mitglied Rang 3 (5 Ränge)
	local me = Me()
	local function Members(fn)
		return MiniRoster({ me, "Verwaltungstest", "Rangtest" }, function()
			ns.Roster.byName[me].ri = 0
			-- zweitniedrigster Rang der echten Gilde (mindestens 2): befördern, degradieren und entfernen sind erlaubt
			ns.Roster.byName.Verwaltungstest.ri, ns.Roster.byName.Verwaltungstest.rank = math.max(2, Ad.NumRanks() - 2), "Mitglied"
			ns.Roster.byName.Rangtest.ri, ns.Roster.byName.Rangtest.rank = 1, "Offizier"
			return fn(ns.Roster.byName.Verwaltungstest)
		end)
	end
	Check("T192", "B", "Verwaltung: mit Rechten offen, Knöpfe nach Recht", function()
		return With(Rights({ promote = true }), function()
			return Outside(function()
				return Members(function(e)
					local open = Ad.CanOpen()
					local a = Ad.Allowed(e)
					local ok = open and a.promote and not a.demote and not a.remove and not a.leader
					return ok and true or false, "offen " .. S(open) .. ", befördern " .. S(a.promote) .. ", entfernen " .. S(a.remove), "offen, nur Befördern"
				end)
			end)
		end)
	end)
	Check("T193", "B", "Verwaltung: ohne Rechte gesperrt", function()
		return With(Rights({}), function()
			return Outside(function()
				local said = Printed(function() Ad:Open() end)
				local shown = Ad.frame and Ad.frame:IsShown()
				return (not Ad.CanOpen() and not shown and AnyHas(said, L["Nur für Gildenleitung und Offiziere."])) and true or false,
					"offen " .. S(Ad.CanOpen()) .. ", Hinweis " .. S(AnyHas(said, L["Nur für Gildenleitung und Offiziere."])), "gesperrt, Hinweis"
			end)
		end)
	end)
	Check("T194", "B", "Verwaltung: Einladen/Befördern/Degradieren/Rauswerfen mit richtigem Namen mitgeschrieben", function()
		local real0 = R.real
		return With(Rights(ALL), function()
			return Outside(function()
				return Members(function(e)
					local got = {}
					-- GV1: Einladen nie direkt, sondern "/ginvite Neuling" in die Chat-Eingabe
					local gi0 = Recorded("GuildInvite")
					Printed(function() Ad.Invite("Neuling") end)
					got[#got + 1] = (R.recLast.ChatFrame_OpenChat or ""):match("^/%S+ Neuling$") ~= nil and Recorded("GuildInvite") == gi0
					-- RV3: Befördern/Degradieren/Entfernen nie direkt, sondern ein Schritt für den sicheren Knopf
					local prot0 = Recorded("GuildPromote") + Recorded("GuildDemote") + Recorded("GuildUninvite")
					for _, k in ipairs({ { Ad.Promote, "promote" }, { Ad.Demote, "demote" }, { Ad.Remove, "remove" } }) do
						k[1](e)
						local st = ns.GuildAct:Current()
						got[#got + 1] = st ~= nil and st.kind == k[2] and st.name == e.name and ns.GuildAct.lastMacro == ns.GuildAct.Macro(k[2], e.name)
						ns.GuildAct:Cancel()
					end
					got[#got] = got[#got] and (Recorded("GuildPromote") + Recorded("GuildDemote") + Recorded("GuildUninvite")) == prot0
					-- nicht über den eigenen Rang: Offizier (Rang 1) nicht weiter befördern als bis unter mich
					Ad.Promote(ns.Roster.byName.Rangtest)
					got[#got + 1] = ns.GuildAct:Current() == nil
					ns.GuildAct:Cancel()
					-- im Kampf nichts
					With({ { ns, "testCombat", true } }, function() Printed(function() Ad.Remove(e) end) end)
					got[#got + 1] = ns.GuildAct:Current() == nil
					ns.GuildAct:Cancel()
					local n = 0
					for _, x in ipairs(got) do if x then n = n + 1 end end
					local flags = {}
					for i, x in ipairs(got) do flags[i] = x and "1" or "0" end
					return (n == #got and R.real == real0) and true or false, n .. "/" .. #got .. " (" .. table.concat(flags) .. "), echt " .. (R.real - real0), #got .. "/" .. #got .. ", echt 0"
				end)
			end)
		end)
	end)
	Check("T195", "B", "Verwaltung: Leitung übergeben nur mit Passwort", function()
		return With(Rights(ALL), function()
			return Outside(function()
				return Members(function(e)
					local r = {}
					Ad.unlocked = false
					local n0 = Recorded("GuildSetLeader")
					Printed(function() Ad.SetLeader(e) end)
					r[1] = ns.GuildAct:Current() == nil                              -- ohne Passwort gesperrt
					ns.GuildAct:Cancel()
					r[2] = Ad.SetPassword(nil, "Probe1234", "Probe1234") == true
					r[3] = Ad.CheckPassword("falsch") == false and not Ad.unlocked  -- falsch
					Ad.unlocked = Ad.CheckPassword("Probe1234") == true            -- richtig
					r[4] = Ad.unlocked
					Ad.SetLeader(e)
					local st = ns.GuildAct:Current()
					r[5] = st ~= nil and st.kind == "leader" and st.name == e.name and Recorded("GuildSetLeader") == n0
					ns.GuildAct:Cancel()
					r[6] = not Ad.unlocked                                          -- danach wieder gesperrt
					local n = 0
					for _, x in ipairs(r) do if x then n = n + 1 end end
					return n == #r, n .. "/" .. #r, #r .. "/" .. #r
				end)
			end)
		end)
	end)

	-- RV (0.9.30): Rechtsklick-Menü und sichere Gilden-Aktionen. T254–T260 = T-RV1–T-RV6, T-RV8
	local GA = ns.GuildAct
	local function Off(items, v)
		for _, it in ipairs(items) do if it.value == v then return it.off ~= nil end end
		return nil
	end
	Check("T254", "B", "T-RV1: Rechtsklick-Menü zeigt genau die Einträge der eigenen Rechte (Mitglied, Offizier, Gildenmeister)", function()
		local Mp = ns.MembersPage
		local res = {}
		local function Case(rights, myRi)
			return With(Rights(rights), function()
				return Outside(function()
					return Members(function(e)
						ns.Roster.byName[me].ri = myRi
						local items = Mp.MenuItems(e.name)
						local leader = Off(items, "leader")
						return string.format("%s%s%s%s%s", Off(items, "promote") and "-" or "+", Off(items, "demote") and "-" or "+",
							Off(items, "setrank") and "-" or "+", Off(items, "remove") and "-" or "+", leader == nil and "x" or (leader and "-" or "+"))
					end)
				end)
			end)
		end
		res[1] = Case({}, 4)
		res[2] = Case({ promote = true, demote = true, remove = true }, 1)
		res[3] = Case(ALL, 0)
		local got = table.concat(res, " ")
		return got == "----x ++++x +++++", got, "----x ++++x +++++ (Mitglied, Offizier, Gildenmeister: Befördern, Degradieren, Rang, Entfernen, Leitung)"
	end)
	Check("T255", "B", "T-RV2: kein geschützter Gilden-Aufruf direkt aus Addon-Code (Einladen, Befördern, Degradieren, Entfernen, Leitung)", function()
		local A = ns.API
		local forbidden = {}
		local list = {}
		for _, k in ipairs({ "GuildInvite", "GuildUninvite", "GuildPromote", "GuildDemote", "GuildSetLeader" }) do
			local f = function() forbidden[#forbidden + 1] = k end
			list[#list + 1] = { A, k, f }
			list[#list + 1] = { A, "C_" .. k, f }
		end
		local real0, prot0 = R.real, ProtCount()
		With(Rights(ALL), function()
			With(list, function()
				Outside(function()
					Members(function(e)
						Printed(function()
							Ad.Invite("Testa Beispiel"); ns.Recruit:Invite("Testa Beispiel")
							Ad.Promote(e); GA:Cancel(); Ad.Demote(e); GA:Cancel(); Ad.Remove(e); GA:Cancel()
							Ad.unlocked = true; Ad.SetLeader(e); GA:Cancel(); Ad.unlocked = false
							With({ { ns, "CanPromote", Yes }, { ns.Bulk, "CanKick", Yes } }, function()
								ns.Promote:Promote(e.name); GA:Cancel()
								ns.Bulk:Start("kick", { e.name }); GA:Cancel()
								ns.Bulk:Start("promote", { e.name }); GA:Cancel()
							end)
							GA:SetRank(e.name, 1); GA:Cancel()
						end)
					end)
				end)
			end)
		end)
		local n = #forbidden + ProtCount() - prot0
		return (n == 0 and R.real == real0) and true or false, n == 0 and "0 direkte Aufrufe" or (n .. " direkt: " .. table.concat(forbidden, ", ")), "0 direkte Aufrufe"
	end)
	Check("T256", "B", "T-RV3: Makro-Text mit Vor- und Nachname, kein Zeilenumbruch", function()
		local a = GA.Macro("promote", "Testa Beispiel") or ""
		local b = GA.Macro("remove", "Mira\n/gleader Sonnenkind") or ""
		local c = GA.Macro("leader", "") == nil
		local ok = a:match("^/%S+ Testa Beispiel$") ~= nil and not b:find("\n", 1, true) and c
		return ok and true or false, a .. " | " .. b, "/gpromote Testa Beispiel | ohne Zeilenumbruch"
	end)
	Check("T257", "B", "T-RV4: Rang setzen über 3 Stufen = 3 Klicks, nie über den eigenen Rang", function()
		return With(Rights(ALL), function()
			return Outside(function()
				return Members(function(e)
					return With({ { Ad, "NumRanks", function() return 6 end } }, function()
						local res = {}
						e.ri = 4
						local st = GA.RankSteps(e.name, 1)
						res[1] = st and #st == 3 and st[1].from == 4 and st[3].to == 1 and st[2].kind == "promote"
						-- je Klick genau ein Schritt
						GA:Start(st, 1)
						local seen = {}
						for k = 1, 3 do seen[k] = GA:Current() and GA:Current().from; GA:Confirmed(true) end
						res[2] = seen[1] == 4 and seen[2] == 3 and seen[3] == 2 and GA:Current() == nil and GA.queue.done == 3
						GA:Cancel()
						-- eigener Rang 1: Ziel 1 und 0 verboten, Ziel 2 erlaubt
						ns.Roster.byName[me].ri = 1
						res[3] = GA.RankSteps(e.name, 1) == nil and GA.RankSteps(e.name, 0) == nil and #(GA.RankSteps(e.name, 2) or {}) == 2
						-- degradieren 2 -> 5 = 3 Schritte, unter den untersten Rang nicht
						e.ri = 2
						res[4] = #(GA.RankSteps(e.name, 5) or {}) == 3 and GA.RankSteps(e.name, 6) == nil
						local f = {}
						for k = 1, 4 do f[k] = res[k] and "1" or "0" end
						return table.concat(f) == "1111", table.concat(f), "1111"
					end)
				end)
			end)
		end)
	end)
	Check("T258", "B", "T-RV5: \"befördert\" erst nach Bestätigung des Spiels, ohne Bestätigung \"nicht ausgeführt\"", function()
		if type(ERR_GUILD_PROMOTE_SSS) ~= "string" then return nil, "ERR_GUILD_PROMOTE_SSS fehlt" end
		return With(Rights(ALL), function()
			return Outside(function()
				return Members(function(e)
					return With({ { ns.G(), "rankLog", {} }, { ns, "GuildRoster", function() end } }, function()
						local res = {}
						Ad.Promote(e)
						GA.PostClick(GA.frame.btn)                      -- Klick: das Spiel führt den Befehl aus
						res[1] = GA.pending ~= nil and GA.queue.done == 0 and not GA:CheckRoster()
						GA:TimedOut()                                    -- keine Antwort des Spiels
						res[2] = GA.queue.done == 0 and GA.queue.failed == 1 and GA:Current() ~= nil
						GA.PostClick(GA.frame.btn)                      -- wiederholen
						GA.OnSystem(string.format(ERR_GUILD_PROMOTE_SSS, me, e.name, "Veteran"))
						res[3] = GA.queue.done == 1 and GA.pending == nil and #ns.G().rankLog == 1 and ns.G().rankLog[1].n == e.name
						GA:Cancel()
						local f = {}
						for k = 1, 3 do f[k] = res[k] and "1" or "0" end
						return table.concat(f) == "111", table.concat(f), "111 (wartet, nicht ausgeführt, nach Meldung erledigt)"
					end)
				end)
			end)
		end)
	end)
	Check("T259", "B", "T-RV6: Twink bekommt den Rang des Mains nur vorgeschlagen", function()
		return With(Rights(ALL), function()
			return Outside(function()
				return MiniRoster({ me, "Maintest", "Twinktest" }, function()
					ns.Roster.byName[me].ri = 0
					ns.Roster.byName.Maintest.ri, ns.Roster.byName.Maintest.rank = 2, "Veteran"
					ns.Roster.byName.Twinktest.ri, ns.Roster.byName.Twinktest.rank = 4, "Rekrut"
					local list = { { ns.Roster, "MainOf", function(_, n) return n == "Twinktest" and "Maintest" or nil end },
						{ ns, "CanPromote", Yes }, { ns.db, "altRank", nil }, { Ad, "NumRanks", function() return 6 end } }
					return With(list, function()
						local off = #ns.Promote:AltCandidates()
						ns.db.altRank = true
						local c = ns.Promote:AltCandidates()
						local rank0 = ns.Roster.byName.Twinktest.ri
						Printed(function() ns.Promote:Apply(c[1]) end)
						local steps = GA.queue and #GA.queue.steps or 0
						GA:Cancel()
						local ok = off == 0 and #c == 1 and c[1].target == 2 and steps == 2 and ns.Roster.byName.Twinktest.ri == rank0
						return ok and true or false, string.format("aus %d, an %d, Schritte %d", off, #c, steps), "aus 0, an 1, Schritte 2"
					end)
				end)
			end)
		end)
	end)
	Check("T260", "B", "T-RV8: Mehrfachauswahl – je Mitglied ein Klick; im Kampf grau", function()
		local Mp = ns.MembersPage
		return With(Rights(ALL), function()
			return Outside(function()
				return MiniRoster({ me, "Testa Beispiel", "Mira Sonnenkind", "Rangtest" }, function()
					ns.Roster.byName[me].ri = 0
					return With({ { Mp, "multi", { ["Testa Beispiel"] = true, ["Mira Sonnenkind"] = true, Rangtest = true } }, { Ad, "NumRanks", function() return 6 end } }, function()
						local names = Mp.MultiNames("promote")
						GA:Run("promote", names)
						local n = #GA.queue.steps
						GA:Confirmed(true)
						local after1 = GA.queue.done
						local cur = GA:Current() and GA:Current().name
						GA:Cancel()
						local combat = With({ { ns, "testCombat", true } }, function() return Off(Mp.MenuItems("Rangtest"), "promote") end)
						local ok = #names == 3 and n == 3 and after1 == 1 and cur == names[2] and combat
						return ok and true or false, string.format("%d ausgewählt, %d Schritte, nach 1 Klick %d erledigt, Kampf grau %s", #names, n, after1, S(combat)),
							"3 ausgewählt, 3 Schritte, nach 1 Klick 1 erledigt, Kampf grau true"
					end)
				end)
			end)
		end)
	end)
	Check("T196", "B", "Verwaltung: 3 Fehlversuche -> 5 Minuten Sperre", function()
		return With(Rights(ALL), function()
			return Outside(function()
				Ad.SetPassword(nil, "Probe1234", "Probe1234")
				for _ = 1, 3 do Ad.CheckPassword("falsch") end
				local locked = Ad.LockedFor()
				local evenRight = Ad.CheckPassword("Probe1234")
				local now = ns.Now()
				local free = With({ { ns, "Now", function() return now + 301 end } }, function() return Ad.CheckPassword("Probe1234") end)
				return (locked and locked > 250 and evenRight == false and free == true) and true or false,
					"Sperre " .. S(locked and math.floor(locked)) .. " s, richtig während Sperre " .. S(evenRight) .. ", danach " .. S(free), "~300 s, false, true"
			end)
		end)
	end)
	Check("T197", "B", "Verwaltung: Passwort nur als Prüfsumme", function()
		return With(Rights(ALL), function()
			return Outside(function()
				Ad.SetPassword(nil, "Geheim987", "Geheim987")
				local d = Ad.Data()
				local plain = false
				local function scan(t, depth)
					if depth > 4 then return end
					for k, v in pairs(t) do
						if v == "Geheim987" or k == "Geheim987" then plain = true end
						if type(v) == "table" then scan(v, depth + 1) end
					end
				end
				scan(GuildSentinelDB, 0)
				local ok = d.pw and type(d.pw.h) == "string" and #d.pw.h == 16 and type(d.pw.s) == "string" and not plain
				return ok and true or false, "Prüfsumme " .. S(d.pw and #d.pw.h) .. " Zeichen, Klartext " .. S(plain), "16, false"
			end)
		end)
	end)
	Check("T198", "B", "Verwaltung: keine Namen im Protokoll und Export", function()
		local box = { entries = {}, sessions = {} }
		return With(Rights(ALL), function()
			return With({ { ns, "diagForce", true }, { GuildSentinelDB, "diag", box } }, function()
				return Outside(function()
					return Members(function(e)
						Ad.Data().access["Zugriffstest"] = true
						Ad.Invite("Neuling"); Ad.Remove(e)
						local text = ns.DiagText() .. ns.DiagExport()
						local leak = text:find("Neuling", 1, true) or text:find(e.name, 1, true) or text:find("Zugriffstest", 1, true)
						return (not leak and #box.entries > 0) and true or false, #box.entries .. " Einträge, Namen " .. (leak and "DRIN" or "keine"), "keine Namen"
					end)
				end)
			end)
		end)
	end)
	Check("T200", "B", "Verwaltung: alter Client ohne C_GuildInfo nimmt die alte Funktion", function()
		local old, new = function() end, function() end
		local got = {}
		for _, x in ipairs({ { "Invite", "GuildInvite" }, { "Promote", "GuildPromote" }, { "Demote", "GuildDemote" },
				{ "Uninvite", "GuildUninvite" }, { "SetLeader", "GuildSetLeader" } }) do
			local a = With({ { A, "C_" .. x[2], nil }, { A, x[2], old } }, function() return Ad.Fn(x[1], x[2]) end)
			local b = With({ { A, "C_" .. x[2], new }, { A, x[2], old } }, function() return Ad.Fn(x[1], x[2]) end)
			got[#got + 1] = (a == old and b == new) and "1" or "0"
		end
		local s = table.concat(got)
		return s == "11111", s, "11111 (ohne C_: alt, mit C_: modern)"
	end)
	Check("T213", "B", "Befördern (Aktivität) und Sammelaktion: nie direkt, nur über den sicheren Knopf (RV3)", function()
		local GA = ns.GuildAct
		local got = {}
		local p0 = Recorded("GuildPromote") + Recorded("GuildUninvite") + Recorded("C_GuildPromote") + Recorded("C_GuildUninvite")
		local function Step(fn, kind)
			Outside(function() Printed(fn) end)
			local st = GA:Current()
			local ok = st ~= nil and st.kind == kind and st.name == "GSTestName"
			GA:Cancel()
			return ok
		end
		With({ { ns, "CanPromote", function() return true end }, { ns.Bulk, "CanKick", function() return true end } }, function()
			got[#got + 1] = Step(function() ns.Promote:Promote("GSTestName") end, "promote")
			got[#got + 1] = Step(function() ns.Bulk:Start("kick", { "GSTestName" }) end, "remove")
			got[#got + 1] = Step(function() ns.Bulk:Start("promote", { "GSTestName" }) end, "promote")
		end)
		got[#got + 1] = (Recorded("GuildPromote") + Recorded("GuildUninvite") + Recorded("C_GuildPromote") + Recorded("C_GuildUninvite")) == p0
		local flags = {}
		for k, v in ipairs(got) do flags[k] = v and "1" or "0" end
		local f = table.concat(flags)
		return f == "1111", f, "1111 (Aktivität, Entfernen, Befördern über den sicheren Knopf, nichts direkt)"
	end)
	Client("T199", "B", "Verwaltungsknopf an der Gildenseite", "J drücken: rechts neben dem Gildenfenster steht 'Verwaltung (GuildSentinel)' (ohne Rechte grau); /gs verwaltung öffnet das Fenster; Passwort festlegen und mit falschem/richtigem Passwort entsperren")
	Ad.unlocked = false
end

------------------------------------------------------------
-- K. OBERFLÄCHE IM ECHTEN CLIENT (anweisung-testroutine-oberflaeche.txt, Fälle 1–6)
-- Nur lesen: Fenster öffnen, Tooltips zeigen und wieder schliessen, Lagen vergleichen. Ohne Bildschirm-Lage (nachgebautes
-- WoW in test/) werden die Fälle begründet übersprungen; die Rechenhilfen prüft test/run_uicheck.lua.
------------------------------------------------------------
local U = {}
R.UICheck = U

-- Lage in UIParent-Koordinaten: { l, b, w, h } oder nil (nicht sichtbar bzw. nicht gelayoutet)
function U.Rect(f)
	if not f then return nil end
	local okM, getRect = pcall(function() return f.GetRect end)
	if not okM or type(getRect) ~= "function" then return nil end
	local ok, l, b, w, h = pcall(getRect, f)
	if not ok or type(l) ~= "number" or type(b) ~= "number" or type(w) ~= "number" or type(h) ~= "number" or w <= 0 or h <= 0 then return nil end
	local s = 1
	local okS, es = pcall(function() return f:GetEffectiveScale() / UIParent:GetEffectiveScale() end)
	if okS and type(es) == "number" and es > 0 then s = es end
	return { l * s, b * s, w * s, h * s }
end

-- echte Überschneidung (Berühren an der Kante zählt nicht; 1 Pixel Spiel)
function U.Overlap(a, b)
	if not a or not b then return false end
	return a[1] + a[3] > b[1] + 1 and b[1] + b[3] > a[1] + 1 and a[2] + a[4] > b[2] + 1 and b[2] + b[4] > a[2] + 1
end

-- a liegt ganz in b (1 Pixel Spiel)
function U.Inside(a, b)
	if not a or not b then return true end
	return a[1] >= b[1] - 1 and a[2] >= b[2] - 1 and a[1] + a[3] <= b[1] + b[3] + 1 and a[2] + a[4] <= b[2] + b[4] + 1
end

local function Call(f, m, ...)
	local okM, fn = pcall(function() return f[m] end)
	if not okM or type(fn) ~= "function" then return nil end
	local ok, a, b, c, d = pcall(fn, f, ...)
	if ok then return a, b, c, d end
	return nil
end
U.Call = Call

local function Kind(f) return Call(f, "GetObjectType") or "?" end
function U.Name(f)
	local n = Call(f, "GetName")
	if type(n) == "string" and n ~= "" then return n end
	local t = Call(f, "GetText")
	if type(t) == "string" and t ~= "" and not ns.IsSecret(t) then return '"' .. t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):sub(1, 24) .. '"' end
	local p = Call(f, "GetParent")
	return Kind(f) .. (p and (" in " .. tostring(Call(p, "GetName") or "?")) or "")
end

-- sichtbare Nachfahren (Frames) eines Fensters
function U.Walk(f, out)
	out = out or {}
	local list = {}
	local okC, a = pcall(function() return { f:GetChildren() } end)
	if okC and type(a) == "table" then list = a end
	for _, c in ipairs(list) do
		if Call(c, "IsVisible") then
			out[#out + 1] = c
			U.Walk(c, out)
		end
	end
	return out
end

-- sichtbare Texte (FontStrings) eines Frames und seiner Nachfahren
function U.Texts(f)
	local out = {}
	local frames = U.Walk(f)
	table.insert(frames, 1, f)
	for _, x in ipairs(frames) do
		local okR, regs = pcall(function() return { x:GetRegions() } end)
		if okR and type(regs) == "table" then
			for _, r in ipairs(regs) do
				if Kind(r) == "FontString" and Call(r, "IsVisible") then out[#out + 1] = { fs = r, owner = x } end
			end
		end
	end
	return out
end

local function IsAncestor(a, b)          -- a ist Vorfahr von b
	local p = Call(b, "GetParent")
	local n = 0
	while p and n < 30 do
		if p == a then return true end
		p = Call(p, "GetParent")
		n = n + 1
	end
	return false
end

-- eigene Fenster, die gerade zu sehen sind
function U.OwnWindows()
	local out = {}
	local seen = {}
	for _, n in ipairs({ "GuildSentinelFrame", "GuildSentinelInfo", "GuildSentinelRules", "GuildSentinelMenu", "GuildSentinelProfButton", "GuildSentinelAdmin", "GuildSentinelAdminButton" }) do
		local f = _G[n]
		if f and Call(f, "IsVisible") then out[#out + 1] = f; seen[f] = true end
	end
	for _, f in ipairs(ns.uiFrames or {}) do
		if not seen[f] and Call(f, "IsVisible") then out[#out + 1] = f; seen[f] = true end
	end
	return out
end

-- Lage messbar? (im nachgebauten WoW nicht)
local function Measurable()
	local UI = ns.UI
	if not UI.frame then UI:Build() end
	UI.frame:Show()
	return U.Rect(UI.frame) ~= nil and U.Rect(UIParent) ~= nil
end

-- Fall 1: Tooltip eines Elements verdeckt einen Knopf oder ein Eingabefeld desselben Fensters
function U.TooltipHits(win)
	local hits, tried = {}, 0
	for _, el in ipairs(U.Walk(win)) do
		local onEnter = Call(el, "GetScript", "OnEnter")
		if type(onEnter) == "function" then
			tried = tried + 1
			pcall(onEnter, el)
			local tip = GameTooltip
			local owner = Call(tip, "GetOwner")
			if Call(tip, "IsVisible") and owner == el then
				local tr = U.Rect(tip)
				for _, other in ipairs(U.Walk(win)) do
					local k = Kind(other)
					if other ~= el and (k == "Button" or k == "CheckButton" or k == "EditBox") and Call(other, "IsVisible")
						and not IsAncestor(other, el) and not IsAncestor(el, other) and U.Overlap(tr, U.Rect(other)) then
						hits[#hits + 1] = U.Name(el) .. " -> " .. U.Name(other)
						break
					end
				end
				if tr and not U.Inside(tr, U.Rect(UIParent)) then hits[#hits + 1] = U.Name(el) .. " -> ausserhalb des Bildschirms" end
			end
			local onLeave = Call(el, "GetScript", "OnLeave")
			if type(onLeave) == "function" then pcall(onLeave, el) end
			pcall(GameTooltip.Hide, GameTooltip)
		end
	end
	return hits, tried
end

-- Fall 4: abgeschnittene Texte (Knöpfe -> FEHLER, sonst WARNUNG)
function U.CutTexts(win)
	local btn, other = {}, {}
	for _, x in ipairs(U.Texts(win)) do
		local fs = x.fs
		local cut = Call(fs, "IsTruncated")
		if cut == nil then
			local sw, w = Call(fs, "GetStringWidth"), Call(fs, "GetWidth")
			local lines = Call(fs, "GetNumLines")
			cut = type(sw) == "number" and type(w) == "number" and w > 0 and (lines == nil or lines <= 1) and sw > w + 2
		end
		if cut then
			local k = Kind(x.owner)
			local label = U.Name(x.owner)
			if k == "Button" or k == "CheckButton" then btn[#btn + 1] = label else other[#other + 1] = label end
		end
	end
	return btn, other
end

-- Fenster anderer GoldSentinel-Addons und Blizzard-Fenster, an die GuildSentinel andockt
U.OTHER_WINDOWS = { "CommunitiesFrame", "GuildFrame", "FriendsFrame", "AHSentinelFrame", "ProfessionSentinelFrame", "RaidMasterFrame", "ThreatSentinelFrame", "BuffSentinelFrame",
	"LevelPilotFrame", "TradeSkillFrame", "ProfessionsFrame", "CraftFrame",
	-- Gilden-Popups (Mitglied-Details, Rangverwaltung, Gildeninfo; Forever: Kind des Communities-Fensters)
	"GuildMemberDetailFrame", "GuildControlPopupFrame", "GuildInfoFrame", "CommunitiesFrame.GuildMemberDetailFrame" }

-- Fenster zu einem Namen; "A.B" = Kind B von Fenster A
function U.Window(n)
	local o = _G
	for part in tostring(n):gmatch("[^%.]+") do
		if type(o) ~= "table" then return nil end
		o = rawget(o, part)
	end
	return type(o) == "table" and o or nil
end

local function ByPage(fn)
	-- jede Seite und jeden Reiter einmal öffnen und fn(Name) im Hauptfenster ausführen
	local UI = ns.UI
	for _, p in ipairs(Pages()) do
		if UI:PageOn(p.page) then
			pcall(UI.Select, UI, p.i)
			local tabs = TabsOf(p.i)
			if #tabs == 0 then fn(p.key) end
			for _, t in ipairs(tabs) do
				if t.bar:IsVisible(t.key) then
					pcall(t.bar.Select, t.bar, t.key)
					fn(p.key .. ">" .. tostring(t.key))
				end
			end
		end
	end
end

function R:AreaK()
	local UI = ns.UI
	local can = Measurable()
	local WHY = "nur im echten Client (Lage der Fenster nicht messbar)"
	-- R7 (0.9.22): Filterleiste der Rezeptliste eines Mitglieds bricht um, nichts abgeschnitten oder überlagert
	Check("T237", "K", "Filterleiste Rezepte: bricht um, nichts abgeschnitten/überlagert", function()
		if not (ns.guild and UI.Open) then return false, "keine Gilde", "Gilde" end
		local wasShown = UI.frame and UI.frame:IsShown()
		UI:Open("prof")
		local page = UI.pages[UI:PageIndex("prof")]
		if not (page and page.bar and page.LayoutBar) then return false, "Seite Berufe ohne Filterleiste", "Filterleiste" end
		-- viele Arten mit langen Namen in schmaler Leiste
		local kinds, counts = {}, {}
		for _, k in ipairs({ "head", "shoulder", "chest", "wrist", "hands", "waist", "legs", "feet", "shield", "weapon1", "weapon2", "reagent", "other" }) do
			kinds[#kinds + 1] = k
			counts[k] = 12
		end
		local res = With({ { page.bar, "GetWidth", function() return 260 end }, { page, "kind", nil } }, function()
			local n, rows = page:LayoutBar(kinds, counts, 156)
			local bad = {}
			local shown = {}
			for i = 1, n do
				local b = page.bar.buttons[i]
				shown[#shown + 1] = b
				if b.lx + b.lw > page.bar.lwidth + 0.5 then bad[#bad + 1] = "zu breit " .. i end
				-- Text passt in den Knopf (gemessen, wo das Spiel misst)
				local tw = b.text:GetStringWidth()
				if tw and tw > b.lw + 0.5 and b.lw < page.bar.lwidth then bad[#bad + 1] = "abgeschnitten " .. i end
			end
			for i = 1, #shown do
				for j = i + 1, #shown do
					local a, c = shown[i], shown[j]
					local sameRow = a.ly == c.ly
					if sameRow and a.lx < c.lx + c.lw and c.lx < a.lx + a.lw then bad[#bad + 1] = "überlagert " .. i .. "/" .. j end
				end
			end
			return { rows = rows, bad = bad, n = n }
		end)
		if not wasShown and UI.frame then UI.frame:Hide() end
		return (res.rows > 1 and #res.bad == 0) and true or false,
			string.format("%d Knöpfe, %d Zeilen, Fehler: %s", res.n, res.rows, #res.bad > 0 and table.concat(res.bad, ", ") or "0"),
			"mehrere Zeilen, Fehler: 0"
	end)
	if not can then
		Skip("T182", "K", "Tooltips verdecken keine Knöpfe", WHY)
		Skip("T183", "K", "kein Überlappen mit anderen Fenstern", WHY)
		Skip("T184", "K", "Fenster und Tooltips im Bildschirm", WHY)
		Skip("T185", "K", "Texte passen", WHY)
	else
		Check("T182", "K", "Tooltips verdecken keine Knöpfe", function()
			local all, n = {}, 0
			ByPage(function(key)
				local hits, tried = U.TooltipHits(UI.frame)
				n = n + tried
				for _, h in ipairs(hits) do all[#all + 1] = key .. ": " .. h end
			end)
			return #all == 0, n .. " Tooltips, verdeckt: " .. (#all > 0 and table.concat(all, "; ", 1, math.min(#all, 12)) or "0"), "0"
		end)
		Check("T183", "K", "kein Überlappen mit anderen Fenstern", function()
			local hits = {}
			for _, win in ipairs(U.OwnWindows()) do
				local r = U.Rect(win)
				for _, n in ipairs(U.OTHER_WINDOWS) do
					local o = U.Window(n)
					if o and o ~= win and Call(o, "IsVisible") and U.Overlap(r, U.Rect(o)) then hits[#hits + 1] = U.Name(win) .. " / " .. n end
				end
			end
			return #hits == 0, #hits > 0 and table.concat(hits, "; ") or "0", "0 (angedockt nebeneinander ist erlaubt)"
		end)
		Check("T184", "K", "Fenster und Tooltips im Bildschirm", function()
			local screen = U.Rect(UIParent)
			local out = {}
			for _, win in ipairs(U.OwnWindows()) do
				if not U.Inside(U.Rect(win), screen) then out[#out + 1] = U.Name(win) end
			end
			local mm = _G.GuildSentinelMinimapButton
			if mm and Call(mm, "IsVisible") and not U.Inside(U.Rect(mm), screen) then out[#out + 1] = U.Name(mm) end
			return #out == 0, #out > 0 and table.concat(out, ", ") or "0 ausserhalb", "0 ausserhalb (Tooltips: T182)"
		end)
		Check("T185", "K", "Texte passen", function()
			local btn, other = {}, {}
			ByPage(function(key)
				local b, o = U.CutTexts(UI.frame)
				for _, x in ipairs(b) do btn[#btn + 1] = key .. ": " .. x end
				for _, x in ipairs(o) do other[#other + 1] = key .. ": " .. x end
			end)
			local warn = #other > 0 and ("WARNUNG " .. #other .. " Texte zu lang: " .. table.concat(other, "; ", 1, math.min(#other, 10))) or "0 zu lang"
			if #btn > 0 then return false, "Knöpfe abgeschnitten: " .. table.concat(btn, "; ", 1, math.min(#btn, 10)) .. " · " .. warn, "0 abgeschnittene Knöpfe" end
			return true, warn, "0"
		end)
	end
	Check("T186", "K", "Spielwerte plausibel", function()
		local bad, seen = {}, {}
		-- Stufe
		local lv = UnitLevel("player")
		if not ns.IsSecret(lv) then
			seen[#seen + 1] = "Stufe " .. tostring(lv)
			if type(lv) ~= "number" or lv < 1 or lv > ns.Roster.MAX_LEVEL then bad[#bad + 1] = "Stufe " .. tostring(lv) .. " (max " .. ns.Roster.MAX_LEVEL .. ")" end
		end
		if GetMaxPlayerLevel then
			local m = GetMaxPlayerLevel()
			if type(m) == "number" and not ns.IsSecret(m) and m ~= ns.Roster.MAX_LEVEL then bad[#bad + 1] = "Höchststufe " .. ns.Roster.MAX_LEVEL .. " statt " .. m end
		end
		-- Berufe: gelernt -> Fertigkeit > 0 und <= Maximum; gespeicherter Stand nicht höher als der echte
		local skills = ns.Prof:ReadSkillLines()
		local real = R.saved and R.saved.guild and R.saved.guild.prof and R.saved.guild.prof[ns.Me()]
		for name, v in pairs(skills) do
			if not ns.IsSecret(name) and not ns.IsSecret(v.r) then
				seen[#seen + 1] = tostring(name) .. " " .. tostring(v.r)
				if type(v.r) ~= "number" or v.r <= 0 or (type(v.m) == "number" and v.m > 0 and v.r > v.m) then
					bad[#bad + 1] = tostring(name) .. " Fertigkeit " .. tostring(v.r) .. "/" .. tostring(v.m)
				end
				local st = type(real) == "table" and type(real.p) == "table" and real.p[name]
				if type(st) == "table" and type(st.r) == "number" and type(v.r) == "number" and st.r > v.r then
					bad[#bad + 1] = tostring(name) .. " gespeichert " .. st.r .. " > echt " .. v.r
				end
			end
		end
		-- Gilde: Anzahl in GuildSentinel = Anzahl laut Spiel (nur ausserhalb des Testmodus gelesen)
		local list = R.saved and R.saved.list
		if IsInGuild and IsInGuild() and GetNumGuildMembers and type(list) == "table" and #list > 0 then
			local total = GetNumGuildMembers()
			if type(total) == "number" and not ns.IsSecret(total) and total > 0 then
				seen[#seen + 1] = "Gilde " .. #list .. "/" .. total
				if math.abs(total - #list) > 1 then bad[#bad + 1] = "Mitglieder " .. #list .. " statt " .. total end
			end
		end
		-- Geld (Bank-Charakter)
		local money = ns.API.GetMoney and ns.API.GetMoney()
		if money ~= nil and not ns.IsSecret(money) and (type(money) ~= "number" or money < 0) then bad[#bad + 1] = "Geld " .. tostring(money) end
		return #bad == 0, (#bad > 0 and table.concat(bad, "; ") or "ok") .. " (" .. table.concat(seen, ", ", 1, math.min(#seen, 6)) .. ")", "plausibel"
	end)
	Check("T187", "K", "keine Fehlerschleifen", function()
		local loops = {}
		local s = GuildSentinelDB and GuildSentinelDB.gsTest
		for _, e in ipairs(GoldSentinelTest.ErrorList(s or {})) do
			if (e.count or 0) > 10 then loops[#loops + 1] = (e.count or 0) .. "× " .. tostring(e.wo) .. ": " .. tostring(e.msg):sub(1, 80) end
		end
		-- eigene Liste der letzten Fehler: 10 gleiche hintereinander deuten auf eine Schleife
		local same, last = 0, nil
		for _, e in ipairs(ns.errors and ns.errors.last or {}) do
			local k = tostring(e.wo) .. "|" .. tostring(e.msg)
			if k == last then same = same + 1 else same, last = 1, k end
		end
		if same >= 10 and ns.errors.n > 10 then loops[#loops + 1] = "10× hintereinander: " .. tostring(last):sub(1, 80) end
		return #loops == 0, #loops > 0 and table.concat(loops, " | ", 1, math.min(#loops, 5)) or "0", "keine Meldung mehr als 10×"
	end)
	pcall(GameTooltip.Hide, GameTooltip)
end

------------------------------------------------------------
-- Ablauf: Sandbox, Bereiche, Aufräumen, Bericht
------------------------------------------------------------
local AREA_FN = { A = "AreaA", B = "AreaB", C = "AreaC", D = "AreaD", E = "AreaE", F = "AreaF", G = "AreaG", H = "AreaH", I = "AreaI", J = "AreaJ", K = "AreaK" }

local function SaveState()
	local st = {
		db = Copy(GuildSentinelDB or {}),
		guild = ns.guild, guildKey = ns.guildKey, lang = ns.lang, debug = ns.debug,
		list = ns.Roster.list, byName = ns.Roster.byName, scans = ns.Roster.scans, liveJoin = ns.Roster.liveJoin,
		users = ns.Comm.users, claims = Copy(ns.Comm.claims), free = ns.Free.list,
		cq = ns.Recruit.combatQueue, cd = ns.Recruit.combatDropped, claimed = Copy(ns.Recruit.claimed), claimBy = Copy(ns.Recruit.claimBy),
		chatHooked = ns.Social.chatHooked, ttHooked = ns.Tooltip.hooked, errors = Copy(ns.errors),
		testActive = ns.Test.active, uiShown = ns.UI.frame and ns.UI.frame:IsShown(),
	}
	st.db.gsTest = nil
	-- eigene Einträge in der Warteschlange der gemeinsamen Sync-Datei (was die Routine dazulegt, wird entfernt)
	st.syncMark = ns.Comm.TestMark()
	st.qh, st.ql = 0, 0
	return st
end

local function RestoreState(st)
	UnswapAll()
	ns.actRecorder = nil
	ns.testSecret = nil
	ns.testCombat = nil
	if GoldSentinelGame.SetTestFlavor then GoldSentinelGame.SetTestFlavor(nil) end
	ns.Game:Refresh()
	-- Testmodus: aus, wenn die Routine ihn gestartet hat (sonst wieder frisch an)
	if ns.Test.active and not st.testActive then ns.Test:Stop() end
	ns.guild, ns.guildKey, ns.lang, ns.debug = st.guild, st.guildKey, st.lang, st.debug
	ns.Roster.list, ns.Roster.byName, ns.Roster.scans, ns.Roster.liveJoin = st.list, st.byName, st.scans, st.liveJoin
	ns.Comm.users, ns.Free.list = st.users, st.free
	wipe(ns.Comm.claims); for k, v in pairs(st.claims) do ns.Comm.claims[k] = v end
	ns.Recruit.combatQueue, ns.Recruit.combatDropped = st.cq, st.cd
	wipe(ns.Recruit.claimed); for k, v in pairs(st.claimed) do ns.Recruit.claimed[k] = v end
	wipe(ns.Recruit.claimBy); for k, v in pairs(st.claimBy) do ns.Recruit.claimBy[k] = v end
	ns.Social.chatHooked, ns.Tooltip.hooked = st.chatHooked, st.ttHooked
	-- Fehlerzähler: Selbsttest-Fehler nicht stehen lassen, echte behalten
	ns.errors.n, ns.errors.last = st.errors.n, st.errors.last
	-- nichts aus der Routine in der Sendewarteschlange lassen; Senden der gemeinsamen Sync-Datei wieder freigeben
	ns.Comm.TestPurge(st.syncMark or {})
	ns.Comm.TestHold(false)
	DropSelfTestErrors()
end

local function CompareAndRestore(st)
	local paths = {}
	Diff(GuildSentinelDB, st.db, "DB", paths, 10, 0, true)
	RestoreInto(GuildSentinelDB, st.db, true)
	ns.db = GuildSentinelDB.settings
	if #paths == 0 then return "OK", paths end
	return string.format("FEHLER (%d Pfade, wiederhergestellt)", #paths), paths
end

local function Finish(st)
	-- TU6/TU8 erst am Ende (nach den verzögerten Fällen)
	if not aborted then
		local okr, errr = pcall(R.TUReport, R)
		if not okr then RUN:Add("FEHLER", "TU-REPORT", "I", "Testbericht TU", { lua = tostring(errr) }) end
	end
	local mem0 = R.mem0
	local realBy = {}
	for k, v in pairs(R.realBy) do realBy[#realBy + 1] = k .. " " .. v end
	local recorded = RecTotal()
	-- T82: über die ganze Routine (jeder Bereich) darf nichts echt hinausgegangen sein, und in der Sendewarteschlange
	-- darf nichts aus der Routine liegen. Sonst FEHLER im Bericht (nicht nur eine Textzeile).
	local pend = ns.Comm.TestPending(st.syncMark or {})
	RUN:Check("T82", "B", "nichts gesendet", function()
		return (R.real == 0 and pend == 0) and true or false,
			string.format("echt %d%s, Warteschlange +%d", R.real, #realBy > 0 and (" (" .. table.concat(realBy, ", ") .. ")") or "", pend), "echt 0, Warteschlange +0"
	end)
	R.running = false
	RestoreState(st)
	local sandbox, paths = CompareAndRestore(st)
	if sandbox ~= "OK" then
		RUN:Add("FEHLER", "SANDBOX", "-", "echte Daten verändert", { ergebnis = table.concat(paths, ", ") })
	end
	collectgarbage("collect")
	local memKB = collectgarbage("count") - (mem0 or 0)
	local text = RUN:Finish({ sandbox = sandbox })
	local GT = GoldSentinelTest
	local last = {}
	for i = 1, math.min(3, #ns.errors.last) do last[#last + 1] = ns.errors.last[i].wo .. ": " .. ns.errors.last[i].msg end
	local extra = {
		string.format("Sprache: %s (%s)", tostring(GetLocale()), tostring(ns.lang)),
		string.format("Fehlerzähler GuildSentinel: %d%s", ns.errors.n, #last > 0 and (" (letzte: " .. table.concat(last, " | ") .. ")") or ""),
		string.format("Recorder: %d echte Sendungen%s (%d nur aufgezeichnet)", R.real, #realBy > 0 and (" – " .. table.concat(realBy, ", ")) or "", recorded),
		"echte Daten unverändert: " .. sandbox,
		string.format("Speicher: %+d KB", math.floor(memKB + 0.5)),
		"",
		L["Bericht gespeichert – wird beim nächsten /reload oder Ausloggen an die Prüfung gemeldet."],
		L["Bitte jetzt /reload, damit alles sicher wie vorher ist."],
	}
	text = text .. "\n" .. table.concat(extra, "\n")
	if #text > 19000 then text = text:sub(1, 19000) .. "\n… gekürzt" end
	R.lastText = text
	local c = RUN.counts
	ns:Print(ORANGE .. string.format(L["Testroutine: OK %d · FEHLER %d · übersprungen %d · im Client prüfen %d"], c.ok, c.fehler, c.uebersprungen, c.client) .. "|r")
	ns:Print(L["Bericht gespeichert – wird beim nächsten /reload oder Ausloggen an die Prüfung gemeldet."])
	ns:Print(L["Bitte jetzt /reload, damit alles sicher wie vorher ist."])
	if ns.UI and ns.UI.Info then pcall(ns.UI.Info, ns.UI, L["Testroutine"], text, true) end
	if R.watch then R.watch:UnregisterAllEvents() end
	RUN = nil
	return text
end

-- Start. which: "" = alle, sonst ein Bereich (a … k). probe = nur prüfen, ob gestartet würde (T105)
function R:Start(which, probe)
	if ns.InCombat() then
		if not probe then ns:Print(L["Die Testroutine startet nicht im Kampf."]) end
		return false
	end
	if probe then return true end
	if R.running then ns:Print(L["Die Testroutine läuft schon."]) return false end
	which = (which or ""):upper()
	only = (which ~= "" and AREA_FN[which]) and which or nil
	aborted = false
	InstallHooks()
	collectgarbage("collect")
	R.mem0 = collectgarbage("count")
	R.rec, R.real, R.realBy = {}, 0, {}
	R.ranIds, R.TU = {}, {}
	local st = SaveState()
	R.saved = st              -- echte Daten (Bereich K vergleicht Spielwerte damit)
	R.running = true
	-- gemeinsame Sync-Datei: während der Routine geht nichts hinaus (nur ihre Schnittstellen-Tabelle wird ersetzt)
	R.syncHeld = 0
	ns.Comm.TestHold(true, function() R.syncHeld = R.syncHeld + 1 end)
	RUN = GoldSentinelTest.Begin("GuildSentinel", ns.version, GuildSentinelDB)
	R.recLast = {}
	ns.actRecorder = function(what, a) R.rec[what] = (R.rec[what] or 0) + 1; R.recLast[what] = a end
	if not ns.Test.active then ns.Test:Start() end
	if not ns.Test.active then R.running = false; RestoreState(st); return false end
	-- Kampf mitten im Lauf: sauber abbrechen
	if not R.watch then R.watch = CreateFrame("Frame") end
	R.watch:RegisterEvent("PLAYER_REGEN_DISABLED")
	R.watch:SetScript("OnEvent", function() aborted = true end)
	for _, a in ipairs(R.AREAS) do
		if Want(a) and not aborted then
			area = a
			local ok, err = pcall(R[AREA_FN[a]], R)
			if not ok then RUN:Add("FEHLER", "AREA-" .. a, a, "Bereich abgebrochen", { lua = tostring(err) }) end
			UnswapAll()
			Flavor(nil)
			ns.testCombat = nil
		end
	end
	if aborted or not (Want("B") or Want("J")) then return Finish(st) end
	local ok, err = pcall(R.Deferred, R, "plan")
	if not ok then RUN:Add("FEHLER", "DEFERRED", "B", "verzögerte Fälle", { lua = tostring(err) }) end
	ns:Print(ORANGE .. string.format(L["Testroutine läuft – bitte %d Sekunden warten."], math.ceil(R.WAIT)) .. "|r")
	C_Timer.After(R.WAIT, function()
		if aborted then
			Skip("T67", "B", "verzögerte Sendungen", "Kampf begonnen")
			Skip("T167", "J", "Kampf-Flüstern", "Kampf begonnen")
		else
			local ok2, err2 = pcall(R.Deferred, R, "check")
			if not ok2 then RUN:Add("FEHLER", "DEFERRED", "B", "verzögerte Fälle", { lua = tostring(err2) }) end
		end
		Finish(st)
	end)
	return true
end

-- nur Anzeige für den Launch-Abend: gemerkte Kampf-Flüsternachrichten (nie der Inhalt)
function R:WhisperQueue()
	local q = ns.Recruit.combatQueue or {}
	local secret = 0
	for _, x in ipairs(q) do if ns.IsSecret(x[1]) or ns.IsSecret(x[2]) then secret = secret + 1 end end
	ns:Print(string.format(L["Kampf-Flüsternachrichten gemerkt: %d, davon geschützt: %d (dazu %d über der Grenze)"], #q, secret, ns.Recruit.combatDropped or 0))
	return #q, secret
end

function R:Slash(rest)
	if not (GoldSentinelDev and GoldSentinelDev:IsDev()) then return end
	rest = ns.Trim(rest or ""):lower()
	if rest == "whisperq" then return self:WhisperQueue() end
	return self:Start(rest)
end
