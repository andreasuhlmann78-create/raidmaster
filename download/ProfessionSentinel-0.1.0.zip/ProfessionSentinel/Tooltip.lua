local _, ns = ...
local L = ns.L

-- Adds "learned / not learned" info to recipe item tooltips (e.g. at vendors or in the AH).

local function AddLines(tooltip, itemID)
    if not ns.db or not ns.db.tooltip or not itemID then return end
    if tooltip.__psItem == itemID then return end
    local r = ns.ByRecipeItem[itemID]
    if not r then return end
    tooltip.__psItem = itemID
    local c = ns.Char()
    tooltip:AddLine(" ")
    if c and c.known[r.spell] then
        tooltip:AddLine("|cff3fc7ebProfessionSentinel:|r |cff7f7f7f" .. (ns.isGerman and "Bereits gelernt" or "Already learned") .. "|r")
    elseif c and c.profs[r.prof] then
        local rank = c.profs[r.prof].rank or 0
        local need = r.req or 0
        local col = (need > 0 and rank < need) and "ff4040" or "1eff00"
        tooltip:AddLine(string.format("|cff3fc7ebProfessionSentinel:|r |cff%s%s|r", col,
            (ns.isGerman and "Noch nicht gelernt" or "Not learned yet") ..
            (need > 0 and string.format(" (%s %d, %s %d)", L.REQ, need, L.YOUR_SKILL, rank) or "")))
    end
    local knownBy, missingBy = ns.Scan:CharsFor(r.spell, r.prof)
    local me = UnitName("player")
    local function others(list)
        local out = {}
        for _, n in ipairs(list) do if n ~= me then out[#out + 1] = n end end
        return out
    end
    knownBy, missingBy = others(knownBy), others(missingBy)
    if #knownBy > 0 then tooltip:AddLine(L.KNOWN_BY .. ": |cffffffff" .. table.concat(knownBy, ", ") .. "|r", 0.6, 0.6, 0.6, true) end
    if #missingBy > 0 then tooltip:AddLine(L.MISSING_BY .. ": |cffffffff" .. table.concat(missingBy, ", ") .. "|r", 0.6, 0.6, 0.6, true) end
    tooltip:Show()
end

local function ItemIDFromTooltip(tooltip, data)
    if data and data.id then return data.id end
    if tooltip.GetItem then
        local _, link = tooltip:GetItem()
        if link then return tonumber(link:match("item:(%d+)")) end
    end
end

local hooked = {}
local function HookTooltip(tt)
    if not tt or hooked[tt] then return end
    hooked[tt] = true
    tt:HookScript("OnTooltipCleared", function(self) self.__psItem = nil end)
    if not (TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall) then
        pcall(tt.HookScript, tt, "OnTooltipSetItem", function(self) AddLines(self, ItemIDFromTooltip(self)) end)
    end
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function()
    for _, tt in ipairs({ GameTooltip, ItemRefTooltip, ShoppingTooltip1, ShoppingTooltip2 }) do HookTooltip(tt) end
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tooltip, data)
            AddLines(tooltip, ItemIDFromTooltip(tooltip, data))
        end)
    end
end)
