local _, ns = ...
local L = ns.L

-- Panel docked to the Retail-style profession window (ProfessionsFrame, Blizzard_Professions).
-- Shows every recipe of the open profession: learned ones greyed out, missing ones in rarity colour.

local UI = {}
ns.UI = UI

local PANEL_WIDTH = 400
local ROW_HEIGHT = 20

-- WoW Forever client uses its own child skill lines (e.g. 2945 Leatherworking) whose parent
-- is the classic skill line our data uses.
local PROF_ALIAS = {
    [2937] = 171, [2938] = 164, [2939] = 185, [2940] = 333, [2941] = 202, [2942] = 129,
    [2943] = 356, [2944] = 182, [2945] = 165, [2946] = 186, [2947] = 393, [2948] = 197,
}

local function ResolveProf(id)
    if not id then return nil end
    id = PROF_ALIAS[id] or id
    return ns.ByProf[id] and id or nil
end

---------------------------------------------------------------------------
-- Current profession and rank
---------------------------------------------------------------------------
local function CurrentProfession()
    if not C_TradeSkillUI then return nil end
    local prof, rank, maxRank
    if C_TradeSkillUI.GetChildProfessionInfo then
        local info = C_TradeSkillUI.GetChildProfessionInfo()
        if info and info.professionID then
            prof = ResolveProf(info.professionID) or ResolveProf(info.parentProfessionID)
            rank, maxRank = info.skillLevel, info.maxSkillLevel
        end
    end
    if not prof and C_TradeSkillUI.GetBaseProfessionInfo then
        local info = C_TradeSkillUI.GetBaseProfessionInfo()
        if info and info.professionID then
            prof = ResolveProf(info.professionID)
            rank = rank or info.skillLevel
            maxRank = maxRank or info.maxSkillLevel
        end
    end
    if not prof and C_TradeSkillUI.GetTradeSkillLine then
        local id, _, r, m = C_TradeSkillUI.GetTradeSkillLine()
        prof = ResolveProf(id); rank = rank or r; maxRank = maxRank or m
    end
    if prof and not rank then rank = ns.Scan:Rank(prof) end
    return prof, rank, maxRank
end

local function IsOwnProfession()
    if C_TradeSkillUI and C_TradeSkillUI.IsTradeSkillLinked and C_TradeSkillUI.IsTradeSkillLinked() then return false end
    if C_TradeSkillUI and C_TradeSkillUI.IsTradeSkillGuild and C_TradeSkillUI.IsTradeSkillGuild() then return false end
    if C_TradeSkillUI and C_TradeSkillUI.IsNPCCrafting and C_TradeSkillUI.IsNPCCrafting() then return false end
    return true
end

local function IsLearned(r)
    if ns.Scan:IsKnown(r.spell) then return true end
    if C_TradeSkillUI and C_TradeSkillUI.GetRecipeInfo and IsOwnProfession() then
        local info = C_TradeSkillUI.GetRecipeInfo(r.spell)
        if info and info.learned then
            local c = ns.Char(); if c then c.known[r.spell] = true end
            return true
        end
    end
    return false
end

---------------------------------------------------------------------------
-- Colours
---------------------------------------------------------------------------
local DIFF = { red = "ff4040", orange = "ff8040", yellow = "ffff00", green = "40c040", grey = "808080", white = "ffffff" }

local function DifficultyHex(r, rank)
    if not rank or (r.yellow or 0) == 0 then return DIFF.white end
    if (r.req or 0) > 1 and rank < r.req then return DIFF.red end
    if rank < r.yellow then return DIFF.orange end
    if rank < r.green then return DIFF.yellow end
    if rank < r.grey then return DIFF.green end
    return DIFF.grey
end

local function SkillLevelsText(r)
    local parts = {}
    if (r.req or 0) > 1 then parts[#parts + 1] = "|cff" .. DIFF.orange .. r.req .. "|r" end
    if (r.yellow or 0) > 0 then
        parts[#parts + 1] = "|cff" .. DIFF.yellow .. r.yellow .. "|r"
        parts[#parts + 1] = "|cff" .. DIFF.green .. r.green .. "|r"
        parts[#parts + 1] = "|cff" .. DIFF.grey .. r.grey .. "|r"
    end
    return table.concat(parts, "  ")
end

local function MoneyText(copper)
    if not copper or copper <= 0 then return "" end
    if GetCoinTextureString then return GetCoinTextureString(copper) end
    return string.format("%dg %ds %dc", copper / 10000, (copper / 100) % 100, copper % 100)
end

---------------------------------------------------------------------------
-- Sources (Trainer / Vendor / Drop ...)
---------------------------------------------------------------------------
local function NPCLine(id, playerFaction)
    local n = ns.NPCs[id]
    if not n then return "NPC " .. id, true end
    local name, zone, fac, sub, lvl = n[1], n[2], n[3], n[4], n[5]
    local s = name
    if sub then s = s .. " |cff9d9d9d<" .. sub .. ">|r" end
    local extra = {}
    if lvl then extra[#extra + 1] = L.LEVEL .. " " .. lvl end
    if zone then extra[#extra + 1] = zone end
    if #extra > 0 then s = s .. " |cffb0b0b0(" .. table.concat(extra, ", ") .. ")|r" end
    local friendly = true
    if fac and playerFaction then
        local want = playerFaction == "Horde" and "H" or "A"
        friendly = fac:find(want, 1, true) ~= nil
    end
    return s, friendly
end

function UI:AddSourceLines(tt, r)
    local faction = UnitFactionGroup("player")
    local S = ns.SRC
    if bit.band(r.src, S.TRAINER) ~= 0 then
        tt:AddLine((r.req or 0) > 1 and string.format(L.SRC_TRAINER_AT, r.req) or L.SRC_TRAINER, 1, 1, 1)
    end
    if bit.band(r.src, S.AUTO) ~= 0 then tt:AddLine(L.SRC_AUTO, 1, 1, 1) end
    for _, ri in ipairs(r.recipeItems) do
        local q = ns.ItemQuality(ri.id)
        local line = "|cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(ri.id) .. "|r"
        if ri.rs then line = line .. "  |cffb0b0b0(" .. L.REQ .. " " .. ri.rs .. ")|r" end
        tt:AddLine(line)
        if ri.v then
            local shown, friendlyFirst = 0, {}
            for _, id in ipairs(ri.v) do
                local s, ok = NPCLine(id, faction)
                table.insert(friendlyFirst, ok and 1 or #friendlyFirst + 1, { s, ok })
            end
            for _, e in ipairs(friendlyFirst) do
                if shown < 4 then
                    tt:AddLine("   " .. L.SRC_VENDOR .. ": " .. e[1] .. (e[2] and "" or " |cffff6060[" .. L.OTHER_FACTION .. "]|r"), 0.85, 0.85, 0.85)
                    shown = shown + 1
                end
            end
            if #ri.v > shown then tt:AddLine("   " .. string.format(L.MORE, #ri.v - shown), 0.6, 0.6, 0.6) end
            if ri.bp then tt:AddLine("   " .. MoneyText(ri.bp), 1, 1, 1) end
        end
        if ri.d then
            if (ri.dn or 0) > 15 then
                tt:AddLine("   " .. string.format(L.SRC_WORLDDROP, ri.dn), 0.85, 0.85, 0.85)
            else
                for i, id in ipairs(ri.d) do
                    if i <= 4 then tt:AddLine("   " .. L.SRC_DROP .. ": " .. (NPCLine(id)), 0.85, 0.85, 0.85) end
                end
                if (ri.dn or #ri.d) > 4 then tt:AddLine("   " .. string.format(L.MORE, (ri.dn or #ri.d) - 4), 0.6, 0.6, 0.6) end
            end
        end
        if ri.qr then tt:AddLine("   " .. string.format(L.SRC_QUEST, ri.qr), 0.85, 0.85, 0.85) end
        if ri.o then tt:AddLine("   " .. string.format(L.SRC_CONTAINER, ri.o), 0.85, 0.85, 0.85) end
        if not (ri.v or ri.d or ri.qr or ri.o) then tt:AddLine("   " .. L.SRC_UNKNOWN, 0.6, 0.6, 0.6) end
    end
end

function UI:ShowRecipeTooltip(owner, r)
    local tt = GameTooltip
    tt:SetOwner(owner, "ANCHOR_RIGHT")
    local qr, qg, qb = ns.QualityRGB(r.quality)
    tt:AddLine(ns.RecipeName(r), qr, qg, qb)
    if r.cat then tt:AddLine(ns.ProfName(r.prof) .. " - " .. r.cat, 0.7, 0.7, 0.7) end
    if r.isNew then tt:AddLine("|cff3fc7eb" .. L.F_NEW .. "|r") end
    if IsLearned(r) then tt:AddLine(ns.isGerman and "Bereits gelernt" or "Already learned", 0.5, 0.5, 0.5) end
    local levels = SkillLevelsText(r)
    if levels ~= "" then tt:AddDoubleLine(L.SKILL_LEVELS, levels, 1, 0.82, 0) end
    if r.out then
        local cnt = (r.outMax or 1) > 1 and (r.outMin == r.outMax and (" x" .. r.outMin) or (" x" .. r.outMin .. "-" .. r.outMax)) or ""
        local q = ns.ItemQuality(r.out)
        tt:AddLine(" ")
        tt:AddLine(L.CREATES .. ": |cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(r.out) .. "|r" .. cnt, 1, 0.82, 0)
    elseif r.ench then
        tt:AddLine(" ")
        tt:AddLine(L.ENCHANT, 1, 0.82, 0)
    end
    if #r.reagents > 0 then
        tt:AddLine(" ")
        tt:AddLine(L.REAGENTS, 1, 0.82, 0)
        for i = 1, #r.reagents, 2 do
            local id, need = r.reagents[i], r.reagents[i + 1]
            local have = ns.GetItemCount(id)
            local q = ns.ItemQuality(id)
            local col = have >= need and "1eff00" or "ff6060"
            tt:AddDoubleLine("|T" .. ns.GetItemIcon(id) .. ":0|t |cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(id) .. "|r",
                "|cff" .. col .. have .. "/" .. need .. "|r")
        end
    end
    tt:AddLine(" ")
    tt:AddLine(L.SOURCES, 1, 0.82, 0)
    self:AddSourceLines(tt, r)
    tt:Show()
end

---------------------------------------------------------------------------
-- Panel
---------------------------------------------------------------------------
local panel, scrollBox, scrollBar, searchBox, missingCheck, summary, collapsed

local function RowIcon(r)
    if r.out then return ns.GetItemIcon(r.out) end
    return ns.GetSpellIcon(r.spell)
end

local function InitHeader(button, node)
    local data = node:GetData()
    if not button.label then
        button:SetHeight(ROW_HEIGHT)
        button.bg = button:CreateTexture(nil, "BACKGROUND")
        button.bg:SetAllPoints()
        button.bg:SetColorTexture(1, 1, 1, 0.06)
        button.arrow = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        button.arrow:SetPoint("LEFT", 4, 0)
        button.label = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        button.label:SetPoint("LEFT", 20, 0)
        button.count = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        button.count:SetPoint("RIGHT", -6, 0)
        button:SetHighlightTexture("Interface\\Buttons\\UI-Listbox-Highlight2", "ADD")
        button:GetHighlightTexture():SetAlpha(0.2)
    end
    button.label:SetText(data.name)
    button.count:SetText(data.known .. "/" .. data.total)
    button.arrow:SetText(node:IsCollapsed() and "+" or "-")
    button:SetScript("OnClick", function()
        node:ToggleCollapsed()
        collapsed[data.name] = node:IsCollapsed() or nil
        button.arrow:SetText(node:IsCollapsed() and "+" or "-")
    end)
    button:SetScript("OnEnter", nil)
    button:SetScript("OnLeave", nil)
end

local function InitRow(button, node)
    local data = node:GetData()
    local r = data.recipe
    if not button.name then
        button:SetHeight(ROW_HEIGHT)
        button.icon = button:CreateTexture(nil, "ARTWORK")
        button.icon:SetSize(16, 16)
        button.icon:SetPoint("LEFT", 22, 0)
        button.check = button:CreateTexture(nil, "OVERLAY")
        button.check:SetSize(14, 14)
        button.check:SetPoint("LEFT", 4, 0)
        button.check:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready")
        button.name = button:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        button.name:SetPoint("LEFT", button.icon, "RIGHT", 6, 0)
        button.name:SetPoint("RIGHT", -70, 0)
        button.name:SetJustifyH("LEFT")
        button.name:SetWordWrap(false)
        button.new = button:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        button.new:SetPoint("RIGHT", -38, 0)
        button.new:SetTextColor(0.25, 0.78, 0.92)
        button.skill = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        button.skill:SetPoint("RIGHT", -6, 0)
        button.skill:SetJustifyH("RIGHT")
        button:SetHighlightTexture("Interface\\Buttons\\UI-Listbox-Highlight2", "ADD")
        button:GetHighlightTexture():SetAlpha(0.25)
        button:RegisterForClicks("LeftButtonUp")
    end
    local learned = data.learned
    button.icon:SetTexture(RowIcon(r))
    button.icon:SetDesaturated(learned)
    button.icon:SetAlpha(learned and 0.5 or 1)
    button.check:SetShown(learned)
    local qr, qg, qb = ns.QualityRGB(r.quality)
    button.name:SetText(ns.RecipeName(r))
    if learned then
        -- leicht ausgegraut: quality colour mixed with grey and dimmed
        button.name:SetTextColor(qr * 0.4 + 0.3, qg * 0.4 + 0.3, qb * 0.4 + 0.3)
        button.name:SetAlpha(0.6)
    else
        button.name:SetTextColor(qr, qg, qb)
        button.name:SetAlpha(1)
    end
    button.new:SetText(r.isNew and L.NEW_TAG or "")
    local lvl = (r.req or 0) > 1 and r.req or (r.yellow or 0)
    button.skill:SetText(lvl > 0 and ("|cff" .. DifficultyHex(r, data.rank) .. lvl .. "|r") or "")
    button.skill:SetAlpha(learned and 0.6 or 1)
    button:SetScript("OnEnter", function(self) UI:ShowRecipeTooltip(self, r) end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    button:SetScript("OnClick", function()
        if IsModifiedClick and IsModifiedClick("CHATLINK") then
            local link = r.recipeItems[1] and ns.GetItemLink(r.recipeItems[1].id) or (r.out and ns.GetItemLink(r.out))
            if link and ChatEdit_InsertLink then ChatEdit_InsertLink(link) end
            return
        end
        if learned and C_TradeSkillUI and C_TradeSkillUI.OpenRecipe then
            C_TradeSkillUI.OpenRecipe(r.spell)
        end
    end)
end

local function MatchesSearch(r, text)
    if text == "" then return true end
    if r.searchText:find(text, 1, true) then return true end
    if r.out and ns.ItemName(r.out):lower():find(text, 1, true) then return true end
    for i = 1, #r.reagents, 2 do
        if ns.ItemName(r.reagents[i]):lower():find(text, 1, true) then return true end
    end
    return false
end

function UI:Refresh()
    if not panel or not panel:IsShown() then return end
    local prof, rank, maxRank = CurrentProfession()
    if not prof then
        panel:SetTitle(L.TITLE)
        summary:SetText("")
        scrollBox:SetDataProvider(CreateTreeDataProvider())
        return
    end
    panel:SetTitle(ns.ProfName(prof))
    local text = (searchBox:GetText() or ""):lower()
    local onlyMissing = missingCheck:GetChecked()

    local dp = CreateTreeDataProvider()
    local cats, order = {}, {}
    local total, known = 0, 0
    for _, r in ipairs(ns.ByProf[prof]) do
        local learned = IsLearned(r)
        total = total + 1
        if learned then known = known + 1 end
        if MatchesSearch(r, text) and not (onlyMissing and learned) then
            local cname = r.cat or ns.ProfName(prof)
            local c = cats[cname]
            if not c then
                c = { name = cname, items = {}, known = 0, total = 0 }
                cats[cname] = c
                order[#order + 1] = c
            end
            c.total = c.total + 1
            if learned then c.known = c.known + 1 end
            c.items[#c.items + 1] = { recipe = r, learned = learned, rank = rank }
        end
    end
    for _, c in ipairs(order) do
        local header = dp:Insert({ header = true, name = c.name, known = c.known, total = c.total })
        for _, item in ipairs(c.items) do header:Insert(item) end
        if collapsed[c.name] and text == "" then header:SetCollapsed(true) end
    end
    scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
    local rankText = rank and string.format("   %s: %d/%d", L.YOUR_SKILL, rank, maxRank or 0) or ""
    summary:SetText(string.format("%d/%d %s%s", known, total, L.KNOWN, rankText))
end

local function CreatePanel()
    panel = CreateFrame("Frame", "ProfessionSentinelPanel", ProfessionsFrame, "ButtonFrameTemplate")
    panel:SetWidth(PANEL_WIDTH)
    panel:SetPoint("TOPLEFT", ProfessionsFrame, "TOPRIGHT", 2, 0)
    panel:SetPoint("BOTTOMLEFT", ProfessionsFrame, "BOTTOMRIGHT", 2, 0)
    if ButtonFrameTemplate_HidePortrait then ButtonFrameTemplate_HidePortrait(panel) end
    if ButtonFrameTemplate_HideButtonBar then ButtonFrameTemplate_HideButtonBar(panel) end
    panel:SetTitle(L.TITLE)
    panel:Hide()
    if panel.CloseButton then
        panel.CloseButton:SetScript("OnClick", function()
            panel:Hide(); ns.db.panelOpen = false
        end)
    end

    searchBox = CreateFrame("EditBox", nil, panel, "SearchBoxTemplate")
    searchBox:SetHeight(20)
    searchBox:SetPoint("TOPLEFT", panel, "TOPLEFT", 16, -30)
    searchBox:SetPoint("RIGHT", panel, "RIGHT", -140, 0)
    searchBox:SetAutoFocus(false)
    if searchBox.Instructions then searchBox.Instructions:SetText(SEARCH or L.SEARCH) end
    searchBox:HookScript("OnTextChanged", function() UI:Refresh() end)

    missingCheck = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
    missingCheck:SetSize(22, 22)
    missingCheck:SetPoint("LEFT", searchBox, "RIGHT", 8, 0)
    local mlabel = missingCheck:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    mlabel:SetPoint("LEFT", missingCheck, "RIGHT", 2, 0)
    mlabel:SetText(L.F_MISSING)
    missingCheck:SetChecked(ns.db.filters.missing)
    missingCheck:SetScript("OnClick", function(self)
        ns.db.filters.missing = self:GetChecked() and true or false
        UI:Refresh()
    end)

    summary = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    summary:SetPoint("TOPLEFT", searchBox, "BOTTOMLEFT", -4, -6)
    summary:SetJustifyH("LEFT")

    local inset = panel.Inset or panel
    if panel.Inset then
        panel.Inset:ClearAllPoints()
        panel.Inset:SetPoint("TOPLEFT", panel, "TOPLEFT", 8, -76)
        panel.Inset:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -6, 6)
    end

    scrollBox = CreateFrame("Frame", nil, inset, "WowScrollBoxList")
    scrollBox:SetPoint("TOPLEFT", inset, "TOPLEFT", 4, -4)
    scrollBox:SetPoint("BOTTOMRIGHT", inset, "BOTTOMRIGHT", -20, 4)
    scrollBar = CreateFrame("EventFrame", nil, inset, "MinimalScrollBar")
    scrollBar:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 4, 0)
    scrollBar:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 4, 0)

    local view = CreateScrollBoxListTreeListView(0)
    view:SetElementExtent(ROW_HEIGHT)
    view:SetElementFactory(function(factory, node)
        if node:GetData().header then factory("Button", InitHeader) else factory("Button", InitRow) end
    end)
    ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, scrollBar, view)

    local info = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    info:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -10, -14)
    info:SetText(string.format(L.DATA_INFO, ns.DataMeta.build or "?", (ns.DataMeta.questie or "?"):match("%d%d%d%d%-%d%d%-%d%d") or "?"))

    panel:SetScript("OnShow", function() UI:Refresh() end)
end

local function CreateToggleButton()
    local b = CreateFrame("Button", "ProfessionSentinelToggle", ProfessionsFrame, "UIPanelButtonTemplate")
    b:SetSize(130, 22)
    b:SetPoint("TOPRIGHT", ProfessionsFrame, "BOTTOMRIGHT", -6, 0)
    b:SetText(ns.isGerman and "Alle Rezepte" or "All recipes")
    b:SetScript("OnClick", function() UI:Toggle() end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("ProfessionSentinel", 0.25, 0.78, 0.92)
        GameTooltip:AddLine(L.SUBTITLE, 1, 1, 1)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

function UI:Toggle()
    if not panel then
        if ProfessionsFrame then ns.Print(ns.isGerman and "Öffne zuerst ein Berufsfenster." or "Open a profession window first.") end
        return
    end
    if panel:IsShown() then
        panel:Hide(); ns.db.panelOpen = false
    else
        panel:Show(); ns.db.panelOpen = true
    end
end

local function OnProfessionsLoaded()
    if panel or not ProfessionsFrame then return end
    collapsed = ns.db.collapsed or {}
    ns.db.collapsed = collapsed
    CreatePanel()
    CreateToggleButton()
    ProfessionsFrame:HookScript("OnShow", function()
        if ns.db.panelOpen ~= false then panel:Show() end
        UI:Refresh()
    end)
    ProfessionsFrame:HookScript("OnHide", function() GameTooltip:Hide() end)
    if ProfessionsFrame:IsShown() and ns.db.panelOpen ~= false then panel:Show() end
end

-- Blizzard_Professions is load-on-demand
local loader = CreateFrame("Frame")
loader:RegisterEvent("ADDON_LOADED")
loader:RegisterEvent("PLAYER_LOGIN")
loader:RegisterEvent("TRADE_SKILL_LIST_UPDATE")
loader:RegisterEvent("TRADE_SKILL_DATA_SOURCE_CHANGED")
loader:SetScript("OnEvent", function(_, event, name)
    if event == "ADDON_LOADED" and name == "Blizzard_Professions" then
        OnProfessionsLoaded()
    elseif event == "PLAYER_LOGIN" then
        if C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded("Blizzard_Professions") then OnProfessionsLoaded() end
    elseif panel then
        UI:Refresh()
    end
end)
