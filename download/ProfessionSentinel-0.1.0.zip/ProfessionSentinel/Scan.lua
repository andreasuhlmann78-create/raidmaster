local _, ns = ...

-- Detects the player's professions (with skill rank) and which recipes are learned.
-- Works with both the modern profession API (C_TradeSkillUI) and the classic one
-- (GetTradeSkillInfo / GetCraftInfo), plus IsPlayerSpell as a passive check.

local Scan = {}
ns.Scan = Scan

local function MatchProfession(name)
    if not name then return nil end
    for _, p in ipairs(ns.Professions) do
        if p.name == name or ns.ProfessionNamesEN[p.id] == name then return p.id end
    end
    return nil
end

-- Profession ranks -------------------------------------------------------
function Scan:UpdateProfessions()
    local c = ns.Char(); if not c then return end
    local found = {}
    if GetProfessions and GetProfessionInfo then
        local slots = { GetProfessions() }
        for i = 1, 6 do
            local idx = slots[i]
            if idx then
                local name, _, rank, maxRank, _, _, skillLine = GetProfessionInfo(idx)
                local id = (skillLine and ns.ProfById[skillLine]) and skillLine or MatchProfession(name)
                if id then found[id] = { rank = rank or 0, max = maxRank or 0 } end
            end
        end
    end
    if GetNumSkillLines and GetSkillLineInfo then
        for i = 1, GetNumSkillLines() do
            local name, isHeader, _, rank, _, _, maxRank = GetSkillLineInfo(i)
            if not isHeader then
                local id = MatchProfession(name)
                if id and not found[id] then found[id] = { rank = rank or 0, max = maxRank or 0 } end
            end
        end
    end
    if next(found) then c.profs = found end
end

-- Known recipes -------------------------------------------------------------
local function MarkKnown(spellID)
    local c = ns.Char()
    if c and spellID and ns.BySpell[spellID] then
        if not c.known[spellID] then
            c.known[spellID] = true
            return true
        end
    end
    return false
end

local function SpellFromLink(link)
    if not link then return nil end
    local id = link:match("enchant:(%d+)") or link:match("spell:(%d+)")
    return id and tonumber(id)
end

function Scan:PassiveCheck()
    local c = ns.Char(); if not c then return end
    if not IsPlayerSpell then return end
    local changed = false
    for spell in pairs(ns.BySpell) do
        local ok, known = pcall(IsPlayerSpell, spell)
        if ok and known and not c.known[spell] then c.known[spell] = true; changed = true end
    end
    return changed
end

function Scan:ScanTradeSkill()
    local changed = false
    -- Modern API
    if C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs then
        local ok, ids = pcall(C_TradeSkillUI.GetAllRecipeIDs)
        if ok and ids then
            for _, id in ipairs(ids) do
                local info = C_TradeSkillUI.GetRecipeInfo(id)
                if info and info.learned and MarkKnown(id) then changed = true end
            end
        end
    end
    -- Classic API
    if GetNumTradeSkills and GetTradeSkillInfo then
        for i = 1, GetNumTradeSkills() do
            local name, kind = GetTradeSkillInfo(i)
            if name and kind ~= "header" and kind ~= "subheader" then
                local spell = GetTradeSkillRecipeLink and SpellFromLink(GetTradeSkillRecipeLink(i))
                if not spell then
                    local r = ns.ByName[name:lower()]
                    spell = r and r.spell
                end
                if MarkKnown(spell) then changed = true end
            end
        end
    end
    -- Classic enchanting window
    if GetNumCrafts and GetCraftInfo then
        for i = 1, GetNumCrafts() do
            local name, _, kind = GetCraftInfo(i)
            if name and kind ~= "header" then
                local spell = GetCraftRecipeLink and SpellFromLink(GetCraftRecipeLink(i))
                if not spell then
                    local r = ns.ByName[name:lower()]
                    spell = r and r.spell
                end
                if MarkKnown(spell) then changed = true end
            end
        end
    end
    return changed
end

local function Refresh()
    if ns.UI and ns.UI.Refresh then ns.UI:Refresh() end
end

function Scan:Init()
    local f = CreateFrame("Frame")
    local events = {
        "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE", "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_DATA_SOURCE_CHANGED",
        "CRAFT_SHOW", "CRAFT_UPDATE", "NEW_RECIPE_LEARNED", "LEARNED_SPELL_IN_TAB", "SKILL_LINES_CHANGED",
        "CHAT_MSG_SKILL",
    }
    for _, e in ipairs(events) do pcall(f.RegisterEvent, f, e) end
    local pending = false
    f:SetScript("OnEvent", function(_, event, arg1)
        if event == "NEW_RECIPE_LEARNED" and arg1 then MarkKnown(arg1) end
        if pending then return end
        pending = true
        C_Timer.After(0.5, function()
            pending = false
            Scan:UpdateProfessions()
            Scan:ScanTradeSkill()
            Scan:PassiveCheck()
            Refresh()
        end)
    end)
    C_Timer.After(2, function()
        Scan:UpdateProfessions()
        Scan:PassiveCheck()
        Refresh()
    end)
end

-- Helpers for the UI ------------------------------------------------------
function Scan:IsKnown(spell)
    local c = ns.Char()
    return c and c.known[spell] or false
end

function Scan:PlayerProfessions()
    local c = ns.Char()
    local list = {}
    if not c then return list end
    for _, p in ipairs(ns.Professions) do
        if c.profs[p.id] and ns.ByProf[p.id] and #ns.ByProf[p.id] > 0 then list[#list + 1] = p end
    end
    return list
end

function Scan:Rank(profID)
    local c = ns.Char()
    local p = c and c.profs[profID]
    return p and p.rank or nil, p and p.max or nil
end

-- Which other characters know / miss a recipe (for tooltips)
function Scan:CharsFor(spell, profID)
    local knownBy, missingBy = {}, {}
    for key, c in pairs(ns.db.chars) do
        local short = key:match("^[^-]+") or key
        if c.known and c.known[spell] then
            knownBy[#knownBy + 1] = short
        elseif c.profs and c.profs[profID] then
            missingBy[#missingBy + 1] = short
        end
    end
    table.sort(knownBy); table.sort(missingBy)
    return knownBy, missingBy
end
