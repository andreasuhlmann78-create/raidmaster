-- BuffSentinel – Prüfung der Oberfläche im echten Client (Testfälle T140–T145, Bereich K)
-- Copyright (c) 2026 GoldSentinel. All Rights Reserved.
--
-- Übernommen aus der GoldSentinel-Vorlage (shared/vorlage/__ADDON__/UICheck.lua, dort T18–T23), angepasst an BuffSentinel:
-- Namensraum BS, Texte aus Locales.lua, schwebende Anzeigen (Buttons, Raster, Reinigungsleiste) gelten bei T141 nicht
-- als "angedockt" – sie schweben frei, wo der Spieler sie hinzieht.
--
-- Anlass (Live-Test 5. Nov. 2026): eigene Tooltips verdeckten Knöpfe, Fenster lagen übereinander, Anzeigen rechneten
-- mit falschen Spielwerten, ein Fehler kam 588×. Offline sieht man das nicht – darum prüft die Testroutine es im
-- Spiel selbst. Nur lesen, nichts verändern.
--
-- Benutzung:
--   BS.RegisterUI(frame, "Name", floating)       -- jedes eigene Fenster anmelden (floating = frei schwebende Anzeige)
--   BS.Plausible("Name", function() return ok, ist, soll end)   -- Spielwert-Prüfung für T144
-- Andere GoldSentinel-Addons melden ihre Fenster in der globalen Liste GoldSentinelUIFrames an (T141 prüft gegeneinander).

local ADDON, BS = ...
local L = BS.L

BS.uiFrames = BS.uiFrames or {}
BS.plausible = BS.plausible or {}
BS.UI_LOOP_LIMIT = 10                       -- dieselbe Fehlermeldung öfter -> Fehlerschleife (T145)

-- Blizzard-Fenster, die eigene Fenster nicht überdecken dürfen
BS.UI_BLIZZARD = { "ProfessionsFrame", "TradeSkillFrame", "CraftFrame", "MerchantFrame", "AuctionHouseFrame",
                   "AuctionFrame", "MailFrame", "QuestLogFrame", "WorldMapFrame", "CharacterFrame", "SpellBookFrame",
                   "PlayerSpellsFrame", "SettingsPanel", "InterfaceOptionsFrame" }

GoldSentinelUIFrames = GoldSentinelUIFrames or {}

function BS.RegisterUI(frame, name, floating)
    if not frame then return end
    for _, e in ipairs(BS.uiFrames) do if e.frame == frame then return end end
    local e = { frame = frame, name = name or (frame.GetName and frame:GetName()) or ADDON, floating = floating == true }
    BS.uiFrames[#BS.uiFrames + 1] = e
    -- Frei schwebende Kampfanzeigen (Anker, Raster, Leisten) NICHT in die gemeinsame Liste: Sie dürfen frei liegen,
    -- andere GoldSentinel-Addons sollen ihre Fenster nicht als "überdeckt" melden (Befund Anker, 10.11.).
    if not e.floating then
        GoldSentinelUIFrames[#GoldSentinelUIFrames + 1] = { frame = frame, name = e.name, addon = ADDON }
    end
end

function BS.Plausible(name, fn) BS.plausible[#BS.plausible + 1] = { name = name, fn = fn } end

-- Tooltip neben das ganze Fenster legen (verdeckt so keine Knöpfe desselben Fensters, T140); Platz rechts, sonst links
function BS.TipBeside(owner, container)
    container = container or owner
    GameTooltip:SetOwner(owner, "ANCHOR_NONE")
    GameTooltip:ClearAllPoints()
    local right = container.GetRight and container:GetRight()
    local sw = UIParent and UIParent.GetWidth and UIParent:GetWidth()
    local cs = container.GetEffectiveScale and container:GetEffectiveScale() or 1
    local us = UIParent and UIParent.GetEffectiveScale and UIParent:GetEffectiveScale() or 1
    if type(right) == "number" and type(sw) == "number" and us > 0 and right * cs / us + 330 > sw then
        GameTooltip:SetPoint("TOPRIGHT", container, "TOPLEFT", -6, 0)
    else
        GameTooltip:SetPoint("TOPLEFT", container, "TOPRIGHT", 6, 0)
    end
end

local U = {}
BS.UICheck = U

-- Ist der echte Client da (Rechtecke, Kinder, Tooltip)? Sonst werden die Fälle ehrlich übersprungen.
function U.Available()
    local f = BS.uiFrames[1] and BS.uiFrames[1].frame
    return f and type(f.GetRect) == "function" and type(f.GetChildren) == "function"
        and type(GameTooltip) == "table" and type(GameTooltip.GetRect) == "function"
        and type(UIParent) == "table" and type(UIParent.GetRect) == "function" and U.Rect(UIParent) ~= nil and true or false
end

function U.Rect(f)
    if not (f and f.GetRect) then return nil end
    local ok, l, b, w, h = pcall(f.GetRect, f)
    if not ok or type(l) ~= "number" or type(w) ~= "number" or w <= 0 or h <= 0 then return nil end
    local s = f.GetEffectiveScale and f:GetEffectiveScale() or 1
    return { l = l * s, b = b * s, r = (l + w) * s, t = (b + h) * s }
end

-- Fläche der Überschneidung (0 = keine). Ein Pixel Rand gilt als "angedockt", nicht als Überlappen.
function U.Overlap(a, c)
    if not (a and c) then return 0 end
    local w = math.min(a.r, c.r) - math.max(a.l, c.l) - 1
    local h = math.min(a.t, c.t) - math.max(a.b, c.b) - 1
    return (w > 0 and h > 0) and w * h or 0
end

local function Shown(f) return f and f.IsVisible and f:IsVisible() and true or false end

local function Name(f)
    local n = f and f.GetName and f:GetName()
    if n then return n end
    local t = f and f.GetText and f:GetText()
    if t and not BS.IsSecret(t) then return "'" .. tostring(t) .. "'" end
    return tostring(f and f.GetObjectType and f:GetObjectType() or "?")
end

-- alle sichtbaren Nachfahren eines Fensters
function U.Descendants(f, out)
    out = out or {}
    if not (f and f.GetChildren) then return out end
    for _, c in ipairs({ f:GetChildren() }) do
        if Shown(c) then out[#out + 1] = c; U.Descendants(c, out) end
    end
    return out
end

local function IsControl(f)
    return f.IsObjectType and (f:IsObjectType("Button") or f:IsObjectType("EditBox") or f:IsObjectType("CheckButton")
        or f:IsObjectType("Slider")) and true or false
end

-- T140: kein eigener Tooltip verdeckt einen Knopf desselben Fensters
function U.TooltipsCoverNothing()
    local problems, tested = {}, 0
    for _, e in ipairs(BS.uiFrames) do
        if Shown(e.frame) then
            local all = U.Descendants(e.frame)
            for _, el in ipairs(all) do
                local enter = el.GetScript and el:GetScript("OnEnter")
                if enter then
                    tested = tested + 1
                    pcall(enter, el)
                    local tip = Shown(GameTooltip) and U.Rect(GameTooltip)
                    if tip then
                        for _, other in ipairs(all) do
                            if other ~= el and IsControl(other) and U.Overlap(tip, U.Rect(other)) > 0 then
                                problems[#problems + 1] = string.format(L.UI_COVERS, Name(el), Name(other))
                                break
                            end
                        end
                    end
                    local leave = el:GetScript("OnLeave")
                    if leave then pcall(leave, el) end
                    if GameTooltip.Hide then GameTooltip:Hide() end
                end
            end
        end
    end
    return problems, tested
end

-- T141: eigene sichtbare Fenster überdecken weder Blizzard-Fenster noch Fenster anderer GoldSentinel-Addons.
-- Frei schwebende Anzeigen (floating) stehen, wo der Spieler sie hinzieht – sie werden nicht geprüft.
function U.WindowsOverlapNothing()
    local problems, tested = {}, 0
    for _, e in ipairs(BS.uiFrames) do
        local mine = not e.floating and Shown(e.frame) and U.Rect(e.frame)
        if mine then
            for _, bn in ipairs(BS.UI_BLIZZARD) do
                local bf = _G[bn]
                if type(bf) == "table" and Shown(bf) then
                    tested = tested + 1
                    if U.Overlap(mine, U.Rect(bf)) > 0 then problems[#problems + 1] = string.format(L.UI_OVERLAPS, e.name, bn) end
                end
            end
            for _, o in ipairs(GoldSentinelUIFrames) do
                if o.addon ~= ADDON and Shown(o.frame) then
                    tested = tested + 1
                    if U.Overlap(mine, U.Rect(o.frame)) > 0 then
                        problems[#problems + 1] = string.format(L.UI_OVERLAPS, e.name, tostring(o.name) .. " (" .. tostring(o.addon) .. ")")
                    end
                end
            end
        end
    end
    return problems, tested
end

-- T142: sichtbare Fenster liegen ganz im Bildschirm
function U.InsideScreen()
    local problems, tested, screen = {}, 0, U.Rect(UIParent)
    for _, e in ipairs(BS.uiFrames) do
        local r = Shown(e.frame) and U.Rect(e.frame)
        if r and screen then
            tested = tested + 1
            if r.l < screen.l - 1 or r.b < screen.b - 1 or r.r > screen.r + 1 or r.t > screen.t + 1 then
                problems[#problems + 1] = string.format(L.UI_OFFSCREEN, e.name)
            end
        end
    end
    return problems, tested
end

-- T143: Beschriftungen von Knöpfen sind nicht abgeschnitten (andere Texte nur als Hinweis)
function U.TextFits()
    local problems, hints, tested = {}, {}, 0
    for _, e in ipairs(BS.uiFrames) do
        if Shown(e.frame) then
            for _, el in ipairs(U.Descendants(e.frame)) do
                local fs = el.GetFontString and el:GetFontString()
                if fs and fs.IsTruncated then
                    tested = tested + 1
                    if fs:IsTruncated() then problems[#problems + 1] = string.format(L.UI_TRUNCATED, Name(el)) end
                end
                for _, region in ipairs(el.GetRegions and { el:GetRegions() } or {}) do
                    if region.IsObjectType and region:IsObjectType("FontString") and region.IsTruncated and Shown(region) then
                        tested = tested + 1
                        if region:IsTruncated() then hints[#hints + 1] = string.format(L.UI_SHORTENED, Name(el)) end
                    end
                end
            end
        end
    end
    return problems, tested, hints
end

-- T144: angezeigte Spielwerte plausibel (Prüfungen meldet BuffSentinel mit BS.Plausible an)
function U.ValuesPlausible()
    local problems = {}
    for _, p in ipairs(BS.plausible) do
        local ok, good, got, want = pcall(p.fn)
        if not ok then problems[#problems + 1] = p.name .. ": " .. L.UI_LUA_ERROR .. tostring(good)
        elseif good == false then
            problems[#problems + 1] = p.name .. ": " .. tostring(got) .. string.format(L.UI_EXPECTED, tostring(want))
        end
    end
    return problems, #BS.plausible
end

-- T145: keine Fehlerschleife – dieselbe Meldung höchstens UI_LOOP_LIMIT× (gemeldete Fehler der echten Daten)
function U.NoErrorLoops(db)
    local problems, n = {}, 0
    db = db or BuffSentinelDB
    local s = db and db.gsTest
    for _, e in pairs(s and type(s.errors) == "table" and s.errors or {}) do
        if type(e) == "table" then
            n = n + 1
            if (e.count or 1) > BS.UI_LOOP_LIMIT then
                problems[#problems + 1] = (e.count or 1) .. "× " .. tostring(e.wo) .. ": " .. tostring(e.msg)
            end
        end
    end
    return problems, n
end

------------------------------------------------------------------------
-- Spielwerte, die BuffSentinel anzeigt oder benutzt (T144)
------------------------------------------------------------------------
local function Unreadable(v) return v == nil or BS.IsSecret(v) end

BS.Plausible(L.UI_P_LEVEL, function()
    local lvl = UnitLevel and UnitLevel("player")
    if Unreadable(lvl) or type(lvl) ~= "number" then return true, L.UI_NOT_READABLE end
    return lvl >= 1 and lvl <= 100, lvl, "1–100"
end)

BS.Plausible(L.UI_P_CLASS, function()
    local _, class = UnitClass("player")
    if Unreadable(class) then return true, L.UI_NOT_READABLE end
    return BS.class == class, tostring(BS.class), tostring(class)
end)

BS.Plausible(L.UI_P_VERSION, function()
    local G = GoldSentinelGame
    if not (G and G.flavor) or not BS.FLAVOR_EXP or not BS.FLAVOR_EXP[G.flavor] then return true, L.UI_NOT_READABLE end
    return BS.flavor == G.flavor, tostring(BS.flavor), tostring(G.flavor)
end)

-- Talentpunkte (Talentbäume bis Cataclysm, auch Forever): verteilt nie mehr als die Stufe erlaubt
BS.Plausible(L.UI_P_TALENTS, function()
    if not BS.expansion or BS.expansion > 4 then return true, L.UI_NOT_READABLE end
    local lvl = UnitLevel and UnitLevel("player")
    if Unreadable(lvl) or type(lvl) ~= "number" then return true, L.UI_NOT_READABLE end
    local sum = 0
    for _, p in ipairs(BS.points or {}) do if type(p) == "number" then sum = sum + p end end
    return sum >= 0 and sum <= math.max(0, lvl - 9), sum, "0–" .. math.max(0, lvl - 9)
end)

-- Gruppen-Raster: so viele Zeilen wie Gruppenmitglieder
BS.Plausible(L.UI_P_GROUP, function()
    if not (BS.GetGroupUnits and GetNumGroupMembers) then return true, L.UI_NOT_READABLE end
    local units = BS:GetGroupUnits()
    local n = GetNumGroupMembers()
    if Unreadable(n) then return true, L.UI_NOT_READABLE end
    if n == 0 then n = 1 end                  -- allein: nur du
    return #units == n, #units, n
end)

-- eigene Buffs: was BuffSentinel gelesen hat, stimmt mit einem frischen Blick ins Spiel überein (nur, wenn erlaubt)
BS.Plausible(L.UI_P_AURAS, function()
    if BS:AuraBlocked("player") or BS:CombatLocked() then return true, L.UI_NOT_READABLE end
    local fresh = BS.ScanAuras("player", {})
    local mine, missing = 0, {}
    for name in pairs(BS.playerAuras or {}) do
        mine = mine + 1
        if not fresh[name] then missing[#missing + 1] = name end
    end
    return #missing == 0, mine .. (#missing > 0 and (" – " .. table.concat(missing, ", ")) or ""), L.UI_SAME_AS_GAME
end)
