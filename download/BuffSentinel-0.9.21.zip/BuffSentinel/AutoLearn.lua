-- BuffSentinel - AutoLearn.lua
-- Automatisches Lernen: neue Procs und neue Fähigkeiten mit Abklingzeit, die nicht in den
-- Klassendaten stehen (z. B. Neuheiten aus WoW Forever), nimmt das Addon selbst auf.
--
-- Procs:     Ein kurzer Buff, den du dir im Kampf selbst gibst und der kein Zauber aus dem
--            Zauberbuch ist, wird beobachtet. Verschwindet er mehrmals genau dann, wenn du
--            denselben Zauber wirkst (er wird "verbraucht"), ist das ein Proc für diesen Zauber.
--            Buffs, die nur auslaufen (Waffen-Verzauberungen, Schmuckstücke), werden nie aufgenommen.
-- Fähigkeiten: Wirkst du einen Klassenzauber mit mindestens 10 s Abklingzeit, der in den Daten
--            fehlt, kommt er in die Cooldown-Leiste. Neu erlernte Zauber (Lehrer, Talent) mit
--            Abklingzeit werden sofort aufgenommen.
-- Entdeckungen werden (abschaltbar) mit anderen BuffSentinel-Nutzern geteilt – nur Zauber-IDs.

local ADDON, BS = ...
local L = BS.L
local API = BS.API

local PROC_MAX_DUR   = 60     -- Procs halten höchstens 60 s
local CONSUME_WINDOW = 0.6    -- Zauber und Verschwinden des Buffs liegen höchstens 0,6 s auseinander
local PROC_MIN_HITS  = 3      -- so oft muss derselbe Zauber den Buff verbraucht haben
local PROC_MIN_RATIO = 0.75   -- ... und zwar bei mindestens 75 % aller vorzeitigen Verluste
local CD_MIN, CD_MAX = 10, 600
local MAX_CAND       = 40
local SEP            = ";"

local active        = {}   -- beobachtete Buffs: Name -> { t, id, icon }
local prevInfo      = {}   -- letzter Stand der eigenen Buffs
local recentCasts   = {}   -- { name, id, t }
local pendingRemove = {}   -- Buff verschwand, Zauber noch nicht gemeldet: Name -> { t, since }

------------------------------------------------------------------------
-- Datenbank
------------------------------------------------------------------------
function BS:AutoDB(class)
    local g = self.gdb
    if not g or not g.auto then return end
    class = class or self.class
    local c = g.auto.classes[class]
    if type(c) ~= "table" then
        c = { procs = {}, cds = {}, ignore = {}, cand = {} }
        g.auto.classes[class] = c
    end
    for _, f in ipairs({ "procs", "cds", "ignore", "cand" }) do
        if type(c[f]) ~= "table" then c[f] = {} end
    end
    return g.auto, c
end

function BS:AutoActive()
    if self.isRetail or self.testClass or not self.gdb or not self.gdb.auto then return false end
    return self.gdb.auto.enabled and true or false
end

local function CurrentSpec()
    local s = BS.mainSpec
    if type(s) == "number" and s > 0 then return s end
    return nil
end

local function AddSpec(rec)
    local s = CurrentSpec()
    if not s then return false end
    rec.specs = rec.specs or {}
    for _, x in ipairs(rec.specs) do if x == s then return false end end
    tinsert(rec.specs, s)
    table.sort(rec.specs)
    return true
end

local function SpecString(specs)
    local t = {}
    for _, s in ipairs(specs or {}) do tinsert(t, tostring(s)) end
    return table.concat(t, ",")
end

local function ParseSpecs(str)
    local t = {}
    for s in tostring(str or ""):gmatch("%d+") do
        local n = tonumber(s)
        if n and n >= 1 and n <= 4 then tinsert(t, n) end
    end
    return t
end

------------------------------------------------------------------------
-- Was steht schon in den Klassendaten?
------------------------------------------------------------------------
local function AddNames(set, v)
    if type(v) == "table" then
        for _, x in ipairs(v) do AddNames(set, x) end
    elseif type(v) == "number" then
        local n = BS.SpellInfo(v)
        if type(n) == "string" then set[n] = true end
    elseif type(v) == "string" then
        set[v] = true
        local loc = BS.LocalSpellName and BS:LocalSpellName(v)
        if type(loc) == "string" then set[loc] = true end
    end
end

function BS:AutoCovered(class)
    class = class or self.class
    if class == self.class and self.autoCoveredCache then return self.autoCoveredCache end
    local set = {}
    local data = self.ClassData[class]
    if data then
        for _, d in ipairs(data.entries) do
            AddNames(set, d.spell); AddNames(set, d.procAuras); AddNames(set, d.auras); AddNames(set, d.groupSpell)
            if d.spellBySpec then
                for _, v in pairs(d.spellBySpec) do AddNames(set, v) end
            end
        end
    end
    if class == self.class and self.db then
        for _, c in ipairs(self.db.custom) do set[c.aura] = true end
        self.autoCoveredCache = set   -- wird bei jedem ResolveEntries neu aufgebaut
    end
    return set
end

function BS:IsClassSpell(name)
    if not name then return false end
    if self.classSpells and next(self.classSpells) then return self.classSpells[name] ~= nil end
    return self.spellbookOK and self.known[name] == true
end

------------------------------------------------------------------------
-- Einträge für ResolveEntries
------------------------------------------------------------------------
function BS:AutoEntries()
    local list = {}
    local _, c = self:AutoDB()
    if not c then return list end
    local covered = self:AutoCovered()
    for aura, r in pairs(c.procs) do
        if type(r) == "table" and not covered[aura] and not c.ignore[aura] then
            tinsert(list, {
                key = "auto:p:" .. aura, kind = "proc", v = "all", auto = r,
                spell = r.spellId or r.spell, procAuras = { r.auraId or aura }, iconSpell = r.auraId,
                specs = (r.specs and #r.specs > 0) and r.specs or nil,
            })
        end
    end
    for name, r in pairs(c.cds) do
        if type(r) == "table" and not covered[name] and not c.ignore[name] then
            tinsert(list, {
                key = "auto:c:" .. name, kind = "cd", v = "all", auto = r,
                spell = r.id or name,
                specs = (r.specs and #r.specs > 0) and r.specs or nil,
            })
        end
    end
    table.sort(list, function(a, b) return a.key < b.key end)
    return list
end

function BS:AutoRebuild()
    -- mitten in AutoScanAuras nicht neu aufbauen (Layout liest die Auren neu ein und würde die Tabellen leeren,
    -- über die AutoScanAuras gerade läuft) – danach nachholen
    if self.autoScanning then self.autoRebuildPending = true return end
    if self:Lockdown() then
        self.pendingLayout = true
    else
        self:Layout()
    end
    if self.optionsFrame and self.optionsFrame:IsShown() then self:RefreshOptions() end
end

------------------------------------------------------------------------
-- Teilen
------------------------------------------------------------------------
function BS:AutoShare(class, rec, kind)
    if not self.gdb.auto.share or not self.SendName then return end
    local msg
    if kind == "P" and rec.auraId and rec.spellId then
        msg = table.concat({ "A", class, "P", tostring(rec.auraId), tostring(rec.spellId), SpecString(rec.specs) }, SEP)
    elseif kind == "C" and rec.id then
        msg = table.concat({ "A", class, "C", tostring(rec.id), "0", SpecString(rec.specs) }, SEP)
    end
    if msg then self:SendName(msg, "both") end
end

-- Gilde/Gruppe: beim Betreten der Gruppe alles Gelernte (nur selbst Entdecktes) weitergeben
function BS:AutoShareAll()
    if not self.gdb or not self.gdb.auto or not self.gdb.auto.share then return end
    for class, c in pairs(self.gdb.auto.classes) do
        for _, r in pairs(c.procs or {}) do
            if r.src ~= "net" and r.auraId and r.spellId then
                self:SendName(table.concat({ "A", class, "P", tostring(r.auraId), tostring(r.spellId), SpecString(r.specs) }, SEP), "group")
            end
        end
        for _, r in pairs(c.cds or {}) do
            if r.src ~= "net" and r.id then
                self:SendName(table.concat({ "A", class, "C", tostring(r.id), "0", SpecString(r.specs) }, SEP), "group")
            end
        end
    end
end

function BS:OnAutoShare(class, kind, a, b, specs, from)
    if not self.gdb or not self.gdb.auto or not self.gdb.auto.enabled or not self.gdb.auto.share then return end
    if self.isRetail or type(class) ~= "string" or not self.ClassData[class] then return end
    local _, c = self:AutoDB(class)
    local covered = self:AutoCovered(class)
    if kind == "P" then
        local auraId, spellId = tonumber(a), tonumber(b)
        local aura, auraIcon = BS.SpellInfo(auraId)
        local spell = BS.SpellInfo(spellId)
        if not aura or not spell or aura == spell then return end
        if covered[aura] or c.ignore[aura] or c.procs[aura] then return end
        c.procs[aura] = { aura = aura, auraId = auraId, spell = spell, spellId = spellId, icon = auraIcon,
            specs = ParseSpecs(specs), src = "net", from = from, t = time() }
        c.cand[aura] = nil
        if class == self.class then
            BS.Print(string.format(L.NEW_PROC_TAKEN_OVER_FROM, from or L.ANOTHER_PLAYER, aura, spell))
            self:AutoRebuild()
        end
    elseif kind == "C" then
        local id = tonumber(a)
        local name = BS.SpellInfo(id)
        if not name or covered[name] or c.ignore[name] or c.cds[name] then return end
        if class == self.class and not self:IsClassSpell(name) and self.spellbookOK then return end
        c.cds[name] = { name = name, id = id, specs = ParseSpecs(specs), src = "net", from = from, t = time() }
        if class == self.class then
            BS.Print(string.format(L.NEW_ABILITY_TAKEN_OVER_FROM, from or L.ANOTHER_PLAYER, name))
            self:AutoRebuild()
        end
    end
end

------------------------------------------------------------------------
-- Procs erkennen
------------------------------------------------------------------------
local function TrimCasts(now)
    for i = #recentCasts, 1, -1 do
        if now - recentCasts[i].t > 2 then tremove(recentCasts, i) end
    end
end

-- Zauber, der zwischen "since" und t (± Fenster) gewirkt wurde und am nächsten an t liegt
local function FindCast(aura, since, t)
    local best, bestDiff
    for _, cst in ipairs(recentCasts) do
        local diff = math.abs(cst.t - t)
        if cst.name ~= aura and cst.t >= since - 0.05 and diff <= CONSUME_WINDOW and (not bestDiff or diff < bestDiff) then
            best, bestDiff = cst, diff
        end
    end
    return best
end

local function TrimCandidates(c)
    local n, oldestName, oldestT = 0, nil, nil
    for name, cand in pairs(c.cand) do
        n = n + 1
        if not oldestT or (cand.t or 0) < oldestT then oldestName, oldestT = name, cand.t or 0 end
    end
    if n > MAX_CAND and oldestName then c.cand[oldestName] = nil end
end

function BS:AutoProcCandidate(name, info, now)
    local _, c = self:AutoDB()
    if not c or c.ignore[name] then return false end
    if c.procs[name] then
        -- schon gelernt: merken, in welcher Skillung er vorkommt
        if AddSpec(c.procs[name]) then self:AutoRebuild() end
        return false
    end
    if self.known[name] then return false end            -- eigener Zauber (Haltung, Gestalt, Siegel ...)
    if self:HasCustom(name) then return false end
    if self:AutoCovered()[name] then return false end
    local dur = info.duration
    if (not dur or dur <= 0) and info.expires and info.expires > 0 then dur = info.expires - now end
    if not dur or dur <= 0 or dur > PROC_MAX_DUR then return false end
    if info.source and info.source ~= "player" then return false end   -- Buffs von anderen (Seele, Anregen ...)
    for _, cst in ipairs(recentCasts) do
        if cst.name == name and now - cst.t <= 1 then return false end
    end
    return true
end

function BS:AutoCredit(aura, spellName, spellId)
    local _, c = self:AutoDB()
    local cand = c and c.cand[aura]
    if not cand then return end
    if not self:IsClassSpell(spellName) then return end
    cand.hits[spellName] = (cand.hits[spellName] or 0) + 1
    cand.ids[spellName] = spellId
    local h = cand.hits[spellName]
    if h >= PROC_MIN_HITS and h / math.max(1, cand.cons) >= PROC_MIN_RATIO and not c.procs[aura] then
        local s = CurrentSpec()
        local rec = { aura = aura, auraId = cand.id, spell = spellName, spellId = spellId, icon = cand.icon,
            specs = s and { s } or {}, src = "self", t = time() }
        c.procs[aura] = rec
        c.cand[aura] = nil
        BS.Print(string.format(L.NEW_PROC_LEARNED_FROM_NOW,
            aura, spellName))
        if BS.PlayAlert then BS.PlayAlert("proc") end
        self:AutoShare(self.class, rec, "P")
        self:AutoRebuild()
    end
end

function BS:AutoConsumed(name, t)
    local a = active[name]
    if not a then return end
    local _, c = self:AutoDB()
    if not c then return end
    local cand = c.cand[name]
    if not cand then
        cand = { id = a.id, icon = a.icon, cons = 0, hits = {}, ids = {} }
        c.cand[name] = cand
        TrimCandidates(c)
    end
    cand.cons = cand.cons + 1
    cand.t = time()
    local cst = FindCast(name, a.t, t)
    if cst then
        self:AutoCredit(name, cst.name, cst.id)
    else
        pendingRemove[name] = { t = t, since = a.t }
    end
end

-- Aus ScanPlayerAuras: Unterschied zum letzten Stand auswerten
function BS:AutoScanAuras()
    if self.autoScanning then return end
    self.autoScanning = true
    local ok, err = pcall(self.AutoScanAurasRun, self)
    self.autoScanning = false
    if self.autoRebuildPending then
        self.autoRebuildPending = false
        self:AutoRebuild()
    end
    if not ok then error(err, 0) end
end

function BS:AutoScanAurasRun()
    local cur = self.playerAuraInfo
    if self:AutoActive() then
        local now = GetTime()
        local inCombat = self:InCombat()
        for name, info in pairs(cur) do
            local p = prevInfo[name]
            if not p then
                if inCombat and self:AutoProcCandidate(name, info, now) then
                    active[name] = { t = now, id = info.id, icon = info.icon }
                end
            elseif active[name] and (info.count or 0) < (p.count or 0) then
                self:AutoConsumed(name, now)                  -- ein Stapel verbraucht
            end
        end
        for name, p in pairs(prevInfo) do
            if not cur[name] then
                if active[name] then
                    -- vorzeitig verschwunden = verbraucht; ausgelaufen zählt nicht
                    if (p.expires or 0) > 0 and p.expires - now > 0.3 then self:AutoConsumed(name, now) end
                    active[name] = nil
                end
            end
        end
    end
    wipe(prevInfo)
    for name, info in pairs(cur) do
        prevInfo[name] = { count = info.count or 0, expires = info.expires or 0 }
    end
end

------------------------------------------------------------------------
-- Fähigkeiten mit Abklingzeit
------------------------------------------------------------------------
local function BaseCooldown(id)
    if not API.GetSpellBaseCooldown or type(id) ~= "number" then return 0 end
    local ok, ms = pcall(API.GetSpellBaseCooldown, id)
    if ok and not BS.IsSecret(ms) and type(ms) == "number" then return ms / 1000 end
    return 0
end

local function CooldownOf(id)
    local best = BaseCooldown(id)
    local s, d, secret = BS.GetCooldown(id)
    if secret then return nil end   -- geheim (Forever/Retail im Kampf): nicht bewerten
    if s and s > 0 and d and d > best then best = d end
    return best
end

local function CdText(sec)
    if sec >= 90 then return string.format(L.MIN, math.floor(sec / 60 + 0.5)) end
    return string.format("%d s", math.floor(sec + 0.5))
end
BS.AutoCdText = CdText

function BS:AutoAddCooldown(name, id, cd, src, noRebuild)
    local _, c = self:AutoDB()
    if not c or c.cds[name] then return end
    local s = CurrentSpec()
    local rec = { name = name, id = id, cd = cd, specs = s and { s } or {}, src = src, t = time() }
    c.cds[name] = rec
    BS.Print(string.format(L.NEW_ABILITY_DETECTED_COOLDOWN_ADDED,
        name, CdText(cd)))
    self:AutoShare(self.class, rec, "C")
    if not noRebuild then self:AutoRebuild() end
end

function BS:AutoCheckCooldown(spellID, name)
    if not self:AutoActive() then return end
    local _, c = self:AutoDB()
    if not c then return end
    if c.cds[name] then
        if AddSpec(c.cds[name]) then self:AutoRebuild() end
        return
    end
    if c.ignore[name] or not self:IsClassSpell(name) then return end
    if self:AutoCovered()[name] then return end
    local cd = CooldownOf(spellID)
    if not cd or cd < CD_MIN or cd > CD_MAX then return end
    self:AutoAddCooldown(name, spellID, cd, "self")
end

-- Aus UNIT_SPELLCAST_SUCCEEDED
function BS:AutoOnCast(spellID)
    if not self:AutoActive() or BS.IsSecret(spellID) or type(spellID) ~= "number" then return end
    local name = BS.SpellInfo(spellID)
    if not name then return end
    local now = GetTime()
    TrimCasts(now)
    tinsert(recentCasts, { name = name, id = spellID, t = now })
    -- Buff ist schon verschwunden, bevor der Zauber gemeldet wurde
    for aura, pr in pairs(pendingRemove) do
        if now - pr.t <= CONSUME_WINDOW and now >= pr.since - 0.05 and aura ~= name then
            self:AutoCredit(aura, name, spellID)
        end
        pendingRemove[aura] = nil
    end
    -- Abklingzeit erst kurz danach lesen (startet mit dem Zauber).
    -- Testroutine: sofort, damit kein verzögerter Aufruf nach dem Test in die echten Daten schreibt.
    if C_Timer and C_Timer.After and not (BS.TestCommActive and BS.TestCommActive()) then
        C_Timer.After(0.3, function() BS:AutoCheckCooldown(spellID, name) end)
    else
        self:AutoCheckCooldown(spellID, name)
    end
end

-- Aus FullScan: neu erlernte Zauber im Zauberbuch (Lehrer, Talentpunkt, Stufenaufstieg)
function BS:AutoSpellbookCheck()
    if self.isRetail or self.testClass or not self.spellbookOK or not self.classSpells or not next(self.classSpells) then return end
    local db = self.db
    if type(db.autoBase) ~= "table" then db.autoBase = {} end
    local first = not db.autoBaseDone      -- erster Scan: alles Vorhandene ist "bekannt", nicht neu
    local on = self.gdb.auto.enabled
    local _, c = self:AutoDB()
    local covered
    for name, id in pairs(self.classSpells) do
        if not db.autoBase[name] then
            db.autoBase[name] = true
            if not first and on and not c.cds[name] and not c.ignore[name] then
                covered = covered or self:AutoCovered()
                if not covered[name] then
                    local cd = BaseCooldown(id)
                    if cd >= CD_MIN and cd <= CD_MAX then self:AutoAddCooldown(name, id, cd, "book", true) end
                end
            end
        end
    end
    db.autoBaseDone = true
end

------------------------------------------------------------------------
-- Bedienung (Seite "Aufnahme")
------------------------------------------------------------------------
function BS:SetAutoLearn(on)
    self.gdb.auto.enabled = on and true or false
    wipe(active); wipe(pendingRemove)
    BS.Print(on and L.AUTOMATIC_LEARNING_ENABLED or L.AUTOMATIC_LEARNING_DISABLED)
    self:AutoRebuild()
end

function BS:AutoRemove(kind, name)
    local _, c = self:AutoDB()
    if not c then return end
    if kind == "proc" then c.procs[name] = nil else c.cds[name] = nil end
    c.cand[name] = nil
    c.ignore[name] = true   -- nicht wieder von selbst aufnehmen
    local key = (kind == "proc" and "auto:p:" or "auto:c:") .. name
    for _, store in pairs(self.db.specs) do store[key] = nil end
    self:AutoRebuild()
end

function BS:AutoResetIgnore()
    local _, c = self:AutoDB()
    if c then wipe(c.ignore) end
    self:AutoRebuild()
end

-- Für die Anzeige: gelernte Einträge sortiert, Beobachtungen mit Fortschritt
function BS:AutoList()
    local out = {}
    local _, c = self:AutoDB()
    if not c then return out, {}, 0 end
    for aura, r in pairs(c.procs) do tinsert(out, { kind = "proc", name = aura, rec = r }) end
    for name, r in pairs(c.cds) do tinsert(out, { kind = "cd", name = name, rec = r }) end
    table.sort(out, function(a, b)
        if a.kind ~= b.kind then return a.kind == "proc" end
        return a.name < b.name
    end)
    local cands = {}
    for name, cand in pairs(c.cand) do
        local bestSpell, bestHits = nil, 0
        for sp, h in pairs(cand.hits) do if h > bestHits then bestSpell, bestHits = sp, h end end
        tinsert(cands, { name = name, cons = cand.cons, spell = bestSpell, hits = bestHits, t = cand.t or 0 })
    end
    table.sort(cands, function(a, b) return a.t > b.t end)
    local nIgnore = 0
    for _ in pairs(c.ignore) do nIgnore = nIgnore + 1 end
    return out, cands, nIgnore
end

BS.AUTO_PROC_MIN_HITS = PROC_MIN_HITS
BS.AUTO_MAX_CAND = MAX_CAND

-- Testroutine: lokalen Beobachtungszustand sichern/leeren/zurückgeben (nur Verweise)
function BS:AutoTestState(restore)
    if restore then
        wipe(active); wipe(prevInfo); wipe(recentCasts); wipe(pendingRemove)
        for k, v in pairs(restore.active) do active[k] = v end
        for k, v in pairs(restore.prevInfo) do prevInfo[k] = v end
        for i, v in ipairs(restore.recentCasts) do recentCasts[i] = v end
        for k, v in pairs(restore.pendingRemove) do pendingRemove[k] = v end
        return
    end
    local function copy(t) local o = {}; for k, v in pairs(t) do o[k] = v end; return o end
    return { active = copy(active), prevInfo = copy(prevInfo), recentCasts = copy(recentCasts), pendingRemove = copy(pendingRemove),
             parseSpecs = ParseSpecs, prev = prevInfo, casts = recentCasts }
end
