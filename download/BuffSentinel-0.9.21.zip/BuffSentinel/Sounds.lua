-- BuffSentinel - Sounds.lua
-- Warntöne: Auswahl aus vielen Spieltönen, Glocken, LibSharedMedia und eigenen Dateien.
-- Ein/Aus und Ton pro Warnart – gespeichert pro Charakter (Klasse) und Skillung.
--
-- Gespeichert:
--   db.soundBase[art]               = { on = bool, sound = Schlüssel, custom = Pfad/ID }   Standard für alle Skillungen
--   db.soundSpecs["specN"][art]     = { on = ..., sound = ..., custom = ... }             Abweichung einer Skillung
--   db.soundChannel                 = "Master" | "SFX" | "Dialog" | "Ambience" | "Music"
-- Sound-Schlüssel: Name aus SOUNDKIT (z. B. "RAID_WARNING"), "f:<name>" (Datei aus der Liste unten),
--                  "lsm:<name>" (LibSharedMedia) oder "custom" (eigener Pfad oder FileDataID).

local ADDON, BS = ...
local L = BS.L

-- Warnarten in der Reihenfolge der Einstellungen
BS.SOUND_KINDS = {
    { key = "horn",       name = L.OWN_BUFF_EXPIRED_HORN_REPEATED, on = true,  sound = "RAID_WARNING" },
    { key = "buff",       name = L.GROUP_BUFF_MISSING_ONCE,               on = false, sound = "RAID_WARNING" },
    { key = "proc",       name = "Proc",                                        on = false, sound = "ALARM_CLOCK_WARNING_3" },
    { key = "cooldown",   name = L.COOLDOWN_READY,                             on = false, sound = "IG_MAINMENU_OPTION_CHECKBOX_ON" },
    { key = "dispel",     name = L.DEBUFF_TO_DISPEL,                         on = false, sound = "IG_PLAYER_INVITE" },
    { key = "dispel_imp", name = L.IMPORTANT_RAID_DEBUFF,                       on = false, sound = "RAID_WARNING" },
    { key = "bell",       name = L.BELL_ENTRIES_WITH_SOUND_ON,           on = true,  sound = "f:shaysbell" },
}
BS.SOUND_KIND_BY_KEY = {}
for _, k in ipairs(BS.SOUND_KINDS) do BS.SOUND_KIND_BY_KEY[k.key] = k end

-- Spieltöne (SOUNDKIT). Was es in einer WoW-Version nicht gibt, wird automatisch ausgeblendet.
-- id = Ersatz, falls ein sehr alter Client kein SOUNDKIT kennt.
local KIT_SOUNDS = {
    -- Warnungen
    { "RAID_WARNING",                   L.RAID_WARNING,            8959 },
    { "READY_CHECK",                    L.READY_CHECK,      8960 },
    { "RAID_BOSS_EMOTE_WARNING",        L.BOSS_EMOTE },
    { "UI_RAID_BOSS_WHISPER_WARNING",   L.BOSS_WHISPER },
    { "PVP_THROUGH_QUEUE",              L.BATTLEGROUND_READY },
    { "PVP_ENTER_QUEUE",                L.BATTLEGROUND_QUEUE },
    { "ALARM_CLOCK_WARNING_1",          L.ALARM_CLOCK_1 },
    { "ALARM_CLOCK_WARNING_2",          L.ALARM_CLOCK_2,                12867 },
    { "ALARM_CLOCK_WARNING_3",          L.ALARM_CLOCK_3,                12889 },
    { "MAP_PING",                       L.MAP_PING },
    { "LFG_ROLE_CHECK",                 L.ROLE_CHECK },
    { "LFG_REWARDS",                    L.DUNGEON_REWARD },
    { "UI_BNET_TOAST",                  L.BATTLE_NET_TOAST },
    { "UI_PROFESSIONS_NEW_RECIPE_LEARNED_TOAST", L.NEW_RECIPE },
    -- Nachrichten & Gruppe
    { "TELL_MESSAGE",                   L.WHISPER,                3081 },
    { "IG_PLAYER_INVITE",               L.INVITATION,               880 },
    { "FRIEND_JOIN_GAME",               L.FRIEND_ONLINE },
    { "U_CHAT_SCROLL_BUTTON",           L.CHAT_CLICK },
    -- Quests & Belohnungen
    { "IG_QUEST_LIST_COMPLETE",         L.QUEST_COMPLETED,     878 },
    { "IG_QUEST_LIST_OPEN",             L.QUEST_LIST_OPEN,          875 },
    { "IG_QUEST_LOG_ABANDON_QUEST",     L.ABANDON_QUEST },
    { "LEVEL_UP",                       L.LEVEL_UP,          888 },
    { "LEVELUPSOUND",                   L.LEVEL_UP_OLD },
    { "LOOT_WINDOW_COIN_SOUND",         L.COINS },
    { "MONEY_FRAME_OPEN",               L.MONEY_BAG },
    { "UI_EPICLOOT_TOAST",              L.EPIC_LOOT },
    { "ACHIEVEMENT_MENU_OPEN",          L.ACHIEVEMENTS },
    -- Fenster & Klicks
    { "AUCTION_WINDOW_OPEN",            L.AUCTION_HOUSE_OPEN,        5274 },
    { "AUCTION_WINDOW_CLOSE",           L.AUCTION_HOUSE_CLOSE },
    { "IG_MAINMENU_OPEN",               L.MENU_OPEN,                850 },
    { "IG_MAINMENU_CLOSE",              L.MENU_CLOSE,                 851 },
    { "IG_MAINMENU_OPTION_CHECKBOX_ON", L.CLICK,                   856 },
    { "IG_MAINMENU_OPTION_CHECKBOX_OFF",L.CLICK_OFF,             857 },
    { "IG_CHARACTER_INFO_OPEN",         L.CHARACTER_WINDOW },
    { "IG_CHARACTER_INFO_TAB",          L.TAB },
    { "IG_SPELLBOOK_OPEN",              L.SPELLBOOK },
    { "IG_ABILITY_PAGE_TURN",           L.TURN_PAGE },
    { "IG_BACKPACK_OPEN",               L.BACKPACK_OPEN },
    { "IG_BACKPACK_CLOSE",              L.BACKPACK_CLOSE },
    { "IG_MINIMAP_OPEN",                "Minimap" },
    { "GS_TITLE_OPTION_OK",             "OK" },
    { "GS_LOGIN",                       L.LOGIN },
    { "WRITE_QUEST",                    L.WRITING },
    { "PUT_DOWN_SMALL_CHAIN",           L.PUT_DOWN_CHAIN_ARMOR },
    { "PUT_DOWN_GEMS",                  L.PUT_DOWN_GEMS },
    { "PUT_DOWN_WOOD",                  L.PUT_DOWN_WOOD },
    { "PUT_DOWN_RING",                  L.PUT_DOWN_RING },
}

-- Sounddateien des Spiels. Spielt eine Datei in einem Client nicht, kommt ersatzweise die Raid-Warnung
-- (beim Testen gibt es dazu einen Hinweis im Chat).
local FILE_SOUNDS = {
    { "shaysbell",   L.HAND_BELL,                 "Sound\\Spells\\ShaysBell.ogg" },
    { "tollhorde",   L.TOWER_BELL_HORDE,           "Sound\\Doodad\\BellTollHorde.ogg" },
    { "tollally",    L.TOWER_BELL_ALLIANCE,         "Sound\\Doodad\\BellTollAlliance.ogg" },
    { "tollelf",     L.TOWER_BELL_NIGHT_ELVES,      "Sound\\Doodad\\BellTollNightElf.ogg" },
    { "trollgong",   L.TROLL_GONG,                 "Sound\\Doodad\\G_GongTroll01.ogg" },
    { "wardrum",     L.WAR_DRUM,              "Sound\\Event Sounds\\Event_wardrum_ogre.ogg" },
    { "flagtaken",   L.FLAG_TAKEN,            "Sound\\Spells\\PVPFlagTaken.ogg" },
    { "flaghorde",   L.FLAG_HORDE,             "Sound\\Spells\\PVPFlagTakenHorde.ogg" },
    { "pvpally",     L.PVP_WARNING_ALLIANCE,        "Sound\\Interface\\PVPWarningAllianceMono.ogg" },
    { "pvphorde",    L.PVP_WARNING_HORDE,          "Sound\\Interface\\PVPWarningHordeMono.ogg" },
    { "murloc",      "Murloc",                     "Sound\\Creature\\Murloc\\mMurlocAggroOld.ogg" },
    { "simonbad",    L.ERROR_TONE,                    "Sound\\Spells\\SimonGame_Visual_BadPress.ogg" },
    { "fizzle",      L.SPELL_FIZZLE,            "Sound\\Spells\\Fizzle\\FizzleHolyA.ogg" },
    { "levelup",     L.LEVEL_UP_FILE,     "Sound\\Spells\\LevelUp.ogg" },
    { "questdone",   L.QUEST_DONE_FILE,       "Sound\\Interface\\iQuestComplete.ogg" },
    { "uwarn",       L.ERROR_WARNING,             "Sound\\Interface\\Error.ogg" },
}

BS.SOUND_CHANNELS = {
    { "Master",   L.MASTER },
    { "SFX",      L.EFFECTS },
    { "Dialog",   "Dialog" },
    { "Ambience", L.AMBIENCE },
    { "Music",    L.MUSIC },
}

local function LSM()
    if not LibStub then return nil end
    local ok, lib = pcall(LibStub, "LibSharedMedia-3.0", true)
    if ok then return lib end
    return nil
end

-- Liste aller Töne, die es im laufenden Client gibt: { key, name, group }
function BS:SoundList()
    if self.soundListCache then return self.soundListCache end
    local list, byKey = {}, {}
    local hasKit = type(SOUNDKIT) == "table"
    for _, s in ipairs(KIT_SOUNDS) do
        if (hasKit and SOUNDKIT[s[1]]) or (not hasKit and s[3]) then
            local item = { key = s[1], name = s[2], group = L.GAME, kit = s[1], id = s[3] }
            tinsert(list, item); byKey[item.key] = item
        end
    end
    for _, s in ipairs(FILE_SOUNDS) do
        local item = { key = "f:" .. s[1], name = s[2], group = L.FILE, file = s[3] }
        tinsert(list, item); byKey[item.key] = item
    end
    local lib = LSM()
    if lib and lib.List then
        local ok, names = pcall(lib.List, lib, "sound")
        if ok and type(names) == "table" then
            for _, n in ipairs(names) do
                if n ~= "None" then
                    local item = { key = "lsm:" .. n, name = n, group = "SharedMedia", lsm = n }
                    tinsert(list, item); byKey[item.key] = item
                end
            end
        end
    end
    local custom = { key = "custom", name = L.CUSTOM_SOUND, group = L.CUSTOM }
    tinsert(list, custom); byKey.custom = custom
    self.soundListCache, self.soundByKey = list, byKey
    return list
end

function BS:SoundName(key, custom)
    self:SoundList()
    if key == "custom" then
        return (custom and custom ~= "") and (L.CUSTOM_2 .. tostring(custom)) or L.CUSTOM_SOUND
    end
    local item = self.soundByKey[key]
    if item then return item.name end
    if type(key) == "string" and key:find("^lsm:") then return key:sub(5) .. L.MISSING_PAREN end
    return tostring(key)
end

------------------------------------------------------------------------
-- Einstellungen pro Skillung
------------------------------------------------------------------------
local function SpecKey()
    return "spec" .. tostring(BS.mainSpec or 0)
end

-- Abweichungen der aktuellen Skillung (Testmodus mit fremder Klasse: nur vorübergehend)
function BS:SoundOverrides(create)
    if self.testClass then
        self.testSoundStore = self.testSoundStore or {}
        return self.testSoundStore
    end
    local k = SpecKey()
    local t = self.db.soundSpecs[k]
    if not t and create then t = {}; self.db.soundSpecs[k] = t end
    return t
end

-- on, sound, custom, abweichend (true = eigene Einstellung dieser Skillung)
function BS:SoundSetting(kind)
    local def = self.SOUND_KIND_BY_KEY[kind]
    if not def or not self.db then return false, nil, nil, false end
    local base = self.db.soundBase[kind] or {}
    local o = self:SoundOverrides(false)
    o = o and o[kind]
    local on, sound, custom = base.on, base.sound, base.custom
    if on == nil then on = def.on end
    if sound == nil then sound = def.sound end
    local changed = false
    if o then
        if o.on ~= nil then on = o.on; changed = true end
        if o.sound ~= nil then sound = o.sound; custom = o.custom; changed = true end
    end
    return on and true or false, sound, custom, changed
end

function BS:SetSoundSetting(kind, field, value, custom)
    local o = self:SoundOverrides(true)
    o[kind] = o[kind] or {}
    o[kind][field] = value
    if field == "sound" then o[kind].custom = custom end
    if self.optionsFrame and self.optionsFrame:IsShown() then self:RefreshOptions() end
end

-- Aktuelle Skillung als Standard für alle Skillungen dieses Charakters übernehmen
function BS:SoundApplyToAll()
    for _, k in ipairs(self.SOUND_KINDS) do
        local on, sound, custom = self:SoundSetting(k.key)
        self.db.soundBase[k.key] = { on = on, sound = sound, custom = custom }
    end
    if not self.testClass then wipe(self.db.soundSpecs) end
    BS.Print(L.ALERT_SOUNDS_NOW_APPLY_TO)
    if self.optionsFrame and self.optionsFrame:IsShown() then self:RefreshOptions() end
end

function BS:SoundResetSpec()
    local o = self:SoundOverrides(false)
    if o then wipe(o) end
    if self.optionsFrame and self.optionsFrame:IsShown() then self:RefreshOptions() end
end

function BS:SoundResetAll()
    wipe(self.db.soundBase)
    wipe(self.db.soundSpecs)
    self.testSoundStore = nil
    if self.optionsFrame and self.optionsFrame:IsShown() then self:RefreshOptions() end
end

-- Alte Einstellungen (bis 0.8.6) übernehmen: ein/aus je Art, Hupe ein/aus
function BS:MigrateSounds()
    local db = self.db
    db.soundBase = db.soundBase or {}
    db.soundSpecs = db.soundSpecs or {}
    if db.soundV3 then return end
    local old = db.sound or {}
    for _, k in ipairs({ "buff", "proc", "cooldown", "dispel" }) do
        if old[k] ~= nil then db.soundBase[k] = { on = old[k] and true or false } end
    end
    if old.dispel ~= nil then db.soundBase.dispel_imp = { on = old.dispel and true or false } end
    if db.hornSelfBuff == false then db.soundBase.horn = { on = false } end
    db.soundV3 = true
end

------------------------------------------------------------------------
-- Abspielen
------------------------------------------------------------------------
local function Fallback(ch)
    pcall(PlaySound, (SOUNDKIT and SOUNDKIT.RAID_WARNING) or 8959, ch)
end

-- true = der gewählte Ton wurde gespielt, false = Ersatzton
function BS:PlaySoundChoice(key, custom)
    if self.testMute then return self:ResolveSoundChoice(key, custom) end
    local ch = (self.db and self.db.soundChannel) or "Master"
    self:SoundList()
    if key == "custom" then
        local v = custom and (tonumber(custom) or custom)
        if v and v ~= "" and PlaySoundFile then
            local ok, will = pcall(PlaySoundFile, v, ch)
            if ok and will ~= false then return true end
        end
        Fallback(ch); return false
    end
    local item = self.soundByKey[key]
    if item and item.lsm then
        local lib = LSM()
        local ok, path = false, nil
        if lib then ok, path = pcall(lib.Fetch, lib, "sound", item.lsm, true) end
        if ok and path and PlaySoundFile then
            local ok2, will = pcall(PlaySoundFile, path, ch)
            if ok2 and will ~= false then return true end
        end
        Fallback(ch); return false
    end
    if item and item.file then
        if PlaySoundFile then
            local ok, will = pcall(PlaySoundFile, item.file, ch)
            if ok and will ~= false then return true end
        end
        Fallback(ch); return false
    end
    if item and item.kit then
        local id = (type(SOUNDKIT) == "table" and SOUNDKIT[item.kit]) or item.id
        if id then
            local ok, will = pcall(PlaySound, id, ch)
            if ok and will ~= false then return true end
        end
    end
    Fallback(ch)
    return false
end

-- Testroutine (BS.testMute): Ton nur auflösen, nicht abspielen. true = der gewählte Ton gibt es, false = Ersatzton
function BS:ResolveSoundChoice(key, custom)
    self:SoundList()
    self.testSoundCount = (self.testSoundCount or 0) + 1
    if key == "custom" then
        local v = custom and (tonumber(custom) or custom)
        return (v ~= nil and v ~= "") and true or false
    end
    local item = self.soundByKey[key]
    if not item then return false end
    if item.lsm then return LSM() ~= nil end
    if item.file then return PlaySoundFile ~= nil end
    if item.kit then
        local id = (type(SOUNDKIT) == "table" and SOUNDKIT[item.kit]) or item.id
        return id ~= nil
    end
    return false
end

-- Vorhören in den Einstellungen (mit Hinweis, wenn es den Ton im Client nicht gibt)
function BS:PreviewSound(key, custom)
    if not self:PlaySoundChoice(key, custom) then
        BS.Print(L.THIS_SOUND_DOES_NOT_EXIST)
    end
end
