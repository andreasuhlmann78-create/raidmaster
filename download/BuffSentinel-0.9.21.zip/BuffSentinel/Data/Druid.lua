-- BuffSentinel - Data/Druid.lua  (Feldbeschreibung siehe Data/Warrior.lua)
-- Achtung: Classic hat 3 Bäume (3 = Wiederherstellung), ab MoP 4 Spezialisierungen (3 = Wächter, 4 = Wiederherstellung)

local ADDON, BS = ...
local L = BS.L
BS.ClassData = BS.ClassData or {}

BS.ClassData.DRUID = {
    specNames       = { L.BALANCE, L.FERAL, L.RESTORATION },
    specNamesModern = { L.BALANCE, L.FERAL, L.GUARDIAN, L.RESTORATION },
    icon = "Interface\\Icons\\Spell_Nature_Regeneration",
    entries = {
        ----------------------------------------------------------------
        -- Classic-Familie
        ----------------------------------------------------------------
        { key = "motw",    kind = "buff", spell = 1126, group = true, groupSpell = 21849 },
        { key = "thorns",  kind = "buff", spell = 467,  specs = { 2 } },
        { key = "omen",    kind = "buff", spell = 16864, max = 2 },   -- ab Wrath passiv
        { key = "moonkin", kind = "buff", spell = 24858, specs = { 1 }, mode = "combat" },

        -- Procs
        { key = "clearcasting", kind = "proc", procAuras = { 16870 },
          spell = 2912, spellBySpec = { [1] = 2912, [2] = 5221, [3] = 8936 },
          -- Wilder Kampf: Klick wirkt je nach Gestalt Schreddern (Katze) oder Zermalmen (Bär)
          formSpellsBySpec = { [2] = { cat = 5221, bear = 6807 } },
          talents = { "Omen of Clarity", "Omen der Klarsicht" }, label = L.CLEARCASTING, alert = L.ALERT_CLEARCASTING },
        { key = "naturesgrace", kind = "proc", procAuras = { 16886 }, spell = 2912, max = 3, specs = { 1 },
          talents = { "Nature's Grace", "Anmut der Natur" }, alert = L.ALERT_STARFIRE },
        { key = "eclipse_s",  kind = "proc", procAuras = { 48517 }, spell = 5176, min = 3, specs = { 1 },
          label = L.SOLAR_ECLIPSE, alert = L.ALERT_WRATH },
        { key = "eclipse_l",  kind = "proc", procAuras = { 48518 }, spell = 2912, min = 3, specs = { 1 },
          label = L.LUNAR_ECLIPSE, alert = L.ALERT_STARFIRE },
        { key = "shootstars", kind = "proc", procAuras = { 93400 }, spell = 78674, min = 4, specs = { 1 },
          talents = { "Shooting Stars", "Sternschnuppen" }, alert = L.ALERT_STARSURGE },
        { key = "predswift",  kind = "proc", procAuras = { 69369 }, spell = 5185, min = 3, specs = { 2 },
          talents = { "Predatory Strikes", "Raubtierschläge" }, alert = L.HEALING_TOUCH },

        -- Cooldowns Gleichgewicht / Wiederherstellung
        { key = "innervate",   kind = "cd", spell = 29166, specs = { 1, 3 } },
        { key = "starfall",    kind = "cd", spell = 48505, min = 3, specs = { 1 } },
        { key = "forcenature", kind = "cd", spell = 33831, min = 2, specs = { 1 } },
        { key = "nswiftness",  kind = "cd", spell = 17116, specs = { 3 } },
        { key = "swiftmend",   kind = "cd", spell = 18562, specs = { 3 } },
        { key = "wildgrowth",  kind = "cd", spell = 48438, min = 3, specs = { 3 } },
        { key = "tranquility", kind = "cd", spell = 740, specs = { 3 } },

        -- Cooldowns Wilder Kampf
        { key = "tigersfury",  kind = "cd", spell = 5217,  specs = { 2 } },
        { key = "mangle",      kind = "cd", spell = 33878, min = 2, specs = { 2 } },
        { key = "enrage",      kind = "cd", spell = 5229,  specs = { 2 } },
        { key = "frenzied",    kind = "cd", spell = 22842, specs = { 2 } },
        { key = "bash",        kind = "cd", spell = 5211,  specs = { 2 } },
        { key = "survival",    kind = "cd", spell = 61336, min = 3, specs = { 2 } },
        { key = "berserk",     kind = "cd", spell = 50334, min = 3, specs = { 2 } },
        { key = "berserk_f",   kind = "cd", spell = "Berserk", specs = { 2 }, forever = true },

        -- Cooldowns alle
        { key = "rebirth",     kind = "cd", spell = 20484 },
        { key = "barkskin",    kind = "cd", spell = 22812 },

        ----------------------------------------------------------------
        -- Moderne Familie (MoP, Retail) – 4 Spezialisierungen
        ----------------------------------------------------------------
        { key = "m_motw",     kind = "buff", v = "modern", spell = 1126, group = true, retail = true },
        { key = "m_moonkin",  kind = "buff", v = "modern", max = 5, spell = 24858, specs = { 1 }, mode = "combat" },

        { key = "m_shootstars",kind = "proc", v = "modern", spell = 78674, procAuras = { 93400 }, specs = { 1 } },
        { key = "m_eclipse_s", kind = "proc", v = "modern", spell = 5176, procAuras = { 48517 }, specs = { 1 }, label = L.SOLAR_ECLIPSE },
        { key = "m_eclipse_l", kind = "proc", v = "modern", spell = 2912, procAuras = { 48518 }, specs = { 1 }, label = L.LUNAR_ECLIPSE },
        { key = "m_predswift", kind = "proc", v = "modern", spell = 5185, procAuras = { 69369 }, specs = { 2 } },
        { key = "m_omen",      kind = "proc", v = "modern", procAuras = { 16870 }, spell = 5221,
          spellBySpec = { [2] = 5221, [3] = 6807, [4] = 8936 }, specs = { 2, 3, 4 }, label = L.CLEARCASTING, alert = L.ALERT_CLEARCASTING },
        { key = "m_toothclaw", kind = "proc", v = "modern", spell = 6807, procAuras = { 135286 }, specs = { 3 } },

        { key = "m_starfall",  kind = "cd", v = "modern", spell = 48505, specs = { 1 } },
        { key = "m_celestial", kind = "cd", v = "modern", spell = 112071, specs = { 1 } },
        { key = "m_solarbeam", kind = "cd", v = "modern", spell = 78675, specs = { 1 } },
        { key = "m_tigersfury",kind = "cd", v = "modern", spell = 5217, specs = { 2 } },
        { key = "m_berserk",   kind = "cd", v = "modern", spell = 106952, specs = { 2, 3 } },
        { key = "m_survival",  kind = "cd", v = "modern", spell = 61336, specs = { 2, 3 } },
        { key = "m_mangle",    kind = "cd", v = "modern", spell = 33878, specs = { 3 } },
        { key = "m_savdef",    kind = "cd", v = "modern", spell = 62606, specs = { 3 } },
        { key = "m_frenzied",  kind = "cd", v = "modern", spell = 22842, specs = { 3 } },
        { key = "m_skullbash", kind = "cd", v = "modern", spell = 106839, specs = { 2, 3 } },
        { key = "m_swiftmend", kind = "cd", v = "modern", spell = 18562, specs = { 4 } },
        { key = "m_wildgrowth",kind = "cd", v = "modern", spell = 48438, specs = { 4 } },
        { key = "m_ironbark",  kind = "cd", v = "modern", spell = 102342, specs = { 4 } },
        { key = "m_tranq",     kind = "cd", v = "modern", spell = 740, specs = { 4 } },
        { key = "m_innervate", kind = "cd", v = "modern", spell = 29166 },
        { key = "m_rebirth",   kind = "cd", v = "modern", spell = 20484 },
        { key = "m_barkskin",  kind = "cd", v = "modern", spell = 22812 },
        { key = "m_incarn",    kind = "cd", v = "modern", spell = 106731 },
        { key = "m_nswift",    kind = "cd", v = "modern", spell = 132158 },
        { key = "m_hotw",      kind = "cd", v = "modern", spell = 108288 },
        { key = "m_roar",      kind = "cd", v = "modern", spell = 106898 },
    },
}
