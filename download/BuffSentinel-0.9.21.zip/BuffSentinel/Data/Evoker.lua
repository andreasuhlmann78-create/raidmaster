-- BuffSentinel - Data/Evoker.lua  (nur Retail; Feldbeschreibung siehe Data/Warrior.lua)

local ADDON, BS = ...
local L = BS.L
BS.ClassData = BS.ClassData or {}

BS.ClassData.EVOKER = {
    specNames       = { L.DEVASTATION, L.PRESERVATION, L.AUGMENTATION },
    specNamesModern = { L.DEVASTATION, L.PRESERVATION, L.AUGMENTATION },
    icon = "Interface\\Icons\\ClassIcon_Evoker",
    entries = {
        -- Segen der Bronze: Gruppenbuff (Retail: Erinnerung ausserhalb des Kampfes)
        { key = "r_bronze", kind = "buff", v = "modern", min = 12, retail = true, retailOnly = true,
          spell = 364342, group = true },
    },
}
