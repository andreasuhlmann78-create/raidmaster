-- GuildSentinel - Test.lua
-- Testmodus: füllt GuildSentinel mit einer erfundenen Gilde, damit man alle Seiten ausprobieren kann – auch
-- allein, ohne Gilde oder bevor der Server startet.
--   * Mitglieder mit Twinks, Zonen, Rängen, Abwesenheit, Paten, Verlauf, Online-Zeiten
--   * Brett (Dienste, Biete/Suche), Termine, Umfrage, Gruppensuche, Berufe, Abklingzeiten, Zugänge,
--     Dank-Punkte, Wochenziel, Meilensteine, Bewerber, Gildenregeln, Addons der Mitglieder
--   * Knöpfe für Ereignisse: neuer Termin, passendes Angebot, Twink schreibt im Gildenchat, Stufenaufstieg …
-- Im Testmodus wird nichts gesendet: kein Addon-Abgleich, kein Gildenchat, kein Flüstern, keine Einladung,
-- keine Gildennotiz. Was sonst hinausginge, steht mit [Test] im Chatfenster. Die echten Daten bleiben
-- unberührt (die Testgilde wird nicht gespeichert) und sind nach "Testmodus beenden" wieder da.

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local T = {}
ns.Test = T

T.active = false
local ORANGE = "|cffff9933"

function T:Active()
	return self.active
end

function T:GuildName()
	return L["Testgilde"]
end

-- was im Testmodus hinausginge: nur anzeigen
function T:Log(kind, target, text)
	local where
	if kind == "GUILD" then where = L["Gildenchat"]
	elseif kind == "WHISPER" then where = string.format(L["Flüstern an %s"], tostring(target))
	elseif kind == "CHANNEL" then where = string.format(L["Kanal %s"], tostring(target))
	elseif kind == "ACTION" then where = L["Aktion"]
	else where = tostring(kind) end
	ns:Print(ORANGE .. "[Test]|r " .. where .. ": " .. tostring(text))
end

------------------------------------------------------------
-- Die Testgilde
------------------------------------------------------------
local function Max() return ns.Roster.MAX_LEVEL end

-- Zonen je Version und Sprache
local function Zones()
	local horde = (UnitFactionGroup and UnitFactionGroup("player")) ~= "Alliance"
	local de = ns.lang == "de"
	local capital = horde and "Orgrimmar" or (de and "Sturmwind" or "Stormwind City")
	if ns.Game.TBC then
		if de then return { "Shattrath", "Nagrand", "Höllenfeuerhalbinsel", "Zangarmarschen", "Brachland", "Eschental", capital } end
		return { "Shattrath City", "Nagrand", "Hellfire Peninsula", "Zangarmarsh", "The Barrens", "Ashenvale", capital }
	end
	if de then return { capital, "Schwarzfelsspitze", "Winterquell", "Östliche Pestländer", "Brachland", "Eschental", "Tanaris" } end
	return { capital, "Blackrock Spire", "Winterspring", "Eastern Plaguelands", "The Barrens", "Ashenvale", "Tanaris" }
end

local RANKS = { N["Gildenmeister"], N["Offizier"], N["Veteran"], N["Mitglied"], N["Rekrut"] }

-- Mitglieder: Name, Klasse, Stufe ("M" = Höchststufe, "M-2" …), Rang (0 = Gildenmeister), Zone, online, Tage offline, Notiz
local function Members()
	local horde = (UnitFactionGroup and UnitFactionGroup("player")) ~= "Alliance"
	local hybrid = (ns.Game.BOTH_HYBRIDS or not horde) and "PALADIN" or "SHAMAN"
	local hybrid2 = (ns.Game.BOTH_HYBRIDS or horde) and "SHAMAN" or "PALADIN"
	local list = {
		{ "Rokan", "PRIEST", "M", 1, 1, true },
		{ "Mira", "MAGE", "M", 2, 1, true },
		{ "Grom", "WARRIOR", "M", 2, 2, true },
		{ "Thalia", "DRUID", "M", 2, 3, true },
		{ "Velka", "WARLOCK", "M", 2, 2, true },
		{ "Zarg", "ROGUE", "M-2", 3, 4, true },
		{ "Kaelis", hybrid, "M", 3, 1, true },
		{ "Sheyla", hybrid2, "M-1", 3, 3, false, 1 },
		{ "Tok", "HUNTER", "M", 3, 1, false, 2 },
		{ "Brann", "HUNTER", 47, 3, 5, false, 45 },
		{ "Ylva", "PRIEST", 52, 3, 5, false, 4 },
		{ "Durok", "WARRIOR", 34, 4, 5, true },
		{ "Lowbie", "DRUID", 29, 4, 6, true },
		{ "Neuling", "ROGUE", 14, 4, 6, true },
		{ "Rokwar", "WARRIOR", 41, 3, 5, false, 6, N["Twink von Rokan"] },
		{ "Mirabank", "MAGE", 6, 4, 7, false, 3, N["Bank – Twink von Mira"] },
		{ "Gromsham", hybrid2, 38, 3, 6, true, nil, N["Twink von Grom"] },
	}
	local out = {}
	local zones = Zones()
	-- ich selbst als Gildenmeister
	local _, cf = UnitClass("player")
	out[1] = { name = ns.Me(), class = cf, level = UnitLevel("player") or Max(), ri = 0, zone = GetRealZoneText and GetRealZoneText() or zones[1], online = true, off = 0, note = "" }
	for _, m in ipairs(list) do
		local lv = m[3]
		if lv == "M" then lv = Max()
		elseif type(lv) == "string" then lv = Max() - tonumber(lv:match("%-(%d+)")) end
		if ns.Game.TBC and type(m[3]) == "number" and m[3] >= 30 then lv = m[3] + 10 end
		out[#out + 1] = { name = m[1], class = m[2], level = lv, ri = m[4], zone = zones[m[5]] or "", online = m[6], off = (m[7] or 0) * 86400 + 3600,
			note = m[8] and L[m[8]] or "" }
	end
	return out
end

-- Daten für Roster:Scan() (gleiche Rückgaben wie GetGuildRosterInfo / GetGuildRosterLastOnline)
function T:RosterAPI()
	local m = self.members or {}
	local function Info(i)
		local e = m[i]
		if not e then return nil end
		return e.name .. "-Test", L[RANKS[e.ri + 1]], e.ri, e.level, e.class, e.online and e.zone or "", e.note or "", "", e.online, 0, e.class
	end
	local function LastOnline(i)
		local e = m[i]
		if not e or e.online then return nil end
		local d = math.floor(e.off / 86400)
		local h = math.floor((e.off % 86400) / 3600)
		return 0, 0, d, h
	end
	return #m, Info, LastOnline
end

function T:Member(name)
	for _, e in ipairs(self.members or {}) do if e.name == name then return e end end
end

------------------------------------------------------------
-- Daten der Testgilde
------------------------------------------------------------
local function Fill(g)
	local now = ns.Now()
	local day = 86400
	local me = ns.Me()
	local max = Max()
	local tbc = ns.Game.TBC

	-- Rollen
	g.roles.Grom = { r = "tank", t = now }
	g.roles.Thalia = { r = "tank", t = now }
	g.roles.Rokan = { r = "heal", t = now }
	g.roles.Kaelis = { r = "heal", t = now }

	-- Beitritt (Jubiläen, Beförderung) und Online-Tage der letzten zwei Wochen
	local joined = { Rokan = 400, Mira = 200, Grom = 190, Thalia = 95, Velka = 60, Zarg = 45, Kaelis = 31, Sheyla = 20, Tok = 120,
		Brann = 150, Ylva = 70, Durok = 40, Lowbie = 33, Neuling = 3, Rokwar = 380, Mirabank = 180, Gromsham = 150 }
	for name, d in pairs(joined) do g.firstSeen[name] = now - d * day end
	local today = math.floor(now / day)
	for _, e in ipairs(T.members) do
		g.days[e.name] = {}
		local every = (e.name == "Durok" or e.name == "Lowbie" or e.name == "Rokan" or e.name == "Mira") and 1 or 3
		if not (e.name == "Brann") then
			for d = 0, 13, every do g.days[e.name][today - d] = true end
		end
	end

	-- Online-Zeiten: abends viel los, am Wochenende mehr
	for d = 0, 13 do
		for h = 0, 23 do
			local base = (h >= 18 and h <= 23) and 8 or ((h >= 12 and h < 18) and 4 or ((h < 2) and 3 or 1))
			local wd = tonumber(date("%w", now - d * day))
			if wd == 0 or wd == 6 then base = base + 3 end
			if wd == 3 and h >= 19 and h <= 22 then base = base + 4 end   -- Mittwoch: Raid
			local slot = math.floor((now - d * day - (now % day) + h * 3600) / 1800)
			g.act[slot] = base + ((h + d) % 3)
			g.act[slot + 1] = base + ((h + d + 1) % 3)
		end
	end

	-- Verlauf
	g.log = {
		{ t = now - 3 * day, k = "join", n = "Neuling" },
		{ t = now - 5 * day, k = "promote", n = "Durok", x = L[RANKS[4]] },
		{ t = now - 8 * day, k = "maxlevel", n = "Velka", x = max },
		{ t = now - 10 * day, k = "leave", n = "Altpaul" },
		{ t = now - 12 * day, k = "join", n = "Lowbie" },
	}

	-- Abwesenheit und Pate
	g.away.Ylva = { u = now + 10 * day, note = L["Urlaub"], t = now - day, by = "Ylva" }
	g.mentor.Neuling = { m = "Rokan", t = now - 2 * day, by = me }

	-- Dank-Punkte
	local thx = { { "Mira", "Rokan", 1, L["Heilung in der Instanz"] }, { "Grom", "Rokan", 3, "" }, { "Neuling", "Rokan", 2, L["Hilfe bei der Quest"] },
		{ "Rokan", "Mira", 1, L["Portal"] }, { "Zarg", "Mira", 4, "" }, { "Lowbie", "Grom", 2, L["Tank in der Instanz"] }, { "Velka", "Thalia", 5, "" },
		{ "Rokan", me, 1, L["Danke für die Gilde!"] } }
	for i, x in ipairs(thx) do
		local id = "test" .. i
		g.thanks[id] = { id = id, from = x[1], to = x[2], t = now - x[3] * day, why = x[4] }
	end

	-- Berufe: Rezepte aus der Liste wichtiger Raid-Rezepte – bewusst mit Lücken
	local imp = ns.Craft.IMPORTANT
	local byProf = {}
	for _, x in ipairs(imp) do byProf[x.p] = byProf[x.p] or {}; table.insert(byProf[x.p], x.i) end
	local function Prof(name, class, spell, take)
		local items = {}
		for i, id in ipairs(byProf[spell] or {}) do if i <= take then items[#items + 1] = id end end
		local names = {}
		for _, id in ipairs(items) do names[#names + 1] = ns.Craft:ItemName(id) end
		local rank = tbc and 375 or 300
		g.prof[name] = g.prof[name] or { c = class, t = now, p = {} }
		g.prof[name].p[ns.Craft:ProfName(spell)] = { r = rank, m = rank, n = names, i = items }
	end
	Prof("Thalia", "DRUID", ns.Craft.ALCHEMY, 8)
	Prof("Rokan", "PRIEST", ns.Craft.TAILORING, 3)
	Prof("Grom", "WARRIOR", ns.Craft.BLACKSMITHING, 2)
	Prof("Grom", "WARRIOR", ns.Craft.MINING, 2)
	Prof("Zarg", "ROGUE", ns.Craft.ENGINEERING, 1)

	-- Herstellungswunsch
	local want = imp[1]
	if want then
		g.creq.test1 = { id = "test1", by = "Lowbie", i = want.i, n = ns.Craft:ItemName(want.i), c = 5, note = L["für den Raid"], t = now - 3600, u = now - 3600 }
	end

	-- Zugänge und Schlüssel
	local att = ns.Attune.LIST
	local function Att(name, n)
		local k = {}
		for i, a in ipairs(att) do if i <= n then k[a.key] = true end end
		g.attune[name] = { t = now, k = k }
	end
	Att("Rokan", #att); Att("Mira", 4); Att("Grom", 3); Att("Thalia", 5); Att("Velka", 2); Att("Kaelis", 1)

	-- Stufen der letzten Tage (Leveling-Rennen, Wochenziel)
	-- Aufstiege der letzten Stunden (liegen damit sicher in "diese Woche" und in "letzte 7 Tage")
	local weekStart = ns.Goals:WeekStart()
	local function Ups(name, from, to, hoursAgo)
		g.levels[name] = g.levels[name] or {}
		for l = from, to do
			local t = now - hoursAgo * 3600 + (l - from) * 600
			g.levels[name][l] = math.max(t, weekStart + 60)
		end
	end
	local function Lv(n) return T:Member(n) and T:Member(n).level or 1 end
	Ups("Neuling", 2, Lv("Neuling"), 2)
	Ups("Lowbie", Lv("Lowbie") - 4, Lv("Lowbie"), 1)
	Ups("Durok", Lv("Durok") - 3, Lv("Durok"), 1)
	Ups("Zarg", Lv("Zarg") - 1, Lv("Zarg"), 0)
	Ups("Gromsham", Lv("Gromsham") - 2, Lv("Gromsham"), 3)
	g.race.first60 = { n = "Rokan", t = now - 120 * day }

	-- Wochenziel und Meilensteine
	g.goal = { target = 30, t = now - day, by = me }
	g.milesInit = true
	g.milesText = {}
	local miles = {
		{ "max:1", string.format(L["Das erste Gildenmitglied ist auf Stufe %d"], max), 120 },
		{ "mem:10", string.format(L["%d Spieler in der Gilde"], 10), 120 },
	}
	for _, m in ipairs(miles) do g.miles[m[1]] = now - m[3] * day; g.milesText[m[1]] = m[2] end

	-- Termine
	local function At(daysAhead, h, m)
		local d = date("*t", now + daysAhead * day)
		return time({ year = d.year, month = d.month, day = d.day, hour = h, min = m or 0, sec = 0 })
	end
	g.events.test1 = { id = "test1", by = "Grom", title = L["PvP-Abend"], kind = "pvp", t = At(1, 20), d = 120, note = L["Treffpunkt: Tor von Orgrimmar"], u = now,
		r = { Grom = { s = "yes", t = now }, Zarg = { s = "yes", t = now }, Mira = { s = "maybe", t = now }, Tok = { s = "no", t = now } } }
	g.events.test2 = { id = "test2", by = "Rokan", title = L["Gildentreffen"], kind = "meet", t = At(3, 19, 30), d = 60, note = "", u = now,
		r = { Rokan = { s = "yes", t = now }, Thalia = { s = "yes", t = now }, Velka = { s = "yes", t = now }, Lowbie = { s = "maybe", t = now } } }
	g.events.test3 = { id = "test3", by = "Mira", title = L["Weltboss"], kind = "worldboss", t = now + 2 * 3600, d = 90, note = "", u = now,
		r = { Mira = { s = "yes", t = now }, [me] = { s = "yes", t = now } } }

	-- Brett: Dienste
	local function Has(key) return ns.Board.BY_KEY[key] ~= nil end
	local horde = (UnitFactionGroup and UnitFactionGroup("player")) ~= "Alliance"
	local mk, n = {}, 0
	for _, s in ipairs(ns.Board.SERVICES) do
		if s.class == "MAGE" and n < 3 and not (s.horde and not horde) and not (s.alliance and horde) then mk[s.key] = true; n = n + 1 end
	end
	g.svc.Mira = { t = now - 600, u = now + 3600, k = mk, x = "" }
	g.svc.Velka = { t = now - 300, u = now + 5400, k = { summon = Has("summon") or nil, soulstone = Has("soulstone") or nil }, x = L["Beschwöre zum Weltboss"] }

	-- Brett: Biete/Suche (Items je Version)
	local cloth, clothN = T:Item("cloth")
	local bar, barN = T:Item("bar")
	local herb, herbN = T:Item("herb")
	local function Mkt(id, by, kind, item, count, price, note, ago)
		local name = select(2, T:ItemByID(item))
		g.market[id] = { id = id, by = by, k = kind, i = item, n = name, c = count, p = price, note = note or "", t = now - ago, u = now - ago }
	end
	Mkt("m1", "Rokan", "offer", cloth, 60, 0, L["gratis für Gildenmitglieder"], 3600)
	Mkt("m2", "Grom", "want", bar, 20, 15000, "", 7200)
	Mkt("m3", "Thalia", "offer", herb, 12, 30000, L["VB"], 86400)
	Mkt("m4", "Zarg", "want", cloth, 40, 0, "", 1800)

	-- Abklingzeiten
	local keys = {}
	for _, c in ipairs(ns.Cooldowns.LIST) do keys[#keys + 1] = c.key end
	-- Transmutation: Alchemistin Thalia; Mondstoff: Schneider Rokan; Salzstreuer: Grom (Lederer)
	g.cds.Thalia = { t = now, k = { [keys[1]] = now + 5 * 3600 } }
	g.cds.Rokan = { t = now, k = { [keys[2] or keys[1]] = 0 } }
	g.cds.Grom = { t = now, k = { [keys[#keys]] = now + 2 * 86400 } }

	-- Gruppensuche (passt zu Stufe und Rolle, damit man mitkommen kann)
	local act = tbc and "sv" or "strat"
	g.lfg.test1 = { id = "test1", by = "Thalia", c = "DRUID", l = max, act = act, note = L["Brauche noch Heiler und Schaden"], roles = { heal = true, dps = true },
		need = 2, t = now - 300, exp = now + 3300, joins = {}, scope = "guild", gn = L["Testgilde"], z = Zones()[3] }

	-- Umfrage
	g.polls.test1 = { id = "test1", by = "Rokan", q = L["Raid lieber Mittwoch oder Donnerstag?"], o = { L["Mittwoch"], L["Donnerstag"], L["Egal"] },
		t = now - 3600, exp = now + 2 * day, votes = { Rokan = { o = 1, t = now }, Grom = { o = 1, t = now }, Thalia = { o = 2, t = now }, Zarg = { o = 3, t = now } } }

	-- Gildenregeln (selbst schon bestätigt, damit kein Fenster aufgeht)
	g.rules = { v = 1, t = now - 20 * day, by = "Rokan", text = L["1. Respektvoller Umgang.\n2. Raidtermine: Mittwoch und Sonntag 20 Uhr.\n3. Beute nach DKP (RaidMaster)."] }
	g.rulesAck = { [me] = { v = 1, t = now }, Rokan = { v = 1, t = now }, Mira = { v = 1, t = now }, Grom = { v = 1, t = now } }

	-- Bewerber
	g.apps.Fremdling = { t = now - 7200, last = now - 7000, st = "new", c = "PRIEST", msg = L["Hallo, sucht ihr noch Mitglieder? Ich bin Heiler."],
		qdone = now - 6000, qa = { { q = L["Welche Klasse und Skillung spielst du?"], a = L["Priester, Heilig"] }, { q = L["Wann hast du meistens Zeit?"], a = L["Abends ab 19 Uhr"] } } }

	-- Leitung: Offiziersnotizen, Abgänge, Online-Zeiten je Spieler
	g.onotes.Durok = {
		n1 = { id = "n1", t = now - 9 * day, by = "Rokan", text = L["Zuverlässig, kommt immer pünktlich zu Terminen."] },
		n2 = { id = "n2", t = now - 2 * day, by = me, text = L["Möchte Tank werden – Raid-Kandidat."] },
	}
	g.onotes.Neuling = { n3 = { id = "n3", t = now - day, by = "Rokan", text = L["Über die Werbung im Handelskanal gekommen."] } }
	g.gone.Altpaul = { t = now - 10 * day, k = "leave", l = max - 2, c = "HUNTER", r = L[RANKS[4]], reason = L["zu einer Raid-Gilde gewechselt"], rt = now - 9 * day }
	g.gone.Stoerenfried = { t = now - 25 * day, k = "kick", l = 31, c = "ROGUE", r = L[RANKS[5]], reason = "", rt = 0 }
	for _, e in ipairs(T.members) do
		local h = {}
		local evening = e.name ~= "Tok" and e.name ~= "Zarg"
		for wd = 0, 6 do
			for hr = (evening and 18 or 9), (evening and 23 or 15) do h[wd * 24 + hr] = 3 + (#e.name + hr) % 4 end
		end
		g.hours[e.name] = h
	end

	-- vergangene Termine (Chronik, Erfolge, Probezeit)
	for i = 1, 3 do
		local id = "past" .. i
		g.events[id] = { id = id, by = "Grom", title = L["Dungeon-Nacht"], kind = "dungeon", t = now - i * 5 * day, d = 120, note = "", u = now,
			r = { Grom = { s = "yes", t = now }, Lowbie = { s = "yes", t = now }, Neuling = { s = "yes", t = now }, Zarg = { s = "yes", t = now } } }
	end

	-- Beute-Wünsche und Fragen
	local dun1 = ns.Game.TBC and "sv" or "strat"
	local dun2 = ns.Game.TBC and "sh" or "scholo"
	g.gear.g1 = { id = "g1", by = "Grom", i = 0, n = L["Schild der Wächter"], act = dun1, t = now - day, u = now - day }
	g.gear.g2 = { id = "g2", by = "Zarg", i = 0, n = L["Dolch der Schatten"], act = dun1, t = now - 2 * day, u = now - 2 * day }
	g.gear.g3 = { id = "g3", by = "Mira", i = 0, n = L["Robe des Erzmagiers"], act = dun2, t = now - 3 * day, u = now - 3 * day }
	g.ask.q1 = { id = "q1", by = "Lowbie", q = L["Wo lerne ich das Reiten?"], t = now - 5 * 3600, u = now - 3 * 3600,
		answers = { Rokan = { t = now - 4 * 3600, a = L["Beim Reitlehrer deines Volkes, ab Stufe 30 (Classic: 40)."] } } }
	g.ask.q2 = { id = "q2", by = "Neuling", q = L["Wer kann mir eine Tasche nähen?"], t = now - 3600, u = now - 3600, answers = {} }

	-- Addons der Mitglieder (GoldSentinel)
	g.addons.Rokan = { t = now, a = { RaidMaster = "3.0.4", ThreatSentinel = "1.1.0" } }
	g.addons.Mira = { t = now, a = { AHAnalyzerPro = "0.60.0", RaidMaster = "3.0.3" } }
	g.addons.Grom = { t = now, a = { ThreatSentinel = "1.1.0", BuffSentinel = "0.6.0" } }
	g.addons.Lowbie = { t = now, a = { LevelPilot = "3.4.0" } }
end

-- Gegenstände für das Brett (Name aus dem Spiel, sonst der eingebaute)
T.ITEMS = {
	cloth = { 14047, N["Runenstoff"], 21877, N["Netherstoff"] },
	bar = { 12359, N["Thoriumbarren"], 23445, N["Teufelseisenbarren"] },
	herb = { 13464, N["Goldener Sansam"], 22785, N["Teufelsgras"] },
}
function T:Item(key)
	local x = self.ITEMS[key]
	local id, n = x[1], x[2]
	if ns.Game.TBC then id, n = x[3], x[4] end
	return id, (ns.Item(id)) or L[n]
end
function T:ItemByID(id)
	for key, x in pairs(self.ITEMS) do
		if x[1] == id or x[3] == id then return self:Item(key) end
	end
	return id, (ns.Item(id)) or ("item:" .. id)
end

-- erfundener nächster Raid (für die Termine) und Erstkills (für die Meilensteine)
function T:FakeRaid()
	-- feste Zeit (übermorgen 20 Uhr), damit der Termin nicht bei jedem Öffnen springt
	if not self.raidTime then
		local d = date("*t", ns.Now() + 2 * 86400)
		self.raidTime = time({ year = d.year, month = d.month, day = d.day, hour = 20, min = 0, sec = 0 })
	end
	return { title = ns.Game.TBC and L["Karazhan"] or L["Geschmolzener Kern"], t = self.raidTime, signed = 14, max = ns.Game.RAID_SIZE }
end

------------------------------------------------------------
-- Ein- und ausschalten
------------------------------------------------------------
local ALL_EVENTS = { "GS_GUILD", "GS_ROSTER", "GS_LOG", "GS_SOCIAL", "GS_BOARD", "GS_EVENTS", "GS_CD", "GS_GOALS", "GS_LFG", "GS_POLL",
	"GS_PROF", "GS_CRAFT", "GS_ATTUNE", "GS_PROGRESS", "GS_ACTIVITY", "GS_PROMO", "GS_COMP", "GS_RULES", "GS_APPS", "GS_RECRUIT",
	"GS_ADDONS", "GS_USERS", "GS_SYNC", "GS_ITEMS" }

local function FireAll()
	for _, e in ipairs(ALL_EVENTS) do ns:Fire(e) end
	ns:Fire("GS_TEST")
end

function T:Start()
	if self.active then return end
	self.real = {
		guild = ns.guild, key = ns.guildKey, list = ns.Roster.list, byName = ns.Roster.byName, scans = ns.Roster.scans,
		users = ns.Comm.users,
	}
	self.active = true
	local g = {}
	ns.MergeDefaults(g, ns.guildDefaults)
	ns.guild, ns.guildKey = g, "TEST"
	local _, cf = UnitClass("player")
	g.mine[ns.Me()] = { c = cf, l = UnitLevel("player") }
	self.members = Members()
	ns.Roster.list, ns.Roster.byName, ns.Roster.scans = {}, {}, 0
	ns.Roster:Scan()                                    -- erster Lauf: nimmt die Testgilde auf (ohne Verlauf)
	Fill(g)
	-- wer "mit GuildSentinel online" ist
	ns.Comm.users = {}
	for _, n in ipairs({ "Rokan", "Mira", "Grom", "Thalia", "Velka", "Zarg", "Lowbie" }) do ns.Comm.users[n] = { v = ns.version, t = ns.Now() } end
	ns:Print(ORANGE .. L["Testmodus gestartet – erfundene Gilde, nichts wird gesendet."] .. "|r")
	FireAll()
end

function T:Stop()
	if not self.active then return end
	self.active = false
	local r = self.real or {}
	ns.guild, ns.guildKey = r.guild, r.key
	ns.Roster.list, ns.Roster.byName, ns.Roster.scans = r.list or {}, r.byName or {}, r.scans
	ns.Comm.users = r.users or {}
	self.real, self.members, self.raidTime = nil, nil, nil
	if ns.GuildRoster and IsInGuild() then ns.GuildRoster() end
	ns:Print(ORANGE .. L["Testmodus beendet – deine echten Daten sind wieder da."] .. "|r")
	FireAll()
end

-- beim Ausloggen nie im Testmodus speichern (die Testgilde gehört nicht in die Speicherdatei)
ns:On("PLAYER_LOGOUT", function() if T.active then T:Stop() end end)

------------------------------------------------------------
-- Ereignisse auslösen
------------------------------------------------------------
local function Handler(msgType) return ns.Comm.handlers[msgType] end

T.EVENTS = {
	{ key = "event", n = N["Neuer Termin kommt rein"] },
	{ key = "remind", n = N["Termin beginnt gleich (Erinnerung)"] },
	{ key = "market", n = N["Passendes Angebot am Brett"] },
	{ key = "chat", n = N["Twink schreibt im Gildenchat"] },
	{ key = "online", n = N["Twink kommt online"] },
	{ key = "lfg", n = N["Passende Gruppensuche"] },
	{ key = "thanks", n = N["Jemand dankt dir"] },
	{ key = "level", n = N["Stufenaufstieg mit Ansage"] },
	{ key = "milestone", n = N["Gilden-Meilenstein erreicht"] },
	{ key = "applicant", n = N["Neuer Bewerber flüstert"] },
	{ key = "poll", n = N["Neue Umfrage"] },
	{ key = "cooldown", n = N["Abklingzeit wird bereit"] },
}

local counter = 0

function T:Trigger(key)
	if not self.active then ns:Print(L["Zuerst den Testmodus starten."]) return end
	counter = counter + 1
	local now = ns.Now()
	local g = ns.guild
	if key == "event" then
		Handler("EVT")("Velka", { id = "trig" .. counter, by = "Velka", title = L["Dungeon-Nacht"], kind = "dungeon", t = now + 86400 + 7200, d = 150,
			note = L["Wer kommt mit?"], u = now })
	elseif key == "remind" then
		local id = "rem" .. counter
		g.events[id] = { id = id, by = "Grom", title = L["PvP-Abend"], kind = "pvp", t = now + 10 * 60, d = 60, note = "", u = now,
			r = { [ns.Events:Voter(ns.Me())] = { s = "yes", t = now } } }
		ns.Events:CheckReminders()
		ns:Fire("GS_EVENTS")
	elseif key == "market" then
		-- erst ein eigenes Angebot, dann sucht jemand genau das
		local item, name = T:Item("cloth")
		ns.Board:Post("offer", item, name, 20, 0, "")
		Handler("MKT")("Lowbie", { e = { ["trig" .. counter] = { id = "trig" .. counter, by = "Lowbie", k = "want", i = item, n = name, c = 10, t = now, u = now } } })
	elseif key == "chat" then
		local _, text = ns.Social.ChatFilter(nil, "CHAT_MSG_GUILD", L["Hat jemand Lust auf eine Instanz?"], "Gromsham-Test")
		local info = ChatTypeInfo and ChatTypeInfo["GUILD"]
		local line = "[" .. L["Gilde"] .. "] [Gromsham]: " .. (text or L["Hat jemand Lust auf eine Instanz?"])
		if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage(line, info and info.r or 0.25, info and info.g or 1, info and info.b or 0.25) end
		if not text then ns:Print(L["(Main-Namen im Gildenchat sind ausgeschaltet.)"]) end
	elseif key == "online" then
		local fmt = ERR_FRIEND_ONLINE_SS or "|Hplayer:%s|h[%s]|h has come online."
		local msg = string.format(fmt, "Rokwar", "Rokwar")
		local _, text = ns.Social.SystemFilter(nil, "CHAT_MSG_SYSTEM", msg)
		local info = ChatTypeInfo and ChatTypeInfo["SYSTEM"]
		if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage(text or msg, info and info.r or 1, info and info.g or 1, info and info.b or 0) end
		local e = self:Member("Rokwar")
		if e then e.online = true; ns.Roster:Scan() end
	elseif key == "lfg" then
		local role = ns.Group:MyRole()
		Handler("LFG")("Zarg", { id = "trig" .. counter, by = "Zarg", c = "ROGUE", l = Max(), act = "quest",
			note = L["Noch einer fehlt!"], roles = { [role] = true }, need = 1, t = now, exp = now + 3600, scope = "guild" }, "GUILD")
	elseif key == "thanks" then
		Handler("THX")("Thalia", { id = "trig" .. counter, from = "Thalia", to = ns.Me(), t = now, why = L["fürs Tanken"] })
	elseif key == "level" then
		-- genau eine Figur steigt genau eine Stufe auf – bevorzugt eine, die damit einen Meilenstein erreicht
		local ms = {}
		for _, l in ipairs(ns.Game.MILESTONES) do ms[l] = true end
		local pick
		for _, e in ipairs(self.members) do
			if e.online and e.level < Max() and ms[e.level + 1] and e.name ~= ns.Me() then pick = e break end
		end
		pick = pick or self:Member("Lowbie")
		if pick and pick.level < Max() then
			pick.level = pick.level + 1
			ns.Roster:Scan()
		end
	elseif key == "milestone" then
		-- zwei neue Mitglieder auf Höchststufe -> "5 Mitglieder auf Stufe x"
		for _, n in ipairs({ "Zarg", "Sheyla", "Ylva", "Durok" }) do
			local e = self:Member(n)
			if e then e.level = Max() end
		end
		ns.Roster:Scan()
		ns.Goals:CheckMiles()
	elseif key == "applicant" then
		ns.Recruit.OnWhisper(L["Hallo! Sucht eure Gilde noch Leute?"] .. " gilde guild", "Wanderer" .. counter .. "-Test", nil)
	elseif key == "poll" then
		Handler("POLL")("Rokan", { id = "trig" .. counter, by = "Rokan", q = L["Neues Gildenwappen?"], o = { L["Ja"], L["Nein"] }, t = now, exp = now + 86400, votes = {} })
	elseif key == "cooldown" then
		-- Thalias Transmutation wird bereit (sie ist die Alchemistin der Testgilde)
		local c = ns.Cooldowns.LIST[1]
		if c then
			g.cds.Thalia = { t = now, k = { [c.key] = 0 } }
			ns:Print(string.format(L["%s: %s ist bereit."], "Thalia", L[c.n]))
			ns:Fire("GS_CD")
		end
	end
end

------------------------------------------------------------
-- Alles durchklicken: jede Seite, jeden Reiter und jedes Ereignis einmal – mit Fehlerbericht
------------------------------------------------------------
function T:RunAll()
	if not self.active then self:Start() end
	local UI = ns.UI
	if not UI.frame then UI:Build() end
	UI.frame:Show()
	local errors, pages, tabs = {}, 0, 0
	local function Try(what, fn, ...)
		local ok, err = pcall(fn, ...)
		if not ok then errors[#errors + 1] = what .. ": " .. tostring(err) end
	end
	for i, page in ipairs(UI.pages) do
		if UI:PageOn(page) then
			pages = pages + 1
			Try(L[page.title], function() UI:Select(i) end)
			for _, bar in ipairs(UI.tabBars or {}) do
				if bar:GetParent() == UI.panels[i] then
					for _, b in ipairs(bar.buttons) do
						if bar:IsVisible(b.key) then
							tabs = tabs + 1
							Try(L[page.title] .. " > " .. tostring(b.text:GetText()), function() bar:Select(b.key) end)
						end
					end
				end
			end
		end
	end
	for _, ev in ipairs(self.EVENTS) do Try(L[ev.n], function() self:Trigger(ev.key) end) end
	UI:Open("settings", "test")
	if #errors == 0 then
		ns:Print(ORANGE .. "[Test]|r " .. string.format(L["Alles durchgeklickt: %d Seiten, %d Reiter, %d Ereignisse – keine Fehler."], pages, tabs, #self.EVENTS))
	else
		ns:Print(ORANGE .. "[Test]|r " .. string.format(L["Alles durchgeklickt: %d Seiten, %d Reiter, %d Ereignisse – %d Fehler:"], pages, tabs, #self.EVENTS, #errors))
		for _, e in ipairs(errors) do ns:Print("|cffff4040" .. e .. "|r") end
	end
	return errors, pages, tabs
end
