-- GuildSentinel - Chronicle.lua
--   * Chronik: automatische Zeitleiste der Gilde – Beitritte und Abgänge, Höchststufen, Erstkills, Meilensteine,
--     geschaffte Wochenziele, Gildentermine. Als Text für Discord exportierbar.
--   * Gildenerfolge: kleine interne Ziele mit Fortschrittsbalken (Mitglieder auf Höchststufe, Raid eingestimmt,
--     alle Tanks eingestimmt, jeder Beruf auf Maximum, Dank-Punkte, Wochenziele, Termine …).
--   * Wochenrückblick: einmal pro Woche (nach dem Reset am Mittwoch) eine Zusammenfassung im Gildenchat:
--     "12 Stufen, 2 neue 70er, Gruul erstmals besiegt, hilfsbereitester Spieler: Mira". Es sagt nur einer an.

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local Ch = {}
ns.Chronicle = Ch

------------------------------------------------------------
-- Chronik
------------------------------------------------------------
-- { { t, text, kind } } – neueste zuerst
function Ch:Timeline()
	local g = ns.G()
	local out = {}
	local function Add(t, text, kind) if t and t > 0 then out[#out + 1] = { t = t, text = text, kind = kind } end end
	for _, x in ipairs(g.log or {}) do
		if x.k == "join" then Add(x.t, string.format(L["%s ist der Gilde beigetreten"], x.n), "join")
		elseif x.k == "leave" then Add(x.t, string.format(L["%s hat die Gilde verlassen"], x.n), "leave")
		elseif x.k == "kick" then Add(x.t, string.format(L["%s wurde aus der Gilde entfernt"], x.n), "leave")
		elseif x.k == "maxlevel" then Add(x.t, string.format(L["%s hat Stufe %s erreicht"], x.n, tostring(x.x or ns.Roster.MAX_LEVEL)), "level")
		end
	end
	local f = g.race and g.race.first60
	if f and f.t then Add(f.t, string.format(L["%s ist als Erstes der Gilde auf Stufe %d"], f.n, ns.Roster.MAX_LEVEL), "level") end
	for _, m in ipairs(ns.Goals:Miles()) do Add(m.t, m.text, m.key:find("^kill:") and "kill" or "mile") end
	for key, t in pairs(g.goalDone or {}) do
		local y, mo, d = tostring(key):match("^(%d%d%d%d)(%d%d)(%d%d)$")
		Add(t, string.format(L["Wochenziel geschafft (Woche ab %s.%s.)"], d or "?", mo or "?"), "goal")
	end
	for _, e in pairs(g.events or {}) do
		if not e.del and e.t < ns.Now() then
			local yes = 0
			for _, r in pairs(e.r or {}) do if r.s == "yes" then yes = yes + 1 end end
			if yes >= 3 then Add(e.t, string.format(L["Gildentermin: %s (%d dabei)"], e.title, yes), "event") end
		end
	end
	table.sort(out, function(a, b) return a.t > b.t end)
	return out
end

-- Text für Discord (neueste zuerst, höchstens 60 Einträge)
function Ch:ExportText()
	local lines = { "**" .. string.format(L["Chronik von <%s>"], ns.GuildName() or "") .. "**", "" }
	for i, x in ipairs(self:Timeline()) do
		if i > 60 then break end
		lines[#lines + 1] = date(L["%d.%m.%Y"], x.t) .. " – " .. x.text
	end
	return table.concat(lines, "\n")
end

------------------------------------------------------------
-- Gildenerfolge
------------------------------------------------------------
local function Step(cur, steps)
	for _, s in ipairs(steps) do if cur < s then return s end end
	return steps[#steps]
end

-- Hauptberufe (Zauber-ID); Juwelenschleifen nur in TBC
local function ProfList()
	local list = { 2259, 2018, 7411, 4036, 2108, 3908 }
	if ns.Game.TBC then list[#list + 1] = 25229 end
	return list
end

local function SpellName(id)
	if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
	return GetSpellInfo and (GetSpellInfo(id)) or nil
end

-- { { key, name, cur, max, done, sub } }
function Ch:Achievements()
	local out = {}
	local g = ns.G()
	local max = ns.Roster.MAX_LEVEL
	local function Add(key, name, cur, goal, sub)
		out[#out + 1] = { key = key, name = name, cur = math.min(cur, goal), max = goal, done = cur >= goal, sub = sub }
	end
	-- Mitglieder auf Höchststufe / Spieler in der Gilde
	local atMax = 0
	for _, e in ipairs(ns.Roster.list) do if e.level >= max and not ns.Roster:IsAlt(e.name) then atMax = atMax + 1 end end
	local s = Step(atMax, { 5, 10, 25, 40 })
	Add("max", string.format(L["%d Mitglieder auf Stufe %d"], s, max), atMax, s)
	local _, _, mains = ns.Roster:Stats()
	s = Step(mains, { 10, 25, 50, 100, 200 })
	Add("mem", string.format(L["%d Spieler in der Gilde"], s), mains, s)
	-- Raids: voll eingestimmt, alle Tanks eingestimmt
	for _, a in ipairs(ns.Attune:InGroup("raid")) do
		local ok, tanks, tanksOk = 0, 0, 0
		for _, e in ipairs(ns.Roster.list) do
			if not ns.Roster:IsAlt(e.name) and e.level >= (a.level or 0) then
				local st = ns.Attune:Status(e.name, a.key)
				if st then ok = ok + 1 end
				local role, src = ns.Comp:Role(e.name, e.class)
				if role == "tank" and src ~= "guess" then tanks = tanks + 1; if st then tanksOk = tanksOk + 1 end end
			end
		end
		Add("att:" .. a.key, string.format(L["%s: ein voller Raid eingestimmt"], L[a.name]), ok, ns.Game.RAID_SIZE)
		if tanks > 0 then Add("tank:" .. a.key, string.format(L["%s: alle Tanks eingestimmt"], L[a.name]), tanksOk, tanks) end
	end
	-- jeder Hauptberuf mindestens einmal auf Maximum
	local cap = ns.Game.TBC and 375 or 300
	local maxed, names = 0, {}
	local profs = ns.Prof:All()
	for _, sid in ipairs(ProfList()) do
		local pname = SpellName(sid)
		local found = false
		for _, e in pairs(profs) do
			local p = pname and e.p and e.p[pname]
			if p and (p.r or 0) >= cap then found = true break end
		end
		if found then maxed = maxed + 1 elseif pname then names[#names + 1] = pname end
	end
	Add("prof", string.format(L["Jeder Hauptberuf auf %d"], cap), maxed, #ProfList(), #names > 0 and (L["fehlt: "] .. table.concat(names, ", ")) or nil)
	-- Dank-Punkte (30 Tage)
	local thanks = 0
	for _, x in ipairs(ns.Social:ThanksTop(30)) do thanks = thanks + x.n end
	s = Step(thanks, { 25, 50, 100, 250 })
	Add("thx", string.format(L["%d Danke in 30 Tagen"], s), thanks, s)
	-- Wochenziele und Termine
	local weeks = 0
	for _ in pairs(g.goalDone or {}) do weeks = weeks + 1 end
	s = Step(weeks, { 1, 5, 10, 25 })
	Add("weeks", string.format(L["%d Wochenziele geschafft"], s), weeks, s)
	local events = 0
	for _, e in pairs(g.events or {}) do if not e.del and e.t < ns.Now() then events = events + 1 end end
	s = Step(events, { 5, 10, 25, 50 })
	Add("events", string.format(L["%d Gildentermine abgehalten"], s), events, s)
	table.sort(out, function(a, b)
		if a.done ~= b.done then return not a.done end
		return (a.cur / math.max(1, a.max)) > (b.cur / math.max(1, b.max))
	end)
	return out
end

------------------------------------------------------------
-- Wochenrückblick
------------------------------------------------------------
function Ch:WeekStats(from, to)
	local g = ns.G()
	local st = { levels = 0, newMax = {}, kills = {}, joins = 0, top = nil }
	for name, lv in pairs(g.levels or {}) do
		for _, t in pairs(lv) do if t and t >= from and t < to then st.levels = st.levels + 1 end end
	end
	for _, x in ipairs(g.log or {}) do
		if x.t >= from and x.t < to then
			if x.k == "maxlevel" then st.newMax[#st.newMax + 1] = x.n end
			if x.k == "join" then st.joins = st.joins + 1 end
		end
	end
	for _, m in ipairs(ns.Goals:Miles()) do
		if m.t >= from and m.t < to and m.key:find("^kill:") then st.kills[#st.kills + 1] = (m.text:gsub("^.-: ", "")) end
	end
	local by = {}
	for _, t in pairs(g.thanks or {}) do
		if t.t >= from and t.t < to then
			local m = ns.Roster:MainOf(t.to) or t.to
			by[m] = (by[m] or 0) + 1
		end
	end
	local best, bn = nil, 0
	for name, n in pairs(by) do if n > bn or (n == bn and best and name < best) then best, bn = name, n end end
	st.top = best
	return st
end

function Ch:ReviewText(st)
	local parts = { string.format(L["%d Stufen"], st.levels) }
	if #st.newMax > 0 then
		parts[#parts + 1] = string.format(L["%d neue %der (%s)"], #st.newMax, ns.Roster.MAX_LEVEL, table.concat(st.newMax, ", "))
	end
	if st.joins > 0 then parts[#parts + 1] = string.format(L["%d neue Mitglieder"], st.joins) end
	for _, k in ipairs(st.kills) do parts[#parts + 1] = string.format(L["%s erstmals besiegt"], k) end
	if st.top then parts[#parts + 1] = string.format(L["hilfsbereitester Spieler: %s"], st.top) end
	return L["Wochenrückblick: "] .. table.concat(parts, ", ") .. "."
end

function Ch:CheckReview()
	local g = ns.guild
	if not g or not ns.Feature("chronicle") or not next(ns.Roster.byName) then return end
	local now = ns.Now()
	local thisStart = ns.Goals:WeekStart(now)
	local prevStart = ns.Goals:WeekStart(thisStart - 3600)
	local key = ns.Goals:WeekKey(prevStart + 3600)
	-- beim allerersten Mal nur merken (sonst käme ein Rückblick über Daten, die es noch gar nicht gibt)
	if not g.reviewInit then g.reviewInit = now; g.review[key] = now return end
	if g.review[key] or g.reviewInit > prevStart then return end
	-- nur in den ersten drei Tagen der neuen Woche
	if now - thisStart > 3 * 86400 then g.review[key] = now return end
	local st = self:WeekStats(prevStart, thisStart)
	if st.levels == 0 and #st.newMax == 0 and #st.kills == 0 and not st.top then g.review[key] = now return end
	-- hat schon jemand anderes angesagt?
	local c = ns.Comm.claims and ns.Comm.claims["review:" .. key]
	if c and not ns.Same(c.by, ns.Me()) then g.review[key] = now return end
	ns.Claim("review:" .. key, function()
		g.review[key] = ns.Now()
		if ns.db.annReview ~= false then ns.Announce(self:ReviewText(st)) end
	end)
end

ns:Listen("GS_LOGIN", function() C_Timer.After(70, function() Ch:CheckReview() end) end)
C_Timer.NewTicker(1800, function() Ch:CheckReview() end)
