-- GuildSentinel - PagesLead.lua
-- Seite "Leitung" (nur für Offiziere): Probezeit, Abgänge mit Grund, Offiziersnotizen mit Verlauf, Rangrechte.

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local UI = ns.UI

local GREEN, GRAY, GOLD, ORANGE = "|cff40d860", "|cff8a8f99", "|cffffd100", "|cffff9933"
local function Gray(t) return GRAY .. tostring(t) .. "|r" end
local function WhenShown(key, fn)
	return function(...) if UI:IsPageShown(key) then fn(...) end end
end

local Le = { key = "lead", feature = "lead", officer = true, order = 60, icon = "Interface\\Icons\\INV_Misc_Book_11" }
Le.title = N["Leitung"]
Le.view = "prob"

local function View(p)
	local v = CreateFrame("Frame", nil, p)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	v:Hide()
	return v
end

function Le.build(p)
	Le.panel = p
	Le.tabs = UI:Tabs(p, {
		{ key = "prob", text = L["Probezeit"] },
		{ key = "gone", text = L["Abgänge"] },
		{ key = "notes", text = L["Offiziersnotizen"] },
		{ key = "ranks", text = L["Rangrechte"] },
	}, function(key) Le.view = key; Le:Refresh() end)
	Le.tabs:SetPoint("TOPLEFT", 0, 0)
	Le.tabs:SetPoint("TOPRIGHT", 0, 0)
	Le.views = {}
	Le:BuildProbation(View(p))
	Le:BuildGone(View(p))
	Le:BuildNotes(View(p))
	Le:BuildRanks(View(p))
end

------------------------------------------------------------
-- Probezeit
------------------------------------------------------------
function Le:BuildProbation(v)
	self.views.prob = v
	self.probInfo = UI:Label(v, "", "GameFontHighlight")
	self.probInfo:SetPoint("TOPLEFT", 0, -5)
	local change = UI:Button(v, L["Probezeit ändern"], 150, 24, function()
		UI:Ask(L["Wie viele Tage dauert die Probezeit?"], tostring(ns.Lead:ProbationDays()), function(t) ns.Lead:SetProbationDays(t) end)
	end)
	change:SetPoint("TOPRIGHT", 0, 0)
	self.probList = UI:List(v, {
		{ key = "name", title = L["Name"], width = 150 },
		{ key = "level", title = L["Stufe"], width = 50, align = "CENTER" },
		{ key = "days", title = L["Dabei seit"], width = 90, align = "CENTER" },
		{ key = "online", title = L["Online-Tage"], width = 90, align = "CENTER" },
		{ key = "events", title = L["Termine"], width = 70, align = "CENTER" },
		{ key = "thanks", title = L["Danke"], width = 60, align = "CENTER" },
		{ key = "mentor", title = L["Pate"], width = 110 },
		{ key = "advice", title = L["Empfehlung"] },
	}, {
		key = function(x) return x.name end,
		render = function(x)
			local adv = ns.Lead:AdviceText(x)
			if x.advice == "promote" then adv = GREEN .. adv .. "|r" elseif x.advice == "talk" then adv = ORANGE .. adv .. "|r" else adv = Gray(adv) end
			return { ns.Colored(x.name, x.class), tostring(x.level), string.format(L["%d Tagen"], x.days), tostring(x.online), tostring(x.events),
				tostring(x.thanks), x.mentor or Gray("–"), adv }
		end,
		onClick = function() Le:UpdateButtons() end,
		empty = L["Gerade ist niemand in der Probezeit."],
	})
	self.probList:SetPoint("TOPLEFT", 0, -32)
	self.probList:SetPoint("BOTTOMRIGHT", 0, 70)
	local function Sel() local x = self.probList:Selected(); return x and x.name end
	self.probPromote = UI:Button(v, L["Befördern"], 140, 26, function()
		local n = Sel()
		if n then UI:Confirm(string.format(L["%s jetzt befördern?"], n), function() ns.Promote:Promote(n) end) end
	end, true)
	self.probPromote:SetPoint("BOTTOMLEFT", 0, 36)
	self.probMentor = UI:Button(v, L["Pate vorschlagen"], 160, 26, function()
		local n = Sel()
		if not n then return end
		local m, ov = ns.Lead:SuggestMentor(n)
		if not m then ns:Print(L["Kein passender Pate gefunden – es braucht noch ein paar Tage Online-Zeiten."]) return end
		UI:Confirm(string.format(L["%s als Pate für %s? (gleiche Online-Zeiten: %d%%)"], m, n, math.floor((ov or 0) * 100 + 0.5)), function() ns.Social:SetMentor(n, m) end)
	end)
	self.probMentor:SetPoint("LEFT", self.probPromote, "RIGHT", 8, 0)
	self.probNote = UI:Button(v, L["Notiz schreiben"], 150, 26, function()
		local n = Sel()
		if n then UI:Ask(string.format(L["Offiziersnotiz zu %s:"], n), "", function(t) ns.Lead:AddNote(n, t) end) end
	end)
	self.probNote:SetPoint("LEFT", self.probMentor, "RIGHT", 8, 0)
	local hint = UI:Label(v, Gray(L["Empfehlung nach Ablauf: Befördern, wenn jemand an mindestens 40 % der Tage online war (mindestens 3), sonst ein Gespräch. Befördert wird immer von Hand."]), "GameFontHighlightSmall")
	hint:SetPoint("BOTTOMLEFT", 0, 4)
	hint:SetPoint("RIGHT")
	hint:SetJustifyH("LEFT")
end

------------------------------------------------------------
-- Abgänge
------------------------------------------------------------
function Le:BuildGone(v)
	self.views.gone = v
	self.goneInfo = UI:Label(v, "", "GameFontHighlight")
	self.goneInfo:SetPoint("TOPLEFT", 0, -5)
	self.goneList = UI:List(v, {
		{ key = "name", title = L["Name"], width = 150 },
		{ key = "l", title = L["Stufe"], width = 50, align = "CENTER" },
		{ key = "r", title = L["Rang"], width = 110 },
		{ key = "t", title = L["Wann"], width = 120 },
		{ key = "k", title = L["Art"], width = 90 },
		{ key = "reason", title = L["Grund"] },
	}, {
		key = function(x) return x.name end,
		render = function(x)
			return { ns.Colored(x.name, x.c), x.l and tostring(x.l) or "?", x.r or Gray("?"), ns.Date(x.t),
				x.k == "kick" and (ORANGE .. L["entfernt"] .. "|r") or L["verlassen"], (x.reason and x.reason ~= "") and x.reason or Gray(L["kein Grund eingetragen"]) }
		end,
		onClick = function() Le:UpdateButtons() end,
		empty = L["In den letzten 180 Tagen hat niemand die Gilde verlassen."],
	})
	self.goneList:SetPoint("TOPLEFT", 0, -32)
	self.goneList:SetPoint("BOTTOMRIGHT", 0, 40)
	self.goneReason = UI:Button(v, L["Grund eintragen"], 160, 26, function()
		local x = self.goneList:Selected()
		if x then UI:Ask(string.format(L["Warum hat %s die Gilde verlassen?"], x.name), x.reason or "", function(t) ns.Lead:SetGoneReason(x.name, t) end) end
	end, true)
	self.goneReason:SetPoint("BOTTOMLEFT", 0, 4)
	local hint = UI:Label(v, Gray(L["Gründe und Notizen sehen nur Offiziere mit GuildSentinel."]), "GameFontHighlightSmall")
	hint:SetPoint("LEFT", self.goneReason, "RIGHT", 12, 0)
end

------------------------------------------------------------
-- Offiziersnotizen
------------------------------------------------------------
function Le:BuildNotes(v)
	self.views.notes = v
	local search = UI:Edit(v, 280, 24, L["Spieler suchen"])
	search:SetPoint("TOPLEFT")
	search.onChange = function(t) Le.noteQuery = t; Le:Refresh() end
	self.notePlayers = UI:List(v, {
		{ key = "name", title = L["Spieler"], width = 170 },
		{ key = "n", title = L["Notizen"], width = 70, align = "CENTER" },
	}, {
		key = function(x) return x.name end,
		render = function(x) return { ns.Colored(x.name, x.class), x.n > 0 and tostring(x.n) or Gray("–") } end,
		onClick = function() Le:RefreshNotes() end,
		empty = L["Keine Spieler gefunden."],
	})
	self.notePlayers:SetPoint("TOPLEFT", 0, -32)
	self.notePlayers:SetPoint("BOTTOMLEFT", 0, 0)
	self.notePlayers:SetWidth(280)
	self.noteTitle = UI:Label(v, "", "GameFontNormalLarge")
	self.noteTitle:SetPoint("TOPLEFT", 296, -4)
	self.noteList = UI:List(v, {
		{ key = "t", title = L["Wann"], width = 110 },
		{ key = "by", title = L["Von"], width = 100 },
		{ key = "text", title = L["Notiz"] },
	}, {
		key = function(x) return x.id end,
		render = function(x) return { Gray(ns.Date(x.t)), x.by, x.text } end,
		onEnter = function(row, x)
			GameTooltip:SetOwner(row, "ANCHOR_CURSOR")
			GameTooltip:AddLine(x.by .. " · " .. ns.Date(x.t), 0.7, 0.7, 0.7)
			GameTooltip:AddLine(x.text, 1, 1, 1, true)
			GameTooltip:Show()
		end,
		onClick = function() Le:UpdateButtons() end,
		empty = L["Noch keine Notizen zu diesem Spieler."],
	})
	self.noteList:SetPoint("TOPLEFT", 296, -32)
	self.noteList:SetPoint("BOTTOMRIGHT", 0, 40)
	self.noteAdd = UI:Button(v, L["Notiz hinzufügen"], 160, 26, function()
		local x = self.notePlayers:Selected()
		if x then UI:Ask(string.format(L["Offiziersnotiz zu %s:"], x.name), "", function(t) ns.Lead:AddNote(x.name, t) end) end
	end, true)
	self.noteAdd:SetPoint("BOTTOMLEFT", 296, 4)
	self.noteDel = UI:Button(v, L["Notiz löschen"], 140, 26, function()
		local x, n = self.noteList:Selected(), self.notePlayers:Selected()
		if x and n then UI:Confirm(L["Diese Notiz löschen?"], function() ns.Lead:DeleteNote(n.name, x.id) end) end
	end)
	self.noteDel:SetPoint("LEFT", self.noteAdd, "RIGHT", 8, 0)
end

function Le:RefreshNotes()
	local x = self.notePlayers:Selected()
	if x then
		self.noteTitle:SetText(ns.Colored(x.name, x.class))
		self.noteList:SetData(ns.Lead:Notes(x.name))
	else
		self.noteTitle:SetText(Gray(L["Wähle links einen Spieler."]))
		self.noteList:SetData({})
	end
	self:UpdateButtons()
end

------------------------------------------------------------
-- Rangrechte
------------------------------------------------------------
function Le:BuildRanks(v)
	self.views.ranks = v
	self.rankInfo = UI:Label(v, "", "GameFontHighlightSmall")
	self.rankInfo:SetPoint("TOPLEFT", 0, -5)
	self.rankInfo:SetPoint("RIGHT")
	self.rankInfo:SetJustifyH("LEFT")
	self.rankText = UI:ScrollText(v, 780, 440)
	self.rankText:SetPoint("TOPLEFT", 0, -30)
	self.rankText:SetPoint("BOTTOMRIGHT")
end

function Le:RefreshRanks()
	local ranks, labels, readable = ns.Lead:RankRights()
	if not readable or #labels == 0 then
		self.rankInfo:SetText(Gray(L["Die Rangrechte kann das Spiel nur der Gildenleitung zeigen (Recht 'Gilde verwalten'). Ränge:"]))
		local t = {}
		for _, r in ipairs(ranks) do t[#t + 1] = r.ri .. ": " .. r.name end
		self.rankText:SetText(table.concat(t, "\n"))
		return
	end
	self.rankInfo:SetText(Gray(L["Welcher Rang darf was? (Bezeichnungen aus dem Spiel; ändern geht im Gildenfenster des Spiels)"]))
	local lines = {}
	for _, lab in ipairs(labels) do
		local who = {}
		for _, r in ipairs(ranks) do if r.flags[lab.i] then who[#who + 1] = r.name end end
		lines[#lines + 1] = GOLD .. lab.text .. "|r: " .. (#who > 0 and table.concat(who, ", ") or Gray(L["niemand"]))
	end
	self.rankText:SetText(table.concat(lines, "\n"))
end

------------------------------------------------------------
-- Anzeige
------------------------------------------------------------
function Le:UpdateButtons()
	if not self.probList then return end
	local p = self.probList:Selected()
	self.probPromote:SetEnabled(p ~= nil and ns.CanPromote())
	self.probMentor:SetEnabled(p ~= nil)
	self.probNote:SetEnabled(p ~= nil)
	self.goneReason:SetEnabled(self.goneList:Selected() ~= nil)
	self.noteAdd:SetEnabled(self.notePlayers:Selected() ~= nil)
	self.noteDel:SetEnabled(self.noteList:Selected() ~= nil)
end

function Le:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	for key, v in pairs(self.views) do v:SetShown(key == self.view) end
	if self.view == "prob" then
		local list = ns.Lead:Probation()
		local due = 0
		for _, x in ipairs(list) do if x.due then due = due + 1 end end
		self.probInfo:SetText(string.format(L["Probezeit: %d Tage · %d in der Probezeit · %d fällig"], ns.Lead:ProbationDays(), #list, due))
		self.probList:SetData(list)
	elseif self.view == "gone" then
		local list = ns.Lead:Gone(180)
		local d30 = 0
		for _, x in ipairs(list) do if x.t >= ns.Now() - 30 * 86400 then d30 = d30 + 1 end end
		self.goneInfo:SetText(string.format(L["%d Abgänge in den letzten 30 Tagen, %d in 180 Tagen"], d30, #list))
		self.goneList:SetData(list)
	elseif self.view == "notes" then
		local q = ns.Trim(self.noteQuery):lower()
		local list, seen = {}, {}
		for _, x in ipairs(ns.Lead:NotedPlayers()) do seen[x.name] = x end
		for _, e in ipairs(ns.Roster.list) do
			if q == "" or e.name:lower():find(q, 1, true) then
				local x = seen[e.name]
				list[#list + 1] = { name = e.name, class = e.class, n = x and x.n or 0 }
			end
		end
		-- Notizen zu Ehemaligen
		for name, x in pairs(seen) do
			if not ns.Roster.byName[name] and (q == "" or name:lower():find(q, 1, true)) then
				list[#list + 1] = { name = name, n = x.n }
			end
		end
		table.sort(list, function(a, b) if (a.n > 0) ~= (b.n > 0) then return a.n > 0 end return a.name < b.name end)
		self.notePlayers:SetData(list)
		self:RefreshNotes()
	elseif self.view == "ranks" then
		self:RefreshRanks()
	end
	self:UpdateButtons()
end

Le.onShow = function(_, arg)
	Le.tabs:Select(arg or Le.view or "prob")
end
ns:Listen("GS_LEAD", WhenShown("lead", function() Le:Refresh() end))
ns:Listen("GS_ROSTER", WhenShown("lead", function() Le:Refresh() end))
ns:Listen("GS_SOCIAL", WhenShown("lead", function() if Le.view == "prob" then Le:Refresh() end end))
UI:AddPage(Le)
