-- ============================================================
-- AH Analyzer Pro 5.9 - Sniper (Logik)
--
-- Ziele: ein Item (Name/ID) oder ein Suchbegriff, jeweils mit
--   Max. Preis pro Stück, Menge, Budget (max. Gold),
--   Seltenheit (Grau bis Episch), Itemlevel und benötigter Stufe.
--
-- Sniper-Modus AN + Auktionshaus offen:
--   * der Sniper sucht die Ziele selbstständig der Reihe nach
--   * jede Mausrad-Raste (oder deine eigene Taste) kauft das nächste
--     passende Angebot, bis Menge oder Budget erreicht ist
--   * Waren (stapelbare Handelswaren): der Sniper holt sich den Preis
--     schon beim Treffer vom Server (Reservierung ohne Tastendruck) -
--     EINE Raste kauft dann sofort. Geht das auf dem Server nicht, wird
--     automatisch auf 2 Rasten umgestellt (1. reserviert, 2. kauft).
-- Gekauft wird NIE ohne deinen Tastendruck (das verlangt WoW selbst).
--
-- Lockangebote: liegt bei Waren ganz unten ein einzelnes Stück, ist das
-- meist ein Köder. Der Sniper löst darauf nicht aus. Kommt ein echter
-- Treffer, nimmt der Server beim Warenkauf trotzdem immer die günstigsten
-- Stücke zuerst - das Lockstück wird also mitgekauft (und mitgerechnet).
--
-- Schnäppchen-Wächter: vorübergehende Ziele (nicht gespeichert), die der
-- Wächter anlegt. Gekauft wird darüber ebenfalls nur per Tastendruck.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local Sn = {}
A.Sniper = Sn

local MIN_INTERVAL = 0          -- automatische Suche: 0 = so oft, wie der Server erlaubt
local ALERT_REPEAT = 4          -- Signal wiederholen, solange ein Treffer kaufbar ist (Sek.)
local PRINT_REPEAT = 30         -- Chat-Meldung zum selben Treffer höchstens so oft
local FOCUS_RECHECK = 10        -- altes AH: wartender Treffer wird so oft (Sek.) nachgeprüft
local TIMEOUT = 8               -- Sekunden, bis eine Suche als ergebnislos gilt
local RESULT_FRESH = 30         -- so lange (Sek.) gelten gefundene Angebote als aktuell
local PRESS_DEBOUNCE = 0.3      -- Mindestabstand zwischen zwei Käufen per Taste
local CONFIRM_TIMEOUT = 10      -- reservierter Warenpreis verfällt nach x Sek.
local AUTO_REQUOTE = 8          -- Sofortkauf: Preis so oft (Sek.) neu holen, solange der Treffer wartet

Sn.QUALITY = {
    [0] = { name = "Grau", short = "Gr", color = "9d9d9d", filter = "PoorQuality" },
    [1] = { name = "Weiß", short = "We", color = "ffffff", filter = "CommonQuality" },
    [2] = { name = "Grün", short = "Gn", color = "1eff00", filter = "UncommonQuality" },
    [3] = { name = "Blau", short = "Bl", color = "0070dd", filter = "RareQuality" },
    [4] = { name = "Episch", short = "Ep", color = "a335ee", filter = "EpicQuality" },
}

Sn.search = nil         -- laufende Suche
Sn.result = nil         -- letztes Ergebnis { key, itemID, listings, time, commodity, candidates }
Sn.pending = nil        -- Waren-Kauf wartet auf Bestätigung
Sn.lastSearch = -100
Sn.lastPress = -100
Sn.rotation = 0
Sn.lastPurchase = nil
Sn.extra = {}           -- vorübergehende Ziele des Schnäppchen-Wächters [key] = Ziel

local function DB()
    return A.db and A.db.sniper
end

local function SafeCall(fn, ...)
    if not fn then return nil end
    local ok, a = pcall(fn, ...)
    if ok then return a end
    return nil
end

local function Now()
    return GetTime()
end

function Sn:QualityText(q)
    local d = self.QUALITY[q or 0]
    if not d then return "?" end
    return "|cff" .. d.color .. L[d.name] .. "|r"
end

-- ------------------------------------------------------------
-- Ziele verwalten
-- ------------------------------------------------------------
function Sn:GetTarget(key)
    local db = DB()
    if not key then return nil end
    return (db and db.targets[key]) or self.extra[key]
end

-- vorübergehendes Ziel (Wächter): nicht gespeichert
function Sn:AddExtraTarget(t)
    self.extra[t.key] = t
    self:ApplyBindings()
    A:Fire("SNIPER_CHANGED")
end

function Sn:RemoveExtraTarget(key)
    if not self.extra[key] then return end
    self.extra[key] = nil
    if self.result and self.result.key == key then self.result = nil end
    if self.current == key then self.current = nil end
    self:ApplyBindings()
    A:Fire("SNIPER_CHANGED")
end

function Sn:HasExtraTargets()
    for _, t in pairs(self.extra) do
        if not self:IsDone(t) then return true end
    end
    return false
end

-- input: Item-Name, Item-ID oder Suchbegriff
-- f: { quals = { [Qualität] = true } oder nil (alle), ilvlMin, ilvlMax, lvlMin, lvlMax }
--    (ältere Aufrufer: qMin/qMax als Bereich)
function Sn:SetTarget(input, maxPrice, qty, budget, f)
    local db = DB()
    if not db then return false, L["Datenbank nicht bereit."] end
    input = input and tostring(input):gsub("^%s+", ""):gsub("%s+$", "") or ""
    if input == "" then return false, L["Bitte Item-Name, Item-ID oder Suchbegriff eingeben."] end
    if not maxPrice or maxPrice <= 0 then return false, L["Bitte einen Max.-Preis pro Stück eingeben (Gold, Silber, Kupfer)."] end
    qty = math.floor(tonumber(qty) or 1)
    if qty < 1 then qty = 1 end
    if not budget or budget <= 0 then budget = maxPrice * qty end
    if budget < maxPrice then return false, L["Das Budget ist kleiner als der Max.-Preis für ein Stück."] end
    f = f or {}
    local quals = f.quals
    if not quals and (f.qMin or f.qMax) then
        local lo, hi = f.qMin or 0, f.qMax or 4
        if lo > hi then lo, hi = hi, lo end
        if lo > 0 or hi < 4 then
            quals = {}
            for q = lo, hi do quals[q] = true end
        end
    end
    if quals and next(quals) == nil then return false, L["Bitte mindestens eine Seltenheit anhaken."] end
    local qMin, qMax = 0, 4
    if quals then
        qMin, qMax = 4, 0
        for q in pairs(quals) do qMin = math.min(qMin, q); qMax = math.max(qMax, q) end
    end

    local itemID, matches = A:FindItemByName(input)
    local t = {
        maxPrice = maxPrice, qty = qty, budget = budget,
        bought = 0, spent = 0,
        qMin = qMin, qMax = qMax, quals = quals,
        ilvlMin = f.ilvlMin, ilvlMax = f.ilvlMax,
        lvlMin = f.lvlMin, lvlMax = f.lvlMax,
        added = time(),
    }
    if itemID then
        t.kind, t.itemID, t.key = "item", itemID, "i:" .. itemID
    else
        if string.len(input) < 3 then return false, L["Suchbegriff bitte mit mindestens 3 Zeichen."] end
        t.kind, t.text, t.key = "text", input, "t:" .. string.lower(input)
    end
    local existed = db.targets[t.key] ~= nil
    db.targets[t.key] = t
    if self.result and self.result.key == t.key then self.result = nil end
    A:Fire("SNIPER_CHANGED")
    local msg = (existed and L["Ziel aktualisiert: "] or L["Ziel gesetzt: "]) .. self:TargetName(t)
        .. " - " .. qty .. L[" Stück, max. "] .. A:FormatMoney(maxPrice) .. L["/Stück, Budget "] .. A:FormatMoney(budget)
    if t.kind == "text" and matches and matches > 1 then
        msg = msg .. L["  (Suchwort, passt auf "] .. matches .. L[" Items - für ein bestimmtes Item einen Vorschlag anklicken)"]
    end
    return true, msg
end

function Sn:RemoveTarget(key)
    local db = DB()
    if self.extra[key] then
        local name = self:TargetName(self.extra[key])
        self:RemoveExtraTarget(key)
        return true, L["Ziel entfernt: "] .. name
    end
    if not (db and db.targets[key]) then return false, L["Ziel nicht gefunden."] end
    local name = self:TargetName(db.targets[key])
    db.targets[key] = nil
    if self.result and self.result.key == key then self.result = nil end
    A:Fire("SNIPER_CHANGED")
    return true, L["Ziel entfernt: "] .. name
end

function Sn:ResetProgress(key)
    local t = self:GetTarget(key)
    if not t then return false, L["Ziel nicht gefunden."] end
    t.bought, t.spent = 0, 0
    A:Fire("SNIPER_CHANGED")
    return true, L["Zähler zurückgesetzt: "] .. self:TargetName(t)
end

function Sn:TargetName(t)
    if t.kind == "item" then return A:GetItemName(t.itemID) end
    return "\"" .. t.text .. "\""
end

function Sn:Remaining(t)
    return (t.qty or 0) - (t.bought or 0), (t.budget or 0) - (t.spent or 0)
end

function Sn:IsDone(t)
    local q, b = self:Remaining(t)
    return q <= 0 or b <= 0
end

-- gewählte Seltenheiten eines Ziels: nil = alle, sonst { [Qualität] = true }
-- (ältere Ziele haben nur einen Bereich qMin..qMax)
function Sn:QualSet(t)
    if t.quals then return t.quals end
    local lo, hi = t.qMin or 0, t.qMax or 4
    if lo == 0 and hi == 4 then return nil end
    local set = {}
    for q = lo, hi do set[q] = true end
    return set
end

function Sn:FilterText(t)
    local parts = {}
    local set = self:QualSet(t)
    if set then
        local list, n = {}, 0
        for q = 0, 4 do if set[q] then n = n + 1; list[n] = q end end
        if n > 2 and list[n] - list[1] + 1 == n then
            table.insert(parts, L[self.QUALITY[list[1]].short] .. "-" .. L[self.QUALITY[list[n]].short])
        else
            local s = {}
            for _, q in ipairs(list) do table.insert(s, L[self.QUALITY[q].short]) end
            table.insert(parts, table.concat(s, ","))
        end
    end
    if t.ilvlMin or t.ilvlMax then table.insert(parts, "i" .. (t.ilvlMin or "") .. "-" .. (t.ilvlMax or "")) end
    if t.lvlMin or t.lvlMax then table.insert(parts, L["St"] .. (t.lvlMin or "") .. "-" .. (t.lvlMax or "")) end
    if #parts == 0 then return L["alle"] end
    return table.concat(parts, " ")
end

local function TargetEntry(key, t)
    local qLeft, bLeft = Sn:Remaining(t)
    return {
        key = key,
        itemID = t.itemID,
        name = Sn:TargetName(t),
        kind = t.kind,
        maxPrice = t.maxPrice,
        qty = t.qty, bought = t.bought or 0,
        budget = t.budget, spent = t.spent or 0,
        qtyLeft = qLeft, budgetLeft = bLeft,
        filter = Sn:FilterText(t),
        done = Sn:IsDone(t),
        checked = t.checked,
        found = t.found,
        watch = t.watch,
        target = t,
    }
end

function Sn:GetTargets()
    local out = {}
    local db = DB()
    if not db then return out end
    for key, t in pairs(db.targets) do table.insert(out, TargetEntry(key, t)) end
    for key, t in pairs(self.extra) do table.insert(out, TargetEntry(key, t)) end
    table.sort(out, function(a, b)
        if (a.watch and true or false) ~= (b.watch and true or false) then return a.watch and true or false end
        return string.lower(a.name) < string.lower(b.name)
    end)
    return out
end

-- offene Ziele. Ist nur der Wächter aktiv (Sniper-Modus aus), nur dessen Ziele.
function Sn:GetActiveTargets(onlyWatch)
    local db = DB()
    if onlyWatch == nil then onlyWatch = not (db and db.armed) and self:HasExtraTargets() end
    local out = {}
    for _, e in ipairs(self:GetTargets()) do
        if not e.done and (not onlyWatch or e.watch) then table.insert(out, e) end
    end
    return out
end

-- Alte Ziele (Watchlist "Kaufen unter") einmalig übernehmen
function Sn:ImportOld()
    local db = DB()
    if not db or db.imported then return end
    db.imported = true
    for itemID, w in pairs(A.db.watchlist or {}) do
        if w.buyBelow and w.buyBelow > 0 and not db.targets["i:" .. itemID] then
            db.targets["i:" .. itemID] = {
                kind = "item", itemID = itemID, key = "i:" .. itemID,
                maxPrice = w.buyBelow, qty = 1, budget = w.buyBelow,
                bought = 0, spent = 0, qMin = 0, qMax = 4, added = time(),
            }
        end
    end
end

-- ------------------------------------------------------------
-- Filter: Seltenheit, Itemlevel, Stufe
-- ------------------------------------------------------------
local function InRange(value, min, max)
    if value == nil then return true end          -- unbekannt: nicht ausfiltern
    if min and value < min then return false end
    if max and value > max then return false end
    return true
end

-- item: itemID oder itemLink. ilvl: Itemlevel des Angebots (falls bekannt)
-- Rückgabe: passt (bool), Qualität, Itemlevel, Stufe
function Sn:ItemPasses(t, item, ilvl)
    local quality, itemLevel, reqLevel
    if GetItemInfo and item then
        local ok, name, _, q, il, req = pcall(GetItemInfo, item)
        if ok and name then quality, itemLevel, reqLevel = q, il, req end
    end
    if ilvl and ilvl > 0 then itemLevel = ilvl end
    local set = self:QualSet(t)
    local pass = (quality == nil or set == nil or set[quality] == true)
        and InRange(itemLevel, t.ilvlMin, t.ilvlMax)
        and InRange(reqLevel, t.lvlMin, t.lvlMax)
    return pass, quality, itemLevel, reqLevel
end

local function ListingItemLevel(link)
    if not link then return nil end
    if GetDetailedItemLevelInfo then
        local lvl = SafeCall(GetDetailedItemLevelInfo, link)
        if lvl and lvl > 0 then return lvl end
    end
    return nil
end

-- ------------------------------------------------------------
-- API
-- ------------------------------------------------------------
function Sn:CheckAPI()
    local C = A.AH
    return {
        SendSearchQuery = C ~= nil and C.SendSearchQuery ~= nil,
        SendBrowseQuery = C ~= nil and C.SendBrowseQuery ~= nil,
        CommodityResults = C ~= nil and C.GetCommoditySearchResultInfo ~= nil,
        ItemResults = C ~= nil and C.GetItemSearchResultInfo ~= nil,
        PlaceBid = C ~= nil and C.PlaceBid ~= nil,
        CommodityBuy = C ~= nil and C.StartCommoditiesPurchase ~= nil and C.ConfirmCommoditiesPurchase ~= nil,
        Bindings = SetOverrideBindingClick ~= nil and ClearOverrideBindings ~= nil,
    }
end

local function MakeKey(itemID)
    if A.AH.MakeItemKey then
        local ok, key = pcall(A.AH.MakeItemKey, itemID)
        if ok and key then return key end
    end
    return { itemID = itemID, itemLevel = 0, itemSuffix = 0, battlePetSpeciesID = 0 }
end

local SORTS = { { sortOrder = 0, reverseSort = false } }

local function QualityFilters(t)
    local out = {}
    local set = Sn:QualSet(t)
    if not set then return out end
    if not (Enum and Enum.AuctionHouseFilter) then return out end
    for q = 0, 4 do
        local v = set[q] and Enum.AuctionHouseFilter[Sn.QUALITY[q].filter]
        if v then table.insert(out, v) end
    end
    return out
end

-- Angebote eines Items lesen
local function ReadListings(t, itemID, key)
    local C = A.AH
    local listings = {}
    local commodity = false

    local nCom = SafeCall(C.GetNumCommoditySearchResults, itemID) or 0
    if nCom > 0 then
        commodity = true
        local pass, quality, ilvl = Sn:ItemPasses(t, itemID)
        for i = 1, nCom do
            local info = SafeCall(C.GetCommoditySearchResultInfo, itemID, i)
            if type(info) == "table" and info.unitPrice and info.unitPrice > 0 then
                table.insert(listings, {
                    price = info.unitPrice, qty = info.quantity or 1,
                    own = info.containsOwnerItem or false,
                    pass = pass, quality = quality, ilvl = ilvl, commodity = true,
                })
            end
        end
    else
        local nItem = SafeCall(C.GetNumItemSearchResults, key) or 0
        for i = 1, nItem do
            local info = SafeCall(C.GetItemSearchResultInfo, key, i)
            if type(info) == "table" and info.buyoutAmount and info.buyoutAmount > 0 then
                local qty = info.quantity or 1
                local pass, quality, ilvl = Sn:ItemPasses(t, info.itemLink or itemID, ListingItemLevel(info.itemLink))
                table.insert(listings, {
                    price = math.floor(info.buyoutAmount / math.max(1, qty)),
                    buyout = info.buyoutAmount, qty = qty,
                    auctionID = info.auctionID,
                    own = info.containsOwnerItem or false,
                    pass = pass, quality = quality, ilvl = ilvl, commodity = false,
                })
            end
        end
    end
    table.sort(listings, function(a, b) return a.price < b.price end)
    if commodity then A:MarkBait(listings) end
    return listings, commodity
end

local function ItemResultsFull(itemID, key)
    local C = A.AH
    if SafeCall(C.HasFullCommoditySearchResults, itemID) then return true end
    return SafeCall(C.HasFullItemSearchResults, key) == true
end

-- ------------------------------------------------------------
-- Suche (eine Suche pro Ziel, nacheinander)
-- ------------------------------------------------------------
function Sn:IsBusy()
    return self.search ~= nil
end

function Sn:CanSearch()
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    if self.search then return false, L["Suche läuft noch ..."], true end
    local p = self.pending
    if p and not (p.auto and p.state == "ready") then return false, L["Erst den laufenden Kauf bestätigen."], true end
    if A:IsScanning() then return false, L["Warte, bis der Markt-Scan fertig ist."] end
    if A.Seller and A.Seller:IsBusy() then return false, L["Suche läuft noch ..."], true end
    if A.Watcher and A.Watcher:IsBusy() then return false, L["Suche läuft noch ..."], true end
    if A.Buy and A.Buy:Blocks() then return false, L["Suche läuft noch ..."], true end
    if not A:CanQueryNow() then
        return false, L["Kurz warten (max. eine Suche alle "] .. string.format("%.1f", A:QueryGap()) .. L[" Sek.)."], true
    end
    if not (A.AH and A.AH.SendSearchQuery) then
        return false, L["Dein Client unterstützt keine Einzel-Suche (SendSearchQuery fehlt)."]
    end
    return true
end

local function StartItemStage(s, itemID, key)
    local ok, err = pcall(A.AH.SendSearchQuery, key, SORTS, false)
    A:NoteQuery()
    if not ok then A:QueryError(); return false, L["Suche fehlgeschlagen: "] .. tostring(err) end
    s.stage, s.itemID, s.key = "items", itemID, key
    s.started, s.lastCount, s.lastChange, s.answered = Now(), -1, Now(), false
    return true
end

function Sn:Search(targetKey)
    local t = self:GetTarget(targetKey)
    if not t then return false, L["Ziel nicht gefunden."] end
    local ok, msg, soft = self:CanSearch()
    if not ok then return false, msg, soft end

    local s = { targetKey = targetKey }
    if t.kind == "item" then
        local okStart, err = StartItemStage(s, t.itemID, MakeKey(t.itemID))
        if not okStart then return false, err end
    else
        if not A.AH.SendBrowseQuery then
            return false, L["Suchbegriffe brauchen SendBrowseQuery - fehlt in deinem Client. Bitte Item-Name oder ID nutzen."]
        end
        local query = {
            searchString = t.text,
            sorts = SORTS,
            filters = QualityFilters(t),
            itemClassFilters = {},
            minLevel = t.lvlMin or 0,
            maxLevel = t.lvlMax or 0,
        }
        local okQ, err = pcall(A.AH.SendBrowseQuery, query)
        A:NoteQuery()
        if not okQ then A:QueryError(); return false, L["Suche fehlgeschlagen: "] .. tostring(err) end
        s.stage, s.started, s.lastCount, s.lastChange, s.answered = "browse", Now(), -1, Now(), false
    end

    self.search = s
    self.lastSearch = Now()
    self.current = targetKey
    A:Fire("SNIPER_CHANGED")
    return true, L["Suche: "] .. self:TargetName(t) .. " ..."
end

-- wird regelmäßig aufgerufen, solange eine Suche läuft
function Sn:PollSearch()
    local s = self.search
    if not s then return end
    local t = self:GetTarget(s.targetKey)
    if not t or not A:IsAHOpen() then
        self.search = nil
        A:Fire("SNIPER_CHANGED")
        return
    end

    if s.stage == "browse" then
        local results = SafeCall(A.AH.GetBrowseResults) or {}
        local count = #results
        local now = Now()
        if count ~= s.lastCount then s.lastCount, s.lastChange = count, now end
        local full = SafeCall(A.AH.HasFullBrowseResults)
        local timedOut = now - s.started > TIMEOUT
        if not ((count > 0 and (full or now - s.lastChange >= 0.75)) or (s.answered and count == 0 and now - s.lastChange >= 0.5) or timedOut) then return end

        -- passende Items heraussuchen
        local candidates = {}
        for _, r in ipairs(results) do
            local ik = r.itemKey
            if ik and ik.itemID and r.minPrice and r.minPrice > 0 and r.minPrice <= t.maxPrice then
                local pass = self:ItemPasses(t, ik.itemID, (ik.itemLevel or 0) > 0 and ik.itemLevel or nil)
                if pass then table.insert(candidates, { itemKey = ik, minPrice = r.minPrice }) end
            end
        end
        table.sort(candidates, function(a, b) return a.minPrice < b.minPrice end)
        s.candidates = #candidates
        if #candidates == 0 then
            self:FinishSearch(nil, {}, false, 0)
            return
        end
        -- günstigsten Kandidaten genauer ansehen (Einzelangebote)
        local c = candidates[1]
        if not A:QueryReady() then return end      -- Server-Drossel: gleich nochmal
        local okStart = StartItemStage(s, c.itemKey.itemID, c.itemKey)
        if not okStart then self:FinishSearch(nil, {}, false, #candidates) end
        return
    end

    -- Stufe "items": Angebote lesen
    local okRead, listings, commodity = pcall(ReadListings, t, s.itemID, s.key)
    if not okRead then listings, commodity = {}, false end
    local count = #listings
    local now = Now()
    if count ~= s.lastCount then s.lastCount, s.lastChange = count, now end
    local full = ItemResultsFull(s.itemID, s.key)
    local timedOut = now - s.started > TIMEOUT
    local done = (full and (count > 0 or s.answered or now - s.started >= 1))
        or (count > 0 and now - s.lastChange >= 0.75)
        or timedOut
    if done then
        if timedOut and count == 0 then A:QueryError() end
        self:FinishSearch(s.itemID, listings, commodity, s.candidates)
    end
end

-- Signal (wiederholt, solange der Treffer da ist) und Chat-Meldung (nur bei neuem Treffer)
function Sn:Alert(plan, fresh)
    local now = Now()
    local id = plan.itemID .. ":" .. plan.qty .. ":" .. (plan.total or 0)
    if fresh and (id ~= self.lastAlertID or now - (self.lastPrint or -100) >= PRINT_REPEAT) then
        A:Print(L["|cff33dd55Treffer:|r "] .. plan.qty .. "x " .. A:GetItemName(plan.itemID) .. L[" für "] .. A:FormatMoney(plan.total)
            .. " - " .. self:GetBindsText() .. L[" zum Kaufen"])
        self.lastPrint = now
    end
    if A.db.settings.alertSound and PlaySound and (id ~= self.lastAlertID or now - (self.lastSound or -100) >= ALERT_REPEAT) then
        pcall(PlaySound, 8959)
        self.lastSound = now
    end
    self.lastAlertID = id
end

function Sn:FinishSearch(itemID, listings, commodity, candidates)
    local s = self.search
    self.search = nil
    if not s then return end
    local t = self:GetTarget(s.targetKey)
    if not t then A:Fire("SNIPER_CHANGED"); return end

    local newResult = {
        key = s.targetKey, itemID = itemID, listings = listings or {},
        commodity = commodity, time = Now(), stamp = time(), candidates = candidates,
    }
    -- ein kaufbarer Treffer eines ANDEREN Ziels bleibt stehen, bis ein neuer Treffer kommt
    -- (die Suche läuft weiter, der Treffer bleibt per Mausrad/Taste kaufbar)
    local keep = self.result
    local keepHit = keep and keep.key ~= s.targetKey and keep.itemID and self:IsResultFresh() and self.hasPlan
    local prevResult = self.result
    self.result = newResult
    t.checked = time()

    -- günstigsten echten Preis (ohne Lockangebote) in den Preisverlauf
    local first
    for _, l in ipairs(listings or {}) do if not l.bait then first = l; break end end
    if itemID and first then
        local totalQty = 0
        for _, l in ipairs(listings) do if not l.bait then totalQty = totalQty + l.qty end end
        A:VerifyPrice(itemID, first.price, totalQty)
    end

    local plan = self:PlanNext()
    t.found = plan and plan.qty or 0
    if not plan and keepHit then
        -- nichts Neues: alten Treffer wieder anzeigen (bleibt kaufbar)
        self.result = prevResult
        plan = self:PlanNext()
        self.hasPlan = plan ~= nil
        if plan and not t.watch then self:Alert(plan, false) end
        A:Fire("SNIPER_CHANGED")
        A:Fire("DATA_CHANGED")
        return
    end
    self.hasPlan = plan ~= nil
    if t.watch then
        if A.Watcher then A.Watcher:OnVerified(t, plan, self.result) end
    elseif plan then
        self:Alert(plan, true)
    end

    A:Fire("SNIPER_CHANGED")
    A:Fire("DATA_CHANGED")
end

-- Nächstes offenes Ziel suchen
-- Wartet ein kaufbarer Treffer auf Mausrad/Taste?
function Sn:HitWaiting()
    if self.pending then return true end
    return self:IsResultFresh() and self.hasPlan and self.result and self.result.itemID ~= nil or false
end

-- Ist der Sniper mit Suchen dran? (Wächter wechselt sich mit ihm ab)
function Sn:WantsTurn()
    if not self:IsArmed() or self.search then return false end
    if self.pending and not (self.pending.auto and self.pending.state == "ready") then return false end
    if #self:GetActiveTargets() == 0 then return false end
    for _, t in pairs(self.extra) do if not t.checked then return true end end            -- neues Wächter-Schnäppchen
    return Now() - self.lastSearch >= math.max(MIN_INTERVAL, DB().interval or 0)
end

function Sn:CheckNext()
    local targets = self:GetActiveTargets()
    if #targets == 0 then
        return false, L["Keine offenen Ziele. Lege oben ein Ziel an (oder alle Ziele sind erfüllt)."]
    end
    local ok, msg, soft = self:CanSearch()
    if not ok then return false, msg, soft end
    -- neue Schnäppchen des Wächters haben Vorrang
    for _, e in ipairs(targets) do
        if e.watch and not e.checked then return self:Search(e.key) end
    end
    self.rotation = (self.rotation % #targets) + 1
    return self:Search(targets[self.rotation].key)
end

-- ------------------------------------------------------------
-- Kaufplanung: was kauft der nächste Tastendruck?
-- ------------------------------------------------------------
function Sn:IsResultFresh()
    return self.result ~= nil and (Now() - self.result.time) <= RESULT_FRESH
end

-- Markiert jedes Angebot mit einem Status und liefert den nächsten Kauf
function Sn:PlanNext()
    local r = self.result
    if not r or not r.itemID then return nil end
    local t = self:GetTarget(r.key)
    if not t then return nil end
    local qtyLeft, budgetLeft = self:Remaining(t)
    local money = GetMoney and GetMoney() or math.huge
    local limit = math.min(budgetLeft, money)

    for _, l in ipairs(r.listings) do l.status, l.planned = nil, nil end

    if r.commodity then
        -- Lockangebote: lösen nichts aus, werden aber bei einem echten Treffer
        -- vom Server zuerst verkauft (günstigste Stücke zuerst) - also einrechnen
        local takeQty, takeCost, realQty = 0, 0, 0
        for _, l in ipairs(r.listings) do
            local avail = l.qty - (l.used or 0)
            if l.bait and avail > 0 then
                l.status = "Lockangebot"
                if l.price <= t.maxPrice and takeQty < qtyLeft and takeCost + l.price <= limit then
                    local n = math.min(avail, qtyLeft - takeQty)
                    takeQty, takeCost = takeQty + n, takeCost + n * l.price
                    l.planned = n
                end
            elseif avail <= 0 then
                l.status = "gekauft"
            elseif l.own then
                l.status = "eigenes"
            elseif not l.pass then
                l.status = "Filter"
            elseif l.price > t.maxPrice then
                l.status = "zu teuer"
            elseif takeQty >= qtyLeft then
                l.status = "Menge erreicht"
            else
                local n = math.min(avail, qtyLeft - takeQty)
                n = math.min(n, math.floor((limit - takeCost) / l.price))
                if n <= 0 then
                    l.status = (money < budgetLeft) and "zu wenig Gold" or "über Budget"
                else
                    takeQty = takeQty + n
                    takeCost = takeCost + n * l.price
                    realQty = realQty + n
                    l.planned = n
                    l.status = "kaufbar"
                end
            end
        end
        if realQty > 0 then
            return { kind = "commodity", key = r.key, itemID = r.itemID, qty = takeQty, total = takeCost, bait = takeQty - realQty }
        end
        -- nur Lockangebote unter dem Max-Preis: kein Treffer
        for _, l in ipairs(r.listings) do l.planned = nil end
        return nil
    end

    local plan
    for _, l in ipairs(r.listings) do
        if l.used and l.used > 0 then
            l.status = "gekauft"
        elseif l.own then
            l.status = "eigenes"
        elseif not l.pass then
            l.status = "Filter"
        elseif l.price > t.maxPrice then
            l.status = "zu teuer"
        elseif l.qty > qtyLeft then
            l.status = "Stapel zu groß"
        elseif l.buyout > limit then
            l.status = (l.buyout > money) and "zu wenig Gold" or "über Budget"
        elseif not l.auctionID then
            l.status = "keine ID"
        else
            l.status = "kaufbar"
            if not plan then
                l.planned = l.qty
                plan = { kind = "item", key = r.key, itemID = r.itemID, qty = l.qty, total = l.buyout, listing = l }
            end
        end
    end
    return plan
end

-- Gesamtmenge, die bei diesem Item insgesamt gekauft wird (bis Ziel-Menge / Budget / Gold reichen)
-- Rückgabe: Stück, Kosten, Anzahl Käufe (Rasten) - oder nil
function Sn:PlanTotal()
    local r = self.result
    if not (r and r.itemID) then return nil end
    local t = self:GetTarget(r.key)
    if not t then return nil end
    local plan = self:PlanNext()
    if not plan then return nil end
    if r.commodity then return plan.qty, plan.total, 1 end     -- Waren: ein Kauf über alles
    local qLeft, bLeft = self:Remaining(t)
    local money = GetMoney and GetMoney() or math.huge
    local limit = math.min(bLeft, money)
    local qty, cost, n = 0, 0, 0
    for _, l in ipairs(r.listings) do
        if l.status == "kaufbar" or l.planned then
            if qty + l.qty <= qLeft and cost + l.buyout <= limit then
                qty, cost, n = qty + l.qty, cost + l.buyout, n + 1
            end
        end
    end
    if qty == 0 then return nil end
    return qty, cost, n
end

-- ------------------------------------------------------------
-- Kaufen (nur durch Tastendruck / Mausrad / Klick)
-- ------------------------------------------------------------
local function CountPurchase(t, qty, cost)
    t.bought = (t.bought or 0) + qty
    t.spent = (t.spent or 0) + cost
end

function Sn:Buy(plan)
    local t = self:GetTarget(plan.key)
    if not t then return false, L["Ziel nicht gefunden."] end
    local name = A:GetItemName(plan.itemID)
    local C = A.AH

    if plan.kind == "item" then
        if not C.PlaceBid then return false, L["Dein Client unterstützt keinen Sofortkauf (PlaceBid fehlt)."] end
        local ok, err = pcall(C.PlaceBid, plan.listing.auctionID, plan.total)
        if not ok then return false, L["Kauf fehlgeschlagen: "] .. tostring(err) end
        plan.listing.used = plan.qty
        CountPurchase(t, plan.qty, plan.total)
        self.lastPurchase = { key = plan.key, itemID = plan.itemID, qty = plan.qty, cost = plan.total, time = Now(), listing = plan.listing }
        local msg = L["Gekauft: "] .. plan.qty .. "x " .. name .. L[" für "] .. A:FormatMoney(plan.total)
        A:Print(msg)
        self:AfterPurchase(t)
        return true, msg
    end

    -- Waren: Preis reservieren, Bestätigung mit dem nächsten Druck
    return self:Reserve(plan, false)
end

-- Sofortkauf mit einer Raste möglich? (abschaltbar, schaltet sich bei Problemen selbst ab)
function Sn:InstantEnabled()
    local db = DB()
    return db and db.instantBuy ~= false and not self.instantFailed
end

-- Warenpreis beim Server reservieren.
-- auto = true: vom Sniper selbst beim Treffer (ohne Tastendruck), damit EINE Raste sofort kauft.
function Sn:Reserve(plan, auto)
    local C = A.AH
    local name = A:GetItemName(plan.itemID)
    if not (C.StartCommoditiesPurchase and C.ConfirmCommoditiesPurchase) then
        return false, L["Dein Client unterstützt keinen Warenkauf (StartCommoditiesPurchase fehlt)."]
    end
    local ok, err = pcall(C.StartCommoditiesPurchase, plan.itemID, plan.qty)
    if auto then A:NoteQuery() end
    if not ok then
        if auto then
            self:DisableInstant()
            return false
        end
        return false, L["Kauf fehlgeschlagen: "] .. tostring(err)
    end
    self.pending = {
        key = plan.key, itemID = plan.itemID, qty = plan.qty,
        expected = plan.total, started = Now(), auto = auto or nil,
        state = self.priceEvents and "waiting" or "ready",
        total = (not self.priceEvents) and plan.total or nil,
    }
    if auto then
        A:Fire("SNIPER_CHANGED")
        return true
    end
    local msg
    if self.priceEvents then
        msg = L["Preis wird geprüft: "] .. plan.qty .. "x " .. name .. " ..."
    else
        msg = plan.qty .. "x " .. name .. L[" für ca. "] .. A:FormatMoney(plan.total) .. L[" - nochmal drücken zum Bestätigen"]
    end
    A:Print(msg)
    A:Fire("SNIPER_CHANGED")
    return true, msg
end

function Sn:Confirm()
    local p = self.pending
    if not p then return false, L["Nichts zu bestätigen."] end
    if p.state ~= "ready" then return false, L["Preis wird noch geprüft ..."], true end
    local t = self:GetTarget(p.key)
    self.pending = nil
    if not t then return false, L["Ziel nicht gefunden."] end
    local ok, err = pcall(A.AH.ConfirmCommoditiesPurchase, p.itemID, p.qty)
    if not ok then
        A:Fire("SNIPER_CHANGED")
        return false, L["Kauf fehlgeschlagen: "] .. tostring(err)
    end
    local cost = p.total or p.expected
    CountPurchase(t, p.qty, cost)
    -- gekaufte Menge aus den Angeboten nehmen
    if self.result and self.result.key == p.key then
        local left = p.qty
        for _, l in ipairs(self.result.listings) do
            if left <= 0 then break end
            if l.planned and l.planned > 0 then
                local n = math.min(l.planned, left)
                l.used = (l.used or 0) + n
                left = left - n
            end
        end
    end
    self.lastPurchase = { key = p.key, itemID = p.itemID, qty = p.qty, cost = cost, time = Now() }
    local msg = L["Gekauft: "] .. p.qty .. "x " .. A:GetItemName(p.itemID) .. L[" für "] .. A:FormatMoney(cost)
    A:Print(msg)
    self:AfterPurchase(t)
    return true, msg
end

-- Sofortkauf geht nicht (keine Preisbestätigung vom Server): zurück zu 2 Rasten
function Sn:DisableInstant()
    if self.instantFailed then return end
    self.instantFailed = true
    A:Print(L["Sofortkauf mit einer Raste geht hier nicht (keine Preisbestätigung vom Server) - Waren wieder mit 2 Rasten: 1. reserviert, 2. kauft."])
    A:Fire("SNIPER_CHANGED")
end

function Sn:CancelPending(reason)
    local p = self.pending
    if not p then return end
    self.pending = nil
    if A.AH and A.AH.CancelCommoditiesPurchase then
        pcall(A.AH.CancelCommoditiesPurchase)
    end
    if reason then A:Print(reason) end
    A:Fire("SNIPER_CHANGED")
end

function Sn:AfterPurchase(t)
    if t.watch then
        if self:IsDone(t) then self:RemoveExtraTarget(t.key) end
        if A.Watcher then A.Watcher:OnBought(t) end
        A:Fire("SNIPER_CHANGED")
        return
    end
    if self:IsDone(t) then
        A:Print(L["|cff33dd55Ziel erfüllt:|r "] .. self:TargetName(t) .. " - " .. t.bought .. L[" Stück für "] .. A:FormatMoney(t.spent))
        if #self:GetActiveTargets(false) == 0 and DB().armed then
            A:Print(L["Alle Ziele erfüllt - Sniper-Modus aus."])
            self:SetArmed(false)
        end
    end
    A:Fire("SNIPER_CHANGED")
end

-- Ein Tastendruck / eine Mausrad-Raste / Klick auf "Kaufen"
-- Rückgabe: ok, Meldung, leise (true = keine Meldung nötig)
-- Mausrad über den Fenstern des Addons: Bindungen greifen dort nicht (die Fenster fangen das
-- Rad ab). Wartet ein Treffer und ist das Mausrad die Kauf-Taste, wird hier gekauft.
-- Rückgabe: true = Rad wurde für den Kauf benutzt (nicht blättern)
local function Mods()
    local m = ""
    if IsAltKeyDown and IsAltKeyDown() then m = m .. "ALT-" end
    if IsControlKeyDown and IsControlKeyDown() then m = m .. "CTRL-" end
    if IsShiftKeyDown and IsShiftKeyDown() then m = m .. "SHIFT-" end
    return m
end

function Sn:WheelBuy(delta)
    if not (A:IsAHOpen() and self.HitWaiting and self:HitWaiting()) then return false end
    local key = Mods() .. ((delta or 0) > 0 and "MOUSEWHEELUP" or "MOUSEWHEELDOWN")
    local db = DB()
    local function has(kind)
        for _, k in ipairs(self:GetBinds(kind)) do if k == key then return true end end
        return false
    end
    local s = db and db.armed and has("sniper")
    local w = self:HasExtraTargets() and has("watcher")
    if not (s or w) then return false end
    local kind = (s and w) and nil or (s and "sniper" or "watcher")
    -- passt der wartende Treffer zur Taste?
    local key2 = self.pending and self.pending.key or (self.result and self.result.key)
    if kind then
        local t = key2 and self:GetTarget(key2)
        if ((kind == "watcher") ~= (t and t.watch or false)) then return false end
    end
    local ok, msg = self:OnTrigger(kind)
    if msg and not ok then A:Print(msg) end
    return true
end

-- gehört ein Ziel zur Taste? (kind nil = beide)
local function KindMatches(kind, key)
    if not kind then return true end
    local t = key and Sn:GetTarget(key)
    local isWatch = t and t.watch or false
    return (kind == "watcher") == isWatch
end

function Sn:OnTrigger(kind)
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    if Now() - self.lastPress < PRESS_DEBOUNCE then return false, nil, true end
    self.lastPress = Now()

    if self.pending then
        if not KindMatches(kind, self.pending.key) then return false, nil, true end
        return self:Confirm()
    end

    if self:IsResultFresh() then
        local plan = self:PlanNext()
        if plan and not KindMatches(kind, plan.key) then return false, nil, true end
        if plan then
            -- altes AH: Angebot muss in der Liste stehen - sonst Seite laden, nächste Raste kauft
            if plan.kind == "item" and A.AH.PrepareBuy and plan.listing and not A.AH.PrepareBuy(plan.listing.auctionID) then
                return false, L["Treffer wird geladen - gleich nochmal drehen/drücken."]
            end
            return self:Buy(plan)
        end
    end
    if kind == "watcher" then return false, nil, true end
    -- nichts zu kaufen: sofort weitersuchen (wenn erlaubt)
    local ok, msg, soft = self:CheckNext()
    if soft then return false, nil, true end
    return ok, msg
end

-- ------------------------------------------------------------
-- Ereignisse rund um den Kauf
-- ------------------------------------------------------------
local evt = CreateFrame("Frame")
local function Reg(e) return A:RegisterAHEvent(evt, e) end
Sn.priceEvents = Reg("COMMODITY_PRICE_UPDATED")
Reg("COMMODITY_PRICE_UNAVAILABLE")
Reg("COMMODITY_PURCHASE_FAILED")
Reg("AUCTION_HOUSE_SHOW_ERROR")
Reg("PLAYER_REGEN_ENABLED")

function Sn:OnEvent(event, a1, a2)
    if event == "PLAYER_REGEN_ENABLED" then
        if self.pendingBindings then self:ApplyBindings() end
    elseif event == "COMMODITY_PRICE_UPDATED" then
        local p = self.pending
        if not p or p.state ~= "waiting" then return end
        local unit, total = a1, a2
        local t = self:GetTarget(p.key)
        local budgetLeft = 0
        if t then
            local _, b = self:Remaining(t)
            budgetLeft = b
        end
        if t and unit and total and unit <= t.maxPrice and total <= budgetLeft then
            p.state, p.total, p.started = "ready", total, Now()
            if p.auto then A:Fire("SNIPER_CHANGED"); return end      -- Sofortkauf: eine Raste kauft
            A:Print(L["Preis bestätigt: "] .. p.qty .. "x " .. A:GetItemName(p.itemID) .. L[" für "] .. A:FormatMoney(total)
                .. L[" - nochmal "] .. self:GetBindsText() .. L[" zum Kaufen"])
            A:Fire("SNIPER_CHANGED")
        else
            if p.auto then
                -- vorab geholter Preis passt nicht mehr: Angebote neu suchen statt immer wieder zu reservieren
                self.result = nil
                self:CancelPending(L["Treffer ist weg - Preis inzwischen gestiegen ("] .. A:FormatMoney(total) .. L[")."])
            else
                self:CancelPending(L["Preis ist inzwischen gestiegen ("] .. A:FormatMoney(total) .. L[") - Kauf abgebrochen."])
            end
        end
    elseif event == "COMMODITY_PRICE_UNAVAILABLE" then
        local p = self.pending
        if p and p.auto then
            self.result = nil
            self:CancelPending(L["Treffer ist weg - Angebot nicht mehr verfügbar."])
        else
            self:CancelPending(L["Angebot nicht mehr verfügbar - Kauf abgebrochen."])
        end
    elseif event == "COMMODITY_PURCHASE_FAILED" or event == "AUCTION_HOUSE_SHOW_ERROR" then
        local lp = self.lastPurchase
        if lp and Now() - lp.time < 5 then
            local t = self:GetTarget(lp.key)
            if t then
                t.bought = math.max(0, (t.bought or 0) - lp.qty)
                t.spent = math.max(0, (t.spent or 0) - lp.cost)
            end
            if lp.listing then lp.listing.used = nil end
            self.lastPurchase = nil
            A:Print(L["|cffff5544Kauf fehlgeschlagen|r (Angebot weg oder nicht genug Gold) - Zähler korrigiert."])
            A:Fire("SNIPER_CHANGED")
        end
    end
end

evt:SetScript("OnEvent", function(_, event, a1, a2) Sn:OnEvent(event, a1, a2) end)

-- ------------------------------------------------------------
-- Auslöser: Mausrad oder selbst gewählte Taste
-- Aktiv nur im Sniper-Modus UND bei offenem Auktionshaus.
-- Über Listen/Fenstern scrollt das Mausrad weiter normal.
-- ------------------------------------------------------------
-- drei Auslöser: gleiche Taste für beide / nur Sniper-Treffer / nur Wächter-Treffer
local function MakeTrigger(name, kind)
    local b = CreateFrame("Button", name, UIParent)
    b:Hide()
    b:SetScript("OnClick", function()
        local ok, msg = Sn:OnTrigger(kind)
        if msg and not ok then A:Print(msg) end
    end)
    return b
end
local triggerButton = MakeTrigger("AHAnalyzerProSnipeButton", nil)
local sniperButton = MakeTrigger("AHAnalyzerProSnipeOnlyButton", "sniper")
local watcherButton = MakeTrigger("AHAnalyzerProWatchButton", "watcher")
Sn.triggerButton, Sn.sniperButton, Sn.watcherButton = triggerButton, sniperButton, watcherButton

local KEY_NAMES = {
    MOUSEWHEELUP = "Mausrad hoch",
    MOUSEWHEELDOWN = "Mausrad runter",
    BUTTON3 = "Mittlere Maustaste",
    BUTTON4 = "Maustaste 4",
    BUTTON5 = "Maustaste 5",
}

function Sn:KeyName(key)
    if not key then return "-" end
    local mods, base = key:match("^(.*%-)(.-)$")
    if not base or base == "" then mods, base = "", key end
    local name = KEY_NAMES[base] and L[KEY_NAMES[base]]
    if not name and GetBindingText then
        local ok, txt = pcall(GetBindingText, base)
        if ok and txt and txt ~= "" then name = txt end
    end
    mods = mods:gsub("SHIFT%-", "Shift+"):gsub("CTRL%-", L["Strg+"]):gsub("ALT%-", "Alt+")
    return mods .. (name or base)
end

-- Tasten: kind = "sniper" (Standard) oder "watcher" - jede Seite hat ihre eigene Belegung
local WHEEL = { "MOUSEWHEELUP", "MOUSEWHEELDOWN" }
function Sn:GetBinds(kind)
    if kind == "watcher" then
        local w = A.db and A.db.watcher
        if w and not w.binds then w.binds = { WHEEL[1], WHEEL[2] } end
        return w and w.binds or {}
    end
    local db = DB()
    return db and db.binds or {}
end

function Sn:IsMouseWheelBind(kind)
    local b = self:GetBinds(kind)
    return #b == 2 and b[1] == WHEEL[1] and b[2] == WHEEL[2]
end

function Sn:GetBindsText(kind)
    local b = self:GetBinds(kind)
    if #b == 0 then return L["keine Taste"] end
    if self:IsMouseWheelBind(kind) then return L["Mausrad"] end
    local names = {}
    for _, k in ipairs(b) do table.insert(names, self:KeyName(k)) end
    return table.concat(names, " / ")
end

function Sn:SetBinds(list, kind)
    if kind == "watcher" then
        if not (A.db and A.db.watcher) then return end
        A.db.watcher.binds = list
    else
        local db = DB()
        if not db then return end
        db.binds = list
    end
    self:ApplyBindings()
    A:Fire("SNIPER_CHANGED")
    A:Fire("WATCHER_CHANGED")
end

function Sn:UseMouseWheel(kind)
    self:SetBinds({ WHEEL[1], WHEEL[2] }, kind)
end

function Sn:IsArmed()
    local db = DB()
    if not (db and A:IsAHOpen()) then return false end
    if db.armed then return true end
    return self:HasExtraTargets()      -- Wächter hat Schnäppchen: Taste/Mausrad kauft diese
end

function Sn:SetArmed(on)
    local db = DB()
    if not db then return end
    db.armed = on and true or false
    if not db.armed then self:CancelPending() end
    self:ApplyBindings()
    A:Fire("SNIPER_CHANGED")
end

function Sn:ToggleArmed()
    local db = DB()
    if not db then return end
    self:SetArmed(not db.armed)
    A:Print(L["Sniper-Modus "] .. (db.armed and (L["|cff33dd55AN|r - Kaufen mit "] .. self:GetBindsText()) or L["|cffff5544AUS|r"]))
end

function Sn:ApplyBindings()
    if not (SetOverrideBindingClick and ClearOverrideBindings) then return end
    if InCombatLockdown and InCombatLockdown() then
        self.pendingBindings = true          -- im Kampf nicht erlaubt, danach nachholen
        return
    end
    self.pendingBindings = false
    ClearOverrideBindings(triggerButton)
    ClearOverrideBindings(sniperButton)
    ClearOverrideBindings(watcherButton)
    local db = DB()
    if not (db and A:IsAHOpen()) then return end
    -- Sniper-Taste: im Sniper-Modus; Wächter-Taste: sobald der Wächter Schnäppchen gefunden hat
    -- (sonst bleibt das Mausrad frei für die Kamera)
    local snOn = db.armed and true or false
    local wOn = self:HasExtraTargets()
    local sKeys, wKeys = {}, {}
    if snOn then for _, k in ipairs(self:GetBinds("sniper")) do sKeys[k] = true end end
    if wOn then for _, k in ipairs(self:GetBinds("watcher")) do wKeys[k] = true end end
    for k in pairs(sKeys) do
        if wKeys[k] then
            pcall(SetOverrideBindingClick, triggerButton, true, k, "AHAnalyzerProSnipeButton")
        else
            pcall(SetOverrideBindingClick, sniperButton, true, k, "AHAnalyzerProSnipeOnlyButton")
        end
    end
    for k in pairs(wKeys) do
        if not sKeys[k] then pcall(SetOverrideBindingClick, watcherButton, true, k, "AHAnalyzerProWatchButton") end
    end
end

-- ------------------------------------------------------------
-- Selbstständige Suche (nur Sniper-Modus AN + Auktionshaus offen)
-- ------------------------------------------------------------
function Sn:Tick()
    if self.search then
        self:PollSearch()
        return
    end

    local p = self.pending
    if p then
        if p.state == "waiting" and Now() - p.started > 5 then
            if p.auto then
                self:CancelPending()
                self:DisableInstant()
            else
                self:CancelPending(L["Keine Preisbestätigung vom Server - Kauf abgebrochen."])
            end
        elseif p.auto and p.state == "ready" and Now() - p.started > AUTO_REQUOTE then
            self:CancelPending()          -- Preis gleich frisch holen (nächster Takt)
        elseif p.state == "ready" and Now() - p.started > CONFIRM_TIMEOUT then
            self:CancelPending(L["Reservierter Preis verfallen - Kauf abgebrochen."])
        end
        -- vorab reservierter Sofortkauf: weitersuchen; sonst wartet der Kauf auf dich
        p = self.pending
        if p and not (p.auto and p.state == "ready") then return end
    end

    if not self:IsArmed() then return end
    if A:IsScanning() then return end
    if A.Buy and A.Buy:Blocks() then return end       -- Einkauf hat Vorrang
    if A.Seller and A.Seller.HasWork and A.Seller:HasWork() then return end   -- Preisprüfung auch

    -- Treffer wartet: Signal wiederholen (solange er kaufbar ist)
    if self:HitWaiting() then
        local plan = self:PlanNext()
        if plan then
            local t = self:GetTarget(plan.key)
            if t and not t.watch then self:Alert(plan, false) end
            -- altes AH: Treffer muss in der Liste des Auktionshauses bleiben, sonst lässt er sich
            -- nicht kaufen -> nichts anderes suchen, Treffer nur ab und zu nachprüfen
            if A.AH_LEGACY then
                if plan.kind == "item" and plan.listing and A.AH.PrepareBuy then A.AH.PrepareBuy(plan.listing.auctionID) end
                if Now() - self.lastSearch >= FOCUS_RECHECK and A:CanQueryNow() and not self.pending then
                    self:Search(plan.key)
                end
                return
            end
        end
    end
    -- Treffer wartet auf deinen Kauf: Waren-Preis vorab holen (eine Raste kauft) - die Suche läuft weiter
    if not self.pending and self:IsResultFresh() then
        local plan = self:PlanNext()
        if plan and plan.kind == "commodity" and self:InstantEnabled() and A:QueryReady() then
            self:Reserve(plan, true)
            return
        end
    end
    -- neue Wächter-Schnäppchen sofort prüfen, sonst im eingestellten Abstand (Standard: so oft der Server erlaubt)
    local urgent = false
    for _, t in pairs(self.extra) do if not t.checked then urgent = true end end
    local interval = urgent and 0 or math.max(MIN_INTERVAL, DB().interval or 0)
    if Now() - self.lastSearch < interval then return end
    local W = A.Watcher
    if W and W:IsBusy() then return end
    -- abwechseln: war der Sniper seit der letzten Wächter-Runde schon dran, kommt jetzt der Wächter
    if not urgent and W and W.WantsTurn and W:WantsTurn() and self.lastSearch > (W.lastRound or -100) then return end
    self:CheckNext()
end

-- Ergebnisse sofort auswerten, sobald der Server sie meldet
A:On("SEARCH_RESULTS", function()
    if Sn.search then Sn.search.answered = true; Sn:PollSearch() end
end)
A:On("BROWSE_RESULTS", function()
    if Sn.search and Sn.search.stage == "browse" then Sn.search.answered = true; Sn:PollSearch() end
end)

local ticker = CreateFrame("Frame")
local acc = 0
ticker:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    if acc < 0.1 then return end
    acc = 0
    Sn:Tick()
end)

A:On("AH_STATE", function()
    if not A:IsAHOpen() then
        Sn.search = nil
        Sn:CancelPending()
        wipe(Sn.extra)
    end
    Sn:ApplyBindings()
    A:Fire("SNIPER_CHANGED")
end)
A:On("READY", function()
    Sn:ImportOld()
    Sn:ApplyBindings()
end)

-- ------------------------------------------------------------
-- Item in der normalen Auktionshaus-Suche öffnen
-- ------------------------------------------------------------
function Sn:OpenInAH(itemID)
    if not itemID then return false, L["Kein Item gewählt."] end
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    local name = A:GetClientItemName(itemID)    -- das Auktionshaus sucht in der Sprache des Clients
    -- Addon-Ansicht im Auktionshaus offen: erst zur Blizzard-Ansicht wechseln
    local UI = A.UI
    if UI and UI.ahOverlay and UI.ahOverlay:IsShown() and UI.LeaveAH then pcall(UI.LeaveAH, UI) end
    -- klassisches Auktionshaus (Classic Era, WoW Forever, TBC, Wrath): Reiter "Durchsuchen"
    if type(AuctionFrame) == "table" and not (type(AuctionHouseFrame) == "table") then
        local browse = _G.AuctionFrameBrowse
        if not (browse and browse:IsShown()) and _G.AuctionFrameTab1 and _G.AuctionFrameTab1.Click then
            pcall(_G.AuctionFrameTab1.Click, _G.AuctionFrameTab1)
        end
        local box = _G.BrowseName
        if box and box.SetText then
            pcall(box.SetText, box, name)
            if type(AuctionFrameBrowse_Search) == "function" and pcall(AuctionFrameBrowse_Search) then
                return true, L["Im Auktionshaus gesucht: "] .. name
            end
            local btn = _G.BrowseSearchButton
            if btn and btn.Click and pcall(btn.Click, btn) then
                return true, L["Im Auktionshaus gesucht: "] .. name
            end
            return true, L["Name eingetragen - im Auktionshaus auf Suchen klicken."]
        end
    end
    local bar = AuctionHouseFrame and AuctionHouseFrame.SearchBar
    local box = bar and bar.SearchBox
    if box and box.SetText then
        pcall(box.SetText, box, name)
        if bar.StartSearch then
            local ok = pcall(bar.StartSearch, bar)
            if ok then return true, L["Im Auktionshaus gesucht: "] .. name end
        end
        return true, L["Name eingetragen - im Auktionshaus auf Suchen klicken."]
    end
    return false, L["Suchfeld des Auktionshauses nicht gefunden. Suche dort nach: "] .. name
end

function Sn:GetStatusText()
    local db = DB()
    if not db then return "" end
    if not db.armed then
        if self:IsArmed() and not self.pending then
            if self:IsResultFresh() and self:PlanNext() then
                return L["|cff33dd55Schnäppchen! "] .. self:GetBindsText("watcher") .. L[" zum Kaufen|r"]
            end
            return L["|cffffcc33Wächter: Schnäppchen werden geprüft ...|r"]
        end
        if not self.pending then return L["|cffff5544Sniper-Modus AUS|r"] end
    end
    if not A:IsAHOpen() then return L["|cffffcc33Sniper-Modus AN - wartet auf das Auktionshaus|r"] end
    if self.pending then
        if self.pending.state == "ready" then
            if self.pending.auto then return L["|cff33dd55Treffer! "] .. self:GetBindsText() .. L[" zum Kaufen|r"] end
            return L["|cff33dd55Preis reserviert: "] .. self:GetBindsText() .. L[" zum Bestätigen|r"]
        end
        return L["|cffffcc33Preis wird geprüft ...|r"]
    end
    if self.search then
        local t = self:GetTarget(self.search.targetKey)
        return L["|cffffcc33Sucht: "] .. (t and self:TargetName(t) or "?") .. "|r"
    end
    if self:IsResultFresh() and self:PlanNext() then
        return L["|cff33dd55Treffer! "] .. self:GetBindsText() .. L[" zum Kaufen|r"]
    end
    if #self:GetActiveTargets(false) == 0 then return L["|cffaaaaaaKeine offenen Ziele|r"] end
    return L["|cff33dd55Sniper-Modus AN - sucht selbstständig|r"]
end

function Sn:GetDebugText()
    local api = self:CheckAPI()
    local function yn(b) return b and L["ja"] or L["nein"] end
    local db = DB()
    return L["Einzel-Suche="] .. yn(api.SendSearchQuery)
        .. L[", Suchbegriff="] .. yn(api.SendBrowseQuery)
        .. L[", Sofortkauf="] .. yn(api.PlaceBid)
        .. L[", Warenkauf="] .. yn(api.CommodityBuy)
        .. L[", Preis-Events="] .. yn(self.priceEvents)
        .. L[", Sofortkauf="] .. yn(self:InstantEnabled())
        .. L[", Tastenbelegung="] .. yn(api.Bindings)
        .. L[", Modus="] .. (self:IsArmed() and L["scharf"] or (db and db.armed and L["an (AH zu)"] or L["aus"]))
        .. L[", Auslöser="] .. self:GetBindsText()
        .. L[", Ziele="] .. #self:GetTargets() .. L[" (offen "] .. #self:GetActiveTargets() .. ")"
end
