-- BuffSentinel - Core.lua
-- Grundgerüst: Versionserkennung, Datenbank, API-Hilfen, Skillungs-/Zauberbuch-Erkennung, Zonen-Logik, Events

local ADDON, BS = ...
_G.BuffSentinel = BS

BS.version        = "0.9.1"
BS.ClassData      = BS.ClassData or {}
BS.pools          = { buff = {}, proc = {}, cd = {} }
BS.entries        = {}
BS.known          = {}
BS.talents        = {}
BS.talentList     = {}
BS.allTalents     = {}
BS.talentByName   = {}
BS.talentByPos    = {}
BS.talentSig      = ""
BS.points         = { 0, 0, 0 }
BS.mainSpec       = 0
BS.playerAuras    = {}
BS.playerAuraInfo = {}
BS.groupMissing   = {}
BS.triggers       = {}
BS.GCD_LIMIT      = 1.6

BS.COLORS = {
    accent = { 1.00, 0.65, 0.20 },
    green  = { 0.40, 0.85, 0.45 },
    yellow = { 1.00, 0.82, 0.25 },
    red    = { 0.95, 0.35, 0.35 },
    dim    = { 0.55, 0.55, 0.60 },
    text   = { 0.90, 0.90, 0.92 },
}

------------------------------------------------------------------------
-- Versionserkennung
--   expansion: 1 Classic Era/SoD/Hardcore + WoW Forever, 2 TBC, 3 Wrath/Titan, 4 Cata, 5 MoP, 12 Retail
--   family:    "classic" = Talentbäume (Era bis Cata, Forever), "modern" = Spezialisierungen (MoP, Retail)
------------------------------------------------------------------------
do
    local build = select(4, GetBuildInfo()) or 0
    BS.interface = build
    local exp, flavor
    if build >= 100000 then     exp, flavor = 12, "retail"
    elseif build >= 50000 then  exp, flavor = 5,  "mists"
    elseif build >= 40000 then  exp, flavor = 4,  "cata"
    elseif build >= 38000 then  exp, flavor = 3,  "titan"
    elseif build >= 30000 then  exp, flavor = 3,  "wrath"
    elseif build >= 20000 then  exp, flavor = 2,  "tbc"
    elseif build >= 16000 then  exp, flavor = 1,  "forever"
    else                        exp, flavor = 1,  "era"
    end
    BS.expansion = exp
    BS.flavor    = flavor
    BS.family    = (exp >= 5) and "modern" or "classic"
    BS.isForever = flavor == "forever"
    BS.isRetail  = flavor == "retail"
    -- WoW Forever und Retail laufen auf dem modernen Client mit denselben Addon-Sperren:
    -- kein Kampflog, im Kampf "geheime Werte" (Auren, Namen, Lebenspunkte, Abklingzeiten).
    BS.restricted = BS.isRetail or BS.isForever
end

-- Sperren wirklich aktiv? Eingeschränkter Client UND das Spiel kennt geheime Werte (Weiche über die Funktion,
-- nicht nur über die Versionsnummer). Classic Era, TBC, Wrath, Cata, MoP Classic: immer false.
function BS:Locked()
    return self.restricted == true and type(issecretvalue) == "function"
end

function BS:CombatLocked()
    return self:Locked() and (InCombatLockdown() or UnitAffectingCombat("player")) and true or false
end

-- Einmaliger Hinweis, wenn im Kampf keine Daten kommen (pro Sitzung)
function BS:NoteSecret()
    if self.secretNoted then return end
    self.secretNoted = true
    BS.Print("Im Kampf gibt " .. (BS.FLAVOR_NAMES[self.flavor] or "dieser Client") .. " Addons keine Buff- und " ..
        "Abklingzeit-Daten. Buff-Erinnerungen kommen vor dem Pull – für Procs im Kampf den Cooldown Manager des Spiels nutzen.")
end

BS.FLAVOR_NAMES = {
    era = "Classic Era / SoD / Hardcore", forever = "WoW Forever", tbc = "Burning Crusade Classic",
    wrath = "Wrath of the Lich King Classic", titan = "Titan Reforged", cata = "Cataclysm Classic",
    mists = "Mists of Pandaria Classic", retail = "Retail (Midnight)",
}

------------------------------------------------------------------------
-- Ausgabe
------------------------------------------------------------------------
function BS.Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cffffa733BuffSentinel|r: " .. tostring(msg))
end

------------------------------------------------------------------------
-- API-Hilfen (funktionieren mit alter und neuer Client-API)
------------------------------------------------------------------------
-- Retail (Midnight) liefert im Kampf "geheime Werte", mit denen Addons nicht rechnen dürfen
function BS.IsSecret(v)
    return issecretvalue ~= nil and v ~= nil and issecretvalue(v) == true
end

function BS.SpellInfo(spell)
    if spell == nil then return end
    if C_Spell and C_Spell.GetSpellInfo then
        local info = C_Spell.GetSpellInfo(spell)
        if info then return info.name, info.iconID, info.spellID end
        return
    end
    if GetSpellInfo then
        local name, _, icon, _, _, _, id = GetSpellInfo(spell)
        return name, icon, id
    end
end

function BS.GetCooldown(spell)
    if not spell then return 0, 0 end
    if C_Spell and C_Spell.GetSpellCooldown then
        local cd = C_Spell.GetSpellCooldown(spell)
        if cd and (BS.IsSecret(cd.startTime) or BS.IsSecret(cd.duration)) then
            return 0, 0, true          -- geheim: nicht "bereit" melden, Aufrufer prüft den 3. Wert
        end
        if cd then return cd.startTime or 0, cd.duration or 0 end
        return 0, 0
    end
    if GetSpellCooldown then
        local s, d = GetSpellCooldown(spell)
        return s or 0, d or 0
    end
    return 0, 0
end

function BS.IsUsable(spell)
    if not spell then return false, false end
    if C_Spell and C_Spell.IsSpellUsable then
        local usable, noMana = C_Spell.IsSpellUsable(spell)
        if BS.IsSecret(usable) then return false, false end
        return usable and true or false, noMana and true or false
    end
    if IsUsableSpell then
        local usable, noMana = IsUsableSpell(spell)
        return usable and true or false, noMana and true or false
    end
    return true, false
end

-- true = in Reichweite, false = ausser Reichweite, nil = keine Prüfung möglich
function BS.InRange(spell, unit)
    if not spell or not unit then return nil end
    local r
    if C_Spell and C_Spell.IsSpellInRange then
        r = C_Spell.IsSpellInRange(spell, unit)
    elseif IsSpellInRange then
        r = IsSpellInRange(spell, unit)
    end
    if r == nil or BS.IsSecret(r) then return nil end
    return (r == true or r == 1)
end

function BS.IsReady(spell)
    local s, d, secret = BS.GetCooldown(spell)
    if secret then return false end
    if not s or s == 0 or d <= BS.GCD_LIMIT then return true end
    return (s + d - GetTime()) <= 0.05
end

function BS.KnowsSpellID(id)
    if type(id) ~= "number" then return false end
    if IsPlayerSpell and IsPlayerSpell(id) then return true end
    if IsSpellKnown and IsSpellKnown(id) then return true end
    return false
end

-- Gegenstände (Gifte u. ä.)
function BS.ItemCount(id)
    if C_Item and C_Item.GetItemCount then return C_Item.GetItemCount(id) or 0 end
    if GetItemCount then return GetItemCount(id) or 0 end
    return 0
end

function BS.ItemIcon(id)
    if C_Item and C_Item.GetItemIconByID then return C_Item.GetItemIconByID(id) end
    if GetItemIcon then return GetItemIcon(id) end
end

function BS.ItemName(id)
    if C_Item and C_Item.GetItemNameByID then return C_Item.GetItemNameByID(id) end
    if GetItemInfo then return (GetItemInfo(id)) end
end

function BS.HasOffhandWeapon()
    if OffhandHasWeapon then return OffhandHasWeapon() and true or false end
    local link = GetInventoryItemLink and GetInventoryItemLink("player", 17)
    if not link then return false end
    local info = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
    if info then
        local classID = select(6, info(link))
        return classID == 2
    end
    return true
end

-- Füllt out[name] = spellId (oder true) für alle hilfreichen Auren einer Einheit
function BS.ScanAuras(unit, out)
    out = out or {}
    wipe(out)
    if not UnitExists(unit) then return out end
    for i = 1, 40 do
        if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
            local a = C_UnitAuras.GetAuraDataByIndex(unit, i, "HELPFUL")
            if not a then break end
            if a.name and not BS.IsSecret(a.name) then
                out[a.name] = (not BS.IsSecret(a.spellId) and a.spellId) or true
            end
        else
            local name, _, _, _, _, _, _, _, _, spellId = UnitBuff(unit, i)
            if not name then break end
            out[name] = spellId or true
        end
    end
    return out
end

function BS.HasAny(auras, names)
    if not auras or not names then return false end
    for n in pairs(names) do
        if auras[n] then return true end
    end
    return false
end

function BS.FormatTime(sec)
    if sec >= 60 then return string.format("%dm", math.floor(sec / 60 + 0.5)) end
    if sec < 3 then return string.format("%.1f", sec) end
    return string.format("%d", math.floor(sec + 0.5))
end

-- Grossbuchstaben inkl. Umlaute (strupper wandelt nur A-Z um: aus "stärke" würde sonst "STäRKE")
local UMLAUT_UPPER = { ["ä"] = "Ä", ["ö"] = "Ö", ["ü"] = "Ü", ["é"] = "É", ["è"] = "È", ["à"] = "À", ["ç"] = "Ç" }
function BS.Upper(text)
    text = strupper(text or "")
    for lower, upper in pairs(UMLAUT_UPPER) do text = text:gsub(lower, upper) end
    return text
end

function BS.Contains(list, value)
    if not list then return false end
    for _, v in ipairs(list) do
        if v == value then return true end
    end
    return false
end

-- Testmodus (alle Klassen durchschalten) nur für den Entwickler – siehe GoldSentinelDev.lua.
-- "Anordnen" (eigene Buttons verschieben) bleibt für alle.
function BS:IsDev()
    return GoldSentinelDev ~= nil and GoldSentinelDev:IsDev() == true
end

function BS:InCombat()
    return InCombatLockdown() or UnitAffectingCombat("player")
end

------------------------------------------------------------------------
-- Datenbank
------------------------------------------------------------------------
local DEFAULTS = {
    zones = {
        world     = true,   -- Offene Welt
        dungeon   = true,
        raid      = true,
        pvp       = true,   -- Schlachtfelder / Arena
        resting   = false,  -- Hauptstädte & Gasthäuser
        sanctuary = false,  -- Schutzgebiete
    },
    cdWorldCombatOnly = true,
    cdTimer = true,
    -- Töne standardmässig aus; einzelne Einträge können eine eigene Klingel haben (z. B. Schlachtruf)
    sound   = { buff = false, proc = false, cooldown = false, dispel = false },
    hornSelfBuff = true,   -- alt (bis 0.8.6), wird nach soundBase übernommen
    hornEvery    = 5,      -- Sekunden zwischen zwei Hupern
    soundBase    = {},     -- Warntöne: Standard für alle Skillungen (Sounds.lua)
    soundSpecs   = {},     -- Warntöne: Abweichungen pro Skillung
    soundChannel = "Master",
    dispel  = { friendly = true },   -- Reinigungsleiste für Mitspieler
    locked  = true,
    scale   = 1.0,
    groupScale = { proc = 1.0, buff = 1.0, cd = 1.0, dispel = 1.0 },   -- Grösse pro Gruppe (x Gesamtgrösse)
    minimap = { angle = 220, hide = false },
    pos     = {},   -- Position der Gruppen (Procs, Buffs, Cooldowns, Reinigen)
    btnPos  = {},   -- frei platzierte einzelne Buttons
    winPos  = {},   -- Fenster (Einstellungen, Gruppen-Raster, Test- und Anordnen-Leiste)
    -- Anordnung pro Gruppe: senkrecht statt waagrecht, zusätzlicher Abstand in Pixeln
    groupLayout = { proc = { vertical = false, gap = 0 }, buff = { vertical = false, gap = 0 }, cd = { vertical = false, gap = 0 } },
    specs   = {},   -- Einstellungen pro Skillung
    custom  = {},   -- eigene Procs aus der Aufnahme
}

local function CopyDefaults(src, dst)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then dst[k] = {} end
            CopyDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

function BS:InitDB()
    BuffSentinelDB = BuffSentinelDB or {}
    local g = BuffSentinelDB
    g.profiles = g.profiles or {}
    g.recorder = g.recorder or {}
    g.recorder.list = g.recorder.list or {}
    g.recorder.seen = g.recorder.seen or {}
    if g.recorder.enabled == nil then g.recorder.enabled = false end
    -- Gelernte Namen gelten für alle Charaktere des Accounts
    g.learned = g.learned or {}
    g.learned.talents = g.learned.talents or {}
    g.learned.spells = g.learned.spells or {}
    if g.shareNames == nil then g.shareNames = true end     -- Gilde + Gruppe
    if g.shareServer == nil then g.shareServer = true end   -- alle Nutzer auf dem Server (Sync-Kanal)
    -- Automatisch gelernte Procs und Fähigkeiten (pro Klasse, für alle Charaktere des Accounts)
    g.auto = g.auto or {}
    g.auto.classes = g.auto.classes or {}
    if g.auto.enabled == nil then g.auto.enabled = true end
    if g.auto.share == nil then g.auto.share = true end

    local key = (UnitName("player") or "?") .. "-" .. (GetRealmName() or "?")
    g.profiles[key] = g.profiles[key] or {}
    CopyDefaults(DEFAULTS, g.profiles[key])

    self.gdb = g
    self.db  = g.profiles[key]
    -- 0.8.4: Töne neu standardmässig aus (einmalig auch für bestehende Profile)
    if not self.db.soundV2 then
        for k in pairs(self.db.sound) do self.db.sound[k] = false end
        self.db.soundV2 = true
    end
    if self.MigrateSounds then self:MigrateSounds() end
end

------------------------------------------------------------------------
-- Fenster: verschiebbar, Position wird gespeichert
------------------------------------------------------------------------
BS.windows = {}

function BS:PlaceWindow(key)
    local w = self.windows[key]
    if not w or not self.db then return end
    if InCombatLockdown() and w.secure then return end
    local p = self.db.winPos[key] or w.default
    w.frame:ClearAllPoints()
    w.frame:SetPoint(p[1], UIParent, p[2], p[3], p[4])
end

-- default = { Punkt, UIParent-Punkt, x, y }; secure = Fenster mit Klick-Buttons (im Kampf gesperrt)
function BS:RegisterWindow(f, key, default, secure)
    self.windows[key] = { frame = f, default = default, secure = secure }
    f:SetMovable(true)
    f:EnableMouse(true)
    f:SetClampedToScreen(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(s)
        if not (secure and InCombatLockdown()) then s:StartMoving() end
    end)
    f:SetScript("OnDragStop", function(s)
        s:StopMovingOrSizing()
        if s.SetUserPlaced then s:SetUserPlaced(false) end
        local p1, _, p2, x, y = s:GetPoint()
        if p1 then BS.db.winPos[key] = { p1, p2, x, y } end
    end)
    self:PlaceWindow(key)
end

function BS:ResetWindows()
    wipe(self.db.winPos)
    for key in pairs(self.windows) do self:PlaceWindow(key) end
end

-- Jede Skillung hat eigene Einstellungen
function BS:EntryStore()
    -- Testmodus mit fremder Klasse: eigene Einstellungen nicht verändern
    if self.testClass then
        self.testStore = self.testStore or {}
        return self.testStore
    end
    local k = "spec" .. tostring(self.mainSpec or 0)
    self.db.specs[k] = self.db.specs[k] or {}
    return self.db.specs[k]
end

function BS:CountOverrides()
    local n = 0
    for _, s in pairs(self:EntryStore()) do
        if s.enabled ~= nil then n = n + 1 end
    end
    return n
end

function BS:ResetEntrySettings()
    wipe(self:EntryStore())
    self:SettingsChanged()
end

function BS:SetEntrySetting(key, field, value)
    local store = self:EntryStore()
    store[key] = store[key] or {}
    store[key][field] = value
    self:SettingsChanged()
end

------------------------------------------------------------------------
-- Zauberbuch
------------------------------------------------------------------------
-- known:       alle Zaubernamen im Zauberbuch (auch Allgemein/Volk)
-- classSpells: aktive Klassenzauber (ohne Allgemein, ohne passive, ohne andere Spezialisierungen) -> Spell-ID
-- Noch nicht erlernte Zauber (Cata/MoP/Retail zeigen sie grau im Zauberbuch) zählen nicht.
local function IsPassiveSlot(i, book, id)
    if IsPassiveSpell then
        local ok, p = pcall(IsPassiveSpell, i, book)
        if ok and p then return true end
    end
    if id and C_Spell and C_Spell.IsSpellPassive then
        local ok, p = pcall(C_Spell.IsSpellPassive, id)
        if ok and p then return true end
    end
    return false
end

function BS:ScanSpellbook()
    local known, classSpells, count = {}, {}, 0
    if C_SpellBook and C_SpellBook.GetNumSpellBookSkillLines then
        local bank = (Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player) or 0
        local FUTURE = Enum and Enum.SpellBookItemType and Enum.SpellBookItemType.FutureSpell
        for line = 1, C_SpellBook.GetNumSpellBookSkillLines() do
            local info = C_SpellBook.GetSpellBookSkillLineInfo(line)
            if info and not info.shouldHide and not (info.offSpecID and info.offSpecID ~= 0) then
                for i = info.itemIndexOffset + 1, info.itemIndexOffset + info.numSpellBookItems do
                    local name = C_SpellBook.GetSpellBookItemName(i, bank)
                    local item = C_SpellBook.GetSpellBookItemInfo and C_SpellBook.GetSpellBookItemInfo(i, bank)
                    local future = item and FUTURE and item.itemType == FUTURE
                    if name and not future then
                        known[name] = true; count = count + 1
                        if line > 1 and item and type(item.spellID) == "number" and not item.isPassive then
                            classSpells[name] = item.spellID
                        end
                    end
                end
            end
        end
    elseif GetNumSpellTabs then
        local book = BOOKTYPE_SPELL or "spell"
        for tab = 1, GetNumSpellTabs() do
            local _, _, offset, num, _, offSpec = GetSpellTabInfo(tab)
            if offset and num and not (offSpec and offSpec ~= 0) then
                for i = offset + 1, offset + num do
                    local name
                    if GetSpellBookItemName then
                        name = GetSpellBookItemName(i, book)
                    elseif GetSpellName then
                        name = GetSpellName(i, "spell")
                    end
                    local stype, sid
                    if GetSpellBookItemInfo then stype, sid = GetSpellBookItemInfo(i, book) end
                    if name and stype ~= "FUTURESPELL" then
                        known[name] = true; count = count + 1
                        if tab > 1 and type(sid) == "number" and stype ~= "FLYOUT" and not IsPassiveSlot(i, book, sid) then
                            classSpells[name] = sid
                        end
                    end
                end
            end
        end
    end
    self.known = known
    self.classSpells = classSpells
    self.spellbookOK = count > 0
end

function BS:IsKnown(name)
    if not name then return false end
    if self.testClass then return true end   -- Testmodus mit fremder Klasse: alles "gelernt"
    if not self.spellbookOK then return true end -- Fallback: Zauberbuch nicht lesbar
    return self.known[name] == true
end

------------------------------------------------------------------------
-- Talente / Spezialisierung
------------------------------------------------------------------------
-- Classic-Familie (Era, Forever, TBC, Wrath, Titan, Cata): Talentbäume.
-- Die Position (Baum:Reihe:Spalte) ist in jeder Client-Sprache gleich und dient zum Lernen der Namen.
function BS:ScanTalentTrees()
    local talents, list, points, sig = {}, {}, { 0, 0, 0 }, {}
    local all, byName, byPos = {}, {}, {}
    local tabs = 0
    -- Zweitskillung: ausdrücklich die aktive Talentgruppe lesen
    local group = nil
    if GetActiveTalentGroup then
        local ok, g = pcall(GetActiveTalentGroup, false, false)
        if ok and type(g) == "number" then group = g end
    end
    if GetNumTalentTabs and GetTalentInfo then
        tabs = GetNumTalentTabs() or 0
        for tab = 1, tabs do
            points[tab] = points[tab] or 0
            for i = 1, (GetNumTalents(tab) or 0) do
                local name, icon, tier, column, rank, maxRank
                if group then
                    name, icon, tier, column, rank, maxRank = GetTalentInfo(tab, i, false, false, group)
                else
                    name, icon, tier, column, rank, maxRank = GetTalentInfo(tab, i)
                end
                if type(name) == "string" then
                    rank = rank or 0
                    local t = {
                        name = name, icon = icon, rank = rank, maxRank = maxRank or rank, tab = tab,
                        tier = tier or 0, column = column or 0,
                        pos = tab .. ":" .. (tier or 0) .. ":" .. (column or 0),
                    }
                    tinsert(all, t)
                    byName[strlower(name)] = t
                    byPos[t.pos] = t
                    if rank > 0 then
                        talents[strlower(name)] = rank
                        points[tab] = points[tab] + rank
                        tinsert(list, t)
                        tinsert(sig, name .. rank)
                    end
                end
            end
        end
    end
    local main, best = 0, 0
    for tab = 1, 3 do
        if (points[tab] or 0) > best then best = points[tab]; main = tab end
    end
    -- Nur Cataclysm hat einen gewählten Hauptbaum. Andere Clients (z. B. TBC Anniversary) kennen die
    -- Funktion teils auch, liefern dort aber keinen sinnvollen Wert -> dort zählt der Baum mit den meisten Punkten.
    if self.expansion == 4 and GetPrimaryTalentTree then
        local ok, primary = pcall(GetPrimaryTalentTree)
        if ok and type(primary) == "number" and primary > 0 then main = primary end
    end
    self.talents, self.talentList, self.points, self.mainSpec = talents, list, points, main
    self.allTalents, self.talentByName, self.talentByPos = all, byName, byPos
    self.talentsReadable = tabs > 0
    self.talentSig = main .. "|" .. table.concat(sig, ",")
end

-- Moderne Familie (MoP, Retail): Spezialisierung + Talente werden über Zauber-IDs geprüft
function BS:ScanSpecialization()
    local spec = (GetSpecialization and GetSpecialization()) or 0
    spec = spec or 0
    local list, talents = {}, {}

    -- MoP Classic: gewählte Talente (je Reihe eines) für die Anzeige auslesen
    if not self.isRetail and GetTalentInfo then
        local group = (GetActiveSpecGroup and GetActiveSpecGroup()) or 1
        for tier = 1, 6 do
            for col = 1, 3 do
                local ok, a, b, c, d = pcall(GetTalentInfo, tier, col, group)
                if ok and type(a) == "number" and type(b) == "string" and d then
                    tinsert(list, { name = b, icon = c, rank = 1, maxRank = 1, tab = 1, tier = tier, column = col })
                    talents[strlower(b)] = 1
                end
            end
        end
        if #list == 0 then
            -- alte Signatur: GetTalentInfo(index) -> name, icon, tier, column, selected
            for i = 1, 18 do
                local ok, name, icon, tier, col, selected = pcall(GetTalentInfo, i)
                if ok and type(name) == "string" and selected then
                    tinsert(list, { name = name, icon = icon, rank = 1, maxRank = 1, tab = 1, tier = tier, column = col })
                    talents[strlower(name)] = 1
                end
            end
        end
    end

    -- Signatur aus Spezialisierung + allen in den Daten genutzten Talent-Zaubern
    local bits = {}
    local data = self.ClassData[self.class]
    if data then
        for _, d in ipairs(data.entries) do
            for _, field in ipairs({ "talentSpell", "enableIfTalentSpell" }) do
                local v = d[field]
                if type(v) == "number" then v = { v } end
                if type(v) == "table" then
                    for _, id in ipairs(v) do tinsert(bits, BS.KnowsSpellID(id) and "1" or "0") end
                end
            end
        end
    end
    for _, t in ipairs(list) do tinsert(bits, t.name) end

    self.mainSpec = spec
    self.points = { 0, 0, 0 }
    self.talents, self.talentList = talents, list
    self.allTalents, self.talentByName, self.talentByPos = {}, {}, {}
    self.talentsReadable = false   -- keine Talentbäume -> keine Namens-Zuordnung nötig
    self.talentSig = "spec" .. spec .. "|" .. table.concat(bits, ",")
end

function BS:ScanTalents()
    if self.family == "modern" then
        self:ScanSpecialization()
    else
        self:ScanTalentTrees()
    end
end

-- Gibt den (lokalen) Namen des ersten geskillten Talents aus der Liste zurück (oder nil).
-- Englische Namen werden über gelernte Zuordnungen in die Client-Sprache übersetzt.
function BS:HasTalent(list)
    if not list then return nil end
    for _, n in ipairs(list) do
        if self.talents[strlower(n)] then return n end
        local loc = self.LocalTalentName and self:LocalTalentName(n)
        if loc and self.talents[strlower(loc)] then return loc end
    end
    return nil
end

-- Talent über Zauber-ID (MoP/Retail – sprachunabhängig)
function BS:HasTalentSpell(list)
    if not list then return nil end
    if type(list) ~= "table" then list = { list } end
    for _, id in ipairs(list) do
        if BS.KnowsSpellID(id) then return (BS.SpellInfo(id)) or tostring(id) end
    end
    return nil
end

function BS:SpecName(index)
    if not index or index == 0 then return nil end
    if self.family == "modern" and GetSpecializationInfo and not self.testClass then
        local ok, _, name = pcall(GetSpecializationInfo, index)
        if ok and type(name) == "string" then return name end
    end
    local data = self.ClassData[self.class]
    if not data then return nil end
    local names = (self.family == "modern" and data.specNamesModern) or data.specNames
    return names and names[index] or nil
end

function BS:SpecText()
    local name = self:SpecName(self.mainSpec) or "noch keine Spezialisierung"
    if self.family == "modern" then return name end
    local p = self.points
    return string.format("%s (%d/%d/%d)", name, p[1] or 0, p[2] or 0, p[3] or 0)
end

------------------------------------------------------------------------
-- Einträge der Klasse auflösen (Version, Namen, Icons, bekannt, empfohlen)
------------------------------------------------------------------------
-- Gilt ein Eintrag für die laufende WoW-Version?
--   v = "classic" (Standard) | "modern" | "all";  min/max = Erweiterung;  forever / noForever;  retail = true
function BS:EntryAvailable(d)
    local v = d.v or "classic"
    if v ~= "all" and v ~= self.family then return false end
    -- alsoForever: gibt es erst ab Erweiterung "min", in WoW Forever aber schon (z. B. Hot Streak)
    if d.min and self.expansion < d.min and not (d.alsoForever and self.isForever) then return false end
    if d.max and self.expansion > d.max then return false end
    if d.forever and not self.isForever then return false end
    if d.noForever and self.isForever then return false end
    if self.isRetail then
        -- Retail: Buffs und Procs sind im Kampf für Addons unlesbar -> nur Buff-Erinnerungen ausserhalb des Kampfes
        if d.kind ~= "buff" then return false end
        if not d.retail then return false end
    elseif d.retailOnly then
        return false
    end
    return true
end

function BS:ResolveSpell(spell)
    if type(spell) == "table" then
        local firstName, firstIcon
        for _, s in ipairs(spell) do
            local name, icon = self:ResolveSpell(s)
            if name then
                if not firstName then firstName, firstIcon = name, icon end
                if self:IsKnown(name) then return name, icon end
            end
        end
        return firstName, firstIcon
    end
    if type(spell) == "string" and self.LocalSpellName then
        local loc = self:LocalSpellName(spell)
        local name, icon = BS.SpellInfo(loc or spell)
        return name or loc or spell, icon
    end
    local name, icon = BS.SpellInfo(spell)
    if not name and type(spell) == "string" then name = spell end
    return name, icon
end

local function NameOf(spell)
    if type(spell) == "number" then
        local n = BS.SpellInfo(spell)
        return n
    end
    if type(spell) == "string" and BS.LocalSpellName then
        return BS:LocalSpellName(spell) or spell
    end
    return spell
end

function BS:SpecList(specs)
    local t = {}
    for _, s in ipairs(specs) do tinsert(t, self:SpecName(s) or ("Baum " .. s)) end
    return table.concat(t, "/")
end

local function FirstTalentName(d)
    if d.talents then return d.talents[1] end
    local ts = d.talentSpell
    if type(ts) == "table" then ts = ts[1] end
    if ts then return (BS.SpellInfo(ts)) or ("Talent " .. ts) end
    return "?"
end

-- Status-Text, warum ein Eintrag aktiv/inaktiv ist (wird im Optionsfenster angezeigt)
function BS:EntryStatus(e)
    local d, C = e.data, BS.COLORS
    if not e.known then
        if d.forever then return "nicht gelernt (nur WoW Forever)", C.dim end
        return "nicht gelernt", C.dim
    end
    if d.auto then
        local src = (d.auto.src == "net") and ("geteilt von " .. (d.auto.from or "?")) or "automatisch gelernt"
        if d.specs and not e.specOK then
            return src .. " – gedacht für " .. self:SpecList(d.specs) .. ", manuell aktivierbar", C.dim
        end
        return src, C.green
    end
    if d.custom then
        if d.alertOnly then return "eigener Proc – nur Meldung", C.green end
        return "eigener Proc – Klick wirkt " .. (e.spellName or "?"), C.green
    end
    if d.items then
        if e.itemName then return "Gift/Gegenstand: " .. e.itemName, C.green end
        return "kein passender Gegenstand in den Taschen", C.yellow
    end
    if d.talents or d.talentSpell then
        if e.talentMatch then return "Talent geskillt: " .. e.talentMatch, C.green end
        if d.talents then
            local loc = self.ResolveTalentList and self:ResolveTalentList(d.talents)
            if not loc and self.talentsReadable then
                return "Talentname unbekannt: " .. d.talents[1] .. " – unter \"Skillung\" zuordnen", C.yellow
            end
            return "Talent nicht geskillt: " .. (loc or d.talents[1]) .. " – manuell aktivierbar", C.yellow
        end
        return "Talent nicht geskillt: " .. FirstTalentName(d) .. " – manuell aktivierbar", C.yellow
    end
    if e.viaTalent and not e.specOK then return "aktiv durch Talent " .. e.viaTalent, C.green end
    if d.optional then return "optional – manuell aktivierbar", C.dim end
    if d.specs then
        if self.mainSpec == 0 then return "noch keine Spezialisierung – vorläufig aktiv", C.yellow end
        if e.specOK then return "empfohlen für " .. (self:SpecName(self.mainSpec) or "?"), C.green end
        return "gedacht für " .. self:SpecList(d.specs) .. " – manuell aktivierbar", C.dim
    end
    return "für alle Skillungen", C.green
end

-- Gestalten des Druiden: Position in der Gestaltleiste (ändert sich nur, wenn eine Gestalt dazugelernt wird)
local FORM_IDS = { cat = { 768 }, bear = { 5487, 9634 } }
function BS:ShapeshiftIndex(form)
    local ids = FORM_IDS[form]
    if not ids or not GetNumShapeshiftForms or not GetShapeshiftFormInfo then return nil end
    local names = {}
    for _, id in ipairs(ids) do local n = BS.SpellInfo(id); if n then names[n] = true end end
    for i = 1, (GetNumShapeshiftForms() or 0) do
        local r = { GetShapeshiftFormInfo(i) }
        local sid = r[4]
        if type(sid) == "number" then
            for _, id in ipairs(ids) do if sid == id then return i end end
            local n = BS.SpellInfo(sid)
            if n and names[n] then return i end
        end
        -- ältere Clients: zweiter Rückgabewert ist der Name
        if type(r[2]) == "string" and names[r[2]] then return i end
    end
    return nil
end

-- Bestes vorhandenes Item aus einer Liste (z. B. höchster Giftrang in den Taschen)
function BS:BestItem(items)
    for _, id in ipairs(items) do
        if BS.ItemCount(id) > 0 then return id end
    end
    return nil
end

function BS:ResolveEntries()
    wipe(self.entries)
    self.autoCoveredCache = nil
    local data  = self.ClassData[self.class]
    local store = self:EntryStore()

    local list = {}
    if data then
        for _, d in ipairs(data.entries) do
            if self:EntryAvailable(d) then tinsert(list, d) end
        end
    end
    if not self.isRetail and not self.testClass then
        for _, c in ipairs(self.db.custom) do
            local spell = (c.spell and c.spell ~= "") and c.spell or nil
            tinsert(list, {
                key = "custom:" .. c.aura, kind = "proc", custom = c, v = "all",
                spell = spell, procAuras = { c.aura }, iconSpell = c.auraId,
                alertOnly = (spell == nil), label = c.aura,
            })
        end
        -- Automatisch gelernte Procs und Fähigkeiten (AutoLearn.lua)
        if self.AutoEntries then
            for _, d in ipairs(self:AutoEntries()) do tinsert(list, d) end
        end
    end

    for _, d in ipairs(list) do
        local e = { data = d, key = d.key, kind = d.kind }

        -- Skillungsabhängiger Zauber (z. B. Freizauber: Arkan -> Arkane Geschosse, Feuer -> Feuerball)
        local spell = d.spell
        if d.spellBySpec and d.spellBySpec[self.mainSpec] then spell = d.spellBySpec[self.mainSpec] end
        if spell then e.spellName, e.icon = self:ResolveSpell(spell) end
        -- Zauber je nach Gestalt (z. B. Freizauber: Katze -> Schreddern, Bär -> Zermalmen)
        local fs = d.formSpellsBySpec and d.formSpellsBySpec[self.mainSpec]
        if fs and not self.testClass then
            e.formMap = {}
            for _, form in ipairs({ "cat", "bear" }) do
                local idx = fs[form] and self:ShapeshiftIndex(form)
                local n = idx and self:ResolveSpell(fs[form])
                if n and self:IsKnown(n) then e.formMap[idx] = n end
            end
            if not next(e.formMap) then e.formMap = nil end
        end

        if d.items then
            e.itemID = self:BestItem(d.items)
            e.itemName = e.itemID and BS.ItemName(e.itemID) or nil
            e.icon = (e.itemID and BS.ItemIcon(e.itemID)) or BS.ItemIcon(d.items[#d.items]) or d.icon
        end
        if not e.icon and d.iconSpell then local _, ic = BS.SpellInfo(d.iconSpell); e.icon = ic end
        if not e.icon and d.procAuras then local _, ic = BS.SpellInfo(d.procAuras[1]); e.icon = ic end
        e.icon = e.icon or d.icon or "Interface\\Icons\\INV_Misc_QuestionMark"

        if d.kind == "buff" and not d.weapon then
            e.auraNames = {}
            local auraList = d.auras or (type(d.spell) == "table" and d.spell) or { d.spell }
            for _, a in ipairs(auraList) do
                local n = NameOf(a)
                if n then e.auraNames[n] = true end
            end
            if d.groupSpell then
                local gName = NameOf(d.groupSpell)
                if gName then e.auraNames[gName] = true end
                e.groupSpellName = self:ResolveSpell(d.groupSpell)
                e.groupSpellKnown = e.groupSpellName and self:IsKnown(e.groupSpellName) or false
            end
        end

        if d.procAuras then
            e.procAuraNames = {}
            for _, a in ipairs(d.procAuras) do
                local n = NameOf(a)
                if n then e.procAuraNames[n] = true end
            end
        end

        -- Skillungsprüfung
        if d.items then
            e.known = true
        else
            e.known = (d.alertOnly or (e.spellName ~= nil and self:IsKnown(e.spellName))) and true or false
        end
        -- Talente, die nur in WoW Forever existieren (z. B. Bloodthrill, Vanguard), gelten nur dort
        e.enableList = d.enableIfTalent
        if self.isForever and d.enableIfTalentForever then e.enableList = d.enableIfTalentForever end
        e.talentMatch = self:HasTalent(d.talents) or self:HasTalentSpell(d.talentSpell)
        e.viaTalent   = self:HasTalent(e.enableList) or self:HasTalentSpell(d.enableIfTalentSpell)
        e.specOK      = (not d.specs) or self.mainSpec == 0 or BS.Contains(d.specs, self.mainSpec)
        if self.testClass and (d.talents or d.talentSpell) and not e.talentMatch and e.specOK then
            e.talentMatch = FirstTalentName(d)   -- Testmodus: Talent-Procs der gewählten Skillung zeigen
        end

        if d.talents or d.talentSpell then
            e.recommended = e.known and e.talentMatch ~= nil
        else
            e.recommended = e.known and not d.optional and (e.specOK or e.viaTalent ~= nil)
        end

        local s = store[d.key]
        if s and s.enabled ~= nil then
            e.enabled = s.enabled and e.known
            e.manual  = true
        else
            e.enabled = e.recommended
        end
        e.mode  = (s and s.mode) or d.mode or "always"
        -- eigene Klingel für diesen Eintrag (unabhängig von den allgemeinen Tönen)
        if s and s.bell ~= nil then e.bell = s.bell else e.bell = d.bell and true or false end
        -- Procs über einen Buff heissen nach dem Buff (z. B. "Schattentrance"), damit gleiche Zauber unterscheidbar sind
        local procName = d.procAuras and not d.custom and NameOf(d.procAuras[1]) or nil
        if type(procName) ~= "string" then procName = nil end
        e.label = d.label or procName or e.spellName or d.key
        if d.kind == "proc" and d.procAuras and not d.custom and not d.label and procName then
            -- Proc über einen Buff: gross die Quelle (z. B. "SCHATTENTRANCE!"), darunter der Zauber
            e.alertText = BS.Upper(procName) .. "!"
        elseif d.kind == "buff" or d.kind == "proc" then
            e.alertText = d.alert or (BS.Upper(e.label) .. "!")
        end
        -- Zauber, den der Klick auslöst, wenn er anders heisst als die Beschriftung (Zeile unter dem Button)
        if d.kind == "proc" and e.spellName and not d.alertOnly and e.spellName ~= e.label then
            e.actionText = e.spellName
        end
        e.status, e.statusColor = self:EntryStatus(e)
        tinsert(self.entries, e)
    end
end

function BS:CountActive()
    local c = { buff = 0, proc = 0, cd = 0 }
    for _, e in ipairs(self.entries) do
        if e.enabled then c[e.kind] = c[e.kind] + 1 end
    end
    return c
end

------------------------------------------------------------------------
-- Zonen-Logik
------------------------------------------------------------------------
BS.CONTEXT_NAMES = {
    world = "Offene Welt", dungeon = "Dungeon", raid = "Raid", pvp = "Schlachtfeld",
    resting = "Hauptstadt / Gasthaus", sanctuary = "Schutzgebiet", instance = "Instanz",
    dead = "tot", taxi = "Flugroute",
}

function BS:GetContext()
    if UnitIsDeadOrGhost("player") then return false, "dead" end
    if UnitOnTaxi("player") then return false, "taxi" end
    local z = self.db.zones
    local inInstance, itype = IsInInstance()
    if inInstance then
        if itype == "raid" then return z.raid, "raid" end
        if itype == "party" or itype == "scenario" then return z.dungeon, "dungeon" end
        if itype == "pvp" or itype == "arena" then return z.pvp, "pvp" end
        return true, "instance"
    end
    local pvpType
    if C_PvP and C_PvP.GetZonePVPInfo then
        pvpType = C_PvP.GetZonePVPInfo()
    elseif GetZonePVPInfo then
        pvpType = GetZonePVPInfo()
    end
    if pvpType == "sanctuary" then return z.sanctuary, "sanctuary" end
    if IsResting() then return z.resting, "resting" end
    return z.world, "world"
end

------------------------------------------------------------------------
-- Scans / Layout auslösen
------------------------------------------------------------------------
local function SafeCall(func, ...)
    local ok, err = pcall(func, ...)
    if not ok then BS.Print("Fehler: " .. tostring(err)) end
end

function BS:AnnounceSpec()
    local c = self:CountActive()
    if self.isRetail then
        BS.Print(string.format("Spezialisierung erkannt: |cffffffff%s|r – %d Buff-Erinnerungen aktiv (Retail: nur ausserhalb des Kampfes).",
            self:SpecText(), c.buff))
        return
    end
    BS.Print(string.format("Skillung erkannt: |cffffffff%s|r – angepasst: %d Buffs, %d Procs, %d Cooldowns.",
        self:SpecText(), c.buff, c.proc, c.cd))
end

function BS:FullScan()
    -- Testmodus mit fremder Klasse: nicht neu einlesen, nur neu aufbauen
    if self.testClass then
        SafeCall(self.Layout, self)
        return
    end
    local oldSig = self.talentSig
    SafeCall(self.ScanSpellbook, self)
    SafeCall(self.ScanTalents, self)
    if self.LearnFromClient then SafeCall(self.LearnFromClient, self) end
    if self.AutoSpellbookCheck then SafeCall(self.AutoSpellbookCheck, self) end
    SafeCall(self.Layout, self)
    if self.talentSig ~= oldSig and self.talentSig ~= "" and self.mainSpec ~= 0 then
        self:AnnounceSpec()
    end
    if self.optionsFrame and self.optionsFrame:IsShown() then
        SafeCall(self.RefreshOptions, self)
    end
end

function BS:FullScanSoon()
    if self.scanQueued then return end
    self.scanQueued = true
    local function run()
        self.scanQueued = false
        if InCombatLockdown() then
            self.pendingScan = true
        else
            self:FullScan()
        end
    end
    if C_Timer and C_Timer.After then C_Timer.After(0.5, run) else run() end
end

function BS:SettingsChanged()
    if InCombatLockdown() then
        self.pendingLayout = true
        BS.Print("Änderung wird nach dem Kampf übernommen.")
    else
        self:Layout()
    end
    if self.optionsFrame and self.optionsFrame:IsShown() then
        self:RefreshOptions()
    end
end

------------------------------------------------------------------------
-- Events
------------------------------------------------------------------------
local frame = CreateFrame("Frame")
BS.frame = frame
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function(_, event, ...)
    local handler = BS[event]
    if handler then
        local ok, err = pcall(handler, BS, ...)
        if not ok and not BS.errShownEvent then
            BS.errShownEvent = true
            BS.Print("Fehler in " .. event .. ": " .. tostring(err))
        end
    end
end)

local EVENTS = {
    "PLAYER_ENTERING_WORLD", "SPELLS_CHANGED", "LEARNED_SPELL_IN_TAB",
    "CHARACTER_POINTS_CHANGED", "PLAYER_TALENT_UPDATE", "ACTIVE_TALENT_GROUP_CHANGED",
    "PLAYER_SPECIALIZATION_CHANGED", "TRAIT_CONFIG_UPDATED",
    "GROUP_ROSTER_UPDATE", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED",
    "UNIT_AURA", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_INVENTORY_CHANGED", "BAG_UPDATE_DELAYED",
    "CHAT_MSG_ADDON", "CHAT_MSG_CHANNEL_NOTICE",
}

function BS:PLAYER_LOGIN()
    self:InitDB()
    self.class = select(2, UnitClass("player"))
    self.playerGUID = UnitGUID("player")
    for _, ev in ipairs(EVENTS) do pcall(frame.RegisterEvent, frame, ev) end
    -- Kampflog: in Retail (Midnight) für Addons gesperrt
    -- Forever und Retail: Kampflog für Addons gesperrt -> nicht registrieren
    self.hasCombatLog = not self.restricted
    if self.hasCombatLog then pcall(frame.RegisterEvent, frame, "COMBAT_LOG_EVENT_UNFILTERED") end

    BS.Print("geladen für " .. (BS.FLAVOR_NAMES[self.flavor] or self.flavor) ..
        (self.isRetail and " – Retail-Modus: Buff-Erinnerungen ausserhalb des Kampfes." or "."))

    if self.InitNames then self:InitNames() end
    self:CreateDisplay()
    self:CreateMinimapButton()
    self.ready = true
    self:FullScan()
    if not self.ClassData[self.class] then
        BS.Print("Für deine Klasse gibt es noch keine Daten – eigene Procs kannst du über die Aufnahme hinzufügen.")
    end

    local acc, gacc = 0, 0
    frame:SetScript("OnUpdate", function(_, dt)
        acc, gacc = acc + dt, gacc + dt
        if acc >= 0.1 then
            acc = 0
            local ok, err = pcall(BS.Refresh, BS)
            if not ok then BS:CountError("Anzeige", err) end
        end
        if gacc >= 0.5 then
            gacc = 0
            local ok, err = pcall(BS.RefreshGroup, BS)
            if not ok then BS:CountError("Gruppe", err) end
            if BS.PumpComm then pcall(BS.PumpComm, BS) end
        end
    end)
end

-- Fehler zählen statt still abbrechen: erster Fehler pro Bereich im Chat, alle in der Diagnose (/bsen fehler)
function BS:CountError(area, err)
    self.errors = self.errors or { count = 0, byArea = {}, last = nil }
    local E = self.errors
    E.count = E.count + 1
    E.byArea[area] = (E.byArea[area] or 0) + 1
    E.last = area .. ": " .. tostring(err)
    if E.byArea[area] == 1 then BS.Print("Fehler (" .. area .. "): " .. tostring(err)) end
end

function BS:ErrorSummary()
    local E = self.errors
    if not E or E.count == 0 then return "keine Fehler" end
    local parts = {}
    for area, n in pairs(E.byArea) do tinsert(parts, area .. " " .. n .. "x") end
    table.sort(parts)
    return string.format("%d Fehler (%s) – zuletzt: %s", E.count, table.concat(parts, ", "), E.last or "?")
end

function BS:PLAYER_ENTERING_WORLD()         self:FullScanSoon() end
function BS:SPELLS_CHANGED()                self:FullScanSoon() end
function BS:LEARNED_SPELL_IN_TAB()          self:FullScanSoon() end
function BS:CHARACTER_POINTS_CHANGED()      self:FullScanSoon() end
function BS:PLAYER_TALENT_UPDATE()          self:FullScanSoon() end
function BS:ACTIVE_TALENT_GROUP_CHANGED()   self:FullScanSoon() end
function BS:PLAYER_SPECIALIZATION_CHANGED(unit)
    if unit == nil or unit == "player" then self:FullScanSoon() end
end
function BS:TRAIT_CONFIG_UPDATED()          self:FullScanSoon() end

-- Gifte in den Taschen / Waffenwechsel -> Item-Buttons neu zuordnen
function BS:BAG_UPDATE_DELAYED()
    if self.hasItemEntries then
        if InCombatLockdown() then self.pendingLayout = true else self:Layout() end
    end
end
function BS:UNIT_INVENTORY_CHANGED(unit)
    if unit == "player" and self.hasItemEntries and not InCombatLockdown() then self:Layout() end
end

function BS:GROUP_ROSTER_UPDATE()
    if InCombatLockdown() then self.pendingLayout = true else self:Layout() end
    if self.OnGroupChanged then self:OnGroupChanged() end
end

-- Kurz vor der Kampfsperre: alle erlaubten Buttons "scharf" machen
function BS:PLAYER_REGEN_DISABLED()
    -- Kampf beginnt: Testmodus beenden, damit alle Buttons wieder echte Zauber wirken
    if self.testMode then self:StopTestMode() end
    if self:Locked() then
        -- Forever/Retail: im Kampf zeigt BuffSentinel nichts an. Alle Klick-Buttons jetzt (noch erlaubt)
        -- verstecken, damit keine unsichtbaren Buttons im Kampf Klicks abfangen.
        if self.HideAllForCombat then self:HideAllForCombat() end
        self:NoteSecret()
        return
    end
    self:Arm()
end

function BS:PLAYER_REGEN_ENABLED()
    if self.pendingScan then
        self.pendingScan = false
        self:FullScan()
    elseif self.pendingLayout then
        self:Layout()
    end
    if self:Locked() then self:ScanPlayerAuras() end
    self:Refresh()
end

------------------------------------------------------------------------
-- Chat-Befehl (nur als Notlösung, alles geht auch per Maus)
------------------------------------------------------------------------
SLASH_BUFFSENTINEL1 = "/buffsentinel"
SLASH_BUFFSENTINEL2 = "/bsen"
SlashCmdList.BUFFSENTINEL = function(msg)
    msg = strlower(strtrim(msg or ""))
    if msg == "test" then
        BS:ToggleTestMode()
    elseif msg == "fehler" or msg == "errors" or msg == "diag" then
        BS.Print("Diagnose: " .. BS:ErrorSummary() .. " · Sperren (geheime Werte): " ..
            (BS:Locked() and "ja" or "nein") .. " · Kampflog: " .. (BS.hasCombatLog and "ja" or "nein"))
    elseif msg == "anordnen" or msg == "move" or msg == "verschieben" then
        BS:ToggleArrangeMode()
    elseif msg == "spenden" or msg == "donate" or msg == "support" then
        if BS.Donate then BS.Donate.Show() end
    else
        BS:ToggleOptions()
    end
end
