-- BuffSentinel - Sounds.lua
-- Warntöne: Auswahl aus vielen Spieltönen, Glocken, LibSharedMedia und eigenen Dateien.
-- Ein/Aus und Ton pro Warnart – gespeichert pro Charakter (Klasse) und Skillung.
--
-- Gespeichert:
--   db.soundBase[art]               = { on = bool, sound = Schlüssel, custom = Pfad/ID }   Standard für alle Skillungen
--   db.soundSpecs["specN"][art]     = { on = ..., sound = ..., custom = ... }             Abweichung einer Skillung
--   db.soundChannel                 = "Master" | "SFX" | "Dialog" | "Ambience" | "Music"
-- Sound-Schlüssel: Name aus SOUNDKIT (z. B. "RAID_WARNING"), "f:<name>" (Datei aus der Liste unten),
--                  "lsm:<name>" (LibSharedMedia) oder "custom" (eigener Pfad oder FileDataID).

local ADDON, BS = ...

-- Warnarten in der Reihenfolge der Einstellungen
BS.SOUND_KINDS = {
    { key = "horn",       name = "Eigener Buff ausgelaufen (Hupe, wiederholt)", on = true,  sound = "RAID_WARNING" },
    { key = "buff",       name = "Gruppen-Buff fehlt (einmalig)",               on = false, sound = "RAID_WARNING" },
    { key = "proc",       name = "Proc",                                        on = false, sound = "ALARM_CLOCK_WARNING_3" },
    { key = "cooldown",   name = "Cooldown bereit",                             on = false, sound = "IG_MAINMENU_OPTION_CHECKBOX_ON" },
    { key = "dispel",     name = "Debuff zum Reinigen",                         on = false, sound = "IG_PLAYER_INVITE" },
    { key = "dispel_imp", name = "Wichtiger Raid-Debuff",                       on = false, sound = "RAID_WARNING" },
    { key = "bell",       name = "Klingel (Einträge mit \"Ton an\")",           on = true,  sound = "f:shaysbell" },
}
BS.SOUND_KIND_BY_KEY = {}
for _, k in ipairs(BS.SOUND_KINDS) do BS.SOUND_KIND_BY_KEY[k.key] = k end

-- Spieltöne (SOUNDKIT). Was es in einer WoW-Version nicht gibt, wird automatisch ausgeblendet.
-- id = Ersatz, falls ein sehr alter Client kein SOUNDKIT kennt.
local KIT_SOUNDS = {
    -- Warnungen
    { "RAID_WARNING",                   "Raid-Warnung",            8959 },
    { "READY_CHECK",                    "Bereitschaftscheck",      8960 },
    { "RAID_BOSS_EMOTE_WARNING",        "Boss-Emote" },
    { "UI_RAID_BOSS_WHISPER_WARNING",   "Boss-Flüstern" },
    { "PVP_THROUGH_QUEUE",              "Schlachtfeld bereit" },
    { "PVP_ENTER_QUEUE",                "Schlachtfeld-Warteschlange" },
    { "ALARM_CLOCK_WARNING_1",          "Wecker 1" },
    { "ALARM_CLOCK_WARNING_2",          "Wecker 2",                12867 },
    { "ALARM_CLOCK_WARNING_3",          "Wecker 3",                12889 },
    { "MAP_PING",                       "Karten-Ping" },
    { "LFG_ROLE_CHECK",                 "Rollencheck" },
    { "LFG_REWARDS",                    "Dungeon-Belohnung" },
    { "UI_BNET_TOAST",                  "Battle.net-Meldung" },
    { "UI_PROFESSIONS_NEW_RECIPE_LEARNED_TOAST", "Neues Rezept" },
    -- Nachrichten & Gruppe
    { "TELL_MESSAGE",                   "Flüstern",                3081 },
    { "IG_PLAYER_INVITE",               "Einladung",               880 },
    { "FRIEND_JOIN_GAME",               "Freund online" },
    { "U_CHAT_SCROLL_BUTTON",           "Chat-Klick" },
    -- Quests & Belohnungen
    { "IG_QUEST_LIST_COMPLETE",         "Quest abgeschlossen",     878 },
    { "IG_QUEST_LIST_OPEN",             "Questliste auf",          875 },
    { "IG_QUEST_LOG_ABANDON_QUEST",     "Quest abbrechen" },
    { "LEVEL_UP",                       "Stufenaufstieg",          888 },
    { "LEVELUPSOUND",                   "Stufenaufstieg (alt)" },
    { "LOOT_WINDOW_COIN_SOUND",         "Münzen" },
    { "MONEY_FRAME_OPEN",               "Geldbeutel" },
    { "UI_EPICLOOT_TOAST",              "Epische Beute" },
    { "ACHIEVEMENT_MENU_OPEN",          "Erfolge" },
    -- Fenster & Klicks
    { "AUCTION_WINDOW_OPEN",            "Auktionshaus auf",        5274 },
    { "AUCTION_WINDOW_CLOSE",           "Auktionshaus zu" },
    { "IG_MAINMENU_OPEN",               "Menü auf",                850 },
    { "IG_MAINMENU_CLOSE",              "Menü zu",                 851 },
    { "IG_MAINMENU_OPTION_CHECKBOX_ON", "Klick",                   856 },
    { "IG_MAINMENU_OPTION_CHECKBOX_OFF","Klick (aus)",             857 },
    { "IG_CHARACTER_INFO_OPEN",         "Charakterfenster" },
    { "IG_CHARACTER_INFO_TAB",          "Reiter" },
    { "IG_SPELLBOOK_OPEN",              "Zauberbuch" },
    { "IG_ABILITY_PAGE_TURN",           "Seite umblättern" },
    { "IG_BACKPACK_OPEN",               "Rucksack auf" },
    { "IG_BACKPACK_CLOSE",              "Rucksack zu" },
    { "IG_MINIMAP_OPEN",                "Minimap" },
    { "GS_TITLE_OPTION_OK",             "OK" },
    { "GS_LOGIN",                       "Anmelden" },
    { "WRITE_QUEST",                    "Schreiben" },
    { "PUT_DOWN_SMALL_CHAIN",           "Kettenrüstung ablegen" },
    { "PUT_DOWN_GEMS",                  "Edelsteine ablegen" },
    { "PUT_DOWN_WOOD",                  "Holz ablegen" },
    { "PUT_DOWN_RING",                  "Ring ablegen" },
}

-- Sounddateien des Spiels. Spielt eine Datei in einem Client nicht, kommt ersatzweise die Raid-Warnung
-- (beim Testen gibt es dazu einen Hinweis im Chat).
local FILE_SOUNDS = {
    { "shaysbell",   "Handglocke",                 "Sound\\Spells\\ShaysBell.ogg" },
    { "tollhorde",   "Turmglocke Horde",           "Sound\\Doodad\\BellTollHorde.ogg" },
    { "tollally",    "Turmglocke Allianz",         "Sound\\Doodad\\BellTollAlliance.ogg" },
    { "tollelf",     "Turmglocke Nachtelfen",      "Sound\\Doodad\\BellTollNightElf.ogg" },
    { "trollgong",   "Troll-Gong",                 "Sound\\Doodad\\G_GongTroll01.ogg" },
    { "wardrum",     "Kriegstrommel",              "Sound\\Event Sounds\\Event_wardrum_ogre.ogg" },
    { "flagtaken",   "Flagge genommen",            "Sound\\Spells\\PVPFlagTaken.ogg" },
    { "flaghorde",   "Flagge (Horde)",             "Sound\\Spells\\PVPFlagTakenHorde.ogg" },
    { "pvpally",     "PvP-Warnung Allianz",        "Sound\\Interface\\PVPWarningAllianceMono.ogg" },
    { "pvphorde",    "PvP-Warnung Horde",          "Sound\\Interface\\PVPWarningHordeMono.ogg" },
    { "murloc",      "Murloc",                     "Sound\\Creature\\Murloc\\mMurlocAggroOld.ogg" },
    { "simonbad",    "Fehlton",                    "Sound\\Spells\\SimonGame_Visual_BadPress.ogg" },
    { "fizzle",      "Zauber verpufft",            "Sound\\Spells\\Fizzle\\FizzleHolyA.ogg" },
    { "levelup",     "Stufenaufstieg (Datei)",     "Sound\\Spells\\LevelUp.ogg" },
    { "questdone",   "Quest fertig (Datei)",       "Sound\\Interface\\iQuestComplete.ogg" },
    { "uwarn",       "Fehler-Warnung",             "Sound\\Interface\\Error.ogg" },
}

BS.SOUND_CHANNELS = {
    { "Master",   "Gesamt" },
    { "SFX",      "Effekte" },
    { "Dialog",   "Dialog" },
    { "Ambience", "Umgebung" },
    { "Music",    "Musik" },
}

local function LSM()
    if not LibStub then return nil end
    local ok, lib = pcall(LibStub, "LibSharedMedia-3.0", true)
    if ok then return lib end
    return nil
end

-- Liste aller Töne, die es im laufenden Client gibt: { key, name, group }
function BS:SoundList()
    if self.soundListCache then return self.soundListCache end
    local list, byKey = {}, {}
    local hasKit = type(SOUNDKIT) == "table"
    for _, s in ipairs(KIT_SOUNDS) do
        if (hasKit and SOUNDKIT[s[1]]) or (not hasKit and s[3]) then
            local item = { key = s[1], name = s[2], group = "Spiel", kit = s[1], id = s[3] }
            tinsert(list, item); byKey[item.key] = item
        end
    end
    for _, s in ipairs(FILE_SOUNDS) do
        local item = { key = "f:" .. s[1], name = s[2], group = "Datei", file = s[3] }
        tinsert(list, item); byKey[item.key] = item
    end
    local lib = LSM()
    if lib and lib.List then
        local ok, names = pcall(lib.List, lib, "sound")
        if ok and type(names) == "table" then
            for _, n in ipairs(names) do
                if n ~= "None" then
                    local item = { key = "lsm:" .. n, name = n, group = "SharedMedia", lsm = n }
                    tinsert(list, item); byKey[item.key] = item
                end
            end
        end
    end
    local custom = { key = "custom", name = "Eigener Sound …", group = "Eigener" }
    tinsert(list, custom); byKey.custom = custom
    self.soundListCache, self.soundByKey = list, byKey
    return list
end

function BS:SoundName(key, custom)
    self:SoundList()
    if key == "custom" then
        return (custom and custom ~= "") and ("Eigener: " .. tostring(custom)) or "Eigener Sound …"
    end
    local item = self.soundByKey[key]
    if item then return item.name end
    if type(key) == "string" and key:find("^lsm:") then return key:sub(5) .. " (fehlt)" end
    return tostring(key)
end

------------------------------------------------------------------------
-- Einstellungen pro Skillung
------------------------------------------------------------------------
local function SpecKey()
    return "spec" .. tostring(BS.mainSpec or 0)
end

-- Abweichungen der aktuellen Skillung (Testmodus mit fremder Klasse: nur vorübergehend)
function BS:SoundOverrides(create)
    if self.testClass then
        self.testSoundStore = self.testSoundStore or {}
        return self.testSoundStore
    end
    local k = SpecKey()
    local t = self.db.soundSpecs[k]
    if not t and create then t = {}; self.db.soundSpecs[k] = t end
    return t
end

-- on, sound, custom, abweichend (true = eigene Einstellung dieser Skillung)
function BS:SoundSetting(kind)
    local def = self.SOUND_KIND_BY_KEY[kind]
    if not def or not self.db then return false, nil, nil, false end
    local base = self.db.soundBase[kind] or {}
    local o = self:SoundOverrides(false)
    o = o and o[kind]
    local on, sound, custom = base.on, base.sound, base.custom
    if on == nil then on = def.on end
    if sound == nil then sound = def.sound end
    local changed = false
    if o then
        if o.on ~= nil then on = o.on; changed = true end
        if o.sound ~= nil then sound = o.sound; custom = o.custom; changed = true end
    end
    return on and true or false, sound, custom, changed
end

function BS:SetSoundSetting(kind, field, value, custom)
    local o = self:SoundOverrides(true)
    o[kind] = o[kind] or {}
    o[kind][field] = value
    if field == "sound" then o[kind].custom = custom end
    if self.optionsFrame and self.optionsFrame:IsShown() then self:RefreshOptions() end
end

-- Aktuelle Skillung als Standard für alle Skillungen dieses Charakters übernehmen
function BS:SoundApplyToAll()
    for _, k in ipairs(self.SOUND_KINDS) do
        local on, sound, custom = self:SoundSetting(k.key)
        self.db.soundBase[k.key] = { on = on, sound = sound, custom = custom }
    end
    if not self.testClass then wipe(self.db.soundSpecs) end
    BS.Print("Warntöne gelten jetzt für alle Skillungen.")
    if self.optionsFrame and self.optionsFrame:IsShown() then self:RefreshOptions() end
end

function BS:SoundResetSpec()
    local o = self:SoundOverrides(false)
    if o then wipe(o) end
    if self.optionsFrame and self.optionsFrame:IsShown() then self:RefreshOptions() end
end

function BS:SoundResetAll()
    wipe(self.db.soundBase)
    wipe(self.db.soundSpecs)
    self.testSoundStore = nil
    if self.optionsFrame and self.optionsFrame:IsShown() then self:RefreshOptions() end
end

-- Alte Einstellungen (bis 0.8.6) übernehmen: ein/aus je Art, Hupe ein/aus
function BS:MigrateSounds()
    local db = self.db
    db.soundBase = db.soundBase or {}
    db.soundSpecs = db.soundSpecs or {}
    if db.soundV3 then return end
    local old = db.sound or {}
    for _, k in ipairs({ "buff", "proc", "cooldown", "dispel" }) do
        if old[k] ~= nil then db.soundBase[k] = { on = old[k] and true or false } end
    end
    if old.dispel ~= nil then db.soundBase.dispel_imp = { on = old.dispel and true or false } end
    if db.hornSelfBuff == false then db.soundBase.horn = { on = false } end
    db.soundV3 = true
end

------------------------------------------------------------------------
-- Abspielen
------------------------------------------------------------------------
local function Fallback(ch)
    pcall(PlaySound, (SOUNDKIT and SOUNDKIT.RAID_WARNING) or 8959, ch)
end

-- true = der gewählte Ton wurde gespielt, false = Ersatzton
function BS:PlaySoundChoice(key, custom)
    local ch = (self.db and self.db.soundChannel) or "Master"
    self:SoundList()
    if key == "custom" then
        local v = custom and (tonumber(custom) or custom)
        if v and v ~= "" and PlaySoundFile then
            local ok, will = pcall(PlaySoundFile, v, ch)
            if ok and will ~= false then return true end
        end
        Fallback(ch); return false
    end
    local item = self.soundByKey[key]
    if item and item.lsm then
        local lib = LSM()
        local ok, path = false, nil
        if lib then ok, path = pcall(lib.Fetch, lib, "sound", item.lsm, true) end
        if ok and path and PlaySoundFile then
            local ok2, will = pcall(PlaySoundFile, path, ch)
            if ok2 and will ~= false then return true end
        end
        Fallback(ch); return false
    end
    if item and item.file then
        if PlaySoundFile then
            local ok, will = pcall(PlaySoundFile, item.file, ch)
            if ok and will ~= false then return true end
        end
        Fallback(ch); return false
    end
    if item and item.kit then
        local id = (type(SOUNDKIT) == "table" and SOUNDKIT[item.kit]) or item.id
        if id then
            local ok, will = pcall(PlaySound, id, ch)
            if ok and will ~= false then return true end
        end
    end
    Fallback(ch)
    return false
end

-- Vorhören in den Einstellungen (mit Hinweis, wenn es den Ton im Client nicht gibt)
function BS:PreviewSound(key, custom)
    if not self:PlaySoundChoice(key, custom) then
        BS.Print("Diesen Ton gibt es in deiner WoW-Version nicht – stattdessen erklingt die Raid-Warnung.")
    end
end
