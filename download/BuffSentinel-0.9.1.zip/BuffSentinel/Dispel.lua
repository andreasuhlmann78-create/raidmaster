-- BuffSentinel - Dispel.lua
-- 1. Mitspieler reinigen: Reinigungsleiste mit einem Button pro Gruppenmitglied.
--    Blizzard erlaubt im Kampf keinen Wechsel von Ziel oder Zauber eines Buttons. Darum hat jeder
--    Button bis zu drei Reinigungszauber fest hinterlegt: Linksklick, Rechtsklick, Mittelklick –
--    der Button zeigt an, welche Maustaste für den aktuellen Debuff die richtige ist.
-- 2. Gegner entzaubern: Proc-Button, sobald dein Ziel einen Buff hat, den du entfernen kannst
--    (Reinigen, Magiebannung, Zauberraub, Einlullender Schuss, Besänftigen, Tückische Klinge).
--    Zielt immer auf dein aktuelles Ziel und funktioniert deshalb auch im Kampf ohne Einschränkung.
-- Retail (Midnight): Debuffs sind im Kampf für Addons gesperrt -> dort nicht verfügbar.

local ADDON, BS = ...

local CELL     = 34
local GAP      = 4
local THROTTLE = 0.2

local TYPE_NAMES = { Magic = "Magie", Curse = "Fluch", Poison = "Gift", Disease = "Krankheit" }
local TYPE_COLORS = {
    Magic   = { 0.20, 0.60, 1.00 },
    Curse   = { 0.60, 0.00, 1.00 },
    Poison  = { 0.00, 0.60, 0.00 },
    Disease = { 0.60, 0.40, 0.00 },
}
local MOUSE = { "Linksklick", "Rechtsklick", "Mittelklick" }
local MOUSE_SHORT = { "L", "R", "M" }

------------------------------------------------------------------------
-- Reinigungszauber für Mitspieler je Klasse und Version
--   types = entfernbare Debuff-Arten;  magicSpecs = Magie zusätzlich in diesen Skillungen
------------------------------------------------------------------------
local FRIENDLY = {
    MAGE = {
        { spell = 475, types = { "Curse" } },
    },
    DRUID = {
        { spell = 2782, types = { "Curse" }, max = 3 },
        { spell = { 2893, 8946 }, types = { "Poison" }, max = 3 },
        { spell = 2782, types = { "Curse", "Poison" }, min = 4, max = 4, magicSpecs = { 3 } },
        { spell = 88423, types = { "Magic", "Curse", "Poison" }, min = 5, specs = { 4 } },
        { spell = 2782, types = { "Curse", "Poison" }, min = 5 },
    },
    PRIEST = {
        { spell = 527, types = { "Magic" }, max = 4 },
        { spell = { 552, 528 }, types = { "Disease" }, max = 4 },
        { spell = 527, types = { "Magic", "Disease" }, min = 5, specs = { 1, 2 } },
    },
    PALADIN = {
        { spell = 4987, types = { "Magic", "Poison", "Disease" }, max = 3 },
        { spell = 1152, types = { "Poison", "Disease" }, max = 3 },
        { spell = 4987, types = { "Poison", "Disease" }, min = 4, magicSpecs = { 1 } },
    },
    SHAMAN = {
        { spell = 526,  types = { "Poison" }, max = 2 },
        { spell = 2870, types = { "Disease" }, max = 2 },
        { spell = 51886, types = { "Poison", "Disease", "Curse" }, min = 3, max = 3 },
        { spell = 526,  types = { "Poison", "Disease" }, min = 3, max = 3 },
        { spell = 51886, types = { "Curse" }, min = 4, max = 4, magicSpecs = { 3 } },
        { spell = 77130, types = { "Magic", "Curse" }, min = 5, specs = { 3 } },
        { spell = 51886, types = { "Curse" }, min = 5 },
    },
    MONK = {
        { spell = 115450, types = { "Poison", "Disease" }, min = 5, magicSpecs = { 2 } },
    },
}

-- Wichtige Raid-Debuffs (leuchten auf, eigener Warnton) – Classic-IDs
local IMPORTANT = {
    [19703] = true,  -- Lucifrons Fluch
    [19716] = true,  -- Gehennas' Fluch
    [19713] = true,  -- Shazzrahs Fluch
    [19659] = true,  -- Mana entzünden (Lucifron/Golemagg)
    [19702] = true,  -- Drohende Verdammnis (Lucifron)
    [26180] = true,  -- Stich des Flügeldrachen (Huhuran)
    [26053] = true,  -- Giftige Säure
    [23153] = true,  -- Brut-Gebrechen: Blau (Chromaggus)
    [22687] = true,  -- Schattenflamme-Fluch
}

-- Nicht reinigen (Rückschlag für den Reiniger o. ä.)
local AVOID = {
    [30108] = true, [30404] = true, [30405] = true, [47841] = true, [47843] = true,  -- Instabiles Gebrechen
    [34914] = true, [34916] = true, [34917] = true, [48159] = true, [48160] = true,  -- Vampirberührung
    [28169] = true,  -- Mutierende Injektion (Grobbulus)
}

------------------------------------------------------------------------
-- Gegner entzaubern: als Proc-Einträge in die Klassendaten einhängen
------------------------------------------------------------------------
local ENRAGE_IDS = {
    [19451] = true, [23342] = true, [23128] = true, [26051] = true, [28371] = true,
    [19812] = true, [8269] = true, [12795] = true, [15716] = true,
}
local ENRAGE_WORDS = { "frenzy", "raserei", "enrage", "wutanfall", "wütend" }

local ENEMY = {
    SHAMAN  = { { key = "purge", spell = 370, types = { Magic = true }, v = "all" } },
    PRIEST  = { { key = "dispelmagic", spell = 527, types = { Magic = true } },
                { key = "m_dispelmagic", spell = 528, types = { Magic = true }, v = "modern" } },
    MAGE    = { { key = "spellsteal", spell = 30449, types = { stealable = true }, min = 2, v = "all" } },
    HUNTER  = { { key = "tranq", spell = 19801, types = { Enrage = true }, v = "all" },
                { key = "tranq_m", spell = 19801, types = { Magic = true }, min = 2, v = "all", optional = true,
                  label = "Einlullender Schuss (Magie)" } },
    DRUID   = { { key = "soothe", spell = 2908, types = { Enrage = true }, min = 4, v = "all" } },
    ROGUE   = { { key = "shiv", spell = 5938, types = { Enrage = true }, min = 5, v = "modern" } },
}

do
    for class, list in pairs(ENEMY) do
        local data = BS.ClassData[class]
        if data then
            for _, x in ipairs(list) do
                tinsert(data.entries, {
                    key = "ed_" .. x.key, kind = "proc", spell = x.spell, v = x.v, min = x.min, max = x.max,
                    enemyDispel = x.types, optional = x.optional, label = x.label,
                    alert = "ENTZAUBERN!",
                })
            end
        end
    end
end

------------------------------------------------------------------------
-- Auren lesen
------------------------------------------------------------------------
local function ForEachAura(unit, filter, fn)
    for i = 1, 40 do
        local name, icon, dtype, spellId, stealable
        if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
            local a = C_UnitAuras.GetAuraDataByIndex(unit, i, filter)
            if not a then break end
            name, icon, dtype, spellId, stealable = a.name, a.icon, a.dispelName, a.spellId, a.isStealable
        elseif not UnitDebuff or not UnitBuff then
            return
        elseif filter == "HARMFUL" then
            local n, ic, _, dt, _, _, _, _, _, sid = UnitDebuff(unit, i)
            if not n then break end
            name, icon, dtype, spellId = n, ic, dt, sid
        else
            local n, ic, _, dt, _, _, _, st, _, sid = UnitBuff(unit, i)
            if not n then break end
            name, icon, dtype, spellId, stealable = n, ic, dt, sid, st
        end
        if name and not BS.IsSecret(name) then
            -- geheime Werte nicht als Tabellenschlüssel oder in strlower verwenden
            if BS.IsSecret(dtype) then dtype = nil end
            if BS.IsSecret(spellId) then spellId = nil end
            if BS.IsSecret(stealable) then stealable = nil end
            if fn(name, icon, dtype, spellId, stealable) then return end
        end
    end
end

local function IsEnrage(name, dtype, spellId)
    if dtype == "Enrage" then return true end
    if dtype and dtype ~= "" then return false end
    if spellId and ENRAGE_IDS[spellId] then return true end
    local low = strlower(name or "")
    for _, w in ipairs(ENRAGE_WORDS) do
        if low:find(w, 1, true) then return true end
    end
    return false
end

-- Für Display.EvalProc: Name des ersten entfernbaren Buffs auf dem Ziel + Anzahl
function BS:FindEnemyDispel(types)
    if not UnitExists("target") or not UnitCanAttack("player", "target") or UnitIsDead("target") then return nil end
    local first, count = nil, 0
    ForEachAura("target", "HELPFUL", function(name, _, dtype, spellId, stealable)
        local ok = (types.Magic and dtype == "Magic")
                or (types.stealable and stealable)
                or (types.Enrage and IsEnrage(name, dtype, spellId))
        if ok then
            count = count + 1
            first = first or name
        end
    end)
    return first, count
end

------------------------------------------------------------------------
-- Reinigungszauber der aktuellen Skillung ermitteln
------------------------------------------------------------------------
function BS:ResolveDispelSpells()
    local res = { types = {}, spells = {}, slotOf = {} }
    local list = FRIENDLY[self.class]
    if not list or self:Locked() then return res end
    for _, d in ipairs(list) do
        local ok = (not d.min or self.expansion >= d.min) and (not d.max or self.expansion <= d.max)
        if ok and d.specs then ok = self.mainSpec == 0 or BS.Contains(d.specs, self.mainSpec) end
        if ok then
            local name = self:ResolveSpell(d.spell)
            if name and self:IsKnown(name) then
                local types = {}
                for _, t in ipairs(d.types) do types[#types + 1] = t end
                if d.magicSpecs and BS.Contains(d.magicSpecs, self.mainSpec) then types[#types + 1] = "Magic" end
                for _, t in ipairs(types) do
                    if not res.types[t] then
                        if not res.slotOf[name] and #res.spells < 3 then
                            tinsert(res.spells, name)
                            res.slotOf[name] = #res.spells
                        end
                        if res.slotOf[name] then res.types[t] = name end
                    end
                end
            end
        end
    end
    return res
end

------------------------------------------------------------------------
-- Reinigungsleiste
------------------------------------------------------------------------
local function UseKeyDown()
    return GetCVar and GetCVar("ActionButtonUseKeyDown") ~= nil
end

local function CreateCell(i)
    local parent = BS.anchors.dispel
    local c = CreateFrame("Button", "BuffSentinelDispel" .. i, parent, "SecureActionButtonTemplate")
    c:SetSize(CELL, CELL)
    c:SetFrameStrata("MEDIUM")
    if UseKeyDown() then c:RegisterForClicks("AnyUp", "AnyDown") else c:RegisterForClicks("AnyUp") end

    c.border = c:CreateTexture(nil, "BACKGROUND")
    c.border:SetPoint("TOPLEFT", -2, 2)
    c.border:SetPoint("BOTTOMRIGHT", 2, -2)
    c.border:SetColorTexture(0, 0, 0, 0.9)
    c.icon = c:CreateTexture(nil, "ARTWORK")
    c.icon:SetAllPoints()
    c.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    local hl = c:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.2)

    c.glow = c:CreateTexture(nil, "OVERLAY")
    c.glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    c.glow:SetBlendMode("ADD")
    c.glow:SetPoint("CENTER")
    c.glow:SetSize(CELL * 1.9, CELL * 1.9)
    c.glow:SetVertexColor(1, 0.2, 0.2)
    c.glow:Hide()

    local overlay = CreateFrame("Frame", nil, c)
    overlay:SetAllPoints()
    overlay:SetFrameLevel(c:GetFrameLevel() + 5)
    c.name = overlay:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    c.name:SetPoint("BOTTOM", c, "TOP", 0, 3)
    c.name:SetWidth(CELL + 20)
    c.hint = overlay:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    c.hint:SetPoint("BOTTOMRIGHT", -1, 2)
    local font = c.hint:GetFont()
    if font then c.hint:SetFont(font, 12, "OUTLINE") end

    -- Ziehen verschiebt die ganze Reinigungsleiste (Testmodus oder Shift)
    c:RegisterForDrag("LeftButton")
    c:SetScript("OnDragStart", function(self)
        if InCombatLockdown() or not (BS.testMode or IsShiftKeyDown()) then return end
        self.dragging = true
        self:GetParent():StartMoving()
    end)
    c:SetScript("OnDragStop", function(self)
        if not self.dragging then return end
        self.dragging = false
        local f = self:GetParent()
        f:StopMovingOrSizing()
        local p1, _, p2, x, y = f:GetPoint()
        BS.db.pos.dispel = { p1, p2, x, y }
    end)

    c:SetScript("OnEnter", function(self)
        if not self.unit then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(UnitName(self.unit) or "?", 1, 0.82, 0)
        if BS.testMode then
            GameTooltip:AddLine("Testmodus – ziehen verschiebt die Reinigungsleiste", 0.4, 0.9, 0.5)
            GameTooltip:Show()
            return
        end
        if self.debuffName then
            GameTooltip:AddLine(self.debuffName .. " (" .. (TYPE_NAMES[self.debuffType] or "?") .. ")", 1, 1, 1)
        end
        local r = BS.dispelSpells
        if r then
            for slot, spell in ipairs(r.spells) do
                GameTooltip:AddLine(MOUSE[slot] .. ": " .. spell, 0.8, 0.8, 0.8)
            end
        end
        GameTooltip:Show()
    end)
    c:SetScript("OnLeave", function() GameTooltip:Hide() end)
    c:Hide()
    return c
end

function BS:GetDispelCell(i)
    self.dispelCells = self.dispelCells or {}
    if not self.dispelCells[i] then self.dispelCells[i] = CreateCell(i) end
    return self.dispelCells[i]
end

-- Nur ausserhalb des Kampfes: Buttons den Gruppenmitgliedern zuordnen
function BS:LayoutDispel()
    if InCombatLockdown() or not self.anchors or not self.anchors.dispel then return end
    self.dispelSpells = self:ResolveDispelSpells()
    local r = self.dispelSpells
    for _, c in ipairs(self.dispelCells or {}) do
        c.unit = nil
        c.wasActive = false
        c:Hide()
    end
    self.dispelActive = self.db.dispel.friendly and #r.spells > 0 and not self:Locked()
    if not self.dispelActive then return end

    local units, inRaid = self:GetGroupUnits()
    -- Testmodus allein unterwegs: 5 Beispiel-Plätze, damit alle Debuff-Arten (L/R/M) sichtbar werden
    if self.testMode and #units < 5 then
        local padded = {}
        for i = 1, 5 do padded[i] = units[i] or "player" end
        units = padded
    end
    local perRow = {}
    local maxCol, maxRow = 1, 1
    for i, u in ipairs(units) do
        local row = 1
        if inRaid and GetRaidRosterInfo then
            local _, _, sg = GetRaidRosterInfo(i)
            row = sg or 1
        end
        perRow[row] = (perRow[row] or 0) + 1
        local col = perRow[row]
        local c = self:GetDispelCell(i)
        c.unit = u
        c:SetAttribute("unit", u)
        for slot = 1, 3 do
            local spell = (not self.testMode) and r.spells[slot] or nil   -- Testmodus: Klicks wirken nichts
            c:SetAttribute("type" .. slot, spell and "spell" or nil)
            c:SetAttribute("spell" .. slot, spell)
        end
        c:ClearAllPoints()
        -- Innenabstand, damit Symbol, Rahmen und Name sicher innerhalb der Fläche liegen
        c:SetPoint("TOPLEFT", self.anchors.dispel, "TOPLEFT", 14 + (col - 1) * (CELL + 24 + GAP), -22 - (row - 1) * (CELL + 18 + GAP))
        maxCol, maxRow = math.max(maxCol, col), math.max(maxRow, row)
    end
    -- Fläche an die Anzahl der Plätze anpassen
    self.anchors.dispel:SetSize(math.max(300, 28 + maxCol * (CELL + 24 + GAP)), math.max(80, 30 + maxRow * (CELL + 18 + GAP)))
end

function BS:ArmDispel(ctxOK)
    if InCombatLockdown() or not self.dispelActive then return end
    for _, c in ipairs(self.dispelCells or {}) do
        if c.unit and ctxOK then
            if not c:IsShown() then c:SetAlpha(0) end
            c:Show()
        end
    end
end

-- über die gemeinsame Sound-Drosselung (Display.lua): nicht zu schnell hintereinander
local function PlayDispelSound(important)
    if BS.PlayAlert then BS.PlayAlert(important and "dispel_imp" or "dispel") end
end

local lastDispel = 0
function BS:RefreshDispel(now, ctxOK, lockdown, preview, test)
    if not self.dispelActive or not self.dispelCells then return end
    if now - lastDispel < THROTTLE then return end
    lastDispel = now
    local r = self.dispelSpells
    local anySound, anyImportant = false, false

    -- Testmodus: Beispiel-Debuffs aller Arten, die du entfernen kannst
    local demoTypes = {}
    if test then
        for t in pairs(r.types) do demoTypes[#demoTypes + 1] = t end
        table.sort(demoTypes)
    end

    for idx, c in ipairs(self.dispelCells) do
        if c.unit then
            local u = c.unit
            local show, best, bestImp = false, nil, false
            if test and #demoTypes > 0 then
                show = true
                local t = demoTypes[(idx - 1) % #demoTypes + 1]
                best = { name = "Beispiel: " .. (TYPE_NAMES[t] or t), icon = "Interface\\Icons\\Spell_Shadow_CurseOfTounges", dtype = t }
                bestImp = (idx == 1)
            elseif preview then
                show = true
            elseif ctxOK and UnitExists(u) and not UnitIsDeadOrGhost(u) and UnitIsConnected(u) then
                ForEachAura(u, "HARMFUL", function(name, icon, dtype, spellId)
                    if dtype and r.types[dtype] and not (spellId and AVOID[spellId]) then
                        local imp = spellId and IMPORTANT[spellId] or false
                        if not best or (imp and not bestImp) then
                            best = { name = name, icon = icon, dtype = dtype }
                            bestImp = imp
                        end
                        return imp   -- wichtiger Debuff gefunden -> fertig
                    end
                end)
                show = best ~= nil
            end

            if best then
                local spell = r.types[best.dtype]
                local slot = r.slotOf[spell] or 1
                c.debuffName, c.debuffType = best.name, best.dtype
                c.icon:SetTexture(best.icon)
                local col = TYPE_COLORS[best.dtype] or { 1, 0, 0 }
                c.border:SetColorTexture(col[1], col[2], col[3], 1)
                c.hint:SetText(#r.spells > 1 and MOUSE_SHORT[slot] or "")
                local inRange = BS.InRange(spell, u)
                c.icon:SetDesaturated(inRange == false)
                if bestImp then c.glow:Show() else c.glow:Hide() end
            elseif preview then
                c.icon:SetTexture("Interface\\Icons\\Spell_Holy_RemoveCurse")
                c.border:SetColorTexture(0, 0, 0, 0.9)
                c.hint:SetText("")
                c.glow:Hide()
            else
                c.debuffName, c.debuffType = nil, nil
                c.glow:Hide()
            end

            local info = UnitExists(u) and select(2, UnitClass(u))
            local color = info and RAID_CLASS_COLORS and RAID_CLASS_COLORS[info]
            if test and idx > 1 then
                local demo = { "Thrall", "Jaina", "Zuljin", "Sylvanas" }
                c.name:SetText(demo[(idx - 2) % #demo + 1])
                c.name:SetTextColor(0.8, 0.8, 0.8)
            else
                c.name:SetText(UnitName(u) or "")
                if color then c.name:SetTextColor(color.r, color.g, color.b) else c.name:SetTextColor(1, 1, 1) end
            end

            if show and not c.wasActive and not preview then
                anySound = true
                anyImportant = anyImportant or bestImp
            end
            c.wasActive = show and not preview

            if lockdown then
                c:SetAlpha(show and 1 or 0)
            elseif show then
                c:SetAlpha((preview and not test) and 0.7 or 1)
                c:Show()
            else
                c:Hide()
            end
        end
    end
    if anySound then PlayDispelSound(anyImportant) end
end

-- Für das Optionsfenster: Übersicht der Maustasten
function BS:DispelSummary()
    local r = self.dispelSpells or self:ResolveDispelSpells()
    local lines = {}
    for slot, spell in ipairs(r.spells) do
        local types = {}
        for t, s in pairs(r.types) do
            if s == spell then types[#types + 1] = TYPE_NAMES[t] or t end
        end
        table.sort(types)
        lines[#lines + 1] = string.format("%s: %s  –  %s", MOUSE[slot], spell, table.concat(types, ", "))
    end
    return lines
end
