local _, ns = ...

-- Prices for the gold ranking. Every value comes through the price broker (PriceSource.lua): AHSentinel first,
-- then auxForever, Auctionator, Auctioneer, TSM, otherwise own calculation by the rule book
-- (raidmaster shared/wissen/wirtschaft-forever.md).
--   Value to calculate with: the cheapest offer of the last scan (rule book section 3), not the median.
--   Reagents:  the cheapest way – AH, vendor, or crafting from a known recipe (≤ 2 levels)
--   Product:   net sale (5 % cut and expected deposit loss off, at least the vendor value) × items per craft;
--              the value of a craft is the better of selling and disenchanting ("best way")
--   Disenchanting: AHSentinel's value (API), otherwise expected materials × their net value (stack sale)
-- ns.Items[id] = { name, quality, vendorSell, vendorBuyPerPiece (0 = no vendor), farmable }

local P = {}
ns.Prices = P

-- Auction house cut: 5 % of the sale price is kept by the auction house (neutral AH 15 %: PriceSource.CutPct)
P.AH_CUT = 0.05

-- WoW Forever (rule book section 1, measured 9 Nov.): 5 % of the sale price when sold; the deposit
-- (vendor price × quantity × 5 % per 2 h) comes back on a sale and is lost when the auction runs out – expected
-- cost deposit × (1 − p) / p. The old rule "max(5 %, 1s) per auction, never refunded" was wrong and is gone.
-- Other game versions (Era, TBC, Retail): 5 % cut on the sale, the deposit comes back (unchanged).
function P.FeeApplies()
    return ns.IsForever == true
end

function P.StackSize(itemID)
    -- old global first (exactly as before), C_Item.GetItemInfo in the modern client
    local ok, _, _, _, _, _, _, _, stack = pcall(ns.ItemInfo, itemID)
    if ok and type(stack) == "number" and stack > 0 then return stack end
    return 1
end

-- AH share of a sale of this total (copper): 5 % (neutral 15 %), rounded like AHSentinel. No minimum.
function P.AuctionFee(price)
    return ns.PriceSource.Cut(price)
end
P.OwnAuctionFee = P.AuctionFee

---------------------------------------------------------------------------
-- Pass memo (performance, diagnostic log 0.9.22: AD.Update 39 ms, UI:Refresh 101 ms in the game).
-- One update (AD.Update, UI:Refresh) evaluates a recipe up to three times (levelling, gold, disenchanting) and
-- asks AHSentinel for the same market values again and again. Inside one pass every AH value, recipe price and
-- bag count is computed once; the memo is thrown away when the pass ends (nothing goes stale).
---------------------------------------------------------------------------
local pass
function P.BeginPass()
    if pass then pass.depth = pass.depth + 1 else pass = { depth = 1, ah = {}, rec = {}, cnt = {}, hits = 0 } end
end
function P.EndPass()
    if not pass then return end
    pass.depth = pass.depth - 1
    if pass.depth <= 0 then P.lastPassHits = pass.hits; pass = nil end
end
function P.Pass() return pass end
-- runs fn inside a pass; the pass always ends, also on a Lua error (which is passed on)
function P.InPass(fn, ...)
    -- already inside a pass (the portioned rebuild begins one per portion): same memo, no extra pcall
    -- (a portioned rebuild may hand over to the next frame inside fn; Lua 5.1 cannot do that across a pcall)
    if pass then return fn(...) end
    P.BeginPass()
    local res = { pcall(fn, ...) }
    P.EndPass()
    if not res[1] then error(res[2], 0) end
    return unpack(res, 2)
end

---------------------------------------------------------------------------
-- Auction house value (copper) and which addon delivered it
---------------------------------------------------------------------------
local AHRaw
function P.AH(itemID)
    if ns.Sim and ns.Sim.prices then
        local v = ns.Sim.prices[itemID]
        if v then return v, "Test" end
    end
    if pass and itemID then
        local c = pass.ah[itemID]
        if c then pass.hits = pass.hits + 1; return c[1], c[2], c[3] end
        local v, src, kind = AHRaw(itemID)
        pass.ah[itemID] = { v, src, kind }
        return v, src, kind
    end
    return AHRaw(itemID)
end

-- the value to calculate with (cheapest offer of the last scan) from the first source that knows the item
AHRaw = function(itemID)
    local v, src, kind = ns.PriceSource.Price(itemID)
    if v then return v, src, kind end
    return nil
end

-- label of the price source ("AHSentinel", "auxForever", "Auctionator", "Auctioneer", "TSM"); nil = own only
function P.SourceName()
    if ns.Sim and ns.Sim.prices then return "Test" end
    return ns.PriceSource.SourceName()
end

-- Vendor price: first what AHSentinel really saw at a vendor (current, exact for WoW Forever), then the data pack
function P.VendorBuy(itemID)
    local A = _G.AHAnalyzerPro
    if A and A.GetVendorBuyPrice then
        local ok, v = pcall(A.GetVendorBuyPrice, A, itemID)
        if not ok then ns.CountError("AHSentinel:GetVendorBuyPrice", v) end
        if ok and type(v) == "number" and v > 0 then return v end
    end
    local d = ns.Items[itemID]
    if d and d[4] and d[4] > 0 then return d[4] end
    return nil
end

-- Price to BUY a reagent in the AH: the value to calculate with (cheapest offer of the last scan, else the market
-- value). Returns copper, "current" (last scan) | "market".
P.DE_SAFE_COUNT, P.DE_SAFETY = 10, 0.10
function P.BuyAH(itemID)
    local v, _, kind = P.AH(itemID)
    if not v then return nil end
    return v, (kind == "scan") and "current" or "market"
end

function P.VendorSell(itemID)
    local d = ns.Items[itemID]
    local v = d and d[3]
    if not v or v == 0 then
        local ok, _, _, _, _, _, _, _, _, _, _, sell = pcall(ns.ItemInfo, itemID)
        if ok and type(sell) == "number" and sell > 0 then v = sell end
    end
    return v and v > 0 and v or nil
end

function P.IsFarmable(itemID)
    local d = ns.Items[itemID]
    return d and d[5] == 1 or false
end

---------------------------------------------------------------------------
-- Cost of one reagent over the cheapest way: (copper per piece, origin "vendor" | "ah" | "farm" | "craft", known,
-- priceSrc "current"/"market", via = { itemIDs it is made of } for "craft")
---------------------------------------------------------------------------
function P.ReagentUnit(itemID)
    local unit, way, known, kind, via, recipe = ns.PriceSource.MaterialUnit(itemID)
    local farm = P.IsFarmable(itemID)
    if not unit then return 0, farm and "farm" or "ah", false end
    local origin = way
    if way == "ah" and farm then origin = "farm" end
    local priceSrc
    if way == "ah" then priceSrc = (kind == "scan" or kind == "current") and "current" or "market" end
    return unit, origin, known, priceSrc, via, recipe
end

-- what to buy for n pieces of a reagent: a reagent made cheaper by yourself ("craft") is broken down into the
-- materials of its recipe (like AHSentinel Cr:ExpandNeed) – the shopping lists buy linen cloth, not the bolt.
-- Returns a list of { id, count, origin, unit, known }
function P.ExpandNeed(itemID, n, out, depth)
    out, depth = out or {}, depth or 0
    local unit, origin, known, _, _, recipe = P.ReagentUnit(itemID)
    if origin == "craft" and recipe and depth < 3 then
        local made = ((recipe.outMin or 1) + (recipe.outMax or recipe.outMin or 1)) / 2
        local crafts = math.ceil(n / math.max(made, 1) - 1e-9)
        for i = 1, #(recipe.reagents or {}), 2 do
            P.ExpandNeed(recipe.reagents[i], crafts * (recipe.reagents[i + 1] or 1), out, depth + 1)
        end
        return out
    end
    for _, e in ipairs(out) do
        if e.id == itemID then e.count = e.count + n; return out end
    end
    out[#out + 1] = { id = itemID, count = n, origin = origin, unit = unit, known = known }
    return out
end

-- Full calculation for a recipe. Returns a table:
--   cost, value, net (per craft, copper), known (all prices found), parts = { {id, count, unit, origin, known} },
--   origins = { vendor = true, ah = true, farm = true }, valueSource "ah" | "vendor" | nil
local RecipeRaw
function P.Recipe(r, withDE)
    if pass and r then
        local k = withDE and 2 or 1
        local c = pass.rec[r]
        if c and c[k] then pass.hits = pass.hits + 1; return c[k] end
        local res = RecipeRaw(r, withDE)
        pass.rec[r] = c or {}
        pass.rec[r][k] = res
        return res
    end
    return RecipeRaw(r, withDE)
end

RecipeRaw = function(r, withDE)
    local PS = ns.PriceSource
    local res = { cost = 0, value = 0, known = true, parts = {}, origins = {} }
    for i = 1, #(r.reagents or {}), 2 do
        local id, n = r.reagents[i], r.reagents[i + 1]
        local unit, origin, known, priceSrc, via = P.ReagentUnit(id)
        res.parts[#res.parts + 1] = { id = id, count = n, unit = unit, origin = origin, known = known,
            priceSrc = priceSrc, via = via }
        res.origins[origin] = true
        res.cost = res.cost + unit * n
        if not known then res.known = false end
    end
    if r.out then
        local count = ((r.outMin or 1) + (r.outMax or r.outMin or 1)) / 2
        -- selling: net per piece (5 % cut and expected deposit loss already off, at least the vendor value) –
        -- NetSale is net: no second fee here
        local net1, info = PS.NetSale(r.out, 1)
        local vs = P.VendorSell(r.out)
        res.valueVendor = vs and vs * count or nil
        -- a real AH price only (AHSentinel gives the vendor value as "gross" when it has no AH price)
        if info and (info.gross or 0) > 0 and not (info.vendorWins and (info.cut or 0) == 0) then
            res.valueAH = info.gross * count
            res.ahCut = (info.cut or 0) * count
            res.depositRisk = (info.depositRisk or 0) > 0 and info.depositRisk * count or nil
            res.valueAHNet = res.valueAH - res.ahCut - (res.depositRisk or 0)
            res.priceKind = info.kind
        end
        if net1 then
            res.value = net1 * count
            res.valueSource = (info and info.vendorWins) and "vendor" or "ah"
        end
        res.ahFee = nil
        -- Disenchanting
        local DE = ns.Disenchant
        -- disenchanting only for enchanters who make gold (review 0.9.33, point 3); Retail: never (DE.WantsGold)
        local deOK = DE and withDE and DE.WantsGold and DE.WantsGold()
        if deOK then
            local g, n, own, src = PS.DisenchantValue(r.out)
            if g then
                -- AHSentinel's value: exactly its numbers
                res.deGross, res.deValue = g * count, n * count
                res.deCut = (g - n) * count
                res.deOwn, res.deSource, res.deComplete = own, "AHSentinel", true
                if DE.Value then
                    local _, _, yield = DE.Value(r.out)
                    res.deYield = yield
                end
            else
                local gross, complete, yield, ownN, shared, dsrc = DE.Value(r.out)
                if not gross and not PS.HasAHS() then
                    local enx = PS.EnchantrixValue(r.out)
                    if enx then gross, complete, dsrc = enx, true, "Enchantrix" end
                end
                if gross then
                    res.deGross = gross * count
                    -- the materials are sold in stacks: their net value (cut and deposit risk off)
                    if type(yield) == "table" and #yield > 0 then
                        local cut = 0
                        for _, y in ipairs(yield) do
                            local price = P.AH(y[1])
                            local netp = PS.NetPiece(y[1])
                            if price and netp then cut = cut + (y[2] or 0) * (y[3] or 0) * math.max(0, price - netp) end
                        end
                        res.deCut = cut * count
                    else
                        res.deCut = PS.Cut(res.deGross)
                    end
                    res.deValue = res.deGross - res.deCut
                    res.deComplete, res.deYield, res.deOwn, res.deShared, res.deSource = complete, yield, ownN, shared, dsrc
                    -- safety margin: under 10 real disenchants of the group the value is an estimate (own value only)
                    if dsrc ~= "Test" and (ownN or 0) + (shared or 0) < P.DE_SAFE_COUNT then
                        res.deSafety = res.deValue * P.DE_SAFETY
                        res.deValue = res.deValue - res.deSafety
                        res.deEstimated = true
                    end
                end
            end
        end
    end
    -- net = selling the product (AH or vendor); deNet = disenchanting it and selling the materials
    res.net = res.value - res.cost
    if res.deValue then res.deNet = res.deValue - res.cost end
    -- best way to use the product: AHSentinel's verdict, otherwise the better of the two
    local way, wayNet
    local DEm = ns.Disenchant
    if withDE and r.out and DEm and DEm.WantsGold and DEm.WantsGold() then way, wayNet = PS.BestWay(r.out) end
    if way then
        local count = ((r.outMin or 1) + (r.outMax or r.outMin or 1)) / 2
        res.bestNet = wayNet * count - res.cost
        res.bestVia = (way == "disenchant") and "de" or (res.valueSource or "ah")
    elseif res.deNet and (res.value <= 0 or res.deNet > res.net) then
        res.bestNet, res.bestVia = res.deNet, "de"
    else
        res.bestNet, res.bestVia = res.net, res.valueSource
    end
    return res
end

---------------------------------------------------------------------------
-- Money text: "+10s 80c", "−2s", "1g 5s"
---------------------------------------------------------------------------
function P.Money(copper, signed)
    if not copper then return "?" end
    local neg = copper < 0
    copper = math.floor(math.abs(copper) + 0.5)
    local g, s, c = math.floor(copper / 10000), math.floor((copper % 10000) / 100), copper % 100
    local parts = {}
    if g > 0 then parts[#parts + 1] = "|cffffd100" .. g .. "g|r" end
    if s > 0 then parts[#parts + 1] = "|cffc7c7cf" .. s .. "s|r" end
    if c > 0 or #parts == 0 then parts[#parts + 1] = "|cffc87533" .. c .. "c|r" end
    local txt = table.concat(parts, " ")
    if signed then txt = (neg and "−" or "+") .. txt elseif neg then txt = "−" .. txt end
    return txt
end

-- Plain version without colour codes (for compact hints)
function P.MoneyPlain(copper, signed)
    if not copper then return "?" end
    local neg = copper < 0
    copper = math.floor(math.abs(copper) + 0.5)
    local g, s, c = math.floor(copper / 10000), math.floor((copper % 10000) / 100), copper % 100
    local parts = {}
    if g > 0 then parts[#parts + 1] = g .. "g" end
    if s > 0 then parts[#parts + 1] = s .. "s" end
    if c > 0 or #parts == 0 then parts[#parts + 1] = c .. "c" end
    local txt = table.concat(parts, " ")
    if signed then txt = (neg and "−" or "+") .. txt elseif neg then txt = "−" .. txt end
    return txt
end

P.ORIGIN_COLOR = { ah = "d9a400", vendor = "9a9aa8", farm = "3aa83a", craft = "3fc7eb" }
