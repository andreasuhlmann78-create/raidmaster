-- GuildSentinel - Tooltip.lua
-- Fährt man mit der Maus über einen Spieler aus der Gilde, zeigt der Tooltip zusätzlich:
-- Rang, Main oder Twinks, Rolle, Berufe und Raid-Zugänge (soweit bekannt). Bewerber sind markiert.
-- Ein-/ausschalten: Einstellungen > "Infos im Spieler-Tooltip".

local ADDON, ns = ...
local L = ns.L
local T = {}
ns.Tooltip = T

local GREEN, GRAY = "|cff40d860", "|cff8a8f99"

-- Zeilen für einen Spieler (nil = nicht in der Gilde und kein Bewerber)
function T:Lines(name)
	name = ns.Short(name)
	if not name or not ns.guild then return nil end
	local lines = {}
	local e = ns.Roster.byName[name]
	if e then
		local head = (e.rank or "")
		local main = ns.Roster:MainOf(name)
		if main then
			head = head .. " · " .. L["Twink von "] .. main
		else
			local alts = ns.Roster:AltsOf(name)
			if #alts > 0 then head = head .. " · " .. L["Twinks: "] .. table.concat(alts, ", ") end
		end
		lines[#lines + 1] = head
		local role, src = ns.Comp:Role(name, e.class)
		if src ~= "guess" then lines[#lines + 1] = L["Rolle: "] .. ns.Group:RoleName(role) end
		local pr = ns.Prof:Of(name)
		if pr and pr.p then
			local t = {}
			for prof, x in pairs(pr.p) do t[#t + 1] = prof .. " " .. (x.r or "?") end
			table.sort(t)
			if #t > 0 then lines[#lines + 1] = L["Berufe: "] .. table.concat(t, ", ") end
		end
		local att = {}
		for _, a in ipairs(ns.Attune.LIST) do
			if ns.Attune:Status(name, a.key) then att[#att + 1] = a.short end
		end
		if #att > 0 then lines[#lines + 1] = L["Raid-Zugänge: "] .. table.concat(att, ", ") end
	else
		local a = ns.G().apps[name]
		if not a then return nil end
		lines[#lines + 1] = L["Bewerber"] .. " (" .. ns.Ago(a.t) .. ")"
	end
	return lines
end

function T:Add(tip, name)
	if not ns.db or not ns.db.tooltip then return end
	local lines = self:Lines(name)
	if not lines or #lines == 0 then return end
	tip:AddLine(ns.TITLE .. GRAY .. ":|r " .. lines[1], 1, 1, 1, true)
	for i = 2, #lines do tip:AddLine(GRAY .. lines[i] .. "|r", 1, 1, 1, true) end
	tip:Show()
end

local function OnUnit(tip)
	if not tip or not tip.GetUnit then return end
	-- moderner Client (WoW Forever, Retail): im Kampf können Namen "secret values" sein – dann nichts anfassen
	if ns.Game.MODERN and InCombatLockdown and InCombatLockdown() then return end
	local _, unit = tip:GetUnit()
	if not unit or ns.IsSecret(unit) or not UnitIsPlayer or not UnitIsPlayer(unit) then return end
	-- Name über GoldSentinelGame: nil bei geschütztem Namen
	local name = UnitName(unit)
	if ns.IsSecret(name) then return end
	name = (GoldSentinelGame and GoldSentinelGame.Short(name)) or (not ns.IsSecret(name) and name) or nil
	if not name then return end
	local ok, err = pcall(T.Add, T, tip, name)
	if not ok and ns.debug then ns:Print("Tooltip: " .. tostring(err)) end
end

function T:Hook()
	if self.hooked then return end
	self.hooked = true
	if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Unit then
		TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, function(tip)
			if tip == GameTooltip then OnUnit(tip) end
		end)
	elseif GameTooltip and GameTooltip.HookScript then
		GameTooltip:HookScript("OnTooltipSetUnit", OnUnit)
	end
end

ns:Listen("GS_LOGIN", function() T:Hook() end)
