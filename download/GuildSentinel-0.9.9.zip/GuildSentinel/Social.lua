-- GuildSentinel - Social.lua
-- Miteinander in der Gilde:
--   * Wer ist wo: Online-Mitglieder nach Zone (zum Treffen, Beschwören, Weltbosse)
--   * Abwesenheit: "Bin zwei Wochen weg" – zählt nicht als inaktiv und nicht für Beförderungsvorschläge
--   * Paten: neue Mitglieder bekommen einen festen Ansprechpartner
--   * Notizen ins Spiel schreiben: "Twink von …" in die echte Gildennotiz (für alle ohne Addon)
--   * Gildenchat mit Main-Namen: "Twinkie [Rokan]: …"
--   * Online-Hinweis mit Twinks: "Twinkie ist online (Rokan)"
--   * Dank-Punkte: mit einem Klick für Hilfe danken, Rangliste der Hilfsbereitesten
--
--   G.away[Name]   = { u = bis (Zeit), note, t, by }
--   G.mentor[Neu]  = { m = Pate, t, by }
--   G.thanks       = { [id] = { id, from, to, t, why } }

local ADDON, ns = ...
local L = ns.L
local So = {}
ns.Social = So

local GREEN, GRAY = "|cff40d860", "|cff8a8f99"

------------------------------------------------------------
-- Wer ist wo
------------------------------------------------------------
-- { { zone, members = { e } } } – volle Zonen zuerst, die eigene Zone ganz oben
function So:Zones()
	local by, list = {}, {}
	local myZone = GetRealZoneText and GetRealZoneText() or nil
	for _, e in ipairs(ns.Roster.list) do
		if e.online then
			local z = (e.zone and e.zone ~= "") and e.zone or L["unbekannt"]
			if not by[z] then by[z] = { zone = z, members = {} }; list[#list + 1] = by[z] end
			table.insert(by[z].members, e)
		end
	end
	for _, z in ipairs(list) do
		z.mine = myZone and z.zone == myZone
		table.sort(z.members, function(a, b) if a.level == b.level then return a.name < b.name end return a.level > b.level end)
	end
	table.sort(list, function(a, b)
		if a.mine ~= b.mine then return a.mine end
		if #a.members ~= #b.members then return #a.members > #b.members end
		return a.zone < b.zone
	end)
	return list
end

-- flache Liste für die Anzeige: Kopfzeile je Zone, dann die Mitglieder
function So:ZoneRows()
	local rows = {}
	for _, z in ipairs(self:Zones()) do
		rows[#rows + 1] = { head = true, zone = z.zone, n = #z.members, mine = z.mine }
		for _, e in ipairs(z.members) do rows[#rows + 1] = { e = e, zone = z.zone } end
	end
	return rows
end

------------------------------------------------------------
-- Abwesenheit
------------------------------------------------------------
function So:Away(name)
	if not ns.Feature("away") then return nil end
	local a = ns.G().away[name]
	if not a or (a.u or 0) <= ns.Now() then return nil end
	return a
end

-- abwesend: der Spieler selbst oder einer seiner Charaktere
function So:IsAway(name)
	local main = ns.Roster:MainOf(name) or name
	if self:Away(main) then return self:Away(main) end
	for _, alt in ipairs(ns.Roster:AltsOf(main)) do
		if self:Away(alt) then return self:Away(alt) end
	end
	return self:Away(name)
end

-- days = 0 hebt die Abwesenheit auf; name = nil heißt ich selbst
function So:SetAway(name, days, note)
	local g = ns.guild
	if not g then return end
	if not ns.Feature("away") then ns:Print(L["Diese Funktion ist ausgeschaltet (Einstellungen > Funktionen)."]) return end
	name = name or ns.Me()
	if not ns.Same(name, ns.Me()) and not ns.IsOfficer() then ns:Print(L["Abwesenheit für andere können nur Offiziere eintragen."]) return end
	local e = { u = (tonumber(days) or 0) > 0 and (ns.Now() + math.floor(tonumber(days) * 86400)) or 0, note = ns.Trim(note):sub(1, 80), t = ns.Now(), by = ns.Me() }
	g.away[name] = e
	ns.Comm:Send("AWAY", { n = name, e = e })
	ns:Fire("GS_SOCIAL")
	if e.u > 0 then
		ns:Print(string.format(L["%s ist abwesend bis %s."], name, date(L["%d.%m.%Y"], e.u)))
	else
		ns:Print(string.format(L["%s ist wieder da."], name))
	end
end

local function StoreAway(name, e)
	local g = ns.guild
	if not g or type(name) ~= "string" or type(e) ~= "table" or type(e.t) ~= "number" then return false end
	local old = g.away[name]
	if old and (old.t or 0) >= e.t then return false end
	g.away[name] = { u = tonumber(e.u) or 0, note = type(e.note) == "string" and e.note:sub(1, 80) or "", t = e.t, by = e.by }
	return true
end
So.StoreAway = StoreAway

ns.Comm:Register("AWAY", function(sender, d)
	-- für andere nur, wenn der Absender Offizier ist (oberste zwei Ränge)
	local x = ns.Roster.byName[sender]
	if not ns.SameExact(d.n, sender) and not (x and x.ri <= 1) then return end
	if StoreAway(d.n, d.e) then ns:Fire("GS_SOCIAL") end
end)

-- beim Einloggen: wieder da?
ns:Listen("GS_LOGIN", function()
	C_Timer.After(25, function()
		local a = ns.G().away[ns.Me()]
		if a and (a.u or 0) > ns.Now() then
			ns:Print(string.format(L["Du bist als abwesend gemeldet bis %s. Wieder da? /gs weg 0"], date(L["%d.%m.%Y"], a.u)))
		end
	end)
end)

------------------------------------------------------------
-- Paten
------------------------------------------------------------
function So:MentorOf(name)
	if not ns.Feature("mentor") then return nil end
	local m = ns.G().mentor[name]
	return m and m.m ~= "" and m.m or nil
end

function So:Mentees(mentor)
	local out = {}
	if not ns.Feature("mentor") then return out end
	for name, m in pairs(ns.G().mentor) do
		if m.m and ns.Same(m.m, mentor) and ns.Roster.byName[name] then out[#out + 1] = name end
	end
	table.sort(out)
	return out
end

function So:SetMentor(name, mentor)
	local g = ns.guild
	if not g or not name then return end
	if not ns.IsOfficer() then ns:Print(L["Paten können nur Offiziere zuteilen."]) return end
	if mentor and ns.Trim(mentor) ~= "" then
		local found = ns.FindMember(ns.Trim(mentor))
		mentor = found and found.name or ns.Proper(ns.Trim(mentor))
	else
		mentor = ""
	end
	local e = { m = mentor, t = ns.Now(), by = ns.Me() }
	g.mentor[name] = e
	ns.Comm:Send("MENT", { n = name, e = e })
	ns:Fire("GS_SOCIAL")
	if mentor ~= "" then ns:Print(string.format(L["%s ist jetzt Pate von %s."], mentor, name)) end
end

local function StoreMentor(name, e)
	local g = ns.guild
	if not g or type(name) ~= "string" or type(e) ~= "table" or type(e.t) ~= "number" then return false end
	local old = g.mentor[name]
	if old and (old.t or 0) >= e.t then return false end
	g.mentor[name] = { m = type(e.m) == "string" and e.m or "", t = e.t, by = e.by }
	return true
end
So.StoreMentor = StoreMentor

ns.Comm:Register("MENT", function(sender, d)
	local x = ns.Roster.byName[sender]
	if not (x and x.ri <= 1) then return end
	if StoreMentor(d.n, d.e) then
		local m = So:MentorOf(d.n)
		if m and ns.Same(m, ns.Me()) then ns:Print(string.format(L["Du bist jetzt Pate von %s – schreib ihm/ihr doch kurz!"], d.n)) end
		if m and ns.Same(d.n, ns.Me()) then ns:Print(string.format(L["Dein Ansprechpartner in der Gilde: %s"], m)) end
		ns:Fire("GS_SOCIAL")
	end
end)

ns:Listen("GS_LOGIN", function()
	C_Timer.After(35, function()
		local m = So:MentorOf(ns.Me())
		local join = ns.Jubilee and ns.Jubilee:JoinDate(ns.Me())
		if m and join and ns.Now() - join < 30 * 86400 then
			ns:Print(string.format(L["Dein Ansprechpartner in der Gilde: %s"], m))
		end
	end)
end)

------------------------------------------------------------
-- Notizen ins Spiel schreiben
------------------------------------------------------------
So.NOTE_MAX = 31

function So:CanWriteNotes()
	if ns.Test and ns.Test:Active() then return true end
	return (CanEditPublicNote and CanEditPublicNote()) and true or false
end

-- "Twink von Rokan" vor die bestehende Notiz (wenn noch nicht drin), höchstens 31 Zeichen
function So:NoteWithMain(note, main)
	note = ns.Trim(note)
	local tag = string.format(L["Twink von %s"], main)
	local low = note:lower()
	if low:find(tag:lower(), 1, true) then return note end
	-- alte Kennzeichnung ersetzen
	note = note:gsub("^[Tt]wink von %S+%s*", ""):gsub("^[Aa]lt of %S+%s*", ""):gsub("^[Aa]lt:%s*%S+%s*", "")
	local s = ns.Trim(tag .. " " .. note)
	if #s > self.NOTE_MAX then s = s:sub(1, self.NOTE_MAX) end
	return s
end

function So:WriteNote(name)
	if not self:CanWriteNotes() then ns:Print(L["Dein Rang darf keine Gildennotizen ändern."]) return false end
	local e = ns.Roster.byName[name]
	local main = ns.Roster:MainOf(name)
	if not e or not main or not GuildRosterSetPublicNote then return false end
	local new = self:NoteWithMain(e.note, main)
	if new == e.note then return false end
	if not ns.Blocked(L["Gildennotiz"] .. " " .. name .. ": " .. new) then GuildRosterSetPublicNote(e.index, new) end
	e.note = new
	return true
end

-- alle Twinks ohne passende Notiz
function So:NotesToWrite()
	local out = {}
	for _, e in ipairs(ns.Roster.list) do
		local main = ns.Roster:MainOf(e.name)
		if main and self:NoteWithMain(e.note, main) ~= ns.Trim(e.note) then out[#out + 1] = e.name end
	end
	return out
end

function So:WriteAllNotes()
	local n = 0
	for _, name in ipairs(self:NotesToWrite()) do
		if self:WriteNote(name) then n = n + 1 end
	end
	ns:Print(string.format(L["%d Gildennotizen eingetragen."], n))
	if ns.GuildRoster then C_Timer.After(1, function() ns.GuildRoster() end) end
	return n
end

------------------------------------------------------------
-- Gildenchat mit Main-Namen
------------------------------------------------------------
local function ChatFilter(self, event, msg, author, ...)
	if not ns.db or not ns.db.chatMain or not ns.guild then return false end
	local name = ns.Short(author)
	local main = name and ns.Roster:MainOf(name)
	if not main or type(msg) ~= "string" then return false end
	return false, GRAY .. "[" .. main .. "]|r " .. msg, author, ...
end

-- System: "X ist jetzt online." -> mit Main
local P_ONLINE
local function OnlinePattern()
	if P_ONLINE ~= nil then return P_ONLINE end
	local fmt = ERR_FRIEND_ONLINE_SS
	if type(fmt) ~= "string" then P_ONLINE = false return false end
	fmt = fmt:gsub("%%%d%$s", "\001"):gsub("%%s", "\001")
	fmt = fmt:gsub("([%%%(%)%.%+%-%*%?%[%]%^%$])", "%%%1")
	fmt = fmt:gsub("\001", "(.-)")
	P_ONLINE = "^" .. fmt .. "$"
	return P_ONLINE
end
So.OnlinePattern = OnlinePattern

local function SystemFilter(self, event, msg, ...)
	if not ns.db or not ns.db.onlineMain or not ns.guild or type(msg) ~= "string" then return false end
	local p = OnlinePattern()
	if not p then return false end
	local _, name = msg:match(p)
	if not name then return false end
	name = ns.Short(name)
	local main = ns.Roster:MainOf(name)
	local extra = ""
	if main then extra = " " .. GRAY .. "(" .. string.format(L["Twink von %s"], main) .. ")|r" end
	local away = So:Away(name)
	if away then extra = extra .. " " .. GRAY .. "(" .. L["abwesend gemeldet"] .. ")|r" end
	if extra == "" then return false end
	return false, msg .. extra, ...
end

function So:HookChat()
	if self.chatHooked or not ChatFrame_AddMessageEventFilter then return end
	self.chatHooked = true
	ChatFrame_AddMessageEventFilter("CHAT_MSG_GUILD", ChatFilter)
	ChatFrame_AddMessageEventFilter("CHAT_MSG_OFFICER", ChatFilter)
	ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM", SystemFilter)
end
So.ChatFilter, So.SystemFilter = ChatFilter, SystemFilter

ns:Listen("GS_LOGIN", function() So:HookChat() end)

------------------------------------------------------------
-- Dank-Punkte
------------------------------------------------------------
local counter = 0

function So:Thank(name, why)
	local g = ns.guild
	if not g or not name then return end
	if not ns.Feature("thanks") then ns:Print(L["Diese Funktion ist ausgeschaltet (Einstellungen > Funktionen)."]) return end
	-- echter Name aus der Gilde (Forever: auch nur Vorname, wenn eindeutig)
	local found = ns.FindMember(name)
	name = found and found.name or ns.Proper(name)
	if ns.Same(name, ns.Me()) or ns.Same(ns.Roster:MainOf(name) or name, ns.Roster:MainOf(ns.Me()) or ns.Me()) then
		ns:Print(L["Dir selbst kannst du nicht danken."])
		return
	end
	-- einmal am Tag je Spieler
	local today = math.floor(ns.Now() / 86400)
	local toMain = ns.Roster:MainOf(name) or name
	for _, t in pairs(g.thanks) do
		if ns.Same(t.from, ns.Me()) and ns.Same(ns.Roster:MainOf(t.to) or t.to, toMain) and math.floor(t.t / 86400) == today then
			ns:Print(string.format(L["Du hast %s heute schon gedankt."], toMain))
			return
		end
	end
	counter = counter + 1
	local e = { id = ns.Me() .. ns.Now() .. counter, from = ns.Me(), to = name, t = ns.Now(), why = ns.Trim(why):sub(1, 80) }
	g.thanks[e.id] = e
	ns.Comm:Send("THX", e)
	ns:Print(string.format(L["Du hast %s gedankt."], name))
	ns:Fire("GS_SOCIAL")
end

local function StoreThanks(e)
	local g = ns.guild
	if not g or type(e) ~= "table" or type(e.id) ~= "string" or type(e.from) ~= "string" or type(e.to) ~= "string" or g.thanks[e.id] then return false end
	g.thanks[e.id] = { id = e.id, from = e.from, to = e.to, t = tonumber(e.t) or ns.Now(), why = type(e.why) == "string" and e.why:sub(1, 80) or "" }
	return true
end
So.StoreThanks = StoreThanks

ns.Comm:Register("THX", function(sender, d)
	if not ns.SameExact(d.from, sender) then return end
	if StoreThanks(d) then
		local toMain = ns.Roster:MainOf(d.to) or d.to
		if ns.Same(toMain, ns.Roster:MainOf(ns.Me()) or ns.Me()) or ns.Same(d.to, ns.Me()) then
			ns:Print(string.format(L["%s dankt dir%s"], sender, (d.why and d.why ~= "") and (": " .. d.why) or "!"))
		end
		ns:Fire("GS_SOCIAL")
	end
end)

ns.Comm:Register("THXS", function(sender, d)
	if type(d.e) ~= "table" then return end
	local any
	for _, e in pairs(d.e) do if StoreThanks(e) then any = true end end
	if any then ns:Fire("GS_SOCIAL") end
end)

-- Rangliste (Twinks zählen für ihren Main): { { name, n, last } }
function So:ThanksTop(days)
	if not ns.Feature("thanks") then return {} end
	local limit = days and (ns.Now() - days * 86400) or 0
	local by, seen = {}, {}
	for _, t in pairs(ns.G().thanks) do
		local m = ns.Roster:MainOf(t.to) or t.to
		-- je Absender und Empfänger zählt höchstens ein Dank am Tag (schützt vor Spam)
		local once = (ns.Roster:MainOf(t.from) or t.from) .. ">" .. m .. ">" .. math.floor(t.t / 86400)
		if t.t >= limit and not seen[once] then
			seen[once] = true
			local x = by[m] or { name = m, n = 0, last = 0, from = {} }
			x.n = x.n + 1
			if t.t > x.last then x.last = t.t; x.why = t.why; x.lastFrom = t.from end
			by[m] = x
		end
	end
	local out = {}
	for _, x in pairs(by) do out[#out + 1] = x end
	table.sort(out, function(a, b) if a.n == b.n then return a.last > b.last end return a.n > b.n end)
	return out
end

function So:ThanksSync(days)
	local limit = ns.Now() - (days or 60) * 86400
	local out, n = {}, 0
	for id, t in pairs(ns.G().thanks) do
		if t.t >= limit and n < 200 then out[id] = t; n = n + 1 end
	end
	return out
end

-- alte Daten aufräumen
ns:Listen("GS_LOGIN", function()
	local g = ns.guild
	if not g then return end
	local limit = ns.Now() - 120 * 86400
	for id, t in pairs(g.thanks) do if t.t < limit then g.thanks[id] = nil end end
	for name, a in pairs(g.away) do if (a.u or 0) < ns.Now() - 30 * 86400 then g.away[name] = nil end end
end)
