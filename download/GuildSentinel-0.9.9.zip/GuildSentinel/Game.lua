-- GuildSentinel - Game.lua
-- Welche Spielversion läuft? GuildSentinel läuft in allen Classic-Clients:
--   * Classic Era / Hardcore / Season (1.15.x)      – Stufe 60, Classic-Inhalte
--   * WoW Forever (1.60.x)                          – wie Classic Era, aber Paladine und Schamanen auf beiden Seiten
--   * The Burning Crusade Classic / Anniversary (2.5.x) – Stufe 70, TBC-Inhalte, Paladine und Schamanen
--     auf beiden Seiten, 25er-Raids, Zugänge für Karazhan bis Schwarzer Tempel, heroische Schlüssel
-- Alle Module fragen hier nach, statt Zahlen wie "60" fest einzubauen.

local ADDON, ns = ...
local N = ns.N
local Game = {}
ns.Game = Game

local _, _, _, toc = GetBuildInfo()
Game.toc = tonumber(toc) or 11500
Game.TBC = Game.toc >= 20000 and Game.toc < 30000
Game.CLASSIC = Game.toc < 20000
Game.FOREVER = Game.toc >= 16000 and Game.toc < 20000
-- gemeinsame Erkennung aller GoldSentinel-Addons (GoldSentinelGame.lua); die eigene oben bleibt als Rückfall
local GSG = _G.GoldSentinelGame
if GSG then
	Game.FOREVER = GSG.IsForever
	Game.TBC = GSG.IsTBC
	Game.MODERN = GSG.IsModern
	Game.flavor = GSG.flavor
else
	Game.MODERN = Game.FOREVER
end
-- Berufsfenster: WoW Forever hat das neue Fenster im Retail-Stil (C_TradeSkillUI, ProfessionsFrame),
-- Classic Era und TBC das klassische (TradeSkillFrame, CraftFrame)
Game.MODERN_PROFESSIONS = Game.FOREVER

-- Höchststufe: aus dem Spiel, sonst nach Version
function Game:MaxLevel()
	local m = GetMaxPlayerLevel and GetMaxPlayerLevel()
	if type(m) == "number" and m > 0 then return m end
	return self.TBC and 70 or 60
end
Game.MAX_LEVEL = Game:MaxLevel()

-- Stufe für das erste Reittier (TBC ab 2.3: 30, Classic: 40)
Game.MOUNT_LEVEL = Game.TBC and 30 or 40
-- Fliegen (nur TBC)
Game.FLY_LEVEL = Game.TBC and 70 or nil

-- Ansagen im Gildenchat
Game.MILESTONES = Game.TBC and { 10, 20, 30, 40, 50, 60, 70 } or { 10, 20, 30, 40, 50, 60 }

-- Stufenbereiche für die Aufstellung
Game.BANDS = Game.TBC
	and { { min = 1, max = 39 }, { min = 40, max = 57 }, { min = 58, max = 69 }, { min = 70, max = 70 } }
	or { { min = 1, max = 29 }, { min = 30, max = 49 }, { min = 50, max = 59 }, { min = 60, max = 60 } }

-- Raidgröße und Standard-Ziel
Game.RAID_SIZE = Game.TBC and 25 or 40
Game.DEFAULT_WANT = Game.TBC and {
	tank = 3, heal = 7,
	WARRIOR = 3, ROGUE = 2, HUNTER = 2, MAGE = 3, WARLOCK = 3, PRIEST = 3, DRUID = 2, SHAMAN = 4, PALADIN = 3,
} or {
	tank = 4, heal = 12,
	WARRIOR = 8, ROGUE = 4, HUNTER = 3, MAGE = 6, WARLOCK = 4, PRIEST = 5, DRUID = 3, SHAMAN = 5, PALADIN = 5,
}
-- ab welcher Stufe jemand für die Aufstellung zählt
Game.COMP_MIN = Game.TBC and 68 or 55

-- Paladine und Schamanen auf beiden Seiten: in TBC (Draenei/Blutelfen) und auf WoW Forever
Game.BOTH_HYBRIDS = Game.TBC or Game.FOREVER

-- Klassen je Fraktion
function Game:Classes(faction)
	local list = { "WARRIOR", "ROGUE", "HUNTER", "MAGE", "WARLOCK", "PRIEST", "DRUID" }
	if self.BOTH_HYBRIDS then
		list[#list + 1] = "PALADIN"
		list[#list + 1] = "SHAMAN"
	elseif faction == "Alliance" then
		list[#list + 1] = "PALADIN"
	else
		list[#list + 1] = "SHAMAN"
	end
	return list
end

-- Auswahl für Stufen-Listen (Beförderung, Gruppensuche)
Game.PROMOTE_LEVELS = Game.TBC and { 58, 60, 65, 68, 70 } or { 50, 55, 58, 60 }
Game.LFG_LEVELS = Game.TBC and { 1, 30, 58, 65, 68, 70 } or { 1, 40, 50, 55, 58, 60 }

-- Meilensteine "x Spieler für einen Raid eingestimmt"
Game.ATTUNE_STEPS = Game.TBC and { 10, 25 } or { 20, 40 }

-- Name der Version (Anzeige)
function Game:Name()
	if self.TBC then return "Burning Crusade Classic" end
	if self.FOREVER then return "WoW Forever" end
	return "Classic Era"
end

------------------------------------------------------------
-- Inhalte für TBC (die Classic-Listen stehen in den jeweiligen Modulen)
------------------------------------------------------------
-- Dungeons in der Scherbenwelt (Namen wie im deutschen Spiel)
Game.TBC_DUNGEONS = {
	{ key = "ramps", n = N["Höllenfeuerbollwerk"], min = 59, max = 62 },
	{ key = "bf", n = N["Der Blutkessel"], min = 60, max = 63 },
	{ key = "sp", n = N["Die Sklavenunterkünfte"], min = 61, max = 64 },
	{ key = "ub", n = N["Der Tiefensumpf"], min = 62, max = 65 },
	{ key = "mt", n = N["Managruft"], min = 63, max = 66 },
	{ key = "ac", n = N["Auchenaikrypta"], min = 64, max = 67 },
	{ key = "ohb", n = N["Vorgebirge des Alten Hügellands"], min = 66, max = 68 },
	{ key = "seth", n = N["Sethekkhallen"], min = 67, max = 69 },
	{ key = "sv", n = N["Die Dampfkammer"], min = 68, max = 70 },
	{ key = "slabs", n = N["Schattenlabyrinth"], min = 69, max = 70 },
	{ key = "sh", n = N["Die Zerschmetterten Hallen"], min = 69, max = 70 },
	{ key = "bm", n = N["Der Schwarze Morast"], min = 69, max = 70 },
	{ key = "mech", n = N["Die Mechanar"], min = 69, max = 70 },
	{ key = "bot", n = N["Die Botanika"], min = 69, max = 70 },
	{ key = "arc", n = N["Die Arkatraz"], min = 69, max = 70 },
	{ key = "mgt", n = N["Terrasse der Magister"], min = 70, max = 70 },
	{ key = "heroic", n = N["Heroische Instanz"], min = 70, max = 70 },
}

-- Neue Dungeons und Raids auf WoW Forever (Stufen laut Blizzard; deutsche Namen wie auf der deutschen Forever-Seite)
Game.FOREVER_DUNGEONS = {
	{ key = "thanes", n = N["Halle der Thanen"], min = 13, max = 18 },
	{ key = "lordaeron", n = N["Ruinen von Lordaeron"], min = 15, max = 20 },
	{ key = "excav", n = N["Ausgrabungsstätte: Sumpfland"], min = 26, max = 31 },
	{ key = "dalaran", n = N["Stadt Dalaran"], min = 28, max = 33 },
	{ key = "drowned", n = N["Versunkene Stadt"], min = 35, max = 40 },
	{ key = "kroldok", n = N["Feste Krol'dok"], min = 40, max = 45 },
	{ key = "alcaz", n = N["Gefängnis von Alcaz"], min = 48, max = 53 },
	{ key = "blackmaw", n = N["Schwarzschlundfeste"], min = 55, max = 60 },
	{ key = "shaper", n = N["Terrasse des Formers"], min = 58, max = 60 },
	-- Raids ab 9. Dezember 2026 (kleine Raids passen gut zur Gruppensuche)
	{ key = "barrow", n = N["Tiefengrabhügel (Raid, 10)"], min = 60, max = 60, raid = 10 },
	{ key = "hyjal", n = N["Hyjalgipfel (Raid, 20)"], min = 60, max = 60, raid = 20 },
	{ key = "onyforever", n = N["Onyxias Hort (Raid, 40)"], min = 60, max = 60, raid = 40 },
}

-- Raid-Zugänge und Schlüssel in TBC (Quest erledigt oder Gegenstand vorhanden)
Game.TBC_ATTUNE = {
	{ key = "kara", short = "Kara", name = N["Karazhan"], quests = { 9837 }, items = { 24490 }, level = 68, raid = true },          -- Der Schlüssel des Meisters
	{ key = "ssc", short = "SSC", name = N["Höhle des Schlangenschreins"], quests = { 10901, 13431 }, level = 70, raid = true },  -- Der Knüppel von Kar'desh
	{ key = "tk", short = "FdS", name = N["Festung der Stürme"], quests = { 10888, 13430 }, level = 70, raid = true },            -- Prüfung der Naaru: Magtheridon
	{ key = "hyjal", short = "Hyjal", name = N["Hyjalgipfel"], quests = { 10445, 13432 }, level = 70, raid = true },             -- Die Phiolen der Ewigkeit
	{ key = "bt", short = "BT", name = N["Der Schwarze Tempel"], quests = { 10985 }, items = { 32649 }, level = 70, raid = true }, -- Medaillon von Karabor
	-- Schlüssel für normale Dungeons
	{ key = "shkey", short = "ZH", name = N["Schlüssel der Zerschmetterten Hallen"], items = { 28395 }, level = 68, isKey = true },
	{ key = "slkey", short = "SL", name = N["Schlüssel des Schattenlabyrinths"], items = { 27991 }, level = 68, isKey = true },
	{ key = "arckey", short = "Arc", name = N["Schlüssel zur Arkatraz"], items = { 31084 }, level = 68, isKey = true },
	-- heroische Schlüssel (Ruf: wohlwollend)
	{ key = "hhfc", short = "H-HFC", name = N["Flammengeschmiedeter Schlüssel (heroisch Höllenfeuer)"], items = { 30622, 30637 }, level = 70, isKey = true, heroic = true },
	{ key = "hcr", short = "H-CR", name = N["Schlüssel des Kessels (heroisch Echsenkessel)"], items = { 30623 }, level = 70, isKey = true, heroic = true },
	{ key = "hauch", short = "H-Auch", name = N["Schlüssel der Auchenai (heroisch Auchindoun)"], items = { 30633 }, level = 70, isKey = true, heroic = true },
	{ key = "htk", short = "H-TK", name = N["Warpgeschmiedeter Schlüssel (heroisch Festung der Stürme)"], items = { 30634 }, level = 70, isKey = true, heroic = true },
	{ key = "hcot", short = "H-HdZ", name = N["Schlüssel der Zeit (heroisch Höhlen der Zeit)"], items = { 30635 }, level = 70, isKey = true, heroic = true },
}

-- wichtige Rezepte für TBC-Raids (Item-ID, Beruf); die Namen liefert das Spiel
Game.TBC_IMPORTANT = {
	{ i = 22854, p = 2259 },  -- Fläschchen des unerbittlichen Angriffs
	{ i = 22853, p = 2259 },  -- Fläschchen der mächtigen Wiederherstellung
	{ i = 22861, p = 2259 },  -- Fläschchen des blendenden Lichts
	{ i = 22866, p = 2259 },  -- Fläschchen des reinen Todes
	{ i = 22851, p = 2259 },  -- Fläschchen der Stärkung
	{ i = 22832, p = 2259 },  -- Supermanatrank
	{ i = 22829, p = 2259 },  -- Superheiltrank
	{ i = 22838, p = 2259 },  -- Hasttrank
	{ i = 22839, p = 2259 },  -- Zerstörungstrank
	{ i = 22849, p = 2259 },  -- Eisenschildtrank
	{ i = 22831, p = 2259 },  -- Elixier der großen Beweglichkeit
	{ i = 22834, p = 2259 },  -- Elixier der großen Verteidigung
	{ i = 23571, p = 2259 },  -- Urmacht (Transmutation)
	{ i = 21845, p = 3908 },  -- Urmondstoff
	{ i = 24272, p = 3908 },  -- Schattenstoff
	{ i = 24271, p = 3908 },  -- Zauberstoff
	{ i = 23449, p = 2575 },  -- Khoriumbarren
}

-- Abklingzeiten in TBC
Game.TBC_COOLDOWNS = {
	{ key = "transmute", n = N["Transmutation"], spells = { 29688, 32765, 32766, 28566, 28567, 28568, 28569, 28580, 28581, 28582, 28583, 28584, 28585, 17187, 17559, 17560, 17561, 17562, 17563, 17564, 17565, 17566 }, out = 23571 },
	{ key = "mooncloth", n = N["Urmondstoff"], spells = { 26751 }, out = 21845 },
	{ key = "shadowcloth", n = N["Schattenstoff"], spells = { 36686 }, out = 24272 },
	{ key = "spellcloth", n = N["Zauberstoff"], spells = { 31373 }, out = 24271 },
	{ key = "saltshaker", n = N["Salzstreuer (Geläutertes Tiefgesteinsalz)"], item = 15846, out = 15409 },
}

-- Dienste in TBC (zusätzlich zu den Classic-Diensten)
Game.TBC_SERVICES = {
	{ key = "port_sm", n = N["Portal: Silbermond"], spells = { 32267 }, class = "MAGE", horde = true },
	{ key = "port_exo", n = N["Portal: Die Exodar"], spells = { 32266 }, class = "MAGE", alliance = true },
	{ key = "port_shatt", n = N["Portal: Shattrath"], spells = { 35717, 33691 }, class = "MAGE" },
	{ key = "table", n = N["Erfrischungstisch"], spells = { 43987 }, class = "MAGE" },
	{ key = "soulwell", n = N["Seelenbrunnen"], spells = { 29893 }, class = "WARLOCK" },
}
