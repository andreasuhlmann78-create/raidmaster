-- BuffSentinel - Options.lua
-- Einstellungsfenster (komplett per Maus) und Minimap-Button

local ADDON, BS = ...
local L = BS.L
local C = BS.COLORS

-- Links: zuerst die Listen (Einträge je Skillung), dann die Bereiche der Optionen (OPT-ALLE 18.11.), zuletzt der Recorder
local PAGES = {
    { key = "skill", label = L.SPEC_2 },
    { key = "proc",  label = "Procs" },
    { key = "buff",  label = "Buffs" },
    { key = "cd",    label = "Cooldowns" },
    { key = "dispel",label = L.DISPEL },
    { key = "aktiv",   label = L.OPT_AREA_ACTIVE, opt = true },
    { key = "toene",   label = L.OPT_AREA_SOUNDS, opt = true },
    { key = "anzeige", label = L.OPT_AREA_DISPLAY, opt = true },
    { key = "hilfen",  label = L.OPT_AREA_HELPERS, opt = true },
    { key = "teilen",  label = L.OPT_AREA_SHARE, opt = true },
    { key = "rec",   label = L.RECORDER },
    { key = "search", label = "", hidden = true },
}
BS.OPT_PAGES = PAGES


local CONTENT_W = 560

------------------------------------------------------------------------
-- Kleine UI-Bausteine
------------------------------------------------------------------------
local function Tex(parent, layer, r, g, b, a)
    local t = parent:CreateTexture(nil, layer or "BACKGROUND")
    t:SetColorTexture(r, g, b, a or 1)
    return t
end

local function OnOff(v) return v and L.ON or L.OFF end

local function SetShownSafe(w, on)
    if on then w:Show() else w:Hide() end
end

local function FlatButton(parent, w, h, label)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(w, h)
    b.bg = Tex(b, "BACKGROUND", 0.18, 0.19, 0.24, 1)
    b.bg:SetAllPoints()
    b.hl = Tex(b, "HIGHLIGHT", 1, 0.65, 0.2, 0.20)
    b.hl:SetAllPoints()
    b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    b.text:SetPoint("CENTER")
    b.text:SetText(label or "")
    function b:SetLabel(t) self.text:SetText(t) end
    function b:SetActive(on)
        if on then self.bg:SetColorTexture(0.55, 0.33, 0.08, 1) else self.bg:SetColorTexture(0.18, 0.19, 0.24, 1) end
    end
    return b
end

local function CheckBox(parent)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(20, 20)
    b.box = Tex(b, "ARTWORK", 0.22, 0.23, 0.28, 1)
    b.box:SetAllPoints()
    b.check = b:CreateTexture(nil, "OVERLAY")
    b.check:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
    b.check:SetSize(26, 26)
    b.check:SetPoint("CENTER")
    local hl = Tex(b, "HIGHLIGHT", 1, 0.65, 0.2, 0.25)
    hl:SetAllPoints()
    function b:SetChecked(on) SetShownSafe(self.check, on) end
    function b:SetUsable(on) self:SetAlpha(on and 1 or 0.35) end
    return b
end

------------------------------------------------------------------------
-- Seiten mit Widget-Pool (wird bei jeder Aktualisierung neu befüllt)
------------------------------------------------------------------------
local function NewPage(parent, key)
    local scroll = CreateFrame("ScrollFrame", "BuffSentinelPage_" .. key, parent, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 14, -44)
    scroll:SetPoint("BOTTOMRIGHT", -32, 12)
    local child = CreateFrame("Frame", nil, scroll)
    child:SetSize(CONTENT_W, 10)
    scroll:SetScrollChild(child)
    scroll.child = child
    scroll.pool, scroll.used, scroll.y, scroll.toggles = {}, {}, 0, {}
    scroll:Hide()
    return scroll
end

local function ResetPage(p)
    p.y = 0
    p.toggles = {}
    for t, list in pairs(p.pool) do
        for _, w in ipairs(list) do w:Hide(); w:ClearAllPoints() end
        p.used[t] = 0
    end
end

local function Acquire(p, t, create)
    p.used[t] = (p.used[t] or 0) + 1
    p.pool[t] = p.pool[t] or {}
    local w = p.pool[t][p.used[t]]
    if not w then
        w = create(p.child)
        p.pool[t][p.used[t]] = w
    end
    w:Show()
    return w
end

local function FinishPage(p)
    p.child:SetHeight(math.max(10, p.y + 20))
end

local function AddHeader(p, text)
    local fs = Acquire(p, "header", function(parent)
        local f = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        f:SetJustifyH("LEFT")
        return f
    end)
    p.y = p.y + (p.y > 0 and 10 or 0)
    fs:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
    fs:SetText(text)
    fs:SetTextColor(C.accent[1], C.accent[2], C.accent[3])
    p.y = p.y + 26
end

local function AddText(p, text, color, indent)
    local fs = Acquire(p, "text", function(parent)
        local f = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        f:SetJustifyH("LEFT")
        if f.SetWordWrap then f:SetWordWrap(true) end
        return f
    end)
    indent = indent or 0
    fs:SetWidth(CONTENT_W - indent)
    fs:SetPoint("TOPLEFT", p.child, "TOPLEFT", indent, -p.y)
    fs:SetText(text)
    color = color or C.text
    fs:SetTextColor(color[1], color[2], color[3])
    p.y = p.y + math.max(14, fs:GetStringHeight()) + 6
end

local function AddButton(p, label, w, onClick, x, keepY)
    local b = Acquire(p, "button", function(parent) return FlatButton(parent, 120, 24, "") end)
    b:SetSize(w or 160, 24)
    b:SetLabel(label)
    b:SetActive(false)
    b:SetPoint("TOPLEFT", p.child, "TOPLEFT", x or 0, -p.y)
    b:SetScript("OnClick", onClick)
    if not keepY then p.y = p.y + 30 end
    return b
end

-- enabled (optional): Funktion; liefert sie false, ist der Schalter ausgegraut und nicht klickbar
local function AddToggle(p, label, get, set, indent, enabled)
    local row = Acquire(p, "toggle", function(parent)
        local r = CreateFrame("Button", nil, parent)
        r:SetSize(CONTENT_W, 22)
        r.cb = CheckBox(r)
        r.cb:SetPoint("LEFT", 0, 0)
        r.cb:EnableMouse(false)
        r.text = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        r.text:SetPoint("LEFT", r.cb, "RIGHT", 10, 0)
        local hl = Tex(r, "HIGHLIGHT", 1, 1, 1, 0.04)
        hl:SetAllPoints()
        return r
    end)
    row:SetPoint("TOPLEFT", p.child, "TOPLEFT", indent or 0, -p.y)
    row.text:SetText(label)
    row.cb:SetChecked(get())
    local on = not enabled or enabled() ~= false
    row:SetAlpha(on and 1 or 0.45)
    row:SetScript("OnClick", function()
        if enabled and enabled() == false then return end
        set(not get())
        row.cb:SetChecked(get())
    end)
    row.get = get
    row.enabled = on
    -- für die Testroutine: alle Schalter der Seite (wird bei jedem Neuaufbau geleert)
    p.toggles[#p.toggles + 1] = { row = row, label = label }
    p.y = p.y + 26
end

-- Zeile für einen Buff/Proc/Cooldown-Eintrag
local function CreateEntryRow(parent)
    local r = CreateFrame("Frame", nil, parent)
    r:SetSize(CONTENT_W, 46)
    r.bg = Tex(r, "BACKGROUND", 1, 1, 1, 0.035)
    r.bg:SetAllPoints()
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(34, 34)
    r.icon:SetPoint("LEFT", 6, 0)
    r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    r.name:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 10, -2)
    r.name:SetJustifyH("LEFT")
    r.status = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    r.status:SetPoint("BOTTOMLEFT", r.icon, "BOTTOMRIGHT", 10, 2)
    r.status:SetJustifyH("LEFT")
    r.status:SetWidth(300)
    r.cb = CheckBox(r)
    r.cb:SetPoint("RIGHT", -12, 0)
    r.mode = FlatButton(r, 96, 22, "")
    r.mode:SetPoint("RIGHT", r.cb, "LEFT", -14, 0)
    -- eigene Klingel für diesen Eintrag
    r.bell = FlatButton(r, 62, 22, "")
    r.bell:SetScript("OnEnter", function(self)
        BS.TipBeside(self, BS.optionsFrame or self)       -- neben dem Fenster: verdeckt keine Zeile (T140)
        GameTooltip:AddLine(L.BELL, 1, 0.82, 0)
        GameTooltip:AddLine(L.OWN_SOUND_FOR_THIS_ENTRY, 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end)
    r.bell:SetScript("OnLeave", function() GameTooltip:Hide() end)
    -- "Auto": manuelle Änderung verwerfen, zurück zur automatischen Auswahl nach Skillung
    r.auto = FlatButton(r, 52, 22, "Auto")
    r.auto:SetScript("OnEnter", function(self)
        BS.TipBeside(self, BS.optionsFrame or self)
        GameTooltip:AddLine(L.BACK_TO_DEFAULT, 1, 0.82, 0)
        GameTooltip:AddLine(L.BUFFSENTINEL_DECIDES_AGAIN_BASED_ON, 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    r.auto:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return r
end

local function AddEntryRow(p, e)
    local r = Acquire(p, "entry", CreateEntryRow)
    r:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
    r.icon:SetTexture(e.icon)
    r.icon:SetDesaturated(not e.known)

    local tags = ""
    if e.data.forever then tags = tags .. "  |cff66ccff[Forever]|r" end
    if e.data.group then tags = tags .. L.GROUP_3 end
    if e.data.spellBySpec and e.spellName and e.data.label then
        tags = tags .. "  |cffaaaaaa» " .. e.spellName .. "|r"
    end
    r.name:SetText(e.label .. tags)
    r.name:SetTextColor(e.known and 1 or 0.55, e.known and 1 or 0.55, e.known and 1 or 0.6)

    local status = e.status or ""
    if e.manual then status = status .. L.MANUAL_PREFIX .. (e.enabled and L.ON or L.OFF) .. ")|r" end
    r.status:SetText(status)
    local col = e.statusColor or C.dim
    r.status:SetTextColor(col[1], col[2], col[3])

    r.cb:SetChecked(e.enabled)
    r.cb:SetUsable(e.known)
    r.cb:SetScript("OnClick", function()
        if not e.known then return end
        BS:SetEntrySetting(e.key, "enabled", not e.enabled)
    end)

    if e.kind == "buff" then
        r.mode:Show()
        r.mode:SetLabel(e.mode == "combat" and L.COMBAT_ONLY or L.ALWAYS)
        r.mode:SetScript("OnClick", function()
            BS:SetEntrySetting(e.key, "mode", e.mode == "combat" and "always" or "combat")
        end)
    else
        r.mode:Hide()
    end

    r.bell:ClearAllPoints()
    r.bell:SetPoint("RIGHT", (e.kind == "buff") and r.mode or r.cb, "LEFT", -10, 0)
    r.bell:SetLabel(e.bell and L.SOUND_ON or L.SOUND_OFF)
    r.bell:SetActive(e.bell)
    r.bell:SetScript("OnClick", function() BS:SetEntrySetting(e.key, "bell", not e.bell) end)

    r.auto:ClearAllPoints()
    r.auto:SetPoint("RIGHT", r.bell, "LEFT", -8, 0)
    if e.manual then
        r.auto:Show()
        r.auto:SetScript("OnClick", function() BS:SetEntrySetting(e.key, "enabled", nil) end)
    else
        r.auto:Hide()
    end
    p.y = p.y + 50
end

------------------------------------------------------------------------
-- Seiteninhalte
------------------------------------------------------------------------
local Fill = {}

function Fill.skill(p)
    AddHeader(p, L.DETECTED_SPEC)
    AddText(p, "|cffffffff" .. BS:SpecText() .. "|r   |cff888888" .. (BS.FLAVOR_NAMES[BS.flavor] or BS.flavor) .. "|r", C.text)
    if BS.isRetail then
        AddText(p, L.RETAIL_MIDNIGHT_BLIZZARD_MAKES_BUFFS ..
            L.PROCS_AND_COOLDOWNS_IN_COMBAT, C.yellow)
    end

    local data = BS.ClassData[BS.class]
    for tab = 1, (BS.family == "classic") and 3 or 0 do
        local pts = BS.points[tab] or 0
        local bar = Acquire(p, "bar", function(parent)
            local f = CreateFrame("Frame", nil, parent)
            f:SetSize(CONTENT_W, 18)
            f.bg = Tex(f, "BACKGROUND", 0.16, 0.17, 0.21, 1)
            f.bg:SetPoint("LEFT", 130, 0); f.bg:SetSize(300, 12)
            f.fill = Tex(f, "ARTWORK", 1, 0.65, 0.2, 1)
            f.fill:SetPoint("LEFT", f.bg, "LEFT"); f.fill:SetHeight(12)
            f.name = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            f.name:SetPoint("LEFT", 0, 0)
            f.val = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            f.val:SetPoint("LEFT", f.bg, "RIGHT", 10, 0)
            return f
        end)
        bar:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
        bar.name:SetText(BS:SpecName(tab) or (L.TREE .. tab))
        bar.fill:SetWidth(math.max(1, 300 * math.min(pts, 51) / 51))
        if tab == BS.mainSpec then bar.fill:SetColorTexture(1, 0.65, 0.2, 1) else bar.fill:SetColorTexture(0.5, 0.5, 0.55, 1) end
        bar.val:SetText(pts .. L.POINTS .. (tab == BS.mainSpec and L.MAIN_TREE or ""))
        p.y = p.y + 22
    end
    if BS.family == "modern" then
        AddText(p, L.TALENTS_ARE_CHECKED_BY_THEIR, C.dim)
    elseif not BS.talentsReadable then
        AddText(p, L.TALENTS_COULD_NOT_BE_READ, C.yellow)
    end

    local c = BS:CountActive()
    AddHeader(p, L.ADJUSTED_AUTOMATICALLY)
    AddText(p, string.format(L.ACTIVE_FOR_THIS_SPEC_PROCS ..
        L.THE_BUTTONS_ARE_SWITCHED_AUTOMATICALLY, c.proc, c.buff, c.cd), C.text)
    local overrides = BS:CountOverrides()
    if overrides > 0 then
        AddText(p, overrides .. L.ENTRIES_WERE_CHANGED_MANUALLY_FOR, C.dim)
        AddButton(p, L.RESTORE_RECOMMENDATION, 220, function() BS:ResetEntrySettings() end)
    end
    AddButton(p, L.RE_READ_SPEC, 220, function() BS:FullScan() end)

    -- Talente, auf die BuffSentinel reagiert
    local shown = false
    for _, e in ipairs(BS.entries) do
        local d = e.data
        local list = d.talents or e.enableList
        local spellList = d.talentSpell or d.enableIfTalentSpell
        if not list and spellList then
            if not shown then AddHeader(p, L.TALENTS_THAT_AFFECT_THE_BUTTONS); shown = true end
            local what = d.talentSpell and L.UNLOCKS or L.ALSO_ENABLES
            local match = d.talentSpell and e.talentMatch or e.viaTalent
            local first = type(spellList) == "table" and spellList[1] or spellList
            if match then
                AddText(p, "|TInterface\\RaidFrame\\ReadyCheck-Ready:14:14|t  " .. match .. "  –  " .. what .. e.label, C.text, 6)
            else
                AddText(p, "–  " .. ((BS.SpellInfo(first)) or ("Talent " .. first)) .. L.NOT_LEARNED_2 .. what .. e.label, C.dim, 6)
            end
        end
        if list then
            if not shown then AddHeader(p, L.TALENTS_THAT_AFFECT_THE_BUTTONS); shown = true end
            local match = BS:HasTalent(list)
            local what = d.talents and L.UNLOCKS or L.ALSO_ENABLES
            if match then
                AddText(p, "|TInterface\\RaidFrame\\ReadyCheck-Ready:14:14|t  " .. match .. "  –  " .. what .. e.label, C.text, 6)
            else
                local loc = BS:ResolveTalentList(list) or list[1]
                AddText(p, "–  " .. loc .. L.NOT_LEARNED_2 .. what .. e.label, C.dim, 6)
            end
        end
    end

    -- Namen in der Client-Sprache (gelernt, geteilt oder manuell zugeordnet)
    local lists = BS.nameIndex and BS.nameIndex.lists[BS.class]
    if lists and #lists > 0 and BS.talentsReadable then
        AddHeader(p, L.TALENT_AND_ABILITY_NAMES)
        AddText(p, L.IF_A_NAME_IS_ONLY ..
            L.ON_THE_SERVER_IF_NOBODY, C.dim)
        for _, item in ipairs(lists) do
            local en = item.names[1]
            local loc, how, _, from = BS:ResolveTalentList(item.names)
            if not loc and item.what == L.ABILITY then
                local sp = BS:LocalSpellName(en)
                if sp then loc, how = sp, L.SPELL_ID end
            end
            local line
            if loc and how == "direkt" then
                line = "|TInterface\\RaidFrame\\ReadyCheck-Ready:14:14|t  " .. loc .. "  |cff888888(" .. item.what .. L.FOUND_IN_THE_CLIENT
            elseif loc then
                local howText = (how == "gelernt" and L.HOW_LEARNED) or (how == "manuell" and L.HOW_MANUAL) or how
                local src = howText .. (from and (L.FROM_ .. from) or "")
                line = "|TInterface\\RaidFrame\\ReadyCheck-Ready:14:14|t  " .. en .. " = |cffffffff" .. loc .. "|r  |cff888888(" .. src .. ")|r"
            else
                line = "|cffffd040?|r  " .. en .. "  |cff888888(" .. item.what .. L.STILL_UNKNOWN
            end
            AddText(p, line, C.text, 6)
            p.y = p.y - 6
            if not loc or how == "manuell" then
                if how == "manuell" then
                    AddButton(p, L.REMOVE_ASSIGNMENT, 170, function() BS:UnassignTalent(en) end, 380, true)
                else
                    local open = BS.assigning == en
                    local b = AddButton(p, open and L.CANCEL or L.ASSIGN, 170, function()
                        BS.assigning = (BS.assigning ~= en) and en or nil
                        BS:RefreshOptions()
                    end, 380, true)
                    b:SetActive(open)
                end
                p.y = p.y + 28
            else
                p.y = p.y + 8
            end
            if BS.assigning == en then
                AddText(p, L.WHICH_TALENT_IN_YOUR_CLIENT .. en .. "\"?", C.yellow, 12)
                for tab = 1, 3 do
                    local col = 0
                    local any = false
                    for _, t in ipairs(BS.allTalents) do
                        if t.tab == tab then
                            if not any then
                                AddText(p, "|cffffa733" .. (BS:SpecName(tab) or (L.TREE .. tab)) .. "|r", C.text, 12)
                                any = true
                            end
                            local pos = t.pos
                            AddButton(p, t.name, 176, function() BS:AssignTalent(en, pos) end, 12 + col * 182, true)
                            col = col + 1
                            if col == 3 then col = 0; p.y = p.y + 28 end
                        end
                    end
                    if col > 0 then p.y = p.y + 28 end
                end
                p.y = p.y + 6
            end
        end
    end

    local nt, ns = BS:CountLearned()
    AddText(p, string.format(L.LEARNED_NAMES_ALL_CHARACTERS_TALENTS,
        nt, ns,
        BS:SyncStatusText(),
        BS.gdb.shareNames and ("|cff66dd77" .. L.ON .. "|r") or ("|cffff5555" .. L.OFF .. "|r")), C.dim)

    AddHeader(p, L.ALL_LEARNED_TALENTS)
    if #BS.talentList == 0 then
        AddText(p, BS.isRetail and L.IN_RETAIL_TALENTS_ARE_CHECKED or L.NO_TALENT_POINTS_SPENT_YET, C.dim)
    elseif BS.family == "modern" then
        local parts = {}
        for _, t in ipairs(BS.talentList) do tinsert(parts, t.name) end
        AddText(p, table.concat(parts, ",  "), C.text)
    else
        for tab = 1, 3 do
            local parts = {}
            for _, t in ipairs(BS.talentList) do
                if t.tab == tab then tinsert(parts, t.name .. " " .. t.rank .. "/" .. t.maxRank) end
            end
            if #parts > 0 then
                AddText(p, "|cffffa733" .. (BS:SpecName(tab) or (L.TREE .. tab)) .. ":|r  " .. table.concat(parts, ",  "), C.text)
            end
        end
    end
    if not data then
        AddText(p, L.THERE_IS_NO_PREPARED_DATA, C.yellow)
    end
end

local KIND_TEXT = {
    proc = L.A_PROC_BUTTON_APPEARS_IN,
    buff = L.WHEN_A_BUFF_RUNS_OUT,
    cd   = L.THE_COOLDOWN_BAR_SHOWS_YOUR,
}

local function FillEntries(p, kind)
    if BS.isRetail and kind ~= "buff" then
        AddHeader(p, L.NOT_AVAILABLE_IN_RETAIL)
        AddText(p, L.SINCE_MIDNIGHT_12_0_BUFFS ..
            L.AND_IN_WOW_FOREVER, C.yellow)
        return
    end
    AddText(p, KIND_TEXT[kind], C.dim)
    if BS:Locked() and not BS.isRetail and kind ~= "buff" then
        -- WoW Forever: im Kampf keine Anzeige, Reinigen-Raster aus, Procs werden nicht gelernt
        AddText(p, BS:LockedText(), C.yellow)
    end
    -- Einteilung "aktiv / weitere" einfrieren, solange die Seite offen ist: ein Häkchen soll den Eintrag
    -- nicht wegspringen lassen (sonst trifft der nächste Klick einen anderen Eintrag).
    -- Neu sortiert wird beim Seitenwechsel oder erneuten Öffnen.
    BS.listFreeze = BS.listFreeze or {}
    local freeze = BS.listFreeze[kind]
    if not freeze or freeze.spec ~= BS.mainSpec or freeze.class ~= BS.class then
        freeze = { spec = BS.mainSpec, class = BS.class, keys = {} }
        for _, e in ipairs(BS.entries) do
            if e.kind == kind then freeze.keys[e.key] = e.enabled end
        end
        BS.listFreeze[kind] = freeze
    end
    local active, other = {}, {}
    for _, e in ipairs(BS.entries) do
        if e.kind == kind and not e.data.enemyDispel then
            local inActive = freeze.keys[e.key]
            if inActive == nil then inActive = e.enabled end
            if inActive then tinsert(active, e) else tinsert(other, e) end
        end
    end
    AddHeader(p, L.ACTIVE_FOR .. (BS:SpecName(BS.mainSpec) or L.YOUR_SPEC))
    if #active == 0 then AddText(p, L.NO_ENTRIES_ACTIVE, C.dim) end
    for _, e in ipairs(active) do AddEntryRow(p, e) end
    if #other > 0 then
        AddHeader(p, L.MORE_NOT_ACTIVE)
        for _, e in ipairs(other) do AddEntryRow(p, e) end
    end
    if kind == "proc" and not BS:Locked() then
        AddText(p, L.BUFFSENTINEL_LEARNS_NEW_PROCS_E, C.dim)
    end
    -- Locked (WoW Forever): der Hinweis BS:LockedText() steht schon oben auf der Seite (auch "Procs werden nicht
    -- automatisch gelernt") – nicht ein zweites Mal wiederholen.
    if kind == "buff" and #BS:GroupEntries() > 0 then
        AddButton(p, L.OPEN_GROUP_GRID, 220, function() BS:ToggleRaster() end)
    end
end

function Fill.dispel(p)
    local db = BS.db
    AddHeader(p, L.DISPEL_GROUP_MEMBERS)
    if BS:Locked() and not BS.isRetail then
        AddText(p, BS:LockedText(), C.yellow)
        return
    end
    if BS.isRetail then
        AddText(p, L.IN_RETAIL_MIDNIGHT_DEBUFFS_ARE, C.yellow)
        return
    end
    AddText(p, L.IF_A_GROUP_MEMBER_HAS ..
        L.EACH_DISPEL_SPELL_IS_ON, C.dim)
    -- OPT-ALLE: die Schalter stehen genau einmal in den Optionen; hier öffnen Knöpfe den passenden Bereich (OPT e)
    AddText(p, string.format(L.OPT_HERE_SETTINGS, OnOff(db.dispel.friendly), OnOff((BS:SoundSetting("dispel")))), C.text)
    AddButton(p, L.OPT_GOTO_DISPLAY, 220, function() BS:OpenOptions("anzeige") end, 0, true)
    AddButton(p, L.OPT_GOTO_SOUNDS, 220, function() BS:OpenOptions("toene") end, 230)

    local lines = BS:DispelSummary()
    if #lines == 0 then
        AddText(p, L.YOUR_CLASS_SPEC_CANNOT_DISPEL, C.dim)
    else
        AddText(p, L.YOUR_DISPEL_SPELLS .. (BS:SpecName(BS.mainSpec) or "") .. "):", C.text)
        for _, l in ipairs(lines) do AddText(p, "•  " .. l, C.text, 10) end
    end
    AddText(p, L.IMPORTANT_RAID_DEBUFFS_E_G ..
        L.VAMPIRIC_TOUCH_MUTATING_INJECTION_ARE, C.dim)
    AddText(p, L.MOVE_ARRANGE_BUTTON_AT_THE, C.dim)

    AddHeader(p, L.PURGE_ENEMIES)
    AddText(p, L.IF_YOUR_TARGET_HAS_A ..
        L.THEREFORE_ALSO_WORKS_IN_THE, C.dim)
    local any = false
    for _, e in ipairs(BS.entries) do
        if e.data.enemyDispel then AddEntryRow(p, e); any = true end
    end
    if not any then
        AddText(p, L.YOUR_CLASS_HAS_NO_ABILITY, C.dim)
    end
end

function Fill.proc(p) FillEntries(p, "proc") end
function Fill.buff(p) FillEntries(p, "buff") end
function Fill.cd(p)   FillEntries(p, "cd") end

------------------------------------------------------------------------
-- Warntöne: Auswahlfenster mit allen Tönen
------------------------------------------------------------------------
local picker
local function ShowSoundPicker(kind)
    if not picker then
        local f = CreateFrame("Frame", "BuffSentinelSoundPicker", BS.optionsFrame)
        f:SetFrameStrata("FULLSCREEN_DIALOG")
        f:SetSize(600, 470)
        f:SetPoint("CENTER", BS.optionsFrame, "CENTER", 60, 0)
        f:EnableMouse(true)
        local bg = Tex(f, "BACKGROUND", 0.06, 0.07, 0.09, 0.98); bg:SetAllPoints()
        local line = Tex(f, "BORDER", 1, 0.65, 0.2, 1)
        line:SetPoint("TOPLEFT"); line:SetPoint("TOPRIGHT"); line:SetHeight(2)
        f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        f.title:SetPoint("TOPLEFT", 12, -10)
        f.hint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        f.hint:SetPoint("TOPLEFT", 12, -32)
        f.hint:SetText(L.LEFT_CLICK_SELECT_AND_LISTEN)
        f.hint:SetTextColor(0.7, 0.7, 0.75)
        local close = FlatButton(f, 26, 26, "×")
        close:SetPoint("TOPRIGHT", -6, -6)
        close:SetScript("OnClick", function() f:Hide() end)
        local scroll = CreateFrame("ScrollFrame", "BuffSentinelSoundPickerScroll", f, "UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT", 12, -52)
        scroll:SetPoint("BOTTOMRIGHT", -32, 12)
        f.child = CreateFrame("Frame", nil, scroll)
        f.child:SetSize(550, 10)
        scroll:SetScrollChild(f.child)
        f.buttons, f.heads = {}, {}
        tinsert(UISpecialFrames, "BuffSentinelSoundPicker")
        picker = f
    end
    local f = picker
    f.kind = kind
    BS.soundListCache = nil   -- neu einlesen (LibSharedMedia-Töne anderer Addons)
    local def = BS.SOUND_KIND_BY_KEY[kind]
    f.title:SetText(L.SOUND_FOR .. (def and def.name or kind))
    local _, cur = BS:SoundSetting(kind)
    for _, b in ipairs(f.buttons) do b:Hide() end
    for _, h in ipairs(f.heads) do h:Hide() end
    local GROUP_NAMES = { Spiel = L.GAME_SOUNDS, Datei = L.BELLS_DRUMS_EFFECTS,
        SharedMedia = L.LIBSHAREDMEDIA_OTHER_ADDONS, Eigener = L.CUSTOM_FILE }
    local y, col, lastGroup, nb, nh = 0, 0, nil, 0, 0
    for _, item in ipairs(BS:SoundList()) do
        if item.group ~= lastGroup then
            if col > 0 then y = y + 26; col = 0 end
            nh = nh + 1
            local h = f.heads[nh]
            if not h then h = f.child:CreateFontString(nil, "OVERLAY", "GameFontNormal"); f.heads[nh] = h end
            h:ClearAllPoints(); h:SetPoint("TOPLEFT", 0, -y - 4)
            h:SetText(GROUP_NAMES[item.group] or item.group); h:Show()
            y = y + 24
            lastGroup = item.group
        end
        nb = nb + 1
        local b = f.buttons[nb]
        if not b then
            b = FlatButton(f.child, 176, 22, "")
            b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
            f.buttons[nb] = b
        end
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", col * 184, -y)
        b:SetLabel(item.name)
        b:SetActive(item.key == cur)
        local key = item.key
        b:SetScript("OnClick", function(_, button)
            if key == "custom" then
                local _, _, custom = BS:SoundSetting(f.kind)
                BS:SetSoundSetting(f.kind, "sound", "custom", custom)
                f:Hide()
                return
            end
            BS:PreviewSound(key)
            if button ~= "RightButton" then
                BS:SetSoundSetting(f.kind, "sound", key)
                ShowSoundPicker(f.kind)
            end
        end)
        b:Show()
        col = col + 1
        if col == 3 then col = 0; y = y + 26 end
    end
    if col > 0 then y = y + 26 end
    f.child:SetHeight(y + 10)
    f:Show()
end

------------------------------------------------------------------------
-- OPT-ALLE (Entscheid des Nutzers 18.11.2026 10:27, Vorbild AHSentinel OPT-1): Optionen in Bereichen.
-- Links die Bereiche, rechts nur die Optionen des Bereichs: EINE Spalte, höchstens 12 Zeilen, kein Bildlauf. Jede Zeile: kurze
-- Beschriftung (höchstens ~28 Zeichen), rechts Schalter/Wert, Erklärung nur im Tooltip. Seltenes unter "Weitere" (eingeklappt),
-- "Standard"-Knopf je Bereich, Suchfeld oben über alle Bereiche. Jede gespeicherte Option genau EINMAL; alle Schlüssel wie bisher.
-- Bereiche werden erst beim Zeigen gebaut (Seite = Widget-Pool, nur die gezeigte Seite wird befüllt).
------------------------------------------------------------------------
local function Next(list, cur)
    for i, v in ipairs(list) do if v == cur then return list[i % #list + 1] end end
    return list[1]
end
local function Pct(v) return math.floor((v or 1) * 100 + 0.5) .. " %" end
local function Paladin() return BS.class == "PALADIN" end
local function NotRetail() return not BS.isRetail end

-- Zeilen-Arten: toggle (an/aus = ein Knopf), cycle (Knopf mit Wert, Klick = nächster), scale (– Wert +), sound (an/aus, Ton,
-- Anhören), action (ein Knopf). get/set wie gespeichert; def = Standardwert (für "Standard"); show = nur wenn true; on = bedienbar.
BS.OPT_AREAS = {
    { key = "aktiv", label = L.OPT_AREA_ACTIVE, rows = {
        { id = "zones.world",     kind = "toggle", label = L.OPEN_WORLD,          tip = L.OPT_TIP_ZONES, def = true,
          get = function() return BS.db.zones.world end,     set = function(v) BS.db.zones.world = v; BS:Refresh() end },
        { id = "zones.dungeon",   kind = "toggle", label = L.DUNGEONS,            tip = L.OPT_TIP_ZONES, def = true,
          get = function() return BS.db.zones.dungeon end,   set = function(v) BS.db.zones.dungeon = v; BS:Refresh() end },
        { id = "zones.raid",      kind = "toggle", label = L.RAIDS,               tip = L.OPT_TIP_ZONES, def = true,
          get = function() return BS.db.zones.raid end,      set = function(v) BS.db.zones.raid = v; BS:Refresh() end },
        { id = "zones.pvp",       kind = "toggle", label = L.BATTLEGROUNDS,       tip = L.OPT_TIP_ZONES, def = true,
          get = function() return BS.db.zones.pvp end,       set = function(v) BS.db.zones.pvp = v; BS:Refresh() end },
        { id = "zones.resting",   kind = "toggle", label = L.CAPITAL_CITIES_INNS, tip = L.OPT_TIP_ZONES, def = false,
          get = function() return BS.db.zones.resting end,   set = function(v) BS.db.zones.resting = v; BS:Refresh() end },
        { id = "zones.sanctuary", kind = "toggle", label = L.SANCTUARIES,         tip = L.OPT_TIP_ZONES, def = false,
          get = function() return BS.db.zones.sanctuary end, set = function(v) BS.db.zones.sanctuary = v; BS:Refresh() end },
        { id = "cdWorldCombatOnly", kind = "toggle", label = L.OPT_CD_WORLD_COMBAT, tip = L.COOLDOWN_BAR_IN_THE_OPEN, def = true,
          get = function() return BS.db.cdWorldCombatOnly end, set = function(v) BS.db.cdWorldCombatOnly = v end },
    } },
    { key = "toene", label = L.OPT_AREA_SOUNDS, rows = {
        -- 1–7: je Warnton-Art eine Zeile (an/aus, Ton, Anhören), gespeichert wie bisher (soundBase/soundSpecs)
        { id = "sound.horn" }, { id = "sound.buff" }, { id = "sound.proc" }, { id = "sound.cooldown" },
        { id = "sound.dispel" }, { id = "sound.dispel_imp" }, { id = "sound.bell" },
        { id = "hornEvery", kind = "cycle", label = L.OPT_HORN_EVERY, tip = L.OPT_TIP_HORN_EVERY, def = 5,
          get = function() return BS.db.hornEvery or 5 end, set = function(v) BS.db.hornEvery = v end,
          values = { 3, 5, 8, 10, 15, 20, 30, 60 }, text = function(v) return v .. " s" end },
        { id = "soundChannel", kind = "cycle", label = L.OPT_SOUND_CHANNEL, tip = L.THE_SOUND_CHANNEL_DECIDES_WHICH, def = "Master",
          get = function() return BS.db.soundChannel or "Master" end, set = function(v) BS.db.soundChannel = v end,
          values = function() local t = {} for _, c in ipairs(BS.SOUND_CHANNELS) do t[#t + 1] = c[1] end return t end,
          text = function(v) for _, c in ipairs(BS.SOUND_CHANNELS) do if c[1] == v then return c[2] end end return tostring(v) end },
        { id = "act.soundAll", kind = "action", more = true, label = L.OPT_SOUND_TO_ALL, button = L.OPT_DO, tip = L.APPLY_ALL_SOUNDS_TO_ALL,
          run = function() BS:SoundApplyToAll() end },
        { id = "act.soundSpec", kind = "action", more = true, label = L.OPT_SOUND_RESET_SPEC, button = L.OPT_DO, tip = L.RESET_SPEC_TO_DEFAULT,
          run = function() BS:SoundResetSpec() end },
    }, std = function() BS:SoundResetAll(); BS.db.hornEvery = 5; BS.db.soundChannel = "Master" end },
    { key = "anzeige", label = L.OPT_AREA_DISPLAY, rows = {
        { id = "scale", kind = "scale", label = L.OPT_SIZE_ALL, tip = L.BUTTON_SIZE_EACH_GROUP_SEPARATELY, def = 1,
          get = function() return BS.db.scale end, step = function(d) BS:ChangeScale(nil, d) end },
        { id = "groupScale.proc", kind = "scale", label = L.OPT_SIZE_PROCS, tip = L.BUTTON_SIZE_EACH_GROUP_SEPARATELY, def = 1,
          get = function() return BS.db.groupScale.proc end, step = function(d) BS:ChangeScale("proc", d) end },
        { id = "groupScale.buff", kind = "scale", label = L.OPT_SIZE_BUFFS, tip = L.BUTTON_SIZE_EACH_GROUP_SEPARATELY, def = 1,
          get = function() return BS.db.groupScale.buff end, step = function(d) BS:ChangeScale("buff", d) end },
        { id = "groupScale.cd", kind = "scale", label = L.OPT_SIZE_CDS, tip = L.BUTTON_SIZE_EACH_GROUP_SEPARATELY, def = 1,
          get = function() return BS.db.groupScale.cd end, step = function(d) BS:ChangeScale("cd", d) end },
        { id = "groupScale.dispel", kind = "scale", label = L.OPT_SIZE_DISPEL, tip = L.BUTTON_SIZE_EACH_GROUP_SEPARATELY, def = 1,
          get = function() return BS.db.groupScale.dispel end, step = function(d) BS:ChangeScale("dispel", d) end },
        { id = "cdTimer", kind = "toggle", label = L.OPT_CD_TIMER, tip = L.SHOW_REMAINING_TIME_ON_COOLDOWNS, def = true,
          get = function() return BS.db.cdTimer end, set = function(v) BS.db.cdTimer = v end },
        { id = "dispel.friendly", kind = "toggle", label = L.OPT_DISPEL_BAR, tip = L.SHOW_DISPEL_BAR_FOR_GROUP, def = true, show = NotRetail,
          get = function() return BS.db.dispel.friendly end, set = function(v) BS.db.dispel.friendly = v; BS:SettingsChanged() end },
        { id = "minimap.hide", kind = "toggle", label = L.OPT_MINIMAP, tip = L.SHOW_MINIMAP_BUTTON, def = true,
          get = function() return not BS.db.minimap.hide end, set = function(v) BS.db.minimap.hide = not v; BS:UpdateMinimapButton() end },
        { id = "act.arrange", kind = "action", label = L.OPT_ARRANGE, tip = L.ARRANGE_BUTTONS_SHOWS_ALL_YOUR,
          button = function() return BS.arrangeMode and L.STOP_ARRANGING or L.ARRANGE end, run = function() BS:ToggleArrangeMode() end },
        { id = "act.resetPos", kind = "action", label = L.OPT_RESET_POS, button = L.OPT_DO, tip = L.RESET_ALL_POSITIONS,
          run = function() BS:ResetPositions() end },
        { id = "act.testMode", kind = "action", more = true, dev = true, label = L.OPT_TEST_MODE, tip = L.TEST_MODE_DEV,
          button = function() return (BS.testMode and not BS.arrangeMode) and L.STOP_TEST or L.TEST_MODE end, run = function() BS:ToggleTestMode() end },
        { id = "act.testAll", kind = "action", more = true, dev = true, label = L.OPT_TEST_ALL, button = L.OPT_DO, tip = L.TEST_EVERYTHING,
          run = function() if BS.RunTestRoutine then BS:RunTestRoutine("alles") end end },
    }, std = function()
        BS:ResetScales(); BS.db.cdTimer = true; BS.db.dispel.friendly = true; BS.db.minimap.hide = false
        BS:SettingsChanged(); BS:UpdateMinimapButton()
    end },
    { key = "hilfen", label = L.OPT_AREA_HELPERS, rows = {
        { id = "readyCheck", kind = "toggle", label = L.OPT_READY_CHECK, tip = L.READY_CHECK_OPTION, def = true,
          get = function() return BS.gdb.readyCheck ~= false end, set = function(v) BS.gdb.readyCheck = v and true or false end },
        { id = "rfHint", kind = "toggle", label = L.OPT_RF_HINT, tip = L.RF_HINT_OPTION, def = true, show = Paladin,
          get = function() return BS.gdb.rfHint ~= false end, set = function(v) BS.gdb.rfHint = v and true or false end },
        { id = "restock", kind = "toggle", label = L.OPT_RESTOCK, tip = L.RESTOCK_OPTION, def = false,
          get = function() return BS.gdb.restock == true end,
          set = function(v) BS.gdb.restock = v and true or false; if BS.UpdateRestockButton then BS:UpdateRestockButton() end end },
        { id = "restockLimit", kind = "cycle", label = L.OPT_RESTOCK_LIMIT, tip = L.OPT_TIP_RESTOCK_LIMIT, def = 10000,
          get = function() return BS:RestockLimit() end,
          set = function(v) BS.gdb.restockLimit = v; if BS.UpdateRestockButton then BS:UpdateRestockButton() end end,
          values = function() return BS.RESTOCK_LIMITS end, text = function(v) return BS.MoneyText(v) end,
          on = function() return BS.gdb.restock == true end },
        { id = "cmdHint", kind = "toggle", label = L.OPT_CMD_HINT, tip = L.CMD_HINT_OPTION, def = true,
          get = function() return BS.gdb.cmdHint ~= false end, set = function(v) BS.gdb.cmdHint = v and true or false end },
        -- Hinweis 18.11. (Spieler ohne Testbefehle): was bisher nur per Befehl ging, auch hier – Befehle bleiben zusätzlich
        { id = "act.log", kind = "action", more = true, label = L.OPT_SHOW_LOG, button = L.OPT_DO, tip = L.OPT_TIP_SHOW_LOG,
          run = function() if BS.ShowDiag then BS.ShowDiag() end end },
        { id = "act.diag", kind = "action", more = true, label = L.OPT_SHOW_DIAG, button = L.OPT_DO, tip = L.OPT_TIP_SHOW_DIAG,
          run = function() if BS.ShowErrors then BS.ShowErrors() end end },
    } },
    { key = "teilen", label = L.OPT_AREA_SHARE, rows = {
        { id = "auto.enabled", kind = "toggle", label = L.OPT_AUTO_LEARN, tip = L.ADD_NEW_PROCS_AND_ABILITIES, def = true, show = NotRetail,
          get = function() return BS.gdb.auto.enabled end, set = function(v) BS:SetAutoLearn(v) end },
        { id = "auto.share", kind = "toggle", label = L.OPT_AUTO_SHARE, tip = L.SHARE_DISCOVERIES_WITH_OTHER_BUFFSENTINEL, def = true, show = NotRetail,
          get = function() return BS.gdb.auto.share end, set = function(v) BS.gdb.auto.share = v end },
        { id = "shareNames", kind = "toggle", label = L.OPT_SHARE_GROUP, tip = L.EXCHANGE_WITH_GUILD_AND_GROUP, def = true,
          get = function() return BS.gdb.shareNames end,
          set = function(v) BS.gdb.shareNames = v; if v then BS:RequestNames() end end },
        { id = "shareServer", kind = "toggle", label = L.OPT_SHARE_ALL, tip = L.EXCHANGE_WITH_ALL_BUFFSENTINEL_USERS, def = true,
          get = function() return BS.gdb.shareServer end, set = function(v) BS:SetShareServer(v) end,
          on = function() return BS.gdb.shareNames == true end },
        { id = "marketShare", kind = "toggle", label = L.OPT_MARKET_SHARE, tip = L.MARKET_SHARE_HINT, def = true,
          get = function() return BS:MarketShareOn() end, set = function(v) BS:SetMarketShare(v) end,
          on = function() return GoldSentinelMarkt ~= nil end },
        { id = "diagSend", kind = "toggle", more = true, label = L.OPT_DIAG_SEND, tip = L.OPT_TIP_DIAG_SEND, def = true,
          get = function() return BS.DiagSendEnabled() end, set = function(v) BS.SetDiagSend(v) end },
        { id = "act.sync", kind = "action", more = true, label = L.OPT_SYNC_CHECK, button = L.OPT_DO, tip = L.OPT_TIP_SYNC_CHECK,
          run = function() if BS.SyncTest then BS:SyncTest() end end },
    } },
}
-- Warnton-Zeilen aus BS.SOUND_KINDS füllen (Beschriftung = Name der Art)
do
    local kinds = {}
    for _, k in ipairs(BS.SOUND_KINDS) do kinds[k.key] = k end
    for _, row in ipairs(BS.OPT_AREAS[2].rows) do
        local key = row.id:match("^sound%.(.+)$")
        if key and kinds[key] then
            -- kurze Beschriftung (OPT c); der volle Name steht im Tooltip
            local short = ({ horn = L.OPT_SND_HORN, buff = L.OPT_SND_BUFF, proc = L.OPT_SND_PROC, cooldown = L.OPT_SND_CD,
                dispel = L.OPT_SND_DISPEL, dispel_imp = L.OPT_SND_DISPEL_IMP, bell = L.OPT_SND_BELL })[key]
            row.kind, row.sound, row.label = "sound", key, short or kinds[key].name
            row.tip = kinds[key].name .. "\n" .. L.OPT_TIP_SOUND
            row.get = function() return (BS:SoundSetting(key)) end
            row.set = function(v) BS:SetSoundSetting(key, "on", v) end
            row.def = kinds[key].on
        end
    end
end
BS.OPT_AREA_BY_KEY = {}
for _, a in ipairs(BS.OPT_AREAS) do BS.OPT_AREA_BY_KEY[a.key] = a end
BS.optMore = {}       -- je Bereich: "Weitere" aufgeklappt?

local function RowVisible(r)
    if r.show and not r.show() then return false end
    if r.dev and not BS:IsDev() then return false end
    return true
end
local function RowEnabled(r) return not r.on or r.on() ~= false end
BS.OptRowVisible = RowVisible                       -- für die Testroutine (T262: ohne Entwicklermodus sichtbar?)

-- Tooltip: Beschriftung fett, darunter die Erklärung
local function Tip(owner, r)
    if not GameTooltip then return end
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:SetText(r.label or "", 1, 0.82, 0)
    if r.tip and r.tip ~= "" then GameTooltip:AddLine(r.tip, 1, 1, 1, true) end
    if not RowEnabled(r) then GameTooltip:AddLine(L.OPT_TIP_LOCKED, 0.7, 0.7, 0.7, true) end
    GameTooltip:Show()
end
local function HideTip() if GameTooltip then GameTooltip:Hide() end end

-- Eine Zeile (Widget aus dem Pool der Seite): links Beschriftung, rechts die Bedienung
local OPT_ROW_H = 30
local function OptRow(p, r, areaLabel)
    local w = Acquire(p, "optrow", function(parent)
        local f = CreateFrame("Frame", nil, parent)
        f:SetSize(CONTENT_W, OPT_ROW_H - 2)
        f.bg = Tex(f, "BACKGROUND", 1, 1, 1, 0.035); f.bg:SetAllPoints()
        f.label = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        f.label:SetPoint("LEFT", 10, 0); f.label:SetWidth(250); f.label:SetJustifyH("LEFT")
        if f.label.SetWordWrap then f.label:SetWordWrap(false) end
        f.area = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        f.area:SetPoint("LEFT", 262, 0); f.area:SetWidth(90); f.area:SetJustifyH("LEFT")
        f.area:SetTextColor(BS.HINT_R, BS.HINT_G, BS.HINT_B)              -- BS-L1
        f.b1 = FlatButton(f, 90, 22, ""); f.b2 = FlatButton(f, 150, 22, ""); f.b3 = FlatButton(f, 70, 22, "")
        f.val = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.val:SetWidth(70); f.val:SetJustifyH("CENTER")
        f:EnableMouse(true)
        return f
    end)
    w:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
    w.label:SetFontObject("GameFontHighlight")
    w.label:SetText(r.label or "")
    -- OPT (c): zu lange Beschriftung (andere Sprachen) kleiner statt umbrechen
    if (w.label:GetStringWidth() or 0) > 250 and GameFontHighlightSmall then w.label:SetFontObject("GameFontHighlightSmall") end
    w.area:SetText(areaLabel or "")
    local enabled = RowEnabled(r)
    w:SetAlpha(enabled and 1 or 0.45)
    for _, b in ipairs({ w.b1, w.b2, w.b3 }) do
        b:Hide(); b:ClearAllPoints(); b:SetScript("OnClick", nil); b:SetActive(false)
        b:SetScript("OnEnter", function(s) Tip(s, r) end); b:SetScript("OnLeave", HideTip)
    end
    w.val:Hide(); w.val:ClearAllPoints()
    w:SetScript("OnEnter", function(s) Tip(s, r) end); w:SetScript("OnLeave", HideTip)
    local function after() BS:RefreshOptions() end
    if r.kind == "toggle" then
        local on = r.get() and true or false
        w.b1:SetSize(90, 22); w.b1:SetPoint("RIGHT", -6, 0); w.b1:SetLabel(OnOff(on)); w.b1:SetActive(on); w.b1:Show()
        w.b1:SetScript("OnClick", function() if RowEnabled(r) then r.set(not r.get()); after() end end)
    elseif r.kind == "cycle" then
        local list = type(r.values) == "function" and r.values() or r.values
        w.b2:SetSize(150, 22); w.b2:SetPoint("RIGHT", -6, 0); w.b2:SetLabel(r.text and r.text(r.get()) or tostring(r.get())); w.b2:Show()
        w.b2:SetScript("OnClick", function() if RowEnabled(r) then r.set(Next(list, r.get())); after() end end)
    elseif r.kind == "scale" then
        w.b3:SetSize(36, 22); w.b3:SetPoint("RIGHT", -6, 0); w.b3:SetLabel("+"); w.b3:Show()
        w.val:SetPoint("RIGHT", w.b3, "LEFT", -4, 0); w.val:SetText(Pct(r.get())); w.val:Show()
        w.b1:SetSize(36, 22); w.b1:SetPoint("RIGHT", w.val, "LEFT", -4, 0); w.b1:SetLabel("–"); w.b1:Show()
        w.b1:SetScript("OnClick", function() r.step(-0.1); after() end)
        w.b3:SetScript("OnClick", function() r.step(0.1); after() end)
    elseif r.kind == "sound" then
        local on, sound, custom = BS:SoundSetting(r.sound)
        w.b3:SetSize(70, 22); w.b3:SetPoint("RIGHT", -6, 0); w.b3:SetLabel(L.LISTEN); w.b3:Show()
        w.b3:SetScript("OnClick", function() BS:PreviewSound(sound, custom) end)
        local name = BS:SoundName(sound, custom)
        if #name > 20 then name = name:sub(1, 18) .. "…" end
        w.b2:SetSize(150, 22); w.b2:SetPoint("RIGHT", w.b3, "LEFT", -4, 0); w.b2:SetLabel(name); w.b2:Show()
        w.b2:SetScript("OnClick", function() ShowSoundPicker(r.sound) end)
        w.b1:SetSize(60, 22); w.b1:SetPoint("RIGHT", w.b2, "LEFT", -4, 0); w.b1:SetLabel(OnOff(on)); w.b1:SetActive(on); w.b1:Show()
        w.b1:SetScript("OnClick", function() r.set(not on); after() end)
    elseif r.kind == "action" then
        local t = type(r.button) == "function" and r.button() or r.button or L.OPT_DO
        w.b2:SetSize(150, 22); w.b2:SetPoint("RIGHT", -6, 0); w.b2:SetLabel(t); w.b2:Show()
        w.b2:SetScript("OnClick", function() r.run(); after() end)
    end
    -- für die Testroutine: Zeilen der Seite (Schalter wie bisher in p.toggles)
    p.optRows = p.optRows or {}
    p.optRows[#p.optRows + 1] = { row = w, def = r }
    if r.kind == "toggle" then
        local btn = w.b1
        p.toggles[#p.toggles + 1] = { row = { get = r.get, Click = function() local h = btn:GetScript("OnClick"); if h then h(btn) end end },
            label = r.label }
    end
    p.y = p.y + OPT_ROW_H
    return w
end
BS.OPT_ROW_H = OPT_ROW_H

-- Bereich zeigen: Zeilen (häufig zuerst), "Weitere" eingeklappt, "Standard"
local function FillArea(p, area)
    p.optRows = {}
    local main, more = {}, {}
    for _, r in ipairs(area.rows) do
        if RowVisible(r) then
            if r.more then more[#more + 1] = r else main[#main + 1] = r end
        end
    end
    for _, r in ipairs(main) do OptRow(p, r) end
    if #more > 0 then
        local open = BS.optMore[area.key]
        local b = AddButton(p, (open and "▾ " or "▸ ") .. string.format(L.OPT_MORE, #more), 200, function()
            BS.optMore[area.key] = not BS.optMore[area.key]; BS:RefreshOptions()
        end, 0, true)
        b:SetActive(open)
        p.y = p.y + OPT_ROW_H
        if open then for _, r in ipairs(more) do OptRow(p, r) end end
    end
    -- Standard: alle Werte dieses Bereichs auf den Auslieferungszustand
    p.y = p.y + 6
    AddButton(p, L.OPT_DEFAULT, 160, function()
        if area.std then area.std() end
        for _, r in ipairs(area.rows) do
            if r.def ~= nil and r.set and r.kind ~= "sound" and RowVisible(r) then r.set(r.def) end
        end
        BS:RefreshOptions()
    end)
end
BS.OPT_FILL_AREA = FillArea

for _, a in ipairs(BS.OPT_AREAS) do
    Fill[a.key] = function(p) FillArea(p, a) end
end
-- alter Name der Seite "Optionen": zeigt den ersten Bereich (Testroutine T114 nutzt Fill.opt)
Fill.opt = function(p) FillArea(p, BS.OPT_AREAS[1]) end

-- Suche über alle Bereiche (Beschriftung und Erklärung), Treffer mit Bereichsname
local MAX_HITS = 12
function Fill.search(p)
    local q = strlower(strtrim(BS.optSearch or ""))
    p.optRows = {}
    local n, shown = 0, 0
    for _, a in ipairs(BS.OPT_AREAS) do
        for _, r in ipairs(a.rows) do
            if RowVisible(r) then
                local hay = strlower((r.label or "") .. " " .. (r.tip or "") .. " " .. (a.label or ""))
                if q ~= "" and hay:find(q, 1, true) then
                    n = n + 1
                    if shown < MAX_HITS then OptRow(p, r, a.label); shown = shown + 1 end
                end
            end
        end
    end
    if n == 0 then AddText(p, L.OPT_NOTHING_FOUND, C.dim)
    elseif n > shown then AddText(p, string.format(L.OPT_MORE_HITS, n - shown), C.dim) end
end

-- Optionen direkt im passenden Bereich öffnen (OPT e: "wo eine Option gebraucht wird")
-- Seite im Einstellungsfenster des Spiels (Esc > Optionen > AddOns > BuffSentinel): Titel, Hinweis, Knopf zum eigenen Fenster
-- (Hinweis 18.11. "Spieler ohne Testbefehle", wie shared/vorlage). Einmal je Sitzung; alte Clients: InterfaceOptions_AddCategory.
function BS:CreateSettingsPage()
    if self.settingsPanel then return self.settingsPanel end
    local panel = CreateFrame("Frame")
    panel.name = "BuffSentinel"
    local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("BuffSentinel " .. tostring(self.version))
    local hint = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    hint:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
    hint:SetWidth(520)
    hint:SetJustifyH("LEFT")
    hint:SetText(L.GAME_SETTINGS_HINT)
    local btn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    btn:SetSize(180, 24)
    btn:SetPoint("TOPLEFT", hint, "BOTTOMLEFT", 0, -12)
    btn:SetText(L.OPT_OPEN_WINDOW)
    btn:SetScript("OnClick", function()
        if HideUIPanel and SettingsPanel and SettingsPanel.IsShown and SettingsPanel:IsShown() then HideUIPanel(SettingsPanel) end
        if HideUIPanel and InterfaceOptionsFrame and InterfaceOptionsFrame.IsShown and InterfaceOptionsFrame:IsShown() then
            HideUIPanel(InterfaceOptionsFrame)
        end
        BS:OpenOptions()
    end)
    panel.openButton = btn
    if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
        local category = Settings.RegisterCanvasLayoutCategory(panel, "BuffSentinel")
        Settings.RegisterAddOnCategory(category)
        self.settingsCategory = category
        panel.via = "Settings"
    elseif InterfaceOptions_AddCategory then
        InterfaceOptions_AddCategory(panel)
        panel.via = "InterfaceOptions"
    end
    self.settingsPanel = panel
    return panel
end

function BS:OpenOptions(area)
    if not self.optionsFrame then self:CreateOptions() end
    self.optSearch = ""
    if self.optionsFrame.search then self.optionsFrame.search:SetText("") end
    if not self.optionsFrame:IsShown() then self.listFreeze = nil; self.optionsFrame:Show() end
    self:ShowPage(area or "aktiv")
end

local function AutoRow(p, item)
    local row = Acquire(p, "autorow", function(parent)
        local f = CreateFrame("Frame", nil, parent)
        f:SetSize(CONTENT_W, 30)
        f.bg = Tex(f, "BACKGROUND", 1, 1, 1, 0.035); f.bg:SetAllPoints()
        f.icon = f:CreateTexture(nil, "ARTWORK"); f.icon:SetSize(24, 24); f.icon:SetPoint("LEFT", 4, 0)
        f.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.text:SetPoint("LEFT", f.icon, "RIGHT", 8, 0)
        f.text:SetWidth(CONTENT_W - 150); f.text:SetJustifyH("LEFT")
        f.btn = FlatButton(f, 100, 22, L.REMOVE); f.btn:SetPoint("RIGHT", -6, 0)
        return f
    end)
    row:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
    local r = item.rec
    local icon
    if item.kind == "proc" then
        local _, ic = BS.SpellInfo(r.auraId); icon = ic or r.icon
    else
        local _, ic = BS.SpellInfo(r.id); icon = ic
    end
    row.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")
    local what
    if item.kind == "proc" then
        what = "Proc  » " .. (r.spell or "?")
    else
        what = "Cooldown" .. (r.cd and (" " .. BS.AutoCdText(r.cd)) or "")
    end
    local src = (r.src == "net") and (L.FROM_PREFIX .. (r.from or "?")) or L.LEARNED_BY_YOU
    local specs = (r.specs and #r.specs > 0) and (BS:SpecList(r.specs) .. "  ·  ") or ""
    row.text:SetText(string.format("%s  |cff888888%s  ·  %s%s|r", item.name, what, specs, src))
    row.btn:SetScript("OnClick", function() BS:AutoRemove(item.kind, item.name) end)
    p.y = p.y + 34
end

function Fill.rec(p)
    local r = BS.gdb.recorder
    local auto = BS.gdb.auto
    AddHeader(p, L.AUTOMATIC_LEARNING)
    if BS.isRetail then
        AddText(p, L.IN_RETAIL_MIDNIGHT_BUFFS_AND, C.yellow)
    else
        AddText(p, L.IF_BUFFSENTINEL_MEETS_A_PROC ..
            BS.AUTO_PROC_MIN_HITS .. L.TIMES_BY_CASTING_THE_SAME ..
            L.AS_SOON_AS_YOU_CAST, C.dim, nil)
        AddText(p, string.format(L.OPT_LEARN_STATE, OnOff(auto.enabled), OnOff(auto.share)), C.text)
        AddButton(p, L.OPT_GOTO_SHARE, 220, function() BS:OpenOptions("teilen") end)

        local list, cands, nIgnore = BS:AutoList()
        AddHeader(p, L.LEARNED_AUTOMATICALLY_2 .. #list .. ")")
        if #list == 0 then AddText(p, L.NOTHING_LEARNED_YET, C.dim) end
        for _, item in ipairs(list) do AutoRow(p, item) end
        AddText(p, L.TURN_ON_AND_OFF_LIKE, C.dim)
        if #cands > 0 then
            local parts = {}
            for i, cnd in ipairs(cands) do
                if i > 6 then break end
                tinsert(parts, string.format("%s (%d/%d%s)", cnd.name, cnd.hits, BS.AUTO_PROC_MIN_HITS,
                    cnd.spell and (" » " .. cnd.spell) or ""))
            end
            AddText(p, L.BEING_WATCHED .. table.concat(parts, ",  "), C.text)
        end
        if nIgnore > 0 then
            AddButton(p, L.ALLOW_REMOVED_AGAIN .. nIgnore .. ")", 260, function() BS:AutoResetIgnore() end)
        end
    end

    AddHeader(p, L.RECORDING_MODE)
    AddText(p, L.LOGS_EVERY_NEW_BUFF_PROC, C.dim)
    local b = AddButton(p, r.enabled and L.STOP_RECORDING or L.START_RECORDING, 180, function()
        BS:SetRecorder(not r.enabled); BS:RefreshOptions()
    end, 0, true)
    b:SetActive(r.enabled)
    AddButton(p, L.CLEAR_LIST, 140, function() BS:ClearRecorder(); BS:RefreshOptions() end, 190)

    AddHeader(p, L.RECORDED .. #r.list .. ")")
    if #r.list == 0 then AddText(p, L.NOTHING_RECORDED_YET, C.dim) end
    for _, name in ipairs(r.list) do
        local rec = r.seen[name]
        if rec then
            local row = Acquire(p, "recrow", function(parent)
                local f = CreateFrame("Frame", nil, parent)
                f:SetSize(CONTENT_W, 30)
                f.bg = Tex(f, "BACKGROUND", 1, 1, 1, 0.035); f.bg:SetAllPoints()
                f.icon = f:CreateTexture(nil, "ARTWORK"); f.icon:SetSize(24, 24); f.icon:SetPoint("LEFT", 4, 0)
                f.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
                f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.text:SetPoint("LEFT", f.icon, "RIGHT", 8, 0)
                f.btn = FlatButton(f, 120, 22, ""); f.btn:SetPoint("RIGHT", -6, 0)
                return f
            end)
            row:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
            row.icon:SetTexture(rec.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
            row.text:SetText(string.format("%s  |cff888888ID %s  ·  %dx|r", rec.name, tostring(rec.id or "?"), rec.count or 0))
            if BS:HasCustom(name) then
                row.btn:SetLabel(L.ADDED); row.btn:SetActive(true)
                row.btn:SetScript("OnClick", nil)
            else
                row.btn:SetLabel(L.AS_PROC); row.btn:SetActive(false)
                row.btn:SetScript("OnClick", function() BS:AddCustomFromRecord(name) end)
            end
            p.y = p.y + 34
        end
    end

    AddHeader(p, L.OWN_PROCS)
    if #BS.db.custom == 0 then AddText(p, L.NO_OWN_PROCS_YET, C.dim) end
    for i, c in ipairs(BS.db.custom) do
        local row = Acquire(p, "customrow", function(parent)
            local f = CreateFrame("Frame", nil, parent)
            f:SetSize(CONTENT_W, 34)
            f.bg = Tex(f, "BACKGROUND", 1, 1, 1, 0.035); f.bg:SetAllPoints()
            f.icon = f:CreateTexture(nil, "ARTWORK"); f.icon:SetSize(24, 24); f.icon:SetPoint("LEFT", 4, 0)
            f.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
            f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.text:SetPoint("LEFT", f.icon, "RIGHT", 8, 0)
            f.text:SetWidth(150); f.text:SetJustifyH("LEFT")
            f.lbl = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.lbl:SetPoint("LEFT", 196, 0)
            f.lbl:SetText(L.CLICK_CASTS)
            f.edit = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
            f.edit:SetSize(160, 20); f.edit:SetPoint("LEFT", 270, 0); f.edit:SetAutoFocus(false)
            f.edit:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
            f.del = FlatButton(f, 90, 22, L.REMOVE); f.del:SetPoint("RIGHT", -6, 0)
            return f
        end)
        row:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
        local _, icon = BS.SpellInfo(c.auraId)
        row.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")
        row.text:SetText(c.aura)
        row.edit:SetText(c.spell or "")
        row.edit:SetScript("OnEnterPressed", function(s) s:ClearFocus(); BS:SetCustomSpell(i, s:GetText()) end)
        row.del:SetScript("OnClick", function() BS:RemoveCustom(i) end)
        p.y = p.y + 38
    end
    AddText(p, L.ENTER_A_SPELL_NAME_AND, C.dim)
end

------------------------------------------------------------------------
-- Hauptfenster
------------------------------------------------------------------------
-- Für die Testroutine: Verweis auf die Seiten-Funktionen (keine eigene Logik)
BS._test = BS._test or {}
BS._test.Fill = Fill

function BS:CreateOptions()
    local f = CreateFrame("Frame", "BuffSentinelOptions", UIParent)
    if BS.RegisterUI then BS.RegisterUI(f, "BuffSentinelOptions") end
    f:SetSize(800, 560)
    f:SetFrameStrata("DIALOG")
    self:RegisterWindow(f, "options", { "CENTER", "CENTER", 0, 0 })
    tinsert(UISpecialFrames, "BuffSentinelOptions")

    local bg = Tex(f, "BACKGROUND", 0.07, 0.08, 0.10, 0.97); bg:SetAllPoints()
    local header = Tex(f, "BORDER", 0.12, 0.13, 0.17, 1)
    header:SetPoint("TOPLEFT"); header:SetPoint("TOPRIGHT"); header:SetHeight(44)
    local line = Tex(f, "ARTWORK", 1, 0.65, 0.2, 1)
    line:SetPoint("TOPLEFT", 0, -44); line:SetPoint("TOPRIGHT", 0, -44); line:SetHeight(2)

    local data = self.ClassData[self.class]
    local logo = f:CreateTexture(nil, "ARTWORK")
    logo:SetSize(28, 28); logo:SetPoint("TOPLEFT", 12, -8)
    logo:SetTexture((data and data.icon) or "Interface\\Icons\\Ability_Warrior_BattleShout")
    logo:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", logo, "TOPRIGHT", 10, 1)
    title:SetText("BuffSentinel  |cff888888v" .. self.version .. "|r")
    local flavor = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    flavor:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -2)
    flavor:SetText(self.FLAVOR_NAMES[self.flavor] or self.flavor)
    flavor:SetTextColor(0.55, 0.55, 0.6)

    f.spec = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f.spec:SetPoint("RIGHT", f, "TOPRIGHT", -48, -22)

    local close = FlatButton(f, 30, 30, "×")
    close:SetPoint("TOPRIGHT", -8, -7)
    close.text:SetFontObject("GameFontHighlightLarge")
    close:SetScript("OnClick", function() f:Hide() end)
    f.close = close

    f.test = FlatButton(f, 100, 26, L.TEST_MODE)
    f.test:SetPoint("RIGHT", close, "LEFT", -10, 0)
    f.test:SetScript("OnClick", function() BS:ToggleTestMode() end)
    -- "Anordnen": eigene Buttons verschieben, Grösse, Abstand und Richtung einstellen
    f.arrange = FlatButton(f, 96, 26, L.ARRANGE)
    f.arrange:SetPoint("RIGHT", f.test, "LEFT", -8, 0)
    f.arrange:SetScript("OnClick", function() BS:ToggleArrangeMode() end)
    -- Spenden-Knopf links neben "Anordnen" (öffnet nur auf Klick)
    if self.Donate then
        f.donate = self.Donate.CreateButton(f, 104, 26)
        f.donate:SetPoint("RIGHT", f.arrange, "LEFT", -8, 0)
    end
    f.spec:ClearAllPoints()
    f.spec:SetPoint("RIGHT", f.donate or f.arrange, "LEFT", -12, 0)
    f.spec:SetWidth(180)
    f.spec:SetJustifyH("RIGHT")
    if f.spec.SetWordWrap then f.spec:SetWordWrap(false) end

    local side = Tex(f, "BORDER", 0.10, 0.11, 0.14, 1)
    side:SetPoint("TOPLEFT", 0, -46); side:SetPoint("BOTTOMLEFT"); side:SetWidth(170)

    local content = CreateFrame("Frame", nil, f)
    content:SetPoint("TOPLEFT", 170, -46)
    content:SetPoint("BOTTOMRIGHT")

    f.pages, f.tabs = {}, {}
    local y = -54
    local optHead
    for _, pg in ipairs(PAGES) do
        if not pg.hidden then
            if pg.opt and not optHead then
                optHead = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                optHead:SetPoint("TOPLEFT", 14, y - 4)
                optHead:SetText(L.OPTIONS)
                optHead:SetTextColor(C.accent[1], C.accent[2], C.accent[3])
                y = y - 20
            end
            local tab = FlatButton(f, 150, 30, pg.label)
            tab:SetPoint("TOPLEFT", 10, y)
            tab.text:ClearAllPoints(); tab.text:SetPoint("LEFT", 14, 0)
            tab:SetScript("OnClick", function()
                BS.optSearch = ""
                if f.search then f.search:SetText(""); f.search:ClearFocus() end
                BS:ShowPage(pg.key)
            end)
            f.tabs[pg.key] = tab
            y = y - 34
        end
        f.pages[pg.key] = NewPage(content, pg.key)
    end
    -- OPT (b): Suchfeld oben über alle Bereiche der Optionen
    local search = CreateFrame("EditBox", "BuffSentinelOptionsSearch", content, "InputBoxTemplate")
    search:SetSize(260, 22)
    search:SetPoint("TOPLEFT", 22, -10)
    search:SetAutoFocus(false)
    search.hint = search:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    search.hint:SetPoint("LEFT", 4, 0)
    search.hint:SetText(L.OPT_SEARCH)
    search.hint:SetTextColor(BS.HINT_R, BS.HINT_G, BS.HINT_B)   -- BS-L1: Platzhalter 6,4:1 statt 4,3:1
    search:SetScript("OnEscapePressed", function(s) s:SetText(""); s:ClearFocus() end)
    search:SetScript("OnEnterPressed", function(s) s:ClearFocus() end)
    search:SetScript("OnTextChanged", function(s)
        local t = s:GetText() or ""
        if t == "" then s.hint:Show() else s.hint:Hide() end
        if (BS.optSearch or "") == t then return end
        BS.optSearch = t
        if t ~= "" then
            if BS.currentPage ~= "search" then BS.searchFrom = BS.currentPage end
            BS:ShowPage("search")
        elseif BS.currentPage == "search" then
            BS:ShowPage(BS.searchFrom or "aktiv")
        end
    end)
    f.search = search

    local foot = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    foot:SetPoint("BOTTOMLEFT", 14, 12)
    foot:SetWidth(150); foot:SetJustifyH("LEFT")
    foot:SetText(L.RIGHT_CLICK_ON_THE_MINIMAP)
    foot:SetTextColor(BS.HINT_R, BS.HINT_G, BS.HINT_B)          -- BS-L1: Kontrast 6,4:1 statt 4,35:1

    f:Hide()
    self.optionsFrame = f
    self.currentPage = "skill"
end

function BS:ShowPage(key)
    if key == "zones" or key == "opt" then key = "aktiv" end   -- alte Namen der Seite "Optionen" -> erster Bereich
    if key ~= self.currentPage then self.listFreeze = nil end   -- Seitenwechsel: Listen neu sortieren
    self.currentPage = key
    self:RefreshOptions()
end

function BS:RefreshOptions()
    local f = self.optionsFrame
    if not f or not f:IsShown() then return end
    f.spec:SetText(L.SPEC_3 .. self:SpecText() .. "|r")
    -- Testmodus-Knopf nur für den Entwickler; sonst rückt "Anordnen" neben das Schliessen-Kreuz
    local dev = self:IsDev()
    f.arrange:ClearAllPoints()
    if dev then
        f.test:Show()
        f.arrange:SetPoint("RIGHT", f.test, "LEFT", -8, 0)
    else
        f.test:Hide()
        f.arrange:SetPoint("RIGHT", f.close, "LEFT", -10, 0)
    end
    f.test:SetActive(self.testMode and not self.arrangeMode)
    f.test:SetLabel((self.testMode and not self.arrangeMode) and L.STOP_TEST or L.TEST_MODE)
    f.arrange:SetActive(self.arrangeMode)
    f.arrange:SetLabel(self.arrangeMode and L.DONE or L.ARRANGE)
    for key, page in pairs(f.pages) do
        local on = key == self.currentPage
        if f.tabs[key] then f.tabs[key]:SetActive(on) end
        if on then
            page:Show()
            ResetPage(page)
            local ok, err = pcall(Fill[key], page)
            if not ok then
                AddText(page, L.ERROR_2 .. tostring(err), C.red)
                BS:CountError(L.OPTIONS_2 .. key, err)
            end
            FinishPage(page)
        else
            page:Hide()
        end
    end
end

function BS:ToggleOptions()
    if not self.optionsFrame then self:CreateOptions() end
    if self.optionsFrame:IsShown() then
        self.optionsFrame:Hide()
    else
        self.listFreeze = nil                                      -- neu geöffnet: Listen neu sortieren
        self:PlaceWindow("options")                                -- gespeicherte Lage (Ausweichen gilt nur für eine Anzeige)
        self.optionsFrame:Show()
        self:RefreshOptions()
        -- BS-K1 (Ingametest 23.11., T141): offenen Blizzard-Fenstern und Fenstern anderer GoldSentinel-Addons ausweichen
        if BS.UIAvoidOthers then pcall(BS.UIAvoidOthers, self.optionsFrame) end
    end
end

------------------------------------------------------------------------
-- Minimap-Button (Linksklick: Optionen, Rechtsklick: Gruppen-Raster, ziehen: verschieben)
------------------------------------------------------------------------
function BS:UpdateMinimapButton()
    local b = self.minimapButton
    if not b then return end
    if self.db.minimap.hide then b:Hide() return end
    b:Show()
    local angle = math.rad(self.db.minimap.angle or 220)
    local radius = (Minimap:GetWidth() / 2) + 6
    b:ClearAllPoints()
    b:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

function BS:CreateMinimapButton()
    local b = CreateFrame("Button", "BuffSentinelMinimapButton", Minimap)
    b:SetSize(31, 31)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    local data = self.ClassData[self.class]
    local icon = b:CreateTexture(nil, "BACKGROUND")
    icon:SetTexture((data and data.icon) or "Interface\\Icons\\Ability_Warrior_BattleShout")
    icon:SetSize(20, 20)
    icon:SetPoint("TOPLEFT", 7, -6)
    icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    local border = b:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT")

    b:SetScript("OnClick", function(_, button)
        if button == "RightButton" then
            BS:ToggleRaster()
        elseif IsShiftKeyDown() and BS:IsDev() then
            BS:ToggleTestMode()
        elseif IsShiftKeyDown() or (IsControlKeyDown and IsControlKeyDown()) then
            BS:ToggleArrangeMode()
        else
            BS:ToggleOptions()
        end
    end)
    b:SetScript("OnDragStart", function(s)
        s:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            cx, cy = cx / scale, cy / scale
            BS.db.minimap.angle = math.deg(math.atan2(cy - my, cx - mx))
            BS:UpdateMinimapButton()
        end)
    end)
    b:SetScript("OnDragStop", function(s) s:SetScript("OnUpdate", nil) end)
    b:SetScript("OnEnter", function(s)
        GameTooltip:SetOwner(s, "ANCHOR_LEFT")
        GameTooltip:AddLine("BuffSentinel", 1, 0.65, 0.2)
        GameTooltip:AddLine(L.SPEC_4 .. BS:SpecText(), 1, 1, 1)
        GameTooltip:AddLine(L.LEFT_CLICK_SETTINGS, 0.8, 0.8, 0.8)
        if BS:IsDev() then
            GameTooltip:AddLine(L.SHIFT_LEFT_CLICK_TEST_MODE, 0.8, 0.8, 0.8)
            GameTooltip:AddLine(L.CTRL_LEFT_CLICK_ARRANGE_BUTTONS, 0.8, 0.8, 0.8)
        else
            GameTooltip:AddLine(L.SHIFT_LEFT_CLICK_ARRANGE_BUTTONS, 0.8, 0.8, 0.8)
        end
        GameTooltip:AddLine(L.RIGHT_CLICK_GROUP_BUFFS, 0.8, 0.8, 0.8)
        GameTooltip:AddLine(L.DRAG_MOVE, 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)

    self.minimapButton = b
    self:UpdateMinimapButton()
end
