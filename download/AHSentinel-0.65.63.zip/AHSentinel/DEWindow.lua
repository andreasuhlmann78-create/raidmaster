if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - eigenes kleines Entzauber-Fenster (ab 0.65.37, Anweisung Sammelkauf E2, Entscheid des Nutzers 11:10)
--
-- Zeigt das nächste Teil (Symbol + Name, "noch N") mit den Knöpfen "Entzaubern", "Überspringen", "Statistik".
-- Reihenfolge: zuerst die über den Sammelkauf gekauften Teile (A.db.deBuys, noch nicht entzaubert), dann übrige
-- entzauberbare Teile aus den Taschen.
-- "Entzaubern" ist ein sicherer Knopf (SecureActionButtonTemplate, Makro "/cast Entzaubern" + "/use Tasche Platz"):
-- ein Klick = ein Teil. Das Makro beginnt mit "/stopmacro [combat]" - im Kampf passiert nichts, ohne dass im Kampf
-- ein Attribut geändert werden muss (kein Taint). Attribute werden nur ausserhalb des Kampfes gesetzt; vor jedem
-- Klick (PreClick) wird der Platz noch einmal geprüft.
-- Schutz: nie Teile in einem Ausrüstungs-Set, nie Quest-Gegenstände, nie Teile auf der Sperrliste (Rechtsklick auf
-- das Symbol: "nie entzaubern"), nur grün bis violett. Blaue/violette Teile und Teile, die sich deutlich besser
-- verkaufen, erst nach "Freigeben". Angelegte Teile sind nie in den Taschen und werden darum nie vorgeschlagen.
-- Ist Disenchantry geladen: kein automatisches Öffnen (einmaliger Hinweis), /ahs entzaubern öffnet trotzdem.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local DW = A.DEWindow or {}
A.DEWindow = DW

DW.DE_SPELL = 13262
DW.SELL_FACTOR = 1.5          -- Verkauf lohnt "deutlich" mehr: mehr als 1,5x der Entzauberungswert
DW.skipped = DW.skipped or {} -- [Tasche:Platz:ItemID] = true (in dieser Sitzung übersprungen)
DW.allowed = DW.allowed or {} -- [ItemID] = true (blau/violett bzw. Verkauf-lohnt freigegeben)

local function Settings() return A.db and A.db.settings or {} end
local function InCombat() return A:InCombat() end
local function API(name) return A:Global(name) end

-- ------------------------------------------------------------
-- Taschen lesen (Retail/Forever: C_Container; alte Clients: globale Funktionen)
-- ------------------------------------------------------------
function DW:NumSlots(bag)
    local C = _G.C_Container
    if C and C.GetContainerNumSlots then return C.GetContainerNumSlots(bag) or 0 end
    local f = API("GetContainerNumSlots")
    return f and f(bag) or 0
end

function DW:SlotInfo(bag, slot)
    local C = _G.C_Container
    if C and C.GetContainerItemInfo then
        local i = C.GetContainerItemInfo(bag, slot)
        if not i or not i.itemID then return nil end
        return { itemID = i.itemID, quality = i.quality, icon = i.iconFileID, link = i.hyperlink, noValue = i.hasNoValue }
    end
    local f = API("GetContainerItemInfo")
    if not f then return nil end
    local icon, _, _, quality, _, _, link = f(bag, slot)
    local id = link and tonumber(link:match("item:(%d+)"))
    if not id then return nil end
    return { itemID = id, quality = quality, icon = icon, link = link }
end

function DW:InEquipmentSet(bag, slot)
    local C = _G.C_Container
    local f = (C and C.GetContainerItemEquipmentSetInfo) or API("GetContainerItemEquipmentSetInfo")
    if not f then return false end
    local ok, inSet = pcall(f, bag, slot)
    return ok and inSet and true or false
end

function DW:IsQuestItem(bag, slot)
    local C = _G.C_Container
    local f = (C and C.GetContainerItemQuestInfo) or API("GetContainerItemQuestInfo")
    if not f then return false end
    local ok, a, b = pcall(f, bag, slot)
    if not ok then return false end
    if type(a) == "table" then return a.isQuestItem or (a.questID ~= nil) end
    return a and true or (b ~= nil)
end

-- ------------------------------------------------------------
-- Sperrliste und Freigaben
-- ------------------------------------------------------------
function DW:IsBlocked(itemID)
    return A.db and A.db.deBlock and A.db.deBlock[itemID] and true or false
end
function DW:ToggleBlock(itemID)
    if not (A.db and itemID) then return nil end
    A.db.deBlock = A.db.deBlock or {}
    A.db.deBlock[itemID] = not A.db.deBlock[itemID] or nil
    self:Refresh()
    return self:IsBlocked(itemID)
end
function DW:ConfirmRare() return Settings().deConfirmRare ~= false end
function DW:Allow(itemID) self.allowed[itemID] = true; self:Refresh() end

-- Grund, warum ein Teil erst freigegeben werden muss: "rare" (blau/violett) oder "sell" (Verkauf lohnt deutlich mehr)
function DW:NeedsConfirm(itemID, quality)
    if self.allowed[itemID] then return nil end
    if self:ConfirmRare() and (quality or 0) >= 3 then return "rare" end
    local deNet, sell = self:Values(itemID)
    if deNet and sell and sell > deNet * self.SELL_FACTOR then return "sell", deNet, sell end
    return nil
end

-- Entzauberungswert (nach Gebühren) und realer Verkaufswert eines Teils (beides Kupfer, nil = unbekannt)
function DW:Values(itemID)
    local D = A.Disenchant
    local deNet
    if D and D.DealValue then
        local _, net = D:DealValue(itemID)
        deNet = net
    end
    local sell = A.RealValue and A:RealValue(itemID, 1) or nil
    return deNet, sell
end

-- ------------------------------------------------------------
-- Warteschlange: gekaufte Teile zuerst, dann übrige
-- ------------------------------------------------------------
-- offene Sammelkauf-Teile je ItemID (gekauft, noch nicht entzaubert)
function DW:OpenBuys()
    local out = {}
    for _, e in ipairs(A.db and A.db.deBuys or {}) do
        if not e.done and e.itemID then out[e.itemID] = (out[e.itemID] or 0) + 1 end
    end
    return out
end

function DW:Queue()
    local D = A.Disenchant
    local bought = self:OpenBuys()
    local list = {}
    if not D then return list end
    for bag = 0, (_G.NUM_BAG_SLOTS or 4) do
        for slot = 1, self:NumSlots(bag) do
            local s = self:SlotInfo(bag, slot)
            if s and D:Prior(s.itemID) and (s.quality or 2) >= 2 and (s.quality or 2) <= 4
                and not self:IsBlocked(s.itemID) and not self.skipped[bag .. ":" .. slot .. ":" .. s.itemID]
                and not self:InEquipmentSet(bag, slot) and not self:IsQuestItem(bag, slot) then
                s.bag, s.slot = bag, slot
                if (bought[s.itemID] or 0) > 0 then
                    s.bought = true
                    bought[s.itemID] = bought[s.itemID] - 1
                end
                list[#list + 1] = s
            end
        end
    end
    table.sort(list, function(a, b)
        if (a.bought and 1 or 0) ~= (b.bought and 1 or 0) then return a.bought == true end
        if a.bag ~= b.bag then return a.bag < b.bag end
        return a.slot < b.slot
    end)
    return list
end

function DW:Current()
    local q = self:Queue()
    return q[1], #q, q
end

function DW:Skip()
    local cur = self:Current()
    if cur then self.skipped[cur.bag .. ":" .. cur.slot .. ":" .. cur.itemID] = true end
    self:Refresh()
    return cur
end

-- ------------------------------------------------------------
-- Makro des sicheren Knopfs
-- ------------------------------------------------------------
function DW:SpellName()
    local n
    if _G.C_Spell and _G.C_Spell.GetSpellName then n = _G.C_Spell.GetSpellName(self.DE_SPELL) end
    if not n then
        local f = API("GetSpellInfo")
        if f then n = f(self.DE_SPELL) end
    end
    return n
end

-- Makrotext für ein Teil (nil = nichts zu tun / gesperrt)
function DW:MacroFor(item)
    if not item then return nil end
    local spell = self:SpellName()
    if not spell then return nil end
    return "/stopmacro [combat]\n/cast " .. spell .. "\n/use " .. item.bag .. " " .. item.slot
end

-- Attribute setzen - nur ausserhalb des Kampfes (sonst später, PLAYER_REGEN_ENABLED)
function DW:Arm(item)
    local b = self.frame and self.frame.deBtn
    if not b then return false end
    if InCombat() then self.dirty = true; return false end
    local macro = item and not self:NeedsConfirm(item.itemID, item.quality) and self:MacroFor(item) or nil
    b:SetAttribute("type", macro and "macro" or nil)
    b:SetAttribute("macrotext", macro)
    b.armed = item and macro and { bag = item.bag, slot = item.slot, itemID = item.itemID } or nil
    return macro ~= nil
end

-- vor dem Klick: liegt am Platz noch das erwartete Teil? Sonst Makro leeren (nur ausserhalb des Kampfes möglich;
-- im Kampf hält "/stopmacro [combat]" das Makro an)
function DW:PreClick()
    local b = self.frame and self.frame.deBtn
    local a = b and b.armed
    if not a or InCombat() then return end
    local s = self:SlotInfo(a.bag, a.slot)
    if not s or s.itemID ~= a.itemID then
        b:SetAttribute("type", nil)
        b:SetAttribute("macrotext", nil)
        b.armed = nil
        if C_Timer and C_Timer.After then C_Timer.After(0, function() DW:Refresh() end) end
        return
    end
    -- für das Lernen der Ergebnisse (Disenchant.lua): dieses Teil wird gleich entzaubert
    if A.Disenchant and A.Disenchant.NoteCandidate then A.Disenchant:NoteCandidate(a.itemID) end
    self.lastClick = { itemID = a.itemID, bag = a.bag, slot = a.slot }
end

-- ------------------------------------------------------------
-- Statistik (verbindet sich mit der Abrechnung in der Buchhaltung, E4)
-- ------------------------------------------------------------
local function DayStart(t)
    local d = date("*t", t)
    d.hour, d.min, d.sec = 0, 0, 0
    return time(d)
end

function DW:Stats(now)
    now = now or time()
    local today = DayStart(now)
    local s = { today = 0, total = 0, mats = {}, value = 0, valueToday = 0 }
    local D = A.Disenchant
    for _, e in ipairs(A.db and A.db.deLog or {}) do
        s.total = s.total + 1
        local isToday = (e.t or 0) >= today
        if isToday then s.today = s.today + 1 end
        for _, m in ipairs(e.loot or {}) do
            s.mats[m[1]] = (s.mats[m[1]] or 0) + (m[2] or 1)
            local p = D and D.MatPrice and D:MatPrice(m[1]) or nil
            if p then
                s.value = s.value + p * (m[2] or 1)
                if isToday then s.valueToday = s.valueToday + p * (m[2] or 1) end
            end
        end
    end
    return s
end

function DW:StatsText()
    local s = self:Stats()
    local lines = {
        string.format(L["Entzaubert heute: %d · gesamt: %d"], s.today, s.total),
        string.format(L["Wert der Materialien: heute %s · gesamt %s"], A:FormatMoney(math.floor(s.valueToday + 0.5)),
            A:FormatMoney(math.floor(s.value + 0.5))),
    }
    local mats = {}
    for id, n in pairs(s.mats) do mats[#mats + 1] = { id = id, n = n } end
    table.sort(mats, function(a, b) if a.n ~= b.n then return a.n > b.n end return a.id < b.id end)
    for k = 1, math.min(6, #mats) do
        lines[#lines + 1] = string.format("  %dx %s", mats[k].n, A:GetItemName(mats[k].id) or ("#" .. mats[k].id))
    end
    if #mats == 0 then lines[#lines + 1] = L["Noch keine Entzauberungen gezählt."] end
    return table.concat(lines, "\n")
end

-- ------------------------------------------------------------
-- Fenster
-- ------------------------------------------------------------
function DW:Build()
    if self.frame then return self.frame end
    if InCombat() then return nil end            -- sicherer Knopf nur ausserhalb des Kampfes anlegen
    local UI = A.UI
    local C = UI.C
    local f = CreateFrame("Frame", "AHSentinelDisenchantFrame", UIParent)
    if A.RegisterUI then A.RegisterUI(f, "Entzauber-Fenster") end
    f:SetSize(280, 128)
    f:SetFrameStrata("DIALOG")
    f:SetClampedToScreen(true)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self) if not InCombat() then self:StartMoving() end end)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        if A.db then A.db.settings.deWindowPos = { p or "CENTER", rp or "CENTER", x or 0, y or 0 } end
    end)
    UI:Box(f, C.bg, C.frameEdge, UI:IsClassic() and 2 or 1)
    f:Hide()
    local pos = Settings().deWindowPos
    if type(pos) == "table" and pos[1] then
        f:SetPoint(pos[1], UIParent, pos[2] or pos[1], pos[3] or 0, pos[4] or 0)
    else
        f:SetPoint("CENTER", UIParent, "CENTER", 260, 80)
    end

    f.title = UI:Label(f, "|cff00d1d1AHSentinel|r  " .. L["Entzaubern"], "GameFontNormal", C.accent)
    f.title:SetPoint("TOPLEFT", 12, -10)
    f.close = UI:CloseButton(f, function() DW:Hide() end)
    f.close:SetPoint("TOPRIGHT", -4, -4)

    -- Symbol: Rechtsklick = Sperrliste
    f.icon = CreateFrame("Button", nil, f)
    f.icon:SetSize(34, 34)
    f.icon:SetPoint("TOPLEFT", 12, -32)
    f.icon.tex = f.icon:CreateTexture(nil, "ARTWORK")
    f.icon.tex:SetAllPoints()
    f.icon:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    f.icon:SetScript("OnClick", function(_, button)
        local cur = DW:Current()
        if button == "RightButton" and cur then
            local on = DW:ToggleBlock(cur.itemID)
            A:Print(string.format(on and L["%s: nie entzaubern (Sperrliste)."] or L["%s: wieder erlaubt."], cur.link or A:GetItemName(cur.itemID) or "?"))
        end
    end)
    f.icon:SetScript("OnEnter", function(self)
        local cur = DW:Current()
        if not (cur and GameTooltip) then return end
        A.UI:AnchorTooltip(self)
        if cur.link and GameTooltip.SetHyperlink then pcall(GameTooltip.SetHyperlink, GameTooltip, cur.link) end
        GameTooltip:AddLine(L["Rechtsklick: nie entzaubern (Sperrliste)"], 0.6, 0.8, 1)
        GameTooltip:Show()
    end)
    f.icon:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)

    f.name = UI:Label(f, "", "GameFontHighlight")
    f.name:SetPoint("TOPLEFT", f.icon, "TOPRIGHT", 8, -1)
    f.name:SetWidth(210)
    f.count = UI:Label(f, "", "GameFontHighlightSmall", C.textDim)
    f.count:SetPoint("TOPLEFT", f.name, "BOTTOMLEFT", 0, -4)
    f.hint = UI:Label(f, "", "GameFontHighlightSmall", C.accent)
    f.hint:SetPoint("TOPLEFT", 12, -72)
    f.hint:SetWidth(180)

    f.allowBtn = UI:Button(f, L["Freigeben"], 78, 20, function()
        local cur = DW:Current()
        if cur then DW:Allow(cur.itemID) end
    end)
    f.allowBtn:SetPoint("TOPRIGHT", -10, -70)
    f.allowBtn.tooltip = L["Dieses Teil trotzdem entzaubern (gilt für diese Sitzung)."]

    -- sicherer Knopf
    local b = CreateFrame("Button", nil, f, "SecureActionButtonTemplate")
    b:SetSize(100, 24)
    b:SetPoint("BOTTOMLEFT", 10, 10)
    UI:Box(b, C.accentDim or C.panel2, C.border)
    b.label = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.label:SetPoint("CENTER")
    b.label:SetText(L["Entzaubern"])
    if b.RegisterForClicks then pcall(b.RegisterForClicks, b, "AnyUp", "AnyDown") end
    b:HookScript("PreClick", function() DW:PreClick() end)
    b:SetScript("OnEnter", function(self)
        if not GameTooltip then return end
        A.UI:AnchorTooltip(self)
        GameTooltip:SetText(L["Ein Klick = ein Teil entzaubern. Im Kampf gesperrt."], 1, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
    f.deBtn = b

    f.skipBtn = UI:Button(f, L["Überspringen"], 82, 24, function() DW:Skip() end)
    f.skipBtn:SetPoint("LEFT", b, "RIGHT", 6, 0)
    f.statsBtn = UI:Button(f, L["Statistik"], 72, 24, function() DW:ToggleStats() end)
    f.statsBtn:SetPoint("LEFT", f.skipBtn, "RIGHT", 6, 0)

    -- Statistik: eigener Rahmen am UIParent (nicht am geschützten Fenster), damit er auch im Kampf auf/zu geht
    local st = CreateFrame("Frame", nil, UIParent)
    st:SetSize(280, 120)
    st:SetPoint("TOPLEFT", f, "BOTTOMLEFT", 0, -2)
    st:SetFrameStrata("DIALOG")
    UI:Box(st, C.bg, C.frameEdge, 1)
    st.text = UI:Label(st, "", "GameFontHighlightSmall")
    st.text:SetPoint("TOPLEFT", 10, -8)
    st.text:SetWidth(260)
    st:Hide()
    f.stats = st

    f:SetScript("OnHide", function() st:Hide() end)
    self.frame = f
    return f
end

function DW:ToggleStats()
    local f = self.frame
    if not f then return end
    if f.stats:IsShown() then f.stats:Hide() else f.stats.text:SetText(self:StatsText()); f.stats:Show() end
end

function DW:Refresh()
    local f = self.frame
    if not f then return end
    local cur, n = self:Current()
    if cur then
        f.icon.tex:SetTexture(cur.icon)
        f.name:SetText(cur.link or A:GetItemName(cur.itemID) or ("#" .. cur.itemID))
        local text = string.format(L["noch %d zum Entzaubern"], n)
        if cur.bought then text = text .. "  ·  " .. L["gekauft"] end
        f.count:SetText(text)
        local why, deNet, sell = self:NeedsConfirm(cur.itemID, cur.quality)
        if why == "rare" then
            f.hint:SetText(L["Blau/violett: erst freigeben."])
        elseif why == "sell" then
            f.hint:SetText(string.format(L["Verkaufen lohnt mehr: %s statt %s."], A:FormatMoney(sell), A:FormatMoney(deNet)))
        elseif InCombat() then
            f.hint:SetText(L["Im Kampf gesperrt."])
        else
            f.hint:SetText("")
        end
        f.allowBtn:SetShown(why ~= nil)
        f.skipBtn:SetActive(true)
    else
        f.icon.tex:SetTexture(nil)
        f.name:SetText(L["Nichts zum Entzaubern."])
        f.count:SetText("")
        f.hint:SetText("")
        f.allowBtn:Hide()
        f.skipBtn:SetActive(false)
    end
    local armed = self:Arm(cur)
    f.deBtn.label:SetTextColor(unpack((armed and not InCombat()) and A.UI.C.text or A.UI.C.textDim))
    if f.stats:IsShown() then f.stats.text:SetText(self:StatsText()) end
end

function DW:Show()
    local f = self:Build()
    if not f then A:Print(L["Im Kampf gesperrt."]); return false end
    if InCombat() then self.wantShow = true; A:Print(L["Im Kampf gesperrt."]); return false end
    f:Show()
    self:Refresh()
    return true
end

function DW:Hide()
    if not self.frame then return end
    if InCombat() then self.wantHide = true; return end
    self.frame:Hide()
end

function DW:Toggle()
    if self.frame and self.frame:IsShown() then self:Hide() else self:Show() end
end

-- nach dem Sammelkauf (AH zu, mindestens ein Teil gekauft) einmal je Sitzung öffnen
function DW:MaybeAutoOpen()
    local DEB = A.DEBuy
    if not (DEB and DEB.session and DEB.session.bought > 0) or self.autoOpened then return false end
    self.autoOpened = true
    if A.DisenchantryLoaded and A:DisenchantryLoaded() then
        if not Settings().deDisenchantryHint and A.db then
            A.db.settings.deDisenchantryHint = true
            A:Print(L["Disenchantry ist geladen - das AHSentinel-Entzauber-Fenster öffnet sich nicht von selbst (/ahs entzaubern)."])
        end
        return false
    end
    return self:Show()
end

-- ein Ergebnis wurde gelernt (Disenchant.lua): Sammelkauf-Teil abhaken, Fenster auffrischen
function DW:OnDisenchanted(itemID)
    self:Refresh()
end

local ev = CreateFrame("Frame")
DW.evt = ev
for _, e in ipairs({ "PLAYER_REGEN_ENABLED", "PLAYER_REGEN_DISABLED", "BAG_UPDATE_DELAYED" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_REGEN_ENABLED" then
        if DW.wantHide then DW.wantHide = nil; if DW.frame then DW.frame:Hide() end end
        if DW.wantShow then DW.wantShow = nil; DW:Show() end
        DW.dirty = nil
        DW:Refresh()
    elseif event == "PLAYER_REGEN_DISABLED" then
        if DW.frame and DW.frame:IsShown() then
            DW.frame.hint:SetText(L["Im Kampf gesperrt."])
            DW.frame.deBtn.label:SetTextColor(unpack(A.UI.C.textDim))
        end
    elseif DW.frame and DW.frame:IsShown() then
        DW:Refresh()
    end
end)
A:On("AH_STATE", function()
    if not A:IsAHOpen() then DW:MaybeAutoOpen() end
end)
A:On("DE_LEARNED", function(itemID) DW:OnDisenchanted(itemID) end)
