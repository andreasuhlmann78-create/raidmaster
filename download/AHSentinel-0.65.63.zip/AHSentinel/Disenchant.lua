if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 0.63 - Entzauberungswert (Classic), lernt mit und teilt
--
-- Erwarteter Wert beim Entzaubern eines grünen, blauen oder epischen
-- Rüstungs- oder Waffenteils: Summe aus Wahrscheinlichkeit x Ø Menge
-- x Marktwert des Materials. Startwerte sind die bekannten
-- Classic-Richtwerte. Jede eigene Entzauberung wird erkannt und
-- gespeichert - die Werte nähern sich so immer mehr der Realität
-- auf deinem Server an. Über den Preis-Sync teilen alle Spieler mit
-- AHSentinel ihre Ergebnisse - so kommen schnell genug Daten zusammen.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
-- Retail 12.x: die alten Item-/Zauber-Funktionen gibt es nur noch in C_Item / C_Spell
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local GetSpellInfo = GetSpellInfo or (C_Spell and C_Spell.GetSpellName)
local A = AHAnalyzerPro
local L = A.L

local D = {}
A.Disenchant = D

-- Material
local STRANGE, SOUL, VISION, DREAM, ILLUSION = 10940, 11083, 11137, 11176, 16204
local LMAGIC, GMAGIC, LASTRAL, GASTRAL = 10938, 10939, 10998, 11082
local LMYSTIC, GMYSTIC, LNETHER, GNETHER, LETERNAL, GETERNAL = 11134, 11135, 11174, 11175, 16202, 16203
local SGLIMMER, LGLIMMER, SGLOW, LGLOW = 10978, 11084, 11138, 11139
local SRADIANT, LRADIANT, SBRILLIANT, LBRILLIANT, NEXUS = 11177, 11178, 14343, 14344, 20725

-- ------------------------------------------------------------
-- Entzauber-Tabelle nach Disenchantry 1.1.2 (DisenchantResults.lua), MIT-Lizenz, Copyright (c) 2026 x_Raven_x
-- (Lizenztext: LICENSE-Disenchantry.txt). Quelle dort: warcraft.wiki.gg "Disenchanting tables" (Classic,
-- Itemstufe vor dem Squish). Gruppen nach ITEMSTUFE (nicht nach benötigter Stufe) - wie Disenchantry und die Tabelle.
-- Forever: grüne Waffen Itemstufe 21-30 geben Grosse Magieessenz (Wowhead-Forever-Daten, laut Disenchantry).
-- ------------------------------------------------------------
-- Grün: { bis Itemlevel, Staub, Ø Staub, Essenz, Ø Essenz, Splitter, Staub min, max, Essenz min, max }
local UNCOMMON = {
    { 15, STRANGE, 1.5, LMAGIC, 1.5, SGLIMMER, 1, 2, 1, 2 },
    { 20, STRANGE, 2.5, GMAGIC, 1.5, SGLIMMER, 2, 3, 1, 2 },
    { 25, STRANGE, 5.0, LASTRAL, 1.5, SGLIMMER, 4, 6, 1, 2 },
    { 30, SOUL, 1.5, GASTRAL, 1.5, LGLIMMER, 1, 2, 1, 2 },
    { 35, SOUL, 3.5, LMYSTIC, 1.5, SGLOW, 2, 5, 1, 2 },
    { 40, VISION, 1.5, GMYSTIC, 1.5, LGLOW, 1, 2, 1, 2 },
    { 45, VISION, 3.5, LNETHER, 1.5, SRADIANT, 2, 5, 1, 2 },
    { 50, DREAM, 1.5, GNETHER, 1.5, LRADIANT, 1, 2, 1, 2 },
    { 55, DREAM, 3.5, LETERNAL, 1.5, SBRILLIANT, 2, 5, 1, 2 },
    { 60, ILLUSION, 1.5, GETERNAL, 1.5, LBRILLIANT, 1, 2, 1, 2 },
    { 65, ILLUSION, 3.5, GETERNAL, 2.5, LBRILLIANT, 2, 5, 2, 3 },
}
-- Blau: { bis Itemlevel, Splitter }
local RARE = {
    { 25, SGLIMMER }, { 30, LGLIMMER }, { 35, SGLOW }, { 40, LGLOW },
    { 45, SRADIANT }, { 50, LRADIANT }, { 55, SBRILLIANT }, { 80, LBRILLIANT },
}
-- Episch: { ab, bis Itemlevel, Material, Ø Menge }
local EPIC = {
    { 40, 45, SRADIANT, 3, 2, 4 }, { 46, 50, LRADIANT, 3, 2, 4 }, { 51, 55, SBRILLIANT, 3, 2, 4 },
    { 56, 60, NEXUS, 1, 1, 1 }, { 61, 88, NEXUS, 1.5, 1, 2 },
}

-- Verhältnis bei grünen Items (Rüstung): Staub / Essenz / Splitter (Standard; je Stufe siehe GREEN_P)
D.GREEN_DUST, D.GREEN_ESSENCE, D.GREEN_SHARD = 0.75, 0.20, 0.05

-- Chancen je grüner Stufe (Quelle: warcraft.wiki.gg "Disenchanting tables", Classic; Befund im Spiel 9. Nov. 09:04:
-- Itemstufe bis 15 gibt KEINEN Splitter). a = Rüstung, w = Waffe: { Staub, Essenz, Splitter }
D.GREEN_P = {
    [1] = { a = { 0.80, 0.20, 0 },    w = { 0.20, 0.80, 0 } },       -- bis 15: nur Staub / Essenz
    [3] = { a = { 0.75, 0.15, 0.10 }, w = { 0.15, 0.75, 0.10 } },    -- 21-25: 10 % Splitter
    [9] = { a = { 0.75, 0.20, 0.05 }, w = { 0.22, 0.75, 0.03 } },    -- 51-55
    [10] = { a = { 0.75, 0.20, 0.05 }, w = { 0.22, 0.75, 0.03 } },   -- 56-60
    [11] = { a = { 0.75, 0.20, 0.05 }, w = { 0.22, 0.75, 0.03 } },   -- 61-65
}
-- Startwerte einer grünen Stufe k (Tabellenzeile b), Waffe ja/nein
function D:GreenPrior(k, b, weapon)
    local p = self.GREEN_P[k]
    local c = p and (weapon and p.w or p.a) or (weapon and { D.GREEN_ESSENCE, D.GREEN_DUST, D.GREEN_SHARD } or { D.GREEN_DUST, D.GREEN_ESSENCE, D.GREEN_SHARD })
    -- Forever: grüne Waffen Itemstufe 21-30 (Stufen 3 und 4) geben Grosse Magieessenz (Disenchantry)
    local ess = b[4]
    if weapon and (k == 3 or k == 4) and A:IsForever() then ess = GMAGIC end
    -- { itemID, Chance, Ø Menge, Menge min, Menge max }
    local out = { { b[2], c[1], b[3], b[7], b[8] }, { ess, c[2], b[5], b[9], b[10] } }
    if c[3] > 0 and b[6] then table.insert(out, { b[6], c[3], 1, 1, 1 }) end
    return out
end

-- nicht entzauberbar, obwohl Rüstung
local NOT_DE = { INVTYPE_BODY = true, INVTYPE_TABARD = true, INVTYPE_BAG = true, INVTYPE_AMMO = true, INVTYPE_QUIVER = true, [""] = true }

-- Startwerte aus der Tabelle: Ertrag { { itemID, Chance (0-1), Ø Menge }, ... }, Gruppe, oder nil.
-- Gruppe = Qualität : Itemlevel-Stufe : Waffe/Rüstung - alle Items einer Gruppe
-- geben laut Tabelle dieselben Materialien und lernen deshalb gemeinsam.
function D:Prior(itemID)
    if not GetItemInfo or not itemID then return nil end
    local info = { pcall(GetItemInfo, itemID) }
    if not info[1] or not info[2] then return nil end
    local quality, ilvl, equipLoc, classID = info[4], info[5], info[10], info[13]
    if not quality or quality < 2 or quality > 4 or not ilvl then return nil end
    if classID ~= 2 and classID ~= 4 then return nil end
    if NOT_DE[equipLoc or ""] then return nil end
    local weapon = (classID == 2)
    if quality == 2 then
        if ilvl < 5 then return nil end
        for k, b in ipairs(UNCOMMON) do
            if ilvl <= b[1] then
                -- Chancen je Stufe (GREEN_P): bis 15 nur Staub/Essenz (80/20), sonst 75/20/5 bzw. 75/15/10;
                -- Waffen gespiegelt
                return self:GreenPrior(k, b, weapon), "2:" .. k .. ":" .. (weapon and "w" or "a")
            end
        end
        return nil
    elseif quality == 3 then
        if ilvl < 1 then return nil end            -- Disenchantry: blau ab Itemstufe 1
        for k, b in ipairs(RARE) do
            if ilvl <= b[1] then
                if b[2] == LBRILLIANT and ilvl >= 56 then
                    return { { LBRILLIANT, 0.995, 1, 1, 1 }, { NEXUS, 0.005, 1, 1, 1 } }, "3:" .. k
                end
                return { { b[2], 1, 1, 1, 1 } }, "3:" .. k
            end
        end
        return nil
    else
        for k, b in ipairs(EPIC) do
            if ilvl >= b[1] and ilvl <= b[2] then return { { b[3], 1, b[4], b[5], b[6] } }, "4:" .. k end
        end
        return nil
    end
end

-- ------------------------------------------------------------
-- Lernen aus eigenen Entzauberungen
-- Die Tabelle zählt wie PRIOR_WEIGHT gedachte Entzauberungen. Jede echte
-- Entzauberung verschiebt Chance und Menge Richtung deiner Ergebnisse:
--   Chance = (Tabelle x W + gesehen) / (W + Anzahl Entzauberungen)
--   Menge  = (Tabelle x W x Chance + Summe) / (W x Chance + gesehen)
-- Nach 10 eigenen Entzauberungen zählen deine Ergebnisse zur Hälfte,
-- nach 50 zu 83 %, nach 100 zu 91 %.
-- ------------------------------------------------------------
D.PRIOR_WEIGHT = 10

local function Stats() return A.db and A.db.deStats end

-- alle Materialien, die beim Entzaubern herauskommen können
local MATERIALS = {}
for _, b in ipairs(UNCOMMON) do MATERIALS[b[2]] = true; MATERIALS[b[4]] = true; if b[6] then MATERIALS[b[6]] = true end end
for _, b in ipairs(RARE) do MATERIALS[b[2]] = true end
for _, b in ipairs(EPIC) do MATERIALS[b[3]] = true end
MATERIALS[NEXUS] = true
D.MATERIALS = MATERIALS

-- Startwerte einer Gruppe (für Übersichten ohne konkretes Item)
--   "2:k:a" / "2:k:w" grün Rüstung/Waffe, "3:k" blau, "4:k" episch
function D:PriorForKey(key)
    if type(key) ~= "string" then return nil end
    local q, k, w = key:match("^(%d):(%d+):?([aw]?)$")
    q, k = tonumber(q), tonumber(k)
    if q == 2 then
        local b = UNCOMMON[k]
        if not b or w == "" then return nil end
        return self:GreenPrior(k, b, w == "w")
    elseif q == 3 then
        local b = RARE[k]
        if not b or w ~= "" then return nil end
        if b[2] == LBRILLIANT then return { { LBRILLIANT, 0.995, 1, 1, 1 }, { NEXUS, 0.005, 1, 1, 1 } } end
        return { { b[2], 1, 1, 1, 1 } }
    elseif q == 4 then
        local b = EPIC[k]
        if not b or w ~= "" then return nil end
        return { { b[3], 1, b[4], b[5], b[6] } }
    end
    return nil
end

-- Bereich einer Gruppe für Anzeigen: Qualität, Itemlevel von, bis, Waffe?
function D:KeyInfo(key)
    local q, k, w = (key or ""):match("^(%d):(%d+):?([aw]?)$")
    q, k = tonumber(q), tonumber(k)
    local from, to
    if q == 2 and UNCOMMON[k] then from, to = (k == 1) and 5 or UNCOMMON[k - 1][1] + 1, UNCOMMON[k][1]
    elseif q == 3 and RARE[k] then from, to = (k == 1) and 11 or RARE[k - 1][1] + 1, RARE[k][1]
    elseif q == 4 and EPIC[k] then from, to = EPIC[k][1], EPIC[k][2] end
    return q, from, to, w == "w"
end

-- Ergebnisse einer Gruppe: eigene + von anderen Spielern geteilte
-- zurück: n eigene, n geteilt, mats = { [itemID] = { times, total } } (zusammengezählt)
function D:Combined(key)
    local own = Stats() and Stats()[key]
    local nOwn, nShared, mats = own and own.n or 0, 0, {}
    local allowed = self.AllowedMats and self:AllowedMats(key)
    local function add(src)
        for id, m in pairs(src or {}) do
            if allowed and not allowed[id] then
                -- unplausibel für diese Gruppe (z. B. Splitter aus Itemstufe bis 15): nicht mitzählen
            else
            local t = mats[id]
            if not t then t = { times = 0, total = 0 }; mats[id] = t end
            t.times = t.times + (m.times or 0)
            t.total = t.total + (m.total or 0)
            end
        end
    end
    if own then add(own.mats) end
    local shared = A.db and A.db.deShared
    if shared then
        for _, rec in pairs(shared) do
            local g = rec.g and rec.g[key]
            if g and (g.n or 0) > 0 then
                nShared = nShared + g.n
                add(g.mats)
            end
        end
    end
    return nOwn, nShared, mats
end

-- Startwerte mit Ergebnissen verrechnen
function D:Blend(prior, nTotal, mats)
    if nTotal <= 0 then return prior end
    local W, n = self.PRIOR_WEIGHT, nTotal
    local out, seen = {}, {}
    for _, e in ipairs(prior) do
        local m = mats[e[1]]
        local times, total = m and m.times or 0, m and m.total or 0
        local chance = (e[2] * W + times) / (W + n)
        local den = e[2] * W + times
        local avg = (den > 0) and ((e[2] * W * e[3] + total) / den) or e[3]
        table.insert(out, { e[1], chance, avg, e[4], e[5] })
        seen[e[1]] = true
    end
    -- Material, das die Tabelle nicht kennt, aber herauskam
    for id, m in pairs(mats) do
        if not seen[id] and m.times > 0 then
            table.insert(out, { id, m.times / (W + n), m.total / m.times })
        end
    end
    return out
end

-- Ertrag (Tabelle + eigene + geteilte Ergebnisse), Gruppe, Anzahl eigener, Anzahl geteilter Entzauberungen
function D:Yield(itemID)
    local prior, key = self:Prior(itemID)
    if not prior then return nil end
    local nOwn, nShared, mats = self:Combined(key)
    return self:Blend(prior, nOwn + nShared, mats), key, nOwn, nShared
end

-- Ertrag einer Gruppe (für Übersichten)
function D:YieldForKey(key)
    local prior = self:PriorForKey(key)
    if not prior then return nil end
    local nOwn, nShared, mats = self:Combined(key)
    return self:Blend(prior, nOwn + nShared, mats), prior, nOwn, nShared
end

-- alle Gruppen mit eigenen oder geteilten Ergebnissen: { { key, nOwn, nShared }, ... }
function D:Groups()
    local keys = {}
    for key in pairs(Stats() or {}) do keys[key] = true end
    for _, rec in pairs((A.db and A.db.deShared) or {}) do
        for key in pairs(rec.g or {}) do keys[key] = true end
    end
    local out = {}
    for key in pairs(keys) do
        if self:PriorForKey(key) then
            local nOwn, nShared = self:Combined(key)
            if nOwn + nShared > 0 then table.insert(out, { key = key, own = nOwn, shared = nShared }) end
        end
    end
    table.sort(out, function(a, b)
        local qa, fa = self:KeyInfo(a.key)
        local qb, fb = self:KeyInfo(b.key)
        if qa ~= qb then return qa < qb end
        if fa ~= fb then return (fa or 0) < (fb or 0) end
        return a.key < b.key
    end)
    return out
end

-- Protokoll der eigenen Entzauberungen (Entzauber-Fenster: Statistik, Buchhaltung: Abrechnung E4).
-- Ein Teil aus dem Sammelkauf (A.db.deBuys) wird dabei abgehakt: gleiche ItemID, gekauft höchstens
-- DE_MATCH_DAYS Tage vorher, das älteste offene zuerst.
D.DE_MATCH_DAYS = 14
function D:LogResult(itemID, loot, t)
    if not A.db then return end
    t = t or time()
    A.db.deLog = A.db.deLog or {}
    local copy = {}
    for _, l in ipairs(loot or {}) do copy[#copy + 1] = { l[1], l[2] or 1 } end
    local e = { t = t, itemID = itemID, loot = copy }
    for _, b in ipairs(A.db.deBuys or {}) do
        if not b.done and b.itemID == itemID and (b.t or 0) <= t and t - (b.t or 0) <= self.DE_MATCH_DAYS * 86400 then
            b.done = t
            e.paid = b.paid
            break
        end
    end
    table.insert(A.db.deLog, e)
    while #A.db.deLog > 2000 do table.remove(A.db.deLog, 1) end
    if A.Activity and not (A.Activity.Paused and A.Activity.Paused()) then pcall(A.Activity.Touch, A.Activity, "de") end   -- H9
    return e
end

-- ein Ergebnis speichern. loot = { { itemID, Menge }, ... }
function D:Record(itemID, loot)
    local prior, key = self:Prior(itemID)
    local db = Stats()
    if not prior or not db or type(loot) ~= "table" or #loot == 0 then return false end
    local sums = {}
    for _, l in ipairs(loot) do
        if not MATERIALS[l[1]] then return false end      -- fremde Beute: nicht mitzählen
        local allowed = self:AllowedMats(key)
        if allowed and not allowed[l[1]] then return false end   -- passt nicht zur Gruppe (falsches Item erkannt)
        sums[l[1]] = (sums[l[1]] or 0) + (l[2] or 1)
    end
    local st = db[key]
    if not st then st = { n = 0, mats = {} }; db[key] = st end
    st.n = st.n + 1
    st.updated = time()
    for id, qty in pairs(sums) do
        local m = st.mats[id]
        if not m then m = { times = 0, total = 0 }; st.mats[id] = m end
        m.times = m.times + 1
        m.total = m.total + qty
    end
    self.lastRecord = { itemID = itemID, key = key, loot = loot }
    self:LogResult(itemID, loot)
    -- teilen nach 10 neuen Entzauberungen ODER spätestens 2 Minuten nach der letzten (und beim Ausloggen)
    self.unshared = (self.unshared or 0) + 1
    self.lastRecordAt = GetTime and GetTime() or time()
    if self.unshared >= self.SHARE_EVERY then self:BroadcastStats()
    elseif C_Timer and C_Timer.After then
        local mark = self.lastRecordAt
        C_Timer.After(self.SHARE_AFTER, function() D:ShareIfQuiet(mark) end)
    end
    A:Fire("DE_LEARNED", itemID, key)
    A:Fire("DATA_CHANGED")
    return true
end

function D:TotalLearned()
    local groups, n = 0, 0
    for _, st in pairs(Stats() or {}) do groups = groups + 1; n = n + (st.n or 0) end
    return n, groups
end

-- geteilte Ergebnisse anderer Spieler: Entzauberungen gesamt, Anzahl Spieler
function D:TotalShared()
    local n, players = 0, 0
    for _, rec in pairs((A.db and A.db.deShared) or {}) do
        local any = false
        for _, g in pairs(rec.g or {}) do n = n + (g.n or 0); any = true end
        if any then players = players + 1 end
    end
    return n, players
end

function D:Reset()
    if A.db then A.db.deStats = {}; A.db.deShared = {} end
    A:Fire("DATA_CHANGED")
end

-- ------------------------------------------------------------
-- Teilen mit allen Spielern, die AHSentinel haben (über den Preis-Sync)
--   E:<Zeit>:<Gruppe>~<n>~<id>,<mal>,<Summe>,<id>,<mal>,<Summe>;<Gruppe>~...
--   Q:<Zeit>   Bitte um die Ergebnisse der anderen (nach dem Einloggen)
-- Jeder schickt immer seine kompletten eigenen Zahlen - der Empfänger
-- ersetzt die Zahlen dieses Spielers, nichts wird doppelt gezählt.
-- Schutz vor Unsinn: nur bekannte Materialien, höchstens SHARE_MAX_N
-- Entzauberungen pro Spieler und Gruppe, Mengen höchstens 20 pro Mal.
-- ------------------------------------------------------------
D.SHARE_MAX_N = 1000
D.SHARE_MAX_AGE = 90 * 86400
local SHARE_RESPOND_GAP = 30 * 60

-- Text für die eigenen Zahlen (Liste von Teilstücken je Gruppe)
function D:EncodeStats()
    local Enc = A.Sync and A.Sync.Enc
    if not Enc then return {} end
    local parts = {}
    for key, st in pairs(Stats() or {}) do
        if (st.n or 0) > 0 and self:PriorForKey(key) then
            local mats = {}
            for id, m in pairs(st.mats or {}) do
                if (m.times or 0) > 0 then table.insert(mats, Enc(id) .. "," .. Enc(m.times) .. "," .. Enc(m.total)) end
            end
            table.insert(parts, key:gsub(":", ".") .. "~" .. Enc(math.min(st.n, D.SHARE_MAX_N)) .. "~" .. table.concat(mats, ","))
        end
    end
    return parts
end

-- Absender nie mit Namen speichern: nur ein Kürzel ("#" + Prüfsumme), 9. Nov. 08:44
function D:SenderKey(sender)
    local s = tostring(sender or ""):lower()
    local h = 5381
    for i = 1, #s do h = (h * 33 + s:byte(i)) % 4294967296 end
    local digits, out = "0123456789abcdefghijklmnopqrstuvwxyz", ""
    repeat local r = h % 36; out = digits:sub(r + 1, r + 1) .. out; h = math.floor(h / 36) until h == 0
    return "#" .. out
end

-- alte Einträge (bis 0.65.25 mit Namen) auf Kürzel umstellen
function D:MigrateShared(sh)
    sh = sh or (A.db and A.db.deShared)
    if type(sh) ~= "table" then return end
    local rename = {}
    for k in pairs(sh) do if type(k) ~= "string" or k:sub(1, 1) ~= "#" then rename[#rename + 1] = k end end
    for _, k in ipairs(rename) do
        local hk = self:SenderKey(k)
        if not sh[hk] then sh[hk] = sh[k] end
        sh[k] = nil
    end
end

-- Ist der Absender einer der eigenen Charaktere (Twink)? Die zählen schon als "eigene" (gemeinsame deStats)
function D:IsOwnChar(sender)
    local chars = A.db and A.db.chars
    if type(chars) ~= "table" or not sender then return false end
    local s = tostring(sender)
    local name = s:match("^([^%-]+)") or s
    for key, c in pairs(chars) do
        if key == s or (type(c) == "table" and c.name == name and (not s:find("-", 1, true) or key == s)) then return true end
    end
    return false
end

-- Material passt zur Gruppe (Qualität/Itemlevel): nur Materialien aus der Tabelle dieser Gruppe
function D:AllowedMats(key)
    local prior = self:PriorForKey(key)
    if not prior then return nil end
    local ok = {}
    for _, e in ipairs(prior) do if e[1] then ok[e[1]] = true end end
    return ok
end

-- Schutz vor Unsinn beim Annehmen (9. Nov. 08:44)
D.SHARE_MSGS_PER_MIN = 1       -- Sendungen je Absender und Minute (alle Teilstücke einer Sendung = gleiche Zeit t zählen als 1)
D.SHARE_PARTS_MAX = 40          -- höchstens so viele Teilstücke je Sendung
D.SHARE_N_PER_MIN = 30         -- so viele neue Entzauberungen je Absender und Minute (gegenüber seiner letzten Meldung)
D.SHARE_MAX_QTY = 5            -- Menge je Entzauberung 1-5
D.rate = D.rate or {}

-- Teilstücke eines anderen Spielers prüfen und übernehmen (er schickt immer seine kompletten Zahlen:
-- der Empfänger ersetzt sie, nichts wird doppelt gezählt)
function D:HandleShared(sender, t, payload)
    local Dec = A.Sync and A.Sync.Dec
    if not (A.db and Dec and sender and type(payload) == "string") then return 0 end
    local now = time()
    if not t or t > now + 300 or t < now - D.SHARE_MAX_AGE then return 0 end
    if self:IsOwnChar(sender) then return 0 end                 -- eigener Twink: zählt schon als eigen
    local sk = self:SenderKey(sender)
    -- Mengenlimit (offener Punkt 9): höchstens SHARE_MSGS_PER_MIN Sendungen je Absender und Minute. Eine Sendung =
    -- alle Teilstücke mit derselben Zeit t (D:BroadcastStats teilt grosse Statistiken auf) - sie zählen als eine.
    local r = self.rate[sk]
    if not r or now - r.t0 >= 60 then r = { t0 = now, n = 0, sends = {} }; self.rate[sk] = r end
    r.sends = r.sends or {}
    if not r.sends[t] then
        r.n = r.n + 1
        if r.n > self.SHARE_MSGS_PER_MIN then return 0 end
        r.sends[t] = 0
    end
    r.sends[t] = r.sends[t] + 1
    if r.sends[t] > self.SHARE_PARTS_MAX then return 0 end
    A.db.deShared = A.db.deShared or {}
    local rec = A.db.deShared[sk]
    if not rec then rec = { t = 0, g = {} }; A.db.deShared[sk] = rec end
    -- doppelte Meldung (gleicher Inhalt): nur einmal
    if rec.last == payload then return 0 end
    local minutes = (rec.t and rec.t > 0) and math.max(0, (now - rec.t) / 60) or nil
    local taken = 0
    for part in payload:gmatch("[^;]+") do
        local k, nEnc, matStr = part:match("^([%d%.aw]+)~(%w+)~([%w,]*)$")
        local key = k and k:gsub("%.", ":")
        local n = Dec(nEnc)
        local allowed = key and self:AllowedMats(key)
        if key and n and n > 0 and n <= D.SHARE_MAX_N and allowed then
            local mats, ok, nums = {}, true, {}
            for x in matStr:gmatch("[^,]+") do table.insert(nums, Dec(x)) end
            if #nums % 3 ~= 0 then ok = false end
            for i = 1, #nums - 2, 3 do
                local id, times, total = nums[i], nums[i + 1], nums[i + 2]
                if not (id and times and total and allowed[id] and times >= 1 and times <= n and total >= times
                    and total <= times * D.SHARE_MAX_QTY) then
                    ok = false; break
                end
                mats[id] = { times = times, total = total }
            end
            -- zu schnell gewachsen gegenüber der letzten Meldung dieses Absenders?
            local prev = rec.g[key]
            if ok and prev and minutes and n - (prev.n or 0) > D.SHARE_N_PER_MIN * (minutes + 1) then ok = false end
            if ok then
                rec.g[key] = { n = n, mats = mats }
                taken = taken + 1
            end
        end
    end
    if taken > 0 then
        rec.t = now
        rec.last = payload
        A:Fire("DATA_CHANGED")
    end
    return taken
end

-- alte Daten von Spielern, die man lange nicht gehört hat, vergessen
function D:PruneShared()
    self:MigrateShared()
    local limit = time() - D.SHARE_MAX_AGE
    for name, rec in pairs((A.db and A.db.deShared) or {}) do
        if (rec.t or 0) < limit then A.db.deShared[name] = nil end
    end
end

D.SHARE_EVERY = 10          -- nach so vielen neuen Entzauberungen teilen
D.SHARE_AFTER = 120         -- oder spätestens so viele Sekunden nach der letzten

-- 2 Minuten nach der letzten Entzauberung: teilen, wenn seitdem keine neue kam und noch etwas offen ist
function D:ShareIfQuiet(mark)
    if (self.unshared or 0) > 0 and self.lastRecordAt == mark then return self:BroadcastStats() end
    return false
end

-- immediate = true: sofort senden (beim Ausloggen), nicht über die Warteschlange
function D:BroadcastStats(immediate)
    local S = A.Sync
    if not (S and S.IsEnabled and S:IsEnabled() and S:IsConnected() and S.Enqueue) then return false end
    local send = (immediate and S.SendNow) or S.Enqueue
    local parts = self:EncodeStats()
    self.unshared = 0
    if #parts == 0 then return false end
    self.lastShared = time()
    local head = "E:" .. S.Enc(time()) .. ":"
    local chunk, size = {}, #head
    for _, p in ipairs(parts) do
        if #head + #p <= S.MAX_MSG then
            if size + #p + 1 > S.MAX_MSG and #chunk > 0 then
                send(head .. table.concat(chunk, ";"))
                chunk, size = {}, #head
            end
            table.insert(chunk, p)
            size = size + #p + 1
        end
    end
    if #chunk > 0 then send(head .. table.concat(chunk, ";")) end
    return true
end

-- nach dem Einloggen: die anderen um ihre Ergebnisse bitten
function D:RequestShared()
    local S = A.Sync
    if not (S and S.Enqueue and S:IsEnabled() and S:IsConnected()) then return end
    self:PruneShared()
    S.Enqueue("Q:" .. S.Enc(time()))
end

-- auf eine Bitte antworten (zufällig verzögert, höchstens alle 30 Minuten)
function D:HandleRequest()
    if self.pendingShare or (self:TotalLearned()) == 0 then return end
    if self.lastShared and time() - self.lastShared < SHARE_RESPOND_GAP then return end
    self.pendingShare = true
    C_Timer.After(5 + math.random() * 25, function()
        D.pendingShare = false
        D:BroadcastStats()
    end)
end

-- ------------------------------------------------------------
-- Entzaubern erkennen:
--   1. Item wird angeklickt, während ein Zauber auf ein Ziel wartet -> Kandidat
--   2. der Zauber "Entzaubern" ist erfolgreich -> Kandidat wird entzaubert
--   3. das Beute-Fenster öffnet sich -> Materialien lesen und speichern
-- ------------------------------------------------------------
local DE_SPELL = 13262
local candidate, pending
local WINDOW = 10            -- Sekunden zwischen den Schritten

local function ItemAt(bag, slot)
    if C_Container and C_Container.GetContainerItemInfo then
        local info = C_Container.GetContainerItemInfo(bag, slot)
        return info and info.itemID
    elseif GetContainerItemLink then
        local link = GetContainerItemLink(bag, slot)
        return link and tonumber(link:match("item:(%d+)"))
    end
end

local function OnItemTargeted(bag, slot)
    if not (SpellIsTargeting and SpellIsTargeting()) then return end
    local id = ItemAt(bag, slot)
    if id and D:Prior(id) then candidate = { itemID = id, t = GetTime() } end
end

-- Entzauber-Fenster (DEWindow.lua): der sichere Knopf entzaubert per Makro - die Hooks oben sehen das nicht,
-- darum meldet das Fenster das Teil vor dem Klick selbst
function D:NoteCandidate(itemID)
    if itemID and self:Prior(itemID) then candidate = { itemID = itemID, t = GetTime() } end
end

local function IsDisenchant(spellID)
    if spellID == DE_SPELL then return true end
    if GetSpellInfo and spellID then
        local a, b = GetSpellInfo(spellID), GetSpellInfo(DE_SPELL)
        return a ~= nil and a == b
    end
    return false
end

function D:ReadLoot()
    if not (GetNumLootItems and GetLootSlotLink) then return nil end
    local out = {}
    for i = 1, GetNumLootItems() or 0 do
        local link = GetLootSlotLink(i)
        local id = link and tonumber(link:match("item:(%d+)"))
        local qty = 1
        if GetLootSlotInfo then
            local _, _, q = GetLootSlotInfo(i)
            if type(q) == "number" and q > 0 then qty = q end
        end
        if id then table.insert(out, { id, qty }) end
    end
    return out
end

local hooked = false
local function Hook()
    if hooked or not hooksecurefunc then return end
    hooked = true
    if C_Container and C_Container.UseContainerItem then pcall(hooksecurefunc, C_Container, "UseContainerItem", OnItemTargeted) end
    if C_Container and C_Container.PickupContainerItem then pcall(hooksecurefunc, C_Container, "PickupContainerItem", OnItemTargeted) end
    if UseContainerItem then pcall(hooksecurefunc, "UseContainerItem", OnItemTargeted) end
    if PickupContainerItem then pcall(hooksecurefunc, "PickupContainerItem", OnItemTargeted) end
end

local evt = CreateFrame("Frame")
D.evt = evt            -- für die Testroutine (Ereignisse mit Testargumenten nachspielen)
for _, e in ipairs({ "UNIT_SPELLCAST_SUCCEEDED", "LOOT_OPENED", "LOOT_READY", "PLAYER_LOGOUT" }) do pcall(evt.RegisterEvent, evt, e) end
evt:SetScript("OnEvent", function(_, event, a1, a2, a3)
    if event == "PLAYER_LOGOUT" then
        -- noch nicht geteilte Entzauberungen beim Ausloggen sofort senden
        if (D.unshared or 0) > 0 then pcall(D.BroadcastStats, D, true) end
        return
    end
    if event == "UNIT_SPELLCAST_SUCCEEDED" then
        local G = _G.GoldSentinelGame
        if G and G.AnySecret and G.AnySecret(a1) then return end          -- geschützter Wert (WoW Forever)
        if a1 ~= "player" then return end
        if G and G.AnySecret and G.AnySecret(a3) then pending = nil; candidate = nil; return end
        if IsDisenchant(a3) and candidate and GetTime() - candidate.t < WINDOW then
            pending = { itemID = candidate.itemID, t = GetTime() }
        else
            pending = nil      -- anderer Zauber oder kein Item angeklickt: nichts zuordnen
        end
        candidate = nil
    elseif (event == "LOOT_OPENED" or event == "LOOT_READY") and pending then
        if GetTime() - pending.t < WINDOW then
            local loot = D:ReadLoot()
            if loot and #loot > 0 then
                local ok = D:Record(pending.itemID, loot)
                pending = nil
                if ok then
                    local n = select(3, D:Yield(D.lastRecord.itemID)) or 0
                    if n % 10 == 0 then
                        A:Print(string.format(L["Entzaubern: %d eigene Ergebnisse in dieser Gruppe - Werte angepasst."], n))
                    end
                end
            end
        else
            pending = nil
        end
    end
end)
A:On("READY", Hook)

-- erwarteter Wert in Kupfer (Marktwert des Materials), nil wenn nicht entzauberbar oder ohne Preise
-- complete = false, wenn für ein Material noch kein Preis bekannt ist; learned = eigene Entzauberungen,
-- shared = geteilte Entzauberungen anderer Spieler. Vor dem Verkauf im AH gehen noch 5 % ab.
function D:GetValue(itemID)
    local y, _, learned, shared = self:Yield(itemID)
    if not y then return nil end
    local value, complete, any = 0, true, false
    for _, e in ipairs(y) do
        local p = self:MatPrice(e[1])
        if p then value = value + e[2] * e[3] * p; any = true
        elseif e[2] >= 0.05 then complete = false end
    end
    if not any then return nil end
    return math.floor(value + 0.5), complete, y, learned or 0, shared or 0
end

-- Items, die im Auktionshaus gerade billiger sind als ihr Entzauberungswert
-- (nach AH-Gebühr beim Verkauf des Materials, auf WoW Forever auch nach der Einstellgebühr
-- von mind. 1 Silber pro Auktion - anteilig pro Stück, das Material wird im Stapel verkauft),
-- nur aktuelle Preise

-- Einstellgebühr für das erwartete Material eines Entzauberns (0 außerhalb von Forever)
-- Forever: 5 % + erwarteter Einzahlungsverlust je Stück (A:FeePerPiece; die Mindest-Einzahlung verteilt sich auf den Stapel)
function D:MaterialFee(yield)
    if not (yield and A:IsForever()) then return 0 end
    local fee = 0
    for _, e in ipairs(yield) do
        local p = self:MatPrice(e[1])
        if p then fee = fee + (e[2] or 0) * (e[3] or 0) * A:FeePerPiece(e[1], p) end
    end
    return math.floor(fee + 0.5)
end
-- Wert nach Gebühren: Forever Wert - (5 % + Einzahlungsverlust je Material), sonst Wert - 5 %
function D:NetValue(v, yield)
    if A:IsForever() then return v - self:MaterialFee(yield) end
    return math.floor(v * (1 - A:CutPct()) + 0.5)
end
-- ------------------------------------------------------------
-- Tatsächlicher Durchschnitt (nur echte Entzauberungen der Gruppe, eigene + geteilte)
--   Ø = Σ (tatsächlich erhaltene Menge je Material × aktueller AH-Preis aus dem letzten Scan) ÷ N
-- ------------------------------------------------------------
D.FEW_DATA = 10          -- unter so vielen Entzauberungen: "(wenig Daten)"

-- Preis eines Materials: zuerst der aktuelle Preis aus dem letzten Scan, sonst der Marktwert
-- zurück: Preis, Alter in Sekunden (nil = Marktwert), Marktwert
-- Preis eines Materials: EIN Wert für Materialblock UND Summe (Befund 9. Nov. 10:31): der reale Wert (A:PriceInfo:
-- eigener Verkauf -> Sofortpreis knapp unter dem günstigsten Angebot, höchstens Median -> Median), Ausreisser
-- (unter 10 % / über 300 % des Medians) zählen nicht.
-- zurück: Preis, Alter in Sekunden (nur bei Quelle "ah"), Marktwert, Quelle ("sale"/"ah"/"market"), unsicher
function D:MatPrice(id)
    local i = A:PriceInfo(id)
    if not i then return nil end
    local age = (i.source == "ah" and i.currentTime) and math.max(0, time() - i.currentTime) or nil
    return i.value, age, i.median, i.source, i.unsure
end

-- tatsächlicher Ø-Wert: v, complete, N, rows, nOwn, nShared (nil, wenn N = 0)
-- rows: { id, times, total, price, age, mv, share } (share = Anteil am Ø in Kupfer)
function D:ActualValue(itemID)
    local _, key = self:Prior(itemID)
    if not key then return nil end
    local nOwn, nShared, mats = self:Combined(key)
    local n = nOwn + nShared
    if n <= 0 then return nil end
    local rows, value, complete = {}, 0, true
    for id, m in pairs(mats) do
        if (m.times or 0) > 0 then
            local price, age, mv, src, unsure = self:MatPrice(id)
            local share = price and (m.total * price / n) or nil
            if share then value = value + share else complete = false end
            table.insert(rows, { id = id, times = m.times, total = m.total, price = price, age = age, mv = mv, share = share,
                source = src, unsure = unsure })
        end
    end
    table.sort(rows, function(a, b) return (a.share or 0) > (b.share or 0) end)
    return math.floor(value + 0.5), complete, n, rows, nOwn, nShared
end

-- nach Gebühren für den tatsächlichen Ø: Forever je Material AH-Gebühr max(5 %, 1s) (anteilig pro Stück eines
-- Stapels), sonst 5 %
function D:ActualNet(v, rows, n)
    if not A:IsForever() then return math.floor(v * (1 - A:CutPct()) + 0.5) end
    local fee = 0
    for _, r in ipairs(rows or {}) do
        if r.price then fee = fee + (r.total / n) * A:FeePerPiece(r.id, r.price) end
    end
    return v - math.floor(fee + 0.5)
end

-- Aufschlüsselung des geschätzten Werts (Tabelle verrechnet mit Ergebnissen): je Material
-- { id, chance, avg, price, age, mv, share } mit share = Chance × Ø-Menge × Marktwert (genau wie D:GetValue)
function D:EstimateRows(itemID)
    local y = self:Yield(itemID)
    if not y then return nil end
    local rows = {}
    for _, e in ipairs(y) do
        if e[2] > 0 then
            local price, age, mv, src, unsure = self:MatPrice(e[1])
            table.insert(rows, { id = e[1], chance = e[2], avg = e[3], min = e[4], max = e[5], price = price, age = age, mv = mv, source = src, unsure = unsure,
                share = price and (e[2] * e[3] * price) or nil })
        end
    end
    table.sort(rows, function(a, b) return (a.share or 0) > (b.share or 0) end)
    return rows
end

-- Wert für Schnäppchen: tatsächlich, wenn genug Daten (N >= 10) und alle Preise da sind, sonst geschätzt
-- zurück: Wert, netto, vollständig, "actual"/"estimate", N
function D:DealValue(itemID)
    local av, acomplete, n, rows = self:ActualValue(itemID)
    if av and acomplete and n >= self.FEW_DATA then
        return av, self:ActualNet(av, rows, n), true, "actual", n
    end
    local v, complete, yield = self:GetValue(itemID)
    if not v then return nil end
    return v, self:NetValue(v, yield), complete, "estimate", n or 0
end

function D:FindDeals()
    local out = {}
    if not A.db then return out end
    local fresh = time() - A.FRESH_SECONDS
    for itemID in pairs(A.db.marketData) do
        local price, qty, t = A:GetCurrent(itemID)
        if price and t and t >= fresh then
            local v, net, complete, basis, n = self:DealValue(itemID)
            if v and complete and net > price then
                table.insert(out, { itemID = itemID, name = A:GetItemName(itemID), price = price, value = v, basis = basis, n = n,
                                    net = net, profit = net - price, pct = (net - price) / net * 100, quantity = qty or 1 })
            end
        end
    end
    return out
end
