RaidMaster 3.0.10 – DKP, loot and raid leading tools
====================================================

INSTALLATION
- Copy the folder "RaidMaster" into ...\Interface\AddOns\ of your game version and restart the game.
- Open the window with the minimap button or /rm.
- Works with Classic Era, WoW Forever, TBC, Wrath (incl. Titan Reforged), Cataclysm,
  Mists of Pandaria Classic and Retail. The detected game version is shown in chat at login (/rm version).
- The language follows your game client (English, German, French, Spanish, Italian, Portuguese,
  Russian, Korean, Simplified and Traditional Chinese).

MAIN FEATURES
- DKP per raid (separate point pools), automatic awards for raid start, boss kills and raid end.
- Open bidding with a bid window for everyone; players without the addon bid with /w <looter> !bid 50.
- Loot rules (auction, guild bank, disenchanter, crafter), trade helper, undo log, decay, standby.
- Raid sign-ups imported from Discord: auto invite and automatic group sorting.
- Assignments (healing, decurse, dispel, crowd control per boss) sent to every player.
- Specs of all raid members (own spec is shared automatically, others via inspect).
- PUG raids without DKP (soft reserve via softres.it) and an ad text for public chat channels.
- All raids of every WoW version (Classic to Midnight, 60+ raids, 400+ bosses): the addon shows the raids of
  your game version, with tactics, two raid chat lines and a raid marker template per boss.
  The boss's marker template is selected automatically when the encounter starts.
- Every raid has its own DKP pool; boss kills are detected and booked automatically.
- Raid target icon bar.

WHAT'S NEW IN 3.0.10 – GoldSentinelGame version 2
- The shared version detection is now version 2. It takes precedence over early, withdrawn copies that other
  GoldSentinel addons briefly shipped, so several addons together run without Lua errors. Nothing else changes.

WHAT'S NEW IN 3.0.9 – Shared version detection (GoldSentinelGame)
- New: GoldSentinelGame.lua detects the game version the same way in all GoldSentinel addons and tells the two
  API worlds apart: old (Classic Era, TBC, Wrath, Cata, MoP Classic) and modern (WoW Forever and Retail).
  Forever is detected even if Blizzard raises the interface number at launch.
- WoW Forever no longer counts as "Classic Era". Raids, classes and level 60 stay the same.
- Names with first and last name (Forever) use the shared file.
- /gsgame and the diagnostics window show the detected version and API.
- Nothing changes for Classic Era, TBC, Wrath, Cata and MoP Classic.

WHAT'S NEW IN 3.0.8 – Marking in combat (WoW Forever)
- In combat on WoW Forever (and Retail) RaidMaster no longer marks anything automatically: "Mark adds"
  (button, bar, /rm adds, key binding) and "Markers" on the boss bar stop with the hint
  "In combat, please mark with the mouseover keys." – no Lua error. Before the pull everything works as usual.
- The mouseover keys (marker 1–8, next free marker, clear marker) keep working in combat; locked values
  ("secret values") are skipped.
- Classic Era, TBC, Wrath, Cata and MoP Classic behave exactly as before.

WHAT'S NEW IN 3.0.7 – WoW Forever: modern client
WoW Forever looks like Classic but runs on the modern client: in combat, addons no longer see names, GUIDs
and buffs ("secret values") and the combat log is closed to addons. RaidMaster now handles this:
- Ready check: reads flasks and elixirs via the new aura API (C_UnitAuras), Classic Era keeps the old one.
  If the client does not provide buffs, the check shows "buffs not readable" instead of a false "no flask".
  The check only starts out of combat.
- Core Hounds: on WoW Forever the Raid page has an "Announce skinners" button instead of the automatic
  announcement (which needs the combat log). Classic Era stays automatic.
- Template marking: if the client locks enemy data in combat, RaidMaster now says so clearly.
  Before the pull the template works as usual; in combat, target the enemy and press a marker button.
- Spell names and item counts use the modern APIs (C_Spell, C_Item) with a fallback.

WHAT'S NEW IN 3.0.6
- The test tool is now available to the developer only.

WHAT'S NEW IN 3.0.5
- New "Support" button at the top of the RaidMaster window (also in Settings and /rm donate): opens a small window
  with the PayPal link selected – press Ctrl+C and paste it into your browser. It never pops up on its own.

SUPPORT THE ADDON
RaidMaster is free and made in my spare time. If it helps you, you can support it with a small donation – thank you so much!
Donate with PayPal: https://www.paypal.com/ncp/payment/46R68N2BF7BTY
In-game: the Support button in the addon window (or /rm donate).

COMMANDS
  /rm          open the window
  /rm bar      toggle the raid icon bar
  /rm sync     request a data sync
  /rm minimap  show/hide the minimap button (drag it around the minimap with the left mouse button)
  /rm donate   support the addon (PayPal link to copy; also /rm support)
  /rm clear    remove all raid target icons at once (also the "Clear all" button on the icon bar)
  /rm adds     mark all visible adds at once using the boss marker template (enemy nameplates on)
  /rm version  show addon version, game version and language
  /rm reset    reset window positions

Without a master looter (Retail) won items are put on the trade list and handed over by trade.
