-- ============================================================
-- AH Analyzer Pro 5.9 - Tab "Verkaufen"
--   links:  verkaufbare Items aus deinen Taschen
--   rechts: aktuelle Angebote, Preisvorschlag (unterbieten), Menge,
--           Dauer, Gebühren, Warnung wenn ein Händler mehr zahlt
-- Einstellen nur per Klick auf "Einstellen".
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local function BuildSell(parent)
    local p = CreateFrame("Frame", nil, parent)
    local Se = A.Seller
    p.selected = nil
    p.duration = (A.db.seller.duration or 2)
    p.confirmLow = nil         -- zweiter Klick nötig, wenn der Händler mehr zahlt

    local function setMessage(ok, msg)
        if not msg then return end
        p.message:SetText(msg)
        p.message:SetTextColor(unpack(ok and C.textDim or C.red))
    end

    -- ================= Links: Taschen =================
    local head = UI:TabTitle(p, L["Verkaufen"], "sell")
    local sub = UI:Label(p, L["Item links wählen, Preis prüfen, 'Einstellen' klicken."], "GameFontDisableSmall", C.textDim)
    sub:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -4)

    p.bagTable = UI:Table(p, {
        columns = {
            { key = "name", title = L["Item"], width = 168 },
            { key = "count", title = L["Anzahl"], width = 52, align = "RIGHT" },
            { key = "market", title = L["Marktwert"], width = 100, align = "RIGHT" },
            { key = "lowest", title = L["Günstigstes"], width = 100, align = "RIGHT",
              tooltip = L["Günstigstes fremdes Angebot (nach 'Preis prüfen')"] },
        },
        rows = 16,
        rowHeight = 22,
        sortKey = "value",
        sortAsc = false,
        cell = function(e, key)
            if key == "name" then return e.name end
            if key == "count" then return tostring(e.count) end
            return A:FormatMoney(e[key])
        end,
        sortValue = function(e, key)
            if key == "name" then return string.lower(e.name) end
            return e[key]
        end,
        onClick = function(e) p:Select(e.itemID) end,
        emptyText = L["Keine verkaufbaren Items in den Taschen."],
    })
    p.bagTable:Fill(0, -44, -486, 34)    -- linke Spalte, darunter "Serie"

    -- Serien-Einstellen
    p.batchBtn = UI:Button(p, "", 260, 24, function()
        if Se.batch then
            local ok, msg, soft = Se:BatchStep()
            setMessage(ok or soft, msg)
        else
            setMessage(Se:StartBatch())
        end
        p:Refresh()
    end, "primary")
    p.batchBtn:SetPoint("TOPLEFT", p.bagTable, "BOTTOMLEFT", 0, -6)
    p.batchBtn.tooltip = L["Stellt alle Taschen-Items ein, für die ein Preis gemerkt ist - ein Klick pro Auktion.\nPreis: Vorschlag (unterbieten). Übersprungen wird, wenn er unter 70 % deines letzten\nPreises fällt oder ein Händler mehr zahlt."]
    p.batchStop = UI:Button(p, "X", 24, 24, function()
        setMessage(true, Se:StopBatch(L["angehalten"]))
        p:Refresh()
    end, "danger")
    p.batchStop:SetPoint("LEFT", p.batchBtn, "RIGHT", 4, 0)
    p.batchStop.tooltip = L["Serie anhalten"]

    -- ================= Rechts: Einstellen =================
    local right = CreateFrame("Frame", nil, p)
    -- rechte Spalte (Formular) fest 470 breit am rechten Rand - die Taschen-Liste links nimmt den Rest
    right:SetPoint("TOPRIGHT", 0, 0)
    right:SetPoint("BOTTOMRIGHT", 0, 0)
    right:SetWidth(470)

    p.title = UI:Label(right, L["Kein Item gewählt"], "GameFontNormalLarge", C.accent)
    p.title:SetPoint("TOPLEFT", 0, 0)
    p.title:SetWidth(460)
    p.info = UI:Label(right, "", "GameFontHighlightSmall", C.textDim)
    p.info:SetPoint("TOPLEFT", 0, -24)
    p.info:SetWidth(460)

    p.checkBtn = UI:Button(right, L["Preis prüfen"], 120, 24, function()
        if not p.selected then return setMessage(false, L["Erst links ein Item aus deinen Taschen wählen."]) end
        if not A:IsAHOpen() then return setMessage(false, L["Bitte zuerst das Auktionshaus öffnen."]) end
        Se:CheckPrice(p.selected, true)
        setMessage(true, L["Angebote werden geladen ..."])
    end)
    p.checkBtn:SetPoint("TOPLEFT", 0, -46)
    p.checkBtn.tooltip = L["Lädt die aktuellen Angebote dieses Items aus dem Auktionshaus"]
    p.checkInfo = UI:Label(right, "", "GameFontHighlightSmall", C.textDim)
    p.checkInfo:SetPoint("LEFT", p.checkBtn, "RIGHT", 10, 0)
    p.checkInfo:SetWidth(330)

    p.listings = UI:Table(right, {
        columns = {
            { key = "price", title = L["Preis/Stück"], width = 120, align = "RIGHT" },
            { key = "qty", title = L["Menge"], width = 70, align = "RIGHT" },
            { key = "pct", title = L["% Markt"], width = 70, align = "RIGHT" },
            { key = "own", title = "", width = 90 },
        },
        rows = 5,
        rowHeight = 20,
        itemTooltip = false,
        noMenu = true,
        cell = function(l, key)
            if key == "price" then return A:FormatMoney(l.price) end
            if key == "qty" then return tostring(l.qty) end
            if key == "pct" then return A:FormatMarketPercent(p.selected and A:GetMarketPercent(p.selected, l.price)) end
            if key == "own" then
                if l.own then return "|cff00d1d1" .. L["eigenes"] .. "|r" end
                if l.bait then return "|cffff9933" .. L["Lockangebot"] .. "|r" end
                return ""
            end
        end,
        onClick = function(l)
            if l.bait then
                -- Lockangebote nicht unterbieten: Vorschlag ohne Köder
                p.price:SetCopper((Se:Suggest(p.selected)))
                p:UpdateSummary()
                return
            end
            p.price:SetCopper(l.own and l.price or Se:Undercut(l.price))
            p:UpdateSummary()
        end,
        emptyText = L["Noch nicht geprüft."],
    })
    p.listings:SetPoint("TOPLEFT", p.checkBtn, "BOTTOMLEFT", 0, -8)

    -- Preis pro Stück
    local y0 = -218
    local priceLabel = UI:Label(right, L["Preis/Stück:"], "GameFontHighlightSmall", C.textDim)
    priceLabel:SetPoint("TOPLEFT", 0, y0 - 6)
    p.price = UI:MoneyInput(right, function() p.confirmLow = nil; p:UpdateSummary() end)
    p.price:SetPoint("TOPLEFT", 90, y0)
    p.suggestBtn = UI:Button(right, L["Vorschlag"], 90, 24, function() p:ApplySuggestion(true) end)
    p.suggestBtn:SetPoint("TOPLEFT", 262, y0)
    p.suggestBtn.tooltip = L["Günstigstes fremdes Angebot unterbieten.\nOhne Preisprüfung: Marktwert (Median 14 Tage)."]
    p.undercutBtn = UI:Button(right, "", 100, 24, function()
        Se:CycleUndercut()
        p:ApplySuggestion(true)
    end)
    p.undercutBtn:SetPoint("LEFT", p.suggestBtn, "RIGHT", 6, 0)
    p.undercutBtn.tooltip = L["Um wie viel das günstigste Angebot unterboten wird (Klick: wechseln)"]

    -- Menge
    local qtyLabel = UI:Label(right, L["Menge:"], "GameFontHighlightSmall", C.textDim)
    qtyLabel:SetPoint("TOPLEFT", 0, y0 - 40)
    p.qty = UI:EditBox(right, 70, 24, "1")
    p.qty:SetPoint("TOPLEFT", 90, y0 - 34)
    p.qty:SetScript("OnTextChanged", function() p.confirmLow = nil; p:UpdateSummary() end)
    p.qty:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    p.allBtn = UI:Button(right, L["Alle"], 60, 24, function()
        if not p.selected then return end
        p.qty:SetText(tostring((Se:CountInBags(p.selected))))
        p:UpdateSummary()
    end)
    p.allBtn:SetPoint("LEFT", p.qty, "RIGHT", 6, 0)
    p.qtyHint = UI:Label(right, "", "GameFontDisableSmall", C.textDim)
    p.qtyHint:SetPoint("LEFT", p.allBtn, "RIGHT", 10, 0)
    p.qtyHint:SetWidth(220)

    -- Dauer
    local durLabel = UI:Label(right, L["Dauer:"], "GameFontHighlightSmall", C.textDim)
    durLabel:SetPoint("TOPLEFT", 0, y0 - 74)
    p.durButtons = {}
    local prev
    for d = 1, 3 do
        local b = UI:Button(right, Se:DurationLabel(d), 104, 24, function()
            p.duration = d
            p.confirmLow = nil
            p:UpdateSummary()
        end)
        if prev then b:SetPoint("LEFT", prev, "RIGHT", 6, 0) else b:SetPoint("TOPLEFT", 90, y0 - 68) end
        b.duration = d
        p.durButtons[d] = b
        prev = b
    end

    -- Zusammenfassung
    local line = right:CreateTexture(nil, "ARTWORK")
    line:SetColorTexture(unpack(C.border))
    line:SetPoint("TOPLEFT", 0, y0 - 102)
    line:SetSize(460, 1)
    local function sumRow(labelText, y)
        local l = UI:Label(right, labelText, "GameFontHighlightSmall", C.textDim)
        l:SetPoint("TOPLEFT", 0, y)
        local v = UI:Label(right, "-", "GameFontHighlight", C.text)
        v:SetPoint("TOPLEFT", 200, y)
        v:SetWidth(200)
        v:SetJustifyH("RIGHT")
        return v
    end
    p.sDeposit = sumRow(L["Einstellgebühr"], y0 - 112)
    p.sGross = sumRow(L["Verkauf brutto"], y0 - 132)
    p.sCut = sumRow(L["AH-Gebühr (5 %)"], y0 - 152)
    p.sNet = sumRow(L["Erlös nach Gebühren"], y0 - 172)
    p.warning = UI:Label(right, "", "GameFontHighlightSmall", C.red)
    p.warning:SetPoint("TOPLEFT", 0, y0 - 194)
    p.warning:SetWidth(460)

    p.postBtn = UI:Button(right, L["Einstellen"], 160, 28, function() p:Post() end, "primary")
    p.postBtn:SetPoint("TOPLEFT", 0, y0 - 218)
    p.postBtn.tooltip = L["Stellt das Item mit Preis, Menge und Dauer ins Auktionshaus.\nEinzelstücke (z.B. Ausrüstung): ein Klick = eine Auktion."]
    p.message = UI:Label(right, "", "GameFontHighlightSmall", C.textDim)
    p.message:SetPoint("LEFT", p.postBtn, "RIGHT", 10, 0)
    p.message:SetWidth(290)

    -- ------------------------------------------------------------
    function p:Select(itemID)
        self.selected = itemID
        self.confirmLow = nil
        self.bagTable.selectedID = itemID
        local last = A.db.seller.items[itemID]
        self.duration = (last and last.duration) or A.db.seller.duration or 2
        local count, entry = Se:CountInBags(itemID)
        if entry and entry.commodity then
            self.qty:SetText(tostring(math.min(count, (last and last.qty) or count)))
        else
            self.qty:SetText("1")
        end
        self:ApplySuggestion(false)
        if A:IsAHOpen() and not Se:IsPriceFresh(itemID) then Se:CheckPrice(itemID, true) end
        self:Refresh()
    end

    function p:ApplySuggestion(announce)
        if not self.selected then return end
        local price, why = Se:Suggest(self.selected)
        if price then self.price:SetCopper(price) else self.price:Clear() end
        self.suggestWhy = why
        if announce then setMessage(price ~= nil, why) end
        self:UpdateSummary()
    end

    function p:Values()
        local unit = self.price:GetCopper()
        local qty = math.floor(tonumber(self.qty:GetText()) or 0)
        return unit, qty
    end

    function p:UpdateSummary()
        for d, b in ipairs(self.durButtons) do
            b:SetText(d == self.duration and ("> " .. Se:DurationLabel(d) .. " <") or Se:DurationLabel(d))
        end
        self.undercutBtn:SetText(L["- "] .. Se:UndercutLabel(A.db.seller.undercut))
        local id = self.selected
        self.warning:SetText("")
        if not id then
            for _, v in ipairs({ self.sDeposit, self.sGross, self.sCut, self.sNet }) do v:SetText("-") end
            self.postBtn:SetActive(false)
            return
        end
        local count, entry = Se:CountInBags(id)
        local commodity = entry and entry.commodity
        self.qtyHint:SetText(commodity and string.format(L["von %d (Gesamtmenge)"], count)
            or string.format(L["Auktionen à 1 Stück (von %d)"], count))
        local unit, qty = self:Values()
        if not unit or qty < 1 or not entry then
            for _, v in ipairs({ self.sDeposit, self.sGross, self.sCut, self.sNet }) do v:SetText("-") end
            self.postBtn:SetActive(entry ~= nil)
            return
        end
        local postQty = commodity and qty or 1
        local deposit = Se:Deposit(id, self.duration, postQty, commodity, entry.slots[1].loc)
        local gross, cut, net = Se:Proceeds(unit, postQty)
        self.sDeposit:SetText(deposit and A:FormatMoney(deposit) or "?")
        self.sGross:SetText(A:FormatMoney(gross))
        self.sCut:SetText(A:FormatMoney(cut))
        local final = net - (deposit or 0)
        self.sNet:SetText(final >= 0 and A:FormatMoney(final) or ("|cffff5544-" .. A:FormatMoney(-final) .. "|r"))
        local warn = {}
        if commodity and qty > count then table.insert(warn, string.format(L["Nur %d Stück in den Taschen."], count)) end
        local beats, vendorTotal = Se:VendorBeats(id, unit, postQty, deposit)
        if beats then
            table.insert(warn, string.format(L["Achtung: Ein Händler zahlt %s - mehr als das Auktionshaus netto!"], A:FormatMoney(vendorTotal)))
        end
        local avgBuy = A.Ledger and A.Ledger:AverageBuyPrice(id, 30)
        if avgBuy and postQty > 0 and math.floor(net / postQty) < avgBuy then
            table.insert(warn, string.format(L["Unter deinem Einkaufspreis (Ø %s der letzten 30 Tage) - Verlust."], A:FormatMoney(avgBuy)))
        end
        -- Preisschutz: zu billig? -> Warnung und zweiter Klick nötig
        local risks = Se:PriceRisks(id, unit)
        for _, r in ipairs(risks) do table.insert(warn, "|cffff9933" .. L["Preisschutz: "] .. r .. "|r") end
        self.warning:SetText(table.concat(warn, "\n"))
        self.lowWarning = beats or #risks > 0
        self.postBtn:SetText((self.lowWarning and self.confirmLow) and L["Trotzdem einstellen"] or L["Einstellen"])
        self.postBtn:SetActive(true)
    end

    function p:Post()
        local unit, qty = self:Values()
        local id = self.selected
        -- Schutz: Händler zahlt mehr oder Preis viel zu niedrig -> erst nach zweitem Klick
        if self.lowWarning and not self.confirmLow then
            self.confirmLow = true
            self:UpdateSummary()
            return setMessage(false, L["Preis prüfen! Nochmal klicken, um trotzdem einzustellen."])
        end
        local ok, msg = Se:Post(id, unit, qty, self.duration)
        self.confirmLow = nil
        setMessage(ok, msg)
        self:UpdateSummary()
    end

    function p:RefreshBatch()
        local cur, pos, total = Se:BatchCurrent()
        if Se.batch and cur then
            self.batchBtn:SetText(string.format(L["Einstellen: %s (%d/%d)"], cur.name, pos, total))
            self.batchBtn:SetActive(A:IsAHOpen())
            self.batchStop:Show()
        else
            if Se.batch then Se:StopBatch() end
            local n = #Se:BatchCandidates()
            self.batchBtn:SetText(string.format(L["Serie: alle mit Preis (%d)"], n))
            self.batchBtn:SetActive(n > 0 and A:IsAHOpen())
            self.batchStop:Hide()
        end
    end

    function p:Refresh()
        self:RefreshBatch()
        local items = Se:GetBagItems()
        self.bagTable.selectedID = self.selected
        self.bagTable:SetData(items, true)
        local id = self.selected
        if id and Se:CountInBags(id) == 0 then
            -- alles verkauft / nicht mehr in den Taschen
            self.title:SetText(A:GetItemName(id))
            self.info:SetText(L["|cffaaaaaaNicht mehr in deinen Taschen.|r"])
            self.listings:SetData({})
            self:UpdateSummary()
            return
        end
        if not id then
            self.title:SetText(L["Kein Item gewählt"])
            self.info:SetText(A:IsAHOpen() and L["Links ein Item anklicken."] or L["|cffff5544Auktionshaus öffnen, um Preise zu prüfen und einzustellen.|r"])
            self.checkInfo:SetText("")
            self.listings:SetData({})
            self:UpdateSummary()
            return
        end
        local count = Se:CountInBags(id)
        self.title:SetText(A:GetItemName(id))
        local mv, vendor = A:GetMarketValue(id), A:GetVendorPrice(id)
        local info = string.format(L["In Taschen: %d   |   Marktwert %s   |   Händler %s"], count,
            A:FormatMoney(mv), (vendor and vendor > 0) and A:FormatMoney(vendor) or "-")
        local avgBuy = A.Ledger and A.Ledger:AverageBuyPrice(id, 30)
        if avgBuy then info = info .. string.format(L["   |   gekauft Ø %s"], A:FormatMoney(avgBuy)) end
        self.info:SetText(info)
        local pr = Se:GetPriceInfo(id)
        if Se.search and Se.search.itemID == id then
            self.checkInfo:SetText(L["|cffffcc33Lade Angebote ...|r"])
        elseif pr then
            local own = 0
            for _, l in ipairs(pr.listings) do if l.own then own = own + 1 end end
            self.checkInfo:SetText(string.format(L["geprüft %s: %d Angebote, %d eigene"], A:FormatAgo(pr.stamp), #pr.listings, own))
        else
            self.checkInfo:SetText(A:IsAHOpen() and "" or L["|cffff5544AH geschlossen|r"])
        end
        self.listings:SetData(A:NoBait(pr and pr.listings))
        self:UpdateSummary()
    end

    -- Vorschlag übernehmen, sobald die Preisprüfung für das gewählte Item fertig ist
    local lastStamp
    A:On("SELLER_CHANGED", function()
        local id = p.selected
        local pr = id and Se:GetPriceInfo(id)
        if pr and pr.stamp ~= lastStamp and pr.time and (GetTime() - pr.time) < 2 then
            lastStamp = pr.stamp
            p:ApplySuggestion(false)
        end
    end)

    p:UpdateSummary()
    return p
end

UI:RegisterTab("sell", "Verkaufen", 3.6, BuildSell)

A:On("SELLER_CHANGED", function()
    local tab = UI:GetTab(UI.activeTab or "")
    if tab and (tab.id == "sell" or tab.id == "auctions") then UI:RefreshActive() end
end)
