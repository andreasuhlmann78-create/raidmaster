-- ThreatSentinel - TestRoutine.lua
-- Automatische Testroutine ("auf Herz und Nieren"), nur für den Entwickler (GoldSentinelDev).
--   /ts testroutine            alle Bereiche A bis K und U
--   /ts testroutine a … k, u   nur ein Bereich (K = Oberfläche im echten Client, U = umfassende Tests TU1–TU7)
--   /ts testroutine halb       Liste der halbautomatischen Schritte
--   /ts testroutine letzte     letzten gespeicherten Bericht zeigen
-- Ergebnisse nur über GoldSentinelTest (T:Check / T:Skip / T:Client). IDs wie in testroutine-threatsentinel.txt.
--
-- Regeln (nachtrag-testroutinen.txt):
--   * Keine Blizzard-Funktion wird ersetzt. Ersetzt werden nur Felder eigener Tabellen (ns, Module), immer am Ende
--     des Bereichs zurückgesetzt. Was sich nur über eine ersetzte Blizzard-Funktion prüfen liesse, ist ÜBERSPRUNGEN
--     (mit Grund) oder IM CLIENT PRÜFEN.
--   * Aktionen mit Folgen (Chat, Addon-Nachrichten, CVars, Tastenbelegung, Neuladen, Betrachten, Töne) laufen im
--     Addon über ns.Act. Während der Routine schreibt ns.Act nur mit. Echte Aufrufe werden über hooksecurefunc gezählt
--     (Erwartung 0).
--   * Geschützte Werte: Köderwert ns.testBait, den ns.IsSecret als geschützt erkennt (issecretvalue bleibt unberührt).
--   * Sandbox: ThreatSentinelDB und der Laufzustand werden vorher kopiert und nach jedem Bereich in dieselben Tabellen
--     zurückgeschrieben (ns.db bleibt mit den gespeicherten Daten verbunden).

local ADDON, ns = ...
local L = ns.L

local R = {}
ns.Routine = R

local AREAS = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "U" }   -- U = umfassende Tests TU1–TU7 (TestRoutineTU.lua)
R.AREAS = AREAS
local RUN                     -- laufender Durchlauf (GoldSentinelTest-Objekt)

------------------------------------------------------------
-- Hilfen
------------------------------------------------------------
local function InCombat()
	return (InCombatLockdown and InCombatLockdown()) or (UnitAffectingCombat and UnitAffectingCombat("player")) or false
end

local function Ms()
	if debugprofilestop then return debugprofilestop() end
	return GetTime() * 1000
end

local function Copy(v, seen)
	if type(v) ~= "table" then return v end
	seen = seen or {}
	if seen[v] then return seen[v] end
	local t = {}
	seen[v] = t
	for k, x in pairs(v) do t[Copy(k, seen)] = Copy(x, seen) end
	return t
end

local function IsGsKey(k) return type(k) == "string" and k:sub(1, 2) == "gs" end

-- dst in-place auf den Stand von src bringen (dieselben Tabellen bleiben erhalten)
local function RestoreInto(dst, src, top)
	for k in pairs(dst) do
		if src[k] == nil and not (top and IsGsKey(k)) then dst[k] = nil end
	end
	for k, v in pairs(src) do
		if not (top and IsGsKey(k)) then
			if type(v) == "table" and type(dst[k]) == "table" then RestoreInto(dst[k], v)
			else dst[k] = Copy(v) end
		end
	end
end

-- erster abweichender Pfad oder nil
local function Diff(a, b, path, top)
	if type(a) ~= type(b) then return path end
	if type(a) ~= "table" then
		if a ~= b then return path end
		return nil
	end
	for k, v in pairs(a) do
		if not (top and IsGsKey(k)) then
			local d = Diff(v, b[k], path .. "." .. tostring(k))
			if d then return d end
		end
	end
	for k in pairs(b) do
		if not (top and IsGsKey(k)) and a[k] == nil then return path .. "." .. tostring(k) end
	end
	return nil
end

local function Eq(a, b) return a == b end
local function Near(a, b, tol) return type(a) == "number" and type(b) == "number" and math.abs(a - b) <= (tol or 0.01) end
local function S(v) if v == nil then return "nil" end return tostring(v) end

-- Testnamen nie im Bericht (auch erfundene werden durch <Name> ersetzt)
local FAKE = { "Grimbar", "Torben", "Anna" }
local function Clean(v)
	local s = S(v)
	for _, n in ipairs(FAKE) do s = s:gsub(n, "<Name>") end
	if ns.playerName and ns.playerName ~= "" then s = s:gsub(ns.playerName:gsub("%p", "%%%0"), "<Name>") end
	return s
end

------------------------------------------------------------
-- Ersetzen eigener Felder (nie _G, nie Blizzard-Tabellen)
------------------------------------------------------------
local swaps = {}
local function Swap(tbl, key, value)
	assert(type(tbl) == "table" and not rawequal(tbl, _G), "Swap: nur eigene Tabellen")
	swaps[#swaps + 1] = { tbl, key, rawget(tbl, key) }
	tbl[key] = value
end
local function UnswapAll()
	for i = #swaps, 1, -1 do
		local s = swaps[i]
		s[1][s[2]] = s[3]
		swaps[i] = nil
	end
end

------------------------------------------------------------
-- Köderwert für geschützte Werte
------------------------------------------------------------
local function NewBait()
	local p, mt
	if newproxy then
		p = newproxy(true)
		mt = getmetatable(p)
	else
		p, mt = {}, {}
		setmetatable(p, mt)
	end
	local function boom() error("secret value used", 2) end
	for _, k in ipairs({ "__add", "__sub", "__mul", "__div", "__mod", "__unm", "__concat", "__lt", "__le", "__len", "__index", "__newindex", "__call" }) do
		mt[k] = boom
	end
	mt.__tostring = function() return "SECRET" end
	return p
end
local SECRET = NewBait()

------------------------------------------------------------
-- Echte Aktionen zählen (hooksecurefunc ersetzt nichts und verseucht nichts)
------------------------------------------------------------
R.realCalls = 0
local hooked = false
local function InstallHooks()
	if hooked or not hooksecurefunc then return end
	hooked = true
	local function count() if R.inArea then R.realCalls = R.realCalls + 1 end end
	for _, name in ipairs({ "SendChatMessage", "SendAddonMessage", "SetCVar", "SetBinding", "SaveBindings", "NotifyInspect", "Screenshot", "ReloadUI" }) do
		if type(_G[name]) == "function" then pcall(hooksecurefunc, name, count) end
	end
	if C_ChatInfo and type(C_ChatInfo.SendAddonMessage) == "function" then pcall(hooksecurefunc, C_ChatInfo, "SendAddonMessage", count) end
	if C_ChatInfo and type(C_ChatInfo.SendChatMessage) == "function" then pcall(hooksecurefunc, C_ChatInfo, "SendChatMessage", count) end
	if C_CVar and type(C_CVar.SetCVar) == "function" then pcall(hooksecurefunc, C_CVar, "SetCVar", count) end
end

------------------------------------------------------------
-- Sandbox
------------------------------------------------------------
local NS_KEYS = { "testMode", "liveTest", "simSecret", "simAccess", "threatAccess", "isModern", "isRetail", "flavor",
	"errorCount", "lastError", "errorNoticed", "memberNow", "aggroLeader", "tankAtPull", "moveMode", "class",
	"tauntSpell", "tauntMode", "routineSelfTest", "noTankHinted", "noTankHintN" }
local NS_TABLES = { "syncRoles", "fakeNames", "cdTrack", "compat", "blocked", "owners" }
local CVARS = { "nameplateShowEnemies", "threatShowNumeric", "threatWarning" }

local function GetCV(name)
	local ok, v
	if C_CVar and C_CVar.GetCVar then ok, v = pcall(C_CVar.GetCVar, name)
	elseif GetCVar then ok, v = pcall(GetCVar, name) end
	if ok then return v end
end

local function ModTables()
	local list = {}
	local TA, Sy, K, DM, A = ns.ThreatAccess, ns.Sync, ns.Track, ns.DmgMeter, ns.Alerts
	if TA then list.TA = { TA, { "checked", "attempts", "announced", "wantBlizzard", "lastProbe", "tempNone" } } end
	if Sy then list.Sync = { Sy, { "claims", "taunts", "cd" } } end
	if K then list.Track = { K, { "sunder", "cc", "ccSince", "ccBreak" } } end
	if DM then list.DM = { DM, { "total", "cur", "showTotal" } } end
	if A then list.Alerts = { A, { "extras" } } end
	if ns.Log then list.Log = { ns.Log, { "on" } } end
	if ns.Specs then list.Specs = { ns.Specs, { "pending", "lastInspect", "failed" } } end
	if ns.Test then list.Test = { ns.Test, { "clientSim" } } end
	return list
end

local function FrameStates()
	local out = {}
	for _, k in ipairs({ "HUD", "Meter", "DD", "DmgMeter" }) do
		local m = ns[k]
		if m and m.f then out[k] = m.f:IsShown() and true or false end
	end
	return out
end

function R:TakeSandbox()
	local sb = { db = {}, ns = {}, nsT = {}, mod = {}, cvars = {}, keys = {} }
	for k, v in pairs(ThreatSentinelDB or {}) do
		if not IsGsKey(k) then sb.db[k] = Copy(v) end
	end
	sb.dbRef, sb.profile = ThreatSentinelDB, ns.db
	for _, k in ipairs(NS_KEYS) do sb.ns[k] = { ns[k] } end
	for _, k in ipairs(NS_TABLES) do sb.nsT[k] = Copy(ns[k] or {}) end
	for name, e in pairs(ModTables()) do
		local saved = {}
		for _, f in ipairs(e[2]) do saved[f] = { Copy(e[1][f]) } end
		sb.mod[name] = saved
	end
	for _, c in ipairs(CVARS) do sb.cvars[c] = GetCV(c) end
	if ns.Taunt and ns.Taunt.BIND and GetBindingKey then
		for which, cmd in pairs(ns.Taunt.BIND) do
			local k1, k2 = GetBindingKey(cmd)
			sb.keys[which] = tostring(k1) .. "/" .. tostring(k2)
		end
	end
	sb.frames = FrameStates()
	sb.live = R:LiveSnap()
	self.sb = sb
end

function R:RestoreSandbox()
	local sb = self.sb
	if not sb then return end
	-- gespeicherte Daten: dieselbe Tabelle wie vorher
	ThreatSentinelDB = sb.dbRef
	RestoreInto(ThreatSentinelDB, sb.db, true)
	ns.db = sb.profile
	for _, k in ipairs(NS_KEYS) do ns[k] = sb.ns[k][1] end
	for _, k in ipairs(NS_TABLES) do
		if type(ns[k]) ~= "table" then ns[k] = {} end
		RestoreInto(ns[k], sb.nsT[k])
	end
	for name, e in pairs(ModTables()) do
		local saved = sb.mod[name]
		if saved then
			for f, box in pairs(saved) do
				local v = box[1]
				if type(v) == "table" and type(e[1][f]) == "table" then RestoreInto(e[1][f], v)
				else e[1][f] = Copy(v) end
			end
		end
	end
	if GoldSentinelGame and GoldSentinelGame.SetTestFlavor then pcall(GoldSentinelGame.SetTestFlavor, nil) end
	ns.testBait = nil
	-- Anzeigen wie vorher
	for k, shown in pairs(sb.frames or {}) do
		local m = ns[k]
		if m and m.f then if shown then m.f:Show() else m.f:Hide() end end
	end
	if ns.UpdateSpells then pcall(ns.UpdateSpells, ns) end
end

-- nach der Wiederherstellung: stimmt alles?
function R:CheckSandbox()
	local sb = self.sb
	local d = Diff(ThreatSentinelDB or {}, sb.db, "ThreatSentinelDB", true)
	if d then return false, d end
	if ns.db ~= sb.profile or ThreatSentinelDB ~= sb.dbRef then return false, "ns.db getrennt" end
	if ns.profileName and ThreatSentinelDB.profiles and ThreatSentinelDB.profiles[ns.profileName] ~= ns.db then
		return false, "ns.db ~= profiles[profil]"
	end
	return true
end

function R:CheckCVars()
	for _, c in ipairs(CVARS) do
		if GetCV(c) ~= self.sb.cvars[c] then return false, c end
	end
	return true
end

function R:CheckKeys()
	if not (ns.Taunt and ns.Taunt.BIND and GetBindingKey) then return true end
	for which, cmd in pairs(ns.Taunt.BIND) do
		local k1, k2 = GetBindingKey(cmd)
		local now = tostring(k1) .. "/" .. tostring(k2)
		if now ~= self.sb.keys[which] then return false, which end
	end
	return true
end

------------------------------------------------------------
-- Livedaten (Entscheid des Nutzers 20.11.2026 08:39, auftraege/hinweis-test-keine-livedaten-2026-11-20.txt):
-- "Der Ingame-Test darf Livedaten nie verändern." Die Sandbox oben deckt ThreatSentinelDB ohne die gemeinsamen gs*-Schlüssel ab.
-- Hier zusätzlich alles Gespeicherte, das andere Addons lesen: das Sync-Adressbuch (liegt auch in fremden Datenbanken),
-- der Marktspeicher und jeder gs*-Schlüssel von ThreatSentinelDB. Ausgenommen ist nur gsTest: dort legt GoldSentinelTest
-- den Testbericht dieses Laufs ab (das ist die Ausgabe des Tests, keine Livedaten).
-- Vorher Kopie, nachher Vergleich; jede Abweichung = FEHLER mit Tabelle und Feld, die Daten werden zurückgesetzt.
-- Marktdaten, die während des Laufs echt aus der Gilde ankommen (Zähler "angenommen" steigt), sind keine Änderung durch den Test.
------------------------------------------------------------
R.LIVE_SKIP = { gsTest = true }

function R.LiveTables()
	local out = {}
	local G = rawget(_G, "GoldSentinelSync")
	if type(G) == "table" and type(G.book) == "table" then out[#out + 1] = { "GoldSentinelSync.book", G.book } end
	local M = rawget(_G, "GoldSentinelMarkt")
	if type(M) == "table" and type(M.store) == "table" then out[#out + 1] = { "GoldSentinelMarkt.store", M.store, market = true } end
	local keys = {}
	for k, v in pairs(ThreatSentinelDB or {}) do
		if IsGsKey(k) and not R.LIVE_SKIP[k] and type(v) == "table" then keys[#keys + 1] = k end
	end
	table.sort(keys)
	for _, k in ipairs(keys) do
		local v = ThreatSentinelDB[k]
		out[#out + 1] = { "ThreatSentinelDB." .. k, v, market = (type(M) == "table" and v == M.store) or k:find("^gsMarkt") ~= nil }
	end
	return out
end

local function MarketAccepted()
	local M = rawget(_G, "GoldSentinelMarkt")
	return type(M) == "table" and type(M.stats) == "table" and (tonumber(M.stats.accepted) or 0) or 0
end

function R:LiveSnap()
	local snap = { list = {}, accepted = MarketAccepted() }
	for _, e in ipairs(R.LiveTables()) do
		snap.list[#snap.list + 1] = { name = e[1], ref = e[2], copy = Copy(e[2]), market = e.market }
	end
	return snap
end

-- Vergleich: Liste der Abweichungen ("Tabelle.Feld"), dazu Hinweise (echter Marktempfang). restore = true setzt zurück.
function R:LiveCheck(snap, restore)
	local bad, notes = {}, {}
	if not snap then return bad, notes end
	local received = MarketAccepted() - (snap.accepted or 0)
	local seen = {}
	for _, e in ipairs(snap.list) do
		local d = Diff(e.ref, e.copy, e.name)
		if d then
			if e.market and received > 0 then
				notes[#notes + 1] = string.format("%s: echter Empfang aus der Gilde (%d angenommen) – kein Test", e.name, received)
			else
				-- Spielernamen im Adressbuch nie in den Bericht: Feld nach "book" als <Name>
				bad[#bad + 1] = (d:gsub("(book%.)[^%.]+", "%1<Name>"))
				if restore then RestoreInto(e.ref, e.copy) end
			end
		end
		seen[e.name] = true
	end
	-- neu angelegte gemeinsame Tabelle (gs*-Schlüssel, der vorher nicht da war)
	for _, e in ipairs(R.LiveTables()) do
		if not seen[e[1]] then
			bad[#bad + 1] = e[1] .. " (neu)"
			if restore and e[1]:find("^ThreatSentinelDB%.") then ThreatSentinelDB[e[1]:sub(18)] = nil end
		end
	end
	return bad, notes
end

------------------------------------------------------------
-- Prüfungen
------------------------------------------------------------
-- TR-ALLE (2.5.16): Bereiche laufen in einer Coroutine; nach jeder Prüfung wird abgegeben, sobald in diesem Bild
-- R.FRAME_MS verbraucht sind (kein Ruckeln). Nie innerhalb von WithAPI/Scene.Run (R.noYield > 0): dort sind Einträge
-- ersetzt, und ein Abgeben über pcall hinweg ist in Lua 5.1 nicht erlaubt.
-- NP-TS16-1 (2.5.17): abgegeben wird VOR einer Prüfung, sobald R.FRAME_MS (2 ms) im Bild verbraucht sind – so bleibt eine
-- Portion auch mit einer langsamen Prüfung meist unter R.FRAME_LIMIT (5 ms, Auftrag TR-ALLE). Ob das stimmt, wird gemessen:
-- Dauer jeder Portion (R.portionMax, über 5 ms gezählt) und jeder einzelnen Prüfung (allein über 5 ms: mit Namen).
R.FRAME_MS_STD = 2          -- Budget je Bild bis zur nächsten Abgabe
R.FRAME_MS = R.FRAME_MS_STD
R.FRAME_LIMIT = 5           -- Ziel je Bild (Auftrag TR-ALLE), gemessen und berichtet
R.STEP_LIMIT = 16           -- leistung.md Regel 8: Schritte über 16 ms mit Namen
R.T90_CHUNK = 6             -- T90: Schalter je Teil-Prüfung (zwischen den Teilen wird abgegeben)
R.TU3_CHUNK = 15            -- TU3-D2: Felder je Teil-Prüfung (Befund 18.11.: am Stück 43,4 ms)
R.K2_FAKE_W, R.K2_FAKE_H = 120, 80   -- T-K2/T-D2: kleines Testfenster über der Ecke der Testzentrale (Befund 18.11.)
R.TICK_ALLOC_KB = 40        -- T140: obere Schranke je Durchlauf mit 10 Gegnern, Nachbau mitgezählt (offline gemessen 23,4 KB)
R.noYield = 0
function R.Now() return Ms() end   -- Uhr (in T-TR1 ersetzbar; keine Blizzard-Funktion)
local function MaybeYield()
	local co = R.co
	if not co or R.noYield > 0 or coroutine.running() ~= co then return end
	if R.Now() - (R.frameStart or 0) < R.FRAME_MS then return end
	R.yields = (R.yields or 0) + 1
	coroutine.yield()
end
-- Dauer einer einzelnen Prüfung messen; allein über R.FRAME_LIMIT -> mit Namen in die Zusammenfassung
local function Timed(id, fn, ...)
	MaybeYield()
	R.lastCheckId = id
	local t0 = R.Now()
	local a = fn(...)
	local d = R.Now() - t0
	if d > R.FRAME_LIMIT and R.slowChecks then R.slowChecks[#R.slowChecks + 1] = string.format("%s %.1f ms", id, d) end
	return a
end
R.Timed = Timed

-- R.seen: jede in diesem Lauf gemeldete Prüfung mit Ergebnis (TU6: Regressionstest vorhanden?)
local function Seen(id, status) if R.seen then R.seen[id] = status end; R.done = (R.done or 0) + 1 end
local function C(id, area, name, fn)
	local ok = Timed(id, RUN.Check, RUN, id, area, name, fn)
	Seen(id, ok and "OK" or "FEHLER")
	return ok
end
local function K(id, area, name, why) Timed(id, RUN.Skip, RUN, id, area, name, why); Seen(id, "SKIP") end
local function CL(id, area, name, how) Timed(id, RUN.Client, RUN, id, area, name, how); Seen(id, "CLIENT") end

local NO_STUB = "noch nicht automatisiert (Test-Kulisse vorhanden, Fall folgt)"
-- noch nicht automatisierte Fälle: gezählt und im Bericht als "nicht automatisiert: N" ausgewiesen
local function KN(id, area, name)
	R.notAuto = (R.notAuto or 0) + 1
	RUN:Skip(id, area, name, NO_STUB)
	Seen(id, "SKIP")
end

-- Ausgabe einer Funktion abfangen (ns:Print, TM:Say)
local function Capture(fn)
	local lines = {}
	Swap(ns, "Print", function(_, msg) lines[#lines + 1] = tostring(msg) end)
	if ns.Test then Swap(ns.Test, "Say", function(_, msg) lines[#lines + 1] = "[Test] " .. tostring(msg) end) end
	local ok, err = pcall(fn)
	UnswapAll()
	if not ok then error(err, 0) end
	return lines
end

local function Has(lines, text)
	if not text then return false end
	for _, l in ipairs(lines) do if l:find(text, 1, true) then return true end end
	return false
end

------------------------------------------------------------
-- ns.API-Einträge vorübergehend ersetzen (nie die Blizzard-Funktion selbst)
------------------------------------------------------------
local NIL = {}   -- Platzhalter: Eintrag fehlt (wie eine im Client fehlende Funktion)
local function WithAPI(map, fn)
	local A = ns.API
	local saved, bait = {}, ns.testBait
	for k, v in pairs(map) do
		saved[k] = { rawget(A, k) }
		if v == NIL then A[k] = nil else A[k] = v end
	end
	ns.testBait = SECRET
	local function finish(ok, ...)
		for k, box in pairs(saved) do A[k] = box[1] end
		ns.testBait = bait
		if not ok then error((...), 0) end
		return ...
	end
	R.noYield = R.noYield + 1
	local function done(...) R.noYield = R.noYield - 1; return ... end
	return done(finish(pcall(fn)))
end
local function Ret(...)
	local n, v = select("#", ...), { ... }
	return function() return unpack(v, 1, n) end
end
local function Num(x) return type(x) == "number" and x or -1 end

------------------------------------------------------------
-- Test-Kulisse: Test-Einheiten, Gruppe, Bedrohung und Plaketten – nur über ns.API-Einträge und die eigenen
-- Vorschau-Plaketten der Testzentrale (keine Blizzard-Plakette, keine Blizzard-Funktion wird angefasst)
------------------------------------------------------------
local Scene = {}
R.Scene = Scene

-- Standard: du (Tank) + Magier (DD) + Priester (Heiler) + Krieger (zweiter Tank) und nMobs Testmobs,
-- jeder Mob wird von dir gehalten
function Scene.New(nMobs)
	local sc = { units = {}, threat = {}, alias = {}, plates = {}, forbidden = {}, group = { "party1", "party2", "party3" },
		tank = true, centers = {}, plays = 0 }
	sc.units.player = { name = "Anna", player = true, class = ns.class or "WARRIOR", combat = true, power = 1 }
	sc.units.party1 = { name = "Torben", player = true, class = "MAGE", role = "DAMAGER", combat = true, power = 0 }
	sc.units.party2 = { name = "Lina", player = true, class = "PRIEST", role = "HEALER", combat = true, power = 0 }
	sc.units.party3 = { name = "Grimbar", player = true, class = "WARRIOR", role = "TANK", combat = true, power = 1 }
	sc.nMobs = nMobs or 5
	for i = 1, sc.nMobs do
		local u = "tsfake" .. i
		sc.units[u] = { name = "Testmob " .. i, guid = string.format("Creature-0-0-0-0-91%03d-%010d", i, i), hostile = true,
			combat = true, hp = 80, hpMax = 100 }
	end
	for i = 1, sc.nMobs do Scene.Hold(sc, "tsfake" .. i, "player") end
	return sc
end

-- Wer hält den Mob? others = { party1 = 95 } (Anteil in % der Bedrohung des Halters)
function Scene.Hold(sc, mob, holder, others)
	local t = {}
	if holder then t[holder] = { true, 3, 100, 100, 1000 } end
	for unit, pct in pairs(others or {}) do t[unit] = { false, pct >= 100 and 1 or 0, pct, pct, pct * 10 } end
	sc.threat[mob] = t
	sc.alias[mob .. "target"] = holder
end

function Scene.Map(sc)
	local U = sc.units
	-- 2.5.17 (TU1-L04t): die Szene erzeugt selbst keine geschützten Zeichenketten (Köder SECRET ist kein String), daher
	-- reicht die Typprüfung. Vorher rief jeder Nachbau-Aufruf ns.IsSecret - das war im Spiel ein grosser Teil der 10,3 ms.
	local function real(u)
		if type(u) ~= "string" then return nil end
		return sc.alias[u] or u
	end
	local function get(u) local r = real(u); return r and U[r] or nil end
	local function f(fn) return function(u, ...) return fn(get(u), u, ...) end end
	local function threat(u, mob)
		local t = sc.threat[real(mob) or ""]
		return t and t[real(u) or ""]
	end
	local group = sc.group or {}
	return {
		UnitExists = f(function(e) return e ~= nil end),
		UnitName = f(function(e) if e then return e.name, e.realm end end),
		UnitGUID = f(function(e) return e and e.guid end),
		UnitIsUnit = function(a, b) local x, y = real(a), real(b); return x ~= nil and U[x] ~= nil and x == y end,
		UnitIsPlayer = f(function(e) return e and e.player or false end),
		UnitClass = f(function(e) if e and e.class then return e.class, e.class end end),
		UnitPowerType = f(function(e) return e and e.power or 1 end),
		UnitCanAttack = function(_, u) local e = get(u); return e and e.hostile or false end,
		UnitIsDeadOrGhost = f(function(e) return e and e.dead or false end),
		UnitIsDead = f(function(e) return e and e.dead or false end),
		UnitAffectingCombat = f(function(e) return e and e.combat or false end),
		UnitIsConnected = f(function(e) return e ~= nil end),
		UnitHealth = f(function(e) return e and e.hp or 100 end),
		UnitHealthMax = f(function(e) return e and e.hpMax or 100 end),
		UnitInRange = f(function(e) return e ~= nil, true end),
		GetRaidTargetIndex = f(function(e) return e and e.mark end),
		UnitGroupRolesAssigned = f(function(e) return e and e.role or "NONE" end),
		GetPartyAssignment = function() return false end,
		UnitBuff = function() return nil end,
		UnitDebuff = function() return nil end,
		UnitDetailedThreatSituation = function(u, mob)
			if sc.secret then return SECRET, SECRET, SECRET, SECRET, SECRET end
			local r = threat(u, mob)
			if r then return r[1], r[2], r[3], r[4], r[5] end
		end,
		UnitThreatSituation = function(u, mob)
			if sc.secret then return SECRET end
			local r = threat(u, mob)
			return r and r[2] or nil
		end,
		IsInGroup = Ret(#group > 0 or sc.raid ~= nil),
		IsInRaid = Ret(sc.raid ~= nil),
		GetNumSubgroupMembers = Ret(#group),
		GetNumGroupMembers = Ret(sc.raid or (#group + 1)),
		C_NamePlate = {
			GetNamePlateForUnit = function(u)
				local r = real(u)
				local uf = r and sc.plates[r]
				if not uf then return nil end
				local p = { UnitFrame = uf, namePlateUnitToken = r }
				if sc.forbidden[r] then p.IsForbidden = function() return true end end
				return p
			end,
			GetNamePlates = function() return {} end,
		},
	}
end

-- fn(sc) in der Kulisse ausführen. Danach ist alles wie vorher: ns.mobs, Gruppe, Besitzer, Sync-Rollen,
-- Anführer, Zwischenspeicher, Vorschau-Plaketten, ersetzte Funktionen.
function Scene.Run(sc, fn)
	local TM, TA, S = ns.Test, ns.ThreatAccess, ns.Sync
	TM:CreatePreview()
	local pp = TM.preview.plates
	for i = 1, sc.nMobs do
		local u = "tsfake" .. i
		if sc.plates[u] == nil then sc.plates[u] = pp[(i - 1) % #pp + 1] end
	end
	local save = {
		mobs = {}, owners = Copy(ns.owners), syncRoles = Copy(ns.syncRoles), claims = Copy(S.claims or {}),
		taunts = Copy(S.taunts or {}), extras = Copy(ns.Alerts.extras or {}),
		gu = ns.groupUnits, gn = ns.groupNames, nu = ns.nameToUnit, member = ns.memberNow, leader = ns.aggroLeader,
		leaderT = ns.aggroLeaderT, lastTankT = ns.lastTankT, lastMode = ns.Threat.lastMode, access = ns.threatAccess,
		simAccess = ns.simAccess, checked = TA.checked, announced = TA.announced, want = TA.wantBlizzard,
		inFight = TA.inFight, openSeen = TA.openSeen, secretSeen = TA.secretSeen, openVotes = TA.openVotes,
		stored = ThreatSentinelDB and ThreatSentinelDB.threatAccess, testMode = ns.testMode, liveTest = ns.liveTest,
	}
	for k, v in pairs(ns.mobs) do save.mobs[k] = v end
	wipe(ns.mobs)
	for i = 1, sc.nMobs do ns.mobs["tsfake" .. i] = { unit = "tsfake" .. i } end
	ns:ClearRoleCache()
	ns.memberNow, ns.testMode, ns.liveTest = false, false, false
	TA.checked = true
	-- Kulisse = lesbare Werte, auch wenn das Spiel "secret" gespeichert hat (T153 im Client); Tests, die geschützte
	-- Werte brauchen, setzen das selbst. Der echte Zustand wird in finish wiederhergestellt.
	if ns.isModern then ns.threatAccess = "open" end
	Swap(ns, "IsTankStance", function() return sc.tank and true or false end)
	Swap(ns.Alerts, "Center", function(_, text) sc.centers[#sc.centers + 1] = tostring(text) end)
	Swap(ns.Alerts, "Play", function() sc.plays = sc.plays + 1 end)
	Swap(TA, "ApplyBlizzard", function() end)
	local function finish(ok, ...)
		UnswapAll()
		for u in pairs(ns.mobs) do ns.Track:Forget("plate:" .. u) end
		for _, e in pairs(sc.units) do if e.guid then ns.Track:Forget(e.guid) end end
		wipe(ns.mobs)
		for k, v in pairs(save.mobs) do ns.mobs[k] = v end
		RestoreInto(ns.owners, save.owners)
		RestoreInto(ns.syncRoles, save.syncRoles)
		if S.claims then RestoreInto(S.claims, save.claims) end
		if S.taunts then RestoreInto(S.taunts, save.taunts) end
		if ns.Alerts.extras then RestoreInto(ns.Alerts.extras, save.extras) end
		ns.groupUnits, ns.groupNames, ns.nameToUnit = save.gu, save.gn, save.nu
		ns.memberNow, ns.aggroLeader, ns.aggroLeaderT, ns.lastTankT = save.member, save.leader, save.leaderT, save.lastTankT
		ns.Threat.lastMode, ns.threatAccess, ns.simAccess = save.lastMode, save.access, save.simAccess
		TA.checked, TA.announced, TA.wantBlizzard = save.checked, save.announced, save.want
		TA.inFight, TA.openSeen, TA.secretSeen, TA.openVotes = save.inFight, save.openSeen, save.secretSeen, save.openVotes
		if ThreatSentinelDB then ThreatSentinelDB.threatAccess = save.stored end
		ns.testMode, ns.liveTest = save.testMode, save.liveTest
		ns:ClearRoleCache()
		for _, uf in ipairs(pp) do
			pcall(ns.Plates.RestoreFrame, ns.Plates, uf)
			if ns.Plates.pendingRestore then ns.Plates.pendingRestore[uf] = nil end
		end
		if not ok then error((...), 0) end
		return ...
	end
	R.noYield = R.noYield + 1
	local function done(...) R.noYield = R.noYield - 1; return ... end
	return done(finish(pcall(WithAPI, Scene.Map(sc), function()
		ns:UpdateGroup()
		return fn(sc)
	end)))
end

-- zählt Aufrufe einer Modul-Funktion (die echte läuft weiter, ausser pass == false)
local function Counter(tbl, key, pass)
	local c = { n = 0 }
	local orig = tbl[key]
	Swap(tbl, key, function(...)
		c.n = c.n + 1
		if pass ~= false and orig then return orig(...) end
	end)
	return c
end

local function Shown(f) return f and f:IsShown() and true or false end

local function FormatStem(fmt)
	-- fester Anfang eines Formattexts (bis zum ersten Platzhalter), zum Wiederfinden in der Ausgabe
	return (fmt or ""):match("^([^%%]*)") or ""
end

local function WithFlavor(f, fn)
	local G = GoldSentinelGame
	G.SetTestFlavor(f)
	ns.isModern = G.IsModern and true or false
	local ok, a, b, c = pcall(fn)
	G.SetTestFlavor(nil)
	ns.isModern = G.IsModern and true or false
	if not ok then error(a, 0) end
	return a, b, c
end

------------------------------------------------------------
-- A. Laden und Erkennung
------------------------------------------------------------
local Area = {}

Area.A = function()
	local G = GoldSentinelGame
	C("T01", "A", "Alle Dateien und Module geladen", function()
		local need = { "L", "Game", "Plates", "Donate", "Alerts", "DD", "DmgMeter", "Guide", "HUD", "Log", "Meter", "Mover",
			"Options", "Specs", "Sync", "Taunt", "Test", "Threat", "ThreatAccess", "Track", "Routine" }
		local miss = {}
		for _, k in ipairs(need) do if ns[k] == nil then miss[#miss + 1] = k end end
		if not GoldSentinelTest then miss[#miss + 1] = "GoldSentinelTest" end
		if #miss > 0 then return false, table.concat(miss, ","), "nichts fehlt" end
		return #ns.modules == 16, "#modules=" .. #ns.modules, "16"
	end)
	C("T02", "A", "Version .toc = Code", function()
		local get = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
		local toc = get and get(ADDON, "Version")
		return toc == ns.version, S(toc), ns.version
	end)
	C("T03", "A", "GoldSentinelGame Version 2 oder neuer (Funktionen)", function()
		if not G then return false, "fehlt", "vorhanden" end
		local miss = {}
		for _, k in ipairs({ "flavor", "IsModern", "IsOldAPI", "HasSecrets", "IsSecret", "AnySecret", "Safe", "InCombat",
			"Short", "CleanName", "SameName", "Status", "SetTestFlavor", "Recalc" }) do
			if G[k] == nil then miss[#miss + 1] = k end
		end
		for _, k in ipairs({ "IsEra", "IsForever", "IsTBC", "IsWrath", "IsTitan", "IsCata", "IsMists", "IsRetail" }) do
			if G[k] == nil then miss[#miss + 1] = k end
		end
		if #miss > 0 then return false, table.concat(miss, ","), "alles vorhanden" end
		if type(G.version) ~= "number" or G.version < 2 or type(G.apiVersion) ~= "number" or G.apiVersion < 2 then
			return false, S(G.version) .. "/" .. S(G.apiVersion), "2 oder neuer"
		end
		return ns.Game == G and type(G.Status()) == "string", "ns.Game", "GoldSentinelGame"
	end)
	C("T04", "A", "Erkennung echt", function()
		local A, DM, TA = ns.Alerts, ns.DmgMeter, ns.ThreatAccess
		if ns.isModern ~= (G.IsModern and true or false) then return false, "isModern " .. S(ns.isModern), S(G.IsModern) end
		if ns.isRetail ~= (G.IsRetail and true or false) then return false, "isRetail " .. S(ns.isRetail), S(G.IsRetail) end
		if ns.flavor ~= G.flavor then return false, S(ns.flavor), S(G.flavor) end
		if A.cleuAllowed ~= (not ns.isModern) or A.cleuRegistered ~= A.cleuAllowed then return false, "cleu " .. S(A.cleuAllowed) .. "/" .. S(A.cleuRegistered), S(not ns.isModern) end
		if DM.allowed ~= (not ns.isModern) then return false, "DM.allowed " .. S(DM.allowed), S(not ns.isModern) end
		if not ns.isModern and (ns.threatAccess ~= "open" or TA.checked ~= true) then return false, S(ns.threatAccess) .. "/" .. S(TA.checked), "open/true" end
		return true, (ns.isModern and "modern" or "alt") .. "/" .. S(ns.flavor)
	end)
	C("T05", "A", "Simulation G.SetTestFlavor – GoldSentinelGame", function()
		local want = { forever = { "IsForever", "IsModern" }, era = { "IsEra", "IsOldAPI" }, tbc = { "IsTBC", "IsOldAPI" }, retail = { "IsRetail", "IsModern" } }
		local bad
		for f, keys in pairs(want) do
			G.SetTestFlavor(f)
			for _, k in ipairs(keys) do if not G[k] then bad = f .. ":" .. k end end
			if not (tostring(G.Status()):lower()):find("[test]", 1, true) then bad = f .. ":Status ohne [Test]" end
			G.SetTestFlavor(nil)
			if bad then break end
		end
		return bad == nil, bad or "ok", "alle Simulationen richtig"
	end)
	C("T06", "A", "Simulation – Weichen des Addons (ohne Kampfsperre-Teile)", function()
		local db, cls = ns.db, ns.class
		local saveAcc, saveMode = ns.threatAccess, db.threatMode
		local bad
		for _, f in ipairs({ "forever", "era", "tbc", "retail" }) do
			WithFlavor(f, function()
				local modern = ns.isModern
				ns.threatAccess = "unknown"
				db.threatMode = "AUTO"
				if ns:ThreatMode() ~= "FULL" then bad = f .. ": unknown ausserhalb Kampf " .. ns:ThreatMode() end
				db.threatMode = "DISPLAY"
				local m = ns:ThreatMode()
				if modern and m ~= "DISPLAY" then bad = f .. ": DISPLAY erzwungen -> " .. m end
				if not modern and m ~= "FULL" then bad = f .. ": alt DISPLAY -> " .. m end
				ns.class = "DRUID"
				local t = ns:DeficitText()
				if modern and t ~= L.DEFICIT_OTHER then bad = f .. ": Druide " .. S(t) end
				if not modern and t ~= L.DEFICIT_DRUID then bad = f .. ": Druide " .. S(t) end
				ns.class = cls
			end)
			ns.threatAccess, db.threatMode = saveAcc, saveMode
			if bad then break end
		end
		ns.class = cls
		return bad == nil, bad or "ok", "Weichen wie angegeben"
	end)
	C("T07", "A", "Beim Laden festgelegte Weichen bleiben", function()
		local A, DM = ns.Alerts, ns.DmgMeter
		local a1, a2, a3 = A.cleuAllowed, A.cleuRegistered, DM.allowed
		local b1, b2, b3 = WithFlavor(ns.isModern and "era" or "forever", function() return A.cleuAllowed, A.cleuRegistered, DM.allowed end)
		return a1 == b1 and a2 == b2 and a3 == b3, "Kampflog/Meter: Simulation erst nach /reload", "unverändert"
	end)
	C("T08", "A", "Weichen wieder echt", function()
		G.SetTestFlavor(nil)
		local st = tostring(G.Status())
		return ns.isModern == (G.IsModern and true or false) and not st:lower():find("[test]", 1, true), S(ns.isModern), S(G.IsModern)
	end)
	C("T09", "A", "Ereignisse angemeldet", function()
		local miss = {}
		for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "NAME_PLATE_UNIT_ADDED",
			"NAME_PLATE_UNIT_REMOVED", "UNIT_THREAT_LIST_UPDATE", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_HEALTH",   -- CHAT_MSG_ADDON: GoldSentinelSync
			"GROUP_ROSTER_UPDATE", "UNIT_PET", "UNIT_AURA", "UPDATE_SHAPESHIFT_FORM", "ADDON_ACTION_BLOCKED", "ADDON_ACTION_FORBIDDEN",
			"SPELLS_CHANGED", "INSPECT_READY" }) do
			if not ns:HasHandler(e) then miss[#miss + 1] = e end
		end
		if #miss > 0 then return false, table.concat(miss, ","), "alle angemeldet" end
		local cleu = ns:HasHandler("COMBAT_LOG_EVENT_UNFILTERED")
		if cleu ~= (not ns.isModern) then return false, "Kampflog " .. S(cleu), S(not ns.isModern) end
		local okOn, res = pcall(ns.On, ns, "TS_GIBT_ES_NICHT", function() end)
		return okOn and res == false, S(res), "false"
	end)
	C("T10", "A", "Befehle angemeldet", function()
		return SLASH_THREATSENTINEL1 == "/ts" and SLASH_THREATSENTINEL2 == "/threatsentinel"
			and type(SlashCmdList.THREATSENTINEL) == "function" and SlashCmdList.GOLDSENTINELGAME ~= nil
			and SlashCmdList.GOLDSENTINELDEV ~= nil, "ok", "/ts, /threatsentinel, /gsgame, /gsdev"
	end)
	CL("T11", "A", "Interface-Nummer des Clients in der .toc", "Interface steht in der Kopfzeile des Berichts; die Prüf-Sitzung vergleicht sie mit ## Interface (am Launch-Tag /dump select(4, GetBuildInfo()))")
end

------------------------------------------------------------
-- B. Jede Funktion des Addons
------------------------------------------------------------
Area.B = function()
	local TA, A, Sy = ns.ThreatAccess, ns.Alerts, ns.Sync
	C("T12", "B", "ns.IsSecret / ns.Safe", function()
		ns.testBait = SECRET
		ns.simSecret = true
		local r = { ns.IsSecret(5, "auras"), ns.IsSecret(nil, "auras"), ns.IsSecret(5), ns.IsSecret(5, "gibtsnicht") }
		local s1, s2 = ns.Safe(5, 0, "auras")
		ns.simSecret = false
		local s3, s4 = ns.Safe(5, 0, "auras")
		local bait = ns.IsSecret(SECRET) and ns.IsSecret(SECRET, "auras")
		ns.testBait = nil
		local ok = r[1] == true and r[2] == false and r[3] == false and r[4] == false and s1 == 0 and s2 == true
			and s3 == 5 and s4 == false and bait
		return ok, string.format("%s %s %s %s | %s %s | %s %s | Köder %s", S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(s1), S(s2), S(s3), S(s4), S(bait)),
			"true false false false | 0 true | 5 false | Köder true"
	end)
	C("T13", "B", "ns:Compat / ResetCompat", function()
		ns:Compat("guid", "ok"); ns:Compat("guid", "off"); ns:Compat("guid", "ok")
		local c = ns.compat.guid
		local ok = c and c.mode == "ok" and c.worst == "off"
		ns:ResetCompat()
		return ok and next(ns.compat) == nil, c and (c.mode .. "/" .. c.worst), "ok/off, danach leer"
	end)
	C("T14", "B", "ns.SpellName / ns.SpellIcon", function()
		return ns.SpellName(355) ~= nil and ns.SpellIcon(355) ~= nil, "355", "Name und Symbol"
	end)
	C("T15", "B", "ReadCooldown / ns.SpellCD (über ns.API)", function()
		local now = GetTime()
		local saveMode = ns.tauntMode
		ns.tauntMode = "hostile"
		local r = {}
		WithAPI({ GetSpellCooldown = Ret(now - 2, 10) }, function()
			r[1] = ns.SpellCD("TSTest"); r[2] = ns.compat.cooldowns and ns.compat.cooldowns.mode
		end)
		WithAPI({ GetSpellCooldown = Ret(now, 1.5) }, function() r[3] = ns.SpellCD("TSTest") end)
		ns.cdTrack.TSTest = now + 4
		WithAPI({ GetSpellCooldown = Ret(SECRET, SECRET) }, function()
			r[4] = ns.SpellCD("TSTest"); r[5] = ns.compat.cooldowns and ns.compat.cooldowns.mode
		end)
		WithAPI({ GetSpellCooldown = NIL, C_Spell = { GetSpellCooldown = function() return { startTime = now - 2, duration = 10 } end } },
			function() r[6] = ns.SpellCD("TSTest") end)
		ns.cdTrack.TSTest = nil
		ns.tauntMode = saveMode
		local ok = Near(r[1], 8, 0.1) and r[2] == "ok" and r[3] == 0 and Near(r[4], 4, 0.1) and r[5] == "fallback" and Near(r[6], 8, 0.1)
		return ok, string.format("%.1f %s / %s / %.1f %s / %.1f", Num(r[1]), S(r[2]), S(r[3]), Num(r[4]), S(r[5]), Num(r[6])),
			"8 ok / 0 / 4 fallback / 8 (C_Spell)"
	end)
	C("T16", "B", "ns:BaseCooldown (gelernter Wert hat Vorrang)", function()
		ns.db.cdLearned = ns.db.cdLearned or {}
		ns.db.cdLearned.TestSpott = 7
		local v = ns:BaseCooldown("TestSpott")
		ns.db.cdLearned.TestSpott = nil
		local none = ns:BaseCooldown("GibtsNicht")
		return v == 7 and none == nil, S(v) .. "/" .. S(none), "7/nil"
	end)
	C("T17", "B", "ns.SpellInRange (über ns.API)", function()
		local out = {}
		for _, v in ipairs({ true, false, 1, 0, NIL, SECRET }) do
			local val = v
			if v == NIL then val = nil end
			out[#out + 1] = S(WithAPI({ IsSpellInRange = Ret(val) }, function() return ns.SpellInRange("TSTest", "target") end))
		end
		local mode = ns.compat.range and ns.compat.range.mode
		local got = table.concat(out, "/")
		return got == "true/false/true/false/nil/nil" and mode == "off", got .. " " .. S(mode), "true/false/true/false/nil/nil off"
	end)
	C("T18", "B", "ns.Aura / ns:FindAura (alter und moderner Weg)", function()
		local list
		local function old(unit, i) local a = list[i]; if a then return a[1], nil, 1, nil, nil, nil, nil, nil, nil, a[2] end end
		local function new(unit, i) local a = list[i]; if a then return { name = a[1], applications = 1, spellId = a[2] } end end
		local res = {}
		local function run(map)
			map.UnitAffectingCombat = Ret(false)
			WithAPI(map, function()
				list = { { "TSAura", 71 } }
				local a1, b1 = ns:FindAura("player", "HELPFUL", { [71] = true })
				local a2, b2 = ns:FindAura("player", "HELPFUL", {}, { TSAura = true })
				list = {}
				local a3, b3 = ns:FindAura("player", "HELPFUL", { [71] = true })
				list = { { SECRET, 71 } }
				local a4, b4 = ns:FindAura("player", "HELPFUL", { [71] = true })
				res[#res + 1] = table.concat({ S(a1), S(b1), S(a2), S(b2), S(a3), S(b3), S(a4), S(b4) }, ",")
			end)
		end
		run({ UnitBuff = old, UnitDebuff = old })
		run({ UnitBuff = NIL, UnitDebuff = NIL, C_UnitAuras = { GetAuraDataByIndex = new } })
		local err = WithAPI({ UnitBuff = function() error("TS-Test") end, UnitDebuff = old }, function()
			local a, b = ns:FindAura("player", "HELPFUL", { [71] = true }); return S(a) .. "," .. S(b)
		end)
		local want = "true,true,true,true,false,true,false,false"
		return res[1] == want and res[2] == want and err == "false,false", res[1] .. " | " .. res[2] .. " | Fehler " .. err,
			want .. " (beide Wege), Fehler false,false"
	end)
	C("T19", "B", "ns:MobKey (über ns.API)", function()
		local k1, ok1 = WithAPI({ UnitGUID = Ret("Creature-0-1-2-3-4-5") }, function() return ns:MobKey("tsfake1") end)
		local k2, ok2 = WithAPI({ UnitGUID = Ret(SECRET) }, function() return ns:MobKey("tsfake1") end)
		local mode = ns.compat.guid and ns.compat.guid.mode
		return k1 == "Creature-0-1-2-3-4-5" and ok1 == true and k2 == "plate:tsfake1" and ok2 == false and mode == "fallback",
			S(ok1) .. " / " .. S(k2) .. " " .. S(ok2) .. " " .. S(mode), "GUID true / plate:tsfake1 false fallback"
	end)
	C("T20", "B", "ns:SameUnit (echte Einheiten)", function()
		local a, b = ns:SameUnit("player", "player"), ns:SameUnit("player", "tsfake1")
		return a == true and b == false, S(a) .. "/" .. S(b), "true/false"
	end)
	C("T21", "B", "ns:SpellbookHas mit leerem Namen", function()
		local a, b = ns:SpellbookHas(""), ns:SpellbookHas(nil)
		return not a and not b, S(a) .. "/" .. S(b), "false/false"
	end)
	C("T22", "B", "ns:FullName (eigener Charakter und Realm)", function()
		local n = ns:FullName("player")
		local own = type(n) == "string" and n ~= "" and not n:find("-", 1, true)
		-- WoW Forever liefert auch für den eigenen Charakter einen Realm: der gehört nicht in den Namen
		local realm = ns:PlayerRealm() or "TSHeimat"
		local saveRealm = ns.playerRealm
		ns.playerRealm = realm
		local names = { player = { "TSIch", realm }, party1 = { "Torben", realm }, party2 = { "Lina", "TSFremd" }, party3 = { "Grimbar", "" } }
		local r = WithAPI({ UnitName = function(u) local e = names[u]; if e then return e[1], e[2] end end }, function()
			return S(ns:FullName("player")) .. " " .. S(ns:FullName("party1")) .. " " .. S(ns:FullName("party2")) .. " " .. S(ns:FullName("party3"))
		end)
		ns.playerRealm = saveRealm
		local want = "TSIch Torben Lina-TSFremd Grimbar"
		return own and r == want, (own and "<Name>" or S(n)) .. " | " .. r, "<Name> ohne Realm | " .. want
	end)
	C("T23", "B", "ns:FormName / ns:SpecName", function()
		local a, b = ns:FormName(), ns:SpecName()
		return type(a) == "string" and type(b) == "string", "Text", "Text"
	end)
	C("T24", "B", "ns:UpdateSpells mit eigenem Spott", function()
		ns.db.tauntOverride = "TestSpott"
		ns:UpdateSpells()
		local ok = ns.tauntSpell == "TestSpott" and ns.tauntMode == "hostile"
		local got = S(ns.tauntSpell) .. "/" .. S(ns.tauntMode)
		ns.db.tauntOverride = ""
		ns:UpdateSpells()
		return ok, got, "TestSpott/hostile"
	end)
	C("T26", "B", "IsTankStance liefert einen Wahrheitswert", function()
		local v = ns:IsTankStance()
		return v == true or v == false, S(v), "true/false"
	end)
	C("T27", "B", "TankUnit / PetTankActive", function()
		local u = ns:TankUnit()
		local p = ns:PetTankActive()
		if ns.tauntMode ~= "pet" and p then return false, "PetTankActive true", "nur bei Pet-Spott" end
		return u == "player" or u == "pet", S(u), "player/pet"
	end)
	C("T28", "B", "IsActive / IsMemberMode", function()
		ns.db.enabled = false
		local a = ns:IsActive()
		local m = ns:IsMemberMode()
		ns.db.enabled = true
		ns.testMode = true
		local b = ns:IsActive()
		local mb = ns:IsMemberMode()
		ns.testMode = false
		return a == false and m == false and b == true and mb == false, S(a) .. S(m) .. S(b) .. S(mb), "false false true false"
	end)
	C("T31", "B", "MyRole / GetRole", function()
		ns.db.myRole = "HEALER"
		local r1 = ns:IsTankStance() and "TANK" or ns:MyRole()
		ns.db.myRole = "DAMAGER"
		local r2 = ns:IsTankStance() and "TANK" or ns:MyRole()
		ns:ClearRoleCache()
		local g = ns:GetRole("player")
		local okG = g == "TANK" or g == "HEALER" or g == "DAMAGER" or g == "PET"
		return (r1 == "HEALER" or r1 == "TANK") and (r2 == "DAMAGER" or r2 == "TANK") and okG, S(r1) .. "/" .. S(r2) .. "/" .. S(g), "HEALER/DAMAGER/Rolle"
	end)
	C("T32", "B", "Profile: geteiltes Profil (ReloadUI nur mitgeschrieben)", function()
		local before = ns.actLog.n.reload or 0
		ns:UseSharedProfile(true)
		local a = ThreatSentinelDB.chars[ns.charKey] == "Global" and ThreatSentinelDB.profiles.Global ~= nil and ns:IsSharedProfile()
		ns:UseSharedProfile(false)
		local b = ThreatSentinelDB.chars[ns.charKey] == ns.charKey and not ns:IsSharedProfile()
		local n = (ns.actLog.n.reload or 0) - before
		return a and b and n == 2, "ReloadUI " .. n .. "x mitgeschrieben", "2x, Profile richtig"
	end)
	C("T33", "B", "Voreinstellungen", function()
		for name, p in pairs(ns.PRESETS) do
			ns:ApplyPreset(name)
			for k, v in pairs(p) do if ns.db[k] ~= v then return false, name .. "." .. k, S(v) end end
		end
		local before = Copy(ns.db)
		ns:ApplyPreset("gibtsnicht")
		local d = Diff(ns.db, before, "db")
		return d == nil, d or "ok", "unverändert"
	end)
	C("T34", "B", "Positionen zurücksetzen", function()
		ns:ResetPositions()
		for _, k in ipairs({ "hudPoint", "ddPoint", "meterPoint", "dmgPoint" }) do
			if ns.db[k] == ns.defaults[k] then return false, k .. " dieselbe Tabelle", "Kopie" end
			if Diff(ns.db[k], ns.defaults[k], k) then return false, k, "wie Standard" end
		end
		return true
	end)
	C("T35", "B", "ns:IsBossFight ohne Fehler", function()
		local v = ns:IsBossFight()
		return v == true or v == false, S(v), "true/false"
	end)
	C("T36", "B", "Slash-Unterbefehle", function()
		local hits = {}
		local function mark(n) return function() hits[#hits + 1] = n end end
		Swap(ns.Log, "Command", mark("log")); Swap(ns.Test, "ToggleWindow", mark("test")); Swap(ns.Guide, "Start", mark("guide"))
		Swap(ns.Donate, "Show", mark("donate")); Swap(ns.ThreatAccess, "Report", mark("threat")); Swap(ns.Mover, "Toggle", mark("move"))
		Swap(ns.Options, "Toggle", mark("options")); Swap(ns.Routine, "Command", mark("routine"))
		local cases = { { "log status", "log" }, { "test", "test" }, { "guide", "guide" }, { "assistent", "guide" }, { "spenden", "donate" },
			{ "donate", "donate" }, { "support", "donate" }, { "bedrohung", "threat" }, { "threat", "threat" }, { "BEDROHUNG", "threat" },
			{ "verschieben", "move" }, { "move", "move" }, { "", "options" }, { "unbekannt", "options" }, { "testroutine x", "routine" } }
		local bad
		for _, c in ipairs(cases) do
			wipe(hits)
			SlashCmdList.THREATSENTINEL(c[1])
			if #hits ~= 1 or hits[1] ~= c[2] then bad = "'" .. c[1] .. "' -> " .. table.concat(hits, ",") break end
		end
		UnswapAll()
		return bad == nil, bad or "ok", "genau das richtige Ziel 1x"
	end)
	C("T37", "B", "ns:ThreatMode – Tabelle (ausserhalb des Kampfs)", function()
		local save = { ns.simAccess, ns.threatAccess, ns.db.threatMode, ns.isModern }
		local bad
		local function want(sim, acc, mode, modern, exp)
			ns.simAccess, ns.threatAccess, ns.db.threatMode, ns.isModern = sim, acc, mode, modern
			local m = ns:ThreatMode()
			if m ~= exp then bad = string.format("%s/%s/%s/%s -> %s", S(sim), S(acc), S(mode), S(modern), m) end
		end
		want("none", "open", "AUTO", true, "OFF"); want("secret", "open", "AUTO", true, "DISPLAY"); want("open", "open", "AUTO", true, "FULL")
		want(nil, "secret", "AUTO", true, "DISPLAY"); want(nil, "none", "AUTO", true, "OFF")
		want(nil, "open", "DISPLAY", true, "DISPLAY"); want(nil, "open", "DISPLAY", false, "FULL")
		want("open", "secret", "AUTO", true, "DISPLAY")   -- T173: Simulation "lesbar" übersteuert keine echte Sperre
		ns.simAccess, ns.threatAccess, ns.db.threatMode, ns.isModern = save[1], save[2], save[3], save[4]
		return bad == nil, bad or "ok", "Tabelle wie angegeben"
	end)
	C("T38", "B", "TA:ModeText", function()
		for _, m in ipairs({ "FULL", "DISPLAY", "OFF" }) do
			local t = TA:ModeText(m)
			if not t or t:find("^TA_MODE_") then return false, m .. " -> " .. S(t), "Text" end
		end
		return true
	end)
	C("T39", "B", "TA:Read ohne Ziel (echte API)", function()
		local f, s, miss = TA:Read("tsfake1")
		if not UnitDetailedThreatSituation and not UnitThreatSituation then return miss == true, S(miss), "missing" end
		return f == false and s == false and miss == false, S(f) .. S(s) .. S(miss), "false false false"
	end)
	C("T40", "B", "TA:Probe ohne Kampf ohne Wirkung", function()
		local before = { TA.checked, TA.attempts, ns.threatAccess }
		TA.checked = false
		TA:Probe({ "tsfake1" })
		local after = { TA.attempts, ns.threatAccess }
		return after[1] == before[2] and after[2] == before[3], S(after[1]) .. "/" .. S(after[2]), "unverändert"
	end)
	C("T42", "B", "TA:Set / Store", function()
		local shown = 0
		Swap(A, "Center", function(_, text) if text == L.TA_NOTE_DISPLAY then shown = shown + 1 end end)
		TA.announced = false
		ns.db.enabled = true
		TA:Set("secret")
		TA:Set("secret")
		UnswapAll()
		local st = ThreatSentinelDB.threatAccess
		local ok = ns.threatAccess == "secret" and TA.checked == true and type(st) == "table" and st.state == "secret"
			and type(st.date) == "string" and st.date:match("^%d%d%d%d%-%d%d%-%d%d %d%d:%d%d$") and type(st.build) == "string"
			and st.build:find("%(") and shown == 1
		return ok and true or false, string.format("%s, Hinweis %dx, %s", S(ns.threatAccess), shown, S(st and st.date)), "secret, Hinweis 1x, JJJJ-MM-TT HH:MM"
	end)
	C("T43", "B", "Neuer Kampf setzt die Prüfung zurück", function()
		TA.checked, TA.attempts, TA.announced = true, 5, true
		ns:Fire("PLAYER_REGEN_DISABLED")
		local got = S(TA.checked) .. "/" .. S(TA.attempts) .. "/" .. S(TA.announced)
		if ns.isModern then return TA.checked == false and TA.attempts == 0 and TA.announced == false, got, "false/0/false" end
		return TA.checked == true and TA.attempts == 5, got, "unverändert (alte API)"
	end)
	C("T44", "B", "ApplyBlizzard nur mitgeschrieben", function()
		local before = ns.actLog.n.cvar or 0
		ns.db.enabled, ns.db.blizzThreat = true, false
		TA.wantBlizzard = true
		TA:ApplyBlizzard()
		local n1 = (ns.actLog.n.cvar or 0) - before
		return n1 == 0 and TA.wantBlizzard == true, "blizzThreat aus: " .. n1 .. " CVar", "0, Wunsch bleibt"
	end)
	C("T45", "B", "Bedrohung prüfen – ausserhalb des Kampfs", function()
		local lines = Capture(function() TA:Report() end)
		local ok = Has(lines, FormatStem(L.TA_R_MODE)) and Has(lines, L.TA_R_NOCOMBAT) and Has(lines, FormatStem(L.TA_R_ERRORS))
			and (ns.isModern or Has(lines, L.TA_R_OLDAPI))
			and (Has(lines, FormatStem(L.TA_R_LAST)) or Has(lines, L.TA_R_NEVER))
		return ok, #lines .. " Zeilen", "Modus, Status, ausserhalb Kampf, zuletzt, Fehler"
	end)
	CL("T46", "B", "Bedrohung prüfen – im Kampf", "Mob angreifen, im Kampf /ts bedrohung: Status und Prozent (oder 'geschützt') erscheinen, kein Lua-Fehler")
	C("T47", "B", "TA:Login übernimmt den gespeicherten Zustand", function()
		local bad
		for _, c in ipairs({ { "open", "open" }, { "secret", "secret" }, { "none", "unknown" } }) do
			ThreatSentinelDB.threatAccess = { state = c[1], date = "2026-11-03 10:00", build = "x (1)" }
			ns.threatAccess = ns.isModern and "unknown" or "open"
			TA:Login()
			local exp = ns.isModern and c[2] or "open"
			if ns.threatAccess ~= exp then bad = c[1] .. " -> " .. S(ns.threatAccess) end
		end
		return bad == nil, bad or "ok", "open/secret übernommen, none nicht (alt immer open)"
	end)
	C("T51", "B", "Reihenfolge loser Mobs (SortLoose)", function()
		local list = {
			{ id = 1, mark = 0, victimRole = "DAMAGER", looseSince = 1 },
			{ id = 2, mark = 7, victimRole = "DAMAGER", looseSince = 5 },
			{ id = 3, mark = 8, victimRole = "DAMAGER", looseSince = 9 },
			{ id = 4, mark = 0, victimRole = "HEALER", looseSince = 8 },
			{ id = 5, mark = 0, victimRole = "DAMAGER", looseSince = 0 },
		}
		table.sort(list, ns.Threat.SortLoose)
		local ids = {}
		for i, e in ipairs(list) do ids[i] = e.id end
		local got = table.concat(ids, ",")
		return got == "3,2,4,5,1", got, "3,2,4,5,1"
	end)
	C("T60", "B", "Initial", function()
		local I = ns.Plates._Initial
		ns.testBait = SECRET
		local r = { I("Grimbar"), I("ärger"), I(""), I(nil), I(SECRET) }
		ns.testBait = nil
		-- string.upper kennt im Spiel keine Umlaute: "ä" bleibt "ä" (erlaubt); wichtig ist ein ganzes UTF-8-Zeichen
		local uml = r[2] == "Ä" or r[2] == "ä"
		return r[1] == "G" and uml and r[3] == "" and r[4] == "" and r[5] == "", r[1] .. "|" .. r[2] .. "|" .. r[3] .. "|" .. r[4] .. "|" .. r[5], "G|Ä|||"
	end)
	C("T62", "B", "Töne: Liste und Play (nur mitgeschrieben)", function()
		local bad
		for _, s in ipairs(ns.SOUNDS) do
			if s.key and ns:SoundByKey(s.key) ~= s then bad = "SoundByKey " .. s.key break end
			local lbl = ns:SoundLabel(s.key)
			if not lbl or lbl == s.key and s.key ~= "none" then bad = "SoundLabel " .. s.key break end
		end
		if bad then return false, bad, "jeder Ton auffindbar" end
		local r1 = A:Play("none", "trTest1")
		local before = ns.actLog.n.sound or 0
		ns.db.sound = true
		A:Play("fx_frosch", "trTest2" .. GetTime(), true)
		local n = (ns.actLog.n.sound or 0) - before
		return r1 == nil and n >= 1, "none -> " .. S(r1) .. ", Ton mitgeschrieben " .. n .. "x", "nil, mitgeschrieben"
	end)
	C("T63", "B", "Meldung in der Mitte: Vorrang", function()
		if not A.center then return false, "kein Rahmen", "Rahmen" end
		A:Center("tr-test", { 1, 1, 1 }, 2, "test")
		A:Center("tr-aoe", { 1, 1, 1 }, 2, "aoe")
		local t = A.center.text:GetText()
		A:ClearCenter("aoe")
		local still = A.center:IsShown()
		A:ClearCenter("test")
		return t == "tr-test" and still, S(t) .. "/" .. S(still), "tr-test/true"
	end)
	C("T64", "B", "Chat-Kanäle gehen nie hinaus", function()
		local before = ns.actLog.n.chat or 0
		local said = 0
		local lines
		for _, ch in ipairs({ "TANKS", "BOSS", "GROUP", "SELF", "OFF" }) do
			ns.db.chatChannel = ch
			ns.db.announceResist = true
			lines = Capture(function() A:OnResist("Grimbar", nil, true); A:AnnounceCC(nil, nil, true) end)
			for _, l in ipairs(lines) do if l:find(L.TEST_CHAT, 1, true) then said = said + 1 end end
		end
		local n = (ns.actLog.n.chat or 0) - before
		return n == 0 and said > 0, "Chat " .. n .. "x, Test-Zeilen " .. said, "0x, nur an dich"
	end)
	C("T73", "B", "Sync:Handle", function()
		Sy:Handle("Grimbar", "H:TANK:2.4.1")
		local r = ns.syncRoles.Grimbar
		local a = r and r.role == "TANK" and r.ver == "2.4.1"
		Sy:Handle("Grimbar", "T:Creature-1:10")
		local c = Sy.claims["Creature-1"]
		local b = c and c.name == "Grimbar" and Sy.cd.Grimbar and Near(Sy.cd.Grimbar - GetTime(), 10, 0.5)
		Sy.claims["-"] = nil
		Sy:Handle("Grimbar", "T:-:5")
		local d = Sy.claims["-"] == nil
		Sy:Handle("Grimbar", "kaputt"); Sy:Handle("Grimbar", nil)
		return (a and b and d) and true or false, S(a) .. "/" .. S(b) .. "/" .. S(d), "true/true/true"
	end)
	C("T74", "B", "Sync:Send (nur mitgeschrieben)", function()
		ns.db.sync = false
		local r0 = Sy:Send("H:TEST")
		ns.db.sync = true
		local before = ns.actLog.n.addonmsg or 0
		local r1 = Sy:Send("H:TEST")
		local n = (ns.actLog.n.addonmsg or 0) - before
		if IsInGroup() then
			return r0 == nil and r1 == true and n == 1, S(r0) .. "/" .. S(r1) .. "/" .. n, "nil/true/1 (mitgeschrieben)"
		end
		return r0 == nil and r1 == nil and n == 0, S(r0) .. "/" .. S(r1) .. "/" .. n, "nil/nil/0 (keine Gruppe)"
	end)
	C("T75", "B", "Tank-Liste", function()
		ns.syncRoles.Grimbar = { role = "TANK", t = GetTime() }
		ns.fakeNames.Grimbar = true   -- wie die Testzentrale: erfundener Tank gilt als in der Gruppe
		local a = Sy:IsTank("Grimbar")
		local list = Sy:Tanks()
		local has = false
		for _, n in ipairs(list or {}) do if n == "Grimbar" then has = true end end
		ns.db.sync = false
		local n0 = Sy:NumTanks()
		ns.db.sync = true
		return a and has and n0 == 0, S(a) .. "/" .. S(has) .. "/" .. S(n0), "true/true/0"
	end)
	C("T76", "B", "Addon-Nachrichten: nur der eigene Endpunkt, geschützter oder fehlender Absender", function()
		ns.syncRoles.Grimbar = nil
		-- Prefix prüft GoldSentinelSync: nur der eigene Endpunkt hat den Empfänger
		local G = GoldSentinelSync
		local own = G and G.endpoints and G.endpoints[Sy.PREFIX] == Sy.ep and Sy.ep ~= nil
		local foreign = G and G.endpoints and G.endpoints.FremdesAddon == nil
		ns.testBait = SECRET
		Sy:OnReceive(SECRET, "Grimbar", "PARTY")
		Sy:OnReceive("H:TANK:1", SECRET, "PARTY")
		Sy:OnReceive("H:TANK:1", nil, "PARTY")
		ns.testBait = nil
		local none = ns.syncRoles.Grimbar == nil
		Sy:OnReceive("H:TANK:1", "Grimbar-Realm", "PARTY")
		local got = ns.syncRoles.Grimbar ~= nil
		ns.syncRoles.Grimbar = nil   -- 2.5.26: erfundenen Mitspieler nicht für spätere Prüfungen stehen lassen (fiel in T55 auf)
		local res = S(own) .. "/" .. S(foreign) .. "/" .. S(none) .. "/" .. S(got)
		return res == "true/true/true/true", res, "eigener Endpunkt/fremder ohne/ignoriert/übernommen"
	end)
	C("T81", "B", "Rolle aus Talentpunkten", function()
		local F = ns.Specs._RoleFromPoints
		local r = { F("WARRIOR", { 0, 5, 31 }, 36), F("PALADIN", { 31, 0, 0 }, 31), F("DRUID", { 0, 31, 0 }, 31), F("PRIEST", { 0, 0, 31 }, 31), F("WARRIOR", { 1, 2, 3 }, 6) }
		return r[1] == "TANK" and r[2] == "HEALER" and r[3] == "FERAL" and r[4] == "DAMAGER" and r[5] == nil,
			table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]) }, "/"), "TANK/HEALER/FERAL/DAMAGER/nil"
	end)
	C("T86", "B", "Schadensmeter: Kurzzahlen und Weiche", function()
		local Sh = ns.DmgMeter._Short
		local r = { Sh(999), Sh(1234), Sh(12345), Sh(2500000) }
		local ok = r[1] == "999" and r[2] == "1.2k" and r[3] == "12k" and r[4] == "2.5M"
		return ok and ns.DmgMeter.allowed == (not ns.isModern), table.concat(r, "/") .. " allowed=" .. S(ns.DmgMeter.allowed), "999/1.2k/12k/2.5M"
	end)
	C("T87", "B", "Anzeigen verschieben: Grösse begrenzt", function()
		ns.Mover:SetScale("hud", 9)
		local a = ns.db.hudScale
		ns.Mover:SetScale("hud", 0.1)
		local b = ns.db.hudScale
		return Near(a, 2.5) and Near(b, 0.5), S(a) .. "/" .. S(b), "2.5/0.5"
	end)
	C("T89", "B", "Einstellungsfenster und alle Seiten", function()
		local O = ns.Options
		if not O.frame then O:Build() end
		local wasShown = O.frame:IsShown()
		O.frame:Show()
		for i = 1, 8 do O:Select(i) end
		O:RefreshAll()
		if not wasShown then O.frame:Hide() end
		return true
	end)
	C("T93", "B", "Testzentrale: Texte und Zugriff-Simulation", function()
		local TM = ns.Test
		if not TM.frame then TM:Build() end
		local d, c, r = TM:DiagText(), TM:CompatText(), TM:ReportText()
		if type(d) ~= "string" or type(c) ~= "string" or type(r) ~= "string" then return false, "Text fehlt", "Texte" end
		local bad
		Capture(function()
			for _, st in ipairs({ "open", "secret", "none" }) do
				TM:SetAccessSim(st)
				local exp = ({ open = "FULL", secret = "DISPLAY", none = "OFF" })[st]
				if ns.threatAccess ~= "secret" and ns:ThreatMode() ~= exp then bad = st .. " -> " .. ns:ThreatMode() end
			end
			TM:SetAccessSim(nil)
		end)
		if A.ClearCenter then A:ClearCenter("test") end
		return bad == nil, bad or "ok", "open/secret/none -> FULL/DISPLAY/OFF"
	end)
	C("T94", "B", "Testprotokoll: Werte", function()
		local V = ns.Log.Val
		ns.testBait = SECRET
		local r = { V(SECRET), V(true), V(1.234), V(nil), V(5) }
		ns.testBait = nil
		return r[1] == "SECRET" and r[2] == "1" and r[3] == "1.23" and r[4] == "-" and r[5] == "5", table.concat(r, "/"), "SECRET/1/1.23/-/5"
	end)
	C("T95", "B", "Spenden-Knopf: Sprache", function()
		local D = ns.Donate
		local save = D.locale
		D.locale = "deDE"; local de = D.Text("title")
		D.locale = "enUS"; local en = D.Text("title")
		D.locale = save
		return type(de) == "string" and type(en) == "string" and de ~= en, "de/en verschieden", "verschieden"
	end)
	C("T96", "B", "/gsgame und /gsdev aufrufbar", function()
		local okA = pcall(SlashCmdList.GOLDSENTINELGAME, "")
		return okA, "ok", "kein Fehler"
	end)
	C("T61", "B", "P:Inspect (Vorschau-Plakette über ns.API)", function()
		local TM = ns.Test
		TM:CreatePreview()
		local uf = TM.preview.plates[1]
		local plates = { tsfake1 = { UnitFrame = uf }, tsfake2 = { UnitFrame = uf, IsForbidden = function() return true end } }
		local a, b, c = WithAPI({ C_NamePlate = { GetNamePlateForUnit = function(u) return plates[u] end } }, function()
			return ns.Plates:Inspect("tsfake1"), ns.Plates:Inspect("tsfake2"), ns.Plates:Inspect("tsfake3")
		end)
		local ok = type(a) == "table" and a.scale ~= nil and a.strata ~= nil and b == nil and c == nil
		return ok, (type(a) == "table" and ("Tabelle, Grösse " .. S(a.scale) .. ", Ebene " .. S(a.strata)) or S(a)) .. " / " .. S(b) .. " / " .. S(c),
			"Tabelle / nil (verboten) / nil (keine)"
	end)
	C("T84", "B", "Aggrometer und DD-Ansicht: Sichtbarkeit", function()
		local M, D, db = ns.Meter, ns.DD, ns.db
		if not (M.f and D.f) then return false, "Rahmen fehlen", "Aggrometer und DD-Ansicht" end
		local wasM, wasD = M.f:IsShown(), D.f:IsShown()
		local save = { ns.moveMode, ns.testMode, ns.simAccess, db.enabled, db.meter, db.meterOnlyTank, db.ddView, db.ddSound, ns.liveTest }
		local res, plays = {}, 0
		Swap(ns.Alerts, "Play", function() plays = plays + 1 end)
		Swap(ns, "Unlocked", function() return false end)
		local stance = false
		Swap(ns, "IsTankStance", function() return stance end)
		ns.testMode, ns.liveTest, ns.simAccess = false, false, "open"
		db.enabled, db.meter, db.meterOnlyTank, db.ddView, db.ddSound = true, true, false, true, true
		WithAPI({ UnitExists = Ret(false), UnitAffectingCombat = Ret(false), IsInGroup = Ret(false) }, function()
			ns.moveMode = true; M:Tick(); res[#res + 1] = M.f:IsShown() and "zeigt" or "weg"; ns.moveMode = false
			M:Tick(); res[#res + 1] = M.f:IsShown() and "zeigt" or "weg"                         -- kein Ziel
			db.meterOnlyTank = true; M:Tick(); res[#res + 1] = M.f:IsShown() and "zeigt" or "weg"; db.meterOnlyTank = false
			ns.simAccess = "none"; M:Tick(); res[#res + 1] = M.f:IsShown() and "zeigt" or "weg"; ns.simAccess = "open"
			db.meter = false; M:Tick(); res[#res + 1] = M.f:IsShown() and "zeigt" or "weg"; db.meter = true
			stance = true; D:Tick(); res[#res + 1] = D.f:IsShown() and "zeigt" or "weg"; stance = false
			ns.simAccess = "none"; D:Tick(); res[#res + 1] = D.f:IsShown() and "zeigt" or "weg"; ns.simAccess = "open"
			D:Tick(); res[#res + 1] = D.f:IsShown() and "zeigt" or "weg"                         -- ohne Gruppe
			D.warned = false
			D:Show(db.ddWarn - 10); local p1 = plays
			D:Show(db.ddWarn + 5); local p2 = plays
			D.warned = false; ns.testMode = true; D:Show(db.ddWarn + 5); local p3 = plays; ns.testMode = false
			res[#res + 1] = (p1 - 0) .. "/" .. (p2 - p1) .. "/" .. (p3 - p2)
		end)
		UnswapAll()
		ns.moveMode, ns.testMode, ns.simAccess, db.enabled, db.meter, db.meterOnlyTank, db.ddView, db.ddSound, ns.liveTest =
			save[1], save[2], save[3], save[4], save[5], save[6], save[7], save[8], save[9]
		D.warned = false
		if wasM then M.f:Show() else M.f:Hide() end
		if wasD then D.f:Show() else D.f:Hide() end
		local got = table.concat(res, ",")
		return got == "zeigt,weg,weg,weg,weg,weg,weg,weg,0/1/0", got, "zeigt,weg×7, Ton 0/1/0"
	end)
	-- T90 in Teilen (leistung.md, NP-TS16-1: am Stück 17–28 ms in einem Bild im Nachbau): je Teil höchstens R.T90_CHUNK Schalter,
	-- zwischen den Teilen darf die Routine abgeben. T90 selbst prüft danach die Auswahl-Optionen und die Fehlerzählung über alles.
	local db = ns.db
	local t90 = { before = ns.errorCount, bad = nil, n = 0 }
	local keys = {}
	for k, v in pairs(ns.defaults) do if type(v) == "boolean" then keys[#keys + 1] = k end end
	table.sort(keys)
	local function ticks()
		ns:ApplySettings()
		ns.routineRunning = false     -- Pause nur für diesen einen Aufruf aufheben
		local ok, err = pcall(function()
			ns.Threat:Tick()
			for _, m in ipairs({ ns.Meter, ns.DD, ns.HUD, ns.DmgMeter }) do if m and m.Tick then m:Tick() end end
		end)
		ns.routineRunning = true
		if not ok then error(err, 0) end
		if ns.Options and ns.Options.frame and ns.Options.RefreshAll then ns.Options:RefreshAll() end
	end
	if ns.Options and not ns.Options.frame and ns.Options.Build then ns.Options:Build() end
	local parts = math.ceil(#keys / R.T90_CHUNK)
	for part = 1, parts do
		local a, b = (part - 1) * R.T90_CHUNK + 1, math.min(#keys, part * R.T90_CHUNK)
		C("T90-" .. part, "B", string.format("Optionen an/aus, Teil %d von %d (%s bis %s)", part, parts, keys[a], keys[b]), function()
			local bad
			for x = a, b do
				local k = keys[x]
				local orig = db[k]
				for _, v in ipairs({ true, false }) do
					db[k] = v
					local ok, err = pcall(ticks)
					if not ok and not bad then bad = k .. ": " .. Clean(err) end
					if db[k] ~= v and not bad then bad = k .. " nicht wie gesetzt" end
				end
				db[k] = orig
				t90.n = t90.n + 1
			end
			if bad and not t90.bad then t90.bad = bad end
			return bad == nil, bad or ((b - a + 1) .. " Schalter ohne Fehler"), "kein Lua-Fehler"
		end)
	end
	C("T90", "B", "Jede Option einmal an/aus", function()
		local bad = t90.bad
		for _, pair in ipairs({ { "myRole", { "AUTO", "HEALER", "DAMAGER" } }, { "threatMode", { "AUTO", "DISPLAY" } } }) do
			local k, orig = pair[1], db[pair[1]]
			for _, v in ipairs(pair[2]) do
				db[k] = v
				local ok, err = pcall(ticks)
				if not ok and not bad then bad = k .. "=" .. v .. ": " .. Clean(err) end
			end
			db[k] = orig
		end
		pcall(ticks)
		local all = t90.n == #keys
		return bad == nil and all and ns.errorCount == t90.before,
			bad or (t90.n .. " von " .. #keys .. " Schaltern (in " .. parts .. " Teilen) + Auswahl myRole/threatMode, Fehler +" .. (ns.errorCount - t90.before)),
			"kein Lua-Fehler, alle Schalter (Schieberegler: T89/T58)"
	end)
	------------------------------------------------------------
	-- Fälle mit der Test-Kulisse (Test-Einheiten und Vorschau-Plaketten über ns.API)
	------------------------------------------------------------
	C("T25", "B", "HasSealOfFury / TauntUsable", function()
		local save = { ns.sealId, ns.sealName, ns.sealUntil, ns.tauntSpell, ns.tauntMode }
		ns.sealId, ns.sealName, ns.tauntSpell, ns.tauntMode = 20375, "TSSiegel", "TSSpott", "seal"
		local list = {}
		local function buff(_, i) local a = list[i]; if a then return a[1], nil, 1, nil, nil, nil, nil, nil, nil, a[2] end end
		local r = {}
		local ok, err = pcall(WithAPI, { UnitBuff = buff, UnitDebuff = buff, UnitAffectingCombat = Ret(false) }, function()
			list = { { "TSSiegel", 20375 } }; r[1] = ns:HasSealOfFury(); r[2] = ns:TauntUsable()
			list = {}; r[3] = ns:HasSealOfFury()
			list = { { SECRET, SECRET } }
			ns.sealUntil = GetTime() + 10; r[4] = ns:HasSealOfFury(); r[5] = ns.compat.selfAuras and ns.compat.selfAuras.mode
			ns.sealUntil = GetTime() - 1; r[6] = ns:HasSealOfFury()
		end)
		ns.tauntSpell = nil; r[7] = ns:TauntUsable()
		ns.sealId, ns.sealName, ns.sealUntil, ns.tauntSpell, ns.tauntMode = save[1], save[2], save[3], save[4], save[5]
		if not ok then error(err, 0) end
		local got = table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]), S(r[6]), S(r[7]) }, " ")
		local want = "true true false true fallback false false"
		return got == want, got, want
	end)
	C("T29", "B", "LooksLikeTank / HasBearForm (TS-R1: nur sichtbare Aura, nie 'hält die meisten Mobs')", function()
		local sc = Scene.New(1)
		local auras = {}
		return Scene.Run(sc, function()
			local function buff(u, i)
				local l = auras[u] or {}
				local a = l[i]
				if a then return a[1], nil, 1, nil, nil, nil, nil, nil, nil, a[2] end
			end
			return WithAPI({ UnitBuff = buff, UnitDebuff = buff, UnitAffectingCombat = Ret(false),
				UnitGroupRolesAssigned = Ret("NONE") }, function()
				local r = {}
				ns.memberNow = false; r[1] = ns:LooksLikeTank("party3")
				ns.memberNow = true
				auras.party1 = { { "TSBär", 5487 } }
				r[2] = ns:LooksLikeTank("party1")
				ns.aggroLeader = "Grimbar"; r[3] = ns:LooksLikeTank("party3")   -- Gegenprobe: alter Anführer-Weg zählt nicht mehr
				ns.aggroLeader = nil
				r[4] = ns:HasBearForm("party1")
				r[5] = ns.CouldTank ~= nil
				sc.units.party2.name = SECRET
				r[6] = ns:LooksLikeTank("party2"); r[7] = ns:HasBearForm("party2")
				local got = table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]), S(r[6]), S(r[7]) }, " ")
				local want = "false true false true false false false"
				return got == want, got, want .. " (aus, Aura, Anführer zählt nicht, Bär, kein Raten über die Klasse, geschützt)"
			end)
		end)
	end)
	C("T30", "B", "UpdateGroup (Gruppe mit Pet, Schlachtzug)", function()
		local sc = Scene.New(0)
		sc.group = { "party1", "party2" }
		sc.units.party3 = nil
		sc.units.partypet1 = { name = "Wolf" }
		local a = Scene.Run(sc, function()
			return table.concat(ns.groupUnits, ",") .. " | " .. S(ns.nameToUnit.Torben) .. " " .. S(ns.groupNames.Lina) .. " " .. S(ns.groupNames.Wolf)
		end)
		local rc = Scene.New(0)
		rc.group, rc.raid = {}, 5
		for i = 1, 5 do rc.units["raid" .. i] = { name = "Raid" .. i, player = true, class = "MAGE" } end
		rc.units.raid3.name = SECRET
		local b = Scene.Run(rc, function()
			local n = 0
			for k in pairs(ns.groupNames) do n = n + 1 end
			return #ns.groupUnits .. " Einheiten, " .. n .. " Namen, raid4=" .. S(ns.nameToUnit.Raid4)
		end)
		local wa = "player,party1,partypet1,party2 | party1 true nil"
		local wb = "5 Einheiten, 4 Namen, raid4=raid4"
		return a == wa and b == wb, a .. " / " .. b, wa .. " / " .. wb
	end)
	C("T41", "B", "TA:Candidates", function()
		local sc = Scene.New(3)
		sc.alias.target = "tsfake2"
		sc.units.tsfake3.combat = false
		return Scene.Run(sc, function()
			local list = ns.ThreatAccess:Candidates(ns.mobs)
			local first = list[1]
			local has3 = false
			for _, u in ipairs(list) do if u == "tsfake3" then has3 = true end end
			sc.units.tsfake1.hostile = SECRET
			local list2 = ns.ThreatAccess:Candidates(ns.mobs)
			local has1 = false
			for _, u in ipairs(list2) do if u == "tsfake1" then has1 = true end end
			local ok = first == "target" and #list == 3 and not has3 and not has1
			return ok, string.format("erstes %s, %d Einträge, ohne Kampf drin %s, geschützt drin %s", S(first), #list, S(has3), S(has1)),
				"erstes target, 3 Einträge, false, false"
		end)
	end)
	C("T48", "B", "Zustände eines Mobs (Evaluate)", function()
		local sc = Scene.New(7)
		sc.units.pet = { name = "Wolf" }
		Scene.Hold(sc, "tsfake1", "player", { party1 = 50 })
		Scene.Hold(sc, "tsfake2", "player", { party1 = ns.db.warnThreshold + 5 })
		Scene.Hold(sc, "tsfake3", "party3")
		Scene.Hold(sc, "tsfake4", "party1")
		Scene.Hold(sc, "tsfake5", "party2")
		Scene.Hold(sc, "tsfake6", "pet")
		sc.units.tsfake7.dead = true
		return Scene.Run(sc, function()
			local save = ns.db.petsSafe
			ns.db.petsSafe = true
			local loose = Counter(ns.Alerts, "OnLoose", false)
			local st = {}
			for i = 1, 7 do
				local m = ns.mobs["tsfake" .. i]
				ns.Threat:Evaluate("tsfake" .. i, m)
				st[i] = m.state
			end
			local m4, m5, m3 = ns.mobs.tsfake4, ns.mobs.tsfake5, ns.mobs.tsfake3
			ns.db.petsSafe = save
			local got = table.concat(st, ",") .. " | " .. S(m4.victim) .. "/" .. S(m4.victimRole) .. " " .. S(m5.victimRole)
				.. " | " .. S(m3.otherTank) .. " " .. S(ns.owners[m3.key] and ns.owners[m3.key].name) .. " | OnLoose " .. loose.n
			local want = "HELD,WARN,OTHERTANK,LOOSE,LOOSE,PETHELD,IDLE | Torben/DAMAGER HEALER | Grimbar Grimbar | OnLoose 2"
			return got == want, got, want
		end)
	end)
	C("T49", "B", "LOOSE: Meldung, Übernahme, Besitzer", function()
		local sc = Scene.New(2)
		Scene.Hold(sc, "tsfake1", "party1")
		Scene.Hold(sc, "tsfake2", "party1")
		return Scene.Run(sc, function()
			local T, db = ns.Threat, ns.db
			local saveSync = db.sync
			db.sync = true
			local loose = Counter(ns.Alerts, "OnLoose", false)
			local regain = Counter(ns.Alerts, "OnRegain", false)
			local warn = Counter(ns.Alerts, "OnWarn", false)
			local m1, m2 = ns.mobs.tsfake1, ns.mobs.tsfake2
			T:Evaluate("tsfake1", m1); T:Evaluate("tsfake1", m1)
			local a = loose.n
			-- übernommen (Spott eines anderen Tanks über die GUID)
			ns.Sync.claims[sc.units.tsfake2.guid] = { name = "Grimbar", t = GetTime() }
			T:Evaluate("tsfake2", m2)
			local claimed, b = m2.claimedBy, loose.n
			ns.Sync.claims[sc.units.tsfake2.guid] = nil
			-- anderer Tank war gerade Besitzer -> stumm
			ns.syncRoles.Grimbar = { role = "TANK", t = GetTime(), ver = ns.version }
			ns.owners[sc.units.tsfake2.guid] = { name = "Grimbar", t = GetTime() }
			m2.state, m2.alerted = nil, false
			T:Evaluate("tsfake2", m2)
			local muted, c = m2.muted, loose.n
			-- zurückgeholt, dann bald Aggro
			Scene.Hold(sc, "tsfake1", "player")
			T:Evaluate("tsfake1", m1)
			Scene.Hold(sc, "tsfake1", "player", { party1 = db.warnThreshold + 5 })
			T:Evaluate("tsfake1", m1)
			db.sync = saveSync
			local got = string.format("OnLoose %d, übernommen %s (%d), stumm %s (%d), OnRegain %d, OnWarn %d", a, S(claimed), b, S(muted), c, regain.n, warn.n)
			local want = "OnLoose 1, übernommen Grimbar (1), stumm true (1), OnRegain 1, OnWarn 1"
			return got == want, got, want
		end)
	end)
	C("T50", "B", "Hinweistext (BuildHint)", function()
		local save = { ns.tauntSpell, ns.tauntMode, ns.class, ns.db.sync, ns.sealId, ns.sealName, ns.sealUntil }
		ns.tauntSpell, ns.tauntMode, ns.class, ns.db.sync = "TSSpott", "hostile", "WARRIOR", false
		local T, r = ns.Threat, {}
		local now = GetTime()
		local ok, err = pcall(function()
			WithAPI({ GetSpellCooldown = Ret(0, 0), IsSpellInRange = Ret(1), C_Spell = NIL }, function()
				local m = { claimedBy = "Grimbar" }; T:BuildHint("tsfake1", m); r[1] = m.hint == string.format(L.CLAIMED, "Grimbar")
				m = { muted = true, ownerName = "Grimbar" }; T:BuildHint("tsfake1", m); r[2] = m.hint == string.format(L.OWNER, "Grimbar")
				m = {}; T:BuildHint("tsfake1", m); r[3] = m.hint == L.TAUNT_READY
				m = { myPull = ns.db.deficitThreshold + 1 }; T:BuildHint("tsfake1", m); r[4] = m.hint == L.DEFICIT_WARRIOR
			end)
			WithAPI({ GetSpellCooldown = Ret(0, 0), IsSpellInRange = Ret(0), C_Spell = NIL }, function()
				local m = {}; T:BuildHint("tsfake1", m); r[5] = m.hint == L.TOO_FAR and m.far == true
			end)
			WithAPI({ GetSpellCooldown = Ret(now - 2, 10), IsSpellInRange = Ret(1), C_Spell = NIL }, function()
				local m = {}; T:BuildHint("tsfake1", m); r[6] = m.hint == string.format(L.TAUNT_CD, 8)
			end)
			ns.tauntMode, ns.sealId, ns.sealName, ns.sealUntil = "seal", 20375, "TSSiegel", 0
			WithAPI({ GetSpellCooldown = Ret(0, 0), IsSpellInRange = Ret(1), C_Spell = NIL, UnitBuff = Ret(nil), UnitDebuff = Ret(nil),
				UnitAffectingCombat = Ret(false) }, function()
				local m = {}; T:BuildHint("tsfake1", m); r[7] = m.hint == L.HINT_NO_SEAL
			end)
		end)
		ns.tauntSpell, ns.tauntMode, ns.class, ns.db.sync, ns.sealId, ns.sealName, ns.sealUntil = save[1], save[2], save[3], save[4], save[5], save[6], save[7]
		if not ok then error(err, 0) end
		local got = table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]), S(r[6]), S(r[7]) }, " ")
		local want = "true true true true true true true"
		return got == want, got, want .. " (übernommen, Besitzer, bereit, Defizit, zu weit, Abklingzeit, ohne Siegel)"
	end)
	C("T52", "B", "T:Tick (aktiv, Modus, Wechsel, inaktiv)", function()
		local sc = Scene.New(5)
		return Scene.Run(sc, function()
			local T, db = ns.Threat, ns.db
			local saveEnabled = db.enabled
			local ev = Counter(T, "Evaluate")
			local up = Counter(ns.Plates, "Update", false)
			local rs = Counter(ns.Plates, "Restore", false)
			ns.simAccess = "open"
			T:Tick()
			local mc = Counter(T, "ModeChanged", false)
			local full = ev.n .. "/" .. up.n
			ev.n, up.n = 0, 0
			T.lastMode = "FULL"
			ns.simAccess = "secret"
			T:Tick(); T:Tick()
			local disp = ev.n .. "/" .. up.n .. " Wechsel " .. mc.n
			db.enabled = false
			T:Tick()
			local off = rs.n
			db.enabled = saveEnabled
			local got = "VOLL " .. full .. ", ANZEIGE " .. disp .. ", inaktiv Restore " .. off
			local want = "VOLL 5/5, ANZEIGE 0/0 Wechsel 1, inaktiv Restore 5"
			return got == want, got, want
		end)
	end)
	C("T53", "B", "T:EvalOne", function()
		local sc = Scene.New(1)
		return Scene.Run(sc, function()
			local T, TA = ns.Threat, ns.ThreatAccess
			local ev = Counter(T, "Evaluate", false)
			ns.simAccess = "open"
			T:Tick()
			ev.n = 0
			local r = {}
			T:EvalOne("tsfake1"); r[1] = ev.n
			local saveModern = ns.isModern
			ns.isModern, TA.checked = true, false
			T:EvalOne("tsfake1"); r[2] = ev.n
			ns.isModern, TA.checked = saveModern, true
			ns.testMode = true; T:EvalOne("tsfake1"); r[3] = ev.n; ns.testMode = false
			ns.simAccess = "secret"; T:EvalOne("tsfake1"); r[4] = ev.n
			local got = table.concat(r, "/")
			return got == "1/1/1/1", got, "1/1/1/1 (nur der erste Aufruf wertet aus)"
		end)
	end)
	C("T54", "B", "Plaketten-Ereignisse", function()
		local sc = Scene.New(0)
		sc.units.tsfake9 = { name = "Testmob 9", guid = "Creature-0-0-0-0-91009-0000000009", hostile = true, combat = true }
		Scene.Hold(sc, "tsfake9", "player")
		return Scene.Run(sc, function()
			local before = ns.errorCount
			ns:Fire("NAME_PLATE_UNIT_ADDED", "tsfake9")
			local added = ns.mobs.tsfake9 ~= nil
			ns.owners["plate:tsfake9"] = { name = "Grimbar", t = GetTime() }
			ns:Fire("NAME_PLATE_UNIT_REMOVED", "tsfake9")
			local removed = ns.mobs.tsfake9 == nil and ns.owners["plate:tsfake9"] == nil
			ns:Fire("UNIT_THREAT_LIST_UPDATE", SECRET)
			local got = string.format("hinzu %s, weg %s, Fehler +%d", S(added), S(removed), ns.errorCount - before)
			return added and removed and ns.errorCount == before, got, "hinzu true, weg true, Fehler +0"
		end)
	end)
	-- TS-R1 (Supervisor 23.11.2026 09:41): Rolle nur aus Spiel/Spieler; ohne gesicherten Tank nie "lose", einmal je Gruppe ein Hinweis
	C("T55", "B", "TS-R1: Rolle nur gesichert, ohne Tank keine Lose-Warnung (genau 1 Hinweis), zugewiesener Tank wie bisher, Bär = Tank", function()
		local r = {}
		-- a) nur Klasse Krieger, keine zugewiesene Rolle, keine Aura -> Rolle unbekannt
		local sc = Scene.New(2)
		sc.tank = false
		sc.units.party3.role = "NONE"
		sc.units.party2.role = "NONE"
		sc.units.party1.role = "NONE"
		-- eigene Namen: die Auren-Zwischenspeicher (3 s) aus früheren Prüfungen dürfen nicht mitzählen
		sc.units.party1.name, sc.units.party2.name, sc.units.party3.name = "TsrEins", "TsrZwei", "TsrDrei"
		for i = 1, 2 do Scene.Hold(sc, "tsfake" .. i, "player") end   -- die Mobs greifen mich an (ich bin kein Tank)
		local ok, res = pcall(Scene.Run, sc, function()
			local T, db = ns.Threat, ns.db
			local save = { db.memberView, ns.tankAtPull, db.specCheck, db.myRole, ns.noTankHinted, ns.syncRoles }
			db.memberView, ns.tankAtPull, ns.lastTankT, db.specCheck, db.myRole = true, nil, 0, false, "AUTO"
			ns.noTankHinted, ns.syncRoles = nil, {}   -- keine Sync-Rollen: nur Gruppenrolle und Auren zählen
			ns.simAccess = "open"
			ns:ClearRoleCache()
			local out = {}
			out[#out + 1] = "Krieger " .. S(ns:GetRole("party3")) .. ", ich " .. S(ns:MyRole())
			local loose = Counter(ns.Alerts, "OnLoose", false)
			local n0 = ns.noTankHintN or 0
			for _ = 1, 3 do ns:ClearRoleCache(); T:Tick() end
			local hints = (ns.noTankHintN or 0) - n0
			local st = {}
			for i = 1, 2 do st[i] = S(ns.mobs["tsfake" .. i] and ns.mobs["tsfake" .. i].state) end
			out[#out + 1] = "ohne Tank " .. table.concat(st, "/") .. ", Hinweise " .. hints .. ", Warnungen " .. loose.n
			-- b) zugewiesener Tank (Gruppenrolle) -> wieder "lose" wie bisher
			sc.units.party3.role = "TANK"
			ns:ClearRoleCache()
			T:Tick()
			hints = (ns.noTankHintN or 0) - n0
			out[#out + 1] = "mit Tank " .. S(ns.mobs.tsfake1 and ns.mobs.tsfake1.state) .. ", Hinweise " .. hints .. ", Warnungen " .. loose.n
			-- c) Bärengestalt sichtbar -> Tank (Spielzustand)
			sc.units.party3.role = "NONE"
			UnswapAll()
			db.memberView, ns.tankAtPull, db.specCheck, db.myRole, ns.noTankHinted, ns.syncRoles = save[1], save[2], save[3], save[4], save[5], save[6]
			ns:ClearRoleCache()
			return table.concat(out, " | ")
		end)
		UnswapAll()
		if not ok then return false, Clean(res), "kein Fehler" end
		r[1] = res
		-- c) Bär: eigene kleine Kulisse mit sichtbarer Aura
		local sc2 = Scene.New(1)
		local okB, bear = pcall(Scene.Run, sc2, function()
			sc2.units.party1.role = "NONE"
			sc2.units.party1.name = "TsrBaer"
			local function buff(u, i)
				if u == "party1" and i == 1 then return "TSBär", nil, 1, nil, nil, nil, nil, nil, nil, 5487 end
			end
			return WithAPI({ UnitBuff = buff, UnitDebuff = buff, UnitGroupRolesAssigned = Ret("NONE") }, function()
				local saveM, saveSR = ns.memberNow, ns.syncRoles
				ns.memberNow, ns.syncRoles = true, {}
				ns:ClearRoleCache()
				local role = ns:GetRole("party1")
				ns.syncRoles = saveSR
				ns.memberNow = saveM
				ns:ClearRoleCache()
				return role
			end)
		end)
		if not okB then return false, Clean(bear), "kein Fehler" end
		local got = Clean(r[1] .. " | Bär " .. S(bear))
		local want = "Krieger UNKNOWN, ich UNKNOWN | ohne Tank NOTANK/NOTANK, Hinweise 1, Warnungen 0 | mit Tank LOOSE, Hinweise 1, Warnungen 2 | Bär TANK"
		return got == want, got, want
	end)
	C("T56", "B", "GetUF", function()
		local GetUF = ns.Plates._GetUF
		local hb = {}
		local frames = {
			a = nil,
			b = { IsForbidden = function() return true end, UnitFrame = { healthBar = hb } },
			c = { UnitFrame = { healthBar = hb, IsForbidden = function() return true end } },
			d = { UnitFrame = { HealthBarsContainer = { healthBar = hb } } },
			e = { UnitFrame = {} },
		}
		return WithAPI({ C_NamePlate = { GetNamePlateForUnit = function(u) return frames[u] end } }, function()
			local d = GetUF("d")
			local got = table.concat({ S(GetUF("a")), S(GetUF("b")), S(GetUF("c")), S(d and d.healthBar == hb), S(GetUF("e")) }, " ")
			return got == "nil nil nil true nil", got, "nil nil nil true nil (keine, verboten, Frame verboten, Container, ohne Balken)"
		end)
	end)
	C("T57", "B", "P:Apply je Zustand", function()
		local sc = Scene.New(1)
		return Scene.Run(sc, function()
			local P, db = ns.Plates, ns.db
			local uf = sc.plates.tsfake1
			local base = ns.Safe(uf:GetScale(), 1)
			local res, bad = {}, nil
			local function want(label, m, check)
				P:Apply(uf, m)
				local i = P:Inspect("tsfake1")
				local ok, why = check(i)
				local rgb = i.borderRGB and string.format("%.2f,%.2f,%.2f", Num(i.borderRGB[1]), Num(i.borderRGB[2]), Num(i.borderRGB[3])) or "-"
				res[#res + 1] = label .. (ok and " ok" or (" " .. tostring(why) .. " [Rahmen " .. S(i.border) .. " " .. rgb
					.. ", Grösse " .. string.format("%.2f", Num(i.scale)) .. "/" .. string.format("%.2f", base) .. ", " .. S(i.strata) .. "]"))
				if not ok and not bad then bad = label end
			end
			local function col(i, c) local x = i.borderRGB; return x and Near(x[1], c[1], 0.02) and Near(x[2], c[2], 0.02) and Near(x[3], c[3], 0.02) end
			want("HELD", { state = "HELD" }, function(i) return i.border == false and Near(i.scale, base * db.heldScale, 0.02), "Rahmen/Grösse" end)
			want("WARN", { state = "WARN" }, function(i) return i.border and col(i, db.colorWarn) and i.strata == "HIGH" and Near(i.scale, base * db.warnScale, 0.02), "Farbe/Ebene/Grösse" end)
			want("LOOSE-DD", { state = "LOOSE", victim = "Torben", victimRole = "DAMAGER" },
				function(i) return i.border and col(i, db.colorDD) and Near(i.scale, base * db.looseScale, 0.02) and i.strata == "HIGH", "Farbe/Grösse" end)
			want("LOOSE-Heiler", { state = "LOOSE", victim = "Lina", victimRole = "HEALER" }, function(i) return i.border and col(i, db.colorHealer), "Farbe" end)
			want("übernommen", { state = "LOOSE", victim = "Lina", victimRole = "HEALER", claimedBy = "Grimbar" },
				function(i) return i.border and col(i, db.colorClaimed) and Near(i.scale, base, 0.02), "Farbe/Grösse" end)
			want("IDLE", { state = "IDLE" }, function(i) return i.border == false and Near(i.scale, base, 0.02), "Rahmen/Grösse" end)
			return bad == nil, table.concat(res, ", "), "alle Zustände wie in Apply"
		end)
	end)
	C("T59", "B", "RestoreFrame / Flash", function()
		local sc = Scene.New(1)
		return Scene.Run(sc, function()
			local P = ns.Plates
			local uf = sc.plates.tsfake1
			P:RestoreFrame(uf)
			local base, strata = ns.Safe(uf:GetScale(), 1), uf:GetFrameStrata()
			P:Apply(uf, { state = "LOOSE", victim = "Torben", victimRole = "DAMAGER" })
			P:RestoreFrame(uf)
			local i = P:Inspect("tsfake1")
			local back = Near(i.scale, base, 0.02) and i.strata == strata and i.border == false
			P:FlashFrame(uf)
			local f = P:Inspect("tsfake1")
			local got = "zurück " .. S(back) .. " [Grösse " .. string.format("%.2f/%.2f", Num(i.scale), base) .. ", " .. S(i.strata) .. "/" .. S(strata)
				.. ", Rahmen " .. S(i.border) .. "], Aufblinken " .. S(f.flash)
			return back and f.flash == true, got, "zurück true, Aufblinken true"
		end)
	end)
	C("T70", "B", "Meldungen anderer Tanks", function()
		local sc = Scene.New(0)
		return Scene.Run(sc, function()
			local A = ns.Alerts
			Swap(ns.Test, "IsTesting", function() return false end)
			A:RemoteResist("Grimbar"); A:RemoteCC("Grimbar")
			local tank = #sc.centers
			local okText = sc.centers[1] == string.format(L.REMOTE_RESIST, "Grimbar") and sc.centers[2] == string.format(L.REMOTE_CC, "Grimbar")
			sc.tank = false
			A:RemoteResist("Grimbar"); A:RemoteCC("Grimbar")
			local other = #sc.centers - tank
			return tank == 2 and okText and other == 0, "Tank " .. tank .. " (Text " .. S(okText) .. "), ohne Haltung " .. other, "Tank 2 (Text true), ohne Haltung 0"
		end)
	end)
	C("T77", "B", "Sync:Hello", function()
		local sent = {}
		Swap(ns.Sync, "Send", function(_, msg) sent[#sent + 1] = msg; return true end)
		local ok, err = pcall(function()
			WithAPI({ IsInGroup = Ret(true), IsInRaid = Ret(false) }, function()
				ns.Sync:Hello(true); ns.Sync:Hello(); ns.Sync:Hello(true)
			end)
			-- ohne Gruppe: kein Gruss (Herzschlag)
			WithAPI({ IsInGroup = Ret(false), IsInRaid = Ret(false) }, function() ns.Sync:Hello(true) end)
		end)
		UnswapAll()
		if not ok then error(err, 0) end
		local first = sent[1] or ""
		return #sent == 2 and first:find("^H:%u+:") ~= nil and first:find(ns.version, 1, true) ~= nil,
			#sent .. " Sendungen, " .. S(first), "2 Sendungen (zweite innerhalb 5 s gebremst, ohne Gruppe keine), H:<Rolle>:" .. ns.version
	end)
	C("T83", "B", "Aggrometer Collect (offene Werte)", function()
		local sc = Scene.New(1)
		sc.group = { "party1", "party2", "party3", "party4", "party5" }
		sc.units.party4 = { name = "Mira", player = true, class = "ROGUE", combat = true }
		sc.units.party5 = { name = "Rolf", player = true, class = "HUNTER", combat = true }
		sc.alias.target = "tsfake1"
		Scene.Hold(sc, "tsfake1", "player", { party1 = 60, party2 = 90, party3 = 30, party4 = 75, party5 = 10 })
		return Scene.Run(sc, function()
			ns.simAccess = "open"
			local list, secret = ns.Meter:Collect()
			local names = {}
			for i, e in ipairs(list) do names[i] = tostring(e.name) end
			local got = table.concat(names, ",") .. (secret and " geschützt" or "")
			local want = "Anna,Lina,Mira,Torben,Grimbar,Rolf"
			local pp = ns.Meter._PullPercent
			local p1, p2 = WithAPI({ UnitIsPlayer = Ret(true) }, function()
				return pp("party1", nil, 110, "WARRIOR"), pp("party1", nil, 130, "MAGE")
			end)
			local pull = Near(p1, 100, 0.01) and Near(p2, 100, 0.01)
			return got == want and pull, got .. ", Pull " .. S(pull), want .. " (Tank zuerst, dann Anteil), Pull 110/130 % = 100"
		end)
	end)
	C("T85", "B", "HUD", function()
		local sc = Scene.New(0)
		return Scene.Run(sc, function()
			local H, db = ns.HUD, ns.db
			if not H.f then return false, "HUD fehlt", "HUD" end
			local was = H.f:IsShown()
			local loose = {}
			for i = 1, 7 do loose[i] = { name = "Testmob " .. i, victim = "Torben", victimRole = i == 1 and "HEALER" or "DAMAGER", mark = i == 1 and 8 or nil } end
			Swap(ns, "Unlocked", function() return false end)
			local saveRows, saveHud = db.hudMaxRows, db.hud
			db.hudMaxRows, db.hud = 5, true
			H:Update(loose, {})
			local lines = 0
			for _, l in ipairs(H.f.lines) do if l:IsShown() then lines = lines + 1 end end
			local head = H.f.header:GetText() == string.format(L.LOOSE, 7)
			local icon = (H.f.lines[1]:GetText() or ""):find("UI-RaidTargetingIcon_8", 1, true) ~= nil
			local shown = Shown(H.f)
			ns.memberNow = true; H:Update(loose, {}); local memberHidden = not Shown(H.f); ns.memberNow = false
			db.hud = false; H:Update(loose, {}); local offHidden = not Shown(H.f)
			db.hudMaxRows, db.hud = saveRows, saveHud
			if was then H.f:Show() else H.f:Hide() end
			local got = string.format("%d Zeilen, Kopf %s, Symbol %s, sichtbar %s, Gruppen-Ansicht weg %s, aus weg %s", lines, S(head), S(icon), S(shown), S(memberHidden), S(offHidden))
			return got == "5 Zeilen, Kopf true, Symbol true, sichtbar true, Gruppen-Ansicht weg true, aus weg true", got, "5 Zeilen, alles true"
		end)
	end)
	C("T58", "B", "Plaketten-Optionen an/aus", function()
		local sc = Scene.New(1)
		return Scene.Run(sc, function()
			local P, db = ns.Plates, ns.db
			local uf = sc.plates.tsfake1
			local m = { state = "LOOSE", victim = "Torben", victimRole = "DAMAGER", hint = "TSHinweis" }
			local keys = { looseFire = "fire", effectGlow = "glow", loosePulse = "pulse", showHints = "hint" }
			local res, bad = {}, nil
			for k, field in pairs(keys) do
				local orig = db[k]
				local seen = {}
				for _, v in ipairs({ true, false }) do
					db[k] = v
					P:Apply(uf, m)
					local i = P:Inspect("tsfake1")
					local x = i[field]
					if field == "hint" then x = (x == "TSHinweis") end
					seen[v] = x and true or false
				end
				db[k] = orig
				res[#res + 1] = k .. " " .. S(seen[true]) .. "/" .. S(seen[false])
				if not (seen[true] and not seen[false]) and not bad then bad = k end
			end
			local before = ns.errorCount
			local saveB, saveE, saveO = db.borderSize, db.effectStrength, db.outOfCombatMode
			local ok, err = pcall(function()
				for _, b in ipairs({ 1, 6 }) do db.borderSize = b; P:Apply(uf, m) end
				for _, e in ipairs({ 50, 200 }) do db.effectStrength = e; P:Apply(uf, m) end
				for _, o in ipairs({ "normal", "faded" }) do db.outOfCombatMode = o; P:Apply(uf, { state = "IDLE" }) end
				for _, k in ipairs({ "warnBlink", "showSunder", "showTankStripe" }) do
					local orig = db[k]
					db[k] = true; P:Apply(uf, { state = "WARN" }); db[k] = false; P:Apply(uf, { state = "WARN" }); db[k] = orig
				end
			end)
			db.borderSize, db.effectStrength, db.outOfCombatMode = saveB, saveE, saveO
			if not ok then bad = bad or Clean(err) end
			table.sort(res)
			return bad == nil and ns.errorCount == before, table.concat(res, ", ") .. (ok and "" or (" | " .. Clean(err))),
				"an/aus wirkt (true/false), übrige Optionen ohne Fehler"
		end)
	end)
	C("T65", "B", "OnLoose / OnWarn / OnRegain", function()
		local sc = Scene.New(1)
		return Scene.Run(sc, function()
			local A, db = ns.Alerts, ns.db
			local keys = {}
			Swap(A, "Play", function(_, key) keys[#keys + 1] = tostring(key) end)
			local save = { db.soundWarn, db.regainSound, db.regainText, db.memberSelfWarn }
			local r = {}
			A:OnLoose({ victimRole = "HEALER" }); A:OnLoose({ victimRole = "DAMAGER" })
			r[1] = (keys[1] == tostring(db.soundHealer) and keys[2] == tostring(db.soundDD)) and "Heiler/DD" or table.concat(keys, ",")
			ns.testMode = true; A:OnLoose({ victimRole = "DAMAGER" }); ns.testMode = false
			r[2] = #keys == 2 and "Test still" or "Test laut"
			db.soundWarn = "none"; A:OnWarn({}); r[3] = #keys == 2 and "kein Warnton" or "Warnton"
			db.regainSound, db.regainText = false, false
			local c0 = #sc.centers
			A:OnRegain("tsfake1", {}); r[4] = (#keys == 2 and #sc.centers == c0) and "Zurück still" or "Zurück laut"
			db.regainSound, db.regainText = true, true
			A:OnRegain("tsfake1", {}); r[5] = (#keys == 3 and #sc.centers == c0 + 1) and "Zurück Ton+Text" or "Zurück fehlt"
			ns.memberNow, db.memberSelfWarn = true, true
			A:OnLoose({ victimIsMe = true, name = "Testmob 1" })
			r[6] = (sc.centers[#sc.centers] or ""):find(FormatStem(L.SELF_AGGRO), 1, true) and "Selbst-Aggro" or "Selbst-Aggro fehlt"
			ns.memberNow = false
			db.soundWarn, db.regainSound, db.regainText, db.memberSelfWarn = save[1], save[2], save[3], save[4]
			local got = table.concat(r, ", ")
			local want = "Heiler/DD, Test still, kein Warnton, Zurück still, Zurück Ton+Text, Selbst-Aggro"
			return got == want, got, want
		end)
	end)
	C("T67", "B", "Leben (HealthPercent)", function()
		local r = {}
		WithAPI({ UnitHealth = Ret(50), UnitHealthMax = Ret(200) }, function() r[1] = ns.Alerts:HealthPercent() end)
		WithAPI({ UnitHealth = Ret(50), UnitHealthMax = Ret(0) }, function() r[2] = ns.Alerts:HealthPercent() end)
		WithAPI({ UnitHealth = Ret(SECRET), UnitHealthMax = Ret(200) }, function() r[3] = ns.Alerts:HealthPercent() end)
		local got = S(r[1]) .. "/" .. S(r[2]) .. "/" .. S(r[3])
		return r[1] == 25 and r[2] == 100 and r[3] == nil, got, "25/100/nil (Notfall-Ersatz: T175 und im Client)"
	end)
	C("T66", "B", "Alerts:Evaluate (Flächenspott, Notfall, Heiler-Reichweite)", function()
		local sc = Scene.New(0)
		sc.units.party4 = { name = "Mia", player = true, class = "PRIEST", role = "HEALER", combat = true, power = 0 }
		sc.units.party5 = { name = "Eva", player = true, class = "DRUID", role = "HEALER", combat = true, power = 0 }
		sc.group = { "party1", "party2", "party3", "party4", "party5" }
		return Scene.Run(sc, function()
			local A, db = ns.Alerts, ns.db
			local save = { db.aoeHint, db.aoeThreshold, db.emergency, db.emergencyHP, db.healerRange, ns.aoeSpell, ns.defensives, A.emergShown }
			local function count(text)
				local n = 0
				for _, t in ipairs(sc.centers) do if t == text then n = n + 1 end end
				return n
			end
			local ok, res = pcall(function()
				db.aoeHint, db.aoeThreshold, db.emergency, db.emergencyHP, db.healerRange = true, 3, true, 30, true
				ns.aoeSpell, ns.defensives, A.emergShown = "TSFlaeche", { "TSSchild" }, false
				local oor = { party2 = true, party4 = true, party5 = true }
				local extras
				WithAPI({ GetSpellCooldown = Ret(0, 0), C_Spell = NIL, UnitHealth = Ret(20), UnitHealthMax = Ret(100),
					UnitInRange = function(u) if oor[u] then return false, true end return true, true end }, function()
					A:Evaluate({ {}, {}, {} }, 1)
					A:Evaluate({ {}, {}, {} }, 1)
					extras = #A.extras
					ns.memberNow = true
					local before = #sc.centers
					A:Evaluate({ {}, {}, {} }, 1)
					extras = extras .. "/" .. #A.extras .. "/" .. (#sc.centers - before)
					ns.memberNow = false
				end)
				return string.format("Flächenspott %d, Notfall %d, Ton %d, Heiler-Zeilen %s", count(string.format(L.AOE_HINT, "TSFlaeche")), count(string.format(L.EMERGENCY, "TSSchild")), sc.plays, extras)
			end)
			db.aoeHint, db.aoeThreshold, db.emergency, db.emergencyHP, db.healerRange = save[1], save[2], save[3], save[4], save[5]
			ns.aoeSpell, ns.defensives, A.emergShown = save[6], save[7], save[8]
			wipe(A.extras)
			if not ok then error(res, 0) end
			local want = "Flächenspott 2, Notfall 2, Ton 1, Heiler-Zeilen 2/0/0"
			return res == want, res, want .. " (Ton nur einmal, höchstens 2 Zeilen, Gruppen-Ansicht nichts)"
		end)
	end)
	C("T68", "B", "Spott widerstanden (OnResist)", function()
		local sc = Scene.New(0)
		return Scene.Run(sc, function()
			local A, db = ns.Alerts, ns.db
			local sent = {}
			Swap(ns.Sync, "Send", function(_, m) sent[#sent + 1] = m; return true end)
			local save = { ns.backupSpells, db.announceResist, ns.tauntMode, ns.tauntSpell }
			local ok, res = pcall(function()
				db.announceResist, ns.tauntMode, ns.tauntSpell, ns.backupSpells = false, "hostile", "TSSpott", {}
				A:OnResist("Testmob", "Creature-0-0-0-0-91001-0000000001", true)
				local selfText = sc.centers[#sc.centers] == L.RESIST_SELF
				local s1 = #sent
				ns.backupSpells = { "TSErsatz" }
				WithAPI({ GetSpellCooldown = Ret(0, 0), C_Spell = NIL }, function()
					A:OnResist("Testmob", "Creature-0-0-0-0-91001-0000000001", true)
				end)
				local backupText = sc.centers[#sc.centers] == string.format(L.RESIST_BACKUP, "TSErsatz")
				A:_ResetResistThrottle()
				A:OnResist("Testmob", "Creature-0-0-0-0-91001-0000000001", false)
				A:OnResist("Testmob", "Creature-0-0-0-0-91001-0000000001", false)
				return string.format("selbst %s, Ersatz %s, Test gesendet %d, echt gesendet %d (%s)", S(selfText), S(backupText), s1, #sent, S(sent[1]))
			end)
			A:_ResetResistThrottle()
			ns.backupSpells, db.announceResist, ns.tauntMode, ns.tauntSpell = save[1], save[2], save[3], save[4]
			if not ok then error(res, 0) end
			local want = "selbst true, Ersatz true, Test gesendet 0, echt gesendet 1 (R:Creature-0-0-0-0-91001-0000000001)"
			return res == want, res, want .. " (zweiter Widerstand < 1.5 s ignoriert)"
		end)
	end)
	C("T69", "B", "Tank kontrolliert (CheckCC)", function()
		local sc = Scene.New(0)
		return Scene.Run(sc, function()
			local A, db = ns.Alerts, ns.db
			local sent = {}
			Swap(ns.Sync, "Send", function(_, m) sent[#sent + 1] = m; return true end)
			local save = { db.announceCC, db.ccMinDuration, db.chatChannel, A.ccState }
			local txt, dur = "TSBetäubt", 4
			local LC = { GetActiveLossOfControlDataCount = Ret(1),
				GetActiveLossOfControlData = function() return { locType = "STUN", displayText = txt, timeRemaining = dur } end }
			local ok, res = pcall(WithAPI, { HasFullControl = Ret(false), C_LossOfControl = LC }, function()
				db.announceCC, db.ccMinDuration, db.chatChannel, A.ccState = true, 1.5, "OFF", nil
				local r = {}
				A:CheckCC(); r[1] = sent[#sent] or "-"
				local n = #sent
				A:CheckCC(); r[2] = (#sent == n) and "keine Wiederholung" or "wiederholt"
				A.ccState, dur = nil, 1
				A:CheckCC(); r[3] = (#sent == n) and "zu kurz still" or "zu kurz gemeldet"
				A.ccState, dur = nil, 4
				ns.memberNow = true; A:CheckCC(); ns.memberNow = false
				r[4] = (#sent == n) and "Gruppen-Ansicht still" or "Gruppen-Ansicht gemeldet"
				A.ccState, txt, dur = nil, SECRET, SECRET
				A:CheckCC(); r[5] = sent[#sent] or "-"
				return table.concat(r, ", ")
			end)
			db.announceCC, db.ccMinDuration, db.chatChannel, A.ccState = save[1], save[2], save[3], save[4]
			if not ok then error(res, 0) end
			local want = "X:TSBetäubt, keine Wiederholung, zu kurz still, Gruppen-Ansicht still, X:"
			return res == want, res, want .. " (geschützte Felder: Meldung ohne Text)"
		end)
	end)
	C("T71", "B", "Hinweis Spott-Taste (CheckKeyHint)", function()
		local A, db = ns.Alerts, ns.db
		local save = { db.keyHintDone, ns.tauntSpell, ns.tauntMode }
		local function pops() return (ns.actLog and ns.actLog.n.popup) or 0 end
		local ok, res = pcall(function()
			ns.tauntSpell, ns.tauntMode = "TSSpott", "hostile"
			local r = {}
			local p0 = pops()
			db.keyHintDone = false
			WithAPI({ IsInInstance = Ret(false) }, function() A:CheckKeyHint() end)
			r[1] = (pops() == p0 and not db.keyHintDone) and "draussen nichts" or "draussen gezeigt"
			WithAPI({ IsInInstance = Ret(true), GetBindingKey = Ret("F5") }, function() A:CheckKeyHint() end)
			r[2] = (pops() == p0 and db.keyHintDone) and "Taste belegt" or "Taste belegt falsch"
			db.keyHintDone = false
			WithAPI({ IsInInstance = Ret(true), GetBindingKey = Ret(nil), InCombatLockdown = Ret(true) }, function() A:CheckKeyHint() end)
			r[3] = (pops() == p0 and not db.keyHintDone) and "Kampf später" or "Kampf falsch"
			WithAPI({ IsInInstance = Ret(true), GetBindingKey = Ret(nil), InCombatLockdown = Ret(false) }, function()
				A:CheckKeyHint(); A:CheckKeyHint()
			end)
			r[4] = (pops() == p0 + 1 and db.keyHintDone) and "Hinweis 1x" or ("Hinweis " .. (pops() - p0) .. "x")
			return table.concat(r, ", ")
		end)
		db.keyHintDone, ns.tauntSpell, ns.tauntMode = save[1], save[2], save[3]
		if not ok then error(res, 0) end
		local want = "draussen nichts, Taste belegt, Kampf später, Hinweis 1x"
		return res == want, res, want .. " (Fenster nur mitgeschrieben)"
	end)
	C("T72", "B", "Kampflog-Spott (nur alte API)", function()
		if ns.isModern or not ns.Alerts.cleuRegistered then return true, "moderne API: Kampflog gesperrt (siehe T85)" end
		local A = ns.Alerts
		local save = { ns.tauntSpell, ns.tauntMode, ns.playerGUID, ns.simSecret }
		local res = Counter(A, "OnResist", false)
		local vias = {}
		UnswapAll()
		Swap(A, "OnResist", function(_, _, _, _, via) vias[#vias + 1] = tostring(via) end)
		local src = "Player-0-TSICH"
		local function ev(source) return Ret(1, "SPELL_MISSED", false, source, "x", 0, 0, "Creature-0-0-0-0-91001-0000000001", "Testmob", 0, 0, 99901, "TSSpott") end
		local ok, err = pcall(function()
			ns.tauntSpell, ns.tauntMode, ns.playerGUID, ns.simSecret = "TSSpott", "hostile", src, nil
			WithAPI({ CombatLogGetCurrentEventInfo = ev(src) }, function() A.OnCombatLog() end)
			WithAPI({ CombatLogGetCurrentEventInfo = ev("Player-0-ANDERER") }, function() A.OnCombatLog() end)
			ns.simSecret = true
			WithAPI({ CombatLogGetCurrentEventInfo = ev(src) }, function() A.OnCombatLog() end)
		end)
		UnswapAll()
		ns.tauntSpell, ns.tauntMode, ns.playerGUID, ns.simSecret = save[1], save[2], save[3], save[4]
		if not ok then error(err, 0) end
		local got = #vias .. " " .. table.concat(vias, ",")
		return got == "1 log", got, "1 log (andere Quelle und Simulation: nichts)"
	end)
	C("T78", "B", "Eigene Zauber (Abklingzeit, Spott, Zerreissen, Siegel)", function()
		local sc = Scene.New(1)
		sc.alias.target = "tsfake1"
		return Scene.Run(sc, function()
			local K = ns.Track
			local names = { [99901] = "TSSpott", [99902] = "TSZerreissen", [99903] = "TSSiegel" }
			local save = { ns.tauntSpell, ns.tauntMode, ns.sunderName, ns.sealName, ns.sealUntil, ns.spellIdByName.TSSpott, ns.cdTrack.TSSpott, ns.db.cdLearned.TSSpott }
			local own = Counter(K, "OnOwnTaunt", false)
			local now = GetTime()
			local ok, res = pcall(WithAPI, {
				C_Spell = { GetSpellName = function(id) return names[id] end }, GetSpellInfo = NIL,
				GetSpellCooldown = Ret(now, 10), GetSpellBaseCooldown = Ret(8000),
				C_Timer = { After = function(_, fn) fn() end, NewTicker = C_Timer.NewTicker, NewTimer = C_Timer.NewTimer },
			}, function()
				ns.tauntSpell, ns.tauntMode, ns.sunderName, ns.sealName = "TSSpott", "hostile", "TSZerreissen", "TSSiegel"
				ns.spellIdByName.TSSpott = 99901
				ns:Fire("UNIT_SPELLCAST_SUCCEEDED", "player", nil, 99901)
				local cd = ns.cdTrack.TSSpott and (ns.cdTrack.TSSpott - now) or -1
				local learned = ns.db.cdLearned.TSSpott
				for _ = 1, 6 do ns:Fire("UNIT_SPELLCAST_SUCCEEDED", "player", nil, 99902) end
				local sunder = K:Sunder(sc.units.tsfake1.guid)
				ns:Fire("UNIT_SPELLCAST_SUCCEEDED", "player", nil, 99903)
				local seal = (ns.sealUntil or 0) - GetTime()
				ns.tauntMode = "seal"; ns.sealUntil = GetTime() + 30
				Swap(ns, "HasSealOfFury", function() return true end)
				ns:Fire("UNIT_SPELLCAST_SUCCEEDED", "player", nil, 99901)
				local sealAfter = ns.sealUntil
				return string.format("Abklingzeit %.0f s, gelernt %s, Spott %dx, Zerreissen %d, Siegel %.0f s, nach Richturteil %s",
					cd, S(learned), own.n, sunder, seal, S(sealAfter))
			end)
			ns.tauntSpell, ns.tauntMode, ns.sunderName, ns.sealName, ns.sealUntil = save[1], save[2], save[3], save[4], save[5]
			ns.spellIdByName.TSSpott, ns.cdTrack.TSSpott, ns.db.cdLearned.TSSpott = save[6], save[7], save[8]
			if not ok then error(res, 0) end
			local want = "Abklingzeit 10 s, gelernt 10, Spott 2x, Zerreissen 5, Siegel 30 s, nach Richturteil 0"
			return res == want, res, want
		end)
	end)
	C("T79", "B", "Kontrolle der Gruppe (Tracker)", function()
		local sc = Scene.New(0)
		sc.units.nameplatets1 = { name = "Testmob 1", guid = "Creature-0-0-0-0-91010-0000000010", hostile = true, combat = true }
		sc.units.nameplatets2 = { name = "Testmob 2", guid = "Creature-0-0-0-0-91010-0000000011", hostile = true, combat = true }
		ns.Test:CreatePreview()
		sc.plates.nameplatets1 = ns.Test.preview.plates[1]
		sc.plates.nameplatets2 = ns.Test.preview.plates[2]
		return Scene.Run(sc, function()
			local K = ns.Track
			local names = { [6770] = "TSKopfnuss", [118] = "TSVerwandlung" }
			local k1, k2 = sc.units.nameplatets1.guid, sc.units.nameplatets2.guid
			return WithAPI({ C_Spell = { GetSpellName = function(id) return names[id] end }, GetSpellInfo = NIL }, function()
				sc.alias.party1target = "nameplatets1"
				ns:Fire("UNIT_SPELLCAST_SUCCEEDED", "party1", nil, 6770)
				local cc = K:IsCC(k1)
				ns:Fire("UNIT_HEALTH", "nameplatets1")
				local early = K:IsCC(k1)
				K.ccSince[k1] = GetTime() - 2
				ns:Fire("UNIT_HEALTH", "nameplatets1")
				local broken = not K:IsCC(k1)
				sc.alias.party1target = "nameplatets2"
				ns:Fire("UNIT_SPELLCAST_SUCCEEDED", "party1", nil, 118)
				K.ccSince[k2] = GetTime() - 2
				ns:Fire("UNIT_HEALTH", "nameplatets2")
				local poly = K:IsCC(k2)
				K:Forget(k2)
				local forgot = not K:IsCC(k2)
				local got = string.format("Kopfnuss %s, sofort %s, Schaden bricht %s, Verwandlung bleibt %s, vergessen %s",
					S(cc), S(early), S(broken), S(poly), S(forgot))
				return got == "Kopfnuss true, sofort true, Schaden bricht true, Verwandlung bleibt true, vergessen true", got, "alles true"
			end)
		end)
	end)
	C("T80", "B", "Widerstand ohne Kampflog (über die Bedrohung)", function()
		if not ns.isModern and ns.Alerts:CombatLogWorks() then return true, "alte API: Kampflog vorhanden (T72)" end
		local sc = Scene.New(1)
		sc.alias.target = "tsfake1"
		Scene.Hold(sc, "tsfake1", "party1", { player = 50 })
		return Scene.Run(sc, function()
			local A, K = ns.Alerts, ns.Track
			local vias = {}
			Swap(A, "OnResist", function(_, _, _, _, via) vias[#vias + 1] = tostring(via) end)
			Swap(ns.Sync, "Send", function() return true end)
			local save = { ns.tauntSpell, ns.tauntMode }
			local ok, res = pcall(WithAPI, { C_Timer = { After = function(_, fn) fn() end, NewTicker = C_Timer.NewTicker, NewTimer = C_Timer.NewTimer } }, function()
				ns.tauntSpell, ns.tauntMode = "TSSpott", "hostile"
				K:OnOwnTaunt("TSSpott")
				local a = #vias
				sc.secret = true
				K:OnOwnTaunt("TSSpott")
				return a .. "/" .. #vias .. " " .. table.concat(vias, ",")
			end)
			ns.tauntSpell, ns.tauntMode = save[1], save[2]
			if not ok then error(res, 0) end
			return res == "1/1 threat", res, "1/1 threat (geschützt: nichts)"
		end)
	end)
	C("T82", "B", "Spezialisierung und Betrachten", function()
		local SP = ns.Specs
		local SR = SP._SpecRole
		local r = {}
		WithAPI({ GetSpecialization = Ret(2), GetSpecializationInfo = Ret(73, "x", "x", 0, "TANK") }, function() r[1] = SR("player") end)
		WithAPI({ GetSpecialization = Ret(SECRET), GetSpecializationInfo = Ret(73, "x", "x", 0, "TANK") }, function() r[2] = SR("player") end)
		WithAPI({ GetSpecialization = Ret(0), GetSpecializationInfo = Ret(73, "x", "x", 0, "TANK") }, function() r[3] = SR("player") end)
		WithAPI({ GetInspectSpecialization = Ret(71), GetSpecializationRoleByID = Ret("DAMAGER") }, function() r[4] = SR("party1", true) end)
		WithAPI({ GetInspectSpecialization = Ret(SECRET), GetSpecializationRoleByID = Ret("DAMAGER") }, function() r[5] = SR("party1", true) end)
		local db = ns.db
		local saveCheck, saveLast = db.specCheck, SP.lastInspect
		local before = (ns.actLog and ns.actLog.n.inspect) or 0
		db.specCheck, SP.lastInspect = true, 0
		WithAPI({ IsInGroup = Ret(true), InCombatLockdown = Ret(true) }, function() SP:Step() end)
		local inspects = ((ns.actLog and ns.actLog.n.inspect) or 0) - before
		db.specCheck, SP.lastInspect = saveCheck, saveLast
		local okList, list = pcall(SP.ListText, SP, 10)
		local got = table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]) }, " ") .. ", im Kampf betrachtet " .. inspects .. ", Liste " .. S(okList)
		local want = "TANK nil nil DAMAGER nil, im Kampf betrachtet 0, Liste true"
		return got == want, got, want
	end)
	C("T88", "B", "Spott-Knöpfe (Makros, Tastenbelegung)", function()
		local Tb = ns.Taunt
		if not (Tb and Tb.taunt and Tb.taunt.GetAttribute) then return false, "Spott-Knopf fehlt", "Knopf" end
		local orig = Tb.taunt:GetAttribute("macrotext")
		local save = { ns.tauntSpell, ns.tauntMode, Tb.pending }
		local r = {}
		local ok, err = pcall(function()
			ns.tauntSpell, ns.tauntMode = "TSSpott", "hostile"
			Tb:UpdateMacros(); r[1] = Tb.taunt:GetAttribute("macrotext") == "/cast [@mouseover,harm,nodead][harm,nodead] TSSpott"
			ns.tauntMode = "friendly"
			Tb:UpdateMacros(); r[2] = (Tb.taunt:GetAttribute("macrotext") or ""):find("@mouseover,help", 1, true) ~= nil
			ns.tauntSpell = nil
			Tb:UpdateMacros(); r[3] = Tb.taunt:GetAttribute("macrotext") == ""
			local before = Tb.taunt:GetAttribute("macrotext")
			ns.tauntSpell, ns.tauntMode = "TSSpott", "hostile"
			WithAPI({ InCombatLockdown = Ret(true) }, function() Tb:UpdateMacros() end)
			r[4] = Tb.pending == true and Tb.taunt:GetAttribute("macrotext") == before
			local b0 = (ns.actLog and ns.actLog.n.binding) or 0
			local fight = WithAPI({ InCombatLockdown = Ret(true), GetBindingKey = Ret("F5") }, function() return Tb:SetKey("taunt", "F6") end)
			local b1 = (ns.actLog and ns.actLog.n.binding) or 0
			local calm = WithAPI({ InCombatLockdown = Ret(false), GetBindingKey = Ret("F5"), GetCurrentBindingSet = Ret(1) }, function() return Tb:SetKey("taunt", "F6") end)
			local b2 = (ns.actLog and ns.actLog.n.binding) or 0
			r[5] = fight == false and b1 == b0 and calm == true and b2 - b1 == 3
		end)
		ns.tauntSpell, ns.tauntMode, Tb.pending = save[1], save[2], save[3]
		pcall(Tb.UpdateMacros, Tb)
		local back = Tb.taunt:GetAttribute("macrotext") == orig
		if not ok then error(err, 0) end
		local got = table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]) }, " ") .. ", zurück " .. S(back)
		return got == "true true true true true, zurück true", got, "Feind, Freund, ohne Spott, Kampf aufgeschoben, Tasten nur mitgeschrieben; Makro wie vorher"
	end)
	C("T91", "B", "Ton- und Farbwahl, Popups", function()
		local O = ns.Options
		local c, changed = { 1, 0, 0 }, 0
		local apply, cancel = O._ColorCallbacks(c, function() changed = changed + 1 end, function() return 0, 1, 0 end)
		apply()
		local applied = c[1] == 0 and c[2] == 1
		cancel()
		local restored = c[1] == 1 and c[2] == 0 and changed == 2
		local okPick, err = pcall(function()
			O:OpenSoundPicker("TS", "soundDD", function() end)
			O:RefreshPicker()
		end)
		local shown = O.picker and O.picker:IsShown() or false
		if O.picker then O.picker:Hide() end
		local pops = 0
		for _, k in ipairs({ "THREATSENTINEL_BINDKEY", "THREATSENTINEL_REBIND", "THREATSENTINEL_CUSTOMSOUND", "THREATSENTINEL_RELOAD" }) do
			local d = StaticPopupDialogs and StaticPopupDialogs[k]
			if d and type(d.text) == "string" and d.text ~= "" then pops = pops + 1 end
		end
		local got = string.format("Farbe übernommen %s, abgebrochen %s, Tonauswahl %s/%s, Popups %d", S(applied), S(restored), S(okPick), S(shown), pops)
		local want = "Farbe übernommen true, abgebrochen true, Tonauswahl true/true, Popups 4"
		return got == want, okPick and got or Clean(err), want .. " (Blizzard-Farbfenster nicht geöffnet)"
	end)
	C("T92", "B", "Minimap-Knopf", function()
		local O, db = ns.Options, ns.db
		local b = O.minimap
		if not b then return false, "Knopf fehlt", "Knopf" end
		local save = { db.minimapShow, db.minimapAngle, b:IsShown() }
		local ok, res = pcall(function()
			db.minimapShow = true; O:UpdateMinimap(); local on = b:IsShown()
			db.minimapShow = false; O:UpdateMinimap(); local off = not b:IsShown()
			for _, a in ipairs({ 0, 220 }) do db.minimapAngle = a; O:PlaceMinimap() end
			local enter, leave = b:GetScript("OnEnter"), b:GetScript("OnLeave")
			if enter then enter(b) end
			if leave then leave(b) end
			return S(on) .. "/" .. S(off)
		end)
		db.minimapShow, db.minimapAngle = save[1], save[2]
		O:UpdateMinimap()
		if save[3] then b:Show() else b:Hide() end
		if not ok then return false, Clean(res), "kein Fehler" end
		return res == "true/true", "an/aus " .. res .. ", Winkel 0/220 und Tooltip ohne Fehler", "true/true"
	end)

end

------------------------------------------------------------
-- C. Forever-Sonderfälle (simuliert)
------------------------------------------------------------
Area.C = function()
	C("T102", "C", "Chat-Argumente geschützt", function()
		local before = ns.errorCount
		ns.testBait = SECRET
		ns.Sync:OnReceive(SECRET, SECRET, SECRET)
		ns.testBait = nil
		return ns.errorCount == before, "Fehler +" .. (ns.errorCount - before), "kein Fehler"
	end)
	C("T111", "C", "Kampflog auf der modernen API nicht angemeldet", function()
		local reg = ns:HasHandler("COMBAT_LOG_EVENT_UNFILTERED")
		if ns.isModern then
			return reg == false and ns.Alerts.cleuRegistered == false and ns.DmgMeter.allowed == false, S(reg), "nicht angemeldet"
		end
		return reg == true and ns.Alerts.cleuRegistered == true and ns.DmgMeter.allowed == true, S(reg), "Gegenprobe: angemeldet"
	end)
	C("T97", "C", "Bedrohung geschützt, ganzer Durchlauf", function()
		local sc = Scene.New(5)
		local saveModern = ns.isModern
		ns.isModern = true
		local ok, a, b, c = pcall(Scene.Run, sc, function()
			local T, TA = ns.Threat, ns.ThreatAccess
			ns.threatAccess, ns.simAccess, TA.announced = "open", nil, false
			local before = ns.errorCount
			T:Tick()                       -- Modus VOLL, Werte offen
			local up = Counter(ns.Plates, "Update", false)
			local hud = 0
			Swap(ns.HUD, "Update", function(_, loose) if loose and #loose > 0 then hud = hud + 1 end end)
			sc.secret = true
			T:Tick(); T:Tick(); T:Tick()
			local notes = 0
			for _, t in ipairs(sc.centers) do if t == L.TA_NOTE_DISPLAY then notes = notes + 1 end end
			local got = string.format("Modus %s, Zugriff %s, Plaketten %d, HUD-Zeilen %d, Hinweis %dx, Fehler +%d",
				ns:ThreatMode(), S(ns.threatAccess), up.n, hud, notes, ns.errorCount - before)
			return got == "Modus DISPLAY, Zugriff secret, Plaketten 0, HUD-Zeilen 0, Hinweis 1x, Fehler +0", got,
				"DISPLAY, secret, 0 Plaketten, HUD leer, Hinweis 1x, kein Fehler"
		end)
		ns.isModern = saveModern
		if not ok then error(a, 0) end
		return a, b, c
	end)
	C("T98", "C", "Namen und GUIDs geschützt", function()
		local save = { ns.groupUnits, ns.groupNames, ns.nameToUnit }
		local names = { party1 = SECRET, party2 = "Torben" }
		WithAPI({ IsInRaid = Ret(false), GetNumSubgroupMembers = Ret(2), UnitIsPlayer = Ret(true),
			UnitExists = function(u) return u ~= "pet" and u ~= "partypet1" and u ~= "partypet2" end,
			UnitName = function(u) if names[u] then return names[u], "" end return "Anna", "" end }, function()
			ns:UpdateGroup()
		end)
		local keys, bad = 0, false
		for k in pairs(ns.groupNames) do keys = keys + 1; if rawequal(k, SECRET) then bad = true end end
		local units = #ns.groupUnits
		local key = WithAPI({ UnitGUID = Ret(SECRET) }, function() return ns:MobKey("tsfake1") end)
		ns.groupUnits, ns.groupNames, ns.nameToUnit = save[1], save[2], save[3]
		return not bad and keys == 2 and units == 3 and key == "plate:tsfake1",
			string.format("%d Einheiten, %d Namen, SECRET-Schlüssel %s, %s", units, keys, S(bad), S(key)), "3 Einheiten, 2 Namen, false, plate:tsfake1"
	end)
	C("T99", "C", "Auren geschützt", function()
		local function sec() return SECRET, nil, SECRET, nil, nil, nil, nil, nil, nil, SECRET end
		local a, b = WithAPI({ UnitBuff = sec, UnitDebuff = sec, UnitAffectingCombat = Ret(false) }, function()
			return ns:FindAura("player", "HELPFUL", { [71] = true })
		end)
		return a == false and b == false, S(a) .. "/" .. S(b), "false/false (nicht lesbar)"
	end)
	C("T100", "C", "Abklingzeiten geschützt", function()
		local now = GetTime()
		local saveMode = ns.tauntMode
		ns.tauntMode = "hostile"
		ns.cdTrack.TSTest = now + 6
		local v = WithAPI({ GetSpellCooldown = Ret(SECRET, SECRET), C_Spell = { GetSpellCooldown = function() return { startTime = SECRET, duration = SECRET } end } },
			function() return ns.SpellCD("TSTest") end)
		local v2 = WithAPI({ GetSpellCooldown = NIL, C_Spell = { GetSpellCooldown = function() return { startTime = SECRET, duration = SECRET } end } },
			function() return ns.SpellCD("TSTest") end)
		ns.cdTrack.TSTest = nil
		ns.tauntMode = saveMode
		local mode = ns.compat.cooldowns and ns.compat.cooldowns.mode
		return Near(v, 6, 0.1) and Near(v2, 6, 0.1) and mode == "fallback", string.format("%.1f / %.1f %s", Num(v), Num(v2), S(mode)), "6 / 6 fallback (aus cdTrack)"
	end)
	C("T101", "C", "Ziel und Mausziel geschützt", function()
		local n, plate = WithAPI({ UnitExists = Ret(SECRET), UnitCanAttack = Ret(SECRET), UnitAffectingCombat = Ret(SECRET) }, function()
			return #ns.ThreatAccess:Candidates(ns.mobs), ns:PlateFor("mouseover")
		end)
		return n == 0 and plate == nil, n .. " Kandidaten, Plakette " .. S(plate), "0, nil"
	end)
	C("T103", "C", "Reichweite geschützt", function()
		local r = WithAPI({ IsSpellInRange = Ret(SECRET), C_Spell = { IsSpellInRange = Ret(SECRET) } }, function()
			return ns.SpellInRange("TSTest", "target")
		end)
		return r == nil, S(r), "nil (kein 'zu weit')"
	end)
	C("T104", "C", "Zauber-Funktionen fehlen", function()
		local before = ns.errorCount
		local r = WithAPI({ GetSpellInfo = NIL, GetSpellTexture = NIL, GetSpellCooldown = NIL, IsSpellInRange = NIL,
			GetSpellBaseCooldown = NIL, IsPlayerSpell = NIL, IsSpellKnown = NIL, C_Spell = NIL }, function()
			return { ns.SpellName(355), ns.SpellIcon(355), ns.SpellCD("TSTest"), ns.SpellInRange("TSTest", "target"), ns:BaseCooldown("TSTest") }
		end)
		return r[1] == nil and r[3] == 0 and r[4] == nil and ns.errorCount == before,
			string.format("Name %s, CD %s, Reichweite %s", S(r[1]), S(r[3]), S(r[4])), "nil, 0, nil – kein Fehler"
	end)
	C("T105", "C", "Auren-Funktionen fehlen -> C_UnitAuras", function()
		local a = WithAPI({ UnitBuff = NIL, UnitDebuff = NIL, UnitAffectingCombat = Ret(false),
			C_UnitAuras = { GetAuraDataByIndex = function(_, i) if i == 1 then return { name = "TSAura", applications = 2, spellId = 71 } end end } },
			function() local n, c, id = ns.Aura("player", 1, "HELPFUL"); return S(n) .. "/" .. S(c) .. "/" .. S(id) end)
		return a == "TSAura/2/71", a, "TSAura/2/71"
	end)
	C("T106", "C", "Chat-, CVar- und Addon-Funktionen fehlen", function()
		local before = ns.errorCount
		local save = { ns.db.sync, ns.simSecret }
		ns.db.sync, ns.simSecret = true, nil
		local ok, res = pcall(WithAPI, { C_ChatInfo = NIL, SendAddonMessage = NIL, RegisterAddonMessagePrefix = NIL,
			C_CVar = NIL, GetCVar = NIL, SetCVar = NIL, C_AddOns = NIL, GetAddOnMetadata = NIL,
			InCombatLockdown = Ret(false), IsInGroup = Ret(true), IsInRaid = Ret(false) }, function()
			-- gesendet wird über GoldSentinelSync (die Datei prüft die Chat-Funktionen selbst): mit Endpunkt true,
			-- ohne Endpunkt false und Rückfall
			local withEp = ns.Sync:Send("H:TEST")
			local ep = ns.Sync.ep
			ns.Sync.ep = false
			local okS, sent = pcall(ns.Sync.Send, ns.Sync, "H:TEST")
			ns.Sync.ep = ep
			if not okS then error(sent, 0) end
			if withEp ~= true then sent = "Endpunkt " .. S(withEp) end
			ns.Sync:Init()
			local cv = ns:GetCVarSafe("nameplateShowEnemies")
			ns:SetCVarSafe("nameplateShowEnemies", "1")
			local ta = ns.ThreatAccess._GetCV("threatWarning")
			ns.ThreatAccess._SetCV("threatWarning", "3")
			return S(sent) .. " " .. S(cv) .. " " .. S(ta)
		end)
		ns.db.sync, ns.simSecret = save[1], save[2]
		if not ok then return false, Clean(res), "kein Lua-Fehler" end
		local mode = ns.compat.sync and ns.compat.sync.mode
		return res == "false nil nil" and mode == "fallback" and ns.errorCount == before,
			"Senden/CVar/CVar: " .. res .. ", Sync " .. S(mode), "false nil nil, Sync fallback, kein Fehler"
	end)
	C("T107", "C", "Bedrohungs-Funktionen fehlen", function()
		local TA = ns.ThreatAccess
		local save = { ns.isModern, ns.threatAccess, TA.checked, TA.announced, ns.groupUnits }
		Swap(ns.Alerts, "Center", function() end)
		ns.isModern, ns.threatAccess, TA.checked, TA.announced = true, "unknown", false, false
		ns.groupUnits = { "player" }
		local before = ns.errorCount
		local f, sec, miss, acc, mode = WithAPI({ UnitDetailedThreatSituation = NIL, UnitThreatSituation = NIL, UnitAffectingCombat = Ret(true) }, function()
			local a, b, c = TA:Read("target")
			TA:Probe({ "target" })
			ns.Threat._ReadThreat("tsfake1")
			return a, b, c, ns.threatAccess, ns:ThreatMode()
		end)
		UnswapAll()
		ns.isModern, ns.threatAccess, TA.checked, TA.announced, ns.groupUnits = save[1], save[2], save[3], save[4], save[5]
		return miss == true and acc == "none" and mode == "OFF" and ns.errorCount == before,
			string.format("fehlt %s, %s, %s", S(miss), S(acc), S(mode)), "fehlt true, none, OFF – kein Fehler"
	end)
	C("T108", "C", "Rollen-, Gestalt- und Spezialisierungs-Funktionen fehlen", function()
		local before = ns.errorCount
		local ok, err = WithAPI({ GetSpecialization = NIL, GetSpecializationInfo = NIL, GetSpecializationRole = NIL,
			GetShapeshiftFormID = NIL, UnitGroupRolesAssigned = NIL, GetPartyAssignment = NIL, GetRaidTargetIndex = NIL,
			UnitHealthPercent = NIL }, function()
			return pcall(function()
				ns:FormName(); ns:SpecName()
				if ns.ClearRoleCache then ns:ClearRoleCache() end
				ns:GetRole("player")
				if ns.ClearRoleCache then ns:ClearRoleCache() end
			end)
		end)
		return ok and ns.errorCount == before, ok and "kein Fehler" or Clean(err), "kein Lua-Fehler"
	end)
	CL("T109", "C", "Keine geschützten Aktionen im Kampf", "Im Kampf: Einstellungen öffnen (Hinweis 'nicht im Kampf'), /ts move (verweigert); danach /ts test > Bericht: Blocked: none")
	CL("T110", "C", "Plaketten im Kampf in ANZEIGE/AUS", "Forever, Modus ANZEIGE: Pull mit 3+ Mobs – nichts leuchtet, Plaketten unverändert; nach dem Kampf wieder normal")
end

------------------------------------------------------------
-- D. Alte Clients
------------------------------------------------------------
Area.D = function()
	if ns.isModern then
		for _, id in ipairs({ "T112", "T113", "T114", "T115", "T116" }) do K(id, "D", "Alter Client", "nur Classic Era / TBC") end
		K("T117", "D", "Gegenprobe im echten Spiel", "nur Classic Era / TBC")
		return
	end
	C("T112", "D", "Bedrohung offen, Modus immer VOLL", function()
		local save = ns.db.threatMode
		ns.db.threatMode = "DISPLAY"
		local m = ns:ThreatMode()
		ns.db.threatMode = save
		return ns.threatAccess == "open" and ns.ThreatAccess.checked == true and m == "FULL", S(ns.threatAccess) .. "/" .. m, "open/FULL"
	end)
	C("T113", "D", "Ersatz über das Ziel des Mobs", function()
		local save = ns.groupUnits
		ns.groupUnits = { "player" }
		local tank, _, _, _, via = WithAPI({ UnitDetailedThreatSituation = Ret(nil), UnitThreatSituation = Ret(nil),
			UnitAffectingCombat = Ret(true), UnitExists = Ret(true),
			UnitIsUnit = function(a, b) return a == "player" and b == "tsfake1target" end }, function()
			return ns.Threat._ReadThreat("tsfake1")
		end)
		ns.groupUnits = save
		return tank == "player" and via == "fallback", S(tank) .. "/" .. S(via), "player/fallback"
	end)
	C("T114", "D", "Auren über UnitBuff/UnitDebuff", function()
		local function old(_, i) if i == 1 then return "TSAura", nil, 3, nil, nil, nil, nil, nil, nil, 71 end end
		local a = WithAPI({ UnitBuff = old, UnitDebuff = old, C_UnitAuras = NIL }, function()
			local n, c, id = ns.Aura("player", 1, "HELPFUL"); return S(n) .. "/" .. S(c) .. "/" .. S(id)
		end)
		return a == "TSAura/3/71", a, "TSAura/3/71"
	end)
	C("T115", "D", "Sync im Kampf nicht gesperrt", function()
		local save = { ns.db.sync, ns.simSecret }
		ns.db.sync, ns.simSecret = true, nil
		local r = WithAPI({ InCombatLockdown = Ret(true), IsInGroup = Ret(true), IsInRaid = Ret(false) }, function()
			return ns.Sync:Send("H:TEST")
		end)
		ns.db.sync, ns.simSecret = save[1], save[2]
		return r ~= false, "Senden " .. S(r) .. " (nur mitgeschrieben)", "nicht gesperrt"
	end)
	C("T116", "D", "Spott je Client", function()
		if ns.class ~= "PALADIN" then return true, "Klasse " .. S(ns.class) .. " (nur Paladin prüfbar)" end
		local G = GoldSentinelGame
		if G.IsEra then return ns.tauntSpell == nil, S(ns.tauntMode), "Era: kein Spott" end
		return ns.tauntMode == nil or ns.tauntMode == "friendly", S(ns.tauntMode), "TBC: friendly (wenn gelernt)"
	end)
	CL("T117", "D", "Gegenprobe im echten Spiel", "/ts guide mit Pet oder in der Gruppe: lose Mobs leuchten, gehaltene ausgeblendet, Ton bei Aggroverlust; Kampflog: Schadensmeter zählt, widerstandener Spott wird gemeldet, kein 'Addon geblockt'")
end

------------------------------------------------------------
-- E. Daten
------------------------------------------------------------
Area.E = function()
	C("T118", "E", "Neuinstallation", function()
		local keep = ThreatSentinelDB
		ThreatSentinelDB = nil
		local ok, err = pcall(function()
			ns:InitDB()
			local DB = ThreatSentinelDB
			local p = DB.profiles[DB.chars[ns.charKey]]
			if type(p) ~= "table" or p.schema ~= 9 then error("Profil/Schema " .. S(p and p.schema)) end
			for k, v in pairs(ns.defaults) do
				if type(v) ~= "table" and p[k] ~= v then error("Standard " .. k) end
			end
			local lines = Capture(function() ns.ThreatAccess:Report() end)
			if not Has(lines, L.TA_R_NEVER) then error("TA_R_NEVER fehlt") end
		end)
		ThreatSentinelDB = keep
		ns:InitDB()
		if not ok then return false, Clean(err), "Profil mit Standardwerten, Schema 9" end
		return true
	end)
	C("T119", "E", "Migration aus Schema 1", function()
		local db = { heldPlateAlpha = 0, chatChannel = "GROUP", soundHealer = "raidwarning", soundDD = "alarm", soundRegain = "click",
			soundResist = "readycheck", hudPoint = { "CENTER", "UIParent", "CENTER", 320, -120 }, meterPoint = { "CENTER", "UIParent", "CENTER", 320, 60 },
			hudScale = 1.3, hudLocked = false, soundEmergency = "ts_emergency", soundDDWarn = "ts_warn", regainSound = true,
			colorWarn = { 1, 0.9, 0 }, colorDD = { 1, 0.55, 0 }, looseScale = 1.25, borderSize = 3 }
		ns._MergeDefaults(db, ns.defaults)
		ns:Migrate(db)
		local d = ns.defaults
		local checks = {
			{ "heldPlateAlpha", db.heldPlateAlpha == 0.35 }, { "chatChannel", db.chatChannel == "TANKS" },
			{ "soundHealer", db.soundHealer == "fx_engel" }, { "soundDD", db.soundDD == "fx_frosch" },
			{ "soundRegain", db.soundRegain == d.soundRegain }, { "soundResist", db.soundResist == "none" or db.soundResist == d.soundResist },
			{ "hudPoint", Diff(db.hudPoint, d.hudPoint, "") == nil }, { "meterPoint", Diff(db.meterPoint, d.meterPoint, "") == nil },
			{ "meterScale", db.meterScale == 1.3 and db.ddScale == 1.3 }, { "hudLocked", db.hudLocked == true },
			{ "soundDDWarn", db.soundDDWarn == "none" }, { "soundEmergency", db.soundEmergency == "none" }, { "regainSound", db.regainSound == false },
			{ "colorWarn", db.colorWarn[1] == 1 and db.colorWarn[2] == 0.5 and db.colorWarn[3] == 0 },
			{ "colorDD", db.colorDD[1] == 1 and db.colorDD[2] == 0.1 and db.colorDD[3] == 0.1 },
			{ "looseScale", db.looseScale == 1.4 }, { "borderSize", db.borderSize == 4 }, { "schema", db.schema == 9 },
		}
		for _, c in ipairs(checks) do if not c[2] then return false, c[1] .. " = " .. S(db[c[1]]), "migriert" end end
		return true
	end)
	C("T120", "E", "Migration aus Schema 5 und 9", function()
		local db5 = { schema = 5, soundHealer = "ts_healer", soundDD = "ts_dd" }
		ns._MergeDefaults(db5, ns.defaults); ns:Migrate(db5)
		local db9 = { schema = 9, soundHealer = "quest", colorDD = { 0, 0, 1, 1 } }
		ns._MergeDefaults(db9, ns.defaults); ns:Migrate(db9)
		local ok = db5.soundHealer == "fx_engel" and db5.soundDD == "fx_frosch" and db9.soundHealer == "quest" and db9.colorDD[3] == 1
		return ok, S(db5.soundHealer) .. "/" .. S(db5.soundDD) .. "/" .. S(db9.soundHealer), "fx_engel/fx_frosch/quest"
	end)
	C("T121", "E", "Alte gespeicherte Bedrohungs-Erkennung", function()
		for _, v in ipairs({ false, { state = "none" }, { state = "secret", date = nil } }) do
			ThreatSentinelDB.threatAccess = v or nil
			ns.ThreatAccess:Login()
			Capture(function() ns.ThreatAccess:Report() end)
		end
		return true
	end)
	C("T122", "E", "Beschädigte Einträge (an einer Kopie)", function()
		local cases = {
			{ "hudPoint", "x", "table" }, { "colorDD", 5, "table" }, { "guide", "x", "table" }, { "cdLearned", "x", "table" },
			{ "soundHealer", 12, "string" }, { "meterRows", "6", "number" }, { "heldScale", true, "number" },
		}
		local bad = {}
		for _, c in ipairs(cases) do
			local k, v, want = c[1], c[2], c[3]
			if ns.defaults[k] ~= nil then
				local copy = Copy(ns.db)
				copy[k] = v
				local ok, err = pcall(ns._MergeDefaults, copy, ns.defaults)
				if not ok then bad[#bad + 1] = k .. ": " .. Clean(err)
				elseif type(copy[k]) ~= want then bad[#bad + 1] = k .. " bleibt " .. type(copy[k]) end
			end
		end
		-- oberste Ebene (Kopie der SavedVariables)
		local root = { profiles = { P = Copy(ns.db) }, chars = { X = 7 }, threatAccess = "open", testlog = 5, diag = "x" }
		root.profiles.P.blizzOrig = "x"
		local ok, err = pcall(ns.SanitizeRoot, ns, root)
		if not ok then bad[#bad + 1] = "SanitizeRoot: " .. Clean(err)
		else
			if root.threatAccess ~= nil then bad[#bad + 1] = "threatAccess" end
			if root.testlog ~= nil then bad[#bad + 1] = "testlog" end
			if root.profiles.P.blizzOrig ~= nil then bad[#bad + 1] = "blizzOrig" end
		end
		local root2 = { testlog = { events = "x" } }
		pcall(ns.SanitizeRoot, ns, root2)
		if type(root2.testlog.events) ~= "table" then bad[#bad + 1] = "testlog.events" end
		-- Sync-Rolle ohne Zeit
		local saveR = ns.syncRoles.TSOhneZeit
		ns.syncRoles.TSOhneZeit = { role = "TANK" }
		local okS, errS = pcall(function() return ns.Sync:IsTank("TSOhneZeit"), ns.Sync:IsFresh("TSOhneZeit") end)
		ns.syncRoles.TSOhneZeit = saveR
		if not okS then bad[#bad + 1] = "syncRoles ohne t: " .. Clean(errS) end
		return #bad == 0, #bad == 0 and "alles repariert, kein Lua-Fehler" or table.concat(bad, "; "), "Typen wieder richtig, kein Lua-Fehler"
	end)
end

------------------------------------------------------------
-- F. Sprachen
------------------------------------------------------------
local function Placeholders(s)
	local out = {}
	for p in tostring(s):gmatch("%%[%-%d%.]*[%a%%]") do out[#out + 1] = p end
	return table.concat(out, " ")
end

Area.F = function()
	local LOC = ns.LOCALES
	C("T123", "F", "Gleiche Schlüssel in en und de", function()
		local n, miss = 0, nil
		for k in pairs(LOC.enUS) do n = n + 1; if LOC.deDE[k] == nil then miss = "de fehlt " .. k end end
		for k in pairs(LOC.deDE) do if LOC.enUS[k] == nil then miss = "en fehlt " .. k end end
		return miss == nil, miss or (n .. " Schlüssel"), "gleich"
	end)
	C("T124", "F", "Zusammengesetzte Schlüssel vorhanden", function()
		local keys = { "TA_MODE_FULL", "TA_MODE_DISPLAY", "TA_MODE_OFF", "PRESET_quiet", "PRESET_standard", "PRESET_loud", "TANK", "HEALER", "DAMAGER", "PET" }
		for _, c in ipairs({ "TANKS", "BOSS", "GROUP", "SELF", "OFF" }) do keys[#keys + 1] = "CH_" .. c end
		for _, f in ipairs(ns.COMPAT_ORDER) do
			for _, p in ipairs({ "CP_", "CPF_", "CPO_", "CPH_" }) do keys[#keys + 1] = p .. f end
		end
		for _, s in ipairs({ "unknown", "open", "secret", "none" }) do keys[#keys + 1] = "TA_STATE_" .. s end
		for _, s in ipairs({ "real", "open", "secret", "none" }) do keys[#keys + 1] = "TEST_ACC_" .. s end
		for _, k in ipairs(keys) do
			if rawget(LOC.enUS, k) == nil or rawget(LOC.deDE, k) == nil then return false, k, "in en und de" end
		end
		return true, #keys .. " Schlüssel"
	end)
	C("T125", "F", "Formatplatzhalter gleich", function()
		for k, v in pairs(LOC.enUS) do
			local d = LOC.deDE[k]
			if type(v) == "string" and type(d) == "string" and Placeholders(v) ~= Placeholders(d) then
				return false, k .. ": " .. Placeholders(v) .. " / " .. Placeholders(d), "gleich"
			end
		end
		return true
	end)
	K("T126", "F", "Im Code benutzte Schlüssel", "vor dem Push per Skript geprüft (manuell)")
	C("T127", "F", "Aktive Sprache: Hauptfenster", function()
		local O, TM = ns.Options, ns.Test
		if not O.frame then O:Build() end
		local w = O.frame:IsShown()
		O.frame:Show(); for i = 1, 8 do O:Select(i) end
		if not w then O.frame:Hide() end
		if not TM.frame then TM:Build() end
		TM:ReportText()
		return true, GetLocale()
	end)
	-- T-L1/T-L2: Sprachtest darf das Laden nie anhalten (2.5.4: GoldSentinelDev.IsDev() mit Punkt -> Lua-Fehler beim Laden)
	C("T-L1", "F", "devLocale gesetzt: Laden ohne Lua-Fehler (echte Entwickler-Prüfung)", function()
		local saveDL, saveLoc = ThreatSentinelDB.devLocale, ns.activeLocale
		ThreatSentinelDB.devLocale = (saveLoc == "deDE") and "enUS" or "deDE"
		local ok, applied = pcall(ns.ApplyDevLocale, ns)
		local now = ns.activeLocale
		ns:ApplyLocale(saveLoc)
		ThreatSentinelDB.devLocale = saveDL
		local textBack = L.DD_AGGRO == ns.LOCALES[saveLoc].DD_AGGRO
		return ok and textBack and (applied == (now ~= saveLoc)), string.format("ohne Fehler %s, angewandt %s, zurück %s", S(ok), S(applied), S(textBack)),
			"ohne Fehler true, (angewandt nur als Entwickler), zurück true"
	end)
	C("T-L2", "F", "Entwickler-Prüfung wirft einen Fehler: Spielsprache, Laden geht weiter", function()
		local saveDL, saveLoc = ThreatSentinelDB.devLocale, ns.activeLocale
		ThreatSentinelDB.devLocale = (saveLoc == "deDE") and "enUS" or "deDE"
		local r = {}
		r[1] = { pcall(ns.ApplyDevLocale, ns, { IsDev = function() error("TS-Test: Prüfung kaputt") end }) }
		r[2] = { pcall(ns.ApplyDevLocale, ns, { IsDev = function(self) return self == nil end }) }   -- Punkt statt Doppelpunkt
		r[3] = { pcall(ns.ApplyDevLocale, ns, { IsDev = "kein Funktion" }) }
		local same = ns.activeLocale == saveLoc
		ns:ApplyLocale(saveLoc)
		ThreatSentinelDB.devLocale = saveDL
		local got = string.format("%s/%s %s/%s %s/%s, Sprache gleich %s", S(r[1][1]), S(r[1][2]), S(r[2][1]), S(r[2][2]), S(r[3][1]), S(r[3][2]), S(same))
		local want = "true/false true/false true/false, Sprache gleich true"
		return got == want, got, want
	end)
	if ns.activeLocale and ns.activeLocale ~= ((GetLocale() == "deDE") and "deDE" or "enUS") then
		C("T128", "F", "Andere Sprache aktiv (Entwickler-Sprachtest)", function()
			local other = ns.LOCALES[ns.activeLocale]
			local okText = L.METER_ORDER_SURE == other.METER_ORDER_SURE and L.TR_ABORTED == other.TR_ABORTED
			local wins = {}
			if ns.Options and ns.Options.Toggle then
				local ok = pcall(function() if not (ns.Options.frame and ns.Options.frame:IsShown()) then ns.Options:Toggle() end end)
				wins[#wins + 1] = "Einstellungen " .. S(ok)
			end
			R.clearDevLocale = true   -- am Ende der Routine löschen (nach dem Zurücksetzen der Sandbox)
			return okText, ns.activeLocale .. " · Texte " .. S(okText) .. " · " .. table.concat(wins, ", "), "Texte der anderen Sprache"
		end)
	else
		CL("T128", "F", "Andere Sprache aktivieren", "/ts testroutine sprache, dann /reload, dann /ts testroutine f (Popups und Tastenbelegungs-Namen bleiben in der Spielsprache)")
	end
	C("T129", "F", "Gemeinsame Dateien liefern Text", function()
		local G = GoldSentinelGame
		local ok = type(G.Status()) == "string"
		return ok, "Status", "Text"
	end)
end

------------------------------------------------------------
-- G. Zusammenspiel
------------------------------------------------------------
local OWN_FRAMES = { "ThreatSentinelCenter", "ThreatSentinelDD", "ThreatSentinelDmgMeter", "ThreatSentinelGuide", "ThreatSentinelHUD",
	"ThreatSentinelSummary", "ThreatSentinelMeter", "ThreatSentinelMoveBar", "ThreatSentinelSoundPicker", "ThreatSentinelOptions",
	"ThreatSentinelMinimapButton", "ThreatSentinelTauntButton", "ThreatSentinelAoeButton", "ThreatSentinelPreview", "ThreatSentinelReport",
	"ThreatSentinelTest" }

Area.G = function()
	C("T130", "G", "Globale Namen gehören ThreatSentinel", function()
		local map = { ThreatSentinelCenter = ns.Alerts.center, ThreatSentinelHUD = ns.HUD.f, ThreatSentinelMeter = ns.Meter.f,
			ThreatSentinelDD = ns.DD.f, ThreatSentinelDmgMeter = ns.DmgMeter.f, ThreatSentinelOptions = ns.Options.frame,
			ThreatSentinelTest = ns.Test.frame, ThreatSentinelReport = ns.Test.report }
		for name, obj in pairs(map) do
			if obj and _G[name] ~= obj then return false, name, "eigenes Objekt" end
		end
		return type(ThreatSentinelDB) == "table" and BINDING_HEADER_THREATSENTINEL ~= nil, "ok"
	end)
	-- Befund 18.11.: _G am Stück durchgehen dauerte im Spiel 47,4 ms (ein Bild). Jetzt in Portionen VOR der Prüfung
	-- (R:ScanGlobals gibt zwischen den Portionen ab), die Prüfung selbst wertet nur noch die Liste aus.
	local before = R.globalsBefore
	local new, scanned = {}, false
	if before then
		scanned = R:ScanGlobals(function(k, v)
			local own = type(k) == "string" and (k:match("^ThreatSentinel") or k:match("^GoldSentinel"))
			-- Das Spiel legt manche Blizzard-Funktionen/-Tabellen erst beim ersten Zugriff an (gross geschrieben,
			-- Funktion oder Tabelle) - das ist kein Leck. Ein Leck aus eigenem Code ist klein geschrieben
			-- oder ein einfacher Wert.
			local lazyBlizz = type(k) == "string" and k:match("^[A-Z_]") and (type(v) == "function" or type(v) == "table" or type(v) == "userdata")
			if not before[k] and not own and not lazyBlizz and #new < 5 then new[#new + 1] = tostring(k) end
		end)
	end
	C("T131", "G", "Keine neuen Globals durch die Routine", function()
		if before == nil then return true, "keine Vorher-Liste (einzelner Bereich)" end
		if before == false or not scanned then return false, "Liste der Globals nicht vollständig (Durchlauf mehrfach unterbrochen)", "vollständig" end
		return #new == 0, #new == 0 and "keine" or table.concat(new, ", "), "keine (ausser eigenen Fenstern ThreatSentinel*)"
	end)
	C("T132", "G", "Gemeinsame GoldSentinelGame-Fassung", function()
		local G = _G.GoldSentinelGame
		return type(G) == "table" and (G.version or 0) >= 2 and ns.Game == G, "Version " .. S(G and G.version), ">= 2"
	end)
	C("T-Q4", "G", "DD-Ansicht im Modus ANZEIGE: lesbares isTanking/Stufe warnt, geschützt wie bisher", function()
		local D = ns.DD
		if not D.f then return false, "DD-Ansicht fehlt", "Rahmen" end
		local was, saveSim, saveWarn = D.f:IsShown(), ns.simAccess, D.warned
		local plays = 0
		Swap(ns.Alerts, "Play", function() plays = plays + 1 end)
		ns.simAccess = "secret"
		local ok, res = pcall(WithAPI, {}, function()
			local r = {}
			D.warned = false
			D:ShowSecret(50, 3, true);           r[1] = D.f.text:GetText() == L.DD_AGGRO
			D:ShowSecret(50, 3, true);           r[2] = plays == 1
			D:ShowSecret(50, SECRET, SECRET);    r[3] = D.f.text:GetText() ~= L.DD_AGGRO and D.f.text:GetText() ~= L.DD_OVER_TANK
			D:ShowSecret(50, 1, false);          r[4] = D.f.text:GetText() == L.DD_OVER_TANK
			D:ShowSecret(50, 0, false);          r[5] = D.f.text:GetText() ~= L.DD_AGGRO
			return table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]) }, " ")
		end)
		UnswapAll()
		ns.simAccess, D.warned = saveSim, saveWarn
		if was then D.f:Show() else D.f:Hide() end
		if not ok then error(res, 0) end
		local want = "true true true true true"
		return res == want, res, "Aggro (Ton 1x) / geschützt neutral / über Tank / Stufe 0 neutral"
	end)
	C("T-Q5", "G", "Sync im Kampf: Rolle nachholen, Ereignisse verwerfen", function()
		local S2 = ns.Sync
		local save = { ns.db.sync, ns.isModern, S2.pending.H }
		ns.db.sync, ns.isModern = true, true
		local ok, res = pcall(function()
			local r = {}
			WithAPI({ InCombatLockdown = Ret(true), IsInGroup = Ret(true), IsInRaid = Ret(false) }, function()
				r[1] = S2:Send("H:TANK:" .. ns.version)
				r[2] = S2:Send("T:Creature-0-0-0-0-91001-0000000001:8")
			end)
			local queued = S2.pending.H ~= nil and S2.pending.T == nil
			local before = (ns.actLog and ns.actLog.n.addonmsg) or 0
			local n = WithAPI({ InCombatLockdown = Ret(false), IsInGroup = Ret(true), IsInRaid = Ret(false) }, function() return S2:Flush() end)
			local sent = ((ns.actLog and ns.actLog.n.addonmsg) or 0) - before
			-- nach dem Kampf die Gruppe verlassen: nichts gesendet -> nachgeholt 0
			WithAPI({ InCombatLockdown = Ret(true), IsInGroup = Ret(true), IsInRaid = Ret(false) }, function() S2:Send("H:TANK:" .. ns.version) end)
			local n2 = WithAPI({ InCombatLockdown = Ret(false), IsInGroup = Ret(false), IsInRaid = Ret(false) }, function() return S2:Flush() end)
			return string.format("im Kampf %s/%s, gemerkt %s, nachgeholt %d (%d gesendet), leer %s, ohne Gruppe nachgeholt %d",
				S(r[1]), S(r[2]), S(queued), n, sent, S(next(S2.pending) == nil), n2)
		end)
		ns.db.sync, ns.isModern, S2.pending.H = save[1], save[2], save[3]
		if not ok then error(res, 0) end
		local want = "im Kampf false/false, gemerkt true, nachgeholt 1 (1 gesendet), leer true, ohne Gruppe nachgeholt 0"
		return res == want, res, want
	end)
	C("T-SY2", "G", "Sync-Weg: in Gruppe PARTY/RAID, ohne Gruppe nichts senden (Zähler 'ohne Gruppe', nicht 'verworfen')", function()
		local S2 = ns.Sync
		local saveSync = ns.db.sync
		ns.db.sync = true
		local ok, res = pcall(function()
			local r = {}
			WithAPI({ IsInRaid = Ret(false), IsInGroup = Ret(true) }, function() r[1] = S2._Channel() end)
			WithAPI({ IsInRaid = Ret(true), IsInGroup = Ret(true) }, function() r[2] = S2._Channel() end)
			local before = (ns.actLog and ns.actLog.n.addonmsg) or 0
			WithAPI({ IsInRaid = Ret(false), IsInGroup = Ret(false), InCombatLockdown = Ret(false) }, function()
				r[3] = S2._Channel()
				S2:Send("H:TEST")
			end)
			local sent = ((ns.actLog and ns.actLog.n.addonmsg) or 0) - before
			return S(r[1]) .. " / " .. S(r[2]) .. " / " .. S(r[3]) .. ", gesendet " .. sent
		end)
		ns.db.sync = saveSync
		if not ok then error(res, 0) end
		local want = "PARTY / RAID / nil, gesendet 0"
		return res == want, res, want .. " (ohne Gruppe: Zähler 'ohne Gruppe', ausserhalb der Testroutine)"
	end)
	C("T133", "G", "Slash- und Prefix-Kollisionen", function()
		for k, v in pairs(_G) do
			if type(k) == "string" and k:match("^SLASH_") and v == "/ts" and not k:match("^SLASH_THREATSENTINEL%d") then
				return false, k, "/ts nur ThreatSentinel"
			end
		end
		if C_ChatInfo and C_ChatInfo.IsAddonMessagePrefixRegistered then
			local ok, r = pcall(C_ChatInfo.IsAddonMessagePrefixRegistered, ns.Sync.PREFIX)
			if ok and r == false then return false, "Prefix nicht angemeldet", "angemeldet" end
		end
		return true
	end)
	K("T134", "G", "Schnittstellen zu den anderen Addons", "keine Schnittstelle")
	CL("T135", "G", "Mehrere GoldSentinel-Addons gleichzeitig", "Mit RaidMaster, GuildSentinel, BuffSentinel, ProfessionSentinel laden, /reload, /gsgame: eine Zeile, Version 3; /ts testroutine g")
end

------------------------------------------------------------
-- H. Leistung
------------------------------------------------------------
local function Time(n, fn)
	local t = Ms()
	for _ = 1, n do fn() end
	return (Ms() - t) / n
end

Area.H = function()
	C("T136", "H", "T:Tick mit 10 und 40 Testmobs (Modus VOLL)", function()
		local res, worst = {}, nil
		for _, n in ipairs({ 10, 40 }) do
			local sc = Scene.New(n)
			for i = 1, n, 3 do Scene.Hold(sc, "tsfake" .. i, "party1", {}) end   -- jeder dritte lose
			local v = Scene.Run(sc, function()
				ns.simAccess = "open"
				ns.Threat:Tick()
				return Time(3, function() ns.Threat:Tick() end)   -- 3 statt 20 Wiederholungen: kürzeres Bild (NP-TS16-1, leistung.md)
			end)
			local limit = n == 10 and 2 or 8
			res[#res + 1] = string.format("%d Mobs %.2f ms", n, v)
			if v > limit then worst = n end
		end
		return worst == nil, table.concat(res, ", "), "10 Mobs < 2 ms, 40 Mobs < 8 ms"
	end)
	C("T137", "H", "Anzeigen (echter Zustand, je 50x)", function()
		local parts = {}
		local worst
		local function m(name, fn, limit)
			local v = Time(50, fn)
			parts[#parts + 1] = string.format("%s %.2f", name, v)
			if v > limit then worst = name end
		end
		m("Meter", function() ns.Meter:Tick() end, 1)
		m("DD", function() ns.DD:Tick() end, 0.5)
		m("HUD", function() ns.HUD:Update({}, {}) end, 0.5)
		m("DmgMeter", function() ns.DmgMeter:Tick() end, 1)
		m("CheckCC", function() ns.Alerts:CheckCC() end, 0.1)
		m("Specs", function() ns.Specs:Step() end, 1)
		return worst == nil, table.concat(parts, ", ") .. " ms", "unter den Grenzen"
	end)
	C("T138", "H", "Bildweise OnUpdate (Flammen, Testzentrale, Meldung)", function()
		local sc = Scene.New(0)
		return Scene.Run(sc, function()
			local P, db = ns.Plates, ns.db
			ns.Test:CreatePreview()
			local ufs = {}
			for _, uf in ipairs(ns.Test.preview.plates) do ufs[#ufs + 1] = uf end
			R.extraPlates = R.extraPlates or {}
			while #ufs + #R.extraPlates < 10 do
				local uf = CreateFrame("Frame", nil, ns.Test.preview.holder)
				uf:SetSize(120, 34)
				local hb = CreateFrame("StatusBar", nil, uf)
				hb:SetSize(110, 10)
				hb:SetPoint("BOTTOM", uf, "BOTTOM", 0, 4)
				uf.healthBar = hb
				R.extraPlates[#R.extraPlates + 1] = uf
			end
			for _, uf in ipairs(R.extraPlates) do if #ufs < 10 then ufs[#ufs + 1] = uf end end
			local saveFire = db.looseFire
			db.looseFire = true
			for _, uf in ipairs(ufs) do P:Apply(uf, { state = "LOOSE", victim = "Torben", victimRole = "DAMAGER" }) end
			local fire = P._fireDriver:GetScript("OnUpdate")
			local t1 = Time(50, function() fire(P._fireDriver, 0.1) end)
			local tf = ns.Test.frame
			local tm = tf and tf:GetScript("OnUpdate")
			local t2 = tm and Time(10, function() tm(tf, 1) end) or 0
			local cf = ns.Alerts.center
			local co = cf and cf:GetScript("OnUpdate")
			local saveExp, wasShown = cf and cf.expire, cf and cf:IsShown()
			local t3 = co and Time(50, function() cf.expire = GetTime() + 10; co(cf) end) or 0
			if cf then cf.expire = saveExp; if wasShown then cf:Show() else cf:Hide() end end
			db.looseFire = saveFire
			for _, uf in ipairs(R.extraPlates) do P:RestoreFrame(uf) end
			local got = string.format("Flammen (%d Plaketten) %.3f ms, Testzentrale %.2f ms, Meldung %.3f ms", #ufs, t1, t2, t3)
			return t1 < 0.5 and t2 < 2 and t3 < 0.05, got, "< 0.5 / < 2 / < 0.05 ms"
		end)
	end)
	C("T-W1", "H", "Spott fehlgeschlagen: Grund aus der Fehlermeldung des Spiels (beide Reihenfolgen)", function()
		local LG, root = ns.Log, ThreatSentinelDB
		local saveLog, saveOn, saveScan, saveSpell = root.testlog, LG.on, LG.scan, ns.tauntSpell
		local saveErr = { LG.lastErr, LG.lastErrT, LG.lastFailT, LG.failOpen }
		root.testlog = { on = true, shots = false, meta = {}, events = {} }
		LG.on, LG.scan, ns.tauntSpell = true, nil, "TSSpott"
		LG.lastErr, LG.lastErrT, LG.lastFailT, LG.failOpen = nil, 0, 0, false
		local saveExtra = LG.whyExtra
		LG.whyExtra = { ["TS noch nicht bereit x 1"] = true, ["TS zu weit entfernt"] = true }
		local fire = LG._castFrame:GetScript("OnEvent")
		local ok, res = pcall(WithAPI, { C_Spell = { GetSpellName = function(id) return id == 99901 and "TSSpott" or nil end }, GetSpellInfo = NIL }, function()
			LG:E("META", "date", "T", "client", "X", "version", ns.version)
			fire(LG._castFrame, "UI_ERROR_MESSAGE", 51, "TS noch nicht bereit|x=1")   -- Grund zuerst
			fire(LG._castFrame, "UNIT_SPELLCAST_FAILED", "player", nil, 99901)
			LG.lastErrT = 0
			fire(LG._castFrame, "UNIT_SPELLCAST_FAILED", "player", nil, 99901)           -- Fehlschlag zuerst
			fire(LG._castFrame, "UI_ERROR_MESSAGE", 52, "TS zu weit entfernt")
			fire(LG._castFrame, "UNIT_SPELLCAST_SUCCEEDED", "player", nil, 99901)
			-- unbekannte Meldung (könnte einen Namen tragen) -> nur "anderer Grund"
			LG.lastErrT = 0
			fire(LG._castFrame, "UI_ERROR_MESSAGE", 53, "TSName ist beschäftigt")
			fire(LG._castFrame, "UNIT_SPELLCAST_FAILED", "player", nil, 99901)
			-- Einträge im Protokoll (alle Clients)
			local a, b, c, leak = 0, 0, 0, false
			local other = "why=" .. ns.L.TAUNT_WHY_OTHER
			for _, line in ipairs(root.testlog.events) do
				if line:find("why=TS noch nicht bereit x 1", 1, true) then a = a + 1 end
				if line:find("TAUNTWHY", 1, true) and line:find("why=TS zu weit entfernt", 1, true) then b = b + 1 end
				if line:find(other, 1, true) then c = c + 1 end
				if line:find("TSName", 1, true) then leak = true end
			end
			if c ~= 1 or leak then return string.format("anderer Grund %d, Name im Protokoll %s", c, S(leak)) end
			-- Zusammenfassung (nur moderne API; Era/TBC zeigen nur die Sichtprüfung)
			LG.scan = nil
			local sum = LG:SummaryText(true) or ""
			local inSum = not ns.isModern or (sum:find("TS noch nicht bereit x 1 1", 1, true) ~= nil and sum:find("TS zu weit entfernt 1", 1, true) ~= nil)
			return string.format("Grund vorher %d, Grund nachher %d, Zusammenfassung %s", a, b, ns.isModern and S(inSum) or "nur Sichtprüfung")
		end)
		root.testlog, LG.on, LG.scan, ns.tauntSpell = saveLog, saveOn, saveScan, saveSpell
		LG.lastErr, LG.lastErrT, LG.lastFailT, LG.failOpen = saveErr[1], saveErr[2], saveErr[3], saveErr[4]
		LG.whyExtra = saveExtra
		if not ok then error(res, 0) end
		local good = res:find("^Grund vorher 1, Grund nachher 1, Zusammenfassung ") ~= nil and not res:find("false", 1, true)
		return good, Clean(res), "Grund vorher 1, Grund nachher 1, Zusammenfassung true (Trennzeichen entfernt; fremde Meldung nur 'anderer Grund')"
	end)
	C("T139b", "H", "Protokoll-Auswertung nach /reload ('META cont=1' in der Mitte)", function()
		local LG, root = ns.Log, ThreatSentinelDB
		local saveLog, saveOn, saveScan = root.testlog, LG.on, LG.scan
		root.testlog = { on = true, shots = false, meta = {}, events = {} }
		LG.on, LG.scan = true, nil
		local ok, a, b, c = pcall(function()
			local function gen(k)
				for i = 1, k do LG:E("STATE", "id", "m" .. (i % 5), "s", (i % 3 == 0) and "LOOSE" or "HELD", "role", "DAMAGER") end
			end
			LG:E("META", "date", "T", "client", "X", "version", ns.version)
			gen(300)
			local guard = 0
			while not LG:Analyze(100) and guard < 50 do guard = guard + 1 end
			LG:E("META", "date", "T", "client", "X", "version", ns.version, "cont", "1")
			gen(300)
			local n, steps = #root.testlog.events, 0
			while LG.scan and LG.scan.n < n and steps < 50 do LG:Analyze(100); steps = steps + 1 end
			local reached = LG.scan and LG.scan.n == n or false
			local inc = LG:SummaryText(true)
			LG.scan = nil
			local full = LG:SummaryText(true)
			return reached, steps, inc == full
		end)
		root.testlog, LG.on, LG.scan = saveLog, saveOn, saveScan
		if not ok then error(a, 0) end
		local got = string.format("Ende erreicht %s in %d Häppchen, gleich wie ganz %s", S(a), b, S(c))
		return a == true and b <= 4 and c == true, got, "Ende erreicht true in <= 4 Häppchen, gleich wie ganz true"
	end)
	C("T139", "H", "Protokoll-Auswertung (Häppchen und nur neue Einträge)", function()
		local LG = ns.Log
		local saved = LG.scan
		local n = LG:Count()
		LG.scan = nil
		local chunk = Time(1, function() LG:Analyze(LG.ANALYZE_CHUNK) end)   -- grösstes Stück je Bild (Hintergrund)
		local guard = 0
		while LG.scan and LG.scan.n < n and guard < 100 do LG:Analyze(LG.ANALYZE_CHUNK); guard = guard + 1 end
		local open = Time(5, function() LG:Analyze() end)                    -- Öffnen: nur neue Einträge
		LG.scan = saved
		return chunk < 16 and open < 16, string.format("%d Einträge: Häppchen %.2f ms, Öffnen %.2f ms", n, chunk, open), "beide < 16 ms"
	end)
	-- leistung.md Regel 2 (17.11.): keine ganze Speicherbereinigung, auch nicht in Tests. Gemessen wird, wie viel Speicher die
	-- Durchläufe ANLEGEN (5 Durchläufe je Versuch, Zuwachs von collectgarbage("count") ohne Bereinigung). Läuft dazwischen ein Bereinigungs-Schritt, ist der
	-- Zuwachs kleiner oder negativ – darum 3 Versuche, gewertet der grösste Zuwachs (der ohne Bereinigung).
	C("T140", "H", "Speicher bei T:Tick: angelegt je Durchlauf (ohne ganze Bereinigung)", function()
		-- Szene mit 10 Gegnern im Kampf (sonst kehrt T:Tick sofort zurück und es gibt nichts zu messen); mitgezählt wird auch,
		-- was der Nachbau der Spiel-Funktionen anlegt (obere Schranke für das Addon)
		local sc = Scene.New(10)
		for i = 1, 10, 3 do Scene.Hold(sc, "tsfake" .. i, "party1") end
		local best = Scene.Run(sc, function()
			ns.simAccess = "open"
			ns.Threat:Tick()
			local b
			for _ = 1, 3 do
				local before = collectgarbage("count")
				for _ = 1, 5 do ns.Threat:Tick() end
				local grow = collectgarbage("count") - before
				if not b or grow > b then b = grow end
			end
			return b
		end)
		local per = best / 5
		return per < R.TICK_ALLOC_KB, string.format("%.2f KB je Durchlauf mit 10 Gegnern (grösster von 3 Versuchen, mit Nachbau)", per), "< " .. R.TICK_ALLOC_KB .. " KB"
	end)
end

------------------------------------------------------------
-- I. Fehlerzählung und Diagnose
------------------------------------------------------------
Area.I = function()
	C("T141", "I", "Absichtlicher Fehler wird gezählt", function()
		local n, last = ns.errorCount, ns.lastError
		ns.routineSelfTest = true
		ns:ReportError("TS-Selbsttest")
		ns.routineSelfTest = nil
		local ok = ns.errorCount == n + 1 and ns.lastError == "TS-Selbsttest"
		local lines = Capture(function() ns.ThreatAccess:Report() end)
		local rep = Has(lines, string.format(L.TA_R_ERRORS, ns.errorCount))
		ns.errorCount, ns.lastError = n, last
		return ok and rep, S(ok) .. "/" .. S(rep), "gezählt und angezeigt"
	end)
	C("T142", "I", "Fehler in einem Teil hält den Durchlauf nicht an", function()
		local n = ns.errorCount
		local meter = 0
		local realMeter = ns.Meter.Tick
		Swap(ns.DD, "Tick", function() error("TS-Selbsttest DD") end)
		Swap(ns.Meter, "Tick", function(...) meter = meter + 1; return realMeter(...) end)
		ns.routineSelfTest = true
		local active = ns:IsActive()
		ns.Threat:Tick()
		ns.routineSelfTest = nil
		UnswapAll()
		local diff = ns.errorCount - n
		ns.errorCount = n
		return diff >= 1 and meter >= 1, "Fehler +" .. diff .. ", Meter " .. meter .. "x (aktiv " .. S(active) .. ")", "Fehler gezählt, Meter läuft"
	end)
	C("T143", "I", "Fehler in einem Ereignis-Handler", function()
		local n = ns.errorCount
		local ran = false
		local bad = function() error("TS-Selbsttest Handler") end
		local good = function() ran = true end
		ns:On("PLAYER_ALIVE", bad); ns:On("PLAYER_ALIVE", good)
		ns.routineSelfTest = true
		ns:Fire("PLAYER_ALIVE")
		ns.routineSelfTest = nil
		ns:Off("PLAYER_ALIVE", bad); ns:Off("PLAYER_ALIVE", good)
		local diff = ns.errorCount - n
		ns.errorCount = n
		return diff == 1 and ran, "Fehler +" .. diff .. ", übrige " .. S(ran), "+1, übrige laufen"
	end)
	-- Hinweis "Fehler aufgetreten" einmal pro Sitzung. IsTesting ist auch bei offener Testzentrale wahr (Bereich K
	-- verlangt sie offen) - darum für die Prüfung auf "nein" ersetzen (eigene Tabelle, danach zurück). Q1, 10.11.
	local function NoticeCount()
		local n, last, noticed = ns.errorCount, ns.lastError, ns.errorNoticed
		ns.errorNoticed = nil
		ns.routineSelfTest = true
		Swap(ns.Test, "IsTesting", function() return false end)
		local ok, lines = pcall(Capture, function() ns:ReportError("TS-Selbsttest 1"); ns:ReportError("TS-Selbsttest 2") end)
		UnswapAll()
		ns.routineSelfTest = nil
		ns.errorCount, ns.lastError, ns.errorNoticed = n, last, noticed
		if not ok then error(lines, 0) end
		local c = 0
		for _, l in ipairs(lines) do if l:find(L.ERR_NOTICE, 1, true) then c = c + 1 end end
		return c
	end
	C("T144", "I", "Hinweis einmal pro Sitzung", function()
		if not ns.isModern then return true, "alte API: kein Hinweis" end
		local c = NoticeCount()
		return c == 1, c .. "x", "1x"
	end)
	C("T-Q1", "I", "Hinweis einmal pro Sitzung auch bei offener Testzentrale", function()
		if not ns.isModern then return true, "alte API: kein Hinweis" end
		local f = ns.Test.frame
		if not f then return true, "Testzentrale nie geöffnet" end
		local was = f:IsShown()
		f:Show()
		local ok, c = pcall(NoticeCount)
		if not was then f:Hide() end
		if not ok then error(c, 0) end
		return c == 1, c .. "x", "1x"
	end)
	C("T-Q2", "I", "Simulationen zurückgesetzt: Vergleich vorher/nachher mit Ort", function()
		local a = R.SimResult({ moveMode = true }, { moveMode = true })
		local b = R.SimResult({}, { moveMode = true })
		local c = R.SimResult({}, {})
		local got = a .. " | " .. b .. " | " .. c
		local ok = a:find("^OK %(") ~= nil and b == "FEHLER (moveMode an)" and c == "OK"
		return ok, got, "OK (… war schon an) | FEHLER (moveMode an) | OK"
	end)
	C("T-Q3", "I", "Hinweiszeile zu Beginn, wenn Testmodus/Verschiebe-Modus/Testzentrale schon an", function()
		local a = R.PreNotice({ testMode = true, center = true }) or ""
		local b = R.PreNotice({})
		return a ~= "" and b == nil, Clean(a) .. " | " .. S(b), "Zeile mit den Namen | nil"
	end)
	C("T145", "I", "Gesperrte Aktion wird gezählt", function()
		local n, nb = ns.errorCount, #ns.blocked
		ns.routineSelfTest = true
		ns:Fire("ADDON_ACTION_BLOCKED", ADDON, "TestFunc")
		ns:Fire("ADDON_ACTION_BLOCKED", "FremdesAddon", "TestFunc")
		ns.routineSelfTest = nil
		local ok = #ns.blocked == nb + 1 and ns.errorCount == n + 1
		local added = #ns.blocked - nb
		while #ns.blocked > nb do table.remove(ns.blocked) end
		ns.errorCount = n
		return ok, "blocked +" .. added, "+1 (fremdes Addon nichts)"
	end)
	C("T146", "I", "Fehlerschritt im Testassistenten", function()
		local step
		for _, s in ipairs(ns.Guide.STEPS) do if s.id == "errors" then step = s end end
		if not step then return false, "Schritt fehlt", "errors" end
		return true, "vorhanden"
	end)
	C("T-GT1", "I", "GoldSentinelTest Version 2 geladen", function()
		local v = GoldSentinelTest and GoldSentinelTest.version
		return type(v) == "number" and v >= 2, S(v), "2 oder neuer"
	end)
	C("T-GT2", "I", "Ohne Zustimmung bleibt der Ausgang (Fehlerberichte teilen) leer", function()
		local GT = GoldSentinelTest
		if not (GT and GT.Outbox and GT.registry) then return false, "GoldSentinelTest 2 fehlt", "Outbox" end
		local db = ThreatSentinelDB
		-- Zustimmung in jeder angemeldeten Datenbank einzeln merken, auf "nein" setzen und danach zurücksetzen
		local saved = {}
		for name, reg in pairs(GT.registry) do
			local sh = reg.db and reg.db.gsTest and reg.db.gsTest.share
			if sh then saved[name] = { sh = sh, consent = sh.consent, collector = sh.collector } ; sh.consent = false; sh.collector = nil end
		end
		local before = db.gsTest and db.gsTest.share and db.gsTest.share.outbox and #db.gsTest.share.outbox or 0
		local ok, err = pcall(GT.Outbox, db, { kind = "test", addon = ADDON, version = ns.version,
			errors = { { wo = "TS-Test", msg = "TS-Zustimmungstest", count = 1 } }, results = {}, env = {}, counts = {} })
		local after = db.gsTest and db.gsTest.share and db.gsTest.share.outbox and #db.gsTest.share.outbox or 0
		for _, x in pairs(saved) do x.sh.consent, x.sh.collector = x.consent, x.collector end
		if not ok then return false, Clean(err), "kein Fehler" end
		return after == before, before .. " -> " .. after, "unverändert"
	end)
	C("T-P3", "I", "Diagnose: Gruppe zählt Spieler und Begleiter getrennt", function()
		local save = ns.groupUnits
		ns.groupUnits = { "player", "party1", "partypet1", "party2", "party3", "party4" }
		local ok, extra = pcall(ns.DiagExtra)
		ns.groupUnits = save
		if not ok then return false, Clean(extra), "kein Fehler" end
		local line = ""
		for _, l in ipairs(extra) do if l:find("Spieler +", 1, true) then line = l end end
		return line:find("Gruppe 5 Spieler + 1 Begleiter", 1, true) ~= nil, Clean(line), "Gruppe 5 Spieler + 1 Begleiter"
	end)
	C("T187", "I", "Diagnose-Protokoll: Einträge, Zähler statt Schleife, Export GSDIAG1, keine Namen", function()
		if not (ns.Diag and ns.DiagText and ns.DiagExport) then return false, "Diag.lua fehlt", "ns.Diag/DiagText/DiagExport" end
		local root = ThreatSentinelDB
		local saved = root.diag and Copy(root.diag) or nil
		ns.diagForce = true
		local ok, err = pcall(function()
			root.diag = nil
			ns.Diag("MODUS", "VOLL -> ANZEIGE", 12.4)
			for _ = 1, 50 do ns.Diag("FEHLER", "TS-Diagnosetest gleicher Fehler") end
			WithAPI({}, function() ns.Diag("SECRET", SECRET) end)   -- WithAPI setzt den Köderwert ns.testBait
		end)
		local d = root.diag or { entries = {} }
		local n, first = #d.entries, d.entries[2]
		local text, exp = ns.DiagText(), ns.DiagExport()
		ns.diagForce = nil
		root.diag = saved
		if not ok then error(err, 0) end
		local count = first and first.k == "FEHLER" and first.n or 0
		local hasName = type(ns.playerName) == "string" and ns.playerName ~= "" and text:find(ns.playerName, 1, true) ~= nil
		local secretOk = d.entries[1] and d.entries[1].t == "<geschützt>"
		local good = n == 3 and count == 50 and exp:sub(1, 22) == "GSDIAG1|ThreatSentinel" and not hasName and secretOk
			and text:find("VOLL -> ANZEIGE", 1, true) ~= nil
		return good, string.format("%d Einträge, Fehler ×%d, Export %s, Name im Text %s, geschützt %s", n, count,
			S(exp:sub(1, 22)), S(hasName), S(secretOk)), "3 Einträge, ×50, GSDIAG1|ThreatSentinel, false, true"
	end)
	C("T189", "I", "Diagnose-Protokoll schreibt nicht während der Testroutine", function()
		local before = ThreatSentinelDB.diag and ThreatSentinelDB.diag.entries and #ThreatSentinelDB.diag.entries or 0
		local first = ThreatSentinelDB.diag and ThreatSentinelDB.diag.entries and ThreatSentinelDB.diag.entries[1]
		ns.Diag("TEST", "TS-darf nicht erscheinen")
		local after = ThreatSentinelDB.diag and ThreatSentinelDB.diag.entries and #ThreatSentinelDB.diag.entries or 0
		local same = (ThreatSentinelDB.diag and ThreatSentinelDB.diag.entries and ThreatSentinelDB.diag.entries[1]) == first
		return after == before and same, before .. " -> " .. after, "unverändert"
	end)
	CL("T188", "I", "Diagnose-Protokoll im Spiel", "/ts protokoll öffnet ein Fenster mit markierbarem Text; nach /reload liegt ThreatSentinelDB.diagExport (beginnt mit GSDIAG1) in den SavedVariables und geht mit dem Uploader nach #testberichte")
	K("T147", "I", "Lua-Fehler ausserhalb von pcall", "würde einen echten Fehler im Fehlerfenster/BugSack des Spielers auslösen; GoldSentinelTest.TrackErrors ist angemeldet (siehe Core.lua)")
end

------------------------------------------------------------
-- J. Regressionstests
------------------------------------------------------------
Area.J = function()
	local TA = ns.ThreatAccess
	CL("T148", "J", "Kein Ersatz über das Ziel des Mobs (modern)", "Forever: Mob ohne Bedrohungsdaten bleibt IDLE (Diagnose 'Bedrohung am Ziel'), kein Leuchten")
	CL("T149", "J", "Kein stilles IDLE bei geschützten Werten", "Forever, erster Kampf: /ts bedrohung zeigt 'geschützt', Hinweis 1x")
	C("T150", "J", "Geschützte Namen nie als Schlüssel", function()
		local save = { ns.groupUnits, ns.groupNames, ns.nameToUnit }
		WithAPI({ IsInRaid = Ret(false), GetNumSubgroupMembers = Ret(1), UnitIsPlayer = Ret(true),
			UnitExists = function(u) return u == "party1" end,
			UnitName = function(u) if u == "party1" then return "Torben", SECRET end return SECRET, "" end }, function()
			ns:UpdateGroup()
		end)
		local keys = 0
		for k in pairs(ns.groupNames) do keys = keys + 1 end
		local units = #ns.groupUnits
		ns.groupUnits, ns.groupNames, ns.nameToUnit = save[1], save[2], save[3]
		return keys == 0 and units == 2, units .. " Einheiten, " .. keys .. " Namen", "2 Einheiten, 0 Namen"
	end)
	C("T151", "J", "Textfunktionen ohne geschützte Werte", function()
		ns.testBait = SECRET
		local i = ns.Plates._Initial(SECRET)
		ns.testBait = nil
		return i == "", "Initial '" .. i .. "'", "''"
	end)
	C("T152", "J", "Leere Aurenliste im Kampf = unbekannt", function()
		local save = ns.isModern
		ns.isModern = true
		local empty = { GetAuraDataByIndex = function() return nil end }
		local r1 = WithAPI({ UnitBuff = NIL, UnitDebuff = NIL, C_UnitAuras = empty, UnitAffectingCombat = Ret(true) }, function()
			local a, b = ns:FindAura("player", "HELPFUL", { [71] = true }); return S(ns.AuraEmptyUnknown()) .. " " .. S(a) .. "," .. S(b)
		end)
		local r2 = WithAPI({ UnitBuff = NIL, UnitDebuff = NIL, C_UnitAuras = empty, UnitAffectingCombat = Ret(false) }, function()
			local a, b = ns:FindAura("player", "HELPFUL", { [71] = true }); return S(ns.AuraEmptyUnknown()) .. " " .. S(a) .. "," .. S(b)
		end)
		ns.isModern = save
		return r1 == "true false,false" and r2 == "false false,true", r1 .. " | " .. r2, "im Kampf unbekannt | ausserhalb keine Aura"
	end)
	C("T153", "J", "Blizzard-Plaketten im Kampf nicht anfassen (ANZEIGE, verbotene Plakette)", function()
		local sc = Scene.New(2)
		Scene.Hold(sc, "tsfake1", "party1")
		Scene.Hold(sc, "tsfake2", "party1")
		sc.forbidden.tsfake2 = true
		return Scene.Run(sc, function()
			local P, T = ns.Plates, ns.Threat
			local uf1, uf2 = sc.plates.tsfake1, sc.plates.tsfake2
			local applied = {}
			local orig = P.Apply
			Swap(P, "Apply", function(self, uf, m) applied[uf] = (applied[uf] or 0) + 1; return orig(self, uf, m) end)
			ns.simAccess = "open"
			T:Tick()
			local fullForbidden = applied[uf2] or 0
			local fullOther = applied[uf1] or 0
			wipe(applied)
			ns.simAccess = "secret"
			T:Tick(); T:Tick()
			local disp = 0
			for _, n in pairs(applied) do disp = disp + n end
			local got = string.format("VOLL: normale %d, verbotene %d; ANZEIGE: %d", fullOther, fullForbidden, disp)
			-- uf1 und uf2 können dieselbe Vorschau-Plakette sein: dann zählt nur "verbotene 0" über GetUF
			return fullOther >= 1 and (uf1 == uf2 or fullForbidden == 0) and disp == 0 and P._GetUF("tsfake2") == nil, got, "VOLL: normale >= 1, verbotene nie (GetUF nil); ANZEIGE: 0"
		end)
	end)
	CL("T154", "J", "Taint im Modus VOLL", "Pull mit 3+ Mobs im Modus VOLL, danach /ts test > Bericht: 'Blocked: none'; kein 'ThreatSentinel hat eine Aktion blockiert'")
	C("T155", "J", "Moderne API überall wie Retail", function()
		if not ns.isModern then return true, "alte API (nur F)" end
		local cls = ns.class
		ns.class = "DRUID"
		local t = ns:DeficitText()
		ns.class = cls
		return t == L.DEFICIT_OTHER, S(t), "DEFICIT_OTHER"
	end)
	C("T156", "J", "Sync-Kampfsperre (moderne API)", function()
		local save = { ns.db.sync, ns.isModern }
		ns.db.sync, ns.isModern = true, true
		local r = WithAPI({ InCombatLockdown = Ret(true), IsInGroup = Ret(true), IsInRaid = Ret(false) }, function()
			return ns.Sync:Send("H:TEST")
		end)
		local mode = ns.compat.sync and ns.compat.sync.mode
		ns.db.sync, ns.isModern = save[1], save[2]
		return r == false and mode == "fallback", S(r) .. " " .. S(mode), "false fallback"
	end)
	CL("T157", "J", "Erkennung einmal pro Kampf, Zustand gespeichert", "Forever: zwei Kämpfe hintereinander, danach /ts bedrohung: 'zuletzt erkannt' mit Datum und Build")
	C("T158", "J", "Bedrohung prüfen zeigt geschützte Werte nie", function()
		ns.testBait = SECRET
		local s = TA._Shown(SECRET)
		ns.testBait = nil
		local a, b = TA._Shown(86.25), TA._Shown(3)
		return s == L.TA_PROTECTED and (a == "86.2" or a == "86.3") and b == "3", S(s) .. "/" .. S(a) .. "/" .. S(b), "geschützt/86.2/3"
	end)
	C("T159", "J", "'Voll' nicht erzwingbar", function()
		local save = { ns.threatAccess, ns.db.threatMode, ns.simAccess }
		ns.threatAccess, ns.simAccess = "secret", nil
		local bad
		for _, m in ipairs({ "AUTO", "DISPLAY", "FULL" }) do
			ns.db.threatMode = m
			if ns:ThreatMode() ~= "DISPLAY" then bad = m end
		end
		ns.threatAccess, ns.db.threatMode, ns.simAccess = save[1], save[2], save[3]
		return bad == nil, bad or "ok", "immer DISPLAY"
	end)
	C("T160", "J", "Drei Zustände simulierbar (Knopftext)", function()
		local TM = ns.Test
		if not TM.frame then TM:Build() end
		local saveAcc = ns.threatAccess
		ns.threatAccess = "open"
		local texts = {}
		Capture(function()
			for _, st in ipairs({ "open", "secret", "none" }) do
				TM:SetAccessSim(st)
				texts[#texts + 1] = TM.accBtn:GetText()
			end
			TM:SetAccessSim(nil)
		end)
		ns.threatAccess = saveAcc
		if ns.Alerts.ClearCenter then ns.Alerts:ClearCenter("test") end
		return texts[1] == L.TEST_ACC_open and texts[2] == L.TEST_ACC_secret and texts[3] == L.TEST_ACC_none, table.concat(texts, "/"), "TEST_ACC_open/secret/none"
	end)
	C("T161", "J", "Fehlerzahl in der Diagnose (L.D_ERRORS)", function()
		local TM = ns.Test
		if not TM.frame then TM:Build() end
		local save = ns.errorCount
		ns.errorCount = 7
		local d = TM:DiagText()
		ns.errorCount = save
		return d:find(L.D_ERRORS, 1, true) ~= nil and d:find(L.D_ERRORS .. ":|r 7", 1, true) ~= nil, "Diagnose", L.D_ERRORS .. ": 7"
	end)
	C("T162", "J", "G.Status in Diagnose und Bericht", function()
		local st = GoldSentinelGame.Status()
		local TM = ns.Test
		if not TM.frame then TM:Build() end
		local d, r = TM:DiagText(), TM:ReportText()
		local lines = Capture(function() TA:Report() end)
		return d:find(st, 1, true) ~= nil and r:find(st, 1, true) ~= nil and Has(lines, st), "Diagnose/Bericht/Bedrohung", "enthalten G.Status()"
	end)
	C("T163", "J", "Einstellungsfenster des Spiels: Settings-API, InterfaceOptions_AddCategory nur ohne Settings (alte Clients); kein EasyMenu", function()
		if not ns.Options.frame then ns.Options:Build() end
		local p = ns.Options:BuildSettingsPage()
		local modern = Settings and Settings.RegisterCanvasLayoutCategory and true or false
		local got = string.format("Seite %s · Weg %s", S(p ~= nil), modern and (ns.Options.settingsCategory and "Settings" or "Settings fehlt") or "alt")
		return p ~= nil and (not modern or ns.Options.settingsCategory ~= nil), got, "Seite true, Settings im modernen Client"
	end)
	C("T164", "J", "'unknown' + Fehlschlag -> 'secret'", function()
		local save = { ns.isModern, ns.threatAccess, TA.checked, TA.announced, TA.wantBlizzard, ns.groupUnits, ThreatSentinelDB.threatAccess }
		Swap(ns.Alerts, "Center", function() end)
		Swap(TA, "ApplyBlizzard", function() end)
		ns.isModern, ns.threatAccess, TA.checked = true, "unknown", true
		ns.groupUnits = { "player" }
		WithAPI({ UnitDetailedThreatSituation = Ret(SECRET, SECRET, SECRET, SECRET, SECRET), UnitThreatSituation = Ret(SECRET),
			UnitAffectingCombat = Ret(true) }, function()
			ns.Threat._ReadThreat("tsfake1")
		end)
		local acc = ns.threatAccess
		UnswapAll()
		ns.isModern, ns.threatAccess, TA.checked, TA.announced, TA.wantBlizzard, ns.groupUnits = save[1], save[2], save[3], save[4], save[5], save[6]
		ThreatSentinelDB.threatAccess = save[7]
		return acc == "secret", S(acc), "secret"
	end)
	C("T165", "J", "MAX_ATTEMPTS-Konstante und neuer Kampf", function()
		if not ns.isModern then return true, "alte API (nur F R)" end
		ns.threatAccess, TA.tempNone = "none", true
		ns:Fire("PLAYER_REGEN_DISABLED")
		return TA.MAX_ATTEMPTS == 40 and ns.threatAccess == "unknown", S(TA.MAX_ATTEMPTS) .. "/" .. S(ns.threatAccess), "40/unknown"
	end)
	C("T166", "J", "'unknown' ausserhalb des Kampfs = VOLL", function()
		local save = { ns.threatAccess, ns.simAccess, ns.db.threatMode }
		ns.threatAccess, ns.simAccess, ns.db.threatMode = "unknown", nil, "AUTO"
		local m = ns:ThreatMode()
		ns.threatAccess, ns.simAccess, ns.db.threatMode = save[1], save[2], save[3]
		return m == "FULL", m, "FULL (im Kampf DISPLAY: im Client prüfen)"
	end)
	C("T166b", "J", "'unknown' im Kampf ergibt ANZEIGE (nur modern)", function()
		local save = { ns.threatAccess, ns.simAccess, ns.db.threatMode, ns.isModern }
		ns.threatAccess, ns.simAccess, ns.db.threatMode = "unknown", nil, "AUTO"
		local r = {}
		WithAPI({ UnitAffectingCombat = Ret(true) }, function()
			ns.isModern = true; r[1] = ns:ThreatMode()
			ns.isModern = false; r[2] = ns:ThreatMode()
		end)
		ns.threatAccess, ns.simAccess, ns.db.threatMode, ns.isModern = save[1], save[2], save[3], save[4]
		return r[1] == "DISPLAY" and r[2] == "FULL", "modern " .. r[1] .. ", alt " .. r[2], "modern DISPLAY, alt FULL"
	end)
	C("T167", "J", "Aggrometer im Modus ANZEIGE ohne lesbare Werte: Tank, dann Gruppe", function()
		local save = { ns.groupUnits, ns.simAccess }
		ns.groupUnits = { "party1", "player", "party2" }
		ns.simAccess = "secret"
		local nm = { party1 = "Torben", player = "Anna", party2 = "Grimbar" }
		local M = ns.Meter
		Swap(ns, "GetRole", function(_, u) return u == "party2" and "TANK" or "DAMAGER" end)
		Swap(M, "Estimates", function() return nil end)
		M.sortT, M.measured = 0, true
		local ok, list = pcall(WithAPI, { UnitDetailedThreatSituation = function() return SECRET, SECRET, 50, SECRET end,
			UnitThreatSituation = Ret(SECRET), UnitExists = function(u) if u == "targettarget" then return SECRET end return true end,
			UnitName = function(u) return nm[u] end, UnitIsPlayer = Ret(true), UnitClass = Ret("Krieger", "WARRIOR") }, function()
			return ns.Meter:Collect()
		end)
		UnswapAll()
		ns.groupUnits, ns.simAccess = save[1], save[2]
		if not ok then error(list, 0) end
		local order = {}
		for i, e in ipairs(list or {}) do order[i] = Clean(e.name) end
		local good = #order == 3 and list[1].name == "Grimbar" and list[2].name == "Torben" and list[3].name == "Anna" and M.orderKind == "role"
		return good, table.concat(order, ",") .. " " .. S(M.orderKind), "Tank, dann Gruppe; Reihenfolge 'role'"
	end)
	------------------------------------------------------------
	-- Aggrometer im Modus ANZEIGE: Reihenfolge nach Aggro (anweisung-aggro-reihenfolge.txt, T-A1 bis T-A6)
	------------------------------------------------------------
	-- Kulisse: Ziel = Testmob 1; Reihenfolge der Gruppe: Anna (du), Torben, Lina, Grimbar
	local function MeterScene(threat, holder)
		local sc = Scene.New(1)
		sc.alias.target = "tsfake1"
		sc.alias.targettarget = holder
		sc.threat.tsfake1 = threat
		return sc
	end
	-- fn(collect) in der Kulisse, Modus ANZEIGE; collect(map, est) liefert Namen, Art und "~"-Markierungen
	local function MeterRun(sc, fn)
		return Scene.Run(sc, function()
			local M = ns.Meter
			ns.simAccess = "secret"
			local est
			Swap(M, "Estimates", function() if est then return est, {} end end)
			M.sortT, M.measured = 0, true
			wipe(M.prevRank)
			local scene = {}
			for k, v in pairs(ns.API) do scene[k] = v end
			local function collect(map, e, keepTime)
				est = e
				if not keepTime then M.sortT = 0 end
				local list = WithAPI(map or {}, function() return M:Collect() end)
				local names, marks = {}, {}
				for i, x in ipairs(list) do names[i] = tostring(x.name); marks[i] = x.estimated and "~" or "" end
				return table.concat(names, ","), M.orderKind, table.concat(marks, ",")
			end
			return fn(collect, scene)
		end)
	end
	-- nichts lesbar: Bedrohung, Stufe und Ziel des Mobs geschützt (Balkenwert bleibt sichtbar)
	local function NothingReadable(scene)
		return {
			UnitDetailedThreatSituation = function() return SECRET, SECRET, 50, SECRET end,
			UnitThreatSituation = Ret(SECRET),
			UnitExists = function(u) if u == "targettarget" then return SECRET end return scene.UnitExists(u) end,
		}
	end
	C("T-P1", "J", "Kein Wechsel zu VOLL im Kampf; VOLL erst nach zwei lesbaren Kämpfen", function()
		local TA = ns.ThreatAccess
		local sc = Scene.New(2)
		Scene.Hold(sc, "tsfake1", "party1")
		local saveModern = ns.isModern
		ns.isModern = true
		local ok, a, b, c = pcall(Scene.Run, sc, function()
			local T = ns.Threat
			ns.threatAccess, ns.simAccess, TA.openVotes = "secret", nil, 0
			local apply = Counter(ns.Plates, "Apply", false)
			local function fight(secretFirst)
				TA:FightStarted()
				TA.checked = false
				if secretFirst then TA:Set("secret") end
				TA:Probe({ "tsfake1" })            -- lesbarer Wert im selben Kampf
				T:Tick(); T:Tick()
				local during = ns.threatAccess .. "/" .. ns:ThreatMode() .. "/" .. apply.n
				WithAPI({ UnitAffectingCombat = Ret(false), InCombatLockdown = Ret(false) }, function() TA:FightEnded() end)
				return during
			end
			local r1 = fight(true)                       -- secret, dann lesbar
			local v1 = TA.openVotes .. " " .. ns.threatAccess
			local r2 = fight(false)                      -- nur lesbar: 1. Erkennung
			local v2 = TA.openVotes .. " " .. ns.threatAccess
			local r3 = fight(false)                      -- 2. Erkennung -> nach dem Kampf "open"
			local v3 = ns.threatAccess .. " " .. ns:ThreatMode()
			local got = string.format("im Kampf %s, %s, %s | danach %s; %s; %s", r1, r2, r3, v1, v2, v3)
			local want = "im Kampf secret/DISPLAY/0, secret/DISPLAY/0, secret/DISPLAY/0 | danach 0 secret; 1 secret; open FULL"
			return got == want, got, want
		end)
		ns.isModern = saveModern
		if not ok then error(a, 0) end
		return a, b, c
	end)
	C("T-P1b", "J", "/reload im Kampf: kein Wechsel zu VOLL ohne PLAYER_REGEN_DISABLED", function()
		local TA = ns.ThreatAccess
		local sc = Scene.New(1)
		local saveModern = ns.isModern
		ns.isModern = true
		local ok, a, b, c = pcall(Scene.Run, sc, function()
			ns.threatAccess, ns.simAccess = "unknown", nil
			TA.inFight, TA.openSeen, TA.secretSeen, TA.openVotes, TA.checked = false, false, false, 0, false
			TA:Probe({ "tsfake1" })                    -- lesbar, Spieler im Kampf (Kulisse), aber kein Kampfbeginn gesehen
			local got = string.format("%s/%s, gemerkt %s, im Kampf %s", tostring(ns.threatAccess), ns:ThreatMode(), S(TA.openSeen), S(TA.inFight))
			local want = "unknown/DISPLAY, gemerkt true, im Kampf true"
			return got == want, got, want
		end)
		ns.isModern = saveModern
		if not ok then error(a, 0) end
		return a, b, c
	end)
	C("T-A6b", "J", "LESBAR: leere Liste misst nicht, erste volle Liste im Kampf misst einmal", function()
		local M = ns.Meter
		local logged = {}
		Swap(ns, "Diag", function(kind, text) if kind == "LESBAR" then logged[#logged + 1] = tostring(text) end end)
		local saveM = M.measured
		local ok, res = pcall(function()
			M.measured = false
			WithAPI({ UnitAffectingCombat = Ret(true) }, function() M:MeasureOnce({ holder = true }, 0) end)
			local a = #logged .. " " .. S(M.measured)
			WithAPI({ UnitAffectingCombat = Ret(false) }, function() M:MeasureOnce({ holder = true }, 3) end)
			local b = #logged .. " " .. S(M.measured)
			WithAPI({ UnitAffectingCombat = Ret(true) }, function() M:MeasureOnce({ holder = true }, 3); M:MeasureOnce({ holder = true }, 3) end)
			return a .. " | " .. b .. " | " .. #logged .. " " .. S(M.measured)
		end)
		UnswapAll()
		M.measured = saveM
		if not ok then error(res, 0) end
		local want = "0 false | 0 false | 1 true"
		return res == want, res, want .. " (leer / ausserhalb Kampf / einmal)"
	end)
	C("T-A8", "J", "ANZEIGE: Mob greift niemanden aus der Gruppe an, nichts lesbar -> 'Tank zuerst'", function()
		local sc = MeterScene({ player = { true, 3, 100, 100, 1000 } }, nil)
		sc.units.wolf = { name = "Wolf" }
		sc.alias.targettarget = "wolf"             -- Ziel des Mobs lesbar, aber nicht aus der Gruppe
		return MeterRun(sc, function(collect, scene)
			local order, kind = collect({ UnitDetailedThreatSituation = function() return SECRET, SECRET, 50, SECRET end,
				UnitThreatSituation = Ret(SECRET) })
			local head = ""
			if ns.Meter.f then
				ns.Meter:Render(WithAPI({ UnitDetailedThreatSituation = function() return SECRET, SECRET, 50, SECRET end,
					UnitThreatSituation = Ret(SECRET) }, function() ns.Meter.sortT = 0; return ns.Meter:Collect() end), "Testmob 1", true)
				head = ns.Meter.f.order:GetText() or ""
				ns.Meter.f:Hide()
			end
			local got = order .. " " .. S(kind)
			local want = "Anna,Grimbar,Torben,Lina role"
			return got == want and (head == "" or head == L.METER_ORDER_ROLE), got .. " | Kopf '" .. head .. "'", want .. " | '" .. L.METER_ORDER_ROLE .. "'"
		end)
	end)
	C("T-M1", "J", "Messung je Plakette im Modus ANZEIGE (einmal je Kampf, ohne Namen)", function()
		local sc = Scene.New(3)
		return Scene.Run(sc, function()
			local T = ns.Threat
			local lines = {}
			Swap(ns, "Diag", function(kind, text) if kind == "LESBAR-PLAKETTEN" then lines[#lines + 1] = tostring(text) end end)
			local saveM, saveAt = T.measured, T.measureAt
			T.measured, T.measureAt = false, GetTime() - 1
			T:MeasurePlates(ns.mobs)
			T:MeasurePlates(ns.mobs)
			T.measured, T.measureAt = saveM, saveAt
			local line = lines[1] or ""
			local hasName = line:find("Anna", 1, true) or line:find("Torben", 1, true) or line:find("Testmob", 1, true)
			local good = #lines == 1 and line:find("Plaketten 3 (im Kampf 3)", 1, true) ~= nil
				and line:find("du: isTanking lesbar 3/3, Stufe lesbar 3/3, Aggro bei dir 3", 1, true) ~= nil and not hasName
			return good, #lines .. "x: " .. line, "1x: Plaketten 3 (im Kampf 3) · du: isTanking lesbar 3/3, Stufe lesbar 3/3, Aggro bei dir 3 · Gruppe: …"
		end)
	end)
	C("T-G1", "J", "Testassistent: Plaketten-Schritte im Modus ANZEIGE übersprungen (n/a)", function()
		local saveSim, saveAccess, saveMode = ns.simAccess, ns.threatAccess, ns.db.threatMode
		local skip, kept = {}, {}
		local plateSteps = { held = true, heldlook = true, warn = true, loose = true, looselook = true, hud = true, regain = true, regainlook = true }
		ns.simAccess = "secret"
		for _, st in ipairs(ns.Guide.STEPS) do
			if plateSteps[st.id] then
				if st.skipIf and st.skipIf() then skip[#skip + 1] = st.id else kept[#kept + 1] = st.id end
			end
		end
		-- VOLL: echte Sperre (Forever) und "immer nur Anzeige" dürfen den Testteil nicht umstellen
		ns.simAccess, ns.threatAccess, ns.db.threatMode = "open", "open", nil
		local fullSkips = 0
		local okFull, errFull = pcall(function()
			for _, st in ipairs(ns.Guide.STEPS) do
				if plateSteps[st.id] and st.skipIf and st.skipIf() then fullSkips = fullSkips + 1 end
			end
		end)
		ns.simAccess, ns.threatAccess, ns.db.threatMode = saveSim, saveAccess, saveMode
		if not okFull then error(errFull, 0) end
		return #kept == 0 and #skip == 8 and fullSkips == 0, string.format("ANZEIGE: %d übersprungen, übrig %s; VOLL: %d übersprungen",
			#skip, #kept > 0 and table.concat(kept, ",") or "-", fullSkips), "ANZEIGE: 8 übersprungen, übrig -; VOLL: 0 übersprungen"
	end)
	C("T-A1", "J", "ANZEIGE: wer die Aggro hat (Ziel des Mobs) steht oben", function()
		local sc = MeterScene({ party2 = { true, 3, 100, 100, 1000 }, player = { false, 2, 90, 90, 900 },
			party1 = { false, 1, 70, 70, 700 }, party3 = { false, 0, 30, 30, 300 } }, "party2")
		return MeterRun(sc, function(collect)
			local order, kind, marks = collect()
			local want = "Lina,Anna,Torben,Grimbar sure"
			local got = order .. " " .. S(kind)
			return got == want and not marks:find("~"), got, want .. " (ohne ~)"
		end)
	end)
	C("T-A2", "J", "ANZEIGE: nach dem Aggro-Halter nach Bedrohungsstufe", function()
		local sc = MeterScene({ player = { true, 3, 100, 100, 1000 }, party1 = { false, 2, 95, 95, 950 },
			party2 = { false, 1, 60, 60, 600 }, party3 = { false, 0, 20, 20, 200 } }, "player")
		return MeterRun(sc, function(collect)
			local order, kind = collect()
			local got = order .. " " .. S(kind)
			local want = "Anna,Torben,Lina,Grimbar sure"
			return got == want, got, want
		end)
	end)
	-- TS-S3a (Supervisor 23.11. 09:23): Stufe 3 (Formel aus Schaden/Heilung) ist aus. Gegenprobe: gleiche Lage mit und ohne
	-- Schadensdaten ergibt dieselbe feste Reihenfolge, kein "~", Kopf "Reihenfolge: geschützt".
	C("T-A3", "J", "ANZEIGE: nichts lesbar -> keine Formel-Reihenfolge, kein '~', Kopf 'geschützt' (TS-S3a)", function()
		local sc = MeterScene({ player = { true, 3, 100, 100, 1000 } }, "player")
		return MeterRun(sc, function(collect, scene)
			local withEst, kind, marks = collect(NothingReadable(scene), { Torben = 3000, Lina = 5000, Grimbar = 9000 })
			local without = collect(NothingReadable(scene), nil)
			local head, rowName = "", ""
			if ns.Meter.f then
				ns.Meter:Render(WithAPI(NothingReadable(scene), function() ns.Meter.sortT = 0; return ns.Meter:Collect() end), "Testmob 1", true)
				head = ns.Meter.f.order:GetText() or ""
				rowName = ns.Meter.f.rows[1].name:GetText() or ""
				ns.Meter.f:Hide()
			end
			local got = string.format("mit Schaden %s | ohne %s | Art %s | Zeichen '%s' | Kopf '%s' | Zeile 1 beginnt mit ~ %s",
				withEst, without, S(kind), marks:gsub(",", ""), head, S(rowName:sub(1, 1) == "~"))
			local want = string.format("mit Schaden %s | ohne %s | Art role | Zeichen '' | Kopf '%s' | Zeile 1 beginnt mit ~ false",
				without, without, ns.Meter.f and L.METER_ORDER_ROLE or "")
			return got == want, Clean(got), Clean(want)
		end)
	end)
	C("T-A4", "J", "ANZEIGE: Schaden/Heilung ändern die Reihenfolge nie (Stufe 3 aus, TS-S3a)", function()
		local sc = MeterScene({ player = { true, 3, 100, 100, 1000 } }, "player")
		return MeterRun(sc, function(collect, scene)
			local map = NothingReadable(scene)
			local a = collect(map, { Torben = 1000, Lina = 900 })
			local b = collect(map, { Torben = 1000, Lina = 5000 })
			local c = collect(map, { Grimbar = 99000 })
			local got = a .. " / " .. b .. " / " .. c
			return a == b and b == c, Clean(got), "dreimal dieselbe Reihenfolge"
		end)
	end)
	-- TS-S3b: Formel nur als Messung (Entwicklermodus, Bedrohung lesbar): Platz 1 / ganze Reihenfolge gegen die echte Bedrohung
	C("T-S3b", "J", "Messung Stufe 3 (TS-S3b): nur im Entwicklermodus, nur mit lesbarer Bedrohung, zählt je Kampf Platz 1 und ganze Reihenfolge", function()
		local sc = MeterScene({ player = { true, 3, 100, 100, 1000 }, party1 = { false, 0, 80, 80, 800 },
			party2 = { false, 0, 60, 60, 600 } }, "player")
		local M = ns.Meter
		local saveMess = ThreatSentinelDB.s3mess
		local ok, res = pcall(Scene.Run, sc, function()
			ns.simAccess = "open"
			local est
			Swap(M, "Estimates", function() if est then return est, {} end end)
			Swap(M, "ThreatFactor", function() return 1 end)
			local out = {}
			local function fight(dev, e)
				Swap(ns, "IsDev", function() return dev end)
				est = e
				M.s3last, M.s3t = nil, nil
				WithAPI({ UnitAffectingCombat = Ret(true) }, function() return M:Collect() end)
				local last = M.s3last
				M:S3FightEnd()
				out[#out + 1] = last and (S(last.top1) .. "/" .. S(last.full)) or "-"
			end
			ThreatSentinelDB.s3mess = nil
			-- Formel gleich wie echt: player 1000 > party1 800 > party2 600
			local names = {}
			for _, u in ipairs({ "player", "party1", "party2" }) do names[u] = ns:FullName(u) end
			fight(true, { [names.player] = 1000, [names.party1] = 800, [names.party2] = 600 })
			-- Platz 1 richtig, Rest vertauscht
			fight(true, { [names.player] = 1000, [names.party1] = 500, [names.party2] = 700 })
			-- Platz 1 falsch
			fight(true, { [names.player] = 100, [names.party1] = 800, [names.party2] = 600 })
			-- Gegenprobe: ohne Entwicklermodus keine Messung
			fight(false, { [names.player] = 1000, [names.party1] = 800, [names.party2] = 600 })
			local m = ThreatSentinelDB.s3mess or {}
			return table.concat(out, " ") .. string.format(" | Kämpfe %d, Platz 1 %d, ganz %d", m.fights or 0, m.top1 or 0, m.full or 0)
		end)
		UnswapAll()
		ThreatSentinelDB.s3mess = saveMess
		M.s3last, M.s3t = nil, nil
		if not ok then return false, Clean(res), "kein Fehler" end
		local want = "true/true true/false false/false - | Kämpfe 3, Platz 1 2, ganz 1"
		return res == want, res, want
	end)
	C("T-A5", "J", "Lesbare Werte (Era/TBC, Modus VOLL): Reihenfolge wie 2.5.0", function()
		local sc = MeterScene({ player = { true, 3, 100, 100, 1000 }, party1 = { false, 0, 40, 40, 400 },
			party2 = { false, 0, 80, 80, 800 }, party3 = { false, 0, 60, 60, 600 } }, "player")
		return Scene.Run(sc, function()
			ns.simAccess = "open"
			local list, secret = ns.Meter:Collect()
			local names = {}
			for i, e in ipairs(list) do names[i] = tostring(e.name) end
			local got = table.concat(names, ",") .. " " .. S(secret) .. " " .. S(ns.Meter.orderKind)
			local want = "Anna,Lina,Grimbar,Torben false nil"
			return got == want, got, want .. " (Aggro zuerst, dann Anteil; kein Hinweis)"
		end)
	end)
	C("T-A6", "J", "ANZEIGE: Ziel des Mobs geschützt -> Stufe 1 übersprungen, Protokoll 'nein'", function()
		local sc = MeterScene({ party1 = { false, 3, 100, 100, 1000 }, player = { false, 2, 90, 90, 900 },
			party2 = { false, 1, 50, 50, 500 }, party3 = { false, 0, 20, 20, 200 } }, "player")
		return MeterRun(sc, function(collect, scene)
			local before = ns.errorCount
			local logged = {}
			Swap(ns, "Diag", function(kind, text) logged[#logged + 1] = tostring(kind) .. " " .. tostring(text) end)
			ns.Meter.measured = false
			local order, kind = collect({ UnitIsUnit = function(a, b) if a == "targettarget" then return SECRET end return scene.UnitIsUnit(a, b) end,
				UnitDetailedThreatSituation = function(u, m) local r = { scene.UnitDetailedThreatSituation(u, m) }; r[1] = SECRET; return unpack(r, 1, 5) end })
			local line = logged[1] or ""
			local got = order .. " " .. S(kind) .. " | " .. line .. " | Fehler +" .. (ns.errorCount - before)
			local good = order == "Torben,Anna,Lina,Grimbar" and kind == "sure" and line:find("Ziel-des-Mobs=nein", 1, true) ~= nil
				and ns.errorCount == before
			return good, got, "nach Stufe: Torben,Anna,Lina,Grimbar sure | LESBAR Ziel-des-Mobs=nein … | Fehler +0"
		end)
	end)
	C("T168", "J", "Kein Vorsprung-Text im Modus ANZEIGE", function()
		local M = ns.Meter
		if not M.f then return false, "kein Aggrometer", "Rahmen" end
		local shown = M.f:IsShown()
		local saveSim = ns.simAccess
		ns.simAccess = "secret"
		M:Render({ { name = "Torben", class = "WARRIOR", pull = 100, tanking = true, isTank = true, status = 2, me = true },
			{ name = "Anna", class = "PRIEST", pull = 50 } }, "Test", true)
		local lead = M.f.lead:GetText()
		local r, g, b = M.f.rows[1]:GetStatusBarColor()
		r, g, b = Num(r), Num(g), Num(b)
		ns.simAccess = saveSim
		if not shown then M.f:Hide() end
		local neutral = Near(r, 0.45, 0.02) and Near(g, 0.6, 0.02) and Near(b, 0.85, 0.02)
		return (lead == nil or lead == "") and neutral, "Vorsprung '" .. S(lead) .. "', Farbe " .. string.format("%.2f,%.2f,%.2f", r, g, b), "leer, neutral"
	end)
	C("T169", "J", "Neutrale Balkenfarbe der DD-Ansicht im Modus ANZEIGE (Stufe und Aggro geschützt)", function()
		local D = ns.DD
		if not D.f then return false, "keine DD-Ansicht", "Rahmen" end
		local shown = D.f:IsShown()
		local saveSim = ns.simAccess
		ns.simAccess = "secret"
		-- seit 2.5.5 warnt eine LESBARE Stufe/Aggro (T-Q4); neutral bleibt es, wenn beides geschützt ist
		WithAPI({}, function() D:ShowSecret(80, SECRET, SECRET) end)
		local r, g, b = D.f.bar:GetStatusBarColor()
		r, g, b = Num(r), Num(g), Num(b)
		ns.simAccess = saveSim
		if not shown then D.f:Hide() end
		return Near(r, 0.45, 0.02) and Near(g, 0.6, 0.02) and Near(b, 0.85, 0.02), string.format("%.2f,%.2f,%.2f", r, g, b), "0.45,0.60,0.85"
	end)
	C("T170", "J", "Blizzard-Anzeigen bei 'immer nur Anzeige' (mitgeschrieben)", function()
		if not ns.isModern then return true, "alte API (nur F R)" end
		local before = ns.actLog.n.cvar or 0
		ns.threatAccess, ns.simAccess = "open", nil
		ns.db.enabled, ns.db.blizzThreat, ns.db.threatMode = true, true, "DISPLAY"
		ns.db.blizzOrig = nil
		ns:ApplySettings()
		local n = (ns.actLog.n.cvar or 0) - before
		local note = rawget(ns.LOCALES.enUS, "O_BLIZZTHREAT_NOTE") and rawget(ns.LOCALES.deDE, "O_BLIZZTHREAT_NOTE")
		-- n == 0 ist richtig, wenn die CVars schon auf dem Zielwert stehen
		return note and true or false, "CVar " .. n .. "x mitgeschrieben", "Hinweistext en/de"
	end)
	C("T171", "J", "Knopf 'Client simulieren: Forever / echt'", function()
		local TM = ns.Test
		if not TM.frame then TM:Build() end
		if not TM.clientBtn then return false, "Knopf fehlt", "vorhanden" end
		local m1, m2
		Capture(function()
			TM:SetClientSim(true); m1 = ns.isModern
			TM:SetClientSim(false); m2 = ns.isModern
		end)
		return m1 == true and m2 == (GoldSentinelGame.IsModern and true or false), S(m1) .. "/" .. S(m2), "true/echt"
	end)
	C("T172", "J", "Ausgeschaltetes Addon meldet nichts", function()
		local shown = 0
		Swap(ns.Alerts, "Center", function() shown = shown + 1 end)
		ns.db.enabled = false
		TA.announced = false
		TA:Set("secret")
		UnswapAll()
		ns.db.enabled = true
		return shown == 0, shown .. "x", "kein Hinweis"
	end)
	C("T173", "J", "Simulation 'open' übersteuert keine echte Sperre", function()
		local save = { ns.threatAccess, ns.simAccess }
		ns.threatAccess, ns.simAccess = "secret", "open"
		local m = ns:ThreatMode()
		ns.threatAccess, ns.simAccess = save[1], save[2]
		return m == "DISPLAY", m, "DISPLAY"
	end)
	CL("T174", "J", "UnitIsUnit nur über ns:SameUnit", "Forever, Gruppe im Kampf: kein Lua-Fehler (Testzentrale-Diagnose 'Fehler: 0')")
	C("T175", "J", "Log.lua und Specs.lua nutzen ns.IsSecret", function()
		ns.testBait = SECRET
		local v = ns.Log.Val(SECRET)
		ns.testBait = nil
		return v == "SECRET", S(v), "SECRET"
	end)
	C("T176", "J", "TBC Anniversary / Classic Era – Kampflog und Meter aktiv", function()
		if ns.isModern then return true, "moderne API: Kampflog aus (richtig)" end
		local A = ns.Alerts
		return A.cleuAllowed == true and A.cleuRegistered == true and ns.DmgMeter.allowed == true and #ns.blocked == 0,
			string.format("%s/%s/%s blocked=%d", S(A.cleuAllowed), S(A.cleuRegistered), S(ns.DmgMeter.allowed), #ns.blocked), "true/true/true blocked=0"
	end)
	CL("T176b", "J", "Alter Client: Kampf in der Gruppe", "Classic Era und TBC Anniversary: Schadens-/Heilmeter zählt, widerstandener Spott wird gemeldet, kein 'Addon geblockt' – Ergebnis dem Nutzer melden")
	CL("T177", "J", "Launch-Tag: Interface-Nummer und erster Kampf", "/dump select(4, GetBuildInfo()); im ersten Kampf /ts bedrohung -> Modus im Bericht")
	K("T178", "J", "Lua-Syntaxprüfung", "vor dem Push mit addon_check.py (manuell)")
end

------------------------------------------------------------
-- K. Oberfläche im echten Client (UICheck.lua, anweisung-testroutine-oberflaeche.txt)
-- Nur lesen, nichts verändern. Ohne echten Client (Rechtecke, Tooltip) ehrlich übersprungen, nie als OK gezählt.
------------------------------------------------------------
Area.K = function()
	local U = ns.UICheck
	if not U then
		K("T180", "K", "Oberfläche im Client", "UICheck.lua fehlt")
		return
	end
	-- Testzentrale und Einstellungen öffnen, damit es etwas zu prüfen gibt (R:Finish schliesst sie wieder)
	if ns.Test and ns.Test.frame then
		ns.Test.frame:Show()
		if ns.UIAvoidBlizzard then ns.UIAvoidBlizzard(ns.Test.frame) end
	end
	local function List(problems) return #problems == 0 and "keine" or Clean(table.concat(problems, "; ")) end
	local cases = {
		{ "T180", "Eigene Tooltips verdecken keine Knöpfe", U.TooltipsCoverNothing },
		{ "T181", "Kein Überlappen mit Blizzard- oder GoldSentinel-Fenstern", U.WindowsOverlapNothing },
		{ "T182", "Fenster ganz im Bildschirm", U.InsideScreen },
		{ "T183", "Beschriftungen von Knöpfen nicht abgeschnitten", U.TextFits },
		{ "T184", "Angezeigte Spielwerte plausibel", U.ValuesPlausible, true },
		{ "T185", "Keine Fehlerschleife (gleiche Meldung > 10×)", U.NoErrorLoops, true },
	}
	for _, c in ipairs(cases) do
		if not c[4] and not U.Available() then
			K(c[1], "K", c[2], "nur im echten Client (Fenster, Rechtecke, Tooltip)")
		else
			C(c[1], "K", c[2], function()
				local problems, tested, hints = c[3]()
				local info = List(problems) .. " · geprüft " .. tostring(tested)
					.. (hints and #hints > 0 and (" · Hinweise: " .. Clean(table.concat(hints, "; "))) or "")
				return #problems == 0, info, "keine"
			end)
		end
	end
	-- L1/L2/L6/L8 (Entscheid 20.11. 13:44): alle sichtbaren eigenen Texte, dazu Aggrometer, Schadensmesser und DD-Ansicht mit
	-- Beispielwerten (danach wieder wie vorher)
	if U.Available() and U.Readable then
		C("T187", "K", "Lesbarkeit: Kontrast, keine grauen Zahlen, Geldbeträge rechtsbündig, Klammerzahlen beschriftet, Schriftgrösse (L1/L2/L6/L8)", function()
			local was = {}
			for _, k in ipairs({ "Meter", "DmgMeter", "DD" }) do
				local m = ns[k]
				if m and m.f then was[k] = m.f:IsShown() and true or false end
			end
			local ok, err = pcall(function()
				if ns.Meter.f then
					ns.Meter:Render({ { name = ns.playerName or "Du", class = ns.class, pull = 100, tanking = true, me = true },
						{ name = "Torben", class = "ROGUE", pull = 72.5 }, { name = "Anna", class = "PRIEST", pull = 41 } }, L.TEST_TARGET)
				end
				if ns.DmgMeter.f then ns.DmgMeter:Render("dmg", { { "Torben", 42100 }, { "Anna", 4200 } }, 60, L.DM_FIGHT) end
				if ns.DD.f then ns.DD:Show(72.5, false) end
			end)
			local problems, tested = {}, 0
			if ok then problems, tested = U.Readable() end
			for k, shown in pairs(was) do if not shown then ns[k].f:Hide() end end
			if not ok then error(err, 0) end
			return #problems == 0, (#problems == 0 and "keine" or Clean(table.concat(problems, "; "))) .. " · geprüft " .. tostring(tested), "keine"
		end)
	else
		K("T187", "K", "Lesbarkeit L1/L2/L6/L8 an den sichtbaren Fenstern", "nur im echten Client (Schriftfarben, Schriftgrössen, Hintergründe)")
	end
	if U.Available() and ns.Meter.f then
		C("T-A7", "K", "Aggrometer: Kopfzeile 'Reihenfolge' nicht abgeschnitten (auch bei kleinster Breite)", function()
			local M, f = ns.Meter, ns.Meter.f
			local was, w = f:IsShown(), f:GetWidth()
			local bad = {}
			for _, width in ipairs({ 160, w }) do
				f:SetWidth(width)
				for _, key in ipairs({ "METER_ORDER_SURE", "METER_ORDER_ROLE" }) do
					f.order:SetText(L[key])
					local sw, fw = f.order:GetStringWidth() or 0, f.order:GetWidth() or 0
					if sw > fw + 0.5 then bad[#bad + 1] = string.format("%s bei %d: %.0f > %.0f", key, width, sw, fw) end
				end
			end
			f.order:SetText("")
			f:SetWidth(w)
			M:ApplySettings()
			if not was then f:Hide() end
			return #bad == 0, #bad == 0 and "passt" or table.concat(bad, "; "), "passt bei 160 und eingestellter Breite"
		end)
	else
		K("T-A7", "K", "Aggrometer: Kopfzeile 'Reihenfolge' nicht abgeschnitten", "nur im echten Client (Textbreite)")
	end
	if U.Available() and ns.Test.frame then
		-- Befund 18.11. 08:26: das alte Testfenster (200×120 mitten auf der Testzentrale 765×440, Bildschirm 1461×767) liess
		-- nachgerechnet KEINEN freien Platz – die Prüfung baute sich ihr Hindernis selbst. Jetzt: Testzentrale oben links,
		-- kleines Testfenster (R.K2_FAKE_W × R.K2_FAKE_H) über ihrer Ecke; frei ist dann z. B. rechts daneben (ab Breite des
		-- Testfensters). Abgeschirmt: nur das Testfenster zählt (andere offene Fenster prüfen T181/T186). OK oder FEHLER, kein SKIP.
		local function Measure()
			local tf = ns.Test.frame
			local was = tf:IsShown()
			local pts = {}
			for i = 1, tf:GetNumPoints() do pts[i] = { tf:GetPoint(i) } end
			tf:Show()
			tf:ClearAllPoints(); tf:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 0, 0)
			R.fakeOther = R.fakeOther or CreateFrame("Frame", nil, UIParent)
			local o = R.fakeOther
			if not o.tex then o.tex = o:CreateTexture(nil, "BACKGROUND"); o.tex:SetAllPoints(); o.tex:SetColorTexture(0, 0, 0, 0.5) end
			o:ClearAllPoints(); o:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 0, 0); o:SetSize(R.K2_FAKE_W, R.K2_FAKE_H); o:Show()
			local entry = { frame = o, name = "TS-Testfenster", addon = "TSFremdTest" }
			local saveBlizz, saveGS = ns.UI_BLIZZARD, rawget(_G, "GoldSentinelUIFrames")
			ns.UI_BLIZZARD = {}
			rawset(_G, "GoldSentinelUIFrames", { entry })
			local before = U.Overlap(U.Rect(tf), U.Rect(o))
			local ok, moved = pcall(ns.UIAvoidOthers, tf)
			local left = U.Overlap(U.Rect(tf), U.Rect(o))
			local last = ns.UIAvoidLast or {}
			ns.UI_BLIZZARD = saveBlizz
			rawset(_G, "GoldSentinelUIFrames", saveGS)
			o:Hide()
			tf:ClearAllPoints()
			for _, pt in ipairs(pts) do tf:SetPoint(unpack(pt)) end
			if not was then tf:Hide() end
			return ok, moved, left, last, before
		end
		local okM, ok, moved, left, last, before = pcall(Measure)
		C("T-K2", "K", "Testzentrale weicht sichtbaren Fenstern anderer GoldSentinel-Addons aus", function()
			if not okM then return false, Clean(ok), "kein Fehler" end
			if not ok then return false, Clean(moved), "kein Fehler" end
			last = last or {}
			return (before or 0) > 0 and moved == true and left == 0 and last.covered == 0,
				"vorher überdeckt " .. tostring(before) .. ", verschoben " .. S(moved) .. ", Überdeckung " .. tostring(left) .. ", Rest " .. tostring(last.covered)
					.. (last.by and #last.by > 0 and (" durch " .. table.concat(last.by, ", ")) or "")
					.. " · Bildschirm " .. tostring(last.screen) .. ", Testzentrale " .. tostring(last.size),
				"vorher überdeckt > 0, verschoben true, Überdeckung 0, Rest 0"
		end)
	else
		K("T-K2", "K", "Testzentrale weicht Fenstern anderer GoldSentinel-Addons aus", "nur im echten Client (Rechtecke)")
	end
	C("T-K2b", "K", "Ausweichen mit zwei Hindernissen: freie Lage gefunden (vorher Pendeln rechts/links)", function()
		local U = ns.UICheck
		local A = { l = 300, r = 500, b = 350, t = 550 }   -- z. B. ein Fenster links
		local B = { l = 480, r = 900, b = 300, t = 600 }   -- ein zweites rechts daneben
		local list = { A, B }
		local best, cover = U.BestPlace(350, 500, 300, 200, 1000, 800, list)
		-- Gegenprobe: alte Regel (nur neben dem ersten getroffenen Hindernis, höchstens 4 Versuche)
		local function cov(x) local c = 0; for _, r in ipairs(list) do c = c + U.Overlap({ l = x, r = x + 300, t = 500, b = 300 }, r) end; return c end
		local function first(x) for _, r in ipairs(list) do if U.Overlap({ l = x, r = x + 300, t = 500, b = 300 }, r) > 0 then return r end end end
		local x, oldBest = 350, cov(350)
		local hit = first(x)
		for _ = 1, 4 do
			if not hit then break end
			x = (hit.r + 8 + 300 <= 1000) and (hit.r + 8) or math.max(0, hit.l - 8 - 300)
			oldBest = math.min(oldBest, cov(x))
			hit = first(x)
		end
		local got = string.format("neu: Lage %d/%d, Überdeckung %d · alt: Überdeckung %d", best.l, best.t, cover, oldBest)
		local want = "neu: Lage 0/500, Überdeckung 0 · alt: Überdeckung " .. oldBest
		return got == want and oldBest > 0, got, "neu: Lage 0/500, Überdeckung 0 · alt: Überdeckung > 0"
	end)
	C("T-K2d", "K", "Ausweichen vollständig: bündige Lücke wird gefunden, voller Bildschirm wird als 'kein Platz' erkannt", function()
		local U = ns.UICheck
		local A = { l = 0, r = 350, b = 0, t = 800, name = "A" }
		local B = { l = 650, r = 1000, b = 0, t = 800, name = "B" }   -- Lücke genau 300 breit (= Fensterbreite)
		local best, cover = U.BestPlace(500, 500, 300, 200, 1000, 800, { A, B })
		local full = { l = 0, r = 1000, b = 0, t = 800, name = "Voll" }
		local _, cover2 = U.BestPlace(500, 500, 300, 200, 1000, 800, { full })
		local by = U.CoveredBy({ l = 100, r = 400, t = 500, b = 300 }, { A, B })
		-- Lage der Prüfung T-K2/T-D2 mit den Massen aus dem Ingametest 18.11. (Bildschirm 1461×767, Testzentrale 765×440):
		-- Testfenster R.K2_FAKE_W×R.K2_FAKE_H oben links -> es gibt einen freien Platz (rechts daneben)
		local fk = { l = 0, r = R.K2_FAKE_W, t = 767, b = 767 - R.K2_FAKE_H, name = "TS-Testfenster" }
		local b3, c3 = U.BestPlace(0, 767, 765, 440, 1461, 767, { fk })
		-- Gegenprobe alte Lage (200×120 mitten auf der Testzentrale, Testzentrale in Bildschirmmitte): beweisbar kein Platz
		local old = { l = 630, r = 830, t = 443, b = 323, name = "alt" }
		local _, c4 = U.BestPlace(348, 603, 765, 440, 1461, 767, { old })
		local got = string.format("Lücke: Lage %d, Überdeckung %d · voll: Überdeckung %s · Namen %s · T-K2 neu: Lage %d, Überdeckung %d · alt: Überdeckung %s",
			best.l, cover, S(cover2 > 0), table.concat(by, ","), b3.l, c3, S(c4 > 0))
		local want = "Lücke: Lage 350, Überdeckung 0 · voll: Überdeckung true · Namen A 49551 · T-K2 neu: Lage 128, Überdeckung 0 · alt: Überdeckung true"   -- (350−100−1)×(500−300−1)
		return got == want, got, want
	end)
	C("T-K2c", "K", "HUD-Anzeigen anderer Addons (LevelPilot-Pfeil) zählen nicht als Fenster (Entscheid 17.11.)", function()
		local U = ns.UICheck
		local named = { GetName = function() return "LevelPilotArrow" end }
		local r = {
			S(U.ForeignHUD({ addon = "LevelPilot", name = "Pfeil", frame = {} })),
			S(U.ForeignHUD({ addon = "LevelPilot", name = "x", frame = named })),
			S(U.ForeignHUD({ addon = "LevelPilot", name = "Guide", frame = {} })),
			S(U.ForeignHUD({ addon = "BuffSentinel", name = "Pfeil", frame = {} })),
		}
		local got = table.concat(r, " ")
		return got == "true true false false", got, "true true false false (Pfeil, LevelPilotArrow ja; Guide, fremder 'Pfeil' nein)"
	end)
	-- TR-ALLE Nachtrag D: nie auf den Nutzer warten. Ist schon ein Spielfenster offen, gleich prüfen; sonst vormerken – die
	-- Prüfung läuft von selbst, wenn der Nutzer beim normalen Spielen ein Spielfenster öffnet (R:CatchUpWindows, höchstens 7 Tage).
	if not U.Available() then
		CL("T186", "K", "Oberfläche mit offenen Blizzard-Fenstern", "nur im echten Spiel (Fenster, Rechtecke)")
	elseif R.BlizzardOpen() then
		C("T186", "K", "Oberfläche mit offenen Blizzard-Fenstern (" .. tostring(R.BlizzardOpen()) .. ")", function()
			local problems, tested = U.WindowsOverlapNothing()
			return #problems == 0 and tested > 0, List(problems) .. " · geprüft " .. tostring(tested), "keine, geprüft > 0"
		end)
	else
		R.waitWindow = true
		K("T186", "K", "Oberfläche mit offenen Blizzard-Fenstern", L.TR_WAIT_WIN)
	end
end

-- alle Globals durchgehen, in Portionen (Abgabe über MaybeYield zwischen den Einträgen, nie im pcall).
-- next() wird einzeln geschützt aufgerufen: verschwindet zwischen zwei Bildern genau der gemerkte Schlüssel (anderes Addon
-- löscht ein Global), beginnt der Durchgang neu (höchstens R.SCAN_RESTARTS Mal) -> false, wenn es nie vollständig gelang.
R.SCAN_RESTARTS = 3
R.SCAN_STEP = 200
function R:ScanGlobals(fn)
	local restarts = 0
	local seen = {}
	local k, n = nil, 0
	while true do
		local ok, nk, v = pcall(next, _G, k)
		if not ok then
			restarts = restarts + 1
			if restarts > R.SCAN_RESTARTS then return false end
			k = nil
		else
			if nk == nil then return true end
			if not seen[nk] then seen[nk] = true; fn(nk, v) end
			k = nk
			n = n + 1
			if n % R.SCAN_STEP == 0 then MaybeYield() end
		end
	end
end

-- erstes sichtbares Spielfenster aus ns.UI_BLIZZARD (Name) oder nil
function R.BlizzardOpen()
	for _, bn in ipairs(ns.UI_BLIZZARD or {}) do
		local bf = _G[bn]
		if bf and bf.IsVisible and bf:IsVisible() then return bn end
	end
	return nil
end

------------------------------------------------------------
-- TR-ALLE Nachtrag D: vorgemerkte Fenster-Prüfung automatisch nachholen (nur Entwicklermodus, nie im Kampf, höchstens 7 Tage)
------------------------------------------------------------
R.PENDING_DAYS = 7
R.hooked = {}
function R:InstallCatchUp()
	for _, bn in ipairs(ns.UI_BLIZZARD or {}) do
		local bf = _G[bn]
		if bf and bf.HookScript and not self.hooked[bn] then
			self.hooked[bn] = true
			bf:HookScript("OnShow", function() R:CatchUpWindows(bn) end)
		end
	end
end

function R:PendingWindow()
	local p = ThreatSentinelDB and ThreatSentinelDB.trPending
	if type(p) ~= "table" then return nil end
	if (time() - (tonumber(p.t) or 0)) > self.PENDING_DAYS * 86400 then
		ThreatSentinelDB.trPending = nil
		self:Say(L.TR_PENDING_EXPIRED)
		return nil
	end
	return p
end

function R:CatchUpWindows(bn)
	if self.running or self.catching or not ns:IsDev() or InCombat() then return end
	if not self:PendingWindow() then return end
	self.catching = true
	-- kurz warten, bis das Spielfenster fertig aufgebaut ist (nicht im OnShow des Spielfensters selbst arbeiten)
	C_Timer.After(0.5, function()
		self.catching = false
		local ok, err = pcall(self.DoCatchUp, self, bn)
		if not ok then ns:ReportError(err) end
	end)
end

-- eigene Fenster unsichtbar (Alpha 0) öffnen, ausweichen lassen, Überlappung messen, alles zurückstellen
function R:DoCatchUp(bn, test)
	local p = self:PendingWindow()
	local bf = _G[bn]
	if not p or (self.running and not test) or InCombat() or not (bf and bf.IsVisible and bf:IsVisible()) then return end
	local U = ns.UICheck
	if not (U and U.Available and U.Available()) then return end
	if ns.Test and not ns.Test.frame and ns.Test.Build then ns.Test:Build() end
	if ns.Options and not ns.Options.frame and ns.Options.Build then ns.Options:Build() end
	local saved = {}
	for _, f in ipairs({ ns.Test and ns.Test.frame, ns.Options and ns.Options.frame }) do
		if f then
			local pts = {}
			for i = 1, (f.GetNumPoints and f:GetNumPoints() or 0) do pts[i] = { f:GetPoint(i) } end
			saved[#saved + 1] = { f = f, shown = f:IsShown(), alpha = f:GetAlpha(), pts = pts }
			f:SetAlpha(0)
			f:Show()
			if ns.UIAvoidBlizzard then ns.UIAvoidBlizzard(f) end
		end
	end
	local okW, problems, tested = pcall(U.WindowsOverlapNothing)
	for _, sv in ipairs(saved) do
		local f = sv.f
		f:ClearAllPoints()
		for _, pt in ipairs(sv.pts) do f:SetPoint(unpack(pt)) end
		f:SetAlpha(sv.alpha)
		if not sv.shown then f:Hide() end
	end
	if not okW then problems, tested = { Clean(problems) }, 0 end
	local passed = #problems == 0 and (tested or 0) > 0
	-- eigener kleiner Bericht mit Verweis auf den Lauf
	local run = GoldSentinelTest and GoldSentinelTest.Begin and GoldSentinelTest.Begin("ThreatSentinel", ns.version, ThreatSentinelDB)
	if run then
		run:Check("T186", "K", "Oberfläche mit offenen Blizzard-Fenstern (nachgeholt bei " .. bn .. ")", function()
			return passed, (#problems == 0 and "keine" or Clean(table.concat(problems, "; "))) .. " · geprüft " .. tostring(tested), "keine, geprüft > 0"
		end)
		run:Finish({ nachgeholt = "T186", lauf = tostring(p.ref or "?"), fenster = bn })
	end
	ThreatSentinelDB.trPending = nil
	self:Say(string.format(L.TR_CATCHUP, bn, passed and L.TR_CATCHUP_OK or L.TR_CATCHUP_ERR))
	if passed and not test then ns:PLRefresh("TR-ALLE", "Fenster-Prüfung nachgeholt (" .. bn .. ")") end
	return passed
end

ns:On("PLAYER_LOGIN", function()
	if ns:IsDev() and ThreatSentinelDB and type(ThreatSentinelDB.trPending) == "table" then R:InstallCatchUp() end
end)
-- Spielfenster, die erst bei Bedarf geladen werden (Auktionshaus, Berufe): danach ebenfalls einhaken
ns:On("ADDON_LOADED", function()
	if next(R.hooked) and ThreatSentinelDB and type(ThreatSentinelDB.trPending) == "table" then R:InstallCatchUp() end
end)

------------------------------------------------------------
-- Ablauf
------------------------------------------------------------
function R:Say(msg) ns:Print("|cffffd100[Testroutine]|r " .. tostring(msg)) end

-- Ende eines Bereichs: Stubs zurücksetzen und prüfen, Sandbox zurück
local function EndArea(letter)
	-- Stubs immer am Ende des Bereichs zurücksetzen und prüfen
	local open = #swaps
	UnswapAll()
	RUN:Check("S" .. letter, letter, "Stubs zurückgesetzt", function() return open == 0, open, 0 end)
	-- Sandbox zurück (Tickers sehen zwischen den Bereichen die echten Daten)
	ns.routineRunning = false
	R:RestoreSandbox()
	ns.routineRunning = true
end

-- Ein Bereich darf eine Fortsetzung zurückgeben (TU4: Portionen, je Bild eine): dann läuft sie in den nächsten
-- Bildern weiter (true = noch nicht fertig), erst danach wird der Bereich abgeschlossen.
-- Den Bereich (bzw. seine Fortsetzung) ein Stück weiterlaufen lassen: in einer Coroutine, die nach jeder Prüfung abgibt,
-- sobald R.FRAME_MS in diesem Bild verbraucht sind. Rückgabe: "weiter" (nächstes Bild), "fortsetzung" (Bereich lieferte eine
-- Fortsetzungs-Funktion), "fertig" oder "fehler".
local function Resume(co, letter, what)
	R.curLetter = letter
	R.co, R.noYield = co, 0
	R.frameStart = R.stepStart or R.Now()   -- Budget zählt ab Beginn des Bildes (step), nicht erst ab hier
	R.inArea = true
	local ok, res = coroutine.resume(co)
	R.inArea = false
	R.co = nil
	if not ok then
		RUN:Check("X" .. letter, letter, "Bereich " .. letter .. " abgebrochen" .. (what or ""), function() error(res, 0) end)
		return "fehler"
	end
	if coroutine.status(co) == "suspended" then return "weiter" end
	return (type(res) == "function") and "fortsetzung" or "fertig", res
end

local function RunArea(letter)
	local fn = Area[letter]
	if not fn then return end
	R.areaNr = (R.areaNr or 0) + 1
	if R.alles then R:Say(string.format(L.TR_PROGRESS, letter, R.areaNr, R.areaTotal or 0)) end
	local co = coroutine.create(function()
		if not R.globalsBefore then
			local before = {}
			local okScan = R:ScanGlobals(function(k) before[k] = true end)
			R.globalsBefore = okScan and before or false
		end
		return fn()
	end)
	local st, res = Resume(co, letter)
	if st == "weiter" then R.cont = { letter = letter, co = co } return end
	if st == "fortsetzung" then R.cont = { letter = letter, fn = res } return end
	EndArea(letter)
end

-- nächstes Stück; false = fertig (Bereich abgeschlossen)
local function RunCont()
	local c = R.cont
	if c.co then
		local st, res = Resume(c.co, c.letter)
		if st == "weiter" then return true end
		c.co = nil
		if st == "fortsetzung" then c.fn = res return true end
		if st == "fertig" and res == true and c.fn then return true end   -- Fortsetzung will noch einmal
	elseif c.fn then
		-- Fortsetzung (TU4-Portionen): je Aufruf ein Stück, ebenfalls in einer Coroutine (C darf abgeben)
		local fn = c.fn
		c.co = coroutine.create(function() return fn() end)
		local st, res = Resume(c.co, c.letter, " (Fortsetzung)")
		if st == "weiter" then return true end
		c.co = nil
		if st == "fertig" and res == true then return true end      -- Fortsetzung will noch einmal
		if st == "fortsetzung" then c.fn = res return true end
	end
	R.cont = nil
	EndArea(c.letter)
	return false
end

-- Befund 18.11. 08:26 (Prüfliste zeigte weiter den Lauf vom 17.11.): Ursache im Bericht 08:26 belegt – T186 wartete auf ein
-- Spielfenster, darum wurde TR-ALLE in 2.5.20 gar nicht erneuert. Jetzt immer der neueste Lauf; wartet die Fenster-Prüfung,
-- steht das in der Notiz (das Nachholen erneuert den Punkt danach noch einmal).
function R:PLRunResult(nOk, nErr, wait)
	local note = string.format("%d/%d OK, %d Fehler · %s", nOk, nOk + nErr, nErr, tostring(ns.flavor or "?"))
	if wait then note = note .. " · " .. L.TR_PL_WAIT end
	local a = ns:PLRefresh("TR-ALLE", note)
	if ns.flavor == "era" or ns.flavor == "tbc" then ns:PLRefresh("ERA-TBC", note) end
	return a, note
end

-- Testort und Lag (Hinweis 18.11. 19:30, E-Regel pruef-ablauf.md): ganzes Bild = Zeit von einem Schritt der Routine zum
-- nächsten (ein Bild, C_Timer.After(0)). Enthält die eigene Portion des Bildes davor und alles, was Spiel und Umgebung
-- (andere Addons, Server-Lag, viele Spieler) in diesem Bild brauchen. Nur Auskunft: bewertet wird die EIGENE Portion.
R.WHOLE_LIMIT = 40
function R:WholeFrame(now)
	if self.lastStepAt and self.wholeN then
		local whole = now - self.lastStepAt
		local own = self.lastPortion or 0
		self.wholeN = self.wholeN + 1
		if whole > (self.wholeMax or 0) then self.wholeMax, self.wholeMaxOwn = whole, own end
		if whole > R.WHOLE_LIMIT then
			self.wholeOver = (self.wholeOver or 0) + 1
			if own <= R.STEP_LIMIT then self.wholeEnv = (self.wholeEnv or 0) + 1 end
		end
	end
	self.lastStepAt = now
end

-- Ort (Zone/Unterzone), Namensplaketten in Sicht (davon Spieler) und Ping beim Start – für den Bericht
function R.EnvLine()
	local function call(name, ...)
		local f = rawget(_G, name)
		if type(f) ~= "function" then return nil end
		local ok, a, b, c, d = pcall(f, ...)
		if ok then return a, b, c, d end
	end
	local function txt(v) if v == nil or (ns.IsSecret and ns.IsSecret(v)) or v == "" then return "-" end return tostring(v) end
	local zone = call("GetRealZoneText") or call("GetZoneText")
	local sub = call("GetSubZoneText")
	local plates, players = "-", "-"
	local NP = rawget(_G, "C_NamePlate")
	if type(NP) == "table" and type(NP.GetNamePlates) == "function" then
		local ok, list = pcall(NP.GetNamePlates)
		if ok and type(list) == "table" then
			local n, p = 0, 0
			for _, plate in ipairs(list) do
				n = n + 1
				local unit = plate.namePlateUnitToken or (plate.UnitFrame and plate.UnitFrame.unit)
				local isP = unit and call("UnitIsPlayer", unit)
				if isP == true then p = p + 1 end
			end
			plates, players = tostring(n), tostring(p)
		end
	end
	local _, _, home, world = call("GetNetStats")
	return string.format(L.TR_ENV, txt(zone), txt(sub), plates, players, txt(home), txt(world))
end

-- Ende eines Bildes (step) bzw. Abschluss: Dauer der Portion messen (seit R.stepStart)
function R:PortionDone(at)
	if not self.stepStart then return end
	local d = R.Now() - self.stepStart
	self.stepStart = nil
	if not self.portions then return end
	self.portions = self.portions + 1
	if d > (self.portionMax or 0) then self.portionMax, self.portionMaxAt = d, at or self.lastCheckId end
	if d > R.FRAME_LIMIT then self.portionsOver = (self.portionsOver or 0) + 1 end
	self.lastPortion = d
	-- Gesamtdauer je Bereich (Summe seiner Bilder), getrennt vom längsten Bild (leistung.md Regel 8)
	local a = at == "Abschluss" and "Abschluss" or (self.curLetter or "?")
	self.areaMs = self.areaMs or {}
	local e = self.areaMs[a] or { ms = 0, frames = 0 }
	e.ms, e.frames = e.ms + d, e.frames + 1
	self.areaMs[a] = e
end

function R:Finish(stopped)
	ns.routineRunning = false
	ns.actLog = nil
	UnswapAll()
	if ns.API and ns.API.Load then ns.API.Load() end   -- ns.API-Einträge sicher wieder wie im Spiel
	self:RestoreSandbox()
	-- alles schliessen, was die Routine geöffnet hat
	if ns.Test and ns.Test.frame and not self.testWasShown then ns.Test.frame:Hide() end
	if ns.Options and ns.Options.frame and not self.optWasShown then ns.Options.frame:Hide() end
	if ns.Alerts and ns.Alerts.ClearCenter then ns.Alerts:ClearCenter("test") end
	local sbOk, sbWhere = self:CheckSandbox()
	local cvOk, cvWhere = self:CheckCVars()
	local kOk, kWhere = self:CheckKeys()
	-- Livedaten (Entscheid 20.11. 08:39): gemeinsame gespeicherte Tabellen vor = nach, sonst FEHLER und zurücksetzen
	local liveBad, liveNotes = self:LiveCheck(self.sb and self.sb.live, true)
	self.liveText = (#liveBad == 0 and "OK" or ("FEHLER (" .. table.concat(liveBad, ", ") .. ")"))
		.. (#liveNotes > 0 and (" · " .. table.concat(liveNotes, "; ")) or "")
	C("T-LIVE", "U", "Test ändert keine Livedaten: Sync-Adressbuch, Marktspeicher, gemeinsame gs*-Tabellen vor = nach", function()
		local n = self.sb and self.sb.live and #self.sb.live.list or 0
		local got = (#liveBad == 0 and "unverändert" or ("geändert und zurückgesetzt: " .. table.concat(liveBad, ", ")))
			.. string.format(" · %d Tabellen", n) .. (#liveNotes > 0 and (" · " .. table.concat(liveNotes, "; ")) or "")
		return #liveBad == 0, Clean(got), "unverändert"
	end)
	-- Sprachtest (T128) erledigt (nach der Sandbox-Prüfung): Entwickler-Sprache löschen, ab dem nächsten /reload wieder die Spielsprache
	if self.clearDevLocale and ThreatSentinelDB then
		ThreatSentinelDB.devLocale = nil
		self.clearDevLocale = nil
		self:Say(L.TR_LOCALE_DONE)
	end
	local simText = R.SimResult(self.simBefore or {}, self:SimState())
	local real = self.realCalls
	local acts = {}
	for k, n in pairs(self.lastAct or {}) do acts[#acts + 1] = k .. "=" .. n end
	table.sort(acts)
	local function res(ok, where) return ok and "OK" or ("FEHLER (" .. tostring(where) .. ")") end
	local last = ThreatSentinelDB and ThreatSentinelDB.threatAccess
	local extra = {
		sandbox = res(sbOk, sbWhere), cvars = res(cvOk, cvWhere), tasten = res(kOk, kWhere),
		simulationen = simText, stubs = (#swaps == 0) and "OK" or "FEHLER",
		echte_aktionen = tostring(real), mitgeschrieben = table.concat(acts, " "),
		fehlerzaehler = tostring(ns.errorCount or 0), blockiert = tostring(#(ns.blocked or {})),
		bedrohung = string.format("%s / %s / gespeichert: %s", S(ns.threatAccess), ns:ThreatMode(),
			type(last) == "table" and (S(last.state) .. " " .. S(last.date) .. " " .. S(last.build)) or "-"),
		abgebrochen = stopped and tostring(stopped) or nil,
		nicht_automatisiert = tostring(self.notAuto or 0),
	}
	-- TU8: je Bereich TU1–TU7 eine Zeile, dazu Regressionen und Standardwerte (TestRoutineTU.lua)
	local tuLines = R.TULines and R:TULines(extra) or {}
	-- MN3: Marktdaten-Netz (Zeile im Bericht und Feld "markt")
	local okM, market = pcall(ns.MarketLine, ns)
	if okM and market then extra.markt = market end
	-- TR-ALLE: eine Zusammenfassung (x von y bestanden, z nicht prüfbar – Grund)
	-- dieselben Zähler wie der Kopf des Testberichts (GoldSentinelTest), damit jede Zahl aufgeht
	local cnt = RUN.counts or {}
	local nOk, nErr, nSkip, nClient = cnt.ok or 0, cnt.fehler or 0, cnt.uebersprungen or 0, cnt.client or 0
	self:PortionDone("Abschluss")   -- das laufende Bild bis hierher (Rest des Abschlusses danach)
	local summary = string.format(L.TR_SUMMARY, nOk, nOk + nErr, nSkip + nClient, nClient, nSkip, nErr,
		self.portions or 0, self.portionMax or 0, tostring(self.portionMaxAt or "-"), R.FRAME_LIMIT, self.portionsOver or 0)
	-- leistung.md Regel 8: Schritte (Prüfungen) über 16 ms mit Namen, getrennt von "allein über 5 ms"
	local over16, over5 = {}, {}
	for _, txt in ipairs(self.slowChecks or {}) do
		local ms = tonumber(txt:match("([%d%.]+) ms$")) or 0
		if ms > R.STEP_LIMIT then over16[#over16 + 1] = txt else over5[#over5 + 1] = txt end
	end
	summary = summary .. " · " .. string.format(L.TR_SUMMARY_STEPS, R.STEP_LIMIT, #over16 > 0 and table.concat(over16, ", ") or "-")
	if #over5 > 0 then
		summary = summary .. " · " .. string.format(L.TR_SUMMARY_SLOW, R.FRAME_LIMIT, table.concat(over5, ", "))
	end
	-- Gesamtdauer: eigene Rechenzeit (Summe aller Bilder) und Uhrzeit vom Start bis jetzt
	local cpu = 0
	local parts = {}
	for _, letter in ipairs({ "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "U", "Abschluss" }) do
		local e = self.areaMs and self.areaMs[letter]
		if e then
			cpu = cpu + e.ms
			parts[#parts + 1] = string.format("%s %.1f ms/%d", letter, e.ms, e.frames)
		end
	end
	summary = summary .. " · " .. string.format(L.TR_SUMMARY_TOTAL, cpu, (R.Now() - (self.startT or R.Now())) / 1000)
	summary = summary .. " · " .. string.format(L.TR_SUMMARY_WHOLE, R.WHOLE_LIMIT, self.wholeOver or 0, R.STEP_LIMIT,
		self.wholeEnv or 0, self.wholeMax or 0, self.wholeMaxOwn or 0)
	extra.ort = self.envText
	extra.bereiche = table.concat(parts, "; ")
	-- "z nicht prüfbar – Grund": die häufigsten Gründe (höchstens 3), Rest im Bericht je Prüfung
	local whyN = {}
	for _, e in ipairs(RUN.results or {}) do
		local w = (e.status == "SKIP" and e.grund) or (e.status == "CLIENT" and L.TR_WHY_CLIENT) or nil
		if w then
			w = tostring(w):match("^[^\n]*"):sub(1, 90)
			whyN[w] = (whyN[w] or 0) + 1
		end
	end
	local whys = {}
	for why, n in pairs(whyN) do whys[#whys + 1] = { why, n } end
	table.sort(whys, function(a, b) if a[2] ~= b[2] then return a[2] > b[2] end return a[1] < b[1] end)
	local wl = {}
	for i = 1, math.min(3, #whys) do wl[#wl + 1] = whys[i][1] .. " ×" .. whys[i][2] end
	if #wl > 0 then summary = summary .. " – " .. string.format(L.TR_SUMMARY_WHY, table.concat(wl, "; ")) end
	if stopped then summary = summary .. " · " .. tostring(stopped) end
	extra.zusammenfassung = summary
	-- Nachtrag D: Fenster-Prüfung vorgemerkt -> klar sagen, was noch fehlt (passiert von selbst)
	if self.waitWindow and not stopped then
		summary = summary .. " · " .. L.TR_PENDING_WIN
		if ThreatSentinelDB then ThreatSentinelDB.trPending = { t = time(), ref = ns.version .. " " .. date("%Y-%m-%d %H:%M") } end
		self:InstallCatchUp()
	end
	-- Prüfliste (nur Entwickler): neuester Lauf (vor den Prüfliste-Zeilen, damit der Bericht den neuen Stand zeigt)
	if self.alles and not stopped then self:PLRunResult(nOk, nErr, self.waitWindow) end
	-- Prüfliste (nur Entwickler): Stand jeder Handprüfung im Bericht
	local plLines = ns:PLLines()
	if #plLines > 0 then extra.pruefliste = table.concat(plLines, " | ") end
	local text = RUN:Finish(extra)
	text = text .. "\n" .. table.concat({
		"echte Daten unverändert: " .. extra.sandbox,
		"Livedaten (Sync-Adressbuch, Markt, gs*) unverändert: " .. tostring(self.liveText),
		self.envText,
		(function()
			-- TS-S3b: Messung der Formel (Stufe 3) gegen die echte Bedrohung, nur Era/TBC im Entwicklermodus
			local m = ThreatSentinelDB and ThreatSentinelDB.s3mess
			if type(m) ~= "table" or (m.fights or 0) == 0 then return L.TR_S3_NONE end
			return string.format(L.TR_S3, m.fights, m.top1 or 0, m.full or 0)
		end)(),
		"CVars unverändert: " .. extra.cvars,
		"Tastenbelegung unverändert: " .. extra.tasten,
		"Simulationen zurückgesetzt: " .. extra.simulationen,
		"Stubs zurückgesetzt: " .. extra.stubs,
		"Echte Aktionen während der Routine: " .. real .. " (erwartet 0) · nur mitgeschrieben: " .. (extra.mitgeschrieben ~= "" and extra.mitgeschrieben or "-"),
		"Fehlerzähler: " .. extra.fehlerzaehler .. " · gesperrte Aktionen: " .. extra.blockiert,
		"Bedrohung: " .. extra.bedrohung,
		"nicht automatisiert: " .. extra.nicht_automatisiert,
		"Kampflog/Meter: Simulation erst nach /reload",
		stopped and ("Abgebrochen: " .. tostring(stopped)) or nil,
	}, "\n")
	if #tuLines > 0 then text = text .. "\n" .. table.concat(tuLines, "\n") end
	if okM and market then text = text .. "\n" .. market end
	if #plLines > 0 then text = text .. "\n" .. table.concat(plLines, "\n") end
	text = summary .. "\n" .. text
	text = Clean(text)
	self.lastText = text
	RUN = nil
	self.running = false
	if ns.Test and ns.Test.ShowText then ns.Test:ShowText(text, L.TR_TITLE) end
	self:Say(summary)
	self:Say(L.TR_SAVED)
	self:Say(L.TR_RELOAD)
end

-- /reload oder Ausloggen mitten in der Routine: echte Daten vor dem Speichern zurück (nie Testdaten in den SavedVariables)
ns:On("PLAYER_LOGOUT", function()
	if not R.running then return end
	pcall(UnswapAll)
	ns.routineRunning = false
	pcall(R.RestoreSandbox, R)
	ns.actLog = nil
	R.running, R.cont = false, nil
end)

-- Schalter, die die Routine nicht verändern darf (Q2): Zustand jetzt
function R:SimState()
	return { testMode = ns.testMode or nil, liveTest = ns.liveTest or nil, moveMode = ns.moveMode or nil,
		simSecret = ns.simSecret, simAccess = ns.simAccess, isModern = ns.isModern, testBait = ns.testBait }
end

local SIM_NAMES = { testMode = "TR_SW_TEST", moveMode = "TR_SW_MOVE", liveTest = "TR_SW_LIVE", center = "TR_SW_CENTER" }

-- Vergleich vorher/nachher: "OK", "OK (Testmodus war schon an)" oder "FEHLER (moveMode an)"
function R.SimResult(before, after)
	local bad, was = {}, {}
	local keys = { "testMode", "liveTest", "moveMode", "simSecret", "simAccess", "isModern", "testBait" }
	for _, k in ipairs(keys) do
		local b, a = before[k], after[k]
		if b ~= a then
			if a == nil or a == false then bad[#bad + 1] = k .. " aus"
			elseif a == true then bad[#bad + 1] = k .. " an"
			else bad[#bad + 1] = k .. "=" .. tostring(a) end
		elseif a == true and SIM_NAMES[k] then
			was[#was + 1] = L[SIM_NAMES[k]]
		end
	end
	if #bad > 0 then return "FEHLER (" .. table.concat(bad, ", ") .. ")" end
	if #was > 0 then return "OK (" .. string.format(L.TR_SW_WAS_ON, table.concat(was, ", ")) .. ")" end
	return "OK"
end

-- Hinweiszeile zu Beginn (Q3): was schon an ist, kann Ergebnisse in I/K beeinflussen
function R.PreNotice(state)
	local on = {}
	for _, k in ipairs({ "testMode", "moveMode", "liveTest", "center" }) do
		if state[k] then on[#on + 1] = L[SIM_NAMES[k]] end
	end
	if #on == 0 then return nil end
	return string.format(L.TR_PRE_ACTIVE, table.concat(on, ", "))
end

function R:Start(only, alles)
	if self.running then self:Say(L.TR_RUNNING) return end
	if not ns:RequireDev() then return end
	if InCombat() then ns:Print(L.NOT_IN_COMBAT) return end
	if not GoldSentinelTest or not GoldSentinelTest.Begin then self:Say("GoldSentinelTest fehlt") return end
	InstallHooks()
	-- Prüfliste: falls der Entwicklermodus beim Einloggen noch nicht erkannt war, jetzt anmelden
	if not ns.PL and ns.PLRegister then pcall(ns.PLRegister, ns) end
	self.running = true
	self.realCalls = 0
	self.notAuto = 0
	self.seen, self.cont = {}, nil
	self.alles, self.stopReq, self.areaNr, self.done, self.yields = alles and true or false, false, 0, 0, 0
	self.portions, self.portionMax, self.portionMaxAt, self.portionsOver, self.slowChecks = 0, 0, nil, 0, {}
	-- Testort (Hinweis 18.11. 19:30): ganze Bilder nur als Auskunft, Ort und Umgebung beim Start
	self.wholeN, self.wholeMax, self.wholeMaxOwn, self.wholeOver, self.wholeEnv = 0, 0, 0, 0, 0
	self.lastStepAt, self.lastPortion = nil, nil
	self.envText = R.EnvLine()
	self.areaMs, self.curLetter, self.startT = {}, nil, R.Now()
	self.waitWindow = false
	self.stepStart = nil
	if self.TUReset then self:TUReset() end
	self.testWasShown = ns.Test.frame and ns.Test.frame:IsShown() or false
	self.optWasShown = ns.Options.frame and ns.Options.frame:IsShown() or false
	-- Zustand der Simulationen vor dem Lauf (Q2) und Hinweiszeile (Q3)
	self.simBefore = self:SimState()
	local pre = R.PreNotice({ testMode = ns.testMode, moveMode = ns.moveMode, liveTest = ns.liveTest, center = self.testWasShown })
	if pre then self:Say(pre) end
	RUN = GoldSentinelTest.Begin("ThreatSentinel", ns.version, ThreatSentinelDB)
	-- globale Namen vor der Routine (T131)
	-- Befund 18.11. (T131 47,4 ms in einem Bild): die Liste der Globals entsteht jetzt in Portionen im ersten Bereich
	-- (R:ScanGlobals, mit Abgabe), nicht mehr am Stück beim Start
	self.globalsBefore = nil
	self:TakeSandbox()
	ns.actLog = { n = {} }
	self.lastAct = ns.actLog.n
	ns.routineRunning = true
	local list = only and { only } or AREAS
	self.areaTotal = #list
	self:Say(string.format(L.TR_STARTED, only or "A–K, U"))
	local i = 0
	local function body()
		-- schon beendet (Ausloggen/Fehler hat alles zurückgesetzt): nichts mehr tun
		if not R.running then return false end
		-- TR-ALLE: abbrechen ("/ts testroutine stop") – laufenden Bereich sauber schliessen, Rest als übersprungen
		if R.stopReq then
			if R.cont then R.cont = nil; EndArea(list[i]) end
			for j = i + 1, #list do RUN:Skip("X" .. list[j], list[j], "Bereich " .. list[j], L.TR_STOPPED) end
			R:Finish(L.TR_STOPPED)
			return false
		end
		if R.cont then
			if InCombat() then
				R.cont = nil
				EndArea(list[i])
			else
				RunCont()
				return true
			end
		end
		i = i + 1
		local letter = list[i]
		if not letter then R:Finish() return false end
		if InCombat() then
			for j = i, #list do RUN:Skip("X" .. list[j], list[j], "Bereich " .. list[j], L.TR_COMBAT) end
			R:Say(L.TR_COMBAT)
			R:Finish(L.TR_COMBAT)
			return false
		end
		RunArea(letter)
		return true
	end
	-- Ein Fehler beim Zurücksetzen (RestoreSandbox, Finish) darf das Addon nie stilllegen:
	-- dann immer routineRunning = false und actLog = nil, Fehler melden.
	local function step()
		R.stepStart = R.Now()
		R:WholeFrame(R.stepStart)
		local ok, more = pcall(body)
		R:PortionDone()
		if ok then
			if more then C_Timer.After(0, step) end
			return
		end
		R:OnStepError(more)
	end
	C_Timer.After(0, step)
end

-- Fehler in einem Schritt der Routine (auch beim Zurücksetzen): das Addon darf nie stillliegen.
-- dry = true (nur Testfall T-R4): Zustand freigeben, aber den laufenden Bericht und die Meldungen stehen lassen.
function R:OnStepError(err, dry)
	ns.routineRunning = false
	ns.actLog = nil
	R.running = false
	R.cont = nil
	if dry then return end
	UnswapAll()
	ns.testBait = nil
	RUN = nil
	ns:TestError("TestRoutine", err)
	ns:ReportError(err)
	R:Say(string.format(L.TR_ABORTED, tostring(err):match("^[^\n]*") or "?"))
end

local HALF = { "TR_HALF_1", "TR_HALF_2", "TR_HALF_3", "TR_HALF_4", "TR_HALF_5", "TR_HALF_6", "TR_HALF_7", "TR_HALF_8", "TR_HALF_9", "TR_HALF_10" }

function R:Command(arg)
	arg = strtrim((arg or ""):lower())
	if arg == "" then
		self:Start(nil)
	elseif arg:match("^[a-ku]$") then
		self:Start(arg:upper())
	elseif arg == "alles" or arg == "all" then
		-- TR-ALLE: alles Automatische nacheinander, Fortschritt und eine Zusammenfassung
		self:Start(nil, true)
	elseif arg == "stop" or arg == "abbrechen" then
		if self.running then self.stopReq = true; self:Say(L.TR_STOPPING) else self:Say(L.TR_NOT_RUNNING) end
	elseif arg == "halb" or arg == "half" then
		if not ns:RequireDev() then return end
		self:Say(L.TR_HALF_TITLE)
		for _, k in ipairs(HALF) do ns:Print(L[k]) end
	elseif arg == "sprache" or arg == "language" then
		-- T128: andere Sprache für den nächsten /reload (nur Entwickler)
		if not ns:RequireDev() then return end
		local other = (GetLocale() == "deDE") and "enUS" or "deDE"
		ThreatSentinelDB.devLocale = other
		self:Say(string.format(L.TR_LOCALE_SET, other))
	elseif arg == "letzte" or arg == "last" then
		if not ns:RequireDev() then return end
		if self.lastText and ns.Test.ShowText then ns.Test:ShowText(self.lastText, L.TR_TITLE)
		else self:Say(L.TR_NO_LAST) end
	else
		self:Say(L.TR_USAGE)
	end
end

------------------------------------------------------------
-- Hilfen für TestRoutineTU.lua (umfassende Tests, Bereich U)
------------------------------------------------------------
R.H = { C = C, K = K, CL = CL, KN = KN, Swap = Swap, UnswapAll = UnswapAll, Scene = Scene, WithAPI = WithAPI, NIL = NIL,
	Ret = Ret, SECRET = SECRET, S = S, Clean = Clean, Near = Near, Ms = Ms, Counter = Counter, Shown = Shown, Copy = Copy,
	RestoreInto = RestoreInto, Diff = Diff, FormatStem = FormatStem, WithFlavor = WithFlavor, Capture = Capture, Has = Has,
	Time = Time, InCombat = InCombat, Num = Num, Area = Area, swaps = swaps, MaybeYield = MaybeYield }
function R:RunObject() return RUN end
