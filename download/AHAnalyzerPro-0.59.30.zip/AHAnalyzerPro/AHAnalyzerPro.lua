-- ============================================================
-- AH Analyzer Pro 5.9 - Kern
-- Datenbank, Markt-Scan, Preisverlauf, Trends, Marktwert (Median),
-- Händlerpreise, Export, Befehle
--
-- WICHTIG: Alle Dateien des Addons benutzen NUR die globale
-- Tabelle "AHAnalyzerPro". Keine weiteren Namensräume.
-- ============================================================

local ADDON_NAME = ...

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

A.version = "0.59.30"
A.DONATE_URL = "https://www.paypal.com/ncp/payment/46R68N2BF7BTY"   -- Spenden (PayPal)
A.ADDON_NAME = ADDON_NAME or "AHAnalyzerPro"
A.SCAN_COOLDOWN = 900          -- Server erlaubt nur alle 15 Minuten einen Scan
A.DB_VERSION = 4
A.MAX_HISTORY = 300            -- max. Preis-Einträge pro Item
A.HISTORY_DAYS = 90            -- ältere Einträge werden gelöscht
A.MARKET_DAYS = 14             -- Marktwert = Median der Preise dieser Tage
A.FRESH_SECONDS = 2 * 3600     -- so lange gilt ein Preis als aktuell (für Händler-Schnäppchen)

-- ------------------------------------------------------------
-- Ausgabe
-- ------------------------------------------------------------
function A:Print(msg)
    print("|cff00d1d1[AH Analyzer]|r " .. tostring(msg))
end

-- ------------------------------------------------------------
-- Internes Nachrichtensystem (Kern -> Oberfläche)
-- Ereignisse: SCAN_STARTED, SCAN_PROGRESS, SCAN_FINISHED,
--             SCAN_FAILED, DATA_CHANGED, WATCHLIST_CHANGED
-- ------------------------------------------------------------
A.listeners = A.listeners or {}

function A:On(event, fn)
    self.listeners[event] = self.listeners[event] or {}
    table.insert(self.listeners[event], fn)
end

function A:Fire(event, ...)
    local list = self.listeners[event]
    if not list then return end
    local yieldOK = self.yieldOK
    self.yieldOK = false            -- innerhalb von pcall darf eine Aufgabe nicht pausieren
    for _, fn in ipairs(list) do
        local ok, err = pcall(fn, ...)
        if not ok then
            self:Print(L["Fehler bei "] .. event .. ": " .. tostring(err))
        end
    end
    self.yieldOK = yieldOK
end

-- ------------------------------------------------------------
-- Aufgaben im Hintergrund (gegen Ruckeln)
-- Große Arbeiten (Scan auswerten, lange Listen aufbauen) laufen in kleinen
-- Portionen: pro Frame nur wenige Millisekunden, der Rest im nächsten Frame.
--   A:Job(name, fn)  - Aufgabe starten (gleicher Name ersetzt eine wartende)
--   A:Pause()        - in langen Schleifen aufrufen: gibt die Zeit ab, wenn
--                      das Frame-Budget aufgebraucht ist (außerhalb einer
--                      Aufgabe macht es nichts)
-- ------------------------------------------------------------
A.FRAME_BUDGET = 6              -- Millisekunden Rechenzeit pro Frame für Hintergrund-Aufgaben
A.jobs = {}
A.yieldOK = false
local jobStart = 0
local pauseCount = 0
local Clock = debugprofilestop

function A:Job(name, fn)
    for i = #self.jobs, 1, -1 do
        local j = self.jobs[i]
        if j.name == name and not j.started then table.remove(self.jobs, i) end
    end
    table.insert(self.jobs, { name = name, co = coroutine.create(fn) })
end

function A:HasJob(name)
    for _, j in ipairs(self.jobs) do if j.name == name then return true end end
    return false
end

function A:Pause()
    if not self.yieldOK then return end
    if Clock then
        if Clock() - jobStart < self.FRAME_BUDGET then return end
    else
        pauseCount = pauseCount + 1
        if pauseCount < 200 then return end
    end
    pauseCount = 0
    self.yieldOK = false
    coroutine.yield()
    self.yieldOK = true
end

local jobFrame = CreateFrame("Frame")
jobFrame:SetScript("OnUpdate", function()
    if #A.jobs == 0 then return end
    jobStart = Clock and Clock() or 0
    pauseCount = 0
    while #A.jobs > 0 do
        local j = A.jobs[1]
        j.started = true
        A.yieldOK = true
        local ok, err = coroutine.resume(j.co)
        A.yieldOK = false
        if not ok then
            table.remove(A.jobs, 1)
            A:Print(L["Fehler bei "] .. tostring(j.name) .. ": " .. tostring(err))
        elseif coroutine.status(j.co) == "dead" then
            table.remove(A.jobs, 1)
        else
            return          -- Budget aufgebraucht: im nächsten Frame weiter
        end
        if Clock and Clock() - jobStart >= A.FRAME_BUDGET then return end
    end
end)

-- ------------------------------------------------------------
-- Hilfsfunktionen
-- ------------------------------------------------------------
local function DeepCopy(t)
    if type(t) ~= "table" then return t end
    local c = {}
    for k, v in pairs(t) do c[k] = DeepCopy(v) end
    return c
end

local function FillDefaults(target, source)
    for k, v in pairs(source) do
        if target[k] == nil then
            target[k] = DeepCopy(v)
        elseif type(v) == "table" and type(target[k]) == "table" then
            FillDefaults(target[k], v)
        end
    end
end

function A:CountTable(t)
    local n = 0
    if type(t) == "table" then
        for _ in pairs(t) do n = n + 1 end
    end
    return n
end

-- ------------------------------------------------------------
-- WoW-Währung: Gold, Silber, Kupfer
-- 1 Gold = 100 Silber, 1 Silber = 100 Kupfer. Intern wird immer in Kupfer gerechnet.
-- Anzeige wahlweise mit den WoW-Münzsymbolen (Standard) oder mit Buchstaben.
-- ------------------------------------------------------------
local COIN_ICONS = {
    "|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:2:0|t",
    "|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t",
    "|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t",
}
local COIN_COLORS = { "ffd700", "c7c7cf", "eda55f" }

-- Kurzzeichen für Gold / Silber / Kupfer je Sprache des Addons
A.COIN_LETTERS = {
    deDE = { "g", "s", "k" },  enUS = { "g", "s", "c" },  frFR = { "po", "pa", "pc" },
    esES = { "o", "p", "c" },  esMX = { "o", "p", "c" },  ptBR = { "o", "p", "c" },
    itIT = { "o", "a", "r" },  ruRU = { "з", "с", "м" },  koKR = { "골", "실", "코" },
    zhCN = { "金", "银", "铜" }, zhTW = { "金", "銀", "銅" },
}

-- Eingabe: alle Kurzzeichen aller Sprachen -> 1 (Gold), 2 (Silber), 3 (Kupfer)
local UNIT_INDEX = {}
for _, letters in pairs(A.COIN_LETTERS) do
    for i, u in ipairs(letters) do UNIT_INDEX[u] = i end
end
for u, i in pairs({ gold = 1, silber = 2, silver = 2, kupfer = 3, copper = 3, ["с"] = 2, ["c"] = 3,
                   ["골드"] = 1, ["실버"] = 2, ["코퍼"] = 3, ["金币"] = 1, ["银币"] = 2, ["铜币"] = 3,
                   ["金幣"] = 1, ["銀幣"] = 2, ["銅幣"] = 3 }) do UNIT_INDEX[u] = i end

function A:SplitMoney(copper)
    copper = math.floor(math.abs(copper or 0) + 0.5)
    return math.floor(copper / 10000), math.floor((copper % 10000) / 100), copper % 100
end

function A:CoinUnit(i)
    if self.db and self.db.settings.moneyStyle == "letters" then
        local letters = self.COIN_LETTERS[self.uiLang or "enUS"] or self.COIN_LETTERS.enUS
        return letters[i], true
    end
    return COIN_ICONS[i], false
end

-- Kupfer -> "12 [Gold] 34 [Silber] 56 [Kupfer]"
-- compact = true für schmale Spalten: ab 100 Gold nur Gold, ab 1 Gold ohne Kupfer
function A:FormatMoney(copper, compact)
    if not copper then return "|cff888888-|r" end
    local negative = copper < 0
    local g, s, c = self:SplitMoney(copper)
    local show = { g > 0, s > 0, c > 0 }
    if compact then
        if g >= 100 then show = { true, false, false }
        elseif g > 0 then show = { true, s > 0, false } end
    end
    if not (show[1] or show[2] or show[3]) then show[3] = true end   -- 0 Kupfer
    local values = { g, s, c }
    local parts = {}
    for i = 1, 3 do
        if show[i] then
            local unit, isLetter = self:CoinUnit(i)
            if isLetter then
                table.insert(parts, "|cff" .. COIN_COLORS[i] .. values[i] .. unit .. "|r")
            else
                table.insert(parts, values[i] .. unit)
            end
        end
    end
    local text = table.concat(parts, " ")
    if negative then text = "-" .. text end
    return text
end

-- frühere Kurzform (z.B. "12.34g") -> jetzt ebenfalls Gold/Silber/Kupfer, kompakt
function A:FormatGoldShort(copper)
    if not copper then return "-" end
    return self:FormatMoney(copper, true)
end

-- Text -> Kupfer. Versteht:
--   "12.5" / "12,5"         = Gold mit Nachkommastellen
--   "12g 50s 3c", "12g50s"  = Gold, Silber, Kupfer (Kurzzeichen jeder Sprache: g/s/k, po/pa/pc, з/с/м, 金/银/铜 ...)
function A:ParseGold(text)
    if not text then return nil end
    text = string.lower(tostring(text)):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    text = text:gsub("|t[^|]*|t", ""):gsub("%s+", " ")
    if text:match("^%s*$") then return nil end
    local total, units, plain = 0, 0, nil
    for num, unit in text:gmatch("([%d%.,]+)%s*([^%d%s%.,]*)") do
        local n = tonumber((num:gsub(",", ".")))
        if not n then return nil end
        if unit == "" then
            if plain or units > 0 then return nil end
            plain = n
        else
            local i = UNIT_INDEX[unit]
            if not i then return nil end
            total = total + n * ({ 10000, 100, 1 })[i]
            units = units + 1
        end
    end
    if plain and units > 0 then return nil end
    if plain then total = plain * 10000 end
    total = math.floor(total + 0.5)
    if total <= 0 then return nil end
    return total
end

-- Zeitdifferenz lesbar
function A:FormatAgo(timestamp)
    if not timestamp or timestamp == 0 then return L["nie"] end
    local diff = time() - timestamp
    if diff < 60 then return string.format(L["vor %d Sek."], diff) end
    if diff < 3600 then return string.format(L["vor %d Min."], math.floor(diff / 60)) end
    if diff < 86400 then return string.format(L["vor %d Std."], math.floor(diff / 3600)) end
    return string.format(L["vor %d Tagen"], math.floor(diff / 86400))
end

function A:FormatDuration(seconds)
    seconds = math.max(0, math.floor(seconds or 0))
    return string.format("%d:%02d", math.floor(seconds / 60), seconds % 60)
end

-- Prozentwert farbig
function A:FormatPercent(value)
    if not value then return "|cff666666-|r" end
    if value > 0.05 then
        return string.format("|cff33dd55+%.1f%%|r", value)
    elseif value < -0.05 then
        return string.format("|cffff5544%.1f%%|r", value)
    end
    return "|cffaaaaaa0.0%|r"
end

-- ------------------------------------------------------------
-- Datenbank
-- ------------------------------------------------------------
local DEFAULTS = {
    dbVersion = 4,
    marketData = {},      -- [itemID] = { name, history = { {t, p, q}, ... } }
    watchlist = {},       -- [itemID] = { name, buyBelow, sellAbove, added }
    scanLog = {},         -- letzte Scans { t, items, duration }
    lastScanTime = 0,     -- time() des letzten Scan-Starts
    totalScans = 0,
    lastOwnScan = nil,    -- { t, data = { [itemID] = { price, qty } } }
    names = {},           -- [Sprache][itemID] = Item-Name (alle WoW-Sprachen)
    namesSent = {},       -- [itemID] = zuletzt geteilt (time())
    vendorPrices = {},    -- [itemID] = Händlerpreis pro Stück in Kupfer (0 = nicht verkaufbar)
    vendorBuy = {},       -- [itemID] = was ein Händler pro Stück VERLANGT (beim Händler gelesen)
    deStats = {},         -- [Gruppe] = { n = Entzauberungen, mats = { [itemID] = { times, total } } } (gelernt)
    chars = {},           -- [Name-Realm] = { name, realm, class, money, gold = { {t, m} }, bags, bank }
    sync = {
        enabled = true,
        received = 0,     -- empfangene Preise gesamt
        lastReceived = 0,
        peers = {},       -- [Name] = zuletzt gehört (time())
    },
    settings = {
        buttonPos = nil,
        windowPos = nil,
        alertSound = true,
        minQuantityForTrends = 1,
        theme = "classic",        -- "classic" (wie das Auktionshaus) oder "modern"
        scale = 1,                -- Fenstergröße
        helpSeen = false,         -- Willkommens-Hilfe schon gezeigt
        lastTab = nil,            -- zuletzt geöffneter Reiter
        sniperFilters = false,    -- Sniper-Filter aufgeklappt
        ahIntegration = false,    -- false = eigenes Fenster (Standard), true = im Auktionshaus-Fenster
        tooltipInfo = true,       -- Preis, Ø 7 Tage und Trend im Item-Tooltip
        tooltipChartDays = 7,     -- Preisdiagramm unter dem Item-Tooltip (0 = aus, 1 / 7 / 30 Tage)
        tooltipVendor = true,     -- Händlerpreis im Item-Tooltip
        craftPanel = true,        -- Gewinn-Fenster neben dem Berufsfenster
        tooltipChars = true,      -- Bestand deiner Twinks im Item-Tooltip
        tooltipDE = true,         -- Entzauberungswert im Item-Tooltip
        mailButtons = true,       -- Knöpfe "AH-Post abholen" am Briefkasten
        chartEMA = true,          -- EMA-Linien im Tab Charts
        ahSize = nil,             -- gemessene Größe des Auktionshaus-Fensters { w, h }
        moneyStyle = "icons",     -- Geldanzeige: "icons" (Münzsymbole) oder "letters" (g/s/k ...)
        nameLocale = "auto",      -- Sprache der angezeigten Item-Namen ("auto" = wie der Client)
        nameLocaleChosen = false, -- true, sobald der Spieler selbst eine Sprache gewählt hat
        uiLanguage = "auto",      -- Sprache des Addons ("auto" = wie der Client, sonst "deDE"/"enUS")
    },
    lists = {
        items = {},               -- [Name] = { created, entries = { [itemID] = { qty, added } } }
        tolerance = 100,          -- Max-Preis der Sniper-Ziele aus einer Liste: % vom Marktwert
    },
    ledger = {
        entries = {},             -- Buchungen { t, kind = "sale"/"buy"/"deposit", itemID, name, qty, amount, cut, refund, player, src }
        seen = {},                -- [Schlüssel] = Zeit: schon gebuchte Rechnungen aus dem Briefkasten
        period = "7",             -- zuletzt gewählter Zeitraum
    },
    seller = {
        undercut = "copper",      -- unterbieten um: "copper" (1 Kupfer), "p1" (1 %), "p5" (5 %)
        duration = 2,             -- zuletzt gewählte Dauer (1 kurz, 2 mittel, 3 lang)
        items = {},               -- [itemID] = { price, duration, qty } zuletzt benutzt
    },
    watcher = {
        enabled = false,          -- Schnäppchen-Wächter an/aus
        threshold = 50,           -- Treffer, wenn Preis <= x % vom Marktwert
        minValue = 10,            -- nur Waren mit Marktwert ab x Kupfer pro Stück
        budget = 500000,          -- höchstens so viel Kupfer pro Schnäppchen (50 Gold)
        interval = 20,            -- Sekunden zwischen zwei Runden
        mode = "combined",        -- "combined" = alle Kategorien in einer Suche, "single" = einzeln
        cats = {                  -- Kategorien (nur Handwerkswaren, keine Ausrüstung)
            herb = true, metal = true, cloth = true, leather = true, enchanting = true,
            elemental = true, gems = true, cooking = true, consumable = false,
        },
        found = 0,                -- bestätigte Schnäppchen gesamt
    },
    sniper = {
        targets = {},                                 -- [key] = Ziel (Item oder Suchbegriff, Preis, Menge, Budget, Filter)
        binds = { "MOUSEWHEELUP", "MOUSEWHEELDOWN" }, -- Kauf-Auslöser im Sniper-Modus
        armed = false,                                -- Sniper-Modus an/aus
        interval = 0,                                 -- Sekunden zwischen zwei Suchen (0 = so oft der Server erlaubt)
        instantBuy = true,                            -- Waren mit EINER Raste kaufen (Preis wird vorab geholt)
        imported = false,                             -- alte Watchlist-Ziele übernommen
    },
}

-- Alte Daten (Version 3.x) so weit wie möglich übernehmen
local function MigrateOldMarketData(old)
    local new = {}
    if type(old) ~= "table" then return new end
    for itemID, entry in pairs(old) do
        local id = tonumber(itemID)
        if id and type(entry) == "table" and type(entry.history) == "table" then
            local hist = {}
            for _, h in ipairs(entry.history) do
                if type(h) == "table" and h.price and (h.time or h.timestamp) then
                    table.insert(hist, { t = h.time or h.timestamp, p = h.price, q = h.quantity or h.qty or 0 })
                end
            end
            if #hist > 0 then
                table.sort(hist, function(a, b) return a.t < b.t end)
                new[id] = { name = entry.name, history = hist }
            end
        end
    end
    return new
end

function A:InitDB()
    if type(AHAnalyzerProDB) ~= "table" then
        AHAnalyzerProDB = DeepCopy(DEFAULTS)
    elseif AHAnalyzerProDB.dbVersion ~= self.DB_VERSION then
        local old = AHAnalyzerProDB
        AHAnalyzerProDB = DeepCopy(DEFAULTS)
        AHAnalyzerProDB.marketData = MigrateOldMarketData(old.marketData)
        if type(old.settings) == "table" then
            AHAnalyzerProDB.settings.windowPos = nil
        end
        self:Print(L["Datenbank auf Version 4 umgestellt."])
    end
    FillDefaults(AHAnalyzerProDB, DEFAULTS)
    -- Vorsichtshalber: Cooldown-Zeit muss eine time()-Zeit sein, keine GetTime()-Zeit
    if (AHAnalyzerProDB.lastScanTime or 0) > time() + 60 then
        AHAnalyzerProDB.lastScanTime = 0
    end
    self.db = AHAnalyzerProDB
    -- 0.59.27: Addon-Fenster ist standardmäßig vom Auktionshaus gelöst (eigenes, frei vergrößerbares Fenster)
    if not self.db.settings.detachedWindow then
        self.db.settings.ahIntegration = false
        self.db.settings.detachedWindow = true
    end
    -- 0.59.20: Sniper sucht standardmäßig so oft wie möglich (alter Standard 3 Sek.)
    local sn = self.db.sniper
    if sn and not sn.fastSearch then
        if sn.interval == 3 then sn.interval = 0 end
        sn.fastSearch = true
    end
    -- Item-Namen folgen der Client-Sprache, solange der Spieler nichts anderes gewählt hat
    if not self.db.settings.nameLocaleChosen then self.db.settings.nameLocale = "auto" end
    self:ApplyUILanguage()
end

-- ------------------------------------------------------------
-- Item-Infos
-- ------------------------------------------------------------
-- Name in der Sprache deines WoW-Clients (für die Suche im Auktionshaus)
function A:GetClientItemName(itemID)
    local entry = self.db and self.db.marketData[itemID]
    if entry and entry.name and not entry.name:find("^Item #") then
        return entry.name
    end
    local name = GetItemInfo and GetItemInfo(itemID)
    if name then
        if entry then entry.name = name end
        if self.Names then self.Names:Learn(itemID, name) end
        return name
    end
    -- Client kennt das Item (noch) nicht: eingebaute Namensliste in der Client-Sprache
    local builtin = self.Names and self.Names:BuiltinGet(itemID, self.Names:ClientLocale())
    if builtin then return builtin end
    return (entry and entry.name) or ("Item #" .. tostring(itemID))
end

-- Name in der gewählten Anzeigesprache (Standard Englisch).
-- Unbekannt in dieser Sprache -> Name aus dem eigenen Client.
function A:GetItemName(itemID)
    local N = self.Names
    if N and self.db then
        local loc = N:DisplayLocale()
        if loc ~= N:ClientLocale() then
            local nm = N:Get(itemID, loc)
            if nm then return nm end
        end
    end
    return self:GetClientItemName(itemID)
end

function A:GetItemIcon(itemID)
    if GetItemIcon then
        local ok, icon = pcall(GetItemIcon, itemID)
        if ok and icon then return icon end
    end
    return "Interface\\Icons\\INV_Misc_QuestionMark"
end

-- Item per Name in den Marktdaten finden (exakt, sonst eindeutiger Teiltreffer)
-- Item per Name (jede Sprache), Item-ID oder Item-Link finden.
-- Rückgabe: itemID oder nil, Anzahl passender Items
function A:FindItemByName(text)
    if not text or text == "" or not self.db then return nil end
    if self.Names then return self.Names:Resolve(text) end
    return tonumber(text)
end

-- ------------------------------------------------------------
-- Gebote unter Wert: jedes Gebot, das irgendwo gelesen wird (Komplett-Scan im alten
-- Auktionshaus, Einzelsuchen im Einkauf/Sniper/Preisprüfung), wird gemerkt, wenn es
-- deutlich unter dem Marktwert liegt. Der Profit-Reiter zeigt sie ("Gebote unter Wert").
-- ------------------------------------------------------------
A.BID_PREFILTER = 0.7          -- nur merken, wenn das nächste Gebot <= 70 % des Marktwerts ist
A.BID_MAX = 600                -- höchstens so viele merken (älteste fliegen raus)

-- timeLeft: Restzeit in Sekunden (Obergrenze), mv: Marktwert pro Stück (optional, sonst berechnet)
function A:NoteBid(itemID, nextBid, qty, timeLeft, buyout, isMine, mv)
    if not (self.db and itemID and nextBid and nextBid > 0) or isMine then return false end
    qty = math.max(1, qty or 1)
    mv = mv or self:GetMarketValue(itemID)
    if not mv or mv <= 0 then return false end
    if nextBid / qty > mv * self.BID_PREFILTER then return false end
    local bids = self.db.bids
    if not bids then bids = {}; self.db.bids = bids end
    local now = time()
    local key = itemID .. ":" .. qty .. ":" .. (buyout or 0) .. ":" .. math.floor(timeLeft or 0) .. ":" .. nextBid
    local e = bids[key]
    if not e then
        e = {}
        bids[key] = e
        self.bidCount = (self.bidCount or 0) + 1
    end
    e.itemID, e.nextBid, e.qty, e.buyout = itemID, nextBid, qty, buyout
    e.seen = now
    e.endsBy = now + (timeLeft or 43200)
    if self.bidCount > self.BID_MAX then self:PruneBids(true) end
    return true
end

function A:PruneBids(hard)
    local bids = self.db and self.db.bids
    if not bids then return end
    local now, n, list = time(), 0, {}
    for k, e in pairs(bids) do
        if (e.endsBy or 0) < now or now - (e.seen or 0) > 2 * 86400 then bids[k] = nil
        else n = n + 1; table.insert(list, { k = k, seen = e.seen or 0 }) end
    end
    if hard and n > self.BID_MAX then
        table.sort(list, function(a, b) return a.seen < b.seen end)
        for i = 1, n - self.BID_MAX do bids[list[i].k] = nil end
        n = self.BID_MAX
    end
    self.bidCount = n
end

-- Gebote, die mindestens threshold % unter dem Marktwert liegen (noch nicht abgelaufen)
function A:GetBidDeals(threshold)
    self:PruneBids()
    local out = {}
    for _, e in pairs(self.db and self.db.bids or {}) do
        local mv = self:GetMarketValue(e.itemID)
        if mv and mv > 0 then
            local unit = e.nextBid / e.qty
            local discount = (mv - unit) / mv * 100
            if discount >= (threshold or 30) then
                table.insert(out, {
                    itemID = e.itemID, name = self:GetItemName(e.itemID), price = math.floor(unit + 0.5), ref = mv,
                    discount = discount, profit = math.floor(mv * 0.95 - unit), quantity = e.qty,
                    nextBid = e.nextBid, endsBy = e.endsBy, seen = e.seen, bidDeal = true,
                })
            end
        end
    end
    return out
end

-- ------------------------------------------------------------
-- Preisverlauf und Kennzahlen
-- ------------------------------------------------------------
-- fromSync = true: Preis kam von einem Mitspieler
-- Gibt true zurück, wenn ein neuer Eintrag entstanden ist
-- unverified = true: verdächtig billiger Waren-Preis (mögliches Lockangebot), zählt erst nach Bestätigung
function A:RecordPrice(itemID, price, quantity, timestamp, fromSync, unverified)
    local db = self.db
    local entry = db.marketData[itemID]
    if not entry then
        entry = { history = {} }
        db.marketData[itemID] = entry
    end
    if not entry.name or entry.name:find("^Item #") then
        entry.name = (GetItemInfo and GetItemInfo(itemID)) or entry.name or ("Item #" .. itemID)
    end

    local h = entry.history
    -- Doppelte vermeiden: gibt es schon einen Eintrag innerhalb von 2 Minuten, nicht erneut speichern
    for i = #h, 1, -1 do
        local d = h[i].t - timestamp
        if d < 0 then d = -d end
        if d <= 120 then return false end
        if h[i].t < timestamp - 120 then break end
    end

    local newEntry = { t = timestamp, p = price, q = quantity or 0 }
    if fromSync then newEntry.s = 1 end
    if unverified then newEntry.u = 1 end
    self:InvalidateMarket(itemID)

    -- zeitlich sortiert einfügen (Sync-Daten können älter sein als eigene)
    local pos = #h + 1
    while pos > 1 and h[pos - 1].t > timestamp do pos = pos - 1 end
    table.insert(h, pos, newEntry)

    local cutoff = time() - self.HISTORY_DAYS * 86400
    while #entry.history > 0 and (entry.history[1].t < cutoff or #entry.history > self.MAX_HISTORY) do
        table.remove(entry.history, 1)
    end
    return true
end

function A:GetHistory(itemID)
    local entry = self.db and self.db.marketData[itemID]
    return entry and entry.history or {}
end

-- Zählt ein Eintrag für Preise und Statistik? Unbestätigte (mögliche Lockangebote) nicht.
local function Usable(e) return e and not e.u end
A.Usable = Usable

-- letzter bestätigter Eintrag (Index)
local function LastUsable(h, before)
    for i = (before or #h), 1, -1 do
        if Usable(h[i]) then return i end
    end
    return nil
end

function A:GetCurrent(itemID)
    local h = self:GetHistory(itemID)
    local i = LastUsable(h)
    if i then return h[i].p, h[i].q, h[i].t end
    return nil
end

-- Veränderung zum vorherigen Scan in %
function A:GetChangeSinceLastScan(itemID)
    local h = self:GetHistory(itemID)
    local i = LastUsable(h)
    local j = i and LastUsable(h, i - 1)
    if not j then return nil end
    local prev, cur = h[j].p, h[i].p
    if not prev or prev <= 0 then return nil end
    return (cur - prev) / prev * 100
end

-- Veränderung über einen Zeitraum in %
-- Vergleich: aktueller Preis gegen den letzten Preis, der mindestens
-- "seconds" alt ist. Gibt es so alte Daten noch nicht -> nil.
function A:GetTrend(itemID, seconds)
    local h = self:GetHistory(itemID)
    local ci = LastUsable(h)
    if not ci then return nil end
    local cur = h[ci]
    local limit = cur.t - seconds
    local ref = nil
    for i = ci - 1, 1, -1 do
        if Usable(h[i]) and h[i].t <= limit then
            ref = h[i]
            break
        end
    end
    if not ref or ref.p <= 0 then return nil end
    return (cur.p - ref.p) / ref.p * 100
end

-- Median einer Zahlenliste (die Liste wird dabei sortiert)
local function Median(values)
    local n = #values
    if n == 0 then return nil end
    table.sort(values)
    if n % 2 == 1 then return values[(n + 1) / 2] end
    return (values[n / 2] + values[n / 2 + 1]) / 2
end
A.Median = Median

-- Durchschnitt, Median und Min/Max im Zeitraum. seconds = nil -> alles
function A:GetStats(itemID, seconds)
    local h = self:GetHistory(itemID)
    if #h == 0 then return nil end
    local limit = seconds and (time() - seconds) or 0
    local sum, n, minP, maxP = 0, 0, nil, nil
    local values = {}
    for _, e in ipairs(h) do
        if e.t >= limit and Usable(e) then
            sum = sum + e.p
            n = n + 1
            values[n] = e.p
            if not minP or e.p < minP then minP = e.p end
            if not maxP or e.p > maxP then maxP = e.p end
        end
    end
    if n == 0 then return nil end
    return { avg = sum / n, median = Median(values), min = minP, max = maxP, count = n }
end

-- ------------------------------------------------------------
-- Marktwert: Median der Preise der letzten 14 Tage.
-- Der Median ist robust: ein einzelnes Wucher- oder Lockangebot
-- verschiebt ihn kaum (ein Durchschnitt dagegen stark).
-- Gibt es weniger als 3 Preise in 14 Tagen, zählen die letzten 3.
-- ------------------------------------------------------------
local marketCache = {}

function A:InvalidateMarket(itemID)
    if itemID then marketCache[itemID] = nil end
end

function A:GetMarketValue(itemID)
    local h = self:GetHistory(itemID)
    local n = #h
    if n == 0 then return nil end
    local first, last = h[1], h[n]
    local c = marketCache[itemID]
    if c and c.n == n and c.last == last.t and c.first == first.t and c.hour == math.floor(time() / 3600) then
        return c.v
    end
    local limit = time() - self.MARKET_DAYS * 86400
    local values = {}
    for i = n, 1, -1 do
        if h[i].t < limit then break end
        if Usable(h[i]) then values[#values + 1] = h[i].p end
    end
    if #values < 3 then
        values = {}
        for i = n, 1, -1 do
            if Usable(h[i]) then values[#values + 1] = h[i].p end
            if #values >= 3 then break end
        end
    end
    if #values == 0 then
        marketCache[itemID] = { n = n, last = last.t, first = first.t, hour = math.floor(time() / 3600), v = nil }
        return nil
    end
    local v = Median(values)
    if v then v = math.floor(v + 0.5) end
    marketCache[itemID] = { n = n, last = last.t, first = first.t, hour = math.floor(time() / 3600), v = v }
    return v
end

-- ------------------------------------------------------------
-- Lockangebote bei Waren: ganz unten Angebote über genau 1 Stück.
-- Sie zählen nirgends für Preise, Statistik, Sniper oder Vorschläge.
-- ------------------------------------------------------------
A.BAIT_FACTOR = 0.7     -- Scan-Preis unter 70 % des Marktwerts -> nachprüfen

-- Waren (stapelbar) oder Einzelstück?
function A:IsCommodityItem(itemID)
    if not (GetItemInfo and itemID) then return false end
    local stack = select(8, GetItemInfo(itemID))
    return (stack or 1) > 1
end

-- Angebote (aufsteigend nach Preis): führende fremde 1-Stück-Angebote als Lockangebot markieren
function A:MarkBait(listings)
    local n = 0
    for _, l in ipairs(listings) do
        if l.qty == 1 and not l.own and n < 5 then l.bait = true; n = n + 1 else break end
    end
    return n
end

-- Angebotsliste ohne Lockangebote (1 Stück ganz unten) - für die Anzeige
function A:NoBait(listings)
    local out = {}
    for _, l in ipairs(listings or {}) do if not l.bait then table.insert(out, l) end end
    return out
end

-- erstes echtes (fremdes, kein Lockangebot) Angebot
function A:FirstReal(listings)
    for _, l in ipairs(listings) do
        if not l.bait and not l.own then return l end
    end
    return nil
end

-- Preis nachgeprüft (Einzelsuche): den unbestätigten Scan-Eintrag korrigieren, sonst neu eintragen
function A:VerifyPrice(itemID, price, quantity)
    local h = self:GetHistory(itemID)
    local now = time()
    for i = #h, 1, -1 do
        local e = h[i]
        if now - e.t > 1800 then break end
        if e.u then
            e.p, e.q, e.u, e.v = price, quantity or e.q, nil, 1
            self:InvalidateMarket(itemID)
            return true
        end
    end
    return self:RecordPrice(itemID, price, quantity, now)
end

-- verdächtig billig (nur Waren)?
function A:IsSuspicious(itemID, price)
    if not self:IsCommodityItem(itemID) then return false end
    local mv = self:GetMarketValue(itemID)
    return mv ~= nil and price < mv * self.BAIT_FACTOR
end

-- ------------------------------------------------------------
-- Zeitbasierte EMAs (exponentiell geglättet über eine Zeitspanne, nicht über
-- eine Anzahl Punkte - die Scans kommen unregelmäßig). Nur bestätigte Preise.
-- ------------------------------------------------------------
A.EMA = {
    { key = "6h", tau = 6 * 3600, label = "EMA 6 Std.", color = { 0.40, 0.75, 1.00 } },
    { key = "1d", tau = 86400, label = "EMA 1 Tag", color = { 1.00, 0.60, 0.20 } },
    { key = "7d", tau = 7 * 86400, label = "EMA 7 Tage", color = { 0.78, 0.45, 1.00 } },
}
A.EMA_MIN_POINTS = 10

function A:GetEMASeries(itemID, tau)
    local out, ema, lastT = {}, nil, nil
    for _, e in ipairs(self:GetHistory(itemID)) do
        if Usable(e) then
            if not ema then
                ema = e.p
            else
                local dt = math.max(0, e.t - lastT)
                ema = ema + (1 - math.exp(-dt / tau)) * (e.p - ema)
            end
            lastT = e.t
            out[#out + 1] = { t = e.t, v = ema }
        end
    end
    return out
end

function A:GetEMA(itemID, tau)
    local s = self:GetEMASeries(itemID, tau)
    if #s < self.EMA_MIN_POINTS then return nil end
    return s[#s].v
end

-- Kreuzungen der schnellen über/unter die langsame EMA: { {t, v, up = true/false}, ... }
function A:GetEMACrossings(itemID, fastTau, slowTau)
    local f, s = self:GetEMASeries(itemID, fastTau), self:GetEMASeries(itemID, slowTau)
    local out = {}
    if #f < self.EMA_MIN_POINTS then return out end
    local prev
    for i = 2, #f do
        local d = f[i].v - s[i].v
        if prev and d ~= 0 and (prev > 0) ~= (d > 0) then
            table.insert(out, { t = f[i].t, v = s[i].v, up = d > 0 })
        end
        if d ~= 0 then prev = d end
    end
    return out
end

-- Preis im Verhältnis zum Marktwert in Prozent (100 = üblicher Preis)
function A:GetMarketPercent(itemID, price)
    price = price or self:GetCurrent(itemID)
    local mv = self:GetMarketValue(itemID)
    if not price or not mv or mv <= 0 then return nil end
    return price / mv * 100
end

-- Prozent vom Marktwert farbig: grün = günstig, weiß = normal, orange/rot = teuer
function A:FormatMarketPercent(pct)
    if not pct then return "|cff666666-|r" end
    local color
    if pct <= 80 then color = "33dd55"
    elseif pct < 95 then color = "aadd88"
    elseif pct <= 110 then color = "dddddd"
    elseif pct <= 130 then color = "ffaa33"
    else color = "ff5544" end
    return string.format("|cff%s%d%%|r", color, math.floor(pct + 0.5))
end

-- ------------------------------------------------------------
-- Händlerpreis (Verkauf an einen NPC-Händler) pro Stück in Kupfer.
-- nil = noch unbekannt (Client kennt das Item noch nicht), 0 = nicht verkaufbar.
-- Einmal bekannt, bleibt er gespeichert.
-- ------------------------------------------------------------
function A:GetVendorPrice(itemID)
    local db = self.db
    local known = db and db.vendorPrices[itemID]
    if known then return known end
    if not GetItemInfo or not itemID then return nil end
    local info = { pcall(GetItemInfo, itemID) }
    if info[1] and info[2] and type(info[12]) == "number" then
        if db then db.vendorPrices[itemID] = info[12] end
        return info[12]
    end
    return nil
end

-- ------------------------------------------------------------
-- Händler-Einkaufspreis: was ein Händler pro Stück VERLANGT.
-- Wird automatisch gelesen, sobald du ein Händlerfenster öffnest.
-- ------------------------------------------------------------
function A:GetVendorBuyPrice(itemID)
    return self.db and itemID and self.db.vendorBuy[itemID] or nil
end

function A:ScanMerchant()
    if not (self.db and GetMerchantNumItems and GetMerchantItemInfo) then return 0 end
    local n, found = GetMerchantNumItems() or 0, 0
    for i = 1, n do
        local ok, name, _, price, quantity, numAvailable, _, _, extendedCost = pcall(GetMerchantItemInfo, i)
        local link = GetMerchantItemLink and GetMerchantItemLink(i)
        local id = link and tonumber(link:match("item:(%d+)"))
        -- nur Gold-Preise (keine Marken/Abzeichen), nur unbegrenzt verfügbare Waren
        if ok and id and price and price > 0 and not extendedCost and (numAvailable == nil or numAvailable < 0) then
            local unit = math.max(1, math.floor(price / math.max(1, quantity or 1) + 0.5))
            local old = self.db.vendorBuy[id]
            if not old or unit < old then self.db.vendorBuy[id] = unit end
            found = found + 1
        end
    end
    if found > 0 then self:Fire("DATA_CHANGED") end
    return found
end

-- Items, die im Auktionshaus gerade billiger sind als beim Händler.
-- Nur aktuelle Preise (letzte 2 Std.), damit keine alten Angebote auftauchen.
function A:FindVendorDeals()
    local out = {}
    if not self.db then return out end
    local fresh = time() - self.FRESH_SECONDS
    for itemID in pairs(self.db.marketData) do
        self:Pause()
        local price, qty, t = self:GetCurrent(itemID)
        if price and t and t >= fresh then
            local vendor = self:GetVendorPrice(itemID)
            if vendor and vendor > price then
                table.insert(out, {
                    itemID = itemID, name = self:GetItemName(itemID),
                    price = price, vendor = vendor, quantity = qty or 0,
                    profit = vendor - price, pct = (vendor - price) / vendor * 100,
                })
            end
        end
    end
    return out
end

-- Alle Items als Liste mit Kennzahlen (für Tabellen)
function A:BuildItemList(filterText)
    local list = {}
    if not self.db then return list end
    local pq = self.Names and self.Names:PrepareQuery(filterText) or nil
    for itemID in pairs(self.db.marketData) do
        self:Pause()
        local name = self:GetItemName(itemID)
        if not pq or self.Names:Matches(itemID, pq) then
            local price, qty, t = self:GetCurrent(itemID)
            if price then
                table.insert(list, {
                    itemID = itemID,
                    name = name,
                    price = price,
                    quantity = qty or 0,
                    seen = t,
                    change = self:GetChangeSinceLastScan(itemID),
                    day = self:GetTrend(itemID, 86400),
                    week = self:GetTrend(itemID, 7 * 86400),
                    month = self:GetTrend(itemID, 30 * 86400),
                    points = #self:GetHistory(itemID),
                    market = self:GetMarketValue(itemID),
                    pct = self:GetMarketPercent(itemID, price),
                    vendor = self:GetVendorPrice(itemID),
                })
            end
        end
    end
    return list
end

-- ------------------------------------------------------------
-- Auktionshaus-Schnittstelle (abgesichert für Custom-Clients)
-- ------------------------------------------------------------
A.ahOpen = false

function A:IsAHOpen()
    -- Ereignisse (AUCTION_HOUSE_SHOW/CLOSED bzw. Öffnen/Schließen des Fensters) sind maßgeblich
    if self.ahOpen then return true end
    -- Rückfall, falls kein Ereignis kam: Auktionshaus-Fenster sichtbar
    -- (direkt nach dem Schließen ist es oft noch kurz sichtbar -> 1 Sek. ignorieren)
    local ah = (type(AuctionHouseFrame) == "table" and AuctionHouseFrame) or (type(AuctionFrame) == "table" and AuctionFrame)
    if ah and ah.IsShown and ah:IsShown() then
        return not self.ahClosedAt or (GetTime() - self.ahClosedAt) > 1
    end
    return false
end


function A:CheckAPI()
    local C = A.AH
    self.api = {
        C_AuctionHouse = C ~= nil,
        SendBrowseQuery = C ~= nil and C.SendBrowseQuery ~= nil,
        GetBrowseResults = C ~= nil and C.GetBrowseResults ~= nil,
        HasFullBrowseResults = C ~= nil and C.HasFullBrowseResults ~= nil,
        RequestMoreBrowseResults = C ~= nil and C.RequestMoreBrowseResults ~= nil,
        GetNumBrowseResults = C ~= nil and C.GetNumBrowseResults ~= nil,
    }
    return self.api
end

-- nur die Anzahl (billig) - die ganze Liste wird erst am Ende einmal abgeholt
local function SafeCountResults()
    if A.AH and A.AH.GetNumBrowseResults then
        local ok, n = pcall(A.AH.GetNumBrowseResults)
        if ok and type(n) == "number" then return n end
    end
    if not (A.AH and A.AH.GetBrowseResults) then return 0 end
    local ok, results = pcall(A.AH.GetBrowseResults)
    return (ok and type(results) == "table") and #results or 0
end

local function SafeGetResults()
    if not (A.AH and A.AH.GetBrowseResults) then return {} end
    local ok, results = pcall(A.AH.GetBrowseResults)
    if ok and type(results) == "table" then return results end
    return {}
end

local function SafeHasFull()
    if not (A.AH and A.AH.HasFullBrowseResults) then return nil end
    local ok, full = pcall(A.AH.HasFullBrowseResults)
    if ok then return full end
    return nil
end

local function SafeRequestMore()
    if not (A.AH and A.AH.RequestMoreBrowseResults) then return false end
    return (pcall(A.AH.RequestMoreBrowseResults))
end

-- ------------------------------------------------------------
-- Cooldown (15 Minuten, gespeichert mit time(), übersteht /reload und Neustart)
-- ------------------------------------------------------------
function A:GetCooldownRemaining()
    if not self.db then return 0 end
    local remaining = self.SCAN_COOLDOWN - (time() - (self.db.lastScanTime or 0))
    if remaining < 0 then remaining = 0 end
    return remaining
end

function A:IsScanReady()
    return self:GetCooldownRemaining() <= 0
end

-- ------------------------------------------------------------
-- Anfrage-Drossel des Servers: "bereit" für die nächste Anfrage?
-- (gibt es den Client-Aufruf nicht, gilt immer "bereit")
-- ------------------------------------------------------------
function A:QueryReady()
    local C = A.AH
    if C and C.IsThrottledMessageSystemReady then
        local ok, ready = pcall(C.IsThrottledMessageSystemReady)
        if ok then return ready and true or false end
    end
    return true
end

-- ------------------------------------------------------------
-- Gemeinsames Tempo für alle Suchen (Sniper, Wächter, Einkauf, Verkaufen):
-- immer an die Grenze, die der Server zulässt - und zwar selbst anpassend:
-- * Server meldet seine Drossel (modernes AH, Classic: CanSendAuctionQuery)
--   -> kein eigener Abstand, gesucht wird, sobald der Server "bereit" sagt
-- * sonst: Abstand wird nach jeder Antwort ein Stück kleiner (tastet sich an die
--   Grenze heran) und bei verworfenen Anfragen/Fehlern verdoppelt
-- So läuft es in jeder WoW-Version so schnell, wie der jeweilige Server es erlaubt.
-- ------------------------------------------------------------
local pace = { last = -100, errors = 0, answers = 0 }
A.pace = pace
A.GAP_MIN_THROTTLED = 0      -- Server sagt selbst, wann er bereit ist
A.GAP_MIN_FIXED = 0.2        -- ohne Drossel-Meldung: so knapp darf es höchstens werden
A.GAP_START_FIXED = 1.0      -- Startwert ohne Drossel-Meldung
A.GAP_MAX = 8                -- mehr Bremse gibt es nicht
A.GAP_SHRINK = 0.85          -- nach jeder Antwort: Abstand x 0,85
A.GAP_GROW = 2               -- nach einem Fehler: Abstand x 2

function A:HasThrottleAPI()
    return A.AH ~= nil and A.AH.IsThrottledMessageSystemReady ~= nil
end

local function MinGap()
    return A:HasThrottleAPI() and A.GAP_MIN_THROTTLED or A.GAP_MIN_FIXED
end

function A:QueryGap()
    if not pace.gap then pace.gap = self:HasThrottleAPI() and self.GAP_MIN_THROTTLED or self.GAP_START_FIXED end
    return pace.gap
end

function A:CanQueryNow()
    return GetTime() - pace.last >= self:QueryGap() and self:QueryReady()
end

function A:NoteQuery() pace.last = GetTime() end

-- Server hat eine Anfrage verworfen oder gemeckert: langsamer
function A:QueryError()
    pace.errors = pace.errors + 1
    local g = self:QueryGap()
    pace.gap = math.min(self.GAP_MAX, math.max(g * self.GAP_GROW, 0.3))
end

-- Antwort kam: wieder ein Stück schneller, bis zur Grenze
function A:QueryAnswered()
    pace.answers = pace.answers + 1
    local g = self:QueryGap() * self.GAP_SHRINK
    local min = MinGap()
    if g < min + 0.02 then g = min end
    pace.gap = g
end

function A:GetSpeedText()
    return string.format(L["Tempo: %s, Abstand %.2f Sek. (passt sich an), Antworten %d, Fehler %d"],
        self:HasThrottleAPI() and L["Server-Drossel"] or L["selbst ermittelt"], self:QueryGap(), pace.answers, pace.errors)
end

-- ------------------------------------------------------------
-- Vollständiger Markt-Scan
-- Seiten werden nachgeladen, sobald der Server "Ergebnisse da" meldet
-- (und die Drossel bereit ist) - ohne feste Wartezeiten. Zur Sicherheit
-- gibt es weiterhin den Rückfall "Anzahl ändert sich nicht mehr".
-- ------------------------------------------------------------
local scan = { running = false }
A.scanState = scan
A.SCAN_MAX_PAGES = 400

-- läuft der Scan noch (oder wird er gerade ausgewertet)?
function A:IsScanning()
    return scan.running or scan.processing or false
end

function A:StartFullScan()
    if not self.db then
        self:Print(L["Datenbank ist noch nicht bereit. Bitte kurz warten."])
        return false
    end
    if self:IsScanning() then
        self:Print(L["Es läuft bereits ein Scan."])
        return false
    end
    if not self:IsAHOpen() then
        self:Print(L["Bitte zuerst das Auktionshaus öffnen."])
        return false
    end
    if not (A.AH and A.AH.SendBrowseQuery) then
        self:Print(L["Dein Client unterstützt die Auktionshaus-Suche nicht (SendBrowseQuery fehlt)."])
        return false
    end
    if not self:IsScanReady() then
        self:Print(L["Scan noch gesperrt (Server-Limit). Wieder möglich in "] .. self:FormatDuration(self:GetCooldownRemaining()) .. L[" Min."])
        return false
    end

    local ok, err = pcall(A.AH.SendBrowseQuery, {
        searchString = "",
        minLevel = 0,
        maxLevel = 0,
        filters = {},
        sorts = {},
    })
    if not ok then
        self:Print(L["Scan konnte nicht gestartet werden: "] .. tostring(err))
        return false
    end

    scan.running = true
    scan.startedAt = GetTime()
    scan.lastCount = -1
    scan.lastChange = GetTime()
    scan.pages = 0
    scan.waitingMore = false
    scan.dirty = false

    self.db.lastScanTime = time()
    self:Print(L["Scan gestartet ..."])
    self:Fire("SCAN_STARTED")

    scan.ticker = C_Timer.NewTicker(0.1, function()
        local okPoll, errPoll = pcall(A.PollScan, A)
        if not okPoll then
            A:Print(L["Fehler während des Scans: "] .. tostring(errPoll))
            A:FinishScan(false)
        end
    end)
    return true
end

-- Server meldet neue Ergebnisse
A:On("QUERY_READY", function() if scan.running then pcall(A.PollScan, A) end end)

function A:OnBrowseResults(added)
    if scan.running then
        scan.dirty = true
        if added then scan.waitingMore = false end
    end
end

function A:PollScan()
    if not scan.running then return end
    local now = GetTime()
    local count = SafeCountResults()          -- nur zählen: die ganze Liste abzuholen kostet viel
    local elapsed = now - scan.startedAt

    if count ~= scan.lastCount then
        scan.lastCount = count
        scan.lastChange = now
        scan.waitingMore = false
        self:Fire("SCAN_PROGRESS", count, elapsed)
    end
    local full = SafeHasFull()

    -- 1) Client meldet: alles geladen
    if full == true and count > 0 then
        self:FinishScan(true)
        return
    end

    -- 2) weitere Seite anfordern, sobald möglich
    if count > 0 and full == false and not scan.waitingMore and scan.pages < self.SCAN_MAX_PAGES and self:QueryReady() then
        if SafeRequestMore() then
            scan.pages = scan.pages + 1
            scan.waitingMore = true
            scan.requestedAt = now
            return
        end
    end

    -- 3) Rückfall: Anzahl ändert sich länger nicht mehr
    local still = now - scan.lastChange
    if count > 0 and still >= 2 then
        if scan.waitingMore and still < 4 then return end
        if full ~= false or scan.pages >= self.SCAN_MAX_PAGES or still >= 4 then
            self:FinishScan(true)
            return
        end
    end

    -- 4) Sicherheits-Timeout
    if elapsed > (A.AH_LEGACY and 900 or 120) then
        self:FinishScan(count > 0)
    end
end

function A:FinishScan(success)
    if not scan.running then return end
    scan.running = false
    if scan.ticker then
        scan.ticker:Cancel()
        scan.ticker = nil
    end

    if not success then
        self:Print(L["Scan ohne Ergebnis beendet."])
        self:Fire("SCAN_FAILED")
        return
    end

    -- Ergebnisse jetzt einmal abholen (danach darf das Auktionshaus auch zu sein),
    -- ausgewertet wird in Portionen über mehrere Frames - das Spiel ruckelt nicht
    local results = SafeGetResults()
    scan.processing = true
    scan.duration = GetTime() - scan.startedAt
    self:Job("scan", function() A:ProcessScan(results) end)
end

function A:ProcessScan(results)
    local now = time()
    local best = {}   -- pro Item den günstigsten Preis und die Gesamtmenge

    for i, r in ipairs(results) do
        local itemID = (type(r.itemKey) == "table" and r.itemKey.itemID) or r.itemID
        local price = r.minPrice or r.buyoutPrice
        if itemID and price and price > 0 then
            local qty = r.totalQuantity or r.quantity or 0
            local b = best[itemID]
            if not b then
                best[itemID] = { price = price, qty = qty }
            else
                if price < b.price then b.price = price end
                b.qty = b.qty + qty
            end
        end
        if i % 50 == 0 then self:Pause() end
    end

    -- verdächtig billige Waren (mögliche Lockangebote): unbestätigt speichern und nachprüfen
    local suspicious = {}
    local itemCount = 0
    for itemID, b in pairs(best) do
        if self:IsSuspicious(itemID, b.price) then
            b.u = true
            local mv = self:GetMarketValue(itemID)
            table.insert(suspicious, { itemID = itemID, ratio = b.price / mv })
        end
        self:RecordPrice(itemID, b.price, b.qty, now, false, b.u)
        itemCount = itemCount + 1
        self:Pause()
    end

    local duration = scan.duration or 0
    self.db.totalScans = (self.db.totalScans or 0) + 1
    table.insert(self.db.scanLog, { t = now, items = itemCount, entries = #results, duration = duration, pages = scan.pages })
    while #self.db.scanLog > 50 do table.remove(self.db.scanLog, 1) end

    -- eigenen Scan merken (für Mitspieler, die später online kommen)
    self.db.lastOwnScan = { t = now, data = best }
    scan.processing = false

    self:Print(string.format(L["Scan fertig: %d Einträge, %d verschiedene Items (%.1f Sek.)."], #results, itemCount, duration))
    -- Nachprüfung: die auffälligsten zuerst, höchstens 60
    if #suspicious > 0 and self.Seller then
        table.sort(suspicious, function(x, y) return x.ratio < y.ratio end)
        local n = math.min(#suspicious, 60)
        for k = 1, n do self.Seller:CheckPrice(suspicious[k].itemID) end
        self:Print(string.format(L["%d auffällig billige Waren werden nachgeprüft (Lockangebote zählen nicht)."], n))
    end
    local deals = self:FindVendorDeals()
    self.vendorDeals = deals
    if #deals > 0 then
        self:Print(string.format(L["|cff33dd55%d Items unter Händlerpreis|r - sicherer Gewinn, siehe Tab Profit"], #deals))
    end
    self:Fire("SCAN_FINISHED", itemCount, best, now)
    self:Fire("DATA_CHANGED")

    if self.Watchlist and self.Watchlist.CheckAlerts then
        self.Watchlist:CheckAlerts(true)
    end
end

function A:ResetScanState()
    if scan.ticker then scan.ticker:Cancel() end
    scan.ticker = nil
    scan.running = false
    scan.processing = false
    self:Print(L["Scan-Status zurückgesetzt."])
    self:Fire("SCAN_FAILED")
end

-- ------------------------------------------------------------
-- CSV-Export
-- ------------------------------------------------------------
function A:BuildCSV()
    local lines = { "ItemID;Name;Preis_Kupfer;Preis_Gold;Menge;Aenderung_Scan_%;Trend_24h_%;Trend_7T_%;Trend_30T_%;Zuletzt_gesehen;Marktwert_Kupfer;Prozent_vom_Marktwert;Haendlerpreis_Kupfer" }
    local list = self:BuildItemList()
    table.sort(list, function(a, b) return a.name < b.name end)
    local function pct(v) return v and string.format("%.2f", v) or "" end
    for _, it in ipairs(list) do
        table.insert(lines, string.format("%d;%s;%d;%.2f;%d;%s;%s;%s;%s;%s;%s;%s;%s",
            it.itemID, (it.name:gsub(";", ",")), it.price, it.price / 10000, it.quantity,
            pct(it.change), pct(it.day), pct(it.week), pct(it.month),
            it.seen and date("%Y-%m-%d %H:%M", it.seen) or "",
            it.market and tostring(it.market) or "", pct(it.pct), it.vendor and tostring(it.vendor) or ""))
    end
    return table.concat(lines, "\n"), #list
end

function A:ExportCSV()
    local text, count = self:BuildCSV()
    if count == 0 then
        self:Print(L["Noch keine Daten zum Exportieren. Erst einen Scan machen."])
        return
    end
    if self.UI and self.UI.ShowTextWindow then
        self.UI:ShowTextWindow(L["CSV-Export ("] .. count .. L[" Items)  -  Strg+A, Strg+C zum Kopieren"], text)
    else
        self:Print(L["Export-Fenster nicht verfügbar."])
    end
end

-- ------------------------------------------------------------
-- Diagnose
-- ------------------------------------------------------------
function A:PrintDebug()
    self:Print(L["Version "] .. self.version .. L["  |  Interface "] .. tostring(select(4, GetBuildInfo())))
    if not self.db then
        self:Print(L["Datenbank: NICHT geladen"])
        return
    end
    self:Print(L["Items in Datenbank: "] .. self:CountTable(self.db.marketData) .. L["  |  Scans gesamt: "] .. (self.db.totalScans or 0))
    self:Print(L["Letzter Scan: "] .. self:FormatAgo(self.db.lastScanTime) .. L["  |  Nächster Scan: "] ..
        (self:IsScanReady() and L["jetzt möglich"] or (L["in "] .. self:FormatDuration(self:GetCooldownRemaining()))))
    self:Print(L["Auktionshaus offen: "] .. tostring(self:IsAHOpen()) .. L["  |  Scan läuft: "] .. tostring(scan.running))
    local api = self:CheckAPI()
    local parts = {}
    for _, key in ipairs({ "C_AuctionHouse", "SendBrowseQuery", "GetBrowseResults", "HasFullBrowseResults", "RequestMoreBrowseResults", "GetNumBrowseResults" }) do
        table.insert(parts, key .. "=" .. (api[key] and L["|cff33dd55ja|r"] or L["|cffff5544nein|r"]))
    end
    self:Print(L["API: "] .. table.concat(parts, ", ") .. (A.AH_LEGACY and L[" (klassisches Auktionshaus)"] or ""))
    if self.UI and self.UI.GetTabDebug then
        self:Print(L["Tabs: "] .. self.UI:GetTabDebug())
    end
    self:Print(L["Button vorhanden: "] .. tostring(self.FloatingButton ~= nil and self.FloatingButton:IsShown()))
    if self.Sync and self.Sync.GetDebugText then
        self:Print(L["Sync: "] .. self.Sync:GetDebugText())
    end
    if self.Names then
        self:Print(L["Namen: "] .. self.Names:GetDebugText())
    end
    if self.Tooltip then
        self:Print("Tooltip: " .. self.Tooltip:GetDebugText())
    end
    if self.Sniper and self.Sniper.GetDebugText then
        self:Print(L["Sniper: "] .. self.Sniper:GetDebugText())
    end
    if self.Seller and self.Seller.GetDebugText then
        self:Print(L["Verkaufen: "] .. self.Seller:GetDebugText())
    end
    if self.Ledger and self.Ledger.GetDebugText then
        self:Print(L["Buchhaltung: "] .. self.Ledger:GetDebugText())
    end
    if self.Buy and self.Buy.GetDebugText then
        self:Print(L["Einkauf: "] .. self.Buy:GetDebugText())
    end
    if self.Watcher and self.Watcher.GetDebugText then
        self:Print(L["Wächter: "] .. self.Watcher:GetDebugText())
    end
    self:Print(self:GetSpeedText())
end

-- Auktionshaus geöffnet/geschlossen (aus Ereignis oder vom Fenster selbst)
function A:SetAHOpenState(open)
    open = open and true or false
    if self.ahOpen == open then return end
    self.ahOpen = open
    if not open then
        self.ahClosedAt = GetTime()
        if scan.running then
            self:FinishScan(SafeCountResults() > 0)
        end
    end
    self:Fire("AH_STATE")
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
local eventFrame = CreateFrame("Frame")

local function SafeRegister(event)
    return A:RegisterAHEvent(eventFrame, event)
end

SafeRegister("ADDON_LOADED")
SafeRegister("PLAYER_LOGIN")
SafeRegister("AUCTION_HOUSE_SHOW")
SafeRegister("AUCTION_HOUSE_CLOSED")
SafeRegister("MERCHANT_SHOW")
SafeRegister("AUCTION_HOUSE_BROWSE_RESULTS_UPDATED")
SafeRegister("AUCTION_HOUSE_BROWSE_RESULTS_ADDED")
SafeRegister("MERCHANT_UPDATE")
SafeRegister("COMMODITY_SEARCH_RESULTS_UPDATED")
SafeRegister("ITEM_SEARCH_RESULTS_UPDATED")
SafeRegister("AUCTION_HOUSE_THROTTLED_SYSTEM_READY")
SafeRegister("AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED")
SafeRegister("AUCTION_HOUSE_SHOW_ERROR")

eventFrame:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" and arg1 == A.ADDON_NAME then
        A:InitDB()
        A:CheckAPI()
    elseif event == "PLAYER_LOGIN" then
        if not A.db then A:InitDB() end
        A:Fire("READY")
        A:Print(L["Version "] .. A.version .. L[" geladen. Öffnen über den Münz-Button oder /ahp"] .. "  |cffaaaaaa(" .. L["/ahp help = alle Befehle"] .. ")|r")
    elseif event == "AUCTION_HOUSE_SHOW" then
        A:SetAHOpenState(true)
    elseif event == "AUCTION_HOUSE_CLOSED" then
        A:SetAHOpenState(false)
    elseif event == "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED" or event == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED" then
        A:QueryAnswered()
        A:OnBrowseResults(event == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED")
        A:Fire("BROWSE_RESULTS", event == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED")
    elseif event == "COMMODITY_SEARCH_RESULTS_UPDATED" or event == "ITEM_SEARCH_RESULTS_UPDATED" then
        A:QueryAnswered()
        A:Fire("SEARCH_RESULTS", arg1)
    elseif event == "AUCTION_HOUSE_THROTTLED_SYSTEM_READY" then
        A:Fire("QUERY_READY")
    elseif event == "AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED" then
        A:QueryError()
    elseif event == "AUCTION_HOUSE_SHOW_ERROR" then
        -- nur als Bremse werten, wenn gerade eine Suche lief
        if GetTime() - pace.last < 3 then A:QueryError() end
    elseif event == "MERCHANT_SHOW" or event == "MERCHANT_UPDATE" then
        -- kurz warten, bis der Händler seine Liste geladen hat
        C_Timer.After(0.3, function() pcall(A.ScanMerchant, A) end)
    end
end)

-- ------------------------------------------------------------
-- Chat-Befehle (alles ist auch per Maus bedienbar)
-- ------------------------------------------------------------
-- Befehlsliste für den Chat (/ahp help): Befehl auf Deutsch / Englisch, Beschreibung
A.COMMANDS = {
    { "", "", "Fenster öffnen / schließen" },
    { "scan", "scan", "Komplett-Scan des Marktes starten" },
    { "sniper", "sniper", "Sniper-Modus an / aus" },
    { "listen", "lists", "Einkaufslisten" },
    { "optionen", "options", "Optionen" },
    { "bilanz", "summary", "Tagesbilanz im Chat" },
    { "twinks", "alts", "Regeln für die Post an Twinks" },
    { "sync", "sync", "Preise mit Mitspielern teilen an / aus" },
    { "design", "design", "Design wechseln (Klassisch / Modern)" },
    { "sprache", "language", "Sprache des Addons wechseln" },
    { "export", "export", "Alle Preise als CSV (zum Kopieren)" },
    { "spenden", "donate", "Addon unterstützen (PayPal-Link)" },
    { "reset", "reset", "Fenster- und Knopf-Positionen zurücksetzen" },
    { "handbuch", "manual", "Hilfe-Fenster mit Anleitung" },
    { "debug", "debug", "Diagnose (für Fehlermeldungen)" },
    { "hilfe", "help", "Diese Liste" },
}

function A:PrintCommands()
    local german = (self.uiLang or (GetLocale and GetLocale())) == "deDE"
    self:Print("|cffffd100" .. L["Befehle"] .. "|r  (" .. L["auch /ahanalyzer"] .. ")")
    for _, c in ipairs(self.COMMANDS) do
        local word = german and c[1] or c[2]
        local cmd = (word == "") and "/ahp" or ("/ahp " .. word)
        print(string.format("   |cff33dd55%s|r  -  %s", cmd, L[c[3]]))
    end
end

SLASH_AHANALYZERPRO1 = "/ahp"
SLASH_AHANALYZERPRO2 = "/ahanalyzer"
SlashCmdList["AHANALYZERPRO"] = function(msg)
    msg = string.lower(msg or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if msg == "" or msg == "show" then
        if A.UI then A.UI:Toggle() end
    elseif msg == "scan" then
        A:StartFullScan()
    elseif msg == "export" then
        A:ExportCSV()
    elseif msg == "debug" then
        A:PrintDebug()
    elseif msg == "reset" then
        if A.ResetButtonPosition then A:ResetButtonPosition() end
        if A.UI then A.UI:ResetPosition() end
    elseif msg == "resetscan" then
        A:ResetScanState()
    elseif msg == "sync" then
        if A.Sync then A.Sync:Toggle() end
    elseif msg == "ahdebug" then
        if A.UI then A.UI:PrintAHDebug() end
    elseif msg == "ah" then
        if A.UI then A.UI:ForceAH() end
    elseif msg == "sniper" then
        if A.Sniper then A.Sniper:ToggleArmed() end
    elseif msg == "design" then
        if A.UI then A.UI:ToggleTheme() end
    elseif msg == "optionen" or msg == "options" then
        if A.UI then A.UI:ShowOptions() end
    elseif msg == "donate" or msg == "spenden" or msg == "support" then
        if A.UI then A.UI:ShowDonate() end
    elseif msg == "bilanz" or msg == "summary" or msg == "daily" then
        if A.Extras then A.Extras:ShowDailySummary(true) end
    elseif msg == "twinks" or msg == "alts" or msg == "mailrules" then
        if A.UI and A.UI.ShowMailRules then A.UI:ShowMailRules() end
    elseif msg == "sprache" or msg == "language" or msg == "lang" then
        A:CycleUILanguage(1)
        A:Print(L["Sprache des Addons: %s"]:format(A:UILanguageLabel()))
    elseif msg == "listen" or msg == "lists" then
        if A.UI then A.UI:ToggleLists() end
    elseif msg == "hilfe" or msg == "help" or msg == "?" or msg == "befehle" or msg == "commands" then
        A:PrintCommands()
    elseif msg == "handbuch" or msg == "manual" or msg == "anleitung" then
        if A.UI then A.UI:ShowHelp("start") end
    else
        A:Print(string.format(L["Unbekannter Befehl: %s"], msg))
        A:PrintCommands()
    end
end
