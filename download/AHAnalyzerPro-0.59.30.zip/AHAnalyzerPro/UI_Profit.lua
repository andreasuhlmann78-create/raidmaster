-- ============================================================
-- AH Analyzer Pro 5.7 - Tab "Profit"
--   links:  Flipping-Rechner
--   rechts: Schnäppchen - wahlweise
--           * unter dem Marktwert (Median 14 Tage),
--           * unter dem Händlerpreis (kaufen, beim NPC verkaufen = sicherer Gewinn), oder
--           * unter dem Entzauberungswert (kaufen und entzaubern)
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local AH_CUT = 0.05      -- Anteil, den das Auktionshaus beim Verkauf einbehält

local function BuildProfit(parent)
    local p = CreateFrame("Frame", nil, parent)
    p.threshold = 20
    p.mode = "market"     -- "market" oder "vendor"

    -- ---------------- Rechner ----------------
    local calc = CreateFrame("Frame", nil, p)
    calc:SetPoint("TOPLEFT", 0, 0)
    calc:SetSize(300, 500)
    UI:Box(calc, C.panel, C.border)

    local ct = UI:Label(calc, L["Flipping-Rechner"], "GameFontNormalLarge", C.text)
    ct:SetPoint("TOPLEFT", 14, -12)
    local cs = UI:Label(calc, L["Billig kaufen, teurer wieder einstellen.\nPreise pro Stück in Gold, Silber und Kupfer."], "GameFontDisableSmall", C.textDim)
    cs:SetPoint("TOPLEFT", ct, "BOTTOMLEFT", 0, -6)

    local function field(labelText, placeholder, y)
        local l = UI:Label(calc, labelText, "GameFontHighlightSmall", C.textDim)
        l:SetPoint("TOPLEFT", 14, y)
        local e = UI:EditBox(calc, 130, 22, placeholder)
        e:SetPoint("TOPRIGHT", -14, y + 4)
        e:SetScript("OnTextChanged", function() p:Calculate() end)
        e:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
        return e
    end

    -- Preise in Gold / Silber / Kupfer
    local function moneyField(labelText, y)
        local l = UI:Label(calc, labelText, "GameFontHighlightSmall", C.textDim)
        l:SetPoint("TOPLEFT", 14, y)
        local m = UI:MoneyInput(calc, function() p:Calculate() end)
        m:SetPoint("TOPRIGHT", -14, y + 4)
        m:SetOnEnter(function(self) self:ClearFocus() end)
        return m
    end
    p.buyBox = moneyField(L["Einkaufspreis"], -76)
    p.sellBox = moneyField(L["Verkaufspreis"], -106)
    p.qtyBox = field(L["Menge"], "1", -136)
    p.feeBox = field(L["AH-Gebühr in %"], "5", -166)

    local line = calc:CreateTexture(nil, "ARTWORK")
    line:SetColorTexture(unpack(C.border))
    line:SetPoint("TOPLEFT", 14, -200)
    line:SetPoint("TOPRIGHT", -14, -200)
    line:SetHeight(1)

    local function resultRow(labelText, y)
        local l = UI:Label(calc, labelText, "GameFontHighlightSmall", C.textDim)
        l:SetPoint("TOPLEFT", 14, y)
        local v = UI:Label(calc, "-", "GameFontHighlight", C.text)
        v:SetPoint("TOPRIGHT", -14, y)
        v:SetJustifyH("RIGHT")
        return v
    end
    p.rCost = resultRow(L["Einkauf gesamt"], -214)
    p.rGross = resultRow(L["Verkauf brutto"], -238)
    p.rFee = resultRow(L["AH-Gebühr"], -262)
    p.rProfit = resultRow(L["Gewinn"], -292)
    p.rMargin = resultRow(L["Marge"], -316)

    local note = UI:Label(calc, L["Hinweis: Die Einstellgebühr (Deposit) ist nicht\nenthalten. Kaufen und Einstellen machst du\nselbst im Auktionshaus."], "GameFontDisableSmall", C.textDim)
    note:SetPoint("BOTTOMLEFT", 14, 14)

    function p:Calculate()
        local buy = self.buyBox:GetCopper()
        local sell = self.sellBox:GetCopper()
        local qty = tonumber(self.qtyBox:GetText()) or 1
        local feeText = (self.feeBox:GetText() or ""):gsub(",", ".")
        local fee = tonumber(feeText) or 5
        if not buy or not sell or qty <= 0 then
            for _, v in ipairs({ self.rCost, self.rGross, self.rFee, self.rProfit, self.rMargin }) do v:SetText("-") end
            return
        end
        local cost = buy * qty
        local gross = sell * qty
        local feeAmount = gross * fee / 100
        local profit = gross - feeAmount - cost
        self.rCost:SetText(A:FormatMoney(cost))
        self.rGross:SetText(A:FormatMoney(gross))
        self.rFee:SetText(A:FormatMoney(feeAmount))
        self.rProfit:SetText(profit >= 0 and A:FormatMoney(profit) or ("|cffff5544" .. L["Verlust|r "] .. A:FormatMoney(profit)))
        self.rMargin:SetText(A:FormatPercent(cost > 0 and (profit / cost * 100) or nil))
    end

    -- ---------------- Schnäppchen ----------------
    local right = CreateFrame("Frame", nil, p)
    right:SetPoint("TOPLEFT", calc, "TOPRIGHT", 14, 0)
    right:SetPoint("BOTTOMRIGHT", 0, 0)

    local rt = UI:Label(right, L["Schnäppchen"], "GameFontNormalLarge", C.text)
    rt:SetPoint("TOPLEFT", 0, 0)

    -- Umschalter: unter Marktwert / unter Händlerpreis
    p.marketBtn = UI:Button(right, L["Unter Marktwert"], 130, 22, function()
        p.mode = "market"
        p:Refresh()
    end)
    p.marketBtn:SetPoint("LEFT", rt, "RIGHT", 16, 0)
    p.marketBtn.tooltip = L["Items, die gerade deutlich unter ihrem Marktwert (Median 14 Tage) angeboten werden"]
    p.vendorBtn = UI:Button(right, L["Unter Händlerpreis"], 140, 22, function()
        p.mode = "vendor"
        p:Refresh()
    end)
    p.vendorBtn:SetPoint("LEFT", p.marketBtn, "RIGHT", 6, 0)
    p.deBtn = UI:Button(right, L["Unter Entzauberwert"], 150, 22, function()
        p.mode = "de"
        p:Refresh()
    end)
    p.deBtn:SetPoint("LEFT", p.vendorBtn, "RIGHT", 6, 0)
    p.deBtn.tooltip = L["Grüne/blaue/epische Ausrüstung, die billiger ist als ihr Entzauberungswert\n(Ø Ertrag an Staub, Essenzen und Splittern nach AH-Gebühr - Richtwerte)."]
    p.vendorBtn.tooltip = L["Items, die im Auktionshaus billiger sind, als ein Händler dafür zahlt.\nKaufen und beim Händler verkaufen = sicherer Gewinn."]
    p.bidBtn = UI:Button(right, L["Gebote"], 90, 22, function()
        p.mode = "bid"
        p:Refresh()
    end)
    p.bidBtn:SetPoint("LEFT", p.deBtn, "RIGHT", 6, 0)
    p.flipBtn = UI:Button(right, L["Flips"], 70, 22, function()
        p.mode = "flip"
        p:Refresh()
    end)
    p.flipBtn:SetPoint("LEFT", p.bidBtn, "RIGHT", 6, 0)
    p.flipBtn.tooltip = L["Flip-Empfehlungen: Items, die regelmäßig angeboten werden und gerade\ndeutlich unter Marktwert liegen - kaufen und wieder einstellen lohnt sich.\nSterne = Umschlag (wie oft das Item im Auktionshaus ist und verkauft wird)."]
    p.bidBtn.tooltip = L["Auktionen, deren nächstes Gebot weit unter dem Marktwert liegt.\nGesammelt beim Komplett-Scan (klassisches Auktionshaus) und bei jeder Suche im Einkauf.\nKlick auf ein Item: im Einkauf öffnen und dort bieten."]

    p.subtitle = UI:Label(right, "", "GameFontDisableSmall", C.textDim)
    p.subtitle:SetPoint("TOPLEFT", rt, "BOTTOMLEFT", 0, -6)
    p.subtitle:SetWidth(600)

    p.thresholdLabel = UI:Label(right, L["Mindestens unter Marktwert:"], "GameFontHighlightSmall", C.textDim)
    p.thresholdLabel:SetPoint("TOPLEFT", 0, -44)
    p.thresholdButtons = {}
    local prev = p.thresholdLabel
    for _, value in ipairs({ 10, 20, 30, 50 }) do
        local b = UI:Button(right, value .. "%", 50, 22, function()
            p.threshold = value
            p:Refresh()
        end)
        b:SetPoint("LEFT", prev, "RIGHT", 6, 0)
        b.value = value
        table.insert(p.thresholdButtons, b)
        prev = b
    end

    p.table = UI:Table(right, {
        columns = {
            { key = "name", title = L["Item"], width = 180 },
            { key = "price", title = L["Sofortkauf"], width = 105, align = "RIGHT",
              tooltip = L["Günstigster Sofortkaufpreis im Auktionshaus beim letzten Scan"] },
            { key = "ref", title = L["Marktwert"], width = 105, align = "RIGHT" },
            { key = "discount", title = L["darunter"], width = 70, align = "RIGHT" },
            { key = "profit", title = L["Gewinn/Stück"], width = 105, align = "RIGHT" },
        },
        rows = 16,
        rowHeight = 22,
        sortKey = "profit",
        sortAsc = false,
        cell = function(item, key)
            if key == "name" then return item.name end
            if key == "discount" then return string.format("|cff33dd55-%.0f%%|r", item.discount) end
            return A:FormatMoney(item[key])
        end,
        sortValue = function(item, key)
            if key == "name" then return string.lower(item.name) end
            return item[key]
        end,
        onClick = function(item)
            if item.bidDeal then
                -- Gebot: im Einkauf öffnen, dort bieten
                if UI.OpenBuyFor then UI:OpenBuyFor(item.itemID) end
                return
            end
            p.buyBox:SetCopper(item.price)
            p.sellBox:SetCopper(item.ref)
            p.feeBox:SetText((item.vendorDeal or item.deDeal) and "0" or "5")
            p:Calculate()
        end,
        action = {
            text = "+", width = 26,
            tooltip = L["Marktwert: zur Watchlist (Kaufgrenze = aktueller Preis)\nHändlerpreis: als Sniper-Ziel (kauft alles unter dem Händlerpreis)"],
            onClick = function(item)
                if item.deDeal then
                    local maxPrice = math.max(1, item.ref - 1)
                    local _, msg = A.Sniper:SetTarget(tostring(item.itemID), maxPrice, 1, maxPrice)
                    A:Print(msg)
                elseif item.vendorDeal then
                    local qty = math.max(1, math.min(item.quantity or 1, 1000))
                    local maxPrice = item.ref - 1
                    local _, msg = A.Sniper:SetTarget(tostring(item.itemID), maxPrice, qty, maxPrice * qty)
                    A:Print(msg)
                else
                    local _, msg = A.Watchlist:Add(tostring(item.itemID), item.price, math.floor(item.ref))
                    A:Print(msg)
                end
            end,
        },
        emptyText = L["Keine Schnäppchen gefunden.\nDafür braucht es Scans über mehrere Tage."],
    })
    p.table:Fill(0, -76, 0, 4)

    -- Schnäppchen unter dem Marktwert (mind. 3 Preise in den letzten 14 Tagen)
    local function MarketDeals(threshold)
        local out = {}
        local limit = time() - A.MARKET_DAYS * 86400
        for itemID in pairs(A.db.marketData) do
            A:Pause()
            local price = A:GetCurrent(itemID)
            local mv = A:GetMarketValue(itemID)
            if price and mv and mv > 0 then
                local n = 0
                local h = A:GetHistory(itemID)
                for i = #h, 1, -1 do
                    if h[i].t < limit or n >= 3 then break end
                    if not h[i].u then n = n + 1 end
                end
                local discount = (mv - price) / mv * 100
                if n >= 3 and discount >= threshold then
                    table.insert(out, {
                        itemID = itemID, name = A:GetItemName(itemID),
                        price = price, ref = mv, discount = discount,
                        profit = mv * (1 - AH_CUT) - price,
                    })
                end
            end
        end
        return out
    end

    -- Schnäppchen unter dem Händlerpreis (nur aktuelle Preise)
    local function VendorDeals()
        local out = {}
        for _, d in ipairs(A:FindVendorDeals()) do
            table.insert(out, {
                itemID = d.itemID, name = d.name, price = d.price, ref = d.vendor,
                discount = d.pct, profit = d.profit, quantity = d.quantity, vendorDeal = true,
            })
        end
        return out
    end

    -- Schnäppchen unter dem Entzauberungswert (nur aktuelle Preise)
    local function DisenchantDeals()
        local out = {}
        for _, d in ipairs(A.Disenchant:FindDeals()) do
            table.insert(out, {
                itemID = d.itemID, name = d.name, price = d.price, ref = d.net,
                discount = d.pct, profit = d.profit, quantity = d.quantity, deDeal = true,
            })
        end
        return out
    end

    local function mark(b, on, text)
        b:SetText(on and ("> " .. text .. " <") or text)
        -- Breite an den (übersetzten) Text anpassen
        local fs = b.label or (b.GetFontString and b:GetFontString())
        local w = fs and fs.GetStringWidth and fs:GetStringWidth()
        if w and w > 0 then b:SetWidth(math.max(80, math.floor(w + 22))) end
    end

    -- Restzeit eines Gebots (bezogen auf jetzt)
    local function BidTime(e)
        local left = (e.endsBy or 0) - time()
        if left < 1800 then return "|cffff5544" .. L["< 30 Min."] .. "|r" end
        if left < 7200 then return "|cffffcc33" .. L["< 2 Std."] .. "|r" end
        if left < 43200 then return L["< 12 Std."] end
        return L["> 12 Std."]
    end

    local function FlipDeals(threshold)
        local out = A.Extras:GetFlipDeals(threshold)
        for _, d in ipairs(out) do
            d.name = d.name .. "  |cffffd100" .. string.rep("*", d.stars or 1) .. "|r"
        end
        return out
    end

    local function BidDeals(threshold)
        local out = A:GetBidDeals(threshold)
        for _, d in ipairs(out) do
            d.name = d.name .. "  |cffaaaaaa(" .. BidTime(d) .. "|cffaaaaaa)|r"
        end
        return out
    end

    function p:Refresh()
        local mode = self.mode
        local vendor, de, bid, flip = (mode == "vendor"), (mode == "de"), (mode == "bid"), (mode == "flip")
        -- kurze Namen, damit fünf Ansichten in eine Zeile passen (Erklärung im Tooltip)
        mark(self.marketBtn, mode == "market", L["Marktwert"])
        mark(self.vendorBtn, vendor, L["Händlerpreis"])
        mark(self.deBtn, de, L["Entzauberwert"])
        mark(self.bidBtn, bid, L["Gebote"])
        mark(self.flipBtn, flip, L["Flips"])
        -- Vergleichswert-Spalte je nach Modus benennen (über den Schlüssel, nicht die Position)
        for _, hb in ipairs(self.table.headerCells) do
            if hb.col.key == "price" then
                hb.col.title = bid and L["Nächstes Gebot"] or L["Sofortkauf"]
                hb.col.tooltip = bid and L["So viel musst du mindestens bieten (pro Stück)"] or L["Günstigster Sofortkaufpreis im Auktionshaus beim letzten Scan"]
            end
            if hb.col.key == "ref" then
                hb.col.title = (vendor and L["Händlerpreis"]) or (de and L["Entzauberwert"]) or L["Marktwert"]
                hb.col.tooltip = (vendor and L["Was ein Händler für das Item zahlt"])
                    or (de and L["Erwarteter Wert beim Entzaubern"])
                    or L["Marktwert = Median der letzten 14 Tage"]
            end
        end
        for _, b in ipairs(self.thresholdButtons) do
            if mode ~= "market" and mode ~= "bid" and mode ~= "flip" then b:Hide() else b:Show() end
            b.label:SetTextColor(unpack(b.value == self.threshold and C.accent or C.text))
        end
        if vendor then
            self.thresholdLabel:Hide()
            self.subtitle:SetText(L["Im Auktionshaus billiger als beim Händler (Preise der letzten 2 Std.).\n+ = Sniper-Ziel anlegen, das alle diese Angebote kauft."])
        elseif flip then
            self.thresholdLabel:Show()
            self.subtitle:SetText(L["Kaufen und wieder einstellen: regelmäßig angeboten, gerade günstig, Gewinn nach AH-Anteil.\nSterne = Umschlag. Sortiert nach erwartetem Gewinn."])
        elseif bid then
            self.thresholdLabel:Show()
            self.subtitle:SetText(L["Gebote weit unter dem Marktwert (Restzeit in Klammern). Wer bietet, gewinnt erst am Ende der Auktion.\nKlick auf ein Item: im Einkauf öffnen und bieten."])
        elseif de then
            self.thresholdLabel:Hide()
            self.subtitle:SetText(L["Billiger als der Entzauberungswert nach AH-Gebühr (Preise der letzten 2 Std.).\n+ = Sniper-Ziel. Entzauberungswerte sind Richtwerte."])
        else
            self.thresholdLabel:Show()
            self.subtitle:SetText(L["Items, die aktuell deutlich unter ihrem Marktwert liegen (Median 14 Tage, mind. 3 Preise)."])
        end
        local out = {}
        if A.db then
            if vendor then out = VendorDeals() elseif de then out = DisenchantDeals()
            elseif bid then out = BidDeals(self.threshold)
            elseif flip then out = FlipDeals(self.threshold) else out = MarketDeals(self.threshold) end
        end
        self.table:SetData(out, true)
        self:Calculate()
    end

    return p
end

UI:RegisterTab("profit", "Profit", 5, BuildProfit)
