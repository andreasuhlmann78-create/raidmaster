if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.9 - Verkaufen und eigene Auktionen (Logik)
--
-- * Taschen lesen: alle Items, die man im Auktionshaus verkaufen kann
-- * Preis prüfen: aktuelle Angebote eines Items (eine Suche pro Item,
--   nacheinander, nie während Markt-Scan oder Sniper-Suche)
-- * Preisvorschlag: günstigstes fremdes Angebot unterbieten, sonst
--   Marktwert (Median), sonst zuletzt benutzter Preis
-- * Einstellen mit Einstellgebühr, AH-Gebühr und Warnung, wenn ein
--   Händler mehr zahlt
-- * Eigene Auktionen: Status (günstigstes / unterboten / verkauft),
--   Abbrechen - immer nur per Klick (das verlangt WoW selbst)
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
-- Retail 12.x: die alten Item-/Zauber-Funktionen gibt es nur noch in C_Item / C_Spell
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local A = AHAnalyzerPro
local L = A.L

local Se = {}
A.Seller = Se

-- Anteil, den das Auktionshaus vom Verkaufspreis einbehält: A:CutPct() (5 %, neutrales AH 15 %, H3)
local SEARCH_TIMEOUT = 8       -- Sekunden, bis eine Preisprüfung als ergebnislos gilt
local PRICE_FRESH = 300        -- so lange (Sek.) gilt eine Preisprüfung als aktuell
local SORTS = { { sortOrder = 0, reverseSort = false } }

Se.prices = {}                 -- [itemID] = { time, stamp, listings = { {price, qty, own} }, lowestOther, lowestOwn }
Se.queue = {}                  -- Item-IDs, deren Preis noch geprüft werden soll
Se.bgQueue = {}                -- AB1: Hintergrund (Materialpreise MP1) - erst wenn die Hauptliste leer ist
Se.search = nil                -- laufende Preisprüfung
Se.lastSearch = -100
Se.owned = {}                  -- eigene Auktionen
Se.ownedTime = nil
Se.pendingPost = nil
Se.pendingCancel = nil

-- Unterbieten: um 1 Kupfer, 1 % oder 5 %
Se.UNDERCUT = {
    { key = "copper", label = "1 Kupfer" },
    { key = "p1", label = "1 %" },
    { key = "p5", label = "5 %" },
}

local function DB()
    return A.db and A.db.seller
end

local function SafeCall(fn, ...)
    if not fn then return nil end
    local ok, a, b = pcall(fn, ...)
    if ok then return a, b end
    if A.ReportOnce then A:ReportOnce(fn, "SafeCall:Verkaufen", a) end
    return nil
end

local function Now() return GetTime() end

-- ------------------------------------------------------------
-- Dauer der Auktion (1 = kurz, 2 = mittel, 3 = lang).
-- Die Stunden hängen vom Server ab - Blizzards eigene Texte nutzen, wenn vorhanden.
-- ------------------------------------------------------------
function Se:DurationLabel(d)
    local g = ({ AUCTION_DURATION_ONE, AUCTION_DURATION_TWO, AUCTION_DURATION_THREE })[d]
    if type(g) == "string" and g ~= "" then return g end
    return L[({ "Kurz", "Mittel", "Lang" })[d] or "Mittel"]
end

function Se:UndercutLabel(key, itemID)
    -- F2: Einzelstücke nur in ganzen Silber -> "1 Silber" statt "1 Kupfer"
    if (key == nil or key == "copper") and itemID and self:SilverOnly(itemID) then return L["1 Silber"] end
    for _, u in ipairs(self.UNDERCUT) do if u.key == key then return L[u.label] end end
    return L["1 Kupfer"]
end

-- Befund F2 (10.11., gemessen): Einzelstücke (keine Waren) nimmt der Server im modernen Auktionshaus nur in ganzen Silber
-- an (199c -> "Interner Auktion-Fehler" zweimal, 200c -> erstellt, Blizzard und AHSentinel mit gleichem Aufruf).
-- Waren dürfen Kupfer haben (Staub 83c). Altes Auktionshaus (Era/TBC): unverändert.
function Se:SilverOnly(itemID)
    if A.AH_LEGACY or not itemID then return false end
    return not A:IsCommodityItem(itemID)
end

function Se:RoundPrice(itemID, price)
    if not price then return nil end
    price = math.floor(price)
    if not self:SilverOnly(itemID) then return price end
    return math.max(100, math.floor(price / 100) * 100)
end

function Se:CycleUndercut()
    local db = DB()
    local i = 1
    for k, u in ipairs(self.UNDERCUT) do if u.key == db.undercut then i = k end end
    db.undercut = self.UNDERCUT[(i % #self.UNDERCUT) + 1].key
    A:Fire("SELLER_CHANGED")
    return db.undercut
end

-- ------------------------------------------------------------
-- Taschen
-- ------------------------------------------------------------
local function ContainerInfo(bag, slot)
    local CC, GetContainerItemInfo = A:Global("C_Container"), A:Global("GetContainerItemInfo")   -- A:API: ohne Test = Blizzard
    if CC and CC.GetContainerItemInfo then
        local info = SafeCall(CC.GetContainerItemInfo, bag, slot)
        if type(info) == "table" then return info end
        return nil
    end
    -- ältere Clients: viele Rückgabewerte statt einer Tabelle
    if GetContainerItemInfo then
        local ok, tex, count, locked, quality, readable, lootable, link, filtered, noValue, itemID = pcall(GetContainerItemInfo, bag, slot)
        if ok and tex then
            return { stackCount = count, isLocked = locked, quality = quality, hyperlink = link, hasNoValue = noValue, itemID = itemID }
        end
    end
    return nil
end

local function NumSlots(bag)
    local CC, old = A:Global("C_Container"), A:Global("GetContainerNumSlots")
    if CC and CC.GetContainerNumSlots then return SafeCall(CC.GetContainerNumSlots, bag) or 0 end
    if old then return SafeCall(old, bag) or 0 end
    return 0
end

local function MakeLocation(bag, slot)
    if ItemLocation and ItemLocation.CreateFromBagAndSlot then
        return SafeCall(ItemLocation.CreateFromBagAndSlot, ItemLocation, bag, slot)
    end
    return nil
end

local bagCache = nil           -- Taschen-Inhalt bis zur nächsten Änderung

-- Waren (stapelbar, Preis pro Stück) oder Einzelangebot (z.B. Ausrüstung)
function Se:IsCommodity(itemID, loc)
    local C = A.AH
    if loc and C and C.GetItemCommodityStatus and Enum and Enum.ItemCommodityStatus then
        local st = SafeCall(C.GetItemCommodityStatus, loc)
        if st == Enum.ItemCommodityStatus.Commodity then return true end
        if st == Enum.ItemCommodityStatus.Item then return false end
    end
    local stack = select(8, GetItemInfo(itemID))
    return (stack or 1) > 1
end

-- Alle verkaufbaren Items in den Taschen, nach Item zusammengefasst
-- light = true: ohne Preise (schneller, nur zum Zählen)
function Se:GetBagItems(light)
    local byID, list = {}, {}
    local C = A.AH
    for bag = 0, (NUM_BAG_SLOTS or 4) + (NUM_REAGENTBAG_SLOTS or 0) do   -- Retail: auch die Reagenzientasche
        for slot = 1, NumSlots(bag) do
            local info = ContainerInfo(bag, slot)
            local itemID = info and (info.itemID or (info.hyperlink and tonumber(info.hyperlink:match("item:(%d+)"))))
            if itemID and not info.isBound then
                local loc = MakeLocation(bag, slot)
                local valid = true
                -- IsSellItemValid antwortet nur bei offenem Auktionshaus sinnvoll (sonst immer "nein")
                if loc and C and C.IsSellItemValid and A:IsAHOpen() then
                    local ok, v = pcall(C.IsSellItemValid, loc, false)
                    if ok and v == false then valid = false end
                end
                if valid then
                    local e = byID[itemID]
                    if not e then
                        e = { itemID = itemID, name = A:GetItemName(itemID), count = 0, slots = {}, quality = info.quality or 1 }
                        byID[itemID] = e
                        table.insert(list, e)
                    end
                    e.count = e.count + (info.stackCount or 1)
                    table.insert(e.slots, { bag = bag, slot = slot, count = info.stackCount or 1, loc = loc })
                end
            end
        end
    end
    for _, e in ipairs(list) do
        e.commodity = self:IsCommodity(e.itemID, e.slots[1].loc)
    end
    if light then return list end
    bagCache = {}
    for _, e in ipairs(list) do
        bagCache[e.itemID] = e
        e.market = A:GetMarketValue(e.itemID)
        e.vendor = A:GetVendorPrice(e.itemID)
        local pr = self:GetPriceInfo(e.itemID)
        e.lowest = pr and pr.lowestOther or nil
        e.value = (e.market or e.lowest or e.vendor or 0) * e.count
    end
    return list
end

-- Anzahl eines Items in den Taschen (zwischengespeichert bis zur nächsten Taschenänderung)
function Se:InvalidateBags() bagCache = nil end
-- AB2: Taschen-Stand kann veraltet sein (gerade eingestellt, BAG_UPDATE noch nicht da) -> Platz prüfen, sonst neu lesen.
-- Zurück: Menge, Eintrag - oder false, Meldung (dann wird PostItem/PostCommodity NICHT aufgerufen)
function Se:PostSource(itemID)
    local have, entry = self:CountInBags(itemID)
    if not entry then return false, L["Dieses Item ist nicht (mehr) in deinen Taschen."] end
    if not self:LocValid(entry.slots[1] and entry.slots[1].loc, itemID) then
        self:InvalidateBags()
        have, entry = self:CountInBags(itemID)
        if not (entry and self:LocValid(entry.slots[1] and entry.slots[1].loc, itemID)) then
            if A.Diag then pcall(A.Diag.Add, A.Diag, "EINSTELLEN", string.format("Item %d: Platz in der Tasche leer/anders -> nicht aufgerufen (schon eingestellt?)", itemID)) end
            return false, L["Schon eingestellt – nicht mehr in deinen Taschen."]
        end
    end
    return have, entry
end
-- AB2: liegt an diesem Platz wirklich noch dieses Item? (ohne C_Item: nicht prüfbar -> gilt als gültig)
function Se:LocValid(loc, itemID)
    if not loc then return true end                      -- alter AH-Weg ohne ItemLocation: weiter wie bisher
    local CI = _G.C_Item
    if not (CI and CI.DoesItemExist) then return true end
    local okE, exists = pcall(CI.DoesItemExist, loc)
    if not okE then return true end
    if not exists then return false end
    if CI.GetItemID then
        local okI, id = pcall(CI.GetItemID, loc)
        if okI and id and id ~= itemID then return false end
    end
    return true
end

-- EK-1 Korrektur (Supervisor 16:10): "Gewinn erwartet" im Verkaufen-Fenster = Erlös nach Gebühren − erwarteter Verlust der
-- Einstellgebühr − Lager-Einstand der eingestellten Stück (Durchschnitt des Lager-Postens dieser Figur; Stück über dem Posten
-- ohne Einstand). Vorher fehlte der Einstand ganz (Gewinn = Erlös). Zurück: Gewinn, Einstand
function Se:ExpectedProfit(itemID, net, loss, qty)
    local cost = 0
    local BK = A.Books
    if BK and BK.Position and itemID and (qty or 0) > 0 then
        local ok, q, c = pcall(BK.Position, BK, itemID)
        if ok and (q or 0) > 0 and (c or 0) > 0 then cost = math.floor(c * math.min(qty, q) / q + 0.5) end
    end
    return (net or 0) - (loss or 0) - cost, cost
end
function Se:CountInBags(itemID)
    if not bagCache then
        bagCache = {}
        for _, e in ipairs(self:GetBagItems(true)) do bagCache[e.itemID] = e end
    end
    local e = bagCache[itemID]
    if e then return e.count, e end
    return 0, nil
end

-- ------------------------------------------------------------
-- Preisprüfung (aktuelle Angebote eines Items)
-- ------------------------------------------------------------
local function MakeKey(itemID)
    local C = A.AH
    if C and C.MakeItemKey then
        local key = SafeCall(C.MakeItemKey, itemID)
        if key then return key end
    end
    return { itemID = itemID, itemLevel = 0, itemSuffix = 0, battlePetSpeciesID = 0 }
end

local function ReadListings(itemID, key)
    local C = A.AH
    local out = {}
    local nCom = SafeCall(C.GetNumCommoditySearchResults, itemID) or 0
    if nCom > 0 then
        for i = 1, nCom do
            local info = SafeCall(C.GetCommoditySearchResultInfo, itemID, i)
            if type(info) == "table" and info.unitPrice and info.unitPrice > 0 then
                local ownQty = info.numOwnerItems or (info.containsOwnerItem and info.quantity) or 0
                table.insert(out, { price = info.unitPrice, qty = info.quantity or 1, own = ownQty > 0, ownQty = ownQty })
            end
        end
        table.sort(out, function(a, b) return a.price < b.price end)
        A:FilterDead(itemID, out)                -- S7: tote Angebote zählen nicht als "günstigstes"
        A:MarkBait(out)          -- Lockangebote (1 Stück ganz unten) markieren
        return out, true
    end
    local nItem = SafeCall(C.GetNumItemSearchResults, key) or 0
    for i = 1, nItem do
        local info = SafeCall(C.GetItemSearchResultInfo, key, i)
        if type(info) == "table" and info.buyoutAmount and info.buyoutAmount > 0 then
            local qty = info.quantity or 1
            table.insert(out, { price = math.floor(info.buyoutAmount / math.max(1, qty)), qty = qty, auctionID = info.auctionID,
                                own = info.containsOwnerItem or false, ownQty = info.containsOwnerItem and qty or 0 })
        end
    end
    A:FilterDead(itemID, out)                    -- S7
    return out, false
end

local function ResultsFull(itemID, key)
    local C = A.AH
    if SafeCall(C.HasFullCommoditySearchResults, itemID) then return true end
    return SafeCall(C.HasFullItemSearchResults, key) == true
end

function Se:IsBusy()
    return self.search ~= nil
end

-- warten noch Preisprüfungen? (haben Vorrang vor Sniper und Wächter)
function Se:HasWork()
    return self.search ~= nil or #self.queue > 0
end

-- wartet ein angeklicktes Item? (dann lassen Sniper und Wächter kurz den Vortritt)
function Se:HasUrgent()
    return self.urgent ~= nil and A:IsAHOpen()
end

-- Zwischenstand der laufenden Preisprüfung (Angebote, die schon da sind)
function Se:GetPartial(itemID)
    local s = self.search
    if s and s.itemID == itemID then return s.partial end
    return nil
end

function Se:GetPriceInfo(itemID)
    return self.prices[itemID]
end

function Se:IsPriceFresh(itemID)
    local p = self.prices[itemID]
    return p ~= nil and (Now() - p.time) <= PRICE_FRESH
end

-- UI-V1b: steht das Item in der Warteschlange (noch nicht gesucht)?
function Se:IsQueued(itemID)
    for _, id in ipairs(self.queue or {}) do if id == itemID then return true end end
    return false
end
-- Preis eines Items prüfen lassen (wird nacheinander abgearbeitet)
function Se:CheckPrice(itemID, front, silent)
    if not itemID then return false end
    if front then self.urgent = itemID end
    if self.search and self.search.itemID == itemID then return true end
    for i, id in ipairs(self.queue) do
        if id == itemID then
            -- angeklickt: nach vorne holen
            if front and i > 1 then table.remove(self.queue, i); table.insert(self.queue, 1, itemID) end
            if front then self:Preempt() end
            return true
        end
    end
    if front then table.insert(self.queue, 1, itemID) else table.insert(self.queue, itemID) end
    if front then self:Preempt() end
    if not silent then A:Fire("SELLER_CHANGED") end
    return true
end

-- Vorladen (Maus über einem Item): leise hinten anstellen, höchstens ein paar
function Se:Prefetch(itemID)
    if not (itemID and A:IsAHOpen()) or self:IsPriceFresh(itemID) then return end
    if self.search and self.search.itemID == itemID then return end
    for _, id in ipairs(self.queue) do if id == itemID then return end end
    if #self.queue >= 3 then return end
    table.insert(self.queue, itemID)
    A:Fire("SELLER_CHANGED")
end

-- ein angeklicktes Item soll sofort dran sein: laufende Wächter-Runde abbrechen
-- (der Wächter macht danach einfach weiter; ein wartender Sniper-Treffer bleibt unangetastet)
function Se:Preempt()
    local W = A.Watcher
    if W and W:IsBusy() and not (A.Sniper and A.Sniper.HitWaiting and A.Sniper:HitWaiting()) then
        if A.AH and A.AH.AbortBrowse then pcall(A.AH.AbortBrowse) end
        if W.Abort then W:Abort() end
    end
    if not self.search then self:StartNext() end
end

local function CanStartSearch()
    if not A:IsAHOpen() then return false end
    if A:IsScanning() then return false end
    if A.Sniper and (A.Sniper:IsBusy() or (A.Sniper.pending and not A.Sniper.pending.auto)) then return false end
    if A.Watcher and A.Watcher:IsBusy() then return false end
    if A.Buy and A.Buy:Blocks() then return false end
    if not (A.AH and A.AH.SendSearchQuery) then return false end
    return A:CanQueryNow()
end

-- AB1: Hintergrund-Prüfung (Materialpreise) hinten an, nie vor eigenen Auktionen oder Klicks
function Se:CheckPriceBg(itemID)
    if not itemID then return false end
    if self.search and self.search.itemID == itemID then return true end
    for _, id in ipairs(self.queue) do if id == itemID then return true end end
    for _, id in ipairs(self.bgQueue) do if id == itemID then return true end end
    table.insert(self.bgQueue, itemID)
    if not self.search then self:StartNext() end
    return true
end
-- AB1: warum ist der Preis eines Items noch nicht geprüft? (Text statt "?")
function Se:WaitReason(itemID)
    if not A:IsAHOpen() then return L["AH zu"] end
    if self.search and self.search.itemID == itemID then return L["wird geprüft"] end
    local pos
    for i, id in ipairs(self.queue) do if id == itemID then pos = i; break end end
    if A:IsScanning() then return L["wartet: Scan läuft"] end
    if A.Sniper and A.Sniper.IsBusy and A.Sniper:IsBusy() then return L["wartet: Sniper sucht"] end
    if A.Watcher and A.Watcher.IsBusy and A.Watcher:IsBusy() then return L["wartet: Wächter sucht"] end
    if not A:CanQueryNow() then return L["wartet: Server bremst"] end
    if pos then return string.format(L["wartet (%d vor dir)"], pos - 1) end
    return L["nicht geprüft – „Unterbietung prüfen“"]
end

function Se:StartNext()
    if self.search or not CanStartSearch() then return end
    if #self.queue == 0 and #self.bgQueue == 0 then return end
    local itemID = (#self.queue > 0) and table.remove(self.queue, 1) or table.remove(self.bgQueue, 1)
    if self.urgent == itemID then self.urgent = nil end
    local key = MakeKey(itemID)
    local ok = pcall(A.AH.SendSearchQuery, key, SORTS, true)
    self.lastSearch = Now()
    A:NoteQuery()
    if not ok then
        A:QueryError()
        if self.undercutBatch and self.undercutBatch.pending[itemID] then self:BatchDone(itemID); return end
        A:Fire("SELLER_CHANGED")
        return
    end
    self.search = { itemID = itemID, key = key, started = Now(), lastCount = -1, lastChange = Now() }
    A:Fire("SELLER_CHANGED")
end

function Se:PollSearch()
    local s = self.search
    if not s then return end
    if not A:IsAHOpen() then self.search = nil; return end
    local okRead, listings, commodity = pcall(ReadListings, s.itemID, s.key)
    if not okRead then listings, commodity = {}, false end
    local count = #listings
    local now = Now()
    if count ~= s.lastCount then s.lastCount, s.lastChange = count, now end
    local full = ResultsFull(s.itemID, s.key)
    local timedOut = now - s.started > SEARCH_TIMEOUT
    local done = (full and (count > 0 or s.answered or now - s.started >= 1))
        or (count > 0 and now - s.lastChange >= 0.75)
        or timedOut
    if not done then
        -- schon vorhandene Angebote sofort zeigen (die Liste wächst, während der Rest lädt)
        if count > 0 and count ~= s.shown then
            s.shown = count
            table.sort(listings, function(a, b) return a.price < b.price end)
            s.partial = listings
            if not (self.undercutBatch and self.undercutBatch.pending[s.itemID]) then A:Fire("SELLER_CHANGED") end
        end
        return
    end
    self.search = nil
    if timedOut and count == 0 then A:QueryError() end
    table.sort(listings, function(a, b) return a.price < b.price end)
    local info = { time = now, stamp = time(), listings = listings, commodity = commodity }
    local bait = 0
    for _, l in ipairs(listings) do
        if l.bait then
            bait = bait + 1          -- Lockangebote zählen nicht
        elseif l.own then
            if not info.lowestOwn then info.lowestOwn = l.price end
            -- eine Zeile kann eigene und fremde Angebote enthalten (Waren)
            if l.qty > (l.ownQty or 0) and not info.lowestOther then info.lowestOther = l.price end
        elseif not info.lowestOther then
            info.lowestOther = l.price
        end
    end
    info.bait = bait
    self.prices[s.itemID] = info
    -- günstigsten echten Preis (ohne Lockangebote) in den Preisverlauf - bestätigt damit auch den Scan
    local first
    for _, l in ipairs(listings) do if not l.bait then first = l; break end end
    local inBatch = self.undercutBatch and self.undercutBatch.pending[s.itemID]
    if first then
        local total = 0
        for _, l in ipairs(listings) do if not l.bait then total = total + l.qty end end
        if inBatch then self:Measure("Preisverlauf", A.VerifyPrice, A, s.itemID, first.price, total)
        else A:VerifyPrice(s.itemID, first.price, total) end
    end
    if inBatch then
        -- U1: nur dieses Item neu bewerten, alles andere einmal am Ende
        self:Measure("Status", self.UpdateOwnedStatus, self, s.itemID)
        self:BatchDone(s.itemID)
        return
    end
    self:UpdateOwnedStatus()
    A:Fire("SELLER_CHANGED")
    A:Fire("DATA_CHANGED")
end

-- ------------------------------------------------------------
-- Preisvorschlag
-- ------------------------------------------------------------
function Se:Undercut(price, itemID)
    local mode = DB().undercut or "copper"
    local silver = itemID and self:SilverOnly(itemID)
    local step = silver and 100 or 1
    local p
    if mode == "p1" then p = math.floor(price * 0.99)
    elseif mode == "p5" then p = math.floor(price * 0.95)
    else p = price - step end
    if p >= price then p = price - step end
    if silver then
        p = math.floor(p / 100) * 100
        if p >= price then p = p - 100 end
        return math.max(100, p)
    end
    return math.max(1, p)
end

-- Mindestpreis pro Item: darunter wird nie unterboten (nil = keiner)
function Se:GetFloor(itemID)
    local e = itemID and DB().items[itemID]
    return e and e.floor or nil
end

function Se:SetFloor(itemID, price)
    if not itemID then return end
    local db = DB()
    db.items[itemID] = db.items[itemID] or {}
    db.items[itemID].floor = (price and price > 0) and math.floor(price) or nil
    A:Fire("SELLER_CHANGED")
end

-- H5: automatischer Mindestpreis je Stück = das Höhere aus
--   (a) Händlerpreis netto: Preis, bei dem das AH nach dem Anteil so viel bringt wie der Händler
--   (b) eigene Kosten je Stück (Einkauf der letzten 30 Tage, sonst Herstellkosten aus dem Rezept) + MIN_PROFIT_PCT,
--       ebenfalls nach dem AH-Anteil
-- Ein von Hand gesetzter Mindestpreis hat Vorrang. Rückgabe: Preis, Quelle ("hand"/"vendor"/"cost") oder nil.
Se.MIN_PROFIT_PCT = 0.20          -- Rückfall; gilt die Einstellung "Mindestrendite" (DEBuy:MinRoi, Standard 20 %)
-- offener Punkt 2a (20:00): ein Mindestgewinn für alles - Tooltip "Lohnt bis", Sammelkauf, Mindestpreis, AHSentinel.API
function Se:MinProfitPct()
    local DEB = A.DEBuy
    local ok, v = pcall(function() return DEB and DEB.MinRoi and DEB:MinRoi() end)
    if ok and type(v) == "number" and v >= 0 then return v / 100 end
    return self.MIN_PROFIT_PCT
end
function Se:CostPerPiece(itemID)
    local Le = A.Ledger
    local buy = Le and Le.AverageBuyPrice and Le:AverageBuyPrice(itemID, 30)
    if buy and buy > 0 then return buy, "buy" end
    local Cr = A.Crafting
    local rec = Cr and Cr.RecipeIndex and Cr:RecipeIndex(nil, true)[itemID]
    if rec then
        local sum = 0
        for _, re in ipairs(rec.reagents or {}) do
            local u = Cr:BestUnit(re[1], 1)
            if not u then return nil end
            sum = sum + u * re[2]
        end
        if sum > 0 then return sum / math.max(rec.made or 1, 1), "craft" end
    end
    return nil
end
function Se:AutoFloor(itemID)
    if not itemID then return nil end
    local hand = self:GetFloor(itemID)
    if hand then return hand, "hand" end
    local keep = 1 - A:CutPct()
    local best, src
    local vendor = A:GetVendorPrice(itemID)
    if type(vendor) == "number" and vendor > 0 then best, src = math.ceil(vendor / keep), "vendor" end
    local okC, cost = pcall(self.CostPerPiece, self, itemID)
    if okC and cost and cost > 0 then
        local c = math.ceil(cost * (1 + self:MinProfitPct()) / keep)
        if not best or c > best then best, src = c, "cost" end
    end
    return best, src
end

-- Rückgabe: Preis pro Stück (Kupfer) oder nil, Begründung, true wenn der Mindestpreis greift, Quelle des Mindestpreises
function Se:Suggest(itemID)
    local price, why, a3, a4 = self:SuggestRaw2(itemID)
    -- Stufe 2 L11 (Option "Ausprobieren", Standard aus): jede 10. Einstellung +5 % zum Lernen
    local Ln = A.Learn
    if Ln and Ln.ExplorePrice and price and not a3 then
        local okX, up, isX = pcall(Ln.ExplorePrice, Ln, itemID, price)
        if okX and isX then price, why = up, (why or "") .. " " .. L["(+5 % Test zum Lernen)"] end
    end
    return self:RoundPrice(itemID, price), why, a3, a4
end

function Se:SuggestRaw2(itemID)
    local price, why = self:SuggestRaw(itemID)
    local floor = self:GetFloor(itemID)
    if floor and (not price or price < floor) then
        return floor, string.format(L["dein Mindestpreis (%s) - Konkurrenz ist billiger"], A:FormatMoney(floor)), true, "hand"
    end
    -- H5: automatischer Mindestpreis nur, wenn die Konkurrenz darunter liegt (Spieler entscheidet, Preis frei änderbar)
    local okF, auto, src = pcall(self.AutoFloor, self, itemID)
    -- Stufe 2 L4: gelerntes Minimum (Netto nach Gebühr und Einzahlungsrisiko mindestens Händler/Einstandspreis)
    local Ln = A.Learn
    if Ln and Ln.Limits then
        local okL, mn = pcall(Ln.Limits, Ln, itemID)
        if okL and mn and (not (okF and auto) or mn > auto) then okF, auto, src = true, mn, "learned" end
    end
    if okF and auto and price and price < auto then
        return auto, string.format(L["Markt liegt unter deinem Mindestpreis (%s) – einstellen zum Mindestpreis oder warten"], A:FormatMoney(auto)), true, src
    end
    return price, why
end

-- AB4c: Ist die GANZE fremde Leiter hoch? Aufkauf-Kennzeichen (D6/MP3) oder günstigstes fremdes Angebot >= 150 % des
-- Marktwerts bei dicker Leiter (>= 3 Angebote oder >= 5 Stück). Einzelne Ausreisser (dünn) zählen nicht.
Se.HIGH_FACTOR = 1.5
function Se:HighMarket(itemID, pr)
    pr = pr or self.prices[itemID]
    if not (pr and pr.lowestOther) then return false end
    local okB, bo = pcall(A.BuyoutInfo, A, itemID)
    if okB and bo then return true, "aufkauf" end
    local mv = A:GetMarketValue(itemID)
    if not (mv and mv > 0 and pr.lowestOther >= mv * self.HIGH_FACTOR) then return false end
    local n, qty = 0, 0
    for _, l in ipairs(pr.listings or {}) do
        if not l.bait and not (l.own and (l.qty or 0) <= (l.ownQty or 0)) then n = n + 1; qty = qty + ((l.qty or 1) - (l.ownQty or 0)) end
    end
    if n >= 3 or qty >= 5 then return true, "leiter" end
    return false
end
-- AB4d: fremde Angebote der Leiter zählen (ohne Lockangebote und eigene)
function Se:LadderCount(pr)
    local n, qty = 0, 0
    for _, l in ipairs((pr and pr.listings) or {}) do
        if not l.bait and not (l.own and (l.qty or 0) <= (l.ownQty or 0)) then n = n + 1; qty = qty + ((l.qty or 1) - (l.ownQty or 0)) end
    end
    return n, qty
end
function Se:LadderFull(pr)
    local n, qty = self:LadderCount(pr)
    return n >= 3 or qty >= 5
end

-- ------------------------------------------------------------
-- WS (Warnschutz, Wunsch des Nutzers 13.11. 08:05): zu billig verkaufen / zu teuer kaufen
-- ------------------------------------------------------------
function Se:GuardOn() return not (A.db and A.db.settings and A.db.settings.warnGuard == false) end
-- Verkauf: zurück nil oder { ref, pct, lost, text } (Stückpreis unit, Menge qty)
function Se:SellWarning(itemID, unit, qty)
    if not (self:GuardOn() and itemID and unit and unit > 0) then return nil end
    if self:GetFloor(itemID) then return nil end                         -- Mindestpreis von Hand: Spieler hat entschieden
    qty = qty or 1
    local pr = self.prices[itemID]
    local fresh = pr and self:IsPriceFresh(itemID)
    local ref, why
    if fresh and pr.lowestOther and self:LadderFull(pr) and unit < pr.lowestOther * 0.9 then
        ref, why = pr.lowestOther, L["unter dem günstigsten Angebot"]
    end
    local mv = A:GetMarketValue(itemID)
    if not ref and mv and mv > 0 and unit < mv * 0.75 then ref, why = mv, L["unter dem Marktwert"] end
    local vendor = A:GetVendorPrice(itemID)
    if not ref and type(vendor) == "number" and vendor > 0 and A:VendorPlausible(itemID, vendor) and unit * (1 - A:CutPct()) < vendor then
        ref, why = vendor, L["unter dem Händlerpreis"]
    end
    local avg = A.Ledger and A.Ledger.AverageBuyPrice and A.Ledger:AverageBuyPrice(itemID, 30)
    if not ref and avg and avg > 0 and unit * (1 - A:CutPct()) < avg then ref, why = avg, L["unter deinem Einkaufspreis"] end
    if not ref then return nil end
    local pct = math.floor((1 - unit / ref) * 100 + 0.5)
    local lost = math.max(0, (ref - unit) * qty)
    return { ref = ref, pct = pct, lost = lost, why = why, unit = unit, qty = qty,
        text = string.format(L["Achtung: %s liegt %d %% %s (%s). Verschenkt: ~%s."], A:FormatMoney(unit), pct, why, A:FormatMoney(ref), A:FormatMoney(lost)) }
end
-- Kauf: über dem Max-Preis/"Lohnt bis" oder > 25 % über dem Marktwert ohne Aufkauf-Grund
function Se:BuyWarning(itemID, unit, maxPrice)
    if not (self:GuardOn() and itemID and unit and unit > 0) then return nil end
    local ref, why
    if maxPrice and maxPrice > 0 and unit > maxPrice then ref, why = maxPrice, L["über deinem Höchstpreis"] end
    local D = A.Disenchant
    if not ref and D and D.WorthLimit and D:Prior(itemID) then
        local ok, lim = pcall(D.WorthLimit, D, itemID)
        if ok and lim and unit > lim and not maxPrice then ref, why = lim, L["über „Lohnt bis“"] end
    end
    local mv = A:GetMarketValue(itemID)
    local okB, bo = pcall(A.BuyoutInfo, A, itemID)
    if not ref and mv and mv > 0 and unit > mv * 1.25 and not (okB and bo) and not maxPrice then ref, why = mv, L["über dem Marktwert"] end
    if not ref then return nil end
    local pct = math.floor((unit / ref - 1) * 100 + 0.5)
    return { ref = ref, pct = pct, why = why, unit = unit,
        text = string.format(L["Achtung: Kauf zu %s liegt %d %% %s (%s)."], A:FormatMoney(unit), pct, why, A:FormatMoney(ref)) }
end
-- Ton der Schlachtzugswarnung + Protokoll (WS2/WS4)
function Se:Alarm(itemID, w, decision)
    if A.Diag then pcall(A.Diag.Add, A.Diag, "WARNSCHUTZ", string.format("Item %s · Preis %s · Vergleich %s (%s) · %s",
        tostring(itemID), tostring(w and w.unit), tostring(w and w.ref), tostring(w and w.why), tostring(decision or "gewarnt"))) end
    if decision and decision ~= "gewarnt" then return end
    if A.db and A.db.settings and A.db.settings.warnSound == false then return end
    local PS = A:Global("PlaySound")
    local SK = A:Global("SOUNDKIT")
    if PS then pcall(PS, (SK and SK.RAID_WARNING) or 8959, "Master") end
end

-- TU4: "billiger einstellen" nie, wenn die fremde Leiter über dem Marktwert liegt (oder Aufkauf)
function Se:SuppressCheaperHint(itemID)
    if self:HighMarket(itemID) then return true end
    local pr = self.prices[itemID]
    local mv = A:GetMarketValue(itemID)
    return (pr and pr.lowestOther and mv and pr.lowestOther > mv and self:IsPriceFresh(itemID)) and true or false
end
-- AB4c (b): von Hand eingetippter Preis wird nie automatisch überschrieben (bis Item-Wechsel oder Klick auf "Vorschlag")
Se.handPrice = Se.handPrice or {}
function Se:SetHandPrice(itemID, on) if itemID then self.handPrice[itemID] = on and true or nil end end
function Se:AutoApplyAllowed(itemID) return not (itemID and self.handPrice[itemID]) end

function Se:SuggestRaw(itemID)
    local pr = self.prices[itemID]
    if pr and self:IsPriceFresh(itemID) then
        if pr.lowestOther then
            if pr.lowestOwn and pr.lowestOwn <= pr.lowestOther then
                return pr.lowestOwn, L["dein Angebot ist schon das günstigste"]
            end
            -- AB4c: ganze Leiter hoch (Aufkauf / neue Marktlage) -> knapp unter dem günstigsten Angebot, nie der alte Preis
            if self:HighMarket(itemID, pr) then
                return self:Undercut(pr.lowestOther, itemID), L["Aufkauf – jetzt teuer verkaufen, Preis fällt meist bald (2 Std.)"]
            end
            -- Stufe 2 L4: Konkurrenz über dem gelernten Maximum -> Normalpreis statt knapp darunter - AB4d: NUR bei
            -- einzelnen Ausreissern (dünne Leiter: < 3 fremde Angebote und < 5 Stück); volle Leiter -> knapp darunter
            local okL, _, normal, max = false, nil, nil, nil
            if A.Learn and A.Learn.Limits then okL, _, normal, max = pcall(A.Learn.Limits, A.Learn, itemID) end
            if okL and normal and max and pr.lowestOther > max and not self:LadderFull(pr) then
                return normal, L["Normalpreis (gelernt) - Konkurrenz liegt über deinem Maximum"]
            end
            -- TU1 L-AUSREISSER: einzelnes teures Angebot (dünne Leiter, >= 150 % Marktwert) ohne gelernte Grenzen -> Marktwert
            local mv = A:GetMarketValue(itemID)
            if mv and mv > 0 and pr.lowestOther >= mv * self.HIGH_FACTOR then
                return mv, L["Marktwert – einzelnes teures Angebot (Ausreisser)"]
            end
            return self:Undercut(pr.lowestOther, itemID), L["unterbietet das günstigste Angebot"]
        end
        if pr.lowestOwn then return pr.lowestOwn, L["nur deine eigenen Angebote"] end
        -- Stufe 2 L4: keine Konkurrenz -> gelernter Normalpreis
        local okL, _, normal = false, nil, nil
        if A.Learn and A.Learn.Limits then okL, _, normal = pcall(A.Learn.Limits, A.Learn, itemID) end
        if okL and normal then return normal, L["Normalpreis (gelernt) - keine Konkurrenz"] end
    end
    local mv = A:GetMarketValue(itemID)
    if mv then return mv, L["Marktwert (keine aktuelle Preisprüfung)"] end
    local last = DB().items[itemID]
    if last and last.price then return last.price, L["zuletzt benutzter Preis"] end
    return nil, L["keine Preisdaten - bitte Preis eingeben"]
end

-- ------------------------------------------------------------
-- Gebühren
-- ------------------------------------------------------------
-- Einzahlung beim Einstellen: aus dem Spiel (CalculateItemDeposit/CalculateCommodityDeposit), kommt beim Verkauf
-- zurück (alle Versionen, auch Forever - Anweisung "Gebühren klassisch" 14:30). Forever ohne Wert vom Spiel:
-- Formel aus dem Händlerpreis (A:ListingDeposit, Minimum je Auktion = A:MinDeposit, gemessen). duration = Dauer-Stufe 1/2/3.
function Se:Deposit(itemID, duration, qty, commodity, loc, auctions)
    local C = A.AH
    local dep
    if C and commodity and C.CalculateCommodityDeposit then
        dep = SafeCall(C.CalculateCommodityDeposit, itemID, duration, qty)
    elseif C and loc and C.CalculateItemDeposit then
        dep = SafeCall(C.CalculateItemDeposit, loc, duration, qty)
    end
    if type(dep) ~= "number" then dep = nil end
    if not dep and A:IsForever() and itemID then
        dep = A:ListingDeposit(itemID, qty or 1, A.DURATION_HOURS[duration or 3] or 24, auctions or 1)
        -- H3: Formel am neutralen AH nicht gemessen -> "unsicher"
        return dep, A:IsNeutralAH()
    end
    return dep
end

-- Gebühr, die BEIM EINSTELLEN bezahlt wird: die Einzahlung (alle Versionen)
function Se:PostFee(itemID, unitPrice, qty, deposit, auctions)
    return deposit
end

-- Warnung, wenn die Einstellgebühr mehr als x % vom Preis ausmacht (0 = aus, Standard 10)
Se.FEE_WARN_STEPS = { 0, 5, 10, 20, 30 }
function Se:FeeWarnPercent()
    local v = A.db and A.db.settings and A.db.settings.feeWarnPct
    if v == nil then return 10 end
    return v
end
function Se:CycleFeeWarn()
    local cur, steps = self:FeeWarnPercent(), self.FEE_WARN_STEPS
    local idx = 1
    for i, v in ipairs(steps) do if v == cur then idx = i end end
    A.db.settings.feeWarnPct = steps[idx % #steps + 1]
    return A.db.settings.feeWarnPct
end
-- liefert Anteil in Prozent, wenn er über der Schwelle liegt, sonst nil
function Se:FeeTooHigh(deposit, unitPrice, qty)
    local pct = self:FeeWarnPercent()
    if pct <= 0 or not deposit or deposit <= 0 or not unitPrice or unitPrice <= 0 then return nil end
    local share = deposit / (unitPrice * (qty or 1)) * 100
    if share > pct then return share end
    return nil
end

-- Beim Einstellen die tatsächlich abgezogene Gebühr ins Protokoll (Eintrag EINSTELLEN: Preis, Menge, Gebühr),
-- damit die Einzahlungsregel im Spiel bestätigt wird (und das Minimum gemessen). Keine Namen.
-- (Die Messung je Item / Verlauf für eine Forever-Formel aus 0.65.17-0.65.20 ist gestrichen: Regel vom 9. Nov.)
function Se:RecordDeposit(p, measured)
    if not p or not p.itemID then return end
    if A.Spieltest and A.Spieltest.activeUntil then pcall(A.Spieltest.OnPostMeasured, A.Spieltest, p, measured) end
    local total = (p.unitPrice or 0) * (p.qty or 1)
    if A.Diag then
        A.Diag:Add("EINSTELLEN", string.format(
            "Item %d · Menge %d · Auktionen %d · Laufzeit %d · Preis %d/Stück, %d gesamt · Gebühr erwartet %s, abgezogen %s%s",
            p.itemID, p.qty or 1, p.auctions or 1, p.duration or 0, p.unitPrice or 0, total,
            p.deposit and tostring(p.deposit) or "-", measured and tostring(measured) or "-",
            (measured and total > 0) and string.format(" (%.2f %% vom Preis)", measured / total * 100) or ""))
    end
    pcall(self.MeasureMinDeposit, self, p, measured)
end

-- Mindest-Einzahlung messen (Hinweis 16:05): nur wenn die Formel je Auktion unter 1s liegt, zeigt die gemessene
-- Einzahlung, ob das Minimum noch gilt (abgezogen 1s) oder gesenkt wurde (abgezogen weniger). Ergebnis in
-- db.minDeposit, Protokoll "MINDESTEINZAHLUNG gemessen=…".
function Se:MeasureMinDeposit(p, measured)
    if not (A:IsForever() and A.db and measured and measured > 0 and p and p.itemID) then return end
    local vendor = A:GetVendorPrice(p.itemID)
    if not (type(vendor) == "number" and vendor >= 0) then return end
    local auctions = math.max(1, p.auctions or 1)
    local hours = A.DURATION_HOURS[p.duration or 3] or 24
    local raw = math.floor(vendor * ((p.qty or 1) / auctions) * A.DEPOSIT_PCT_PER_2H * hours / 2)
    if raw >= 100 then return end
    local per = math.floor(measured / auctions + 0.5)
    local min = (per >= 100) and 100 or 1
    if A.db.minDeposit ~= min then
        A.db.minDeposit = min
        A:Fire("DATA_CHANGED")
    end
    if A.Diag then A.Diag:Add("MINDESTEINZAHLUNG", string.format("gemessen=%d je Auktion · Formel=%d · Minimum jetzt %d", per, raw, min)) end
end

-- Erlös: brutto, AH-Gebühr, netto (ohne Einstellgebühr anderer Versionen)
function Se:Proceeds(unitPrice, qty, itemID, auctions)
    local gross = unitPrice * qty
    local cut
    cut = math.floor(gross * A:CutPct())          -- abgerundet (gemessen); 5 % beim Verkauf (neutral 15 %), alle Versionen, auch Forever
    return gross, cut, gross - cut
end

-- Vergleich mit dem Händler: zahlt der mehr als das Auktionshaus netto?
-- Die Einstellgebühr wird hier immer ganz abgezogen (WoW Forever: sie ist nie erstattet).
function Se:VendorBeats(itemID, unitPrice, qty, deposit, auctions)
    local vendor = A:GetVendorPrice(itemID)
    if not vendor or vendor <= 0 then return false, nil end
    local _, _, net = self:Proceeds(unitPrice, qty, itemID, auctions or 1)
    net = net - (deposit or 0)
    return vendor * qty >= net, vendor * qty
end

-- ------------------------------------------------------------
-- Preisschutz: Ist der Preis gefährlich niedrig? (wie "Undercut Protection")
-- Rückgabe: Liste mit Gründen (leer = alles gut)
-- ------------------------------------------------------------
Se.GUARD_STEPS = { 0, 20, 30, 40, 50 }       -- 0 = aus; sonst: Warnung, wenn mehr als x % unter Marktwert
function Se:GuardPercent()
    local s = A.db and A.db.settings
    local v = s and s.priceGuard
    if v == nil then return 40 end
    return v
end

function Se:CycleGuard()
    local cur, steps = self:GuardPercent(), self.GUARD_STEPS
    local idx = 1
    for i, v in ipairs(steps) do if v == cur then idx = i end end
    A.db.settings.priceGuard = steps[(idx % #steps) + 1]
    return A.db.settings.priceGuard
end

function Se:PriceRisks(itemID, unitPrice)
    local out = {}
    local pct = self:GuardPercent()
    if not (itemID and unitPrice) or pct <= 0 then return out end
    local mv = A:GetMarketValue(itemID)
    if mv and mv > 0 and unitPrice < mv * (1 - pct / 100) then
        table.insert(out, string.format(L["%d %% unter dem Marktwert (%s)"], math.floor((1 - unitPrice / mv) * 100 + 0.5), A:FormatMoney(math.floor(mv))))
    end
    -- offener Punkt 13: Tippfehler beim Preis ("78" = 78 Gold) - über dem 100-fachen des Marktwerts nachfragen
    -- (gilt auch, wenn der Preisschutz nach unten ausgeschaltet ist, siehe Se:PriceTooHigh)
    -- Preis-Manipulation: das günstigste fremde Angebot ist ein Einzelstück weit unter der nächsten Stufe
    local pr = self.prices[itemID]
    if pr and pr.listings then
        local real = {}
        for _, l in ipairs(pr.listings) do
            if not l.own and l.price then table.insert(real, l) end
            if #real >= 2 then break end
        end
        local a, b = real[1], real[2]
        if a and b and (a.qty or 1) <= 2 and a.price < b.price * 0.6 and unitPrice <= a.price then
            table.insert(out, string.format(L["günstigstes Angebot ist auffällig billig (nur %d Stück, nächstes %s)"], a.qty or 1, A:FormatMoney(b.price)))
        end
    end
    return out
end

-- Preis über dem 100-fachen des Marktwerts (meist Tippfehler: Zahl ohne Zeichen = Gold)? -> Faktor, sonst nil
Se.TOO_HIGH_FACTOR = 100
function Se:PriceTooHigh(itemID, unitPrice)
    if not (itemID and unitPrice and unitPrice > 0) then return nil end
    local mv = A:GetMarketValue(itemID)
    if not (mv and mv > 0) then return nil end
    if unitPrice > mv * self.TOO_HIGH_FACTOR then return unitPrice / mv end
    return nil
end

-- ------------------------------------------------------------
-- Einstellen (nur per Klick)
-- qty = Gesamtmenge (Waren) bzw. Anzahl Auktionen (Einzelangebote, je 1 Stück)
-- ------------------------------------------------------------
-- stackSize (nur altes Auktionshaus, Waren): Stück je Stapel; nil = möglichst große Stapel
function Se:Post(itemID, unitPrice, qty, duration, stackSize, feeConfirmed)
    local C = A.AH
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    if not itemID then return false, L["Erst links ein Item aus deinen Taschen wählen."] end
    if not unitPrice or unitPrice < 1 then return false, L["Bitte einen Preis pro Stück eingeben (Gold, Silber, Kupfer)."] end
    unitPrice = self:RoundPrice(itemID, unitPrice)        -- F2: Einzelstücke ganze Silber (Serie und Neu-Einstellen auch)
    qty = math.floor(tonumber(qty) or 1)
    if qty < 1 then return false, L["Menge muss mindestens 1 sein."] end
    if duration ~= 1 and duration ~= 2 and duration ~= 3 then duration = 2 end
    if self.pendingPost and Now() - self.pendingPost.time < 5 then
        return false, L["Warte auf die Bestätigung des letzten Angebots ..."]
    end
    local have, entry = self:PostSource(itemID)
    if not have then return false, entry end
    -- WS1: Serie, Neu einstellen usw. (das Verkaufen-Fenster prüft selbst und zeigt das Bestätigungsfenster)
    if not self.wsBypass then
        local w = self:SellWarning(itemID, unitPrice, qty)
        if w then self:Alarm(itemID, w); return false, w.text .. " " .. L["Nicht eingestellt – Preis im Verkaufen-Fenster prüfen."] end
    end
    local commodity = entry.commodity
    local loc = entry.slots[1].loc
    if not loc then return false, L["Dein Client unterstützt das Einstellen nicht (ItemLocation fehlt)."] end

    local ok, err
    local postQty
    -- Einstellgebühr VOR dem Einstellen aus dem Spiel lesen (danach ist das Item nicht mehr in der Tasche)
    local apiDeposit
    do
        local C2 = A.AH
        local q = commodity and qty or 1
        if commodity and C2.CalculateCommodityDeposit then apiDeposit = SafeCall(C2.CalculateCommodityDeposit, itemID, duration, q)
        elseif C2.CalculateItemDeposit then apiDeposit = SafeCall(C2.CalculateItemDeposit, loc, duration, 1) end
        if type(apiDeposit) ~= "number" then apiDeposit = nil end
    end
    -- alter AH-Weg: CalculateItemDeposit ist dort die eigene Schätzung (LegacyAH.lua), solange kein Faktor gelernt ist
    local apiEstimate = (A.AH_LEGACY and A.AH and A.AH.DepositIsEstimate and A.AH.DepositIsEstimate(duration)) and true or nil
    -- Warnung: Gebühr über x % vom Preis -> zweiter Klick nötig (innerhalb von 15 s, gleicher Preis)
    -- alle Versionen: die Einzahlung je Auktion (Forever: Händlerpreis × 5 % je 2 Std., mind. 1s - zurück beim Verkauf)
    local warnAuctions = 1
    if commodity and A.AH_LEGACY and tonumber(stackSize) and tonumber(stackSize) >= 1 then
        warnAuctions = math.max(1, math.floor(qty / math.floor(tonumber(stackSize))))
    end
    do
        local dep = self:PostFee(itemID, unitPrice, commodity and qty or 1,
            apiDeposit or self:Deposit(itemID, duration, commodity and qty or 1, commodity, loc), warnAuctions)
        local share = self:FeeTooHigh(dep, unitPrice, commodity and qty or 1)
        local key = itemID .. ":" .. unitPrice .. ":" .. duration
        if share and not feeConfirmed and not (self.feeConfirm and self.feeConfirm.key == key and Now() - self.feeConfirm.time < 15) then
            self.feeConfirm = { key = key, time = Now() }
            return false, string.format(L["Achtung: Die Einstellgebühr %s ist %d %% vom Preis. Nochmals klicken, um trotzdem einzustellen."],
                A:FormatMoney(dep), math.floor(share + 0.5)) .. (A:DepositRefunded() and L[" (wird beim Verkauf erstattet)"] or "")
        end
        self.feeConfirm = nil
    end
    if commodity then
        if qty > have then return false, string.format(L["Nur %d Stück in den Taschen."], have) end
        if not C.PostCommodity then return false, L["Dein Client unterstützt das Einstellen von Waren nicht (PostCommodity fehlt)."] end
        -- altes Auktionshaus: nur volle Stapel in einem Rutsch (Rest beim nächsten Klick)
        if A.AH_LEGACY then
            local maxStack = math.max(1, select(8, GetItemInfo(itemID)) or 1)
            stackSize = math.floor(tonumber(stackSize) or 0)
            if stackSize >= 1 then
                stackSize = math.min(stackSize, maxStack)
                if qty < stackSize then return false, string.format(L["Zu wenig für einen Stapel à %d."], stackSize) end
                qty = stackSize * math.floor(qty / stackSize)
            else
                stackSize = nil
                if qty > maxStack then qty = maxStack * math.floor(qty / maxStack) end
            end
        else
            stackSize = nil
        end
        postQty = qty
        self.ownPost = true
        self:LogPost("AHS-POST", "PostCommodity", loc, duration, qty, unitPrice, stackSize)
        ok, err = pcall(C.PostCommodity, loc, duration, qty, unitPrice, stackSize)
        self.ownPost = nil
    else
        if not C.PostItem then return false, L["Dein Client unterstützt das Einstellen nicht (PostItem fehlt)."] end
        postQty = 1
        self.ownPost = true
        self:LogPost("AHS-POST", "PostItem", loc, duration, 1, nil, unitPrice)
        ok, err = pcall(C.PostItem, loc, duration, 1, nil, unitPrice)
        self.ownPost = nil
    end
    if not ok then
        self:LogPostError(itemID, commodity, postQty, duration, unitPrice, tostring(err))
        self:InvalidateBags()
        -- AB2: nie die rohe Lua-Meldung zeigen (steht im Testlog)
        local e = tostring(err)
        if e:find("bad argument", 1, true) or e:find("Usage:", 1, true) then
            return false, L["Einstellen nicht möglich: Item nicht mehr an diesem Platz (schon eingestellt?)."]
        end
        return false, L["Einstellen fehlgeschlagen – Details im Testlog."]
    end

    local auctions = (stackSize and stackSize >= 1) and math.max(1, math.floor(postQty / stackSize)) or 1
    local deposit = self:PostFee(itemID, unitPrice, postQty, apiDeposit or self:Deposit(itemID, duration, postQty, commodity, nil), auctions)
    self.pendingPost = { itemID = itemID, qty = postQty, unitPrice = unitPrice, duration = duration, auctions = auctions,
                         commodity = commodity and true or false,
                         deposit = deposit, apiDeposit = apiDeposit, apiEstimate = apiEstimate, money = GetMoney and GetMoney() or nil,
                         time = Now(), left = (not commodity) and (qty - 1) or 0 }
    local db = DB()
    local prev = db.items[itemID] or {}
    db.items[itemID] = { price = unitPrice, duration = duration, qty = commodity and qty or nil,
                         stack = stackSize or (commodity and prev.stack) or nil,
                         stacks = (stackSize and math.floor(qty / stackSize)) or (commodity and prev.stacks) or nil,
                         floor = prev.floor }
    db.duration = duration
    local msg = string.format(L["Wird eingestellt: %dx %s für %s/Stück ..."], postQty, A:GetItemName(itemID), A:FormatMoney(unitPrice))
    A:Fire("SELLER_CHANGED")
    return true, msg
end

-- ------------------------------------------------------------
-- Serien-Einstellen: alle Taschen-Items mit gemerktem Preis nacheinander,
-- ein Klick = eine Auktion. Schutz:
--   * Vorschlag unter 70 % deines letzten Preises -> überspringen
--   * Händler zahlt mehr -> überspringen
-- ------------------------------------------------------------
Se.BATCH_FLOOR = 0.7

-- only: { [itemID] = true } = nur diese Items (z.B. zurückgekommene Auktionen), auch ohne gemerkten Preis
function Se:BatchCandidates(only)
    local out = {}
    local db = DB()
    for _, e in ipairs(self:GetBagItems(true)) do
        local last = db.items[e.itemID]
        if only then
            if only[e.itemID] then table.insert(out, { itemID = e.itemID, name = e.name }) end
        elseif last and last.price then
            table.insert(out, { itemID = e.itemID, name = e.name })
        end
    end
    table.sort(out, function(a, b) return string.lower(a.name) < string.lower(b.name) end)
    return out
end

function Se:StartBatch(only)
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    local list = self:BatchCandidates(only)
    if #list == 0 then return false, L["Keine Items mit gemerktem Preis in den Taschen (erst einmal normal einstellen)."] end
    -- immer frisch prüfen: eingestellt wird nur mit Preisen, die nach dem Start geladen wurden
    self.batch = { items = list, pos = 1, posted = 0, skipped = {}, started = Now() }
    for _, e in ipairs(list) do self:CheckPrice(e.itemID) end
    A:Fire("SELLER_CHANGED")
    return true, string.format(L["Serie: %d Items. Jeder Klick stellt eine Auktion ein."], #list)
end

function Se:StopBatch(reason)
    local b = self.batch
    if not b then return end
    self.batch = nil
    local msg = string.format(L["Serie beendet: %d eingestellt, %d übersprungen."], b.posted, #b.skipped)
    if #b.skipped > 0 then msg = msg .. " " .. table.concat(b.skipped, "; ") end
    if reason then msg = msg .. " " .. reason end
    A:Print(msg)
    A:Fire("SELLER_CHANGED")
    return msg
end

-- aktuelles Item der Serie (leere überspringen)
function Se:BatchCurrent()
    local b = self.batch
    if not b then return nil end
    while b.items[b.pos] do
        local e = b.items[b.pos]
        if self:CountInBags(e.itemID) > 0 or (self.pendingPost and self.pendingPost.itemID == e.itemID) then
            return e, b.pos, #b.items
        end
        b.pos = b.pos + 1
    end
    return nil
end

local function BatchSkip(self, e, reason)
    local b = self.batch
    table.insert(b.skipped, e.name .. " (" .. reason .. ")")
    b.pos = b.pos + 1
    return true, string.format(L["Übersprungen: %s - %s"], e.name, reason)
end

-- ein Klick: das nächste Item einstellen
function Se:BatchStep()
    if not self.batch then return false, L["Keine Serie aktiv."] end
    if self.pendingPost and Now() - self.pendingPost.time < 5 then
        return false, L["Warte auf die Bestätigung des letzten Angebots ..."], true
    end
    local e = self:BatchCurrent()
    if not e then return true, self:StopBatch() end
    local id = e.itemID
    local pr = self.prices[id]
    if not pr or pr.time < self.batch.started then
        self:CheckPrice(id, true)
        return false, string.format(L["Preis von %s wird geprüft - gleich nochmal klicken."], e.name), true
    end
    local last = DB().items[id]
    local price, _, atFloor = self:Suggest(id)
    if not price then return BatchSkip(self, e, L["kein Preis"]) end
    -- Konkurrenz unter deinem Mindestpreis: warten statt billig verkaufen
    if atFloor and self:IsPriceFresh(id) and pr.lowestOther and pr.lowestOther < price then
        return BatchSkip(self, e, string.format(L["Konkurrenz unter deinem Mindestpreis (%s)"], A:FormatMoney(price)))
    end
    if last and last.price and price < math.floor(last.price * self.BATCH_FLOOR) then
        return BatchSkip(self, e, string.format(L["nur %s, unter 70 %% deines letzten Preises"], A:FormatMoney(price)))
    end
    local count, entry = self:CountInBags(id)
    local qty = (entry and entry.commodity) and count or 1
    local stack = (entry and entry.commodity and A.AH_LEGACY and last and last.stack) or nil
    if stack then
        if count < stack then return BatchSkip(self, e, string.format(L["Zu wenig für einen Stapel à %d."], stack)) end
        qty = stack * math.min(math.floor(count / stack), last.stacks or math.huge)
    end
    local auctions = stack and math.floor(qty / stack) or 1
    local deposit = entry and self:Deposit(id, (last and last.duration) or DB().duration or 2, qty, entry.commodity, entry.slots[1].loc, auctions)
    if self:VendorBeats(id, price, qty, deposit, auctions) then return BatchSkip(self, e, L["Händler zahlt mehr"]) end
    local risks = self:PriceRisks(id, price)
    if #risks > 0 then return BatchSkip(self, e, L["Preisschutz: "] .. risks[1]) end
    local ok, msg = self:Post(id, price, qty, A:StandardDurationStep(), stack)     -- D4: Standard-Laufzeit
    if ok then
        self.batch.posted = self.batch.posted + 1
        if entry and entry.commodity then self.batch.pos = self.batch.pos + 1 end
    end
    return ok, msg
end

-- ------------------------------------------------------------
-- Eigene Auktionen
-- ------------------------------------------------------------
function Se:QueryOwned()
    local C = A.AH
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    if not (C and C.QueryOwnedAuctions) then return false, L["Dein Client unterstützt das Abfragen eigener Auktionen nicht."] end
    local ok, err = pcall(C.QueryOwnedAuctions, SORTS)
    if not ok then return false, tostring(err) end
    self.ownedQueried = Now()
    return true, L["Eigene Auktionen werden geladen ..."]
end

function Se:ReadOwned()
    local C = A.AH
    local list = {}
    local n = SafeCall(C.GetNumOwnedAuctions) or 0
    local soldStatus = (Enum and Enum.AuctionStatus and Enum.AuctionStatus.Sold) or 1
    for i = 1, n do
        local info = SafeCall(C.GetOwnedAuctionInfo, i)
        if type(info) == "table" and info.auctionID then
            local itemID = (info.itemKey and info.itemKey.itemID) or (info.itemLink and tonumber(info.itemLink:match("item:(%d+)")))
            local qty = info.quantity or 1
            local raw = info.buyoutAmount or info.bidAmount or 0
            local sold = info.status == soldStatus
            local unit, buyout = self:OwnedPrice(itemID, raw, qty, sold)
            table.insert(list, {
                auctionID = info.auctionID, itemID = itemID, name = itemID and A:GetItemName(itemID) or "?",
                qty = qty, buyout = buyout, unitPrice = unit, rawBuyout = raw,
                sold = sold, timeLeft = info.timeLeftSeconds,
            })
        end
    end
    -- AB3 (messen): eingestellter Stückpreis gegen den Preis, den der Server führt (Rohwert, Menge, Lesart)
    local lp = self.lastPosted
    if lp and not lp.checkedAB3 and A.Diag then
        for _, o in ipairs(list) do
            if o.itemID == lp.itemID and not o.sold and o.qty == lp.qty then
                lp.checkedAB3 = true
                if o.unitPrice ~= lp.unitPrice then
                    pcall(A.Diag.Add, A.Diag, "EIGENE-PREIS", string.format("Item %d · eingestellt %d/Stück · Server roh %d · Menge %d · gelesen %d/Stück",
                        o.itemID, lp.unitPrice or 0, o.rawBuyout or 0, o.qty or 0, o.unitPrice or 0))
                end
                break
            end
        end
    end
    self.owned = list
    self.ownedTime = Now()
    if A.Core then pcall(A.Core.OnOwned, A.Core, list) end                     -- MA1: verschwundene eigene Auktionen
    self:UpdateOwnedStatus()
    A:Fire("SELLER_CHANGED")
end

-- Befund "Meine Auktionen" O1 (10.11., gemessen): Bei AKTIVEN Waren-Auktionen liefert GetOwnedAuctionInfo in
-- buyoutAmount den Preis JE STÜCK (43 Essenzen: 97, Markt 97c), bei VERKAUFTEN den Gesamtbetrag (4 Staub: 332 = 4 x 83).
-- Einzelstücke: Gesamt = Stück. Altes Auktionshaus (LegacyAH) liefert immer Gesamt - dort unverändert.
-- Rückgabe: Stückpreis, Gesamt. Gegenprobe: Ist der Wert als Stückpreis mehr als das 10-fache des Marktwerts, der
-- geteilte Wert aber plausibel (mind. 10 % vom Markt), gilt er doch als Gesamt (falls Forever das ändert).
function Se:OwnedPrice(itemID, raw, qty, sold)
    qty = math.max(1, qty or 1)
    raw = raw or 0
    local perUnit = not A.AH_LEGACY and not sold and qty > 1 and itemID and A:IsCommodityItem(itemID)
    if perUnit then
        local mv = A:GetMarketValue(itemID)
        if mv and mv > 0 and raw > mv * 10 and raw / qty >= mv * 0.1 then perUnit = false end
        if not self.ownedLogged and A.Diag then
            self.ownedLogged = true
            pcall(A.Diag.Add, A.Diag, "EIGENE", string.format("Ware Item %s · buyout %d · Menge %d · als %s gelesen", tostring(itemID), raw, qty,
                perUnit and "Stückpreis" or "Gesamt (Gegenprobe Markt)"))
        end
    end
    if perUnit then return raw, raw * qty end
    return math.floor(raw / qty), raw
end

-- Status: "verkauft", "unterboten" (Abbrechen lohnt), "liegen" (unterboten - liegen lassen), "gleich", "günstigstes",
-- "?" (noch nicht geprüft)
function Se:UpdateOwnedStatus(onlyItem)
    for _, o in ipairs(self.owned) do
        if not onlyItem or o.itemID == onlyItem then self:UpdateOneStatus(o) end
    end
end

function Se:UpdateOneStatus(o)
    do
        local pr = o.itemID and self.prices[o.itemID]
        o.lowest = pr and pr.lowestOther or nil
        if o.sold then o.status = "verkauft"
        elseif not pr then o.status = "?"; o.waitWhy = self:WaitReason(o.itemID)
        elseif not pr.lowestOther then o.status = "günstigstes"
        elseif pr.lowestOther > o.unitPrice and A.Learn and A.Learn.RelistHigher
            and select(2, pcall(A.Learn.RelistHigher, A.Learn, o, pr.lowestOther)) then
            -- Stufe 2 L6: günstigere Konkurrenz ist weg - teurer neu einstellen lohnt (nur Hinweis, Abbrechen per Klick)
            local _, newPrice, gain, dep = pcall(A.Learn.RelistHigher, A.Learn, o, pr.lowestOther)
            o.status, o.relist = "teurer", { price = newPrice, gain = gain, deposit = dep }
        elseif pr.lowestOther < o.unitPrice then
            -- H1: nur zum Abbrechen vorschlagen, wenn es sich lohnt (sonst "liegen lassen")
            local okW, worth, calc = pcall(self.CancelWorth, self, o, pr.lowestOther)
            o.cancelCalc = okW and calc or nil
            o.status = (okW and worth == false) and "liegen" or "unterboten"
        elseif pr.lowestOther == o.unitPrice then o.status = "gleich"
        else o.status = "günstigstes" end
    end
end

-- H1: Lohnt das Abbrechen einer unterbotenen Auktion? (Regelwerk Abschnitt 1: beim Abbrechen ist die Einzahlung weg)
--   Mehrerlös = (neuer Preis × p − eigener Preis × p_bleiben) × Menge × (1 − AH-Anteil)
--   Kosten    = verlorene Einzahlung + neue Einzahlung × (1 − p) / p
--   p = Verkaufschance je Einstellung (1 / erwartete Einstellungen). p_bleiben: Käufer nehmen die billigsten Stücke
--   zuerst; bis 2 % teurer gilt die eigene Auktion als gleich gut (p), ab 20 % als sicher abgelaufen (0), dazwischen
--   linear. Darum lohnt Abbrechen bei 1c-Unterbietung nie.
Se.CANCEL_SAME, Se.CANCEL_DEAD = 0.02, 0.20
function Se:CancelWorth(o, lowest)
    if not (o and o.unitPrice and o.unitPrice > 0 and lowest and lowest < o.unitPrice) then return nil end
    local qty = math.max(1, o.qty or 1)
    local newPrice = math.max(1, self:Undercut(lowest, o.itemID))
    -- nach dem Unterbieten steht man vorne in der Warteschlange: Einstellungen zum NEUEN Preis (Angebot und Absatz)
    local listings = (o.itemID and A:ExpectedListings(o.itemID, qty, newPrice)) or 1
    local p = 1 / math.max(1, listings)
    local drop = (o.unitPrice - lowest) / o.unitPrice
    local stay = (drop <= self.CANCEL_SAME) and 1 or math.max(0, math.min(1, (self.CANCEL_DEAD - drop) / (self.CANCEL_DEAD - self.CANCEL_SAME)))
    local pStay = p * stay
    local dep = o.deposit or (o.itemID and A:ListingDeposit(o.itemID, qty, 24, 1)) or 0
    local cut = 1 - A:CutPct()
    local gain = math.floor((newPrice * p - o.unitPrice * pStay) * qty * cut + 0.5)
    local cost = math.floor(dep + dep * (1 - p) / p + 0.5)
    local calc = { gain = gain, cost = cost, deposit = dep, p = p, newPrice = newPrice }
    return gain > cost, calc
end

-- Preise aller eigenen (aktiven) Auktionen prüfen
-- U1–U4 (Befund "Unterbietung prüfen" friert 3–4 s ein): nur aktive Auktionen, je Item EINE Suche; während der Runde
-- wird je Ergebnis nur der Status dieses Items neu gerechnet, die Liste und alle Empfänger (SELLER_CHANGED/DATA_CHANGED)
-- erst EINMAL am Ende; jeder Schritt wird gemessen (Protokoll LANGSAM > 50 ms, längster Frame im Ergebnis).
Se.SLOW_MS = 50
local function Clock() return debugprofilestop and debugprofilestop() or (GetTime() * 1000) end
function Se:CheckUndercuts()
    local seen, n = {}, 0
    local batch = { pending = {}, n = 0, started = Now(), maxMs = 0, steps = {} }
    for _, o in ipairs(self.owned) do
        if not o.sold and o.itemID and not seen[o.itemID] then
            seen[o.itemID] = true
            batch.pending[o.itemID] = true
            n = n + 1
            self:CheckPrice(o.itemID, nil, true)
        end
    end
    if n == 0 then return false, L["Keine aktiven Auktionen."] end
    batch.n = n
    self.undercutBatch = batch
    A:Fire("SELLER_CHANGED")
    return true, string.format(L["Prüfe %d Items ..."], n)
end
-- Schritt messen (U4)
function Se:Measure(name, fn, ...)
    local t0 = Clock()
    local r = { pcall(fn, ...) }
    local ms = Clock() - t0
    local b = self.undercutBatch or self.closingBatch
    if b then
        b.steps[name] = math.max(b.steps[name] or 0, ms)
        if ms > b.maxMs then b.maxMs = ms end
    end
    if ms > self.SLOW_MS and A.Diag then pcall(A.Diag.Add, A.Diag, "LANGSAM", string.format("Unterbietung: %s %.0f ms", name, ms)) end
    if not r[1] then error(r[2], 0) end
    return unpack(r, 2)
end
-- ein Item der Runde fertig; die letzte Antwort schliesst die Runde ab (EINMAL neu aufbauen)
function Se:BatchDone(itemID, force)
    local b = self.undercutBatch
    if not b then return false end
    if itemID then b.pending[itemID] = nil end
    -- Sicherheitsnetz: höchstens 90 s (AH zu, Suche verworfen) - dann trotzdem abschliessen
    if next(b.pending) and not force and Now() - b.started < 90 then return true end
    self.undercutBatch = nil
    self.lastBatch = b
    b.ms = (Now() - b.started) * 1000
    self.closingBatch = b
    local ok, err = pcall(function()
        self:Measure("Liste neu", function() A:Fire("SELLER_CHANGED") end)
        self:Measure("Empfänger (Daten)", function() A:Fire("DATA_CHANGED") end)
    end)
    self.closingBatch = nil
    if not ok then error(err, 0) end
    return true
end

function Se:CountByStatus(status)
    local n = 0
    for _, o in ipairs(self.owned) do if o.status == status then n = n + 1 end end
    return n
end

-- Eine Auktion abbrechen (nur per Klick). Die Einstellgebühr ist dabei verloren.
-- VF5 (Befund 11.11. 16:31): Bei Waren behalten die verkauften Teile nach einem Teilverkauf DIESELBE auctionID wie die
-- aktive Restmenge. Gesucht wird darum der NICHT verkaufte Eintrag (bzw. genau der übergebene Eintrag der Zeile).
function Se:OwnedActive(auctionID)
    local sold
    for _, x in ipairs(self.owned or {}) do
        if x.auctionID == auctionID then
            if not x.sold then return x end
            sold = sold or x
        end
    end
    return nil, sold
end
function Se:Cancel(auctionID, entry)
    local C = A.AH
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."] end
    if not (C and C.CancelAuction) then return false, L["Dein Client unterstützt das Abbrechen nicht (CancelAuction fehlt)."] end
    local o, soldOnly
    if entry and entry.auctionID == auctionID and not entry.sold then o = entry
    else o, soldOnly = self:OwnedActive(auctionID) end
    if not o and soldOnly then return false, L["Diese Auktion ist schon verkauft."] end
    if not o then return false, L["Auktion nicht gefunden."] end
    if o.sold then return false, L["Diese Auktion ist schon verkauft."] end
    if C.CanCancelAuction and SafeCall(C.CanCancelAuction, auctionID) == false then
        return false, L["Diese Auktion kann nicht abgebrochen werden."]
    end
    self:CancelLog(string.format("Klick: Zeile auctionID %s · Item %s · Menge %s · Status %s · Preis %s", tostring(auctionID),
        tostring(o.itemID), tostring(o.qty), tostring(o.status), tostring(o.unitPrice)))
    local ok, err = pcall(C.CancelAuction, auctionID)
    if not ok then
        self:CancelLog("CancelAuction Fehler: " .. tostring(err))
        return false, L["Abbrechen fehlgeschlagen – Details im Testlog."]
    end
    self:CancelLog("CancelAuction aufgerufen, warte auf AUCTION_CANCELED")
    self.pendingCancel = { auctionID = auctionID, time = Now(), name = o.name, qty = o.qty, itemID = o.itemID,
                           money = GetMoney and GetMoney() or nil, row = o }
    return true, string.format(L["Wird abgebrochen: %dx %s ..."], o.qty or 1, o.name or A:GetItemName(o.itemID) or "?")
end

function Se:CancelLog(txt)
    if A.Diag then pcall(A.Diag.Add, A.Diag, "ABBRECHEN", txt) end
end
-- AB1: abgebrochene Zeile sofort aus der Liste (die Ware geht mit der Post zurück)
function Se:DropOwnedRow(c)
    if not c then return end
    for i = #self.owned, 1, -1 do
        local x = self.owned[i]
        if x == c.row or (x.auctionID == c.auctionID and not x.sold) then table.remove(self.owned, i) end
    end
end

-- MV1 (Wunsch des Nutzers 13.11.): verkaufte Auktionen nach "Aktualisieren" (und beim Öffnen der Ansicht) ausblenden.
-- Neu Verkauftes seit dem letzten Klick bleibt bis zum nächsten sichtbar. Buchhaltung und Kopf-Summen unverändert.
Se.soldSeenAt = Se.soldSeenAt or {}
Se.soldHideBefore = Se.soldHideBefore or 0
local function SoldKey(o) return tostring(o.auctionID or "?") .. ":" .. tostring(o.itemID) .. ":" .. tostring(o.qty) end
function Se:HideSoldNow(t) self.soldHideBefore = t or time() end
function Se:VisibleOwned(showSold)
    local out, now = {}, time()
    for _, o in ipairs(self.owned or {}) do
        if o.sold then
            local k = SoldKey(o)
            self.soldSeenAt[k] = self.soldSeenAt[k] or now
            if showSold or self.soldSeenAt[k] >= self.soldHideBefore then out[#out + 1] = o end
        else
            out[#out + 1] = o
        end
    end
    return out
end

-- AUCTION_CANCELED: Zeile weg, Meldung, Buchhaltung; eine laufende Preisprüfung (Se.search, Warteschlange) bleibt unberührt
-- DG1300 D1: nur eigene, erwartete Abbrüche verarbeiten. Das Spiel meldet AUCTION_CANCELED auch beim gescheiterten
-- Kauf (Sniper) bzw. mit fremder auctionID - dann nichts entfernen, nichts buchen, nur protokollieren. Gleiche ID nur einmal.
Se.cancelSeen = Se.cancelSeen or {}
function Se:CancelForeign(a1)
    local c = self.pendingCancel
    if a1 ~= nil and self.cancelSeen[a1] and time() - self.cancelSeen[a1] < 600 then return "doppelt" end
    if not c then return "unerwartet" end
    if a1 ~= nil and c.auctionID ~= nil and a1 ~= c.auctionID then return "fremd" end
    return nil
end
function Se:OnCanceled(a1)
    local why = self:CancelForeign(a1)
    if why then
        self:CancelLog(string.format("AUCTION_CANCELED auctionID %s (erwartet %s) -> %s, nichts geändert",
            tostring(a1), tostring(self.pendingCancel and self.pendingCancel.auctionID), why))
        return
    end
    local c = self.pendingCancel
    self.pendingCancel = nil
    if a1 ~= nil then self.cancelSeen[a1] = time() end
    if c.auctionID ~= nil then self.cancelSeen[c.auctionID] = time() end
    self:CancelLog(string.format("AUCTION_CANCELED auctionID %s (erwartet %s) -> Zeile entfernt, Ware zurück per Post",
        tostring(a1), tostring(c and c.auctionID)))
    if c then self:DropOwnedRow(c); A:Fire("SELLER_CHANGED") end
    if c then
        -- Forever: ob beim Abbrechen etwas zurückkommt, misst die Buchhaltung (L2, Erstattung src "cancel")
        A:Print(string.format(A:IsForever() and L["Abgebrochen: %dx %s (Erstattung wird gemessen)"]
            or L["Abgebrochen: %dx %s (Einstellgebühr verloren)"], c.qty or 0, c.name or A:GetItemName(c.itemID) or "?"))
    end
    A:Fire("AUCTION_CANCELLED", c, a1)
    self:QueryOwned()
end

-- die nächste unterbotene Auktion abbrechen (ein Klick = eine Auktion)
-- VF2 (Befund grosser Test 0.65.88): bricht nur eine Auktion mit Status "unterboten" ab - "liegen" nie.
-- onlyID: nur diese Auktion (Testroutine: nie eine echte Auktion des Spielers ansprechen)
function Se:CancelNextUndercut(onlyID)
    for _, o in ipairs(self.owned) do
        if o.status == "unterboten" and not o.sold and (not onlyID or o.auctionID == onlyID) then return self:Cancel(o.auctionID, o) end
    end
    return false, L["Keine unterbotenen Auktionen (vorher 'Unterbietung prüfen')."]
end

-- ------------------------------------------------------------
-- Befund E1-E3 (10.11.): Ausrüstung einstellen scheitert mit "Interner Auktion-Fehler", Blizzards Fenster geht.
-- Zuerst MESSEN: womit ruft Blizzard den Server (Nachhaken, ändert nichts), womit wir. Nur Typen und Zahlen, keine Namen.
-- ------------------------------------------------------------
local function ArgText(v)
    if v == nil then return "nil" end
    if type(v) == "number" then return tostring(v) end
    if type(v) == "boolean" then return tostring(v) end
    return type(v)
end

function Se:LocInfo(loc)
    if type(loc) ~= "table" then return "ItemLocation " .. type(loc) end
    local valid
    local okV, v = pcall(function() return loc.IsValid and loc:IsValid() end)
    if okV then valid = v end
    local CI = A:Global("C_Item")
    if valid == nil and CI and CI.DoesItemExist then
        local okE, e = pcall(CI.DoesItemExist, loc)
        if okE then valid = e end
    end
    local bag, slot
    pcall(function() bag, slot = loc:GetBagAndSlot() end)
    return string.format("ItemLocation gültig %s, Bag/Slot %s/%s", valid == nil and "?" or (valid and "ja" or "nein"),
        tostring(bag), tostring(slot))
end

function Se:LogPost(tag, fn, loc, a2, a3, a4, a5, a6)
    if not A.Diag then return end
    local parts = { string.format("%s: arg2=%s arg3=%s arg4=%s arg5=%s", fn, ArgText(a2), ArgText(a3), ArgText(a4), ArgText(a5)) }
    if a6 ~= nil then parts[1] = parts[1] .. " arg6=" .. ArgText(a6) end
    parts[#parts + 1] = self:LocInfo(loc)
    pcall(A.Diag.Add, A.Diag, tag, table.concat(parts, ", "))
end

-- Blizzards eigene Aufrufe mitschreiben (hooksecurefunc: Nachhaken, Blizzard läuft unverändert)
function Se:HookBlizzardPost()
    if self.postHooked then return end
    local CA = A:Global("C_AuctionHouse")
    local hook = A:Global("hooksecurefunc")
    if not (CA and hook) then return end
    self.postHooked = true
    for _, fn in ipairs({ "PostItem", "PostCommodity" }) do
        if type(CA[fn]) == "function" then
            pcall(hook, CA, fn, function(loc, a2, a3, a4, a5)
                if Se.ownPost then return end       -- unser eigener Aufruf steht schon als AHS-POST im Protokoll
                Se.blizzardPost = { fn = fn, time = Now() }
                Se:LogPost("BLIZZARD-POST", fn, loc, a2, a3, a4, a5)
                pcall(Se.NoteExternalPost, Se, fn, loc, a2, a3, a4, a5)
            end)
        end
    end
end

-- PR2-1 (Prüf-Sitzung 08:40): Abbrechen über Blizzards Fenster (oder andere Addons) bisher nicht erkannt -> Abbruch-Grund
-- leer. Nachhaken an C_AuctionHouse.CancelAuction: gehört die Auktion zu den eigenen, wie ein eigener Abbruch merken
-- (AUCTION_CANCELED verarbeitet ihn dann wie immer: Zeile weg, Prognose cr, Buchhaltung Anzahlung).
function Se:HookBlizzardCancel()
    if self.cancelHooked then return end
    local CA = A:Global("C_AuctionHouse")
    local hook = A:Global("hooksecurefunc")
    if not (CA and hook and type(CA.CancelAuction) == "function") then return end
    self.cancelHooked = true
    pcall(hook, CA, "CancelAuction", function(auctionID)
        if Se.pendingCancel or A:Simulated() then return end              -- eigener Aufruf (Se:Cancel) setzt ihn selbst
        local o = Se.OwnedActive and Se:OwnedActive(auctionID)
        if o and not o.sold then
            Se.pendingCancel = { auctionID = auctionID, time = Now(), name = o.name, qty = o.qty, itemID = o.itemID,
                money = GetMoney and GetMoney() or nil, row = o, external = true }
            Se:CancelLog(string.format("Blizzard-Abbruch auctionID %s · Item %s", tostring(auctionID), tostring(o.itemID)))
        end
    end)
end
A:On("READY", function() pcall(Se.HookBlizzardPost, Se); pcall(Se.HookBlizzardCancel, Se) end)

-- Befund Buchhaltung B2a (10.11. 09:15): auch Einstellungen über Blizzards Fenster oder andere Addons buchen - sonst
-- steht beim Verkauf eine Erstattung ohne Einzahlung in der Buchhaltung (positive Gebühren). Nur Zahlen, keine Namen.
function Se:NoteExternalPost(fn, loc, duration, a3, a4, a5)
    if A:Simulated() then return end
    local CI = A:Global("C_Item")
    local itemID = CI and CI.GetItemID and SafeCall(CI.GetItemID, loc)
    if not itemID then return end
    local qty, unit
    if fn == "PostCommodity" then qty, unit = tonumber(a3) or 1, tonumber(a4)
    else qty, unit = tonumber(a3) or 1, a5 and math.floor(a5 / math.max(1, tonumber(a3) or 1)) or nil end
    local hours = A.DURATION_HOURS[duration or 3] or 24
    local okD, dep = pcall(A.ListingDeposit, A, itemID, qty, hours, 1)
    self.externalPost = { itemID = itemID, qty = qty, unitPrice = unit, duration = duration, auctions = 1,
        deposit = okD and dep or nil, money = GetMoney and GetMoney() or nil, time = Now(), external = true }
end

-- Fehlertexte des Spiels (Enum.AuctionHouseError -> ERR_...); ohne Treffer der Name des Fehlers
Se.ERROR_STRINGS = {
    NotEnoughMoney = "ERR_NOT_ENOUGH_MONEY", HigherBid = "ERR_AUCTION_HIGHER_BID", BidIncrement = "ERR_AUCTION_BID_INCREMENT",
    BidOwn = "ERR_AUCTION_BID_OWN", ItemNotFound = "ERR_ITEM_NOT_FOUND", RestrictedAccount = "ERR_RESTRICTED_ACCOUNT_TRIAL",
    HasRestriction = "ERR_AUCTION_HAS_RESTRICTION", IsBusy = "ERR_AUCTION_HOUSE_BUSY", Unavailable = "ERR_AUCTION_HOUSE_UNAVAILABLE",
    DatabaseError = "ERR_AUCTION_DATABASE_ERROR", MinBid = "ERR_AUCTION_MIN_BID", NotEnoughItems = "ERR_AUCTION_NOT_ENOUGH_ITEMS",
    RepairItem = "ERR_AUCTION_REPAIR_ITEM", UsedCharges = "ERR_AUCTION_USED_CHARGES", QuestItem = "ERR_AUCTION_QUEST_ITEM",
    BoundItem = "ERR_AUCTION_BOUND_ITEM", LimitExceeded = "ERR_AUCTION_LIMIT_EXCEEDED",
}
function Se:ErrorText(code)
    if type(code) ~= "number" then return nil, nil end
    local E = A:Global("Enum")
    local enum = E and E.AuctionHouseError
    if type(enum) ~= "table" then return nil, nil end
    for name, v in pairs(enum) do
        if v == code then
            local g = self.ERROR_STRINGS[name]
            local text = g and A:Global(g)
            return (type(text) == "string" and text ~= "") and text or nil, name
        end
    end
    return nil, nil
end

-- Fehlversuch: echte Meldung des Spiels zeigen (E2) und ins Protokoll (E3)
function Se:LogPostError(itemID, commodity, qty, duration, unitPrice, msg)
    if not A.Diag then return end
    pcall(A.Diag.Add, A.Diag, "EINSTELLEN-FEHLER", string.format("Item %s · Ware %s · Menge %s · Dauer %s · Preis %s · Meldung %s",
        tostring(itemID), commodity and "ja" or "nein", tostring(qty), tostring(duration), tostring(unitPrice), tostring(msg or "?")))
end

function Se:PostFailed(code)
    local p = self.pendingPost
    if not p then return end
    self.pendingPost = nil
    local text, name = self:ErrorText(code)
    local ui = self.lastUIError
    if not text and ui and Now() - ui.time < 3 then text = ui.msg end
    self:LogPostError(p.itemID, p.commodity, p.qty, p.duration, p.unitPrice,
        (text or "-") .. (name and (" (" .. name .. ")") or (code and (" (" .. tostring(code) .. ")") or "")))
    if text then
        A:Print(L["|cffff5544Einstellen fehlgeschlagen:|r "] .. text)
    else
        A:Print(L["|cffff5544Einstellen fehlgeschlagen|r (zu wenig Gold für die Einstellgebühr oder Item nicht verfügbar)."])
    end
    self.lastPostError = { itemID = p.itemID, text = text, code = code, name = name, time = Now() }
    A:Fire("SELLER_CHANGED")
end

-- ------------------------------------------------------------
-- Ereignisse und Takt
-- ------------------------------------------------------------
local evt = CreateFrame("Frame")
local function Reg(e) A:RegisterAHEvent(evt, e) end
Reg("OWNED_AUCTIONS_UPDATED")
Reg("AUCTION_HOUSE_AUCTION_CREATED")
Reg("AUCTION_CANCELED")
Reg("AUCTION_HOUSE_SHOW_ERROR")
Reg("BAG_UPDATE")
Reg("BAG_UPDATE_DELAYED")
Reg("UI_ERROR_MESSAGE")
Reg("AUCTION_HOUSE_SHOW")

local bagDirty = false
evt:SetScript("OnEvent", function(_, event, a1, a2)
    -- Punkt 0 (Befund 10.11.): geschützte Werte (WoW Forever "secret string") nie indizieren
    do local G = _G.GoldSentinelGame; if G and G.AnySecret and G.AnySecret(a1, a2) then return end end
    if event == "UI_ERROR_MESSAGE" then
        -- Text der Spielmeldung merken (a1 = Nummer, a2 = Text; ältere Clients: a1 = Text)
        local msg = type(a2) == "string" and a2 or (type(a1) == "string" and a1 or nil)
        if msg and Se.pendingPost and Now() - Se.pendingPost.time < 5 then Se.lastUIError = { msg = msg, time = Now() } end
        return
    elseif event == "AUCTION_HOUSE_SHOW" then
        Se:HookBlizzardPost()
        return
    end
    if event == "OWNED_AUCTIONS_UPDATED" then
        Se:ReadOwned()
    elseif event == "AUCTION_HOUSE_AUCTION_CREATED" then
        local p = Se.pendingPost
        local ext = Se.externalPost
        if not p and ext and Now() - ext.time < 5 then
            -- B2a: fremd eingestellt - still buchen (Einzahlung aus der Gold-Differenz, sonst Formel)
            Se.externalPost = nil
            local function book()
                local after = GetMoney and GetMoney()
                local m = (ext.money and after) and (ext.money - after) or nil
                if m and (m <= 0 or (ext.deposit and ext.deposit > 0 and m > ext.deposit * 10 + 10000)) then m = nil end
                ext.measured = m
                A:Fire("AUCTION_POSTED", ext, a1)
            end
            if C_Timer and C_Timer.After then C_Timer.After(0.5, book) else book() end
            return
        end
        if p then
            Se.pendingPost = nil
            -- tatsächlich abgezogene Gebühr: Gold vorher - nachher (nur wenn plausibel: 0 < x <= 10x Spiel-Wert)
            -- Testmodus/Testroutine: nur simuliert eingestellt -> nichts messen (keine echten Daten schreiben)
            if not A:Simulated() then
                local function Measure()
                    local after = GetMoney and GetMoney()
                    local m = (p.money and after) and (p.money - after) or nil
                    -- unplausibel (Post, Handel o. ä. dazwischen): nicht protokollieren
                    if m and (m <= 0 or (p.deposit and p.deposit > 0 and m > p.deposit * 10 + 10000)) then m = nil end
                    return m
                end
                local measured = Measure()
                p.measured = measured
                if measured or not (C_Timer and C_Timer.After) then
                    pcall(Se.RecordDeposit, Se, p, measured)
                else
                    -- Gold oft erst nach dem Ereignis abgebucht: kurz danach noch einmal, falls kein neues Angebot dazwischen
                    Se.postSeq = (Se.postSeq or 0) + 1
                    local seq = Se.postSeq
                    C_Timer.After(0.5, function()
                        local m = (Se.postSeq == seq and not Se.pendingPost) and Measure() or nil
                        pcall(Se.RecordDeposit, Se, p, m)
                    end)
                end
            end
            local msg = string.format(L["|cff33dd55Eingestellt:|r %dx %s für %s/Stück"], p.qty, A:GetItemName(p.itemID), A:FormatMoney(p.unitPrice))
            if p.deposit then
                msg = msg .. string.format(L[" (Einstellgebühr %s)"], A:FormatMoney(p.measured or p.deposit))
            end
            if p.left and p.left > 0 then msg = msg .. string.format(L[" - noch %d: nochmal 'Einstellen' klicken"], p.left) end
            A:Print(msg)
            A:Fire("AUCTION_POSTED", p, a1)
            Se.lastPosted = p
        end
        Se:QueryOwned()
    elseif event == "AUCTION_CANCELED" then
        Se:OnCanceled(a1)
    elseif event == "AUCTION_HOUSE_SHOW_ERROR" then
        if Se.pendingPost and Now() - Se.pendingPost.time < 5 then
            -- kurz warten: UI_ERROR_MESSAGE mit dem Text kann direkt danach kommen
            local code, seq = a1, Se.pendingPost
            if C_Timer and C_Timer.After then
                C_Timer.After(0.3, function() if Se.pendingPost == seq then Se:PostFailed(code) end end)
            else
                Se:PostFailed(code)
            end
        elseif Se.pendingCancel and Now() - Se.pendingCancel.time < 5 then
            Se:CancelLog("Fehlermeldung des Servers: " .. tostring(a1))
            Se.pendingCancel = nil
            A:Print(L["|cffff5544Abbrechen fehlgeschlagen.|r"])
            A:Fire("SELLER_CHANGED")
        end
    elseif event == "BAG_UPDATE" or event == "BAG_UPDATE_DELAYED" then
        bagDirty = true
        bagCache = nil
    end
end)

-- Ergebnisse sofort auswerten, sobald der Server sie meldet
A:On("SEARCH_RESULTS", function()
    if Se.search then Se.search.answered = true; Se:PollSearch() end
end)
A:On("QUERY_READY", function()
    if not Se.search then Se:StartNext() end
end)

local ticker = CreateFrame("Frame")
local acc, bagAcc = 0, 0
ticker:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    bagAcc = bagAcc + (dt or 0)
    if acc >= 0.1 then
        acc = 0
        if Se.search then Se:PollSearch() else Se:StartNext() end
        if Se.undercutBatch and Now() - Se.undercutBatch.started > 90 then Se:BatchDone(nil, true) end
        if Se.pendingPost and Now() - Se.pendingPost.time > 10 then Se.pendingPost = nil; A:Fire("SELLER_CHANGED") end
    end
    -- Taschenänderungen gesammelt melden (nicht bei jedem einzelnen Ereignis)
    if bagDirty and bagAcc >= 0.5 then
        bagAcc, bagDirty = 0, false
        A:Fire("SELLER_CHANGED")
    end
end)

A:On("AH_STATE", function()
    if A:IsAHOpen() then
        C_Timer.After(1, function() if A:IsAHOpen() then Se:QueryOwned() end end)
    else
        Se.search = nil
        wipe(Se.queue); wipe(Se.bgQueue)
        Se.pendingPost, Se.pendingCancel = nil, nil
        if Se.batch then Se:StopBatch() end
    end
    A:Fire("SELLER_CHANGED")
end)

function Se:GetDebugText()
    local C = A.AH
    local function yn(v) return v and L["ja"] or L["nein"] end
    return "PostCommodity=" .. yn(C and C.PostCommodity) .. ", PostItem=" .. yn(C and C.PostItem)
        .. ", Eigene=" .. yn(C and C.QueryOwnedAuctions) .. ", Abbrechen=" .. yn(C and C.CancelAuction)
        .. ", C_Container=" .. yn(C_Container) .. ", ItemLocation=" .. yn(ItemLocation)
        .. ", Auktionen=" .. #self.owned .. ", Warteschlange=" .. #self.queue
end

-- ------------------------------------------------------------
-- Verkaufs-Meldung: sobald eine Auktion verkauft ist (Systemnachricht des Spiels)
-- Meldung mit Erlös (netto nach AH-Anteil) und Gewinn gegenüber deinem Einkauf
-- ------------------------------------------------------------
local function SoldPattern(text)
    local s = text or _G.ERR_AUCTION_SOLD_S
    -- "%s" oder mit Positionsangabe "%1$s" (manche Sprachfassungen)
    if type(s) ~= "string" or not (s:find("%%s") or s:find("%%%d%$s")) then return nil end
    -- Text des Spiels in ein Suchmuster verwandeln: "%s" = Item-Name
    local p = s:gsub("%%(%d)%$s", "\1"):gsub("%%s", "\1")      -- Platzhalter vorübergehend als Steuerzeichen
    p = p:gsub("([%(%)%.%[%]%*%+%-%?%^%$%%])", "%%%1")
    p = p:gsub("\1", "(.+)")
    return "^" .. p .. "$"
end
Se.SoldPattern = SoldPattern      -- nur lesen (Testroutine T130/T199)

function Se:SaleAlertEnabled()
    return not (A.db and A.db.settings.saleAlert == false)
end

-- Item-Name aus der Meldung -> passende eigene Auktion (für den Preis)
function Se:FindOwnedByName(name)
    local lname = string.lower(name or "")
    for _, o in ipairs(self.owned or {}) do
        if o.itemID and not o.alerted then
            local n1 = A:GetClientItemName(o.itemID)
            local n2 = A:GetItemName(o.itemID)
            if (n1 and string.lower(n1) == lname) or (n2 and string.lower(n2) == lname) then return o end
        end
    end
    return nil
end

Se.saleMsg = Se.saleMsg or { secret = 0, readable = 0 }
function Se:OnSold(name)
    local o = self:FindOwnedByName(name)
    self.saleMsg.readable = self.saleMsg.readable + 1
    -- BP4: ausstehend buchen (altes AH: Meldung ist die einzige Quelle; neues AH: Abgleich über die auctionID)
    if o and not o.bookedSale then o.bookedSale = true; A:Fire("OWN_AUCTION_SOLD", o) end
    if not self:SaleAlertEnabled() then return end
    local itemID = o and o.itemID or (A.FindItemByName and A:FindItemByName(name))
    local qty = o and o.qty or 1
    local gross = o and o.buyout or (itemID and A:GetMarketValue(itemID) and math.floor(A:GetMarketValue(itemID) * qty)) or nil
    if o then o.alerted = true; o.sold = true; o.status = "verkauft" end
    local parts = { "|cff33dd55" .. L["Verkauft:"] .. "|r " .. qty .. "x " .. (itemID and A:GetItemName(itemID) or name) }
    if gross and gross > 0 then
        local _, _, net = self:Proceeds(math.floor(gross / math.max(1, qty)), qty, itemID, 1)
        table.insert(parts, L["für "] .. A:FormatMoney(gross) .. " (" .. L["netto "] .. A:FormatMoney(net) .. ")")
        local avgBuy = itemID and A.Ledger and A.Ledger.AverageBuyPrice and A.Ledger:AverageBuyPrice(itemID, 30)
        if avgBuy and avgBuy > 0 then
            local profit = net - avgBuy * qty
            local col = profit >= 0 and "|cff33dd55+" or "|cffff5544-"
            table.insert(parts, L["Gewinn "] .. col .. A:FormatMoney(math.abs(profit)) .. "|r")
        end
    end
    local msg = table.concat(parts, "  ") .. "  |cffaaaaaa- " .. L["Gold im Briefkasten abholen"] .. "|r"
    A:Print(msg)
    if UIErrorsFrame and UIErrorsFrame.AddMessage then
        pcall(UIErrorsFrame.AddMessage, UIErrorsFrame, L["Verkauft:"] .. " " .. qty .. "x " .. (itemID and A:GetItemName(itemID) or name), 0.2, 0.87, 0.33)
    end
    if A.db and A.db.settings.alertSound and PlaySound then pcall(PlaySound, 120) end   -- Münzklang
    self.lastSale = { name = name, itemID = itemID, qty = qty, gross = gross, time = Now() }
    A:Fire("SELLER_CHANGED")
end

local saleFrame = CreateFrame("Frame")
Se.saleFrame = saleFrame        -- für die Testroutine
saleFrame:RegisterEvent("CHAT_MSG_SYSTEM")
saleFrame:SetScript("OnEvent", function(_, event, msg)
    -- Punkt 0 (Befund 10.11.): geschützte Werte (WoW Forever "secret string") nie indizieren
    do local G = _G.GoldSentinelGame; if G and G.AnySecret and G.AnySecret(msg) then
        Se.saleMsg = Se.saleMsg or { secret = 0, readable = 0 }
        Se.saleMsg.secret = Se.saleMsg.secret + 1        -- Messauftrag: wie oft ist die Systemmeldung geschützt
        return
    end end
    if event ~= "CHAT_MSG_SYSTEM" or type(msg) ~= "string" then return end
    local pat = SoldPattern()
    -- Befund 20:15 B1: Vorlage des Spiels und Muster einmal je Sitzung ins Protokoll (ohne Namen)
    if not Se.soldLogged and A.Diag then
        Se.soldLogged = true
        A.Diag:Add("VERKAUF-MELDUNG", string.format("Vorlage %s · Muster %s", tostring(_G.ERR_AUCTION_SOLD_S), pat and "ja" or "nein"))
    end
    local name = pat and msg:match(pat)
    if name and not Se.soldMatchLogged and A.Diag then
        Se.soldMatchLogged = true
        A.Diag:Add("VERKAUF-MELDUNG", "erkannt, Item " .. tostring(A.FindItemByName and A:FindItemByName(name) or "?"))
    end
    if name then
        local ok, err = pcall(Se.OnSold, Se, name)
        if not ok then A:ReportError("Verkauft", err) end   -- (bis 0.65.5 verschluckt: A.Debug gab es nie)
    end
end)
