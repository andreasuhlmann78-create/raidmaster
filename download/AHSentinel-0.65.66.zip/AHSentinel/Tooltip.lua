if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.8 - Preise und Preisverlauf im Item-Tooltip
--
-- Überall, wo WoW einen Item-Tooltip zeigt (Taschen, Auktionshaus,
-- Chat-Links, Listen anderer Addons, unsere eigenen Tabellen):
--   * zusätzliche Zeilen: aktueller Preis (mit % vom Marktwert),
--     Marktwert (Median 14 Tage), Trend 24 Std., Händlerpreis
--   * ein kleines Preisdiagramm direkt unter dem Tooltip
-- Beides lässt sich in den Optionen ein- und ausschalten.
-- Fehler in diesem Modul dürfen den Tooltip nie kaputt machen (pcall).
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local TT = {}
A.Tooltip = TT

local CW, CH = 240, 92                  -- Größe des Diagramms
local PAD_L, PAD_R, PAD_T, PAD_B = 6, 6, 20, 16

-- wählbare Zeiträume für das Diagramm (0 = aus)
TT.PERIODS = { 0, 1, 7, 30 }
local PERIOD_LABEL = { [1] = "24 Std.", [7] = "7 Tage", [30] = "30 Tage" }

function TT:Settings()
    local s = A.db and A.db.settings
    return s
end

function TT:ChartDays()
    local s = self:Settings()
    if not s then return 0 end
    local d = s.tooltipChartDays
    if d == nil then d = 7 end
    return d
end

function TT:PeriodLabel(days)
    days = days or self:ChartDays()
    if days == 0 then return L["aus"] end
    return L[PERIOD_LABEL[days] or "7 Tage"]
end

function TT:CycleChartDays()
    local s = self:Settings()
    if not s then return end
    local cur, i = self:ChartDays(), 1
    for k, d in ipairs(self.PERIODS) do if d == cur then i = k end end
    i = (i % #self.PERIODS) + 1
    s.tooltipChartDays = self.PERIODS[i]
    return s.tooltipChartDays
end

-- ------------------------------------------------------------
-- Diagramm-Fenster (wird einmal gebaut und wiederverwendet)
-- ------------------------------------------------------------
local chart

local function GetChart()
    if chart then return chart end
    local UI, C = A.UI, A.UI.C
    local f = CreateFrame("Frame", "AHAnalyzerProTooltipChart", UIParent)
    f:SetSize(CW, CH)
    f:SetFrameStrata("TOOLTIP")
    f:SetClampedToScreen(true)
    f:EnableMouse(false)
    UI:Box(f, { 0.03, 0.03, 0.05, 0.92 }, C.border)
    f:Hide()

    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    f.title:SetPoint("TOPLEFT", 6, -5)
    f.title:SetJustifyH("LEFT")
    f.high = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.high:SetPoint("TOPRIGHT", -6, -5)
    f.high:SetJustifyH("RIGHT")
    f.low = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.low:SetPoint("BOTTOMRIGHT", -6, 3)
    f.low:SetJustifyH("RIGHT")
    f.from = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    f.from:SetPoint("BOTTOMLEFT", 6, 3)
    f.from:SetJustifyH("LEFT")

    f.lines, f.dots, f.used = {}, {}, { lines = 0, dots = 0 }
    f.canRotate = true

    function f:Clear()
        for _, t in ipairs(self.lines) do t:Hide() end
        for _, t in ipairs(self.dots) do t:Hide() end
        self.used.lines, self.used.dots = 0, 0
        if self.avg then self.avg:Hide() end
    end

    function f:Dot(x, y, size, r, g, b, a)
        self.used.dots = self.used.dots + 1
        local t = self.dots[self.used.dots]
        if not t then
            t = self:CreateTexture(nil, "OVERLAY")
            self.dots[self.used.dots] = t
        end
        t:SetColorTexture(r, g, b, a or 1)
        t:SetSize(size, size)
        t:ClearAllPoints()
        t:SetPoint("CENTER", self, "BOTTOMLEFT", x, y)
        t:Show()
    end

    function f:Line(x1, y1, x2, y2, r, g, b)
        local dx, dy = x2 - x1, y2 - y1
        local len = math.sqrt(dx * dx + dy * dy)
        if len < 0.5 then return end
        if self.canRotate then
            self.used.lines = self.used.lines + 1
            local t = self.lines[self.used.lines]
            if not t then
                t = self:CreateTexture(nil, "ARTWORK")
                self.lines[self.used.lines] = t
            end
            t:SetColorTexture(r, g, b, 0.95)
            t:ClearAllPoints()
            t:SetSize(len, 2)
            t:SetPoint("CENTER", self, "BOTTOMLEFT", (x1 + x2) / 2, (y1 + y2) / 2)
            local ok = t.SetRotation and pcall(t.SetRotation, t, math.atan2(dy, dx))
            if ok then
                t:Show()
                return
            end
            t:Hide()
            self.canRotate = false
        end
        -- Rückfall ohne Drehen: Linie aus kleinen Punkten
        local steps = math.min(40, math.max(2, math.floor(len / 2)))
        for i = 0, steps do
            self:Dot(x1 + dx * i / steps, y1 + dy * i / steps, 2, r, g, b, 0.95)
        end
    end

    chart = f
    return f
end

-- Preispunkte des Zeitraums
local function Points(itemID, days)
    local out = {}
    local limit = time() - days * 86400
    for _, e in ipairs(A:GetHistory(itemID)) do
        if e.t >= limit and e.p and e.p > 0 and not e.u then table.insert(out, e) end      -- ohne unbestätigte (Lockangebote)
    end
    return out
end

function TT:HideChart(owner)
    if chart and (owner == nil or chart.owner == owner) then
        chart:Hide()
        chart.owner = nil
    end
end

function TT:ShowChart(tooltip, itemID)
    local days = self:ChartDays()
    if days == 0 then return self:HideChart() end
    local points = Points(itemID, days)
    if #points < 2 then return self:HideChart() end

    local f = GetChart()
    local C = A.UI.C
    f:Clear()

    local w = CW
    local tw = tooltip.GetWidth and tooltip:GetWidth()
    if tw and tw > w then w = tw end
    f:SetWidth(w)

    local minP, maxP = points[1].p, points[1].p
    for _, e in ipairs(points) do
        if e.p < minP then minP = e.p end
        if e.p > maxP then maxP = e.p end
    end
    local lo, hi = minP, maxP
    if hi == lo then lo, hi = lo * 0.9, hi * 1.1 + 1 end
    local minT, maxT = points[1].t, points[#points].t
    if maxT == minT then maxT = minT + 1 end

    local plotW, plotH = w - PAD_L - PAD_R, CH - PAD_T - PAD_B
    local function X(t) return PAD_L + (t - minT) / (maxT - minT) * plotW end
    local function Y(p) return PAD_B + (p - lo) / (hi - lo) * plotH end

    -- Linie beim Marktwert (Median der gezeigten Preise)
    local values = {}
    for i, e in ipairs(points) do values[i] = e.p end
    local avg = A.Median(values)
    if not f.avg then f.avg = f:CreateTexture(nil, "BORDER") end
    f.avg:SetColorTexture(1, 0.8, 0.2, 0.35)
    f.avg:ClearAllPoints()
    f.avg:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", PAD_L, Y(avg))
    f.avg:SetSize(plotW, 1)
    f.avg:Show()

    -- Steigt der Preis -> grün, fällt er -> rot, sonst Akzentfarbe
    local first, last = points[1].p, points[#points].p
    local col = C.accent
    if last > first * 1.02 then col = C.green elseif last < first * 0.98 then col = C.red end

    local px, py
    for _, e in ipairs(points) do
        local x, y = X(e.t), Y(e.p)
        if px then f:Line(px, py, x, y, col[1], col[2], col[3]) end
        px, py = x, y
    end
    f:Dot(px, py, 5, 1, 1, 1, 1)          -- aktueller Preis

    f.title:SetText("|cff00d1d1AHSentinel|r  " .. string.format(L["Preisverlauf (%s)"], self:PeriodLabel(days)))
    f.high:SetText(A:FormatMoney(maxP, true))
    f.low:SetText(A:FormatMoney(minP, true))
    f.from:SetText(date("%d.%m.", minT) .. "  -  " .. date("%d.%m.", maxT))

    -- unter den Tooltip, oder darüber, wenn unten kein Platz ist
    f:ClearAllPoints()
    local bottom = tooltip.GetBottom and tooltip:GetBottom()
    if bottom and bottom < CH + 10 then
        f:SetPoint("BOTTOMLEFT", tooltip, "TOPLEFT", 0, 2)
    else
        f:SetPoint("TOPLEFT", tooltip, "BOTTOMLEFT", 0, -2)
    end
    f.owner = tooltip
    f:Show()
end

-- ------------------------------------------------------------
-- Zusätzliche Zeilen im Tooltip
-- ------------------------------------------------------------
function TT:AddLines(tooltip, itemID)
    local s = self:Settings()
    local showInfo = not (s and s.tooltipInfo == false)
    local vendor = (not s or s.tooltipVendor ~= false) and A:GetVendorPrice(itemID) or nil
    -- beim Händler zeigt WoW den Verkaufspreis selbst an
    if vendor and type(MerchantFrame) == "table" and MerchantFrame.IsShown and MerchantFrame:IsShown() then vendor = nil end
    if vendor and vendor <= 0 then vendor = nil end
    if not showInfo and not vendor then return end
    tooltip:AddLine(" ")
    -- Addon in einer anderen Sprache als der Client: Item-Namen in der Sprache des Addons zeigen
    -- (den Titel des Tooltips schreibt WoW immer in der Sprache des Clients)
    local N = A.Names
    if N and N.DisplayLocale and N:DisplayLocale() ~= N:ClientLocale() then
        local nm = N:Get(itemID)
        if nm then tooltip:AddLine("|cff00d1d1AHSentinel|r  " .. nm, 1, 1, 1) end
    end
    if not showInfo then
        tooltip:AddDoubleLine("|cff00d1d1AHSentinel|r  " .. L["Händlerpreis"], A:FormatMoney(vendor), 1, 1, 1, 1, 1, 1)
        return
    end
    -- Variante A (Anweisung 14:50): ohne Shift genau drei Blöcke - Preis, Urteil, Materialien.
    -- Alles andere (Realer Wert mit Rechnung, Median, Trend, Absatz, Händler, Verkaufschance, Twinks ...) mit Shift
    -- bzw. Einstellung "alles".
    local isShift = A:Global("IsShiftKeyDown")
    local shift = isShift and isShift() or false
    local all = shift or self:DEMode() == "all"
    local cur = A:GetCurrent(itemID)
    local mv = A:GetMarketValue(itemID)
    local bag = self:OwnBagTooltip()
    if not cur and not mv then
        tooltip:AddLine(L["AHSentinel: noch keine Preisdaten"], 0.6, 0.6, 0.6)
        if vendor then tooltip:AddDoubleLine(L["Händlerpreis"], A:FormatMoney(vendor), 0.8, 0.8, 0.8, 1, 1, 1) end
        self:AddBlock2(tooltip, itemID, all)
        TT:AddExtraLines(tooltip, itemID, all)
        return
    end
    -- Block 1: Preis
    if bag or not cur then
        tooltip:AddDoubleLine("|cff00d1d1AHSentinel|r", L["Marktwert"] .. " " .. A:FormatMoney(mv or cur), 1, 1, 1, 1, 1, 1)
    else
        -- B5 (10.11.): gerechnet wird nur mit Preisen aus dem letzten Scan (A:PriceInfo). Nicht im Scan -> "(alt)";
        -- im Scan, aber als Ausreisser ersetzt -> der Rechenwert dahinter. Sonst stünde "Preis 17c" neben "Verkaufen: 21c".
        local pinfo = A:PriceInfo(itemID)
        local mark = ""
        if pinfo and not pinfo.inScan then
            mark = " |cffff9933(" .. L["alt"] .. ")|r"
        elseif pinfo and pinfo.value and pinfo.value ~= cur then
            mark = " |cff999999(" .. string.format(L["gerechnet %s"], A:FormatMoney(pinfo.value)) .. ")|r"
        end
        tooltip:AddDoubleLine("|cff00d1d1AHSentinel|r", L["Preis"] .. " " .. A:FormatMoney(cur) .. mark, 1, 1, 1, 1, 1, 1)
        if mv and mv ~= cur then tooltip:AddDoubleLine(L["Marktwert"], A:FormatMoney(mv), 0.8, 0.8, 0.8, 1, 1, 1) end
    end
    -- F2: eigene Verkaufsdauer als letzte Zeile von Block 1 (ohne Shift)
    local speedText, speedColor = nil, nil
    if A.Ledger and A.Ledger.SellSpeedText then
        local okS, t, c = pcall(A.Ledger.SellSpeedText, A.Ledger, itemID)
        if okS then speedText, speedColor = t, c end
    end
    if speedText then
        tooltip:AddDoubleLine(L["Verkauft sich:"], speedText, 0.8, 0.8, 0.8, speedColor[1], speedColor[2], speedColor[3])
    end
    -- Block 2 und 3
    self:AddBlock2(tooltip, itemID, all)
    -- nur mit Shift: Realer Wert mit Quelle und Rechnung, Absatz, Trend, Händler
    if all then
        local okR, rv, rp, rinfo, vendorWins = pcall(A.RealValue, A, itemID, 1)
        if okR and rv then
            local src = vendorWins and L["Händler"] or (rinfo and (rinfo.source == "sale" and L["eigener Verkauf"]
                or (rinfo.source == "ah" and L["Scan"] or L["Markt"]))) or ""
            local extra = (rinfo and rinfo.old) and (" |cffff9933" .. L["Preis alt"] .. "|r") or ""
            tooltip:AddDoubleLine(L["Realer Wert (nach Gebühren)"], A:FormatMoney(rv) .. " |cff999999" .. src .. "|r" .. extra, 0.8, 0.8, 0.8, 1, 1, 1)
            if rinfo then
                -- eigener Ø-Verkaufspreis: nur Statistik (K3), gelb wenn mehr als 30 % unter dem Markt
                if rinfo.sale then
                    local low = rinfo.median and rinfo.median > 0 and rinfo.sale < rinfo.median * 0.7
                    tooltip:AddDoubleLine("   " .. L["eigener Verkauf (14 Tage)"] .. (low and (" |cffffcc33(" .. L["unter Markt"] .. ")|r") or ""),
                        A:FormatMoney(rinfo.sale), 0.6, 0.6, 0.6, low and 1 or 0.8, low and 0.8 or 0.8, low and 0.2 or 0.8)
                end
                if rinfo.current then tooltip:AddDoubleLine("   " .. L["günstigstes Angebot"] .. (rinfo.unsure and (" (" .. L["Angebot unsicher"] .. ")") or ""),
                    A:FormatMoney(rinfo.current), 0.6, 0.6, 0.6, 0.8, 0.8, 0.8) end
                if rinfo.median then tooltip:AddDoubleLine("   " .. L["Median 14 Tage"], A:FormatMoney(rinfo.median), 0.6, 0.6, 0.6, 0.8, 0.8, 0.8) end
                if rp and not vendorWins then tooltip:AddDoubleLine("   " .. L["Gebühr"], A:FormatMoney(rp - (rv or rp) - (rinfo.relistCost or 0)), 0.6, 0.6, 0.6, 0.8, 0.8, 0.8) end
                if rinfo.relistCost and rinfo.relistCost > 0 and not vendorWins then
                    tooltip:AddDoubleLine("   " .. string.format(rinfo.relistWhy == "own" and L["~%.1fx einstellen (deine Verkaufsquote)"]
                        or L["~%.1fx einstellen (wenig Absatz)"], rinfo.listings), "-" .. A:FormatMoney(rinfo.relistCost), 0.6, 0.6, 0.6, 0.8, 0.8, 0.8)
                end
            end
        end
        if mv and A.LiquidityText then
            local ok, txt = pcall(A.LiquidityText, A, itemID)
            if ok and txt then tooltip:AddLine(txt, 0.75, 0.75, 0.75) end
        end
        local trend = A:GetTrend(itemID, 86400)
        if trend then tooltip:AddDoubleLine(L["Trend 24 Std."], A:FormatPercent(trend), 0.8, 0.8, 0.8, 1, 1, 1) end
        if vendor then
            local color = (cur and vendor > cur) and "|cff33dd55" or ""
            tooltip:AddDoubleLine(L["Händlerpreis"], color .. A:FormatMoney(vendor) .. (color ~= "" and "|r" or ""), 0.8, 0.8, 0.8, 1, 1, 1)
        end
    end
    TT:AddExtraLines(tooltip, itemID, all)
    local w = A.db.watchlist[itemID]
    if w and (w.buyBelow or w.sellAbove) then
        local parts = {}
        if w.buyBelow then table.insert(parts, L["Kaufen <"] .. " " .. A:FormatMoney(w.buyBelow, true)) end
        if w.sellAbove then table.insert(parts, L["Verkaufen >"] .. " " .. A:FormatMoney(w.sellAbove, true)) end
        tooltip:AddDoubleLine(L["Watchlist"], table.concat(parts, "  "), 0.8, 0.8, 0.8, 1, 1, 1)
    end
end

-- Block 2 (Urteil) und Block 3 (Materialien). Nicht entzauberbar: nur "Verkaufen:" (bzw. Händler, falls besser).
-- P5 (Nachprüfung 07:40): Entzauberwert nachprüfbar - einmal je Item und Tag ins Protokoll (ohne Namen):
-- Quelle, je Material Chance / Ø Menge / Preis netto, Ergebnis brutto und netto
TT.deLogged = {}
function TT:LogDEValue(itemID)
    if not (A.Diag and itemID) or (A.TestRoutine and A.TestRoutine.running) then return end
    local day = math.floor(time() / 86400)
    if self.deLogged[itemID] == day then return end
    local D = A.Disenchant
    if not (D and D.DealValue and D.Prior and D:Prior(itemID)) then return end
    local okV, v, net, _, basis, n = pcall(D.DealValue, D, itemID)
    if not (okV and v) then return end
    self.deLogged[itemID] = day
    local okM, mats = pcall(self.DisenchantMats, self, itemID)
    local parts = {}
    for _, m in ipairs(okM and mats or {}) do
        local netP = m.price and (A:IsForever() and (m.price - (A:FeePerPiece(m.id, m.price) or 0)) or m.price * (1 - A:CutPct()))
        parts[#parts + 1] = string.format("%s %.0f%% × %.2f à %s", tostring(m.id), (m.chance or 0) * 100, m.avg or 0,
            netP and tostring(math.floor(netP + 0.5)) or "?")
    end
    pcall(A.Diag.Add, A.Diag, "ENTZAUBERWERT", string.format("Item %d · %s · %s · brutto %d · netto %d", itemID,
        basis == "actual" and string.format("eigene Ø aus %d", n or 0) or "Tabelle", table.concat(parts, ", "), math.floor(v + 0.5),
        math.floor((net or 0) + 0.5)))
end

function TT:AddBlock2(tooltip, itemID, all)
    local s = self:Settings() or {}
    if A.LogAbsatz then pcall(A.LogAbsatz, A, itemID) end
    pcall(self.LogDEValue, self, itemID)
    local D = A.Disenchant
    local deOK = s.tooltipDE ~= false and D and D.Prior and D:Prior(itemID)
    if deOK then
        tooltip:AddLine(" ")
        local ok, n = pcall(self.AddDisenchantLines, self, tooltip, itemID, nil, all)
        if ok and n then
            if all then self:AddOutlookLine(tooltip, itemID) end
            return
        end
    end
    local okR, rv, _, _, vendorWins = pcall(A.RealValue, A, itemID, 1)
    if okR and rv then
        tooltip:AddLine(" ")
        tooltip:AddDoubleLine(vendorWins and L["Händler:"] or L["Verkaufen:"], A:FormatMoney(rv), 0.8, 0.8, 0.8, 1, 1, 1)
        self:AddBagTotal(tooltip, itemID)
        if all then self:AddOutlookLine(tooltip, itemID) end
    end
end

-- A5 (Angebot und Absatz): nur mit Shift eine kurze Begründung - "150 im AH · ~5/Tag · ~30 Tage · 4 Einstellungen"
function TT:OutlookText(itemID)
    local ok, v = pcall(A.SellOutlook, A, itemID, 1, (A:RealPrice(itemID)))
    if not (ok and v) then return nil end
    local parts = {}
    if v.queue then parts[#parts + 1] = string.format(L["%d im AH"], v.queue) end
    if v.perDay then
        parts[#parts + 1] = string.format(L["~%s/Tag"], v.perDay >= 10 and tostring(math.floor(v.perDay + 0.5)) or string.format("%.1f", v.perDay))
    end
    if v.wait then parts[#parts + 1] = string.format(L["~%d Tage"], math.max(1, math.floor(v.wait + 0.5))) end
    if v.rare then parts[#parts + 1] = L["verkauft sich kaum"]
    elseif v.listings then parts[#parts + 1] = string.format(v.listings == 1 and L["%d Einstellung"] or L["%d Einstellungen"], v.listings) end
    if v.unsure then parts[#parts + 1] = L["unsicher (wenig Scans)"] end
    if #parts == 0 then return nil end
    return table.concat(parts, " · "), v
end

function TT:AddOutlookLine(tooltip, itemID)
    local text, v = self:OutlookText(itemID)
    if not text then return end
    tooltip:AddLine("   " .. text, (v and v.rare) and 1 or 0.6, (v and v.rare) and 0.6 or 0.6, (v and v.rare) and 0.2 or 0.6)
end

-- Wunsch des Nutzers (10.11. 06:13, Anweisung Gesamtwert): stapelbar und mindestens 2 Stück in den Taschen (ohne Bank)
-- -> Gesamtwert aller Stapel, dieselbe Rechnung wie "Verkaufen:" mit der ganzen Menge (A:RealValue)
function TT:BagCount(itemID)
    local f = A:Global("GetItemCount")
    if not f then local CI = A:Global("C_Item"); f = CI and CI.GetItemCount end
    local ok, n = pcall(function() return f and f(itemID) end)
    return (ok and type(n) == "number") and n or 0
end

function TT:IsStackable(itemID)
    local ok, maxStack = pcall(function() return select(8, GetItemInfo(itemID)) end)
    return ok and type(maxStack) == "number" and maxStack > 1
end

function TT:AddBagTotal(tooltip, itemID)
    local n = self:BagCount(itemID)
    if n < 2 or not self:IsStackable(itemID) then return end
    local okT, total = pcall(A.RealValue, A, itemID, n)
    if not (okT and total) then return end
    tooltip:AddDoubleLine(string.format(L["%d in den Taschen:"], n), A:FormatMoney(total), 0.8, 0.8, 0.8, 1, 1, 1)
end

-- Entzaubern im Tooltip: zwei klar getrennte Werte
--   "Entzaubern tatsächlich (Ø aus N)": nur echte Entzauberungen (eigene + geteilte), aktueller AH-Preis je Material
--   "Entzaubern geschätzt (Tabelle)":    D:GetValue (Tabelle verrechnet mit Ergebnissen)
-- detail = je Material eine Zeile und "nach Gebühren" (Einstellung, Standard an)
function TT:DisenchantLines(itemID, detail)
    local D = A.Disenchant
    local lines = {}            -- { left, right, dim }
    local function priceText(r)
        if not r.price then return L["kein Preis"] end
        local t = "AH " .. A:FormatMoney(r.price)
        if r.age then t = t .. " (" .. A:FormatAgo(time() - r.age) .. ")" end
        if r.mv and r.mv ~= r.price then t = t .. " · " .. string.format(L["Markt %s"], A:FormatMoney(r.mv)) end
        return t
    end
    local function share(r) return r.share and ("= " .. A:FormatMoney(math.floor(r.share + 0.5))) or "+?" end
    -- tatsächlich
    local av, acomplete, n, arows = D:ActualValue(itemID)
    if av then
        local label = string.format(L["Entzaubern tatsächlich (Ø aus %d)"], n)
        if n < D.FEW_DATA then label = label .. " " .. L["(wenig Daten)"] end
        table.insert(lines, { label, A:FormatMoney(av) .. (acomplete and "" or " +?") })
        if detail then
            for _, r in ipairs(arows) do
                table.insert(lines, { string.format("   %s  %d/%d × Ø %.1f · %s", A:GetItemName(r.id) or ("#" .. r.id), r.times, n,
                    r.total / r.times, priceText(r)), share(r), true })
            end
            table.insert(lines, { "   " .. L["nach Gebühren"], A:FormatMoney(D:ActualNet(av, arows, n)) .. (acomplete and "" or " +?"), true })
        end
    end
    -- geschätzt
    local v, complete, yield = D:GetValue(itemID)
    if v then
        table.insert(lines, { L["Entzaubern geschätzt (Tabelle)"], "~" .. A:FormatMoney(v) .. (complete and "" or " +?") })
        if detail then
            for _, r in ipairs(D:EstimateRows(itemID) or {}) do
                table.insert(lines, { string.format("   %s  %d%% × Ø %.1f · %s", A:GetItemName(r.id) or ("#" .. r.id),
                    math.floor(r.chance * 100 + 0.5), r.avg, priceText(r)), share(r), true })
            end
            table.insert(lines, { "   " .. L["nach Gebühren"], "~" .. A:FormatMoney(D:NetValue(v, yield)) .. (complete and "" or " +?"), true })
        end
    end
    -- womit die Schnäppchen rechnen
    if detail and (av or v) then
        local _, _, _, basis = D:DealValue(itemID)
        if basis then
            table.insert(lines, { "   " .. (basis == "actual" and L["Schnäppchen rechnen mit: tatsächlich"]
                or L["Schnäppchen rechnen mit: geschätzt"]), "", true })
        end
    end
    return lines
end

-- Kurzform (0.65.26, Wunsch des Nutzers): EINE Zeile "Entzaubern: erwarteter Gewinn ~X" (Wert nach Gebühren),
-- dahinter klein der Vergleich mit dem Verkauf des Items und die Quelle ("(Ø 12)" = aus 12 Entzauberungen,
-- "(T)" = Tabelle). Die ganze Rechnung läuft weiter (DisenchantLines), Shift zeigt sie.
-- zurück: { left, right, net, basis, n, sellNet } oder nil
function TT:DisenchantShort(itemID)
    local D = A.Disenchant
    local v, net, complete, basis, n = D:DealValue(itemID)
    if not v then return nil end
    local mark = (basis == "actual") and string.format("(Ø %d)", n) or "(T)"
    -- Befund 9. Nov. 10:31: das ist der Entzauberungswert (hängt nur von der Gruppe ab), kein Gewinn
    local left = L["Entzauberungswert"]
    local sellNet, _, _, vendorWins = A:RealValue(itemID, 1)
    if sellNet then
        left = left .. "  " .. ((net > sellNet) and ("|cff33dd55" .. (vendorWins and L["lohnt mehr als Händler"] or L["lohnt mehr als Verkauf"]) .. "|r")
            or ("|cffff9933" .. (vendorWins and L["Händler bringt mehr"] or L["Verkauf bringt mehr"]) .. "|r"))
    end
    local res = { left = left, right = "~" .. A:FormatMoney(net) .. (complete and "" or " +?") .. " |cff999999" .. mark .. "|r",
        net = net, basis = basis, n = n, sellNet = sellNet }
    -- Gewinn beim Kauf: Wert - Kaufpreis (Kaufpreis aus der Zeile im Addon, beim Händler, sonst günstigstes Angebot)
    local buy, how = self:BuyPriceFor(itemID)
    if buy then
        local g = net - buy
        res.buy, res.gain = buy, g
        res.gainLeft = how == "list" and L["Gewinn beim Kauf"] or (how == "vendor" and L["Gewinn beim Kauf (Händler)"]
            or L["Gewinn beim Kauf (günstigstes Angebot)"])
        res.gainRight = (g >= 0 and ("|cff33dd55" .. A:FormatMoney(g)) or ("|cffff5544-" .. A:FormatMoney(-g))) .. "|r"
            .. " |cff999999(" .. A:FormatMoney(net) .. " − " .. A:FormatMoney(buy) .. ")|r"
    end
    return res
end

-- ------------------------------------------------------------
-- Entzauber-Urteil (Anweisung "Entzauber-Urteil", 9. Nov. 13:05): der Spieler sieht ohne Rechnen, ob es sich lohnt.
--   Gewinn    = Entzauberungswert (nach Gebühren, wie bisher) - Kaufpreis
--   Lohnt bis = Entzauberungswert / (1 + Mindestgewinn %)  (Mindestgewinn = Sammelkauf, Standard 20 %), abwärts
--   state     = "good" (Kaufpreis <= Lohnt bis), "bad" (sonst), "unsure" (Materialpreis fehlt oder unsicher)
-- zurück: { net, limit, buy, gain, state, how, sellNet, own } oder nil (nicht entzauberbar / kein Wert)
-- ------------------------------------------------------------
TT.ICON_GOOD = "|TInterface\\RaidFrame\\ReadyCheck-Ready:14:14:0:0|t "
TT.ICON_BAD = "|TInterface\\RaidFrame\\ReadyCheck-NotReady:14:14:0:0|t "

function TT:MinGainPct()
    local DEB = A.DEBuy
    return (DEB and DEB.MinRoi and DEB:MinRoi()) or 20
end

-- ist ein Material unsicher? (kein Preis, Angebot unsicher oder Markt nicht verlässlich)
function TT:MatsUnsure(itemID)
    local mats = self:DisenchantMats(itemID)
    for _, m in ipairs(mats) do
        if not m.price or m.unsure then return true end
        if A.IsReliable then
            local ok, rel = pcall(A.IsReliable, A, m.id)
            if ok and rel == false then return true end
        end
    end
    return false
end

-- eigenes Item in den Taschen (für die Zeile Verkauf/Entzaubern)?
function TT:OwnsItem(itemID)
    local f = A:Global("GetItemCount")
    if not f then return false end
    local ok, n = pcall(f, itemID)
    return ok and type(n) == "number" and n > 0
end

function TT:DisenchantVerdict(itemID)
    local D = A.Disenchant
    if not (D and D.DealValue) then return nil end
    local v, net, complete = D:DealValue(itemID)
    if not v or not net then return nil end
    local res = { net = net }
    res.limit = math.floor(net / (1 + self:MinGainPct() / 100))
    local unsure = (not complete) or self:MatsUnsure(itemID)
    local buy, how = self:BuyPriceFor(itemID)
    if buy then
        res.buy, res.how, res.gain = buy, how, net - buy
        if unsure then res.state = "unsure"
        elseif buy <= res.limit then res.state = "good"
        else res.state = "bad" end
    elseif unsure then
        res.state = "unsure"
    end
    res.own = self:OwnsItem(itemID)
    local _, _, _, vendorWins
    res.sellNet, _, _, vendorWins = A:RealValue(itemID, 1)
    res.sellVendor = vendorWins and true or false        -- Händler zahlt mehr bzw. "verkauft sich kaum" (Angebot/Absatz)
    return res
end

local function SignedMoney(v)
    if v >= 0 then return "+" .. A:FormatMoney(v) end
    return "−" .. A:FormatMoney(-v)
end

-- die zwei Urteilszeilen (ohne Shift genau diese); own items: nur Verkauf/Entzaubern
-- Zeilen 3-4 (Nachträge 14:16/14:18): beide Wege mit Betrag nach Gebühr, der bessere zuerst und farbig
function TT:AddWayLines(tooltip, r)
    local de, sell = r.net, r.sellNet
    if not sell then
        tooltip:AddDoubleLine(self.ICON_GOOD .. L["Entzaubern:"], A:FormatMoney(de), 0.2, 0.87, 0.33, 0.2, 0.87, 0.33)
        return 1
    end
    if de > sell then
        tooltip:AddDoubleLine(self.ICON_GOOD .. L["Entzaubern:"], A:FormatMoney(de), 0.2, 0.87, 0.33, 0.2, 0.87, 0.33)
        tooltip:AddDoubleLine(r.sellVendor and L["Händler:"] or L["Verkaufen:"], A:FormatMoney(sell), 0.6, 0.6, 0.6, 0.6, 0.6, 0.6)
    else
        tooltip:AddDoubleLine(self.ICON_BAD .. (r.sellVendor and L["Händler bringt mehr:"] or L["Verkaufen bringt mehr:"]),
            A:FormatMoney(sell), 1, 0.6, 0.2, 1, 0.6, 0.2)
        tooltip:AddDoubleLine(L["Entzaubern:"], A:FormatMoney(de), 0.6, 0.6, 0.6, 0.6, 0.6, 0.6)
    end
    return 2
end

function TT:AddVerdictLines(tooltip, itemID)
    local r = self:DisenchantVerdict(itemID)
    if not r then return 0 end
    local n = 0
    local bagItem = self:OwnBagTooltip() and r.how ~= "list"
    if bagItem then
        -- eigenes Item in den Taschen: nur die zwei Wege mit Betrag
        return self:AddWayLines(tooltip, r)
    end
    if r.buy then
        if r.state == "good" then
            tooltip:AddDoubleLine(self.ICON_GOOD .. L["Entzaubern lohnt sich"], SignedMoney(r.gain), 0.2, 0.87, 0.33, 0.2, 0.87, 0.33)
        elseif r.state == "bad" then
            tooltip:AddDoubleLine(self.ICON_BAD .. L["Entzaubern lohnt nicht"], SignedMoney(r.gain), 1, 0.33, 0.27, 1, 0.33, 0.27)
        else
            tooltip:AddDoubleLine(L["Entzaubern: unsicher"], SignedMoney(r.gain), 0.6, 0.6, 0.6, 0.6, 0.6, 0.6)
        end
        n = 1
    elseif r.state == "unsure" then
        tooltip:AddLine(L["Entzaubern: unsicher"], 0.6, 0.6, 0.6)
        n = 1
    end
    tooltip:AddDoubleLine(L["Lohnt bis"], A:FormatMoney(r.limit), 0.8, 0.8, 0.8, 1, 0.82, 0)
    n = n + 1
    return n + self:AddWayLines(tooltip, r)
end

-- Tooltip eines eigenen Taschen-Platzes? (gesetzt in TT:Handle über den Besitzer des Tooltips)
function TT:OwnBagTooltip() return self.bagTooltip == true end

-- Besitzer ist ein Taschen-Knopf? Modern: GetBagID am Knopf; alt: Name "ContainerFrameNItemM"
function TT:IsBagOwner(tooltip)
    local ok, res = pcall(function()
        local owner = tooltip.GetOwner and tooltip:GetOwner()
        if type(owner) ~= "table" then return false end
        if owner.GetBagID then return true end
        local name = owner.GetName and owner:GetName()
        local G = _G.GoldSentinelGame
        if G and G.AnySecret and G.AnySecret(name) then return false end
        if type(name) == "string" and name:match("^ContainerFrame%d+Item%d+$") then return true end
        return false
    end)
    return ok and res or false
end

-- Kaufpreis für "Gewinn beim Kauf": zuerst die Zeile, über der die Maus im Addon steht (Kaufliste, Sniper,
-- Schnäppchen: TT.buyContext), dann beim Händler dessen Preis, sonst das günstigste aktuelle Angebot (frisch)
TT.buyContext = nil
function TT:BuyPriceFor(itemID)
    local c = self.buyContext
    if c and c.itemID == itemID and c.price and c.price > 0 then return c.price, "list" end
    local atMerchant = type(MerchantFrame) == "table" and MerchantFrame.IsShown and MerchantFrame:IsShown()
    if atMerchant then
        local v = A:GetVendorBuyPrice(itemID)
        if v and v > 0 then return v, "vendor" end
    end
    local cur, _, t = A:GetCurrent(itemID)
    if cur and cur > 0 and t and time() - t <= A.PRICE_OLD_HOURS * 3600 then return cur, "ah" end
    return nil
end

-- Block "Entzaubern – Materialien (AHSentinel)" im Aussehen von "Mögliche Materialien": Icon · Name · Dropchance ·
-- Wert pro Stück (AH-Preis aus dem letzten Scan, sonst Marktwert). Chance aus derselben Quelle wie die Kurzzeile.
-- zurück: { { icon, name, chance (0-1), price, id }, ... }
function TT:DisenchantMats(itemID)
    local D = A.Disenchant
    local _, _, _, basis, n = D:DealValue(itemID)
    local out = {}
    if basis == "actual" then
        local _, _, nn, rows = D:ActualValue(itemID)
        for _, r in ipairs(rows or {}) do
            out[#out + 1] = { id = r.id, chance = r.times / nn, price = r.price, avg = r.total / r.times, source = r.source, unsure = r.unsure }
        end
    else
        for _, r in ipairs(D:EstimateRows(itemID) or {}) do
            out[#out + 1] = { id = r.id, chance = r.chance, price = r.price, avg = r.avg, min = r.min, max = r.max, source = r.source, unsure = r.unsure }
        end
    end
    for _, m in ipairs(out) do
        m.name = A:GetItemName(m.id) or ("#" .. m.id)
        m.icon = A.GetItemIcon and A:GetItemIcon(m.id) or nil
    end
    table.sort(out, function(a, b) return a.chance > b.chance end)
    return out, basis, n
end

-- Einstellung: "short" (nur die Zeile), "mats" (mit Materialien, Standard), "all" (ganze Aufstellung)
function TT:DEMode()
    local s = self:Settings() or {}
    local m = s.tooltipDEMode
    if m == "short" or m == "mats" or m == "all" then return m end
    if s.tooltipDEDetail == false then return "short" end     -- alte Einstellung (0.65.22-0.65.25)
    return "mats"
end

-- Block 2 (Urteil + Wege) und Block 3 (Materialien, ohne Shift - Variante A). all = Shift bzw. Einstellung "alles":
-- dazu Rechnung und Preisquellen. Rückgabe: Anzahl Zeilen (0 = nicht entzauberbar / kein Wert)
function TT:AddDisenchantLines(tooltip, itemID, mode, all)
    mode = mode or self:DEMode()
    if A.Spieltest and A.Spieltest.activeUntil then
        pcall(A.Spieltest.OnDETooltip, A.Spieltest, itemID, self:DisenchantLines(itemID, true))
    end
    if all == nil then
        local isShift = A:Global("IsShiftKeyDown")      -- über A:API: die Testroutine ersetzt nie die Blizzard-Funktion
        all = (isShift and isShift()) or mode == "all"
    end
    local n = self:AddVerdictLines(tooltip, itemID)
    if n == 0 then return 0 end
    -- Block 3: Materialien - immer (auch mit Disenchantry, das abgelöst wird), ausser Einstellung "kurz"
    if mode ~= "short" or all then
        n = n + self:AddMaterialBlock(tooltip, itemID, all)
    end
    if all then
        local short = self:DisenchantShort(itemID)
        if short then
            tooltip:AddDoubleLine("   " .. short.left, short.right, 0.6, 0.6, 0.6, 0.8, 0.8, 0.8)
            if short.gainLeft then tooltip:AddDoubleLine("   " .. short.gainLeft, short.gainRight, 0.6, 0.6, 0.6, 0.8, 0.8, 0.8) end
        end
        for _, l in ipairs(self:DisenchantLines(itemID, true)) do
            if l[3] then tooltip:AddDoubleLine(l[1], l[2], 0.6, 0.6, 0.6, 0.8, 0.8, 0.8)
            else tooltip:AddDoubleLine(l[1], l[2], 0.8, 0.8, 0.8, 1, 1, 1) end
        end
    end
    return n
end

-- Block 3: Kopf "Materialien (echt, aus N Entzauberungen)" / "Materialien (Tabelle)", je Material eine Zeile:
-- Symbol, Name, grau "78% × 1,5", rechts Preis je Stück nach Gebühr. all: dazu die Preisquelle.
function TT:AddMaterialBlock(tooltip, itemID, all)
    local mats, basis, n = self:DisenchantMats(itemID)
    if #mats == 0 then return 0 end
    tooltip:AddLine(" ")
    local head = (basis == "actual") and string.format(L["Materialien (echt, aus %d Entzauberungen)"], n or 0) or L["Materialien (Tabelle)"]
    tooltip:AddLine(head, 0.6, 0.6, 0.6)
    local comma = (A.uiLang or (GetLocale and GetLocale())) == "deDE"
    for _, m in ipairs(mats) do
        local icon = m.icon and ("|T" .. tostring(m.icon) .. ":14:14:0:0|t ") or ""
        local pct = m.chance * 100
        local qty = (m.min and m.max) and ((m.min == m.max) and tostring(m.min) or (m.min .. "–" .. m.max)) or string.format("%.1f", m.avg or 1)
        if comma then qty = qty:gsub("%.", ",") end
        local pctText = pct >= 10 and string.format("%d%%", pct + 0.5) or string.format("%.1f%%", pct)
        if comma then pctText = pctText:gsub("%.", ",") end
        local right = L["kein Preis"]
        if m.price then
            local net = A:IsForever() and (m.price - (A:FeePerPiece(m.id, m.price) or 0)) or (m.price * (1 - A:CutPct()))
            right = A:FormatMoney(math.max(0, math.floor(net + 0.5)))
            -- K4: Quelle immer klein grau ("Scan" / "Markt"); mit Shift dazu "Angebot unsicher"
            local src = m.source == "ah" and L["Scan"] or L["Markt"]
            if all and m.unsure then src = src .. " |cffff9933(" .. L["Angebot unsicher"] .. ")|r" end
            right = right .. " |cff999999" .. src .. "|r"
        end
        tooltip:AddDoubleLine(icon .. m.name .. "  |cff999999" .. pctText .. " × " .. qty .. "|r", right, 1, 1, 1, 1, 1, 1)
    end
    return #mats + 2
end

-- Zusatzzeilen (Variante A: nur mit Shift bzw. "alles"): beim Händler kaufen, Verkaufschance, Bestand der Twinks.
-- Entzaubern steht in Block 2/3 (TT:AddBlock2).
function TT:AddExtraLines(tooltip, itemID, all)
    if not all then return end
    local s = self:Settings() or {}
    local atMerchant = type(MerchantFrame) == "table" and MerchantFrame.IsShown and MerchantFrame:IsShown()
    local buy = A:GetVendorBuyPrice(itemID)
    if buy and not atMerchant then
        tooltip:AddDoubleLine(L["Beim Händler kaufen"], A:FormatMoney(buy), 0.8, 0.8, 0.8, 1, 1, 1)
    end
    if s.tooltipChance ~= false and A.Comfort then
        local chance = A.Comfort:ChanceText(itemID)
        if chance then tooltip:AddDoubleLine(L["Verkaufschance (deine)"], chance, 0.8, 0.8, 0.8, 1, 1, 1) end
    end
    -- Hinweis 10.11. (Anweisung Angebot und Absatz): Bestand als eigener Abschnitt mit Überschrift (sah sonst aus wie ein
    -- Material), zusammen mit dem Wert in den Taschen (nicht stapelbar: hier; stapelbar steht er schon in Block 2)
    local bagLine
    local n = self:BagCount(itemID)
    if n >= 2 and not self:IsStackable(itemID) then
        local okT, total = pcall(A.RealValue, A, itemID, n)
        if okT and total then bagLine = { string.format(L["%d in den Taschen:"], n), A:FormatMoney(total) } end
    end
    local charsText, charsTotal
    if s.tooltipChars ~= false and A.Chars then
        local list, total = A.Chars:ItemCounts(itemID)
        local others = 0
        for _, c in ipairs(list) do if not c.me then others = others + 1 end end
        if others > 0 then
            local parts = {}
            for k, c in ipairs(list) do
                if k > 4 then table.insert(parts, "..."); break end
                local cn = c.bags + c.bank
                local where = (c.bank > 0 and c.bags == 0) and L[" (Bank)"] or ""
                table.insert(parts, c.name .. " " .. cn .. where)
            end
            charsText, charsTotal = table.concat(parts, ", "), total
        end
    end
    if bagLine or charsText then
        tooltip:AddLine(" ")
        tooltip:AddDoubleLine(L["Im Besitz:"], charsTotal and tostring(charsTotal) or "", 0.6, 0.6, 0.6, 0.8, 0.8, 0.8)
        if bagLine then tooltip:AddDoubleLine("   " .. bagLine[1], bagLine[2], 0.8, 0.8, 0.8, 1, 1, 1) end
        if charsText then tooltip:AddLine("   " .. charsText, 0.8, 0.8, 0.8) end
    end
end

-- Item-ID aus Tooltip-Daten oder Tooltip-Link
-- WoW Forever: geschützte Werte ("secret values") nie vergleichen, zerlegen oder als Schlüssel benutzen
local function AnySecret(...)
    local G = _G.GoldSentinelGame
    return G and G.AnySecret and G.AnySecret(...) or false
end

local function ItemIDOf(tooltip, data)
    if type(data) == "table" and type(data.id) == "number" then
        if AnySecret(data.id) then return nil end
        return data.id
    end
    if tooltip.GetItem then
        local ok, _, link = pcall(tooltip.GetItem, tooltip)
        if ok and type(link) == "string" and not AnySecret(link) then
            local id = link:match("item:(%d+)")
            if id then return tonumber(id) end
        end
    end
    return nil
end

local MAIN_TIPS = {}      -- Tooltips, unter denen das Diagramm erscheinen darf

function TT:Handle(tooltip, data)
    if not A.db or type(tooltip) ~= "table" or not tooltip.AddLine then return end
    local itemID = ItemIDOf(tooltip, data)
    if not itemID then return end
    -- jede Tooltip-Anzeige nur einmal ergänzen. Nicht nur am Item festmachen: Manche Clients
    -- (z. B. TBC Anniversary) bauen den Tooltip neu auf, ohne OnTooltipCleared auszulösen -
    -- dann fehlen unsere Zeilen wieder, und das erkennen wir an der Zeilenzahl.
    local n = tooltip.NumLines and tooltip:NumLines() or 0
    if tooltip.__ahapItem == itemID and tooltip.__ahapN and n >= tooltip.__ahapN then return end
    tooltip.__ahapItem = itemID
    self.bagTooltip = self:IsBagOwner(tooltip)
    self:AddLinesCached(tooltip, itemID)
    self.bagTooltip = nil
    tooltip.__ahapN = tooltip.NumLines and tooltip:NumLines() or 0
    if MAIN_TIPS[tooltip] then self:ShowChart(tooltip, itemID) end
    -- Größe an die neuen Zeilen anpassen (sonst bleiben sie unsichtbar)
    if tooltip.__ahapN > n and tooltip.IsShown and tooltip:IsShown() and tooltip.Show then tooltip:Show() end
end

-- ------------------------------------------------------------
-- Zwischenspeicher je Item (Befund 22:25 Punkt 3: Tooltip 2,33 ms, Ziel < 2 ms). Die fertigen Zeilen werden je
-- Item und Zustand gemerkt (Preisdaten-Version, Shift, Taschen-Tooltip, Händler, Kaufzeile, Einstellungen,
-- Watchlist) und höchstens CACHE_TTL Sekunden wiederverwendet. Der Shift-Teil wird nur mit Shift gerechnet (all).
-- ------------------------------------------------------------
TT.CACHE_TTL = 10
TT.CACHE_MAX = 200
TT.cache, TT.cacheN = {}, 0
TT.cacheStamp = 0            -- steigt bei Einstellungen, Watchlist, Taschen
function TT:InvalidateCache() self.cacheStamp = self.cacheStamp + 1; wipe(self.cache); self.cacheN = 0 end

-- Recorder: sammelt AddLine/AddDoubleLine, damit dieselben Zeilen später wieder eingefügt werden können
local Recorder = {}
Recorder.__index = Recorder
function Recorder:AddLine(...) self.lines[#self.lines + 1] = { 1, select("#", ...), ... } end
function Recorder:AddDoubleLine(...) self.lines[#self.lines + 1] = { 2, select("#", ...), ... } end
function Recorder:NumLines() return #self.lines end
function Recorder:GetOwner() if self.tip and self.tip.GetOwner then return self.tip:GetOwner() end end
function Recorder:IsShown() return false end
function Recorder:Show() end

local function Replay(tooltip, lines)
    for _, l in ipairs(lines) do
        if l[1] == 1 then tooltip:AddLine(unpack(l, 3, l[2] + 2)) else tooltip:AddDoubleLine(unpack(l, 3, l[2] + 2)) end
    end
end

function TT:CacheKey(itemID)
    local s = self:Settings() or {}
    local isShift = A:Global("IsShiftKeyDown")
    local all = (isShift and isShift()) or self:DEMode() == "all"
    local atMerchant = type(MerchantFrame) == "table" and MerchantFrame.IsShown and MerchantFrame:IsShown()
    local c = self.buyContext
    local w = A.db.watchlist and A.db.watchlist[itemID]
    return table.concat({ itemID, all and 1 or 0, self.bagTooltip and 1 or 0, atMerchant and 1 or 0,
        (c and c.itemID == itemID and c.price) or 0, A:DataVersion(), self.cacheStamp, tostring(A.uiLang),
        tostring(s.tooltipInfo), tostring(s.tooltipVendor), self:DEMode(), tostring(s.tooltipChance), tostring(s.tooltipChars),
        w and (tostring(w.buyBelow) .. "/" .. tostring(w.sellAbove)) or "-", self:BagCount(itemID) }, "|")
end

function TT:CacheEnabled()
    if A.Spieltest and A.Spieltest.activeUntil then return false end           -- Spieltest hängt sich in die Berechnung
    local TR = A.TestRoutine
    if ((TR and TR.running) or (A.SelfTest and A.SelfTest.running)) and not self.testCache then return false end
    return true
end

function TT:AddLinesCached(tooltip, itemID)
    if not self:CacheEnabled() then return self:AddLines(tooltip, itemID) end
    local ok, key = pcall(self.CacheKey, self, itemID)
    if not ok then return self:AddLines(tooltip, itemID) end
    local now = GetTime and GetTime() or time()
    local e = self.cache[key]
    if e and now - e.t <= self.CACHE_TTL then
        self.cacheHits = (self.cacheHits or 0) + 1
        return Replay(tooltip, e.lines)
    end
    local rec = setmetatable({ lines = {}, tip = tooltip }, Recorder)
    local okB, err = pcall(self.AddLines, self, rec, itemID)
    Replay(tooltip, rec.lines)
    if not okB then error(err, 0) end
    if self.cacheN >= self.CACHE_MAX then wipe(self.cache); self.cacheN = 0 end
    if not e then self.cacheN = self.cacheN + 1 end
    self.cache[key] = { t = now, lines = rec.lines }
end

A:On("SETTINGS_CHANGED", function() TT:InvalidateCache() end)
A:On("WATCHLIST_CHANGED", function() TT:InvalidateCache() end)
A:On("DATA_CHANGED", function() TT:InvalidateCache() end)        -- z. B. neue eigene Entzauberung
A:On("DE_LEARNED", function() TT:InvalidateCache() end)
A:On("LEDGER_CHANGED", function() TT:InvalidateCache() end)
do
    local f = CreateFrame("Frame")
    for _, ev in ipairs({ "BAG_UPDATE_DELAYED", "BANKFRAME_CLOSED", "MERCHANT_SHOW", "MERCHANT_CLOSED" }) do pcall(f.RegisterEvent, f, ev) end
    f:SetScript("OnEvent", function() TT:InvalidateCache() end)
end

local function Cleared(tooltip)
    tooltip.__ahapItem, tooltip.__ahapN = nil, nil
    TT:HideChart(tooltip)
end

-- ------------------------------------------------------------
-- Einhängen (neue Clients: TooltipDataProcessor, ältere: OnTooltipSetItem)
-- ------------------------------------------------------------
function TT:Install()
    if self.installed then return end
    self.installed = true
    for _, tip in ipairs({ GameTooltip, ItemRefTooltip }) do
        if type(tip) == "table" then
            MAIN_TIPS[tip] = true
            if tip.HookScript then
                pcall(tip.HookScript, tip, "OnTooltipCleared", Cleared)
                pcall(tip.HookScript, tip, "OnHide", Cleared)
            end
        end
    end
    local handler = function(tooltip, data)
        local ok, err = pcall(TT.Handle, TT, tooltip, data)
        if not ok then
            A:ReportError("Tooltip", err)          -- jeden Fehler melden, der Chat-Hinweis bleibt einmalig
            if not TT.reported then
                TT.reported = true
                A:Print("Tooltip: " .. tostring(err))
            end
        end
    end
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, handler)
        self.mode = "TooltipDataProcessor"
    else
        local tips = { GameTooltip, ItemRefTooltip, ShoppingTooltip1, ShoppingTooltip2 }
        for _, tip in ipairs(tips) do
            if type(tip) == "table" and tip.HookScript then
                pcall(tip.HookScript, tip, "OnTooltipSetItem", function(t) handler(t) end)
                if not MAIN_TIPS[tip] then pcall(tip.HookScript, tip, "OnTooltipCleared", Cleared) end
            end
        end
        self.mode = "OnTooltipSetItem"
    end
    -- zusätzlich direkt an den Befehlen, die einen Item-Tooltip füllen: falls der Weg oben
    -- auf einem Client nicht greift (doppelte Zeilen verhindert Handle)
    local hooked = 0
    for _, tip in ipairs({ GameTooltip, ItemRefTooltip }) do
        if type(tip) == "table" then
            for _, m in ipairs({ "SetBagItem", "SetInventoryItem", "SetHyperlink", "SetItemByID", "SetAuctionItem",
                "SetAuctionSellItem", "SetMerchantItem", "SetBuybackItem", "SetLootItem", "SetInboxItem", "SetSendMailItem",
                "SetTradePlayerItem", "SetTradeTargetItem", "SetQuestItem", "SetQuestLogItem", "SetGuildBankItem" }) do
                if type(tip[m]) == "function" and pcall(hooksecurefunc, tip, m, function(t) handler(t) end) then hooked = hooked + 1 end
            end
        end
    end
    if hooked > 0 then self.mode = self.mode .. "+Set*" end
end

function TT:GetDebugText()
    return "Modus=" .. tostring(self.mode) .. ", Zeilen=" .. ((A.db and A.db.settings.tooltipInfo == false) and "aus" or "an")
        .. ", Händlerpreis=" .. ((A.db and A.db.settings.tooltipVendor == false) and "aus" or "an")
        .. ", Diagramm=" .. self:PeriodLabel()
end

A:On("READY", function() TT:Install() end)
