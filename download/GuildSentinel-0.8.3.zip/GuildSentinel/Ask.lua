-- GuildSentinel - Ask.lua
-- Fragen an die Gilde ("Wer weiss …?"): Jeder stellt eine Frage, alle mit GuildSentinel sehen sie und können
-- antworten. Wer gefragt hat, markiert die hilfreichste Antwort – deren Schreiber bekommt einen Danke-Punkt.
-- Fragen bleiben 14 Tage.
--
--   G.ask[id] = { id, by, q, t, u, answers = { [Name] = { t, a } }, solved = Name, del }

local ADDON, ns = ...
local L = ns.L
local Ak = {}
ns.Ask = Ak

Ak.TTL = 14 * 86400
local counter = 0

function Ak:Active(e)
	return e and not e.del and ns.Now() - (e.t or 0) < self.TTL
end

local function Wire(e)
	return { id = e.id, by = e.by, q = e.q, t = e.t, u = e.u, answers = e.answers, solved = e.solved, del = e.del }
end

function Ak:Create(q)
	local g = ns.guild
	q = ns.Trim(q)
	if not g then return end
	if q == "" then ns:Print(L["Bitte eine Frage eingeben."]) return end
	counter = counter + 1
	local now = ns.Now()
	local e = { id = ns.Me() .. now .. counter, by = ns.Me(), q = q:sub(1, 200), t = now, u = now, answers = {} }
	g.ask[e.id] = e
	ns.Comm:Send("ASK", { e = { [e.id] = Wire(e) } })
	ns:Fire("GS_ASK")
	return e
end

function Ak:Answer(id, text)
	local e = ns.G().ask[id]
	text = ns.Trim(text)
	if not self:Active(e) then return end
	if text == "" then ns:Print(L["Bitte eine Antwort eingeben."]) return end
	e.answers = e.answers or {}
	e.answers[ns.Me()] = { t = ns.Now(), a = text:sub(1, 250) }
	e.u = ns.Now()
	ns.Comm:Send("ASK", { e = { [id] = Wire(e) } })
	ns:Fire("GS_ASK")
end

-- hilfreichste Antwort markieren: Danke-Punkt für den Schreiber
function Ak:Solve(id, name)
	local e = ns.G().ask[id]
	if not e or not ns.Same(e.by, ns.Me()) or not (e.answers and e.answers[name]) then return end
	e.solved, e.u = name, ns.Now()
	ns.Comm:Send("ASK", { e = { [id] = Wire(e) } })
	if ns.Feature("thanks") and ns.Roster.byName[name] then ns.Social:Thank(name, L["Frage: "] .. e.q:sub(1, 60)) end
	ns:Fire("GS_ASK")
end

function Ak:Remove(id)
	local e = ns.G().ask[id]
	if not e or not (ns.Same(e.by, ns.Me()) or ns.IsOfficer()) then return end
	e.del, e.u = true, ns.Now()
	ns.Comm:Send("ASK", { e = { [id] = Wire(e) } })
	ns:Fire("GS_ASK")
end

-- zusammenführen: neuere Fassung gewinnt, Antworten werden vereinigt
local function Store(d)
	local g = ns.guild
	if not g or type(d) ~= "table" or type(d.id) ~= "string" or type(d.by) ~= "string" or type(d.q) ~= "string" then return false, nil end
	local old = g.ask[d.id]
	local e = old or { id = d.id, by = d.by, q = d.q:sub(1, 200), t = tonumber(d.t) or ns.Now(), u = 0, answers = {} }
	local changed = not old
	local fresh = {}
	for name, a in pairs(type(d.answers) == "table" and d.answers or {}) do
		if type(name) == "string" and type(a) == "table" and type(a.a) == "string" then
			local cur = e.answers[name]
			if not cur then fresh[#fresh + 1] = name end
			if not cur or (cur.t or 0) < (tonumber(a.t) or 0) then e.answers[name] = { t = tonumber(a.t) or ns.Now(), a = a.a:sub(1, 250) }; changed = true end
		end
	end
	local u = tonumber(d.u) or 0
	if u > (e.u or 0) then
		e.u = u
		if type(d.solved) == "string" then e.solved = d.solved end
		if d.del then e.del = true end
		changed = true
	end
	g.ask[d.id] = e
	return changed, old, fresh
end
Ak.Store = Store

local function OnAsk(sender, d)
	if type(d.e) ~= "table" then return end
	local any
	for _, x in pairs(d.e) do
		local ok, old, fresh = Store(x)
		if ok then
			any = true
			local e = ns.G().ask[x.id]
			if not old and not e.del and Ak:Active(e) and not ns.Same(e.by, ns.Me()) and sender == e.by then
				ns:Print(string.format(L["%s fragt: %s – antworten: /gs brett"], e.by, e.q))
			end
			-- Antwort auf meine Frage
			if old and ns.Same(e.by, ns.Me()) then
				for _, name in ipairs(fresh or {}) do
					if not ns.Same(name, ns.Me()) then
						ns:Print(string.format(L["%s hat deine Frage beantwortet: %s"], name, e.answers[name].a))
					end
				end
			end
		end
	end
	if any then ns:Fire("GS_ASK") end
end
ns.Comm:Register("ASK", OnAsk)
ns.Comm:Register("ASKS", OnAsk)

-- { { e, n = Antworten } } – offene zuerst, neueste zuerst
function Ak:List(showSolved)
	local out = {}
	for _, e in pairs(ns.G().ask) do
		if self:Active(e) and (showSolved or not e.solved) then out[#out + 1] = e end
	end
	table.sort(out, function(a, b)
		if (a.solved ~= nil) ~= (b.solved ~= nil) then return a.solved == nil end
		return (a.t or 0) > (b.t or 0)
	end)
	return out
end

function Ak:Answers(e)
	local out = {}
	for name, a in pairs(e and e.answers or {}) do out[#out + 1] = { name = name, t = a.t, a = a.a, best = e.solved == name } end
	table.sort(out, function(a, b) if a.best ~= b.best then return a.best end return (a.t or 0) < (b.t or 0) end)
	return out
end

-- offene Fragen anderer, auf die ich noch nicht geantwortet habe
function Ak:OpenCount()
	local n = 0
	for _, e in ipairs(self:List(false)) do
		if not ns.Same(e.by, ns.Me()) and not (e.answers and e.answers[ns.Me()]) then n = n + 1 end
	end
	return n
end

function Ak:SyncData()
	local out, n = {}, 0
	for id, e in pairs(ns.G().ask) do
		if self:Active(e) and n < 60 then out[id] = Wire(e); n = n + 1 end
	end
	return out
end

ns:Listen("GS_LOGIN", function()
	local g = ns.guild
	if not g then return end
	for id, e in pairs(g.ask) do
		if ns.Now() - (e.u or e.t or 0) > Ak.TTL + 7 * 86400 then g.ask[id] = nil end
	end
end)
