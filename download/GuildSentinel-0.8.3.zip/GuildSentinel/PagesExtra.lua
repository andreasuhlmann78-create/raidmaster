-- GuildSentinel - PagesExtra.lua
-- Zusätzliche Reiter auf bestehenden Seiten:
--   Brett > Beute-Wünsche, Brett > Fragen, Fortschritt > Erfolge, Fortschritt > Chronik

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local UI = ns.UI

local GREEN, GRAY, GOLD, ORANGE = "|cff40d860", "|cff8a8f99", "|cffffd100", "|cffff9933"
local WHITE = "Interface\\Buttons\\WHITE8x8"
local function Gray(t) return GRAY .. tostring(t) .. "|r" end

local function View(p)
	local v = CreateFrame("Frame", nil, p)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	v:Hide()
	return v
end

------------------------------------------------------------
-- Brett > Beute-Wünsche
------------------------------------------------------------
local Bd = ns.BoardPage
Bd.extra = Bd.extra or {}
Bd.extraViews = Bd.extraViews or {}
local GW = {}

table.insert(Bd.extra, function(p)
	local v = View(p)
	GW.frame = v
	local h = UI:Header(v, L["Was brauchst du noch?"])
	h:SetPoint("TOPLEFT", 0, 0)
	GW.item = UI:Edit(v, 260, 24, L["Gegenstand: Shift-Klick oder Name"])
	GW.item:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -6)
	UI:AcceptLinks(GW.item)
	GW.act = nil
	GW.actDD = UI:Dropdown(v, 250, function()
		local out = {}
		for _, a in ipairs(ns.Group.ACTIVITIES) do
			if a.min then out[#out + 1] = { value = a.key, text = L[a.n] .. Gray(string.format(" (%d–%d)", a.min, a.max)) } end
		end
		return out
	end, function() return GW.act end, function(val) GW.act = val end)
	GW.actDD:SetPoint("LEFT", GW.item, "RIGHT", 8, 0)
	local add = UI:Button(v, L["Wunsch eintragen"], 160, 24, function()
		local text = GW.item:GetText()
		if not GW.act then
			GW.info:SetText("|cffff9933" .. L["Bitte einen Dungeon wählen."] .. "|r")
			return
		end
		local id = ns.FindItemID(text)
		local name = text:match("%[(.-)%]") or text
		if ns.Gear:Add(id or 0, name, GW.act) then GW.item:SetText("") end
	end, true)
	add:SetPoint("LEFT", GW.actDD, "RIGHT", 8, 0)
	GW.mine = UI:Check(v, L["nur meine"], function() return GW.onlyMine end, function(val) GW.onlyMine = val; GW.Refresh() end)
	GW.mine:SetPoint("TOPRIGHT", -80, -2)
	GW.list = UI:List(v, {
		{ key = "act", title = L["Dungeon"], width = 230 },
		{ key = "item", title = L["Gegenstand"], width = 260 },
		{ key = "by", title = L["Wer"], width = 140 },
		{ key = "t", title = L["Seit"] },
	}, {
		key = function(e) return e.id end,
		icon = function(e) return (e.i or 0) > 0 and select(4, ns.Item(e.i)) or nil end,
		render = function(e)
			local r = ns.Roster.byName[e.by]
			local _, link = ns.Item(e.i)
			return { ns.Group:ActivityName({ act = e.act }), link or e.n, ns.Colored(e.by, r and r.class), Gray(ns.Ago(e.t)) }
		end,
		onEnter = function(row, e)
			if (e.i or 0) > 0 then
				GameTooltip:SetOwner(row, "ANCHOR_CURSOR")
				GameTooltip:SetHyperlink("item:" .. e.i)
				GameTooltip:Show()
			end
		end,
		onClick = function() GW.Buttons() end,
		empty = L["Noch keine Beute-Wünsche. Trag ein, was du aus welchem Dungeon brauchst – die Gruppensuche zeigt dann, wer mitkommen will."],
	})
	GW.list:SetPoint("TOPLEFT", 0, -64)
	GW.list:SetPoint("BOTTOMRIGHT", 0, 40)
	GW.got = UI:Button(v, L["Bekommen!"], 140, 26, function()
		local e = GW.list:Selected()
		if e then ns.Gear:Done(e.id); ns:Print(string.format(L["Glückwunsch zu %s!"], e.n)) end
	end, true)
	GW.got:SetPoint("BOTTOMLEFT", 0, 4)
	GW.del = UI:Button(v, L["Entfernen"], 120, 26, function() local e = GW.list:Selected(); if e then ns.Gear:Remove(e.id) end end)
	GW.del:SetPoint("LEFT", GW.got, "RIGHT", 8, 0)
	GW.whisper = UI:Button(v, L["Anflüstern"], 120, 26, function() local e = GW.list:Selected(); if e then ns.Recruit:Whisper(e.by) end end)
	GW.whisper:SetPoint("LEFT", GW.del, "RIGHT", 8, 0)
	GW.info = UI:Label(v, "", "GameFontHighlightSmall")
	GW.info:SetPoint("LEFT", GW.whisper, "RIGHT", 12, 0)
	Bd.extraViews.gear = { frame = v, refresh = function() GW.Refresh() end }
end)

function GW.Buttons()
	local e = GW.list:Selected()
	local mine = e and ns.Same(e.by, ns.Me())
	GW.got:SetEnabled(mine and true or false)
	GW.del:SetEnabled(e ~= nil and (mine or ns.IsOfficer()))
	GW.whisper:SetEnabled(e ~= nil and not mine)
end

-- Dungeon passend zur eigenen Stufe vorwählen
function GW.Preselect()
	if GW.act then return end
	local lvl = UnitLevel("player") or 1
	local best
	for _, a in ipairs(ns.Group.ACTIVITIES) do
		if a.min and a.max and lvl >= a.min and lvl <= a.max then best = a.key break end
	end
	if not best then
		for _, a in ipairs(ns.Group.ACTIVITIES) do if a.min and a.min <= lvl then best = a.key end end
	end
	GW.act = best
	if GW.actDD and GW.actDD.Refresh then GW.actDD.Refresh() end
end

function GW.Refresh()
	GW.Preselect()
	local list = GW.onlyMine and ns.Gear:Mine() or ns.Gear:List()
	GW.list:SetData(list)
	local players = 0
	for _ in pairs(ns.Gear:Counts()) do players = players + 1 end
	GW.info:SetText(Gray(string.format(L["%d Wünsche für %d Dungeons"], #ns.Gear:List(), players)))
	GW.Buttons()
end
ns:Listen("GS_GEAR", function() if UI:IsPageShown("board") and Bd.view == "gear" then GW.Refresh() end end)

------------------------------------------------------------
-- Brett > Fragen
------------------------------------------------------------
local AQ = {}

table.insert(Bd.extra, function(p)
	local v = View(p)
	AQ.frame = v
	AQ.q = UI:Edit(v, 460, 24, L["Deine Frage an die Gilde, z. B. 'Wer erklärt mir die Taktik für Karazhan?'"], false, 200)
	AQ.q:SetPoint("TOPLEFT", 0, 0)
	AQ.q.onEnter = function(t) if ns.Ask:Create(t) then AQ.q:SetText("") end end
	local ask = UI:Button(v, L["Fragen"], 120, 24, function() if ns.Ask:Create(AQ.q:GetText()) then AQ.q:SetText("") end end, true)
	ask:SetPoint("LEFT", AQ.q, "RIGHT", 8, 0)
	AQ.solved = UI:Check(v, L["Gelöste zeigen"], function() return AQ.showSolved end, function(val) AQ.showSolved = val; AQ.Refresh() end)
	AQ.solved:SetPoint("LEFT", ask, "RIGHT", 12, 0)
	AQ.list = UI:List(v, {
		{ key = "q", title = L["Frage"], width = 440 },
		{ key = "by", title = L["Von"], width = 120 },
		{ key = "n", title = L["Antworten"], width = 80, align = "CENTER" },
		{ key = "st", title = L["Status"] },
	}, {
		key = function(e) return e.id end,
		render = function(e)
			local r = ns.Roster.byName[e.by]
			local n = 0
			for _ in pairs(e.answers or {}) do n = n + 1 end
			return { e.q, ns.Colored(e.by, r and r.class), tostring(n), e.solved and (GREEN .. L["gelöst"] .. "|r") or (n == 0 and (ORANGE .. L["offen"] .. "|r") or Gray(L["beantwortet"])) }
		end,
		onClick = function() AQ.RefreshAnswers() end,
		empty = L["Keine offenen Fragen. Wer etwas wissen will, fragt oben – alle mit GuildSentinel sehen die Frage."],
	})
	AQ.list:SetPoint("TOPLEFT", 0, -32)
	AQ.list:SetPoint("RIGHT")
	AQ.list:SetHeight(210)
	AQ.title = UI:Label(v, "", "GameFontNormal")
	AQ.title:SetPoint("TOPLEFT", AQ.list, "BOTTOMLEFT", 0, -8)
	AQ.title:SetPoint("RIGHT")
	AQ.title:SetJustifyH("LEFT")
	AQ.answers = UI:List(v, {
		{ key = "name", title = L["Wer"], width = 140 },
		{ key = "a", title = L["Antwort"] },
	}, {
		key = function(a) return a.name end,
		render = function(a)
			local r = ns.Roster.byName[a.name]
			return { (a.best and (GREEN .. "> |r") or "") .. ns.Colored(a.name, r and r.class), a.a }
		end,
		onEnter = function(row, a)
			GameTooltip:SetOwner(row, "ANCHOR_CURSOR")
			GameTooltip:AddLine(a.name, 1, 1, 1)
			GameTooltip:AddLine(a.a, 0.9, 0.9, 0.9, true)
			GameTooltip:Show()
		end,
		onClick = function() AQ.Buttons() end,
		empty = L["Noch keine Antworten."],
	})
	AQ.answers:SetPoint("TOPLEFT", AQ.title, "BOTTOMLEFT", 0, -6)
	AQ.answers:SetPoint("BOTTOMRIGHT", 0, 40)
	AQ.answerBtn = UI:Button(v, L["Antworten"], 140, 26, function()
		local e = AQ.list:Selected()
		if e then UI:Ask(string.format(L["Deine Antwort an %s:"], e.by), "", function(t) ns.Ask:Answer(e.id, t) end) end
	end, true)
	AQ.answerBtn:SetPoint("BOTTOMLEFT", 0, 4)
	AQ.best = UI:Button(v, L["Hat geholfen"], 140, 26, function()
		local e, a = AQ.list:Selected(), AQ.answers:Selected()
		if e and a then ns.Ask:Solve(e.id, a.name) end
	end)
	AQ.best:SetPoint("LEFT", AQ.answerBtn, "RIGHT", 8, 0)
	AQ.del = UI:Button(v, L["Entfernen"], 120, 26, function()
		local e = AQ.list:Selected()
		if e then UI:Confirm(L["Diese Frage löschen?"], function() ns.Ask:Remove(e.id) end) end
	end)
	AQ.del:SetPoint("LEFT", AQ.best, "RIGHT", 8, 0)
	local hint = UI:Label(v, Gray(L["„Hat geholfen“ gibt dem Schreiber einen Danke-Punkt."]), "GameFontHighlightSmall")
	hint:SetPoint("LEFT", AQ.del, "RIGHT", 12, 0)
	Bd.extraViews.ask = { frame = v, refresh = function() AQ.Refresh() end }
end)

function AQ.Buttons()
	local e, a = AQ.list:Selected(), AQ.answers:Selected()
	local mine = e and ns.Same(e.by, ns.Me())
	AQ.answerBtn:SetEnabled(e ~= nil and not mine)
	AQ.best:SetEnabled(mine and a ~= nil and not ns.Same(a.name, ns.Me()) and true or false)
	AQ.del:SetEnabled(e ~= nil and (mine or ns.IsOfficer()))
end

function AQ.RefreshAnswers()
	local e = AQ.list:Selected()
	if e then
		AQ.title:SetText(GOLD .. e.q .. "|r")
		AQ.answers:SetData(ns.Ask:Answers(e))
	else
		AQ.title:SetText(Gray(L["Wähle oben eine Frage."]))
		AQ.answers:SetData({})
	end
	AQ.Buttons()
end

function AQ.Refresh()
	AQ.list:SetData(ns.Ask:List(AQ.showSolved))
	AQ.RefreshAnswers()
end
ns:Listen("GS_ASK", function() if UI:IsPageShown("board") and Bd.view == "ask" then AQ.Refresh() end end)

------------------------------------------------------------
-- Fortschritt > Erfolge
------------------------------------------------------------
local Pr = ns.ProgressPage
Pr.extra = Pr.extra or {}
Pr.extraViews = Pr.extraViews or {}
local AC = { rows = {} }

table.insert(Pr.extra, function(p)
	local v = View(p)
	AC.frame = v
	local h = UI:Header(v, L["Gildenerfolge"])
	h:SetPoint("TOPLEFT", 0, 0)
	AC.info = UI:Label(v, "", "GameFontHighlightSmall")
	AC.info:SetPoint("LEFT", h, "RIGHT", 12, 0)
	AC.holder = CreateFrame("Frame", nil, v)
	AC.holder:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -8)
	AC.holder:SetPoint("BOTTOMRIGHT")
	Pr.extraViews.achv = { frame = v, refresh = function() AC.Refresh() end }
end)

local function AchRow(i)
	local r = AC.rows[i]
	if r then return r end
	r = CreateFrame("Frame", nil, AC.holder)
	r:SetHeight(24)
	r:SetPoint("TOPLEFT", 0, -(i - 1) * 26)
	r:SetPoint("RIGHT")
	r.name = UI:Label(r, "", "GameFontHighlight")
	r.name:SetPoint("LEFT", 0, 0)
	r.name:SetWidth(410)
	r.name:SetJustifyH("LEFT")
	r.name:SetWordWrap(false)
	r.bar = CreateFrame("Frame", nil, r, UI.BACKDROP)
	r.bar:SetPoint("LEFT", 420, 0)
	r.bar:SetSize(220, 16)
	UI.Box(r.bar, 0.04, 0.05, 0.07, 1, 0.25, 0.28, 0.34, 1)
	r.fill = r.bar:CreateTexture(nil, "ARTWORK")
	r.fill:SetPoint("TOPLEFT", 1, -1)
	r.fill:SetPoint("BOTTOMLEFT", 1, 1)
	r.fill:SetTexture(WHITE)
	r.val = UI:Label(r, "", "GameFontHighlightSmall")
	r.val:SetPoint("LEFT", r.bar, "RIGHT", 8, 0)
	r.sub = UI:Label(r, "", "GameFontDisableSmall")
	r.sub:SetPoint("LEFT", r.val, "RIGHT", 8, 0)
	r.sub:SetPoint("RIGHT")
	r.sub:SetJustifyH("LEFT")
	r.sub:SetWordWrap(false)
	AC.rows[i] = r
	return r
end

function AC.Refresh()
	local list = ns.Chronicle:Achievements()
	local done = 0
	for i, a in ipairs(list) do
		if i > 18 then break end
		local r = AchRow(i)
		r:Show()
		-- zu lange Namen: kleinere Schrift statt abschneiden
		r.name:SetFontObject("GameFontHighlight")
		r.name:SetText((a.done and GREEN or "") .. a.name .. (a.done and "|r" or ""))
		if r.name.IsTruncated and r.name:IsTruncated() then r.name:SetFontObject("GameFontHighlightSmall") end
		local f = a.max > 0 and a.cur / a.max or 0
		r.fill:SetWidth(math.max(1, 218 * math.min(1, f)))
		if a.done then r.fill:SetVertexColor(0.25, 0.85, 0.4, 0.9) else r.fill:SetVertexColor(0.31, 0.82, 0.54, 0.55) end
		r.val:SetText(string.format("%d/%d", a.cur, a.max))
		r.sub:SetText(a.sub and Gray(a.sub) or "")
		if a.done then done = done + 1 end
	end
	for i = math.min(#list, 18) + 1, #AC.rows do AC.rows[i]:Hide() end
	AC.info:SetText(Gray(string.format(L["%d von %d erreicht"], done, #list)))
end

------------------------------------------------------------
-- Fortschritt > Chronik
------------------------------------------------------------
local CH = {}
table.insert(Pr.extra, function(p)
	local v = View(p)
	CH.frame = v
	local h = UI:Header(v, L["Chronik der Gilde"])
	h:SetPoint("TOPLEFT", 0, 0)
	local exp = UI:Button(v, L["Für Discord exportieren"], 200, 24, function()
		UI:Info(L["Chronik für Discord"], ns.Chronicle:ExportText(), true)
	end)
	exp:SetPoint("TOPRIGHT", 0, 0)
	CH.text = UI:ScrollText(v, 780, 480)
	CH.text:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -10)
	CH.text:SetPoint("BOTTOMRIGHT")
	Pr.extraViews.chron = { frame = v, refresh = function() CH.Refresh() end }
end)

local KIND_COLOR = { join = GREEN, leave = ORANGE, level = GOLD, kill = "|cffff7040", mile = GOLD, goal = GREEN, event = "|cff8fb8ff" }
function CH.Refresh()
	local lines = {}
	local lastMonth
	for i, x in ipairs(ns.Chronicle:Timeline()) do
		if i > 200 then break end
		local month = date(L["%m/%Y"], x.t)
		if month ~= lastMonth then
			if lastMonth then lines[#lines + 1] = "" end
			lines[#lines + 1] = GOLD .. month .. "|r"
			lastMonth = month
		end
		lines[#lines + 1] = Gray(date(L["%d.%m."], x.t)) .. "  " .. (KIND_COLOR[x.kind] or "") .. x.text .. "|r"
	end
	if #lines == 0 then lines[1] = Gray(L["Noch nichts in der Chronik – sie füllt sich mit Beitritten, Höchststufen, Erstkills und Meilensteinen."]) end
	CH.text:SetText(table.concat(lines, "\n"))
end

------------------------------------------------------------
-- Gruppensuche: Beute-Wünsche je Dungeon anzeigen
------------------------------------------------------------
function ns.Group:GearHint(act)
	if not ns.Feature("gear") then return "" end
	local n = ns.Gear:Counts()[act]
	if not n or n == 0 then return "" end
	return GOLD .. string.format(L["%d mit Beute-Wunsch"], n) .. "|r "
end
