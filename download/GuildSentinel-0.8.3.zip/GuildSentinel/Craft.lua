-- GuildSentinel - Craft.lua
-- Berufe-Lücken: Welche wichtigen Rezepte (Raid-Tränke, Fläschchen, Transmutation, Mondstoff ...) kann in der
-- Gilde niemand herstellen? Die betroffenen Berufe stehen im Platzhalter {berufe} der Gildenwerbung.
-- Rezept-Nachfrage: Mitglieder tragen ein, was sie hergestellt haben möchten. Wer es herstellen kann, bekommt
-- einen Hinweis und übernimmt den Wunsch mit einem Klick.
--
--   G.craftWatch[Item-ID] = Beruf-Zauber-ID   (von der Gildenleitung ergänzte Rezepte)
--   G.creq[id] = { id, by, i = Item-ID, n = Name, c = Anzahl, note, t, u = zuletzt geändert, taker, done, del }

local ADDON, ns = ...
local L = ns.L
local Cr = {}
ns.Craft = Cr

Cr.KEEP = 14 * 86400        -- Wünsche bleiben 14 Tage, erledigte noch 3 Tage sichtbar
Cr.KEEP_DONE = 3 * 86400

-- Berufe (Zauber-ID -> Name kommt aus dem Spiel, also in jeder Sprache richtig)
Cr.ALCHEMY, Cr.TAILORING, Cr.BLACKSMITHING, Cr.ENGINEERING, Cr.MINING = 2259, 3908, 2018, 4036, 2575

-- wichtige Rezepte für Raids (Item-IDs; Namen liefert das Spiel)
Cr.IMPORTANT = {
	{ i = 13457, p = 2259 },  -- Großer Feuerschutztrank
	{ i = 13458, p = 2259 },  -- Großer Naturschutztrank
	{ i = 13459, p = 2259 },  -- Großer Schattenschutztrank
	{ i = 13456, p = 2259 },  -- Großer Frostschutztrank
	{ i = 13461, p = 2259 },  -- Großer Arkanschutztrank
	{ i = 13510, p = 2259 },  -- Fläschchen der Titanen
	{ i = 13511, p = 2259 },  -- Fläschchen der destillierten Weisheit
	{ i = 13512, p = 2259 },  -- Fläschchen der höchsten Macht
	{ i = 13452, p = 2259 },  -- Elixier des Mungos
	{ i = 9206, p = 2259 },   -- Elixier der Riesen
	{ i = 13444, p = 2259 },  -- Erheblicher Manatrank
	{ i = 13446, p = 2259 },  -- Erheblicher Heiltrank
	{ i = 5634, p = 2259 },   -- Trank der freien Aktion
	{ i = 12360, p = 2259 },  -- Arkanitbarren (Transmutation)
	{ i = 14342, p = 3908 },  -- Mondstoff
	{ i = 11371, p = 2575 },  -- Dunkeleisenbarren (Verhüttung)
	{ i = 18641, p = 4036 },  -- Dichtes Dynamit
	{ i = 10646, p = 4036 },  -- Goblin-Pioniersprengladung
}

if ns.Game.TBC then Cr.IMPORTANT = ns.Game.TBC_IMPORTANT end

local function SpellName(id)
	if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
	return GetSpellInfo and (GetSpellInfo(id)) or nil
end

function Cr:ProfName(spellId)
	if not spellId or spellId == 0 then return L["Beruf unbekannt"] end
	return SpellName(spellId) or ("#" .. tostring(spellId))
end

function Cr:ItemName(id, fallback)
	local name = ns.Item(id)
	return name or fallback or ("item:" .. tostring(id))
end

function Cr:ItemLink(id, fallback)
	local _, link = ns.Item(id)
	return link or ("[" .. self:ItemName(id, fallback) .. "]")
end

-- Wer (in der Gilde) kann das Item herstellen? (Item-ID oder Rezeptname)
function Cr:WhoCanCraft(id, name)
	local out = {}
	local lname = name and name:lower()
	for who, e in pairs(ns.Prof:All()) do
		if ns.Roster.byName[who] or not next(ns.Roster.byName) then
			local found
			for _, v in pairs(e.p or {}) do
				for k, n in ipairs(v.n or {}) do
					if (id and id > 0 and v.i and v.i[k] == id) or (lname and n:lower() == lname) then found = true break end
				end
				if found then break end
			end
			if found then out[#out + 1] = who end
		end
	end
	table.sort(out, function(a, b)
		local ao, bo = ns.Roster:OnlineChar(a) ~= nil, ns.Roster:OnlineChar(b) ~= nil
		if ao ~= bo then return ao end
		return a < b
	end)
	return out
end

function Cr:CanICraft(id, name)
	for _, who in ipairs(self:WhoCanCraft(id, name)) do
		if ns.Same(who, ns.Me()) then return true end
	end
	return false
end

------------------------------------------------------------
-- Berufe-Lücken
------------------------------------------------------------
function Cr:Watched()
	local list, seen = {}, {}
	for _, x in ipairs(self.IMPORTANT) do list[#list + 1] = { i = x.i, p = x.p }; seen[x.i] = true end
	local cw = ns.G().craftWatch
	local drop = {}
	for id, p in pairs(cw) do
		-- alte Einträge aufräumen: Rohstoffe (z. B. Teufelsgras) entfernen, unbekannten Beruf nachtragen
		local fp, why = self:ProfFromItem(id)
		if why == "gathered" then drop[#drop + 1] = id
		else
			if (p or 0) == 0 and fp then cw[id] = fp; p = fp end
			if not seen[id] then list[#list + 1] = { i = id, p = p, custom = true } end
		end
	end
	for _, id in ipairs(drop) do cw[id] = nil end
	return list
end

-- { { i, p, prof, name, who = { Namen }, custom } } – Lücken zuerst
function Cr:Gaps()
	local out = {}
	for _, x in ipairs(self:Watched()) do
		local who = self:WhoCanCraft(x.i)
		out[#out + 1] = { i = x.i, p = x.p, prof = self:ProfName(x.p), name = self:ItemName(x.i), who = who, custom = x.custom }
	end
	table.sort(out, function(a, b)
		if (#a.who == 0) ~= (#b.who == 0) then return #a.who == 0 end
		if a.prof ~= b.prof then return a.prof < b.prof end
		return a.name < b.name
	end)
	return out
end

-- Berufe, in denen wichtige Rezepte fehlen
function Cr:MissingProfs()
	local seen, out = {}, {}
	for _, g in ipairs(self:Gaps()) do
		if #g.who == 0 and not seen[g.prof] then seen[g.prof] = true; out[#out + 1] = g.prof end
	end
	table.sort(out)
	return out
end

-- Text für {berufe}: "Handwerker gesucht: Alchemie, Schneiderei." (leer, wenn alles abgedeckt)
function Cr:WantedText()
	local list = self:MissingProfs()
	if #list == 0 then return "" end
	return string.format(L["Handwerker gesucht: %s."], table.concat(list, ", "))
end

-- Rezept zur Beobachtung hinzufügen (Item-ID; Beruf wird geraten aus den bekannten Rezepten der Gilde)
-- Beruf aus den Item-Daten (classID/subclassID): nil = kein herstellbarer Gegenstand (z. B. Kraut, Erz)
-- 0 Verbrauchbar: 1 Trank, 2 Elixier, 3 Fläschchen -> Alchemie; 5 Essen -> Kochkunst; 7 Verband -> Erste Hilfe
-- 7 Handwerkswaren: 1 Teile, 2 Sprengstoff, 3 Geräte -> Ingenieur; 5 Stoff -> Schneiderei; 6 Leder -> Lederverarbeitung;
--   7 Metall & Stein -> Bergbau (Barren); 12 Verzauberung -> Verzauberkunst; 9 Kräuter, 8 Fleisch -> gesammelt
Cr.ITEM_PROF = {
	[0] = { [1] = 2259, [2] = 2259, [3] = 2259, [5] = 2550, [7] = 3273 },
	[7] = { [1] = 4036, [2] = 4036, [3] = 4036, [5] = 3908, [6] = 2108, [7] = 2575, [12] = 7411 },
}
function Cr:ProfFromItem(id)
	local info = { ns.GetItemInfo(id) }
	local classID, subID = info[12], info[13]
	if classID == nil then return nil, "unknown" end
	local t = self.ITEM_PROF[classID]
	local p = t and t[subID]
	if p then return p end
	if classID == 7 and (subID == 9 or subID == 8 or subID == 10 or subID == 11) then return nil, "gathered" end
	return nil, "unknown"
end

function Cr:Watch(id)
	local g = ns.guild
	if not g or not id then return end
	local prof
	for _, e in pairs(ns.Prof:All()) do
		for pname, v in pairs(e.p or {}) do
			for _, iid in ipairs(v.i or {}) do
				if iid == id then prof = pname end
			end
		end
	end
	local spell = 0
	if prof then
		for _, sid in ipairs({ 2259, 3908, 2018, 4036, 7411, 2108, 2550, 3273, 2656, 2575 }) do
			if SpellName(sid) == prof then spell = sid end
		end
	end
	-- sonst aus den Item-Daten; Rohstoffe (Kräuter, Erz …) sind keine Rezepte
	if spell == 0 then
		local p, why = self:ProfFromItem(id)
		if p then spell = p
		elseif why == "gathered" then
			ns:Print(string.format(L["%s ist ein Rohstoff und wird nicht hergestellt – nur herstellbare Gegenstände lassen sich beobachten."], self:ItemName(id)))
			return false
		end
	end
	-- Beruf unbekannt (Item noch nicht geladen oder ungewöhnlich): 0
	g.craftWatch[id] = spell
	ns:Fire("GS_CRAFT")
	return true
end

function Cr:Unwatch(id)
	local g = ns.guild
	if g then g.craftWatch[id] = nil; ns:Fire("GS_CRAFT") end
end

------------------------------------------------------------
-- Rezept-Nachfrage
------------------------------------------------------------
local counter = 0

function Cr:Send(r)
	ns.Comm:Send("CREQ", { e = { [r.id] = r } })
end

function Cr:Request(id, name, count, note)
	local g = ns.guild
	if not g then return end
	counter = counter + 1
	local now = ns.Now()
	if id and id > 0 then name = self:ItemName(id, name) end
	local r = { id = ns.Me() .. now .. counter, by = ns.Me(), i = id or 0, n = ns.Trim(name), c = math.max(1, tonumber(count) or 1), note = ns.Trim(note), t = now, u = now }
	if r.n == "" then return end
	g.creq[r.id] = r
	self:Send(r)
	local who = self:WhoCanCraft(r.i, r.n)
	if #who == 0 then
		ns:Print(string.format(L["Wunsch eingetragen. Noch kann das niemand in der Gilde mit GuildSentinel herstellen: %s"], r.n))
	else
		ns:Print(string.format(L["Wunsch eingetragen. Herstellen können das: %s"], table.concat(who, ", ")))
	end
	ns:Fire("GS_CRAFT")
	return r
end

local function Update(id, fn)
	local g = ns.guild
	local r = g and g.creq[id]
	if not r then return end
	fn(r)
	r.u = ns.Now()
	Cr:Send(r)
	ns:Fire("GS_CRAFT")
	return r
end

function Cr:Take(id)
	local r = Update(id, function(r) r.taker = ns.Me() end)
	if r then ns:Print(string.format(L["Du stellst für %s her: %s ×%d."], r.by, r.n, r.c)) end
end

function Cr:Done(id) Update(id, function(r) r.done = true end) end
function Cr:Remove(id) Update(id, function(r) r.del = true end) end

function Cr:CanEdit(r)
	return ns.Same(r.by, ns.Me()) or ns.Same(r.taker, ns.Me()) or ns.IsOfficer()
end

function Cr:Store(r)
	local g = ns.guild
	if not g or type(r) ~= "table" or type(r.id) ~= "string" or type(r.by) ~= "string" then return false, nil end
	local u = tonumber(r.u) or tonumber(r.t) or 0
	local old = g.creq[r.id]
	if old and (old.u or 0) >= u then return false, old end
	g.creq[r.id] = {
		id = r.id, by = r.by, i = tonumber(r.i) or 0, n = type(r.n) == "string" and r.n or "?", c = tonumber(r.c) or 1,
		note = type(r.note) == "string" and r.note or "", t = tonumber(r.t) or u, u = u,
		taker = type(r.taker) == "string" and r.taker or nil, done = r.done and true or nil, del = r.del and true or nil,
	}
	return true, old
end

ns.Comm:Register("CREQ", function(sender, d)
	if type(d.e) ~= "table" then return end
	local any
	for _, r in pairs(d.e) do
		local ok, old = Cr:Store(r)
		if ok then
			any = true
			local cur = ns.G().creq[r.id]
			-- neuer Wunsch, den ich herstellen kann
			if not old and not cur.done and not cur.del and not ns.Same(cur.by, ns.Me()) and Cr:CanICraft(cur.i, cur.n) then
				ns:Print(string.format(L["%s möchte %s ×%d – das kannst du herstellen. /gs berufe"], cur.by, Cr:ItemLink(cur.i, cur.n), cur.c))
			end
			-- mein Wunsch wurde übernommen
			if ns.Same(cur.by, ns.Me()) and cur.taker and not (old and old.taker) then
				ns:Print(string.format(L["%s stellt dir %s her."], cur.taker, cur.n))
			end
		end
	end
	if any then ns:Fire("GS_CRAFT") end
end)

-- offene Wünsche (neueste zuerst); mineOnly = nur, was ich herstellen kann
function Cr:Requests(mineOnly, showDone)
	local out = {}
	local now = ns.Now()
	for _, r in pairs(ns.G().creq) do
		local keep = not r.del and (not r.done or showDone) and (now - (r.t or 0) < self.KEEP)
		if keep and (not mineOnly or self:CanICraft(r.i, r.n)) then out[#out + 1] = r end
	end
	table.sort(out, function(a, b)
		if (a.done and true or false) ~= (b.done and true or false) then return not a.done end
		return (a.t or 0) > (b.t or 0)
	end)
	return out
end

function Cr:OpenCount()
	local n = 0
	for _, r in ipairs(self:Requests(false)) do if not r.taker then n = n + 1 end end
	return n
end

-- aufräumen
ns:Listen("GS_LOGIN", function()
	local g = ns.guild
	if not g then return end
	local now = ns.Now()
	for id, r in pairs(g.creq) do
		if r.del and now - (r.u or 0) > 86400 then g.creq[id] = nil
		elseif r.done and now - (r.u or 0) > Cr.KEEP_DONE then g.creq[id] = nil
		elseif now - (r.t or 0) > Cr.KEEP then g.creq[id] = nil end
	end
end)
