-- GuildSentinel - Sync.lua
-- Abgleich beim Einloggen: Ich sage der Gilde, welchen Stand ich habe. Einer, der online ist, schickt mir
-- per Flüstern, was mir fehlt: Twinks, Gildenregeln und Bestätigungen, Raid-Zugänge, Online-Zeiten, Beitritte,
-- Online-Tage, Stufen und Rollen, offene Gruppensuchen, Umfragen, Herstellungswünsche und zum Schluss die Berufe.

local ADDON, ns = ...
local L = ns.L
local S = {}
ns.Sync = S

S.claimed = {}        -- [Anfragender] = GetTime()
S.lastSync = 0

local function MaxT(t, field)
	local m = 0
	for _, v in pairs(t or {}) do
		local x = type(v) == "table" and v[field or "t"] or nil
		if type(x) == "number" and x > m then m = x end
	end
	return m
end

function S:Digest()
	local g = ns.G()
	local p = {}
	for name, e in pairs(ns.Prof:All()) do p[name] = e.t or 0 end
	local ac = 0
	for slot in pairs(g.act) do if slot > ac then ac = slot end end
	return { p = p, a = MaxT(g.alts), r = g.rules.v or 0, at = MaxT(g.attune), ac = ac }
end

function S:Request()
	if not ns.guild or not IsInGuild() then return end
	self.lastSync = GetTime()
	ns.Comm:Send("SREQ", self:Digest())
	ns:Fire("GS_SYNC")
end

-- Antwort an einen Anfragenden (per Flüstern)
function S:Answer(to, d)
	local g = ns.guild
	if not g then return end
	local sent = 0
	-- Twinks zuerst (klein), Berufe zum Schluss (die Leitung ist gedrosselt)
	local at = tonumber(d.a) or 0
	local alts = {}
	for ch, a in pairs(g.alts) do if (a.t or 0) > at then alts[ch] = a end end
	if next(alts) then ns.Comm:Send("ALT", { e = alts }, "WHISPER", to); sent = sent + 1 end
	-- Gildenregeln und wer sie bestätigt hat
	if (g.rules.v or 0) > (tonumber(d.r) or 0) then ns.Comm:Send("RULES", g.rules, "WHISPER", to); sent = sent + 1 end
	if next(g.rulesAck) then ns.Comm:Send("RACKS", { e = g.rulesAck }, "WHISPER", to); sent = sent + 1 end
	-- Raid-Zugänge
	local att, attT = {}, tonumber(d.at) or 0
	for name, a in pairs(g.attune) do if (a.t or 0) > attT then att[name] = a end end
	if next(att) then ns.Comm:Send("ATTS", { e = att }, "WHISPER", to); sent = sent + 1 end
	-- offene Gruppensuchen
	for _, x in ipairs(ns.Group:Open()) do ns.Comm:Send("LFG", ns.Group:Wire(x), "WHISPER", to); sent = sent + 1 end
	-- Umfragen mit Stimmen, Herstellungswünsche
	local polls = ns.Poll:SyncData()
	if next(polls) then ns.Comm:Send("POLLS", { e = polls }, "WHISPER", to); sent = sent + 1 end
	local reqs = {}
	for _, r in ipairs(ns.Craft:Requests(false, true)) do reqs[r.id] = r end
	if next(reqs) then ns.Comm:Send("CREQ", { e = reqs }, "WHISPER", to); sent = sent + 1 end
	-- Brett, Termine, Abklingzeiten, Dank, Abwesenheit, Paten, Meilensteine, Addons
	local mkt = ns.Board:SyncData()
	if next(mkt) then ns.Comm:Send("MKT", { e = mkt }, "WHISPER", to); sent = sent + 1 end
	for name, o in pairs(g.svc) do
		if (o.u or 0) > ns.Now() then ns.Comm:Send("SVCS", { n = name, e = o }, "WHISPER", to); sent = sent + 1 end
	end
	local evs = ns.Events:SyncData()
	if next(evs) then ns.Comm:Send("EVTS", { e = evs }, "WHISPER", to); sent = sent + 1 end
	if next(g.cds) then ns.Comm:Send("CDS", { e = g.cds }, "WHISPER", to); sent = sent + 1 end
	local thx = ns.Social:ThanksSync(60)
	if next(thx) then ns.Comm:Send("THXS", { e = thx }, "WHISPER", to); sent = sent + 1 end
	ns.Comm:Send("SOC", { away = g.away, mentor = g.mentor, goal = g.goal, review = g.review }, "WHISPER", to); sent = sent + 1
	-- Leitung: Offiziersnotizen und Abgänge nur von Offizier zu Offizier
	if ns.Lead then ns.Lead:SyncTo(to) end
	if g.probation and g.probation.t then ns.Comm:Send("PROB", g.probation, "WHISPER", to) end
	-- Beute-Wünsche und Fragen
	if ns.Gear then local x = ns.Gear:SyncData(); if next(x) then ns.Comm:Send("GEARS", { e = x }, "WHISPER", to); sent = sent + 1 end end
	if ns.Ask then local x = ns.Ask:SyncData(); if next(x) then ns.Comm:Send("ASKS", { e = x }, "WHISPER", to); sent = sent + 1 end end
	ns.Comm:Send("MILES", { m = g.miles, w = g.goalDone }, "WHISPER", to); sent = sent + 1
	ns.Comm:Send("ADDALL", { e = g.addons }, "WHISPER", to); sent = sent + 1
	-- Gildendaten: Beitritt, Online-Tage (14), aktuelle Stufe mit Zeit, Erster auf 60
	ns.Comm:Send("MEM", S:MemData(), "WHISPER", to); sent = sent + 1
	-- Online-Zeiten (Messungen, die neuer sind als die des Anfragenden)
	local acFrom, slots, n = tonumber(d.ac) or 0, {}, 0
	for slot, c in pairs(g.act) do
		if slot > acFrom and n < 400 then slots[slot] = c; n = n + 1 end
	end
	if n > 0 then ns.Comm:Send("ACT", { s = slots }, "WHISPER", to); sent = sent + 1 end
	-- Berufe (nur von Mitgliedern, neueste zuerst)
	local p = type(d.p) == "table" and d.p or {}
	local list = {}
	local all = ns.Prof:All()
	for name, e in pairs(all) do
		if not ns.Same(name, to) and (e.t or 0) > (tonumber(p[name]) or 0) and type(e.p) == "table"
			and (ns.Roster.byName[name] or not next(ns.Roster.byName)) then
			list[#list + 1] = name
		end
	end
	table.sort(list, function(x, y) return (all[x].t or 0) > (all[y].t or 0) end)
	for _, name in ipairs(list) do
		local e = all[name]
		ns.Comm:Send("PROF", { n = name, c = e.c, t = e.t, p = e.p }, "WHISPER", to)
		sent = sent + 1
	end
	if ns.debug then ns:Print(string.format("sync -> %s: %d", to, sent)) end
end

-- Gildendaten kompakt: f = Beitritte, d = Online-Tage als Text "Tag,Tag,...", l = { Stufe, Zeit }, f60 = Erster auf 60
function S:MemData()
	local g = ns.G()
	local today = math.floor(ns.Now() / 86400)
	local days, lv = {}, {}
	for name, set in pairs(g.days) do
		local list = {}
		for dnum in pairs(set) do if dnum > today - 14 then list[#list + 1] = dnum - today end end
		if #list > 0 then days[name] = table.concat(list, ",") end
	end
	for _, e in ipairs(ns.Roster.list) do
		local t = ns.Race:LevelTime(e.name, e.level)
		if t then lv[e.name] = { e.level, t } end
	end
	return { f = g.firstSeen, d = days, today = today, l = lv, f60 = g.race.first60, r = g.roles }
end

ns.Comm:Register("MEM", function(sender, d)
	local g = ns.guild
	if not g then return end
	if type(d.f) == "table" then
		for name, t in pairs(d.f) do
			t = tonumber(t)
			if type(name) == "string" and t and t > 0 and (not g.firstSeen[name] or t < g.firstSeen[name]) then g.firstSeen[name] = t end
		end
	end
	local base = tonumber(d.today) or math.floor(ns.Now() / 86400)
	if type(d.d) == "table" then
		for name, list in pairs(d.d) do
			if type(name) == "string" and type(list) == "string" then
				g.days[name] = g.days[name] or {}
				for off in list:gmatch("-?%d+") do g.days[name][base + tonumber(off)] = true end
			end
		end
	end
	if type(d.l) == "table" then
		for name, x in pairs(d.l) do
			local l, t = type(x) == "table" and tonumber(x[1]), type(x) == "table" and tonumber(x[2])
			if type(name) == "string" and l and t and t > 0 then
				g.levels[name] = g.levels[name] or {}
				local cur = g.levels[name][l]
				if not cur or cur == 0 or t < cur then g.levels[name][l] = t end
			end
		end
	end
	if type(d.r) == "table" then
		for name, x in pairs(d.r) do
			if type(name) == "string" and type(x) == "table" then ns.Comp.StoreRole(name, x.r, tonumber(x.t)) end
		end
	end
	if type(d.f60) == "table" and type(d.f60.n) == "string" and not g.race.first60 then
		g.race.first60 = { n = d.f60.n, t = tonumber(d.f60.t) or 0 }
	end
	ns:Fire("GS_PROGRESS")
end)

ns.Comm:Register("SVCS", function(sender, d)
	if type(d.n) == "string" and not ns.Same(d.n, ns.Me()) and ns.Board.StoreSvc(d.n, d.e) then ns:Fire("GS_BOARD") end
end)

ns.Comm:Register("SOC", function(sender, d)
	local g = ns.guild
	if not g then return end
	for name, e in pairs(type(d.away) == "table" and d.away or {}) do ns.Social.StoreAway(name, e) end
	for name, e in pairs(type(d.mentor) == "table" and d.mentor or {}) do ns.Social.StoreMentor(name, e) end
	for key, t in pairs(type(d.review) == "table" and d.review or {}) do
		if type(key) == "string" and tonumber(t) and not g.review[key] then g.review[key] = tonumber(t) end
	end
	if type(d.goal) == "table" and type(d.goal.t) == "number" and (not g.goal.t or g.goal.t < d.goal.t) then
		g.goal = { target = tonumber(d.goal.target) or ns.Goals.DEFAULT_TARGET, t = d.goal.t, by = d.goal.by }
	end
	ns:Fire("GS_SOCIAL")
	ns:Fire("GS_GOALS")
end)

ns.Comm:Register("ADDALL", function(sender, d)
	local g = ns.guild
	if not g or type(d.e) ~= "table" then return end
	for name, e in pairs(d.e) do
		if type(name) == "string" and type(e) == "table" and not ns.Same(name, ns.Me()) and type(e.a) == "table"
			and (not g.addons[name] or (g.addons[name].t or 0) < (tonumber(e.t) or 0)) then
			ns.Links:Store(name, e.a)
			g.addons[name].t = tonumber(e.t) or ns.Now()
		end
	end
end)

ns.Comm:Register("ACT", function(sender, d)
	local g = ns.guild
	if not g or type(d.s) ~= "table" then return end
	for slot, c in pairs(d.s) do
		slot, c = tonumber(slot), tonumber(c)
		if slot and c and (not g.act[slot] or c > g.act[slot]) then g.act[slot] = c end
	end
	ns:Fire("GS_ACTIVITY")
end)

ns.Comm:Register("SREQ", function(sender, d, channel)
	if channel ~= "GUILD" or not ns.guild then return end
	ns.Comm:Seen(sender)
	-- kurz warten: Wer zuerst "ich mach's" sagt, antwortet
	C_Timer.After(1 + math.random() * 5, function()
		local c = S.claimed[sender]
		if c and GetTime() - c < 30 then return end
		S.claimed[sender] = GetTime()
		ns.Comm:Send("SCLAIM", { to = sender }, "GUILD", nil, true)
		C_Timer.After(0.5, function() S:Answer(sender, d) end)
	end)
end)

ns.Comm:Register("SCLAIM", function(sender, d)
	if type(d.to) == "string" then S.claimed[d.to] = GetTime() end
end)

ns:Listen("GS_LOGIN", function()
	C_Timer.After(25, function() S:Request() end)
end)
