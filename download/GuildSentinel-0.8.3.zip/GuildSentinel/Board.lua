-- GuildSentinel - Board.lua
-- Das Brett der Gilde:
--   * Dienste: Wer bietet gerade was an? Portale, Beschwören, Schlösser knacken, Verzauberungen, Seelensteine …
--     Klassen-Dienste erkennt GuildSentinel am Zauberbuch (mit BuffSentinel noch genauer); eigene Angebote
--     sind als Text möglich. Ein Angebot gilt, solange man online ist (höchstens 2 Stunden).
--   * Biete/Suche: Mitglieder bieten untereinander Items an oder suchen welche. Keine Gildenbank – gehandelt
--     wird direkt zwischen den Spielern. Mit AH Analyzer Pro steht der Marktwert dabei.
--
--   G.svc[Name] = { t, u = gültig bis, k = { [Dienst] = true }, x = eigener Text }
--   G.market[id] = { id, by, k = "offer"/"want", i = Item-ID, n = Name, c = Anzahl, p = Preis (Kupfer), note, t, u, del }

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local B = {}
ns.Board = B

B.SVC_TTL = 2 * 3600
B.MARKET_TTL = 7 * 86400

-- Dienste: Zauber-IDs (einer davon reicht), Klasse oder Beruf
B.SERVICES = {
	{ key = "port_uc", n = N["Portal: Unterstadt"], spells = { 11418 }, class = "MAGE", horde = true },
	{ key = "port_og", n = N["Portal: Orgrimmar"], spells = { 11417 }, class = "MAGE", horde = true },
	{ key = "port_tb", n = N["Portal: Donnerfels"], spells = { 11420 }, class = "MAGE", horde = true },
	{ key = "port_sw", n = N["Portal: Sturmwind"], spells = { 10059 }, class = "MAGE", alliance = true },
	{ key = "port_if", n = N["Portal: Eisenschmiede"], spells = { 11416 }, class = "MAGE", alliance = true },
	{ key = "port_da", n = N["Portal: Darnassus"], spells = { 11419 }, class = "MAGE", alliance = true },
	{ key = "food", n = N["Essen und Wasser"], spells = { 587, 5504 }, class = "MAGE" },
	{ key = "summon", n = N["Beschwören"], spells = { 698 }, class = "WARLOCK" },
	{ key = "soulstone", n = N["Seelenstein"], spells = { 693 }, class = "WARLOCK" },
	{ key = "lockpick", n = N["Schlösser knacken"], spells = { 1804 }, class = "ROGUE" },
	{ key = "enchant", n = N["Verzauberungen"], prof = 7411 },
	{ key = "craft", n = N["Herstellen (eigene Mats)"] },
	{ key = "run", n = N["Dungeon-Begleitung (Run)"] },
}
if ns.Game.TBC then
	-- TBC-Portale und Rituale vor den allgemeinen Diensten einfügen
	local pos = 1
	for i, s in ipairs(B.SERVICES) do if s.key == "food" then pos = i break end end
	for i, s in ipairs(ns.Game.TBC_SERVICES) do table.insert(B.SERVICES, pos + i - 1, s) end
end
B.BY_KEY = {}
for _, s in ipairs(B.SERVICES) do B.BY_KEY[s.key] = s end

local function SpellName(id)
	if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
	return GetSpellInfo and (GetSpellInfo(id)) or nil
end

function B:ServiceName(key)
	local s = self.BY_KEY[key]
	return s and L[s.n] or key
end

-- Dienste, die ich anbieten kann (nach Fraktion, Klasse, Zauberbuch, Beruf)
function B:MyServices()
	local _, cf = UnitClass("player")
	local faction = UnitFactionGroup and UnitFactionGroup("player")
	local out = {}
	for _, s in ipairs(self.SERVICES) do
		local ok = true
		if s.horde and faction ~= "Horde" then ok = false end
		if s.alliance and faction ~= "Alliance" then ok = false end
		if ok and s.class and s.class ~= cf then ok = false end
		if ok and s.spells then
			ok = false
			for _, id in ipairs(s.spells) do if ns.Links:KnowsSpell(id) then ok = true end end
		end
		if ok and s.prof then
			local name = SpellName(s.prof)
			local mine = ns.Prof:Of(ns.Me())
			ok = name and mine and mine.p and mine.p[name] ~= nil or false
		end
		if ok then out[#out + 1] = s end
	end
	return out
end

function B:MyOffer()
	local o = ns.G().svc[ns.Me()]
	if not o or (o.u or 0) <= ns.Now() then return nil end
	return o
end

-- keys = { [Dienst] = true }; text = eigenes Angebot; leer = Angebot zurückziehen
function B:SetOffer(keys, text)
	local g = ns.guild
	if not g then return end
	local any = ns.Trim(text) ~= ""
	for _ in pairs(keys or {}) do any = true end
	local e = { t = ns.Now(), u = any and (ns.Now() + self.SVC_TTL) or 0, k = keys or {}, x = ns.Trim(text):sub(1, 60) }
	g.svc[ns.Me()] = e
	ns.Comm:Send("SVC", e)
	ns:Fire("GS_BOARD")
end

function B:ClearOffer()
	self:SetOffer({}, "")
end

local function StoreSvc(name, e)
	local g = ns.guild
	if not g or type(name) ~= "string" or type(e) ~= "table" or type(e.t) ~= "number" then return false end
	local old = g.svc[name]
	if old and (old.t or 0) >= e.t then return false end
	local k = {}
	for key in pairs(type(e.k) == "table" and e.k or {}) do if B.BY_KEY[key] then k[key] = true end end
	g.svc[name] = { t = e.t, u = tonumber(e.u) or 0, k = k, x = type(e.x) == "string" and e.x:sub(1, 60) or "" }
	return true
end
B.StoreSvc = StoreSvc

ns.Comm:Register("SVC", function(sender, d)
	if StoreSvc(sender, d) then ns:Fire("GS_BOARD") end
end)

-- aktuelle Angebote von Mitgliedern, die online sind: { { name, class, keys, text, t } }
function B:Offers()
	local out = {}
	for name, o in pairs(ns.G().svc) do
		local e = ns.Roster.byName[name]
		local online = ns.Same(name, ns.Me()) or (e and e.online)
		if (o.u or 0) > ns.Now() and online then
			local list = {}
			for key in pairs(o.k or {}) do list[#list + 1] = key end
			table.sort(list)
			if #list > 0 or (o.x and o.x ~= "") then
				out[#out + 1] = { name = name, class = e and e.class, zone = e and e.zone, keys = list, text = o.x, t = o.t }
			end
		end
	end
	table.sort(out, function(a, b) return (a.t or 0) > (b.t or 0) end)
	return out
end

function B:OffersText(o)
	local t = {}
	for _, k in ipairs(o.keys) do t[#t + 1] = self:ServiceName(k) end
	if o.text and o.text ~= "" then t[#t + 1] = o.text end
	return table.concat(t, ", ")
end

function B:AskService(o)
	local what = self:OffersText(o)
	local text = string.format(L["Hallo %s! Du bietest gerade an: %s – hättest du kurz Zeit?"], o.name, what)
	ns.OpenWhisper(o.name, text)
end

-- beim Ausloggen das Angebot zurückziehen
ns:On("PLAYER_LOGOUT", function()
	local o = ns.guild and ns.guild.svc[ns.Me()]
	if o then o.u = 0 end
end)

------------------------------------------------------------
-- Biete/Suche
------------------------------------------------------------
local counter = 0

function B:Post(kind, itemID, name, count, price, note)
	local g = ns.guild
	if not g then return end
	if itemID and itemID > 0 then name = (ns.Item(itemID)) or name end
	name = ns.Trim(name)
	if name == "" then return end
	counter = counter + 1
	local now = ns.Now()
	local e = { id = ns.Me() .. now .. counter, by = ns.Me(), k = (kind == "want") and "want" or "offer", i = itemID or 0, n = name,
		c = math.max(1, tonumber(count) or 1), p = math.max(0, math.floor(tonumber(price) or 0)), note = ns.Trim(note):sub(1, 80), t = now, u = now }
	g.market[e.id] = e
	ns.Comm:Send("MKT", { e = { [e.id] = e } })
	ns:Fire("GS_BOARD")
	-- passt es zu einem Gegenstück? (jemand sucht, was ich anbiete – oder umgekehrt)
	for _, x in ipairs(self:Matches(e)) do
		ns:Print(string.format(e.k == "offer" and L["%s sucht genau das: %s"] or L["%s bietet genau das an: %s"], x.by, x.n))
	end
	return e
end

function B:Remove(id)
	local g = ns.guild
	local e = g and g.market[id]
	if not e then return end
	e.del, e.u = true, ns.Now()
	ns.Comm:Send("MKT", { e = { [id] = e } })
	ns:Fire("GS_BOARD")
end

function B:CanEdit(e)
	return e and (ns.Same(e.by, ns.Me()) or ns.IsOfficer())
end

local function StoreMkt(e)
	local g = ns.guild
	if not g or type(e) ~= "table" or type(e.id) ~= "string" or type(e.by) ~= "string" then return false, nil end
	local u = tonumber(e.u) or tonumber(e.t) or 0
	local old = g.market[e.id]
	if old and (old.u or 0) >= u then return false, old end
	g.market[e.id] = { id = e.id, by = e.by, k = e.k == "want" and "want" or "offer", i = tonumber(e.i) or 0,
		n = type(e.n) == "string" and e.n or "?", c = tonumber(e.c) or 1, p = tonumber(e.p) or 0,
		note = type(e.note) == "string" and e.note or "", t = tonumber(e.t) or u, u = u, del = e.del and true or nil }
	return true, old
end
B.StoreMkt = StoreMkt

ns.Comm:Register("MKT", function(sender, d)
	if type(d.e) ~= "table" then return end
	local any
	for _, e in pairs(d.e) do
		local ok, old = StoreMkt(e)
		if ok then
			any = true
			local cur = ns.G().market[e.id]
			if not old and not cur.del and not ns.Same(cur.by, ns.Me()) then
				-- passt zu einem meiner Einträge?
				for _, mine in ipairs(B:Matches(cur)) do
					if ns.Same(mine.by, ns.Me()) then
						ns:Print(string.format(cur.k == "offer" and L["%s bietet an, was du suchst: %s"] or L["%s sucht, was du anbietest: %s"], cur.by, cur.n))
						break
					end
				end
			end
		end
	end
	if any then ns:Fire("GS_BOARD") end
end)

local function SameItem(a, b)
	if (a.i or 0) > 0 and (b.i or 0) > 0 then return a.i == b.i end
	return a.n:lower() == b.n:lower()
end

-- Gegenstücke zu einem Eintrag (Angebot <-> Suche, gleiches Item, anderer Spieler)
function B:Matches(e)
	local out = {}
	for _, x in ipairs(self:List()) do
		if x.k ~= e.k and not ns.Same(x.by, e.by) and SameItem(x, e) then out[#out + 1] = x end
	end
	return out
end

function B:Active(e)
	return e and not e.del and ns.Now() - (e.t or 0) < self.MARKET_TTL
end

-- kind = nil (alle), "offer" oder "want"; query = Teil des Namens
function B:List(kind, query)
	query = ns.Trim(query):lower()
	local out = {}
	for _, e in pairs(ns.G().market) do
		if self:Active(e) and (not kind or e.k == kind) and (query == "" or e.n:lower():find(query, 1, true)) then
			out[#out + 1] = e
		end
	end
	table.sort(out, function(a, b) return (a.t or 0) > (b.t or 0) end)
	return out
end

function B:MarketValue(e)
	return ns.Links:MarketValue(e.i)
end

function B:Contact(e)
	local to = ns.Roster:OnlineChar(e.by) or e.by
	local _, link = ns.Item(e.i)
	local item = link or ("[" .. e.n .. "]")
	local fmt = e.k == "offer" and L["Hallo %s! Ich hätte Interesse an %s ×%d vom Brett."] or L["Hallo %s! Ich hätte %s für dich (Brett: Suche)."]
	-- Text um den Link herum aufteilen, damit der Link als echter Item-Link eingefügt wird
	local full = e.k == "offer" and string.format(fmt, to, "\001", e.c) or string.format(fmt, to, "\001")
	local before, after = full:match("^(.-)\001(.*)$")
	ns.OpenWhisper(to, before, item, after)
end

function B:SyncData()
	local out, n = {}, 0
	for id, e in pairs(ns.G().market) do
		if self:Active(e) and n < 150 then out[id] = e; n = n + 1 end
	end
	return out
end

ns:Listen("GS_LOGIN", function()
	local g = ns.guild
	if not g then return end
	local now = ns.Now()
	for id, e in pairs(g.market) do
		if e.del and now - (e.u or 0) > 86400 then g.market[id] = nil
		elseif now - (e.t or 0) > B.MARKET_TTL + 86400 then g.market[id] = nil end
	end
	for name, o in pairs(g.svc) do if (o.u or 0) < now - 86400 then g.svc[name] = nil end end
end)
