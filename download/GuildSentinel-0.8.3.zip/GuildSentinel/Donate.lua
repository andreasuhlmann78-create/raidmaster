-- ============================================================
-- GuildSentinel - Donate.lua
-- Spenden-Knopf (PayPal) von GoldSentinel.
-- Funktioniert in jeder WoW-Version (Retail, Classic, Anniversary, Era, WoW Forever),
-- ohne fremde Bibliotheken. WoW kann keine Webseiten öffnen: das Fenster zeigt den
-- Link markiert zum Kopieren (Strg+C), dann im Browser einfügen.
-- Nicht aufdringlich: öffnet sich nur auf Klick oder per Befehl (/gs spenden, donate, support).
--
-- In der .toc nach den Locale-Dateien und vor den Oberflächen-Dateien eingetragen.
-- Optik: flach und dunkel wie der Rest von GuildSentinel (ns.UI), sonst Blizzard-Vorlagen.
-- Texte: über das Übersetzungssystem des Addons (L["..."], Deutsch im Code).
-- Nutzung im Addon:
--   ns.Donate.Show()                              Fenster öffnen
--   ns.Donate.CreateButton(parent, breite, höhe)  Knopf „Unterstützen“ (öffnet das Fenster)
--   ns.Donate.ICON = "Interface\\AddOns\\<Ordner>\\Media\\Icon"   (optional, eigenes Icon)
-- ============================================================

local ADDON_NAME, ns = ...
ns = ns or {}
local L = ns.L or setmetatable({}, { __index = function(_, k) return k end })
local D = {}
ns.Donate = D

D.URL = "https://www.paypal.com/ncp/payment/46R68N2BF7BTY"
D.SIGN = "- GoldSentinel"
D.ICON = nil                         -- nil = Icon von GuildSentinel (ns.ICON), sonst Goldmünze

-- Texte (Deutsch = Schlüssel; Übersetzungen in Locales*.lua)
local TEXT = {
	title  = "%s unterstützen",
	button = "Unterstützen",
	thanks = "Danke, dass du %s unterstützt! Jede Spende hilft mir, mehr Zeit in neue Funktionen und schnelle Fehlerbehebungen zu stecken.",
	hint   = "Strg+C kopiert den PayPal-Link - dann im Browser einfügen.",
}
local function T(key)
	return L[TEXT[key]]
end
D.Text = T

-- Name des Addons aus der .toc (ohne Farbcodes)
local function AddonTitle()
	local get = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
	local t = get and get(ADDON_NAME, "Title") or ADDON_NAME
	return (tostring(t or ADDON_NAME):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
end
D.AddonTitle = AddonTitle

local BACKDROP = BackdropTemplateMixin and "BackdropTemplate" or nil
local frame

-- dunkle Fläche mit Rahmen (wie UI.Box), auch ohne ns.UI
local function Box(f, r, g, b, a, br, bg, bb, ba)
	if ns.UI and ns.UI.Box then return ns.UI.Box(f, r, g, b, a, br, bg, bb, ba) end
	if not f.SetBackdrop then return end
	f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
	f:SetBackdropColor(r, g, b, a)
	f:SetBackdropBorderColor(br, bg, bb, ba)
end

local function Accent()
	local A = ns.ACCENT or { 1, 0.82, 0 }
	return A[1], A[2], A[3]
end

local function Build()
	local f = CreateFrame("Frame", ADDON_NAME .. "DonateFrame", UIParent, BACKDROP)
	f:SetSize(470, 220)
	f:SetPoint("CENTER")
	f:SetFrameStrata("DIALOG")
	f:SetToplevel(true)
	f:SetClampedToScreen(true)
	f:EnableMouse(true)
	f:SetMovable(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", f.StartMoving)
	f:SetScript("OnDragStop", f.StopMovingOrSizing)
	local ar, ag, ab = Accent()
	Box(f, 0.05, 0.06, 0.08, 0.98, ar, ag, ab, 0.8)
	if UISpecialFrames then table.insert(UISpecialFrames, f:GetName()) end      -- Esc schließt

	f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	f.title:SetPoint("TOP", 0, -16)
	f.title:SetTextColor(ar, ag, ab)

	local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", -2, -2)
	close:SetScript("OnClick", function() f:Hide() end)
	f.close = close

	local icon = f:CreateTexture(nil, "ARTWORK")
	icon:SetSize(36, 36)
	icon:SetPoint("TOPLEFT", 24, -48)
	icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	f.icon = icon

	f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	f.text:SetPoint("TOPLEFT", icon, "TOPRIGHT", 12, 0)
	f.text:SetPoint("RIGHT", f, "RIGHT", -24, 0)
	f.text:SetJustifyH("LEFT")
	if f.text.SetWordWrap then f.text:SetWordWrap(true) end

	-- Eingabefeld im Stil von GuildSentinel, nur zum Kopieren
	local holder = CreateFrame("Frame", nil, f, BACKDROP)
	holder:SetSize(410, 26)
	holder:SetPoint("TOPLEFT", 30, -130)
	Box(holder, 0.04, 0.05, 0.07, 1, ar, ag, ab, 1)
	local eb = CreateFrame("EditBox", nil, holder)
	eb:SetPoint("TOPLEFT", 6, 0)
	eb:SetPoint("BOTTOMRIGHT", -6, 0)
	eb:SetAutoFocus(false)
	eb:SetFontObject(ChatFontNormal or GameFontHighlight)
	-- Änderungen sofort zurücknehmen
	eb:SetScript("OnTextChanged", function(self, user)
		if user and self:GetText() ~= D.URL then self:SetText(D.URL); self:HighlightText() end
	end)
	eb:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
	eb:SetScript("OnEscapePressed", function() f:Hide() end)
	eb:SetScript("OnEnterPressed", function() f:Hide() end)
	holder:EnableMouse(true)
	holder:SetScript("OnMouseDown", function() eb:SetFocus(); eb:HighlightText() end)
	f.edit = eb
	f.editHolder = holder

	f.hint = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	f.hint:SetPoint("TOPLEFT", holder, "BOTTOMLEFT", 0, -8)
	f.hint:SetPoint("RIGHT", f, "RIGHT", -24, 0)
	f.hint:SetJustifyH("LEFT")

	f.sign = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	f.sign:SetPoint("BOTTOMRIGHT", -24, 18)
	f.sign:SetText(D.SIGN)
	f:SetScript("OnHide", function() eb:ClearFocus() end)
	f:Hide()
	return f
end

function D.Show()
	frame = frame or Build()
	local title = AddonTitle()
	frame.title:SetText(string.format(T("title"), title))
	frame.text:SetText(string.format(T("thanks"), title))
	frame.hint:SetText(T("hint"))
	frame.icon:SetTexture(D.ICON or ns.ICON or "Interface\\Icons\\INV_Misc_Coin_01")
	frame:Show()
	frame.edit:SetText(D.URL)
	frame.edit:SetFocus()
	frame.edit:HighlightText()
	return frame
end

function D.Hide()
	if frame then frame:Hide() end
end

function D.IsShown()
	return frame and frame:IsShown() or false
end

function D.Frame()
	return frame
end

function D.Toggle()
	if frame and frame:IsShown() then frame:Hide() else D.Show() end
end

-- Knopf „Unterstützen“ für Titelleiste, Einstellungen o. Ä.
-- Wird mindestens so breit wie der Text (lange Wörter in manchen Sprachen).
function D.CreateButton(parent, width, height)
	local b
	if ns.UI and ns.UI.Button then
		b = ns.UI:Button(parent, T("button"), width or 100, height or 22, function() D.Show() end)
	else
		b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
		b:SetSize(width or 100, height or 22)
		b:SetText(T("button"))
		b:SetScript("OnClick", function() D.Show() end)
	end
	local fs = b.text or (b.GetFontString and b:GetFontString())
	if fs and fs.GetStringWidth then
		local need = math.ceil((fs:GetStringWidth() or 0) + 24)
		if need > b:GetWidth() then b:SetWidth(need) end
	end
	b:HookScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
		GameTooltip:SetText(string.format(T("title"), AddonTitle()), 1, 1, 1)
		GameTooltip:AddLine("PayPal", 0.8, 0.8, 0.8)
		GameTooltip:Show()
	end)
	b:HookScript("OnLeave", function() GameTooltip:Hide() end)
	b.isDonate = true
	return b
end
