-- GuildSentinel - Gear.lua
-- Beute-Wünsche: Jeder trägt ein, welchen Gegenstand er aus welchem Dungeon (oder Raid) noch braucht.
-- In der Gruppensuche steht dann "Dampfkammer: 3 Wünsche" – so findet man schneller Mitspieler, die
-- ohnehin dorthin wollen. Wünsche bleiben 30 Tage oder bis "Bekommen!".
--
--   G.gear[id] = { id, by, i = Item-ID, n = Name, act = Dungeon-Schlüssel, t, u, done, del }

local ADDON, ns = ...
local L = ns.L
local Ge = {}
ns.Gear = Ge

Ge.TTL = 30 * 86400
local counter = 0

function Ge:Active(e)
	return e and not e.del and not e.done and ns.Now() - (e.t or 0) < self.TTL
end

function Ge:Add(itemID, name, act)
	local g = ns.guild
	if not g then return end
	if itemID and itemID > 0 then name = (ns.Item(itemID)) or name end
	name = ns.Trim(name)
	if name == "" then ns:Print(L["Bitte einen Gegenstand angeben (Shift-Klick oder Name)."]) return end
	if not act or not ns.Group.BY_KEY[act] then ns:Print(L["Bitte einen Dungeon wählen."]) return end
	counter = counter + 1
	local now = ns.Now()
	local e = { id = ns.Me() .. now .. counter, by = ns.Me(), i = itemID or 0, n = name, act = act, t = now, u = now }
	g.gear[e.id] = e
	ns.Comm:Send("GEAR", { e = { [e.id] = e } })
	ns:Fire("GS_GEAR")
	return e
end

local function Update(id, fn)
	local g = ns.guild
	local e = g and g.gear[id]
	if not e or not (ns.Same(e.by, ns.Me()) or ns.IsOfficer()) then return end
	fn(e)
	e.u = ns.Now()
	ns.Comm:Send("GEAR", { e = { [id] = e } })
	ns:Fire("GS_GEAR")
end
function Ge:Done(id) Update(id, function(e) e.done = true end) end
function Ge:Remove(id) Update(id, function(e) e.del = true end) end

local function Store(e)
	local g = ns.guild
	if not g or type(e) ~= "table" or type(e.id) ~= "string" or type(e.by) ~= "string" then return false end
	local u = tonumber(e.u) or tonumber(e.t) or 0
	local old = g.gear[e.id]
	if old and (old.u or 0) >= u then return false end
	g.gear[e.id] = { id = e.id, by = e.by, i = tonumber(e.i) or 0, n = type(e.n) == "string" and e.n:sub(1, 80) or "?",
		act = type(e.act) == "string" and e.act or "other", t = tonumber(e.t) or u, u = u, done = e.done and true or nil, del = e.del and true or nil }
	return true
end
Ge.Store = Store

local function OnGear(sender, d)
	if type(d.e) ~= "table" then return end
	local any
	for _, e in pairs(d.e) do if Store(e) then any = true end end
	if any then ns:Fire("GS_GEAR") end
end
ns.Comm:Register("GEAR", OnGear)
ns.Comm:Register("GEARS", OnGear)

-- offene Wünsche: alle oder für einen Dungeon; nur Spieler, die noch in der Gilde sind
function Ge:List(act)
	local out = {}
	for _, e in pairs(ns.G().gear) do
		if self:Active(e) and (not act or e.act == act) and (ns.Roster.byName[e.by] or ns.Same(e.by, ns.Me()) or not next(ns.Roster.byName)) then
			out[#out + 1] = e
		end
	end
	table.sort(out, function(a, b)
		local na, nb = ns.Group:ActivityName({ act = a.act }), ns.Group:ActivityName({ act = b.act })
		if na ~= nb then return na < nb end
		return (a.t or 0) > (b.t or 0)
	end)
	return out
end

function Ge:Mine()
	local out = {}
	for _, e in ipairs(self:List()) do if ns.Same(e.by, ns.Me()) then out[#out + 1] = e end end
	return out
end

-- Anzahl Spieler mit offenen Wünschen je Dungeon: { [act] = n }
function Ge:Counts()
	local out, seen = {}, {}
	for _, e in ipairs(self:List()) do
		local k = e.act .. "|" .. (ns.Roster:MainOf(e.by) or e.by)
		if not seen[k] then seen[k] = true; out[e.act] = (out[e.act] or 0) + 1 end
	end
	return out
end

function Ge:SyncData()
	local out, n = {}, 0
	for id, e in pairs(ns.G().gear) do
		if (self:Active(e) or (e.u or 0) > ns.Now() - 86400) and n < 150 then out[id] = e; n = n + 1 end
	end
	return out
end

ns:Listen("GS_LOGIN", function()
	local g = ns.guild
	if not g then return end
	for id, e in pairs(g.gear) do
		if ns.Now() - (e.u or e.t or 0) > Ge.TTL + 7 * 86400 then g.gear[id] = nil end
	end
end)
