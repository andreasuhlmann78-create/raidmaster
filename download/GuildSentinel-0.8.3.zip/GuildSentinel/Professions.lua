-- GuildSentinel - Professions.lua
-- Berufe-Verzeichnis: Öffnet jemand ein Berufsfenster, liest GuildSentinel Stufe und alle Rezepte aus
-- und schickt sie an die Gilde. So weiß jeder mit dem Addon, wer was herstellen kann.
-- Mit RaidMaster: RaidMaster liest und verschickt die Berufe (gleiches Format in RaidMasterDB.prof),
-- GuildSentinel zeigt sie nur an. So gehen die Berufe nicht doppelt durch den Gildenkanal.
--
--   G.prof[Name] = { c = Klasse, t = Zeit, p = { [Beruf] = { r = Stufe, m = Max, n = { Rezepte }, i = { Item-IDs } } } }

local ADDON, ns = ...
local L = ns.L
local P = {}
ns.Prof = P

-- Berufe mit Fenster (Zauber-ID zum Öffnen; der Name kommt aus dem Spiel, also in jeder Sprache richtig)
P.CRAFT_SPELLS = { 2259, 2018, 7411, 4036, 2108, 3908, 2550, 3273, 2656 }  -- Alchemie, Schmieden, Verzauberkunst, Ingenieur, Leder, Schneidern, Kochen, Erste Hilfe, Verhüttung
P.MINING = 2575

local function SpellName(id)
	if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
	return GetSpellInfo and (GetSpellInfo(id)) or nil
end

local function Store()
	return ns.G().prof
end

-- alle bekannten Berufe: eigene Daten plus die aus RaidMaster (der neuere Stand gewinnt)
function P:All()
	local gs = Store()
	local rm = ns.RMI:Profs()
	if not rm then return gs end
	local out = {}
	for k, v in pairs(gs) do out[k] = v end
	for k, v in pairs(rm) do
		if type(k) == "string" and type(v) == "table" and type(v.p) == "table" and (not out[k] or (v.t or 0) >= (out[k].t or 0)) then
			out[k] = v
		end
	end
	return out
end

function P:Of(name)
	return self:All()[name]
end

local function Mine()
	local s = Store()
	local me = ns.Me()
	s[me] = s[me] or { p = {} }
	s[me].c = select(2, UnitClass("player"))
	return s[me]
end

-- Stufen aller Berufe aus der Fertigkeitenliste (auch Sammelberufe)
function P:ReadSkillLines()
	local out = {}
	if not GetNumSkillLines then return out end
	local section
	for i = 1, GetNumSkillLines() do
		local name, isHeader, _, rank, _, _, max = GetSkillLineInfo(i)
		if isHeader then
			section = name
		elseif name and (section == TRADE_SKILLS or section == SECONDARY_SKILLS) then
			out[name] = { r = rank, m = max }
		end
	end
	return out
end

local function IDFromLink(link)
	return type(link) == "string" and tonumber(link:match("item:(%d+)")) or 0
end

-- offenes Berufsfenster lesen ("trade" = Fertigkeitenfenster, "craft" = Verzauberkunst in Classic)
function P:ScanOpen(kind)
	if not ns.guild then return nil end
	if ns.RMI:Active() then
		-- RaidMaster liest das Fenster selbst; hier nur merken, welcher Beruf dran war
		local profName = (kind == "craft") and (GetCraftDisplaySkillLine and GetCraftDisplaySkillLine()) or (GetTradeSkillLine and GetTradeSkillLine())
		if not profName or profName == "" or profName == "UNKNOWN" then return nil end
		self.scanned = self.scanned or {}
		self.scanned[profName] = true
		C_Timer.After(1, function() ns:Fire("GS_PROF") end)
		local mine = self:Of(ns.Me())
		local v = mine and mine.p and mine.p[profName]
		return profName, v and v.n and #v.n or 0, false
	end
	local profName, rank, max
	local ids, names = {}, {}
	if kind == "craft" then
		if not GetCraftDisplaySkillLine then return nil end
		profName, rank, max = GetCraftDisplaySkillLine()
		for i = 1, (GetNumCrafts and GetNumCrafts() or 0) do
			local name, _, ctype = GetCraftInfo(i)
			if name and ctype ~= "header" then
				ids[#ids + 1] = IDFromLink(GetCraftItemLink and GetCraftItemLink(i))
				names[#names + 1] = name
			end
		end
	else
		if not GetTradeSkillLine then return nil end
		profName, rank, max = GetTradeSkillLine()
		-- Filter/zugeklappte Kategorien würden Rezepte verstecken: nur lesen, wenn alles sichtbar ist
		for i = 1, (GetNumTradeSkills and GetNumTradeSkills() or 0) do
			local name, ttype, _, expanded = GetTradeSkillInfo(i)
			if ttype == "header" and expanded == false and ExpandTradeSkillSubClass then
				ExpandTradeSkillSubClass(0)
				break
			end
		end
		for i = 1, (GetNumTradeSkills and GetNumTradeSkills() or 0) do
			local name, ttype = GetTradeSkillInfo(i)
			if name and ttype ~= "header" then
				ids[#ids + 1] = IDFromLink(GetTradeSkillItemLink and GetTradeSkillItemLink(i))
				names[#names + 1] = name
			end
		end
	end
	if not profName or profName == "" or profName == "UNKNOWN" or #names == 0 then return nil end
	local me = Mine()
	local old = me.p[profName]
	-- Rezepte verlernt man nicht: bekannte behalten (falls ein Filter im Fenster welche versteckt)
	local seen = {}
	for _, n in ipairs(names) do seen[n] = true end
	if old and old.n then
		for k, n in ipairs(old.n) do
			if not seen[n] then
				names[#names + 1] = n
				ids[#ids + 1] = old.i and old.i[k] or 0
				seen[n] = true
			end
		end
	end
	local changed = not old or #(old.n or {}) ~= #names or old.r ~= rank
	me.p[profName] = { r = rank, m = max, n = names, i = ids }
	for name, v in pairs(self:ReadSkillLines()) do
		me.p[name] = me.p[name] or {}
		me.p[name].r, me.p[name].m = v.r, v.m
	end
	if changed then
		me.t = ns.Now()
		self:ScheduleSend()
	end
	self.scanned = self.scanned or {}
	self.scanned[profName] = true
	ns:Fire("GS_PROF")
	return profName, #names, changed
end

-- nur Stufen (z. B. Kräuterkunde) ohne Fenster
function P:UpdateLevels()
	if not ns.guild or ns.RMI:Active() then return end
	local me = Mine()
	local changed
	local now = self:ReadSkillLines()
	for name, v in pairs(now) do
		me.p[name] = me.p[name] or {}
		if me.p[name].r ~= v.r then changed = true end
		me.p[name].r, me.p[name].m = v.r, v.m
	end
	-- verlernte Berufe entfernen
	if next(now) then
		for name in pairs(me.p) do
			if not now[name] and not self:IsCraftName(name) then me.p[name] = nil; changed = true end
		end
	end
	if changed then
		me.t = ns.Now()
		self:ScheduleSend()
		ns:Fire("GS_PROF")
	end
end

function P:IsCraftName(name)
	for _, id in ipairs(self.CRAFT_SPELLS) do
		if SpellName(id) == name then return true end
	end
	return false
end

local function AfterScan(kind)
	local name, n = P:ScanOpen(kind)
	if name and P.announce then
		P.announce = nil
		ns:Print(string.format(L["%s eingelesen (%d Rezepte)."], name, n))
	end
end
ns:On("TRADE_SKILL_SHOW", function() C_Timer.After(0.4, function() AfterScan("trade") end) end)
ns:On("TRADE_SKILL_UPDATE", function()
	if P.tsPending then return end
	P.tsPending = true
	C_Timer.After(1, function() P.tsPending = false; if TradeSkillFrame and TradeSkillFrame:IsShown() then AfterScan("trade") end end)
end)
ns:On("CRAFT_SHOW", function() C_Timer.After(0.4, function() AfterScan("craft") end) end)
ns:On("SKILL_LINES_CHANGED", function()
	if P.slPending then return end
	P.slPending = true
	C_Timer.After(2, function() P.slPending = false; P:UpdateLevels() end)
end)

------------------------------------------------------------
-- Berufe mit Fenster, die ich habe (für den Knopf "Nächsten Beruf öffnen")
------------------------------------------------------------
function P:Openable()
	local list = {}
	local skills = self:ReadSkillLines()
	for _, id in ipairs(self.CRAFT_SPELLS) do
		local name = SpellName(id)
		if name then
			local skill = (id == 2656) and SpellName(self.MINING) or name
			if skills[skill] or skills[name] then list[#list + 1] = name end
		end
	end
	return list
end

-- welchen Beruf der Knopf als Nächstes öffnet (nil = alle durch)
function P:NextToOpen()
	self.scanned = self.scanned or {}
	for _, name in ipairs(self:Openable()) do
		if not self.scanned[name] then return name end
	end
	return nil
end

function P:ReadNext()
	ns:Print(L["Öffne jedes Berufsfenster einmal (oder nutze den Knopf auf der Seite Berufe) – GuildSentinel liest es automatisch."])
	if ns.UI then ns.UI:Open("prof") end
end

------------------------------------------------------------
-- An die Gilde
------------------------------------------------------------
function P:ScheduleSend()
	if self.sendPending then return end
	self.sendPending = true
	C_Timer.After(4, function()
		self.sendPending = false
		self:SendMine()
	end)
end

function P:SendMine(channel, target)
	if ns.RMI:Active() then return end      -- RaidMaster verschickt die Berufe schon
	local me = Store()[ns.Me()]
	if not me or not ns.InGuild() then return end
	ns.Comm:Send("PROF", { n = ns.Me(), c = me.c, t = me.t, p = me.p }, channel or "GUILD", target)
end

-- d.n erlaubt es, beim Abgleich auch die Daten anderer weiterzugeben
function P:Receive(sender, d)
	if type(d.p) ~= "table" then return end
	local who = (type(d.n) == "string" and d.n ~= "") and d.n or sender
	if ns.Same(who, ns.Me()) then return end
	local s = Store()
	local old = s[who]
	local t = tonumber(d.t) or 0
	if old and (old.t or 0) >= t then return end
	s[who] = { c = d.c, t = t, p = d.p }
	ns:Fire("GS_PROF")
end

ns.Comm:Register("PROF", function(sender, d) P:Receive(sender, d) end)

-- einmal am Tag nach dem Einloggen die eigenen Berufe verteilen
ns:Listen("GS_LOGIN", function()
	C_Timer.After(20, function()
		P:UpdateLevels()
		local g = ns.guild
		if g and not ns.RMI:Active() and Store()[ns.Me()] and (g.profSent or 0) < ns.Now() - 86400 then
			g.profSent = ns.Now()
			P:SendMine()
		end
	end)
end)

------------------------------------------------------------
-- Suchen
------------------------------------------------------------
-- Wer kann das herstellen? -> { { name, prof, recipe, id, rank } }
function P:Find(query)
	query = ns.Trim(query):lower()
	local out = {}
	if query == "" then return out end
	for who, e in pairs(self:All()) do
		if ns.Roster.byName[who] or not next(ns.Roster.byName) then
			for prof, v in pairs(e.p or {}) do
				for k, n in ipairs(v.n or {}) do
					if n:lower():find(query, 1, true) then
						out[#out + 1] = { name = who, prof = prof, recipe = n, id = v.i and v.i[k] or 0, rank = v.r, class = e.c }
					end
				end
			end
		end
	end
	table.sort(out, function(a, b)
		if a.recipe ~= b.recipe then return a.recipe < b.recipe end
		local ao, bo = ns.Roster:OnlineChar(a.name) ~= nil, ns.Roster:OnlineChar(b.name) ~= nil
		if ao ~= bo then return ao end
		return a.name < b.name
	end)
	return out
end

-- Übersicht: Beruf -> { { name, r, m, n = Anzahl Rezepte } } (beste zuerst)
function P:Overview()
	local out = {}
	for who, e in pairs(self:All()) do
		if ns.Roster.byName[who] or not next(ns.Roster.byName) then
			for prof, v in pairs(e.p or {}) do
				out[prof] = out[prof] or {}
				table.insert(out[prof], { name = who, r = v.r or 0, m = v.m or 0, n = #(v.n or {}), class = e.c, t = e.t })
			end
		end
	end
	for _, list in pairs(out) do
		table.sort(list, function(a, b) if a.r == b.r then return a.name < b.name end return a.r > b.r end)
	end
	return out
end

function P:ProfNames()
	local out = {}
	for prof, list in pairs(self:Overview()) do out[#out + 1] = { name = prof, count = #list } end
	table.sort(out, function(a, b) return a.name < b.name end)
	return out
end

-- Link zum Rezept (wenn das Item bekannt ist), sonst [Name]
function P:RecipeLink(id, name)
	if id and id > 0 then
		local _, link = ns.Item(id)
		if link then return link end
	end
	return "[" .. tostring(name) .. "]"
end

function P:AskCraft(r)
	local target = ns.Roster:OnlineChar(r.name) or r.name
	local full = string.format(L["Hallo %s! Könntest du mir %s herstellen? Die Materialien bringe ich mit."], target, "\001")
	local before, after = full:match("^(.-)\001(.*)$")
	ns.OpenWhisper(target, before, self:RecipeLink(r.id, r.recipe), after)
end
