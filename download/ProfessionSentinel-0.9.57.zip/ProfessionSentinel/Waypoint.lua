local _, ns = ...
local L = ns.L

-- Locations and waypoints for NPCs (trainers, vendors, drop mobs).
-- ns.NPCs[id] = { name, zone, faction, title, level, uiMapID, x, y }
-- Waypoint order: LevelPilot (navigation with an arrow, LevelPilotAPI.NavigateTo, 0.9.57) -> TomTom (if installed) -> the
-- game's own map pin (C_Map.SetUserWaypoint via ns.Act) -> chat output.

local WP = {}
ns.Waypoint = WP

-- Zone name in the client's language (falls back to the stored name)
function WP.ZoneName(n)
    if not n then return nil end
    local mapID = n[6]
    if mapID and C_Map and C_Map.GetMapInfo then
        local ok, info = pcall(C_Map.GetMapInfo, mapID)
        if ok and info and info.name and info.name ~= "" then return info.name end
    end
    return n[2]
end

function WP.Has(id)
    local n = ns.NPCs[id]
    return n and n[6] and n[7] and n[8] and true or false
end

-- "Zone 41.5, 42.6" (or just the zone, or nil)
function WP.LocationText(id)
    local n = ns.NPCs[id]
    if not n then return nil end
    local zone = WP.ZoneName(n)
    if n[7] and n[8] then
        return string.format("%s %.1f, %.1f", zone or "?", n[7], n[8])
    end
    return zone
end

-- Is the NPC friendly to the player's faction? (nil faction = hostile to both / unknown -> false)
-- the player's faction ("Horde"/"Alliance"); the test routine can set WP.factionTest for the counter-check
function WP.MyFaction()
    if WP.factionTest then return WP.factionTest end
    return UnitFactionGroup and UnitFactionGroup("player") or nil
end

function WP.IsFriendly(id)
    local n = ns.NPCs[id]
    local fac = n and n[3]
    if not fac then return false end
    local mine = WP.MyFaction()
    local want = mine == "Horde" and "H" or "A"
    return fac:find(want, 1, true) ~= nil
end

function WP.Available()
    local TomTom = ns.Foreign("TomTom")
    if TomTom and TomTom.AddWaypoint then return "TomTom" end
    if ns.CanAct("waypoint") then return "map" end
    return nil
end

-- Sets a waypoint to the NPC. Returns true when a waypoint was placed.
function WP.Set(id, label)
    if ns.BlockedInCombat() then return false end
    local n = ns.NPCs[id]
    if not n or not n[6] or not n[7] or not n[8] then
        ns.Print(L.WP_NO_COORDS)
        return false
    end
    local mapID, x, y = n[6], n[7] / 100, n[8] / 100
    local title = label or n[1]
    local where = WP.LocationText(id) or ""
    -- 0) LevelPilot (version >= 1): x/y in percent; true = it navigates (the target ends when reached)
    local LP = ns.Foreign("LevelPilotAPI")
    if type(LP) == "table" and type(LP.NavigateTo) == "function" then
        local ok, res = pcall(LP.NavigateTo, mapID, n[7], n[8], title)
        if not ok then ns.CountError("LevelPilot", res) end
        if ok and res == true then
            ns.Print(string.format(L.WP_SET, title, where) .. " (LevelPilot)")
            return true
        end
    end
    -- 1) TomTom
    local TomTom = ns.Foreign("TomTom")
    if TomTom and TomTom.AddWaypoint then
        local ok, err = pcall(TomTom.AddWaypoint, TomTom, mapID, x, y, { title = title, persistent = false, minimap = true, world = true })
        if not ok then ns.CountError("TomTom", err) end
        if ok then
            ns.Print(string.format(L.WP_SET, title, where) .. " (TomTom)")
            return true
        end
    end
    -- 2) the game's own map pin
    if ns.CanAct("waypoint") then
        local can = true
        if ns.API.MapCanSetUserWaypointOnMap then
            local ok, res = pcall(ns.API.MapCanSetUserWaypointOnMap, mapID)
            can = ok and res
        end
        if can then
            local okP, set = pcall(ns.Act, "waypoint", mapID, x, y)     -- map pin + super tracking (ns.Act)
            if okP and set then
                ns.Print(string.format(L.WP_SET, title, where))
                return true
            end
        end
    end
    -- 3) chat only
    ns.Print(string.format(L.WP_CHAT, title, where))
    return false
end

-- Best NPC to walk to for a recipe: a friendly vendor first, then any vendor, then a drop mob.
function WP.BestSourceNPC(r)
    local anyVendor, drop
    for _, ri in ipairs(r.recipeItems or {}) do
        for _, id in ipairs(ri.v or {}) do
            if WP.Has(id) then
                if WP.IsFriendly(id) then return id, "vendor" end
                anyVendor = anyVendor or id
            end
        end
        if (ri.dn or 0) <= 15 then
            for _, id in ipairs(ri.d or {}) do
                if WP.Has(id) then drop = drop or id end
            end
        end
    end
    if anyVendor then return anyVendor, "vendor" end
    if drop then return drop, "drop" end
    return nil
end

-- Trainer ranks
WP.RANKS = {
    { key = 4, cap = 300, req = 200, level = 35 },
    { key = 3, cap = 225, req = 125, level = 20 },
    { key = 2, cap = 150, req = 50, level = 10 },
    { key = 1, cap = 75, req = 1, level = 5 },
    { key = 5 },
    { key = 0 },
}

-- Which rank does the player need next? Returns the rank table or nil (cap reached or unknown).
function WP.NextRank(rank, maxRank)
    if not rank or not maxRank or maxRank <= 0 then return nil end
    for i = #WP.RANKS, 1, -1 do
        local r = WP.RANKS[i]
        if r.cap and r.cap > maxRank then return r end
    end
    return nil
end

---------------------------------------------------------------------------
-- Nearest suitable trainer (UI rework 2, question of the user 19:37: "what if someone does not know where the next trainer
-- is?"). The trainer of the NEXT rank, own faction, sorted by distance to the player: same continent by world coordinates
-- (C_Map.GetWorldPosFromMapPos, in yards); otherwise a capital of the faction first. Only reading map functions.
---------------------------------------------------------------------------
WP.CAPITALS = { [1454] = "H", [1458] = "H", [1456] = "H", [1453] = "A", [1455] = "A", [1457] = "A" }   -- uiMapIDs
WP.posCache = {}

local function WorldPos(mapID, x, y)
    local A = ns.API
    if not (A.MapGetWorldPosFromMapPos and A.CreateVector2D and mapID and x and y) then return nil end
    local okV, vec = pcall(A.CreateVector2D, x, y)
    if not okV or not vec then return nil end
    local ok, cont, pos = pcall(A.MapGetWorldPosFromMapPos, mapID, vec)
    if not ok or not cont or type(pos) ~= "table" then return nil end
    local px, py
    if pos.GetXY then px, py = pos:GetXY() else px, py = pos.x, pos.y end
    if type(px) ~= "number" or type(py) ~= "number" then return nil end
    return cont, px, py
end

-- the player's position: continent, x, y (yards) – nil when unknown (instance, no map)
function WP.PlayerPos()
    local A = ns.API
    if not (A.MapGetBestMapForUnit and A.MapGetPlayerMapPosition) then return nil end
    local ok, mapID = pcall(A.MapGetBestMapForUnit, "player")
    if not ok or not mapID then return nil end
    local okP, pos = pcall(A.MapGetPlayerMapPosition, mapID, "player")
    if not okP or type(pos) ~= "table" then return nil end
    local x, y
    if pos.GetXY then x, y = pos:GetXY() else x, y = pos.x, pos.y end
    return WorldPos(mapID, x, y)
end

-- an NPC's position (cached: NPCs do not move)
function WP.NpcPos(id)
    local c = WP.posCache[id]
    if c ~= nil then return c and c[1], c and c[2], c and c[3] end
    local n = ns.NPCs[id]
    local cont, x, y
    if n and n[6] and n[7] and n[8] then cont, x, y = WorldPos(n[6], n[7] / 100, n[8] / 100) end
    WP.posCache[id] = cont and { cont, x, y } or false
    return cont, x, y
end

-- distance in yards (nil: other continent or unknown)
function WP.Distance(id, pc, px, py)
    if not pc then return nil end
    local cont, x, y = WP.NpcPos(id)
    if not cont or cont ~= pc then return nil end
    return math.sqrt((x - px) ^ 2 + (y - py) ^ 2)
end

-- the character level (the test routine sets WP.levelTest)
function WP.PlayerLevel()
    if WP.levelTest then return WP.levelTest end
    return ns.API.UnitLevel and ns.API.UnitLevel("player") or nil
end

-- the rank to learn next for this skill: rank table (WP.RANKS) or nil
function WP.RankFor(rank, maxRank) return WP.NextRank(rank, maxRank) end

-- nearest friendly trainer of a rank: id, yards (nil = other continent), how ("near" | "capital" | "any") – or nil
function WP.NearestTrainer(prof, rankKey)
    local list = ns.Trainers and ns.Trainers[prof] or {}
    local pc, px, py = WP.PlayerPos()
    local best, bestD, capital, any
    local mine = WP.MyFaction()
    local want = mine == "Horde" and "H" or "A"
    for _, e in ipairs(list) do
        local id, rk = e[1], e[2]
        local n = ns.NPCs[id]
        if rk == rankKey and n and WP.Has(id) and (WP.IsFriendly(id) or n[3] == nil) then
            local d = WP.Distance(id, pc, px, py)
            if d and (not bestD or d < bestD) then best, bestD = id, d end
            if WP.CAPITALS[n[6]] == want and not capital then capital = id end
            any = any or id
        end
    end
    if best then return best, bestD, "near" end
    if capital then return capital, nil, "capital" end
    if any then return any, nil, "any" end
    return nil
end

-- one line for the next trainer: text, npc id (nil: no way to show), level hint
-- (c) a rank that cannot be learned yet (character level too low): only the hint, no way
-- (d) Retail (no trainer data): an honest sentence instead of an empty list
function WP.NextTrainerLine(prof, rank, maxRank)
    if ns.HasSourceData == false then return L.TRAINER_RETAIL, nil end
    local rk = WP.NextRank(rank, maxRank)
    if not rk or not rk.cap then return nil end
    local rankName = (L["RANK_" .. rk.key] or ""):gsub("%s*–.*$", "")
    local lvl = WP.PlayerLevel()
    if type(lvl) == "number" and rk.level and lvl < rk.level then
        return string.format(L.TRAINER_LEVEL, rankName, rk.level, lvl), nil
    end
    local id, yards, how = WP.NearestTrainer(prof, rk.key)
    if not id then return nil end
    local n = ns.NPCs[id]
    local where
    if yards then where = string.format(L.TRAINER_YARDS, math.floor(yards / 10 + 0.5) * 10, WP.ZoneName(n) or "?")
    else where = string.format(L.TRAINER_IN, WP.ZoneName(n) or "?") end
    return string.format(L.TRAINER_NEXT, rankName, n[1] or "?", where), id, how
end
