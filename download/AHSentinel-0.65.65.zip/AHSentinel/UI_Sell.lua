if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.9 - Tab "Verkaufen"
--   links:  verkaufbare Items aus deinen Taschen
--   rechts: aktuelle Angebote, Preisvorschlag (unterbieten), Menge,
--           Dauer, Gebühren, Warnung wenn ein Händler mehr zahlt
-- Einstellen nur per Klick auf "Einstellen".
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local function BuildSell(parent)
    local p = CreateFrame("Frame", nil, parent)
    local Se = A.Seller
    p.selected = nil
    p.duration = (A.db.seller.duration or 2)
    p.confirmLow = nil         -- zweiter Klick nötig, wenn der Händler mehr zahlt

    local function setMessage(ok, msg)
        if not msg then return end
        p.message:SetText(msg)
        p.message:SetTextColor(unpack(ok and C.textDim or C.red))
    end

    -- ================= Links: Taschen =================
    local head = UI:TabTitle(p, L["Verkaufen"], "sell")
    local sub = UI:Label(p, L["Item links wählen, Preis prüfen, 'Einstellen' klicken."], "GameFontDisableSmall", C.textDim)
    sub:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -4)

    p.bagTable = UI:Table(p, {
        columns = {
            { key = "name", title = L["Item"], width = 168 },
            { key = "count", title = L["Anzahl"], width = 52, align = "RIGHT" },
            { key = "market", title = L["Marktwert"], width = 100, align = "RIGHT" },
            { key = "lowest", title = L["Günstigstes"], width = 100, align = "RIGHT",
              tooltip = L["Günstigstes fremdes Angebot (nach 'Preis prüfen')"] },
        },
        rows = 16,
        rowHeight = 22,
        sortKey = "value",
        sortAsc = false,
        cell = function(e, key)
            if key == "name" then return UI.ItemName(e) end
            if key == "count" then return tostring(e.count) end
            return A:FormatMoney(e[key])
        end,
        sortValue = function(e, key)
            if key == "name" then return string.lower(UI.ItemName(e)) end
            return e[key]
        end,
        onClick = function(e) p:Select(e.itemID) end,
        -- Maus drüber: Angebote schon mal vorladen, damit sie beim Klick da sind
        onHover = function(e) Se:Prefetch(e.itemID) end,
        emptyText = L["Keine verkaufbaren Items in den Taschen."],
    })
    p.bagTable:Fill(0, -44, -486, 34)    -- linke Spalte, darunter "Serie"

    -- Serien-Einstellen
    p.batchBtn = UI:Button(p, "", 260, 24, function()
        if Se.batch then
            local ok, msg, soft = Se:BatchStep()
            setMessage(ok or soft, msg)
        else
            setMessage(Se:StartBatch())
        end
        p:Refresh()
    end, "primary")
    p.batchBtn:SetPoint("TOPLEFT", p.bagTable, "BOTTOMLEFT", 0, -6)
    p.batchBtn.tooltip = L["Stellt alle Taschen-Items ein, für die ein Preis gemerkt ist - ein Klick pro Auktion.\nPreis: Vorschlag (unterbieten). Übersprungen wird, wenn er unter 70 % deines letzten\nPreises fällt oder ein Händler mehr zahlt."]
    p.batchStop = UI:Button(p, "X", 24, 24, function()
        setMessage(true, Se:StopBatch(L["angehalten"]))
        p:Refresh()
    end, "danger")
    p.batchStop:SetPoint("LEFT", p.batchBtn, "RIGHT", 4, 0)
    p.batchStop.tooltip = L["Serie anhalten"]

    -- ================= Rechts: Einstellen =================
    local right = CreateFrame("Frame", nil, p)
    -- rechte Spalte (Formular) fest 470 breit am rechten Rand - die Taschen-Liste links nimmt den Rest
    right:SetPoint("TOPRIGHT", 0, 0)
    right:SetPoint("BOTTOMRIGHT", 0, 0)
    right:SetWidth(470)

    p.title = UI:Label(right, L["Kein Item gewählt"], "GameFontNormalLarge", C.accent)
    p.title:SetPoint("TOPLEFT", 0, 0)
    p.title:SetWidth(460)
    p.info = UI:Label(right, "", "GameFontHighlightSmall", C.textDim)
    p.info:SetPoint("TOPLEFT", 0, -24)
    p.info:SetWidth(460)

    p.checkBtn = UI:Button(right, L["Preis prüfen"], 120, 24, function()
        if not p.selected then return setMessage(false, L["Erst links ein Item aus deinen Taschen wählen."]) end
        if not A:IsAHOpen() then return setMessage(false, L["Bitte zuerst das Auktionshaus öffnen."]) end
        Se:CheckPrice(p.selected, true)
        setMessage(true, L["Angebote werden geladen ..."])
    end)
    p.checkBtn:SetPoint("TOPLEFT", 0, -46)
    p.checkBtn.tooltip = L["Lädt die aktuellen Angebote dieses Items aus dem Auktionshaus"]
    p.checkInfo = UI:Label(right, "", "GameFontHighlightSmall", C.textDim)
    p.checkInfo:SetPoint("LEFT", p.checkBtn, "RIGHT", 10, 0)
    p.checkInfo:SetWidth(330)

    p.listings = UI:Table(right, {
        columns = {
            { key = "price", title = L["Preis/Stück"], width = 120, align = "RIGHT" },
            { key = "qty", title = L["Menge"], width = 70, align = "RIGHT" },
            { key = "pct", title = L["% Markt"], width = 70, align = "RIGHT" },
            { key = "own", title = "", width = 90 },
        },
        rows = 5,
        rowHeight = 20,
        itemTooltip = false,
        noMenu = true,
        cell = function(l, key)
            if key == "price" then return A:FormatMoney(l.price) end
            if key == "qty" then return tostring(l.qty) end
            if key == "pct" then return A:FormatMarketPercent(p.selected and A:GetMarketPercent(p.selected, l.price)) end
            if key == "own" then
                if l.own then return "|cff00d1d1" .. L["eigenes"] .. "|r" end
                if l.bait then return "|cffff9933" .. L["Lockangebot"] .. "|r" end
                return ""
            end
        end,
        onClick = function(l)
            if l.bait then
                -- Lockangebote nicht unterbieten: Vorschlag ohne Köder
                p.price:SetCopper((Se:Suggest(p.selected)))
                p:UpdateSummary()
                return
            end
            p.price:SetCopper(l.own and l.price or Se:Undercut(l.price, p.selected))
            p:UpdateSummary()
        end,
        emptyText = L["Noch nicht geprüft."],
    })
    p.listings:SetPoint("TOPLEFT", p.checkBtn, "BOTTOMLEFT", 0, -8)

    -- Preis pro Stück
    local y0 = -218
    local priceLabel = UI:Label(right, L["Preis/Stück:"], "GameFontHighlightSmall", C.textDim)
    priceLabel:SetPoint("TOPLEFT", 0, y0 - 6)
    p.price = UI:MoneyInput(right, function() p.confirmLow = nil; p:UpdateSummary() end)
    p.price:SetPoint("TOPLEFT", 90, y0)
    p.suggestBtn = UI:Button(right, L["Vorschlag"], 74, 24, function() p:ApplySuggestion(true) end)
    p.suggestBtn:SetPoint("TOPLEFT", 262, y0)
    p.suggestBtn.tooltip = L["Günstigstes fremdes Angebot unterbieten.\nOhne Preisprüfung: Marktwert (Median 14 Tage)."]
    p.undercutBtn = UI:Button(right, "", 80, 24, function()
        Se:CycleUndercut()
        p:ApplySuggestion(true)
    end)
    p.undercutBtn:SetPoint("LEFT", p.suggestBtn, "RIGHT", 6, 0)
    p.undercutBtn.tooltip = L["Um wie viel das günstigste Angebot unterboten wird (Klick: wechseln)"]
    -- Mindestpreis: darunter wird nie unterboten
    p.floorBtn = UI:Button(right, L["Min"], 40, 24, function()
        local id = p.selected
        if not id then return end
        local cur, floor = p.price:GetCopper(), Se:GetFloor(id)
        if floor and (not cur or cur == floor) then
            Se:SetFloor(id, nil)
            setMessage(true, L["Mindestpreis gelöscht."])
        elseif cur and cur > 0 then
            Se:SetFloor(id, cur)
            setMessage(true, string.format(L["Mindestpreis: %s - darunter wird nie unterboten."], A:FormatMoney(cur)))
        end
        p:UpdateSummary()
    end)
    p.floorBtn:SetPoint("LEFT", p.undercutBtn, "RIGHT", 6, 0)

    -- Menge
    local qtyLabel = UI:Label(right, L["Menge:"], "GameFontHighlightSmall", C.textDim)
    qtyLabel:SetPoint("TOPLEFT", 0, y0 - 40)
    p.qty = UI:EditBox(right, 70, 24, "1")
    p.qty:SetPoint("TOPLEFT", 90, y0 - 34)
    p.qty:SetScript("OnTextChanged", function() p.confirmLow = nil; p:UpdateSummary() end)
    p.qty:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    p.allBtn = UI:Button(right, L["Alle"], 60, 24, function()
        if not p.selected then return end
        p.qty:SetText(tostring((Se:CountInBags(p.selected))))
        p:UpdateSummary()
    end)
    p.allBtn:SetPoint("LEFT", p.qty, "RIGHT", 6, 0)
    p.qtyHint = UI:Label(right, "", "GameFontDisableSmall", C.textDim)
    p.qtyHint:SetPoint("LEFT", p.allBtn, "RIGHT", 10, 0)
    p.qtyHint:SetWidth(220)

    -- Stapel (altes Auktionshaus): Stück je Stapel x Anzahl Stapel
    p.stackFrame = CreateFrame("Frame", nil, right)
    p.stackFrame:SetSize(122, 24)
    p.stackFrame:SetPoint("LEFT", p.allBtn, "RIGHT", 8, 0)
    p.stackBox = UI:EditBox(p.stackFrame, 44, 24, L["Stk."])
    p.stackBox:SetPoint("LEFT", 0, 0)
    local xl = UI:Label(p.stackFrame, "x", "GameFontHighlightSmall", C.textDim)
    xl:SetPoint("LEFT", p.stackBox, "RIGHT", 6, 0)
    p.stacksBox = UI:EditBox(p.stackFrame, 44, 24, L["Anz."])
    p.stacksBox:SetPoint("LEFT", xl, "RIGHT", 6, 0)
    p.stackBox.tooltipText = L["Stück je Stapel (leer = möglichst große Stapel)"]
    p.stacksBox.tooltipText = L["Anzahl Stapel (leer = so viele wie möglich)"]
    for _, e in ipairs({ p.stackBox, p.stacksBox }) do
        e:SetScript("OnEnter", function(self)
            UI:AnchorTooltip(self)
            GameTooltip:SetText(self.tooltipText, 1, 1, 1, 1, true)
            GameTooltip:Show()
        end)
        e:SetScript("OnLeave", function() GameTooltip:Hide() end)
        e:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
        e:SetScript("OnTextChanged", function()
            if p.fillingStacks then return end
            local s, n = tonumber(p.stackBox:GetText() or ""), tonumber(p.stacksBox:GetText() or "")
            if s and s >= 1 and p.selected then
                local have = Se:CountInBags(p.selected)
                n = n and math.max(1, math.floor(n)) or math.max(1, math.floor(have / s))
                p.qty:SetText(tostring(math.floor(s) * n))
            end
            p.confirmLow = nil
            p:UpdateSummary()
        end)
    end
    p.stackFrame:Hide()

    -- Dauer
    local durLabel = UI:Label(right, L["Dauer:"], "GameFontHighlightSmall", C.textDim)
    durLabel:SetPoint("TOPLEFT", 0, y0 - 74)
    p.durButtons = {}
    local prev
    for d = 1, 3 do
        local b = UI:Button(right, Se:DurationLabel(d), 104, 24, function()
            p.duration = d
            p.confirmLow = nil
            p:UpdateSummary()
        end)
        if prev then b:SetPoint("LEFT", prev, "RIGHT", 6, 0) else b:SetPoint("TOPLEFT", 90, y0 - 68) end
        b.duration = d
        p.durButtons[d] = b
        prev = b
    end
    -- Grund der Vorbelegung (Forever, E1), klein und grau unter den Knöpfen
    p.durWhy = UI:Label(right, "", "GameFontDisableSmall", C.textDim)
    p.durWhy:SetPoint("TOPLEFT", 90, y0 - 93)
    p.durWhy:SetWidth(330)
    if p.durWhy.SetWordWrap then p.durWhy:SetWordWrap(false) end

    -- Zusammenfassung
    local line = right:CreateTexture(nil, "ARTWORK")
    line:SetColorTexture(unpack(C.border))
    line:SetPoint("TOPLEFT", 0, y0 - 102)
    line:SetSize(460, 1)
    local function sumRow(labelText, y)
        local l = UI:Label(right, labelText, "GameFontHighlightSmall", C.textDim)
        l:SetPoint("TOPLEFT", 0, y)
        local v = UI:Label(right, "-", "GameFontHighlight", C.text)
        v:SetPoint("TOPLEFT", 200, y)
        v:SetWidth(200)
        v:SetJustifyH("RIGHT")
        return v, l
    end
    p.sDeposit, p.sDepositLabel = sumRow(L["Einstellgebühr"], y0 - 112)
    p.sGross = sumRow(L["Verkauf brutto"], y0 - 132)
    p.sCut, p.sCutLabel = sumRow(L["AH-Gebühr (5 %)"], y0 - 152)
    p.sNet = sumRow(L["Erlös nach Gebühren"], y0 - 172)
    p.warning = UI:Label(right, "", "GameFontHighlightSmall", C.red)
    p.warning:SetPoint("TOPLEFT", 0, y0 - 194)
    p.warning:SetWidth(460)

    p.postBtn = UI:Button(right, L["Einstellen"], 160, 28, function() p:Post() end, "primary")
    p.postBtn:SetPoint("TOPLEFT", 0, y0 - 218)
    p.postBtn.tooltip = L["Stellt das Item mit Preis, Menge und Dauer ins Auktionshaus.\nEinzelstücke (z.B. Ausrüstung): ein Klick = eine Auktion."]
    p.message = UI:Label(right, "", "GameFontHighlightSmall", C.textDim)
    p.message:SetPoint("LEFT", p.postBtn, "RIGHT", 10, 0)
    p.message:SetWidth(290)

    -- ------------------------------------------------------------
    function p:Select(itemID)
        self.selected = itemID
        self.confirmLow = nil
        self.bagTable.selectedID = itemID
        local last = A.db.seller.items[itemID]
        self.duration = (last and last.duration) or A.db.seller.duration or 2
        local count, entry = Se:CountInBags(itemID)
        -- Forever: Laufzeit vorbelegen (E1) - die eigene Wahl gilt danach für diese Einstellung
        self.durWhy:SetText("")
        local hours, why = A:DefaultDuration(itemID, (entry and entry.commodity) and count or 1)
        if hours then
            self.duration = (hours <= 2 and 1) or (hours <= 8 and 2) or 3
            self.durWhy:SetText(why or "")
        end
        if entry and entry.commodity then
            -- Entscheid des Nutzers 9. Nov. 11:49: immer alles aus den Taschen vorbelegen (nicht die letzte Menge)
            self.qty:SetText(tostring(count))
        else
            self.qty:SetText("1")
        end
        -- Stapel wie beim letzten Mal
        self.fillingStacks = true
        self.stackBox:SetText((last and last.stack) and tostring(last.stack) or "")
        self.stacksBox:SetText((last and last.stacks) and tostring(last.stacks) or "")
        self.fillingStacks = nil
        if last and last.stack and entry and entry.commodity and A.AH_LEGACY then
            local n = math.floor(count / last.stack)        -- so viele volle Stapel wie im Bestand
            if n >= 1 then self.qty:SetText(tostring(last.stack * n)) end
        end
        self:ApplySuggestion(false)
        if A.LogAbsatz then pcall(A.LogAbsatz, A, itemID) end
        if A:IsAHOpen() and not Se:IsPriceFresh(itemID) then Se:CheckPrice(itemID, true) end
        self:Refresh()
    end

    function p:ApplySuggestion(announce)
        if not self.selected then return end
        local price, why = Se:Suggest(self.selected)
        if price then self.price:SetCopper(price) else self.price:Clear() end
        self.suggestWhy = why
        if announce then setMessage(price ~= nil, why) end
        self:UpdateSummary()
    end

    function p:Values()
        local unit = self.price:GetCopper()
        -- Befund E4 (10.11.): leeres Mengenfeld zeigt die graue 1 (Platzhalter) - dann gilt sie auch
        local text = (self.qty:GetText() or ""):gsub("%s", "")
        local qty = (text == "") and 1 or math.floor(tonumber(text) or 0)
        return unit, qty
    end

    function p:UpdateSummary()
        for d, b in ipairs(self.durButtons) do
            b:SetText(d == self.duration and ("> " .. Se:DurationLabel(d) .. " <") or Se:DurationLabel(d))
        end
        self.undercutBtn:SetText(L["- "] .. Se:UndercutLabel(A.db.seller.undercut, self.selected))
        local id = self.selected
        self.warning:SetText("")
        if not id then
            for _, v in ipairs({ self.sDeposit, self.sGross, self.sCut, self.sNet }) do v:SetText("-") end
            self.postBtn:SetActive(false)
            return
        end
        local count, entry = Se:CountInBags(id)
        local commodity = entry and entry.commodity
        local stacks = commodity and A.AH_LEGACY
        self.stackFrame:SetShown(stacks and true or false)
        self.qtyHint:ClearAllPoints()
        if stacks then
            self.qtyHint:SetPoint("LEFT", self.stackFrame, "RIGHT", 6, 0)
            self.qtyHint:SetWidth(96)
        else
            self.qtyHint:SetPoint("LEFT", self.allBtn, "RIGHT", 10, 0)
            self.qtyHint:SetWidth(220)
        end
        self.qtyHint:SetText(commodity and string.format(L["von %d (Gesamtmenge)"], count)
            or string.format(L["Auktionen à 1 Stück (von %d)"], count))
        local floor = Se:GetFloor(id)
        self.floorBtn:SetText(floor and L["Min *"] or L["Min"])
        self.floorBtn.tooltip = (floor and string.format(L["Mindestpreis: %s"], A:FormatMoney(floor)) .. "\n" or "")
            .. L["Klick: aktuellen Preis als Mindestpreis merken - darunter wird nie unterboten.\nIst der Preis gleich dem Mindestpreis: Klick löscht ihn."]
        local unit, qty = self:Values()
        if not unit or qty < 1 or not entry then
            for _, v in ipairs({ self.sDeposit, self.sGross, self.sCut, self.sNet }) do v:SetText("-") end
            self.postBtn:SetActive(entry ~= nil)
            return
        end
        local postQty = commodity and qty or 1
        local stackSize = stacks and tonumber(self.stackBox:GetText() or "")
        if stackSize and stackSize >= 1 then
            stackSize = math.floor(stackSize)
            postQty = stackSize * math.floor(qty / stackSize)
            self.qtyHint:SetText(string.format(L["= %d Stück (von %d)"], postQty, count))
        end
        local auctions = (stackSize and stackSize >= 1) and math.max(1, math.floor(postQty / stackSize)) or 1
        local deposit, depUnsure = Se:Deposit(id, self.duration, postQty, commodity, entry.slots[1].loc, auctions)
        local gross, cut, net = Se:Proceeds(unit, postQty, id, auctions)
        -- klassisches AH: geschätzt aus dem Händlerpreis, bis das Addon die echte Gebühr einmal gesehen hat
        local est = A.AH_LEGACY and A.AH.DepositIsEstimate and A.AH.DepositIsEstimate(self.duration)
        -- Die Gebühr kommt beim Verkauf zurück und ist nur bei Rücklauf verloren:
        -- erwarteter Verlust = Gebühr x (1 - Verkaufsquote) / Verkaufsquote (ohne Daten: einmal Rücklauf)
        local rate = 0.5
        local chance = A.Comfort and A.Comfort.SellChance and A.Comfort:SellChance(id)
        if chance and chance.rate then rate = math.max(0.1, math.min(1, chance.rate / 100)) end
        local loss = deposit and math.floor(deposit * (1 - rate) / rate + 0.5) or 0
        -- Gebühren wie im klassischen WoW (auch Forever, Anweisung 14:30): Einzahlung beim Einstellen (kommt beim
        -- Verkauf zurück), 5 % beim Verkauf. Forever: Verkaufschance aus der eigenen Quote bzw. dem Markt.
        local forever = A:IsForever()
        if forever and deposit then
            local listings = A:ExpectedListings(id)
            rate = 1 / math.max(1, listings)
            loss = math.floor(deposit * (listings - 1) + 0.5)
        end
        self.sDeposit:SetShown(true); self.sDepositLabel:SetShown(true)
        self.sCutLabel:SetText(string.format(L["AH-Gebühr (%d %%)"], math.floor(A:CutPct() * 100 + 0.5)))
        local depText = deposit and ((est and (L["ca. "] .. A:FormatMoney(deposit))) or A:FormatMoney(deposit))
            or (A.AH_LEGACY and L["beim Einstellen"] or "?")
        if chance and deposit then
            depText = depText .. string.format(L[" (verkauft %d %%)"], math.floor(rate * 100 + 0.5))
        end
        if depUnsure and deposit then depText = depText .. L[" (unsicher)"] end   -- H3: neutrale Formel nicht gemessen
        self.sDeposit:SetText(depText)
        self.sGross:SetText(A:FormatMoney(gross))
        self.sCut:SetText(A:FormatMoney(cut))
        -- Spieltest S1 (nur wenn eingeschaltet): angezeigte Gebühr nachrechnen
        if A.Spieltest and A.Spieltest.activeUntil then
            A.Spieltest:OnSellSummary({ forever = forever, unit = unit, qty = postQty, auctions = auctions, cut = cut,
                depositShown = self.sDepositLabel:IsShown(), cutPct = A:CutPct() })
        end
        local final = net - loss
        self.sNet:SetText(final >= 0 and A:FormatMoney(final) or ("|cffff5544-" .. A:FormatMoney(-final) .. "|r"))
        local warn = {}
        if commodity and qty > count then table.insert(warn, string.format(L["Nur %d Stück in den Taschen."], count)) end
        local beats, vendorTotal = Se:VendorBeats(id, unit, postQty, deposit, auctions)
        -- nur warnen, wenn es um etwas geht: Händler zahlt mind. 1 Silber und 10 % mehr als das AH netto
        if beats and vendorTotal then
            local ahNet = net - loss
            if vendorTotal - ahNet < math.max(100, math.floor(math.abs(ahNet) * 0.1)) then beats = false end
        end
        if beats then
            table.insert(warn, string.format(L["Achtung: Ein Händler zahlt %s - mehr als das Auktionshaus netto!"], A:FormatMoney(vendorTotal)))
        end
        -- F4: verkauft sich kaum -> Hinweis (keine automatische Preisänderung)
        local sp = A:IsForever() and A.Ledger and A.Ledger.SellSpeed and A.Ledger:SellSpeed(id)
        if sp and sp.speed == "kaum" then
            table.insert(warn, "|cffffcc33" .. L["Läuft oft ab – billiger einstellen oder liegen lassen."] .. "|r")
        end
        -- H5: Markt unter dem automatischen Mindestpreis -> gelber Hinweis (Einstellen geht trotzdem)
        local okS, _, _, atFloor, fsrc = pcall(Se.Suggest, Se, id)
        if okS and atFloor and fsrc ~= "hand" then
            local auto = Se:AutoFloor(id)
            local line = string.format(L["Markt liegt unter deinem Mindestpreis (%s) – einstellen zum Mindestpreis oder warten"], A:FormatMoney(auto or 0))
            local okT, trend = pcall(A.GetTrend, A, id, 86400)
            if okT and trend and trend < -10 then line = line .. " · " .. L["Preis fällt"] end
            table.insert(warn, "|cffffcc33" .. line .. "|r")
        end
        -- H6: ab 3 Abläufen in Folge
        local okE, streak, lost = pcall(A.Ledger.ExpiryStreak, A.Ledger, id)
        if okE and streak and streak >= 3 then
            local cheaper = math.max(1, math.floor((unit or 0) * 0.9))
            local okR, raw = pcall(Se.SuggestRaw, Se, id)
            if okR and raw and raw < cheaper then cheaper = raw end
            local vendor = A:GetVendorPrice(id)
            local vtxt = (type(vendor) == "number" and vendor > 0) and A:FormatMoney(vendor) or "-"
            table.insert(warn, "|cffffcc33" .. string.format(L["%d× abgelaufen – billiger einstellen (Vorschlag: %s) oder an den Händler (%s). Bisher verloren: %s"],
                streak, A:FormatMoney(cheaper), vtxt, A:FormatMoney(lost or 0)) .. "|r")
        end
        local avgBuy = A.Ledger and A.Ledger:AverageBuyPrice(id, 30)
        if avgBuy and postQty > 0 and math.floor(net / postQty) < avgBuy then
            table.insert(warn, string.format(L["Unter deinem Einkaufspreis (Ø %s der letzten 30 Tage) - Verlust."], A:FormatMoney(avgBuy)))
        end
        -- Preisschutz: zu billig? -> Warnung und zweiter Klick nötig
        if floor and unit < floor then
            table.insert(warn, string.format(L["Unter deinem Mindestpreis (%s)."], A:FormatMoney(floor)))
        end
        local risks = Se:PriceRisks(id, unit)
        for _, r in ipairs(risks) do table.insert(warn, "|cffff9933" .. L["Preisschutz: "] .. r .. "|r") end
        local tooHigh = Se.PriceTooHigh and Se:PriceTooHigh(id, unit)
        if tooHigh then
            table.insert(warn, "|cffff9933" .. string.format(L["Preis %dx über dem Marktwert (%s) - Tippfehler? (Zahl ohne Zeichen = Gold)"],
                math.floor(tooHigh + 0.5), A:FormatMoney(A:GetMarketValue(id) or 0)) .. "|r")
        end
        -- Einstellgebühr über x % vom Preis (Einstellungen, Standard 10 %): gleiche Rückfrage wie oben
        local postFee = Se:PostFee(id, unit, postQty, deposit, auctions)
        local feeShare = Se.FeeTooHigh and Se:FeeTooHigh(postFee, unit, postQty)
        if feeShare then
            table.insert(warn, "|cffff9933" .. string.format(L["Einstellgebühr %s = %d %% vom Preis."],
                A:FormatMoney(postFee), math.floor(feeShare + 0.5))
                .. (A:DepositRefunded() and L[" (wird beim Verkauf erstattet)"] or "") .. "|r")
        end
        self.warning:SetText(table.concat(warn, "\n"))
        self.lowWarning = beats or #risks > 0 or (floor ~= nil and unit < floor) or (feeShare ~= nil) or (tooHigh ~= nil)
        self.postBtn:SetText((self.lowWarning and self.confirmLow) and L["Trotzdem einstellen"] or L["Einstellen"])
        self.postBtn:SetActive(true)
    end

    function p:Post()
        local unit, qty = self:Values()
        local id = self.selected
        -- F2: Einzelstücke in ganzen Silber - der gerundete Preis steht sichtbar im Feld
        local rounded = unit and Se:RoundPrice(id, unit)
        if rounded and rounded ~= unit then self.price:SetCopper(rounded); unit = rounded end
        -- Schutz: Händler zahlt mehr oder Preis viel zu niedrig -> erst nach zweitem Klick
        if self.lowWarning and not self.confirmLow then
            self.confirmLow = true
            self:UpdateSummary()
            return setMessage(false, L["Preis prüfen! Nochmal klicken, um trotzdem einzustellen."])
        end
        local stackSize = (A.AH_LEGACY and self.stackFrame:IsShown()) and tonumber(self.stackBox:GetText() or "") or nil
        -- Gebühr wurde oben schon gewarnt und bestätigt
        local ok, msg = Se:Post(id, unit, qty, self.duration, stackSize, true)
        self.confirmLow = nil
        setMessage(ok, msg)
        self:UpdateSummary()
    end

    function p:RefreshBatch()
        local cur, pos, total = Se:BatchCurrent()
        if Se.batch and cur then
            self.batchBtn:SetText(string.format(L["Einstellen: %s (%d/%d)"], cur.name, pos, total))
            self.batchBtn:SetActive(A:IsAHOpen())
            self.batchStop:Show()
        else
            if Se.batch then Se:StopBatch() end
            local n = #Se:BatchCandidates()
            self.batchBtn:SetText(string.format(L["Serie: alle mit Preis (%d)"], n))
            self.batchBtn:SetActive(n > 0 and A:IsAHOpen())
            self.batchStop:Hide()
        end
    end

    function p:Refresh()
        self:RefreshBatch()
        local items = Se:GetBagItems()
        self.bagTable.selectedID = self.selected
        self.bagTable:SetData(items, true)
        local id = self.selected
        if id and Se:CountInBags(id) == 0 then
            -- alles verkauft / nicht mehr in den Taschen
            self.title:SetText(A:GetItemName(id))
            self.info:SetText(L["|cffaaaaaaNicht mehr in deinen Taschen.|r"])
            self.listings:SetData({})
            self:UpdateSummary()
            return
        end
        if not id then
            self.title:SetText(L["Kein Item gewählt"])
            self.info:SetText(A:IsAHOpen() and L["Links ein Item anklicken."] or L["|cffff5544Auktionshaus öffnen, um Preise zu prüfen und einzustellen.|r"])
            self.checkInfo:SetText("")
            self.listings:SetData({})
            self:UpdateSummary()
            return
        end
        local count = Se:CountInBags(id)
        self.title:SetText(A:GetItemName(id))
        local mv, vendor = A:GetMarketValue(id), A:GetVendorPrice(id)
        local info = string.format(L["In Taschen: %d   |   Marktwert %s   |   Händler %s"], count,
            A:FormatMoney(mv), (vendor and vendor > 0) and A:FormatMoney(vendor) or "-")
        local avgBuy = A.Ledger and A.Ledger:AverageBuyPrice(id, 30)
        if avgBuy then info = info .. string.format(L["   |   gekauft Ø %s"], A:FormatMoney(avgBuy)) end
        self.info:SetText(info)
        local pr = Se:GetPriceInfo(id)
        local partial = Se:GetPartial(id)
        if Se.search and Se.search.itemID == id then
            if partial then
                self.checkInfo:SetText(string.format(L["|cffffcc33Lade Angebote ...|r %d"], #partial))
            else
                self.checkInfo:SetText(L["|cffffcc33Lade Angebote ...|r"])
            end
        elseif pr then
            local own = 0
            for _, l in ipairs(pr.listings) do if l.own then own = own + 1 end end
            self.checkInfo:SetText(string.format(L["geprüft %s: %d Angebote, %d eigene"], A:FormatAgo(pr.stamp), #pr.listings, own))
        else
            self.checkInfo:SetText(A:IsAHOpen() and "" or L["|cffff5544AH geschlossen|r"])
        end
        self.listings:SetData(A:NoBait(partial or (pr and pr.listings)))
        self:UpdateSummary()
    end

    -- Vorschlag übernehmen, sobald die Preisprüfung für das gewählte Item fertig ist
    local lastStamp
    A:On("SELLER_CHANGED", function()
        local id = p.selected
        local pr = id and Se:GetPriceInfo(id)
        if pr and pr.stamp ~= lastStamp and pr.time and (GetTime() - pr.time) < 2 then
            lastStamp = pr.stamp
            p:ApplySuggestion(false)
        end
    end)

    -- Rückmeldung, sobald der Server (oder der Testmodus) das Einstellen bestätigt -
    -- sonst bliebe "Wird eingestellt ..." stehen
    A:On("AUCTION_POSTED", function(pp)
        if pp and pp.itemID and p.message then
            setMessage(true, string.format(L["|cff33dd55Eingestellt:|r %dx %s für %s/Stück"], pp.qty or 1,
                A:GetItemName(pp.itemID), A:FormatMoney(pp.unitPrice or 0)))
        end
    end)

    p:UpdateSummary()
    return p
end

UI:RegisterTab("sell", "Verkaufen", 3.6, BuildSell)

A:On("SELLER_CHANGED", function()
    local tab = UI:GetTab(UI.activeTab or "")
    if tab and (tab.id == "sell" or tab.id == "auctions") then UI:RefreshActive() end
end)
