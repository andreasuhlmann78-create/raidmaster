if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Prognose-Journal (Stufe 1, Anweisung der Prüf-Sitzung 10.11. 09:45, Ziel des Nutzers:
-- "jede Vorhersage wird nachgeprüft, die Trefferquote gemessen und im Testbericht gezeigt")
--
-- P1 Bei jeder Entscheidung (Einstellen, Kaufen, Entzaubern) ein kompakter Eintrag ohne Namen: was AHSentinel in
--    diesem Moment vorhergesagt hat (HEUTIGE Logik: SellOutlook, BestWay, DealValue - keine neue Rechnung).
-- P2 Ergebnis zuordnen: Verkaufsrechnung (FIFO, Teilverkäufe anteilig), abgelaufen (zensiert, y = 0, nicht
--    weggelassen), abgebrochen (zensiert "abgebrochen"), nach 7 Tagen ohne Briefkasten "unbekannt".
-- P3 Güte: Zuverlässigkeits-Tabelle, Brier-Score, Dauer, Erlös, Kauf-Trefferquote, Entzaubern.
-- P4 db.forecastStats: Zusammenfassung der aus dem Ringpuffer gefallenen Fälle (bleibt dauerhaft, klein).
-- P5 Messaufträge M1 (nur Existenz), M2 (Felder der Item-Suche), M3 (Mindestpreis/Menge je Stunde des Tages).
--
-- SCHUTZ: nur NEUE Tabellen (db.forecast, db.forecastStats, db.forecastHours). Buchhaltung, Entzauber-Daten und
-- Preisverlauf werden nur gelesen. Während Testmodus/Testroutine schreibt das Journal nur in eine Ersatztabelle
-- (Fc.testStore) - sonst gar nicht.
--
-- Format (Speicher-Ziel < 300 KB): ein Eintrag = eine Zeichenkette "Art;Feld;Feld;...", Zeit in Minuten seit BASE.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local A = AHAnalyzerPro
local L = A.L

local Fc = {}
A.Forecast = Fc

Fc.MAX = 3000                 -- Ringpuffer
Fc.KEEP_DAYS = 60             -- älter -> nur noch in die Zusammenfassung
Fc.UNKNOWN_DAYS = 7           -- so lange nach Ende ohne Briefkasten -> "unbekannt"
Fc.MAIL_GRACE = 3600          -- Verkaufspost kommt in Forever 1 Std. nach dem Verkauf
Fc.MIN_TOOLTIP = 20           -- P7: ab so vielen eigenen Fällen der Warengruppe
Fc.MIN_GROUP = 10             -- Brier je Warengruppe ab so vielen Fällen
Fc.MIN_REPORT = 10            -- darunter "zu wenig Daten (N)"
Fc.HOUR_ITEMS = 300           -- M3: höchstens so viele Items
Fc.BUY_MATCH_DAYS = 30        -- Kauf -> Verkauf/Entzaubern höchstens so lange danach
local BASE = 1760000000      -- Minuten seit Oktober 2025 (kürzer im Speicher)

-- Felder je Art (Reihenfolge = Speicherformat; nie umstellen, nur hinten anfügen)
--  P Einstellen: t id q(Menge) a(Auktionen) pr(Stückpreis) rel(Preis/Marktwert) d(Laufzeit Std.) Q qs(Quelle Q) S(Absatz/Tag)
--    ss(Quelle S) u(unsicher 1/0) p(Verkaufschance in der Laufzeit) W(Std. bis Verkauf) N(Einstellungen) net(Netto je Stück)
--    v(Version) g(Warengruppe) | Ergebnis: r(s/t/e/c/u) sq(verkaufte Menge) sh(Std. bis zum ersten Verkauf) sp(Ø Stückpreis)
--    x(1 = über Blizzards Fenster) ex(1 = Lern-Test +5 %, Stufe 2 L11)
--  B Kaufen: t id q pr way(e/d/v) ev(erwarteter Netto-Wert je Stück) src(sniper/watcher/buy/mail) v g | r(c = abgeschlossen)
--    rq(zugeordnete Menge) rv(realisierter Netto-Erlös gesamt) rk(letzter Weg s/d) mv(Marktwert beim Kauf, Stufe 2 L8)
--  D Entzaubern: t id ev(Netto vorhergesagt) g dk(Gruppe der Entzauber-Tabelle) src(a = echt / e = Tabelle) n lv(Beute-Wert)
--    c(Preise vollständig 1/0) bp(Kaufpreis, wenn ein Kauf zugeordnet ist)
Fc.FIELDS = {
    P = { "t", "id", "q", "a", "pr", "rel", "d", "Q", "qs", "S", "ss", "u", "p", "W", "N", "net", "v", "g", "r", "sq", "sh", "sp", "x", "ex", "rs", "cr" },   -- rs (X7): Herkunft des Verkaufs; cr (PR1): Abbruch-Grund u/a
    B = { "t", "id", "q", "pr", "way", "ev", "src", "v", "g", "r", "rq", "rv", "rk", "mv", "aid" },   -- aid (PD2): auctionID
    D = { "t", "id", "ev", "g", "dk", "src", "n", "lv", "c", "bp" },
}
local TEXT = { qs = true, ss = true, v = true, g = true, r = true, way = true, src = true, dk = true, rk = true, rs = true, cr = true }

-- Warengruppen (P3, aus classID/subClassID, keine Namen)
Fc.GROUPS = { "de", "cloth", "leather", "metal", "herb", "consum", "gear2", "gear3", "misc" }
Fc.GROUP_NAMES = { de = "Staub/Essenz/Splitter", cloth = "Stoff", leather = "Leder", metal = "Erz/Barren/Stein", herb = "Kräuter",
    consum = "Tränke/Verbrauch", gear2 = "Ausrüstung grün", gear3 = "Ausrüstung blau+", misc = "Sonstiges" }

-- ------------------------------------------------------------
-- Speicher
-- ------------------------------------------------------------
local function NewJournal() return { v = 1, list = {}, vers = {}, mail = 0, m2 = {} } end
local function NewStats() return { v = 1, P = {}, B = {}, Bs = {}, D = {}, dropped = 0 } end

-- Schreibziel: Ersatztabelle (Tests) oder die echten Tabellen; im Testmodus/in der Testroutine ohne Ersatz: nichts
function Fc:Store()
    local ts = self.testStore
    if ts then
        ts.f = ts.f or NewJournal(); ts.st = ts.st or NewStats(); ts.hours = ts.hours or {}
        return ts.f, ts.st, ts.hours
    end
    if not A.db or A:Simulated() then return nil end
    return self:Real()
end

function Fc:Real()
    local db = A.db
    if not db then return nil end
    if type(db.forecast) ~= "table" or type(db.forecast.list) ~= "table" then db.forecast = NewJournal() end
    if type(db.forecastStats) ~= "table" then db.forecastStats = NewStats() end
    if type(db.forecastHours) ~= "table" then db.forecastHours = {} end
    return db.forecast, db.forecastStats, db.forecastHours
end

-- nur lesen (Bericht, Tooltip): Ersatz in Tests, sonst die echten Tabellen (ohne sie anzulegen)
function Fc:Data()
    local ts = self.testStore
    if ts then return self:Store() end
    local db = A.db
    if not db then return nil end
    return db.forecast, db.forecastStats, db.forecastHours
end

-- PD2 (Befund PC-Daten 0.65.94): derselbe Kauf stand bis 23-mal im Journal. Ein Fall je Kauf: Schlüssel je Art.
-- Doppel werden NICHT gelöscht (Journal bleibt erhalten), sondern einmal in f.dups verschoben - die Auswertung zählt
-- sie nicht mehr. Neue Doppel nimmt Fc:Add gar nicht erst auf.
local function CaseKey(s)
    if type(s) ~= "string" or s:sub(1, 1) ~= "B" then return nil end      -- nur Käufe (P/D wiederholen sich echt)
    local e = Fc:Decode(s)
    if not e then return nil end
    if e.aid then return "A:" .. tostring(e.aid) end                          -- neu: je Auktion genau ein Fall
    return table.concat({ "B", tostring(e.t), tostring(e.id), tostring(e.q), tostring(e.pr) }, ":"), e
end
Fc.CaseKey = CaseKey
-- wie viele echte Käufe gibt es für diesen Schlüssel (Buchhaltung)? nil = unbekannt (dann nichts beiseitelegen)
function Fc:LedgerBuys(e)
    if self.ledgerBuysTest then return self.ledgerBuysTest(e) end
    local led = A.db and A.db.ledger
    if not (led and led.entries and e and e.t) then return nil end
    local n, minute = 0, math.floor(e.t / 60)
    for _, x in ipairs(led.entries) do
        if x.kind == "buy" and x.itemID == e.id and (x.qty or 1) == (e.q or 1) and math.abs(math.floor((x.t or 0) / 60) - minute) <= 1
            and math.floor((x.amount or 0) / math.max(1, x.qty or 1) + 0.5) == e.pr then n = n + 1 end
    end
    return n > 0 and n or nil
end
function Fc:Dedupe(f)
    if not (f and f.list) then return 0 end
    local groups, order = {}, {}
    for i, s in ipairs(f.list) do
        local k, e = CaseKey(s)
        if k then
            if not groups[k] then groups[k] = { e = e, idx = {} }; order[#order + 1] = k end
            table.insert(groups[k].idx, i)
        end
    end
    local drop = {}
    for _, k in ipairs(order) do
        local g = groups[k]
        if #g.idx > 1 then
            local allowed = (k:sub(1, 2) == "A:") and 1 or self:LedgerBuys(g.e)
            if allowed and #g.idx > allowed then
                -- die vollständigsten (längsten, mit Ergebnis) behalten
                table.sort(g.idx, function(x, y) return #f.list[x] > #f.list[y] end)
                for j = allowed + 1, #g.idx do drop[g.idx[j]] = true end
            end
        end
    end
    local keep, moved = {}, 0
    f.dups = f.dups or {}
    for i, s in ipairs(f.list) do
        if drop[i] then f.dups[#f.dups + 1] = s; moved = moved + 1 else keep[#keep + 1] = s end
    end
    while #f.dups > 2000 do table.remove(f.dups, 1) end
    f.list = keep
    f.dupMoved = (f.dupMoved or 0) + moved
    self.evalCache = nil
    return moved
end
-- Doppel = Käufe derselben Auktion mehrfach bzw. mehr gleiche Fälle als Käufe in der Buchhaltung
function Fc:Doubles(f)
    f = f or self:Data()
    local groups = {}
    for _, s in ipairs(f and f.list or {}) do
        local k, e = CaseKey(s)
        if k then local g = groups[k] or { n = 0, e = e }; g.n = g.n + 1; groups[k] = g end
    end
    local n = 0
    for k, g in pairs(groups) do
        if g.n > 1 then
            local allowed = (k:sub(1, 2) == "A:") and 1 or self:LedgerBuys(g.e)
            if allowed and g.n > allowed then n = n + g.n - allowed end
        end
    end
    return n
end

-- legt die Tabellen beim Laden an (vor jeder Testroutine - sonst meldet die Sandbox einen neuen Pfad)
A:On("READY", function()
    pcall(Fc.Real, Fc)
    local f = A.db and A.db.forecast
    if f and not f.dedupPD2 then
        local ok, n = pcall(Fc.Dedupe, Fc, f)
        f.dedupPD2 = true
        if ok and n > 0 and A.Diag then pcall(A.Diag.Add, A.Diag, "PROGNOSE", string.format("PD2 %d doppelte Fälle beiseitegelegt (f.dups, nicht gelöscht)", n)) end
    end
end)

-- ------------------------------------------------------------
-- Kodieren / Lesen
-- ------------------------------------------------------------
-- Nachkommastellen je Feld (Speicher): Absatz, Stunden 1, Preis/Markt 2, Chance 3
local PREC = { S = 1, W = 1, sh = 1, rel = 2, p = 3 }
-- Standardwerte werden nicht gespeichert (leer = Standard beim Lesen)
local DEFAULT = { a = 1, u = 0 }
local function Num(x, prec)
    if type(x) ~= "number" then return "" end
    if x ~= x or x == math.huge or x == -math.huge then return "" end
    if x == math.floor(x) then return string.format("%d", x) end
    local s = string.format("%." .. (prec or 3) .. "f", x):gsub("0+$", ""):gsub("%.$", "")
    return s
end

function Fc:Encode(kind, e)
    local out = { kind }
    for i, k in ipairs(self.FIELDS[kind]) do
        local v = e[k]
        if k == "t" and type(v) == "number" then v = math.floor((v - BASE) / 60 + 0.5) end
        if DEFAULT[k] ~= nil and v == DEFAULT[k] then v = nil end
        if TEXT[k] then out[i + 1] = v ~= nil and tostring(v):gsub(";", ""):sub(1, 12) or ""
        elseif type(v) == "boolean" then out[i + 1] = v and "1" or "0"
        else out[i + 1] = Num(v, PREC[k]) end
    end
    -- leere Felder am Ende weglassen
    local n = #out
    while n > 2 and out[n] == "" do out[n] = nil; n = n - 1 end
    return table.concat(out, ";")
end

function Fc:Decode(s)
    if type(s) ~= "string" then return nil end
    local kind = s:sub(1, 1)
    local fields = self.FIELDS[kind]
    if not fields or s:sub(2, 2) ~= ";" then return nil end
    local e = { kind = kind }
    local pos, i = 3, 1
    local len = #s
    while i <= #fields do
        local stop = s:find(";", pos, true)
        local part = s:sub(pos, (stop or (len + 1)) - 1)
        local k = fields[i]
        if part ~= "" then
            if TEXT[k] then e[k] = part else e[k] = tonumber(part) end
        end
        i = i + 1
        if not stop then break end
        pos = stop + 1
    end
    if e.t then e.t = BASE + e.t * 60 end
    for k, d in pairs(DEFAULT) do if e[k] == nil and kind == "P" then e[k] = d end end
    return e
end

-- Item-ID eines Eintrags ohne ganzes Lesen ("P;t;id;...")
local function IdOf(s)
    return tonumber(s:match("^%a;[^;]*;(%d+)"))
end

local function VersionIndex(f)
    local v = tostring(A.version or "?")
    for i, x in ipairs(f.vers) do if x == v then return tostring(i) end end
    f.vers[#f.vers + 1] = v
    return tostring(#f.vers)
end

-- ------------------------------------------------------------
-- Warengruppe
-- ------------------------------------------------------------
function Fc:Group(itemID)
    if not itemID then return "misc" end
    local D = A.Disenchant
    if D and D.MATERIALS and D.MATERIALS[itemID] then return "de" end
    if not GetItemInfo then return "misc" end
    local info = { pcall(GetItemInfo, itemID) }
    if not info[1] then return "misc" end
    local quality, classID, sub = info[4], info[13], info[14]
    if classID == 2 or classID == 4 then
        if (quality or 0) >= 3 then return "gear3" end
        return "gear2"
    end
    if classID == 0 then return "consum" end
    if classID == 7 then
        if sub == 12 then return "de" end
        if sub == 5 then return "cloth" end
        if sub == 6 then return "leather" end
        if sub == 7 then return "metal" end
        if sub == 9 then return "herb" end
    end
    return "misc"
end

-- ------------------------------------------------------------
-- Einträge schreiben, Ringpuffer
-- ------------------------------------------------------------
function Fc:Add(kind, e)
    local f, st = self:Store()
    if not f then return nil end
    e.v = VersionIndex(f)
    e.t = e.t or time()
    e.g = e.g or self:Group(e.id)
    local s = self:Encode(kind, e)
    -- PD2: derselbe Kauf (gleiche Auktion) schon da (letzte 300)? Dann nicht nochmals
    if kind == "B" and e.aid then
        local k = "A:" .. tostring(e.aid)
        for i = #f.list, math.max(1, #f.list - 300), -1 do
            if CaseKey(f.list[i]) == k then return nil end
        end
    end
    f.list[#f.list + 1] = s
    self:Prune(f, st)
    self.evalCache = nil
    return s
end

-- älter als KEEP_DAYS oder über MAX: in die Zusammenfassung (P4), dann weg
function Fc:Prune(f, st, now)
    now = now or time()
    local cutoff = now - self.KEEP_DAYS * 86400
    local list = f.list
    local drop = 0
    while drop < #list do
        local s = list[drop + 1]
        local e = self:Decode(s)
        local old = (not e) or (e.t or 0) < cutoff
        if not old and (#list - drop) <= self.MAX then break end
        if e then self:Archive(st, e, now) end
        drop = drop + 1
    end
    if drop > 0 then
        local keep = {}
        for i = drop + 1, #list do keep[#keep + 1] = list[i] end
        f.list = keep
    end
    return drop
end

-- aktualisiert den Eintrag i (gelesen e) im Speicher
local function Put(f, i, e)
    f.list[i] = Fc:Encode(e.kind, e)
end

-- ------------------------------------------------------------
-- P1a Einstellen
-- ------------------------------------------------------------
-- p (Verkaufschance in der Laufzeit) genau so, wie AHSentinel heute rechnet: eigene Quote -> 1/N; sonst
-- min(1, Laufzeit / W); ohne W -> 1/N
function Fc:PostPrediction(itemID, qty, price, hours, auctions)
    local r = {}
    local ok, v = pcall(A.SellOutlook, A, itemID, qty, price)
    if not (ok and v) then return r end
    -- Quellen als Kürzel: Q r = Suche, s = Scan; S o = eigene Quote, m = Markt, c = Markt mit Deckel, om = eigene > Markt
    r.Q, r.qs = v.queue, ({ search = "r", scan = "s" })[v.queueSource or ""]
    r.S = v.perDay
    r.ss = v.listingsSource == "own" and "o" or ({ ["market, Deckel"] = "c", ["own>market"] = "om", market = "m", own = "o", measured = "g", ["market, gelernt"] = "lf" })[v.perDaySource or ""]
    r.u = v.unsure and 1 or 0
    r.N = v.listings or 1
    r.W = v.wait and v.wait * 24 or nil
    hours = hours or 24
    if v.listingsSource == "own" then r.p = 1 / math.max(1, r.N)
    elseif v.wait and v.wait > 0 then r.p = math.min(1, (hours / 24) / v.wait)
    elseif v.wait then r.p = 1
    else r.p = 1 / math.max(1, r.N) end
    -- PR1 (2): Verkaufschance je PREISSTUFE (Preis/Marktwert) aus den echten Verkäufen gelernt (Ln:Chance: Item ->
    -- Warengruppe -> geteilt), sobald gelernt (nicht nur Startwert). Der Preis entscheidet (Messung 14.11.: ≤ 1,00 59 %,
    -- > 1,50 15 %); die alte Rechnung aus der Wartezeit kannte den Preis kaum.
    local Ln = A.Learn
    if Ln and Ln.Chance and price and price > 0 then
        local okM, mv = pcall(A.GetMarketValue, A, itemID)
        if okM and mv and mv > 0 then
            local okC, pl, info = pcall(Ln.Chance, Ln, itemID, price / mv, hours, nil)
            if okC and pl and info and info.src ~= "start" then r.pw, r.p = r.p, pl end
        end
    end
    r.p = math.floor(r.p * 1000 + 0.5) / 1000
    local okN, net = pcall(A.NetSale, A, itemID, price, qty, auctions)
    if okN and net then
        local loss = 0
        if A:IsForever() and (r.N or 1) > 1 and A.ExpectedDepositLoss then
            local okL, l = pcall(A.ExpectedDepositLoss, A, itemID, qty, r.N)
            if okL and type(l) == "number" then loss = l end
        end
        r.net = math.floor((net - loss) / math.max(1, qty) + 0.5)
    end
    return r
end

function Fc:OnPosted(p)
    if not (p and p.itemID and p.unitPrice) then return end
    if A.SilverTest and A.SilverTest.run then return end         -- Messreihe (Test-Einstellungen) ist keine Entscheidung
    if not self:Store() then return end
    local qty = math.max(1, math.floor(p.qty or 1))
    local hours = p.hours or (p.duration and A.DURATION_HOURS[p.duration]) or 24
    local e = { t = p.t or time(), id = p.itemID, q = qty, a = p.auctions or 1, pr = math.floor(p.unitPrice + 0.5), d = hours,
        x = p.external and 1 or nil }
    -- Stufe 2 L11: Lern-Test (+5 %) markieren
    local Ln = A.Learn
    if Ln and Ln.TakeExplore then
        local okX, isX = pcall(Ln.TakeExplore, Ln, p.itemID, e.pr)
        if okX and isX then e.ex = 1 end
    end
    local mv = A.GetMarketValue and A:GetMarketValue(p.itemID)
    if mv and mv > 0 then e.rel = math.floor(e.pr / mv * 1000 + 0.5) / 1000 end
    local r = self:PostPrediction(p.itemID, qty, e.pr, hours, e.a)
    for k, v in pairs(r) do e[k] = v end
    return self:Add("P", e)
end

-- ------------------------------------------------------------
-- P1b Kaufen
-- ------------------------------------------------------------
function Fc:BuyPrediction(itemID)
    local sale, isVendor
    local ok, v, _, _, vend = pcall(A.RealValue, A, itemID, 1)
    if ok then sale, isVendor = v, vend end
    -- H5 (Befund 10.11.): Wiederverkauf mit dem realistischen Verkaufspreis (A:ResalePrice: Angebotsliste + Absatz,
    -- nach AH-Anteil), nicht mit dem Marktwert
    if sale and not isVendor and A.ResalePrice then
        local okR, rp = pcall(A.ResalePrice, A, itemID)
        if okR and type(rp) == "number" then
            local net = math.floor(rp * (1 - A:CutPct()) + 0.5)
            if net < sale then sale = net end
        end
    end
    local de
    local D = A.Disenchant
    if D and D.Prior and D:Prior(itemID) then
        local okD, _, net = pcall(D.DealValue, D, itemID)
        if okD then de = net end
    end
    if de and (not sale or de > sale) then return "d", math.floor(de + 0.5) end
    if sale then return isVendor and "v" or "e", math.floor(sale + 0.5) end
    return nil, nil
end

function Fc:OnBuy(itemID, qty, cost, src, t, aid)
    if not (itemID and cost) then return end
    if not self:Store() then return end
    qty = math.max(1, math.floor(qty or 1))
    local way, ev = self:BuyPrediction(itemID)
    local mv = A.GetMarketValue and A:GetMarketValue(itemID)
    return self:Add("B", { t = t or time(), id = itemID, q = qty, pr = math.floor(cost / qty + 0.5), way = way or "e", ev = ev, src = src or "buy",
        mv = mv and math.floor(mv + 0.5) or nil, aid = aid })
end

-- ------------------------------------------------------------
-- P1c Entzaubern (Vorhersage und Ergebnis zugleich; ev VOR dem Lernen dieses Ergebnisses)
-- ------------------------------------------------------------
function Fc:DEPrediction(itemID)
    local D = A.Disenchant
    if not (D and D.Prior) then return nil end
    local _, key = D:Prior(itemID)
    if not key then return nil end
    local ok, _, net, _, basis, n = pcall(D.DealValue, D, itemID, true)     -- unkorrigiert (S1 misst sonst sich selbst)
    if not ok or not net then return { dk = key } end
    return { ev = math.floor(net + 0.5), dk = key, src = basis == "actual" and "a" or "e", n = n or 0 }
end

function Fc:OnDisenchant(itemID, loot, pred)
    local f = self:Store()
    if not (f and itemID) then return end
    local e = { t = time(), id = itemID }
    for k, v in pairs(pred or {}) do e[k] = v end
    local Le = A.Ledger
    if Le and Le.DisenchantLootValue then
        local ok, v, complete = pcall(Le.DisenchantLootValue, Le, loot)
        if ok then e.lv, e.c = v, complete and 1 or 0 end
    end
    -- Kauf zuordnen (ältester offener Kauf dieses Items)
    local bp = self:AssignBuy(f, itemID, 1, e.lv or 0, "d", e.t)
    e.bp = bp
    return self:Add("D", e)
end

-- ------------------------------------------------------------
-- P2 Ergebnisse zuordnen
-- ------------------------------------------------------------
-- Kauf: qty Stück mit Erlös value (gesamt) dem ältesten offenen Kauf (FIFO) zuordnen; Rückgabe Kaufpreis je Stück
function Fc:AssignBuy(f, itemID, qty, value, how, at)
    local list = f.list
    local left = qty
    local bp
    local from = (at or time()) - self.BUY_MATCH_DAYS * 86400
    for i = 1, #list do
        if left <= 0 then break end
        local s = list[i]
        if s:sub(1, 1) == "B" and IdOf(s) == itemID then
            local e = self:Decode(s)
            if e and e.r ~= "c" and (e.t or 0) <= (at or time()) and (e.t or 0) >= from then
                local open = (e.q or 1) - (e.rq or 0)
                local take = math.min(open, left)
                if take > 0 then
                    e.rq = (e.rq or 0) + take
                    e.rv = (e.rv or 0) + math.floor(value * take / qty + 0.5)
                    e.rk = how
                    if e.rq >= (e.q or 1) then e.r = "c" end
                    Put(f, i, e)
                    left = left - take
                    bp = bp or e.pr
                end
            end
        end
    end
    return bp
end

-- Verkauf (Buchhaltung): Menge FIFO auf die Einstellungen, deren Laufzeit den Verkaufszeitpunkt enthält
-- X7 (Befund 0.65.86): Die Verkaufszeit aus der Rechnung ist "Ankunft der Post - 1 Std.". Kommt die Post in Forever
-- schneller, liegt diese Zeit VOR der Einstellung - der Verkauf wurde dann keinem Fall zugeordnet und der Fall galt beim
-- Briefkasten als "nicht verkauft". Deshalb für Rechnungen 1 Std. Spielraum vor der Einstellung.
Fc.MAIL_SLACK = 3600
function Fc:OnSale(itemID, qty, gross, cut, saleTime, fromMail)
    local f = self:Store()
    if not (f and itemID) then return end
    qty = math.max(1, math.floor(qty or 1))
    local unit = (gross or 0) / qty
    local list = f.list
    local left = qty
    for i = 1, #list do
        if left <= 0 then break end
        local s = list[i]
        if s:sub(1, 1) == "P" and IdOf(s) == itemID then
            local e = self:Decode(s)
            if e and e.r ~= "s" and e.r ~= "c" then
                local t0 = e.t or 0
                local slack = fromMail and self.MAIL_SLACK or 0
                local t1 = t0 + (e.d or 24) * 3600 + 300 + slack
                if saleTime >= t0 - 120 - slack and saleTime <= t1 then
                    local open = (e.q or 1) - (e.sq or 0)
                    local take = math.min(open, left)
                    if take > 0 then
                        local before = e.sq or 0
                        e.sp = math.floor(((e.sp or 0) * before + unit * take) / (before + take) + 0.5)
                        e.sq = before + take
                        if not e.sh then e.sh = math.floor(math.max(0, saleTime - t0) / 360 + 0.5) / 10 end
                        e.rs = fromMail and "inv" or "msg"          -- X7: Herkunft des Ergebnisses (Rechnung / Meldung)
                        if e.sq >= (e.q or 1) then e.r = "s"
                        elseif e.r == "e" or e.r == "u" then e.r = "t" end
                        Put(f, i, e)
                        left = left - take
                    end
                end
            end
        end
    end
    -- Käufe dieses Items: Netto-Erlös des Verkaufs
    self:AssignBuy(f, itemID, qty, (gross or 0) - (cut or 0), "s", saleTime)
    self.evalCache = nil
end

-- Abbrechen: die jüngste laufende Einstellung dieses Items -> zensiert "abgebrochen"
function Fc:OnCancel(itemID, now)
    local f = self:Store()
    if not (f and itemID) then return end
    now = now or time()
    for i = #f.list, 1, -1 do
        local s = f.list[i]
        if s:sub(1, 1) == "P" and IdOf(s) == itemID then
            local e = self:Decode(s)
            if e and (e.r == nil or e.r == "") and now <= (e.t or 0) + (e.d or 24) * 3600 then
                e.r = "c"
                -- PR1 (Nutzer 00:53): Abbruch meist "unterboten" - im Moment des Abbruchs festhalten: günstigeres fremdes
                -- Angebot im letzten Scan (aktueller Preis unter dem eigenen Stückpreis) -> "u", sonst "a" (anderer Grund)
                local okC, cur = pcall(A.GetCurrent, A, itemID)
                e.cr = (okC and cur and e.pr and cur < e.pr) and "u" or "a"
                Put(f, i, e)
                self.evalCache = nil
                return true
            end
        end
    end
end

-- Briefkasten gelesen: Einstellungen, deren Verkaufspost schon da sein müsste, abschliessen
function Fc:NoteMail(now)
    local f = self:Store()
    if not f then return end
    now = now or time()
    f.mail = now
    self:Close(now)
end

-- abgelaufene Einstellungen abschliessen: Briefkasten nach dem Ende gelesen -> "e"/"t"; sonst nach 7 Tagen "u"
function Fc:Close(now)
    local f = self:Store()
    if not f then return 0 end
    now = now or time()
    local n = 0
    for i, s in ipairs(f.list) do
        if s:sub(1, 1) == "P" then
            local e = self:Decode(s)
            if e and (e.r == nil or e.r == "") then
                local stop = (e.t or 0) + (e.d or 24) * 3600
                if (e.sq or 0) >= (e.q or 1) then e.r = "s"
                elseif (f.mail or 0) >= stop + self.MAIL_GRACE and now >= stop + self.MAIL_GRACE then e.r = (e.sq or 0) > 0 and "t" or "e"
                elseif now >= stop + self.UNKNOWN_DAYS * 86400 then e.r = "u" end
                if e.r then Put(f, i, e); n = n + 1 end
            end
        end
    end
    if n > 0 then self.evalCache = nil end
    return n
end

-- ------------------------------------------------------------
-- Auswertung (P3) - Zähler, die auch die Zusammenfassung (P4) benutzt
-- ------------------------------------------------------------
local DUR_B = { 0.25, 0.5, 0.75, 0.9, 1.1, 1.5, 2, 3, 5 }     -- Grenzen der Verhältnis-Histogramme (letzte Klasse: darüber)
local REV_B = { 0.8, 0.9, 0.97, 1.03, 1.1, 1.25 }
local function Bucket(bounds, x)
    for i, b in ipairs(bounds) do if x <= b then return i end end
    return #bounds + 1
end
Fc.DUR_B, Fc.REV_B = DUR_B, REV_B

local function Cls(p) return math.min(5, math.floor((p or 0) * 5) + 1) end

-- Preislage (Stufe 2 L1): rel = Preis/Marktwert in 5 Klassen (<= 0,90 / 0,90-0,97 / 0,97-1,03 / 1,03-1,10 / > 1,10)
Fc.REL_B = { 0.90, 0.97, 1.03, 1.10 }
function Fc:RelClass(rel)
    for i, b in ipairs(self.REL_B) do if rel <= b then return i end end
    return #self.REL_B + 1
end
-- Laufzeit-Stufe in Stunden (2/8/24; andere Werte auf die nächste)
function Fc:DurKey(h)
    if not h or h >= 16 then return 24 end
    if h >= 5 then return 8 end
    return 2
end

local function PG(st, g)
    st.P[g] = st.P[g] or { n = 0, sp = 0, sy = 0, sb = 0, hit = 0, cls = {}, dur = {}, late = 0, durN = 0, rev = {}, revN = 0, c = 0 }
    return st.P[g]
end

-- y: Anteil verkauft innerhalb der Laufzeit (abgelaufen/abgebrochen zensiert -> zählt mit dem verkauften Anteil)
function Fc:PostOutcome(e)
    -- PR1: abgebrochen = zensiert (weder Treffer noch Fehler, auch nicht im Lernen)
    if not e.r or e.r == "" or e.r == "u" or e.r == "c" then return nil end
    return math.max(0, math.min(1, (e.sq or 0) / math.max(1, e.q or 1)))
end

-- fügt einen abgeschlossenen Eintrag in Zähler (st-Format) ein; live = Werte zusätzlich für exakte Mediane sammeln
function Fc:Count(st, e, live)
    if e.kind == "P" then
        if e.r == "c" then
            -- PR1: abgebrochen getrennt zählen (zensiert); zum Vergleich "alt" (mit Abbrüchen wie bisher) mitführen
            local g = PG(st, e.g or "misc")
            g.c = g.c + 1
            if e.cr == "u" then g.cu = (g.cu or 0) + 1 end
            if e.p then
                local y = math.max(0, math.min(1, (e.sq or 0) / math.max(1, e.q or 1)))
                g.xn, g.xsp, g.xsy = (g.xn or 0) + 1, (g.xsp or 0) + e.p, (g.xsy or 0) + y
                if (e.p >= 0.5) == (y >= 0.5) then g.xhit = (g.xhit or 0) + 1 end
            end
            return true
        end
        local y = self:PostOutcome(e)
        if y == nil or not e.p then
            if e.r == "u" then st.unknown = (st.unknown or 0) + 1 end
            return false
        end
        local g = PG(st, e.g or "misc")
        local p = e.p
        g.n, g.sp, g.sy, g.sb = g.n + 1, g.sp + p, g.sy + y, g.sb + (p - y) ^ 2
        if (p >= 0.5) == (y >= 0.5) then g.hit = g.hit + 1 end
        if e.r == "c" then g.c = g.c + 1 end
        -- Stufe 2 L1: Zähler je Preislage (rel) und Laufzeit - bleiben in der Zusammenfassung erhalten
        if e.rel and e.d then
            g.rel = g.rel or {}
            local rk = Fc:RelClass(e.rel) .. ":" .. Fc:DurKey(e.d)
            local cell = g.rel[rk] or { 0, 0, 0, 0 }
            cell[1], cell[2] = cell[1] + 1, cell[2] + y
            if (e.sq or 0) > 0 and e.sh then cell[3], cell[4] = cell[3] + e.sh, cell[4] + 1 end
            g.rel[rk] = cell
        end
        local k = Cls(p)
        local c = g.cls[k] or { 0, 0, 0 }
        c[1], c[2], c[3] = c[1] + 1, c[2] + p, c[3] + y
        g.cls[k] = c
        if (e.sq or 0) > 0 and e.sh and e.W and e.W > 0 then
            local ratio = e.sh / e.W
            local b = Bucket(DUR_B, ratio)
            g.dur[b] = (g.dur[b] or 0) + 1
            g.durN = g.durN + 1
            if e.sh > e.W then g.late = g.late + 1 end
            if live then live.dur[#live.dur + 1] = ratio end
        end
        if (e.sq or 0) > 0 and e.sp and e.pr and e.pr > 0 then
            local ratio = e.sp / e.pr
            local b = Bucket(REV_B, ratio)
            g.rev[b] = (g.rev[b] or 0) + 1
            g.revN = g.revN + 1
            if live then live.rev[#live.rev + 1] = ratio end
        end
        return true
    elseif e.kind == "B" then
        if e.r ~= "c" then return false end
        local cost = (e.pr or 0) * (e.q or 1)
        local profit = (e.rv or 0) - cost
        for _, key in ipairs({ "w:" .. (e.way or "e"), "s:" .. (e.src or "buy") }) do
            local tb = key:sub(1, 1) == "w" and st.B or st.Bs
            local k = key:sub(3)
            local x = tb[k] or { n = 0, win = 0, cost = 0, profit = 0 }
            x.n, x.cost, x.profit = x.n + 1, x.cost + cost, x.profit + profit
            if profit > 0 then x.win = x.win + 1 end
            tb[k] = x
        end
        return true
    elseif e.kind == "D" then
        if not (e.ev and e.ev > 0 and e.lv) then return false end
        local k = e.dk or e.g or "?"
        local x = st.D[k] or { n = 0, h = {}, loss = 0, lossN = 0 }
        -- KF2 (Prüf-Sitzung 23:50): Zufallsbeute -> Summen statt Median (Summe Beute / Summe Vorhersage), dazu
        -- Summen der zugeordneten Käufe (Beute / Einsatz) für den Gewinn gesamt je Gruppe (DE30b)
        x.sLv, x.sEv = (x.sLv or 0) + e.lv, (x.sEv or 0) + e.ev
        if e.bp and e.bp > 0 then x.nB, x.sLvB, x.sBp = (x.nB or 0) + 1, (x.sLvB or 0) + e.lv, (x.sBp or 0) + e.bp end
        local ratio = e.lv / e.ev
        local b = Bucket(DUR_B, ratio)
        x.h[b] = (x.h[b] or 0) + 1
        x.n = x.n + 1
        if e.bp then
            x.lossN = x.lossN + 1
            if e.lv < e.bp then x.loss = x.loss + 1 end
        end
        st.D[k] = x
        if live then live.de[k] = live.de[k] or {}; table.insert(live.de[k], ratio) end
        return true
    end
    return false
end

-- P4: aus dem Ringpuffer gefallener Eintrag -> Zusammenfassung (offene: "unbekannt")
function Fc:Archive(st, e, now)
    if not st then return end
    if e.kind == "P" and (e.r == nil or e.r == "") then e.r = "u" end
    if not self:Count(st, e) then st.dropped = (st.dropped or 0) + 1 end
end

local function CopyCounts(src)
    local function cp(t)
        if type(t) ~= "table" then return t end
        local o = {}
        for k, v in pairs(t) do o[k] = cp(v) end
        return o
    end
    return cp(src)
end

-- Gesamtauswertung: Zusammenfassung + Ringpuffer. Rückgabe Tabelle R (siehe Report)
-- Punkt 3 (Nachprüfung 10.11. 14:35): die volle Auswertung läuft im Tooltip-/Lernpfad nicht mehr synchron.
-- Fc:Eval rechnet sofort (Berichte, Tests); Fc:EvalCached liefert den Zwischenspeicher und stösst bei Bedarf eine
-- Hintergrund-Aufgabe an, die in Portionen rechnet (A:Pause alle EVAL_STEP Einträge).
Fc.EVAL_STEP = 100
function Fc:EvalKey(f, now)
    return f and (#f.list .. ":" .. tostring(f.list[#f.list]) .. ":" .. math.floor(now / 60)) or "-"
end
function Fc:Eval(now)
    local f = self:Data()
    now = now or time()
    local key = self:EvalKey(f, now)
    if self.evalCache and self.evalCache.key == key and self.evalCache.store == f then return self.evalCache.r end
    local R = self:EvalCore(now)
    self.evalCache = { key = key, store = f, r = R }
    return R
end
-- Zwischenspeicher (auch älter als eine Minute); nil, solange noch nie gerechnet wurde. Startet die Neuberechnung im
-- Hintergrund, wenn sich Liste oder Minute geändert haben.
function Fc:EvalCached(now)
    local f = self:Data()
    now = now or time()
    local c = self.evalCache
    local key = self:EvalKey(f, now)
    if c and c.store == f then
        if c.key ~= key then self:EvalInBackground(now) end
        return c.r
    end
    -- Ersatz-Journal der Testroutine: sofort rechnen (klein, nur im Test)
    if self.testStore then return self:Eval(now) end
    self:EvalInBackground(now)
    return nil
end
function Fc:EvalInBackground(now, after)
    if self.evalRunning and not after then return end
    self.evalRunning = true
    A:Job("forecast-eval", function()
        local f = Fc:Data()
        local t = now or time()
        local ok, R = A:PCall(Fc.EvalCore, Fc, t, true)
        if ok and R then Fc.evalCache = { key = Fc:EvalKey(f, t), store = f, r = R } end
        Fc.evalRunning = nil
        if after then pcall(after, ok and R or nil) end
    end)
end

function Fc:EvalCore(now, pause)
    local f, st = self:Data()
    now = now or time()
    local R = CopyCounts(st or NewStats())
    R.unknown = R.unknown or 0
    R.live = { dur = {}, rev = {}, de = {} }
    R.total, R.done, R.open, R.posts, R.buys, R.des, R.openBuys = 0, 0, 0, 0, 0, 0, 0
    R.openBuyValue, R.openBuyCost = 0, 0
    for idx, s in ipairs(f and f.list or {}) do
        if pause and idx % self.EVAL_STEP == 0 then A:Pause() end
        local e = self:Decode(s)
        if e then
            R.total = R.total + 1
            if e.kind == "P" then R.posts = R.posts + 1
            elseif e.kind == "B" then R.buys = R.buys + 1
            else R.des = R.des + 1 end
            if self:Count(R, e, R.live) then R.done = R.done + 1
            elseif e.kind == "P" and e.r ~= "u" then R.open = R.open + 1
            elseif e.kind == "B" then
                R.openBuys = R.openBuys + 1
                local left = (e.q or 1) - (e.rq or 0)
                local okV, v = pcall(A.RealValue, A, e.id, 1)
                R.openBuyValue = R.openBuyValue + (e.rv or 0) + ((okV and v) or 0) * left
                R.openBuyCost = R.openBuyCost + (e.pr or 0) * (e.q or 1)
            end
        end
    end
    -- Summen über alle Gruppen
    local all = { n = 0, sp = 0, sy = 0, sb = 0, hit = 0, cls = {}, dur = {}, late = 0, durN = 0, rev = {}, revN = 0, c = 0 }
    for _, g in pairs(R.P) do
        all.n, all.sp, all.sy, all.sb, all.hit = all.n + g.n, all.sp + g.sp, all.sy + g.sy, all.sb + g.sb, all.hit + g.hit
        all.late, all.durN, all.revN, all.c = all.late + g.late, all.durN + g.durN, all.revN + g.revN, all.c + g.c
        all.cu, all.xn, all.xsp, all.xsy, all.xhit = (all.cu or 0) + (g.cu or 0), (all.xn or 0) + (g.xn or 0), (all.xsp or 0) + (g.xsp or 0),
            (all.xsy or 0) + (g.xsy or 0), (all.xhit or 0) + (g.xhit or 0)
        for k, c in pairs(g.cls) do
            local a = all.cls[k] or { 0, 0, 0 }
            a[1], a[2], a[3] = a[1] + c[1], a[2] + c[2], a[3] + c[3]
            all.cls[k] = a
        end
        for k, n in pairs(g.dur) do all.dur[k] = (all.dur[k] or 0) + n end
        for k, c in pairs(g.rel or {}) do
            all.rel = all.rel or {}
            local a = all.rel[k] or { 0, 0, 0, 0 }
            for i = 1, 4 do a[i] = a[i] + c[i] end
            all.rel[k] = a
        end
        for k, n in pairs(g.rev) do all.rev[k] = (all.rev[k] or 0) + n end
    end
    R.all = all
    return R
end

-- PR1 (3): Einstellungen desselben Items zu Ketten verbinden: die nächste Einstellung beginnt höchstens CHAIN_GAP nach
-- dem Ende (Ablauf) bzw. dem Abbruch der vorigen. Eine Kette endet mit "verkauft" (s), sonst offen/nicht verkauft.
Fc.CHAIN_GAP = 6 * 3600
-- EB-DET-1: Verkaufsquote je KETTE (Abbruch/Ablauf mit Neu-Einstellung zählt nicht doppelt): eingestellt = grösste
-- Menge einer Einstellung der Kette, verkauft = Summe verkaufter Stück (höchstens eingestellt). Nur abgeschlossene Ketten
-- (letzte Einstellung mit Ergebnis), Beginn ab from. Zurück: verkauft, eingestellt
function Fc:ChainSellRate(from, list)
    local f = self:Data()
    list = list or (f and f.list) or {}
    local by = {}
    for _, s in ipairs(list) do
        if s:sub(1, 1) == "P" then
            local e = self:Decode(s)
            if e and e.id then by[e.id] = by[e.id] or {}; table.insert(by[e.id], e) end
        end
    end
    local posted, sold = 0, 0
    for _, posts in pairs(by) do
        table.sort(posts, function(a, b) return (a.t or 0) < (b.t or 0) end)
        local chain
        local function close()
            if chain and chain.done and chain.t0 >= (from or 0) then
                posted, sold = posted + chain.q, sold + math.min(chain.q, chain.sq)
            end
            chain = nil
        end
        for _, e in ipairs(posts) do
            local stop = (e.t or 0) + (e.d or 24) * 3600
            if not (chain and not chain.sold and (e.t or 0) <= chain.stop + self.CHAIN_GAP) then
                close()
                chain = { t0 = e.t or 0, q = 0, sq = 0 }
            end
            chain.stop = stop
            chain.q = math.max(chain.q, e.q or 1)
            chain.sq = chain.sq + (e.sq or 0)
            if e.r == "s" then chain.sold = true end
            chain.done = e.r ~= nil and e.r ~= "" and e.r ~= "u"
        end
        close()
    end
    return sold, posted
end

function Fc:Chains(list)
    local f = self:Data()
    list = list or (f and f.list) or {}
    local by = {}
    for _, s in ipairs(list) do
        if s:sub(1, 1) == "P" then
            local e = self:Decode(s)
            if e and e.id then by[e.id] = by[e.id] or {}; table.insert(by[e.id], e) end
        end
    end
    local res = { n = 0, sold = 0, open = 0, reposts = 0, posts = {}, price = {} }
    for _, posts in pairs(by) do
        table.sort(posts, function(a, b) return (a.t or 0) < (b.t or 0) end)
        local chain
        local function close()
            if not chain then return end
            res.n = res.n + 1
            if chain.sold then res.sold = res.sold + 1 elseif chain.open then res.open = res.open + 1 end
            res.posts[#res.posts + 1] = chain.k
            if chain.k > 1 and chain.p0 and chain.p0 > 0 and chain.p1 then res.price[#res.price + 1] = chain.p1 / chain.p0 end
            chain = nil
        end
        for _, e in ipairs(posts) do
            local stop = (e.t or 0) + (e.d or 24) * 3600
            if chain and not chain.sold and (e.t or 0) <= chain.stop + self.CHAIN_GAP then
                chain.k, chain.stop, chain.p1 = chain.k + 1, stop, e.pr
                res.reposts = res.reposts + 1
            else
                close()
                chain = { k = 1, stop = stop, p0 = e.pr, p1 = e.pr }
            end
            if e.r == "s" then chain.sold = true end
            chain.open = (e.r == nil or e.r == "")
        end
        close()
    end
    local sumP = 0
    for _, k in ipairs(res.posts) do sumP = sumP + k end
    res.avgPosts = res.n > 0 and sumP / res.n or 0
    res.medPosts = Fc.Median(res.posts, {}, #res.posts, DUR_B)
    res.medPrice = #res.price > 0 and Fc.Median(res.price, {}, #res.price, DUR_B) or nil
    return res
end

function Fc:Brier(g) return (g and g.n > 0) and g.sb / g.n or nil end

-- ------------------------------------------------------------
-- Kalibrierung (TB108, Releaseplan 0.65.110): Verkaufs-Wahrscheinlichkeit "verkauft sich zu x %" ist erst nach
-- Kalibrierung eine Zahl; vorher grau "lernt noch". Selbstkorrektur sofort: Faktor = tatsächlich verkauft / vorhergesagt
-- (alle Fälle), gedämpft auf 0,2–1,2. Kalibriert = mind. 30 Fälle, Brier <= 0,20 und Faktor 0,85–1,15.
-- ------------------------------------------------------------
Fc.CALIB_N, Fc.CALIB_BRIER, Fc.CALIB_TOL = 30, 0.20, 0.15
function Fc:CalibFromAll(all)
    if not (all and all.n and all.n > 0 and all.cls) then return 1, false, 0, nil end
    local pred, sold = 0, 0
    for k = 1, 5 do local c = all.cls[k]; if c then pred, sold = pred + (c[2] or 0), sold + (c[3] or 0) end end
    local factor = 1
    if all.n >= self.MIN_REPORT and pred > 0 then factor = math.max(0.2, math.min(1.2, sold / pred)) end
    local brier = all.sb and all.sb / all.n or nil
    local ok = all.n >= self.CALIB_N and brier ~= nil and brier <= self.CALIB_BRIER and math.abs(factor - 1) <= self.CALIB_TOL
    return factor, ok, all.n, brier
end
function Fc:Calibration()
    if self.calibTest then return unpack(self.calibTest) end
    local ok, R = pcall(self.EvalCached, self)
    return self:CalibFromAll(ok and R and R.all)
end
-- angezeigte Wahrscheinlichkeit: korrigiert; Text mit "lernt noch", solange nicht kalibriert
function Fc:ShownChance(p)
    if not p then return nil, false end
    local factor, ok = self:Calibration()
    return math.max(0, math.min(1, p * factor)), ok
end

-- Median: exakt aus den Werten, wenn alle Fälle noch im Ringpuffer sind; sonst aus dem Histogramm (Klassenmitte)
local function Median(values, hist, n, bounds)
    if n == 0 then return nil end
    if #values == n then
        table.sort(values)
        local m = math.floor((#values + 1) / 2)
        if #values % 2 == 0 then return (values[m] + values[m + 1]) / 2 end
        return values[m]
    end
    local half, acc = n / 2, 0
    for i = 1, #bounds + 1 do
        acc = acc + (hist[i] or 0)
        if acc >= half then
            local lo, hi = bounds[i - 1] or 0, bounds[i] or (bounds[#bounds] * 1.5)
            return (lo + hi) / 2
        end
    end
    return nil
end
Fc.Median = Median

-- P7: Anteil richtig vorhergesagt (p >= 50 % <-> verkauft) in der Warengruppe des Items, ab MIN_TOOLTIP Fällen
function Fc:TooltipLine(itemID)
    local f, st = self:Data()
    if not itemID or not ((f and #f.list > 0) or (st and next(st.P or {}))) then return nil end
    local ok, R = pcall(self.Eval, self, nil)
    if not (ok and R) then return nil end
    local g = R.P[self:Group(itemID)]
    if not g or g.n < self.MIN_TOOLTIP then return nil end
    return string.format(L["Prognosen bei dir: %d %% zutreffend (N %d)"], math.floor(g.hit / g.n * 100 + 0.5), g.n), g
end

-- ------------------------------------------------------------
-- P5 Messaufträge
-- ------------------------------------------------------------
-- M1: nur Existenz (NICHT aufrufen)
function Fc:M1()
    local CA = A:Global("C_AuctionHouse")
    local have = {}
    for _, fn in ipairs({ "ReplicateItems", "GetNumReplicateItems", "GetReplicateItemInfo", "GetReplicateItemTimeLeft" }) do
        if type(CA) == "table" and type(CA[fn]) == "function" then have[#have + 1] = fn end
    end
    return have
end

-- M2: Felder eines Ergebnisses der Item-Suche (nur Feldnamen und Art, keine Werte, keine Namen) - einmal je Version und Art
local NAMEY = { owners = true, bidder = true, owner = true, sellerName = true }
function Fc:NoteM2(kind, info)
    if type(info) ~= "table" then return end
    local f = self:Store()
    if not f then return end
    f.m2 = f.m2 or {}
    local v = tostring(A.version)
    if f.m2[kind] and f.m2[kind].v == v then return end
    local keys = {}
    for k, x in pairs(info) do
        if type(k) == "string" then keys[#keys + 1] = k .. (NAMEY[k] and "" or (":" .. type(x):sub(1, 1))) end
    end
    table.sort(keys)
    local text = table.concat(keys, ",")
    f.m2[kind] = { v = v, f = text:sub(1, 400) }
    if A.Diag then pcall(A.Diag.Add, A.Diag, "M2", string.format("%s: %s", kind == "com" and "Ware" or "Ausrüstung", text:sub(1, 400))) end
end

-- M3: je Item und Stunde des Tages gleitender Mindestpreis/Menge (nur gehandelte/beobachtete Items)
function Fc:RelevantItems(now)
    local set, n = {}, 0
    local function add(id)
        if type(id) == "number" and not set[id] and n < self.HOUR_ITEMS then set[id] = true; n = n + 1 end
    end
    local db = A.db or {}
    local from = (now or time()) - 30 * 86400
    local led = db.ledger and db.ledger.entries or {}
    for i = #led, 1, -1 do
        local e = led[i]
        if (e.t or 0) < from then break end
        add(e.itemID)
    end
    for id in pairs(db.watchlist or {}) do add(tonumber(id)) end
    local Sn = A.Sniper
    if Sn and Sn.GetTargets then
        local ok, list = pcall(Sn.GetTargets, Sn)
        for _, t in ipairs(ok and list or {}) do add(t.itemID) end
    end
    return set, n
end

function Fc:UpdateHours(now)
    local f, _, hours = self:Store()
    if not (f and hours) then return 0 end
    now = now or time()
    local set = self:RelevantItems(now)
    local h = tonumber(date("%H", now)) or 0
    local done = 0
    for id in pairs(set) do
        local price, qty, t = A:GetCurrent(id)
        if price and t and now - t < 3600 then
            local slots = {}
            for p, q in (hours[id] or ""):gmatch("([%d]*):([%d]*)") do slots[#slots + 1] = { tonumber(p), tonumber(q) } end
            for i = #slots + 1, 24 do slots[i] = {} end
            local s = slots[h + 1]
            s[1] = s[1] and math.floor(s[1] * 0.7 + price * 0.3 + 0.5) or price
            s[2] = s[2] and math.floor(s[2] * 0.7 + (qty or 0) * 0.3 + 0.5) or (qty or 0)
            local out = {}
            for i = 1, 24 do out[i] = (slots[i][1] or "") .. ":" .. (slots[i][2] or "") end
            hours[id] = table.concat(out, ",")
            done = done + 1
        end
    end
    -- nicht mehr relevante Items entfernen (Speicher)
    local count = 0
    for id in pairs(hours) do
        if not set[id] then count = count + 1 end
    end
    if count > 0 then
        local total = 0
        for _ in pairs(hours) do total = total + 1 end
        if total > self.HOUR_ITEMS then
            for id in pairs(hours) do if not set[id] then hours[id] = nil end end
        end
    end
    return done
end

-- Speichergrösse (Schätzung der SavedVariables-Zeichen: Zeichenketten + Rahmen je Zeile)
local function SizeOf(v, depth)
    depth = depth or 0
    if type(v) == "string" then return #v + 4 end
    if type(v) ~= "table" or depth > 8 then return 8 end
    local n = 4
    for k, x in pairs(v) do n = n + (type(k) == "string" and #k + 6 or 12) + SizeOf(x, depth + 1) end
    return n
end
function Fc:Size()
    local f, st, hours = self:Data()
    local fj = f and SizeOf(f) or 0
    local sj = st and SizeOf(st) or 0
    local hj = hours and SizeOf(hours) or 0
    local items = 0
    for _ in pairs(hours or {}) do items = items + 1 end
    return fj, sj, hj, items, f and #f.list or 0
end

-- ------------------------------------------------------------
-- X7: Zähler nur aus Fällen ab einem Zeitpunkt (Selbstkorrektur lernt nicht mit Fällen vor der Behebung)
function Fc:EvalSince(since)
    local f = self:Data()
    local R = NewStats()
    for _, s in ipairs(f and f.list or {}) do
        if s:sub(1, 1) == "P" then
            local e = self:Decode(s)
            if e and (e.t or 0) >= (since or 0) then self:Count(R, e) end
        end
    end
    local all = { n = 0 }
    for _, g in pairs(R.P) do all.n = all.n + g.n end
    R.all = all
    return R
end

-- X7: P-Diagnose - je Fall (ohne Namen) Item-ID, vorhergesagt %, eingestellt/verkauft, Ergebnis und WOHER es kommt
Fc.RESULT_SRC = { s = "Rechnung/Meldung (alles verkauft)", t = "Teilverkauf, Rest abgelaufen (Briefkasten)", e = "Ablauf (Briefkasten, nichts verkauft)",
    c = "Abbruch", u = "Zeitlimit (7 Tage ohne Briefkasten)" }
function Fc:PDiagnosis(group, max)
    local f = self:Data()
    local rows, n = {}, 0
    local list = f and f.list or {}
    for i = #list, 1, -1 do
        local s = list[i]
        if s:sub(1, 1) == "P" then
            local e = self:Decode(s)
            if e and e.r and e.r ~= "" and (not group or e.g == group) then
                n = n + 1
                if n <= (max or 20) then
                    local y = self:PostOutcome(e)
                    rows[#rows + 1] = string.format("%s %d%% %d/%d %s (%s%s)", tostring(e.id), math.floor((e.p or 0) * 100 + 0.5), e.q or 1, e.sq or 0,
                        y and string.format("%.2f", y) or "-", self.RESULT_SRC[e.r] or e.r, e.rs and (", " .. e.rs) or "")
                end
            end
        end
    end
    return rows, n
end

-- X8: Entzaubern - Beute/Vorhersage in Chancen-, Mengen- und Rest-Faktor (Preis u. a.) zerlegen, je Gruppe.
-- Nur messen (eigene deStats lesen, nichts ändern). Chance/Menge zu den heutigen Materialpreisen gewichtet.
-- DE30b: Entzauber-Gruppe = Stufenband + Qualität (welche Materialien herauskommen); Rüstung und Waffe zusammen
function Fc:DEGroupOf(dk) return dk and (tostring(dk):gsub(":[aw]$", "")) or nil end
-- Summen je Gruppe (alle dk mit derselben Gruppe): n, Summe Beute, Summe Vorhersage, Käufe, Beute der Käufe, Einsatz
function Fc:DEGroupStats(group, R)
    if not group then return nil end
    if not R then
        local ok, r = pcall(self.EvalCached, self)
        R = ok and r or nil
    end
    if not (R and R.D) then return nil end
    local g = { n = 0, sLv = 0, sEv = 0, nB = 0, sLvB = 0, sBp = 0, keys = {} }
    for k, x in pairs(R.D) do
        if self:DEGroupOf(k) == group then
            g.n, g.sLv, g.sEv = g.n + (x.n or 0), g.sLv + (x.sLv or 0), g.sEv + (x.sEv or 0)
            g.nB, g.sLvB, g.sBp = g.nB + (x.nB or 0), g.sLvB + (x.sLvB or 0), g.sBp + (x.sBp or 0)
            g.keys[#g.keys + 1] = k
        end
    end
    return g
end

function Fc:DEFactors(key)
    local D = A.Disenchant
    local st = A.db and A.db.deStats and A.db.deStats[key]
    local prior = D and D.PriorForKey and D:PriorForKey(key)
    if not (st and (st.n or 0) > 0 and prior) then return nil end
    local tab, chanceW, qtyW = 0, 0, 0
    for _, p in ipairs(prior) do
        local id, chance, avg = p[1], p[2] or 0, p[3] or 1
        local okP, price = pcall(D.MatPrice, D, id)
        price = (okP and price) or 0
        local m = st.mats and st.mats[id]
        local share = m and (m.times or 0) / st.n or 0
        local avgM = (m and (m.times or 0) > 0) and (m.total or 0) / m.times or avg
        tab = tab + chance * avg * price
        chanceW = chanceW + share * avg * price
        qtyW = qtyW + share * avgM * price
    end
    if tab <= 0 or chanceW <= 0 then return nil end
    return chanceW / tab, qtyW / chanceW, st.n
end

-- Bericht "Prognose-Güte" (P6 Teil B: echte Daten, nur lesen)
-- ------------------------------------------------------------
local function Pct(x) return string.format("%d %%", math.floor(x * 100 + 0.5)) end
local function F2(x) return x and string.format("%.2f", x) or "-" end

function Fc:Report()
    local R = self:Eval()
    local out, fields = { "Prognose-Güte (echte Daten):" }, {}
    local a = R.all
    out[#out + 1] = string.format("  Fälle gesamt %d (Einstellen %d, Kaufen %d, Entzaubern %d) · mit Ergebnis %d · offen %d · unbekannt %d · abgebrochen %d",
        R.total, R.posts, R.buys, R.des, R.done, R.open, R.unknown or 0, a.c)
    fields.prognose_faelle = string.format("%d/%d/%d", R.total, R.done, R.open)
    do  -- PD2: Doppel im Journal (Soll 0) und beiseitegelegte
        local f = self:Data()
        local nd = self:Doubles(f)
        out[#out + 1] = string.format("  Doppel %d · beiseitegelegt %d", nd, f and f.dups and #f.dups or 0)
        fields.prognose_doppel = tostring(nd)
    end
    -- Zuverlässigkeit
    if a.n < self.MIN_REPORT then
        out[#out + 1] = string.format("  Verkaufschance: zu wenig Daten (%d)", a.n)
        fields.prognose_brier = string.format("zu wenig Daten (%d)", a.n)
        fields.prognose_zuverlaessigkeit = "-"
    else
        local rows = {}
        for k = 1, 5 do
            local c = a.cls[k]
            if c and c[1] > 0 then
                rows[#rows + 1] = string.format("%d–%d %%: %d Fälle, vorhergesagt Ø %s, verkauft %s", (k - 1) * 20, k * 20, c[1], Pct(c[2] / c[1]), Pct(c[3] / c[1]))
            end
        end
        out[#out + 1] = "  Zuverlässigkeit: " .. table.concat(rows, " | ")
        fields.prognose_zuverlaessigkeit = table.concat(rows, " | "):sub(1, 400)
        local per = {}
        for _, g in ipairs(self.GROUPS) do
            local x = R.P[g]
            if x and x.n >= self.MIN_GROUP then per[#per + 1] = string.format("%s %.3f (%d)", self.GROUP_NAMES[g], x.sb / x.n, x.n) end
        end
        out[#out + 1] = string.format("  Brier gesamt %.3f (N %d, 0 = perfekt, 0,25 = Münzwurf) · zutreffend %s%s", a.sb / a.n, a.n, Pct(a.hit / a.n),
            #per > 0 and (" · je Gruppe: " .. table.concat(per, ", ")) or "")
        fields.prognose_brier = string.format("%.3f (%d)", a.sb / a.n, a.n)
        local fac, calOK = self:CalibFromAll(a)
        out[#out + 1] = string.format("  Kalibrierung: Faktor %.2f (verkauft / vorhergesagt, angewendet) · %s", fac,
            calOK and "kalibriert" or "nicht kalibriert – Prozent grau \"lernt noch\"")
    end
    -- PR1 (3): Ketten (Ablauf/Abbruch -> neu eingestellt -> ... -> verkauft) als EIN Fall
    do
        local okK, k = pcall(self.Chains, self)
        if okK and k and k.n > 0 then
            out[#out + 1] = string.format("  PR1 Ketten: %d (verkauft %s, offen %d) · Einstellungen je Kette Median %s, Ø %.1f · Neu-Einstellungen %d · Preis letzte/erste Einstellung Median %s",
                k.n, Pct(k.sold / k.n), k.open, F2(k.medPosts), k.avgPosts, k.reposts, F2(k.medPrice))
            fields.prognose_ketten = string.format("%d/%d/%s/%s", k.n, k.sold, F2(k.medPosts), F2(k.medPrice))
        else
            out[#out + 1] = "  PR1 Ketten: noch keine"
            fields.prognose_ketten = "-"
        end
    end
    -- SN-M: Käufe je Preisstufe (Kaufpreis / erwarteter Netto-Wert beim Kauf): Gewinn gesamt (Summe Erlös / Summe Einsatz)
    do
        local B = { 0.7, 0.8, 0.9 }
        local NAMES = { "≤ 0,7", "0,7–0,8", "0,8–0,9", "> 0,9" }
        local acc = {}
        local f = self:Data()
        for _, s2 in ipairs(f and f.list or {}) do
            if s2:sub(1, 1) == "B" then
                local e = self:Decode(s2)
                if e and e.r == "c" and e.pr and e.ev and e.ev > 0 then
                    local x = e.pr / e.ev
                    local k = #B + 1
                    for i, b in ipairs(B) do if x <= b then k = i; break end end
                    local c = acc[k] or { 0, 0, 0 }
                    c[1], c[2], c[3] = c[1] + 1, c[2] + (e.pr or 0) * (e.q or 1), c[3] + (e.rv or 0)
                    acc[k] = c
                end
            end
        end
        local parts = {}
        for k = 1, #NAMES do
            local c = acc[k]
            if c and c[1] > 0 and c[2] > 0 then parts[#parts + 1] = string.format("%s: %+.0f %% (N %d)", NAMES[k], (c[3] / c[2] - 1) * 100, c[1]) end
        end
        out[#out + 1] = "  SN-M Käufe je Preisstufe (Kaufpreis/Wert, Gewinn gesamt): " .. (#parts > 0 and table.concat(parts, " | ") or "noch keine")
        fields.kauf_preisstufe = #parts > 0 and table.concat(parts, " | ") or "-"
    end
    -- PR1: Abbrüche zensiert; Vergleich alt (mit Abbrüchen) / neu; Verkaufsanteil je Preisstufe (Preis/Marktwert)
    do
        local xn = a.xn or 0
        local nAll, spAll, syAll, hitAll = a.n + xn, a.sp + (a.xsp or 0), a.sy + (a.xsy or 0), a.hit + (a.xhit or 0)
        out[#out + 1] = string.format("  PR1 Abbrüche (zensiert, zählen nicht): %d, davon unterboten %d · ohne Abbrüche: zutreffend %s, vorhergesagt %s, verkauft %s (N %d) · alt mit Abbrüchen: zutreffend %s, vorhergesagt %s, verkauft %s (N %d)",
            a.c or 0, a.cu or 0, a.n > 0 and Pct(a.hit / a.n) or "-", a.n > 0 and Pct(a.sp / a.n) or "-", a.n > 0 and Pct(a.sy / a.n) or "-", a.n,
            nAll > 0 and Pct(hitAll / nAll) or "-", nAll > 0 and Pct(spAll / nAll) or "-", nAll > 0 and Pct(syAll / nAll) or "-", nAll)
        local REL = { "≤ 0,90", "0,90–0,97", "0,97–1,03", "1,03–1,10", "> 1,10" }
        local per, cells = {}, {}
        for k, c in pairs(a.rel or {}) do
            local rc = tonumber(tostring(k):match("^(%d+)"))
            if rc then local x = cells[rc] or { 0, 0 }; x[1], x[2] = x[1] + c[1], x[2] + c[2]; cells[rc] = x end
        end
        for rc = 1, #REL do
            local x = cells[rc]
            if x and x[1] > 0 then per[#per + 1] = string.format("%s: verkauft %s (N %d)", REL[rc], Pct(x[2] / x[1]), x[1]) end
        end
        out[#out + 1] = "  PR1 je Preisstufe (Preis/Marktwert): " .. (#per > 0 and table.concat(per, " | ") or "noch keine Fälle")
        fields.prognose_pr1 = string.format("abgebrochen %d/unterboten %d · neu %s (%d) · alt %s (%d)", a.c or 0, a.cu or 0,
            a.n > 0 and Pct(a.hit / a.n) or "-", a.n, nAll > 0 and Pct(hitAll / nAll) or "-", nAll)
        fields.prognose_preisstufe = table.concat(per, " | "):sub(1, 300)
    end
    -- Dauer, Erlös
    local md = Median(R.live.dur, a.dur, a.durN, DUR_B)
    local mr = Median(R.live.rev, a.rev, a.revN, REV_B)
    if a.durN < self.MIN_REPORT then out[#out + 1] = string.format("  Dauer: zu wenig Daten (%d)", a.durN)
    else out[#out + 1] = string.format("  Dauer: Median tatsächlich/vorhergesagt %s (N %d) · später als vorhergesagt %s", F2(md), a.durN, Pct(a.late / a.durN)) end
    if a.revN < self.MIN_REPORT then out[#out + 1] = string.format("  Erlös: zu wenig Daten (%d)", a.revN)
    else out[#out + 1] = string.format("  Erlös: Median erzielt/vorhergesagt %s (N %d)", F2(mr), a.revN) end
    fields.prognose_dauer = a.durN >= self.MIN_REPORT and string.format("%s (%d)", F2(md), a.durN) or string.format("zu wenig Daten (%d)", a.durN)
    fields.prognose_erloes = a.revN >= self.MIN_REPORT and string.format("%s (%d)", F2(mr), a.revN) or string.format("zu wenig Daten (%d)", a.revN)
    -- Kaufen
    local WAY = { e = "Einstellen/Flip", d = "Entzaubern", v = "Händler", c = "Herstellen" }
    local parts = {}
    for _, w in ipairs({ "e", "d", "v", "c" }) do
        local x = R.B[w]
        if x and x.n > 0 then
            parts[#parts + 1] = x.n < self.MIN_REPORT and string.format("%s: zu wenig Daten (%d)", WAY[w], x.n)
                or string.format("%s: %d, mit Gewinn %s, Gewinn je Gold %s", WAY[w], x.n, Pct(x.win / x.n), F2(x.cost > 0 and x.profit / x.cost or 0))
        end
    end
    local srcs = {}
    for k, x in pairs(R.Bs) do srcs[#srcs + 1] = string.format("%s %d (%s mit Gewinn)", k, x.n, Pct(x.win / math.max(1, x.n))) end
    table.sort(srcs)
    out[#out + 1] = string.format("  Käufe: offen %d (heute Wert %s für Einsatz %s)%s%s", R.openBuys, A:FormatMoney(math.floor(R.openBuyValue)),
        A:FormatMoney(R.openBuyCost), #parts > 0 and (" · " .. table.concat(parts, " · ")) or " · noch keine abgeschlossen",
        #srcs > 0 and (" · Quellen: " .. table.concat(srcs, ", ")) or "")
    fields.prognose_kauf = (#parts > 0 and table.concat(parts, " · ") or "-"):sub(1, 300)
    -- Entzaubern
    local dparts, lossN, loss = {}, 0, 0
    local keys = {}
    for k in pairs(R.D) do keys[#keys + 1] = k end
    table.sort(keys)
    -- KF2: Zufallsbeute -> Summen (Summe Beute / Summe Vorhersage; Gewinn gesamt = Summe Beute / Summe Einsatz − 1).
    -- Die Einzel-Verlustquote steht nur als Nebeninfo ("Zufallsbeute": meist Staub, selten teure Essenz/Splitter).
    local gparts, groupsDone = {}, {}
    for _, k in ipairs(keys) do
        local x = R.D[k]
        local sumR = (x.sEv or 0) > 0 and (x.sLv or 0) / x.sEv or nil
        dparts[#dparts + 1] = x.n < self.MIN_REPORT and string.format("%s zu wenig Daten (%d)", k, x.n) or string.format("%s %s (%d)", k, F2(sumR), x.n)
        lossN, loss = lossN + x.lossN, loss + x.loss
        local grp = self:DEGroupOf(k)
        if grp and not groupsDone[grp] then
            groupsDone[grp] = true
            local g = self:DEGroupStats(grp, R)
            if g and g.sBp > 0 then
                local gain = g.sLvB / g.sBp - 1
                local minG, why
                if g.nB >= (A.DE_PROVEN_N or 30) then
                    minG, why = gain >= 0.20 and (A.DE_GAIN_PROVEN or 20) or (A.DE_GAIN_BAD or 30), gain >= 0.20 and "gemessen gut" or "gemessen schlecht"
                else
                    local rel = A.DETableReliable and A:DETableReliable()
                    minG, why = rel and (A.DE_GAIN_PROVEN or 20) or (A.DE_GAIN_UNPROVEN or 25), rel and "Tabelle verlässlich" or "Tabelle weicht ab"
                end
                local okF, cf, qf = pcall(self.DEFactors, self, g.keys[1])
                gparts[#gparts + 1] = string.format("%s Gewinn gesamt %+.0f %% (%d Käufe, Chance %s, Menge %s) -> %d %% (%s)", grp, gain * 100, g.nB,
                    okF and F2(cf) or "-", okF and F2(qf) or "-", minG, why)
            end
        end
    end
    out[#out + 1] = string.format("  Entzaubern: Beute/Vorhersage (Summen) %s · Gewinn gesamt je Gruppe: %s · Nebeninfo Zufallsbeute: Einzelfälle unter Kaufpreis %s",
        #dparts > 0 and table.concat(dparts, ", ") or "keine Fälle", #gparts > 0 and table.concat(gparts, " | ") or "-",
        lossN > 0 and string.format("%s (%d)", Pct(loss / lossN), lossN) or "-")
    fields.prognose_entzaubern = (#dparts > 0 and table.concat(dparts, ", ") or "-"):sub(1, 300)
    fields.entzaubern_gruppen = (#gparts > 0 and table.concat(gparts, " | ") or "-"):sub(1, 400)          -- DE30b
    -- X8: Zerlegung je Gruppe (Chance × Menge × Rest = Beute/Vorhersage). TB125-8/KF2: aus SUMMEN (Summe Beute /
    -- Summe Vorhersage), nie Median - Zufallsbeute
    local fparts = {}
    for _, k in ipairs(keys) do
        local x = R.D[k]
        local m = (x.sEv or 0) > 0 and x.sLv / x.sEv or nil
        local okF, cf, qf = pcall(self.DEFactors, self, k)
        if okF and cf and m and x.n >= self.MIN_REPORT then
            fparts[#fparts + 1] = string.format("%s Chance %s × Menge %s × Rest (Preis u. a.) %s = %s", k, F2(cf), F2(qf), F2(m / (cf * qf)), F2(m))
        end
    end
    out[#out + 1] = "  Entzaubern zerlegt: " .. (#fparts > 0 and table.concat(fparts, " | ") or "zu wenig Daten")
    fields.prognose_de_faktoren = (#fparts > 0 and table.concat(fparts, " | ") or "-"):sub(1, 400)
    -- X7: P-Diagnose Staub/Essenz/Splitter (die auffällige Gruppe) - je Fall Herkunft des Ergebnisses
    local drows, dn = self:PDiagnosis("de", 12)
    out[#out + 1] = string.format("  P-Diagnose %s (%d Fälle, neueste zuerst: Item vorhergesagt eingestellt/verkauft Ergebnis (Herkunft)): %s",
        self.GROUP_NAMES.de or "de", dn, #drows > 0 and table.concat(drows, " | ") or "keine")
    fields.prognose_p_diagnose = (#drows > 0 and table.concat(drows, " | ") or "-"):sub(1, 600)
    local Ln = A.Learn
    local since = Ln and Ln.Data and Ln:Data() and Ln:Data().x7Since
    out[#out + 1] = "  Selbstkorrektur: lernt erst mit Fällen ab " .. (since and date("%d.%m.%Y %H:%M", since) or "der nächsten Einstellung")
        .. " (Zuordnung der Rechnungen behoben in 0.65.88; ältere Fälle nur in der Anzeige)"
    -- Messaufträge
    local m1 = self:M1()
    local f = self:Data()
    local m2 = f and f.m2 or {}
    out[#out + 1] = string.format("  M1 ReplicateItems: %s · M2 Ware: %s · M2 Ausrüstung: %s", #m1 > 0 and ("da (" .. table.concat(m1, ", ") .. ")") or "nicht da",
        m2.com and m2.com.f or "noch keine Suche", m2.item and m2.item.f or "noch keine Suche")
    fields.prognose_m1 = #m1 > 0 and table.concat(m1, ",") or "nicht da"
    fields.prognose_m2 = ((m2.com and ("Ware " .. m2.com.f) or "Ware -") .. " | " .. (m2.item and ("Ausrüstung " .. m2.item.f) or "Ausrüstung -")):sub(1, 600)
    local fj, sj, hj, items, n = self:Size()
    out[#out + 1] = string.format("  Speicher: Journal %d KB (%d Einträge) + Zusammenfassung %d KB = %d KB (Ziel < 300 KB) · Stundenwerte M3 %d KB (%d Items)",
        math.ceil(fj / 1024), n, math.ceil(sj / 1024), math.ceil((fj + sj) / 1024), math.ceil(hj / 1024), items)
    fields.prognose_speicher_kb = tostring(math.ceil((fj + sj) / 1024))
    return out, fields
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
A:On("AUCTION_POSTED", function(p)
    local ok, err = pcall(Fc.OnPosted, Fc, p)
    if not ok then A:ReportOnce("Forecast:Post", "Forecast:OnPosted", tostring(err)) end
end)
A:On("AUCTION_CANCELLED", function(c)
    if c and c.itemID then pcall(Fc.OnCancel, Fc, c.itemID) end
end)
A:On("SCAN_FINISHED", function(itemCount)
    -- nur nach echten Scans (Testroutine/Testmodus: Store() liefert nil)
    if not (A.TestRoutine and A.TestRoutine.running) then
        A:Job("forecast:hours", function() A:PCall(Fc.UpdateHours, Fc) end)     -- 0.65.110: eigene Portion
    end
end)

-- aus der Buchhaltung (Ledger Le:Add): Verkäufe und Käufe
function Fc:OnLedger(e)
    if not (e and e.itemID) then return end
    if e.kind == "sale" then
        local Le = A.Ledger
        local st = (Le and Le.SaleTime) and Le:SaleTime(e) or e.t
        self:OnSale(e.itemID, e.qty, e.amount, e.cut, st, e.src == "mail")
    elseif e.kind == "buy" then
        local src = e.src
        if src == "sniper" then
            local Sn = A.Sniper
            local lp = Sn and Sn.lastPurchase
            if lp and lp.key and Sn.extra and Sn.extra[lp.key] then src = "watcher" end
        end
        self:OnBuy(e.itemID, e.qty, e.amount, src, e.t, e.aid)
    end
end
