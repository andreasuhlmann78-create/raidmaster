-- BuffSentinel - Names.lua
-- Lernt die Namen von Talenten und Zaubern in der Sprache des Clients und teilt sie mit anderen
-- BuffSentinel-Nutzern.
--
-- Talente:  Zuordnung über die Position im Talentbaum (Baum:Reihe:Spalte) – in jeder Sprache gleich.
-- Zauber:   Zuordnung über die Spell-ID – in jeder Sprache gleich.
--
-- Zwei Wege zum Teilen:
--  1. Gilde + Gruppe/Raid (klein, vertraut): beim Login und bei neuen Mitgliedern wird die ganze
--     Liste ausgetauscht.
--  2. Server-Sync über den versteckten Kanal "BuffSentinelSync" (alle Nutzer derselben Fraktion auf
--     dem Server): hier wird nur gefragt, was fehlt. Es antwortet nur einer – wer eine Antwort von
--     jemand anderem sieht, schweigt. Neues Wissen wird genau einmal verteilt.
--
-- Nachrichten:  T;KLASSE;Baum:Reihe:Spalte;Name   Talent-Zuordnung
--               S;SpellID;Name                    Zauber-/Aura-Zuordnung
--               Q;T;KLASSE;Name / Q;S;Name        Frage nach einer fehlenden Zuordnung
--               R                                 (nur Gilde/Gruppe) bitte ganze Liste schicken

local ADDON, BS = ...
local API = BS.API

local PREFIX       = "BuffSentinel"
local SYNC_CHANNEL = "BuffSentinelSync"
local SEP          = ";"
local POS_PAT      = "^%d+:%d+:%d+$"
local GROUP_PER_PUMP = 3     -- Gilde/Gruppe: bis 3 Nachrichten pro 0,5 s
local SYNC_EVERY     = 2     -- Server-Kanal: 1 Nachricht pro Sekunde (jeder 2. Takt)
local SYNC_QUEUE_MAX = 40
local QUERY_REPEAT   = 600   -- dieselbe Frage höchstens alle 10 Minuten

local qGroup, qSync = {}, {}
local pending = {}           -- geplante Antworten im Server-Kanal (werden unterdrückt, wenn jemand schneller ist)
local queried = {}           -- Zeitpunkt der letzten Frage pro Name
local lastFullShare, lastRequest, lastGroupSize, pumpTick = 0, 0, 0, 0

local function After(sec, fn)
    if C_Timer and C_Timer.After then C_Timer.After(sec, fn) else fn() end
end

-- Testroutine: solange GetTime() < BS.testCommUntil wird nichts gesendet und kein Kanal betreten –
-- Nachrichten landen nur in BS.testSink (wird nie in Berichte übernommen).
local function TestComm()
    return type(BS.testCommUntil) == "number" and GetTime() < BS.testCommUntil
end
BS.TestCommActive = TestComm

local function SinkAdd(msg, scope)
    if type(msg) ~= "string" or #msg > 250 then return end
    BS.testSink = BS.testSink or {}
    for _, m in ipairs(BS.testSink) do
        if m.msg == msg and m.scope == scope then return end
    end
    tinsert(BS.testSink, { msg = msg, scope = scope })
end

------------------------------------------------------------------------
-- Index: welche englischen Namen kommen in den Klassendaten vor?
------------------------------------------------------------------------
local function AddStrings(set, v)
    if type(v) == "string" then
        set[v] = true
    elseif type(v) == "table" then
        for _, x in ipairs(v) do AddStrings(set, x) end
    end
end

function BS:BuildNameIndex()
    local spells, talents, lists, classSpells = {}, {}, {}, {}
    for class, data in pairs(self.ClassData) do
        talents[class], lists[class], classSpells[class] = {}, {}, {}
        local seen = {}
        local function addList(list, what)
            if not list or #list == 0 then return end
            for _, n in ipairs(list) do talents[class][n] = true end
            if not seen[list[1]] then
                seen[list[1]] = true
                tinsert(lists[class], { names = list, what = what })
            end
        end
        for _, d in ipairs(data.entries) do
            -- nur Einträge, die es in der laufenden WoW-Version gibt (sonst tauchen z. B. WotLK- oder
            -- Forever-Talente in TBC als "noch unbekannt" auf)
            if self:EntryAvailable(d) then
                for _, v in ipairs({ d.spell or false, d.groupSpell or false, d.procAuras or false, d.auras or false }) do
                    if v then AddStrings(spells, v); AddStrings(classSpells[class], v) end
                end
                if d.spellBySpec then
                    for _, v in pairs(d.spellBySpec) do AddStrings(spells, v); AddStrings(classSpells[class], v) end
                end
                addList(d.talents, "Talent")
                addList(d.enableIfTalent, "Talent")
                if self.isForever then addList(d.enableIfTalentForever, "Talent") end
                -- Fähigkeiten mit Namen statt ID sind meist Talent-Fähigkeiten (z. B. Forever-Neuheiten)
                if type(d.spell) == "string" then addList({ d.spell }, "Fähigkeit") end
            end
        end
    end
    self.nameIndex = { spells = spells, talents = talents, lists = lists, classSpells = classSpells }
end

function BS:InitNames()
    self:BuildNameIndex()
    local reg = (API.C_ChatInfo and API.C_ChatInfo.RegisterAddonMessagePrefix) or API.RegisterAddonMessagePrefix
    if reg then pcall(reg, PREFIX) end
    -- Gilde/Gruppe: kurz nach dem Login austauschen
    After(12, function() BS:RequestNames() end)
    -- Server-Kanal erst später betreten, damit Allgemein/Handel ihre gewohnten Kanalnummern behalten
    After(30, function() BS:JoinSync() end)
end

------------------------------------------------------------------------
-- Nachschlagen
------------------------------------------------------------------------
local function Learned()
    return BS.gdb and BS.gdb.learned
end

-- Lokaler Talentname für einen (englischen) Namen, oder nil
function BS:LocalTalentName(n)
    if not n then return nil end
    local t = self.talentByName[strlower(n)]
    if t then return t.name end
    local L = Learned()
    local m = L and L.talents[self.class] and L.talents[self.class][n]
    if m then
        local lt = self.talentByPos[m.pos]
        if lt then return lt.name end
    end
    return nil
end

-- Lokaler Name einer Talentliste + Herkunft ("direkt", "gelernt", "manuell") oder nil
function BS:ResolveTalentList(list)
    if not list then return nil end
    for _, n in ipairs(list) do
        local t = self.talentByName[strlower(n)]
        if t then return t.name, "direkt", t.pos end
    end
    local L = Learned()
    local map = L and L.talents[self.class]
    if map then
        for _, n in ipairs(list) do
            local m = map[n]
            if m and self.talentByPos[m.pos] then
                return self.talentByPos[m.pos].name, (m.src == "manual" and "manuell" or "gelernt"), m.pos, m.from
            end
        end
    end
    return nil
end

-- Lokaler Zaubername für einen (englischen) Namen, oder nil
function BS:LocalSpellName(n)
    if type(n) ~= "string" then return nil end
    local name = BS.SpellInfo(n)
    if name then return name end
    local L = Learned()
    local m = L and L.spells[n]
    if m and m.id then
        local ln = BS.SpellInfo(m.id)
        if ln then return ln end
    end
    -- Talent-Fähigkeit: Fähigkeit heisst meist wie das Talent
    local tn = self.LocalTalentName and self:LocalTalentName(n)
    if tn and tn ~= n then return tn end
    return nil
end

------------------------------------------------------------------------
-- Speichern
------------------------------------------------------------------------
local function StoreTalent(class, name, pos, src, from)
    local L = Learned()
    L.talents[class] = L.talents[class] or {}
    local old = L.talents[class][name]
    if old and old.pos == pos then return false end
    if old and src == "net" then return false end              -- Netz überschreibt nichts Bestehendes
    if old and old.src == "manual" and src ~= "manual" then return false end
    L.talents[class][name] = { pos = pos, src = src, from = from }
    return true
end

local function StoreSpell(name, id, src, from)
    local L = Learned()
    local old = L.spells[name]
    if old and old.id == id then return false end
    if old and src == "net" then return false end
    L.spells[name] = { id = id, src = src, from = from }
    return true
end

local function TalentMsg(class, pos, name) return table.concat({ "T", class, pos, name }, SEP) end
local function SpellMsg(id, name) return table.concat({ "S", tostring(id), name }, SEP) end

------------------------------------------------------------------------
-- Warteschlangen und Senden
------------------------------------------------------------------------
local function Enqueue(q, msg, max)
    if #msg > 250 then return end
    for _, m in ipairs(q) do
        if m == msg then return end
    end
    if max and #q >= max then return end
    tinsert(q, msg)
end

local function Send(msg, channel, target)
    if TestComm() then SinkAdd(msg, channel) return end
    local f = (API.C_ChatInfo and API.C_ChatInfo.SendAddonMessage) or API.SendAddonMessage
    if f then pcall(f, PREFIX, msg, channel, target) end
end

local function GroupChannels()
    local ch = {}
    if IsInGuild and IsInGuild() then tinsert(ch, "GUILD") end
    if IsInRaid and IsInRaid() then
        tinsert(ch, "RAID")
    elseif (GetNumSubgroupMembers and GetNumSubgroupMembers() or 0) > 0 then
        tinsert(ch, "PARTY")
    end
    return ch
end

local function SyncChannelId()
    if not API.GetChannelName then return nil end
    local id = API.GetChannelName(SYNC_CHANNEL)
    if id and id > 0 then return id end
    return nil
end

-- scope: "group" = Gilde/Gruppe, "sync" = Server-Kanal, "both" = beides
function BS:SendName(msg, scope)
    if not self.gdb then return end
    local test = TestComm()
    if (scope == "group" or scope == "both") and self.gdb.shareNames then
        if test then SinkAdd(msg, "group") else Enqueue(qGroup, msg) end
    end
    if (scope == "sync" or scope == "both") and self.gdb.shareServer then
        if test then SinkAdd(msg, "sync") else Enqueue(qSync, msg, SYNC_QUEUE_MAX) end
    end
end

-- Testroutine: Warteschlangen und geplante Antworten leeren (die Tabellen sind lokal in dieser Datei)
function BS:CommReset()
    wipe(qGroup); wipe(qSync); wipe(pending)
end

-- Testroutine: Länge der Warteschlangen (Grenzen prüfen)
function BS:CommQueueSizes()
    return #qGroup, #qSync
end

-- Alle 0,5 s aufgerufen (Core.lua)
function BS:PumpComm()
    pumpTick = pumpTick + 1
    if #qGroup > 0 then
        local ch = GroupChannels()
        if #ch == 0 then
            wipe(qGroup)
        else
            for _ = 1, GROUP_PER_PUMP do
                local msg = tremove(qGroup, 1)
                if not msg then break end
                for _, c in ipairs(ch) do Send(msg, c) end
            end
        end
    end
    if #qSync > 0 and pumpTick % SYNC_EVERY == 0 then
        local id = SyncChannelId()
        if id and self.syncReady then
            local msg = tremove(qSync, 1)
            if msg then Send(msg, "CHANNEL", id) end
        end
    end
end

------------------------------------------------------------------------
-- Server-Kanal
------------------------------------------------------------------------
local function HideSyncFromChat()
    local remove = API.ChatFrame_RemoveChannel
    if not remove then return end
    for i = 1, (NUM_CHAT_WINDOWS or 10) do
        local cf = _G["ChatFrame" .. i]
        if cf then pcall(remove, cf, SYNC_CHANNEL) end
    end
end

-- Zustand des Server-Kanals für die Anzeige: "waiting" (vor dem ersten Versuch), "connecting", "ready", "failed"
BS.syncState = "waiting"
local SYNC_TRIES, SYNC_RETRY = 8, 10

local function SyncConnected()
    if BS.syncReady then return end
    BS.syncReady = true
    BS.syncState = "ready"
    HideSyncFromChat()
    BS:QueryUnknown()
    if BS.optionsFrame and BS.optionsFrame:IsShown() then BS:RefreshOptions() end
end

local function TryJoin()
    if TestComm() then return end
    if API.JoinTemporaryChannel then
        pcall(API.JoinTemporaryChannel, SYNC_CHANNEL)
    elseif API.JoinChannelByName then
        pcall(API.JoinChannelByName, SYNC_CHANNEL)
    end
end

-- Beitritt mit Wiederholungen: Kanäle brauchen beim Einloggen teils länger als ein paar Sekunden
function BS:JoinSync(attempt)
    if TestComm() then return end
    if not self.gdb or not self.gdb.shareServer or self.syncReady then return end
    attempt = attempt or 1
    self.syncState = "connecting"
    if not SyncChannelId() and (attempt == 1 or attempt % 3 == 0) then TryJoin() end
    After(attempt == 1 and 3 or SYNC_RETRY, function()
        if BS.syncReady or not BS.gdb.shareServer then return end
        if SyncChannelId() then
            SyncConnected()
        elseif attempt < SYNC_TRIES then
            BS:JoinSync(attempt + 1)
        else
            BS.syncState = "failed"
            if BS.optionsFrame and BS.optionsFrame:IsShown() then BS:RefreshOptions() end
        end
    end)
end

-- Rückmeldung des Spiels beim Kanalbeitritt
function BS:CHAT_MSG_CHANNEL_NOTICE(noticeType, _, _, _, _, _, _, _, channelBaseName)
    -- geschützte Argumente (Forever/Retail im Kampf): nicht vergleichen, nicht zerlegen
    if BS.IsSecret(noticeType) or BS.IsSecret(channelBaseName) then return end
    if type(channelBaseName) ~= "string" or strlower(channelBaseName) ~= strlower(SYNC_CHANNEL) then return end
    if noticeType == "YOU_JOINED" or noticeType == "YOU_CHANGED" then
        SyncConnected()
    elseif noticeType == "YOU_LEFT" then
        self.syncReady = false
        self.syncState = self.gdb and self.gdb.shareServer and "connecting" or "waiting"
    end
end

function BS:SyncStatusText()
    if not self.gdb or not self.gdb.shareServer then return "|cff888888aus|r" end
    local st = self.syncReady and "ready" or self.syncState
    if st == "ready" then return "|cff66dd77verbunden|r" end
    if st == "failed" then return "|cffff5555nicht verfügbar (Kanal-Beitritt fehlgeschlagen)|r" end
    if st == "waiting" then return "|cffffd040startet ca. 30 s nach dem Einloggen|r" end
    return "|cffffd040verbindet …|r"
end

function BS:LeaveSync()
    if TestComm() then return end
    self.syncReady = false
    self.syncState = "waiting"
    wipe(qSync)
    if SyncChannelId() and API.LeaveChannelByName then pcall(API.LeaveChannelByName, SYNC_CHANNEL) end
end

function BS:SetShareServer(on)
    self.gdb.shareServer = on and true or false
    if on then self:JoinSync() else self:LeaveSync() end
end

-- Fragt im Server-Kanal nach allen Namen der eigenen Klasse, die noch fehlen
function BS:QueryUnknown()
    if not self.syncReady or not self.nameIndex or not self.talentsReadable then return end
    local now, class = GetTime(), self.class
    local function ask(key, msg)
        if queried[key] and now - queried[key] < QUERY_REPEAT then return end
        queried[key] = now
        Enqueue(qSync, msg, SYNC_QUEUE_MAX)
    end
    for _, item in ipairs(self.nameIndex.lists[class] or {}) do
        if not self:ResolveTalentList(item.names) then
            local en = item.names[1]
            ask("T:" .. class .. ":" .. en, table.concat({ "Q", "T", class, en }, SEP))
        end
    end
    for n in pairs(self.nameIndex.classSpells[class] or {}) do
        local L = Learned()
        if not BS.SpellInfo(n) and not (L.spells[n]) then
            ask("S:" .. n, table.concat({ "Q", "S", n }, SEP))
        end
    end
end

------------------------------------------------------------------------
-- Lernen aus dem eigenen Client (neues Wissen -> überall genau einmal verteilen)
------------------------------------------------------------------------
function BS:LearnFromClient()
    if not self.nameIndex or not self.gdb then return end
    local class = self.class
    for n in pairs(self.nameIndex.talents[class] or {}) do
        local t = self.talentByName[strlower(n)]
        if t and StoreTalent(class, n, t.pos, "client") then
            self:SendName(TalentMsg(class, t.pos, n), "both")
        end
    end
    for n in pairs(self.nameIndex.spells) do
        local name, _, id = BS.SpellInfo(n)
        if name and type(id) == "number" and StoreSpell(n, id, "client") then
            self:SendName(SpellMsg(id, n), "both")
        end
    end
    if self.syncReady then self:QueryUnknown() end
end

-- Aus Display.ScanPlayerAuras: Proc-Buffs wie "Hot Streak" mit ihrer ID lernen
function BS:LearnAura(name, id)
    if not self.nameIndex or type(id) ~= "number" then return end
    if self.nameIndex.spells[name] and StoreSpell(name, id, "client") then
        self:SendName(SpellMsg(id, name), "both")
    end
end

------------------------------------------------------------------------
-- Manuelle Zuordnung (Optionsfenster)
------------------------------------------------------------------------
function BS:AssignTalent(name, pos)
    if not self.talentByPos[pos] then return end
    StoreTalent(self.class, name, pos, "manual")
    self:SendName(TalentMsg(self.class, pos, name), "both")
    BS.Print(string.format("Zugeordnet: %s = |cffffffff%s|r – wird mit allen BuffSentinel-Nutzern geteilt.",
        name, self.talentByPos[pos].name))
    self.assigning = nil
    self:FullScan()
end

function BS:UnassignTalent(name)
    local L = Learned()
    if L.talents[self.class] then L.talents[self.class][name] = nil end
    self:FullScan()
end

function BS:CountLearned()
    local L, t, s = Learned(), 0, 0
    if not L then return 0, 0 end
    for _, map in pairs(L.talents) do for _ in pairs(map) do t = t + 1 end end
    for _ in pairs(L.spells) do s = s + 1 end
    return t, s
end

------------------------------------------------------------------------
-- Gilde/Gruppe: ganze Liste austauschen
------------------------------------------------------------------------
function BS:ShareAll()
    local L = Learned()
    if not L then return end
    lastFullShare = GetTime()
    for class, map in pairs(L.talents) do
        for name, m in pairs(map) do self:SendName(TalentMsg(class, m.pos, name), "group") end
    end
    for name, m in pairs(L.spells) do self:SendName(SpellMsg(m.id, name), "group") end
    if self.AutoShareAll then self:AutoShareAll() end
end

function BS:RequestNames()
    if not self.gdb or not self.gdb.shareNames then return end
    lastRequest = GetTime()
    self:SendName("R", "group")
    self:ShareAll()
end

function BS:OnGroupChanged()
    local n = (GetNumGroupMembers and GetNumGroupMembers()) or (GetNumSubgroupMembers and GetNumSubgroupMembers()) or 0
    if n > lastGroupSize and GetTime() - lastRequest > 120 then self:RequestNames() end
    lastGroupSize = n
end

------------------------------------------------------------------------
-- Empfangen
------------------------------------------------------------------------
local function IsMe(sender)
    if type(sender) ~= "string" then return true end
    local me = UnitName("player")
    local realm = (GetRealmName() or ""):gsub("%s", "")
    return sender == me or sender == (me .. "-" .. realm)
end

local function ShortName(sender)
    return (sender and sender:match("^([^%-]+)")) or "?"
end

-- Antwort auf eine Frage: nach zufälliger Wartezeit senden, ausser jemand war schneller
local function ScheduleAnswer(msg, scope)
    if scope == "group" then
        BS:SendName(msg, "group")
        return
    end
    if pending[msg] then return end
    pending[msg] = true
    After(1 + math.random() * 9, function()
        if pending[msg] then
            pending[msg] = nil
            BS:SendName(msg, "sync")
        end
    end)
end

local function AnswerQuery(what, a, b, scope)
    local L = Learned()
    if what == "T" then
        local class, name = a, b
        local m = class and name and L.talents[class] and L.talents[class][name]
        if m then ScheduleAnswer(TalentMsg(class, m.pos, name), scope) end
    elseif what == "S" then
        local m = a and L.spells[a]
        if m then ScheduleAnswer(SpellMsg(m.id, a), scope) end
    end
end

function BS:CHAT_MSG_ADDON(prefix, msg, channel, sender)
    -- geschützte Argumente (Forever/Retail im Kampf): nicht vergleichen, nicht als Schlüssel benutzen
    if BS.IsSecret(prefix) or BS.IsSecret(msg) or BS.IsSecret(channel) or BS.IsSecret(sender) then return end
    if prefix ~= PREFIX or not self.nameIndex or not self.gdb then return end
    if type(msg) ~= "string" then return end
    if IsMe(sender) then return end
    local fromSync = (channel == "CHANNEL")
    if fromSync and not self.gdb.shareServer then return end
    if not fromSync and not self.gdb.shareNames then return end

    -- Jemand hat diese Antwort/Frage schon gesendet -> eigene geplante oder wartende Nachricht verwerfen
    pending[msg] = nil
    for i = #qSync, 1, -1 do
        if qSync[i] == msg then tremove(qSync, i) end
    end

    local kind, a, b, c, d, e = strsplit(SEP, msg)
    local scope = fromSync and "sync" or "group"
    local changed = false

    if kind == "R" and not fromSync then
        if GetTime() - lastFullShare > 60 then
            lastFullShare = GetTime()
            After(2 + math.random() * 6, function() BS:ShareAll() end)
        end

    elseif kind == "A" then
        -- automatisch gelernter Proc / Fähigkeit eines anderen Nutzers (AutoLearn.lua)
        if self.OnAutoShare then self:OnAutoShare(a, b, c, d, e, ShortName(sender)) end

    elseif kind == "Q" then
        AnswerQuery(a, b, c, scope)

    elseif kind == "T" then
        local class, pos, name = a, b, c
        if class and pos and name and pos:match(POS_PAT)
           and self.nameIndex.talents[class] and self.nameIndex.talents[class][name] then
            local before = (class == self.class) and self:LocalTalentName(name) or nil
            if StoreTalent(class, name, pos, "net", ShortName(sender)) and class == self.class then
                local after = self:LocalTalentName(name)
                if after and not before then
                    changed = true
                    if after ~= name then
                        BS.Print(string.format("Talentname gelernt: %s = |cffffffff%s|r (von %s)", name, after, ShortName(sender)))
                    end
                end
            end
        end

    elseif kind == "S" then
        local id, name = tonumber(a), b
        if id and name and self.nameIndex.spells[name] and BS.SpellInfo(id) then
            local before = self:LocalSpellName(name)
            if StoreSpell(name, id, "net", ShortName(sender)) then
                local after = self:LocalSpellName(name)
                if after and after ~= before then
                    changed = true
                    if after ~= name then
                        BS.Print(string.format("Zaubername gelernt: %s = |cffffffff%s|r (von %s)", name, after, ShortName(sender)))
                    end
                end
            end
        end
    end

    if changed then self:FullScanSoon() end
end
