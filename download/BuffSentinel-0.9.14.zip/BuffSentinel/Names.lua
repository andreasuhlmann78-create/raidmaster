-- BuffSentinel - Names.lua
-- Lernt die Namen von Talenten und Zaubern in der Sprache des Clients und teilt sie mit anderen
-- BuffSentinel-Nutzern.
--
-- Talente:  Zuordnung über die Position im Talentbaum (Baum:Reihe:Spalte) – in jeder Sprache gleich.
-- Zauber:   Zuordnung über die Spell-ID – in jeder Sprache gleich.
--
-- Zwei Wege zum Teilen (beide über die gemeinsame Datei GoldSentinelSync, Kennung "BuffSentinel"):
--  1. Gilde + Gruppe/Raid (klein, vertraut): beim Login und bei neuen Mitgliedern wird die ganze
--     Liste ausgetauscht.
--  2. Flüster-Netz von GoldSentinelSync 2 (Spieler ausserhalb von Gilde und Gruppe): hier wird nur
--     gefragt, was fehlt. Es antwortet nur einer – wer eine Antwort von jemand anderem sieht, schweigt.
--     Früher lief das über den Kanal "BuffSentinelSync"; in WoW Forever kommen Addon-Nachrichten in
--     eigenen Kanälen nicht an (shared/wissen/kommunikation-forever.md im raidmaster-Repo).
--
-- Nachrichten:  T;KLASSE;Baum:Reihe:Spalte;Name   Talent-Zuordnung
--               S;SpellID;Name                    Zauber-/Aura-Zuordnung
--               Q;T;KLASSE;Name / Q;S;Name        Frage nach einer fehlenden Zuordnung
--               R                                 (nur Gilde/Gruppe) bitte ganze Liste schicken

local ADDON, BS = ...
local L = BS.L
local API = BS.API

local PREFIX       = "BuffSentinel"       -- Kennung bleibt: alte Versionen anderer Spieler verstehen uns weiter
local OLD_CHANNEL  = "BuffSentinelSync"   -- früherer eigener Kanal: nur noch einmal verlassen
local SEP          = ";"
local POS_PAT      = "^%d+:%d+:%d+$"
local QUERY_REPEAT   = 600   -- dieselbe Frage höchstens alle 10 Minuten
local QUERY_MAX      = 10    -- höchstens so viele Fragen auf einmal

local pending = {}           -- geplante Antworten aus dem Netz (werden unterdrückt, wenn jemand schneller ist)
local queried = {}           -- Zeitpunkt der letzten Frage pro Name
local lastFullShare, lastRequest, lastGroupSize = 0, 0, 0

local function After(sec, fn)
    if C_Timer and C_Timer.After then C_Timer.After(sec, fn) else fn() end
end

-- Testroutine: solange GetTime() < BS.testCommUntil wird nichts gesendet –
-- Nachrichten landen nur in BS.testSink (wird nie in Berichte übernommen).
local function TestComm()
    return type(BS.testCommUntil) == "number" and GetTime() < BS.testCommUntil
end
BS.TestCommActive = TestComm

local function SinkAdd(msg, scope)
    if type(msg) ~= "string" or #msg > 250 then return end
    BS.testSink = BS.testSink or {}
    for _, m in ipairs(BS.testSink) do
        if m.msg == msg and m.scope == scope then return end
    end
    tinsert(BS.testSink, { msg = msg, scope = scope })
end

------------------------------------------------------------------------
-- Index: welche englischen Namen kommen in den Klassendaten vor?
------------------------------------------------------------------------
local function AddStrings(set, v)
    if type(v) == "string" then
        set[v] = true
    elseif type(v) == "table" then
        for _, x in ipairs(v) do AddStrings(set, x) end
    end
end

function BS:BuildNameIndex()
    local spells, talents, lists, classSpells = {}, {}, {}, {}
    for class, data in pairs(self.ClassData) do
        talents[class], lists[class], classSpells[class] = {}, {}, {}
        local seen = {}
        local function addList(list, what)
            if not list or #list == 0 then return end
            for _, n in ipairs(list) do talents[class][n] = true end
            if not seen[list[1]] then
                seen[list[1]] = true
                tinsert(lists[class], { names = list, what = what })
            end
        end
        for _, d in ipairs(data.entries) do
            -- nur Einträge, die es in der laufenden WoW-Version gibt (sonst tauchen z. B. WotLK- oder
            -- Forever-Talente in TBC als "noch unbekannt" auf)
            if self:EntryAvailable(d) then
                for _, v in ipairs({ d.spell or false, d.groupSpell or false, d.procAuras or false, d.auras or false }) do
                    if v then AddStrings(spells, v); AddStrings(classSpells[class], v) end
                end
                if d.spellBySpec then
                    for _, v in pairs(d.spellBySpec) do AddStrings(spells, v); AddStrings(classSpells[class], v) end
                end
                addList(d.talents, "Talent")
                addList(d.enableIfTalent, "Talent")
                if self.isForever then addList(d.enableIfTalentForever, "Talent") end
                -- Fähigkeiten mit Namen statt ID sind meist Talent-Fähigkeiten (z. B. Forever-Neuheiten)
                if type(d.spell) == "string" then addList({ d.spell }, L.ABILITY) end
            end
        end
    end
    self.nameIndex = { spells = spells, talents = talents, lists = lists, classSpells = classSpells }
end

function BS:InitNames()
    self:BuildNameIndex()
    BS.SyncEndpoint()                               -- meldet die Kennung an (GoldSentinelSync)
    local S = GoldSentinelSync
    if self.syncEP and self.gdb and self.syncEP.UseStorage then
        pcall(self.syncEP.UseStorage, self.syncEP, self.gdb)  -- bekannte Netz-Mitspieler über /reload (BuffSentinelDB.gsSync)
    end
    if BS.Diag and S then
        BS.Diag("SYNC", "Weg=GoldSentinelSync " .. tostring(S.VERSION) .. " (Gilde/Gruppe" ..
            ((self.gdb and self.gdb.shareServer) and "/Netz)" or ")"))
    end
    -- Gilde/Gruppe: kurz nach dem Login austauschen
    After(12, function() BS:RequestNames() end)
    -- früherer Kanal BuffSentinelSync: einmal verlassen (Kanalplatz frei), danach im Netz fehlende Namen erfragen
    After(30, function() BS:LeaveOldChannel(); BS:QueryUnknown() end)
end

------------------------------------------------------------------------
-- Nachschlagen
------------------------------------------------------------------------
local function Learned()
    return BS.gdb and BS.gdb.learned
end

-- Lokaler Talentname für einen (englischen) Namen, oder nil
function BS:LocalTalentName(n)
    if not n then return nil end
    local t = self.talentByName[strlower(n)]
    if t then return t.name end
    local LN = Learned()
    local m = LN and LN.talents[self.class] and LN.talents[self.class][n]
    if m then
        local lt = self.talentByPos[m.pos]
        if lt then return lt.name end
    end
    return nil
end

-- Lokaler Name einer Talentliste + Herkunft ("direkt", "gelernt", "manuell") oder nil
function BS:ResolveTalentList(list)
    if not list then return nil end
    for _, n in ipairs(list) do
        local t = self.talentByName[strlower(n)]
        if t then return t.name, "direkt", t.pos end
    end
    local LN = Learned()
    local map = LN and LN.talents[self.class]
    if map then
        for _, n in ipairs(list) do
            local m = map[n]
            if m and self.talentByPos[m.pos] then
                return self.talentByPos[m.pos].name, (m.src == "manual" and "manuell" or "gelernt"), m.pos, m.from
            end
        end
    end
    return nil
end

-- Lokaler Zaubername für einen (englischen) Namen, oder nil
function BS:LocalSpellName(n)
    if type(n) ~= "string" then return nil end
    local name = BS.SpellInfo(n)
    if name then return name end
    local LN = Learned()
    local m = LN and LN.spells[n]
    if m and m.id then
        local ln = BS.SpellInfo(m.id)
        if ln then return ln end
    end
    -- Talent-Fähigkeit: Fähigkeit heisst meist wie das Talent
    local tn = self.LocalTalentName and self:LocalTalentName(n)
    if tn and tn ~= n then return tn end
    return nil
end

------------------------------------------------------------------------
-- Speichern
------------------------------------------------------------------------
local function StoreTalent(class, name, pos, src, from)
    local LN = Learned()
    LN.talents[class] = LN.talents[class] or {}
    local old = LN.talents[class][name]
    if old and old.pos == pos then return false end
    if old and src == "net" then return false end              -- Netz überschreibt nichts Bestehendes
    if old and old.src == "manual" and src ~= "manual" then return false end
    LN.talents[class][name] = { pos = pos, src = src, from = from }
    return true
end

local function StoreSpell(name, id, src, from)
    local LN = Learned()
    local old = LN.spells[name]
    if old and old.id == id then return false end
    if old and src == "net" then return false end
    LN.spells[name] = { id = id, src = src, from = from }
    return true
end

local function TalentMsg(class, pos, name) return table.concat({ "T", class, pos, name }, SEP) end
local function SpellMsg(id, name) return table.concat({ "S", tostring(id), name }, SEP) end

------------------------------------------------------------------------
-- Senden und Empfangen über GoldSentinelSync (gemeinsame Datei, Version 2)
------------------------------------------------------------------------
-- Gilde und Gruppe/Raid wie bisher; "Server" heisst jetzt: zusätzlich ins Flüster-Netz von GoldSentinelSync 2
-- (Spieler mit einem GoldSentinel-Addon ausserhalb von Gilde und Gruppe). Eigene Kanäle gehen in WoW Forever nicht
-- (Server: NOT_ALLOWED_IN_CHANNEL) und belegen Kanalplätze – BuffSentinel tritt keinem mehr bei.
-- Keine eigene Warteschlange und kein eigener Takt mehr: Drossel, Dubletten und Wege übernimmt GoldSentinelSync.
local function Endpoint()
    if BS.syncEP then return BS.syncEP end
    local S = GoldSentinelSync
    if type(S) ~= "table" or type(S.Register) ~= "function" then return nil end
    local ok, ep = pcall(S.Register, "BuffSentinel", PREFIX, BS.version)
    if not ok or not ep then return nil end
    BS.syncEP = ep
    ep:OnMessage(function(text, sender, dist)
        local okh, err = pcall(BS.CHAT_MSG_ADDON, BS, PREFIX, text, dist, sender)
        if not okh and BS.CountError then BS:CountError("Komm", err) end
    end)
    return ep
end
BS.SyncEndpoint = Endpoint

-- scope: "group" = Gilde/Gruppe, "sync" = auch ins Netz, "both" = beides
function BS:SendName(msg, scope)
    if not self.gdb or type(msg) ~= "string" then return end
    local wantGroup = (scope == "group" or scope == "both") and self.gdb.shareNames
    local wantNet = (scope == "sync" or scope == "both") and self.gdb.shareServer
    if not wantGroup and not wantNet then return end
    if TestComm() then
        if wantGroup then SinkAdd(msg, "group") end
        if wantNet then SinkAdd(msg, "sync") end
        return
    end
    local S = GoldSentinelSync
    if #msg > ((S and S.MAX_PAYLOAD) or 230) then return end
    local ep = Endpoint()
    if not ep then return end
    -- Netz nur für "sync"/"both" mit Server-Teilen an; reine Gilde/Gruppe nie ins Netz
    ep:Send(msg, { net = wantNet and true or false })
end

-- Testroutine: geplante Antworten leeren (Tabellen sind lokal in dieser Datei)
function BS:CommReset()
    wipe(pending)
end

-- Früherer eigener Kanal: einmal verlassen, falls noch betreten (gibt den Kanalplatz frei). Nie mehr beitreten.
function BS:LeaveOldChannel()
    if TestComm() then return false end
    if not API.GetChannelName or not API.LeaveChannelByName then return false end
    local id = API.GetChannelName(OLD_CHANNEL)
    if BS.IsSecret(id) or type(id) ~= "number" or id <= 0 then return false end
    pcall(API.LeaveChannelByName, OLD_CHANNEL)
    if BS.Diag then BS.Diag("SYNC", "alter Kanal verlassen") end
    return true
end

-- Anzeige im Optionsfenster: Mitspieler mit BuffSentinel (letzte Stunde) bzw. aus
function BS:SyncStatusText()
    if not self.gdb or not self.gdb.shareServer then return L.SYNC_STATUS_OFF end
    local ep = Endpoint()
    if not ep then return L.SYNC_STATUS_NONE end
    local ok, n = pcall(ep.Peers, ep, 3600)
    return string.format(L.SYNC_STATUS_PEERS, ok and tonumber(n) or 0)
end

function BS:SetShareServer(on)
    self.gdb.shareServer = on and true or false
end

-- alle 10 Minuten (Core.lua): Zähler ins Diagnose-Protokoll
function BS:SyncDiagTick()
    local ep = self.syncEP
    if not (ep and ep.Stats and BS.Diag) then return end
    local st = ep:Stats() or {}
    local dropped, parts = 0, {}
    for k, v in pairs(st.dropped or {}) do dropped = dropped + v; parts[#parts + 1] = k .. " " .. v end
    table.sort(parts)
    BS.Diag("SYNC", string.format("gesendet %d, empfangen %d, verworfen %d%s", tonumber(st.sent) or 0,
        tonumber(st.received) or 0, dropped, #parts > 0 and (" (" .. table.concat(parts, ", ") .. ")") or ""))
end

-- /bsen sync test: wer antwortet?
function BS:SyncTest()
    local S = GoldSentinelSync
    if not (S and S.Ping and Endpoint()) then BS.Print(L.SYNC_TEST_NONE); return end
    BS.Print(L.SYNC_TEST_RUNNING)
    S.Ping("BuffSentinel", function(r)
        r = r or {}
        BS.Print(string.format(L.SYNC_TEST_RESULT, tonumber(r.total) or 0, tonumber(r.guild) or 0,
            tonumber(r.group) or 0, tonumber(r.whisper) or 0))
    end)
end

-- Fragt (Gilde/Gruppe und Netz) nach allen Namen der eigenen Klasse, die noch fehlen
function BS:QueryUnknown()
    if not self.nameIndex or not self.talentsReadable then return end
    local now, class = GetTime(), self.class
    local asked = 0
    local function ask(key, msg)
        -- höchstens QUERY_MAX Fragen je Aufruf (Netz: wenige Flüsternachrichten), dieselbe höchstens alle 10 Minuten
        if asked >= QUERY_MAX then return end
        if queried[key] and now - queried[key] < QUERY_REPEAT then return end
        queried[key] = now
        asked = asked + 1
        self:SendName(msg, "both")
    end
    for _, item in ipairs(self.nameIndex.lists[class] or {}) do
        if not self:ResolveTalentList(item.names) then
            local en = item.names[1]
            ask("T:" .. class .. ":" .. en, table.concat({ "Q", "T", class, en }, SEP))
        end
    end
    for n in pairs(self.nameIndex.classSpells[class] or {}) do
        local LN = Learned()
        if not BS.SpellInfo(n) and not (LN.spells[n]) then
            ask("S:" .. n, table.concat({ "Q", "S", n }, SEP))
        end
    end
end

------------------------------------------------------------------------
-- Lernen aus dem eigenen Client (neues Wissen -> überall genau einmal verteilen)
------------------------------------------------------------------------
function BS:LearnFromClient()
    if not self.nameIndex or not self.gdb then return end
    local class = self.class
    for n in pairs(self.nameIndex.talents[class] or {}) do
        local t = self.talentByName[strlower(n)]
        if t and StoreTalent(class, n, t.pos, "client") then
            self:SendName(TalentMsg(class, t.pos, n), "both")
        end
    end
    for n in pairs(self.nameIndex.spells) do
        local name, _, id = BS.SpellInfo(n)
        if name and type(id) == "number" and StoreSpell(n, id, "client") then
            self:SendName(SpellMsg(id, n), "both")
        end
    end
    self:QueryUnknown()
end

-- Aus Display.ScanPlayerAuras: Proc-Buffs wie "Hot Streak" mit ihrer ID lernen
function BS:LearnAura(name, id)
    if not self.nameIndex or type(id) ~= "number" then return end
    if self.nameIndex.spells[name] and StoreSpell(name, id, "client") then
        self:SendName(SpellMsg(id, name), "both")
    end
end

------------------------------------------------------------------------
-- Manuelle Zuordnung (Optionsfenster)
------------------------------------------------------------------------
function BS:AssignTalent(name, pos)
    if not self.talentByPos[pos] then return end
    StoreTalent(self.class, name, pos, "manual")
    self:SendName(TalentMsg(self.class, pos, name), "both")
    BS.Print(string.format(L.ASSIGNED_SHARED_WITH_ALL_BUFFSENTINEL,
        name, self.talentByPos[pos].name))
    self.assigning = nil
    self:FullScan()
end

function BS:UnassignTalent(name)
    local LN = Learned()
    if LN.talents[self.class] then LN.talents[self.class][name] = nil end
    self:FullScan()
end

function BS:CountLearned()
    local LN, t, s = Learned(), 0, 0
    if not LN then return 0, 0 end
    for _, map in pairs(LN.talents) do for _ in pairs(map) do t = t + 1 end end
    for _ in pairs(LN.spells) do s = s + 1 end
    return t, s
end

------------------------------------------------------------------------
-- Gilde/Gruppe: ganze Liste austauschen
------------------------------------------------------------------------
function BS:ShareAll()
    local LN = Learned()
    if not LN then return end
    lastFullShare = GetTime()
    for class, map in pairs(LN.talents) do
        for name, m in pairs(map) do self:SendName(TalentMsg(class, m.pos, name), "group") end
    end
    for name, m in pairs(LN.spells) do self:SendName(SpellMsg(m.id, name), "group") end
    if self.AutoShareAll then self:AutoShareAll() end
end

function BS:RequestNames()
    if not self.gdb or not self.gdb.shareNames then return end
    lastRequest = GetTime()
    self:SendName("R", "group")
    self:ShareAll()
end

function BS:OnGroupChanged()
    local n = (GetNumGroupMembers and GetNumGroupMembers()) or (GetNumSubgroupMembers and GetNumSubgroupMembers()) or 0
    if n > lastGroupSize and GetTime() - lastRequest > 120 then self:RequestNames() end
    lastGroupSize = n
end

------------------------------------------------------------------------
-- Empfangen
------------------------------------------------------------------------
-- sender kann nil sein (geschützt/unbekannt) – dann ist es nicht der eigene Charakter (GoldSentinelSync filtert
-- eigene Nachrichten schon über die Kennung)
local function IsMe(sender)
    if type(sender) ~= "string" then return false end
    local me = UnitName("player")
    if BS.IsSecret(me) or type(me) ~= "string" then return false end
    local realm = (GetRealmName() or ""):gsub("%s", "")
    return sender == me or sender == (me .. "-" .. realm)
end

-- Name für die Chat-Meldung: nur bei Gilde/Gruppe; aus dem Netz (Flüstern) nie ein Spielername
local function ShortName(sender, fromNet)
    if fromNet or type(sender) ~= "string" then return nil end
    return sender:match("^([^%-]+)") or sender
end

-- Antwort auf eine Frage: nach zufälliger Wartezeit senden, ausser jemand war schneller
local function ScheduleAnswer(msg, scope)
    if scope == "group" then
        BS:SendName(msg, "group")
        return
    end
    if pending[msg] then return end
    pending[msg] = true
    After(1 + math.random() * 9, function()
        if pending[msg] then
            pending[msg] = nil
            BS:SendName(msg, "sync")
        end
    end)
end

local function AnswerQuery(what, a, b, scope)
    local LN = Learned()
    if what == "T" then
        local class, name = a, b
        local m = class and name and LN.talents[class] and LN.talents[class][name]
        if m then ScheduleAnswer(TalentMsg(class, m.pos, name), scope) end
    elseif what == "S" then
        local m = a and LN.spells[a]
        if m then ScheduleAnswer(SpellMsg(m.id, a), scope) end
    end
end

function BS:CHAT_MSG_ADDON(prefix, msg, channel, sender)
    -- geschützte Argumente (Forever/Retail im Kampf): nicht vergleichen, nicht als Schlüssel benutzen
    if BS.IsSecret(prefix) or BS.IsSecret(msg) or BS.IsSecret(channel) or BS.IsSecret(sender) then return end
    if prefix ~= PREFIX or not self.nameIndex or not self.gdb then return end
    if type(msg) ~= "string" then return end
    if IsMe(sender) then return end
    -- Netz (Flüstern) oder alter Kanal einer alten Version -> wie früher "Server"
    local fromSync = (channel == "WHISPER" or channel == "CHANNEL")
    if fromSync and not self.gdb.shareServer then return end
    if not fromSync and not self.gdb.shareNames then return end

    -- Jemand hat diese Antwort/Frage schon gesendet -> eigene geplante Nachricht verwerfen
    pending[msg] = nil
    local from = ShortName(sender, fromSync)

    local kind, a, b, c, d, e = strsplit(SEP, msg)
    local scope = fromSync and "sync" or "group"
    local changed = false

    if kind == "R" and not fromSync then
        if GetTime() - lastFullShare > 60 then
            lastFullShare = GetTime()
            After(2 + math.random() * 6, function() BS:ShareAll() end)
        end

    elseif kind == "A" then
        -- automatisch gelernter Proc / Fähigkeit eines anderen Nutzers (AutoLearn.lua)
        if self.OnAutoShare then self:OnAutoShare(a, b, c, d, e, from) end

    elseif kind == "Q" then
        AnswerQuery(a, b, c, scope)

    elseif kind == "T" then
        local class, pos, name = a, b, c
        if class and pos and name and pos:match(POS_PAT)
           and self.nameIndex.talents[class] and self.nameIndex.talents[class][name] then
            local before = (class == self.class) and self:LocalTalentName(name) or nil
            if StoreTalent(class, name, pos, "net", from) and class == self.class then
                local after = self:LocalTalentName(name)
                if after and not before then
                    changed = true
                    if after ~= name then
                        BS.Print(string.format(L.TALENT_NAME_LEARNED_FROM, name, after, from or L.ANOTHER_PLAYER))
                    end
                end
            end
        end

    elseif kind == "S" then
        local id, name = tonumber(a), b
        if id and name and self.nameIndex.spells[name] and BS.SpellInfo(id) then
            local before = self:LocalSpellName(name)
            if StoreSpell(name, id, "net", from) then
                local after = self:LocalSpellName(name)
                if after and after ~= before then
                    changed = true
                    if after ~= name then
                        BS.Print(string.format(L.SPELL_NAME_LEARNED_FROM, name, after, from or L.ANOTHER_PLAYER))
                    end
                end
            end
        end
    end

    if changed then self:FullScanSoon() end
end
