# BuffSentinel – Changelog

## 0.9.14
- **Sync without own chat channel (WoW Forever):** In WoW Forever addon messages in own chat channels never arrive (server: NOT_ALLOWED_IN_CHANNEL). BuffSentinel no longer joins the channel "BuffSentinelSync" and leaves it once if it is still joined (frees one of your 10 channel slots).
- New shared file **GoldSentinelSync 2** (unchanged copy): name sharing runs over guild, group/raid and the whisper network of the GoldSentinel addons, in all game versions (Era, TBC, Mists, Retail, Forever). The message prefix "BuffSentinel" stays, so older BuffSentinel versions of other players are still understood. No own send queue or timer any more.
- What goes into the whisper network (option "Also exchange via the whisper network"): talent and spell name mappings you learned, questions for missing names and their answers (at most 10 questions at once), and procs/abilities learned automatically. Guild/group only (never the network): the full list exchange at login and when the group grows ("R").
- Names of other players from the network are never shown in chat; messages from guild or group still name the sender.
- New command `/bsen sync test`: who else uses BuffSentinel (answers from guild, group, whisper network). The options show how many players with BuffSentinel were seen in the last hour.
- Diagnostic log: sync path once per session, every 10 minutes "sent / received / dropped", and the lines of GoldSentinelSync (including "NETZ", without names).
- **GoldSentinelTest 2:** share error reports with the developer (only with consent, /gstest).
- GoldSentinelGame 3 (shared file, comments only).
- Test routine (developer only): new cases T150–T157 (sending never over a channel, receiving with unknown sender and old messages, no channel join, /bsen sync test, versions of the shared files, whisper network storage and net=false, diagnostics without names, error reports only with consent).

## 0.9.13
- The display areas (buffs, procs, cooldowns, dispel) no longer get in the way of other GoldSentinel addons: free-floating displays are no longer entered in the shared window list, so the interface checks of ThreatSentinel and AHSentinel no longer report their windows as "covering BuffSentinelAnchor_…".
- Empty display areas (no icon) shrink to 1 × 1 outside move mode instead of lying invisibly 340 pixels wide on the screen; in move mode and as soon as they have content they get their full size back.
- Test routine (developer only): new case T149.

## 0.9.12
- English clients: long alerts on the buttons (e.g. "CLEARCASTING!") are now split at the word joint ("CLEAR-" / "CASTING!") instead of only shrinking the font. German clients keep the German word parts ("BLITZSCHLAG-" / "SCHILD!").
- Test routine (developer only): new case T148 checks the split in both languages.

## 0.9.11
- New diagnostic log (from the GoldSentinel template, new file `Diag.lua`): BuffSentinel records errors, refused aura access in WoW Forever/Retail and slow display updates (more than one frame). Repeated identical entries are only counted (×N). `/bsen protokoll` shows the log to copy. At logout or `/reload` it is stored as `BuffSentinelDB.diagExport` (starts with GSDIAG1) so the RaidMaster uploader can send it to GoldSentinel's test reports; `/bsen protokoll off` turns that off, `/bsen protokoll on` back on. The log contains no player, character, guild or realm names.
- `/bsen help` lists the new command.
- Test routine (developer only): new case T146 (entries, counter instead of loop, GSDIAG1 export, no names) and client case T147.

## 0.9.10
- Tooltips of the options window, the group grid, the dispel bar and the PayPal button now appear beside the window instead of on top of it, so they no longer cover other buttons.
- Test routine (developer only): new area K "oberflaeche" checks the interface in the real client (from the GoldSentinel template, new file `UICheck.lua`): own tooltips cover no buttons (T140), no overlap with Blizzard or other GoldSentinel windows (T141, free-floating displays excluded), windows fully on screen (T142), button labels not cut off (T143), displayed game values plausible – level, class, game version, talent points, group grid rows, own buffs (T144), no error loop with the same message more than 10× (T145). Without a real client T140–T143 are skipped, never counted as OK. Area K runs first, before other areas set test values. Read only, nothing is changed.

## 0.9.9
- WoW Forever: newly learned spells are recognised again without `/reload`. The event LEARNED_SPELL_IN_TAB does not exist in Forever; BuffSentinel now also listens to LEARNED_SPELL_IN_SKILL_LINE and only registers events the client knows (C_EventUtils.IsEventValid where available).
- Test routine (developer only): T29 accepts events the client does not know and checks that learning a spell is always detected; the combat report states "real actions: not counted in the combat part" instead of a stale value from the last automatic run.

## 0.9.8
- **WoW Forever / Retail – fixes Lua errors from the test reports** ("GetAuraDataByIndex(): Auras cannot be accessed when secret while tainted by 'BuffSentinel'", on UNIT_AURA and right after combat). BuffSentinel now only reads auras when the game allows it: not in combat, not in the first moment after combat (read half a second later instead), not from group members or targets that are in combat themselves, and not while the game reports protected auras. If the game refuses access anyway, the call is caught, the last known values are kept (no false "buff missing" alerts) and reading pauses for 2 seconds – no Lua error.
- Old clients (Classic Era, TBC, Wrath, Cata, MoP) are unchanged.
- Test routine (developer only): new case T139 simulates the refused access, the delayed read after combat, a group member in combat and protected auras.

## 0.9.7
- **Languages:** BuffSentinel now follows the language of the game client (for all players). English is the default, German is fully translated; all other languages show English for now. All texts live in the new file `Locales.lua`: chat messages, options, group grid, tooltips, minimap button, test bar, arrange bar, alerts on the buttons (e.g. "CLEARCASTING!"), spec and sound names and the test routine report. Spell and talent names come from the game as before.
- New command `/bsen help` listing all commands; the English short forms `/bsen move`, `/bsen errors`, `/bsen donate` work in every language.
- Addon list description in English, in German on a German client.
- Test routine (developer only): language tests in area F (every English text has a German one, placeholders match, help on an English client contains no German – T98, T137, T138); final count "real actions: 0" with the new case T136 (sending, chat and joining channels are only counted, never triggered); the `/reload` reminder appears after every run; T134 appears only once in the combat report.

## 0.9.6
- WoW Forever: the Procs and Cooldowns pages now show the same clear notice as the other pages – no display of procs, cooldowns and buffs in combat, dispel grid off, procs are not learned automatically. The line "learns new procs automatically" is no longer shown in Forever. (As before, BuffSentinel shows nothing in combat in Forever; buff reminders work before the pull and out of combat.)
- Damaged saved settings (wrong value types, incomplete positions) are repaired on load instead of causing Lua errors.
- Forever/Retail: tooltips of the group grid, the buttons and the dispel bar no longer concatenate protected player names (no Lua error in combat); addon messages and channel notices with protected values are ignored.
- Automatic learning no longer rebuilds the display in the middle of an aura scan.
- Errors (also in scanning, options pages and name sharing) are counted, shown in `/bsen fehler` and reported to GoldSentinel's test reports via the shared file `GoldSentinelTest.lua` (included unchanged). `/bsen fehler` also shows the number of pending reports.
- Developer only: test routine `/bsen testroutine [area|kampf]`, `/bsen selbsttest` (simulates WoW Forever via `GoldSentinelGame.SetTestFlavor`) and the "Alles testen" button. It sends nothing, joins no channel, casts nothing and leaves your saved settings unchanged.

## 0.9.5
- Errors in event handlers are now counted and show up in `/bsen fehler` (only the first one is still printed to chat).
- Forever/Retail: if BuffSentinel cannot hide its buttons before combat (combat lockdown already active), it does so right after combat.
- WoW Forever – stated clearly, also in the options and on the dispel page: no display of procs, cooldowns and buffs in combat (secret values), the dispel grid is off (also out of combat), procs are not learned automatically. Buff reminders work before the pull and out of combat.

## 0.9.4
- `GoldSentinelGame.lua` updated to version 2: wins over early, withdrawn copies that other GoldSentinel addons may still ship – no Lua errors when several addons are loaded together.

## 0.9.3
- Version detection now uses the shared `GoldSentinelGame.lua` of all GoldSentinel addons (included unchanged, listed in the .toc right after `GoldSentinelDev.lua`). WoW Forever is also recognised via the game's project ID in case the interface number changes at launch.
- Modern-client restrictions now depend on `GoldSentinelGame.IsModern` (Forever, Retail or any client with secret values). Classic Era, TBC, Wrath, Cata and MoP Classic are unchanged.
- Group names go through `GoldSentinelGame.Short` (secret names are never stored).
- `/gsgame` shows the detected game version; `/bsen fehler` shows the same line in addition to the error diagnostics.

## 0.9.1 – WoW Forever hardened
- WoW Forever runs on the modern client with the same addon restrictions as Retail (no combat log, "secret values" in combat). BuffSentinel now treats Forever the same way: buff reminders before the pull, no evaluation of auras, cooldowns, health or names in combat – a one-time chat hint (use the game's Cooldown Manager for procs in combat). The switch checks whether the game knows secret values; Classic Era, TBC, Wrath, Cata and MoP Classic are unchanged.
- The combat log is no longer registered on Forever and Retail; Overpower, Revenge and Riposte are detected via "spell usable" there.
- Secret values are checked everywhere before any arithmetic or comparison: own auras (stacks, expiration, spell ID), target health (Execute), group names, debuff types for dispelling, cooldowns. Secret cooldowns no longer count as "ready" – no false flash with sound on pull.
- Forever/Retail: all click buttons are hidden before combat so no invisible buttons catch clicks in combat.
- Errors no longer freeze the display: every button is protected individually and errors are counted. New command `/bsen fehler` shows diagnostics.

## 0.9.0
- New "Optionen" (options) tab (replaces "Zonen & Anzeige") with all settings in one place: alert sounds, zones, cooldowns & dispel, auto-learning, display & arrange, sizes, minimap, name sharing.
- Alert sounds fully configurable per alert type (horn for expired own buff, group buff missing, proc, cooldown ready, dispellable debuff, important raid debuff, bell):
  - On/off and sound per class and spec (switches with your spec), with "apply to all specs" and "reset spec".
  - Large selection: about 50 game sounds (only those present in your WoW version), bells, gong, war drum and more effects, all LibSharedMedia sounds from other addons, and custom files or sound IDs.
  - Picker window with preview (right-click = preview only) and a "listen" button on each row.
  - Selectable sound channel (Master, SFX, Dialog, Ambience, Music) and horn interval 3–60 s.
- Previous sound settings are migrated.

## 0.8.6
- Battle Shout now sounds the horn like all your own buffs until it is renewed (no bell by default anymore; the bell can still be enabled per entry).
- Feral druid: the Clearcasting button casts Shred (cat) or Maul (bear) depending on your form and appears in both forms. The mapping adapts even if not all forms are learned yet.

## 0.8.5
- When one of your own buffs expires (armor, shield, weapon enchant, poison …), BuffSentinel sounds a horn every 5 seconds until it is renewed (can be turned off, interval 5/10/15/30 s). Entries with a bell such as Battle Shout ring instead.
- Procs only appear when they are possible in your current stance or form (e.g. Overpower only in Battle Stance, Shred only in Cat Form). If only rage/mana/energy is missing, the proc stays visible with a blue tint.

## 0.8.4
- Sounds are off by default (switched off once in existing profiles too; afterwards your own choice applies).
- New: per-entry bell ("Ton" button on the procs, buffs and cooldowns pages). It rings even when the general sounds are off. By default only Battle Shout has a bell.
- "Test sounds" also plays the bell.

## 0.8.3
- Test mode with all classes and specs is now a developer tool (GoldSentinelDev). For everyone else, test mode shortcuts (`/bsen test`, Shift + left-click on the minimap button) open the arrange mode instead.
- "Test sounds" is now available in the arrange bar.

## 0.8.2
- New "Anordnen" (arrange) button at the top of the options window (also Ctrl + left-click on the minimap button or `/bsen anordnen`). Shows all your own buttons for dragging, like test mode, plus a bar with size, spacing and direction (horizontal/vertical) per group.
- Window positions are saved (options, group grid, test and arrange bars). "Reset all positions" resets windows too.

## 0.8.1
- New: size per group – procs, buffs, cooldowns and dispel 50–200 % each, on top of the overall size ("Zonen & Anzeige" page). Groups and freely placed buttons keep their screen position when resized.
- New "reset sizes" button.

## 0.8.0
- New: **automatic learning.** When BuffSentinel meets procs or abilities that are not in its data yet (e.g. new content in WoW Forever), it adds them by itself:
  - Procs: a short self-buff gained in combat that is consumed three times by casting the same spell gets a proc button for that spell. Buffs that simply expire (weapon enchants, trinkets) and buffs from other players are ignored.
  - Abilities: class spells with a cooldown of at least 10 s are added to the cooldown bar as soon as you cast them or learn them (trainer, talent point).
  - Learned entries are remembered per spec and for all characters on the account.
  - Discoveries are shared with other BuffSentinel users (spell IDs only, can be turned off).
  - Overview, removal and on/off switch on the "Aufnahme" (recording) page.
- Spells not learned yet (greyed out in the Cata/MoP spellbook) and spells of other specializations no longer count as known.

## 0.7.3
- Long compound words are split at a word boundary onto two lines (e.g. "BLITZSCHLAG-" / "SCHILD!") instead of shrinking the font; the font only gets smaller if that is not enough.
- Umlauts are now capitalised correctly in alerts ("SEELENSTÄRKE" instead of "SEELENSTäRKE").

## 0.7.2
- Priest: Surge of Light casts Smite in TBC (Flash Heal only from WotLK on).
- Hunter: Kill Command is a baseline ability in TBC – now shown for all specs.
- Warrior: Commanding Shout available from TBC; new Rampage buff reminder (TBC Fury).
- Procs from a buff are labelled with their source (e.g. "SHADOW TRANCE!") with the spell to press below.
- Long labels shrink automatically instead of being cut off.
- Dispel bar moved below/left of the buffs, cooldown and dispel titles sit above their area – no more overlaps.

## 0.7.1
- Fixed: main talent tree detection (e.g. 14/41/0 is now Fury, not Arms) – also with dual spec; the active talent group is read explicitly.
- Fixed: talents and procs are filtered by game version. WoW Forever talents (Bloodthrill, Vanguard) and WotLK procs (Sudden Death, Bloodsurge, Sword and Board, Hot Streak) no longer appear in TBC/Classic Era.
- Fixed: test mode only shows talent procs of the selected spec (e.g. Hot Streak only for Fire, Nature's Grace only for Balance).
- Settings lists no longer jump when you untick an entry; new "Auto" button resets an entry to the automatic choice.
- Fixed missing glyphs (arrow, check mark) and an outdated hint text.
- Test mode layout: two-line labels, group titles beside their area, areas grow with the number of buttons, test bar at the very top, settings window closes when test mode starts, dispel bar shows 5 sample slots and is hidden for classes without dispels.
- Warlock procs are named after their source (Shadow Trance, Backlash).
- Server sync retries joining the channel and shows a clear status.
- Fixed a tooltip that stayed visible after opening the support window.

## 0.7.0
- New "Support" button (PayPal) in the settings window header and on the "Zonen & Anzeige" page; also `/bsen donate` (or `/bsen support`). Opens only on click – no pop-ups, no chat messages.

## 0.6.3
- At least 3 seconds between alert sounds, the same sound at most every 4 seconds.
- "Test sounds" plays all alerts 3 seconds apart and shows which one is playing.

## 0.6.1
- WoW Forever: new Paladin (Seal of Fury, Light's Vigil, Voice of Truth, Swift Judgement, Templar's Bulwark, Infusion of Light) and Shaman abilities (Rage of the Farseer, Fire Nova, Totemic Projection).
- Test mode in Classic Era shows only the classes of your faction.

## 0.6.0
- Test mode with sample display for all classes and specs; buttons can be placed freely.

## 0.5.0
- Dispel bar for party/raid members and enemy dispel/purge buttons.

## 0.4.0
- First release: proc buttons, buff reminders with one-click buffing, cooldown bar, talent detection, all WoW versions.
