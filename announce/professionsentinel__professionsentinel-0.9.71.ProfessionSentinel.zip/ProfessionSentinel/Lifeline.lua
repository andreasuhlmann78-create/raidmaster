local _, ns = ...
local L = ns.L

-- "Lebenslinie": a thin line under every recipe (orange -> yellow -> green -> grey) with a marker
-- at your current skill and a hint how many crafts it takes until the next colour.
-- Uses the skill thresholds of the running game version (WoW Forever turns many recipes grey sooner).

local LL = {}
ns.Lifeline = LL

local COL = {
    orange = { 1.00, 0.50, 0.25 }, yellow = { 1.00, 0.82, 0.25 },
    green = { 0.25, 0.75, 0.25 }, grey = { 0.50, 0.50, 0.50 }, red = { 1.00, 0.25, 0.25 },
}
local HEX = { orange = "ff8040", yellow = "ffd23f", green = "40c040", grey = "a0a0a0", red = "ff4040" }
LL.HEX = HEX

---------------------------------------------------------------------------
-- Maths
---------------------------------------------------------------------------
-- Skill-up chance per craft (Classic rule): orange 100 %, from yellow on it falls linearly
-- to 0 % at grey: p = (grey - skill) / (grey - yellow).
function LL.Chance(r, skill)
    if skill < r.yellow then return 1 end
    if skill >= r.grey or r.grey <= r.yellow then return 0 end
    return (r.grey - skill) / (r.grey - r.yellow)
end

-- Expected number of crafts to raise the skill from `from` to `to` with this recipe (nil = impossible).
function LL.ExpectedCrafts(r, from, to)
    if to <= from then return 0 end
    local su = r.skillUps or 1
    local n, k, guard = 0, from, 0
    while k < to do
        local p = LL.Chance(r, k)
        if p <= 0 then return nil end
        n = n + 1 / p
        k = k + su
        guard = guard + 1
        if guard > 1000 then return nil end
    end
    return n
end

local function round(x) return math.floor(x + 0.5) end

-- Returns a table describing the recipe for the given skill, or nil when no thresholds are known.
-- { state = "red"|"orange"|"yellow"|"green"|"grey", target = colour name, crafts = n, exact = bool,
--   text = short hint, toYellow, toGreen, toGrey (expected crafts, nil if not applicable) }
function LL.Calc(r, rank)
    if not r or not rank or (r.yellow or 0) <= 0 or (r.grey or 0) <= 0 then return nil end
    local res = {}
    local req = (r.req or 0) > 1 and r.req or nil
    if rank < r.yellow then res.state = "orange"
    elseif rank < r.green then res.state = "yellow"
    elseif rank < r.grey then res.state = "green"
    else res.state = "grey" end
    if req and rank < req then res.state = "red" end

    if rank < r.yellow then res.toYellow = LL.ExpectedCrafts(r, rank, r.yellow) end
    if rank < r.green and r.green > r.yellow then res.toGreen = LL.ExpectedCrafts(r, rank, r.green) end
    if rank < r.grey then res.toGrey = LL.ExpectedCrafts(r, rank, r.grey) end

    if res.state == "red" then
        res.text = string.format(L.LL_FROM, req)
    elseif res.state == "grey" then
        res.text = L.LL_ISGREY
    elseif res.state == "orange" then
        -- orange gives a point every time: exact number
        if r.yellow >= r.grey then
            res.target, res.crafts = "grey", math.ceil((r.grey - rank) / (r.skillUps or 1))
        else
            res.target, res.crafts = "yellow", math.ceil((r.yellow - rank) / (r.skillUps or 1))
        end
        res.exact = true
    elseif res.state == "yellow" then
        if r.green >= r.grey then
            res.target, res.crafts = "grey", res.toGrey and round(res.toGrey)
        else
            res.target, res.crafts = "green", res.toGreen and round(res.toGreen)
        end
    else
        res.target, res.crafts = "grey", res.toGrey and round(res.toGrey)
    end
    if res.target and res.crafts then
        res.text = string.format(res.exact and L.LL_TO or L.LL_TO_APPROX, res.crafts, L["LL_" .. res.target:upper()])
        res.textColored = "|cff" .. HEX[res.target] .. res.text .. "|r"
    end
    res.textColored = res.textColored or ("|cff" .. HEX[res.state] .. (res.text or "") .. "|r")
    return res
end

-- Relative widths of the four zones and the marker position (0..1)
function LL.Layout(r, rank)
    local req = (r.req or 0) > 1 and r.req < r.yellow and r.req or nil
    local lo = req or math.max(0, r.yellow - math.max(r.grey - r.yellow, 10))
    local o = math.max(r.yellow - lo, 0)
    local y = math.max(r.green - r.yellow, 0)
    local g = math.max(r.grey - r.green, 0)
    local cap = math.max((r.grey - lo) * 0.12, 1)
    local total = o + y + g + cap
    local pos
    if not rank then pos = nil
    elseif rank >= r.grey then pos = (o + y + g + cap * 0.5) / total
    else pos = math.max(0, math.min(rank - lo, o + y + g)) / total end
    return { o / total, y / total, g / total, cap / total }, pos
end

---------------------------------------------------------------------------
-- Widget
---------------------------------------------------------------------------
local ORDER = { "orange", "yellow", "green", "grey" }

local function LayoutWidget(w)
    local width = w:GetWidth()
    if not width or width <= 0 or not w.fracs then return end
    local x = 0
    for i, seg in ipairs(w.segs) do
        local fw = width * w.fracs[i]
        -- Skillspur: the current section strong, the others only hinted (step 4, user 19:45 "feiner und moderner")
        if w.current then seg:SetAlpha(i == w.current and LL.SPUR_STRONG or LL.SPUR_WEAK) else seg:SetAlpha(1) end
        seg:ClearAllPoints()
        if fw >= 0.5 then
            seg:SetPoint("TOPLEFT", w, "TOPLEFT", x, 0)
            seg:SetPoint("BOTTOMLEFT", w, "BOTTOMLEFT", x, 0)
            seg:SetWidth(fw)
            seg:Show()
        else
            seg:Hide()
        end
        x = x + fw
    end
    if w.pos then
        w.marker:ClearAllPoints()
        w.marker:SetPoint("CENTER", w, "LEFT", width * w.pos, 0)
        w.marker:Show()
    else
        w.marker:Hide()
    end
end

-- Creates a line widget on `parent`. Anchor it yourself; height defaults to 2.
function LL.Create(parent, height)
    local w = CreateFrame("Frame", nil, parent)
    w:SetHeight(height or 2)
    w.segs = {}
    for i, key in ipairs(ORDER) do
        local t = w:CreateTexture(nil, "ARTWORK")
        t:SetColorTexture(COL[key][1], COL[key][2], COL[key][3], 1)
        w.segs[i] = t
    end
    w.marker = w:CreateTexture(nil, "OVERLAY")
    w.marker:SetColorTexture(1, 1, 1, 1)
    w.marker:SetSize(2, (height or 2) + 5)
    w:SetScript("OnSizeChanged", LayoutWidget)
    return w
end

function LL.Update(w, r, rank, dim)
    if not r or (r.yellow or 0) <= 0 then w:Hide(); return end
    w.fracs, w.pos = LL.Layout(r, rank)
    w:SetAlpha(dim and 0.45 or 1)
    w:Show()
    LayoutWidget(w)
end

---------------------------------------------------------------------------
-- Test mode overrides (TestMode.lua sets ns.Sim)
---------------------------------------------------------------------------
function ns.EffectiveRank(rank)
    if ns.Sim and ns.Sim.rank then return ns.Sim.rank end
    return rank
end

---------------------------------------------------------------------------
-- Blizzard recipe list: WoW Forever (modern ProfessionsFrame, ScrollBox)
---------------------------------------------------------------------------
-- Same reading as the panel (UI.ForeverProfession): highest valid skill of the open profession, nil if unknown
local function ForeverRank()
    if ns.UI and ns.UI.ForeverProfession then
        local _, rank = ns.UI.ForeverProfession()
        return rank
    end
end

---------------------------------------------------------------------------
-- SKILLSPUR (UI rework 2, step 4; released by the user 19:55, name "Skillspur" for now – locale key LL_SPUR):
-- under every recipe in Blizzard's list a 2 px line over the row width: sections orange/yellow/green/grey in the ratio of
-- the recipe's thresholds, the current section strong (85 %), the others hinted (30 %), a fine white mark (2×6 px) = own
-- skill (moves after every point). On the right ONE small number in Blizzard's font: orange = safe points until yellow
-- ("5"), yellow/green = chance of the next point ("70 %"), grey = nothing. No "≈", no "×".
-- The chance: measured from your own crafts once a band has LL.MEASURED_MIN cases, otherwise the formula
-- p = (grey − skill) / (grey − yellow) – marked "estimated" in the tooltip (Blizzard publishes no formula).
---------------------------------------------------------------------------
LL.SPUR_STRONG, LL.SPUR_WEAK = 0.85, 0.30
LL.MEASURED_MIN = 30
local STATE_INDEX = { orange = 1, yellow = 2, green = 3, grey = 4 }

-- band of a yellow/green skill for the measurement: quarter of the way from yellow to grey (0..3)
function LL.Band(r, rank)
    if not (r and rank and r.grey and r.yellow and r.grey > r.yellow) or rank < r.yellow or rank >= r.grey then return nil end
    local q = math.floor((rank - r.yellow) / (r.grey - r.yellow) * 4)
    return "q" .. math.max(0, math.min(3, q))
end

-- PS54-1: the measurement belongs to the CHARACTER (ProfessionSentinelDB is account-wide; Forever's legacy talent
-- "Working Overtime" differs per character): ProfessionSentinelDB.chars[<character>].skillChance
local function Store()
    local c = ns.Char and ns.Char()
    if type(c) ~= "table" then return nil end
    if type(c.skillChance) ~= "table" then c.skillChance = {} end
    return c.skillChance
end
LL.Store = Store

-- chance shown for the next point: p (0..1), measured (bool), cases (n of the band)
function LL.ShownChance(r, rank)
    local p = LL.Chance(r, rank)
    local band = LL.Band(r, rank)
    local st = band and Store()
    local b = st and st[band]
    if type(b) == "table" and (tonumber(b.n) or 0) >= LL.MEASURED_MIN then
        return (tonumber(b.up) or 0) / b.n, true, b.n
    end
    return p, false, type(b) == "table" and tonumber(b.n) or 0
end

-- the ONE number on the right: text, colour (hex) – or nil (grey / not learnable / unknown)
function LL.SpurNumber(r, rank)
    local c = r and rank and LL.Calc(r, rank)
    if not c or c.state == "grey" or c.state == "red" then return nil end
    if c.state == "orange" then
        return tostring(math.max(1, (r.yellow or rank) - rank)), HEX.orange
    end
    local p = LL.ShownChance(r, rank)
    return string.format("%d %%", math.floor(p * 100 + 0.5)), HEX[c.state]
end

-- kept for older callers (test routine, diagnostics): the sign of the row is the Skillspur number now
function LL.RowSign(r, rank) return LL.SpurNumber(r, rank) end

-- measurement (PS54-2: crafts in a row never overlap): every craft is recorded exactly ONCE – by the next craft of the same
-- profession (its skill now = the skill after the previous craft) or, after the last craft, LL.SETTLE seconds later.
-- A point that appears between two crafts belongs to the earlier one. No names, only numbers.
LL.SETTLE = 3
LL.pending = nil      -- { r, prof, rank, token }
function LL.After(sec, fn) if ns.API and ns.API.TimerAfter then ns.API.TimerAfter(sec, fn) end end
function LL.Settle(token)
    local p = LL.pending
    if not p or p.token ~= token then return end
    LL.pending = nil
    LL.Record(p.r, p.rank, ns.Scan:Rank(p.prof))
end
function LL.NoteCraft(r)
    if not (r and r.prof and ns.Scan) then return end
    local now = ns.Scan:Rank(r.prof)
    local p = LL.pending
    if p and p.prof == r.prof then
        LL.pending = nil
        LL.Record(p.r, p.rank, now)
    elseif p then
        LL.Settle(p.token)      -- another profession in between: the old one is settled now
    end
    if not LL.Band(r, now) then return end      -- orange / grey: nothing to measure
    LL.token = (LL.token or 0) + 1
    local token = LL.token
    LL.pending = { r = r, prof = r.prof, rank = now, token = token }
    LL.After(LL.SETTLE, function() LL.Settle(token) end)
end
function LL.Record(r, before, now)
    local band = LL.Band(r, before)
    local st = band and Store()
    if not (st and type(now) == "number" and type(before) == "number") then return end
    local b = st[band]
    if type(b) ~= "table" then b = { n = 0, up = 0 }; st[band] = b end
    b.n = (tonumber(b.n) or 0) + 1
    if now > before then b.up = (tonumber(b.up) or 0) + 1 end
end

-- tooltip of a row: the scale with the four thresholds, safe points, chances, where the number comes from
function LL.AddSpurTooltip(tt, r, rank)
    if not (tt and r and rank and (r.yellow or 0) > 0) then return end
    tt:AddLine(" ")
    tt:AddLine(L.LL_SPUR, 0.25, 0.78, 0.92)
    tt:AddLine(string.format(L.LL_SPUR_SCALE, r.yellow, r.green, r.grey), 1, 1, 1)
    local c = LL.Calc(r, rank)
    if c and c.state == "orange" then
        tt:AddLine(string.format(L.LL_SPUR_SAFE, math.max(1, r.yellow - rank), r.yellow), 1, 0.5, 0.25)
    elseif c and (c.state == "yellow" or c.state == "green") then
        local p, measured, n = LL.ShownChance(r, rank)
        tt:AddLine(string.format(measured and L.LL_SPUR_MEASURED or L.LL_SPUR_ESTIMATED, math.floor(p * 100 + 0.5), n), 1, 0.82, 0.25)
    elseif c and c.state == "grey" then
        tt:AddLine(L.LL_ISGREY, 0.6, 0.6, 0.6)
    end
    tt:AddLine(L.LL_SPUR_WHY, 0.7, 0.7, 0.7, true)
end

-- right end of the row's own texts (name, count …) in screen coordinates; ours left out
function LL.TextEnd(frame)
    local maxRight
    local function consider(fs)
        if type(fs) ~= "table" or fs == frame.psHint or not (fs.IsShown and fs:IsShown()) then return end
        if not (fs.GetLeft and fs.GetStringWidth) then return end
        local l, w = fs:GetLeft(), fs:GetStringWidth()
        if l and w then
            local justify = fs.GetJustifyH and fs:GetJustifyH()
            local right = (justify == "RIGHT" and fs.GetRight and fs:GetRight()) or (l + w)
            if not maxRight or right > maxRight then maxRight = right end
        end
    end
    for _, region in ipairs({ frame:GetRegions() }) do
        if region.IsObjectType and region:IsObjectType("FontString") then consider(region) end
    end
    consider(frame.Label)
    consider(frame.Count)
    if frame.GetFontString then consider(frame:GetFontString()) end
    return maxRight
end

LL.SIGN_GAP = 6
-- room for a sign of this width between the row's texts and its right edge?
function LL.SignFits(frameRight, textEnd, signWidth)
    if not frameRight or not signWidth then return false end
    if not textEnd then return true end
    return frameRight - 4 - signWidth >= textEnd + LL.SIGN_GAP
end

local function HideOld(frame)
    if frame.psLine then frame.psLine:Hide() end
    if frame.psHint then frame.psHint:Hide() end
    frame.psRecipe = nil
end

-- the tooltip of the row gets the Skillspur lines (hooked once; Blizzard's own tooltip stays, ours is added below)
local function HookTooltip(frame)
    if frame.psSpurHooked or not frame.HookScript then return end
    frame.psSpurHooked = true
    frame:HookScript("OnEnter", function(self)
        local r = self.psRecipe
        if not r or not GameTooltip then return end
        if not (GameTooltip:IsShown() and GameTooltip:GetOwner() == self) then GameTooltip:SetOwner(self, "ANCHOR_RIGHT") end
        LL.AddSpurTooltip(GameTooltip, r, self.psRank)
        GameTooltip:Show()
    end)
end

local function DecorateRow(frame, r, rank)
    if not ns.db or ns.db.lifeline == false or not r then HideOld(frame); return end
    rank = ns.EffectiveRank(rank)
    frame.psRecipe, frame.psRank = r, rank
    HookTooltip(frame)
    -- the line under the name over the row width (2 px), inside the row: never over the name, the count or Blizzard's parts
    if (r.yellow or 0) > 0 and rank then
        if not frame.psLine then
            frame.psLine = LL.Create(frame, 2)
            frame.psLine.marker:SetSize(2, 6)
        end
        local line = frame.psLine
        line:ClearAllPoints()
        line:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 4, 1)
        line:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -4, 1)
        local c = LL.Calc(r, rank)
        line.current = c and STATE_INDEX[c.state] or nil
        LL.Update(line, r, rank, false)
    elseif frame.psLine then
        frame.psLine:Hide()
    end
    local text, hex = LL.SpurNumber(r, rank)
    if not text then if frame.psHint then frame.psHint:Hide() end; return end
    if not frame.psHint then
        frame.psHint = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        frame.psHint:SetJustifyH("RIGHT")
    end
    local hint = frame.psHint
    -- the font of the row (at least as large as Blizzard's recipe line)
    local label = frame.Label
    if type(label) ~= "table" and frame.GetFontString then label = frame:GetFontString() end
    if type(label) == "table" and label.GetFont then
        local font, size, flags = label:GetFont()
        if font and size then pcall(hint.SetFont, hint, font, size, flags) end
    end
    hint:ClearAllPoints()
    hint:SetPoint("RIGHT", frame, "RIGHT", -4, 0)
    hint:SetText("|cff" .. hex .. text .. "|r")
    local fits = LL.SignFits(frame.GetRight and frame:GetRight(), LL.TextEnd(frame), hint:GetStringWidth())
    hint:SetShown(fits)
end
LL.DecorateRow = DecorateRow

local function DecorateForeverRow(frame, node)
    local data = node and node.GetData and node:GetData()
    local info = data and data.recipeInfo
    local r = info and ns.BySpell[info.recipeID]
    if not r then HideOld(frame); return end
    DecorateRow(frame, r, ForeverRank())
end

function LL.HookForever()
    if LL.foreverHooked or not ProfessionsFrame then return end
    local list = ProfessionsFrame.CraftingPage and ProfessionsFrame.CraftingPage.RecipeList
    local sb = list and list.ScrollBox
    if not sb or not ScrollUtil or not ScrollUtil.AddInitializedFrameCallback then return end
    LL.foreverHooked = true
    LL.foreverScrollBox = sb
    ScrollUtil.AddInitializedFrameCallback(sb, function(_, frame, node) DecorateForeverRow(frame, node) end, LL, true)
end

---------------------------------------------------------------------------
-- Blizzard recipe list: Classic Era (TradeSkillFrame / CraftFrame)
---------------------------------------------------------------------------
local function SpellFromLink(link)
    local id = link and (link:match("enchant:(%d+)") or link:match("spell:(%d+)"))
    return id and tonumber(id)
end

local function RecipeFromName(name)
    return name and ns.ByName[name:lower()]
end

local function UpdateEraTradeSkill()
    if not TradeSkillFrame or not TradeSkillFrame:IsShown() then return end
    if not (ns.API.GetTradeSkillLine and ns.API.GetTradeSkillInfo) then return end      -- old API missing: stay quiet
    local _, rank = ns.API.GetTradeSkillLine()
    local shown = TRADE_SKILLS_DISPLAYED or 8
    for i = 1, shown do
        local btn = _G["TradeSkillSkill" .. i]
        if btn then
            local r
            if btn:IsShown() then
                local idx = btn:GetID()
                local name, kind = ns.API.GetTradeSkillInfo(idx)
                if name and kind ~= "header" then
                    local spell = ns.API.GetTradeSkillRecipeLink and SpellFromLink(ns.API.GetTradeSkillRecipeLink(idx))
                    r = (spell and ns.BySpell[spell]) or RecipeFromName(name)
                end
            end
            if r then DecorateRow(btn, r, rank) else HideOld(btn) end
        end
    end
end

local function UpdateEraCraft()
    if not CraftFrame or not CraftFrame:IsShown() then return end
    if not (ns.API.GetCraftDisplaySkillLine and ns.API.GetCraftInfo) then return end
    local _, rank = ns.API.GetCraftDisplaySkillLine()
    local shown = CRAFTS_DISPLAYED or 8
    for i = 1, shown do
        local btn = _G["Craft" .. i]
        if btn then
            local r
            if btn:IsShown() then
                local idx = btn:GetID()
                local name, _, kind = ns.API.GetCraftInfo(idx)
                if name and kind ~= "header" then
                    local spell = ns.API.GetCraftRecipeLink and SpellFromLink(ns.API.GetCraftRecipeLink(idx))
                    r = (spell and ns.BySpell[spell]) or RecipeFromName(name)
                end
            end
            if r then DecorateRow(btn, r, rank) else HideOld(btn) end
        end
    end
end

function LL.HookEraTradeSkill()
    if LL.tsHooked or not TradeSkillFrame_Update then return end
    LL.tsHooked = true
    hooksecurefunc("TradeSkillFrame_Update", UpdateEraTradeSkill)
end

function LL.HookEraCraft()
    if LL.craftHooked or not CraftFrame_Update then return end
    LL.craftHooked = true
    hooksecurefunc("CraftFrame_Update", UpdateEraCraft)
end

-- area K (T242): on the visible rows of the profession window our sign never touches the name or the count
function LL.CheckRows()
    local problems, tested = {}, 0
    local function check(frame)
        local h = frame and frame.psHint
        if not (h and h.IsShown and h:IsShown()) then return end
        tested = tested + 1
        local textEnd, left = LL.TextEnd(frame), h.GetLeft and h:GetLeft()
        if textEnd and left and left < textEnd + 2 then
            problems[#problems + 1] = string.format("Zeichen überlappt Name/Anzahl (%.0f < %.0f)", left, textEnd)
        end
        -- Skillspur line: inside the row (never outside, never higher than 3 px from the row's bottom)
        local ln = frame.psLine
        if ln and ln.IsShown and ln:IsShown() and ln.GetBottom and frame.GetBottom then
            local lb, fb, lt = ln:GetBottom(), frame:GetBottom(), ln.GetTop and ln:GetTop()
            if lb and fb and (lb < fb - 0.5 or (lt and lt > fb + 4)) then problems[#problems + 1] = "Skillspur ausserhalb der Zeile" end
        end
    end
    if LL.foreverScrollBox and LL.foreverScrollBox.ForEachFrame then LL.foreverScrollBox:ForEachFrame(check) end
    for i = 1, TRADE_SKILLS_DISPLAYED or 8 do check(_G["TradeSkillSkill" .. i]) end
    for i = 1, CRAFTS_DISPLAYED or 8 do check(_G["Craft" .. i]) end
    return problems, tested
end

-- Re-decorate visible rows (after skill changes or test mode changes)
function LL.RefreshBlizzard()
    if LL.foreverScrollBox and LL.foreverScrollBox.ForEachFrame then
        LL.foreverScrollBox:ForEachFrame(function(frame, node) DecorateForeverRow(frame, node) end)
    end
    UpdateEraTradeSkill()
    UpdateEraCraft()
end

local f = ns.AddEventFrame(CreateFrame("Frame"), "Lifeline")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(_, event, name)
    if not ns.Flavor then return end
    if event == "PLAYER_LOGIN" then
        if ns.UsesModernProfessions and ProfessionsFrame then LL.HookForever() end
        if ns.IsEra then LL.HookEraTradeSkill(); LL.HookEraCraft() end
    elseif name == "Blizzard_Professions" then
        LL.HookForever()
    elseif name == "Blizzard_TradeSkillUI" then
        LL.HookEraTradeSkill()
    elseif name == "Blizzard_CraftUI" then
        LL.HookEraCraft()
    end
end)
