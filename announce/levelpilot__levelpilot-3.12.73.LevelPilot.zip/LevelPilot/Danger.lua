-- LevelPilot - Danger
-- Gefahrenkarte: hoechstes Level feindlicher Mobs je Gebiet (aus den Spawnpunkten des Datenpakets).
-- Pflichtregel: Die Route fuehrt nie zu Zielen und moeglichst nie ueber Wege, an denen Mobs 3 oder mehr
-- Level ueber dem Spielerlevel stehen. Elite-Mobs zaehlen 2 Level hoeher.

local _, LP = ...
local L = LP.L
local D = {}
LP:RegisterModule("Danger", D)

D.MAX_DIFF = 3            -- Mobs ab Spielerlevel + 3 sind tabu
D.ELITE_BONUS = 2         -- Elite zaehlt so viele Level mehr
D.pathRule = true         -- auch Wege durch gefaehrliche Gebiete meiden (Testumgebung kann es abschalten)
D.TOWN = 99               -- Ort der anderen Fraktion (Wachen): Sperrgebiet fuer jedes Level
local CELL = 100          -- Yards je Zelle
local SPREAD = 0          -- Nachbarzellen mitmarkieren (Mobs laufen umher, Aggro-Radius)
local ENTRANCE = 200      -- Yards um einen Dungeoneingang
local GUARD_LEVEL = 45    -- NPCs der anderen Fraktion ab diesem Level gelten als Wachen

local cells = nil         -- [inst] = { [key] = Level }
local segCache, segCount = {}, 0

local function Key(n, w) return math.floor(n / CELL) * 100000 + math.floor(w / CELL) end

local function MyCode() return LP:PlayerFaction() == "Horde" and "H" or "A" end

-- effektives Level eines Mobs (Elite hoeher); nil fuer freundliche NPCs
function D:MobLevel(npc, id)
    if type(npc) ~= "table" or not npc.lo then return nil end
    if npc.f and npc.f ~= "" and npc.f:find(MyCode(), 1, true) then return nil end
    if npc.v then return nil end                              -- Haendler, Lehrer, Flugmeister ...
    -- Elite, Boss (seltene zaehlen nicht); NPCs der anderen Fraktion (Wachen, Questgeber) ohne Aufschlag
    local faction = npc.f and npc.f ~= ""
    local elite = not faction and (npc.rk == 1 or npc.rk == 3)
    -- echtes Level aus dem Spiel, wenn hoeher als im Datenpaket (WoW Forever)
    local lo = (id and LP.Calib) and LP.Calib:MobLo(id, npc.lo) or npc.lo
    return lo + (elite and self.ELITE_BONUS or 0)
end

-- Fuer die Gefahrenkarte: nur Mobs, die ein Gebiet besetzen (mehrere Spawnpunkte) oder Elite;
-- einzelne NPCs ohne Fraktion sind meist Questgeber, seltene Mobs wandern umher
local function Occupies(npc)
    if npc.rk == 2 or npc.rk == 4 then return false end
    local pts = 0
    for _, s in ipairs(npc.s or {}) do pts = pts + (#s - 1) / 2 end
    -- NPCs der anderen Fraktion nur als Gruppe (Wachen eines Ortes); einzelne sind Questgeber oder stehen
    -- in Schlachtfeldern, deren Spawns auf die Aussenzone umgerechnet sind (Bericht 3.9.0: "Mob 63" am Pass)
    if npc.f and npc.f ~= "" then return pts >= 3 end
    if npc.rk == 1 or npc.rk == 3 then return true end
    return pts >= 3
end

function D:Build()
    -- in eine eigene Tabelle bauen und erst am Ende einsetzen: wird der Aufbau unterbrochen (Stopp der Reise),
    -- bleibt keine halbe Karte uebrig
    local built = {}
    local N = LevelPilotData and LevelPilotData.N
    if not N then cells = built wipe(segCache) segCount = 0 D.gen = (D.gen or 0) + 1 return end
    local Geo = LP.Geo
    -- Dungeoneingaenge: Elite-Spawns dort sind Dungeon-Mobs (stehen drinnen, nicht draussen)
    local ents = {}
    for _, d in pairs(LevelPilotData.D or {}) do
        for _, e in ipairs(d.e or {}) do
            local i, n, w = Geo:ToWorld(e[1], e[2], e[3])
            if i then ents[#ents + 1] = { i, n, w } end
        end
    end
    local function AtEntrance(inst, n, w)
        for _, e in ipairs(ents) do
            if e[1] == inst and math.abs(e[2] - n) < ENTRANCE and math.abs(e[3] - w) < ENTRANCE then return true end
        end
        return false
    end
    local count = 0
    for id, npc in pairs(N) do
        count = count + 1
        if count % 100 == 0 then LP:Yield("plan") end
        local lv = self:MobLevel(npc, id)
        -- Wachen eines Ortes der anderen Fraktion (Elite oder ab Level 45): Sperrgebiet fuer jedes Level;
        -- andere NPCs der Fraktion (z. B. Bauern von Hillsbrad = Questgegner der Horde) zaehlen mit ihrem Level
        if lv and npc.f and npc.f ~= "" and (npc.rk == 1 or npc.rk == 3 or npc.lo >= GUARD_LEVEL) then lv = self.TOWN end
        if lv and lv > 1 and Occupies(npc) then
            for _, s in ipairs(npc.s or {}) do
                local map = s[1]
                if Geo:Bounds(map) then
                    for i = 2, #s - 1, 2 do
                        local inst, n, w = Geo:ToWorld(map, s[i], s[i + 1])
                        if inst and not ((npc.rk == 1 or npc.rk == 3) and AtEntrance(inst, n, w)) then
                            local t = built[inst]
                            if not t then t = {} built[inst] = t end
                            local cn, cw = math.floor(n / CELL), math.floor(w / CELL)
                            for dn = -SPREAD, SPREAD do
                                for dw = -SPREAD, SPREAD do
                                    local k = (cn + dn) * 100000 + (cw + dw)
                                    if (t[k] or 0) < lv then t[k] = lv end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    cells = built
    wipe(segCache) segCount = 0
    D.gen = (D.gen or 0) + 1       -- 3.12.37: Stand der Gefahrenkarte (Zwischenspeicher an den Startwegen)
end

function D:Ready() return cells ~= nil end
function D:Reset() cells = nil wipe(segCache) segCount = 0 D.gen = (D.gen or 0) + 1 end
function D:CacheSize() return segCount end      -- 3.12.30 SP1 (Diagnose)

-- hoechstes Mob-Level an einem Weltpunkt (0 = nichts bekannt)
function D:At(inst, n, w)
    if not inst or not n then return 0 end
    if not cells then self:Build() end
    local t = cells and cells[inst]
    return t and t[Key(n, w)] or 0
end

function D:AtMap(map, x, y)
    local inst, n, w = LP.Geo:ToWorld(map, x, y)
    return self:At(inst, n, w)
end

-- hoechstes Mob-Level entlang einer Strecke, die ersten skip Yards ausgenommen (nicht zwischengespeichert).
-- stop (optional): sobald ein Level >= stop gefunden ist, sofort zurueck (der Aufrufer fragt nur "ab Grenze?").
-- 3.12.32 PF-A: dieselben Messpunkte wie bisher (n1 + dn * i / steps), aber ohne Funktionsaufruf je Punkt und
-- ohne die Punkte vor skip einzeln zu pruefen – kostete auf der Allianz (Elwynn L10) 95 % der Planungszeit.
local floor = math.floor
function D:Route(inst, n1, w1, n2, w2, skip, stop)
    if not inst then return 0 end
    if not cells then self:Build() end
    local t = cells and cells[inst]
    if not t then return 0 end
    skip = skip or 0
    local dn, dw = n2 - n1, w2 - w1
    local len = math.sqrt(dn * dn + dw * dw)
    if len <= skip then return 0 end
    local steps = math.max(1, math.ceil(len / (CELL * 0.5)))
    local mx = 0
    local i = 0
    if skip > 0 then
        -- erster Punkt mit len * i / steps >= skip (genau wie die bisherige Pruefung je Punkt)
        i = floor(skip * steps / len)
        if i > 0 and len * (i - 1) / steps >= skip then i = i - 1 end
        while len * i / steps < skip do i = i + 1 end
    end
    for k = i, steps do
        local v = t[floor((n1 + dn * k / steps) / CELL) * 100000 + floor((w1 + dw * k / steps) / CELL)]
        if v and v > mx then
            mx = v
            if stop and mx >= stop then return mx end
        end
    end
    return mx
end

-- 3.12.71 ERA-1 (b): jede Zelle, die die Strecke beruehrt (Gitter-Durchlauf), statt Messpunkten alle 50 Yards.
-- Vorher wurde eine Zelle, deren Ecke die Strecke schneidet, nur getroffen, wenn ein Messpunkt hineinfiel: 30 Yards
-- weiter lag die Strecke "sicher" bzw. "gefaehrlich" (x25) – der Weg sprang zwischen zwei Varianten, der Pfeil drehte.
function D.CellsOnLine(t, n1, w1, n2, w2)
    local cn, cw = floor(n1 / CELL), floor(w1 / CELL)
    local en, ew = floor(n2 / CELL), floor(w2 / CELL)
    local dn, dw = n2 - n1, w2 - w1
    local sn, sw = dn > 0 and 1 or -1, dw > 0 and 1 or -1
    local inf = math.huge
    local tdn = dn ~= 0 and math.abs(CELL / dn) or inf
    local tdw = dw ~= 0 and math.abs(CELL / dw) or inf
    local tmn = dn ~= 0 and (((sn > 0) and (cn + 1) * CELL - n1 or n1 - cn * CELL) / math.abs(dn)) or inf
    local tmw = dw ~= 0 and (((sw > 0) and (cw + 1) * CELL - w1 or w1 - cw * CELL) / math.abs(dw)) or inf
    local mx = 0
    local guard = math.abs(en - cn) + math.abs(ew - cw) + 2
    while guard > 0 do
        local v = t[cn * 100000 + cw]
        if v and v > mx then mx = v end
        if cn == en and cw == ew then break end
        if tmn < tmw then cn, tmn = cn + sn, tmn + tdn
        else cw, tmw = cw + sw, tmw + tdw end
        guard = guard - 1
    end
    return mx
end

-- hoechstes Mob-Level entlang einer Strecke (zwischengespeichert)
function D:Segment(inst, n1, w1, n2, w2)
    if not inst then return 0 end
    if not cells then self:Build() end
    local t = cells and cells[inst]
    if not t then return 0 end
    -- 3.12.71: Schluessel auf 1 Yard (vorher 40 Yards: zwei verschiedene Strecken teilten sich ein Ergebnis, je nachdem,
    -- welche zuerst gerechnet wurde). Knoten des Wegenetzes liegen fest, ihre Strecken treffen den Speicher weiter.
    local ck = inst .. ":" .. floor(n1 + 0.5) .. ":" .. floor(w1 + 0.5) .. ":" .. floor(n2 + 0.5) .. ":" .. floor(w2 + 0.5)
    local c = segCache[ck]
    if c then return c end
    local mx = D.CellsOnLine(t, n1, w1, n2, w2)
    if segCount > 50000 then wipe(segCache) segCount = 0 end
    segCache[ck] = mx
    segCount = segCount + 1
    return mx
end

-- Ist ein Mob dieses Levels fuer den Spieler erlaubt?
function D:OK(mobLevel, level)
    if not mobLevel then return true end
    return mobLevel < (level or LP:PlayerLevel() or 1) + self.MAX_DIFF
end

-- Level-Grenze (ab hier tabu)
function D:Limit(level) return (level or LP:PlayerLevel() or 1) + self.MAX_DIFF end

-- Gefahr entlang eines ganzen Weges (Punkte {inst, n, w, ...}). Die ersten skip Yards zaehlen nicht;
-- steht man schon in einem Gebiet mit zu starken Mobs (Level >= lim), zaehlt auch der Weg hinaus nicht
-- (hoechstens ESCAPE Yards) - entscheidend ist, nicht in ein solches Gebiet hineinzulaufen.
-- Liefert das hoechste Level und den Punkt (inst, n, w), an dem es auftritt.
local ESCAPE = 600
function D:PathDanger(path, skip, lim)
    if not path or #path < 2 then return 0 end
    if not cells then self:Build() end
    local walked, escaping = 0, lim ~= nil
    local mx, mi, mn, mw = 0, nil, nil, nil
    for i = 2, #path do
        local a, b = path[i - 1], path[i]
        local via = b.via
        if a[1] == b[1] and via ~= "boat" and via ~= "zep" and via ~= "tram" and via ~= "portal" then
            local t = cells and cells[a[1]]
            local dn, dw = b[2] - a[2], b[3] - a[3]
            local len = math.sqrt(dn * dn + dw * dw)
            local steps = math.max(1, math.ceil(len / (CELL * 0.5)))
            for k = 0, steps do
                local pos = walked + len * k / steps
                local n, w = a[2] + dn * k / steps, a[3] + dw * k / steps
                local v = t and t[Key(n, w)] or 0
                if escaping and (v < lim or pos > ESCAPE) then escaping = false end
                if pos >= (skip or 0) and not escaping and v > mx then mx, mi, mn, mw = v, a[1], n, w end
            end
            walked = walked + len
            if i % 4 == 0 then LP:Yield("graph") end
        end
    end
    return mx, mi, mn, mw
end

-- Wo grinden? Naechste Zelle mit Mobs im passenden Level (eigenes Level -2 bis +1, also nicht grau und machbar)
-- im Umkreis; liefert inst, n, w und das Mob-Level
function D:GrindSpot(inst, n, w, level, radius)
    if not inst or not n then return nil end
    if not cells then self:Build() end
    local t = cells and cells[inst]
    if not t then return nil end
    radius = radius or 1500
    local lo, hi = level - 2, level + 1
    local r = math.ceil(radius / CELL)
    local cn, cw = math.floor(n / CELL), math.floor(w / CELL)
    local best, bd, blv
    for dn = -r, r do
        for dw = -r, r do
            local v = t[(cn + dn) * 100000 + (cw + dw)]
            if v and v >= lo and v <= hi then
                local d = dn * dn + dw * dw
                if not bd or d < bd then best, bd, blv = { (cn + dn + 0.5) * CELL, (cw + dw + 0.5) * CELL }, d, v end
            end
        end
    end
    if not best then return nil end
    return inst, best[1], best[2], blv
end

-- Monster auf dem Weg, die man im Vorbeigehen mitnimmt (Speedrun): Zellen entlang des Weges mit Mobs, die EP
-- geben (nicht grau: hoechstens greyDiff unter dem Spieler) und machbar sind (hoechstens 2 Level darueber).
-- Liefert die Zahl der Kills (eine je Zelle, hoechstens eine je perYards) und die Summe ihrer Level.
function D:WayKills(path, level, greyDiff, perYards, minLevel)
    if not path or #path < 2 then return 0, 0 end
    if not cells then self:Build() end
    local lo, hi = level - (greyDiff or 5) + 1, level + 2
    if minLevel and minLevel > lo then lo = minLevel end
    local seen, kills, sum, len = {}, 0, 0, 0
    for i = 2, #path do
        local a, b = path[i - 1], path[i]
        local via = b.via
        if a[1] == b[1] and via ~= "boat" and via ~= "zep" and via ~= "tram" and via ~= "portal" then
            local t = cells and cells[a[1]]
            local dn, dw = b[2] - a[2], b[3] - a[3]
            local l = math.sqrt(dn * dn + dw * dw)
            len = len + l
            local steps = math.max(1, math.ceil(l / (CELL * 0.5)))
            for k = 0, steps do
                local key = Key(a[2] + dn * k / steps, a[3] + dw * k / steps)
                local v = t and t[key]
                if v and v >= lo and v <= hi and not seen[key] then
                    seen[key] = true
                    kills, sum = kills + 1, sum + v
                end
            end
        end
    end
    local cap = math.floor(len / (perYards or 120))
    if kills > cap then sum, kills = sum * cap / math.max(1, kills), cap end
    return kills, sum
end

