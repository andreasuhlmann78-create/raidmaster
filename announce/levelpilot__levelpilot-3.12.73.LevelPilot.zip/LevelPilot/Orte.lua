-- LevelPilot – Orte (3.12.72, ORT-1): Gebiets-ID (AreaTable, wie der Ortsname an der Minikarte) zu jedem Punkt einer Zonenkarte.
-- Daten: LevelPilotData.ORTE (Datenpaket 1.6.3, aus den Spieldateien, 1 % x 1 % der Karte), je Spielversion im eigenen Kartenrahmen.
-- Ohne Datenpaket liefert alles nil (der Planer nimmt dann die alte Regel).
local _, LP = ...
local O = {}
LP.Orte = O

-- Startgebiete je Volk: Gebiet des Startplatzes + angrenzende Teilgebiete mit Erkundungsstufe 0 (aus den Daten,
-- orte_bauen/Bericht ORT-1). Nicht dazu: Südstrom (Fluss am Rand des Tals der Prüfungen, kein Questgebiet).
O.START = {
    Human = { 9, 34, 59 },                 -- Nordhaintal, Echokammmine, Weinberge von Nordhain
    Dwarf = { 132 }, Gnome = { 132 },      -- Coldridgetal
    NightElf = { 188, 256, 263 },          -- Schattenhain, Aldrassil, Die Kluft
    Orc = { 363, 638, 639, 640 }, Troll = { 363, 638, 639, 640 },   -- Tal der Prüfungen + Verborgener Pfad, Geisterfels, Schrein
    Scourge = { 154, 155 },                -- Todesend, Nachtwebergrund
    Tauren = { 220, 221 },                 -- Rotwolkenplateau, Camp Narache
}

local cache = {}          -- [rahmen .. map] = { [y] = { x -> id } } (zeilenweise beim ersten Zugriff entpackt)
local function Data()
    local d = _G.LevelPilotData
    return d and d.ORTE
end

local function Row(str, j)
    -- j-te Zeile (0-basiert) aus "z0;z1;…"
    local i = 0
    for row in (str .. ";"):gmatch("([^;]*);") do
        if i == j then return row end
        i = i + 1
    end
end

local function Decode(row)
    local out, x = {}, 0
    for part in row:gmatch("[^,]+") do
        local id, n = part:match("^(%d+)%*(%d+)$")
        id, n = tonumber(id or part), tonumber(n or 1)
        for _ = 1, n do out[x] = id x = x + 1 end
    end
    return out
end

function O.Available() return Data() ~= nil end

-- Gebiets-ID an Kartenpunkt (x, y in 0..100) der Karte map; nil ausserhalb/ohne Daten
function O.At(map, x, y)
    local d = Data()
    if not d or not map or not x or not y or x < 0 or y < 0 or x >= 100 or y >= 100 then return nil end
    local era = LP.Geo and LP.Geo.EraFrame and LP.Geo.EraFrame()
    local str = (era and d.era and d.era[map]) or (d.forever and d.forever[map])
    if not str then return nil end
    local key = (era and "e" or "f") .. map
    local z = cache[key]
    if not z then z = {} cache[key] = z end
    local j = math.floor(y)
    local r = z[j]
    if not r then
        local row = Row(str, j)
        if not row then return nil end
        r = Decode(row)
        z[j] = r
    end
    local id = r[math.floor(x)]
    return (id and id ~= 0) and id or nil
end

-- Gebiets-ID an einem Weltpunkt, bezogen auf die Karte map
function O.AtWorld(map, inst, n, w)
    if not (map and inst and n and LP.Geo) then return nil end
    local x, y = LP.Geo:ToMap(map, inst, n, w)
    return O.At(map, x, y)
end

-- Eltern, Erkundungsstufe, Name (englisch) eines Gebiets
function O.Info(id)
    local d = _G.LevelPilotData
    local a = d and d.ORTA and d.ORTA[id]
    if a then return a[1], a[2], a[3] end
end

function O.Reset() wipe(cache) end
