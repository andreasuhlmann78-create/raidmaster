-- LevelPilot - oeffentliche Schnittstelle fuer andere Addons (LevelPilotAPI)
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- 3.12.44 (Wunsch ProfessionSentinel, Supervisor 15.11. 23:48):
--   LevelPilotAPI.NavigateTo(uiMapID, x, y, titel) -> true / false
--     uiMapID: Karte (C_Map), x/y: Kartenkoordinaten in Prozent (0-100), titel: Text des Schritts (optional).
--     LevelPilot fuehrt hin wie bei eigenen Zielen (Pfeil, Weg, Fluege/Schiffe; Ziel steht oben im Guide).
--     false, wenn die Angaben ungueltig sind oder LevelPilot fuer die Karte keine Weltkoordinaten kennt.
--   LevelPilotAPI.version: Nummer der Schnittstelle (2)
--
-- 3.12.63 NAV-4 (Version 2) – nur lesen oder anstossen, LevelPilot ändert nie Daten anderer Addons:
--   LevelPilotAPI.NavigateToNearest(art) -> true / false
--     art: "mailbox", "auction", "bank", "inn", "flight", "vendor", "repair", "trainer" – nächster Dienst nach Wegkosten.
--   LevelPilotAPI.StopNavigation() -> true / false
--     beendet nur ein Ziel, das über die Schnittstelle gesetzt wurde (nie ein eigenes Ziel des Spielers).
--   LevelPilotAPI.GetNavigation() -> nil oder { map, x, y, title, seconds, plan }
--     aktuelles Hinführ-Ziel (Kopie): Karte, Koordinaten, Titel, Reisezeit in Sekunden und Reiseplan-Text (wenn schon gerechnet).
--   LevelPilotAPI.TravelTime(uiMapID, x, y, callback) -> true / false
--     rechnet den Reiseplan dorthin in Portionen; danach callback(sekunden, text) bzw. callback(nil), wenn kein Weg bekannt ist.

local _, LP = ...

local API = _G.LevelPilotAPI or {}
_G.LevelPilotAPI = API
API.version = 2

function API.NavigateTo(map, x, y, title)
    map, x, y = tonumber(map), tonumber(x), tonumber(y)
    if not (map and x and y) or x < 0 or x > 100 or y < 0 or y > 100 then return false end
    if not (LP.Geo and LP.Planner and LP.Planner.Replan) then return false end
    local i, n, w = LP.Geo:ToWorld(map, x, y)
    if not i then return false end
    local text = (type(title) == "string" and title ~= "") and title or LP.Geo:MapName(map)
    local key = ("PRIO:API:%d:%.1f:%.1f"):format(map, x, y)
    if LP.Comfort and LP.Comfort.Navigate then
        LP.Comfort.Navigate(map, x, y, text, key)        -- 3.12.63: wie /lp navi (mit Reiseplan)
    else
        LP.Planner.priority = { t = "GOTO", map = map, x = x, y = y, inst = i, n = n, w = w, text = text, key = key, explicit = true }
        LP.Planner:Replan()
    end
    return true
end

local KINDS = { mailbox = true, auction = true, bank = true, inn = true, flight = true, vendor = true, repair = true, trainer = true }
function API.NavigateToNearest(kind)
    if not (type(kind) == "string" and KINDS[kind]) or not (LP.Comfort and LP.Comfort.Find and LP.Planner) then return false end
    local before = LP.Planner.priority
    LP.Comfort:Find(kind)
    local p = LP.Planner.priority
    if p and p ~= before and p.key then p.key = p.key:gsub("^PRIO:", "PRIO:API:") return true end
    return false
end

function API.StopNavigation()
    local P = LP.Planner
    local p = P and P.priority
    if not (p and p.key and p.key:find("^PRIO:API:")) then return false end
    P.priority = nil
    P:Replan()
    return true
end

function API.GetNavigation()
    local p = LP.Planner and LP.Planner.priority
    if not (p and p.map) then return nil end
    return { map = p.map, x = p.x, y = p.y, title = p.text, seconds = p.navPlan and p.navPlan.total or nil, plan = p.navText }
end

function API.TravelTime(map, x, y, callback)
    map, x, y = tonumber(map), tonumber(x), tonumber(y)
    if type(callback) ~= "function" or not (map and x and y) or x < 0 or x > 100 or y < 0 or y > 100 then return false end
    local P = LP.Planner
    if not (LP.Geo and P and P.TravelPlan and LP.Jobs) then return false end
    local gi, gn, gw = LP.Geo:ToWorld(map, x, y)
    local pi, pn, pw, pmap = LP.Geo:Player()
    if not (gi and pi) then return false end
    LP.Jobs.Start("apiTravel", "nav", function()
        return P:TravelPlan(pi, pn, pw, pmap, { inst = gi, n = gn, w = gw, map = map })
    end, function(ok, plan)
        local okc, err
        if ok and plan then okc, err = pcall(callback, plan.total, P.PlanText(plan)) else okc, err = pcall(callback, nil) end
        if not okc and LP.Protocol then LP.Protocol:AddL("error", "LevelPilotAPI.TravelTime: Fehler im Rückruf: %s", tostring(err)) end
    end, { graph = true })
    return true
end
