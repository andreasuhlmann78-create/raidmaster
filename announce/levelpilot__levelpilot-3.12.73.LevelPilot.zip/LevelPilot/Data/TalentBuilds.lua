-- LevelPilot - eigene Level-Builds je Klasse (LP-N1 Punkt 1). Erzeugt mit berichte/LevelPilot/talente/talente_bauen.py
-- aus builds.py (eigene Auswahl und eigene Begründungen) und den Talentbäumen WoW Forever (wago.tools, Zweig wowf,
-- Build 1.60.1.70938). Je Eintrag: Baum, Reihe, Spalte (1-basiert wie GetTalentInfo), Ränge, Satz de, Satz en.

local _, LP = ...
LP.TalentBuilds = {
    WARRIOR = {
        { 1, 1, 1, 3, "Heldenhafter Stoß kostet weniger Wut – du schlägst ihn öfter.", "Heroic Strike costs less rage, so you can use it more often." },   -- Verbesserter heldenhafter Stoß
        { 1, 1, 3, 3, "Verwunden macht mehr Blutungsschaden; nötig für Tiefe Wunden.", "Rend bleeds harder; needed for Deep Wounds." },   -- Verbessertes Verwunden
        { 1, 2, 1, 2, "Sturmangriff gibt mehr Wut – du startest jeden Kampf stärker.", "Charge gives more rage, so every fight starts stronger." },   -- Verbesserter Sturmangriff
        { 1, 2, 2, 5, "Mehr Wut bleibt beim Haltungswechsel; nötig für Aggressionskontrolle.", "Keep more rage when switching stances; needed for Anger Management." },   -- Verbesserter Taktiker
        { 1, 3, 2, 1, "Erzeugt im Kampf laufend Wut – weniger Leerlauf.", "Generates rage during combat – less waiting." },   -- Aggressionskontrolle
        { 1, 3, 3, 3, "Kritische Treffer lassen bluten – mehr Schaden ohne Mehrkosten.", "Critical hits make the target bleed – more damage at no cost." },   -- Tiefe Wunden
        { 1, 4, 2, 5, "Mehr Schaden mit Zweihandwaffen, der Standard beim Leveln.", "More damage with two-handed weapons, the usual leveling choice." },   -- Zweihandwaffen-Spezialisierung
        { 1, 4, 3, 2, "Kritische Treffer deiner Fähigkeiten treffen härter.", "Critical hits of your abilities hit harder." },   -- Durchbohren
        { 1, 5, 2, 1, "Trifft einen zweiten Gegner mit – ideal bei zwei Monstern.", "Hits a second enemy too – great when two monsters attack." },   -- Weitreichende Stöße
        { 1, 5, 1, 5, "Waffenmeister passend zu deiner Waffe: mehr Schaden mit genau dieser Waffenart.", "Weaponmaster for your weapon type: more damage with exactly that weapon.", alt = { { 1, 5, 1, { 0, 1, 6 } }, { 1, 5, 3, { 4, 5, 10 } }, { 1, 5, 4, { 7, 8 } } } },   -- Waffenmeister
        { 1, 7, 2, 1, "Tödlicher Stoß: dein stärkster Angriff, dazu weniger Heilung beim Gegner.", "Mortal Strike: your strongest attack, and the target heals less." },   -- Tödlicher Stoß
        { 2, 1, 3, 5, "Mehr kritische Treffer bei allen Nahkampfangriffen.", "More critical hits with all melee attacks." },   -- Grausamkeit
        { 2, 2, 3, 5, "Treffer erzeugen öfter zusätzliche Wut.", "Hits generate extra rage more often." },   -- Entfesselter Zorn
        { 2, 3, 4, 5, "Schlachtruf gibt mehr Angriffskraft.", "Battle Shout gives more attack power." },   -- Verbesserter Schlachtruf
        { 2, 4, 3, 5, "Nach erlittenen Treffern machst du zeitweise mehr Schaden.", "After taking hits you deal more damage for a while." },   -- Wutanfall
    },
    PALADIN = {
        { 3, 1, 3, 5, "Sofortzauber wie Richturteil kosten weniger Mana – längere Kämpfe ohne Pause.", "Instant spells like Judgement cost less mana – longer fights without resting." },   -- Segnung
        { 3, 2, 1, 2, "Richturteil öfter einsetzen – mehr Schaden.", "Use Judgement more often – more damage." },   -- Verbessertes Richturteil
        { 3, 2, 2, 3, "Siegel des Kreuzfahrers gibt mehr Angriffskraft.", "Seal of the Crusader gives more attack power." },   -- Verbessertes Siegel des Kreuzfahrers
        { 3, 3, 2, 5, "Mehr kritische Treffer mit allen Zaubern und Angriffen; nötig für Rache.", "More critical hits with all spells and attacks; needed for Vengeance." },   -- Überzeugung
        { 3, 3, 3, 1, "Siegel des Befehls: starkes Siegel für langsame Zweihandwaffen.", "Seal of Command: a strong seal for slow two-handed weapons." },   -- Siegel des Befehls
        { 3, 3, 4, 2, "Schneller unterwegs – zu Fuss und beritten.", "Move faster – on foot and mounted." },   -- Streben nach Gerechtigkeit
        { 3, 4, 3, 2, "Aura der Vergeltung schadet Angreifern mehr.", "Retribution Aura hurts attackers more." },   -- Verbesserte Aura der Vergeltung
        { 3, 5, 1, 3, "Mehr Schaden mit Zweihandwaffen.", "More damage with two-handed weapons." },   -- Zweihandwaffen-Spezialisierung
        { 3, 5, 3, 1, "Aura der Heiligkeit: mehr Heiligschaden für dich und die Gruppe.", "Sanctity Aura: more Holy damage for you and your group." },   -- Aura der Heiligkeit
        { 3, 3, 1, 1, "Schwächt die Angriffskraft des Gegners – du nimmst weniger Schaden.", "Lowers the enemy's attack power – you take less damage." },   -- Rechtschaffene Schwächung
        { 3, 6, 2, 5, "Nach kritischen Treffern machst du mehr Schaden.", "After critical hits you deal more damage." },   -- Rache
        { 3, 7, 2, 1, "Buße: ein Humanoider schläft, während du den anderen besiegst.", "Repentance: one humanoid sleeps while you defeat the other." },   -- Buße
        { 1, 1, 2, 5, "Mehr Stärke – mehr Schaden im Nahkampf.", "More Strength – more melee damage." },   -- Göttliche Stärke
        { 1, 1, 3, 5, "Mehr Intelligenz – mehr Mana.", "More Intellect – more mana." },   -- Göttliche Weisheit
        { 1, 2, 3, 5, "Siegel und Richturteile machen mehr Schaden.", "Seals and Judgements deal more damage." },   -- Verbesserte Siegel
        { 1, 3, 1, 3, "Deine Heilzauber heilen mehr.", "Your heals heal more." },   -- Heilendes Licht
        { 1, 3, 2, 1, "Weihe: Flächenschaden gegen mehrere Gegner.", "Consecration: area damage against several enemies." },   -- Weihe
        { 1, 3, 4, 1, "Furcht wirkt kürzer auf dich.", "Fear lasts shorter on you." },   -- Unumstößlicher Glaube
    },
    HUNTER = {
        { 1, 1, 2, 5, "Mit dem Aspekt des Falken schiesst du öfter schneller.", "With Aspect of the Hawk you shoot faster more often." },   -- Tödliche Aspekte
        { 1, 2, 3, 3, "Dein Tier hält mehr aus.", "Your pet takes less damage." },   -- Dickes Fell
        { 1, 2, 4, 2, "Tier schneller und billiger wiederbeleben.", "Revive your pet faster and cheaper." },   -- Verbessertes Tier wiederbeleben
        { 1, 3, 3, 5, "Dein Tier macht mehr Schaden.", "Your pet deals more damage." },   -- Entfesselter Zorn
        { 1, 3, 1, 2, "Aspekt des Geparden ist schneller – kürzere Wege.", "Aspect of the Cheetah is faster – shorter travel." },   -- Orientierung
        { 1, 4, 3, 5, "Dein Tier trifft öfter kritisch; nötig für Raserei.", "Your pet crits more often; needed for Frenzy." },   -- Wildheit
        { 1, 4, 2, 2, "Tier heilen entfernt schädliche Effekte.", "Mend Pet also removes harmful effects." },   -- Verbessertes Tier heilen
        { 1, 5, 2, 1, "Einschüchterung betäubt den Gegner; nötig für Zorn des Wildtiers.", "Intimidation stuns the enemy; needed for Bestial Wrath." },   -- Einschüchterung
        { 1, 5, 1, 2, "Du und dein Tier regenerieren Leben – weniger Pausen.", "You and your pet regenerate health – fewer breaks." },   -- Geistbande
        { 1, 5, 4, 2, "Mehr Fokus für dein Tier und Mana-Regeneration beim Zaubern.", "More focus for your pet and mana regeneration while casting." },   -- Wildtierdisziplin
        { 1, 6, 3, 5, "Nach kritischen Treffern greift dein Tier schneller an.", "After critical hits your pet attacks faster." },   -- Raserei
        { 1, 7, 2, 1, "Zorn des Wildtiers: dein Tier macht kurz viel mehr Schaden.", "Bestial Wrath: your pet deals much more damage for a short time." },   -- Zorn des Wildtiers
        { 2, 1, 3, 5, "Schüsse und Stiche kosten weniger Mana.", "Shots and stings cost less mana." },   -- Effizienz
        { 2, 2, 3, 5, "Mehr kritische Treffer bei allen Angriffen.", "More critical hits with all attacks." },   -- Tödliche Angriffe
        { 2, 3, 1, 1, "Gezielter Schuss: starker Eröffnungsschuss.", "Aimed Shot: a strong opening shot." },   -- Gezielter Schuss
        { 2, 3, 4, 3, "Grössere Reichweite – mehr Schüsse, bevor der Gegner ankommt.", "Longer range – more shots before the enemy arrives." },   -- Falkenauge
        { 2, 2, 2, 2, "Mal des Jägers gibt mehr Distanz-Angriffskraft.", "Hunter's Mark gives more ranged attack power." },   -- Verbessertes Mal des Jägers
    },
    ROGUE = {
        { 2, 1, 2, 2, "Finsterer Stoss kostet weniger Energie.", "Sinister Strike costs less energy." },   -- Effiziente Schläge
        { 2, 1, 3, 3, "Du weichst öfter aus.", "You dodge more often." },   -- Blitzartige Reflexe
        { 2, 2, 3, 5, "Du triffst öfter; nötig für Beidhändigkeit.", "You hit more often; needed for Dual Wield Specialization." },   -- Präzision
        { 2, 3, 1, 2, "Sprinten und Entrinnen öfter einsetzbar.", "Use Sprint and Evasion more often." },   -- Durchhaltevermögen
        { 2, 2, 2, 3, "Du parierst öfter.", "You parry more often." },   -- Abwehr
        { 2, 4, 3, 5, "Deine Nebenhand macht mehr Schaden.", "Your off-hand deals more damage." },   -- Beidhändigkeitsspezialisierung
        { 2, 5, 2, 1, "Klingenwirbel: schneller angreifen und einen zweiten Gegner treffen.", "Blade Flurry: attack faster and hit a second enemy." },   -- Klingenwirbel
        { 2, 5, 3, 5, "Niedermetzeln passend zu deiner Waffe: mehr Schaden mit genau dieser Waffenart.", "Hack and Slash for your weapon type: more damage with exactly that weapon.", alt = { { 2, 5, 3, { 0, 7 } }, { 2, 5, 1, { 4 } }, { 2, 4, 2, { 15, 13 } } } },   -- Niedermetzeln
        { 2, 6, 2, 2, "Deine Angriffe werden seltener ausgewichen oder pariert.", "Your attacks are dodged or parried less often." },   -- Waffenexperte
        { 2, 6, 3, 3, "Finsterer Stoss und Ausweiden machen mehr Schaden.", "Sinister Strike and Eviscerate deal more damage." },   -- Aggression
        { 2, 7, 2, 1, "Adrenalinrausch: viel mehr Energie für kurze Zeit.", "Adrenaline Rush: much more energy for a short time." },   -- Adrenalinrausch
        { 1, 1, 3, 5, "Mehr kritische Treffer; nötig für Tödlichkeit.", "More critical hits; needed for Lethality." },   -- Tücke
        { 1, 2, 1, 3, "Finisher geben manchmal einen Combopunkt zurück.", "Finishers sometimes give a combo point back." },   -- Skrupellosigkeit
        { 1, 2, 2, 2, "Mehr Schaden gegen Humanoide und Riesen.", "More damage against humanoids and giants." },   -- Mord
        { 1, 3, 1, 1, "Finisher geben Energie zurück.", "Finishers restore energy." },   -- Unerbittliche Stöße
        { 1, 3, 3, 5, "Kritische Treffer von Finsterer Stoss treffen härter.", "Critical Sinister Strikes hit harder." },   -- Tödlichkeit
        { 1, 2, 4, 3, "Zerhäckseln hält länger.", "Slice and Dice lasts longer." },   -- Verbessertes Zerhäckseln
    },
    PRIEST = {
        { 3, 1, 2, 5, "Nach einem Sieg regenerierst du schnell Mana – weniger Pausen.", "After a kill you regain mana quickly – fewer breaks." },   -- Willensentzug
        { 3, 2, 2, 2, "Schattenwort: Schmerz wirkt länger.", "Shadow Word: Pain lasts longer." },   -- Verbessertes Schattenwort: Schmerz
        { 3, 2, 3, 3, "Deine Schattenzauber treffen öfter.", "Your Shadow spells hit more often." },   -- Schattenfokus
        { 3, 3, 3, 1, "Gedankenschinden: Schaden und Verlangsamung.", "Mind Flay: damage and a slow." },   -- Gedankenschinden
        { 3, 3, 2, 4, "Gedankenschlag öfter einsetzbar.", "Use Mind Blast more often." },   -- Verbesserter Gedankenschlag
        { 3, 4, 4, 5, "Der Gegner nimmt mehr Schattenschaden von dir.", "The enemy takes more Shadow damage from you." },   -- Schattenwirken
        { 3, 5, 2, 1, "Vampirumarmung: dein Schattenschaden heilt dich.", "Vampiric Embrace: your Shadow damage heals you." },   -- Vampirumarmung
        { 3, 5, 3, 2, "Vampirumarmung heilt mehr.", "Vampiric Embrace heals more." },   -- Verbesserte Vampirumarmung
        { 3, 2, 3, 2, "Noch sicherer treffen mit Schattenzaubern.", "Hit even more reliably with Shadow spells." },   -- Schattenfokus
        { 3, 6, 3, 5, "Mehr Schattenschaden.", "More Shadow damage." },   -- Dunkelheit
        { 3, 7, 2, 1, "Schattengestalt: mehr Schattenschaden, weniger erlittener Schaden.", "Shadowform: more Shadow damage, less damage taken." },   -- Schattengestalt
        { 1, 1, 3, 5, "Mehr Schaden mit dem Zauberstab – spart Mana beim Leveln.", "More wand damage – saves mana while leveling." },   -- Zauberstab-Spezialisierung
        { 1, 2, 3, 3, "Machtwort: Schild fängt mehr Schaden ab.", "Power Word: Shield absorbs more damage." },   -- Verbessertes Machtwort: Schild
        { 1, 2, 2, 2, "Seelenstärke gibt mehr Ausdauer.", "Fortitude gives more Stamina." },   -- Verbessertes Machtwort: Seelenstärke
        { 1, 3, 3, 3, "Mana-Regeneration läuft beim Zaubern teilweise weiter.", "Part of your mana regeneration continues while casting." },   -- Meditation
        { 1, 3, 2, 1, "Innerer Fokus: ein kostenloser, stärkerer Zauber.", "Inner Focus: one free, stronger spell." },   -- Innerer Fokus
        { 1, 1, 2, 1, "Betäubung, Furcht und Stille wirken kürzer.", "Stun, fear and silence last shorter." },   -- Unbezwingbarer Wille
        { 1, 4, 2, 5, "Sofortzauber kosten weniger Mana.", "Instant spells cost less mana." },   -- Mentale Beweglichkeit
    },
    SHAMAN = {
        { 2, 1, 2, 5, "Mehr Intelligenz – mehr Mana.", "More Intellect – more mana." },   -- Wissen der Ahnen
        { 2, 2, 2, 5, "Mehr kritische Treffer; nötig für Schlaghagel.", "More critical hits; needed for Flurry." },   -- Donnernde Stöße
        { 2, 3, 3, 1, "Erlaubt Zweihandäxte und -streitkolben – mehr Schaden.", "Allows two-handed axes and maces – more damage." },   -- Zweihandäxte und -Streitkolben
        { 2, 3, 4, 4, "Du weichst öfter aus.", "You dodge more often." },   -- Vorahnung
        { 2, 4, 2, 5, "Nach kritischen Treffern schlägst du schneller zu.", "After critical hits you attack faster." },   -- Schlaghagel
        { 2, 5, 2, 3, "Waffenverzauberungen werden stärker; nötig für Sturmschlag.", "Weapon enchants get stronger; needed for Stormstrike." },   -- Elementarwaffen
        { 2, 5, 3, 1, "Du kannst parieren und erzeugst weniger Bedrohung.", "You can parry and generate less threat." },   -- Waffen der Geister
        { 2, 5, 1, 2, "Windzorn-Totem gibt mehr Angriffskraft.", "Windfury Totem gives more attack power." },   -- Verbesserte Waffentotems
        { 2, 6, 3, 5, "Mehr Schaden mit allen Waffen.", "More damage with all weapons." },   -- Waffenbeherrschung
        { 2, 7, 2, 1, "Sturmschlag: starker Sofortangriff.", "Stormstrike: a strong instant attack." },   -- Sturmschlag
        { 1, 1, 2, 5, "Schocks und Blitze kosten weniger Mana.", "Shocks and lightning cost less mana." },   -- Konvektion
        { 1, 1, 3, 5, "Blitzschlag und Erdschock machen mehr Schaden.", "Lightning Bolt and Earth Shock deal more damage." },   -- Erschütterung
        { 1, 2, 3, 3, "Flammenschock und Feuertotems machen mehr Schaden.", "Flame Shock and fire totems deal more damage." },   -- Ruf der Flamme
        { 1, 3, 1, 1, "Manchmal kostet dein nächster Zauber weniger Mana.", "Sometimes your next spell costs less mana." },   -- Elementarfokus
        { 1, 3, 2, 5, "Schocks öfter einsetzbar.", "Use shocks more often." },   -- Nachklingen
    },
    MAGE = {
        { 3, 1, 2, 5, "Frostblitz zaubert schneller – mehr Schaden pro Sekunde.", "Frostbolt casts faster – more damage per second." },   -- Verbesserter Frostblitz
        { 3, 1, 3, 3, "Alle deine Zauber treffen öfter.", "All your spells hit more often." },   -- Präzision
        { 3, 2, 1, 5, "Kritische Frosttreffer machen mehr Schaden.", "Critical Frost hits deal more damage." },   -- Eissplitter
        { 3, 2, 3, 2, "Frostnova öfter einsetzbar; nötig für Zertrümmern.", "Use Frost Nova more often; needed for Shatter." },   -- Verbesserte Frostnova
        { 3, 3, 1, 3, "Mehr Frostschaden.", "More Frost damage." },   -- Stechendes Eis
        { 3, 4, 3, 5, "Gegen eingefrorene Ziele triffst du viel öfter kritisch.", "Much more critical hits against frozen targets." },   -- Zertrümmern
        { 3, 4, 2, 3, "Frostzauber kosten weniger Mana.", "Frost spells cost less mana." },   -- Frost-Kanalisierung
        { 3, 5, 2, 1, "Eisblock rettet dich aus gefährlichen Lagen.", "Ice Block saves you in dangerous situations." },   -- Eisblock
        { 3, 5, 3, 3, "Kältekegel macht mehr Schaden.", "Cone of Cold deals more damage." },   -- Verbesserter Kältekegel
        { 3, 7, 2, 1, "Eisbarriere fängt Schaden ab – du kannst länger zaubern.", "Ice Barrier absorbs damage so you can keep casting." },   -- Eisbarriere
        { 1, 1, 1, 2, "Gegner widerstehen deinen Zaubern seltener.", "Enemies resist your spells less often." },   -- Arkanes Feingefühl
        { 1, 1, 2, 3, "Arkane Explosion trifft öfter – gut gegen Gruppen.", "Arcane Explosion hits more often – good against groups." },   -- Arkaner Fokus
        { 1, 2, 3, 5, "Manchmal kostet dein nächster Zauber kein Mana.", "Sometimes your next spell costs no mana." },   -- Arkane Konzentration
        { 1, 3, 3, 1, "Mehr Rüstung durch Intelligenz.", "More armor from Intellect." },   -- Arkane Widerstandsfähigkeit
        { 1, 3, 1, 2, "Grössere Reichweite der Arkanzauber.", "Longer range for Arcane spells." },   -- Arkane Geometrie
        { 1, 2, 1, 2, "Mehr Schaden mit dem Zauberstab.", "More wand damage." },   -- Zauberstab-Spezialisierung
        { 1, 4, 4, 3, "Mana-Regeneration läuft beim Zaubern teilweise weiter.", "Part of your mana regeneration continues while casting." },   -- Arkane Meditation
        { 1, 2, 2, 2, "Mehr Widerstand gegen alle Zauberschulen.", "More resistance against all spell schools." },   -- Magische Vereinnahmung
    },
    WARLOCK = {
        { 1, 1, 3, 5, "Verderbnis wirkt sofort – ein Zauber weniger zu warten.", "Corruption becomes instant – one less cast to wait for." },   -- Verbesserte Verderbnis
        { 1, 2, 3, 2, "Aderlass gibt mehr Mana.", "Life Tap gives more mana." },   -- Verbesserter Aderlass
        { 1, 2, 4, 3, "Blutsauger wirkt stärker je deiner Effekte auf dem Ziel.", "Drain Life is stronger for each of your effects on the target." },   -- Seelenentzug
        { 1, 3, 1, 3, "Omen der Pein macht mehr Schaden.", "Bane of Agony deals more damage." },   -- Verbessertes Omen der Pein
        { 1, 3, 2, 2, "Entziehen-Zauber werden seltener unterbrochen.", "Drain spells are interrupted less often." },   -- Teufelskonzentration
        { 1, 4, 2, 2, "Manchmal zaubert dein nächster Schattenblitz viel schneller.", "Sometimes your next Shadow Bolt casts much faster." },   -- Einbruch der Nacht
        { 1, 4, 1, 2, "Grössere Reichweite der Gebrechenszauber.", "Longer range for Affliction spells." },   -- Grimmige Reichweite
        { 1, 2, 4, 1, "Blutsauger noch stärker.", "Drain Life even stronger." },   -- Seelenentzug
        { 1, 5, 2, 1, "Lebensentzug: Schaden, der dich heilt.", "Siphon Life: damage that heals you." },   -- Lebensentzug
        { 1, 1, 2, 4, "Du triffst öfter und erzeugst weniger Bedrohung.", "You hit more often and generate less threat." },   -- Unterdrückung
        { 1, 6, 2, 5, "Mehr Schattenschaden.", "More Shadow damage." },   -- Schattenbeherrschung
        { 2, 1, 3, 5, "Mehr Ausdauer – mehr Leben.", "More Stamina – more health." },   -- Dämonische Umarmung
        { 2, 2, 2, 3, "Dein Leerwandler wird stärker.", "Your Voidwalker gets stronger." },   -- Verbesserter Leerwandler
        { 2, 2, 3, 5, "Deine Dämonen haben mehr Leben und Mana.", "Your demons have more health and mana." },   -- Teuflische Vitalität
        { 2, 3, 2, 1, "Teufelsbeherrschung: Dämon sofort neu beschwören.", "Fel Domination: resummon your demon instantly." },   -- Teufelsbeherrschung
        { 2, 2, 1, 2, "Lebenslinie überträgt mehr Leben.", "Health Funnel transfers more health." },   -- Verbesserte Lebenslinie
        { 2, 4, 3, 5, "Deine Dämonen machen mehr Schaden.", "Your demons deal more damage." },   -- Unheilige Macht
    },
    DRUID = {
        { 2, 1, 2, 5, "Prankenhieb, Klaue und Krallenhieb kosten weniger.", "Maul, Claw and Rake cost less." },   -- Wildheit
        { 2, 2, 3, 5, "Mehr Rüstung in Tiergestalt.", "More armor in animal forms." },   -- Dickes Fell
        { 2, 3, 3, 3, "Mehr kritische Treffer in Bär- und Katzengestalt.", "More critical hits in bear and cat form." },   -- Geschärfte Klauen
        { 2, 3, 1, 2, "Schneller in Katzengestalt – kürzere Wege.", "Faster in cat form – shorter travel." },   -- Schnelligkeit der Wildnis
        { 2, 4, 2, 3, "Mehr Angriffskraft in Tiergestalt; nötig für Herz der Wildnis.", "More attack power in animal forms; needed for Heart of the Wild." },   -- Raubtierschläge
        { 2, 4, 4, 2, "Mehr Wut bzw. Combopunkte bei kritischen Treffern.", "More rage or combo points on critical hits." },   -- Blutraserei
        { 2, 5, 1, 2, "Klaue, Krallenhieb und Prankenhieb machen mehr Schaden.", "Claw, Rake and Maul deal more damage." },   -- Ungezähmte Wut
        { 2, 3, 2, 1, "Wilde Attacke: in Bärengestalt zum Gegner springen.", "Feral Charge: leap to the enemy in bear form." },   -- Wilde Attacke (Bär)
        { 2, 4, 1, 2, "Schreddern kostet weniger Energie.", "Shred costs less energy." },   -- Schreddernde Angriffe
        { 2, 6, 2, 5, "Mehr Intelligenz und Tiergestalt wird stärker.", "More Intellect and stronger animal forms." },   -- Herz der Wildnis
        { 2, 7, 2, 1, "Rudelführer: mehr kritische Treffer in Tiergestalt.", "Leader of the Pack: more critical hits in animal forms." },   -- Rudelführer
        { 3, 1, 3, 5, "Beim Gestaltwechsel startest du mit Wut bzw. Energie.", "Shapeshifting starts you with rage or energy." },   -- Ingrimm
        { 3, 1, 2, 5, "Mal der Wildnis wird stärker.", "Mark of the Wild gets stronger." },   -- Verbessertes Mal der Wildnis
        { 3, 2, 1, 5, "Heilende Berührung zaubert schneller und du machst mehr Schaden.", "Healing Touch casts faster and you deal more damage." },   -- Naturalist
        { 3, 3, 2, 3, "Mana-Regeneration läuft beim Zaubern teilweise weiter.", "Part of your mana regeneration continues while casting." },   -- Reflexion
        { 3, 2, 3, 2, "Wutanfall gibt mehr Wut.", "Enrage gives more rage." },   -- Verbesserter Wutanfall
    },
}
