-- LevelPilot - Calib
-- Aus dem echten Spiel lernen, damit Planung und virtuelle Reise der Wirklichkeit naeher kommen:
--  * Kills pro Minute der eigenen Klasse (Abstand zwischen Monster-EP-Meldungen, Pausen ausgenommen)
--  * Quest-EP-Faktor von WoW Forever (echte EP bei der Abgabe gegen die Classic-Werte des Datenpakets)
--  * Abgleich der Level-Zeiten (echt gegen virtuelle Reise)
-- Gespeichert accountweit in LevelPilotDB.calib (nur Zahlen, keine Namen). Die virtuelle Reise schreibt nichts.

local _, LP = ...
local L = LP.L
local Ca = {}
LP:RegisterModule("Calib", Ca)

local KILL_GAP = 120          -- Sekunden: laengere Abstaende sind Pausen (Questgeber, Stadt, AFK), nicht Grinden
local KILL_MIN_SAMPLES = 20   -- erst ab so vielen Messungen den Messwert benutzen
local KPM_MIN, KPM_MAX = 0.6, 3.0
local XP_MIN_QUESTS = 5       -- erst ab so vielen abgegebenen Quests den Forever-Faktor benutzen
local XP_MIN, XP_MAX = 0.5, 3.0

-- 3.12.56 LW-5 E3: im Bereich der eigenen Spielversion (LP.Acc: Forever = LevelPilotDB, Classic Era = LevelPilotDB.era)
local function Store()
    local acc = LP.Acc and LP.Acc()
    if type(acc) ~= "table" then return nil end
    acc.calib = type(acc.calib) == "table" and acc.calib or {}
    return acc.calib
end
local function Calib()
    local acc = LP.Acc and LP.Acc()
    return type(acc) == "table" and acc.calib or nil
end
Ca.CalibTable = Calib

local function ClassKey()
    local _, class = UnitClass("player")
    return class or "?"
end

------------------------------------------------------------------------
-- Kills pro Minute
------------------------------------------------------------------------
local lastKill
function Ca:OnKill()
    if LP.Virtual and LP.Virtual.active then return end
    local now = GetTime()
    if lastKill and now - lastKill <= KILL_GAP and now - lastKill >= 2 then
        local s = Store()
        if s then
            s.kills = type(s.kills) == "table" and s.kills or {}
            local k = s.kills[ClassKey()] or { n = 0, sum = 0 }
            k.n, k.sum = k.n + 1, k.sum + (now - lastKill)
            -- gleitend: alte Messungen verlieren mit der Zeit an Gewicht (Ausruestung und Level aendern sich)
            if k.n > 400 then k.sum, k.n = k.sum * 0.5, k.n * 0.5 end
            s.kills[ClassKey()] = k
        end
    end
    lastKill = now
end

-- gemessene Kills pro Minute (nil = noch zu wenig Messungen)
function Ca:KillsPerMin()
    local s = Store()
    local k = s and type(s.kills) == "table" and s.kills[ClassKey()]
    if not k or k.n < KILL_MIN_SAMPLES or k.sum <= 0 then return nil, k and k.n or 0 end
    local kpm = 60 / (k.sum / k.n)
    return math.max(KPM_MIN, math.min(KPM_MAX, kpm)), k.n
end

------------------------------------------------------------------------
-- Quest-EP-Faktor (echt gegen Datenpaket)
------------------------------------------------------------------------
local factorCache, factorN
function Ca:QuestXPFactor()
    if factorCache ~= nil then return factorCache or nil, factorN end
    local ratios = {}
    for id, e in pairs(LP.db and LP.db.qdb or {}) do
        if type(e) == "table" and e.x and e.xl then
            local q = LP.QuestDB and LP.QuestDB:Get(id)
            local ql = q and q.level and q.level > 0 and q.level
            -- nur Abgaben ohne Abschlag (Spieler hoechstens 5 Level ueber der Quest) und mit Classic-Wert
            if q and q.xp and q.xp > 0 and ql and e.xl <= ql + 5 then
                ratios[#ratios + 1] = e.x / q.xp
            end
        end
    end
    factorN = #ratios
    if #ratios < XP_MIN_QUESTS then factorCache = false return nil, factorN end
    table.sort(ratios)
    local med = ratios[math.floor((#ratios + 1) / 2)]
    if #ratios % 2 == 0 then med = (ratios[#ratios / 2] + ratios[#ratios / 2 + 1]) / 2 end
    factorCache = math.max(XP_MIN, math.min(XP_MAX, med))
    return factorCache, factorN
end
function Ca:Invalidate() factorCache = nil end

------------------------------------------------------------------------
-- Level-Zeiten: echt gegen virtuelle Reise
------------------------------------------------------------------------
-- Liefert Zeilen { level, real, sim } fuer alle Level, die es in beiden gibt, und die mittlere Abweichung (%)
function Ca:CompareLevelTimes(levelAt, realTimes)
    local rows, sumDev, n = {}, 0, 0
    realTimes = realTimes or (LP.Virtual and LP.Virtual:RealChar() or LP.char or {}).levelTimes or {}
    for l = 1, 59 do
        local a, b = levelAt[l], levelAt[l + 1]
        local real = realTimes[l]
        if a and b and real and real > 60 then
            local sim = b.t - a.t
            rows[#rows + 1] = { level = l, real = real, sim = sim }
            sumDev = sumDev + math.abs(sim - real) / real
            n = n + 1
        end
    end
    return rows, n > 0 and math.floor(sumDev / n * 100 + 0.5) or nil
end

------------------------------------------------------------------------
-- Flugdauer (echte Fluege: Luftlinie Start -> Landung gegen gemessene Sekunden)
------------------------------------------------------------------------
local FLY_MIN_SAMPLES = 3
local FLY_LATE = 1.5           -- Sekunden: der Start wird so spaet erkannt (UnitOnTaxi gilt erst kurz danach)
local flight

function Ca:OnControlLost()
    if LP.Virtual and LP.Virtual.active then return end
    C_Timer.After(FLY_LATE, function()
        if not UnitOnTaxi or not LP.SafeValue(UnitOnTaxi("player")) then return end
        local i, n, w = LP.Geo:Player()
        flight = i and { t = GetTime() - FLY_LATE, i = i, n = n, w = w } or nil
    end)
end

function Ca:OnControlGained()
    local f = flight
    flight = nil
    if not f then return end
    C_Timer.After(1, function()
        if LP.Virtual and LP.Virtual.active then return end
        local i, n, w = LP.Geo:Player()
        if not i or i ~= f.i then return end            -- anderer Kontinent oder keine Position
        local secs = GetTime() - 1 - f.t
        local dist = LP.Geo:Dist(f.n, f.w, n, w)
        if dist < 300 or secs < 10 or secs > 1800 then return end
        local s = Store()
        if not s then return end
        local fl = type(s.flights) == "table" and s.flights or { n = 0, dist = 0, secs = 0 }
        fl.n, fl.dist, fl.secs = fl.n + 1, fl.dist + dist, fl.secs + secs
        if fl.n > 100 then fl.n, fl.dist, fl.secs = fl.n * 0.5, fl.dist * 0.5, fl.secs * 0.5 end
        s.flights = fl
        LP:Fire("CALIB_FLIGHT")
    end)
end

-- gelernte Flugdauer fuer eine Luftlinie (nil = noch zu wenig Fluege)
-- eigene Fluege und (solange es zu wenige sind) die anderer Spieler
local function FlightSums()
    local s = Store()
    local fl = s and type(s.flights) == "table" and s.flights or { n = 0, dist = 0, secs = 0 }
    local n, dist, secs = fl.n, fl.dist, fl.secs
    if n < FLY_MIN_SAMPLES and s and type(s.netFlights) == "table" then
        for _, v in pairs(s.netFlights) do n, dist, secs = n + (v[1] or 0), dist + (v[2] or 0), secs + (v[3] or 0) end
    end
    return n, dist, secs
end

function Ca:FlightSecs(dist)
    local n, d, secs = FlightSums()
    if n < FLY_MIN_SAMPLES or d <= 0 then return nil end
    return dist * secs / d
end

function Ca:FlightText()
    local n, d, secs = FlightSums()
    local per = d > 0 and secs / d * 1000
    return L("Flüge: %d gemessen · %s Sekunden je 1000 Yards Luftlinie", math.floor(n + 0.5),
        (n >= FLY_MIN_SAMPLES and per) and string.format("%.0f", per) or L["Annahme"])
end

-- eigene Flugsumme zum Teilen
function Ca:OwnFlights()
    local s = Store()
    local fl = s and type(s.flights) == "table" and s.flights
    if not fl or fl.n < 1 then return nil end
    return fl.n, fl.dist, fl.secs
end

------------------------------------------------------------------------
-- Diagnose-Text
------------------------------------------------------------------------
function Ca:StatusText()
    local kpm, kn = self:KillsPerMin()
    local f, fn = self:QuestXPFactor()
    return L("Kills pro Minute: %s (%d Messungen) · Quest-EP-Faktor: %s (%d Quests)",
        kpm and string.format("%.2f", kpm) or L["Annahme"], kn or 0, f and string.format("%.2f", f) or L["Annahme"], fn or 0)
        .. "\n" .. self:KillXPText()
end

------------------------------------------------------------------------
-- Dropraten der Questgegenstaende (Questie kennt nur, wer etwas fallen laesst, nicht wie oft)
-- calib.drops[Gegenstand] = { k = Kills der Droppenden, solange gebraucht, g = erhaltene Stueck }
-- calib.need[Gegenstand]  = benoetigte Anzahl (aus dem Questlog)
-- Fremde Messungen (Austausch) je Absender in calib.netDrops[Gegenstand][Absender] = { k, g } - so zaehlt eine
-- wiederholte Meldung nicht doppelt.
------------------------------------------------------------------------
local DROP_MIN_KILLS = 10       -- erst ab so vielen Kills eine Droprate benutzen
local NET_SENDERS = 20
local wanted, wantedT = {}, 0  -- [Gegenstand] = { npc = {[id]=true} } fuer offene Questziele im Log
local tagged = {}              -- [GUID] = NPC-ID: Gegner, die man selbst (oder das Begleittier) getroffen hat

local function Learning() return not (LP.Virtual and LP.Virtual.active) end

-- offene Gegenstands-Ziele im Questlog (alle paar Sekunden neu)
local function Wanted()
    if Ca.testWanted then return Ca.testWanted end          -- nur Testroutine (Sandbox)
    local now = GetTime()
    if now - wantedT < 5 then return wanted end
    wantedT = now
    wipe(wanted)
    local N = LevelPilotData and LevelPilotData.I
    for _, e in ipairs(LP.API.Quests()) do
        local q = LP.QuestDB and LP.QuestDB:Get(e.id)
        local objs = LP.API.Objectives(e.index) or {}
        for oi, o in ipairs(q and q.objectives or {}) do
            if o.kind == "item" and o.item then
                local it = N and N[o.item]
                local go = objs[oi]
                local open = not (go and go.finished)
                -- Gegenstaende auch aus Objekten (Kisten, Pflanzen): keine Kill-Rate messbar
                if open and it and it.dn and #it.dn > 0 and not (it.dob and #it.dob > 0) then
                    local w = { npc = {} }
                    for _, id in ipairs(it.dn) do w.npc[id] = true end
                    wanted[o.item] = w
                end
                if go and go.need and go.need > 0 then
                    local s = Store()
                    if s then
                        s.need = type(s.need) == "table" and s.need or {}
                        s.need[o.item] = go.need
                    end
                end
            end
        end
    end
    return wanted
end
Ca.Wanted = Wanted

local function NpcOf(guid)
    if type(guid) ~= "string" then return nil end
    local kind, id = guid:match("^(%a+)%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")
    if kind ~= "Creature" then return nil end
    return tonumber(id)
end
Ca.NpcOf = NpcOf

-- Kampf-Protokoll: getroffene Gegner merken, ihren Tod als Kill zaehlen (eigener Schlag oder Begleittier)
function Ca:OnCombatLog(_, sub, _, srcGUID, _, srcFlags, _, dstGUID)
    if not Learning() then return end
    -- moderner Client: geschuetzte Werte nicht anfassen
    local S = LP.SafeValue
    sub, srcGUID, srcFlags, dstGUID = S(sub), S(srcGUID), S(srcFlags), S(dstGUID)
    if not sub or not dstGUID then return end
    if sub == "UNIT_DIED" then
        local id = tagged[dstGUID]
        if id then
            tagged[dstGUID] = nil
            self:OnMobKill(id)
        end
        return
    end
    if not sub or not sub:find("_DAMAGE$") then return end
    local mine = srcGUID ~= nil and (srcGUID == S(UnitGUID("player")) or srcGUID == S(UnitGUID("pet")))
    if not mine and srcFlags and COMBATLOG_OBJECT_AFFILIATION_MINE and bit and bit.band then
        mine = bit.band(srcFlags, COMBATLOG_OBJECT_AFFILIATION_MINE) > 0
    end
    if not mine then return end
    local id = NpcOf(dstGUID)
    if id then tagged[dstGUID] = id end
end

function Ca:OnMobKill(npc)
    local s = Store()
    if not s then return end
    for item, w in pairs(Wanted()) do
        if w.npc[npc] then
            s.drops = type(s.drops) == "table" and s.drops or {}
            local d = s.drops[item] or { k = 0, g = 0 }
            d.k = d.k + 1
            if d.k > 400 then d.k, d.g = d.k * 0.5, d.g * 0.5 end
            s.drops[item] = d
        end
    end
end

-- Moderner Client (WoW Forever, Retail): kein Kampf-Protokoll. Dort zaehlt LevelPilot so (3.12.6):
-- Kill:  bei der Monster-EP-Meldung (CHAT_MSG_COMBAT_XP_GAIN) das tote Ziel, sonst spaetestens beim Pluendern
--        (LOOT_OPENED, GetLootSourceInfo). Jede Leiche zaehlt nur einmal (GUID) - auch Leichen ohne Beute zaehlen,
--        sobald sie Ziel waren; damit faellt die Rate nicht mehr zu hoch aus.
-- Stueck: nur was wirklich in der Tasche ankommt (CHAT_MSG_LOOT "Ihr bekommt Beute"), hoechstens so viele, wie die
--        Leichen im offenen Beutefenster vom gesuchten Gegenstand hatten. Bleibt etwas liegen (Tasche voll), zaehlt es
--        erst, wenn es spaeter wirklich aufgehoben wird.
-- Geschuetzte Werte werden nie benutzt; Taschendiebstahl (Ziel lebt noch) zaehlt nicht.
local looted = {}             -- [GUID] = true: diese Leiche ist schon als Kill gezaehlt
local lootedN = 0
local allow = {}              -- [Gegenstand] = Stueck, die im offenen Beutefenster gutgeschrieben werden duerfen
local allowT = 0              -- bis wann (GetTime) Beutemeldungen noch zu diesem Fenster gehoeren
local LOOT_GRACE = 3          -- Sekunden nach dem Schliessen des Beutefensters
local function IsPickpocket(guid)
    if not UnitGUID or not UnitIsDead or not UnitExists then return false end
    local S = LP.SafeValue
    if not S(UnitExists("target")) then return false end
    local tg = S(UnitGUID("target"))
    if tg == nil or tg ~= guid then return false end
    local dead = S(UnitIsDead("target"))
    return dead == false
end
Ca.IsPickpocket = IsPickpocket

-- eine Leiche als Kill zaehlen (nur einmal je GUID)
local function CountCorpse(guid, npc, w)
    if not guid or not npc or looted[guid] then return false end
    looted[guid] = true
    lootedN = lootedN + 1
    if lootedN > 500 then wipe(looted) lootedN = 0 looted[guid] = true end
    local s = Store()
    if not s then return false end
    s.drops = type(s.drops) == "table" and s.drops or {}
    for item, wi in pairs(w) do
        if wi.npc[npc] then
            local d = s.drops[item] or { k = 0, g = 0 }
            d.k = d.k + 1
            if d.k > 400 then d.k, d.g = d.k * 0.5, d.g * 0.5 end
            s.drops[item] = d
        end
    end
    return true
end

-- Monster-EP-Meldung: das tote Ziel ist der Kill (auch ohne Beute)
function Ca:OnXPKill()
    if not Learning() or not (LP.Game and LP.Game.IsModern) then return end
    if not UnitExists or not UnitGUID or not UnitIsDead then return end
    local S = LP.SafeValue
    if not S(UnitExists("target")) or S(UnitIsDead("target")) ~= true then return end
    local guid = S(UnitGUID("target"))
    local npc = NpcOf(guid)
    if not npc then return end
    local w = Wanted()
    local any = false
    for _, wi in pairs(w) do if wi.npc[npc] then any = true break end end
    if any then CountCorpse(guid, npc, w) end
end

function Ca:OnLootOpened()
    if not Learning() or not GetNumLootItems or not GetLootSourceInfo then return end
    local S = LP.SafeValue
    local G = LP.Game
    local w = Wanted()
    if not next(w) then return end
    local corpses = {}        -- [GUID] = NPC-ID der Leichen in diesem Fenster
    local avail = {}          -- [Gegenstand] = Stueck in diesem Fenster (von passenden Gegnern)
    local n = S(GetNumLootItems()) or 0
    for slot = 1, n do
        local raw = GetLootSlotLink and GetLootSlotLink(slot)
        if G and G.IsSecret and G.IsSecret(raw) then wipe(allow) return end      -- Link geschuetzt: Fenster auslassen
        local link = raw
        local item = type(link) == "string" and tonumber(link:match("|Hitem:(%d+)"))
        local src = { GetLootSourceInfo(slot) }
        for i = 1, #src, 2 do
            if G and G.AnySecret and G.AnySecret(src[i], src[i + 1]) then wipe(allow) return end   -- Quelle/Stueck geschuetzt
            local guid, qty = S(src[i]), S(src[i + 1])
            local npc = NpcOf(guid)
            if npc then
                if IsPickpocket(guid) then wipe(allow) return end      -- Taschendiebstahl: kein Kill, keine Stueck
                corpses[guid] = npc
                if item and w[item] and w[item].npc[npc] and type(qty) == "number" and qty > 0 then
                    avail[item] = (avail[item] or 0) + qty
                end
            end
        end
    end
    for guid, npc in pairs(corpses) do CountCorpse(guid, npc, w) end
    -- gutgeschrieben wird erst bei der Beutemeldung (was liegen bleibt, zaehlt nicht)
    wipe(allow)
    for item, qty in pairs(avail) do allow[item] = qty end
    allowT = math.huge
end

function Ca:OnLootClosed()
    if allowT == math.huge then allowT = GetTime() + LOOT_GRACE end
end

-- nur fuer die Testroutine: gezaehlte Leiche (oder alle) vergessen, Beutefenster schliessen
function Ca.ResetLooted(guid)
    wipe(allow) allowT = 0
    if guid then if looted[guid] then looted[guid] = nil lootedN = lootedN - 1 end return end
    wipe(looted) lootedN = 0
end

-- eigene Beutemeldung? (andere Gruppenmitglieder zaehlen nicht)
local selfPatterns
local function SelfLoot(msg)
    if not selfPatterns then
        selfPatterns = {}
        for _, f in ipairs({ LOOT_ITEM_SELF_MULTIPLE, LOOT_ITEM_SELF, LOOT_ITEM_PUSHED_SELF_MULTIPLE, LOOT_ITEM_PUSHED_SELF }) do
            if type(f) == "string" and f ~= "" then
                local pat = f:gsub("%%%d%$s", "\1"):gsub("%%%d%$d", "\2"):gsub("%%s", "\1"):gsub("%%d", "\2")
                pat = "^" .. pat:gsub("([%(%)%.%[%]%*%+%-%?%^%$%%])", "%%%1"):gsub("\1", ".+"):gsub("\2", "%%d+")
                selfPatterns[#selfPatterns + 1] = pat
            end
        end
    end
    if #selfPatterns == 0 then return true end           -- Spiel ohne Muster: wie bisher jede Meldung
    for _, pat in ipairs(selfPatterns) do if msg:find(pat) then return true end end
    return false
end

-- Beute: "Ihr bekommt Beute: [Gegenstand]x2"
function Ca:OnLoot(msg)
    if LP.Game and LP.Game.IsSecret(msg) then return end
    if not Learning() or type(msg) ~= "string" then return end
    local item = tonumber(msg:match("|Hitem:(%d+)"))
    if not item then return end
    local w = Wanted()[item]
    if not w then return end
    local n = tonumber(msg:match("|r%s*[xX×](%d+)")) or 1
    local s = Store()
    if not s then return end
    s.drops = type(s.drops) == "table" and s.drops or {}
    local d = s.drops[item] or { k = 0, g = 0 }
    if d.k <= 0 then return end                       -- Gegenstand ohne gezaehlten Kill (Handel, Post) zaehlt nicht
    if LP.Game and LP.Game.IsModern then
        -- moderner Client: nur eigene Beute aus dem gerade offenen (oder eben geschlossenen) Beutefenster
        if GetTime() > allowT or not SelfLoot(msg) then return end
        local a = allow[item] or 0
        if a <= 0 then return end
        n = math.min(n, a)
        allow[item] = a - n
    end
    d.g = d.g + n
    s.drops[item] = d
    LP:Fire("CALIB_DROP", item)
end

-- Droprate (Stueck je Kill) und Zahl der Kills dahinter; nil = noch zu wenig gemessen
function Ca:DropRate(item)
    local s = Store()
    if not s or not item then return nil end
    local k, g = 0, 0
    local own = type(s.drops) == "table" and s.drops[item]
    if own then k, g = own.k, own.g end
    -- eigene Messung reicht nicht: fremde Messungen dazu
    if k < DROP_MIN_KILLS then
        local net = type(s.netDrops) == "table" and s.netDrops[item]
        for _, v in pairs(net or {}) do k, g = k + (v[1] or 0), g + (v[2] or 0) end
    end
    if k < DROP_MIN_KILLS then return nil, k end
    return math.max(0.02, math.min(3, g / k)), k
end

function Ca:Need(item)
    local s = Store()
    return s and type(s.need) == "table" and s.need[item] or nil
end

function Ca:AddNetDrop(item, sender, k, g, need)
    local s = Store()
    if not s or not item or not sender then return end
    s.netDrops = type(s.netDrops) == "table" and s.netDrops or {}
    local t = s.netDrops[item] or {}
    if not t[sender] then
        local c = 0
        for _ in pairs(t) do c = c + 1 end
        if c >= NET_SENDERS then return end
    end
    t[sender] = { k, g }
    s.netDrops[item] = t
    if need then
        s.need = type(s.need) == "table" and s.need or {}
        s.need[item] = s.need[item] or need
    end
end

------------------------------------------------------------------------
-- Echte Mob-Level (WoW Forever kann von den Classic-Daten abweichen)
-- calib.mobs[NPC] = { lo, hi } aus Namensplaketten und Ziel. Benutzt wird nur ein hoeheres Level als im
-- Datenpaket (Pflichtregel: lieber vorsichtig). Fremde Meldungen in calib.netMobs[NPC] = { lo, hi, Anzahl }.
------------------------------------------------------------------------
function Ca:ObserveUnit(unit)
    if not Learning() or not unit or not LP.SafeValue(UnitExists(unit)) or LP.SafeValue(UnitIsPlayer(unit)) then return end
    if UnitPlayerControlled and LP.SafeValue(UnitPlayerControlled(unit)) then return end
    local id = UnitGUID and NpcOf(LP.SafeValue(UnitGUID(unit)))
    local N = LevelPilotData and LevelPilotData.N
    local npc = id and N and N[id]
    if not npc or not npc.lo then return end
    local lv = LP.SafeValue(UnitLevel(unit))
    if type(lv) ~= "number" or lv <= 0 then return end
    local s = Store()
    if not s then return end
    s.mobs = type(s.mobs) == "table" and s.mobs or {}
    local m = s.mobs[id]
    if not m then
        -- nur abweichende Gegner merken (spart Platz)
        if lv >= npc.lo and lv <= (npc.hi or npc.lo) then return end
        m = { lv, lv }
        s.mobs[id] = m
    else
        if lv < m[1] then m[1] = lv end
        if lv > m[2] then m[2] = lv end
    end
    if lv > (npc.hi or npc.lo) then
        LP:Fire("CALIB_MOB", id)
        if LP.Danger then LP:Throttle("calib_danger", 60, function() LP.Danger:Reset() end) end
    end
end

-- tiefstes echtes Level eines Gegners fuer die Planung (nie unter dem Datenpaket)
function Ca:MobLo(id, packLo)
    local s = Calib()
    if not s or not id or not packLo then return packLo end
    local lo = packLo
    local m = type(s.mobs) == "table" and s.mobs[id]
    if m and m[1] > lo then lo = m[1] end
    local nm = type(s.netMobs) == "table" and s.netMobs[id]
    if nm and (nm[3] or 0) >= 2 and nm[1] > lo then lo = nm[1] end    -- fremd: erst ab zwei Meldungen
    return lo
end

function Ca:AddNetMob(id, lo, hi)
    local s = Store()
    if not s then return end
    s.netMobs = type(s.netMobs) == "table" and s.netMobs or {}
    local m = s.netMobs[id]
    if m then m[1], m[2], m[3] = math.min(m[1], lo), math.max(m[2], hi), math.min((m[3] or 1) + 1, 50)
    else s.netMobs[id] = { lo, hi, 1 } end
end

-- Flugzeiten anderer Spieler (je Absender die zuletzt gemeldete Summe)
function Ca:AddNetFlights(sender, n, dist, secs)
    local s = Store()
    if not s then return end
    s.netFlights = type(s.netFlights) == "table" and s.netFlights or {}
    local c = 0
    for _ in pairs(s.netFlights) do c = c + 1 end
    if not s.netFlights[sender] and c >= NET_SENDERS then return end
    s.netFlights[sender] = { n, dist, secs }
end

function Ca:LearnText()
    local s = Store() or {}
    local function C(t) local c = 0 for _ in pairs(type(t) == "table" and t or {}) do c = c + 1 end return c end
    local rated = 0
    for item in pairs(type(s.drops) == "table" and s.drops or {}) do if self:DropRate(item) then rated = rated + 1 end end
    return L("Dropraten: %d Gegenstände gemessen (%d von anderen) · abweichende Mob-Level: %d (%d von anderen)",
        rated, C(s.netDrops), C(s.mobs), C(s.netMobs))
end

------------------------------------------------------------------------
-- EP je Kill (echte EP gegen die Classic-Formel, je Levelunterschied; im Dungeon getrennt)
-- calib.killxp[Unterschied -5..+4] = { n, sum }  (sum = Summe der Verhaeltnisse echt / Formel)
-- calib.dungeonxp = { n, sum }
-- Gemessen wird nur ueber UnitXP (nie der Nachrichtentext): EP-Aenderung bei einer Monster-EP-Meldung.
-- Nicht gezaehlt: Erholt-Bonus vorhanden, in einer Gruppe (EP geteilt), Level des Gegners unbekannt oder
-- geschuetzt (moderner Client: "secret values"), virtuelle Reise.
------------------------------------------------------------------------
local KXP_MIN = 20              -- Messungen je Stufe, ab denen der Messwert die Schaetzung ersetzt
local KXP_LO, KXP_HI = 0.2, 2.0 -- unplausible Verhaeltnisse verwerfen
local xpLast, xpMaxLast, xpLevelLast   -- letzter Stand von UnitXP
local xpDelta, xpDeltaT                -- letzte EP-Aenderung und Zeitpunkt
local pendingKill                      -- Monster-EP-Meldung, deren EP-Aenderung noch fehlt
local targetLevel, targetT             -- Level des Ziels, zuletzt ausserhalb des Schutzes gelesen
-- nur Testroutine: Messzustand vergessen (danach misst das Spiel wie nach dem Einloggen)
function Ca.ResetKillXP()
    xpLast, xpMaxLast, xpLevelLast, xpDelta, xpDeltaT, pendingKill, targetLevel, targetT = nil, nil, nil, nil, nil, nil, nil, nil
end

local function Plain(v)
    if LP.SafeValue then return LP.SafeValue(v) end
    return v
end

function Ca:ReadTarget()
    local lv = Plain(UnitLevel and UnitLevel("target"))
    if type(lv) == "number" and lv > 0 and LP.SafeValue(UnitExists("target")) and not LP.SafeValue(UnitIsPlayer("target")) then
        targetLevel, targetT = lv, GetTime()
    elseif LP.SafeValue(UnitExists("target")) then
        targetLevel = nil          -- neues Ziel, Level unbekannt oder geschuetzt: nicht dem alten zuordnen
    end
end

local function RecordKillXP(gain, mobLevel, inDungeon)
    local s = Store()
    if not s or not gain or gain <= 0 or not mobLevel then return end
    local pl = Plain(UnitLevel("player"))
    if type(pl) ~= "number" then return end
    local P = LP.Planner
    local formula = P and P.KillXPFormula and P:KillXPFormula(pl, mobLevel)
    if not formula or formula <= 0 then return end
    local r = gain / formula
    if inDungeon then
        if r < 0.05 or r > KXP_HI then return end
        local d = type(s.dungeonxp) == "table" and s.dungeonxp or { n = 0, sum = 0 }
        d.n, d.sum = d.n + 1, d.sum + r
        if d.n > 200 then d.n, d.sum = d.n * 0.5, d.sum * 0.5 end
        s.dungeonxp = d
        return
    end
    if r < KXP_LO or r > KXP_HI then return end
    local diff = math.max(-5, math.min(4, math.floor(mobLevel + 0.5) - pl))
    s.killxp = type(s.killxp) == "table" and s.killxp or {}
    local k = s.killxp[diff] or { n = 0, sum = 0 }
    k.n, k.sum = k.n + 1, k.sum + r
    if k.n > 200 then k.n, k.sum = k.n * 0.5, k.sum * 0.5 end   -- gleitend
    s.killxp[diff] = k
end

local function TryMeasure(gain)
    local pk = pendingKill
    pendingKill = nil
    if not pk then return end
    RecordKillXP(gain, pk.level, pk.dungeon)
end

-- EP-Stand: bei jeder Aenderung die Differenz merken (beim Levelaufstieg das alte Maximum dazu)
function Ca:OnXPUpdate()
    local xp, mx, lv = Plain(UnitXP("player")), Plain(UnitXPMax("player")), Plain(UnitLevel("player"))
    if type(xp) ~= "number" or type(mx) ~= "number" or type(lv) ~= "number" then xpLast = nil return end
    if xpLast and xpLevelLast then
        local d
        if lv == xpLevelLast then d = xp - xpLast
        elseif lv == xpLevelLast + 1 and xpMaxLast then d = (xpMaxLast - xpLast) + xp end
        if d and d > 0 then
            xpDelta, xpDeltaT = d, GetTime()
            if pendingKill and GetTime() - pendingKill.t <= 1.5 then TryMeasure(d) xpDelta = nil end
        end
    end
    xpLast, xpMaxLast, xpLevelLast = xp, mx, lv
end

-- Monster-EP-Meldung: nur zaehlen, wenn das Ergebnis eindeutig ist
function Ca:OnKillXPMessage()
    if not Learning() then return end
    pendingKill = nil
    if IsInGroup and IsInGroup() then return end                     -- EP geteilt
    local rested = Plain(GetXPExhaustion and GetXPExhaustion())
    if rested and (type(rested) ~= "number" or rested > 0) then return end   -- Erholt-Bonus: nicht zaehlen
    local lv = targetLevel
    if not lv or not targetT or GetTime() - targetT > 300 then return end
    local inDungeon = false
    if IsInInstance then local _, kind = IsInInstance() inDungeon = kind == "party" or kind == "raid" end
    local pk = { t = GetTime(), level = lv, dungeon = inDungeon }
    -- die EP-Aenderung kann vor oder nach der Meldung kommen
    if xpDelta and xpDeltaT and GetTime() - xpDeltaT <= 0.5 then
        pendingKill = pk
        TryMeasure(xpDelta)
        xpDelta = nil
    else
        pendingKill = pk
    end
end

-- gemessenes Verhaeltnis echt / Formel fuer einen Levelunterschied (nil = zu wenig Messungen)
function Ca:KillXPRatio(diff)
    local s = Calib()
    local k = s and type(s.killxp) == "table" and diff and s.killxp[diff]
    if not k or k.n < KXP_MIN then return nil end
    return k.sum / k.n, k.n
end

function Ca:DungeonXPRatio()
    local s = Calib()
    local d = s and type(s.dungeonxp) == "table" and s.dungeonxp
    if not d or d.n < KXP_MIN then return nil end
    return d.sum / d.n, d.n
end

-- "EP je Kill: gemessen n · grün x %"
function Ca:KillXPText()
    local s = Store() or {}
    local n = 0
    for _, k in pairs(type(s.killxp) == "table" and s.killxp or {}) do n = n + (k.n or 0) end
    local gsum, gn = 0, 0
    for diff = -5, -(LP.Planner and LP.Planner.GREEN_DIFF or 3) do
        local r = self:KillXPRatio(diff)
        if r then gsum, gn = gsum + r, gn + 1 end
    end
    local green
    if gn > 0 then green = string.format("%d %%", math.floor(gsum / gn * 100 + 0.5))
    else
        local f = LP.Planner and LP.Planner:GreenXPFactor(-5) or 1
        green = string.format("%d %% (%s)", math.floor(f * 100 + 0.5), L["Annahme"])
    end
    return L("EP je Kill: gemessen %d · grün %s", math.floor(n + 0.5), green)
end

function Ca:KillXPMeasured()
    for diff = -5, 4 do if self:KillXPRatio(diff) then return true end end
    return false
end

function Ca:Init()
    LP:On("CHAT_MSG_COMBAT_XP_GAIN", function() Ca:OnKill() Ca:OnKillXPMessage() Ca:OnXPKill() end)
    LP:On("PLAYER_XP_UPDATE", function() Ca:OnXPUpdate() end)
    LP:On("PLAYER_ENTERING_WORLD", function() Ca:OnXPUpdate() end)
    LP:On("PLAYER_TARGET_CHANGED", function() Ca:ReadTarget() end)
    -- Kampf-Protokoll: auf dem modernen Client (WoW Forever, Retail) fuer Addons gesperrt - dort nicht anmelden
    if not (LP.Game and LP.Game.IsModern) then
        LP:On("COMBAT_LOG_EVENT_UNFILTERED", function()
            if CombatLogGetCurrentEventInfo then Ca:OnCombatLog(CombatLogGetCurrentEventInfo()) end
        end)
    end
    LP:On("CHAT_MSG_LOOT", function(_, msg) Ca:OnLoot(msg) end)
    -- moderner Client ohne Kampf-Protokoll: Kills und Beute fuer die Dropraten beim Pluendern zaehlen
    if LP.Game and LP.Game.IsModern then
        LP:On("LOOT_OPENED", function() Ca:OnLootOpened() end)
        LP:On("LOOT_CLOSED", function() Ca:OnLootClosed() end)
    end
    LP:On("NAME_PLATE_UNIT_ADDED", function(_, unit) Ca:ObserveUnit(unit) end)
    LP:On("PLAYER_TARGET_CHANGED", function() Ca:ObserveUnit("target") end)
    LP:On("QUEST_LOG_UPDATE", function() wantedT = 0 end)
    LP:On("QUEST_TURNED_IN", function() Ca:Invalidate() end)
    LP:On("PLAYER_CONTROL_LOST", function() Ca:OnControlLost() end)
    LP:On("PLAYER_CONTROL_GAINED", function() Ca:OnControlGained() end)
end
