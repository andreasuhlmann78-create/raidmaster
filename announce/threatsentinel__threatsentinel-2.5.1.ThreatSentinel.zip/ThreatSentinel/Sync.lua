-- ThreatSentinel - Sync.lua
-- Austausch zwischen Spielern mit ThreatSentinel: Rollen, Spotts, Abklingzeiten, Meldungen.
-- Ersatzwege für WoW Forever:
--   * Mob-GUID geschützt: Spotts werden dem Mob zugeordnet, den der spottende Tank im Ziel hat
--   * Addon-Nachrichten gesperrt: andere Tanks werden trotzdem an ihrem Ziel erkannt (Kürzel an der Plakette)

local ADDON, ns = ...
local API = ns.API   -- Blizzard-Funktionen nur über ns.API (API.lua)
local L = ns.L

local S = {}
ns.Sync = S
table.insert(ns.modules, S)

local PREFIX = "ThreatSentinel"
S.PREFIX = PREFIX
local ROLE_TTL = 90
local CLAIM_TIME = 4

S.claims = {}   -- guid -> { name, t }
S.taunts = {}   -- Tank-Name -> Zeitpunkt seines letzten Spotts (für die Zuordnung ohne GUID)
S.cd = {}       -- Tank-Name -> Zeitpunkt, ab dem der Spott wieder bereit ist

local PALETTE = {
	{ 0.25, 0.65, 1 },
	{ 0.75, 0.35, 1 },
	{ 0.2, 0.9, 0.6 },
	{ 1, 0.45, 0.8 },
	{ 0.95, 0.95, 0.35 },
}

local lastHello = 0

local function Channel()
	if API.IsInRaid() then return "RAID" end
	if API.IsInGroup() then return "PARTY" end
end

function S:Send(msg)
	if not ns.db.sync then return end
	local ch = Channel()
	if not ch then return end
	-- moderne API: im Kampf keine Addon-Nachrichten (gesperrt); auch in der Simulation
	if API.InCombatLockdown() and (ns.simSecret or ns.isModern) then ns:Compat("sync", "fallback") return false end
	local ok, result = pcall(function()
		local CI = API.C_ChatInfo
		if CI and CI.SendAddonMessage then
			return ns.Act("addonmsg", CI.SendAddonMessage, PREFIX, msg, ch)
		elseif API.SendAddonMessage then
			return ns.Act("addonmsg", API.SendAddonMessage, PREFIX, msg, ch)
		end
		return false   -- keine Sendefunktion im Client
	end)
	-- In neueren Clients liefert SendAddonMessage einen Ergebniscode (0 = gesendet)
	local blocked = not ok or (not ns.IsSecret(result) and (result == false
		or (type(result) == "number" and result ~= 0)))
	ns:Compat("sync", blocked and "fallback" or "ok")
	return not blocked
end

function S:Init()
	local CI = API.C_ChatInfo
	if CI and CI.RegisterAddonMessagePrefix then
		pcall(CI.RegisterAddonMessagePrefix, PREFIX)
	elseif API.RegisterAddonMessagePrefix then
		pcall(API.RegisterAddonMessagePrefix, PREFIX)
	end
end

function S:Login()
	C_Timer.NewTicker(20, function() if not ns.routineRunning then S:Hello() end end)
	C_Timer.After(3, function() S:Hello(true) end)
end

function S:Hello(force)
	local now = GetTime()
	if not force and now - lastHello < 5 then return end
	lastHello = now
	self:Send("H:" .. ns:MyRole() .. ":" .. ns.version)
end

-- Eigener Spott gewirkt: Mob (falls bekannt) als übernommen melden, Abklingzeit mitsenden
function S:OnTaunt(guid)
	guid = guid or "-"
	API.C_Timer.After(0.2, function()
		local cd = math.floor(ns.SpellCD(ns.tauntSpell) + 0.5)
		S:Send("T:" .. guid .. ":" .. cd)
	end)
end

function S:IsFresh(name)
	local r = ns.syncRoles[name]
	return r and (GetTime() - r.t) < ROLE_TTL
end

function S:IsTank(name)
	if name == ns.playerName then return ns:IsTankStance() end
	local r = ns.syncRoles[name]
	if r and r.role == "TANK" and (GetTime() - r.t) < ROLE_TTL then return true end
	-- ohne Sync: Tank-Rolle oder Haupttank-Markierung in der Gruppe
	local u = ns.nameToUnit[name]
	return u and ns:GetRole(u) == "TANK" or false
end

function S:Tanks()
	local list, seen = {}, {}
	if ns:IsTankStance() then list[#list + 1] = ns.playerName; seen[ns.playerName] = true end
	for name, r in pairs(ns.syncRoles) do
		if r.role == "TANK" and GetTime() - r.t < ROLE_TTL and ns:InGroupByName(name) and not seen[name] then
			list[#list + 1] = name
			seen[name] = true
		end
	end
	-- Tanks ohne ThreatSentinel (Rolle / Haupttank) bekommen ebenfalls eine Farbe
	for name, u in pairs(ns.nameToUnit) do
		if not seen[name] and name ~= ns.playerName and ns:GetRole(u) == "TANK" then
			list[#list + 1] = name
			seen[name] = true
		end
	end
	table.sort(list)
	return list
end

function S:NumTanks()
	if not ns.db.sync then return 0 end
	return #self:Tanks()
end

function S:TankColor(name)
	if not name then return nil end
	for i, n in ipairs(self:Tanks()) do
		if n == name then return PALETTE[((i - 1) % #PALETTE) + 1] end
	end
	if ns.testMode then return name == ns.playerName and PALETTE[1] or PALETTE[2] end
end

function S:OtherTankReady()
	if not ns.db.sync then return nil end
	local now = GetTime()
	for name, r in pairs(ns.syncRoles) do
		if r.role == "TANK" and now - r.t < ROLE_TTL and ns:InGroupByName(name)
			and (ns.fakeNames[name] or not ns.Safe(API.UnitIsDeadOrGhost(name), false))
			and (not self.cd[name] or self.cd[name] <= now) then
			return name
		end
	end
end

-- Spott über die Mob-GUID zugeordnet
function S:Claim(guid)
	if not ns.db.sync or not guid then return nil end
	local c = self.claims[guid]
	if c and GetTime() - c.t < CLAIM_TIME then return c.name end
end

-- Ersatz ohne GUID: ein Tank hat eben gespottet und hat diesen Mob im Ziel
function S:ClaimByTarget(unit)
	if not ns.db.sync then return nil end
	local now = GetTime()
	for name, t in pairs(self.taunts) do
		if now - t < CLAIM_TIME then
			local u = ns.nameToUnit[name]
			if u and (ns:PlateFor(u .. "target") == unit or ns:SameUnit(unit, u .. "target")) then return name end
			if ns.fakeNames[name] and ns:SameUnit(unit, "target") then return name end
		end
	end
end

-- Ein anderer Tank hat diesen Mob im Ziel (auch ohne Addon-Nachrichten erkennbar)
function S:TankTargeting(unit)
	if not ns.db.sync then return nil end
	for name, u in pairs(ns.nameToUnit) do
		if name ~= ns.playerName and self:IsTank(name)
			and (ns:PlateFor(u .. "target") == unit or ns:SameUnit(unit, u .. "target")) then
			return name
		end
	end
end

function S:Users()
	local list = {}
	for name, r in pairs(ns.syncRoles) do
		if GetTime() - r.t < ROLE_TTL and ns:InGroupByName(name) then
			list[#list + 1] = { name = name, role = r.role, ver = r.ver }
		end
	end
	table.sort(list, function(a, b) return a.name < b.name end)
	return list
end

-- Verarbeitet eine Nachricht (vom Kanal oder aus der Testzentrale)
function S:Handle(name, msg)
	local cmd, rest = (msg or ""):match("^(%a):(.*)$")
	if not cmd then return end
	local now = GetTime()

	if cmd == "H" then
		local role, ver = rest:match("^(%u+):?(.*)$")
		if role then
			ns.syncRoles[name] = { role = role, t = now, ver = ver }
			ns:ClearRoleCache()
		end
	elseif cmd == "T" then
		local guid, cd = rest:match("^([^:]+):?(%d*)$")
		if guid and guid ~= "-" then S.claims[guid] = { name = name, t = now } end
		S.taunts[name] = now
		S.cd[name] = now + (tonumber(cd) or 10)
		local r = ns.syncRoles[name]
		if not r then ns.syncRoles[name] = { role = "TANK", t = now } else r.t = now end
	elseif cmd == "R" then
		ns.Alerts:RemoteResist(name)
	elseif cmd == "X" then
		ns.Alerts:RemoteCC(name, rest)
	end
end

ns:On("CHAT_MSG_ADDON", function(_, prefix, msg, _, sender)
	if prefix ~= PREFIX or not ns.db or not ns.db.sync then return end
	if ns.IsSecret(msg) or ns.IsSecret(sender) then return end
	local name = Ambiguate(sender or "", "none")
	if name == ns.playerName then return end
	S:Handle(name, msg)
end)

ns:On("GROUP_ROSTER_UPDATE", function()
	C_Timer.After(2, function() S:Hello() end)
end)

ns:On("PLAYER_REGEN_ENABLED", function()
	local now = GetTime()
	for guid, c in pairs(S.claims) do
		if now - c.t > 30 then S.claims[guid] = nil end
	end
end)
