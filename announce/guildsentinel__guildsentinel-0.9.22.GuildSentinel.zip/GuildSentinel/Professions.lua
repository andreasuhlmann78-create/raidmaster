-- GuildSentinel - Professions.lua
-- Berufe-Verzeichnis: Öffnet jemand ein Berufsfenster, liest GuildSentinel Stufe und alle Rezepte aus
-- und schickt sie an die Gilde. So weiß jeder mit dem Addon, wer was herstellen kann.
-- Zwei Wege, je nach Spielclient (ns.Game.MODERN_PROFESSIONS):
--   * WoW Forever: neues Berufsfenster im Retail-Stil (ProfessionsFrame, C_TradeSkillUI)
--   * Classic Era und TBC: klassisches Fenster (TradeSkillFrame, CraftFrame für Verzauberkunst)
-- Das Datenformat ist auf beiden Wegen gleich (Berufsname = Hauptberuf in der Sprache des Spiels).
-- Mit RaidMaster: GuildSentinel liest und schickt seine Berufe trotzdem selbst (seit 0.9.19; vorher schwieg es, und die
-- Daten kamen bei Mitgliedern ohne RaidMaster nie an). RaidMasters Daten (RaidMasterDB.prof) zeigt es zusätzlich an.
--
--   G.prof[Name] = { c = Klasse, t = Zeit, g = nur aus dem Spiel,
--                    p = { [Beruf] = { r = Stufe, m = Max, n = { Rezepte }, i = { Item-IDs }, s = { Rezept-IDs },
--                                      k = { Blizzard-Kategorie } } } }   (k optional, seit 0.9.22; nur WoW Forever)
-- Name = Schlüssel immer in der Form der Gildenliste (P.Key). s ist neu in 0.9.19 (ältere Versionen übergehen es).
--
-- Vollautomatisch (ohne Klick, nie im Kampf):
--   * eigene Berufe nach dem Einloggen an die Gilde (neu oder älter als 24 h), nach jedem Einlesen sofort
--   * Gilden-Berufsliste des Spiels mit Offline-Mitgliedern (Einstellung kurz ein, danach zurück) und aufgeklappt
--   * neue Rezepte sofort (NEW_RECIPE_LEARNED), Rezeptprobe mit IsPlayerSpell, Gilden-Rezepte des Spiels
-- Protokoll (Diag.lua, nur Zahlen und Berufsnamen, keine Spielernamen): BERUFE, GILDENREZEPTE, REZEPTPROBE

local ADDON, ns = ...
local L = ns.L
local P = {}
ns.Prof = P
local Game = ns.Game

-- Berufe mit Fenster (Zauber-ID zum Öffnen; der Name kommt aus dem Spiel, also in jeder Sprache richtig)
P.CRAFT_SPELLS = { 2259, 2018, 7411, 4036, 2108, 3908, 2550, 3273, 2656 }  -- Alchemie, Schmieden, Verzauberkunst, Ingenieur, Leder, Schneidern, Kochen, Erste Hilfe, Verhüttung
P.MINING = 2575

-- Zaubername über ns.API (moderner Weg zuerst, siehe API.lua)
local function SpellName(id) return ns.SpellName(id) end

local function Store()
	return ns.G().prof
end

local function Now() return GetTime and GetTime() or 0 end

------------------------------------------------------------
-- Namen: EIN Schlüssel je Spieler, immer so, wie er in der Gildenliste steht
-- (Realm-Zusatz, Gross-/Kleinschreibung, Vorname allein in Forever -> Name aus der Gildenliste)
------------------------------------------------------------
local keyCache, keyFor = {}, nil
function P.Key(name)
	if type(name) ~= "string" or ns.IsSecret(name) then return nil end
	local R = ns.Roster
	local by = R and R.byName or {}
	if keyFor ~= by then keyCache, keyFor = {}, by end      -- neue Gildenliste -> neu nachschlagen
	local c = keyCache[name]
	if c then return c end
	local short = ns.Short(name)
	if not short or short == "" then return nil end
	local k
	if by[short] then
		k = short
	else
		local pr = ns.Proper(short)
		if pr and by[pr] then
			k = pr
		else
			local e = ns.FindMember(short)
			k = (e and e.name) or pr
		end
	end
	if k and next(by) then keyCache[name] = k end
	return k
end

-- eigener Schlüssel (ohne Gildenliste: der eigene Name)
local function MyKey()
	return P.Key(ns.Me()) or ns.Me()
end
P.MyKey = MyKey

local function Valid(v) return type(v) == "table" and type(v.p) == "table" end

-- welcher von zwei Einträgen desselben Spielers gilt: Angaben des Spielers vor der Gilden-Berufsliste, sonst der neuere
local function Better(a, b)
	if a.g and not b.g then return b, a end
	if b.g and not a.g then return a, b end
	if (tonumber(b.t) or 0) > (tonumber(a.t) or 0) then return b, a end
	return a, b
end

-- zusammenführen (für den Speicher): Gewinner behalten, fehlende Stufen aus einem Eintrag des Spiels ergänzen
local function Merge(a, b)
	local win, lose = Better(a, b)
	if lose.g then
		for prof, v in pairs(lose.p) do
			if win.p[prof] == nil and type(v) == "table" then win.p[prof] = v end
		end
	end
	return win
end
P.Merge = Merge

-- Einträge unter einer anderen Schreibweise auf den Namen der Gildenliste umschlüsseln (doppelte zusammenführen).
-- Läuft nach jeder neuen Gildenliste; ohne Änderung kostet es nur einen Durchlauf.
function P:Rekey()
	local R = ns.Roster
	if not (ns.guild and R and R.byName and next(R.byName)) then return 0 end
	local s = Store()
	local keys = {}
	for k, v in pairs(s) do
		if type(k) == "string" and Valid(v) and not R.byName[k] then keys[#keys + 1] = k end
	end
	local moved = 0
	for _, k in ipairs(keys) do
		local nk = P.Key(k)
		if nk and nk ~= k and R.byName[nk] then
			local v = s[k]
			s[k] = nil
			s[nk] = Valid(s[nk]) and Merge(s[nk], v) or v
			moved = moved + 1
		end
	end
	ns.guild.profKeys = 1          -- Schalter: Umschlüsseln ist gelaufen (Daten ab 0.9.19)
	if moved > 0 then
		if ns.Diag then ns.Diag("BERUFE", string.format("umgeschlüsselt: %d Einträge (Name wie in der Gildenliste)", moved)) end
		ns:Fire("GS_PROF")
	end
	return moved
end
ns:Listen("GS_ROSTER", function() P:Rekey() end)

-- alle bekannten Berufe: eigene Daten plus die aus RaidMaster, je Spieler EIN Eintrag (Schlüssel wie Gildenliste)
function P:All()
	local out = {}
	local function add(k, v)
		-- kaputte Einträge (falscher Typ, z. B. nach einem Fehler in alten Daten) überspringen
		if type(k) ~= "string" or not Valid(v) then return end
		local key = P.Key(k) or k
		local cur = out[key]
		out[key] = cur and (Better(cur, v)) or v
	end
	for k, v in pairs(Store()) do add(k, v) end
	local rm = ns.RMI:Profs()
	if type(rm) == "table" then
		for k, v in pairs(rm) do add(k, v) end
	end
	return out
end

function P:Of(name)
	return self:All()[P.Key(name) or name]
end

local function Mine()
	local s = Store()
	local me = MyKey()
	-- früher unter dem eigenen Namen in anderer Schreibweise gespeichert: übernehmen
	local raw = ns.Me()
	if raw and raw ~= me and Valid(s[raw]) then
		s[me] = Valid(s[me]) and Merge(s[me], s[raw]) or s[raw]
		s[raw] = nil
	end
	if not Valid(s[me]) then s[me] = { p = {} } end
	s[me].g = nil              -- eigene Angaben ersetzen einen Eintrag aus der Gilden-Berufsliste
	s[me].c = select(2, UnitClass("player"))
	return s[me]
end
P.Mine = Mine

-- Zahlen für das Protokoll: Einträge im Speicher, davon mit Rezepten, davon nur Stufe aus dem Spiel
function P:StoreStats()
	local n, rec, g = 0, 0, 0
	for _, v in pairs(self:All()) do
		n = n + 1
		local has = false
		for _, x in pairs(v.p) do
			if type(x) == "table" and type(x.n) == "table" and #x.n > 0 then has = true break end
		end
		if has then rec = rec + 1 elseif v.g then g = g + 1 end
	end
	return n, rec, g
end

------------------------------------------------------------
-- Welcher Weg? Entscheidend ist der Spielclient; die Prüfung der Befehle ist nur ein Sicherheitsnetz
-- (fehlt die Schnittstelle des gewählten Wegs, wird der andere versucht und das einmal im Debug gemeldet)
------------------------------------------------------------
local warned = false
local function UseModern()
	local modernAPI = C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs and C_TradeSkillUI.GetRecipeInfo and true or false
	local classicAPI = (GetTradeSkillLine and GetNumTradeSkills) and true or false
	local modern
	if Game.MODERN_PROFESSIONS then
		modern = modernAPI or not classicAPI      -- nichts da: trotzdem modern versuchen (liefert dann nichts)
	else
		modern = (not classicAPI) and modernAPI
	end
	if modern ~= (Game.MODERN_PROFESSIONS and true or false) and not warned and (ns.debug or (ns.Test and ns.Test:Active())) then
		warned = true
		ns:Print("Berufsfenster: " .. (modern and "modern" or "klassisch") .. " (Sicherheitsnetz, Client erwartet anderes)")
	end
	return modern
end
P.UseModern = UseModern

-- Text für die Diagnose: "modern (Forever)" oder "klassisch"
function P:WindowKind()
	return UseModern() and L["modern (Forever)"] or L["klassisch"]
end

-- fremde Fenster (verlinkter Beruf, Gildenberuf, NPC) nicht einlesen
local function IsOwnTradeSkill()
	if C_TradeSkillUI then
		if C_TradeSkillUI.IsTradeSkillLinked and C_TradeSkillUI.IsTradeSkillLinked() then return false end
		if C_TradeSkillUI.IsTradeSkillGuild and C_TradeSkillUI.IsTradeSkillGuild() then return false end
		if C_TradeSkillUI.IsNPCCrafting and C_TradeSkillUI.IsNPCCrafting() then return false end
	end
	if IsTradeSkillLinked and IsTradeSkillLinked() then return false end
	return true
end

local function IDFromLink(link)
	return type(link) == "string" and tonumber(link:match("item:(%d+)")) or 0
end

-- Forever: Beruf, Stufe, Max – Name vom Basis-Beruf (Hauptberuf), Stufe vom Unterberuf, falls vorhanden
local function ModernProfession()
	local base = C_TradeSkillUI.GetBaseProfessionInfo and C_TradeSkillUI.GetBaseProfessionInfo()
	local child = C_TradeSkillUI.GetChildProfessionInfo and C_TradeSkillUI.GetChildProfessionInfo()
	local name = base and base.professionName
	local rank = (child and child.skillLevel) or (base and base.skillLevel)
	local max = (child and child.maxSkillLevel) or (base and base.maxSkillLevel)
	return name, rank, max
end

-- Forever: Item-ID des Ergebnisses (0 = kein Gegenstand, z. B. Verzauberung)
local function ModernOutputItem(recipeID)
	if C_TradeSkillUI.GetRecipeOutputItemData then
		local ok, data = pcall(C_TradeSkillUI.GetRecipeOutputItemData, recipeID)
		if ok and type(data) == "table" and data.itemID then return data.itemID end
	end
	if C_TradeSkillUI.GetRecipeItemLink then
		local ok, link = pcall(C_TradeSkillUI.GetRecipeItemLink, recipeID)
		if ok and link then return IDFromLink(link) end
	end
	return 0
end

-- Forever: alle gelernten Rezepte (GetAllRecipeIDs liefert alles, Filter im Fenster spielen keine Rolle)
-- spells = Rezept-IDs (in Forever gleich der Zauber-ID; für Rezeptprobe und Gilden-Rezepte)
local function ReadModern()
	if not C_TradeSkillUI then return nil, nil, nil, {}, {}, {}, {} end
	local profName, rank, max = ModernProfession()
	local ids, names, spells, cats = {}, {}, {}, {}
	local catName = {}
	-- Blizzard-Kategorie des Rezepts (z. B. "Helme", "Elixiere"); optional, nur wo das Spiel sie liefert
	local function Cat(id)
		if type(id) ~= "number" or ns.IsSecret(id) or not C_TradeSkillUI.GetCategoryInfo then return "" end
		if catName[id] == nil then
			local okc, ci = pcall(C_TradeSkillUI.GetCategoryInfo, id)
			local n = okc and type(ci) == "table" and ci.name
			catName[id] = (type(n) == "string" and not ns.IsSecret(n)) and n or ""
		end
		return catName[id]
	end
	local ok, all = pcall(C_TradeSkillUI.GetAllRecipeIDs)
	if ok and type(all) == "table" then
		for _, recipeID in ipairs(all) do
			local info = C_TradeSkillUI.GetRecipeInfo(recipeID)
			if info and info.learned and info.name then
				names[#names + 1] = info.name
				ids[#ids + 1] = ModernOutputItem(recipeID)
				spells[#spells + 1] = (type(recipeID) == "number" and not ns.IsSecret(recipeID)) and recipeID or 0
				cats[#cats + 1] = Cat(info.categoryID)
			end
		end
	end
	return profName, rank, max, ids, names, spells, cats
end

-- Zauber-ID aus einem Rezept-Link ("enchant:123" / "spell:123"), sonst 0
local function SpellFromLink(fn, i)
	if not fn then return 0 end
	local ok, link = pcall(fn, i)
	if not ok or type(link) ~= "string" or ns.IsSecret(link) then return 0 end
	return tonumber(link:match("enchant:(%d+)") or link:match("spell:(%d+)")) or 0
end

-- Stufen aller Berufe aus der Fertigkeitenliste (auch Sammelberufe)
function P:ReadSkillLines()
	local out = {}
	-- Forever: Berufe über GetProfessions / GetProfessionInfo
	if Game.MODERN_PROFESSIONS and GetProfessions and GetProfessionInfo then
		local slots = { GetProfessions() }
		for i = 1, 6 do
			local idx = slots[i]
			if idx then
				local name, _, rank, max = GetProfessionInfo(idx)
				if name then out[name] = { r = rank, m = max } end
			end
		end
		if next(out) then return out end
	end
	-- sonst (Classic, TBC, oder als Sicherheitsnetz): Fertigkeitenliste
	if not GetNumSkillLines then return out end
	local section
	for i = 1, GetNumSkillLines() do
		local name, isHeader, _, rank, _, _, max = GetSkillLineInfo(i)
		if isHeader then
			section = name
		elseif name and (section == TRADE_SKILLS or section == SECONDARY_SKILLS) then
			out[name] = { r = rank, m = max }
		end
	end
	return out
end

-- offenes Berufsfenster lesen ("trade" = Fertigkeitenfenster, "craft" = Verzauberkunst in Classic)
function P:ScanOpen(kind)
	if not ns.guild then return nil end
	-- Blizzards Gilden-Ansicht: nur als Kandidaten für Gilden-Rezepte merken (A2), nie als eigene Rezepte
	if self:ScanGuildView() then return nil end
	if not IsOwnTradeSkill() then return nil end
	local modern = UseModern()
	-- auch mit RaidMaster selbst lesen und senden (V1, 0.9.19): doppelt schadet nicht, Receive verwirft Älteres
	local profName, rank, max
	local ids, names, spells, cats = {}, {}, {}, {}
	if modern then
		profName, rank, max, ids, names, spells, cats = ReadModern()
	elseif kind == "craft" then
		if not GetCraftDisplaySkillLine then return nil end
		profName, rank, max = GetCraftDisplaySkillLine()
		for i = 1, (GetNumCrafts and GetNumCrafts() or 0) do
			local name, _, ctype = GetCraftInfo(i)
			if name and ctype ~= "header" then
				ids[#ids + 1] = IDFromLink(GetCraftItemLink and GetCraftItemLink(i))
				names[#names + 1] = name
				spells[#spells + 1] = SpellFromLink(ns.API.GetCraftRecipeLink, i)
			end
		end
	else
		if not GetTradeSkillLine then return nil end
		profName, rank, max = GetTradeSkillLine()
		-- Filter/zugeklappte Kategorien würden Rezepte verstecken: nur lesen, wenn alles sichtbar ist
		for i = 1, (GetNumTradeSkills and GetNumTradeSkills() or 0) do
			local name, ttype, _, expanded = GetTradeSkillInfo(i)
			if ttype == "header" and expanded == false and ExpandTradeSkillSubClass then
				ExpandTradeSkillSubClass(0)
				break
			end
		end
		for i = 1, (GetNumTradeSkills and GetNumTradeSkills() or 0) do
			local name, ttype = GetTradeSkillInfo(i)
			if name and ttype ~= "header" then
				ids[#ids + 1] = IDFromLink(GetTradeSkillItemLink and GetTradeSkillItemLink(i))
				names[#names + 1] = name
				spells[#spells + 1] = SpellFromLink(ns.API.GetTradeSkillRecipeLink, i)
			end
		end
	end
	if not profName or profName == "" or profName == "UNKNOWN" or #names == 0 then return nil end
	local me = Mine()
	local old = me.p[profName]
	-- Rezepte verlernt man nicht: bekannte behalten (falls ein Filter im Fenster welche versteckt)
	local seen = {}
	for _, n in ipairs(names) do seen[n] = true end
	if old and old.n then
		for k, n in ipairs(old.n) do
			if not seen[n] then
				names[#names + 1] = n
				ids[#ids + 1] = type(old.i) == "table" and old.i[k] or 0
				spells[#spells + 1] = type(old.s) == "table" and old.s[k] or 0
				cats[#names] = type(old.k) == "table" and type(old.k[k]) == "string" and old.k[k] or ""
				seen[n] = true
			end
		end
	end
	-- neue Rezepte (oder neuer Beruf): nach 4 s senden. Nur eine neue Stufe (Hochleveln bei offenem Fenster):
	-- höchstens alle 5 Minuten bzw. beim Schliessen des Fensters (LevelChanged)
	local recipesChanged = not old or #(old.n or {}) ~= #names
	local levelChanged = old and old.r ~= rank
	-- k (Blizzard-Kategorien) nur, wenn das Spiel welche geliefert hat (sonst kein leeres Feld mitsenden)
	local anyCat = false
	for _, c in pairs(cats) do if c ~= "" then anyCat = true break end end
	if anyCat then for k2 = 1, #names do cats[k2] = cats[k2] or "" end end
	me.p[profName] = { r = rank, m = max, n = names, i = ids, s = spells, k = anyCat and cats or nil }
	for name, v in pairs(self:ReadSkillLines()) do
		me.p[name] = me.p[name] or {}
		me.p[name].r, me.p[name].m = v.r, v.m
	end
	if recipesChanged then
		me.t = ns.Now()
		self:ScheduleSend()
	elseif levelChanged then
		self:LevelChanged()
	end
	self.scanned = self.scanned or {}
	self.scanned[profName] = true
	-- Protokoll nur, wenn sich die Rezeptzahl ändert (sonst nur zählen – sonst läuft es beim Hochleveln voll)
	self.toldCount = self.toldCount or {}
	if self.toldCount[profName] ~= #names then
		self.toldCount[profName] = #names
		if ns.Diag then ns.Diag("BERUFE", string.format("eingelesen: %s %d Rezepte", profName, #names)) end
	else
		self.scanQuiet = (self.scanQuiet or 0) + 1
	end
	ns:Fire("GS_PROF")
	return profName, #names, recipesChanged or levelChanged
end

-- nur die Stufe hat sich geändert: Zeit merken, höchstens alle 5 Minuten senden; beim Schliessen des Fensters sofort
P.LEVEL_EVERY = 300
function P:LevelChanged()
	local me = Mine()
	me.t = ns.Now()
	local now = Now()
	if (self.lvlSent or -1e9) <= now - P.LEVEL_EVERY then
		self.lvlSent = now
		self.lvlPending = false
		self:ScheduleSend()
		return true
	end
	if not self.lvlPending then
		self.lvlPending = true
		C_Timer.After(math.max(1, self.lvlSent + P.LEVEL_EVERY - now), function() P:FlushLevels() end)
	end
	return false
end

function P:FlushLevels()
	if not self.lvlPending then return false end
	self.lvlPending = false
	self.lvlSent = Now()
	self:ScheduleSend()
	return true
end

-- nur Stufen (z. B. Kräuterkunde) ohne Fenster
function P:UpdateLevels()
	if not ns.guild then return end
	local me = Mine()
	local level, removed
	local now = self:ReadSkillLines()
	for name, v in pairs(now) do
		if type(me.p[name]) ~= "table" then me.p[name] = {}; removed = true end    -- neuer Beruf: wie eine echte Änderung
		if me.p[name].r ~= v.r then level = true end
		me.p[name].r, me.p[name].m = v.r, v.m
	end
	-- verlernte Berufe entfernen
	if next(now) then
		for name in pairs(me.p) do
			if not now[name] and not self:IsCraftName(name) then me.p[name] = nil; removed = true end
		end
	end
	if removed then
		me.t = ns.Now()
		self:ScheduleSend()
	elseif level then
		self:LevelChanged()
	end
	if removed or level then ns:Fire("GS_PROF") end
end
ns:On("TRADE_SKILL_CLOSE", function() P:FlushLevels() end)
ns:On("CRAFT_CLOSE", function() P:FlushLevels() end)

function P:IsCraftName(name)
	for _, id in ipairs(self.CRAFT_SPELLS) do
		if SpellName(id) == name then return true end
	end
	return false
end

local function AfterScan(kind)
	local name, n = P:ScanOpen(kind)
	if name and P.announce then
		P.announce = nil
		ns:Print(string.format(L["%s eingelesen (%d Rezepte)."], name, n))
	end
end
-- ist das Berufsfenster offen? (Forever: ProfessionsFrame, Classic/TBC: TradeSkillFrame)
local function TradeWindowShown()
	if Game.MODERN_PROFESSIONS and ProfessionsFrame then return ProfessionsFrame:IsShown() and true or false end
	return (TradeSkillFrame and TradeSkillFrame:IsShown()) and true or false
end
P.TradeWindowShown = TradeWindowShown

-- Änderungen sammeln: höchstens ein Lesen pro Sekunde
local function LaterScan()
	if P.tsPending then return end
	P.tsPending = true
	C_Timer.After(1, function() P.tsPending = false; if TradeWindowShown() then AfterScan("trade") end end)
end

ns:On("TRADE_SKILL_SHOW", function() C_Timer.After(0.4, function() AfterScan("trade") end) end)
ns:On("TRADE_SKILL_UPDATE", LaterScan)
if Game.MODERN_PROFESSIONS then
	-- Forever: die Rezeptliste ist bei TRADE_SKILL_SHOW oft noch nicht fertig geladen
	ns:On("TRADE_SKILL_LIST_UPDATE", LaterScan)
	ns:On("TRADE_SKILL_DATA_SOURCE_CHANGED", LaterScan)
else
	ns:On("CRAFT_SHOW", function() C_Timer.After(0.4, function() AfterScan("craft") end) end)
end
ns:On("SKILL_LINES_CHANGED", function()
	if P.slPending then return end
	P.slPending = true
	C_Timer.After(2, function() P.slPending = false; P:UpdateLevels() end)
end)

------------------------------------------------------------
-- Berufe mit Fenster, die ich habe (für den Knopf "Nächsten Beruf öffnen")
------------------------------------------------------------
function P:Openable()
	local list = {}
	local skills = self:ReadSkillLines()
	for _, id in ipairs(self.CRAFT_SPELLS) do
		local name = SpellName(id)
		if name then
			local skill = (id == 2656) and SpellName(self.MINING) or name
			if skills[skill] or skills[name] then list[#list + 1] = name end
		end
	end
	return list
end

-- Forever: Berufsfenster über C_TradeSkillUI öffnen (skillLine steht in GetProfessionInfo an 7. Stelle; Verhüttung
-- gehört zu Bergbau). Nur aus einem Klick des Spielers aufrufen, nie aus einem Timer oder Ereignis: OpenTradeSkill ist
-- in Forever geschützt (sonst "Aktion blockiert"). Seit 0.9.14 ruft GuildSentinel es selbst nicht mehr auf.
function P:OpenModern(name)
	if InCombatLockdown and InCombatLockdown() then return false end
	if not (Game.MODERN_PROFESSIONS and C_TradeSkillUI and C_TradeSkillUI.OpenTradeSkill and GetProfessions and GetProfessionInfo) then return false end
	if TradeWindowShown() then return true end
	local want = (name == SpellName(2656)) and SpellName(self.MINING) or name
	local slots = { GetProfessions() }
	for i = 1, 6 do
		local idx = slots[i]
		if idx then
			local pname, _, _, _, _, _, skillLine = GetProfessionInfo(idx)
			if pname and pname == want and skillLine then
				pcall(ns.Act, "OpenTradeSkill", C_TradeSkillUI.OpenTradeSkill, skillLine)
				return true
			end
		end
	end
	return false
end

-- welchen Beruf der Knopf als Nächstes öffnet (nil = alle durch)
function P:NextToOpen()
	self.scanned = self.scanned or {}
	for _, name in ipairs(self:Openable()) do
		if not self.scanned[name] then return name end
	end
	return nil
end

function P:ReadNext()
	ns:Print(L["Öffne jedes Berufsfenster einmal (oder nutze den Knopf auf der Seite Berufe) – GuildSentinel liest es automatisch."])
	if ns.UI then ns.UI:Open("prof") end
end

------------------------------------------------------------
-- An die Gilde
------------------------------------------------------------
function P:ScheduleSend()
	if self.sendPending then return end
	self.sendPending = true
	C_Timer.After(4, function()
		self.sendPending = false
		self:SendMine()
	end)
end

-- Protokoll: gesendet ja/nein mit Grund (gleiche Zeile direkt hintereinander zählt Diag nur hoch)
function P:TellSent(yes, why)
	self.lastSent = { yes = yes, why = why }
	if ns.Diag then ns.Diag("BERUFE", string.format("gesendet: eigene=%s (%s)", yes and "ja" or "nein", why)) end
end

-- eigene Berufe an die Gilde (oder per Flüstern an target). Immer, auch wenn RaidMaster geladen ist (V1).
function P:SendMine(channel, target)
	local me = Store()[MyKey()]
	if not ns.InGuild() then self:TellSent(false, "nicht in einer Gilde") return false end
	if not Valid(me) or not next(me.p) then self:TellSent(false, "kein Eintrag") return false end
	if not me.t then me.t = ns.Now() end
	ns.Comm:Send("PROF", { n = MyKey(), c = me.c, t = me.t, p = me.p }, channel or "GUILD", target)
	if (channel or "GUILD") == "GUILD" and ns.guild then
		ns.guild.profSent = ns.Now()
		ns.guild.profSentT = me.t
	end
	self:TellSent(true, ns.RMI:Active() and "gesendet, RaidMaster aktiv" or "gesendet")
	return true
end

-- Empfang zählen; das Protokoll bekommt eine Zeile je 30 Sekunden (nur Zahlen)
P.rx = { n = 0, a = 0, o = 0, u = 0 }
function P:RxTell()
	if self.rxPending then return end
	self.rxPending = true
	C_Timer.After(30, function() P:RxFlush() end)
end
function P:RxFlush()
	self.rxPending = false
	local rx = self.rx
	if rx.n > 0 and ns.Diag then
		ns.Diag("BERUFE", string.format("empfangen: %d Einträge, angenommen %d, älter verworfen %d, Name unbekannt %d", rx.n, rx.a, rx.o, rx.u))
	end
	self.rx = { n = 0, a = 0, o = 0, u = 0 }
end

-- Berufsdaten aus einer Addon-Nachricht in der Tiefe prüfen: nur Tabellen, Namen als Text, Zahlen als Zahl.
-- Listen n, i, s bleiben gleich lang (fehlende Werte 0). nil = nichts Brauchbares.
function P.CleanProf(p)
	if type(p) ~= "table" then return nil end
	local out, any = {}, false
	for prof, v in pairs(p) do
		if type(prof) == "string" and prof ~= "" and #prof <= 60 and type(v) == "table" then
			local c = { r = tonumber(v.r), m = tonumber(v.m) }
			if type(v.n) == "table" then
				local n, i, sp, ct = {}, {}, {}, {}
				local vi = type(v.i) == "table" and v.i or {}
				local vs = type(v.s) == "table" and v.s or {}
				local vk = type(v.k) == "table" and v.k or nil      -- optional (seit 0.9.22): Blizzard-Kategorie
				for k, name in ipairs(v.n) do
					if type(name) == "string" and name ~= "" then
						n[#n + 1] = name:sub(1, 120)
						i[#n] = tonumber(vi[k]) or 0
						sp[#n] = tonumber(vs[k]) or 0
						if vk then ct[#n] = (type(vk[k]) == "string" and vk[k]:sub(1, 60)) or "" end
					end
				end
				c.n, c.i, c.s = n, i, sp
				if vk then c.k = ct end
			end
			out[prof] = c
			any = true
		end
	end
	return any and out or nil
end

-- d.n erlaubt es, beim Abgleich auch die Daten anderer weiterzugeben. Der Name wird auf die Form der Gildenliste
-- gebracht (V2): "testa beispiel-Realm" und "Testa Beispiel" sind derselbe Eintrag.
function P:Receive(sender, d)
	if type(d) ~= "table" then return end
	local clean = P.CleanProf(d.p)
	if not clean then return end
	local raw = (type(d.n) == "string" and d.n ~= "") and d.n or sender
	local who = P.Key(raw)
	if not who or who == MyKey() or ns.Same(who, ns.Me()) then return end
	local rx = self.rx
	rx.n = rx.n + 1
	local by = ns.Roster.byName
	if next(by) and not by[who] then rx.u = rx.u + 1 end
	local s = Store()
	-- alter Eintrag unter einer anderen Schreibweise: zuerst zusammenführen
	local short = ns.Short(raw)
	if short and short ~= who and Valid(s[short]) then
		s[who] = Valid(s[who]) and Merge(s[who], s[short]) or s[short]
		s[short] = nil
	end
	local old = Valid(s[who]) and s[who] or nil
	local t = tonumber(d.t) or 0
	-- Einträge aus der Gilden-Berufsliste (g) weichen immer den Angaben eines Spielers
	local reject = (old and not old.g and (d.g or (tonumber(old.t) or 0) >= t))
		or (old and old.g and d.g and (tonumber(old.t) or 0) >= t)
	if reject then
		rx.o = rx.o + 1
		self:RxTell()
		return
	end
	s[who] = { c = type(d.c) == "string" and d.c or nil, t = t, p = clean, g = d.g and true or nil }
	rx.a = rx.a + 1
	self:RxTell()
	ns:Fire("GS_PROF")
end

ns.Comm:Register("PROF", function(sender, d) P:Receive(sender, d) end)

-- eigene Berufe nach dem Einloggen (V3): jedes Mitglied schickt seine EIGENEN Berufe selbst, wenn sie seit dem letzten
-- Senden neu sind oder älter als 24 h (force: sofort, z. B. gerade beigetreten). So hängt niemand davon ab, dass der eine
-- Antwortende beim Abgleich die Daten eines Dritten hat.
function P:SendLogin(force)
	self:UpdateLevels()
	local g = ns.guild
	if not g then return false end
	local me = Store()[MyKey()]
	if not Valid(me) then self:TellSent(false, "kein Eintrag") return false end
	local new = (tonumber(me.t) or 0) > (tonumber(g.profSentT) or 0)
	local old = (tonumber(g.profSent) or 0) < ns.Now() - 86400
	if force or new or old then return self:SendMine() end
	self:TellSent(false, "unverändert, gesendet vor weniger als 24 h")
	return false
end
P.SendDaily = P.SendLogin       -- alter Name (Testroutine, andere Stellen)

-- nach dem Einloggen: Zufallsverzögerung 10–60 s (nicht alle gleichzeitig), danach Rezeptprobe und Gilden-Rezepte
ns:Listen("GS_LOGIN", function()
	C_Timer.After(10 + math.random() * 50, function() P:SendLogin() end)
	C_Timer.After(75, function() P:RecipeProbe() end)
	C_Timer.After(120, function() P:GuildRecipesStart() end)
end)

-- neu in einer Gilde (beigetreten, während man online ist): Berufe gleich schicken, nicht erst beim nächsten Login
ns:On("PLAYER_GUILD_UPDATE", function()
	if P.guildWait then return end
	P.guildWait = true
	C_Timer.After(15, function()
		P.guildWait = nil
		local g = ns.guild
		if g and not g.profSent then P:SendLogin(true) end
	end)
end)

------------------------------------------------------------
-- Neue Rezepte sofort (A3): NEW_RECIPE_LEARNED, ohne offenes Berufsfenster
------------------------------------------------------------
local function HasRecipe(v, id, name)
	if type(v) ~= "table" or type(v.n) ~= "table" then return false end
	for k, n in ipairs(v.n) do
		if n == name or (id and id > 0 and type(v.s) == "table" and v.s[k] == id) then return true end
	end
	return false
end

-- ein Rezept an den eigenen Beruf hängen (Listen n, i, s bleiben gleich lang)
local function AddRecipe(v, name, item, id)
	if type(v.n) ~= "table" then v.n = {} end
	if type(v.i) ~= "table" then v.i = {} end
	if type(v.s) ~= "table" then v.s = {} end
	for k = #v.i + 1, #v.n do v.i[k] = 0 end
	for k = #v.s + 1, #v.n do v.s[k] = 0 end
	local k = #v.n + 1
	v.n[k], v.i[k], v.s[k] = name, item or 0, id or 0
end
P.AddRecipe = AddRecipe

-- Rezept-ID -> { prof, name, item } aus allen bekannten Angaben (eigene, Gilde, Gilden-Ansicht des Spiels)
function P:SpellIndex()
	local out = {}
	for _, e in pairs(self:All()) do
		for prof, v in pairs(e.p) do
			if type(v) == "table" and type(v.s) == "table" and type(v.n) == "table" then
				for k, id in ipairs(v.s) do
					id = tonumber(id)
					if id and id > 0 and not out[id] and type(v.n[k]) == "string" then
						out[id] = { prof = prof, name = v.n[k], item = type(v.i) == "table" and tonumber(v.i[k]) or 0 }
					end
				end
			end
		end
	end
	for prof, list in pairs(self.guildView or {}) do
		for id, x in pairs(list) do
			if not out[id] then out[id] = { prof = prof, name = x.name, item = x.item or 0 } end
		end
	end
	return out
end

-- meine Berufe (Namen wie im Speicher)
function P:MyProfs()
	local out = {}
	local me = Store()[MyKey()]
	if Valid(me) then for prof in pairs(me.p) do out[prof] = true end end
	for name in pairs(self:ReadSkillLines()) do out[name] = true end
	return out
end

-- zu welchem meiner Berufe gehört ein Rezept?
function P:RecipeProf(id)
	local A = ns.API
	local mine = self:MyProfs()
	local function ok(name)
		return type(name) == "string" and name ~= "" and not ns.IsSecret(name) and mine[name] and name or nil
	end
	if A.GetProfessionInfoByRecipeID then
		local okc, info = pcall(A.GetProfessionInfoByRecipeID, id)
		if okc and type(info) == "table" then
			local n = ok(info.parentProfessionName) or ok(info.professionName)
			if n then return n end
		end
	end
	if A.GetTradeSkillLineForRecipe then
		local okc, _, lineName, _, parentName = pcall(A.GetTradeSkillLineForRecipe, id)
		if okc then
			local n = ok(parentName) or ok(lineName)
			if n then return n end
		end
	end
	local x = self:SpellIndex()[id]
	return x and ok(x.prof) or nil
end

local function ItemOf(id)
	local A = ns.API
	if A.GetRecipeOutputItemData then
		local okc, data = pcall(A.GetRecipeOutputItemData, id)
		if okc and type(data) == "table" and tonumber(data.itemID) then return tonumber(data.itemID) end
	end
	local x = P:SpellIndex()[id]
	return x and x.item or 0
end

-- id = Zauber-/Rezept-ID aus NEW_RECIPE_LEARNED. true = übernommen
function P:LearnRecipe(id)
	if ns.IsSecret(id) or type(id) ~= "number" or id <= 0 or not ns.guild then return false end
	if ns.InCombat() then
		self.learnQueue = self.learnQueue or {}
		self.learnQueue[#self.learnQueue + 1] = id
		return false, "Kampf"
	end
	local name = SpellName(id)
	if type(name) ~= "string" or ns.IsSecret(name) or name == "" then return false, "Name unbekannt" end
	local prof = self:RecipeProf(id)
	if not prof then
		-- das offene Fenster liest das neue Rezept ohnehin
		if TradeWindowShown() then LaterScan() end
		if ns.Diag then ns.Diag("BERUFE", "neues Rezept: Beruf unbekannt (wird beim nächsten Öffnen des Fensters gelesen)") end
		return false, "Beruf unbekannt"
	end
	local me = Mine()
	local v = me.p[prof]
	if type(v) ~= "table" then v = {}; me.p[prof] = v end
	if HasRecipe(v, id, name) then return false, "schon bekannt" end
	AddRecipe(v, name, ItemOf(id), id)
	me.t = ns.Now()
	self:ScheduleSend()
	if ns.Diag then ns.Diag("BERUFE", string.format("neues Rezept: %s, jetzt %d Rezepte", prof, #v.n)) end
	ns:Fire("GS_PROF")
	return true
end

ns:On("NEW_RECIPE_LEARNED", function(id) P:LearnRecipe(id) end)
ns:On("PLAYER_REGEN_ENABLED", function()
	local q = P.learnQueue
	if not q then return end
	P.learnQueue = nil
	C_Timer.After(1, function() for _, id in ipairs(q) do P:LearnRecipe(id) end end)
end)

------------------------------------------------------------
-- Rezeptprobe ohne Fenster (A4): bekannte Rezept-IDs mit IsPlayerSpell prüfen. Die Liste der Rezept-IDs kommt aus
-- den Angaben der Gilde (Feld s) und aus Blizzards Gilden-Ansicht – ProfessionSentinel hat keine öffentliche Liste.
-- Nur, wenn die Probe stimmt: ein Rezept aus meinem letzten Einlesen -> true, eines aus einem fremden Beruf -> false.
-- Stimmt sie nicht, ist der Weg bis zur nächsten Version aus.
------------------------------------------------------------
function P:RecipeProbe()
	local g = ns.guild
	if not g or ns.InCombat() then return nil end
	local Known = ns.API.IsPlayerSpell
	local way = Known and "IsPlayerSpell" or "keiner"
	local function tell(probe, found, extra)
		if ns.Diag then ns.Diag("REZEPTPROBE", string.format("Weg=%s Probe=%s · gefunden %d%s", way, probe, found, extra or "")) end
	end
	if not Known then tell("-", 0) return 0, "kein Weg" end
	if g.probeOff == ns.version then return 0, "aus" end
	local me = Store()[MyKey()]
	local mine = self:MyProfs()
	local index = self:SpellIndex()
	local known, unknown
	if Valid(me) then
		for _, v in pairs(me.p) do
			if type(v) == "table" and type(v.s) == "table" then
				for _, id in ipairs(v.s) do
					id = tonumber(id)
					if id and id > 0 then known = id break end
				end
			end
			if known then break end
		end
	end
	for id, x in pairs(index) do
		if not mine[x.prof] then unknown = id break end
	end
	if not known or not unknown then tell("zu wenig Daten", 0) return 0, "zu wenig Daten" end
	local ok1, k1 = pcall(Known, known)
	local ok2, k2 = pcall(Known, unknown)
	if not (ok1 and k1 == true and ok2 and k2 == false) then
		g.probeOff = ns.version
		tell("falsch", 0, " (Weg abgeschaltet)")
		return 0, "falsch"
	end
	local found = 0
	for id, x in pairs(index) do
		if mine[x.prof] and Valid(me) and not HasRecipe(me.p[x.prof], id, x.name) then
			local okc, k = pcall(Known, id)
			if okc and k == true then
				local v = me.p[x.prof]
				if type(v) ~= "table" then v = {}; me.p[x.prof] = v end
				AddRecipe(v, x.name, x.item, id)
				found = found + 1
			end
		end
	end
	if found > 0 then
		me.t = ns.Now()
		self:ScheduleSend()
		ns:Fire("GS_PROF")
	end
	tell("ok", found)
	return found, "ok"
end

------------------------------------------------------------
-- Blizzards Gilden-Rezepte (A2): wer in der Gilde welches Rezept kann. Nur wo das Spiel die Abfrage anbietet;
-- ohne Klick, gedrosselt (ein Rezept je 1,5 s), je Beruf einmal am Tag, nie im Kampf. Ergebnis als Einträge mit g = true
-- (Quelle Spiel); Angaben eines Spielers gehen immer vor. Blockiert das Spiel die Abfrage, ist der Weg bis zur nächsten
-- Version aus – dann liest GuildSentinel die Gilden-Ansicht, wenn der Spieler sie selbst öffnet (ScanGuildView).
------------------------------------------------------------
P.gr = { queue = {}, profs = 0, entries = 0 }
P.GR_MAX = 300
P.GR_VIEW_EVERY = 600     -- Gilden-Ansicht öffnen startet die Abfragen je Beruf höchstens alle 10 Minuten neu

local function GRWay()
	local A = ns.API
	if A.QueryGuildMembersForRecipe and A.GetGuildRecipeInfoPostQuery and A.GetGuildRecipeMember then
		return "QueryGuildMembersForRecipe"
	end
	return nil
end

function P:GuildRecipesTell(noClick)
	if ns.Diag then
		ns.Diag("GILDENREZEPTE", string.format("Weg=%s ohne Klick=%s · Berufe %d · Abfragen %d · Einträge %d",
			GRWay() or "keiner", noClick, self.gr.profs or 0, self.gr.calls or 0, self.gr.entries or 0))
	end
end

function P:GuildRecipesStart(onlyProf)
	local g = ns.guild
	if not g then return 0 end
	if not GRWay() then self:GuildRecipesTell("nein") return 0 end
	if g.grBlocked == ns.version then self:GuildRecipesTell("blockiert") return 0 end
	local day = math.floor(ns.Now() / 86400)
	if type(g.grDay) ~= "table" then g.grDay = {} end
	local lines = self.guildSkillIDs or {}
	local byProf = {}
	for id, x in pairs(self:SpellIndex()) do
		if lines[x.prof] and (not onlyProf or onlyProf == x.prof) then
			byProf[x.prof] = byProf[x.prof] or {}
			table.insert(byProf[x.prof], id)
		end
	end
	local q = self.gr.queue
	local added = 0
	-- schon gefragte Rezepte (heute) nicht noch einmal; Liste wird am nächsten Tag neu angelegt
	if type(g.grAsked) ~= "table" or g.grAsked.day ~= day then g.grAsked = { day = day } end
	local queued = {}
	for _, x in ipairs(q) do queued[x.id] = true end
	for prof, ids in pairs(byProf) do
		if g.grDay[prof] ~= day then
			g.grDay[prof] = day
			self.gr.profs = (self.gr.profs or 0) + 1
			table.sort(ids)
			for _, id in ipairs(ids) do
				if #q < P.GR_MAX and not g.grAsked[id] and not queued[id] then
					q[#q + 1] = { line = lines[prof], id = id, prof = prof }
					queued[id] = true
					added = added + 1
				end
			end
		end
	end
	if added > 0 and not self.gr.running then
		self.gr.running = true
		self:GuildRecipesNext()
	end
	return added
end

function P:GuildRecipesNext()
	local q = self.gr.queue
	if #q == 0 or not ns.guild or ns.guild.grBlocked == ns.version then
		self.gr.running = false
		self.gr.busy = nil
		self:GuildRecipesTell(ns.guild and ns.guild.grBlocked == ns.version and "blockiert" or "ja")
		return
	end
	if ns.InCombat() then C_Timer.After(5, function() P:GuildRecipesNext() end) return end
	local x = table.remove(q, 1)
	self.gr.busy = x
	self.gr.calls = (self.gr.calls or 0) + 1
	if type(ns.guild.grAsked) == "table" then ns.guild.grAsked[x.id] = true end
	local ok = pcall(ns.API.QueryGuildMembersForRecipe, x.line, x.id)
	if not ok then
		-- Fehler beim Aufruf: Weg für diese Sitzung aus
		self.gr.queue = {}
		self.gr.running = false
		self.gr.busy = nil
		self:GuildRecipesTell("nein")
		return
	end
	C_Timer.After(1.5, function() P:GuildRecipesNext() end)
end

-- Antwort des Spiels: wer kann das abgefragte Rezept
function P:GuildRecipesRead()
	local x = self.gr.busy
	if not x or not ns.guild then return 0 end
	local A = ns.API
	local ok, _, recipeID, num = pcall(A.GetGuildRecipeInfoPostQuery)
	if not ok or ns.IsSecret(num) or type(num) ~= "number" then return 0 end
	if recipeID ~= nil and not ns.IsSecret(recipeID) and recipeID ~= x.id then return 0 end
	local s = Store()
	local info = self:SpellIndex()[x.id]
	local mk = MyKey()
	local n = 0
	for i = 1, math.min(num, 500) do
		local okm, name = pcall(A.GetGuildRecipeMember, i)
		local key = okm and P.Key(name)
		if key and key ~= mk and ns.Roster.byName[key] then
			local e = s[key]
			if not Valid(e) then e = { t = 0, g = true, p = {} }; s[key] = e end
			if e.g and info then
				local v = e.p[x.prof]
				if type(v) ~= "table" then v = {}; e.p[x.prof] = v end
				if not HasRecipe(v, x.id, info.name) then AddRecipe(v, info.name, info.item, x.id); n = n + 1 end
			end
		end
	end
	self.gr.busy = nil
	self.gr.entries = (self.gr.entries or 0) + n
	if n > 0 then ns:Fire("GS_PROF") end
	return n
end

ns:On("GUILD_RECIPE_KNOWN_BY_MEMBERS", function() P:GuildRecipesRead() end)
ns:On("ADDON_ACTION_BLOCKED", function(addon, func)
	if addon ~= ADDON or not ns.guild then return end
	if type(func) == "string" and not ns.IsSecret(func) and func:find("Recipe") then
		ns.guild.grBlocked = ns.version
		P.gr.queue = {}
	end
end)

-- Gilden-Ansicht eines Berufs (Blizzard, vom Spieler geöffnet): Rezepte als Kandidaten merken, nicht als eigene.
-- true = es war die Gilden-Ansicht
function P:ScanGuildView()
	local A = ns.API
	if not (A.IsTradeSkillGuild and C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs) then return false end
	local okg, isGuild = pcall(A.IsTradeSkillGuild)
	if not okg or not isGuild then return false end
	local prof = ModernProfession()
	if type(prof) ~= "string" or prof == "" then return true end
	local ok, all = pcall(C_TradeSkillUI.GetAllRecipeIDs)
	local n = 0
	self.guildView = self.guildView or {}
	self.guildView[prof] = self.guildView[prof] or {}
	if ok and type(all) == "table" then
		for _, id in ipairs(all) do
			local info = C_TradeSkillUI.GetRecipeInfo(id)
			if type(id) == "number" and info and info.learned and info.name then
				self.guildView[prof][id] = { name = info.name, item = ModernOutputItem(id) }
				n = n + 1
			end
		end
	end
	if ns.Diag then ns.Diag("GILDENREZEPTE", string.format("Gilden-Ansicht geöffnet: %s, %d Rezepte", prof, n)) end
	-- jetzt fragen, wer sie kann (wenn das Spiel es ohne Klick erlaubt): je Beruf höchstens alle 10 Minuten neu,
	-- und nur Rezepte, die heute noch nicht gefragt wurden
	self.grViewLast = self.grViewLast or {}
	local now = Now()
	if n > 0 and (self.grViewLast[prof] or -1e9) <= now - P.GR_VIEW_EVERY then
		self.grViewLast[prof] = now
		if ns.guild and type(ns.guild.grDay) == "table" then ns.guild.grDay[prof] = nil end
		self:GuildRecipesStart(prof)
	end
	return true
end

------------------------------------------------------------
-- Gilden-Berufsliste des Spiels (GetGuildTradeSkillInfo): Stufen ALLER Mitglieder, auch ohne GuildSentinel.
-- Gibt es nur in manchen Spielversionen; fehlt sie oder ist sie leer, passiert nichts. Rezepte stehen dort nicht –
-- die kommen weiter nur von Spielern mit GuildSentinel (oder RaidMaster), die ihr Berufsfenster geöffnet haben.
-- Solche Einträge haben t = 0 und g = true: echte Daten eines Spielers gehen immer vor.
-- Offline-Mitglieder (A1): "Offline-Mitglieder anzeigen" kurz einschalten, lesen, alten Wert zurücksetzen.
-- Zugeklappte Berufe: kurz aufklappen, lesen, zuklappen. Beides höchstens alle 5 Minuten, nie im Kampf und nie bei
-- offenem Gildenfenster; was das eigene Auf-/Zuklappen an Ereignissen auslöst, startet kein neues Lesen (glSelf).
------------------------------------------------------------
P.GL_EVERY = 300      -- Sekunden zwischen zwei Änderungen (Aufklappen, Offline einblenden)
P.GL_WAIT = 2         -- Sekunden, die das Spiel nach einer Änderung für neue Daten bekommt

-- Zeilen der Gilden-Berufsliste lesen: Kopfzeilen (Beruf) und Mitglieder darunter
local function GuildRows()
	local A = ns.API
	local okN, n = pcall(A.GetNumGuildTradeSkill)
	if not okN or type(n) ~= "number" or ns.IsSecret(n) then return nil end
	local rows = {}
	for i = 1, n do
		local ok, skillID, collapsed, _, headerName, _, _, numPlayers, playerName, _, class, _, _, skill = pcall(A.GetGuildTradeSkillInfo, i)
		if ok then
			if type(headerName) == "string" and headerName ~= "" and not ns.IsSecret(headerName) then
				rows[#rows + 1] = { head = headerName, id = skillID, collapsed = collapsed and true or false, players = tonumber(numPlayers) }
			elseif type(playerName) == "string" and not ns.IsSecret(playerName) then
				rows[#rows + 1] = { player = playerName, class = class, skill = skill }
			end
		end
	end
	return rows, n
end

-- Blizzards Gildenfenster offen? (dann nichts auf- oder zuklappen – der Spieler sieht die Liste gerade)
local function GuildUIOpen()
	for _, nm in ipairs({ "CommunitiesFrame", "GuildFrame" }) do
		local f = _G[nm]
		if f and f.IsShown and f:IsShown() then return true end
	end
	return false
end
P.GuildUIOpen = GuildUIOpen

-- alten Zustand wiederherstellen (zugeklappt, Offline-Anzeige)
local function Restore(opened, offline)
	local A = ns.API
	P.glSelf = Now() + P.GL_WAIT
	if opened and #opened > 0 and A.CollapseGuildTradeSkillHeader then
		for _, id in ipairs(opened) do pcall(A.CollapseGuildTradeSkillHeader, id) end
	end
	if offline and A.SetGuildRosterShowOffline then pcall(A.SetGuildRosterShowOffline, false) end
end

-- again: zweites Lesen, nachdem das Spiel Zeit für die aufgeklappten/eingeblendeten Daten hatte
function P:ReadGuildList(again)
	local A = ns.API
	if not (ns.guild and A.GetNumGuildTradeSkill and A.GetGuildTradeSkillInfo) then return nil end
	local rows, n = GuildRows()
	if not rows then return nil end
	local now = Now()
	-- Kopfzeilen zählen
	local heads, collapsed = 0, {}
	for _, r in ipairs(rows) do
		if r.head then
			heads = heads + 1
			if r.collapsed then collapsed[#collapsed + 1] = r end
		end
	end
	local opened = again and self.glOpened or {}
	local offline = again and self.glOffline or false
	if not again and not ns.InCombat() and not P.GuildUIOpen() then
		-- A1: Offline-Mitglieder einblenden (nur wenn ausgeschaltet)
		if A.GetGuildRosterShowOffline and A.SetGuildRosterShowOffline and (self.glOfflineLast or -1e9) <= now - P.GL_EVERY then
			local ok, shown = pcall(A.GetGuildRosterShowOffline)
			if ok and shown == false then
				self.glOfflineLast = now
				self.glSelf = now + P.GL_WAIT
				if pcall(A.SetGuildRosterShowOffline, true) then offline = true end
			end
		end
		-- zugeklappte Berufe kurz aufklappen (höchstens alle 5 Minuten)
		if #collapsed > 0 and A.ExpandGuildTradeSkillHeader and (self.glExpandLast or -1e9) <= now - P.GL_EVERY then
			self.glExpandLast = now
			self.glSelf = now + P.GL_WAIT
			for _, r in ipairs(collapsed) do
				if r.id and pcall(A.ExpandGuildTradeSkillHeader, r.id) then opened[#opened + 1] = r.id end
			end
			if #opened > 0 then self.glExpands = (self.glExpands or 0) + 1 end
		end
		if #opened > 0 or offline then rows, n = GuildRows() end
	end
	local s = Store()
	local header, found, people, counts = nil, 0, {}, {}
	self.guildSkillIDs = self.guildSkillIDs or {}
	for _, r in ipairs(rows or {}) do
		if r.head then
			header = r.head
			if r.players then counts[header] = r.players end
			if type(r.id) == "number" and not ns.IsSecret(r.id) then self.guildSkillIDs[header] = r.id end
		elseif header and r.player then
			local member = P.Key(r.player)
			if member and not ns.Roster.byName[member] and next(ns.Roster.byName) then member = nil end
			local lvl = tonumber(r.skill)
			if member and lvl and not ns.IsSecret(r.skill) then
				local e = s[member]
				if not Valid(e) then
					e = { t = 0, g = true, c = type(r.class) == "string" and r.class or nil, p = {} }
					s[member] = e
				end
				local v = e.p[header]
				if type(v) ~= "table" then v = {}; e.p[header] = v end
				-- eigene Angaben des Spielers (mit Rezepten) nicht überschreiben, nur fehlende Stufen ergänzen
				if e.g or not v.r then v.r = lvl end
				found = found + 1
				people[member] = true
			end
		end
	end
	-- Hat das Spiel nach dem Aufklappen/Einblenden noch nichts geliefert: einmal warten und neu lesen, erst dann
	-- den alten Zustand wiederherstellen
	-- Offline-Mitglieder eingeblendet: IMMER warten (das Spiel liefert sie evtl. erst nach einer Antwort des Servers),
	-- bis GUILD_TRADESKILL_UPDATE kommt oder P.GL_WAIT vorbei ist, dann noch einmal lesen und erst danach zurücksetzen.
	-- Nur aufgeklappt: warten nur, wenn noch nichts kam.
	local wait = not again and (offline or (#opened > 0 and found == 0))
	if wait then
		self.glOpened, self.glOffline = opened, offline
		local np0 = 0
		for _ in pairs(people) do np0 = np0 + 1 end
		self.glBefore = np0
		local token = {}
		self.glToken = token
		C_Timer.After(P.GL_WAIT, function() if P.glToken == token then P:ReadGuildList(true) end end)
	else
		Restore(opened, offline)
		self.glOpened, self.glOffline, self.glToken = nil, nil, nil
	end
	-- Anzahl je Beruf (auch ohne Namen; für die Seite Berufe)
	self.guildCounts = next(counts) and counts or self.guildCounts
	local np = 0
	for _ in pairs(people) do np = np + 1 end
	-- Diagnose: beim ersten Lesen, beim ersten Lesen mit Einträgen und wenn offline eingeblendet wurde
	-- (nur vermerken, wenn die Zeile wirklich geschrieben wurde – im Testmodus/in der Testroutine schreibt ns.Diag nichts)
	if ns.Diag and not wait and (not self.guildListTold or (found > 0 and not self.guildListFound) or offline or again) then
		local before = (again and offline and self.glBefore) and string.format(" (vor dem Einblenden %d)", self.glBefore) or ""
		local e = ns.Diag("BERUFE", string.format("Gilden-Berufsliste: %d Zeilen, %d Kopfzeilen, %d zugeklappt, %d aufgeklappt (%d-mal), offline eingeblendet: %s, %d Einträge, %d Mitglieder%s",
			n or 0, heads, #collapsed, #opened, self.glExpands or 0, offline and "ja" or "nein", found, np, before))
		if e then
			self.guildListTold = true
			if found > 0 then self.guildListFound = true end
		end
	end
	if found > 0 or next(counts) then ns:Fire("GS_PROF") end
	return found, np
end

local function GuildListLater()
	if P.glPending then return end
	P.glPending = true
	C_Timer.After(5, function() P.glPending = false; P:ReadGuildList() end)
end
-- eigenes Auf-/Zuklappen bzw. Einblenden löst das Ereignis selbst aus: dann nicht neu lesen (kein Kreislauf)
ns:On("GUILD_TRADESKILL_UPDATE", function()
	-- wartet ein Lesen nach dem Einblenden/Aufklappen: Daten sind da -> jetzt lesen (frühestens 0,5 s danach)
	if P.glToken then
		local token = P.glToken
		C_Timer.After(0.5, function() if P.glToken == token then P:ReadGuildList(true) end end)
		return
	end
	if (P.glSelf or -1e9) >= Now() then return end
	GuildListLater()
end)
ns:On("GUILD_ROSTER_UPDATE", function()
	-- höchstens alle 5 Minuten (die Gildenliste kommt oft)
	local now = Now()
	if (P.glLast or -1e9) > now - 300 then return end
	P.glLast = now
	GuildListLater()
end)

------------------------------------------------------------
-- Suchen
------------------------------------------------------------
-- nur Mitglieder der Gilde (ohne Gildenliste: alle)
local function IsMember(name)
	local by = ns.Roster.byName
	return by[name] ~= nil or not next(by)
end
P.IsMember = IsMember

-- Wer kann das herstellen? -> { { name, prof, recipe, id, rank } }
function P:Find(query)
	query = ns.Trim(query):lower()
	local out = {}
	if query == "" then return out end
	for who, e in pairs(self:All()) do
		if IsMember(who) then
			for prof, v in pairs(e.p) do
				if type(v) == "table" and type(v.n) == "table" then
					for k, n in ipairs(v.n) do
						if type(n) == "string" and n:lower():find(query, 1, true) then
							out[#out + 1] = { name = who, prof = prof, recipe = n, id = type(v.i) == "table" and v.i[k] or 0, rank = v.r, class = e.c }
						end
					end
				end
			end
		end
	end
	table.sort(out, function(a, b)
		if a.recipe ~= b.recipe then return a.recipe < b.recipe end
		local ao, bo = ns.Roster:OnlineChar(a.name) ~= nil, ns.Roster:OnlineChar(b.name) ~= nil
		if ao ~= bo then return ao end
		return a.name < b.name
	end)
	return out
end

-- Übersicht: Beruf -> { { name, r, m, n = Anzahl Rezepte, g = nur aus dem Spiel } } (beste zuerst)
function P:Overview()
	local out = {}
	local total, shown, dropped = 0, 0, 0
	for who, e in pairs(self:All()) do
		total = total + 1
		if IsMember(who) then
			shown = shown + 1
			for prof, v in pairs(e.p) do
				if type(v) == "table" then
					out[prof] = out[prof] or {}
					local nrec = type(v.n) == "table" and #v.n or 0
					table.insert(out[prof], { name = who, r = tonumber(v.r) or 0, m = tonumber(v.m) or 0, n = nrec, class = e.c, t = e.t,
						g = (e.g and nrec == 0) and true or nil })
				end
			end
		else
			dropped = dropped + 1
		end
	end
	for _, list in pairs(out) do
		table.sort(list, function(a, b) if a.r == b.r then return a.name < b.name end return a.r > b.r end)
	end
	self.view = { total = total, shown = shown, dropped = dropped }
	return out
end

-- Protokoll: was im Speicher ist und was davon angezeigt wird (nur, wenn sich die Zahlen ändern)
function P:TellView()
	local v = self.view
	if not v or not ns.Diag then return end
	local line = string.format("Anzeige: %d Einträge im Speicher, %d angezeigt, %d aussortiert (Name nicht in Gildenliste)", v.total, v.shown, v.dropped)
	if line ~= self.viewTold and ns.Diag("BERUFE", line) then self.viewTold = line end
end

function P:ProfNames()
	local out = {}
	local seen = {}
	local total = self.guildCounts or {}
	for prof, list in pairs(self:Overview()) do
		out[#out + 1] = { name = prof, count = #list, total = tonumber(total[prof]) }
		seen[prof] = true
	end
	-- Berufe, von denen das Spiel nur die Anzahl liefert (Kopfzeile ohne lesbare Namen)
	for prof, n in pairs(total) do
		if not seen[prof] and tonumber(n) and n > 0 then out[#out + 1] = { name = prof, count = 0, total = n } end
	end
	table.sort(out, function(a, b) return a.name < b.name end)
	return out
end

-- Spalte "Wer" links: "1 von 4" (wenn das Spiel mehr Mitglieder kennt), sonst nur die Zahl
function P:CountText(x, gray)
	gray = gray or function(t) return t end
	if x.total and x.total > x.count then return x.count .. " " .. gray(string.format(L["von %d"], x.total)) end
	return tostring(x.count)
end

-- Rezepte EINES Mitglieds in einem Beruf, mit Art (RecipeKind.lua), gefiltert nach Art und Suchtext.
-- -> Zeilen { recipe, id, kind, name, prof, class }, Zähler { [Art] = n }, Arten in Reihenfolge, Gesamtzahl
function P:MemberRecipes(member, prof, kind, query)
	local e = self:All()[P.Key(member) or member]
	local v = Valid(e) and e.p[prof]
	local rows, counts, kinds, total = {}, {}, {}, 0
	if type(v) ~= "table" or type(v.n) ~= "table" then return rows, counts, kinds, 0 end
	query = query and ns.Trim(query):lower() or ""
	local vi = type(v.i) == "table" and v.i or {}
	local vk = type(v.k) == "table" and v.k or {}
	for k, name in ipairs(v.n) do
		if type(name) == "string" then
			local id = tonumber(vi[k]) or 0
			local kd = ns.Kinds.Of(name, id, vk[k])
			-- Zähler gelten für den Suchtext (Filter + Suche kombinierbar), nicht für die gewählte Art
			if query == "" or name:lower():find(query, 1, true) then
				total = total + 1
				if not counts[kd] then counts[kd] = 0; kinds[#kinds + 1] = kd end
				counts[kd] = counts[kd] + 1
				if not kind or kind == kd then
					rows[#rows + 1] = { recipe = name, id = id, kind = kd, name = P.Key(member) or member, prof = prof, class = e.c, rank = v.r }
				end
			end
		end
	end
	local function Less(a, b)
		local ra, rb = ns.Kinds.Rank(a), ns.Kinds.Rank(b)
		if ra ~= rb then return ra < rb end
		return ns.Kinds.Label(a) < ns.Kinds.Label(b)
	end
	table.sort(kinds, Less)
	table.sort(rows, function(a, b)
		if a.kind ~= b.kind then return Less(a.kind, b.kind) end
		return a.recipe < b.recipe
	end)
	return rows, counts, kinds, total
end

-- Leertext der Rezeptliste eines Mitglieds
function P:MemberEmpty(member)
	return string.format(L["Rezepte noch nicht bekannt – erscheinen, sobald %s mit GuildSentinel das Berufsfenster öffnet."], member or "?")
end

-- rechte Liste für einen gewählten Beruf: Zeilen, Leertext, Zeile darunter ("+n weitere laut Spiel")
function P:DirView(prof)
	if not prof then return {}, L["Suche oben nach einem Rezept oder wähle links einen Beruf."], nil end
	local list = self:Overview()[prof] or {}
	local total = tonumber((self.guildCounts or {})[prof])
	local empty = L["Suche oben nach einem Rezept oder wähle links einen Beruf."]
	local more
	if #list == 0 and total and total > 0 then
		if total == 1 then
			empty = string.format(L["1 Gildenmitglied hat %s. Die Rezepte sind noch nicht bekannt – sie erscheinen, sobald es mit GuildSentinel sein Berufsfenster öffnet."], prof)
		else
			empty = string.format(L["%d Gildenmitglieder haben %s. Ihre Rezepte sind noch nicht bekannt – sie erscheinen, sobald sie mit GuildSentinel ihr Berufsfenster öffnen."], total, prof)
		end
	elseif #list == 0 then
		empty = L["Noch niemand mit diesem Beruf bekannt."]
	end
	if total and total > #list and #list > 0 then
		more = string.format(L["+%d weitere laut Spiel, Rezepte unbekannt"], total - #list)
	end
	return list, empty, more
end

function P:RecipeLink(id, name)
	if id and id > 0 then
		local _, link = ns.Item(id)
		if link then return link end
	end
	return "[" .. tostring(name) .. "]"
end

function P:AskCraft(r)
	local target = ns.Roster:OnlineChar(r.name) or r.name
	local full = string.format(L["Hallo %s! Könntest du mir %s herstellen? Die Materialien bringe ich mit."], target, "\001")
	local before, after = full:match("^(.-)\001(.*)$")
	ns.OpenWhisper(target, before, self:RecipeLink(r.id, r.recipe), after)
end
