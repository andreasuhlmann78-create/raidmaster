-- LevelPilot - Testroutine (/lp testroutine), Bericht über GoldSentinelTest
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Nur im Testmodus (LP:DevOnly). Läuft in Häppchen (höchstens 8 ms je Bild), nur ausserhalb des Kampfes.
-- Echte Daten: Sicherung vorher, Wiederherstellung in place nachher, Vergleich je Hauptschlüssel ("Sandbox").
-- Aktionen mit Folgen (Kaufen, Reparieren, Anlegen, Quests, Flug, Senden …) laufen über LP.Act und werden
-- während des Laufs nur mitgeschrieben (LP.Act.dry). Es wird keine Blizzard-Funktion ersetzt: Simulationen
-- laufen über setfenv auf eigene Funktionen, über eigene Tabellen (LP.API, LP.Game) und Köderwerte.
-- Ergebnisse nur über T:Check / T:Skip / T:Client. Testfall-IDs wie in testroutine-levelpilot.txt.

local _, LP = ...
local L = LP.L
local TR = {}
LP.TestRoutine = TR

local NOT_YET = "noch nicht automatisiert – folgt"
local ONLY_FOREVER = "LevelPilot nur für WoW Forever"

------------------------------------------------------------------------
-- Testfälle (ID, Bereich, Name) – über alle Versionen gleich
------------------------------------------------------------------------
TR.IDS = {
    { "T01", "A", "alle Module gestartet" },
    { "T02", "A", "Dateien ohne Modul geladen" },
    { "T03", "A", "Version .toc = Code" },
    { "T04", "A", "Version Datenpaket .toc = Code" },
    { "T05", "A", "Interface-Nummer passt zum Client" },
    { "T06", "A", "GoldSentinelGame Version 2 oder neuer" },
    { "T07", "A", "GoldSentinelTest geladen und angemeldet" },
    { "T08", "A", "echte Erkennung" },
    { "T09", "A", "Weichen mit SetTestFlavor(\"forever\")" },
    { "T10", "A", "Weichen mit SetTestFlavor(\"era\")" },
    { "T11", "A", "Weichen mit SetTestFlavor(\"tbc\")" },
    { "T12", "A", "Weichen mit SetTestFlavor(\"retail\")" },
    { "T13", "A", "SetTestFlavor(nil) stellt alles zurück" },
    { "T14", "A", "ohne GoldSentinelGame" },
    { "T15", "A", "Reihenfolge in der .toc" },
    { "T16", "B", "Fenster-Befehle" },
    { "T17", "B", "Modus-Befehle" },
    { "T18", "B", "Wegpunkt und Suche" },
    { "T19", "B", "Sprache per Befehl" },
    { "T20", "B", "Teilen, Gruppe, Bilanz" },
    { "T21", "B", "Protokoll, Diagnose, Messung, Selbsttest" },
    { "T22", "B", "Reise-Befehle" },
    { "T23", "B", "Debug, Zurück, Reset" },
    { "T24", "B", "unbekannter Befehl" },
    { "T25", "B", "Guide-Fenster LevelPilotFrame" },
    { "T26", "B", "Schritt-Menü LevelPilotStepMenu" },
    { "T27", "B", "Hinweise oben (Toasts) LevelPilotToasts" },
    { "T28", "B", "Minimap-Button LevelPilotMinimapButton" },
    { "T29", "B", "Pfeil LevelPilotArrow" },
    { "T30", "B", "Zentrale LevelPilotCenter, alle 8 Reiter" },
    { "T31", "B", "jede Option der Zentrale einmal an und aus" },
    { "T32", "B", "alle 12 Stepper" },
    { "T33", "B", "Sprachknöpfe" },
    { "T34", "B", "Zentrale » Daten: Knöpfe" },
    { "T35", "B", "Fenster der virtuellen Reise LevelPilotVirtualFrame" },
    { "T36", "B", "Gruppen-Panel LevelPilotGroupPanel" },
    { "T37", "B", "Aktionsleiste und Tastenbelegung" },
    { "T38", "B", "Spenden-Fenster" },
    { "T39", "B", "Planung" },
    { "T40", "B", "Planner:KillXPFormula – Werte" },
    { "T41", "B", "Planner:GreyLevel" },
    { "T42", "B", "Planner:GreenXPFactor / KillXP ohne Messung" },
    { "T43", "B", "Dungeon-Faktoren" },
    { "T44", "B", "Questlevel bei Quest-Kills" },
    { "T45", "B", "Speedrun-Filter" },
    { "T46", "B", "Dungeon-Übersicht" },
    { "T47", "B", "Diagnose" },
    { "T48", "B", "Engine-Funktionen" },
    { "T49", "B", "Automatik Annehmen/Abgeben/Gossip" },
    { "T50", "B", "Navigation" },
    { "T51", "B", "Wegenetz Graph" },
    { "T52", "B", "Gelände Terrain" },
    { "T53", "B", "Höhlen Caves" },
    { "T54", "B", "Gefahr Danger" },
    { "T55", "B", "Geo" },
    { "T56", "B", "QuestDB" },
    { "T57", "B", "Namen" },
    { "T58", "B", "Recorder (Aufzeichnung)" },
    { "T59", "B", "Comm: Kodieren und Empfangen" },
    { "T60", "B", "Comm: Begrenzung je Absender" },
    { "T61", "B", "Comm: Senden" },
    { "T62", "B", "Comm: Zonen-Abgleich" },
    { "T63", "B", "Gruppe (LvPilotG)" },
    { "T64", "B", "Social (Teilen, Gruppensuche, Partner)" },
    { "T65", "B", "Session" },
    { "T66", "B", "Comfort" },
    { "T67", "B", "Supply (Vorräte, Belohnung anlegen)" },
    { "T68", "B", "Advisor (Assistent)" },
    { "T69", "B", "Hints" },
    { "T70", "B", "Pins (Karte, Fundstellen)" },
    { "T71", "B", "Plates (Namensplaketten)" },
    { "T72", "B", "Tooltips" },
    { "T73", "B", "Calib (Lernwerte)" },
    { "T74", "B", "Calib: EP-Messung je Kill" },
    { "T75", "B", "Protocol (Fehler-Protokoll)" },
    { "T76", "B", "Backup (Sichern/Laden)" },
    { "T77", "B", "Measure (/lp messen)" },
    { "T78", "B", "Sprache: Hilfsfunktionen" },
    { "T79", "B", "Core-Hilfen" },
    { "T80", "B", "alle Ereignisse einmal" },
    { "T81", "B", "alle Ticker einmal" },
    { "T82", "B", "OnUpdate-Treiber" },
    { "T83", "B", "virtuelle Reise kurz" },
    { "T84", "B", "virtuelle Reise 1–60, beide Modi" },
    { "T85", "B", "Reise abbrechen" },
    { "T86", "B", "Datenpaket-Inhalt" },
    { "T87", "B", "Werkzeuge ausserhalb des Spiels (Tools/: Sicherung.ps1, Wiederherstellen.ps1, lp_sammeln.py …)" },
    { "T88", "C", "API.ItemCooldown mit geschützten start/duration (Ruhestein)" },
    { "T89", "C", "Recorder:RecordService mit geschütztem UnitName(\"npc\")" },
    { "T90", "C", "Tooltip-Hook OnShow mit geschütztem GameTooltipTextLeft1:GetText() und geschütztem tt:GetUnit()" },
    { "T91", "C", "Calib:OnLoot mit geschütztem Beute-Text" },
    { "T92", "C", "CHAT_MSG_ADDON mit geschütztem prefix/msg/sender (Comm und Group)" },
    { "T93", "C", "Plates:ForUnit mit geschütztem UnitName/UnitGUID" },
    { "T94", "C", "Calib:ReadTarget / OnXPUpdate mit geschütztem UnitLevel/UnitXP" },
    { "T95", "C", "Measure-Zeile mit geschütztem UnitClassification" },
    { "T96", "C", "Calib:ObserveUnit mit geschützter GUID und geschütztem Level" },
    { "T97", "C", "Namensvergleich mit geschütztem Namen" },
    { "T98", "C", "EP-Anzeige mit geschütztem UnitXP/UnitXPMax (UI-Ticker im Kampf)" },
    { "T99", "C", "geschützte Werte im echten Kampf" },
    { "T100", "C", "Questlog-Funktionen" },
    { "T101", "C", "API.GreenRange ohne C_QuestLog.GetTrivialRange und GetQuestGreenRange" },
    { "T102", "C", "Händler" },
    { "T103", "C", "Gegenstände" },
    { "T104", "C", "Taschen" },
    { "T105", "C", "Talentpunkte" },
    { "T106", "C", "Hints Known ohne IsSpellKnown/IsPlayerSpell" },
    { "T107", "C", "Gruppensuche ohne ChatFrame_OpenChat" },
    { "T108", "C", "Alter Kanal LevelPilotNet: nur verlassen, nie betreten" },
    { "T109", "C", "Jäger ohne GetPetHappiness/GetPetFoodTypes" },
    { "T110", "C", "Metadaten und AddOns" },
    { "T111", "C", "Gruppe sendet über GoldSentinelSync nur an die Gruppe" },
    { "T112", "C", "weitere alte Globals ohne Prüfung" },
    { "T113", "C", "Names: collectgarbage wirft" },
    { "T114", "C", "Aktionsleiste im Kampf" },
    { "T115", "C", "Belohnung anlegen und Hinweis-Knöpfe im Kampf" },
    { "T116", "C", "Testroutine und Kampf" },
    { "T117", "C", "ADDON_ACTION_BLOCKED für LevelPilot" },
    { "T118", "C", "Kampflog nicht angemeldet" },
    { "T119", "D", "Laden in Classic Era" },
    { "T120", "D", "Hinweis \"für WoW Forever gebaut\"" },
    { "T121", "D", "Weichen auf dem alten Weg" },
    { "T122", "D", "TBC und Retail" },
    { "T123", "E", "Neuinstallation (leere SavedVariables)" },
    { "T124", "E", "Migration Speedrun-Strenge (3.10)" },
    { "T125", "E", "Migration Sprache" },
    { "T126", "E", "Migration Protokoll" },
    { "T127", "E", "Überlagerung der Flugpunkte nach einem Abbruch" },
    { "T128", "E", "alte Fassung (Beispieldaten im Test)" },
    { "T129", "E", "beschädigte Einträge (nil, falscher Typ)" },
    { "T130", "E", "Datenpaket fehlt, falsches Format, zu alt" },
    { "T131", "E", "QuestieDB vorhanden, aber zu alt oder unvollständig" },
    { "T132", "E", "Einstellungen pro Charakter" },
    { "T133", "F", "Schlüssel in jeder Sprache vorhanden" },
    { "T134", "F", "Formatplatzhalter" },
    { "T135", "F", "Format mit Werten" },
    { "T136", "F", "jede Sprache aktivieren, Hauptfenster öffnen" },
    { "T137", "F", "Sprachen ohne Schrift" },
    { "T138", "F", "Namen je Sprache" },
    { "T139", "F", "Texte von GoldSentinelGame" },
    { "T140", "G", "gemeinsame Dateien mit anderen GoldSentinel-Addons" },
    { "T141", "G", "keine globalen Namen überschrieben" },
    { "T142", "G", "Fehler-Handler-Kette" },
    { "T143", "G", "Schnittstellen zu anderen GoldSentinel-Addons" },
    { "T144", "G", "Questie mit und ohne" },
    { "T145", "G", "Addon-Präfixe angemeldet" },
    { "T146", "H", "UI:Refresh (Ticker 1 s)" },
    { "T147", "H", "Engine:CheckSteps (Ticker 0,5 s)" },
    { "T148", "H", "Navigations-Treiber (OnUpdate alle 0,05 s: Nav:Recalc(false), Pfeil, Minikarte)" },
    { "T149", "H", "Pins-Treiber und Weltkarte" },
    { "T150", "H", "Planner:Replan(true) (Ticker 15 s und bei Ereignissen)" },
    { "T151", "H", "Graph:Path für eine lange Route (Orgrimmar -> Wegkreuz)" },
    { "T152", "H", "Drosselung bei \"vom Weg ab\"" },
    { "T153", "H", "Plaketten, Tooltip und Beobachtung je Einheit" },
    { "T154", "H", "Comm" },
    { "T155", "H", "Planung je Reiseschritt" },
    { "T156", "H", "alle 1-s-Ticker zusammen (ui, caves, recorder, session)" },
    { "T157", "H", "Speicher" },
    { "T158", "I", "absichtlicher Fehler über LP:Safe" },
    { "T159", "I", "Lua-Fehler ausserhalb eines pcall" },
    { "T160", "I", "Fehler in einem Ereignis-Handler" },
    { "T161", "I", "Fehler in einem LP:Fire-Listener" },
    { "T162", "I", "Modul-Startfehler in der Diagnose" },
    { "T163", "I", "Ticker-Fehler" },
    { "T164", "I", "Fehler der virtuellen Reise" },
    { "T165", "I", "Bericht gespeichert und datenschutzkonform" },
    { "T166", "I", "Testfall-IDs eindeutig und vollständig" },
    { "T167", "J", "[V Schritt 1] GoldSentinelGame unverändert und vor allen eigenen Dateien" },
    { "T168", "J", "[V Schritt 1] G.Status() in der Diagnose" },
    { "T169", "J", "[V Schritt 1] Namensvergleiche über G.SameName" },
    { "T170", "J", "[V Schritt 2.1] Datenpaket-Version passt" },
    { "T171", "J", "[V Launch] Interface-Nummer in beiden .toc" },
    { "T172", "J", "[Z1a] EP je Kill nach Levelunterschied" },
    { "T173", "J", "[Z1b] Abschlag für grüne Monster nur in Forever" },
    { "T174", "J", "[Z1c] Weg-Kills mit mittlerem Monsterlevel" },
    { "T175", "J", "[Z1d] Quest-Kills mit Questlevel" },
    { "T176", "J", "[Z2] Dungeon-Werte Forever 0,36 / 1,5, Classic 1,0" },
    { "T177", "J", "[Z3] Messung EP je Kill: geschützt, erholt, Gruppe" },
    { "T178", "J", "[Z4] Gruppen-EP-Hinweis in Forever" },
    { "T179", "J", "[Z5a] \"Zeit bis 60\" klar beschriftet" },
    { "T180", "J", "[Z5b] beide Modi vergleichen, echter Modus bleibt" },
    { "T181", "J", "[Z5c] Reisebericht nennt die Herkunft der Werte" },
    { "T182", "J", "[Z NICHT ÄNDERN] EP-Tabelle und Regeln unverändert" },
    { "T183", "J", "[Z Test 1] Zeiten 1–60 Normal und Speedrun" },
    { "T184", "J", "[K1] /lp reise bericht ohne Lua-Fehler (global L)" },
    { "T185", "J", "[K2] Ruhestein-Abklingzeit mit geschützten Werten" },
    { "T186", "J", "[K3] Recorder: geschützter NPC-Name" },
    { "T187", "J", "[K4] Tooltip-Titel und GetUnit geschützt" },
    { "T188", "J", "[K5] Calib:OnLoot geschützt" },
    { "T189", "J", "[K6] CHAT_MSG_ADDON geschützt (Comm und Group)" },
    { "T190", "J", "[K7] collectgarbage in Names mit pcall" },
    { "T191", "J", "[K8] Hints Known ohne Rückgabe true" },
    { "T192", "J", "[K9] Gruppen-Text ohne ChatFrame_OpenChat" },
    { "T193", "J", "[K10] alter Kanal LevelPilotNet nur verlassen" },
    { "T194", "J", "[K11] GreenRange mit UnitQuestTrivialLevelRange" },
    { "T195", "J", "[K12] Talent- und Jägerfunktionen" },
    { "T196", "J", "[K13] Dropraten ohne Kampflog" },
    { "T197", "J", "[K14] Navigation: 0,5 s Mindestpause auch bei \"off\", nicht neu rechnen auf Flügen" },
    { "T198", "J", "[K15] alle Ticker in LP:Safe" },
    { "T199", "J", "[K16] Protokoll mit beschädigtem Eintrag startet" },
    { "T200", "J", "[K17] Measure: UnitClassification geschützt" },
    { "T201", "J", "[K18] Tooltips nutzen LP.API.IsQuestDone" },
    { "T202", "J", "[K19] eigene Erkennung auf LP.Game umgeleitet" },
    { "T203", "J", "[K20] Mindestversion des Datenpakets" },
    { "T204", "J", "[K Frage] Standardwerte mit echten Folgen" },
    { "T205", "J", "[R] Datenpaket nur in der gemeinsamen ZIP" },
    -- 3.12.5: Grundeinstellung der Automatiken und einmalige Hinweise (anweisung-levelpilot-automatiken.txt)
    { "T206", "J", "[A1] Neuinstallation: Reparieren/Flug an, Nachkaufen/Belohnung aus" },
    { "T207", "J", "[A1] Bestehende Einstellungen bleiben" },
    { "T208", "J", "[A2a] Hinweis Nachkaufen einmal, nichts gekauft" },
    { "T209", "J", "[A2b] Hinweis Belohnung einmal, nichts gewählt oder angelegt" },
    { "T210", "J", "[A2c] Option an -> kein Hinweis" },
    { "T211", "J", "[A2d] Im Kampf -> kein Hinweis" },
    { "T212", "J", "[3.12.5-1] Drop-Messung: erneut geöffnete Leiche zählt nicht doppelt" },
    -- 3.12.6: offen-Punkt 2 (Berufszauber im Client)
    { "T213", "J", "[3.12.6-2] Berufszauber: C_SpellBook und IsPlayerSpell im Client" },
    -- 3.12.7: Routenbefund aus Mulgore und Lua-Fehler in CheckNav
    { "T214", "J", "[3.12.7-1] Abgabebereite Quests in der Nähe zuerst (Mulgore Fall 1 und 2)" },
    { "T215", "J", "[3.12.7-2] Kein Ziel und keine Linie im Gebirge (unplausible Orte)" },
    { "T216", "J", "[3.12.7-3] Protokoll CheckNav mit geschützten Werten" },
    -- 3.12.8: Thunder Bluff und Mulgore zusammen planen, Vorrang-Ziele nie vor nahe Abgaben
    { "T217", "J", "[3.12.8-1] Thunder Bluff und Mulgore: ein Fokus, kein FOKUS-Eintrag, Vorrang-Ziel nach nahen Abgaben" },
    -- 3.12.9: Linie nur über bekannte Wege
    { "T218", "J", "[3.12.9-1] Wegnetz statt Luftlinie: ohne bekannten Weg keine Linie, nur Pfeil \"Weg unbekannt\"" },    -- 3.12.10: Sackgassen nur aus reiner Laufzeit
    { "T219", "J", "[3.12.10-1] FEST nur bei Laufzeit: 10 min AFK, 2 min stehen + 1 min laufen, 4 min im Kreis" },    -- 3.12.11: echte NPC-Orte
    { "T220", "J", "[3.12.11-1] Echter Ort eines Questgebers korrigiert das Ziel" },    -- 3.12.12: Wegdaten zum Einsenden
    { "T221", "J", "[3.12.12-1] Wegdaten: /lp wege und GSWEGE1 ohne Namen, nur Neues, Grösse begrenzt" },    -- 3.12.13: erst die offenen Quests der Zone, dann gesammelt weiter
    { "T222", "J", "[3.12.13-1] Offene Quests in Mulgore vor Abgaben im Brachland" },    -- 3.12.14: geschützte Wahrheitswerte aus Unit*-Abfragen
    { "T223", "J", "[3.12.14-1] UnitIsAFK & Co. geschützt: kein Fehler, AFK über den eigenen Leerlauf" },    -- K. Oberfläche im echten Client (UICheck.lua, aus der Vorlage T18–T23)
    { "T224", "K", "Eigene Tooltips verdecken keine Knöpfe" },
    { "T225", "K", "Kein Überlappen mit Blizzard- oder GoldSentinel-Fenstern" },
    { "T226", "K", "Fenster ganz im Bildschirm" },
    { "T227", "K", "Beschriftungen von Knöpfen nicht abgeschnitten" },
    { "T228", "K", "Angezeigte Spielwerte plausibel („N fertig“ = Abgeben, Questlog, Stufe, Position)" },
    { "T229", "K", "Keine Fehlerschleife (gleiche Meldung > 10× in der Sitzung)" },
    -- 3.12.16: graue Gegenstände automatisch verkaufen, kein Verkaufen-Knopf
    { "T230", "J", "[3.12.16-1] Graue Items: Option an verkauft nur Qualität 0 mit Wert, ungesperrt; Chatzeile" },
    { "T231", "J", "[3.12.16-2] Graue Items: Option aus (auch /lp grau) – nichts verkauft, keine Zeile" },
    { "T232", "J", "[3.12.16-3] Graue Items: Abbruch bei MERCHANT_CLOSED" },
    { "T233", "J", "[3.12.16-4] Graue Items: im Kampf nichts, Kampfbeginn bricht ab" },
    { "T234", "J", "[3.12.16-5] Graue Items: im Test nur mitgeschrieben, kein Knopf am Händlerfenster" },
    -- 3.12.17: Wegdaten (Auswertung testberichte/wege)
    { "T235", "J", "[3.12.17-1] Wegnetz: Anfang/Ende und Kreuzung bis 10 Yards an bestehende Kante gehängt" },
    { "T236", "J", "[3.12.17-2] Wegpunkte höchstens 25 Yards auseinander, Ecke > 30° bleibt" },
    { "T237", "J", "[3.12.17-3] Keine Wege auf der Kontinentkarte (Aufzeichnung und Wegdaten)" },
    { "T238", "J", "[3.12.17-4] Wegdaten NPC: old/new als [x, y], oldMap, nächster Fundort, nopack" },
    { "T239", "J", "[3.12.17-5] Datenpaket: Orte von NPC 10666, 10881 und 15350 stimmen" },
    -- 3.12.18: eigene Tooltips neben dem Fenster
    { "T240", "J", "[3.12.18-1] Tooltip neben dem Fenster (rechts, sonst links, sonst darunter), nie über den Knöpfen" },
    -- 3.12.19: übrige Abfragen mit geschütztem Wert
    { "T241", "J", "[3.12.19-1] GetPlayerFacing, IsIndoors, IsResting, GetUnitSpeed, UnitLevel geschützt: kein Fehler, Rückfall" },
    -- 3.12.21: GoldSentinelSync 2 und GoldSentinelTest 2
    { "T242", "J", "[T-SY1/T-GS1/T-GS4] Senden nur über GoldSentinelSync, nie CHANNEL, kein Kanal-Beitritt" },
    { "T243", "J", "[T-SY2] Gilde -> GUILD, Gruppe -> PARTY/RAID, ohne beides und ohne Netz: nichts" },
    { "T244", "J", "[T-SY3] NOT_ALLOWED_IN_CHANNEL steht in der Diagnose" },
    { "T245", "J", "[T-GS2] Empfang über ep:OnMessage, Absender nil wird vertragen" },
    { "T246", "J", "[T-GS3] alte Nachricht ohne Kopf (ältere LevelPilot-Version) wird verstanden" },
    { "T247", "J", "[T-GS5] /lp sync test gibt eine Antwortzeile aus" },
    { "T248", "J", "[T-N1] GoldSentinelSync Version 2" },
    { "T249", "J", "[T-N2] ep:UseStorage: gelernter Mitspieler steht in LevelPilotDB.gsSync.book" },
    { "T250", "J", "[T-N3] net = false und scope guild: nichts ins Flüster-Netz" },
    { "T251", "J", "[T-N4] Diagnose enthält NETZ und keinen Spielernamen" },
    { "T252", "J", "[T-GT1] GoldSentinelTest Version 2" },
    { "T253", "J", "[T-GT2] ohne Zustimmung bleibt der Ausgang (share.outbox) nach einem Fehler leer" },
    -- 3.12.22: Nachprüfung 3.12.21
    { "T254", "J", "[3.12.22-1] Netz: Zonen-Anfrage und Mitspielersuche nur vom Urheber, eigene nie ins Netz" },
    { "T255", "J", "[3.12.22-3] Zonen-Antwort höchstens 25 Nachrichten, keine bei voller Warteschlange" },
    { "T256", "J", "[3.12.22-4] Broadcast merkt nur Gesendetes" },
    { "T257", "J", "[3.12.22-5] Testroutine pumpt nur eigene Testnachrichten" },
    { "T258", "J", "[3.12.22-6] Protokoll: kein SCHRITT beim Stehen in der Stadt, kein FOKUS beim Abarbeiten der Zone" },
    -- 3.12.23
    { "T259", "J", "[3.12.23-2] Wegaufzeichnung: Lücke über 25 Yards trennt die Spur (keine gerade Linie)" },
    { "T260", "J", "[3.12.23-2] alte lange Wegstücke in Stücke <= 25 Yards geteilt, Netz bleibt verbunden" },
    -- 3.12.24: Lag beim Einloggen (befund-lag-cpu-beim-einloggen.txt)
    { "T261", "J", "[T-LAG1] Einloggen ohne Lag: Rechenzeit der ersten 60 s < 1 s" },
    { "T262", "J", "[T-LAG2] Notbremse: > 50 ms oder > 1 s in 5 s -> 60 s Pause, eine Chatzeile, LANGSAM" },
    { "T263", "J", "[T-LAG3] Last-Test: 2000 Wegpunkte, 500 Netz-Einträge, unerreichbares Ziel – Portionen <= 16 ms" },
    { "T264", "J", "[T-LAG4] Diagnose zeigt Zeiten je Modul (auch erste 60 s) und schreibt GSDIAG1" },
    { "T265", "J", "[3.12.24] Wegnetz teilen: nur > 80 Yards, 25–80 Yards unsicher, kein verwaister Knoten" },
    -- 3.12.25: Nachprüfung 3.12.24
    { "T266", "J", "[3.12.25-2] Suchschritt-Grenze gilt nur je Suche (keine globale Variable)" },
    { "T267", "J", "[3.12.25-4] von 3.12.23 geteilte Lücken (25–80 Yards) werden als unsicher erkannt" },
    { "T268", "J", "[3.12.25-3/5] LANGSAM der Notbremse bleibt; neuer Auftrag während einer Portion" },
    -- 3.12.26: umfassende Tests (anweisung-tests-umfassend.txt)
    { "T269", "J", "[TU1] Lagen-Katalog: alle Völker/Klassen/Startgebiete, Stufen 1–60, Queststand" },
    { "T270", "J", "[TU2] Abläufe: /reload unterwegs, Plan wechseln, Tod -> Geistheiler -> weiter, annehmen/abgeben" },
    { "T271", "J", "[TU3] Standardwerte: jede Option ab Werk = was der Spieler meint (Liste)" },
    { "T272", "J", "[TU4] Grundregeln mit 1000 Zufallsfällen (Weg, Belohnung, Zeiten, Kampf)" },
    { "T273", "J", "[TU6] Regressionen: jeder Befund seit 1.11. hat einen bleibenden Test" },
    { "T274", "J", "[TU5] echte Daten (nur lesen): Questlog und gemessene Zeiten gegen den Plan" },
    { "T275", "J", "[TU7] Formen des Spiels: Forever/Era/TBC, deDE/enUS, Fenster bei Skalierung 80 %" },
    -- 3.12.27: Befehlsliste beim Tippen (BL)
    { "T276", "J", "[T-BL1] jeder Befehl des Handlers steht in der Liste (aus derselben Tabelle)" },
    { "T277", "J", "[T-BL2] Filter /lp w und /lp we liefern genau die passenden" },
    { "T278", "J", "[T-BL3] Klick wählt, Enter führt aus (frische Auswahl <= 10 s)" },
    { "T279", "J", "[T-BL4] Chatfeld wird nie beschrieben (nur HookScript lesen)" },
    { "T280", "J", "[T-BL5] Entwickler-Befehle nur für den Entwickler" },
    { "T281", "J", "[T-BL6] alle Sprachen: jede Beschreibung übersetzt, keine Platzhalter-Fehler" },
    -- 3.12.28: Marktdaten-Netz (anweisung-marktdaten-netz.txt, MN1–MN4)
    { "T282", "J", "[MN4-1] LevelPilot lädt mit und ohne GoldSentinelMarkt.lua (angemeldet bzw. still aus)" },
    { "T283", "J", "[MN4-2] Schalter „Marktdaten teilen“ aus -> kein Lesen, kein Senden, kein Annehmen" },
    { "T284", "J", "[MN4-3] ohne Auktionshaus-API (Era/TBC) kein Lua-Fehler, nichts gelesen" },
    { "T285", "J", "[MN3] Zeile MARKT-NETZ in Testbericht und Diagnose; Schalter in der Zentrale, Standard an" },
    { "T286", "J", "[3.12.28] Zentrale: keine zwei Schalter an derselben Stelle" },
    { "T287", "J", "[T-MK1] T283 auch während ein anderes Addon einen Vollscan weitergibt (feedUntil) und mit AHSentinel" },
    -- 3.12.30
    { "T288", "J", "[T-GR1] fertige Quest mit ferner Abgabe (445 Silberwald, Spieler Undercity L10) bleibt sichtbar, Grundregel still" },
    { "T289", "J", "[T-SP1] Speicher-Messung: Zeilen SPEICHER in der Diagnose, angelegt je Modul, Bestand wächst bei Neuplanungen nicht" },
    -- 3.12.31
    { "T290", "J", "[T-ML] Schalter „Meldungen“ aus: kein Chat, keine Bildschirmmeldung, kein Ton, kein Toast, keine Assistent-Hinweise; Antworten bleiben" },
    -- 3.12.32
    { "T291", "J", "[T-PF-A] Gefahr entlang einer Strecke: schnelle Rechnung liefert genau dasselbe wie die bisherige (2000 Strecken)" },
    -- 3.12.33
    { "T292", "J", "[T-LP-D1] Questauswertung: Pausen zwischen Portionen zählen nicht als Rechenzeit; Auswertung Stufe 31 unter 16 ms" },
    { "T293", "J", "[T-GR1-K] Kompaktmodus: „+n später abgeben“ in der einen Zeile, Questnamen im Tooltip; normale Liste unverändert" },
    -- 3.12.34
    { "T294", "J", "[T-L-1] 5-Minuten-Ticker misst Speicher ohne UpdateAddOnMemoryUsage (kein Ruckler); genaue Messung nur auf Befehl" },
    { "T295", "J", "[T-PF-A2] Klick „Neu planen“ mit kalten Zwischenspeichern läuft in Portionen (längste < 16 ms), warm sofort" },
    -- 3.12.35
    { "T296", "J", "[T-UC-W1] Undercity: Auktionshaus -> Bethor Iceshard über gelaufene Wege (nicht „Weg unbekannt“)" },
    -- 3.12.36
    { "T297", "J", "[T-W3D-B1] Ebenen-Angabe (Karte|drinnen|Unterzone) wird gespeichert; W3D-Schalter aus = Wegführung wie bisher" },
    -- 3.12.37
    { "T298", "J", "[T-WEGE-1] Startwegnetz Mulgore/Brachland/Donnerfels (eigene Koordinatenlisten) geladen, nichts gespeichert" },
    -- 3.12.38
    { "T299", "J", "[T-W3D-SPRACHE] Ebenen-Schlüssel sprachfrei: Magieviertel / Das Magieviertel / Magic Quarter = derselbe Schlüssel" },
    -- 3.12.39
    { "T300", "J", "[T-LPN1-ERHOLT] Pause ausserhalb des Gasthauses: Hinweis nur bei AFK, nicht beim Ausruhen, nicht auf Höchststufe, abschaltbar" },
    { "T301", "J", "[T-LPN1-WAFFE] Waffenfertigkeit der angelegten Waffe 25+ unter dem Höchstwert: Hinweis; sonst keiner" },
    -- 3.12.40
    { "T302", "J", "[T-LPN1-MEISTER] Waffe einer noch nicht gelernten Art in der Tasche: Hinweis mit dem Waffenmeister, der sie lehrt" },
    -- 3.12.41
    { "T303", "J", "[T-LPN1-GRIND] Stelle abgegrast: Hinweis erst nach 3 Min. ohne Fortschritt am Ziel, „Andere Stelle“ plant die nächste" },
    -- 3.12.42
    { "T304", "J", "[T-LPN1-HAENDLER] Händlerfenster: Upgrades markiert (nur Kauf-Reiter, richtige Seite, aus = keine Markierung)" },
    -- 3.12.43
    { "T305", "J", "[T-LPN1-TALENT] Talent-Vorschlag: nächster Punkt des Level-Builds, Waffen-Alternative, Baum passt nicht = still" },
    -- 3.12.44
    { "T306", "J", "[T-API-NAV] LevelPilotAPI.NavigateTo: gültiges Ziel -> true und Schritt oben; ungültig/unbekannte Karte -> false" },
    -- 3.12.45
    { "T307", "J", "[T-LPN2] /lp clienttest: automatische Prüfungen, Fragen nur wo nötig, Antworten OK/Nicht OK/Überspringen, Zeilen in der Diagnose" },
    -- 3.12.46
    { "T308", "J", "[T-WEGMESSUNG] /lp wegmessung: GSWegMess fehlt = Hinweis; Start, Markieren je Schritt, Lauf überspringen, Ende stoppt die Messung" },
    -- 3.12.47
    { "T309", "J", "[T-PRUEFLISTE] Prüfliste im Spiel: im Testmodus angemeldet (14 Punkte), ohne Testmodus wirkungslos, jede Erkennungsstelle löst ihren Punkt aus" },
    -- 3.12.48
    { "T310", "J", "[T-LW6] Laufweg-Messung: Luftlinie/gelaufen/Zeit Weg+Ziel, Pfadart, Neuplanung mit Richtungswechsel, Leerlauf, EP/h je Level; Sprung/Flug/AFK/Lücke zählen nicht" },
    -- 3.12.49
    { "T311", "J", "[T-LW3] Flug nach Zeit: gemessene Flugzeit/Annahme, Reittier-Tempo, Entscheid in beide Richtungen anders als die alte Strecken-Regel" },
    -- 3.12.50
    { "T312", "J", "[T-ST2] Strassennetz (Forever bzw. Classic Era): Kontinent des Spielers geladen, Knoten mit Zone, nichts gespeichert, Weg entlang einer Strasse über Strassenkanten" },
    -- 3.12.51
    { "T313", "J", "[T-LW1] Wegkosten statt Luftlinie: Umweg-Faktor je Zone (Median, Grenzen, Annahme), Reihenfolge wählt das schneller erreichbare Ziel" },
    -- 3.12.54
    { "T314", "J", "[T-NAV1A] /lp navi: Koordinaten mit Zone, Zonenname (genau/Anfang), aus, ungültig; Dienstwörter (auch repair); nächster Dienst nach Wegkosten" },
    -- 3.12.55
    { "T315", "J", "[T-LW5-E2] Classic Era: 4 Forever-Zonen zurückgerechnet (Datenpaket, Dungeon-Eingänge), Hin-/Rückweg genau, Forever unverändert, 2 Forever-Orte auf Questie zurück" },
    -- 3.12.56
    { "T316", "J", "[T-LW5-E3] Daten je Spielversion: Forever = LevelPilotDB (unverändert), Classic Era = LevelPilotDB.era; Kalibrierung liest/schreibt im Bereich der Spielversion" },
    -- 3.12.57
    { "T317", "J", "[T-LW5-E4] Forever-Eigenheiten je Spielversion: Schalter \"Server WoW Forever\" nur wo er wirkt, Hilfetext ohne Forever-Quests, NEU-Kennzeichen nur in Forever" },
    -- 3.12.58
    { "T318", "J", "[T-NAV2] Reiseplan nach Zeit: Laufen/Schiff/Laufen mit Sekunden, Flug statt Laufen, Ruhestein wenn schneller, nicht wenn nicht bereit; Text wie ein Navi" },
    -- 3.12.59
    { "T319", "J", "[T-NAV1B] /lp navi <Name>: NPC (nächster Fundort, keine feindlichen), Dungeon, Zone; Trefferliste, Wahl per Nummer, ein Treffer direkt; Dienstwörter händler/trainer" },
    -- 3.12.60
    { "T320", "J", "[T-NAV1C] Markierung auf der Weltkarte = Navi-Ziel; dieselbe Markierung nur einmal; entfernt -> Navi endet; Schalter aus -> nichts" },
    -- 3.12.61
    { "T321", "J", "[T-LW2A] Exakte Reihenfolge der nächsten 8 Schritte: kürzeste Kette, annehmen vor abgeben, Questlog läuft nie über, erster Schritt bleibt" },
    -- 3.12.62
    { "T322", "J", "[T-NAV3] Navi unterwegs: Gefahr auf dem Weg im Reiseplan (ab Spielerlevel + 3), Ankunft am Navi-Ziel mit Meldung, andere Gehe-zu-Ziele still" },
    -- 3.12.63
    { "T323", "J", "[T-NAV4] Reiseplan auch für weite Routenschritte (gleicher Schritt behält den Plan), Schnittstelle v2: Stop nur für eigene Ziele, Abfrage als Kopie, Reisezeit mit Rückruf" },
    -- 3.12.64
    { "T324", "J", "[T-LW7A] Rundgang über die Fundorte der Gegner: nur nahe und ab 3 Fundorten, nächster nicht besuchter, besucht ab 30 yd, Runde beginnt von vorn" },
    -- 3.12.65
    { "T325", "J", "[T-LW5-E5] Prüfliste im Classic-Era-Client: eigene Era-Liste (6 Punkte, vollständig), im Forever-Client die bisherige; Selbstprüfungen der Era-Punkte" },
    { "T326", "J", "[T-LW2B] Zeitfaktor auch im Normalmodus: Annahme-Wert × Anteil Questdauer an Questdauer + halbem Weg (mind. 0,35), anderer Kontinent 900 s, Questgeber teilen den Weg; Schalter aus = wie vorher; nichts ausgelassen" },
}
TR.SHORT = { T01 = true, T02 = true, T03 = true, T04 = true, T06 = true, T07 = true, T08 = true, T39 = true,
             T50 = true, T56 = true, T133 = true }

------------------------------------------------------------------------
-- Hilfen
------------------------------------------------------------------------
local IMPL, SKIP, CLIENT = {}, {}, {}
-- Rückgabe NA statt true: in dieser Lage nicht prüfbar -> als übersprungen zählen, nicht als OK
local NA = setmetatable({}, { __tostring = function() return "nicht prüfbar" end })
TR.NA = NA
TR.NA_SUFFIX = " – in dieser Lage nicht prüfbar"
TR.IMPL, TR.SKIP, TR.CLIENT = IMPL, SKIP, CLIENT

local function G() return LP.Game end
local function Count(t) local n = 0 for _ in pairs(type(t) == "table" and t or {}) do n = n + 1 end return n end
local function Near(a, b, eps) return type(a) == "number" and math.abs(a - b) <= (eps or 0.01) end
local function Ms() return debugprofilestop and debugprofilestop() or (GetTime() * 1000) end
local function S(v) return tostring(v) end

-- body ausführen, danach restore() – auch im Fehlerfall – und den Fehler weitergeben
local function Guard(body, restore)
    local ok, a, b, c = pcall(body)
    restore()
    if not ok then error(a, 0) end
    return a, b, c
end

-- Simulierte Spielversion (GoldSentinelGame.SetTestFlavor), immer zurück
local function WithFlavor(fl, body)
    local g = G()
    if not g or not g.SetTestFlavor then error("GoldSentinelGame fehlt", 0) end
    g.SetTestFlavor(fl)
    return Guard(body, function() g.SetTestFlavor(nil) end)
end

-- Einstellung vorübergehend setzen (über LP.db), immer zurück
local function WithSetting(map, body)
    local old = {}
    for k, v in pairs(map) do old[k] = { LP.db[k] } LP.db[k] = v end
    return Guard(body, function() for k, o in pairs(old) do LP.db[k] = o[1] end end)
end

-- calib.killxp / dungeonxp leer (gemessene Werte ausblenden), immer zurück
local function WithEmptyCalib(body)
    local c = LevelPilotDB and type(LP.Acc().calib) == "table" and LP.Acc().calib
    if not c then return body() end
    local kx, dx = c.killxp, c.dungeonxp
    c.killxp, c.dungeonxp = {}, nil
    return Guard(body, function() c.killxp, c.dungeonxp = kx, dx end)
end

-- Umgebung eigener Funktionen umleiten (setfenv). fake[k] == false bedeutet nil. _G wird nie beschrieben.
local function WithEnv(funcs, fake, body)
    local proxy = setmetatable({}, {
        __index = function(_, k)
            local v = fake[k]
            if v ~= nil then if v == false then return nil end return v end
            return _G[k]
        end,
        __newindex = function(_, k, v) _G[k] = v end,
    })
    local saved = {}
    for i, f in ipairs(funcs) do
        if type(f) == "function" then saved[i] = getfenv(f) setfenv(f, proxy) end
    end
    return Guard(body, function()
        for i, f in ipairs(funcs) do if saved[i] then setfenv(f, saved[i]) end end
    end)
end
TR.WithEnv = WithEnv
-- 3.12.56: wie WithEnv, dazu der Bereich der Spielversion (LP.accRoot) auf das vorgetaeuschte LevelPilotDB – Sicherung
-- und virtuelle Reise lesen ueber LP.Acc() (Classic Era: LevelPilotDB.era), nie mehr direkt die Grundtabelle
local function WithAccEnv(funcs, fake, body)
    local savedAcc = LP.accRoot
    LP.accRoot = fake.LevelPilotDB
    return Guard(function() return WithEnv(funcs, fake, body) end, function() LP.accRoot = savedAcc end)
end

-- flache Kopie einer C_-Tabelle ohne bestimmte Felder (für WithEnv)
local function Without(tbl, ...)
    if type(tbl) ~= "table" then return false end
    local t = {}
    for k, v in pairs(tbl) do t[k] = v end
    for i = 1, select("#", ...) do t[(select(i, ...))] = nil end
    return t
end

-- Köderwerte: gelten innerhalb von body als geschützt (nur LP.Game, synchron, immer zurück)
local function WithSecret(baits, body)
    local g = G()
    if not g then error("GoldSentinelGame fehlt", 0) end
    local set = {}
    for _, v in ipairs(baits) do set[v] = true end
    local orig = g.IsSecret
    g.IsSecret = function(v) return (v ~= nil and set[v] == true) or orig(v) end
    return Guard(body, function() g.IsSecret = orig end)
end

-- simulierter Kampf über LP:InCombat
local function WithCombat(state, body)
    local old = LP.testCombat
    LP.testCombat = state
    return Guard(body, function() LP.testCombat = old end)
end

local function Act() return LP.Act end
local function ActMark() return #LP.Act.log end
local function ActSince(mark, name)
    local n = 0
    for i = mark + 1, #LP.Act.log do if not name or LP.Act.log[i].name == name then n = n + 1 end end
    return n
end

local function Meta(addon, field)
    local f = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
    if not f then return nil end
    local ok, v = pcall(f, addon, field)
    return ok and v or nil
end

------------------------------------------------------------------------
-- A. Laden und Erkennung
------------------------------------------------------------------------
local MODULES = { "Actions", "Advisor", "Backup", "Calib", "Caves", "Center", "Comfort", "Comm", "Danger", "Engine", "Geo",
    "Graph", "Group", "Hints", "Measure", "Names", "Nav", "Pins", "Planner", "Plates", "Protocol", "QuestDB", "Recorder",
    "SelfTest", "Session", "Social", "Supply", "Terrain", "Tooltips", "UI", "Virtual", "ClientTest", "WegMessung", "Pruefliste", "Laufweg" }

IMPL.T01 = function()
    local have, missing = {}, {}
    for _, m in ipairs(LP.modules) do have[m.name] = true end
    for _, n in ipairs(MODULES) do if not have[n] then missing[#missing + 1] = n end end
    local init = {}
    for n in pairs(LP.initErrors or {}) do init[#init + 1] = n end
    if #missing > 0 or #init > 0 or #LP.modules ~= #MODULES then
        return false, string.format("%d Module, fehlend: %s, Startfehler: %s", #LP.modules, table.concat(missing, ","),
            table.concat(init, ",")), #MODULES .. " Module, keine Startfehler"
    end
    return true, #LP.modules .. " Module"
end

IMPL.T02 = function()
    local miss = {}
    for _, k in ipairs({ "API", "Act", "Donate", "Seed", "Dungeons", "Gateways", "CaveSeed", "CaveForeverMaps", "LocaleEN" }) do
        if type(LP[k]) ~= "table" then miss[#miss + 1] = k end
    end
    local n = 0
    for _, c in ipairs({ "en", "fr", "es", "mx", "pt", "it", "ru", "ko", "cn", "tw" }) do if type(LP.Locales[c]) == "table" then n = n + 1 end end
    if #miss > 0 or n ~= 10 or _G.LevelPilot ~= LP then
        return false, "fehlend: " .. table.concat(miss, ",") .. " · Übersetzungen " .. n, "alle Tabellen, 10 Übersetzungen"
    end
    return true, "10 Übersetzungen"
end

IMPL.T03 = function()
    local toc = Meta("LevelPilot", "Version")
    return toc == LP.version, S(toc), LP.version
end

IMPL.T04 = function()
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return NA, "Datenpaket LevelPilot_Data fehlt" end
    local toc = Meta("LevelPilot_Data", "Version")
    return toc == d.version and d.format == 1, S(toc) .. " / " .. S(d.version) .. " / Format " .. S(d.format), "gleich, Format 1"
end
CLIENT.T05 = "/dump select(4, GetBuildInfo()) – steht die Zahl in beiden .toc? Addon-Liste: LevelPilot nicht 'veraltet'"

IMPL.T06 = function()
    local g = _G.GoldSentinelGame
    if type(g) ~= "table" then return false, "fehlt", "Version 2" end
    local miss = {}
    for _, k in ipairs({ "IsSecret", "AnySecret", "Safe", "InCombat", "Short", "CleanName", "SameName", "Status", "SetTestFlavor", "Recalc" }) do
        if type(g[k]) ~= "function" then miss[#miss + 1] = k end
    end
    local ok = type(g.version) == "number" and g.version >= 2 and LP.Game == g and #miss == 0 and g.flavor ~= nil and type(SlashCmdList.GOLDSENTINELGAME) == "function"
    return ok, "Version " .. S(g.version) .. (#miss > 0 and (" fehlt: " .. table.concat(miss, ",")) or ""), "Version >= 2 (heute 3), alles vorhanden"
end

IMPL.T07 = function()
    local GT = _G.GoldSentinelTest
    if type(GT) ~= "table" then return false, "fehlt", "geladen" end
    local reg = GT.registry and GT.registry.LevelPilot
    local ok = (GT.version or 0) >= 1 and reg and reg.db == LevelPilotDB and type(LevelPilotDB.gsTest) == "table"
    return ok and true or false, "Version " .. S(GT.version) .. (reg and " angemeldet" or " nicht angemeldet"), "angemeldet mit LevelPilotDB"
end

IMPL.T08 = function()
    local g = G()
    if not g then return false, "GoldSentinelGame fehlt", "vorhanden" end
    if g.flavor == "forever" then
        local ok = g.IsModern and g.HasSecrets and not g.IsOldAPI and LP.API.modern == true and LP.API.Forever() == true
        return ok and true or false, g.Status(), "Forever, modern"
    end
    if g.flavor == "era" then
        local ok = g.IsOldAPI and LP.API.modern == false
        return ok and true or false, g.Status(), "Era, alte API"
    end
    return true, g.Status()
end

local function FlavorBlock(fl)
    return function()
        return WithEmptyCalib(function()
            return WithSetting({ questLogMax = 0, dungeonMobXP = 0, dungeonQuestXP = 0, forever = true }, function()
                return WithFlavor(fl, function()
                    local g, P = G(), LP.Planner
                    local f, mq = LP.API.Forever(), LP.API.MaxQuests()
                    local dg, dq, gr = P:DungeonXPFactor(), P:DungeonQuestFactor(), P:GreenXPFactor(-3)
                    local note = LP.Social.ForeverGroupNote("x")
                    local got = string.format("Forever %s, Questlog %d, Dungeon %.2f/%.2f, grün %.2f", S(f), mq, dg, dq, gr)
                    if fl == "forever" then
                        return f == true and mq == 40 and Near(dg, 0.36) and Near(dq, 1.5) and Near(gr, 0.85) and note ~= "x", got,
                            "Forever true, 40, 0.36/1.50, 0.85, Gruppenhinweis"
                    elseif fl == "retail" then
                        return g.IsModern and not g.IsForever and f == false and mq == 20, got, "modern, nicht Forever, 20"
                    else
                        local okT = (fl ~= "tbc") or g.IsTBC
                        return okT and g.IsOldAPI and f == false and mq == 20 and Near(dg, 1) and Near(dq, 1) and Near(gr, 1) and note == "x",
                            got, "alt, Forever false, 20, 1/1, 1"
                    end
                end)
            end)
        end)
    end
end
local flavorBefore
IMPL.T09 = function() flavorBefore = G() and G().flavor return FlavorBlock("forever")() end
IMPL.T10 = FlavorBlock("era")
IMPL.T11 = FlavorBlock("tbc")
IMPL.T12 = FlavorBlock("retail")
IMPL.T13 = function()
    local g = G()
    if not g then return false, "GoldSentinelGame fehlt", "vorhanden" end
    local st = g.Status()
    return (flavorBefore == nil or g.flavor == flavorBefore) and not st:find("%[Test%]"), g.flavor .. " · " .. st, S(flavorBefore)
end

IMPL.T14 = function()
    local saved = LP.Game
    LP.Game = nil
    return Guard(function()
        local a = LP.SafeValue(5) == 5
        local b = LP.SameName("Testa-Realm", "Testa") == true and LP.SameName("Testa-Realm", "testa") == false
        return a and b, "SafeValue " .. S(a) .. ", SameName " .. S(b), "beide true"
    end, function() LP.Game = saved end)
end
SKIP.T15 = "wird von addon-check geprüft"

------------------------------------------------------------------------
-- B. Funktionen
------------------------------------------------------------------------
local function Slash(msg) SlashCmdList.LEVELPILOT(msg) end

IMPL.T17 = function()
    local real = LP.char.mode
    return Guard(function()
        Slash("speed")
        local a = LP.char.mode == "speed" and LP.Planner:IsSpeed()
        Slash("normal")
        local b = LP.char.mode == "normal" and not LP.Planner:IsSpeed()
        return a and b, "speed " .. S(a) .. ", normal " .. S(b), "beide true"
    end, function() LP.Planner:SetMode(real) end)
end

IMPL.T19 = function()
    local before = LP.db.language
    return Guard(function()
        local r1 = LP:SetLanguage(nil)
        local r2 = LP:SetLanguage("xx")
        return r1 == false and r2 == false, "ohne Kürzel " .. S(r1) .. ", xx " .. S(r2), "false, false"
    end, function() LP.db.language = before LP:ResetLanguageCache() end)
end

IMPL.T23 = function()
    local mark = ActMark()
    local pos = { LP.db.framePos, LP.db.arrowPos, LP.db.centerPos }
    return Guard(function()
        Slash("reset")
        local n = ActSince(mark, "ReloadUI")
        return n == 1, "ReloadUI mitgeschrieben: " .. n, "1 (nicht ausgeführt)"
    end, function() LP.db.framePos, LP.db.arrowPos, LP.db.centerPos = pos[1], pos[2], pos[3] end)
end

IMPL.T24 = function()
    local was = LP.UI:IsShown()
    Slash("xyz") Slash("xyz")
    return LP.UI:IsShown() == was, S(LP.UI:IsShown()), S(was)
end

IMPL.T27 = function()
    LP.UI:Toast({ key = "test", sev = 1, text = "Test" })
    LP.UI:ClearToasts()
    return true
end

IMPL.T30 = function()
    local f = _G.LevelPilotCenter
    local wasShown = f and f:IsShown()
    return Guard(function()
        if not wasShown then LP.Center:Toggle() end
        for _, k in ipairs({ "route", "dungeons", "data", "share", "assist", "comfort", "extras", "settings" }) do LP.Center:Select(k) end
        local esc = false
        for _, n in ipairs(UISpecialFrames or {}) do if n == "LevelPilotCenter" then esc = true end end
        return esc, "8 Reiter, Escape " .. S(esc), "Escape schliesst"
    end, function() if f and not wasShown then f:Hide() end end)
end

IMPL.T38 = function()
    local t = LP.Donate.AddonTitle()
    return t == "LevelPilot", S(t), "LevelPilot"
end

IMPL.T39 = function()
    if (UnitLevel("player") or 1) >= 60 then return NA, "Level 60" end
    LP.Planner:BuildCandidates()
    LP.Planner:Replan(true)
    local st, cur = LP.Engine:Steps(), LP.Engine:Current()
    return #st > 0 and cur and cur.key ~= nil and cur.t ~= nil, #st .. " Schritte, Zustand " .. S(LP.Planner.state), "> 0 Schritte"
end

local KXP = { { 20, 20, 145 }, { 20, 22, 159.5 }, { 20, 24, 174 }, { 20, 25, 174 }, { 20, 17, 105.45 }, { 20, 14, 65.91 },
              { 20, 13, 0 }, { 5, 1, 14 }, { 60, 60, 345 }, { 60, 64, 414 }, { 60, 48, 86.25 }, { 60, 47, 0 } }
IMPL.T40 = function()
    local bad = {}
    for _, e in ipairs(KXP) do
        local v = LP.Planner:KillXPFormula(e[1], e[2])
        if not Near(v, e[3], 0.01) then bad[#bad + 1] = string.format("(%d,%d)=%.2f statt %.2f", e[1], e[2], v, e[3]) end
    end
    return #bad == 0, #bad == 0 and "12 Werte" or table.concat(bad, "; "), "alle 12 Werte"
end

IMPL.T41 = function()
    local P, bad = LP.Planner, {}
    for _, e in ipairs({ { 5, 0 }, { 6, 1 }, { 10, 4 }, { 39, 31 }, { 40, 31 }, { 60, 47 } }) do
        if P:GreyLevel(e[1]) ~= e[2] then bad[#bad + 1] = e[1] .. "->" .. S(P:GreyLevel(e[1])) end
    end
    return #bad == 0, table.concat(bad, ", "), "5->0, 6->1, 10->4, 39->31, 40->31, 60->47"
end

IMPL.T42 = function()
    return WithEmptyCalib(function()
        return WithSetting({ forever = true }, function()
            return WithFlavor("forever", function()
                local P = LP.Planner
                local g3, g2 = P:GreenXPFactor(-3), P:GreenXPFactor(-2)
                local k17, k18 = P:KillXP(20, 17), P:KillXP(20, 18)
                return Near(g3, 0.85) and Near(g2, 1) and Near(k17, 89.64) and Near(k18, 118.64),
                    string.format("%.2f %.2f %.2f %.2f", g3, g2, k17, k18), "0.85 1.00 89.64 118.64"
            end)
        end)
    end)
end

IMPL.T43 = function()
    return WithEmptyCalib(function()
        return WithFlavor("forever", function()
            local P = LP.Planner
            local r = {}
            WithSetting({ dungeonMobXP = 0, forever = true }, function() r[1], r[2] = P:DungeonXPFactor() end)
            WithSetting({ dungeonMobXP = 50, forever = true }, function() r[3], r[4] = P:DungeonXPFactor() end)
            WithSetting({ dungeonQuestXP = 200, forever = true }, function() r[5], r[6] = P:DungeonQuestFactor() end)
            local ok = Near(r[1], 0.36) and r[2] == "auto" and Near(r[3], 0.5) and r[4] == "set" and Near(r[5], 2) and r[6] == "set"
            return ok, string.format("%.2f %s · %.2f %s · %.2f %s", r[1], S(r[2]), r[3], S(r[4]), r[5], S(r[6])), "0.36 auto · 0.50 set · 2.00 set"
        end)
    end)
end

IMPL.T44 = function()
    local P = LP.Planner
    local a, b = P:QuestKillLevel({ level = 18 }, 20), P:QuestKillLevel({}, 20)
    return a == 18 and b == 20, S(a) .. ", " .. S(b), "18, 20"
end

IMPL.T47 = function()
    local txt = table.concat(LP.Planner:DiagLines(), "\n")
    local ok = txt:find("Version " .. LP.version, 1, true) or txt:find(LP.version, 1, true)
    return ok and (not G() or txt:find(G().Status(), 1, true)) and true or false, "Diagnose " .. #txt .. " Zeichen", "Version und G.Status()"
end

IMPL.T50 = function()
    LP.Nav:Recalc(true)
    if not LP.Nav.target then return NA, "kein Ziel (Schritt ohne Ort)" end
    local d = LP.Nav.RemainingDistance and LP.Nav:RemainingDistance()
    if not LP.Nav.hasPath then return false, S(LP.Nav.pathError), "Weg gefunden" end
    return type(d) == "number" and d >= 0, "Weg " .. (d and LP:FormatDist(d) or "?"), "Zahl >= 0"
end

IMPL.T55 = function()
    local Geo = LP.Geo
    local i, n, w = Geo:ToWorld(1411, 0.5, 0.5)
    local cont = Geo.ContinentOf and Geo:ContinentOf(1411)
    local name = Geo:MapName(1411)
    return i ~= nil and type(name) == "string" and name ~= "" and (cont == nil or cont == 1414),
        "Kontinent " .. S(cont) .. ", Name " .. S(name), "1414, Name"
end

IMPL.T56 = function()
    local c = LP.QuestDB:Counts()
    local q = LP.QuestDB:Get(844) or LP.QuestDB:Get(7)
    local ok = type(c) == "table" and type(c.pack) == "number" and type(c.seed) == "number" and type(c.own) == "number"
    return ok and (q == nil or q.name ~= nil), string.format("Paket %s, Start %s, eigene %s", S(c.pack), S(c.seed), S(c.own)), "Zahlen"
end

IMPL.T57 = function()
    local st = LP.Names:StatusText()
    return type(st) == "string" and st ~= "", st, "nicht leer"
end

IMPL.T60 = function()
    local rate = LP.Comm.RateOk
    if not rate then return false, "Comm.RateOk fehlt", "zugänglich" end
    local who = "LPTest-" .. tostring(math.random(100000, 999999))
    local r80, r81
    for i = 1, 81 do local r = rate(who) if i == 80 then r80 = r elseif i == 81 then r81 = r end end
    return r80 == true and r81 == false, "80: " .. S(r80) .. ", 81: " .. S(r81), "80: true, 81: false"
end

IMPL.T63 = function()
    local Gp = LP.Group
    local who = "LPTester-Test"
    local saved = Gp.members[who:match("^([^%-]+)")]
    return Guard(function()
        Gp:OnMessage("S\t5\t10\tGOTO\t0\ttext", who)
        local m = Gp.members["LPTester"]
        local ok = m and m.level == 5 and m.pct == 10 and m.text == "text"
        return ok and true or false, ok and "Mitglied erkannt" or "nicht erkannt", "level 5, pct 10, text"
    end, function() Gp.members["LPTester"] = saved end)
end

IMPL.T65 = function()
    local M = LP.Session.Money
    local a, b, c = M(12345), M(250), M(5)
    local sum = LP.Session:SummaryText()
    return a == "1g 23s" and b == "2s 50c" and c == "5c" and type(sum) == "string", a .. " · " .. b .. " · " .. c, "1g 23s · 2s 50c · 5c"
end

IMPL.T66 = function()
    local D = LP.Comfort.Dur
    local a, b = D(59), D(nil)
    local mark = ActMark()
    -- Reparieren mit simuliertem Händler: nur mitschreiben
    WithSetting({ autoRepair = true }, function()
        WithEnv({ LP.Comfort.Repair }, { CanMerchantRepair = function() return true end,
            GetRepairAllCost = function() return 100, true end, GetMoney = function() return 100000 end }, function()
            LP.Comfort:Repair()
        end)
    end)
    local n = ActSince(mark, "RepairAllItems")
    return b == "?" and type(a) == "string" and n == 1, "Dur(59) " .. a .. ", Reparieren mitgeschrieben " .. n, "?, 1"
end

IMPL.T67 = function()
    local needs = LP.Supply:Needs()
    local mark = ActMark()
    local pend = LP.Supply.EquipRewards
    -- Nachkaufen mit simuliertem Händler: nur API.MerchantBuy im Protokoll (über LP.Act)
    WithSetting({ restock = true }, function()
        local plan = { { index = 1, id = 4540, purchases = 1, perBuy = 5, price = 25, name = "Test" } }
        local origPlan = LP.Supply.Plan
        LP.Supply.Plan = function() return plan, 25 end
        Guard(function()
            WithEnv({ LP.Supply.Restock }, { MerchantFrame = { IsShown = function() return true end } }, function()
                LP.Supply:Restock()
            end)
        end, function() LP.Supply.Plan = origPlan end)
    end)
    local n = ActSince(mark, "MerchantBuy")
    return type(needs) == "table" and n >= 1 and pend ~= nil, #needs .. " Bedarf, Kauf mitgeschrieben " .. n, ">= 1 mitgeschrieben"
end

IMPL.T68 = function()
    LP.Advisor:Run()
    return type(LP.Advisor.hints) == "table", #LP.Advisor.hints .. " Hinweis(e)", "Liste"
end

IMPL.T73 = function()
    local t = LP.Calib:KillXPText()
    return type(t) == "string" and t ~= "", t, "Text"
end

IMPL.T75 = function()
    local Pr = LP.Protocol
    local n0 = Pr:Count()
    Pr:Add("error", "LP-Testroutine Protokoll")
    Pr:Add("error", "LP-Testroutine Protokoll")
    local n1 = Pr:Count()
    -- Eintrag wieder entfernen (Sandbox stellt am Ende ohnehin alles zurück)
    local entries = Pr:Entries()
    for i = #entries, 1, -1 do
        local e = entries[i]
        if type(e) == "table" and type(e.msg) == "string" and e.msg:find("LP-Testroutine", 1, true) then table.remove(entries, i) end
    end
    return n1 - n0 <= 1, "neu: " .. (n1 - n0), "höchstens 1 (gleiche Meldung zusammengefasst)"
end

IMPL.T77 = function()
    local t = LP.Measure:Text()
    return type(t) == "string" and (not G() or t:find(G().Status(), 1, true) ~= nil), #t .. " Zeichen (Text nicht im Bericht)", "enthält G.Status()"
end

IMPL.T79 = function()
    local a = LP.HasBit(2 ^ 32 + 1, 2 ^ 32) == true and LP.HasBit(5, 2) == false and LP.HasBit(0, 1) == false
    local b = LP:SameZoneName("Das Brachland", "Brachland") == true and LP:SameZoneName("Durotar", "Mulgore") == false
    local c = LP:FormatDist(2000) == "1.8 km" and LP.TagHash("Ab c#1") == LP.TagHash("abc#1")
    -- LP:Fire: ein fehlerhafter Zuhörer bricht nicht ab
    local ran = false
    local key = "LP_TEST_FIRE"
    LP.callbacks[key] = { function() error("LP-Testfehler Fire") end, function() ran = true end }
    local before = LP.errorCount
    LP:Fire(key)
    LP.callbacks[key] = nil
    LP.errorCount = before
    return a and b and c and ran, string.format("Bits %s, Zonen %s, Format %s, Fire %s", S(a), S(b), S(c), S(ran)), "alle true"
end

IMPL.T81 = function()
    local names, bad = {}, {}
    for _, t in ipairs(LP.tickers or {}) do
        names[#names + 1] = t.name
        if t.name ~= "journey" then
            local ok, err = pcall(t.fn)
            if not ok then bad[#bad + 1] = t.name .. ": " .. tostring(err) end
        end
    end
    return #bad == 0 and #names > 0, #names .. " Ticker" .. (#bad > 0 and (" – " .. table.concat(bad, "; ")) or ""), "kein Fehler"
end

IMPL.T86 = function()
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return NA, "kein Datenpaket" end
    local ok = type(d.Q) == "table" and type(d.N) == "table" and next(d.Q) ~= nil
    return ok, "Quests " .. Count(d.Q), "Tabellen gefüllt"
end
SKIP.T87 = "ausserhalb des Spiels"

------------------------------------------------------------------------
-- C. Forever-Sonderfälle (Köder, fehlende Funktionen, Kampfsperre)
------------------------------------------------------------------------
local BAIT_N1, BAIT_N2 = 987654.25, 987655.25

IMPL.T88 = function()
    local fakeC = Without(C_Container, "GetItemCooldown") or {}
    fakeC.GetItemCooldown = function() return BAIT_N1, BAIT_N2 end
    return WithSecret({ BAIT_N1, BAIT_N2 }, function()
        return WithEnv({ LP.API.ItemCooldown }, { C_Container = fakeC, GetItemCooldown = false }, function()
            local v = LP.API.ItemCooldown(LP.API.HEARTHSTONE or 6948)
            return type(v) == "number" and v >= 0, "Rückgabe " .. S(v), "Zahl >= 0 (letzter lesbarer Wert oder 0)"
        end)
    end)
end

IMPL.T91 = function()
    local item = 999001
    local s = LP.Acc().calib or {}
    LP.Acc().calib = s
    s.drops = type(s.drops) == "table" and s.drops or {}
    local savedDrop = s.drops[item]
    s.drops[item] = { k = 1, g = 0 }
    local msg = "Ihr bekommt Beute: |cffffffff|Hitem:" .. item .. "::::::::|h[x]|h|r"
    local savedW = LP.Calib.testWanted
    LP.Calib.testWanted = { [item] = { npc = { [1] = true } } }
    return Guard(function()
        WithSecret({ msg }, function() LP.Calib:OnLoot(msg) end)
        return s.drops[item].g == 0, "Stück " .. S(s.drops[item].g), "0 (Köder nicht verarbeitet)"
    end, function() s.drops[item] = savedDrop LP.Calib.testWanted = savedW end)
end
IMPL.T188 = IMPL.T91

IMPL.T97 = function()
    local bait = "LPTestKoeder Name"
    return WithSecret({ bait }, function()
        local a = LP.SameName(bait, "x")
        local b = G().Short(bait)
        return a == false and b == nil, "SameName " .. S(a) .. ", Short " .. S(b), "false, nil"
    end)
end

IMPL.T101 = function()
    local fakeQ = Without(C_QuestLog, "GetTrivialRange") or false
    return WithEnv({ LP.API.GreenRange }, { C_QuestLog = fakeQ, GetQuestGreenRange = false, UnitQuestTrivialLevelRange = false }, function()
        local R = LP.API.GreenRange
        local a, b, c, d = R(5), R(20), R(45), R(60)
        return a == 5 and b == 7 and c == 10 and d == 13, a .. "," .. b .. "," .. c .. "," .. d, "5,7,10,13"
    end)
end
IMPL.T194 = IMPL.T101

IMPL.T102 = function()
    local API = LP.API
    return WithEnv({ API.MerchantCount, API.MerchantAvailable, API.MerchantLink, API.MerchantBuy, API.MerchantItem },
        { GetMerchantNumItems = false, C_MerchantFrame = false, GetMerchantItemLink = false, BuyMerchantItem = false,
          GetMerchantItemInfo = false }, function()
        local ok = API.MerchantCount() == 0 and API.MerchantAvailable() == false and API.MerchantLink(1) == nil
            and API.MerchantBuy(1, 1) == false and API.MerchantItem(1) == nil
        return ok, ok and "alle Rückfälle" or "falscher Rückfall", "0/false/nil/false/nil"
    end)
end

IMPL.T103 = function()
    local API = LP.API
    return WithEnv({ API.ItemInfo, API.IsEquippable, API.SellPrice, API.ItemSpell },
        { C_Item = false, GetItemInfo = false, IsEquippableItem = false, GetItemSpell = false }, function()
        local ok = API.ItemInfo(6948) == nil and API.IsEquippable(6948) == false and API.SellPrice(6948) == 0 and API.ItemSpell(6948) == nil
        return ok, ok and "alle Rückfälle" or "falscher Rückfall", "nil/false/0/nil"
    end)
end

IMPL.T104 = function()
    local API = LP.API
    return WithEnv({ API.BagSlots, API.BagFree, API.BagLink, API.BagItem, API.UseBagItem },
        { C_Container = false, GetContainerNumSlots = false, GetContainerNumFreeSlots = false, GetContainerItemLink = false,
          GetContainerItemInfo = false, UseContainerItem = false }, function()
        local f1, f2 = API.BagFree(0)
        local ok = API.BagSlots(0) == 0 and f1 == 0 and f2 == 0 and API.BagLink(0, 1) == nil and API.BagItem(0, 1) == nil
            and API.UseBagItem(0, 1) == nil
        return ok, ok and "alle Rückfälle" or "falscher Rückfall", "0/0,0/nil/nil/nil"
    end)
end

IMPL.T106 = function()
    local known = LP.Hints.Known
    if not known then return false, "Hints.Known fehlt", "zugänglich" end
    return WithEnv({ known }, { C_SpellBook = false, IsSpellKnown = false, IsPlayerSpell = false }, function()
        local r = known(3273)
        return r == nil, "Rückgabe " .. S(r), "nil (unbekannt – kein Hinweis)"
    end)
end
IMPL.T191 = IMPL.T106

IMPL.T107 = function()
    local mark = ActMark()
    local So = LP.Social
    local origText = So.GroupText
    So.GroupText = function() return "LFG Test" end
    return Guard(function()
        local line = WithEnv({ So.OpenGroupChat }, { ChatFrame_OpenChat = false }, function() return So:OpenGroupChat({}) end)
        local n = ActSince(mark, "OpenChat")
        local hasUtil = ChatFrameUtil and ChatFrameUtil.OpenChat
        return line ~= nil and (n == 1 or not hasUtil), "Zeile " .. S(line ~= nil) .. ", mitgeschrieben " .. n, "Zeile, OpenChat mitgeschrieben"
    end, function() So.GroupText = origText end)
end
IMPL.T192 = IMPL.T107

IMPL.T115 = function()
    local mark = ActMark()
    WithSetting({ autoEquipRewards = true }, function()
        WithEnv({ LP.Supply.EquipRewards }, { InCombatLockdown = function() return true end }, function() LP.Supply:EquipRewards() end)
    end)
    local n = ActSince(mark, "Equip")
    return n == 0, "mitgeschrieben " .. n, "0"
end

IMPL.T116 = function()
    local r = WithCombat(true, function() return TR:CanStart(true) end)
    return r == false, "Start erlaubt: " .. S(r), "false"
end

IMPL.T117 = function()
    local Pr = LP.Protocol
    local list = LP.handlers.ADDON_ACTION_BLOCKED
    if not list then return false, "kein Handler", "Handler angemeldet" end
    local n0 = Pr:Count()
    for _, fn in ipairs(list) do pcall(fn, "ADDON_ACTION_BLOCKED", "LevelPilot", "LPTestAktion") end
    local n1 = Pr:Count()
    local entries = Pr:Entries()
    for i = #entries, 1, -1 do
        local e = entries[i]
        local txt = type(e) == "table" and (tostring(e.msg or "") .. tostring(e.a1 or "") .. tostring(e.args and e.args[1] or ""))
        if txt and txt:find("LPTestAktion", 1, true) then table.remove(entries, i) end
    end
    return n1 > n0, "neu: " .. (n1 - n0), "Eintrag 'blocked'"
end

IMPL.T118 = function()
    local g = G()
    local reg = LP.eventFrame:IsEventRegistered("COMBAT_LOG_EVENT_UNFILTERED") and true or false
    if g and g.IsModern then
        return LP.handlers.COMBAT_LOG_EVENT_UNFILTERED == nil and not reg, "angemeldet " .. S(reg), "nicht angemeldet (Forever)"
    end
    return reg, "angemeldet " .. S(reg), "angemeldet (alter Client)"
end
CLIENT.T99 = "/lp testroutine kampf, dann allein einen Gegner töten – Fehlerzähler vorher/nachher gleich"

------------------------------------------------------------------------
-- D. Alte Clients
------------------------------------------------------------------------
CLIENT.T119 = "Classic Era mit 'Veraltete AddOns laden' starten, dann /lp testroutine – keine Lua-Fehler beim Laden, T01 OK"
IMPL.T120 = function()
    local g = G()
    if not g then return false, "GoldSentinelGame fehlt", "vorhanden" end
    return true, g.Status() .. (g.IsForever and "" or " – LevelPilot ist für WoW Forever gebaut, alter Client nur Ladeprüfung")
end
IMPL.T121 = function()
    local g = G()
    local want = g and (g.IsModern and true or false) or (C_QuestLog and C_QuestLog.GetInfo ~= nil)
    return LP.API.modern == want, "API.modern " .. S(LP.API.modern), S(want) .. " (laut GoldSentinelGame)"
end
SKIP.T122 = ONLY_FOREVER

------------------------------------------------------------------------
-- E. Daten (Testtabellen über LP:LoadSaved, danach wieder die echten Tabellen)
------------------------------------------------------------------------
local function WithLoad(acc, char, body)
    return Guard(function() LP:LoadSaved(acc, char) return body(acc, char) end,
        function() LP:LoadSaved(LP.Acc(), LevelPilotCharDB) end)   -- 3.12.56: Bereich der Spielversion
end

IMPL.T123 = function()
    return WithLoad({}, {}, function(acc, char)
        local miss = {}
        for k in pairs(LP.DEFAULTS) do if acc[k] == nil and LP.DEFAULTS[k] ~= nil then miss[#miss + 1] = k end end
        for k in pairs(LP.CHAR_DEFAULTS) do if char[k] == nil then miss[#miss + 1] = "char." .. k end end
        local ok = #miss == 0 and acc.speedLevelV2 == true and acc.language == "auto"
        return ok, #miss == 0 and "alle Standardwerte" or ("fehlend: " .. table.concat(miss, ",")), "alle Standardwerte"
    end)
end
IMPL.T206 = function()
    return WithLoad({}, {}, function(acc)
        local ok = acc.autoRepair == true and acc.autoFly == true and acc.restock == false and acc.autoEquipRewards == false
        return ok, string.format("autoRepair %s, autoFly %s, restock %s, autoEquipRewards %s", S(acc.autoRepair), S(acc.autoFly),
            S(acc.restock), S(acc.autoEquipRewards)), "true, true, false, false"
    end)
end
IMPL.T207 = function()
    return WithLoad({ autoRepair = false, autoFly = false, restock = true }, {}, function(acc)
        local ok = acc.autoRepair == false and acc.autoFly == false and acc.restock == true
        return ok, string.format("autoRepair %s, autoFly %s, restock %s", S(acc.autoRepair), S(acc.autoFly), S(acc.restock)), "false, false, true"
    end)
end
IMPL.T204 = function()
    local D = LP.DEFAULTS
    local ok = D.autoRepair == true and D.autoFly == true and D.restock == false and D.autoEquipRewards == false
    return ok, string.format("restock %s, autoEquipRewards %s, autoRepair %s, autoFly %s", S(D.restock), S(D.autoEquipRewards),
        S(D.autoRepair), S(D.autoFly)), "false, false, true, true (Entscheid des Nutzers 3.12.5)"
end

IMPL.T124 = function()
    local a, b
    WithLoad({ speedLevel = 3 }, {}, function(acc) a = acc.speedLevel end)
    WithLoad({ speedLevel = 3, speedLevelV2 = true }, {}, function(acc) b = acc.speedLevel end)
    return a == 2 and b == 3, S(a) .. ", " .. S(b), "2, 3"
end
IMPL.T125 = function()
    local a
    WithLoad({ language = "xx" }, {}, function(acc) a = acc.language end)
    return a == "auto", S(a), "auto"
end
IMPL.T126 = function()
    local M = LP.Protocol.Migrate
    if not M then return false, "Protocol.Migrate fehlt", "vorhanden" end
    local r = M({ k = "zone", msg = "… Das Brachland (1413), Brachland" })
    return r == "drop", S(r), "drop"
end
IMPL.T132 = function()
    local acc = { autoAccept = true }
    return WithLoad(acc, {}, function()
        LP.db.ownSettings = true
        LP.db.autoAccept = false
        local a = acc.autoAccept == true and LP.db.autoAccept == false
        LP.db.ownSettings = false
        local b = LP.db.autoAccept == true
        return a and b, "Charakter " .. S(a) .. ", Konto wieder " .. S(b), "true, true"
    end)
end
IMPL.T199 = function()
    local Pr = LP.Protocol
    local s = LevelPilotDB.protocolLog
    if type(s) ~= "table" then return true, "kein Protokoll" end
    local entries = s.entries
    entries[#entries + 1] = { k = nil, msg = 5 }
    return Guard(function() Pr:LoadEntries() return true, "Laden ohne Fehler" end,
        function() for i = #entries, 1, -1 do if entries[i] and entries[i].msg == 5 then table.remove(entries, i) end end end)
end
IMPL.T203 = function()
    local Q = LP.QuestDB
    return Q.OlderThan("1.5.0", Q.MIN_PACK) == true and Q.OlderThan("1.6.0", Q.MIN_PACK) == false,
        "Mindestversion " .. S(Q.MIN_PACK), "1.5.0 zu alt, 1.6.0 ok"
end
IMPL.T170 = function()
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return NA, "kein Datenpaket" end
    return LP.QuestDB.OlderThan(d.version, "1.6.0") == false, S(d.version), ">= 1.6.0"
end

------------------------------------------------------------------------
-- F. Sprachen
------------------------------------------------------------------------
local CODES = { "en", "fr", "es", "mx", "pt", "it", "ru", "ko", "cn", "tw" }
local function Placeholders(s)
    local out = {}
    for p in tostring(s):gsub("%%%%", ""):gmatch("%%[%-%+ #0]*%d*%.?%d*[sdif]") do out[#out + 1] = p:sub(-1) end
    return table.concat(out)
end

IMPL.T133 = function()
    local res, bad = {}, 0
    for _, code in ipairs(CODES) do
        local t = LP.Locales[code]
        local fb = LP.LanguageInfo[code] and LP.LanguageInfo[code].fallback
        local miss, ex = 0, nil
        for k in pairs(LP.usedKeys or {}) do
            if k ~= "" and not k:find("^%s*$") and not ((t and t[k]) or (fb and LP.Locales[fb] and LP.Locales[fb][k])) then
                miss = miss + 1 ex = ex or k
            end
        end
        if miss > 0 then bad = bad + 1 res[#res + 1] = code .. " " .. miss .. " (" .. tostring(ex):sub(1, 30) .. ")" end
    end
    return bad == 0, bad == 0 and (Count(LP.usedKeys) .. " benutzte Schlüssel in allen Sprachen") or table.concat(res, "; "), "0 fehlend"
end

IMPL.T134 = function()
    local res = {}
    for _, code in ipairs(CODES) do
        for k, v in pairs(LP.Locales[code] or {}) do
            if type(k) == "string" and type(v) == "string" and Placeholders(k) ~= Placeholders(v) then
                res[#res + 1] = code .. ": " .. k:sub(1, 30)
            end
        end
    end
    return #res == 0, #res == 0 and "keine Abweichung" or (#res .. ": " .. table.concat(res, "; "):sub(1, 200)), "0 Abweichungen"
end

IMPL.T135 = function()
    local bad = {}
    local VAL = { s = "x", d = 3, i = 3, f = 1.5 }
    for _, code in ipairs(CODES) do
        for k in pairs(LP.Locales[code] or {}) do
            if type(k) == "string" and k:find("%", 1, true) then
                local args = {}
                for c in Placeholders(k):gmatch(".") do args[#args + 1] = VAL[c] end
                -- nur echte Formattexte (der deutsche Schlüssel selbst lässt sich formatieren)
                if pcall(string.format, k, unpack(args)) then
                    local ok = pcall(string.format, LP.LocaleLookup(code, k), unpack(args))
                    if not ok then bad[#bad + 1] = code .. ": " .. k:sub(1, 30) end
                end
            end
        end
    end
    return #bad == 0, #bad == 0 and "alle formatierbar" or table.concat(bad, "; "):sub(1, 200), "kein Formatfehler"
end

IMPL.T137 = function()
    local bad = {}
    for _, l in ipairs(LP.LANGUAGES) do
        if not LP:CanDisplay(l.code) then
            local before = LP.db.language
            local r = LP:SetLanguage(l.code)
            LP.db.language = before
            LP:ResetLanguageCache()
            if r ~= false then bad[#bad + 1] = l.code end
        end
    end
    return #bad == 0, #bad == 0 and "ok" or table.concat(bad, ","), "SetLanguage gibt false zurück"
end

IMPL.T139 = function()
    local g = G()
    if not g or not g.Text then return true, "keine Texte" end
    local t = g.Text("game")
    return type(t) == "string" and t ~= "", S(t), "Text"
end

------------------------------------------------------------------------
-- G. Zusammenspiel
------------------------------------------------------------------------
IMPL.T140 = function()
    local loaded = {}
    local f = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
    for _, a in ipairs({ "GuildSentinel", "RaidMaster", "ThreatSentinel", "BuffSentinel", "ProfessionSentinel", "AHSentinel" }) do
        if f and f(a) then loaded[#loaded + 1] = a end
    end
    local GT, g = _G.GoldSentinelTest, _G.GoldSentinelGame
    local ok = g and g.version >= 2 and GT and GT.version >= 1 and LP.Game == g and GT.registry.LevelPilot ~= nil
    return ok and true or false, "geladen: " .. (#loaded > 0 and table.concat(loaded, ", ") or "keine"), "gemeinsame Dateien ok"
end
IMPL.T141 = function()
    local ok = _G.LevelPilot == LP and SLASH_LEVELPILOT1 == "/lp" and type(SlashCmdList.LEVELPILOT) == "function"
    return ok, ok and "ok" or "überschrieben", "eigene Namen"
end
SKIP.T143 = "keine Schnittstelle – LevelPilot nutzt keine anderen GoldSentinel-Addons"
IMPL.T145 = function()
    local f = C_ChatInfo and C_ChatInfo.IsAddonMessagePrefixRegistered
    if not f then return true, "keine Abfrage möglich" end
    local a, b = f("LvPilot2"), f("LvPilotG")
    return a and b and true or false, S(a) .. ", " .. S(b), "true, true"
end

------------------------------------------------------------------------
-- H. Leistung (je 20 Aufrufe, Median und Höchstwert)
------------------------------------------------------------------------
local function Bench(fn, n)
    local t = {}
    for i = 1, n or 20 do local a = Ms() fn() t[i] = Ms() - a end
    table.sort(t)
    return t[math.floor(#t / 2) + 1], t[#t]
end
local function BenchCheck(fn, limit, n)
    return function()
        local med, max = Bench(fn, n)
        return med < limit, string.format("Median %.2f ms, Höchstwert %.2f ms", med, max), string.format("Median < %g ms", limit)
    end
end
IMPL.T146 = BenchCheck(function() LP.UI:Refresh() end, 2)
IMPL.T147 = BenchCheck(function() LP.Engine:CheckSteps() end, 2)
-- 3.12.32 PF-A: Median < 16 ms (kein Bild > 16 ms) und Höchstwert < 33 ms (höchstens zwei Bilder)
-- 3.12.34: vorher einmal planen (Zwischenspeicher warm); der kalte Fall läuft in Portionen und hat eigenen Test T295
IMPL.T150 = function()
    pcall(LP.Planner.DoReplan, LP.Planner)
    local med, max = Bench(function() LP.Planner:Replan(true) end, 5)
    return med < 16 and max < 33, string.format("Median %.2f ms, Höchstwert %.2f ms", med, max), "Median < 16 ms, Höchstwert < 33 ms"
end
IMPL.T157 = function()
    collectgarbage("collect")
    local kb = collectgarbage("count")
    local grow = TR.memStart and (kb - TR.memStart) or 0
    local usage
    if UpdateAddOnMemoryUsage and ((C_AddOns and C_AddOns.GetAddOnMemoryUsage) or GetAddOnMemoryUsage) then
        pcall(UpdateAddOnMemoryUsage)
        local ok, kb2 = pcall((C_AddOns and C_AddOns.GetAddOnMemoryUsage) or GetAddOnMemoryUsage, "LevelPilot")
        usage = ok and kb2 or nil
    end
    return grow < 1024, string.format("Zuwachs %.0f KB (ab dem Start der Prüfungen)%s", grow,
        usage and string.format(", LevelPilot %.0f KB", usage) or ""), "< 1024 KB"
end

------------------------------------------------------------------------
-- I. Fehlerzählung
------------------------------------------------------------------------
-- 3.12.19: absichtliche Testfehler danach wieder vergessen (Zähler, letzte Meldung, Fehlerliste von
-- GoldSentinelTest), damit der Fehlerzähler im Bericht nur echte Fehler zeigt
local function ForgetTestErrors(n0, last0)
    LP.errorCount, LP.lastError = n0, last0
    for k in pairs(LP.errors) do if type(k) == "string" and k:find("LP-Testfehler", 1, true) then LP.errors[k] = nil end end
    local st = LevelPilotDB and LevelPilotDB.gsTest
    if st and type(st.errors) == "table" then
        for k, e in pairs(st.errors) do
            if type(e) == "table" and (tostring(e.msg):find("LP-Testfehler", 1, true) or e.wo == "Testroutine" or e.wo == "ticker-test") then
                st.errors[k] = nil
            end
        end
    end
end
TR.ForgetTestErrors = ForgetTestErrors

IMPL.T158 = function()
    local n0, last0 = LP.errorCount, LP.lastError
    local msg = "LP-Testfehler Safe " .. tostring(math.random(1000, 9999))
    local r = LP:Safe("Testroutine", function() error(msg, 0) end)
    local inErr = LP.errors[msg] == true
    local gt = false
    local s = LevelPilotDB.gsTest
    if s and type(s.errors) == "table" then
        for k, e in pairs(s.errors) do if type(e) == "table" and e.wo == "Testroutine" then gt = true s.errors[k] = nil end end
    end
    local ok = r == false and LP.errorCount == n0 + 1 and inErr and (gt or not LP.trackingErrors)
    local plus = LP.errorCount - n0
    ForgetTestErrors(n0, last0)
    return ok, string.format("Rückgabe %s, Zähler +%d, GoldSentinelTest %s", S(r), plus, S(gt)), "false, +1, true"
end
IMPL.T160 = function()
    local list = LP.handlers.PLAYER_XP_UPDATE
    if not list then return true, "kein Handler" end
    local n0, ran, last0 = LP.errorCount, false, LP.lastError
    table.insert(list, 1, function() error("LP-Testfehler Ereignis", 0) end)
    table.insert(list, function() ran = true end)
    return Guard(function()
        LP.eventFrame:GetScript("OnEvent")(LP.eventFrame, "PLAYER_XP_UPDATE", "player")
        return LP.errorCount == n0 + 1 and ran, "Zähler +" .. (LP.errorCount - n0) .. ", übrige liefen " .. S(ran), "+1, true"
    end, function()
        table.remove(list, 1) table.remove(list)
        ForgetTestErrors(n0, last0)
    end)
end
IMPL.T161 = function()
    local n0, ran, last0 = LP.errorCount, false, LP.lastError
    local key = "LP_TEST_FIRE2"
    LP.callbacks[key] = { function() error("LP-Testfehler Fire", 0) end, function() ran = true end }
    LP:Fire(key)
    LP.callbacks[key] = nil
    local plus = LP.errorCount - n0
    ForgetTestErrors(n0, last0)
    return plus == 1 and ran, "Zähler +" .. plus .. ", nächster lief " .. S(ran), "+1, true"
end
IMPL.T163 = function()
    local n0, last0 = LP.errorCount, LP.lastError
    local msg = "LP-Testfehler Ticker"
    LP:Safe("ticker-test", function() error(msg, 0) end)
    LP:Safe("ticker-test", function() error(msg, 0) end)
    local plus = LP.errorCount - n0
    ForgetTestErrors(n0, last0)
    return plus == 2, "Zähler +" .. plus, "+2 (Chatmeldung nur einmal)"
end
IMPL.T198 = function()
    local n = 0
    for _, t in ipairs(LP.tickers or {}) do if t.name ~= "journey" then n = n + 1 end end
    return n == 15, n .. " Ticker über LP:Ticker", "15 (ohne Reise; 3.12.26 dazu Grundregeln; 3.12.48 dazu Laufweg-Messung)"
end
SKIP.T205 = "vor dem Push mit addon-check"

------------------------------------------------------------------------
-- J. Regressionstests (wiederverwendete Prüfungen unter eigener ID)
------------------------------------------------------------------------
IMPL.T167 = IMPL.T06
IMPL.T168 = IMPL.T47
IMPL.T172 = IMPL.T40
IMPL.T173 = function()
    local P = LP.Planner
    return P.FOREVER_GREEN == 0.85 and P.GREEN_DIFF == 3, S(P.FOREVER_GREEN) .. " / " .. S(P.GREEN_DIFF), "0.85 / 3"
end
IMPL.T175 = IMPL.T44
IMPL.T176 = function()
    local P = LP.Planner
    return P.FOREVER_DG_MOB == 0.36 and P.FOREVER_DG_QUEST == 1.5, S(P.FOREVER_DG_MOB) .. " / " .. S(P.FOREVER_DG_QUEST), "0.36 / 1.5"
end
IMPL.T178 = function()
    return WithSetting({ forever = true }, function()
        return WithFlavor("forever", function()
            local t = LP.Social.ForeverGroupNote("x")
            local want = L["Ein viel höheres Gruppenmitglied kann dafür sorgen, dass alle 0 EP bekommen."]
            return t:sub(-#want) == want, "Hinweis " .. S(t ~= "x"), "endet mit dem Gruppen-EP-Hinweis"
        end)
    end)
end
IMPL.T182 = function()
    local f = LP.Comfort.XPNeed
    if not f then return false, "Comfort.XPNeed fehlt", "zugänglich" end
    local sum, n = 0, 0
    for l = 1, 59 do local v = f(l) if v then sum, n = sum + v, n + 1 end end
    return sum == 4084700 and n == 59, sum .. " in " .. n .. " Einträgen", "4084700 in 59"
end
IMPL.T185 = IMPL.T88
IMPL.T202 = function()
    local g = G()
    if not g then return true, "ohne GoldSentinelGame: Einstellung" end
    return WithSetting({ forever = true }, function()
        local a = WithFlavor("forever", function() return LP.API.Forever() end)
        local b = WithFlavor("era", function() return LP.API.Forever() end)
        return a == true and b == false, "forever " .. S(a) .. ", era " .. S(b), "true, false"
    end)
end

------------------------------------------------------------------------
-- J. 3.12.5: einmalige Hinweise auf Nachkaufen und Belohnung anlegen
------------------------------------------------------------------------
local PLAN = { { index = 1, id = 4540, purchases = 1, perBuy = 5, price = 25, name = "Test" } }

-- Hinweis-Zustand des Charakters vorübergehend leeren
local function WithOptState(body)
    local Su = LP.Supply
    local savedHints, savedPending = LP.char.optHints, Su.optPending
    LP.char.optHints, Su.optPending = {}, {}
    return Guard(body, function() LP.char.optHints, Su.optPending = savedHints, savedPending end)
end
-- Hinweise des Anbieters abfragen (ohne den Assistenten laufen zu lassen)
local function OptHintsShown()
    local list = {}
    LP.Supply.OptHintsProvider(function(key, sev, text, action, label, action2)
        list[#list + 1] = { key = key, action = action, action2 = action2 }
    end)
    return list
end

IMPL.T208 = function()
    return WithOptState(function()
        return WithSetting({ restock = false }, function()
            local mark = ActMark()
            local first = LP.Supply:CheckRestockHint(PLAN)
            local shown1 = #OptHintsShown()
            LP.Supply.optPending = {}                 -- Händler geschlossen, Sitzung geht weiter
            local second = LP.Supply:CheckRestockHint(PLAN)
            local bought = ActSince(mark, "MerchantBuy")
            return first == true and shown1 == 1 and second == false and bought == 0,
                string.format("erster Besuch %s (%d Hinweis), zweiter %s, gekauft %d", S(first), shown1, S(second), bought),
                "true (1), false, 0"
        end)
    end)
end

IMPL.T209 = function()
    local link = "|cff1eff00|Hitem:999002::::::::|h[Test]|h|r"
    local A = LP.Advisor
    local orig = A.UpgradeValue
    A.UpgradeValue = function(_, l) if l == link then return 10 end return orig(A, l) end
    return Guard(function()
        return WithOptState(function()
            return WithSetting({ autoEquipRewards = false }, function()
                local mark = ActMark()
                local first = LP.Supply:CheckRewardHint({ link })
                local shown = #OptHintsShown()
                LP.Supply.optPending = {}
                local second = LP.Supply:CheckRewardHint({ link })
                local acted = ActSince(mark, "Equip") + ActSince(mark, "GetQuestReward")
                return first == true and shown == 1 and second == false and acted == 0,
                    string.format("erste %s (%d Hinweis), zweite %s, gewählt/angelegt %d", S(first), shown, S(second), acted),
                    "true (1), false, 0"
            end)
        end)
    end, function() A.UpgradeValue = orig end)
end

IMPL.T210 = function()
    return WithOptState(function()
        return WithSetting({ restock = true, autoEquipRewards = true }, function()
            local a = LP.Supply:CheckRestockHint(PLAN)
            LP.Supply.optPending.restock = { text = "x" }          -- schon vorgemerkt, dann eingeschaltet
            local shown = #OptHintsShown()
            return a == false and shown == 0, "Hinweis " .. S(a) .. ", gezeigt " .. shown, "false, 0"
        end)
    end)
end

IMPL.T211 = function()
    return WithOptState(function()
        return WithSetting({ restock = false }, function()
            LP.Supply:CheckRestockHint(PLAN)
            local inCombat = WithCombat(true, function() return #OptHintsShown() end)
            local later = WithCombat(false, function() return #OptHintsShown() end)
            return inCombat == 0 and later == 1, "im Kampf " .. inCombat .. ", danach " .. later, "0, 1"
        end)
    end)
end

-- 3.12.5 offen-Punkt 1: dieselbe Leiche zweimal öffnen zählt Kill und Stück nur einmal
IMPL.T212 = function()
    local Ca = LP.Calib
    if not Ca.ResetLooted then return false, "Calib.ResetLooted fehlt", "zugänglich" end
    local item, npc = 999003, 99901
    local guid = "Creature-0-1-1-1-" .. npc .. "-0000ABCDEF"
    local s = LP.Acc().calib or {}
    LP.Acc().calib = s
    s.drops = type(s.drops) == "table" and s.drops or {}
    local saved, savedW = s.drops[item], Ca.testWanted
    s.drops[item] = nil
    Ca.testWanted = { [item] = { npc = { [npc] = true } } }
    local fake = {
        GetNumLootItems = function() return 1 end,
        GetLootSlotLink = function() return "|cffffffff|Hitem:" .. item .. "::::::::|h[x]|h|r" end,
        GetLootSourceInfo = function() return guid, 2 end,
        UnitExists = function() return false end,
    }
    return Guard(function()
        -- 3.12.6: Stück zählen erst bei der Beutemeldung (was liegen bleibt, zählt nicht)
        local link = "|cffffffff|Hitem:" .. item .. "::::::::|h[x]|h|r"
        local selfMsg = (LOOT_ITEM_SELF_MULTIPLE and LOOT_ITEM_SELF_MULTIPLE:gsub("%%%d?%$?s", link, 1):gsub("%%%d?%$?d", "2", 1))
            or ("Ihr bekommt Beute: " .. link .. "x2.")
        WithEnv({ Ca.OnLootOpened, Ca.IsPickpocket }, fake, function()
            Ca:OnLootOpened()
            Ca:OnLoot(selfMsg)
            Ca:OnLootClosed()
            Ca:OnLootOpened()          -- erneut geöffnet: dieselbe Leiche, keine neue Beutemeldung
            Ca:OnLootClosed()
        end)
        local d = s.drops[item] or { k = 0, g = 0 }
        return d.k == 1 and d.g == 2, "Kills " .. d.k .. ", Stück " .. d.g, "Kills 1, Stück 2"
    end, function() s.drops[item] = saved Ca.testWanted = savedW Ca.ResetLooted(guid) end)
end

------------------------------------------------------------------------
-- 3.12.6: weitere Hilfen
------------------------------------------------------------------------
-- Funktion vorübergehend durch einen Zähler ersetzen (Addon-Tabelle, nie _G). pass = true: Original danach aufrufen
local function WithCounter(tbl, key, body, pass)
    local orig = tbl[key]
    local n = 0
    tbl[key] = function(...)
        n = n + 1
        if pass and orig then return orig(...) end
    end
    return Guard(function() return body(function() return n end) end, function() tbl[key] = orig end)
end

-- Text in einem Fenster suchen (FontStrings in allen Unterfenstern)
local function FindText(frame, text, depth)
    if not frame or (depth or 0) > 12 then return false end
    if frame.GetRegions then
        for _, r in ipairs({ frame:GetRegions() }) do
            local t = r and r.GetText and r:GetText()
            if type(t) == "string" and t:find(text, 1, true) then return true end
        end
    end
    if frame.GetChildren then
        for _, c in ipairs({ frame:GetChildren() }) do
            if FindText(c, text, (depth or 0) + 1) then return true end
        end
    end
    return false
end

-- Einträge in der Fehlerliste von GoldSentinelTest (dieses Addon) zählen/entfernen
local function GTErrors(where, remove)
    local s = LevelPilotDB.gsTest
    local n = 0
    if s and type(s.errors) == "table" then
        for k, e in pairs(s.errors) do
            if type(e) == "table" and (where == nil or e.wo == where or tostring(e.msg):find(where, 1, true)) then
                n = n + 1
                if remove then s.errors[k] = nil end
            end
        end
    end
    return n
end

-- Protokoll-Einträge mit einem Text entfernen
local function DropProtocol(text)
    local entries = LP.Protocol:Entries()
    local n = 0
    for i = #entries, 1, -1 do
        local e = entries[i]
        if type(e) == "table" and tostring(e.msg or ""):find(text, 1, true) then table.remove(entries, i) n = n + 1 end
    end
    return n
end

local function HandlerList(ev) return LP.handlers[ev] or {} end
local function CallHandlers(ev, ...)
    for _, fn in ipairs(HandlerList(ev)) do fn(ev, ...) end
end

-- Kill mit EP-Meldung simulieren (Calib): Ziellevel tl, EP-Gewinn gain. Rückgabe calib.killxp
local function SimKill(tl, gain, fake)
    local Ca = LP.Calib
    local L0 = UnitLevel("player") or 1
    local xp = 100
    local f = {
        UnitLevel = function(u) if u == "target" then return tl end return L0 end,
        UnitExists = function() return true end,
        UnitIsPlayer = function() return false end,
        UnitXP = function() return xp end,
        UnitXPMax = function() return 1000000 end,
        IsInGroup = function() return false end,
        GetXPExhaustion = function() return nil end,
        IsInInstance = function() return false, "none" end,
    }
    for k, v in pairs(fake or {}) do f[k] = v end
    Ca.ResetKillXP()
    return Guard(function()
        WithEnv({ Ca.ReadTarget, Ca.OnXPUpdate, Ca.OnKillXPMessage }, f, function()
            Ca:ReadTarget()
            Ca:OnXPUpdate()
            xp = xp + gain
            if f.SetXP then f.SetXP() end
            Ca:OnXPUpdate()
            Ca:OnKillXPMessage()
        end)
    end, function() Ca.ResetKillXP() end)
end

------------------------------------------------------------------------
-- C. Forever-Sonderfälle (3.12.6)
------------------------------------------------------------------------
IMPL.T89 = function()
    local R = LP.Recorder
    local bait = "LPTestKoeder Haendler"
    local plain = "LPTestHaendler"
    local before = Count(LP.db.vendors)
    -- ohne Schutz wird der Händler erkannt (Gegenprobe), mit Schutz nicht
    local function rec(name)
        return WithEnv({ R.RecordService }, { UnitName = function() return name end, UnitGUID = function() return nil end,
            CanMerchantRepair = function() return false end }, function() R:RecordService("merchant") end)
    end
    local pos = LP.Geo:Player() ~= nil
    WithSecret({ bait }, function() rec(bait) end)
    local secretN = Count(LP.db.vendors)
    rec(plain)
    local plainN = Count(LP.db.vendors)
    for k, v in pairs(LP.db.vendors) do if type(v) == "table" and v.name == plain then LP.db.vendors[k] = nil end end
    LP.QuestDB:InvalidateServices()
    local ok = secretN == before and (plainN == before + 1 or not pos)
    return ok, string.format("geschützt %+d, Gegenprobe %+d", secretN - before, plainN - before), "geschützt +0, Gegenprobe +1"
end
IMPL.T186 = IMPL.T89

IMPL.T90 = function()
    local bait, baitUnit = "LPTestKoeder Kiste", "LPTestKoeder Einheit"
    local added = 0
    local tt = {
        GetUnit = function() return bait, baitUnit end,
        GetItem = function() return nil end,
        GetOwner = function() return UIParent end,
        AddLine = function() added = added + 1 end,
        Show = function() end,
    }
    local left = { GetText = function() return bait end }
    return WithSecret({ bait, baitUnit }, function()
        return WithEnv({ LP.Tooltips.OnShowObject, LP.Tooltips.OnUnit }, { GameTooltipTextLeft1 = left }, function()
            LP.Tooltips.OnShowObject(tt)
            tt.lpObjectDone = nil
            LP.Tooltips.OnUnit(tt)
            return added == 0, "Zeilen " .. added, "0"
        end)
    end)
end
IMPL.T187 = IMPL.T90

-- 3.12.21: Addon-Nachrichten kommen über GoldSentinelSync an (eigenes Ereignis-Frame der gemeinsamen Datei)
local OWN_PREFIX = { LvPilot2 = true, LvPilotG = true }   -- eigene Kennungen bei GoldSentinelSync
local function Deliver(prefix, msg, dist, sender)
    local Sy = _G.GoldSentinelSync
    if Sy and Sy.OnAddonMessage then Sy.OnAddonMessage(prefix, msg, dist, sender) end
end
TR.Deliver = Deliver

-- CHAT_MSG_ADDON mit geschützten Werten: geschützte Kennung/Nachricht -> nichts; geschützter Absender -> Comm
-- verarbeitet ohne Absender (keine Antwort), Group ignoriert (Gegenprobe ohne Schutz)
IMPL.T92 = function()
    local Gp = LP.Group
    local who = "LPTester-Test"
    local prefixC, prefixG = "LvPilot2", "LvPilotG"
    local msgG = "S\t5\t10\tGOTO\t0\ttext"
    local recv0 = LP.db.net and LP.db.net.recv
    return WithCounter(LP.Comm, "Receive", function(nC)
        return WithCounter(Gp, "OnMessage", function(nG)
            WithSecret({ "LPTestNachricht", msgG }, function()
                Deliver(prefixC, "LPTestNachricht", "WHISPER", who)
                Deliver(prefixG, msgG, "PARTY", who)
            end)
            local secretC, secretG = nC(), nG()
            -- nur der Absender geschützt: Comm ohne Absender, Group nichts
            WithSecret({ who }, function()
                Deliver(prefixC, "LPTestNachricht2", "WHISPER", who)
                Deliver(prefixG, msgG, "PARTY", who)
            end)
            local anonC, anonG = nC() - secretC, nG() - secretG
            -- Gegenprobe ohne Schutz: beide würden verarbeiten
            Deliver(prefixC, "LPTestNachricht3", "WHISPER", "LPTester2-Test")
            Deliver(prefixG, msgG, "PARTY", "LPTester2-Test")
            local plainC, plainG = nC() - secretC - anonC, nG() - secretG - anonG
            local ok = secretC == 0 and secretG == 0 and anonC == 1 and anonG == 0 and plainC == 1 and plainG == 1
            return ok, string.format("geschützt Comm %d Group %d · Absender geschützt Comm %d Group %d · Gegenprobe Comm %d Group %d",
                secretC, secretG, anonC, anonG, plainC, plainG), "0/0 · 1/0 · 1/1"
        end)
    end)
end
IMPL.T189 = IMPL.T92

-- Testkandidat für die Namensplaketten: Questziel "LPTestwolf getötet"
local function PlateCand()
    return { { id = 999101, title = "LPTest", byNpc = {}, objs = { { text = "LPTestwolf getötet: 0/8", have = 0, need = 8,
        finished = false, type = "monster" } } } }
end
IMPL.T93 = function()
    local bait = "LPTestwolf"
    local cand = PlateCand()
    local fake = { UnitName = function() return bait end, UnitGUID = function() return "LPTestKoeder GUID" end,
                   UnitIsPlayer = function() return false end, UnitIsDead = function() return false end }
    local plain = WithEnv({ LP.Plates.ForUnit }, fake, function() return LP.Plates:ForUnit("target", true, cand) end)
    local secret = WithSecret({ bait, "LPTestKoeder GUID" }, function()
        return WithEnv({ LP.Plates.ForUnit }, fake, function() return LP.Plates:ForUnit("target", true, cand) end)
    end)
    return secret == nil and plain ~= nil, "geschützt " .. S(secret ~= nil) .. ", Gegenprobe " .. S(plain ~= nil), "kein Treffer, Gegenprobe Treffer"
end

-- EP-Messung je Kill: echte Werte messen, geschützte nicht
IMPL.T74 = function()
    local P = LP.Planner
    local L0 = UnitLevel("player") or 1
    if L0 >= 60 then return NA, "Level 60 – keine EP" end
    local f = P:KillXPFormula(L0, L0)
    return WithEmptyCalib(function()
        local c = LP.Acc().calib
        SimKill(L0, f)
        local k = c.killxp and c.killxp[0]
        local n1, r1 = k and k.n or 0, k and k.n > 0 and k.sum / k.n or 0
        SimKill(L0, f, { GetXPExhaustion = function() return 500 end })
        local n2 = c.killxp and c.killxp[0] and c.killxp[0].n or 0
        SimKill(L0, f, { IsInGroup = function() return true end })
        local n3 = c.killxp and c.killxp[0] and c.killxp[0].n or 0
        local ok = n1 == 1 and Near(r1, 1, 0.01) and n2 == 1 and n3 == 1
        return ok, string.format("gemessen %d (Verhältnis %.2f), erholt %+d, Gruppe %+d", n1, r1, n2 - n1, n3 - n2), "1 (1.00), +0, +0"
    end)
end

IMPL.T94 = function()
    local L0 = UnitLevel("player") or 1
    if L0 >= 60 then return NA, "Level 60 – keine EP" end
    local f = LP.Planner:KillXPFormula(L0, L0)
    local baitL, baitXP = "LPTestKoeder Level", "LPTestKoeder EP"
    return WithEmptyCalib(function()
        local c = LP.Acc().calib
        -- geschütztes Ziellevel
        WithSecret({ baitL }, function()
            SimKill(L0, f, { UnitLevel = function(u) if u == "target" then return baitL end return L0 end })
        end)
        local n1 = Count(c.killxp)
        -- geschützte EP
        WithSecret({ baitXP }, function()
            SimKill(L0, f, { UnitXP = function() return baitXP end })
        end)
        local n2 = Count(c.killxp)
        return n1 == 0 and n2 == 0, "Messungen: Level geschützt " .. n1 .. ", EP geschützt " .. n2, "0, 0"
    end)
end

IMPL.T95 = function()
    local bait = "LPTestKoeder Klasse"
    local line = WithSecret({ bait }, function()
        return WithEnv({ LP.Measure.UnitLine }, { UnitExists = function() return true end, UnitIsPlayer = function() return false end,
            UnitClassification = function() return bait end, UnitGUID = function() return nil end, UnitLevel = function() return 5 end,
            UnitName = function() return "LPTest" end }, function() return LP.Measure.UnitLine("target") end)
    end)
    local ok = type(line) == "string" and not line:find(bait, 1, true) and line:find(" ? ", 1, true) ~= nil
    return ok, ok and "\"?\" statt des Werts" or S(line), "\"?\""
end
IMPL.T200 = IMPL.T95

-- erstes Paket-NPC mit Levelbereich (für die Gegenprobe)
local function PackNpcWithLevel()
    local N = _G.LevelPilotData and _G.LevelPilotData.N
    if type(N) ~= "table" then return nil end
    local n = 0
    for id, e in pairs(N) do
        n = n + 1
        if type(e) == "table" and type(e.lo) == "number" and e.lo > 0 and e.lo < 55 then return id, e end
        if n > 2000 then break end
    end
    return nil
end
IMPL.T96 = function()
    local Ca = LP.Calib
    local id, npc = PackNpcWithLevel()
    local guid = "Creature-0-1-1-1-" .. (id or 99902) .. "-0000ABCDEF"
    local lv = npc and ((npc.hi or npc.lo) + 3) or 10
    local c = LP.Acc().calib or {}
    LP.Acc().calib = c
    c.mobs = type(c.mobs) == "table" and c.mobs or {}
    local saved = c.mobs[id or 99902]
    c.mobs[id or 99902] = nil
    local fake = { UnitExists = function() return true end, UnitIsPlayer = function() return false end,
                   UnitPlayerControlled = function() return false end,
                   UnitGUID = function() return guid end, UnitLevel = function() return lv end }
    return Guard(function()
        WithSecret({ guid }, function() WithEnv({ Ca.ObserveUnit }, fake, function() Ca:ObserveUnit("target") end) end)
        local a = c.mobs[id or 99902] == nil
        WithSecret({ lv }, function() WithEnv({ Ca.ObserveUnit }, fake, function() Ca:ObserveUnit("target") end) end)
        local b = c.mobs[id or 99902] == nil
        WithEnv({ Ca.ObserveUnit }, fake, function() Ca:ObserveUnit("target") end)
        local plain = c.mobs[id or 99902] ~= nil
        return a and b and (plain or not id), string.format("GUID geschützt %s, Level geschützt %s, Gegenprobe %s",
            a and "nichts" or "gelernt", b and "nichts" or "gelernt", plain and "gelernt" or "nichts"), "nichts, nichts, gelernt"
    end, function() c.mobs[id or 99902] = saved end)
end

IMPL.T98 = function()
    local bx, bm = "LPTestKoeder EP", "LPTestKoeder EPmax"
    return WithSecret({ bx, bm }, function()
        return WithEnv({ LP.PlayerXP }, { UnitXP = function() return bx end, UnitXPMax = function() return bm end }, function()
            local xp, mx, readable = LP:PlayerXP()
            LP.Comfort:TimerText()
            LP.Comfort:TimeTo60()
            LP.Comfort:TimeToLevel()
            LP.UI:Refresh()
            return readable == false and xp == 0 and mx == 1, string.format("lesbar %s, EP %s/%s", S(readable), S(xp), S(mx)),
                "lesbar false, 0/1, kein Lua-Fehler"
        end)
    end)
end

IMPL.T100 = function()
    local API = LP.API
    local fakeQ = Without(C_QuestLog, "GetNumQuestLogEntries", "GetQuestObjectives", "GetQuestTagInfo", "IsQuestFlaggedCompleted",
        "GetLogIndexForQuestID") or false
    return WithEnv({ API.NumEntries, API.Objectives, API.QuestTag, API.IsQuestDone, API.LogIndexForQuest, API.Entry },
        { C_QuestLog = fakeQ, GetNumQuestLogEntries = false, GetNumQuestLeaderBoards = false, GetQuestTagInfo = false,
          IsQuestFlaggedCompleted = false, GetQuestLogTitle = false }, function()
        local n, o, t, d, i = API.NumEntries(), API.Objectives(1), API.QuestTag(999104), API.IsQuestDone(1), API.LogIndexForQuest(1)
        local ok = n == 0 and type(o) == "table" and #o == 0 and t == nil and d == false and i == nil
        return ok, string.format("%s, %s Ziele, %s, %s, %s", S(n), S(type(o) == "table" and #o), S(t), S(d), S(i)), "0, 0 Ziele, nil, false, nil"
    end)
end

-- Selbsttest-Prüfung "Schnittstellen" mit fehlenden Funktionen
local function InterfacesCheck(fake)
    local fn
    for _, c in ipairs(LP.SelfTest.CHECKS or {}) do if c.name == "Schnittstellen" then fn = c.fn end end
    if not fn then return nil end
    local res = WithEnv({ fn }, fake, function() return LP.SelfTest:RunCheck("Schnittstellen") end)
    local t = {}
    for _, r in ipairs(res or {}) do t[#t + 1] = r.text end
    return table.concat(t, " ")
end

IMPL.T105 = function()
    local API = LP.API
    local fake = { UnitCharacterPoints = false, GetUnspentTalentPoints = false }
    return WithEnv({ API.TalentPoints }, fake, function()
        local p = API.TalentPoints()
        local talentHint = false
        WithSetting({ advTalents = true }, function()
            LP.Advisor:Run()
            for _, h in ipairs(LP.Advisor.hints or {}) do if h.key == "talents" then talentHint = true end end
        end)
        local diag = InterfacesCheck(fake) or ""
        local ok = p == nil and not talentHint and diag:find(L["Talentpunkte"], 1, true) ~= nil
        return ok, string.format("Punkte %s, Hinweis %s, Diagnose %s", S(p), S(talentHint),
            diag:find(L["Talentpunkte"], 1, true) and "nennt Talentpunkte" or "ohne Eintrag"), "nil, false, nennt Talentpunkte"
    end)
end

-- 3.12.21: der frühere Kanal LevelPilotNet wird nur noch verlassen, nie betreten
IMPL.T108 = function()
    local Comm = LP.Comm
    if not Comm.LeaveOldChannel then return false, "Comm.LeaveOldChannel fehlt", "zugänglich" end
    local function run(idx)
        local mark = ActMark()
        WithEnv({ Comm.LeaveOldChannel }, { GetChannelName = function() return idx end, LeaveChannelByName = function() end },
            function() Comm.LeaveOldChannel() end)
        return ActSince(mark, "LeaveChannelByName")
    end
    local a, b = run(7), run(0)
    return a == 1 and b == 0, string.format("im Kanal: verlassen %d×, nicht im Kanal: %d×", a, b), "1×, 0×"
end
IMPL.T193 = IMPL.T108

IMPL.T109 = function()
    local Su, H = LP.Supply, LP.Hints
    local fake = { GetPetHappiness = false, GetPetFoodTypes = false, UnitClass = function() return "Jäger", "HUNTER" end,
                   UnitExists = function() return true end }
    WithSetting({ restockPetFood = true, hintClass = true }, function()
        WithEnv({ Su.Needs, H.ClassReminders }, fake, function()
            Su:Needs()
            H.ClassReminders(function() end)
        end)
    end)
    local diag = InterfacesCheck(fake) or ""
    local a = diag:find(L["Zufriedenheit des Begleiters"], 1, true) ~= nil
    local b = diag:find(L["Futter des Begleiters"], 1, true) ~= nil
    return a and b, "Diagnose: Zufriedenheit " .. S(a) .. ", Futter " .. S(b), "beide als nicht verfügbar"
end

IMPL.T110 = function()
    local D, Nm, Pr = LP.Donate, LP.Names, LP.Protocol
    local used = 0
    local a = WithEnv({ D.AddonTitle }, { C_AddOns = false, GetAddOnMetadata = function() used = used + 1 return "|cffffb238LevelPilot|r" end },
        function() return D.AddonTitle() end)
    local b = WithEnv({ D.AddonTitle }, { C_AddOns = false, GetAddOnMetadata = false }, function() return D.AddonTitle() end)
    WithEnv({ Nm.Load }, { C_AddOns = false, LoadAddOn = false }, function() Nm:Load("xx") Nm:Load(LP:Language()) end)
    if Pr.Memory then WithEnv({ Pr.Memory }, { UpdateAddOnMemoryUsage = false }, function() Pr.Memory() end) end
    local ok = a == "LevelPilot" and used == 1 and b == "LevelPilot"
    return ok, string.format("alt %s (%d×), ohne beide %s", S(a), used, S(b)), "LevelPilot (1×), LevelPilot"
end

IMPL.T111 = function()
    local Gp, Se = LP.Group, LP.Session
    if not Gp.Send then return false, "Group.Send fehlt", "zugänglich" end
    return WithSetting({ groupSync = true }, function()
        -- 3.12.21: Gruppe über GoldSentinelSync (nur an die Gruppe, nie ins Netz)
        local Sy = _G.GoldSentinelSync
        local api = Sy and Sy.api
        if not api then return false, "GoldSentinelSync fehlt", "geladen" end
        local oGroup, oRaid = api.inGroup, api.inRaid
        local a, b, net0 = 0, 0, Sy.netQueue and #Sy.netQueue or 0
        local snap = LP.Comm:QueueSnapshot()
        Guard(function()
            api.inGroup, api.inRaid = function() return true end, function() return false end
            local q0 = LP.Comm:QueueCount()
            WithEnv({ Gp.InGroup }, { IsInGroup = function() return true end }, function() Gp.Send("R") end)
            a = LP.Comm:QueueCount() - q0
            q0 = LP.Comm:QueueCount()
            WithSetting({ groupSync = false }, function()
                WithEnv({ Gp.InGroup }, { IsInGroup = function() return true end }, function() Gp.Send("R") end)
            end)
            b = LP.Comm:QueueCount() - q0
        end, function() api.inGroup, api.inRaid = oGroup, oRaid LP.Comm:QueueRestore(snap) end)
        local netAdded = (Sy.netQueue and #Sy.netQueue or 0) - net0
        if netAdded > 0 then a = -1 end
        local mark = ActMark()
        WithEnv({ Se.Summary }, { C_ChatInfo = false, SendChatMessage = false, IsInGuild = function() return true end },
            function() Se:Summary(true) end)
        local c = ActSince(mark, "SendChatMessage")
        return a == 1 and b == 0 and c == 0, string.format("Gruppe %d, Gruppenmodus aus %d, Bilanz %d", a, b, c), "1, 0, 0"
    end)
end

-- Flug-Schritt vorgeben (Engine:Current, Addon-Tabelle)
local function FlyStep(body)
    local E = LP.Engine
    local orig = E.Current
    E.Current = function() return { t = "FLY", text = "LPTestflugpunkt", key = "LPTestFlug" } end
    return Guard(body, function() E.Current = orig end)
end

-- weitere alte Globals, je einzeln weg
IMPL.T112 = function()
    local E, C, A, Su, H, Ac = LP.Engine, LP.Comfort, LP.Advisor, LP.Supply, LP.Hints, LP.Actions
    local step = { t = "COMPLETE", id = 999105, key = "LPTest" }
    local cases = {
        { { E.HandleGreeting }, "GetNumActiveQuests", function() E.HandleGreeting() end },
        { { E.HandleGreeting }, "GetActiveTitle", function() E.HandleGreeting() end },
        { { E.HandleGreeting }, "SelectActiveQuest", function() E.HandleGreeting() end },
        { { E.HandleGreeting }, "GetNumAvailableQuests", function() E.HandleGreeting() end },
        { { C.Repair }, "GetRepairAllCost", function() C:Repair() end, { CanMerchantRepair = function() return true end } },
        { { A.Checks.Durability }, "GetInventoryItemDurability", function() A.Checks.Durability(function() end) end },
        { { A.Checks.Ammo }, "GetInventoryItemCount", function() A.Checks.Ammo(function() end) end,
          { UnitClass = function() return "Jäger", "HUNTER" end, GetInventoryItemLink = function() return "item:2504" end } },
        { { Su.Needs }, "GetItemInfoInstant", function() Su:Needs() end,
          { C_Item = Without(C_Item, "GetItemInfoInstant") or false, UnitClass = function() return "Jäger", "HUNTER" end,
            GetInventoryItemLink = function() return "item:2504" end } },
        { { C.AutoFly }, "NumTaxiNodes", function() FlyStep(function() C:AutoFly() end) end },
        { { C.AutoFly }, "TaxiNodeName", function() FlyStep(function() C:AutoFly() end) end },
        { { H.LearnTrainerCosts }, "GetNumTrainerServices", function() H:LearnTrainerCosts() end },
        { { H.ClassReminders }, "GetWeaponEnchantInfo", function() H.ClassReminders(function() end) end,
          { UnitClass = function() return "Schurke", "ROGUE" end } },
        { { Ac.ItemFor }, "GetQuestLogSpecialItemInfo", function() Ac.ItemFor(step) end },
        { { Ac.Update }, "GetItemIcon", function() Ac:Update() end, { C_Item = Without(C_Item, "GetItemIconByID") or false } },
    }
    local bad = {}
    WithSetting({ autoTurnin = true, autoAccept = true, autoRepair = true, autoFly = true, advDurability = true, advAmmo = true,
                  restockAmmo = true, hintClass = true }, function()
        for _, c in ipairs(cases) do
            local fake = { [c[2]] = false }
            for k, v in pairs(c[4] or {}) do fake[k] = v end
            local ok, err = pcall(WithEnv, c[1], fake, c[3])
            if not ok then bad[#bad + 1] = c[2] .. ": " .. tostring(err):sub(1, 80) end
        end
    end)
    return #bad == 0, #bad == 0 and (#cases .. " Fälle ohne Fehler") or table.concat(bad, "; "), "kein Lua-Fehler"
end

IMPL.T113 = function()
    local Nm = LP.Names
    local threw = 0
    return WithEnv({ Nm.Init }, { collectgarbage = function() threw = threw + 1 error("LP-Testfehler collectgarbage", 0) end }, function()
        local ok, err = pcall(Nm.Init, Nm)
        local st = Nm:StatusText()
        return ok and type(st) == "string", ok and ("Laden zu Ende" .. (threw > 0 and ", collectgarbage warf" or "")) or tostring(err),
            "Laden läuft zu Ende"
    end)
end
IMPL.T190 = IMPL.T113

IMPL.T114 = function()
    local Ac = LP.Actions
    local btn = _G.LevelPilotTargetButton
    if not btn then return false, "LevelPilotTargetButton fehlt", "vorhanden" end
    -- Zustand vorher/nachher vergleichen (der sichere Knopf selbst wird nie verändert)
    local function state()
        return tostring(btn.GetAttribute and btn:GetAttribute("macrotext")), btn:IsShown() and true or false,
            Ac.bar and Ac.bar:IsShown() and true or false
    end
    local m1, s1, b1 = state()
    local touched = 0
    local fake = { InCombatLockdown = function() return true end }
    WithEnv({ Ac.Update }, fake, function()
        WithCounter(LP.Engine, "Current", function(n)
            Ac:Update()
            touched = n()
        end)
    end)
    local m2, s2, b2 = state()
    local inCombat = touched == 0 and m1 == m2 and s1 == s2 and b1 == b2
    -- nach dem Kampf: PLAYER_REGEN_ENABLED holt die Aktualisierung nach
    local runs = WithCounter(Ac, "Update", function(n)
        for _, fn in ipairs(HandlerList("PLAYER_REGEN_ENABLED")) do pcall(fn, "PLAYER_REGEN_ENABLED") end
        return n()
    end, true)
    return inCombat and runs >= 1, string.format("im Kampf: Schritt gelesen %d×, Knopf %s · danach %d Aktualisierung", touched,
        inCombat and "unverändert" or "verändert", runs), "0×, unverändert · danach >= 1"
end

------------------------------------------------------------------------
-- J. Regressionstests (3.12.6)
------------------------------------------------------------------------
IMPL.T169 = function()
    return WithFlavor("forever", function()
        local a = LP.SameName("Testa", "Testa Beispiel")
        local b = LP.SameName("Testa Beispiel", "Testa Eisenfaust")
        local me = UnitName("player")
        local realm = GetRealmName and GetRealmName() or "Realm"
        local own = tostring(me) .. "-" .. tostring(realm):gsub("%s", "")
        local members = Count(LP.Group.members)
        local c = WithCounter(LP.Comm, "Receive", function(n)
            Deliver("LvPilot2", "LPTestNachricht", "WHISPER", own)
            Deliver("LvPilotG", "S\t5\t10\tGOTO\t0\ttext", "PARTY", own)
            return n()
        end)
        local m2 = Count(LP.Group.members)
        return a == true and b == false and c == 0 and m2 == members, string.format("%s, %s, eigene Nachricht: Comm %d, Group %+d",
            S(a), S(b), c, m2 - members), "true, false, 0, +0"
    end)
end

CLIENT.T171 = "/dump select(4, GetBuildInfo()) – Nummer in LevelPilot.toc und LevelPilot_Data.toc, 16001 bleibt drin"

IMPL.T177 = function()
    local P, Ca = LP.Planner, LP.Calib
    local a = { IMPL.T74() }
    local b = { IMPL.T94() }
    local L0 = UnitLevel("player") or 1
    if L0 >= 60 or L0 < 6 then return a[1] and b[1] and true or false, "Level " .. L0 .. " – Messung auf Stufe -3 nicht möglich" end
    return WithEmptyCalib(function()
        return WithSetting({ forever = true }, function()
            return WithFlavor("forever", function()
                local f = P:KillXPFormula(L0, L0 - 3)
                for _ = 1, 20 do SimKill(L0 - 3, math.floor(f * 0.7 + 0.5)) end
                local r = Ca:KillXPRatio(-3)
                local g, measured = P:GreenXPFactor(-3)
                local txt = Ca:KillXPText()
                local ok = a[1] and b[1] and r ~= nil and Near(g, r, 0.001) and measured == true and txt:find("20", 1, true) ~= nil
                return ok and true or false, string.format("T74 %s, T94 %s, Stufe -3: %.2f (%s), %s", S(a[1]), S(b[1]), g or 0,
                    S(measured), txt), "OK, OK, Messwert ersetzt 0.85, gemessen 20"
            end)
        end)
    end)
end

IMPL.T179 = function()
    local key = "aus deinen EP der letzten Stunde – gilt für jeden Modus (Normal und Speedrun)"
    local miss = {}
    for _, code in ipairs(CODES) do
        local t = LP.Locales[code]
        local fb = LP.LanguageInfo[code] and LP.LanguageInfo[code].fallback
        if not ((t and t[key]) or (fb and LP.Locales[fb] and LP.Locales[fb][key])) then miss[#miss + 1] = code end
    end
    local f = _G.LevelPilotCenter
    local wasShown = f and f:IsShown()
    local shown = Guard(function()
        if not (f and f:IsShown()) then LP.Center:Toggle() end
        LP.Center:Select("comfort")
        return FindText(_G.LevelPilotCenter, L[key])
    end, function() if _G.LevelPilotCenter and not wasShown then _G.LevelPilotCenter:Hide() end end)
    return #miss == 0 and shown, "angezeigt " .. S(shown) .. (#miss > 0 and (", fehlt in " .. table.concat(miss, ",")) or ", alle 10 Sprachen"),
        "angezeigt, alle 10 Sprachen"
end

IMPL.T184 = function()
    local B = LP.Backup
    local ok, err = pcall(Slash, "reise bericht")
    local f = _G.LevelPilotBackupFrame
    local titled = f and FindText(f, L["Virtuelle Reise – Bericht"]) or false
    if f then f:Hide() end
    return ok and titled, ok and ("Titel übersetzt " .. S(titled)) or tostring(err), "kein Fehler, Titel übersetzt"
end

IMPL.T195 = function()
    local a = { IMPL.T105() }
    local b = { IMPL.T109() }
    return a[1] and b[1] and true or false, "T105 " .. S(a[1]) .. ", T109 " .. S(b[1]), "beide OK"
end
CLIENT.T195 = "/dump UnitCharacterPoints, /dump GetUnspentTalentPoints, /dump GetPetHappiness, /dump GetPetFoodTypes – Ergebnis zurückmelden"
CLIENT.T213 = "/dump C_SpellBook.IsSpellKnown(3273) und /dump IsPlayerSpell(3273) – Erste Hilfe gelernt? Beide Antworten zurückmelden"

-- K13: Dropraten ohne Kampflog (3.12.6: Kill bei der EP-Meldung, Stück über CHAT_MSG_LOOT)
IMPL.T196 = function()
    local Ca = LP.Calib
    local g = G()
    if not (g and g.IsModern) then return true, "alter Client: Kampflog wie bisher" end
    local item, npc = 999006, 99906
    local guid = "Creature-0-1-1-1-" .. npc .. "-0000ABCD01"
    local guid2 = "Creature-0-1-1-1-" .. npc .. "-0000ABCD02"
    local s = LP.Acc().calib or {}
    LP.Acc().calib = s
    s.drops = type(s.drops) == "table" and s.drops or {}
    local saved, savedW = s.drops[item], Ca.testWanted
    s.drops[item] = nil
    Ca.testWanted = { [item] = { npc = { [npc] = true } } }
    local link = "|cffffffff|Hitem:" .. item .. "::::::::|h[x]|h|r"
    local tguid = guid
    local target = { UnitExists = function() return true end, UnitGUID = function() return tguid end, UnitIsDead = function() return true end }
    local loot = {
        GetNumLootItems = function() return 1 end,
        GetLootSlotLink = function() return link end,
        GetLootSourceInfo = function() return tguid, 2 end,
        UnitExists = function() return false end,
    }
    local selfMsg = (LOOT_ITEM_SELF_MULTIPLE and LOOT_ITEM_SELF_MULTIPLE:gsub("%%%d?%$?s", link, 1):gsub("%%%d?%$?d", "2", 1))
        or ("Ihr bekommt Beute: " .. link .. "x2.")
    local function D() local d = s.drops[item] or { k = 0, g = 0 } return d.k, d.g end
    return Guard(function()
        -- 1) Kill bei der EP-Meldung, Leiche ohne Beute (nie geöffnet)
        WithEnv({ Ca.OnXPKill }, target, function() Ca:OnXPKill() end)
        local k1, g1 = D()
        -- 2) zweite Leiche: EP-Meldung, dann plündern (Kill nicht doppelt), Beutemeldung x2
        tguid = guid2
        WithEnv({ Ca.OnXPKill }, target, function() Ca:OnXPKill() end)
        WithEnv({ Ca.OnLootOpened, Ca.IsPickpocket }, loot, function() Ca:OnLootOpened() end)
        Ca:OnLoot(selfMsg)
        Ca:OnLootClosed()
        local k2, g2 = D()
        -- 3) erneut geöffnet, Tasche voll: nichts kommt an -> keine Stück
        WithEnv({ Ca.OnLootOpened, Ca.IsPickpocket }, loot, function() Ca:OnLootOpened() end)
        Ca:OnLootClosed()
        local k3, g3 = D()
        -- 4) geschützte GUID bei der EP-Meldung -> kein Kill
        tguid = "Creature-0-1-1-1-" .. npc .. "-0000ABCD03"
        WithSecret({ tguid }, function() WithEnv({ Ca.OnXPKill }, target, function() Ca:OnXPKill() end) end)
        local k4 = D()
        local ok = k1 == 1 and g1 == 0 and k2 == 2 and g2 == 2 and k3 == 2 and g3 == 2 and k4 == 2
        return ok, string.format("ohne Beute %d/%d · geplündert %d/%d · liegen gelassen %d/%d · geschützt %d", k1, g1, k2, g2, k3, g3, k4),
            "1/0 · 2/2 · 2/2 · 2 (Kills/Stück)"
    end, function()
        s.drops[item] = saved
        Ca.testWanted = savedW
        Ca.ResetLooted(guid) Ca.ResetLooted(guid2) Ca.ResetLooted(tguid)
    end)
end

IMPL.T201 = function()
    local Tt, Q = LP.Tooltips, LP.QuestDB
    local I = _G.LevelPilotData and _G.LevelPilotData.I
    local item
    local n = 0
    for id in pairs(type(I) == "table" and I or {}) do
        n = n + 1
        local info = Q:ItemQuests(id)
        if info and info.starts and #info.starts > 0 then item = id break end
        if n > 3000 then break end
    end
    if not item then return true, "kein Gegenstand, der eine Quest startet (ohne Datenpaket)" end
    return WithSetting({ tooltips = true }, function()
        return WithCounter(LP.API, "IsQuestDone", function(calls)
            Tt:ItemLines(item)
            Tt:IsProtected(item)
            return calls() >= 1, "LP.API.IsQuestDone " .. calls() .. "×", ">= 1×"
        end, true)
    end)
end

------------------------------------------------------------------------
-- B. Funktionen (3.12.6)
------------------------------------------------------------------------
local function Shown(name) local f = _G[name] return f and f:IsShown() and true or false end
local function Hide(name) local f = _G[name] if f then f:Hide() end end

-- alle Slash-Befehle in pcall: Fehlerliste
local function SlashAll(list)
    local bad = {}
    for _, m in ipairs(list) do
        local ok, err = pcall(Slash, m)
        if not ok then bad[#bad + 1] = "\"" .. m .. "\": " .. tostring(err):sub(1, 80) end
    end
    return bad
end

IMPL.T16 = function()
    local ui0, ce0, compact0 = LP.UI:IsShown(), Shown("LevelPilotCenter"), LP.db.compactMode
    local bad = SlashAll({ "" })
    local ui1 = LP.UI:IsShown()
    bad = SlashAll({ "" })
    local ce = {}
    for _, m in ipairs({ "zentrale", "center" }) do
        local a = Shown("LevelPilotCenter")
        for _, e in ipairs(SlashAll({ m })) do bad[#bad + 1] = e end
        ce[#ce + 1] = Shown("LevelPilotCenter") ~= a
    end
    for _, m in ipairs({ "kompakt", "kompakt", "compact", "compact" }) do for _, e in ipairs(SlashAll({ m })) do bad[#bad + 1] = e end end
    local donate = {}
    for _, m in ipairs({ "spenden", "donate", "support" }) do
        for _, e in ipairs(SlashAll({ m })) do bad[#bad + 1] = e end
        local f = LP.Donate.frame or _G.LevelPilotDonateFrame
        donate[#donate + 1] = f == nil or f:IsShown()
        if f then f:Hide() end
    end
    if LP.UI:IsShown() ~= ui0 then LP.UI:Toggle() end
    if Shown("LevelPilotCenter") ~= ce0 then LP.Center:Toggle() end
    local ok = #bad == 0 and ui1 ~= ui0 and ce[1] and ce[2] and LP.db.compactMode == compact0 and donate[1] and donate[2] and donate[3]
    return ok and true or false, #bad > 0 and table.concat(bad, "; ") or string.format("Guide wechselt %s, Zentrale %s/%s, kompakt gleich %s",
        S(ui1 ~= ui0), S(ce[1]), S(ce[2]), S(LP.db.compactMode == compact0)), "alles wechselt, kompakt wie vorher"
end

IMPL.T18 = function()
    local P = LP.Planner
    local old = P.priority
    return Guard(function()
        local bad = SlashAll({ "way 45.5 60.2" })
        local p1 = P.priority
        local a = p1 and p1.t == "GOTO" and Near(p1.x, 45.5, 0.01) and Near(p1.y, 60.2, 0.01)
        for _, e in ipairs(SlashAll({ "weg 10 20" })) do bad[#bad + 1] = e end
        local p2 = P.priority
        local b = p2 and p2.t == "GOTO" and Near(p2.x, 10, 0.01) and Near(p2.y, 20, 0.01)
        for _, e in ipairs(SlashAll({ "find repar", "such flug", "find xyz" })) do bad[#bad + 1] = e end
        local pos = LP.Geo:Player() ~= nil
        return #bad == 0 and ((a and b) or not pos) and true or false,
            #bad > 0 and table.concat(bad, "; ") or ("way " .. S(a) .. ", weg " .. S(b)), "GOTO 45.5/60.2 und 10/20, kein Fehler"
    end, function() P.priority = old pcall(P.Replan, P) end)
end

IMPL.T20 = function()
    local mark = ActMark()
    local bad = SlashAll({ "teilen", "share", "gruppe", "lfg", "bilanz", "summary", "bilanz gilde", "summary guild" })
    local guild = IsInGuild and IsInGuild() and ((C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage) and true or false
    local sent = ActSince(mark, "SendChatMessage")
    local push = ActSince(mark, "QuestLogPushQuest")
    local share = LP.Social:ShareList()
    local sum = LP.Session:Summary(false)
    local want = L("LevelPilot-Bilanz: %d Level, %d Quests, %s, %s aktiv gespielt", 0, 0, "", ""):match("^[^:]+")
    local ok = #bad == 0 and (guild and sent == 2 or (not guild and sent == 0)) and (push == 0 or #share > 0)
        and type(sum) == "string" and sum:sub(1, #want) == want
    return ok and true or false, #bad > 0 and table.concat(bad, "; ") or string.format("Gilde %s: %d mitgeschrieben, Teilen %d, Bilanz %s",
        S(guild), sent, push, sum:sub(1, #want)), "Gilde nur mit Gilde, Bilanz-Text"
end

IMPL.T21 = function()
    local Pr = LP.Protocol
    local f = function() return _G.LevelPilotBackupFrame end
    local opened = {}
    local bad = {}
    for _, m in ipairs({ "protokoll", "log", "diag", "diagnose", "plan", "messen", "measure", "test", "selbsttest" }) do
        if f() then f():Hide() end
        for _, e in ipairs(SlashAll({ m })) do bad[#bad + 1] = e end
        if m == "protokoll" or m == "messen" or m == "test" then opened[#opened + 1] = f() and f():IsShown() or false end
        if f() then f():Hide() end
    end
    for _, e in ipairs(SlashAll({ "protokoll leer" })) do bad[#bad + 1] = e end
    local n = Pr:Count()
    local ok = #bad == 0 and n == 0 and opened[1] and opened[2] and opened[3]
    return ok and true or false, #bad > 0 and table.concat(bad, "; ") or string.format("Kopierfenster %s/%s/%s, Protokoll danach %d",
        S(opened[1]), S(opened[2]), S(opened[3]), n), "Fenster auf und zu, Protokoll 0"
end

IMPL.T22 = function()
    local V = LP.Virtual
    if not LP:IsDev() then
        local bad = SlashAll({ "reise hier" })
        local was = V.active
        if V.active then V:Abort() end
        return #bad == 0 and not was, "ohne Testmodus: Reise gestartet " .. S(was), "nichts"
    end
    local bad = SlashAll({ "reise hier", "reise stop", "reise zuschauen", "reise stopp", "reise bericht", "journey report" })
    Hide("LevelPilotBackupFrame") Hide("LevelPilotVirtualFrame")
    local active = V.active
    if V.active then V:Abort() end
    local sb = V.s and V.s.sandboxDiff
    local ok = #bad == 0 and not active and (sb == nil or #sb == 0)
    return ok, #bad > 0 and table.concat(bad, "; ") or ("Reise aktiv " .. S(active) .. ", Sandbox " .. (sb and #sb == 0 and "OK" or "?")),
        "aus, Sandbox OK (\"reise vergleich\" nur mit /lp testroutine reise)"
end

IMPL.T25 = function()
    local UI = LP.UI
    local db = LP.db
    local saved = { db.compactMode, db.stepsShown, db.scale, db.locked }
    local was = UI:IsShown()
    return Guard(function()
        UI:Toggle() UI:Toggle()
        local same = UI:IsShown() == was
        if not UI:IsShown() then UI:Toggle() end
        for _, v in ipairs({ true, false }) do db.compactMode = v UI:ApplySettings() UI:Refresh() end
        for _, v in ipairs({ 1, 5, 10 }) do db.stepsShown = v UI:ApplySettings() UI:Refresh() end
        for _, v in ipairs({ 0.6, 1.6 }) do db.scale = v UI:ApplySettings() UI:Refresh() end
        for _, v in ipairs({ true, false }) do db.locked = v UI:ApplySettings() end
        local grip = type(UI.CreateSizeGrip) == "function"
        local cur = LP.Engine:Current()
        local txt = cur and UI:StepText(cur, false)
        local ok = same and grip and (cur == nil or (type(txt) == "string" and txt ~= ""))
        return ok, string.format("Toggle zweimal gleich %s, Text %s", S(same), cur and S(txt ~= "") or "kein Schritt"), "kein Fehler, Text"
    end, function()
        db.compactMode, db.stepsShown, db.scale, db.locked = saved[1], saved[2], saved[3], saved[4]
        UI:ApplySettings()
        if UI:IsShown() ~= was then UI:Toggle() end
    end)
end

IMPL.T26 = function()
    local E, UI = LP.Engine, LP.UI
    local step = E:Current()
    if not step then return NA, "kein Schritt geplant" end
    if step.t == "LEVEL" or step.key == "NODATA" or step.key == "NOPOS" or step.key == "DGIN" then
        return NA, "aktueller Schritt lässt sich nicht überspringen (" .. tostring(step.t) .. ")"
    end
    local saved = {}
    for _, k in ipairs({ "ignored", "doneKeys", "notOffered", "dungeonRun" }) do saved[k] = LP.Backup.DeepCopy(LP.char[k] or {}) end
    local lastIgn = E.lastIgnored
    local function planned()
        for _, s in ipairs(E:Steps()) do if s.key == step.key then return true end end
        return false
    end
    return Guard(function()
        UI:StepMenu(nil, step)
        local menuShown = Shown("LevelPilotStepMenu")
        Hide("LevelPilotStepMenu")
        E:Skip(step)
        local gone = not planned()
        local quest = step.id and (step.t == "ACCEPT" or step.t == "COMPLETE" or step.t == "TURNIN")
        if quest then E:Unignore() else LP.char.doneKeys[step.key] = nil end
        LP.Planner:Replan(true)
        local back = planned()
        E:Later(step)
        local later = E:IsLater(step.key) and not planned()
        E.later[step.key] = nil
        E:ResetIgnored()
        return menuShown and gone and back and later, string.format("Menü %s, übersprungen %s, wieder geplant %s, zurückgestellt %s",
            S(menuShown), S(gone), S(back), S(later)), "Menü, übersprungen, wieder geplant, zurückgestellt"
    end, function()
        E.later[step.key] = nil
        E.lastIgnored = lastIgn
        for k, v in pairs(saved) do
            local cur = LP.char[k]
            if type(cur) == "table" then
                for kk in pairs(cur) do if v[kk] == nil then cur[kk] = nil end end
                for kk, vv in pairs(v) do cur[kk] = vv end
            end
        end
        pcall(LP.Planner.Replan, LP.Planner, true)
    end)
end

IMPL.T28 = function()
    local b = _G.LevelPilotMinimapButton
    if not b then return false, "Minimap-Button fehlt", "vorhanden" end
    local was, angle = LP.db.showMinimapBtn, LP.db.minimapAngle
    return Guard(function()
        LP.db.showMinimapBtn = false LP.UI:ApplySettings()
        local off = not b:IsShown()
        LP.db.showMinimapBtn = true LP.UI:ApplySettings()
        local on = b:IsShown() and true or false
        return off and on and LP.db.minimapAngle == angle, "aus versteckt " .. S(off) .. ", an sichtbar " .. S(on), "versteckt, sichtbar, Winkel gleich"
    end, function() LP.db.showMinimapBtn = was LP.UI:ApplySettings() end)
end

IMPL.T29 = function()
    local a = _G.LevelPilotArrow
    local was = LP.db.showArrow
    return Guard(function()
        LP.db.showArrow = false
        LP.Nav:Refresh()
        local hidden = not a or not a:IsShown()
        LP.db.showArrow = true
        LP.Nav:Refresh()
        return hidden, "aus versteckt " .. S(hidden), "versteckt"
    end, function() LP.db.showArrow = was pcall(LP.Nav.Refresh, LP.Nav) end)
end

-- Zentrale öffnen und alle Reiter einmal aufbauen
local function WithCenter(body)
    local f = _G.LevelPilotCenter
    local was = f and f:IsShown()
    return Guard(function()
        if not (_G.LevelPilotCenter and _G.LevelPilotCenter:IsShown()) then LP.Center:Toggle() end
        for _, k in ipairs({ "route", "dungeons", "data", "share", "assist", "comfort", "extras", "settings" }) do LP.Center:Select(k) end
        return body()
    end, function() if _G.LevelPilotCenter and not was then _G.LevelPilotCenter:Hide() end end)
end

IMPL.T31 = function()
    return WithCenter(function()
        local list, seen = {}, {}
        for i = #(LP.Center.toggles or {}), 1, -1 do
            local t = LP.Center.toggles[i]
            if not seen[t.key] then seen[t.key] = true list[#list + 1] = t end
        end
        local mark = ActMark()
        local bad, changed = {}, {}
        for _, t in ipairs(list) do
            local before = LP.db[t.key]
            local ok1, e1 = pcall(t.button.Click, t.button)
            local mid = LP.db[t.key]
            local ok2, e2 = pcall(t.button.Click, t.button)
            if not ok1 or not ok2 then bad[#bad + 1] = t.key .. ": " .. tostring(e1 or e2):sub(1, 60)
            elseif LP.db[t.key] ~= before then changed[#changed + 1] = t.key
            elseif (not mid) == (not before) then bad[#bad + 1] = t.key .. ": schaltet nicht" end
        end
        local ok = #bad == 0 and #changed == 0 and #list >= 60
        return ok, string.format("%d Schalter, Fehler: %s, nicht zurück: %s", #list,
            #bad > 0 and table.concat(bad, "; ") or "keine", #changed > 0 and table.concat(changed, ",") or "keine"),
            ">= 60 Schalter, alle zweimal, Wert wie vorher"
    end)
end

IMPL.T32 = function()
    return WithCenter(function()
        local bad = {}
        local list = {}
        local seen = {}
        for i = #(LP.Center.steppers or {}), 1, -1 do
            local st = LP.Center.steppers[i]
            if not seen[st.label] then seen[st.label] = true list[#list + 1] = st end
        end
        for _, st in ipairs(list) do
            -- Seite des Steppers zeigen (die Anzeige wird nur auf der sichtbaren Seite erneuert)
            for k, p in pairs(LP.Center.pages or {}) do if p == st.page then LP.Center:Select(k) end end
            local v0 = st.get()
            local ok, err = pcall(function()
                local steps = math.ceil((st.max - st.min) / st.step) + 2
                for _ = 1, steps do st.plus:Click() end
                if math.abs(st.get() - st.max) > 1e-6 then error("Maximum " .. tostring(st.get()) .. " statt " .. st.max, 0) end
                local txt = st.val:GetText()
                if txt ~= string.format(st.fmt, st.get()) then error("Text " .. tostring(txt), 0) end
                for _ = 1, steps do st.minus:Click() end
                if math.abs(st.get() - st.min) > 1e-6 then error("Minimum " .. tostring(st.get()) .. " statt " .. st.min, 0) end
                txt = st.val:GetText()
                if txt ~= string.format(st.fmt, st.get()) then error("Text " .. tostring(txt), 0) end
            end)
            st.set(v0)
            if not ok then bad[#bad + 1] = tostring(st.label):sub(1, 30) .. ": " .. tostring(err) end
            if st.get() ~= v0 then bad[#bad + 1] = tostring(st.label):sub(1, 30) .. ": nicht zurück" end
        end
        LP.UI:ApplySettings()
        LP.Center:Refresh()
        -- im Code gibt es 11 Stepper; einen zwölften "Vorräte" hat die Zentrale nicht (Mengen kommen aus den Grundwerten)
        return #bad == 0 and #list >= 11, #list .. " Stepper" .. (#bad > 0 and (": " .. table.concat(bad, "; ")) or ""),
            "alle Stepper (11 im Code), Grenzen halten, Text = format(Wert)"
    end)
end

IMPL.T33 = function()
    return WithCenter(function()
        LP.Center:Select("comfort")
        local n = 0
        for _, l in ipairs(LP.LANGUAGES) do if LP:CanDisplay(l.code) then n = n + 1 end end
        local btn = 0
        for _, e in ipairs(LP.Center.langButtons or {}) do if e.button:IsShown() then btn = btn + 1 end end
        return btn == n + 1, "Knöpfe " .. S(btn) .. ", anzeigbare Sprachen " .. n, "1 + anzeigbare Sprachen"
    end)
end

IMPL.T34 = function()
    return WithCenter(function()
        LP.Center:Select("data")
        local bad = {}
        local B = LP.Backup
        for _, fn in ipairs({ function() LP.QuestDB:Reconnect() end, function() LP.Planner:Diagnose() end,
                              function() LP.Protocol:Show() end, function() LP.SelfTest:Show(false) end,
                              function() B:ShowExport() end, function() B:ShowImport() end }) do
            local ok, err = pcall(fn)
            if not ok then bad[#bad + 1] = tostring(err):sub(1, 80) end
            Hide("LevelPilotBackupFrame")
        end
        local jb = LP.Center.journeyButtons or {}
        local vis = 0
        for _, b in ipairs(jb) do if b:IsShown() then vis = vis + 1 end end
        local want = LP:IsDev() and #jb or 0
        return #bad == 0 and #jb == 3 and vis == want, string.format("Fehler %d, Reiseknöpfe %d sichtbar von %d", #bad, vis, #jb),
            "kein Fehler, 3 Reiseknöpfe nur im Testmodus"
    end)
end

IMPL.T36 = function()
    local Gp = LP.Group
    local who = "LPTester-Test"
    local saved = Gp.members.LPTester
    return Guard(function()
        Gp:OnMessage("S\t5\t10\tGOTO\t0\ttext", who)
        Gp:Refresh()
        local st = Gp:Status(Gp.members.LPTester or {})
        local shared = Gp:SharedQuests()
        local panel = _G.LevelPilotGroupPanel
        local inGroup = IsInGroup and IsInGroup() or false
        local hidden = inGroup or not panel or not panel:IsShown()
        return hidden and (shared == nil or type(shared) == "table"), "Status " .. S(st) .. ", Panel ohne Gruppe versteckt " .. S(hidden), "kein Fehler, versteckt"
    end, function() Gp.members.LPTester = saved pcall(Gp.Refresh, Gp) end)
end

IMPL.T37 = function()
    local Ac = LP.Actions
    local was = LP.db.showActionBar
    return Guard(function()
        LP.db.showActionBar = false Ac:Update()
        LP.db.showActionBar = true Ac:Update()
        local m = Ac.MacroText({ "Kobold", "Wolf" })
        local long = {}
        for i = 1, 30 do long[i] = "Sehr langer Name eines Gegners Nummer " .. i end
        local m2 = Ac.MacroText(long)
        local b1 = _G["BINDING_NAME_CLICK LevelPilotTargetButton:LeftButton"]
        local b2 = _G["BINDING_NAME_CLICK LevelPilotItemButton:LeftButton"]
        local ok = m:sub(1, 12) == "/cleartarget" and m:find("/targetexact Kobold", 1, true) ~= nil and #m2 <= 255 and b1 ~= nil and b2 ~= nil
        return ok, string.format("Makro %d Zeichen, lang %d Zeichen, Tasten %s/%s", #m, #m2, S(b1 ~= nil), S(b2 ~= nil)),
            "/cleartarget … /targetexact Kobold, <= 255, Tasten gesetzt"
    end, function() LP.db.showActionBar = was pcall(Ac.Update, Ac) end)
end

IMPL.T45 = function()
    local P = LP.Planner
    local d = _G.LevelPilotData
    if type(d) ~= "table" or type(d.Q) ~= "table" then return NA, "kein Datenpaket" end
    local real = LP.char.mode
    local speed0 = LP.db.speedLevel
    return Guard(function()
        local bad = {}
        for _, lv in ipairs({ 1, 2, 3 }) do
            LP.db.speedLevel = lv
            P:SetMode("speed")
            local ok, err = pcall(P.Replan, P, true)
            if not ok then bad[#bad + 1] = lv .. ": " .. tostring(err):sub(1, 60) end
        end
        LP.db.speedLevel = 2
        P:Replan(true)
        local escort, protectedSkipped = nil, nil
        for id in pairs(P.speedSkip) do
            local q = d.Q[id]
            if type(q) == "table" and q.tg == 84 then escort = id end
            if P:IsProtected(id) then protectedSkipped = id end
        end
        if #bad > 0 then return false, table.concat(bad, "; "), "kein Fehler" end
        if not escort then
            if protectedSkipped then return false, "Klassenquest übersprungen: " .. S(protectedSkipped), "Klassenquest nein" end
            return NA, "keine Eskortenquest im Bereich (Stufen 1–3 ohne Fehler, keine Klassenquest übersprungen)"
        end
        return protectedSkipped == nil, "Eskorte " .. escort .. " übersprungen, Klassenquest übersprungen: " .. S(protectedSkipped), "Eskorte ja, Klassenquest nein"
    end, function() LP.db.speedLevel = speed0 P:SetMode(real) end)
end

IMPL.T46 = function()
    local P = LP.Planner
    local ov = P:DungeonOverview()
    local n = type(ov) == "table" and #ov or 0
    for _, d in ipairs(LP.Dungeons or {}) do P:DungeonUsable(d.area or d.id or d[1]) break end
    P:PlanInstance(LP:PlayerLevel() or 1)
    local rows = WithCenter(function()
        LP.Center:Select("dungeons")
        return FindText(_G.LevelPilotCenter, L["Dungeons"]) or n == 0
    end)
    return type(ov) == "table" and rows and true or false, n .. " Dungeons in der Übersicht", "Liste, Reiter zeigt Zeilen"
end

IMPL.T48 = function()
    local E = LP.Engine
    local id = 999301
    local ign = LP.char.ignored
    local saved = ign[id]
    ign[id] = true
    return Guard(function()
        local want = E:WantQuest(id, "LPTest")
        E:CheckSteps()
        local dg = E:InDungeon()
        local inInst = IsInInstance and select(1, IsInInstance())
        E:UpdateInstance()
        return want == false and (dg == false or (inInst and true or false)), "WantQuest " .. S(want) .. ", Dungeon " .. S(dg), "false, false"
    end, function() ign[id] = saved end)
end

IMPL.T49 = function()
    local id = 999302
    local mark = ActMark()
    local choices = 0
    local selActive = {}
    local gossip = {
        GetActiveQuests = function() return { { title = "Fertig", questID = 999303, isComplete = true } } end,
        GetAvailableQuests = function() return { { title = "Neu", questID = id } } end,
        SelectActiveQuest = function(q) selActive[#selActive + 1] = q end,
        SelectAvailableQuest = function() end,
    }
    local fake = {
        GetQuestID = function() return id end, GetTitleText = function() return "LPTest" end,
        IsQuestCompletable = function() return true end, GetNumQuestChoices = function() return choices end,
        C_GossipInfo = gossip, IsShiftKeyDown = function() return false end,
    }
    local list = {}
    for _, ev in ipairs({ "QUEST_DETAIL", "QUEST_PROGRESS", "QUEST_COMPLETE", "GOSSIP_SHOW", "QUEST_GREETING" }) do
        for _, fn in ipairs(HandlerList(ev)) do list[#list + 1] = fn end
    end
    list[#list + 1] = LP.Engine.HandleGossip
    list[#list + 1] = LP.Engine.HandleGreeting
    local origWant = LP.Engine.WantQuest
    local ign = LP.char.ignored
    local savedIgn = ign[id]
    return Guard(function()
        LP.Engine.WantQuest = function(_, qid) return qid == id and not ign[id] end
        local r = {}
        WithEnv(list, fake, function()
            WithSetting({ autoAccept = true, autoTurnin = true }, function()
                local m = ActMark()
                CallHandlers("QUEST_DETAIL")
                r.accept = ActSince(m, "AcceptQuest")
                m = ActMark()
                WithSetting({ autoAccept = false }, function() CallHandlers("QUEST_DETAIL") end)
                r.acceptOff = ActSince(m, "AcceptQuest")
                for _, c in ipairs({ 0, 1, 2 }) do
                    choices = c
                    m = ActMark()
                    CallHandlers("QUEST_COMPLETE")
                    r["c" .. c] = ActSince(m, "GetQuestReward")
                end
                m = ActMark()
                CallHandlers("GOSSIP_SHOW")
                local first = LP.Act.log[m + 1]
                r.gossip = first and first.name or "-"
                ign[id] = true
                m = ActMark()
                CallHandlers("QUEST_DETAIL")
                r.ignored = ActSince(m, "AcceptQuest")
            end)
        end)
        local ok = r.accept == 1 and r.acceptOff == 0 and r.c0 == 1 and r.c1 == 1 and r.c2 == 0 and r.gossip == "SelectActiveQuest" and r.ignored == 0
        return ok, string.format("Annehmen %d/%d, Belohnung 0:%d 1:%d 2:%d, Gossip zuerst %s, ignoriert %d", r.accept, r.acceptOff,
            r.c0, r.c1, r.c2, r.gossip, r.ignored), "1/0, 1 1 0, SelectActiveQuest, 0"
    end, function() LP.Engine.WantQuest = origWant ign[id] = savedIgn end)
end

IMPL.T51 = function()
    local Gr, Geo = LP.Graph, LP.Geo
    local st = Gr:Stats()
    local i1, n1, w1 = Geo:ToWorld(1411, 0.52, 0.44)
    local i2, n2, w2 = Geo:ToWorld(1454, 0.45, 0.55)
    if not i1 then return false, "Geo:ToWorld(1411) liefert nichts", "Weltkoordinaten" end
    local path = i2 and Gr:Path(i1, n1, w1, 1411, i2, n2, w2, 1454)
    local near = Gr:Near(i1, n1, w1, 2000, 1411)
    local nearest = Gr:Nearest(i1, n1, w1, 4000, 1411)
    local s0 = st.nodes or st.count or 0
    local id1 = Gr:AddNode(i1, n1 + 37, w1 + 41, 1411)
    local id2 = Gr:AddNode(i1, n1 + 77, w1 + 81, 1411)
    local added = Gr:AddEdge(id1, id2, "s")
    local st2 = Gr:Stats()
    -- Startwege: so viele, wie die Startdatenbank enthält (Data/Seed.lua, zurzeit leer – die Wege kommen aus dem Wegenetz)
    local seedN = #((LP.Seed and LP.Seed.paths) or {})
    local seedOk = (seedN == 0 and (st.seedEdges or 0) == 0) or (st.seedEdges or 0) > 0
    local st2n = st2.nodes or st2.count or 0
    local ok = seedOk and type(path) == "table" and type(near) == "table" and nearest ~= nil and id1 and id2 and added and st2n >= s0
    return ok and true or false, string.format("Startwege %s (Startdatenbank %d), Weg %s Punkte, Knoten nah %d, neu %s/%s", S(st.seedEdges), seedN,
        S(type(path) == "table" and #path), type(near) == "table" and #near or 0, S(id1), S(id2)), "Startwege > 0, Weg, Knoten"
end

IMPL.T52 = function()
    local T = LP.Terrain
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return NA, "kein Datenpaket" end
    local a = T:Available(1411)
    _G.LevelPilotData = nil
    local b = Guard(function() return T:Available(1411) end, function() _G.LevelPilotData = d end)
    local i, n, w = LP.Geo:ToWorld(1411, 0.4, 0.4)
    local i2, n2, w2 = LP.Geo:ToWorld(1411, 0.6, 0.6)
    local seg = T:Segment(1411, { i, n, w }, { i2, n2, w2 })
    local ref = T:Refine({ { i, n, w, 1411 }, { i2, n2, w2, 1411 } })
    T:Unknown(1411, { i, n, w }, { i2, n2, w2 })
    T:Clear()
    LP.Graph:ClearTerrainCache()
    return a == true and b == false and type(ref) == "table", "mit Paket " .. S(a) .. ", ohne " .. S(b) .. ", Strecke " .. S(seg ~= nil),
        "true, false, Punkte"
end

IMPL.T53 = function()
    local Cv = LP.Caves
    local a, b, c = Cv:Count()
    local i, n, w = LP.Geo:ToWorld(1411, 0.33, 0.77)
    local isNew = Cv:Store({ i = i, en = n, ew = w, cn = n + 30, cw = w + 30, r = 60 })
    Cv:Rebuild()
    local a2, b2, c2 = Cv:Count()
    Cv:At(i, n + 30, w + 30)
    Cv:Same({ inst = i, cn = n, cw = w, r = 60 }, { inst = i, cn = n + 5, cw = w, r = 60 })
    Cv:All() Cv:Rebuild() Cv:Tick()
    return type(a) == "number" and type(b) == "number" and type(c) == "number" and isNew and b2 == b + 1,
        string.format("%s/%s/%s -> %s/%s/%s", S(a), S(b), S(c), S(a2), S(b2), S(c2)), "3 Zahlen, +1"
end

IMPL.T54 = function()
    local Dg, Geo = LP.Danger, LP.Geo
    local L0 = UnitLevel("player") or 1
    Dg:Ready()
    local id, npc = PackNpcWithLevel()
    if npc then Dg:MobLevel(npc, id) end
    local i, n, w = Geo:ToWorld(1411, 0.5, 0.5)
    local i2, n2, w2 = Geo:ToWorld(1411, 0.4, 0.3)
    Dg:At(i, n, w) Dg:AtMap(1411, 0.5, 0.5) Dg:Route(i, n, w, n2, w2) Dg:Segment(i, n, w, n2, w2)
    Dg:OK(L0, L0) Dg:Limit(L0)
    local path = { { i, n, w, 1411 }, { i2, n2, w2, 1411 } }
    Dg:PathDanger(path)
    Dg:GrindSpot(i, n, w, L0, 300)
    local grey = L0 - LP.Planner:GreyLevel(L0)
    local minLevel = math.max(1, L0 - 3)
    local kills, sum = Dg:WayKills(path, L0, grey, 120, minLevel)
    local avg = kills > 0 and sum / kills or nil
    local ok = type(kills) == "number" and (kills == 0 or (avg >= minLevel and avg <= L0 + 2))
    return ok, string.format("Weg-Kills %d, Mittel %s", kills, avg and string.format("%.1f", avg) or "–"), "Mittel zwischen " .. minLevel .. " und " .. (L0 + 2)
end

IMPL.T58 = function()
    local R, API = LP.Recorder, LP.API
    local id = 999401
    local saved = LP.db.qdb[id]
    return Guard(function()
        local e = R:Entry(id, true)
        local own = LP.db.qdb[id] == e and e.net == nil
        local a1, a2 = API.AcceptedArgs(1234, nil)
        local b1, b2 = API.AcceptedArgs(3, 1234)
        R:ScanProgress() R:FlushTrail(true) R:SamplePath()
        local n0 = Count(LP.db.vendors)
        WithEnv({ R.RecordService }, { UnitName = function() return nil end }, function() R:RecordService("merchant") end)
        local none = Count(LP.db.vendors) == n0
        local ok = own and a2 == 1234 and a1 == API.LogIndexForQuest(1234) and b1 == 3 and b2 == 1234 and none
        return ok, string.format("Eintrag %s, (1234,nil)->(%s,%s), (3,1234)->(%s,%s), ohne NPC %s", S(own), S(a1), S(a2), S(b1), S(b2),
            none and "nichts" or "angelegt"), "eigener Eintrag, (LogIndex,1234), (3,1234), nichts"
    end, function() LP.db.qdb[id] = saved end)
end

-- leere Sandbox-Questdatenbank
local function WithQdb(tbl, body)
    local saved = LP.db.qdb
    LP.db.qdb = tbl
    LP.QuestDB:Invalidate()
    return Guard(body, function() LP.db.qdb = saved LP.QuestDB:Invalidate() end)
end

IMPL.T59 = function()
    local Comm = LP.Comm
    local sender = "LPTest-Realm"
    local id = 299501
    local i, n, w = LP.Geo:ToWorld(1411, 0.5, 0.5)
    local test = { [id] = { n = "LPTestquest", l = 12, f = "H", s = { i, n, w }, o = { [1] = { { i, n + 20, w + 20 } } } } }
    local msgs = WithQdb(test, function() return Comm:EncodeQuest(id) end) or {}
    local bad = {}
    local res = WithQdb({}, function()
        for _, m in ipairs(msgs) do local ok, err = pcall(Comm.Receive, Comm, m, sender) if not ok then bad[#bad + 1] = err end end
        local r = LP.db.qdb[id]
        local got = r and r.net == true and r.n == "LPTestquest" and r.l == 12 and r.f == "H" and r.o ~= nil
        -- eigener Eintrag: nur Bestätigung
        LP.db.qdb[id + 1] = { n = "Eigen", l = 5, f = "H", by = 0 }
        local enc = WithQdb({ [id + 1] = { n = "Eigen", l = 7, f = "A" } }, function() return Comm:EncodeQuest(id + 1) end)
        LP.db.qdb[id + 1] = { n = "Eigen", l = 5, f = "H", by = 0 }
        for _, m in ipairs(enc or {}) do pcall(Comm.Receive, Comm, m, sender) end
        local o = LP.db.qdb[id + 1]
        local ownOk = o.by == 1 and o.l == 5 and o.f == "H" and o.net == nil
        -- ungültige Quests
        local n0 = Count(LP.db.qdb)
        for _, m in ipairs({ "Q\t299503\t12\tX\t\t\tName\t0", "Q\t0\t12\tH\t\t\tName\t0", "Q\t299504\t99\tH\t\t\tName\t0" }) do
            local ok, err = pcall(Comm.Receive, Comm, m, sender) if not ok then bad[#bad + 1] = err end
        end
        local invalidOk = Count(LP.db.qdb) == n0
        return { got = got, own = ownOk, invalid = invalidOk }
    end)
    -- jede Art gültig und kaputt (Wirkung landet in der Sandbox)
    local item
    for k in pairs((_G.LevelPilotData and _G.LevelPilotData.I) or {}) do item = k break end
    local mob, npc = PackNpcWithLevel()
    local kinds = {
        { "H\t3.12.6", "H" },
        { "Z\t1411", "Z\tx" },
        { "E\t1411\t12\t" .. id, "E\tx\ty" },
        { "C\t" .. (i or 0) .. "\t" .. math.floor(n or 0) .. "\t" .. math.floor(w or 0) .. "\t1411\t" .. math.floor((n or 0) + 30) .. "\t" .. math.floor((w or 0) + 30) .. "\t60", "C\t1\t2" },
        { item and ("D\t" .. item .. "\t10\t5\t2") or "D\t1\t10\t5", "D\tx\t1" },
        { mob and ("M\t" .. mob .. "\t" .. npc.lo .. "\t" .. (npc.lo + 1)) or "M\t1\t1\t2", "M\t1\t70\t1" },
        { "F\t3\t3000\t90", "F\t0" },
        { "P\t" .. (i or 0) .. "\t" .. math.floor(n or 0) .. "," .. math.floor(w or 0) .. ",1411;" .. math.floor((n or 0) + 10) .. "," .. math.floor((w or 0) + 10) .. ",1411\t1", "P\t0\tzz" },
    }
    local leak = 0
    WithQdb({}, function()
        for _, k in ipairs(kinds) do
            local ok1, e1 = pcall(Comm.Receive, Comm, k[1], sender)
            local q0 = Count(LP.db.qdb)
            local c0 = select(1, LP.Caves:Count())
            local ok2, e2 = pcall(Comm.Receive, Comm, k[2], sender)
            if not ok1 then bad[#bad + 1] = k[1]:sub(1, 1) .. ": " .. tostring(e1):sub(1, 60) end
            if not ok2 then bad[#bad + 1] = k[2]:sub(1, 1) .. " kaputt: " .. tostring(e2):sub(1, 60) end
            if Count(LP.db.qdb) ~= q0 or select(1, LP.Caves:Count()) ~= c0 then leak = leak + 1 end
        end
    end)
    if LP.Social and LP.Social.partners then LP.Social.partners.LPTest = nil end
    local ok = #bad == 0 and res.got and res.own and res.invalid and leak == 0
    return ok and true or false, string.format("Quest übernommen %s, eigene nur bestätigt %s, ungültig verworfen %s, kaputt ohne Eintrag %s%s",
        S(res.got), S(res.own), S(res.invalid), S(leak == 0), #bad > 0 and (" · Fehler: " .. table.concat(bad, "; ")) or ""), "alles true, kein Fehler"
end

IMPL.T61 = function()
    local Comm = LP.Comm
    local mark = ActMark()
    local snap = Comm:QueueSnapshot()
    return Guard(function()
        Comm:Queue("H\tLPTest", "PARTY")
        Comm:Broadcast({ "H\tLPTest2" }, "lptest")
        for _ = 1, 3 do if Comm.SendNext then Comm:SendNext() end end
        Comm:Hello()
        Comm:Rejoin()
        local st = Comm:Stats()
        local sends, prefixOk = 0, true
        for i = mark + 1, #LP.Act.log do
            local e = LP.Act.log[i]
            if e.name == "SendAddonMessage" then sends = sends + 1 if e.a1 ~= "LvPilot2" and e.a1 ~= "LvPilotG" then prefixOk = false end end
        end
        return type(st) == "table" and st.sent ~= nil and st.recv ~= nil and prefixOk,
            string.format("mitgeschrieben %d, Präfix %s, Stats sent/recv %s/%s", sends, prefixOk and "LvPilot2" or "falsch", S(st.sent), S(st.recv)),
            "nur mitgeschrieben, Präfix LvPilot2, Stats"
    end, function() Comm:QueueRestore(snap) end)
end

IMPL.T62 = function()
    local Comm = LP.Comm
    local mark = ActMark()
    local snap = Comm:QueueSnapshot()
    return Guard(function()
        Comm:RequestZone(1411, true)
        Comm:ReplyZone("LPTest", 1411)
        Comm:OnZoneRequest("LPTest", 1411)
        for _ = 1, 5 do if Comm.SendNext then Comm:SendNext() end end
        local n = ActSince(mark)
        return n >= 1, "mitgeschrieben " .. n, ">= 1"
    end, function() Comm:QueueRestore(snap) end)
end

IMPL.T64 = function()
    local So = LP.Social
    local mark = ActMark()
    local saved = So.partners and So.partners.LPTester
    return Guard(function()
        local list = So:ShareList()
        local step = { t = "COMPLETE", id = 999601, elite = true, q = "LPTest", key = "LPTestElite" }
        local text = So:GroupText(step)
        local line = So:OpenGroupChat(step)
        local r = {}
        WithSetting({ findPartners = true }, function()
            So:OnMessage({ "E", "1411", "12", "999601" }, "LPTester-Test")
            r.on = So.partners.LPTester ~= nil
            So:Matches()
            So.partners.LPTester = nil
            So:Announce()
        end)
        WithSetting({ findPartners = false }, function()
            So:OnMessage({ "E", "1411", "12", "999601" }, "LPTester-Test")
            r.off = So.partners.LPTester == nil
        end)
        local real = 0
        local ok = type(list) == "table" and (text == nil or text:find("^LF[GM]") ~= nil) and r.on and r.off
        return ok and true or false, string.format("Teilen %d, Text %s, Partner an %s, aus ignoriert %s", #list, S(text and text:sub(1, 3)),
            S(r.on), S(r.off)), "Liste, LFG/LFM, an erkannt, aus ignoriert"
    end, function() if So.partners then So.partners.LPTester = saved end end)
end

IMPL.T69 = function()
    local H = LP.Hints
    local up = H:UpcomingClassQuests()
    H:TrainerCost(LP:PlayerLevel() or 1)
    H:RidingTrainer()
    H:LearnTrainerCosts()
    local keys = { "hintClassQuests", "hintClass", "hintTrainer", "hintMount", "hintProfessions" }
    local bad = {}
    for _, k in ipairs(keys) do
        for _, v in ipairs({ true, false }) do
            local ok, err = pcall(WithSetting, { [k] = v }, function() LP.Advisor:Run() end)
            if not ok then bad[#bad + 1] = k .. ": " .. tostring(err):sub(1, 60) end
        end
    end
    LP.Advisor:Run()
    return type(up) == "table" and #bad == 0, #up .. " Klassenquests" .. (#bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "Liste, kein Fehler"
end

IMPL.T70 = function()
    local Pi = LP.Pins
    Pi:Refresh()
    local ok = type(Pi.areas) == "table" and type(Pi.objects) == "table" and type(Pi.avail) == "table"
    Pi:NearestObject() Pi:CheckAlert() Pi:UpdateMinimap() Pi:UpdateWorldMap()
    local bad = {}
    for _, k in ipairs({ "mapAreas", "mapAvailable", "objPins", "objArrow", "objAlert" }) do
        for _, v in ipairs({ false, true }) do
            local okc, err = pcall(WithSetting, { [k] = v }, function() Pi:Refresh() Pi:UpdateMinimap() Pi:UpdateWorldMap() Pi:CheckAlert() end)
            if not okc then bad[#bad + 1] = k .. ": " .. tostring(err):sub(1, 60) end
        end
    end
    Pi:Refresh()
    return ok and #bad == 0, string.format("Gebiete %d, Fundstellen %d, verfügbar %d", Count(Pi.areas), Count(Pi.objects), Count(Pi.avail))
        .. (#bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "Tabellen, kein Fehler"
end

IMPL.T71 = function()
    local Pl = LP.Plates
    Pl:ForUnit("target")
    Pl:UpdateAll()
    local o = Pl:OpenObjectives()
    Pl:Refresh()
    local bad = {}
    for _, k in ipairs({ "platesQuest", "platesAll" }) do
        for _, v in ipairs({ false, true }) do
            local ok, err = pcall(WithSetting, { [k] = v }, function() Pl:Refresh() Pl:UpdateAll() end)
            if not ok then bad[#bad + 1] = k .. ": " .. tostring(err):sub(1, 60) end
        end
    end
    Pl:Refresh()
    return type(o) == "table" and #bad == 0, #o .. " offene Ziele" .. (#bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "kein Fehler"
end

IMPL.T72 = function()
    local Tt = LP.Tooltips
    return WithSetting({ tooltips = true }, function()
        local u = Tt:UnitLines("player")
        -- Questgegenstand einer Quest im Log
        local item
        for qid, st in pairs(LP.Planner.inLog or {}) do
            local q = LP.QuestDB:Get(qid)
            for _, o in ipairs(q and q.obj or {}) do if o.item and not st.complete then item = o.item break end end
            if item then break end
        end
        local lines = item and Tt:ItemLines(item)
        Tt:ObjectLines("Testobjekt")
        Tt:IsProtected(6948)
        local tdp = TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and true or false
        local ok = u == nil and (item == nil or type(lines) == "table")
        return ok, string.format("Spieler %s, Questgegenstand %s, Hook über %s", S(u), item and S(lines ~= nil) or "keiner im Log",
            tdp and "TooltipDataProcessor" or "HookScript"), "nil, Zeilen"
    end)
end

IMPL.T76 = function()
    local B = LP.Backup
    local test = {
        qdb = { [999701] = { n = "LPTest1", l = 3, f = "H" }, [999702] = { n = "LPTest2", l = 4, f = "A" } },
        vendors = { ["LPTest@1411"] = { map = 1411, x = 0.5, y = 0.5, name = "LPTest", vendor = true } },
        taxi = { ["LPTestflug"] = { map = 1411, x = 0.4, y = 0.4 } },
        caves = {}, graph = { nodes = {}, edges = {} },
    }
    local savedF = {}
    for k in pairs(test) do savedF[k] = LP.db[k] end
    local okI, msg, export, ok2, msg2, ok3, sumOk
    Guard(function()
        for k, v in pairs(test) do LP.db[k] = v end
        export = B:Export()
        for _, k in ipairs({ "qdb", "vendors", "taxi", "caves" }) do LP.db[k] = {} end
        okI, msg = B:Import(export)
        sumOk = Count(LP.db.qdb) == 2 and Count(LP.db.vendors) == 1 and Count(LP.db.taxi) == 1
        ok2, msg2 = B:Import("kaputt")
        local bad = export:gsub("^(%w+):(%x)", function(f, c) return f .. ":" .. (c == "0" and "1" or "0") end)
        ok3 = B:Import(bad)
    end, function() for k, v in pairs(savedF) do LP.db[k] = v end LP.QuestDB:Invalidate() LP.QuestDB:InvalidateServices() end)
    -- SaveCopy / CheckOnLoad mit Test-Tabellen (die echten bleiben unberührt)
    local fakeDB = { qdb = { [1] = { n = "a" } }, vendors = {}, taxi = {}, caves = {}, calib = {}, graph = { nodes = {} } }
    local bigBackup = { t = 1, count = 1000000, data = {} }
    local fakeChar = { backup = bigBackup }
    WithAccEnv({ B.SaveCopy }, { LevelPilotDB = fakeDB, LevelPilotCharDB = fakeChar }, function() B:SaveCopy() end)
    local kept = fakeChar.backup == bigBackup
    local db2 = { qdb = {}, vendors = {}, taxi = {}, caves = {}, calib = {}, graph = { nodes = {} } }
    local char2 = { backup = { t = 1, count = 3, data = { qdb = { [1] = { n = "a" }, [2] = { n = "b" }, [3] = { n = "c" } }, vendors = {}, taxi = {} } } }
    local restoredBefore = B.restored
    WithAccEnv({ B.CheckOnLoad }, { LevelPilotDB = db2, LevelPilotCharDB = char2 }, function() B:CheckOnLoad() end)
    B.restored = restoredBefore
    local healed = Count(db2.qdb) == 3
    local bad = {}
    for _, fn in ipairs({ function() B:ShowExport() end, function() B:ShowImport() end, function() B:ShowText("LPTest", "LPTest", "LPTest") end,
                          function() return B:Info() end }) do
        local ok, err = pcall(fn)
        if not ok then bad[#bad + 1] = tostring(err):sub(1, 60) end
        Hide("LevelPilotBackupFrame")
    end
    local nothing = type(msg) == "string" and msg:find(L["Ergänzt: %d Quests, %d Händler, %d Flugpunkte, %d Wegstücke. Nichts wurde gelöscht."]
        :match("([^.]+)%.$") or "Nichts wurde gelöscht", 1, true) ~= nil
    local ok = okI and sumOk and nothing and ok2 == false and msg2 == L["Das ist kein LevelPilot-Sicherungstext."] and ok3 == false and kept and healed and #bad == 0
    return ok and true or false, string.format("Import %s (Anzahlen %s), kaputt %s, Prüfsumme %s, Kopie behalten %s, wiederhergestellt %s%s",
        S(okI), S(sumOk), S(ok2), S(ok3), S(kept), S(healed), #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""),
        "true (gleich), false, false, true, true"
end

IMPL.T78 = function()
    local t = L("%d Module gestartet", 3)
    local client = LP:ClientLanguage()
    local loc = GetLocale and GetLocale() or "enUS"
    local map = { deDE = "de", enUS = "en", enGB = "en", frFR = "fr", esES = "es", esMX = "mx", ptBR = "pt", itIT = "it", ruRU = "ru",
                  koKR = "ko", zhCN = "cn", zhTW = "tw" }
    LP:CanDisplay(client)
    local path = LP:FontFor(client)
    LP:FontWorks(path)
    local fixed = LP:FixText("LPTest")
    local fs = LP.UI:Text(UIParent, 11)
    LP:RegisterText(fs, "LPTest")
    LP:ApplyFont(fs, 11)
    fs:Hide()
    local ok = t:find("3", 1, true) ~= nil and (map[loc] == nil or map[loc] == client)
    return ok, "Text " .. t .. ", Client " .. S(client) .. " (" .. S(loc) .. ")", "enthält 3, Sprache passt"
end

IMPL.T80 = function()
    local skip = { ADDON_LOADED = true, PLAYER_LOGIN = true, CHAT_MSG_ADDON = true, COMBAT_LOG_EVENT_UNFILTERED = true,
                   PLAYER_LOGOUT = true }
    local args = { UNIT_QUEST_LOG_CHANGED = { "player" }, NAME_PLATE_UNIT_ADDED = { "nameplate1" }, NAME_PLATE_UNIT_REMOVED = { "nameplate1" },
                   PLAYER_ENTERING_WORLD = { false, false }, UNIT_INVENTORY_CHANGED = { "player" }, QUEST_ACCEPTED = { 0 },
                   QUEST_TURNED_IN = { 0, 0, 0 }, CHAT_MSG_LOOT = { "" }, PLAYER_XP_UPDATE = { "player" } }
    local n0 = LP.errorCount
    local onEvent = LP.eventFrame:GetScript("OnEvent")
    local evs = {}
    for ev in pairs(LP.handlers) do if not skip[ev] then evs[#evs + 1] = ev end end
    table.sort(evs)
    local mark = ActMark()
    local list = {}
    for _, ev in ipairs(evs) do
        local before = LP.errorCount
        onEvent(LP.eventFrame, ev, unpack(args[ev] or {}))
        if LP.errorCount > before then list[#list + 1] = ev end
    end
    local real = LP.Act.real
    return LP.errorCount == n0, #evs .. " Ereignisse" .. (#list > 0 and (", Fehler bei: " .. table.concat(list, ",")) or ""), "Fehlerzähler unverändert"
end

IMPL.T82 = function()
    local bad = {}
    for _, n in ipairs({ "nav", "pins" }) do
        local d = LP.drivers and LP.drivers[n]
        local fn = d and d:GetScript("OnUpdate")
        if not fn then bad[#bad + 1] = n .. ": kein Treiber"
        else
            local ok, err = pcall(fn, d, 0.1)
            if not ok then bad[#bad + 1] = n .. ": " .. tostring(err):sub(1, 60) end
        end
    end
    local map = WorldMapFrame and WorldMapFrame:IsShown()
    if map then local ok, err = pcall(LP.Pins.UpdateWorldMap, LP.Pins) if not ok then bad[#bad + 1] = "Weltkarte: " .. tostring(err) end end
    return #bad == 0, #bad == 0 and ("Navigation und Pins" .. (map and ", Weltkarte offen" or ", Weltkarte zu (Hooks nicht geprüft)")) or table.concat(bad, "; "),
        "kein Fehler"
end

------------------------------------------------------------------------
-- Virtuelle Reisen (vorab im Ablauf gestartet – Warten geht nur ausserhalb einer Prüfung, siehe TR:Journeys)
------------------------------------------------------------------------
local JOURNEY_SKIP = "virtuelle Reise nicht gelaufen (nur im Testmodus, nicht auf Level 60)"
local LONG_ONLY = "nur mit /lp testroutine reise (Reise 1–60 in beiden Modi, dauert einige Minuten)"
local function J(k) return TR.journey and TR.journey[k] end

IMPL.T83 = function()
    local r = J("short")
    if not r then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local s = r.s or {}
    local rep = tostring(r.report or "")
    local sbLine = L["Sandbox: echte Daten unverändert (OK)"]
    local ok = (s.steps or 0) > 0 and type(s.sandboxDiff) == "table" and #s.sandboxDiff == 0 and rep:find(sbLine, 1, true) ~= nil
        and r.after.char and not r.after.taxiMeta and r.after.quests
    return ok and true or false, string.format("%d Schritte, Sandbox %s, danach LP.char echt %s, Flugpunkte ohne Überlagerung %s, API.Quests Original %s",
        s.steps or 0, (type(s.sandboxDiff) == "table" and #s.sandboxDiff == 0) and "OK" or "FEHLER", S(r.after.char), S(not r.after.taxiMeta),
        S(r.after.quests)), "Schritte > 0, alles zurück"
end

IMPL.T35 = function()
    local w = J("window")
    if not w then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local ok = w.pause == L["Weiter"] and w.resume == L["Pause"] and w.watch == L["Schnell"] and w.fast == L["Zuschauen"]
        and w.afterStop and w.report
    return ok and true or false, string.format("Pause→%s→%s, Zuschauen→%s→%s, nach Stopp nur Bericht/Schliessen %s, Bericht %s",
        S(w.pause), S(w.resume), S(w.watch), S(w.fast), S(w.afterStop), S(w.report)), "Beschriftungen wechseln, danach nur Bericht"
end

IMPL.T85 = function()
    local a = J("abort")
    if not a then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local ok = a.realChar and a.realTaxi and a.restored
    return ok and true or false, string.format("während: echter Charakter %s, Flugpunkte ohne Überlagerung %s · nach Abbruch zurück %s%s",
        S(a.realChar), S(a.realTaxi), S(a.restored), a.left and (" (umgeleitet: " .. a.left .. ")") or ""), "true, true, true"
end

IMPL.T155 = function()
    local r = J("short")
    if not r then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local s = r.s or {}
    local per = (s.planMs or 0) / math.max(1, s.planN or 1)
    return per < 16, string.format("%.2f ms je Planung (%d)", per, s.planN or 0), "< 16 ms"
end

IMPL.T174 = function()
    local r = J("speed")
    if not r then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local s = r.s or {}
    -- ohne Erholt-Bonus (der verdoppelt Monster-EP und gehört nicht zur Rechnung mit dem Monsterlevel)
    local k, xp = s.wayKills or 0, (s.wayXP or 0) - (s.wayBonus or 0)
    local L0 = s.startLevel or (UnitLevel("player") or 1)
    local Lmax = s.level or (L0 + 2)
    local cap = LP.Planner:KillXP(Lmax, Lmax)
    if k == 0 then return false, string.format("keine Weg-Kills im Speedrun (Level %d–%d)", L0, Lmax), "Weg-Kills > 0" end
    local per = xp / k
    return per <= cap, string.format("%d Weg-Kills (Level %d–%d), %.1f EP je Kill ohne Erholt-Bonus (Grenze %.1f)", k, L0, Lmax, per, cap),
        "EP je Kill <= KillXP(Level, Level)"
end

IMPL.T181 = function()
    local r = J("short")
    if not r then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local head = L("Werte: Kills/Min %s · EP je Kill %s · Dungeon-Faktoren %s", "\1", "\1", "\1"):match("^([^\1]*)")
    local found = tostring(LP.Virtual.lastReport or r.report or ""):find(head, 1, true) ~= nil
    return found, "Zeile \"" .. head .. "…\" " .. (found and "vorhanden" or "fehlt"), "vorhanden"
end

local function LongCheck()
    local l = J("long")
    if not l then return false, TR.journey and TR.journey.longWhy or "lange Reise nicht beendet", "Normal und Speedrun" end
    local hn, hs = (l.normal or 0) / 3600, (l.speed or 0) / 3600
    local ok = hs < hn and hn >= 50 and hn <= 400 and hs >= 50 and hs <= 400 and l.mode == l.modeBefore and l.text ~= nil
    return ok, tostring(l.text) .. string.format(" (Modus danach %s)", S(l.mode)), "Speedrun < Normal, beide 50–400 h, Modus unverändert"
end
IMPL.T84, IMPL.T180, IMPL.T183 = LongCheck, LongCheck, LongCheck
TR.LONG = { T84 = true, T180 = true, T183 = true }

-- Reisen nacheinander laufen lassen (im Ablauf, ausserhalb jeder Prüfung). wait(cond, sek) gibt die Kontrolle ab.
function TR:Journeys(wait, long)
    local V = LP.Virtual
    self.journey = {}
    if not V or not LP:IsDev() then self.journey.why = JOURNEY_SKIP return end
    local L0 = UnitLevel("player") or 1
    if V.active then self.journey.why = "virtuelle Reise lief schon" return end
    local API, Geo = LP.API, LP.Geo
    local orig = { Quests = API.Quests, Objectives = API.Objectives, IsQuestDone = API.IsQuestDone, GeoPlayer = Geo.Player,
                   HearthReady = API.HearthReady }
    local function run(opts, during)
        local res = {}
        opts.silent = true
        opts.onDone = function(rep, s) res.report, res.s, res.done = rep, s, true end
        V:Start(opts.where or "here", opts)
        if not V.active then return nil end
        if during then pcall(during, res) end
        wait(function() return res.done or not V.active end, opts.maxSec or 240)
        if V.active then V:Stop() end
        wait(function() return res.done end, 3)
        -- nur die geprüften Werte behalten (Speicher, T157)
        local s = res.s or {}
        res.s = { steps = s.steps, sandboxDiff = s.sandboxDiff, planMs = s.planMs, planN = s.planN, wayKills = s.wayKills,
                  wayXP = s.wayXP, wayBonus = s.wayBonus, startLevel = s.startLevel, level = s.level }
        res.report = res.report and tostring(res.report):sub(1, 4000)
        res.after = { char = LP.char == LevelPilotCharDB,
                      taxiMeta = type(LP.Acc().taxi) == "table" and getmetatable(LP.Acc().taxi) ~= nil,
                      quests = API.Quests == orig.Quests }
        return res
    end
    if L0 < 60 and not self.abort then
        -- T83/T155/T181: kurze Reise über den Ticker
        self.journey.short = run({ maxLevel = math.min(60, L0 + 2) })
        -- T174: dasselbe im Speedrun
        -- unter Level 10 etwas länger: am Anfang bringen Wege selten Monster, die sich lohnen
        if not self.abort then self.journey.speed = run({ maxLevel = math.min(60, L0 + (L0 < 10 and 5 or 2)), mode = "speed" }) end
    else
        self.journey.why = L0 >= 60 and "Level 60 – keine Reise ab hier" or self.abort
    end
    -- T35: Fenster der Reise (Knöpfe; Zuschauen öffnet keine Weltkarte)
    if not self.abort and L0 < 60 then
        local w = {}
        local res = run({ maxLevel = math.min(60, L0 + 1), maxSec = 1 }, function()
            V:ShowWindow()
            local win = V.Window and V.Window()
            if not win then return end
            local click = function(b)
                local fn = b:GetScript("OnClick")
                if fn then WithEnv({ fn }, { ToggleWorldMap = false }, function() fn(b, "LeftButton") end) end
            end
            click(win.bPause) w.pause = win.bPause.label:GetText()
            click(win.bPause) w.resume = win.bPause.label:GetText()
            click(win.bWatch) w.watch = win.bWatch.label:GetText()
            click(win.bWatch) w.fast = win.bWatch.label:GetText()
            click(win.bStop)
            w.afterStop = not win.bPause:IsShown() and not win.bWatch:IsShown() and not win.bStop:IsShown()
            local rb = win.bReport
            if rb then click(rb) end
            w.report = _G.LevelPilotBackupFrame and _G.LevelPilotBackupFrame:IsShown() or false
            Hide("LevelPilotBackupFrame")
            win:Hide()
        end)
        if res then self.journey.window = w end
    end
    -- T85: Abbruch mitten in der Reise
    if not self.abort and L0 < 60 then
        local a = {}
        V:Start("here", { silent = true, maxLevel = math.min(60, L0 + 2) })
        if V.active then
            wait(function() return false end, 1)
            a.realChar = V:RealChar() == LevelPilotCharDB
            a.realTaxi = getmetatable(V:RealTaxi() or {}) == nil
            V:Abort()
            local left = {}
            if API.Quests ~= orig.Quests then left[#left + 1] = "API.Quests" end
            if API.Objectives ~= orig.Objectives then left[#left + 1] = "API.Objectives" end
            if API.IsQuestDone ~= orig.IsQuestDone then left[#left + 1] = "API.IsQuestDone" end
            if Geo.Player ~= orig.GeoPlayer then left[#left + 1] = "Geo.Player" end
            if API.HearthReady ~= orig.HearthReady then left[#left + 1] = "API.HearthReady" end
            a.restored = #left == 0 and LP.char == LevelPilotCharDB
            a.left = #left > 0 and table.concat(left, ", ") or nil
            self.journey.abort = a
        end
    end
    -- T84/T180/T183: 1–60 in beiden Modi (nur "/lp testroutine reise")
    if long and not self.abort then
        local l = { modeBefore = LP.char.mode }
        local started = V:CompareModes(function(n, s, text) l.normal, l.speed, l.text = n, s, text end, 60)
        if started then
            wait(function() return l.text ~= nil end, 3600)
            if V.active then V:Stop() end
        end
        l.mode = LP.char.mode
        if l.text then self.journey.long = l else self.journey.longWhy = "lange Reise nicht beendet" end
    end
end

------------------------------------------------------------------------
-- E. Daten (3.12.6)
------------------------------------------------------------------------
IMPL.T127 = function()
    local V = LP.Virtual
    local real = { ["LPTestflug"] = { map = 1411 } }
    local overlay = V.MakeOverlay(real)
    overlay.LPTestVirtuell = { map = 1 }
    local isReal = V.RealTaxiOf(overlay) == real
    -- SaveCopy speichert die echte Liste (Test-Tabellen, die echten bleiben unberührt)
    local fakeDB = { qdb = { [1] = { n = "a" } }, vendors = {}, taxi = overlay, caves = {}, calib = {}, graph = { nodes = {} } }
    local fakeChar = {}
    WithAccEnv({ LP.Backup.SaveCopy }, { LevelPilotDB = fakeDB, LevelPilotCharDB = fakeChar }, function() LP.Backup:SaveCopy() end)
    local savedReal = fakeDB.taxi == real
    local copy = fakeChar.backup and fakeChar.backup.data and fakeChar.backup.data.taxi
    local copyReal = type(copy) == "table" and copy.LPTestflug ~= nil and copy.LPTestVirtuell == nil
    return isReal and savedReal and copyReal, string.format("RealTaxiOf echt %s, Konto echt %s, Kopie ohne Reise-Einträge %s",
        S(isReal), S(savedReal), S(copyReal)), "true, true, true"
end

-- Beispiel-DB im Stand vor 3.8/3.10
local OLD_DB = function()
    return {
        qdb = { [999801] = { n = "Alt", l = 5, f = "H", s = { 1, 100, 100 } } },
        speedLevel = 3, calib = { kills = {} },
        protocolLog = { entries = { { k = "zone", msg = "… Das Brachland (1413), Brachland" }, { k = "session", msg = "L1 L5 3" } } },
    }, { mode = "normal" }
end

IMPL.T128 = function()
    local acc, char = OLD_DB()
    -- Calib liest die Messungen immer aus LP.Acc().calib (nicht aus der geladenen Fassung); im echten Spiel
    -- sind dort eigene Messungen -> "gemessen true". Darum ohne eigene Messungen prüfen (3.12.19).
    return WithEmptyCalib(function() return WithLoad(acc, char, function()
        local bad = {}
        for _, fn in ipairs({ function() LP.Planner:Replan(true) end, function() LP.Calib:KillXPText() end,
                              function() LP.Protocol:LoadEntries() end, function() LP.Virtual:Report() end }) do
            local ok, err = pcall(fn)
            if not ok then bad[#bad + 1] = tostring(err):sub(1, 80) end
        end
        local filled = acc.speedLevelV2 == true and type(char.levelTimes) == "table" and type(char.fpVisited) == "table"
        local measured = LP.Calib:KillXPMeasured()
        return #bad == 0 and filled and measured == false, string.format("ergänzt %s, gemessen %s%s", S(filled), S(measured),
            #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "ergänzt, false, kein Fehler"
    end) end)
end

IMPL.T129 = function()
    local acc = {
        qdb = { [123] = "kaputt", [124] = { n = 5, l = "x" } }, graph = 5, taxi = "x", vendors = { [1] = false }, caves = { 1 },
        calib = { killxp = { [-3] = { n = "a" } } }, protocolLog = { entries = { { k = nil, msg = 5 } } }, net = { peers = 7 },
    }
    local char = { ignored = "x", levelTimes = { [5] = "x" }, bind = 3 }
    return WithLoad(acc, char, function()
        local bad = {}
        local calls = {
            { "QuestDB:Counts", function() LP.QuestDB:Counts() LP.QuestDB:Get(123) LP.QuestDB:Get(124) end },
            { "Planner:Replan", function() LP.Planner:Replan(true) end },
            { "Center", function() WithCenter(function() LP.Center:Select("data") LP.Center:Select("route") end) end },
            { "Backup", function() LP.Backup:Count(acc) LP.Backup:Export() end },
            { "Protocol", function() LP.Protocol:LoadEntries() end },
            { "Calib", function() LP.Calib:KillXPRatio(-3) LP.Calib:KillXPText() end },
            { "Comm", function() LP.Comm:EncodeQuest(123) LP.Comm:EncodeQuest(124) end },
            { "Virtual", function() LP.Virtual:Fingerprint() end },
            { "Comfort", function() LP.Comfort:LevelTimesText() end },
        }
        for _, c in ipairs(calls) do
            local ok, err = pcall(c[2])
            if not ok then bad[#bad + 1] = c[1] .. ": " .. tostring(err):sub(1, 70) end
        end
        -- SaveCopy mit denselben Tabellen (ohne die echten zu berühren)
        local okS, errS = pcall(WithAccEnv, { LP.Backup.SaveCopy }, { LevelPilotDB = acc, LevelPilotCharDB = char }, function() LP.Backup:SaveCopy() end)
        if not okS then bad[#bad + 1] = "SaveCopy: " .. tostring(errS):sub(1, 70) end
        return #bad == 0, #bad == 0 and "alle Aufrufe ohne Fehler" or table.concat(bad, "; "), "kein Lua-Fehler"
    end)
end

IMPL.T130 = function()
    local Q = LP.QuestDB
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return NA, "kein Datenpaket installiert" end
    local CP = Q.ConnectPack
    if not CP then return false, "QuestDB.ConnectPack fehlt", "zugänglich" end
    local scheduled
    local function conn(data)
        return WithEnv({ CP }, { _G = { LevelPilotData = data }, C_Timer = { After = function(_, fn) scheduled = fn end } },
            function() return CP() end)
    end
    local r = {}
    return Guard(function()
        WithSetting({ usePack = true }, function()
            local ok1, i1 = conn(nil)
            r.miss = ok1 == false and i1 == L["nicht installiert"]
            local ok2, i2 = conn(setmetatable({ format = 2 }, { __index = d }))
            r.fmt = ok2 == false and i2 == L["unbekanntes Format "] .. "2"
            local warned = Q.packWarned
            Q.packWarned = false
            scheduled = nil
            local ok3 = conn(setmetatable({ version = "1.5.0" }, { __index = d }))
            r.old = ok3 == true and scheduled ~= nil
            scheduled = nil
            conn(setmetatable({ version = "1.5.0" }, { __index = d }))
            r.once = scheduled == nil
            Q.packWarned = warned
        end)
        -- Kurztest-Prüfung (T04) ohne Paket
        _G.LevelPilotData = nil
        local _, b = Guard(function() return IMPL.T04() end, function() _G.LevelPilotData = d end)
        r.short = b == "Datenpaket LevelPilot_Data fehlt"
        Q:Reconnect()
        r.back = Q.pack == true
        local ok = r.miss and r.fmt and r.old and r.once and r.short and r.back
        return ok and true or false, string.format("fehlt %s, Kurztest %s, Format 2 %s, 1.5.0 läuft mit einem Hinweis %s/%s, danach Paket %s",
            S(r.miss), S(r.short), S(r.fmt), S(r.old), S(r.once), S(r.back)), "alles true"
    end, function() _G.LevelPilotData = d pcall(Q.Reconnect, Q) end)
end
IMPL.T203 = function()
    local Q = LP.QuestDB
    return Q.OlderThan("1.5.0", Q.MIN_PACK) == true and Q.OlderThan("1.6.0", Q.MIN_PACK) == false,
        "Mindestversion " .. S(Q.MIN_PACK), "1.5.0 zu alt, 1.6.0 ok"
end

IMPL.T131 = function()
    local Q = LP.QuestDB
    local CQ = Q.ConnectQuestie
    if not CQ then return false, "QuestDB.ConnectQuestie fehlt", "zugänglich" end
    -- Ersatz nur in der Umgebung der Funktion: ein echtes Questie bleibt unberührt
    local function conn(lib) return WithEnv({ CQ }, { _G = { LibQuestieDB = lib } }, function() return CQ() end) end
    return Guard(function()
        return WithSetting({ useQuestie = true }, function()
            local ok1, i1 = conn({ RequireContract = function() return false, "LPTest" end })
            local ok2, i2 = conn({ RequireContract = function() return true end })
            local a = ok1 == false and tostring(i1):sub(1, #L["Version zu alt ("]) == L["Version zu alt ("]
            local b = ok2 == false and i2 == L["Schnittstelle unvollständig"]
            return a and b, "alt: " .. tostring(i1) .. " · ohne Tabelle: " .. tostring(i2) ..
                (_G.LibQuestieDB and " · echtes Questie geladen (nicht ersetzt)" or ""), "Version zu alt (…) · Schnittstelle unvollständig"
        end)
    end, function() pcall(Q.Reconnect, Q) end)
end

------------------------------------------------------------------------
-- F. Sprachen (3.12.6)
------------------------------------------------------------------------
local function CutLabels()
    local bad = {}
    for b in pairs(LP.UI.buttons or {}) do
        local fs = b.label
        if fs and b:IsShown() and fs.GetStringWidth and b.GetWidth then
            local tw, bw = fs:GetStringWidth() or 0, b:GetWidth() or 0
            if bw > 0 and tw > bw - 2 then bad[#bad + 1] = tostring(fs:GetText()) end
        end
    end
    return bad
end

IMPL.T136 = function()
    local before = LP.db.language
    local bad = {}
    local n = 0
    return Guard(function()
        for _, l in ipairs(LP.LANGUAGES) do
            if LP:CanDisplay(l.code) then
                n = n + 1
                local ok, err = pcall(function()
                    LP:SetLanguage(l.code)
                    if LP:Language() ~= l.code then error("Sprache " .. LP:Language(), 0) end
                    if not LP.UI:IsShown() then LP.UI:Toggle() LP.UI:Toggle() end
                    LP.UI:Refresh()
                    WithCenter(function() end)
                    LP.Backup:ShowText("LPTest", "LPTest", "LPTest") Hide("LevelPilotBackupFrame")
                    LP.Protocol:Show() Hide("LevelPilotBackupFrame")
                    if LP:IsDev() and LP.Virtual.ShowWindow then LP.Virtual:ShowWindow() Hide("LevelPilotVirtualFrame") end
                    local cut = CutLabels()
                    if #cut > 0 then error("abgeschnitten: " .. table.concat(cut, ", "):sub(1, 80), 0) end
                end)
                if not ok then bad[#bad + 1] = l.code .. ": " .. tostring(err) end
            end
        end
        return #bad == 0, n .. " Sprachen" .. (#bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "kein Fehler, nichts abgeschnitten"
    end, function()
        LP.db.language = before
        LP:ResetLanguageCache()
        pcall(LP.SetLanguage, LP, before)
        LP.db.language = before
    end)
end

IMPL.T138 = function()
    local st = LP.Names:StatusText()
    local ok = type(st) == "string" and (st:find("ok", 1, true) or st:find(L["geladen"], 1, true)
        or st == L["nicht nötig (Englisch)"]) ~= nil
    local en = LP.Names.LOCALE_OF and LP.Names.LOCALE_OF.en
    local it = LP.Names.LOCALE_OF and LP.Names.LOCALE_OF.it
    local same = en == nil or en == it
    return ok and same, st:sub(1, 80) .. (en and (" · en/it: " .. S(en) .. "/" .. S(it)) or ""), "ok/geladen, en und it englisch"
end

------------------------------------------------------------------------
-- G. Zusammenspiel (3.12.6)
------------------------------------------------------------------------
IMPL.T142 = function()
    if not geterrorhandler then return true, "kein Fehler-Handler" end
    local h = geterrorhandler()
    local msg = "Interface/AddOns/LevelPilot/Test.lua:1: LP-Testfehler Handlerkette"
    local gt0, pr0 = GTErrors("LP-Testfehler Handlerkette"), LP.Protocol:Count()
    pcall(h, msg)
    local gt1 = GTErrors("LP-Testfehler Handlerkette", true)
    local pr = DropProtocol("LP-Testfehler Handlerkette")
    local bug = _G.BugGrabber and "BugGrabber geladen (bekommt die Meldung weiter)" or "ohne BugGrabber (Teil übersprungen)"
    local ok = gt1 > gt0 and pr >= 1
    return ok, string.format("GoldSentinelTest %d, Protokoll %d · %s", gt1 - gt0, pr, bug), "beide >= 1"
end

IMPL.T144 = function()
    local Q = LP.QuestDB
    local r = {}
    if _G.LibQuestieDB or _G.QuestieLoader then
        WithSetting({ usePack = false, useQuestie = true }, function()
            Q:Reconnect()
            local c = Q:Counts()
            r.with = Q.questie == true and (c.questie or 0) > 0
        end)
        Q:Reconnect()
        return r.with and true or false, "mit Questie: aktiv " .. S(r.with), "aktiv, Quests > 0"
    end
    WithSetting({ usePack = false, useQuestie = true }, function()
        Q:Reconnect()
        r.info = tostring(Q.questieInfo or "")
    end)
    Q:Reconnect()
    local ok = r.info:find(L["nicht installiert"], 1, true) ~= nil
    return ok, "ohne Questie: " .. r.info:sub(1, 60) .. " (Teil mit Questie übersprungen)", "nicht installiert"
end

------------------------------------------------------------------------
-- H. Leistung (3.12.6)
------------------------------------------------------------------------
IMPL.T148 = function()
    local d = LP.drivers and LP.drivers.nav
    local fn = d and d:GetScript("OnUpdate")
    if not fn then return false, "Navigations-Treiber fehlt", "vorhanden" end
    local med, max = Bench(function() fn(d, 0.05) end)
    -- 3.12.24: Recalc(true) startet die Wegsuche in Portionen; gemessen wird der Start und die laengste Portion
    local Jobs = LP.Jobs
    local oldSync = Jobs.sync
    Jobs.sync = false
    local t0 = Ms()
    LP.Nav:Recalc(true)
    local full = Ms() - t0
    local slice, frames = 0, 0
    while Jobs.Running("navpath") and frames < 5000 do
        local s0 = Ms()
        Jobs.Step()
        slice = math.max(slice, Ms() - s0)
        frames = frames + 1
    end
    Jobs.sync = oldSync
    return med < 2 and full < 16 and slice < 16, string.format("Median %.2f ms, Höchstwert %.2f ms, Recalc(true) %.2f ms, Wegsuche %d Portionen, längste %.2f ms",
        med, max, full, frames, slice), "Median < 2 ms, Recalc < 16 ms, Portion < 16 ms"
end

IMPL.T149 = function()
    local d = LP.drivers and LP.drivers.pins
    local fn = d and d:GetScript("OnUpdate")
    if not fn then return false, "Pins-Treiber fehlt", "vorhanden" end
    local med, max = Bench(function() fn(d, 0.05) end)
    local wm = Bench(function() LP.Pins:UpdateWorldMap() end, 5)
    return med < 2 and wm < 16, string.format("OnUpdate Median %.2f ms (max %.2f), Weltkarte %.2f ms", med, max, wm), "< 2 ms, < 16 ms"
end

IMPL.T151 = function()
    local Geo = LP.Geo
    local i1, n1, w1 = Geo:ToWorld(1454, 0.45, 0.55)
    local i2, n2, w2 = Geo:ToWorld(1413, 0.52, 0.30)
    if not (i1 and i2) then return false, "Koordinaten fehlen", "Orgrimmar und Wegkreuz" end
    local med, max = Bench(function() LP.Graph:Path(i1, n1, w1, 1454, i2, n2, w2, 1413) end, 5)
    return med < 16, string.format("Median %.2f ms, Höchstwert %.2f ms", med, max), "< 16 ms"
end

-- Drosselung abseits des Weges (Nav.recalcCount)
local function OffPathThrottle()
    local N, Geo = LP.Nav, LP.Geo
    N:Recalc(true)
    local path = N:PathInfo()
    if not path or not path[1] or not path[2] then return NA, "kein Weg (Schritt ohne Ort) – Drosselung nicht messbar" end
    local a, b = path[1], path[2]
    local dn, dw = b[2] - a[2], b[3] - a[3]
    local len = math.sqrt(dn * dn + dw * dw)
    if len < 1 then dn, dw, len = 1, 0, 1 end
    local pn, pw = b[2] - dw / len * 100, b[3] + dn / len * 100      -- 100 Yards seitlich
    local origPlayer = Geo.Player
    local t = GetTime() + 10
    local onTaxi = false
    local fake = { GetTime = function() return t end, UnitOnTaxi = function() return onTaxi end }
    return Guard(function()
        local inst = a[1]
        Geo.Player = function() return inst, pn, pw, a[4] end
        local c0 = N.recalcCount or 0
        WithEnv({ N.Recalc }, fake, function()
            for _ = 1, 20 do t = t + 0.05 N:Recalc(false) end
        end)
        local n1 = (N.recalcCount or 0) - c0
        -- auf dem Flug nie
        onTaxi = true
        pn, pw = pn + 150, pw + 150
        t = t + 5
        local c1 = N.recalcCount or 0
        WithEnv({ N.Recalc }, fake, function()
            for _ = 1, 20 do t = t + 0.05 N:Recalc(false) end
        end)
        local n2 = (N.recalcCount or 0) - c1
        return n1 <= 2 and n2 == 0, string.format("vom Weg ab: %d Neuberechnungen in 1 s, auf dem Flug %d", n1, n2), "<= 2, 0"
    end, function() Geo.Player = origPlayer pcall(N.Recalc, N, true) end)
end
IMPL.T152 = OffPathThrottle
IMPL.T197 = OffPathThrottle

IMPL.T153 = function()
    local h = HandlerList("NAME_PLATE_UNIT_ADDED")
    local a = Bench(function() for _, fn in ipairs(h) do fn("NAME_PLATE_UNIT_ADDED", "nameplate1") end end)
    local b = Bench(function() LP.Tooltips:UnitLines("target") end)
    local c = Bench(function() LP.Calib:ObserveUnit("target") end)
    return a < 1 and b < 1 and c < 0.5, string.format("Plakette %.3f ms, Tooltip %.3f ms, Beobachtung %.3f ms", a, b, c), "< 1, < 1, < 0.5 ms"
end

IMPL.T154 = function()
    local Comm = LP.Comm
    local msg = "Q\t299901\t12\tH\t\t\tLPTestquest\t0"
    local snap = Comm:QueueSnapshot()
    local a, b
    WithQdb({}, function()
        a = Bench(function() Comm:Receive(msg, "LPTest-Realm") end)
    end)
    return Guard(function()
        b = Bench(function() Comm:SendNext() end)
        return a < 1 and b < 0.5, string.format("Empfang %.3f ms, Senden %.3f ms", a, b), "< 1 ms, < 0.5 ms"
    end, function() Comm:QueueRestore(snap) end)
end

IMPL.T156 = function()
    local names = { ui = true, caves = true, recorder = true, session = true }
    local fns = {}
    for _, t in ipairs(LP.tickers or {}) do if names[t.name] then fns[#fns + 1] = t.fn end end
    if #fns == 0 then return false, "Ticker nicht gefunden", "ui, caves, recorder, session" end
    local med, max = Bench(function() for _, fn in ipairs(fns) do fn() end end)
    return med < 3, string.format("%d Ticker, Summe Median %.2f ms, Höchstwert %.2f ms", #fns, med, max), "Summe < 3 ms"
end

------------------------------------------------------------------------
-- I. Fehlerzählung (3.12.6)
------------------------------------------------------------------------
IMPL.T159 = function()
    if not geterrorhandler then return true, "kein Fehler-Handler" end
    local msg = "Interface/AddOns/LevelPilot/Test.lua:1: LP-Testfehler"
    local gt0 = GTErrors("LP-Testfehler")
    pcall(geterrorhandler(), msg)
    local gt = GTErrors("LP-Testfehler", true) - gt0
    local pr = DropProtocol("LP-Testfehler")
    return gt >= 1 and pr >= 1, string.format("GoldSentinelTest %d, Protokoll %d", gt, pr), "beide >= 1"
end

IMPL.T162 = function()
    LP.initErrors = LP.initErrors or {}
    LP.initErrors.LPTestModul = "LP-Testfehler Start"
    return Guard(function()
        local a = IMPL.T01()
        local diag = table.concat(LP.Planner:DiagLines(), "\n")
        local b = diag:find("LPTestModul", 1, true) ~= nil
        return a == false and b, "T01 meldet FEHLER " .. S(a == false) .. ", Diagnose zeigt ihn " .. S(b), "true, true"
    end, function() LP.initErrors.LPTestModul = nil end)
end

IMPL.T164 = function()
    local V = LP.Virtual
    if not V.Note then return false, "Virtual.Note fehlt", "zugänglich" end
    if V.active then return NA, "Reise läuft – nicht geprüft" end
    local savedS = V.s
    V.s = { problems = {}, seen = {}, level = 1, protoErrors = 0 }
    local gt0 = GTErrors("Reise")
    local pr0 = LP.Protocol:Count(true)
    return Guard(function()
        for i = 1, 6 do V.Note("error", "LP-Testfehler Reise " .. i) end
        local gt = GTErrors("Reise", true) - gt0
        local pr = DropProtocol("LP-Testfehler Reise")
        local tracking = LP.trackingErrors
        local ok = pr == 5 and (gt == 5 or not tracking)
        return ok, string.format("Protokoll %d, GoldSentinelTest %d (je Reise höchstens 5)", pr, gt), "5, 5"
    end, function() V.s = savedS end)
end

------------------------------------------------------------------------
-- J. 3.12.7: Route in Mulgore (Befund aus dem Spiel) und CheckNav
------------------------------------------------------------------------
-- Schritt an einem Kartenpunkt (Mulgore 1412, Koordinaten von WoW Forever)
local function MulgoreStep(t, id, x, y, key)
    local i, n, w = LP.Geo:ToWorld(1412, x, y)
    return { t = t, id = id, map = 1412, x = x, y = y, inst = i, n = n, w = w, key = key or (t .. ":" .. tostring(id)) }
end

IMPL.T214 = function()
    local P = LP.Planner
    local fake = { inLog = { [780] = { complete = true }, [757] = { complete = true }, [3376] = { complete = true },
                             [761] = { complete = true }, [756] = { complete = true }, [772] = { complete = false } } }
    -- Fall 1: Spieler Red Cloud Mesa 54.1/83.9, drei Abgaben in Camp Narache, weites Ziel bei 62/58
    local pi, pn, pw = LP.Geo:ToWorld(1412, 54.1, 83.9)
    if not pi then return NA, "Mulgore-Karte nicht verfügbar" end
    local steps1 = { MulgoreStep("FP", nil, 62, 58, "FP:LPTest"), MulgoreStep("ACCEPT", 753, 48.8, 80.9),
                     MulgoreStep("TURNIN", 3376, 44.2, 77.0), MulgoreStep("TURNIN", 780, 44.5, 77.5),
                     MulgoreStep("TURNIN", 757, 43.9, 76.7) }
    P.NearTurninsFirst(fake, steps1, pi, pn, pw)
    local f1 = steps1[1].t == "TURNIN" and steps1[2].t == "TURNIN" and steps1[3].t == "TURNIN" and steps1[4].key == "FP:LPTest"
    -- Fall 2: Spieler 39.3/46.2, zwei Abgaben in Bloodhoof (südöstlich), offene Quest und weites Ziel im Nordwesten
    local qi, qn, qw = LP.Geo:ToWorld(1412, 39.3, 46.2)
    local steps2 = { MulgoreStep("COMPLETE", 745, 30, 32), MulgoreStep("COMPLETE", 772, 46.5, 61.0),
                     MulgoreStep("TURNIN", 761, 47.6, 60.6), MulgoreStep("TURNIN", 756, 46.7, 60.2) }
    P.NearTurninsFirst(fake, steps2, qi, qn, qw)
    local f2 = steps2[1].t == "TURNIN" and steps2[2].t == "TURNIN" and steps2[3].id == 745
    -- weit entfernte Abgabe (> NEAR_TURNIN) bleibt, wo die Planung sie hingestellt hat
    local steps3 = { MulgoreStep("ACCEPT", 753, 48.8, 80.9), MulgoreStep("TURNIN", 761, 20, 15) }
    P.NearTurninsFirst(fake, steps3, pi, pn, pw)
    local f3 = steps3[1].t == "ACCEPT"
    return f1 and f2 and f3, string.format("Fall 1 Abgaben vorn %s, Fall 2 Abgaben vorn %s, weite Abgabe unverändert %s (Nähe %d Yards)",
        S(f1), S(f2), S(f3), P.NEAR_TURNIN), "true, true, true"
end

-- unbekannte Zelle (kein begehbarer Boden in der Umgebung) auf einer Karte suchen
local function UnknownSpot(map, block)
    local Tr = LP.Terrain
    for y = 5, 95, 2 do
        for x = 5, 95, 2 do
            local all = true
            for dy = -(block or 0), block or 0 do
                for dx = -(block or 0), block or 0 do
                    if Tr:Walkable(map, x + dx, y + dy) ~= false then all = false break end
                end
                if not all then break end
            end
            if all then return x, y end
        end
    end
    return nil
end

IMPL.T215 = function()
    local Q, Tr = LP.QuestDB, LP.Terrain
    -- a) aufgezeichnete Abgabe weit neben dem Datenpaket wird nicht bevorzugt, eine passende schon
    local function base() return { ends = { { 1412, 46.2, 63.3, "Kauth" } }, starts = {}, objectives = {} } end
    local far = Q.Merge(base(), { starts = {}, ends = { { 1412, 62, 58 } }, objectives = {} })
    local near = Q.Merge(base(), { starts = {}, ends = { { 1412, 46.4, 63.0 } }, objectives = {} })
    local a = far.ends[1][2] == 46.2 and near.ends[1][2] == 46.4
    if Tr:Walkable(1412, 46.2, 63.3) == nil then
        return a, "Merge " .. S(a) .. " · ohne Geländekarte (kein Datenpaket): Gebirgsprüfung nicht möglich", "Merge true"
    end
    -- b) Händler/Gastwirt im Gebirge (Aufzeichnung ohne begehbaren Boden) wird nicht angeboten
    local x, y = UnknownSpot(1412, 1)
    local key = "LPTestGebirge@1412"
    local saved = LP.db.vendors[key]
    local b, c = false, false
    Guard(function()
        if x then
            LP.db.vendors[key] = { map = 1412, x = x, y = y, name = "LPTestGebirge", inn = true, vendor = true }
            Q:InvalidateServices()
            b = true
            for _, v in ipairs(Q:ServiceNPCs().inn or {}) do if v.name == "LPTestGebirge" then b = false end end
        end
    end, function() LP.db.vendors[key] = saved Q:InvalidateServices() end)
    -- c) Luftlinie quer über unbekanntes Gelände: keine Linie (nur Pfeil)
    local bx, by = UnknownSpot(1412, 4)
    if bx then
        local i1, n1, w1 = LP.Geo:ToWorld(1412, bx - 4, by - 4)
        local i2, n2, w2 = LP.Geo:ToWorld(1412, bx + 4, by + 4)
        c = LP.Nav.Blocked({ { i1, n1, w1, 1412 }, { i2, n2, w2, 1412 } }) == true
    end
    local walk = Tr:Walkable(1412, 46.2, 63.3) == true            -- Bloodhoof (Datenpaket): begehbar
    local ok = a and walk and (b or not x) and (c or not bx)
    return ok, string.format("Merge %s, Bloodhoof begehbar %s, Gastwirt im Gebirge ausgeblendet %s, Linie über Gebirge unterdrückt %s",
        S(a), S(walk), x and S(b) or "keine Gebirgszelle", bx and S(c) or "kein grosses Gebirge"), "alles true"
end

IMPL.T216 = function()
    local Pr, N = LP.Protocol, LP.Nav
    local pi, pn, pw = LP.Geo:Player()
    if not pi then return true, "keine Position" end
    local bm, bs = "LPTestKoeder Bewegung", "LPTestKoeder Tempo"
    local savedT = N.target
    N.target = { key = "LPTestNav", inst = pi, n = pn + 500, w = pw, label = "LPTest" }
    return Guard(function()
        return WithSecret({ bm, bs }, function()
            return WithEnv({ Pr.CheckNav }, { IsPlayerMoving = function() return bm end, GetUnitSpeed = function() return bs end,
                UnitAffectingCombat = function() return false end }, function()
                local ok, err = pcall(Pr.CheckNav, Pr)
                return ok, ok and "kein Fehler, Vergleich übersprungen" or tostring(err), "kein Lua-Fehler"
            end)
        end)
    end, function() N.target = savedT end)
end

IMPL.T217 = function()
    local P, Pr, Geo = LP.Planner, LP.Protocol, LP.Geo
    local pi, pn, pw = Geo:ToWorld(1456, 45, 55)
    if not pi then return true, "Karte Thunder Bluff nicht verfügbar" end
    -- 3 Aufgaben in Thunder Bluff, 6 in Mulgore
    local tasks = {}
    for k = 1, 3 do local t = MulgoreStep("ACCEPT", 299700 + k, 50, 50) t.map = 1456 t.inst, t.n, t.w = Geo:ToWorld(1456, 40 + k * 4, 50) t.value = 1 tasks[#tasks + 1] = t end
    for k = 1, 6 do local t = MulgoreStep("COMPLETE", 299710 + k, 40 + k, 60) t.value = 1 tasks[#tasks + 1] = t end
    local savedFocus, savedZone, savedTasks = P.focus, LP.char.focusZone, P.lastTasks
    local savedPlayer = Geo.Player
    return Guard(function()
        LP.char.focusZone = nil
        P.focus = nil
        local f1 = P:ChooseFocus(tasks, pi, pn, pw, 1456, {})
        P.focus = 1412
        local f2 = P:ChooseFocus(tasks, pi, pn, pw, 1456, {})
        local same = P.ZoneOf(1456) == 1412 and f1 == 1412 and f2 == 1412
        -- Fokus-Wächter: Spieler in Thunder Bluff, Fokus Mulgore -> kein Eintrag
        P.lastTasks = tasks
        Geo.Player = function() return pi, pn, pw, 1456, 45, 55 end
        local n0 = Pr:Count(true)
        WithEnv({ Pr.CheckFocus }, { GetTime = function() return 1e9 end, UnitOnTaxi = function() return false end }, function() Pr:CheckFocus() end)
        local logged = Pr:Count(true) - n0
        -- Vorrang-Ziel (Klassentrainer in Thunder Bluff) nicht vor nahe Abgaben
        local steps = { { t = "TURNIN", nearTurnin = true, key = "TURNIN:1" }, { t = "TURNIN", nearTurnin = true, key = "TURNIN:2" },
                        { t = "ACCEPT", key = "ACCEPT:3" } }
        P.InsertPriority(steps, { t = "GOTO", key = "PRIO:TRAIN:8" })
        local prioOk = steps[3].key == "PRIO:TRAIN:8" and steps[1].t == "TURNIN"
        local ok = same and logged == 0 and prioOk
        return ok, string.format("Fokus aus Thunder Bluff %s/%s, Wächter-Einträge %d, Vorrang-Ziel an Stelle %s", S(f1), S(f2), logged,
            prioOk and "3 (nach den Abgaben)" or "falsch"), "1412/1412, 0, nach den Abgaben"
    end, function()
        P.focus, LP.char.focusZone, P.lastTasks = savedFocus, savedZone, savedTasks
        Geo.Player = savedPlayer
    end)
end

IMPL.T218 = function()
    local N, Geo = LP.Nav, LP.Geo
    local function P(x, y, via, map) local i, n, w = Geo:ToWorld(map or 1412, x, y) return { i, n, w, map or 1412, via = via } end
    if not Geo:ToWorld(1412, 50, 50) then return true, "Mulgore-Karte nicht verfügbar" end
    -- a) Mulgore Fall 1: Red Cloud Mesa -> 62/58 nur als Luftlinie (kein gelaufener Weg) -> keine Linie
    local a = N.Known({ P(54.1, 83.9), P(50, 35, "v"), P(62, 58, "v") }) == false
    -- Mulgore Fall 2: 39.3/46.2 -> Schleife 30/32 als Luftlinie -> keine Linie
    local b = N.Known({ P(39.3, 46.2), P(30, 32, "v") }) == false
    -- b) bekannter Weg: kurzes erstes Stück, gelaufene Kanten, kurzes letztes Stück -> Linie
    local p1 = P(46.0, 63.0)
    local p2 = { p1[1], p1[2] + 20, p1[3], 1412 }
    local p3 = { p1[1], p1[2] + 300, p1[3] + 50, 1412, via = "s" }
    local p4 = { p1[1], p1[2] + 600, p1[3] + 80, 1412, via = "r" }
    local p5 = { p1[1], p1[2] + 630, p1[3] + 80, 1412, via = "v" }
    local c = N.Known({ p1, p2, p3, p4, p5 }) == true
    -- Ziel ohne Netzanschluss: letztes Stück 200 Yards Luftlinie -> keine Linie
    local p6 = { p1[1], p1[2] + 800, p1[3] + 80, 1412, via = "v" }
    local d = N.Known({ p1, p2, p3, p4, p6 }) == false
    -- c) Thunder Bluff mit Aufzug: ohne gelaufene Aufzugskante bleibt der Weg unbekannt, mit Kante bekannt
    local t1 = P(30, 30, nil, 1456)
    local up = { t1[1], t1[2] + 25, t1[3], 1456, via = "v" }
    local lift = { t1[1], t1[2] + 25, t1[3] + 5, 1456, via = "s" }
    local trainer = { t1[1], t1[2] + 60, t1[3] + 5, 1456, via = "v" }
    local e = t1[1] and N.Known({ t1, up, { t1[1], t1[2] + 200, t1[3], 1456, via = "v" } }) == false
    local f = t1[1] and N.Known({ t1, up, lift, trainer }) == true
    local ok = a and b and c and d and (not t1[1] or (e and f))
    return ok, string.format("Mulgore 1 %s, Mulgore 2 %s, bekannter Weg %s, Ziel ohne Netz %s, Aufzug ohne/mit Kante %s/%s",
        S(a), S(b), S(c), S(d), S(e), S(f)), "alles true"
end

IMPL.T219 = function()
    local N, Geo, Gr = LP.Nav, LP.Geo, LP.Graph
    local pi, pn, pw = Geo:Player()
    if not pi then return true, "keine Position" end
    local tgt = { key = "LPTestFest", inst = pi, n = pn + 500, w = pw, label = "LPTest" }
    local savedT, savedP, savedKey = N.target, Geo.Player, N.stuckKey
    local cn, cw = pn, pw
    local px, py = cn, cw
    local afk = false
    local fake = { UnitIsAFK = function() return afk end, UnitIsDeadOrGhost = function() return false end,
                   UnitOnTaxi = function() return false end }
    -- Szenario: Liste { Sekunden, Art } mit Art "steh", "kreis"; AFK-Schalter je Szenario
    local function run(plan, isAfk)
        N.ResetStuck()
        afk = isAfk and true or false
        local now, ang = 1000, 0
        px, py = cn + 30, cw                                   -- Kreis um (cn, cw), Start am zielnächsten Punkt
        return WithCounter(N, "OnStuck", function(fired)
            WithEnv({ N.StuckTick, N.Excluded }, fake, function()
                for _, part in ipairs(plan) do
                    for _ = 1, part[1] do
                        now = now + 1
                        if part[2] == "kreis" then
                            ang = ang + 0.25
                            px, py = cn + 30 * math.cos(ang), cw + 30 * math.sin(ang)
                        end
                        N:StuckTick(now)
                    end
                end
            end)
            return fired()
        end)
    end
    return Guard(function()
        N.target = tgt
        Geo.Player = function() return pi, px, py, nil end
        local a = run({ { 600, "kreis" } }, true)                          -- 10 min AFK (auch wenn sich etwas bewegt)
        local a2 = run({ { 600, "steh" } }, false)                         -- 10 min stehen
        local b = run({ { 120, "steh" }, { 60, "kreis" } }, false)          -- 2 min stehen, dann 1 min laufen
        local c = run({ { 250, "kreis" } }, false)                         -- 4 min im Kreis ohne Annäherung
        -- Kante sperren: die Wegsuche nimmt sie nicht mehr
        local i1 = Gr:AddNode(pi, pn + 3000, pw + 3000)
        local i2 = Gr:AddNode(pi, pn + 3100, pw + 3000)
        Gr:AddEdge(i1, i2, "s")
        local before = Gr:IsBlocked(i1, i2)
        Gr:Block(i1, i2, "FEST")
        local after = Gr:IsBlocked(i1, i2)
        local p = Gr:PathRaw(pi, pn + 3000, pw + 3000, nil, pi, pn + 3100, pw + 3000, nil)
        local usesEdge = false
        for _, q in ipairs(p or {}) do if q.via == "s" then usesEdge = true end end
        Gr:Unblock(i1, i2)
        local ok = a == 0 and a2 == 0 and b == 0 and c == 1 and not before and after and not usesEdge
        return ok, string.format("10 min AFK %d, 10 min stehen %d, 2+1 min %d, 4 min Kreis %d (FEST), Kante gesperrt %s, danach gemieden %s",
            a, a2, b, c, S(after), S(not usesEdge)), "0, 0, 0, 1, true, true"
    end, function()
        N.target, Geo.Player, N.stuckKey = savedT, savedP, savedKey
        N.ResetStuck()
    end)
end

IMPL.T220 = function()
    local R, Q, Geo = LP.Recorder, LP.QuestDB, LP.Geo
    local N = _G.LevelPilotData and _G.LevelPilotData.N
    local npc = 6747                                    -- Gastwirt Kauth (Bloodhoof), Abgabe von „Eine unvollendete Aufgabe“
    if type(N) ~= "table" or not N[npc] then return true, "kein Datenpaket" end
    -- 3.12.30 (Offline-Routine TU9): Quest 1656 gibt es nur für die Horde – auf der Allianz meldete der Test fälschlich FEHLER
    if LP:PlayerFaction() ~= "Horde" then return NA, "Hordequest 1656 – auf der Allianz nicht prüfbar" end
    local pi = Geo:ToWorld(1412, 47.0, 61.0)
    if not pi then return true, "Mulgore-Karte nicht verfügbar" end
    LP.db.npcPos = type(LP.db.npcPos) == "table" and LP.db.npcPos or {}
    local saved = LP.db.npcPos[npc]
    local savedPlayer = Geo.Player
    return Guard(function()
        LP.db.npcPos[npc] = nil
        Geo.Player = function() local i, n, w = Geo:ToWorld(1412, 47.0, 61.0) return i, n, w, 1412, 47.0, 61.0 end
        WithEnv({ R.RecordNpc }, { UnitGUID = function() return "Creature-0-1-1-1-" .. npc .. "-0000ABCD99" end }, function() R:RecordNpc() end)
        local rec = LP.db.npcPos[npc]
        Q:Invalidate()
        local q = Q:Get(1656)
        local e = q and q.ends and q.ends[1]
        local used = e and e[1] == 1412 and math.abs(e[2] - 47.0) < 0.01 and math.abs(e[3] - 61.0) < 0.01
        -- geschützte GUID: nichts gemerkt
        LP.db.npcPos[npc] = nil
        local bait = "LPTestKoeder GUID"
        WithSecret({ bait }, function()
            WithEnv({ R.RecordNpc }, { UnitGUID = function() return bait end }, function() R:RecordNpc() end)
        end)
        local none = LP.db.npcPos[npc] == nil
        local ok = rec ~= nil and used and none
        return ok and true or false, string.format("gemerkt %s (Datenpaket %s), Abgabeziel aus dem echten Ort %s, geschützt nichts %s",
            S(rec ~= nil), rec and rec.o and string.format("%.1f/%.1f", rec.o[2], rec.o[3]) or "-", S(used), S(none)), "true, true, true"
    end, function()
        LP.db.npcPos[npc] = saved
        Geo.Player = savedPlayer
        Q:Invalidate()
    end)
end

IMPL.T221 = function()
    local Gr, Geo = LP.Graph, LP.Geo
    local pi, pn, pw, map = Geo:Player()
    if not pi or not map then return NA, "keine Position" end
    -- zwei gelaufene Wegstücke in der aktuellen Zone (Sandbox stellt die Daten zurück)
    local a = Gr:AddNode(pi, pn + 2000, pw + 2000, map)
    local b = Gr:AddNode(pi, pn + 2050, pw + 2000, map)
    local c = Gr:AddNode(pi, pn + 2100, pw + 2010, map)
    Gr:AddEdge(a, b, "r") Gr:AddEdge(b, c, "r")
    local text, edges = Gr:WegeText(tostring(map))
    local f = _G.LevelPilotBackupFrame
    Gr:ShowWege(tostring(map))
    local shown = f and _G.LevelPilotBackupFrame:IsShown() or (_G.LevelPilotBackupFrame and _G.LevelPilotBackupFrame:IsShown()) or false
    Hide("LevelPilotBackupFrame")
    local savedList, savedSent = LevelPilotDB.wegeExport, LP.db.wegeSent
    return Guard(function()
        LevelPilotDB.wegeExport, LP.db.wegeSent = {}, {}
        local ok1 = WithSetting({ wegeAuto = true }, function() return Gr:WegeExport() end)
        local s1 = LevelPilotDB.wegeExport[1] or ""
        local ok2 = WithSetting({ wegeAuto = true }, function() return Gr:WegeExport() end)   -- nichts Neues
        local n2 = #LevelPilotDB.wegeExport
        LP.db.wegeSent = {}
        local off = WithSetting({ wegeAuto = false }, function() return Gr:WegeExport() end)
        local me = UnitName("player")
        local guild = GetGuildInfo and GetGuildInfo("player")
        local leak = (type(me) == "string" and me ~= "" and (s1:find(me, 1, true) or text:find(me, 1, true)))
            or (type(guild) == "string" and guild ~= "" and (s1:find(guild, 1, true) or text:find(guild, 1, true)))
        local ok = edges >= 1 and shown and ok1 == true and s1:sub(1, 7) == "GSWEGE1" and #s1 <= Gr.WEGE_MAX and not ok2 and n2 == 1
            and not off and not leak
        return ok and true or false, string.format("Text %d Wege (Fenster %s), GSWEGE1 %s (%d Zeichen), zweiter Versand ohne Neues %s, aus %s, Namen %s",
            edges, S(shown), S(ok1), #s1, S(not ok2), S(not off), leak and "GEFUNDEN" or "keine"), "Wege, Fenster, GSWEGE1, nur Neues, abschaltbar, keine Namen"
    end, function() LevelPilotDB.wegeExport, LP.db.wegeSent = savedList, savedSent end)
end

IMPL.T222 = function()
    local P, Geo = LP.Planner, LP.Geo
    local pi, pn, pw = Geo:ToWorld(1412, 38.3, 37.6)
    if not pi then return NA, "Mulgore-Karte nicht verfügbar" end
    local function task(t, id, map, x, y, value)
        local i, n, w = Geo:ToWorld(map, x, y)
        return { t = t, id = id, map = map, x = x, y = y, inst = i, n = n, w = w, value = value, key = t .. ":" .. id }
    end
    -- 3 offene Quests in Mulgore (wenig wert), im Brachland 3 Abgaben und viele neue Quests (viel wert)
    local tasks = { task("COMPLETE", 745, 1412, 33, 30, 0.3), task("COMPLETE", 776, 1412, 52, 40, 0.3),
                    task("COMPLETE", 758, 1412, 47, 22, 0.3) }
    local barrens = {}
    for k = 1, 3 do barrens[#barrens + 1] = task("TURNIN", 299800 + k, 1413, 52, 30, 3) end
    for k = 1, 6 do barrens[#barrens + 1] = task("ACCEPT", 299810 + k, 1413, 52, 30, 3) end
    for _, t in ipairs(barrens) do tasks[#tasks + 1] = t end
    local savedFocus, savedZone = P.focus, LP.char.focusZone
    return Guard(function()
        LP.char.focusZone = nil
        P.focus = nil
        local a = P:ChooseFocus(tasks, pi, pn, pw, 1412, {})
        P.focus = 1413
        local b = P:ChooseFocus(tasks, pi, pn, pw, 1412, {})
        -- aus Thunder Bluff (gehört zu Mulgore) ebenso
        local c = P:ChooseFocus(tasks, pi, pn, pw, 1456, {})
        -- Mulgore fertig: dann gesammelt ins Brachland
        P.focus = 1412
        local d = P:ChooseFocus(barrens, pi, pn, pw, 1412, {})
        local ok = a == 1412 and b == 1412 and c == 1412 and d == 1413
        return ok, string.format("Fokus ohne/mit altem Fokus %s/%s, aus Thunder Bluff %s, Mulgore fertig %s", S(a), S(b), S(c), S(d)),
            "1412/1412, 1412, 1413"
    end, function() P.focus, LP.char.focusZone = savedFocus, savedZone end)
end

------------------------------------------------------------------------
-- 3.12.17: Wegdaten (Auswertung testberichte/wege/auswertung.md)
------------------------------------------------------------------------
-- Testpunkte in Mulgore, Rand der Karte (Sandbox stellt das Wegnetz zurück); Weltkoordinaten in Yards
local function WegBase()
    local i, n, w = LP.Geo:ToWorld(1412, 8, 92)
    return i, n, w
end
local function Connected(a, b)
    local Gr, seen, queue = LP.Graph, { [a] = true }, { a }
    while #queue > 0 do
        local id = table.remove(queue, 1)
        if id == b then return true end
        for v in pairs(Gr:Neighbors(id) or {}) do
            if not seen[v] and v > 0 then seen[v] = true queue[#queue + 1] = v end
        end
    end
    return false
end

IMPL.T235 = function()
    local Gr = LP.Graph
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    local function P(dn, dw) return { i, n + dn, w + dw, 1412 } end
    -- Weg A: 0 -> 50 -> 100 Yards (Kanten 50 Yards lang)
    Gr:AddPolyline({ P(0, 0), P(50, 0), P(100, 0) }, "r")
    local a0 = Gr:Nearest(i, n, w, 2, 1412)
    local a2 = Gr:Nearest(i, n + 100, w, 2, 1412)
    -- Weg B beginnt 6 Yards neben der Mitte der ersten Kante
    Gr:AddPolyline({ P(25, 6), P(25, 46) }, "r")
    local bEnd = Gr:Nearest(i, n + 25, w + 46, 2, 1412)
    -- Weg C kreuzt die zweite Kante (Punkt 4 Yards daneben)
    Gr:AddPolyline({ P(75, -30), P(75, -4), P(75, 22) }, "r")
    local cEnd = Gr:Nearest(i, n + 75, w + 22, 2, 1412)
    -- Weg D beginnt 15 Yards daneben: bleibt getrennt
    Gr:AddPolyline({ P(40, -15), P(40, -55) }, "r")
    local dEnd = Gr:Nearest(i, n + 40, w - 55, 2, 1412)
    local ab, ac, ad, ok2 = Connected(a0, bEnd), Connected(a0, cEnd), Connected(a0, dEnd), Connected(a0, a2)
    return ab and ac and not ad and ok2,
        string.format("Anfang an Kante %s, Kreuzung %s, 15 Yards daneben %s, Weg A ganz %s", S(ab), S(ac), S(ad), S(ok2)),
        "true, true, false, true"
end

IMPL.T236 = function()
    local R = LP.Recorder
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    -- gerade 240 Yards, dann rechtwinklig 120 Yards; Punkte alle 12 Yards
    local pts = {}
    for k = 0, 20 do pts[#pts + 1] = { i, n + k * 12, w, 1412, k } end
    for k = 1, 10 do pts[#pts + 1] = { i, n + 240, w + k * 12, 1412, 20 + k } end
    local kp = R.KeyPoints(pts)
    local maxGap, corner = 0, false
    for k = 2, #kp do
        local d = math.sqrt((kp[k][2] - kp[k - 1][2]) ^ 2 + (kp[k][3] - kp[k - 1][3]) ^ 2)
        maxGap = math.max(maxGap, d)
    end
    for _, p in ipairs(kp) do if p[2] == n + 240 and p[3] == w then corner = true end end
    return maxGap <= R.SEG_MAX and corner and #kp < #pts,
        string.format("%d von %d Punkten, grösster Abstand %.1f Yards, Ecke %s", #kp, #pts, maxGap, S(corner)),
        "weniger Punkte, <= 25 Yards, Ecke true"
end

IMPL.T237 = function()
    local R, Gr, Geo = LP.Recorder, LP.Graph, LP.Geo
    local ci, cn, cw = Geo:ToWorld(1414, 50, 50)
    if not ci or Geo:ContinentOf(1414) ~= 1414 then return NA, "Kontinentkarte Kalimdor nicht verfügbar" end
    local origPlayer, origVirt = Geo.Player, LP.Virtual.active
    local k = 0
    Geo.Player = function() k = k + 1 return ci, cn + k * 30, cw, 1414, 50, 50 + k * 0.1 end
    return Guard(function()
        LP.Virtual.active = false
        local recorded = 0
        WithSetting({ recordPaths = true }, function()
            for _ = 1, 4 do R:SamplePath() recorded = math.max(recorded, R:TrailCount()) end
        end)
        -- alte Kontinent-Kante in den Daten: nicht in den Wegdaten
        local a = Gr:AddNode(ci, cn - 500, cw - 500, 1414)
        local b = Gr:AddNode(ci, cn - 450, cw - 500, 1414)
        Gr:AddEdge(a, b, "r")
        local d = Gr:WegeData(nil, function(m) return m == 1414 end)
        return recorded == 0 and #d.zones == 0,
            string.format("aufgezeichnete Punkte %d, Wegdaten Kalimdor %d Zonen", recorded, #d.zones), "0, 0"
    end, function() Geo.Player, LP.Virtual.active = origPlayer, origVirt R:FlushTrail(true) end)
end

IMPL.T238 = function()
    local Gr, R = LP.Graph, LP.Recorder
    local d = LevelPilotData and LevelPilotData.N
    if type(d) ~= "table" or type(d[15350]) ~= "table" then return NA, "kein Datenpaket" end
    local saved = LP.db.npcPos
    return Guard(function()
        LP.db.npcPos = {
            [15350] = { 1456, 58.0, 76.7, t = 100, c = 1, o = { 1413, 46.7, 8.7 } },  -- alter Eintrag: erster Fundort
            [299901] = { 1412, 40, 40, t = 100, c = 1 },                               -- nicht im Datenpaket
        }
        local data = Gr:WegeData(nil)
        local byId = {}
        for _, e in ipairs(data.npc) do byId[e.id] = e end
        local w, x = byId[15350], byId[299901]
        local spawn = R.PackSpawn(15350, { 1456, 58.0, 76.7 })
        local ok = w and type(w.old) == "table" and #w.old == 2 and #w.new == 2 and w.oldMap == nil
            and math.abs(w.old[1] - 57.8) < 0.05 and math.abs(w.old[2] - 76.4) < 0.05
            and x and x.old == nil and x.nopack == true and spawn and spawn[1] == 1456
        return ok and true or false,
            string.format("15350 alt %s (Karte %s), 299901 nopack %s", w and w.old and (w.old[1] .. "," .. w.old[2]) or "?",
                S(w and w.oldMap or "gleich"), S(x and x.nopack)),
            "15350 alt 57.8,76.4 (Karte gleich), nopack true"
    end, function() LP.db.npcPos = saved end)
end

IMPL.T239 = function()
    local d = LevelPilotData and LevelPilotData.N
    if type(d) ~= "table" or not d[10666] then return NA, "kein Datenpaket" end
    local function near(id, map, x, y)
        local sp = LP.Recorder.PackSpawn(id, { map, x, y })
        return sp and sp[1] == map and math.abs(sp[2] - x) < 0.6 and math.abs(sp[3] - y) < 0.6 or false
    end
    -- 3.12.55 LW-5 E2: im Classic-Era-Client gelten fuer 10666/10881 die Questie-Orte (die Forever-Messung gilt nur Forever)
    local era = LP.Geo.EraFrame and LP.Geo.EraFrame() and LevelPilotData.eraFrame
    local a = era and near(10666, 1420, 43.1, 54.7) or (not era and near(10666, 1420, 52.8, 54.2))
    local b = era and near(10881, 1456, 44.3, 58.8) or (not era and near(10881, 1456, 56.6, 48.1))
    local c = near(15350, 1456, 58.0, 76.7)
    return a and b and c, string.format("10666 %s, 10881 %s, 15350 %s (Datenpaket %s, %s)", S(a), S(b), S(c), S(LevelPilotData.version), era and "Era-Orte" or "Forever-Orte"),
        "true, true, true"
end

------------------------------------------------------------------------
-- 3.12.18: eigene Tooltips neben dem Fenster
------------------------------------------------------------------------
IMPL.T240 = function()
    local UI = LP.UI
    -- reine Rechnung: Fenster 300 breit, Bildschirm 1920
    local s1, d1 = UI.TipSide(800, 1100, 700, 300, 650, 1920, 280)     -- Mitte -> rechts, 50 tiefer
    local s2 = UI.TipSide(1620, 1920, 700, 300, 650, 1920, 280)         -- rechter Rand -> links
    local s3 = UI.TipSide(100, 1850, 700, 300, 650, 1920, 280)          -- fast so breit wie der Bildschirm -> darunter
    local pure = s1 == "RIGHT" and d1 == -50 and s2 == "LEFT" and s3 == "BELOW"
    -- echter Knopf im Leitfenster mit eigenem Test-Tooltip (zeichnet nur auf)
    local frame = _G.LevelPilotFrame
    local btn
    for b in pairs(UI.buttons or {}) do
        if UI.WindowOf(b) == frame then btn = b break end
    end
    local rec = { points = {} }
    local fake = {
        SetOwner = function(_, o, a) rec.owner, rec.anchor = o, a end,
        ClearAllPoints = function() rec.points = {} end,
        SetPoint = function(_, p, rel, rp) rec.points[#rec.points + 1] = { p, rel, rp } end,
        GetEffectiveScale = function() return UIParent:GetEffectiveScale() end,
    }
    local anchored = "kein Knopf"
    if btn then
        UI.TipAnchor(btn, fake)
        local pt = rec.points[1]
        if UI.lastTipSide == "CURSOR" then
            anchored = "ohne Fensterlage (Maus)"
        else
            anchored = (rec.anchor == "ANCHOR_NONE" and pt and pt[2] == frame) and ("am Fenster, " .. tostring(UI.lastTipSide)) or "FALSCH"
        end
    end
    local ok = pure and anchored ~= "FALSCH"
    return ok, string.format("Mitte %s (%s), rechter Rand %s, breit %s; Knopf im Leitfenster: %s", S(s1), S(d1), S(s2), S(s3), anchored),
        "RIGHT (-50), LEFT, BELOW; am Fenster"
end

------------------------------------------------------------------------
-- 3.12.19: übrige Abfragen mit geschütztem Wert (Ergänzung zu T223)
------------------------------------------------------------------------
IMPL.T241 = function()
    local bait = { "LPTestKoeder Abfrage" }
    local fake = {}
    for _, f in ipairs({ "GetPlayerFacing", "IsIndoors", "IsResting", "GetUnitSpeed", "UnitLevel" }) do
        fake[f] = function() return bait end
    end
    local last0 = LP.lastLevel
    return Guard(function()
        LP.lastLevel = 17
        return WithSecret({ bait }, function()
            return WithEnv({ LP.Facing, LP.Indoors, LP.Resting, LP.UnitSpeed, LP.RealLevel }, fake, function()
                local facing, indoors, resting, speed, level = LP.Facing(), LP.Indoors(), LP.Resting(), LP.UnitSpeed(), LP:RealLevel()
                -- Benutzer dieser Abfragen laufen ohne Fehler
                local bad = {}
                for name, fn in pairs({
                    Caves = function() local i, n, w = LP.Geo:Player() if i then LP.Caves:At(i, n, w, nil, nil, true) end end,
                    Ruhe = function() if LP.Session.ExtraText then LP.Session:ExtraText() end end,
                    Messen = function() if LP.Measure and LP.Measure.Text then LP.Measure:Text() end end,
                }) do
                    local ok, err = pcall(fn)
                    if not ok then bad[#bad + 1] = name .. ": " .. tostring(err):sub(1, 60) end
                end
                local ok = facing == nil and indoors == false and resting == false and speed == nil and level == 17 and #bad == 0
                return ok, string.format("Richtung %s, drinnen %s, Erholung %s, Tempo %s, Stufe %s%s", S(facing), S(indoors), S(resting),
                    S(speed), S(level), #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "nil, false, false, nil, 17 (zuletzt gelesen)"
            end)
        end)
    end, function() LP.lastLevel = last0 end)
end

------------------------------------------------------------------------
-- 3.12.21: GoldSentinelSync 2 und GoldSentinelTest 2 (Tests ersetzen nur GoldSentinelSync.api-Einträge)
------------------------------------------------------------------------
local function Sy() return _G.GoldSentinelSync end
-- api-Einträge vorübergehend ersetzen; eigene Einträge der Warteschlangen danach entfernen
local function WithSyncApi(repl, body)
    local S0 = Sy()
    if not S0 or type(S0.api) ~= "table" then return NA, "GoldSentinelSync fehlt" end
    local saved = {}
    for k, v in pairs(repl) do saved[k] = S0.api[k] S0.api[k] = v end
    local snap = LP.Comm:QueueSnapshot()
    return Guard(function() return body(S0) end, function()
        for k in pairs(repl) do S0.api[k] = saved[k] end
        LP.Comm:QueueRestore(snap)
    end)
end
local function Yes() return true end
local function No() return false end
-- Wege der eigenen neuen Einträge in der Warteschlange (Gilde/Gruppe) und im Netz
local function OwnDists(S0, q0, n0)
    local d = {}
    for i = q0 + 1, #S0.queue do local it = S0.queue[i] if it.prefix == "LvPilot2" then d[#d + 1] = it.dist end end
    local net = #(S0.netQueue or {}) - n0
    return d, net
end
-- einen Mitspieler mit Sync 2 ins Adressbuch (für das Netz); Rückgabe Aufräumfunktion
local function FakeNetPeer(S0, name)
    local old = S0.book[name]
    S0.book[name] = { seen = S0.api.time(), v = 2, src = "whisper", fail = 0, pause = 0 }
    return function() S0.book[name] = old end
end

IMPL.T242 = function()
    local Comm = LP.Comm
    return WithSetting({ shareGuild = true, shareGroup = true, shareChannel = true }, function()
        return WithSyncApi({ inGuild = Yes, inGroup = Yes, inRaid = No }, function(S0)
            local q0 = #S0.queue
            Comm:Broadcast({ "H\tLPTest242" })
            Comm:Hello()
            Comm:RequestZone(1411, true)
            local mark = ActMark()
            Comm:Rejoin()
            local joined = ActSince(mark)
            local dists, channel = {}, 0
            for i = q0 + 1, #S0.queue do
                local it = S0.queue[i]
                if it.prefix == "LvPilot2" then
                    dists[it.dist] = (dists[it.dist] or 0) + 1
                    local okDist = { GUILD = true, PARTY = true, RAID = true, WHISPER = true }
                    if not okDist[it.dist] then channel = channel + 1 end   -- jeder andere Weg (Kanal) ist falsch
                end
            end
            local n = (dists.GUILD or 0) + (dists.PARTY or 0)
            return n >= 6 and channel == 0 and joined == 0 and Comm.JoinChannel == nil,
                string.format("GUILD %d, PARTY %d, anderer Weg (Kanal) %d, Aktionen beim früheren Kanal-Beitritt %d", dists.GUILD or 0,
                    dists.PARTY or 0, channel, joined), "GUILD und PARTY je 3, Kanal 0, 0"
        end)
    end)
end

IMPL.T243 = function()
    local Comm = LP.Comm
    local function run(guild, group, net, inGuild, inGroup)
        return WithSetting({ shareGuild = guild, shareGroup = group, shareChannel = net }, function()
            return WithSyncApi({ inGuild = inGuild and Yes or No, inGroup = inGroup and Yes or No, inRaid = No }, function(S0)
                local q0, n0 = #S0.queue, #(S0.netQueue or {})
                local drop0 = S0.stats.dropped.nopath or 0
                local ok = Comm:Queue("H\tLPTest243")
                local d, net2 = OwnDists(S0, q0, n0)
                local nopath = (S0.stats.dropped.nopath or 0) - drop0
                S0.stats.dropped.nopath = drop0 > 0 and drop0 or nil
                return table.concat(d, "+") .. (net2 > 0 and "+NETZ" or ""), ok, nopath
            end)
        end)
    end
    local a = run(true, true, false, true, false)
    local b = run(true, true, false, false, true)
    local c, okc, dropc = run(true, true, false, false, false)
    local d = run(false, true, false, true, true)
    -- 3.12.22: Einstellungen mit Netz (ein Netz-Mitspieler bekannt, in Gilde und Gruppe)
    local S0 = Sy()
    local undo = S0 and FakeNetPeer(S0, "Testa Beispiel") or function() end
    local oldNet = S0 and S0.NET
    if S0 then S0.NET = true end
    local e, f, g, h = "", "", "", ""
    Guard(function()
        e = run(false, false, true, true, true)
        f = run(true, false, true, true, true)
        g = run(false, true, true, true, true)
        h = run(true, true, true, true, true)
    end, function() undo() if S0 then S0.NET = oldNet end end)
    local ok = a == "GUILD" and b == "PARTY" and c == "" and okc == false and dropc == 1 and d == "PARTY"
        and e == "" and f == "GUILD" and g == "PARTY" and h == "GUILD+PARTY+NETZ"
    return ok, string.format("Gilde: %s · Gruppe: %s · ohne beides: %s (gesendet %s, kein Weg %d) · nur Gruppe erlaubt: %s"
        .. " · nur Netz: %s · Gilde+Netz: %s · Gruppe+Netz: %s · alles: %s",
        a, b, c == "" and "nichts" or c, S(okc), dropc or 0, d, e == "" and "nichts" or e, f, g, h),
        "GUILD · PARTY · nichts (false, 1) · PARTY · nichts · GUILD · PARTY · GUILD+PARTY+NETZ"
end

IMPL.T244 = function()
    local S0 = Sy()
    if not S0 or not S0.OnChannelNotice then return NA, "GoldSentinelSync fehlt" end
    local before = S0.stats.channelRefused or 0
    return Guard(function()
        S0.OnChannelNotice("NOT_ALLOWED_IN_CHANNEL")
        S0.OnChannelNotice("YOU_JOINED")
        local after = S0.stats.channelRefused
        local lines = table.concat(LP.Comm:DiagLines(), "\n")
        local shown = lines:find("Kanal verweigert " .. after, 1, true) ~= nil
        local proto = LP.Protocol:Text():find("SYNC", 1, true) ~= nil
        return after == before + 1 and shown and proto, string.format("gezählt +%d, in der Diagnose %s, im Protokoll %s",
            after - before, S(shown), S(proto)), "+1, true, true"
    end, function() S0.stats.channelRefused = before end)
end

IMPL.T245 = function()
    local ep = LP.Comm.ep
    if not ep then return false, "LevelPilot nicht bei GoldSentinelSync angemeldet", "angemeldet" end
    return WithCounter(LP.Comm, "Receive", function(n)
        local bad = 0
        for _, fn in ipairs(ep.handlers) do
            local ok = pcall(fn, "H\t3.12.0\t5\t10", nil, "GUILD")
            if not ok then bad = bad + 1 end
        end
        local mark = ActMark()
        LP.Comm:OnZoneRequest(nil, 1411)
        local replies = ActSince(mark)
        return n() == 1 and bad == 0 and replies == 0, string.format("verarbeitet %d, Fehler %d, Antwort ohne Absender %d", n(), bad, replies),
            "1, 0, 0"
    end)
end

IMPL.T246 = function()
    local recv0 = LP.db.net.recv or 0
    return WithCounter(LP.Comm, "Receive", function(n)
        Deliver("LvPilot2", "H\t3.11.0\t5\t10", "GUILD", "LPAlt-Test")
        local a = n()
        Deliver("LvPilotG", "S\t5\t10\tGOTO\t0\tLPTest", "PARTY", "LPAlt-Test")
        local member = LP.Group.members["LPAlt"] ~= nil
        LP.Group.members["LPAlt"] = nil
        LP.db.net.recv = recv0
        return a == 1 and member, string.format("Daten ohne Kopf verstanden %d, Gruppe ohne Kopf %s", a, S(member)), "1, true"
    end)
end

IMPL.T247 = function()
    local S0 = Sy()
    if not S0 or not S0.Ping then return NA, "GoldSentinelSync fehlt" end
    local realNow, realSend = S0.api.now, S0.api.send
    local t = realNow()
    local sent = 0
    -- Ping und eigene Nachrichten nur zählen; Nachrichten anderer Addons gehen normal hinaus
    local function send(prefix, ...)
        if prefix == S0.CTRL or OWN_PREFIX[prefix] then sent = sent + 1 return true end
        return realSend(prefix, ...)
    end
    return WithSyncApi({ now = function() return t end, inGuild = Yes, inGroup = No, inRaid = No, send = send }, function()
        local out = {}
        LP.Comm:SyncTest(function(line) out[#out + 1] = line end)
        for _ = 1, 3 do S0.Pump(true) end
        t = t + S0.PING_WAIT + 1
        S0.Tick()
        local last = out[#out] or ""
        local ok = #out == 2 and last:find("%d") ~= nil and last ~= out[1]
        return ok, string.format("%d Zeilen: %s (Ping gesendet %d)", #out, table.concat(out, " | "), sent),
            "2 Zeilen, zweite „N Antworten (Gilde a, Gruppe b)“"
    end)
end

IMPL.T248 = function()
    local S0 = Sy()
    local v = S0 and tonumber(S0.VERSION)
    return v ~= nil and v >= 2, "GoldSentinelSync " .. S(v), "Version >= 2"
end

IMPL.T249 = function()
    local S0 = Sy()
    if not S0 or not S0.OnAddonMessage then return NA, "GoldSentinelSync fehlt" end
    local store = LP.Acc().gsSync      -- 3.12.56: Bereich der Spielversion
    local name = "Testa Beispiel"
    local old = S0.book[name]
    return Guard(function()
        S0.OnAddonMessage("LvPilot2", "#S1:lptst249:1:H\t3.12.21\t1\t1", "GUILD", name)
        local inBook = S0.book[name] ~= nil
        local own = type(store) == "table" and type(store.book) == "table"
        local stored = own and (store.book[name] ~= nil or (S0.store ~= store and S0.store and S0.store.book[name] ~= nil))
        return inBook and stored and true or false, string.format("gelernt %s, LevelPilotDB.gsSync %s, gespeichert %s%s", S(inBook), S(own),
            S(stored), S0.store == store and "" or " (Speicher eines anderen GoldSentinel-Addons)"), "true, true, true"
    end, function() S0.book[name] = old S0.peers.lptst249 = nil end)
end

IMPL.T250 = function()
    local ep = LP.Comm.ep
    local S0 = Sy()
    if not ep or not S0 then return NA, "GoldSentinelSync fehlt" end
    return WithSyncApi({ inGuild = Yes, inGroup = No, inRaid = No }, function()
        local undo = FakeNetPeer(S0, "Testa Beispiel")
        local oldNet = S0.NET
        return Guard(function()
            S0.NET = true
            local function grow(opts)
                local n0 = #S0.netQueue
                ep:Send("H\tLPTest250", opts)
                return #S0.netQueue - n0
            end
            local all, nonet, guild = grow(nil), grow({ net = false }), grow({ scope = "guild" })
            return all >= 1 and nonet == 0 and guild == 0, string.format("normal %d, net=false %d, scope guild %d", all, nonet, guild),
                ">= 1, 0, 0"
        end, function() undo() S0.NET = oldNet end)
    end)
end

IMPL.T251 = function()
    local S0 = Sy()
    if not S0 then return NA, "GoldSentinelSync fehlt" end
    local undo = FakeNetPeer(S0, "Testa Beispiel")
    return Guard(function()
        local text = table.concat(LP.Comm:DiagLines(), "\n") .. "\n" .. LP.Protocol:Text()
        local me = UnitName("player")
        local netz = text:find("NETZ", 1, true) ~= nil
        local leak = text:find("Testa Beispiel", 1, true) ~= nil
            or (type(me) == "string" and not LP.Game.IsSecret(me) and me ~= "" and text:find(me, 1, true) ~= nil)
        for name in pairs(S0.book) do
            if type(name) == "string" and #name > 2 and text:find(name, 1, true) then leak = true end
        end
        return netz and not leak, string.format("NETZ %s, Spielernamen %s", S(netz), leak and "GEFUNDEN" or "keine"), "true, keine"
    end, undo)
end

IMPL.T252 = function()
    local g = _G.GoldSentinelTest
    local v = g and tonumber(g.version)
    return v ~= nil and v >= 2, "GoldSentinelTest " .. S(v), "Version >= 2"
end

IMPL.T253 = function()
    local g = _G.GoldSentinelTest
    if not g or not g.Setting then return NA, "GoldSentinelTest 2 fehlt" end
    local old = g.Setting("consent")
    local sh = LevelPilotDB.gsTest and LevelPilotDB.gsTest.share
    local n0 = sh and type(sh.outbox) == "table" and #sh.outbox or 0
    local e0, last0 = LP.errorCount, LP.lastError
    return Guard(function()
        g.SetSetting("consent", false)
        LP:Safe("Testroutine", function() error("LP-Testfehler Ausgang", 0) end)
        sh = LevelPilotDB.gsTest and LevelPilotDB.gsTest.share
        local n1 = sh and type(sh.outbox) == "table" and #sh.outbox or 0
        return n1 == n0, string.format("Ausgang vorher %d, nach dem Fehler %d (Zustimmung %s)", n0, n1, S(old)), "unverändert"
    end, function()
        g.SetSetting("consent", old)
        TR.ForgetTestErrors(e0, last0)
    end)
end

------------------------------------------------------------------------
-- 3.12.22: Nachprüfung 3.12.21
------------------------------------------------------------------------
IMPL.T254 = function()
    local Comm, Soc = LP.Comm, LP.Social
    local S0 = Sy()
    if not S0 or not Comm.ep then return NA, "GoldSentinelSync fehlt" end
    local origin = "Testa Beispiel"
    local hash = Comm.OriginKey(origin)
    return WithSetting({ findPartners = true, shareGuild = true, shareGroup = true, shareChannel = true }, function()
        return WithSyncApi({ inGuild = Yes, inGroup = Yes, inRaid = No }, function()
            local undo = FakeNetPeer(S0, "LPNetz Partner")
            local oldNet, saved = S0.NET, {}
            for k, v in pairs(Soc.partners) do saved[k] = v end
            return Guard(function()
                S0.NET = true
                wipe(Soc.partners)
                local zone = 0
                local origZ = Comm.OnZoneRequest
                Comm.OnZoneRequest = function() zone = zone + 1 end
                local function count() local n = 0 for _ in pairs(Soc.partners) do n = n + 1 end return n end
                -- weitergegeben übers Netz (Absender = Weitergeber)
                Deliver("LvPilot2", "#S2:lpt254a:1:1:E\t1413\t20\t123\t" .. hash, "WHISPER", "LPWeiter-Test")
                Deliver("LvPilot2", "#S2:lpt254a:2:1:Z\t1413\t20\t" .. hash, "WHISPER", "LPWeiter-Test")
                -- ältere Version ohne Prüfsumme, geflüstert und vom Weitergeber in seine Gilde gebracht (3.12.23)
                Deliver("LvPilot2", "E\t1413\t20\t123", "WHISPER", "LPWeiter-Test")
                Deliver("LvPilot2", "#S1:lpt254c:1:E\t1413\t20\t123", "GUILD", "LPWeiter-Test")
                Deliver("LvPilot2", "#S1:lpt254c:2:Z\t1413\t20", "GUILD", "LPWeiter-Test")
                local relayed, relayedZ = count(), zone
                -- vom Urheber selbst in der Gilde
                Deliver("LvPilot2", "#S1:lpt254b:1:E\t1413\t20\t123\t" .. hash, "GUILD", origin .. "-Realm")
                Deliver("LvPilot2", "#S1:lpt254b:2:Z\t1413\t20\t" .. hash, "GUILD", origin)
                local direct, directZ = count() - relayed, zone - relayedZ
                Comm.OnZoneRequest = origZ
                -- eigenes Senden von E und Z: nichts ins Netz
                local n0 = #S0.netQueue
                local enc = Soc.Encode
                Soc.Encode = function() return "E\t1413\t20\t123\t" .. Comm.OwnOrigin() end
                Soc:Announce()
                Soc.Encode = enc
                Comm:RequestZone(1413, true)
                local netAdded = #S0.netQueue - n0
                local ok = relayed == 0 and relayedZ == 0 and direct == 1 and directZ == 1 and netAdded == 0
                return ok, string.format("weitergegeben: Partner %d, Anfrage %d · vom Urheber: Partner %d, Anfrage %d · eigene ins Netz %d",
                    relayed, relayedZ, direct, directZ, netAdded), "0, 0 · 1, 1 · 0"
            end, function()
                undo() S0.NET = oldNet
                wipe(Soc.partners) for k, v in pairs(saved) do Soc.partners[k] = v end
            end)
        end)
    end)
end

IMPL.T255 = function()
    local Comm = LP.Comm
    local S0 = Sy()
    if not S0 then return NA, "GoldSentinelSync fehlt" end
    local caves = LP.db.caves
    local fake = {}
    for k = 1, 60 do
        fake["lpt255_" .. k] = { i = 1, en = 1000 + k, ew = 2000 + k, cn = 1010 + k, cw = 2010 + k, m = 1412, r = 60, net = true }
    end
    return WithSyncApi({}, function()
        return Guard(function()
            LP.db.caves = fake
            local q0 = #S0.queue
            local sent = Comm:ReplyZone("LPFrager-Test", 1412) or 0
            local inQueue = #S0.queue - q0
            -- volle Warteschlange: keine Antwort
            for _ = 1, Comm.REPLY_QUEUE_LIMIT + 1 do S0.queue[#S0.queue + 1] = { prefix = "LPTestFremd", msg = "x", dist = "GUILD" } end
            local q1 = #S0.queue
            local sent2 = Comm:ReplyZone("LPFrager2-Test", 1412) or 0
            local full = #S0.queue - q1
            for i = #S0.queue, 1, -1 do if S0.queue[i].prefix == "LPTestFremd" then table.remove(S0.queue, i) end end
            return sent > 0 and sent <= Comm.REPLY_MAX and inQueue <= Comm.REPLY_MAX and sent2 == 0 and full == 0,
                string.format("Antwort %d Nachrichten (Warteschlange +%d) · bei voller Warteschlange %d", sent, inQueue, sent2),
                "1–25 · 0"
        end, function() LP.db.caves = caves end)
    end)
end

IMPL.T256 = function()
    local Comm = LP.Comm
    return WithSyncApi({ inGuild = No, inGroup = No, inRaid = No }, function()
        local key = "lpt256"
        local first = WithSetting({ shareGuild = true, shareGroup = true, shareChannel = false }, function()
            return Comm:Broadcast({ "H\tLPTest256" }, key)
        end)
        local second
        WithSyncApi({ inGuild = Yes }, function()
            second = WithSetting({ shareGuild = true, shareGroup = true, shareChannel = false }, function()
                return Comm:Broadcast({ "H\tLPTest256" }, key)
            end)
        end)
        local third
        WithSyncApi({ inGuild = Yes }, function()
            third = WithSetting({ shareGuild = true, shareGroup = true, shareChannel = false }, function()
                return Comm:Broadcast({ "H\tLPTest256" }, key)
            end)
        end)
        return first == false and second == true and third == nil,
            string.format("ohne Weg %s, danach mit Gilde %s, nochmals %s", S(first), S(second), S(third)),
            "false, true, nil (schon gesendet)"
    end)
end

IMPL.T257 = function()
    local S0 = Sy()
    if not S0 or not S0.api or not S0.api.lpDry then return NA, "nur während der ganzen Testroutine" end
    -- während der Routine sind die Warteschlangen eigene Tabellen: nichts Fremdes darin
    local foreign = 0
    for _, it in ipairs(S0.queue) do if not OWN_PREFIX[it.prefix] and it.prefix ~= S0.CTRL then foreign = foreign + 1 end end
    local h = TR.syncHandle
    local separate = h ~= nil and h.queue ~= S0.queue and h.netQueue ~= S0.netQueue
    return separate and foreign == 0, string.format("eigene Warteschlange %s, fremde Einträge darin %d", S(separate), foreign),
        "true, 0"
end

IMPL.T258 = function()
    local Pr = LP.Protocol
    if not Pr.StepIdle then return false, "Protocol.StepIdle fehlt", "vorhanden" end
    -- in der Stadt stehen (Bank, Auktionshaus): kein SCHRITT-Eintrag; gelaufen: Eintrag
    local idle = Pr.StepIdle(40, true)
    local walked = Pr.StepIdle(800, true)
    local field = Pr.StepIdle(40, false)
    local dungeon = Pr.StepSkip({ key = "DGIN", t = "DUNGEON" })
    local turnin = Pr.StepSkip({ key = "TURNIN:405", t = "TURNIN" })
    -- FOKUS: aktueller Schritt in der Zone des Spielers -> keine Meldung
    local fokusHere = Pr.FocusOk(1456, 1456, 1413)
    local fokusAway = Pr.FocusOk(1456, 1413, 1413)
    local ok = idle and not walked and not field and dungeon and not turnin and fokusHere and not fokusAway
    return ok, string.format("Stadt gestanden: ruhig %s, gelaufen: %s, Feld: %s · Dungeon ruhig %s, Abgabe %s · Fokus beim Abarbeiten ruhig %s, sonst %s",
        S(idle), S(walked), S(field), S(dungeon), S(turnin), S(fokusHere), S(fokusAway)),
        "true, false, false · true, false · true, false"
end

------------------------------------------------------------------------
-- 3.12.23: Wegstücke ohne grosse Lücken
------------------------------------------------------------------------
IMPL.T259 = function()
    local R, Gr, Geo = LP.Recorder, LP.Graph, LP.Geo
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    local pos = { n, w }
    local origPlayer, origVirt = Geo.Player, LP.Virtual.active
    Geo.Player = function() return i, pos[1], pos[2], 1412, 8, 92 end
    return Guard(function()
        LP.Virtual.active = false
        R:FlushTrail(true)
        local e0 = Gr:Stats().edges
        local gapTrail, gapEdges, walkTrail
        WithSetting({ recordPaths = true }, function()
            R:SamplePath()                       -- erster Punkt
            pos[1] = n + 70                      -- 70 Yards weiter (Ruckler, schnell)
            R:SamplePath()
            gapTrail = R:TrailCount()            -- neue Spur ab dem zweiten Punkt
            R:FlushTrail(false)
            gapEdges = Gr:Stats().edges - e0
            -- normal gelaufen: alle 12 Yards
            for k = 1, 5 do pos[1] = n + 200 + k * 12 R:SamplePath() end
            walkTrail = R:TrailCount()
        end)
        return gapTrail == 1 and gapEdges == 0 and walkTrail == 5,
            string.format("nach 70-Yards-Lücke Spur %d Punkt(e), Kanten über die Lücke %d · gelaufen %d Punkte", gapTrail, gapEdges, walkTrail),
            "1, 0 · 5"
    end, function() Geo.Player, LP.Virtual.active = origPlayer, origVirt R:FlushTrail(true) end)
end

IMPL.T260 = function()
    local Gr = LP.Graph
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    -- ein altes gerades Stück: 100 Yards ohne Zwischenpunkt, daneben ein Weg, der 30 Yards vor dem Ende davon abgeht
    Gr:AddPolyline({ { i, n, w - 60, 1412 }, { i, n + 100, w - 60, 1412 } }, "r")
    local a = Gr:Nearest(i, n, w - 60, 2, 1412)
    local b = Gr:Nearest(i, n + 100, w - 60, 2, 1412)
    local split = Gr:Densify()
    local longest, steps = 0, 0
    -- Weg von a nach b ablaufen
    local cur, prev = a, nil
    while cur and cur ~= b and steps < 20 do
        local nextId
        for v in pairs(Gr:Neighbors(cur) or {}) do
            local nd = Gr:NodeById(v)
            if v ~= prev and nd and math.abs(nd[3] - (w - 60)) < 1 then nextId = v end
        end
        if not nextId then break end
        local p, q = Gr:NodeById(cur), Gr:NodeById(nextId)
        longest = math.max(longest, math.sqrt((q[2] - p[2]) ^ 2 + (q[3] - p[3]) ^ 2))
        prev, cur, steps = cur, nextId, steps + 1
    end
    local reached = cur == b
    return split >= 1 and reached and longest <= 25.5 and steps >= 4,
        string.format("geteilt %d, %d Stücke, längstes %.1f Yards, Weg durchgehend %s", split, steps, longest, S(reached)),
        ">= 1, 4 Stücke, <= 25 Yards, true"
end

------------------------------------------------------------------------
-- 3.12.24: Lag beim Einloggen (T-LAG1–T-LAG4)
------------------------------------------------------------------------
IMPL.T261 = function()
    local Pf = LP.Perf
    local sum, worst, n = 0, 0, 0
    for _, s in pairs(Pf.stats) do
        sum = sum + (s.lms or 0)
        worst = math.max(worst, s.lmax or 0)
        n = n + (s.ln or 0)
    end
    if n == 0 then return NA, "keine Messung aus den ersten 60 s nach dem Einloggen" end
    return sum < 1000, string.format("erste 60 s: %d ms in %d Aufrufen, längster %d ms", math.floor(sum), n, math.floor(worst)),
        "< 1000 ms"
end
CLIENT.T261 = "Mit dem Krieger einloggen: sofort laufen können, CPU normal; /lp diag – Zeile „ZEIT erste 60 s“ unter 1000 ms"

IMPL.T262 = function()
    local Pf = LP.Perf
    local saved = { clock = Pf.clock, paused = Pf.paused, windows = Pf.windows, said = Pf.said, brakes = Pf.brakes, print = LP.Print }
    local t = 0
    local printed = {}
    return Guard(function()
        Pf.clock = function() return t end
        Pf.paused, Pf.windows, Pf.said, Pf.testBrake = {}, {}, {}, true
        LP.Print = function(_, m) printed[#printed + 1] = tostring(m) end
        local runs = 0
        local function costly(ms) return function() runs = runs + 1 t = t + ms end end
        -- 1) ein Aufruf über 50 ms
        Pf.Run("lpt262a", "route", true, costly(80))
        local paused1 = Pf.Paused("lpt262a")
        Pf.Run("lpt262a", "route", true, costly(80))       -- pausiert: läuft nicht
        local ran1 = runs
        -- 2) viele kleine: 30 × 40 ms in 5 s
        runs = 0
        for _ = 1, 30 do Pf.Run("lpt262b", "route", true, costly(40)) end
        local paused2, ran2 = Pf.Paused("lpt262b"), runs
        -- 3) nochmals über 50 ms: keine zweite Chatzeile für denselben Schlüssel
        Pf.paused.lpt262a = nil
        Pf.Run("lpt262a", "route", true, costly(80))
        local lines = 0
        for _, m in ipairs(printed) do if m:find("60", 1, true) then lines = lines + 1 end end
        local slow = 0
        for _, e in ipairs(LP.Protocol:Entries()) do if e.k == "brake" and tostring(e.msg):find("lpt262", 1, true) then slow = slow + 1 end end
        -- 4) 3.12.25: Hintergrund 300 ms in 4-ms-Portionen -> keine Pause; eine Portion über 50 ms -> Pause
        local bg = Pf.CheckSlice("lpt262c", 4)
        local bgLong = Pf.CheckSlice("lpt262d", 60)
        -- 5) in der Pause verworfen: gezählt, Nachholen vorgemerkt
        local again = 0
        Pf.after.lpt262b = function() again = again + 1 end
        local sk0 = Pf.skipped.lpt262b or 0
        Pf.Run("lpt262b", "route", true, costly(1))
        local skipped = (Pf.skipped.lpt262b or 0) - sk0
        local queued = Pf.afterSet and Pf.afterSet.lpt262b == true
        Pf.after.lpt262b, Pf.skipped.lpt262b = nil, nil
        if Pf.afterSet then Pf.afterSet.lpt262b = nil end
        local ok = paused1 and ran1 == 1 and paused2 and ran2 < 30 and lines >= 2 and slow >= 2
            and bg == false and bgLong == true and skipped == 1 and queued
        return ok, string.format("über 50 ms: Pause %s, zweiter Aufruf lief %s · Summe: Pause %s nach %d Aufrufen · Chatzeilen %d · LANGSAM %d"
            .. " · Portionen 4 ms: Pause %s, Portion 60 ms: Pause %s · in der Pause verworfen %d, Nachholen vorgemerkt %s",
            S(paused1), S(ran1 > 1), S(paused2), ran2, lines, slow, S(bg), S(bgLong), skipped, S(queued)),
            "true, false · true, < 30 · >= 2 · >= 2 · false, true · 1, true"
    end, function()
        Pf.clock, Pf.paused, Pf.windows, Pf.said, Pf.brakes, LP.Print = saved.clock, saved.paused, saved.windows, saved.said, saved.brakes, saved.print
        Pf.testBrake = nil
    end)
end

IMPL.T263 = function()
    local Gr, Comm, Jobs, Pf = LP.Graph, LP.Comm, LP.Jobs, LP.Perf
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    local t0 = Pf.clock()
    -- 2000 Wegpunkte: 50 Spuren zu 40 Punkten (alle 12 Yards) am Kartenrand
    local seed = 1
    local function rnd() seed = (seed * 1103515245 + 12345) % 2147483648 return seed / 2147483648 end
    for k = 1, 50 do
        local pts, dn, dw, dir = {}, n + rnd() * 600, w - rnd() * 600, rnd() * 6.28
        for _ = 1, 40 do
            dir = dir + (rnd() - 0.5) * 0.6
            dn, dw = dn + 12 * math.cos(dir), dw + 12 * math.sin(dir)
            pts[#pts + 1] = { i, dn, dw, 1412 }
        end
        Gr:AddPolyline(pts, "r")
    end
    local build = Pf.clock() - t0
    -- 500 empfangene Netz-Einträge (Wegstücke), je Absender höchstens 25
    local worstRecv, recv = 0, 0
    WithCounter(LP, "Fire", function()
        for k = 1, 500 do
            local a = { i, n + 700 + (k % 40) * 12, w - 700 - math.floor(k / 40) * 12, 1412 }
            local b = { i, a[2] + 12, a[3], 1412 }
            local msg = Comm:EncodePath({ a, b }, "0")[1]
            local s0 = Pf.clock()
            Comm:Receive(msg, "LPLast" .. math.floor(k / 25) .. "-Test", "GUILD")
            local ms = Pf.clock() - s0
            recv = recv + ms
            if ms > worstRecv then worstRecv = ms end
        end
    end)
    -- Wegsuche in Portionen: erreichbares und unerreichbares Ziel (andere Welt ohne Übergang)
    local function portions(gi, gn, gw, gz)
        local oldSync, frames, worst, result = Jobs.sync, 0, 0, nil
        Jobs.sync = false
        Jobs.Start("lpt263", "path", function() return Gr:Path(i, n, w, 1412, gi, gn, gw, gz) end, function(ok, p) result = ok and (p and #p or 0) or -1 end)
        while Jobs.Running("lpt263") and frames < 5000 do
            local s0 = Pf.clock()
            Jobs.Step()
            local ms = Pf.clock() - s0
            if ms > worst then worst = ms end
            frames = frames + 1
        end
        Jobs.Cancel("lpt263")
        Jobs.sync = oldSync
        return frames, worst, result
    end
    local f1, w1, r1 = portions(i, n + 500, w - 500, 1412)
    local f2, w2, r2 = portions(i + 999, n, w, 99999)
    local total = Pf.clock() - t0
    local ok = worstRecv <= 16 and w1 <= 16 and w2 <= 16 and f1 < 5000 and f2 < 5000 and r1 ~= nil and r2 ~= nil
    return ok, string.format("Aufbau %d ms · 500 Einträge: längster %.1f ms (Summe %d ms) · Wegsuche: %d Portionen, längste %.1f ms · unerreichbar: %d Portionen, längste %.1f ms, beendet %s · gesamt %d ms",
        math.floor(build), worstRecv, math.floor(recv), f1, w1, f2, w2, S(r2 ~= nil), math.floor(total)),
        "je Portion und Eintrag <= 16 ms, Suche endet"
end

IMPL.T264 = function()
    local Pf, Pr = LP.Perf, LP.Protocol
    Pf.Add("route", 3)
    local text = Pr:Text()
    local zeit = text:find("ZEIT ", 1, true) ~= nil
    local login = text:find("erste 60 s", 1, true) ~= nil
    local route = text:find("Routenberechnung", 1, true) ~= nil
    local exp = Pr.ExportString()
    local head = exp:sub(1, 19) == "GSDIAG1|LevelPilot|"
    local me = UnitName and LP.SafeValue(UnitName("player"))
    local leak = type(me) == "string" and me ~= "" and exp:find(me, 1, true) ~= nil
    local wrote = Pr:WriteExport()                   -- im Test nie in die Speicherdatei
    return zeit and login and route and head and not leak and wrote == false,
        string.format("ZEIT %s, erste 60 s %s, Module %s, Export %s (%d Zeichen), Name %s, im Test geschrieben %s",
            S(zeit), S(login), S(route), S(head), #exp, leak and "GEFUNDEN" or "keiner", S(wrote)),
        "true, true, true, true, keiner, false"
end

IMPL.T265 = function()
    local Gr = LP.Graph
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    local c0 = Gr:Count()
    -- 60 Yards (mögliche Lücke) und 120 Yards (alte Vereinfachung)
    Gr:AddPolyline({ { i, n - 900, w + 300, 1412 }, { i, n - 840, w + 300, 1412 } }, "r")
    Gr:AddPolyline({ { i, n - 900, w + 400, 1412 }, { i, n - 780, w + 400, 1412 } }, "r")
    local a = Gr:Nearest(i, n - 900, w + 300, 2, 1412)
    local b = Gr:Nearest(i, n - 840, w + 300, 2, 1412)
    local c1 = Gr:Count()
    Gr:Densify()
    local e60 = a and b and Gr:Neighbors(a) and Gr:Neighbors(a)[b]
    local unsure = e60 and e60.u == 1
    local added = Gr:Count() - c1
    -- verwaiste Knoten: jeder neue Knoten hat Kanten
    local orphans = 0
    for _, id in ipairs(Gr:Near(i, n - 840, w + 400, 80, 1412)) do
        if not next(Gr:Neighbors(id) or {}) then orphans = orphans + 1 end
    end
    return unsure and added == 4 and orphans == 0 and c1 - c0 == 4,
        string.format("60 Yards unsicher und ungeteilt %s · 120 Yards: %d neue Knoten · ohne Kante %d", S(unsure), added, orphans),
        "true · 4 · 0"
end

------------------------------------------------------------------------
-- 3.12.25: Nachprüfung 3.12.24
------------------------------------------------------------------------
IMPL.T266 = function()
    local Gr = LP.Graph
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    -- Planung mit kurzer Wegprüfung, auch wenn die Suche einen Fehler wirft
    local origRaw = Gr.PathRaw
    Gr.PathRaw = function() error("LP-Testfehler Wegsuche", 0) end
    local ok1 = pcall(Gr.Path, Gr, i, n, w, 1412, i, n + 300, w, 1412, 5)
    Gr.PathRaw = origRaw
    local global = Gr.expandLimit
    -- je Suche: mit 1 Schritt kein langer Weg, danach ohne Grenze wieder normal
    local seen = {}
    local origRaw2 = Gr.PathRaw
    Gr.PathRaw = function(self, a, b, c, d, e, f, g, h, maxExpand) seen[#seen + 1] = maxExpand or "nil" return origRaw2(self, a, b, c, d, e, f, g, h, maxExpand) end
    pcall(Gr.Path, Gr, i, n, w, 1412, i, n + 300, w, 1412, 1)
    pcall(Gr.Path, Gr, i, n, w, 1412, i, n + 300, w, 1412)
    Gr.PathRaw = origRaw2
    local passed = seen[1] == 1 and seen[#seen] == "nil"
    return ok1 == false and global == nil and passed,
        string.format("Fehler in der Suche aufgefangen %s, globale Grenze %s, Grenze je Suche %s (danach %s)", S(not ok1), S(global),
            S(seen[1]), S(seen[#seen])), "true, nil, 1 (danach nil)"
end

IMPL.T267 = function()
    local Gr = LP.Graph
    local i, n, w = WegBase()
    if not i then return NA, "Mulgore-Karte nicht verfügbar" end
    local function line(dn, dw, step, count)
        local pts = {}
        for k = 0, count do pts[#pts + 1] = { i, n + dn + k * step, w + dw, 1412 } end
        -- Knoten direkt anlegen wie Densify (ohne Zusammenlegen benachbarter Punkte)
        Gr:AddPolyline(pts, "r")
        return Gr:Nearest(i, n + dn, w + dw, 2, 1412), Gr:Nearest(i, n + dn + step, w + dw, 2, 1412)
    end
    local a1, b1 = line(-1300, 500, 20, 3)          -- 60 Yards in 3 gleichen Stücken: geteilte Lücke
    local a2, b2 = line(-1300, 600, 30, 4)          -- 120 Yards: alte Vereinfachung, nicht markieren
    local chains = Gr:MarkSplitGaps()
    local e1 = a1 and b1 and (Gr:Neighbors(a1) or {})[b1]
    local e2 = a2 and b2 and (Gr:Neighbors(a2) or {})[b2]
    local m1, m2 = e1 and e1.u == 1, e2 and e2.u == 1
    return m1 and not m2 and chains >= 1, string.format("60-Yards-Kette unsicher %s, 120-Yards-Kette unsicher %s, Ketten %d", S(m1), S(m2), chains),
        "true, false, >= 1"
end

IMPL.T268 = function()
    local Pf, Pr, Jobs = LP.Perf, LP.Protocol, LP.Jobs
    local saved = { paused = Pf.paused, windows = Pf.windows, said = Pf.said, print = LP.Print }
    return Guard(function()
        Pf.paused, Pf.windows, Pf.said, Pf.testBrake = {}, {}, {}, true
        LP.Print = function() end
        Pf.Check("lpt268", 99, "Test")
        LP.Planner:Replan()
        local kept = 0
        for _, e in ipairs(Pr:Entries()) do if e.k == "brake" and tostring(e.msg):find("lpt268", 1, true) then kept = kept + 1 end end
        -- ein Auftrag startet während seiner Portion einen neuen
        local oldSync = Jobs.sync
        Jobs.sync = false
        local inner, err = false, nil
        Jobs.Start("lpt268a", "graph", function()
            Jobs.Start("lpt268b", "graph", function() inner = true end)
        end)
        local ok = pcall(function()
            for _ = 1, 5 do Jobs.Step() end
        end)
        Jobs.Cancel("lpt268a") Jobs.Cancel("lpt268b")
        Jobs.sync = oldSync
        return kept >= 1 and ok and inner, string.format("LANGSAM nach Planung noch da %d · Auftrag im Auftrag: ohne Fehler %s, lief %s", kept, S(ok), S(inner)),
            ">= 1 · true, true"
    end, function()
        Pf.paused, Pf.windows, Pf.said, LP.Print, Pf.testBrake = saved.paused, saved.windows, saved.said, saved.print, nil
    end)
end

------------------------------------------------------------------------
-- 3.12.26: umfassende Tests TU1–TU9 (anweisung-tests-umfassend.txt)
------------------------------------------------------------------------
-- Zuordnung der Fälle zu den Bereichen TU1–TU7 für die Zeilen im Testbericht (TU8)
TR.TU = {
    TU1 = { "T269", "T214", "T217", "T222", "T26", "T45", "T39" },
    TU2 = { "T270", "T230", "T232", "T259", "T263", "T147", "T155" },
    TU3 = { "T271", "T123", "T206", "T207", "T204" },
    TU4 = { "T272" },
    TU5 = { "T274" },
    TU6 = { "T273" },
    TU7 = { "T275", "T06", "T77", "T92", "T223", "T241" },
}
TR.TU_NAMES = { TU1 = "Lagen", TU2 = "Abläufe", TU3 = "Standardwerte", TU4 = "Grundregeln", TU5 = "echte Daten",
                TU6 = "Regressionen", TU7 = "Formen des Spiels" }

-- Völker (Classic-Bit, Fraktion, Startgebiet) und mögliche Klassen
local LAGEN_RACES = {
    { id = 1, name = "Human",    f = "Alliance", start = 1429, classes = { "WARRIOR", "PALADIN", "ROGUE", "PRIEST", "MAGE", "WARLOCK" } },
    { id = 3, name = "Dwarf",    f = "Alliance", start = 1426, classes = { "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST" } },
    { id = 4, name = "NightElf", f = "Alliance", start = 1438, classes = { "WARRIOR", "HUNTER", "ROGUE", "PRIEST", "DRUID" } },
    { id = 7, name = "Gnome",    f = "Alliance", start = 1426, classes = { "WARRIOR", "ROGUE", "MAGE", "WARLOCK" } },
    { id = 2, name = "Orc",      f = "Horde",    start = 1411, classes = { "WARRIOR", "HUNTER", "ROGUE", "SHAMAN", "WARLOCK" } },
    { id = 5, name = "Scourge",  f = "Horde",    start = 1420, classes = { "WARRIOR", "ROGUE", "PRIEST", "MAGE", "WARLOCK" } },
    { id = 6, name = "Tauren",   f = "Horde",    start = 1412, classes = { "WARRIOR", "HUNTER", "SHAMAN", "DRUID" } },
    { id = 8, name = "Troll",    f = "Horde",    start = 1411, classes = { "WARRIOR", "HUNTER", "ROGUE", "PRIEST", "SHAMAN", "MAGE" } },
}
local LAGEN_CLASS_BITS = { WARRIOR = 1, PALADIN = 2, HUNTER = 4, ROGUE = 8, PRIEST = 16, SHAMAN = 64, MAGE = 128, WARLOCK = 256, DRUID = 1024 }
local LAGEN_RACE_BITS = { [1] = 1, [2] = 2, [3] = 4, [4] = 8, [5] = 16, [6] = 32, [7] = 64, [8] = 128 }
local LAGEN_LEVELS = { 1, 12, 30, 58 }

-- Lage einstellen: Volk, Klasse, Fraktion, Stufe (eigene Tabellen und Umgebung eigener Funktionen; nie Blizzard)
-- frischer Charakter: nichts erledigt, leerer Questlog, nichts ignoriert (eigene Tabellen, danach zurück)
local function WithLage(race, class, level, body)
    local QDB, P, API = LP.QuestDB, LP.Planner, LP.API
    local oc, orb, oLevel, oDone = QDB.classBit, QDB.packRaceBit, LP.PlayerLevel, API.IsQuestDone
    local oTurned, oIgn, oNo = LP.char.turnedIn, LP.char.ignored, LP.char.notOffered
    local log = {}
    for k, v in pairs(P.inLog) do log[k] = v end
    return Guard(function()
        QDB.classBit, QDB.packRaceBit = LAGEN_CLASS_BITS[class], LAGEN_RACE_BITS[race.id]
        LP.PlayerLevel = function() return level end
        API.IsQuestDone = function() return false end
        LP.char.turnedIn, LP.char.ignored, LP.char.notOffered = {}, {}, {}
        wipe(P.inLog)
        return WithEnv({ LP.PlayerFaction }, { UnitFactionGroup = function() return race.f, race.f end }, body)
    end, function()
        QDB.classBit, QDB.packRaceBit, LP.PlayerLevel, API.IsQuestDone = oc, orb, oLevel, oDone
        LP.char.turnedIn, LP.char.ignored, LP.char.notOffered = oTurned, oIgn, oNo
        wipe(P.inLog)
        for k, v in pairs(log) do P.inLog[k] = v end
    end)
end

-- Quests nach Stufe vorsortieren (einmal je Lauf)
local levelIndex
local function LevelIndex()
    if levelIndex then return levelIndex end
    levelIndex = {}
    for _, id in ipairs(LP.QuestDB:AllIds()) do
        local info = LP.QuestDB:QuickInfo(id)
        local l = info and ((info.level or 0) > 0 and info.level or info.reqLevel) or 0
        if l and l > 0 and l <= 63 then
            levelIndex[l] = levelIndex[l] or {}
            local t = levelIndex[l]
            t[#t + 1] = id
        end
    end
    return levelIndex
end

IMPL.T269 = function()
    local P, QDB = LP.Planner, LP.QuestDB
    if not (_G.LevelPilotData and _G.LevelPilotData.version) then return NA, "kein Datenpaket" end
    local idx = LevelIndex()
    local lagen, bad, checked = 0, {}, 0
    local function fail(msg) if #bad < 8 then bad[#bad + 1] = msg end end
    local mineF = LP:PlayerFaction()
    -- Völker der eigenen Fraktion: Quests werden mit den Questgebern der eigenen Fraktion zwischengespeichert; die
    -- andere Fraktion prüft der Testlauf eines Charakters dieser Fraktion
    local other = 0
    for _, race in ipairs(LAGEN_RACES) do
        if race.f ~= mineF then other = other + #race.classes * #LAGEN_LEVELS end
        for _, class in ipairs(race.f == mineF and race.classes or {}) do
            for _, level in ipairs(LAGEN_LEVELS) do
                lagen = lagen + 1
                WithLage(race, class, level, function()
                    local avail, startHere = 0, 0
                    for l = math.max(1, level - 12), level + 3 do
                        for _, id in ipairs(idx[l] or {}) do
                            local q = QDB:Get(id)
                            if q and P:IsAvailable(q, level) then
                                avail = avail + 1
                                checked = checked + 1
                                -- Regeln je verfügbarer Quest
                                if q.faction and q.faction ~= (race.f == "Horde" and "H" or "A") then
                                    fail(("%s %s L%d: Quest %d der anderen Fraktion"):format(race.name, class, level, id))
                                end
                                if q.classes and q.classes ~= 0 and not LP.HasBit(q.classes, LAGEN_CLASS_BITS[class]) then
                                    fail(("%s %s L%d: Klassenquest %d einer anderen Klasse"):format(race.name, class, level, id))
                                end
                                if q.races and q.races ~= 0 and q.raceSys == "pack" and not LP.HasBit(q.races, LAGEN_RACE_BITS[race.id]) then
                                    fail(("%s %s L%d: Volksquest %d eines anderen Volks"):format(race.name, class, level, id))
                                end
                                if (q.reqLevel or 0) > level then
                                    fail(("%s %s L%d: Quest %d erst ab Stufe %d"):format(race.name, class, level, id, q.reqLevel))
                                end
                                if level == 1 then
                                    for _, st in ipairs(q.starts or {}) do if st[1] == race.start then startHere = startHere + 1 break end end
                                end
                            end
                        end
                    end
                    if level == 1 and startHere < 1 then
                        fail(("%s %s L1: nur %d Quests im Startgebiet %d"):format(race.name, class, startHere, race.start))
                    end
                    if level < 58 and avail == 0 then fail(("%s %s L%d: keine verfügbare Quest"):format(race.name, class, level)) end
                end)
            end
        end
    end
    -- Queststand: erledigt / im Log / abgebrochen / fehlgeschlagen an einer verfügbaren Quest der eigenen Lage
    local level = LP:PlayerLevel()
    local probe
    for l = math.max(1, level - 3), level + 2 do
        for _, id in ipairs(idx[l] or {}) do
            local q = QDB:Get(id)
            if q and P:IsAvailable(q, level) then probe = q break end
        end
        if probe then break end
    end
    local states = "keine verfügbare Quest"
    if probe then
        local id = probe.id
        local oldDone, oldLog = LP.char.turnedIn[id], P.inLog[id]
        Guard(function()
            LP.char.turnedIn[id] = LP:Now()
            local done = P:IsAvailable(probe, level)
            LP.char.turnedIn[id] = nil
            P.inLog[id] = { complete = false, objDone = {} }
            local inlog = P:IsAvailable(probe, level)
            P.inLog[id] = { complete = false, objDone = {}, failed = true }
            local failed = P:IsAvailable(probe, level)
            P.inLog[id] = nil
            local abandoned = P:IsAvailable(probe, level)
            states = ("erledigt %s, im Log %s, fehlgeschlagen %s, abgebrochen %s"):format(S(done), S(inlog), S(failed), S(abandoned))
            if done or inlog or failed or not abandoned then fail("Queststand " .. id .. ": " .. states) end
        end, function() LP.char.turnedIn[id], P.inLog[id] = oldDone, oldLog end)
    end
    return #bad == 0, ("%d Lagen (%s; %d Lagen der anderen Fraktion im Lauf mit deren Charakter), %d verfügbare Quests geprüft · %s%s"):format(lagen,
        mineF, other, checked, states,
        #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "keine Verletzung; erledigt/im Log/fehlgeschlagen false, abgebrochen true"
end

IMPL.T270 = function()
    local P, E = LP.Planner, LP.Engine
    local function keys()
        local out = {}
        for i, st in ipairs(E:Steps() or {}) do if i > 5 then break end out[#out + 1] = st.key end
        return table.concat(out, ",")
    end
    local bad = {}
    local mark, real = ActMark(), LP.Act.real
    local e0 = LP.errorCount
    -- 1) /reload unterwegs: Kandidaten und Plan neu aus den gespeicherten Daten -> gleicher Plan
    P:Replan(true)
    local before = keys()
    WithLoad(LevelPilotDB, LevelPilotCharDB, function()
        P:BuildCandidates()
        P:Replan(true)
    end)
    local after = keys()
    if before ~= after then bad[#bad + 1] = "nach /reload anderer Plan: " .. before .. " -> " .. after end
    -- 2) Plan wechseln: Normal -> Speedrun -> Normal ergibt wieder denselben Plan
    local mode = LP.char.mode
    Guard(function()
        P:SetMode(mode == "speed" and "normal" or "speed")
        P:Replan(true)
        P:SetMode(mode)
        P:Replan(true)
    end, function() LP.char.mode = mode end)
    local back = keys()
    if back ~= before then bad[#bad + 1] = "Modus hin und zurück: " .. before .. " -> " .. back end
    -- 3) Tod -> Geistheiler -> weiter: kein Fehler, der Schritt bleibt
    local cur = E:Current()
    local okDead = pcall(CallHandlers, "PLAYER_DEAD")
    local okAlive = pcall(CallHandlers, "PLAYER_UNGHOST")
    pcall(CallHandlers, "PLAYER_ALIVE")
    P:Replan(true)
    local cur2 = E:Current()
    if not okDead or not okAlive then bad[#bad + 1] = "Tod/Geistheiler mit Fehler" end
    if cur and cur2 and cur.key ~= cur2.key and not cur2.key:find("^DEATH") then
        bad[#bad + 1] = "nach dem Tod anderer Schritt: " .. tostring(cur.key) .. " -> " .. tostring(cur2.key)
    end
    -- 4) annehmen/abgeben automatisch: QUEST_COMPLETE mit 1 Belohnung -> GetQuestReward(1), mit 3 -> nichts
    local function complete(choices)
        local m = ActMark()
        local fake = { GetNumQuestChoices = function() return choices end, GetQuestItemLink = function() return nil end }
        local list = HandlerList("QUEST_COMPLETE")
        WithEnv(list, fake, function() WithSetting({ autoTurnin = true }, function() CallHandlers("QUEST_COMPLETE") end) end)
        local n, arg = 0, nil
        for i = m + 1, #LP.Act.log do
            local e = LP.Act.log[i]
            if e.name == "GetQuestReward" then n, arg = n + 1, e.a1 end
        end
        return n, arg
    end
    local n1, a1 = complete(1)
    local n3 = complete(3)
    if n1 ~= 1 or a1 ~= 1 then bad[#bad + 1] = ("1 Belohnung: %d× Index %s"):format(n1, S(a1)) end
    if n3 ~= 0 then bad[#bad + 1] = "3 Belohnungen: automatisch gewählt" end
    -- am Ende: nichts Echtes, keine Lua-Fehler
    local realActs = LP.Act.real - real
    local errs = LP.errorCount - e0
    if realActs ~= 0 then bad[#bad + 1] = "echte Aktionen " .. realActs end
    if errs ~= 0 then bad[#bad + 1] = "Lua-Fehler " .. errs end
    return #bad == 0, #bad == 0 and ("Plan nach /reload und Moduswechsel gleich (%s), Tod ohne Fehler, Belohnung 1 -> Index 1, 3 -> keine"):format(before)
        or table.concat(bad, "; "), "alles gleich, keine Fehler, nichts Echtes"
end

-- erwartete Standardwerte (was der Spieler ab Werk erwartet) – jede Abweichung ist ein FEHLER
local EXPECT_DEFAULTS = {
    autoAccept = true, autoTurnin = true, autoSellGrey = true, autoRepair = true, autoFly = true, restock = false,
    autoEquipRewards = false, showArrow = true, showEta = true, showTimer = true, recordPaths = true, recordQuests = true,
    shareGuild = true, shareGroup = true, shareChannel = true, shareSeed = false, compactMode = false, locked = false,
    safeMode = false, dungeons = true, language = "auto", questLogMax = 0, dungeonMobXP = 0, dungeonQuestXP = 0,
    speedLevel = 2, scale = 1.0, stepsShown = 5, summaryGuild = false, findPartners = true, groupSync = true,
    cmdHint = true, marktTeilen = true,
}
IMPL.T271 = function()
    return WithLoad({}, {}, function(acc)
        local list, bad = {}, {}
        local keys = {}
        for k, v in pairs(LP.DEFAULTS) do if type(v) ~= "table" then keys[#keys + 1] = k end end
        table.sort(keys)
        for _, k in ipairs(keys) do list[#list + 1] = k .. "=" .. tostring(acc[k]) end
        for k, v in pairs(EXPECT_DEFAULTS) do
            if acc[k] ~= v then bad[#bad + 1] = ("%s ist %s, soll %s"):format(k, tostring(acc[k]), tostring(v)) end
        end
        -- leere Felder: nil-Werte ab Werk (Fenstergrösse) führen nicht zu Fehlern beim Anzeigen
        local okUI = pcall(LP.UI.Refresh, LP.UI)
        if not okUI then bad[#bad + 1] = "Anzeige mit Werkseinstellungen wirft einen Fehler" end
        return #bad == 0, ("%d Optionen ab Werk: %s%s"):format(#keys, table.concat(list, ", "),
            #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "alle wie erwartet"
    end)
end

-- TU4: Grundregeln mit Zufallsfällen – läuft vor den Prüfungen in Portionen (TR:Invariants), T272 meldet
TR.INV_SEED = 1113
TR.INV_CASES = 1000
local PROTECTED_IN_COMBAT = { Sell = true, EquipItemByName = true, EquipItem = true, PickupContainerItem = true,
                              UseAction = true, BuyMerchantItem = true }
function TR:Invariants(yield)
    local seed = TR.INV_SEED
    local function rnd() seed = (seed * 1103515245 + 12345) % 2147483648 return seed / 2147483648 end
    local res = { n = 0, fails = {}, kinds = { weg = 0, belohnung = 0, zeit = 0, kampf = 0 }, seed = TR.INV_SEED }
    local function fail(kind, msg) if #res.fails < 10 then res.fails[#res.fails + 1] = kind .. ": " .. msg end end
    local P, Gr, Ter = LP.Planner, LP.Graph, LP.Terrain
    local pi, pn, pw, pmap = LP.Geo:Player()
    local cases = TR.INV_CASES
    local function case(k)
        local kind = k % 4
        if kind == 0 and pi and pmap then
            -- Weg: zufälliges Ziel bis 400 Yards; jedes Stück Luftlinie über Gelände, das die Geländekarte kennt,
            -- muss begehbar sein
            if k % 40 == 0 then
                local gn, gw = pn + (rnd() - 0.5) * 800, pw + (rnd() - 0.5) * 800
                local ok, p = pcall(Gr.Path, Gr, pi, pn, pw, pmap, pi, gn, gw, pmap, 2000)
                if ok and p then
                    for j = 2, #p do
                        local a, b = p[j - 1], p[j]
                        if a.map and a.map == b.map and Ter and Ter.Walkable and Ter:Available(a.map) then
                            local mx, my = ((a.x or 0) + (b.x or 0)) / 2, ((a.y or 0) + (b.y or 0)) / 2
                            if a.x and b.x and Ter:Walkable(a.map, mx, my) == false and not (a.known and b.known) then
                                fail("weg", ("Fall %d: Stück %.1f,%.1f -> %.1f,%.1f über unbegehbares Gelände (Karte %d)"):format(k, a.x, a.y, b.x, b.y, a.map))
                            end
                        end
                    end
                end
            end
            res.kinds.weg = res.kinds.weg + 1
        elseif kind == 1 then
            -- Belohnung: nie automatisch eine falsche (mehrere Wahlmöglichkeiten -> nie automatisch)
            local choices = math.floor(rnd() * 6)
            local auto = rnd() < 0.8
            local m = ActMark()
            local fake = { GetNumQuestChoices = function() return choices end, GetQuestItemLink = function() return nil end }
            WithEnv(HandlerList("QUEST_COMPLETE"), fake, function()
                WithSetting({ autoTurnin = auto }, function() pcall(CallHandlers, "QUEST_COMPLETE") end)
            end)
            for i = m + 1, #LP.Act.log do
                local e = LP.Act.log[i]
                if e.name == "GetQuestReward" then
                    if not auto then fail("belohnung", ("Fall %d: abgegeben, obwohl automatisch aus"):format(k)) end
                    if choices > 1 then fail("belohnung", ("Fall %d: bei %d Belohnungen automatisch gewählt"):format(k, choices)) end
                    if (e.a1 or 0) > choices then fail("belohnung", ("Fall %d: Index %s bei %d Belohnungen"):format(k, S(e.a1), choices)) end
                end
            end
            res.kinds.belohnung = res.kinds.belohnung + 1
        elseif kind == 2 then
            -- Zeiten: Schätzungen nie negativ, nie über 6 Stunden je Quest
            local ids = {}
            for id in pairs(P.inLog) do ids[#ids + 1] = id end
            if #ids > 0 then
                local id = ids[math.floor(rnd() * #ids) + 1]
                local ok, eta = pcall(LP.Session.QuestETA, LP.Session, id)
                if ok and eta and (eta < 0 or eta > 6 * 3600) then
                    fail("zeit", ("Fall %d: Quest %d geschätzt %d s"):format(k, id, math.floor(eta)))
                end
            end
            res.kinds.zeit = res.kinds.zeit + 1
        else
            -- Kampf: Händler und Belohnung im Kampf -> keine geschützte Aktion
            local m = ActMark()
            WithCombat(true, function()
                local ev = rnd() < 0.5 and "MERCHANT_SHOW" or "QUEST_COMPLETE"
                local fake = { GetNumQuestChoices = function() return 1 end, GetQuestItemLink = function() return nil end }
                WithEnv(HandlerList(ev), fake, function() pcall(CallHandlers, ev) end)
                if ev == "MERCHANT_SHOW" then pcall(CallHandlers, "MERCHANT_CLOSED") end
            end)
            for i = m + 1, #LP.Act.log do
                local e = LP.Act.log[i]
                if PROTECTED_IN_COMBAT[e.name] then fail("kampf", ("Fall %d: %s im Kampf"):format(k, e.name)) end
            end
            res.kinds.kampf = res.kinds.kampf + 1
        end
    end
    -- je Fall geschützt (ein Fehler ist eine Verletzung, kein Abbruch); abgegeben wird ausserhalb des pcall
    for k = 1, cases do
        local ok, err = pcall(case, k)
        if not ok then fail("fehler", ("Fall %d: %s"):format(k, tostring(err):sub(1, 80))) end
        res.n = res.n + 1
        if yield then yield() end
    end
    self.inv = res
    return res
end

IMPL.T272 = function()
    local r = TR.inv
    if not r then return NA, "Grundregeln nur in der ganzen Testroutine (Bereich J)" end
    local k = r.kinds
    return #r.fails == 0 and r.n >= 1000, ("%d Fälle (Startwert %d): Weg %d, Belohnung %d, Zeiten %d, Kampf %d%s"):format(r.n, r.seed,
        k.weg, k.belohnung, k.zeit, k.kampf, #r.fails > 0 and (" · VERLETZT: " .. table.concat(r.fails, "; ")) or ""),
        ">= 1000 Fälle, keine Verletzung"
end

-- TU6: jeder Befund seit dem 1.11. (auftraege/LevelPilot) mit seinem bleibenden Test
TR.REGRESSIONS = {
    { "korrektur-3.12.2 K1–K20", { "T174", "T175", "T176", "T177", "T178", "T179", "T180", "T181", "T182", "T183", "T184", "T185",
      "T186", "T187", "T188", "T189", "T190", "T191", "T192", "T193", "T194", "T195", "T196", "T197", "T198", "T199", "T200",
      "T201", "T202", "T203" } },
    { "Standardwerte mit Folgen (K Frage, A1, A2)", { "T204", "T206", "T207", "T208", "T209", "T210", "T211" } },
    { "Datenpaket nur in der gemeinsamen ZIP (R)", { "T205" } },
    { "3.12.5-1 Drop-Messung doppelt", { "T212" } },
    { "3.12.6-2 Berufszauber", { "T213" } },
    { "5.11. Mulgore: nahe Abgaben zuerst", { "T214" } },
    { "5.11. Linie übers Gebirge", { "T215" } },
    { "5.11. Protocol.lua:235 geschützte Zahl", { "T216" } },
    { "5.11. Thunder Bluff/Mulgore ein Fokus, PRIO, FEST", { "T217" } },
    { "Wegpunkte Punkt 1–6 Wegnetz statt Luftlinie", { "T218" } },
    { "Wegpunkte Punkt 7–9 FEST nur bei Laufzeit", { "T219" } },
    { "Wegpunkte Punkt 10 echte NPC-Orte", { "T220" } },
    { "Wegpunkte Punkt 11/13/14 Wegdaten GSWEGE1", { "T221" } },
    { "5.11. erst offene Quests der aktuellen Zone", { "T222" } },
    { "9.11. Session.lua:29 secret boolean (798×)", { "T223" } },
    { "Oberfläche (anweisung-testroutine-oberflaeche)", { "T224", "T225", "T226", "T227", "T228", "T229" } },
    { "Graue Items ohne Knopf", { "T230", "T231", "T232", "T233", "T234" } },
    { "Wegdaten a–e (Netz zerfällt, Punkte selten, Kontinent, npc old, NPC-Orte)", { "T235", "T236", "T237", "T238", "T239" } },
    { "Tooltips über den Knöpfen", { "T240" } },
    { "übrige geschützte Abfragen, T128, Fehlerzähler", { "T241", "T128" } },
    { "Kanal LevelPilotNet / gemeinsamer Sync 2 / Test 2", { "T108", "T242", "T243", "T244", "T245", "T246", "T247", "T248",
      "T249", "T250", "T251", "T252", "T253" } },
    { "keine Spielernamen", { "T165", "T251" } },
    { "Nachprüfung 3.12.21 Punkte 1–5", { "T254", "T243", "T255", "T256", "T257" } },
    { "Protokoll: SCHRITT/FOKUS/ZONE ruhig", { "T258" } },
    { "Nachprüfung 3.12.22: Z/E ohne Prüfsumme, grosse Wegelücken", { "T254", "T259", "T260" } },
    { "KRITISCH Lag beim Einloggen (T-LAG1–4)", { "T261", "T262", "T263", "T264", "T148" } },
    { "Nachprüfung 3.12.23: Sprung-Kanten, verwaister Knoten", { "T265" } },
    { "Nachprüfung 3.12.24 Punkte 1–6", { "T262", "T266", "T267", "T268" } },
    { "3.12.27: Schalter Befehlsliste auf derselben Stelle wie „nur für diesen Charakter“", { "T286" } },
    { "Nachprüfung 3.12.28 MK1 (feedUntil störte T283)", { "T287" } },
    { "Nachprüfung 3.12.28 GR1 (Quest 445 fertig, kein Abgabe-Schritt)", { "T288" } },
    { "Nachprüfung 3.12.28 SP1 (Speicher bis 125 MB, Messauftrag)", { "T289" } },
    { "ML1 Schalter „Meldungen“ (Wunsch des Nutzers 14.11.)", { "T290" } },
    { "Nachprüfung 3.12.30 PF-A (Planung Allianz 26 ms)", { "T150", "T291" } },
    { "Nachprüfung 3.12.31 LP-D1 (Questauswertung 495 ms nach dem Einloggen)", { "T292" } },
    { "Nachprüfung 3.12.30 GR1-K (Kompaktmodus: Später abgeben unsichtbar)", { "T293" } },
    { "L-1 Ruckler alle 5 Min. (UpdateAddOnMemoryUsage im Ticker)", { "T294" } },
    { "Nachprüfung 3.12.32 PF-A-Rest (Höchstwert 26 ms im ersten Lauf)", { "T295" } },
    { "UC-W1 Undercity „Weg unbekannt“ zum Lich-NPC (Bildschirmfotos 15.11.)", { "T296" } },
    { "W3D B1 Ebenen-Angabe mitschreiben (Supervisor 15.11. 20:15, nur speichern)", { "T297" } },
    { "Punkt 1/6 Koordinatenlisten Mulgore, Brachland, Donnerfels (anweisung-wegpunkte-strassen)", { "T298" } },
    { "W3D sprachfreier Ebenen-Schlüssel (Supervisor 15.11. 21:48/22:03)", { "T299" } },
    { "LP-N1 Wünsche der Spieler: Erholt-Bonus und Waffenfertigkeit (Supervisor 15.11. 22:33)", { "T300", "T301" } },
    { "LP-N1 4b Waffenmeister für neue Waffenarten (Supervisor 15.11. 22:49)", { "T302" } },
    { "LP-N1 3 Grind-Ausweichorte (Supervisor 15.11. 22:49/23:18)", { "T303" } },
    { "LP-N1 2 Schritt 1 Upgrades im Händlerfenster (Supervisor 15.11. 23:18)", { "T304" } },
    { "LP-N1 1 Talent-Empfehlung als Text (Supervisor 15.11. 23:18)", { "T305" } },
    { "Wunsch ProfessionSentinel: LevelPilotAPI.NavigateTo (Supervisor 15.11. 23:48)", { "T306" } },
    { "LP-N2 geführter Client-Test (Supervisor 16.11. 00:19)", { "T307" } },
    { "Geführte Wegmessung für GSWegMess (Supervisor 16.11. 00:48)", { "T308" } },
    { "Prüfliste im Spiel (Entscheid des Nutzers 16.11. 06:47, Supervisor 06:49)", { "T309" } },
    { "LW-6 Laufweg-Messung (Auftrag des Nutzers 16.11. 07:30, Supervisor 07:34)", { "T310" } },
    { "LW-3 Flug nach Zeit (Auftrag des Nutzers 16.11. 07:30, Supervisor 07:34)", { "T311" } },
    { "ST-2 Strassennetz aus den Spieldateien (Supervisor 16.11. 08:11)", { "T312" } },
    { "LW-1 Wegkosten statt Luftlinie (Auftrag des Nutzers 16.11. 07:30, Supervisor 07:34)", { "T313" } },
    { "NAV-1a /lp navi (Navigator, Entscheid des Nutzers 16.11. 07:55)", { "T314" } },
    { "LW-5 E2 Classic Era: Rückrechnung der Forever-Zonen (Entscheid des Nutzers 16.11. 10:08)", { "T315" } },
    { "LW-5 E3 Classic Era: Daten je Spielversion (Entscheid des Nutzers 16.11. 10:08)", { "T316" } },
    { "LW-5 E4 Classic Era: Forever-Eigenheiten je Spielversion (Entscheid des Nutzers 16.11. 10:08)", { "T317" } },
    { "NAV-2 Reiseplan nach Zeit (Entscheid des Nutzers 16.11. 07:55, Plan 09:54)", { "T318" } },
    { "NAV-1b Namenssuche mit Trefferliste (Entscheid des Nutzers 16.11. 07:55, Plan 09:54)", { "T319" } },
    { "NAV-1c Weltkarte: Markierung = Navi-Ziel (Entscheid des Nutzers 16.11. 07:55, Plan 09:54)", { "T320" } },
    { "LW-2a exakte Reihenfolge bis 8 Ziele (Auftrag des Nutzers 16.11. 07:30, Analyse Abschnitt 6 (3))", { "T321" } },
    { "NAV-3 Navi unterwegs: Gefahr, Ankunft (Entscheid des Nutzers 16.11. 07:55, Plan 09:54)", { "T322" } },
    { "NAV-4 Zusammenspiel: Route nutzt den Reiseplan, Schnittstelle für andere Addons (Entscheid des Nutzers 16.11. 07:55)", { "T323" } },
    { "LW-7a Rundgang über die Fundorte der Gegner (RestedXP-Vergleich, Bewertung 13:10)", { "T324" } },
    { "LW-5 E1/E5 Classic Era: .toc 16001+11509, Prüfliste Era (Supervisor 13:25, Messung Forever 13:39)", { "T325" } },
    { "LW-2b Zeitmodell im Normalmodus (Messreihe 18 Reisen, Supervisor 13:25 \"Code nur bei Beleg\")", { "T326" } },
}
IMPL.T273 = function()
    local known = {}
    for _, e in ipairs(TR.IDS) do known[e[1]] = true end
    local special = { T165 = true, T166 = true }        -- laufen am Ende der Routine (eigener Ablauf)
    local have, missing = 0, {}
    for _, r in ipairs(TR.REGRESSIONS) do
        local ok = #r[2] > 0
        for _, id in ipairs(r[2]) do
            if not known[id] or not (IMPL[id] or CLIENT[id] or SKIP[id] or special[id]) then ok = false end
        end
        if ok then have = have + 1 else missing[#missing + 1] = r[1] end
    end
    TR.regressionLine = ("Regressionen: %d von %d vorhanden"):format(have, #TR.REGRESSIONS)
    return #missing == 0, TR.regressionLine .. (#missing > 0 and (" · fehlt: " .. table.concat(missing, "; ")) or ""), "alle vorhanden"
end

IMPL.T274 = function()
    local Pr = LP.Protocol
    if not Pr.CheckRules then return false, "Protocol.CheckRules fehlt", "vorhanden" end
    local v, checked = Pr:CheckRules(true)
    return #v == 0, ("%d Questlog-Einträge und Messwerte geprüft%s"):format(checked, #v > 0 and (" · " .. table.concat(v, "; ")) or ""),
        "keine Grundregel verletzt"
end
CLIENT.T274 = "Nach einer Spielsitzung /lp diag: keine Zeile „GRUNDREGEL VERLETZT“ (oder Fall melden)"

IMPL.T275 = function()
    local bad, done = {}, {}
    local P, UI = LP.Planner, LP.UI
    for _, fl in ipairs({ "forever", "era", "tbc" }) do
        local ok, err = pcall(WithFlavor, fl, function()
            P:BuildCandidates()
            P:Replan(true)
            UI:Refresh()
            return true
        end)
        if ok then done[#done + 1] = fl else bad[#bad + 1] = fl .. ": " .. tostring(err):sub(1, 60) end
    end
    pcall(P.BuildCandidates, P) pcall(P.Replan, P, true)
    -- Sprachen: Texte des aktuellen Schritts in deDE und enUS ohne Platzhalter-Fehler
    local lang0 = LP.db.language
    for _, code in ipairs({ "de", "en" }) do
        local ok, err = pcall(function()
            LP.db.language = code
            LP:ResetLanguageCache()
            UI:Refresh()
            local cur = LP.Engine:Current()
            if cur and UI.StepText then UI:StepText(cur) end
        end)
        if ok then done[#done + 1] = code else bad[#bad + 1] = code .. ": " .. tostring(err):sub(1, 60) end
    end
    LP.db.language = lang0
    LP:ResetLanguageCache()
    -- Fenster bei Skalierung 80 %: ganz im Bildschirm (Oberflächenprüfung, nur im echten Client)
    local f = _G.LevelPilotFrame
    if f and f.GetScale and LP.UICheck and LP.UICheck.Available() then
        local sc = f:GetScale()
        local ok = pcall(function()
            f:SetScale(sc * 0.8)
            local out = LP.UICheck.InsideScreen and LP.UICheck.InsideScreen() or {}
            if type(out) == "table" and #out > 0 then bad[#bad + 1] = "80 %: ausserhalb " .. #out end
        end)
        f:SetScale(sc)
        done[#done + 1] = ok and "80 %" or "80 % Fehler"
    end
    UI:Refresh()
    return #bad == 0, ("geprüft: %s%s"):format(table.concat(done, ", "), #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""),
        "forever, era, tbc, de, en ohne Fehler"
end

------------------------------------------------------------------------
-- 3.12.27: Befehlsliste beim Tippen (T-BL1–T-BL6)
------------------------------------------------------------------------
local function WithHint(dev, body)
    local H = LP.CmdHint
    local oDev, oSel, oStore = H.dev, H.selected, H.store
    local uses = {}
    return Guard(function()
        H.dev = function() return dev end
        H.store = function() return uses end
        H.selected = nil
        return body(H)
    end, function() H.dev, H.selected, H.store = oDev, oSel, oStore end)
end
local function Keys(list) local t = {} for _, it in ipairs(list) do t[it.key] = true end return t end

IMPL.T276 = function()
    if not (LP.CmdHint and LP.COMMANDS and LP.FindCommand) then return false, "CmdHint/COMMANDS fehlt", "vorhanden" end
    return WithHint(true, function(H)
        local listed = Keys(H:List(""))
        local missing, wrong = {}, {}
        for _, c in ipairs(LP.COMMANDS) do
            if c[1] ~= "" then
                if not listed[H.Base(c)] then missing[#missing + 1] = c[1] end
                -- jedes Wort, das der Handler versteht, findet genau diesen Eintrag
                for _, w in ipairs(c.words or { c[1], c[2] }) do
                    local msg = w .. (c.args and " x" or "")
                    if LP:FindCommand(msg) ~= c then wrong[#wrong + 1] = msg end
                end
            end
        end
        -- Befehle vor 3.12.27 (Rückwärts-Prüfung): alle finden einen Eintrag
        local old = { "zentrale", "center", "speed", "speedrun", "normal", "modus", "mode", "weg 45 60", "way 45 60", "suche gasthaus",
            "find inn", "sprache de", "lang en", "teilen", "share", "gruppe", "lfg", "bilanz", "bilanz gilde", "summary", "kompakt",
            "compact", "wege", "ways", "protokoll", "protokoll leer", "log", "testroutine a", "test", "selbsttest", "messen", "measure",
            "test reise", "reise", "reise stopp", "journey", "grau", "grey", "gray", "junk", "spenden", "donate", "support", "zurück",
            "zurueck", "undo", "plan", "sync test", "sync", "diag", "diagnose", "debug", "reset" }
        for _, m in ipairs(old) do if not LP:FindCommand(m) then wrong[#wrong + 1] = m end end
        return #missing == 0 and #wrong == 0, ("%d Befehle in der Tabelle, fehlen in der Liste: %s · falsch zugeordnet: %s"):format(#LP.COMMANDS - 1,
            #missing > 0 and table.concat(missing, ", ") or "keine", #wrong > 0 and table.concat(wrong, ", ") or "keine"), "keine, keine"
    end)
end

IMPL.T277 = function()
    return WithHint(true, function(H)
        local function expect(prefix)
            local t = {}
            for _, c in ipairs(LP.COMMANDS) do
                if c[1] ~= "" and (c[1]:lower():sub(1, #prefix) == prefix or c[2]:lower():sub(1, #prefix) == prefix) then t[H.Base(c)] = true end
            end
            return t
        end
        local bad = {}
        for _, pfx in ipairs({ "w", "we", "s", "test", "" }) do
            local got, want = Keys(H:List(pfx)), expect(pfx)
            for k in pairs(want) do if not got[k] then bad[#bad + 1] = pfx .. ": fehlt " .. k end end
            for k in pairs(got) do if not want[k] then bad[#bad + 1] = pfx .. ": zu viel " .. k end end
        end
        local w = {}
        for _, it in ipairs(H:List("we")) do w[#w + 1] = it.key end
        table.sort(w)
        local m = H:Match("/lp we")
        return #bad == 0 and m == "we", ("/lp we -> %s (Rest %s)%s"):format(table.concat(w, ", "), S(m), #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""),
            "genau die passenden"
    end)
end

IMPL.T278 = function()
    return WithHint(true, function(H)
        local plan
        for _, it in ipairs(H:List("pl")) do if it.key == "plan" then plan = it end end
        if not plan then return false, "Eintrag plan fehlt", "vorhanden" end
        H:Select(plan, true)
        local resolved = H:Resolve("pl")              -- unvollständiges Wort + frische Auswahl -> plan
        H:Select(plan, true)
        H.selected.t = H.selected.t - 11              -- abgelaufen
        local stale = H:Resolve("pl")
        -- Enter: Slash-Handler führt die Auswahl aus
        local ran = 0
        H:Select(plan, true)
        WithCounter(LP.Planner, "Replan", function(n)
            SlashCmdList.LEVELPILOT("pl")
            ran = n()
        end)
        return resolved == "plan" and stale == "pl" and ran >= 1,
            ("Auswahl -> %s, nach 11 s -> %s, Enter führte aus %d×"):format(S(resolved), S(stale), ran), "plan, pl, >= 1"
    end)
end

IMPL.T279 = function()
    local H = LP.CmdHint
    local writes, hooks, scripts = 0, {}, 0
    local text = "/lp w"
    local box = {
        HookScript = function(_, ev, fn) hooks[ev] = fn end,
        SetScript = function() scripts = scripts + 1 end,
        SetText = function() writes = writes + 1 end, Insert = function() writes = writes + 1 end,
        GetText = function() return text end, GetWidth = function() return 300 end,
        IsShown = function() return true end, SetFocus = function() end,
    }
    local oInstant = H.instantClose
    return Guard(function()
        H.instantClose = true
        H:HookBox(box)
        if hooks.OnTextChanged then hooks.OnTextChanged(box) end
        local shown = H.frame and H.frame:IsShown()
        if hooks.OnTabPressed then hooks.OnTabPressed(box) end
        local selected = H:Selection() ~= nil
        if hooks.OnEditFocusLost then hooks.OnEditFocusLost(box) end
        text = "hallo"
        if hooks.OnTextChanged then hooks.OnTextChanged(box) end
        local hidden = not (H.frame and H.frame:IsShown())
        return writes == 0 and scripts == 0 and shown and selected and hidden,
            ("Liste gezeigt %s, Tab wählt %s, geschlossen %s · ins Chatfeld geschrieben %d×, SetScript %d×"):format(S(shown), S(selected),
                S(hidden), writes, scripts), "true, true, true · 0, 0"
    end, function() H.instantClose = oInstant H.selected = nil H:Hide() if H.hooked then H.hooked[box] = nil end end)
end

IMPL.T280 = function()
    local function devCount(dev)
        return WithHint(dev, function(H)
            local n = 0
            for _, it in ipairs(H:List("")) do
                for _, c in ipairs(LP.COMMANDS) do if c.dev and H.Base(c) == it.key then n = n + 1 end end
            end
            return n
        end)
    end
    local total = 0
    for _, c in ipairs(LP.COMMANDS) do if c.dev then total = total + 1 end end
    local a, b = devCount(false), devCount(true)
    return a == 0 and b == total and total > 0, ("ohne Entwickler %d, mit Entwickler %d von %d"):format(a, b, total), "0, alle"
end

IMPL.T281 = function()
    local lang0 = LP.db.language
    local bad, langs = {}, 0
    for _, code in ipairs({ "en", "fr", "es", "it", "pt", "ru", "ko", "cn", "tw" }) do
        LP.db.language = code
        LP:ResetLanguageCache()
        langs = langs + 1
        for _, c in ipairs(LP.COMMANDS) do
            local t = LP.L[c[3]]
            if type(t) ~= "string" or t == "" or t == c[3] then bad[#bad + 1] = code .. ": " .. c[3] break end
        end
        local ok, txt = pcall(string.format, LP.L["Enter = %s"], "/lp plan")
        if not ok or not txt:find("/lp plan", 1, true) then bad[#bad + 1] = code .. ": Enter = %s" end
    end
    LP.db.language = lang0
    LP:ResetLanguageCache()
    return #bad == 0, ("%d Sprachen%s"):format(langs, #bad > 0 and (" · fehlt: " .. table.concat(bad, "; ")) or ", alle Beschreibungen übersetzt"),
        "alle übersetzt"
end

------------------------------------------------------------------------
-- 3.12.28: Marktdaten-Netz (MN1–MN4). Ersetzt wird nur GoldSentinelMarkt.api und der eigene Zustand der Datei
-- (Hosts, Zähler, Zeitpunkte) – nie eine Blizzard-Funktion. Alles wird danach zurückgestellt.
------------------------------------------------------------------------
local function GMk() return _G.GoldSentinelMarkt end

-- Zustand der gemeinsamen Datei sichern, Test-Hosts und Test-API setzen, danach alles zurück
local function WithMarkt(api, body)
    local GM = GMk()
    if type(GM) ~= "table" then return NA end
    local keep = {}
    for _, k in ipairs({ "api", "hosts", "store", "lastEv", "readAt", "reader", "askAt", "answerAt", "answerT", "outbox", "prev", "feedUntil" }) do
        keep[k] = { GM[k] }
    end
    local st = GM.stats or {}
    local stCopy, drCopy = {}, {}
    for k, v in pairs(st) do if k ~= "dropped" then stCopy[k] = v end end
    for k, v in pairs(st.dropped or {}) do drCopy[k] = v end
    local marktDB = LP.marktDB
    local fakeApi = {}
    for k, v in pairs(GM.api or {}) do fakeApi[k] = v end
    for k, v in pairs(api or {}) do fakeApi[k] = v end
    local testDB = {}
    GM.api = fakeApi
    GM.hosts = {}
    GM.store = nil
    GM.lastEv, GM.readAt, GM.reader, GM.askAt, GM.answerAt, GM.prev = nil, nil, nil, nil, nil, nil
    GM.feedUntil = nil   -- 3.12.29 MK1: ein laufender Vollscan eines anderen Addons (FeedStart) darf den Test nicht stören
    GM.outbox = {}
    GM.Attach("LevelPilot", testDB)
    GM.askAt = nil
    LP.marktDB = testDB
    return Guard(function() return body(GM, testDB) end, function()
        for k, v in pairs(keep) do GM[k] = v[1] end
        if GM.stats then
            for k in pairs(GM.stats) do if k ~= "dropped" then GM.stats[k] = nil end end
            for k, v in pairs(stCopy) do GM.stats[k] = v end
            GM.stats.dropped = GM.stats.dropped or {}
            for k in pairs(GM.stats.dropped) do GM.stats.dropped[k] = nil end
            for k, v in pairs(drCopy) do GM.stats.dropped[k] = v end
        end
        LP.marktDB = marktDB
        pcall(LP.MarktSync, LP)
    end)
end

-- nachgebautes Auktionshaus mit drei Auktionen (keine Namen)
local function FakeAH(reads)
    local rows = { { 2589, 5, 500 }, { 2589, 10, 900 }, { 2592, 1, 120 } }
    return {
        GetNumReplicateItems = function() return #rows end,
        GetReplicateItemInfo = function(i)
            reads[1] = reads[1] + 1
            local r = rows[i + 1]
            if not r then return nil end
            return nil, nil, r[2], nil, nil, nil, nil, nil, nil, r[3], nil, nil, nil, nil, nil, nil, r[1]
        end,
        GetReplicateItemTimeLeft = function() return 4 end,
    }
end

local function MarktApi(clock, ah)
    return {
        now = function() return clock[1] end,
        time = function() return 1800000000 + math.floor(clock[1]) end,
        ms = function() return clock[1] * 1000 end,
        inCombat = function() return false end,
        ah = function() return ah end,
        faction = function() return "H" end,
        random = function() return 1 end,
        ahs = function() return false end,   -- 3.12.29 (GoldSentinelMarkt v2): Test unabhängig davon, ob AHSentinel geladen ist
    }
end

IMPL.T282 = function()
    local GM = GMk()
    local with = type(GM) == "table" and (tonumber(GM.VERSION) or 0) >= 1 and GM.hosts and GM.hosts.LevelPilot == LevelPilotDB
        and type(LevelPilotDB.gsMarkt) == "table"
    -- ohne die Datei: dieselben Funktionen mit einer Umgebung, in der GoldSentinelMarkt fehlt
    local okA, attached, okL, line
    WithEnv({ LP.MarktAttach, LP.MarktSync, LP.MarktLine }, { GoldSentinelMarkt = false }, function()
        okA, attached = pcall(LP.MarktAttach, LP, {})
        pcall(LP.MarktSync, LP)
        okL, line = pcall(LP.MarktLine, LP)
    end)
    local without = okA and attached == false and okL and line == "MARKT-NETZ: Datei fehlt"
    return with and without and true or false,
        ("mit Datei: angemeldet %s (v%s) · ohne Datei: Fehler %s, angemeldet %s, Zeile „%s“"):format(S(with),
            S(type(GM) == "table" and GM.VERSION), S(not okA), S(attached), S(line)),
        "true · false, false, MARKT-NETZ: Datei fehlt"
end

IMPL.T283 = function()
    local clock, reads = { 1000 }, { 0 }
    local ah = FakeAH(reads)
    return WithMarkt(MarktApi(clock, ah), function(GM, db)
        -- Gegenprobe an: ein Scan-Ereignis merkt das Lesen vor
        LP:MarktSync()
        GM.OnReplicate()
        local onPlanned = GM.readAt ~= nil
        GM.readAt, GM.lastEv = nil, nil
        -- Schalter aus (wie in der Zentrale)
        local sent0, acc0 = GM.stats.sent, GM.stats.accepted
        local out = WithSetting({ marktTeilen = false }, function()
            LP:MarktSync()
            local shareOff = GM.IsShareOn() == false and db.gsMarktAus == true
            clock[1] = clock[1] + 100
            GM.OnReplicate()
            local planned = GM.readAt ~= nil or GM.reader ~= nil
            GM.OnMessage("S:H:" .. GM.Enc(1800000000) .. ":" .. GM.Enc(2589) .. ",1k,5,1", "x")
            local accepted = GM.stats.accepted - acc0
            GM.Pump()
            return { shareOff, planned, accepted, GM.stats.sent - sent0, #GM.outbox }
        end)
        LP:MarktSync()
        local backOn = GM.IsShareOn()
        local ok = onPlanned and out[1] and not out[2] and out[3] == 0 and out[4] == 0 and out[5] == 0 and reads[1] == 0 and backOn
        return ok, ("an: Lesen vorgemerkt %s · aus: Schalter %s, Lesen vorgemerkt %s, gelesen %d, angenommen %d, gesendet %d, Warteschlange %d · wieder an %s")
            :format(S(onPlanned), S(out[1]), S(out[2]), reads[1], out[3], out[4], out[5], S(backOn)),
            "true · true, false, 0, 0, 0, 0 · true"
    end)
end

-- T-MK1: echter Wert wie bei AHSentinel FeedStart (Uhr + 300), dazu "AHSentinel geladen" in der echten api
IMPL.T287 = function()
    local GM = GMk()
    if type(GM) ~= "table" or type(GM.api) ~= "table" or type(GM.api.now) ~= "function" then return NA end
    local keepFeed, keepApi = GM.feedUntil, GM.api
    local fake = {}
    for k, v in pairs(GM.api) do fake[k] = v end
    fake.ahs = function() return true end
    local okRun, a, b
    Guard(function()
        GM.feedUntil = GM.api.now() + 300
        GM.api = fake
        okRun, a, b = pcall(IMPL.T283)
    end, function() GM.feedUntil, GM.api = keepFeed, keepApi end)
    local restored = GM.feedUntil == keepFeed and GM.api == keepApi
    return okRun and a == true and restored,
        ("T283 mit feedUntil = Uhr + 300 und AHSentinel geladen: %s (%s) · Zustand zurück %s"):format(S(okRun and a), S(b), S(restored)),
        "true (… Lesen vorgemerkt true …) · true"
end

IMPL.T284 = function()
    local clock = { 2000 }
    return WithMarkt(MarktApi(clock, nil), function(GM)
        LP:MarktSync()
        local errs = {}
        local function try(name, f, ...) local ok, e = pcall(f, ...) if not ok then errs[#errs + 1] = name .. ": " .. tostring(e) end end
        try("OnReplicate", GM.OnReplicate)
        clock[1] = clock[1] + 10
        local scans0 = GM.stats.scans
        try("Tick", GM.Tick)
        try("Get", GM.Get, 2589)
        try("DiagLines", GM.DiagLines)
        local okL, line = pcall(LP.MarktLine, LP)
        if not okL then errs[#errs + 1] = "MarktLine: " .. tostring(line) end
        local ok = #errs == 0 and GM.reader == nil and GM.stats.scans == scans0 and okL and line:find("ohne AH-API", 1, true) ~= nil
        return ok, ("Fehler %d%s · gelesen %s · Zeile „%s“"):format(#errs, #errs > 0 and (" (" .. errs[1] .. ")") or "",
            S(GM.reader ~= nil or GM.stats.scans ~= scans0), S(line)), "0 · false · … ohne AH-API …"
    end)
end

IMPL.T285 = function()
    local okL, line = pcall(LP.MarktLine, LP)
    local need = { "MARKT-NETZ: v", "Scans mitgelesen", "gesendet", "empfangen", "Speicher" }
    local miss = {}
    for _, w in ipairs(need) do if not (okL and line:find(w, 1, true)) then miss[#miss + 1] = w end end
    local okT, txt = pcall(LP.Protocol.Text, LP.Protocol)
    local inDiag = okT and type(txt) == "string" and txt:find("MARKT-NETZ", 1, true) ~= nil
    local toggle = WithCenter(function()
        for _, t in ipairs((LP.Center and LP.Center.toggles) or {}) do if t.key == "marktTeilen" then return true end end
        return false
    end)
    local def = LP.DEFAULTS and LP.DEFAULTS.marktTeilen == true
    local lbl = LP.L["Marktdaten teilen (anonym, nur Preise)"]
    return #miss == 0 and inDiag and toggle and def and type(lbl) == "string" and lbl ~= "",
        ("Zeile „%s“%s · Diagnose %s · Schalter %s · Standard an %s"):format(S(line), #miss > 0 and (" fehlt: " .. table.concat(miss, ", ")) or "",
            S(inDiag), S(toggle), S(def)), "alle Teile, true, true, true"
end

IMPL.T286 = function() return WithCenter(function()
    local Ce = LP.Center
    if not (Ce and Ce.toggles) or #Ce.toggles == 0 then return NA end
    local seen, dup = {}, {}
    for _, t in ipairs(Ce.toggles) do
        if t.parent and t.x and t.y then
            local k = tostring(t.parent) .. ":" .. t.x .. ":" .. t.y
            if seen[k] then dup[#dup + 1] = seen[k] .. " / " .. t.key else seen[k] = t.key end
        end
    end
    return #dup == 0, ("%d Schalter%s"):format(#Ce.toggles, #dup > 0 and (" · gleiche Stelle: " .. table.concat(dup, "; ")) or ", jeder an eigener Stelle"),
        "keine doppelte Stelle"
end) end

------------------------------------------------------------------------
-- 3.12.30 GR1: echte Lage aus der Diagnose 3.12.27 – Priester L10 in Undercity (1458), Fokus Tirisfal (1420),
-- aktueller Schritt TURNIN:405; Quest 445 "Lieferung in den Silberwald" fertig, Abgabe NPC 1937 im Silberwald (1421).
------------------------------------------------------------------------
IMPL.T288 = function()
    local P, QDB, Pr, Geo = LP.Planner, LP.QuestDB, LP.Protocol, LP.Geo
    local q445, q405 = QDB:Get(445), QDB:Get(405)
    if not (q445 and q445.ends and #q445.ends > 0 and q405) then return NA, "Quest 445/405 nicht in den Daten" end
    if LP.Virtual and LP.Virtual.active then return NA end
    local e1 = q445.ends[1]
    local endMap = type(e1) == "table" and e1[1]
    local ui, un, uw = Geo:ToWorld(1458, 60, 50)
    if not ui then return NA, "Undercity-Karte nicht verfügbar" end
    local log = {}
    for k, v in pairs(P.inLog) do log[k] = v end
    local savedSteps, savedIgn, savedPrint, savedShown = P.steps, LP.char.ignored, LP.Print, LP.db.stepsShown
    local doneBefore = 0
    for _ in pairs(LP.char.doneKeys) do doneBefore = doneBefore + 1 end
    return Guard(function()
        LP.char.ignored = {}
        wipe(P.inLog)
        P.inLog[445] = { complete = true, title = q445.name or "Quest 445", objDone = {}, index = 1 }
        P.inLog[405] = { complete = true, title = q405.name or "Quest 405", objDone = {}, index = 2 }
        local tasks = P:CollectTasks(ui, un, uw, 10)
        local t445
        for _, t in ipairs(tasks) do if t.t == "TURNIN" and t.id == 445 then t445 = t end end
        -- so wie in der Diagnose: nur die Abgabe 405 ist Schritt (445 liegt ausserhalb von Fokus, Nähe und Zone)
        local steps = { { t = "TURNIN", id = 405, key = "TURNIN:405", q = q405.name, map = 1458 } }
        P.steps = steps
        local function Viol()
            local v = Pr:CheckRules(true)
            for _, m in ipairs(v) do if m:find("Quest 445 ", 1, true) then return true end end
            return false
        end
        local before = Viol()                       -- Gegenprobe: ohne Hinweis meldet die Grundregel 445
        LP.db.stepsShown = 5
        local note = P:LaterTurnins(steps, tasks)
        local after = Viol()
        local pos
        for i, st in ipairs(steps) do if st == note then pos = i end end
        local zone = endMap and Geo:MapName(endMap) or ""
        local text = note and note.text or ""
        local named = text:find(q445.name or "Quest 445", 1, true) ~= nil and (zone == "" or text:find(zone, 1, true) ~= nil)
        local only445 = note and #note.laterIds == 1 and note.laterIds[1] == 445
        -- Überspringen / Zurückstellen entfernt den Hinweis nicht und schreibt nichts in den Charakter
        LP.Print = function() end
        LP.Engine:Skip(note)
        LP.Engine:Later(note)
        local doneAfter = 0
        for _ in pairs(LP.char.doneKeys) do doneAfter = doneAfter + 1 end
        local kept = not LP.char.ignored[445] and doneAfter == doneBefore and not LP.Engine.later[note and note.key or ""]
        -- viele Schritte: der Hinweis steht in der letzten angezeigten Zeile
        local many = {}
        for k = 1, 9 do many[k] = { t = "COMPLETE", id = 900000 + k, key = "COMPLETE:" .. (900000 + k) } end
        local n2 = P:LaterTurnins(many, tasks)
        local visible = n2 and many[5] == n2
        local ok = before and note and not after and pos == 2 and named and only445 and kept and visible
        return ok and true or false,
            ("ohne Hinweis Grundregel %s · Hinweis %s an Stelle %s: „%s“ · mit Hinweis Grundregel %s · Abgabe-Aufgabe 445 %s (Karte %s) · Überspringen/Zurückstellen lässt ihn stehen %s · bei 10 Schritten Zeile 5 %s")
                :format(before and "meldet 445" or "still", S(note ~= nil), S(pos), text, after and "meldet 445" or "still",
                    S(t445 ~= nil), S(t445 and t445.map or endMap), S(kept), S(visible)),
            "meldet 445 · true an Stelle 2 (Quest + Silberwald) · still · … · true · true"
    end, function()
        wipe(P.inLog)
        for k, v in pairs(log) do P.inLog[k] = v end
        P.steps, LP.char.ignored, LP.Print, LP.db.stepsShown = savedSteps, savedIgn, savedPrint, savedShown
    end)
end

-- 3.12.30 SP1: Messung des Speichers (keine volle Müllabfuhr). Ersetzt wird nur LP.Perf.mem (eigene Funktion).
IMPL.T289 = function()
    local Perf, P, G, Q, D = LP.Perf, LP.Planner, LP.Graph, LP.QuestDB, LP.Danger
    if not (Perf and Perf.MemLines and G.CacheSizes and Q.CacheSize and D.CacheSize) then return false, "Messung fehlt", "vorhanden" end
    -- a) angelegter Speicher je Aufruf: 100 -> 150 KB zählt 50, fällt der Wert (Müllabfuhr lief) zählt 0
    local savedMem, savedStat = Perf.mem, Perf.stats.t289
    local seq, i = { 100, 150, 150, 90 }, 0
    local a = Guard(function()
        Perf.stats.t289 = nil
        Perf.mem = function() i = i + 1 return seq[i] or 0 end
        Perf.Run("t289", "t289", false, function() end)
        Perf.Run("t289", "t289", false, function() end)
        return Perf.stats.t289 and Perf.stats.t289.kb or -1
    end, function() Perf.mem, Perf.stats.t289 = savedMem, savedStat end)
    -- b) Zeilen in der Diagnose
    local okT, txt = pcall(LP.Protocol.Text, LP.Protocol)
    local diag = okT and type(txt) == "string" and txt:find("SPEICHER Lua gesamt", 1, true) ~= nil
        and txt:find("SPEICHER angelegt je Modul", 1, true) ~= nil and txt:find("SPEICHER Bestand", 1, true) ~= nil
    -- c) Bestand: 10 Neuplanungen am selben Ort lassen die Zwischenspeicher nicht weiter wachsen
    local function Sizes() local v, u = G:CacheSizes() return { v, u, D:CacheSize(), Q:CacheSize() } end
    local grow = {}
    if not (LP.Virtual and LP.Virtual.active) and LP.Geo:Player() then
        pcall(P.DoReplan, P)
        local s1 = Sizes()
        for _ = 1, 10 do pcall(P.DoReplan, P) end
        local s2 = Sizes()
        local names = { "Luftlinien-Nachbarn", "Geländeprüfungen", "Gefahren-Strecken", "Quests entschlüsselt" }
        for k = 1, 4 do if s2[k] > s1[k] then grow[#grow + 1] = ("%s %d->%d"):format(names[k], s1[k], s2[k]) end end
    end
    local ok = a == 50 and diag and #grow == 0
    return ok, ("angelegt gezählt %s KB (soll 50) · Diagnose-Zeilen %s · Zuwachs nach 10 Neuplanungen: %s"):format(S(a), S(diag),
        #grow > 0 and table.concat(grow, ", ") or "keiner"), "50 · true · keiner"
end

-- 3.12.31 ML1: Schalter "Meldungen". Ersetzt wird nur LP.sink (eigene Tabelle) – keine Blizzard-Funktion.
IMPL.T290 = function()
    local A, UI = LP.Advisor, LP.UI
    local cnt = { chat = 0, screen = 0, sound = 0 }
    local fake = {
        chat = function() cnt.chat = cnt.chat + 1 end,
        screen = function() cnt.screen = cnt.screen + 1 end,
        sound = function() cnt.sound = cnt.sound + 1 end,
    }
    local savedSink, st = LP.sink, LP.msgStats
    local sup0, leak0 = st.suppressed, st.leaked
    local savedHints = A and A.hints
    local function Reset() cnt.chat, cnt.screen, cnt.sound = 0, 0, 0 end
    return Guard(function()
        LP.sink = fake
        local r = {}
        -- AUS: ungefragte Meldungen auf allen Wegen
        WithSetting({ messages = false }, function()
            LP:Print("t290")
            LP:Screen("t290", 1, 1, 1, 3175)
            local sup1 = st.suppressed
            if UI and UI.toastAnchor then UI:Toast({ key = "t290", sev = 1, text = "t290" }) end
            r.toastSup = (not (UI and UI.toastAnchor)) or st.suppressed > sup1
            if A and A.Run then A:Run() end
            r.hints = #(A and A.hints or {})
            r.off = { cnt.chat, cnt.screen, cnt.sound }
            -- Ausnahmen 1 und 2: Antwort auf eigene Handlung und Ausgabe während eines Befehls bleiben
            Reset()
            LP:Reply("t290")
            LP:AsReply(function() LP:Print("t290") LP:Screen("t290", 1, 1, 1) end)
            r.reply = { cnt.chat, cnt.screen }
            r.leakOff = st.leaked - leak0
            -- absichtlich falscher Fall: Ausgabe am Schalter vorbei wird erkannt
            Reset()
            LP.out.chat("t290 am Schalter vorbei")
            r.bypass = st.leaked - leak0
        end)
        st.leaked = leak0
        -- AN: unverändert
        Reset()
        WithSetting({ messages = true }, function()
            LP:Print("t290")
            LP:Screen("t290", 1, 1, 1, 3175)
            r.on = { cnt.chat, cnt.screen, cnt.sound }
        end)
        local okLine, line = pcall(LP.MessagesLine, LP)
        local toggle = WithCenter(function()
            for _, t in ipairs((LP.Center and LP.Center.toggles) or {}) do if t.key == "messages" then return true end end
            return false
        end)
        local def = LP.DEFAULTS and LP.DEFAULTS.messages == true
        local ok = r.off[1] == 0 and r.off[2] == 0 and r.off[3] == 0 and r.toastSup and r.hints == 0
            and r.reply[1] == 2 and r.reply[2] == 1 and r.leakOff == 0 and r.bypass == 1
            and r.on[1] == 1 and r.on[2] == 1 and r.on[3] == 1 and okLine and line == LP.L("MELDUNGEN: %s · unterdrückt %d · durchgerutscht %d", LP:MessagesOn() and LP.L["an"] or LP.L["aus"], st.suppressed, st.leaked)
            and toggle and def
        return ok, ("AUS: Chat %d, Mitte %d, Ton %d, Toast unterdrückt %s, Assistent-Hinweise %d · Antworten Chat %d, Mitte %d · durchgerutscht %d · am Schalter vorbei erkannt %d · AN: Chat %d, Mitte %d, Ton %d · Schalter %s, Standard an %s")
            :format(r.off[1], r.off[2], r.off[3], S(r.toastSup), r.hints, r.reply[1], r.reply[2], r.leakOff, r.bypass,
                r.on[1], r.on[2], r.on[3], S(toggle), S(def)),
            "AUS 0/0/0, true, 0 · 2, 1 · 0 · 1 · AN 1/1/1 · true, true"
    end, function()
        LP.sink = savedSink
        st.suppressed, st.leaked = sup0, leak0
        if A then
            A.hints = savedHints
            if A.Run then pcall(A.Run, A) end
        end
    end)
end

-- 3.12.32 PF-A: Danger:Route wurde schneller (ohne Funktionsaufruf je Punkt, Abbruch ab Grenze). Gegenprobe mit der
-- bisherigen Rechnung (Punkt für Punkt über Danger:At) auf 2000 Zufallsstrecken um den Spieler (eigener Zufall).
IMPL.T291 = function()
    local D = LP.Danger
    local inst, pn, pw = LP.Geo:Player()
    if not (D and D.Route and inst and pn) then return NA end
    local seed = 291
    local function rnd() seed = (seed * 1103515245 + 12345) % 2147483648 return seed / 2147483648 end
    local function Ref(n1, w1, n2, w2, skip)
        local dn, dw = n2 - n1, w2 - w1
        local len = math.sqrt(dn * dn + dw * dw)
        if len <= (skip or 0) then return 0 end
        local steps = math.max(1, math.ceil(len / 50))
        local mx = 0
        for i = 0, steps do
            if len * i / steps >= (skip or 0) then
                local v = D:At(inst, n1 + dn * i / steps, w1 + dw * i / steps)
                if v > mx then mx = v end
            end
        end
        return mx
    end
    local skips = { 0, 150, 37.5, 300 }
    local diff, diffStop, nonzero, first = 0, 0, 0, nil
    for k = 1, 2000 do
        local n1, w1 = pn + (rnd() - 0.5) * 2000, pw + (rnd() - 0.5) * 2000
        local n2, w2 = pn + (rnd() - 0.5) * 10000, pw + (rnd() - 0.5) * 10000
        local skip = skips[k % 4 + 1]
        local ref = Ref(n1, w1, n2, w2, skip)
        local new = D:Route(inst, n1, w1, n2, w2, skip)
        local lim = 1 + math.floor(rnd() * 60)
        local fast = D:Route(inst, n1, w1, n2, w2, skip, lim)
        if ref > 0 then nonzero = nonzero + 1 end
        if new ~= ref then diff = diff + 1 first = first or ("%d: neu %s, bisher %s"):format(k, new, ref) end
        if (fast >= lim) ~= (ref >= lim) then diffStop = diffStop + 1 first = first or ("%d: Grenze %d neu %s, bisher %s"):format(k, lim, fast, ref) end
    end
    -- absichtlich falscher Fall: eine Rechnung mit halb so vielen Messpunkten (alle 100 statt 50 Yards) muss der
    -- Vergleich als abweichend erkennen
    local caught = 0
    for k = 1, 500 do
        local n1, w1 = pn + (rnd() - 0.5) * 2000, pw + (rnd() - 0.5) * 2000
        local n2, w2 = pn + (rnd() - 0.5) * 10000, pw + (rnd() - 0.5) * 10000
        local dn, dw = n2 - n1, w2 - w1
        local steps = math.max(1, math.ceil(math.sqrt(dn * dn + dw * dw) / 100))
        local wrong = 0
        for i = 0, steps do
            local v = D:At(inst, n1 + dn * i / steps, w1 + dw * i / steps)
            if v > wrong then wrong = v end
        end
        if wrong ~= Ref(n1, w1, n2, w2, 0) then caught = caught + 1 end
    end
    return diff == 0 and diffStop == 0 and caught > 0, ("2000 Strecken (mit Gefahr %d): Abweichung %d, mit Grenze %d%s · Gegenprobe (halbe Messpunkte) erkannt %d von 500")
        :format(nonzero, diff, diffStop, first and (" – " .. first) or "", caught), "0, 0, Gegenprobe > 0"
end

-- 3.12.33 LP-D1: Ursache der "Questauswertung 495 ms": Perf.Run mass die Wanduhr über die Pausen einer Portion hinweg.
-- a) eigene Uhr und eine eigene Portion in LP.Jobs.list (eigene Tabellen): 5 ms rechnen, abgeben, 100 ms andere Bilder,
--    3 ms rechnen -> gemessen 8 ms (Gegenprobe: Wanduhr 108 ms). b) Questauswertung auf Stufe 31 (eigenes Volk) unter 16 ms.
IMPL.T292 = function()
    local Perf, J, P = LP.Perf, LP.Jobs, LP.Planner
    if not (Perf and J and J.list and P._perf_BuildCandidates) then return NA end
    local clock = 0
    local savedClock, savedStat = Perf.clock, Perf.stats.t292
    local measured, wall
    Guard(function()
        Perf.clock = function() return clock end
        Perf.stats.t292 = nil
        local co
        co = coroutine.create(function()
            Perf.Run("t292", "t292", false, function()
                clock = clock + 5
                J.Yield("plan")              -- Budget 4 ms überschritten -> abgeben
                clock = clock + 3
            end)
        end)
        J.list.t292 = { co = co, kinds = { plan = true }, sliceStart = 0, budget = 4, slices = 0, cpu = 0, mod = "t292" }
        local t0 = clock
        coroutine.resume(co)                 -- erste Portion bis zur Abgabe
        clock = clock + 100                  -- andere Bilder vergehen
        coroutine.resume(co)                 -- Rest
        wall = clock - t0
        measured = Perf.stats.t292 and Perf.stats.t292.max or -1
    end, function()
        J.list.t292 = nil
        Perf.clock, Perf.stats.t292 = savedClock, savedStat
    end)
    -- b) Rechenzeit der Questauswertung auf Stufe 31 (ohne Portionen, am Stück)
    local race
    for _, r in ipairs(LAGEN_RACES) do if r.f == LP:PlayerFaction() then race = r break end end
    -- b) Questauswertung Stufe 31 als Portion (wie im Spiel nach dem Einloggen und beim Stufenaufstieg):
    --    längste Portion < 16 ms, Gesamtrechenzeit zur Information
    local cpu, longest, slices, n = 0, 0, 0, #(LP.QuestDB:AllIds() or {})
    if race then
        WithLage(race, race.classes[1], 31, function()
            local co = coroutine.create(function() P._perf_BuildCandidates(P) end)
            J.list.t292b = { co = co, kinds = { plan = true }, budget = J.BUDGET_MS, slices = 0, cpu = 0, mod = "t292" }
            local okR = true
            Guard(function()
                while coroutine.status(co) ~= "dead" and slices < 500 do
                    J.list.t292b.sliceStart = Perf.clock()
                    local t = Perf.clock()
                    local ok2 = coroutine.resume(co)
                    local ms = Perf.clock() - t
                    if not ok2 then okR = false break end
                    slices, cpu = slices + 1, cpu + ms
                    if ms > longest then longest = ms end
                end
            end, function() J.list.t292b = nil end)
            if not okR then longest = 999 end
        end)
        pcall(P._perf_BuildCandidates, P)    -- Kandidaten für die echte Stufe wiederherstellen
    end
    local ok = measured == 8 and wall == 108 and slices > 0 and longest < 16
    return ok, ("in Portionen gemessen %s ms (Wanduhr %s ms) · Stufe 31, %d Quests: %d Portionen, längste %.2f ms, zusammen %.2f ms")
        :format(S(measured), S(wall), n, slices, longest, cpu), "8 (108) · längste Portion < 16 ms"
end

-- 3.12.33 GR1-K: eigene Schritte, Anzeige neu zeichnen, danach alles zurück
IMPL.T293 = function()
    local P, UI = LP.Planner, LP.UI
    if not (UI and UI.rows and UI.Refresh and UI.LaterSuffix) then return NA end
    local savedSteps = P.steps
    local note = { t = "NOTE", key = "LATER:445", laterIds = { 445 }, text = LP.L["|cff3dd694Später abgeben|r: "] .. "Test 445 (Silberwald)" }
    local steps = { { t = "TURNIN", id = 405, key = "TURNIN:405", q = "Test 405" }, note }
    local want = LP.L("+%d später abgeben", 1)
    local r = {}
    Guard(function()
        P.steps = steps
        WithSetting({ compactMode = true }, function()
            UI:Refresh()
            local row = UI.rows[1]
            r.compact = row and row.text and (row.text:GetText() or ""):find(want, 1, true) ~= nil
            r.tip = row and rawget(row, "laterNote") == note
        end)
        WithSetting({ compactMode = false, stepsShown = 5 }, function()
            UI:Refresh()
            local row = UI.rows[1]
            r.normal = row and row.text and (row.text:GetText() or ""):find(want, 1, true) == nil and rawget(row, "laterNote") == nil
        end)
        -- Gegenprobe: ohne Hinweis nichts angehängt
        P.steps = { steps[1] }
        WithSetting({ compactMode = true }, function()
            UI:Refresh()
            local row = UI.rows[1]
            r.none = row and row.text and (row.text:GetText() or ""):find(want, 1, true) == nil
        end)
    end, function()
        P.steps = savedSteps
        pcall(UI.Refresh, UI)
    end)
    local ok = r.compact and r.tip and r.normal and r.none
    return ok and true or false, ("kompakt angehängt %s, Tooltip %s · normale Liste ohne Anhang %s · ohne Hinweis kein Anhang %s")
        :format(S(r.compact), S(r.tip), S(r.normal), S(r.none)), "true, true · true · true"
end

-- 3.12.34 L-1: Der registrierte 300-s-Ticker, das Einloggen-Sample und der Diagnose-Text rufen UpdateAddOnMemoryUsage nie auf.
-- WithEnv setzt eine zählende Ersatzfunktion nur für die eigenen Funktionen ein (setfenv) – keine Blizzard-Tabelle wird geändert.
IMPL.T294 = function()
    local Pr = LP.Protocol
    if not (Pr and Pr.MemoryTick and Pr.MeasureAddon and Pr.LuaSample) then return false, "Funktionen fehlen", "vorhanden" end
    local tick
    for _, t in ipairs(LP.tickers or {}) do if t.name == "protocol_memory" then tick = t end end
    local calls = 0
    local fake = {
        UpdateAddOnMemoryUsage = function() calls = calls + 1 end,
        GetAddOnMemoryUsage = function() return 1024 end,
        C_AddOns = { GetAddOnMemoryUsage = function() return 1024 end },
    }
    local r = {}
    WithEnv({ Pr.MemoryTick, Pr.LuaSample, Pr.MeasureAddon, Pr.Text, Pr.ExportString }, fake, function()
        if tick then tick.fn() end
        Pr.MemoryTick()
        r.tick = calls
        pcall(Pr.ExportString)              -- Diagnose-Text (auch beim Ausloggen)
        r.text = calls - r.tick
        Pr.MeasureAddon()                   -- Gegenprobe: die alte Messung im Ticker wäre 1 Aufruf
        r.measure = calls - r.tick - r.text
    end)
    local info = Pr.MemInfo()
    local ok = tick and tick.fn == Pr.MemoryTick and tick.interval == 300 and r.tick == 0 and r.text == 0 and r.measure == 1
        and info.luaNow and info.luaNow > 0
    return ok and true or false, ("Ticker 300 s registriert %s · UpdateAddOnMemoryUsage im Ticker %d×, im Diagnose-Text %d× · Gegenprobe Messung auf Befehl %d× · Lua gesamt %s KB")
        :format(S(tick ~= nil and tick.fn == Pr.MemoryTick), r.tick or -1, r.text or -1, r.measure or -1, S(info.luaNow and math.floor(info.luaNow))),
        "true · 0×, 0× · 1× · > 0"
end

-- 3.12.34 PF-A-Rest: Ursache der 26 ms im ersten T150-Lauf = Aufbau der Kandidaten und Dienst-NPCs nach vorherigen Tests
-- (Stufe/Sprache gewechselt). Prüft: kalt -> Portionen (eigene Schleife über LP.Jobs.Step), warm -> sofort.
IMPL.T295 = function()
    local P, J, Q = LP.Planner, LP.Jobs, LP.QuestDB
    if not (P.Cold and J and J.Step and Q.InvalidateServices) then return false, "fehlt", "vorhanden" end
    local r = {}
    local savedSync, savedMax = J.sync, J.maxSlice
    Guard(function()
        J.sync = false
        P:InvalidateCandidates()
        Q:InvalidateServices()
        r.cold = P:Cold()
        P:Replan(true)
        r.job = J.Running("replan")
        J.maxSlice = 0
        local frames = 0
        while J.Running("replan") and frames < 500 do J.Step() frames = frames + 1 end
        r.frames, r.longest = frames, J.maxSlice
        r.done = not J.Running("replan")
        r.warm = not P:Cold()
        P:Replan(true)
        r.warmSync = not J.Running("replan")
    end, function()
        if J.Running("replan") then J.Cancel("replan") end
        J.sync, J.maxSlice = savedSync, math.max(savedMax or 0, J.maxSlice or 0)
    end)
    local ok = r.cold and r.job and r.done and (r.longest or 99) < 16 and r.warm and r.warmSync
    return ok and true or false, ("kalt erkannt %s · in Portionen %s (%d Bilder, längste %.2f ms) · danach warm %s · warmer Klick sofort %s")
        :format(S(r.cold), S(r.job), r.frames or -1, r.longest or -1, S(r.warm), S(r.warmSync)), "true · true (< 16 ms) · true · true"
end

-- 3.12.35 UC-W1: mit dem echten Wegnetz des Spielers (nur lesen). Ohne genug Wegdaten in Undercity nicht prüfbar;
-- die feste Prüfung mit den eingesandten Wegdaten läuft in der Offline-Routine (test_ucw1.lua).
IMPL.T296 = function()
    local G, Geo, N = LP.Graph, LP.Geo, LP.Nav
    if not (G.PathKnown and N.Known) then return false, "PathKnown fehlt", "vorhanden" end
    local npc = _G.LevelPilotData and LevelPilotData.N and LevelPilotData.N[1498]
    local s = npc and npc.s and npc.s[1]
    if not (s and s[1] == 1458) then return NA, "Bethor Iceshard nicht im Datenpaket" end
    local i2, n2, w2 = Geo:ToWorld(1458, s[2], s[3])
    local i1, n1, w1 = Geo:ToWorld(1458, 64.3, 35.9)
    if not (i1 and i2) then return NA, "Undercity-Karte nicht verfügbar" end
    local near = G:Near(i1, n1, w1, 60, 1458)
    if not near or #near == 0 then return NA, "keine gelaufenen Wege am Auktionshaus von Undercity" end
    local p = G:Path(i1, n1, w1, 1458, i2, n2, w2, 1458)
    local q = G:PathKnown(i1, n1, w1, 1458, i2, n2, w2, 1458)
    local knownP, knownQ = p and N.Known(p), q and N.Known(q)
    if not q then return NA, ("im eigenen Wegnetz kein ganz gelaufener Weg bis Bethor (normale Suche bekannt %s)"):format(S(knownP)) end
    return knownQ == true, ("normale Suche bekannt %s · nur bekannte Wege: %d Punkte, bekannt %s"):format(S(knownP), #q, S(knownQ)),
        "bekannt true"
end

-- 3.12.36 W3D B1: Ebenen-Angabe am Spieler, Speichern als Nummer, Schalter aus (Messung GSWegMess steht noch aus)
IMPL.T297 = function()
    local G = LP.Graph
    if not (G.LevelInfo and G.LvId and G.LvName and G.On) then return false, "W3D-Bausteine fehlen", "vorhanden" end
    local lv = G.LevelInfo()
    local form = type(lv) == "string" and lv:find("^%d+|[do]|") ~= nil
    local id = G.LvId(lv)
    local back = id and G.LvName({ lv = id })
    local off = G.On() == false
    return (form and back == lv and off) and true or false,
        ("Ebenen-Angabe „%s“ · gespeichert als Nr. %s · zurück „%s“ · Schalter aus %s"):format(tostring(lv), tostring(id),
            tostring(back), S(off)), "Karte|d/o|Unterzone · Nummer · gleich · true"
end

-- 3.12.37 Punkt 1/6: Startwegnetz aus Data/Wege.lua (nur WoW-Forever-Client), in Portionen beim Einloggen geladen
IMPL.T298 = function()
    local G = LP.Graph
    if not G.SeedWegeAktiv then return false, "Startwegnetz fehlt", "vorhanden" end
    if not G.SeedWegeAktiv() then return NA, "kein WoW-Forever-Client – Startwegnetz absichtlich aus" end
    local st = G.seedWegeStat
    if not st then return false, "nicht geladen", "geladen" end
    if not st.fertig then return NA, ("wird noch geladen (%d Wege)"):format(st.wege or 0) end
    local saved = 0
    for _, e in pairs(LP.db.graph.edges or {}) do if e[3] == "seed" then saved = saved + 1 end end
    local ok = st.karten == 3 and (st.knoten or 0) + (st.eigen or 0) > 500 and (st.kanten or 0) > 600 and saved == 0
    return ok, ("Karten %d · neue Knoten %d · eigene genutzt %d · Kanten %d · gespeichert %d"):format(st.karten or 0,
        st.knoten or 0, st.eigen or 0, st.kanten or 0, saved), "Karten 3 · Knoten > 500 · Kanten > 600 · gespeichert 0"
end

-- 3.12.38 W3D: Unterzonen-Namen aller Sprachen -> ein Schluessel (Data/AreaNames.lua aus AreaTable + WMOAreaTable)
IMPL.T299 = function()
    local G = LP.Graph
    if not (G.SubKey and G.SubName and LP.AreaNames) then return false, "Tabelle oder SubKey fehlt", "vorhanden" end
    local a, b, c = G.SubKey("Magieviertel"), G.SubKey("Das Magieviertel"), G.SubKey("Magic Quarter")
    local u = G.SubKey("Kein Ort lpt299")
    local show = G.SubName(a)
    local ok = a == "#1497:Magic Quarter" and b == a and c == a and u == "Kein Ort lpt299" and show ~= a and show ~= ""
    return ok, ("%s · %s · %s · unbekannt bleibt %s · Anzeige „%s“"):format(a, b, c, S(u == "Kein Ort lpt299"), tostring(show)),
        "#1497:Magic Quarter dreimal · true · Name"
end

-- 3.12.39 LP-N1: Hinweise mit eigener Sammelliste (keine Toasts, keine echten Spielwerte)
local function Collect(fn)
    local out = {}
    fn(function(key, sev, text) out[#out + 1] = { key = key, sev = sev, text = text } end)
    return out
end
IMPL.T300 = function()
    local A = LP.Advisor
    if not A.CheckRested then return false, "CheckRested fehlt", "vorhanden" end
    local afk, resting, level = true, false, 20
    local fake = { UnitIsAFK = function() return afk end, IsResting = function() return resting end,
                   GetMaxPlayerLevel = function() return 60 end, InCombatLockdown = function() return false end }
    local r = {}
    local savedLevel = LP.PlayerLevel
    local ok, err = pcall(WithEnv, { A.CheckRested }, fake, function()
        LP.PlayerLevel = function() return level end
        r.afk = #Collect(A.CheckRested)
        resting = true r.rest = #Collect(A.CheckRested)
        resting, afk = false, false r.noafk = #Collect(A.CheckRested)
        afk, level = true, 60 r.max = #Collect(A.CheckRested)
        level = 20
        local was = LP.db.advRested
        LP.db.advRested = false r.off = #Collect(A.CheckRested)
        LP.db.advRested = was
        return true
    end)
    LP.PlayerLevel = savedLevel
    if not ok then error(err, 0) end
    local good = ok and r.afk == 1 and r.rest == 0 and r.noafk == 0 and r.max == 0 and r.off == 0
    return good and true or false, ("AFK draussen %s · im Gasthaus %s · nicht AFK %s · Stufe 60 %s · aus %s"):format(
        S(r.afk), S(r.rest), S(r.noafk), S(r.max), S(r.off)), "1 · 0 · 0 · 0 · 0"
end
CLIENT.T300 = "Ausserhalb von Gasthaus/Hauptstadt /afk eingeben: im Assistenten erscheint „Pause? Im Gasthaus …“ mit „Hinführen“; im Gasthaus nicht"
CLIENT.T301 = "Waffe einer Art mit niedriger Fertigkeit anlegen (z. B. neue Questwaffe): Hinweis „Waffenfertigkeit …: x von y“ – prüft, ob der Name der Fertigkeit genau der Waffenart entspricht (Sprache des Clients)"
IMPL.T301 = function()
    local A = LP.Advisor
    if not A.CheckWeaponSkill then return false, "CheckWeaponSkill fehlt", "vorhanden" end
    local rank = 40
    local lines = { { "Waffenfertigkeiten", true }, { "Einhandäxte", false }, { "Dolche", false } }
    local fake = {
        GetInventoryItemLink = function(_, slot) if slot == 16 then return "|Hitem:999301::::::::|h[Testaxt]|h|r" end end,
        GetItemInfo = function() return "Testaxt", nil, 2, 20, 15, "Waffe", "Einhandäxte" end,
        GetNumSkillLines = function() return #lines end,
        GetSkillLineInfo = function(i)
            local l = lines[i]
            if l[2] then return l[1], true end
            if l[1] == "Einhandäxte" then return l[1], false, nil, rank, 0, 0, 100 end
            return l[1], false, nil, 20, 0, 0, 100
        end,
    }
    local r = {}
    local ok = WithEnv({ A.CheckWeaponSkill }, fake, function()
        local h = Collect(A.CheckWeaponSkill)
        r.low, r.text = #h, h[1] and h[1].text
        rank = 80 r.ok = #Collect(A.CheckWeaponSkill)           -- 20 unter dem Hoechstwert: kein Hinweis
        rank = 40
        lines[2][1] = "Zweihandäxte" r.other = #Collect(A.CheckWeaponSkill)   -- andere Waffenart niedrig: kein Hinweis
        lines[2][1] = "Einhandäxte"
        return true
    end)
    local good = ok and r.low == 1 and r.ok == 0 and r.other == 0 and tostring(r.text):find("40", 1, true) ~= nil
    return good and true or false, ("40/100 %s („%s“) · 80/100 %s · andere Waffenart %s"):format(S(r.low), tostring(r.text),
        S(r.ok), S(r.other)), "1 · 0 · 0"
end

-- 3.12.40 LP-N1 4b: eigene Testtasche, eigene Fertigkeiten, Krieger
IMPL.T302 = function()
    local A, API = LP.Advisor, LP.API
    if not (A.CheckWeaponMaster and A.WEAPON_MASTERS) then return false, "CheckWeaponMaster fehlt", "vorhanden" end
    local NAMES = { [0] = "Einhandäxte", [15] = "Dolche", [6] = "Stangenwaffen", [19] = "Zauberstäbe" }
    local ITEMS = { [999401] = { 2, 15 }, [999402] = { 2, 6 }, [999403] = { 2, 19 }, [999400] = { 2, 0 } }
    local skills = { "Waffenfertigkeiten", "Einhandäxte" }
    local bag = {}
    local fake = {
        GetNumSkillLines = function() return #skills end,
        GetSkillLineInfo = function(i) return skills[i], i == 1 end,
        GetItemSubClassInfo = function(_, sub) return NAMES[sub] end,
        GetInventoryItemLink = function(_, slot) if slot == 16 then return "item:999400" end end,
        C_Item = false,
        GetItemInfoInstant = function(id)
            local n = tonumber(tostring(id):match("(%d+)"))
            local it = ITEMS[n]
            if it then return n, nil, nil, nil, nil, it[1], it[2] end
        end,
        UnitClass = function() return "Krieger", "WARRIOR" end,
        InCombatLockdown = function() return false end,
    }
    local saved = { BagSlots = API.BagSlots, BagItem = API.BagItem, PlayerLevel = LP.PlayerLevel }
    local level = 15
    local r = {}
    local ok, err = pcall(WithEnv, { A.CheckWeaponMaster }, fake, function()
        API.BagSlots = function(b) return b == 0 and 1 or 0 end
        API.BagItem = function(b, slot) return bag[1] end
        LP.PlayerLevel = function() return level end
        bag[1] = { id = 999401, quality = 2, link = "[Testdolch]" }
        local h = Collect(A.CheckWeaponMaster)
        r.dagger, r.text = #h, h[1] and h[1].text or ""
        skills[3] = "Dolche" r.known = #Collect(A.CheckWeaponMaster) skills[3] = nil
        bag[1] = { id = 999401, quality = 0, link = "[grauer Dolch]" } r.grey = #Collect(A.CheckWeaponMaster)
        bag[1] = { id = 999403, quality = 2, link = "[Zauberstab]" } r.wand = #Collect(A.CheckWeaponMaster)
        bag[1] = { id = 999402, quality = 2, link = "[Stangenwaffe]" } r.pole15 = #Collect(A.CheckWeaponMaster)
        level = 20 r.pole20 = #Collect(A.CheckWeaponMaster)
        bag[1] = { id = 999401, quality = 2, link = "[Testdolch]" }
        skills[2] = "One-Handed Axes" r.calib = #Collect(A.CheckWeaponMaster) skills[2] = "Einhandäxte"
        return true
    end)
    API.BagSlots, API.BagItem, LP.PlayerLevel = saved.BagSlots, saved.BagItem, saved.PlayerLevel
    if not ok then error(err, 0) end
    -- Der Lehrer der Dolche fuer die Horde in Kalimdor ist Sayoc (11868); fehlt das Datenpaket, steht die Ersatzzeile da
    -- Lehrer der Dolche der eigenen Fraktion (Horde: Sayoc; Allianz: Woo Ping/Bixi/Ilyenia) – je nach Ort der nächste
    local teacher = not _G.LevelPilotData
    for _, x in ipairs(LP.QuestDB:ServiceNPCs().trainer or {}) do
        if x.id and A.WEAPON_MASTERS[x.id] and A.WEAPON_MASTERS[x.id][15] and x.name and r.text:find(x.name, 1, true) then teacher = true end
    end
    local good = r.dagger == 1 and teacher and r.known == 0 and r.grey == 0 and r.wand == 0 and r.pole15 == 0 and r.pole20 == 1 and r.calib == 0
    return good, ("Dolch ungelernt %s („%s“) · gelernt %s · grau %s · Zauberstab (Krieger) %s · Stangenwaffe Lv15 %s / Lv20 %s · Sprache passt nicht %s")
        :format(S(r.dagger), r.text, S(r.known), S(r.grey), S(r.wand), S(r.pole15), S(r.pole20), S(r.calib)), "1 · 0 · 0 · 0 · 0 / 1 · 0"
end
CLIENT.T302 = "Waffe einer noch nicht gelernten, für die Klasse erlaubten Art (grün oder besser) in die Tasche: Hinweis nennt den richtigen Waffenmeister; nach dem Lernen verschwindet er"

-- 3.12.41 LP-N1 3: eigene Testquest, eigene Stellen; Spieler, Zeit und Quest nur in eigenen Tabellen ersetzt
IMPL.T303 = function()
    local P, Geo, QDB = LP.Planner, LP.Geo, LP.QuestDB
    if not (P.WithoutExhausted and P.CheckStuck and P.MarkExhausted) then return false, "Funktionen fehlen", "vorhanden" end
    local Z = 1411
    local A, B, C = { Z, 40, 40 }, { Z, 41, 40 }, { Z, 60, 60 }        -- A und B nah beieinander, C weit weg
    local ai, an, aw = Geo:ToWorld(Z, 40, 40)
    local QID = 999303
    local saved = { steps = P.steps, ex = P.exhausted[QID], get = QDB.Get, player = Geo.Player, replan = P.Replan, stuck = P.stuck,
                    grind = LP.db.advGrind }
    local r = {}
    local ok, err = pcall(function()
        LP.db.advGrind = true
        -- a) leere Stelle wird ausgelassen, alle leer -> Liste bleibt, abgelaufen -> wieder da
        P.exhausted[QID] = { { ai, an, aw, (GetTime and GetTime() or 0) + 600 } }
        local keep = P:WithoutExhausted(QID, { A, B, C })
        r.skip = #keep == 1 and keep[1] == C
        r.all = #P:WithoutExhausted(QID, { A, B }) == 2
        P.exhausted[QID][1][4] = 0
        r.expired = #P:WithoutExhausted(QID, { A, B, C }) == 3 and P.exhausted[QID] == nil
        -- b) Hinweis erst nach STUCK_SECS am Ziel ohne Fortschritt
        QDB.Get = function(_, id) if id == QID then return { id = QID, name = "Testquest", objectives = { { kind = "kill", spots = { A, B, C } } } } end return saved.get(QDB, id) end
        P.steps = { { t = "COMPLETE", id = QID, q = "Testquest", inst = ai, n = an, w = aw } }
        Geo.Player = function() return ai, an + 5, aw end
        P.stuck = nil
        r.first = #Collect(function(add) P:CheckStuck(add) end)
        P.stuck.since = P.stuck.since - (P.STUCK_SECS + 5)
        local h = Collect(function(add) P:CheckStuck(add) end)
        r.after, r.text = #h, h[1] and h[1].text or ""
        local hint
        P:CheckStuck(function(key, sev, text, action) hint = action end)
        -- c) "Andere Stelle": A gilt als leer, die Planung nimmt C (Replan hier nur gezählt)
        local replans = 0
        P.Replan = function() replans = replans + 1 end
        if hint then hint() end
        local keep2 = P:WithoutExhausted(QID, { A, B, C })
        r.marked = replans == 1 and #keep2 == 1 and keep2[1] == C
        -- d) weg vom Ziel -> zurückgesetzt; aus -> nichts
        Geo.Player = function() return ai, an + 500, aw end
        P:CheckStuck(function() end)
        r.away = P.stuck == nil
        LP.db.advGrind = false
        Geo.Player = function() return ai, an + 5, aw end
        r.off = #Collect(function(add) P:CheckStuck(add) end) == 0 and P.stuck == nil
    end)
    P.steps, P.exhausted[QID], QDB.Get, Geo.Player, P.Replan, P.stuck = saved.steps, saved.ex, saved.get, saved.player, saved.replan, saved.stuck
    LP.db.advGrind = saved.grind
    if not ok then error(err, 0) end
    local good = r.skip and r.all and r.expired and r.first == 0 and r.after == 1 and r.marked and r.away and r.off
    return good and true or false, ("leere Stelle ausgelassen %s · alle leer -> Liste bleibt %s · abgelaufen %s · sofort %s · nach 3 Min. %s („%s“) · Andere Stelle %s · weg %s · aus %s")
        :format(S(r.skip), S(r.all), S(r.expired), S(r.first), S(r.after), tostring(r.text), S(r.marked), S(r.away), S(r.off)),
        "true · true · true · 0 · 1 · true · true · true"
end
CLIENT.T303 = "Bei einer Töte-Quest 3 Min. am Ziel ohne Fortschritt stehen/suchen: Hinweis „Seit 3 Min. kein Fortschritt …“, Klick „Andere Stelle“ -> Pfeil zur nächsten Stelle"

-- 3.12.42: eigene Ware, eigene Knöpfe, eigenes Händlerfenster (nur LP-Tabellen ersetzt; MerchantFrame über WithEnv)
IMPL.T304 = function()
    local A, API = LP.Advisor, LP.API
    if not (A.MarkMerchant and A.MerchantUpgrades) then return false, "MarkMerchant fehlt", "vorhanden" end
    local wares = {}
    for i = 1, 14 do wares[i] = (i == 2 or i == 12) and "lpt304:up" or "lpt304:no" end
    local function Btn()
        local b = { shown = false }
        function b:CreateTexture()
            local t = { visible = true }
            function t:SetTexture() end function t:SetSize() end function t:SetPoint() end
            function t:Show() self.visible = true end function t:Hide() self.visible = false end
            return t
        end
        return b
    end
    local btns = {}
    for i = 1, 10 do btns[i] = Btn() end
    local frame = { page = 1, selectedTab = 1, IsShown = function() return true end }
    local saved = { count = API.MerchantCount, link = API.MerchantLink, equ = API.IsEquippable, up = A.UpgradeValue,
                    btn = A.MerchantButton, adv = LP.db.advUpgrades }
    local r = {}
    local ok, err = pcall(WithEnv, { A.MarkMerchant }, { MerchantFrame = frame, MERCHANT_ITEMS_PER_PAGE = 10 }, function()
        API.MerchantCount = function() return #wares end
        API.MerchantLink = function(i) return wares[i] end
        API.IsEquippable = function() return true end
        A.UpgradeValue = function(_, link) if link == "lpt304:up" then return 5 end return nil end
        A.MerchantButton = function(i) return btns[i] end
        LP.db.advUpgrades = true
        r.p1 = A:MarkMerchant()
        r.b2 = btns[2].lpUpgrade and btns[2].lpUpgrade.visible
        r.b3 = btns[3].lpUpgrade == nil
        frame.page = 2 r.p2 = A:MarkMerchant()
        r.p2b2 = btns[2].lpUpgrade and btns[2].lpUpgrade.visible           -- Ware 12 auf Seite 2, Platz 2
        frame.selectedTab = 2 r.buyback = A:MarkMerchant()
        r.hidden = btns[2].lpUpgrade and not btns[2].lpUpgrade.visible
        frame.selectedTab = 1 LP.db.advUpgrades = false r.off = A:MarkMerchant()
        return true
    end)
    API.MerchantCount, API.MerchantLink, API.IsEquippable, A.UpgradeValue, A.MerchantButton = saved.count, saved.link, saved.equ, saved.up, saved.btn
    LP.db.advUpgrades = saved.adv
    if not ok then error(err, 0) end
    local good = r.p1 == 1 and r.b2 and r.b3 and r.p2 == 1 and r.p2b2 and r.buyback == 0 and r.hidden and r.off == 0
    return good and true or false, ("Seite 1: %s markiert (Platz 2 %s, Platz 3 ohne %s) · Seite 2: %s (Platz 2 %s) · Rückkauf-Reiter %s, ausgeblendet %s · aus %s")
        :format(S(r.p1), S(r.b2), S(r.b3), S(r.p2), S(r.p2b2), S(r.buyback), S(r.hidden), S(r.off)), "1 · true · true · 1 · true · 0 · true · 0"
end
CLIENT.T304 = "Händler mit tragbarer Ware öffnen: Plus-Zeichen oben links an den Waren, die für deine Klasse ein Upgrade sind (wie „Mögliches Upgrade“); Seite wechseln: Zeichen wandern mit"

-- 3.12.43: Talentbaum des Kriegers aus den eigenen Build-Daten nachgebaut (eigene Ränge), Waffe und Sprache ersetzt
IMPL.T305 = function()
    local A = LP.Advisor
    local list = LP.TalentBuilds and LP.TalentBuilds.WARRIOR
    if not (A.TalentNext and list) then return false, "TalentNext oder Builds fehlen", "vorhanden" end
    -- alle 9 Klassen: 51 Punkte
    local sums = {}
    for cls, l in pairs(LP.TalentBuilds) do local n = 0 for _, e in ipairs(l) do n = n + e[4] end sums[#sums + 1] = n == 51 and 1 or 0 end
    local all51 = #sums == 9
    for _, v in ipairs(sums) do if v == 0 then all51 = false end end
    local talents = {}          -- [tab] = { {tier, col, rank, max}, ... }
    local function add(tab, tier, col, max) talents[tab] = talents[tab] or {} table.insert(talents[tab], { tier, col, 0, max }) end
    for _, e in ipairs(list) do
        add(e[1], e[2], e[3], 5)
        for _, a in ipairs(e.alt or {}) do add(a[1], a[2], a[3], 5) end
    end
    local function rankOf(tab, tier, col) for _, t in ipairs(talents[tab] or {}) do if t[1] == tier and t[2] == col then return t end end end
    local sub, empty = 4, false
    local fake = {
        UnitClass = function() return "Krieger", "WARRIOR" end,
        GetLocale = function() return "deDE" end,
        GetNumTalents = function(tab) if empty then return 0 end return #(talents[tab] or {}) end,
        GetTalentInfo = function(tab, i)
            local t = talents[tab][i]
            return ("T%d-%d-%d"):format(tab, t[1], t[2]), nil, t[1], t[2], t[3], t[4]
        end,
        GetInventoryItemLink = function(_, slot) if slot == 16 then return "item:999305" end end,
        C_Item = false,
        GetItemInfoInstant = function() return 999305, nil, nil, nil, nil, 2, sub end,
    }
    local r = {}
    local ok, err = pcall(WithEnv, { A.TalentNext }, fake, function()
        r.n1, r.r1, _, r.w1 = A:TalentNext()
        local t = rankOf(list[1][1], list[1][2], list[1][3]) t[3] = 3
        t = rankOf(list[2][1], list[2][2], list[2][3]) t[3] = 1
        r.n2, r.r2 = A:TalentNext()
        -- alles bis vor den Waffenmeister erfüllt, Waffe Schwert (7) -> Alternative
        for k = 1, #list do
            if list[k].alt then r.wmIndex = k break end
            local x = rankOf(list[k][1], list[k][2], list[k][3]) x[3] = list[k][4]
        end
        -- Wiederholte Einträge (gleiche Stelle) aufsummiert: hier keine beim Krieger
        sub = 7
        r.n3 = A:TalentNext()
        local sword
        for _, a in ipairs(list[r.wmIndex].alt) do for _, s2 in ipairs(a[4]) do if s2 == 7 then sword = ("T%d-%d-%d"):format(a[1], a[2], a[3]) end end end
        r.sword = sword
        sub = 99
        r.n4 = A:TalentNext()
        local std = list[r.wmIndex]
        r.std = ("T%d-%d-%d"):format(std[1], std[2], std[3])
        empty = true
        r.n5 = A:TalentNext()
        return true
    end)
    if not ok then error(err, 0) end
    local first = ("T%d-%d-%d"):format(list[1][1], list[1][2], list[1][3])
    local second = ("T%d-%d-%d"):format(list[2][1], list[2][2], list[2][3])
    local good = all51 and r.n1 == first and r.r1 == 1 and r.w1 == list[1][5] and r.n2 == second and r.r2 == 2
        and r.n3 == r.sword and r.n4 == r.std and r.n5 == nil
    return good, ("51 Punkte je Klasse %s · Start %s %s/… („%s“) · danach %s %s · Schwert -> %s (soll %s) · andere Waffe -> %s · fremder Baum -> %s")
        :format(S(all51), tostring(r.n1), tostring(r.r1), tostring(r.w1), tostring(r.n2), tostring(r.r2), tostring(r.n3), tostring(r.sword),
            tostring(r.n4), tostring(r.n5)), "true · erster Eintrag Rang 1 · zweiter Rang 2 · Schwert-Talent · Standard · nil"
end
CLIENT.T305 = "Mit freiem Talentpunkt: Hinweis „Talentpunkt(e) frei“ zeigt „Vorschlag (Level-Build von LevelPilot): <Talent> x/y – <Satz>“; der Name muss dem Talent im Talentfenster an dieser Stelle entsprechen"

-- 3.12.44: öffentliche Schnittstelle; Neuplanung nur gezählt, Ziel danach wiederhergestellt
IMPL.T306 = function()
    local API = _G.LevelPilotAPI
    if not (API and API.NavigateTo) then return false, "LevelPilotAPI.NavigateTo fehlt", "vorhanden" end
    local P = LP.Planner
    local saved, savedReplan = P.priority, P.Replan
    local replans = 0
    local r = {}
    local ok, err = pcall(function()
        P.Replan = function() replans = replans + 1 end
        r.good = API.NavigateTo(1411, 52.0, 43.0, "Lehrer lpt306")
        local p = P.priority
        r.step = p and p.t == "GOTO" and p.text == "Lehrer lpt306" and p.map == 1411 and p.inst ~= nil
        r.notitle = API.NavigateTo(1411, 50, 50) and P.priority.text ~= ""
        P.priority = nil
        r.bad1 = API.NavigateTo(1411, 150, 20)
        r.bad2 = API.NavigateTo(nil, 10, 10)
        r.bad3 = API.NavigateTo("x", 10, 10)
        r.untouched = P.priority == nil
        -- unbekannte Karte: nur prüfbar, wo die Spielversion für sie keine Weltkoordinaten liefert (im Nachbau gibt es alle)
        if LP.Geo:ToWorld(987654, 50, 50) == nil then r.unknown = API.NavigateTo(987654, 50, 50) else r.unknown = "n/a" end
    end)
    P.priority, P.Replan = saved, savedReplan
    if not ok then error(err, 0) end
    local good = r.good == true and r.step and r.notitle and r.bad1 == false and r.bad2 == false and r.bad3 == false
        and (r.unknown == false or r.unknown == "n/a") and r.untouched and replans == 2 and API.version == 2      -- 3.12.63: Schnittstelle Version 2 (T323)
    return good, ("gültig %s, Schritt oben %s, ohne Titel %s · x=150 %s · ohne Karte %s · Text %s · unbekannte Karte %s · Ziel unverändert %s · Neuplanungen %d · Version %s")
        :format(S(r.good), S(r.step), S(r.notitle), S(r.bad1), S(r.bad2), S(r.bad3), S(r.unknown), S(r.untouched), replans, S(API.version)),
        "true · true · true · false · false · false · false · true · 2 · 2"
end
CLIENT.T306 = "/run print(LevelPilotAPI.NavigateTo(1411, 52, 43, \"Test\")) -> true, oben im Guide steht „Test“ mit Pfeil dorthin"

-- 3.12.45 LP-N2: eigene Prüfpunkte (Fenster und Meldung ersetzt), dann die echten zehn ohne Lua-Fehler
IMPL.T307 = function()
    local CT = LP.ClientTest
    if not (CT and CT.Start and CT.Answer and CT.DiagLines) then return false, "ClientTest fehlt", "vorhanden" end
    local saved = { steps = CT.STEPS, show = CT.Show, hide = CT.Hide, reply = LP.Reply, ct = LP.db.clientTest }
    local shown, replies = {}, {}
    local r = {}
    local ok, err = pcall(function()
        CT.Show = function(_, x) shown[#shown + 1] = x.id end
        CT.Hide = function() end
        LP.Reply = function(_, m) replies[#replies + 1] = m end
        CT.STEPS = {
            { id = "A", name = "auto ok, Frage", auto = function() return "OK", "a" end, ask = function() return "Siehst du A?" end },
            { id = "B", name = "auto ok", auto = function() return "OK", "b" end },
            { id = "C", name = "auto fehler", auto = function() return "FEHLER", "c" end, ask = function() return "nie gefragt" end },
            { id = "D", name = "Lua-Fehler", auto = function() error("lpt307") end },
            { id = "E", name = "auto ok, Frage", auto = function() return "OK", "e" end, ask = function() return "Siehst du E?" end },
            { id = "F", name = "auto ok, Frage", auto = function() return "OK", "f" end, ask = function() return "Siehst du F?" end },
        }
        CT:Start()
        r.firstShown = shown[1]
        r.queued = #CT.queue
        CT:Answer(true)
        CT:Answer(false)
        CT:Answer(nil)
        local st = {}
        for _, x in ipairs(CT.results) do st[x.id] = x.status end
        r.st = st
        r.summary = CT:Summary()
        r.reply = replies[1]
        r.diag = #CT:DiagLines()
        -- echte Prüfpunkte: laufen ohne Lua-Fehler durch (Antworten: überspringen)
        CT.STEPS = saved.steps
        CT:Start()
        while #CT.queue > 0 do CT:Answer(nil) end
        local luaErr = 0
        for _, x in ipairs(CT.results) do if tostring(x.detail):find("lua", 1, true) or tostring(x.detail):find("attempt to", 1, true) then luaErr = luaErr + 1 end end
        r.real, r.realErr = #CT.results, luaErr
    end)
    CT.STEPS, CT.Show, CT.Hide, LP.Reply, LP.db.clientTest = saved.steps, saved.show, saved.hide, saved.reply, saved.ct
    if not ok then error(err, 0) end
    local st = r.st or {}
    local good = r.firstShown == "A" and r.queued == 3 and st.A == "OK" and st.B == "OK" and st.C == "FEHLER" and st.D == "FEHLER"
        and st.E == "FEHLER" and st.F == "N/A" and r.diag == 7 and r.reply and r.real == 10 and r.realErr == 0
    return good, ("zuerst gefragt %s · Fragen %s · A %s B %s C %s D %s E(nicht OK) %s F(übersprungen) %s · „%s“ · Diagnose-Zeilen %s · echte Punkte %s, Lua-Fehler %s")
        :format(tostring(r.firstShown), S(r.queued), tostring(st.A), tostring(st.B), tostring(st.C), tostring(st.D), tostring(st.E),
            tostring(st.F), tostring(r.reply), S(r.diag), S(r.real), S(r.realErr)),
        "A · 3 · OK OK FEHLER FEHLER FEHLER N/A · Meldung · 7 · 10, 0"
end

-- 3.12.46: eigenes Mess-Werkzeug (nur Zähler), Fenster und Meldung ersetzt, Ziel des Guides danach wiederhergestellt
IMPL.T308 = function()
    local WM = LP.WegMessung
    if not (WM and WM.Start and WM.Mark and WM.Tool) then return false, "WegMessung fehlt", "vorhanden" end
    local marks, running, started, stopped = {}, false, 0, 0
    local tool = {
        Running = function() return running end,
        Start = function() running = true started = started + 1 end,
        Stop = function() running = false stopped = stopped + 1 end,
        Mark = function(t) if not running then return false end marks[#marks + 1] = t return true end,
    }
    local have = false
    local saved = { show = WM.Show, reply = LP.Reply, prio = LP.Planner.priority, replan = LP.Planner.Replan }
    local replies, shown = {}, 0
    local r = {}
    local ok, err = pcall(function()
        WM.Show = function() shown = shown + 1 end
        LP.Reply = function(_, m) replies[#replies + 1] = m end
        LP.Planner.Replan = function() end
        local realTool = WM.Tool
        WM.Tool = function() return have and tool or nil end
        r.missing = WM:Start() == false and replies[1] ~= nil and WM.state == nil
        have = true
        r.started = WM:Start() == true and started == 1 and running and shown == 1
        r.arrow = LP.Planner.priority and LP.Planner.priority.text ~= nil      -- Lauf 1 Schritt 1: Pfeil zum Auktionshaus
        local names = WM.Names()
        r.names = names.uc ~= nil and names.mq ~= nil and not tostring(names.mq):find("^#")
        WM:Mark() WM:Mark() WM:Mark()                                      -- Lauf 1 fertig
        r.run2 = WM.state and WM.state.run == 2 and WM.state.step == 1
        WM:SkipRun()                                                       -- Lauf 2 übersprungen
        r.run3 = WM.state and WM.state.run == 3
        WM:Mark() WM:Mark()                                                -- Lauf 3
        WM:Mark() WM:Mark() WM:Mark()                                      -- Lauf 4 -> fertig
        r.done = WM.state == nil and stopped == 1 and not running
        r.marks = #marks
        r.first = marks[1]
        r.skip = false for _, m in ipairs(marks) do if m == "L2 übersprungen" then r.skip = true end end
        r.final = replies[#replies]
        WM.Tool = realTool
    end)
    WM.Show, LP.Reply, LP.Planner.priority, LP.Planner.Replan = saved.show, saved.reply, saved.prio, saved.replan
    WM.state = nil
    if not ok then error(err, 0) end
    local good = r.missing and r.started and r.arrow and r.names and r.run2 and r.run3 and r.done and r.marks == 9 and r.skip
        and r.first == "L1 Auktionshaus"
    return good and true or false, ("ohne Werkzeug Hinweis %s · Start %s · Pfeil %s · Ortsnamen %s · Lauf 2 %s · übersprungen -> Lauf 3 %s · Ende stoppt %s · Notizen %s (erste „%s“, Sprung notiert %s) · „%s“")
        :format(S(r.missing), S(r.started), S(r.arrow), S(r.names), S(r.run2), S(r.run3), S(r.done), S(r.marks), tostring(r.first), S(r.skip), tostring(r.final)),
        "true · true · true · true · true · true · true · 9 (L1 Auktionshaus, true)"
end
CLIENT.T308 = "Mit GSWegMess: /lp wegmessung – Fenster zeigt Lauf 1 Schritt 1, Pfeil zum Auktionshaus; „Markieren & weiter“ -> /wegmess zeigt mehr Zeilen; am Ende Chatzeile „Wegmessung fertig …“"

-- 16.11.: Prüfliste im Spiel. (a)/(b) echter Baustein GoldSentinelPruefliste, Testmodus über eine eigene Umgebung für dessen
-- IsDev (setfenv, _G.GoldSentinelDev bleibt unberührt), Zustand in einer Testtabelle (nie LevelPilotDB).
-- (c) jede Erkennungsstelle: eine Ersatzliste zählt mit, welche Punkte gemeldet werden; die Stellen laufen über die
-- vorhandenen Tests (T293, T300–T304, T307) bzw. über eigene kleine Aufrufe (Talent, Wegmessung, Unterstadt, Protokoll).
IMPL.T309 = function()
    local M = LP.Pruefliste
    local PL = M and M.Baustein and M.Baustein()
    if not (M and M.List and M.Hit and M.POINTS) then return false, "Prüfliste fehlt", "vorhanden" end
    if type(PL) ~= "table" or type(PL.IsDev) ~= "function" then return false, "GoldSentinelPruefliste.lua fehlt", "vorhanden" end
    local saved = { list = M.list, next = M.nextTry, db = M.DB, dry = M.Dry, reg = PL.lists and PL.lists.LevelPilot, pts = M.Points,
                    perf = LP.Perf, mem = LP.Protocol.MemInfo, fac = LP.PlayerFaction, player = LP.Geo.Player,
                    tp = LP.API.TalentPoints, tn = LP.Advisor.TalentNext, adv = LP.db.advTalents, reply = LP.Reply }
    local devOn, testDB, r = false, {}, {}
    local fakeDev = { version = 99, IsDev = function() return devOn end }
    -- der Baustein liest _G.GoldSentinelDev: eigene Sicht auf _G nur für dessen IsDev (das echte _G wird nicht beschrieben)
    local viewG = setmetatable({ GoldSentinelDev = fakeDev }, { __index = _G, __newindex = function() error("T309: _G nicht beschreiben", 0) end })
    local ok, err = pcall(WithEnv, { PL.IsDev }, { GoldSentinelDev = fakeDev, _G = viewG }, function()
        M.DB = function() return testDB end
        M.Dry = function() return false end
        M.Points = function() return M.POINTS end    -- 3.12.65: die Forever-Liste (die Era-Liste prüft T325)
        -- (a) ohne Testmodus: keine Liste, nichts gemeldet, keine Berichtszeilen
        M.list, M.nextTry = nil, 0
        r.offList = M:List(true) == nil
        r.offHit = M:Hit("T300", "x") == false and M:Fail("PF-A", "x") == false
        r.offReport = #M:ReportLines() == 0
        r.offStore = next(testDB) == nil
        -- (b) mit Testmodus: angemeldet, 14 Punkte vollständig, Fehler-Meldung und Bericht
        devOn = true
        M.list, M.nextTry = nil, 0
        local l = M:List(true)
        r.on = l ~= nil and PL.lists.LevelPilot == l
        local ids, full = {}, 0
        for _, p in ipairs(l and l.points or {}) do
            if p.id and p.title and p.since and p.todo and p.expect and not ids[p.id] then full = full + 1 end
            ids[p.id] = true
        end
        r.n, r.full = l and #l.points or 0, full
        r.fail = M:Fail("PF-A", "20 ms") == true and l:State("PF-A") == "fehler"
        r.failAgain = M:Fail("PF-A", "21 ms") == false
        r.head = (M:ReportLines()[1] or "")
        r.lines = #M:ReportLines()
        r.stored = type(testDB.pruefliste) == "table" and type(testDB.pruefliste.p) == "table" and testDB.pruefliste.p["PF-A"] ~= nil
        -- (c) jede Erkennungsstelle: Ersatzliste zählt mit
        local seen = {}
        M.list = { byId = ids, State = function() return "offen" end, Set = function() return true end,
                   Hit = function(_, id) seen[id] = "hit" return true end, ReportLines = function() return {} end }
        local fakeFail = M.Fail
        M.Fail = function(self, id) seen[id] = seen[id] or "fail" return true end
        for _, t in ipairs({ "T293", "T300", "T301", "T302", "T303", "T304", "T307" }) do pcall(IMPL[t]) end
        -- Talent-Vorschlag (CheckTalents mit einem freien Punkt und einem Vorschlag)
        LP.db.advTalents = true
        LP.API.TalentPoints = function() return 1 end
        LP.Advisor.TalentNext = function() return "Testtalent", 1, 5, "Test" end
        pcall(Collect, LP.Advisor.CheckTalents)
        LP.API.TalentPoints, LP.Advisor.TalentNext, LP.db.advTalents = saved.tp, saved.tn, saved.adv
        -- Wegmessung vollständig (eigenes Mess-Werkzeug, 12 Markierungen, kein Lauf übersprungen)
        local WM = LP.WegMessung
        local running = false
        local tool = { Running = function() return running end, Start = function() running = true end,
                       Stop = function() running = false end, Mark = function() return running end }
        local realTool, realShow, realGuidePrio, realReplan = WM.Tool, WM.Show, LP.Planner.priority, LP.Planner.Replan
        WM.Tool, WM.Show, LP.Planner.Replan = function() return tool end, function() end, function() end
        LP.Reply = function() end
        pcall(function()
            WM:Start()
            for _ = 1, WM.StepCount() do WM:Mark() end
        end)
        WM.Tool, WM.Show, LP.Planner.priority, LP.Planner.Replan, WM.state = realTool, realShow, realGuidePrio, realReplan, nil
        r.wmSteps = WM.StepCount()
        -- Unterstadt: bekannter Weg (graph) in Karte 1458; Gegenprobe: "Weg unbekannt" bzw. andere Karte meldet nichts
        LP.Geo.Player = function() return 1, 0, 0, 1458 end
        local nav = LP.Nav
        r.navNo = nav.PLWeg("  (Weg unbekannt)", "graph", 200) == false and nav.PLWeg("", "direct", 200) == false
        LP.Geo.Player = function() return 1, 0, 0, 1454 end
        r.navNo = r.navNo and nav.PLWeg("", "graph", 200) == false and seen["UC-W1"] == nil
        LP.Geo.Player = function() return 1, 0, 0, 1458 end
        nav.PLWeg("", "graph", 200)
        LP.Geo.Player = saved.player
        -- Protokoll: Speicher-Messung, Krieger 60 s, Allianz-Planung (20 ms = zu langsam), 2 Stunden Spiel
        local now = GetTime and GetTime() or 0
        LP.Perf = { stats = { route = { n = 4, max = 20, ln = 1, lms = 300 }, ui = { n = 9, max = 2, ln = 3, lms = 200 } },
                    loginT = now - 8000, FRAME_MS = 16 }
        LP.Protocol.MemInfo = function() return { ms = 12 } end
        LP.PlayerFaction = function() return "Alliance" end
        r.loginMs = M.LoginMs()
        pcall(WithEnv, { M.OnProtocol }, { UnitClass = function() return "Krieger", "WARRIOR" end }, function() M:OnProtocol() return true end)
        LP.Perf, LP.Protocol.MemInfo, LP.PlayerFaction = saved.perf, saved.mem, saved.fac
        M.Fail = fakeFail
        -- Testroutine (trocken) meldet nie etwas: echte Sperre M.Dry mit LP.Act.dry = true
        M.Dry = saved.dry
        local wasDry = LP.Act.dry
        LP.Act.dry = true
        seen.DRY = nil
        r.dry = M:Hit("T300", "trocken") == false and M:Fail("PF-A", "trocken") == false
        LP.Act.dry = wasDry
        local miss = {}
        for _, p in ipairs(M.POINTS) do if not seen[p.id] then miss[#miss + 1] = p.id end end
        r.miss = table.concat(miss, ",")
        r.pfa = seen["PF-A"]
        return true
    end)
    M.list, M.nextTry, M.DB, M.Dry, M.Points = saved.list, saved.next, saved.db, saved.dry, saved.pts
    if PL.lists then PL.lists.LevelPilot = saved.reg end
    LP.Perf, LP.Protocol.MemInfo, LP.PlayerFaction, LP.Geo.Player = saved.perf, saved.mem, saved.fac, saved.player
    LP.API.TalentPoints, LP.Advisor.TalentNext, LP.db.advTalents, LP.Reply = saved.tp, saved.tn, saved.adv, saved.reply
    if not ok then error(err, 0) end
    local good = r.offList and r.offHit and r.offReport and r.offStore and r.on and r.n == 14 and r.full == 14 and r.fail
        and r.failAgain and r.head:find("0 von 14", 1, true) ~= nil and r.lines == 15 and r.stored and r.navNo and r.miss == ""
        and r.pfa == "fail" and r.loginMs == 500 and r.wmSteps == 12 and r.dry
    return good and true or false, ("ohne Testmodus: Liste %s, Meldung %s, Bericht leer %s, nichts gespeichert %s · mit: angemeldet %s, Punkte %s (vollständig %s), Fehler %s/doppelt %s, „%s“ (%s Zeilen), gespeichert %s · Unterstadt-Gegenprobe %s · nicht ausgelöst: „%s“ · PF-A %s · 60 s %s ms · Wegmessung %s Schritte · trocken gesperrt %s")
        :format(S(r.offList), S(r.offHit), S(r.offReport), S(r.offStore), S(r.on), S(r.n), S(r.full), S(r.fail), S(r.failAgain),
            tostring(r.head), S(r.lines), S(r.stored), S(r.navNo), tostring(r.miss), tostring(r.pfa), S(r.loginMs), S(r.wmSteps), S(r.dry)),
        "true ×4 · true, 14 (14), true/true, „PRÜFLISTE LevelPilot: 0 von 14 erledigt“ (15), true · true · „“ · fail · 500 · 12 · true"
end
CLIENT.T309 = "/lp prüfliste (nur Testmodus): Fenster „Prüfliste LevelPilot 3.12.47 – 0 von 14 erledigt“, unten die Anweisung zum ersten Punkt; /afk draussen -> T300 springt auf „erledigt (erkannt)“ und eine Chatzeile erscheint"

-- LW-6: Laufweg-Messung mit gespielter Folge (Werte direkt an LW:Sample, eigene Charakter-Tabelle statt LevelPilotCharDB)
IMPL.T310 = function()
    local LW = LP.Laufweg
    if not (LW and LW.Sample and LW.Lines and LW.Store) then return false, "Laufweg fehlt", "vorhanden" end
    local saved = { char = LP.char, cur = LW.cur, last = LW.last }
    local r = {}
    local ok, err = pcall(function()
        LP.char = {}
        LW.cur, LW.last = nil, nil
        local t, pos = 0, { 0, 0 }
        local planned = {}
        local function tick(dt, o)
            t = t + dt
            o = o or {}
            o.now, o.inst, o.n, o.w, o.map = t, 1, o.n or pos[1], o.w or pos[2], 1413
            o.level, o.xp, o.xpMax = o.level or 10, o.xp, o.xpMax or 1000
            o.planned = function(k) return planned[k] == true end
            pos = { o.n, o.w }
            LW:Sample(o)
        end
        local A = { key = "A", t = "COMPLETE", inst = 1, n = 0, w = 300 }
        local B = { key = "B", t = "TURNIN", inst = 1, n = 0, w = 900 }
        local C = { key = "C", t = "ACCEPT", inst = 1, n = 0, w = -900 }
        -- A: 300 yd Luftlinie, 30 s geradeaus mit 10 yd/s (Pfad Netz), Ankunft bei 260 (40 yd), dann 20 s am Ziel
        planned.A = true
        tick(0, { step = A, xp = 100 })
        for i = 1, 30 do tick(1, { step = A, w = i * 10, kind = "graph", xp = 100 + i * 10 }) end
        for _ = 1, 20 do tick(1, { step = A, w = 300, kind = "graph", xp = 400 }) end
        -- A erledigt (nicht mehr geplant) -> B; 12 s Richtung B, dann Neuplanung auf C (entgegengesetzt), B bleibt geplant
        planned.A, planned.B = nil, true
        for i = 1, 12 do tick(1, { step = B, w = 300 + i * 5, kind = "terrain", xp = 400 }) end
        planned.C = true
        tick(1, { step = C, w = 360, xp = 400 })
        -- C: Sprung (500 yd in 1 s), Flug (taxi), AFK, Lücke (10 s) – zählen nicht als gelaufen
        tick(1, { step = C, w = -140, unknown = true, xp = 400 })
        for i = 1, 5 do tick(1, { step = C, w = -140 - i * 50, taxi = true, kind = "direct", xp = 400 }) end
        for _ = 1, 4 do tick(1, { step = C, w = -390, afk = true, xp = 400 }) end
        tick(10, { step = C, w = -390, xp = 400 })
        for i = 1, 6 do tick(1, { step = C, w = -390 - i * 10, kind = "direct", xp = 900 }) end
        -- Levelaufstieg: 900 -> Level 11 mit 50 EP (Level 10 bekommt die restlichen 100)
        tick(1, { step = C, w = -460, level = 11, xp = 50 })
        r.gelC = LW.cur and LW.cur.key == "C" and LW.cur.gel        -- nur 6×10 + 10 beim Levelaufstieg (ohne Sprung 500, Flug 250)
        -- Leerlauf: 7 s ohne Schritt mit Ziel (C wird dabei abgeschlossen)
        planned.C = nil
        for _ = 1, 7 do tick(1, { step = { key = "NODATA", t = "LEVEL" }, w = -460, level = 11, xp = 50 }) end
        local s = LW.Store()
        local z = s.z[1413] or { k = {} }
        r.n, r.a, r.luftA, r.gelA, r.tw, r.tz = z.n, z.a, z.luftA, z.gelA, z.tw, z.tz
        r.netz, r.gel, r.unb = z.k.netz or 0, z.k.gel or 0, z.k.unb or 0
        r.replans, r.rev, r.idle = s.replans, s.rev, s.idle
        r.l10, r.l11 = s.lvl[10] and s.lvl[10].xp, s.lvl[11] and s.lvl[11].xp
        r.s10 = s.lvl[10] and s.lvl[10].s
        local lines = LW.Lines(s)
        r.lines = #lines
        r.first = lines[1]
        r.umweg = tostring(lines[1]):find("Umweg gelaufen/Luftlinie 0,87", 1, true) ~= nil
        r.zone = tostring(lines[4]):find("(3, ", 1, true) ~= nil
        r.eph = tostring(lines[5]):find("^EP/h je Level") ~= nil
        r.diff = LW.Diff(170, -170) == 20 and LW.Diff(0, 180) == 180
        return true
    end)
    LP.char, LW.cur, LW.last = saved.char, saved.cur, saved.last
    if not ok then error(err, 0) end
    -- erwartet: A (Start bei 0, Luftlinie 300, Ankunft in Sekunde 26 bei 260 yd = 40 yd vor dem Ziel: gelaufen 260, Weg 25 s,
    -- die Sekunde der Ankunft und die 24 danach am Ziel = 25 s), B (12 s Weg, Gelände), C (Weg 1 + 1 Sprung + 5 Flug + 6 + 1 s;
    -- AFK und die Lücke zählen nicht). EP Level 10: 300 + 500 + 100 = 900, Level 11: 50
    local good = r.n == 3 and r.a == 1 and r.luftA == 300 and r.gelA == 260 and r.tw == 25 + 12 + 14 and r.tz == 25
        and r.netz == 25 and r.gel == 12 and r.unb == 1 and r.replans == 1 and r.rev == 1 and r.idle == 7
        and r.l10 == 900 and r.l11 == 50 and r.gelC == 70 and r.lines == 6 and r.umweg and r.zone and r.eph and r.diff
    return good and true or false, ("Schritte %s (angekommen %s) · Luftlinie %s gelaufen %s · Zeit Weg %s / Ziel %s · Netz %s s Gelände %s s unbekannt %s s · Neuplanungen %s Richtungswechsel %s · Leerlauf %s s · EP L10 %s L11 %s (L10 %s s) · C gelaufen %s · Zeilen %s, Umweg 0,87 %s, Zone %s, EP/h %s, Winkel %s")
        :format(S(r.n), S(r.a), S(r.luftA), S(r.gelA), S(r.tw), S(r.tz), S(r.netz), S(r.gel), S(r.unb), S(r.replans), S(r.rev), S(r.idle),
            S(r.l10), S(r.l11), S(r.s10), S(r.gelC), S(r.lines), S(r.umweg), S(r.zone), S(r.eph), S(r.diff)),
        "3 (1) · 300 / 260 · 51 / 25 · 25 / 12 / 1 · 1 / 1 · 7 · 900 / 50 · C 70 · 6, true ×5"
end
CLIENT.T310 = "Nach einer Spielstunde /lp protokoll: Zeilen „LAUFWEG …“ (Schritte, Umweg, Zeit Weg/Ziel, Pfad, Neuplanungen, je Zone) und „EP/h je Level“ mit plausiblen Zahlen"

-- LW-3: Flug nach Zeit. Zahlen (Umweg 1,25, Gespräch 15 s, Vorsprung 30 s):
--  B Reittier 14 yd/s, Luftlinie 2600, je 500 yd zum/vom Flugmeister, Flug 1800 yd (Annahme 30 + 1800×1,3/32 = 103,1 s):
--    laufen 232,1 s · fliegen 89,3 + 15 + 103,1 = 207,4 s (+30 = 237,4 > 232,1) -> LAUFEN; alte Regel 1000×1,25+300 = 1550 < 2600 = Flug
--  C zu Fuss 7 yd/s, Luftlinie 2500, je 900 yd, Flug gemessen 60 s: laufen 446,4 s · fliegen 321,4 + 15 + 60 = 396,4 (+30 = 426,4
--    < 446,4) -> FLUG; alte Regel 1800×1,25+300 = 2550 >= 2500 = laufen
IMPL.T311 = function()
    local P, Geo = LP.Planner, LP.Geo
    if not (P.FlyDecision and P.GroundYps and P.FlightSecs and LP.Laufweg and LP.Laufweg.MountSpeed) then return false, "LW-3 fehlt", "vorhanden" end
    local saved = { char = LP.char, taxi = LP.db.taxi, tp = Geo.TaxiPoint, fs = LP.Calib.FlightSecs, last = P.lastTravel }
    local r = {}
    local ok, err = pcall(function()
        LP.char = { taxiKnown = {} }
        -- Tempo
        r.foot = P.GroundYps() == 7
        r.m1 = LP.Laufweg.MountSpeed(11.2) == true and LP.char.mountYps == 11.2
        r.m2 = LP.Laufweg.MountSpeed(30) == false and LP.Laufweg.MountSpeed(6) == false and LP.Laufweg.MountSpeed(9) == false
        r.m3 = LP.Laufweg.MountSpeed(14) == true and P.GroundYps() == 14
        -- Flugzeit: Annahme ohne Messung, sonst gemessen
        LP.Calib.FlightSecs = function() return nil end
        local a, asrc = P.FlightSecs(1800)
        r.ann = math.abs(a - (30 + 1800 * 1.3 / 32)) < 0.01 and asrc == "Annahme"
        LP.Calib.FlightSecs = function(_, d) return d / 30 end
        local g, gsrc = P.FlightSecs(1800)
        r.mes = g == 60 and gsrc == "gemessen"
        -- Entscheid als Zahl
        local fb, wb, flb = P.FlyDecision(2600, 500, 500, 30 + 1800 * 1.3 / 32, 14)
        r.b = fb == false and math.abs(wb - 232.14) < 0.01 and math.abs(flb - 207.41) < 0.01
        local fc, wc, flc = P.FlyDecision(2500, 900, 900, 60, 7)
        r.c = fc == true and math.abs(wc - 446.43) < 0.01 and math.abs(flc - 396.43) < 0.01
        -- in TravelSteps (zwei Flugmeister auf einer Linie, Ziel dahinter)
        local A = { name = "LPTestFP-A", n = 0, w = 500 }
        local B = { name = "LPTestFP-B", n = 0, w = 2300 }
        LP.db.taxi = { a = A, b = B }
        LP.char.taxiKnown = { a = true, b = true }
        Geo.TaxiPoint = function(_, tx) if tx then return 1413, 50, 50, 1, tx.n, tx.w end end
        -- B: Reittier 14, Start (0, 0), Flugmeister (0, 500) und (0, 2300) = 1800 yd Flug (Annahme), Ziel (424, 2565,2):
        -- Luftlinie 2600, vom Flugmeister 500 -> genau Fall B oben -> laufen
        LP.Calib.FlightSecs = function() return nil end
        local stB = P:TravelSteps({ inst = 1, n = 424.0, w = 2565.2 }, 1, 0, 0)
        r.geoB = math.abs(Geo:Dist(0, 0, 424.0, 2565.2) - 2600) < 0.5 and math.abs(Geo:Dist(0, 2300, 424.0, 2565.2) - 500) < 0.5
        r.tsB = #stB == 0 and P.lastTravel and P.lastTravel.took == false
        -- C: zu Fuss, Luftlinie 2500 (Flugmeister je 900), Flug gemessen 60 s -> Flug
        LP.char.mountYps = nil
        A.w, B.w = 900, 2200
        LP.Calib.FlightSecs = function() return 60 end
        local stC = P:TravelSteps({ inst = 1, n = 0, w = 2500 + 0 }, 1, 0, 0)
        -- Ziel 2500, Start 0: zum Flugmeister 900, vom Flugmeister 300 – andere Zahlen: laufen 446,4 · fliegen 1200×1,25/7 + 15 + 60 = 289,3
        r.tsC = #stC == 2 and stC[1].t == "GOTO" and stC[2].t == "FLY" and P.lastTravel.took == true and P.lastTravel.fsrc == "gemessen"
        r.lines = table.concat(LP.Laufweg.Lines({ v = 1, since = "x", z = {}, rev = 0, replans = 0, idle = 0, lvl = {} }), "\n"):find("REISE letzter Flugvergleich: Laufen 446 s · Fliegen 289 s (Flugzeit gemessen) -> Flug", 1, true) ~= nil
        return true
    end)
    LP.char, LP.db.taxi, Geo.TaxiPoint, LP.Calib.FlightSecs, P.lastTravel = saved.char, saved.taxi, saved.tp, saved.fs, saved.last
    if not ok then error(err, 0) end
    local good = r.foot and r.m1 and r.m2 and r.m3 and r.ann and r.mes and r.b and r.c and r.geoB and r.tsB and r.tsC and r.lines
    return good and true or false, ("zu Fuss 7 %s · Reittier 11,2 %s · unplausibel abgelehnt %s · 14 %s · Flugzeit Annahme %s / gemessen %s · B Reittier: laufen %s · C zu Fuss: Flug %s · Planung B ohne Flug %s · Planung C Flugmeister+Flug %s · Protokollzeile %s")
        :format(S(r.foot), S(r.m1), S(r.m2), S(r.m3), S(r.ann), S(r.mes), S(r.b), S(r.c), S(r.tsB), S(r.tsC), S(r.lines)),
        "true ×11 (dazu Geometrie Fall B geprüft)"
end
-- 3.12.50 ST-2: Strassen des eigenen Kontinents (im Spiel: echte Zonen über C_Map.GetMapInfoAtPosition)
IMPL.T312 = function()
    local G, Geo, N = LP.Graph, LP.Geo, LP.Nav
    if not (G.LoadRoads and G.RoadText and Geo.ZoneAt) then return false, "Strassen fehlen", "vorhanden" end
    if not G.RoadsAktiv() then return NA, "weder WoW Forever noch Classic Era – Strassen absichtlich aus" end
    if not (C_Map and C_Map.GetMapInfoAtPosition) then return NA, "C_Map.GetMapInfoAtPosition fehlt – Zonen der Strassen unbekannt" end
    local R, welche = G.RoadData()
    local inst = Geo:Player()
    local k = R and R.karten and inst ~= nil and R.karten[inst]
    if not k then return NA, "keine Strassen für diesen Kontinent (" .. tostring(inst) .. ")" end
    local st = G.roadStat and G.roadStat[inst]
    if not st then return false, "nicht geladen", "geladen" end
    if not st.fertig then return NA, "wird noch geladen" end
    local saved = 0
    for _, e in pairs(LP.db.graph.edges or {}) do if e[3] == "road" then saved = saved + 1 end end
    -- Weg entlang der längsten Strasse dieses Kontinents (3. bis drittletzter Punkt)
    local best, bl
    for _, line in ipairs(k.e) do
        local l = 0
        for j = 2, #line do l = l + Geo:Dist(k.p[2 * line[j - 1] - 1], k.p[2 * line[j - 1]], k.p[2 * line[j] - 1], k.p[2 * line[j]]) end
        if #line >= 8 and (not bl or l > bl) then best, bl = line, l end
    end
    local road, len = 0, 0
    if best then
        local a, b = best[3], best[#best - 2]
        local an, aw, bn, bw = k.p[2 * a - 1], k.p[2 * a], k.p[2 * b - 1], k.p[2 * b]
        local za, zb = Geo:ZoneAt(inst, an, aw), Geo:ZoneAt(inst, bn, bw)
        local p = za and zb and G:Path(inst, an, aw, za, inst, bn, bw, zb)
        if p then for i = 2, #p do
            local d = Geo:Dist(p[i - 1][2], p[i - 1][3], p[i][2], p[i][3])
            len = len + d
            if p[i].via == "road" then road = road + d end
        end end
    end
    local share = len > 0 and road / len or 0
    local ok = st.kanten > 0 and st.ohneZone * 10 < st.knoten and saved == 0 and share >= 0.5
    return ok, ("%s · gespeichert %d · Weg auf der längsten Strasse: %d yd, davon Strasse %d %%"):format(G.RoadText(), saved,
        math.floor(len + 0.5), math.floor(share * 100 + 0.5)), "Kanten > 0 · ohne Zone < 10 % · gespeichert 0 · Strasse ≥ 50 %"
end
-- 3.12.51 LW-1: Umweg-Faktor und Reihenfolge. Ziel A 500 yd in einer Zone mit Umweg 1,8 (= 900 yd Weg), Ziel B 700 yd in
-- einer Zone mit Umweg 1,0 (= 700 yd Weg): mit Wegkosten zuerst B, mit reiner Luftlinie (vorher) zuerst A.
IMPL.T313 = function()
    local G, P = LP.Graph, LP.Planner
    if not (G.Detour and G.DetourOf and P.WayFactor and P.OPT) then return false, "LW-1 fehlt", "vorhanden" end
    local saved = { det = G.detour, opt = P.OPT.wayCost }
    local r = {}
    local ok, err = pcall(function()
        r.med = G.DetourOf({ 1.1, 1.3, 1.2, 2.5, 1.0 }) == 1.2
        r.even = math.abs(G.DetourOf({ 1.1, 1.3, 1.2, 1.4, 1.0, 1.5 }) - 1.25) < 1e-9
        r.cap = G.DetourOf({ 3, 3, 3, 3, 3 }) == G.DETOUR_MAX and G.DetourOf({ 0.9, 0.9, 0.9, 0.9, 0.9 }) == G.DETOUR_MIN
        r.few = G.DetourOf({ 1.2, 1.3 }) == nil
        G.detour = { [99001] = { f = 1.8, n = 12 }, [99002] = { f = 1.0, n = 12 } }
        local f0, n0 = G:Detour(nil)
        r.def = f0 == G.DETOUR_DEFAULT and n0 == 0
        r.zone = G:Detour(99001) == 1.8 and P.WayFactor(99002) == 1.0
        local A = { t = "COMPLETE", id = 990001, key = "T313A", inst = 1, n = 500, w = 0, map = 99001, value = 1 }
        local B = { t = "COMPLETE", id = 990002, key = "T313B", inst = 1, n = -700, w = 0, map = 99002, value = 1 }
        P.OPT.wayCost = true
        local o1 = P:Order({ A, B }, 1, 0, 0)
        P.OPT.wayCost = false
        local o2 = P:Order({ A, B }, 1, 0, 0)
        r.first1, r.first2 = o1[1] and o1[1].key, o2[1] and o2[1].key
        r.off = P.WayFactor(99001) == 1
        return true
    end)
    G.detour, P.OPT.wayCost = saved.det, saved.opt
    if not ok then error(err, 0) end
    local good = r.med and r.even and r.cap and r.few and r.def and r.zone and r.first1 == "T313B" and r.first2 == "T313A" and r.off
    return good and true or false, ("Median %s (gerade Anzahl %s) · Grenzen %s · zu wenig Paare %s · ohne Zone Annahme %s · je Zone %s · mit Wegkosten zuerst %s · Luftlinie (vorher) zuerst %s · Schalter aus = 1 %s")
        :format(S(r.med), S(r.even), S(r.cap), S(r.few), S(r.def), S(r.zone), tostring(r.first1), tostring(r.first2), S(r.off)),
        "true ×6 · T313B · T313A · true"
end
-- 3.12.54 NAV-1a: eigene Kartennamen/Spielerort/Dienste nur über die eigenen Tabellen von LevelPilot ersetzt (immer zurück)
IMPL.T314 = function()
    local C, Geo, Q, P, G = LP.Comfort, LP.Geo, LP.QuestDB, LP.Planner, LP.Graph
    if not (C.Navi and C.ZoneByName and Q.NearestService) then return false, "Navi fehlt", "vorhanden" end
    local saved = { mn = Geo.MapName, zn = LP.Names and LP.Names.Zone, rep = P.Replan, prio = P.priority, reply = LP.Reply,
                    find = C.Find, sv = Q.ServiceNPCs, pl = Geo.Player, tw = Geo.ToWorld, det = G.detour, wc = P.OPT.wayCost }
    local NAMES = { [1413] = "Brachland", [1412] = "Mulgore", [1454] = "Orgrimmar" }
    local r, replies, found = {}, {}, {}
    local ok, err = pcall(function()
        Geo.MapName = function(_, m) return NAMES[m] or tostring(m) end
        if LP.Names then LP.Names.Zone = function() return nil end end
        P.Replan = function() end
        LP.Reply = function(_, m) replies[#replies + 1] = m end
        r.z1 = C.ZoneByName("Brachland") == 1413 and C.ZoneByName("  BRACHLAND ") == 1413
        r.z2 = C.ZoneByName("mul") == 1412 and C.ZoneByName("xyz") == nil and C.ZoneByName("") == nil
        P.priority = nil
        local kind, map = C:Navi("45 60 brachland")
        r.nav = kind == "weg" and map == 1413 and P.priority and P.priority.key == "WAY:1413:45.0:60.0"
        r.off = C:Navi("aus") == "aus" and P.priority == nil
        local n0 = #replies
        r.off2 = C:Navi("off") == "aus" and #replies == n0 + 1
        C:Navi("120 5")
        r.bad = P.priority == nil
        C:Navi("45 60 nirgendwo")
        r.nozone = P.priority == nil and tostring(replies[#replies]):find("nirgendwo", 1, true) ~= nil
        C.Find = function(_, k) found[#found + 1] = k end
        C:Navi("repair") C:Navi("Reparatur") C:Navi("mailbox") C:Navi("gasthaus")
        r.words = table.concat(found, ",")
        -- nächster Dienst nach Wegkosten: A 500 yd in Zone mit Umweg 1,8, B 700 yd in Zone mit Umweg 1,0
        Geo.Player = function() return 1, 0, 0, 1413 end
        Geo.ToWorld = function(_, m, x, y) return 1, x, y end
        Q.ServiceNPCs = function() return { vendor = { { name = "A", map = 99001, x = 500, y = 0 }, { name = "B", map = 99002, x = -700, y = 0 } } } end
        G.detour = { [99001] = { f = 1.8, n = 12 }, [99002] = { f = 1.0, n = 12 } }
        P.OPT.wayCost = true
        local v1, d1 = Q:NearestService("vendor")
        P.OPT.wayCost = false
        local v2 = Q:NearestService("vendor")
        r.svc = v1 and v1.name == "B" and d1 == 700 and v2 and v2.name == "A"
        return true
    end)
    Geo.MapName, P.Replan, P.priority, LP.Reply, C.Find = saved.mn, saved.rep, saved.prio, saved.reply, saved.find
    if LP.Names then LP.Names.Zone = saved.zn end
    Q.ServiceNPCs, Geo.Player, Geo.ToWorld, G.detour, P.OPT.wayCost = saved.sv, saved.pl, saved.tw, saved.det, saved.wc
    if not ok then error(err, 0) end
    local good = r.z1 and r.z2 and r.nav and r.off and r.off2 and r.bad and r.nozone and r.words == "repair,repair,mailbox,inn" and r.svc
    return good and true or false, ("Zone genau %s · Anfang/unbekannt %s · navi 45 60 brachland %s · aus %s · aus ohne Ziel %s · ungültig %s · Zone fehlt %s · Dienstwörter „%s“ · nächster Händler nach Wegkosten %s")
        :format(S(r.z1), S(r.z2), S(r.nav), S(r.off), S(r.off2), S(r.bad), S(r.nozone), tostring(r.words), S(r.svc)),
        "true ×7 · repair,repair,mailbox,inn · true"
end
-- 3.12.55 LW-5 E2: eigenes Paket im Test (nie LevelPilotData), Spielversion über GoldSentinelGame.SetTestFlavor (WithFlavor)
IMPL.T315 = function()
    local Geo, Q = LP.Geo, LP.QuestDB
    if not (Geo.FromData and Geo.ToData and Q.EraUnconvert and LP.CaveForeverMaps) then return false, "LW-5 E2 fehlt", "vorhanden" end
    local t = LP.CaveForeverMaps[1412]
    local fx, fy = 44.2, 76.1                                  -- Forever-Kartenpunkt in Mulgore
    local ex, ey = (fx - t[2]) / t[1], (fy - t[4]) / t[3]       -- erwartet in Classic-Grenzen
    local function fake()
        return { N = { [1] = { s = { { 1412, fx, fy, 50, 50 }, { 1413, 1, 2 } } }, [10666] = { s = { { 1420, 52.8, 54.2 } } } },
                 O = { [2] = { s = { { 1433, 10, 10 } } } }, Q = { [5] = { ob = { e = { "x", { { 1453, 10, 20 } } } } } },
                 D = { [9] = { e = { { 1423, 30, 40 } } } }, MB = { { 1433, 5, 6 }, { 1411, 5, 6 } } }
    end
    local r = {}
    WithFlavor("forever", function()
        local x, y = Geo:FromData(1412, fx, fy)
        r.fv = x == fx and y == fy and Geo.EraFrame() == false
        local d = fake()
        r.fvPack = Q.EraUnconvert(d) == 0 and d.N[1].s[1][2] == fx and d.N[10666].s[1][2] == 52.8
    end)
    WithFlavor("era", function()
        local x, y = Geo:FromData(1412, fx, fy)
        r.era = math.abs(x - ex) < 1e-9 and math.abs(y - ey) < 1e-9 and Geo.EraFrame() == true
        local bx, by = Geo:ToData(1412, x, y)
        r.round = math.abs(bx - fx) < 1e-9 and math.abs(by - fy) < 1e-9
        local ox, oy = Geo:FromData(1413, 33.3, 44.4)
        r.other = ox == 33.3 and oy == 44.4
        local d = fake()
        local n = Q.EraUnconvert(d)
        r.n = n
        r.pack = math.abs(d.N[1].s[1][2] - ex) < 1e-9 and d.N[1].s[2][2] == 1 and d.MB[2][2] == 5
            and math.abs(d.D[9].e[1][2] - (30 - LP.CaveForeverMaps[1423][2]) / LP.CaveForeverMaps[1423][1]) < 1e-9
        r.npc = d.N[10666].s[1][2] == 43.1 and d.N[10666].s[1][3] == 54.7
        r.again = Q.EraUnconvert(d) == 0
    end)
    local good = r.fv and r.fvPack and r.era and r.round and r.other and r.n == 6 and r.pack and r.npc and r.again
    return good and true or false, ("Forever unverändert %s (Paket %s) · Era Mulgore %.2f/%.2f -> %.2f/%.2f %s · hin und zurück %s · andere Zone %s · Paket: %s Punkte zurückgerechnet, Werte %s · Gordo auf Questie %s · zweimal = nichts %s")
        :format(S(r.fv), S(r.fvPack), fx, fy, ex, ey, S(r.era), S(r.round), S(r.other), S(r.n), S(r.pack), S(r.npc), S(r.again)),
        "true (true) · true · true · true · 6 (NPC 2, Objekt 1, Quest 1, Dungeon 1, Briefkasten 1), true · true · true"
end
-- 3.12.56 LW-5 E3: Wahl des Bereichs (reine Rechnung mit eigenen Tabellen) und Kalibrierung im gewählten Bereich
IMPL.T316 = function()
    if not (LP.ChooseAcc and LP.Acc and LP.Calib and LP.Calib.KillXPRatio) then return false, "LW-5 E3 fehlt", "vorhanden" end
    local r = {}
    local root = { graph = { nodes = { 1 } }, qdb = { 9 } }
    local a, k = LP.ChooseAcc(root, false)
    r.fv = a == root and k == "forever" and root.era == nil
    local e, k2 = LP.ChooseAcc(root, true)
    r.era = e == root.era and k2 == "era" and type(e) == "table" and e.graph == nil and root.graph.nodes[1] == 1
    e.graph = { nodes = { 2 } }
    local e2 = LP.ChooseAcc(root, true)
    r.keep = e2 == e and e2.graph.nodes[1] == 2 and root.graph.nodes[1] == 1
    -- Kalibrierung: liest im festgelegten Bereich (LP.accRoot), nie in einer anderen Tabelle
    local saved = LP.accRoot
    local ok, err = pcall(function()
        LP.accRoot = { calib = { killxp = { [7] = { n = 99, sum = 148.5 } } } }
        local v = LP.Calib:KillXPRatio(7)
        r.calib = v == 1.5
        LP.accRoot = { calib = {} }
        r.calib2 = LP.Calib:KillXPRatio(7) == nil
        -- Sprache und echte Flugpunkte ebenso im Bereich (Era-Befund der Offline-Routine 3.12.56: Sprache aus der Grundtabelle)
        local tx = { ["1:2"] = { 1 } }
        LP.accRoot = { language = (LP:Language() == "fr") and "es" or "fr", taxi = tx }
        r.lang = LP:Language() == LP.accRoot.language
        r.taxi = (LP.Virtual.active and true) or LP.Virtual:RealTaxi() == tx
    end)
    LP.accRoot = saved
    if not ok then error(err, 0) end
    -- ersetzte Grundtabelle (nur Offline-Tests tun das): Bereich der neuen Tabelle, nie die alte
    local savedBase, savedAcc2 = LP.accBase, LP.accRoot
    LP.accBase, LP.accRoot = {}, { stale = true }
    local okB, accB = pcall(LP.Acc)
    LP.accBase, LP.accRoot = savedBase, savedAcc2
    r.base = okB and accB ~= nil and not accB.stale and accB == (LP.ChooseAcc(LevelPilotDB, LP.accKind == "era"))
    r.now = LP.Acc() == (LP.accRoot or LevelPilotDB) and (LP.accKind == "era") == LP.IsEraClient()
    local good = r.fv and r.era and r.keep and r.calib and r.calib2 and r.lang and r.taxi and r.base and r.now
    return good and true or false, ("Forever = Grundtabelle %s · Era = eigener Bereich %s · Era-Daten bleiben, Forever unberührt %s · Kalibrierung im Bereich %s / leer %s · Sprache %s · Flugpunkte %s · ersetzte Grundtabelle %s · jetzt %s (%s)")
        :format(S(r.fv), S(r.era), S(r.keep), S(r.calib), S(r.calib2), S(r.lang), S(r.taxi), S(r.base), S(r.now), tostring(LP.accKind)),
        "true ×9"
end
IMPL.T317 = function()
    local Ce, QDB = LP.Center, LP.QuestDB
    if not (Ce and Ce.ForeverSwitchUseful and Ce.DataHelp and QDB and QDB.IsNewQuest) then return false, "LW-5 E4 fehlt", "vorhanden" end
    local r, savedSet = {}, LP.db.forever
    local ok, err = pcall(function()
        LP.db.forever = true
        WithFlavor("forever", function()
            r.swF = Ce.ForeverSwitchUseful()
            local t = Ce.DataHelp()
            r.helpF = t:find("Forever", 1, true) ~= nil
            r.newF = QDB.IsNewQuest(nil) == (QDB.pack and true or false) and QDB.IsNewQuest({}) == false
        end)
        WithFlavor("era", function()
            r.swE = Ce.ForeverSwitchUseful() == false
            local t = Ce.DataHelp()
            r.helpE = t:find("Forever", 1, true) == nil and #t > 100
            r.newE = QDB.IsNewQuest(nil) == false
        end)
        WithFlavor("tbc", function() r.swT = Ce.ForeverSwitchUseful() == false end)
    end)
    LP.db.forever = savedSet
    if not ok then error(err, 0) end
    local good = r.swF and r.swE and r.swT and r.helpF and r.helpE and r.newF and r.newE
    return good and true or false, ("Schalter Forever %s / Era aus %s / TBC aus %s · Hilfe Forever %s / Era ohne Forever %s · NEU Forever %s / Era nie %s")
        :format(S(r.swF), S(r.swE), S(r.swT), S(r.helpF), S(r.helpE), S(r.newF), S(r.newE)), "true ×7"
end
IMPL.T318 = function()
    local P = LP.Planner
    if not (P and P.TravelPlan and P.PlanText and P.PlanPath) then return false, "NAV-2 fehlt", "vorhanden" end
    local G, Geo, API = LP.Graph, LP.Geo, LP.API
    local o = { path = G.Path, tp = Geo.TaxiPoint, tw = Geo.ToWorld, hr = API.HearthReady, fs = P.FlightSecs,
                known = LP.char.taxiKnown, bind = LP.char.bind, yps = LP.char.mountYps, useH = LP.db.useHearth, taxi = LP.db.taxi }
    local route
    local r = {}
    local function near(a, b) return a and b and math.abs(a - b) < 0.05 end
    local ok, err = pcall(function()
        G.Path = function(_, sI, sn, sw, sZ, gI, gn, gw, gZ)
            if route then return route, "graph" end
            return { { sI, sn, sw, sZ }, { gI, gn, gw, gZ, via = "g" } }, "graph"
        end
        LP.char.taxiKnown, LP.char.mountYps, LP.db.useHearth = {}, nil, false
        local goal = { inst = 1, n = 6000, w = 0, map = 1411 }
        -- 1) Laufen 700 yd · Schiff 300 s · Laufen 350 yd (7 yd/s zu Fuss)
        route = { { 1, 0, 0, 1411 }, { 1, 700, 0, 1411, via = "g" }, { 0, 0, 0, 1429, via = "boat", secs = 300, name = "Test" },
                  { 0, 0, 350, 1429, via = "g" } }
        local p1 = P:TravelPlan(1, 0, 0, 1411, { inst = 0, n = 0, w = 350, map = 1429 })
        local l = p1 and p1.legs or {}
        r.boat = #l == 3 and l[1].k == "walk" and near(l[1].secs, 100) and l[2].k == "boat" and l[2].secs == 300
                 and l[3].k == "walk" and near(l[3].secs, 50) and near(p1.total, 450)
        local txt = P.PlanText(p1) or ""
        r.text = txt:find("7:30", 1, true) ~= nil and txt:find("5:00", 1, true) ~= nil
        route = nil
        -- 2) Flug: Flugmeister je 100 yd von Start und Ziel, Flugzeit 120 s -> 100/7 + 15 + 120 + 100/7 statt 6000/7
        local A, B = { name = "FA", i = 1, n = 100, w = 0 }, { name = "FB", i = 1, n = 5900, w = 0 }
        Geo.TaxiPoint = function(_, tx) if type(tx) == "table" and tx.i then return 1411, 0, 0, tx.i, tx.n, tx.w end end
        P.FlightSecs = function() return 120, "Test" end
        LP.char.taxiKnown, LP.db.taxi = { FA = true, FB = true }, { FA = A, FB = B }
        local p2 = P:TravelPlan(1, 0, 0, 1411, goal)
        l = p2 and p2.legs or {}
        r.fly = #l == 3 and l[1].k == "walk" and l[2].k == "fly" and l[2].to == "FB" and near(l[2].secs, 135)
                and near(p2.total, 200 / 7 + 135)
        LP.char.taxiKnown = {}
        -- 3) Ruhestein: Bindeort 1000 yd vor dem Ziel, bereit -> 10 s + 1000/7 statt 6000/7; nicht bereit -> laufen
        LP.db.useHearth, LP.char.bind = true, { map = 1411, x = 50, y = 50, name = "Gasthaus Test" }
        Geo.ToWorld = function(_, map, x, y) if map == 1411 and x == 50 then return 1, 5000, 0 end return o.tw(Geo, map, x, y) end
        API.HearthReady = function() return true end
        local p3 = P:TravelPlan(1, 0, 0, 1411, goal)
        l = p3 and p3.legs or {}
        r.hearth = p3 and p3.hearth and l[1].k == "hearth" and l[1].secs == 10 and near(p3.total, 10 + 1000 / 7) or false
        API.HearthReady = function() return false end
        local p4 = P:TravelPlan(1, 0, 0, 1411, goal)
        r.noHearth = p4 and not p4.hearth and #p4.legs == 1 and near(p4.total, 6000 / 7) or false
    end)
    G.Path, Geo.TaxiPoint, Geo.ToWorld, API.HearthReady, P.FlightSecs = o.path, o.tp, o.tw, o.hr, o.fs
    LP.char.taxiKnown, LP.char.bind, LP.char.mountYps, LP.db.useHearth, LP.db.taxi = o.known, o.bind, o.yps, o.useH, o.taxi
    if not ok then error(err, 0) end
    local good = r.boat and r.text and r.fly and r.hearth and r.noHearth
    return good and true or false, ("Laufen/Schiff/Laufen 450 s %s · Text %s · Flug %s · Ruhestein %s · nicht bereit -> laufen %s")
        :format(S(r.boat), S(r.text), S(r.fly), S(r.hearth), S(r.noHearth)), "true ×5"
end
IMPL.T319 = function()
    local C, Geo, P = LP.Comfort, LP.Geo, LP.Planner
    if not (C.NameCandidates and C.ShowHits and C.ServiceKind and C.NaviTo) then return false, "NAV-1b fehlt", "vorhanden" end
    local saved = { mn = Geo.MapName, rep = P.Replan, prio = P.priority, reply = LP.Reply, pl = Geo.Player, tw = Geo.ToWorld,
                    hits = C.naviHits, dg = LP.Dungeons }
    local r, replies = {}, {}
    local fac = LP:PlayerFaction() == "Horde" and "H" or "A"
    local foe = fac == "H" and "A" or "H"
    local data = { N = {
        [900001] = { n = "Testgeber Alpha", f = fac, s = { { 99001, 10, 0 }, { 99001, 2, 0 } } },
        [900002] = { n = "Testgeber Beta", f = "AH", s = { { 99001, 30, 0 } } },
        [900003] = { n = "Testgeber Feind", f = foe, s = { { 99001, 1, 0 } } },
        [900004] = { n = "Wildschwein Gamma", s = { { 99001, 50, 0 } } },
    } }
    local ok, err = pcall(function()
        Geo.MapName = function(_, m) return "Testzone" .. tostring(m) end
        Geo.Player = function() return 1, 0, 0, 99001 end
        Geo.ToWorld = function(_, m, x, y) if m == 99001 then return 1, x * 100, y * 100 end return saved.tw(Geo, m, x, y) end
        P.Replan = function() end
        LP.Reply = function(_, m) replies[#replies + 1] = tostring(m) end
        LP.Dungeons = { [99] = { name = "Testgrotte", en = "Test Cave", e = { { 99001, 70, 0 } } } }
        r.words = C.ServiceKind("händler") == "vendor" and C.ServiceKind("trainer") == "trainer" and C.ServiceKind("gasthaus") == "inn"
                  and C.ServiceKind("thrall") == nil
        local c = C.NameCandidates("testgeber", data)
        local keys = {}
        for _, x in ipairs(c) do keys[x.key] = x end
        r.npc = keys.N900001 and keys.N900002 and not keys.N900003 and keys.N900001.x == 2 and true or false
        r.mob = #C.NameCandidates("gamma", data) == 1
        local dg = C.NameCandidates("test cave", data)
        r.dungeon = #dg == 1 and dg[1].kind == "dungeon" and dg[1].x == 70
        r.short = #C.NameCandidates("te", data) == 0
        -- Liste mit 2 Treffern, Wahl per Nummer; ein Treffer -> direkt
        P.priority = nil
        C.ShowHits("testgeber", { keys.N900001, keys.N900002 }, 2)
        r.list = C.naviHits and #C.naviHits == 2 and replies[#replies]:find("2) ", 1, true) ~= nil and P.priority == nil
        r.pick = C:Navi("2") == "treffer" and P.priority and P.priority.key == "PRIO:navi:N900002" and true or false
        r.off = C:Navi("aus") == "aus" and P.priority == nil
        C.ShowHits("gamma", { C.NameCandidates("gamma", data)[1] }, 1)
        r.single = P.priority and P.priority.key == "PRIO:navi:N900004" and C.naviHits == nil and true or false
        C.ShowHits("nix", {}, 0)
        r.none = replies[#replies]:find("nix", 1, true) ~= nil
    end)
    Geo.MapName, P.Replan, P.priority, LP.Reply, Geo.Player, Geo.ToWorld = saved.mn, saved.rep, saved.prio, saved.reply, saved.pl, saved.tw
    C.naviHits, LP.Dungeons = saved.hits, saved.dg
    if not ok then error(err, 0) end
    local good = r.words and r.npc and r.mob and r.dungeon and r.short and r.list and r.pick and r.off and r.single and r.none
    return good and true or false, ("Dienstwörter %s · NPC nächster Fundort, ohne feindliche %s · Gegner %s · Dungeon %s · zu kurz %s · Liste %s · Nummer %s · aus %s · ein Treffer direkt %s · nichts gefunden %s")
        :format(S(r.words), S(r.npc), S(r.mob), S(r.dungeon), S(r.short), S(r.list), S(r.pick), S(r.off), S(r.single), S(r.none)), "true ×10"
end
IMPL.T320 = function()
    local C, Geo, P = LP.Comfort, LP.Geo, LP.Planner
    if not C.OnUserWaypoint then return false, "NAV-1c fehlt", "vorhanden" end
    -- C_Map ist eine Blizzard-Tabelle: nie ändern. Die Markierung kommt über eine eigene Ersatz-Umgebung (WithEnv).
    local wp
    local fakeMap = setmetatable({ GetUserWaypoint = function() return wp end }, { __index = C_Map })
    local saved = { rep = P.Replan, prio = P.priority, reply = LP.Reply, set = LP.db.naviMapPin, mn = Geo.MapName }
    local r, replies = {}, {}
    local ok, err = pcall(function()
        P.Replan = function() end
        LP.Reply = function(_, m) replies[#replies + 1] = tostring(m) end
        Geo.MapName = function(_, m) return "Testzone" .. tostring(m) end
        LP.db.naviMapPin = true
        P.priority = nil
        local function fire() return WithEnv({ C.OnUserWaypoint }, { C_Map = fakeMap }, function() return C.OnUserWaypoint() end) end
        wp = { uiMapID = 1411, position = { x = 0.452, y = 0.607 } }
        local k1 = fire()
        r.set = k1 == "pin" and P.priority and P.priority.key == "PRIO:navi:PIN:1411:45.2:60.7" and true or false
        local n = #replies
        r.once = fire() == nil and #replies == n
        wp = { uiMapID = 1411, position = { GetXY = function() return 0.5, 0.25 end } }
        r.xy = fire() == "pin" and P.priority and P.priority.key == "PRIO:navi:PIN:1411:50.0:25.0" and true or false
        wp = nil
        r.clear = fire() == "aus" and P.priority == nil
        P.priority = { key = "WAY:1:1:1", t = "GOTO" }
        r.keepOther = fire() == nil and P.priority and P.priority.key == "WAY:1:1:1" and true or false
        LP.db.naviMapPin = false
        wp = { uiMapID = 1411, position = { x = 0.1, y = 0.1 } }
        r.off = fire() == nil and P.priority and P.priority.key == "WAY:1:1:1" and true or false
    end)
    P.Replan, P.priority, LP.Reply, LP.db.naviMapPin, Geo.MapName = saved.rep, saved.prio, saved.reply, saved.set, saved.mn
    if not ok then error(err, 0) end
    local good = r.set and r.once and r.xy and r.clear and r.keepOther and r.off
    return good and true or false, ("Markierung -> Ziel %s · doppelt nur einmal %s · Vector2D %s · entfernt -> Ende %s · anderes Ziel bleibt %s · Schalter aus %s · Ereignis im Client %s")
        :format(S(r.set), S(r.once), S(r.xy), S(r.clear), S(r.keepOther), S(r.off), S(C.pinEvent)), "true ×6"
end
IMPL.T321 = function()
    local P = LP.Planner
    if not (P.ExactOrder and P.ValidOrder) then return false, "LW-2a fehlt", "vorhanden" end
    local savedWC = P.OPT.wayCost
    local r = {}
    local function T(t, id, x) return { t = t, id = id, inst = 1, n = x, w = 0 } end
    local function keys(list) local o = {} for i, t in ipairs(list) do o[i] = t.t:sub(1, 1) .. (t.id or "") .. "@" .. t.n end return table.concat(o, " ") end
    local ok, err = pcall(function()
        P.OPT.wayCost = false                                   -- reine Luftlinie: Zahlen im Test genau
        -- 1) Linie: Start 0, erster Schritt 50, dann 400/100/300/200 -> 100/200/300/400 (Kette ab Schritt 1: 950 -> 350)
        local l1 = { T("COMPLETE", 1, 50), T("COMPLETE", 2, 400), T("COMPLETE", 3, 100), T("COMPLETE", 4, 300), T("COMPLETE", 5, 200) }
        local changed, old, new = P:ExactOrder(l1, 1, 0, 0, 10)
        r.line = changed and keys(l1) == "C1@50 C3@100 C5@200 C4@300 C2@400" and math.abs(old - 950) < 0.01 and math.abs(new - 350) < 0.01
        -- 2) Abgabe erst nach Annahme derselben Quest (Abgabe liegt näher)
        local l2 = { T("COMPLETE", 1, 50), T("ACCEPT", 7, 400), T("TURNIN", 7, 100), T("COMPLETE", 2, 300), T("COMPLETE", 3, 200) }
        P:ExactOrder(l2, 1, 0, 0, 10)
        local posA, posT
        for i, t in ipairs(l2) do if t.id == 7 then if t.t == "ACCEPT" then posA = i else posT = i end end end
        r.prec = posA and posT and posA < posT and P.ValidOrder(l2, 10) and l2[1].id == 1
        -- 3) Questlog voll (frei 1, erster Schritt nimmt an): Annahme 8 erst nach der Abgabe 9, obwohl sie näher liegt.
        --    Gültige Eingabe T9 A8 C2 C3 = 750; frei wäre A8 C2 T9 C3 = 350 (ungültig); bestes gültiges = 650
        local l3 = { T("ACCEPT", 1, 50), T("TURNIN", 9, 300), T("ACCEPT", 8, 100), T("COMPLETE", 2, 200), T("COMPLETE", 3, 400) }
        local _, o3, n3 = P:ExactOrder(l3, 1, 0, 0, 1)
        local pA, pT
        for i, t in ipairs(l3) do if t.id == 8 then pA = i elseif t.id == 9 then pT = i end end
        r.log = pA and pT and pT < pA and P.ValidOrder(l3, 1) and o3 and math.abs(o3 - 750) < 0.01 and math.abs(n3 - 650) < 0.01 and true or false
        -- 4) schon optimal -> unverändert; 5) weniger als 4 Schritte -> nichts
        local l4 = { T("COMPLETE", 1, 50), T("COMPLETE", 2, 100), T("COMPLETE", 3, 200), T("COMPLETE", 4, 300) }
        r.keep = P:ExactOrder(l4, 1, 0, 0, 10) == false and keys(l4) == "C1@50 C2@100 C3@200 C4@300"
        r.small = P:ExactOrder({ T("COMPLETE", 1, 50), T("COMPLETE", 2, 10) }, 1, 0, 0, 10) == false
        -- 6) Schritt danach zählt mit: 9 Schritte im Fenster + 1 dahinter bei 1000 -> der letzte im Fenster liegt nahe 1000
        local l6 = { T("COMPLETE", 1, 50) }
        for i, x in ipairs({ 900, 150, 800, 250, 700, 350, 600, 450 }) do l6[#l6 + 1] = T("COMPLETE", 10 + i, x) end
        l6[#l6 + 1] = T("COMPLETE", 99, 1000)
        P:ExactOrder(l6, 1, 0, 0, 10)
        r.tail = l6[9].n == 900 and l6[10].id == 99 and l6[2].n == 150
    end)
    P.OPT.wayCost = savedWC
    if not ok then error(err, 0) end
    local good = r.line and r.prec and r.log and r.keep and r.small and r.tail
    return good and true or false, ("Linie 950 -> 350 %s · annehmen vor abgeben %s · Questlog voll 750 -> 650 %s · optimal bleibt %s · < 4 nichts %s · Schritt danach zählt %s")
        :format(S(r.line), S(r.prec), S(r.log), S(r.keep), S(r.small), S(r.tail)), "true ×6"
end

IMPL.T322 = function()
    local P, G, Dg, Geo, E = LP.Planner, LP.Graph, LP.Danger, LP.Geo, LP.Engine
    if not (P.PlanPath and P.PlanText and Dg and E and E.CheckSteps) then return false, "NAV-3 fehlt", "vorhanden" end
    local o = { path = G.Path, pd = Dg.PathDanger, lim = Dg.Limit, pl = Geo.Player, rep = P.Replan, reply = LP.Reply,
                steps = P.steps, prio = P.priority, known = LP.char.taxiKnown }
    local r, replies, worst = {}, {}, 0
    local ok, err = pcall(function()
        G.Path = function(_, sI, sn, sw, sZ, gI, gn, gw, gZ) return { { sI, sn, sw, sZ }, { gI, gn, gw, gZ, via = "g" } }, "graph" end
        Dg.Limit = function() return 10 end
        Dg.PathDanger = function() return worst, 1, 100, 0 end
        LP.char.taxiKnown = {}
        local goal = { inst = 1, n = 700, w = 0, map = 1411 }
        worst = 12
        local p1 = P.PlanPath(1, 0, 0, 1411, goal)
        r.danger = p1 and p1.danger and p1.danger.level == 12 and (P.PlanText(p1) or ""):find("12", 1, true) ~= nil and true or false
        worst = 9
        local p2 = P.PlanPath(1, 0, 0, 1411, goal)
        r.safe = p2 and p2.danger == nil and not (P.PlanText(p2) or ""):find("|cffff5555", 1, true) and true or false
        -- Ankunft: Navi-Ziel (Planner.priority) erreicht -> Meldung; anderes Gehe-zu-Ziel -> still
        P.Replan = function() end
        LP.Reply = function(_, m) replies[#replies + 1] = tostring(m) end
        Geo.Player = function() return 1, 500, 500, 1411 end
        local prio = { t = "GOTO", inst = 1, n = 505, w = 500, key = "WAY:T322" }
        P.priority, P.steps = prio, { prio }
        E:CheckSteps()
        r.arrive = LP.char.doneKeys["WAY:T322"] == true and #replies == 1
        LP.char.doneKeys["WAY:T322"] = nil
        local other = { t = "GOTO", inst = 1, n = 505, w = 500, key = "FPGO:T322" }
        P.priority, P.steps = nil, { other }
        E:CheckSteps()
        r.quiet = LP.char.doneKeys["FPGO:T322"] == true and #replies == 1
        LP.char.doneKeys["FPGO:T322"] = nil
    end)
    G.Path, Dg.PathDanger, Dg.Limit, Geo.Player, P.Replan, LP.Reply = o.path, o.pd, o.lim, o.pl, o.rep, o.reply
    P.steps, P.priority, LP.char.taxiKnown = o.steps, o.prio, o.known
    LP.char.doneKeys["WAY:T322"], LP.char.doneKeys["FPGO:T322"] = nil, nil
    if not ok then error(err, 0) end
    local good = r.danger and r.safe and r.arrive and r.quiet
    return good and true or false, ("Gefahr Stufe 12 im Plan %s · ohne Gefahr kein Hinweis %s · Ankunft Navi-Ziel mit Meldung %s · anderes Ziel still %s")
        :format(S(r.danger), S(r.safe), S(r.arrive), S(r.quiet)), "true ×4"
end
IMPL.T323 = function()
    local C, P, Geo, API = LP.Comfort, LP.Planner, LP.Geo, _G.LevelPilotAPI
    if not (C.PlanTarget and C.OnPlanChanged and API and API.version == 2 and API.StopNavigation and API.TravelTime) then
        return false, "NAV-4 fehlt", "vorhanden"
    end
    local o = { pl = Geo.Player, tw = Geo.ToWorld, steps = P.steps, prio = P.priority, rep = P.Replan, tp = P.TravelPlan,
                cache = C.planCache, sync = LP.Jobs.sync, pn = C.PlanNavi }
    local r = {}
    local ok, err = pcall(function()
        Geo.Player = function() return 1, 0, 0, 1411 end
        Geo.ToWorld = function(_, m, x, y) return 1, x * 100, y * 100 end
        P.Replan = function() end
        LP.Jobs.sync = true
        P.TravelPlan = function(_, _, _, _, _, g) return { legs = { { k = "walk", dist = g.n, secs = g.n / 7 } }, total = g.n / 7 } end
        -- Routenschritt weit weg -> Ziel des Reiseplans; nah -> keins; Navi-Ziel geht vor
        local far = { t = "TURNIN", inst = 1, n = 2000, w = 0, key = "TURNIN:9001" }
        local near = { t = "TURNIN", inst = 1, n = 300, w = 0, key = "TURNIN:9002" }
        P.priority = nil
        P.steps = { far }
        r.far = C.PlanTarget() == far
        P.steps = { near }
        r.near = C.PlanTarget() == nil
        local prio = { t = "GOTO", inst = 1, n = 50, w = 0, key = "WAY:T323" }
        P.priority = prio
        r.prio = C.PlanTarget() == prio
        P.priority = nil
        -- gleicher Schritt nach Neuplanung: Plan aus dem Zwischenspeicher, ohne neu zu rechnen
        P.steps = { far }
        C.PlanNavi(far)
        r.plan = far.navText ~= nil and C.planCache and C.planCache.key == "TURNIN:9001" and true or false
        local again = { t = "TURNIN", inst = 1, n = 2000, w = 0, key = "TURNIN:9001" }
        P.steps = { again }
        local calls = 0
        C.PlanNavi = function(...) calls = calls + 1 return o.pn(...) end
        C.OnPlanChanged()
        r.cache = again.navText == far.navText and calls == 0
        C.PlanNavi = o.pn
        -- Schnittstelle v2
        P.priority = { t = "GOTO", map = 1411, x = 10, y = 20, inst = 1, n = 1000, w = 2000, text = "Eigenes Ziel", key = "WAY:1411:10.0:20.0" }
        r.stopOwn = API.StopNavigation() == false and P.priority ~= nil
        local nav = API.GetNavigation()
        r.get = nav and nav.map == 1411 and nav.x == 10 and nav.title == "Eigenes Ziel" and nav ~= P.priority and true or false
        P.priority = { t = "GOTO", map = 1411, x = 10, y = 20, inst = 1, n = 1000, w = 2000, text = "API", key = "PRIO:API:1411:10.0:20.0" }
        r.stopApi = API.StopNavigation() == true and P.priority == nil
        r.badKind = API.NavigateToNearest("schmied") == false
        local got
        r.travel = API.TravelTime(1411, 7, 0, function(secs, txt) got = { secs, txt } end) == true
                   and got and math.abs(got[1] - 100) < 0.01 and type(got[2]) == "string" and true or false
        r.badArgs = API.TravelTime(1411, 120, 0, function() end) == false and API.TravelTime(1411, 5, 5) == false
    end)
    Geo.Player, Geo.ToWorld, P.steps, P.priority, P.Replan, P.TravelPlan = o.pl, o.tw, o.steps, o.prio, o.rep, o.tp
    C.planCache, LP.Jobs.sync, C.PlanNavi = o.cache, o.sync, o.pn
    if not ok then error(err, 0) end
    local good = r.far and r.near and r.prio and r.plan and r.cache and r.stopOwn and r.get and r.stopApi and r.badKind and r.travel and r.badArgs
    return good and true or false, ("Route weit %s / nah keins %s / Navi zuerst %s · Plan %s · gleicher Schritt aus Speicher %s · Stop eigenes Ziel nein %s · Abfrage Kopie %s · Stop API-Ziel %s · falsche Art %s · Reisezeit 100 s %s · falsche Angaben %s")
        :format(S(r.far), S(r.near), S(r.prio), S(r.plan), S(r.cache), S(r.stopOwn), S(r.get), S(r.stopApi), S(r.badKind), S(r.travel), S(r.badArgs)), "true ×11"
end
IMPL.T324 = function()
    local Pi, Geo = LP.Pins, LP.Geo
    if not (Pi and Pi.NextKillSpot) then return false, "LW-7a fehlt", "vorhanden" end
    local saved = { areas = Pi.areas, tw = Geo.ToWorld, arrow = LP.db.objArrow }
    local r = {}
    local function A(key, x) return { p = { 99001, x, 0 }, kill = true, key = "K:T324:" .. key } end
    local ok, err = pcall(function()
        Geo.ToWorld = function(_, m, x, y) if m == 99001 then return 1, x, y end return saved.tw(Geo, m, x, y) end
        -- Fundorte auf einer Linie: 0, 100, 200, 300 (Yards)
        Pi.areas = { A("a", 0), A("b", 100), A("c", 200), A("d", 300) }
        local t1 = Pi:NextKillSpot(1, 5, 0)                -- bei a: a besucht -> nächster b
        r.first = t1 and t1.entry.key == "K:T324:b" and t1.round == true and true or false
        local t2 = Pi:NextKillSpot(1, 100, 0)              -- bei b -> c
        local t3 = Pi:NextKillSpot(1, 200, 0)              -- bei c -> d
        r.order = t2 and t3 and t2.entry.key == "K:T324:c" and t3.entry.key == "K:T324:d" and true or false
        local t4 = Pi:NextKillSpot(1, 300, 0)              -- bei d: alle besucht -> Runde von vorn, nächster ist c
        r.loop = t4 and t4.entry.key == "K:T324:c" and true or false
        r.far = Pi:NextKillSpot(1, 900, 0) == nil          -- weiter als 250 yd vom nächsten Fundort
        Pi.areas = { A("x", 0), A("y", 100) }
        r.few = Pi:NextKillSpot(1, 50, 0) == nil           -- nur 2 Fundorte
        Pi.areas = { A("m", 0), A("n", 100), { p = { 99001, 50, 0 }, key = "K:T324:area" } }
        r.onlyKill = Pi:NextKillSpot(1, 50, 0) == nil      -- Gebiete ohne Töte-Ziel zählen nicht
    end)
    Pi.areas, Geo.ToWorld, LP.db.objArrow = saved.areas, saved.tw, saved.arrow
    if not ok then error(err, 0) end
    local good = r.first and r.order and r.loop and r.far and r.few and r.onlyKill
    return good and true or false, ("erster %s · Reihenfolge %s · Runde von vorn %s · zu weit %s · < 3 %s · nur Töte-Ziele %s")
        :format(S(r.first), S(r.order), S(r.loop), S(r.far), S(r.few), S(r.onlyKill)), "true ×6"
end
IMPL.T325 = function()
    local M = LP.Pruefliste
    if not (M and M.Points and M.ERA_POINTS) then return false, "E5 fehlt", "vorhanden" end
    local o = { era = LP.IsEraClient, kind = LP.accKind, acc = LP.Acc, max = LP.API.MaxQuests, sw = LP.Center.ForeverSwitchUseful,
                hadEra = type(LevelPilotDB) == "table" and LevelPilotDB.era }
    local r = {}
    local function auto(id)
        for _, p in ipairs(M.ERA_POINTS) do if p.id == id then return p.auto() end end
    end
    local ok, err = pcall(function()
        -- Liste je Spielversion, Era-Punkte vollständig und eindeutig
        LP.IsEraClient = function() return true end
        local e = M.Points()
        local ids, full = {}, 0
        for _, p in ipairs(e) do
            if p.id and p.title and p.since and p.todo and p.expect and not ids[p.id] then full = full + 1 end
            ids[p.id] = true
        end
        r.era = e == M.ERA_POINTS and #e == 6 and full == 6
        LP.IsEraClient = function() return false end
        r.fv = M.Points() == M.POINTS
        -- Selbstprüfungen: ausserhalb von Era nichts (nil)
        r.offEra = auto("E5-1") == nil and auto("E5-2") == nil and auto("E5-3") == nil
        LP.IsEraClient = function() return true end
        r.load = auto("E5-1") == true
        local eraTab = o.hadEra or {}
        if not o.hadEra then LevelPilotDB.era = eraTab end
        LP.accKind, LP.Acc = "era", function() return eraTab end
        local a2 = auto("E5-2")
        LP.accKind = "forever"
        local a2b = auto("E5-2")
        r.data = a2 == true and a2b == false
        LP.API.MaxQuests, LP.Center.ForeverSwitchUseful = function() return 20 end, function() return false end
        local a3 = auto("E5-3")
        LP.API.MaxQuests = function() return 40 end
        r.log = a3 == true and auto("E5-3") == false
    end)
    LP.IsEraClient, LP.accKind, LP.Acc, LP.API.MaxQuests, LP.Center.ForeverSwitchUseful = o.era, o.kind, o.acc, o.max, o.sw
    if not o.hadEra and type(LevelPilotDB) == "table" then LevelPilotDB.era = nil end
    if not ok then error(err, 0) end
    local good = r.era and r.fv and r.offEra and r.load and r.data and r.log
    return good and true or false, ("Era-Liste 6 vollständig %s · Forever bisherige %s · ausserhalb Era still %s · lädt %s · Bereich era / falsch %s · Questlog 20 / 40 %s")
        :format(S(r.era), S(r.fv), S(r.offEra), S(r.load), S(r.data), S(r.log)), "true ×6"
end
IMPL.T326 = function()
    local P = LP.Planner
    if not (P.TravelFactor and P.OPT.timeNormal ~= nil) then return false, "LW-2b fehlt", "vorhanden" end
    local o = { wc = P.OPT.wayCost, tn = P.OPT.timeNormal, sp = P.IsSpeed, tw = LP.Geo.ToWorld }
    local r = {}
    local function near(a, b) return math.abs(a - b) < 0.001 end
    local ok, err = pcall(function()
        P.OPT.wayCost = false                                -- Luftlinie: genaue Zahlen
        r.f1 = near(P.TravelFactor(300, { inst = 1, n = 700, w = 0 }, 1, 0, 0, 1), 300 / 350)       -- 700 yd = 100 s
        r.f2 = near(P.TravelFactor(30, { inst = 1, n = 7000, w = 0 }, 1, 0, 0, 1), 0.35)            -- sehr weit: Untergrenze
        r.f3 = near(P.TravelFactor(300, { inst = 2, n = 0, w = 0 }, 1, 0, 0, 1), 300 / 750)         -- anderer Kontinent 900 s
        r.f4 = near(P.TravelFactor(300, { inst = 1, n = 700, w = 0 }, 1, 0, 0, 2), 300 / 325)       -- 2 Questgeber teilen
        -- im Normalmodus angewendet, nichts ausgelassen; Schalter aus = unverändert
        P.IsSpeed = function() return false end
        LP.Geo.ToWorld = function(_, m, x, y) return 1, x, y end
        local function run()
            local q = { id = 99901, starts = {}, objectives = {} }
            local acc = { { q = q, t = { t = "ACCEPT", id = 99901, value = 1, inst = 1, n = 7000, w = 0, map = 1411 } } }
            local tasks = {}
            P:SpeedFilter(acc, tasks, 10, 1, 0, 0)
            return tasks
        end
        P.OPT.timeNormal = true
        local t1 = run()
        r.on = #t1 == 1 and t1[1].value < 1 and t1[1].value >= 0.35
        P.OPT.timeNormal = false
        local t2 = run()
        r.off = #t2 == 1 and t2[1].value == 1
    end)
    P.OPT.wayCost, P.OPT.timeNormal, P.IsSpeed, LP.Geo.ToWorld = o.wc, o.tn, o.sp, o.tw
    if not ok then error(err, 0) end
    local good = r.f1 and r.f2 and r.f3 and r.f4 and r.on and r.off
    return good and true or false, ("700 yd/300 s = 0,857 %s · Untergrenze 0,35 %s · anderer Kontinent 0,4 %s · 2 Questgeber %s · Normalmodus angewendet, nicht ausgelassen %s · Schalter aus unverändert %s")
        :format(S(r.f1), S(r.f2), S(r.f3), S(r.f4), S(r.on), S(r.off)), "true ×6"
end
CLIENT.T326 = "Im Spiel nicht einzeln sichtbar: Wirkung über die virtuelle Reise (/lp testroutine reise) und die Laufweg-Zeilen (LW-6)"

CLIENT.T325 = "Im Classic-Era-Client: AddOn-Liste ohne „veraltet“, /lp prüfliste zeigt „Classic Era: …“ (6 Punkte), E5-1 bis E5-3 erledigt sich selbst"

CLIENT.T324 = "Im Spiel: Töte-Quest mit mehreren Gegner-Gruppen – nahe dem Gebiet zeigt der Pfeil „Gegner – Rundgang“ und führt von Gruppe zu Gruppe, danach von vorn"

CLIENT.T323 = "Im Spiel: weiter Routenschritt (z. B. Abgabe in einer anderen Zone) – „Reise ~…“ unter dem Schritt; ein anderes Addon (ProfessionSentinel) ruft LevelPilotAPI.NavigateToNearest(\"trainer\")"

CLIENT.T322 = "Im Spiel: /lp navi zu einem Ort hinter einem Gebiet mit hohen Gegnern – rote Zeile „Vorsicht: Gegner bis Stufe …“; am Ziel „Navi: angekommen“"

CLIENT.T320 = "Im Spiel: Markierung auf der Weltkarte setzen (Strg+Klick) – LevelPilot führt hin, Reiseplan unter dem Ziel; Markierung entfernen -> Navi endet. Gibt es das Ereignis im Forever-Client? (Zeile „Ereignis im Client“)"

CLIENT.T319 = "Im Spiel: /lp navi gornek (oder ein anderer Questgeber), /lp navi flammenschlund, bei mehreren Treffern /lp navi 2"

CLIENT.T318 = "Im Spiel: /lp navi 50 50 Brachland (von Durotar) – im Guide unter dem Ziel „Reise ~m:ss: … → …“, die Zeit wird alle 10 s neu gerechnet"

CLIENT.T317 = "Im Classic-Era-Client: Einstellungen > Server & Dungeons ohne Schalter „Server WoW Forever“; Daten-Seite ohne „WoW-Forever-Quests“"

CLIENT.T316 = "Im Classic-Era-Client (Nutzer seit 10:36): nach dem ersten Einloggen steht in SavedVariables/LevelPilot.lua ein Bereich „era“; Forever-Wege erscheinen dort nicht"

CLIENT.T315 = "Nur im Classic-Era-Client prüfbar (Nutzer hat keinen): NPCs in Mulgore/Sturmwind stehen am richtigen Ort – Verdacht, zu messen"

CLIENT.T314 = "/lp navi 45 60 Brachland: Pfeil zum Punkt, oben im Guide „Wegpunkt 45.0, 60.0 · Brachland“; /lp navi briefkasten: nächster Briefkasten; /lp navi aus: Route geht weiter"

CLIENT.T313 = "Nach einer Spielstunde /lp protokoll: Zeile „UMWEG je Zone …“ mit gemessenen Zonen (n Paare), Werte zwischen 1,0 und 1,8"

CLIENT.T312 = "WoW Forever: /lp testroutine – T312 zeigt „STRASSEN Kontinent … Knoten (… ohne Zone …)“; „ohne Zone“ fast 0 (sonst liefert C_Map.GetMapInfoAtPosition nichts)"

CLIENT.T311 = "Mit bekannten Flugpunkten ein Ziel weit weg wählen, /lp protokoll: Zeile „REISE letzter Flugvergleich: Laufen x s · Fliegen y s (Flugzeit gemessen) …“ passt zur Wahl; auf dem Reittier „Tempo 11,2 yd/s (Reittier gemessen)“"

-- TU8: je Bereich eine Zeile "OK n · FEHLER n · SKIP n"
function TR:TULines(T)
    local byId = {}
    for _, r in ipairs(T.results) do byId[r.id] = r.status end
    local out = {}
    for _, key in ipairs({ "TU1", "TU2", "TU3", "TU4", "TU5", "TU6", "TU7" }) do
        local ok, fe, sk, cl = 0, 0, 0, 0
        for _, id in ipairs(TR.TU[key]) do
            local st = byId[id]
            if st == "OK" then ok = ok + 1 elseif st == "FEHLER" then fe = fe + 1
            elseif st == "CLIENT" then cl = cl + 1 elseif st then sk = sk + 1 end
        end
        out[#out + 1] = ("%s %s: OK %d · FEHLER %d · SKIP %d%s"):format(key, TR.TU_NAMES[key], ok, fe, sk, cl > 0 and (" · im Client %d"):format(cl) or "")
    end
    out[#out + 1] = TR.regressionLine or "Regressionen: nicht geprüft"
    return out
end

------------------------------------------------------------------------
-- 3.12.16: graue Gegenstände automatisch verkaufen (Comfort:SellGrey), alles mit Testtaschen und eigener Uhr
------------------------------------------------------------------------
-- Testtasche: Platz -> Gegenstand; eigene Zeitschlange statt C_Timer; LP:Print mitgeschrieben
local GREY_LINK = "|cff9d9d9d|Hitem:999101::::::::|h[Testplunder]|h|r"
local function GreyBag()
    return {
        [1] = { id = 999101, count = 1, quality = 0, link = GREY_LINK },                       -- verkaufen
        [2] = { id = 999102, count = 1, quality = 0, link = GREY_LINK, noValue = true },       -- kein Wert
        [3] = { id = 999103, count = 1, quality = 0, link = GREY_LINK, locked = true },        -- gesperrt
        [4] = { id = 999104, count = 1, quality = 1, link = "|cffffffff|Hitem:999104::::::::|h[Weiß]|h|r" },
        [5] = { id = 999105, count = 1, quality = 2, link = "|cff1eff00|Hitem:999105::::::::|h[Grün]|h|r" },
        [6] = { id = 999106, count = 3, quality = 0, link = GREY_LINK },                       -- verkaufen
    }
end
local function WithGreyShop(bag, open, body)
    local C, API = LP.Comfort, LP.API
    local queue, printed = {}, {}
    local timer = { After = function(_, fn) queue[#queue + 1] = fn end }
    local oSlots, oItem, oPrint, oOpen, oRun = API.BagSlots, API.BagItem, LP.Print, C.merchantOpen, C.sellRun
    API.BagSlots = function(b) return b == 0 and 6 or 0 end
    API.BagItem = function(b, sl) return b == 0 and bag[sl] or nil end
    LP.Print = function(_, msg) printed[#printed + 1] = tostring(msg) end
    C.merchantOpen, C.sellRun = open, nil
    local function drain(max)
        local n = 0
        while #queue > 0 and n < (max or 50) do
            local fn = table.remove(queue, 1)
            fn() n = n + 1
        end
        return n
    end
    return Guard(function()
        return WithEnv({ C.SellGrey }, { C_Timer = timer, GetMoney = function() return 12345 end }, function()
            return body(C, drain, printed, queue)
        end)
    end, function()
        API.BagSlots, API.BagItem, LP.Print, C.merchantOpen, C.sellRun = oSlots, oItem, oPrint, oOpen, oRun
    end)
end

IMPL.T230 = function()
    return WithCombat(false, function()
        return WithSetting({ autoSellGrey = true }, function()
            return WithGreyShop(GreyBag(), true, function(C, drain, printed)
                local mark = ActMark()
                local real = LP.Act.real
                local run = C:SellGrey()
                drain()
                local sold = ActSince(mark, "Sell")
                local line = #printed == 1 and printed[1] or nil
                local listed = run and #run.list or 0
                local ok = run ~= nil and listed == 2 and sold == 2 and run.sold == 2 and line ~= nil and line:find("2", 1, true) ~= nil
                    and LP.Act.real == real
                return ok, string.format("Liste %d, verkauft %d, Zeilen %d (%s)", listed, sold, #printed, S(line)),
                    "Liste 2 (nur Qualität 0 mit Wert, ungesperrt), verkauft 2, 1 Zeile"
            end)
        end)
    end)
end

IMPL.T231 = function()
    return WithCombat(false, function()
        return WithSetting({ autoSellGrey = true }, function()
            return WithGreyShop(GreyBag(), true, function(C, drain, printed)
                local mark = ActMark()
                -- /lp grau schaltet aus (Chatzeile der Umschaltung zählt nicht als Verkaufszeile)
                SlashCmdList.LEVELPILOT("grau")
                local off = LP.db.autoSellGrey
                local n0 = #printed
                local run = C:SellGrey()
                drain()
                local sold = ActSince(mark, "Sell")
                SlashCmdList.LEVELPILOT("grau")
                local back = LP.db.autoSellGrey
                local empty = WithSetting({ autoSellGrey = true }, function()
                    return WithGreyShop({}, true, function(C2, drain2, printed2)
                        local r = C2:SellGrey() drain2()
                        return r == nil and #printed2 == 0
                    end)
                end)
                return off == false and run == nil and sold == 0 and #printed == n0 + 1 and back == true and empty,
                    string.format("aus %s, Lauf %s, verkauft %d, Zeilen %d, wieder an %s, leere Tasche ohne Zeile %s",
                        S(not off), S(run), sold, #printed - n0, S(back), S(empty)),
                    "aus true, Lauf nil, verkauft 0, Zeilen 1 (Umschaltung), wieder an true, leere Tasche true"
            end)
        end)
    end)
end

IMPL.T232 = function()
    return WithCombat(false, function()
        return WithSetting({ autoSellGrey = true }, function()
            return WithGreyShop(GreyBag(), true, function(C, drain, printed)
                local mark = ActMark()
                local run = C:SellGrey()                  -- erster Gegenstand sofort
                CallHandlers("MERCHANT_CLOSED")            -- Händler zu
                drain()
                local sold = ActSince(mark, "Sell")
                return run ~= nil and sold == 1 and run.done == true and C.merchantOpen == false,
                    string.format("verkauft %d von %d, beendet %s, Händler offen %s", sold, run and #run.list or 0,
                        S(run and run.done), S(C.merchantOpen)),
                    "verkauft 1 von 2, beendet true, Händler offen false"
            end)
        end)
    end)
end

IMPL.T233 = function()
    return WithSetting({ autoSellGrey = true }, function()
        return WithGreyShop(GreyBag(), true, function(C, drain, printed)
            local mark = ActMark()
            local inCombat = WithCombat(true, function() return C:SellGrey() end)
            local sold1 = ActSince(mark, "Sell")
            local run, sold2
            WithCombat(false, function() run = C:SellGrey() end)   -- erster Gegenstand
            WithCombat(true, function() drain() end)               -- Kampf beginnt: Rest bleibt liegen
            sold2 = ActSince(mark, "Sell")
            return inCombat == nil and sold1 == 0 and run ~= nil and sold2 == 1,
                string.format("im Kampf Lauf %s, verkauft %d; Kampfbeginn: verkauft %d", S(inCombat), sold1, sold2),
                "im Kampf Lauf nil, verkauft 0; Kampfbeginn: verkauft 1"
        end)
    end)
end

IMPL.T234 = function()
    return WithCombat(false, function()
        return WithSetting({ autoSellGrey = true }, function()
            return WithGreyShop(GreyBag(), true, function(C, drain)
                local mark, real = ActMark(), LP.Act.real
                C:SellGrey() drain()
                local logged = ActSince(mark, "Sell")
                -- kein eigener Knopf oder Rahmen am Händlerfenster
                local attached = 0
                local mf = _G.MerchantFrame
                for name, f in pairs(_G) do
                    if type(name) == "string" and name:find("^LevelPilot") and type(f) == "table" and f.GetParent then
                        local ok, p = pcall(f.GetParent, f)
                        if ok and p and mf and p == mf then attached = attached + 1 end
                    end
                end
                return logged == 2 and LP.Act.real == real and attached == 0,
                    string.format("mitgeschrieben %d, echt ausgeführt %d, LevelPilot-Rahmen am Händlerfenster %d",
                        logged, LP.Act.real - real, attached),
                    "mitgeschrieben 2, echt ausgeführt 0, Rahmen 0"
            end)
        end)
    end)
end
CLIENT.T234 = "Händler öffnen: graue Gegenstände verschwinden, Chatzeile „N graue Gegenstände verkauft für …“, Reiter Händler/Rückkauf frei sichtbar"

IMPL.T223 = function()
    local Se = LP.Session
    -- Köder: Tabellen gelten als geschützt; ein ungeschützter Wahrheitstest wäre in Forever ein Lua-Fehler,
    -- hier fällt er dadurch auf, dass der Köder (eine Tabelle) als "wahr" durchgeht
    local bait = { "LPTestKoeder Wahrheitswert" }
    local fake = {}
    for _, f in ipairs({ "UnitIsAFK", "UnitOnTaxi", "UnitIsDeadOrGhost", "UnitIsDead", "UnitIsGhost", "UnitAffectingCombat",
                         "UnitInVehicle", "UnitIsPlayer", "UnitPlayerControlled" }) do
        fake[f] = function() return bait end
    end
    fake.UnitExists = function() return true end
    return WithSecret({ bait }, function()
        local bad = {}
        local function try(name, fns, body)
            local ok, err = pcall(WithEnv, fns, fake, body)
            if not ok then bad[#bad + 1] = name .. ": " .. tostring(err):sub(1, 60) end
            return ok, err
        end
        local afk
        Se.MarkActive()
        try("Session:IsAFK", { Se.IsAFK }, function() afk = Se:IsAFK() end)
        try("LP:InCombat", { LP.InCombat }, function() LP:InCombat() end)
        local rec
        try("Recorder", { LP.Recorder.CanRecord }, function() rec = WithSetting({ recordPaths = true }, function() return LP.Recorder.CanRecord() end) end)
        try("Navigation:Excluded", { LP.Nav.Excluded }, function() LP.Nav.Excluded() end)
        try("Calib:ObserveUnit", { LP.Calib.ObserveUnit }, function() LP.Calib:ObserveUnit("target") end)
        try("Plates:ForUnit", { LP.Plates.ForUnit }, function() LP.Plates:ForUnit("target", true, {}) end)
        try("Measure", { LP.Measure.UnitLine }, function() LP.Measure.UnitLine("target") end)
        local ok = #bad == 0 and afk == false and rec == true
        return ok, #bad == 0 and ("kein Fehler, AFK aus dem Leerlauf: " .. S(afk)) or table.concat(bad, "; "), "kein Fehler, AFK false (gerade aktiv)"
    end)
end

------------------------------------------------------------------------
-- K. Oberfläche im echten Client (UICheck.lua). Ohne echten Client ehrlich übersprungen, nie als OK gezählt.
------------------------------------------------------------------------
TR.UI = { T224 = true, T225 = true, T226 = true, T227 = true }        -- brauchen Fenster, Rechtecke, Tooltip
local UI_SKIP = "nur im echten Client (Fenster, Rechtecke, Tooltip)"
local function UIList(problems) return #problems == 0 and "keine" or table.concat(problems, "; ") end
-- Guide und Zentrale offen (alle Reiter einmal gebaut), danach wie vorher
local function WithOpenUI(body)
    local UIm = LP.UI
    local was = UIm:IsShown()
    return Guard(function()
        if not UIm:IsShown() then UIm:Toggle() end
        return WithCenter(function()
            LP.Center:Select("route")
            LP.UICheck.Collect()
            return body()
        end)
    end, function() if UIm:IsShown() ~= was then UIm:Toggle() end end)
end
local function UICase(fn)
    return function()
        return WithOpenUI(function()
            local problems, tested, hints = fn()
            return #problems == 0, UIList(problems) .. " · geprüft " .. tostring(tested)
                .. (hints and #hints > 0 and (" · Hinweise: " .. table.concat(hints, "; "):sub(1, 300)) or ""), "keine"
        end)
    end
end
IMPL.T224 = UICase(function() return LP.UICheck.TooltipsCoverNothing() end)
IMPL.T225 = UICase(function() return LP.UICheck.WindowsOverlapNothing() end)
IMPL.T226 = UICase(function() return LP.UICheck.InsideScreen() end)
IMPL.T227 = UICase(function() return LP.UICheck.TextFits() end)
IMPL.T228 = function()
    local problems, tested = LP.UICheck.ValuesPlausible()
    return #problems == 0, UIList(problems) .. " · geprüft " .. tested, "keine"
end
IMPL.T229 = function()
    local problems, n = LP.UICheck.NoErrorLoops()
    return #problems == 0, UIList(problems) .. " · Meldungen " .. n, "keine"
end

------------------------------------------------------------------------
-- Ablauf
------------------------------------------------------------------------
local function GT() return _G.GoldSentinelTest end
local AREAS = "abcdefghijk"

function TR:CanStart(silent)
    if LP:InCombat() then
        if not silent then LP:Reply(L["Testroutine nur ausserhalb des Kampfes."]) end
        return false
    end
    if LP.Virtual and LP.Virtual.active then
        if not silent then LP:Reply(L["Testroutine: Es läuft gerade eine virtuelle Reise."]) end
        return false
    end
    if self.running then
        if not silent then LP:Reply(L["Testroutine läuft bereits."]) end
        return false
    end
    if not GT() then
        if not silent then LP:Reply(L["GoldSentinelTest.lua fehlt – keine Testroutine möglich."]) end
        return false
    end
    return true
end

-- eine Prüfung eintragen
local function RunOne(T, e)
    local id, area, name = e[1], e[2], e[3]
    if TR.LONG[id] and not TR.long then
        T:Skip(id, area, name, LONG_ONLY)
    elseif TR.UI[id] and not LP.UICheck.Available() then
        T:Skip(id, area, name, UI_SKIP)
    elseif IMPL[id] then
        local fn = IMPL[id]
        local autoOK, autoText
        -- erster Rückgabewert immer als true/false (nil aus "a and b" darf nicht als OK gelten)
        local naReason
        local passed = T:Check(id, area, name, function()
            local a, b, c = fn()
            if a == NA then naReason = tostring(b or "") return true, b end
            if a then autoOK, autoText = true, b return true, b end
            return false, b, c
        end)
        -- in dieser Lage nicht prüfbar: als übersprungen zählen (nicht als OK)
        if passed and naReason then
            local last = T.results[#T.results]
            T.counts.ok = T.counts.ok - 1
            if last and last.id == id and last.status == "OK" then
                last.status, last.grund, last.ergebnis = "SKIP", naReason .. TR.NA_SUFFIX, nil
                T.counts.uebersprungen = T.counts.uebersprungen + 1
            else
                T:Skip(id, area, name, naReason .. TR.NA_SUFFIX)
            end
            return
        end
        -- automatischer Teil OK, Rest im Client (auto + halb): zusätzlich als "im Client prüfen" eintragen
        if passed and CLIENT[id] and T.results[#T.results] and T.results[#T.results].id == id then
            T.results[#T.results].status = "CLIENT"
            T.counts.ok, T.counts.client = T.counts.ok - 1, T.counts.client + 1
            T.results[#T.results].anleitung = CLIENT[id] .. " (automatischer Teil OK" .. (autoText and (": " .. tostring(autoText)) or "") .. ")"
        end
    elseif CLIENT[id] then T:Client(id, area, name, CLIENT[id])
    elseif SKIP[id] then T:Skip(id, area, name, SKIP[id])
    else
        TR.notYet = (TR.notYet or 0) + 1
        T:Skip(id, area, name, NOT_YET)
    end
end

-- Sandbox: echte Daten sichern / in place zurückschreiben / vergleichen
local function Copy(v) return LP.Backup.DeepCopy(v) end
local function RestoreInto(cur, saved)
    for k in pairs(cur) do if saved[k] == nil then cur[k] = nil end end
    for k, v in pairs(saved) do
        if type(v) == "table" and type(cur[k]) == "table" and getmetatable(cur[k]) == nil then RestoreInto(cur[k], v)
        else cur[k] = v end
    end
end

-- 3.12.21: GoldSentinelSync sendet selbst (gemeinsame Warteschlange). Waehrend der Testroutine gehen eigene
-- Nachrichten nur ins Mitschreiben (LP.Act, trocken); ersetzt wird nur GoldSentinelSync.api.send, nie Blizzard.
local function SyncDry()
    local Sy = _G.GoldSentinelSync
    if not Sy or type(Sy.api) ~= "table" or Sy.api.lpDry then return nil end
    local orig = Sy.api.send
    local wrap = function(prefix, msg, dist, target)
        if OWN_PREFIX[prefix] and LP.Act.dry then
            LP.Act.Call("SendAddonMessage", orig, prefix, msg, dist, target)
            return true
        end
        return orig(prefix, msg, dist, target)
    end
    Sy.api.send, Sy.api.lpDry = wrap, true
    -- 3.12.22: eigene leere Warteschlangen fuer die Dauer der Routine (Felder der gemeinsamen Tabelle). Tests pumpen
    -- so nur Testnachrichten; echte Nachrichten (auch anderer Addons) warten in den echten Tabellen.
    local h = { api = Sy.api, orig = orig, sy = Sy, queue = Sy.queue, netQueue = Sy.netQueue }
    Sy.queue, Sy.netQueue = {}, {}
    return h
end
local function SyncUndo(h)
    if not h then return end
    if h.api then h.api.send, h.api.lpDry = h.orig, nil end
    local Sy = h.sy
    if Sy and h.queue then
        -- was andere Addons waehrend der Routine eingereiht haben, kommt in die echten Tabellen
        for _, pair in ipairs({ { Sy.queue, h.queue }, { Sy.netQueue, h.netQueue } }) do
            local tmp, real = pair[1], pair[2]
            if type(tmp) == "table" and type(real) == "table" and tmp ~= real then
                for _, it in ipairs(tmp) do
                    if type(it) == "table" and not OWN_PREFIX[it.prefix] and it.prefix ~= Sy.CTRL then real[#real + 1] = it end
                end
            end
        end
        Sy.queue, Sy.netQueue = h.queue, h.netQueue
    end
end
TR.SyncDry, TR.SyncUndo = SyncDry, SyncUndo

local function Snapshot()
    local sb = { acc = {}, char = Copy(LevelPilotCharDB), enc = {}, encChar = nil }
    for k, v in pairs(LevelPilotDB) do if k ~= "gsTest" then sb.acc[k] = Copy(v) end end
    sb.debug, sb.mode = LP.debug, LP.char.mode
    local P = LP.Planner
    sb.focus, sb.priority, sb.leftZones = P.focus, P.priority, P.leftZones and Copy(P.leftZones)
    sb.queue = LP.Comm.QueueSnapshot and LP.Comm:QueueSnapshot() or nil
    sb.language = LP.db.language
    return sb
end

local function Restore(sb)
    local accSaved = {}
    for k, v in pairs(sb.acc) do accSaved[k] = Copy(v) end
    accSaved.gsTest = LevelPilotDB.gsTest                       -- der neue Bericht bleibt stehen
    RestoreInto(LevelPilotDB, accSaved)
    RestoreInto(LevelPilotCharDB, Copy(sb.char))
    LP:LoadSaved(LP.Acc(), LevelPilotCharDB)   -- 3.12.56: Bereich der Spielversion (Era: LevelPilotDB.era)
    LP.debug = sb.debug
    local P = LP.Planner
    P.focus, P.priority = sb.focus, sb.priority
    if sb.leftZones then P.leftZones = sb.leftZones end
end

local function Diff(sb, yield)
    local Enc = GT().Encode
    local bad = {}
    local keys = {}
    for k in pairs(sb.acc) do keys[k] = true end
    for k in pairs(LevelPilotDB) do if k ~= "gsTest" then keys[k] = true end end
    for k in pairs(keys) do
        if Enc(sb.acc[k]) ~= Enc(LevelPilotDB[k]) then bad[#bad + 1] = tostring(k) end
        yield()
    end
    if Enc(sb.char) ~= Enc(LevelPilotCharDB) then bad[#bad + 1] = "LevelPilotCharDB" end
    if LP.char ~= LevelPilotCharDB then bad[#bad + 1] = "LP.char" end
    if type(LP.Acc().taxi) == "table" and getmetatable(LP.Acc().taxi) ~= nil then bad[#bad + 1] = "taxi (Überlagerung)" end
    if LP.db.language ~= sb.language then bad[#bad + 1] = "language" end
    table.sort(bad)
    return #bad == 0 and "OK" or ("FEHLER: " .. table.concat(bad, ", "))
end

-- Beobachtung echter Spielereignisse während des Laufs
local watch = CreateFrame("Frame")
local WATCH = { PLAYER_REGEN_DISABLED = "Kampf begonnen", QUEST_TURNED_IN = "echtes Spielereignis während des Tests",
                PLAYER_LEVEL_UP = "echtes Spielereignis während des Tests", QUEST_ACCEPTED = "echtes Spielereignis während des Tests",
                TAXIMAP_OPENED = "echtes Spielereignis während des Tests" }
watch:SetScript("OnEvent", function(_, ev) if TR.running and not TR.abort then TR.abort = WATCH[ev] end end)

-- direkte Aufrufe an LP.Act vorbei zählen (nur während des Laufs; hooksecurefunc ersetzt nichts)
local hooked = false
TR.direct = 0
local function InstallHooks()
    if hooked or not hooksecurefunc then return end
    hooked = true
    local function count() if TR.running then TR.direct = TR.direct + 1 end end
    for _, n in ipairs({ "BuyMerchantItem", "RepairAllItems", "TakeTaxiNode", "AcceptQuest", "CompleteQuest", "GetQuestReward",
                         "EquipItemByName", "QuestLogPushQuest" }) do
        if type(_G[n]) == "function" then pcall(hooksecurefunc, n, count) end
    end
end

function TR:Run(area, long)
    if not LP:DevOnly() or not self:CanStart() then return end
    area = area and area:upper() or nil
    if area and not AREAS:upper():find(area, 1, true) then area = nil end
    local A = LP.Act
    self.running, self.abort, self.direct, self.notYet, self.long = true, nil, 0, 0, long and true or false
    LP.testGen = LP.testGen + 1
    A.dry, A.log, A.dryCount = true, {}, 0
    self.syncDry = SyncDry()
    -- 3.12.24: Arbeit in Portionen waehrend der Routine am Stueck (Tests erwarten das Ergebnis sofort)
    self.jobsSync = LP.Jobs.sync
    LP.Jobs.sync = true
    TR.syncHandle = self.syncDry
    local realBefore = A.real
    InstallHooks()
    for ev in pairs(WATCH) do pcall(watch.RegisterEvent, watch, ev) end
    local errBefore = LP.errorCount
    local T = GT().Begin("LevelPilot", LP.version, LevelPilotDB)
    LP:Reply(L["Testroutine läuft – bitte stillstehen …"])
    local sb = Snapshot()
    collectgarbage("collect")
    self.memStart = collectgarbage("count")          -- nach der Sicherung (die Kopie zählt nicht als Zuwachs)

    local sliceStart = Ms()
    local co
    local function yield()
        if Ms() - sliceStart > 8 then coroutine.yield() end
    end
    local function body()
        -- virtuelle Reisen vorab (Warten ausserhalb jeder Prüfung)
        self.journey = nil
        if not area or area == "B" or area == "H" or area == "J" then
            self:Journeys(function(cond, maxSec)
                local t0 = GetTime()
                while not cond() and GetTime() - t0 < maxSec and not self.abort do coroutine.yield() end
            end, self.long)
            -- Speicher (T157) ab hier: die Reisen füllen einmalig Zwischenspeicher (Wegenetz, Gefahrenkarte) und der
            -- letzte Reisebericht bleibt absichtlich für /lp reise bericht stehen
            collectgarbage("collect")
            self.memStart = collectgarbage("count")
        end
        -- 3.12.26 TU4: Grundregeln mit Zufallsfällen in Portionen (vor den Prüfungen, ausserhalb jedes pcall)
        self.inv = nil
        if not area or area == "J" then
            levelIndex = nil
            self:Invariants(yield)
        end
        for _, e in ipairs(self.IDS) do
            if (not area or e[2] == area) and e[1] ~= "T165" and e[1] ~= "T166" then
                if self.abort then T:Skip(e[1], e[2], e[3], self.abort)
                else RunOne(T, e) end
                yield()
            end
        end
        -- Sandbox zurück und vergleichen
        local ok, err = pcall(Restore, sb)
        local sandbox = ok and Diff(sb, yield) or ("FEHLER: " .. tostring(err))
        -- Testfehler aus der Fehlerliste von GoldSentinelTest entfernen (sonst gelten sie als echte Fehler)
        local s = LevelPilotDB.gsTest
        if s and type(s.errors) == "table" then
            for k, v in pairs(s.errors) do
                local m = type(v) == "table" and tostring(v.msg) or ""
                if m:find("LP-Testfehler", 1, true) or (type(v) == "table" and v.wo == "Testroutine") then s.errors[k] = nil end
            end
        end
        pcall(LP.Protocol.LoadEntries, LP.Protocol)
        -- T166: IDs eindeutig und vollständig
        if not area or area == "I" then
            T:Check("T166", "I", "Testfall-IDs eindeutig und vollständig", function()
                local seen, dup, miss = {}, {}, {}
                for _, r in ipairs(T.results) do
                    if seen[r.id] then dup[#dup + 1] = r.id end
                    seen[r.id] = true
                end
                for _, e in ipairs(self.IDS) do
                    if (not area or e[2] == area) and e[1] ~= "T165" and e[1] ~= "T166" and not seen[e[1]]
                       and not (#T.results >= GT().MAX_RESULTS) then miss[#miss + 1] = e[1] end
                end
                return #dup == 0 and #miss == 0, "doppelt: " .. table.concat(dup, ",") .. " fehlend: " .. table.concat(miss, ","), "keine"
            end)
        end
        local extra = { sandbox = sandbox, sprache = LP:Language(), spielsprache = GetLocale(), fehlerzaehler = LP.errorCount,
                        fehlerEindeutig = Count(LP.errors), initFehler = Count(LP.initErrors),
                        datenpaket = _G.LevelPilotData and _G.LevelPilotData.version, modus = LP.char.mode,
                        bereich = area or "alle", echteAktionen = (A.real - realBefore) + self.direct,
                        nichtAutomatisiert = self.notYet }
        -- T165: Bericht ohne Namen (vor Finish geprüft)
        if not area or area == "I" then
            T:Check("T165", "I", "Bericht gespeichert und datenschutzkonform", function()
                local enc = GT().Encode(T:Report(extra))
                local me = UnitName("player")
                local guild = GetGuildInfo and GetGuildInfo("player")
                local leak = (type(me) == "string" and me ~= "" and enc:find(me, 1, true)) or
                             (type(guild) == "string" and guild ~= "" and enc:find(guild, 1, true))
                local acts = (A.real - realBefore) + self.direct
                return not leak and acts == 0, "Namen im Bericht: " .. S(leak and true or false) .. ", echte Aktionen: " .. acts,
                    "keine Namen, 0 echte Aktionen"
            end)
        end
        local text = T:Finish(extra)
        -- Platzhalter zählen nicht als bestanden: eigene Zeile direkt unter der Zählung
        text = text:gsub("(OK %d+ · FEHLER %d+ · [^\n]*)", "%1\n" .. string.format("nicht automatisiert: %d", self.notYet), 1)
        -- 3.12.26 TU8: je Bereich TU1–TU7 eine Zeile
        local okTU, tu = pcall(self.TULines, self, T)
        if okTU then text = text .. "\n" .. table.concat(tu, "\n") end
        -- 3.12.28 MN3: Marktdaten-Netz
        pcall(LP.MarktSync, LP)
        local okM, ml = pcall(LP.MarktLine, LP)
        if okM and ml then text = text .. "\n" .. ml end
        -- 3.12.31 ML1: Selbstkontrolle "Meldungen"
        local okG, mg = pcall(LP.MessagesLine, LP)
        if okG and mg then text = text .. "\n" .. mg end
        text = text .. "\n" .. string.format("Sprache: %s (Spiel %s) · Datenpaket: %s", LP:Language(), tostring(GetLocale()),
            _G.LevelPilotData and tostring(_G.LevelPilotData.version) or "fehlt")
        text = text .. "\n" .. string.format("Fehlerzähler LevelPilot: %d (vor dem Test %d, eindeutig %d), Modulstartfehler: %d",
            LP.errorCount, errBefore, Count(LP.errors), Count(LP.initErrors))
        text = text .. "\n" .. (sandbox == "OK" and "echte Daten unverändert: OK" or ("echte Daten unverändert: " .. sandbox:gsub("^FEHLER: ", "FEHLER – ")))
        text = text .. "\n" .. string.format("mitgeschriebene Aktionen: %d · echte Aktionen: %d", A.dryCount, (A.real - realBefore) + self.direct)
        text = text .. "\n" .. "Bitte /reload"
        self.lastText = text
        LP.testGen = LP.testGen + 1
        for ev in pairs(WATCH) do pcall(watch.UnregisterEvent, watch, ev) end
        -- Nachlauf: Trockenlauf noch 5 s, dann Warteschlange von Comm auf den Stand vor dem Test
        C_Timer.After(5, function()
            A.dry = false
            if sb.queue and LP.Comm.QueueRestore then LP.Comm:QueueRestore(sb.queue) end
            SyncUndo(self.syncDry) self.syncDry = nil TR.syncHandle = nil
            if self.jobsSync ~= nil then LP.Jobs.sync = self.jobsSync self.jobsSync = nil end
            self.running = false
        end)
        pcall(LP.ResetLanguageCache, LP)
        pcall(LP.Planner.BuildCandidates, LP.Planner)
        pcall(LP.Planner.Replan, LP.Planner, true)
        pcall(LP.Nav.Recalc, LP.Nav, true)
        pcall(LP.UI.Refresh, LP.UI)
        pcall(LP.Center.Refresh, LP.Center)
        LP.Backup:ShowText(L["Testroutine"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."]
            .. " " .. L["Wird auch automatisch gemeldet."], text)
        LP:Reply(L["Bericht gespeichert – wird beim nächsten /reload oder Ausloggen an die Prüfung gemeldet"])
    end
    co = coroutine.create(body)
    local ticker
    ticker = C_Timer.NewTicker(0.05, function()
        sliceStart = Ms()
        local ok, err = coroutine.resume(co)
        if not ok then
            ticker:Cancel()
            A.dry = false
            if sb.queue and LP.Comm.QueueRestore then pcall(LP.Comm.QueueRestore, LP.Comm, sb.queue) end
            SyncUndo(self.syncDry) self.syncDry = nil TR.syncHandle = nil
            if self.jobsSync ~= nil then LP.Jobs.sync = self.jobsSync self.jobsSync = nil end
            pcall(Restore, sb)
            self.running = false
            LP.testGen = LP.testGen + 1
            for ev in pairs(WATCH) do pcall(watch.UnregisterEvent, watch, ev) end
            LP:Error("Testroutine", err)
        elseif coroutine.status(co) == "dead" then
            ticker:Cancel()
        end
    end)
end

-- Kurztest für alle Spieler (/lp test): nur lesende Prüfungen, gleicher Bericht
function TR:Short()
    if not GT() then LP.SelfTest:Run() return end
    local T = GT().Begin("LevelPilot", LP.version, LevelPilotDB)
    for _, e in ipairs(self.IDS) do if self.SHORT[e[1]] then RunOne(T, e) end end
    local text = T:Finish({ bereich = "kurz", sprache = LP:Language(), spielsprache = GetLocale(), fehlerzaehler = LP.errorCount,
        datenpaket = _G.LevelPilotData and _G.LevelPilotData.version })
    text = text .. "\n" .. string.format("Sprache: %s (Spiel %s) · Datenpaket: %s", LP:Language(), tostring(GetLocale()),
        _G.LevelPilotData and tostring(_G.LevelPilotData.version) or "fehlt")
    text = text .. "\n" .. string.format("Fehlerzähler LevelPilot: %d (eindeutig %d), Modulstartfehler: %d", LP.errorCount,
        Count(LP.errors), Count(LP.initErrors))
    LP.Backup:ShowText(L["Selbsttest"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."]
        .. " " .. L["Wird auch automatisch gemeldet."], text)
    return text
end

-- Halbautomatische Beobachtung (Launch-Abend): 2 Minuten, Aktionen mit Folgen nur mitgeschrieben (haendler, quest, flug)
local OBSERVE = { kampf = false, haendler = true, quest = true, flug = true, trainer = false, gruppe = false }
function TR:Observe(kind)
    if not LP:DevOnly() then return end
    if self.running then LP:Reply(L["Testroutine läuft bereits."]) return end
    local A = LP.Act
    local dry = OBSERVE[kind]
    self.running = true
    local err0, mark = LP.errorCount, #A.log
    if dry then A.dry = true end
    LP:Reply(L("Beobachtung „%s“ läuft 2 Minuten – jetzt die Aktion im Spiel ausführen.", kind))
    C_Timer.After(120, function()
        if dry then A.dry = false end
        self.running = false
        local names = {}
        for i = mark + 1, #A.log do names[#names + 1] = tostring(A.log[i].name) end
        LP:Reply(L("Beobachtung „%s“ beendet: neue Fehler %d, mitgeschriebene Aktionen: %s", kind, LP.errorCount - err0,
            #names > 0 and table.concat(names, ", ") or "–"))
    end)
end

function TR:Command(arg)
    arg = arg and arg:lower():gsub("^%s+", ""):gsub("%s+$", "") or ""
    if arg == "" then return self:Run(nil) end
    if #arg == 1 and AREAS:find(arg, 1, true) then return self:Run(arg) end
    if OBSERVE[arg] ~= nil then return self:Observe(arg) end
    if arg == "reise" or arg == "journey" then return self:Run(nil, true) end
    LP:Print(L["Testroutine: /lp testroutine [a–k | kampf | haendler | quest | flug | trainer | gruppe]"])
end
