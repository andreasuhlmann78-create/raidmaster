-- LevelPilot - Laufweg-Messung (LW-6, Auftrag des Nutzers 16.11.2026 07:30, Supervisor 07:34)
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Misst, wie gut LevelPilot durch die Welt führt – die Grundlage für jede Verbesserung der Laufwege (LW-1 bis LW-4):
--  * je Schritt: Luftlinie vom Start des Schritts zum Ziel, tatsächlich gelaufene Strecke bis zur Ankunft (40 Yards),
--    Zeit auf dem Weg und Zeit am Ziel, Art des Pfads während des Wegs (Netz / Gelände / Luftlinie / unbekannt)
--  * Neuplanungen, bei denen das Ziel wechselt, bevor der Schritt erledigt ist, und davon die mit Richtungswechsel (> 90°)
--  * Leerlauf: Zeit ohne Schritt mit Ziel (keine passende Quest, keine Position)
--  * je Level: aktive Spielzeit und erhaltene EP -> EP je Stunde
-- Nur Summen je Zone und je Level (klein, je Charakter). Nicht gezählt: AFK, tot, Flug (Strecke), Sprünge über 80 Yards je
-- Sekunde (Ruhestein, Ladebild), virtuelle Reise und Testroutine. Ergebnis: Zeilen "LAUFWEG" im Diagnose-Protokoll.
-- Kosten: ein Ticker je Sekunde mit einer Position, einer Entfernung und ein paar Additionen; beim Wechsel des Schritts
-- einmal die Schrittliste (höchstens 12 Einträge) durchsehen.

local _, LP = ...
local L = LP.L
local LW = {}
LP:RegisterModule("Laufweg", LW)

LW.JUMP = 80          -- Yards je Sekunde: mehr = Sprung (Ruhestein, Ladebild, Tod), zählt nicht als gelaufen
LW.ARRIVE = 40        -- Yards: am Ziel angekommen (wie Navigation N.ARRIVE)
LW.MIN_SECS = 10      -- kürzere Schritte zählen nicht (sofort erledigt, Durchklicken)
LW.TURN = 90          -- Grad: Richtungswechsel nach einer Neuplanung
LW.GAP = 5            -- Sekunden: längere Lücke zwischen zwei Messungen = Pause (Ladebild), zählt nicht
LW.VERSION = 1        -- Aufbau der gespeicherten Summen

local KINDS = { graph = "netz", cave = "netz", terrain = "gel", direct = "luft" }

-- Summen je Charakter: LevelPilotCharDB.laufweg
function LW.Store()
    local c = LP.char
    if type(c) ~= "table" then return nil end
    local s = c.laufweg
    if type(s) ~= "table" or s.v ~= LW.VERSION then
        s = { v = LW.VERSION, since = LP.version, z = {}, rev = 0, replans = 0, idle = 0, lvl = {} }
        c.laufweg = s
    end
    return s
end

local function Zone(s, map)
    local z = s.z[map]
    if not z then
        z = { n = 0, a = 0, luftA = 0, gelA = 0, tw = 0, tz = 0, k = { netz = 0, gel = 0, luft = 0, unb = 0, ohne = 0 } }
        s.z[map] = z
    end
    return z
end

-- Richtung (Grad) von (n, w) nach (n2, w2); Unterschied zweier Richtungen 0..180
local function Bearing(n, w, n2, w2) return math.deg(math.atan2(w2 - w, n2 - n)) end
local function Diff(a, b) local d = math.abs(a - b) % 360 return d > 180 and 360 - d or d end
LW.Diff = Diff

local function HasTarget(step)
    return step and step.inst and step.n and step.w and step.t ~= "LEVEL" and step.key ~= "NODATA" and step.key ~= "NOPOS"
end

-- Schritt abschliessen: in die Summen der Zone (nur ab MIN_SECS)
local function Finish(s, cur)
    if not cur then return end
    if cur.tw + cur.tz < LW.MIN_SECS then return end
    local z = Zone(s, cur.map or 0)
    z.n, z.tw, z.tz = z.n + 1, z.tw + cur.tw, z.tz + cur.tz
    if cur.arrived and cur.luft > 0 then z.a, z.luftA, z.gelA = z.a + 1, z.luftA + cur.luft, z.gelA + cur.gel end
    for k, v in pairs(cur.k) do z.k[k] = (z.k[k] or 0) + v end
end

LW.cur, LW.last = nil, nil

-- Eine Messung. o = { now, inst, n, w, map, step, kind, unknown, taxi, afk, dead, level, xp, xpMax, planned(key) }
-- (eigene Funktion mit allen Werten als Eingabe, damit die Testroutine sie ohne das Spiel prüfen kann)
function LW:Sample(o)
    local s = LW.Store()
    if not s then return end
    local last = self.last
    self.last = o
    if not last or not o.inst then return end
    local dt = (o.now or 0) - (last.now or 0)
    if dt <= 0 or dt > LW.GAP then return end
    -- EP je Level (auch beim Kampf, nicht bei AFK)
    if not o.afk and o.level then
        local b = s.lvl[o.level] or { s = 0, xp = 0 }
        s.lvl[o.level] = b
        b.s = b.s + dt
        if last.level == o.level and o.xp and last.xp and o.xp >= last.xp then
            b.xp = b.xp + (o.xp - last.xp)
        elseif last.level and o.level == last.level + 1 and o.xp and last.xp and last.xpMax then
            local old = s.lvl[last.level] or { s = 0, xp = 0 }
            s.lvl[last.level] = old
            old.xp = old.xp + math.max(0, last.xpMax - last.xp)
            b.xp = b.xp + o.xp
        end
    end
    if o.afk or o.dead then return end
    local step = o.step
    local cur = self.cur
    -- Wechsel des Schritts
    local key = HasTarget(step) and step.key or nil
    if cur and cur.key ~= key then
        local stillPlanned = cur.key and o.planned and o.planned(cur.key)
        if stillPlanned and key then
            s.replans = s.replans + 1
            local a = Bearing(o.n, o.w, cur.tn, cur.tw2)
            local b = Bearing(o.n, o.w, step.n, step.w)
            if Diff(a, b) > LW.TURN then s.rev = s.rev + 1 end
        end
        Finish(s, cur)
        cur = nil
        self.cur = nil
    end
    if not key then
        s.idle = s.idle + dt
        return
    end
    if not cur then
        -- der Schritt begann zwischen der letzten und dieser Messung: Start = letzte Position, diese Sekunde zählt schon mit
        local sn, sw = last.n, last.w
        if last.inst ~= o.inst then sn, sw = o.n, o.w end
        cur = { key = key, map = o.map, tn = step.n, tw2 = step.w, luft = (step.inst == o.inst) and LP.Geo:Dist(sn, sw, step.n, step.w) or 0,
                gel = 0, tw = 0, tz = 0, arrived = false, k = {} }
        self.cur = cur
    end
    -- gelaufen (gleiche Welt, kein Sprung, kein Flug)
    if not cur.arrived then
        if not o.taxi and last.inst == o.inst then
            local d = LP.Geo:Dist(last.n, last.w, o.n, o.w)
            if d <= LW.JUMP * dt then cur.gel = cur.gel + d end
        end
        if step.inst == o.inst and LP.Geo:Dist(o.n, o.w, step.n, step.w) <= LW.ARRIVE then cur.arrived = true end
    end
    if cur.arrived then
        cur.tz = cur.tz + dt
    else
        cur.tw = cur.tw + dt
        local k = o.unknown and "unb" or KINDS[o.kind or ""] or "ohne"
        cur.k[k] = (cur.k[k] or 0) + dt
    end
end

-- Werte aus dem Spiel sammeln (Ticker, 1 s)
local function Planned(key)
    for _, st in ipairs(LP.Planner and LP.Planner.steps or {}) do if st.key == key then return true end end
    return false
end
function LW:Tick()
    if (LP.Virtual and LP.Virtual.active) or (LP.Act and LP.Act.dry) then self.last, self.cur = nil, nil return end
    local S = LP.SafeValue
    local inst, n, w, map = LP.Geo:Player()
    local N = LP.Nav
    self:Sample({
        now = GetTime(), inst = inst, n = n, w = w, map = map, step = LP.Engine and LP.Engine:Current(),
        kind = N and N.pathKind, unknown = N and N.pathUnknown,
        taxi = UnitOnTaxi and S(UnitOnTaxi("player")) or false,
        afk = LP.Session and LP.Session.IsAFK and LP.Session:IsAFK() or false,
        dead = UnitIsDeadOrGhost and S(UnitIsDeadOrGhost("player")) or false,
        level = LP:RealLevel(), xp = UnitXP and S(UnitXP("player")), xpMax = UnitXPMax and S(UnitXPMax("player")),
        planned = Planned,
    })
end

------------------------------------------------------------------------
-- Zeilen für das Diagnose-Protokoll (nur Zahlen und Zonennamen)
------------------------------------------------------------------------
local function HM(secs)
    secs = math.floor((secs or 0) + 0.5)
    return string.format("%d:%02d", math.floor(secs / 3600), math.floor(secs % 3600 / 60))
end
local function Pct(a, b) return b > 0 and math.floor(a * 100 / b + 0.5) or 0 end
local function F2(x) return (string.format("%.2f", x):gsub("%.", ",")) end

function LW.Lines(s)
    s = s or LW.Store()
    if not s then return {} end
    local n, a, luftA, gelA, tw, tz = 0, 0, 0, 0, 0, 0
    local k = { netz = 0, gel = 0, luft = 0, unb = 0, ohne = 0 }
    local zones = {}
    for map, z in pairs(s.z) do
        n, a, luftA, gelA, tw, tz = n + z.n, a + z.a, luftA + z.luftA, gelA + z.gelA, tw + z.tw, tz + z.tz
        for kk, v in pairs(z.k) do k[kk] = (k[kk] or 0) + v end
        zones[#zones + 1] = { map = map, z = z }
    end
    local out = {}
    out[#out + 1] = ("LAUFWEG (seit %s): Schritte %d (angekommen %d) · Umweg gelaufen/Luftlinie %s · Zeit Weg %s / am Ziel %s (Weg-Anteil %d %%) · Leerlauf %s")
        :format(tostring(s.since), n, a, luftA > 0 and F2(gelA / luftA) or "–", HM(tw), HM(tz), Pct(tw, tw + tz), HM(s.idle))
    out[#out + 1] = ("LAUFWEG Pfad während des Wegs: Netz %d %% · Gelände %d %% · Luftlinie %d %% · unbekannt %d %% · ohne Pfad %d %%")
        :format(Pct(k.netz, tw), Pct(k.gel, tw), Pct(k.luft, tw), Pct(k.unb, tw), Pct(k.ohne, tw))
    out[#out + 1] = ("LAUFWEG Neuplanungen mit Zielwechsel %d, davon Richtungswechsel über %d° %d"):format(s.replans, LW.TURN, s.rev)
    table.sort(zones, function(x, y) return x.z.n > y.z.n end)
    local parts = {}
    for i = 1, math.min(8, #zones) do
        local z = zones[i].z
        local name = (zones[i].map ~= 0 and LP.Geo.MapName and LP.Geo:MapName(zones[i].map)) or "?"
        parts[#parts + 1] = ("%s %s (%d, Weg %d %%)"):format(name, z.luftA > 0 and F2(z.gelA / z.luftA) or "–", z.n, Pct(z.tw, z.tw + z.tz))
    end
    out[#out + 1] = "LAUFWEG je Zone (Umweg, Schritte, Weg-Anteil): " .. (#parts > 0 and table.concat(parts, " · ") or "noch keine Messung")
    local lv = {}
    for l in pairs(s.lvl) do lv[#lv + 1] = l end
    table.sort(lv)
    parts = {}
    for i = math.max(1, #lv - 7), #lv do
        local b = s.lvl[lv[i]]
        if b.s >= 60 then parts[#parts + 1] = ("%d: %d (%s h)"):format(lv[i], math.floor(b.xp * 3600 / b.s + 0.5), HM(b.s)) end
    end
    out[#out + 1] = "EP/h je Level (aktive Zeit): " .. (#parts > 0 and table.concat(parts, " · ") or "noch keine Messung")
    return out
end

function LW:Init()
    LP:Ticker("laufweg", 1, function() LW:Tick() end)
end
