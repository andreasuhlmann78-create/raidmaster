-- LevelPilot - Selbsttest: prueft alle Funktionen im Spiel und zeigt einen Bericht zum Kopieren
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Liest nur und rechnet; es wird nichts gekauft, angenommen, angeklickt oder verschickt.
-- Ergebnis je Pruefung: OK, HINWEIS (funktioniert, aber auffaellig) oder FEHLER.
-- Optional am Ende: kurze virtuelle Reise (5 Level ab dem aktuellen), um Planung und Wege zu pruefen.

local _, LP = ...
local L = LP.L
local T = {}
LP:RegisterModule("SelfTest", T)

local results
local function add(state, area, text)
    results[#results + 1] = { state = state, area = area, text = tostring(text or "") }
end
local function ok(area, text) add("OK", area, text) end
local function warn(area, text) add("HINWEIS", area, text) end
local function bad(area, text) add("FEHLER", area, text) end

local function count(t) local n = 0 for _ in pairs(t or {}) do n = n + 1 end return n end

local CHECKS = {}
local function check(name, fn) CHECKS[#CHECKS + 1] = { name = name, fn = fn } end

check("Module", function()
    local n, failed = #LP.modules, {}
    for name, err in pairs(LP.initErrors or {}) do failed[#failed + 1] = name .. ": " .. err end
    if #failed > 0 then bad("Module", table.concat(failed, "; ")) else ok("Module", L("%d Module gestartet", n)) end
    local e = count(LP.errors)
    if e > 0 then warn("Module", L("%d Fehlermeldung(en) seit dem Einloggen – siehe /lp protokoll", e)) end
end)

-- Schnittstellen, die auf dem modernen Client fehlen koennen (dann fallen einzelne Hinweise weg)
check("Schnittstellen", function()
    local _, class = UnitClass("player")
    local missing = {}
    if not (UnitCharacterPoints or GetUnspentTalentPoints) then missing[#missing + 1] = L["Talentpunkte"] end
    if class == "HUNTER" and not GetPetHappiness then missing[#missing + 1] = L["Zufriedenheit des Begleiters"] end
    if class == "HUNTER" and not GetPetFoodTypes then missing[#missing + 1] = L["Futter des Begleiters"] end
    if not (ChatFrame_OpenChat or (ChatFrameUtil and ChatFrameUtil.OpenChat)) then missing[#missing + 1] = L["Chatfeld öffnen"] end
    if not ((C_SpellBook and C_SpellBook.IsSpellKnown) or IsSpellKnown or IsPlayerSpell) then missing[#missing + 1] = L["bekannte Zauber"] end
    if #missing > 0 then warn("Schnittstellen", L("nicht verfügbar: %s – diese Hinweise fallen weg", table.concat(missing, ", ")))
    else ok("Schnittstellen", L["alle benötigten Spielfunktionen vorhanden"]) end
end)

check("Spielversion", function()
    local G = LP.Game
    if not G then warn("Spielversion", L["GoldSentinelGame.lua fehlt"]) return end
    -- Erkennung pruefen: erzwungenes Forever muss die moderne API ergeben, danach wieder die echte Erkennung
    G.SetTestFlavor("forever")
    local modern = G.IsModern and G.IsForever and not G.IsOldAPI
    G.SetTestFlavor(nil)
    if not modern then bad("Spielversion", L["Erkennung falsch: WoW Forever gilt nicht als moderne Schnittstelle"]) end
    if G.IsForever then ok("Spielversion", G.Status())
    else warn("Spielversion", G.Status() .. L[" – LevelPilot ist für WoW Forever gebaut"]) end
end)

check("Daten", function()
    local d = _G.LevelPilotData
    if type(d) ~= "table" then bad("Daten", L["Datenpaket LevelPilot_Data fehlt"]) return end
    local c = LP.QuestDB:Counts()
    ok("Daten", L("Datenpaket %s · Quests: Paket %d, Startdatenbank %d, eigene %d, andere %d", tostring(d.version), c.pack, c.seed, c.own, c.net))
    if not LP.QuestDB.pack then bad("Daten", L["Datenpaket ist installiert, aber nicht verbunden (Einstellungen » Datenpaket nutzen)"]) end
end)

check("Sprache", function()
    local lang, client = LP:Language(), LP:ClientLanguage()
    ok("Sprache", L("eingestellt %s, Spiel %s", lang, client))
    if not LP:CanDisplay(lang) then bad("Sprache", L["die eingestellte Sprache kann das Spiel nicht anzeigen"]) end
    -- fehlende Uebersetzungen der benutzten Texte
    if lang ~= "de" then
        local miss, ex = 0, nil
        for k in pairs(LP.usedKeys or {}) do
            local t = LP.Locales[lang]
            local fb = LP.LanguageInfo[lang] and LP.LanguageInfo[lang].fallback
            if not ((t and t[k]) or (fb and LP.Locales[fb] and LP.Locales[fb][k]) or (lang == "en" and LP.Locales.en and LP.Locales.en[k])) then
                miss = miss + 1 ex = ex or k
            end
        end
        if miss > 0 then warn("Sprache", L("%d Text(e) ohne eigene Übersetzung (englisch angezeigt), z. B. „%s“", miss, tostring(ex):sub(1, 50)))
        else ok("Sprache", L["alle benutzten Texte übersetzt"]) end
    end
    if LP.Names then
        local st = LP.Names:StatusText()
        if st:find("ok") or st:find(L["geladen"], 1, true) or lang == "en" or lang == "it" then ok("Namen", st) else bad("Namen", st) end
        local q = LP.QuestDB:Get(844) or LP.QuestDB:Get(7)
        if q then ok("Namen", L("Beispiel: %s", q.name)) end
    end
end)

check("Position", function()
    local inst, n, w, map, x, y = LP.Geo:Player()
    if not map then bad("Position", L["Position unbekannt"]) return end
    local zone = LP.Protocol and LP.Protocol.ZoneOf and LP.Protocol.ZoneOf(map)
    local real = GetRealZoneText and GetRealZoneText()
    local name = zone and zone.name or LP.Geo:MapName(map)
    if real and real ~= "" and zone and zone.name and not LP:SameZoneName(zone.name, real) and not (IsInInstance and IsInInstance()) then
        bad("Position", L("LevelPilot erkennt %s (%d), das Spiel zeigt %s", zone.name, zone.mapID or map, real))
    else
        ok("Position", string.format("%s (%d) %.1f, %.1f", name, map, x or 0, y or 0))
    end
    if not inst then bad("Position", L["keine Weltkoordinaten für diese Karte"]) end
end)

check("Planung", function()
    local t0 = debugprofilestop and debugprofilestop() or 0
    LP.Planner:Replan(true)
    local ms = debugprofilestop and math.floor(debugprofilestop() - t0) or 0
    local steps = LP.Engine:Steps()
    local st = LP.Engine:Current()
    if #steps == 0 then bad("Planung", L("keine Schritte (Zustand %s)", tostring(LP.Planner.state)))
    else ok("Planung", L("%d Schritte in %d ms · nächster: %s", #steps, ms, LP.UI and LP.UI:StepText(st, false):match("^[^\n]*") or "?")) end
    if ms > 500 then warn("Planung", L("Planung dauert lange (%d ms)", ms)) end
    if LP.Planner.focus then ok("Planung", L("Fokus %s", LP.Geo:MapName(LP.Planner.focus))) end
end)

check("Weg", function()
    if not LP.Nav then return end
    LP.Nav:Recalc(true)
    local tgt = LP.Nav.target
    if not tgt then warn("Weg", L["kein Ziel (Schritt ohne Ort)"]) return end
    if LP.Nav.hasPath then
        local d = LP.Nav.RemainingDistance and LP.Nav:RemainingDistance()
        ok("Weg", L("Weg zu „%s“ gefunden (%s, %s)", tostring(tgt.label or tgt.key), tostring(LP.Nav.pathKind), d and LP:FormatDist(d) or "?"))
    else
        bad("Weg", L("kein Weg zu „%s“ %s", tostring(tgt.label or tgt.key), LP.Nav.pathError or ""))
    end
    local _, _, _, map = LP.Geo:Player()
    if LP.Terrain and LP.Terrain.Available and not LP.Terrain:Available(map) then warn("Weg", L["keine Geländekarte für diese Zone"]) end
    if LP.Caves then ok("Weg", L("Höhlen und Tunnel bekannt: %d (selbst gelernt %d, von anderen %d)", LP.Caves:Count())) end
end)

check("Flüge", function()
    local ok_, all = LP.Geo:TaxiUsable()
    local known = 0 for _ in pairs(LP.char.taxiKnown or {}) do known = known + 1 end
    if all == 0 then warn("Flüge", L["noch keine Flugpunkte aufgezeichnet – einmal die Flugkarte bei einem Flugmeister öffnen"])
    elseif ok_ < all then warn("Flüge", L("%d von %d Flugpunkten verortet, %d bekannt", ok_, all, known))
    else ok("Flüge", L("%d von %d Flugpunkten verortet, %d bekannt", ok_, all, known)) end
end)

check("Anzeige", function()
    if LP.UI and LP.UI.frame then
        if LP.UI.frame:IsShown() then ok("Anzeige", L["Leitfaden-Fenster sichtbar"]) else warn("Anzeige", L["Leitfaden-Fenster ausgeblendet"]) end
    end
    -- abgeschnittene Knopf-Beschriftungen
    local cut = {}
    for b in pairs(LP.UI and LP.UI.buttons or {}) do
        local fs = b.label
        if fs and b.IsVisible and b:IsVisible() and fs.GetStringWidth and fs:GetText() and fs:GetText() ~= "" then
            if (fs:GetStringWidth() or 0) > (b:GetWidth() or 0) - 2 then cut[#cut + 1] = fs:GetText() end
        end
    end
    if #cut > 0 then warn("Anzeige", L("%d Knopf-Beschriftung(en) zu lang: %s", #cut, table.concat(cut, ", "):sub(1, 120)))
    else ok("Anzeige", L["alle Knopf-Beschriftungen passen"]) end
    if LP.Pins then
        LP.Pins:Refresh()
        ok("Karte", L("%d Questgebiete, %d Fundstellen, %d annehmbare Quests", #LP.Pins.areas, #LP.Pins.objects, #LP.Pins.avail))
    end
    if LP.Plates then ok("Plaketten", LP.db.platesQuest and L["Questfortschritt über den Gegnern an"] or L["Questfortschritt über den Gegnern aus"]) end
end)

check("Ziel", function()
    if not (LP.Actions and LP.Actions.btnTarget) then return end
    local mt = LP.Actions.btnTarget.GetAttribute and LP.Actions.btnTarget:GetAttribute("macrotext") or ""
    if #mt > 255 then bad("Ziel", L("Ziel-Makro zu lang (%d Zeichen)", #mt))
    elseif mt:find("/targetexact") then ok("Ziel", (mt:match("/targetexact ([^\n]+)") or "")) else ok("Ziel", L["kein Gegner im aktuellen Schritt"]) end
end)

check("Komfort", function()
    if LP.Session then
        ok("Sitzung", L("aktive Zeit %s, Gold pro Stunde %s", LP.Comfort.Dur(LP.Session:Clock()),
            LP.Session:GoldPerHour() and LP.Session.Money(LP.Session:GoldPerHour()) or "–"))
    end
    if LP.Supply then
        local okp, plan = pcall(LP.Supply.Needs, LP.Supply)
        if okp then ok("Vorräte", L["Bedarf berechnet"]) else bad("Vorräte", tostring(plan)) end
    end
    if LP.Advisor then LP.Advisor:Run() ok("Assistent", L("%d Hinweis(e)", #(LP.Advisor.hints or {}))) end
    if LP.Hints then
        local okh, up = pcall(LP.Hints.UpcomingClassQuests, LP.Hints)
        if okh then ok("Hinweise", L("Klassenquests bald: %d", #(up or {}))) else bad("Hinweise", tostring(up)) end
    end
end)

check("Austausch", function()
    if LP.Comm and LP.Comm.Stats then
        local okc, s = pcall(LP.Comm.Stats, LP.Comm)
        if okc and type(s) == "table" then ok("Austausch", L("gesendet %s, empfangen %s", tostring(s.sent or "?"), tostring(s.received or s.recv or "?")))
        else ok("Austausch", L["Modul bereit"]) end
    end
    if LP.Protocol then
        local n = LP.Protocol:Count()
        if n == 0 then ok("Protokoll", L("%d Auffälligkeit(en) im Fehler-Protokoll", n))
        else warn("Protokoll", L("%d Auffälligkeit(en) im Fehler-Protokoll", n)) end
    end
end)

------------------------------------------------------------------------
function T:Run(withJourney)
    results = {}
    for _, c in ipairs(CHECKS) do
        local okc, err = pcall(c.fn)
        if not okc then bad(c.name, L("Prüfung abgebrochen: %s", tostring(err))) end
    end
    return results
end

function T:Text(res)
    res = res or results or {}
    local out = { L("LevelPilot – Selbsttest · v%s · %s", LP.version, date("%d.%m.%Y %H:%M")) }
    local nb, nw = 0, 0
    for _, r in ipairs(res) do
        if r.state == "FEHLER" then nb = nb + 1 elseif r.state == "HINWEIS" then nw = nw + 1 end
    end
    out[#out + 1] = L("Ergebnis: %d Prüfungen, %d Fehler, %d Hinweise", #res, nb, nw)
    out[#out + 1] = ""
    for _, r in ipairs(res) do
        out[#out + 1] = string.format("[%s] %s: %s", L[r.state], L[r.area], r.text)
    end
    return (table.concat(out, "\n"):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
end

function T:Show(withJourney)
    local res = self:Run()
    local function show()
        local nb = 0
        for _, r in ipairs(res) do if r.state == "FEHLER" then nb = nb + 1 if LP.Protocol then LP.Protocol:AddL("error", "Selbsttest %s: %s", L[r.area], r.text) end end end
        LP:Print(nb == 0 and L["Selbsttest: alles in Ordnung."] or L("Selbsttest: %d Fehler gefunden.", nb))
        LP.Backup:ShowText(L["Selbsttest"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."], self:Text(res))
    end
    if not (withJourney and LP.Virtual and not LP.Virtual.active) then return show() end
    -- kurze Reise ab hier (5 Level) im Hintergrund, danach der Bericht
    local lvl = UnitLevel("player") or 1
    LP.Virtual:Start("here", { maxLevel = math.min(60, lvl + 5), onDone = function(_, s)
        local p = s and #s.problems or 0
        local line = L("ab Level %d bis %d: %d Schritte, %d Quests, %d Auffälligkeit(en)", s.startLevel, s.level, s.steps, s.quests, p)
        if p == 0 then add("OK", "Reise", line) else add("HINWEIS", "Reise", line .. L[" – Einzelheiten im Bericht der virtuellen Reise"]) end
        show()
    end })
end
