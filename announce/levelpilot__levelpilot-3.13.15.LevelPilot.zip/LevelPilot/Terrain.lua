-- LevelPilot - Gelaendefuehrung
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Addons koennen das Gelaende (Hoehen, Felsen, Wasser) nicht auslesen. Ersatz: die Gelaendekarte
-- aus dem Datenpaket. Wo Kreaturen und Objekte stehen, ist begehbarer Boden; Patrouillenwege der
-- Wachen sind meist Strassen; leere Flaechen sind oft Berge, Felswaende oder Wasser.
-- Abschnitte des Weges, die nicht ueber selbst gelaufene Wege fuehren, werden ueber diese Karte
-- gelegt: Strassen bevorzugt, Unbekanntes gemieden, danach geglaettet.

local _, LP = ...
local T = {}
LP:RegisterModule("Terrain", T)

local COST = { [0] = 3.5, [1] = 1.0, [2] = 0.45 }   -- unbekannt / begehbar / Strasse
local NEAR = 30               -- Zellen: Kostenfeld nur im Umkreis des Ziels (schneller), sonst ganze Zone
local MIN_SEGMENT = 70        -- Yards: kuerzere Abschnitte bleiben gerade
local MAX_DETOUR = 2.4        -- laengere Umwege als x-mal Luftlinie werden verworfen
-- (3.13.10: MAX_GRIDS entfällt – Gitter werden nicht mehr entpackt, siehe Grid)
local MAX_FIELDS = 10         -- gespeicherte Kostenfelder (je Ziel)
local B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

local DEC = {}
for i = 1, 64 do DEC[B64:sub(i, i)] = i - 1 end
-- 3.12.97: dasselbe je Bytewert (Entpacken mit string.byte in Blöcken statt s:sub je Zeichen; gleiches Ergebnis, T360)
local DECB = {}
for ch, v in pairs(DEC) do DECB[ch:byte()] = v end
T.DEC, T.DECB = DEC, DECB

local grids, gridOrder = {}, {}
local fields, fieldOrder = {}, {}
T.stats = { refined = 0, fields = 0 }

local function Source()
    local d = _G.LevelPilotData
    if type(d) ~= "table" or type(d.T) ~= "table" or not LP.QuestDB.pack then return nil end
    return d
end

T.Source = Source          -- Testroutine (T383)

function T:Available(map)
    local d = Source()
    return d and map and d.T[map] ~= nil or false
end

-- 2 Bit je Zelle, 3 Zellen je Zeichen. 3.12.97 (Profil Ingametest 3.12.95 T295/T129: Entpacken der Geländekarte im langen Bild):
-- string.byte in Blöcken zu 2000 Zeichen (Lua 5.1: Rückgabewerte auf dem C-Stapel, Grenze ~8000) statt s:sub je Zeichen
function T.DecodeInto(g, s)
    local i, n = 0, #s
    for c0 = 1, n, 2000 do
        local bytes = { s:byte(c0, math.min(n, c0 + 1999)) }
        for k = 1, #bytes do
            local v = DECB[bytes[k]] or 0
            g[i] = v % 4
            g[i + 1] = math.floor(v / 4) % 4
            g[i + 2] = math.floor(v / 16) % 4
            i = i + 3
        end
    end
    return g
end
-- bisheriger Weg (nur Testroutine T360: Gegenprobe gleiches Ergebnis)
function T.DecodeOld(g, s)
    local i = 0
    for c = 1, #s do
        local v = DEC[s:sub(c, c)] or 0
        g[i] = v % 4
        g[i + 1] = math.floor(v / 4) % 4
        g[i + 2] = math.floor(v / 16) % 4
        i = i + 3
    end
    return g
end

-- Gitter einer Zone (2 Bit je Zelle, 3 Zellen je Zeichen).
-- 3.13.10 LP-T2-a (Prüfung 23.11.: "Anlegen je Portion messen und senken"): belegt im Nachbau – die unerreichbare Wegsuche legte
-- 12,8 MB an, grösste Portion 1273 KB; den grössten Teil das Entpacken der Geländekarten (je Zone ~310 KB Tabelle), weil nur 6 Zonen
-- im Speicher blieben (MAX_GRIDS) und die Suche über mehr Zonen läuft -> immer wieder neu entpackt. Jetzt wird nichts entpackt: das Gitter
-- liest jede Zelle direkt aus dem gepackten Text (gleiche Werte wie T.DecodeInto, Prüfung T360/T383), kein Anlegen, kein Verdrängen.
local floor, byte = math.floor, string.byte
local GridMT = {
    __index = function(g, i)
        if type(i) ~= "number" then return nil end
        local c = floor(i / 3)
        local b = byte(rawget(g, "s"), c + 1)
        if not b then return nil end
        local v = DECB[b] or 0
        local sh = i - c * 3
        if sh == 0 then return v % 4 elseif sh == 1 then return floor(v / 4) % 4 end
        return floor(v / 16) % 4
    end,
}
local function Grid(map)
    local g = grids[map]
    if g then return g end
    local d = Source()
    local s = d and d.T[map]
    if not s then return nil end
    g = setmetatable({ size = d.TG or 100, s = s }, GridMT)
    grids[map] = g
    return g
end
T.Grid = Grid             -- Testroutine (T383: gleiche Zellen wie T.DecodeInto)

-- Kleiner Binaerheap
local function Push(h, id, prio)
    local n = #h + 1
    h[n] = { id, prio }
    while n > 1 do
        local p = math.floor(n / 2)
        if h[p][2] <= h[n][2] then break end
        h[p], h[n] = h[n], h[p]
        n = p
    end
end
local function Pop(h)
    local n = #h
    if n == 0 then return nil end
    local top = h[1]
    h[1] = h[n]
    h[n] = nil
    n = n - 1
    local i = 1
    while true do
        local l, r, s = i * 2, i * 2 + 1, i
        if l <= n and h[l][2] < h[s][2] then s = l end
        if r <= n and h[r][2] < h[s][2] then s = r end
        if s == i then break end
        h[i], h[s] = h[s], h[i]
        i = s
    end
    return top[1], top[2]
end

local NB = { { 1, 0, 1 }, { -1, 0, 1 }, { 0, 1, 1 }, { 0, -1, 1 },
             { 1, 1, 1.4142 }, { 1, -1, 1.4142 }, { -1, 1, 1.4142 }, { -1, -1, 1.4142 } }

-- Kostenfeld zum Ziel (Dijkstra ueber die ganze Zone), wird je Ziel zwischengespeichert
local function Field(map, g, goal, radius)
    local key = map .. ":" .. goal .. ":" .. (radius or 0)
    local f = fields[key]
    if f then return f end
    local size = g.size
    local gx, gy = goal % size, math.floor(goal / size)
    f = {}
    f[goal] = 0
    local h = {}
    Push(h, goal, 0)
    local pops = 0
    while true do
        local u, du = Pop(h)
        if not u then break end
        -- 3.12.24: in der Hintergrund-Arbeit nach dem Budget dieses Bildes abgeben
        pops = pops + 1
        if pops % 50 == 0 then LP:Yield("graph") end
        if du <= f[u] then
            local ux, uy = u % size, math.floor(u / size)
            local cu = COST[g[u] or 0]
            for _, nb in ipairs(NB) do
                local vx, vy = ux + nb[1], uy + nb[2]
                if vx >= 0 and vy >= 0 and vx < size and vy < size
                   and (not radius or (math.abs(vx - gx) <= radius and math.abs(vy - gy) <= radius)) then
                    local v = vy * size + vx
                    local nd = du + (cu + COST[g[v] or 0]) * 0.5 * nb[3]
                    local old = f[v]
                    if not old or nd < old then
                        f[v] = nd
                        Push(h, v, nd)
                    end
                end
            end
        end
    end
    fields[key] = f
    fieldOrder[#fieldOrder + 1] = key
    if #fieldOrder > MAX_FIELDS then
        local old = table.remove(fieldOrder, 1)
        fields[old] = nil
    end
    T.stats.fields = T.stats.fields + 1
    return f
end

-- Zellenfolge vom Start zum Ziel entlang des Feldes
local function Trace(g, f, start, goal)
    local size = g.size
    local cells = { start }
    local cur, guard = start, size * 4
    while cur ~= goal and guard > 0 do
        guard = guard - 1
        local cx, cy = cur % size, math.floor(cur / size)
        local best, bestV
        for _, nb in ipairs(NB) do
            local vx, vy = cx + nb[1], cy + nb[2]
            if vx >= 0 and vy >= 0 and vx < size and vy < size then
                local v = vy * size + vx
                local fv = f[v]
                if fv then
                    local val = fv + (COST[g[cur] or 0] + COST[g[v] or 0]) * 0.5 * nb[3]
                    if not bestV or val < bestV then best, bestV = v, val end
                end
            end
        end
        if not best or (f[best] or 1e9) >= (f[cur] or 1e9) then break end
        cur = best
        cells[#cells + 1] = cur
    end
    return cells
end

-- Ramer-Douglas-Peucker auf Kartenpunkten
local function Simplify(pts, eps)
    if #pts <= 2 then return pts end
    local keep = { [1] = true, [#pts] = true }
    local function rdp(a, b)
        local ax, ay, bx, by = pts[a][1], pts[a][2], pts[b][1], pts[b][2]
        local dx, dy = bx - ax, by - ay
        local len = math.sqrt(dx * dx + dy * dy)
        local far, idx = 0, nil
        for i = a + 1, b - 1 do
            local d
            if len == 0 then
                d = math.sqrt((pts[i][1] - ax) ^ 2 + (pts[i][2] - ay) ^ 2)
            else
                d = math.abs(dy * pts[i][1] - dx * pts[i][2] + bx * ay - by * ax) / len
            end
            if d > far then far, idx = d, i end
        end
        if idx and far > eps then
            keep[idx] = true
            rdp(a, idx)
            rdp(idx, b)
        end
    end
    rdp(1, #pts)
    local out = {}
    for i = 1, #pts do if keep[i] then out[#out + 1] = pts[i] end end
    return out
end

-- Chaikin-Glaettung (Endpunkte bleiben)
local function Smooth(pts, rounds)
    for _ = 1, rounds do
        if #pts < 3 then return pts end
        local out = { pts[1] }
        for i = 1, #pts - 1 do
            local a, b = pts[i], pts[i + 1]
            out[#out + 1] = { a[1] * 0.75 + b[1] * 0.25, a[2] * 0.75 + b[2] * 0.25 }
            out[#out + 1] = { a[1] * 0.25 + b[1] * 0.75, a[2] * 0.25 + b[2] * 0.75 }
        end
        out[#out + 1] = pts[#pts]
        pts = out
    end
    return pts
end

-- Einen Abschnitt in derselben Zone dem Gelaende anpassen; liefert Zwischenpunkte oder nil
function T:Segment(map, a, b)
    local g = Grid(map)
    if not g then return nil end
    local ax, ay = LP.Geo:ToMap(map, a[1], a[2], a[3])
    local bx, by = LP.Geo:ToMap(map, b[1], b[2], b[3])
    if not ax or not bx then return nil end
    ax, ay = LP.Geo:ToData(map, ax, ay)          -- 3.12.55 LW-5: Gelaendekarte im Forever-Rahmen
    bx, by = LP.Geo:ToData(map, bx, by)
    local size = g.size
    local function cell(x, y)
        local cx = math.max(0, math.min(size - 1, math.floor(x * size / 100)))
        local cy = math.max(0, math.min(size - 1, math.floor(y * size / 100)))
        return cy * size + cx
    end
    local sc, gc = cell(ax, ay), cell(bx, by)
    if sc == gc then return nil end
    local sx, sy, gx, gy = sc % size, math.floor(sc / size), gc % size, math.floor(gc / size)
    local radius = (math.abs(sx - gx) <= NEAR - 5 and math.abs(sy - gy) <= NEAR - 5) and NEAR or nil
    local f = Field(map, g, gc, radius)
    local cells = Trace(g, f, sc, gc)
    if cells[#cells] ~= gc then return nil end
    -- Zellmitten in Kartenkoordinaten, Endpunkte exakt
    local pts = { { ax, ay } }
    for i = 2, #cells - 1 do
        local c = cells[i]
        pts[#pts + 1] = { (c % size + 0.5) * 100 / size, (math.floor(c / size) + 0.5) * 100 / size }
    end
    pts[#pts + 1] = { bx, by }
    pts = Smooth(Simplify(pts, 0.9 * 100 / size), 2)
    -- in Weltkoordinaten; zu grosse Umwege verwerfen
    local out, len = {}, 0
    local pn, pw = a[2], a[3]
    for i = 2, #pts - 1 do
        local inst, n, w = LP.Geo:ToWorld(map, LP.Geo:FromData(map, pts[i][1], pts[i][2]))
        if inst ~= a[1] then return nil end
        len = len + LP.Geo:Dist(pn, pw, n, w)
        pn, pw = n, w
        out[#out + 1] = { inst, n, w, map, terrain = true }
    end
    len = len + LP.Geo:Dist(pn, pw, b[2], b[3])
    if len > LP.Geo:Dist(a[2], a[3], b[2], b[3]) * MAX_DETOUR then return nil end
    return out
end

-- Begehbarer Boden an einem Kartenpunkt (x, y in Prozent)? true/false; nil = keine Gelaendekarte fuer die Zone.
-- Geprueft wird die Zelle und ihre Nachbarn (3.12.7: unplausible aufgezeichnete Orte, z. B. mitten im Gebirge)
function T:Walkable(map, x, y)
    local g = map and x and y and Grid(map)
    if not g then return nil end
    x, y = LP.Geo:ToData(map, x, y)              -- 3.12.55 LW-5: Gelaendekarte im Forever-Rahmen
    local size = g.size
    local cx, cy = math.floor(x * size / 100), math.floor(y * size / 100)
    for dy = -1, 1 do
        for dx = -1, 1 do
            local ix, iy = cx + dx, cy + dy
            if ix >= 0 and iy >= 0 and ix < size and iy < size and (g[iy * size + ix] or 0) > 0 then return true end
        end
    end
    return false
end

-- Wie viel unbekanntes Gelaende (Berge, Felsen, Wasser) liegt auf einer Luftlinie? 0..1
-- Fuer die Wegsuche: Luftlinien quer ueber Berge werden teurer, gelaufene Wege durch
-- Tunnel und Paesse gewinnen dadurch.
function T:Unknown(map, a, b)
    if not map or not LP.db.terrainPath then return 0 end
    local g = Grid(map)
    if not g then return 0 end
    local ax, ay = LP.Geo:ToMap(map, a[1], a[2], a[3])
    local bx, by = LP.Geo:ToMap(map, b[1], b[2], b[3])
    if not ax or not bx then return 0 end
    ax, ay = LP.Geo:ToData(map, ax, ay)          -- 3.12.55 LW-5: Gelaendekarte im Forever-Rahmen
    bx, by = LP.Geo:ToData(map, bx, by)
    local size = g.size
    local steps = math.max(2, math.min(40, math.floor(math.max(math.abs(bx - ax), math.abs(by - ay)) * size / 100) + 1))
    local unknown = 0
    for i = 0, steps do
        local f = i / steps
        local cx = math.max(0, math.min(size - 1, math.floor((ax + (bx - ax) * f) * size / 100)))
        local cy = math.max(0, math.min(size - 1, math.floor((ay + (by - ay) * f) * size / 100)))
        if (g[cy * size + cx] or 0) == 0 then unknown = unknown + 1 end
    end
    return unknown / (steps + 1)
end

-- Ganzen Weg verfeinern: lange Luftlinien-Abschnitte innerhalb einer Zone folgen dem Gelaende.
-- Unveraendert bleiben: gelaufene Wege, Zonenuebergaenge (Tunnel, Paesse, Bruecken) und
-- Abschnitte in Hoehlen (dort hat die Gelaendekarte keine Bedeutung).
local function Keep(a, b)
    if a.cave or b.cave then return true end
    local via = b.via
    if via and via ~= "v" then return true end      -- Kante aus dem Wegenetz
    if a.gw and b.gw then return true end            -- Uebergang zwischen zwei Zonen
    return false
end
T.Keep = Keep

function T:Refine(path)
    if not path or not LP.db.terrainPath or not Source() then return path, false end
    local out, changed = { path[1] }, false
    for i = 2, #path do
        local a, b = path[i - 1], path[i]
        local map = (a[4] and b[4] and a[4] == b[4]) and a[4] or nil
        if map and a[1] == b[1] and not Keep(a, b) and LP.Geo:Dist(a[2], a[3], b[2], b[3]) >= MIN_SEGMENT
           and self:Available(map) then
            -- in der Hintergrund-Arbeit ohne pcall (dort darf abgegeben werden; Fehler faengt die Coroutine)
            local ok, mid
            if LP.Jobs and LP.Jobs.Current() then ok, mid = true, self:Segment(map, a, b)
            else ok, mid = LP.PCall(self.Segment, self, map, a, b) end    -- 3.12.93: = pcall (ausser in der Testroutine, TR.Coop)
            if ok and mid then
                for _, p in ipairs(mid) do out[#out + 1] = p end
                changed = true
            end
        end
        out[#out + 1] = b
    end
    if changed then T.stats.refined = T.stats.refined + 1 end
    return out, changed
end

function T:Clear()
    wipe(grids) wipe(gridOrder) wipe(fields) wipe(fieldOrder)
end

function T:Init()
    -- 3.12.24: die Gelaendekarte kommt aus dem Datenpaket – nur neu lesen, wenn sich das Paket aendert (vorher bei
    -- jeder empfangenen Quest: Zwischenspeicher der Wegsuche leer, jede Suche wieder teuer)
    local pack = LP.QuestDB.pack
    LP:Listen("QDB_CHANGED", function()
        if LP.QuestDB.pack == pack then return end
        pack = LP.QuestDB.pack
        T:Clear()
        if LP.Graph.ClearTerrainCache then LP.Graph:ClearTerrainCache() end
    end)
end
