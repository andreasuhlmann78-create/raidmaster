# AHSentinel (früher AH Analyzer Pro) – Änderungen (deutsch)

Diese Datei ist die deutsche Zusammenfassung für Discord. Die ausführliche englische Fassung steht in CHANGELOG.md.

## 0.65.424
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Diagnose:** auf WoW Forever meldet der Server den eigenen Sniper-Kauf zusätzlich als "Auktion abgebrochen" mit derselben Auktion. Das Protokoll nennt das jetzt "eigener Kauf" statt "unerwartet". Gebucht oder geändert wird nichts.

## 0.65.423
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper mit mehreren Zielen:** Fenster und Kaufen-Knopf wechseln jetzt zwischen den Treffern aller Ziele. Vorher blieb ein Ziel mit Dauertreffer weit unter seinem Max immer vorne, und ein Treffer genau am Max eines anderen Ziels kam nie nach vorne (nur der Chat wechselte). Der vordere Treffer bleibt jetzt mindestens 3 Sekunden, dann übernimmt der Treffer des nächsten Ziels (nicht, während ein Kauf läuft).
- Wartet ein Treffer, zeigt die Statuszeile zusätzlich, welches andere Ziel gerade gesucht wird.
- Ein gehaltener Treffer, der nicht mehr kaufbar ist (weg oder schon gekauft), belegt den Kaufen-Knopf nicht mehr bis zu 30 Sekunden.

## 0.65.422
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Schnellere "Lohnt bis"-Antworten (z. B. für ProfessionSentinel):** die Sicherheitsmarge beim Entzaubern hat für jeden einzelnen früheren Entzauber-Kauf die Item-Daten neu abgefragt (rund 1000-mal) – jetzt nur einmal je Item. Eine erste Abfrage dauert etwa 1–2 ms statt bis zu 40 ms, mit denselben Werten.
- Materialpreise und Entzauber-Startwerte werden je Abfrage nur noch einmal gerechnet.

## 0.65.421
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Diagnose:** die Zeile zu langsamen Preis-Abfragen zählt gleiche Teile zusammen, zeigt den belegten Speicher vor der Abfrage und ob darin eine Speicherbereinigung lief, und teilt die Materialpreise auf (Preis, Marktwert, Verlauf, Angebotsliste). Keine Änderung an Werten oder Anzeigen.

## 0.65.420
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Diagnose:** die Zeile zu langsamen Preis-Abfragen teilt jetzt auch den Entzauber-Teil auf (Fertigkeit, Item-Info, tatsächlicher und geschätzter Wert, Korrektur). Keine Änderung an Werten oder Anzeigen.

## 0.65.419
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Intern:** die neue Diagnose-Zeile aus 0.65.418 nutzt jetzt wie das übrige Addon die Zahlen-Formatierung ohne Überlauf. Keine sichtbare Änderung.

## 0.65.418
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Diagnose für Preis-Abfragen anderer Addons:** dauert eine "Lohnt bis"-Abfrage (z. B. von ProfessionSentinel) 4 ms oder länger, schreibt das Diagnose-Protokoll, wie lange jeder Teil gedauert und wie viel Speicher er gebraucht hat (höchstens 20 Zeilen je Sitzung). Keine Änderung an Werten oder Anzeigen.

## 0.65.417
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Weniger Chat, nur was dir hilft:** beim Einloggen nur noch eine Zeile mit Version ("AHSentinel 0.65.417 – /ahs oder der Münz-Button öffnet das Fenster"). Die Tagesbilanz kommt nur, wenn es etwas zu melden gibt.
- **Fehler:** im Chat nur noch eine kurze Zeile je Sitzung ("Ein Fehler ist aufgetreten – er wird automatisch gemeldet"); die Einzelheiten gehen wie bisher in die Fehlerliste.
- **Tipps nur einmal:** Hinweise wie der Raid-Start-Hinweis erscheinen ein einziges Mal und danach nie wieder.
- **Optionen in verständlichen Worten:** das Vollscan-Tempo zeigt "sehr flüssig / flüssig / ausgewogen / schneller" statt Millisekunden; "Preis-Sync" heisst jetzt "Preise teilen".
- Im Testmodus bleibt alles wie bisher sichtbar.

## 0.65.416
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Schnellere Preis-Abfragen anderer Addons (z. B. ProfessionSentinel):** die erste "Lohnt bis"-Abfrage einer Sitzung konnte 18–21 ms dauern, weil AHSentinel einen Index über die ganze Buchhaltung neu baute. Neue Buchungen werden jetzt nur angehängt, der Index wird nach dem Einloggen im Hintergrund gebaut, und der Absatz je Tag wird aus den Einträgen des Items gezählt. Gleiche Werte wie bisher.

## 0.65.415
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Auktionshaus gleich nach dem Einloggen öffnen ist flüssiger:** der vorgebaute Reiter ist jetzt etwa 2 Sekunden nach dem Laden fertig, und auch sein erstes Anzeigen (Layout) geschieht im Hintergrund – unsichtbar – statt beim Öffnen des Auktionshauses.

## 0.65.414
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Auktionshaus öffnen:** der Reiter wird jetzt 5 Sekunden nach dem Einloggen vorgebaut (vorher 20) – er ist öfter schon fertig, wenn du gleich zum Auktionshaus gehst.
- **Diagnose:** die Öffnen-Zeile zeigt auch, wo nicht zugeordnete Zeit liegt ("Lücke in: …").

## 0.65.413
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Diagnose:** das erste Öffnen des Auktionshauses je Sitzung steht immer im Protokoll (auch wenn es schnell ist), mit "vorgebaut: ja/nein".

## 0.65.412
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Auktionshaus öffnen flüssiger:** der Reiter, den du sehen wirst, wird kurz nach dem Einloggen im Hintergrund aufgebaut – das erste Öffnen des Auktionshauses muss ihn nicht mehr bauen.
- **Diagnose:** die Zeile beim Öffnen des Auktionshauses geht jetzt genau auf und zeigt, wie viel der Zeit zugeordnet ist.

## 0.65.411
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Diagnose:** die Zeile beim Öffnen des Auktionshauses misst mehr Teile und zeigt die kleinen Teile und den nicht zugeordneten Rest; langsame Hintergrund-Zeilen mit Speicherbereinigung schätzen jetzt, wie viel des Schritts die Bereinigung war.

## 0.65.410
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Diagnose:** nach dem Einloggen hält eine Zeile fest, ob die vorige Sitzung mit /reload endete. Die Zeile beim Öffnen des Auktionshauses nennt jetzt ihre langsamsten Teile (z. B. Reiter aufbauen oder füllen).

## 0.65.409
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Wächter flüssiger:** bei vielen Angeboten (z. B. 4 500) holte der Wächter bei jeder neuen Ergebnisseite die ganze Liste vom Spiel neu (je etwa 9 ms und 3,7 MB). Jetzt hängt er nur die neuen Einträge an, die das Spiel mit der Seite mitschickt – die ganze Liste wird einmal je Runde gelesen.

## 0.65.408
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Diagnose:** die Gold-Zeile beim Ausloggen sagt jetzt auch, wie die Sitzung endete (Ausloggen, Spiel beenden oder ohne Ankündigung) und das Gold beim Verlassen der Welt. Neue Diagnose-Zeile, wenn Öffnen/Schliessen des Auktionshauses in einem Bild länger als 8 ms braucht (welcher Teil, welcher Reiter, Speicherbereinigung).

## 0.65.407
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Wächter:** neue Diagnose-Zeile, wenn eine Wächter-Runde in einem Bild länger als 8 ms braucht (wie viel davon die Ergebnisliste des Spiels ist, wie viel eigene Arbeit, und ob eine Speicherbereinigung lief) – um die Ursache eines 44-ms-Bilds zu finden.

## 0.65.406
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Figuren doppelt gezählt – behoben:** WoW Forever meldet seit etwa 21.11. keinen Realm-Namen mehr. Dadurch stand jede Figur ein zweites Mal in den Daten, und "Gold (alle Figuren)" zählte ihr Gold doppelt. AHSentinel behält jetzt den bekannten Realm und führt die Doppel einmal zusammen (Goldverlauf, Einstand, Geldfluss, Buchungen, Rezepte); eine Sicherung der alten Einträge bleibt erhalten.
- Eine Figur ohne bekannten Goldstand (z. B. Bank-Figur) nimmt jetzt den letzten Goldstand aus der Buchhaltung.
- Etwas weniger Speicherabfall je Vollscan (intern).

## 0.65.405
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Tagesbilanz berichtigt:** "seit gestern" zeigt nach Aus- und Einloggen nicht mehr das ganze Gold einer Figur als Zuwachs. Das Spiel meldet beim Ausloggen 0 Gold; diese 0 wurde als Gold der Figur gespeichert. Vorhandene Daten werden richtig gelesen, nichts wird gelöscht.
- **Klarer:** die Zeile heisst jetzt "Gold (alle Figuren)", und "heute ohne Handel", wenn sich dein Gold ohne eine Buchung verändert hat.

## 0.65.404
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Flüssiger nach einem Scan:** die eingebaute Liste der Item-Namen wird mit einem kleineren Zeitanteil je Bild aufgebaut (höchstens ~6 ms statt bis ~8 ms eigene Arbeit je Bild).

## 0.65.403
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Flüssiger am Briefkasten:** die Übersicht der Entzauberungen für andere Addons (ProfessionSentinel) wird nach jeder Buchung im Hintergrund in kleinen Portionen neu aufgebaut statt am Stück; bis sie fertig ist, meldet die Schnittstelle "noch nicht bereit".

## 0.65.402
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Schnittstelle für andere Addons:** neue Abfrage `AHSentinel.API.Disenchanted(itemID[, seit])` – wie oft du ein Item entzaubert hast und was die Beute wert war (verkauftes Material mit dem echten Erlös, sonst mit dem Preis beim Entzaubern). Für ProfessionSentinel.

## 0.65.401
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Markt-Details:** "Preis · Marktwert" und "Menge" stehen in zwei Zeilen – bei grossen Beträgen wurde die Zeile abgeschnitten.
- **Testroutine:** stellt den Sniper-Modus nach dem Lauf genau so wieder her, wie er vorher gespeichert war (auch mit Wächter-Prüfziel); ein Fehler der Sicherungs-Kopie zählt jetzt in der Fehlerzahl.

## 0.65.400
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Kein Absatz mehr für Ware, die nicht mehr angeboten wird:** Ein alter gemessener Absatz zählt nicht mehr, wenn das Item seit über 2 Tagen in keinem vollständigen Scan mehr da war (vorher z. B. 1972/Tag bei 0 Angeboten).
- **Angebote zum Höchstpreis des Auktionshauses** (9 999 999g 99s 99c) ergeben keinen Trend mehr (vorher z. B. "+10526315689 %" in "Lücken").

## 0.65.399
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Kein Lua-Fehler "integer overflow" mehr:** sehr grosse Beträge (über 214 748 Gold in Kupfer, z. B. Summen oder Höchstpreise) werden überall ohne Fehler angezeigt und gespeichert. Bisher war das nur beim CSV-Export behoben. Normale Beträge erscheinen genau wie bisher.
- **Testroutine:** ein Fehler im Ablauf nennt jetzt die Stelle (Datei und Zeile); die Vollscan-Selbstkontrolle nennt, der wievielte Vollscan seit dem Laden es war.

## 0.65.398
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Weniger Speicher nach jedem Scan:** die Auswertung der Prognosen, das Lernen des Absatzes und das Teilen der Preise mit Mitspielern legen deutlich weniger neue Tabellen an. Ergebnisse, Anzeigen und Nachrichten an Mitspieler bleiben genau gleich.

## 0.65.397
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Scan braucht weniger Speicher für die Bestpreise:** die günstigsten Preise und Mengen eines Scans liegen in wenigen Listen statt in einer eigenen Tabelle je Item; beim Vollscan werden die Listen des vorletzten Scans wiederverwendet. Preise, Verlauf, Weitergabe an Mitspieler (gleiche Nachrichten wie bisher) und Empfehlungen bleiben gleich; ältere gespeicherte Daten werden weiter gelesen.
- **Testroutine:** Ansichten, die nur mit offenem Berufsfenster oder am Briefkasten geprüft werden können, gelten nicht mehr als Fehler, sondern stehen als "im Client prüfen" mit Anleitung (T750b).

## 0.65.396
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Vollscan legt beim Zusammenfassen weniger Speicher an:** die Preisstufen jedes Items entstehen als ein einziger Text (vorher ein Zwischentext je Stufe); Preise und Anzeigen bleiben gleich.

## 0.65.395
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Vollscan braucht deutlich weniger Speicher:** die Preisleitern aller Items werden kompakt gehalten (etwa ein Fünftel des bisherigen Speichers); Preise, Tooltips und Empfehlungen bleiben genau gleich.

## 0.65.394
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Reiter Wächter ruhiger:** die Liste wird einmal je Wächter-Runde neu aufgebaut (vorher etwa viermal); der Status zählt weiter jede halbe Sekunde.
- **Markt-Detail:** ein Item-Name, der auch in kleiner Schrift nicht passt, wird gekürzt – mit der Maus darüber steht der ganze Name.

## 0.65.393
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Wächter-Funde sind jetzt Tipps:** sie erscheinen nicht mehr von selbst in der Zielliste des Snipers und werden nie per Taste, Mausrad oder Knopf gekauft. Rechtsklick auf das Item im Wächter "In den Sniper übernehmen" (oder Knopf "In den Sniper") macht daraus ein normales Sniper-Ziel mit dem Höchstpreis des Wächters; gekauft wird dann wie bei jedem Ziel im Sniper. Die eigene Wächter-Taste in den Optionen entfällt.
- **Leuchten und Schlachtzugswarnung im Suchtakt:** der Bildschirmrand leuchtet und der Ton kommt jedes Mal, wenn eine Suche fertig ist und ihr Item kaufbar ist – nur für dieses Item (bei mehreren Zielen nie für ein anderes), bei jeder weiteren Suche wieder, solange es kaufbar bleibt. Aus bei Kauf, Treffer weg, AH zu und Kampf. Kein fester Abstand mehr.
- **Wächter leuchtet auch:** jede Prüfung, die einen Tipp kaufbar findet, lässt den Rand in einer eigenen Farbe leuchten (Standard Grün, Optionen > Schnäppchen-Alarm). Ton nur bei gesicherten Tipps wie bisher.
- **Kopfzeile:** "Sniper: an/aus" zeigt dasselbe wie der Knopf "Sniper-Modus" im Reiter (vorher "an", sobald der Wächter etwas prüfte).
- **Testroutine:** der Wächter-Schritt wartet, bis ein laufender Vollscan fertig ist, und zählt seine 3 Minuten erst danach; ohne Runde nennt er den Grund.
- **Auktionshaus:** die Abdeckung unserer Ansicht liegt jetzt über allen Rahmen des Auktionshauses, damit dessen Liste nicht blass durchscheint.

## 0.65.392
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Kaufen > Einkauf:** die Seitenleiste über den Ergebnissen liegt nicht mehr unter "X" und "Favoriten"; bei wenig Platz kurze Form "< 3 / 22 >".
- **Markt-Reiter:** die zweite Kopfzeile zeigt nur, was passt; der Rest steht oben im Tooltip. Zeilen "Preis gefallen" zeigen Item und Erlös in zwei Zeilen (ganzer Satz im Tooltip). Die Spalte "Stand" zeigt "Zutaten fehlen: n" (Kosten je Herstellung im Tooltip). Der Detailbereich zeigt "Gelernt" in zwei Zeilen.
- **Wächter:** "lernt noch" steht immer mit der Zahl der Fälle.
- **Tooltips** der Markt-Kopfzeile, der Zeile "Treffer je Weg", der Zeiten im Detailbereich, des Sync-Stands und zweier Verkaufs-Hinweise öffnen neben dem Fenster und verdecken keine Knöpfe mehr.
- **Testroutine:** der Wächter-Schritt dauert 3 statt 10 Minuten; beim Start sagt ein Tipp, dass ein eigener Vollscan kurz vorher einen Scan und 15 Minuten spart.

## 0.65.391
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Vollscan:** während ein Scan verdichtet wird, ändern sich die sichtbaren Preisleitern nicht mehr stückweise, sondern am Ende alle auf einmal (0.65.390 verwendete die sichtbaren Leitern des letzten Scans wieder). Items ohne Auktion im Scan lassen ihre gemerkte Leiter unberührt.

## 0.65.390
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Vollscan braucht weniger Speicher:** die Preisleitern des letzten Scans werden ab dem zweiten Scan nach dem Einloggen wiederverwendet (vorher erst ab dem dritten, und ein unvollständiger Scan löschte den Vorrat). Ein unvollständiger Scan wird jetzt vor dem Verdichten erkannt und ändert wie bisher nichts.
- **Vollscan-Messung (nur Testroutine):** die Messung des Speichers je Addon gehört jetzt zum längsten Bild; der Bericht zeigt, wie viele Preisleitern wiederverwendet wurden.

## 0.65.389
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Testroutine, Sniper-Ruckeln (S13):** Antworten auf Item-Daten wurden als Millisekunden eigener Arbeit gezählt ("105 ms" waren 105 Antworten); eigene Arbeit ist jetzt Aufgaben + Ereignisse + Skripte, die Antworten stehen als Anzahl dabei. Der Bericht nennt die Stelle (Datei:Zeile) des langsamsten eigenen Skripts je Bild und welche Stellen Bilder über 33 ms machen.
- **Testroutine, Sandbox:** Diagnose-Einträge aus dem Abschluss der Routine landen nicht mehr im echten Protokoll.
- **Testroutine, Sniper-Prüfungen:** ein echter Treffer oder ein Wächter-Ziel des Spielers beeinflusst die Prüfungen von Knopf und Mausrad nicht mehr.
- **Vollscan-Messung (nur Testroutine):** die Kosten der Messung stehen je Bild (höchstens) und als Summe da.

## 0.65.388
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Vollscan-Messung (nur Testroutine):** der Bericht zum längsten Bild nennt jetzt alle Gesamtwerte des Speichers (Scan-Beginn, im Bild, vor und nach der Messung je Addon) und ob während dieser Messung eine Speicherbereinigung lief. Die Werte je Addon heissen jetzt "belegter Speicher" (nicht angelegter).
- **Bilder pro Sekunde:** der Bericht sagt, dass es Mittelwerte des Spiels sind, und zeigt daneben das längste Bild je Schritt.
- **Neue Messung im längsten Bild beim Einlesen (nur Testroutine):** welche Spiel-Ereignisse in diesem Bild kamen (nur Namen und Anzahl), ob das Auktionshaus-Fenster offen war und welche Auktion gerade gelesen wurde; die Kosten der Messung stehen dabei.
- **Versionshinweise auf GitHub:** zuerst Deutsch, Englisch zusätzlich.
- **Gemeinsame Testdatei GoldSentinelTest Version 3:** eine Prüfung ohne Ergebnis zählt in allen GoldSentinel-Addons als FEHLER; die eigene Prüfung akzeptiert Version 3.

## 0.65.387
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Markt-Reiter, Detail:** ohne frische Preisprüfung kein "einstellen für x" mehr und nie der Marktwert als Ersatz – dort steht wie im Verkaufen-Reiter "Preis nicht geprüft – erneut prüfen".
- **Hinweis "teurer neu einstellen":** der neue Preis ist genau der Vorschlag des Verkaufen-Reiters (vorher konnte deine Unterbieten-Einstellung ihn um einige Kupfer senken).
- **Testroutine:** eine Prüfung ohne Ergebnis zählte als bestanden – jetzt als FEHLER. Alle Prüfungen folgen den geltenden Regeln (Tooltip, Verkaufspreis, ein Markt je Fraktion, Mengen aus Feld 11, Tageszeit-Trend); Prüfungen lesen keine gelernten Werte, Einstellgrössen oder deine Standard-Laufzeit mehr.

## 0.65.386
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Testroutine fasst deine Daten nie an:** Schnäppchen-Liste des Snipers, Zähler des Gilden-Syncs und die Konto-Kennung werden während der Testroutine nicht mehr geschrieben; das Aufräumen danach wiederholt sich, bis alles stimmt, und sagt das genau.
- **Befehl repariert:** "/ahs shortage" (Buchhaltung: Chat-Hinweis bei Fehlbestand) – "missing" gehört wieder der Einkaufsliste fürs Rezept.
- **Testroutine:** mehrere Prüfungen an die geltenden Regeln angepasst (Itemstufe, Mengen aus Feld 11, Gilden-Format, Sync-Itembereich, gemessene Mindest-Einzahlung).

## 0.65.385
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Messreihe Ausrüstung:** Kommt die Gebühren-Rückfrage, stellt der zweite Klick jetzt denselben Schritt ein, statt zum nächsten zu springen.
- **Im Hintergrund:** Das Nachtragen der Übersicht vereinter Märkte läuft im Hintergrund und schreibt seine Dauer ins Protokoll.
- **Testbericht:** zeigt die Grösse der gemerkten Stapelgrössen (Login / nach Vollscan).

## 0.65.384
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Post zusammengefasst:** Gleiche Items stehen jetzt in EINER Chatzeile (z. B. "Zurück (abgelaufen): 60× Seelenstaub"), mit exakten Summen; die Summe am Ende.
- **Gebühren-Rückfrage überall:** Bei hoher Einstellgebühr fragt der erste Klick, der zweite stellt ein – jetzt in jedem Verkaufsweg (Verkaufen-Fenster, Serie, Neu einstellen, "Heute tun", Messreihe). Gleiche Schwelle, gleicher Text.
- **Gewinn erwartet geht auf:** Die Zeile nennt ihre Abzüge (Einstand, erwartet verlorene Einstellgebühr) – die Zahlen gehen genau auf.
- **Buchhaltung:** Verbrauchsgüter, deren Iteminfo noch nicht geladen ist, werden nicht mehr als "fehlt" gebucht.
- **Kleinigkeiten:** "meist nach x Std." zeigt die Fallzahl statt "~"; der Gilden-Sync zählt Abweichungen je Ursache und Tag; Post-Mengen werden mit dem Item geprüft.

## 0.65.383
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper sicherer:** Ist die Stapelgrösse eines Items noch unbekannt (kurz nach dem Einloggen), wird bei zusammengefassten Angeboten nicht mehr geraten – der Sniper kauft nicht ("Stapel unbekannt") und Verkaufen macht keinen Vorschlag, bis die Iteminfo geladen ist. Stapelgrösse 1 wird jetzt auch gemerkt.
- **Märkte vereinen repariert:** Ein Lua-Fehler brach das Vereinen alter Märkte nach je einem Markt ab; jetzt alle in einem Lauf, die Übersicht wird nachgetragen.
- **Gilden-Daten:** Verkaufsfälle, Eichung und Rechnungen von Versionen vor der Mengen-Korrektur werden verworfen (kein Mischen falscher Mengen). Die Eichung zählt nur Fälle ab jetzt.
- **Buchhaltung:** Der Gewinn-Tooltip zeigt höchstens 5 Zeilen (Erlös, Eingesetzt, Gebühren, Entzauber-Ausbeute, Gewinn).
- **Testbericht:** Die Zahlen einmaliger Bereinigungen bleiben dauerhaft gespeichert und stehen im Testbericht.

## 0.65.382
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Preisfeld = Vorschlag:** Das Preisfeld zeigt jetzt immer den Vorschlag, der darunter erklärt wird – bis du selbst einen Preis tippst oder eine Zeile wählst. Vorher konnte das Feld den Vorschlag einer älteren Preisprüfung behalten (z. B. 6s91, obwohl der Vorschlag 3s99 lautete). Hast du selbst einen Preis gesetzt, steht "dein Preis x, Vorschlag y" da.
- **Preisprüfung findet mehr Angebote:** Gesucht wird nicht mehr mit einem Item-Schlüssel ohne Itemstufe (der fand immer 0 Angebote); findet die Prüfung trotzdem nichts, obwohl der Scan das Item kennt, holt AHSentinel die echten Varianten über den Namen. Items mit Zufalls-Zusatz: Ist deine Variante nicht im AH, steht das da – mit der Zahl der anderen Varianten.
- **Kein endloses "wird aktualisiert …":** Nach 20 s ohne Antwort sagt der Verkaufen-Reiter das, mit Grund.
- **Spalte "Günstigstes":** Ohne frische Preisprüfung steht grau der günstigste Preis aus dem letzten Scan statt "-".

## 0.65.381
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufen-Liste – zuerst messen:** Wie lange der Aufbau der Liste links im Reiter Verkaufen dauert, wird jetzt Schritt für Schritt gemessen und ins Protokoll geschrieben ("VERKAUFEN-LISTE", einmal je Minute). Sonst ändert sich nichts – schneller wird es, sobald die Messung zeigt, wo die Zeit hingeht.

## 0.65.380
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **CSV-Export repariert:** Ein Angebot zum Höchstpreis im AH (9'999'999g 99s 99c) führte zu "integer overflow attempting to store 99999999999". Grosse Zahlen stehen jetzt als Text in der Datei, unbegrenzte Werte als leeres Feld.

## 0.65.379
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung geht auf:** Der Gewinn-Tooltip zeigt jetzt jeden Teil des Gewinns – Erlös, Eingesetzt, Gebühren und die Entzauber-Ausbeute (Glück/Pech beim Entzaubern). Die Zeilen ergeben genau den Gewinn.
- **Rendite mit Zahl:** Rendite = Gewinn aus Posten mit Einkauf ÷ Eingesetzt. Posten ohne Einkauf stehen getrennt ("Herkunft unbekannt"); "–" nur, wenn nichts eingesetzt wurde.

## 0.65.378
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Alte geteilte Preise bereinigt:** Preise aus Preisprüfung/Sniper/Einkauf von vor 0.65.376, die deutlich unter dem Scan derselben Zeit liegen (geteilt durch die Anzahl Angebote), zählen nicht mehr im Marktwert.
- **„Angebote“ statt „Stück“:** bei nicht stapelbaren Items zeigt die Liste „19 Angebote“, und der Vorschlag sagt „(19 Angebote)“.
- **Kein Vorschlag:** steht kein Preis im Feld, zeigt AHSentinel trotzdem „Händler zahlt … – mehr als hier“, wenn der Händler mehr bringt; der Grund kommt ins Protokoll.
- **Stapelgrösse prüfen:** „/ahs stapel <Item-Link>“ zeigt, ob ein Item stapelbar ist – damit lässt sich jeder Stückpreis nachprüfen (z. B. 30 Rezepte zu je 5s70 = 5s70 je Stück).
- **Sniper-Takt:** die Auswertung im Protokoll nennt jetzt Zeitraum und wie viele Suchen mit minimiertem Spiel liefen.

## 0.65.377
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Keine Meldung mehr nach jedem Kampf:** verschossene Munition, Essen, Trinken, Tränke, Verbände und Reagenzien bucht die Buchhaltung still als „verbraucht“. Für echten Fehlbestand kommt höchstens EINE Chatzeile je Sitzung; ganz aus mit „/ahs fehlbestand“.
- **Beim Öffnen eines Berufs öffnet sich nichts mehr von selbst:** am Berufsfenster steht ein kleiner Knopf „AHS“, das Gewinn-Fenster kommt erst auf Klick. Wer es wie früher will: „/ahs gewinnfenster auto“.

## 0.65.376
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Stückpreis bei zusammengefassten Angeboten richtig:** der Server fasst gleiche Einzel-Angebote nicht stapelbarer Items in eine Zeile („9 Stück“). AHSentinel teilte deren Preis durch 9 – z. B. „1s16“ statt 10s44 je Seite, daraus „jetzt günstig – kaufen (−98 %)“. Jetzt gilt bei nicht stapelbaren Items der Preis je Angebot; ein Kauf kauft 1 Stück. Falsch gespeicherte Preise und Kauf-Mengen werden beim ersten Treffer je Item bereinigt.
- **Mengen aus der Post richtig:** „Gekauft: 36× …“ las die Lieferzeit (Minuten) statt der Menge. Jetzt die echte Menge; falsche gespeicherte Mengen werden einmalig bereinigt.
- **Eine Rundung für den Stückpreis:** Kopf und Tabelle zeigen denselben Wert, unter 1 Silber mit Bruchteil („6,9c“).
- **Woher der Vorschlag kommt:** eine Zeile unter dem Preis, z. B. „Vorschlag 53c = günstigstes fremdes Angebot 54c (33 Stück) − 1c“.
- **Händler zahlt mehr:** immer roter Hinweis „Händler zahlt 62c – mehr als hier (53c)“, auch bei kleinen Beträgen. Einstellen bleibt möglich.

## 0.65.375
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper sucht alle Ziele:** hat ein Ziel ständig Treffer, kam ein anderes ohne Treffer im Ruhemodus nur alle 30 Sekunden dran. Jetzt wird jedes Ziel spätestens nach 4 Suchen der anderen Ziele gesucht.
- **„Nichts bis zu deinem Max-Preis“ trotz kaufbarem Angebot behoben:** die Kopfzeile zeigt wieder „Nächster Kauf: …“. Gibt es passende Angebote, die gerade nicht kaufbar sind, steht der Grund da (z. B. „über Budget“).

## 0.65.374
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Rechnung immer lesbar:** der Kasten mit der Rechnung liegt nicht mehr unter dem Vergleichs-Tooltip („Ausgerüstet“) – er steht rechts daneben, wenn dort kein Platz ist links, sonst unter dem Tooltip.
- **Materialtabelle zeigt die gemessene Menge:** „74 % × 1,50“ = in 74 % der Entzauberungen kam das Material, dann im Schnitt 1,50 Stück. Genau damit rechnet der Gewinn.

## 0.65.373
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Takt wird gemessen:** für jede Suche hält AHSentinel fest, wie lange es seit der letzten Suche gedauert hat und wer gewartet hat (Server, eigene Wartezeiten, Intervall, Antwort des Servers …). /ahs protokoll zeigt die Auswertung. Am Takt selbst ändert sich nichts.

## 0.65.372
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gleiche Scan-Zeit im Tooltip:** „Scan alt – vor x Min.“ und „Marktwert (Scan vor x Min.)“ zeigen jetzt dieselbe Zeit (vorher 34 und 32 Min. für denselben Scan).

## 0.65.371
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Marktdaten aus Gilde, Gruppe und Netz – abgesichert:** jeder Spieler zählt je Item und Stunde nur einmal. Ein fremder Preis, der mehr als doppelt bzw. halb so hoch ist wie dein eigener Scan der letzten 24 Std., wird verworfen; ohne eigenen Scan zählt er erst, wenn ein zweiter Spieler Ähnliches meldet. Dein eigener Scan in derselben Stunde geht immer vor.
- **Dein Verkaufsvorschlag** kommt weiter nur aus deinem eigenen frischen Angebots-Scan, nie aus fremden Daten.
- **Statuszeile:** „Empfangen: x Daten von y Spielern“ – mit der Maus darüber je Weg (Gilde / Gruppe / Netz), angenommen und verworfen, seit Login und 7 Tage. Keine Namen.
- **Abweichungen werden geklärt:** jeder verworfene Preis steht im Protokoll mit eingeordneter Ursache (Teil-Scan, Stapelpreis, Variante, Markt bewegt …); /ahs protokoll zeigt die Auswertung.

## 0.65.370
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verzauberer, eigenes Item ohne Angebot:** der Tooltip zeigt jetzt „Entzaubern statt verkaufen +x“ (grün) bzw. „−x“ (rot) – Entzauberwert gegen den besten Verkaufsweg (AH nach Gebühr oder Händler) – und darunter den Entzauberwert. Vorher stand dort kein Wert.
- **Gewinn und Verlust an derselben Stelle:** direkt unter „AHSentinel“, gleiche Schrift, plus grün, minus rot. Die Farbe ging beim grösseren Schriftsatz verloren – behoben.
- **Alter ohne Uhrzeit:** „Scan alt – vor 3 Std.“, wenn der letzte Scan alt ist; „Zurzeit nicht im Angebot – letzter Preis vor 20 Std.“, wenn der Scan aktuell ist, das Item darin aber fehlte.
- **„Verkauft sich“ ohne „~“:** eine Dauer steht nur mit ihrer Grundlage (z. B. „schnell (2 Std., gemessen 4 Tage)“), sonst nur „schnell“.
- **Post abholen:** gleiche Briefe (z. B. mehrere „Auktion abgelaufen: Seelenstaub“ aus derselben Minute) bekommen jetzt je eine eigene Zeile und zählen in der Summe.
- **Beruf:** ist die Verzauberkunst nach 10 Sekunden noch nicht lesbar (z. B. eingeklappte Berufe), zeigt der Tooltip nicht mehr still die Verzauberer-Ansicht.

## 0.65.369
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Absatz aus echten Verkäufen:** wie viel von den vorzeitig verschwundenen Angeboten wirklich verkauft ist, rechnet AHSentinel je Item-Gruppe (z. B. Kräuter, Stoff, Ausrüstung) aus den Post-Briefen – deinen und denen der Gilde –, sobald es dort mindestens 30 echte Fälle (verkauft oder abgebrochen) gibt. Bis dahin bleibt es wie bisher. Es gibt immer nur einen Wert.
- **Hinweis „Gildenmitglied bietet hier zu x“ entfernt** (aus 0.65.368). Gespeicherte Reste werden beim Laden gelöscht. Dein Vorschlag im Verkaufen-Fenster ist unverändert.

## 0.65.368
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gildenmitglied bietet hier zu x:** jedes Gildenmitglied teilt seine eigenen laufenden Auktionen (je Item günstigster Stückpreis und Stückzahl, ohne Namen). Das Verkaufen-Fenster zeigt dann „Gildenmitglied bietet hier zu x (n Stück, Stand vor y Min.)“. Nur ein Hinweis – dein Preis und der Vorschlag ändern sich dadurch nicht.
- **Schnäppchen-Zeiten der ganzen Gilde:** die Sniper-Treffer aller Gildenmitglieder (Zeit, Item, Dauer, ohne Namen) zählen in „Schnäppchen … meist um x Uhr“ mit („davon Gilde n“).
- **Gebührenregel mit Belegen:** AHSentinel sammelt die Zahlen deiner Verkaufs-Rechnungen (Gesamt, Gebühr, Einzahlung, Menge) und die der Gilde. „/ahs gebuehren“ zeigt, wie viele davon exakt „5 Prozent abgerundet“ sind.
- **Händlerpreise aus der Gilde:** kennt dein Client ein Item noch nicht, nimmt AHSentinel den Händlerpreis, den ein Gildenmitglied im Spiel gelesen hat. Dein eigener Spielwert geht immer vor.
- **Alle Gildenmitglieder bitte auf 0.65.368 aktualisieren**, damit diese Daten geteilt werden.

## 0.65.367
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Marktwert ohne Doppelzählung:** je Stunde zählt jetzt EIN Preis (der Median dieser Stunde). Scannen zwei Gildenmitglieder zur selben Zeit, hat das nicht mehr doppeltes Gewicht; ein Ausreisser aus einem einzelnen Scan zählt nur als eine Stunde gegen die Mehrheit. Unter 3 Stunden mit Preisen in 14 Tagen bleibt der Marktwert unbekannt.
- **Beste Tageszeit ohne Trend:** auf einem jungen Server fallen die Preise von Tag zu Tag. Die Stunden werden jetzt auf das heutige Preisniveau umgerechnet, bevor sie verglichen werden – „besser um x Uhr“ kommt nicht mehr nur daher, dass ein älterer Tag teurer war.
- **Zeiten im Markt-Reiter (nur Information):** Maus über die Details eines Items zeigt: günstigste und teuerste Tageszeit (mit Anzahl Werte), ob es zur jetzigen Stunde in deinen Vollscans der letzten 7 Tage ein Angebot gab („kein Angebot“ erst ab 3 Vollscans zu dieser Stunde), und wann Schnäppchen auftauchen und wie lange sie bleiben (ab 5 Fällen). Zu wenig Daten heisst „zu wenig Daten“ – nichts wird geschätzt.

## 0.65.366
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufschance der ganzen Gilde:** Gildenmitglieder teilen, wie oft Items bei welchem Preisabstand verkauft wurden (verdichtet, ohne Namen). Das Verkaufen-Fenster zählt diese Fälle mit („… (davon Gilde n)“); die Dauer bis zum Verkauf steht nur aus deinen eigenen Fällen.
- **Entzauber-Ergebnisse je Konto:** geteilte Entzauber-Zahlen werden jetzt je Konto statt je Charakter geführt – ein Gildenmitglied mit mehreren Charakteren zählt nicht mehr doppelt.

## 0.65.365
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Echte Verkaufschance (aus deiner Post):** AHSentinel merkt sich, mit welchem Abstand zum günstigsten Angebot du eingestellt hast, und die Post sagt sicher, ob verkauft, abgelaufen oder abgebrochen. Ab 5 Fällen im selben Preisabstand zeigt das Verkaufen-Fenster z. B. „Bisher bei 1–5 Prozent darüber: 4 von 6 verkauft, meist nach ~3 Std.“.
- **Woher die Marktdaten stammen:** jeder Vollscan wird mit Zeit und Quelle (eigen oder Gilde, ohne Namen) vermerkt. Der Markt-Reiter zeigt die Abdeckung: „Abdeckung 7 Tage: x von 24 Std. (eigene a, Gilde b)“.

## 0.65.364
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Ein Markt je Fraktion:** WoW Forever meldet für Spieler am selben Auktionshaus verschiedene Realm-Namen. AHSentinel führt jetzt EINEN Markt für die Horde, einen für die Allianz und einen für das neutrale Auktionshaus – egal welcher Realm-Name.
- **Alte Daten einmal zusammengeführt:** deine bisherigen Märkte derselben Fraktion werden im Hintergrund in den gemeinsamen übernommen (gleiche Beobachtung nur einmal). Die alten Daten bleiben als Sicherung; „/ahs markt“ zeigt die Zahlen, „/ahs markt sicherung löschen“ entfernt die Sicherung.
- **Marktabgleich der Gilde zwischen allen Mitgliedern:** **Alle Gildenmitglieder bitte auf 0.65.364 aktualisieren**, sonst kein Marktabgleich (ältere Versionen werden ignoriert, nichts wird gemischt).

## 0.65.363
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Post-Scan:** jeder Brief wird vor dem Leeren gelesen – je Brief eine Chatzeile mit exakten Zahlen („Verkauft: 1× … für 36s99 – erhalten 35s14 (Gebühr 1s85)“, „Zurück (abgelaufen): 4× …“, „Gekauft: …“, „Post von …: 5g“, „Nachnahme liegen gelassen: …“), am Ende die Summe. Gold von Spielern oder Händlern zählt als erklärter Geldfluss, nicht als Handel.
- **Entzauberwert für Nicht-Verzauberer:** Charaktere ohne Verzauberkunst sehen statt der Materialtabelle eine Zeile „Entzauberwert x“ (nach Gebühr und Einzahlungsrisiko; „Händler bringt mehr (y)“, wenn höher) – auch bei seelengebundenen Items. Verzauberer sehen den Tooltip wie bisher. Weisse und graue Items haben keinen Entzauberwert.
- **„Scan alt“ nur noch einmal** im Tooltip.
- **Rechnungszeilen:** der gezeigte Faktor ist genau der, der den Zeilenwert ergibt (Werte unverändert).

## 0.65.362
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **„Post abholen“ holt alles:** beim Öffnen des Briefkastens (und mit dem einen Knopf „Post abholen“) kommt jetzt alle Post mit Gold oder Gegenständen – Auktionen, Händler, Spieler, Rücksendungen, abgelaufene Auktionen. Nachnahme wird nie bezahlt, reine Textbriefe bleiben liegen. Volle Taschen -> Halt mit Meldung. Shift beim Öffnen = kein automatisches Abholen. Gold von Spielern oder Händlern wird nie als Auktionsverkauf gebucht.

## 0.65.361
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Kein Preis ohne Preisprüfung:** findet die Preisprüfung keine Angebote (oder lief keine), füllt das Verkaufen-Fenster nicht mehr den Marktwert ein – es steht „Preis nicht geprüft – erneut prüfen“. Für Items in deinen Taschen sucht die Prüfung jetzt genau deine Variante.
- **Schlachtzugswarnung vor dem Einstellen:** „Stopp – tiefer als alle anderen Angebote!“ kommt, sobald dein eigener Preis steht (Feld verlassen, Enter, Zeile angeklickt) – einmal je Item und Preis, mit Item und Preis im Protokoll.
- **Markt > Entzaubern: ein Wert je Item:** rechts stehen derselbe Wert und dieselbe Grenze wie in der Zeile links. Items mit unbekannter Itemstufe bekommen keinen Wert und keinen Kaufhinweis, bis die Stufe bekannt ist.
- **Tooltip-Rechnung exakt:** Faktoren ungerundet (z. B. „1,125 ×“), jede Zeile rechnet sich aus dem, was dasteht.

## 0.65.360
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Neuer Item-Tooltip:** oben der Gewinn beim Entzaubern (grün, etwas grösser), darunter „Marktwert (Median 14 Tage)“ und „Marktwert (Scan hh:mm)“ – letzterer ersetzt die Zeile „Verkaufen“.
- **Rechnung neben dem Tooltip:** ein kleiner Kasten rechts zeigt jeden Schritt (Materialien × Scanpreis, 5 % Gebühr, Einzahlungsrisiko, Kaufpreis) – die Zeilen ergeben exakt den Gewinn. Kein Abzug fürs Unterbieten.
- **Unsichere Werte werden benannt:** weniger als 3 Preise in 14 Tagen -> „Marktwert nicht bekannt“ (er rechnet dann nirgends mehr mit); Scan älter als 30 Minuten -> „Scan alt – Preis vom hh:mm“ und kein Gewinn.
- **Materialtabelle bündig:** Spalten „Vorgabe“, „Ø“ und „Preis“ stehen untereinander; „…-Preis seit dem letzten Scan gestiegen“ wird an den Scans gemessen, nicht an der Uhr.
- **Kein Preisverlauf mehr im Tooltip** (in den Fenstern bleibt er).

## 0.65.359
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufspreis exakt auf den Kupfer:** Vorschlag und Einstellen runden Einzelstücke nicht mehr auf ganze Silber (z. B. 14s58 statt 14s, 7c statt 1s). Der Händlerpreis steht nur als Hinweis da.
- **Schlachtzugswarnung nur bei deinem eigenen tieferen Preis:** nicht mehr beim Vorschlag und nicht beim Tippen – nur wenn du einen selbst gesetzten Preis unter allen anderen Angeboten einstellst.
- **Keine widersprüchlichen Hinweise:** „abgelaufen – billiger einstellen“ nennt denselben Vorschlag wie das Preisfeld; Zeitpunkt-Hinweise („Jetzt teuer“, „Jetzt günstig“, „besser um …“) entfallen, wenn sie dem Marktwert widersprechen.
- **Entzaubern nur mit Verzauberkunst:** Verkaufs-Hinweise („Entzaubern: +2s 71c mehr“), Kauf zum Entzaubern und das Entzaubern-Fenster gibt es nur, wenn einer deiner Charaktere Verzauberkunst hat; hat nur ein Twink sie: „Entzaubern über deinen Twink“. In WoW Forever entzaubert jede Verzauberkunst-Stufe alles. Die Tooltip-Angaben bleiben für alle.

## 0.65.358
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Neuer Verkaufspreis-Vorschlag (eine einfache Regel):** günstigstes Angebot anderer Spieler minus 1c. Liegen zum günstigsten Preis nur 1–5 Stück, wird diese Preisstufe übersprungen und die nächste genommen. Unter 20c gilt der gleiche Preis statt 1c darunter.
- **Keine Bestätigungen mehr beim Verkaufen:** das Verkaufen-Fenster sperrt nie und verlangt keinen zweiten Klick. Warnungen bleiben als Hinweis. Gibst du selbst einen Preis tiefer als alle anderen Angebote ein, kommt einmal eine Schlachtzugswarnung: „Stopp – tiefer als alle anderen Angebote!“ – einstellen kannst du trotzdem.

## 0.65.357
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper zeigt Angebote von Items mit Varianten auch über Max:** bei der Suche per Name zählt jede Variante des Items (über Max als „zu teuer“, gekauft wird nur bis Max). Ist der Server direkt nach einer leeren Suche noch nicht bereit, wartet der Sniper bis 3 s statt mit „0 Angebote“ aufzugeben. Das Diagnose-Protokoll (SNIPER-NAME) zeigt Anfrage und Antwort des Servers.
- **„Angebot schon verkauft“ (Code 4) ist kein Fehlkauf mehr:** zählt nicht zur 10-Minuten-Pause des Items; die Liste gilt als veraltet und der Sniper sucht sofort neu. Der Kauf-Knopf verschwindet, solange das Item pausiert oder die Liste veraltet ist.
- **Zähler stimmen überein:** „in dieser Suche gekauft“ im Fenster zählt jetzt dieselben Käufe wie der Chat (Käufe, deren Zeile in der nächsten Liste fehlte, fehlten). Meldungen bei pausiertem Item nennen die Pause statt „sucht weiter“. „Ziel aktualisiert“ sagt jetzt, dass die Zähler neu beginnen (und wie viel vorher gekauft war).

## 0.65.356
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Budget nicht mehr durch ein früheres Ziel „aufgebraucht“:** ein neues Ziel für dasselbe Item behielt die Gold-Sicherung des früheren Ziels; dessen Käufe zählten gegen das neue Budget („Budget aufgebraucht (0 Stück gekauft)“, Angebote unter Max als „über Budget“). Ein neues Ziel beginnt jetzt mit eigener Sicherung.
- **Sniper sucht gleich nach „Ziel setzen“:** bei eingeschaltetem Sniper-Modus wird ein neu gesetztes Ziel im nächsten Takt gesucht (sobald der Server es erlaubt). Suchen in AHSentinel (z. B. Einkauf) pausieren den Sniper nicht mehr als „du suchst gerade“; nur Suchen im Blizzard-Auktionsfenster oder in anderen Addons (30 s). Die letzten Treffer bleiben nach einer Ziel-Änderung sichtbar (gekauft wird erst aus der neuen Suche).
- **Sniper findet Items mit Varianten:** bleibt die Suche nach einem Item leer (z. B. grüne Items „… des Affen“ mit eigenem Item-Schlüssel), sucht der Sniper per Name und nimmt nur Angebote desselben Items.
- **Tooltip seelengebundener Items:** keine Auktionspreis-, Verkaufen-, Gewinn- oder Zeitpunkt-Zeilen mehr – nur ein Hinweis, Händlerpreis und Entzauberungswert.

## 0.65.355
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Die Testroutine ändert das gemeinsame GoldSentinel-Adressbuch nie:** Meldungen "Spieler nicht online" während der Testroutine werden jetzt mit dem Zeitpunkt des Flüsterns gemessen. Ein Flüstern von vor dem Start ist echter Verkehr (zählt wie immer), eines aus dem Test wird zurückgesetzt. Die Adressbuch-Prüfung zeigt die Netz-Zahlen des Laufs.

## 0.65.354
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Kaufgrenze beim Entzaubern ("Lohnt bis") korrigiert:** Die Grenze je Preisstufe (wie viel vom Wert du zahlen darfst) wurde 5 Minuten lang gemerkt, egal aus welchen Daten sie stammte. Ein Wert aus den leeren Ersatz-Daten der Testroutine (0,90) konnte danach für deine echten Daten (0,80) gelten – "Lohnt bis" beim Entzaubern war für Gruppen mit 20 % Mindestgewinn bis 4 % zu hoch. Der gemerkte Wert gilt jetzt nur noch für die Daten, aus denen er stammt.
- **Verkaufen-Reiter: keine viel zu billigen Vorschläge mehr:** Bei einem einzigen fremden Angebot (z. B. 3s 40c) und einem alten tiefen Marktwert (z. B. 15c) fiel der Vorschlag ohne Warnung auf den Marktwert. Der Marktwert gilt jetzt nur bis zur Hälfte des günstigsten fremden Angebots, und ein Preis unter dieser Hälfte warnt immer – auch bei nur ein oder zwei Angeboten. Ohne jede Preisinfo (keine Preisprüfung, kein Marktwert) warnt AHSentinel jetzt deutlich vor dem Einstellen.

## 0.65.353
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Testroutine (Sniper, Vollscan):** Aufrufe von AHSentinel, in denen die Lua-Speicherbereinigung lief, werden getrennt gezählt (ihr eigener Anteil ist nicht trennbar) statt als eigene Arbeit; das langsamste eigene Skript wird genannt. Der Sniper selbst ist unverändert.

## 0.65.352
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Testroutine auch im Hintergrund:** Ruckeln wird jetzt an der eigenen Rechenzeit von AHSentinel je Bild gemessen (nicht an der Bildlänge, die bei 30 Bildern/s immer etwa 33 ms ist); die Prüfung "reihum" zählt Warten auf den Server nicht mehr als eigene Lücke und zeigt beides. Der Sniper selbst ist unverändert.

## 0.65.351
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Testroutine:** Eine gedrosselte Bildrate (WoW im Hintergrund oder Bildraten-Grenze 33 oder weniger) wird jetzt bis 10 % über der Grenze erkannt; Ruckeln und Tempo gelten dann als "nicht bewertbar" statt als Fehler. Der Sniper selbst ist unverändert.

## 0.65.350
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Weniger Speicher beim Vollscan in der Testroutine:** Die Prüfung "ist das eine Ware?" nutzt in der Testroutine für echte Items jetzt auch ihren Zwischenspeicher (vorher fragte sie das Spiel zweimal je Item) – die Testroutine misst den Scan damit so, wie er beim Spieler läuft.

## 0.65.349
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufspreise in "Heute tun":** Eine Angebotsliste aus einem älteren Vollscan gilt nicht mehr unverändert, wenn ein neuerer Scan einen anderen Preis hat (ein Verkaufsvorschlag von 1s 25c wurde mit einem 58c-Angebot vom Vortag verglichen). Billigere Stufen, die weg sind, fallen weg; ein neuerer, niedrigerer Preis steht vorne.
- **Ruhigerer Wächter:** Während einer Runde liest der Wächter die Ergebnisliste nur noch, wenn das Spiel neue Ergebnisse meldet (oder einmal je Sekunde), statt zehnmal je Sekunde.
- **Testroutine:** Der Bericht nennt den Testort (Gebiet, Namensplaketten in Sicht, Ping); beim längsten Bild steht die eigene Arbeit von AHSentinel daneben; eine eigene Zeile zeigt das längste Bild im Vollscan mit eigener Arbeit, Rest und Speicher je Addon.

## 0.65.348
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Wächter wartet nicht mehr minutenlang:** Nach einem Markt-Scan werden bis zu 60 auffällig billige Angebote nachgeprüft; der Wächter kommt jetzt spätestens nach 45 Sekunden an die Reihe, statt auf die ganze Liste zu warten.
- **Eigene Auktionen zuerst:** Diese Nachprüfungen laufen jetzt in der Hintergrund-Liste – "Unterbietung prüfen" und angeklickte Items stehen nicht mehr dahinter.
- **Ein "Lohnt bis" überall:** Ein Zwischenspeicher der Entzauber-Prüfung galt auch für Tooltip und Markt, solange die Prüfung pausierte – dadurch konnten für ein Item zwei Werte erscheinen. Er gilt jetzt nur noch für die Prüfung selbst.
- **Weniger Speicher im Vollscan:** "Heute tun" und die Prognose warten, bis der Vollscan fertig ist (höchstens 5 Minuten).
- **Testroutine:** zeigt bei einer aufgehaltenen Suche die Länge der Preisprüfungs-Listen; die Adressbuch-Prüfung nennt die geänderten Felder; der Vollscan-Speicher zeigt zuerst den Anteil je Aufgabe.

## 0.65.347
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **GoldSentinel-Kommunikation (Version 3):** Während der Testroutine eines GoldSentinel-Addons werden aus Testnachrichten keine Adressen gelernt und keine echten Flüsternachrichten verschickt; die Meldung "Spieler nicht online" wird zuverlässiger erkannt.
- **Für andere Addons:** `AHSentinelAPI.TestRunning()` meldet, ob die Testroutine von AHSentinel läuft.

## 0.65.346
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Weniger Ruckeln, während das Auktionshaus aktualisiert:** Entzauber-Schnäppchen, Auf-/Absteiger der Übersicht, der Reiter Buchhaltung, das Teilen der Preise mit Mitspielern und das Sortieren langer Listen arbeiten jetzt in kleinen Schritten.
- **Fenster Preisverlauf:** zeichnet die Fläche unter der Preislinie mit halb so vielen Teilen und probiert nicht mehr bei jedem Teil eine Farbfunktion, die es im Client nicht gibt.
- **Herstellen erkennen:** Der Rang-Zauber eines Berufs (öffnet das Berufsfenster) zählt nicht mehr als Herstellen; es zählen nur Rezepte aus dem Berufsfenster.
- **Testroutine:** Sniper- und Wächter-Prüfung nennen, was eine Suche aufgehalten hat („nicht prüfbar“, wenn der Server sperrt); das gemeinsame GoldSentinel-Adressbuch bleibt genau wie vorher (ein Testname eines anderen Addons stört die Prüfung nicht mehr); mehr Angaben zu Vollscan-Speicher und Wächter-Rechenzeit.

## 0.65.345
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Vollscan ruckelt weniger:** Die Vorbereitung der verfolgten Items baut nicht mehr die ganzen Sniper-Zielzeilen (im Spiel bis 37 ms in einem Bild), sondern sammelt nur die Item-Nummern und kann dazwischen abgeben.
- **Namensliste ruckelt weniger:** Die eingebaute Liste der Itemnamen wird in kleinen Portionen aufgebaut (64 Fächer statt einer grossen Tabelle).
- **Testroutine:** Die Vollscan-Prüfung bewertet AHSentinels eigene Arbeit je Bild; Zeit anderer Addons oder des Spiels steht als Hinweis dabei, mit Verursacher.

## 0.65.344
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **„Heute tun“ – Verkaufspreise:** Die Angebotsleiter nimmt keine ältere Suche mehr, wenn es einen neueren Scan gibt (ein Verkaufsvorschlag wurde mit einem 18 Minuten alten Angebot verglichen).
- **Wächter ruckelt weniger:** Die Bewertung einer Wächter-Runde (mehrere hundert Angebote) läuft jetzt in kleinen Schritten im Hintergrund statt in einem Bild.
- **Vollscan:** weniger Speicher je Scan (der Tagesbeginn wurde zehntausende Male mit jeweils neuer Tabelle berechnet). Die Scan-Messung trennt jetzt den eigenen Speicher von anderen Addons und dem Spiel.
- **Stapelgrössen gemerkt:** Direkt nach dem Einloggen werden Items, die der Client noch nicht geladen hat (z. B. Leinenstoff), nicht mehr wie Einzelstücke gerechnet (Einzahlung und Auktionsgrösse).
- **Herstellen erkennen:** Zauber beim Einloggen/Neuladen (z. B. der Anmelde-Effekt) und während des Tests eines anderen GoldSentinel-Addons zählen nicht mehr als Herstellen; die Selbstkontrolle nennt den Zaubernamen.
- **Ketten:** Itemname und Händlerpreis jetzt auch im Forever-Client.
- **Testroutine:** Mehrere Prüfungen hängen nicht mehr vom Alter deiner echten Preise oder von geladenen Items ab; die Prüfung der Marktdaten läuft in kleinen Schritten.

## 0.65.343
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Für andere Addons (API):** neu `API.Pending()` – true, solange AHSentinel nach dem Einloggen seine Lernwerte noch berechnet. Andere GoldSentinel-Addons (z. B. ProfessionSentinel) können dann „AHSentinel lädt noch“ anzeigen statt keinen Wert. Rein zusätzlich, bestehende Aufrufe ändern sich nicht.

## 0.65.342
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Behoben: AHSentinel lud nicht vollständig (seit 0.65.335).** Ein Lua-Fehler beim Laden („AHAnalyzerPro.lua:161: attempt to concatenate local 'line'“) hielt grosse Teile des Addons an. Bitte sofort aktualisieren – 0.65.335 bis 0.65.341 nicht mehr benutzen.
- **Gelernte Kauf-Statistik:** Ältere Käufe, die aus der Liste der letzten Käufe gefallen sind, zählen wieder mit (Trefferquote und Anzahl Fälle für das Kauf-Budget).
- **Sitzungsprotokoll:** Deine Klasse steht wieder drin statt „?“.
- **Ältere Clients:** Die Stapelgrösse von Taschen-Items wird beim Zählen des Entzauberns wieder richtig gelesen.

## 0.65.341
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Flüssigere Tooltips:** Die Prognose-Zeile im Tooltip rechnet nicht mehr einmal je Minute die ganze Prognose-Auswertung am Stück, sondern nimmt das im Hintergrund vorbereitete Ergebnis (kurz nach dem Einloggen kann die Zeile etwas später erscheinen).
- **Entzauber-Fenster:** Die Statistik-Zeile wird deutlich schneller berechnet (jeder Materialpreis einmal statt je Beute-Eintrag).

## 0.65.340
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Namensverzeichnis nur für eindeutige Namen:** Haben zwei Items denselben Namen, nimmt der Briefkasten keinen direkten Treffer, sondern sucht wie bisher (nie auf das falsche Item gebucht).
- **Testroutine:** Lange Prüfungen sind in kleinere Schritte geteilt (Item-Menü, Überlagerung in den Optionen, Tooltips je Marktlage, Prognose-Bericht), damit der Testlauf selbst weniger ruckelt. Im normalen Spiel ändert sich nichts.

## 0.65.339
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Schnellerer Briefkasten und Namenssuche:** Item-Namen aus Auktionshaus-Post (und überall, wo ein Name einem Item zugeordnet wird) werden jetzt über ein Verzeichnis der Namen in deiner Spielsprache gefunden, das beim ersten Bedarf im Hintergrund gebaut wird – etwa 20 ms weniger je Brief; mehrdeutige Namen werden wie bisher gesucht.
- **Design- oder Sprachwechsel nie im Kampf:** Wechselst du im Kampf, werden die Fenster direkt nach dem Kampf neu aufgebaut; die Dauer des Neuaufbaus wird protokolliert.
- **Testroutine:** Berichte nehmen die im Hintergrund vorbereitete Prognose-Auswertung auch über einen Minutenwechsel hinweg; Design-/Sprachwechsel sind als einmalige, vom Spieler ausgelöste Handlung gekennzeichnet.

## 0.65.338
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **CSV-Export ohne Ruckeln:** Der Export wird jetzt im Hintergrund in kleinen Portionen vorbereitet; das Fenster öffnet sich, sobald er fertig ist.
- **Testroutine:** Die Speicher-Prüfung des Vollscans folgt der neuen Regel (erster Scan der Sitzung bis 30 MB, weitere bis 10 MB, ohne die gelesenen Auktionen; kein Bild über 40 ms mit Speicherbereinigung); Berichte nehmen die im Hintergrund vorbereitete Prognose-Auswertung.
- **Testroutine / Diagnose:** Die vollständige Liste der Oberflächen-Befunde des letzten Testlaufs wird jetzt in den gespeicherten Daten behalten (für den Uploader), und das Lesen von Sniper-Ergebnissen über 16 ms wird mit der Anzahl Angebote protokolliert. Im normalen Spiel ändert sich nichts.

## 0.65.336
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Flüssigerer Vollscan:** Nach dem Vollscan werden die bis zu 60 auffällig billigen Waren nicht mehr am Stück sortiert und eingereiht (eine Meldung statt 60); weniger Zwischen-Tabellen während des Scans (Preis-Rhythmus, Warengruppen, Stapelgrössen).
- **Andere Addons werden benachrichtigt** (Grund „settings“), sobald die gelernten Werte nach dem Einloggen fertig sind.
- **Hintergrund-Arbeit gemessen wie der gemeinsame GoldSentinel-Takt:** längstes Bild mit Stelle, Bilder über 5/16/40 ms und Stellen, an denen keine Pause möglich ist, werden gezählt und in der Vollscan-Messung gezeigt. Eine Pause an so einer Stelle wird jetzt übersprungen, statt die Arbeit abzubrechen.

## 0.65.335
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Richtige Werte für andere Addons (ProfessionSentinel):** Antworten an andere Addons werden nachträglich nie mehr überschrieben. In 0.65.334 konnte eine gemerkte Antwort (z. B. die Zutatenliste eines Rezepts) später die Zutaten eines ANDEREN Items zeigen – das konnte in ProfessionSentinel falsche Herstellkosten ergeben. Behoben; Wiederholungen legen weiterhin keine neuen Tabellen an.
- **Gold pro Stunde ohne Ruckeln:** Der 30-Tage-Bericht wird jetzt immer im Hintergrund in kleinen Portionen gerechnet (längstes Bild etwa 6 ms statt etwa 100–150 ms); bis er fertig ist, gilt der letzte Wert mit seiner Stand-Zeit. Genauso die Ansicht „Rendite“ in der Buchhaltung.
- **Keine vorläufigen Werte direkt nach dem Einloggen:** In den ersten Sekunden nach dem Laden, solange die gelernten Absatz-Faktoren noch gerechnet werden, bekommen andere Addons „noch nicht bekannt“ statt eines vorläufigen Werts, der Sammelkauf urteilt nicht und der Sniper wartet („Lernwerte werden geladen“).
- **Testroutine:** Die Prüfung „Ereignisse gesammelt“ (T167) schlägt mit geladenem ProfessionSentinel nicht mehr fehl; langsame Ereignis-Empfänger werden im Spiel mit Datei und Zeile genannt; Zauber 836 zählt nicht mehr als Herstellen; die Regressionsliste ist wieder vollständig; die Prüfliste zeigt nach „alles“ sofort den neuen Stand; lange Hintergrund-Schritte nennen, ob eine Speicherbereinigung lief; die Markt-Ansichten in der Testroutine enden bei grossen Datenmengen nicht mehr als „Fehler“.

## 0.65.334
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Flüssiger für andere Addons (z. B. ProfessionSentinel):** Die Schnittstelle von AHSentinel für andere Addons ist jetzt viel günstiger. „Gold pro Stunde“ wird einmal je Datenstand gerechnet statt bei jedem Aufruf (vorher je etwa 100 ms); wiederholte Preisfragen zum selben Item kommen aus dem Speicher, ohne neue Tabellen; die erste Frage nach dem Einloggen rechnet die Lern-Faktoren nicht mehr am Stück. Neu: eine fertige Liste der Entzauber-Schnäppchen (im Hintergrund gerechnet) für andere Addons.

## 0.65.333
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Flüssigere Fenster:** Die Listen „Aufsteiger/Absteiger“ in der Übersicht und die Item-Liste im Preisverlauf-Fenster entstehen jetzt im Hintergrund in kleinen Portionen (wie die Markt-Ansichten) – das Öffnen hält das Spiel bei vielen gescannten Items nicht mehr kurz an.
- **Für Tester – noch weniger Ruckeln in der Testroutine:** „Heute“, Namenssuche, Flips, Verkaufbarkeit und die Händler-/Entzauber-Listen laufen in Portionen; der Sprachwechsel zeigt je Bild einen Reiter; mehrere Prüfungen kopieren oder durchsuchen nicht mehr alle echten Daten (mit echten Daten: 63 → 39 Schritte über 16 ms in Teil „auto“). Das längste Bild eines Testlaufs (T722) wird wieder gemessen – es zeigte immer „0 ms“.

## 0.65.332
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Preisschutz – Marktwert und aktuelle Angebote widersprechen sich:** sagt der Marktwert „zu billig“, die frischen Angebote aber „zu teuer“, kommt kein Vorschlag mehr, der gleich wieder warnt. Stattdessen EINE klare Meldung mit beiden Zahlen („Marktwert vermutlich veraltet“); der Vorschlag ist der Preis der aktuellen Angebote, eingestellt wird nach deinem Klick auf „Preis anpassen“. Ohne Klick nie unter 75 % des Marktwerts.
- **Für Tester – weniger Ruckeln in der Testroutine:** Prüfungen, die eine ganze Markt-Ansicht oder „Heute“ am Stück rechneten, nehmen nur noch ihre Test-Items oder laufen in mehreren Schritten (mit echten Daten: 96 → 63 Schritte über 16 ms in Teil „auto“). Ein Test-Scan erledigt keinen vorgemerkten Vollscan-Schritt aus „alles“ mehr.

## 0.65.331
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Für Tester – die Testroutine fasst deine echten Sniper-Daten nicht mehr an:** zwei Prüfungen schrieben in die heutigen Sniper-Zahlen („gekauft“/„verpasst“) und in „gefunden“ eines echten Sniper-Ziels. Die Routine hat das zurückgeschrieben, jetzt wird gar nicht mehr geschrieben: Test-Treffer zählen nur in eine Kopie, und die kurze Prüfung „Sniper scharf“ sucht nur ihr eigenes Test-Ziel.
- **Für Tester – „Einstellen (simuliert)“ bleibt nicht mehr am Preisschutz hängen:** liegt das günstigste echte Angebot weit unter dem Marktwert, nimmt die Prüfung einen Preis, den der Schutz annimmt, oder – wenn er keinen annimmt – den Weg „Trotzdem einstellen“. Wirklich eingestellt wird nichts.
- **Für Tester – „Markt-Scan“ wartet auf den Server:** direkt nach anderen Suchen war der Server noch nicht bereit, und die Prüfung meldete „Scan ließ sich nicht starten“. Jetzt wartet sie bis zu 60 Sekunden, startet den Scan selbst und wird sonst mit Grund übersprungen.

## 0.65.330
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Behoben – Lua-Fehler nach der Testroutine („TextStatusBar … tainted by AHSentinel“):** Die Entwickler-Testroutine ersetzte vorübergehend einige Spiel-Funktionen (z. B. GetCVar). In WoW „verdirbt“ das diese bis zum /reload, sodass danach Blizzards eigene Lebens-/Mana-Leisten scheitern konnten. Die Testroutine fasst jetzt keine Spiel-Funktion mehr an, sie ersetzt nur AHSentinels eigenen Zugang. Eine neue Prüfung nach jedem Lauf bestätigt, dass die wichtigen Spiel-Funktionen unberührt sind.

## 0.65.329
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Aufgeräumte Fenster (Teil 4):** Zahlen werden nie mehr abgeschnitten. Markt „Was tun“: erste Zeile Aktion und Item, zweite Zeile nur die Zahlen. Schnäppchen unter Händlerpreis: das Alter des Preises („vor x Min.“) steht in einer eigenen Zeile unter dem Namen. Sniper-Ziele: der Hinweis „lernt noch“ steht im Tooltip, die Zeile zeigt den Namen. Feld-Hinweise (z. B. „Stufe bis“) werden gleich beim Anlegen eingepasst.
- **Für Tester:** Die Fenster-Prüfung (T750) prüft jetzt auch die Markt-Details, die Buchhaltungs-Details, das Warnschutz-Fenster und – wenn offen – das Berufsfenster und die Post-Knöpfe. Gekürzte Listenzellen mit ganzem Text im Tooltip stehen als „gekürzt (Tooltip)“ da und sind kein Fehler – ausser eine Zahl würde abgeschnitten.

## 0.65.328
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Aufgeräumte Fenster (Teil 3):** Die Spalte „Was tun“ im Markt bricht auf zwei Zeilen um; kürzere Sätze für Kaufen-und-Einstellen, Händler-Flip und „Nicht einstellen“ (alle Sprachen). Item-Namen passen besser: Übersicht, Preisverlauf-Liste, Schnäppchen, Buchhaltung Verlauf und Statistik (Zahlen-Spalten etwas schmaler).

## 0.65.327
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Aufgeräumte Fenster (Teil 2):** Ist der Text einer Listenzelle zu lang für die Spalte, steht er beim Darüberfahren ganz im Tooltip. Die Erklärzeile im Markt hat zwei Zeilen, die Preisleiter in den Markt-Details zwei Zeilen, die Spalte „eigene“ unter Buchhaltung > Entzaubern ist breiter, und die Stufen- und Itemlevel-Felder (Einkauf, Sniper) sind breit genug für ihre Hinweise.
- **Für Tester:** Die Selbstkontrolle zeigt ihren Status aus den Fällen der aktuellen Version und nennt ältere Fälle getrennt („seit 0.65.327: … · älter: …“). Der Testbericht nennt jeden Schritt über 16 ms mit Namen.

## 0.65.326
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Aufgeräumte Fenster (Teil 1):** Keine Knöpfe mehr, die aus einer Liste ragen (das „X“ der Sniper-Ziele, das „+“ der Schnäppchen): Ist eine Liste schmaler als ihre Spalten, wird ihre breite Spalte schmaler. Die Schnäppchen-Knöpfe und die Kopfzeile im Markt bleiben in ihrem Bereich, die Seitenleiste der Buchhaltungs-Statistik verdeckt die Ansicht-Knöpfe nicht mehr, und der Knopf „Gesperrt“ im Entzauber-Fenster liegt nicht mehr unter dem Schliessen-Knopf.

## 0.65.325
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Zielliste:** Ein pausiertes Ziel zeigt in der Spalte „Stand“ jetzt einen kurzen Text („Pause bis 18:45 · 3 Fehlkäufe“); der ganze Text steht im Tooltip.
- **Für Tester – Sniper-Test:** „Reihum“ (S8) misst Lücken ab der ersten Suche; die Zeit bis zur ersten Suche steht getrennt (im letzten Ingametest war sie der einzige Grund für den Fehler). Warten, während du das AH selbst benutzt, zählt als Pause. Die Prüfung der Zielzeile prüft den kurzen Text, den die Zeile wirklich zeigt. Die Prüfung am Berufsfenster wartet auf einen verschobenen Neuaufbau und nennt übersprungene/verschobene Aufbauten.

## 0.65.324
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Selbstkontrolle „ein Lohnt bis je Item“ berichtigt:** Sie meldete „zwei Werte“ bei Items, deren bester Weg der Händler oder der Wiederverkauf im AH ist: Sie verglich die Schnittstelle für andere Addons (liefert den besten Weg) mit dem Entzauber-Wert. Jetzt gilt für beide Selbstkontrollen eine Regel: Jede Entzauber-Anzeige zeigt die Entzauber-Grenze, die Schnittstelle den einen Wert über alle Wege. Echte Abweichungen werden weiter gefunden. Keine angezeigte Zahl ändert sich.
- **Für Tester:** Diese Selbstkontrolle läuft jetzt in kleinen Portionen (vorher im Nachbau 90 ms am Stück).

## 0.65.323
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Optionen öffnen ohne Ruckler:** Beim ersten Öffnen der Optionen zählte das Addon die eingebauten Item-Namen aller zehn Sprachen, indem es die ganzen Namenslisten kopierte (rund 30 MB Zwischenspeicher; im Nachbau 96 ms). Die Zahlen liegen jetzt dem Addon bei (gegen die Listen geprüft; weicht eine Liste je ab, wird ohne Kopie gezählt): 3,8 ms und 1 MB.
- **Für Tester – Testroutine in kleineren Schritten:** Lange Einzelprüfungen (Bericht-Prüfungen, Preisverlauf, Vollscan-Auswahl, Verkaufen-Fenster, Reiter Buchhaltung u. a.) laufen jetzt in mehreren kurzen Schritten; Ersatz-Werte gelten nur innerhalb eines Schritts. Die Zeile „Schritte über 5 ms“ nennt jetzt die richtige Prüfung.

## 0.65.322
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Behoben – Kauf doppelt gebucht:** Wurde die Rechnung eines Sniper-Kaufs gelesen, bevor der Kauf selbst gebucht war, stand der Kauf zweimal da (einmal aus der Post, einmal vom Sniper) – in der Buchhaltung und im Kauf-Journal. Jetzt übernimmt der Sniper-Kauf die Zeile der Rechnung, eine zweimal gelesene Rechnung wird erkannt, und eine Rechnung gehört zum zeitlich nächsten Kauf. Bestehende Doppel werden einmal bereinigt (nur die zweite Zeile desselben Kaufs; echte Käufe bleiben); die Zahlen stehen im Protokoll (KAUF-DOPPELT).
- **Behoben:** Zwei gleiche Käufe in derselben Stunde behalten beide Rechnungen (vorher wurde die zweite übersehen).
- **Mess-Hüllen:** Geschützte Rahmen (z. B. der Entzauber-Knopf) werden von der Bild-Messung gar nicht mehr berührt.

## 0.65.321
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Für Tester – `/ahs testroutine alles` wartet nie auf dich:** Ist das Fenster eines Schritts zu, wenn er dran ist (Auktionshaus, Berufsfenster, Händler), wird der Schritt vorgemerkt und der Lauf endet normal („noch offen“, kein Fehler). Der vorgemerkte Schritt läuft dann von selbst, sobald du das Fenster beim normalen Spielen öffnest (nur Entwicklermodus, nie im Kampf, höchstens 7 Tage), mit einer kurzen Chatzeile „… nachgeholt – bestanden/FEHLER“ und einem eigenen kleinen Bericht. Der Vollscan-Schritt wartet nicht mehr auf die 15 Minuten des Servers: gemessen wird der nächste Schnell-Vollscan, den du selbst startest (Entwicklermodus).

## 0.65.320
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Weniger Ruckeln nach dem Einloggen und nach Scans:** Das erste Lesen des Kauf-Journals, die Auswertung der Sniper-Entzauber-Tage, die Grössenprüfung der gespeicherten Daten, die Auswertung der Kauf-/Verkaufszeitpunkte und die eingebaute Namensliste laufen jetzt in kleinen Portionen im Hintergrund (vorher je 9–17 ms am Stück).
- **Gelernter Absatz-Faktor:** wird jetzt nach jedem gültigen Vollscan neu gerechnet (vorher praktisch nur einmal pro Stunde).
- **Vollscan:** Scheitert das Einlesen, enden Scan und Messung sauber (vorher blieb die Bild-Messung bis /reload an). Eine Messung endet spätestens nach 30 Minuten.
- **Gemeinsame Marktdaten (Version 10):** prüfen ihr Zeitbudget öfter – keine Bilder über dem Budget beim Teilen.
- **Für Tester – Messung:** Die Vollscan-Messung zählt jetzt auch AHSentinels eigene Fenster-Skripte und Zeitgeber („Skripte/Zeitgeber“), „Rest“ ist damit nur noch Spiel und andere Addons. Im Entwicklermodus steht jeder langsame Empfänger eines Ereignisses (über 16 ms) mit Datei und Zeile im Protokoll.

## 0.65.319
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Liste „Heute“ – Knopf für jede Zeile:** Die Zeilen „Entzaubere … aus der Tasche“ und „Preis gefallen … jetzt verkaufen“ hatten keinen Knopf. Jetzt haben sie einen, und er öffnet das passende Fenster.
- **Ruhigerer Vollscan:** Die Auswahl der 500 Items mit den meisten Auktionen sortiert nicht mehr alle Items am Stück, sondern läuft in Portionen.
- **Für Tester – Testroutine:** Der Vollscan-Schritt von `/ahs testroutine alles` erkennt den gemessenen Scan jetzt (vorher wartete er ewig, sobald 5 Scans gespeichert waren, und meldete „Scan ohne Messung“). Prüfungen lesen deine echten Daten nicht mehr mit: die Margen-Prüfung nutzt ein leeres Test-Journal, die Budget-Prüfung ein Test-Gold, die Einstellen-Prüfung einen Preis, den der Preisschutz annimmt, die Zwischenspeicher-Prüfung ein leeres Scan-Protokoll. Eine lange Prüfung (Ringpuffer) ist in zwei kurze geteilt.
- **Für Tester – Vollscan-Messung:** Das längste Bild zeigt jetzt auch den Speicher vor und nach dem Bild, die Bereinigung in den Bildern danach und die Zeit für das Lesen der Auktionsliste aus dem Spiel.

## 0.65.318
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Viel weniger Ruckeln nach dem Vollscan:** Nach jedem Scan las die gelernte Kauf-Marge das ganze Kauf-Journal neu (bis 3000 Einträge) – für jedes Item der Liste „Heute“ und der Preisprüfung. Mit grossen Daten gab das Bilder von 20–60 ms, viele hintereinander. Jetzt wird das Journal nur neu gelesen, wenn es sich wirklich geändert hat (und dann nur die geänderten Einträge); alle Zahlen bleiben genau gleich.
- **Gelernter Absatz-Faktor je Warengruppe:** jetzt in einem Durchlauf für alle Gruppen (vorher ein Durchlauf je Gruppe, jeder ohne Pause) und nach jedem Scan und zur vollen Stunde im Hintergrund vorgerechnet.
- **Für Tester – Vollscan-Messung:** Das längste Bild eines Vollscans wird jetzt zerlegt: eigene Arbeit von AHSentinel (Hintergrund-Aufgaben, Ereignisse), Rest (Spiel, andere Addons) und Zahl der Antworten des Servers auf Item-Daten. So sieht man, woher ein langes Bild wirklich kommt.
- **Für Tester – Testroutine:** neue Prüfung für das Kauf-Journal (nur bei Änderung gelesen).

## 0.65.317
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Behoben für Tester – „script ran too long“ bei `/ahs testroutine alles`:** Das Fenster des Testberichts wurde nach jeder einzelnen Prüfung neu aufgebaut, und ein Block der Testroutine lief mit über 400 Prüfungen am Stück. Jetzt wird das Fenster höchstens alle halbe Sekunde neu gezeichnet, jede Prüfung ist ein eigener kleiner Schritt (höchstens 5 ms je Bild), und das Aufräumen des Speichers läuft in Portionen. Prüfungen, die allein lange dauern, stehen mit Namen und Zeit in der Zusammenfassung. Ein Fehler in der Fensteranzeige stoppt den Lauf nie.

## 0.65.316
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Für Tester – Testroutine:** Die nachgebauten Marktlagen benutzen für Ausrüstung jetzt ganze Silberpreise (wie im Spiel) – geprüft wird nur noch, was es wirklich geben kann.

## 0.65.315
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Flüssigerer Vollscan:** Die Vorbereitung der Preis-Verfolgung nach einem Vollscan läuft jetzt in Portionen (vorher bis 16 ms am Stück).
- **Gemeinsame Marktdaten (Version 9):** Teilen und Auswerten der Marktdaten laufen jetzt ebenfalls in Portionen – kein Ruckeln nach Vollscans.
- **Für Tester – Testroutine:** Die Prüfung „Scan-Auswertung in Portionen“ ist auch dann ein Fehler, wenn ein einzelnes Bild mehr als das Doppelte der Grenze braucht.

## 0.65.314
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Markt-Reiter – Händler:** Zahlt der Händler mehr als das Auktionshaus nach Gebühren, sagt die Empfehlung für ein Item in deiner Tasche jetzt „an den Händler für …“ (vorher „einstellen für …“ zum tieferen Auktionspreis). Und ein Angebot unter einem bestätigten Händlerpreis bekommt im Detail „kaufen bis …“, genau wie die Liste Markt > Händler (vorher stand im Detail „liegen lassen“).
- **Für Tester – Testroutine:** prüft die Empfehlung des Markt-Reiters in allen Marktlagen (Ware und Ausrüstung, mit und ohne Bestand).
- 0.65.313 (Tooltip: „läuft oft ab“, Aufkauf-Leiter) kommt mit dieser Version.

## 0.65.313
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Tooltip verspricht nicht mehr als der Verkaufen-Reiter:** Läuft ein Item oft ab (3-mal in Folge), zeigt „Verkaufen:“ im Tooltip jetzt den Preis, den der Verkaufen-Reiter vorschlägt (nach dem AH-Anteil), grau markiert „(läuft oft ab)“ – nicht mehr den höheren Wert.
- **Tooltip – Aufkauf ohne Kennzeichen:** Ist die ganze Angebots-Leiter hoch (gleiche Erkennung wie im Verkaufen-Reiter), steht im Tooltip grau-gelb „Preis wohl künstlich hoch (Aufkauf-Leiter) – eigene Bestände jetzt verkaufen?“. Bei einem erkannten Aufkauf bleibt der klare Text.

## 0.65.312
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Flüssiger nach einem Vollscan:** Waren nach einem Vollscan die Preis-Zwischenspeicher fertig, wurde der offene AHSentinel-Reiter (z. B. Markt) in einem Stück neu aufgebaut – ein kurzer Ruckler. Jetzt geschieht das im Hintergrund in kleinen Portionen.
- 0.65.311 (Buchhaltung: Abbruch-Post, Testroutine-Prüfung in Portionen) kommt mit dieser Version.

## 0.65.311
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – abgebrochene Auktionen:** Eine alte Post „Auktion abgebrochen“ übernimmt nicht mehr einen späteren eigenen Abbruch desselben Items; jede Post gehört zur Buchung aus ihrer Zeit (die Summe stimmte schon, jetzt auch das Datum).
- **Für Tester – Testroutine:** Die Prüfung „Scan-Auswertung in Portionen“ bewertet das mittlere der drei längsten Bilder (ein einzelner Ruckler des Rechners macht sie nicht mehr rot); das längste Bild steht weiter da.

## 0.65.310
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Für Tester – Testroutine:** prüft jetzt auch den Tooltip in sieben Marktlagen (normal, Aufkauf, Flut, dünner Markt, Händlerpreis, alter Scan) für Ware und Ausrüstung: Preis, Marktwert, Wert „Verkaufen:“, Aufkauf-Hinweis und Händlerpreis.

## 0.65.309
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper – ehrlicher Verkaufswert:** Solange die Sniper-Trefferquote gesperrt ist (unter 60 %), steht der Verkaufswert grau mit „Verkaufswert unsicher (Treffer x %)“ – in der Zielzeile, in der Treffer-Meldung im Chat und im Tooltip (Shift). Gekauft wird weiter nur nach deinem Höchstpreis.
- **Für Tester – Testbericht:** Ein gesperrter Weg meldet jetzt auch „mittlerer Fehler über 15 %“, wenn das zutrifft (vorher nur bei freien Wegen).

## 0.65.308
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Für Tester – Testbericht:** Lange Felder des Testberichts (Markt-Kern, Entzauber-Stand, Lernen, Prognose, Vollscan) werden nicht mehr bei 300 Zeichen abgeschnitten, sondern in Teile geteilt; jeder Weg des Markt-Kerns hat ein eigenes Feld.
- 0.65.307 (Buchhaltung, Marktdaten in Portionen, Texte der Testroutine) kommt mit dieser Version.

## 0.65.307
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – abgebrochene Auktionen:** Hast du die Post „Auktion abgebrochen“ erst mehr als 6 Stunden nach deinem eigenen Abbruch gelesen, wurde die Anzahlung ein zweites Mal als verfallen gebucht. Die Post wird jetzt nach ihrer Ankunftszeit zugeordnet – die Anzahlung zählt genau einmal.
- **Gemeinsame Marktdaten in Portionen:** Die Übergabe eines Vollscans an die gemeinsamen Marktdaten läuft jetzt in kleinen Portionen (höchstens 5 ms je Bild) statt rund 10 ms am Stück.
- **Für Tester – `/ahs testroutine alles`:** Der Chat sagt bei den letzten zwei Schritten genau, was zu tun ist (Beruf öffnen und ein Rezept anklicken; Auktionshaus schliessen und den nächsten Händler ansprechen – für den Weg hast du 5 Minuten). Ein Charakter ohne Beruf bekommt „kein Beruf“, das zählt nicht gegen das Ergebnis. Testkäufe aus der Prüfliste (Leinenstoff zu 50 Silber) zählen nie für die Sniper-Trefferquote – nur diese und höchstens 24 Stunden lang.

## 0.65.306
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Trefferquote lernt neu:** Die Quote „Sniper“ (Markt-Reiter) war bei 59 % gesperrt. 37 ihrer 39 Fälle waren alte Entzauber-Käufe aus der Zeit vor 0.65.258, die noch warteten und dann mit dem falschen Massstab gewertet wurden (Auktionspreis statt Entzauber-Ertrag). Diese alten Fälle werden einmal entfernt; die Entzauber-Kauftage werden aus dem Journal neu gewertet. Testkäufe aus der Prüfliste (Entwicklermodus) zählen nie.
- **Gemeinsame Marktdaten:** Test-Item-IDs werden nie gespeichert oder geteilt und beim Laden entfernt.

## 0.65.305
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufen – „Preis anpassen“ bei zu teuer:** War der vorgeschlagene Preis selbst „zu billig“ (z. B. unter deinem Einkaufspreis), kam nach „Preis anpassen“ gleich die nächste Warnung. Vorgeschlagen wird jetzt der kleinste Preis ohne jede Warnung, solange er nicht wieder „zu teuer“ ist.
- **Für Tester – Prüfliste (Entwicklermodus):** Es bleibt nur noch, was wirklich deine Hand braucht: eine Zeile für `/ahs testroutine alles`, der Kauf-Knopf mit echtem Testkauf, das Mausrad (grün und grau), Einstellen zu billig / zu teuer mit echter Auktion und graue Items beim Händler. Jeder Punkt sagt: wo, nummerierte Schritte mit den genauen Knopfnamen, was du sehen musst und was es kostet.

## 0.65.304
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Testdaten aufgeräumt:** Zwei Prüfungen der Testroutine liessen Testdaten zurück: 14 erfundene Händlerpreise und (über die gemeinsamen Marktdaten) einen nachgespielten Scan mit 1050 erfundenen Items. Beides ist behoben, und beim Laden entfernt AHSentinel solche Testdaten jetzt selbst aus deinen Daten (echte Daten bleiben unberührt).
- **Testroutine:** Die Sicherungs-Prüfung („nichts Echtes geändert“) ist strenger und meldet jetzt auch kleinste Abweichungen.
- 0.65.303 (Vollscan-Messung in `/ahs testroutine alles`) kommt mit dieser Version.

## 0.65.303
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Für Tester – `/ahs testroutine alles`:** misst jetzt auch den Schnell-Vollscan selbst. Zwei Vollscans im Abstand von mindestens 15 Minuten (der Chat sagt, wann der nächste kommt); gemessen werden der bleibende Speicher und die längste Lücke. Du musst nur das Auktionshaus offen lassen.

## 0.65.302
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Für Tester – `/ahs testroutine alles`:** misst jetzt auch den Schnäppchen-Wächter selbst. Er läuft 10 Minuten (sucht nur, kauft nie), öffnet einmal kurz die Optionen und misst dabei die Rechenzeit je Bild und die Hürden-Zeile („Letzte Runde: …“). Deine Wächter-Einstellung bleibt unverändert; danach ist er wieder so wie vorher. Ist keine Wächter-Kategorie gewählt, steht „nicht prüfbar“ mit Grund.

## 0.65.301
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Für Tester – `/ahs testroutine alles`:** führt jetzt alles, was ohne Hand geht, nacheinander aus: automatische Prüfungen (mit nachgebauten Marktlagen), Oberflächen-Prüfung, Befehlsliste, Sniper-Testroutine (ohne echten Kauf), dann die Prüfungen am Auktionshaus, am Berufsfenster und am Händler, sobald das Fenster offen ist. Im Chat steht der Fortschritt („3 von 7 – …“), am Ende EINE Zusammenfassung („x von 7 bestanden, z nicht prüfbar – Grund“), die auch in den Testbericht geht. Erst dann kommt die Bitte um /reload. Abbrechen jederzeit mit `/ahs testroutine stop`.
- **Testroutine mit offenem Auktionshaus:** Nachgespielte Test-Scans gingen in die gemeinsamen Marktdaten, einige Prüfungen schrieben in echte Zähler. Die Sicherung stellte das wieder her, aber nicht immer vollständig. Jetzt bleibt alles unberührt.

## 0.65.300
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Händlerpreis nur, wenn er sicher ist:** Ein Händlerpreis, der nur aus der mitgelieferten Tabelle stammt (vom Spiel noch nicht bestätigt) und mehr als doppelt so hoch ist wie der Marktwert, zählt nicht mehr als Wert und nicht als Weg „Händler“ (Tooltip, Mein Lager, Markt, Sniper). Fall Eisengranate: Tabelle 5s, Markt 1s83. Im Tooltip steht er grau mit „Händlerpreis unbestätigt“. Vom Spiel bestätigte Händlerpreise bleiben immer die Untergrenze.

## 0.65.299
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Mehr Tests:** Der Markt-Reiter „Mein Lager“ wird jetzt für jede Marktlage geprüft (Wert = bester Weg × Menge wie überall; mit altem Scan grau „Scan nötig“). Im Spiel ändert sich nichts.

## 0.65.298
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Tooltip ohne Verzauberkunst:** Die Zeile „Gewinn: … / Stück“ rechnet jetzt mit dem Weg, den du wirklich gehen kannst – ohne Verzauberkunst (oder mit „Entzaubern“ in den Optionen aus) also mit Verkaufen bzw. Händler, wie Markt, Sniper und Gewinn-Fenster. Der Entzauberwert bleibt als graue Info-Zeile „Entzaubern (mit Verzauberkunst)“ bzw. „Entzaubern (Weg aus)“ sichtbar.

## 0.65.297
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Neu einstellen – nur, was zurückgekommen ist:** „Neu einstellen“ (Meine Auktionen) stellte bei Waren alles ein, was in deinen Taschen lag – auch das, was du bewusst behalten hast. Jetzt höchstens die Menge, die per Post zurückgekommen ist (z. B. 20 zurück, 60 in den Taschen -> 20 eingestellt, 40 behältst du); der Chat sagt die Menge. Ist die zurückgekommene Menge unbekannt, wird das Item übersprungen statt alles einzustellen.

## 0.65.296
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Meine Auktionen – „teurer neu einstellen“:** Stand im Markt nur ein einzelnes, viel zu teures Angebot (z. B. eines zu 50s, während die Ware sonst 10s kostet), schlug AHSentinel vor, deine Auktion abzubrechen und für 49s 99c neu einzustellen. Jetzt gilt höchstens der Preis, den auch der Reiter Verkaufen vorschlägt – der erkennt solche Ausreisser und einen Aufkauf.
- **Mehr Tests:** Der Status deiner Auktionen wird jetzt für jede Marktlage geprüft (normal, Aufkauf, Ausreisser, Flut, leer).

## 0.65.295
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Abnahme (`/ahs testroutine sniper`, für Tester):** Die Reaktionszeit (S6) wird jetzt in einer eigenen Phase von 60 s nur mit dem Test-Ziel gemessen. Deine eigenen Ziele werden dafür nur pausiert – nicht gelöscht, nicht verändert – und sind danach garantiert wieder aktiv, auch bei Abbruch, geschlossenem Auktionshaus oder /reload. Im Chat steht vorher „deine Ziele 60 s pausiert“ und danach „wieder aktiv“.

## 0.65.294
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Bester Weg überall gleich:** Gewinn-Fenster, „Beste Rezepte“ und die Schnittstelle für andere Addons (API.BestWay) wählen jetzt nach derselben Regel wie Markt und Sniper: kein Entzaubern, wenn der Weg in den Optionen aus ist, die Verzauberkunst fehlt oder das Hauptmaterial nur einen veralteten Preis hat; bei Gleichstand Entzaubern (vorher dort „Verkaufen“, im Tooltip „Entzaubern“). Die Gewinn-Zeile im Tooltip beachtet jetzt auch den Schalter „Entzaubern aus“ in den Optionen.
- **Mehr Tests:** Grösse einer Auktion (modernes AH: Ware als eine Auktion, altes AH: höchstens ein Stapel, gelernte Grösse zuerst) und der Entzauberwert, wenn du ein Material selbst regelmässig verkaufst, werden jetzt automatisch geprüft.

## 0.65.293
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Schnäppchen-Wächter:** Wurden Schnäppchen gefunden, die noch nicht gesichert sind, sagt das Wächter-Fenster das jetzt in einer grauen Zeile mit Grund (z. B. „2 Schnäppchen gefunden, aber noch nicht gesichert – Weiterverkauf lernt noch, 12 von 20 Fällen. Sie stehen rechts in der Liste.“). Ohne Ton, ohne Druck – vorher kam das nur als graue Chatzeile.

## 0.65.292
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Mehr Tests (Abläufe wie ein Spieler):** AH gleich nach „Einstellen“ schliessen, Fenster während der Preisprüfung schliessen, AH während einer Sniper-Suche schliessen, /reload, während eine Einstellung auf den Server wartet, „Abbrechen -> Post abholen -> Neu einstellen“ ein kaputter Eintrag im Preisverlauf sowie Stückpreis, Gesamt und Status in „Meine Auktionen“ werden jetzt automatisch geprüft. Im Spiel ändert sich nichts.

## 0.65.291
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Mehr Tests:** Die Standard-Laufzeit wird jetzt für alle Wege des Einstellens (Serie, Neu einstellen, „Heute tun“) automatisch geprüft, die von Hand gewählte Laufzeit gilt nur für dieses eine Einstellen, das alte Auktionshaus (Era/TBC) zeigt die Beschriftungen des Spiels, und Entzauberungen werden auf jedem Weg gezählt (Warteschlange anderer Addons, Rechtsklick in der Tasche). Im Spiel ändert sich nichts.

## 0.65.290
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Mehr Tests:** Optionen im Design „Klassisch“ mit 130 % auf Englisch (nichts überlagert, eine neue Option landet in der nächsten freien Zeile), die Gewinn-Zeile im Tooltip für Spieler ohne Verzauberkunst, der Taschen-Gesamtwert, wenn der Händler mehr zahlt, und das Adressbuch des GoldSentinel-Sync werden jetzt automatisch geprüft. Im Spiel ändert sich nichts.

## 0.65.289
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Reiter Schnäppchen:** Der Flipping-Rechner links ragt im Design „Modern“ nicht mehr 20 Pixel unten heraus.
- **Oberflächen-Prüfung der Testroutine:** Der graue Stand „lernt noch (12 von 20)“ ist gewollt und zählt nicht mehr als veralteter Text.

## 0.65.288
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Prüfliste (nur Entwicklermodus):** Der Punkt „Befehlsliste in Gruppen“ prüft sich nach „/ahs hilfe“ und „/ahs einstellungen“ jetzt selbst (Gruppen gezählt, Doppelte gesucht). Im normalen Spiel ändert sich nichts.

## 0.65.287
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Schnäppchen-Wächter sagt, warum nichts kam:** Unter dem Runden-Zähler steht jetzt für die letzte Runde, wie viele Angebote kamen und an welcher Prüfung alle hängen blieben, z. B. „Letzte Runde: 412 Angebote – 0 unter 30 % des Marktwerts – bei 30 % ist das selten, mit 50 % wären es 3 gewesen“. Die Prüfungen der Reihe nach: Ware, Marktwert, belastbarer Marktwert, unter deiner Schwelle, kein Preissturz, unter der Flip-Grenze, im Tagesbudget Weiterverkauf, Mindestwert, nicht gerade abgelehnt. Am Kaufen ändert sich nichts – der Wächter kauft nie ohne deinen Klick.

## 0.65.286
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Schnäppchen-Wächter bei sehr grossem Markt:** Die Entzauber-Prüfung legt viel weniger Zwischen-Speicher an (gemessen 2,1 KB statt 5,9 KB je Angebot), die Speicherbereinigung macht keine langen Bilder mehr. Gemessen mit 15 000 Angeboten: längstes Bild 11 ms statt 26 ms.
- **Sniper-Reiter:** Die Grenze von zwei Neuaufbauten je Sekunde (0.65.285) gilt nur noch beim Snipen (Sniper an, AH offen). Eigene Aktionen – Ziel setzen, löschen oder wählen – erscheinen wieder sofort.

## 0.65.285
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Ruhigeres Snipen:** Der Sniper-Reiter zeichnet sich höchstens zweimal je Sekunde neu (vorher bis zu 6-mal: Zeitgeber, jede Suche und die Hintergrund-Aktualisierung zeichneten ihn je neu). Was dazwischen passiert, erscheint am Ende der halben Sekunde – nichts geht verloren.
- **Kein Ruckler 90 Sekunden nach dem Einloggen:** Das Verdichten des Preisverlaufs pausiert jetzt nach jedem Item statt nach 50 Items (gemessen mit 7165 Items: längstes Bild 10 ms statt 72 ms).

## 0.65.284
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Eingebaute Testroutine berührt deine Daten nie:** Das Anzeigen der Entzauber-Statistik legt keinen neuen Tages-Zähler mehr an (nur das Zählen), und die Oberflächen-Prüfung merkt sich die durchgeklickte Ansicht der Buchhaltung nicht mehr. Vorher musste die Testroutine diese Werte danach zurücksetzen und meldete das als Fehler.

## 0.65.283
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Messung beim Vollscan (nur Entwicklermodus):** Die Speicher-Prüfung nach einem Vollscan misst jetzt, was wirklich bleibt (nach der Speicherbereinigung), statt des Augenblickswerts, der je nach Bereinigung um 100 MB und mehr schwankt. Das Diagnose-Protokoll zeigt dazu, wie viel Speicher jeder Schritt des Scans anlegt. Im normalen Spiel ändert sich nichts.

## 0.65.282
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Absturz mit dem Schnäppchen-Wächter behoben („script ran too long“):** Mit der Entzauber-Prüfung und einem grossen Markt (über 7000 Items) lief die Prüfung aller Angebote in einem einzigen Bild und konnte das Spiel einfrieren. Jetzt läuft sie in kleinen Portionen (höchstens 5 ms je Bild), und jeder Materialpreis und Entzauberwert wird je Runde nur einmal gerechnet. Gemessen mit 7200 Angeboten: längstes Bild 7 ms statt 5,4 Sekunden.

## 0.65.281
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – im Blizzard-Fenster abgebrochene Auktionen:** Die Post „Auktion abgebrochen“ bucht die Einzahlung jetzt als verloren (vorher nur bei Abbrüchen über den AHSentinel-Knopf). Eigene Abbrüche werden nie doppelt gebucht.

## 0.65.280
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Mehr Tests:** Der Fall „Item mit Zufalls-Suffix“ im Einkauf (mit dem allgemeinen Item-Schlüssel nachladen; wirklich weg -> aus der Liste) wird jetzt automatisch geprüft. Im Spiel ändert sich nichts.

## 0.65.279
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Testbericht:** Die Abdeckungsliste der eingebauten Testroutine nutzt jetzt die aktuelle Nummerierung der offenen Punkte (alte Nummern bleiben als „alt“). Im Spiel ändert sich nichts.

## 0.65.278
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Keine doppelten Käufe in der Buchhaltung:** Ware von mehreren Verkäufern auf einmal kommt als mehrere Rechnungen in den Briefkasten. Alle werden jetzt dem einen Kauf zugeordnet (der Rest bleibt offen, bis die letzte Rechnung da ist); vorher konnte jede kleinere Rechnung ein zweites Mal gebucht werden.

## 0.65.277
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Daten zweier Rechner zusammenführen:** Entzaubern und Herstellen auf dem anderen Rechner bringen jetzt auch ihre Materialien bzw. Produkte mit dem richtigen Einstand in die zusammengeführte Buchhaltung (vorher fehlten die Materialien dort). Ältere Buchungen ohne diese Angaben werden im Protokoll gezählt.

## 0.65.276
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung bucht, was du wirklich bezahlt hast:** Waren-Käufe des Snipers werden jetzt mit dem Gold gebucht, das wirklich weggegangen ist, nicht mit dem angefragten Preis – der Server kann weniger berechnen (günstigere Stücke zuerst). Nur wenn im selben Moment nichts anderes gekauft wurde; sonst wie bisher der angefragte Preis. Behebt Tage, an denen die Käufe höher aussahen, als sie waren.

## 0.65.275
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Händlerpreise am echten Gold geprüft:** Verkauft AHSentinel für dich beim Händler, misst es den wirklich erhaltenen Gold-Betrag je Item. Bringt ein Item weniger als sein bekannter Händlerpreis (z. B. nach einem Hotfix), kommt eine Chatzeile und der Händler-Weg ist für dieses Item gesperrt – keine Händler-Flip-Vorschläge mehr mit falschem Preis. Ein späterer stimmiger Verkauf hebt die Sperre auf.

## 0.65.274
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Schnittstelle für andere Addons:** `AHSentinel.API.Sold(itemID[, seit])` liefert, wie viel du von einem Item verkauft hast und was es gebracht hat (nach AH-Anteil), aus deiner Buchhaltung – z. B. für ProfessionSentinel. Nur lesen. Sichtbar ändert sich nichts.

## 0.65.273
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Prüfliste im Spiel (nur Entwicklermodus):** zwei Messpunkte – „Vollscan: Speicher und Ruckeln“ (zwei Vollscans hintereinander: höchstens 10 MB mehr Speicher, längster Ruckler höchstens 50 ms) und „Oberflächen-Prüfung“ (`/ahs testroutine ui` ohne Fehler). Beide haken sich selbst ab oder zeigen die gemessenen Zahlen. Für normale Spieler ändert sich nichts.

## 0.65.272
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Knopf „Kaufen“ hält den Treffer:** Ein auf dem Knopf gezeigter Treffer bleibt klickbar, bis er gekauft, weg oder durch einen neuen Treffer ersetzt ist (höchstens 30 s nach dem letzten Sehen) – auch während der Sniper ein anderes Ziel sucht oder der Server kurz beschäftigt ist. Bei „nur Knopf“ sucht der Sniper seltener, solange ein Treffer wartet, damit dein Klick durchkommt. Trifft ein Klick genau die kurze Sperrzeit des Servers, sagt der Knopf das, und der Treffer bleibt. Preis, Max und Budget prüft der Server weiterhin bei jedem Kauf.

## 0.65.271
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Prüfliste im Spiel (nur Entwicklermodus):** drei neue Punkte für die neuen Funktionen – Warnschutz bei zu teuer, Schnäppchen-Alarm und die Befehlsliste in Gruppen. Die ersten beiden haken sich selbst ab, wenn sie funktionieren. Für normale Spieler ändert sich nichts.

## 0.65.270
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Befehlsliste in Gruppen:** `/ahs hilfe` zeigt die Befehle jetzt in vier Gruppen – Alltag, Einstellungen, Hilfe und (nur im Entwicklermodus) Entwickler – im selben Aufbau, den alle GoldSentinel-Addons bekommen sollen. Deutsche und englische Wörter gehen immer, dazu ein paar übliche Zusatzwörter (z. B. öffnen `/ahs einstellungen` oder `/ahs config` die Optionen).

## 0.65.269
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Vorräte vor Raid-Abenden:** 3 bis 5 Tage vor einem Raid-Termin (fest: 9.12.2026, Onyxia, Hyjal-Gipfel und Barrow Deeps öffnen; weitere Termine aus RaidMaster, sobald es sie anbietet; geprüft werden die Items der Raid-Vorlage /ahs raid und gehandelte Tränke/Essen) steht in „Heute tun“ ein Hinweis: „Tränke/Essen jetzt kaufen – heute x % unter dem Raid-Tag-Preis“, mit bis zu drei Items. Nur wenn der Preis je Wochentag gemessen ist (3 Wochen Daten, in beiden Wochen-Hälften am Raid-Wochentag mindestens 10 % teurer) – sonst „noch zu wenig Daten“. Nur ein Hinweis, kauft nie.

## 0.65.268
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Schnäppchen-Alarm:** Der Wächter meldet sich mit Ton und einer grünen Chatzeile nur noch bei *gesicherten* Schnäppchen – der Weiterverkauf ist durch seine eigene Trefferquote freigegeben, die Preisprüfung ist höchstens 60 s alt, Lockangebote zählen nicht und der Preis liegt im Höchstpreis. Nicht Gesichertes bekommt nur eine graue Zeile mit dem Grund, ohne Ton. Höchstens eine Meldung je Item in 10 Minuten. Von selbst an erst, wenn die Markt-Vorhersage ihre eigene Prüfung (P2) besteht; selbst an- oder abschalten unter Optionen > Kaufen & Sniper („Schnäppchen-Alarm“) – deine Wahl geht immer vor. Gekauft wird nie selbst – nur mit deinem Klick oder deiner Taste.

## 0.65.267
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Warnschutz – zu teuer:** Einstellen weit über dem Markt warnt jetzt auch (über dem 1,5-fachen des günstigsten fremden Angebots, ein einzelnes Lockangebot zählt nicht; ohne frische Preisprüfung über dem 2-fachen Marktwert) – es verkauft sich dann wohl nicht, und die Einzahlung wäre weg. „Preis anpassen“ schlägt das Unterbieten des günstigsten Angebots vor; „Trotzdem einstellen“ und die Bestätigungs-Regeln gelten wie bei zu billig.

## 0.65.266
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Intern: Die Zeitmessung der Hintergrund-Arbeit misst jetzt je Aufgabe (vorher bekam eine Aufgabe, die im selben Bild nach einer anderen lief, deren Schluss-Stück angerechnet). Der Selbsttest zählt ein einzelnes Lockangebot weit unter dem Markt nicht mehr als „günstigstes Angebot“. Für Spieler keine Änderung.

## 0.65.265
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Optionen:** Die Bereichs-Knöpfe links wechseln jetzt den Bereich (in 0.65.263/264 ging nur die Suche). Der gewählte Bereich steht in Gold.
- **Optionen – Kaufen & Sniper:** eine Zeile „Sniper kauft mit: Mausrad / Eigene Taste / nur Knopf“ statt zwei fast gleich heissender Zeilen.

## 0.65.264
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Kopfzeile im Markt-Reiter in Klartext:** statt „messe 0/5“ je Stufenband steht jetzt „Marktrichtung je Stufe: noch zu wenig Daten (2 von 5 Tagen)“, und sobald ein Band gemessen ist „1–25: Preise fallen · 26–45: Preise stabil …“. Die Hinweiszeile ist kürzer und läuft nicht mehr unter den Zähler „n Einträge“.
- **Einkaufsliste aus einem Rezept – auch mit ProfessionSentinel:** Berufsfenster offen, Rezept gewählt: `/ahs material` setzt alle Materialien auf eine Einkaufsliste, `/ahs fehlt` nur das, was dir fehlt.

## 0.65.263
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Optionen – endlich übersichtlich:** links die Bereiche (Allgemein, Anzeige & Tooltip, Verkaufen, Kaufen & Sniper, Markt & Empfehlungen, Daten & Lernen), rechts nur die Optionen dieses Bereichs in einer Spalte – ohne Scrollen. Oben ein Suchfeld findet jede Option in allen Bereichen (z. B. „Mausrad“, „Gebühr“). Alle deine Einstellungen bleiben, wie sie sind.
- Der Optionen-Knopf öffnet den Bereich, der zum offenen Reiter passt (Sniper -> Kaufen & Sniper).
- Behoben: Der Knopf „Preisschutz beim Einstellen“ zeigte keinen Wert – er hatte denselben Namen wie der Knopf „Warnschutz“.

## 0.65.262
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufen – „Preis anpassen“:** Der Preis, den der Warnschutz vorschlägt, gilt jetzt als deine Entscheidung – Einstellen fragt nicht ein zweites Mal („Preis prüfen! Nochmal klicken …“). Nur für genau diesen Preis und dieses Item, 2 Minuten lang.
- **„Trotzdem einstellen“:** Im Chat steht jetzt, dass diese Bestätigung 30 Sekunden gilt (gleiches Item, gleicher Preis) – ein zweites Einstellen gleich danach warnt nicht noch einmal.

## 0.65.261
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gold-Sicherheit – Sniper „nur Knopf“:** Mit „Kaufen mit: nur Knopf“ kaufen Mausrad und eigene Taste jetzt nichts mehr – vorher konnte das Mausrad über einem AHSentinel-Fenster (oder eine Tasten-Bindung) einen wartenden Treffer trotzdem kaufen.
- **Sniper:** Der Knopf „Mausrad“ neben „Sniper-Modus“ schaltet jetzt um: grün = das Mausrad kauft, grau = nur der Knopf „Kaufen“ kauft (dieselbe Einstellung wie in den Optionen). Ist der Kaufen-Knopf grau, steht der Grund in der Zeile darunter.

## 0.65.260
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Für Spieler keine Änderung. Intern: zwei weitere Punkte in der Prüfliste für Entwickler.

## 0.65.259
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Für Spieler keine Änderung. Intern: eine Prüfliste im Spiel für Tests, nur im Entwicklermodus (Spieler sehen nichts, sie kostet nichts).

## 0.65.258
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Lernen: Eigene 2-Stunden-Auktionen zählen jetzt, wenn sie früher verschwinden – das geplante Ende kommt aus deinem Journal (bisher wurden sie als "lange" Auktionen übersprungen).
- Sniper-Käufe fürs Entzaubern werden jetzt je Kauftag am echten Erlös gewertet (Summe Erlös gegen Summe Kaufpreis). Frühere falsche Wertungen dieses Wegs werden einmal zurückgesetzt.
- Sniper: Ein Ziel mit festem Max über "Lohnt bis" (Entzauber-Weg) zeigt sein Max gelb, mit einer Zeile im Tooltip (ab 3 Käufen mit dem gemessenen Ertrag). Neuer Knopf "Max folgt Lohnt bis" lässt das Ziel der Grenze folgen. Nichts wird erzwungen.
- Stufenbänder (Marktrichtung): Der Index ist jetzt eine Kette der Tag-zu-Tag-Änderungen über Items, die an beiden Tagen da sind. Items, die mitten im Zeitraum dazukommen, zeigen kein falsches "fällt" mehr.
- Absatz je Tag ist höchstens das ganze aktuelle Angebot; darüber steht der Wert grau als "unsicher".

## 0.65.257
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Rechenkern: Der einmalige Neuaufbau des Wegs "Verkauf" behält jetzt die Tage, die älter sind als dein Journal (sie stehen nur noch im Kern). Neu aufgebaut werden nur die Tage, die das Journal abdeckt. Ein Fall gilt nur als gezählt, wenn der Kern ihn wirklich gezählt hat; ein späterer Teilverkauf wird am selben Tag wie der Fall gebucht.

## 0.65.256
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Rechenkern: Verkaufte Einstellungen erreichen den Kern jetzt immer (vorher kamen ganz verkaufte nie an – er lernte "verkauft fast nie"). Jeder abgeschlossene Fall zählt genau einmal; ein späterer Teilverkauf trägt nur den verkauften Anteil nach. Der Weg "Verkauf" wird einmal aus deinem Journal neu aufgebaut.
- Der Kern zeigt eigene Zahlen, sobald seine Vorhersagen nach der Güte (Brier) besser sind als die Grundlinie, und fällt erst nach 7 bewerteten Tagen zurück.
- Markt-Tabellen aktualisiert; der Testbericht nennt die Teile "alle" und "kern".

## 0.65.255
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Einkauf > Entzaubern: Der Tooltip der "Mindestrendite" sagt jetzt, dass sie auch fürs Flippen gilt (Kaufgrenze in Heute, Markt und Sniper) und dass die kleinste Stufe 10 % ist.

## 0.65.254
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Gold-Sicherheit: Die Kaufgrenze fürs Flippen hält jetzt immer deine Mindestrendite (Einstellung "Mindestrendite", Standard 20 %) – auch ohne Lernen und in jeder Risiko-Stufe. Vorher war die Grenze ohne Lernen der volle Wiederverkaufswert (kein Gewinn, nach Einzahlung und Liegezeit ein Verlust).

## 0.65.253
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Testroutine: drei doppelte Abdeckungs-IDs umbenannt bzw. entfernt, dazu eine Prüfung, dass jede Abdeckungs-ID nur einmal vorkommt. Im Spiel keine Änderung.

## 0.65.252
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Flippen: eine Kaufgrenze für "Heute", den Markt-Reiter und den Sniper. Sie folgt jetzt auch deiner Risiko-Wahl (vorsichtig / normal / mutig); "normal" bleibt genau wie bisher. Ist die Verkaufsdauer bekannt, senkt ein fallendes Stufenband die Grenze, eine Spitze hebt sie auf.

## 0.65.251
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- "Heute" schlägt Entzauber-Käufe nur noch aus derselben Rechnung vor wie Markt > Entzaubern (Mindestgewinn, Qualität, Absatz der Materialien, Preissturz/Aufkauf). Vorher konnte "Heute" ein Teil vorschlagen, das Markt > Entzaubern ablehnt. Der Selbsttest zählt dieselbe Liste.

## 0.65.250
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Markt-Reiter "Heute": Der Tooltip eines Kauf-Vorschlags sagt es jetzt in einfachen Worten: "Bringt etwa x je Tag für 1g Einsatz – sicherere Wege kommen zuerst." (statt "Rang").

## 0.65.249
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Testbericht (MARKT-KERN): neue Zeile mit der Stufenband-Zeile genau so, wie sie im Kopf des Markt-Reiters steht – zum leichten Vergleich im Spiel.

## 0.65.248
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Vollscan: Die Absatz-Zähler je Item verwenden eine Hilfstabelle wieder, statt für jedes Item eine neue anzulegen. Der Speicher-Müll je Vollscan liegt in der Test-Nachbildung jetzt bei 10,06 MB (zu Beginn der Nacht 18,5 MB).

## 0.65.247
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Markt-Reiter "Heute": Der Tooltip eines Kauf-Vorschlags zeigt jetzt auch "Lohnt bis" – den höchsten Preis, zu dem sich dieser Kauf noch lohnt (Flippen: Kaufgrenze, Entzaubern: Lohnt bis, Händler: Händlerpreis − 1c). Nur Anzeige.

## 0.65.246
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Markt-Reiter: Fahr mit der Maus über den Kopf, dann steht das Wochentag-Muster je Stufenband da (aus allen Preisen im Verlauf, auch den Scans deiner Gilde): "günstig Mo · teuer Sa", sobald dasselbe Muster 3 Wochen hielt, sonst grau "messe (x von 3 Wochen)".

## 0.65.245
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Markt-Reiter "Heute": Der Tooltip eines Kauf-Vorschlags zeigt jetzt seinen Rang (Gold je Tag je 1g Einsatz) und seinen Weg mit Trefferquote – frei, lernt noch (Fälle von 20) oder gesperrt.

## 0.65.244
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Markt-Reiter: neue Zeile "Treffer je Weg" über der Fusszeile – für Flippen, Sniper, Entzaubern, Herstellen und Händler: grün = frei (Quote und Fälle), grau = lernt noch (Fälle von 20), rot = gesperrt. Beim Darüberfahren steht die Erklärung.

## 0.65.243
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Kopf des Markt-Reiters: Statt eines Preis-Index über alle Waren zeigt die erste Zeile jetzt jedes Stufenband (1-25, 26-45, 46-60): seine Richtung (fällt / steigt / Spitze / ruhig), sobald es genug gemessen ist, sonst grau "messe x/5". Bänder mit erkanntem Aufkauf sind orange markiert, die Summe steht am Ende.

## 0.65.242
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Markt-Reiter, Detail: Für ein Item ohne eigene Preisdaten steht der geteilte Marktwert anderer Spieler als "Netz (andere Spieler)" mit Alter da – als unsicher markiert und nie für Käufe. Tooltip, Preise und Buchhaltung nutzen weiter nur deine eigenen Daten.

## 0.65.241
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Markt-Reiter: Der Kopf sagt jetzt, wann der nächste Vollscan möglich ist ("Vollscan in x Min. möglich" / "jetzt möglich" / "läuft") – öfter scannen gibt bessere Messungen. Nur mit eingeschaltetem Vollscan.
- Der Kopf hat jetzt zwei Zeilen (Markt-Index | Spielrhythmus · Vollscan) – vorher war der Text länger als der Platz und wurde abgeschnitten.

## 0.65.240
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Mit mehr als 4000 Items im Auktionshaus wurde der Marktwert-Speicher alle 10 Minuten geleert und neu gerechnet. Seine Grenze richtet sich jetzt nach deinem letzten Vollscan (+20 %, mindestens 4000, höchstens 20 000), und neue Preise markieren einen Eintrag als veraltet, statt ihn wegzuwerfen. Weniger Speicher-Müll nach dem Vollscan.

## 0.65.239
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Weniger Speicher-Müll nach einem Vollscan (gemessen rund ein Drittel weniger): Das Sortieren langer Tabellen verwendet seine Hilfslisten wieder, und der Verkaufsverlauf legt für Items, die du nie eingestellt hast, keine Wegwerf-Tabellen mehr an.

## 0.65.238
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Der Preisverlauf der Stufenbänder (Testbericht) ist jetzt von Tag zu Tag vergleichbar: Jeder Tageswert wird auf derselben Basis verkettet (vorher wurde ein gleichmässiger Anstieg von 2 % je Tag als 0 % aufgezeichnet). Keine Wirkung auf Preise oder Vorschläge.
- Der Bandverlauf bleibt 120 Tage, damit später ein Monatszyklus messbar ist.

## 0.65.237
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Die Entwickler-Messung langsamer Ereignisse misst wieder (sie lief nie, weil ihre Uhr noch nicht festgelegt war).
- Intern: Die Uhr der Zeitbudgets im Hintergrund ist in der Test-Nachbildung austauschbar (feste Messung). Im Spiel keine Änderung.

## 0.65.236
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Die Zahl der Spieler hinter den Absatz-Daten "alle Spieler" ist eine Untergrenze – sie heisst jetzt "mind. n".

## 0.65.235
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Plan nach längerer Pause:** Nach mindestens 2 Tagen Pause zeigt "Seit deinem letzten Besuch" zusätzlich einen kurzen Plan
  nach denselben Regeln wie "Mein Lager" und "Heute tun": was verkaufen (mit Preis), was kaufen (mit Höchstpreis) und wie viel
  liegen bleiben darf. Nur Anzeige.

## 0.65.234
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Tages- und Wochenzyklen werden gemessen:** Im Hintergrund misst AHSentinel jetzt je Stufenband, ob die Preise zu bestimmten
  Stunden oder an bestimmten Wochentagen üblicherweise höher oder tiefer sind. Nur Messung (Testbericht) – angezeigt oder
  empfohlen wird nichts, bis ein Zyklus über mindestens 3 Wochen bestätigt ist.

## 0.65.233
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gold-Sicherheit:** Sniper-Ziele aus "+" (Schnäppchen unter Händlerpreis oder Entzauberwert) und "Kaufen" in Markt >
  Entzaubern bekommen nie mehr Budget als deine Grenze je Item (10 % deines Golds). Reicht das nicht für ein Stück, wird kein
  Ziel angelegt, und eine Meldung sagt warum.

## 0.65.232
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **"Bevor du gehst":** Ein Knopf im Markt-Reiter (und einmal je Sitzung kurz vor dem Ende deiner üblichen Spielzeit) zeigt die
  3 wichtigsten Schritte: was bis zum nächsten Login an Wert verliert (fallendes Band), was du einstellen kannst (24 Std., wenn
  du länger weg bist) und was liegen bleiben darf. Nur Anzeige – nichts wird ohne deinen Klick gekauft oder eingestellt.

## 0.65.231
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Halte-Risiko:** Fällt ein Stufenband messbar (genug Daten), senkt AHSentinel "Lohnt bis" für Käufe, deren Verkauf länger als
  einen Tag dauert (5 % je Tag bis zu deinem nächsten Login – vorsichtige Annahme, bis gemessen). Bei einer Preisspitze kauft
  es nie zum Halten, und "Mein Lager" sagt "jetzt verkaufen"; bei fallendem Band "vor dem Ausloggen verkaufen". Ohne genug
  Band-Daten ändert sich nichts. Steigende Preise zählen nie als Gewinn.

## 0.65.230
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Stufenbänder werden gemessen:** AHSentinel misst jetzt täglich je Stufenband (1–25, 26–45, 46–60 nach benötigter Stufe), ob
  die Preise fallen, steigen oder eine Spitze haben – aus deinen eigenen Scans, erst wenn ein Band genug Daten hat (5 Tage mit je
  20 Items). Vorerst nur Messung (Testbericht, Schnittstelle für andere Addons); keine Kaufgrenze ändert sich dadurch.

## 0.65.229
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Laufzeit passend zum Spielrhythmus:** Hat AHSentinel deinen Rhythmus gelernt, wählt das Verkaufen-Fenster die Laufzeit vor –
  2 Std., wenn du voraussichtlich noch mindestens 2 Std. spielst, sonst 24 Std. – und sagt warum, mit der Einzahlung beider
  Laufzeiten. Deine eigene Wahl gilt für den Rest der Sitzung. Ohne gelernten Rhythmus ändert sich nichts. Option "Laufzeit vorwählen".

## 0.65.228
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung > Pro Item, Entzauber-Zeilen:** Die Material-Zeilen im Tooltip stehen jetzt unter "Erlös:" – sie zeigen,
  was die Materialien eingebracht haben, nicht den Gewinn.

## 0.65.227
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **"Seit deinem letzten Besuch":** Nach mehr als einem Tag Pause zeigt AHSentinel beim ersten Öffnen einmal, was verkauft
  wurde (netto, aus den Rechnungen), was zurückkam (abgelaufene Auktionen), wie sich die Stufenbänder verändert haben – mit
  Knöpfen für die nächsten Schritte ("Mein Lager", "Heute tun"). Liegen die Rechnungen noch im Briefkasten, steht das da.
  Abschaltbar ("Nicht mehr zeigen" oder in den Optionen).

## 0.65.226
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Absatz pro Tag aus den Daten aller Spieler:** Sobald die gemeinsamen Markt-Tabellen Daten aller GoldSentinel-Spieler
  enthalten (Teil "alle", je Fraktion), nutzt AHSentinel sie als Vorwissen dafür, wie viel sich von einem Item pro Tag verkauft:
  deine eigene Messung zählt immer mehr (Vorwissen = Gewicht von 2 Messungen); ohne eigene Messung gilt vorsichtig die
  Untergrenze aller Spieler. Anzeige "alle Spieler (n), x Tage" im Tooltip und in den Markt-Details. Ohne diese Daten bleibt
  alles wie bisher.

## 0.65.225
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Spielrhythmus:** AHSentinel lernt, wann du ungefähr wieder spielst (aus Logins und Online-Minuten, ab 14 Tagen Daten;
  sonst 1 Tag), und zeigt es im Kopf des Markt-Reiters ("Nächstes Login ~2 Tage (gelernt)"). In den Optionen auch selbst
  einstellbar: automatisch / täglich / einige Tage pro Woche / nur Wochenende. Vorerst nur Information; später hilft es bei der
  Laufzeit und "Bevor du gehst".

## 0.65.224
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Unter Händlerpreis – genaue Zahlen:** eine Rechnung für Schnäppchen, "Heute tun", Markt > Händler und den Sniper-"+". Es
  zählen nur vom Spiel bestätigte Händlerpreise (keine alten Tabellenwerte). Neue Spalte "Menge" = Stücke wirklich unter dem
  Händlerpreis (je Preisstufe; "≥" = mindestens), "Gewinn gesamt" = Summe über genau diese Stücke (vorher Gesamtmenge aller
  Preisstufen, aufgebläht). Das Alter der Preise steht beim Namen; älter als 30 Minuten = grau.
- **"+" -> Sniper-Ziel:** Höchstpreis = Händlerpreis − 1 Kupfer (nie gleich oder darüber), Menge = diese Stücke, Budget = ihr
  Gesamtpreis.
- Kürzen aufs Budget jetzt über die Preisstufen (günstigste zuerst) statt günstigster Preis × Menge.

## 0.65.223
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Schnäppchen > Unter Entzauberwert = Markt > Entzaubern:** Beide Ansichten rechnen jetzt gleich und zeigen dieselben Items
  und Zahlen (geplante Menge, Gewinn gesamt). Der "+"-Knopf legt das Sniper-Ziel bis "Lohnt bis" mit geplanter Menge und Budget
  an – vorher durfte er bis zum vollen Wert minus 1 Kupfer kaufen, also ohne Gewinn.
- **Leere Listen sagen warum:** z. B. "Zurzeit nichts unter dem Entzauber-Wert mit mindestens 20 % Gewinn (geprüft: 41 Items …;
  Preise vom Scan vor 3 Min.)", "Weg Entzaubern ist abgewählt" oder "keine Preise der letzten 2 Std.".
- Für andere Addons: neue Schnittstelle `API.QuietOn()` (ist der Sniper im Ruhemodus?).

## 0.65.222
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Kaufen > Schnäppchen ohne "Marktwert" und "Flips":** Beide Ansichten rechneten gegen den Median der angebotenen Preise statt
  der bezahlten, und ihr Gewinn pro Tag war nicht gemessen – sie zeigten oft gefallene Märkte oder Ladenhüter. Sie sind
  ausgeblendet, bis AHSentinel echte Verkäufe je Item misst. Schnäppchen öffnet jetzt mit "Unter Händlerpreis";
  "Unter Entzauberwert", "Gebote" und der Flipping-Rechner bleiben.

## 0.65.221
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **"Heute tun" erklärt Kürzungen:** Wurde die Menge eines Vorschlags wegen deines Budgets kleiner, sagt die Zeile das in
  einem Satz. Fallen Vorschläge wegen des Budgets weg, nennt eine Tipp-Zeile am Ende, wie viele es sind und wie gross das
  Budget ist. Die Liste bleibt nach Gewinn sortiert.

## 0.65.220
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Deine Vollscans füllen jetzt die gemeinsamen Marktdaten:** nach jedem Vollscan gibt AHSentinel die tiefsten Preise an die
  gemeinsame Markt-Datei weiter – die anderen Addons deiner Gilde (und die Prognosen von AHSentinel) können sie nutzen.
  Gemessen: höchstens etwa 2,4 MB Speicher je Scan, keine längeren Bilder. Der Schalter "Marktdaten teilen" gilt weiter.
- Weniger Speicher je Scan: die weitergegebenen Daten werden wiederverwendet statt jedes Mal neu angelegt.

## 0.65.219
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Ein Aktualisieren-Knopf überall:** Beide AHSentinel-Fenster (Hauptfenster und im Auktionshaus) haben denselben
  Aktualisieren-Knopf an derselben Stelle – oben rechts, direkt links neben Optionen. Klick = aktueller Reiter neu,
  Shift-Klick = alles neu rechnen.

## 0.65.218
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Gemeinsame Markt-Datei auf Version 7 aktualisiert (braucht beim Teilen weniger Speicher). Das Teilen deiner Vollscan-Preise mit
  anderen Spielern bleibt vorerst aus, bis es gemessen innerhalb seiner Speichergrenze liegt.

## 0.65.217
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Eine Rezeptliste am Berufsfenster:** Ist ProfessionSentinel installiert, zeigt AHSentinel sein eigenes Gewinn-Fenster neben
  dem Berufsfenster nicht mehr – ProfessionSentinel ist das Berufs-Addon und zeigt dieselben Zahlen von AHSentinel.
  "Materialien als Einkaufsliste" und "Nur was mir fehlt" bleiben über ProfessionSentinel erreichbar. Ohne ProfessionSentinel
  bleibt alles wie bisher.

## 0.65.216
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Heute tun – eine Rangfolge für alle Wege:** Wird dein Gold-Budget (25 %) auf Kauf-Vorschläge verteilt, zählt jetzt Gold je Tag
  je 1g Einsatz mal Sicherheit des Wegs (gemessene Trefferquote; solange ein Weg noch lernt, vorsichtig 60 %). Was schneller und
  sicherer Gewinn bringt, bekommt das Budget zuerst. Die Liste selbst bleibt nach Gewinn sortiert.

## 0.65.215
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Warnschutz funktioniert in allen Wegen (Spieler-Meldung):** "Preis anpassen" schlägt jetzt den kleinsten Preis vor, der NICHT
  wieder warnt – bei Regeln nach 5 % Gebühr (Händler, dein Einkaufspreis, Entzaubern) mit der Gebühr (z. B. Einkauf 9s 19c ->
  9s 68c), nach oben auf das Raster des Items gerundet. Vorher kam dieselbe Warnung endlos wieder. Der Text rechnet mit echten
  Zahlen nach der Gebühr: "Nach 5 % Gebühr bekommst du 8s 73c – das ist 46c unter deinem Einkaufspreis (9s 19c). Verlust: ~1s 84c."
- **"Trotzdem einstellen" stellt zuerst ein:** direkt im Klick, vor dem Schliessen des Fensters. Sperrt WoW es trotzdem, stellt
  der nächste Klick auf "Einstellen" dieses Item zu diesem Preis ohne erneute Warnung ein.

## 0.65.214
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Ruhiger nach dem Vollscan:** Nach einem Scan fragte AHSentinel den Server auf einmal nach Tausenden noch unbekannter Items –
  das gab Ruckler bis zu einer halben Sekunde. Neue Item-Anfragen sind jetzt auf 200 je Sekunde begrenzt; bekannte Items nie.
  Namen neuer Items erscheinen etwas später.

## 0.65.213
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Kaufgrenze – Risiko wählen:** Neue Einstellung "vorsichtig / normal / mutig". Sie ändert nur die Sicherheitsmarge von "Lohnt
  bis": normal = wie bisher (ohne Wahl ändert sich nichts), vorsichtig = 10 Punkte mehr Marge, mutig = 5 Punkte weniger (nie
  unter 5 %). Mindestgewinn und höchstens 90 % des Werts gelten immer. Der Tooltip zeigt ein Beispiel für ein Teil zu 10s.

## 0.65.212
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper während des Vollscans gesperrt:** Solange ein Vollscan läuft, ist der Knopf "Sniper-Modus" grau, und Umschalten (Knopf,
  Kopfzeile, /ahs sniper) hat keine Wirkung – der Tooltip nennt die Restzeit. Die Sperre endet mit dem Scan, beim Abbruch, wenn
  das AH zu ist, spätestens nach 120 Sekunden.
- **Sniper sucht nach dem Scan sofort wieder:** Preisprüfungen im Verkaufen-Reiter, die du nicht angeklickt hast (Serie,
  Unterbietung, erneute Prüfung), belegen den Such-Platz nicht mehr, solange der Sniper an ist – sie warten, bis er aus ist.
  Eine angeklickte Preisprüfung geht weiter vor.

## 0.65.211
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper – verlorene Wettläufe:** Sind mehrere Käufe offen und meldet der Server "Angebot nicht gefunden" (ein anderer Käufer
  war schneller), gehört das jetzt zum jüngsten Kauf (in der letzten Sekunde gesendet). Dieses Angebot wird nie nochmals
  gesendet; ältere offene Käufe bleiben offen, bis Server oder Gold sie bestätigen.
- **Sniper-Status:** "Kauf bestätigt (Server meldete kurz einen internen Fehler – ohne Folgen)" verdeckt keinen wartenden Treffer
  mehr. "Treffer! … zum Kaufen" steht vorne, der Hinweis hängt hinten an.

## 0.65.210
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Berufsfenster – Einkaufsliste (Spieler-Meldung):** "Materialien als Einkaufsliste" und "Nur was mir fehlt" meldeten Erfolg,
  aber es erschien keine Liste, wenn der Berufsname leer oder zu lang war. Der Listenname ist jetzt "Berufe" (bzw. gekürzt),
  und Erfolg gibt es nur, wenn die Liste wirklich Einträge hat – sonst siehst du den echten Fehler.
- **Entzauber-Fenster leer, obwohl Teile in der Tasche sind:** Kannte das Spiel ein Teil noch nicht, blieb das Fenster leer, bis
  sich die Tasche änderte. Jetzt zeichnet es neu, sobald die Iteminfo da ist, und solange Teile ausgelassen sind, steht der
  Grund da ("1 Teile ausgelassen: Iteminfo noch nicht geladen 1"). Das Diagnose-Protokoll nennt jedes Teil mit Grund (DE-LEER).

## 0.65.209
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper – schneller zum nächsten Kauf:** Nach einem bestätigten Kauf schickt der Server die aktualisierte Angebotsliste von
  selbst. Ist sie vollständig, nutzt AHSentinel sie jetzt sofort (dieselben Prüfungen wie bei einer Suche: Max-Preis, Budget,
  eigene und tote Angebote) – der nächste Treffer ist ohne Warten auf die nächste Suche kaufbar. Der Sniper-Bericht zeigt
  "Bestätigung -> nächster Kauf" (Durchschnitt und längste).

## 0.65.208
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper – ein Klick, ein Kauf (Spieler-Wunsch):** Ein grosser Knopf "Kaufen" über die ganze Sniper-Spalte. Er sagt, was er
  kauft: "Kaufen: 1× Schultern … für 8s 50c" (nur der Name wird gekürzt, nie der Betrag). Waren brauchen nach Blizzards Regeln
  zwei Klicks, und der Knopf sagt das: "Preis anfragen (12× Leinenstoff)" -> "Kaufen bestätigen: 12× für 3s 00c". Ohne Treffer
  ist er grau mit Grund und startet keine versteckte Suche. Zustände ohne Blinken: bereit, wartet auf den Server (gedämpft),
  kein Treffer (grau), gekauft (kurz grün). Dieselben Schutz-Prüfungen wie beim Mausrad (Max-Preis, Budget, ein Einzelkauf
  zur Zeit, Server bereit); ein Doppelklick kauft nicht doppelt.
- **Kaufen mit:** Neue Einstellung "Mausrad + Knopf" (Standard, alles wie bisher) oder "nur Knopf" (Mausrad und Tasten bleiben
  frei für die Kamera).

## 0.65.207
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Einstellen vom Spiel gesperrt (ADDON_ACTION_BLOCKED):** Sperrt WoW ein Einstellen, sagt AHSentinel jetzt "Einstellen braucht
  einen Klick – bitte nochmal auf Einstellen klicken" statt "Wird eingestellt …" und sperrt den Knopf nicht mehr 5 Sekunden.
  Der nächste Klick stellt ein. Das Diagnose-Protokoll merkt sich den Weg (Knopf, Serie, Heute, Neu einstellen) und die
  Version, damit die Ursache gefunden wird.
- **Ruhemodus beim Snipen:** Auch schon begonnene Hintergrund-Rechnungen halten an, solange der Sniper sucht, und laufen danach
  an derselben Stelle weiter (nichts geht verloren, die 30-Minuten-Grenze bleibt).

## 0.65.206
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Wege selbst wählen:** In den Einstellungen lassen sich Entzaubern, Herstellen, Flippen und Händler abschalten (grün = an,
  grau = aus, Standard alle an). Ein abgeschalteter Weg erscheint nirgends als Kauf- oder Herstell-Vorschlag – nicht in
  Heute tun, im Markt-Reiter, beim Sniper oder im Tooltip "Lohnt bis".
- **Verzauberkunst automatisch:** Entzaubern zählt nur, wenn eine deiner Figuren auf diesem Server die nötige Verzauberkunst
  für das Teil hat. Jede Figur merkt sich ihre Fertigkeit beim Einloggen.
- **Sicherere Entzauber-Grenze:** Hält kein Kaufpreis den Mindestgewinn, gibt es jetzt gar kein "Lohnt bis" – vorher rechneten
  einige Stellen ersatzweise mit dem vollen Netto-Wert.
- Gemeinsame Markt-Datei auf Version 6 aktualisiert.

## 0.65.205
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Berufsfenster – beide Richtungen:** Verliert ein Rezept Geld, weil deine Zutaten roh mehr wert sind, sagt die Zeile
  "bester Weg" das jetzt mit Betrag: "kein Gewinn – Zutaten roh verkaufen (+1s 18c)". Dieselbe Rechnung wie der Gewinn
  darüber (eigene Zutaten zählen mit ihrem Verkaufserlös, fehlende über die Preisleiter, Händlerware zum Händlerpreis).
  Rezepte nur mit Händler-Zutaten zeigen weiter "kein Weg mit Gewinn".

## 0.65.204
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Markt-Reiter – neue Ansicht "Mein Lager":** alles, was dir in diesem Auktionshaus gehört (Taschen und Bank aller deiner
  Figuren auf diesem Server, Post wie beim letzten Öffnen des Briefkastens, laufende Auktionen), in einer Liste: Menge je Ort, Wert jetzt nach Gebühren (bester Weg:
  verkaufen, entzaubern oder Händler – dieselbe Zahl wie überall), der beste Weg und ein Knopf (Einstellen / Entzaubern /
  Händler / Behalten). Was im Preis fällt, steht oben, im Tooltip "Warten bis morgen kostet etwa …". Ohne Scan der letzten
  30 Minuten ist der Wert grau mit "Scan nötig". Der Tooltip zeigt die Herkunft: wie viele du gekauft hast und den
  Einstand je Stück aus der Buchhaltung, sonst "Beute oder ohne Kaufpreis".

## 0.65.203
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauber-Tooltip – deine echten Ergebnisse:** Der Abschnitt "Materialien" zeigt neben den Vorgabe-Chancen, was deine
  eigenen Entzauberungen dieser Gruppe wirklich ergaben ("bei dir (659)": Staub 73 %, Essenz 22 %, Splitter 6 %); mit
  weniger als 30 eigenen zählen die der Gilde ("Gilde (n)") oder es steht "noch n/30". Letzte Zeile "Ø je Entzauberung
  … netto" – dieselbe Zahl wie der Entzauberungswert oben. Der Rest des Tooltips bleibt unverändert.

## 0.65.202
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufen – ehrlicher Vorschlag:** Lohnt Entzaubern mehr als Verkaufen, sagt das eine grüne Zeile ("Entzaubern lohnt
  mehr (≈ 11s18 statt 8s55) – nicht einstellen"), und Einstellen fragt nach. Liegt der Markt unter deinem Mindestpreis,
  steht klar "Verkauf zurzeit mit Verlust: Markt 9s, dein Mindestpreis 11s41 – warten oder Händler (6s59)". Dein
  Mindestpreis wird nie durch Runden unterschritten. Auf "Gewinn erwartet" zeigt der Tooltip die Rechnung in einem Satz.
- Gemeinsame Marktdatei auf Version 5.

## 0.65.201
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Meine Auktionen – "Nächste unterbotene abbrechen" geht auch, solange Preise unbekannt sind:** Statt "keine
  unterbotenen" stösst der erste Klick die Preisprüfung dieser Items an ("Preise werden noch geprüft – gleich nochmals");
  der nächste Klick bricht eine unterbotene ab. Der Kopf zeigt "? unterboten" statt "0", solange Preise geprüft werden.
- Status "liegen lassen" kurz; der Tooltip sagt warum ("unterboten um 2c – Abbrechen kostet die Gebühr"). Die Fusszeile
  erscheint nur bei gefilterter Liste (sonst wiederholte sie die Kopfzeile).

## 0.65.200
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Der Sniper blockiert dich nie:** Verkaufst oder suchst du selbst in einem anderen Reiter, pausiert der Sniper seine
  eigenen Suchen 30 Sekunden ("Sniper pausiert – du verkaufst gerade, weiter in n s"); ein wartender Treffer bleibt mit
  dem Mausrad kaufbar.
- **Sniper-Fenster:** Zielnamen und Stand nicht mehr abgeschnitten ("140/1000 · Rest 7g81", der Rest im Tooltip); die
  Zeile "Heute" passt in eine Zeile und nennt offene Treffer, damit die Zahlen aufgehen ("1 offen"); Dezimalkomma.
- **Jeder "Interner Auktion-Fehler" wird erklärt** im Sniper-Bericht (letzte Anfrage, offene Käufe, Server bereit vor
  dem Senden). Wird der Kauf gleich danach bestätigt, ist es kein Fehlschlag: Der Sniper meldet "Kauf bestätigt (Server
  meldete kurz einen internen Fehler – ohne Folgen)". Direkt nach einem Kauf sendet AHSentinel 0,3 s keine andere eigene
  Anfrage.

## 0.65.199
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Marktdaten-Netz (erster Schritt):** AHSentinel bringt jetzt die gemeinsame GoldSentinel-Marktdatei mit und empfängt
  Marktdaten anderer GoldSentinel-Nutzer (nur Preise und Mengen, keine Namen, keine Abfrage). Einstellung "Marktdaten
  teilen" (Standard an) schaltet es aus. Deine eigenen Vollscans gibt AHSentinel noch nicht weiter – das käme jetzt in einem
  einzigen Rechenschritt und würde ruckeln; es folgt, sobald es in kleinen Portionen geht. Fremde Werte überschreiben nie
  deinen eigenen Scan und lösen nie einen Kauf aus.
- **Entzaubern: fairer Einstand je Material.** Der Einstand eines entzauberten Teils wird jetzt nach dem verteilt, was eine
  Entzauberung dieser Gruppe erwartungsgemäss bringt – nicht nur nach dem, was diese eine zufällig ergab. Glück oder Pech
  steht als eigene Zeile "Entzauber-Ausbeute" in der Buchhaltung und zählt zum Handelsgewinn. Die Summen gehen auf den
  Kupfer auf. Gilt nur für neue Entzauberungen; ältere Buchungen bleiben, wie sie sind.

## 0.65.198
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Der Rechenkern lernt schneller – ohne Einbussen:** Aus den Vollscans, die ohnehin laufen, werden fremde
  Einzelauktionen zu Lernfällen (vorzeitig weg oder noch da, unterboten oder nicht). Ob "weg" "verkauft" heisst, wird an
  deinen eigenen Auktionen je Warengruppe geeicht – keine pauschale Annahme. Dieser Weg hat eine eigene Prüfung und
  dient erst als Vorwissen, wenn er seine Grundlinie schlägt. Keine zusätzlichen Server-Anfragen, kein Ruckeln.
- **Die Gilde lernt mit:** Fall-Zähler (je Warengruppe, Preisstufe und Tag – keine Namen, keine Einzelfälle) werden mit
  Gildenmitgliedern mit AHSentinel geteilt; nur neue Fälle zählen, fremde Zähler als eigener Topf mit eigener Prüfung.
- Vorwissen-Tabellen von aussen lassen sich jetzt je Zelle laden; ohne sie läuft alles wie bisher.

## 0.65.197
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Ruhemodus (Standard an):** Solange der Sniper an und das Auktionshaus offen ist, arbeitet nur der Sniper.
  Hintergrund-Rechnungen (Prognosen, Zwischenspeicher, Ketten, Markt-Tabellen, Lernen) warten – nach 30 Minuten laufen
  sie in kleinen Schritten trotzdem. Keine selbstständigen AH-Anfragen ausser dem Sniper: Hintergrund-Preisprüfung,
  automatisches Aktualisieren von Meine Auktionen, Wächter und Scan warten, bis der Sniper aus oder das AH zu ist
  (Scan-Knopf grau mit Grund). Was du selbst anklickst, geht weiter vor. Es geht nichts verloren.
- **Ziele ohne Treffer seltener gesucht:** Im Ruhemodus wird ein Ziel, das seit 10 Minuten kein Angebot zum Max-Preis
  oder darunter hatte, höchstens alle 30 Sekunden gesucht (keines fällt heraus); der Tooltip des Ziels sagt es.
- Sniper-Fenster: "Ruhemodus: n Aufgaben pausiert" (Tooltip mit Liste). `/ahs ruhe an|aus`.

## 0.65.196
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper: "Interner Auktion-Fehler" kostet keine guten Angebote mehr:** Der Fehler heisst "zu schnell gesendet", nicht
  "weg". Das Angebot bleibt kaufbar; nach 2 Wiederholungen ohne Kauf (Fehler oder keine Antwort) 30 Sekunden Pause
  ("Pause 30 s"), nie 10 Minuten. Behoben: Ein Fehler nach einem schon abgelehnten Kauf wurde übersehen.
- **Sniper-Status:** "Server noch nicht bereit (0,4 s) – Raste wartet" zeigt, wie lange der Server schon beschäftigt ist.
- **Ruhigeres Snipen:** Solange der Sniper scharf und das Auktionshaus offen ist, warten Prognose-Auswertung und
  Zwischenspeicher (höchstens 2 Minuten). Der Sniper-Bericht zeigt die Rechenzeit je Sniper-Ereignis und je Fenster-Neuaufbau.

## 0.65.195
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Angebotsliste aufgeräumt:** Ein gekauftes Angebot zeigt 1 Sekunde "gekauft", ein sicher verschwundenes 1 Sekunde
  "weg" – dann verschwindet die Zeile. Bei "Interner Auktion-Fehler" oder ohne Antwort bleibt die Zeile stehen ("Fehler –
  nochmal" bzw. "keine Antwort") und ist weiter kaufbar. Unter der Liste: "gekauft n · weggeschnappt n · ohne Antwort n".

## 0.65.194
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper kauft verlässlicher:** Gekauft wird nur, wenn der Server bereit ist, und standardmässig nur ein Einzelkauf zur Zeit
  (`/ahs einzelkauf aus` im Entwickler-Modus schaltet das ab). Während ein Kauf auf Antwort wartet, sucht der Sniper nicht –
  so verwirft der Server weniger Käufe ("Interner Auktion-Fehler").
- **Zähler = Server:** Gezählt wird nur ein Kauf, den der Server bestätigt. Ist Gold weg, aber die Bestätigung fehlt, bleibt
  der Betrag im Budget reserviert, zählt aber nicht als gekauft.
- **Keine 8-Sekunden-Pausen:** Bleibt eine Suche ohne Antwort, sucht der Sniper nach der gemessenen Antwortzeit neu (meist
  nach 2 s).
- **Beträge:** immer lückenlos, z. B. "2g 00s 64c" statt "2g 64c".
- **Meine Auktionen:** "Nächste unterbotene abbrechen" ist nur aktiv, wenn es eine unterbotene Auktion gibt; Meldungen stehen
  in eigener Zeile über der Liste.

## 0.65.193
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Fenster:** Die Eingabefelder "Stufe ab/bis" sind breiter, und zu lange Platzhalter werden kleiner geschrieben statt
  abgeschnitten. "n Einträge" über der Angebotsliste liegt nicht mehr unter dem Knopf "Preisverlauf".

## 0.65.192
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper rücksichtsvoll:** Ersetzt deine eigene Suche (oder die eines anderen Addons) eine Sniper-Suche, wartet der Sniper
  1 Sekunde, bevor er neu sucht. Höchstens 3 sofortige Wiederholungen in 10 Sekunden.
- **Sniper mit mehreren Zielen:** Auch gesendete, noch unbestätigte Käufe eines anderen Ziels und Käufe eines gelöschten Ziels
  senken den Rest eines Ziels nicht mehr.

## 0.65.191
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Zielzeile:** kurz und ganz lesbar ("15/1000 · 6 warten · Rest 3g92"), die ganze Zeile steht im Tooltip.
  Vom Server abgelehnte Käufe zählen nicht mehr bei "warten".
- **Sniper-Bericht:** Ein Treffer, der ohne eine einzige Raste verschwand, heisst "keine Raste" statt "andere schneller".
  Die Prüfung "reihum" zählt Lücken über eine Pause (Vollscan, eigener Klick) nicht mehr mit.

## 0.65.190
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Selbsttest hängt nie:** `/ahs testroutine sniper` (Entwickler) endet spätestens nach 5 Minuten. Bleibt die Frage
  zum Testkauf 30 s ohne Antwort, geht es ohne Testkauf weiter. Das Testfenster zeigt "Schritt 2 von 4 · wartet noch
  höchstens 110 s".
- **Sniper-Bericht:** Die Zeilen "Geld je Ziel" und "Einzelkäufe" stehen immer im Bericht – ohne Käufe mit "keine", sonst
  auch aus der letzten echten Sniper-Sitzung. Nach einem eigenen Klick im Auktionshaus misst der Bericht, was den Sniper
  aufhielt.
- **Sniper mit mehreren Zielen:** Kauft ein Ziel, sinkt der Rest der anderen Ziele nicht mehr mit. Gold, das keinem Ziel
  gehört, wird im Rest abgezogen und genannt ("… andere Ausgaben mitgerechnet").
- **Sniper schneller weiter:** Verwirft der Server eine Suche oder ersetzt deine eigene Suche im Auktionshaus sie, sucht der
  Sniper sofort neu, statt 8 Sekunden zu warten.
- **Sniper-Meldung:** Sind alle passenden Angebote schon gesendet, steht "Alle passenden Angebote gesendet – 6 warten auf
  Antwort" statt "Nichts Passendes unter deinem Max-Preis".
- **Selbsttest:** Während der Testroutine startet kein echter Markt-Scan mehr (seine Daten bleiben so vollständig erhalten).
- **Buchhaltung:** Vergangene Verkäufe seit deinem Stichtag gehen nicht mehr verloren, wenn viele neue Buchungen dazukommen
  (bisher fielen ab 4000 Buchungen die ältesten weg – Erlös und Verkäufe sanken rückwirkend).
- **Fehlbestand:** Bucht das Addon Ware aus, die nirgends mehr ist (Taschen, Bank, Briefkasten, Auktionen), sagt es das
  jetzt im Chat – mit Menge und Einstand. Kommt die Ware zurück, wird es zurückgenommen.

## 0.65.189
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper hängt nie am Markt-Scan:** Bricht die Auswertung eines Markt-Scans mit einem Fehler ab, wartet der Sniper nicht
  mehr endlos ("wartet: Markt-Scan läuft"), sondern sucht sofort weiter.

## 0.65.188
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Meine Auktionen – Abbrechen-Empfehlung:** Das Addon rechnet jetzt mit dem Preis, zu dem es wirklich neu einstellen würde
  (nie unter deinem Mindestpreis). Liegt der Markt unter deinem Mindestpreis, heisst es "liegen lassen" statt "Abbrechen
  lohnt sich" – du verlierst keine Einstellgebühr mehr für ein Neu-Einstellen zum selben Preis.

## 0.65.187
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper nach dem Vollscan:** Während ein Vollscan läuft, zeigt der Sniper ruhig "Vollscan läuft – noch ca. 30 s (Sniper
  wartet)". Ist der Vollscan fertig, sucht der Sniper sofort weiter. Hält ein Vollscan länger als 2 Minuten, sucht der
  Sniper trotzdem weiter.
- **Sniper zählt richtig:** Ein Kauf wird nie doppelt gezählt, auch wenn der Server die Bestätigung erst spät schickt.
  Wieder mehrere Käufe gleichzeitig (wie in 0.65.183). Ein abgelehntes Angebot prüft die nächste Suche neu.
- **Heute-Zeile im Sniper:** "Heute: 162 Treffer · 67 mit Kauf · 95 verpasst · gekauft 70 Stück" – Treffer und Stück
  getrennt.

## 0.65.186
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper schickt keinen Kauf doppelt:** Ein schon gesendetes oder gekauftes Angebot bleibt auch nach der nächsten Suche
  "gesendet" bzw. "gekauft" – die nächste Raste nimmt das nächste Angebot. Bisher wurde dasselbe Angebot nach jeder Suche
  nochmals gekauft und vom Server abgelehnt.

## 0.65.185
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper bei Ausrüstung:** Der Server nimmt Einzelkäufe nur nacheinander an. Der Sniper schickt darum nur noch einen Kauf
  zur Zeit und wartet kurz auf die Antwort (Status "warte auf Antwort …"), statt Dutzende Käufe gleichzeitig zu senden, die
  der Server verwirft. Stand "5/1000 gekauft · 1 wartet auf Antwort · Rest 9g60" statt "(+67 gesendet)".

## 0.65.184
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Post abholen:** Post, die noch lädt ("Rufe Daten ab"), wird nicht mehr übersprungen – das Abholen wartet kurz und macht
  von selbst weiter, statt "Keine Auktionspost" zu melden. Die gleiche Meldung erscheint nicht mehr mehrfach in der
  Bildschirmmitte. Liegen mehr als 50 Posten im Briefkasten, sagt das Addon es.

## 0.65.183
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper zählt Käufe richtig:** Gelingen viele Käufe schnell hintereinander, zählt der Sniper sie jetzt über das abgebuchte
  Gold – auch wenn der Server keine Bestätigung schickt. Gelungene Käufe gelten nicht mehr als gescheitert, und das Item wird
  deswegen nicht mehr pausiert.
- **Budget hält:** Zusätzlich prüft der Sniper das Budget gegen dein echtes Gold seit dem ersten Kauf – er kauft nie über
  das Budget.

## 0.65.182
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Aufräumen vorbereitet:** Eine neue Prüfung geht alle Fenster und Reiter durch (Klassisch und Modern, 100 % und 130 %) und
  findet Überlappungen, abgeschnittene Texte, Knöpfe ohne Funktion und veraltete Texte. Die Funde werden danach bereinigt.

## 0.65.181
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper hängt nicht mehr:** Hält ein anderer Teil des Addons (Preisprüfung, Wächter, Einkauf) die Suche länger als 10
  Sekunden fest, wird die Sperre gelöst und der Sniper sucht weiter. Die Statuszeile nennt, wer gerade sperrt.

## 0.65.180
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Herstellungs-Ketten eingeschaltet:** "Heute tun" schlägt jetzt vor, was sich herzustellen lohnt – z. B. "Stelle 12x Braune
  Leinenhose her (+60c je Stück)" – samt Zwischenprodukten (Leinenstoff -> Ballen -> Hose -> entzaubern). Nur mit mindestens
  20 % Gewinn, nie mit Verlust.
- **Eine Zahl:** Die Ketten rechnen jetzt genau wie "Beste Rezepte" (gleicher Weg, gleicher Gewinn).

## 0.65.179
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper kauft mit weniger Rasten:** Solange ein Kauf zum Server unterwegs ist, startet eine weitere Raste keine neue
  Preisprüfung mehr (die hat den laufenden Kauf überholt). Scheitert ein Kauf, fragt die nächste Raste gleich eine kleinere
  Menge an.
- **Keine falsche Verlust-Warnung bei Zutaten:** Ist ein Sniper-Ziel Zutat eines deiner Rezepte (z. B. Leinenstoff), steht statt
  "jeder Kauf verliert" grau "Zutat für deine Rezepte – Gewinn siehe Gewinn-Fenster".

## 0.65.178
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper wieder schnell:** Ein abgebrochener Kauf (Preis gestiegen, Angebot weg) bremst die Suchen nicht mehr. Nach einem
  echten Server-Fehler ist der Sniper nach 10 Sekunden wieder im vollen Takt. Die Statuszeile sagt in Worten, warum er wartet,
  und wie viele Ziele aktiv sind.
- **Weniger verlorene Duelle:** Ist der Preis bis zur Bestätigung gestiegen, bricht der Sniper nicht mehr ab und sucht
  neu, sondern die nächste Raste fragt sofort eine kleinere Menge an. Die volle Menge bleibt dein Ziel. Gekauft wird
  weiterhin nur per Raste/Taste und nie über deinem Max-Preis.
- **Einkauf, Knopf X:** setzt Suche, Filter, Kategorie und die Liste zurück, schliesst das Favoriten-Menü und ruckelt nicht
  mehr. Ist nichts zurückzusetzen, ist X grau.

## 0.65.177
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzaubern-Tooltip:** Die Materialien stehen wieder einfach da, nach der WoW-Forever-Vorgabe – z. B. "1–2 Visionenstaub
  75 %" mit dem Preis je Stück. Keine Rechenwege mehr ("× Ø", "Scan"); deine eigenen Entzauberungen rechnen weiter im
  Hintergrund mit.
- **Test- und Messfunktionen nur noch für die Entwicklung:** Testroutine, Selbsttest, Selbstkontrollen, Diagnose-Protokoll
  und Zeitmessungen laufen bei normalen Spielern nicht mehr – weniger Rechenzeit und Speicher.

## 0.65.176
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Abnahme ausführlicher (`/ahs testroutine sniper`):** Am offenen Auktionshaus beobachtet der Test jetzt deine
  eigenen Ziele (ohne Ziele ein Testziel) und misst: Takt (Suchen pro Minute gegen die Server-Grenze 90), ob alle Ziele
  reihum drankommen, ob Treffer stimmen (nur bis zum Max-Preis, golden markiert), Geld-Sicherheit (nichts gesendet, beim
  Testkauf Gold vorher − nachher = gebuchter Preis), Pausen (Sniper sucht danach von selbst weiter), verpasste Treffer und
  Ruckeln (kein Bild länger als 33 ms). Ganz oben im Bericht steht das Ergebnis in wenigen einfachen Sätzen.
- Es wird weiterhin nichts ohne deine Raste/Taste gekauft.

## 0.65.175
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Tempo gemessen:** Jede Sniper-Sitzung (vom Einschalten bis zum Ausschalten) wird gemessen – Suchen, Ø und höchste
  Suchen pro Minute, Anzahl Ziele – nur echte Sniper-Suchen, nie die Testroutine. Der Testbericht zeigt die letzte Sitzung.
  Der Text in der Zeile ist kürzer ("vor 12 s").
- **"Heute tun":** Eine "Preis gefallen"-Zeile erscheint nur, wenn sich das Verkaufen jetzt wirklich lohnt (mindestens 1s und
  mehr als warten).

## 0.65.174
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper prüft ALLE Ziele:** Jedes Ziel der Liste wird reihum gleich oft gesucht, so schnell wie der Server erlaubt (vorher
  wurde ein Ziel mit Treffern viel öfter gesucht, die anderen selten). Jede Zeile zeigt "geprüft vor x Sek."; eine Zeile mit
  wartendem Treffer ist golden markiert. Kaufen weiter nur per Klick; Budget und Max je Zeile gelten. Test T727.

## 0.65.173
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung:** Der Tooltip über "Gewinn" zeigt jetzt genau vier Zeilen – Erlös, Eingesetzt, Gebühren, Gewinn – mit denselben
  Zahlen wie der Kopf. "Gewinn %" ist einfach Gewinn ÷ Eingesetzt dieser Zeile; enthält die Zeile Stücke ohne Einkaufspreis,
  steht "–" (der Tooltip sagt, wie viele). Gewinn und % haben nie verschiedene Vorzeichen.
- **"Heute tun":** Zeilen, die sich als "nicht mehr lohnend" herausstellen, werden nicht mehr gezeigt; der Flip-Teil rechnet in
  kleineren Schritten.
- Vollscan: langsame Ereignis-Aufrufe von AHSentinel werden jetzt gemessen und beim längsten Bild genannt (um das restliche
  Ruckeln zu finden).

## 0.65.172
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Markt-Reiter einfacher:** Sichtbar sind nur noch "Heute" und "Entzaubern" – Flippen, Händler, Lücken, Überfüllt und Trends
  sind mit deinen eigenen Daten noch nicht belegt und ausgeblendet (Option "Markt: alle Ansichten (Experten)"). Oben ein Satz:
  hier steht nur, was sich mit deinen Daten lohnt. Test T723.
- **Entzaubern:** Gruppen, die du noch nicht gemessen hast, werden aus deinen eigenen Entzauberungen hochgerechnet (alle
  gemessenen Gruppen zusammen, höchstens +10 %, ab 100 Entzauberungen) und grau markiert "hochgerechnet aus n eigenen
  Entzauberungen". Test T724.
- **"Heute tun":** nach dem Kürzen der Mengen wieder nach Gewinn sortiert; rechnet in kleineren Schritten (weniger Ruckeln).
  Schnittstelle "Lohnt bis" liefert denselben Wert wie der Tooltip (auch für Händler/AH-Weg). Beste Rezepte werden innerhalb
  von 2 Sekunden nicht doppelt gerechnet. Test T725, Korrekturen in der Testroutine.

## 0.65.171
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Weniger Ruckeln nach dem Vollscan:** Am Ende des Scans wurde der Speicher ALLER Addons zweimal im selben Bild gemessen (mit
  grossen gespeicherten Daten mehrere 100 ms). Das passiert jetzt nur noch im Tempo-Test. Test T721.
- **Selbstkontrolle Gold:** Auktionshaus- und Briefkasten-Sitzungen messen das Gold jetzt auch direkt (Anfang/Ende); Geld am
  offenen Auktionshaus landet nicht mehr bei einem Händler-Besuch, der nicht sauber geschlossen wurde. Test T719.
- Selbstkontrolle: Entzaubern zählt nicht mehr als "Herstellen ohne Rezept" (der Zaubername steht dabei); die Tagesbilanz nimmt
  1 % vom Umsatz wie die Buchhaltung; der Entzaubern-Knopf nennt, was er verdecken würde, und probiert andere Plätze. Test T720.
- Testroutine: vorher ein deutlicher Hinweis im Chat (etwa 2 Minuten, bitte nichts tun), eine Erinnerung, wenn du währenddessen
  Briefkasten oder Auktionshaus öffnest, und das längste Bild im Bericht. Test T722.

## 0.65.170
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **"Heute tun", Gold-Sicherheit:** Ein einzelner Kauf-Vorschlag nimmt höchstens 10 % deines Golds; solange ein Weg noch lernt
  (keine eigenen Fälle), wird nur eine kleine Probe vorgeschlagen. Neue Selbstkontrolle. Test T718.
- **"Heute tun" folgt deinem besten Weg:** Zutaten einer lohnenden Herstellungs-Kette, die du kannst (z. B. Ballen und Faden für
  eine Hose), werden nicht mehr zum Verkauf vorgeschlagen; Teile, die entzaubert mehr bringen, bekommen "Entzaubern" statt
  "beim Händler verkaufen"; die Zahl ist jetzt der Gewinn (nicht der Erlös), mit einem kurzen Satz beim Zeigen. Test T717.
- **Buchhaltung:** "Gewinn %" der Entzauber-Gruppen zählt wieder nur gekaufte Stücke (keine 477 % mehr); der Tooltip erklärt
  den Teil ohne Einkauf. Test T715.
- **Gewinn-Fenster:** kein "Händler zahlt mehr: 0c" und kein "bester Weg: Händler", wenn der Händler das Teil nicht kauft und
  jeder Weg Verlust macht – dort steht "kein Weg mit Gewinn". Test T716.

## 0.65.169
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufen-Fenster:** "Gewinn erwartet" zieht jetzt ab, was dich die Ware gekostet hat (Durchschnitts-Einstand deines Lagers).
  Vorher stand der ganze Erlös als Gewinn da. Zeig auf die Zeile für einen kurzen Erklär-Satz. Neue Selbstkontrolle. Test T714.
- **Sniper, neues Ziel:** Menge leer = 1000, Budget leer = 5g, den Höchstpreis trägst immer du ein (kein automatischer Preis).
  Bestehende Ziele bleiben unverändert. Test T713.

## 0.65.168
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper, Gold-Sicherheit:** Eine Zahl ohne Einheit bei "Max/Stück" (und anderen Höchstpreisen beim Kaufen) ist jetzt KUPFER –
  "22" ist 22c, nicht 22g. Budgets bleiben Gold ("6" = 6g). Preis-Felder beim VERKAUFEN brauchen eine Einheit ("13" ist rot
  "Einheit fehlt", Einstellen gesperrt, bis 13s dasteht). Ein Höchstpreis über 50 × Marktwert fragt nach (Tippfehler?). Test T710.
- **Sniper, Gold-Sicherheit:** Der bestätigte Server-Preis wird jetzt als Durchschnitt je Stück geprüft (Gesamt ÷ Menge). Über
  deinem Max kauft der Sniper nicht und sucht neu – dann nimmt er nur die Stück innerhalb deines Max. Neue Selbstkontrolle
  "Sniper-Kauf ≤ Max". Test T711.
- **Beste Rezepte:** Die Liste konnte leer bleiben ("Noch keine Preise") – behoben; ohne Angebotsliste gilt der normale Preis.
  Neue Selbstkontrolle: Liste leer, obwohl ein Scan jünger als 1 Std. ist. Test T712.
- **Verkaufen:** Die Zeit-Schätzung im Tooltip nutzt jetzt deinen Platz in der Warteschlange: Angebote billiger als du plus deine
  Stück, beim üblichen Absatz ("schnell (~2 Std.)" statt "langsam (~13 Std.)", wenn du vorne stehst). Mit Shift erklärt ein
  kurzer Satz die Zahl. Neue Selbstkontrolle: vorhergesagte vs. echte Verkaufsdauer deiner Auktionen. Test T709.

## 0.65.167
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung, Herstellen:** Ein Herstellen wurde nur gebucht, wenn das Rezept schon im Zwischenspeicher von "Beste Rezepte"
  stand. Sonst hatte das hergestellte Teil keinen Einstand, und Material daraus zeigte nach dem Entzaubern den ganzen Erlös als
  Gewinn. Jetzt wird das Rezept auch im offenen Berufsfenster oder in den gemerkten Rezepten der Figur gefunden. Neue
  Selbstkontrolle "Herstellen gebucht". Test T708. Frühere Buchungen bleiben unverändert.
- **Gewinn-Fenster:** Ist Entzaubern der beste Weg, steht der Händler-Betrag als "Händler: 60c" da (nicht mehr "Händler zahlt
  mehr", das widersprach "bester Weg: entzaubern"). Test T707.

## 0.65.166
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung, Entzauber-Gruppen:** Materialien aus neuen Entzauberungen merken sich den Preis im Moment des Entzauberns. Der
  Tooltip der Gruppe zeigt getrennt "Preis gefallen seit dem Entzaubern −x" (oder gestiegen) – was dich das Warten gekostet oder
  gebracht hat. Älterer Bestand hat diesen Preis nicht und wird nicht geschätzt. Ein kurzer Satz erklärt die Gruppen-Zahl. Tests T705, T706.

## 0.65.165
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Beste Rezepte:** Zutaten, die du kaufen musst, kosten jetzt den Preis, zu dem die Menge für eine Serie von 20 Herstellungen
  wirklich kaufbar ist (Preisleiter), nicht das billigste Einzelangebot – kein Schein-Gewinn mehr wie "Wollstoffballen +1s 66c".
- **Herstellungs-Ketten (Vorbereitung):** AHSentinel rechnet nach jedem Scan die Ketten deiner bekannten Rezepte (kaufen ->
  herstellen, auch Zwischenprodukte -> verkaufen oder entzaubern) und behält nur solche mit mindestens 20 % Gewinn. Bis sie
  dreifach geprüft sind, stehen sie nur im Testbericht, nicht im Tooltip oder im Markt-Reiter. Test T704.

## 0.65.164
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung, Entzaubern:** Der Einstand eines entzauberten Teils wird jetzt nach dem aktuellen Marktpreis auf die Materialien
  verteilt. Vorher galt der "realistische Wiederverkaufspreis", der langsam verkaufte Essenzen und Splitter stark drückt – der
  Seelenstaub bekam viel zu viel Einstand (etwa 6s statt 4s je Staub), die Essenzen zu wenig, und der Staub sah nach Verlust aus.
  Schon gebuchte Werte bleiben unverändert. Neue Selbstkontrolle "Verteilung beim Entzaubern": meldet, wenn ein Material mehr als
  ein Drittel von den anderen abweicht (mit Zahlen). Test T703.

## 0.65.163
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Lager (Gold-Sicherheit):** Die "Phantom-Lager"-Regel aus 0.65.160 konnte eigene laufende oder zurückgekommene Auktionen
  und AH-Käufe, die noch in der Post liegen, als "fehlt" ausbuchen. Jetzt wird nur ausgebucht, wenn Briefkasten UND eigene
  Auktionen nach dem letzten Zugang (und nach dem Ende deiner Auktionen dieses Items) gesehen wurden – auch wenn nur ein Teil
  fehlt. Auktionen aus früheren Sitzungen zählen als vorhanden. Kommt ausgebuchte Ware später doch an (30 Tage), wird die
  Buchung mit dem alten Einstand zurückgenommen. Ausbuchen und Zurücknehmen stehen im Reparatur-Protokoll. Tests T699, T701, T663.
- **Buchhaltung, Entzauber-Gruppen:** Gewinn und "Gewinn %" kommen aus denselben Stücken (vorher: Gewinn +3g 50s grün neben
  −4 %). Der Tooltip der Gruppe zeigt EINE Zahl (Gold rein − Gold raus), "davon Stücke ohne Einkauf" und die Materialien nur
  mit Menge und Erlös – kein irreführender "Verlust je Material" mehr. Test T702, Selbstkontrolle: Gruppe = Erlös − Einsatz.
- Testroutine: Der absichtliche Testfehler (T131) öffnet kein Lua-Fehlerfenster mehr; dein Fehler-Handler ist danach sofort
  zurück. Testbericht: kein Farbcode im Text der Selbstkontrolle.

## 0.65.162
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Neu: Knopf „Entzaubern (n)“ am Berufsfenster** – öffnet das Entzauber-Fenster von AHSentinel, ohne „/ahs entzaubern“
  zu tippen. n = entzauberbare Teile in den Taschen (gesperrte, Ausrüstungs-Sets und Quest-Gegenstände zählen nicht);
  bei 0 grau. Der Knopf sitzt links neben „Alle erstellen“, wenn dort Platz ist, sonst unter dem Berufsfenster – er
  verdeckt nie einen anderen Knopf. Im Kampf gesperrt. Test T700, Selbstkontrolle „Entzaubern-Knopf“.

## 0.65.161
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Selbstkontrolle:** Die Testroutine schreibt nie mehr in die echten Prüf-Sitzungen am Briefkasten oder im AH (vorher konnte
  ein Test am offenen AH eine falsche Abweichung erzeugen).
- **Lohnt bis (Händler):** Ein Kauf zum Händlerpreis bringt nichts – der Weg Händler rechnet jetzt mit 20 % Mindestgewinn.
- Testroutine: Tests warten nach einem frischen Vollscan länger auf ihre Hintergrund-Aufgaben; bei vollem Hintergrund
  „übersprungen“ mit Grund statt Fehler. Neuer Simulator-Lauf mit offenem Auktionshaus.

## 0.65.160
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Weniger Ruckeln bei „Heute tun“:** Die Herstell-Vorschläge von ProfessionSentinel werden höchstens alle 15 Minuten neu
  geholt statt nach jedem Scan (ein Schritt dauerte bis 153 ms).
- **Lager:** Ware, die nirgends mehr ist (keine Tasche, Bank, Post oder Auktion) und seit über einem Tag nicht nachgekauft
  wurde, wird ausgebucht – kein Phantom-Bestand mehr. Test T699.
- Selbstkontrolle Lager: „mehr vorhanden als gebucht“ (Beute, Geschenke) ist kein Fehler mehr, nur eine graue Info.

## 0.65.159
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Kaufgrenze lernt sofort:** Die abgeschlossenen Käufe der letzten 30 Tage werden einmal neu gezählt (jeder genau einmal),
  damit die Kaufgrenze je Preisstufe nicht erst nach Wochen wirkt. Test T697.
- **Selbstkontrolle Post:** Ist das Geld nach dem Abholen schon aus der Post verschwunden, zählt der Stand vom letzten Lesen
  des Briefkastens. Test T698.

## 0.65.158
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Rechenkern Schritt 3a:** Ein „Lohnt bis“ über alle Wege (Entzaubern, Wiederverkauf im AH, Händler) – der beste
  sichere Ausgang je Item. Der Testbericht vergleicht ihn mit den Zahlen, die Tooltip, Markt, Sammelkauf und Sniper heute
  zeigen; die Umstellung aller Anzeigen folgt, sobald die Abweichungen erklärt sind. Test T696.
- Selbstkontrolle Auktionshaus findet auch ältere Buchungen.

## 0.65.157
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Selbstkontrolle Post richtig:** Die Prüfung am Briefkasten zählt jetzt jedes genommene Geld nach Art (AH-Verkauf,
  andere AH-Post, Gold von Spielern, Nachnahme) und meldet nur Gold, das sich nicht erklären lässt, oder einen Verkauf
  ohne Buchung – keine falschen roten Meldungen mehr. Handel und Verkaufen-Fenster werden genauer geprüft (geschriebene
  Buchungen, erste Zeile Preis und Menge).
- **Kaufgrenze:** Die eigenen Käufe zählen vor der Tabelle (die Tabelle ist nur Vorwissen), Gewinn je Stufe als Summe.
  Lohnt sich keine Preisstufe, gibt es kein „Lohnt bis“. Testbericht: je Stufe vorhergesagter gegen erzielten Gewinn.

## 0.65.156
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Weniger Ruckeln beim Vollscan (Teil 2):** Preisleitern, Verfolgung und Prüfungen nach dem Scan legen keine neuen
  Tabellen je Item mehr an. Ab dem dritten Scan legt ein Vollscan im Test rund 13,8 MB neu an (vorher
  über 60 MB), keine Hintergrund-Portion über 9 ms.
- **Gold-Abstimmung genauer:** zählt erst ab Beginn der Messung (alte Buchungen verwässern die 1-%-Grenze nicht mehr), das
  Post-Geld zählt am Tag, an dem du es abholst, und es wird gemessen, ob die Anzahlung im Post-Geld steckt. Tests T694, T695.
- Verkaufen: Hinweise werden über die Höhe gemessen – nichts wird mehr abgeschnitten.

## 0.65.155
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **AHSentinel prüft sich selbst:** Während du normal spielst, vergleicht das Addon im Hintergrund jede Buchung mit dem,
  was wirklich passiert ist: Händler, Post, Auktionshaus und Handel gegen die Gold-Änderung, Lager gegen Taschen/Bank/Post,
  das Verkaufen-Fenster nach jedem Klick, Speicher nach jedem Vollscan und die Gewinn-Anzeigen untereinander. Ergebnis im
  Testbericht (Abschnitt „Selbstkontrolle“) und in /ahs testroutine; im Details-Fenster nur eine Zeile, wenn etwas nicht
  stimmt. Du musst dir kein Gold mehr notieren. Tests T686–T693.

## 0.65.154
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Rechenkern Schritt 2:** Markt-Tabellen (täglich neu gerechnet) liegen jetzt im Addon und dienen als Vorwissen,
  solange die eigenen Zahlen noch fehlen. Die Kaufgrenze lernt je Preisstufe: bringt eine Stufe nicht den Mindestgewinn,
  wird dort gesenkt (nie über 90 % vom Wert). Ist ein Entzauber-Material in einer Welle (Preis fällt), steht beim
  Verkaufen „Welle: jetzt verkaufen“. Tests T683–T685.

## 0.65.153
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Rechenkern lernt mit ehrlicher Prüfung (Schritt 1):** Eine neue Lernschicht zählt jedes Verkaufsergebnis je
  Warengruppe und Preisstufe (wenige Fälle -> Richtung Vorwissen, alte Fälle zählen weniger). Jeder Fall wird vorher
  vorhergesagt und erst danach gezählt – so ist sichtbar, ob die Vorhersage wirklich trifft. Im Testbericht „MARKT-KERN“
  (Treffer, Grundlinie, Brier). Angezeigt wird noch nichts Neues. Tests T681, T682.
- **Abbruch-Grund:** Brichst du eine Auktion ab, zählt „unterboten“ jetzt nach dem günstigsten FREMDEN Angebot der letzten
  Suche (vorher war oft die eigene Auktion die günstigste -> nie „unterboten“). Testbericht: Klasse 80–100 % vor/ab
  0.65.128 getrennt. Test T680.

## 0.65.152
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Entzauber-Materialien je Gruppe:** In der Liste „je Item“ stehen Staub, Essenzen und Splitter eines
  Stufenbands zusammen in einer Zeile („Entzaubern 26–35“), die einzelnen Materialien zeigt der Tooltip. So zählt, ob sich
  das Entzaubern einer Gruppe lohnt – nicht ein einzelnes Material, das gerade in einer Welle gefallen ist. Test T679.
- Testroutine: Absatz-, Entzauber-, Sync- und Vollscan-Tests (T285, T289, T291, T223, T272, T310) laufen im Spiel jetzt
  unabhängig von deinen echten gelernten Daten.

## 0.65.151
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Handel mit Spielern gebucht:** Kaufst oder verkaufst du über das Handelsfenster, steht das jetzt in der Buchhaltung –
  gemessen aus Gold und Taschen (Herkunft bzw. Weg „Spieler“). Geschenke ohne Gold werden nicht als Verkauf gebucht. Test T678.
- **Material-Wellen:** Der Index rechnet nur noch ganze Tage – der angefangene heutige Tag (nur Morgenpreise) verfälscht ihn
  nicht mehr. Test T677.
- „Heute tun“ rechnet in kleineren Portionen (weniger Ruckeln). Testbericht: Kauf-Sicherheit Entzaubern nach den
  Gruppen-Regeln (20/25/30 %, kein Budget).

## 0.65.150
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gold-Abstimmung als Geldfluss:** Jede Gold-Änderung wird jetzt gemessen und dem Ort zugeordnet (Auktionshaus, Post,
  Händler, Handel mit Spielern, Lehrer, Flugmeister, Beute, Quest, sonst). Abgestimmt wird gemessener Handels-Geldfluss
  gegen gebuchten Geldfluss – Geld ausserhalb des Handels (Quest, Beute, Lehrer, Flug) gilt als erklärt. Der Testbericht
  zeigt die grössten Lücken je Tag mit den Orten. Test T676.

## 0.65.149
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Weniger Ruckeln nach dem Vollscan:** Die Marktwert-Rechnung legt keine Hilfstabellen mehr je Item an. Nach einem Scan
  entsteht dadurch rund zwei Drittel weniger Speicher-Müll (im Test 65 MB -> 18–23 MB), es gibt weniger
  Speicherbereinigungen und der Speicher wächst je Scan kaum noch. Gleiche Werte wie vorher (6000 Items verglichen).
  Test T675.
- **Verkaufen:** Hinweise werden nicht mehr abgeschnitten – es stehen so viele da, wie ganz in 2 Zeilen passen, der Rest im
  Tooltip „(i)“. „Viel zu teuer – verkauft sich bei …“ statt „Preis 120x über Markt“.

## 0.65.148
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Händler gemessen statt angenommen:** Käufe, Verkäufe an den Händler (auch von Hand), Rückkäufe und Reparaturen werden
  aus dem Unterschied von Gold und Taschen gebucht – genau mit dem Betrag, der wirklich bezahlt wurde. Gescheiterte Käufe
  oder Reparaturen werden nicht mehr gebucht. Verkäufe an den Händler stehen jetzt in der Buchhaltung (Weg „Händler“) statt
  später als „fehlt“. Beim Schliessen des Händlers wird geprüft, ob alles aufgeht; ein Rest steht als „Händler unklar“.
  Tests T670–T674.
- **Verkaufen – Klick trifft das gesehene Item:** Wird die Taschen-Liste genau zwischen Zeigen und Klicken neu sortiert,
  wählt der Klick trotzdem das Item, das unter der Maus zu sehen war. Tests T667/T668 laufen jetzt immer (Ersatz-Taschen).

## 0.65.147
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufen – Einstellen-Feld aufgeräumt:** Kein Text überlappt mehr. Jede Zahl steht in ihrer eigenen Zeile:
  neu „Gewinn erwartet“ (grün/rot, grau solange das Addon die Verkaufsquote noch lernt) und „Verkaufschance“ – die Chance
  hängt nicht mehr an der Einstellgebühr.
- „Erlös nach Gebühren“ ist jetzt ehrlich: Verkaufspreis minus AH-Gebühr. Mögliche Rückläufe stecken nur in „Gewinn erwartet“.
- Hinweise stehen in einem festen Bereich über dem Knopf: höchstens 2 Zeilen, der wichtigste zuerst, alle weiteren im
  Tooltip „(i)“. Kürzer: „Händler zahlt mehr: 1c“, „Preis 120x über Markt – verkauft sich bei 25c“. Test T669.

## 0.65.146
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufen – immer der aktuelle AH-Stand:** Jedes gewählte Item wird sofort neu beim Server gesucht (vorne in der
  Warteschlange), auch wenn der letzte Preis erst wenige Minuten alt ist. Bis die Antwort da ist, steht die alte Liste
  grau mit „wird aktualisiert …“; bremst der Server, steht dort, in wie vielen Sekunden er wieder suchen lässt – die
  Suche läuft dann von selbst. Nach Einstellen, Abbrechen oder Kaufen des gewählten Items wird sofort neu gesucht.
- Jeder Klick in der Verkaufen-Liste steht im Protokoll (Item, vorher/nachher gewählt, Fehler, Titel). Test T668.

## 0.65.145
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufen – Item-Wahl:** Ein links gewähltes Item erscheint jetzt immer rechts, auch wenn ein einzelner Schritt
  (Preisvorschlag, Laufzeit, Taschen zählen) scheitert; der Fehler steht im Fehlerprotokoll mit Item und Schritt.
  Test T667.

## 0.65.144
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Lager-Abgleich sicherer:** Ware, die noch im Briefkasten liegen kann (AH-Kauf, Post von einer eigenen Figur,
  zurückgekommene Auktion), wird erst ausgebucht, wenn der Briefkasten danach gesehen wurde – frisch Gekauftes 7 Tage
  gar nicht. Was 0.65.140–0.65.143 vorschnell als „fehlt“ oder „verbraucht“ ausgebucht hat, kommt einmalig zurück ins Lager.
- Fehlbestand und an andere verschickte Ware stehen getrennt vom Eigenbedarf (Details-Fenster, Testbericht). Test T666.

## 0.65.143
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Briefkasten von Hand:** Post wird auch gezählt, wenn du sie selbst oder mit einem anderen Addon abholst –
  Rechnungen, Ablauf-Post (Anzahlung verfallen) und Ware im Briefkasten (zählt im Lager-Abgleich als vorhanden).
- **Verkaufs-Prognose:** Die Chance kommt jetzt aus deiner gezählten Quote je Preisstufe. Beim Abbrechen (auch über
  Blizzards Fenster) wird festgehalten, ob du unterboten warst und um wie viel. Tests T664, T665.
- Lager-Abgleich: Ware, die nirgends mehr liegt (Taschen, Bank, Auktion, Briefkasten), wird sofort ausgebucht.

## 0.65.142
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – ein Gewinn:** Der Kopf zeigt jetzt denselben Gewinn wie das Fenster „Details“ (kein zweiter
  „Gewinn mit Einkauf“ mehr). Ware ohne bekannten Einkauf steht grau als „Herkunft unbekannt“.
- **Details:** Rendite je Weg erst ab 30 Fällen als Zahl (vorher grau „lernt noch“); die Gold-Abstimmung warnt erst
  rot, wenn sie stimmig ist (vorher grau „wird abgeglichen“).

## 0.65.141
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Fehler behoben: „Crafting.lua:515 attempt to index field“ beim Berechnen der Herstellen-Liste.
- Testroutine schreibt beim Aufräumen keine echten Daten mehr (Gold-Stand, Vollscan-Messung).
- Test T659 läuft jetzt auch im Spiel (Sperren durch Briefkasten/Herstellen im Test aus).

## 0.65.140
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Lager-Abgleich korrigiert (wichtig):** Der Abgleich hat Ware in Taschen und Bank als „0 vorhanden“ gesehen. Jetzt
  zählt AHSentinel mit dem gespeicherten Abbild deiner Taschen und Bank (Bank beim letzten Öffnen). Solange die Bank nie
  gesehen wurde, wird nichts ausgebucht. Was 0.65.136–0.65.139 fälschlich als „verbraucht“ ausgebucht hat, kommt einmalig
  zurück ins Lager. Ware, die wirklich fehlt, wird als Abgang gebucht (nicht im Gewinn). Test T663.

## 0.65.139
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Rechenkern (Vorbereitung 0.66):** AHSentinel misst die Marktwellen je Stufenband (Entzauber-Materialien): „in der
  Welle“ (2 Tage stark gefallen), „durch“ (seitwärts) oder offen. Vorerst nur im Testbericht. Test T662.

## 0.65.138
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Spielkosten:** Reparaturen beim Händler werden als Spielkosten gebucht (nicht im Handelsgewinn) und
  erscheinen im Fenster „Details“; die Gold-Abstimmung geht damit besser auf. Reparatur aus der Gildenbank zählt nicht.
  Test T661.

## 0.65.137
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Herstellen:** Beim Herstellen wandern die Kosten der Zutaten (z. B. Fläschchen vom Händler) in das
  hergestellte Produkt – der spätere Verkauf zeigt den echten Gewinn.
- **Verschickte Post:** Ware an eine eigene Figur nimmt den Einkaufspreis mit; Ware an andere Spieler zählt als
  Eigenbedarf. Verschickte oder verbaute Händlerware gilt nicht mehr fälschlich als „verbraucht“. Test T660.

## 0.65.136
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – verbrauchte Händlerware:** Was du beim Händler gekauft und verbraucht hast (Essen, Wasser, Munition,
  Reagenzien), verschwindet aus dem Lager und zählt als Eigenbedarf – kein Phantom-Bestand mehr. Test T659.

## 0.65.135
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Händlerkäufe:** Käufe beim Händler werden jetzt gebucht (Einkauf mit Herkunft „Händler“, Einstand im
  Lager, z. B. für Herstellen). Die Gold-Abstimmung geht damit besser auf. Test T658.

## 0.65.134
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Details – Verkaufsquote je Verkaufskette:** Abbrechen und billiger neu einstellen zählt nicht mehr als „nicht
  verkauft“ – nur Ware, die abläuft und nicht neu eingestellt wird. Test T657.

## 0.65.133
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Knopf „Details“:** öffnet ein eigenes Fenster (Heute / Woche / Gesamt, Standard Gesamt) mit Handel
  (Gewinn), Handel pro Stunde (Gewinn ÷ Spielzeit ohne AFK, ab 2 Std.), Eigenbedarf, verfallene Anzahlung,
  Verkaufsquote, Rendite je Weg (Entzaubern als Summe aller Fälle) und Gold-Abstimmung. Sonst sieht die Buchhaltung
  aus wie bisher. Test T656.

## 0.65.132
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Anzahlung – genauer:** Eine Anzahlung gilt erst als verfallen, wenn die Ablauf-Post kommt oder du die Auktion
  abbrichst – nicht mehr nach fester Zeit. Eine spät gelesene Erstattung (auch nach Tagen) löst sie immer auf.
  Test T654.

## 0.65.131
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Eigenbedarf:** Gekaufte Ware, die du anlegst oder als Tasche einsetzt, ist keine Handelsware mehr:
  Sie verschwindet aus dem Lager und zählt nicht im Handelsgewinn (eigene Ausgabe „Eigenbedarf“, nur im Testbericht).
  Die Buchhaltung sieht aus wie bisher. Test T655.

## 0.65.130
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Anzahlung richtig gebucht:** Die Anzahlung beim Einstellen ist hinterlegt und drückt den Gewinn
  nicht mehr. Kommt sie beim Verkauf zurück, ist das kein Ertrag. Nur eine verfallene Anzahlung (Ablauf/Abbruch) ist
  Aufwand – im Zeitraum des Ablaufs. Bezeichnung wie im Spiel („Anzahlung“ aus dem Verkaufsfenster).
- Testbericht: hinterlegte und verfallene Anzahlungen. Test T654.

## 0.65.129
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Weniger Speicher:** Zwischenspeicher je Item (Marktwert, Absatz, Aufkauf) werden begrenzt und bei Bedarf alle
  10 Minuten geleert. Der Tempo-Test zeigt ihre Grösse. Test T653.

## 0.65.128
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufs-Prognose kennt den Preis:** Die Verkaufschance kommt jetzt aus deinen echten Verkäufen je Preisstufe
  (Preis zum Marktwert) – teurer eingestellt heisst kleinere Chance. Ohne gelernte Fälle bleibt es wie bisher.
- Testbericht: Verkaufsketten (abgelaufen/abgebrochen -> neu eingestellt -> verkauft zählt als ein Fall), mit Anzahl
  Einstellungen und Preis der letzten zur ersten Einstellung. Tests T651, T652.

## 0.65.127
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Phantom-Ware entfernt:** Ware, die nach der Reparatur noch im Lager stand, obwohl sie verkauft war,
  wird einmalig auf die Rechnungen umgebucht (Einkaufspreis dort, nicht im Lager). Neu: Abgleich Lager gegen Taschen,
  Bank und eigene Auktionen – liegt im Lager mehr, steht es im Testbericht (nur gemeldet, nichts still geändert).
- **Gold-Abstimmung** rechnet nur noch über den Zeitraum, für den es Gold-Stände gibt, über alle Figuren; vorher „lernt noch“.
- **Schnäppchen-Reiter** rechnet nicht mehr beim Öffnen, sondern im Hintergrund (sofort der letzte Stand).
- **Sniper/Entzaubern:** Kaufgrenze nie über 0,9 × Wert.
- Testroutine schreibt keine echten Gold-Stände mehr. Tempo-Test: Start-Teile mit Datei:Zeile, Tooltip-Messung mit
  Hinweis auf Speicherbereinigung, Ursache von Vollscan-Lücken, letzte Vollscan-Messung auch nach dem Reload.
- Testbericht: Käufe je Preisstufe, Entzauber-Zerlegung aus Summen. Tests T649, T650.

## 0.65.126
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Leere Listen:** Der Hinweis in einer leeren Liste (z. B. Markt > Entzaubern) steht jetzt innerhalb der Liste und
  bricht auf deren Breite um, statt quer über den Bildschirm zu laufen.
- **Fenster „Testbericht“:** Sehr lange Berichte werden in Teilen gezeigt (Pfeile oben rechts, „Teil x von y“), statt
  dass das Fenster leer/schwarz bleibt.
- **Verkaufs-Prognose ehrlicher:** Selbst abgebrochene Auktionen zählen nicht mehr als „nicht verkauft“ (weder Treffer
  noch Fehler, auch nicht beim Lernen). Beim Abbruch wird festgehalten, ob du unterboten warst. Der Testbericht zeigt
  die Trefferquote alt/neu und den Verkaufsanteil je Preisstufe.
- Test: Liste „Heute“ mit 5000 Items rechnet in kleinen Portionen (T647). Tests T645–T648.

## 0.65.125
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Weniger Ruckeln – Preisverlauf kompakt im Speicher:** Im Spiel hält AHSentinel den Preisverlauf jetzt als eine
  kompakte Zahlenliste je Item statt einer eigenen Tabelle je Preis-Eintrag (zehntausende Lua-Objekte weniger; die
  Speicherbereinigung hat viel weniger zu tun). Gespeichert wird genau wie bisher, alle Werte bleiben gleich.
- **Buchhaltung – Reparatur korrigiert:** Bei Rechnungen, die früher doppelt zu ausstehenden Verkäufen gebucht wurden,
  kommt der Einkaufspreis jetzt auf die Rechnung (die Ware ist verkauft) statt zurück ins Lager. Wer 0.65.124 schon
  gestartet hat, bekommt das einmal nachträglich korrigiert (Sicherung bleibt). Die Reparatur gilt erst als erledigt,
  wenn sie ohne Fehler durchgelaufen ist.
- Tempo-Test zeigt die Tabellen des Preisverlaufs. Tests T643, T644.

## 0.65.124
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung – Gewinn nur aus bestätigten Verkäufen:** Verkaufte, aber noch nicht per Post bezahlte Auktionen
  („ausstehend“) zählen nicht mehr im Gewinn, sondern stehen getrennt als „unterwegs“. Ausstehende Buchungen, die älter
  als 24 Std. ohne Rechnung sind, werden im Tooltip gemeldet.
- **Rechnungen in grossen Posten:** Eine Rechnung über z. B. 72 Stück bestätigt jetzt mehrere kleine ausstehende
  Buchungen desselben Items (über die Menge summiert) statt einen zweiten Verkauf zu buchen.
- **Einmalige Reparatur:** Ausstehende Buchungen, die eine früher neu gebuchte Rechnung schon enthält, werden als „durch
  Rechnung ersetzt“ markiert (nichts gelöscht, Sicherung bleibt). Kein Doppel mehr zwischen Rechnung und ausstehend.
- Testbericht: Gewinn alt/neu, Anzahl aufgelöster Buchungen, Gold-Abstimmung seit Stichtag. Tests T640–T642.

## 0.65.123
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gemeinsame Befehlsliste:** Die Liste beim Tippen von `/ahs` kommt jetzt aus der gemeinsamen GoldSentinel-Datei
  (GoldSentinelCmdHint.lua), gleich für alle GoldSentinel-Addons. Bedienung bleibt gleich (Klick wählt, Tab/Shift+Tab,
  Enter führt aus); deine Zähler bleiben erhalten.
- Tempo-Test (`/ahs testroutine tempo`): Speicher von AHSentinel je Bereich (Grösse und Anzahl Tabellen) im Testbericht.
- Tests T638, T639.

## 0.65.122
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzaubern – endgültige Regeln je Materialgruppe:** 20 % Mindestgewinn für Gruppen, die deine Ergebnisse belegen, und
  auch für noch nicht gemessene Gruppen, solange die Entzauber-Tabelle zu deinen Messungen passt (±10 %); 25 % nur,
  wenn die Tabelle abweicht; 30 % für Gruppen, die gemessen schlecht laufen. Kein Budget-Deckel je Gruppe. Im Spiel
  siehst du nur, ob es sich lohnt – die Regeln stehen nur im Testbericht.
- Test T637 angepasst.

## 0.65.121
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauberwert war viel zu stark korrigiert (wichtig):** Die Materialpreis-Korrektur (×0,57) nahm den Median eines
  Zufallsergebnisses – meist billiger Staub, selten teure Essenz oder Splitter. Im Schnitt stimmte die Vorhersage
  (≈ 0,96). Jetzt rechnet die Korrektur mit Summen (gesamte Beute / gesamte Vorhersage, ab 30 Fällen) – „Lohnt bis“,
  Sniper-Max und Gewinn-Zeile sind wieder realistisch. Auch die gelernte Sicherheitsmarge beim Entzaubern nutzt Summen.
- **Mindestgewinn beim Entzaubern je Materialgruppe:** 20 % für Gruppen, die deine eigenen Ergebnisse belegen
  (≥ 30 Käufe, Gewinn gesamt ≥ 20 %), 25 % für noch nicht belegte Gruppen (und höchstens 20 % des Entzauber-Budgets je
  Gruppe zum Kennenlernen), 30 % nur für Gruppen, die gemessen schlecht laufen. Waffen und Rüstung desselben
  Stufenbands zählen zusammen.
- Testbericht: Gewinn gesamt je Gruppe (Beute / Einsatz) und der geltende Mindestgewinn.
- Tests T589, T637.

## 0.65.120
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Keine Sync-Flut mehr:** AHSentinel füllt die gemeinsame Sende-Warteschlange nie über 10 Nachrichten; der Rest wartet
  in einem eigenen Ausgang und geht nach und nach raus (während der Testroutine wartet er). Das verringert auch das
  Ruckeln nach einem Vollscan.
- **Markt-Reiter öffnet sofort:** „Heute“ rechnet beim Öffnen nicht mehr (vorher über 1 Sekunde), sondern im Hintergrund
  und erscheint, sobald es fertig ist.
- **Schnelleres Einloggen/Reload:** Der kompakte Preisverlauf wird gleich nach dem Laden in kleinen Portionen entpackt
  statt auf einmal; nichts kann verloren gehen (Ausloggen während des Entpackens behält die gepackten Daten).
- Sniper-Test: „keine Treffer“, weil der Markt nichts Passendes hatte, ist jetzt SKIP mit Gründen; die Sync-Warteschlange
  zeigt ihre Zusammensetzung. Tempo-Test: die letzte Vollscan-Messung überlebt einen Reload.
- Tests T634–T636.

## 0.65.119
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzaubern braucht mindestens 30 % Gewinn (bisher 20 %):** Deine eigenen Ergebnisse zeigten zu viele Entzauber-Käufe
  ohne Gewinn. „Lohnt bis“, das Sniper-Max für Entzauber-Ziele, die Markt-Ansicht und der Tooltip rechnen jetzt alle mit
  denselben 30 % (Wert ÷ 1,3). Eine höhere Einstellung gilt weiter; der allgemeine Mindestgewinn beim Verkaufen bleibt.
- Test T633.

## 0.65.118
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Neuer Testteil `/ahs testroutine tempo`:** misst die Tempo-Ziele im Spiel – Tooltip-Rechenzeit, Reiter wechseln,
  Sniper-Reaktion, Kauf per Raste, längstes Bild bei offenem Auktionshaus, Einloggen/Reload und Speicher beim Vollscan –
  und schreibt sie in den Testbericht (Feld „tempo“), bei einem verfehlten Ziel mit der langsamen Stelle.
- Vollscan: Das Diagnose-Protokoll zeigt jetzt, ob langsame Lese-Portionen von der Speicherbereinigung kommen.
- Tests T625–T632.

## 0.65.117
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Budget nach dem Zurücksetzen verdoppelt:** „Zähler zurücksetzen“ setzt das Budget jetzt immer auf den
  eingestellten Betrag zurück (eine Nachfüllung bleibt nicht mehr drin).
- **Ein „bester Weg“ für alle Zahlen:** Gewinn-Zeile, „… bringt mehr“ und „Max über Verkaufswert – jeder Kauf verliert
  ca. …“ kommen jetzt alle aus derselben Rechnung (Verkaufen, Entzaubern, Händler nach Gebühren) – keine widersprüchlichen
  Zahlen mehr.
- Die Rechen-Zeile „Mit … Budget kauft der Sniper höchstens …“ ist aus dem Ziel-Tooltip weg.
- **Sniper und Scrollen:** Der Sniper misst, ob der Server Suchen ohne Tastendruck beantwortet. Wenn nicht, steht oben
  „Zum Suchen und Kaufen scrollen · letzte Suche vor 12 s“, und nach 10 s ohne Scrollen kommt eine leise Erinnerung.
- Testbericht: Zusammensetzung der Sync-Warteschlange je Präfix.
- Tests T621–T624.

## 0.65.116
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **„Lohnt bis“ beim Entzaubern war zu tief:** Die Materialpreis-Korrektur (z. B. ×0,57) wurde zweimal gerechnet – einmal
  im Wert und noch einmal in der gelernten Sicherheitsmarge (beide massen denselben Fehlbetrag deiner eigenen
  Entzauberungen). Die gelernte Marge deckt jetzt nur noch ab, was die Korrektur nicht schon erklärt. „Lohnt bis“ (Sniper-
  Max für Entzauber-Ziele, Kaufgrenzen) ist wieder Wert ÷ (1 + Mindestgewinn), z. B. 10s -> 8s 33c statt 5s 90c.
- Test T620.

## 0.65.115
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Abnahme im Spiel:** `/ahs testroutine sniper` (Auktionshaus offen). Zuerst fragt ein eigenes Fenster, ob EIN
  echter Testkauf von 1 Stück bis 5c erlaubt ist – gekauft wird nur mit deiner Mausrad-Raste bzw. Taste; „Nein“
  überspringt ihn. Danach beobachtet die Testroutine (Kaufen gesperrt) den Sniper 2 Minuten: Treffer bleiben stehen (S1),
  Zähler und Budget nur bestätigte Käufe (S2), Pause sichtbar und „fortsetzen“ wirkt (S3), Bilder/s, längster Frame und
  Sync-Warteschlange (S5) sowie die Reaktionszeit (S6). Das Ergebnis kommt wie die anderen Teile in den Testbericht.
- Tests T613–T619.

## 0.65.114
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper verliert keinen echten Kauf:** Schickt der Server keine Antwort, prüft der Sniper nach 30 s dein Gold (Gold um
  den Preis weniger -> gezählt). Eine späte Bestätigung wird noch gezählt (bis 5 Min.). Im modernen Auktionshaus macht
  eine Fehlermeldung ohne Angebot (z. B. von einer Suche) den Kauf nicht mehr zum Fehlschlag.
- **Live-Tooltip (neu):** Über einem Angebot (Sniper-Liste, Einkauf, Schnäppchen, Zeile im alten Auktionshaus) steht EINE
  Zeile „Gewinn: −44c / Stück“ (rot) bzw. „Gewinn: +2s 61c / Stück“ (grün) – mit dem Preis genau dieses Angebots und dem
  besten Weg nach Gebühren (Verkaufen, Entzaubern, Händler). Sie ersetzt „Entzaubern lohnt …“ und „Lohnt bis …“, alles
  andere bleibt. In den Taschen rechnet sie mit dem Marktwert. „Materialpreise korrigiert ×…“ nur noch mit Shift.
- **Einkauf:** Mit Qualitätsfilter erscheinen Items, deren Daten erst später geladen wurden, ohne neue Suche.
- **Testroutine:** Sync-Nachrichten während des Laufs werden danach angewendet (kein Sandbox-Fehler, nichts geht verloren).
- **Flip-Liste:** Liste und Detail rechnen immer mit demselben Stand (kein „FLIP-WIDERSPRUCH“).
- Diagnose: „LANGSAM“ nennt den längsten Einzelschritt (Datei:Zeile); der Vollscan-Test wartet bis 300 s.
- Tests T602–T612, T597 prüft die hochgeladenen Felder.

## 0.65.113
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper zählte gescheiterte Käufe (wichtig):** Ein gesendeter Einzelkauf zählt – und braucht Budget – erst, wenn der
  Server ihn bestätigt. Gescheiterte oder unbeantwortete Käufe zählen nicht mehr (vorher zeigte ein Ziel nach 3 echten
  Käufen "32/35 gekauft" und suchte nicht mehr). Solange ein Kauf auf die Antwort wartet, steht "(+1 gesendet)" in der
  Zeile. Altes Auktionshaus: jede Antwort des Servers gehört zum ältesten offenen Kauf.
- **Sniper-Pause sichtbar:** Nach 3 gescheiterten Käufen beim gleichen Item zeigen Zielzeile und Statuszeile "pausiert
  bis 19:58 – 3 Käufe gescheitert" (Tooltip mit dem Fehlertext des Servers), dazu der Knopf "jetzt fortsetzen".
- **Sniper-Liste:** 3 Fehlschläge hintereinander leeren die Trefferliste nicht mehr – sie bleibt als veraltet stehen,
  bis neue Ergebnisse da sind.
- **Sniper-Ziel über Verkaufswert:** Beim Anlegen kommt einmal eine deutliche Warnung im Chat (mit Warnton).
- Tests T598–T601.

## 0.65.112
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gelernter Absatz-Faktor behoben:** seit 0.65.111 stand jeder Gruppenfaktor auf 1,00, weil die Schätzung mit sich
  selbst verglichen wurde. Die unabhängige Schätzung wird wieder getrennt behalten.
- **Lagerwert:** das Lager wird zum erzielbaren Preis bewertet – nie über dem Marktwert (der Wert war durch einen
  einzelnen hohen Wiederverkaufspreis um das 12-Fache gesprungen). Der Testbericht nennt die grössten Lagerposten.
- **Weniger Ruckeln im Vollscan:** die Verfolgung der Auktionen legt keine Zeichenkette und keine Tabelle mehr je
  Auktion an (die Speicherbereinigung verursachte Stocker bis 821 ms).
- **Einkauf:** der Qualitätsfilter blendet jetzt auch Items aus, deren Qualität noch nicht geladen ist (weisse/graue
  Teile rutschten durch).
- **Tooltip:** ein kleiner Gewinn unter dem Mindestgewinn heisst jetzt "Entzaubern: nur +86c (+9 %) – unter dem
  Mindestgewinn 20 %", ohne grünen Haken beim Wert.
- Testbericht: Abschnitt Markt-Kern auch in den hochgeladenen Feldern. Tests T592–T597.

## 0.65.111
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

Sofort-Korrektur verfälschter Zahlen (dein Entscheid):
- **Entzauberwert = erzielbarer Preis:** deine eigenen Entzauberungen haben gemessen, dass die Materialpreise ~43 % zu
  hoch angenommen waren (Beute/Vorhersage 0,60). Der Entzauberwert wird jetzt je Gruppe mit diesem gemessenen Faktor
  korrigiert – für "Lohnt bis", Sniper, Markt, Tooltip und Heute tun. Der Tooltip zeigt "Materialpreise korrigiert ×0,57".
- **Absatz je Tag: gemessen vor geschätzt** überall; eine unplausible Schätzung ohne Messung steht jetzt als unbekannt
  statt als zu hohe Zahl.
- Tests T240 (Einzahlung bei Nicht-Verkauf) und die Sortierprüfung von Heute tun behoben; Tests T589–T591.

## 0.65.110
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

Ruckeln und Zuverlässigkeit:
- **Kompakter Preisverlauf (PD7, dein Entscheid):** Einträge älter als 48 Std. werden kompakt gespeichert – im Spiel ist
  der Preisverlauf genau wie vorher. Sicherung: beim ersten Mal bleiben die alten Einträge zusätzlich erhalten; beim
  nächsten Einloggen wird alles geprüft, erst dann gilt das kompakte Format. Schlägt eine Prüfung fehl, bleiben deine
  Daten wie sie waren und du bekommst eine Meldung. "/ahs pd7" zeigt den Stand, "/ahs pd7 zurück" schaltet es ab,
  solange die Sicherung da ist.
- **Weniger Ruckeln:** Arbeit nach dem Scan (Markt-Kern-Nachprüfung, Rhythmus, Prognose, Material-Protokoll, Prüfung
  echter Daten) läuft in kleinen Portionen im Hintergrund; "Heute tun" teilt seine Abschnitte in Portionen; die
  Scan-Auswertung pausiert je Zeile.
- **Sniper:** jeder gescheiterte Kauf steht mit der Server-Meldung im Protokoll; nach 3 Fehlschlägen hintereinander sucht
  der Sniper frisch, statt eine alte Liste abzuarbeiten. Entzauber-Ziele zeigen grau "lernt noch"/"Weg gesperrt".
- **Verkaufschance:** die angezeigte Prozentzahl wird mit dem tatsächlich Verkauften korrigiert (z. B. 98 % vorhergesagt,
  30 % verkauft -> 30 %) und bis zur Kalibrierung "lernt noch (nicht kalibriert)" markiert.
- **Protokoll:** Fehler der Testroutine werden getrennt gezählt; Fehler-Einträge werden nicht mehr aus dem Protokoll
  verdrängt.
- "/ahs testroutine echt" meldet nur einmal; Tests T231, T253 und T52 hängen nicht mehr von deinen echten Lerndaten ab,
  T52 versucht nie ein Abbrechen.
- Tests T584–T588.

## 0.65.109
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

Behebt falsche Zahlen aus dem grossen Test von 0.65.108:
- **Materialien nach dem Vollscan:** ein echter Preisrutsch (z. B. Levelwelle) wurde als "unbestätigtes Lockangebot"
  gespeichert, die Materialien blieben "geschätzt, unsicher". Ein Vollscan mit mindestens 5 Stück auf der günstigsten
  Stufe gilt jetzt als echter Preis. Das Diagnose-Protokoll nennt nach jedem Scan je Entzauber-Material Quelle, Alter
  und Grund.
- **Tooltip:** kein grünes Häkchen bei "Entzaubern", wenn die Materialpreise unsicher sind (grau "Entzaubern: unsicher").
- **Keine Schein-Flips:** ein Wiederverkaufspreis über dem Marktwert zählt nur bei voller Leiter (≥ 3 Stufen oder
  ≥ 5 Stück) und Absatz von mindestens 1 je Tag – sonst höchstens der Marktwert.
- **Freigaben überall:** "Heute tun" zeigt lernende oder gesperrte Wege nur grau unten ("lernt noch (n von 20)") bzw.
  gar nicht; Gewinn über 300 % steht als "unplausibel". Der Tooltip zeigt "Entzaubern lohnt sich" grau, solange der Weg
  noch lernt.
- **Abbrüche:** AUCTION_CANCELED mit unbekannter/fremder Auktions-ID (z. B. beim gescheiterten Sniper-Kauf) gilt nicht
  mehr als eigener Abbruch; dieselbe ID nur einmal.
- **Buchhaltung:** ist mehr als 30 % des Erlöses ohne Einkauf (Kostenbasis fehlt), zeigt der Kopf gross "Gewinn mit
  Einkauf" und klein gelb "dazu ohne Einkauf … – Kostenbasis prüfen". Der Testbericht listet diese Items mit
  vermuteter Herkunft.
- Tests T580–T583 (T-D1, T-TT1317, T-MH1310, T-BH1307); T223, T248, T431, T432 jetzt unabhängig von deiner echten gelernten Marge.

## 0.65.108
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Markt-Reiter "Entzaubern" rechnet jetzt dasselbe "Lohnt bis"** wie Tooltip, Einkauf, Sammelkauf, Sniper und API
  (Zeile und Detailzeile). Die Option "Mindestgewinn" ist nur noch ein Filter. Sniper-Entzauberziele stehen immer genau
  auf "Lohnt bis" (Chat-Meldung erst ab 5 % Änderung).
- **Markt-Kern misst richtig:**
  - Eigene Auktionen: Abbruch- oder Verkaufsmeldung, die vor der neuen Auktionsliste kommt, geht nicht mehr verloren.
    "Neu eingestellt" wird nur aus wirklich neuen Auktionen geraten (mehrere gleiche Stapel verwirren nicht mehr).
  - Entzauber-Empfehlungen werden am Materialwert nach 24 Std. geprüft, Händler-Empfehlungen am bestätigten
    Händlerpreis (nicht mehr am AH-Preis des Teils).
- **Freigaben (Teil D) im Markt-Reiter:** ein Weg unter 60 % Treffern wird ausgeblendet ("Weg … gesperrt (Treffer
  n %)"); ein Weg mit weniger als 20 Fällen zeigt seine Zeilen grau "lernt noch (n von 20)"; Flippen, Lücken und
  Überfüllt bleiben grau, bis 30 eigene Verkäufe gemessen sind. Gemessen wird im Hintergrund weiter.
- Selbsttest "Plausibilität (Ü3)": keine unplausible Zeile darf als Empfehlung erscheinen.
- Tests T573–T579 (T-MA1b/c, T-MA2c, T-FG1–T-FG3, T-RK2c).

## 0.65.107
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Ein "Lohnt bis" überall (Entzaubern):** Tooltip, Einkauf-Markierung "[Entzaubern lohnt]", Warnschutz,
  Sniper-Entzauberziele, Markt-Reiter "Entzaubern", die Kaufgrenze im Markt, der Sammelkauf und die API rechnen jetzt
  mit EINER Rechnung. Vorher konnten Tooltip und Markt für dasselbe Item zwei verschiedene Grenzen zeigen.
  - Lohnt bis = Netto-Wert × die strengere Grenze aus (1 / (1 + Mindestrendite)) und (1 − gelernte Sicherheitsmarge).
    Ohne Lernen: 10 % Marge unter 10 echten Entzauberungen.
  - Der Sammelkauf zieht die Mindestrendite nicht mehr ein zweites Mal ab (gekauft wird bis "Lohnt bis").
  - Selbsttest: "Ein Lohnt bis je Item" prüft 20 gescannte Items – zwei verschiedene Werte = Fehler.
- **Unplausible Vorschläge** (Gewinn über 300 %) stehen im Markt-Reiter als "unplausibel: …" und zählen nicht als
  Empfehlung.
- **Sniper: Budget aufgebraucht -> Abfrage.** Ist das Budget eines Ziels aufgebraucht und kommt ein kaufbarer Treffer,
  kauft der nächste Kauf-Druck (Taste/Mausrad) nicht, sondern fragt: "Budget von X aufgebraucht (n Stück gekauft).
  Weiter kaufen? Budget um X auffüllen." "Ja" (Enter) füllt um das ursprüngliche Budget auf (höchstens so weit das Gold
  reicht), der nächste Dreh kauft. "Nein" ändert nichts. Die Frage kommt jedes Mal neu, wenn das aufgefüllte Budget
  wieder aufgebraucht ist. Max-Preis und Menge bleiben.
- **Eine Befehlstabelle:** der /ahs-Befehl arbeitet nur noch aus der Befehlsliste – jeder Befehl, den er versteht, steht
  in /ahs hilfe und in der Liste beim Tippen (neu dort: doppelt, resetscan, messreihe, ahdebug, ah).
- **API:** WorthUpTo liefert als 4. Wert die Sicherheit 0–1 (nil = lernt noch) und als 5. Wert den Stückpreis; der 1.
  Wert bleibt die Summe für qty. MaterialCost rechnet über die Preisleiter für die benötigte Menge. Trend-Wörter von
  MarketState in API.md festgehalten.
- **Tests:** "/ahs testroutine echt" prüft die Grundregeln an deinen eigenen Daten (nur lesen: Vorschläge, ein
  "Lohnt bis", Sniper-Budget); läuft auch still nach jedem Vollscan und schreibt Verletzungen ins Diagnose-Protokoll
  ("GRUNDREGEL VERLETZT"). Neue Tests für die Freigaben des Markt-Kerns (59 % gesperrt, 61 % frei, 19 Fälle lernt) und
  für Auktions-Post mit beliebigem Absender.
- Tests T556–T572 (T-RK2a/b, T-Ü3b, T-SB1–T-SB6, T-BL1/5/6, T-API-PM2/PM3, T-TU5, T-TU7, T-BP-1113-1).

## 0.65.106
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Markt-Kern, Stufe 1 "Vertrauen" (Messungen für den neuen Markt-Reiter):**
  - Jede gezeigte Kauf-Empfehlung (Flip, Händler, Entzaubern aus dem Markt-Reiter, Sniper-Treffer) wird gemerkt und
    nach 24 Std. mit dem Scan nachgeprüft: Trefferquote und mittlerer Fehler je Weg. Ein Weg mit mindestens 20 Fällen
    und unter 60 % Treffern wird automatisch gesperrt (Protokoll "WEG GESPERRT"); unter 20 Fällen "lernt noch".
  - Verkauf oder Abbruch: verschwindet eine eigene Auktion mit langer Restzeit, rät die Erkennung "verkauft" oder "neu
    eingestellt"; die echte Ursache (Verkauf / eigener Abbruch) ergibt die Fehlerquote – Grundlage für die Freigabe
    der Absatz-Zahlen.
  - Händlerpreise: wie viele vom Spiel bestätigt wurden und wie viele von der gemerkten Tabelle abwichen.
  - Neuer Testbericht-Abschnitt "MARKT-KERN" mit diesen Zahlen, verfehlte Grenzwerte als "VERFEHLT".
- Tests T550–T555 (T-MA1–T-MA3, T-Ü1–T-Ü3).

## 0.65.105
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Kein zu billiges Einstellen mehr, wenn der Markt um 125–150 % steigt.** Bei voller Preisleiter (≥ 3 Angebote oder
  ≥ 5 Stück) liegt der Vorschlag immer knapp unter dem günstigsten Angebot; der alte gelernte Preis gilt nur noch bei
  einzelnen Ausreissern.
- **Warnschutz (Standard an):** Klick auf "Einstellen" mit einem Preis mehr als 10 % unter dem günstigsten Angebot (volle
  Leiter), mehr als 25 % unter dem Marktwert oder unter Händler-/Einkaufspreis: nichts wird eingestellt – Ton der
  Schlachtzugswarnung, der Knopf blinkt rot, ein Fenster fragt: "Preis anpassen (…)" (Enter) / "Trotzdem einstellen" /
  "Abbrechen" und zeigt, wie viel du verschenken würdest. Serie und Neu einstellen werden genauso gestoppt. Kaufen über
  dem Max-Preis des Ziels, über "Lohnt bis" oder mehr als 25 % über dem Marktwert (ohne Aufkauf) warnt ebenfalls –
  innert 10 s nochmal drücken = trotzdem kaufen. Optionen: Warnschutz an/aus, Ton an/aus. Jede Warnung steht im
  Protokoll (WARNSCHUTZ).
- Tests T542–T549 (T-AB4d, T-WS1–T-WS6).

## 0.65.104
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Befehlsliste beim Tippen von "/ahs": Mausklick wählt einen Befehl aus, Enter führt ihn aus.** Die Liste bleibt nach
  dem Klick offen, das Chatfeld bekommt den Fokus zurück, oben steht "Enter = /ahs …". Drückst du dann Enter mit dem
  getippten Anfang (z. B. "/ahs ent"), läuft der ausgewählte Befehl. Eine Auswahl gilt 10 s; Tab wählt den nächsten
  Eintrag. Das Chatfeld wird weiterhin nie beschrieben (kein Taint).
- Tests T537–T541 (T-CH1–T-CH5).

## 0.65.103
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauber-Grenzen müssen stimmen:** "[Entzaubern lohnt]" im Einkauf nur, wenn der Preis höchstens "Lohnt bis"
  (Mindestgewinn) ist, mit frischen Materialpreisen – bisher schon, sobald der Wert über dem Preis lag.
- **Sniper-Ziele aus Entzaubern folgen der Grenze:** ändert sich "Lohnt bis" um mehr als 5 % (neue Materialpreise), wird
  der Höchstpreis angepasst und einmal im Chat gemeldet.
- **Referenz-Nachrechnung in der Testroutine:** die Gruppen 26–30, 31–35 und 36–40 werden unabhängig aus den
  Scan-Preisen nachgerechnet (günstigstes − 1c × Chance × Ø Menge) und mit dem Wert verglichen, den das Addon benutzt;
  über 5 % Abweichung = FEHLER mit Material, Quelle und Alter. Eine Berichtszeile je Gruppe.
- **Händlerpreise nach dem Hotfix vom 10.11.:** zuerst der Händlerpreis des Spiels; die gemerkte Tabelle ist nur
  Rückfall und wird nachgeführt, wenn das Spiel etwas anderes sagt. Händler-Flips nur mit vom Spiel bestätigtem Preis.
- **Mindest-Einzahlung 1c (angekündigt für 17.11.):** wird beim Einstellen automatisch gemessen – nichts fest eingebaut.
- **AHSentinel.API:** neu `WorthUpTo(itemID[, qty])` (dasselbe "Lohnt bis" wie im Tooltip) und `MarketState(itemID)`
  (normal / Aufkauf / Flut / dünn / alt) für ProfessionSentinel.
- Tests T530–T536 (T-HP1, T-HP2, API-PM, T-ST1–T-ST3).

## 0.65.102
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Meine Auktionen: Verkaufte verschwinden nach "Aktualisieren"** (und beim Öffnen der Ansicht); neu Verkauftes bleibt
  bis zum nächsten Klick sichtbar. Der Kopf zählt weiter alle Verkauften. Neuer Knopf "Verkaufte: an/aus".
- **Verkaufs-Vorschlag bei einem einzelnen teuren Angebot** (dünne Leiter ≥ 150 % des Marktwerts): Marktwert statt
  knapp unter dem Ausreisser. "Billiger einstellen" erscheint nie, solange die Konkurrenz über dem Marktwert liegt.
- **Händler-Flips:** ein Händlerpreis über dem Doppelten des Marktwerts gilt als falsch (z. B. Eisengranate) – kein
  Händler-Flip damit.
- **Umfassende Tests (TU1–TU4, TU6):** jede Marktlage (normal, Aufkauf, Ausreisser, Flut, dünn, leer, alt,
  fallend/Spitze, falscher Händlerpreis, neu eingestellt) läuft durch Verkaufs-Vorschlag, Leiter-Erkennung, Hinweise,
  Entzauber-Kaufpreis und Händler-Prüfung; Abläufe wie ein Spieler (getippter Preis, drei Sniper-Ziele); Standardwerte
  leerer Felder (Liste im Testbericht); Grundregeln mit 1000 Zufalls-Leitern und Zufallsfolgen in der Buchhaltung. Der
  Testbericht hat je Bereich (TU1–TU7) eine Zeile und "Regressionen: n von m vorhanden". Tests T513–T529.
- **Tests ausserhalb des Spiels (TU9):** `tests/run_offline.sh` im Repository AHAnalyzerPro führt die Testroutine im
  nachgebauten Spiel ohne WoW aus (Lua 5.1).

## 0.65.101
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufs-Vorschlag folgt einem Aufkauf.** Ist die ganze Preisleiter hoch (Aufkauf oder neue Marktlage: günstigstes
  Angebot ≥ 150 % des Marktwerts bei mindestens 3 Angeboten oder 5 Stück), liegt der Vorschlag knapp unter dem
  günstigsten Angebot – nicht mehr beim alten gelernten Preis. Hinweis "Aufkauf – jetzt teuer verkaufen, Preis fällt
  meist bald (2 Std.)" statt "billiger einstellen"; der Ablauf-Zähler gilt dann nicht. "Verkauft sich nur ~N" bleibt
  aus, bis die Absatz-Messung freigegeben ist.
- **Ein getippter Preis bleibt.** Eine fertige Preisprüfung überschreibt einen von Hand eingegebenen Preis nicht mehr;
  Item-Wechsel oder Klick auf "Vorschlag"/"−1" macht ihn wieder automatisch.
- **Sniper behält mehrere Treffer.** Finden zwei Ziele gleichzeitig Treffer, bleiben beide kaufbar (grösster Abstand
  zum Max-Preis zuerst, dann der nächste); abgelaufene fallen raus. Anzeige "N weitere Treffer warten".
- **Sniper-Menge leer:** Ware kauft so viele, wie das Budget reicht ("Menge: bis Budget (N Stück)"), Ausrüstung 1.
  Hinweis, wenn Menge × Max-Preis weit unter dem Budget liegt.
- Tests T509–T512 (T-AB4c-a/b, T-SM1, T-SM2).

## 0.65.100
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Preisverlauf wird verdichtet (kleinere Spielstand-Datei).** 48 Std. in voller Auflösung, danach 1 Wert je Stunde
  bis 7 Tage, danach 1 Wert je Tag bis 60 Tage; Älteres fällt weg. Items ohne neuen Preis seit 30 Tagen behalten nur
  Tageswerte. Ein verdichteter Wert ist der Median der Stunde bzw. des Tages – die Marktwerte bleiben gleich. Läuft
  90 s nach dem Einloggen in kleinen Schritten; der Testbericht zeigt die geschätzte Grösse je Bereich und die letzte
  Verdichtung.
- **Doppel-Reparatur sicher für Waren:** entfernt werden nur zeitlich nahe "ausstehend"-Buchungen, nie abgeschlossene
  Verkäufe (eine Waren-Auktion wird oft Stück für Stück zum gleichen Preis verkauft). Entfernte Buchungen werden in
  einer Nebenliste gesichert, jede Reparatur mit Datum, Version und Anzahl festgehalten (Testbericht).
- **Vollscan-Prüfung sperrt nicht mehr für immer:** die Vergleichszahl verfällt nach 24 Std., und zwei Vollscans
  hintereinander mit ähnlich kleiner Zahl werden angenommen (Markt wirklich kleiner).
- **Alter Einstand nach einem Neustart:** nur ab dem ältesten Eintrag, den das Entzauber-Protokoll noch abdeckt.
- **Aufkauf:** das Testlog nennt beide Preise, wenn eine Kauf-Rechnung den Preis vor dem Aufkauf nimmt.
- Tests: Materialpreise in der Test-Sandbox sind immer frisch (T223/T230/T425 hängen nicht mehr von deinen echten
  Preisen ab); neu T502–T508 (T-VF5f, T-MP2b, T-PD5c, T-PD7a, T-MP1, T-AB8c, T-AB4b).

## 0.65.99
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Ein leerer Vollscan verändert nichts.** Antwortet der Server auf einen Vollscan mit keinen oder viel zu wenigen
  Auktionen (unter 30 % des letzten gültigen), werden keine Markt-, Absatz-, Rhythmus- oder Verfolgungsdaten übernommen:
  "Vollscan ohne Antwort – nichts übernommen." Absatz kommt nur aus zwei gültigen Vollscans.
- **Der Sniper pausiert, während ein Vollscan läuft** (etwa 30–90 s) – der Vollscan hat Vorrang. Die 15-Min.-Sperre
  allein hält den Sniper nicht an. Statuszeile: "wartet: Vollscan läuft".
- **Prognose: ein Fall je Kauf.** Derselbe Kauf konnte mehrfach im Prognose-Journal stehen. Käufe tragen jetzt ihre
  Auktion; wiederholte Meldungen werden nicht nochmals aufgenommen. Bestehende Doppel werden einmal beiseitegelegt
  (nicht gelöscht, in einer Nebenliste), wenn mehr gleiche Fälle da sind als Käufe in der Buchhaltung. Bericht: "Doppel 0".
- Tests T499–T501 (T-PD5a/b, T-PD2); Nachbildungs-Test "Scan mit Waren aktualisiert deren Preiszeit" (T-MP1).

## 0.65.98
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper-Käufe werden sofort gebucht, auch wenn du schnell hintereinander kaufst.** Bisher kam das Kauf-Ereignis
  manchmal erst, als schon der nächste Kauf lief, und wurde dann erst mit der Rechnung gebucht – Entzaubern dazwischen
  zählte mit Kosten 0. Jetzt merkt sich AHSentinel jeden Kauf mit seiner Auktion und bucht ihn, wenn sein Ereignis
  kommt; nie doppelt.
- **Entzaubern eines Teils ohne bekannte Herkunft** wird als "ohne Einkauf" gekennzeichnet statt still mit 0 gerechnet.
- **Korrektur nach dem Neustart (0.65.97) berichtigt:** Material-Verkäufe, die die Kosten der korrigierten
  Entzauberungen bekommen haben, zählen nicht mehr als "ohne Einkauf" – die Rendite stimmt wieder, die 30-%-Warnung
  verschwindet. Daten, die 0.65.97 schon korrigiert hat, werden beim Einloggen einmal berichtigt. Kosten ohne Ziel
  (Material weitergegeben) stehen im Protokoll.
- **Doppelte "ausstehend"-Verkaufsbuchungen aus 0.65.93/0.65.94** (ohne neue Kennung) werden jetzt gefunden und einmal
  entfernt (Lager zurück); echte gleich grosse Teilverkäufe bleiben.
- Tests T491–T498 (T-AB8c/d, T-AB1b–d, T-VF5e, T-PD1a/b).

## 0.65.97
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Neustart der Buchhaltung behält die Einstandspreise (Eröffnungsbilanz).** Ware, die vor dem Neustart gekauft wurde
  (Taschen, Bank, Post, eigene Auktionen), behält ihren Kaufpreis aus den alten Daten; nur die Gewinn-Zähler beginnen
  bei 0. Ware ohne Kauf (Beute) behält den Wert am Stichtag. Ein Neustart, der die Kostenbasis verloren hat, wird beim
  Einloggen einmal korrigiert: Entzauberungen mit Kosten 0 bekommen den bezahlten Preis, die Kosten wandern auf die
  Materialien (verkaufte in die Verkäufe, der Rest ins Lager). Das Diagnose-Protokoll nennt die Anzahl.
- **Plausibilität:** Warnung im Gewinn-Tooltip, wenn mehr als 30 % des Erlöses "ohne Einkauf" sind oder die Rendite
  beim Entzaubern über 100 % liegt; der Testbericht meldet FEHLER bei Entzauberungen mit Kosten 0 eines gekauften Teils.
- **Gold-Abstimmung ab demselben Zeitpunkt wie die Buchhaltung** (später von Tagesbeginn und Neustart). Ausstehende
  Verkäufe ("kommt noch mit der Post") stehen direkt dabei; "nicht gebucht" erst ab 1 % des Umsatzes.
- **Gewinn % je Item** nur aus Stücken mit Einkauf (wie im Kopf).
- **Einstellen:** kein Lua-Fehler mehr nach erfolgreichem Einstellen. Vor dem Einstellen prüft AHSentinel, ob das Item
  noch am Platz in der Tasche liegt; sonst "Schon eingestellt – nicht mehr in deinen Taschen". Der Knopf bleibt
  gesperrt, bis du ein Item wählst.
- **Meine Auktionen:** statt "?" steht, warum der Preis noch nicht geprüft ist (AH zu, wartet, Sniper sucht, Server
  bremst). Eigene Auktionen werden vor den Materialpreisen im Hintergrund geprüft. Abbrechen wird Schritt für Schritt
  protokolliert (Testlog), die abgebrochene Zeile verschwindet sofort.
- **Aufkauf (z. B. Seelenstaub zum 3-fachen Preis):** nie ein Kauf-Signal; für eigene Ware "Jetzt teuer – verkaufen …
  · Aufkauf – Preis kann schnell fallen".
- **Veraltete Preise:** jedes Material mit ≥ 25 % Anteil am Entzauberwert muss frisch sein, nicht nur das Hauptmaterial.
- Diagnose-Protokoll: Art des letzten Scans bei PREIS-ALT; eingestellter gegen Server-Preis der eigenen Auktion (EIGENE-PREIS).
- Tests T484–T490 (T-AB1, T-AB2, T-AB4, T-AB5, T-AB7, T-AB8a/b).

## 0.65.96
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **AHSentinel sagt dir jetzt, wann kaufen und wann verkaufen – aber nur, wenn es das aus eigenen Messungen weiss.**
  Eine Tooltip-Zeile, nur wenn belegt: "Jetzt günstig – kaufen (−x % unter üblich)", "Fällt – abwarten", "Jetzt teuer –
  verkaufen (+x % über üblich)" oder (eigene Ware / Verkaufen-Reiter) "Jetzt nicht verkaufen – besser um <Zeit> (+x %)".
  Sonst keine Zeile. Dieselbe Zeile steht im Einkauf, im Sniper und im Verkaufen-Reiter (dort nur die Verkaufs-Varianten).
- **Rhythmus für alle Items aus dem Scan:** einmal je Stunde Mindestpreis und Menge jedes Items (Absatz = Menge
  gesunken), kompakt je Tagesstunde und Wochentag (eigener Wochenrhythmus, z. B. Raidtage ab 9.12.). Items ohne Angebot
  seit 14 Tagen fallen raus; auch 5'000 Items bleiben unter 2 MB.
- **Ehrlich:** nur mit frischem Preis (≤ 30 Min.), nie bei Aufkauf oder veralteten Materialpreisen, erst ab 7 Tagen
  Daten und 3 Werten für diese Stunde, und nur bei Abweichung ≥ 10 % ausserhalb der normalen Schwankung. Nie "kaufen"
  in einen Absturz: fällt der Tagespreis seit 2 Tagen, steht "Fällt – abwarten".
- **Jede Zeile wird nachgeprüft** (nach 24 Std. bzw. zur genannten Zeit). Eine Signal-Art unter 60 % Treffer (ab 20
  Fällen) wird ausgeblendet, bis sie wieder besser ist. Die Trefferquoten stehen im Testbericht. Mit Shift bei zu
  wenig Daten: "Rhythmus: noch N Tage messen".
- Tests T477–T483 (T-JK1–T-JK6).

## 0.65.95
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **"Lohnt bis" in jedem Tooltip eines entzauberbaren Items** – auch in Taschen, Bank, Post, Chat-Links, beim Händler
  und in fremden Fenstern (Ausrüstung anderer Spieler, Beute). Für alle Spieler, mit oder ohne Verzauberkunst, auch im
  kurzen Tooltip. In den Taschen direkt über den zwei Wegen (Entzaubern / Verkaufen). Die bestehende Option
  "Entzaub.: an/aus" schaltet den ganzen Entzauber-Teil zusammen ab.
- **Nie mit veralteten Materialpreisen entscheiden.** Hat das Material mit dem grössten Anteil am Entzauberwert keinen
  Preis, der jünger als 6 Std. ist: Tooltip "Lohnt bis: Preise veraltet – erst scannen" (kein Betrag, Urteil
  "unsicher"), Sniper-Entzauberziele kaufen nicht ("Materialpreise veraltet – erst scannen"), Markt "Entzaubern" bietet
  keine Zeile an. Verkaufen-Werte des eigenen Lagers zeigen den alten Preis weiter mit dem Hinweis "alt".
- **Frische Materialpreise am offenen AH:** nach einem Scan und beim Öffnen des AH werden die Entzauber-Materialien
  (bis 15, die häufigsten zuerst), deren Preis älter als 30 Min. ist, einzeln nachgeholt (gedrosselt). Das
  Diagnose-Protokoll notiert Scan-Art, Anzahl Waren im Vollscan und das Preisalter der drei Hauptmaterialien (PREIS-ALT).
- **Aufkauf-Kennzeichen bleibt, bis es widerlegt ist:** ein Material mit Aufkauf behält den Preis vor dem Aufkauf über
  Sitzungen und Tage, bis ein neuerer Scan Menge ≥ 50 % oder Preis ≤ 120 % zeigt.
- **Buchhaltung:** Teilverkäufe derselben Auktion, die 0.65.92 oder älter schon gebucht hat, werden nicht nochmals
  gebucht (bestehende Doppelte einmal beim Einloggen repariert, Lager zurück). Sync: Bestände desselben Charakters,
  auf zwei Rechnern gekauft, werden zusammengezählt (5 + 3 = 8 mit beiden Einständen). Das Paket liest auch die älteren
  Feldnamen, und der Bericht zählt Entzauberungen ohne Verlaufseintrag.
- Tests T467–T476 (T-LB1–T-LB4, T-MP1–T-MP3, T-VF5c/d, T-ZM5).

## 0.65.94
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung: Rendite neben dem Gewinn.** Der Kopf zeigt jetzt "Gewinn X · Rendite Y %" (Gewinn aus gekaufter Ware ÷
  was sie gekostet hat). Ohne Einsatz: "Rendite –".
- **Wo du Geld verlierst** (Tooltip des Gewinns): die Geschäftsart (Entzaubern, Flippen, Herstellen, Händlerware) und
  das Item mit dem grössten realisierten Verlust, mit Betrag – oder "Kein Verlust-Geschäft". Die Art kommt aus der
  Herkunft des Einstandspreises (Kauf im AH = Flippen, aus Entzaubern = Entzaubern); gemischt oder unklar = "unbekannt".
- **Ehrlich bei Ware ohne Einkauf:** Gewinn aus Ware, die du nie gekauft hast (Beute, Farmen, Quests), steht getrennt im
  Kopf ("davon ohne Einkauf: X", nur wenn vorhanden) und zählt nicht in die Rendite.
- Tests T463–T466 (T-BE1–T-BE4).

## 0.65.93
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Behoben: teilweise verkaufte Auktionen lassen sich wieder abbrechen.** Bei Waren behalten die verkauften Teile einer
  Auktion dieselbe Auktions-Nummer wie die aktive Restmenge. Abbrechen (X in der Zeile und "Nächste unterbotene
  abbrechen") nahm einen verkauften Teil und meldete "Diese Auktion ist schon verkauft." Jetzt bricht die Zeile genau
  ihren eigenen Eintrag ab, sonst die aktive Restmenge.
- Buchhaltung: zwei Teilverkäufe derselben Auktion werden beide als "ausstehend" gebucht (nicht mehr übersprungen),
  die aktive Restmenge gilt nicht als verkauft.
- Tests T461–T462 (T-VF5a/b).

## 0.65.92
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Schnell-Vollscan flüssiger.** Die Auswertung nach dem Vollscan rechnet jetzt mit einem Zeitbudget je Bild
  (Standard 4 ms, Option 2/4/6/8 ms neben "Schnell-Vollscan" – kleiner = flüssiger, dauert aber länger). Die Tabellen
  je Item werden zwischen zwei Vollscans wiederverwendet, die Verdichtung erzeugt keinen Müll je Item mehr – viel
  weniger Speicher-Wechsel. Alles, was nach dem Scan neu aufgebaut wird (Marktlisten, Zwischenspeicher), läuft in
  Portionen statt in einem Bild. Der Optionstext weist darauf hin, dass es bis zur nächsten Messung noch ruckeln kann.
- **Messung erweitert:** Bilder/s je Schritt, Anteil der Bilder über 33 ms und AHSentinels eigener Speicher
  vorher/nachher (Testbericht, Abschnitt "Vollscan-Messung"). Neue Prüfungen: kein Schritt mit einem Bild über 16 ms,
  Speicher-Zuwachs höchstens 10 MB.
- "Nächste unterbotene abbrechen" bricht nur Auktionen mit Status "unterboten" ab, nie "liegen"; die Testroutine
  spricht nur ihre eigene Test-Auktion an.
- Marktwerte von 0 oder weniger gibt es nicht mehr (ein Preis 0 wird nicht gespeichert); der Selbsttest nennt die Items.
- Testroutine: der Zeitpunkt "zuletzt geprüft" der Sniper-Ziele gilt nicht mehr als Sandbox-FEHLER.
- Tests T458–T460 (T-VF1–T-VF3).

## 0.65.91
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Daten von zwei Rechnern zusammenführen.** Hast du an zwei Rechnern gespielt, ohne dazwischen abzugleichen, kann
  der GoldSentinel-Uploader AHSentinel die Daten des anderen Rechners übergeben (gespeicherte Variable
  `AHSentinelMerge`). Beim nächsten Einloggen führt AHSentinel sie einmal zusammen und leert das Paket:
  Entzauber-Ergebnisse werden ohne Doppelzählung vereinigt (nur fehlende kommen dazu – nichts geht verloren), Käufe,
  Buchungen und Prognose-Fälle ebenso, der Preisverlauf je Item wird vereinigt, der neuere Vollscan und Charakter-Stand
  gewinnen, und die Einstellungen dieses Rechners bleiben. Chat: "Daten vom anderen Rechner übernommen: …".
- Tests T454–T457 (T-ZM1–T-ZM4).

## 0.65.90
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Signal bei Sniper-Treffer.** Findet der Sniper einen echten Treffer, leuchtet der Bildschirmrand 3 Mal golden auf
  (wie das Glühen bei wenig Leben). Es endet beim Kauf, wenn der Treffer weg ist, beim Schliessen des Auktionshauses
  oder spätestens nach 4 s. Kein Signal bei toten Angeboten, pausierten Items, im Kampf oder bei geschlossenem
  Auktionshaus; höchstens ein Signal alle 3 s. Optionen: "Signal" an/aus und Farbe (Gold, Grün, Blau) neben "Ton bei
  Treffern". Das Leuchten nimmt nie Mausklicks an.
- Tests T450–T453 (T-SG1–T-SG4).

## 0.65.89
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung neu: Gewinn wie bei Profis.** Einkauf ist kein Verlust mehr – was du kaufst, liegt mit seinem
  Kaufpreis im Lager, und der Gewinn entsteht beim Verkauf: Erlös nach 5 % − Kaufpreis genau der verkauften Stücke −
  verlorene Einzahlungen. Der Kopf der Buchhaltung zeigt jetzt EINE Zahl, "Gewinn", für Heute / 7 Tage / 30 Tage /
  Seit Neustart, darunter "Verkauft · Eingesetzt · Gebühren". Alles Weitere steht im Tooltip: Kasse, Lager zum
  Einstandspreis und zum Marktwert, nicht realisierter Gewinn, ausstehende Verkäufe und die Abstimmung mit deinem
  Gold ("nicht gebucht: X").
- **Neustart.** Beim ersten Einloggen mit dieser Version beginnt die Buchhaltung heute. Die alten Daten bleiben im
  Hintergrund (Statistik, Absatz, Prognose nutzen sie weiter), zählen aber nie in der neuen Buchhaltung. Entzauber-,
  Lern-, Prognose- und Vollscan-Daten bleiben unberührt. Was du schon besitzt, bekommt zum Start seinen realistischen
  Wert als Einstandspreis – der Verkauf von altem Bestand ist so weder reiner Gewinn noch Verlust.
  `/ahs buchhaltung neu` beginnt die Buchhaltung erneut (mit Rückfrage).
- **Einstandspreis je Item und Charakter (gleitender Durchschnitt).** Entzaubern verteilt den Preis des Teils nach
  ihrem Wert auf die Materialien; Post an eigene Twinks nimmt den Einstandspreis mit. Items ohne Einkauf (Beute)
  haben Einstandspreis 0.
- **Verkäufe zählen sofort.** Sobald deine eigene Auktion als verkauft erscheint (in Forever ist die Chat-Meldung
  geschützt), wird sie "ausstehend" gebucht; die Rechnung bestätigt sie später – nie doppelt. Der Testbericht misst
  die Verzögerung.
- "Pro Item": Verkauft, Erlös, Eingesetzt, Gewinn, Gewinn %.
- Tests T441–T449 (T-BP1–T-BP9).

## 0.65.88
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Markt "Entzaubern": Kosten und Gewinn über die ganze Preisleiter.** Jede Zeile summiert alle Stufen bis "lohnt
  bis": Menge, Gesamtkosten, Ø-Preis, Gesamtgewinn und Rendite (danach sortiert), z. B. "40x bis 15s 43c (Ø 12s 38c) ·
  Wert 18s 55c · Gewinn 2g 47s (50 %)". Die Menge wird von der günstigsten Stufe aus bis 25 % deines Golds (Option)
  aufgefüllt; der Sniper bekommt genau diese Kosten als Budget und "lohnt bis" als Höchstpreis. Zeile und Fusszeile
  zeigen dieselbe Menge.
- **Wert sinkt mit der eigenen Menge** – eine Funktion für Markt, Sammelkauf und Tooltip: je mehr Teile geplant sind,
  desto tiefer der Materialwert (geplante Kaufmenge, nicht Budget / Preis).
- **Sicherheit höchstens "mittel", wenn das Hauptmaterial frisch gestiegen ist**, dazu "ohne Anstieg: X" in Zeile
  und Detail.
- **Aufkauf erkennen (jemand kauft ein Material weg).** Menge −70 % in 6 Std. und Preis +50 % über dem Marktwert =
  Kennzeichen, bis Menge oder Preis wieder normal sind. Kaufen (Markt, Sammelkauf, "lohnt bis") rechnet dann mit dem
  alten Preis ("Aufkauf bei X – mit altem Preis gerechnet"); Verkaufen bleibt beim aktuellen Preis mit "Preis
  künstlich hoch – eigene Bestände jetzt verkaufen". Der Testbericht listet die Materialien mit Kennzeichen
  (Schwellen werden gemessen).
- **"Stufe ?" behoben**: Zeilen werden neu gezeichnet, sobald die Item-Daten da sind.
- **Einkauf: "~"-Zeilen (aus dem Scan) mit leerem Detail behoben.** Vor der Detailsuche holt eine Scan-Zeile ihren
  echten itemKey über eine Browse-Suche nach dem Namen (Suffix/Itemstufe). Findet auch Browse nichts, verschwindet die
  Zeile sofort ("Keine Angebote mehr – aus der Liste genommen"), auch aus "Entzaubern lohnt", und der Scan bringt sie
  erst mit einem neueren Scan zurück. "~"-Zeilen älter als 30 Min. zählen nicht mehr für den Sammelkauf.
- **Prognose: Verkäufe aus Rechnungen werden wieder zugeordnet.** In Forever kommt die Post schneller als 1 Std.,
  dadurch lag die Verkaufszeit vor der Einstellung und der Fall galt als "nicht verkauft". Teilverkäufe zählen als
  Anteil. Der Testbericht zeigt je Fall, woher das Ergebnis kommt; die Selbstkorrektur lernt nur mit Fällen nach
  dieser Behebung.
- **Entzauber-Prognose zerlegt**: Chance × Menge × Rest (Preis u. a.) je Gruppe im Testbericht.
- Hintergrund-Aufgaben geben vorausschauend ab (ein Frame wird nicht mehr Budget + ein langer Schritt); "Heute tun"
  rechnet in kleineren Portionen.
- Testroutine: das echte Sync-Adressbuch und ein laufender Sniper-Treffer gelten nicht mehr als Sandbox-FEHLER;
  Pfade im Bericht nennen nie Spielernamen. Preis-Tests ersetzen alle Preisquellen. Sammelkauf mit geplanter Menge.
- Tests T425–T440 (T-X3–T-X8, T-MD1–T-MD6, T-SR8a/b).

## 0.65.87
> ⚠️ **Dies ist eine Beta-Version.** Bitte melde Fehler in den Kommentaren auf CurseForge,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Behoben: Lua-Fehler bei Verkaufs-Meldungen in WoW Forever.** Geschützte ("secret") Chat- und Ereigniswerte
  werden nie mehr gelesen (Verkaufs-Meldung, Kauf, Post, Einstellen, altes Auktionshaus).
- **"Unterbietung prüfen" friert das Spiel nicht mehr ein.** Nur aktive Auktionen, je Item eine Suche, ohne
  Neuaufbau nach jedem Item: die Liste wird EINMAL am Ende neu gezeichnet. Jeder Schritt wird gemessen; Schritte über
  50 ms stehen als LANGSAM im Protokoll.
- **Vollscan-Messung (für den grossen Test).** Der Schnell-Vollscan misst jetzt jeden Schritt (Warten auf den Server,
  Ereignis, Einlesen, Verdichtung, Verfolgung, Preisverlauf/Neuaufbau), die längste Lücke zwischen zwei Frames (die
  echte Hängezeit), Speicher und Speicherbereinigungen. Der Teil "server" der Testroutine startet einen echten
  Schnell-Vollscan (nur lesen) und meldet ihn im Abschnitt "Vollscan-Messung"; ein Schritt oder eine Lücke über 1 s ist
  ein FEHLER mit Schrittname. Sonst ist am Vollscan nichts geändert.
- **Behoben: ein einzelnes 2c-Angebot drückt keine Materialwerte mehr.** Die Preisleiter wird nur mit dem bereinigten
  Scan-Preis gedeckelt, nie mit dem rohen Minimum; ohne bereinigten Preis gilt der Leiter-Wert als "Markt, unsicher".
- **Behoben: Lagerwert zu hoch, wenn alles verkauft ist.** Eine leere Liste eigener Auktionen (abgefragt, alles
  verkauft) heisst jetzt "nichts im AH"; alte Ablaufzeiten und das Prognose-Journal zählen nur, wenn nie abgefragt.
- **Sniper: tote Angebote werden komplett ausgeblendet.** Ein Angebot, dessen Kauf fehlschlug oder das der Server nach
  "weg" wieder liefert, verschwindet für die Sitzung (je auctionID, höchstens 48 Std.): nicht im Sniper, Einkauf,
  Unterbietung, aktuellen Preis, in der Preisleiter aus Suchen, in "% Markt" oder im Sammelkauf. Waren ohne auctionID:
  nach 2 Fehlschlägen. Die Statuszeile zeigt "1 totes Angebot ausgeblendet (Preis, Grund)", Protokoll
  SNIPER-TOT-AUSGEBLENDET. Nach 3 gescheiterten verschiedenen Angeboten desselben Items pausiert das Item 10 Minuten
  (Protokoll SNIPER-PAUSE). Ein neues Angebot zum gleichen Preis bleibt kaufbar.
- **"Nicht entzauberbar" sperrt nicht mehr die ganze Klasse.** Gelernte Sperren gelten je Item; eine Klasse (z. B.
  Lederrüstung) erst, wenn 3 verschiedene Items gescheitert sind. Solche Items stehen jetzt in "Gesperrt (N)" als
  "nicht entzauberbar (Forever)" mit Freigeben; `/ahs entzaubern freigeben` gibt sie auch frei.
- Testroutine: T410–T424 (T-0, T-UP1–3, T-VM1/2, T-X1, T-X2a/b, T-SR7a–c, T-ME10/11), Abdeckungsliste ergänzt.

## 0.65.86
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper: Tote Angebote bleiben weg.**
  - Ein Angebot, dessen Kauf fehlschlug (z. B. „Es liegt bereits ein höheres Gebot vor“), ist über seine Auktions-ID
    10 Minuten gesperrt. Liefert der Server es noch einmal, bleibt es „weg“ (rot) und wird nicht erneut versucht.
  - Eine neue Auktion zum gleichen Preis bleibt kaufbar.
  - Waren ohne Auktions-ID: Dieselbe Kombination aus Preis und Menge wird 60 s übersprungen.
  - Das Protokoll SNIPER-SUCHE zählt „tot wieder geliefert“.
- Testroutine: T409 (T-SR6).

## 0.65.85
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Fehler behoben (wichtig): keine Schein-Flips mehr.**
  - Der Wiederverkaufspreis nimmt nie mehr den geschätzten Preis des Teils oberhalb der gespeicherten Preisleiter.
    Von dort kamen die „11s 39c“ für eine Kiste, die zu 4s verkauft wird.
  - Ohne aktuelle Preisleiter gibt es keinen Flip-Vorschlag.
  - Die Kaufmenge ist höchstens das, was bis zum Kaufpreis wirklich angeboten wird.
- Eine Flip-Zeile in Heute/Flippen erscheint nur, wenn der Detailbereich mit genau derselben Rechnung „kaufen bis X“
  sagt. Sonst fällt sie weg, das Protokoll schreibt FLIP-WIDERSPRUCH.
- Ein Klick auf eine Zeile in „Heute“ zeigt sie jetzt auch im Detailbereich.
- **Zauberstäbe werden nie zum Entzaubern vorgeschlagen** (in WoW Forever nicht möglich). Scheitert ein Entzaubern mit
  „kann nicht entzaubert werden“, ist das Item (und seine Klasse) ab dann überall ausgeschlossen. Das Protokoll
  schreibt DE-NICHT-MOEGLICH.
- Testroutine: T403–T408 (T-F1–T-F4, T-ME8, T-ME9).

## 0.65.84
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Der Sniper sucht wieder von selbst:**
  - Der Schnell-Vollscan (ReplicateItems) sperrt die Item-Suche des Snipers nicht mehr. Eine laufende Einkaufs-Suche
    oder Preisprüfung sperrt höchstens 20 s.
  - Beim Öffnen des AH (auch nach /reload) startet sofort eine Suche.
  - Statt „Noch nichts gesucht“ zeigt der Sniper seinen Stand: „nächste Suche in 12 s · zuletzt vor 40 s: 5 Treffer“
    oder „wartet: Markt-Scan läuft“. Dazu, wenn nötig, „Vollscan-Sperre noch N Min. (Sniper sucht trotzdem)“.
  - Neues Protokoll SNIPER-SUCHE (Ziel-ID, Angebote, Treffer ≤ Max, gekauft, Sperrgrund; ohne Namen).
- **„Kauf fehlgeschlagen“ nur noch einmal:**
  - Dasselbe Angebot wird nur einmal gemeldet. Weitere Fehlschläge innert 30 s kommen als eine Sammelzeile.
  - Das gescheiterte Angebot gilt als „weg“ und wird nicht erneut versucht. Die nächste Raste kauft das nächste
    passende Angebot; ist keines mehr da, startet eine neue Suche.
- Die Warnung „Max über Verkaufswert“ nutzt denselben Wert wie der Tooltip, bei Entzauber-Items also den
  Entzauberwert.
- Testroutine: T399–T402 (T-SR2–T-SR5).

## 0.65.83
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Neue Markt-Ansicht „Entzaubern“:** Teile, die nach dem Entzaubern mindestens 20 % Gewinn bringen – zum aktuellen
  Markt, nach Gebühren.
  - Jede Zeile zeigt: Item (Stufe), den Preis jetzt und die Menge bis „lohnt bis“, den Wert nach Entzaubern, den
    Gewinn je Stück und in %, dazu die Sicherheit (grün = echte Ergebnisse, grau = Tabelle).
  - Der Knopf „Kaufen“ legt ein Sniper-Ziel an (Max = lohnt bis, Menge, Budget). Gekauft wird nie ohne Klick.
- Filter:
  - Nur Teile, die dein Charakter entzaubern kann (Fertigkeit Verzauberkunst).
  - Mindestgewinn 20 %, in den Optionen einstellbar (10–50 %).
  - Das Markt-Budget gilt (25 % des Golds).
  - Keine Zeile, wenn das wichtigste Material eingebrochen oder überflutet ist. Gelb, wenn der Wert an einem frisch
    gestiegenen Materialpreis hängt.
  - Der Absatz der Materialien gilt nur als Sicherheitsnetz: Erst wenn deine Menge samt Lager mehr als einen Tag
    Absatz ausmacht, wird gekürzt (mit gelbem Hinweis).
- Detail rechts: Materialien mit Chance, Ø-Menge, aktuellem Preis und Hinweis, deine Ergebnisse der Gruppe und „lohnt
  bis“.
- Die Fusszeile zeigt nur den aktuellen Kauf (die gewählte Zeile), keine Summe aller Zeilen.
- Testbericht: Median-Dauer bis Verkauf je Material (aus dem Prognose-Journal).
- Testroutine: T392–T398 (T-ME1–T-ME7).

## 0.65.82
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Preise aus dem aktuellen Markt (dein Entscheid):**
  - Werte kommen nur noch aus der aktuellen Preisleiter und dem Absatz. Es gibt keinen Deckel und kein Mischen mehr
    mit dem Marktwert (Durchschnitt).
  - Der Marktwert ist nur noch eine Warnung: „Preis frisch gestiegen (seit N Std.)“, „Preis eingebrochen (seit N
    Std.)“, „alt (vor N Std.)“, wenn der letzte Scan älter als 2 Std. ist, und „geschätzt“, wenn es gar keinen Scan
    gibt. Die Zahl selbst ändert sich dabei nicht.
  - Mit Shift steht die Quelle dabei, z. B. „Preisleiter, 311 Stück, Absatz ~20/Tag · Marktwert …“.
- **Der Markt rechnet höchstens mit 25 % deines Golds (dein Entscheid):**
  - Das gilt für alle Kaufvorschläge zusammen (Heute, Flippen, Händler). Der beste Gewinn pro Gold kommt zuerst.
    Passt ein Vorschlag nicht mehr ganz, wird er gekürzt, sonst fällt er weg.
  - Die Fusszeile zeigt „Kapitalbedarf X von Y (höchstens 25 %)“.
  - Neue Option „Markt: höchstens % des Golds“ (Standard 25, höchstens 50). Das Tagesbudget je Strategie richtet
    sich danach.
- **Unplausibler Absatz:**
  - Es gilt höchstens 2× die Ø-Menge pro Tag und höchstens 25 % des aktuellen Angebots pro Stunde. Gemessene Werte
    darüber werden nicht verwendet, das Protokoll schreibt ABSATZ-UNPLAUSIBEL.
  - Flip-Texte sagen „geschätzt“ oder „gemessen, N Tage“.
- **Kopf der Buchhaltung:**
  - Die Lager-Kachel zeigt „Lager X (davon im AH Y) − zu Beginn Z“. Der Tooltip rechnet vor: „Kasse + Lager − Lager
    zu Beginn = Ergebnis“.
  - Käufe für Berufe (gekaufte Handwerkswaren, die weg sind) stehen getrennt: „Handel ±A · Berufe −B“.
  - Laufende eigene Auktionen zählen auch aus dem Prognose-Journal, wenn das AH nicht abgefragt wurde.
- Testroutine: T371 (T-AM1), T384–T391 (T-AM3/4, T-K1–3, T-LG6–8).

## 0.65.81
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Fehler behoben (wichtig): Materialpreise beim Entzaubern ehrlich.**
  - Der Materialpreis ist der realistische Verkaufspreis aus Preisleiter und Absatz. Er wird nicht mehr auf den
    Marktwert gedeckelt.
  - Der Tooltip nennt die Quelle: „Scan“ nur bei Werten aus dem Scan, sonst „Markt“ oder „Preis frisch gestiegen (seit
    N Std.)“.
  - Liegen Scan und Marktwert mehr als 50 % auseinander, ist der Preis grau „unsicher“. Mit Shift siehst du beide Werte.
  - Ein frischer Preissprung (unter 24 Std.) zählt höchstens 1,5× den Marktwert. Ab 24 Std. gilt der Leiterpreis, das
    Protokoll schreibt MARKTWERT-CHECK.
  - Lockangebote (1–2 Stück weit unter dem Median) ziehen den Marktwert im Preisverlauf nicht mehr hinunter.
- **Entzauber-Sperrliste mit Weg zurück:**
  - Ein Rechtsklick fragt nach: „Ja / Nur diesmal überspringen / Abbrechen“.
  - Der neue Knopf „Gesperrt (N)“ öffnet eine Liste. Dort gibst du einzelne Items oder alle wieder frei.
  - Das leere Fenster nennt, wie viele Items gesperrt oder übersprungen sind.
  - `/ahs entzaubern freigeben` gibt alle frei.
- Tempo: Die volle Prognose-Auswertung läuft nicht mehr im Tooltip und nicht mehr nach Buchungen. Sie wird im
  Hintergrund in Portionen gerechnet, der Tooltip liest den Zwischenspeicher.
- Vollscan:
  - `/ahs vollscan messen` misst einmal je Sitzung einen kürzeren Abstand (mit Rückfrage).
  - Die Wartemeldung behauptet keine Server-Grenze mehr, sondern sagt „vorsichtshalber, noch nicht gemessen“.
- Die Kauf-Prognose „Wiederverkauf“ rechnet mit dem realistischen Wiederverkaufspreis.
- Sync: Alte Scan-Ankündigungen werden aufgeräumt.
- Veraltete Texte zur Gebühr und unbenutzte Schlüssel entfernt.
- Testroutine:
  - Neu sind T369–T383 (T-HF9–11, H5, T-SK1/2/5, T-SP1–4, Prüfung Hintergrund-Aufgaben unter 16 ms,
    Tooltip-Prüfung mit 3000 Einträgen).
  - Der Entzauber-Bericht hat eine Erklärzeile „gelernt gegen Verlauf“.

## 0.65.80
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Fehler behoben (wichtig): Lager in der Buchhaltung.** „Ergebnis mit Lager“ zeigte −9g 60s und „Lager −8s 22c“,
  obwohl rund 4,7g Ware in den Taschen lag. Jetzt gilt:
  - Der Lagerwert ist nie negativ. Taschen und Bank zählen zum realistischen Verkaufspreis nach Gebühren, mindestens
    zum Händlerpreis. Dazu kommen deine laufenden Auktionen (Angebotspreis × 0,95, die Einzahlung ist schon bezahlt).
  - Der Stand zu Tagesbeginn wird als Stückliste gespeichert und ebenfalls zum heutigen Preis bewertet. Die Kachel
    zeigt so das „Ergebnis, wenn alles zum heutigen Preis verkauft wird“.
  - Die Kachel zeigt „Lager X (davon im AH Y)“. Unter „Pro Item“ gibt es die neue Spalte „im AH“.
- Entzauber-Abrechnung je Charge und gesamt: Kauf, Beute verkauft / im AH / Lager, Gebühren, Ergebnis.
- **Fehler behoben (wichtig): Käufe werden genau einmal gebucht.**
  - Ein Kauf-Ereignis bucht nur den Kauf mit derselben Auktions-ID. Vorher konnte ein verspätetes Ereignis einen
    anderen Kauf erwischen. Jede Auktion wird höchstens einmal gebucht.
  - Kauf-Rechnungen in Forever: Die Menge ist nie 0, der Gesamtbetrag kommt aus der Rechnung.
  - Rechnung und Kaufmeldung werden über Item und Menge zugeordnet, auch wenn der Betrag abweicht. Dann gilt der
    Betrag der Rechnung, und das Protokoll schreibt KAUF-DOPPELT.
  - `/ahs doppelt` zeigt mögliche alte Doppelbuchungen. `/ahs doppelt bereinigen` bereinigt eindeutige Paare mit
    Sicherung, `/ahs doppelt zurück` macht das rückgängig.
- Testroutine: T364–T368 (T-LG1–T-LG5).

## 0.65.79
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Die Testroutine fasst deine Entzauber-Daten nie an.** Tests zum Zurücksetzen und Wiederherstellen laufen jetzt nur
  noch auf Ersatztabellen. Das gilt auch für den Optionstest „Entzaubern zurücksetzen“ und die Sicherung `deBackup`.
- **Der gemessene Absatz aus dem Vollscan war viel zu hoch (10–20×).** Bei Waren (stapelbar) ergab ein Teilkauf eine
  neue Signatur, dann zählte der ganze alte Stapel als „weg“. Jetzt gilt:
  - Waren werden nach Menge je Stückpreis verglichen. Es zählen nur Preisstufen bis Mindestpreis + 2 %, und
    Neueinstellungen zum gleichen Preis werden gegengerechnet.
  - Der Absatz pro Tag wird erst ab 6 Stunden Abdeckung hochgerechnet, vorher heisst es „zu kurz“.
  - Eine Plausibilitätsgrenze (höchstens 2× die Ø-Menge im AH) markiert unplausible Werte und schreibt sie ins
    Protokoll.
  - Raten aus älteren Versionen (zu kurze Paare) werden nicht mehr verwendet.
- Vollscan lesen: Die Uhr wird alle 25 Einträge geprüft, mit 5 ms je Frame (Ziel: längster Frame ≤ 8 ms).
- Testroutine: Die Rangliste (T169) misst nur noch die eigene Aufgabe, andere Aufgaben werden genannt. Die
  Zählkontrolle beim Entzaubern vergleicht nur Einträge ab Beginn der Zählung (kein falscher Alarm mehr).
- Testroutine: T360–T363 (T-W1, T-W2, T-W5).

## 0.65.78
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Fehler behoben (wichtig): Entzauber-Käufe werden realistisch bewertet.** Die Materialpreise nutzen jetzt denselben
  realistischen Wiederverkaufspreis wie die Flips (Preisleiter und Absatz pro Tag), nach AH-Anteil und erwarteten
  Einzahlungsverlusten. Viele gekaufte Teile senken den Preis: Liegt dein Material über dem Absatz von zwei Tagen,
  zählt jede weitere Tagesmenge eine Stufe tiefer. Das gilt für Entzauberwert, „Entzaubern lohnt“, Sammelkauf und
  Entzauber-Schnäppchen.
- Tooltip: Das Urteil zeigt den Gewinn mit Prozent. Mit Shift: „Gewinn nach Verkauf der Materialien: X (Y %)“.
- Buchhaltung -> Entzaubern: Abrechnung je Kauf-Charge, z. B. „Charge 10.11.: bezahlt 5g, verkauft Xg, Lager Yg,
  Gebühren Zg, Ergebnis ±Wg“. Mit der Maus siehst du alle Chargen.
- **Meine Auktionen:** „8 verkauft (4g 42s 77c, erhalten 4g 20s 60c)“. Erhalten = je Auktion Gesamt × 0,95,
  abgerundet. Eine Fusszeile zeigt die Summen der Liste je Status. Mit Shift zeigt der Tooltip am Kopf, wie viel
  heute insgesamt verkauft wurde (aus der Buchhaltung).
- **Sniper:** „Ergebnis ist veraltet – in dieser Suche gekauft: 23 Stück für 2g 30s · verpasst 13 – neue Suche
  nötig.“ Die Zielzeile zeigt „50/100 gekauft · Budget 5g aufgebraucht“ (bzw. „Budget übrig …“) ganz. Ist das
  Budget aufgebraucht, kommt einmal eine Meldung im Chat und eine Kopfzeile. Das Ziel bleibt in der Liste. Der
  Ziel-Tooltip erklärt, wie viele Stück das Budget hergibt.
- Testroutine: T351–T359 (T-HF8, T-MS1–3, T-SN1–3).

## 0.65.77
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Fehler behoben (wichtig): keine Schein-Flips mehr.** „Heute“ schlug z. B. vor: „Kaufe 4x Instabiles Magiepartikel
  bis 45s 97c, wieder einstellen um 2g 3s“. Im AH lagen aber 855 Stück zu 46–50s, die 2g 3s waren ein veralteter
  Angebotspreis. Jetzt gilt überall EIN realistischer Wiederverkaufspreis (Heute, Flippen, Details, Wächter):
  - Es ist der Preis, vor dem weniger Stück warten, als sich in deiner Laufzeit verkaufen. Die Grundlage ist die
    Preisleiter aus dem Vollscan oder der Suche.
  - Höchstens gilt der gelernte Normalpreis und der Marktwert.
  - Ohne Preisleiter liegt er höchstens 15 % über dem aktuellen Mindestpreis.
- Bei Preissturz oder geflutetem Angebot (3× so viel wie üblich) gibt es keinen Flip. Solche Items erscheinen unter
  „Überfüllt“.
- Liste und Details widersprechen sich nie mehr: Eine Kaufzeile gibt es nur, wenn auch die Details „kaufen bis X“
  sagen.
- Der Flip-Gewinn ist ehrlich: nach AH-Anteil und erwarteten Einzahlungsverlusten. Die Menge ist höchstens so gross,
  wie du mit deinem Marktanteil verkaufen kannst.
- Die Markt-Ansichten bleiben nicht mehr leer, solange der Absatz noch nicht gemessen ist. Dann wird mit dem
  geschätzten Absatz gerechnet und die Zeile grau mit „geschätzt“ markiert. Eine leere Ansicht nennt den Grund.
  Beim Wechsel der Ansicht leert sich der Detailbereich bzw. zeigt die erste Zeile.
- **Meine Auktionen:** In der Kopfzeile steht die Gesamtsumme der verkauften Ware (brutto und nach AH-Anteil).
- Testroutine: T344–T350 (T-HF1–T-HF7).

## 0.65.76
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gesamtprüfung nach allen Stufen:** `/ahs testroutine alles` führt den automatischen Teil aus und danach nacheinander
  die Teile Server, Berufe und Händler. Fehlt ein Fenster, sagt eine Zeile, was zu öffnen ist. Die Routine wartet bis
  2 Minuten und macht dann weiter.
- **Testbericht:**
  - Oben stehen fünf Zeilen Zusammenfassung: OK/Fehler, was im Spiel noch zu tun ist, Prognose-Trefferquote,
    gemessener Absatz für N Items und Speicher.
  - Eine Abdeckungsliste ordnet jedem Auftrag und Testfall seine Prüfungen zu oder sagt, warum er nur im Spiel prüfbar
    ist.
  - Abschnitte mit echten Daten: Entzaubern, Prognose-Güte, Vollscan, Lern-Datenbank, Markt-Reiter und Messreihe.
  - Die Sandbox vergleicht alle echten Tabellen, auch Journal, Lernen und Vollscan.
  - Speichergrössen und Ladezeit stehen im Bericht.
- **Messreihe „Ausrüstung in ganzen Silbern“** (`/ahs messreihe`, nur mit deiner Zustimmung): Mit ein paar billigen
  grauen/weissen Ausrüstungsteilen wird eingestellt:
  - zu 1s 00c, 1s 01c, 1s 50c, 1s 99c, 2s, 10s 50c und 1g 00s 01c
  - einmal mit Gebot
  - dazu eine Ware zu 1s 99c

  Jede Einstellung wird sofort wieder abgebrochen. Jeder Schritt ist ein Klick, höchstens 10 Einstellungen, die
  Kosten werden vorher gezeigt. Das Ergebnis kommt ins Protokoll und in den Testbericht. Die Preisrundung bleibt, bis
  die Messung etwas anderes belegt.
- Preis-Sync: Eine unvollständige Preisliste aus dem Netz hält ein Gildenmitglied mit vollem Scan nicht mehr vom
  Antworten ab.

## 0.65.75
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Neuer Reiter „Markt“ ersetzt „Heute tun“ (Stufe 3):** eine Leiste mit 6 Ansichten:
  - **Heute**: das bisherige „Heute tun“, deine Sachen zuerst, darunter die besten Chancen.
  - **Flippen**: unter deiner Kaufgrenze, sortiert nach Gewinn je Gold und Tag.
  - **Händler**: Sofortkauf unter dem Händlerpreis.
  - **Lücken**: wenig Angebot, stetiger Absatz, Preis steigt. Dein Lager steht oben.
  - **Überfüllt**: nicht einstellen. Viel mehr Angebot als Absatz, mit Tagen bis zum Verkauf und dem
    Einzahlungsrisiko.
  - **Trends**: stabile Bewegungen über 7 und 30 Tage, fallende Leveling-Waren zuerst.

  Jede Ansicht hat eine Erklärzeile, höchstens 20 Zeilen, eine Zahl, die Sicherheit als Farbe und einen Knopf. Der
  Knopf arbeitet wie bisher: Prüfen -> Kaufen -> Einstellen, nie ohne deinen Klick.
- **Details rechts:** Zeile anklicken oder oben ein Item suchen. Du siehst:
  - Preis und Angebot über 14 Tage
  - die Preisleiter
  - deine eigene Geschichte
  - die gelernten Preisgrenzen
  - EINE Empfehlung („kaufen bis X“ / „einstellen für Y“ / „liegen lassen“) mit Begründung
  - Knöpfe für Watchlist, Einkaufsliste, Sniper (mit vorgeschlagener Grenze) und Preisverlauf
- **Markt heute:** Ein Preis-Index typischer Waren steht oben („Markt heute +3 % (7 Tage +8 %)“).
- Die Liste aller Items ist aus der Reiterleiste verschwunden. Die Daten bleiben, alle Ansichten rechnen damit.
  Nachschlagen geht über die Suche.
- `/ahs heute`, der Knopf „Heute tun“ und andere Addons öffnen den Markt auf „Heute“. Das gilt auch für die Zeilen von
  ProfessionSentinel (QuickBuy/QuickSell), die oben stehen. Neue Option: „Markt: Standard-Ansicht“.
- Testroutine: neuer Teil „m“ (Markt) und der Abschnitt „Markt-Reiter“ im Bericht.

## 0.65.74
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Lern-Datenbank (Stufe 2, unsichtbar):** AHSentinel lernt jetzt im Hintergrund aus deinen eigenen Ergebnissen. Es gibt
  nichts Neues zu bedienen, nur bessere Zahlen in dem, was du schon benutzt. Die Option „Lernen“ (an) schaltet alles
  wieder ab.
  - Verkaufschance je Preislage (Preis ÷ Marktwert) und Laufzeit. Abgelaufene und abgebrochene Auktionen zählen als
    „nicht verkauft“ und werden nie weggelassen. Wenige eigene Fälle werden zur Warengruppe gezogen, dann zu den
    geteilten Zahlen aller Spieler (Sync, nur Zähler, keine Namen), dann zu einem Startwert.
  - Preisgrenzen je Item: Der Verkaufen-Reiter schlägt den gelernten Normalpreis vor, wenn niemand mitbietet oder die
    Konkurrenz über deinem Maximum liegt. Das Minimum rechnet Gebühr und erwartete Einzahlungsverluste mit ein.
  - Verkaufen: „Verkauft sich in dieser Laufzeit nur ~N – Rest in der Tasche lassen.“ Meine Auktionen: „teurer möglich“,
    wenn die günstigere Konkurrenz weg ist. Abgebrochen wird nur mit deinem Klick.
  - Sicherer kaufen: Wächter, Sammelkauf, Flips und Entzauber-Schnäppchen nehmen eine Sicherheitsmarge aus dem
    gemessenen Fehler (20 % bis 20 Käufe, danach mindestens 10 %). Dazu kommt ein Tagesbudget je Strategie (10 % deines
    Golds), solange ihre Trefferquote unter 60 % liegt.
  - Heute tun: ein Hinweis, wenn Gekauftes mehr als 25 % an Wert verloren hat („jetzt verkaufen bringt X, warten
    erwartet Y“).
  - Seltene Items: Der eigene Absatz wird mit Croston geschätzt. Der Markt-Absatz nimmt einen gelernten Faktor je Gruppe
    (aus dem Vollscan) statt des festen 20-%-Deckels.
  - Selbstkorrektur jede Woche oder alle 50 neuen Ergebnisse (gedämpft ±30 %, Protokoll „LERNEN“). Den Rhythmus
    (günstige/teure Stunde und Wochentag) gibt es ab 21 Tagen und nur, wenn er stabil ist.
  - Option „Ausprobieren (+5 %)“ (aus): Jede 10. Einstellung schlägt 5 % mehr vor, um die Preisempfindlichkeit zu
    lernen.
- Tooltip (Shift): „Verkaufschance zum Marktwert: 72 % (gelernt aus 23 eigenen Verkäufen)“, dazu der Rhythmus, wenn er
  bekannt ist.
- Testroutine: neuer Teil „l“ (Lernen) mit festen Zahlen. Bericht und GSTEST1 bekommen den Abschnitt „Lern-Datenbank“.

## 0.65.73
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Schnell-Vollscan (neue Option, Standard aus):** Im modernen Auktionshaus (WoW Forever) liest der Scan-Knopf auf
  Wunsch alle Einzelauktionen auf einmal mit ihrer Restzeit (ReplicateItems), statt Seite für Seite zu blättern. Gelesen
  wird in kleinen Portionen, das Spiel bleibt flüssig. Höchstens alle 15 Minuten, sonst läuft der normale Scan.
  `/ahs vollscan` startet ihn einmal. Preise, Marktwert und Verlauf bekommen dieselben Werte wie bisher (Mindestpreis,
  Menge; Lockangebote zählen nicht).
- **Exakte Warteschlange:** „Wie viele sind vor mir?“ zählt jetzt nur die Stück zu deinem Preis oder billiger
  (Preisleiter aus dem Vollscan) statt aller Stück des Items.
- **Echter Markt-Absatz gemessen:** Zwischen zwei Vollscans vergleicht AHSentinel die Auktionen (Menge und
  Sofortkauf, keine Namen). Vorzeitig weg mit langer Restzeit = gekauft oder abgebrochen, weg mit kurzer Restzeit =
  abgelaufen (kein Verkauf). Ab 3 Tagen Daten zeigt der Tooltip (Shift) „~12/Tag (gemessen, 5 Tage)“ statt der alten
  Schätzung, bis dahin „(geschätzt)“. Deine eigenen Auktionen dienen als Gegenprobe (Anteil Abbrüche).
- Era/TBC: unverändert (das alte Auktionshaus hat keinen Vollscan).
- Testroutine: neuer Teil „v“ (Vollscan) mit festen Zahlen. Bericht und GSTEST1 bekommen den Abschnitt „Vollscan“
  (Zeit je Frame, Drosselung, Bedeutung der Restzeit-Stufen, gemessener Absatz).

## 0.65.72
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Prognose-Journal (Stufe 1 „jede Vorhersage nachprüfen“):** Beim Einstellen, Kaufen und Entzaubern merkt sich
  AHSentinel im Hintergrund, was es in diesem Moment vorhergesagt hat (Verkaufschance in der Laufzeit, Stunden bis
  Verkauf, Einstellungen, Netto-Wert; beim Kauf den geplanten Weg, beim Entzaubern den erwarteten Materialwert). Später
  ordnet es das Ergebnis zu: Verkaufsrechnungen (älteste Einstellung zuerst, Teilverkäufe anteilig), abgelaufene und
  abgebrochene Auktionen (zählen als „nicht verkauft“, werden nie weggelassen), Entzauber-Beute und was aus gekauften
  Waren wurde. Ohne Namen, kompakt (höchstens 3000 Einträge, älter als 60 Tage nur noch in einer kleinen
  Zusammenfassung). Buchhaltung, Entzauber-Ergebnisse und Preisverlauf werden nur gelesen, nie geändert.
- **Tooltip (Shift):** ab 20 eigenen Ergebnissen in der Warengruppe: „Prognosen bei dir: X % zutreffend (N …)“.
- **Testroutine:** neuer Teil „p“ (Prognose) mit festen Zahlen (Brier-Score, Zuverlässigkeits-Tabelle, FIFO,
  Teilverkauf, Ablauf, Abbruch, Ringpuffer, Grösse < 300 KB, keine Namen); Bericht und GSTEST1-Export bekommen den
  Abschnitt „Prognose-Güte“ aus deinen echten Daten (nur lesen).
- Messungen: welche Replicate-Funktionen es gibt (nur geprüft, nie aufgerufen), welche Felder die Item-Suche liefert,
  und der Mindestpreis/die Menge je Stunde des Tages für Items, die du handelst oder beobachtest (später ausgewertet).

## 0.65.71
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauber-Statistik:** Abgelehnte Ergebnisse (Material ausserhalb der Tabelle) zählen als entzaubert, ihre Beute
  zählt mit, sie stehen aber getrennt: „(davon abgelehnt N)“. Fürs Lernen zählen sie nie.
- **Entzauber-Ergebnisse wiederherstellen:** Nach dem Zurücksetzen wird der Knopf in den Optionen zu „Wiederherstellen“
  und holt die letzte Sicherung exakt zurück.
- **Schnellerer Tooltip:** Das Preisdiagramm unter dem Tooltip wird nur neu gezeichnet, wenn sich Item oder Daten
  geändert haben.
- **Testroutine:** Die Tempo-Prüfung des Tooltips zeigt die Zeit je Block; am Ende des Berichts steht in einer Zeile, was
  für die übersprungenen Teile zu tun ist (z. B. „Auktionshaus öffnen, dann /ahs testroutine server“).

## 0.65.70
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Korrektur: Optionen überlagerten sich** (z. B. „Selbsttest“ über „Standard-Laufzeit“): Es gab mehr Optionen, als in
  zwei Spalten à 18 Zeilen passten. Jede Option hat jetzt ihren eigenen Platz (20 je Spalte, bei Bedarf mehr Spalten).
- **Deine Entzauber-Ergebnisse sind geschützt:** „Zurücksetzen“ (Optionen → Entzaubern gelernt) fragt mit der Zahl der
  Ergebnisse nach und legt vorher eine Sicherung an. Die Testroutine prüft, dass die Entzauber-Daten nach dem Lauf
  unverändert sind (Anzahl und Mengen), und meldet jede Abweichung.
- **Entzaubern:** Beute ganz ohne Entzauber-Material (Mob, Kiste, Kürschnern) zählt nie als Entzaubern; die Beute muss
  innerhalb von 5 Sekunden kommen.
- **Testroutine:** neuer Abschnitt „Entzaubern (echte Daten)“ – je Gruppe eigene/geteilte Ergebnisse, Rate je Material
  gegen die Tabelle (Auffälliges markiert), Zählkontrolle des Tages und Plausibilität; auch im GSTEST1-Export. Neue
  Prüfungen für die ganze Kette (Zauber → Beute → gezählt), die Lernrechnung mit festen Zahlen, geteilte Ergebnisse und
  Werte.
- Tooltip: Quelle der Chancen bei der Entzauber-Gruppe „bis 15“ richtig benannt.

## 0.65.69
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Korrektur: Buchhaltung zeigte den Preis als Menge** (z. B. „verkauft 22000“ für EINE Kappe): Bei manchen
  Forever-Rechnungen ist Feld 5 der Preis, nicht die Menge. Es zählt jetzt nur noch als Menge, wenn es plausibel eine ist
  (bei Ausrüstung nie). Gespeicherte Verkäufe werden einmal repariert (mit Sicherung, Protokoll REPARATUR-MENGE).
- **Korrektur: positive Gebühren in der Buchhaltung:** Eine Erstattung beim Verkauf ohne gebuchte Einzahlung (eingestellt
  über Blizzards Fenster, ein anderes Addon oder vor AHSentinel) wird jetzt durch die passende Einzahlung gedeckt – netto
  0, wie im Spiel. Einstellungen über Blizzards Fenster oder andere Addons werden auch gebucht. Alte Daten werden einmal
  repariert.
- **Entzaubern wird auf jedem Weg gezählt:** Neben Klick in der Tasche und AHSentinels Fenster werden jetzt auch Makros
  und andere Addons (/use Tasche Platz) über den Tascheninhalt erkannt. Ergebnisse mit einem Material ausserhalb der
  Tabelle verschwinden nicht mehr still (Protokoll DE-ABGELEHNT); jedes Entzaubern schreibt DE-GEZÄHLT oder DE-VERPASST.
  Statistik: „heute gezählt N · verpasst M“.
- **Tooltip-Materialien:** gelernte Ø-Menge („Ø 1,4“), den Bereich der Tabelle nur mit Shift; eigene und geteilte
  Ergebnisse getrennt genannt.

## 0.65.68
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Korrektur (0.65.66): Mit der Standard-Laufzeit 2 Std. sah fast alles unverkäuflich aus** – die Bewertung zog bis zu
  sechs verlorene Einzahlungen ab, sobald sich etwas nicht in 14 Std. verkauft (z. B. Staub zeigte „Händler“). Der Reiter
  Verkaufen bleibt bei 2 Std.; die Bewertung rechnet mit 24 Std., wenn das dieselbe Einzahlung kostet (Mindesteinzahlung),
  sonst mit der Standard-Laufzeit. Mit Shift zeigt der Tooltip die benutzte Laufzeit.
- **Sofortkauf fehlgeschlagen – klare Meldung:** „Angebot ist weg (vermutlich schon gekauft)“ statt „Angebot weg oder
  nicht genug Gold“; die Meldung des Spiels steht dabei, Gold wird nur genannt, wenn es wirklich fehlt. Ein verschwundenes
  Angebot wird markiert, sein Knopf gesperrt, und es verschwindet aus der Einkaufsliste. Protokoll-Zeile KAUF-FEHLER (ohne
  Namen).
- **Mindestgebot:** +5 % nur, wenn schon jemand geboten hat; ohne Bieter ist das Startgebot das Mindestgebot. Ist kein
  Gebot unter dem Sofortkauf möglich, ist das Gebotsfeld ausgeblendet.
- **Detailsuche findet nichts, obwohl der Scan das Item führt:** AHSentinel versucht es einmal ohne Itemstufe/Suffix;
  bleibt es leer, verschwindet die Zeile aus der Einkaufsliste (Protokoll DETAIL-LEER).
- Schnittstelle für andere Addons: Preisquelle „scan“ nur, wenn der Preis wirklich im letzten Scan war.
- Testroutine: Knopf-Namen mit Text und Lage; veraltete Gebühren-Texte entfernt.

## 0.65.67
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Korrektur: Die Zeile „110 in den Taschen: …“ erschien nicht** (z. B. Seltsamer Staub): Der Tooltip prüfte „stapelbar“
  mit einer Spielfunktion, die es in WoW Forever nicht gibt. Jetzt geht es mit jedem Taschen-Addon. Kann der Gesamtwert
  nicht gerechnet werden, steht „Verkaufen:“ × Menge da, und das Diagnose-Protokoll bekommt eine Zeile GESAMTWERT.
- **Entzauber-Chancen grüner Items in WoW Forever** nach dem Forever-Leitfaden (wow-professions.com): Rüstung 75/20/5,
  Waffen 20/75/5 (Staub/Essenz/Splitter); bis Itemstufe 15 bleibt 80/20 ohne Splitter. Eigene Ergebnisse zählen weiter
  stärker. Andere Spielversionen behalten die Tabelle von warcraft.wiki.gg.
- **Tooltip:** „Materialien (Tabelle + N eigene)“, wenn eigene Entzauber-Ergebnisse eingerechnet sind; mit Shift die
  Quelle der Chancen. Diagnose-Protokoll: eine Zeile DE-CHANCEN je Gruppe und Tag (Tabelle gegen echte Ergebnisse).

## 0.65.66
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Neue Option „Standard-Laufzeit“ (Standard: 2 Std. in WoW Forever):** Jedes neue Item im Reiter Verkaufen steht
  darauf; eine von Hand gewählte Dauer gilt nur für dieses Einstellen. Serie, Neu einstellen und „Heute tun“ nehmen sie
  auch, ebenso alle Rechnungen. „24 Std. kostet gleich viel“ bleibt nur ein Hinweis.
- **Korrektur: „Heute tun“ riet, Waren beim Händler zu verkaufen** (z. B. Leinenstoffballen), weil es 1 Stück je
  Auktion annahm: Im modernen Auktionshaus wird eine Ware als EINE Auktion mit beliebiger Menge eingestellt – die
  Mindesteinzahlung fällt einmal an. Im alten Auktionshaus (Era/TBC) bleiben die Stapel.
- **Absatz bei überfüllten Items:** Auktionen laufen in WoW Forever höchstens 24 Std., also verschwindet fast alles jeden
  Tag, auch ohne Verkauf. Der Markt-Absatz ist jetzt höchstens 20 % der Menge im letzten Scan pro Tag (Annahme, wird im
  Diagnose-Protokoll geprüft). Deine eigene Erfahrung (eingestellt gegen verkauft, ab 3 Einstellungen) geht vor –
  dieselbe Zahl in Tooltip, Gewinn-Fenster und Protokoll.
- **Gewinn-Fenster:** zeigt in WoW Forever die Einzahlung je Auktion (zurück bei Verkauf) und die erwartete Zahl der
  Einstellungen mit dem erwarteten Einzahlungsverlust.
- **„Heute tun“: Klick auf eine Zeile** bewirkt immer etwas Sichtbares – oder zeigt einen Hinweis; Fehler werden nicht
  mehr verschluckt.
- Diagnose-Protokoll: ABSATZ mit Rohwert, Deckel, eigener Quote und Laufzeit; neue Zeile ENTZAUBERWERT (Materialien,
  Chancen, netto).
- Testroutine: Wächter-Einstellung bleibt unberührt (Sandbox), Tooltips im Ergebnisfenster neben dem Fenster, T33 immer
  mit Grund, T52 prüft „unterboten“ und „liegen lassen“ getrennt, T27 nennt den wahren Grund, leere Rahmen anderer Addons
  sind nur ein Hinweis.

## 0.65.65
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Korrektur: Ausrüstung einstellen scheiterte mit „Interner Auktion-Fehler“** (WoW Forever): Der Server nimmt
  Einzelstücke (Ausrüstung) nur in ganzen Silber an. AHSentinel rundet den Preis von Einzelstücken auf ganze Silber ab
  (mindestens 1s) und zeigt ihn im Feld; Unterbieten bei Einzelstücken mit „−1 Silber“. Waren behalten Kupferpreise.
- **Korrektur: Staub und Essenzen „verkauften sich kaum“** (0.65.63): Der Absatz kommt jetzt immer vom Markt; deine
  eigenen Verkäufe erhöhen ihn nur, und was du selbst regelmässig verkaufst, gilt nie als „kaum“.
- **„Heute tun“ stockt nicht mehr:** Die Schleife über die Entzauber-Angebote pausiert jetzt in kleinen Portionen; das
  Diagnose-Protokoll zeigt bei langsamen Hintergrund-Aufgaben die Schritte je Frame.
- **Neu: Befehlsliste beim Tippen:** Tippst du im Chat /ahs, erscheinen über dem Eingabefeld alle Befehle – die
  meistbenutzten oben; Weitertippen filtert, Klick führt aus. AHSentinel schreibt nie ins Chat-Eingabefeld. Abschaltbar
  in den Optionen („Befehlsliste beim Tippen“).

## 0.65.64
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung: „Gewinn“ heisst jetzt „Kasse“** – Einnahmen minus Ausgaben minus Gebühren. Gekaufte Materialien zählen
  als Ausgabe, auch wenn sie noch im Lager liegen (z. B. Stoff, der durch Herstellen und Entzaubern zu Staub wurde).
- **Neue Kachel „Ergebnis mit Lager“:** Kasse plus die Änderung des Lagerwerts im Zeitraum (Taschen, Bank und laufende
  Auktionen dieses Charakters, bewertet wie „Verkaufen:“ im Tooltip). Ein Lagerstand wird beim ersten Einloggen des Tages
  und beim Ausloggen gespeichert, mit den Preisen von damals. Ohne Stand zu Beginn steht „–“.
- **„Pro Item“ hat eine Spalte „im Lager“** (Stück jetzt).
- „1 Verkauf“ / „1 Kauf“ statt „1 Verkäufe“.
- **Tooltip:** Ein Preis, der nicht im letzten Scan war, ist mit „(alt)“ gekennzeichnet; wurde ein Scan-Preis als
  Ausreisser ersetzt, steht der Rechenwert daneben.

## 0.65.63
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Verkaufen wird nach Angebot und Absatz bewertet:** Wie viele Stück zu deinem Preis oder billiger im AH liegen (ohne
  Lockangebote und eigene Auktionen) und wie viele pro Tag verkauft werden, ergibt die Wartezeit und die erwarteten
  Einstellungen; jede Einstellung ohne Verkauf kostet in WoW Forever die Einzahlung. Dauert es länger als 7 Tage,
  „verkauft sich kaum“ – Verkaufen ist dann nicht der beste Weg (Händler oder Entzaubern). Eine Zahl überall: Tooltip,
  Gewinn-Fenster, Beste Rezepte, „Heute tun“ und die Schnittstelle. Mit Shift zeigt der Tooltip die Begründung, z. B.
  „150 im AH · ~5/Tag · ~30 Tage · verkauft sich kaum“. Die Absatz-Schätzung (verschwunden = halb verkauft) ist eine
  Annahme und wird im Diagnose-Protokoll geprüft.
- **Korrektur: „Meine Auktionen“ zeigte bei aktiven Waren falsche Preise** (z. B. 0c oder 2c je Stück): Das Spiel meldet
  bei aktiven Waren den Preis je Stück. Preis, Gesamt, der „Wert“ in der Kopfzeile und das Erkennen von Unterbietungen
  stimmen jetzt.
- **Tooltip mit Shift:** Was du besitzt, steht mit eigener Überschrift („Im Besitz:“), mit dem Wert in den Taschen und
  dem Bestand deiner anderen Charaktere.

## 0.65.62
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Item-Tooltip zeigt den Wert von allem in den Taschen:** Bei stapelbaren Items ab 2 Stück steht unter „Verkaufen:“
  eine zweite Zeile mit dem Gesamtwert aller Stapel (z. B. „386 in den Taschen: 2g 0s 72c“), gerechnet wie „Verkaufen:“
  für die ganze Menge (bzw. der Händlerwert, wenn der Händler mehr zahlt). Die Bank zählt nicht mit.
- **Ausrüstung einstellen – Diagnose:** In WoW Forever scheitert das Einstellen von Ausrüstung über AHSentinel mit
  „Interner Auktion-Fehler“, Blizzards Fenster geht. AHSentinel schreibt jetzt ins Diagnose-Protokoll, was Blizzards
  Fenster an den Server schickt und was AHSentinel schickt (nur Typen und Zahlen, keine Namen), damit der Aufruf gleich
  gebaut werden kann.
- **Echte Fehlermeldung beim Einstellen:** Es erscheint die Meldung des Spiels (z. B. „Interner Auktion-Fehler“) statt
  „zu wenig Gold oder Item nicht verfügbar“; Fehlversuche stehen im Diagnose-Protokoll.
- **Verkaufen-Reiter:** Ein leeres Mengenfeld gilt als 1 (es zeigte eine graue 1, stellte aber nicht ein).

## 0.65.61
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Korrektur: „Heute tun“ konnte Vorschläge verlieren und nach dem Einloggen kurz stocken** (Protokoll: 413 ms in einem
  Frame). Hintergrund-Rechnungen konnten in einem geschützten Aufruf nicht pausieren (Lua 5.1): Vorschläge „unter
  Händlerpreis“ und Flips fielen still weg, der Rest lief am Stück. Jetzt wird richtig pausiert und nichts geht verloren.
- **Korrektur: Buchhaltung → „Werte stimmen?“ (Vorhersage gegen Verkauf) war in WoW Forever falsch:** Der echte
  Stückpreis kam aus dem Mengenfeld der Rechnung („echt 1“, +7800 %). Jetzt Gesamt / Menge; bisherige Verkäufe werden
  einmal neu gerechnet.
- **Gewinn-Fenster, „Beste Rezepte“:** Nur neue Preise vom Sniper oder Sync bauen die Liste höchstens alle 30 Sekunden
  neu (vorher beim Snipen alle 2 Sekunden). Öffnen, Berufswechsel, Taschen und Buchhaltung aktualisieren weiter sofort.

## 0.65.60
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Hauptfenster öffnet neben dem Auktionshaus** statt darüber, solange du es nicht selbst verschoben hast (und Platz
  auf dem Bildschirm ist).
- **Schnellere Item-Tooltips:** Die AHSentinel-Zeilen werden je Item einige Sekunden zwischengespeichert (Preisdaten,
  Shift, Einstellungen, Watchlist und Taschen zählen mit); der Shift-Teil wird nur mit gedrückter Shift-Taste gerechnet.
- **Testroutine abbrechen:** `/ahs testroutine stop` (oder `abbrechen`) und der Knopf „Abbrechen“ im Ergebnisfenster
  beenden den Lauf; alle Daten werden wiederhergestellt, im Bericht steht „vom Nutzer abgebrochen“.
- Testroutine: Es werden keine echten Daten mehr verändert (eigene Auktionen, Verkäufer-Eintrag, Buchhaltung,
  Sniper-Tageszähler, Entzauber-Protokoll – jeder Test arbeitet jetzt auf einer eigenen Kopie); Sniper und Wächter
  pausieren während der Server-Suchen und kommen danach auf deine Einstellung zurück; eine Zeitüberschreitung nennt den
  Grund (Anfragen pro Minute, Suche, Sniper, Wächter); der Sniper-Test setzt das Maximum unter das günstigste Angebot;
  die Überlappungsprüfung meldet nur Fenster, die AHSentinel selbst platziert (von dir verschobene Fenster und
  unsichtbare Rahmen anderer Addons sind Hinweise).

## 0.65.59
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Korrektur: Buchhaltung → Rendite (Gold pro Stunde) brach mit einem Lua-Fehler ab** („compare nil with number“): Der
  Tagesbeginn wird jetzt ohne time(tabelle) gerechnet, das im Client für „Alles“ nichts zurückgibt. Gleiche Korrektur für
  die Zeiträume der Buchhaltung, das Gold-Diagramm, die Tageszahlen des Snipers und den Raid-Hinweis.
- **Schneller:** Marktliste und „Heute tun“ stocken bei 5000+ Items nicht mehr kurz – sie werden zwischengespeichert und
  nach einem Scan bzw. einer Datenänderung im Hintergrund in kleinen Portionen neu gerechnet (das Fenster aktualisiert sich).
- **Gewinn-Fenster und Beste Rezepte:** „Beste Rezepte“ baut nach dem Herstellen wieder neu auf (Tascheninhalt zählt als
  Änderung); das Gewinn-Fenster liegt nie über dem Berufsfenster, auch nicht über dessen unsichtbarem Rand.
- **Tooltips der AHSentinel-Fenster** erscheinen neben dem Fenster statt über seinen Knöpfen.
- Verkaufs-Meldung: Die Textvorlage des Spiels steht einmal im Diagnose-Protokoll (ohne Namen).
- Testroutine: Während eines Laufs werden keine echten Daten mehr geändert (Aktivität, gemerkte Rezepte, Stück je
  Auktion); der Sniper-Test wertet nur sein eigenes Ziel und zeigt Preis, Max und Einheit; neue Tests (Angebot 2c bei Max
  1c -> kein Treffer; Tagesbeginn ohne time(tabelle)); veraltete Tests angepasst (Verkaufs-Meldung mit „%1$s“, Sync-Empfang,
  Tooltip-Prüfung je Sprache, eigenes Testfenster bei der Überlappung ausgenommen, API-Ereignisse).

## 0.65.58
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Preis-Sync erreicht Spieler ausserhalb der Gilde (GoldSentinelSync 2, Flüster-Netz):** AHSentinel nutzt jetzt
  Version 2 der gemeinsamen GoldSentinel-Sync-Datei. Neben Gilde und Gruppe erreicht es andere Spieler mit
  GoldSentinel-Addons per Flüstern; diese geben weiter. Bekannte Mitspieler werden nur lokal gemerkt (AHSentinelDB.gsSync,
  nur Namen und Zeiten).
  - **Was ins Netz geht:** nur Preise nach deinem eigenen Scan, gebündelt – die meistgehandelten Items zuerst, höchstens
    20 Nachrichten und höchstens alle 30 Minuten (das Netz schickt höchstens 40 Flüsternachrichten pro Minute).
  - **Nur Gilde/Gruppe:** die ganze Preisliste, Antworten auf Preis-Anfragen, Item-Namen und Entzauber-Ergebnisse.
  - „Nur Gilde“ in den Optionen hält alles in der Gilde (nichts geht ins Netz).
- **GoldSentinelTest 2:** Fehlerberichte an den Entwickler teilen (nur mit Zustimmung, /gstest).
- Diagnose-Protokoll: neue Zeile „NETZ“ (ohne Spielernamen).

## 0.65.57
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Ein Mindestgewinn für alles:** Der automatische Mindestpreis beim Verkaufen und AHSentinel.API.MinProfitPct nehmen
  jetzt deine Einstellung „Mindestrendite“ (wie „Lohnt bis“ im Tooltip, Standard 20 %).
- Für Addon-Autoren: API.Price meldet „scan“ nur, wenn der Wert wirklich aus dem letzten Scan stammt („market“, wenn ein
  Ausreisser durch den Median ersetzt wurde). API.md entspricht dem geklärten Vertrag (MaterialCost = Herstellkosten des
  Produkts, „vendor“ ist kein AH-Preis).
- Texte: Beim Abbrechen ist die Einzahlung weg (auch in WoW Forever); der Tooltip „je Auktion“ im Gewinn-Fenster zeigt die
  gemessene Mindest-Einzahlung statt fest 1s.
- Testroutine: neue Tests für den ganzen Tooltip (mit/ohne Shift, nicht entzauberbar), „echt aus 12 Entzauberungen“, Quelle
  im Materialblock, „Kauf gesendet“ über den echten Bestätigen-Weg, kein Flip-Vorschlag für Items, die sich kaum verkaufen,
  und höchstens 3 Neuaufbauten von „Beste Rezepte“ beim Herstellen.

## 0.65.56
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- Testroutine: Sync-Tests nur noch mit Gilden-Nachrichten (nirgends mehr Kanal-Nachrichten im Addon).

## 0.65.55
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Preis-Sync geht wieder (WoW Forever):** Addon-Nachrichten in eigenen Chat-Kanälen kommen in Forever nie an (der
  Server verweigert sie). AHSentinel benutzt seinen Kanal „AHAPSync“ nicht mehr – verlässt ihn einmal (frei werdender
  Kanalplatz) und teilt Preise, Item-Namen und Entzauber-Ergebnisse nur noch über **Gilde und Gruppe/Raid**, in allen
  Spielversionen. Dafür die gemeinsame GoldSentinel-Datei GoldSentinelSync.lua (wie die anderen GoldSentinel-Addons);
  Nachrichten älterer AHSentinel-Versionen werden weiter verstanden.
- Ehrliche Anzeige: „Sync über Gilde: N Mitspieler“ bzw. „niemand mit AHSentinel online“.
- Neu: **/ahs sync test** – fragt Gilde und Gruppe an und zeigt „N Antworten (Gilde a, Gruppe b)“.
- Diagnose-Protokoll: Sync-Weg, gesendet/empfangen/verworfen und verweigerte Kanal-Nachrichten.

## 0.65.54
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper in vollem Tempo:** Solange der Sniper-Modus AN ist und offene Ziele hat, pausiert der Wächter (kein Abwechseln
  mehr). Der Wächter läuft, wenn der Sniper aus ist oder keine Ziele hat; Wächter-Schnäppchen lassen sich weiter kaufen.
- **Ziele nach Ertrag:** Ziele mit Treffern in den letzten 10 Minuten werden öfter gesucht, Ziele ohne Treffer höchstens
  jede dritte Runde. Kein Ziel fällt heraus.
- **Gemessen:** Der Sniper zeigt „Heute: N Treffer · N gekauft · N verpasst · Ø Reaktion X s“, der Tooltip eines Ziels
  Treffer und Kaufquote. Ab 10 Treffern und unter 20 % gekauft: „Hier sind andere schneller – anderes Ziel wählen?“
  (gelbes „!“). Im Diagnose-Protokoll eine SNIPER-Zeile je Minute mit den Zeiten je Schritt (ohne Namen).

## 0.65.53
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sniper schneller, weiter nach den Regeln:** Jeder Kauf braucht weiterhin einen echten Tastendruck bzw. eine
  Mausrad-Raste – der Sniper reserviert oder kauft nie aus einem Timer (der alte „Sofortkauf“, der ohne Tastendruck
  vorab reserviert hat, ist weg).
  - Einfach weiterscrollen: Jede Raste macht den nächsten Schritt. Rasten, während der Preis geprüft wird, werden still übergangen.
  - Bestätigen ist nur 0,05 s gesperrt (Reservieren weiter 0,3 s).
  - Suchen gleichmässig verteilt (höchstens 90 pro Minute) statt erst alle auf einmal und dann Stillstand.
  - Waren-Treffer gelten nur 3 s als aktuell; ältere werden neu gesucht statt reserviert.
  - Reserviert werden nur Stücke bis zu deinem Max-Preis; liefert der Server weniger, wird genau diese Menge gekauft.
  - Ein anderer AH-Fehler (z. B. von einer Suche) bricht einen laufenden Kauf nicht mehr ab.
- AH-Anteil wie gemessen abgerundet (6279 → 313).

## 0.65.52
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung (WoW Forever): Verkäufe nicht mehr doppelt gebucht.** Nach dem Abholen des Goldes wurde dieselbe
  Verkaufsrechnung noch einmal als neuer Verkauf gelesen (Menge doppelt, Einnahmen −5 %). Der Schlüssel der Rechnung
  enthält das Post-Gold nicht mehr, und eine Rechnung ohne Gold wird nie neu gebucht, wenn sie schon gebucht ist.
  Gesamt = Feld „bid“ der Rechnung (Gegenprobe Gold + AH-Anteil − Einzahlung, solange das Gold noch in der Post ist).
  Vorhandene Doppelbuchungen werden beim Einloggen einmal entfernt („Buchhaltung: N doppelte Verkäufe entfernt“) und
  als Sicherung aufgehoben.
- Diagnose-Protokoll: Die Anzahl Items der Preisdaten stimmt jetzt mit der Statuszeile überein (war nach dem Ausloggen 0).

## 0.65.51
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gewinn-Fenster und ProfessionSentinel:** Solange das Panel von ProfessionSentinel offen ist, blendet sich das
  Gewinn-Fenster von AHSentinel aus (ProfessionSentinel zeigt dieselben Zahlen über AHSentinel.API) und kommt zurück,
  wenn das Panel schliesst.
- **Sniper-Hinweis „Jetzt kaufen“:** nur noch einmal, höchstens 2 Sekunden, oberhalb der Aktionsleisten statt doppelt in
  der Bildschirmmitte über offenen Fenstern.

## 0.65.50
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Für Addon-Autoren – öffentliche Schnittstelle `AHSentinel.API` (Version 1):** global `AHSentinel.API`, Alias
  `AHAnalyzerPro.API`. Funktionen: `Price`, `NetSale`, `Deposit`, `CutPct`, `MaterialCost`, `DisenchantValue`, `BestWay`,
  `SellSpeed`, `MinProfitPct`, `GoldPerHour`, `LastScan`, `Subscribe` (ruft `fn("scan"/"ledger"/"settings")`, höchstens
  einmal je 2 s). Jede Funktion ist sicher (nie ein Lua-Fehler, `nil` wenn unbekannt), Beträge in Kupfer. Einzelheiten in
  `API.md`. Die alten Funktionen (RealPrice, RealValue, AuctionFee, AHFee, ForeverAuctionFee, GetMarketValue, GetCurrent)
  bleiben.
- Automatischer Mindestpreis beim Verkaufen: Mindestgewinn jetzt 20 % (gleicher Standard wie die Schnittstelle).

## 0.65.49
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Buchhaltung → Rendite:** neue Ansicht mit eingesetzt, erlöst, Gewinn und Rendite je Geschäftsart – Flippen (Kauf
  und Verkauf desselben Items), Herstellen (hergestellte Items gegen Materialkosten), Entzaubern (vorhandene Abrechnung)
  und Rohstoffe (Verkauf ohne Kauf). Ein Verkauf zählt zum Geschäft, aus dem das Item stammt, und zu dessen Tag – nicht
  zum Eingang der Post.
- **Gold pro Stunde** je Geschäftsart und gesamt, dazu „Dein Stundenlohn heute“. Es zählt nur aktive Zeit (nur lokal
  gespeichert): am AH und Briefkasten die Zeit zwischen deinen Handlungen, nach der letzten höchstens 2 Min.; Herstellen und
  Entzaubern vom ersten bis zum letzten einer Serie. Pausen über 2 Min., AFK und automatische Scans/Sniper-/Wächter-Läufe
  zählen nicht. Unter 15 Min. gemessen: „zu wenig Daten“. Verlust steht rot mit Minus.
- **Raid-Hinweis:** ab 25.11. höchstens einmal am Tag beim Öffnen des AH: „Raid-Start 9.12.: Verbrauchsgüter und ihre
  Kräuter jetzt günstig einkaufen/herstellen.“ Nach dem 9.12. aus.

## 0.65.48
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Automatischer Mindestpreis beim Verkaufen:** das Höhere aus Händlerpreis nach AH-Anteil und deinen eigenen Kosten
  je Stück (Einkäufe der letzten 30 Tage, sonst Herstellkosten) + 5 %. Ein von Hand gesetzter Mindestpreis hat Vorrang.
  Liegt die Konkurrenz darunter, schlägt das Addon den Mindestpreis vor, mit gelbem Hinweis „Markt liegt unter deinem
  Mindestpreis – einstellen zum Mindestpreis oder warten“ (und „Preis fällt“, wenn der 24-Std.-Trend unter −10 % liegt).
  Du entscheidest – das Preisfeld bleibt frei.
- **3× in Folge abgelaufen:** Im Reiter Verkaufen ein gelber Hinweis mit billigerem Vorschlag, Händlerpreis und den bisher
  verlorenen Einzahlungen. Automatisch passiert nichts.

## 0.65.47
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Abbrechen nur, wenn es sich lohnt:** Eine unterbotene Auktion wird nur zum Abbrechen vorgeschlagen, wenn neu
  Einstellen mehr bringt als die verlorene Einzahlung plus das Risiko der neuen. Eine 1c-Unterbietung steht jetzt grau
  als „unterboten – liegen lassen“, „Nächste unterbotene abbrechen“ überspringt sie. Der Tooltip der Zeile zeigt die Rechnung.
- **Höchstens 90 Suchen pro Minute (WoW Forever):** Alle Suchen (Sniper, Wächter, Scan, Einkauf, Preis prüfen) teilen
  sich ein Fenster von 60 Sekunden unter der Server-Grenze von 100; der Sniper hat Vorrang.
- **Neutrales Auktionshaus (Beutebucht, Gadgetzan, Ewige Warte): 15 % statt 5 %** beim Verkauf – überall, wo der
  Anteil gerechnet wird. Eine Formel-Einzahlung dort steht als „(unsicher)“, bis sie gemessen ist.
- **Sniper:** Liegt dein Max/Stück über dem Netto-Verkaufswert (letzter Scan minus Anteil und Einzahlungsrisiko),
  zeigt ein gelber Hinweis den erwarteten Verlust je Stück. Gesperrt wird nichts.

## 0.65.46
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Mindest-Einzahlung wird gemessen statt fest (WoW Forever):** Blizzard hat angekündigt, das Minimum je Auktion von
  1s auf 1c zu senken. AHSentinel baut 1s nicht mehr fest ein: Die Einzahlung kommt immer zuerst von Blizzard, die
  Formel ist nur Ersatz, und ihr Minimum wird beim Einstellen gelernt, wenn die Formel unter 1s liegt (Protokoll
  „MINDESTEINZAHLUNG gemessen=…“). Sobald 1c gemessen ist, fällt die Vorbelegung „24 Std. kostet gleich viel“ von selbst weg.
- Gewinn-Fenster: Die Zeile AH-Gebühr rechnet kein 1s-Minimum mehr (nur 5 % beim Verkauf – die Einzahlung kommt zurück).

## 0.65.45
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.45** – Buchhaltung korrigiert, Werte aus dem letzten Scan 🔧

• **Buchhaltung:** In der Forever-Rechnung steht im Feld „Preis“ die **Menge**. 0.65.42–0.65.44 haben Menge und Stückpreis vertauscht (z. B. 91 Stück zu 1s 84c statt 184 zu 91c). Das ist behoben, alte Verkäufe werden **einmal korrigiert** – nichts wird gelöscht.
• **Werte aus dem letzten Scan:** Gerechnet wird mit dem günstigsten Angebot deines letzten Scans – ohne Abzug, ohne Deckel. Nur offensichtliche Ausreisser (z. B. 1 Stück zu 1c) und Items, die im Scan fehlen, nehmen den Markt-Median. Dein eigener Ø-Verkaufspreis ist nur noch Statistik (Shift).
• Materialien im Tooltip zeigen die Quelle („Scan“ / „Markt“).

## 0.65.44
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.44** – Tooltip übersichtlich, Sniper ehrlich ✨

• **Tooltip in drei Blöcken:** **Preis** (mit „Verkauft sich: schnell/langsam/kaum“), **Urteil** („Entzaubern lohnt sich/nicht“, „Lohnt bis“, beide Wege mit Betrag) und **Materialien** mit echten Chancen – immer, auch mit Disenchantry. Alles andere mit **Shift**.
• **Sniper:** „Kauf gesendet“ beim Bestätigen, **„Gekauft“ erst, wenn der Server es bestätigt**. „Preis wird geprüft“ nur einmal. Ist der Preis bestätigt: kurzer Ton, der Kaufen-Knopf blinkt und „Jetzt kaufen: Mausrad“ erscheint.
• **Sammelkauf** zählt erst nach dem erfolgreichen Kauf.
• **Gewinn-Fenster:** „AH-Gebühr“ zeigt nur die 5 %, Neu-Einstellungen bzw. „Händler zahlt mehr“ in einer grauen Zeile.
• Schneller bei grosser Buchhaltung.

## 0.65.43
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.43** – Laufzeit und Verkaufsdauer ⏱️

• **Verkaufen:** Die **Laufzeit ist vorbelegt** – 24 Std., wenn es nicht mehr kostet (z. B. Staub, Stoff, Kräuter), sonst nach deiner Verkaufsdauer. Der Grund steht darunter; du kannst sie wie bisher ändern.
• **Tooltip:** „Verkauft sich: **schnell** (~3 Std.)“, „**langsam** (~2 Tage)“ oder „**kaum** (läuft oft ab)“ – gemessen aus deiner Buchhaltung.
• Was sich bei dir kaum verkauft, wird bei „Heute tun“ nicht mehr vorgeschlagen.

## 0.65.42
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.42** – Gebühren wie im klassischen WoW 🪙

• **Gemessen in Forever:** Beim Einstellen zahlst du eine **Einzahlung** (Händlerpreis × Menge × 5 % je 2 Std., mind. 1s je Auktion). Beim Verkauf gehen **5 %** ab und die **Einzahlung kommt zurück**. Läuft eine Auktion ab, ist die Einzahlung weg – das rechnet AHSentinel jetzt ein.
• **Buchhaltung:** Forever-Rechnungen werden richtig gelesen (Stückpreis, Menge). Alte Verkäufe werden **einmal neu berechnet** – nichts wird gelöscht.
• **Tooltip:** beide Wege mit Betrag, der bessere zuerst: „Entzaubern: 9s 35c“ / „Verkaufen: 8s 99c“.
• **Kein Ruckeln mehr** beim Herstellen („Beste Rezepte“ rechnet seltener und verteilt).

## 0.65.41
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.41** – sehen, ob es sich lohnt 🟢🔴

• **Tooltip:** statt Rechnung ein **farbiges Urteil**: grün „Entzaubern lohnt sich +2s 85c“, rot „Entzaubern lohnt nicht −65c“ oder grau „unsicher“ – darunter **„Lohnt bis 7s 79c“**. Materialien und Rechnung nur mit **Shift**.
• **Gewinn-Fenster:** Materialien über den **günstigsten Weg** (AH, Händler oder selbst herstellen, z. B. Leinenstoffballen aus Leinenstoff). Die Einkaufsliste kauft genau diese Zutaten.
• **Gewinn über den besten Weg:** Verkaufen oder Entzaubern – darunter „bester Weg: …“ und der andere Weg mit Betrag. „Beste Rezepte“ sortiert danach.

## 0.65.40
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.40** – Buchhaltung repariert 🧾

• Verkäufe von **vor 0.65.35** hatten in Forever die Gebühr doppelt abgezogen (z. B. negative Einnahmen „Heute“). Sie werden beim Einloggen **einmal korrigiert** – nichts wird gelöscht. Im Chat: „Buchhaltung: N alte Verkäufe korrigiert“.

## 0.65.39
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.39** – Feinschliff 🧹

• **Kategorien mit drei Ebenen** wie im Blizzard-AH (z. B. Waffen → Einhändig → Äxte).
• **Post an Twinks:** Kategorie per **Menü** wählen statt durch über 50 Einträge zu klicken.
• **Verkaufen:** Preis über dem 100-fachen Marktwert → Rückfrage (Tippfehler? Zahl ohne Zeichen = Gold).
• **Heute tun → unter Händlerpreis:** aus Scan/Suche wird mit **1 Stück** gerechnet – keine zu hohen Gewinne mehr.
• **Entzauber-Ergebnisse teilen:** grosse Statistiken kommen ganz an.
• **Spieltest** übersetzt; S7 zählt nur echtes Herstellen. Testroutine ersetzt keine Blizzard-Funktionen mehr.

## 0.65.38
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.38** – Werte, denen du trauen kannst 🎯

• **Nicht verkaufen kostet:** In Forever kostet jedes Einstellen die Gebühr. Der reale Wert zieht jetzt die erwarteten **Neu-Einstellungen** ab – aus deiner eigenen Verkaufsquote, sonst aus dem Absatz am Markt. Shift im Tooltip zeigt es.
• **Herstellen:** Eigene Materialien zählen mit dem, was du beim Verkauf bekämst; fehlende zum Sofortpreis, Händlerware zum Händlerpreis.
• **Vorhersage gegen Wirklichkeit:** Buchhaltung → Statistik zeigt **„Werte im Schnitt N % zu hoch/tief“** – je Item-Gruppe und gesamt.
• **Halbe Scans** gelten nie als vollständig, fehlende Items gelten nicht als weg.
• **Geteilte Preise** zählen nur, wenn sie zu deinen passen oder ein zweiter Mitspieler sie bestätigt.

## 0.65.37
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.37** – eigenes Entzauber-Fenster ✨

• **Kleines Entzauber-Fenster** (`/ahs entzaubern` oder Kaufen → „Entzaubern lohnt“ → „Entzauber-Fenster“): nächstes Teil mit Symbol, **„noch N“**, Knöpfe **Entzaubern / Überspringen / Statistik**.
• **Zuerst die gekauften Teile** aus dem Sammelkauf, dann die übrigen. Nach einem Sammelkauf öffnet es sich beim Schliessen des AH einmal von selbst.
• **Ein Klick = ein Teil** (sicherer Knopf, im Kampf gesperrt).
• **Schutz:** nie Set-Teile, Quest-Gegenstände oder Teile auf der Sperrliste (Rechtsklick aufs Symbol). Blaue/violette Teile und Teile, die sich deutlich besser verkaufen, erst nach **„Freigeben“**.
• **Statistik:** Entzauberungen heute/gesamt, Materialien und ihr Wert.
• **Buchhaltung → Entzaubern:** je Tag und gesamt: ausgegeben, Wert der Materialien (schon verkauftes zum echten Erlös), **Gewinn** und **Rendite %**. Eigene Teile getrennt, noch nicht entzauberte als „offen“.

## 0.65.36
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.36** – Entzauber-Wächter 🔮

• Ist der **Schnäppchen-Wächter** an, sucht er bei offenem AH jede zweite Runde **Waffen und Rüstung**, die sich zum Entzaubern lohnen (gleiche Grenzen wie „Entzaubern lohnt“).
• Neue Funde meldet er einmal: **„N Teile mit über X % Rendite verfügbar“** – im Chat und auf dem Bildschirm, höchstens einmal pro Minute, nie im Kampf.
• Er **kauft nie selbst** – gekauft wird wie bisher unter Kaufen → „Entzaubern lohnt“. Abschalten mit dem Knopf **„Wächter-Meldung: AN/AUS“**.

## 0.65.35
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **AH-Gebühr im Gewinn-Fenster – eine sichtbare Annahme:** Die Gebühr hängt davon ab, wie viele Stück du je Auktion
  einstellst (mindestens 1s je Auktion). Das Fenster sagt es jetzt: "bei N Stück je Auktion (gelernt / selbst gewählt
  / vorsichtig)". Gelernt aus deinen eigenen Einstellungen (Median der letzten 10); ohne Daten 1 Stück. Klick darauf
  wechselt 1 / 5 / 20 (Stapel) / automatisch, gemerkt je Item. "Beste Rezepte", "Heute tun" und andere Addons rechnen
  mit derselben Annahme. Das Fenster springt nicht mehr zwischen zwei Rechnungen, wenn Item-Daten spät nachladen.
  (Beispiel: 1 Wollstoffballen zu 3s 97c, Material 3s 42c: Gebühr 1s, Verlust 45c; bei 20 je Auktion: 20c, +35c.)
- **Verkaufen: Menge = alles aus den Taschen** (nicht mehr die letzte Menge). Die Zahl änderst du selbst.
- **Buchhaltung (WoW Forever):** Ein Verkauf wird mit dem Gold gebucht, das die Post wirklich bringt – die Gebühr ist
  schon beim Einstellen gebucht, darum werden keine zweite Gebühr und keine Erstattung abgezogen. Die Werte der
  Rechnung gehen ins Diagnose-Protokoll (RECHNUNG). Abbrechen bucht jetzt die gemessene Erstattung. Era/TBC unverändert.
- Spieltest: neue Prüfung S10 – AH-Gebühr von AHSentinel = Blizzards "Einzahlen" bei gleicher Menge.

## 0.65.34
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sammelkauf zum Entzaubern** (Reiter Kaufen → Einkauf): Der Knopf "Entzaubern lohnt" unter den Kategorien zeigt aus
  deiner Suche nur Teile (Rüstung/Waffen), deren Entzauberungswert den Preis um die Mindestrendite übersteigt, mit
  mindestens 10c Gewinn je Teil – nach Gewinn sortiert, mit Spalten Entzauberungswert, Gewinn und Rendite %.
  - Jede Mausrad-Raste über der Liste oder "Nächstes kaufen" kauft das nächste Teil von oben (die erste Raste lädt
    dessen Angebote). Vor jedem Kauf: Angebot noch da und nicht teurer – sonst übersprungen.
  - Grenzen: "höchstens X Gold" (Standard 5g) und "Rendite ab X %" (Standard 20 %). Stopp bei der Grenze, bei vollen
    Taschen oder im Kampf. Unter 10 echten Entzauberungen der Gruppe zählt der Wert 10 % weniger.
  - Statuszeile: "Gekauft N · bezahlt · erwartet +Gewinn". Nur auf deinen Klick/deine Raste, nie automatisch;
    Protokoll KAUF (ohne Namen). Kein Fertigkeits-Filter – in WoW Forever ist ab Verzauberkunst 1 alles entzauberbar.

## 0.65.33
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **AH-Gebühr im Gewinn-Fenster korrigiert:** Die Gebühr pro Stück ging davon aus, dass du immer einen vollen Stapel
  einstellst (z. B. 20 Wollstoffballen), und teilte die Mindestgebühr 1s durch 20 – so zeigte 1 Ballen zu 3s 98c 20c
  statt der echten 1s. Jetzt richtet sich die Gebühr danach, wie viele Stück du dieses Item zuletzt auf einmal
  eingestellt hast; ohne Erfahrung 1 Stück (volle Mindestgebühr 1s).

## 0.65.32
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauber-Tabelle aus Disenchantry:** Die Tabelle folgt jetzt Disenchantry 1.1.2 (MIT-Lizenz, Copyright (c) 2026
  x_Raven_x; Lizenztext in LICENSE-Disenchantry.txt), Grundlage warcraft.wiki.gg: Itemstufe 5–15 ohne Splitter (80/20),
  21–25 Rüstung 75/15/10, 51–65 Waffen 75/22/3, **WoW Forever: grüne Waffen Itemstufe 21–30 geben Grosse
  Magieessenz**, blaue Items ab Itemstufe 1 und bis 80, epische bis 88. Gruppen nach Itemstufe (wie in der Tabelle),
  nicht nach benötigter Stufe.
- Der Materialblock zeigt jetzt die Mengen aus der Tabelle ("1–2×"), aus echten Entzauberungen den Durchschnitt.
- **Disenchantry geladen:** AHSentinel zeigt keinen zweiten Materialblock.

## 0.65.31
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Ein Preis für alles:** AHSentinel bewertet jedes Item jetzt mit EINER Funktion – Tooltip, Gewinn-Fenster (Ergebnis
  und Materialien), Schnäppchen, Flips, "Heute tun", Entzaubern (Block und Wert), Inventarwert und der Vergleich mit dem
  Händler zeigen für dasselbe Item denselben Wert. Reihenfolge der Quellen: eigene Verkäufe der letzten 14 Tage, dann
  knapp unter dem günstigsten aktuellen Angebot (höchstens der Median), dann der Median 14 Tage. Angebote unter 10 % oder
  über 300 % des Medians zählen nicht. Bei Schnäppchen und Flips gilt das billige Angebot selbst nicht als Wiederverkaufswert.
- **Realer Wert im Tooltip:** neue Zeile "Realer Wert (nach Gebühren)" mit Quelle (eigener Verkauf / AH aktuell / Markt /
  Händler) und "Preis alt" nach 6 Stunden; mit Shift jeder Bestandteil (eigener Verkauf, günstigstes Angebot, Median, Gebühr).
- **Händlerpreis als Untergrenze:** Zahlt ein Händler mehr als das Auktionshaus nach Gebühren, gilt der Händlerpreis.
- Andere Addons (ProfessionSentinel) können dieselben Werte nutzen: `AHAnalyzerPro:RealPrice(itemID)` und
  `AHAnalyzerPro:RealValue(itemID, Menge)`; das alte `GetSalePrice` liefert jetzt denselben Wert.

## 0.65.30
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Preise je Server und Fraktion:** AHSentinel führt jetzt für jeden Server und jedes Auktionshaus eine eigene
  Preisliste – Horde, Allianz und die neutralen Auktionshäuser (Beutebucht, Gadgetzan, Ewige Warte). Eigene Scans und
  geteilte Preise landen nur in der Liste des Auktionshauses, an dem du stehst; Tooltips und Rechnungen nehmen die Liste
  deiner Fraktion (am neutralen Auktionshaus die neutrale).
- **Sync nur vom selben Auktionshaus:** Preis-Nachrichten tragen jetzt eine Kennung von Server und Fraktion; Preise
  einer anderen Fraktion oder eines anderen Servers und alte Nachrichten ohne Kennung werden verworfen. (Bitte
  aktualisieren – ältere Versionen tauschen mit 0.65.30 keine Preise mehr.)
- Deine bisherigen Preise bleiben für Server und Fraktion des aktuellen Charakters. Hast du Charaktere auf mehreren
  Servern oder Fraktionen, weist ein Hinweis darauf hin, dass die alten Preise gemischt sein können – der nächste Scan
  ersetzt sie.

## 0.65.29
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauberungswert statt "Gewinn":** Die Tooltip-Zeile heisst jetzt "Entzauberungswert ~X (T)" – er hängt nur von
  der Gruppe ab (Qualität, Itemstufe, Rüstung/Waffe) und ist für alle Items dieser Gruppe gleich. Neu darunter:
  "Gewinn beim Kauf: Wert − Kaufpreis" (grün/rot) mit dem Preis der Zeile, auf die du im Addon zeigst (Kaufliste,
  Sniper, Schnäppchen), beim Händler dessen Preis, sonst das günstigste aktuelle Angebot. In der Kaufliste steht
  "[Entzaubern lohnt]" nur, wenn Wert − Preis positiv ist.
- **Materialblock passt zum Wert:** Block und Wert rechnen jetzt mit demselben Preis je Material – eigene Verkäufe der
  letzten 14 Tage, sonst knapp unter dem günstigsten aktuellen Angebot (höchstens der Median), sonst der Median. Die
  Quelle steht dabei ("AH aktuell" / "Markt" / "eigener Verkauf"). Angebote unter 10 % oder über 300 % des Medians
  zählen nicht ("Angebot unsicher") – z. B. 22c für eine Grosse Mystikeressenz.
- **Entzauberungen teilen:** nach 10 neuen oder spätestens 2 Minuten nach der letzten, und beim Ausloggen.

## 0.65.28
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Öffnet mit dem Auktionshaus:** Das AHSentinel-Fenster öffnet sich, wenn du das Auktionshaus öffnest, und schliesst
  sich wieder mit ihm. War es vorher schon offen, bleibt es offen. Einstellung "Mit dem Auktionshaus öffnen und
  schliessen" (ab Werk an). Im Kampf drängt es sich nie auf.
- **Fenster immer im Bildschirm:** Das Hauptfenster bleibt ganz im Bildschirm – höchstens 90 % davon, Position an den
  Rand geklemmt, auch nach Änderung der UI-Skalierung oder Auflösung.
- **Sniper in WoW Forever:** Waren kaufst du mit zwei Rasten – 1. Raste reserviert den Preis, 2. Raste kauft (WoW
  Forever erlaubt die Reservierung nur mit Tastendruck). Die Statuszeile sagt das jetzt ("1. …: Preis reservieren ·
  2. …: kaufen", danach "Reserviert – nochmal … zum Kaufen (10 s)"), auch während der Sniper weitersucht; Hilfe und
  Tooltips angepasst. Die Gesamtzeile unter der Liste verschwindet beim Weitersuchen nicht mehr. Era/TBC unverändert.
- Spieltest: neue Prüfung S9 (Fenster öffnet und schliesst mit dem Auktionshaus).
- Testroutine (Entwickler): Prüfungen, die in diesem Client nicht gehen (kein BugSack, fehlende Item-Daten, kein echtes
  Layout), zählen als übersprungen, nie als OK oder FEHLER.

## 0.65.27
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauber-Tabelle korrigiert** (Quelle: warcraft.wiki.gg, Classic-Entzaubertabellen): grüne Items bis Itemstufe
  15 geben keinen Splitter – Rüstung 80 % Staub / 20 % Essenz, Waffen 20 % / 80 %. Itemstufe 21–25 jetzt 75/15/10
  (Waffen 15/75/10), Itemstufe 51–65 Waffen 22/75/3; die übrigen Stufen bleiben 75/20/5.
- Materialien, die aus einer Gruppe nicht kommen können (z. B. ein Splitter aus Itemstufe 15), zählen nicht mehr mit –
  weder eigene (falsch erkannte) noch geteilte Ergebnisse.

## 0.65.26
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzaubern im Tooltip, kürzer:**
  - Eine Zeile "Entzaubern: erwarteter Gewinn ~X" (Wert nach Gebühren) mit kleinem Vergleich ("lohnt mehr als
    Verkauf" / "Verkauf bringt mehr") und der Quelle: "(Ø 12)" = aus 12 echten Entzauberungen (ab 10), "(T)" = Tabelle.
  - Darunter ein Block "Entzaubern – Materialien (AHSentinel)": Icon, Name, Dropchance und Wert pro Stück
    (AH-Preis aus dem letzten Scan, sonst Marktwert).
  - Mit gedrückter Shift-Taste erscheint die ganze Rechnung (tatsächlich und geschätzt, je Material, nach Gebühren).
  - Einstellung "Entzauber-Details im Tooltip": kurz / mit Materialien (Standard) / alles.
- **Entzauber-Ergebnisse mit allen AHSentinel-Nutzern teilen:** Jedes Entzaubern auf jedem Charakter wird
  automatisch gezählt (Twinks zählen als eigene) und über den öffentlichen Sync-Kanal geteilt ("nur Gilde" bleibt als
  Einstellung). Schutz: höchstens 6 Nachrichten je Absender und Minute, Materialien müssen zur Gruppe passen, 1–5
  Stück je Entzauberung, keine Sprünge, doppelte Meldungen zählen einmal. Absender werden nur als Kürzel gespeichert,
  nie mit Namen.

## 0.65.25
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Post abholen:** "Post abgeholt" zeigt jetzt das wirklich abgeholte Gold (z. B. 1g 56s 26c) statt 0. Das Spiel
  schreibt das Gold oft erst nach der Briefkasten-Aktualisierung gut; das Addon zählt jetzt den Betrag jeder abgeholten
  Post mit.
- "1 neue Rechnungen" → "1 neue Rechnung".

## 0.65.24
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Spieltest S5** prüft jetzt nur noch, was er soll: das Gewinn-Fenster gegen das Berufsfenster und ProfessionSentinel.
  Vorher zählte er auch das Hauptfenster über dem Auktionshaus, LevelPilot und unsichtbare Anker anderer Addons mit
  und meldete fälschlich FEHLER.

## 0.65.23
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Spieltest:** `/ahs spieltest an` – AHSentinel prüft die Test-Checkliste im Spiel selbst, sobald du die Lage
  herstellst, und meldet nur, was nicht stimmt (eine Chat-Zeile je Prüfung). Er öffnet nie selbst Fenster, kauft,
  stellt ein oder stellt her und tut im Kampf nichts. Aktiv bis /reload oder 2 Stunden.
  - S1 Gebühr im Verkaufen-Reiter · S2 echte Gebühr nach dem Einstellen · S3 Gewinn-Fenster · S4 Entzaubern im
    Tooltip · S5 Gewinn-Fenster überdeckt nichts · S6 Händler-Knopf · S7 Neuaufbau beim Herstellen von 5 Gegenständen
    · S8 keine blockierten Aufrufe.
  - `/ahs spieltest bericht` zeigt OK / FEHLER / offen und was für die offenen noch zu tun ist. Die Ergebnisse gehen
    auch ins Diagnose-Protokoll und in den Testbericht für die Addon-Prüfung (Bereich S). Keine Namen.
- Übrig gebliebene Datei (TestRoutine.lua.orig) aus dem Download entfernt.

## 0.65.22
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzaubern im Tooltip – tatsächlich und geschätzt, klar getrennt:**
  - "Entzaubern tatsächlich (Ø aus N)": nur aus echten Entzauberungen dieser Gruppe (eigene + geteilte): Summe der
    wirklich erhaltenen Materialien × aktueller AH-Preis aus dem letzten Scan ÷ N. Unter 10 Entzauberungen steht
    "(wenig Daten)" dabei, ohne Entzauberung fehlt die Zeile.
  - "Entzaubern geschätzt (Tabelle)": der bisherige Wert (Tabelle verrechnet mit den Ergebnissen).
  - Je Material eine Zeile: Chance (bzw. tatsächliche Häufigkeit "x/N") × Ø-Menge · AH-Preis aus dem letzten Scan (mit
    Alter) · Marktwert = Anteil; darunter "nach Gebühren" (WoW Forever: AH-Gebühr 5 %, mind. 1s pro Auktion).
  - Der Tooltip sagt, mit welchem Wert die Entzauber-Schnäppchen rechnen: ab 10 Entzauberungen mit dem tatsächlichen
    Ø, sonst mit der Schätzung.
  - Neue Einstellung "Entzaubern: je Material" (Standard an).

## 0.65.21
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gebührenregel WoW Forever:** In Forever gibt es nur EINE Gebühr – die AH-Gebühr = 5 % vom Preis der Auktion,
  mindestens 1 Silber, pro Auktion (pro Stapel), bezahlt beim Einstellen. Eine separate Einstellgebühr gibt es nicht
  mehr. Beispiele: 3s 90c → 1s, 2s → 1s, 1g → 5s, Stapel 20 zu je 1c → einmal 1s.
- Die Zeile "Einstellgebühr (nicht erstattet)" fällt im Gewinn-Fenster und beim Verkaufen weg; es gibt nur noch
  "AH-Gebühr (5 %, mind. 1s)". Überall gleich gerechnet: Gewinn-Fenster, Verkaufen, "Heute tun", Schnäppchen,
  Flips, Entzauber-Werte, Händler-Vergleich, Gewinnrechner.
- Beim Einstellen kommt die wirklich abgezogene Gebühr ins Diagnose-Protokoll (Eintrag EINSTELLEN: Preis, Menge,
  Gebühr), um die Regel im Spiel zu bestätigen. Die Messung der Einstellgebühr aus 0.65.17–0.65.20 ist entfernt. Die
  Warnung, wenn die Gebühr mehr als 10 % vom Preis ausmacht, bleibt.
- Era, TBC und Retail unverändert (5 % beim Verkauf, Einstellgebühr kommt beim Verkauf zurück).

## 0.65.20
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Berufsfenster:** Die Liste „Beste Rezepte“ baut sich beim Herstellen höchstens alle 2 Sekunden neu auf (bisher bis
  zu 190-mal pro Sitzung); Öffnen und Berufswechsel bleiben sofort.
- **Sniper (WoW Forever):** Der Sniper reserviert Waren nicht mehr selbst ohne Tastendruck. WoW Forever hat das
  geblockt (einmal pro Sitzung „Aktion blockiert“). Waren kaufst du mit 2 Rasten: die 1. reserviert, die 2. kauft.
  Blockt WoW das in einem anderen Client, merkt sich das Addon das für diesen Client, auch nach /reload.
- **Post an Twinks:** Eine Regel mit Unterkategorie greift jetzt auch nach /reload am Briefkasten, ohne vorher im
  Auktionshaus gewesen zu sein. Regeln aus 0.65.11–0.65.17 werden wiedergefunden.
- **Einkauf:** Die Kategorie-Liste behält beim Tippen und Suchen ihre Scroll-Position, die gewählte Kategorie bleibt
  sichtbar. Bis das Auktionshaus einmal offen war, zeigen Classic Era, TBC und WoW Forever die klassische Reihenfolge
  (mit Projektil, Köcher, Reagenz).
- **Verkaufs-Meldung:** geht auch, wenn der Spieltext einen nummerierten Platzhalter hat („%1$s“).
- **Berufsfenster:** Ohne Reiterleiste dockt das Gewinn-Fenster direkt neben dem Fenster an (beim alten Fenster nur
  über dessen unsichtbaren Rand), nie über Sichtbarem. Ein Klick auf ein Rezept schaltet „Ungelernte zeigen“ nicht
  mehr ein. In Classic Era und TBC keine Leerzeile mehr, wo in WoW Forever die Einstellgebühr steht.
- **Einstellgebühr:** Die Warnung sagt, wenn die Gebühr beim Verkauf erstattet wird (Classic Era, TBC …). Im Testmodus
  wird nichts gemessen, eine Schätzung des alten Auktionshauses zählt nie als Messung, das Gold wird kurz nach dem
  Einstellen noch einmal geprüft, und die letzten 300 Messungen stehen im Diagnose-Protokoll (nur Zahlen, keine Namen).
  „Heute tun – Herstellen“ zieht die Gebühr für die ganze hergestellte Menge ab.
- Tooltip des Preisfelds zeigt in jeder Sprache g/s/c.
- Testroutine (nur für den Entwickler): neuer Bereich K (Oberfläche im echten Client: Tooltips, überlappende Fenster,
  Bildschirm, Beschriftungen, plausible Werte, Fehlerschleifen, T191–T197) und Tests T198–T202; gemerkte Rezepte,
  Fensterpositionen und Wächter-Daten bleiben während der Routine unverändert.

## 0.65.18
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Händler-Knopf verdeckt nichts mehr:** Der Knopf „Verkaufen: … Items“ sass unter dem Händlerfenster und verdeckte
  den Reiter „Rückkauf“. Er sitzt jetzt oben rechts über dem Händlerfenster, nie bei den Reitern „Händler“ / „Rückkauf“.
- **Nur wenn es etwas zu verkaufen gibt:** Statt „Verkaufen: 0 Items (0)“ ist der Knopf dann ganz weg.
- **Ab Werk aus mit LevelPilot:** Ist LevelPilot geladen und verkauft dort graue Items selbst (Option ab Werk an), bleibt
  der Knopf aus, bis du ihn in den Einstellungen („Knopf beim Händler“) selbst einschaltest. Deine Einstellung gewinnt immer.
- Testroutine (nur für den Entwickler): T186 prüft im Spiel, dass der Knopf keinen Reiter des Händlerfensters verdeckt
  (sonst FEHLER), T187 die Werkseinstellung mit und ohne LevelPilot.

## 0.65.17
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Einstellgebühr wird gemessen:** Bei jedem Einstellen schreibt das Addon Item, Händlerpreis, Menge, Laufzeit, deinen
  Preis (pro Stück und gesamt), die Gebühr laut Spiel und die wirklich abgezogene Gebühr mit, dazu die Verhältnisse
  Gebühr/Preis und Gebühr/Händlerpreis – im Diagnose-Protokoll (`/ahs protokoll`, Eintrag EINSTELLEN) und im
  GSDIAG1-Export, ohne Namen. Nennt das Spiel keine Gebühr, gilt die zuletzt gemessene für dieses Item – nie geschätzt.
- **Warnung Einstellgebühr:** Macht die Gebühr mehr als 10 % vom Preis aus, ist zum Einstellen ein zweiter Klick nötig.
  Die Schwelle ist in den Einstellungen wählbar (aus / 5 / 10 / 20 / 30 %).
- **"Heute tun": unter Händlerpreis:** Angebote, deren Stückpreis unter dem Händlerverkaufspreis liegt (aus dem letzten
  Scan oder deiner aktuellen Suche), stehen als "Unter Händlerpreis: kaufen und beim Händler verkaufen" – Gewinn =
  (Händlerpreis − Kaufpreis) × Menge, ohne AH-Anteil. Erst ab 10 Silber Gewinn je Angebot (einstellbar: alle / 5s /
  10s / 50s / 1g), die besten 10, nach Gewinn sortiert. Items ohne Händlerpreis erscheinen nie, verschwundene Angebote
  werden ausgeblendet. Der Knopf kauft nur auf deinen Klick und sagt dann: beim Händler verkaufen.

## 0.65.16

- **Geschützte Werte:** Rezept-Auswahl und Diagnose-Protokoll übergehen geschützte Werte des Spiels, statt sie anzufassen.
- Testroutine (nur für den Entwickler), nach den bei LevelPilot bewährten Regeln: ehrliche Zählung (was im Client nicht prüfbar ist, zählt als übersprungen, nie als OK; der Bericht nennt „nicht automatisiert: N“ und listet alles, was im Spiel zu prüfen ist), jeder Fehler aus dem Spiel ist ein eigener Testfall (Rezept-Klick ohne vorherigen Klick, die 50 Sekunden), Köderwerte für geschützte Werte, das Test-Protokoll landet in einer Sandbox, Testfall-IDs sind eindeutig.

## 0.65.15

- **Diagnose-Protokoll:** `/ahs protokoll` öffnet ein Fenster mit markierbarem Protokoll – Version, Client, Sitzungen, geänderte Einstellungen, offene Fenster und wo das Gewinn-Fenster angedockt ist, dazu Einträge (neueste zuerst): KLICK (Rezept, Rezept-ID, Weg, Millisekunden, Erfolg), AUFBAU (Liste „Beste Rezepte“, Auslöser, Dauer), LANGSAM (jeder Schritt über 16 ms), ÜBERLAPPT (fremdes Fenster über dem Gewinn-Fenster) und FEHLER (gleiche nur gezählt). Beim Ausloggen wird es zusätzlich als „GSDIAG1“ für die Addon-Prüfung gespeichert. Keine Spieler-, Charakter-, Gilden- oder Realmnamen.

## 0.65.14

- **Berufsfenster (moderner Client):** Ein Klick auf ein Rezept in „Beste Rezepte“ wählt es sofort über die Rezeptliste des Berufsfensters und scrollt es in die Ansicht – im selben Moment, ohne auf einen Timer zu warten. Nur wenn das nicht geht, nimmt das Addon OpenRecipe des Spiels, prüft jeden Frame und meldet im Chat, wenn das Rezept nach 0,5 Sekunden nicht angezeigt wird.

## 0.65.13

- **WoW Forever – Gewinn am Berufsfenster:** Die Einstellgebühr (mindestens 1 Silber pro Auktion, wird nie erstattet) wird jetzt abgezogen und als eigene Zeile gezeigt: Gewinn = Wert × 0,95 − Material − Einstellgebühr (z. B. Kupferne Kettenhose 18c statt 1s 18c – gleich wie ProfessionSentinel). Die Liste „Beste Rezepte“ ist danach sortiert.
- **WoW Forever – Gebots-Schnäppchen** ziehen die Einstellgebühr fürs Weiterverkaufen ebenfalls ab.
- Classic Era, TBC und die anderen Versionen bleiben unverändert (dort kommt die Gebühr beim Verkauf zurück).

## 0.65.12

- **Berufsfenster – Klick auf ein Rezept in „Beste Rezepte“ öffnet es jetzt immer:**
  - Die Liste baut sich nicht mehr bei jedem Spiel-Ereignis neu auf: Ereignisse werden gesammelt, neu aufgebaut wird höchstens alle 0,4 s, nur wenn sich etwas geändert hat, und verteilt über mehrere Frames – ein Klick geht während des Aufbaus nicht mehr verloren.
  - Jede Zeile merkt sich ihr Rezept; beim Klick wird es im Berufsfenster neu gesucht. Verstecken es Suchtext, Filter oder eine zugeklappte Kategorie, werden diese zurückgesetzt und das Rezept trotzdem geöffnet.
  - Klappt es trotzdem nicht, kommt eine kurze Meldung im Chat.

## 0.65.11

- **Einkauf → Kategorien wie im Blizzard-Auktionshaus:** Jede Hauptkategorie hat jetzt ihre Unterkategorien (Waffen → Einhandäxte …, Rüstung → Stoff/Leder …, Verbrauchbares → Tränke …), mit Namen und Reihenfolge aus dem Spiel. Die Unterkategorien klappen unter der gewählten Hauptkategorie auf. Bis das Auktionshaus einmal offen war, nimmt das Addon die Item-Klassen des Spiels.
- **Preisfeld:** zeigt Gold/Silber/Kupfer immer als g/s/c („78c“, „3s 90c“), in jeder Sprache – nie mehr „k“, das wie „tausend“ aussah. Eingaben wie „78“, „78c“, „1s 20c“, „1g“ und das alte „78k“ gehen weiter.
- Für ProfessionSentinel: `AHAnalyzerPro.Crafting:GetDockFrame(true)` liefert das Gewinn-Fenster auch, solange es verborgen ist.

## 0.65.10

- **Berufsfenster (WoW Forever):** Das AHSentinel-Gewinn-Fenster verdeckt die Berufsreiter rechts am Berufsfenster nicht mehr – es dockt jetzt rechts neben der Reiterleiste an. Ohne solche Reiterleiste sitzt es wie bisher.

## 0.65.9

- **Berufsfenster:** neue Schnittstelle `AHAnalyzerPro.Crafting:GetDockFrame()` – liefert das sichtbare AHSentinel-Gewinn-Fenster neben dem Berufsfenster, sonst nil. ProfessionSentinel dockt damit rechts daneben an, statt darüber zu liegen. AHSentinel selbst bleibt direkt rechts am Blizzard-Berufsfenster.

## 0.65.8

- **Beschädigte gespeicherte Daten werden beim Einloggen repariert:** Einzelne kaputte Einträge (Preisverlauf, Charaktere, Sniper-Ziele, Buchhaltung, Einkaufslisten, Rezepte) werden entfernt, statt in einem Reiter oder Tooltip einen Lua-Fehler auszulösen. Gesunde Daten bleiben unverändert.
- Testroutine (nur für den Entwickler): zwei Prüfungen, die immer fehlschlugen, sind behoben (Wächter bei geschlossenem Auktionshaus, `/ahs scan` während der Routine); Optionen und Chat-Befehle laufen jetzt einzeln (kein „script ran too long“); viele weitere Prüfungen (Wächter-Kandidaten, Verkaufs-Meldung, Buchhaltung aus dem Test-Briefkasten, Neu einstellen, Händler, Berufe, Entzaubern, Charaktere, Preis-Sync, Datenübernahme und kaputte Daten, Tempo, geschützte AH-Aufrufe) und mit offenem Auktionshaus simulierter Warenkauf, Sniper-Vorab-Reservierung, Serie einstellen, Unterbieten und Scan in Portionen. Was in einem Client nicht prüfbar ist, steht jetzt als „übersprungen“ mit Grund statt als OK im Bericht.

## 0.65.7
- **Testroutine (nur Entwickler):** viele weitere Prüfungen – jede Option einmal an und aus, jeder Chat-Befehl, alle
  Zusatzfenster, Hauptfenster und Designs, Größe und Position, Einkauf- und Buchhaltungs-Rechnung, Sniper-Ziele und
  -Tasten, Wächter-Einstellungen, Watchlist, Taschen ohne alte Funktionen, Chat-Hilfen, Esc-Fenster im Kampf, Fehler
  in Hintergrund-Aufgaben, Übergang vom alten AH Analyzer Pro.
- Taschen, Postfach-Plätze und Preis-Teilen holen die Client-Funktionen jetzt über eine Stelle, damit die Testroutine
  fehlende Funktionen simulieren kann, ohne Blizzard-Funktionen anzufassen (kein Taint). Im normalen Spiel ändert sich
  nichts.
- Meldung "GoldSentinelTest.lua fehlt" ist jetzt übersetzt.

## 0.65.6

Korrekturen aus der Addon-Prüfung:
- **Scan-Start scheitert dauerhaft (WoW Forever, Retail):** Lehnt der Server den Scan-Start immer wieder ab, wird der Chat nicht mehr geflutet (vorher rund 240 Zeilen in 2 Minuten). Die Fehlermeldung kommt einmal, das Addon versucht es höchstens 3-mal neu (mindestens 2 Sekunden Abstand) und meldet dann einmal, dass der Scan nicht starten konnte. Der Wächter läuft sofort weiter.
- **Wächter:** Verwirft der Server Anfragen, während die kurze Pause eines Scan-Wunschs läuft, pausiert der Wächter jetzt wie gewollt die vollen 15 Minuten (vorher lief er nach 2 Minuten wieder). Bewusst keine Pause nur deshalb, weil ein Scan erlaubt ist: Sonst würde der Wächter bei Spielern, die nie scannen, dauerhaft ruhen.
- **Berufsfenster (moderner Client):** Das im Blizzard-Fenster gewählte Rezept wird jetzt wirklich erkannt (der Ereignisname war falsch) – der Zutaten-Knopf nimmt nie ein älteres Rezept.
- **Post an Twinks (WoW Forever):** Eine Regel nur mit dem eigenen Vornamen („Testa“ für „Testa Beispiel“) plant keine Post mehr an dich selbst.
- **WoW Forever, geschützte Werte:** Preis-Sync, Tooltip, Briefkasten-Fehlermeldungen, blockierte Aktionen und das Entzaubern-Lernen übergehen geschützte Werte („secret values“), statt einen Lua-Fehler zu riskieren.
- Vom Addon abgefangene Fehler werden jetzt auch für die Addon-Prüfung gezählt (GoldSentinelTest.lua); `/ahs debug` zeigt „Fehler seit Login · Berichte offen“. Die Chat-Meldungen bleiben wie bisher. Die Verkaufs-Meldung verschluckt Fehler nicht mehr still.
- Nur für den Entwickler: neue Testroutine `/ahs testroutine` (Bereiche a–j, `server`, `haendler`, `berufe`, `post`, `gildenbank`, `kampf`) mit gespeichertem Bericht. Deine echten Daten werden vorher gesichert und danach wiederhergestellt; Kaufen, Einstellen, Post, Händler und Preis-Sync sind nur simuliert. `/ahs test` und `/ahs test daten` sind Kurzformen.
- Fehlende Übersetzungen für das klassische Auktionshaus ergänzt.

## 0.65.5

Nachbesserungen aus der Addon-Prüfung:
- **Komplett-Scan hat Vorrang (WoW Forever, Retail):** Startest du den Scan, während der Server ausgelastet ist oder noch eine Wächter-Suche läuft, scheitert er nicht mehr – der Wächter pausiert, und der Scan startet von selbst, sobald der Server bereit ist (höchstens 2 Minuten). Ein abgelehnter Scan-Start wird genauso behandelt. Classic Era und TBC bleiben unverändert.
- **Berufsfenster:** In den alten Clients (Classic Era, TBC) werden Rezepte wieder höchstens alle 5 Sekunden gelesen, wie in 0.65.3. Im modernen Client kommt das gewählte Rezept direkt aus der Rezeptliste und wird beim Schließen vergessen – der Zutaten-Knopf nimmt nie ein altes Rezept.

## 0.65.4

Korrekturen aus der Addon-Prüfung:
- **Altes „AH Analyzer Pro“ (bis 0.61) noch installiert:** AHSentinel lädt nicht mehr daneben (beide nutzten dieselbe Tabelle – doppelte Ereignisse und Befehle, mögliche Lua-Fehler). Stattdessen kommt einmal im Chat die Bitte, den alten Ordner `AddOns\AHAnalyzerPro` zu löschen. Deine alten Daten werden vorher für AHSentinel gesichert. Der alte Ordner wird auch nicht mehr vor AHSentinel geladen.
- **Wächter (Classic Era, TBC):** wieder wie in 0.64.2 – keine Pause von bis zu 15 Minuten mehr, wenn der Server „kein Komplett-Scan“ meldet (das kann auch von einem anderen Addon kommen).
- **Wächter (WoW Forever, Retail):** Ist der Komplett-Scan fällig und verwirft der Server Anfragen, pausiert der Wächter, bis der Scan gelaufen ist (höchstens 15 Minuten).
- **Berufsfenster (moderner Client):** Eine direkt nach dem Öffnen noch leere Rezeptliste blockiert das Einlesen nicht mehr 5 Sekunden; der Zutaten-Knopf merkt sich das zuletzt gewählte Rezept; die Rezeptdetails werden nur einmal pro Beruf gelesen (weniger Ruckeln).
- `/ahs debug` zeigt, ob Händler-Kosten in Währung (z. B. Merchant's Favor) in diesem Client lesbar sind.

## 0.65.3

- **Der alte Ordner „AHAnalyzerPro“ ist nicht mehr dabei.** Es gibt nur noch den Ordner AHSentinel. Hast du AHSentinel schon einmal gestartet, sind deine alten Daten bereits übernommen und du kannst den Ordner „AHAnalyzerPro“ unter Interface\AddOns löschen.

## 0.65.2

- **GoldSentinelGame Version 2:** Die gemeinsame Versionserkennung setzt sich jetzt auch gegen frühe Fassungen durch, die andere GoldSentinel-Addons kurz mitgebracht hatten – keine Lua-Fehler, wenn mehrere Addons zusammen geladen sind.
- Händlerpreise: Fehlt im Spiel die Funktion für den Item-Link beim Händler, wird die Item-ID auf anderem Weg gelesen.

## 0.65.1

- **Gemeinsame Versionserkennung:** AHSentinel erkennt die Spielversion jetzt über **GoldSentinelGame** – dieselbe Erkennung, die nach und nach alle GoldSentinel-Addons bekommen. WoW Forever gilt dort immer als moderner Client, nie als Classic.
- Neu: `/gsgame` zeigt im Chat, welche Spielversion erkannt wurde; `/ahs debug` zeigt es ebenfalls.
- Für dich ändert sich sonst nichts.

## 0.65.0

**WoW Forever und Retail (moderner Client) – nichts bleibt mehr still leer:**
- **Berufsfenster:** Rezepte werden jetzt über die moderne Berufe-Schnittstelle (`C_TradeSkillUI`) gelesen, wenn die alte fehlt. Das Gewinn-Fenster neben dem Berufsfenster und die Herstell-Vorschläge in „Heute tun“ funktionieren damit auch dort. Ältere Spielversionen nutzen weiter den alten Weg.
- **Händlerpreise:** werden über `C_MerchantFrame` gelesen, wenn die alte Funktion fehlt. Artikel, die Währung oder Marken kosten (z. B. Merchant's Favor), werden mit ihren genauen Kosten gemerkt.
- **Raid-Vorrat:** Auf WoW Forever gilt die Classic-Vorlage (`/ahs raid`).
- **Wächter und der 15-Minuten-Komplett-Scan:** Lässt der Server nach einer Wächter-Runde den fälligen Komplett-Scan nicht zu, pausiert der Wächter, bis der Scan gelaufen ist.
- **Sniper:** Blockiert WoW den vorab reservierten Warenkauf (ohne Fehlermeldung, nur als Ereignis), schaltet sich „eine Raste kauft“ selbst ab und der Sniper kauft wieder mit zwei Rasten.
- Die Texte zur Einstellgebühr auf WoW Forever (0.64.2) gibt es jetzt in allen Sprachen.

## 0.64.2

- **WoW Forever: Einstellgebühr richtig eingerechnet.** Auf WoW Forever kostet jede Auktion **mindestens 1 Silber**, und die Gebühr gibt es **nie zurück**, auch nicht beim Verkauf. AHSentinel erkennt Forever jetzt selbst und zieht die Gebühr überall **immer** ab statt nur als Risiko bei Rücklauf: Flips, Verkaufsvorschläge in „Heute tun“, Herstellungs-Gewinne, Schnäppchen, Entzauber-Schnäppchen (Material wird im Stapel verkauft, Gebühr anteilig pro Stück), Händler-gegen-AH-Vergleich und Reiter Verkaufen (dort steht „nicht erstattet“).
- Vor allem **günstige Items** betrifft das: Bringt ein Item im AH 1s 50c und beim Händler 71c, bleiben nach 5 % und 1s Gebühr nur 42c – „Heute tun“ schlägt dann **„beim Händler verkaufen“** vor.
- Gebühr pro Stück = max(1 Silber, Gebühr eines vollen Stapels) ÷ Stapelgröße. In den anderen Spielversionen bleibt alles wie bisher (Gebühr wird beim Verkauf erstattet).
- Gewinnrechner: auf Forever ist 1 Silber Einstellgebühr enthalten.

## 0.64.1

- **„Heute tun“ schlägt Herstellen vor – auch ohne ProfessionSentinel:** AHSentinel merkt sich jetzt die Rezepte jedes Charakters, sobald du das Berufsfenster öffnest. „Heute tun“ schlägt dann die 2–3 lohnendsten Rezepte vor, die du **schon kannst** (Ergebnis verkauft sich gut, mindestens 10 % Gewinn nach AH-Anteil). Der Knopf **Zutaten kaufen** legt für jede fehlende Zutat aus dem Auktionshaus eine Kauf-Zeile an (10 % Preisspielraum, gekauft wird nur per Klick); Zutaten vom Händler stehen im Chat. Ist alles da: „Alles da – herstellen“.
- Ist ProfessionSentinel installiert, kommen dessen Vorschläge statt der eigenen (nichts doppelt).
- Wer einen Herstellungsberuf hat, aber ProfessionSentinel nicht, sieht unten in „Heute tun“ einen kleinen Tipp – **Ausblenden** entfernt ihn für immer.

## 0.64.0

**„Heute tun“ – kaufen und einstellen direkt in der Liste:**
- Jede Zeile hat jetzt einen **Knopf mit dem nächsten Schritt**, ohne Sprung in einen anderen Reiter:
  - Kauf-Vorschläge: **Prüfen** sucht das Item im Hintergrund. Danach steht in der Zeile das echte aktuelle Angebot („5× zu je 2g 40s = 12g“), und der Knopf heißt **Kaufen 12g**. Mehrere Einzel-Auktionen: **Kaufen (1/3)**, ein Klick pro Auktion (verlangt WoW). Waren im modernen Auktionshaus: Erst wird der Preis reserviert, dann **Bestätigen**.
  - **Nie teurer und nie mehr als vorgeschlagen**, der Kapitalschutz gilt weiter. Ist das Angebot weg oder teurer, steht „nicht mehr lohnend“ da, und es wird nichts gekauft.
  - Nach dem Kauf: Flips bekommen **Einstellen** (Preisvorschlag mit Preisschutz), Entzauber-Schnäppchen zeigen, wie viele in der Tasche sind, Händler-Schnäppchen sagen „Beim Händler verkaufen“.
  - Ware aus den Taschen: **Prüfen → Einstellen**. Zurückgekommene Auktionen: **Neu einstellen**, ein Klick pro Auktion.
- Ein Klick auf die Zeile selbst wechselt wie bisher in den Reiter.
- **Für andere Addons:** `AHAnalyzerPro.Today:QuickBuy(itemID, Menge, Höchstpreis, Text)` und `:QuickSell(itemID, Menge)` legen oben in „Heute tun“ eine Zeile an – gekauft wird nichts ohne deinen Klick.
- **ProfessionSentinel:** Seine Vorschläge „heute herstellen“ erscheinen in „Heute tun“. Der Knopf führt durch Zutaten kaufen, herstellen und einstellen.
- Die Entzaubern-Texte aus 0.63.0 gibt es jetzt in allen Sprachen.

## 0.63.4

- **Wächter nur noch bei belastbarem Marktwert:** Bisher meldete der Wächter auch „Schnäppchen“ bei 0–10 % vom Marktwert – fast immer, weil der Marktwert selbst falsch war (Mondpreis, seltenes Item, Preissturz). Weil der Wächter per Mausrad kauft, zählt jetzt nur noch ein Marktwert, dem man trauen kann.
- **Testmodus-Protokoll:** Käufe des Wächters stehen als „Sniper-Kauf (Wächter)“ mit Preis drin; Waren-Käufe aus Einkauf und Sniper ebenfalls mit Preis.

## 0.63.3

- **Qualitätsstufen (Retail):** Handwerksmaterial und hergestellte Items gibt es in mehreren Stufen – bisher standen z. B. dreimal „Bismut“ untereinander, ohne Unterschied. Jetzt steht das Stufen-Symbol hinter dem Namen (Einkauf, Markt, Verkaufen, Sniper, Buchhaltung …).
- **Rückmeldung nach Einstellen und Abbrechen:** Statt „Wird eingestellt …“ / „Wird abgebrochen …“ stehen zu bleiben, zeigt das Fenster jetzt „Eingestellt: …“ bzw. „Abgebrochen: …“.
- **Tagesbilanz:** zeigte „+ dein ganzes Gold seit gestern“, wenn das Spiel beim Einloggen kurz 0 Gold gemeldet hatte. Ein solcher 0-Wert zählt nicht mehr.
- **Testmodus-Protokoll:** Kauf von Waren (Retail) steht jetzt mit Preis drin, ein Sniper-Kauf als „Sniper-Kauf“ statt „Sofortkauf“.

## 0.63.2

- **Selbsttest in Retail:** brach mit „script ran too long“ ab (Retail stoppt Skripte, die zu lange am Stück laufen – bei rund 20 000 Items im Scan passiert das). Der Test legt jetzt regelmäßig kurze Pausen ein; der Sprachwechsel-Test prüft eine Sprache pro Bild.
- **Verkaufen bei geschlossenem Auktionshaus:** zeigte in Retail „Keine verkaufbaren Items in den Taschen“, obwohl die Taschen voll waren. Die Prüfung „kann man das einstellen?“ läuft jetzt nur noch bei offenem Auktionshaus.
- **Reagenzientasche (Retail):** Items darin zählen jetzt beim Verkaufen, Post an Twinks und Händler-Verkauf mit.

## 0.63.1

- **Retail (The War Within / Midnight, Interface 12.x): Item-Namen wieder da.** Im modernen Spiel gibt es die alten Funktionen `GetItemInfo`, `GetItemIcon` usw. nicht mehr – AHSentinel nimmt dort jetzt `C_Item`. Vorher stand überall „Item #12345“ statt des Namens (Einkauf, Preisverlauf, Tooltip, Testdaten).
- **Namen werden nachgeladen:** Der Komplett-Scan im modernen Auktionshaus liefert nur Item-IDs. Items, die dein Client noch nicht kennt, lädt AHSentinel jetzt gedrosselt im Hintergrund nach (40 pro Sekunde); die Listen aktualisieren sich von selbst.
- **Selbsttest „Suche nach Namen“** schlug in Retail fehl („'Item #251665' -> nil“). Er nimmt jetzt ein Item, dessen Name schon bekannt ist, und meldet sonst, wie viele Namen noch geladen werden.
- **Testmodus in Retail:** Die fiktiven Auktionen und Briefe brauchen Item-Namen – sie entstehen jetzt auch dort.
- Entzaubern: Zaubername über `C_Spell` (Retail).

## 0.63.0

- **Entzaubern – alle lernen gemeinsam:** Was beim Entzaubern herauskommt, teilt AHSentinel jetzt über den Preis-Sync mit allen Spielern, die das Addon haben (oder nur mit deiner Gilde, wenn du das eingestellt hast). Jeder schickt nur seine eigenen Zahlen, nichts wird doppelt gezählt. So stimmen die Dropchancen viel schneller mit der Wirklichkeit auf WoW Forever überein.
- **Neue Startwerte bei grünen Teilen:** 75 % Staub, 20 % Essenz, 5 % Splitter (Waffen umgekehrt: 75 % Essenz, 20 % Staub). Deine eigenen und die geteilten Ergebnisse passen die Werte danach an.
- Tooltip: „Entzaubern (Ø, 12 eigene, 340 geteilt)“ zeigt, auf wie vielen Entzauberungen der Wert beruht.
- Geteilt wird nur, welches Material wie oft herauskam – Unsinn (fremde Gegenstände, unmögliche Mengen) wird abgelehnt.
- ProfessionSentinel nutzt diese Werte für die Rangliste „Herstellen & Entzaubern“.

## 0.62.4

- **Stapelware zusammengefasst (klassisches Auktionshaus):** Im Einkauf bilden alle Angebote eines stapelbaren Items mit gleichem Stückpreis **eine Zeile mit der Summe** – z. B. 5 Stapel zu 20 stehen als „100“ da, mit Stückpreis und **Gesamtpreis** der Zeile.
- **Mehrere zusammen kaufen:** Zeile anklicken, mit **Shift+Linksklick** weitere Zeilen dazu. Rechts stehen Stückzahl, Anzahl Angebote und der Gesamtpreis deiner Auswahl. „Auswahl kaufen“ fragt einmal mit der Summe nach, danach kauft jeder Klick das nächste Angebot (WoW verlangt einen Klick pro Auktion).
- „Einzelne Angebote anzeigen“ schaltet zur bisherigen Liste zurück (dort auch Bieten). Das moderne Auktionshaus fasst Waren schon selbst nach Preis zusammen – dort gibst du einfach die Menge ein.

## 0.62.3

- **Item-Namen für WoW Forever:** Die eingebauten Namen von WoW Forever haben wieder Vorrang, die in 0.62.1 ergänzten TBC-Namen füllen nur noch Lücken. Rund 2000 Items, die in TBC umbenannt wurden, heißen in den anderen Sprachen wieder wie auf WoW Forever.

## 0.62.2

- **Test- und Entwicklerfunktionen ausgeblendet:** Selbsttest und Testmodus (Knopf „Test“, `/ahs test`, `/ahs testmodus`) gibt es jetzt nur noch für den Entwickler. Für alle anderen sieht das Addon gleich aus und funktioniert gleich, nur ohne diese Werkzeuge.

## 0.62.1

**Realistische Preise – wichtig für den frischen Server, auf dem die Preise jeden Tag fallen:**
- **Marktwert folgt dem Markt schneller:** Neuere Preise zählen stärker (Halbwertszeit 3 Tage) statt eines einfachen Medians über 14 Tage. Mondpreise wie „1666g 99s 98c“ zählen gar nicht mehr.
- **Preissturz wird erkannt:** Liegen die letzten zwei Scans (mind. 6 Std. auseinander) weit unter dem Marktwert, steht im Tooltip „Preis gerade eingebrochen“, und der Marktwert gilt als unsicher. Solche Items werden nicht mehr zum Kaufen, Flippen oder Verkaufen vorgeschlagen.
- **„Heute tun“ rechnet mit dem, was du wirklich bekommst:** höchstens 5 % über dem günstigsten aktuellen Angebot, nie mit dem alten Marktwert. Ist der AH-Preis bis nahe an den Händlerpreis gefallen, kommt der Vorschlag „beim Händler verkaufen“.
- **Gebote** werden nur noch bei sicherem Marktwert und nie auf Mondpreise vorgeschlagen.
- **Gewinn/Tag** bei den Schnäppchen zählt nur einen Teil der Tagesverkäufe (du bist nicht der einzige Verkäufer), höchstens die verfügbare Menge und was 20 % deines Golds kaufen.
- Die Übersicht zeigt keine Preise mit …99s 9xc mehr.

**Fehler behoben:**
- **Esc** schließt wieder den Preisverlauf statt des ganzen Auktionshauses (auch nach einem Sprachwechsel).
- **Testmodus:** Ein Sniper-Kauf per Mausrad steht jetzt im Protokoll und in der Buchhaltung.
- **Briefkasten:** neuer Knopf „Neu einstellen (N)“ für zurückgekommene Auktionen. Bildschirmmeldungen haben im Testmodus „[Test]“. Im Testmodus wird langsamer abgeholt, damit man „Anhalten“ ausprobieren kann. Zurückgekommene Test-Ware wird mitgezählt.
- `/ahs bilanz` zeigt kein „+ dein ganzes Gold seit gestern“ mehr, wenn das Gold von gestern nicht bekannt ist.
- Das Geldfeld zeigt bei jeder Eingabe, was verstanden wurde („= 5s“), nicht nur bei reinen Zahlen.
- Ein Item-Tooltip bleibt nicht mehr über einem neu geöffneten Fenster stehen („Heute tun“, Optionen …).
- Im Selbsttest stehen keine Symbol-Codes mehr in den Details.

**Sprachen:**
- **Rund 10 000 Item-Namen mehr in jeder Sprache**, auch alle Items aus Burning Crusade (Englisch: 25 800 statt 14 800). In einer englischen Oberfläche stehen keine deutschen Namen mehr.
- **Listen zeigen die Namen immer in der eingestellten Sprache** – Suchergebnisse, Sniper-Ziele, Beobachtungsliste, Einkaufslisten, Buchhaltung, Auktionen – auch direkt nach dem Wechsel, ohne neue Suche.
- Der Einkauf behält nach dem Sprachwechsel Kategorie, Suchtext und Filter.
- Optionen: Lange Beschriftungen (Französisch, Spanisch, Russisch) brechen in eine zweite Zeile um, statt abgeschnitten zu werden.
- Filter im Einkauf: kurze Platzhalter („St. ab / bis“, „Lvl min / max“), die sich nicht mehr überlappen.
- Chinesisch: „vereinfacht“ und „traditionell“ sind in der Sprachliste unterscheidbar. Item-Namen ohne chinesischen Namen werden ohne Umlaute geschrieben (ö → oe), weil die chinesische Schrift sie nicht hat.
- Selbsttest: Die Sprachprüfung findet jetzt auch abgeschnittene Beschriftungen und Namen in der falschen Sprache und zählt fehlende Item-Namen pro Sprache.

## 0.62.0

**AH Analyzer Pro heißt jetzt AHSentinel** – passend zur Sentinel-Familie (BuffSentinel, GuildSentinel, ThreatSentinel).

- **Deine Daten werden automatisch übernommen:** In der ZIP sind der neue Ordner `AHSentinel` und ein kleiner Ordner `AHAnalyzerPro`, der beim ersten Start nur deine alten Daten (Preise, Buchhaltung, Listen, Sniper-Ziele, Einstellungen) übergibt. Danach kannst du `AHAnalyzerPro` löschen.
- **Neuer Befehl `/ahs`** (auch `/ahsentinel`); `/ahp` geht weiterhin.
- Sonst bleibt alles gleich.

**Installieren:** beide Ordner aus der ZIP nach `Interface\AddOns` kopieren (den alten Ordner `AHAnalyzerPro` überschreiben), Spiel starten, fertig.

## 0.61.2

- **Eine Sprache für alles:** Item-Namen folgen jetzt der Sprache des Addons (außer du hast eine eigene Sprache für Item-Namen gewählt), und der Tooltip zeigt den Item-Namen in dieser Sprache, wenn sie von der Sprache des Spiels abweicht.
- **Sprachwechsel baut jedes Fenster neu auf:** neben dem Hauptfenster auch „Heute tun“, das Test-Fenster, die Regeln für „Post an Twinks“ und die Leiste am Briefkasten (auch bei offenem Briefkasten).
- **Selbsttest:** neue Prüfung „Sprachwechsel“ – jede Sprache des Addons einmal, danach mehrfach hin und her; Fenster, Reiter, Texte, Item-Namen und Tooltip müssen in der gewählten Sprache erscheinen, danach ist die alte Sprache wieder eingestellt.

## 0.61.1

- **Behoben: „Heute tun“ schlug unrealistische Käufe vor.** Seiten-Scans sehen oft nur einen Teil des Auktionshauses – das sah aus wie riesige Verkäufe. Verkäufe pro Tag werden jetzt nur noch zwischen **vollständigen** Scans geschätzt, jeder Rückgang zählt nur zur Hälfte (der Rest ist abgelaufen oder zurückgezogen), und es wird nie mehr als die Hälfte der üblichen Angebotsmenge angenommen. Auch „seit Scan“ vergleicht nur noch vollständige Scans.
- **Kapitalschutz:** Jeder Vorschlag in „Heute tun“ nutzt höchstens 20 % deines Golds, alle zusammen höchstens die Hälfte; das Fenster zeigt den Kapitalbedarf. Der Selbsttest prüft das.
- **Übersicht:** Anstiege auf ein Vielfaches des Marktwerts und Rückgänge von einem früheren Mondpreis erscheinen nicht mehr.
- **Briefkasten:** Die Knöpfe des Addons sitzen jetzt ordentlich in einer Leiste **neben** dem Briefkasten statt über dessen Rahmen. „Alles abholen“ gibt es nur, wenn WoW kein eigenes „Alle öffnen“ hat (und im Testmodus für die Test-Post), „Anhalten“ nur während des Abholens.
- **Ein Geldfeld statt drei:** „5s“, „1g 20s“, „4s 85k“ oder „1.5“ (= 1g 50s) eintippen; bei einer reinen Zahl steht dabei, wie sie verstanden wird („= 5g“). Kein Silber mehr im Gold-Feld.
- Kleinigkeiten: „Bieten“ ohne gewähltes Angebot sagt das, die Händler-Warnung beim Einstellen kommt nur noch, wenn es um etwas geht (mind. 1 Silber und 10 %), fiktive Auktionen erscheinen im Testmodus sofort, das Fenster „Heute tun“ schließt beim Sprung in den Reiter.

## 0.61.0

**Mehr Gewinn, weniger Schein-Schnäppchen:**

- **„Heute tun“** (Knopf in der Übersicht, `/ahp heute`): die Aktionen, die gerade am meisten Gold bringen, sortiert nach geschätztem Netto-Gewinn – unter Händlerpreis kaufen, Flips, Taschen verkaufen, unterbotene Auktionen, Neu einstellen, Entzauber- und Gebots-Schnäppchen. Ein Klick auf eine Zeile führt direkt in den passenden Reiter.
- **Verkaufbarkeit statt Angebotspreisen:** Aus deinen Scans schätzt das Addon jetzt, wie viel sich von einem Item wirklich pro Tag verkauft und ob man dem Marktwert trauen kann. Selten angebotene Items und **Mondpreise** (z. B. 2499g 99s 99c) erscheinen nicht mehr bei Schnäppchen, Flips und in der Übersicht (Knopf „auch unsichere“ zeigt sie trotzdem). Schnäppchen sind nach **Gewinn pro Tag** sortiert, der Tooltip zeigt „~N/Tag verkauft (geschätzt)“.
- **Netto-Gewinn mit Einstellgebühr:** Im klassischen Auktionshaus wird die Gebühr jetzt aus dem Händlerpreis geschätzt („ca.“) und beim ersten echten Einstellen genau gelernt. Gewinne ziehen die Gebühr ab, die bei Rücklauf verloren geht (nach deiner eigenen Verkaufsquote).

## 0.60.11

- **Briefkasten-Knöpfe antworten immer:** „Post abgeholt: …“ erscheint jetzt auch in der Bildschirmmitte, und ein leerer Briefkasten meldet „Nichts zum Abholen“, statt still zu bleiben.
- **„An Twinks“ ohne Regel** sagt das im Chat, bevor sich das Regel-Fenster öffnet.
- **Testmodus:** Der fiktive Brief „Auktion erfolgreich“ gehört jetzt zur verkauften fiktiven Auktion, und diese verschwindet aus „Meine Auktionen“, sobald der Erlös abgeholt ist – wie im Spiel.

## 0.60.10

- **Testmodus mit fiktiven Auktionen:** „Meine Auktionen“ zeigt im Test drei fiktive Auktionen (eine unterboten, eine günstigste, eine verkauft) und alles, was du im Test einstellst – Abbrechen und Unterbietung prüfen lassen sich so ohne echte Auktion ausprobieren. Der Selbsttest nimmt fürs Abbrechen eine fiktive Auktion, wenn du keine hast.
- **Test-Briefkasten:** Im Testmodus arbeiten die Briefkasten-Knöpfe des Addons mit fiktiver Post (verkauft, gewonnen, abgelaufen, abgebrochen, überboten, ein normaler Brief): automatisch abholen, „Alles“, Rechnungen in der Buchhaltung und „Neu einstellen“ lassen sich ausprobieren – deine echte Post bleibt unberührt.
- **Einkauf:** Beim Wechsel zu einem anderen Item werden Gebotsfeld und gewähltes Angebot zurückgesetzt (kein altes Gebot mehr im Feld). Die Kopfzeile zeigt günstigstes Angebot und Marktwert (Median 14 Tage) getrennt und sagt, wenn noch weitere Angebote geladen werden.
- **Sniper:** Angebote des vorigen Ziels stehen nicht mehr unter dem Namen des neuen.
- **Selbsttest:** Der Sniper-Test „kauft“ (simuliert) den kleinsten Stapel statt eines 2er-Stapels.
- **Preisverlauf:** lässt sich jetzt auch am Titel verschieben.

## 0.60.9

- **Meldung, wenn der Scan fertig ist:** groß in der Bildschirmmitte („AH-Scan fertig: N Items“) und mit Ton (wenn in den Optionen der Ton an ist) – du musst nicht mehr auf den Chat schauen. Ein Scan ohne Ergebnis wird dort ebenfalls gemeldet.

## 0.60.8

- **Behoben: keine Preiszeilen im Tooltip** auf manchen Clients (z. B. TBC Anniversary). Das Addon hängt sich jetzt an alle Wege, über die WoW einen Item-Tooltip füllt, und passt die Größe nach seinen Zeilen an. Der Selbsttest prüft jetzt den echten Taschen-Tooltip.
- **Esc schließt nur das oberste Fenster:** z. B. den Preisverlauf – Addon-Fenster und Auktionshaus bleiben offen (vorher ging mit einem Esc alles zu).
- **Preisverlauf:** Das X liegt nicht mehr auf dem Knopf „Alles“.
- **Testmodus** setzt jetzt auch Favoriten im Einkauf, die Liste zum Neu-Einstellen und die Post-Regeln zurück.
- **Deine eigene Suche geht vor:** Eine laufende Wächter-Runde wird abgebrochen, der Einkauf wartet nicht mehr („Warte auf den Wächter …“).
- Einkauf zeigt nach dem Kauf „Gekauft: …“ statt „Kauf wird ausgeführt …“.
- Übersicht: Preissprünge um das Zehnfache (fast immer Fehldaten) erscheinen nicht mehr als Anstieg oder Rückgang.
- Kleinigkeiten: Sniper-Käufe heißen im Testmodus-Protokoll „Sniper-Kauf“, die Einkaufslisten geben nach dem Löschen die Tastatur frei, „N Einträge“ überlappt nicht mehr, Option heißt kurz „Ablauf-Erinnerung“, Einstellgebühr im klassischen AH „beim Einstellen“ statt „?“, iLvl-Hinweis nur bei vorhandenen Treffern, Mausrad im Berichtsfenster schneller, Titel „Testbericht“.

## 0.60.7

- **Neuer Knopf „Test“** oben im Fenster (und in der Leiste im Auktionshaus): Selbsttest und der neue **Testmodus** in einem Fenster.
- **Testmodus:** Alle Funktionen von Hand mit deinen echten Auktionshaus-Daten ausprobieren – Kaufen, Bieten, Sniper (auch mit dem Mausrad), Einstellen, Abbrechen, Händler-Verkauf, Post abholen und verschicken. Jeder Handel ist **nur simuliert**: Der Befehl an den Server wird abgefangen und die Antwort des Servers nachgespielt – Meldungen, Buchhaltung und Sniper-Zähler verhalten sich wie echt. Beim Beenden sind alle Einstellungen und Daten (Listen, Buchhaltung, Sniper, Wächter, Verkaufen) wieder wie vorher – auch automatisch nach `/reload` oder einem Absturz. Ein Protokoll zeigt jede simulierte Aktion und kommt mit in den kopierten Bericht.
- ⚠️ Nur die Knöpfe des Addons sind simuliert – Blizzards eigene Knöpfe im Auktionshaus kaufen weiterhin echt. Auch: `/ahp testmodus`.

## 0.60.6

- **Selbsttest simuliert echten Handel:** Mit den echten Angeboten aus dem Auktionshaus spielt er jetzt Sofortkauf, Gebot, Sniper-Kauf, Einstellen und Abbrechen genau wie im Ernstfall durch – gleiches Angebot, gleicher Preis, gleicher Befehl. Nur der Befehl an den Server wird abgefangen: Es wird nichts gekauft, eingestellt oder abgebrochen, und am Ende prüft der Test, dass dein Gold unverändert ist. Meldungen im Chat sind dabei mit „[Simulation]“ markiert.
- **Selbsttest:** Der Wächter wird nach seiner Testrunde gleich wieder ausgeschaltet und blockiert die folgenden Server-Suchen nicht mehr.

## 0.60.5

- **Behoben (klassische Clients):** Beim Öffnen des Auktionshauses konnte der Lua-Fehler „attempt to compare number with nil“ kommen (Gebote nach einem Reload).
- **Kopfzeile:** „Sniper: an/aus“ und „Wächter: an/aus“ stimmen jetzt immer, auch nach dem Umschalten.
- **Selbsttest:** Läuft im Hintergrund noch ein Markt-Scan, laufen die Server-Suchen nicht mehr alle in die Zeitüberschreitung – beim Test mit gespeicherten Daten wird der Scan beendet, sonst wird auf ihn gewartet. Ein neuer Scan ist während des Tests gesperrt.
- **Selbsttest:** Danach sind Einstellungen, Wächter und Fenster (Reiter, oder geschlossen) zuverlässig wie vorher. Klappt etwas nicht, steht es im Bericht.
- **Textfenster** („Bericht kopieren“) öffnet sich immer vorne, beginnt oben und scrollt mit dem Mausrad zügig (mit Shift in großen Schritten).

## 0.60.4

- **Selbsttest mit gespeicherten Daten:** neuer Knopf „Mit gespeicherten Daten“ im Selbsttest-Fenster (oder `/ahp test daten`). Er testet mit den Auktionshaus-Daten, die du schon gescannt hast – **kein neuer Scan**. Er läuft sogar bei geschlossenem Auktionshaus, dann werden nur die Suchen beim Server übersprungen.

## 0.60.3

- **Behoben für TBC Anniversary (und andere klassische Clients):** „Meine Auktionen“ wurde nie aktualisiert, und manche Meldungen des Auktionshauses (z. B. „eingestellt“) kamen nicht an. Diese Clients kennen die Ereignis-Namen des neuen Auktionshauses, lösen sie beim klassischen aber nie aus – das Addon nutzt dort jetzt immer seine eigenen. Gefunden mit dem neuen Selbsttest.
- **Selbsttest:** Der kopierte Bericht lässt sich jetzt scrollen, die Ergebnisliste ist breiter – Maus über eine Zeile zeigt den ganzen Text.

## 0.60.2

- **Selbsttest:** Optionen → „Selbsttest“ oder `/ahp test` prüft alle Funktionen mit echten Daten aus deinem Auktionshaus: Markt-Scan (falls nötig), Marktdaten, alle Reiter, alle Auswertungen und echte Suchen beim Server (Einkauf, Preisprüfung, Sniper, Wächter, eigene Auktionen). Während des Tests sind **Kaufen, Bieten, Einstellen und Abbrechen gesperrt**, danach sind Einstellungen und Sniper-Ziele wie vorher. Das Ergebnis erscheint in einem Fenster, lässt sich als Bericht kopieren und wird gespeichert.

## 0.60.1

- **Echter Minikarten-Knopf:** Der Knopf sitzt jetzt wie bei anderen Addons an der Minikarte – mit der Maus **rund um die Minikarte ziehen**, die Position wird gespeichert. Funktioniert mit runden und eckigen Minikarten. Ein-/ausblenden in den Optionen oder mit `/ahp minimap`, `/ahp reset` holt ihn zurück.
- **Neues Icon:** eine goldene **Waage** – am Minikarten-Knopf, oben im Fenster und in der Addon-Liste.

## 0.60.0

**Aufgeräumtes Fenster – 5 Reiter statt 11:**

- **Übersicht · Kaufen · Verkaufen · Markt · Buchhaltung.** Was zusammengehört, steht jetzt als Unterreiter:
  Kaufen = Einkauf, Sniper, Wächter, Schnäppchen · Verkaufen = Einstellen, Meine Auktionen · Markt = Alle Preise, Watchlist.
  Alle Funktionen sind noch da, nichts ist weggefallen.
- **Preisverlauf im eigenen Fenster:** Ein Klick auf ein Item öffnet den Verlauf neben dem Addon – die Liste, aus der du kommst, bleibt genau, wo sie war. Das Fenster lässt sich verschieben und in der Größe ziehen.
- **Sniper und Wächter in der Kopfzeile:** auf einen Blick sehen, ob sie laufen, und mit einem Klick an- oder ausschalten (Rechtsklick öffnet ihren Reiter).
- **Merkt sich, wo du warst:** Das Addon öffnet sich im zuletzt benutzten Reiter, jeder Haupt-Reiter merkt sich seinen Unterreiter.

## 0.59.33

**Komfort-Update – zwölf kleine Dinge, die jeden Tag Klicks sparen:**

- **Stapelgröße und Anzahl Stapel** (klassisches Auktionshaus): z. B. 5 Stapel à 20 – wird pro Item gemerkt, auch für die Serie.
- **Post automatisch abholen:** Beim Öffnen des Briefkastens wird die Auktionspost gleich abgeholt (Shift beim Öffnen = diesmal nicht).
- **Mindestpreis pro Item:** Knopf „Min“ beim Verkaufen – darunter wird nie unterboten, die Serie wartet statt billig zu verkaufen.
- **Nur was mir fehlt:** Am Berufsfenster kommt nur die fehlende Menge auf die Einkaufsliste (Taschen, Bank und Twinks werden gezählt).
- **Alt-Klick auf ein Item** in den Taschen oder im Chat: öffnet den Preisverlauf, bei offenem Auktionshaus den Einkauf.
- **Verkaufschance im Tooltip:** wie viel von dem, was du eingestellt hast, verkauft wurde und wie lange es meist dauert.
- **Erinnerung bei ablaufenden Auktionen** und beim Einloggen, was seit dem letzten Besuch abgelaufen ist.
- **Favoriten im Einkauf:** Suchen speichern und mit einem Klick wieder ausführen.
- **Gold-Ziel** für alle Charaktere zusammen (Optionen oder `/ahp ziel 5000`).
- **Gildenbank-Wert** in der Buchhaltung (ab TBC).
- **Raid-Vorrat:** Einkaufsliste mit Tränken, Fläschchen, Elixieren und Buff-Food für eine Raidwoche (`/ahp raid`).
- **Preis-Sync nur mit der Gilde** als neue Option.

## 0.59.32

- **Keine absurden Gewinne mehr:** Items mit 1000 % Gewinn oder mehr (fast immer Fehldaten) erscheinen nicht mehr bei den Schnäppchen und nicht mehr unter „Größte Preisanstiege“.

## 0.59.31

- **Itemlevel als Suchfilter:** Felder „iLvl ab / bis“ im Einkauf und im Markt – filtern sofort, ohne neue Suche beim Server.

## 0.59.30

- **Schrott beim Händler verkaufen** mit einem Knopf (graue Items und alles, was beim Händler mehr bringt).
- **Vermögen:** Wert von Taschen, Bank und Twinks plus das Gold aller Charaktere.
- **Tagesbilanz beim Einloggen**, jederzeit mit `/ahp bilanz`.
- **Neu einstellen mit einem Klick** für abgelaufene Auktionen.
- **Flip-Empfehlungen**, **Post an Twinks**, **/ahp help** im Chat.
- Einkauf: iLvl für jedes Item · Verkaufen: Angebote erscheinen viel schneller.
