-- ThreatSentinel - TestRoutine.lua
-- Automatische Testroutine ("auf Herz und Nieren"), nur für den Entwickler (GoldSentinelDev).
--   /ts testroutine            alle Bereiche A bis K
--   /ts testroutine a … k      nur ein Bereich (K = Oberfläche im echten Client)
--   /ts testroutine halb       Liste der halbautomatischen Schritte
--   /ts testroutine letzte     letzten gespeicherten Bericht zeigen
-- Ergebnisse nur über GoldSentinelTest (T:Check / T:Skip / T:Client). IDs wie in testroutine-threatsentinel.txt.
--
-- Regeln (nachtrag-testroutinen.txt):
--   * Keine Blizzard-Funktion wird ersetzt. Ersetzt werden nur Felder eigener Tabellen (ns, Module), immer am Ende
--     des Bereichs zurückgesetzt. Was sich nur über eine ersetzte Blizzard-Funktion prüfen liesse, ist ÜBERSPRUNGEN
--     (mit Grund) oder IM CLIENT PRÜFEN.
--   * Aktionen mit Folgen (Chat, Addon-Nachrichten, CVars, Tastenbelegung, Neuladen, Betrachten, Töne) laufen im
--     Addon über ns.Act. Während der Routine schreibt ns.Act nur mit. Echte Aufrufe werden über hooksecurefunc gezählt
--     (Erwartung 0).
--   * Geschützte Werte: Köderwert ns.testBait, den ns.IsSecret als geschützt erkennt (issecretvalue bleibt unberührt).
--   * Sandbox: ThreatSentinelDB und der Laufzustand werden vorher kopiert und nach jedem Bereich in dieselben Tabellen
--     zurückgeschrieben (ns.db bleibt mit den gespeicherten Daten verbunden).

local ADDON, ns = ...
local L = ns.L

local R = {}
ns.Routine = R

local AREAS = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K" }
R.AREAS = AREAS
local RUN                     -- laufender Durchlauf (GoldSentinelTest-Objekt)

------------------------------------------------------------
-- Hilfen
------------------------------------------------------------
local function InCombat()
	return (InCombatLockdown and InCombatLockdown()) or (UnitAffectingCombat and UnitAffectingCombat("player")) or false
end

local function Ms()
	if debugprofilestop then return debugprofilestop() end
	return GetTime() * 1000
end

local function Copy(v, seen)
	if type(v) ~= "table" then return v end
	seen = seen or {}
	if seen[v] then return seen[v] end
	local t = {}
	seen[v] = t
	for k, x in pairs(v) do t[Copy(k, seen)] = Copy(x, seen) end
	return t
end

local function IsGsKey(k) return type(k) == "string" and k:sub(1, 2) == "gs" end

-- dst in-place auf den Stand von src bringen (dieselben Tabellen bleiben erhalten)
local function RestoreInto(dst, src, top)
	for k in pairs(dst) do
		if src[k] == nil and not (top and IsGsKey(k)) then dst[k] = nil end
	end
	for k, v in pairs(src) do
		if not (top and IsGsKey(k)) then
			if type(v) == "table" and type(dst[k]) == "table" then RestoreInto(dst[k], v)
			else dst[k] = Copy(v) end
		end
	end
end

-- erster abweichender Pfad oder nil
local function Diff(a, b, path, top)
	if type(a) ~= type(b) then return path end
	if type(a) ~= "table" then
		if a ~= b then return path end
		return nil
	end
	for k, v in pairs(a) do
		if not (top and IsGsKey(k)) then
			local d = Diff(v, b[k], path .. "." .. tostring(k))
			if d then return d end
		end
	end
	for k in pairs(b) do
		if not (top and IsGsKey(k)) and a[k] == nil then return path .. "." .. tostring(k) end
	end
	return nil
end

local function Eq(a, b) return a == b end
local function Near(a, b, tol) return type(a) == "number" and type(b) == "number" and math.abs(a - b) <= (tol or 0.01) end
local function S(v) if v == nil then return "nil" end return tostring(v) end

-- Testnamen nie im Bericht (auch erfundene werden durch <Name> ersetzt)
local FAKE = { "Grimbar", "Torben", "Anna" }
local function Clean(v)
	local s = S(v)
	for _, n in ipairs(FAKE) do s = s:gsub(n, "<Name>") end
	if ns.playerName and ns.playerName ~= "" then s = s:gsub(ns.playerName:gsub("%p", "%%%0"), "<Name>") end
	return s
end

------------------------------------------------------------
-- Ersetzen eigener Felder (nie _G, nie Blizzard-Tabellen)
------------------------------------------------------------
local swaps = {}
local function Swap(tbl, key, value)
	assert(type(tbl) == "table" and not rawequal(tbl, _G), "Swap: nur eigene Tabellen")
	swaps[#swaps + 1] = { tbl, key, rawget(tbl, key) }
	tbl[key] = value
end
local function UnswapAll()
	for i = #swaps, 1, -1 do
		local s = swaps[i]
		s[1][s[2]] = s[3]
		swaps[i] = nil
	end
end

------------------------------------------------------------
-- Köderwert für geschützte Werte
------------------------------------------------------------
local function NewBait()
	local p, mt
	if newproxy then
		p = newproxy(true)
		mt = getmetatable(p)
	else
		p, mt = {}, {}
		setmetatable(p, mt)
	end
	local function boom() error("secret value used", 2) end
	for _, k in ipairs({ "__add", "__sub", "__mul", "__div", "__mod", "__unm", "__concat", "__lt", "__le", "__len", "__index", "__newindex", "__call" }) do
		mt[k] = boom
	end
	mt.__tostring = function() return "SECRET" end
	return p
end
local SECRET = NewBait()

------------------------------------------------------------
-- Echte Aktionen zählen (hooksecurefunc ersetzt nichts und verseucht nichts)
------------------------------------------------------------
R.realCalls = 0
local hooked = false
local function InstallHooks()
	if hooked or not hooksecurefunc then return end
	hooked = true
	local function count() if R.inArea then R.realCalls = R.realCalls + 1 end end
	for _, name in ipairs({ "SendChatMessage", "SendAddonMessage", "SetCVar", "SetBinding", "SaveBindings", "NotifyInspect", "Screenshot", "ReloadUI" }) do
		if type(_G[name]) == "function" then pcall(hooksecurefunc, name, count) end
	end
	if C_ChatInfo and type(C_ChatInfo.SendAddonMessage) == "function" then pcall(hooksecurefunc, C_ChatInfo, "SendAddonMessage", count) end
	if C_ChatInfo and type(C_ChatInfo.SendChatMessage) == "function" then pcall(hooksecurefunc, C_ChatInfo, "SendChatMessage", count) end
	if C_CVar and type(C_CVar.SetCVar) == "function" then pcall(hooksecurefunc, C_CVar, "SetCVar", count) end
end

------------------------------------------------------------
-- Sandbox
------------------------------------------------------------
local NS_KEYS = { "testMode", "liveTest", "simSecret", "simAccess", "threatAccess", "isModern", "isRetail", "flavor",
	"errorCount", "lastError", "errorNoticed", "memberNow", "aggroLeader", "tankAtPull", "moveMode", "class",
	"tauntSpell", "tauntMode", "routineSelfTest" }
local NS_TABLES = { "syncRoles", "fakeNames", "cdTrack", "compat", "blocked", "owners" }
local CVARS = { "nameplateShowEnemies", "threatShowNumeric", "threatWarning" }

local function GetCV(name)
	local ok, v
	if C_CVar and C_CVar.GetCVar then ok, v = pcall(C_CVar.GetCVar, name)
	elseif GetCVar then ok, v = pcall(GetCVar, name) end
	if ok then return v end
end

local function ModTables()
	local list = {}
	local TA, Sy, K, DM, A = ns.ThreatAccess, ns.Sync, ns.Track, ns.DmgMeter, ns.Alerts
	if TA then list.TA = { TA, { "checked", "attempts", "announced", "wantBlizzard", "lastProbe", "tempNone" } } end
	if Sy then list.Sync = { Sy, { "claims", "taunts", "cd" } } end
	if K then list.Track = { K, { "sunder", "cc", "ccSince", "ccBreak" } } end
	if DM then list.DM = { DM, { "total", "cur", "showTotal" } } end
	if A then list.Alerts = { A, { "extras" } } end
	if ns.Log then list.Log = { ns.Log, { "on" } } end
	if ns.Specs then list.Specs = { ns.Specs, { "pending", "lastInspect", "failed" } } end
	if ns.Test then list.Test = { ns.Test, { "clientSim" } } end
	return list
end

local function FrameStates()
	local out = {}
	for _, k in ipairs({ "HUD", "Meter", "DD", "DmgMeter" }) do
		local m = ns[k]
		if m and m.f then out[k] = m.f:IsShown() and true or false end
	end
	return out
end

function R:TakeSandbox()
	local sb = { db = {}, ns = {}, nsT = {}, mod = {}, cvars = {}, keys = {} }
	for k, v in pairs(ThreatSentinelDB or {}) do
		if not IsGsKey(k) then sb.db[k] = Copy(v) end
	end
	sb.dbRef, sb.profile = ThreatSentinelDB, ns.db
	for _, k in ipairs(NS_KEYS) do sb.ns[k] = { ns[k] } end
	for _, k in ipairs(NS_TABLES) do sb.nsT[k] = Copy(ns[k] or {}) end
	for name, e in pairs(ModTables()) do
		local saved = {}
		for _, f in ipairs(e[2]) do saved[f] = { Copy(e[1][f]) } end
		sb.mod[name] = saved
	end
	for _, c in ipairs(CVARS) do sb.cvars[c] = GetCV(c) end
	if ns.Taunt and ns.Taunt.BIND and GetBindingKey then
		for which, cmd in pairs(ns.Taunt.BIND) do
			local k1, k2 = GetBindingKey(cmd)
			sb.keys[which] = tostring(k1) .. "/" .. tostring(k2)
		end
	end
	sb.frames = FrameStates()
	self.sb = sb
end

function R:RestoreSandbox()
	local sb = self.sb
	if not sb then return end
	-- gespeicherte Daten: dieselbe Tabelle wie vorher
	ThreatSentinelDB = sb.dbRef
	RestoreInto(ThreatSentinelDB, sb.db, true)
	ns.db = sb.profile
	for _, k in ipairs(NS_KEYS) do ns[k] = sb.ns[k][1] end
	for _, k in ipairs(NS_TABLES) do
		if type(ns[k]) ~= "table" then ns[k] = {} end
		RestoreInto(ns[k], sb.nsT[k])
	end
	for name, e in pairs(ModTables()) do
		local saved = sb.mod[name]
		if saved then
			for f, box in pairs(saved) do
				local v = box[1]
				if type(v) == "table" and type(e[1][f]) == "table" then RestoreInto(e[1][f], v)
				else e[1][f] = Copy(v) end
			end
		end
	end
	if GoldSentinelGame and GoldSentinelGame.SetTestFlavor then pcall(GoldSentinelGame.SetTestFlavor, nil) end
	ns.testBait = nil
	-- Anzeigen wie vorher
	for k, shown in pairs(sb.frames or {}) do
		local m = ns[k]
		if m and m.f then if shown then m.f:Show() else m.f:Hide() end end
	end
	if ns.UpdateSpells then pcall(ns.UpdateSpells, ns) end
end

-- nach der Wiederherstellung: stimmt alles?
function R:CheckSandbox()
	local sb = self.sb
	local d = Diff(ThreatSentinelDB or {}, sb.db, "ThreatSentinelDB", true)
	if d then return false, d end
	if ns.db ~= sb.profile or ThreatSentinelDB ~= sb.dbRef then return false, "ns.db getrennt" end
	if ns.profileName and ThreatSentinelDB.profiles and ThreatSentinelDB.profiles[ns.profileName] ~= ns.db then
		return false, "ns.db ~= profiles[profil]"
	end
	return true
end

function R:CheckCVars()
	for _, c in ipairs(CVARS) do
		if GetCV(c) ~= self.sb.cvars[c] then return false, c end
	end
	return true
end

function R:CheckKeys()
	if not (ns.Taunt and ns.Taunt.BIND and GetBindingKey) then return true end
	for which, cmd in pairs(ns.Taunt.BIND) do
		local k1, k2 = GetBindingKey(cmd)
		local now = tostring(k1) .. "/" .. tostring(k2)
		if now ~= self.sb.keys[which] then return false, which end
	end
	return true
end

------------------------------------------------------------
-- Prüfungen
------------------------------------------------------------
local function C(id, area, name, fn) RUN:Check(id, area, name, fn) end
local function K(id, area, name, why) RUN:Skip(id, area, name, why) end
local function CL(id, area, name, how) RUN:Client(id, area, name, how) end

local NO_STUB = "noch nicht automatisiert (Test-Kulisse vorhanden, Fall folgt)"
-- noch nicht automatisierte Fälle: gezählt und im Bericht als "nicht automatisiert: N" ausgewiesen
local function KN(id, area, name)
	R.notAuto = (R.notAuto or 0) + 1
	RUN:Skip(id, area, name, NO_STUB)
end

-- Ausgabe einer Funktion abfangen (ns:Print, TM:Say)
local function Capture(fn)
	local lines = {}
	Swap(ns, "Print", function(_, msg) lines[#lines + 1] = tostring(msg) end)
	if ns.Test then Swap(ns.Test, "Say", function(_, msg) lines[#lines + 1] = "[Test] " .. tostring(msg) end) end
	local ok, err = pcall(fn)
	UnswapAll()
	if not ok then error(err, 0) end
	return lines
end

local function Has(lines, text)
	if not text then return false end
	for _, l in ipairs(lines) do if l:find(text, 1, true) then return true end end
	return false
end

------------------------------------------------------------
-- ns.API-Einträge vorübergehend ersetzen (nie die Blizzard-Funktion selbst)
------------------------------------------------------------
local NIL = {}   -- Platzhalter: Eintrag fehlt (wie eine im Client fehlende Funktion)
local function WithAPI(map, fn)
	local A = ns.API
	local saved, bait = {}, ns.testBait
	for k, v in pairs(map) do
		saved[k] = { rawget(A, k) }
		if v == NIL then A[k] = nil else A[k] = v end
	end
	ns.testBait = SECRET
	local function finish(ok, ...)
		for k, box in pairs(saved) do A[k] = box[1] end
		ns.testBait = bait
		if not ok then error((...), 0) end
		return ...
	end
	return finish(pcall(fn))
end
local function Ret(...)
	local n, v = select("#", ...), { ... }
	return function() return unpack(v, 1, n) end
end
local function Num(x) return type(x) == "number" and x or -1 end

------------------------------------------------------------
-- Test-Kulisse: Test-Einheiten, Gruppe, Bedrohung und Plaketten – nur über ns.API-Einträge und die eigenen
-- Vorschau-Plaketten der Testzentrale (keine Blizzard-Plakette, keine Blizzard-Funktion wird angefasst)
------------------------------------------------------------
local Scene = {}
R.Scene = Scene

-- Standard: du (Tank) + Magier (DD) + Priester (Heiler) + Krieger (zweiter Tank) und nMobs Testmobs,
-- jeder Mob wird von dir gehalten
function Scene.New(nMobs)
	local sc = { units = {}, threat = {}, alias = {}, plates = {}, forbidden = {}, group = { "party1", "party2", "party3" },
		tank = true, centers = {}, plays = 0 }
	sc.units.player = { name = "Anna", player = true, class = ns.class or "WARRIOR", combat = true, power = 1 }
	sc.units.party1 = { name = "Torben", player = true, class = "MAGE", role = "DAMAGER", combat = true, power = 0 }
	sc.units.party2 = { name = "Lina", player = true, class = "PRIEST", role = "HEALER", combat = true, power = 0 }
	sc.units.party3 = { name = "Grimbar", player = true, class = "WARRIOR", role = "TANK", combat = true, power = 1 }
	sc.nMobs = nMobs or 5
	for i = 1, sc.nMobs do
		local u = "tsfake" .. i
		sc.units[u] = { name = "Testmob " .. i, guid = string.format("Creature-0-0-0-0-91%03d-%010d", i, i), hostile = true,
			combat = true, hp = 80, hpMax = 100 }
	end
	for i = 1, sc.nMobs do Scene.Hold(sc, "tsfake" .. i, "player") end
	return sc
end

-- Wer hält den Mob? others = { party1 = 95 } (Anteil in % der Bedrohung des Halters)
function Scene.Hold(sc, mob, holder, others)
	local t = {}
	if holder then t[holder] = { true, 3, 100, 100, 1000 } end
	for unit, pct in pairs(others or {}) do t[unit] = { false, pct >= 100 and 1 or 0, pct, pct, pct * 10 } end
	sc.threat[mob] = t
	sc.alias[mob .. "target"] = holder
end

function Scene.Map(sc)
	local U = sc.units
	local function real(u)
		if type(u) ~= "string" or ns.IsSecret(u) then return nil end
		return sc.alias[u] or u
	end
	local function get(u) local r = real(u); return r and U[r] or nil end
	local function f(fn) return function(u, ...) return fn(get(u), u, ...) end end
	local function threat(u, mob)
		local t = sc.threat[real(mob) or ""]
		return t and t[real(u) or ""]
	end
	local group = sc.group or {}
	return {
		UnitExists = f(function(e) return e ~= nil end),
		UnitName = f(function(e) if e then return e.name, e.realm end end),
		UnitGUID = f(function(e) return e and e.guid end),
		UnitIsUnit = function(a, b) local x, y = real(a), real(b); return x ~= nil and U[x] ~= nil and x == y end,
		UnitIsPlayer = f(function(e) return e and e.player or false end),
		UnitClass = f(function(e) if e and e.class then return e.class, e.class end end),
		UnitPowerType = f(function(e) return e and e.power or 1 end),
		UnitCanAttack = function(_, u) local e = get(u); return e and e.hostile or false end,
		UnitIsDeadOrGhost = f(function(e) return e and e.dead or false end),
		UnitIsDead = f(function(e) return e and e.dead or false end),
		UnitAffectingCombat = f(function(e) return e and e.combat or false end),
		UnitIsConnected = f(function(e) return e ~= nil end),
		UnitHealth = f(function(e) return e and e.hp or 100 end),
		UnitHealthMax = f(function(e) return e and e.hpMax or 100 end),
		UnitInRange = f(function(e) return e ~= nil, true end),
		GetRaidTargetIndex = f(function(e) return e and e.mark end),
		UnitGroupRolesAssigned = f(function(e) return e and e.role or "NONE" end),
		GetPartyAssignment = function() return false end,
		UnitBuff = function() return nil end,
		UnitDebuff = function() return nil end,
		UnitDetailedThreatSituation = function(u, mob)
			if sc.secret then return SECRET, SECRET, SECRET, SECRET, SECRET end
			local r = threat(u, mob)
			if r then return r[1], r[2], r[3], r[4], r[5] end
		end,
		UnitThreatSituation = function(u, mob)
			if sc.secret then return SECRET end
			local r = threat(u, mob)
			return r and r[2] or nil
		end,
		IsInGroup = Ret(#group > 0 or sc.raid ~= nil),
		IsInRaid = Ret(sc.raid ~= nil),
		GetNumSubgroupMembers = Ret(#group),
		GetNumGroupMembers = Ret(sc.raid or (#group + 1)),
		C_NamePlate = {
			GetNamePlateForUnit = function(u)
				local r = real(u)
				local uf = r and sc.plates[r]
				if not uf then return nil end
				local p = { UnitFrame = uf, namePlateUnitToken = r }
				if sc.forbidden[r] then p.IsForbidden = function() return true end end
				return p
			end,
			GetNamePlates = function() return {} end,
		},
	}
end

-- fn(sc) in der Kulisse ausführen. Danach ist alles wie vorher: ns.mobs, Gruppe, Besitzer, Sync-Rollen,
-- Anführer, Zwischenspeicher, Vorschau-Plaketten, ersetzte Funktionen.
function Scene.Run(sc, fn)
	local TM, TA, S = ns.Test, ns.ThreatAccess, ns.Sync
	TM:CreatePreview()
	local pp = TM.preview.plates
	for i = 1, sc.nMobs do
		local u = "tsfake" .. i
		if sc.plates[u] == nil then sc.plates[u] = pp[(i - 1) % #pp + 1] end
	end
	local save = {
		mobs = {}, owners = Copy(ns.owners), syncRoles = Copy(ns.syncRoles), claims = Copy(S.claims or {}),
		taunts = Copy(S.taunts or {}), extras = Copy(ns.Alerts.extras or {}),
		gu = ns.groupUnits, gn = ns.groupNames, nu = ns.nameToUnit, member = ns.memberNow, leader = ns.aggroLeader,
		leaderT = ns.aggroLeaderT, lastTankT = ns.lastTankT, lastMode = ns.Threat.lastMode, access = ns.threatAccess,
		simAccess = ns.simAccess, checked = TA.checked, announced = TA.announced, want = TA.wantBlizzard,
		stored = ThreatSentinelDB and ThreatSentinelDB.threatAccess, testMode = ns.testMode, liveTest = ns.liveTest,
	}
	for k, v in pairs(ns.mobs) do save.mobs[k] = v end
	wipe(ns.mobs)
	for i = 1, sc.nMobs do ns.mobs["tsfake" .. i] = { unit = "tsfake" .. i } end
	ns:ClearRoleCache()
	ns.memberNow, ns.testMode, ns.liveTest = false, false, false
	TA.checked = true
	if ns.isModern and ns.threatAccess ~= "secret" and ns.threatAccess ~= "none" then ns.threatAccess = "open" end
	Swap(ns, "IsTankStance", function() return sc.tank and true or false end)
	Swap(ns.Alerts, "Center", function(_, text) sc.centers[#sc.centers + 1] = tostring(text) end)
	Swap(ns.Alerts, "Play", function() sc.plays = sc.plays + 1 end)
	Swap(TA, "ApplyBlizzard", function() end)
	local function finish(ok, ...)
		UnswapAll()
		for u in pairs(ns.mobs) do ns.Track:Forget("plate:" .. u) end
		for _, e in pairs(sc.units) do if e.guid then ns.Track:Forget(e.guid) end end
		wipe(ns.mobs)
		for k, v in pairs(save.mobs) do ns.mobs[k] = v end
		RestoreInto(ns.owners, save.owners)
		RestoreInto(ns.syncRoles, save.syncRoles)
		if S.claims then RestoreInto(S.claims, save.claims) end
		if S.taunts then RestoreInto(S.taunts, save.taunts) end
		if ns.Alerts.extras then RestoreInto(ns.Alerts.extras, save.extras) end
		ns.groupUnits, ns.groupNames, ns.nameToUnit = save.gu, save.gn, save.nu
		ns.memberNow, ns.aggroLeader, ns.aggroLeaderT, ns.lastTankT = save.member, save.leader, save.leaderT, save.lastTankT
		ns.Threat.lastMode, ns.threatAccess, ns.simAccess = save.lastMode, save.access, save.simAccess
		TA.checked, TA.announced, TA.wantBlizzard = save.checked, save.announced, save.want
		if ThreatSentinelDB then ThreatSentinelDB.threatAccess = save.stored end
		ns.testMode, ns.liveTest = save.testMode, save.liveTest
		ns:ClearRoleCache()
		for _, uf in ipairs(pp) do
			pcall(ns.Plates.RestoreFrame, ns.Plates, uf)
			if ns.Plates.pendingRestore then ns.Plates.pendingRestore[uf] = nil end
		end
		if not ok then error((...), 0) end
		return ...
	end
	return finish(pcall(WithAPI, Scene.Map(sc), function()
		ns:UpdateGroup()
		return fn(sc)
	end))
end

-- zählt Aufrufe einer Modul-Funktion (die echte läuft weiter, ausser pass == false)
local function Counter(tbl, key, pass)
	local c = { n = 0 }
	local orig = tbl[key]
	Swap(tbl, key, function(...)
		c.n = c.n + 1
		if pass ~= false and orig then return orig(...) end
	end)
	return c
end

local function Shown(f) return f and f:IsShown() and true or false end

local function FormatStem(fmt)
	-- fester Anfang eines Formattexts (bis zum ersten Platzhalter), zum Wiederfinden in der Ausgabe
	return (fmt or ""):match("^([^%%]*)") or ""
end

local function WithFlavor(f, fn)
	local G = GoldSentinelGame
	G.SetTestFlavor(f)
	ns.isModern = G.IsModern and true or false
	local ok, a, b, c = pcall(fn)
	G.SetTestFlavor(nil)
	ns.isModern = G.IsModern and true or false
	if not ok then error(a, 0) end
	return a, b, c
end

------------------------------------------------------------
-- A. Laden und Erkennung
------------------------------------------------------------
local Area = {}

Area.A = function()
	local G = GoldSentinelGame
	C("T01", "A", "Alle Dateien und Module geladen", function()
		local need = { "L", "Game", "Plates", "Donate", "Alerts", "DD", "DmgMeter", "Guide", "HUD", "Log", "Meter", "Mover",
			"Options", "Specs", "Sync", "Taunt", "Test", "Threat", "ThreatAccess", "Track", "Routine" }
		local miss = {}
		for _, k in ipairs(need) do if ns[k] == nil then miss[#miss + 1] = k end end
		if not GoldSentinelTest then miss[#miss + 1] = "GoldSentinelTest" end
		if #miss > 0 then return false, table.concat(miss, ","), "nichts fehlt" end
		return #ns.modules == 16, "#modules=" .. #ns.modules, "16"
	end)
	C("T02", "A", "Version .toc = Code", function()
		local get = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
		local toc = get and get(ADDON, "Version")
		return toc == ns.version, S(toc), ns.version
	end)
	C("T03", "A", "GoldSentinelGame Version 2", function()
		if not G then return false, "fehlt", "vorhanden" end
		local miss = {}
		for _, k in ipairs({ "flavor", "IsModern", "IsOldAPI", "HasSecrets", "IsSecret", "AnySecret", "Safe", "InCombat",
			"Short", "CleanName", "SameName", "Status", "SetTestFlavor", "Recalc" }) do
			if G[k] == nil then miss[#miss + 1] = k end
		end
		for _, k in ipairs({ "IsEra", "IsForever", "IsTBC", "IsWrath", "IsTitan", "IsCata", "IsMists", "IsRetail" }) do
			if G[k] == nil then miss[#miss + 1] = k end
		end
		if #miss > 0 then return false, table.concat(miss, ","), "alles vorhanden" end
		if G.version ~= 2 or G.apiVersion ~= 2 then return false, S(G.version) .. "/" .. S(G.apiVersion), "2/2" end
		return ns.Game == G and type(G.Status()) == "string", "ns.Game", "GoldSentinelGame"
	end)
	C("T04", "A", "Erkennung echt", function()
		local A, DM, TA = ns.Alerts, ns.DmgMeter, ns.ThreatAccess
		if ns.isModern ~= (G.IsModern and true or false) then return false, "isModern " .. S(ns.isModern), S(G.IsModern) end
		if ns.isRetail ~= (G.IsRetail and true or false) then return false, "isRetail " .. S(ns.isRetail), S(G.IsRetail) end
		if ns.flavor ~= G.flavor then return false, S(ns.flavor), S(G.flavor) end
		if A.cleuAllowed ~= (not ns.isModern) or A.cleuRegistered ~= A.cleuAllowed then return false, "cleu " .. S(A.cleuAllowed) .. "/" .. S(A.cleuRegistered), S(not ns.isModern) end
		if DM.allowed ~= (not ns.isModern) then return false, "DM.allowed " .. S(DM.allowed), S(not ns.isModern) end
		if not ns.isModern and (ns.threatAccess ~= "open" or TA.checked ~= true) then return false, S(ns.threatAccess) .. "/" .. S(TA.checked), "open/true" end
		return true, (ns.isModern and "modern" or "alt") .. "/" .. S(ns.flavor)
	end)
	C("T05", "A", "Simulation G.SetTestFlavor – GoldSentinelGame", function()
		local want = { forever = { "IsForever", "IsModern" }, era = { "IsEra", "IsOldAPI" }, tbc = { "IsTBC", "IsOldAPI" }, retail = { "IsRetail", "IsModern" } }
		local bad
		for f, keys in pairs(want) do
			G.SetTestFlavor(f)
			for _, k in ipairs(keys) do if not G[k] then bad = f .. ":" .. k end end
			if not (tostring(G.Status()):lower()):find("[test]", 1, true) then bad = f .. ":Status ohne [Test]" end
			G.SetTestFlavor(nil)
			if bad then break end
		end
		return bad == nil, bad or "ok", "alle Simulationen richtig"
	end)
	C("T06", "A", "Simulation – Weichen des Addons (ohne Kampfsperre-Teile)", function()
		local db, cls = ns.db, ns.class
		local saveAcc, saveMode = ns.threatAccess, db.threatMode
		local bad
		for _, f in ipairs({ "forever", "era", "tbc", "retail" }) do
			WithFlavor(f, function()
				local modern = ns.isModern
				ns.threatAccess = "unknown"
				db.threatMode = "AUTO"
				if ns:ThreatMode() ~= "FULL" then bad = f .. ": unknown ausserhalb Kampf " .. ns:ThreatMode() end
				db.threatMode = "DISPLAY"
				local m = ns:ThreatMode()
				if modern and m ~= "DISPLAY" then bad = f .. ": DISPLAY erzwungen -> " .. m end
				if not modern and m ~= "FULL" then bad = f .. ": alt DISPLAY -> " .. m end
				ns.class = "DRUID"
				local t = ns:DeficitText()
				if modern and t ~= L.DEFICIT_OTHER then bad = f .. ": Druide " .. S(t) end
				if not modern and t ~= L.DEFICIT_DRUID then bad = f .. ": Druide " .. S(t) end
				ns.class = cls
			end)
			ns.threatAccess, db.threatMode = saveAcc, saveMode
			if bad then break end
		end
		ns.class = cls
		return bad == nil, bad or "ok", "Weichen wie angegeben"
	end)
	C("T07", "A", "Beim Laden festgelegte Weichen bleiben", function()
		local A, DM = ns.Alerts, ns.DmgMeter
		local a1, a2, a3 = A.cleuAllowed, A.cleuRegistered, DM.allowed
		local b1, b2, b3 = WithFlavor(ns.isModern and "era" or "forever", function() return A.cleuAllowed, A.cleuRegistered, DM.allowed end)
		return a1 == b1 and a2 == b2 and a3 == b3, "Kampflog/Meter: Simulation erst nach /reload", "unverändert"
	end)
	C("T08", "A", "Weichen wieder echt", function()
		G.SetTestFlavor(nil)
		local st = tostring(G.Status())
		return ns.isModern == (G.IsModern and true or false) and not st:lower():find("[test]", 1, true), S(ns.isModern), S(G.IsModern)
	end)
	C("T09", "A", "Ereignisse angemeldet", function()
		local miss = {}
		for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "NAME_PLATE_UNIT_ADDED",
			"NAME_PLATE_UNIT_REMOVED", "UNIT_THREAT_LIST_UPDATE", "CHAT_MSG_ADDON", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_HEALTH",
			"GROUP_ROSTER_UPDATE", "UNIT_PET", "UNIT_AURA", "UPDATE_SHAPESHIFT_FORM", "ADDON_ACTION_BLOCKED", "ADDON_ACTION_FORBIDDEN",
			"SPELLS_CHANGED", "INSPECT_READY" }) do
			if not ns:HasHandler(e) then miss[#miss + 1] = e end
		end
		if #miss > 0 then return false, table.concat(miss, ","), "alle angemeldet" end
		local cleu = ns:HasHandler("COMBAT_LOG_EVENT_UNFILTERED")
		if cleu ~= (not ns.isModern) then return false, "Kampflog " .. S(cleu), S(not ns.isModern) end
		local okOn, res = pcall(ns.On, ns, "TS_GIBT_ES_NICHT", function() end)
		return okOn and res == false, S(res), "false"
	end)
	C("T10", "A", "Befehle angemeldet", function()
		return SLASH_THREATSENTINEL1 == "/ts" and SLASH_THREATSENTINEL2 == "/threatsentinel"
			and type(SlashCmdList.THREATSENTINEL) == "function" and SlashCmdList.GOLDSENTINELGAME ~= nil
			and SlashCmdList.GOLDSENTINELDEV ~= nil, "ok", "/ts, /threatsentinel, /gsgame, /gsdev"
	end)
	CL("T11", "A", "Interface-Nummer des Clients in der .toc", "Interface steht in der Kopfzeile des Berichts; die Prüf-Sitzung vergleicht sie mit ## Interface (am Launch-Tag /dump select(4, GetBuildInfo()))")
end

------------------------------------------------------------
-- B. Jede Funktion des Addons
------------------------------------------------------------
Area.B = function()
	local TA, A, Sy = ns.ThreatAccess, ns.Alerts, ns.Sync
	C("T12", "B", "ns.IsSecret / ns.Safe", function()
		ns.testBait = SECRET
		ns.simSecret = true
		local r = { ns.IsSecret(5, "auras"), ns.IsSecret(nil, "auras"), ns.IsSecret(5), ns.IsSecret(5, "gibtsnicht") }
		local s1, s2 = ns.Safe(5, 0, "auras")
		ns.simSecret = false
		local s3, s4 = ns.Safe(5, 0, "auras")
		local bait = ns.IsSecret(SECRET) and ns.IsSecret(SECRET, "auras")
		ns.testBait = nil
		local ok = r[1] == true and r[2] == false and r[3] == false and r[4] == false and s1 == 0 and s2 == true
			and s3 == 5 and s4 == false and bait
		return ok, string.format("%s %s %s %s | %s %s | %s %s | Köder %s", S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(s1), S(s2), S(s3), S(s4), S(bait)),
			"true false false false | 0 true | 5 false | Köder true"
	end)
	C("T13", "B", "ns:Compat / ResetCompat", function()
		ns:Compat("guid", "ok"); ns:Compat("guid", "off"); ns:Compat("guid", "ok")
		local c = ns.compat.guid
		local ok = c and c.mode == "ok" and c.worst == "off"
		ns:ResetCompat()
		return ok and next(ns.compat) == nil, c and (c.mode .. "/" .. c.worst), "ok/off, danach leer"
	end)
	C("T14", "B", "ns.SpellName / ns.SpellIcon", function()
		return ns.SpellName(355) ~= nil and ns.SpellIcon(355) ~= nil, "355", "Name und Symbol"
	end)
	C("T15", "B", "ReadCooldown / ns.SpellCD (über ns.API)", function()
		local now = GetTime()
		local saveMode = ns.tauntMode
		ns.tauntMode = "hostile"
		local r = {}
		WithAPI({ GetSpellCooldown = Ret(now - 2, 10) }, function()
			r[1] = ns.SpellCD("TSTest"); r[2] = ns.compat.cooldowns and ns.compat.cooldowns.mode
		end)
		WithAPI({ GetSpellCooldown = Ret(now, 1.5) }, function() r[3] = ns.SpellCD("TSTest") end)
		ns.cdTrack.TSTest = now + 4
		WithAPI({ GetSpellCooldown = Ret(SECRET, SECRET) }, function()
			r[4] = ns.SpellCD("TSTest"); r[5] = ns.compat.cooldowns and ns.compat.cooldowns.mode
		end)
		WithAPI({ GetSpellCooldown = NIL, C_Spell = { GetSpellCooldown = function() return { startTime = now - 2, duration = 10 } end } },
			function() r[6] = ns.SpellCD("TSTest") end)
		ns.cdTrack.TSTest = nil
		ns.tauntMode = saveMode
		local ok = Near(r[1], 8, 0.1) and r[2] == "ok" and r[3] == 0 and Near(r[4], 4, 0.1) and r[5] == "fallback" and Near(r[6], 8, 0.1)
		return ok, string.format("%.1f %s / %s / %.1f %s / %.1f", Num(r[1]), S(r[2]), S(r[3]), Num(r[4]), S(r[5]), Num(r[6])),
			"8 ok / 0 / 4 fallback / 8 (C_Spell)"
	end)
	C("T16", "B", "ns:BaseCooldown (gelernter Wert hat Vorrang)", function()
		ns.db.cdLearned = ns.db.cdLearned or {}
		ns.db.cdLearned.TestSpott = 7
		local v = ns:BaseCooldown("TestSpott")
		ns.db.cdLearned.TestSpott = nil
		local none = ns:BaseCooldown("GibtsNicht")
		return v == 7 and none == nil, S(v) .. "/" .. S(none), "7/nil"
	end)
	C("T17", "B", "ns.SpellInRange (über ns.API)", function()
		local out = {}
		for _, v in ipairs({ true, false, 1, 0, NIL, SECRET }) do
			local val = v
			if v == NIL then val = nil end
			out[#out + 1] = S(WithAPI({ IsSpellInRange = Ret(val) }, function() return ns.SpellInRange("TSTest", "target") end))
		end
		local mode = ns.compat.range and ns.compat.range.mode
		local got = table.concat(out, "/")
		return got == "true/false/true/false/nil/nil" and mode == "off", got .. " " .. S(mode), "true/false/true/false/nil/nil off"
	end)
	C("T18", "B", "ns.Aura / ns:FindAura (alter und moderner Weg)", function()
		local list
		local function old(unit, i) local a = list[i]; if a then return a[1], nil, 1, nil, nil, nil, nil, nil, nil, a[2] end end
		local function new(unit, i) local a = list[i]; if a then return { name = a[1], applications = 1, spellId = a[2] } end end
		local res = {}
		local function run(map)
			map.UnitAffectingCombat = Ret(false)
			WithAPI(map, function()
				list = { { "TSAura", 71 } }
				local a1, b1 = ns:FindAura("player", "HELPFUL", { [71] = true })
				local a2, b2 = ns:FindAura("player", "HELPFUL", {}, { TSAura = true })
				list = {}
				local a3, b3 = ns:FindAura("player", "HELPFUL", { [71] = true })
				list = { { SECRET, 71 } }
				local a4, b4 = ns:FindAura("player", "HELPFUL", { [71] = true })
				res[#res + 1] = table.concat({ S(a1), S(b1), S(a2), S(b2), S(a3), S(b3), S(a4), S(b4) }, ",")
			end)
		end
		run({ UnitBuff = old, UnitDebuff = old })
		run({ UnitBuff = NIL, UnitDebuff = NIL, C_UnitAuras = { GetAuraDataByIndex = new } })
		local err = WithAPI({ UnitBuff = function() error("TS-Test") end, UnitDebuff = old }, function()
			local a, b = ns:FindAura("player", "HELPFUL", { [71] = true }); return S(a) .. "," .. S(b)
		end)
		local want = "true,true,true,true,false,true,false,false"
		return res[1] == want and res[2] == want and err == "false,false", res[1] .. " | " .. res[2] .. " | Fehler " .. err,
			want .. " (beide Wege), Fehler false,false"
	end)
	C("T19", "B", "ns:MobKey (über ns.API)", function()
		local k1, ok1 = WithAPI({ UnitGUID = Ret("Creature-0-1-2-3-4-5") }, function() return ns:MobKey("tsfake1") end)
		local k2, ok2 = WithAPI({ UnitGUID = Ret(SECRET) }, function() return ns:MobKey("tsfake1") end)
		local mode = ns.compat.guid and ns.compat.guid.mode
		return k1 == "Creature-0-1-2-3-4-5" and ok1 == true and k2 == "plate:tsfake1" and ok2 == false and mode == "fallback",
			S(ok1) .. " / " .. S(k2) .. " " .. S(ok2) .. " " .. S(mode), "GUID true / plate:tsfake1 false fallback"
	end)
	C("T20", "B", "ns:SameUnit (echte Einheiten)", function()
		local a, b = ns:SameUnit("player", "player"), ns:SameUnit("player", "tsfake1")
		return a == true and b == false, S(a) .. "/" .. S(b), "true/false"
	end)
	C("T21", "B", "ns:SpellbookHas mit leerem Namen", function()
		local a, b = ns:SpellbookHas(""), ns:SpellbookHas(nil)
		return not a and not b, S(a) .. "/" .. S(b), "false/false"
	end)
	C("T22", "B", "ns:FullName (eigener Charakter und Realm)", function()
		local n = ns:FullName("player")
		local own = type(n) == "string" and n ~= "" and not n:find("-", 1, true)
		-- WoW Forever liefert auch für den eigenen Charakter einen Realm: der gehört nicht in den Namen
		local realm = ns:PlayerRealm() or "TSHeimat"
		local saveRealm = ns.playerRealm
		ns.playerRealm = realm
		local names = { player = { "TSIch", realm }, party1 = { "Torben", realm }, party2 = { "Lina", "TSFremd" }, party3 = { "Grimbar", "" } }
		local r = WithAPI({ UnitName = function(u) local e = names[u]; if e then return e[1], e[2] end end }, function()
			return S(ns:FullName("player")) .. " " .. S(ns:FullName("party1")) .. " " .. S(ns:FullName("party2")) .. " " .. S(ns:FullName("party3"))
		end)
		ns.playerRealm = saveRealm
		local want = "TSIch Torben Lina-TSFremd Grimbar"
		return own and r == want, (own and "<Name>" or S(n)) .. " | " .. r, "<Name> ohne Realm | " .. want
	end)
	C("T23", "B", "ns:FormName / ns:SpecName", function()
		local a, b = ns:FormName(), ns:SpecName()
		return type(a) == "string" and type(b) == "string", "Text", "Text"
	end)
	C("T24", "B", "ns:UpdateSpells mit eigenem Spott", function()
		ns.db.tauntOverride = "TestSpott"
		ns:UpdateSpells()
		local ok = ns.tauntSpell == "TestSpott" and ns.tauntMode == "hostile"
		local got = S(ns.tauntSpell) .. "/" .. S(ns.tauntMode)
		ns.db.tauntOverride = ""
		ns:UpdateSpells()
		return ok, got, "TestSpott/hostile"
	end)
	C("T26", "B", "IsTankStance liefert einen Wahrheitswert", function()
		local v = ns:IsTankStance()
		return v == true or v == false, S(v), "true/false"
	end)
	C("T27", "B", "TankUnit / PetTankActive", function()
		local u = ns:TankUnit()
		local p = ns:PetTankActive()
		if ns.tauntMode ~= "pet" and p then return false, "PetTankActive true", "nur bei Pet-Spott" end
		return u == "player" or u == "pet", S(u), "player/pet"
	end)
	C("T28", "B", "IsActive / IsMemberMode", function()
		ns.db.enabled = false
		local a = ns:IsActive()
		local m = ns:IsMemberMode()
		ns.db.enabled = true
		ns.testMode = true
		local b = ns:IsActive()
		local mb = ns:IsMemberMode()
		ns.testMode = false
		return a == false and m == false and b == true and mb == false, S(a) .. S(m) .. S(b) .. S(mb), "false false true false"
	end)
	C("T31", "B", "MyRole / GetRole", function()
		ns.db.myRole = "HEALER"
		local r1 = ns:IsTankStance() and "TANK" or ns:MyRole()
		ns.db.myRole = "DAMAGER"
		local r2 = ns:IsTankStance() and "TANK" or ns:MyRole()
		ns:ClearRoleCache()
		local g = ns:GetRole("player")
		local okG = g == "TANK" or g == "HEALER" or g == "DAMAGER" or g == "PET"
		return (r1 == "HEALER" or r1 == "TANK") and (r2 == "DAMAGER" or r2 == "TANK") and okG, S(r1) .. "/" .. S(r2) .. "/" .. S(g), "HEALER/DAMAGER/Rolle"
	end)
	C("T32", "B", "Profile: geteiltes Profil (ReloadUI nur mitgeschrieben)", function()
		local before = ns.actLog.n.reload or 0
		ns:UseSharedProfile(true)
		local a = ThreatSentinelDB.chars[ns.charKey] == "Global" and ThreatSentinelDB.profiles.Global ~= nil and ns:IsSharedProfile()
		ns:UseSharedProfile(false)
		local b = ThreatSentinelDB.chars[ns.charKey] == ns.charKey and not ns:IsSharedProfile()
		local n = (ns.actLog.n.reload or 0) - before
		return a and b and n == 2, "ReloadUI " .. n .. "x mitgeschrieben", "2x, Profile richtig"
	end)
	C("T33", "B", "Voreinstellungen", function()
		for name, p in pairs(ns.PRESETS) do
			ns:ApplyPreset(name)
			for k, v in pairs(p) do if ns.db[k] ~= v then return false, name .. "." .. k, S(v) end end
		end
		local before = Copy(ns.db)
		ns:ApplyPreset("gibtsnicht")
		local d = Diff(ns.db, before, "db")
		return d == nil, d or "ok", "unverändert"
	end)
	C("T34", "B", "Positionen zurücksetzen", function()
		ns:ResetPositions()
		for _, k in ipairs({ "hudPoint", "ddPoint", "meterPoint", "dmgPoint" }) do
			if ns.db[k] == ns.defaults[k] then return false, k .. " dieselbe Tabelle", "Kopie" end
			if Diff(ns.db[k], ns.defaults[k], k) then return false, k, "wie Standard" end
		end
		return true
	end)
	C("T35", "B", "ns:IsBossFight ohne Fehler", function()
		local v = ns:IsBossFight()
		return v == true or v == false, S(v), "true/false"
	end)
	C("T36", "B", "Slash-Unterbefehle", function()
		local hits = {}
		local function mark(n) return function() hits[#hits + 1] = n end end
		Swap(ns.Log, "Command", mark("log")); Swap(ns.Test, "ToggleWindow", mark("test")); Swap(ns.Guide, "Start", mark("guide"))
		Swap(ns.Donate, "Show", mark("donate")); Swap(ns.ThreatAccess, "Report", mark("threat")); Swap(ns.Mover, "Toggle", mark("move"))
		Swap(ns.Options, "Toggle", mark("options")); Swap(ns.Routine, "Command", mark("routine"))
		local cases = { { "log status", "log" }, { "test", "test" }, { "guide", "guide" }, { "assistent", "guide" }, { "spenden", "donate" },
			{ "donate", "donate" }, { "support", "donate" }, { "bedrohung", "threat" }, { "threat", "threat" }, { "BEDROHUNG", "threat" },
			{ "verschieben", "move" }, { "move", "move" }, { "", "options" }, { "unbekannt", "options" }, { "testroutine x", "routine" } }
		local bad
		for _, c in ipairs(cases) do
			wipe(hits)
			SlashCmdList.THREATSENTINEL(c[1])
			if #hits ~= 1 or hits[1] ~= c[2] then bad = "'" .. c[1] .. "' -> " .. table.concat(hits, ",") break end
		end
		UnswapAll()
		return bad == nil, bad or "ok", "genau das richtige Ziel 1x"
	end)
	C("T37", "B", "ns:ThreatMode – Tabelle (ausserhalb des Kampfs)", function()
		local save = { ns.simAccess, ns.threatAccess, ns.db.threatMode, ns.isModern }
		local bad
		local function want(sim, acc, mode, modern, exp)
			ns.simAccess, ns.threatAccess, ns.db.threatMode, ns.isModern = sim, acc, mode, modern
			local m = ns:ThreatMode()
			if m ~= exp then bad = string.format("%s/%s/%s/%s -> %s", S(sim), S(acc), S(mode), S(modern), m) end
		end
		want("none", "open", "AUTO", true, "OFF"); want("secret", "open", "AUTO", true, "DISPLAY"); want("open", "open", "AUTO", true, "FULL")
		want(nil, "secret", "AUTO", true, "DISPLAY"); want(nil, "none", "AUTO", true, "OFF")
		want(nil, "open", "DISPLAY", true, "DISPLAY"); want(nil, "open", "DISPLAY", false, "FULL")
		want("open", "secret", "AUTO", true, "DISPLAY")   -- T173: Simulation "lesbar" übersteuert keine echte Sperre
		ns.simAccess, ns.threatAccess, ns.db.threatMode, ns.isModern = save[1], save[2], save[3], save[4]
		return bad == nil, bad or "ok", "Tabelle wie angegeben"
	end)
	C("T38", "B", "TA:ModeText", function()
		for _, m in ipairs({ "FULL", "DISPLAY", "OFF" }) do
			local t = TA:ModeText(m)
			if not t or t:find("^TA_MODE_") then return false, m .. " -> " .. S(t), "Text" end
		end
		return true
	end)
	C("T39", "B", "TA:Read ohne Ziel (echte API)", function()
		local f, s, miss = TA:Read("tsfake1")
		if not UnitDetailedThreatSituation and not UnitThreatSituation then return miss == true, S(miss), "missing" end
		return f == false and s == false and miss == false, S(f) .. S(s) .. S(miss), "false false false"
	end)
	C("T40", "B", "TA:Probe ohne Kampf ohne Wirkung", function()
		local before = { TA.checked, TA.attempts, ns.threatAccess }
		TA.checked = false
		TA:Probe({ "tsfake1" })
		local after = { TA.attempts, ns.threatAccess }
		return after[1] == before[2] and after[2] == before[3], S(after[1]) .. "/" .. S(after[2]), "unverändert"
	end)
	C("T42", "B", "TA:Set / Store", function()
		local shown = 0
		Swap(A, "Center", function(_, text) if text == L.TA_NOTE_DISPLAY then shown = shown + 1 end end)
		TA.announced = false
		ns.db.enabled = true
		TA:Set("secret")
		TA:Set("secret")
		UnswapAll()
		local st = ThreatSentinelDB.threatAccess
		local ok = ns.threatAccess == "secret" and TA.checked == true and type(st) == "table" and st.state == "secret"
			and type(st.date) == "string" and st.date:match("^%d%d%d%d%-%d%d%-%d%d %d%d:%d%d$") and type(st.build) == "string"
			and st.build:find("%(") and shown == 1
		return ok and true or false, string.format("%s, Hinweis %dx, %s", S(ns.threatAccess), shown, S(st and st.date)), "secret, Hinweis 1x, JJJJ-MM-TT HH:MM"
	end)
	C("T43", "B", "Neuer Kampf setzt die Prüfung zurück", function()
		TA.checked, TA.attempts, TA.announced = true, 5, true
		ns:Fire("PLAYER_REGEN_DISABLED")
		local got = S(TA.checked) .. "/" .. S(TA.attempts) .. "/" .. S(TA.announced)
		if ns.isModern then return TA.checked == false and TA.attempts == 0 and TA.announced == false, got, "false/0/false" end
		return TA.checked == true and TA.attempts == 5, got, "unverändert (alte API)"
	end)
	C("T44", "B", "ApplyBlizzard nur mitgeschrieben", function()
		local before = ns.actLog.n.cvar or 0
		ns.db.enabled, ns.db.blizzThreat = true, false
		TA.wantBlizzard = true
		TA:ApplyBlizzard()
		local n1 = (ns.actLog.n.cvar or 0) - before
		return n1 == 0 and TA.wantBlizzard == true, "blizzThreat aus: " .. n1 .. " CVar", "0, Wunsch bleibt"
	end)
	C("T45", "B", "Bedrohung prüfen – ausserhalb des Kampfs", function()
		local lines = Capture(function() TA:Report() end)
		local ok = Has(lines, FormatStem(L.TA_R_MODE)) and Has(lines, L.TA_R_NOCOMBAT) and Has(lines, FormatStem(L.TA_R_ERRORS))
			and (ns.isModern or Has(lines, L.TA_R_OLDAPI))
			and (Has(lines, FormatStem(L.TA_R_LAST)) or Has(lines, L.TA_R_NEVER))
		return ok, #lines .. " Zeilen", "Modus, Status, ausserhalb Kampf, zuletzt, Fehler"
	end)
	CL("T46", "B", "Bedrohung prüfen – im Kampf", "Mob angreifen, im Kampf /ts bedrohung: Status und Prozent (oder 'geschützt') erscheinen, kein Lua-Fehler")
	C("T47", "B", "TA:Login übernimmt den gespeicherten Zustand", function()
		local bad
		for _, c in ipairs({ { "open", "open" }, { "secret", "secret" }, { "none", "unknown" } }) do
			ThreatSentinelDB.threatAccess = { state = c[1], date = "2026-11-03 10:00", build = "x (1)" }
			ns.threatAccess = ns.isModern and "unknown" or "open"
			TA:Login()
			local exp = ns.isModern and c[2] or "open"
			if ns.threatAccess ~= exp then bad = c[1] .. " -> " .. S(ns.threatAccess) end
		end
		return bad == nil, bad or "ok", "open/secret übernommen, none nicht (alt immer open)"
	end)
	C("T51", "B", "Reihenfolge loser Mobs (SortLoose)", function()
		local list = {
			{ id = 1, mark = 0, victimRole = "DAMAGER", looseSince = 1 },
			{ id = 2, mark = 7, victimRole = "DAMAGER", looseSince = 5 },
			{ id = 3, mark = 8, victimRole = "DAMAGER", looseSince = 9 },
			{ id = 4, mark = 0, victimRole = "HEALER", looseSince = 8 },
			{ id = 5, mark = 0, victimRole = "DAMAGER", looseSince = 0 },
		}
		table.sort(list, ns.Threat.SortLoose)
		local ids = {}
		for i, e in ipairs(list) do ids[i] = e.id end
		local got = table.concat(ids, ",")
		return got == "3,2,4,5,1", got, "3,2,4,5,1"
	end)
	C("T60", "B", "Initial", function()
		local I = ns.Plates._Initial
		ns.testBait = SECRET
		local r = { I("Grimbar"), I("ärger"), I(""), I(nil), I(SECRET) }
		ns.testBait = nil
		-- string.upper kennt im Spiel keine Umlaute: "ä" bleibt "ä" (erlaubt); wichtig ist ein ganzes UTF-8-Zeichen
		local uml = r[2] == "Ä" or r[2] == "ä"
		return r[1] == "G" and uml and r[3] == "" and r[4] == "" and r[5] == "", r[1] .. "|" .. r[2] .. "|" .. r[3] .. "|" .. r[4] .. "|" .. r[5], "G|Ä|||"
	end)
	C("T62", "B", "Töne: Liste und Play (nur mitgeschrieben)", function()
		local bad
		for _, s in ipairs(ns.SOUNDS) do
			if s.key and ns:SoundByKey(s.key) ~= s then bad = "SoundByKey " .. s.key break end
			local lbl = ns:SoundLabel(s.key)
			if not lbl or lbl == s.key and s.key ~= "none" then bad = "SoundLabel " .. s.key break end
		end
		if bad then return false, bad, "jeder Ton auffindbar" end
		local r1 = A:Play("none", "trTest1")
		local before = ns.actLog.n.sound or 0
		ns.db.sound = true
		A:Play("fx_frosch", "trTest2" .. GetTime(), true)
		local n = (ns.actLog.n.sound or 0) - before
		return r1 == nil and n >= 1, "none -> " .. S(r1) .. ", Ton mitgeschrieben " .. n .. "x", "nil, mitgeschrieben"
	end)
	C("T63", "B", "Meldung in der Mitte: Vorrang", function()
		if not A.center then return false, "kein Rahmen", "Rahmen" end
		A:Center("tr-test", { 1, 1, 1 }, 2, "test")
		A:Center("tr-aoe", { 1, 1, 1 }, 2, "aoe")
		local t = A.center.text:GetText()
		A:ClearCenter("aoe")
		local still = A.center:IsShown()
		A:ClearCenter("test")
		return t == "tr-test" and still, S(t) .. "/" .. S(still), "tr-test/true"
	end)
	C("T64", "B", "Chat-Kanäle gehen nie hinaus", function()
		local before = ns.actLog.n.chat or 0
		local said = 0
		local lines
		for _, ch in ipairs({ "TANKS", "BOSS", "GROUP", "SELF", "OFF" }) do
			ns.db.chatChannel = ch
			ns.db.announceResist = true
			lines = Capture(function() A:OnResist("Grimbar", nil, true); A:AnnounceCC(nil, nil, true) end)
			for _, l in ipairs(lines) do if l:find(L.TEST_CHAT, 1, true) then said = said + 1 end end
		end
		local n = (ns.actLog.n.chat or 0) - before
		return n == 0 and said > 0, "Chat " .. n .. "x, Test-Zeilen " .. said, "0x, nur an dich"
	end)
	C("T73", "B", "Sync:Handle", function()
		Sy:Handle("Grimbar", "H:TANK:2.4.1")
		local r = ns.syncRoles.Grimbar
		local a = r and r.role == "TANK" and r.ver == "2.4.1"
		Sy:Handle("Grimbar", "T:Creature-1:10")
		local c = Sy.claims["Creature-1"]
		local b = c and c.name == "Grimbar" and Sy.cd.Grimbar and Near(Sy.cd.Grimbar - GetTime(), 10, 0.5)
		Sy.claims["-"] = nil
		Sy:Handle("Grimbar", "T:-:5")
		local d = Sy.claims["-"] == nil
		Sy:Handle("Grimbar", "kaputt"); Sy:Handle("Grimbar", nil)
		return (a and b and d) and true or false, S(a) .. "/" .. S(b) .. "/" .. S(d), "true/true/true"
	end)
	C("T74", "B", "Sync:Send (nur mitgeschrieben)", function()
		ns.db.sync = false
		local r0 = Sy:Send("H:TEST")
		ns.db.sync = true
		local before = ns.actLog.n.addonmsg or 0
		local r1 = Sy:Send("H:TEST")
		local n = (ns.actLog.n.addonmsg or 0) - before
		if IsInGroup() then
			return r0 == nil and r1 == true and n == 1, S(r0) .. "/" .. S(r1) .. "/" .. n, "nil/true/1 (mitgeschrieben)"
		end
		return r0 == nil and r1 == nil and n == 0, S(r0) .. "/" .. S(r1) .. "/" .. n, "nil/nil/0 (keine Gruppe)"
	end)
	C("T75", "B", "Tank-Liste", function()
		ns.syncRoles.Grimbar = { role = "TANK", t = GetTime() }
		ns.fakeNames.Grimbar = true   -- wie die Testzentrale: erfundener Tank gilt als in der Gruppe
		local a = Sy:IsTank("Grimbar")
		local list = Sy:Tanks()
		local has = false
		for _, n in ipairs(list or {}) do if n == "Grimbar" then has = true end end
		ns.db.sync = false
		local n0 = Sy:NumTanks()
		ns.db.sync = true
		return a and has and n0 == 0, S(a) .. "/" .. S(has) .. "/" .. S(n0), "true/true/0"
	end)
	C("T76", "B", "Addon-Nachrichten: falscher Prefix und geschützter Absender", function()
		ns.syncRoles.Grimbar = nil
		ns.testBait = SECRET
		ns:Fire("CHAT_MSG_ADDON", "FremdesAddon", "H:TANK:1", "PARTY", "Grimbar")
		ns:Fire("CHAT_MSG_ADDON", Sy.PREFIX, SECRET, "PARTY", "Grimbar")
		ns:Fire("CHAT_MSG_ADDON", Sy.PREFIX, "H:TANK:1", "PARTY", SECRET)
		ns.testBait = nil
		local none = ns.syncRoles.Grimbar == nil
		ns:Fire("CHAT_MSG_ADDON", Sy.PREFIX, "H:TANK:1", "PARTY", "Grimbar")
		local got = ns.syncRoles.Grimbar ~= nil
		return none and got, S(none) .. "/" .. S(got), "ignoriert/übernommen"
	end)
	C("T81", "B", "Rolle aus Talentpunkten", function()
		local F = ns.Specs._RoleFromPoints
		local r = { F("WARRIOR", { 0, 5, 31 }, 36), F("PALADIN", { 31, 0, 0 }, 31), F("DRUID", { 0, 31, 0 }, 31), F("PRIEST", { 0, 0, 31 }, 31), F("WARRIOR", { 1, 2, 3 }, 6) }
		return r[1] == "TANK" and r[2] == "HEALER" and r[3] == "FERAL" and r[4] == "DAMAGER" and r[5] == nil,
			table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]) }, "/"), "TANK/HEALER/FERAL/DAMAGER/nil"
	end)
	C("T86", "B", "Schadensmeter: Kurzzahlen und Weiche", function()
		local Sh = ns.DmgMeter._Short
		local r = { Sh(999), Sh(1234), Sh(12345), Sh(2500000) }
		local ok = r[1] == "999" and r[2] == "1.2k" and r[3] == "12k" and r[4] == "2.5M"
		return ok and ns.DmgMeter.allowed == (not ns.isModern), table.concat(r, "/") .. " allowed=" .. S(ns.DmgMeter.allowed), "999/1.2k/12k/2.5M"
	end)
	C("T87", "B", "Anzeigen verschieben: Grösse begrenzt", function()
		ns.Mover:SetScale("hud", 9)
		local a = ns.db.hudScale
		ns.Mover:SetScale("hud", 0.1)
		local b = ns.db.hudScale
		return Near(a, 2.5) and Near(b, 0.5), S(a) .. "/" .. S(b), "2.5/0.5"
	end)
	C("T89", "B", "Einstellungsfenster und alle Seiten", function()
		local O = ns.Options
		if not O.frame then O:Build() end
		local wasShown = O.frame:IsShown()
		O.frame:Show()
		for i = 1, 8 do O:Select(i) end
		O:RefreshAll()
		if not wasShown then O.frame:Hide() end
		return true
	end)
	C("T93", "B", "Testzentrale: Texte und Zugriff-Simulation", function()
		local TM = ns.Test
		if not TM.frame then TM:Build() end
		local d, c, r = TM:DiagText(), TM:CompatText(), TM:ReportText()
		if type(d) ~= "string" or type(c) ~= "string" or type(r) ~= "string" then return false, "Text fehlt", "Texte" end
		local bad
		Capture(function()
			for _, st in ipairs({ "open", "secret", "none" }) do
				TM:SetAccessSim(st)
				local exp = ({ open = "FULL", secret = "DISPLAY", none = "OFF" })[st]
				if ns.threatAccess ~= "secret" and ns:ThreatMode() ~= exp then bad = st .. " -> " .. ns:ThreatMode() end
			end
			TM:SetAccessSim(nil)
		end)
		if A.ClearCenter then A:ClearCenter("test") end
		return bad == nil, bad or "ok", "open/secret/none -> FULL/DISPLAY/OFF"
	end)
	C("T94", "B", "Testprotokoll: Werte", function()
		local V = ns.Log.Val
		ns.testBait = SECRET
		local r = { V(SECRET), V(true), V(1.234), V(nil), V(5) }
		ns.testBait = nil
		return r[1] == "SECRET" and r[2] == "1" and r[3] == "1.23" and r[4] == "-" and r[5] == "5", table.concat(r, "/"), "SECRET/1/1.23/-/5"
	end)
	C("T95", "B", "Spenden-Knopf: Sprache", function()
		local D = ns.Donate
		local save = D.locale
		D.locale = "deDE"; local de = D.Text("title")
		D.locale = "enUS"; local en = D.Text("title")
		D.locale = save
		return type(de) == "string" and type(en) == "string" and de ~= en, "de/en verschieden", "verschieden"
	end)
	C("T96", "B", "/gsgame und /gsdev aufrufbar", function()
		local okA = pcall(SlashCmdList.GOLDSENTINELGAME, "")
		return okA, "ok", "kein Fehler"
	end)
	C("T61", "B", "P:Inspect (Vorschau-Plakette über ns.API)", function()
		local TM = ns.Test
		TM:CreatePreview()
		local uf = TM.preview.plates[1]
		local plates = { tsfake1 = { UnitFrame = uf }, tsfake2 = { UnitFrame = uf, IsForbidden = function() return true end } }
		local a, b, c = WithAPI({ C_NamePlate = { GetNamePlateForUnit = function(u) return plates[u] end } }, function()
			return ns.Plates:Inspect("tsfake1"), ns.Plates:Inspect("tsfake2"), ns.Plates:Inspect("tsfake3")
		end)
		local ok = type(a) == "table" and a.scale ~= nil and a.strata ~= nil and b == nil and c == nil
		return ok, (type(a) == "table" and ("Tabelle, Grösse " .. S(a.scale) .. ", Ebene " .. S(a.strata)) or S(a)) .. " / " .. S(b) .. " / " .. S(c),
			"Tabelle / nil (verboten) / nil (keine)"
	end)
	C("T84", "B", "Aggrometer und DD-Ansicht: Sichtbarkeit", function()
		local M, D, db = ns.Meter, ns.DD, ns.db
		if not (M.f and D.f) then return false, "Rahmen fehlen", "Aggrometer und DD-Ansicht" end
		local wasM, wasD = M.f:IsShown(), D.f:IsShown()
		local save = { ns.moveMode, ns.testMode, ns.simAccess, db.enabled, db.meter, db.meterOnlyTank, db.ddView, db.ddSound, ns.liveTest }
		local res, plays = {}, 0
		Swap(ns.Alerts, "Play", function() plays = plays + 1 end)
		Swap(ns, "Unlocked", function() return false end)
		local stance = false
		Swap(ns, "IsTankStance", function() return stance end)
		ns.testMode, ns.liveTest, ns.simAccess = false, false, "open"
		db.enabled, db.meter, db.meterOnlyTank, db.ddView, db.ddSound = true, true, false, true, true
		WithAPI({ UnitExists = Ret(false), UnitAffectingCombat = Ret(false), IsInGroup = Ret(false) }, function()
			ns.moveMode = true; M:Tick(); res[#res + 1] = M.f:IsShown() and "zeigt" or "weg"; ns.moveMode = false
			M:Tick(); res[#res + 1] = M.f:IsShown() and "zeigt" or "weg"                         -- kein Ziel
			db.meterOnlyTank = true; M:Tick(); res[#res + 1] = M.f:IsShown() and "zeigt" or "weg"; db.meterOnlyTank = false
			ns.simAccess = "none"; M:Tick(); res[#res + 1] = M.f:IsShown() and "zeigt" or "weg"; ns.simAccess = "open"
			db.meter = false; M:Tick(); res[#res + 1] = M.f:IsShown() and "zeigt" or "weg"; db.meter = true
			stance = true; D:Tick(); res[#res + 1] = D.f:IsShown() and "zeigt" or "weg"; stance = false
			ns.simAccess = "none"; D:Tick(); res[#res + 1] = D.f:IsShown() and "zeigt" or "weg"; ns.simAccess = "open"
			D:Tick(); res[#res + 1] = D.f:IsShown() and "zeigt" or "weg"                         -- ohne Gruppe
			D.warned = false
			D:Show(db.ddWarn - 10); local p1 = plays
			D:Show(db.ddWarn + 5); local p2 = plays
			D.warned = false; ns.testMode = true; D:Show(db.ddWarn + 5); local p3 = plays; ns.testMode = false
			res[#res + 1] = (p1 - 0) .. "/" .. (p2 - p1) .. "/" .. (p3 - p2)
		end)
		UnswapAll()
		ns.moveMode, ns.testMode, ns.simAccess, db.enabled, db.meter, db.meterOnlyTank, db.ddView, db.ddSound, ns.liveTest =
			save[1], save[2], save[3], save[4], save[5], save[6], save[7], save[8], save[9]
		D.warned = false
		if wasM then M.f:Show() else M.f:Hide() end
		if wasD then D.f:Show() else D.f:Hide() end
		local got = table.concat(res, ",")
		return got == "zeigt,weg,weg,weg,weg,weg,weg,weg,0/1/0", got, "zeigt,weg×7, Ton 0/1/0"
	end)
	C("T90", "B", "Jede Option einmal an/aus", function()
		local db, before, bad, n = ns.db, ns.errorCount, nil, 0
		local keys = {}
		for k, v in pairs(ns.defaults) do if type(v) == "boolean" then keys[#keys + 1] = k end end
		table.sort(keys)
		local function ticks()
			ns:ApplySettings()
			ns.routineRunning = false     -- Pause nur für diesen einen Aufruf aufheben
			local ok, err = pcall(function()
				ns.Threat:Tick()
				for _, m in ipairs({ ns.Meter, ns.DD, ns.HUD, ns.DmgMeter }) do if m and m.Tick then m:Tick() end end
			end)
			ns.routineRunning = true
			if not ok then error(err, 0) end
			if ns.Options and ns.Options.frame and ns.Options.RefreshAll then ns.Options:RefreshAll() end
		end
		if ns.Options and not ns.Options.frame and ns.Options.Build then ns.Options:Build() end
		for _, k in ipairs(keys) do
			local orig = db[k]
			for _, v in ipairs({ true, false }) do
				db[k] = v
				local ok, err = pcall(ticks)
				if not ok and not bad then bad = k .. ": " .. Clean(err) end
				if db[k] ~= v and not bad then bad = k .. " nicht wie gesetzt" end
			end
			db[k] = orig
			n = n + 1
		end
		for _, pair in ipairs({ { "myRole", { "AUTO", "HEALER", "DAMAGER" } }, { "threatMode", { "AUTO", "DISPLAY" } } }) do
			local k, orig = pair[1], db[pair[1]]
			for _, v in ipairs(pair[2]) do
				db[k] = v
				local ok, err = pcall(ticks)
				if not ok and not bad then bad = k .. "=" .. v .. ": " .. Clean(err) end
			end
			db[k] = orig
		end
		pcall(ticks)
		return bad == nil and ns.errorCount == before, bad or (n .. " Schalter + Auswahl myRole/threatMode, Fehler +" .. (ns.errorCount - before)),
			"kein Lua-Fehler (Schieberegler: T89/T58)"
	end)
	------------------------------------------------------------
	-- Fälle mit der Test-Kulisse (Test-Einheiten und Vorschau-Plaketten über ns.API)
	------------------------------------------------------------
	C("T25", "B", "HasSealOfFury / TauntUsable", function()
		local save = { ns.sealId, ns.sealName, ns.sealUntil, ns.tauntSpell, ns.tauntMode }
		ns.sealId, ns.sealName, ns.tauntSpell, ns.tauntMode = 20375, "TSSiegel", "TSSpott", "seal"
		local list = {}
		local function buff(_, i) local a = list[i]; if a then return a[1], nil, 1, nil, nil, nil, nil, nil, nil, a[2] end end
		local r = {}
		local ok, err = pcall(WithAPI, { UnitBuff = buff, UnitDebuff = buff, UnitAffectingCombat = Ret(false) }, function()
			list = { { "TSSiegel", 20375 } }; r[1] = ns:HasSealOfFury(); r[2] = ns:TauntUsable()
			list = {}; r[3] = ns:HasSealOfFury()
			list = { { SECRET, SECRET } }
			ns.sealUntil = GetTime() + 10; r[4] = ns:HasSealOfFury(); r[5] = ns.compat.selfAuras and ns.compat.selfAuras.mode
			ns.sealUntil = GetTime() - 1; r[6] = ns:HasSealOfFury()
		end)
		ns.tauntSpell = nil; r[7] = ns:TauntUsable()
		ns.sealId, ns.sealName, ns.sealUntil, ns.tauntSpell, ns.tauntMode = save[1], save[2], save[3], save[4], save[5]
		if not ok then error(err, 0) end
		local got = table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]), S(r[6]), S(r[7]) }, " ")
		local want = "true true false true fallback false false"
		return got == want, got, want
	end)
	C("T29", "B", "LooksLikeTank / HasBearForm / CouldTank", function()
		local sc = Scene.New(1)
		local auras = {}
		return Scene.Run(sc, function()
			local function buff(u, i)
				local l = auras[u] or {}
				local a = l[i]
				if a then return a[1], nil, 1, nil, nil, nil, nil, nil, nil, a[2] end
			end
			return WithAPI({ UnitBuff = buff, UnitDebuff = buff, UnitAffectingCombat = Ret(false),
				UnitGroupRolesAssigned = Ret("NONE") }, function()
				local r = {}
				ns.memberNow = false; r[1] = ns:LooksLikeTank("party3")
				ns.memberNow = true
				auras.party1 = { { "TSBär", 5487 } }
				r[2] = ns:LooksLikeTank("party1")
				ns.aggroLeader = "Grimbar"; r[3] = ns:LooksLikeTank("party3")
				r[4] = ns:HasBearForm("party1")
				r[5] = ns:CouldTank("party1")
				sc.units.party2.name = SECRET
				r[6] = ns:LooksLikeTank("party2"); r[7] = ns:HasBearForm("party2")
				local got = table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]), S(r[6]), S(r[7]) }, " ")
				local want = "false true true true false false false"
				return got == want, got, want .. " (aus, Aura, Anführer, Bär, Magier, geschützt)"
			end)
		end)
	end)
	C("T30", "B", "UpdateGroup (Gruppe mit Pet, Schlachtzug)", function()
		local sc = Scene.New(0)
		sc.group = { "party1", "party2" }
		sc.units.party3 = nil
		sc.units.partypet1 = { name = "Wolf" }
		local a = Scene.Run(sc, function()
			return table.concat(ns.groupUnits, ",") .. " | " .. S(ns.nameToUnit.Torben) .. " " .. S(ns.groupNames.Lina) .. " " .. S(ns.groupNames.Wolf)
		end)
		local rc = Scene.New(0)
		rc.group, rc.raid = {}, 5
		for i = 1, 5 do rc.units["raid" .. i] = { name = "Raid" .. i, player = true, class = "MAGE" } end
		rc.units.raid3.name = SECRET
		local b = Scene.Run(rc, function()
			local n = 0
			for k in pairs(ns.groupNames) do n = n + 1 end
			return #ns.groupUnits .. " Einheiten, " .. n .. " Namen, raid4=" .. S(ns.nameToUnit.Raid4)
		end)
		local wa = "player,party1,partypet1,party2 | party1 true nil"
		local wb = "5 Einheiten, 4 Namen, raid4=raid4"
		return a == wa and b == wb, a .. " / " .. b, wa .. " / " .. wb
	end)
	C("T41", "B", "TA:Candidates", function()
		local sc = Scene.New(3)
		sc.alias.target = "tsfake2"
		sc.units.tsfake3.combat = false
		return Scene.Run(sc, function()
			local list = ns.ThreatAccess:Candidates(ns.mobs)
			local first = list[1]
			local has3 = false
			for _, u in ipairs(list) do if u == "tsfake3" then has3 = true end end
			sc.units.tsfake1.hostile = SECRET
			local list2 = ns.ThreatAccess:Candidates(ns.mobs)
			local has1 = false
			for _, u in ipairs(list2) do if u == "tsfake1" then has1 = true end end
			local ok = first == "target" and #list == 3 and not has3 and not has1
			return ok, string.format("erstes %s, %d Einträge, ohne Kampf drin %s, geschützt drin %s", S(first), #list, S(has3), S(has1)),
				"erstes target, 3 Einträge, false, false"
		end)
	end)
	C("T48", "B", "Zustände eines Mobs (Evaluate)", function()
		local sc = Scene.New(7)
		sc.units.pet = { name = "Wolf" }
		Scene.Hold(sc, "tsfake1", "player", { party1 = 50 })
		Scene.Hold(sc, "tsfake2", "player", { party1 = ns.db.warnThreshold + 5 })
		Scene.Hold(sc, "tsfake3", "party3")
		Scene.Hold(sc, "tsfake4", "party1")
		Scene.Hold(sc, "tsfake5", "party2")
		Scene.Hold(sc, "tsfake6", "pet")
		sc.units.tsfake7.dead = true
		return Scene.Run(sc, function()
			local save = ns.db.petsSafe
			ns.db.petsSafe = true
			local loose = Counter(ns.Alerts, "OnLoose", false)
			local st = {}
			for i = 1, 7 do
				local m = ns.mobs["tsfake" .. i]
				ns.Threat:Evaluate("tsfake" .. i, m)
				st[i] = m.state
			end
			local m4, m5, m3 = ns.mobs.tsfake4, ns.mobs.tsfake5, ns.mobs.tsfake3
			ns.db.petsSafe = save
			local got = table.concat(st, ",") .. " | " .. S(m4.victim) .. "/" .. S(m4.victimRole) .. " " .. S(m5.victimRole)
				.. " | " .. S(m3.otherTank) .. " " .. S(ns.owners[m3.key] and ns.owners[m3.key].name) .. " | OnLoose " .. loose.n
			local want = "HELD,WARN,OTHERTANK,LOOSE,LOOSE,PETHELD,IDLE | Torben/DAMAGER HEALER | Grimbar Grimbar | OnLoose 2"
			return got == want, got, want
		end)
	end)
	C("T49", "B", "LOOSE: Meldung, Übernahme, Besitzer", function()
		local sc = Scene.New(2)
		Scene.Hold(sc, "tsfake1", "party1")
		Scene.Hold(sc, "tsfake2", "party1")
		return Scene.Run(sc, function()
			local T, db = ns.Threat, ns.db
			local saveSync = db.sync
			db.sync = true
			local loose = Counter(ns.Alerts, "OnLoose", false)
			local regain = Counter(ns.Alerts, "OnRegain", false)
			local warn = Counter(ns.Alerts, "OnWarn", false)
			local m1, m2 = ns.mobs.tsfake1, ns.mobs.tsfake2
			T:Evaluate("tsfake1", m1); T:Evaluate("tsfake1", m1)
			local a = loose.n
			-- übernommen (Spott eines anderen Tanks über die GUID)
			ns.Sync.claims[sc.units.tsfake2.guid] = { name = "Grimbar", t = GetTime() }
			T:Evaluate("tsfake2", m2)
			local claimed, b = m2.claimedBy, loose.n
			ns.Sync.claims[sc.units.tsfake2.guid] = nil
			-- anderer Tank war gerade Besitzer -> stumm
			ns.syncRoles.Grimbar = { role = "TANK", t = GetTime(), ver = ns.version }
			ns.owners[sc.units.tsfake2.guid] = { name = "Grimbar", t = GetTime() }
			m2.state, m2.alerted = nil, false
			T:Evaluate("tsfake2", m2)
			local muted, c = m2.muted, loose.n
			-- zurückgeholt, dann bald Aggro
			Scene.Hold(sc, "tsfake1", "player")
			T:Evaluate("tsfake1", m1)
			Scene.Hold(sc, "tsfake1", "player", { party1 = db.warnThreshold + 5 })
			T:Evaluate("tsfake1", m1)
			db.sync = saveSync
			local got = string.format("OnLoose %d, übernommen %s (%d), stumm %s (%d), OnRegain %d, OnWarn %d", a, S(claimed), b, S(muted), c, regain.n, warn.n)
			local want = "OnLoose 1, übernommen Grimbar (1), stumm true (1), OnRegain 1, OnWarn 1"
			return got == want, got, want
		end)
	end)
	C("T50", "B", "Hinweistext (BuildHint)", function()
		local save = { ns.tauntSpell, ns.tauntMode, ns.class, ns.db.sync, ns.sealId, ns.sealName, ns.sealUntil }
		ns.tauntSpell, ns.tauntMode, ns.class, ns.db.sync = "TSSpott", "hostile", "WARRIOR", false
		local T, r = ns.Threat, {}
		local now = GetTime()
		local ok, err = pcall(function()
			WithAPI({ GetSpellCooldown = Ret(0, 0), IsSpellInRange = Ret(1), C_Spell = NIL }, function()
				local m = { claimedBy = "Grimbar" }; T:BuildHint("tsfake1", m); r[1] = m.hint == string.format(L.CLAIMED, "Grimbar")
				m = { muted = true, ownerName = "Grimbar" }; T:BuildHint("tsfake1", m); r[2] = m.hint == string.format(L.OWNER, "Grimbar")
				m = {}; T:BuildHint("tsfake1", m); r[3] = m.hint == L.TAUNT_READY
				m = { myPull = ns.db.deficitThreshold + 1 }; T:BuildHint("tsfake1", m); r[4] = m.hint == L.DEFICIT_WARRIOR
			end)
			WithAPI({ GetSpellCooldown = Ret(0, 0), IsSpellInRange = Ret(0), C_Spell = NIL }, function()
				local m = {}; T:BuildHint("tsfake1", m); r[5] = m.hint == L.TOO_FAR and m.far == true
			end)
			WithAPI({ GetSpellCooldown = Ret(now - 2, 10), IsSpellInRange = Ret(1), C_Spell = NIL }, function()
				local m = {}; T:BuildHint("tsfake1", m); r[6] = m.hint == string.format(L.TAUNT_CD, 8)
			end)
			ns.tauntMode, ns.sealId, ns.sealName, ns.sealUntil = "seal", 20375, "TSSiegel", 0
			WithAPI({ GetSpellCooldown = Ret(0, 0), IsSpellInRange = Ret(1), C_Spell = NIL, UnitBuff = Ret(nil), UnitDebuff = Ret(nil),
				UnitAffectingCombat = Ret(false) }, function()
				local m = {}; T:BuildHint("tsfake1", m); r[7] = m.hint == L.HINT_NO_SEAL
			end)
		end)
		ns.tauntSpell, ns.tauntMode, ns.class, ns.db.sync, ns.sealId, ns.sealName, ns.sealUntil = save[1], save[2], save[3], save[4], save[5], save[6], save[7]
		if not ok then error(err, 0) end
		local got = table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]), S(r[6]), S(r[7]) }, " ")
		local want = "true true true true true true true"
		return got == want, got, want .. " (übernommen, Besitzer, bereit, Defizit, zu weit, Abklingzeit, ohne Siegel)"
	end)
	C("T52", "B", "T:Tick (aktiv, Modus, Wechsel, inaktiv)", function()
		local sc = Scene.New(5)
		return Scene.Run(sc, function()
			local T, db = ns.Threat, ns.db
			local saveEnabled = db.enabled
			local ev = Counter(T, "Evaluate")
			local up = Counter(ns.Plates, "Update", false)
			local rs = Counter(ns.Plates, "Restore", false)
			ns.simAccess = "open"
			T:Tick()
			local mc = Counter(T, "ModeChanged", false)
			local full = ev.n .. "/" .. up.n
			ev.n, up.n = 0, 0
			T.lastMode = "FULL"
			ns.simAccess = "secret"
			T:Tick(); T:Tick()
			local disp = ev.n .. "/" .. up.n .. " Wechsel " .. mc.n
			db.enabled = false
			T:Tick()
			local off = rs.n
			db.enabled = saveEnabled
			local got = "VOLL " .. full .. ", ANZEIGE " .. disp .. ", inaktiv Restore " .. off
			local want = "VOLL 5/5, ANZEIGE 0/0 Wechsel 1, inaktiv Restore 5"
			return got == want, got, want
		end)
	end)
	C("T53", "B", "T:EvalOne", function()
		local sc = Scene.New(1)
		return Scene.Run(sc, function()
			local T, TA = ns.Threat, ns.ThreatAccess
			local ev = Counter(T, "Evaluate", false)
			ns.simAccess = "open"
			T:Tick()
			ev.n = 0
			local r = {}
			T:EvalOne("tsfake1"); r[1] = ev.n
			local saveModern = ns.isModern
			ns.isModern, TA.checked = true, false
			T:EvalOne("tsfake1"); r[2] = ev.n
			ns.isModern, TA.checked = saveModern, true
			ns.testMode = true; T:EvalOne("tsfake1"); r[3] = ev.n; ns.testMode = false
			ns.simAccess = "secret"; T:EvalOne("tsfake1"); r[4] = ev.n
			local got = table.concat(r, "/")
			return got == "1/1/1/1", got, "1/1/1/1 (nur der erste Aufruf wertet aus)"
		end)
	end)
	C("T54", "B", "Plaketten-Ereignisse", function()
		local sc = Scene.New(0)
		sc.units.tsfake9 = { name = "Testmob 9", guid = "Creature-0-0-0-0-91009-0000000009", hostile = true, combat = true }
		Scene.Hold(sc, "tsfake9", "player")
		return Scene.Run(sc, function()
			local before = ns.errorCount
			ns:Fire("NAME_PLATE_UNIT_ADDED", "tsfake9")
			local added = ns.mobs.tsfake9 ~= nil
			ns.owners["plate:tsfake9"] = { name = "Grimbar", t = GetTime() }
			ns:Fire("NAME_PLATE_UNIT_REMOVED", "tsfake9")
			local removed = ns.mobs.tsfake9 == nil and ns.owners["plate:tsfake9"] == nil
			ns:Fire("UNIT_THREAT_LIST_UPDATE", SECRET)
			local got = string.format("hinzu %s, weg %s, Fehler +%d", S(added), S(removed), ns.errorCount - before)
			return added and removed and ns.errorCount == before, got, "hinzu true, weg true, Fehler +0"
		end)
	end)
	C("T55", "B", "Gruppen-Ansicht: Aggro-Anführer", function()
		local sc = Scene.New(3)
		sc.tank = false
		for i = 1, 3 do Scene.Hold(sc, "tsfake" .. i, "party3") end
		sc.units.party3.role = "NONE"
		return Scene.Run(sc, function()
			local T, db = ns.Threat, ns.db
			local save = { db.memberView, ns.tankAtPull }
			db.memberView, ns.tankAtPull, ns.lastTankT = true, nil, 0
			ns.simAccess = "open"
			T:Tick(); T:Tick()
			local a = ns.aggroLeader
			sc.threat, sc.alias = {}, {}
			T:Tick()
			ns.aggroLeaderT = GetTime() - 16
			T:Tick()
			local b = ns.aggroLeader
			db.memberView, ns.tankAtPull = save[1], save[2]
			return a == "Grimbar" and b == nil, "Anführer " .. S(a) .. ", nach 15 s " .. S(b), "Grimbar, danach nil"
		end)
	end)
	C("T56", "B", "GetUF", function()
		local GetUF = ns.Plates._GetUF
		local hb = {}
		local frames = {
			a = nil,
			b = { IsForbidden = function() return true end, UnitFrame = { healthBar = hb } },
			c = { UnitFrame = { healthBar = hb, IsForbidden = function() return true end } },
			d = { UnitFrame = { HealthBarsContainer = { healthBar = hb } } },
			e = { UnitFrame = {} },
		}
		return WithAPI({ C_NamePlate = { GetNamePlateForUnit = function(u) return frames[u] end } }, function()
			local d = GetUF("d")
			local got = table.concat({ S(GetUF("a")), S(GetUF("b")), S(GetUF("c")), S(d and d.healthBar == hb), S(GetUF("e")) }, " ")
			return got == "nil nil nil true nil", got, "nil nil nil true nil (keine, verboten, Frame verboten, Container, ohne Balken)"
		end)
	end)
	C("T57", "B", "P:Apply je Zustand", function()
		local sc = Scene.New(1)
		return Scene.Run(sc, function()
			local P, db = ns.Plates, ns.db
			local uf = sc.plates.tsfake1
			local base = ns.Safe(uf:GetScale(), 1)
			local res, bad = {}, nil
			local function want(label, m, check)
				P:Apply(uf, m)
				local i = P:Inspect("tsfake1")
				local ok, why = check(i)
				local rgb = i.borderRGB and string.format("%.2f,%.2f,%.2f", Num(i.borderRGB[1]), Num(i.borderRGB[2]), Num(i.borderRGB[3])) or "-"
				res[#res + 1] = label .. (ok and " ok" or (" " .. tostring(why) .. " [Rahmen " .. S(i.border) .. " " .. rgb
					.. ", Grösse " .. string.format("%.2f", Num(i.scale)) .. "/" .. string.format("%.2f", base) .. ", " .. S(i.strata) .. "]"))
				if not ok and not bad then bad = label end
			end
			local function col(i, c) local x = i.borderRGB; return x and Near(x[1], c[1], 0.02) and Near(x[2], c[2], 0.02) and Near(x[3], c[3], 0.02) end
			want("HELD", { state = "HELD" }, function(i) return i.border == false and Near(i.scale, base * db.heldScale, 0.02), "Rahmen/Grösse" end)
			want("WARN", { state = "WARN" }, function(i) return i.border and col(i, db.colorWarn) and i.strata == "HIGH" and Near(i.scale, base * db.warnScale, 0.02), "Farbe/Ebene/Grösse" end)
			want("LOOSE-DD", { state = "LOOSE", victim = "Torben", victimRole = "DAMAGER" },
				function(i) return i.border and col(i, db.colorDD) and Near(i.scale, base * db.looseScale, 0.02) and i.strata == "HIGH", "Farbe/Grösse" end)
			want("LOOSE-Heiler", { state = "LOOSE", victim = "Lina", victimRole = "HEALER" }, function(i) return i.border and col(i, db.colorHealer), "Farbe" end)
			want("übernommen", { state = "LOOSE", victim = "Lina", victimRole = "HEALER", claimedBy = "Grimbar" },
				function(i) return i.border and col(i, db.colorClaimed) and Near(i.scale, base, 0.02), "Farbe/Grösse" end)
			want("IDLE", { state = "IDLE" }, function(i) return i.border == false and Near(i.scale, base, 0.02), "Rahmen/Grösse" end)
			return bad == nil, table.concat(res, ", "), "alle Zustände wie in Apply"
		end)
	end)
	C("T59", "B", "RestoreFrame / Flash", function()
		local sc = Scene.New(1)
		return Scene.Run(sc, function()
			local P = ns.Plates
			local uf = sc.plates.tsfake1
			P:RestoreFrame(uf)
			local base, strata = ns.Safe(uf:GetScale(), 1), uf:GetFrameStrata()
			P:Apply(uf, { state = "LOOSE", victim = "Torben", victimRole = "DAMAGER" })
			P:RestoreFrame(uf)
			local i = P:Inspect("tsfake1")
			local back = Near(i.scale, base, 0.02) and i.strata == strata and i.border == false
			P:FlashFrame(uf)
			local f = P:Inspect("tsfake1")
			local got = "zurück " .. S(back) .. " [Grösse " .. string.format("%.2f/%.2f", Num(i.scale), base) .. ", " .. S(i.strata) .. "/" .. S(strata)
				.. ", Rahmen " .. S(i.border) .. "], Aufblinken " .. S(f.flash)
			return back and f.flash == true, got, "zurück true, Aufblinken true"
		end)
	end)
	C("T70", "B", "Meldungen anderer Tanks", function()
		local sc = Scene.New(0)
		return Scene.Run(sc, function()
			local A = ns.Alerts
			Swap(ns.Test, "IsTesting", function() return false end)
			A:RemoteResist("Grimbar"); A:RemoteCC("Grimbar")
			local tank = #sc.centers
			local okText = sc.centers[1] == string.format(L.REMOTE_RESIST, "Grimbar") and sc.centers[2] == string.format(L.REMOTE_CC, "Grimbar")
			sc.tank = false
			A:RemoteResist("Grimbar"); A:RemoteCC("Grimbar")
			local other = #sc.centers - tank
			return tank == 2 and okText and other == 0, "Tank " .. tank .. " (Text " .. S(okText) .. "), ohne Haltung " .. other, "Tank 2 (Text true), ohne Haltung 0"
		end)
	end)
	C("T77", "B", "Sync:Hello", function()
		local sent = {}
		Swap(ns.Sync, "Send", function(_, msg) sent[#sent + 1] = msg; return true end)
		local ok, err = pcall(function()
			ns.Sync:Hello(true); ns.Sync:Hello(); ns.Sync:Hello(true)
		end)
		UnswapAll()
		if not ok then error(err, 0) end
		local first = sent[1] or ""
		return #sent == 2 and first:find("^H:%u+:") ~= nil and first:find(ns.version, 1, true) ~= nil,
			#sent .. " Sendungen, " .. S(first), "2 Sendungen (zweite innerhalb 5 s gebremst), H:<Rolle>:" .. ns.version
	end)
	C("T83", "B", "Aggrometer Collect (offene Werte)", function()
		local sc = Scene.New(1)
		sc.group = { "party1", "party2", "party3", "party4", "party5" }
		sc.units.party4 = { name = "Mira", player = true, class = "ROGUE", combat = true }
		sc.units.party5 = { name = "Rolf", player = true, class = "HUNTER", combat = true }
		sc.alias.target = "tsfake1"
		Scene.Hold(sc, "tsfake1", "player", { party1 = 60, party2 = 90, party3 = 30, party4 = 75, party5 = 10 })
		return Scene.Run(sc, function()
			ns.simAccess = "open"
			local list, secret = ns.Meter:Collect()
			local names = {}
			for i, e in ipairs(list) do names[i] = tostring(e.name) end
			local got = table.concat(names, ",") .. (secret and " geschützt" or "")
			local want = "Anna,Lina,Mira,Torben,Grimbar,Rolf"
			local pp = ns.Meter._PullPercent
			local p1, p2 = WithAPI({ UnitIsPlayer = Ret(true) }, function()
				return pp("party1", nil, 110, "WARRIOR"), pp("party1", nil, 130, "MAGE")
			end)
			local pull = Near(p1, 100, 0.01) and Near(p2, 100, 0.01)
			return got == want and pull, got .. ", Pull " .. S(pull), want .. " (Tank zuerst, dann Anteil), Pull 110/130 % = 100"
		end)
	end)
	C("T85", "B", "HUD", function()
		local sc = Scene.New(0)
		return Scene.Run(sc, function()
			local H, db = ns.HUD, ns.db
			if not H.f then return false, "HUD fehlt", "HUD" end
			local was = H.f:IsShown()
			local loose = {}
			for i = 1, 7 do loose[i] = { name = "Testmob " .. i, victim = "Torben", victimRole = i == 1 and "HEALER" or "DAMAGER", mark = i == 1 and 8 or nil } end
			Swap(ns, "Unlocked", function() return false end)
			local saveRows, saveHud = db.hudMaxRows, db.hud
			db.hudMaxRows, db.hud = 5, true
			H:Update(loose, {})
			local lines = 0
			for _, l in ipairs(H.f.lines) do if l:IsShown() then lines = lines + 1 end end
			local head = H.f.header:GetText() == string.format(L.LOOSE, 7)
			local icon = (H.f.lines[1]:GetText() or ""):find("UI-RaidTargetingIcon_8", 1, true) ~= nil
			local shown = Shown(H.f)
			ns.memberNow = true; H:Update(loose, {}); local memberHidden = not Shown(H.f); ns.memberNow = false
			db.hud = false; H:Update(loose, {}); local offHidden = not Shown(H.f)
			db.hudMaxRows, db.hud = saveRows, saveHud
			if was then H.f:Show() else H.f:Hide() end
			local got = string.format("%d Zeilen, Kopf %s, Symbol %s, sichtbar %s, Gruppen-Ansicht weg %s, aus weg %s", lines, S(head), S(icon), S(shown), S(memberHidden), S(offHidden))
			return got == "5 Zeilen, Kopf true, Symbol true, sichtbar true, Gruppen-Ansicht weg true, aus weg true", got, "5 Zeilen, alles true"
		end)
	end)
	C("T58", "B", "Plaketten-Optionen an/aus", function()
		local sc = Scene.New(1)
		return Scene.Run(sc, function()
			local P, db = ns.Plates, ns.db
			local uf = sc.plates.tsfake1
			local m = { state = "LOOSE", victim = "Torben", victimRole = "DAMAGER", hint = "TSHinweis" }
			local keys = { looseFire = "fire", effectGlow = "glow", loosePulse = "pulse", showHints = "hint" }
			local res, bad = {}, nil
			for k, field in pairs(keys) do
				local orig = db[k]
				local seen = {}
				for _, v in ipairs({ true, false }) do
					db[k] = v
					P:Apply(uf, m)
					local i = P:Inspect("tsfake1")
					local x = i[field]
					if field == "hint" then x = (x == "TSHinweis") end
					seen[v] = x and true or false
				end
				db[k] = orig
				res[#res + 1] = k .. " " .. S(seen[true]) .. "/" .. S(seen[false])
				if not (seen[true] and not seen[false]) and not bad then bad = k end
			end
			local before = ns.errorCount
			local saveB, saveE, saveO = db.borderSize, db.effectStrength, db.outOfCombatMode
			local ok, err = pcall(function()
				for _, b in ipairs({ 1, 6 }) do db.borderSize = b; P:Apply(uf, m) end
				for _, e in ipairs({ 50, 200 }) do db.effectStrength = e; P:Apply(uf, m) end
				for _, o in ipairs({ "normal", "faded" }) do db.outOfCombatMode = o; P:Apply(uf, { state = "IDLE" }) end
				for _, k in ipairs({ "warnBlink", "showSunder", "showTankStripe" }) do
					local orig = db[k]
					db[k] = true; P:Apply(uf, { state = "WARN" }); db[k] = false; P:Apply(uf, { state = "WARN" }); db[k] = orig
				end
			end)
			db.borderSize, db.effectStrength, db.outOfCombatMode = saveB, saveE, saveO
			if not ok then bad = bad or Clean(err) end
			table.sort(res)
			return bad == nil and ns.errorCount == before, table.concat(res, ", ") .. (ok and "" or (" | " .. Clean(err))),
				"an/aus wirkt (true/false), übrige Optionen ohne Fehler"
		end)
	end)
	C("T65", "B", "OnLoose / OnWarn / OnRegain", function()
		local sc = Scene.New(1)
		return Scene.Run(sc, function()
			local A, db = ns.Alerts, ns.db
			local keys = {}
			Swap(A, "Play", function(_, key) keys[#keys + 1] = tostring(key) end)
			local save = { db.soundWarn, db.regainSound, db.regainText, db.memberSelfWarn }
			local r = {}
			A:OnLoose({ victimRole = "HEALER" }); A:OnLoose({ victimRole = "DAMAGER" })
			r[1] = (keys[1] == tostring(db.soundHealer) and keys[2] == tostring(db.soundDD)) and "Heiler/DD" or table.concat(keys, ",")
			ns.testMode = true; A:OnLoose({ victimRole = "DAMAGER" }); ns.testMode = false
			r[2] = #keys == 2 and "Test still" or "Test laut"
			db.soundWarn = "none"; A:OnWarn({}); r[3] = #keys == 2 and "kein Warnton" or "Warnton"
			db.regainSound, db.regainText = false, false
			local c0 = #sc.centers
			A:OnRegain("tsfake1", {}); r[4] = (#keys == 2 and #sc.centers == c0) and "Zurück still" or "Zurück laut"
			db.regainSound, db.regainText = true, true
			A:OnRegain("tsfake1", {}); r[5] = (#keys == 3 and #sc.centers == c0 + 1) and "Zurück Ton+Text" or "Zurück fehlt"
			ns.memberNow, db.memberSelfWarn = true, true
			A:OnLoose({ victimIsMe = true, name = "Testmob 1" })
			r[6] = (sc.centers[#sc.centers] or ""):find(FormatStem(L.SELF_AGGRO), 1, true) and "Selbst-Aggro" or "Selbst-Aggro fehlt"
			ns.memberNow = false
			db.soundWarn, db.regainSound, db.regainText, db.memberSelfWarn = save[1], save[2], save[3], save[4]
			local got = table.concat(r, ", ")
			local want = "Heiler/DD, Test still, kein Warnton, Zurück still, Zurück Ton+Text, Selbst-Aggro"
			return got == want, got, want
		end)
	end)
	C("T67", "B", "Leben (HealthPercent)", function()
		local r = {}
		WithAPI({ UnitHealth = Ret(50), UnitHealthMax = Ret(200) }, function() r[1] = ns.Alerts:HealthPercent() end)
		WithAPI({ UnitHealth = Ret(50), UnitHealthMax = Ret(0) }, function() r[2] = ns.Alerts:HealthPercent() end)
		WithAPI({ UnitHealth = Ret(SECRET), UnitHealthMax = Ret(200) }, function() r[3] = ns.Alerts:HealthPercent() end)
		local got = S(r[1]) .. "/" .. S(r[2]) .. "/" .. S(r[3])
		return r[1] == 25 and r[2] == 100 and r[3] == nil, got, "25/100/nil (Notfall-Ersatz: T175 und im Client)"
	end)
	C("T66", "B", "Alerts:Evaluate (Flächenspott, Notfall, Heiler-Reichweite)", function()
		local sc = Scene.New(0)
		sc.units.party4 = { name = "Mia", player = true, class = "PRIEST", role = "HEALER", combat = true, power = 0 }
		sc.units.party5 = { name = "Eva", player = true, class = "DRUID", role = "HEALER", combat = true, power = 0 }
		sc.group = { "party1", "party2", "party3", "party4", "party5" }
		return Scene.Run(sc, function()
			local A, db = ns.Alerts, ns.db
			local save = { db.aoeHint, db.aoeThreshold, db.emergency, db.emergencyHP, db.healerRange, ns.aoeSpell, ns.defensives, A.emergShown }
			local function count(text)
				local n = 0
				for _, t in ipairs(sc.centers) do if t == text then n = n + 1 end end
				return n
			end
			local ok, res = pcall(function()
				db.aoeHint, db.aoeThreshold, db.emergency, db.emergencyHP, db.healerRange = true, 3, true, 30, true
				ns.aoeSpell, ns.defensives, A.emergShown = "TSFlaeche", { "TSSchild" }, false
				local oor = { party2 = true, party4 = true, party5 = true }
				local extras
				WithAPI({ GetSpellCooldown = Ret(0, 0), C_Spell = NIL, UnitHealth = Ret(20), UnitHealthMax = Ret(100),
					UnitInRange = function(u) if oor[u] then return false, true end return true, true end }, function()
					A:Evaluate({ {}, {}, {} }, 1)
					A:Evaluate({ {}, {}, {} }, 1)
					extras = #A.extras
					ns.memberNow = true
					local before = #sc.centers
					A:Evaluate({ {}, {}, {} }, 1)
					extras = extras .. "/" .. #A.extras .. "/" .. (#sc.centers - before)
					ns.memberNow = false
				end)
				return string.format("Flächenspott %d, Notfall %d, Ton %d, Heiler-Zeilen %s", count(string.format(L.AOE_HINT, "TSFlaeche")), count(string.format(L.EMERGENCY, "TSSchild")), sc.plays, extras)
			end)
			db.aoeHint, db.aoeThreshold, db.emergency, db.emergencyHP, db.healerRange = save[1], save[2], save[3], save[4], save[5]
			ns.aoeSpell, ns.defensives, A.emergShown = save[6], save[7], save[8]
			wipe(A.extras)
			if not ok then error(res, 0) end
			local want = "Flächenspott 2, Notfall 2, Ton 1, Heiler-Zeilen 2/0/0"
			return res == want, res, want .. " (Ton nur einmal, höchstens 2 Zeilen, Gruppen-Ansicht nichts)"
		end)
	end)
	C("T68", "B", "Spott widerstanden (OnResist)", function()
		local sc = Scene.New(0)
		return Scene.Run(sc, function()
			local A, db = ns.Alerts, ns.db
			local sent = {}
			Swap(ns.Sync, "Send", function(_, m) sent[#sent + 1] = m; return true end)
			local save = { ns.backupSpells, db.announceResist, ns.tauntMode, ns.tauntSpell }
			local ok, res = pcall(function()
				db.announceResist, ns.tauntMode, ns.tauntSpell, ns.backupSpells = false, "hostile", "TSSpott", {}
				A:OnResist("Testmob", "Creature-0-0-0-0-91001-0000000001", true)
				local selfText = sc.centers[#sc.centers] == L.RESIST_SELF
				local s1 = #sent
				ns.backupSpells = { "TSErsatz" }
				WithAPI({ GetSpellCooldown = Ret(0, 0), C_Spell = NIL }, function()
					A:OnResist("Testmob", "Creature-0-0-0-0-91001-0000000001", true)
				end)
				local backupText = sc.centers[#sc.centers] == string.format(L.RESIST_BACKUP, "TSErsatz")
				A:_ResetResistThrottle()
				A:OnResist("Testmob", "Creature-0-0-0-0-91001-0000000001", false)
				A:OnResist("Testmob", "Creature-0-0-0-0-91001-0000000001", false)
				return string.format("selbst %s, Ersatz %s, Test gesendet %d, echt gesendet %d (%s)", S(selfText), S(backupText), s1, #sent, S(sent[1]))
			end)
			A:_ResetResistThrottle()
			ns.backupSpells, db.announceResist, ns.tauntMode, ns.tauntSpell = save[1], save[2], save[3], save[4]
			if not ok then error(res, 0) end
			local want = "selbst true, Ersatz true, Test gesendet 0, echt gesendet 1 (R:Creature-0-0-0-0-91001-0000000001)"
			return res == want, res, want .. " (zweiter Widerstand < 1.5 s ignoriert)"
		end)
	end)
	C("T69", "B", "Tank kontrolliert (CheckCC)", function()
		local sc = Scene.New(0)
		return Scene.Run(sc, function()
			local A, db = ns.Alerts, ns.db
			local sent = {}
			Swap(ns.Sync, "Send", function(_, m) sent[#sent + 1] = m; return true end)
			local save = { db.announceCC, db.ccMinDuration, db.chatChannel, A.ccState }
			local txt, dur = "TSBetäubt", 4
			local LC = { GetActiveLossOfControlDataCount = Ret(1),
				GetActiveLossOfControlData = function() return { locType = "STUN", displayText = txt, timeRemaining = dur } end }
			local ok, res = pcall(WithAPI, { HasFullControl = Ret(false), C_LossOfControl = LC }, function()
				db.announceCC, db.ccMinDuration, db.chatChannel, A.ccState = true, 1.5, "OFF", nil
				local r = {}
				A:CheckCC(); r[1] = sent[#sent] or "-"
				local n = #sent
				A:CheckCC(); r[2] = (#sent == n) and "keine Wiederholung" or "wiederholt"
				A.ccState, dur = nil, 1
				A:CheckCC(); r[3] = (#sent == n) and "zu kurz still" or "zu kurz gemeldet"
				A.ccState, dur = nil, 4
				ns.memberNow = true; A:CheckCC(); ns.memberNow = false
				r[4] = (#sent == n) and "Gruppen-Ansicht still" or "Gruppen-Ansicht gemeldet"
				A.ccState, txt, dur = nil, SECRET, SECRET
				A:CheckCC(); r[5] = sent[#sent] or "-"
				return table.concat(r, ", ")
			end)
			db.announceCC, db.ccMinDuration, db.chatChannel, A.ccState = save[1], save[2], save[3], save[4]
			if not ok then error(res, 0) end
			local want = "X:TSBetäubt, keine Wiederholung, zu kurz still, Gruppen-Ansicht still, X:"
			return res == want, res, want .. " (geschützte Felder: Meldung ohne Text)"
		end)
	end)
	C("T71", "B", "Hinweis Spott-Taste (CheckKeyHint)", function()
		local A, db = ns.Alerts, ns.db
		local save = { db.keyHintDone, ns.tauntSpell, ns.tauntMode }
		local function pops() return (ns.actLog and ns.actLog.n.popup) or 0 end
		local ok, res = pcall(function()
			ns.tauntSpell, ns.tauntMode = "TSSpott", "hostile"
			local r = {}
			local p0 = pops()
			db.keyHintDone = false
			WithAPI({ IsInInstance = Ret(false) }, function() A:CheckKeyHint() end)
			r[1] = (pops() == p0 and not db.keyHintDone) and "draussen nichts" or "draussen gezeigt"
			WithAPI({ IsInInstance = Ret(true), GetBindingKey = Ret("F5") }, function() A:CheckKeyHint() end)
			r[2] = (pops() == p0 and db.keyHintDone) and "Taste belegt" or "Taste belegt falsch"
			db.keyHintDone = false
			WithAPI({ IsInInstance = Ret(true), GetBindingKey = Ret(nil), InCombatLockdown = Ret(true) }, function() A:CheckKeyHint() end)
			r[3] = (pops() == p0 and not db.keyHintDone) and "Kampf später" or "Kampf falsch"
			WithAPI({ IsInInstance = Ret(true), GetBindingKey = Ret(nil), InCombatLockdown = Ret(false) }, function()
				A:CheckKeyHint(); A:CheckKeyHint()
			end)
			r[4] = (pops() == p0 + 1 and db.keyHintDone) and "Hinweis 1x" or ("Hinweis " .. (pops() - p0) .. "x")
			return table.concat(r, ", ")
		end)
		db.keyHintDone, ns.tauntSpell, ns.tauntMode = save[1], save[2], save[3]
		if not ok then error(res, 0) end
		local want = "draussen nichts, Taste belegt, Kampf später, Hinweis 1x"
		return res == want, res, want .. " (Fenster nur mitgeschrieben)"
	end)
	C("T72", "B", "Kampflog-Spott (nur alte API)", function()
		if ns.isModern or not ns.Alerts.cleuRegistered then return true, "moderne API: Kampflog gesperrt (siehe T85)" end
		local A = ns.Alerts
		local save = { ns.tauntSpell, ns.tauntMode, ns.playerGUID, ns.simSecret }
		local res = Counter(A, "OnResist", false)
		local vias = {}
		UnswapAll()
		Swap(A, "OnResist", function(_, _, _, _, via) vias[#vias + 1] = tostring(via) end)
		local src = "Player-0-TSICH"
		local function ev(source) return Ret(1, "SPELL_MISSED", false, source, "x", 0, 0, "Creature-0-0-0-0-91001-0000000001", "Testmob", 0, 0, 99901, "TSSpott") end
		local ok, err = pcall(function()
			ns.tauntSpell, ns.tauntMode, ns.playerGUID, ns.simSecret = "TSSpott", "hostile", src, nil
			WithAPI({ CombatLogGetCurrentEventInfo = ev(src) }, function() A.OnCombatLog() end)
			WithAPI({ CombatLogGetCurrentEventInfo = ev("Player-0-ANDERER") }, function() A.OnCombatLog() end)
			ns.simSecret = true
			WithAPI({ CombatLogGetCurrentEventInfo = ev(src) }, function() A.OnCombatLog() end)
		end)
		UnswapAll()
		ns.tauntSpell, ns.tauntMode, ns.playerGUID, ns.simSecret = save[1], save[2], save[3], save[4]
		if not ok then error(err, 0) end
		local got = #vias .. " " .. table.concat(vias, ",")
		return got == "1 log", got, "1 log (andere Quelle und Simulation: nichts)"
	end)
	C("T78", "B", "Eigene Zauber (Abklingzeit, Spott, Zerreissen, Siegel)", function()
		local sc = Scene.New(1)
		sc.alias.target = "tsfake1"
		return Scene.Run(sc, function()
			local K = ns.Track
			local names = { [99901] = "TSSpott", [99902] = "TSZerreissen", [99903] = "TSSiegel" }
			local save = { ns.tauntSpell, ns.tauntMode, ns.sunderName, ns.sealName, ns.sealUntil, ns.spellIdByName.TSSpott, ns.cdTrack.TSSpott, ns.db.cdLearned.TSSpott }
			local own = Counter(K, "OnOwnTaunt", false)
			local now = GetTime()
			local ok, res = pcall(WithAPI, {
				C_Spell = { GetSpellName = function(id) return names[id] end }, GetSpellInfo = NIL,
				GetSpellCooldown = Ret(now, 10), GetSpellBaseCooldown = Ret(8000),
				C_Timer = { After = function(_, fn) fn() end, NewTicker = C_Timer.NewTicker, NewTimer = C_Timer.NewTimer },
			}, function()
				ns.tauntSpell, ns.tauntMode, ns.sunderName, ns.sealName = "TSSpott", "hostile", "TSZerreissen", "TSSiegel"
				ns.spellIdByName.TSSpott = 99901
				ns:Fire("UNIT_SPELLCAST_SUCCEEDED", "player", nil, 99901)
				local cd = ns.cdTrack.TSSpott and (ns.cdTrack.TSSpott - now) or -1
				local learned = ns.db.cdLearned.TSSpott
				for _ = 1, 6 do ns:Fire("UNIT_SPELLCAST_SUCCEEDED", "player", nil, 99902) end
				local sunder = K:Sunder(sc.units.tsfake1.guid)
				ns:Fire("UNIT_SPELLCAST_SUCCEEDED", "player", nil, 99903)
				local seal = (ns.sealUntil or 0) - GetTime()
				ns.tauntMode = "seal"; ns.sealUntil = GetTime() + 30
				Swap(ns, "HasSealOfFury", function() return true end)
				ns:Fire("UNIT_SPELLCAST_SUCCEEDED", "player", nil, 99901)
				local sealAfter = ns.sealUntil
				return string.format("Abklingzeit %.0f s, gelernt %s, Spott %dx, Zerreissen %d, Siegel %.0f s, nach Richturteil %s",
					cd, S(learned), own.n, sunder, seal, S(sealAfter))
			end)
			ns.tauntSpell, ns.tauntMode, ns.sunderName, ns.sealName, ns.sealUntil = save[1], save[2], save[3], save[4], save[5]
			ns.spellIdByName.TSSpott, ns.cdTrack.TSSpott, ns.db.cdLearned.TSSpott = save[6], save[7], save[8]
			if not ok then error(res, 0) end
			local want = "Abklingzeit 10 s, gelernt 10, Spott 2x, Zerreissen 5, Siegel 30 s, nach Richturteil 0"
			return res == want, res, want
		end)
	end)
	C("T79", "B", "Kontrolle der Gruppe (Tracker)", function()
		local sc = Scene.New(0)
		sc.units.nameplatets1 = { name = "Testmob 1", guid = "Creature-0-0-0-0-91010-0000000010", hostile = true, combat = true }
		sc.units.nameplatets2 = { name = "Testmob 2", guid = "Creature-0-0-0-0-91010-0000000011", hostile = true, combat = true }
		ns.Test:CreatePreview()
		sc.plates.nameplatets1 = ns.Test.preview.plates[1]
		sc.plates.nameplatets2 = ns.Test.preview.plates[2]
		return Scene.Run(sc, function()
			local K = ns.Track
			local names = { [6770] = "TSKopfnuss", [118] = "TSVerwandlung" }
			local k1, k2 = sc.units.nameplatets1.guid, sc.units.nameplatets2.guid
			return WithAPI({ C_Spell = { GetSpellName = function(id) return names[id] end }, GetSpellInfo = NIL }, function()
				sc.alias.party1target = "nameplatets1"
				ns:Fire("UNIT_SPELLCAST_SUCCEEDED", "party1", nil, 6770)
				local cc = K:IsCC(k1)
				ns:Fire("UNIT_HEALTH", "nameplatets1")
				local early = K:IsCC(k1)
				K.ccSince[k1] = GetTime() - 2
				ns:Fire("UNIT_HEALTH", "nameplatets1")
				local broken = not K:IsCC(k1)
				sc.alias.party1target = "nameplatets2"
				ns:Fire("UNIT_SPELLCAST_SUCCEEDED", "party1", nil, 118)
				K.ccSince[k2] = GetTime() - 2
				ns:Fire("UNIT_HEALTH", "nameplatets2")
				local poly = K:IsCC(k2)
				K:Forget(k2)
				local forgot = not K:IsCC(k2)
				local got = string.format("Kopfnuss %s, sofort %s, Schaden bricht %s, Verwandlung bleibt %s, vergessen %s",
					S(cc), S(early), S(broken), S(poly), S(forgot))
				return got == "Kopfnuss true, sofort true, Schaden bricht true, Verwandlung bleibt true, vergessen true", got, "alles true"
			end)
		end)
	end)
	C("T80", "B", "Widerstand ohne Kampflog (über die Bedrohung)", function()
		if not ns.isModern and ns.Alerts:CombatLogWorks() then return true, "alte API: Kampflog vorhanden (T72)" end
		local sc = Scene.New(1)
		sc.alias.target = "tsfake1"
		Scene.Hold(sc, "tsfake1", "party1", { player = 50 })
		return Scene.Run(sc, function()
			local A, K = ns.Alerts, ns.Track
			local vias = {}
			Swap(A, "OnResist", function(_, _, _, _, via) vias[#vias + 1] = tostring(via) end)
			Swap(ns.Sync, "Send", function() return true end)
			local save = { ns.tauntSpell, ns.tauntMode }
			local ok, res = pcall(WithAPI, { C_Timer = { After = function(_, fn) fn() end, NewTicker = C_Timer.NewTicker, NewTimer = C_Timer.NewTimer } }, function()
				ns.tauntSpell, ns.tauntMode = "TSSpott", "hostile"
				K:OnOwnTaunt("TSSpott")
				local a = #vias
				sc.secret = true
				K:OnOwnTaunt("TSSpott")
				return a .. "/" .. #vias .. " " .. table.concat(vias, ",")
			end)
			ns.tauntSpell, ns.tauntMode = save[1], save[2]
			if not ok then error(res, 0) end
			return res == "1/1 threat", res, "1/1 threat (geschützt: nichts)"
		end)
	end)
	C("T82", "B", "Spezialisierung und Betrachten", function()
		local SP = ns.Specs
		local SR = SP._SpecRole
		local r = {}
		WithAPI({ GetSpecialization = Ret(2), GetSpecializationInfo = Ret(73, "x", "x", 0, "TANK") }, function() r[1] = SR("player") end)
		WithAPI({ GetSpecialization = Ret(SECRET), GetSpecializationInfo = Ret(73, "x", "x", 0, "TANK") }, function() r[2] = SR("player") end)
		WithAPI({ GetSpecialization = Ret(0), GetSpecializationInfo = Ret(73, "x", "x", 0, "TANK") }, function() r[3] = SR("player") end)
		WithAPI({ GetInspectSpecialization = Ret(71), GetSpecializationRoleByID = Ret("DAMAGER") }, function() r[4] = SR("party1", true) end)
		WithAPI({ GetInspectSpecialization = Ret(SECRET), GetSpecializationRoleByID = Ret("DAMAGER") }, function() r[5] = SR("party1", true) end)
		local db = ns.db
		local saveCheck, saveLast = db.specCheck, SP.lastInspect
		local before = (ns.actLog and ns.actLog.n.inspect) or 0
		db.specCheck, SP.lastInspect = true, 0
		WithAPI({ IsInGroup = Ret(true), InCombatLockdown = Ret(true) }, function() SP:Step() end)
		local inspects = ((ns.actLog and ns.actLog.n.inspect) or 0) - before
		db.specCheck, SP.lastInspect = saveCheck, saveLast
		local okList, list = pcall(SP.ListText, SP, 10)
		local got = table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]) }, " ") .. ", im Kampf betrachtet " .. inspects .. ", Liste " .. S(okList)
		local want = "TANK nil nil DAMAGER nil, im Kampf betrachtet 0, Liste true"
		return got == want, got, want
	end)
	C("T88", "B", "Spott-Knöpfe (Makros, Tastenbelegung)", function()
		local Tb = ns.Taunt
		if not (Tb and Tb.taunt and Tb.taunt.GetAttribute) then return false, "Spott-Knopf fehlt", "Knopf" end
		local orig = Tb.taunt:GetAttribute("macrotext")
		local save = { ns.tauntSpell, ns.tauntMode, Tb.pending }
		local r = {}
		local ok, err = pcall(function()
			ns.tauntSpell, ns.tauntMode = "TSSpott", "hostile"
			Tb:UpdateMacros(); r[1] = Tb.taunt:GetAttribute("macrotext") == "/cast [@mouseover,harm,nodead][harm,nodead] TSSpott"
			ns.tauntMode = "friendly"
			Tb:UpdateMacros(); r[2] = (Tb.taunt:GetAttribute("macrotext") or ""):find("@mouseover,help", 1, true) ~= nil
			ns.tauntSpell = nil
			Tb:UpdateMacros(); r[3] = Tb.taunt:GetAttribute("macrotext") == ""
			local before = Tb.taunt:GetAttribute("macrotext")
			ns.tauntSpell, ns.tauntMode = "TSSpott", "hostile"
			WithAPI({ InCombatLockdown = Ret(true) }, function() Tb:UpdateMacros() end)
			r[4] = Tb.pending == true and Tb.taunt:GetAttribute("macrotext") == before
			local b0 = (ns.actLog and ns.actLog.n.binding) or 0
			local fight = WithAPI({ InCombatLockdown = Ret(true), GetBindingKey = Ret("F5") }, function() return Tb:SetKey("taunt", "F6") end)
			local b1 = (ns.actLog and ns.actLog.n.binding) or 0
			local calm = WithAPI({ InCombatLockdown = Ret(false), GetBindingKey = Ret("F5"), GetCurrentBindingSet = Ret(1) }, function() return Tb:SetKey("taunt", "F6") end)
			local b2 = (ns.actLog and ns.actLog.n.binding) or 0
			r[5] = fight == false and b1 == b0 and calm == true and b2 - b1 == 3
		end)
		ns.tauntSpell, ns.tauntMode, Tb.pending = save[1], save[2], save[3]
		pcall(Tb.UpdateMacros, Tb)
		local back = Tb.taunt:GetAttribute("macrotext") == orig
		if not ok then error(err, 0) end
		local got = table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]) }, " ") .. ", zurück " .. S(back)
		return got == "true true true true true, zurück true", got, "Feind, Freund, ohne Spott, Kampf aufgeschoben, Tasten nur mitgeschrieben; Makro wie vorher"
	end)
	C("T91", "B", "Ton- und Farbwahl, Popups", function()
		local O = ns.Options
		local c, changed = { 1, 0, 0 }, 0
		local apply, cancel = O._ColorCallbacks(c, function() changed = changed + 1 end, function() return 0, 1, 0 end)
		apply()
		local applied = c[1] == 0 and c[2] == 1
		cancel()
		local restored = c[1] == 1 and c[2] == 0 and changed == 2
		local okPick, err = pcall(function()
			O:OpenSoundPicker("TS", "soundDD", function() end)
			O:RefreshPicker()
		end)
		local shown = O.picker and O.picker:IsShown() or false
		if O.picker then O.picker:Hide() end
		local pops = 0
		for _, k in ipairs({ "THREATSENTINEL_BINDKEY", "THREATSENTINEL_REBIND", "THREATSENTINEL_CUSTOMSOUND", "THREATSENTINEL_RELOAD" }) do
			local d = StaticPopupDialogs and StaticPopupDialogs[k]
			if d and type(d.text) == "string" and d.text ~= "" then pops = pops + 1 end
		end
		local got = string.format("Farbe übernommen %s, abgebrochen %s, Tonauswahl %s/%s, Popups %d", S(applied), S(restored), S(okPick), S(shown), pops)
		local want = "Farbe übernommen true, abgebrochen true, Tonauswahl true/true, Popups 4"
		return got == want, okPick and got or Clean(err), want .. " (Blizzard-Farbfenster nicht geöffnet)"
	end)
	C("T92", "B", "Minimap-Knopf", function()
		local O, db = ns.Options, ns.db
		local b = O.minimap
		if not b then return false, "Knopf fehlt", "Knopf" end
		local save = { db.minimapShow, db.minimapAngle, b:IsShown() }
		local ok, res = pcall(function()
			db.minimapShow = true; O:UpdateMinimap(); local on = b:IsShown()
			db.minimapShow = false; O:UpdateMinimap(); local off = not b:IsShown()
			for _, a in ipairs({ 0, 220 }) do db.minimapAngle = a; O:PlaceMinimap() end
			local enter, leave = b:GetScript("OnEnter"), b:GetScript("OnLeave")
			if enter then enter(b) end
			if leave then leave(b) end
			return S(on) .. "/" .. S(off)
		end)
		db.minimapShow, db.minimapAngle = save[1], save[2]
		O:UpdateMinimap()
		if save[3] then b:Show() else b:Hide() end
		if not ok then return false, Clean(res), "kein Fehler" end
		return res == "true/true", "an/aus " .. res .. ", Winkel 0/220 und Tooltip ohne Fehler", "true/true"
	end)

end

------------------------------------------------------------
-- C. Forever-Sonderfälle (simuliert)
------------------------------------------------------------
Area.C = function()
	C("T102", "C", "Chat-Argumente geschützt", function()
		local before = ns.errorCount
		ns.testBait = SECRET
		ns:Fire("CHAT_MSG_ADDON", ns.Sync.PREFIX, SECRET, "PARTY", SECRET)
		ns.testBait = nil
		return ns.errorCount == before, "Fehler +" .. (ns.errorCount - before), "kein Fehler"
	end)
	C("T111", "C", "Kampflog auf der modernen API nicht angemeldet", function()
		local reg = ns:HasHandler("COMBAT_LOG_EVENT_UNFILTERED")
		if ns.isModern then
			return reg == false and ns.Alerts.cleuRegistered == false and ns.DmgMeter.allowed == false, S(reg), "nicht angemeldet"
		end
		return reg == true and ns.Alerts.cleuRegistered == true and ns.DmgMeter.allowed == true, S(reg), "Gegenprobe: angemeldet"
	end)
	C("T97", "C", "Bedrohung geschützt, ganzer Durchlauf", function()
		local sc = Scene.New(5)
		local saveModern = ns.isModern
		ns.isModern = true
		local ok, a, b, c = pcall(Scene.Run, sc, function()
			local T, TA = ns.Threat, ns.ThreatAccess
			ns.threatAccess, ns.simAccess, TA.announced = "open", nil, false
			local before = ns.errorCount
			T:Tick()                       -- Modus VOLL, Werte offen
			local up = Counter(ns.Plates, "Update", false)
			local hud = 0
			Swap(ns.HUD, "Update", function(_, loose) if loose and #loose > 0 then hud = hud + 1 end end)
			sc.secret = true
			T:Tick(); T:Tick(); T:Tick()
			local notes = 0
			for _, t in ipairs(sc.centers) do if t == L.TA_NOTE_DISPLAY then notes = notes + 1 end end
			local got = string.format("Modus %s, Zugriff %s, Plaketten %d, HUD-Zeilen %d, Hinweis %dx, Fehler +%d",
				ns:ThreatMode(), S(ns.threatAccess), up.n, hud, notes, ns.errorCount - before)
			return got == "Modus DISPLAY, Zugriff secret, Plaketten 0, HUD-Zeilen 0, Hinweis 1x, Fehler +0", got,
				"DISPLAY, secret, 0 Plaketten, HUD leer, Hinweis 1x, kein Fehler"
		end)
		ns.isModern = saveModern
		if not ok then error(a, 0) end
		return a, b, c
	end)
	C("T98", "C", "Namen und GUIDs geschützt", function()
		local save = { ns.groupUnits, ns.groupNames, ns.nameToUnit }
		local names = { party1 = SECRET, party2 = "Torben" }
		WithAPI({ IsInRaid = Ret(false), GetNumSubgroupMembers = Ret(2), UnitIsPlayer = Ret(true),
			UnitExists = function(u) return u ~= "pet" and u ~= "partypet1" and u ~= "partypet2" end,
			UnitName = function(u) if names[u] then return names[u], "" end return "Anna", "" end }, function()
			ns:UpdateGroup()
		end)
		local keys, bad = 0, false
		for k in pairs(ns.groupNames) do keys = keys + 1; if rawequal(k, SECRET) then bad = true end end
		local units = #ns.groupUnits
		local key = WithAPI({ UnitGUID = Ret(SECRET) }, function() return ns:MobKey("tsfake1") end)
		ns.groupUnits, ns.groupNames, ns.nameToUnit = save[1], save[2], save[3]
		return not bad and keys == 2 and units == 3 and key == "plate:tsfake1",
			string.format("%d Einheiten, %d Namen, SECRET-Schlüssel %s, %s", units, keys, S(bad), S(key)), "3 Einheiten, 2 Namen, false, plate:tsfake1"
	end)
	C("T99", "C", "Auren geschützt", function()
		local function sec() return SECRET, nil, SECRET, nil, nil, nil, nil, nil, nil, SECRET end
		local a, b = WithAPI({ UnitBuff = sec, UnitDebuff = sec, UnitAffectingCombat = Ret(false) }, function()
			return ns:FindAura("player", "HELPFUL", { [71] = true })
		end)
		return a == false and b == false, S(a) .. "/" .. S(b), "false/false (nicht lesbar)"
	end)
	C("T100", "C", "Abklingzeiten geschützt", function()
		local now = GetTime()
		local saveMode = ns.tauntMode
		ns.tauntMode = "hostile"
		ns.cdTrack.TSTest = now + 6
		local v = WithAPI({ GetSpellCooldown = Ret(SECRET, SECRET), C_Spell = { GetSpellCooldown = function() return { startTime = SECRET, duration = SECRET } end } },
			function() return ns.SpellCD("TSTest") end)
		local v2 = WithAPI({ GetSpellCooldown = NIL, C_Spell = { GetSpellCooldown = function() return { startTime = SECRET, duration = SECRET } end } },
			function() return ns.SpellCD("TSTest") end)
		ns.cdTrack.TSTest = nil
		ns.tauntMode = saveMode
		local mode = ns.compat.cooldowns and ns.compat.cooldowns.mode
		return Near(v, 6, 0.1) and Near(v2, 6, 0.1) and mode == "fallback", string.format("%.1f / %.1f %s", Num(v), Num(v2), S(mode)), "6 / 6 fallback (aus cdTrack)"
	end)
	C("T101", "C", "Ziel und Mausziel geschützt", function()
		local n, plate = WithAPI({ UnitExists = Ret(SECRET), UnitCanAttack = Ret(SECRET), UnitAffectingCombat = Ret(SECRET) }, function()
			return #ns.ThreatAccess:Candidates(ns.mobs), ns:PlateFor("mouseover")
		end)
		return n == 0 and plate == nil, n .. " Kandidaten, Plakette " .. S(plate), "0, nil"
	end)
	C("T103", "C", "Reichweite geschützt", function()
		local r = WithAPI({ IsSpellInRange = Ret(SECRET), C_Spell = { IsSpellInRange = Ret(SECRET) } }, function()
			return ns.SpellInRange("TSTest", "target")
		end)
		return r == nil, S(r), "nil (kein 'zu weit')"
	end)
	C("T104", "C", "Zauber-Funktionen fehlen", function()
		local before = ns.errorCount
		local r = WithAPI({ GetSpellInfo = NIL, GetSpellTexture = NIL, GetSpellCooldown = NIL, IsSpellInRange = NIL,
			GetSpellBaseCooldown = NIL, IsPlayerSpell = NIL, IsSpellKnown = NIL, C_Spell = NIL }, function()
			return { ns.SpellName(355), ns.SpellIcon(355), ns.SpellCD("TSTest"), ns.SpellInRange("TSTest", "target"), ns:BaseCooldown("TSTest") }
		end)
		return r[1] == nil and r[3] == 0 and r[4] == nil and ns.errorCount == before,
			string.format("Name %s, CD %s, Reichweite %s", S(r[1]), S(r[3]), S(r[4])), "nil, 0, nil – kein Fehler"
	end)
	C("T105", "C", "Auren-Funktionen fehlen -> C_UnitAuras", function()
		local a = WithAPI({ UnitBuff = NIL, UnitDebuff = NIL, UnitAffectingCombat = Ret(false),
			C_UnitAuras = { GetAuraDataByIndex = function(_, i) if i == 1 then return { name = "TSAura", applications = 2, spellId = 71 } end end } },
			function() local n, c, id = ns.Aura("player", 1, "HELPFUL"); return S(n) .. "/" .. S(c) .. "/" .. S(id) end)
		return a == "TSAura/2/71", a, "TSAura/2/71"
	end)
	C("T106", "C", "Chat-, CVar- und Addon-Funktionen fehlen", function()
		local before = ns.errorCount
		local save = { ns.db.sync, ns.simSecret }
		ns.db.sync, ns.simSecret = true, nil
		local ok, res = pcall(WithAPI, { C_ChatInfo = NIL, SendAddonMessage = NIL, RegisterAddonMessagePrefix = NIL,
			C_CVar = NIL, GetCVar = NIL, SetCVar = NIL, C_AddOns = NIL, GetAddOnMetadata = NIL,
			InCombatLockdown = Ret(false), IsInGroup = Ret(true), IsInRaid = Ret(false) }, function()
			local sent = ns.Sync:Send("H:TEST")
			ns.Sync:Init()
			local cv = ns:GetCVarSafe("nameplateShowEnemies")
			ns:SetCVarSafe("nameplateShowEnemies", "1")
			local ta = ns.ThreatAccess._GetCV("threatWarning")
			ns.ThreatAccess._SetCV("threatWarning", "3")
			return S(sent) .. " " .. S(cv) .. " " .. S(ta)
		end)
		ns.db.sync, ns.simSecret = save[1], save[2]
		if not ok then return false, Clean(res), "kein Lua-Fehler" end
		local mode = ns.compat.sync and ns.compat.sync.mode
		return res == "false nil nil" and mode == "fallback" and ns.errorCount == before,
			"Senden/CVar/CVar: " .. res .. ", Sync " .. S(mode), "false nil nil, Sync fallback, kein Fehler"
	end)
	C("T107", "C", "Bedrohungs-Funktionen fehlen", function()
		local TA = ns.ThreatAccess
		local save = { ns.isModern, ns.threatAccess, TA.checked, TA.announced, ns.groupUnits }
		Swap(ns.Alerts, "Center", function() end)
		ns.isModern, ns.threatAccess, TA.checked, TA.announced = true, "unknown", false, false
		ns.groupUnits = { "player" }
		local before = ns.errorCount
		local f, sec, miss, acc, mode = WithAPI({ UnitDetailedThreatSituation = NIL, UnitThreatSituation = NIL, UnitAffectingCombat = Ret(true) }, function()
			local a, b, c = TA:Read("target")
			TA:Probe({ "target" })
			ns.Threat._ReadThreat("tsfake1")
			return a, b, c, ns.threatAccess, ns:ThreatMode()
		end)
		UnswapAll()
		ns.isModern, ns.threatAccess, TA.checked, TA.announced, ns.groupUnits = save[1], save[2], save[3], save[4], save[5]
		return miss == true and acc == "none" and mode == "OFF" and ns.errorCount == before,
			string.format("fehlt %s, %s, %s", S(miss), S(acc), S(mode)), "fehlt true, none, OFF – kein Fehler"
	end)
	C("T108", "C", "Rollen-, Gestalt- und Spezialisierungs-Funktionen fehlen", function()
		local before = ns.errorCount
		local ok, err = WithAPI({ GetSpecialization = NIL, GetSpecializationInfo = NIL, GetSpecializationRole = NIL,
			GetShapeshiftFormID = NIL, UnitGroupRolesAssigned = NIL, GetPartyAssignment = NIL, GetRaidTargetIndex = NIL,
			UnitHealthPercent = NIL }, function()
			return pcall(function()
				ns:FormName(); ns:SpecName()
				if ns.ClearRoleCache then ns:ClearRoleCache() end
				ns:GetRole("player")
				if ns.ClearRoleCache then ns:ClearRoleCache() end
			end)
		end)
		return ok and ns.errorCount == before, ok and "kein Fehler" or Clean(err), "kein Lua-Fehler"
	end)
	CL("T109", "C", "Keine geschützten Aktionen im Kampf", "Im Kampf: Einstellungen öffnen (Hinweis 'nicht im Kampf'), /ts move (verweigert); danach /ts test > Bericht: Blocked: none")
	CL("T110", "C", "Plaketten im Kampf in ANZEIGE/AUS", "Forever, Modus ANZEIGE: Pull mit 3+ Mobs – nichts leuchtet, Plaketten unverändert; nach dem Kampf wieder normal")
end

------------------------------------------------------------
-- D. Alte Clients
------------------------------------------------------------
Area.D = function()
	if ns.isModern then
		for _, id in ipairs({ "T112", "T113", "T114", "T115", "T116" }) do K(id, "D", "Alter Client", "nur Classic Era / TBC") end
		K("T117", "D", "Gegenprobe im echten Spiel", "nur Classic Era / TBC")
		return
	end
	C("T112", "D", "Bedrohung offen, Modus immer VOLL", function()
		local save = ns.db.threatMode
		ns.db.threatMode = "DISPLAY"
		local m = ns:ThreatMode()
		ns.db.threatMode = save
		return ns.threatAccess == "open" and ns.ThreatAccess.checked == true and m == "FULL", S(ns.threatAccess) .. "/" .. m, "open/FULL"
	end)
	C("T113", "D", "Ersatz über das Ziel des Mobs", function()
		local save = ns.groupUnits
		ns.groupUnits = { "player" }
		local tank, _, _, _, via = WithAPI({ UnitDetailedThreatSituation = Ret(nil), UnitThreatSituation = Ret(nil),
			UnitAffectingCombat = Ret(true), UnitExists = Ret(true),
			UnitIsUnit = function(a, b) return a == "player" and b == "tsfake1target" end }, function()
			return ns.Threat._ReadThreat("tsfake1")
		end)
		ns.groupUnits = save
		return tank == "player" and via == "fallback", S(tank) .. "/" .. S(via), "player/fallback"
	end)
	C("T114", "D", "Auren über UnitBuff/UnitDebuff", function()
		local function old(_, i) if i == 1 then return "TSAura", nil, 3, nil, nil, nil, nil, nil, nil, 71 end end
		local a = WithAPI({ UnitBuff = old, UnitDebuff = old, C_UnitAuras = NIL }, function()
			local n, c, id = ns.Aura("player", 1, "HELPFUL"); return S(n) .. "/" .. S(c) .. "/" .. S(id)
		end)
		return a == "TSAura/3/71", a, "TSAura/3/71"
	end)
	C("T115", "D", "Sync im Kampf nicht gesperrt", function()
		local save = { ns.db.sync, ns.simSecret }
		ns.db.sync, ns.simSecret = true, nil
		local r = WithAPI({ InCombatLockdown = Ret(true), IsInGroup = Ret(true), IsInRaid = Ret(false) }, function()
			return ns.Sync:Send("H:TEST")
		end)
		ns.db.sync, ns.simSecret = save[1], save[2]
		return r ~= false, "Senden " .. S(r) .. " (nur mitgeschrieben)", "nicht gesperrt"
	end)
	C("T116", "D", "Spott je Client", function()
		if ns.class ~= "PALADIN" then return true, "Klasse " .. S(ns.class) .. " (nur Paladin prüfbar)" end
		local G = GoldSentinelGame
		if G.IsEra then return ns.tauntSpell == nil, S(ns.tauntMode), "Era: kein Spott" end
		return ns.tauntMode == nil or ns.tauntMode == "friendly", S(ns.tauntMode), "TBC: friendly (wenn gelernt)"
	end)
	CL("T117", "D", "Gegenprobe im echten Spiel", "/ts guide mit Pet oder in der Gruppe: lose Mobs leuchten, gehaltene ausgeblendet, Ton bei Aggroverlust; Kampflog: Schadensmeter zählt, widerstandener Spott wird gemeldet, kein 'Addon geblockt'")
end

------------------------------------------------------------
-- E. Daten
------------------------------------------------------------
Area.E = function()
	C("T118", "E", "Neuinstallation", function()
		local keep = ThreatSentinelDB
		ThreatSentinelDB = nil
		local ok, err = pcall(function()
			ns:InitDB()
			local DB = ThreatSentinelDB
			local p = DB.profiles[DB.chars[ns.charKey]]
			if type(p) ~= "table" or p.schema ~= 9 then error("Profil/Schema " .. S(p and p.schema)) end
			for k, v in pairs(ns.defaults) do
				if type(v) ~= "table" and p[k] ~= v then error("Standard " .. k) end
			end
			local lines = Capture(function() ns.ThreatAccess:Report() end)
			if not Has(lines, L.TA_R_NEVER) then error("TA_R_NEVER fehlt") end
		end)
		ThreatSentinelDB = keep
		ns:InitDB()
		if not ok then return false, Clean(err), "Profil mit Standardwerten, Schema 9" end
		return true
	end)
	C("T119", "E", "Migration aus Schema 1", function()
		local db = { heldPlateAlpha = 0, chatChannel = "GROUP", soundHealer = "raidwarning", soundDD = "alarm", soundRegain = "click",
			soundResist = "readycheck", hudPoint = { "CENTER", "UIParent", "CENTER", 320, -120 }, meterPoint = { "CENTER", "UIParent", "CENTER", 320, 60 },
			hudScale = 1.3, hudLocked = false, soundEmergency = "ts_emergency", soundDDWarn = "ts_warn", regainSound = true,
			colorWarn = { 1, 0.9, 0 }, colorDD = { 1, 0.55, 0 }, looseScale = 1.25, borderSize = 3 }
		ns._MergeDefaults(db, ns.defaults)
		ns:Migrate(db)
		local d = ns.defaults
		local checks = {
			{ "heldPlateAlpha", db.heldPlateAlpha == 0.35 }, { "chatChannel", db.chatChannel == "TANKS" },
			{ "soundHealer", db.soundHealer == "fx_engel" }, { "soundDD", db.soundDD == "fx_frosch" },
			{ "soundRegain", db.soundRegain == d.soundRegain }, { "soundResist", db.soundResist == "none" or db.soundResist == d.soundResist },
			{ "hudPoint", Diff(db.hudPoint, d.hudPoint, "") == nil }, { "meterPoint", Diff(db.meterPoint, d.meterPoint, "") == nil },
			{ "meterScale", db.meterScale == 1.3 and db.ddScale == 1.3 }, { "hudLocked", db.hudLocked == true },
			{ "soundDDWarn", db.soundDDWarn == "none" }, { "soundEmergency", db.soundEmergency == "none" }, { "regainSound", db.regainSound == false },
			{ "colorWarn", db.colorWarn[1] == 1 and db.colorWarn[2] == 0.5 and db.colorWarn[3] == 0 },
			{ "colorDD", db.colorDD[1] == 1 and db.colorDD[2] == 0.1 and db.colorDD[3] == 0.1 },
			{ "looseScale", db.looseScale == 1.4 }, { "borderSize", db.borderSize == 4 }, { "schema", db.schema == 9 },
		}
		for _, c in ipairs(checks) do if not c[2] then return false, c[1] .. " = " .. S(db[c[1]]), "migriert" end end
		return true
	end)
	C("T120", "E", "Migration aus Schema 5 und 9", function()
		local db5 = { schema = 5, soundHealer = "ts_healer", soundDD = "ts_dd" }
		ns._MergeDefaults(db5, ns.defaults); ns:Migrate(db5)
		local db9 = { schema = 9, soundHealer = "quest", colorDD = { 0, 0, 1, 1 } }
		ns._MergeDefaults(db9, ns.defaults); ns:Migrate(db9)
		local ok = db5.soundHealer == "fx_engel" and db5.soundDD == "fx_frosch" and db9.soundHealer == "quest" and db9.colorDD[3] == 1
		return ok, S(db5.soundHealer) .. "/" .. S(db5.soundDD) .. "/" .. S(db9.soundHealer), "fx_engel/fx_frosch/quest"
	end)
	C("T121", "E", "Alte gespeicherte Bedrohungs-Erkennung", function()
		for _, v in ipairs({ false, { state = "none" }, { state = "secret", date = nil } }) do
			ThreatSentinelDB.threatAccess = v or nil
			ns.ThreatAccess:Login()
			Capture(function() ns.ThreatAccess:Report() end)
		end
		return true
	end)
	K("T122", "E", "Beschädigte Einträge", "nicht automatisch: InitDB mit falschen Typen würde Login-Teile der Module auf echten Rahmen auslösen; Typprüfung in Migrate ist ein eigener Auftrag")
end

------------------------------------------------------------
-- F. Sprachen
------------------------------------------------------------
local function Placeholders(s)
	local out = {}
	for p in tostring(s):gmatch("%%[%-%d%.]*[%a%%]") do out[#out + 1] = p end
	return table.concat(out, " ")
end

Area.F = function()
	local LOC = ns.LOCALES
	C("T123", "F", "Gleiche Schlüssel in en und de", function()
		local n, miss = 0, nil
		for k in pairs(LOC.enUS) do n = n + 1; if LOC.deDE[k] == nil then miss = "de fehlt " .. k end end
		for k in pairs(LOC.deDE) do if LOC.enUS[k] == nil then miss = "en fehlt " .. k end end
		return miss == nil, miss or (n .. " Schlüssel"), "gleich"
	end)
	C("T124", "F", "Zusammengesetzte Schlüssel vorhanden", function()
		local keys = { "TA_MODE_FULL", "TA_MODE_DISPLAY", "TA_MODE_OFF", "PRESET_quiet", "PRESET_standard", "PRESET_loud", "TANK", "HEALER", "DAMAGER", "PET" }
		for _, c in ipairs({ "TANKS", "BOSS", "GROUP", "SELF", "OFF" }) do keys[#keys + 1] = "CH_" .. c end
		for _, f in ipairs(ns.COMPAT_ORDER) do
			for _, p in ipairs({ "CP_", "CPF_", "CPO_", "CPH_" }) do keys[#keys + 1] = p .. f end
		end
		for _, s in ipairs({ "unknown", "open", "secret", "none" }) do keys[#keys + 1] = "TA_STATE_" .. s end
		for _, s in ipairs({ "real", "open", "secret", "none" }) do keys[#keys + 1] = "TEST_ACC_" .. s end
		for _, k in ipairs(keys) do
			if rawget(LOC.enUS, k) == nil or rawget(LOC.deDE, k) == nil then return false, k, "in en und de" end
		end
		return true, #keys .. " Schlüssel"
	end)
	C("T125", "F", "Formatplatzhalter gleich", function()
		for k, v in pairs(LOC.enUS) do
			local d = LOC.deDE[k]
			if type(v) == "string" and type(d) == "string" and Placeholders(v) ~= Placeholders(d) then
				return false, k .. ": " .. Placeholders(v) .. " / " .. Placeholders(d), "gleich"
			end
		end
		return true
	end)
	K("T126", "F", "Im Code benutzte Schlüssel", "vor dem Push per Skript geprüft (manuell)")
	C("T127", "F", "Aktive Sprache: Hauptfenster", function()
		local O, TM = ns.Options, ns.Test
		if not O.frame then O:Build() end
		local w = O.frame:IsShown()
		O.frame:Show(); for i = 1, 8 do O:Select(i) end
		if not w then O.frame:Hide() end
		if not TM.frame then TM:Build() end
		TM:ReportText()
		return true, GetLocale()
	end)
	K("T128", "F", "Andere Sprache aktivieren", "Sprachumschaltung (devLocale) ist noch nicht eingebaut")
	C("T129", "F", "Gemeinsame Dateien liefern Text", function()
		local G = GoldSentinelGame
		local ok = type(G.Status()) == "string"
		return ok, "Status", "Text"
	end)
end

------------------------------------------------------------
-- G. Zusammenspiel
------------------------------------------------------------
local OWN_FRAMES = { "ThreatSentinelCenter", "ThreatSentinelDD", "ThreatSentinelDmgMeter", "ThreatSentinelGuide", "ThreatSentinelHUD",
	"ThreatSentinelSummary", "ThreatSentinelMeter", "ThreatSentinelMoveBar", "ThreatSentinelSoundPicker", "ThreatSentinelOptions",
	"ThreatSentinelMinimapButton", "ThreatSentinelTauntButton", "ThreatSentinelAoeButton", "ThreatSentinelPreview", "ThreatSentinelReport",
	"ThreatSentinelTest" }

Area.G = function()
	C("T130", "G", "Globale Namen gehören ThreatSentinel", function()
		local map = { ThreatSentinelCenter = ns.Alerts.center, ThreatSentinelHUD = ns.HUD.f, ThreatSentinelMeter = ns.Meter.f,
			ThreatSentinelDD = ns.DD.f, ThreatSentinelDmgMeter = ns.DmgMeter.f, ThreatSentinelOptions = ns.Options.frame,
			ThreatSentinelTest = ns.Test.frame, ThreatSentinelReport = ns.Test.report }
		for name, obj in pairs(map) do
			if obj and _G[name] ~= obj then return false, name, "eigenes Objekt" end
		end
		return type(ThreatSentinelDB) == "table" and BINDING_HEADER_THREATSENTINEL ~= nil, "ok"
	end)
	C("T131", "G", "Keine neuen Globals durch die Routine", function()
		local before = R.globalsBefore
		if not before then return true, "keine Vorher-Liste" end
		local new = {}
		for k, v in pairs(_G) do
			local own = type(k) == "string" and (k:match("^ThreatSentinel") or k:match("^GoldSentinel"))
			-- Das Spiel legt manche Blizzard-Funktionen/-Tabellen erst beim ersten Zugriff an (gross geschrieben,
			-- Funktion oder Tabelle) - das ist kein Leck. Ein Leck aus eigenem Code ist klein geschrieben
			-- oder ein einfacher Wert.
			local lazyBlizz = type(k) == "string" and k:match("^[A-Z_]") and (type(v) == "function" or type(v) == "table" or type(v) == "userdata")
			if not before[k] and not own and not lazyBlizz then
				new[#new + 1] = tostring(k)
				if #new >= 5 then break end
			end
		end
		return #new == 0, #new == 0 and "keine" or table.concat(new, ", "), "keine (ausser eigenen Fenstern ThreatSentinel*)"
	end)
	C("T132", "G", "Gemeinsame GoldSentinelGame-Fassung", function()
		local G = _G.GoldSentinelGame
		return type(G) == "table" and (G.version or 0) >= 2 and ns.Game == G, "Version " .. S(G and G.version), ">= 2"
	end)
	C("T133", "G", "Slash- und Prefix-Kollisionen", function()
		for k, v in pairs(_G) do
			if type(k) == "string" and k:match("^SLASH_") and v == "/ts" and not k:match("^SLASH_THREATSENTINEL%d") then
				return false, k, "/ts nur ThreatSentinel"
			end
		end
		if C_ChatInfo and C_ChatInfo.IsAddonMessagePrefixRegistered then
			local ok, r = pcall(C_ChatInfo.IsAddonMessagePrefixRegistered, ns.Sync.PREFIX)
			if ok and r == false then return false, "Prefix nicht angemeldet", "angemeldet" end
		end
		return true
	end)
	K("T134", "G", "Schnittstellen zu den anderen Addons", "keine Schnittstelle")
	CL("T135", "G", "Mehrere GoldSentinel-Addons gleichzeitig", "Mit RaidMaster, GuildSentinel, BuffSentinel, ProfessionSentinel laden, /reload, /gsgame: eine Zeile, Version 2; /ts testroutine g")
end

------------------------------------------------------------
-- H. Leistung
------------------------------------------------------------
local function Time(n, fn)
	local t = Ms()
	for _ = 1, n do fn() end
	return (Ms() - t) / n
end

Area.H = function()
	C("T136", "H", "T:Tick mit 10 und 40 Testmobs (Modus VOLL)", function()
		local res, worst = {}, nil
		for _, n in ipairs({ 10, 40 }) do
			local sc = Scene.New(n)
			for i = 1, n, 3 do Scene.Hold(sc, "tsfake" .. i, "party1", {}) end   -- jeder dritte lose
			local v = Scene.Run(sc, function()
				ns.simAccess = "open"
				ns.Threat:Tick()
				return Time(20, function() ns.Threat:Tick() end)
			end)
			local limit = n == 10 and 2 or 8
			res[#res + 1] = string.format("%d Mobs %.2f ms", n, v)
			if v > limit then worst = n end
		end
		return worst == nil, table.concat(res, ", "), "10 Mobs < 2 ms, 40 Mobs < 8 ms"
	end)
	C("T137", "H", "Anzeigen (echter Zustand, je 50x)", function()
		local parts = {}
		local worst
		local function m(name, fn, limit)
			local v = Time(50, fn)
			parts[#parts + 1] = string.format("%s %.2f", name, v)
			if v > limit then worst = name end
		end
		m("Meter", function() ns.Meter:Tick() end, 1)
		m("DD", function() ns.DD:Tick() end, 0.5)
		m("HUD", function() ns.HUD:Update({}, {}) end, 0.5)
		m("DmgMeter", function() ns.DmgMeter:Tick() end, 1)
		m("CheckCC", function() ns.Alerts:CheckCC() end, 0.1)
		m("Specs", function() ns.Specs:Step() end, 1)
		return worst == nil, table.concat(parts, ", ") .. " ms", "unter den Grenzen"
	end)
	C("T138", "H", "Bildweise OnUpdate (Flammen, Testzentrale, Meldung)", function()
		local sc = Scene.New(0)
		return Scene.Run(sc, function()
			local P, db = ns.Plates, ns.db
			ns.Test:CreatePreview()
			local ufs = {}
			for _, uf in ipairs(ns.Test.preview.plates) do ufs[#ufs + 1] = uf end
			R.extraPlates = R.extraPlates or {}
			while #ufs + #R.extraPlates < 10 do
				local uf = CreateFrame("Frame", nil, ns.Test.preview.holder)
				uf:SetSize(120, 34)
				local hb = CreateFrame("StatusBar", nil, uf)
				hb:SetSize(110, 10)
				hb:SetPoint("BOTTOM", uf, "BOTTOM", 0, 4)
				uf.healthBar = hb
				R.extraPlates[#R.extraPlates + 1] = uf
			end
			for _, uf in ipairs(R.extraPlates) do if #ufs < 10 then ufs[#ufs + 1] = uf end end
			local saveFire = db.looseFire
			db.looseFire = true
			for _, uf in ipairs(ufs) do P:Apply(uf, { state = "LOOSE", victim = "Torben", victimRole = "DAMAGER" }) end
			local fire = P._fireDriver:GetScript("OnUpdate")
			local t1 = Time(50, function() fire(P._fireDriver, 0.1) end)
			local tf = ns.Test.frame
			local tm = tf and tf:GetScript("OnUpdate")
			local t2 = tm and Time(10, function() tm(tf, 1) end) or 0
			local cf = ns.Alerts.center
			local co = cf and cf:GetScript("OnUpdate")
			local saveExp, wasShown = cf and cf.expire, cf and cf:IsShown()
			local t3 = co and Time(50, function() cf.expire = GetTime() + 10; co(cf) end) or 0
			if cf then cf.expire = saveExp; if wasShown then cf:Show() else cf:Hide() end end
			db.looseFire = saveFire
			for _, uf in ipairs(R.extraPlates) do P:RestoreFrame(uf) end
			local got = string.format("Flammen (%d Plaketten) %.3f ms, Testzentrale %.2f ms, Meldung %.3f ms", #ufs, t1, t2, t3)
			return t1 < 0.5 and t2 < 2 and t3 < 0.05, got, "< 0.5 / < 2 / < 0.05 ms"
		end)
	end)
	C("T139", "H", "Protokoll-Auswertung", function()
		local v = Time(5, function() ns.Log:Analyze() end)
		return v < 16, string.format("%.2f ms", v), "< 16 ms"
	end)
	C("T140", "H", "Speicher bei T:Tick", function()
		collectgarbage("collect")
		local before = collectgarbage("count")
		for _ = 1, 200 do ns.Threat:Tick() end
		collectgarbage("collect")
		local grow = collectgarbage("count") - before
		return grow < 100, string.format("%.0f KB", grow), "< 100 KB"
	end)
end

------------------------------------------------------------
-- I. Fehlerzählung und Diagnose
------------------------------------------------------------
Area.I = function()
	C("T141", "I", "Absichtlicher Fehler wird gezählt", function()
		local n, last = ns.errorCount, ns.lastError
		ns.routineSelfTest = true
		ns:ReportError("TS-Selbsttest")
		ns.routineSelfTest = nil
		local ok = ns.errorCount == n + 1 and ns.lastError == "TS-Selbsttest"
		local lines = Capture(function() ns.ThreatAccess:Report() end)
		local rep = Has(lines, string.format(L.TA_R_ERRORS, ns.errorCount))
		ns.errorCount, ns.lastError = n, last
		return ok and rep, S(ok) .. "/" .. S(rep), "gezählt und angezeigt"
	end)
	C("T142", "I", "Fehler in einem Teil hält den Durchlauf nicht an", function()
		local n = ns.errorCount
		local meter = 0
		local realMeter = ns.Meter.Tick
		Swap(ns.DD, "Tick", function() error("TS-Selbsttest DD") end)
		Swap(ns.Meter, "Tick", function(...) meter = meter + 1; return realMeter(...) end)
		ns.routineSelfTest = true
		local active = ns:IsActive()
		ns.Threat:Tick()
		ns.routineSelfTest = nil
		UnswapAll()
		local diff = ns.errorCount - n
		ns.errorCount = n
		return diff >= 1 and meter >= 1, "Fehler +" .. diff .. ", Meter " .. meter .. "x (aktiv " .. S(active) .. ")", "Fehler gezählt, Meter läuft"
	end)
	C("T143", "I", "Fehler in einem Ereignis-Handler", function()
		local n = ns.errorCount
		local ran = false
		local bad = function() error("TS-Selbsttest Handler") end
		local good = function() ran = true end
		ns:On("PLAYER_ALIVE", bad); ns:On("PLAYER_ALIVE", good)
		ns.routineSelfTest = true
		ns:Fire("PLAYER_ALIVE")
		ns.routineSelfTest = nil
		ns:Off("PLAYER_ALIVE", bad); ns:Off("PLAYER_ALIVE", good)
		local diff = ns.errorCount - n
		ns.errorCount = n
		return diff == 1 and ran, "Fehler +" .. diff .. ", übrige " .. S(ran), "+1, übrige laufen"
	end)
	C("T144", "I", "Hinweis einmal pro Sitzung", function()
		if not ns.isModern then return true, "alte API: kein Hinweis" end
		local n, last, noticed = ns.errorCount, ns.lastError, ns.errorNoticed
		ns.errorNoticed = nil
		ns.routineRunning = false   -- IsTesting aus, damit der Hinweis käme (Ausgabe abgefangen)
		ns.routineSelfTest = true
		local lines = Capture(function() ns:ReportError("TS-Selbsttest 1"); ns:ReportError("TS-Selbsttest 2") end)
		ns.routineSelfTest = nil
		ns.routineRunning = true
		local c = 0
		for _, l in ipairs(lines) do if l:find(L.ERR_NOTICE, 1, true) then c = c + 1 end end
		ns.errorCount, ns.lastError, ns.errorNoticed = n, last, noticed
		return c == 1, c .. "x", "1x"
	end)
	C("T145", "I", "Gesperrte Aktion wird gezählt", function()
		local n, nb = ns.errorCount, #ns.blocked
		ns.routineSelfTest = true
		ns:Fire("ADDON_ACTION_BLOCKED", ADDON, "TestFunc")
		ns:Fire("ADDON_ACTION_BLOCKED", "FremdesAddon", "TestFunc")
		ns.routineSelfTest = nil
		local ok = #ns.blocked == nb + 1 and ns.errorCount == n + 1
		local added = #ns.blocked - nb
		while #ns.blocked > nb do table.remove(ns.blocked) end
		ns.errorCount = n
		return ok, "blocked +" .. added, "+1 (fremdes Addon nichts)"
	end)
	C("T146", "I", "Fehlerschritt im Testassistenten", function()
		local step
		for _, s in ipairs(ns.Guide.STEPS) do if s.id == "errors" then step = s end end
		if not step then return false, "Schritt fehlt", "errors" end
		return true, "vorhanden"
	end)
	C("T187", "I", "Diagnose-Protokoll: Einträge, Zähler statt Schleife, Export GSDIAG1, keine Namen", function()
		if not (ns.Diag and ns.DiagText and ns.DiagExport) then return false, "Diag.lua fehlt", "ns.Diag/DiagText/DiagExport" end
		local root = ThreatSentinelDB
		local saved = root.diag and Copy(root.diag) or nil
		ns.diagForce = true
		local ok, err = pcall(function()
			root.diag = nil
			ns.Diag("MODUS", "VOLL -> ANZEIGE", 12.4)
			for _ = 1, 50 do ns.Diag("FEHLER", "TS-Diagnosetest gleicher Fehler") end
			WithAPI({}, function() ns.Diag("SECRET", SECRET) end)   -- WithAPI setzt den Köderwert ns.testBait
		end)
		local d = root.diag or { entries = {} }
		local n, first = #d.entries, d.entries[2]
		local text, exp = ns.DiagText(), ns.DiagExport()
		ns.diagForce = nil
		root.diag = saved
		if not ok then error(err, 0) end
		local count = first and first.k == "FEHLER" and first.n or 0
		local hasName = type(ns.playerName) == "string" and ns.playerName ~= "" and text:find(ns.playerName, 1, true) ~= nil
		local secretOk = d.entries[1] and d.entries[1].t == "<geschützt>"
		local good = n == 3 and count == 50 and exp:sub(1, 22) == "GSDIAG1|ThreatSentinel" and not hasName and secretOk
			and text:find("VOLL -> ANZEIGE", 1, true) ~= nil
		return good, string.format("%d Einträge, Fehler ×%d, Export %s, Name im Text %s, geschützt %s", n, count,
			S(exp:sub(1, 22)), S(hasName), S(secretOk)), "3 Einträge, ×50, GSDIAG1|ThreatSentinel, false, true"
	end)
	C("T189", "I", "Diagnose-Protokoll schreibt nicht während der Testroutine", function()
		local before = ThreatSentinelDB.diag and ThreatSentinelDB.diag.entries and #ThreatSentinelDB.diag.entries or 0
		local first = ThreatSentinelDB.diag and ThreatSentinelDB.diag.entries and ThreatSentinelDB.diag.entries[1]
		ns.Diag("TEST", "TS-darf nicht erscheinen")
		local after = ThreatSentinelDB.diag and ThreatSentinelDB.diag.entries and #ThreatSentinelDB.diag.entries or 0
		local same = (ThreatSentinelDB.diag and ThreatSentinelDB.diag.entries and ThreatSentinelDB.diag.entries[1]) == first
		return after == before and same, before .. " -> " .. after, "unverändert"
	end)
	CL("T188", "I", "Diagnose-Protokoll im Spiel", "/ts protokoll öffnet ein Fenster mit markierbarem Text; nach /reload liegt ThreatSentinelDB.diagExport (beginnt mit GSDIAG1) in den SavedVariables und geht mit dem Uploader nach #testberichte")
	K("T147", "I", "Lua-Fehler ausserhalb von pcall", "würde einen echten Fehler im Fehlerfenster/BugSack des Spielers auslösen; GoldSentinelTest.TrackErrors ist angemeldet (siehe Core.lua)")
end

------------------------------------------------------------
-- J. Regressionstests
------------------------------------------------------------
Area.J = function()
	local TA = ns.ThreatAccess
	CL("T148", "J", "Kein Ersatz über das Ziel des Mobs (modern)", "Forever: Mob ohne Bedrohungsdaten bleibt IDLE (Diagnose 'Bedrohung am Ziel'), kein Leuchten")
	CL("T149", "J", "Kein stilles IDLE bei geschützten Werten", "Forever, erster Kampf: /ts bedrohung zeigt 'geschützt', Hinweis 1x")
	C("T150", "J", "Geschützte Namen nie als Schlüssel", function()
		local save = { ns.groupUnits, ns.groupNames, ns.nameToUnit }
		WithAPI({ IsInRaid = Ret(false), GetNumSubgroupMembers = Ret(1), UnitIsPlayer = Ret(true),
			UnitExists = function(u) return u == "party1" end,
			UnitName = function(u) if u == "party1" then return "Torben", SECRET end return SECRET, "" end }, function()
			ns:UpdateGroup()
		end)
		local keys = 0
		for k in pairs(ns.groupNames) do keys = keys + 1 end
		local units = #ns.groupUnits
		ns.groupUnits, ns.groupNames, ns.nameToUnit = save[1], save[2], save[3]
		return keys == 0 and units == 2, units .. " Einheiten, " .. keys .. " Namen", "2 Einheiten, 0 Namen"
	end)
	C("T151", "J", "Textfunktionen ohne geschützte Werte", function()
		ns.testBait = SECRET
		local i = ns.Plates._Initial(SECRET)
		ns.testBait = nil
		return i == "", "Initial '" .. i .. "'", "''"
	end)
	C("T152", "J", "Leere Aurenliste im Kampf = unbekannt", function()
		local save = ns.isModern
		ns.isModern = true
		local empty = { GetAuraDataByIndex = function() return nil end }
		local r1 = WithAPI({ UnitBuff = NIL, UnitDebuff = NIL, C_UnitAuras = empty, UnitAffectingCombat = Ret(true) }, function()
			local a, b = ns:FindAura("player", "HELPFUL", { [71] = true }); return S(ns.AuraEmptyUnknown()) .. " " .. S(a) .. "," .. S(b)
		end)
		local r2 = WithAPI({ UnitBuff = NIL, UnitDebuff = NIL, C_UnitAuras = empty, UnitAffectingCombat = Ret(false) }, function()
			local a, b = ns:FindAura("player", "HELPFUL", { [71] = true }); return S(ns.AuraEmptyUnknown()) .. " " .. S(a) .. "," .. S(b)
		end)
		ns.isModern = save
		return r1 == "true false,false" and r2 == "false false,true", r1 .. " | " .. r2, "im Kampf unbekannt | ausserhalb keine Aura"
	end)
	C("T153", "J", "Blizzard-Plaketten im Kampf nicht anfassen (ANZEIGE, verbotene Plakette)", function()
		local sc = Scene.New(2)
		Scene.Hold(sc, "tsfake1", "party1")
		Scene.Hold(sc, "tsfake2", "party1")
		sc.forbidden.tsfake2 = true
		return Scene.Run(sc, function()
			local P, T = ns.Plates, ns.Threat
			local uf1, uf2 = sc.plates.tsfake1, sc.plates.tsfake2
			local applied = {}
			local orig = P.Apply
			Swap(P, "Apply", function(self, uf, m) applied[uf] = (applied[uf] or 0) + 1; return orig(self, uf, m) end)
			ns.simAccess = "open"
			T:Tick()
			local fullForbidden = applied[uf2] or 0
			local fullOther = applied[uf1] or 0
			wipe(applied)
			ns.simAccess = "secret"
			T:Tick(); T:Tick()
			local disp = 0
			for _, n in pairs(applied) do disp = disp + n end
			local got = string.format("VOLL: normale %d, verbotene %d; ANZEIGE: %d", fullOther, fullForbidden, disp)
			-- uf1 und uf2 können dieselbe Vorschau-Plakette sein: dann zählt nur "verbotene 0" über GetUF
			return fullOther >= 1 and (uf1 == uf2 or fullForbidden == 0) and disp == 0 and P._GetUF("tsfake2") == nil, got, "VOLL: normale >= 1, verbotene nie (GetUF nil); ANZEIGE: 0"
		end)
	end)
	CL("T154", "J", "Taint im Modus VOLL", "Pull mit 3+ Mobs im Modus VOLL, danach /ts test > Bericht: 'Blocked: none'; kein 'ThreatSentinel hat eine Aktion blockiert'")
	C("T155", "J", "Moderne API überall wie Retail", function()
		if not ns.isModern then return true, "alte API (nur F)" end
		local cls = ns.class
		ns.class = "DRUID"
		local t = ns:DeficitText()
		ns.class = cls
		return t == L.DEFICIT_OTHER, S(t), "DEFICIT_OTHER"
	end)
	C("T156", "J", "Sync-Kampfsperre (moderne API)", function()
		local save = { ns.db.sync, ns.isModern }
		ns.db.sync, ns.isModern = true, true
		local r = WithAPI({ InCombatLockdown = Ret(true), IsInGroup = Ret(true), IsInRaid = Ret(false) }, function()
			return ns.Sync:Send("H:TEST")
		end)
		local mode = ns.compat.sync and ns.compat.sync.mode
		ns.db.sync, ns.isModern = save[1], save[2]
		return r == false and mode == "fallback", S(r) .. " " .. S(mode), "false fallback"
	end)
	CL("T157", "J", "Erkennung einmal pro Kampf, Zustand gespeichert", "Forever: zwei Kämpfe hintereinander, danach /ts bedrohung: 'zuletzt erkannt' mit Datum und Build")
	C("T158", "J", "Bedrohung prüfen zeigt geschützte Werte nie", function()
		ns.testBait = SECRET
		local s = TA._Shown(SECRET)
		ns.testBait = nil
		local a, b = TA._Shown(86.25), TA._Shown(3)
		return s == L.TA_PROTECTED and (a == "86.2" or a == "86.3") and b == "3", S(s) .. "/" .. S(a) .. "/" .. S(b), "geschützt/86.2/3"
	end)
	C("T159", "J", "'Voll' nicht erzwingbar", function()
		local save = { ns.threatAccess, ns.db.threatMode, ns.simAccess }
		ns.threatAccess, ns.simAccess = "secret", nil
		local bad
		for _, m in ipairs({ "AUTO", "DISPLAY", "FULL" }) do
			ns.db.threatMode = m
			if ns:ThreatMode() ~= "DISPLAY" then bad = m end
		end
		ns.threatAccess, ns.db.threatMode, ns.simAccess = save[1], save[2], save[3]
		return bad == nil, bad or "ok", "immer DISPLAY"
	end)
	C("T160", "J", "Drei Zustände simulierbar (Knopftext)", function()
		local TM = ns.Test
		if not TM.frame then TM:Build() end
		local saveAcc = ns.threatAccess
		ns.threatAccess = "open"
		local texts = {}
		Capture(function()
			for _, st in ipairs({ "open", "secret", "none" }) do
				TM:SetAccessSim(st)
				texts[#texts + 1] = TM.accBtn:GetText()
			end
			TM:SetAccessSim(nil)
		end)
		ns.threatAccess = saveAcc
		if ns.Alerts.ClearCenter then ns.Alerts:ClearCenter("test") end
		return texts[1] == L.TEST_ACC_open and texts[2] == L.TEST_ACC_secret and texts[3] == L.TEST_ACC_none, table.concat(texts, "/"), "TEST_ACC_open/secret/none"
	end)
	C("T161", "J", "Fehlerzahl in der Diagnose (L.D_ERRORS)", function()
		local TM = ns.Test
		if not TM.frame then TM:Build() end
		local save = ns.errorCount
		ns.errorCount = 7
		local d = TM:DiagText()
		ns.errorCount = save
		return d:find(L.D_ERRORS, 1, true) ~= nil and d:find(L.D_ERRORS .. ":|r 7", 1, true) ~= nil, "Diagnose", L.D_ERRORS .. ": 7"
	end)
	C("T162", "J", "G.Status in Diagnose und Bericht", function()
		local st = GoldSentinelGame.Status()
		local TM = ns.Test
		if not TM.frame then TM:Build() end
		local d, r = TM:DiagText(), TM:ReportText()
		local lines = Capture(function() TA:Report() end)
		return d:find(st, 1, true) ~= nil and r:find(st, 1, true) ~= nil and Has(lines, st), "Diagnose/Bericht/Bedrohung", "enthalten G.Status()"
	end)
	C("T163", "J", "Kein InterfaceOptions_AddCategory/EasyMenu", function()
		-- Prüfung im Quelltext vor dem Push (Skript); hier nur: Optionen bauen ohne Fehler
		if not ns.Options.frame then ns.Options:Build() end
		return true, "Optionen gebaut"
	end)
	C("T164", "J", "'unknown' + Fehlschlag -> 'secret'", function()
		local save = { ns.isModern, ns.threatAccess, TA.checked, TA.announced, TA.wantBlizzard, ns.groupUnits, ThreatSentinelDB.threatAccess }
		Swap(ns.Alerts, "Center", function() end)
		Swap(TA, "ApplyBlizzard", function() end)
		ns.isModern, ns.threatAccess, TA.checked = true, "unknown", true
		ns.groupUnits = { "player" }
		WithAPI({ UnitDetailedThreatSituation = Ret(SECRET, SECRET, SECRET, SECRET, SECRET), UnitThreatSituation = Ret(SECRET),
			UnitAffectingCombat = Ret(true) }, function()
			ns.Threat._ReadThreat("tsfake1")
		end)
		local acc = ns.threatAccess
		UnswapAll()
		ns.isModern, ns.threatAccess, TA.checked, TA.announced, TA.wantBlizzard, ns.groupUnits = save[1], save[2], save[3], save[4], save[5], save[6]
		ThreatSentinelDB.threatAccess = save[7]
		return acc == "secret", S(acc), "secret"
	end)
	C("T165", "J", "MAX_ATTEMPTS-Konstante und neuer Kampf", function()
		if not ns.isModern then return true, "alte API (nur F R)" end
		ns.threatAccess, TA.tempNone = "none", true
		ns:Fire("PLAYER_REGEN_DISABLED")
		return TA.MAX_ATTEMPTS == 40 and ns.threatAccess == "unknown", S(TA.MAX_ATTEMPTS) .. "/" .. S(ns.threatAccess), "40/unknown"
	end)
	C("T166", "J", "'unknown' ausserhalb des Kampfs = VOLL", function()
		local save = { ns.threatAccess, ns.simAccess, ns.db.threatMode }
		ns.threatAccess, ns.simAccess, ns.db.threatMode = "unknown", nil, "AUTO"
		local m = ns:ThreatMode()
		ns.threatAccess, ns.simAccess, ns.db.threatMode = save[1], save[2], save[3]
		return m == "FULL", m, "FULL (im Kampf DISPLAY: im Client prüfen)"
	end)
	C("T166b", "J", "'unknown' im Kampf ergibt ANZEIGE (nur modern)", function()
		local save = { ns.threatAccess, ns.simAccess, ns.db.threatMode, ns.isModern }
		ns.threatAccess, ns.simAccess, ns.db.threatMode = "unknown", nil, "AUTO"
		local r = {}
		WithAPI({ UnitAffectingCombat = Ret(true) }, function()
			ns.isModern = true; r[1] = ns:ThreatMode()
			ns.isModern = false; r[2] = ns:ThreatMode()
		end)
		ns.threatAccess, ns.simAccess, ns.db.threatMode, ns.isModern = save[1], save[2], save[3], save[4]
		return r[1] == "DISPLAY" and r[2] == "FULL", "modern " .. r[1] .. ", alt " .. r[2], "modern DISPLAY, alt FULL"
	end)
	C("T167", "J", "Aggrometer sortiert im Modus ANZEIGE nicht", function()
		local save = { ns.groupUnits, ns.simAccess }
		ns.groupUnits = { "party1", "player", "party2" }
		ns.simAccess = "secret"
		local st = { party1 = 0, player = 3, party2 = 1 }
		local nm = { party1 = "Torben", player = "Anna", party2 = "Grimbar" }
		Swap(ns, "GetRole", function(_, u) return u == "party2" and "TANK" or "DAMAGER" end)
		local list = WithAPI({ UnitDetailedThreatSituation = function(u) return u == "party2", st[u], 50, 5000 end,
			UnitName = function(u) return nm[u] end, UnitIsPlayer = Ret(true), UnitClass = Ret("Krieger", "WARRIOR") }, function()
			return ns.Meter:Collect()
		end)
		UnswapAll()
		ns.groupUnits, ns.simAccess = save[1], save[2]
		local order = {}
		for i, e in ipairs(list or {}) do order[i] = Clean(e.name) end
		local got = table.concat(order, ",")
		local ok = #order == 3 and list[1].name == "Grimbar" and list[2].name == "Torben" and list[3].name == "Anna"
		return ok, got, "Tank, dann Gruppe (nicht nach Status)"
	end)
	C("T168", "J", "Kein Vorsprung-Text im Modus ANZEIGE", function()
		local M = ns.Meter
		if not M.f then return false, "kein Aggrometer", "Rahmen" end
		local shown = M.f:IsShown()
		local saveSim = ns.simAccess
		ns.simAccess = "secret"
		M:Render({ { name = "Torben", class = "WARRIOR", pull = 100, tanking = true, isTank = true, status = 2, me = true },
			{ name = "Anna", class = "PRIEST", pull = 50 } }, "Test", true)
		local lead = M.f.lead:GetText()
		local r, g, b = M.f.rows[1]:GetStatusBarColor()
		r, g, b = Num(r), Num(g), Num(b)
		ns.simAccess = saveSim
		if not shown then M.f:Hide() end
		local neutral = Near(r, 0.45, 0.02) and Near(g, 0.6, 0.02) and Near(b, 0.85, 0.02)
		return (lead == nil or lead == "") and neutral, "Vorsprung '" .. S(lead) .. "', Farbe " .. string.format("%.2f,%.2f,%.2f", r, g, b), "leer, neutral"
	end)
	C("T169", "J", "Neutrale Balkenfarbe der DD-Ansicht im Modus ANZEIGE", function()
		local D = ns.DD
		if not D.f then return false, "keine DD-Ansicht", "Rahmen" end
		local shown = D.f:IsShown()
		local saveSim = ns.simAccess
		ns.simAccess = "secret"
		D:ShowSecret(80, 3)
		local r, g, b = D.f.bar:GetStatusBarColor()
		r, g, b = Num(r), Num(g), Num(b)
		ns.simAccess = saveSim
		if not shown then D.f:Hide() end
		return Near(r, 0.45, 0.02) and Near(g, 0.6, 0.02) and Near(b, 0.85, 0.02), string.format("%.2f,%.2f,%.2f", r, g, b), "0.45,0.60,0.85"
	end)
	C("T170", "J", "Blizzard-Anzeigen bei 'immer nur Anzeige' (mitgeschrieben)", function()
		if not ns.isModern then return true, "alte API (nur F R)" end
		local before = ns.actLog.n.cvar or 0
		ns.threatAccess, ns.simAccess = "open", nil
		ns.db.enabled, ns.db.blizzThreat, ns.db.threatMode = true, true, "DISPLAY"
		ns.db.blizzOrig = nil
		ns:ApplySettings()
		local n = (ns.actLog.n.cvar or 0) - before
		local note = rawget(ns.LOCALES.enUS, "O_BLIZZTHREAT_NOTE") and rawget(ns.LOCALES.deDE, "O_BLIZZTHREAT_NOTE")
		-- n == 0 ist richtig, wenn die CVars schon auf dem Zielwert stehen
		return note and true or false, "CVar " .. n .. "x mitgeschrieben", "Hinweistext en/de"
	end)
	C("T171", "J", "Knopf 'Client simulieren: Forever / echt'", function()
		local TM = ns.Test
		if not TM.frame then TM:Build() end
		if not TM.clientBtn then return false, "Knopf fehlt", "vorhanden" end
		local m1, m2
		Capture(function()
			TM:SetClientSim(true); m1 = ns.isModern
			TM:SetClientSim(false); m2 = ns.isModern
		end)
		return m1 == true and m2 == (GoldSentinelGame.IsModern and true or false), S(m1) .. "/" .. S(m2), "true/echt"
	end)
	C("T172", "J", "Ausgeschaltetes Addon meldet nichts", function()
		local shown = 0
		Swap(ns.Alerts, "Center", function() shown = shown + 1 end)
		ns.db.enabled = false
		TA.announced = false
		TA:Set("secret")
		UnswapAll()
		ns.db.enabled = true
		return shown == 0, shown .. "x", "kein Hinweis"
	end)
	C("T173", "J", "Simulation 'open' übersteuert keine echte Sperre", function()
		local save = { ns.threatAccess, ns.simAccess }
		ns.threatAccess, ns.simAccess = "secret", "open"
		local m = ns:ThreatMode()
		ns.threatAccess, ns.simAccess = save[1], save[2]
		return m == "DISPLAY", m, "DISPLAY"
	end)
	CL("T174", "J", "UnitIsUnit nur über ns:SameUnit", "Forever, Gruppe im Kampf: kein Lua-Fehler (Testzentrale-Diagnose 'Fehler: 0')")
	C("T175", "J", "Log.lua und Specs.lua nutzen ns.IsSecret", function()
		ns.testBait = SECRET
		local v = ns.Log.Val(SECRET)
		ns.testBait = nil
		return v == "SECRET", S(v), "SECRET"
	end)
	C("T176", "J", "TBC Anniversary / Classic Era – Kampflog und Meter aktiv", function()
		if ns.isModern then return true, "moderne API: Kampflog aus (richtig)" end
		local A = ns.Alerts
		return A.cleuAllowed == true and A.cleuRegistered == true and ns.DmgMeter.allowed == true and #ns.blocked == 0,
			string.format("%s/%s/%s blocked=%d", S(A.cleuAllowed), S(A.cleuRegistered), S(ns.DmgMeter.allowed), #ns.blocked), "true/true/true blocked=0"
	end)
	CL("T176b", "J", "Alter Client: Kampf in der Gruppe", "Classic Era und TBC Anniversary: Schadens-/Heilmeter zählt, widerstandener Spott wird gemeldet, kein 'Addon geblockt' – Ergebnis dem Nutzer melden")
	CL("T177", "J", "Launch-Tag: Interface-Nummer und erster Kampf", "/dump select(4, GetBuildInfo()); im ersten Kampf /ts bedrohung -> Modus im Bericht")
	K("T178", "J", "Lua-Syntaxprüfung", "vor dem Push mit addon_check.py (manuell)")
end

------------------------------------------------------------
-- K. Oberfläche im echten Client (UICheck.lua, anweisung-testroutine-oberflaeche.txt)
-- Nur lesen, nichts verändern. Ohne echten Client (Rechtecke, Tooltip) ehrlich übersprungen, nie als OK gezählt.
------------------------------------------------------------
Area.K = function()
	local U = ns.UICheck
	if not U then
		K("T180", "K", "Oberfläche im Client", "UICheck.lua fehlt")
		return
	end
	-- Testzentrale und Einstellungen öffnen, damit es etwas zu prüfen gibt (R:Finish schliesst sie wieder)
	if ns.Test and ns.Test.frame then ns.Test.frame:Show() end
	local function List(problems) return #problems == 0 and "keine" or Clean(table.concat(problems, "; ")) end
	local cases = {
		{ "T180", "Eigene Tooltips verdecken keine Knöpfe", U.TooltipsCoverNothing },
		{ "T181", "Kein Überlappen mit Blizzard- oder GoldSentinel-Fenstern", U.WindowsOverlapNothing },
		{ "T182", "Fenster ganz im Bildschirm", U.InsideScreen },
		{ "T183", "Beschriftungen von Knöpfen nicht abgeschnitten", U.TextFits },
		{ "T184", "Angezeigte Spielwerte plausibel", U.ValuesPlausible, true },
		{ "T185", "Keine Fehlerschleife (gleiche Meldung > 10×)", U.NoErrorLoops, true },
	}
	for _, c in ipairs(cases) do
		if not c[4] and not U.Available() then
			K(c[1], "K", c[2], "nur im echten Client (Fenster, Rechtecke, Tooltip)")
		else
			C(c[1], "K", c[2], function()
				local problems, tested, hints = c[3]()
				local info = List(problems) .. " · geprüft " .. tostring(tested)
					.. (hints and #hints > 0 and (" · Hinweise: " .. Clean(table.concat(hints, "; "))) or "")
				return #problems == 0, info, "keine"
			end)
		end
	end
	CL("T186", "K", "Oberfläche mit offenen Blizzard-Fenstern", "Charakterfenster, Karte, Händler oder Post öffnen, dazu Testzentrale und Einstellungen; dann /ts testroutine k: T181 ohne Überlappen")
end

------------------------------------------------------------
-- Ablauf
------------------------------------------------------------
function R:Say(msg) ns:Print("|cffffd100[Testroutine]|r " .. tostring(msg)) end

local function RunArea(letter)
	local fn = Area[letter]
	if not fn then return end
	R.inArea = true
	local ok, err = pcall(fn)
	R.inArea = false
	if not ok then RUN:Check("X" .. letter, letter, "Bereich " .. letter .. " abgebrochen", function() error(err, 0) end) end
	-- Stubs immer am Ende des Bereichs zurücksetzen und prüfen
	local open = #swaps
	UnswapAll()
	RUN:Check("S" .. letter, letter, "Stubs zurückgesetzt", function() return open == 0, open, 0 end)
	-- Sandbox zurück (Tickers sehen zwischen den Bereichen die echten Daten)
	ns.routineRunning = false
	R:RestoreSandbox()
	ns.routineRunning = true
end

function R:Finish(stopped)
	ns.routineRunning = false
	ns.actLog = nil
	UnswapAll()
	if ns.API and ns.API.Load then ns.API.Load() end   -- ns.API-Einträge sicher wieder wie im Spiel
	self:RestoreSandbox()
	-- alles schliessen, was die Routine geöffnet hat
	if ns.Test and ns.Test.frame and not self.testWasShown then ns.Test.frame:Hide() end
	if ns.Options and ns.Options.frame and not self.optWasShown then ns.Options.frame:Hide() end
	if ns.Alerts and ns.Alerts.ClearCenter then ns.Alerts:ClearCenter("test") end
	local sbOk, sbWhere = self:CheckSandbox()
	local cvOk, cvWhere = self:CheckCVars()
	local kOk, kWhere = self:CheckKeys()
	local simOk = not ns.testMode and not ns.liveTest and not ns.moveMode and ns.simSecret == self.sb.ns.simSecret[1]
		and ns.simAccess == self.sb.ns.simAccess[1] and ns.isModern == self.sb.ns.isModern[1] and ns.testBait == nil
	local real = self.realCalls
	local acts = {}
	for k, n in pairs(self.lastAct or {}) do acts[#acts + 1] = k .. "=" .. n end
	table.sort(acts)
	local function res(ok, where) return ok and "OK" or ("FEHLER (" .. tostring(where) .. ")") end
	local last = ThreatSentinelDB and ThreatSentinelDB.threatAccess
	local extra = {
		sandbox = res(sbOk, sbWhere), cvars = res(cvOk, cvWhere), tasten = res(kOk, kWhere),
		simulationen = simOk and "OK" or "FEHLER", stubs = (#swaps == 0) and "OK" or "FEHLER",
		echte_aktionen = tostring(real), mitgeschrieben = table.concat(acts, " "),
		fehlerzaehler = tostring(ns.errorCount or 0), blockiert = tostring(#(ns.blocked or {})),
		bedrohung = string.format("%s / %s / gespeichert: %s", S(ns.threatAccess), ns:ThreatMode(),
			type(last) == "table" and (S(last.state) .. " " .. S(last.date) .. " " .. S(last.build)) or "-"),
		abgebrochen = stopped and tostring(stopped) or nil,
		nicht_automatisiert = tostring(self.notAuto or 0),
	}
	local text = RUN:Finish(extra)
	text = text .. "\n" .. table.concat({
		"echte Daten unverändert: " .. extra.sandbox,
		"CVars unverändert: " .. extra.cvars,
		"Tastenbelegung unverändert: " .. extra.tasten,
		"Simulationen zurückgesetzt: " .. extra.simulationen,
		"Stubs zurückgesetzt: " .. extra.stubs,
		"Echte Aktionen während der Routine: " .. real .. " (erwartet 0) · nur mitgeschrieben: " .. (extra.mitgeschrieben ~= "" and extra.mitgeschrieben or "-"),
		"Fehlerzähler: " .. extra.fehlerzaehler .. " · gesperrte Aktionen: " .. extra.blockiert,
		"Bedrohung: " .. extra.bedrohung,
		"nicht automatisiert: " .. extra.nicht_automatisiert,
		"Kampflog/Meter: Simulation erst nach /reload",
		stopped and ("Abgebrochen: " .. tostring(stopped)) or nil,
	}, "\n")
	text = Clean(text)
	self.lastText = text
	RUN = nil
	self.running = false
	if ns.Test and ns.Test.ShowText then ns.Test:ShowText(text, L.TR_TITLE) end
	self:Say(L.TR_SAVED)
	self:Say(L.TR_RELOAD)
end

function R:Start(only)
	if self.running then self:Say(L.TR_RUNNING) return end
	if not ns:RequireDev() then return end
	if InCombat() then ns:Print(L.NOT_IN_COMBAT) return end
	if not GoldSentinelTest or not GoldSentinelTest.Begin then self:Say("GoldSentinelTest fehlt") return end
	InstallHooks()
	self.running = true
	self.realCalls = 0
	self.notAuto = 0
	self.testWasShown = ns.Test.frame and ns.Test.frame:IsShown() or false
	self.optWasShown = ns.Options.frame and ns.Options.frame:IsShown() or false
	RUN = GoldSentinelTest.Begin("ThreatSentinel", ns.version, ThreatSentinelDB)
	-- globale Namen vor der Routine (T131)
	self.globalsBefore = {}
	for k in pairs(_G) do self.globalsBefore[k] = true end
	self:TakeSandbox()
	ns.actLog = { n = {} }
	self.lastAct = ns.actLog.n
	ns.routineRunning = true
	local list = only and { only } or AREAS
	self:Say(string.format(L.TR_STARTED, only or "A–K"))
	local i = 0
	local function body()
		i = i + 1
		local letter = list[i]
		if not letter then R:Finish() return false end
		if InCombat() then
			for j = i, #list do RUN:Skip("X" .. list[j], list[j], "Bereich " .. list[j], L.TR_COMBAT) end
			R:Say(L.TR_COMBAT)
			R:Finish(L.TR_COMBAT)
			return false
		end
		RunArea(letter)
		return true
	end
	-- Ein Fehler beim Zurücksetzen (RestoreSandbox, Finish) darf das Addon nie stilllegen:
	-- dann immer routineRunning = false und actLog = nil, Fehler melden.
	local function step()
		local ok, more = pcall(body)
		if ok then
			if more then C_Timer.After(0, step) end
			return
		end
		ns.routineRunning = false
		ns.actLog = nil
		R.running = false
		UnswapAll()
		ns.testBait = nil
		RUN = nil
		ns:TestError("TestRoutine", more)
		ns:ReportError(more)
		R:Say(string.format(L.TR_ABORTED, tostring(more):match("^[^\n]*") or "?"))
	end
	C_Timer.After(0, step)
end

local HALF = { "TR_HALF_1", "TR_HALF_2", "TR_HALF_3", "TR_HALF_4", "TR_HALF_5", "TR_HALF_6", "TR_HALF_7", "TR_HALF_8", "TR_HALF_9", "TR_HALF_10" }

function R:Command(arg)
	arg = strtrim((arg or ""):lower())
	if arg == "" then
		self:Start(nil)
	elseif arg:match("^[a-k]$") then
		self:Start(arg:upper())
	elseif arg == "halb" or arg == "half" then
		if not ns:RequireDev() then return end
		self:Say(L.TR_HALF_TITLE)
		for _, k in ipairs(HALF) do ns:Print(L[k]) end
	elseif arg == "letzte" or arg == "last" then
		if not ns:RequireDev() then return end
		if self.lastText and ns.Test.ShowText then ns.Test:ShowText(self.lastText, L.TR_TITLE)
		else self:Say(L.TR_NO_LAST) end
	else
		self:Say(L.TR_USAGE)
	end
end
