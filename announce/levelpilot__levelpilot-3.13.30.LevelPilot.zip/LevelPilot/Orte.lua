-- LevelPilot – Orte (3.12.87, EULA-Austausch; vorher 3.12.72 ORT-1 aus den Spieldateien)
-- Entscheid des Nutzers 17.11.2026 06:22/06:34: keine aus Spieldateien abgeleiteten Daten mehr; gleiche Logik, nur die Quelle
-- tauschen. Ein "Ort" ist jetzt eine Häufung von Questgebern und Abgebern aus den Questdaten (Questie, GPL-3): Punkte, die
-- höchstens O.LINK Yards auseinander liegen, gehören zum selben Ort (Kette). Ein Ort braucht mindestens O.MIN_POINTS Punkte.
-- Ort-ID = Karte * 1000 + laufende Nummer (nur innerhalb dieser Spielsitzung gültig, nie gespeichert oder verglichen über Sitzungen).
-- Das Startgebiet kommt NICHT von hier (O.START fehlt): der Planer nimmt die Regel ohne Spieldaten (Mittellinie Startplatz–Gasthaus).
local _, LP = ...
local O = {}
LP.Orte = O

O.LINK = 100            -- Yards: Questgeber näher als das gehören zum selben Ort
O.MIN_POINTS = 3        -- so viele Questgeber-/Abgeber-Punkte braucht ein Ort
O.MARGIN = 40           -- Yards: Rand um den äussersten Punkt eines Orts

local hubs              -- [map] = { { id, inst, n, w, r }, ... }  (beim ersten Zugriff gebaut)
local built = false

-- Punkte je Karte sammeln (Questgeber und Abgeber aller Quests, die das Datenpaket für diesen Spieler liefert)
local function Collect()
    local QDB, Geo = LP.QuestDB, LP.Geo
    local per = {}
    if not (QDB and QDB.AllIds and Geo) then return per end
    local seen = {}
    for ci, id in ipairs(QDB:AllIds()) do
        if ci % 40 == 0 and LP.Yield then LP:Yield("plan") end
        local q = QDB:Get(id)
        if q then
            for _, list in ipairs({ q.starts or {}, q.ends or {} }) do
                for _, pt in ipairs(list) do
                    if pt[1] and pt[2] and pt[3] and not pt.obj then
                        local key = ("%d:%.1f:%.1f"):format(pt[1], pt[2], pt[3])
                        if not seen[key] then
                            seen[key] = true
                            local i, n, w = Geo:ToWorld(pt[1], pt[2], pt[3])
                            if i then
                                local p = per[pt[1]] or {}
                                per[pt[1]] = p
                                p[#p + 1] = { i, n, w }
                            end
                        end
                    end
                end
            end
        end
    end
    return per
end

-- Häufungen bilden (Kette: Nachbar näher als O.LINK)
local function Cluster(map, pts)
    local out, used = {}, {}
    local link2 = O.LINK * O.LINK
    for a = 1, #pts do
        if not used[a] then
            used[a] = true
            local member, k = { pts[a] }, 1
            while k <= #member do
                local m = member[k]
                for b = 1, #pts do
                    if not used[b] then
                        local p = pts[b]
                        if p[1] == m[1] then
                            local dn, dw = p[2] - m[2], p[3] - m[3]
                            if dn * dn + dw * dw <= link2 then used[b] = true member[#member + 1] = p end
                        end
                    end
                end
                k = k + 1
            end
            if #member >= O.MIN_POINTS then
                local sn, sw = 0, 0
                for _, p in ipairs(member) do sn, sw = sn + p[2], sw + p[3] end
                local cn, cw = sn / #member, sw / #member
                local r = 0
                for _, p in ipairs(member) do
                    local d = math.sqrt((p[2] - cn) ^ 2 + (p[3] - cw) ^ 2)
                    if d > r then r = d end
                end
                out[#out + 1] = { id = map * 1000 + #out + 1, inst = member[1][1], n = cn, w = cw, r = r + O.MARGIN, cnt = #member }
            end
        end
    end
    return out
end

-- Aufbau einmal je Sitzung: geht durch alle Quests (einige tausend) – darum nie mitten in einer Planung am Stück, sondern als
-- eigene Portion (LP.Jobs, gibt alle 40 Quests ab). Bis er fertig ist, kennt der Planer keine Orte (alte 150-yd-Regel).
-- In der virtuellen Reise und im Testlauf (Jobs.sync) läuft die Portion sofort am Stück.
local building = false
local function BuildNow()
    if built then return hubs end
    local per = Collect()
    local h = {}
    for map, pts in pairs(per) do h[map] = Cluster(map, pts) end
    hubs, built, building = h, true, false
    return hubs
end
local function Build(fromTimer)
    if built then return hubs end
    -- Wo Portionen am Stück laufen (Jobs.sync, ausser in der virtuellen Reise), nie aus einer Planung heraus bauen – das
    -- übernimmt der Zeitgeber nach dem Anmelden (sonst eine Spitze von einigen hundert ms in genau dieser Planung)
    if not fromTimer and LP.Jobs and LP.Jobs.sync and not (LP.Virtual and LP.Virtual.active) then return nil end
    if not building then
        building = true
        if LP.Jobs and LP.Jobs.Start then
            LP.Jobs.Start("orte", "plan", BuildNow, function(ok) if not ok then building = false end end, { plan = true })
        else
            BuildNow()
        end
    end
    return built and hubs or nil
end

-- billig: wird je Planung oft gefragt (HubOf je Kandidat) – nie die Questliste bauen (AllIds legt jedes Mal eine neue Liste an)
function O.Available()
    return LP.QuestDB ~= nil and LP.QuestDB.AllIds ~= nil and LP.Geo ~= nil
end

-- Ort-ID an einem Weltpunkt, bezogen auf die Karte map (nächster Ort, in dessen Rand der Punkt liegt); nil sonst
function O.AtWorld(map, inst, n, w)
    if not (map and inst and n and w) then return nil end
    local h = Build()
    local list = h and h[map]
    if not list then return nil end
    local best, bestD
    for _, h in ipairs(list) do
        if h.inst == inst then
            local d = math.sqrt((n - h.n) ^ 2 + (w - h.w) ^ 2)
            if d <= h.r and (not bestD or d < bestD) then best, bestD = h, d end
        end
    end
    return best and best.id or nil
end

-- Ort-ID an einem Kartenpunkt (x, y in 0..100)
function O.At(map, x, y)
    if not (map and x and y and LP.Geo) then return nil end
    local i, n, w = LP.Geo:ToWorld(map, x, y)
    if not i then return nil end
    return O.AtWorld(map, i, n, w)
end

-- Eltern (= Karte), Stufe (unbekannt), Name (keiner) – Eltern ~= 0 heisst "Ort innerhalb einer Zone" wie früher
function O.Info(id)
    if not id then return nil end
    return math.floor(id / 1000)
end

-- Orte einer Karte (Diagnose/Test)
function O.Hubs(map) local h = Build() return h and h[map] or {} end
function O.Ready() return built end
-- sofort bauen (Testroutine, Diagnose) – im Spiel nur ausserhalb einer Planung aufrufen
function O.BuildNow() return BuildNow() end

function O.Reset()
    hubs, built, building = nil, false, false
    if LP.Jobs and LP.Jobs.Cancel then LP.Jobs.Cancel("orte") end
end

-- Aufbau ein paar Sekunden nach dem Anmelden starten, ausserhalb jeder Planung: die erste Planung findet die Orte dann schon
-- fertig vor (sonst Rückfall auf die 150-yd-Regel, bis die Portion fertig ist)
O.PREBUILD_DELAY = 5
LP:On("PLAYER_LOGIN", function()
    if C_Timer and C_Timer.After then C_Timer.After(O.PREBUILD_DELAY, function() if O.Available() then Build(true) end end) end
end)
