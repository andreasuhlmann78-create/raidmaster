-- LevelPilot - Wegnetz-Lücken automatisch messen (Auftrag 19.11.2026 11:00, Nutzer 10:56: "bei zwei automatisch messen")
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Lückenliste: Abschnitte, die LevelPilot ohne bekannten Weg plant (Luftlinie ab 300 Yards), aus der virtuellen Reise 1–60 im Nachbau
-- (beide Fraktionen, Normal und Speedrun), sortiert nach Häufigkeit x Länge (= Strecke ohne Weg, die sie verursachen). Die ersten 300
-- decken 61,9 % dieser Strecke ab (Nachbau mit den im Spiel gemessenen Kartenrahmen, /lp kartenrahmen). Orte in Zonenkoordinaten
-- (Karte, x, y), damit sie im Spiel mit den Kartenrahmen des Clients gelten.
--
-- Läuft der Spieler beim normalen Spielen von einem Ende einer Lücke zum anderen, misst LevelPilot den Abschnitt: gelaufene Strecke,
-- Zeit, Umweg gegenüber der Luftlinie. Die Punkte selbst zeichnet die Weg-Aufzeichnung (Recorder) wie jeden gelaufenen Weg auf und
-- legt sie ins Wegnetz. Ohne Fenster, ohne Chatzeile. Nicht gewertet: Flug, Tod/Geist, Fahrzeug, Instanz (Recorder.CanRecord), Sprünge
-- über JUMP Yards je Sekunde (Schiff, Zeppelin, Teleport, Ruhestein, Ladebild), Kontinentkarte. Gemessene Lücke -> aus der Liste;
-- Messung geht mit den Wegdaten mit (Feld "lu", ohne Namen; ab Werk an, Entscheid 19.11. 11:00).
-- 3.13.5 (Auftrag 19.11. 12:42): Stillstand/AFK beendet die Messung (Recorder), Umweg über 2,5x verworfen, 2 Läufe je Lücke,
-- der schnellste bleibt.
-- Leistung: je Abtastung (alle 0,5 s) höchstens 25 Umrechnungen in Weltkoordinaten (nur bis alle umgerechnet sind) und ein Vergleich
-- mit den Lücken desselben Kontinents; keine Neuplanung.

local _, LP = ...
local LU = {}
LP:RegisterModule("Luecken", LU)

LU.ENTER = 60            -- Yards: Ende einer Lücke erreicht
LU.JUMP = 80             -- Yards je Sekunde: mehr = Sprung (zählt nicht)
LU.MAX_PTS = 400         -- Punkte je Messung (danach nur noch zählen)
LU.MAX_STORE = 200       -- gespeicherte Messungen (älteste zuerst weg)
LU.MAX_DONE = 2000       -- gemerkte gemessene Lücken (älteste zuerst weg)
LU.MAX_FACTOR = 2.5      -- 3.13.5 (Auftrag 12:42): gelaufen mehr als 2,5x Luftlinie -> verworfen (Kreis, Hin-und-her, abseits)
LU.GAP_SECS = 5          -- 3.13.5: mehr Sekunden zwischen zwei Abtastungen -> Messung verworfen
LU.MIN_RUNS = 2          -- 3.13.5 (Auftrag 12:42 Punkt 3): ein Lauf ist nie die Wahrheit – erst nach 2 Läufen aus der Liste
LU.MAX_SECS = 900        -- länger als 15 Minuten -> verworfen
LU.CONVERT_STEP = 25     -- Umrechnungen je Abtastung

-- { Karte, x1, y1, x2, y2, Häufigkeit, Länge in Yards } – erzeugt im Nachbau (berichte/LevelPilot: Bericht 3.13.2)
LU.LIST = {
    { 1426, 53.20, 35.00, 84.60, 50.70, 68, 1630 },
    { 1448, 52.50, 91.50, 64.50, 7.50, 23, 3293 },
    { 1422, 65.50, 32.50, 27.50, 57.50, 35, 1784 },
    { 1429, 93.50, 72.50, 31.50, 48.50, 27, 2222 },
    { 1440, 70.50, 86.00, 53.50, 27.50, 23, 2453 },
    { 1432, 25.50, 1.50, 21.00, 76.00, 41, 1376 },
    { 1453, 73.50, 91.50, 64.00, 8.00, 56, 981 },
    { 1421, 67.00, 77.50, 67.50, 4.50, 26, 2044 },
    { 1431, 19.60, 18.00, 45.00, 88.50, 33, 1442 },
    { 1417, 43.50, 91.50, 20.50, 29.50, 26, 1703 },
    { 1446, 33.50, 34.50, 52.50, 21.50, 29, 1441 },
    { 1437, 51.00, 10.00, 55.50, 85.50, 20, 2089 },
    { 1443, 54.50, 3.50, 42.50, 97.50, 14, 2869 },
    { 1424, 82.50, 57.50, 13.50, 46.50, 17, 2220 },
    { 1433, 2.50, 71.50, 41.50, 7.50, 29, 1255 },
    { 1440, 29.00, 13.00, 70.50, 86.00, 9, 3688 },
    { 1445, 28.50, 47.50, 71.50, 56.50, 14, 2279 },
    { 1429, 31.50, 48.50, 32.80, 85.60, 35, 860 },
    { 1439, 43.50, 92.00, 32.50, 43.80, 13, 2225 },
    { 1437, 55.50, 85.50, 4.60, 57.00, 12, 2247 },
    { 1449, 82.50, 60.50, 18.50, 37.50, 11, 2435 },
    { 1424, 13.50, 46.50, 87.50, 31.00, 11, 2391 },
    { 1428, 78.50, 76.50, 29.50, 38.00, 16, 1620 },
    { 1455, 76.00, 51.00, 18.00, 51.00, 55, 459 },
    { 1444, 90.50, 47.50, 31.80, 45.60, 6, 4081 },
    { 1411, 50.80, 13.80, 34.00, 42.50, 18, 1346 },
    { 1434, 39.00, 2.00, 25.80, 73.00, 7, 3136 },
    { 1425, 9.50, 59.00, 77.40, 83.30, 8, 2688 },
    { 1429, 93.50, 72.50, 32.80, 85.60, 10, 2129 },
    { 1423, 3.50, 42.50, 71.60, 50.10, 7, 2938 },
    { 1440, 53.50, 27.50, 94.50, 49.50, 8, 2511 },
    { 1413, 62.00, 19.00, 48.50, 5.50, 12, 1644 },
    { 1413, 62.00, 19.00, 63.70, 38.80, 14, 1349 },
    { 1421, 47.71, 54.43, 67.00, 77.50, 18, 1036 },
    { 1434, 31.40, 29.30, 39.00, 2.00, 14, 1259 },
    { 1412, 62.50, 45.50, 37.50, 27.50, 10, 1707 },
    { 1449, 18.50, 37.50, 77.20, 50.00, 7, 2194 },
    { 1411, 40.47, 31.21, 50.60, 12.60, 18, 847 },
    { 1437, 5.00, 63.50, 55.50, 85.50, 7, 2175 },
    { 1432, 47.00, 77.00, 21.00, 76.00, 21, 717 },
    { 1413, 56.72, 34.04, 48.50, 5.50, 7, 2100 },
    { 1423, 3.50, 42.50, 22.90, 73.00, 12, 1209 },
    { 1452, 61.40, 38.80, 27.50, 34.50, 6, 2415 },
    { 1440, 70.50, 86.00, 94.50, 49.50, 7, 1971 },
    { 1431, 19.60, 18.00, 71.90, 47.80, 9, 1511 },
    { 1441, 71.00, 77.59, 75.50, 95.50, 24, 561 },
    { 1449, 71.60, 76.00, 68.10, 12.60, 8, 1569 },
    { 1413, 50.50, 78.50, 44.50, 91.00, 12, 1041 },
    { 1446, 67.10, 24.00, 52.50, 28.50, 12, 1028 },
    { 1449, 41.90, 2.70, 18.50, 37.50, 10, 1219 },
    { 1437, 10.60, 60.60, 55.50, 85.50, 6, 1980 },
    { 1452, 27.50, 34.50, 60.90, 37.60, 5, 2376 },
    { 1452, 27.50, 34.50, 59.80, 74.30, 4, 2968 },
    { 1434, 32.20, 27.70, 39.00, 2.00, 10, 1176 },
    { 1449, 44.70, 8.10, 82.50, 60.50, 6, 1904 },
    { 1434, 32.20, 27.70, 35.60, 10.60, 15, 759 },
    { 1418, 2.40, 46.10, 46.00, 8.00, 9, 1255 },
    { 1422, 27.50, 57.50, 39.50, 66.80, 19, 581 },
    { 1430, 31.00, 30.00, 62.00, 75.00, 10, 1078 },
    { 1423, 3.50, 42.50, 62.00, 11.10, 4, 2673 },
    { 1420, 83.10, 68.90, 60.70, 58.80, 10, 1057 },
    { 1449, 18.50, 37.50, 43.70, 9.40, 9, 1162 },
    { 1422, 65.50, 32.50, 45.00, 66.00, 8, 1304 },
    { 1449, 41.90, 2.70, 82.50, 60.50, 5, 2071 },
    { 1446, 51.80, 28.70, 33.50, 34.50, 8, 1291 },
    { 1446, 52.50, 21.50, 66.80, 22.30, 10, 987 },
    { 1449, 43.60, 8.50, 71.60, 76.00, 5, 1961 },
    { 1431, 19.60, 18.00, 88.00, 41.00, 5, 1893 },
    { 1449, 18.50, 37.50, 49.70, 45.60, 8, 1172 },
    { 1451, 51.20, 38.30, 75.50, 39.50, 11, 847 },
    { 1437, 51.00, 10.00, 4.60, 57.00, 4, 2315 },
    { 1446, 28.90, 61.90, 51.60, 26.80, 4, 2249 },
    { 1444, 90.50, 47.50, 74.90, 42.50, 8, 1109 },
    { 1449, 71.60, 76.00, 69.10, 17.60, 6, 1444 },
    { 1424, 13.50, 46.50, 55.00, 23.00, 6, 1419 },
    { 1434, 31.40, 29.30, 35.70, 10.80, 10, 833 },
    { 1413, 48.12, 5.15, 63.70, 38.80, 3, 2768 },
    { 1423, 5.20, 35.60, 31.10, 78.00, 5, 1649 },
    { 1446, 56.00, 71.20, 50.20, 27.50, 4, 2050 },
    { 1420, 75.86, 60.68, 83.50, 70.00, 18, 445 },
    { 1411, 40.47, 31.21, 45.50, 12.00, 11, 728 },
    { 1452, 65.10, 37.20, 27.70, 34.50, 3, 2658 },
    { 1449, 82.50, 60.50, 30.90, 50.40, 4, 1925 },
    { 1434, 35.60, 10.60, 32.50, 29.40, 9, 824 },
    { 1417, 43.50, 91.50, 45.80, 47.60, 7, 1057 },
    { 1440, 11.70, 34.90, 73.10, 61.50, 2, 3685 },
    { 1437, 5.00, 63.50, 51.00, 10.00, 3, 2407 },
    { 1422, 43.00, 84.50, 65.50, 32.50, 4, 1777 },
    { 1440, 42.50, 71.00, 29.00, 13.00, 3, 2361 },
    { 1417, 20.50, 29.50, 45.80, 47.60, 7, 1009 },
    { 1444, 90.50, 47.50, 76.20, 43.80, 7, 1009 },
    { 1422, 27.50, 57.50, 43.00, 83.60, 7, 1002 },
    { 1443, 25.80, 68.20, 54.50, 3.50, 3, 2330 },
    { 1447, 10.50, 76.50, 79.30, 73.70, 2, 3490 },
    { 1447, 53.50, 21.80, 46.30, 45.00, 8, 865 },
    { 1449, 82.50, 60.50, 21.90, 38.60, 3, 2306 },
    { 1447, 77.80, 91.40, 10.50, 76.50, 2, 3450 },
    { 1452, 27.50, 34.50, 31.30, 45.20, 12, 574 },
    { 1446, 67.00, 22.40, 36.30, 41.60, 3, 2295 },
    { 1444, 90.50, 47.50, 65.90, 45.70, 4, 1712 },
    { 1440, 42.50, 71.00, 11.70, 34.90, 3, 2254 },
    { 1416, 54.00, 82.00, 23.10, 60.40, 7, 955 },
    { 1423, 70.90, 48.40, 34.90, 31.00, 4, 1627 },
    { 1444, 90.50, 47.50, 45.40, 65.00, 2, 3238 },
    { 1434, 39.00, 2.00, 15.30, 15.50, 4, 1618 },
    { 1452, 31.30, 45.20, 60.90, 37.60, 3, 2132 },
    { 1437, 10.60, 60.60, 47.50, 47.00, 4, 1571 },
    { 1423, 31.10, 78.00, 3.50, 42.50, 4, 1564 },
    { 1434, 32.10, 29.20, 39.00, 2.00, 5, 1238 },
    { 1434, 39.00, 2.00, 29.80, 21.60, 6, 1020 },
    { 1422, 65.50, 32.50, 51.90, 28.10, 10, 598 },
    { 1417, 20.50, 29.50, 74.70, 36.30, 3, 1958 },
    { 1448, 64.80, 8.10, 50.90, 81.60, 2, 2929 },
    { 1412, 41.34, 29.55, 62.50, 45.50, 4, 1457 },
    { 1434, 27.80, 77.10, 35.10, 60.90, 7, 832 },
    { 1423, 3.50, 42.50, 70.90, 48.40, 2, 2905 },
    { 1431, 88.00, 41.00, 45.00, 88.50, 4, 1442 },
    { 1417, 20.50, 29.50, 73.80, 34.00, 3, 1922 },
    { 1423, 69.90, 53.70, 3.50, 42.50, 2, 2875 },
    { 1424, 55.00, 23.00, 82.50, 57.50, 5, 1147 },
    { 1423, 11.40, 26.40, 3.50, 42.50, 10, 573 },
    { 1440, 70.50, 86.00, 73.10, 61.50, 6, 954 },
    { 1446, 52.70, 45.90, 33.50, 34.50, 4, 1425 },
    { 1425, 81.70, 81.80, 9.50, 59.00, 2, 2841 },
    { 1434, 25.80, 73.00, 31.40, 29.30, 3, 1893 },
    { 1452, 27.50, 34.50, 67.30, 40.00, 2, 2838 },
    { 1434, 38.00, 3.00, 35.70, 10.50, 16, 351 },
    { 1420, 54.00, 76.00, 61.90, 59.10, 9, 622 },
    { 1425, 80.30, 81.50, 9.50, 59.00, 2, 2786 },
    { 1418, 26.00, 44.90, 46.00, 8.00, 7, 789 },
    { 1446, 50.20, 27.50, 39.00, 29.00, 7, 776 },
    { 1446, 50.90, 27.00, 38.70, 20.10, 6, 900 },
    { 1416, 54.00, 82.00, 63.60, 43.70, 7, 764 },
    { 1434, 35.70, 10.80, 38.20, 35.60, 5, 1067 },
    { 1424, 82.50, 57.50, 87.50, 31.00, 9, 588 },
    { 1447, 10.50, 76.50, 22.60, 51.40, 5, 1047 },
    { 1418, 2.90, 45.60, 26.00, 44.90, 9, 575 },
    { 1451, 41.30, 88.50, 49.20, 34.20, 4, 1291 },
    { 1429, 43.30, 65.70, 31.50, 48.50, 9, 571 },
    { 1448, 51.20, 82.10, 35.20, 59.80, 4, 1256 },
    { 1449, 71.60, 76.00, 79.70, 49.80, 7, 712 },
    { 1423, 5.20, 35.60, 14.70, 55.80, 7, 709 },
    { 1420, 83.50, 70.00, 61.80, 65.00, 5, 992 },
    { 1452, 30.30, 36.30, 65.10, 37.20, 2, 2471 },
    { 1422, 65.50, 32.50, 45.20, 62.80, 4, 1231 },
    { 1413, 45.10, 57.70, 68.60, 49.20, 2, 2450 },
    { 1434, 27.60, 76.70, 49.80, 30.90, 2, 2409 },
    { 1439, 43.50, 92.00, 33.20, 40.00, 2, 2369 },
    { 1411, 40.47, 31.21, 34.00, 42.50, 9, 525 },
    { 1423, 18.90, 28.00, 71.70, 50.00, 2, 2357 },
    { 1449, 41.90, 2.70, 38.50, 66.10, 3, 1569 },
    { 1452, 60.50, 36.30, 27.50, 34.50, 2, 2345 },
    { 1443, 28.20, 6.70, 38.90, 27.20, 6, 780 },
    { 1449, 51.90, 49.90, 82.50, 60.50, 4, 1162 },
    { 1440, 85.20, 44.70, 78.00, 72.70, 4, 1154 },
    { 1444, 90.50, 47.50, 58.20, 57.80, 2, 2295 },
    { 1443, 54.50, 3.50, 52.60, 54.40, 3, 1528 },
    { 1448, 62.50, 24.20, 51.40, 81.50, 2, 2287 },
    { 1449, 30.90, 50.40, 43.70, 8.30, 4, 1141 },
    { 1432, 25.50, 1.50, 47.00, 77.00, 3, 1510 },
    { 1443, 35.90, 28.80, 54.50, 3.50, 4, 1129 },
    { 1449, 30.90, 50.40, 18.50, 37.50, 8, 558 },
    { 1443, 54.50, 3.50, 30.00, 8.70, 4, 1112 },
    { 1446, 67.00, 22.40, 42.10, 53.10, 2, 2224 },
    { 1443, 38.90, 27.20, 55.20, 30.20, 6, 738 },
    { 1431, 7.50, 63.50, 88.00, 41.00, 2, 2211 },
    { 1440, 42.50, 71.00, 14.80, 31.30, 2, 2209 },
    { 1448, 64.80, 8.10, 62.50, 24.20, 7, 631 },
    { 1423, 22.20, 30.00, 71.70, 50.00, 2, 2205 },
    { 1424, 30.43, 41.94, 13.50, 46.50, 8, 550 },
    { 1440, 26.20, 38.70, 36.60, 49.60, 6, 732 },
    { 1428, 65.20, 23.90, 78.50, 76.50, 4, 1098 },
    { 1423, 70.90, 48.40, 22.90, 73.00, 2, 2182 },
    { 1446, 51.80, 28.70, 67.00, 22.40, 4, 1088 },
    { 1443, 25.80, 68.20, 49.40, 76.00, 4, 1086 },
    { 1452, 31.30, 45.20, 61.40, 39.00, 2, 2157 },
    { 1431, 7.80, 34.10, 19.60, 18.00, 10, 431 },
    { 1443, 38.90, 27.20, 60.90, 61.90, 3, 1435 },
    { 1431, 45.00, 88.50, 73.50, 46.80, 4, 1075 },
    { 1443, 34.40, 8.10, 66.20, 9.60, 3, 1430 },
    { 1437, 9.90, 57.50, 51.00, 10.00, 2, 2145 },
    { 1423, 22.20, 63.50, 70.90, 48.40, 2, 2139 },
    { 1449, 43.60, 8.50, 51.90, 49.90, 4, 1066 },
    { 1417, 43.50, 91.50, 29.60, 63.00, 5, 847 },
    { 1452, 60.50, 36.30, 31.30, 45.20, 2, 2116 },
    { 1449, 43.70, 8.30, 36.60, 26.60, 8, 522 },
    { 1428, 84.60, 68.70, 65.20, 23.90, 4, 1043 },
    { 1444, 90.50, 47.50, 75.70, 44.30, 4, 1039 },
    { 1448, 51.20, 82.10, 53.50, 28.10, 2, 2074 },
    { 1440, 42.50, 71.00, 21.70, 53.30, 3, 1379 },
    { 1444, 74.40, 42.90, 44.80, 43.40, 2, 2057 },
    { 1433, 28.40, 49.00, 75.10, 37.10, 4, 1028 },
    { 1441, 13.73, 27.41, 32.00, 22.00, 5, 819 },
    { 1445, 35.20, 30.70, 71.50, 51.20, 2, 2036 },
    { 1428, 39.30, 55.30, 84.60, 68.70, 3, 1352 },
    { 1423, 3.50, 42.50, 46.50, 16.00, 2, 2000 },
    { 1417, 45.80, 47.60, 20.90, 65.70, 4, 996 },
    { 1446, 52.50, 28.50, 58.60, 36.70, 7, 565 },
    { 1423, 5.20, 35.60, 23.10, 72.60, 3, 1311 },
    { 1424, 82.50, 57.50, 51.90, 58.70, 4, 980 },
    { 1417, 32.30, 81.40, 45.70, 46.10, 4, 975 },
    { 1449, 71.60, 76.00, 82.50, 60.50, 7, 556 },
    { 1451, 41.90, 68.70, 51.60, 38.60, 5, 777 },
    { 1446, 66.60, 25.70, 38.70, 20.10, 2, 1942 },
    { 1418, 26.00, 44.90, 42.40, 52.90, 9, 429 },
    { 1442, 57.40, 89.40, 47.20, 64.00, 4, 965 },
    { 1439, 56.70, 13.50, 33.20, 40.00, 2, 1926 },
    { 1434, 25.00, 23.60, 39.00, 2.00, 3, 1282 },
    { 1434, 48.10, 23.00, 35.60, 10.60, 4, 956 },
    { 1413, 62.50, 38.50, 68.60, 49.20, 4, 951 },
    { 1427, 34.80, 84.00, 65.60, 62.20, 5, 760 },
    { 1447, 11.40, 78.20, 19.10, 64.00, 6, 619 },
    { 1434, 35.60, 10.60, 48.80, 19.40, 4, 922 },
    { 1434, 27.80, 14.30, 35.70, 10.80, 7, 526 },
    { 1429, 32.80, 85.60, 84.60, 69.40, 2, 1837 },
    { 1446, 36.30, 41.60, 50.90, 27.00, 3, 1211 },
    { 1443, 55.00, 26.60, 25.80, 68.20, 2, 1811 },
    { 1425, 59.50, 78.30, 78.20, 81.20, 5, 724 },
    { 1423, 44.30, 41.20, 71.70, 50.00, 3, 1205 },
    { 1449, 46.40, 13.40, 71.60, 76.00, 2, 1804 },
    { 1448, 34.80, 52.70, 52.50, 91.50, 2, 1802 },
    { 1439, 38.80, 43.40, 47.20, 48.70, 6, 597 },
    { 1413, 47.25, 40.32, 45.10, 57.70, 3, 1194 },
    { 1433, 24.60, 44.30, 64.40, 59.40, 4, 891 },
    { 1417, 74.70, 36.30, 25.50, 30.10, 2, 1777 },
    { 1449, 41.90, 2.70, 56.50, 12.50, 6, 592 },
    { 1413, 48.83, 50.38, 65.80, 43.80, 2, 1776 },
    { 1443, 54.50, 3.50, 60.90, 61.90, 2, 1774 },
    { 1417, 45.80, 47.60, 54.80, 81.90, 4, 885 },
    { 1451, 81.90, 18.90, 64.90, 47.20, 4, 885 },
    { 1444, 74.90, 42.50, 59.00, 51.10, 3, 1175 },
    { 1434, 39.00, 2.00, 40.40, 43.30, 2, 1759 },
    { 1443, 22.50, 73.10, 42.50, 97.50, 3, 1159 },
    { 1448, 34.40, 54.00, 48.20, 94.30, 2, 1737 },
    { 1434, 27.10, 77.20, 40.00, 58.20, 3, 1154 },
    { 1446, 50.20, 27.50, 52.70, 45.90, 4, 864 },
    { 1435, 4.00, 62.00, 34.00, 66.00, 5, 691 },
    { 1439, 33.20, 40.00, 43.60, 76.30, 2, 1725 },
    { 1427, 34.80, 84.00, 37.70, 26.50, 4, 858 },
    { 1417, 46.70, 47.00, 18.20, 68.10, 3, 1144 },
    { 1449, 71.60, 76.00, 68.70, 56.70, 7, 488 },
    { 1423, 22.20, 63.50, 40.90, 53.70, 4, 852 },
    { 1434, 26.70, 73.60, 37.00, 69.70, 5, 678 },
    { 1437, 64.80, 75.30, 49.90, 18.20, 2, 1690 },
    { 1449, 63.10, 69.10, 43.90, 7.20, 2, 1684 },
    { 1440, 42.50, 71.00, 69.00, 53.40, 2, 1671 },
    { 1437, 11.80, 58.00, 38.20, 50.90, 3, 1109 },
    { 1444, 45.10, 25.60, 90.50, 47.50, 1, 3314 },
    { 1422, 49.70, 76.80, 27.50, 57.50, 3, 1103 },
    { 1440, 14.80, 31.30, 7.20, 13.10, 4, 826 },
    { 1445, 37.20, 33.10, 39.00, 64.40, 3, 1100 },
    { 1441, 45.36, 49.77, 77.80, 77.30, 2, 1640 },
    { 1452, 27.50, 34.50, 49.00, 46.90, 2, 1635 },
    { 1439, 37.40, 40.10, 43.60, 76.30, 2, 1632 },
    { 1444, 74.40, 43.40, 75.60, 60.90, 4, 815 },
    { 1422, 39.50, 66.80, 43.40, 84.80, 6, 543 },
    { 1417, 43.50, 91.50, 60.20, 53.90, 3, 1084 },
    { 1449, 48.70, 85.30, 18.50, 37.50, 2, 1624 },
    { 1431, 75.80, 47.60, 19.60, 18.00, 2, 1608 },
    { 1428, 95.10, 31.60, 85.40, 70.10, 4, 803 },
    { 1445, 28.50, 47.50, 55.40, 26.30, 2, 1595 },
    { 1437, 10.90, 59.60, 13.50, 31.00, 4, 796 },
    { 1448, 45.10, 41.00, 50.90, 81.60, 2, 1592 },
    { 1440, 64.70, 75.40, 29.00, 13.00, 1, 3161 },
    { 1449, 18.50, 37.50, 39.30, 30.30, 4, 790 },
    { 1446, 50.20, 27.50, 70.60, 43.00, 2, 1578 },
    { 1439, 55.00, 24.90, 33.20, 40.00, 2, 1573 },
    { 1446, 67.00, 22.40, 29.50, 60.50, 1, 3125 },
    { 1433, 24.90, 44.50, 2.50, 71.50, 5, 624 },
    { 1417, 20.50, 29.50, 60.10, 55.90, 2, 1560 },
    { 1449, 54.20, 13.70, 82.50, 60.50, 2, 1559 },
    { 1440, 26.20, 38.70, 42.50, 71.00, 2, 1557 },
    { 1448, 39.00, 62.20, 51.20, 82.10, 3, 1036 },
    { 1447, 10.50, 76.50, 36.90, 53.20, 2, 1553 },
    { 1444, 55.90, 61.70, 74.40, 43.40, 2, 1540 },
    { 1447, 42.40, 64.20, 53.50, 21.80, 2, 1540 },
    { 1434, 41.90, 47.00, 32.30, 27.70, 3, 1024 },
    { 1448, 64.50, 7.50, 50.90, 85.00, 1, 3072 },
    { 1448, 46.80, 83.10, 64.50, 7.50, 1, 3072 },
    { 1416, 17.80, 83.20, 54.00, 82.00, 3, 1014 },
    { 1440, 53.50, 27.50, 29.00, 13.00, 2, 1519 },
    { 1449, 82.50, 60.50, 43.90, 81.40, 2, 1518 },
    { 1431, 73.80, 44.50, 18.40, 56.40, 2, 1511 },
    { 1418, 46.00, 8.00, 42.40, 52.90, 4, 750 },
    { 1427, 38.60, 27.80, 63.90, 61.00, 4, 750 },
    { 1424, 82.50, 57.50, 63.20, 20.70, 3, 999 },
    { 1413, 39.50, 47.50, 62.00, 19.00, 1, 2984 },
    { 1434, 39.00, 2.00, 43.30, 36.40, 2, 1489 },
    { 1444, 53.00, 32.00, 44.50, 2.50, 2, 1489 },
    { 1446, 52.50, 21.50, 66.60, 25.70, 3, 992 },
    { 1447, 22.60, 51.40, 79.30, 73.70, 1, 2972 },
    { 1443, 38.90, 27.20, 52.30, 53.40, 3, 990 },
    { 1431, 21.50, 73.60, 73.50, 46.80, 2, 1485 },
    { 1447, 10.50, 76.50, 34.10, 50.50, 2, 1485 },
    { 1451, 48.60, 37.80, 67.20, 69.80, 3, 986 },
    { 1440, 36.60, 49.60, 29.00, 13.00, 2, 1473 },
    { 1451, 41.30, 88.50, 50.90, 26.80, 2, 1472 },
    { 1448, 34.80, 52.70, 51.20, 82.10, 2, 1469 },
    { 1417, 66.70, 29.70, 52.00, 50.70, 4, 731 },
    { 1413, 62.30, 39.00, 61.80, 53.40, 3, 974 },
}

local world, converted = {}, 0      -- [i] = { inst, n1, w1, n2, w2, len } oder false

function LU.Key(e) return string.format("%d:%.2f,%.2f:%.2f,%.2f", e[1], e[2], e[3], e[4], e[5]) end

local function Store()
    local db = LP.db
    if type(db) ~= "table" then return {}, {} end
    if type(db.lueckenMess) ~= "table" then db.lueckenMess = {} end
    if type(db.lueckenDone) ~= "table" then db.lueckenDone = {} end
    return db.lueckenMess, db.lueckenDone
end
LU.Store = Store

function LU:Reset() wipe(world) converted = 0 self.active = nil self.holdAt = nil end

-- höchstens CONVERT_STEP Einträge in Weltkoordinaten umrechnen
function LU:Convert()
    local list = self.LIST
    local stop = math.min(#list, converted + self.CONVERT_STEP)
    for i = converted + 1, stop do
        local e = list[i]
        local i1, n1, w1 = LP.Geo:ToWorld(e[1], e[2], e[3])
        local i2, n2, w2 = LP.Geo:ToWorld(e[1], e[4], e[5])
        if i1 and i2 and i1 == i2 then
            world[i] = { i1, n1, w1, n2, w2, LP.Geo:Dist(n1, w1, n2, w2) }
        else
            world[i] = false
        end
    end
    converted = stop
    return converted >= #list
end

-- nächste noch nicht gemessene Lücke, an deren Ende der Spieler steht: Index, Seite (1 = Anfang, 2 = Ende)
function LU:Find(inst, n, w)
    local _, done = Store()
    local lim = self.ENTER
    for i = 1, converted do
        local g = world[i]
        if g and g[1] == inst then
            local d1 = LP.Geo:Dist(n, w, g[2], g[3])
            local d2 = d1 > lim and LP.Geo:Dist(n, w, g[4], g[5]) or nil
            if d1 <= lim or (d2 and d2 <= lim) then
                if not done[self.Key(self.LIST[i])] then return i, d1 <= lim and 1 or 2 end
            end
        end
    end
    return nil
end

function LU:Abort(why)
    if self.active then self.stats.aborted = self.stats.aborted + 1 self.lastAbort = why end
    self.active = nil
end
LU.stats = { started = 0, done = 0, aborted = 0, ms = 0, calls = 0 }

-- eine Abtastung (Recorder, alle 0,5 s). ok = Aufzeichnung erlaubt (Recorder.CanRecord, keine virtuelle Reise, Zonenkarte)
function LU:Sample(ok, inst, n, w, now)
    local t0 = LP.Perf and LP.Perf.clock and LP.Perf.clock()
    self:SampleCore(ok, inst, n, w, now)
    if t0 then
        local ms = LP.Perf.clock() - t0
        self.stats.ms, self.stats.calls = self.stats.ms + ms, self.stats.calls + 1
        if ms > (self.stats.max or 0) then self.stats.max = ms end
    end
end

function LU:SampleCore(ok, inst, n, w, now)
    if converted < #self.LIST then self:Convert() end
    if not ok or not inst then if self.active then self:Abort("aus") end return end
    local a = self.active
    if not a then
        -- 3.13.5: nach einer Messung erst wieder suchen, wenn der Spieler den Endpunkt verlassen hat (sonst begann sofort eine
        -- Messung in Gegenrichtung, die beim nächsten Halt am anderen Ende die Wartezeit mitzählte)
        local hold = self.holdAt
        if hold then
            if hold[1] == inst and LP.Geo:Dist(n, w, hold[2], hold[3]) < 2 * self.ENTER then return end
            self.holdAt = nil
        end
        local i, side = self:Find(inst, n, w)
        if not i then return end
        self.active = { i = i, side = side, t0 = now, inst = inst, last = { n, w, now }, first = { n, w }, walked = 0, pts = { { n, w } } }
        self.stats.started = self.stats.started + 1
        return
    end
    local g = world[a.i]
    local ln, lw, lt = a.last[1], a.last[2], a.last[3]
    local d = LP.Geo:Dist(ln, lw, n, w)
    local dt = math.max(now - lt, 0.5)
    if inst ~= a.inst or d > self.JUMP * dt + 5 then return self:Abort("sprung") end
    -- 3.13.5: Lücke in der Abtastung (Ladebild, Pause, Stillstand-Abschnitt) -> Messung ungültig
    if now - lt > self.GAP_SECS then return self:Abort("pause") end
    a.walked = a.walked + d
    a.last[1], a.last[2], a.last[3] = n, w, now
    if d >= 6 and #a.pts < self.MAX_PTS then a.pts[#a.pts + 1] = { n, w } end
    -- wieder am Anfang: neu beginnen (Start ist der letzte Halt dort)
    local sn, sw = (a.side == 1) and g[2] or g[4], (a.side == 1) and g[3] or g[5]
    local en, ew = (a.side == 1) and g[4] or g[2], (a.side == 1) and g[5] or g[3]
    if LP.Geo:Dist(n, w, sn, sw) <= self.ENTER then
        a.t0, a.walked, a.pts, a.first = now, 0, { { n, w } }, { n, w }
        return
    end
    if a.walked > self.MAX_FACTOR * g[6] or now - a.t0 > self.MAX_SECS then return self:Abort("umweg") end
    if LP.Geo:Dist(n, w, en, ew) <= self.ENTER then self:Finish(now) end
end

function LU:Finish(now)
    local a = self.active
    self.active = nil
    if not a then return end
    local e = self.LIST[a.i]
    local mess, done = Store()
    local key = self.Key(e)
    -- Umweg-Faktor gegen die Luftlinie zwischen dem ersten und dem letzten gemessenen Punkt (beide höchstens ENTER von den Enden)
    local straight = LP.Geo:Dist(a.first[1], a.first[2], a.last[1], a.last[2])
    local rec = { k = key, m = e[1], w = math.floor(a.walked + 0.5), s = math.floor(now - a.t0 + 0.5), l = math.floor(straight + 0.5),
                  f = math.floor(a.walked / math.max(1, straight) * 100 + 0.5) / 100, p = #a.pts, t = time(), v = LP.version }
    -- 3.13.5: Läufe je Lücke; der beste (schnellste) bleibt, ein langsamerer ersetzt ihn nie
    local db = LP.db
    if type(db.lueckenRuns) ~= "table" then db.lueckenRuns = {} end
    local runs = db.lueckenRuns[key]
    if type(runs) ~= "table" then runs = { n = 0 } db.lueckenRuns[key] = runs end
    runs.n = (runs.n or 0) + 1
    rec.n = runs.n
    if not runs.best or rec.s < runs.best.s then
        runs.best = { w = rec.w, s = rec.s, l = rec.l, f = rec.f, t = rec.t }
        rec.best = true
    end
    mess[#mess + 1] = rec
    while #mess > self.MAX_STORE do table.remove(mess, 1) end
    if runs.n >= self.MIN_RUNS then done[key] = rec.t end
    local nDone = 0
    for _ in pairs(done) do nDone = nDone + 1 end
    if nDone > self.MAX_DONE then
        local oldK, oldT
        for k, t in pairs(done) do if not oldT or t < oldT then oldK, oldT = k, t end end
        if oldK then done[oldK] = nil end
    end
    self.stats.done = self.stats.done + 1
    self.lastRec = rec
    self.holdAt = { a.inst, a.last[1], a.last[2] }
    return rec
end

-- offene Lücken (nicht gemessen), für Diagnose und Bericht
function LU:OpenCount()
    local _, done = Store()
    local n = 0
    for _, e in ipairs(self.LIST) do if not done[self.Key(e)] then n = n + 1 end end
    return n
end

-- Messungen seit dem letzten Versand (Wegdaten, Feld "lu")
function LU:Since(t)
    local out = {}
    local mess = Store()
    for _, r in ipairs(mess) do if (r.t or 0) > (t or 0) then out[#out + 1] = r end end
    return out
end

function LU:Init() end
