-- LevelPilot - Hinweise: Klasse, Trainer, Reittier, Berufe
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- * Klassenquest-Vorwarnung: Klassenquests der naechsten zwei Level (aus den Questdaten)
-- * Klassen-Erinnerungen: Seelensplitter, Gift auf der Waffe, Begleiter, Waffenmeister
-- * Trainer: Besuch einplanen, wenn der Klassentrainer in der Naehe ist; Kosten der naechsten
--   Level (beim Trainer gelernt, sonst geschaetzt)
-- * Reittier: Gold-Ziel fuer Level 40, danach Weg zum Reitlehrer des eigenen Volkes
-- * Erste Hilfe und Kochen: Trainer in der Naehe, wenn noch nicht gelernt

local _, LP = ...
local L = LP.L
local H = {}
LP:RegisterModule("Hints", H)

local CLASS_EN = { WARRIOR = "Warrior", PALADIN = "Paladin", HUNTER = "Hunter", ROGUE = "Rogue", PRIEST = "Priest",
                   SHAMAN = "Shaman", MAGE = "Mage", WARLOCK = "Warlock", DRUID = "Druid" }
local TRAINER_NEAR = 400       -- Yards: Trainerbesuch einplanen
-- 3.13.0: PROF_NEAR (300 yd) ersetzt durch LP.Advisor:TeacherOK (150 yd, Weg, Stadt des Lehrers)
-- Heimatgebiete der Reitlehrer je Volk (Reittiere des eigenen Volkes)
local RIDING_HOME = {
    Orc = { 1411, 1454 }, Troll = { 1411, 1454 }, Tauren = { 1412, 1456 }, Scourge = { 1420, 1458 },
    Human = { 1429, 1453 }, Dwarf = { 1426, 1455 }, Gnome = { 1426, 1455 }, NightElf = { 1438, 1457 },
}
local SOUL_SHARD, FIRST_AID, COOKING = 6265, 3273, 2550

local function Navigate(v, label, key)
    if not v then return end
    local i, n, w = LP.Geo:ToWorld(v.map, v.x, v.y)
    LP.Planner.priority = { t = "GOTO", map = v.map, x = v.x, y = v.y, inst = i, n = n, w = w,
                            text = label .. ": " .. (v.name or "?"), key = key }
    LP.Planner:Replan()
end

-- Zauber bekannt? Moderner Client zuerst. true/false nur, wenn eine Funktion antwortet; ist gar nichts davon da:
-- nil (unbekannt). Die Aufrufer pruefen auf == true bzw. == false - lieber kein Hinweis als ein falscher (3.12.5).
-- 3.12.6: antwortet eine Abfrage mit false, werden die uebrigen auch gefragt (Berufszauber kennt Forever evtl. nur ueber
-- IsPlayerSpell) - true gewinnt.
local function Known(spell)
    local answered = false
    local function ask(fn)
        local ok, r = pcall(fn, spell)
        if not ok or (LP.Game and LP.Game.IsSecret(r)) then return false end
        answered = true
        return r and true or false
    end
    if C_SpellBook and C_SpellBook.IsSpellKnown and ask(C_SpellBook.IsSpellKnown) then return true end
    if IsSpellKnown and ask(IsSpellKnown) then return true end
    if IsPlayerSpell and ask(IsPlayerSpell) then return true end
    if answered then return false end
    return nil
end
H.Known = Known

------------------------------------------------------------------------
-- Klassenquest-Vorwarnung
------------------------------------------------------------------------
local upcoming, upcomingLevel = {}, nil

-- yieldKind (3.12.97, Ingametest 3.12.95 T261 b: "advisor" max 37 ms; Nachbau kalt 12 ms = diese Schleife über alle Quests): der
-- Assistent rechnet die Liste vorab im Auftrag mit Abgabe (A:AddPrepare, ausserhalb jedes pcall); fertig ersetzt, nie halb sichtbar
function H:UpcomingClassQuests(yieldKind)
    local level = LP:PlayerLevel() or 1
    if upcomingLevel == level then return upcoming end
    local list = {}
    local QDB = LP.QuestDB
    for i, id in ipairs(QDB:AllIds()) do
        if yieldKind and i % 200 == 0 then LP:Yield(yieldKind) end
        local info = QDB:QuickInfo(id)
        if info and info.classes and info.classes ~= 0 and LP.Planner.IsClassQuest(info.classes)
           and (info.reqLevel or 0) > level and (info.reqLevel or 0) <= level + 2
           and QDB:FitsPlayer(info) and not LP.API.IsQuestDone(id) then
            local q = QDB:Get(id)
            if q and q.starts and q.starts[1] and not q.itemStart then
                list[#list + 1] = { id = id, name = q.name, level = info.reqLevel, map = q.starts[1][1] }
            end
        end
    end
    table.sort(list, function(a, b) if a.level ~= b.level then return a.level < b.level end return a.id < b.id end)
    while #list > 3 do table.remove(list) end
    if (LP:PlayerLevel() or 1) ~= level then return list end       -- Stufe hat sich in einer Pause geändert: nicht merken
    upcoming, upcomingLevel = list, level
    return upcoming
end

local function ClassQuestHint(add)
    if not LP.db.hintClassQuests then return end
    for _, q in ipairs(H:UpcomingClassQuests()) do
        add("cq" .. q.id, LP.Advisor.SEV_INFO, L("Ab Level %d: Klassenquest „%s“ (%s)", q.level, q.name or "?", LP.Geo:MapName(q.map)))
    end
end

------------------------------------------------------------------------
-- Klassen-Erinnerungen
------------------------------------------------------------------------
local function ClassReminders(add)
    if not LP.db.hintClass then return end
    local _, class = UnitClass("player")
    local level = LP:PlayerLevel() or 1
    if class == "WARLOCK" and level >= 10 then
        local n = LP.API.ItemCount(SOUL_SHARD) or 0
        if n < 3 then add("shards", LP.Advisor.SEV_INFO, L("Nur %d Seelensplitter – Gegner mit Seelendieb erledigen.", n)) end
    end
    if class == "ROGUE" and level >= 20 and GetWeaponEnchantInfo and (Known(2842) == true or Known(8681) == true) then
        local hasMain = GetWeaponEnchantInfo()
        if not hasMain then add("poison", LP.Advisor.SEV_INFO, L["Kein Gift auf der Waffe – Gift auftragen."]) end
    end
    if class == "HUNTER" and level >= 10 then
        if UnitExists and not LP.SafeValue(UnitExists("pet")) then
            add("pet", LP.Advisor.SEV_INFO, L["Kein Begleiter aktiv – Tier rufen oder zähmen."])
        elseif GetPetHappiness then
            local happy = GetPetHappiness()
            if happy == 1 then add("pethappy", LP.Advisor.SEV_WARN, L["Dein Begleiter ist unglücklich – füttern (Tier füttern)."]) end
        end
    end
    if (class == "WARRIOR" or class == "ROGUE" or class == "HUNTER" or class == "PALADIN") and (level == 10 or level == 20)
       and (LP.char.weaponHint or 0) < level then
        local where = LP:PlayerFaction() == "Horde" and L["Orgrimmar, Unterstadt oder Donnerfels"] or L["Sturmwind, Eisenschmiede oder Darnassus"]
        add("weapons", LP.Advisor.SEV_INFO, L("Weitere Waffenarten lernst du beim Waffenmeister in %s.", where), function()
            LP.char.weaponHint = level
            LP.Advisor:Soon()
        end, L["Verstanden"])
    end
end

------------------------------------------------------------------------
-- Trainer: Kosten lernen und vorhersagen, Besuch einplanen
------------------------------------------------------------------------
-- beim Trainer: Kosten aller angezeigten Faehigkeiten je Stufe merken (auch kuenftige)
function H:LearnTrainerCosts()
    if not GetNumTrainerServices or not GetTrainerServiceCost then return end
    local _, class = UnitClass("player")
    LP.db.trainerCosts = LP.db.trainerCosts or {}
    local costs = {}
    for i = 1, GetNumTrainerServices() or 0 do
        local _, _, category = GetTrainerServiceInfo(i)
        if category == "available" or category == "unavailable" then
            local lvl = GetTrainerServiceLevelReq and GetTrainerServiceLevelReq(i) or 0
            local cost = GetTrainerServiceCost(i) or 0
            if lvl and lvl > 0 and cost > 0 then costs[lvl] = (costs[lvl] or 0) + cost end
        end
    end
    if next(costs) then
        local c = LP.db.trainerCosts[class] or {}
        LP.db.trainerCosts[class] = c
        for lvl, cost in pairs(costs) do c[lvl] = cost end
    end
end

-- Kosten fuer ein Level (Kupfer) und ob gelernt oder geschaetzt
function H:TrainerCost(level)
    local _, class = UnitClass("player")
    local c = LP.db.trainerCosts and LP.db.trainerCosts[class]
    if c and c[level] then return c[level], false end
    if level % 2 == 1 and level > 1 then return nil end
    return math.floor(72 * level * level), true          -- Erfahrungswert Classic (ca. 0,7 Gold auf 10, 26 Gold auf 60)
end

local function TrainerHints(add)
    if not LP.db.hintTrainer then return end
    local level = LP:PlayerLevel() or 1
    -- Kostenvorschau fuer das naechste Trainer-Level
    local nextLvl = level + (level % 2 == 0 and 2 or 1)
    if nextLvl <= 60 then
        local cost, guessed = H:TrainerCost(nextLvl)
        -- 3.13.8 LP-B2: ohne gemessene Trainerkosten (Trainer noch nicht geöffnet) keine Zahl – 72 × Stufe² ist eine Schätzung
        if guessed then cost = nil end
        if cost and cost > 0 then
            local money = GetMoney and GetMoney() or 0
            if money < cost then
                add("traincost", LP.Advisor.SEV_INFO, L("Auf Level %d brauchst du %s%s beim Trainer – du hast %s.", nextLvl,
                    guessed and L["ca. "] or "", LP.Session.Money(cost), LP.Session.Money(money)))
            end
        end
    end
    -- Besuch einplanen: neue Faehigkeiten und der Trainer ist nah
    -- 3.13.10 LP-T1-R: in der virtuellen Reise nicht hier (Takt des Assistenten = Uhrzeit), sondern je Reiseschritt (H.TrainerVisit aus
    -- Virtual.lua) – sonst hing der Trainerbesuch der Reise an der Phase des 30-s-Tickers (belegt: Startzeit der Reise je Lauf verschieden,
    -- erste Abweichung immer PRIO:TRAIN)
    if not (LP.Virtual and LP.Virtual.active) then H.TrainerVisit(level, true) end
end
-- Trainerbesuch als Vorrang-Ziel einplanen (neue Fähigkeiten, Trainer nah). replan = Neuplanung anstossen (nicht in der Reise:
-- dort plant der Schritt ohnehin). Liefert true, wenn eingeplant.
function H.TrainerVisit(level, replan)
    level = level or LP:PlayerLevel() or 1
    if not (level >= 2 and level % 2 == 0 and (LP.char.trainerLevel or 0) < level) then return false end
    local _, class = UnitClass("player")
    local want = CLASS_EN[class] and (CLASS_EN[class] .. " Trainer")
    local v, d = LP.QuestDB:NearestService("trainer", function(x) return x.sub == want end)
    local key = "PRIO:TRAIN:" .. level
    if v and d and d <= TRAINER_NEAR and not LP.Planner.priority and not LP.char.doneKeys[key] then
        if replan then Navigate(v, L["Klassentrainer"], key)
        else
            local i, n, w = LP.Geo:ToWorld(v.map, v.x, v.y)
            LP.Planner.priority = { t = "GOTO", map = v.map, x = v.x, y = v.y, inst = i, n = n, w = w,
                                    text = L["Klassentrainer"] .. ": " .. (v.name or "?"), key = key }
        end
        return true
    end
    return false
end

------------------------------------------------------------------------
-- Reittier
------------------------------------------------------------------------
local function HasMount()
    local info = C_Item and C_Item.GetItemInfoInstant or GetItemInfoInstant
    for bag = 0, 4 do
        for slot = 1, (LP.API.BagSlots(bag) or 0) do
            local it = LP.API.BagItem(bag, slot)
            if it and it.id and info then
                local classID, sub = select(6, info(it.id)), select(7, info(it.id))
                if classID == 15 and sub == 5 then return true end
            end
        end
    end
    return LP.char.hasMount or false
end
H.HasMount = HasMount

function H:RidingTrainer()
    local _, race = UnitRace("player")
    local home = RIDING_HOME[race]
    local function filter(v)
        if not v.sub or not v.sub:find("Riding") then return false end
        if not home then return true end
        for _, m in ipairs(home) do if v.map == m then return true end end
        return false
    end
    return LP.QuestDB:NearestService("trainer", filter)
end

-- 3.13.0: nächster Klassentrainer (für den Vorschlag "Neue Fähigkeiten" nur am passenden Ort)
function H:ClassTrainer()
    local _, class = UnitClass("player")
    local want = CLASS_EN[class] and (CLASS_EN[class] .. " Trainer")
    if not want then return nil end
    return LP.QuestDB:NearestService("trainer", function(x) return x.sub == want end)
end

local function MountHint(add)
    if not LP.db.hintMount then return end
    local level = LP:PlayerLevel() or 1
    if HasMount() then LP.Advisor:Done("mountgold") LP.Advisor:Done("mountgo") return end   -- 3.13.0: erledigt
    if level < 35 then return end
    local goal = (LP.db.mountGold or 100) * 10000
    local money = GetMoney and GetMoney() or 0
    if money < goal then
        add("mountgold", level >= 40 and LP.Advisor.SEV_WARN or LP.Advisor.SEV_INFO,
            L("Reittier ab Level 40: %s von %s – es fehlen noch %s.", LP.Session.Money(money), LP.Session.Money(goal), LP.Session.Money(goal - money)))
    elseif level >= 40 then
        local v = H:RidingTrainer()
        add("mountgo", LP.Advisor.SEV_WARN, L["Genug Gold für das Reittier – ab zum Reitlehrer!"] ..
            (v and ("\n" .. (v.name or "?") .. ", " .. LP.Geo:MapName(v.map)) or ""),
            v and function() Navigate(v, L["Reitlehrer"], "PRIO:RIDE") end or nil, v and L["Hinführen"] or nil)
    end
end

------------------------------------------------------------------------
-- Erste Hilfe und Kochen
-- 3.13.7 (Auftrag 23.11., Befund Ingame 3.13.6 Brachland Stufe 25: "Kochen kannst du hier lernen", obwohl Kochen gelernt war):
-- Vorher prüfte nur Known(Zauber 2550 / 3273) – das ist der Zauber der ERSTEN Stufe; mit einer höheren Stufe kann der Client ihn
-- als unbekannt melden. Jetzt zuerst die Fertigkeitenliste des Charakters (GetNumSkillLines/GetSkillLineInfo, Name = Name des
-- Berufszaubers aus GetSpellInfo in der Sprache des Clients):
--   Liste nicht geladen (0 Zeilen / Funktion fehlt) oder Name unbekannt -> KEIN Hinweis
--   Beruf in der Liste -> gelernt. Hinweis nur auf die nächste Stufe, wenn sie jetzt beim Lehrer lernbar ist: Geselle bei
--     höchstens 75 Punkten, Fertigkeit ab 50 und Stufe ab 10 (belegt: goldgoblin Verzauberkunst Forever "Geselle ab Skill 50 +
--     Stufe 10", shared/wissen/referenz-goldgoblin.md). Experte/Fachmann: keine Angabe für Kochen/Erste Hilfe belegt -> kein Hinweis.
--   Beruf nicht in der Liste und auch Known(Zauber) nicht true -> Lehrling beim Lehrer
------------------------------------------------------------------------
H.JOURNEY_SKILL, H.JOURNEY_LEVEL, H.APPRENTICE_MAX = 50, 10, 75

-- Fertigkeitenliste: [Name] = { rank, max }; nil = (noch) nicht lesbar
function H.SkillLines()
    if not (GetNumSkillLines and GetSkillLineInfo) then return nil end
    local ok, n = pcall(GetNumSkillLines)
    if not ok or type(n) ~= "number" or n <= 0 then return nil end
    local out, any = {}, false
    for i = 1, n do
        local ok2, name, isHeader, _, rank, _, _, maxRank = pcall(GetSkillLineInfo, i)
        if ok2 and type(name) == "string" and not isHeader then
            out[name] = { rank = tonumber(rank) or 0, max = tonumber(maxRank) or 0 }
            any = true
        end
    end
    return any and out or nil
end

-- Stufe, die jetzt beim Lehrer lernbar ist: "lehrling", "geselle" oder nil (nichts / nicht sicher)
function H.ProfTier(spell, lines, level)
    if not lines then return nil end
    local name = GetSpellInfo and GetSpellInfo(spell)
    if type(name) ~= "string" or name == "" then return nil end
    local s = lines[name]
    if s then
        if s.max == H.APPRENTICE_MAX and s.rank >= H.JOURNEY_SKILL and (level or 0) >= H.JOURNEY_LEVEL then return "geselle" end
        return nil, "gelernt"
    end
    if Known(spell) == true then return nil, "gelernt" end
    return "lehrling"
end

local function ProfessionHints(add)
    if not LP.db.hintProfessions or (LP:PlayerLevel() or 1) < 5 then return end
    local lines = H.SkillLines()
    if not lines then return end                                    -- Liste noch nicht geladen: kein Hinweis
    local level = LP:PlayerLevel() or 1
    for _, p in ipairs({ { FIRST_AID, "First Aid Trainer", L["Erste Hilfe"] }, { COOKING, "Cooking Trainer", L["Kochen"] } }) do
        local tier, why = H.ProfTier(p[1], lines, level)
        local key = "prof" .. p[1]
        if why == "gelernt" then LP.Advisor:Done(key) end              -- 3.13.0: gelernt -> sofort weg, auch aus der Liste
        if tier ~= "geselle" then LP.Advisor:Done(key .. "j") end
        if tier then
            local v, d = LP.QuestDB:NearestService("trainer", function(x) return x.sub == p[2] end)
            -- 3.13.0 (Auftrag 19.11. 09:36): nur am passenden Ort (vorher: Lehrer bis 300 yd, auch im Kampf und in Eile)
            if v and LP.Advisor:TeacherOK(v, d) then
                if tier == "geselle" then
                    add(key .. "j", LP.Advisor.SEV_INFO, L("%s (Geselle) kannst du hier lernen: %s (%s)", p[3], v.name or "?", LP:FormatDist(d)),
                        function() Navigate(v, p[3], "PRIO:PROF" .. p[1]) end, L["Hinführen"])
                else
                    add(key, LP.Advisor.SEV_INFO, L("%s kannst du hier lernen: %s (%s)", p[3], v.name or "?", LP:FormatDist(d)),
                        function() Navigate(v, p[3], "PRIO:PROF" .. p[1]) end, L["Hinführen"])
                end
            end
        end
    end
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
H.ClassReminders, H.TrainerHints, H.ProfessionHints, H.MountHint = ClassReminders, TrainerHints, ProfessionHints, MountHint   -- Testroutine

function H:Init()
    local A = LP.Advisor
    if A.AddPrepare then A:AddPrepare(function() if LP.db.hintClassQuests then H:UpcomingClassQuests("advisor") end end) end
    A:AddProvider(ClassQuestHint)
    A:AddProvider(ClassReminders)
    A:AddProvider(TrainerHints)
    A:AddProvider(MountHint)
    A:AddProvider(ProfessionHints)
    LP:On("TRAINER_SHOW", function()
        C_Timer.After(0.5, function() H:LearnTrainerCosts() end)
        local key = "PRIO:TRAIN:" .. (LP:PlayerLevel() or 0)
        local p = LP.Planner.priority
        if p and p.key and (p.key:find("^PRIO:TRAIN") or p.key == "PRIO:RIDE" or p.key:find("^PRIO:PROF")) then
            LP.char.doneKeys[key] = true
            LP.Planner.priority = nil
            LP.Planner:Replan()
        end
    end)
    LP:On("PLAYER_LEVEL_UP", function() upcomingLevel = nil end)
    LP:On("COMPANION_LEARNED", function() LP.char.hasMount = true end)
end
