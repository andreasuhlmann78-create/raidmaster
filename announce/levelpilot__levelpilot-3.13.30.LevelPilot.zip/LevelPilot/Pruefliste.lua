-- LevelPilot - Prüfliste im Spiel (/lp prüfliste), nur Testmodus (Entscheid des Nutzers 16.11.2026 06:47, Supervisor 06:49)
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Nutzt den gemeinsamen Baustein GoldSentinelPruefliste.lua (unverändert aus shared/). Die Liste enthält die offenen Punkte
-- "im Client prüfen" (offen-levelpilot.txt, eigene Berichte), höchstens 14, in der Reihenfolge, in der man sie im Spiel am
-- besten nacheinander macht. Die meisten Punkte merken selbst, dass sie erledigt sind: M:Hit() steht im Code genau dort, wo
-- die Funktion wirklich benutzt wurde (Hinweis im Assistenten gezeigt, Plus am Händler gesetzt, Messung gemacht ...).
--
-- Testmodus: der Baustein fragt GoldSentinelDev. Seit 3.12.48 bringt LevelPilot GoldSentinelDev.lua (Version 2, Prüfsummen
-- statt Namen; Supervisor 16.11. 07:44) selbst mit; die neueste Kopie aller Addons gilt. LevelPilot meldet sich trotzdem erst
-- beim ersten Gebrauch an (Battle.net ist beim Laden manchmal noch nicht bereit).
-- Ohne Testmodus ist alles wirkungslos: keine Liste, kein Fenster, keine Rechnung (höchstens ein Versuch je 30 s).

local _, LP = ...
local L = LP.L
local M = {}
LP:RegisterModule("Pruefliste", M)

local function Now() return GetTime and GetTime() or 0 end
local function Perf() return LP.Perf end

-- Summe der Rechenzeit in den ersten 60 s nach dem Einloggen (alle Module), nil = keine Messung
local function LoginMs()
    local P = Perf()
    if not (P and P.stats) then return nil end
    local sum, any = 0, false
    for _, s in pairs(P.stats) do
        if (s.ln or 0) > 0 then sum, any = sum + (s.lms or 0), true end
    end
    return any and sum or nil
end
M.LoginMs = LoginMs

------------------------------------------------------------------------
-- Punkte (id = Kürzel aus offen-levelpilot.txt bzw. Testnummer, since = Version der Funktion)
------------------------------------------------------------------------
-- 3.12.88 TR-ALLE B (Entscheid des Nutzers 17.11.2026 07:36): jeder Punkt ohne Vorwissen verständlich – Wo, nummerierte Schritte
-- (ein Handgriff je Schritt, Befehle wörtlich), was du siehst, was es kostet. Die meisten Punkte haken sich beim normalen Spielen
-- selbst ab; niemand muss dafür warten. L-1 (Speicher-Messung) ist in SP1-M aufgegangen (beides über /lp protokoll).
M.POINTS = {
    { id = "T344", title = "Kartenrahmen messen (einmal)", since = "3.12.87",
      todo = "Wo: irgendwo im Spiel, nicht im Kampf. 1. Tippe in den Chat: /lp kartenrahmen  2. Tippe in den Chat: /reload "
          .. "(der Uploader schickt die Daten danach von selbst). Kosten: kein Gold, unter 1 Minute. Einmal in WoW Forever, einmal in Classic Era.",
      expect = "Im Chat steht: „LevelPilot: Kartenrahmen: … Karten gemessen und gespeichert – jetzt /reload, dann Upload.“ – mit einer Zahl "
          .. "um 50 (alle Zonen und beide Kontinente; WoW Forever: 54). Die Liste hakt sich dabei selbst ab." },
    { id = "CT-1", title = "Client-Test einmal ganz durchlaufen", since = "3.12.45",
      todo = "Wo: irgendwo, nicht im Kampf. 1. Tippe in den Chat: /lp clienttest  2. Es erscheinen bis zu 3 Fragen – klicke jeweils "
          .. "„OK“, „Nicht OK“ oder „Überspringen“. Kosten: kein Gold, etwa 2 Minuten.",
      expect = "Im Chat steht: „Client-Test fertig: OK … · FEHLER 0 · …“. Steht bei FEHLER eine Zahl über 0: tippe /lp diag und schick "
          .. "die Zeile, die mit CLIENTTEST beginnt.",
      auto = function()
          local d = LP.db and LP.db.clientTest
          if type(d) ~= "table" or type(d.lines) ~= "table" or d.version ~= LP.version then return nil end
          local bad, open = 0, 0
          for _, l in ipairs(d.lines) do
              if tostring(l):find("^T%d+ FEHLER") then bad = bad + 1 elseif tostring(l):find("^T%d+ %?") then open = open + 1 end
          end
          if bad > 0 then return false, ("%d von %d FEHLER (Zeile CLIENTTEST in /lp diag)"):format(bad, #d.lines) end
          if open > 0 or #d.lines == 0 then return nil end
          return true, ("%d Punkte, FEHLER 0"):format(#d.lines)
      end },
    { id = "T300", title = "Hinweis Erholt-Bonus bei Pause", since = "3.12.39",
      todo = "Wo: draussen, nicht in einem Gasthaus und nicht in einer Hauptstadt, nicht im Kampf. 1. Stehen bleiben.  2. Tippe in den "
          .. "Chat: /afk  3. Ins Guide-Fenster (Assistent) schauen.  4. Tippe nochmals: /afk. Kosten: kein Gold, 1 Minute.",
      expect = "Im Assistenten steht: „Pause? Im Gasthaus oder in einer Hauptstadt ausloggen …“ mit dem Knopf „Hinführen“ zum nächsten "
          .. "Gasthaus. Die Liste hakt sich dabei selbst ab." },
    { id = "T304", title = "Plus-Zeichen beim Händler", since = "3.12.42",
      todo = "Wo: bei einem Rüstungs- oder Waffenhändler (z. B. in einer Stadt). 1. Den Händler ansprechen (Rechtsklick).  2. Die Waren "
          .. "ansehen. Kosten: kein Gold (nichts kaufen), 1 Minute. Passiert auch von selbst beim nächsten Händlerbesuch.",
      expect = "Teile, die für deine Klasse besser sind als das, was du trägst, haben oben links ein grünes Plus. Stimmt ein Plus nicht: "
          .. "„Nicht OK“ und dazuschreiben, welches Teil." },
    { id = "T305", title = "Talent-Vorschlag im Assistenten", since = "3.12.43",
      todo = "Wo: irgendwo, ab Stufe 10 mit mindestens einem freien Talentpunkt. 1. Ins Guide-Fenster (Assistent) schauen.  2. Mit der "
          .. "Taste N das Talentfenster öffnen und das vorgeschlagene Talent suchen. Kosten: kein Gold, 1 Minute.",
      expect = "Im Assistenten steht unter „… Talentpunkt(e) frei“: „Vorschlag (Level-Build von LevelPilot): <Talent> x/y – <Grund>“, "
          .. "und dieses Talent gibt es im Talentfenster." },
    { id = "T362", title = "Vorschläge: Später und Nicht mehr", since = "3.13.0",
      todo = "Wo: in einer Hauptstadt mit Erste-Hilfe- oder Kochlehrer (z. B. Unterstadt), wenn du Erste Hilfe oder Kochen noch nicht kannst – "
          .. "sonst bei irgendeinem anderen Vorschlag des Assistenten. 1. Beim Vorschlag „Später“ klicken.  2. In derselben Stadt bleiben: "
          .. "er kommt nicht wieder.  3. Bei einem anderen Vorschlag „Nicht mehr“ klicken, dann /reload.  4. Zentrale > Assistent: unter "
          .. "„Ausgeblendete Vorschläge“ steht er, „wieder zeigen“ klicken. Kosten: kein Gold, 3 Minuten.",
      expect = "„Später“: weg, kommt in derselben Stadt und Stufe nicht wieder. „Nicht mehr“: auch nach /reload weg, steht in der Liste; "
          .. "nach „wieder zeigen“ kommt er beim nächsten Durchlauf (spätestens 30 s) wieder." },
    { id = "T302", title = "Hinweis Waffenmeister", since = "3.12.40",
      todo = "Wo: in der Stadt des passenden Waffenmeisters (seit 3.13.0 erscheint der Hinweis nur dort oder höchstens etwa 150 yd vom "
          .. "Lehrer). 1. Eine grüne (oder bessere) Waffe in die Tasche legen, deren Waffenart deine Klasse lernen darf, aber noch "
          .. "nicht kann.  2. Ins Guide-Fenster (Assistent) schauen. Kosten: kein Gold (Beute reicht), 1 Minute.",
      expect = "Im Assistenten steht: „<Waffe> in deiner Tasche: Waffenart „…“ noch nicht gelernt. Lernen beim Waffenmeister …“ mit Ort "
          .. "und Knopf „Hinführen“." },
    { id = "T301", title = "Hinweis Waffenfertigkeit", since = "3.12.39",
      todo = "Wo: irgendwo. 1. Eine Waffe anlegen, die du erst gerade gelernt hast (Fertigkeit noch tief).  2. Ins Guide-Fenster (Assistent) "
          .. "schauen. Kosten: kein Gold, 1 Minute.",
      expect = "Im Assistenten steht: „Waffenfertigkeit <Art>: x von y – du verfehlst öfter …“. Nach etwas Üben (Abstand unter 25) "
          .. "verschwindet der Hinweis." },
    { id = "T303", title = "Abgegraste Stelle", since = "3.12.41",
      todo = "Wo: an der Stelle einer Quest, bei der du Gegner töten oder etwas sammeln musst. 1. Dort 3 Minuten bleiben, ohne dass der "
          .. "Zähler der Quest steigt (nicht /afk).  2. Ins Guide-Fenster schauen.  3. Auf „Andere Stelle“ klicken. Kosten: kein Gold, 4 Minuten.",
      expect = "Im Assistenten steht: „Seit 3 Min. kein Fortschritt bei „…“ – Stelle abgegrast? …“. Nach dem Klick zeigt der Pfeil "
          .. "an eine andere Stelle." },
    { id = "GR1-K", title = "„+1 später abgeben“ in der Einzeilen-Ansicht", since = "3.12.33",
      todo = "Wo: irgendwo, mit einer fertigen Quest, die in einer anderen Zone abgegeben wird. 1. Tippe in den Chat: /lp kompakt  "
          .. "2. Die eine Zeile ansehen und mit der Maus darüber fahren.  3. Tippe nochmals: /lp kompakt (stellt zurück). Kosten: kein Gold, 1 Minute.",
      expect = "In der Zeile steht hinten grün „· +1 später abgeben“; mit der Maus darüber erscheint der Name der Quest." },
    { id = "UC-W1", title = "Weg in Unterstadt (Auktionshaus -> Lich)", since = "3.12.35",
      todo = "Wo: Unterstadt, beim Auktionshaus. 1. Ein Ziel im Magierviertel wählen (z. B. Quest 405 abgeben).  2. Auf den Pfeil und "
          .. "die Minikarte schauen. Kosten: kein Gold, 2 Minuten.",
      expect = "Der Pfeil zeigt eine Entfernung OHNE „(Weg unbekannt)“, und auf der Minikarte führt eine Linie durch die Stadt." },
    { id = "WM", title = "Wegmessung ganz durchlaufen", since = "3.12.46",
      todo = "Wo: Unterstadt/Donnerfels (das Messfenster führt dich). Braucht das kleine Hilfs-Addon GSWegMess (shared/messtest). "
          .. "1. Tippe in den Chat: /lp wegmessung  2. Dem kleinen Fenster folgen; am Ziel „Markieren & weiter“ klicken.  "
          .. "3. Am Ende /reload tippen. Kosten: kein Gold, etwa 20 Minuten.",
      expect = "Im Chat steht am Ende: „Wegmessung fertig (12 Markierungen) …“. Die Datei kommt mit dem Upload." },
    { id = "LAG1", title = "Krieger: erste Minute nach dem Einloggen", since = "3.12.24",
      todo = "Wo: mit deinem Krieger. 1. Einloggen und sofort loslaufen.  2. Nach 2 Minuten in den Chat tippen: /lp protokoll. "
          .. "Kosten: kein Gold, 3 Minuten.",
      expect = "Du kannst sofort laufen, nichts stockt. Die Liste misst selbst (Rechenzeit der ersten Minute unter 1000 Millisekunden) "
          .. "und hakt sich ab." },
    { id = "PF-A", title = "Allianz: Routenberechnung schnell genug", since = "3.12.32",
      todo = "Wo: mit einem Allianz-Charakter, z. B. im Wald von Elwynn. 1. 10 Minuten normal Quests machen.  2. In den Chat tippen: "
          .. "/lp protokoll. Kosten: kein Gold, 10 Minuten.",
      expect = "Die Liste prüft selbst: die längste Routenberechnung dauerte höchstens 16 Millisekunden (sonst steht dort rot "
          .. "„Fehler (erkannt)“)." },
    { id = "SP1-M", title = "Speicher nach 2–4 Stunden Spiel", since = "3.12.30",
      todo = "Wo: beim normalen Spielen. 1. 2 bis 4 Stunden spielen, ohne /reload.  2. In den Chat tippen: /lp protokoll speicher "
          .. "(misst den Speicher aller Addons; das Spiel steht dabei kurz). "
          .. "Kosten: kein Gold, nur normales Spielen.",
      expect = "Im Text stehen die Zeilen „SPEICHER LevelPilot … Speicher-Messung … ms“ und „… Bestand: Wegpunkte …“ (unter 50 000). "
          .. "Die Liste prüft es ab 2 Stunden Spielzeit selbst." },
}

-- 3.12.65 LW-5 E5: im Classic-Era-Client eine eigene Liste (die Forever-Punkte sind dort nicht prüfbar, und umgekehrt)
M.ERA_POINTS = {
    { id = "E5-1", title = "Classic Era: LevelPilot lädt", since = "3.12.65",
      todo = "Wo: Charakterauswahl von Classic Era. 1. Unten links auf „AddOns“ klicken.  2. Nachsehen, ob LevelPilot und "
          .. "LevelPilot Data ohne „veraltet“ in der Liste stehen.  3. Einloggen. Kosten: kein Gold, 1 Minute.",
      expect = "Das Guide-Fenster erscheint. Die Liste hakt sich selbst ab (Spielversion Classic Era).",
      auto = function()
          if not LP.IsEraClient() then return nil end
          local ui = GetBuildInfo and select(4, GetBuildInfo())
          return true, ("Interface %s, Spielversion era"):format(tostring(ui))
      end },
    { id = "E5-2", title = "Classic Era: eigene Daten", since = "3.12.65",
      todo = "Wo: irgendwo in Classic Era. Nichts zu tun – die Liste prüft beim Öffnen selbst, ob LevelPilot seine Daten getrennt "
          .. "für Classic Era speichert. Kosten: keine.",
      expect = "Der Punkt steht auf „erledigt (erkannt)“ mit „Bereich era“.",
      auto = function()
          if not LP.IsEraClient() then return nil end
          local ok = LP.accKind == "era" and type(LevelPilotDB) == "table" and type(LevelPilotDB.era) == "table" and LP.Acc() == LevelPilotDB.era
          return ok and true or false, ok and "Bereich era" or ("Bereich " .. tostring(LP.accKind))
      end },
    { id = "E5-3", title = "Classic Era: Questlog 20, kein Forever-Schalter", since = "3.12.65",
      todo = "Wo: irgendwo in Classic Era. 1. Tippe in den Chat: /lp  2. Oben auf den Reiter „Einstellungen“ klicken.  3. Den "
          .. "Abschnitt „Server & Dungeons“ ansehen. Kosten: kein Gold, 1 Minute.",
      expect = "Dort gibt es KEINEN Schalter „Server WoW Forever …“. Die Liste prüft zusätzlich selbst: Questlog fasst 20 Quests.",
      auto = function()
          if not LP.IsEraClient() then return nil end
          local max = LP.API and LP.API.MaxQuests and LP.API.MaxQuests()
          local sw = LP.Center and LP.Center.ForeverSwitchUseful and LP.Center.ForeverSwitchUseful()
          if max == 20 and sw == false then return true, "Questlog 20, Schalter aus" end
          return false, ("Questlog %s, Schalter %s"):format(tostring(max), tostring(sw))
      end },
    { id = "E5-4", title = "Classic Era: Route, Pfeil und Weg", since = "3.12.65",
      todo = "Wo: Classic Era, ein Charakter Stufe 1–10 in seiner Startzone. 1. Einloggen.  2. Ins Guide-Fenster schauen.  "
          .. "3. Ein paar Schritte dem Pfeil folgen. Kosten: kein Gold, 5 Minuten.",
      expect = "Das Guide-Fenster zeigt Quests der Startzone, der Pfeil zeigt zum ersten Schritt, und auf der Minikarte führt eine Linie "
          .. "den Wegen entlang." },
    { id = "E5-5", title = "Classic Era: Orte in Mulgore bzw. Sturmwind", since = "3.12.65",
      todo = "Wo: Classic Era, in Mulgore (Horde) oder Sturmwind (Allianz). 1. Tippe in den Chat: /lp navi briefkasten  "
          .. "2. Dem Pfeil folgen. Kosten: kein Gold, 3 Minuten.",
      expect = "Der Pfeil endet genau am Briefkasten." },
    { id = "E5-6", title = "Classic Era: Testroutine", since = "3.12.65",
      todo = "Wo: irgendwo in Classic Era, nicht im Kampf. 1. Tippe in den Chat: /lp testroutine alles  2. Weiterspielen oder "
          .. "weggehen – der Lauf wartet nie auf dich. Kosten: kein Gold, einige Minuten.",
      expect = "Im Chat steht am Ende: „Ergebnis: … von … bestanden …“ und keine Zeile „FEHLER: …“. Der Bericht kommt mit dem Upload." },
}
function M.Points() return LP.IsEraClient and LP.IsEraClient() and M.ERA_POINTS or M.POINTS end

------------------------------------------------------------------------
-- Anmeldung beim Baustein (erst beim ersten Gebrauch, siehe oben)
------------------------------------------------------------------------
M.RETRY = 30
M.list, M.nextTry = nil, 0                               -- angemeldete Liste (nil = noch nicht), nächster Versuch
function M.DB() return LevelPilotDB end                  -- Speicherort des Zustands (Feld "pruefliste"); Testroutine ersetzt ihn
function M.Baustein() return _G.GoldSentinelPruefliste end
function M:List(force)
    if self.list then return self.list end
    local PL = M.Baustein()
    if type(PL) ~= "table" or type(PL.Register) ~= "function" or type(PL.IsDev) ~= "function" then return nil end
    if not force and Now() < self.nextTry then return nil end
    self.nextTry = Now() + M.RETRY
    if not PL.IsDev() then return nil end
    self.list = PL:Register("LevelPilot", { db = function() return M.DB() end, version = LP.version, points = M.Points() })
    return self.list
end

-- Funktion wurde wirklich benutzt -> Punkt erledigt (nur wenn noch offen; OK/Nicht OK des Spielers bleiben)
-- Testroutine (trocken) und virtuelle Reise markieren nie etwas: nur echtes Spielen zählt
function M.Dry() return (LP.Act and LP.Act.dry) or (LP.Virtual and LP.Virtual.active) or false end
function M:Hit(id, note)
    if M.Dry() then return false end
    local l = self:List()
    if not l then return false end
    local done = l:Hit(id, note) == true
    if done then self:SaveHitReport(id, "OK", note) end
    return done
end
-- Messung zeigt einen Fehler -> "Fehler (erkannt)" (nur aus "offen"; ein späterer Hit macht den Punkt erledigt)
function M:Fail(id, note)
    if M.Dry() then return false end
    local l = self:List()
    if not (l and l.byId and l.byId[id]) then return false end
    if l:State(id) ~= "offen" then return false end
    local done = l:Set(id, "fehler", note) == true
    if done then self:SaveHitReport(id, "FEHLER", note) end
    return done
end

-- 3.12.89 TR-ALLE Nachtrag D2 (Supervisor 17.11.2026 19:15): je Punkt, der sich beim Spielen selbst abhakt (oder als Fehler
-- erkannt wird), EIN kleiner GSTEST-Bericht – damit das Ergebnis über den Uploader bei der Prüfung ankommt, nicht nur als
-- Chatzeile. Inhalt: Punkt, Name, Messwert, Version, Zeit, "erkannt beim Spielen". Nur Entwicklermodus (die Liste gibt es nur
-- dort), keine Frist, keine Sperre. Während der Testroutine nie in die echten Daten (nur, wenn ein Test ReportDB umleitet).
M.REPORT_DB_REAL = function() return _G.LevelPilotDB end
M.ReportDB = M.REPORT_DB_REAL
M.lastReportMs = nil
function M:SaveHitReport(id, status, note)
    local tr = LP.TestRoutine
    if tr and tr.running and M.ReportDB == M.REPORT_DB_REAL then return false end
    local GT, db = _G.GoldSentinelTest, M.ReportDB()
    if not (GT and type(GT.Begin) == "function" and type(db) == "table") then return false end
    local l = self.list
    local p = l and l.byId and l.byId[id]
    local title = type(p) == "table" and p.title or tostring(id)
    local t0 = type(debugprofilestop) == "function" and debugprofilestop() or nil
    local ok = pcall(function()
        local r = GT.Begin("LevelPilot", LP.version, db)
        r:Add(status, id, "Prüfliste", title, { ergebnis = note ~= nil and tostring(note) or nil, erkannt = "beim Spielen" })
        r:Finish({ bereich = "pruefliste", punkt = tostring(id), erkannt = "beim Spielen" })
    end)
    if t0 then M.lastReportMs = debugprofilestop() - t0 end
    return ok
end
function M:Check(id, good, note)
    if good then return self:Hit(id, note) end
    return self:Fail(id, note)
end

-- Beim Öffnen des Protokolls (/lp protokoll): Messwerte für L-1, LAG1, PF-A, SP1-M
M.SP1_SECS = 7200
function M:OnProtocol()
    if not self:List() then return end
    local mem = LP.Protocol and LP.Protocol.MemInfo and LP.Protocol.MemInfo() or {}
    local P = Perf()
    local login = LoginMs()
    if login and select(2, UnitClass("player")) == "WARRIOR" then
        self:Check("LAG1", login < 1000, ("erste 60 s zusammen %d ms"):format(math.floor(login)))
    end
    local route = P and P.stats and P.stats.route
    if route and (route.n or 0) > 0 and LP:PlayerFaction() == "Alliance" then
        local mx = route.max or 0
        self:Check("PF-A", mx <= (P.FRAME_MS or 16), ("Routenberechnung max %d ms bei %d Läufen"):format(math.floor(mx), route.n))
    end
    if P and P.loginT and Now() - P.loginT >= M.SP1_SECS then
        local G = LP.Graph
        local nodes = G and G.Count and G:Count() or 0
        self:Check("SP1-M", nodes < 50000 and mem.ms ~= nil, ("nach %d Min.: Wegpunkte %d, Speicher-Messung %s ms"):format(
            math.floor((Now() - P.loginT) / 60), nodes, mem.ms and ("%.0f"):format(mem.ms) or "fehlt"))
    end
end

-- Zeilen für den Testbericht (Protokoll/GSDIAG1): nur Kürzel und Zahlen
function M:ReportLines()
    local l = self:List()
    if not l then return {} end
    return l:ReportLines()
end

-- /lp prüfliste
function M:Open()
    if not LP:DevOnly() then return false end
    local l = self:List(true)
    if not l then
        LP:Reply(L["Prüfliste: Der gemeinsame Baustein meldet keinen Testmodus. Er braucht GoldSentinelDev (kommt mit RaidMaster oder einem anderen GoldSentinel-Addon) – /gsdev zeigt den Stand."])
        return false
    end
    return l:Open() == true
end

function M:Init() end
