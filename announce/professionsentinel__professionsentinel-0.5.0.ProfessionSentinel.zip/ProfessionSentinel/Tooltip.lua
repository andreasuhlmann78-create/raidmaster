local _, ns = ...
local L = ns.L

-- Adds "learned / not learned" info to recipe item tooltips (vendors, auction house, bags).

local function AddLines(tooltip, itemID)
    if not ns.Flavor or not ns.db or not ns.db.tooltip or not itemID then return end
    if tooltip.__psItem == itemID then return end
    local r = ns.ByRecipeItem[itemID]
    if not r then return end
    tooltip.__psItem = itemID
    local c = ns.Char()
    tooltip:AddLine(" ")
    local rank = c and c.profs[r.prof] and c.profs[r.prof].rank
    rank = ns.EffectiveRank(rank)
    if ns.IsLearned(r) then
        tooltip:AddLine("|cff3fc7ebProfessionSentinel:|r |cff7f7f7f" .. L.ALREADY_LEARNED .. "|r")
    elseif rank then
        local need = r.req or 0
        local col = (need > 1 and rank < need) and "ff4040" or "1eff00"
        tooltip:AddLine(string.format("|cff3fc7ebProfessionSentinel:|r |cff%s%s|r", col,
            L.NOT_LEARNED_YET .. (need > 1 and string.format(" (%s %d, %s %d)", L.REQ, need, L.YOUR_SKILL, rank) or "")))
    end
    if rank and ns.Lifeline then
        local calc = ns.Lifeline.Calc(r, rank)
        if calc and calc.textColored then tooltip:AddLine(L.LL_TITLE .. ": " .. calc.textColored, 0.8, 0.8, 0.8) end
    end
    local knownBy, missingBy = ns.Scan:CharsFor(r.spell, r.prof)
    local me = UnitName("player")
    local function others(list)
        local out = {}
        for _, n in ipairs(list) do if n ~= me then out[#out + 1] = n end end
        return out
    end
    knownBy, missingBy = others(knownBy), others(missingBy)
    if #knownBy > 0 then tooltip:AddLine(L.KNOWN_BY .. ": |cffffffff" .. table.concat(knownBy, ", ") .. "|r", 0.6, 0.6, 0.6, true) end
    if #missingBy > 0 then tooltip:AddLine(L.MISSING_BY .. ": |cffffffff" .. table.concat(missingBy, ", ") .. "|r", 0.6, 0.6, 0.6, true) end
    tooltip:Show()
end

local function ItemIDFromTooltip(tooltip, data)
    if data and data.id then return data.id end
    if tooltip.GetItem then
        local _, link = tooltip:GetItem()
        if link then return tonumber(link:match("item:(%d+)")) end
    end
end

local hooked = {}
local function HookTooltip(tt)
    if not tt or hooked[tt] then return end
    hooked[tt] = true
    tt:HookScript("OnTooltipCleared", function(self) self.__psItem = nil end)
    if not (TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall) then
        pcall(tt.HookScript, tt, "OnTooltipSetItem", function(self) AddLines(self, ItemIDFromTooltip(self)) end)
    end
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function()
    if not ns.Flavor then return end
    for _, tt in ipairs({ GameTooltip, ItemRefTooltip, ShoppingTooltip1, ShoppingTooltip2 }) do HookTooltip(tt) end
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tooltip, data)
            AddLines(tooltip, ItemIDFromTooltip(tooltip, data))
        end)
    end
end)
