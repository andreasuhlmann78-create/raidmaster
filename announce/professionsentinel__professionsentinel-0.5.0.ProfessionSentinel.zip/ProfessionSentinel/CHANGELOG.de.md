# ProfessionSentinel – Änderungen

## 0.5.0
- Gold in der Rangliste: „Leveln“ nach Gold pro Skillpunkt, neue Gruppe „Gold verdienen“ nach Netto-Gewinn pro Herstellung – auch graue Rezepte
- Materialkosten: Händlerware zum Händlerpreis, alles andere zum AH-Wert (auch selbst Gefarmtes); Produkt zum höheren Wert aus AH und Händler
- AH-Werte aus AHSentinel (sonst TSM oder Auctionator); ohne AH-Addon bleibt die Rangliste bei Material pro Skillpunkt
- Zeilen zeigen die Herkunft der Zutaten (AH / Händler / Farm) und „+10s 80c/Pkt“; der Tooltip schlüsselt jede Zutat mit Preis, Kosten, Verkaufswert und Netto auf
- Testmodus: „Testpreise“, um die Gold-Rangliste ohne AH-Scan auszuprobieren

## 0.4.0
- Rangliste zum Leveln: alle Rezepte, die bei deiner Fertigkeit Punkte bringen – gelernte und nicht gelernte – sortiert nach Material pro Skillpunkt (Material ÷ Chance auf einen Punkt)
- Neuer Reiter „Rangliste“ mit der ganzen Liste, Top 10 oben im Reiter „Rezepte“; noch nicht gelernte Rezepte mit [lernen] und Quelle
- Stern beim besten gelernten Rezept in Blizzards Rezeptliste, Hinweis mit Platz und Material pro Punkt am Berufsfenster (Klick wählt es aus)
- Rezepte weit über deiner Fertigkeit zählen nicht mehr als orange: fehlende Lernstufen werden geschätzt (WoW Forever über die Era-Stufe desselben Rezepts)
- Classic Era: Rezepte aus Season of Discovery entfernt (1267 echte Era-Rezepte)

## 0.3.0
- Neuer Reiter „Lehrer“: alle Lehrer des offenen Berufs nach Rang – Geselle (bis 150), Experte (bis 225), Fachmann (bis 300), Spezialisierungen – mit Zone, Koordinaten und Fraktion; dein nächster Rang ist markiert
- Händler und Drop-Gegner im Rezept-Tooltip jetzt mit Zone und Koordinaten
- Klick auf einen Lehrer setzt einen Wegpunkt, Rechtsklick auf ein Rezept einen Wegpunkt zum nächsten Händler (TomTom, sonst Kartenpin des Spiels)
- Zonennamen in der Sprache des Spiels; neue WoW-Forever-Gebiete (Insel Zephras, Flusslande) unterstützt
- Testmodus: Prüfungen für Lehrer und Wegpunkte, Knopf „Wegpunkt testen“

## 0.2.0
- Erkennt die Spielversion am Client und passt sich an: WoW Forever (eigene Rezepte und Fertigkeitsstufen – viele Rezepte werden früher grau) und Classic Era (klassisches Berufs- und Verzauberungsfenster)
- Lebenslinie: dünne Linie unter jedem Rezept (orange → gelb → grün → grau) mit Markierung deiner Fertigkeit und wie oft du bis zur nächsten Farbe herstellen musst – in Blizzards Rezeptliste und im Panel „Alle Rezepte“
- Tooltip zeigt Herstellungen bis Gelb, Grün und Grau
- Testmodus (/ps test): Diagnose, simulierte Fertigkeit, simuliert gelernt/nicht gelernt, Panel ohne Berufsfenster, Selbsttest (/ps selftest)
- /ps line schaltet die Lebenslinie an und aus
- Vertauschte Fertigkeitsstufen bei einzelnen Rezepten im Client korrigiert (z. B. Aufgeladene Schuppe von Onyxia)

## 0.1.0
- Erste Version für WoW Forever (Interface 16001)
- Knopf „Alle Rezepte“ im Berufsfenster, gegliedert wie die Kategorien im Spiel
- Gelernte Rezepte ausgegraut, fehlende in Seltenheitsfarbe
- Tooltips mit Fertigkeitsstufen, Reagenzien und Quelle (Lehrer, Händler, Drop, Quest)
- Tooltip bei Rezepten: gelernt oder nicht, auch für deine anderen Charaktere
- 2210 Rezepte, davon 934 neu in WoW Forever
