local _, ns = ...

-- Detects the player's professions (with skill rank) and which recipes are learned.
-- Works with the modern profession API (C_TradeSkillUI, WoW Forever) and the classic one
-- (GetTradeSkillInfo / GetCraftInfo, Classic Era), plus IsPlayerSpell as a passive check.

local Scan = {}
ns.Scan = Scan

-- WoW Forever uses its own child skill lines (e.g. 2945 Leatherworking) whose parent is the
-- classic skill line our data uses.
local PROF_ALIAS = {
    [2937] = 171, [2938] = 164, [2939] = 185, [2940] = 333, [2941] = 202, [2942] = 129,
    [2943] = 356, [2944] = 182, [2945] = 165, [2946] = 186, [2947] = 393, [2948] = 197,
}

function ns.ResolveProf(id)
    if not id then return nil end
    id = PROF_ALIAS[id] or id
    return (ns.ByProf[id] and #ns.ByProf[id] > 0) and id or nil
end

function ns.MatchProfession(name)
    if not name then return nil end
    for _, p in ipairs(ns.Professions) do
        if p.name == name or ns.ProfessionNamesEN[p.id] == name then return p.id end
    end
    return nil
end

-- Profession ranks -------------------------------------------------------
function Scan:UpdateProfessions()
    local c = ns.Char(); if not c then return end
    local found = {}
    if GetProfessions and GetProfessionInfo then
        local slots = { GetProfessions() }
        for i = 1, 6 do
            local idx = slots[i]
            if idx then
                local name, _, rank, maxRank, _, _, skillLine = GetProfessionInfo(idx)
                local id = ns.ResolveProf(skillLine) or ns.MatchProfession(name)
                if id then found[id] = { rank = rank or 0, max = maxRank or 0 } end
            end
        end
    end
    if GetNumSkillLines and GetSkillLineInfo then
        for i = 1, GetNumSkillLines() do
            local name, isHeader, _, rank, _, _, maxRank = GetSkillLineInfo(i)
            if not isHeader then
                local id = ns.MatchProfession(name)
                if id and not found[id] then found[id] = { rank = rank or 0, max = maxRank or 0 } end
            end
        end
    end
    if next(found) then c.profs = found end
end

-- Known recipes -------------------------------------------------------------
local function MarkKnown(spellID)
    local c = ns.Char()
    if c and spellID and ns.BySpell[spellID] and not c.known[spellID] then
        c.known[spellID] = true
        return true
    end
    return false
end

local function SpellFromLink(link)
    if not link then return nil end
    local id = link:match("enchant:(%d+)") or link:match("spell:(%d+)")
    return id and tonumber(id)
end

function Scan:PassiveCheck()
    local c = ns.Char(); if not c or not IsPlayerSpell then return end
    local changed = false
    for spell in pairs(ns.BySpell) do
        local ok, known = pcall(IsPlayerSpell, spell)
        if ok and known and not c.known[spell] then c.known[spell] = true; changed = true end
    end
    return changed
end

local function IsOwnTradeSkill()
    if C_TradeSkillUI then
        if C_TradeSkillUI.IsTradeSkillLinked and C_TradeSkillUI.IsTradeSkillLinked() then return false end
        if C_TradeSkillUI.IsTradeSkillGuild and C_TradeSkillUI.IsTradeSkillGuild() then return false end
        if C_TradeSkillUI.IsNPCCrafting and C_TradeSkillUI.IsNPCCrafting() then return false end
    end
    if IsTradeSkillLinked and IsTradeSkillLinked() then return false end
    return true
end

function Scan:ScanTradeSkill()
    if not IsOwnTradeSkill() then return false end
    local changed = false
    -- Modern API (WoW Forever)
    if C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs then
        local ok, ids = pcall(C_TradeSkillUI.GetAllRecipeIDs)
        if ok and ids then
            for _, id in ipairs(ids) do
                local info = C_TradeSkillUI.GetRecipeInfo(id)
                if info and info.learned and MarkKnown(id) then changed = true end
            end
        end
    end
    -- Classic API (Classic Era)
    if GetNumTradeSkills and GetTradeSkillInfo then
        for i = 1, GetNumTradeSkills() do
            local name, kind = GetTradeSkillInfo(i)
            if name and kind ~= "header" and kind ~= "subheader" then
                local spell = GetTradeSkillRecipeLink and SpellFromLink(GetTradeSkillRecipeLink(i))
                if not spell then
                    local r = ns.ByName[name:lower()]
                    spell = r and r.spell
                end
                if MarkKnown(spell) then changed = true end
            end
        end
    end
    -- Classic enchanting window
    if GetNumCrafts and GetCraftInfo then
        for i = 1, GetNumCrafts() do
            local name, _, kind = GetCraftInfo(i)
            if name and kind ~= "header" then
                local spell = GetCraftRecipeLink and SpellFromLink(GetCraftRecipeLink(i))
                if not spell then
                    local r = ns.ByName[name:lower()]
                    spell = r and r.spell
                end
                if MarkKnown(spell) then changed = true end
            end
        end
    end
    return changed
end

local function Refresh()
    if ns.UI and ns.UI.Refresh then ns.UI:Refresh() end
    if ns.Lifeline then ns.Lifeline.RefreshBlizzard() end
end
ns.RefreshAll = Refresh

function Scan:Init()
    local f = CreateFrame("Frame")
    local events = {
        "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE", "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_DATA_SOURCE_CHANGED",
        "CRAFT_SHOW", "CRAFT_UPDATE", "NEW_RECIPE_LEARNED", "LEARNED_SPELL_IN_TAB", "SKILL_LINES_CHANGED",
        "CHAT_MSG_SKILL",
    }
    for _, e in ipairs(events) do pcall(f.RegisterEvent, f, e) end
    local pending = false
    f:SetScript("OnEvent", function(_, event, arg1)
        if event == "NEW_RECIPE_LEARNED" and arg1 then MarkKnown(arg1) end
        if pending then return end
        pending = true
        C_Timer.After(0.5, function()
            pending = false
            Scan:UpdateProfessions()
            Scan:ScanTradeSkill()
            Scan:PassiveCheck()
            Refresh()
        end)
    end)
    C_Timer.After(2, function()
        Scan:UpdateProfessions()
        Scan:PassiveCheck()
        Refresh()
    end)
end

-- Helpers for the UI ------------------------------------------------------
function Scan:IsKnown(spell)
    local c = ns.Char()
    return c and c.known[spell] or false
end

function Scan:PlayerProfessions()
    local c = ns.Char()
    local list = {}
    if not c then return list end
    for _, p in ipairs(ns.Professions) do
        if c.profs[p.id] and ns.ByProf[p.id] and #ns.ByProf[p.id] > 0 then list[#list + 1] = p end
    end
    return list
end

function Scan:Rank(profID)
    local c = ns.Char()
    local p = c and c.profs[profID]
    return p and p.rank or nil, p and p.max or nil
end

-- Which characters (of this game version) know / miss a recipe (for tooltips)
function Scan:CharsFor(spell, profID)
    local knownBy, missingBy = {}, {}
    for key, c in pairs(ns.db.chars) do
        if not c.flavor or c.flavor == ns.Flavor then
            local short = key:match("^[^-]+") or key
            if c.known and c.known[spell] then
                knownBy[#knownBy + 1] = short
            elseif c.profs and c.profs[profID] then
                missingBy[#missingBy + 1] = short
            end
        end
    end
    table.sort(knownBy); table.sort(missingBy)
    return knownBy, missingBy
end
