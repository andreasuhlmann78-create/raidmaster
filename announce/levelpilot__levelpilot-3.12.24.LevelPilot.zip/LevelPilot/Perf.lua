-- LevelPilot - Rechenzeit: Messung je Modul, Notbremse, Arbeit in Portionen (3.12.24)
--
-- Befund 10. Nov. 2026: Auf einem Charakter mit dichtem Wegnetz (viel gelaufen, Orgrimmar/Brachland) fror das Spiel
-- nach dem Einloggen ein. Darum:
--   * LP.Jobs   – schwere Arbeit (Wegsuche, Wegnetz teilen/verbinden) laeuft in einer Coroutine, je Bild hoechstens
--                 BUDGET_MS Millisekunden, danach geht es im naechsten Bild weiter.
--   * LP.Perf   – misst die Rechenzeit je Modul (Route, Wegnetz, Netz-Empfang, Quests, Anzeige, ...), die ersten
--                 60 Sekunden nach dem Einloggen getrennt, fuer das Diagnose-Protokoll.
--   * Notbremse – dauert ein Aufruf laenger als BRAKE_MS oder summiert sich in 5 s mehr als BRAKE_SUM_MS, ruht die
--                 Funktion 60 s: eine Chatzeile, ein Eintrag LANGSAM im Diagnose-Protokoll (ohne Namen).
local ADDON, LP = ...
local L = LP.L

local function Clock()
    if debugprofilestop then return debugprofilestop() end
    return (os and os.clock and os.clock() or 0) * 1000
end

------------------------------------------------------------------------
-- Messung je Modul
------------------------------------------------------------------------
local Perf = { BRAKE_MS = 50, BRAKE_SUM_MS = 1000, BRAKE_WINDOW = 5, BRAKE_PAUSE = 60, LOGIN_SECS = 60 }
LP.Perf = Perf
Perf.clock = Clock                 -- Testroutine: eigene Uhr einsetzbar
Perf.stats = {}                    -- [modul] = { n, ms, max, ln, lms, lmax }
Perf.windows = {}                  -- [key] = { t0, sum }
Perf.paused = {}                   -- [key] = Ende der Pause (GetTime)
Perf.said = {}                     -- [key] = true: Chatzeile in dieser Sitzung schon gezeigt
Perf.loginT = nil

-- sichtbare Modulnamen (Schluessel der Sprachtabelle)
Perf.NAMES = {
    route = "Routenberechnung", path = "Wegsuche", graph = "Wegnetz", net = "Netz-Empfang",
    quests = "Questauswertung", ui = "Anzeige", nav = "Navigation", record = "Aufzeichnung", proto = "Protokoll",
    start = "Start",
}

local function Now() return GetTime and GetTime() or 0 end

function Perf.InLogin()
    return Perf.loginT ~= nil and Now() - Perf.loginT <= Perf.LOGIN_SECS
end

function Perf.Add(mod, ms)
    local s = Perf.stats[mod]
    if not s then s = { n = 0, ms = 0, max = 0, ln = 0, lms = 0, lmax = 0 } Perf.stats[mod] = s end
    s.n, s.ms = s.n + 1, s.ms + ms
    if ms > s.max then s.max = ms end
    -- Testroutine (trocken): zaehlt nicht zu den ersten 60 s nach dem Einloggen
    if Perf.InLogin() and not (LP.Act and LP.Act.dry) then
        s.ln, s.lms = s.ln + 1, s.lms + ms
        if ms > s.lmax then s.lmax = ms end
    end
end

function Perf.Paused(key)
    local t = Perf.paused[key]
    if not t then return false end
    if Now() >= t then Perf.paused[key] = nil return false end
    return true
end

-- Notbremse pruefen; info: kurze Angaben fuer das Protokoll (Ziele, Punkte, Zone) – nie Namen
function Perf.Check(key, ms, info)
    local now = Now()
    local w = Perf.windows[key]
    if not w or now - w.t0 > Perf.BRAKE_WINDOW then w = { t0 = now, sum = 0 } Perf.windows[key] = w end
    w.sum = w.sum + ms
    local over = ms > Perf.BRAKE_MS and ("%d ms"):format(math.floor(ms))
        or (w.sum > Perf.BRAKE_SUM_MS and ("%d ms in %d s"):format(math.floor(w.sum), Perf.BRAKE_WINDOW))
    if not over then return false end
    Perf.paused[key] = now + Perf.BRAKE_PAUSE
    Perf.windows[key] = nil
    Perf.brakes = (Perf.brakes or 0) + 1
    local name = L[Perf.NAMES[key] or key]
    if not Perf.said[key] and not (LP.Virtual and LP.Virtual.active) then
        Perf.said[key] = true
        LP:Print(L("%s pausiert (zu aufwendig) – weiter in 60 Sekunden.", name))
    end
    if LP.Protocol and LP.Protocol.Add then
        local _, _, _, map = LP.Geo and LP.Geo:Player()
        pcall(LP.Protocol.Add, LP.Protocol, "slow",
            ("%s %s%s · Zone %s · Pause 60 s"):format(Perf.NAMES[key] or key, over, info and (" · " .. info) or "", tostring(map or "?")))
    end
    return true
end

-- Funktion messen; brake = true: Notbremse fuer diesen Schluessel. Rueckgabe wie fn (oder nichts, wenn pausiert).
function Perf.Run(key, mod, brake, fn, ...)
    if brake and Perf.Paused(key) and (Perf.testBrake or not (LP.Act and LP.Act.dry)) then return end
    local t0 = Perf.clock()
    local r = { fn(...) }
    local ms = Perf.clock() - t0
    Perf.Add(mod, ms)
    -- waehrend der Testroutine keine Notbremse (ausser im Test der Notbremse selbst)
    if brake and (Perf.testBrake or not (LP.Act and LP.Act.dry)) then Perf.Check(key, ms, Perf.info and Perf.info(key)) end
    return unpack(r)
end

-- Methode einer eigenen Tabelle ummanteln (nie Blizzard-Funktionen). bypass(args): true = ohne Bremse (Nutzer klickt)
function Perf.Wrap(tbl, method, key, mod, brake, bypass)
    if type(tbl) ~= "table" or type(tbl[method]) ~= "function" then return end
    local orig = tbl[method]
    if tbl["_perf_" .. method] then return end
    tbl["_perf_" .. method] = orig
    tbl[method] = function(...)
        if bypass and bypass(...) then return Perf.Run(key, mod, false, orig, ...) end
        return Perf.Run(key, mod, brake, orig, ...)
    end
end

-- Zeilen fuer das Diagnose-Protokoll
function Perf.DiagLines()
    local out = {}
    local keys = {}
    for k in pairs(Perf.stats) do keys[#keys + 1] = k end
    table.sort(keys, function(a, b) return Perf.stats[a].ms > Perf.stats[b].ms end)
    local parts, login = {}, {}
    for _, k in ipairs(keys) do
        local s = Perf.stats[k]
        parts[#parts + 1] = ("%s %d ms/%d× max %d"):format(Perf.NAMES[k] or k, math.floor(s.ms), s.n, math.floor(s.max))
        if s.ln > 0 then login[#login + 1] = ("%s %d ms max %d"):format(Perf.NAMES[k] or k, math.floor(s.lms), math.floor(s.lmax)) end
    end
    out[#out + 1] = "ZEIT " .. (#parts > 0 and table.concat(parts, " · ") or "keine Messung")
    out[#out + 1] = "ZEIT erste 60 s nach dem Einloggen: " .. (#login > 0 and table.concat(login, " · ") or "keine Messung")
    local paused = {}
    for k in pairs(Perf.paused) do if Perf.Paused(k) then paused[#paused + 1] = Perf.NAMES[k] or k end end
    out[#out + 1] = ("ZEIT Notbremse %d× · pausiert: %s · Hintergrund-Arbeit: %d laufend, %d fertig, längste Portion %d ms")
        :format(Perf.brakes or 0, #paused > 0 and table.concat(paused, ", ") or "nichts", LP.Jobs.Count(),
            LP.Jobs.done or 0, math.floor(LP.Jobs.maxSlice or 0))
    return out
end

-- Angaben fuer LANGSAM (ohne Namen)
function Perf.info(key)
    local P, G = LP.Planner, LP.Graph
    local nodes = G and G.Count and G:Count() or 0
    if key == "route" and P then
        return ("Aufgaben %d · Kandidaten %d · Questlog %d · Wegpunkte %d"):format(#(P.lastTasks or {}),
            P.diag and P.diag.candidates or 0, P.inLog and (function() local n = 0 for _ in pairs(P.inLog) do n = n + 1 end return n end)() or 0, nodes)
    end
    return ("Wegpunkte %d"):format(nodes)
end

-- nach dem Start der Module: Hauptfunktionen messen (eigene Tabellen)
function Perf.Setup()
    if Perf.ready then return end
    Perf.ready = true
    local P = LP.Planner
    -- Routenberechnung: Notbremse; ein Klick des Nutzers (verbose) rechnet immer
    Perf.Wrap(P, "Replan", "route", "route", true, function(_, verbose) return verbose end)
    Perf.Wrap(P, "BuildCandidates", "quests", "quests", false)
    Perf.Wrap(LP.Comm, "Receive", "net", "net", true)
    Perf.Wrap(LP.UI, "Refresh", "ui", "ui", false)
    Perf.Wrap(LP.Engine, "CheckSteps", "nav", "nav", false)
    Perf.Wrap(LP.Nav, "Recalc", "nav", "nav", false)
    Perf.Wrap(LP.Recorder, "SamplePath", "record", "record", false)
    if LP.Protocol then
        for _, m in ipairs({ "CheckZone", "CheckFocus", "CheckStep" }) do Perf.Wrap(LP.Protocol, m, "proto", "proto", false) end
    end
end

------------------------------------------------------------------------
-- Arbeit in Portionen
------------------------------------------------------------------------
local Jobs = { BUDGET_MS = 4, list = {}, done = 0, maxSlice = 0 }
LP.Jobs = Jobs
Jobs.sync = false            -- true: sofort und am Stueck rechnen (Testumgebung, virtuelle Reise)

function Jobs.Count()
    local n = 0
    for _ in pairs(Jobs.list) do n = n + 1 end
    return n
end

function Jobs.Running(name) return Jobs.list[name] ~= nil end

-- Ist der laufende Code eine Portion? (fuer LP:Yield)
function Jobs.Current()
    local co = coroutine.running()
    if not co then return nil end
    for _, j in pairs(Jobs.list) do if j.co == co then return j end end
    return nil
end

-- name: eindeutiger Name (ein neuer Auftrag gleichen Namens ersetzt den alten); fn laeuft in einer Coroutine;
-- done(ok, ...) bekommt das Ergebnis. mod: Modul fuer die Zeitmessung. kinds: Stellen, an denen abgegeben werden
-- darf (LP:Yield(kind)); nur Stellen, die sicher nicht in einem pcall liegen (Lua 5.1 kann dort nicht abgeben).
function Jobs.Start(name, mod, fn, done, kinds)
    if Jobs.sync or not coroutine or (LP.Virtual and LP.Virtual.active) then
        local t0 = Clock()
        local res = { pcall(fn) }
        Jobs.lastCpu = Clock() - t0
        Perf.Add(mod, Jobs.lastCpu)
        if done then done(unpack(res)) end
        return
    end
    Jobs.list[name] = { co = coroutine.create(fn), done = done, mod = mod, started = Now(), slices = 0, cpu = 0,
                        kinds = kinds or { graph = true } }
end

function Jobs.Cancel(name) Jobs.list[name] = nil end

-- ein Bild: jede Portion bekommt ihren Anteil am Budget
function Jobs.Step()
    local n = Jobs.Count()
    if n == 0 then return end
    local each = Jobs.BUDGET_MS / n
    for name, j in pairs(Jobs.list) do
        j.sliceStart, j.budget = Clock(), each
        local res = { coroutine.resume(j.co) }
        local ms = Clock() - j.sliceStart
        j.slices, j.cpu = j.slices + 1, j.cpu + ms
        Perf.Add(j.mod, ms)
        if ms > Jobs.maxSlice then Jobs.maxSlice = ms end
        if coroutine.status(j.co) == "dead" then
            if Jobs.list[name] == j then Jobs.list[name] = nil end
            Jobs.done = Jobs.done + 1
            Jobs.lastCpu = j.cpu
            if j.done then
                local ok, err = pcall(j.done, unpack(res))
                if not ok then LP:Error(name, err) end
            end
        end
    end
end

-- in langen Schleifen aufrufen: gibt an das Spiel ab, wenn das Budget dieses Bildes verbraucht ist
function Jobs.Yield(kind)
    local j = Jobs.Current()
    if not j or (kind and not j.kinds[kind]) then return false end
    if Clock() - (j.sliceStart or 0) >= (j.budget or Jobs.BUDGET_MS) then
        coroutine.yield()
        return true
    end
    return false
end

-- Antrieb: jedes Bild
local driver = CreateFrame and CreateFrame("Frame")
if driver then
    driver:SetScript("OnUpdate", function() Jobs.Step() end)
    LP.drivers = LP.drivers or {}
    LP.drivers.jobs = driver
end
