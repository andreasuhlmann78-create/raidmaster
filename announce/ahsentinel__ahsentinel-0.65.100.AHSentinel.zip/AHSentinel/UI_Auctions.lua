if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.4 - Tab "Auktionen" (deine eigenen Auktionen)
--   * Status je Auktion: günstigstes / gleich / unterboten / verkauft
--   * "Unterbietung prüfen": aktuelle Preise aller deiner Items laden
--   * Abbrechen per Klick (X oder "Nächste unterbotene abbrechen")
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local STATUS_COLOR = {
    ["günstigstes"] = "33dd55", ["gleich"] = "ffcc33", ["unterboten"] = "ff5544", ["liegen"] = "999999", ["teurer"] = "66ccff",
    ["verkauft"] = "00d1d1", ["?"] = "888888",
}
local STATUS_ORDER = { ["teurer"] = 0, ["unterboten"] = 1, ["liegen"] = 2, ["gleich"] = 3, ["?"] = 4, ["günstigstes"] = 5, ["verkauft"] = 6 }

local function FormatTimeLeft(sec)
    if not sec then return "-" end
    if sec >= 3600 then return string.format(L["%d Std."], math.floor(sec / 3600)) end
    return string.format(L["%d Min."], math.max(1, math.floor(sec / 60)))
end

local function BuildAuctions(parent)
    local p = CreateFrame("Frame", nil, parent)
    local Se = A.Seller

    local function setMessage(ok, msg)
        if not msg then return end
        p.message:SetText(msg)
        p.message:SetTextColor(unpack(ok and C.textDim or C.red))
    end

    local head = UI:TabTitle(p, L["Meine Auktionen"], "auctions")
    p.summary = UI:Label(p, "", "GameFontHighlightSmall", C.textDim)
    p.summary:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -4)
    p.summary:SetWidth(900)

    p.refreshBtn = UI:Button(p, L["Aktualisieren"], 120, 24, function()
        setMessage(Se:QueryOwned())
    end)
    p.refreshBtn:SetPoint("TOPLEFT", 0, -44)
    p.refreshBtn.tooltip = L["Deine Auktionen neu vom Server laden"]

    p.checkBtn = UI:Button(p, L["Unterbietung prüfen"], 160, 24, function()
        setMessage(Se:CheckUndercuts())
    end)
    p.checkBtn:SetPoint("LEFT", p.refreshBtn, "RIGHT", 6, 0)
    p.checkBtn.tooltip = L["Lädt die aktuellen Angebote aller Items, die du anbietest,\nund zeigt, wo dich jemand unterboten hat."]

    p.cancelNextBtn = UI:Button(p, L["Nächste unterbotene abbrechen"], 230, 24, function()
        setMessage(Se:CancelNextUndercut())
    end, "danger")
    p.cancelNextBtn:SetPoint("LEFT", p.checkBtn, "RIGHT", 6, 0)
    -- Gebühren klassisch (auch Forever): beim Abbrechen ist die Einzahlung weg
    p.cancelNextBtn.tooltip = L["Ein Klick bricht EINE unterbotene Auktion ab (die Einstellgebühr ist dann verloren).\nDanach im Tab Verkaufen neu und günstiger einstellen."]

    -- abgelaufene / abgebrochene Auktionen (aus der Post) wieder einstellen: ein Klick = eine Auktion
    p.repostBtn = UI:Button(p, "", 190, 24, function()
        setMessage(A.Extras:RepostStep())
        p:Refresh()
    end, "primary")
    p.repostBtn:SetPoint("LEFT", p.cancelNextBtn, "RIGHT", 6, 0)
    p.repostBtn.tooltip = L["Stellt Items wieder ein, die als abgelaufene oder abgebrochene Auktion\nper Post zurückgekommen sind (nach 'AH-Post abholen' am Briefkasten).\nEin Klick = eine Auktion, Preis: aktueller Vorschlag (unterbieten), mit Preisschutz."]

    p.message = UI:Label(p, "", "GameFontHighlightSmall", C.textDim)
    p.message:SetPoint("LEFT", p.repostBtn, "RIGHT", 10, 0)
    p.message:SetPoint("RIGHT", p, "RIGHT", 0, 0)

    p.table = UI:Table(p, {
        columns = {
            { key = "name", title = L["Item"], width = 220 },
            { key = "qty", title = L["Menge"], width = 60, align = "RIGHT" },
            { key = "unitPrice", title = L["Preis/Stück"], width = 120, align = "RIGHT" },
            { key = "lowest", title = L["Günstigstes"], width = 120, align = "RIGHT",
              tooltip = L["Günstigstes fremdes Angebot (nach 'Unterbietung prüfen')"] },
            { key = "buyout", title = L["Gesamt"], width = 120, align = "RIGHT" },
            { key = "timeLeft", title = L["Restzeit"], width = 80, align = "RIGHT" },
            { key = "status", title = L["Status"], width = 110 },
        },
        rows = 16,
        rowHeight = 22,
        idKey = "auctionID",
        sortKey = "status",
        sortAsc = true,
        cell = function(o, key)
            if key == "name" then return UI.ItemName(o) end
            if key == "qty" then return tostring(o.qty) end
            if key == "timeLeft" then return o.sold and "-" or FormatTimeLeft(o.timeLeft) end
            if key == "status" then
                local s = o.status or "?"
                local txt = (s == "liegen") and L["unterboten – liegen lassen"] or (s == "teurer" and L["teurer möglich"]) or L[s]
                if s == "?" and o.waitWhy then txt = o.waitWhy end                     -- AB1: Grund statt "?"
                return "|cff" .. (STATUS_COLOR[s] or "888888") .. txt .. "|r"
            end
            return A:FormatMoney(o[key])
        end,
        sortValue = function(o, key)
            if key == "name" then return string.lower(UI.ItemName(o)) end
            if key == "status" then return STATUS_ORDER[o.status or "?"] or 9 end
            return o[key]
        end,
        onClick = function(o) end,
        -- H1: Rechnung "Abbrechen lohnt?" im Tooltip der Zeile
        tooltipLines = function(o, tt)
            -- Stufe 2 L6: teurer neu einstellen
            if o.status == "teurer" and o.relist then
                tt:AddLine(" ")
                tt:AddLine(string.format(L["Abbrechen und für %s neu einstellen"], A:FormatMoney(o.relist.price)), 0.4, 0.8, 1)
                tt:AddLine(string.format(L["Mehrerlös %s, Einzahlung %s (X bricht ab, danach im Tab Verkaufen neu einstellen)"],
                    A:FormatMoney(o.relist.gain or 0), A:FormatMoney(o.relist.deposit or 0)), 0.9, 0.9, 0.9)
                return
            end
            local c = o.cancelCalc
            if not (c and (o.status == "unterboten" or o.status == "liegen")) then return end
            tt:AddLine(" ")
            tt:AddLine(o.status == "liegen" and L["Abbrechen lohnt nicht – liegen lassen"] or L["Abbrechen lohnt sich"],
                o.status == "liegen" and 0.7 or 1, o.status == "liegen" and 0.7 or 0.35, o.status == "liegen" and 0.7 or 0.3)
            tt:AddLine(string.format(L["Mehrerlös neu einstellen: %s"], A:FormatMoney(c.gain)), 0.9, 0.9, 0.9)
            tt:AddLine(string.format(L["Kosten: Einzahlung %s weg + neue Einzahlung × (1 − %d %%) / %d %% = %s"],
                A:FormatMoney(c.deposit), math.floor(c.p * 100 + 0.5), math.floor(c.p * 100 + 0.5), A:FormatMoney(c.cost)), 0.9, 0.9, 0.9)
        end,
        action = {
            text = "X", width = 26,
            tooltip = L["Auktion abbrechen (Einstellgebühr ist verloren)"],
            onClick = function(o) setMessage(Se:Cancel(o.auctionID, o)) end,         -- VF5: genau diese Zeile
        },
        emptyText = L["Keine eigenen Auktionen.\nIm Tab Verkaufen Items einstellen."],
    })
    p.table:Fill(0, -80, 0, 22)
    -- S3 (Anweisung 10.11.): Fusszeile mit der Summe der sichtbaren Zeilen je Status
    p.footer = UI:Label(p, "", "GameFontHighlightSmall", C.textDim)
    p.footer:SetPoint("BOTTOMLEFT", 4, 4)
    p.footer:SetPoint("BOTTOMRIGHT", -4, 4)
    p.footer:SetJustifyH("LEFT")
    -- S4: Tooltip am Kopf (Shift: heute insgesamt aus der Buchhaltung)
    p.summaryHit = CreateFrame("Frame", nil, p)
    p.summaryHit:SetPoint("TOPLEFT", p.summary, "TOPLEFT", 0, 2)
    p.summaryHit:SetPoint("BOTTOMRIGHT", p.summary, "BOTTOMRIGHT", 0, -2)
    p.summaryHit:EnableMouse(true)
    p.summaryHit:SetScript("OnEnter", function(self)
        UI:AnchorTooltip(self)
        for i, l in ipairs(p:SummaryTooltipLines(IsShiftKeyDown and IsShiftKeyDown())) do
            if i == 1 then GameTooltip:SetText(l, 1, 1, 1) else GameTooltip:AddLine(l, 0.9, 0.9, 0.9, true) end
        end
        GameTooltip:Show()
    end)
    p.summaryHit:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Summen der Liste: aktiv (alle nicht verkauften) / unterboten / verkauft, je Anzahl und Betrag;
    -- received = Σ floor(Gesamt × (1 − AH-Anteil)) je verkaufter Auktion (S1: Einzahlungen zählen nicht)
    function p:Totals(list)
        local t = { active = 0, value = 0, under = 0, underValue = 0, sold = 0, soldSum = 0, received = 0 }
        local keep = 100 - math.floor(A:CutPct() * 100 + 0.5)
        for _, o in ipairs(list or {}) do
            local b = o.buyout or 0
            if o.sold then
                t.sold, t.soldSum = t.sold + 1, t.soldSum + b
                t.received = t.received + math.floor(b * keep / 100)
            else
                t.active, t.value = t.active + 1, t.value + b
                if o.status == "unterboten" then t.under, t.underValue = t.under + 1, t.underValue + b end
            end
        end
        return t
    end

    function p:SummaryTooltipLines(shift)
        local lines = { L["Meine Auktionen"] }
        lines[#lines + 1] = L["Verkauft: Summe der Sofortkaufpreise; erhalten = je Auktion Gesamt × 0,95 (abgerundet). Einzahlungen zählen nicht."]
        local Le = A.Ledger
        if shift and Le and Le.Summary then
            local ok, s = pcall(Le.Summary, Le, "today")
            if ok and s then
                lines[#lines + 1] = string.format(L["heute verkauft insgesamt %s (aus der Buchhaltung)"], A:FormatMoney(s.gross or 0))
            end
        elseif not shift then
            lines[#lines + 1] = L["Shift: heute verkauft insgesamt (aus der Buchhaltung)"]
        end
        return lines
    end

    function p:Refresh()
        local open = A:IsAHOpen()
        for _, b in ipairs({ self.refreshBtn, self.checkBtn, self.cancelNextBtn }) do b:SetActive(open) end
        local Se2 = A.Seller
        if Se2.batch and Se2.batch.repost then
            local cur, pos, total = Se2:BatchCurrent()
            self.repostBtn:SetText(cur and string.format(L["Neu einstellen: %s (%d/%d)"], cur.name, pos, total) or L["Neu einstellen"])
            self.repostBtn:SetActive(open)
        else
            local n = A.Extras:RepostCount()
            self.repostBtn:SetText(string.format(L["Neu einstellen (%d)"], n))
            self.repostBtn:SetActive(open and n > 0)
        end
        local list = Se.owned
        self.table:SetData(list, true)
        local t = self:Totals(list)
        local text
        if t.soldSum > 0 then
            -- S1/S2 (Anweisung 10.11.): "8 verkauft (4g 42s 77c, erhalten 4g 20s 60c)" - gleiches Format wie "aktiv (Wert …)"
            text = string.format(L["%d aktiv (Wert %s)   |   %d unterboten   |   %d verkauft (%s, erhalten %s)"], t.active, A:FormatMoney(t.value),
                Se:CountByStatus("unterboten"), Se:CountByStatus("verkauft"), A:FormatMoney(t.soldSum), A:FormatMoney(t.received))
        else
            text = string.format(L["%d aktiv (Wert %s)   |   %d unterboten   |   %d verkauft"], t.active, A:FormatMoney(t.value),
                Se:CountByStatus("unterboten"), Se:CountByStatus("verkauft"))
        end
        if #list > 0 then
            self.footer:SetText(string.format(L["Summe der Liste: aktiv %s (%d) · unterboten %s (%d) · verkauft %s (%d)"],
                A:FormatMoney(t.value), t.active, A:FormatMoney(t.underValue), t.under, A:FormatMoney(t.soldSum), t.sold))
        else
            self.footer:SetText("")
        end
        if #Se.queue > 0 or Se.search then
            text = text .. "   |   " .. string.format(L["|cffffcc33prüfe Preise ... (%d offen)|r"], #Se.queue + (Se.search and 1 or 0))
        end
        if not open then text = L["|cffff5544Auktionshaus öffnen, um deine Auktionen zu sehen.|r"] .. "   " .. text end
        self.summary:SetText(text)
    end

    -- Rückmeldung nach dem Abbrechen (sonst bliebe "Wird abgebrochen ..." stehen)
    A:On("AUCTION_CANCELLED", function(c)
        if c and c.name and p.message then
            setMessage(true, string.format(A:IsForever() and L["Abgebrochen: %dx %s (AH-Gebühr anteilig zurück)"]
                or L["Abgebrochen: %dx %s (Einstellgebühr verloren)"], c.qty or 1, c.name))
        end
    end)

    return p
end

UI:RegisterTab("auctions", "Auktionen", 3.7, BuildAuctions)
