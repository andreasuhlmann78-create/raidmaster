-- ThreatSentinel - Threat.lua
-- Herzstück: wertet für jede Namensplakette aus, wer den Mob hat, und steuert Anzeige und Warnungen.
--
-- Zustände eines Mobs:
--   IDLE       nicht im Kampf mit der Gruppe
--   HELD       du hältst ihn
--   WARN       du hältst ihn, aber ein DD ist nahe dran
--   OTHERTANK  ein anderer Tank hält ihn
--   PETHELD    ein Begleiter hält ihn (gilt als sicher)
--   CC         Mob ist kontrolliert und wird ignoriert
--   LOOSE      Mob greift einen DD oder Heiler an
--
-- WoW Forever kann Werte im Kampf schützen. Dann greifen Ersatzwege (siehe Kommentare),
-- und kein geschützter Wert wird je verglichen oder verrechnet.

local ADDON, ns = ...
local API = ns.API   -- Blizzard-Funktionen nur über ns.API (API.lua)
local L = ns.L

local T = {}
ns.Threat = T
table.insert(ns.modules, T)

local mobs = {}
ns.mobs = mobs
ns.owners = {}

local active = false
local TICK = 0.25
-- Zeitbudget je Durchlauf für die Bewertung der Mobs (2.5.17, TU1-L04t). Uhr ersetzbar (Testroutine, keine Blizzard-Funktion)
T.BUDGET_MS = 3
T.MIN_EVAL = 4
function T.Clock() return debugprofilestop and debugprofilestop() or 0 end

local ROLE_ORDER = { HEALER = 1, DAMAGER = 2, PET = 3 }

function T:Login()
	for _, plate in ipairs(API.C_NamePlate.GetNamePlates() or {}) do
		local u = plate.namePlateUnitToken
		if u then mobs[u] = { unit = u } end
	end
	-- gemessen: dauert ein Durchlauf länger als ein Frame, steht das im Diagnose-Protokoll (LANGSAM)
	C_Timer.NewTicker(TICK, function() if not ns.routineRunning then ns.Timed("Durchlauf (T:Tick)", T.Tick, T) end end)
end

------------------------------------------------------------
-- Hinweistext unter einer losen Plakette
------------------------------------------------------------
function T:BuildHint(unit, m)
	local db = ns.db
	m.hint, m.far, m.tauntCD = nil, false, 0
	if m.claimedBy then m.hint = string.format(L.CLAIMED, m.claimedBy) return end
	if m.muted then m.hint = string.format(L.OWNER, m.ownerName or "?") return end

	local spell = ns.tauntSpell
	if spell then
		m.tauntCD = ns.SpellCD(spell)
		-- Rechtschaffene Verteidigung zielt auf den Mitspieler: Reichweite zu ihm prüfen
		local rangeUnit = (ns.tauntMode == "friendly") and (unit .. "target") or unit
		if ns.SpellInRange(spell, rangeUnit) == false then
			m.far = true
			m.hint = L.TOO_FAR
			return
		end
	end
	-- nur wenn der eigene Anteil lesbar ist (sonst kein "Zerreissen reicht")
	if m.myPull and m.myPull >= db.deficitThreshold then
		if ns.class == "WARRIOR" then m.hint = L.DEFICIT_WARRIOR
		elseif ns.class == "DRUID" and not ns.isModern then m.hint = L.DEFICIT_DRUID
		else m.hint = L.DEFICIT_OTHER end
		return
	end
	if not spell then return end
	if ns.tauntMode == "seal" and not ns:HasSealOfFury() then
		m.hint = L.HINT_NO_SEAL
		return
	end
	if m.tauntCD > 0 then
		local other = ns.Sync:OtherTankReady()
		if other then
			m.hint = string.format(L.OTHER_TANK_READY, other)
		else
			m.hint = string.format(L.TAUNT_CD, math.ceil(m.tauntCD))
		end
	else
		m.hint = L.TAUNT_READY
	end
end

------------------------------------------------------------
-- Kontrolle und Rüstung zerreissen am Mob
------------------------------------------------------------
local function ReadMobAuras(unit, key)
	local cc, sunder, readable, ccName = false, 0, true, nil
	for i = 1, 40 do
		local ok, name, count = pcall(ns.Aura, unit, i, "HARMFUL")
		if not ok or ns.IsSecret(name, "auras") then readable = false break end
		if not name then
			-- moderne API: leere Liste im Kampf = unbekannt (dann zählt der Ersatz)
			if i == 1 and ns.AuraEmptyUnknown() then readable = false end
			break
		end
		if ns.ccNames[name] then cc = true; ccName = name end
		if name == ns.sunderName then
			count = ns.Safe(count, 1)
			sunder = (type(count) == "number" and count > 0) and count or 1
		end
	end
	if readable then
		ns:Compat("mobAuras", "ok")
		return cc, sunder, ccName
	end
	-- Ersatz: aus den Zaubern der Gruppe und den eigenen Zerreissen mitgezählt
	ns:Compat("mobAuras", "fallback")
	return ns.Track:IsCC(key), ns.Track:Sunder(key), "tracker"
end

------------------------------------------------------------
-- Wer hat den Mob? Rückgabe: tankUnit, myPull, maxOther, warnByStatus
------------------------------------------------------------
local function ReadThreat(unit)
	local tankUnit, myPull, maxOther, warnByStatus = nil, nil, 0, false
	local any, apiFailed, valuesSecret = false, false, false
	-- Gruppen-Ansicht: ich bin nicht der Tank, mein eigener Wert zählt wie der jedes DDs
	local tank = (not ns.memberNow) and ns:TankUnit() or nil

	local IsSecret = ns.IsSecret
	for _, u in ipairs(ns.groupUnits) do
		local ok, isTanking, status, scaled = pcall(API.UnitDetailedThreatSituation, u, unit)
		-- 2.5.17 (TU1-L04t, gemessen: ns.IsSecret war fast die Hälfte eines Durchlaufs): steht der Spieler nicht auf der
		-- Bedrohungsliste, sind alle drei Werte nil - nil ist nie geschützt (ns.IsSecret(nil) = false), also nichts zu prüfen.
		if ok and isTanking == nil and status == nil and scaled == nil then
			-- nichts: kein Eintrag für diesen Spieler
		elseif not ok or IsSecret(isTanking) or IsSecret(status) then
			apiFailed = true
			break
		end
		if status then
			any = true
			if isTanking then
				tankUnit = u
				-- Status 2: Tank vorne, aber jemand anderes über 100 %
				if status == 2 then warnByStatus = true end
			end
			if IsSecret(scaled, "threatValues") then
				valuesSecret = true
			elseif scaled then
				if tank and ns:SameUnit(u, tank) then
					-- Anteil bis zum Zurückholen (100 = Aggro springt zu mir; 110/130-%-Regel eingerechnet)
					myPull = scaled
				elseif not isTanking and scaled > maxOther and not ns:IsSafeUnit(u) then
					maxOther = scaled
				end
			end
		end
	end

	-- moderne API: geschützte Werte trotz "lesbar" - ab jetzt Modus ANZEIGE (kein stilles IDLE)
	-- (auch beim ersten Kampf nach dem Login, solange noch nichts erkannt ist)
	if apiFailed and ns.isModern and ns.threatAccess ~= "secret" and ns.threatAccess ~= "none" then
		ns.ThreatAccess:Set("secret")
	end
	if apiFailed then
		-- Ersatz 1: nur der Bedrohungsstatus (API.UnitThreatSituation)
		tankUnit, any = nil, false
		for _, u in ipairs(ns.groupUnits) do
			local ok, status = pcall(API.UnitThreatSituation, u, unit)
			if ok and not ns.IsSecret(status) and status then
				any = true
				if status >= 2 then
					tankUnit = u
					if status == 2 then warnByStatus = true end
				end
			end
		end
		ns:Compat("threat", any and "fallback" or "off")
		valuesSecret = true
	else
		if any then ns:Compat("threat", "ok") end
	end

	-- Ersatz 2: das Ziel des Mobs (wenn das Spiel gar keine Bedrohung liefert).
	-- Nur alte API: auf der modernen API (Forever / Retail) würde das Addon damit selbst berechnen,
	-- wer Aggro hat - das ist dort nicht erlaubt.
	if not ns.isModern and not tankUnit and not any and ns.Safe(API.UnitAffectingCombat(unit), false) then
		local tu = unit .. "target"
		if ns.Safe(API.UnitExists(tu), false) then
			for _, u in ipairs(ns.groupUnits) do
				if ns:SameUnit(u, tu) then tankUnit = u break end
			end
		end
	end

	if any then ns:Compat("threatValues", valuesSecret and "fallback" or "ok") end
	-- woher die Entscheidung stammt (Testprotokoll)
	local via = (not any and tankUnit) and "fallback" or ((apiFailed or valuesSecret) and "status" or "pct")
	if valuesSecret then
		myPull, maxOther = nil, 0
	else
		warnByStatus = false
	end
	return tankUnit, myPull, maxOther, warnByStatus, via
end
T._ReadThreat = ReadThreat   -- Test-Zugang (Testroutine T164)

------------------------------------------------------------
-- Auswertung eines Mobs
------------------------------------------------------------
function T:Evaluate(unit, m)
	local db = ns.db
	local now = GetTime()
	local prev = m.state
	local key, realGuid = ns:MobKey(unit)
	if key ~= m.key then
		m.key = key
		prev = nil
		m.looseSince = nil
		m.alerted, m.alertedMe = false, false
	end
	m.guid = realGuid and key or nil
	m.name = ns.Safe(API.UnitName(unit), "?")           -- geschützt: "?" (wird verkettet / formatiert)
	local mark = API.GetRaidTargetIndex and API.GetRaidTargetIndex(unit) or nil
	m.mark = ns.Safe(mark, nil)
	m.victim, m.victimRole, m.otherTank, m.claimedBy, m.tankOnIt = nil, nil, nil, nil, nil
	m.muted, m.ownerName, m.myPull, m.victimIsMe, m.holder = false, nil, nil, false, nil
	m.via, m.maxOther, m.warnStatus = nil, nil, nil

	local cc, sunder, ccSrc = ReadMobAuras(unit, key)
	m.sunder = sunder
	m.ccSpell = ccSrc
	if cc and ns.Log.on then ns.Log:CC(unit, m, ccSrc) end

	local state
	local canAttack = ns.Safe(API.UnitCanAttack("player", unit), true)
	local dead = ns.Safe(API.UnitIsDeadOrGhost(unit), false)
	if not canAttack or dead then
		state = "IDLE"
	elseif cc and db.ignoreCC then
		state = "CC"
	else
		local tankUnit, myPull, maxOther, warnByStatus, via = ReadThreat(unit)
		m.via = via
		m.maxOther, m.warnStatus = maxOther, warnByStatus   -- für die Grundregeln (CheckRules)

		m.holder = tankUnit and ns:FullName(tankUnit) or nil
		if not tankUnit then
			state = "IDLE"
		elseif not ns.memberNow and ns:SameUnit(tankUnit, ns:TankUnit()) then
			state = (maxOther >= db.warnThreshold or warnByStatus) and "WARN" or "HELD"
			ns.owners[key] = { name = ns.playerName, t = now }
		else
			local role = ns:GetRole(tankUnit)
			if role == "TANK" and ns.memberNow then
				-- Gruppen-Ansicht: der Tank hält ihn (bald Aggro, wenn jemand nahe dran ist)
				state = (maxOther >= db.warnThreshold or warnByStatus) and "WARN" or "HELD"
				m.otherTank = ns:FullName(tankUnit)
			elseif role == "TANK" then
				state = "OTHERTANK"
				m.otherTank = ns:FullName(tankUnit)
				ns.owners[key] = { name = m.otherTank, t = now }
			elseif role == "PET" and db.petsSafe then
				state = "PETHELD"
			else
				state = "LOOSE"
				m.victim = ns.Safe(API.UnitName(tankUnit), "?")
				m.victimRole = role
				m.victimIsMe = ns:SameUnit(tankUnit, "player")
				m.myPull = myPull
			end
		end
	end

	m.state = state
	m.via = m.via or "-"

	if state == "LOOSE" and ns.memberNow then
		-- Gruppen-Ansicht: keine Spott-Hinweise, keine Übernahme - nur warnen, wenn ich selbst Aggro habe
		if prev ~= "LOOSE" then m.looseSince = now end
		m.hint, m.far, m.tauntCD = nil, false, 0
		-- auch warnen, wenn der Mob von einem anderen Spieler direkt zu mir springt
		if m.victimIsMe and not m.alertedMe then
			m.alertedMe = true
			ns.Alerts:OnLoose(m)
		elseif not m.victimIsMe then
			m.alertedMe = false
		end
	elseif state == "LOOSE" then
		if prev ~= "LOOSE" then m.looseSince = now end
		m.claimedBy = ns.Sync:Claim(m.guid) or ns.Sync:ClaimByTarget(unit)
		if m.claimedBy and not ns.testMode then ns:PLHit("SYNC-SPOTT", "übernommen") end
		if not m.claimedBy then m.tankOnIt = ns.Sync:TankTargeting(unit) end
		local owner = ns.owners[key]
		if db.sync and owner and owner.name ~= ns.playerName and ns.Sync:IsTank(owner.name)
			and (now - (m.looseSince or now)) < db.ownerGrace then
			m.muted = true
			m.ownerName = owner.name
		end
		self:BuildHint(unit, m)
		if not m.muted and not m.claimedBy and not m.alerted then
			m.alerted = true
			ns.Alerts:OnLoose(m)
		end
	else
		if prev == "LOOSE" and (state == "HELD" or state == "WARN") then
			ns.Alerts:OnRegain(unit, m)
		elseif prev == "HELD" and state == "WARN" then
			ns.Alerts:OnWarn(m)
		end
		m.alerted, m.alertedMe = false, false
		m.hint, m.far, m.tauntCD = nil, false, 0
	end

	self:CheckRules(m)

	-- Testprotokoll: Zustandswechsel (inkl. "übernommen")
	if ns.Log.on then
		local sig = state .. (m.claimedBy and "+C" or "") .. ":" .. ns.Log.epoch
		if sig ~= m.logged then
			local from = m.loggedState
			m.logged, m.loggedState = sig, (m.claimedBy and state == "LOOSE") and "CLAIMED" or (state == "IDLE" and "NONE" or state)
			ns.Log:State(unit, m, from, m.via)
		end
	end
end

------------------------------------------------------------
-- Grundregeln im echten Spiel (TU5, 2.5.10): nach jeder Auswertung billig nachrechnen. Verletzt -> einmal je Regel und
-- Kampf ins Diagnose-Protokoll ("GRUNDREGEL VERLETZT …", nur Zahlen, keine Namen). So sieht die Prüf-Sitzung echte
-- Fehler über den Uploader, bevor der Spieler sie bemerkt. Die Testroutine prüft dieselben Regeln (TU4, Zufall).
--   G1 WARN nur, wenn ein anderer >= Warnschwelle liegt (oder Status 2 bei geschützten Werten)
--   G2 HELD nur, wenn alle anderen unter der Warnschwelle liegen
--   G3 Bedrohungswerte >= 0
--   G4 Aggro bei einem Mitspieler (nicht übernommen, nicht stumm, Tank-Ansicht) -> Meldung ausgelöst
------------------------------------------------------------
T.ruleSeen = {}
ns:On("PLAYER_REGEN_DISABLED", function() wipe(T.ruleSeen) end)

function T:RuleViolation(m)
	local thr = ns.db.warnThreshold or 90
	local mo = m.maxOther
	if type(mo) == "number" and not ns.IsSecret(mo) then
		if mo < 0 then return "G3", string.format("Wert %.0f", mo) end
		if m.state == "WARN" and mo < thr and not m.warnStatus then
			return "G1", string.format("Zustand WARN, Wert %.0f, Schwelle %d", mo, thr)
		end
		if m.state == "HELD" and (mo >= thr or m.warnStatus) then
			return "G2", string.format("Zustand HELD, Wert %.0f, Schwelle %d", mo, thr)
		end
	end
	if m.state == "LOOSE" and not ns.memberNow and not m.muted and not m.claimedBy and not m.alerted then
		return "G4", "Zustand LOOSE ohne Meldung"
	end
end

function T:CheckRules(m)
	local rule, text = self:RuleViolation(m)
	if not rule or self.ruleSeen[rule] then return rule end
	self.ruleSeen[rule] = true
	if ns.Diag then ns.Diag("GRUNDREGEL", "VERLETZT " .. rule .. ": " .. text) end
	return rule
end

-- Reihenfolge der Raidmarkierungen: Totenkopf vor Kreuz vor den übrigen, ohne Markierung zuletzt
local MARK_ORDER = { [8] = 1, [7] = 2, [6] = 3, [5] = 4, [4] = 5, [3] = 6, [2] = 7, [1] = 8 }

local function SortLoose(a, b)
	local ma, mb = MARK_ORDER[a.mark or 0] or 9, MARK_ORDER[b.mark or 0] or 9
	if ma ~= mb then return ma < mb end
	local ra, rb = ROLE_ORDER[a.victimRole] or 9, ROLE_ORDER[b.victimRole] or 9
	if ra ~= rb then return ra < rb end
	return (a.looseSince or 0) < (b.looseSince or 0)
end
T.SortLoose = SortLoose

------------------------------------------------------------
-- Regelmässiger Durchlauf
------------------------------------------------------------
-- Fehler in einem einzelnen Teil sollen nie das ganze Addon anhalten
local function Try(fn, ...)
	local ok, err = pcall(fn, ...)
	if not ok then ns:ReportError(err) end
	return ok
end

-- Gruppen-Ansicht: wer hält die meisten Mobs? (Tank ohne Addon erkennen)
-- Nur Krieger / Druiden / Paladine, die keine Heiler sind; schon ein einzelner Mob (Boss) zählt.
local function UpdateAggroLeader()
	local count, best, bestN = {}, nil, 0
	for _, m in pairs(mobs) do
		local h = m.holder
		if h and not ns.IsSecret(h) and h ~= ns.playerName and m.state and m.state ~= "IDLE" then
			local u = ns.nameToUnit[h]
			if u and ns:CouldTank(u) then
				count[h] = (count[h] or 0) + 1
				if count[h] > bestN then best, bestN = h, count[h] end
			end
		end
	end
	if best then
		ns.aggroLeader, ns.aggroLeaderT = best, GetTime()
	elseif ns.aggroLeader and GetTime() - (ns.aggroLeaderT or 0) > 15 then
		ns.aggroLeader = nil
	end
end

function T:Tick()
	if not ns.db then return end
	local member = ns:IsMemberMode()
	if member ~= ns.memberNow then
		-- Wechsel Tank <-> Gruppen-Ansicht: alle Mobs neu bewerten, ohne alte Meldungen auszulösen
		ns.memberNow = member
		for _, m in pairs(mobs) do m.state, m.alerted, m.alertedMe = nil, false, false end
	end
	if ns.memberNow then Try(UpdateAggroLeader) end
	ns:ClearRoleCache()
	Try(ns.DD.Tick, ns.DD)
	Try(ns.Meter.Tick, ns.Meter)

	local nowActive = ns:IsActive()
	if nowActive ~= active then
		active = nowActive
		if not active then
			for unit, m in pairs(mobs) do
				ns.Plates:Restore(unit)
				m.state = nil
				m.alerted = false
			end
			-- Testmeldungen (Schlüssel "test") stehen lassen
			local c = ns.Alerts.center
			if c and c.key ~= "test" then ns.Alerts:ClearCenter() end
		end
	end
	-- WoW Forever / Retail: einmal pro Kampf prüfen, ob die Bedrohungswerte lesbar sind
	-- (auch wenn das Addon gerade nicht aktiv ist - Aggrometer und DD-Ansicht hängen am Modus)
	if ns.isModern and not ns.ThreatAccess.checked and API.UnitAffectingCombat("player") then
		local list = ns.ThreatAccess:Candidates(mobs)
		if #list > 0 then Try(ns.ThreatAccess.Probe, ns.ThreatAccess, list) end
	end
	-- jeder Moduswechsel (Erkennung, Einstellung, Testzentrale, Login) läuft hier durch
	local mode = ns:ThreatMode()
	if mode ~= self.lastMode then
		local before = self.lastMode
		self.lastMode = mode
		if before then self:ModeChanged(before, mode) end
	end

	if not active then
		ns.HUD:Update(nil, nil)
		return
	end

	if ns.testMode then
		Try(ns.Test.Tick, ns.Test, mobs)
		return
	end

	-- Modus ANZEIGE / AUS: keine eigene Entscheidung, Plaketten nicht anfassen
	if mode ~= "FULL" then
		if mode == "DISPLAY" then Try(self.MeasurePlates, self, mobs) end
		ns.HUD:Update(nil, nil)
		return
	end

	-- 2.5.17 (TU1-L04t: 40 Spieler × 40 Mobs brauchten im Spiel 10,3 ms in EINEM Bild): Mobs der Reihe nach bewerten, die am
	-- längsten nicht bewerteten zuerst (neue Mobs sofort). Ist T.BUDGET_MS verbraucht, kommen die übrigen im nächsten Durchlauf
	-- (0,25 s) dran und behalten bis dahin ihren letzten Stand. Mindestens T.MIN_EVAL Mobs je Durchlauf, damit es immer vorangeht.
	self.tickNr = (self.tickNr or 0) + 1
	local order = {}
	for unit, m in pairs(mobs) do order[#order + 1] = unit end
	table.sort(order, function(a, b)
		local ea, eb = mobs[a].evalNr or -1, mobs[b].evalNr or -1
		if ea ~= eb then return ea < eb end
		return a < b
	end)
	local t0 = T.Clock()
	local done = 0
	self.lastDeferred = 0
	for i, unit in ipairs(order) do
		if done >= T.MIN_EVAL and T.Clock() - t0 >= T.BUDGET_MS then
			self.lastDeferred = #order - i + 1
			break
		end
		local m = mobs[unit]
		done = done + 1
		m.evalNr = self.tickNr
		m.evalOk = Try(self.Evaluate, self, unit, m)
		if m.evalOk then
			-- gerade auf "geschützt" gewechselt: diesen Durchlauf abbrechen (Plaketten nicht mehr anfassen)
			if ns:ThreatMode() ~= "FULL" then return end
			Try(ns.Plates.Update, ns.Plates, unit, m)
		end
	end
	self.lastEvaluated = done
	-- Meldungen und HUD aus dem Stand ALLER Mobs (auch der noch nicht neu bewerteten)
	local loose, heldOnMe = {}, 0
	for _, unit in ipairs(order) do
		local m = mobs[unit]
		if m and m.evalOk then
			if m.state == "LOOSE" and not m.muted and not m.claimedBy then
				loose[#loose + 1] = m
			elseif m.state == "HELD" or m.state == "WARN" then
				heldOnMe = heldOnMe + 1
			end
		end
	end
	table.sort(loose, SortLoose)
	Try(ns.Alerts.Evaluate, ns.Alerts, loose, heldOnMe)
	Try(ns.HUD.Update, ns.HUD, loose, ns.Alerts.extras)
end

------------------------------------------------------------
-- Messung (2.5.7): Was ist im Modus ANZEIGE je Mob lesbar - nicht nur für dein Ziel?
-- Einmal je Kampf, 3 s nach Kampfbeginn (dann haben die Mobs Bedrohung), ins Diagnose-Protokoll. Keine Namen.
-- Grundlage für die Aggro-Warnung des Tanks in WoW Forever (Plaketten bleiben unangetastet).
------------------------------------------------------------
ns:On("PLAYER_REGEN_DISABLED", function() T.measureAt = GetTime() + 3; T.measured = false end)

local function Readable(v) return v ~= nil and not ns.IsSecret(v) end

function T:MeasurePlates(list)
	if self.measured or not self.measureAt or GetTime() < self.measureAt or not ns.Diag then return end
	if not ns.Safe(API.UnitAffectingCombat("player"), false) then return end
	local n, tankR, stR, combat, mine, otherT, otherS, other = 0, 0, 0, 0, 0, 0, 0, 0
	local probe   -- ein anderes Gruppenmitglied (nicht du) für die Gegenprobe
	for _, u in ipairs(ns.groupUnits or {}) do
		if not ns:SameUnit(u, "player") and not u:find("pet", 1, true) then probe = u break end
	end
	for unit in pairs(list) do
		n = n + 1
		local okC, c = pcall(API.UnitAffectingCombat, unit)
		if okC and ns.Safe(c, false) then combat = combat + 1 end
		local ok, isT, st = pcall(API.UnitDetailedThreatSituation, "player", unit)
		if ok then
			if Readable(isT) then tankR = tankR + 1; if isT == true then mine = mine + 1 end end
			if Readable(st) then stR = stR + 1 end
		end
		if probe then
			local ok2, isT2, st2 = pcall(API.UnitDetailedThreatSituation, probe, unit)
			if ok2 then
				other = other + 1
				if Readable(isT2) then otherT = otherT + 1 end
				if Readable(st2) then otherS = otherS + 1 end
			end
		end
	end
	if n == 0 then return end
	self.measured = true
	ns:PLHit("LESBAR", "Plaketten " .. n)
	ns.Diag("LESBAR-PLAKETTEN", string.format(
		"Plaketten %d (im Kampf %d) · du: isTanking lesbar %d/%d, Stufe lesbar %d/%d, Aggro bei dir %d · Gruppe: isTanking lesbar %d/%d, Stufe lesbar %d/%d",
		n, combat, tankR, n, stR, n, mine, otherT, other, otherS, other))
end

-- Wechsel VOLL <-> ANZEIGE / AUS: eigene Anzeigen an den Plaketten ausblenden, die Blizzard-Frames
-- im Kampf nicht anfassen (wiederhergestellt wird nach dem Kampf)
function T:ModeChanged(before, mode)
	if ns.Diag then ns.Diag("MODUS", tostring(before) .. " -> " .. tostring(mode)) end
	if mode == "FULL" then
		if not API.InCombatLockdown() then ns.ThreatAccess:RestoreBlizzard() end
		return
	end
	-- Modus ANZEIGE (erkannt oder "immer nur Anzeige", nicht nur "noch unbekannt"): Blizzards Anzeigen vormerken
	if mode == "DISPLAY" and ns.threatAccess ~= "unknown" then
		ns.ThreatAccess.wantBlizzard = true
		ns.ThreatAccess:ApplyBlizzard()
	end
	for unit, m in pairs(mobs) do
		ns.Plates:Detach(unit)
		m.state, m.alerted, m.alertedMe = nil, false, false
	end
	local c = ns.Alerts.center
	if c and c.key ~= "test" and c.key ~= "remote" then ns.Alerts:ClearCenter() end
	wipe(ns.Alerts.extras)
	if ns.Alerts.emergFrame then ns.Alerts.emergFrame:Hide() end
end

function T:EvalOne(unit)
	if not active or ns.testMode or ns:ThreatMode() ~= "FULL" then return end
	-- moderne API: erst nach der Prüfung dieses Kampfs entscheiden (Plaketten sonst evtl. zu früh angefasst)
	if ns.isModern and not ns.ThreatAccess.checked and API.UnitAffectingCombat("player") then return end
	local m = mobs[unit]
	if not m then return end
	if Try(self.Evaluate, self, unit, m) and ns:ThreatMode() == "FULL" then Try(ns.Plates.Update, ns.Plates, unit, m) end
end

------------------------------------------------------------
-- Ereignisse
------------------------------------------------------------
ns:On("NAME_PLATE_UNIT_ADDED", function(_, unit)
	mobs[unit] = { unit = unit }
	T:EvalOne(unit)
end)

ns:On("NAME_PLATE_UNIT_REMOVED", function(_, unit)
	ns.Plates:Restore(unit)
	-- Plakette wird für einen anderen Mob wiederverwendet: ihre Ersatz-Daten vergessen
	ns.Track:Forget("plate:" .. unit)
	ns.owners["plate:" .. unit] = nil
	mobs[unit] = nil
end)

ns:On("UNIT_THREAT_LIST_UPDATE", function(_, unit)
	if not ns.IsSecret(unit) and unit and mobs[unit] then T:EvalOne(unit) end
end)

ns:On("PLAYER_REGEN_ENABLED", function()
	local now = GetTime()
	for k, o in pairs(ns.owners) do
		if now - o.t > 30 then ns.owners[k] = nil end
	end
end)
