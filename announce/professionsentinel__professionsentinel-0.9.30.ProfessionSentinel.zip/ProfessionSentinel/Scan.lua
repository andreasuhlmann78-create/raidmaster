local _, ns = ...

-- Detects the player's professions (with skill rank) and which recipes are learned.
-- Works with the modern profession API (C_TradeSkillUI, WoW Forever) and the classic one
-- (GetTradeSkillInfo / GetCraftInfo, Classic Era), plus IsPlayerSpell as a passive check.

local Scan = {}
ns.Scan = Scan

-- WoW Forever uses its own child skill lines (e.g. 2945 Leatherworking) whose parent is the
-- classic skill line our data uses.
local PROF_ALIAS = {
    [2937] = 171, [2938] = 164, [2939] = 185, [2940] = 333, [2941] = 202, [2942] = 129,
    [2943] = 356, [2944] = 182, [2945] = 165, [2946] = 186, [2947] = 393, [2948] = 197,
}

function ns.ResolveProf(id)
    if not id then return nil end
    id = PROF_ALIAS[id] or id
    return (ns.ByProf[id] and #ns.ByProf[id] > 0) and id or nil
end

function ns.MatchProfession(name)
    if not name then return nil end
    for _, p in ipairs(ns.Professions) do
        if p.name == name or ns.ProfessionNamesEN[p.id] == name then return p.id end
    end
    return nil
end

-- Profession ranks -------------------------------------------------------
-- Retail: every expansion is its own skill line (e.g. 2915 Midnight Leatherworking, parent 165) with
-- its own skill; GetProfessions only knows the base profession.
local function RetailProfessions(found)
    if not (ns.API.GetProfessions and ns.API.GetProfessionInfo) then return end
    local bases = {}
    local slots = { ns.API.GetProfessions() }
    for i = 1, 6 do
        local idx = slots[i]
        if idx then
            local _, _, rank, maxRank, _, _, skillLine = ns.API.GetProfessionInfo(idx)
            if skillLine then bases[skillLine] = { rank = rank or 0, max = maxRank or 0 } end
        end
    end
    local byLine = ns.API.TradeSkillGetProfessionInfoBySkillLineID
    for _, p in ipairs(ns.Professions) do
        if p.parent and bases[p.parent] then
            local info = byLine and select(2, pcall(byLine, p.id))
            if type(info) == "table" and (info.maxSkillLevel or 0) > 0 then
                found[p.id] = { rank = info.skillLevel or 0, max = info.maxSkillLevel }
            elseif p.id == p.parent then
                found[p.id] = bases[p.parent]
            end
        end
    end
    -- the open window knows its expansion line for sure
    if ns.API.TradeSkillGetChildProfessionInfo then
        local ok, info = pcall(ns.API.TradeSkillGetChildProfessionInfo)
        if ok and type(info) == "table" and info.professionID and ns.ProfById[info.professionID] then
            found[info.professionID] = { rank = info.skillLevel or 0, max = info.maxSkillLevel or 0 }
        end
    end
end

function Scan:UpdateProfessions()
    local c = ns.Char(); if not c then return end
    local found = {}
    if ns.IsRetail then
        RetailProfessions(found)
        if next(found) then
            -- keep expansion lines learned earlier that the client does not report right now
            local bases = {}
            for id in pairs(found) do bases[ns.ProfById[id] and ns.ProfById[id].parent or id] = true end
            for id, v in pairs(c.profs or {}) do
                local p = ns.ProfById[id]
                if not found[id] and p and bases[p.parent or id] then found[id] = v end
            end
            c.profs = found
        end
        return
    end
    if ns.API.GetProfessions and ns.API.GetProfessionInfo then
        local slots = { ns.API.GetProfessions() }
        for i = 1, 6 do
            local idx = slots[i]
            if idx then
                local name, _, rank, maxRank, _, _, skillLine = ns.API.GetProfessionInfo(idx)
                local id = ns.ResolveProf(skillLine) or ns.MatchProfession(name)
                if id then found[id] = { rank = rank or 0, max = maxRank or 0 } end
            end
        end
    end
    if ns.API.GetNumSkillLines and ns.API.GetSkillLineInfo then
        for i = 1, ns.API.GetNumSkillLines() do
            local name, isHeader, _, rank, _, _, maxRank = ns.API.GetSkillLineInfo(i)
            if not isHeader then
                local id = ns.MatchProfession(name)
                if id and not found[id] then found[id] = { rank = rank or 0, max = maxRank or 0 } end
            end
        end
    end
    if next(found) then c.profs = found end
end

-- Known recipes -------------------------------------------------------------
local function MarkKnown(spellID)
    -- protected value (WoW Forever / Retail in combat): never use it as a table key
    -- IsSecret first: even comparing a protected value (== / ~=) can raise an error in combat
    if ns.IsSecret(spellID) or type(spellID) ~= "number" then return false end
    local c = ns.Char()
    if c and ns.BySpell[spellID] and not c.known[spellID] then
        c.known[spellID] = true
        return true
    end
    return false
end

local function SpellFromLink(link)
    if not link then return nil end
    local id = link:match("enchant:(%d+)") or link:match("spell:(%d+)")
    return id and tonumber(id)
end

function Scan:PassiveCheck()
    local c = ns.Char(); if not c or not IsPlayerSpell then return end
    local changed = false
    for spell in pairs(ns.BySpell) do
        local ok, known = pcall(IsPlayerSpell, spell)
        if ok and known and not c.known[spell] then c.known[spell] = true; changed = true end
    end
    return changed
end

local function IsOwnTradeSkill()
    local A = ns.API
    if A.TradeSkillIsTradeSkillLinked and A.TradeSkillIsTradeSkillLinked() then return false end
    if A.TradeSkillIsTradeSkillGuild and A.TradeSkillIsTradeSkillGuild() then return false end
    if A.TradeSkillIsNPCCrafting and A.TradeSkillIsNPCCrafting() then return false end
    if IsTradeSkillLinked and IsTradeSkillLinked() then return false end
    return true
end

function Scan:ScanTradeSkill()
    if not IsOwnTradeSkill() then return false end
    local changed = false
    -- Modern API (WoW Forever)
    if ns.API.TradeSkillGetAllRecipeIDs then
        local ok, ids = pcall(ns.API.TradeSkillGetAllRecipeIDs)
        if ok and ids then
            local getInfo = ns.API.TradeSkillGetRecipeInfo
            for _, id in ipairs(getInfo and ids or {}) do
                local okI, info = pcall(getInfo, id)
                if okI and type(info) == "table" and info.learned and MarkKnown(id) then changed = true end
            end
        end
    end
    -- Classic API (Classic Era)
    if ns.API.GetNumTradeSkills and ns.API.GetTradeSkillInfo then
        for i = 1, ns.API.GetNumTradeSkills() do
            local name, kind = ns.API.GetTradeSkillInfo(i)
            if name and kind ~= "header" and kind ~= "subheader" then
                local spell = ns.API.GetTradeSkillRecipeLink and SpellFromLink(ns.API.GetTradeSkillRecipeLink(i))
                if not spell then
                    local r = ns.ByName[name:lower()]
                    spell = r and r.spell
                end
                if MarkKnown(spell) then changed = true end
            end
        end
    end
    -- Classic enchanting window
    if ns.API.GetNumCrafts and ns.API.GetCraftInfo then
        for i = 1, ns.API.GetNumCrafts() do
            local name, _, kind = ns.API.GetCraftInfo(i)
            if name and kind ~= "header" then
                local spell = ns.API.GetCraftRecipeLink and SpellFromLink(ns.API.GetCraftRecipeLink(i))
                if not spell then
                    local r = ns.ByName[name:lower()]
                    spell = r and r.spell
                end
                if MarkKnown(spell) then changed = true end
            end
        end
    end
    return changed
end

local function Refresh()
    if ns.Advisor and ns.Advisor.Invalidate then ns.Advisor.Invalidate() end      -- recipe/learned/skill data changed
    if ns.UI and ns.UI.Refresh then ns.UI:Refresh() end
    if ns.Lifeline then ns.Lifeline.RefreshBlizzard() end
    if ns.Spieltest and ns.Spieltest.IsOn() then pcall(ns.Spieltest.OnProfession) end      -- S2, S3
end
ns.RefreshAll = Refresh

---------------------------------------------------------------------------
-- Event storm protection (diagnostic log 0.9.22: 7450 rebuilds by TRADE_SKILL_LIST_UPDATE, UI:Refresh 101 ms each).
-- Reading the recipe list can make the game send TRADE_SKILL_LIST_UPDATE again – our own scan fed itself.
-- 1. List events (TRADE_SKILL_LIST_UPDATE / TRADE_SKILL_UPDATE / CRAFT_UPDATE) right after our own scan are
--    ignored (Scan.QUIET seconds).
-- 2. Events are collected: one scan per Scan.DELAY seconds.
-- 3. A full refresh (recompute + rebuild) only if something really changed: profession, skill, learned recipes –
--    or the event itself says so (window opened, recipe learned, skill up). Otherwise only a light refresh of a
--    visible panel from the cache.
---------------------------------------------------------------------------
Scan.DELAY, Scan.QUIET = 0.5, 1.0
local LIST_EVENTS = { TRADE_SKILL_LIST_UPDATE = true, TRADE_SKILL_UPDATE = true, CRAFT_UPDATE = true }
local scanPending, forceFull, quietUntil, lastFp = false, false, 0, nil

function Scan.Now() return (GetTime and GetTime()) or 0 end
function Scan.InQuiet() return Scan.Now() < quietUntil end

-- what decides whether the results change: professions with skill, number of learned recipes
function Scan:Fingerprint()
    local c = ns.Char()
    if not c then return "" end
    local parts = {}
    for id, p in pairs(type(c.profs) == "table" and c.profs or {}) do
        if type(p) == "table" then parts[#parts + 1] = tostring(id) .. ":" .. tostring(p.rank) .. "/" .. tostring(p.max) end
    end
    table.sort(parts)
    local n = 0
    for _ in pairs(type(c.known) == "table" and c.known or {}) do n = n + 1 end
    return table.concat(parts, ",") .. "|" .. n .. "|" .. tostring(ns.Sim)
end

function Scan.RunPending()
    scanPending = false
    local full = forceFull
    forceFull = false
    Scan:UpdateProfessions()
    Scan:ScanTradeSkill()
    Scan:PassiveCheck()
    local fp = Scan:Fingerprint()
    if full or fp ~= lastFp then
        lastFp = fp
        Scan.fullRuns = (Scan.fullRuns or 0) + 1
        Refresh()
        if ns.Disenchant then ns.Disenchant.CheckAsk() end
    else
        Scan.lightRuns = (Scan.lightRuns or 0) + 1
        -- nothing changed: only a visible panel is redrawn (from the cache), a hidden one not at all
        if ns.UI and ns.UI.PanelVisible and ns.UI.PanelVisible() then ns.UI.RequestRefresh("Scan") end
    end
    quietUntil = Scan.Now() + Scan.QUIET      -- what our own scan stirred up is not a change
end

function Scan.OnEvent(event, arg1)
    -- arg1 is only read for NEW_RECIPE_LEARNED (CHAT_MSG_SKILL text is never touched)
    if event == "NEW_RECIPE_LEARNED" then
        MarkKnown(arg1)      -- MarkKnown asks IsSecret first
        if ns.UI and ns.UI.InvalidateRecipeMap then ns.UI.InvalidateRecipeMap() end      -- the window has a new recipe
    end
    if LIST_EVENTS[event] then
        if Scan.InQuiet() then Scan.ignored = (Scan.ignored or 0) + 1; return end
    else
        forceFull = true
    end
    if scanPending then return end
    scanPending = true
    if ns.API.TimerAfter then ns.API.TimerAfter(Scan.DELAY, Scan.RunPending) else Scan.RunPending() end
end

function Scan:Init()
    if self.frame then return end
    local f = ns.AddEventFrame(CreateFrame("Frame"), "Scan")
    self.frame = f
    local events = {
        "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE", "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_DATA_SOURCE_CHANGED",
        "CRAFT_SHOW", "CRAFT_UPDATE", "NEW_RECIPE_LEARNED", "LEARNED_SPELL_IN_TAB", "SKILL_LINES_CHANGED",
        "CHAT_MSG_SKILL",
    }
    for _, e in ipairs(events) do pcall(f.RegisterEvent, f, e) end
    f:SetScript("OnEvent", function(_, event, arg1) Scan.OnEvent(event, arg1) end)
    C_Timer.After(2, function()
        Scan:UpdateProfessions()
        Scan:PassiveCheck()
        Refresh()
        if ns.Disenchant then ns.Disenchant.CheckAsk() end
    end)
end

-- Helpers for the UI ------------------------------------------------------
function Scan:IsKnown(spell)
    local c = ns.Char()
    return c and c.known[spell] or false
end

function Scan:PlayerProfessions()
    local c = ns.Char()
    local list = {}
    if not c then return list end
    for _, p in ipairs(ns.Professions) do
        if c.profs[p.id] and ns.ByProf[p.id] and #ns.ByProf[p.id] > 0 then list[#list + 1] = p end
    end
    return list
end

function Scan:Rank(profID)
    local c = ns.Char()
    local p = c and c.profs[profID]
    return p and p.rank or nil, p and p.max or nil
end

-- Which characters (of this game version) know / miss a recipe (for tooltips)
function Scan:CharsFor(spell, profID)
    local knownBy, missingBy = {}, {}
    for key, c in pairs(ns.db and type(ns.db.chars) == "table" and ns.db.chars or {}) do
        if type(key) == "string" and type(c) == "table" and (not c.flavor or c.flavor == ns.Flavor) then
            local short = key:match("^[^-]+") or key
            if type(c.known) == "table" and c.known[spell] then
                knownBy[#knownBy + 1] = short
            elseif type(c.profs) == "table" and c.profs[profID] then
                missingBy[#missingBy + 1] = short
            end
        end
    end
    table.sort(knownBy); table.sort(missingBy)
    return knownBy, missingBy
end
