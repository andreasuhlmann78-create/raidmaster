local _, ns = ...
local L = ns.L

-- Disenchant value of a crafted item (for "Gold verdienen" and "Herstellen & Entzaubern").
--
-- Source: AHSentinel (GoldSentinel). It learns from every disenchant and shares the results with
-- every player who has AHSentinel, so its drop chances follow the real ones on the server.
-- Without AHSentinel: the classic table with the starting values (green armour 75 % dust, 20 % essence,
-- 5 % shard; weapons the other way round) and AH prices from TSM/Auctionator – no learning.
--
-- DE.Value(itemID) -> gross (copper, before the 5 % AH cut), complete, yield, own, shared, source
--   yield = { { materialID, chance 0-1, average count }, ... }

local DE = {}
ns.Disenchant = DE

---------------------------------------------------------------------------
-- Enchanters only: what do you want to do with enchanting? Asked at the first login (window stays
-- until the player picks and closes it), default "gold"; changeable any time (/ps ziel or the first
-- row of the "Verzauberer" tab), stored per character.
--   "gold" – make gold by disenchanting (bargains, craft & disenchant, drop chances) – default
--   "sell" – sell enchants to other players (material cost per enchant)
--   "both"
-- Disenchant values only count for characters with enchanting who chose "gold" or "both".
---------------------------------------------------------------------------
DE.ENCHANTING = 333

-- enchanting skill lines: 333, in Retail also every expansion line (parent 333)
function DE.EnchantProfs()
    local out = {}
    for _, p in ipairs(ns.Professions or {}) do
        if p.id == DE.ENCHANTING or p.parent == DE.ENCHANTING then out[#out + 1] = p.id end
    end
    return out
end

function DE.IsEnchanter()
    if ns.Sim and ns.Sim.enchanter ~= nil then return ns.Sim.enchanter end
    local c = ns.Char and ns.Char()
    if not (c and c.profs) then return false end
    for _, id in ipairs(DE.EnchantProfs()) do
        if c.profs[id] then return true end
    end
    return false
end

-- Retail: the disenchant tables (Classic) do not apply, AHSentinel's disenchant values neither –
-- only "sell enchants" there
function DE.Goal()
    if ns.Sim and ns.Sim.goal then return ns.Sim.goal end    -- test mode / self-test may simulate any goal
    if ns.IsRetail then return "sell" end
    local c = ns.Char and ns.Char()
    return c and c.enchantGoal or DE.DEFAULT_GOAL
end
DE.DEFAULT_GOAL = "gold"

function DE.WantsGold()
    if not DE.IsEnchanter() then return false end
    local g = DE.Goal()
    return g == "gold" or g == "both"
end

function DE.WantsSell()
    if not DE.IsEnchanter() then return false end
    local g = DE.Goal()
    return g == "sell" or g == "both"
end

function DE.SetGoal(goal)
    if goal ~= "gold" and goal ~= "sell" and goal ~= "both" then return end
    local c = ns.Char and ns.Char()
    if c then c.enchantGoal = goal end
    if ns.Sim then ns.Sim.goal = nil end
    ns.Print(string.format(L.GOAL_SET, L["GOAL_" .. goal:upper()]))
    if ns.RefreshAll then ns.RefreshAll() end
end

-- Question window: three choices, "Gold machen" marked as default. No X, Esc does not close it:
-- the player has to pick one, then closes the window himself with "Fertig".
local ask
local function UpdateAsk()
    if not ask then return end
    local c = ns.Char and ns.Char()
    local chosen = (ns.Sim and ns.Sim.goal) or (c and c.enchantGoal)
    for goal, b in pairs(ask.buttons) do
        local label = L["GOAL_" .. goal:upper()]
        if goal == DE.DEFAULT_GOAL then label = label .. " " .. L.GOAL_DEFAULT_TAG end
        if chosen == goal then
            b:SetText("|cff40c040✓|r " .. label)
            b:LockHighlight()
        else
            b:SetText(label)
            b:UnlockHighlight()
        end
    end
    ask.status:SetText(chosen and string.format(L.GOAL_CHOSEN, L["GOAL_" .. chosen:upper()]) or ("|cffffd100" .. L.GOAL_PICK .. "|r"))
    ask.done:SetEnabled(chosen ~= nil)
end

function DE.AskGoal()
    if not ask then
        ask = CreateFrame("Frame", "ProfessionSentinelGoalFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
        if ns.RegisterUI then ns.RegisterUI(ask, "Ziel-Frage Verzauberer") end
        ask:SetSize(440, 200)
        ask:SetPoint("CENTER", 0, 140)
        ask:SetFrameStrata("DIALOG")
        ask:EnableMouse(true)
        ask:SetMovable(true)
        ask:RegisterForDrag("LeftButton")
        ask:SetScript("OnDragStart", ask.StartMoving)
        ask:SetScript("OnDragStop", ask.StopMovingOrSizing)
        if ask.SetBackdrop then
            ask:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
                edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32,
                insets = { left = 11, right = 12, top = 12, bottom = 11 } })
        end
        ask.title = ask:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        ask.title:SetPoint("TOP", 0, -20)
        ask.title:SetText("ProfessionSentinel")
        ask.text = ask:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        ask.text:SetPoint("TOP", 0, -46)
        ask.text:SetWidth(400)
        ask.text:SetText(L.GOAL_QUESTION)
        ask.buttons = {}
        local function btn(goal, x)
            local b = CreateFrame("Button", nil, ask, "UIPanelButtonTemplate")
            b:SetSize(132, 26)
            b:SetPoint("TOP", x, -80)
            b:SetScript("OnClick", function()
                DE.SetGoal(goal)
                UpdateAsk()
            end)
            b:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
                GameTooltip:AddLine(L["GOAL_" .. goal:upper() .. "_TIP"], 1, 1, 1, true)
                GameTooltip:Show()
            end)
            b:SetScript("OnLeave", function() GameTooltip:Hide() end)
            ask.buttons[goal] = b
        end
        btn("gold", -140)
        btn("sell", 0)
        btn("both", 140)
        ask.status = ask:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        ask.status:SetPoint("TOP", 0, -118)
        ask.status:SetWidth(400)
        ask.done = CreateFrame("Button", nil, ask, "UIPanelButtonTemplate")
        ask.done:SetSize(120, 24)
        ask.done:SetPoint("BOTTOM", 0, 20)
        ask.done:SetText(L.GOAL_DONE)
        ask.done:SetScript("OnClick", function() ask:Hide() end)
        ask:Hide()
    end
    UpdateAsk()
    ask:Show()
end

---------------------------------------------------------------------------
-- Selling enchants: price = material cost + your surcharge (at least your minimum profit),
-- rounded up to a full silver (under 1 gold) or to 10 silver
---------------------------------------------------------------------------
function DE.SellPrice(cost)
    if not cost or cost <= 0 then return nil end
    local markup = tonumber(ns.db and ns.db.vzMarkup) or 20
    local minProfit = tonumber(ns.db and ns.db.vzMinProfit) or 0
    local price = math.max(cost * (1 + markup / 100), cost + minProfit)
    local step = price < 10000 and 100 or 1000
    return math.ceil(price / step - 1e-9) * step
end

local function ParseMoney(text)
    text = (text or ""):lower():gsub(",", ".")
    local g = tonumber(text:match("([%d%.]+)%s*g")) or 0
    local s = tonumber(text:match("([%d%.]+)%s*s")) or 0
    local c = tonumber(text:match("([%d%.]+)%s*c")) or 0
    if g == 0 and s == 0 and c == 0 then
        local n = tonumber(text:match("^%s*([%d%.]+)%s*$"))
        if n then g = n end          -- a plain number means gold
    end
    return math.floor(g * 10000 + s * 100 + c + 0.5)
end
DE.ParseMoney = ParseMoney

-- StaticPopup sends its text through string.format (text_arg1/text_arg2): a single "%" (e.g. "in %") raises
-- "invalid option in `format'". So every "%" goes in as "%%" and shows up as one "%".
local function PopupText(s)
    return (tostring(s or ""):gsub("%%", "%%%%"))
end
DE.PopupText = PopupText

local function EditPopup(key, title, current, apply)
    if not StaticPopupDialogs then return end
    StaticPopupDialogs[key] = {
        text = PopupText(title), button1 = OKAY or "OK", button2 = CANCEL or "Cancel",
        hasEditBox = true, timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
        OnShow = function(self)
            local eb = self.editBox or self.EditBox
            if eb then eb:SetText(current()); eb:HighlightText() end
        end,
        OnAccept = function(self)
            local eb = self.editBox or self.EditBox
            if eb then apply(eb:GetText()) end
            if ns.RefreshAll then ns.RefreshAll() end
        end,
        EditBoxOnEnterPressed = function(self)
            local parent = self:GetParent()
            apply(self:GetText())
            parent:Hide()
            if ns.RefreshAll then ns.RefreshAll() end
        end,
    }
    StaticPopup_Show(key)
end

function DE.EditMarkup()
    EditPopup("PROFESSIONSENTINEL_VZ_MARKUP", L.VZ_MARKUP_ASK,
        function() return tostring(ns.db.vzMarkup or 20) end,
        function(t)
            local n = tonumber((tostring(t or ""):gsub(",", "."):gsub("%%", "")))
            if n and n >= 0 and n <= 1000 then ns.db.vzMarkup = n end
        end)
end

function DE.EditMinProfit()
    EditPopup("PROFESSIONSENTINEL_VZ_MIN", L.VZ_MIN_ASK,
        function() return ns.Prices.MoneyPlain(ns.db.vzMinProfit or 0) end,
        function(t) ns.db.vzMinProfit = math.max(0, ParseMoney(t)) end)
end

-- ask once per session if the character has enchanting and has not decided yet
---------------------------------------------------------------------------
-- Enchanting service: whisper the customer materials and price
-- customer = trade partner, otherwise your target (a player), otherwise the last whisper partner
---------------------------------------------------------------------------
-- pure rule (test routine): trade partner before target ("Name-Realm") before the last whisper partner.
-- Protected ("secret") names are never used.
function DE.CustomerFrom(tradeName, targetName, targetRealm, lastTell)
    -- IsSecret first, then type and comparison
    local function ok(n) return not ns.IsSecret(n) and type(n) == "string" and n ~= "" end
    if ok(tradeName) then return tradeName end
    if ok(targetName) then
        if ok(targetRealm) then return targetName .. "-" .. targetRealm end
        return targetName
    end
    if ok(lastTell) then return lastTell end
    return nil
end

function DE.Customer()
    local trade, target, realm, tell
    if TradeFrame and TradeFrame.IsShown and TradeFrame:IsShown() and UnitName then trade = UnitName("NPC") end
    if UnitExists and UnitExists("target") and UnitIsPlayer and UnitIsPlayer("target") and not UnitIsUnit("target", "player") then
        target, realm = UnitName("target")
    end
    if ChatEdit_GetLastTellTarget then tell = ChatEdit_GetLastTellTarget() end
    return DE.CustomerFrom(trade, target, realm, tell)
end

-- message parts: "<Verzauberung>: 4× Seltsamer Staub, 1× … | Preis 1g 20s (mit deinem Material 30s)"
function DE.OfferText(r)
    local P = ns.Prices
    local mats = {}
    for i = 1, #(r.reagents or {}), 2 do
        mats[#mats + 1] = r.reagents[i + 1] .. "x " .. ns.ItemName(r.reagents[i])
    end
    local pr = P.Recipe(r)
    local sp = pr.known and DE.SellPrice(pr.cost)
    local price = sp and string.format(L.VZ_OFFER_PRICE, P.MoneyPlain(sp), P.MoneyPlain(sp - pr.cost)) or ""
    return string.format(L.VZ_OFFER, ns.RecipeName(r), table.concat(mats, ", "), price)
end

-- chat messages are limited to 255 characters: split at ", " (parts of at most max bytes)
function DE.SplitMessage(msg, max)
    max = max or 250
    local parts = {}
    while #msg > max do
        local cut = msg:sub(1, max):match("^.*(), ")
        if cut and cut > 1 then
            parts[#parts + 1] = msg:sub(1, cut - 1)
            msg = msg:sub(cut + 2)
        else
            parts[#parts + 1] = msg:sub(1, max)
            msg = msg:sub(max + 1)
        end
    end
    parts[#parts + 1] = msg
    return parts
end

function DE.WhisperOffer(r, to)
    if ns.BlockedInCombat() then return false end
    to = to or DE.Customer()
    if not to then ns.Print(L.VZ_NO_CUSTOMER); return false end
    for _, part in ipairs(DE.SplitMessage(DE.OfferText(r), 250)) do
        if not ns.Act("whisper", part, to) then return false end
    end
    return true
end

-- First login with enchanting (no choice saved yet): ask. Until answered, "gold" applies.
-- Not answered (e.g. /reload while open): asked again at the next login.
local asked = false
function DE.CheckAsk()
    if ns.IsRetail or asked or not DE.IsEnchanter() or (ns.Sim and ns.Sim.enchanter ~= nil) then return end
    local c = ns.Char and ns.Char()
    if not c or c.enchantGoal then return end
    asked = true
    if C_Timer then C_Timer.After(3, DE.AskGoal) else DE.AskGoal() end
end

-- Materials
local STRANGE, SOUL, VISION, DREAM, ILLUSION = 10940, 11083, 11137, 11176, 16204
local LMAGIC, GMAGIC, LASTRAL, GASTRAL = 10938, 10939, 10998, 11082
local LMYSTIC, GMYSTIC, LNETHER, GNETHER, LETERNAL, GETERNAL = 11134, 11135, 11174, 11175, 16202, 16203
local SGLIMMER, LGLIMMER, SGLOW, LGLOW = 10978, 11084, 11138, 11139
local SRADIANT, LRADIANT, SBRILLIANT, LBRILLIANT, NEXUS = 11177, 11178, 14343, 14344, 20725

-- Green: { up to item level, dust, avg dust, essence, avg essence, shard }
local UNCOMMON = {
    { 15, STRANGE, 1.5, LMAGIC, 1.5, SGLIMMER },
    { 20, STRANGE, 2.5, GMAGIC, 1.5, SGLIMMER },
    { 25, STRANGE, 5.0, LASTRAL, 1.5, SGLIMMER },
    { 30, SOUL, 1.5, GASTRAL, 1.5, LGLIMMER },
    { 35, SOUL, 3.5, LMYSTIC, 1.5, SGLOW },
    { 40, VISION, 1.5, GMYSTIC, 1.5, LGLOW },
    { 45, VISION, 3.5, LNETHER, 1.5, SRADIANT },
    { 50, DREAM, 1.5, GNETHER, 1.5, LRADIANT },
    { 55, DREAM, 3.5, LETERNAL, 1.5, SBRILLIANT },
    { 60, ILLUSION, 1.5, GETERNAL, 1.5, LBRILLIANT },
    { 65, ILLUSION, 3.5, GETERNAL, 2.5, LBRILLIANT },
}
-- Blue: { up to item level, shard }
local RARE = {
    { 25, SGLIMMER }, { 30, LGLIMMER }, { 35, SGLOW }, { 40, LGLOW },
    { 45, SRADIANT }, { 50, LRADIANT }, { 55, SBRILLIANT }, { 65, LBRILLIANT },
}
-- Epic: { from, to item level, material, avg count }
local EPIC = {
    { 40, 45, SRADIANT, 3 }, { 46, 50, LRADIANT, 3 }, { 51, 55, SBRILLIANT, 3 },
    { 56, 60, NEXUS, 1 }, { 61, 94, NEXUS, 1.5 },
}

DE.GREEN_DUST, DE.GREEN_ESSENCE, DE.GREEN_SHARD = 0.75, 0.20, 0.05

local NOT_DE = { INVTYPE_BODY = true, INVTYPE_TABARD = true, INVTYPE_BAG = true, INVTYPE_AMMO = true, INVTYPE_QUIVER = true, [""] = true }

-- AHSentinel available?
function DE.AHS()
    local A = _G.AHAnalyzerPro
    return A and A.Disenchant and A.Disenchant.GetValue and A.Disenchant or nil
end

---------------------------------------------------------------------------
-- Item info (crafted items are often not cached yet: request them, refresh once they arrive)
---------------------------------------------------------------------------
local requested = {}
local refreshTimer
local loader = ns.AddEventFrame(CreateFrame("Frame"), "Disenchant")
pcall(loader.RegisterEvent, loader, "GET_ITEM_INFO_RECEIVED")
loader:SetScript("OnEvent", function(_, _, itemID)
    if not requested[itemID] or refreshTimer or not C_Timer then return end
    refreshTimer = true
    C_Timer.After(1, function()
        refreshTimer = nil
        if ns.RefreshAll then ns.RefreshAll() end
    end)
end)

local function ItemInfo(itemID)
    if not (ns.API.GetItemInfo or (ns.API.ItemGetItemInfo)) then return nil end
    local info = { pcall(ns.ItemInfo, itemID) }      -- old global first, C_Item in the modern client
    if not info[1] or not info[2] then
        if not requested[itemID] then
            requested[itemID] = true
            if ns.API.ItemRequestLoadItemDataByID then pcall(ns.API.ItemRequestLoadItemDataByID, itemID) end
        end
        return nil
    end
    -- quality, item level, equip location, class
    return info[4], info[5], info[10], info[13]
end

-- Starting values (fallback without AHSentinel)
function DE.Prior(itemID)
    local quality, ilvl, equipLoc, classID = ItemInfo(itemID)
    if not quality or quality < 2 or quality > 4 or not ilvl then return nil end
    if classID ~= 2 and classID ~= 4 then return nil end
    if NOT_DE[equipLoc or ""] then return nil end
    local weapon = (classID == 2)
    if quality == 2 then
        if ilvl < 5 then return nil end
        for _, b in ipairs(UNCOMMON) do
            if ilvl <= b[1] then
                local pDust, pEss = DE.GREEN_DUST, DE.GREEN_ESSENCE
                if weapon then pDust, pEss = DE.GREEN_ESSENCE, DE.GREEN_DUST end
                return { { b[2], pDust, b[3] }, { b[4], pEss, b[5] }, { b[6], DE.GREEN_SHARD, 1 } }
            end
        end
    elseif quality == 3 then
        if ilvl < 11 then return nil end
        for _, b in ipairs(RARE) do
            if ilvl <= b[1] then
                if b[2] == LBRILLIANT and ilvl >= 56 then return { { LBRILLIANT, 0.995, 1 }, { NEXUS, 0.005, 1 } } end
                return { { b[2], 1, 1 } }
            end
        end
    else
        for _, b in ipairs(EPIC) do
            if ilvl >= b[1] and ilvl <= b[2] then return { { b[3], 1, b[4] } } end
        end
    end
    return nil
end

---------------------------------------------------------------------------
-- Expected value (gross, before the 5 % cut)
---------------------------------------------------------------------------
function DE.Value(itemID)
    if not itemID or not DE.WantsGold() then return nil end
    -- test mode: fixed values
    if ns.Sim and ns.Sim.de and ns.Sim.de[itemID] ~= nil then
        local v = ns.Sim.de[itemID]
        if v == false then return nil end
        return v, true, nil, 0, 0, "Test"
    end
    local D = DE.AHS()
    if D then
        local ok, v, complete, yield, own, shared = pcall(D.GetValue, D, itemID)
        if not ok then ns.CountError("AHSentinel:Disenchant.GetValue", v) end
        if ok and v then return v, complete, yield, own or 0, shared or 0, "AHSentinel" end
        if ok then return nil end
    end
    local yield = DE.Prior(itemID)
    if not yield then return nil end
    local value, complete, any = 0, true, false
    for _, e in ipairs(yield) do
        local p = ns.Prices.AH(e[1])
        if p then value = value + e[2] * e[3] * p; any = true
        elseif e[2] >= 0.05 then complete = false end
    end
    if not any then return nil end
    return math.floor(value + 0.5), complete, yield, 0, 0, "table"
end

-- Can the item be disenchanted at all (independent of prices)?
function DE.IsDisenchantable(itemID)
    if ns.Sim and ns.Sim.de and ns.Sim.de[itemID] ~= nil then return ns.Sim.de[itemID] ~= false end
    local D = DE.AHS()
    if D and D.Prior then
        local ok, prior = pcall(D.Prior, D, itemID)
        if not ok then ns.CountError("AHSentinel:Disenchant.Prior", prior) end
        return ok and prior ~= nil
    end
    return DE.Prior(itemID) ~= nil
end

---------------------------------------------------------------------------
-- Statistics for the "Entzaubern" tab (only with AHSentinel)
---------------------------------------------------------------------------
-- { { key, label, own, shared, rows = { { id, chance, prior, avg } } } }
function DE.Groups()
    local D = DE.AHS()
    if not (D and D.Groups and D.YieldForKey) then return nil end
    local ok, groups = pcall(D.Groups, D)
    if not ok then ns.CountError("AHSentinel:Disenchant.Groups", groups) end
    if not ok or type(groups) ~= "table" then return {} end
    local out = {}
    for _, g in ipairs(groups) do
        if type(g) ~= "table" then g = {} end
        local okY, y, prior = pcall(D.YieldForKey, D, g.key)
        if not okY then ns.CountError("AHSentinel:Disenchant.YieldForKey", y); y = nil end
        if type(y) == "table" then
            local okK, q, from, to, weapon = true, nil, nil, nil, nil
            if D.KeyInfo then okK, q, from, to, weapon = pcall(D.KeyInfo, D, g.key) end
            if not okK then ns.CountError("AHSentinel:Disenchant.KeyInfo", q); q, from, to, weapon = nil, nil, nil, nil end
            local priorBy = {}
            for _, e in ipairs(type(prior) == "table" and prior or {}) do
                if type(e) == "table" then priorBy[e[1]] = e[2] end
            end
            local rows = {}
            for _, e in ipairs(y) do
                if type(e) == "table" and type(e[2]) == "number" then
                    rows[#rows + 1] = { id = e[1], chance = e[2], avg = e[3], prior = priorBy[e[1]] or 0 }
                end
            end
            table.sort(rows, function(a, b) return a.chance > b.chance end)
            out[#out + 1] = { key = g.key, quality = q, from = from, to = to, weapon = weapon,
                              own = g.own or 0, shared = g.shared or 0, rows = rows }
        end
    end
    return out
end

function DE.Totals()
    local D = DE.AHS()
    if not D then return nil end
    local own, shared, players = 0, 0, 0
    if D.TotalLearned then
        local ok, n = pcall(D.TotalLearned, D)
        if ok then own = tonumber(n) or 0 else ns.CountError("AHSentinel:Disenchant.TotalLearned", n) end
    end
    if D.TotalShared then
        local ok, n, p = pcall(D.TotalShared, D)
        if ok then shared, players = tonumber(n) or 0, tonumber(p) or 0 else ns.CountError("AHSentinel:Disenchant.TotalShared", n) end
    end
    return own, shared, players
end

-- only bargains that keep the minimum margin: price <= value after the cut × (1 - margin)
function DE.FilterDeals(list, margin)
    margin = margin or DE.Margin()
    local out = {}
    for _, d in ipairs(list or {}) do
        if d.price and d.net and d.price <= d.net * (1 - margin) then out[#out + 1] = d end
    end
    return out
end

-- AH bargains from AHSentinel: items currently cheaper than their disenchant value after the cut,
-- with at least your minimum margin
function DE.Deals(max)
    local D = DE.AHS()
    if not (D and D.FindDeals) then return nil end
    local ok, list = pcall(D.FindDeals, D)
    if not ok then ns.CountError("AHSentinel:Disenchant.FindDeals", list) end
    if not ok or type(list) ~= "table" then return {} end
    list = DE.FilterDeals(list)
    table.sort(list, function(a, b) return (a.profit or 0) > (b.profit or 0) end)
    if max and #list > max then
        for i = #list, max + 1, -1 do list[i] = nil end
    end
    return list
end

---------------------------------------------------------------------------
-- Sniper (AHSentinel): buy items to disenchant and reagents for "craft & disenchant"
-- with your minimum margin. Only the budget is left to set in the sniper.
--
-- Margin m (ns.db.deMargin, %): what you pay may be at most (1 - m) of what the
-- materials bring after the 5 % AH cut.
--   items:     max price = disenchant value after cut × (1 - m)
--   reagents:  the whole craft may cost at most value after cut × (1 - m); vendor
--              reagents keep their price, AH reagents get their market value × factor
--              (factor capped at 1: never above the market value)
---------------------------------------------------------------------------
DE.SNIPE_ITEM_QTY = 10      -- pieces per item target
DE.SNIPE_CRAFTS = 10        -- crafts per recipe for the reagent targets
DE.SNIPE_RECIPES = 5        -- best recipes of "craft & disenchant" for the reagent targets

function DE.Margin()
    local m = tonumber(ns.db and ns.db.deMargin) or 20
    if m < 0 or m >= 100 then m = 20 end
    return m / 100
end

-- deals = { { itemID, net (after cut), quantity }, ... } -> { { id, maxPrice, qty } }
function DE.ItemTargets(deals, margin)
    margin = margin or DE.Margin()
    local out = {}
    for _, d in ipairs(deals or {}) do
        local maxPrice = math.floor((d.net or 0) * (1 - margin))
        if d.itemID and maxPrice > 0 then
            out[#out + 1] = { id = d.itemID, maxPrice = maxPrice, qty = math.max(DE.SNIPE_ITEM_QTY, d.quantity or 1) }
        end
    end
    return out
end

-- entries = Advisor entries of "craft & disenchant" (with .price) -> { { id, maxPrice, qty } }, recipes used
function DE.ReagentTargets(entries, margin, maxRecipes, crafts)
    margin = margin or DE.Margin()
    maxRecipes = maxRecipes or DE.SNIPE_RECIPES
    crafts = crafts or DE.SNIPE_CRAFTS
    local byID, used = {}, 0
    for _, e in ipairs(entries or {}) do
        if used >= maxRecipes then break end
        local pr = e.price
        if pr and pr.deValue and pr.known and e.learned ~= false then
            local allowed = pr.deValue * (1 - margin)
            local vendorCost, ahCost = 0, 0
            for _, part in ipairs(pr.parts) do
                if part.origin == "vendor" then vendorCost = vendorCost + part.unit * part.count
                else ahCost = ahCost + part.unit * part.count end
            end
            if ahCost > 0 and allowed > vendorCost then
                local factor = math.min(1, (allowed - vendorCost) / ahCost)
                used = used + 1
                for _, part in ipairs(pr.parts) do
                    if part.origin ~= "vendor" then
                        local maxPrice = math.max(1, math.floor(part.unit * factor))
                        local t = byID[part.id]
                        if t then
                            t.qty = t.qty + part.count * crafts
                            t.maxPrice = math.min(t.maxPrice, maxPrice)   -- the strictest recipe decides
                        else
                            byID[part.id] = { id = part.id, maxPrice = maxPrice, qty = part.count * crafts }
                        end
                    end
                end
            end
        end
    end
    local out = {}
    for _, t in pairs(byID) do out[#out + 1] = t end
    table.sort(out, function(a, b) return a.id < b.id end)
    return out, used
end

function DE.Sniper()
    local A = _G.AHAnalyzerPro
    return A and A.Sniper and A.Sniper.SetTarget and A.Sniper or nil
end

-- hand the targets to AHSentinel's sniper and open it
function DE.SendToSniper(targets, what, doneText)
    if ns.BlockedInCombat() then return 0 end
    local Sn = DE.Sniper()
    if not Sn then ns.Print(L.SNIPE_NEED_AHS); return 0 end
    local made = 0
    for _, t in ipairs(targets or {}) do
        local ok, err = pcall(Sn.SetTarget, Sn, tostring(t.id), t.maxPrice, t.qty, t.maxPrice * t.qty)
        if ok then made = made + 1 else ns.CountError("AHSentinel:Sniper.SetTarget", err) end
    end
    ns.Print(doneText and string.format(doneText, made, what or "") or string.format(L.SNIPE_DONE, made, what or "", math.floor(DE.Margin() * 100 + 0.5)))
    local UI = _G.AHAnalyzerPro.UI
    if made > 0 and UI and UI.Show and UI.SelectTab then
        pcall(UI.Show, UI)
        pcall(UI.SelectTab, UI, "sniper")
    end
    return made
end

function DE.SnipeDeals()
    if not DE.WantsGold() then return 0 end
    local deals = DE.Deals() or {}
    if #deals == 0 then ns.Print(L.SNIPE_NOTHING); return 0 end
    return DE.SendToSniper(DE.ItemTargets(deals), L.SNIPE_WHAT_ITEMS)
end

function DE.SnipeReagents()
    if not DE.WantsGold() then return 0 end
    local AD = ns.Advisor
    local list = AD and AD.current.de or {}
    local targets, used = DE.ReagentTargets(list)
    if #targets == 0 then ns.Print(L.SNIPE_NOTHING_MATS); return 0 end
    return DE.SendToSniper(targets, string.format(L.SNIPE_WHAT_MATS, used))
end

function DE.EditMargin()
    if not StaticPopupDialogs then return end
    StaticPopupDialogs.PROFESSIONSENTINEL_DE_MARGIN = {
        text = PopupText(L.DE_MARGIN_ASK), button1 = OKAY or "OK", button2 = CANCEL or "Cancel",
        hasEditBox = true, timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
        OnShow = function(self)
            local eb = self.editBox or self.EditBox
            if eb then eb:SetText(tostring(ns.db.deMargin or 20)); eb:HighlightText() end
        end,
        OnAccept = function(self)
            local eb = self.editBox or self.EditBox
            local n = eb and tonumber(((eb:GetText() or ""):gsub(",", "."):gsub("%%", "")))
            if n and n >= 0 and n < 100 then ns.db.deMargin = n end
            if ns.RefreshAll then ns.RefreshAll() end
        end,
        EditBoxOnEnterPressed = function(self)
            local n = tonumber(((self:GetText() or ""):gsub(",", "."):gsub("%%", "")))
            if n and n >= 0 and n < 100 then ns.db.deMargin = n end
            self:GetParent():Hide()
            if ns.RefreshAll then ns.RefreshAll() end
        end,
    }
    StaticPopup_Show("PROFESSIONSENTINEL_DE_MARGIN")
end
