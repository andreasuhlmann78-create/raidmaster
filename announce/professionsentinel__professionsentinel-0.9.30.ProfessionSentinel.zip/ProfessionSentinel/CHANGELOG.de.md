# ProfessionSentinel – Änderungen

## 0.9.30
Wunsch des Nutzers (9. November): **Mengenfenster am Händler**
- **Shift+Klick auf eine Ware im Blizzard-Händlerfenster** öffnet ein kleines Fenster von ProfessionSentinel statt Blizzards Dialog (der nur bis zu einem Stapel geht): Icon, Name, Preis pro Stück (bzw. pro Packung), Mengenfeld, Gesamtpreis, „Kaufen“ und „Abbrechen“. Vorbelegt mit der fehlenden Menge laut Einkaufsliste, sonst ein Stapel. Enter = Kaufen, Esc = Abbrechen, Mausrad ±1, Shift+Mausrad ±1 Stapel
- „Kaufen“ kauft genau diese Menge über mehrere Käufe – dieselbe Funktion wie die Einkaufsliste (volle Stapel, dann der Rest; Packungen aufgerundet mit Hinweis; begrenzte Ware höchstens so viel, wie der Händler hat, mit Hinweis; zu wenig Gold oder volle Taschen: so viel wie möglich und eine Chat-Zeile). Nur auf Klick, nie automatisch; das Fenster dockt rechts am Händlerfenster an und schliesst mit ihm
- Rechtsklick (1 kaufen) und Linksklick (aufnehmen) bleiben, wie sie sind; bei aktivem Chat-Eingabefeld fügt Shift+Klick nur den Link ein. Kein Taint: nur `hooksecurefunc` auf `MerchantItemButton_OnModifiedClick`, Blizzards Dialog wird danach nur ausgeblendet. Classic Era genauso
- Option „Mengenfenster am Händler (Shift+Klick)“, Standard an, `/ps menge`; steht beim Rechtsklick auf den Minimap-Button bei den übrigen Optionen
- Spieltest: neue Prüfung **S10** „Shift+Klick öffnet das Mengenfenster, Blizzard-Dialog geschlossen, Chat-Link geht weiter“
- Testroutine: neuer Testfall **T215** (Fenster öffnet, Blizzard-Dialog zu; Chat-Feld aktiv → nur Link; Option aus; 60 bei Stapel 20 → 20+20+20; Packung 5, Eingabe 12 → 15 mit Hinweis; begrenzte Ware 3, Eingabe 10 → 3 mit Hinweis; Gold für 7 → 7; Händler zu → Fenster zu)

## 0.9.29
Wunsch des Nutzers (9. November): **Händlerware in freier Menge kaufen**
- **Einkaufsliste (Reiter „Plan“):** Bei offenem Händler bekommt jede Zeile mit Händlerware (z. B. Leere Phiole, Grober Faden) ein Mengenfeld – vorbelegt mit der fehlenden Menge, frei änderbar – und einen Knopf **„Kaufen“**. Der Tooltip des Knopfs zeigt vor dem Kauf den Gesamtpreis
- Auf Klick kauft er **genau diese Menge**, auch über mehrere Käufe (volle Stapel bis zum Höchstwert des Händlers, dann der Rest); Ware in Packungen (z. B. 5 Stück) wird auf ganze Packungen aufgerundet, der Chat sagt es. Zu wenig Gold, volle Taschen oder der Händler hat nicht mehr: so viel wie möglich und eine Chat-Zeile. Nur auf Klick bei offenem Händler, nie automatisch; die Käufe laufen wie bisher über `ns.Act`. Das Diagnose-Protokoll notiert KAUF (Material, gewünscht, gekauft, Preis)
- Spieltest: neue Prüfung **S9** „gekaufte Menge = eingegebene Menge (bzw. ganze Packungen)“ – vergleicht kurz nach dem Kauf die Taschen
- Testroutine: neuer Testfall **T214** (16 bei Stapel 20 → 1 Kauf; 50 → 20+20+10; Packung 5, Eingabe 12 → 15 mit Hinweis; Gold reicht für 7 → 7 und Meldung; volle Taschen; ohne offenen Händler nichts; S9); T213 an S9 angepasst

## 0.9.28
- **Neu: Spieltest `/ps spieltest an|aus|bericht`** (Wunsch des Nutzers): Statt die Checkliste von Hand abzuarbeiten, prüft ProfessionSentinel sich selbst, während du spielst – sobald du die Lage herstellst (Berufsfenster öffnen, Rezepte anklicken, herstellen, Skillpunkt holen). Es ruft nie selbst eine geschützte Funktion auf und tut im Kampf nichts an der Oberfläche. Standard aus; eingeschaltet läuft er bis /reload, höchstens 2 Stunden
  - **S1** Klick öffnet das Rezept sofort (Weg „Liste“, < 0,5 s; Ergebnis nach 5 Klicks) · **S2** Fertigkeit > 0 und der Plan beginnt bei der Fertigkeit · **S3** „N× bis Gelb“ sinkt nach einem Skillpunkt · **S4** Panel überdeckt weder Berufsfenster noch AHSentinel-Fenster (auch wenn es später erscheint) · **S5** AH-Gebühr ist dieselbe Zahl wie in AHSentinel · **S6** Rangliste Leveln: gelernte zuerst, nach Material pro Punkt sortiert, nichts Graues · **S7** 5 Gegenstände herstellen löst keinen Sturm aus (höchstens 2 Neuaufbauten/s, nichts über 16 ms) · **S8** die Oberflächen-Prüfung aus Bereich K einmal bei offenem Berufsfenster
  - Jedes Ergebnis (OK / FEHLER mit Messwert und Erwartung) kommt ins Diagnose-Protokoll; ein FEHLER gibt eine Chat-Zeile je Prüfung. `/ps spieltest bericht` listet OK / FEHLER / offen mit der Lage, die noch fehlt, und speichert einen GSTEST1-Bericht (Bereich „S“) für die Prüfung. Keine Namen
- Testroutine: neuer Testfall **T213** (jede Prüfung S1–S8 mit einer OK- und einer FEHLER-Lage, eine Chat-Zeile je FEHLER, Bericht mit OK/FEHLER/offen)

## 0.9.27
Leistung (im Spiel brauchte das Panel bis 44 ms, das beste Rezept 20 ms, AD.Plan 68 ms; Grenze 16 ms) und zwei Befunde der Testroutine:
- **Einmal je Durchlauf rechnen:** Ein Update (AD.Update, UI:Refresh, AD.Plan) bewertete ein Rezept bis zu dreimal (Leveln, Gold, Entzaubern) und fragte AHSentinel immer wieder nach denselben Marktpreisen. Jetzt wird jeder AH-Wert, jeder Rezeptpreis und jede Taschenzahl einmal je Durchlauf berechnet; der Zwischenspeicher wird am Ende des Durchlaufs verworfen, es veraltet also nichts
- **Diagnose-Protokoll zeigt den langsamen Teil:** Neben UI:Refresh protokolliert es jetzt UI:UpdateBest und UI:Refresh/<Ansicht> einzeln (nur über 16 ms)
- **T145 Speicher:** Nach dem Lauf verwirft die Testroutine vor der Messung die abgeleiteten Zwischenspeicher, die sie mit Testdaten gefüllt hat (Gilden-Index mit 300 Mitgliedern, Ranglisten mit „alles gelernt“, Rezept-ID-Tabelle, eigene Kopie des Berichts)
- **T132 globale Namen:** Die Unterelemente, die Blizzard-Vorlagen nach unseren eigenen Fenstern benennen (…Bg, …CloseButton, …Inset, …Portrait, …TitleText), gelten als eigene und werden nicht mehr gemeldet
- Testroutine: neuer Testfall **T212** (ein Update fragt jeden Marktpreis und jede Taschenzahl nur einmal; der Durchlauf endet immer)

## 0.9.26
Die Testroutine prüft die Oberfläche im echten Client (Anweisung vom 5. Nov., Vorlage UICheck.lua):
- **Neu UICheck.lua** (aus der GoldSentinel-Vorlage, in allen vier TOCs): Panel, Diagnose-Protokoll, Testbericht, Testmodus und die Verzauberer-Frage melden sich mit `ns.RegisterUI` an – so können auch die anderen GoldSentinel-Addons gegen sie prüfen
- **Neuer Bereich K** (`/ps testroutine k`): **T206** eigene Tooltips verdecken keine Knöpfe, **T207** kein Überlappen mit Berufsfenster, AHSentinel-Gewinn-Fenster und anderen GoldSentinel-Fenstern, **T208** Fenster ganz im Bildschirm, **T209** Beschriftungen von Knöpfen nicht abgeschnitten – diese vier nur im echten Client mit offenem Panel (sonst mit Hinweis übersprungen, nie als OK gezählt); **T210** Spielwerte plausibel: „Fertigkeit > 0, wenn Beruf gelernt“ und „Plan beginnt bei der Fertigkeit“ (`ns.Plausible`); **T211** keine Fehlerschleife (gleiche Meldung mehr als 10×)

## 0.9.25
**Gebührenregel für WoW Forever (Angabe des Nutzers vom 9. November, ersetzt alle früheren):** Es gibt nur EINE Gebühr – die AH-Gebühr = max(5 % vom Verkaufspreis der Auktion, 1 Silber), pro Auktion (pro eingestelltem Stapel, nicht pro Stück), bezahlt beim Einstellen. Eine separate Einstellgebühr gibt es nicht.
- Prices.lua: keine Einstellgebühr aus dem Händlerwert mehr. Gebühr pro Stück = max(5 % × Verkaufspreis eines vollen Stapels, 1s) ÷ Stapelgrösse; netto = AH-Wert − AH-Gebühr. Ist AHSentinel geladen, wird dessen Gebührenfunktion verwendet (gleiche Zahl in beiden Addons). Entzauberungsmaterial genauso. Classic Era, TBC und Retail unverändert (5 % Kommission beim Verkauf)
- Tooltip: eine Zeile „AH-Gebühr (5 %, mind. 1s)“ statt „AH-Kommission“ plus „Einstellgebühr“; unter dem Netto „davon AH-Gebühr“
- Testroutine: T35 prüft jetzt die Regel (3s 90c → 1s, 2s → 1s, 1g → 5s, Stapel 20 × 1c → einmal 1s, keine eigene Einstellgebühr, AHSentinel-Funktion gilt); T33 und der alte Selbsttest angepasst

## 0.9.24
Korrektur aus dem Diagnose-Protokoll (0.9.22 in WoW Forever): **Ereignis-Sturm am Berufsfenster** – 7450 Neuaufbauten durch TRADE_SKILL_LIST_UPDATE, UI:Refresh 101 ms und AD.Update 39 ms bei jedem Mal; das waren die Ruckler.
- **Ursache:** Nach jedem TRADE_SKILL_LIST_UPDATE wurden alle Rezepte gescannt und alles neu gerechnet und gezeichnet – auch bei geschlossenem Panel. Das Lesen der Rezeptliste kann das Spiel wieder TRADE_SKILL_LIST_UPDATE senden lassen, der Scan hat sich also selbst angetrieben
- **Jetzt:** Listen-Ereignisse direkt nach dem eigenen Scan werden verworfen (1 s); Ereignisse werden gesammelt (ein Scan je 0,5 s); ein voller Neuaufbau (rechnen + zeichnen) nur, wenn sich Beruf, Fertigkeit oder gelernte Rezepte wirklich geändert haben oder das Fenster geöffnet / ein Rezept gelernt / ein Skillpunkt geholt wurde. Sonst wird nur ein sichtbares Panel aus dem Zwischenspeicher neu gezeichnet – ein verborgenes gar nicht. Ergebnisse bleiben bis zu 30 s gespeichert (vorher 5 s). Das Panel wird höchstens alle 0,5 s neu aufgebaut
- **Andocken:** Das Panel dockt auch neu an, wenn das AHSentinel-Fenster seine Grösse ändert (OnSizeChanged), zusätzlich zu OnShow/OnHide und jedem eigenen Refresh
- Die Tooltip-Zeile „davon Einstellgebühr“ (Schritt 1 der Liste vom 9. Nov.) ist seit 0.9.19 drin
- Testroutine: neuer Testfall **T205** (100 Listen-Ereignisse ohne Änderung → kein voller Neuaufbau, verborgenes Panel nicht neu gezeichnet, Ereignisse direkt nach dem eigenen Scan verworfen; ein Skillpunkt baut weiter neu auf); T91 und T190 angepasst

## 0.9.23
Korrektur aus dem Spiel (WoW Forever, 5. November): Mit 0.9.20 sprang das Berufsfenster immer noch sehr langsam zum Rezept.
- **Auswahl über die Liste des Fensters, wie AHSentinel:** Ein Klick wählt das Rezept jetzt mit `ProfessionsFrame.CraftingPage.RecipeList:SelectRecipe(recipeInfo, true)` – das springt im selben Frame dorthin. `C_TradeSkillUI.OpenRecipe` (springt in WoW Forever erst viel später) ist nur noch der Rückfall. Das Diagnose-Protokoll zeigt den Weg („Liste“ / „OpenRecipe“)
- **Rezept-ID-Tabelle bleibt erhalten:** Sie wird nur noch neu gelesen, wenn das Fenster öffnet oder den Beruf wechselt oder ein Rezept gelernt wurde – nicht mehr bei jedem TRADE_SKILL_LIST_UPDATE (vorher musste der nächste Klick alle Rezepte neu lesen)
- Testroutine: neue Testfälle **T203** (Klick wählt über die Liste und scrollt dorthin, kein OpenRecipe; Auswahl im selben Frame gemeldet; Rückfall auf OpenRecipe) und **T204** (20 Listen-Ereignisse → Tabelle höchstens 1× gebaut; Berufswechsel baut sie neu)

## 0.9.22
Testroutine nach den bei LevelPilot bewährten Regeln:
- **Ehrliche Zählung:** Ein Testfall, der nichts geprüft hat, zählt nie mehr als OK – er gilt als übersprungen („nicht automatisiert – keine Prüfung lief“). Das betraf T195 im modernen Client. Nach jedem Lauf folgt den Zahlen eine Zeile **„Nicht automatisiert: N“** (übersprungen plus im Client prüfen)
- **Feste Liste „im Spiel prüfen“:** Der Lauf merkt sich alle Fälle, die nur das Spiel prüfen kann; `/ps testroutine liste` gibt sie mit Anleitung aus und sagt, wie man bestätigt (`/ps testroutine ok <ID>`)
- **Jeder Fehler aus dem Spiel hat einen eigenen Testfall** – geprüft vom neuen Fall **T202** (Popup-%, Andocken, Fertigkeit 0, spät erscheinendes AHSentinel-Fenster, Klick ohne AHSentinel und ohne Warten, Diagnose-Protokoll)

## 0.9.21
- **Neu: Diagnose-Protokoll `/ps protokoll`** (nach dem Vorbild von LevelPilot): ein Fenster mit kopierbarem Text – Version, Client, Interface, Sitzungen, geänderte Einstellungen, Diagnose (Preisquelle, Panel offen, angedockt an Berufsfenster oder AHSentinel-Fenster, Neuaufbauten) und die Einträge, neueste zuerst: **KLICK** (Rezept, Zauber-ID, Rezept-ID, Weg, ms, ausgewählt ja/nein), **AUFBAU** (gesammelter Neuaufbau: Auslöser, Anfragen, ms), **LANGSAM** (UI:Refresh, AD.Update, Plan über 16 ms), **ÜBERLAPPT** (keine freie Stelle / Panel überdeckt das AHSentinel-Fenster), **FEHLER** (Lua-Fehler des Addons, gleicher Fehler nur gezählt). Ringpuffer mit 200 Einträgen in ProfessionSentinelDB.diag
- Beim /reload oder Ausloggen wird das Protokoll als **GSDIAG1**-Zeichenkette in `ProfessionSentinelDB.diagExport` abgelegt (Kopfzeile `GSDIAG1|ProfessionSentinel|<Version>|<Client>|<Interface>|<Datum>`, dann der Text, höchstens 24 000 Zeichen), damit der RaidMasterUploader es wie die GSTEST1-Berichte mitschicken kann. Spieler-, Realm-, Gilden- und Charakternamen werden durch `<Name>` ersetzt. Die Testroutine schreibt nie ins echte Protokoll
- Testroutine: neue Testfälle **T198** (alle fünf Arten, zählen statt fluten, Klick im Panel wird protokolliert), **T199** (Ringpuffer, Testlauf schreibt nicht, beschädigtes Protokoll repariert), **T200** (GSDIAG1-Kopfzeile, Grösse, Köder-Namen nie im Export, kein Export während der Testroutine), **T201** (`/ps protokoll` öffnet das Fenster)

## 0.9.20
Korrektur aus dem Spiel (WoW Forever, 5. November): Ein Klick im Panel öffnete das Rezept nur, wenn es vorher in AHSentinel angeklickt worden war; sonst sprang das Fenster erst nach 50 Sekunden oder mehr dorthin.
- **ProfessionSentinel ermittelt die Rezept-ID des offenen Fensters jetzt selbst** (ohne AHSentinel): Die Rezept-IDs des Fensters (GetAllRecipeIDs) werden einmal in eine Tabelle Name / Ergebnis-Item → Rezept-ID gelesen, erneut wenn sich die Liste des Fensters ändert. Ein Klick nimmt die eigene ID des Fensters – nach deutschem oder englischem Namen, sonst nach Ergebnis-Item, sonst die ID, die das Fenster zur Zauber-ID meldet – und öffnet sie sofort. Im selben Frame wird geprüft, ob das Fenster es zeigt (kein Timer)
- Testroutine: neuer Testfall **T197** (der Fall aus dem Spiel: ohne AHSentinel, das Fenster antwortet auch auf die Zauber-ID, führt das Rezept aber unter eigener ID → seine ID wird sofort geöffnet, ohne Timer, bestätigt in < 0,5 s; Ergebnis-Item bei anderem Namen); T196 angepasst

## 0.9.19
Korrektur aus dem Spiel (WoW Forever, 5. November):
- **Behoben: Ein Klick auf ein Rezept öffnete seit 0.9.18 nichts mehr** (dafür kam eine Chat-Meldung). Unsere Daten führen die Classic-Zauber-ID, das moderne Berufsfenster kennt das Rezept aber teils unter einer anderen Rezept-ID. Der Klick sucht jetzt die Rezept-ID des offenen Fensters: die Zauber-ID, wenn das Fenster sie unter demselben Namen kennt, sonst das Rezept des Fensters mit demselben deutschen oder englischen Namen (ohne Platzhalter- und Umschmiede-Einträge), und öffnet dieses. Die Meldung kommt nur noch, wenn das Rezept wirklich nicht im Fenster ist. Ein Linksklick löst weiterhin genau einmal aus (beim Drücken)
- **Tooltip: „davon Einstellgebühr“** unter „Netto pro Herstellung“ (und unter dem Entzauberungs-Netto) in WoW Forever, damit die Zahl nachvollziehbar ist. Die Rechnung selbst bleibt gleich (Einstellgebühr mind. 1s pro Auktion, nie erstattet; 5 % Kommission)
- Testroutine: neuer Testfall **T196** (Zauber-ID → Rezept-ID des Fensters, deutscher und englischer Name, gleiche ID, Rezept fehlt → Meldung; eine Aktion pro Klick); T193/T194 angepasst

## 0.9.18
Korrektur aus dem Spiel (WoW Forever, 5. November): Ein Klick auf ein Rezept im Panel öffnete es im Berufsfenster nur manchmal.
- **Ursache: Die Liste wurde während des Klicks neu aufgebaut.** Berufs-Ereignisse kommen in Schüben (TRADE_SKILL_LIST_UPDATE mehrmals pro Sekunde), und jedes baute das Panel neu auf. Jetzt werden sie gesammelt, und das Panel wird höchstens alle 0,4 s neu aufgebaut
- **Einmal rechnen, oft zeichnen:** Leveln-, Gold- und Material-Rangliste werden zwischengespeichert und nur neu gerechnet, wenn sich Beruf, Fertigkeit, Rezept-/Lerndaten, Testmodus oder Preisquelle ändern (bei AH-Preisen spätestens nach 5 s). Reiterwechsel und Tippen im Suchfeld zeichnen nur noch
- **Linksklick beim Drücken:** Zeilen nehmen den Linksklick schon beim Drücken an, ein Neuaufbau zwischen Drücken und Loslassen kann ihn nicht mehr verschlucken
- **Öffnen ist robuster:** Ein Suchtext im Berufsfenster wird vorher geleert; in Classic Era auch der Namensfilter, und zugeklappte Kategorien werden aufgeklappt. Geht es trotzdem nicht, sagt eine kurze Chat-Meldung (DE/EN) Bescheid, statt dass nichts passiert. Der Hintergrund der Liste nimmt keine Klicks an
- Testroutine: neue Testfälle **T192** (20 Ereignisse in 1 s → höchstens 3 Neuaufbauten; Zwischenspeicher), **T193** (Klick bei geplantem Neuaufbau öffnet das Rezept), **T194** (Suchtext aktiv → richtiges Rezept; Meldung bei Fehlschlag), **T195** (zugeklappte Kategorie; Hintergrund nimmt keine Klicks)

## 0.9.17
Wunsch des Nutzers (5. November):
- **Reiter Rangliste: „Leveln – Material pro Skillpunkt“** statt „Gold pro Skillpunkt“. Zuerst stehen die gelernten Rezepte, darunter die noch nicht gelernten (eigener Unterteil „Noch nicht gelernt“). Beide Teile sind nach der geringsten Materialmenge pro erwartetem Skillpunkt sortiert – reine Menge der Reagenzien, nicht ihr Gold-Wert. Zwischenprodukte desselben Berufs zählen als ihr Grundmaterial (Schmiedekunst rechnet in Barren). Erwartete Punkte pro Herstellung: orange 1, gelb 0,5, grün 0,25; graue Rezepte fallen weg. Die Zeile zeigt dort keinen Gold-Wert mehr, nur noch, wie oft bis zur nächsten Farbe. „Gold verdienen“, „Top 10“, der Stern und der Levelplan bleiben, wie sie sind
- Testroutine: neuer Testfall **T191** (orange 2 Barren und gelb 1 Barren beide Wert 2, Gleichstand in stabiler Reihenfolge; ungelerntes Rezept mit Wert 1 unter allen gelernten; graues Rezept fehlt; Zwischenprodukt als Grundmaterial)

## 0.9.16
Korrektur aus dem Spiel (WoW Forever, 5. November):
- **Das Gewinn-Fenster von AHSentinel liegt nicht mehr über dem Panel:** Es erscheint oft später (z. B. bei der Rezeptwahl), wenn das Panel schon angedockt ist. Mit AHSentinel 0.65.11+ hängt sich das Panel jetzt einmal über `AHAnalyzerPro.Crafting:GetDockFrame(true)` an das AHSentinel-Fenster (auch solange es verborgen ist) und dockt neu an, sobald es ein- oder ausgeblendet wird, bei jedem eigenen Refresh und bei TRADE_SKILL_SHOW. Ältere AHSentinel-Versionen laufen wie bisher
- Testroutine: neuer Testfall **T190** (AHSentinel-Fenster erscheint nach dem Panel → einmal gehakt, rechts daneben angedockt, kein Überlappen; ältere AHSentinel-Versionen)

## 0.9.15
Korrektur aus dem Spiel (WoW Forever, 5. November):
- **Behoben: Fertigkeit im modernen Client als 0 gelesen** (WoW Forever, Retail): Der Levelplan begann bei 0 (z. B. Kochkunst 110/150: „von 0 bis 75“, Angeln 114/150: „von 0 bis 20“), und die Lebenslinie zeigte fast überall dasselbe „45× bis Gelb“ und zählte nicht herunter. Die Unterberufs-Info des Fensters kann 0 oder einen veralteten Wert liefern. Jetzt werden alle Quellen des offenen Berufs gelesen (Unter- und Hauptberufs-Info des Berufsfensters, die Fertigkeitslinie, GetProfessions/GetProfessionInfo), und der höchste gültige Wert gilt. Bei jedem Skillpunkt (CHAT_MSG_SKILL, SKILL_LINES_CHANGED, TRADE_SKILL_LIST_UPDATE) werden Plan und Lebenslinie damit neu gezeichnet. Ist kein gültiger Wert lesbar, zeigt der Plan „Fertigkeit unbekannt“, statt ab 0 zu planen
- Der Platzhalter im Suchfeld ist kürzer und bleibt auf einer Zeile
- Testroutine: neuer Testfall **T189** (Fertigkeit 110 simuliert → Plan beginnt bei 110; +1 → „N× bis Gelb“ sinkt; veralteter Wert und Rückfall; unbekannt bleibt unbekannt)

## 0.9.14
Korrekturen aus der Testroutine im Spiel (WoW Forever, 5. November):
- **Behoben: Lua-Fehler in den Eingabefenstern** für Aufschlag, Mindestgewinn und Entzauberungs-Marge (`GameDialog.lua: invalid option in 'format'`). Das Spiel schickt den Text des Fensters durch `string.format`, das „%“ in „in %“ brach das ab; jedes „%“ geht jetzt als „%%“ hinein. Testfall **T63** prüft jetzt auch, dass der Text `string.format` übersteht
- **Kein Überlappen mehr am Berufsfenster:** Ist das Gewinn-Fenster von AHSentinel offen, dockt das Panel rechts daran an, sonst wie bisher direkt rechts am Berufsfenster. Benutzt wird nur die Schnittstelle `AHAnalyzerPro.Crafting:GetDockFrame()` von AHSentinel; ältere AHSentinel-Versionen ohne sie bleiben unberührt (keine Suche nach Fenstern). Wird das AHSentinel-Fenster ein- oder ausgeblendet, dockt das Panel neu an. Am rechten Bildschirmrand weicht es unter das AHSentinel-Fenster oder links neben das Berufsfenster aus – nie über ein anderes Fenster. Verschoben wird nur das eigene Panel
- Testroutine: neue Testfälle **T187** (kein Überlappen mit und ohne AHSentinel, Bildschirmrand, ältere AHSentinel-Versionen, Fehler in der Schnittstelle) und **T188** (im Spiel mit AHSentinel prüfen)

## 0.9.13
- **Neu: Minimap-Button** (Buch-Symbol, wie bei allen GoldSentinel-Addons): Linksklick öffnet oder schliesst das Panel wie `/ps`, Rechtsklick listet die Optionen mit ihrem Stand und dem Befehl zum Umschalten (ProfessionSentinel hat kein Optionsfenster – seine Optionen sind die `/ps`-Befehle), Ziehen verschiebt ihn um die Minimap; die Position wird pro Konto gespeichert. `/ps minimap` blendet ihn aus und ein (Standard: an, auch in `/ps help`). Keine Bibliothek nötig, läuft in allen Spielversionen; beschädigte gespeicherte Positionen werden beim Laden repariert
- Testroutine: neue Testfälle **T182–T185** (Bereich B: Button da und sichtbar, aus-/einblenden mit `/ps minimap`, gespeicherter Winkel → Position nach /reload, simuliertes Ziehen, Reparatur beschädigter Werte, Linksklick öffnet und schliesst, Rechtsklick Optionen, Tooltip auf Englisch und Deutsch) und **T186** (im Spiel prüfen: sichtbar, Ziehen, Sprache des Tooltips)
- Testroutine: Die Beschreibung von `/ps testroutine api` sagt jetzt, was passiert – es werden nur Einträge der eigenen Tabelle `ns.API` umgeschaltet, nie eine Blizzard-Funktion

## 0.9.12
Korrekturen aus der Nachprüfung 0.9.11:
- **Keine Blizzard-Funktion wird mehr ersetzt, auch nicht in der Testroutine (Taint):** Das Addon ruft die Spiel-API nur noch über seine eigene Tabelle `ns.API` auf (beim Laden befüllt; Funktionen aus `C_`-Tabellen bekommen flache Einträge wie `ns.API.MerchantGetItemInfo`; fehlende Funktionen bleiben leer, ältere Spielversionen gehen also ihren alten Weg). Die Testroutine schaltet nur Einträge dieser Tabelle um. Die `[api]`-Fälle laufen nur noch mit `/ps testroutine api` (mit Warnung vor dem Start), nicht mehr im normalen Lauf
- **Eine Stelle für Aktionen mit Folgen:** Kaufen beim Händler, VZ-Angebote flüstern (mit `C_ChatInfo.SendChatMessage` als zweitem Weg, falls die globale Funktion fehlt), Herstellen und der Kartenpin laufen über `ns.Act`; im Testlauf schreibt es nur mit. Neuer Testfall **T180** (Bereich I) prüft, dass jeder Aktionsweg dort ankommt und nichts Echtes passiert; `tests/check_actions.py` prüft den Quelltext
- **T145 Speicher:** gemessen nach Freigabe der eigenen Kopien des Laufs und zwei vollen Speicherbereinigungen, mit längerem Aufwärmen; offline zählt die Messung den kompilierten Code von LuaJIT nicht mehr mit (das Spiel hat kein JIT)
- Testroutine: Die Unterläufe von T20 und T110 nehmen jetzt wirklich nur Bereich F
- **Realms mit Bindestrich** (z. B. Retail „Azjol-Nerub“): Der eigene Charakter erscheint im Tooltip nicht mehr bei „deine anderen Charaktere“ (neuer Testfall T181)
- „Bitte /reload“ nach jedem Testlauf; die restlichen Testtexte („GoldSentinelTest/SavedVariables fehlen“, „Erneut starten“, „Alles markieren“) kommen jetzt aus den Locales (EN/DE)
- Geschützte Werte (WoW Forever, Retail im Kampf): Ereignis „Rezept gelernt“, Tooltips, der VZ-Kunde und die Gildenliste fragen zuerst `IsSecret`, vor jedem Vergleich
- Für Spieler ändert sich an Aussehen und Bedienung nichts

## 0.9.11
- Intern: **eine Testroutine** für den Entwickler (`/ps testroutine`, Knopf „Alles testen“ im Testmodus): 179 Testfälle (T01–T179) in zehn Bereichen, die Ergebnisse gehen über die gemeinsame `GoldSentinelTest.lua` an die Prüfung. `/ps selftest` und `/ps autotest` laufen jetzt über dieselbe Maschine. Für Spieler ändert sich nichts
- Lua-Fehler des Addons werden jetzt lokal gezählt (höchstens 50 Arten) und mit dem nächsten Testbericht gemeldet; das Addon selbst sendet nichts
- Behoben, gefunden von den neuen Testfällen (ältere Spielversionen laufen exakt wie bisher):
  - moderner Client: Stapelgröße, Händler-Verkaufspreis, Entzauberungswerte und Shift-Klick-Links gehen auch ohne das alte `GetItemInfo`
  - geschützte Werte im Kampf (WoW Forever, Retail): Ereignis „Rezept gelernt“, Tooltips, der Kunde für VZ-Angebote und die Gildenliste benutzen sie nie
  - Fehler in AHSentinel brechen den Verzauberer-Reiter nicht mehr ab; beschädigte gespeicherte Daten (Favor-Kosten, Planziel, VZ-Preise, Charaktere) werden beim Laden repariert statt Lua-Fehler auszulösen
  - Einkaufen, Flüstern, Sniper-Ziele und Wegpunkte werden im Kampf mit kurzem Hinweis abgelehnt

## 0.9.10
Rezeptdaten aktualisiert (WoW-Forever-Client 1.60.1.70753, QuestieDB 2026-11-02):
- **Neues Rezept:** Stiefel - Geschwindigkeit (Verzauberkunst, Stufe 280) – Formel beim Händler
- **37 Rezepte mit neu bekannter Händlerquelle**, jetzt mit Preis und benötigter Stufe: z. B. die Kettenrüstungen des Veteranen, Gardisten und Beschützers (Schmiedekunst 80–125), 18 Lederverarbeitungs-Muster, die Herz-des-Berges-Formeln (Verzauberkunst 265) und Schwacher Trank des Zauberschlags (Alchemie 35)
- Classic Era und Retail: keine Änderungen an Rezepten (nur Datenstand)

## 0.9.9
Korrekturen aus der Nachprüfung von 0.9.8:
- **WoW Forever, Ruf:** Dein Ruf wird jetzt auch im modernen Client gelesen (`C_Reputation`) – die Rufstufe bei Favor-Rezepten wird wieder grün bzw. rot statt immer gelb
- **Händlergunst von AHSentinel:** übernommen wird nur noch Merchant's Favor, keine andere Währung (sonst stimmten Preis und Stand nicht)
- **Kosten nicht lesbar?** Kann der Client die Favor-Kosten beim Händler nicht lesen, sagt das Addon das einmal pro Händlerbesuch; in der Diagnose steht „Händler-Kosten lesbar: ja/nein“
- **Kistenrechner:** Bei grünen Kisten (Barren, Stoffballen, Bauteile) zählt jetzt das Günstigere aus Kaufen und **selbst Herstellen**; im Tooltip steht, was benutzt wurde
- **Neu, standardmässig aus:** die beste Kiste (Gold pro Gunst) oben in „Heute herstellen“ – einschalten im Reiter Gunst oder mit `/ps kisten`
- Favor-Kosten und Rufstufe jetzt auch im Item-Tooltip (Taschen, AH)
- Ältere Spielversionen: Händlerkauf wieder exakt wie früher; die neue Reiter-Verteilung ohne Lücken gilt nur in WoW Forever

## 0.9.8
- Intern: **GoldSentinelGame.lua Version 2** – setzt sich gegen frühe, zurückgezogene Fassungen anderer GoldSentinel-Addons durch und verträgt sich mit ihnen (keine Lua-Fehler, wenn mehrere Addons verschiedene Fassungen mitbringen). Für Spieler ändert sich nichts

## 0.9.7
- **WoW Forever, Händler:** Wurde ein Handelslager-Händler nur mit AHSentinel besucht, übernimmt ProfessionSentinel jetzt auch die Währung – der Stand deiner Händlergunst erscheint dann ohne eigenen Händlerbesuch. Reihenfolge der Kosten: selbst beim Händler gelesen → von AHSentinel gelesen → Guides
- Händlerkauf und Lesen der Kosten sind gegen fehlende alte Händler-Funktionen im modernen Client abgesichert (Anzahl, Link, Kauf); ältere Spielversionen laufen unverändert (im Client testen)

## 0.9.6
- Intern: Die Spielversion kommt jetzt aus **GoldSentinelGame.lua**, der gemeinsamen Erkennung aller GoldSentinel-Addons (dieselbe Datei wie in RaidMaster, GuildSentinel, ThreatSentinel und BuffSentinel). WoW Forever gilt dort immer als moderner Client, nie als Classic. `/gsgame` zeigt im Chat, was erkannt wurde. Für Spieler ändert sich sonst nichts

## 0.9.5
- **WoW Forever: neuer Reiter „Gunst“** (Händlergunst / Merchant's Favor)
  - **Favor-Planer:** Favor-Rezepte (Klick) und Ziele – Packkodo 6000, Minimuli 1500, Berufs-Zertifizierung 1000, Wappenrock 200 – auf die Wunschliste; das Addon zeigt deinen Stand und wie viel noch fehlt. Gelernte Rezepte fallen von selbst heraus
  - **Favor-Rezepte deines Berufs** mit Kosten, Rufstufe und **wer in der Gilde sie schon kann** (Daten aus GuildSentinel/RaidMaster)
  - **Kistenrechner:** alle 30 Abgefangenen Kisten mit dem günstigsten Materialbündel (AH- bzw. Händlerpreise), der leeren Kiste aus dem AH und **Gold pro Gunst-Punkt**. Kisten in deinen Taschen stehen oben, „bereit“ heißt: das Material liegt schon da. Die Gunst der Fachmann-Kisten ist noch geschätzt
- **WoW Forever: Kauf beim Händler** (Levelplan, Heute herstellen) nutzt jetzt die Händler-Funktionen des modernen Clients – die alten gibt es dort nicht mehr (im Client testen)
- Liest AHSentinel beim Händler die Kosten in Händlergunst, nutzt ProfessionSentinel diese Werte, wenn es selbst noch keine hat
- 0.9.3 und 0.9.4 (gemeinsame Versionserkennung) wurden zurückgezogen; sie kommt später für alle GoldSentinel-Addons zusammen

## 0.9.2
- **WoW Forever: Rezepte der Handelslager kosten Händlergunst statt Gold.** Bei den 310 Rezepten von „Versorgung und Logistik Durotar“ (Horde, Brachland) und der „Handelskommission von Azeroth“ (Allianz, Three Corners) stand bisher ein Goldpreis, der im Spiel nicht gilt. Jetzt zeigt der Tooltip die Kosten in **Merchant's Favor** und die nötige **Rufstufe** (Allianz-Spieler sehen ihre Fraktion)
- Die Werte stammen aus öffentlichen Guides (Beta-Stand). **Öffnest du einen Handelslager-Händler, liest das Addon die echten Kosten aus** und merkt sie sich – diese gelten dann vor den Guide-Werten. Hast du die Währung einmal beim Händler gesehen, steht im Tooltip auch, wie viel du davon hast
- Rezepte, die es auch bei normalen Händlern gibt (z. B. Geräucherter Weisenfisch), behalten ihren Goldpreis

## 0.9.1
- **WoW Forever: Einstellgebühr** – jede Auktion kostet mindestens 1 Silber, und die gibt es nicht zurück. Sie wird jetzt vom AH-Erlös abgezogen (zusätzlich zu 5 % Kommission): Gold verdienen, Leveln, Heute herstellen, Entzaubern-Material
- Günstige Items lohnen sich dadurch oft eher beim Händler – das Addon nimmt dann den Händlerpreis (z. B. AH 1s 50c → nur 42c übrig, Händler zahlt 71c)
- Tooltip zeigt die Gebühr als eigene Zeile

## 0.9.0
- **Heute herstellen** (oben im Reiter „Rangliste“, `/ps heute`): die lukrativsten Herstellungen aus allen deinen Berufen – gelernte Rezepte, Verkauf im AH, netto nach 5 % Kommission; höchstens 5 pro Rezept und 20 % deines Golds pro Zeile
- **Ein Klick = nächster Schritt:** Händlerware kaufen (Händler offen) → AH-Zutaten kaufen (über AHSentinel) → herstellen (Berufsfenster offen) → im AH einstellen (über AHSentinel)
- Schnittstelle für AHSentinel: Die Herstellungs-Vorschläge können dort in „Heute tun“ erscheinen (kommt mit der nächsten AHSentinel-Version)

## 0.8.3
- Intern: Das Testmodus-Fenster für den Entwickler (`/ps test`) geht nach dem Einloggen schon beim ersten Mal auf. Für Spieler ändert sich nichts

## 0.8.2
- Intern: Der Entwickler-Autotest nennt den Grund, wenn das Testmodus-Fenster nicht aufgeht, und klappt nur Gruppen mit Zeilen auf und zu (keine falschen Warnungen mehr bei leeren Ranglisten). Für Spieler ändert sich nichts

## 0.8.1
- Retail: Fehler „Attempt to register unknown event TRADE_SKILL_UPDATE“ beim Laden behoben – Berufs-Ereignisse werden nur noch angemeldet, wenn das Spiel sie kennt

## 0.8.0
- **Retail** (12.1.5 Midnight, Interface 120105): ProfessionSentinel läuft jetzt auch im normalen WoW – mit rund **10 170 Rezepten aller Erweiterungen** direkt aus dem Retail-Client
- In Retail ist **jede Erweiterung ein eigener Beruf mit eigener Stufe** wie im Berufsfenster (z. B. „Lederverarbeitung von Midnight“, „Klassische Lederverarbeitung“) – Rezepte, Lebenslinie, Rangliste, Levelplan bis zur Höchststufe der Erweiterung, Ruf, Rezept-Alarm und Material-Tooltip funktionieren dort
- Retail hat keine QuestieDB: keine Händler-, Drop- und Lehrer-Koordinaten (der Reiter „Lehrer“ ist dort ausgeblendet); Händlerware wie Fäden und Farbstoffe wird aus Classic übernommen, neue Händlerpreise liest AHSentinel beim Händlerbesuch
- Verzauberkunst in Retail: nur „VZ verkaufen“ – die Entzauberungstabellen gelten dort nicht
- Händlerpreise: wo die Daten keinen kennen, nimmt ProfessionSentinel den Preis, den AHSentinel beim Händler abgelesen hat (alle Spielversionen)

## 0.7.1
- Intern: automatischer Test im Spiel für den Entwickler (öffnet für jeden Beruf alle Reiter und Knöpfe, fängt Lua-Fehler ab und schreibt einen Bericht). Für Spieler ändert sich nichts

## 0.7.0
- **Levelplan** (neuer Reiter „Plan“): von deiner Fertigkeit bis 75/150/225/300 – welches Rezept wie oft, mit Einkaufsliste (fehlt nach Taschen und Bank). Ein Klick kauft beim offenen Händler genau das Fehlende, ein zweiter legt die AH-Zutaten in den Sniper von AHSentinel (Marktwert + 10 %)
- **Ruf-Rezepte:** im Tooltip steht, welcher Ruf auf welcher Stufe nötig ist – grün, wenn du ihn schon hast (auch neue Forever-Fraktionen wie Kirin Tor)
- **Rezept-Alarm:** liegt ein Rezept, das dir oder einem Twink fehlt, im AH (Scan mit AHSentinel), kommt eine Meldung mit Ton; im Reiter „Rezepte“ stehen sie oben, Klick = Sniper. Aus/an: `/ps alarm`
- **Gilde** (Daten aus GuildSentinel / RaidMaster): wer kann das Rezept herstellen (online zuerst), Gruppe „Kennt niemand in der Gilde“ und die **Abklingzeiten** (Transmutation, Mondstoff, Salzstreuer)
- **Rezepte in deinen Taschen:** wer sie noch braucht – oder keiner (dann verkaufen); **Material-Tooltip:** in wie vielen Rezepten ein Material gebraucht wird und welche davon du kennst (auch Raid-Material wie Lavakern)
- **VZ verkaufen:** Rechtsklick flüstert dem Kunden Material und Preis (auch mit seinem Material)
- Leveln: profitable Rezepte mit kleiner Chance gewinnen nicht mehr nur, weil viele Herstellungen viel Gewinn ergeben – Gewinn zählt pro Herstellung × Chance

## 0.6.5
- Verzauberkunst: Beim **ersten Einloggen** fragt ein Fenster nach deinem Ziel – **Gold machen** (Standard, vorgemerkt), **VZ verkaufen** oder **beides**. Das Fenster bleibt offen, bis du eins gewählt hast, und du schließt es selbst mit „Fertig“. Bis dahin gilt Gold machen. Später ändern: `/ps ziel` oder oben im Reiter „Verzauberer“

## 0.6.4
- Verzauberkunst: keine Frage mehr beim Einloggen – Standard ist **Gold machen**. Umstellen auf VZ verkaufen oder beides optional mit `/ps ziel` oder oben im Reiter „Verzauberer“; einmal pro Charakter kommt ein kurzer Hinweis im Chat

## 0.6.3
- Testmodus und Selbsttest (`/ps test`, `/ps selftest`) gibt es nur noch für den Entwickler – wie bei AHSentinel. Für alle anderen funktioniert das Addon genau gleich, nur ohne diese Werkzeuge

## 0.6.2
- Verzauberer: „Schnäppchen im AH“ zeigt nur noch Gegenstände, die deine **Mindestmarge beim Entzaubern** einhalten – genau die, die auch der Sniper kauft

## 0.6.1
- Nur für Verzauberer mit dem Ziel „Gold machen“ oder „beides“: **Mit dem Sniper kaufen** – ein Klick legt die Schnäppchen (Gegenstände billiger als entzaubert) oder die AH-Zutaten deiner besten Rezepte aus „Herstellen & Entzaubern“ als Ziele in den Sniper von AHSentinel. Max-Preis und Menge sind schon eingestellt, du stellst nur noch das Budget ein
- **Mindestmarge beim Entzaubern** (Standard 20 %) einstellbar: du zahlst höchstens 80 % dessen, was das Material nach AH-Kommission bringt
- Entzaubern gibt es nur noch im Reiter „Verzauberer“: „Gold verdienen“ in der Rangliste der anderen Berufe rechnet wieder nur mit dem Verkauf
- „Herstellen & Entzaubern“ umfasst jetzt die Rezepte **aller deiner Berufe**

## 0.6.0
- Verzauberkunst: Wer Verzauberkunst hat, wird einmal gefragt, wofür – **Gold machen**, **VZ verkaufen** oder **beides**. Das Addon richtet den Verzauberungsteil danach aus, alles andere bleibt gleich. Ändern jederzeit mit `/ps ziel` oder im neuen Reiter „Verzauberer“
- **Gold machen:** Entzauberungswert jedes herstellbaren Gegenstands (Material abzüglich 5 % AH-Kommission). „Gold verdienen“ nimmt Entzaubern, wenn es mehr bringt (DE); neue Gruppe **„Herstellen & Entzaubern“** – Material kaufen, herstellen, entzaubern, nach Gewinn sortiert
- Reiter „Verzauberer“: **Schnäppchen im AH**, die weniger kosten, als sie entzaubert bringen, und die **gelernten Dropchancen** im Vergleich zu den Startwerten
- Dropchancen lernen aus jeder Entzauberung – deiner und der aller Spieler mit AHSentinel. Startwerte bei grünen Teilen: 75 % Staub, 20 % Essenz, 5 % Splitter (Waffen umgekehrt)
- **VZ verkaufen:** alle deine Verzauberungen mit Materialkosten (AH- bzw. Händlerpreise) und deinem **Verkaufspreis** – Aufschlag in % und Mindestgewinn stellst du selbst ein
- Leveln rechnet weiter nur mit dem Verkauf
- Testmodus: Verzauberer simulieren und die drei Ziele durchschalten

## 0.5.1
- Gewinnrechnung zieht die 5 % AH-Kommission vom Verkaufspreis ab – Rangliste, Gold verdienen und Netto pro Punkt rechnen mit dem echten Erlös
- Lohnt sich der Händler nach Abzug der Kommission mehr, zählt der Händlerpreis
- Tooltip zeigt Verkauf im AH, AH-Kommission (5 %) und Erlös aus dem AH

## 0.5.0
- Gold in der Rangliste: „Leveln“ nach Gold pro Skillpunkt, neue Gruppe „Gold verdienen“ nach Netto-Gewinn pro Herstellung – auch graue Rezepte
- Materialkosten: Händlerware zum Händlerpreis, alles andere zum AH-Wert (auch selbst Gefarmtes); Produkt zum höheren Wert aus AH und Händler
- AH-Werte aus AHSentinel (sonst TSM oder Auctionator); ohne AH-Addon bleibt die Rangliste bei Material pro Skillpunkt
- Zeilen zeigen die Herkunft der Zutaten (AH / Händler / Farm) und „+10s 80c/Pkt“; der Tooltip schlüsselt jede Zutat mit Preis, Kosten, Verkaufswert und Netto auf
- Testmodus: „Testpreise“, um die Gold-Rangliste ohne AH-Scan auszuprobieren

## 0.4.0
- Rangliste zum Leveln: alle Rezepte, die bei deiner Fertigkeit Punkte bringen – gelernte und nicht gelernte – sortiert nach Material pro Skillpunkt (Material ÷ Chance auf einen Punkt)
- Neuer Reiter „Rangliste“ mit der ganzen Liste, Top 10 oben im Reiter „Rezepte“; noch nicht gelernte Rezepte mit [lernen] und Quelle
- Stern beim besten gelernten Rezept in Blizzards Rezeptliste, Hinweis mit Platz und Material pro Punkt am Berufsfenster (Klick wählt es aus)
- Rezepte weit über deiner Fertigkeit zählen nicht mehr als orange: fehlende Lernstufen werden geschätzt (WoW Forever über die Era-Stufe desselben Rezepts)
- Classic Era: Rezepte aus Season of Discovery entfernt (1267 echte Era-Rezepte)

## 0.3.0
- Neuer Reiter „Lehrer“: alle Lehrer des offenen Berufs nach Rang – Geselle (bis 150), Experte (bis 225), Fachmann (bis 300), Spezialisierungen – mit Zone, Koordinaten und Fraktion; dein nächster Rang ist markiert
- Händler und Drop-Gegner im Rezept-Tooltip jetzt mit Zone und Koordinaten
- Klick auf einen Lehrer setzt einen Wegpunkt, Rechtsklick auf ein Rezept einen Wegpunkt zum nächsten Händler (TomTom, sonst Kartenpin des Spiels)
- Zonennamen in der Sprache des Spiels; neue WoW-Forever-Gebiete (Insel Zephras, Flusslande) unterstützt
- Testmodus: Prüfungen für Lehrer und Wegpunkte, Knopf „Wegpunkt testen“

## 0.2.0
- Erkennt die Spielversion am Client und passt sich an: WoW Forever (eigene Rezepte und Fertigkeitsstufen – viele Rezepte werden früher grau) und Classic Era (klassisches Berufs- und Verzauberungsfenster)
- Lebenslinie: dünne Linie unter jedem Rezept (orange → gelb → grün → grau) mit Markierung deiner Fertigkeit und wie oft du bis zur nächsten Farbe herstellen musst – in Blizzards Rezeptliste und im Panel „Alle Rezepte“
- Tooltip zeigt Herstellungen bis Gelb, Grün und Grau
- Testmodus (/ps test): Diagnose, simulierte Fertigkeit, simuliert gelernt/nicht gelernt, Panel ohne Berufsfenster, Selbsttest (/ps selftest)
- /ps line schaltet die Lebenslinie an und aus
- Vertauschte Fertigkeitsstufen bei einzelnen Rezepten im Client korrigiert (z. B. Aufgeladene Schuppe von Onyxia)

## 0.1.0
- Erste Version für WoW Forever (Interface 16001)
- Knopf „Alle Rezepte“ im Berufsfenster, gegliedert wie die Kategorien im Spiel
- Gelernte Rezepte ausgegraut, fehlende in Seltenheitsfarbe
- Tooltips mit Fertigkeitsstufen, Reagenzien und Quelle (Lehrer, Händler, Drop, Quest)
- Tooltip bei Rezepten: gelernt oder nicht, auch für deine anderen Charaktere
- 2210 Rezepte, davon 934 neu in WoW Forever
