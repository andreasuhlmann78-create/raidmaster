if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.7 - Briefkasten: Post abholen
--
-- Am Briefkasten erscheinen zwei Knöpfe:
--   "AH-Post abholen" - Gold und Items aus Auktionspost (verkauft,
--                        gekauft, abgelaufen, abgebrochen, überboten)
--   "Alles"           - jede Post (außer Nachnahme)
-- Vorher werden alle Rechnungen für die Buchhaltung gelesen.
-- Abgeholt wird eins nach dem anderen (der Server braucht kurz),
-- bei vollen Taschen wird angehalten. Nachnahme (COD) wird nie bezahlt.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local CreateFrame, C_Timer = A.OwnCreateFrame or CreateFrame, A.OwnTimer or C_Timer      -- VS-BILD-2 (0.65.320): eigene Skripte/Zeitgeber je Bild messen (nur während einer Vollscan-Messung)
local L = A.L

-- Briefkasten über A.Inbox (im Testmodus: Test-Briefkasten mit fiktiver Post)
local function GetInboxNumItems(...) return A.Inbox.GetInboxNumItems(...) end
local function GetInboxHeaderInfo(...) return A.Inbox.GetInboxHeaderInfo(...) end
local function GetInboxInvoiceInfo(...) return A.Inbox.GetInboxInvoiceInfo(...) end
local function GetInboxItem(...) return A.Inbox.GetInboxItem(...) end
local function GetInboxItemLink(...) return A.Inbox.GetInboxItemLink(...) end
local function TakeInboxMoney(...) return A.Inbox.TakeInboxMoney(...) end
local function TakeInboxItem(...) return A.Inbox.TakeInboxItem(...) end

local M = {}
A.Mailer = M

-- Briefkasten offen? (Nahtstelle: die Testroutine ersetzt M.MailOpen, nie das Blizzard-Fenster MailFrame)
function M:MailOpen()
    local mf = _G.MailFrame
    return (type(mf) == "table" and mf.IsShown and mf:IsShown()) and true or false
end

local STEP = 0.35          -- Sekunden zwischen zwei Aktionen
local WAIT_MAX = 3         -- so lange auf die Antwort des Servers warten

M.running = false

-- Betreff-Muster der Auktionspost aus Blizzards eigenen Texten (jede Sprache)
local function SubjectPatterns()
    local out = {}
    for _, g in ipairs({ "AUCTION_SOLD_MAIL_SUBJECT", "AUCTION_WON_MAIL_SUBJECT", "AUCTION_EXPIRED_MAIL_SUBJECT",
                         "AUCTION_REMOVED_MAIL_SUBJECT", "AUCTION_OUTBID_MAIL_SUBJECT" }) do
        local fmt = _G[g]
        if type(fmt) == "string" and fmt ~= "" then
            local esc = fmt:gsub("([%(%)%.%+%-%*%?%[%]%^%$])", "%%%1")
            esc = esc:gsub("%%s", ".+")
            esc = esc:gsub("%%d", "%%d+")
            local pat = "^" .. esc
            table.insert(out, pat)
        end
    end
    return out
end

-- BH-ANZ-1: nur abgelaufen (nicht abgebrochen)?
function M:IsExpiredMail(i)
    local fmt = _G.AUCTION_EXPIRED_MAIL_SUBJECT
    if type(fmt) ~= "string" or fmt == "" then return false end
    local pat = "^" .. fmt:gsub("([%(%)%.%+%-%*%?%[%]%^%$])", "%%%1"):gsub("%%%%s", ".+"):gsub("%%s", ".+")
    local ok, _, _, _, subject = pcall(GetInboxHeaderInfo, i)
    return ok and type(subject) == "string" and subject:find(pat) ~= nil
end
-- T-BM6 (E b): Post "Auktion abgebrochen" (AUCTION_REMOVED_MAIL_SUBJECT) - auch nach Abbruch im Blizzard-Fenster
function M:IsRemovedMail(i)
    local fmt = _G.AUCTION_REMOVED_MAIL_SUBJECT
    if type(fmt) ~= "string" or fmt == "" then return false end
    local pat = "^" .. fmt:gsub("([%(%)%.%+%-%*%?%[%]%^%$])", "%%%1"):gsub("%%%%s", ".+"):gsub("%%s", ".+")
    local ok, _, _, _, subject = pcall(GetInboxHeaderInfo, i)
    return ok and type(subject) == "string" and subject:find(pat) ~= nil
end
-- Post mit zurückgekommener Ware (abgelaufen oder abgebrochen)?
function M:IsReturnMail(i)
    if not self.returnPatterns then
        self.returnPatterns = {}
        for _, g in ipairs({ "AUCTION_EXPIRED_MAIL_SUBJECT", "AUCTION_REMOVED_MAIL_SUBJECT" }) do
            local fmt = _G[g]
            if type(fmt) == "string" and fmt ~= "" then
                local esc = fmt:gsub("([%(%)%.%+%-%*%?%[%]%^%$])", "%%%1")
                esc = esc:gsub("%%s", ".+")
                table.insert(self.returnPatterns, "^" .. esc)
            end
        end
    end
    local ok, _, _, _, subject = pcall(GetInboxHeaderInfo, i)
    if not (ok and type(subject) == "string") then return false end
    for _, pat in ipairs(self.returnPatterns) do
        if subject:find(pat) then return true end
    end
    return false
end

function M:IsAuctionMail(i)
    local okI, invoiceType = pcall(GetInboxInvoiceInfo, i)
    if okI and invoiceType then return true end
    local ok, _, _, sender, subject = pcall(GetInboxHeaderInfo, i)
    if not ok then return false end
    for _, pat in ipairs(self.patterns or {}) do
        if type(subject) == "string" and subject:find(pat) then return true end
    end
    return false
end

local function FreeSlots()
    local n = 0
    for bag = 0, (NUM_BAG_SLOTS or 4) + (NUM_REAGENTBAG_SLOTS or 0) do   -- Retail: auch die Reagenzientasche
        local CC, old = A:Global("C_Container"), A:Global("GetContainerNumFreeSlots")
        if CC and CC.GetContainerNumFreeSlots then
            n = n + (select(1, CC.GetContainerNumFreeSlots(bag)) or 0)
        elseif old then
            n = n + (select(1, old(bag)) or 0)
        end
    end
    return n
end
M.FreeSlots = FreeSlots          -- für die Testroutine (T89)

local function FirstAttachment(i)
    if not GetInboxItem then return nil end
    for a = 1, (ATTACHMENTS_MAX_RECEIVE or 16) do
        local ok, name, itemID = pcall(GetInboxItem, i, a)
        if ok and (name or itemID) then return a, itemID end
    end
    return nil
end

-- ------------------------------------------------------------
-- POST-SCAN (Auftrag 21.11. 15:44, DAUERREGEL des Nutzers – nicht entfernen oder schwächen): jeden Brief VOR dem Leeren auslesen
-- (Art, Gold, Items + Menge, Rechnung) und je Brief EINE Chatzeile mit exakten Zahlen; am Ende die Summe. Gebucht wird weiter nur
-- über die bestehenden Wege (Ledger:ScanInbox, Books:OnTakeMoney/NoteInboxMail, Extras:NoteReturned) - keine zweite Buchung (F3).
-- ------------------------------------------------------------
function M:MailItems(i)
    local out = {}
    if not GetInboxItem then return out end
    for a = 1, (ATTACHMENTS_MAX_RECEIVE or 16) do
        local ok, name, itemID, _, count = pcall(GetInboxItem, i, a)
        if ok and (name or itemID) then
            out[#out + 1] = { name = name or (itemID and A:GetItemName(itemID)) or "?", id = itemID, count = count or 1 }
        end
    end
    return out
end
local function ItemsText(items)
    local parts = {}
    for _, it in ipairs(items) do parts[#parts + 1] = string.format("%d× %s", it.count or 1, it.name or "?") end
    return table.concat(parts, ", ")
end
M.ItemsText = ItemsText
local function FM(c) return A:FormatMoney(math.max(0, math.floor(c or 0))) end
-- Schlüssel eines Briefs, der beim Leeren gleich bleibt (Index verschiebt sich, Gold/Anzahl ändern sich)
function M:MailKey(i)
    local ok, _, _, sender, subject, _, _, daysLeft = pcall(GetInboxHeaderInfo, i)
    if not ok then return nil end
    return tostring(sender) .. "|" .. tostring(subject) .. "|" .. tostring(math.floor((daysLeft or 0) * 1440))
end
-- eine Zeile je Brief; zurück: Text, Gold im Brief, W3-E: Liste von Bausteinen zum Zusammenfassen (je Art und Item)
function M:DescribeMail(i)
    local ok, _, _, sender, subject, money, cod = pcall(GetInboxHeaderInfo, i)
    if not ok then return nil end
    money, cod = money or 0, cod or 0
    -- PM1 (Befund 22.11. 08:50, belegt): Feld 10 ist etaMin, nicht die Menge ("Gekauft: 36× … für 1s" bei 1 Stück) -> Feld 11 + Le:InvoiceQty
    local okI, itype, itemName, _, bid, buyout, deposit, consignment, _, _, _, f11 = pcall(GetInboxInvoiceInfo, i)
    if not okI then itype = nil end
    local count = 1
    if okI and (itype == "seller" or itype == "buyer") then
        local Le = A.Ledger
        -- PM1-d (Prüfung 23.11. 06:26): itemID aus dem Namen mitgeben -> Stapel-/Marktwert-Plausibilität von QtyFromField5 greift
        local okN, iid = pcall(function() return Le.ResolveName and Le.ResolveName(itemName) end)
        if Le and Le.InvoiceQty then local okQ, q = pcall(Le.InvoiceQty, Le, okN and iid or nil, buyout, bid, f11); if okQ and q then count = q end end
    end
    local items = self:MailItems(i)
    local it = ItemsText(items)
    if cod > 0 then
        return string.format(L["Nachnahme liegen gelassen: %s für %s"], it ~= "" and it or "-", FM(cod)), 0
    end
    if itype == "seller" then
        pcall(self.NoteInvoiceMail, self, i)                                                                    -- G17
        if A.SaleOutcome then pcall(A.SaleOutcome.NoteResult, A.SaleOutcome, "sold", nil, itemName, count or 1, (bid or buyout or 0), deposit) end   -- G10, G17-a
        local brutto = bid or buyout or 0
        local fee = consignment or 0
        local line = string.format(L["Verkauft: %d× %s für %s – erhalten %s (Gebühr %s)"], count or 1, itemName or "?", FM(brutto), FM(money), FM(fee))
        local rest = money - (brutto - fee)
        if rest > 0 then line = line .. string.format(L[" + Anzahlung zurück %s"], FM(rest))
        elseif rest < 0 then line = line .. string.format(L[" − weitere Abzüge %s"], FM(-rest)) end
        return line, money, { { k = "v", key = "v|" .. tostring(itemName), name = itemName or "?", n = count or 1, brutto = brutto, money = money, fee = fee,
            rp = rest > 0 and rest or 0, rn = rest < 0 and -rest or 0 } }
    end
    if itype == "buyer" then
        return string.format(L["Gekauft: %d× %s für %s"], count or 1, itemName or "?", FM(bid or buyout or 0)), money,
            { { k = "g", key = "g|" .. tostring(itemName), name = itemName or "?", n = count or 1, price = bid or buyout or 0, money = money } }
    end
    local function itemRecs(k)
        local r = {}
        for _, x in ipairs(items) do r[#r + 1] = { k = k, key = k .. "|" .. tostring(x.name), name = x.name or "?", n = x.count or 1, money = 0 } end
        if #r == 0 then r[1] = { k = k, key = k .. "|-", name = "-", n = 0, money = 0 } end
        r[1].money = money                                                  -- Gold im Brief zählt einmal
        return r
    end
    if self:IsExpiredMail(i) then
        if A.SaleOutcome then for _, x in ipairs(items) do pcall(A.SaleOutcome.NoteResult, A.SaleOutcome, "expired", x.id, x.name, x.count) end end   -- G10
        return string.format(L["Zurück (abgelaufen): %s"], it ~= "" and it or "-"), money, itemRecs("a")
    end
    if self:IsRemovedMail(i) then
        if A.SaleOutcome then for _, x in ipairs(items) do pcall(A.SaleOutcome.NoteResult, A.SaleOutcome, "cancelled", x.id, x.name, x.count) end end   -- G10
        return string.format(L["Zurück (abgebrochen): %s"], it ~= "" and it or "-"), money, itemRecs("b")
    end
    local outbid = _G.AUCTION_OUTBID_MAIL_SUBJECT
    if type(outbid) == "string" and outbid ~= "" and type(subject) == "string" then
        local pat = "^" .. outbid:gsub("([%(%)%.%+%-%*%?%[%]%^%$])", "%%%1"):gsub("%%%%s", ".+"):gsub("%%s", ".+")
        if subject:find(pat) then return string.format(L["Überboten – Rückzahlung %s"], FM(money)), money, { { k = "u", key = "u", money = money } } end
    end
    local who = (type(sender) == "string" and sender ~= "") and sender or L["unbekannt"]
    local parts = {}
    if money > 0 then parts[#parts + 1] = FM(money) end
    if it ~= "" then parts[#parts + 1] = it end
    return string.format(L["Post von %s: %s"], who, table.concat(parts, ", ")), money,
        { { k = "p", key = "p|" .. who, who = who, money = money, items = items } }
end
-- W3-E (Entscheid des Nutzers 23.11. 07:41): Post-Chat je Art und Item EINE Zeile (z. B. "Zurück (abgelaufen): 60× Seelenstaub"), Beträge
-- und Mengen = exakte Summen der Briefe; ersetzt "je Brief eine Zeile" (B5). Ausgabe gesammelt beim Ende des Abholens (M:FlushGroups),
-- vor "Summe Post". Nachnahme-Briefe weiter sofort (einmal je Öffnen). Zählung POST-ZEILEN: Briefe und Zeilen.
function M:AddGroup(rec)
    self.groups = self.groups or { order = {}, by = {} }
    local G = self.groups
    local g = G.by[rec.key]
    if not g then
        g = { k = rec.k, name = rec.name, who = rec.who, n = 0, brutto = 0, money = 0, fee = 0, rp = 0, rn = 0, price = 0, items = {}, itemOrder = {}, line = rec.line }
        G.by[rec.key] = g
        G.order[#G.order + 1] = rec.key
    end
    g.n = g.n + (rec.n or 0)
    g.brutto, g.money, g.fee = g.brutto + (rec.brutto or 0), g.money + (rec.money or 0), g.fee + (rec.fee or 0)
    g.rp, g.rn, g.price = g.rp + (rec.rp or 0), g.rn + (rec.rn or 0), g.price + (rec.price or 0)
    for _, x in ipairs(rec.items or {}) do
        local nm = x.name or "?"
        if not g.items[nm] then g.items[nm] = 0; g.itemOrder[#g.itemOrder + 1] = nm end
        g.items[nm] = g.items[nm] + (x.count or 1)
    end
end
function M:GroupLine(g)
    if g.line then return g.line end
    if g.k == "v" then
        local line = string.format(L["Verkauft: %d× %s für %s – erhalten %s (Gebühr %s)"], g.n, g.name, FM(g.brutto), FM(g.money), FM(g.fee))
        if g.rp > 0 then line = line .. string.format(L[" + Anzahlung zurück %s"], FM(g.rp)) end
        if g.rn > 0 then line = line .. string.format(L[" − weitere Abzüge %s"], FM(g.rn)) end
        return line
    elseif g.k == "g" then
        return string.format(L["Gekauft: %d× %s für %s"], g.n, g.name, FM(g.price))
    elseif g.k == "a" or g.k == "b" then
        local it = (g.name ~= "-" and g.n > 0) and string.format("%d× %s", g.n, g.name) or "-"
        local line = string.format(g.k == "a" and L["Zurück (abgelaufen): %s"] or L["Zurück (abgebrochen): %s"], it)
        if g.money > 0 then line = line .. ", " .. FM(g.money) end
        return line
    elseif g.k == "u" then
        return string.format(L["Überboten – Rückzahlung %s"], FM(g.money))
    elseif g.k == "p" then
        local parts = {}
        if g.money > 0 then parts[#parts + 1] = FM(g.money) end
        for _, nm in ipairs(g.itemOrder) do parts[#parts + 1] = string.format("%d× %s", g.items[nm], nm) end
        return string.format(L["Post von %s: %s"], g.who or L["unbekannt"], table.concat(parts, ", "))
    end
    return "?"
end
function M:FlushGroups()
    local G = self.groups
    self.groups = nil
    local out = {}
    if not G then return out end
    for _, key in ipairs(G.order) do
        local line = self:GroupLine(G.by[key])
        out[#out + 1] = line
        self.lines = self.lines or {}
        self.lines[#self.lines + 1] = line
        A:Print(line)
    end
    return out
end
-- vor dem ersten Abholen aus Brief i: Zeile ausgeben (einmal je Brief)
-- B5 (Befund 21.11. 18:45: "Summe Post: 0c aus 3 Briefen", "34 Items", keine Zeile je Brief sichtbar): belegt im Code - der Schlüssel
-- Absender|Betreff|Minute ist für GLEICHE Briefe gleich (z. B. mehrere "Auktion abgelaufen: Seelenstaub" aus derselben Minute), jeder
-- weitere solche Brief bekam KEINE Zeile und zählte nicht. Jetzt: derselbe Brief = gleicher Platz, gleicher Schlüssel UND gleiche
-- Anzahl Briefe im Kasten (ein Brief mit mehreren Anhängen wird über mehrere Schritte geleert; ist er weg, sinkt die Anzahl).
-- Nachnahme-Briefe weiter einmal je Öffnen (Schlüssel). Schlägt die Beschreibung fehl: Ersatzzeile und Protokoll, nie still.
function M:NoteMail(i, isCOD)
    local key = self:MailKey(i)
    if not key then return end
    self.noted = self.noted or {}
    local nBox = GetInboxNumItems and GetInboxNumItems() or 0
    if isCOD then
        if self.noted[key] then return end
    else
        local last = self.lastNote
        if last and last.i == i and last.key == key and last.n == nBox then return end
        self.lastNote = { i = i, key = key, n = nBox }
    end
    local okD, line, _, recs = pcall(self.DescribeMail, self, i)
    if not (okD and line) then
        if A.Diag then pcall(A.Diag.Add, A.Diag, "POST-ZEILE", string.format("Brief %d nicht lesbar: %s", i, tostring(line):sub(1, 120))) end
        line = string.format(L["Brief %d: nicht lesbar"], i)
        recs = nil
    end
    self.noted[key] = true
    if isCOD then
        self.lines = self.lines or {}
        self.lines[#self.lines + 1] = line
        A:Print(line)
        return
    end
    self.nLetters = (self.nLetters or 0) + 1
    -- W3-E: sammeln statt sofort drucken (Ausgabe in M:FlushGroups); Brief ohne Bausteine bleibt eine eigene Zeile
    self.groupSeq = (self.groupSeq or 0) + 1
    if type(recs) == "table" and #recs > 0 then for _, r in ipairs(recs) do self:AddGroup(r) end
    else self:AddGroup({ k = "x", key = "x|" .. self.groupSeq, line = line }) end
end
-- Nachnahme-Briefe einmal je Öffnen nennen (werden nie bezahlt)
function M:NoteCOD()
    local n = GetInboxNumItems and GetInboxNumItems() or 0
    for i = 1, n do
        local ok, _, _, _, _, _, cod = pcall(GetInboxHeaderInfo, i)
        if ok and (cod or 0) > 0 then self:NoteMail(i, true) end
    end
end

-- MAIL-1 (a): Kopfzeile noch nicht geladen ("Rufe Daten ab")? Dann sind Absender, Betreff und Anzahl leer
function M:HeaderLoading(i)
    local ok, _, _, sender, subject, money, _, _, itemCount = pcall(GetInboxHeaderInfo, i)
    if not ok then return false end
    local empty = function(x) return x == nil or (type(x) == "string" and x == "") end
    return empty(subject) and empty(sender) and (money or 0) == 0 and (itemCount or 0) == 0
end
function M:LoadingCount()
    local n = GetInboxNumItems and GetInboxNumItems() or 0
    local c = 0
    for i = 1, n do if self:HeaderLoading(i) then c = c + 1 end end
    return c
end
-- MAIL-1 (d): übersprungene Post messen (ohne Namen/Texte): Betreff-Länge, Muster-Treffer, Rechnungs-Art, Anzahl, Absender leer
function M:LogSkipped(i)
    if not (A.Diag and A:IsDev()) then return end
    self.skipLogged = self.skipLogged or {}
    if self.skipLogged[i] then return end
    self.skipLogged[i] = true
    local ok, _, _, sender, subject, money, _, _, itemCount = pcall(GetInboxHeaderInfo, i)
    if not ok then return end
    local okI, invType = pcall(GetInboxInvoiceInfo, i)
    local hit = false
    for _, pat in ipairs(self.patterns or {}) do if type(subject) == "string" and subject:find(pat) then hit = true end end
    pcall(A.Diag.Add, A.Diag, "POST-ÜBERSPRUNGEN", string.format("Post %d · Betreff-Länge %d · Muster %s · Rechnung %s · Anzahl %s · Gold %s · Absender leer %s",
        i, type(subject) == "string" and #subject or -1, hit and "ja" or "nein", tostring(okI and invType or "-"), tostring(itemCount), tostring(money),
        (sender == nil or sender == "") and "ja" or "nein"))
end
-- nächste Post mit etwas zum Abholen
function M:NextMail()
    local n = GetInboxNumItems and GetInboxNumItems() or 0
    for i = 1, n do
        local ok, _, _, sender, subject, money, cod, _, itemCount = pcall(GetInboxHeaderInfo, i)
        if ok and (not cod or cod == 0) and ((money or 0) > 0 or (itemCount or 0) > 0) then
            if not self.onlyAH or self:IsAuctionMail(i) then
                return i, money or 0, itemCount or 0
            end
            self:LogSkipped(i)
        end
    end
    return nil
end
-- MAIL-1 (c): gleiche Meldung höchstens 1× je 5 s in die Bildschirmmitte
function M:Screen(msg, r, g, b)
    local now = GetTime and GetTime() or 0
    self.lastScreen = self.lastScreen or {}
    if self.lastScreen[msg] and now - self.lastScreen[msg] < 5 then return false end
    self.lastScreen[msg] = now
    A:ScreenMessage(msg, r, g, b)
    return true
end
M.LOAD_WAIT = 10

function M:Start(onlyAH)
    if self.running then return false, L["Läuft schon ..."] end
    if not A.Inbox.Available() then return false, L["Dein Client unterstützt das Abholen der Post nicht."] end
    self.patterns = SubjectPatterns()
    self.onlyAH = onlyAH and true or false
    self.skipLogged = {}
    self.noted, self.lines, self.nLetters, self.lastNote, self.groups = {}, {}, 0, nil, nil   -- Post-Scan: neue Runde
    pcall(self.NoteCOD, self)
    -- erst die Rechnungen buchen, bevor die Post verschwindet
    if A.Ledger then pcall(A.Ledger.ScanInbox, A.Ledger) end
    -- nichts da: gleich sagen (sonst sieht man nicht, dass der Klick angekommen ist)
    if not self:NextMail() and self:LoadingCount() > 0 then
        -- MAIL-1 (a): Post lädt noch -> warten und von selbst weitermachen (höchstens LOAD_WAIT s)
        if CheckInbox then pcall(CheckInbox) end
        self.running = true
        self.money, self.items, self.mails = 0, 0, 0
        self.waiting, self.lastAction = nil, 0
        self.loadUntil = GetTime() + self.LOAD_WAIT
        self.startMoney = GetMoney and GetMoney() or 0
        local msg = L["Post lädt noch – Abholen läuft gleich weiter."]
        self:Screen(msg, 0.8, 0.8, 0.8)
        A:Fire("MAILER_CHANGED")
        return true, msg
    end
    if not self:NextMail() then
        local msg = onlyAH and L["Keine Auktionspost zum Abholen."] or L["Nichts zum Abholen."]
        -- TB168-10 (Screenshot 16:41): "Auktion erfolgreich"-Post da, aber das Gold ist noch nicht freigegeben (Forever:
        -- Geld kommt später) -> das sagen statt "keine Post"; Diagnose mit den Zahlen der Rechnung (ohne Namen)
        local pend, eta = self:PendingAuctionMoney()
        if pend > 0 then
            msg = eta and string.format(L["%d Auktionspost(en) da – das Gold kommt in etwa %d Min."], pend, eta)
                or string.format(L["%d Auktionspost(en) da – das Gold ist noch nicht freigegeben."], pend)
        end
        self:Screen(msg, 0.8, 0.8, 0.8)
        return true, msg
    end
    self.loadUntil = nil
    self.running = true
    self.money, self.items, self.mails = 0, 0, 0
    self.waiting, self.lastAction = nil, 0
    self.startMoney = GetMoney and GetMoney() or 0
    A:Fire("MAILER_CHANGED")
    return true, onlyAH and L["Hole Auktionspost ab ..."] or L["Hole alle Post ab ..."]
end

-- TB168-10: Auktionspost ohne Gold und ohne Ware (Gold noch nicht freigegeben). Zurück: Anzahl, kleinste Wartezeit (Min.) oder nil
function M:PendingAuctionMoney()
    local n = GetInboxNumItems and GetInboxNumItems() or 0
    local cnt, eta = 0, nil
    for i = 1, n do
        local ok, _, _, _, _, money, cod, _, itemCount = pcall(GetInboxHeaderInfo, i)
        if ok and (money or 0) == 0 and (itemCount or 0) == 0 and (not cod or cod == 0) and self:IsAuctionMail(i) then
            cnt = cnt + 1
            local okI, invType, _, _, bid, buyout, deposit, consignment, delay, etaH, etaM = pcall(GetInboxInvoiceInfo, i)
            if okI then
                local m = (type(etaH) == "number" and type(etaM) == "number") and (etaH * 60 + etaM) or (type(delay) == "number" and delay > 0 and math.ceil(delay / 60) or nil)
                if m and m > 0 and (not eta or m < eta) then eta = m end
                if A.Diag then
                    pcall(A.Diag.Add, A.Diag, "POST", string.format("Auktionspost ohne Gold: Art %s · Gebot %s · Sofortkauf %s · Anzahlung %s · Gebühr %s · Verzögerung %s · ETA %s:%s",
                        tostring(invType), tostring(bid), tostring(buyout), tostring(deposit), tostring(consignment), tostring(delay), tostring(etaH), tostring(etaM)))
                end
            end
        end
    end
    return cnt, eta
end
-- Liegt Auktionspost im Briefkasten?
function M:HasAHMail()
    if not A.Inbox.Available() then return false end
    local pats = SubjectPatterns()
    local n = GetInboxNumItems() or 0
    for i = 1, n do
        local ok, _, _, _, subject, money, cod, _, itemCount = pcall(GetInboxHeaderInfo, i)
        if ok and type(subject) == "string" and (cod or 0) == 0 and ((money or 0) > 0 or (itemCount or 0) > 0) then
            for _, pat in ipairs(pats) do
                if subject:find(pat) then return true end
            end
        end
    end
    return false
end

-- automatisch abholen, sobald der Briefkasten offen ist (Shift beim Öffnen = nicht abholen)
function M:AutoEnabled()
    return not (A.db and A.db.settings.autoCollect == false)
end

-- AUFTRAG 21.11. 14:58 (Nutzer 14:57 "nicht nur AH-Post abholen, sondern alles"): beim Öffnen ALLE Post mit Gold oder Gegenständen
-- (Auktionen, Händler, Spieler, Rücksendungen, abgelaufene). Nachnahme (COD) nie; reine Textbriefe bleiben liegen (NextMail).
-- Buchhaltung: Rechnungen werden vorher gelesen (Ledger:ScanInbox, nur Rechnungs-Art seller/buyer); Spieler-/Händler-Gold ist keine
-- Rechnung und wird nicht als Auktionsverkauf gebucht (Books:OnTakeMoney nur itype "seller"). Shift beim Öffnen = kein Auto.
function M:HasAnyMail()
    if not A.Inbox.Available() then return false end
    local was = self.onlyAH
    self.onlyAH = false
    local i = self:NextMail()
    self.onlyAH = was
    return i ~= nil
end
function M:TryAuto()
    if not self.autoPending then return end
    self.autoPending = nil
    if self.running or not self:AutoEnabled() then return end
    if IsShiftKeyDown and IsShiftKeyDown() then return end
    if self:HasAnyMail() then
        local ok, msg = self:Start(false)
        if ok and msg then A:Print(msg) end
    end
end

function M:Stop(reason)
    if not self.running then return end
    self.running = false
    local gained = (GetMoney and GetMoney() or 0) - (self.startMoney or 0)
    -- Testmodus: Gold aus dem Test-Briefkasten ist nur gezählt, nicht wirklich da
    if A:Simulated() then gained = gained + A.TestMode:TakeMailMoneyCount() end
    -- Die Gutschrift (PLAYER_MONEY) kommt oft erst NACH MAIL_INBOX_UPDATE, also nach dem Stop: dann ist die
    -- Gold-Differenz noch 0. Darum zählt der beim Abholen gelesene Betrag der Post (Befund 9. Nov. 08:19).
    gained = math.max(gained, self.money or 0)
    local msg = string.format(L["Post abgeholt: %s, %d Items"], A:FormatMoney(math.max(0, gained)), self.items)
    pcall(self.FlushGroups, self)                                                     -- W3-E: zusammengefasste Zeilen vor der Summe
    -- B5: messbar machen - Briefe mit Zeile, Zeilen insgesamt (mit Nachnahme), abgeholte Items
    if A.Diag then pcall(A.Diag.Add, A.Diag, "POST-ZEILEN", string.format("Briefe %d · Zeilen %d · Items %d", self.nLetters or 0, #(self.lines or {}), self.items or 0)) end
    -- Post-Scan: Summe = Summe der "erhalten"-Beträge der Zeilen (das Gold, das aus den Briefen genommen wurde)
    if (self.nLetters or 0) > 0 then
        local diff = (GetMoney and GetMoney() or 0) - (self.startMoney or 0)
        local sum = string.format(L["Summe Post: %s aus %d Briefen"], A:FormatMoney(math.max(0, self.money or 0)), self.nLetters)
        if diff ~= (self.money or 0) and not A:Simulated() then sum = sum .. " " .. string.format(L["(Gold bisher +%s, Gutschrift folgt)"], A:FormatMoney(math.max(0, diff))) end
        A:Print(sum)
        if A.SaleOutcome then pcall(A.SaleOutcome.Broadcast, A.SaleOutcome) end      -- G10 Teil B: neue Ergebnisse der Gilde melden
        pcall(self.BroadcastInvoices, self)                                                -- G17 (gedrosselt, nur bei Neuem)
    end
    if reason then msg = msg .. " - " .. reason end
    -- MAIL-1 (b): WoW zeigt höchstens 50 Posten - mehr liegt bereit
    local shown, total = 0, 0
    if GetInboxNumItems then shown, total = GetInboxNumItems() end
    if (total or 0) > (shown or 0) then msg = msg .. " - " .. string.format(L["weitere %d Posten: Briefkasten neu öffnen"], total - shown) end
    A:Print(msg)
    self:Screen(msg, 0.2, 0.87, 0.33)
    A:Fire("MAILER_CHANGED")
end

function M:Step()
    if not self.running then return end
    if not self:MailOpen() then return self:Stop(L["Briefkasten geschlossen"]) end
    local now = GetTime()
    if self.waiting and now - self.lastAction < WAIT_MAX then return end
    -- Testmodus: langsamer, damit man "Anhalten" sieht und ausprobieren kann
    local step = A:Simulated() and 0.8 or STEP
    if now - self.lastAction < step then return end
    self.waiting = nil
    local i, money, itemCount = self:NextMail()
    if not i then
        -- MAIL-1 (a)(b): weitere Post lädt noch -> warten (höchstens LOAD_WAIT s), nicht aufhören
        if self:LoadingCount() > 0 then
            self.loadUntil = self.loadUntil or (now + self.LOAD_WAIT)
            if now < self.loadUntil then
                if not self.loadAsked and CheckInbox then self.loadAsked = true; pcall(CheckInbox) end
                return
            end
            self.loadUntil, self.loadAsked = nil, nil
            return self:Stop(L["Post lädt nicht – Briefkasten neu öffnen."])
        end
        self.loadUntil, self.loadAsked = nil, nil
        return self:Stop()
    end
    self.loadUntil, self.loadAsked = nil, nil
    pcall(self.NoteMail, self, i)                                                -- Post-Scan: Zeile vor dem Leeren
    if money > 0 then
        if pcall(TakeInboxMoney, i) then self.money = (self.money or 0) + money end
    else
        if FreeSlots() == 0 then return self:Stop(L["|cffff5544Taschen voll|r"]) end
        local a = FirstAttachment(i)
        if not a then
            -- Anzahl gemeldet, aber kein Anhang lesbar: Post überspringen
            self.skip = (self.skip or 0) + 1
            if self.skip > 5 then return self:Stop() end
            return
        end
        -- abgelaufene / abgebrochene Auktion? -> zum Neu-Einstellen merken
        if A.Extras and self:IsReturnMail(i) then
            local okI, _, itemID, _, count = pcall(GetInboxItem, i, a)
            if not (okI and itemID) and GetInboxItemLink then
                local link = GetInboxItemLink(i, a)
                itemID = link and tonumber(link:match("item:(%d+)"))
            end
            if itemID then A.Extras:NoteReturned(itemID, okI and count or 1) end
            -- BH-ANZ-1: Ablauf-Post -> Anzahlung verfallen (Abbruch bucht schon AUCTION_CANCELLED)
            if itemID and A.Books then pcall(A.Books.NoteInboxMail, A.Books, i) end     -- BR1: einmal je Post (Schlüssel)
        end
        pcall(TakeInboxItem, i, a)
        self.items = self.items + 1
    end
    self.waiting = true
    self.lastAction = now
end

local evt = CreateFrame("Frame")
M.evt = evt            -- für die Testroutine (Ereignisse mit Testargumenten nachspielen)
for _, e in ipairs({ "MAIL_SHOW", "MAIL_CLOSED", "MAIL_INBOX_UPDATE", "UI_ERROR_MESSAGE" }) do pcall(evt.RegisterEvent, evt, e) end
evt:SetScript("OnEvent", function(_, event, a1, a2)
    -- Punkt 0 (Befund 10.11.): geschützte Werte (WoW Forever "secret string") nie indizieren
    do local G = _G.GoldSentinelGame; if G and G.AnySecret and G.AnySecret(a1, a2) then return end end
    if event == "MAIL_SHOW" then
        M:EnsureButtons()
        M.autoPending = true
        if C_Timer and C_Timer.After then C_Timer.After(1.5, function() M:TryAuto() end) end
    elseif event == "MAIL_CLOSED" then
        if M.running then M:Stop(L["Briefkasten geschlossen"]) end
    elseif event == "MAIL_INBOX_UPDATE" then
        M.waiting = nil      -- Server hat geantwortet
        if M.autoPending then M:TryAuto() end
    elseif event == "UI_ERROR_MESSAGE" and M.running then
        local G = _G.GoldSentinelGame
        if G and G.AnySecret and G.AnySecret(a1, a2) then return end     -- geschützter Wert (WoW Forever)
        local msg = tostring(a2 or a1 or "")
        if ERR_INV_FULL and msg == ERR_INV_FULL or msg:lower():find("voll") or msg:lower():find("full") then
            M:Stop(L["|cffff5544Taschen voll|r"])
        end
    end
end)
local acc = 0
evt:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    if acc < 0.1 then return end
    acc = 0
    if M.running then M:Step() end
end)

-- Knöpfe am Briefkasten
function M:EnsureButtons()
    if self.buttons or not (A.db and A.db.settings.mailButtons ~= false) then
        if self.buttons then self.buttons:Show() end
        return
    end
    local parent = (type(InboxFrame) == "table" and InboxFrame) or (type(MailFrame) == "table" and MailFrame)
    if not parent then return end
    local frame = (type(MailFrame) == "table" and MailFrame) or parent
    local UI = A.UI
    local C = UI.C
    -- Eigene Leiste RECHTS NEBEN dem Briefkasten (nicht darüber): nichts überlappt den Rahmen,
    -- das Porträt oder Blizzards eigene Knöpfe. Untereinander, gleich breit.
    local W, BH, GAP = 150, 24, 6
    local f = CreateFrame("Frame", "AHAnalyzerProMailButtons", parent)
    f:SetPoint("TOPLEFT", frame, "TOPRIGHT", 4, -24)
    f:SetFrameLevel((parent.GetFrameLevel and parent:GetFrameLevel() or 1) + 10)
    if f.EnableMouse then f:EnableMouse(true) end
    UI:Box(f, C.bg, C.frameEdge, UI:IsClassic() and 2 or 1)
    f.title = UI:Label(f, "AHSentinel", "GameFontNormal", C.accent)
    f.title:SetPoint("TOP", 0, -8)
    local function place() end   -- Anordnung macht f:UpdateState()
    -- Auftrag 21.11. 14:58: EIN Knopf "Post abholen" für alle Post mit Gold und Gegenständen
    f.ah = UI:Button(f, L["Post abholen"], W, BH, function()
        local ok, msg = M:Start(false)
        if msg then A:Print(msg) end
    end, "primary")
    place(f.ah)
    f.ah.tooltip = L["Holt alle Post mit Gold und Gegenständen. Nachnahme wird nie bezahlt."]
    -- "Alles abholen" nur, wenn WoW keinen eigenen Knopf dafür hat ("Alle öffnen" unten im Briefkasten)
    f.all = UI:Button(f, L["Alles abholen"], W, BH, function()
        local ok, msg = M:Start(false)
        if msg then A:Print(msg) end
    end)
    f.all.tooltip = L["Holt jede Post ab (Nachnahme wird nie bezahlt)"]
    place(f.all)
    f.alts = UI:Button(f, L["An Twinks"], W, BH, function(btn, button)
        if button == "RightButton" or not next(A.Extras.RulesDB()) then
            if button ~= "RightButton" then
                A:Print(L["Post an Twinks: noch keine Regel - nichts verschickt. Hier die Regeln festlegen."])
            end
            UI:ShowMailRules()
            return
        end
        local ok, msg = A.Extras:MailStep()
        if msg then A:Print(msg) end
    end)
    if f.alts.RegisterForClicks then f.alts:RegisterForClicks("LeftButtonUp", "RightButtonUp") end
    place(f.alts)
    f.alts:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(L["Post an Twinks"], 1, 1, 1)
        local plan, order = A.Extras:MailPlan()
        if #order == 0 then
            GameTooltip:AddLine(L["Nichts zu verschicken. Rechtsklick: Regeln festlegen."], 0.9, 0.9, 0.9, true)
        else
            for _, to in ipairs(order) do
                GameTooltip:AddDoubleLine(to, string.format(L["%d Stapel"], #plan[to]), 1, 0.82, 0, 1, 1, 1)
            end
            GameTooltip:AddLine(L["Klick: eine Post verschicken. Rechtsklick: Regeln."], 0.6, 0.6, 0.6, true)
        end
        GameTooltip:Show()
    end)
    f.alts:SetScript("OnLeave", function() GameTooltip:Hide() end)
    -- Anhalten: nur sichtbar, solange abgeholt wird (statt eines dauerhaften roten "X")
    f.stop = UI:Button(f, L["Anhalten"], W, BH, function() M:Stop(L["angehalten"]) end, "danger")
    place(f.stop)
    f.stop.tooltip = L["Abholen anhalten"]
    -- zurückgekommene Ware (abgelaufen / abgebrochen): Hinweis mit Anzahl, Einstellen geht am Auktionshaus
    f.repost = UI:Button(f, "", W, BH, function()
        if A:IsAHOpen() and A.Extras then
            local ok, msg = A.Extras:RepostStep()
            if msg then A:Print(msg) end
        else
            A:Print(L["Neu einstellen geht am Auktionshaus: Verkaufen -> Meine Auktionen."])
        end
    end)
    place(f.repost)
    f.repost.tooltip = L["Zurückgekommene Auktionen (abgelaufen oder abgebrochen), die noch in den Taschen liegen.\nEinstellen am Auktionshaus: Verkaufen -> Meine Auktionen."]
    -- untereinander anordnen, nur was gerade Sinn ergibt:
    --  "Alles abholen" nur ohne WoW-eigenes "Alle öffnen" (oder im Testmodus für die Test-Post),
    --  "Anhalten" nur, solange abgeholt wird
    function f:UpdateState()
        local hasOpenAll = type(OpenAllMail) == "table"
        local test = A.TestMode and A.TestMode.active
        local list = { self.ah }
        self.all:Hide()                                                   -- Auftrag 21.11. 14:58: nur noch EIN Knopf
        table.insert(list, self.alts)
        if M.running then table.insert(list, self.stop); self.stop:Show() else self.stop:Hide() end
        local rc = A.Extras and A.Extras.RepostCount and A.Extras:RepostCount() or 0
        if rc > 0 then
            self.repost:SetText(string.format(L["Neu einstellen (%d)"], rc))
            table.insert(list, self.repost); self.repost:Show()
        else
            self.repost:Hide()
        end
        local y = -30
        for _, b in ipairs(list) do
            b:ClearAllPoints()
            b:SetPoint("TOP", self, "TOP", 0, y)
            y = y - BH - GAP
        end
        self:SetSize(W + 16, -y + 6)
    end
    f:UpdateState()
    self.buttons = f
    if not M.stateHooked then
        M.stateHooked = true
        local function upd() if M.buttons and M.buttons.UpdateState then M.buttons:UpdateState() end end
        A:On("MAILER_CHANGED", upd)
        A:On("TESTMODE_CHANGED", upd)
        A:On("SELLER_CHANGED", upd)      -- zurückgekommene Ware gezählt
    end
end

A:On("THEME_CHANGED", function()
    if M.buttons then M.buttons:Hide(); M.buttons = nil end
    -- Briefkasten offen (z. B. Sprachwechsel dort): Leiste gleich neu in der neuen Sprache
    if type(MailFrame) == "table" and MailFrame.IsShown and MailFrame:IsShown() then M:EnsureButtons() end
end)

-- ------------------------------------------------------------
-- G17 Teil 1 (Auftrag 21.11. 16:35): Rechnungen aller Gildenmitglieder (verdichtet, ohne Namen, ohne Item) zum exakten Beleg der
-- Gebührenregel (wirtschaft-forever §0/§1: "5 % vom Verkaufspreis, abgerundet" - belegt mit 4 Rechnungen).
-- Je Verkaufs-Rechnung ein Fall "Ankunft;Gesamt;Gebühr;Einzahlung;Menge" (Ankunft aus der Restzeit des Briefs, 30 Tage Post).
-- Derselbe Brief in einer späteren Sitzung (Gold nicht abgeholt) zählt nur einmal: gleiche Zahlen und Ankunft ±15 Min.
-- Geteilt: "I:<Zeit>:<Markt-Tag>:@konto;Ankunft,Gesamt,Gebühr,Einzahlung,Menge;…"; Empfänger sammelt je Konto (Menge, kein Addieren
-- doppelter). Bericht: /ahs gebuehren. Nur Information - keine Rechnung in AHSentinel ändert sich dadurch.
-- ------------------------------------------------------------
M.INV_KEEP, M.INV_DAYS, M.INV_GAP = 500, 60, 600
function M:InvoiceStore()
    if self.invTest then return self.invTest end
    if A:InTestRoutine() then return nil end
    local db = A.db
    if not db then return nil end
    db.invoices = db.invoices or {}
    return db.invoices
end
function M:NoteInvoice(arrival, gross, cut, dep, n)
    local L2 = self:InvoiceStore()
    if not (L2 and arrival and gross and gross > 0) then return false end
    cut, dep, n = math.floor(cut or 0), math.floor(dep or 0), math.floor(n or 0)
    for i = #L2, 1, -1 do
        local t, g, c, d, q = L2[i]:match("^(%d+);(%d+);(%d+);(%d+);(%d+)$")
        if tonumber(g) == gross and tonumber(c) == cut and tonumber(d) == dep and tonumber(q) == n and math.abs((tonumber(t) or 0) - arrival) <= 900 then return false end
    end
    L2[#L2 + 1] = string.format("%d;%d;%d;%d;%d", math.floor(arrival), gross, cut, dep, n)
    local limit = time() - self.INV_DAYS * 86400
    while #L2 > 0 and (#L2 > self.INV_KEEP or (tonumber(L2[1]:match("^(%d+)")) or 0) < limit) do table.remove(L2, 1) end
    self.invDirty = true
    return true
end
-- aus dem Brief i (nur Verkaufs-Rechnungen)
function M:NoteInvoiceMail(i)
    local ok, _, _, _, _, _, _, daysLeft = pcall(GetInboxHeaderInfo, i)
    local okI, itype, itemName, _, bid, buyout, deposit, consignment, _, _, _, f11 = pcall(GetInboxInvoiceInfo, i)
    if not (ok and okI and itype == "seller" and daysLeft) then return false end
    -- PM1: Menge über Le:InvoiceQty (Feld 11, sonst Feld 5 in Forever) - nie Feld 10 (etaMin)
    local n = 1
    local Le = A.Ledger
    local okN, iid = pcall(function() return Le and Le.ResolveName and Le.ResolveName(itemName) end)      -- PM1-d
    if Le and Le.InvoiceQty then local okQ, q = pcall(Le.InvoiceQty, Le, okN and iid or nil, buyout, bid, f11); if okQ and q then n = q end end
    local arrival = time() - (30 - daysLeft) * 86400
    return self:NoteInvoice(arrival, bid or 0, consignment or 0, deposit or 0, n)
end
function M:BroadcastInvoices(force)
    local S = A.Sync
    if not (S and S.IsEnabled and S:IsEnabled() and S:IsConnected() and S.SendNow and S.Enc and A.MarketTag) then return false end
    if A:InTestRoutine() or (A.Simulated and A:Simulated()) then return false end
    local now = time()
    if not force and (not self.invDirty or (self.invSent and now - self.invSent < self.INV_GAP)) then return false end
    local L2 = self:InvoiceStore()
    if not L2 or #L2 == 0 then return false end
    self.invSent, self.invDirty = now, nil
    local D = A.Disenchant
    local head = "I:" .. S.Enc(now) .. ":" .. A:MarketTag() .. ":@" .. (D and D.AccountId and D:AccountId() or "0") .. ";" .. A.SaleOutcome.FMT .. ";"   -- PM1-c
    local chunk, size, sent = {}, #head, 0
    for _, str in ipairs(L2) do
        local t, g, c, d, q = str:match("^(%d+);(%d+);(%d+);(%d+);(%d+)$")
        if t then
            local p = S.Enc(t) .. "," .. S.Enc(g) .. "," .. S.Enc(c) .. "," .. S.Enc(d) .. "," .. S.Enc(q)
            if size + #p + 1 > S.MAX_MSG and #chunk > 0 then
                S.SendNow(head .. table.concat(chunk, ";")); sent = sent + 1
                chunk, size = {}, #head
            end
            chunk[#chunk + 1] = p
            size = size + #p + 1
        end
    end
    if #chunk > 0 then S.SendNow(head .. table.concat(chunk, ";")); sent = sent + 1 end
    return sent > 0
end
function M:HandleInvoices(t, rest)
    local S = A.Sync
    if not (S and S.Dec and type(rest) == "string") then return -1 end
    local tag, body = rest:match("^(%w+):(.*)$")
    if not tag or tag ~= A:MarketTag() then return -1 end
    local acc, data = (body or ""):match("^@(%w+);(.*)$")
    if not acc then return -1 end
    if not (A.SaleOutcome and A.SaleOutcome.HasFmt(data)) then return -1 end      -- PM1-c: Rechnungen alter Versionen (Menge aus Feld 10)
    local D = A.Disenchant
    if D and D.AccountId and acc == D:AccountId() then return -1 end
    local now = time()
    if not t or t > now + 300 or t < now - self.INV_DAYS * 86400 then return -1 end
    local sh = self.invSharedTest
    if not sh then
        if not A.db then return -1 end
        A.db.invoiceShared = A.db.invoiceShared or {}
        sh = A.db.invoiceShared
    end
    local rec = sh[acc]
    if not (rec and rec.f == A.SaleOutcome.FMT) then rec = { m = {}, n = 0, f = A.SaleOutcome.FMT } end
    sh[acc] = rec
    rec.t = math.max(rec.t or 0, t)
    local taken = 0
    for part in data:gmatch("[^;]+") do
        local a, b, c, d, e = part:match("^(%w+),(%w+),(%w+),(%w+),(%w+)$")
        local tt, g, cu, de, q = S.Dec(a or ""), S.Dec(b or ""), S.Dec(c or ""), S.Dec(d or ""), S.Dec(e or "")
        if tt and g and cu and de and q and g > 0 and cu <= g and tt >= now - self.INV_DAYS * 86400 and tt <= now + 300 and rec.n < self.INV_KEEP then
            local k = string.format("%d;%d;%d;%d;%d", tt, g, cu, de, q)
            if not rec.m[k] then rec.m[k] = true; rec.n = rec.n + 1; taken = taken + 1 end
        end
    end
    for k, r in pairs(sh) do if (r.t or 0) < now - self.INV_DAYS * 86400 then sh[k] = nil end end
    return taken
end
-- Prüfung der Gebührenregel: Gebühr = abgerundet pct × Gesamt (pct 5 %; neutrales AH 15 % vermutet, mitgezählt)
function M:FeeCheck()
    local res = { n = 0, own = 0, guild = 0, p5 = 0, p15 = 0, other = {} }
    local seen = {}
    local function one(s, guild)
        local t, g, c = s:match("^(%d+);(%d+);(%d+);")
        g, c = tonumber(g), tonumber(c)
        if not (g and c) then return end
        -- dieselbe Rechnung von zwei Quellen (z. B. eigenes Konto auf zwei Rechnern) nur einmal: gleiche Zahlen, Ankunft ±15 Min.
        local key = g .. ";" .. c
        local tt = tonumber(t) or 0
        for _, x in ipairs(seen[key] or {}) do if math.abs(x - tt) <= 900 then return end end
        seen[key] = seen[key] or {}
        table.insert(seen[key], tt)
        res.n = res.n + 1
        if guild then res.guild = res.guild + 1 else res.own = res.own + 1 end
        if c == math.floor(g * 5 / 100) then res.p5 = res.p5 + 1
        elseif c == math.floor(g * 15 / 100) then res.p15 = res.p15 + 1
        elseif #res.other < 5 then res.other[#res.other + 1] = string.format("%d -> %d", g, c) end
    end
    for _, s in ipairs(self:InvoiceStore() or {}) do one(s) end
    local sh = self.invSharedTest or (A.db and A.db.invoiceShared) or {}
    for _, rec in pairs(sh) do for s in pairs(rec.m or {}) do one(s, true) end end
    return res
end
function M:FeeText()
    local r = self:FeeCheck()
    if r.n == 0 then return L["Gebührenregel: noch keine Verkaufs-Rechnungen (Post abholen)."] end
    local s = string.format(L["Gebührenregel aus %d Rechnungen (eigene %d, Gilde %d): 5 Prozent abgerundet exakt %d, 15 Prozent abgerundet exakt %d, anders %d"],
        r.n, r.own, r.guild, r.p5, r.p15, r.n - r.p5 - r.p15)
    if #r.other > 0 then s = s .. " (" .. table.concat(r.other, ", ") .. ")" end
    return s
end
