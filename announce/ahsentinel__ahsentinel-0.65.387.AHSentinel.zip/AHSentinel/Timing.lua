if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- AHSentinel - Zeitpunkt: wann kaufen, wann verkaufen (JK1–JK4, Anweisung der Prüf-Sitzung 11.11. 20:07)
--
-- JK2 Rhythmus für ALLE Items aus dem Scan: einmal je Stunde je Item ein Wert (Mindestpreis), Menge -> Absatz je Stunde.
--     Speicher je Item EINE Zeichenkette (db.timing.items[itemID], neue Tabelle, ändert keine anderen Daten):
--       "Basis;erster Tag;letzte Stunde;letzte Menge;H;D;W;S"
--       Basis      erster Preis (Kupfer); alle Preise relativ dazu, logarithmisch in 2 Zeichen (1 %-Schritte)
--       H          24 Gruppen (Stunde 0–23, Ortszeit), je bis 3 Einträge "Tag(1) Preis(2)", neuester zuerst
--       D          bis 10 Tageswerte "Tag(1) Preis(2) Anzahl(1)", neuester zuerst (Tag = Tagesnummer mod 36)
--       W          7 Wochentage (Mo..So) je 2 Zeichen gleitend ("__" = leer) - eigener Wochenrhythmus (Raidtage ab 9.12.)
--       S          24 Zeichen Absatz je Stunde (gleitend, log2-Stufen)
--     Items ohne Angebot seit 14 Tagen fallen raus. Ziel < 2 MB für 5'000 Items (T-JK6).
-- JK3 Signal nur mit frischem Preis (<= 30 Min.), nie bei Aufkauf (D6), nie mit veralteten Materialpreisen (MP2),
--     Abweichung >= 10 % UND > 1,5 × übliche Schwankung (MAD der Tageswerte), >= 7 Tage Daten, je Stunde >= 3 Werte.
-- JK4 Jede gezeigte Zeile ist ein Fall; nach 24 Std. (bzw. zur genannten Zeit) nachgeprüft. Signal-Art mit < 60 %
--     Treffern (ab 20 Fällen, letzte 50) wird ausgeblendet, bis sie wieder darüber liegt (Fälle laufen still weiter).

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local TM = {}
A.Timing = TM

TM.FRESH = 30 * 60
TM.MIN_DAYS = 7
TM.MIN_HOUR_VALUES = 3
TM.KEEP_DAYS = 14
TM.MIN_DEV = 0.10
TM.MAD_FACTOR = 1.5
TM.HOUR_SLOTS = 3
TM.DAY_SLOTS = 10
TM.CHECK_AFTER = 24 * 3600
TM.QUOTE_MIN = 20
TM.QUOTE_PCT = 0.60
TM.QUOTE_LAST = 50
TM.NOTE_GAP = 6 * 3600
TM.MAX_CASES = 400
TM.KINDS = { "buy", "wait", "sell", "notnow" }

-- ------------------------------------------------------------
-- Speicher (testDB in der Testroutine; in der Nachbildung nur mit testDB)
-- ------------------------------------------------------------
local function NewDB() return { v = 1, items = {}, cases = {}, res = {} } end
TM.NewDB = NewDB
function TM:Store()
    if self.testDB then return self.testDB end
    if not A.db or A:Simulated() then return nil end
    if A.TestRoutine and A.TestRoutine.running then return nil end      -- Testroutine: nie echte Daten schreiben
    A.db.timing = A.db.timing or NewDB()
    local db = A.db.timing
    db.items, db.cases, db.res = db.items or {}, db.cases or {}, db.res or {}
    return db
end
function TM:Data()
    if self.testDB then return self.testDB end
    return A.db and A.db.timing
end
local function Now() return TM.now or time() end            -- Naht für Tests (eigene Funktion)
function TM:Now() return Now() end

-- ------------------------------------------------------------
-- Kodierung
-- ------------------------------------------------------------
local B36 = "0123456789abcdefghijklmnopqrstuvwxyz"
local DEC = {}
for i = 1, 36 do DEC[B36:sub(i, i)] = i - 1 end
local LOG101 = math.log(1.01)
local function C1(n) n = math.max(0, math.min(35, math.floor(n + 0.5))); return B36:sub(n + 1, n + 1) end
local function C2(n) n = math.max(0, math.min(1295, math.floor(n + 0.5))); local a = math.floor(n / 36); return B36:sub(a + 1, a + 1) .. B36:sub(n % 36 + 1, n % 36 + 1) end
local function D1(s) return DEC[s] or 0 end
local function D2(s) return (DEC[s:sub(1, 1)] or 0) * 36 + (DEC[s:sub(2, 2)] or 0) end
local function PCode(p, base) return C2(math.log(p / base) / LOG101 + 648) end
local function PVal(code, base) return base * (1.01 ^ (code - 648)) end
local function Day(t)                                   -- Tag nach Ortszeit (Stunde und Tag passen zusammen)
    local d = date("*t", t)
    return math.floor(time({ year = d.year, month = d.month, day = d.day, hour = 12 }) / 86400)
end
local function HourOf(t) return tonumber(date("%H", t)) or 0 end
local function WeekdayOf(t) local w = tonumber(date("%w", t)) or 0; return w == 0 and 7 or w end   -- 1 = Montag
local function Age(today, dc) return (today - dc) % 36 end
local function SalesCode(x) return math.min(35, math.floor(math.log(1 + math.max(0, x)) / math.log(2) * 3 + 0.5)) end
TM.SalesCode = SalesCode

-- Zerlegen / Zusammensetzen
function TM:Decode(str)
    if type(str) ~= "string" then return nil end
    local base, first, lastH, lastQ, H, D, W, S = str:match("^(%d+);(%d+);(%d+);(%d+);([^;]*);([^;]*);([^;]*);([^;]*)$")
    if not base then return nil end
    local r = { base = tonumber(base), first = tonumber(first), lastH = tonumber(lastH), lastQ = tonumber(lastQ), H = {}, D = {}, W = {}, S = {} }
    local h = 0
    for grp in (H .. ","):gmatch("([^,]*),") do
        h = h + 1
        if h > 24 then break end
        local list = {}
        for i = 1, #grp - 2, 3 do list[#list + 1] = { d = D1(grp:sub(i, i)), c = D2(grp:sub(i + 1, i + 2)) } end
        r.H[h] = list
    end
    for i = h + 1, 24 do r.H[i] = {} end
    for i = 1, #D - 3, 4 do r.D[#r.D + 1] = { d = D1(D:sub(i, i)), c = D2(D:sub(i + 1, i + 2)), n = D1(D:sub(i + 3, i + 3)) } end
    for i = 1, 7 do local s = W:sub(i * 2 - 1, i * 2); r.W[i] = (s ~= "" and s ~= "__") and D2(s) or nil end
    for i = 1, 24 do local s = S:sub(i, i); r.S[i] = s ~= "" and D1(s) or 0 end
    return r
end
function TM:Encode(r)
    local hs = {}
    for h = 1, 24 do
        local g = {}
        for _, e in ipairs(r.H[h] or {}) do g[#g + 1] = C1(e.d) .. C2(e.c) end
        hs[h] = table.concat(g)
    end
    local ds = {}
    for _, e in ipairs(r.D) do ds[#ds + 1] = C1(e.d) .. C2(e.c) .. C1(e.n) end
    local ws = {}
    for i = 1, 7 do ws[i] = r.W[i] and C2(r.W[i]) or "__" end
    local ss = {}
    for i = 1, 24 do ss[i] = C1(r.S[i] or 0) end
    return table.concat({ math.floor(r.base), r.first, r.lastH, math.floor(r.lastQ or 0), table.concat(hs, ","), table.concat(ds), table.concat(ws), table.concat(ss) }, ";")
end

-- Zeit-Kontext einer Stunde (einmal je Stunde gerechnet, nicht je Item)
TM.ctxCache = nil
function TM:Ctx(t)
    local hk = math.floor(t / 3600)
    local c = self.ctxCache
    if c and c.hk == hk then return c end
    local day = Day(t)
    c = { hk = hk, day = day, dc = day % 36, h = HourOf(t) + 1, wd = WeekdayOf(t) }
    self.ctxCache = c
    return c
end

-- Einen Wert aufnehmen (höchstens einmal je Stunde je Item). Schnell: nur die betroffenen Teile der Zeichenkette ändern.
local EMPTY_H = string.rep(",", 23)
local EMPTY_W = string.rep("__", 7)
local EMPTY_S = string.rep("0", 24)
local scratchGroups, scratchG, scratchOut = {}, {}, {}
function TM:Record(itemID, price, qty, t)
    local db = self:Store()
    if not (db and itemID and price and price > 0) then return false end
    t = t or Now()
    local c = self:Ctx(t)
    local str = db.items[itemID]
    local base, first, lastH, lastQ, H, D, W, S
    if str then base, first, lastH, lastQ, H, D, W, S = str:match("^(%d+);(%d+);(%d+);(%d+);([^;]*);([^;]*);([^;]*);([^;]*)$") end
    if base then
        base, lastH, lastQ = tonumber(base), tonumber(lastH), tonumber(lastQ)
        if lastH == c.hk then return false end
    else
        base, first, lastH, lastQ, H, D, W, S = price, tostring(c.day), 0, 0, EMPTY_H, "", EMPTY_W, EMPTY_S
    end
    local code = math.max(0, math.min(1295, math.floor(math.log(price / base) / LOG101 + 648 + 0.5)))
    local cc, dch = C2(code), C1(c.dc)
    -- Stunde: neuester Eintrag zuerst, gleicher Tag und alte (> 14 Tage) raus, höchstens 3
    -- Punkt 5 (Vollscan-Speicher, Nachbau echte Daten: 8,1 MB in 3949 Aufrufen): Hilfstabellen wiederverwenden statt je Aufruf neu
    local groups, gi = scratchGroups, 0
    for grp in (H .. ","):gmatch("([^,]*),") do gi = gi + 1; groups[gi] = grp end
    for i = gi + 1, 24 do groups[i] = "" end
    for i = #groups, 25, -1 do groups[i] = nil end
    local old = groups[c.h]
    local g, ng = scratchG, 1
    g[1] = dch .. cc
    for i = 1, #old - 2, 3 do
        if ng >= self.HOUR_SLOTS then break end
        local d = D1(old:sub(i, i))
        if d ~= c.dc and Age(c.day, d) < self.KEEP_DAYS then ng = ng + 1; g[ng] = old:sub(i, i + 2) end
    end
    groups[c.h] = table.concat(g, "", 1, ng)
    H = table.concat(groups, ",", 1, 24)
    -- Tag: laufender Mittelwert
    if D:sub(1, 1) == dch and #D >= 4 then
        local oc, on = D2(D:sub(2, 3)), D1(D:sub(4, 4))
        D = dch .. C2((oc * on + code) / (on + 1)) .. C1(math.min(35, on + 1)) .. D:sub(5)
    else
        D = (dch .. cc .. "1" .. D):sub(1, 4 * self.DAY_SLOTS)
    end
    -- Wochentag gleitend
    local ws = W:sub(c.wd * 2 - 1, c.wd * 2)
    local wv = (ws ~= "__" and ws ~= "") and math.floor(D2(ws) * 0.9 + code * 0.1 + 0.5) or code
    W = W:sub(1, c.wd * 2 - 2) .. C2(wv) .. W:sub(c.wd * 2 + 1)
    -- Absatz: Menge gesunken seit der Vorstunde (Nachschub verdeckt Verkäufe -> eher zu wenig)
    if lastH == c.hk - 1 and qty then
        local drop = math.max(0, (lastQ or 0) - qty)
        local sv = math.floor(D1(S:sub(c.h, c.h)) * 0.7 + SalesCode(drop) * 0.3 + 0.5)
        S = S:sub(1, c.h - 1) .. C1(sv) .. S:sub(c.h + 1)
    end
    local o = scratchOut
    o[1], o[2], o[3], o[4], o[5], o[6], o[7], o[8] = math.floor(base), first, c.hk, math.floor(qty or 0), H, D, W, S
    db.items[itemID] = table.concat(o, ";", 1, 8)
    return true
end

-- Items ohne Angebot seit 14 Tagen entfernen
function TM:Prune(now)
    local db = self:Store()
    if not db then return 0 end
    local limit = math.floor((now or Now()) / 3600) - self.KEEP_DAYS * 24
    local n = 0
    -- RUCKEL-3 (0.65.320, Nachbau echte Daten: Aufgabe timing 12,5 ms am Stück): erst die Schlüssel holen, dann je 200 Items eine Pause
    -- (in der Aufgabe; ausserhalb ohne Wirkung). Kein pairs über eine Tabelle, die sich in der Pause ändern könnte.
    local ids = {}
    for id in pairs(db.items) do ids[#ids + 1] = id end
    for i, id in ipairs(ids) do
        local s = db.items[id]
        local lh = tonumber(type(s) == "string" and s:match("^%d+;%d+;(%d+);") or nil)
        if s ~= nil and (not lh or lh < limit) then db.items[id] = nil; n = n + 1 end
        if i % 200 == 0 then A:Pause() end
    end
    return n
end

-- ------------------------------------------------------------
-- Auswertung
-- ------------------------------------------------------------
local function Median(t)
    if #t == 0 then return nil end
    local s = {}
    for i, v in ipairs(t) do s[i] = v end
    table.sort(s)
    local m = math.floor((#s + 1) / 2)
    if #s % 2 == 1 then return s[m] end
    return (s[m] + s[m + 1]) / 2
end
TM.Median = Median

-- Werte der Stunde h (1..24) aus den letzten 14 Tagen (Preise in Kupfer)
-- G11 (Auftrag 21.11. 16:35, junger Server – Preise fallen): zuerst den Trend über die Tage herausrechnen. Jeder Stundenwert wird
-- durch den Tageswert SEINES Tages geteilt und mit dem neuesten Tageswert multipliziert -> Stunden werden auf dem heutigen
-- Preisniveau verglichen. Ohne Tageswert für diesen Tag bleibt der Wert unverändert. TM.TREND = false schaltet es ab.
TM.TREND = true
function TM:HourValues(r, h, today)
    local out = {}
    local dm, ref
    if self.TREND then
        dm = r.__dm
        if not dm then
            dm = {}
            local newestAge
            for _, e in ipairs(r.D or {}) do
                local v = PVal(e.c, r.base)
                if v and v > 0 then
                    dm[e.d] = v
                    local a = Age(today, e.d)
                    if not newestAge or a < newestAge then newestAge, ref = a, v end
                end
            end
            r.__dm, r.__ref = dm, ref
        end
        ref = r.__ref
    end
    for _, e in ipairs(r.H[h] or {}) do
        if Age(today, e.d) < self.KEEP_DAYS then
            local v = PVal(e.c, r.base)
            local dv = dm and dm[e.d]
            if ref and dv and dv > 0 then v = v / dv * ref end
            out[#out + 1] = v
        end
    end
    return out
end
-- G6/G11 (Auftrag 21.11. 16:35): Preis je Tageszeit - nur Stunden mit mindestens MIN_HOUR_VALUES Werten (14 Tage, trendbereinigt),
-- erst ab MIN_DAYS Tagen Daten und mindestens 2 solchen Stunden; sonst "zu wenig Daten" (nichts schätzen). Nur Anzeige.
function TM:HourProfile(itemID, now)
    now = now or Now()
    local db = self:Data()
    local r = db and itemID and self:Decode(db.items and db.items[itemID])
    if not r then return nil, 0 end
    local today = Day(now)
    if today - r.first < self.MIN_DAYS then return nil, 0 end
    local lo, hi, k = nil, nil, 0
    for h = 1, 24 do
        local hv = self:HourValues(r, h, today)
        if #hv >= self.MIN_HOUR_VALUES then
            k = k + 1
            local m = Median(hv)
            if not lo or m < lo.v then lo = { h = h - 1, v = m, n = #hv } end
            if not hi or m > hi.v then hi = { h = h - 1, v = m, n = #hv } end
        end
    end
    if k < 2 then return nil, k end
    return { lo = lo, hi = hi, hours = k }, k
end
function TM:HourProfileText(itemID, now)
    local p, k = self:HourProfile(itemID, now)
    if not p then return string.format(L["Tageszeit: zu wenig Daten (%d von 24 Std. mit mind. %d Werten)"], k or 0, self.MIN_HOUR_VALUES) end
    return string.format(L["Tageszeit (14 Tage, trendbereinigt): günstig um %d Uhr %s (%d Werte), teuer um %d Uhr %s (%d Werte)"],
        p.lo.h, A:FormatMoney(math.floor(p.lo.v + 0.5)), p.lo.n, p.hi.h, A:FormatMoney(math.floor(p.hi.v + 0.5)), p.hi.n)
end
function TM:DayValues(r, today)
    local out = {}
    for _, e in ipairs(r.D) do if Age(today, e.d) < self.KEEP_DAYS then out[#out + 1] = { d = Age(today, e.d), v = PVal(e.c, r.base) } end end
    return out
end

-- übliche Schwankung: MAD der Tageswerte relativ zum Median
function TM:Spread(days)
    local v = {}
    for i, e in ipairs(days) do v[i] = e.v end
    local med = Median(v)
    if not med or med <= 0 or #v < 3 then return nil end
    local dev = {}
    for i, x in ipairs(v) do dev[i] = math.abs(x - med) end
    return Median(dev) / med
end

-- fällt seit >= 2 Tagen: heute < gestern < vorgestern (Tageswerte)
function TM:Falling(days)
    local by = {}
    for _, e in ipairs(days) do by[e.d] = e.v end
    return by[0] and by[1] and by[2] and by[0] < by[1] * 0.99 and by[1] < by[2] * 0.99 or false
end

-- Trefferquote einer Signal-Art: n, Quote (letzte 50)
function TM:Quote(kind)
    local db = self:Data()
    local s = db and db.res and db.res[kind] or ""
    local n, hit = #s, 0
    for i = 1, n do if s:sub(i, i) == "1" then hit = hit + 1 end end
    return n, n > 0 and hit / n or nil, hit
end
function TM:Hidden(kind)
    local n, q = self:Quote(kind)
    return n >= self.QUOTE_MIN and q < self.QUOTE_PCT
end

-- Kern: Signal für ein Item. mode: "any" (Tooltip/Einkauf: kaufen/abwarten/verkaufen), "sell" (Einstellen:
-- verkaufen / nicht jetzt), "own" (eigene Ware im Tooltip: zuerst Verkaufs-Varianten)
-- zurück: { kind, pct, text, usual, cur, at } oder nil, Grund
function TM:Evaluate(itemID, mode, now)
    now = now or Now()
    if not itemID then return nil, "kein Item" end
    local db = self:Data()
    local r = db and self:Decode(db.items and db.items[itemID])
    local cur, _, t = A:GetCurrent(itemID)
    local fresh = cur and t and now - t <= self.FRESH
    local okB, bo = pcall(A.BuyoutInfo, A, itemID)
    if okB and bo then
        -- AB4: Aufkauf = Chance zum Verkaufen (eigene Ware / Verkaufen-Reiter), nie ein Kauf-Signal
        if fresh and (mode == "sell" or mode == "own") and bo.p0 and bo.p0 > 0 and cur >= bo.p0 * 1.2 then
            return { kind = "sell", pct = math.floor((cur / bo.p0 - 1) * 100 + 0.5), cur = cur, usual = bo.p0, buyout = true }
        end
        return nil, "aufkauf"
    end
    if not r then return nil, "keine Daten" end
    local today = Day(now)
    local days = today - r.first
    if days < self.MIN_DAYS then return nil, "tage", self.MIN_DAYS - days end
    if not fresh then return nil, "alt" end
    local D = A.Disenchant
    if D and D.StaleMain and D.Prior then
        local okP, prior = pcall(D.Prior, D, itemID)
        if okP and prior then
            local okS, stale = pcall(D.StaleMain, D, itemID)
            if okS and stale then return nil, "material" end
        end
    end
    local h = HourOf(now) + 1
    local hv = self:HourValues(r, h, today)
    if #hv < self.MIN_HOUR_VALUES then return nil, "stunde" end
    local usual = Median(hv)
    local dv = self:DayValues(r, today)
    local spread = self:Spread(dv) or 0
    local thr = math.max(self.MIN_DEV, self.MAD_FACTOR * spread)
    local dev = cur / usual - 1
    local res = { cur = cur, usual = usual, thr = thr, dev = dev, spread = spread }
    local function sellSide()
        if dev >= thr then
            local active = (r.S[h] or 0) >= 2                        -- Käufer aktiv: Absatz in dieser Stunde (gemessen)
            if active then
                res.kind, res.pct = "sell", math.floor(dev * 100 + 0.5)
                return res
            end
            return nil
        end
        if dev < 0 then
            -- besseres Fenster in den nächsten 24 Std.?
            local bestH, bestV
            for k = 1, 23 do
                local hh = (h - 1 + k) % 24 + 1
                local vals = self:HourValues(r, hh, today)
                if #vals >= self.MIN_HOUR_VALUES then
                    local m = Median(vals)
                    if not bestV or m > bestV then bestH, bestV = hh, m end
                end
            end
            if bestV and bestV / cur - 1 >= thr then
                res.kind, res.pct, res.at = "notnow", math.floor((bestV / cur - 1) * 100 + 0.5), bestH - 1
                local k = (bestH - h) % 24
                res.atTime = now - (now % 3600) + k * 3600
                return res
            end
        end
        return nil
    end
    if mode == "sell" or mode == "own" then
        local s = sellSide()
        if s or mode == "sell" then return s, s and nil or "normal" end
    end
    if dev <= -thr then
        if self:Falling(dv) then res.kind = "wait" else res.kind = "buy" end
        res.pct = math.floor(-dev * 100 + 0.5)
        return res
    end
    if dev >= thr then
        local s = sellSide()
        if s then return s end
    end
    return nil, "normal"
end

-- V1d (Befund 21.11. 08:45: Essenz "+66 % über üblich" bei Preis 39s74 unter dem Marktwert 39s85; Silberrute "+5614 %", Tooltip
-- "−98 %" bei 7c über dem Marktwert 6c): die Prozente rechnen gegen "üblich" = Median der gespeicherten Stundenwerte (Essenz 8 Uhr:
-- 23s96/24s69/19s06 -> 23s96, 39s74/23s96 = +66 %; Silberrute 22 Uhr: 3s96/4s00), der Marktwert aus einer anderen Quelle zeigt das
-- Gegenteil. Widersprechen sich die beiden Richtungen, gibt es kein Signal (eine Aussage je Zustand).
function TM:Consistent(itemID, sig)
    if not (sig and sig.kind and sig.cur and not sig.buyout) then return true end
    local mv = A:GetMarketValue(itemID)
    if not (mv and mv > 0) then return true end
    if sig.kind == "sell" then return sig.cur > mv end
    if sig.kind == "notnow" or sig.kind == "buy" or sig.kind == "wait" then return sig.cur < mv end
    return true
end
function TM:Text(sig)
    if not sig then return nil end
    if sig.kind == "buy" then return string.format(L["Jetzt günstig – kaufen (−%d %% unter üblich)"], sig.pct), 0.2, 0.87, 0.33
    elseif sig.kind == "wait" then return L["Fällt – abwarten"], 1, 0.6, 0.2
    elseif sig.kind == "sell" then
        local txt = string.format(L["Jetzt teuer – verkaufen (+%d %% über üblich)"], sig.pct)
        if sig.buyout then txt = txt .. " · " .. L["Aufkauf – Preis kann schnell fallen"] end
        return txt, 1, 0.82, 0
    elseif sig.kind == "notnow" then return string.format(L["Jetzt nicht verkaufen – besser um %d Uhr (+%d %%)"], sig.at, sig.pct), 1, 0.6, 0.2 end
    return nil
end

-- Signal, das gezeigt werden darf (nachgeprüft, Art nicht ausgeblendet); jede Berechnung mit Signal ist ein Fall
function TM:Signal(itemID, mode, now)
    if A.db and A.db.settings and A.db.settings.timingSignal == false then return nil, "aus" end
    local ok, sig, why, extra = pcall(self.Evaluate, self, itemID, mode, now)
    if not ok then return nil, "fehler" end
    if not sig then return nil, why, extra end
    local okC, cons = pcall(self.Consistent, self, itemID, sig)                 -- V1d
    if okC and not cons then return nil, "widerspruch" end
    pcall(self.Note, self, itemID, sig, now)
    if self:Hidden(sig.kind) then return nil, "ausgeblendet" end
    return sig
end

-- Eine Zeile für Fenster (Einkauf, Sniper, Verkaufen): farbiger Text oder nil
function TM:InlineText(itemID, mode)
    local sig = self:Signal(itemID, mode)
    local txt, r, g, b = self:Text(sig)
    if not txt then return nil end
    return string.format("|cff%02x%02x%02x%s|r", math.floor(r * 255), math.floor(g * 255), math.floor(b * 255), txt)
end

-- ------------------------------------------------------------
-- JK4 Nachprüfen
-- ------------------------------------------------------------
TM.notedAt = TM.notedAt or {}
function TM:Note(itemID, sig, now)
    local db = self:Store()
    if not (db and sig and sig.kind) then return false end
    now = now or Now()
    local key = sig.kind .. ":" .. itemID
    if self.notedAt[key] and now - self.notedAt[key] < self.NOTE_GAP then return false end
    for i = #db.cases, 1, -1 do
        local k, id, t = db.cases[i]:match("^(%a+);(%d+);(%d+)")
        if k == sig.kind and tonumber(id) == itemID and now - tonumber(t) < self.NOTE_GAP then self.notedAt[key] = tonumber(t); return false end
        if tonumber(t) < now - self.NOTE_GAP then break end
    end
    self.notedAt[key] = now
    db.cases[#db.cases + 1] = string.format("%s;%d;%d;%d;%d", sig.kind, itemID, now, math.floor(sig.cur), sig.atTime or 0)
    while #db.cases > self.MAX_CASES do table.remove(db.cases, 1) end
    return true
end

-- Preis nahe einer Zeit aus dem Verlauf (erster bestätigter Eintrag in [from, to])
function TM:PriceBetween(itemID, from, to)
    local F, n = A:HF(itemID)
    for i = 1, n do
        local b = (i - 1) * 5
        local t = F[b + 1]
        if t >= from and t <= to and F[b + 5] % 2 == 0 then return F[b + 2] end
        if t > to then break end
    end
    return nil
end

function TM:Resolve(now)
    local db = self:Store()
    if not db then return 0 end
    now = now or Now()
    local keep, n = {}, 0
    -- RUCKEL-3: je Fall eine mögliche Pause; in der Pause neu gemerkte Fälle landen in der neuen Liste und bleiben erhalten
    local cases = db.cases
    db.cases = {}
    for _, c in ipairs(cases) do
        A:Pause()
        local kind, id, t, p, at = c:match("^(%a+);(%d+);(%d+);(%d+);(%d+)$")
        id, t, p, at = tonumber(id), tonumber(t), tonumber(p), tonumber(at)
        local result
        if kind == "notnow" and at and at > 0 then
            if now >= at + 5400 then
                local q = self:PriceBetween(id, at - 1800, at + 5400)
                if q then result = q > p else result = "drop" end
            end
        elseif t and now >= t + self.CHECK_AFTER then
            local q = self:PriceBetween(id, t + self.CHECK_AFTER - 3600, t + self.CHECK_AFTER + 6 * 3600)
            if q then
                if kind == "buy" then result = q > p
                elseif kind == "wait" then result = q <= p
                elseif kind == "sell" then result = q < p end
            elseif now >= t + 2 * self.CHECK_AFTER then result = "drop" end
        end
        if result == nil then keep[#keep + 1] = c
        elseif result ~= "drop" and kind then
            local s = (db.res[kind] or "") .. (result and "1" or "0")
            if #s > self.QUOTE_LAST then s = s:sub(-self.QUOTE_LAST) end
            db.res[kind] = s
            n = n + 1
        end
    end
    for _, c in ipairs(db.cases) do keep[#keep + 1] = c end
    db.cases = keep
    return n
end

-- ------------------------------------------------------------
-- Aufnahme nach jedem Scan (einmal je Stunde, in Portionen)
-- ------------------------------------------------------------
TM.doneHour = nil
function TM:OnScan(best, now)
    if type(best) ~= "table" then return 0 end
    now = now or Now()
    local hk = math.floor(now / 3600)
    if self.doneHour == hk then return 0 end
    local own = A.db and A.db.lastOwnScan
    if own and own.partial then return 0 end              -- halber Scan: nichts lernen
    self.doneHour = hk
    local n, i = 0, 0
    for id, b in pairs(best) do
        if b and b.price and b.price > 0 and not b.u then
            if self:Record(id, b.price, b.qty, now) then n = n + 1 end
        end
        i = i + 1
        if i % 25 == 0 then A:Pause() end                -- in Portionen (VF1: nicht ruckeln)
    end
    self:Prune(now)
    self:Resolve(now)
    return n
end
A:On("SCAN_FINISHED", function(_, best, now)
    if (A.TestRoutine and A.TestRoutine.running) or not TM:Store() then return end
    if A.Job then A:Job("timing", function() TM:OnScan(best, now) end) else pcall(TM.OnScan, TM, best, now) end
end)

-- ------------------------------------------------------------
-- Bericht (Testroutine, ohne Namen)
-- ------------------------------------------------------------
function TM:Size()
    local db = self:Data()
    local bytes, n = 0, 0
    for id, s in pairs(db and db.items or {}) do bytes = bytes + #s + #tostring(id) + 8; n = n + 1 end
    for _, c in ipairs(db and db.cases or {}) do bytes = bytes + #c + 4 end
    return bytes, n
end
function TM:Report()
    local out, fields = { "Zeitpunkt kaufen/verkaufen (JK1–JK4):" }, {}
    local bytes, n = self:Size()
    local db = self:Data()
    local ready = 0
    local today = Day(Now())
    for _, s in pairs(db and db.items or {}) do
        local f = tonumber(s:match("^%d+;(%d+);"))
        if f and today - f >= self.MIN_DAYS then ready = ready + 1 end
    end
    out[#out + 1] = string.format("  Rhythmus für %d Items (%d mit >= %d Tagen) · Speicher %d KB (Ziel < 2048 KB) · offene Fälle %d",
        n, ready, self.MIN_DAYS, math.ceil(bytes / 1024), db and #(db.cases or {}) or 0)
    local q = {}
    for _, k in ipairs(self.KINDS) do
        local c, rate = self:Quote(k)
        q[#q + 1] = string.format("%s %s (%d)%s", k, rate and string.format("%d %%", math.floor(rate * 100 + 0.5)) or "-", c, self:Hidden(k) and " AUS" or "")
    end
    out[#out + 1] = "  Trefferquote je Signal-Art (letzte 50): " .. table.concat(q, " · ")
    fields.zeitpunkt_items = tostring(n)
    fields.zeitpunkt_quote = table.concat(q, " / ")
    return out, fields
end
