# BuffSentinel – Changelog

## 0.9.44
- **New: Rebirth seeds for druids** (Classic, WoW Forever, TBC, Wrath): in a group, "REAGENT LOW!" when you have no seed for your highest learned rank of Rebirth (e.g. Maple Seed for rank 1, Ironwood Seed for rank 5). IDs from the game data. Only out of combat; can be switched off in the options.
- Test routine (developer only): T243 (seed of the highest learned rank per version).

## 0.9.43
- **New: poison supply for rogues** (Classic, WoW Forever, TBC, Wrath): "POISONS LOW!" with the count when you have fewer than 10 weapon poisons in your bags in total (all types and ranks: instant, deadly, wound, crippling, mind-numbing, anesthetic) – from level 20. Which items count comes from the game data of your game version. Only out of combat; can be switched off in the options.
- New data file BuffSentinelGifte.lua (game data, unchanged from the GoldSentinel test system).
- Test routine (developer only): T242 (all poison types per game version, other items not counted, from level 20).

## 0.9.42
- **New: pet happiness for hunters** (Classic, WoW Forever, TBC, Wrath): "FEED YOUR PET!" out of combat when your pet is only content (100 % damage) or unhappy (75 %) instead of happy (125 %) – with the current damage value. Uses the game's own happiness value; if the game has no such function, nothing is shown. Can be switched off in the options.
- Test routine (developer only): T241 (unhappy, content, happy, no pet, dead, combat, function missing).

## 0.9.41
- **Performance measurement (diagnostics)**: in combat, BuffSentinel now measures how long its own code takes per frame. After each fight the log (`/bsen protokoll`) gets one line "PERFORMANCE Combat: longest frame by BuffSentinel x ms (part), over 16 ms: n of m frames". The log also shows the cost of the supply checks per bag event. Measuring costs two clock reads per part, only in combat. No change to what you see.
- Test routine (developer only): T237 (measurement with three frames 8/18/1 ms), T238 (line of the last real fight; error if a frame was over 16 ms), T239 (all supply checks with full bags under 1 ms per bag event).

## 0.9.40
- **New: totems in your bags (shamans, Classic to Wrath)**: "TOTEM MISSING!" with the element (Earth, Fire, Water, Air) when you know totem spells of an element but the matching totem is not in your bags. A master totem (TBC/Wrath) in your bags or relic slot covers all elements. Which spell needs which totem comes from the game data. Only out of combat; can be switched off in the options.
- New data file BuffSentinelTotems.lua (game data, unchanged from the GoldSentinel test system).
- Test routine (developer only): T236 (missing elements, master totem in bags and relic slot, per game version).

## 0.9.39
- **New: Righteous Fury hint for paladins** (all versions with Righteous Fury): in a group, when Righteous Fury is on although you are not the tank (spec not Protection, no tank role and not main tank), BuffSentinel writes ONE line in your own chat – once per group, nothing is sent to others. Can be switched off in the options.
- Test routine (developer only): T235 (spec, tank role, main tank, aura by ID, alone, switch, once per group).

## 0.9.38
- **New (optional): Fish Oil and Shiny Fish Scales for shamans** (Classic, WoW Forever, TBC, Wrath): "REAGENT LOW!" when you know Water Walking or Water Breathing and have fewer than 5 of the reagent. Off by default – switch it on in the options of your spec.
- Test routine (developer only): T234 (both reagents, optional, counting).

## 0.9.37
- **New: Symbol of Divinity for paladins** (Classic, WoW Forever, TBC, Wrath): in a group, "NO SYMBOL!" when you know Divine Intervention but carry no Symbol of Divinity (the reagent). IDs from the game data. Only out of combat; can be switched off in the options.
- Test routine (developer only): T233 (spell known, counting, group only, warning at 0).

## 0.9.36
- **New (optional): Light Feathers for priests and mages** (Classic, WoW Forever, TBC, Wrath): "FEATHERS LOW!" when you know Levitate or Slow Fall and have fewer than 5 Light Feathers. Off by default (not everyone uses these spells) – switch it on in the options of your spec.
- Test routine (developer only): T229 (priest and mage, optional and switchable, counting Light Feathers).

## 0.9.35
- **New: no room for soul shards (warlocks, Classic to Wrath)**: "NO ROOM FOR SHARDS!" when there is no free slot left in your normal bags or soul bags – the next shard from Drain Soul would be lost. Quivers and other special bags do not count. Only out of combat; can be switched off in the options.
- Test routine (developer only): T228 (normal and soul bags, special bags, new and old bag API, warning at 0).

## 0.9.34
- **New: drinks reminder for mana classes** (mage, priest, warlock, druid, shaman, paladin, hunter; Classic, WoW Forever, TBC, Wrath): "DRINKS LOW!" with the count when you have fewer than 10 drinks that restore mana – from level 10. Which items count comes from the game data for your game version (items with the "Drink" effect). Only out of combat; can be switched off in the options.
- Test routine (developer only): T227 (data per game version, all bags, mana classes only, from level 10).

## 0.9.33
- Test routine (developer only): in Retail, T35 (recorder) and T221 (empty own proc) reported FEHLER although everything works – own procs do not exist in Retail by design. Both now check the rule with the Classic family and additionally that Retail creates no own proc. T117 no longer compares an unused button alpha; T84 works with every Lua version. No change for players.

## 0.9.32
- **New: Soulstone reminder for warlocks** (Classic, WoW Forever, TBC, Wrath): in a group, "NO SOULSTONE IN GROUP!" when nobody (you included) has a Soulstone – so you place one on a healer before the pull. Checked by spell ID, every rank counts. Only out of combat; if the game does not report an aura ID, nothing is shown (no guessing). Can be switched off in the options.
- Test routine (developer only): T226 (group without/with Soulstone, on yourself, alone, combat, aura without ID, data per version).

## 0.9.31
- **New: pet food reminder for hunters (WoW Forever)**: "PET FOOD LOW!" when you have fewer than 10 items of food that your current pet eats (meat, fish, bread, cheese, fruit, fungus …). Which food is which comes from the game data – only WoW Forever has it, so the reminder exists only there. Only out of combat, with a pet out, in English or German clients; can be switched off in the options.
- New data file BuffSentinelVorratDaten.lua (game data, unchanged from the GoldSentinel test system).
- Test routine (developer only): T225 (food the pet eats, all bags, new and old bag API, language, no pet, only WoW Forever, recount on pet change).

## 0.9.30
- **New: Inner Fire charges for priests** (Classic, WoW Forever, TBC, Wrath): when your Inner Fire has only 1–4 of its 20 charges left, BuffSentinel shows "RENEW INNER FIRE!" with the remaining charges – out of combat, so you renew it before the pull. A click casts Inner Fire. If the game does not report a charge count, nothing is shown (no guessing).
- Test routine (developer only): T224 (charges 1–4, 5+, unknown, protected, aura missing, combat, data per version).

## 0.9.29
- **New: mana gem reminder for mages** (Classic, WoW Forever, TBC, Wrath): "NO MANA GEM!" when you can conjure a mana gem but have none in your bags – every gem rank counts. IDs from the game data (wago.tools). Only out of combat, also when playing alone; can be switched off in the options.
- Test routine (developer only): T223 (conjure spell per version, all gem ranks).

## 0.9.28
- **New: healthstone reminder for warlocks** (Classic, WoW Forever, TBC, Wrath): "NO HEALTHSTONE!" when you can create a Healthstone but have none in your bags – stones of every rank and talent level count. Item and spell IDs come from the game data (wago.tools). Only out of combat, also when playing alone; can be switched off in the options.
- Test routine (developer only): T219 (create spell per version, stones of all ranks and talent levels, display at 0 only); T208 now looks up its entries by name.

## 0.9.27
- **New: reagent reminders for group buffs** (Classic, WoW Forever, TBC, Wrath): mages (Arcane Powder), priests (candles for Prayer of Fortitude), druids (reagent for Gift of the Wild) and paladins (Symbol of Kings) see "REAGENT LOW!" with the count when they are in a group and have fewer than 10 (Symbol of Kings: 20). BuffSentinel counts the reagent of your HIGHEST learned rank – e.g. Holy Candle for rank 1, Sacred Candle from rank 2 – so there is no false alarm while levelling. Item and spell IDs come from the game data (wago.tools).
- **Shamans:** "NO ANKH!" when you have no Ankh for Reincarnation (also when playing alone).
- Only out of combat, counted only when your bags change; can be switched off in the options.
- Test routine (developer only): T218 (highest rank per reagent, group only, Ankh alone, data per class and version).

## 0.9.26
- **New: ready check summary** (all game versions): when a ready check starts, BuffSentinel writes ONE line in chat with everything that is currently missing (e.g. "Ready check – missing: Arcane Intellect, Ammo (150)"), or "everything ready". Where buff reminders are switched off for the zone, no line is written (nothing was checked there). Can be switched off in the options.
- Test routine (developer only): T217 (line, "everything ready", no line where nothing is evaluated, switch).

## 0.9.25
- **New: repair reminder for all classes** (all game versions): in capital cities, inns and sanctuaries – where you can repair – BuffSentinel shows "REPAIR!" with the percentage of your most damaged item when it is below 30 %, and "broken" at 0 %. This works even if buff reminders are switched off for cities and inns. Only out of combat; read only when durability changes.
- Can be switched off in the options like any other reminder.
- Test routine (developer only): T216 (weakest item, protected values, places, combat, zone setting).

## 0.9.24
- **New: pet reminder for hunters and warlocks** (Classic, WoW Forever, TBC, Wrath, Cata): "PET MISSING!" or "DEMON MISSING!" when you have no pet, and "dead" when it has died – only out of combat and only after 3 seconds, so it does not flash when you dismount, land or change zones. Comes back -> disappears at once.
- Warlocks with Demonic Sacrifice get no demon reminder (you sacrifice the demon on purpose).
- Can be switched off in the options like any other reminder.
- Test routine (developer only): T209 (data per class and version, Demonic Sacrifice, display rules with the 3-second grace time).

## 0.9.23
- **New: ammo reminder for hunters** (Classic, WoW Forever, TBC, Wrath): with a bow, gun or crossbow, BuffSentinel shows "AMMO LOW!" with the remaining count when you have fewer than 200 rounds left, and "empty" when the ammo slot is empty. Only out of combat and not while mounted – so you can restock before the pull. Thrown weapons and wands are ignored.
- **New: soul shard reminder for warlocks** (Classic to Wrath): "SHARDS LOW!" with the count when you have fewer than 3 soul shards (as soon as you know Drain Soul). Only out of combat.
- Both are counted only when your bags or equipment change, never every frame – no extra load in combat. Both can be switched off in the options like any other reminder.
- Test routine (developer only): T207 (ammo: weapon types, empty slot, client without ammo slot, display rules), T208 (soul shards and ammo per game version, counting on the bag event); TU1 situations know the supply rules.

## 0.9.22
- Shared file GoldSentinelMarkt updated to version 7 (unchanged copy). Without AHSentinel, passing on a scan now creates about 2.8 MB of temporary memory instead of up to 7.5 MB (less stutter), with the same result. Switching off "Share market data" now also stops a reply to the guild that was already planned.
- Test routine (developer only): T178 also checks that a planned guild reply is not sent after switching off (own switch and switch of another addon), with a counter-check that this path really sends while the switch is on.

## 0.9.21
- Shared file GoldSentinelMarkt updated to version 3 (unchanged copy): the export for the uploader keeps the last 6 scans instead of 2 (at most 1.5 MB).
- Test routine (developer only): T178 now also checks the case where "Share market data" is switched off while something is already waiting – queued messages and a planned read are dropped, nothing is sent and nothing is read (T-MN-S). The test-only portions of TU4 are shorter (2 ms instead of 4 ms), so the 8 ms limit per frame holds even with garbage collection.

## 0.9.20
- **Shaman weapon imbue + weapon totem (WoW Forever hotfix of 12 Nov):** shamans can now have their own weapon imbue and a weapon totem at the same time. BuffSentinel now writes the weapon enchant IDs (main/off hand) and the active totems to the diagnostic log whenever they change ("WAFFE mh=… oh=… totem=…"), so the real values can be measured in the game. Recognition of a totem enchant as "not your own imbue" is prepared but stays switched off until the measurement is in – nothing is guessed, the reminder behaves as before.
- A proc whose aura has already run out is no longer shown as active before the next aura update.
- Options and test report: if "Share market data" is switched off in another GoldSentinel addon, BuffSentinel now shows "on (network off: other addon)" and a note in the options – the shared network only runs when it is on everywhere.
- Test routine (developer only): T205 (shaman imbue/totem cases a/b/c, unknown ID, measurement), T206 (group buff from another player counts as present), proc situations "0.5 s left" and "expired", T180 (network off through another addon).

## 0.9.19
- Shared file GoldSentinelMarkt updated to version 2 (unchanged copy): it no longer reads a full scan a second time while AHSentinel is loaded (version 1 could make the game stutter during the AHSentinel full scan and in the sniper), smaller send queue, guild summary hourly, sold-out items in the export.

## 0.9.18
- Shared file GoldSentinelMarkt v1 updated to the current version (FeedStart/Feed: addons with their own full scan pass on their result, so a scan is never read twice). 0.9.17 still carried the earlier copy.

## 0.9.17
- **Market data network (shared GoldSentinel file GoldSentinelMarkt v1):** BuffSentinel itself never queries the auction house. The shared file only reads along when another addon or you start a full scan of the auction house, and shares lowest prices and quantities (no names) with your guild and the GoldSentinel network, so all GoldSentinel users get complete market data. No question to the player, on by default; switch "Share market data (anonymous, prices only)" in the options to turn it off. Old clients without the auction house interface: silently off.
- Test report and diagnostic log contain a "MARKT-NETZ" line (version, on/off, scans read, sent/received, stored items).
- Test routine (developer only): T176–T179 (loaded and attached, BuffSentinel works without the file, switch off = no reading/sending, no Lua error without the auction house interface).

## 0.9.16
- **New: command list while typing.** Type `/bsen` (or `/buffsentinel`) in the chat and a list of ALL commands with a short description appears above the input. Every letter filters (e.g. `/bsen p` = log commands), most used commands come first. Click or Tab selects, Enter runs the selected command. The chat input itself is never written (no taint). Switch it off in the options or with `/bsen cmdlist off` (German client: `/bsen befehlsliste aus`).
- The list and the chat command use one and the same command table, so nothing can be missing; German and English command words work in every client. `/bsen help` lists all commands from this table. Developer commands only show for the developer.
- Test routine (developer only): T170–T175 (every command in the list, filtering, click selects/Enter runs, chat input never written, developer commands, all languages); TU4 portions now about 4 ms per frame.

## 0.9.15
- "Share names" (guild/group) is now the main switch: if it is off, BuffSentinel sends nothing at all – the whisper network of GoldSentinelSync always includes guild and group. The option "Also exchange via the whisper network" is greyed out while "share names" is off.
- The options window shows "on"/"off" in the game language (was always German).
- Mounted or in a vehicle: no buff reminder out of combat.
- Test routine (developer only), comprehensive tests TU1–TU8:
  - L (TU1) situations: every class and spec × procs (ready, out of combat, wrong stance/form, too little resource, on cooldown, not triggered, without combat log, stacks), buffs (missing, present, mounted, in combat, group and weapon buffs), cooldowns (ready, running, protected, open world) and context (dead, ghost, flight, vehicle, Forever in combat) – T200–T204.
  - M (TU2) player flows: change stance while a proc glows, click in combat, change spec, /reload in combat, buff expires → horn → rebuff → horn stops, choose and preview sounds – T210–T215.
  - N (TU3) defaults with the list of all fields – T220–T222.
  - O (TU4) invariants with 1000 random cases (fixed seed 20261113), in portions below 8 ms per frame – T230–T232.
  - P (TU5) real data (read only): can every enabled warning trigger? Violations go to the diagnostic log ("GRUNDREGEL VERLETZT …").
  - Q (TU6) a regression test for every finding since October (T158–T162, "Regressions: n of m present").
  - S (TU7) all situations on Forever, Era and TBC, languages deDE/enUS, windows at a scale other than 100 % – T251–T255.
  - The report shows one line per area TU1–TU7 ("OK n · FEHLER n · SKIP n").

## 0.9.14
- **Sync without own chat channel (WoW Forever):** In WoW Forever addon messages in own chat channels never arrive (server: NOT_ALLOWED_IN_CHANNEL). BuffSentinel no longer joins the channel "BuffSentinelSync" and leaves it once if it is still joined (frees one of your 10 channel slots).
- New shared file **GoldSentinelSync 2** (unchanged copy): name sharing runs over guild, group/raid and the whisper network of the GoldSentinel addons, in all game versions (Era, TBC, Mists, Retail, Forever). The message prefix "BuffSentinel" stays, so older BuffSentinel versions of other players are still understood. No own send queue or timer any more.
- What goes into the whisper network (option "Also exchange via the whisper network"): talent and spell name mappings you learned, questions for missing names and their answers (at most 10 questions at once), and procs/abilities learned automatically. Guild/group only (never the network): the full list exchange at login and when the group grows ("R").
- Names of other players from the network are never shown in chat; messages from guild or group still name the sender.
- New command `/bsen sync test`: who else uses BuffSentinel (answers from guild, group, whisper network). The options show how many players with BuffSentinel were seen in the last hour.
- Diagnostic log: sync path once per session, every 10 minutes "sent / received / dropped", and the lines of GoldSentinelSync (including "NETZ", without names).
- **GoldSentinelTest 2:** share error reports with the developer (only with consent, /gstest).
- GoldSentinelGame 3 (shared file, comments only).
- Test routine (developer only): new cases T150–T157 (sending never over a channel, receiving with unknown sender and old messages, no channel join, /bsen sync test, versions of the shared files, whisper network storage and net=false, diagnostics without names, error reports only with consent).

## 0.9.13
- The display areas (buffs, procs, cooldowns, dispel) no longer get in the way of other GoldSentinel addons: free-floating displays are no longer entered in the shared window list, so the interface checks of ThreatSentinel and AHSentinel no longer report their windows as "covering BuffSentinelAnchor_…".
- Empty display areas (no icon) shrink to 1 × 1 outside move mode instead of lying invisibly 340 pixels wide on the screen; in move mode and as soon as they have content they get their full size back.
- Test routine (developer only): new case T149.

## 0.9.12
- English clients: long alerts on the buttons (e.g. "CLEARCASTING!") are now split at the word joint ("CLEAR-" / "CASTING!") instead of only shrinking the font. German clients keep the German word parts ("BLITZSCHLAG-" / "SCHILD!").
- Test routine (developer only): new case T148 checks the split in both languages.

## 0.9.11
- New diagnostic log (from the GoldSentinel template, new file `Diag.lua`): BuffSentinel records errors, refused aura access in WoW Forever/Retail and slow display updates (more than one frame). Repeated identical entries are only counted (×N). `/bsen protokoll` shows the log to copy. At logout or `/reload` it is stored as `BuffSentinelDB.diagExport` (starts with GSDIAG1) so the RaidMaster uploader can send it to GoldSentinel's test reports; `/bsen protokoll off` turns that off, `/bsen protokoll on` back on. The log contains no player, character, guild or realm names.
- `/bsen help` lists the new command.
- Test routine (developer only): new case T146 (entries, counter instead of loop, GSDIAG1 export, no names) and client case T147.

## 0.9.10
- Tooltips of the options window, the group grid, the dispel bar and the PayPal button now appear beside the window instead of on top of it, so they no longer cover other buttons.
- Test routine (developer only): new area K "oberflaeche" checks the interface in the real client (from the GoldSentinel template, new file `UICheck.lua`): own tooltips cover no buttons (T140), no overlap with Blizzard or other GoldSentinel windows (T141, free-floating displays excluded), windows fully on screen (T142), button labels not cut off (T143), displayed game values plausible – level, class, game version, talent points, group grid rows, own buffs (T144), no error loop with the same message more than 10× (T145). Without a real client T140–T143 are skipped, never counted as OK. Area K runs first, before other areas set test values. Read only, nothing is changed.

## 0.9.9
- WoW Forever: newly learned spells are recognised again without `/reload`. The event LEARNED_SPELL_IN_TAB does not exist in Forever; BuffSentinel now also listens to LEARNED_SPELL_IN_SKILL_LINE and only registers events the client knows (C_EventUtils.IsEventValid where available).
- Test routine (developer only): T29 accepts events the client does not know and checks that learning a spell is always detected; the combat report states "real actions: not counted in the combat part" instead of a stale value from the last automatic run.

## 0.9.8
- **WoW Forever / Retail – fixes Lua errors from the test reports** ("GetAuraDataByIndex(): Auras cannot be accessed when secret while tainted by 'BuffSentinel'", on UNIT_AURA and right after combat). BuffSentinel now only reads auras when the game allows it: not in combat, not in the first moment after combat (read half a second later instead), not from group members or targets that are in combat themselves, and not while the game reports protected auras. If the game refuses access anyway, the call is caught, the last known values are kept (no false "buff missing" alerts) and reading pauses for 2 seconds – no Lua error.
- Old clients (Classic Era, TBC, Wrath, Cata, MoP) are unchanged.
- Test routine (developer only): new case T139 simulates the refused access, the delayed read after combat, a group member in combat and protected auras.

## 0.9.7
- **Languages:** BuffSentinel now follows the language of the game client (for all players). English is the default, German is fully translated; all other languages show English for now. All texts live in the new file `Locales.lua`: chat messages, options, group grid, tooltips, minimap button, test bar, arrange bar, alerts on the buttons (e.g. "CLEARCASTING!"), spec and sound names and the test routine report. Spell and talent names come from the game as before.
- New command `/bsen help` listing all commands; the English short forms `/bsen move`, `/bsen errors`, `/bsen donate` work in every language.
- Addon list description in English, in German on a German client.
- Test routine (developer only): language tests in area F (every English text has a German one, placeholders match, help on an English client contains no German – T98, T137, T138); final count "real actions: 0" with the new case T136 (sending, chat and joining channels are only counted, never triggered); the `/reload` reminder appears after every run; T134 appears only once in the combat report.

## 0.9.6
- WoW Forever: the Procs and Cooldowns pages now show the same clear notice as the other pages – no display of procs, cooldowns and buffs in combat, dispel grid off, procs are not learned automatically. The line "learns new procs automatically" is no longer shown in Forever. (As before, BuffSentinel shows nothing in combat in Forever; buff reminders work before the pull and out of combat.)
- Damaged saved settings (wrong value types, incomplete positions) are repaired on load instead of causing Lua errors.
- Forever/Retail: tooltips of the group grid, the buttons and the dispel bar no longer concatenate protected player names (no Lua error in combat); addon messages and channel notices with protected values are ignored.
- Automatic learning no longer rebuilds the display in the middle of an aura scan.
- Errors (also in scanning, options pages and name sharing) are counted, shown in `/bsen fehler` and reported to GoldSentinel's test reports via the shared file `GoldSentinelTest.lua` (included unchanged). `/bsen fehler` also shows the number of pending reports.
- Developer only: test routine `/bsen testroutine [area|kampf]`, `/bsen selbsttest` (simulates WoW Forever via `GoldSentinelGame.SetTestFlavor`) and the "Alles testen" button. It sends nothing, joins no channel, casts nothing and leaves your saved settings unchanged.

## 0.9.5
- Errors in event handlers are now counted and show up in `/bsen fehler` (only the first one is still printed to chat).
- Forever/Retail: if BuffSentinel cannot hide its buttons before combat (combat lockdown already active), it does so right after combat.
- WoW Forever – stated clearly, also in the options and on the dispel page: no display of procs, cooldowns and buffs in combat (secret values), the dispel grid is off (also out of combat), procs are not learned automatically. Buff reminders work before the pull and out of combat.

## 0.9.4
- `GoldSentinelGame.lua` updated to version 2: wins over early, withdrawn copies that other GoldSentinel addons may still ship – no Lua errors when several addons are loaded together.

## 0.9.3
- Version detection now uses the shared `GoldSentinelGame.lua` of all GoldSentinel addons (included unchanged, listed in the .toc right after `GoldSentinelDev.lua`). WoW Forever is also recognised via the game's project ID in case the interface number changes at launch.
- Modern-client restrictions now depend on `GoldSentinelGame.IsModern` (Forever, Retail or any client with secret values). Classic Era, TBC, Wrath, Cata and MoP Classic are unchanged.
- Group names go through `GoldSentinelGame.Short` (secret names are never stored).
- `/gsgame` shows the detected game version; `/bsen fehler` shows the same line in addition to the error diagnostics.

## 0.9.1 – WoW Forever hardened
- WoW Forever runs on the modern client with the same addon restrictions as Retail (no combat log, "secret values" in combat). BuffSentinel now treats Forever the same way: buff reminders before the pull, no evaluation of auras, cooldowns, health or names in combat – a one-time chat hint (use the game's Cooldown Manager for procs in combat). The switch checks whether the game knows secret values; Classic Era, TBC, Wrath, Cata and MoP Classic are unchanged.
- The combat log is no longer registered on Forever and Retail; Overpower, Revenge and Riposte are detected via "spell usable" there.
- Secret values are checked everywhere before any arithmetic or comparison: own auras (stacks, expiration, spell ID), target health (Execute), group names, debuff types for dispelling, cooldowns. Secret cooldowns no longer count as "ready" – no false flash with sound on pull.
- Forever/Retail: all click buttons are hidden before combat so no invisible buttons catch clicks in combat.
- Errors no longer freeze the display: every button is protected individually and errors are counted. New command `/bsen fehler` shows diagnostics.

## 0.9.0
- New "Optionen" (options) tab (replaces "Zonen & Anzeige") with all settings in one place: alert sounds, zones, cooldowns & dispel, auto-learning, display & arrange, sizes, minimap, name sharing.
- Alert sounds fully configurable per alert type (horn for expired own buff, group buff missing, proc, cooldown ready, dispellable debuff, important raid debuff, bell):
  - On/off and sound per class and spec (switches with your spec), with "apply to all specs" and "reset spec".
  - Large selection: about 50 game sounds (only those present in your WoW version), bells, gong, war drum and more effects, all LibSharedMedia sounds from other addons, and custom files or sound IDs.
  - Picker window with preview (right-click = preview only) and a "listen" button on each row.
  - Selectable sound channel (Master, SFX, Dialog, Ambience, Music) and horn interval 3–60 s.
- Previous sound settings are migrated.

## 0.8.6
- Battle Shout now sounds the horn like all your own buffs until it is renewed (no bell by default anymore; the bell can still be enabled per entry).
- Feral druid: the Clearcasting button casts Shred (cat) or Maul (bear) depending on your form and appears in both forms. The mapping adapts even if not all forms are learned yet.

## 0.8.5
- When one of your own buffs expires (armor, shield, weapon enchant, poison …), BuffSentinel sounds a horn every 5 seconds until it is renewed (can be turned off, interval 5/10/15/30 s). Entries with a bell such as Battle Shout ring instead.
- Procs only appear when they are possible in your current stance or form (e.g. Overpower only in Battle Stance, Shred only in Cat Form). If only rage/mana/energy is missing, the proc stays visible with a blue tint.

## 0.8.4
- Sounds are off by default (switched off once in existing profiles too; afterwards your own choice applies).
- New: per-entry bell ("Ton" button on the procs, buffs and cooldowns pages). It rings even when the general sounds are off. By default only Battle Shout has a bell.
- "Test sounds" also plays the bell.

## 0.8.3
- Test mode with all classes and specs is now a developer tool (GoldSentinelDev). For everyone else, test mode shortcuts (`/bsen test`, Shift + left-click on the minimap button) open the arrange mode instead.
- "Test sounds" is now available in the arrange bar.

## 0.8.2
- New "Anordnen" (arrange) button at the top of the options window (also Ctrl + left-click on the minimap button or `/bsen anordnen`). Shows all your own buttons for dragging, like test mode, plus a bar with size, spacing and direction (horizontal/vertical) per group.
- Window positions are saved (options, group grid, test and arrange bars). "Reset all positions" resets windows too.

## 0.8.1
- New: size per group – procs, buffs, cooldowns and dispel 50–200 % each, on top of the overall size ("Zonen & Anzeige" page). Groups and freely placed buttons keep their screen position when resized.
- New "reset sizes" button.

## 0.8.0
- New: **automatic learning.** When BuffSentinel meets procs or abilities that are not in its data yet (e.g. new content in WoW Forever), it adds them by itself:
  - Procs: a short self-buff gained in combat that is consumed three times by casting the same spell gets a proc button for that spell. Buffs that simply expire (weapon enchants, trinkets) and buffs from other players are ignored.
  - Abilities: class spells with a cooldown of at least 10 s are added to the cooldown bar as soon as you cast them or learn them (trainer, talent point).
  - Learned entries are remembered per spec and for all characters on the account.
  - Discoveries are shared with other BuffSentinel users (spell IDs only, can be turned off).
  - Overview, removal and on/off switch on the "Aufnahme" (recording) page.
- Spells not learned yet (greyed out in the Cata/MoP spellbook) and spells of other specializations no longer count as known.

## 0.7.3
- Long compound words are split at a word boundary onto two lines (e.g. "BLITZSCHLAG-" / "SCHILD!") instead of shrinking the font; the font only gets smaller if that is not enough.
- Umlauts are now capitalised correctly in alerts ("SEELENSTÄRKE" instead of "SEELENSTäRKE").

## 0.7.2
- Priest: Surge of Light casts Smite in TBC (Flash Heal only from WotLK on).
- Hunter: Kill Command is a baseline ability in TBC – now shown for all specs.
- Warrior: Commanding Shout available from TBC; new Rampage buff reminder (TBC Fury).
- Procs from a buff are labelled with their source (e.g. "SHADOW TRANCE!") with the spell to press below.
- Long labels shrink automatically instead of being cut off.
- Dispel bar moved below/left of the buffs, cooldown and dispel titles sit above their area – no more overlaps.

## 0.7.1
- Fixed: main talent tree detection (e.g. 14/41/0 is now Fury, not Arms) – also with dual spec; the active talent group is read explicitly.
- Fixed: talents and procs are filtered by game version. WoW Forever talents (Bloodthrill, Vanguard) and WotLK procs (Sudden Death, Bloodsurge, Sword and Board, Hot Streak) no longer appear in TBC/Classic Era.
- Fixed: test mode only shows talent procs of the selected spec (e.g. Hot Streak only for Fire, Nature's Grace only for Balance).
- Settings lists no longer jump when you untick an entry; new "Auto" button resets an entry to the automatic choice.
- Fixed missing glyphs (arrow, check mark) and an outdated hint text.
- Test mode layout: two-line labels, group titles beside their area, areas grow with the number of buttons, test bar at the very top, settings window closes when test mode starts, dispel bar shows 5 sample slots and is hidden for classes without dispels.
- Warlock procs are named after their source (Shadow Trance, Backlash).
- Server sync retries joining the channel and shows a clear status.
- Fixed a tooltip that stayed visible after opening the support window.

## 0.7.0
- New "Support" button (PayPal) in the settings window header and on the "Zonen & Anzeige" page; also `/bsen donate` (or `/bsen support`). Opens only on click – no pop-ups, no chat messages.

## 0.6.3
- At least 3 seconds between alert sounds, the same sound at most every 4 seconds.
- "Test sounds" plays all alerts 3 seconds apart and shows which one is playing.

## 0.6.1
- WoW Forever: new Paladin (Seal of Fury, Light's Vigil, Voice of Truth, Swift Judgement, Templar's Bulwark, Infusion of Light) and Shaman abilities (Rage of the Farseer, Fire Nova, Totemic Projection).
- Test mode in Classic Era shows only the classes of your faction.

## 0.6.0
- Test mode with sample display for all classes and specs; buttons can be placed freely.

## 0.5.0
- Dispel bar for party/raid members and enemy dispel/purge buttons.

## 0.4.0
- First release: proc buttons, buff reminders with one-click buffing, cooldown bar, talent detection, all WoW versions.
