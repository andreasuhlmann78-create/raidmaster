-- BuffSentinel - Options.lua
-- Einstellungsfenster (komplett per Maus) und Minimap-Button

local ADDON, BS = ...
local C = BS.COLORS

local PAGES = {
    { key = "skill", label = "Skillung" },
    { key = "proc",  label = "Procs" },
    { key = "buff",  label = "Buffs" },
    { key = "cd",    label = "Cooldowns" },
    { key = "dispel",label = "Reinigen" },
    { key = "zones", label = "Zonen & Anzeige" },
    { key = "rec",   label = "Aufnahme" },
}

local ZONE_LABELS = {
    { "world",     "Offene Welt" },
    { "dungeon",   "Dungeons" },
    { "raid",      "Raids" },
    { "pvp",       "Schlachtfelder" },
    { "resting",   "Hauptstädte & Gasthäuser" },
    { "sanctuary", "Schutzgebiete" },
}

local CONTENT_W = 560

------------------------------------------------------------------------
-- Kleine UI-Bausteine
------------------------------------------------------------------------
local function Tex(parent, layer, r, g, b, a)
    local t = parent:CreateTexture(nil, layer or "BACKGROUND")
    t:SetColorTexture(r, g, b, a or 1)
    return t
end

local function SetShownSafe(w, on)
    if on then w:Show() else w:Hide() end
end

local function FlatButton(parent, w, h, label)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(w, h)
    b.bg = Tex(b, "BACKGROUND", 0.18, 0.19, 0.24, 1)
    b.bg:SetAllPoints()
    b.hl = Tex(b, "HIGHLIGHT", 1, 0.65, 0.2, 0.20)
    b.hl:SetAllPoints()
    b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    b.text:SetPoint("CENTER")
    b.text:SetText(label or "")
    function b:SetLabel(t) self.text:SetText(t) end
    function b:SetActive(on)
        if on then self.bg:SetColorTexture(0.55, 0.33, 0.08, 1) else self.bg:SetColorTexture(0.18, 0.19, 0.24, 1) end
    end
    return b
end

local function CheckBox(parent)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(20, 20)
    b.box = Tex(b, "ARTWORK", 0.22, 0.23, 0.28, 1)
    b.box:SetAllPoints()
    b.check = b:CreateTexture(nil, "OVERLAY")
    b.check:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
    b.check:SetSize(26, 26)
    b.check:SetPoint("CENTER")
    local hl = Tex(b, "HIGHLIGHT", 1, 0.65, 0.2, 0.25)
    hl:SetAllPoints()
    function b:SetChecked(on) SetShownSafe(self.check, on) end
    function b:SetUsable(on) self:SetAlpha(on and 1 or 0.35) end
    return b
end

------------------------------------------------------------------------
-- Seiten mit Widget-Pool (wird bei jeder Aktualisierung neu befüllt)
------------------------------------------------------------------------
local function NewPage(parent, key)
    local scroll = CreateFrame("ScrollFrame", "BuffSentinelPage_" .. key, parent, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 14, -12)
    scroll:SetPoint("BOTTOMRIGHT", -32, 12)
    local child = CreateFrame("Frame", nil, scroll)
    child:SetSize(CONTENT_W, 10)
    scroll:SetScrollChild(child)
    scroll.child = child
    scroll.pool, scroll.used, scroll.y = {}, {}, 0
    scroll:Hide()
    return scroll
end

local function ResetPage(p)
    p.y = 0
    for t, list in pairs(p.pool) do
        for _, w in ipairs(list) do w:Hide(); w:ClearAllPoints() end
        p.used[t] = 0
    end
end

local function Acquire(p, t, create)
    p.used[t] = (p.used[t] or 0) + 1
    p.pool[t] = p.pool[t] or {}
    local w = p.pool[t][p.used[t]]
    if not w then
        w = create(p.child)
        p.pool[t][p.used[t]] = w
    end
    w:Show()
    return w
end

local function FinishPage(p)
    p.child:SetHeight(math.max(10, p.y + 20))
end

local function AddHeader(p, text)
    local fs = Acquire(p, "header", function(parent)
        local f = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        f:SetJustifyH("LEFT")
        return f
    end)
    p.y = p.y + (p.y > 0 and 10 or 0)
    fs:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
    fs:SetText(text)
    fs:SetTextColor(C.accent[1], C.accent[2], C.accent[3])
    p.y = p.y + 26
end

local function AddText(p, text, color, indent)
    local fs = Acquire(p, "text", function(parent)
        local f = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        f:SetJustifyH("LEFT")
        if f.SetWordWrap then f:SetWordWrap(true) end
        return f
    end)
    indent = indent or 0
    fs:SetWidth(CONTENT_W - indent)
    fs:SetPoint("TOPLEFT", p.child, "TOPLEFT", indent, -p.y)
    fs:SetText(text)
    color = color or C.text
    fs:SetTextColor(color[1], color[2], color[3])
    p.y = p.y + math.max(14, fs:GetStringHeight()) + 6
end

local function AddButton(p, label, w, onClick, x, keepY)
    local b = Acquire(p, "button", function(parent) return FlatButton(parent, 120, 24, "") end)
    b:SetSize(w or 160, 24)
    b:SetLabel(label)
    b:SetActive(false)
    b:SetPoint("TOPLEFT", p.child, "TOPLEFT", x or 0, -p.y)
    b:SetScript("OnClick", onClick)
    if not keepY then p.y = p.y + 30 end
    return b
end

local function AddToggle(p, label, get, set, indent)
    local row = Acquire(p, "toggle", function(parent)
        local r = CreateFrame("Button", nil, parent)
        r:SetSize(CONTENT_W, 22)
        r.cb = CheckBox(r)
        r.cb:SetPoint("LEFT", 0, 0)
        r.cb:EnableMouse(false)
        r.text = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        r.text:SetPoint("LEFT", r.cb, "RIGHT", 10, 0)
        local hl = Tex(r, "HIGHLIGHT", 1, 1, 1, 0.04)
        hl:SetAllPoints()
        return r
    end)
    row:SetPoint("TOPLEFT", p.child, "TOPLEFT", indent or 0, -p.y)
    row.text:SetText(label)
    row.cb:SetChecked(get())
    row:SetScript("OnClick", function()
        set(not get())
        row.cb:SetChecked(get())
    end)
    p.y = p.y + 26
end

-- Zeile für einen Buff/Proc/Cooldown-Eintrag
local function CreateEntryRow(parent)
    local r = CreateFrame("Frame", nil, parent)
    r:SetSize(CONTENT_W, 46)
    r.bg = Tex(r, "BACKGROUND", 1, 1, 1, 0.035)
    r.bg:SetAllPoints()
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(34, 34)
    r.icon:SetPoint("LEFT", 6, 0)
    r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    r.name:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 10, -2)
    r.name:SetJustifyH("LEFT")
    r.status = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    r.status:SetPoint("BOTTOMLEFT", r.icon, "BOTTOMRIGHT", 10, 2)
    r.status:SetJustifyH("LEFT")
    r.status:SetWidth(340)
    r.cb = CheckBox(r)
    r.cb:SetPoint("RIGHT", -12, 0)
    r.mode = FlatButton(r, 104, 22, "")
    r.mode:SetPoint("RIGHT", r.cb, "LEFT", -14, 0)
    -- "Auto": manuelle Änderung verwerfen, zurück zur automatischen Auswahl nach Skillung
    r.auto = FlatButton(r, 52, 22, "Auto")
    r.auto:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("Zurück zum Standard", 1, 0.82, 0)
        GameTooltip:AddLine("BuffSentinel entscheidet wieder selbst nach deiner Skillung.", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    r.auto:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return r
end

local function AddEntryRow(p, e)
    local r = Acquire(p, "entry", CreateEntryRow)
    r:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
    r.icon:SetTexture(e.icon)
    r.icon:SetDesaturated(not e.known)

    local tags = ""
    if e.data.forever then tags = tags .. "  |cff66ccff[Forever]|r" end
    if e.data.group then tags = tags .. "  |cffaaaaaa[Gruppe]|r" end
    if e.data.spellBySpec and e.spellName and e.data.label then
        tags = tags .. "  |cffaaaaaa» " .. e.spellName .. "|r"
    end
    r.name:SetText(e.label .. tags)
    r.name:SetTextColor(e.known and 1 or 0.55, e.known and 1 or 0.55, e.known and 1 or 0.6)

    local status = e.status or ""
    if e.manual then status = status .. "  |cffaaaaaa(manuell " .. (e.enabled and "an" or "aus") .. ")|r" end
    r.status:SetText(status)
    local col = e.statusColor or C.dim
    r.status:SetTextColor(col[1], col[2], col[3])

    r.cb:SetChecked(e.enabled)
    r.cb:SetUsable(e.known)
    r.cb:SetScript("OnClick", function()
        if not e.known then return end
        BS:SetEntrySetting(e.key, "enabled", not e.enabled)
    end)

    if e.kind == "buff" then
        r.mode:Show()
        r.mode:SetLabel(e.mode == "combat" and "Nur im Kampf" or "Immer")
        r.mode:SetScript("OnClick", function()
            BS:SetEntrySetting(e.key, "mode", e.mode == "combat" and "always" or "combat")
        end)
    else
        r.mode:Hide()
    end

    r.auto:ClearAllPoints()
    r.auto:SetPoint("RIGHT", (e.kind == "buff") and r.mode or r.cb, "LEFT", -10, 0)
    if e.manual then
        r.auto:Show()
        r.auto:SetScript("OnClick", function() BS:SetEntrySetting(e.key, "enabled", nil) end)
    else
        r.auto:Hide()
    end
    p.y = p.y + 50
end

------------------------------------------------------------------------
-- Seiteninhalte
------------------------------------------------------------------------
local Fill = {}

function Fill.skill(p)
    AddHeader(p, "Erkannte Skillung")
    AddText(p, "|cffffffff" .. BS:SpecText() .. "|r   |cff888888" .. (BS.FLAVOR_NAMES[BS.flavor] or BS.flavor) .. "|r", C.text)
    if BS.isRetail then
        AddText(p, "Retail (Midnight): Blizzard macht Buffs, Cooldowns und das Kampflog im Kampf für Addons " ..
            "unlesbar. BuffSentinel zeigt hier deshalb nur fehlende Buffs ausserhalb des Kampfes an – " ..
            "Procs und Cooldowns im Kampf sind in Retail nicht möglich.", C.yellow)
    end

    local data = BS.ClassData[BS.class]
    for tab = 1, (BS.family == "classic") and 3 or 0 do
        local pts = BS.points[tab] or 0
        local bar = Acquire(p, "bar", function(parent)
            local f = CreateFrame("Frame", nil, parent)
            f:SetSize(CONTENT_W, 18)
            f.bg = Tex(f, "BACKGROUND", 0.16, 0.17, 0.21, 1)
            f.bg:SetPoint("LEFT", 130, 0); f.bg:SetSize(300, 12)
            f.fill = Tex(f, "ARTWORK", 1, 0.65, 0.2, 1)
            f.fill:SetPoint("LEFT", f.bg, "LEFT"); f.fill:SetHeight(12)
            f.name = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            f.name:SetPoint("LEFT", 0, 0)
            f.val = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            f.val:SetPoint("LEFT", f.bg, "RIGHT", 10, 0)
            return f
        end)
        bar:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
        bar.name:SetText(BS:SpecName(tab) or ("Baum " .. tab))
        bar.fill:SetWidth(math.max(1, 300 * math.min(pts, 51) / 51))
        if tab == BS.mainSpec then bar.fill:SetColorTexture(1, 0.65, 0.2, 1) else bar.fill:SetColorTexture(0.5, 0.5, 0.55, 1) end
        bar.val:SetText(pts .. " Punkte" .. (tab == BS.mainSpec and "  |cffffa733(Hauptbaum)|r" or ""))
        p.y = p.y + 22
    end
    if BS.family == "modern" then
        AddText(p, "Talente werden über ihre Zauber-IDs geprüft – unabhängig von der Client-Sprache.", C.dim)
    elseif not BS.talentsReadable then
        AddText(p, "Talente konnten nicht gelesen werden – die Auswahl richtet sich nur nach dem Zauberbuch.", C.yellow)
    end

    local c = BS:CountActive()
    AddHeader(p, "Automatisch angepasst")
    AddText(p, string.format("Aktiv für diese Skillung: |cffffffff%d Procs, %d Buffs, %d Cooldowns|r. " ..
        "Jede Skillung hat eigene Einstellungen – beim Umskillen oder Wechsel der Zweitskillung " ..
        "werden die Buttons automatisch umgestellt.", c.proc, c.buff, c.cd), C.text)
    local overrides = BS:CountOverrides()
    if overrides > 0 then
        AddText(p, overrides .. " Einträge hast du für diese Skillung manuell geändert.", C.dim)
        AddButton(p, "Empfehlung wiederherstellen", 220, function() BS:ResetEntrySettings() end)
    end
    AddButton(p, "Skillung neu einlesen", 220, function() BS:FullScan() end)

    -- Talente, auf die BuffSentinel reagiert
    local shown = false
    for _, e in ipairs(BS.entries) do
        local d = e.data
        local list = d.talents or e.enableList
        local spellList = d.talentSpell or d.enableIfTalentSpell
        if not list and spellList then
            if not shown then AddHeader(p, "Talente mit Einfluss auf die Buttons"); shown = true end
            local what = d.talentSpell and "schaltet frei: " or "aktiviert zusätzlich: "
            local match = d.talentSpell and e.talentMatch or e.viaTalent
            local first = type(spellList) == "table" and spellList[1] or spellList
            if match then
                AddText(p, "|TInterface\\RaidFrame\\ReadyCheck-Ready:14:14|t  " .. match .. "  –  " .. what .. e.label, C.text, 6)
            else
                AddText(p, "–  " .. ((BS.SpellInfo(first)) or ("Talent " .. first)) .. " (nicht geskillt)  –  " .. what .. e.label, C.dim, 6)
            end
        end
        if list then
            if not shown then AddHeader(p, "Talente mit Einfluss auf die Buttons"); shown = true end
            local match = BS:HasTalent(list)
            local what = d.talents and "schaltet frei: " or "aktiviert zusätzlich: "
            if match then
                AddText(p, "|TInterface\\RaidFrame\\ReadyCheck-Ready:14:14|t  " .. match .. "  –  " .. what .. e.label, C.text, 6)
            else
                local loc = BS:ResolveTalentList(list) or list[1]
                AddText(p, "–  " .. loc .. " (nicht geskillt)  –  " .. what .. e.label, C.dim, 6)
            end
        end
    end

    -- Namen in der Client-Sprache (gelernt, geteilt oder manuell zugeordnet)
    local lists = BS.nameIndex and BS.nameIndex.lists[BS.class]
    if lists and #lists > 0 and BS.talentsReadable then
        AddHeader(p, "Talent- und Fähigkeitsnamen")
        AddText(p, "Steht ein Name nur auf Englisch in den Addon-Daten, lernt BuffSentinel den Namen deines " ..
            "Clients über die Position im Talentbaum bzw. die Zauber-ID – von allen BuffSentinel-Nutzern " ..
            "auf dem Server. Findet sich niemand, ordne das Talent hier einmal per Klick zu.", C.dim)
        for _, item in ipairs(lists) do
            local en = item.names[1]
            local loc, how, _, from = BS:ResolveTalentList(item.names)
            if not loc and item.what == "Fähigkeit" then
                local sp = BS:LocalSpellName(en)
                if sp then loc, how = sp, "Zauber-ID" end
            end
            local line
            if loc and how == "direkt" then
                line = "|TInterface\\RaidFrame\\ReadyCheck-Ready:14:14|t  " .. loc .. "  |cff888888(" .. item.what .. ", im Client gefunden)|r"
            elseif loc then
                local src = how .. (from and (" von " .. from) or "")
                line = "|TInterface\\RaidFrame\\ReadyCheck-Ready:14:14|t  " .. en .. " = |cffffffff" .. loc .. "|r  |cff888888(" .. src .. ")|r"
            else
                line = "|cffffd040?|r  " .. en .. "  |cff888888(" .. item.what .. ", noch unbekannt)|r"
            end
            AddText(p, line, C.text, 6)
            p.y = p.y - 6
            if not loc or how == "manuell" then
                if how == "manuell" then
                    AddButton(p, "Zuordnung entfernen", 170, function() BS:UnassignTalent(en) end, 380, true)
                else
                    local open = BS.assigning == en
                    local b = AddButton(p, open and "Abbrechen" or "Zuordnen", 170, function()
                        BS.assigning = (BS.assigning ~= en) and en or nil
                        BS:RefreshOptions()
                    end, 380, true)
                    b:SetActive(open)
                end
                p.y = p.y + 28
            else
                p.y = p.y + 8
            end
            if BS.assigning == en then
                AddText(p, "Welches Talent in deinem Client ist \"" .. en .. "\"?", C.yellow, 12)
                for tab = 1, 3 do
                    local col = 0
                    local any = false
                    for _, t in ipairs(BS.allTalents) do
                        if t.tab == tab then
                            if not any then
                                AddText(p, "|cffffa733" .. (BS:SpecName(tab) or ("Baum " .. tab)) .. "|r", C.text, 12)
                                any = true
                            end
                            local pos = t.pos
                            AddButton(p, t.name, 176, function() BS:AssignTalent(en, pos) end, 12 + col * 182, true)
                            col = col + 1
                            if col == 3 then col = 0; p.y = p.y + 28 end
                        end
                    end
                    if col > 0 then p.y = p.y + 28 end
                end
                p.y = p.y + 6
            end
        end
    end

    local nt, ns = BS:CountLearned()
    AddText(p, string.format("Gelernte Namen (alle Charaktere): %d Talente, %d Zauber.  Server-Sync: %s  ·  Gilde/Gruppe: %s",
        nt, ns,
        BS:SyncStatusText(),
        BS.gdb.shareNames and "|cff66dd77an|r" or "|cffff5555aus|r"), C.dim)

    AddHeader(p, "Alle geskillten Talente")
    if #BS.talentList == 0 then
        AddText(p, BS.isRetail and "In Retail werden Talente direkt über Zauber-IDs geprüft." or "Noch keine Talentpunkte verteilt.", C.dim)
    elseif BS.family == "modern" then
        local parts = {}
        for _, t in ipairs(BS.talentList) do tinsert(parts, t.name) end
        AddText(p, table.concat(parts, ",  "), C.text)
    else
        for tab = 1, 3 do
            local parts = {}
            for _, t in ipairs(BS.talentList) do
                if t.tab == tab then tinsert(parts, t.name .. " " .. t.rank .. "/" .. t.maxRank) end
            end
            if #parts > 0 then
                AddText(p, "|cffffa733" .. (BS:SpecName(tab) or ("Baum " .. tab)) .. ":|r  " .. table.concat(parts, ",  "), C.text)
            end
        end
    end
    if not data then
        AddText(p, "Für deine Klasse gibt es noch keine vorgefertigten Daten.", C.yellow)
    end
end

local KIND_TEXT = {
    proc = "Ein Proc-Button erscheint sofort mittig, sobald die Fähigkeit nutzbar wird. Ein Klick darauf löst sie aus.",
    buff = "Läuft ein Buff aus, erscheint der passende Buff-Button. Ein Klick buffed dich bzw. direkt den Mitspieler ohne Buff.",
    cd   = "Die Cooldown-Leiste zeigt deine wichtigsten Fähigkeiten. Sobald eine bereit ist, leuchtet sie kurz auf. Klick = wirken.",
}

local function FillEntries(p, kind)
    if BS.isRetail and kind ~= "buff" then
        AddHeader(p, "In Retail nicht verfügbar")
        AddText(p, "Seit Midnight (12.0) sind Buffs, Cooldowns und das Kampflog im Kampf für Addons gesperrt " ..
            "(\"geheime Werte\"). Procs und Cooldowns kann BuffSentinel deshalb nur in den Classic-Versionen " ..
            "und in WoW Forever anzeigen.", C.yellow)
        return
    end
    AddText(p, KIND_TEXT[kind], C.dim)
    -- Einteilung "aktiv / weitere" einfrieren, solange die Seite offen ist: ein Häkchen soll den Eintrag
    -- nicht wegspringen lassen (sonst trifft der nächste Klick einen anderen Eintrag).
    -- Neu sortiert wird beim Seitenwechsel oder erneuten Öffnen.
    BS.listFreeze = BS.listFreeze or {}
    local freeze = BS.listFreeze[kind]
    if not freeze or freeze.spec ~= BS.mainSpec or freeze.class ~= BS.class then
        freeze = { spec = BS.mainSpec, class = BS.class, keys = {} }
        for _, e in ipairs(BS.entries) do
            if e.kind == kind then freeze.keys[e.key] = e.enabled end
        end
        BS.listFreeze[kind] = freeze
    end
    local active, other = {}, {}
    for _, e in ipairs(BS.entries) do
        if e.kind == kind and not e.data.enemyDispel then
            local inActive = freeze.keys[e.key]
            if inActive == nil then inActive = e.enabled end
            if inActive then tinsert(active, e) else tinsert(other, e) end
        end
    end
    AddHeader(p, "Aktiv für " .. (BS:SpecName(BS.mainSpec) or "deine Skillung"))
    if #active == 0 then AddText(p, "Keine Einträge aktiv.", C.dim) end
    for _, e in ipairs(active) do AddEntryRow(p, e) end
    if #other > 0 then
        AddHeader(p, "Weitere (nicht aktiv)")
        for _, e in ipairs(other) do AddEntryRow(p, e) end
    end
    if kind == "proc" then
        AddText(p, "Neue Procs (z. B. aus WoW Forever) lernt BuffSentinel automatisch – Übersicht auf der Seite \"Aufnahme\".", C.dim)
    end
    if kind == "buff" and #BS:GroupEntries() > 0 then
        AddButton(p, "Gruppen-Raster öffnen", 220, function() BS:ToggleRaster() end)
    end
end

function Fill.dispel(p)
    local db = BS.db
    AddHeader(p, "Mitspieler reinigen")
    if BS.isRetail then
        AddText(p, "In Retail (Midnight) sind Debuffs im Kampf für Addons gesperrt – Blizzard zeigt entfernbare " ..
            "Debuffs dort selbst an. Diese Funktion gibt es nur in den Classic-Versionen und in WoW Forever.", C.yellow)
        return
    end
    AddText(p, "Hat ein Gruppenmitglied einen Debuff, den du entfernen kannst, leuchtet sein Button in der " ..
        "Reinigungsleiste auf. Ein Klick reinigt genau diesen Spieler. Weil Blizzard im Kampf keinen Zauberwechsel " ..
        "erlaubt, liegt jeder Reinigungszauber auf einer eigenen Maustaste – der Buchstabe auf dem Button " ..
        "(L / R / M) zeigt, welche du drücken musst.", C.dim)
    AddToggle(p, "Reinigungsleiste anzeigen", function() return db.dispel.friendly end,
        function(v) db.dispel.friendly = v; BS:SettingsChanged() end)
    AddToggle(p, "Warnton bei neuem Debuff", function() return db.sound.dispel end,
        function(v) db.sound.dispel = v end)

    local lines = BS:DispelSummary()
    if #lines == 0 then
        AddText(p, "Deine Klasse/Skillung kann in dieser WoW-Version keine Mitspieler reinigen.", C.dim)
    else
        AddText(p, "Deine Reinigungszauber (" .. (BS:SpecName(BS.mainSpec) or "") .. "):", C.text)
        for _, l in ipairs(lines) do AddText(p, "•  " .. l, C.text, 10) end
    end
    AddText(p, "Wichtige Raid-Debuffs (z. B. Lucifrons Fluch, Stich des Flügeldrachen) leuchten zusätzlich rot " ..
        "und haben einen eigenen Warnton. Debuffs, die beim Reinigen schaden (Instabiles Gebrechen, " ..
        "Vampirberührung, Mutierende Injektion), werden bewusst nicht angezeigt.", C.dim)
    AddText(p, "Verschieben: im Testmodus die Leiste ziehen (Knopf \"Testmodus\" oben) oder ausserhalb des Kampfes Shift + ziehen.", C.dim)

    AddHeader(p, "Gegner entzaubern")
    AddText(p, "Hat dein Ziel einen Buff, den du entfernen kannst (Magie, stehlbare Buffs, Raserei/Wut), " ..
        "erscheint sofort ein Button wie bei einem Proc. Er zielt immer auf dein aktuelles Ziel und " ..
        "funktioniert deshalb auch mitten im Kampf.", C.dim)
    local any = false
    for _, e in ipairs(BS.entries) do
        if e.data.enemyDispel then AddEntryRow(p, e); any = true end
    end
    if not any then
        AddText(p, "Deine Klasse hat in dieser WoW-Version keine Fähigkeit zum Entzaubern von Gegnern.", C.dim)
    end
end

function Fill.proc(p) FillEntries(p, "proc") end
function Fill.buff(p) FillEntries(p, "buff") end
function Fill.cd(p)   FillEntries(p, "cd") end

function Fill.zones(p)
    local db = BS.db
    AddHeader(p, "Wo soll BuffSentinel aktiv sein?")
    local ok, ctx = BS:GetContext()
    AddText(p, "Aktuell: " .. (BS.CONTEXT_NAMES[ctx] or ctx) .. " – " ..
        (ok and "|cff66dd77aktiv|r" or "|cffff5555pausiert|r"), C.text)
    for _, z in ipairs(ZONE_LABELS) do
        AddToggle(p, z[2], function() return db.zones[z[1]] end,
            function(v) db.zones[z[1]] = v; BS:Refresh() end)
    end
    AddText(p, "Beim Fliegen, als Geist und beritten (ausserhalb des Kampfes) pausiert BuffSentinel automatisch.", C.dim)
    AddToggle(p, "Cooldown-Leiste in der offenen Welt nur im Kampf", function() return db.cdWorldCombatOnly end,
        function(v) db.cdWorldCombatOnly = v end)
    AddToggle(p, "Restzeit auf Cooldowns anzeigen", function() return db.cdTimer end,
        function(v) db.cdTimer = v end)

    AddHeader(p, "Sounds")
    AddToggle(p, "Sound bei fehlendem Buff", function() return db.sound.buff end, function(v) db.sound.buff = v end)
    AddToggle(p, "Sound bei Proc", function() return db.sound.proc end, function(v) db.sound.proc = v end)
    AddToggle(p, "Sound wenn Cooldown bereit", function() return db.sound.cooldown end, function(v) db.sound.cooldown = v end)

    AddHeader(p, "Anzeige & Testmodus")
    AddText(p, "Im Testmodus erscheinen alle Buttons mit Beispielwerten – ohne Kampf. Ziehe jeden Button dorthin, " ..
        "wo du ihn haben willst (Shift + ziehen = ganze Gruppe, Rechtsklick = zurücksetzen). Klicks wirken im " ..
        "Testmodus nichts. Er endet von selbst, sobald ein Kampf beginnt.", C.dim)
    local arrBtn = AddButton(p, BS.arrangeMode and "Anordnen beenden" or "Buttons anordnen", 170, function()
        BS:ToggleArrangeMode()
    end, 0, true)
    arrBtn:SetActive(BS.arrangeMode)
    local testBtn = AddButton(p, (BS.testMode and not BS.arrangeMode) and "Testmodus beenden" or "Testmodus starten", 170, function()
        BS:ToggleTestMode()
    end, 180, true)
    testBtn:SetActive(BS.testMode and not BS.arrangeMode)
    AddButton(p, "Alle Positionen zurücksetzen", 200, function() BS:ResetPositions() end, 360)
    AddText(p, "\"Buttons anordnen\" zeigt nur deine eigenen Buttons – wie im Testmodus ziehen, dazu Grösse, " ..
        "Abstand und Richtung (waagrecht/senkrecht) jeder Gruppe. Auch über den Knopf \"Anordnen\" oben, " ..
        "Strg + Linksklick auf den Minimap-Button oder /bsen anordnen.", C.dim)
    AddText(p, "Auch ohne Testmodus: Shift + ziehen verschiebt einen einzelnen Button (ausserhalb des Kampfes).", C.dim)

    AddText(p, "Grösse der Buttons – jede Gruppe einzeln, dazu die Gesamtgrösse für alle. " ..
        "Am besten im Testmodus einstellen, dann siehst du alle Buttons sofort.", C.dim)
    local function Pct(v) return math.floor((v or 1) * 100 + 0.5) end
    local function SizeRow(text, kind)
        AddButton(p, "–", 36, function() BS:ChangeScale(kind, -0.1) end, 0, true)
        AddButton(p, "+", 36, function() BS:ChangeScale(kind, 0.1) end, 42, true)
        p.y = p.y + 5
        AddText(p, text, C.text, 90)
        p.y = p.y + 5
    end
    SizeRow(string.format("Alle Buttons: |cffffffff%d %%|r", Pct(db.scale)), nil)
    for _, g in ipairs({ { "proc", "Procs" }, { "buff", "Buffs" }, { "cd", "Cooldowns" }, { "dispel", "Reinigen" } }) do
        SizeRow(string.format("%s: |cffffffff%d %%|r  |cff888888(%d px)|r", g[2], Pct(db.groupScale[g[1]]), BS:GroupSize(g[1])), g[1])
    end
    AddButton(p, "Grössen zurücksetzen", 200, function() BS:ResetScales() end)

    AddToggle(p, "Minimap-Button anzeigen", function() return not db.minimap.hide end,
        function(v) db.minimap.hide = not v; BS:UpdateMinimapButton() end)

    AddHeader(p, "Addon unterstützen")
    AddText(p, "BuffSentinel ist kostenlos und entsteht in meiner Freizeit. Wenn es dir hilft, freue ich mich über " ..
        "eine kleine Spende. Der Knopf zeigt den PayPal-Link zum Kopieren an.", C.dim)
    local donate = AddButton(p, "Unterstützen (PayPal)", 200, function() if BS.Donate then BS.Donate.Show() end end)
    donate:SetActive(false)
    AddText(p, "Auch per Befehl: /bsen spenden", C.dim)

    AddHeader(p, "Namen teilen")
    AddToggle(p, "Mit allen BuffSentinel-Nutzern auf dem Server austauschen",
        function() return BS.gdb.shareServer end,
        function(v) BS:SetShareServer(v) end)
    AddText(p, "Läuft über den versteckten Kanal \"BuffSentinelSync\" (erscheint nicht im Chat). " ..
        "Gefragt wird nur nach fehlenden Namen, es antwortet jeweils nur ein Spieler. " ..
        "Blizzard trennt Chat-Kanäle nach Fraktion: Horde tauscht mit Horde, Allianz mit Allianz.", C.dim, 30)
    AddToggle(p, "Mit Gilde und Gruppe austauschen",
        function() return BS.gdb.shareNames end,
        function(v) BS.gdb.shareNames = v; if v then BS:RequestNames() end end)
    AddText(p, "Server-Kanal: " .. BS:SyncStatusText(), C.text)
    AddText(p, "Es werden nur Talentpositionen und Zauber-IDs aus den BuffSentinel-Daten ausgetauscht – " ..
        "keine Charakter- oder sonstigen Daten.", C.dim)
end

local function AutoRow(p, item)
    local row = Acquire(p, "autorow", function(parent)
        local f = CreateFrame("Frame", nil, parent)
        f:SetSize(CONTENT_W, 30)
        f.bg = Tex(f, "BACKGROUND", 1, 1, 1, 0.035); f.bg:SetAllPoints()
        f.icon = f:CreateTexture(nil, "ARTWORK"); f.icon:SetSize(24, 24); f.icon:SetPoint("LEFT", 4, 0)
        f.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.text:SetPoint("LEFT", f.icon, "RIGHT", 8, 0)
        f.text:SetWidth(CONTENT_W - 150); f.text:SetJustifyH("LEFT")
        f.btn = FlatButton(f, 100, 22, "Entfernen"); f.btn:SetPoint("RIGHT", -6, 0)
        return f
    end)
    row:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
    local r = item.rec
    local icon
    if item.kind == "proc" then
        local _, ic = BS.SpellInfo(r.auraId); icon = ic or r.icon
    else
        local _, ic = BS.SpellInfo(r.id); icon = ic
    end
    row.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")
    local what
    if item.kind == "proc" then
        what = "Proc  » " .. (r.spell or "?")
    else
        what = "Cooldown" .. (r.cd and (" " .. BS.AutoCdText(r.cd)) or "")
    end
    local src = (r.src == "net") and ("von " .. (r.from or "?")) or "selbst gelernt"
    local specs = (r.specs and #r.specs > 0) and (BS:SpecList(r.specs) .. "  ·  ") or ""
    row.text:SetText(string.format("%s  |cff888888%s  ·  %s%s|r", item.name, what, specs, src))
    row.btn:SetScript("OnClick", function() BS:AutoRemove(item.kind, item.name) end)
    p.y = p.y + 34
end

function Fill.rec(p)
    local r = BS.gdb.recorder
    local auto = BS.gdb.auto
    AddHeader(p, "Automatisch lernen")
    if BS.isRetail then
        AddText(p, "In Retail (Midnight) sind Buffs und Cooldowns im Kampf für Addons gesperrt – " ..
            "automatisches Lernen gibt es nur in den Classic-Versionen und in WoW Forever.", C.yellow)
    else
        AddText(p, "Trifft BuffSentinel auf einen Proc oder eine Fähigkeit, die noch nicht in seinen Daten steht " ..
            "(z. B. Neuheiten in WoW Forever), nimmt es sie selbst auf: Ein kurzer Buff, der " ..
            BS.AUTO_PROC_MIN_HITS .. "-mal beim Wirken desselben Zaubers verbraucht wird, bekommt einen Proc-Button " ..
            "für diesen Zauber. Klassenzauber mit mindestens 10 s Abklingzeit kommen in die Cooldown-Leiste, " ..
            "sobald du sie wirkst oder neu erlernst. Buffs, die nur auslaufen (Waffen-Verzauberungen, " ..
            "Schmuckstücke), werden nicht aufgenommen.", C.dim, nil)
        AddToggle(p, "Neue Procs und Fähigkeiten automatisch aufnehmen",
            function() return auto.enabled end, function(v) BS:SetAutoLearn(v) end)
        AddToggle(p, "Entdeckungen mit anderen BuffSentinel-Nutzern teilen (nur Zauber-IDs)",
            function() return auto.share end, function(v) auto.share = v end)

        local list, cands, nIgnore = BS:AutoList()
        AddHeader(p, "Automatisch gelernt (" .. #list .. ")")
        if #list == 0 then AddText(p, "Noch nichts gelernt.", C.dim) end
        for _, item in ipairs(list) do AutoRow(p, item) end
        AddText(p, "Ein- und ausschalten wie alle anderen Einträge auf den Seiten Procs und Cooldowns. " ..
            "\"Entfernen\" löscht den Eintrag und nimmt ihn nicht wieder von selbst auf.", C.dim)
        if #cands > 0 then
            local parts = {}
            for i, cnd in ipairs(cands) do
                if i > 6 then break end
                tinsert(parts, string.format("%s (%d/%d%s)", cnd.name, cnd.hits, BS.AUTO_PROC_MIN_HITS,
                    cnd.spell and (" » " .. cnd.spell) or ""))
            end
            AddText(p, "Wird beobachtet: " .. table.concat(parts, ",  "), C.text)
        end
        if nIgnore > 0 then
            AddButton(p, "Entfernte wieder zulassen (" .. nIgnore .. ")", 260, function() BS:AutoResetIgnore() end)
        end
    end

    AddHeader(p, "Aufnahme-Modus")
    AddText(p, "Protokolliert jeden neuen Buff/Proc auf dir mit Spell-ID. So lassen sich Procs, die das " ..
        "automatische Lernen nicht erkennt, per Klick als eigener Proc-Button übernehmen.", C.dim)
    local b = AddButton(p, r.enabled and "Aufnahme stoppen" or "Aufnahme starten", 180, function()
        BS:SetRecorder(not r.enabled); BS:RefreshOptions()
    end, 0, true)
    b:SetActive(r.enabled)
    AddButton(p, "Liste leeren", 140, function() BS:ClearRecorder(); BS:RefreshOptions() end, 190)

    AddHeader(p, "Aufgenommen (" .. #r.list .. ")")
    if #r.list == 0 then AddText(p, "Noch nichts aufgenommen.", C.dim) end
    for _, name in ipairs(r.list) do
        local rec = r.seen[name]
        if rec then
            local row = Acquire(p, "recrow", function(parent)
                local f = CreateFrame("Frame", nil, parent)
                f:SetSize(CONTENT_W, 30)
                f.bg = Tex(f, "BACKGROUND", 1, 1, 1, 0.035); f.bg:SetAllPoints()
                f.icon = f:CreateTexture(nil, "ARTWORK"); f.icon:SetSize(24, 24); f.icon:SetPoint("LEFT", 4, 0)
                f.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
                f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.text:SetPoint("LEFT", f.icon, "RIGHT", 8, 0)
                f.btn = FlatButton(f, 120, 22, ""); f.btn:SetPoint("RIGHT", -6, 0)
                return f
            end)
            row:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
            row.icon:SetTexture(rec.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
            row.text:SetText(string.format("%s  |cff888888ID %s  ·  %dx|r", rec.name, tostring(rec.id or "?"), rec.count or 0))
            if BS:HasCustom(name) then
                row.btn:SetLabel("hinzugefügt"); row.btn:SetActive(true)
                row.btn:SetScript("OnClick", nil)
            else
                row.btn:SetLabel("+ als Proc"); row.btn:SetActive(false)
                row.btn:SetScript("OnClick", function() BS:AddCustomFromRecord(name) end)
            end
            p.y = p.y + 34
        end
    end

    AddHeader(p, "Eigene Procs")
    if #BS.db.custom == 0 then AddText(p, "Noch keine eigenen Procs.", C.dim) end
    for i, c in ipairs(BS.db.custom) do
        local row = Acquire(p, "customrow", function(parent)
            local f = CreateFrame("Frame", nil, parent)
            f:SetSize(CONTENT_W, 34)
            f.bg = Tex(f, "BACKGROUND", 1, 1, 1, 0.035); f.bg:SetAllPoints()
            f.icon = f:CreateTexture(nil, "ARTWORK"); f.icon:SetSize(24, 24); f.icon:SetPoint("LEFT", 4, 0)
            f.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
            f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.text:SetPoint("LEFT", f.icon, "RIGHT", 8, 0)
            f.text:SetWidth(150); f.text:SetJustifyH("LEFT")
            f.lbl = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.lbl:SetPoint("LEFT", 196, 0)
            f.lbl:SetText("Klick wirkt:")
            f.edit = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
            f.edit:SetSize(160, 20); f.edit:SetPoint("LEFT", 270, 0); f.edit:SetAutoFocus(false)
            f.edit:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
            f.del = FlatButton(f, 90, 22, "Entfernen"); f.del:SetPoint("RIGHT", -6, 0)
            return f
        end)
        row:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
        local _, icon = BS.SpellInfo(c.auraId)
        row.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")
        row.text:SetText(c.aura)
        row.edit:SetText(c.spell or "")
        row.edit:SetScript("OnEnterPressed", function(s) s:ClearFocus(); BS:SetCustomSpell(i, s:GetText()) end)
        row.del:SetScript("OnClick", function() BS:RemoveCustom(i) end)
        p.y = p.y + 38
    end
    AddText(p, "Zaubername eintragen und Enter drücken. Leer lassen = nur Meldung ohne Klick-Funktion.", C.dim)
end

------------------------------------------------------------------------
-- Hauptfenster
------------------------------------------------------------------------
function BS:CreateOptions()
    local f = CreateFrame("Frame", "BuffSentinelOptions", UIParent)
    f:SetSize(800, 560)
    f:SetFrameStrata("DIALOG")
    self:RegisterWindow(f, "options", { "CENTER", "CENTER", 0, 0 })
    tinsert(UISpecialFrames, "BuffSentinelOptions")

    local bg = Tex(f, "BACKGROUND", 0.07, 0.08, 0.10, 0.97); bg:SetAllPoints()
    local header = Tex(f, "BORDER", 0.12, 0.13, 0.17, 1)
    header:SetPoint("TOPLEFT"); header:SetPoint("TOPRIGHT"); header:SetHeight(44)
    local line = Tex(f, "ARTWORK", 1, 0.65, 0.2, 1)
    line:SetPoint("TOPLEFT", 0, -44); line:SetPoint("TOPRIGHT", 0, -44); line:SetHeight(2)

    local data = self.ClassData[self.class]
    local logo = f:CreateTexture(nil, "ARTWORK")
    logo:SetSize(28, 28); logo:SetPoint("TOPLEFT", 12, -8)
    logo:SetTexture((data and data.icon) or "Interface\\Icons\\Ability_Warrior_BattleShout")
    logo:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", logo, "TOPRIGHT", 10, 1)
    title:SetText("BuffSentinel  |cff888888v" .. self.version .. "|r")
    local flavor = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    flavor:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -2)
    flavor:SetText(self.FLAVOR_NAMES[self.flavor] or self.flavor)
    flavor:SetTextColor(0.55, 0.55, 0.6)

    f.spec = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f.spec:SetPoint("RIGHT", f, "TOPRIGHT", -48, -22)

    local close = FlatButton(f, 30, 30, "×")
    close:SetPoint("TOPRIGHT", -8, -7)
    close.text:SetFontObject("GameFontHighlightLarge")
    close:SetScript("OnClick", function() f:Hide() end)

    f.test = FlatButton(f, 100, 26, "Testmodus")
    f.test:SetPoint("RIGHT", close, "LEFT", -10, 0)
    f.test:SetScript("OnClick", function() BS:ToggleTestMode() end)
    -- "Anordnen": eigene Buttons verschieben, Grösse, Abstand und Richtung einstellen
    f.arrange = FlatButton(f, 96, 26, "Anordnen")
    f.arrange:SetPoint("RIGHT", f.test, "LEFT", -8, 0)
    f.arrange:SetScript("OnClick", function() BS:ToggleArrangeMode() end)
    -- Spenden-Knopf links neben "Anordnen" (öffnet nur auf Klick)
    if self.Donate then
        f.donate = self.Donate.CreateButton(f, 104, 26)
        f.donate:SetPoint("RIGHT", f.arrange, "LEFT", -8, 0)
    end
    f.spec:ClearAllPoints()
    f.spec:SetPoint("RIGHT", f.donate or f.arrange, "LEFT", -12, 0)
    f.spec:SetWidth(180)
    f.spec:SetJustifyH("RIGHT")
    if f.spec.SetWordWrap then f.spec:SetWordWrap(false) end

    local side = Tex(f, "BORDER", 0.10, 0.11, 0.14, 1)
    side:SetPoint("TOPLEFT", 0, -46); side:SetPoint("BOTTOMLEFT"); side:SetWidth(170)

    local content = CreateFrame("Frame", nil, f)
    content:SetPoint("TOPLEFT", 170, -46)
    content:SetPoint("BOTTOMRIGHT")

    f.pages, f.tabs = {}, {}
    for i, pg in ipairs(PAGES) do
        local tab = FlatButton(f, 150, 32, pg.label)
        tab:SetPoint("TOPLEFT", 10, -56 - (i - 1) * 38)
        tab.text:ClearAllPoints(); tab.text:SetPoint("LEFT", 14, 0)
        tab:SetScript("OnClick", function() BS:ShowPage(pg.key) end)
        f.tabs[pg.key] = tab
        f.pages[pg.key] = NewPage(content, pg.key)
    end

    local foot = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    foot:SetPoint("BOTTOMLEFT", 14, 12)
    foot:SetWidth(150); foot:SetJustifyH("LEFT")
    foot:SetText("Rechtsklick auf den Minimap-Button öffnet das Gruppen-Raster.")
    foot:SetTextColor(0.5, 0.5, 0.55)

    f:Hide()
    self.optionsFrame = f
    self.currentPage = "skill"
end

function BS:ShowPage(key)
    if key ~= self.currentPage then self.listFreeze = nil end   -- Seitenwechsel: Listen neu sortieren
    self.currentPage = key
    self:RefreshOptions()
end

function BS:RefreshOptions()
    local f = self.optionsFrame
    if not f or not f:IsShown() then return end
    f.spec:SetText("Skillung: |cffffa733" .. self:SpecText() .. "|r")
    f.test:SetActive(self.testMode and not self.arrangeMode)
    f.test:SetLabel((self.testMode and not self.arrangeMode) and "Test beenden" or "Testmodus")
    f.arrange:SetActive(self.arrangeMode)
    f.arrange:SetLabel(self.arrangeMode and "Fertig" or "Anordnen")
    for key, page in pairs(f.pages) do
        local on = key == self.currentPage
        f.tabs[key]:SetActive(on)
        if on then
            page:Show()
            ResetPage(page)
            local ok, err = pcall(Fill[key], page)
            if not ok then AddText(page, "Fehler: " .. tostring(err), C.red) end
            FinishPage(page)
        else
            page:Hide()
        end
    end
end

function BS:ToggleOptions()
    if not self.optionsFrame then self:CreateOptions() end
    if self.optionsFrame:IsShown() then
        self.optionsFrame:Hide()
    else
        self.listFreeze = nil                                      -- neu geöffnet: Listen neu sortieren
        self.optionsFrame:Show()
        self:RefreshOptions()
    end
end

------------------------------------------------------------------------
-- Minimap-Button (Linksklick: Optionen, Rechtsklick: Gruppen-Raster, ziehen: verschieben)
------------------------------------------------------------------------
function BS:UpdateMinimapButton()
    local b = self.minimapButton
    if not b then return end
    if self.db.minimap.hide then b:Hide() return end
    b:Show()
    local angle = math.rad(self.db.minimap.angle or 220)
    local radius = (Minimap:GetWidth() / 2) + 6
    b:ClearAllPoints()
    b:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

function BS:CreateMinimapButton()
    local b = CreateFrame("Button", "BuffSentinelMinimapButton", Minimap)
    b:SetSize(31, 31)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    local data = self.ClassData[self.class]
    local icon = b:CreateTexture(nil, "BACKGROUND")
    icon:SetTexture((data and data.icon) or "Interface\\Icons\\Ability_Warrior_BattleShout")
    icon:SetSize(20, 20)
    icon:SetPoint("TOPLEFT", 7, -6)
    icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    local border = b:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT")

    b:SetScript("OnClick", function(_, button)
        if button == "RightButton" then
            BS:ToggleRaster()
        elseif IsShiftKeyDown() then
            BS:ToggleTestMode()
        elseif IsControlKeyDown and IsControlKeyDown() then
            BS:ToggleArrangeMode()
        else
            BS:ToggleOptions()
        end
    end)
    b:SetScript("OnDragStart", function(s)
        s:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            cx, cy = cx / scale, cy / scale
            BS.db.minimap.angle = math.deg(math.atan2(cy - my, cx - mx))
            BS:UpdateMinimapButton()
        end)
    end)
    b:SetScript("OnDragStop", function(s) s:SetScript("OnUpdate", nil) end)
    b:SetScript("OnEnter", function(s)
        GameTooltip:SetOwner(s, "ANCHOR_LEFT")
        GameTooltip:AddLine("BuffSentinel", 1, 0.65, 0.2)
        GameTooltip:AddLine("Skillung: " .. BS:SpecText(), 1, 1, 1)
        GameTooltip:AddLine("Linksklick: Einstellungen", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Shift + Linksklick: Testmodus", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Strg + Linksklick: Buttons anordnen", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Rechtsklick: Gruppen-Buffs", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Ziehen: verschieben", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)

    self.minimapButton = b
    self:UpdateMinimapButton()
end
