if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Activity.lua
-- Rendite je Geschäftsart (H7) und Gold pro Stunde (H9), Anweisung "Handel nach Regelwerk" 9. Nov. 16:00.
--
-- Zeit (nur lokal, ohne Namen), je Tätigkeit:
--   ah    AH-Arbeit: nur AKTIVE Zeit bei offenem Auktionshaus. Aktiv = Zeit zwischen eigenen Handlungen (Klick im
--         Spiel bzw. in AHSentinel, Mausrad-Kauf). Zwischen zwei Handlungen zählen höchstens 2 Min.; nach der letzten
--         Handlung höchstens 2 Min. bis zum Schliessen. Automatische Scans/Sniper-/Wächter-Läufe zählen nicht.
--   mail  Briefkasten, gleiche Regel; wird beim Anzeigen nach dem Erlös auf die Geschäftsarten verteilt.
--   craft Herstellen: vom ersten bis zum letzten Herstellen einer Serie (Pausen über 2 Min. zählen nicht).
--   de    Entzaubern: zwischen Entzauberungen einer Serie (Pausen über 2 Min. zählen nicht).
--   AFK-Markierung stoppt jede Messung sofort; die Zeit seit der letzten Handlung zählt dann nicht.
--
-- Geschäftsarten (H7): Flippen (Kauf und Verkauf desselben Items), Herstellen (Verkauf hergestellter Items gegen
-- Materialkosten), Entzaubern (Abrechnung Le:DisenchantReport), Rohstoffe (Verkauf ohne Kauf). Ein Verkauf zählt
-- zum Geschäft, aus dem das Item stammt, und zu dessen Zeitpunkt (Herstellen bzw. Kauf), nicht zum Eingang der Post.
-- ============================================================
local A = AHAnalyzerPro
local string = A.SafeString or string          -- AHS-OVF1: string.format ohne 32-Bit-Überlauf (gleicher Text darunter)
local CreateFrame, C_Timer = A.OwnCreateFrame or CreateFrame, A.OwnTimer or C_Timer      -- VS-BILD-2 (0.65.320): eigene Skripte/Zeitgeber je Bild messen (nur während einer Vollscan-Messung)
local L = A.L

local Act = {}
A.Activity = Act

Act.GAP = 120                 -- Pause ohne Handlung: höchstens 2 Min. zählen
Act.MIN_SECONDS = 15 * 60     -- darunter "zu wenig Daten"
Act.KEEP_DAYS = 120
Act.TAIL = { ah = true, mail = true }   -- nach der letzten Handlung bis 2 Min. (beim Schliessen)
Act.Clock = function() return time() end
Act.sessions = {}             -- [kind] = { last = Zeitpunkt der letzten Handlung }

local function DB()
    if not A.db then return nil end
    local d = A.db.activity
    if type(d) ~= "table" then d = { days = {}, crafts = {} }; A.db.activity = d end
    d.days = d.days or {}
    d.crafts = d.crafts or {}
    return d
end
Act.DB = DB

-- Tagesbeginn ohne time(tabelle) (Befund 20:15, A1): immer eine Zahl, auch für 0/nil
local function DayKey(t)
    return A:DayStart(t)
end
Act.DayKey = DayKey

-- Sekunden einer Tätigkeit dem Tag des Zeitpunkts t gutschreiben
function Act:Add(kind, sec, t)
    if not (sec and sec > 0) then return end
    local d = DB()
    if not d then return end
    local dk = DayKey(t or self.Clock())
    local day = d.days[dk]
    if not day then day = {}; d.days[dk] = day end
    day[kind] = (day[kind] or 0) + sec
end

-- eigene Handlung: Zeit seit der letzten Handlung (höchstens GAP) zählen
function Act:Touch(kind, now)
    now = now or self.Clock()
    if self.afk then return end
    local s = self.sessions[kind]
    if s and s.last then
        local gap = now - s.last
        -- AH/Briefkasten: höchstens 2 Min. nach der letzten Handlung; Herstellen/Entzaubern: Pause über 2 Min. gar nicht
        if gap > 0 and (gap <= self.GAP or self.TAIL[kind]) then self:Add(kind, math.min(gap, self.GAP), now) end
    end
    self.sessions[kind] = { last = now }
end

-- Tätigkeit endet (AH/Briefkasten zu): nach der letzten Handlung höchstens GAP dazu (nicht bei AFK)
function Act:Stop(kind, now, noTail)
    now = now or self.Clock()
    local s = self.sessions[kind]
    self.sessions[kind] = nil
    if not (s and s.last) or noTail or self.afk or not self.TAIL[kind] then return end
    local gap = now - s.last
    if gap > 0 then self:Add(kind, math.min(gap, self.GAP), now) end
end

-- AFK: alle Messungen sofort stoppen (ohne Nachlauf); zurück: erst die nächste Handlung startet neu
function Act:SetAFK(afk, now)
    if afk and not self.afk then
        for k in pairs(self.sessions) do self.sessions[k] = nil end
    end
    self.afk = afk and true or nil
end

-- Zeit je Tätigkeit seit from (Tagesgenau)
function Act:Seconds(from)
    local d = DB()
    local out = { ah = 0, mail = 0, craft = 0, de = 0 }
    if not d then return out end
    local fromDay = DayKey(from or 0)
    for dk, day in pairs(d.days) do
        if dk >= fromDay then
            for k, v in pairs(day) do out[k] = (out[k] or 0) + v end
        end
    end
    return out
end

-- EB7 (Handel pro Stunde): eingeloggte Zeit je Tag, ohne AFK (Kennzeichen des Spiels) - jede Minute
Act.ONLINE_STEP = 60
function Act:OnlineTick()
    if self.afk or (A.Simulated and A:Simulated()) or (A.TestRoutine and A.TestRoutine.running) then return end
    self:Add("online", self.ONLINE_STEP)
    self:MarkSeen()                                     -- MR5: zuletzt gesehen
end
if C_Timer and C_Timer.NewTicker then
    A:On("READY", function() C_Timer.NewTicker(Act.ONLINE_STEP, function() pcall(Act.OnlineTick, Act) end) end)
end

-- ------------------------------------------------------------
-- MR7 (anweisung-markt-reiter Teil B, Masterplan Phase 6): Spielrhythmus lernen.
-- Grundlage: vorhandene Aktivität (Online-Minuten je Tag, days[..].online) und die Logins (Zeitpunkte, höchstens 200).
-- Ein Tag zählt als gespielt ab RHYTHM_MIN_ONLINE Sekunden online oder mit einem Login. Gelernt wird aus den letzten
-- RHYTHM_WINDOW Tagen; erst ab RHYTHM_MIN_SPAN Tagen Daten (sonst "ohne Daten: 1 Tag").
-- Nächstes Login = erster kommender Tag (ab morgen), dessen Wochentag in mindestens der Hälfte der Wochen gespielt wurde;
-- gibt es keinen, der Wochentag mit dem höchsten Anteil. Selbst einstellbar: täglich / einige Tage pro Woche (= alle
-- 2 Tage, Annahme) / nur Wochenende. Nur Information - Käufe ändert das nicht (MR8/MR6 nutzen es später).
-- ------------------------------------------------------------
Act.RHYTHM_WINDOW = 28
Act.RHYTHM_MIN_SPAN = 14
Act.RHYTHM_MIN_ONLINE = 600
Act.RHYTHM_MODES = { "auto", "daily", "some", "weekend" }
Act.LOGINS_MAX = 200

function Act:NoteLogin(t)
    local d = DB()
    if not d then return end
    d.logins = type(d.logins) == "table" and d.logins or {}
    t = t or self.Clock()
    local last = d.logins[#d.logins]
    if last and t - last < 300 then return end            -- /reload: kein neues Login
    d.logins[#d.logins + 1] = t
    while #d.logins > self.LOGINS_MAX do table.remove(d.logins, 1) end
end

function Act:RhythmMode()
    local m = A.db and A.db.settings and A.db.settings.rhythm
    for _, x in ipairs(self.RHYTHM_MODES) do if x == m then return m end end
    return "auto"
end
function Act:SetRhythmMode(m)
    if not (A.db and A.db.settings) then return end
    A.db.settings.rhythm = (m ~= "auto") and m or nil
end

-- Wochentag 1 = Sonntag ... 7 = Samstag (wie date("*t").wday)
local function WDay(t)
    local ok, d = pcall(date, "*t", t)
    return ok and type(d) == "table" and d.wday or 1
end

-- gespielte Tage (Tagesbeginn -> true) aus Aktivität und Logins
function Act:PlayedDays()
    local d = DB()
    local out = {}
    if not d then return out end
    for dk, day in pairs(d.days or {}) do
        if (day.online or 0) >= self.RHYTHM_MIN_ONLINE then out[dk] = true end
    end
    for _, t in ipairs(type(d.logins) == "table" and d.logins or {}) do out[DayKey(t)] = true end
    return out
end

-- Rückgabe: { mode, basis ("gelernt"/"eingestellt"/"ohne Daten"), days = Tage bis zum nächsten Login, share = Anteil des
-- Wochentags (gelernt), span = Tage mit Daten, perWeek = gespielte Tage je Woche (gelernt) }
function Act:Rhythm(now)
    now = now or self.Clock()
    local mode = self:RhythmMode()
    local today = DayKey(now)
    if mode == "daily" then return { mode = mode, basis = "eingestellt", days = 1 } end
    if mode == "some" then return { mode = mode, basis = "eingestellt", days = 2 } end
    if mode == "weekend" then                                   -- nächster Samstag oder Sonntag ab morgen
        local k = 1
        for i = 1, 7 do
            local w = WDay(today + i * 86400 + 43200)
            if w == 7 or w == 1 then k = i; break end
        end
        return { mode = mode, basis = "eingestellt", days = k }
    end
    local played = self:PlayedDays()
    local first
    for dk in pairs(played) do if dk < today and (not first or dk < first) then first = dk end end
    local from = math.max(first or today, today - self.RHYTHM_WINDOW * 86400)
    local span = math.floor((today - from) / 86400 + 0.5)
    if not first or span < self.RHYTHM_MIN_SPAN then
        return { mode = mode, basis = "ohne Daten", days = 1, span = span }
    end
    local seen, hit, nPlayed = {}, {}, 0
    for dk = from, today - 86400, 86400 do
        local key = DayKey(dk + 43200)                          -- Sommerzeit: Tagesbeginn neu bestimmen
        local w = WDay(key + 43200)
        seen[w] = (seen[w] or 0) + 1
        if played[key] then hit[w] = (hit[w] or 0) + 1; nPlayed = nPlayed + 1 end
    end
    local best, bestK, bestShare = nil, 1, -1
    for k = 1, 7 do
        local w = WDay(today + k * 86400 + 43200)
        local share = (seen[w] or 0) > 0 and (hit[w] or 0) / seen[w] or 0
        if share >= 0.5 and not best then best = k end
        if share > bestShare then bestK, bestShare = k, share end
    end
    local k = best or bestK
    local w = WDay(today + k * 86400 + 43200)
    local share = (seen[w] or 0) > 0 and (hit[w] or 0) / seen[w] or 0
    return { mode = mode, basis = "gelernt", days = k, share = share, span = span, perWeek = nPlayed / span * 7 }
end

-- MR8 (Antwort Supervisor 21:02, F4): wie lange spielt der Spieler heute voraussichtlich noch? Nur mit GELERNTEM Rhythmus.
-- Übliche Spielzeit dieses Wochentags = Median der Login-Uhrzeit (Logins an diesem Wochentag, sonst alle) + Median der Online-
-- Zeit an gespielten Tagen dieses Wochentags (sonst aller Tage). Rückgabe: Sekunden bis zum üblichen Ende (kann ≤ 0 sein),
-- Rhythmus. nil = ohne Rhythmus-Daten (dann keine Vorwahl).
local function Median(t)
    if #t == 0 then return nil end
    table.sort(t)
    local m = math.floor((#t + 1) / 2)
    return (#t % 2 == 1) and t[m] or (t[m] + t[m + 1]) / 2
end
function Act:SessionLeft(now)
    now = now or self.Clock()
    local r = self:Rhythm(now)
    if r.basis ~= "gelernt" then return nil, r end
    local d = DB()
    local today = DayKey(now)
    local wd = WDay(now)
    local from = today - self.RHYTHM_WINDOW * 86400
    local startsW, startsAll = {}, {}
    for _, t in ipairs((d and type(d.logins) == "table" and d.logins) or {}) do
        if t >= from and t < today then
            local sec = t - DayKey(t)
            startsAll[#startsAll + 1] = sec
            if WDay(t) == wd then startsW[#startsW + 1] = sec end
        end
    end
    local onW, onAll = {}, {}
    for dk, day in pairs((d and d.days) or {}) do
        if dk >= from and dk < today and (day.online or 0) >= self.RHYTHM_MIN_ONLINE then
            onAll[#onAll + 1] = day.online
            if WDay(dk + 43200) == wd then onW[#onW + 1] = day.online end
        end
    end
    local start = Median(#startsW > 0 and startsW or startsAll)
    local len = Median(#onW > 0 and onW or onAll)
    if not (start and len) then return nil, r end
    return today + start + len - now, r
end

-- kurzer Text für den Kopf: "Nächstes Login ~1 Tag (gelernt)"
function Act:RhythmText(now)
    local r = self:Rhythm(now)
    local when = (r.days == 1) and L["~1 Tag"] or string.format(L["~%d Tage"], r.days)
    local basis = (r.basis == "gelernt" and L["gelernt"]) or (r.basis == "eingestellt" and L["selbst eingestellt"]) or L["ohne Daten"]
    return string.format(L["Nächstes Login %s (%s)"], when, basis), r
end

-- ------------------------------------------------------------
-- MR5 "Seit deinem letzten Besuch" (anweisung-markt-reiter Teil B): nach > 24 Std. Pause beim ersten Öffnen von AHSentinel
-- eine Übersicht: verkauft (Post-Rechnungen seither), zurück (Auktionen, deren Laufzeit seither endete, nicht ganz verkauft),
-- Bänder seither (Zustand der Stufenbänder damals -> jetzt), nächste Schritte mit Knopf. Ausblendbar (settings.sinceHidden).
-- "Zuletzt gesehen" = letzte Online-Minute bzw. Ausloggen (lastSeen); beim Login wird der alte Wert gemerkt (prevSeen).
-- ------------------------------------------------------------
Act.SINCE_PAUSE = 86400
function Act:MarkSeen(t)
    local d = DB()
    if d then d.lastSeen = t or self.Clock() end
end
function Act:OnLogin(t)
    local d = DB()
    if not d then return end
    t = t or self.Clock()
    self.prevSeen, self.loginAt, self.sinceShown = d.lastSeen, t, nil
    d.lastSeen = t
    -- MR7 (Supervisor 21:48): Vorhersage "nächstes Login in k Tagen" gegen das wirkliche Login mitschreiben (je Tag einmal)
    local p = d.lastPred
    local today = DayKey(t)
    if type(p) == "table" and p.t and DayKey(p.t) < today then
        local actual = math.floor((today - DayKey(p.t)) / 86400 + 0.5)
        d.rhythmLog = type(d.rhythmLog) == "table" and d.rhythmLog or {}
        table.insert(d.rhythmLog, { p.t, p.days, actual, p.basis })
        while #d.rhythmLog > 120 do table.remove(d.rhythmLog, 1) end
    end
    if not (type(p) == "table" and p.t and DayKey(p.t) == today) then
        local okR, r = pcall(self.Rhythm, self, t)
        if okR and r then d.lastPred = { t = t, days = r.days, basis = r.basis } end
    end
end
-- Trefferquote je Woche: { {Woche, richtig, n}, ... } (nur gelernte Vorhersagen), neueste zuletzt
function Act:RhythmHits(log)
    local d = DB()
    log = log or (d and d.rhythmLog) or {}
    local by, order = {}, {}
    for _, e in ipairs(log) do
        if e[4] == "gelernt" then
            local wk = date("%Y-%W", e[1])
            if not by[wk] then by[wk] = { wk, 0, 0 }; order[#order + 1] = wk end
            by[wk][3] = by[wk][3] + 1
            if e[2] == e[3] then by[wk][2] = by[wk][2] + 1 end
        end
    end
    table.sort(order)
    local out = {}
    for _, wk in ipairs(order) do out[#out + 1] = by[wk] end
    return out
end

function Act:SinceLastVisit(now)
    now = now or self.Clock()
    local prev = self.prevSeen
    if not prev or (self.loginAt or now) - prev < self.SINCE_PAUSE then return nil end
    local out = { pause = (self.loginAt or now) - prev, from = prev, soldQty = 0, soldGold = 0, soldItems = 0, back = 0, bands = {} }
    -- verkauft: Rechnungen (Buchhaltung, Verkauf aus der Post) mit Zeitpunkt seit dem letzten Besuch
    local items = {}
    for _, e in ipairs((A.db and A.db.ledger and A.db.ledger.entries) or {}) do
        if e.kind == "sale" and (e.t or 0) >= prev then
            out.soldQty = out.soldQty + (e.qty or 0)
            out.soldGold = out.soldGold + (e.amount or 0) - (e.cut or 0)
            if e.itemID and not items[e.itemID] then items[e.itemID] = true; out.soldItems = out.soldItems + 1 end
        end
    end
    -- zurück: eigene Einstellungen, deren Laufzeit seither endete und die nicht ganz verkauft (oder abgebrochen) sind
    local Fc = A.Forecast
    local f = Fc and Fc.Store and Fc:Store()
    for _, str in ipairs((f and f.list) or {}) do
        if str:sub(1, 1) == "P" then
            local e = Fc:Decode(str)
            local stop = e and (e.t or 0) + (e.d or 24) * 3600
            if e and stop > prev and stop <= now and e.r ~= "s" and e.r ~= "c" then
                local left = (e.q or 1) - (e.sq or 0)
                if left > 0 then out.back = out.back + left end
            end
        end
    end
    -- Bänder: Zustand beim letzten Besuch -> jetzt (nur geänderte)
    local W = A.Waves
    if W and W.States then
        local okA, a = pcall(W.States, W, prev)
        local okB, b = pcall(W.States, W, now)
        if okA and okB then
            local old = {}
            for _, x in ipairs(a) do old[x.key] = x.state end
            for _, x in ipairs(b) do
                if old[x.key] and old[x.key] ~= x.state then out.bands[#out.bands + 1] = { key = x.key, from = old[x.key], to = x.state } end
            end
        end
    end
    -- Briefkasten seit dem Login noch nicht geöffnet -> Rechnungen fehlen noch
    local B = A.Books
    local snap = A.db and A.db.inboxSnap and B and B.CharKey and A.db.inboxSnap[B:CharKey()]
    out.mailPending = not (snap and (snap.t or 0) >= (self.loginAt or now))
    return out
end

function Act:Prune()
    local d = DB()
    if not d then return end
    local limit = DayKey(self.Clock() - self.KEEP_DAYS * 86400)
    for dk in pairs(d.days) do if dk < limit then d.days[dk] = nil end end
    while #d.crafts > 1000 do table.remove(d.crafts, 1) end
end

-- ------------------------------------------------------------
-- Herstellen merken: { t, itemID, cost (je Stück, wenn bekannt) }
-- ------------------------------------------------------------
function Act:NoteCraft(itemID, cost, t)
    local d = DB()
    if not (d and itemID) then return end
    d.crafts[#d.crafts + 1] = { t = t or self.Clock(), itemID = itemID, cost = cost }
end

-- LANG-3/E1 (T279 Activity:Report 201–242 ms im Nachbau mit echten Daten, API.GoldPerHour im Spiel 75–489 ms): der Bericht darf
-- in Portionen abgeben - aber NUR in der Coroutine der eigenen Aufgabe (Act.pauseCo; nie über ein pcall eines anderen Aufrufers,
-- Lua 5.1). Ausserhalb dieser Aufgabe rechnet er wie bisher am Stück.
local pauseN = 0
local function MaybePause()
    pauseN = pauseN + 1
    if pauseN >= 100 and Act.pauseCo and Act.pauseCo == coroutine.running() then
        pauseN = 0
        A:Pause()
    end
end

local function LastBefore(list, t)
    local best
    for _, e in ipairs(list) do
        if e.t <= t and (not best or e.t > best.t) then best = e end
    end
    return best
end

-- ------------------------------------------------------------
-- H7: Rendite je Geschäftsart im Zeitraum ab from
-- Rückgabe: rows = { flip, craft, de, raw } je { invested, revenue, profit, roi, gross }, total
-- ------------------------------------------------------------
Act.KINDS = { "flip", "craft", "de", "raw", "other" }
-- AHS-BH-REN2 Teil 2 (Entscheid Supervisor 28.11. 07:16 nach buchhaltung.md: Haupt-Zahl = REALISIERT, Entzaubern = Umbuchung der Kostenbasis,
-- unrealisiert nur als Zusatz): die Rendite je Geschäftsart kommt aus DENSELBEN Buchungen wie die Kopfzeile (Books.lua BK:Summary) -
-- je Verkauf Erlös nach Gebühr (rev) und Kostenbasis (cost, beim Entzaubern der umgebuchte Einstand), Art = Buchung bt (de/flip/craft;
-- Händlerware/gemischt/unbekannt -> "other"), Stücke ohne Einkauf -> "raw" (Kostenbasis 0). Verfallene Einzahlungen -> "other" (eingesetzt),
-- Entzauber-Ausbeute (Glück/Pech) -> "de". Summe aller Arten = Kopfzeile auf den Kupfer. Noch nicht verkaufte Materialien sind NICHT
-- im Gewinn (rows.de.stockQ / stockValue als Zusatz: Lager aus Entzaubern, unrealisiert).
Act.BT_KIND = { de = "de", flip = "flip", craft = "craft" }
function Act:BusinessBooks(periodKey)
    local BK = A.Books
    local db = BK and BK.Data and BK:Data()
    if not (db and db.log and BK.PeriodStart) then return nil end
    local from = BK:PeriodStart(periodKey or "all")
    local rows = {}
    for _, k in ipairs(self.KINDS) do rows[k] = { kind = k, invested = 0, revenue = 0, profit = 0, gross = 0 } end
    for i, e in ipairs(db.log) do
        if i % 200 == 0 then MaybePause() end
        if (e.t or 0) >= from then
            if e.k == "sale" and e.st ~= "p" and e.st ~= "x" then
                local q = math.max(1, e.q or 1)
                local rev, cost, gross = e.rev or 0, e.cost or 0, e.gross or (e.rev or 0)
                local freeRev, freeGross = 0, 0
                if (e.free or 0) > 0 then
                    freeRev = math.floor(rev * e.free / q + 0.5)
                    freeGross = math.floor(gross * e.free / q + 0.5)
                end
                local r = rows.raw
                r.revenue, r.gross = r.revenue + freeRev, r.gross + freeGross
                local k = self.BT_KIND[e.bt or ""] or "other"
                r = rows[k]
                r.revenue, r.invested, r.gross = r.revenue + rev - freeRev, r.invested + cost, r.gross + gross - freeGross
            elseif e.k == "dey" then
                rows.de.revenue = rows.de.revenue + (e.amt or 0)
            end
        end
    end
    local okD, forfeit = pcall(BK.DepositStatus, BK, db, from, Now and Now() or time())
    if okD and type(forfeit) == "number" and forfeit ~= 0 then
        rows.other.invested = rows.other.invested + forfeit
        rows.other.forfeit = forfeit
    end
    return rows, from
end
-- AHS-BH-REN2 Zusatz (Entscheid Supervisor 07:16/08:10): Lager aus Entzaubern, noch nicht verkauft (unrealisiert, nicht im Gewinn):
-- Stück, umgebuchter Einstand und Wert jetzt (Materialpreis nach Gebühr) aus der Kostenbasis der Buchhaltung (cb, Art "de")
function Act:DEStock()
    local BK = A.Books
    local db = BK and BK.Data and BK:Data()
    if not (db and db.cb) then return nil end
    local D = A.Disenchant
    local q, cost, value = 0, 0, 0
    for _, items in pairs(db.cb) do
        for id, p in pairs(items) do
            MaybePause()
            if type(p) == "table" and p.bt == "de" and (p.q or 0) > 0 then
                q, cost = q + p.q, cost + (p.c or 0)
                local mp = D and D.MatPrice and D:MatPrice(id) or nil
                if mp then
                    local fee = A.FeePerPiece and A:FeePerPiece(id, mp) or 0
                    value = value + math.max(0, mp - fee) * p.q
                end
            end
        end
    end
    return { kind = "stock", q = q, invested = cost, revenue = math.floor(value + 0.5), profit = math.floor(value + 0.5) - cost }
end
function Act:Business(from, periodKey)
    -- AHS-BH-REN2 Teil 2: mit Buchhaltung (Books) dieselbe Rechnung wie die Kopfzeile
    -- Act.forceLedger: alter Weg ohne Buchhaltung (nur Tests T263/T264, Rückfall wenn Books fehlt)
    local bRows = not self.forceLedger and self:BusinessBooks(periodKey)
    if bRows then
        local total = { kind = "total", invested = 0, revenue = 0, profit = 0, gross = 0 }
        for _, k in ipairs(self.KINDS) do
            local r = bRows[k]
            r.profit = r.revenue - r.invested
            r.roi = r.invested > 0 and (r.profit / r.invested * 100) or nil
            total.invested, total.revenue, total.gross = total.invested + r.invested, total.revenue + r.revenue, total.gross + r.gross
        end
        total.profit = total.revenue - total.invested
        -- AHS-BH-REN (Entscheid Supervisor 08:10): EINE Formel wie die Kopfzeile (Books.lua BK:Summary s.roi = s.boughtProfit / s.cost):
        -- (Gewinn − Erlös ohne Einkauf) / Kostenbasis der Verkäufe (ohne verfallene Einzahlungen)
        local cost = total.invested - ((bRows.other and bRows.other.forfeit) or 0)
        total.cost, total.freeRev = cost, bRows.raw.revenue
        total.roi = cost > 0 and ((total.profit - bRows.raw.revenue) / cost * 100) or nil
        local okS, st = pcall(self.DEStock, self)
        if okS and st and st.q > 0 then bRows.stock = st end
        return bRows, total
    end
    from = from or 0
    local Le = A.Ledger
    local db = A.db and A.db.ledger
    local rows = {}
    for _, k in ipairs(self.KINDS) do rows[k] = { kind = k, invested = 0, revenue = 0, profit = 0, gross = 0 } end
    if not (Le and db) then return rows, { kind = "total", invested = 0, revenue = 0, profit = 0, gross = 0 } end
    local d = DB() or { crafts = {} }
    -- Material aus Entzauberungen: sein Verkauf ist schon im Materialwert der Abrechnung enthalten
    local deMat = {}
    for _, e in ipairs(A.db.deLog or {}) do
        MaybePause()
        for _, m in ipairs(e.loot or {}) do if m[1] then deMat[m[1]] = true end end
    end
    local byItem = {}
    for _, e in ipairs(db.entries or {}) do
        MaybePause()
        if e.itemID and (e.kind == "buy" or e.kind == "sale" or e.kind == "deposit" or e.kind == "refund") then
            local b = byItem[e.itemID]
            if not b then b = { buys = {}, sales = {}, deps = {}, crafts = {} }; byItem[e.itemID] = b end
            if e.kind == "buy" then b.buys[#b.buys + 1] = e
            elseif e.kind == "sale" then b.sales[#b.sales + 1] = e
            else b.deps[#b.deps + 1] = e end
        end
    end
    for _, c in ipairs(d.crafts) do
        local b = byItem[c.itemID]
        if b then b.crafts[#b.crafts + 1] = c end
    end
    local Se = A.Seller
    for itemID, b in pairs(byItem) do
        for _, s in ipairs(b.sales) do
            MaybePause()
            local st = Le.SaleTime and Le:SaleTime(s) or s.t
            local craft = LastBefore(b.crafts, st)
            local buy = LastBefore(b.buys, st)
            local kind, when, unitCost
            if craft and (not buy or craft.t >= buy.t) then
                kind, when = "craft", craft.t
                unitCost = craft.cost
                if not unitCost and Se and Se.CostPerPiece then
                    local ok, c = pcall(Se.CostPerPiece, Se, itemID)
                    unitCost = ok and c or nil
                end
            elseif buy then
                kind, when = "flip", buy.t
                local qty, cost = 0, 0
                for _, x in ipairs(b.buys) do
                    if x.t <= st and st - x.t <= 30 * 86400 then qty = qty + (x.qty or 0); cost = cost + (x.amount or 0) end
                end
                unitCost = qty > 0 and cost / qty or nil
            elseif deMat[itemID] then
                kind = nil
            else
                kind, when = "raw", st
            end
            if kind and when >= from then
                local r = rows[kind]
                local net = (s.amount or 0) - (s.cut or 0)
                local cost = math.floor((unitCost or 0) * (s.qty or 1) + 0.5)
                r.revenue = r.revenue + net
                r.gross = r.gross + (s.amount or 0)
                r.invested = r.invested + cost
            end
        end
        -- verlorene Einzahlungen (Einzahlungen ohne Erstattung) dem Geschäft des Items zuordnen
        local kindOf = (#b.crafts > 0 and "craft") or (#b.buys > 0 and #b.sales > 0 and "flip") or (not deMat[itemID] and "raw") or nil
        if kindOf then
            local fee = 0
            for _, x in ipairs(b.deps) do
                if x.t >= from then fee = fee + (x.kind == "deposit" and (x.amount or 0) or -(x.amount or 0)) end
            end
            for _, s in ipairs(b.sales) do if s.t >= from then fee = fee - (s.refund or 0) end end
            if fee > 0 then rows[kindOf].invested = rows[kindOf].invested + fee end
        end
    end
    -- Entzaubern: vorhandene Abrechnung (Zeitraum als Wert, nicht über self: ein pausierter Bericht und ein anderer am Stück
    -- dürfen sich nicht stören)
    local key = periodKey or self.periodKey
    if Le.DisenchantReport then
        local ok, _, t
        if Act.pauseCo and Act.pauseCo == coroutine.running() then
            -- in der eigenen Aufgabe: mit Abgabe (A:PCall erlaubt Pausen; Le.pauseCo = genau diese innere Coroutine)
            ok, _, t = A:PCall(function()
                Le.pauseCo = coroutine.running()
                local r1, r2 = Le:DisenchantReport(key)
                Le.pauseCo = nil
                return r1, r2
            end)
            Le.pauseCo = nil
        else
            ok, _, t = pcall(Le.DisenchantReport, Le, key)
        end
        if ok and t then
            rows.de.invested = t.spent or 0
            rows.de.revenue = (t.value or 0) + (t.ownValue or 0)
            rows.de.gross = rows.de.revenue
        end
    end
    local total = { kind = "total", invested = 0, revenue = 0, profit = 0, gross = 0 }
    for _, k in ipairs(self.KINDS) do
        local r = rows[k]
        r.profit = r.revenue - r.invested
        r.roi = r.invested > 0 and (r.profit / r.invested * 100) or nil
        total.invested, total.revenue, total.gross = total.invested + r.invested, total.revenue + r.revenue, total.gross + r.gross
    end
    total.profit = total.revenue - total.invested
    total.roi = total.invested > 0 and (total.profit / total.invested * 100) or nil
    return rows, total
end

-- ------------------------------------------------------------
-- H9: Gold pro Stunde je Geschäftsart. Zeit: Herstellen = craft, Entzaubern = de; AH-Arbeit und Briefkasten werden
-- nach dem Brutto-Erlös auf Flippen, Herstellen und Rohstoffe verteilt (ohne Erlös: alles zu Flippen/Rohstoffe gleich).
-- ------------------------------------------------------------
function Act:Report(periodKey)
    local Le = A.Ledger
    local from = (Le and Le.PeriodStart) and Le:PeriodStart(periodKey) or 0
    local rows, total = self:Business(from, periodKey)
    local sec = self:Seconds(from)
    local shared = (sec.ah or 0) + (sec.mail or 0)
    local grossSum = rows.flip.gross + rows.craft.gross + rows.raw.gross + (rows.other and rows.other.gross or 0)
    for _, k in ipairs({ "flip", "craft", "raw", "other" }) do
        local share = grossSum > 0 and (rows[k].gross / grossSum) or ((k == "flip" or k == "raw") and 0.5 or 0)
        rows[k].seconds = shared * share
    end
    rows.craft.seconds = rows.craft.seconds + (sec.craft or 0)
    rows.de.seconds = sec.de or 0
    total.seconds = shared + (sec.craft or 0) + (sec.de or 0)
    for _, k in ipairs(self.KINDS) do
        local r = rows[k]
        r.perHour = (r.seconds or 0) >= self.MIN_SECONDS and (r.profit / r.seconds * 3600) or nil
    end
    total.perHour = total.seconds >= self.MIN_SECONDS and (total.profit / total.seconds * 3600) or nil
    return rows, total
end

-- LANG-3/E1: Bericht je Zeitraum gemerkt, solange dieselben Buchungen gelten (Liste, Länge, letzter Eintrag, Herstellen,
-- Entzauber-Protokoll) und höchstens REPORT_KEEP s alt (die gemessene Spielzeit läuft weiter). Neu gerechnet als Hintergrund-
-- Aufgabe "act:report:<Zeitraum>" in Portionen; bis dahin der letzte Bericht mit seiner Stand-Zeit.
-- Rückgabe: rows, total, Stand-Zeit (time()), aktuell (true/false) - oder nil, solange noch nie gerechnet (Aufgabe angestossen).
-- Ohne Hintergrund-Aufgaben (A.Job fehlt): am Stück wie bisher. Fertig -> Ereignis ACT_REPORT_READY(Zeitraum).
Act.REPORT_KEEP = 60
Act.reports = {}
function Act:LedgerKey()
    local led = A.db and A.db.ledger and A.db.ledger.entries
    local d = A.db and A.db.activity
    return table.concat({ tostring(led), led and #led or 0, tostring(led and led[#led] or "-"),
        d and d.crafts and #d.crafts or 0, A.db and A.db.deLog and #A.db.deLog or 0 }, "|")
end
function Act:CachedReport(periodKey)
    periodKey = periodKey or "all"
    local key = self:LedgerKey()
    local c = self.reports[periodKey]
    if c and c.key == key and time() - c.t <= self.REPORT_KEEP then return c.rows, c.total, c.t, true end
    if not (A.Job and A.HasJob and A.PCall) then
        local rows, total = self:Report(periodKey)
        self.reports[periodKey] = { rows = rows, total = total, t = time(), key = key }
        return rows, total, time(), true
    end
    local name = "act:report:" .. periodKey
    if not A:HasJob(name) then
        A:Job(name, function()
            local k0, t0 = Act:LedgerKey(), time()
            local ok, rows, total = A:PCall(function()
                Act.pauseCo = coroutine.running()
                return Act:Report(periodKey)
            end)
            Act.pauseCo = nil
            if ok and rows then
                Act.reports[periodKey] = { rows = rows, total = total, t = t0, key = k0 }
                A:Fire("ACT_REPORT_READY", periodKey)
            end
        end)
    end
    if c then return c.rows, c.total, c.t, false end
    return nil
end

-- "1g 20s/Std." bzw. rot "-30s/Std."; unter 15 Min. grau "zu wenig Daten"
function Act:PerHourText(r)
    if not r or not r.perHour then return "|cff888888" .. L["zu wenig Daten"] .. "|r" end
    local v = math.floor(math.abs(r.perHour) + 0.5)
    local s = A:FormatMoney(v) .. L["/Std."]
    if r.perHour < 0 then return "|cffff5544-" .. s .. "|r" end
    return s
end

function Act:DurationText(sec)
    sec = math.floor((sec or 0) + 0.5)
    local h, m = math.floor(sec / 3600), math.floor((sec % 3600) / 60)
    if h > 0 then return string.format(L["%d Std. %d Min."], h, m) end
    return string.format(L["%d Min."], m)
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
local evt = CreateFrame("Frame")
Act.evt = evt
for _, e in ipairs({ "GLOBAL_MOUSE_DOWN", "PLAYER_FLAGS_CHANGED", "MAIL_SHOW", "MAIL_CLOSED", "UNIT_SPELLCAST_SUCCEEDED",
                     "PLAYER_LOGOUT" }) do
    pcall(evt.RegisterEvent, evt, e)
end

local function IsAFK()
    local f = A:Global("UnitIsAFK")
    local ok, v = pcall(function() return f and f("player") end)
    local G = _G.GoldSentinelGame
    if G and G.IsSecret and G.IsSecret(v) then return false end
    return ok and v and true or false
end

-- Während der Testroutine keine echten Ereignisse mitschreiben (Sandbox, Befund 20:15 A2: activity.days)
local function Paused()
    local TR = A.TestRoutine
    return TR and TR.running and true or false
end
Act.Paused = Paused

-- eine Handlung des Spielers (Klick): zählt für das offene AH bzw. den offenen Briefkasten
function Act:PlayerAction()
    if Paused() then return end
    if A.IsAHOpen and A:IsAHOpen() then self:Touch("ah") end
    if self.mailOpen then self:Touch("mail") end
end

-- Herstellen: Produkt über den Rezeptnamen im gemerkten Rezept-Stand (ohne neues Lesen)
local function CraftProduct(spellID)
    local gsi = A:Global("GetSpellInfo")
    local name = gsi and gsi(spellID)
    if not name then
        local CS = A:Global("C_Spell")
        local info = CS and CS.GetSpellInfo and CS.GetSpellInfo(spellID)
        name = info and info.name
    end
    local Cr = A.Crafting
    if not (name and Cr and Cr.RecipeByName) then return nil end
    local pid, rec = Cr:RecipeByName(name)               -- EK-1: auch ohne Zwischenspeicher (Fenster, gemerkte Rezepte)
    if not pid then return nil end
    local sum = 0
    for _, re in ipairs(rec.reagents or {}) do
        local u = Cr.BestUnit and Cr:BestUnit(re[1], 1)
        if not u then sum = nil; break end
        sum = sum + u * re[2]
    end
    return pid, sum and (sum / math.max(rec.made or 1, 1)) or nil, rec
end
Act.CraftProduct = CraftProduct

evt:SetScript("OnEvent", function(_, event, a1, a2, a3)
    local G = _G.GoldSentinelGame
    if G and G.AnySecret and G.AnySecret(a1, a3) then return end      -- geschützte Werte nie vergleichen
    if Paused() and event ~= "PLAYER_FLAGS_CHANGED" then return end
    if event == "GLOBAL_MOUSE_DOWN" then
        Act:PlayerAction()
    elseif event == "PLAYER_FLAGS_CHANGED" then
        if a1 == "player" then Act:SetAFK(IsAFK()) end
    elseif event == "MAIL_SHOW" then
        Act.mailOpen = true
        Act:Touch("mail")
    elseif event == "MAIL_CLOSED" then
        Act.mailOpen = nil
        Act:Stop("mail")
    elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
        if a1 ~= "player" then return end
        local P = A.Spieltest
        local ok, isCraft = pcall(function() return P and P.IsCraftSpell and P:IsCraftSpell(a3) end)
        if not (ok and isCraft) then return end
        -- SK1-M2 (Ingametest 18.11. 09:29: "Herstellen ohne Rezept: Zauber 836 (?)" 17× und "3909 (?)" 3×, genau beim Einloggen/
        -- Neuladen und zum Start der Testroutine von ProfessionSentinel): Herstellen gibt es nur bei offenem Berufsfenster (oder bis
        -- 30 s nach dem Schliessen, laufende Serie). Während ProfessionSentinelAPI.TestRunning() ist alles Testgeschehen -> nichts buchen.
        local Cr = A.Crafting
        local winOK = not Cr or Cr.tsOpen or (Cr.tsCloseAt and GetTime() - Cr.tsCloseAt < 30)
        if not winOK then return end
        local PSA = A:Global("ProfessionSentinelAPI")
        local okT, psTest = pcall(function() return type(PSA) == "table" and type(PSA.TestRunning) == "function" and PSA.TestRunning() end)
        if okT and psTest then return end
        Act:Touch("craft")
        if a3 == 13262 then return end                     -- TB168-5: Entzaubern (13262) ist kein Herstellen
        local okP, pid, cost, rec = pcall(CraftProduct, a3)
        -- SK1-m (EK-1): jedes erkannte Herstellen muss gebucht werden können (Rezept gefunden)
        if A.SelfCheck and A.SelfCheck.Note then
            -- SK1-M2: Name auch im modernen Client (C_Spell.GetSpellName; GetSpellInfo gibt es dort nicht mehr -> bisher "?")
            local gsi, CS = A:Global("GetSpellInfo"), A:Global("C_Spell")
            local okN, sname = pcall(function()
                local nm = gsi and gsi(a3)
                if not nm and type(CS) == "table" and CS.GetSpellName then nm = CS.GetSpellName(a3) end
                return nm
            end)
            pcall(A.SelfCheck.Note, A.SelfCheck, "m", okP and pid ~= nil and rec ~= nil, string.format("Herstellen ohne Rezept: Zauber %s (%s)", tostring(a3), tostring(okN and sname or "?")))
        end
        if okP and pid then
            Act:NoteCraft(pid, cost)
            -- EB4-2: Herstellen sofort buchen (Zutaten aus dem Lager -> Kosten des Produkts), vor jedem Lager-Abgleich
            if rec then A:Fire("CRAFT_DONE", pid, math.max(1, math.floor((rec.made or 1) + 0.5)), rec.reagents) end
        end
    elseif event == "PLAYER_LOGOUT" then
        Act:Stop("ah"); Act:Stop("mail")
        pcall(Act.Prune, Act)
    end
end)

A:On("AH_STATE", function()
    if Paused() then return end
    if A:IsAHOpen() then
        Act:Touch("ah")
        pcall(Act.RaidHint, Act)
    else
        Act:Stop("ah")
    end
end)

-- ------------------------------------------------------------
-- H8: Hinweis vor dem Raid-Start 9.12.2026 (Onyxia, Hyjal-Gipfel, Barrow Deeps; Regelwerk Abschnitt 9,
-- shared/wissen/wirtschaft-forever.md). Ab 25.11. höchstens einmal am Tag beim Öffnen des AH, nach dem 9.12. aus.
-- ------------------------------------------------------------
Act.RAID_DATE = { year = 2026, month = 12, day = 9 }
Act.RAID_HINT_FROM = { year = 2026, month = 11, day = 25 }
function Act:RaidHint(now)
    if not (A.IsForever and A:IsForever()) then return false end
    now = now or self.Clock()
    -- feste Zeitpunkte (UTC 00:00; ohne time(tabelle)): 25.11.2026 = 1795564800, 9.12.2026 = 1796774400
    local from = self.RAID_HINT_FROM_T or 1795564800
    local till = self.RAID_DATE_T or 1796774400
    if now < from or now >= till then return false end
    local d = DB()
    local dk = DayKey(now)
    if not d or d.raidHintDay == dk then return false end
    d.raidHintDay = dk
    -- ST1 E) (27.11.): Tipp nur EINMAL (vorher einmal am Tag)
    return A:PrintOnce("raidStart1209", L["Raid-Start 9.12.: Verbrauchsgüter und ihre Kräuter jetzt günstig einkaufen/herstellen."])
end
