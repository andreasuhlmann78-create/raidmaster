if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - SelfCheck.lua (SK1, Entscheid des Nutzers 14.11. 11:23: "AHS soll selbst prüfen, ob es stimmt")
-- Passive Selbstkontrolle bei echten Ereignissen: jede Buchung und Anzeige gegen die Wirklichkeit (Gold, Taschen,
-- Server-Antwort). Keine Aktion, nichts kaufen. Je Kontrolle nur Zähler (Fälle, stimmig, Abweichung) und die letzten
-- 20 Abweichungen als Zahlen (ohne Namen). Nie während der Testroutine in echte Daten (eigene Tests mit SC.testDB).
--   a Händler: Gold-Änderung je Besuch = Händler-Buchungen (HB1-3)
--   b Post: Post-Geld je Briefkasten-Sitzung = gebuchte Erlöse (+ erstattete Anzahlung, A7 - wird gemessen)
--   c AH: Gold-Änderung je AH-Sitzung = gebuchte Käufe + Anzahlungen
--   d Handel mit Spielern: Gold-Änderung = gebuchter Betrag (EB5)
--   e Tagesbilanz: Geldfluss gemessen vs. gebucht je Tag (TB138-2), grün ≤ 1 %
--   f Lager: Lager je Item = Taschen + Bank + Briefkasten + Auktionen (nach dem Abgleich)
--   g Verkaufen-Fenster: nach jedem Klick Titel = gewähltes Item, Liste = letzte Server-Antwort (UI-V1/V1b)
--   h Vollscan: Speicher vorher/nachher, Bereinigungen, längste Lücke je Scan (letzte 5), zweiter Scan nicht über dem ersten
--   i Anzeige: Gewinn-Kopf = Details = Summe der Liste (eine Zahl je Sache)
-- ============================================================
local A = AHAnalyzerPro
if not (A and A.On) then return end
local L = A.L
local SC = {}
A.SelfCheck = SC

SC.KINDS = { "a", "b", "c", "d", "e", "f", "g", "h", "i" }
SC.NAMES = { a = "Händler", b = "Post", c = "Auktionshaus", d = "Handel mit Spielern", e = "Tagesbilanz", f = "Lager",
    g = "Verkaufen-Fenster", h = "Vollscan", i = "Anzeige" }
SC.EX_MAX, SC.TOL = 20, 1                          -- Beispiele je Kontrolle; Toleranz in Kupfer (Rundung)

function SC:Store()
    if self.testDB then return self.testDB end
    if A.InTestRoutine and A:InTestRoutine() then return nil end
    local db = A.db
    if not db then return nil end
    if type(db.selfcheck) ~= "table" then db.selfcheck = { v = 1, k = {}, scans = {}, since = time() } end
    db.selfcheck.k, db.selfcheck.scans = db.selfcheck.k or {}, db.selfcheck.scans or {}
    return db.selfcheck
end
-- nur lesen (auch während der Testroutine: Zähler aus dem echten Spiel anzeigen)
function SC:Data()
    if self.testDB then return self.testDB end
    return A.db and type(A.db.selfcheck) == "table" and A.db.selfcheck or nil
end
function SC.NewDB() return { v = 1, k = {}, scans = {}, since = time() } end
-- ein Fall: ok = stimmig; text = Zahlen der Abweichung
function SC:Note(kind, ok, text, t)
    local st = self:Store()
    if not st then return end
    local k = st.k[kind]
    if not k then k = { n = 0, ok = 0, bad = 0, ex = {} }; st.k[kind] = k end
    k.n = k.n + 1
    if ok then k.ok = k.ok + 1
    else
        k.bad = k.bad + 1
        table.insert(k.ex, string.format("%s %s", date("%d.%m. %H:%M", t or time()), tostring(text or "")))
        while #k.ex > self.EX_MAX do table.remove(k.ex, 1) end
    end
    k.last = t or time()
end
function SC:Get(kind)
    local st = self:Data()
    return st and st.k[kind] or { n = 0, ok = 0, bad = 0, ex = {} }
end

-- ------------------------------------------------------------
-- b/c: Sitzungen (Briefkasten, Auktionshaus): gemessenes Gold am Ort gegen Buchungen in der Sitzung
-- ------------------------------------------------------------
SC.sess = {}
function SC:SessionStart(kind)
    if not self:Store() then return end
    self.sess[kind] = { t0 = time(), sum = 0, take = {}, takeSum = 0, unbooked = 0 }
end
-- SK1-B1: Post - jedes genommene Geld (bzw. bezahlte Nachnahme) mit seiner Art; booked = false: Verkaufs-Rechnung ohne
-- gebuchten Verkauf
function SC:OnMailTake(kind, amount, booked)
    local s = self.sess.b
    if not s then return end
    s.take[kind] = (s.take[kind] or 0) + amount
    s.takeSum = s.takeSum + amount
    if booked == false then s.unbooked = s.unbooked + 1 end
end
-- vom Geldfluss (Books OnMoney) je Änderung am Ort aufgerufen
function SC:OnFlow(ctx, d)
    local kind = (ctx == "post" and "b") or (ctx == "ah" and "c") or nil
    local s = kind and self.sess[kind]
    if s then s.sum = s.sum + d end
end
-- gebuchter Geldfluss einer Figur in [t0, t1]: Post (Erlöse am Tag der Rechnung ti, erstattete Anzahlungen gemessen
-- nicht gebucht) bzw. AH (Käufe aus dem AH, Anzahlungen)
function SC:Booked(kind, t0, t1)
    local BK = A.Books
    local db = BK and BK:Data()
    if not db then return 0 end
    local ch = BK:CharKey()
    local sum = 0
    -- Supervisor 12:55: nicht nach Zeit abbrechen (ein alter Eintrag dazwischen beendete die Suche zu früh) -
    -- höchstens die letzten 500 Einträge (wie OnTakeMoney)
    for i = #db.log, math.max(1, #db.log - 500), -1 do
        local e = db.log[i]
        local t = (e.k == "sale" and (e.tm or e.ti or e.t)) or e.t or 0     -- NP152-2: Abholzeit
        if e.ch == ch and t >= t0 and t <= t1 then
            if kind == "b" then
                if e.k == "sale" and e.st == "c" and not e.via then sum = sum + (e.rev or 0) + (e.dr or 0) end   -- A7
            elseif kind == "c" then
                if e.k == "buy" and not e.src then sum = sum - (e.cost or 0)
                elseif e.k == "fee" then sum = sum - (e.fee or 0) end
            end
        end
    end
    return sum
end
function SC:SessionEnd(kind)
    local s = self.sess[kind]
    self.sess[kind] = nil
    if not s then return end
    if kind == "b" then
        -- SK1-B1: gemessenes Gold am Briefkasten = Summe der genommenen Post (nach Art); dazu jede Verkaufs-Rechnung gebucht
        if s.sum == 0 and s.takeSum == 0 then return end
        local parts = {}
        for k, v in pairs(s.take) do parts[#parts + 1] = string.format("%s %+d", k, v) end
        table.sort(parts)
        local diff = s.sum - s.takeSum
        local ok = math.abs(diff) <= self.TOL and s.unbooked == 0
        self:Note("b", ok, string.format("Gold %+d · genommen %+d (%s) · ungeklärt %+d%s", s.sum, s.takeSum, table.concat(parts, ", "), diff,
            s.unbooked > 0 and string.format(" · %d Verkaufs-Rechnung(en) ohne Buchung", s.unbooked) or ""))
        return ok, s.sum, s.takeSum
    end
    if s.sum == 0 and self:Booked(kind, s.t0, time()) == 0 then return end
    local booked = self:Booked(kind, s.t0, time() + 1)
    local diff = s.sum - booked
    local ok = math.abs(diff) <= self.TOL
    self:Note(kind, ok, string.format("Gold %+d · gebucht %+d · Differenz %+d", s.sum, booked, diff))
    return ok, s.sum, booked
end

-- ------------------------------------------------------------
-- a/d: Händler-Besuch und Handel (von Books aufgerufen)
-- ------------------------------------------------------------
function SC:OnMerchantVisit(change, booked, rest)
    if change == 0 and booked == 0 then return end
    self:Note("a", math.abs(rest or 0) <= self.TOL, string.format("Gold %+d · gebucht %+d · Rest %+d", change or 0, booked or 0, rest or 0))
end
function SC:OnTrade(dm, booked, kind)
    if (dm or 0) == 0 and (booked or 0) == 0 then return end
    self:Note("d", math.abs((dm or 0) - (booked or 0)) <= self.TOL, string.format("Gold %+d · gebucht %+d (%s)", dm or 0, booked or 0, tostring(kind)))
end

-- ------------------------------------------------------------
-- g: Verkaufen-Fenster nach einem Klick
-- ------------------------------------------------------------
function SC:OnSellClick(p, itemID)
    if not (p and itemID) then return end
    local want = A:GetItemName(itemID)
    local title = p.title and p.title.GetText and p.title:GetText()
    local okTitle = p.selected == itemID and (not want or title == want)
    -- Liste = letzte Server-Antwort (oder grau "wird aktualisiert", solange die neue Suche aussteht)
    local Se = A.Seller
    local pr = Se and Se.GetPriceInfo and Se:GetPriceInfo(itemID)
    local shown = p.listings and p.listings.items
    local okList = true
    local firstTxt = ""
    if pr and pr.listings and shown and not p.stale then
        local n, first = 0, nil
        for _, l in ipairs(pr.listings) do if not l.bait then n = n + 1; first = first or l end end
        okList = #shown == n or #shown == #pr.listings
        -- SK1-B3 ("1:1 wie im AH"): günstigster Preis und Stückzahl der ersten Zeile = letzte Server-Antwort
        local s1 = shown[1]
        if okList and first and type(s1) == "table" then
            local pS, pA = s1.price or s1.unitPrice, first.price or first.unitPrice
            local qS, qA = s1.qty or s1.quantity, first.qty or first.quantity
            if pS ~= pA or qS ~= qA then okList = false end
            firstTxt = string.format(" · erste Zeile %s×%s / Server %s×%s", tostring(qS), tostring(pS), tostring(qA), tostring(pA))
        end
    end
    self:Note("g", okTitle and okList, string.format("Item %s · gewählt %s · Titel %s · Liste %s/%s%s", tostring(itemID), tostring(p.selected),
        okTitle and "ok" or "falsch", shown and #shown or "-", pr and pr.listings and #pr.listings or "-", firstTxt))
end

-- ------------------------------------------------------------
-- h: Vollscan (nach jeder Messung, ohne /ahs testroutine tempo)
-- ------------------------------------------------------------
SC.SCAN_GROW_KB = 10240
function SC:OnScan(m)
    local st = self:Store()
    if not (st and m and m.memAfter) then return end
    local prev = st.scans[#st.scans]
    local rec = { t = time(), before = math.floor(m.memBefore or 0), after = math.floor(m.memAfter or 0), gc = m.gcN or 0, gap = math.floor(m.gapMax or 0), n = m.auctions or 0 }
    table.insert(st.scans, rec)
    while #st.scans > 5 do table.remove(st.scans, 1) end
    if prev and time() - (prev.t or 0) < 6 * 3600 then
        local grow = rec.after - prev.after
        self:Note("h", grow <= self.SCAN_GROW_KB, string.format("Speicher nach dem Scan %d KB (vorher %d KB, %+d KB) · Bereinigungen %d · Lücke %d ms",
            rec.after, prev.after, grow, rec.gc, rec.gap))
    end
end

-- ------------------------------------------------------------
-- e/f/i: beim Testbericht bzw. Öffnen der Buchhaltung gerechnet (keine Kosten beim Spielen)
-- ------------------------------------------------------------
function SC:CheckDays()
    local BK = A.Books
    if not (BK and BK.FlowGaps) then return 0, 0, {} end
    local list = BK:FlowGaps()
    local ok, bad, ex = 0, 0, {}
    for _, g in ipairs(list) do
        local lim = math.max(100, (math.abs(g.trade) + math.abs(g.booked)) / 2 * 0.01)
        if math.abs(g.gap) <= lim then ok = ok + 1
        else
            bad = bad + 1
            if #ex < 3 then ex[#ex + 1] = string.format("%s: Handel %+d · gebucht %+d · Lücke %+d", date("%d.%m.", g.day), g.trade, g.booked, g.gap) end
        end
    end
    return ok, bad, ex
end
function SC:CheckStock(max)
    local BK = A.Books
    local db = BK and BK:Data()
    if not (db and BK.HaveCount) then return 0, 0, {} end
    local _, _, bankKnown = BK:Snapshot()
    if not bankKnown then return 0, 0, {}, "Bank unbekannt" end
    local ch = BK:CharKey()
    local ok, bad, ex, n = 0, 0, {}, 0
    for id, p in pairs(db.cb[ch] or {}) do
        if type(p) == "table" and (p.q or 0) > 0 then
            n = n + 1
            if n > (max or 200) then break end
            local have = BK:HaveCount(id)
            if have == p.q then ok = ok + 1
            else
                bad = bad + 1
                if #ex < 3 then ex[#ex + 1] = string.format("Item %d: Lager %d · vorhanden %d", id, p.q, have) end
            end
        end
    end
    return ok, bad, ex
end
function SC:CheckDisplay(key)
    local BK = A.Books
    if not BK then return true, "-" end
    key = key or "all"
    local s = BK:Summary(key)
    local d = BK:Details(key)
    local sumList = 0
    for _, r in ipairs(BK:ByItem(key, true)) do sumList = sumList + (r.profit or 0) end
    local listTrade = s.rev - s.cost
    local ok = d.profit == s.profit and sumList == listTrade
    return ok, string.format("Kopf %+d · Details %+d · Liste %+d (Handel vor Gebühren %+d)", s.profit, d.profit or 0, sumList, listTrade)
end

-- Testbericht-Abschnitt SELBSTKONTROLLE; zurück: Anzahl roter Kontrollen
function SC:ReportLines(out, fields)
    local st = self:Data()
    out[#out + 1] = "SELBSTKONTROLLE (SK1, passiv im Spiel)" .. (st and st.since and (" seit " .. date("%d.%m. %H:%M", st.since)) or "")
    local red = 0
    local function line(kind, n, ok, bad, ex, extra)
        local col = bad > 0 and "FEHLER" or (n > 0 and "stimmig" or "noch keine Fälle")
        if bad > 0 then red = red + 1 end
        out[#out + 1] = string.format("  SK1-%s %s: %d Fälle · %d stimmig · %d Abweichungen · %s%s", kind, self.NAMES[kind], n, ok, bad, col, extra or "")
        for i = math.max(1, #ex - 2), #ex do if ex[i] then out[#out + 1] = "    " .. ex[i] end end
        if fields then fields["sk1_" .. kind] = string.format("%d/%d/%d", n, ok, bad) end
    end
    for _, kind in ipairs({ "a", "b", "c", "d" }) do
        local k = self:Get(kind)
        line(kind, k.n, k.ok, k.bad, k.ex)
    end
    local okE, badE, exE = self:CheckDays()
    line("e", okE + badE, okE, badE, exE)
    local okF, badF, exF, whyF = self:CheckStock()
    line("f", okF + badF, okF, badF, exF, whyF and (" (" .. whyF .. ")") or "")
    local kg = self:Get("g")
    line("g", kg.n, kg.ok, kg.bad, kg.ex)
    local kh = self:Get("h")
    local scans = {}
    for _, s in ipairs(st and st.scans or {}) do scans[#scans + 1] = string.format("%s %d->%d KB GC %d Lücke %d ms", date("%H:%M", s.t), s.before, s.after, s.gc, s.gap) end
    line("h", kh.n, kh.ok, kh.bad, kh.ex, #scans > 0 and (" · letzte Scans: " .. table.concat(scans, " | ")) or "")
    local okI, txtI = self:CheckDisplay("all")
    line("i", 1, okI and 1 or 0, okI and 0 or 1, okI and {} or { txtI }, " · " .. txtI)
    return red
end
-- für das Details-Fenster: nur wenn etwas rot ist
function SC:RedCount()
    local red = 0
    for _, kind in ipairs({ "a", "b", "c", "d", "g", "h" }) do if self:Get(kind).bad > 0 then red = red + 1 end end
    return red
end

-- Sitzungs-Ereignisse
do
    local f = CreateFrame("Frame")
    for _, e in ipairs({ "MAIL_SHOW", "MAIL_CLOSED", "AUCTION_HOUSE_SHOW", "AUCTION_HOUSE_CLOSED" }) do pcall(f.RegisterEvent, f, e) end
    f:SetScript("OnEvent", function(_, event)
        local kind = (event == "MAIL_SHOW" or event == "MAIL_CLOSED") and "b" or "c"
        if event == "MAIL_SHOW" or event == "AUCTION_HOUSE_SHOW" then
            if not SC.sess[kind] then SC:SessionStart(kind) end
        elseif SC.sess[kind] then
            -- Gold und Buchungen kommen kurz nach dem Schliessen: 2 s warten
            local s = SC.sess[kind]
            if C_Timer and C_Timer.After then C_Timer.After(2, function() if SC.sess[kind] == s then pcall(SC.SessionEnd, SC, kind) end end)
            else pcall(SC.SessionEnd, SC, kind) end
        end
    end)
end
