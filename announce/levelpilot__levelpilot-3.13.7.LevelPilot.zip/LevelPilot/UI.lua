-- LevelPilot - Hauptfenster
-- Kopf mit EP-Balken, geplante Schritte, Statusleiste (Haltbarkeit, Taschen, Munition),
-- Hinweis-Einblendungen, Minimap-Button.

local _, LP = ...
local L = LP.L
local UI = {}
LP:RegisterModule("UI", UI)

------------------------------------------------------------------------
-- 3.12.18: eigene Tooltips nie ueber den eigenen Knoepfen. Der Tooltip steht neben dem Fenster, zu dem der Knopf
-- gehoert (rechts, sonst links, sonst darunter), auf Hoehe des Knopfs. Das Spiel haelt ihn im Bildschirm.
------------------------------------------------------------------------
UI.TIP_GAP = 4
UI.TIP_WIDTH = 280          -- so viel Platz (Bildschirmpunkte) braucht ein Tooltip neben dem Fenster

-- oberstes eigenes Fenster eines Knopfs (direkt unter UIParent)
function UI.WindowOf(owner)
    local f, guard = owner, 0
    while f and f.GetParent and guard < 20 do
        local p = f:GetParent()
        if not p or p == UIParent then return f end
        f, guard = p, guard + 1
    end
    return owner
end

-- Rueckgabe: Seite ("RIGHT", "LEFT", "BELOW") und Hoehenversatz; reine Rechnung (Testroutine T240)
function UI.TipSide(winLeft, winRight, winTop, winBottom, ownerTop, screenW, tipW)
    if not (winLeft and winRight and winTop and screenW) then return nil end
    local dy = ownerTop and (ownerTop - winTop) or 0
    if screenW - winRight >= tipW then return "RIGHT", dy end
    if winLeft >= tipW then return "LEFT", dy end
    return "BELOW", 0
end

function UI.TipAnchor(owner, tip)
    tip = tip or GameTooltip
    local win = UI.WindowOf(owner)
    local ok = pcall(function()
        local es, ues = win:GetEffectiveScale(), UIParent:GetEffectiveScale()
        local f = es / ues
        local side, dy = UI.TipSide(win:GetLeft() * f, win:GetRight() * f, win:GetTop() * f, win:GetBottom() * f,
            owner:GetTop() and owner:GetTop() * owner:GetEffectiveScale() / ues, UIParent:GetWidth(), UI.TIP_WIDTH)
        if not side then error("keine Lage") end
        tip:SetOwner(owner, "ANCHOR_NONE")
        tip:ClearAllPoints()
        dy = (dy or 0) * ues / tip:GetEffectiveScale()     -- Versatz in Einheiten des Tooltips
        if side == "RIGHT" then tip:SetPoint("TOPLEFT", win, "TOPRIGHT", UI.TIP_GAP, dy)
        elseif side == "LEFT" then tip:SetPoint("TOPRIGHT", win, "TOPLEFT", -UI.TIP_GAP, dy)
        else tip:SetPoint("TOP", win, "BOTTOM", 0, -UI.TIP_GAP) end
        UI.lastTipSide = side
    end)
    if not ok then tip:SetOwner(owner, "ANCHOR_CURSOR") UI.lastTipSide = "CURSOR" end
end

local C = LP.colors
local WHITE = "Interface\\Buttons\\WHITE8X8"
local BACKDROP_TEMPLATE = BackdropTemplateMixin and "BackdropTemplate" or nil

local WIDTH   = 350          -- Standardbreite
local MIN_W, MAX_W = 260, 900
local MIN_H, MAX_H = 150, 1000
local MAX_ROWS = 15
local HEADER  = 93           -- wird an die Textlaenge angepasst (Layout)
local STATUS  = 26           -- wird an die Textlaenge angepasst (Layout)
local STATUS_MIN = 26
local GAP     = 3
local MIN_ROW = 30

------------------------------------------------------------------------
-- Styling-Helfer
------------------------------------------------------------------------
function UI:Skin(f, bg, border)
    if not f.SetBackdrop then Mixin(f, BackdropTemplateMixin) end
    f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
    bg = bg or C.bg
    border = border or C.border
    f:SetBackdropColor(bg[1], bg[2], bg[3], bg[4] or 1)
    f:SetBackdropBorderColor(border[1], border[2], border[3], border[4] or 1)
end

-- alle Texte und Knoepfe von LevelPilot: beim Sprachwechsel sofort neu beschriften (ohne /reload)
UI.texts = {}           -- Texte werden im Spiel nie freigegeben, daher feste Liste
UI.buttons = {}

function UI:Text(parent, size, color, flags)
    local fs = parent:CreateFontString(nil, "OVERLAY")
    UI.texts[fs] = true
    LP:RegisterText(fs)
    fs:SetFont(LP.FONT, size or 12, flags or "")
    color = color or C.text
    fs:SetTextColor(color[1], color[2], color[3])
    fs:SetJustifyH("LEFT")
    fs:SetJustifyV("TOP")
    fs:SetWordWrap(true)
    return fs
end

-- Beschriftung in den Knopf einpassen: bei langen Woertern (andere Sprachen) kleinere Schrift statt "..."
function UI.FitLabel(b)
    local fs = b and b.label
    if not (fs and fs.GetStringWidth and fs.SetFont) then return end
    local w = (b:GetWidth() or 0) - 8
    if w <= 0 then return end
    local font = rawget(b, "fontPath") or LP.FONT
    for size = 11, 7, -1 do
        pcall(fs.SetFont, fs, font, size, "")
        if (fs:GetStringWidth() or 0) <= w then return end
    end
end

function UI:Button(parent, label, w, h, onClick, tooltip)
    local b = CreateFrame("Button", nil, parent, BACKDROP_TEMPLATE)
    b:SetSize(w or 24, h or 20)
    UI:Skin(b, C.row, C.border)
    local fs = UI:Text(b, 11, C.text)
    fs:SetPoint("CENTER")
    fs:SetJustifyH("CENTER")
    fs:SetJustifyV("MIDDLE")
    fs:SetText(label)
    b.label = fs
    b.tip = tooltip
    UI.buttons[b] = true
    UI.FitLabel(b)
    b:SetScript("OnEnter", function(self)
        self:SetBackdropBorderColor(C.accent[1], C.accent[2], C.accent[3], 1)
        local tip = (rawget(self, "tipFn") and self.tipFn()) or rawget(self, "tip")
        if tip then
            UI.TipAnchor(self)
            GameTooltip:AddLine(tip, 1, 1, 1, true)
            GameTooltip:Show()
        end
    end)
    b:SetScript("OnLeave", function(self)
        self:SetBackdropBorderColor(C.border[1], C.border[2], C.border[3], 1)
        GameTooltip:Hide()
    end)
    b:SetScript("OnClick", onClick)
    return b
end

function UI:Gradient(tex)
    tex:SetTexture(WHITE)
    if tex.SetGradient and CreateColor then
        local ok = pcall(tex.SetGradient, tex, "HORIZONTAL",
            CreateColor(C.accent[1], C.accent[2], C.accent[3], 1),
            CreateColor(C.accent2[1], C.accent2[2], C.accent2[3], 1))
        if ok then return end
    end
    if tex.SetGradientAlpha then
        pcall(tex.SetGradientAlpha, tex, "HORIZONTAL",
            C.accent[1], C.accent[2], C.accent[3], 1, C.accent2[1], C.accent2[2], C.accent2[3], 1)
    else
        tex:SetVertexColor(C.accent[1], C.accent[2], C.accent[3])
    end
end

------------------------------------------------------------------------
-- Schritt-Texte
------------------------------------------------------------------------
local ICONS = {
    ACCEPT   = "Interface\\GossipFrame\\AvailableQuestIcon",
    TURNIN   = "Interface\\GossipFrame\\ActiveQuestIcon",
    COMPLETE = "Interface\\Icons\\INV_Sword_04",
    GOTO     = "Interface\\Icons\\INV_Misc_Map_01",
    FLY      = "Interface\\Minimap\\Tracking\\FlightMaster",
    FP       = "Interface\\Minimap\\Tracking\\FlightMaster",
    LEVEL    = "Interface\\Icons\\Spell_ChargePositive",
    NOTE     = "Interface\\Icons\\INV_Misc_Note_01",
    DUNGEON  = "Interface\\Icons\\INV_Misc_Key_03",
    HEARTH   = "Interface\\Icons\\INV_Misc_Rune_01",
    BIND     = "Interface\\Icons\\INV_Misc_Rune_01",
}

local LABELS = {
    ACCEPT   = "|cffffd24aAnnehmen|r",
    TURNIN   = "|cff3dd694Abgeben|r",
    COMPLETE = "|cffffa040Erledigen|r",
    GOTO     = "|cffffb238Gehe zu|r",
    FLY      = "|cff7fc8ffFliegen nach|r",
    FP       = "|cff7fc8ffFlugpunkt|r",
    LEVEL    = "|cff4ddb80Level|r",
    NOTE     = "",
    DUNGEON  = "|cffc890ffDungeon|r",
    HEARTH   = "|cff7fc8ffRuhestein|r",
    BIND     = "|cff7fc8ffRuhestein binden|r",
}

local MUTED = "|cff9c9ea6"

local function LevelTag(level)
    if not level or level <= 0 then return "" end
    -- Classic-Regeln, bezogen auf LP:PlayerLevel() (bei der virtuellen Reise das Level der Reise)
    local me = LP:PlayerLevel()
    local d = level - me
    local hex
    if d >= 5 then hex = "ff1919"            -- rot
    elseif d >= 3 then hex = "ff8040"        -- orange
    elseif d >= -2 then hex = "ffff00"       -- gelb
    elseif -d <= (LP.API.GreenRange and LP.API.GreenRange(me) or 5) then hex = "40c040"   -- gruen
    else hex = "808080" end                  -- grau
    return " |cff" .. hex .. "[" .. level .. "]|r"
end

-- 3.13.7 LP-M2: EINE Entfernung je Schritt. Kopfzeile und Reisezeile ("Reise ~0:05: 35 Yards laufen") nehmen beide diese Zahl.
local function StepDist(step, current)
    local d
    -- aktueller Schritt: ueberall die Weglaenge (wie am Pfeil), nicht die Luftlinie
    if not current and LP.Engine and LP.Engine:Current() == step then current = true end
    if current and LP.Nav then d = LP.Nav:RemainingDistance() end
    if not d and step.map and step.x then d = LP.Geo:DistToMapPoint(step.map, step.x, step.y) end
    return d
end
UI.StepDist = StepDist
local function DistText(step, current)
    local d = StepDist(step, current)
    if not d then return "" end
    return "  " .. MUTED .. LP:FormatDist(d) .. "|r"
end
-- Reisezeile: reiner Fussweg -> mit derselben Entfernung wie die Kopfzeile neu geschrieben (Zeit nur einmal); sonst der Reiseplan
function UI.NavLine(s, full)
    local p = s.navPlan
    if p and p.legs and #p.legs == 1 and p.legs[1].k == "walk" and LP.Planner and LP.Planner.PlanText then
        local d = StepDist(s, full)
        if d then return LP.Planner.PlanText(p, d) end
    end
    return s.navText
end

function UI:ShortLabel(step)
    if not step then return "" end
    if step.q then return step.q end
    local t = step.text or ""
    t = t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    t = t:match("^[^\n]*") or ""
    if #t > 50 then t = t:sub(1, 48) .. "…" end
    return t
end

function UI:StepText(s, full)
    local head = L[LABELS[s.t] or ""]
    local extra = {}
    if s.t == "ACCEPT" or s.t == "TURNIN" or s.t == "COMPLETE" then
        head = head .. ": " .. (s.q or (L["Quest "] .. (s.id or "?"))) .. LevelTag(s.level)
        if s.isNew and LP.db.showNewTag then head = head .. L[" |cffb48cff["] .. LP.L["NEU"] .. "]|r" end
        if s.shared and full then extra[#extra + 1] = "|cff7fc8ff" .. LP.L("Auch in der Gruppe (%d)", s.shared) .. "|r" end
        if s.classQuest and full and not LP.Planner:IsSpeed() then extra[#extra + 1] = "|cffffb238" .. LP.L["Klassenquest"] .. "|r" end
        if s.npc and s.t ~= "COMPLETE" then extra[#extra + 1] = L["bei "] .. s.npc end
        if s.map and s.map ~= select(4, LP.Geo:Player()) then extra[#extra + 1] = LP.Geo:MapName(s.map) end
        if s.t == "COMPLETE" and full then
            local st = LP.Planner.inLog[s.id]
            if st then
                local objs = LP.API.Objectives(st.index)
                local tr = LP.Names and LP.Names:ObjectiveTexts(s.id, objs) or {}
                for ci, ob in ipairs(objs) do
                    local text = tr[ci] or ob.text
                    if text then extra[#extra + 1] = (ob.finished and "|cff4ddb80" or "") .. text .. (ob.finished and "|r" or "") end
                end
            end
            if not s.map then extra[#extra + 1] = L["Ort unbekannt – Questbeschreibung lesen"] end
            if s.also then extra[#extra + 1] = "|cff7fc8ff" .. LP.L("Gleich dabei erledigen: %s", table.concat(s.also, ", ")) .. "|r" end
            local eta = full and LP.Session and LP.Session:EtaText(s)
            if eta then extra[#extra + 1] = "|cff9c9ea6" .. eta .. "|r" end
        end
        -- 3.13.7 LP-M1 (b): Annahme/Abgabe ohne Ort sagt es wie "Erledigen" (vorher: Zeile ohne Entfernung, Zone und Hinweis)
        if (s.t == "ACCEPT" or s.t == "TURNIN") and not s.map then extra[#extra + 1] = L["Ort unbekannt – Questbeschreibung lesen"]
        elseif s.t == "ACCEPT" and not s.npc and full then extra[#extra + 1] = L["Questgeber an dieser Stelle"] end
        if s.classQuest and full then extra[#extra + 1] = L["|cffffb238Klassenquest – auch im Speedrun|r"] end
    elseif s.t == "FLY" then
        head = head .. ": " .. (s.text or "?")
        if full then extra[#extra + 1] = L["Sprich mit dem Flugmeister"] end
    elseif s.t == "LEVEL" then
        head = head .. ": " .. (s.lvl or "?")
        if s.text then extra[#extra + 1] = s.text end
    elseif s.t == "HEARTH" then
        head = head .. ": " .. (s.text or "?")
        if full then extra[#extra + 1] = LP.L["Ruhestein benutzen (Knopf neben dem Fenster) – spart den langen Weg"] end
    elseif s.t == "BIND" then
        head = head .. ": " .. (s.text or "?")
        if full then
            if s.npc then extra[#extra + 1] = LP.L("bei %s", s.npc) end
            extra[#extra + 1] = LP.L["Viele Aufgaben in dieser Zone – hier binden spart später Wege"]
        end
    elseif s.t == "DUNGEON" then
        head = head .. ": " .. (s.q or "?")
        if s.min then head = head .. " " .. MUTED .. L["(Stufe "] .. s.min .. "–" .. (s.max or "?") .. ")|r" end
        if s.inside then
            extra[#extra + 1] = L["Du bist im Dungeon – die offenen Questziele stehen darunter."]
        else
            local list = s.quests or {}
            extra[#extra + 1] = #list .. (#list == 1 and L[" Quest: "] or L[" Quests: "]) .. table.concat(list, ", ")
            if full then
                extra[#extra + 1] = L["Am Eingang eine Gruppe suchen (5 Spieler)."]
                if s.urgent then extra[#extra + 1] = L["|cffffb238Jetzt ideal – die Quests werden bald grau.|r"] end
                if s.hostile then extra[#extra + 1] = L["Eingang im Gebiet der anderen Fraktion – Vorsicht."] end
                extra[#extra + 1] = L["Rechtsklick = zurückstellen"]
            end
        end
    else
        local first = (s.text or ""):match("^[^\n]*") or ""
        head = (head ~= "" and (head .. ": ") or "") .. first
        local rest = (s.text or ""):match("^[^\n]*\n(.+)$")
        if rest then extra[#extra + 1] = rest end
    end
    if full and s.navText then extra[#extra + 1] = UI.NavLine(s, full) end   -- 3.12.58 NAV-2 / 3.12.63 NAV-4 / 3.13.7 LP-M2
    if full and LP.db.safeMode and LP.Nav and LP.Nav.danger and s == LP.Engine:Current() then
        table.insert(extra, 1, "|cffff5555" .. LP.Nav.danger .. "|r")
    end
    local out = head .. DistText(s, full)
    if #extra > 0 then
        if full then
            out = out .. "\n" .. MUTED .. table.concat(extra, "\n") .. "|r"
        else
            out = out .. "\n" .. MUTED .. extra[1] .. "|r"
        end
    end
    return out
end

------------------------------------------------------------------------
-- Hauptfenster
------------------------------------------------------------------------
local frame, rows = nil, {}
UI.rows = rows        -- 3.12.33: Testroutine liest die Zeilen (nur lesen)

local function CreateRow(i)
    local r = CreateFrame("Button", nil, frame.body, BACKDROP_TEMPLATE)
    r:SetHeight(MIN_ROW)
    if i == 1 then
        r:SetPoint("TOPLEFT", frame.body, "TOPLEFT", 0, 0)
        r:SetPoint("TOPRIGHT", frame.body, "TOPRIGHT", 0, 0)
    else
        r:SetPoint("TOPLEFT", rows[i - 1], "BOTTOMLEFT", 0, -GAP)
        r:SetPoint("TOPRIGHT", rows[i - 1], "BOTTOMRIGHT", 0, -GAP)
    end
    UI:Skin(r, C.row, { 0, 0, 0, 0 })
    r:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    local bar = r:CreateTexture(nil, "ARTWORK")
    bar:SetTexture(WHITE)
    bar:SetWidth(3)
    bar:SetPoint("TOPLEFT")
    bar:SetPoint("BOTTOMLEFT")
    r.bar = bar

    local icon = r:CreateTexture(nil, "ARTWORK")
    icon:SetSize(18, 18)
    icon:SetPoint("TOPLEFT", 10, -7)
    r.icon = icon

    local text = UI:Text(r, 11, C.text)
    text:SetPoint("TOPLEFT", icon, "TOPRIGHT", 8, 0)
    text:SetWidth(math.max(MIN_W, math.min(MAX_W, LP.db.frameW or WIDTH)) - 70)
    text:SetSpacing(2)
    r.text = text

    r:SetScript("OnClick", function(self, btn)
        if btn == "RightButton" and self.step then
            UI:StepMenu(self, self.step)       -- Menue statt sofort ueberspringen (Bericht 3.9.0)
        end
    end)
    r:SetScript("OnEnter", function(self)
        if not self.step then return end
        UI.TipAnchor(self)
        GameTooltip:AddLine(UI:StepText(self.step, true), 1, 1, 1, true)
        -- 3.12.33 GR1-K: in der einen Zeile (kompakt/eingeklappt) die Questnamen von "Später abgeben"
        local note = rawget(self, "laterNote")
        if note then
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine(note.text, 1, 1, 1, true)
        end
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine(L["Rechtsklick: Menü (zurückstellen / Quest ignorieren)"], 0.6, 0.6, 0.65)
        GameTooltip:Show()
    end)
    r:SetScript("OnLeave", function() GameTooltip:Hide() end)
    rows[i] = r
    return r
end

local sizing = false

local function Width() return math.max(MIN_W, math.min(MAX_W, LP.db.frameW or WIDTH)) end
local function ManualHeight() return (not LP.char.collapsed) and LP.db.frameH or nil end

-- Anzahl Zeilen: eingeklappt 1, feste Hoehe = so viele wie passen (max. MAX_ROWS), sonst Einstellung
local function RowCount()
    if LP.char.collapsed or LP.db.compactMode then return 1 end
    if ManualHeight() or sizing then return MAX_ROWS end
    return LP.db.stepsShown
end

local function EnsureRows()
    local n = RowCount()
    for i = 1, math.max(n, #rows) do
        local r = rows[i] or CreateRow(i)
        if i <= n then r:Show() else r:Hide() end
    end
end

-- Kopf und Statusleiste der Textlaenge anpassen (lange Texte umbrechen statt abschneiden)
local function Layout()
    if not frame or not frame.xtext then return end
    local xh = math.max(10, math.ceil(frame.xtext:GetStringHeight() or 10))
    frame.xbg:ClearAllPoints()
    frame.xbg:SetPoint("TOPLEFT", 10, -(70 + xh + 3))
    frame.xbg:SetPoint("TOPRIGHT", -10, -(70 + xh + 3))
    HEADER = 70 + xh + 3 + 4 + 6
    frame.body:ClearAllPoints()
    frame.body:SetPoint("TOPLEFT", 6, -HEADER)
    frame.body:SetPoint("TOPRIGHT", -6, -HEADER)
    local st = frame.status
    st.text:SetHeight(0)                        -- ohne feste Hoehe misst das Spiel die echte Texthoehe
    local sh = math.max(STATUS_MIN - 4, math.ceil(st.text:GetStringHeight() or 0) + 6)
    st:SetHeight(sh)
    st.text:SetHeight(sh)
    STATUS = sh + 4
end
UI.Layout = Layout

-- Breitenabhaengige Elemente anpassen
local function ApplyWidth()
    local w = Width()
    frame:SetWidth(w)
    -- schmales Fenster: Spenden-Knopf nur als Muenze, damit nichts ueberdeckt wird
    local b = frame.bSupport
    if b then
        if w < 330 then b.label:Hide() b.coin:Show() b:SetWidth(20)
        else b.label:Show() b.coin:Hide() b:SetWidth(b.fullW) end
    end
    frame.title:SetWidth(w - 24)
    frame.xtext:SetWidth(w - 20)
    frame.status.text:SetWidth(w - 34)       -- Platz fuer den Groessen-Griff unten rechts
    if frame.status.text.SetWordWrap then frame.status.text:SetWordWrap(true) end
    for _, r in ipairs(rows) do r.text:SetWidth(w - 70) end
    Layout()
end

-- Statusleiste
local function CreateStatus()
    local s = CreateFrame("Button", nil, frame)
    s:SetHeight(STATUS - 4)
    s:SetPoint("BOTTOMLEFT", 8, 4)
    s:SetPoint("BOTTOMRIGHT", -8, 4)
    s.text = UI:Text(s, 10, C.muted)
    s.text:SetPoint("LEFT", 0, 0)
    s.text:SetJustifyV("MIDDLE")
    s.text:SetWidth(WIDTH - 16)
    s:SetScript("OnClick", function() LP.Center:Toggle("assist") end)
    s:SetScript("OnEnter", function(self)
        UI.TipAnchor(self)
        GameTooltip:AddLine(L["Assistent"])
        local hints = LP.Advisor and LP.Advisor.hints or {}
        if #hints == 0 then GameTooltip:AddLine(L["Alles in Ordnung."], 0.5, 0.9, 0.6) end
        for _, h in ipairs(hints) do
            local c = h.sev == 3 and C.bad or (h.sev == 2 and C.warn or C.muted)
            GameTooltip:AddLine(h.text, c[1], c[2], c[3], true)
        end
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine(L["Klick: Zentrale öffnen"], 0.6, 0.6, 0.65)
        GameTooltip:Show()
    end)
    s:SetScript("OnLeave", function() GameTooltip:Hide() end)
    frame.status = s
end

function UI:Init()
    frame = CreateFrame("Frame", "LevelPilotFrame", UIParent, BACKDROP_TEMPLATE)
    UI.frame = frame
    frame:SetWidth(Width())
    frame:SetHeight(220)
    frame:SetScale(LP.db.scale or 1)
    frame:SetResizable(true)
    if frame.SetResizeBounds then
        frame:SetResizeBounds(MIN_W, MIN_H, MAX_W, MAX_H)
    else
        if frame.SetMinResize then frame:SetMinResize(MIN_W, MIN_H) end
        if frame.SetMaxResize then frame:SetMaxResize(MAX_W, MAX_H) end
    end
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetFrameStrata("MEDIUM")
    UI:Skin(frame, C.bg, C.border)
    if LP.db.framePos then
        local p = LP.db.framePos
        frame:SetPoint(p[1], UIParent, p[2], p[3], p[4])
    else
        frame:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -40, -220)
    end
    frame:SetScript("OnDragStart", function(self) if not LP.db.locked then self:StartMoving() end end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        LP.db.framePos = { p, rp, x, y }
    end)

    -- Kopf: Marke links, Akzentstreifen links (Fraktionsfarbe)
    local side = frame:CreateTexture(nil, "ARTWORK")
    side:SetTexture(WHITE)
    side:SetWidth(2)
    side:SetPoint("TOPLEFT", 1, -1)
    side:SetPoint("BOTTOMLEFT", 1, 1)
    local fc = LP:PlayerFaction() == "Horde" and C.horde or C.alliance
    side:SetVertexColor(fc[1], fc[2], fc[3], 0.9)

    local brand = UI:Text(frame, 10, C.muted)
    brand:SetPoint("TOPLEFT", 12, -9)
    brand:SetText("|cffffb238LEVEL|r|cff3dd694PILOT|r")

    local title = UI:Text(frame, 14, C.text)
    title:SetPoint("TOPLEFT", 12, -28)      -- eigene Zeile unter den Knoepfen: nichts wird abgeschnitten
    title:SetWidth(WIDTH - 24)
    title:SetWordWrap(false)
    frame.title = title
    -- 3.13.7 LP-M3: Tooltip am Titel (wie das Gebiet gewählt wird). Eigene Fläche über dem Titel; Ziehen bewegt weiter das Fenster.
    local titleHit = CreateFrame("Frame", nil, frame)
    titleHit:SetPoint("TOPLEFT", title, "TOPLEFT", 0, 0)
    titleHit:SetSize(1, 16)                 -- Breite = Textbreite (UI:Refresh), damit die Knöpfe daneben frei bleiben
    titleHit:EnableMouse(true)
    if titleHit.RegisterForDrag then titleHit:RegisterForDrag("LeftButton") end
    titleHit:SetScript("OnDragStart", function() local h = frame:GetScript("OnDragStart") if h then h(frame) end end)
    titleHit:SetScript("OnDragStop", function() local h = frame:GetScript("OnDragStop") if h then h(frame) end end)
    titleHit:SetScript("OnEnter", function(self)
        local tip = UI.TitleTip()
        if not tip then return end
        UI.TipAnchor(self)
        GameTooltip:AddLine(tip, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    titleHit:SetScript("OnLeave", function() GameTooltip:Hide() end)
    frame.titleHit = titleHit

    local bClose = UI:Button(frame, "x", 20, 20, function() UI:Toggle() end, L["Ausblenden"])
    bClose:SetPoint("TOPRIGHT", -6, -6)
    local bCollapse = UI:Button(frame, "–", 20, 20, function()
        LP.char.collapsed = not LP.char.collapsed
        EnsureRows()
        UI:Refresh()
    end, L["Einklappen / Ausklappen"])
    bCollapse:SetPoint("RIGHT", bClose, "LEFT", -3, 0)
    local bCenter = UI:Button(frame, L["Zentrale"], 58, 20, function() LP.Center:Toggle() end, L["Route, Daten, Austausch, Assistent, Einstellungen"])
    bCenter:SetPoint("RIGHT", bCollapse, "LEFT", -3, 0)
    -- Spenden-Knopf (oeffnet nur auf Klick das Fenster mit dem PayPal-Link)
    local bSupport = LP.Donate.CreateButton(frame, 96, 20)
    bSupport:SetPoint("RIGHT", bCenter, "LEFT", -3, 0)
    local coin = bSupport:CreateTexture(nil, "OVERLAY")
    coin:SetSize(14, 14)
    coin:SetPoint("CENTER")
    coin:SetTexture("Interface\\Icons\\INV_Misc_Coin_01")
    coin:Hide()
    bSupport.coin, bSupport.fullW = coin, bSupport:GetWidth()
    frame.bSupport = bSupport
    -- Neu-planen-Knopf mit Pfeil-Grafik (das Zeichen ↻ fehlt in den Schriften des Spiels)
    local bPlan = UI:Button(frame, "", 20, 20, function() LP.Planner:Replan(true) end, L["Route neu planen"])
    bPlan:SetPoint("TOPRIGHT", -6, -46)
    local ptex = bPlan:CreateTexture(nil, "OVERLAY")
    ptex:SetSize(16, 16)
    ptex:SetPoint("CENTER")
    ptex:SetTexture("Interface\\Buttons\\UI-RotationRight-Button-Up")
    ptex:SetTexCoord(0.2, 0.8, 0.2, 0.8)
    local bSkip = UI:Button(frame, L["Überspringen"], 82, 20, function() LP.Engine:Skip() end, L["Aktuellen Schritt überspringen (Quest wird ignoriert)"])
    bSkip:SetPoint("RIGHT", bPlan, "LEFT", -3, 0)
    local bMode = UI:Button(frame, L["Normal"], 70, 20, function() LP.Planner:ToggleMode() end,
        L["Umschalten: Normal (alle passenden Quests) / Speedrun (nur Quests, die mehr bringen als Grinden – Klassenquests bleiben)"])
    bMode:SetPoint("RIGHT", bSkip, "LEFT", -3, 0)
    frame.bMode = bMode

    -- EP-Balken
    local xbg = frame:CreateTexture(nil, "ARTWORK")
    xbg:SetTexture(WHITE)
    xbg:SetVertexColor(1, 1, 1, 0.07)
    xbg:SetHeight(4)
    xbg:SetPoint("TOPLEFT", 10, -84)
    xbg:SetPoint("TOPRIGHT", -10, -84)
    local xfill = frame:CreateTexture(nil, "OVERLAY")
    xfill:SetHeight(4)
    xfill:SetPoint("TOPLEFT", xbg, "TOPLEFT")
    UI:Gradient(xfill)
    local xtext = UI:Text(frame, 9, C.muted)
    xtext:SetPoint("TOPLEFT", 10, -70)
    xtext:SetJustifyH("LEFT")
    if xtext.SetWordWrap then xtext:SetWordWrap(true) end
    frame.xbg, frame.xfill, frame.xtext = xbg, xfill, xtext

    local body = CreateFrame("Frame", nil, frame)
    body:SetPoint("TOPLEFT", 6, -HEADER)
    body:SetPoint("TOPRIGHT", -6, -HEADER)
    body:SetHeight(1)
    frame.body = body

    CreateStatus()
    EnsureRows()
    self:CreateSizeGrip()
    ApplyWidth()
    -- Strg + Mausrad: Gesamtgroesse (inkl. Schrift)
    frame:EnableMouseWheel(true)
    frame:SetScript("OnMouseWheel", function(_, delta)
        if not IsControlKeyDown() then return end
        local s = (LP.db.scale or 1) + delta * 0.05
        LP.db.scale = math.floor(math.max(0.6, math.min(1.6, s)) * 100 + 0.5) / 100
        UI:ApplySettings()
    end)
    self:CreateMinimapButton()
    self:CreateToasts()
    if LP.char.hidden then frame:Hide() end

    LP:Listen("PLAN_CHANGED", function() UI:Refresh() end)
    LP:Listen("TIMER_CHANGED", function() LP:Throttle("ui_timer", 2, function() UI:Refresh() end) end)
    LP:Listen("GROUP_CHANGED", function() LP:Throttle("ui_group", 1, function() UI:Refresh() end) end)
    LP:Listen("HINTS_CHANGED", function() UI:Refresh() end)
    LP:On("PLAYER_XP_UPDATE", function() UI:Refresh() end)
    LP:Ticker("ui", 1, function() UI:Refresh() end)
end

function UI:Toggle()
    if not frame then return end
    if frame:IsShown() then
        frame:Hide()
        LP.char.hidden = true
    else
        frame:Show()
        LP.char.hidden = false
        UI:Refresh()
    end
    if LP.Actions then LP.Actions:Update() end
end

function UI:IsShown()
    return frame and frame:IsShown() or false
end

------------------------------------------------------------------------
-- Groesse per Ziehgriff (unten rechts)
------------------------------------------------------------------------
function UI:CreateSizeGrip()
    local g = CreateFrame("Button", nil, frame)
    g:SetSize(16, 16)
    g:SetPoint("BOTTOMRIGHT", -2, 2)
    g:SetFrameLevel(frame:GetFrameLevel() + 10)
    g:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    g:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    g:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    g:RegisterForClicks("LeftButtonUp")
    g:SetScript("OnMouseDown", function(_, btn)
        if btn ~= "LeftButton" or LP.db.locked then return end
        sizing = true
        EnsureRows()
        frame:StartSizing("BOTTOMRIGHT")
    end)
    g:SetScript("OnMouseUp", function()
        if not sizing then return end
        frame:StopMovingOrSizing()
        sizing = false
        LP.db.frameW = math.floor(frame:GetWidth() + 0.5)
        if not LP.char.collapsed then LP.db.frameH = math.floor(frame:GetHeight() + 0.5) end
        local p, _, rp, x, y = frame:GetPoint()
        LP.db.framePos = { p, rp, x, y }
        EnsureRows()
        ApplyWidth()
        UI:Refresh()
    end)
    g:SetScript("OnDoubleClick", function()
        LP.db.frameW, LP.db.frameH = nil, nil
        EnsureRows()
        ApplyWidth()
        UI:Refresh()
        LP:Reply(L["Fenstergrösse zurückgesetzt (automatische Höhe)."])
    end)
    g:SetScript("OnEnter", function(self)
        UI.TipAnchor(self)
        GameTooltip:AddLine(L["Grösse ändern"], 1, 1, 1)
        GameTooltip:AddLine(L["Ziehen: Breite und Höhe"], 0.7, 0.7, 0.75)
        GameTooltip:AddLine(L["Doppelklick: automatische Grösse"], 0.7, 0.7, 0.75)
        GameTooltip:AddLine(L["Strg + Mausrad über dem Fenster: alles grösser/kleiner"], 0.7, 0.7, 0.75)
        GameTooltip:Show()
    end)
    g:SetScript("OnLeave", function() GameTooltip:Hide() end)
    frame:SetScript("OnSizeChanged", function()
        if sizing then
            LP.db.frameW = math.floor(frame:GetWidth() + 0.5)
            ApplyWidth()
            UI:Refresh()
        end
    end)
    frame.grip = g
end

function UI:ApplySettings()
    if not frame then return end
    frame:SetScale(LP.db.scale or 1)
    EnsureRows()
    ApplyWidth()
    if UI.mmButton then UI.mmButton:SetShown(LP.db.showMinimapBtn and true or false) end
    UI:Refresh()
    if LP.Nav then LP.Nav:Refresh() end
end

local function StatusText()
    local A = LP.Advisor
    if not A then return "" end
    local parts = {}
    if A.durability then
        local c = A.durability <= 10 and "ff4d4d" or (A.durability <= LP.db.durWarn and "ff8c33" or "9c9ea6")
        parts[#parts + 1] = "|cff" .. c .. L["Haltbarkeit "] .. math.floor(A.durability) .. "%|r"
    end
    if A.bagFree then
        local c = A.bagFree <= LP.db.bagWarn and "ff8c33" or "9c9ea6"
        parts[#parts + 1] = "|cff" .. c .. L["Taschen "] .. A.bagFree .. "/" .. (A.bagTotal or 0) .. L[" frei|r"]
    end
    if A.ammo then
        local c = A.ammo <= LP.db.ammoWarn and "ff8c33" or "9c9ea6"
        parts[#parts + 1] = "|cff" .. c .. L["Munition "] .. A.ammo .. "|r"
    end
    local n = #(A.hints or {})
    if n > 0 then parts[#parts + 1] = "|cffffb238" .. n .. (n > 1 and L[" Hinweise"] or L[" Hinweis"]) .. "|r" end
    local extra = LP.Session and LP.Session:ExtraText()
    if extra then parts[#parts + 1] = "|cff9c9ea6" .. extra .. "|r" end
    return table.concat(parts, "   ")
end

-- 3.13.7 LP-M3 (Befund 22.11.: Titel "Das Brachland", Spieler in Donnerfels): Der Titel ist das Gebiet, in dem LevelPilot plant
-- (Fokus-Zone), nicht der Ort des Spielers. Steht der Spieler nicht darin, heisst er "Ziel: <Zone>". Fehlerzustände unverändert.
-- st = Planer-Zustand, focus = Fokus-Zone, playerMap = Karte des Spielers. Liefert Titel und ob es ein Ziel ausserhalb ist.
function UI.TitleText(st, focus, playerMap)
    if st == "error" then return L["|cffff5555Fehler bei der Planung|r"]
    elseif st == "nodata" then return L["|cffff8c33Keine Questdaten|r"]
    elseif st == "noposition" then return L["|cffff8c33Position unbekannt|r"]
    elseif focus then
        local name = LP.Geo:MapName(focus)
        local Z = LP.Planner.ZoneOf
        if playerMap and Z(playerMap) == focus then return name, false end
        return L("Ziel: %s", name or "?"), true
    elseif st == "noquests" then return LP.Geo:MapName(playerMap)
    end
    return L["Route wird geplant …"]
end
-- Tooltip zum Titel: ein Satz, wie das Gebiet gewählt wird (nur mit Fokus-Zone)
function UI.TitleTip()
    if not LP.Planner.focus then return nil end
    if LP.char and LP.char.focusZone then
        return L["Levelgebiet: von dir in der Zentrale gewählt. „Automatisch“ in der Zentrale lässt LevelPilot wieder selbst wählen."]
    end
    return L["Levelgebiet: hier plant LevelPilot deine nächsten Quests. Automatisch gewählt: die Zone, in der du stehst, wenn dort Quests offen sind; sonst die bisherige Zone, bis sie fast leer ist; sonst die lohnendste Zone für deine Stufe (Wert der Quests und Weg dorthin). Ändern: Zentrale."]
end

function UI:Refresh()
    if not frame or not frame:IsShown() then return end
    local level = LP:PlayerLevel() or 1
    local focus = LP.Planner.focus
    local st = LP.Planner.state
    local title = UI.TitleText(st, focus, select(4, LP.Geo:Player()))
    frame.title:SetText(title)
    if frame.titleHit then
        local okW, w = pcall(frame.title.GetStringWidth, frame.title)
        frame.titleHit:SetWidth(math.max(1, math.min(okW and tonumber(w) or 1, WIDTH - 24)))
    end
    if LP.Planner:IsSpeed() then
        frame.bMode.label:SetText(L["|cffff7a3cSpeedrun|r"])
    else
        frame.bMode.label:SetText(L["Normal"])
    end

    local xp, xpMax = LP:PlayerXP()
    if LP.Virtual and LP.Virtual.active and LP.Virtual.s then xp, xpMax = LP.Virtual.s.xp, LP.Virtual.s.xpMax end
    local pct = xpMax > 0 and xp / xpMax or 0
    frame.xfill:SetWidth(math.max(0.1, frame.xbg:GetWidth() * pct))
    local active, ready = 0, 0
    for _, st in pairs(LP.Planner.inLog) do
        active = active + 1
        if st.complete then ready = ready + 1 end
    end
    local timer = LP.Comfort and LP.Comfort:TimerText()
    frame.xtext:SetText(L["Level "] .. level .. "  ·  " .. math.floor(pct * 100) .. L["% EP  ·  Questlog "]
        .. active .. "/" .. LP.API.MaxQuests() .. (ready > 0 and (L["  |cff3dd694("] .. ready .. L[" fertig)|r"]) or "")
        .. (timer and ("  ·  " .. timer) or ""))

    frame.status.text:SetText(StatusText())
    Layout()

    local steps = LP.Engine:Steps()
    local n = RowCount()
    -- 3.12.33 GR1-K: nur eine Zeile sichtbar -> Hinweis "Später abgeben" kurz an diese Zeile anhängen
    local laterNote
    if n == 1 then
        for k = 2, #steps do if steps[k].laterIds then laterNote = steps[k] break end end
    end
    local fixedH = sizing and frame:GetHeight() or ManualHeight()
    local room = fixedH and (fixedH - HEADER - STATUS - 8) or nil
    local used = 0
    for i = 1, n do
        local r = rows[i]
        local s = steps[i]
        if s then
            r.step = s
            r.icon:SetTexture(ICONS[s.t] or ICONS.NOTE)
            local later = (i == 1 and laterNote) and UI:LaterSuffix(laterNote) or ""
            if later ~= "" and LP.Pruefliste then LP.Pruefliste:Hit("GR1-K", ("+%d später abgeben"):format(#laterNote.laterIds)) end   -- Prüfliste
            r.laterNote = (i == 1) and laterNote or nil
            if LP.db.compactMode then
                -- eine Zeile: Schritt und Entfernung
                -- eine Zeile mit genau einer Entfernung (der des Weges, wie am Pfeil)
                r.text:SetText((UI:StepText(s, true):match("^[^\n]*") or "") .. later)
            else
                r.text:SetText(UI:StepText(s, i == 1) .. later)
            end
            if i == 1 then
                r:SetBackdropColor(C.rowCur[1], C.rowCur[2], C.rowCur[3], C.rowCur[4])
                r.bar:SetVertexColor(C.accent[1], C.accent[2], C.accent[3], 1)
                r:SetAlpha(1)
            else
                r:SetBackdropColor(C.row[1], C.row[2], C.row[3], C.row[4])
                r.bar:SetVertexColor(C.accent2[1], C.accent2[2], C.accent2[3], 0.35)
                r:SetAlpha(math.max(0.5, 1 - (i - 1) * 0.12))
            end
            r:SetHeight(math.max(MIN_ROW, r.text:GetStringHeight() + 14))
        elseif room and i > 1 then
            r.step = nil
            r:SetHeight(MIN_ROW)
        else
            r.step = nil
            r.icon:SetTexture(nil)
            r.bar:SetVertexColor(0, 0, 0, 0)
            r:SetBackdropColor(C.row[1], C.row[2], C.row[3], 0.35)
            r.text:SetText(i == 1 and L["Keine Schritte geplant."] or "")
            r:SetHeight(MIN_ROW)
        end
    end
    -- feste Hoehe: nur Zeilen zeigen, die vollstaendig hineinpassen
    if room then
        for i = 1, n do
            local r = rows[i]
            local need = r:GetHeight() + GAP
            if r.step and used + need <= room or i == 1 then
                r:Show()
                used = used + need
            else
                r:Hide()
                room = -1   -- alle folgenden ausblenden
            end
        end
        if not sizing then frame:SetHeight(math.max(MIN_H, fixedH)) end
    else
        local h = HEADER + STATUS + 8
        for i = 1, n do h = h + rows[i]:GetHeight() + GAP end
        frame:SetHeight(h)
    end
end

------------------------------------------------------------------------
-- Hinweis-Einblendungen (Toasts)
------------------------------------------------------------------------
local toasts = {}
local TOAST_MAX = 3

function UI:CreateToasts()
    local anchor = CreateFrame("Frame", "LevelPilotToasts", UIParent)
    anchor:SetSize(320, 10)
    anchor:SetPoint("TOP", UIParent, "TOP", 0, -260)
    self.toastAnchor = anchor
end

local function LayoutToasts()
    local y = 0
    for _, t in ipairs(toasts) do
        t:ClearAllPoints()
        t:SetPoint("TOP", UI.toastAnchor, "TOP", 0, -y)
        y = y + t:GetHeight() + 6
    end
end

local function RemoveToast(t)
    for i, x in ipairs(toasts) do
        if x == t then table.remove(toasts, i) break end
    end
    t:Hide()
    -- Einblendungen werden nicht wiederverwendet: Texte nicht mehr beim Sprachwechsel mitfuehren
    if rawget(t, "txt") then UI.texts[t.txt] = nil end
    LayoutToasts()
end

-- alle Einblendungen schliessen (z. B. nach einem Sprachwechsel – sie stehen noch in der alten Sprache)
function UI:ClearToasts()
    while #toasts > 0 do RemoveToast(toasts[1]) end
end

-- 3.12.33 GR1-K: kurzer Anhang fuer die eine sichtbare Zeile, z. B. " · +1 später abgeben" (grün)
function UI:LaterSuffix(note)
    local nIds = note and note.laterIds and #note.laterIds or 0
    if nIds == 0 then return "" end
    return "  ·  |cff3dd694" .. L("+%d später abgeben", nIds) .. "|r"
end

function UI:Toast(hint)
    if not self.toastAnchor then return end
    -- 3.12.31 ML1: "Meldungen" aus -> keine Toasts (ausser als Antwort auf eine eigene Handlung)
    if not LP:MessagesOn() and not LP:InReply() then
        LP.msgStats.suppressed = LP.msgStats.suppressed + 1
        return
    end
    if #toasts >= TOAST_MAX then RemoveToast(toasts[1]) end
    local t = CreateFrame("Button", nil, self.toastAnchor, BACKDROP_TEMPLATE)
    t:SetWidth(320)
    UI:Skin(t, C.panel, hint.sev == 3 and C.bad or (hint.sev == 2 and C.warn or C.border))
    local txt = UI:Text(t, 11, C.text)
    t.txt = txt
    txt:SetPoint("TOPLEFT", 10, -8)
    txt:SetWidth(hint.action2 and 200 or (hint.action and 220 or 290))
    txt:SetText(hint.text)
    local h = math.max(34, txt:GetStringHeight() + 16)
    t:SetHeight(h)
    if hint.action then
        local b = UI:Button(t, hint.actionLabel or L["Los"], hint.action2 and 96 or 76, 22, function()
            hint.action()
            RemoveToast(t)
        end)
        if hint.action2 then b:SetPoint("TOPRIGHT", -8, -6) else b:SetPoint("RIGHT", -8, 0) end
        t.actBtn = b
    end
    if hint.action2 then
        -- zweiter Knopf (z. B. "Später erinnern")
        local b2 = UI:Button(t, hint.action2Label or L["Los"], 96, 22, function()
            hint.action2()
            RemoveToast(t)
        end)
        b2:SetPoint("BOTTOMRIGHT", -8, 6)
        t:SetHeight(math.max(h, 62))
    end
    -- 3.13.0 (Auftrag 19.11. 09:36): Vorschläge des Assistenten mit "Später" und "Nicht mehr"
    if hint.advisor and hint.key and LP.Advisor and LP.Advisor.Later then
        local hh = t:GetHeight() + 24
        local bl = UI:Button(t, L["Später"], 70, 18, function() LP.Advisor:Later(hint) RemoveToast(t) end,
            L["Vorschlag ruht bis zur nächsten Stufe oder zum nächsten Ort, mindestens 30 Min. (jedes weitere Mal doppelt so lang)"])
        bl:SetPoint("BOTTOMLEFT", 10, 6)
        local bn = UI:Button(t, L["Nicht mehr"], 80, 18, function() LP.Advisor:Never(hint) RemoveToast(t) end,
            L["Diesen Vorschlag für diesen Charakter nicht mehr zeigen (wieder einschalten: Zentrale, Assistent)"])
        bn:SetPoint("LEFT", bl, "RIGHT", 6, 0)
        if hint.action2 then hh = math.max(hh, 86) end
        t:SetHeight(hh)
        if hint.action and not hint.action2 then
            -- Knopf oben rechts, damit unten Platz für "Später"/"Nicht mehr" bleibt
            t.actBtn:ClearAllPoints()
            t.actBtn:SetPoint("TOPRIGHT", -8, -6)
        end
    end
    t:SetScript("OnClick", function() RemoveToast(t) end)
    toasts[#toasts + 1] = t
    LayoutToasts()
    t:Show()
    LP.out.sound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON or 856)
    C_Timer.After(hint.sev == 3 and 25 or 12, function() if t:IsShown() then RemoveToast(t) end end)
end

------------------------------------------------------------------------
-- Minimap-Button
------------------------------------------------------------------------
function UI:CreateMinimapButton()
    local b = CreateFrame("Button", "LevelPilotMinimapButton", Minimap)
    b:SetSize(31, 31)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    local icon = b:CreateTexture(nil, "BACKGROUND")
    icon:SetTexture("Interface\\Icons\\INV_Misc_Spyglass_02")
    icon:SetSize(20, 20)
    icon:SetPoint("TOPLEFT", 7, -5)
    icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    local border = b:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT")

    local function Place()
        local a = math.rad(LP.db.minimapAngle or 200)
        local r = (Minimap:GetWidth() / 2) + 10
        b:ClearAllPoints()
        b:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
    end
    Place()
    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local s = Minimap:GetEffectiveScale()
            LP.db.minimapAngle = math.deg(math.atan2(cy / s - my, cx / s - mx))
            Place()
        end)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    b:SetScript("OnClick", function(_, btn)
        if btn == "RightButton" then LP.Center:Toggle() else UI:Toggle() end
    end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("|cffffb238Level|r|cff3dd694Pilot|r")
        if LP.Planner.focus then GameTooltip:AddLine(L["Zone: "] .. LP.Geo:MapName(LP.Planner.focus), 1, 1, 1) end
        GameTooltip:AddLine(L["Linksklick: Guide ein/aus"], 0.7, 0.7, 0.75)
        GameTooltip:AddLine(L["Rechtsklick: Zentrale"], 0.7, 0.7, 0.75)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    UI.mmButton = b
    if not LP.db.showMinimapBtn then b:Hide() end
end

------------------------------------------------------------------------
-- Sprachwechsel ohne /reload: feste Beschriftungen von der alten in die neue Sprache uebersetzen.
-- Texte, die sich laufend aendern (Schritte, Status, Werte), schreibt die naechste Aktualisierung neu.
------------------------------------------------------------------------
-- Zuordnung Text -> deutscher Schluessel fuer eine Sprache. Bei Mehrdeutigkeit (zwei deutsche Texte
-- heissen in der anderen Sprache gleich) gewinnt ein Text, den die Oberflaeche wirklich benutzt.
local function ReverseMap(lang)
    local rev = {}
    local keys = {}
    for k in pairs(LP.Locales.en or {}) do keys[k] = true end
    for _, t in pairs(LP.Locales) do
        if type(t) == "table" then for k in pairs(t) do keys[k] = true end end
    end
    local steps = 0
    for pass = 1, 2 do
        for k in pairs(keys) do
            -- 3.12.93: Art "svc" – gibt nur in einer freigegebenen Rechnung der Testroutine ab (keys ist eigen)
            steps = steps + 1
            if steps % 500 == 0 then LP:Yield("svc") end
            if (pass == 1) == (LP.usedKeys[k] == true) then
                local v = LP.LocaleLookup(lang, k)
                if type(v) == "string" and v ~= "" and rev[v] == nil then rev[v] = k end
                -- so, wie die Schrift es zeigt ("·" und "–" ersetzt, siehe LP:FixText)
                local v2 = type(v) == "string" and (v:gsub("·", "-"):gsub("–", "-"))
                if v2 and v2 ~= v and rev[v2] == nil then rev[v2] = k end
            end
        end
    end
    for k in pairs(keys) do
        if rev[k] == nil and lang == "de" then rev[k] = k end
        local k2 = lang == "de" and (k:gsub("·", "-"):gsub("–", "-"))
        if k2 and k2 ~= k and rev[k2] == nil then rev[k2] = k end
    end
    return rev
end

-- Text in Bausteine zerlegen: { {k = Schluessel} | {raw = fester Text} }
-- 3.12.93: pidx (optional) = Präfixe nach ihren ersten 6 Bytes (alle Präfixe haben >= 6 Bytes), je Fach in derselben Reihenfolge
-- wie prefixes – der erste Treffer ist derselbe wie beim Durchlauf über alle (Nachbau Laptop-Daten: Sprachwechsel 168 ms in einem
-- Bild, 61 % in diesem Durchlauf)
local function Segments(rev, prefixes, text, pidx)
    if type(text) ~= "string" or text == "" then return nil end
    if rev[text] then return { { k = rev[text] } } end
    if text:find("\n", 1, true) then
        local segs, any, rest = {}, false, text
        while rest ~= "" do
            local line, nl = rest:match("^([^\n]*)(\n?)")
            if rev[line .. nl] and nl ~= "" then
                segs[#segs + 1] = { k = rev[line .. nl] } any = true
            elseif line ~= "" and rev[line] then
                segs[#segs + 1] = { k = rev[line] } any = true
                if nl ~= "" then segs[#segs + 1] = { raw = nl } end
            else
                segs[#segs + 1] = { raw = line .. nl }
            end
            if #line + #nl == 0 then break end
            rest = rest:sub(#line + #nl + 1)
        end
        if any then return segs end
    end
    local list = prefixes
    if pidx then list = pidx[text:sub(1, 6)] or {} end
    for _, p in ipairs(list) do
        if #text > #p.v and text:sub(1, #p.v) == p.v then return { { k = p.k }, { raw = text:sub(#p.v + 1) } } end
    end
    return nil
end

local function Render(segs, lang)
    local out = {}
    for _, sg in ipairs(segs) do out[#out + 1] = sg.k and LP.LocaleLookup(lang, sg.k) or sg.raw end
    return table.concat(out)
end
UI.RenderSegments = Render

-- Bausteine eines Texts: gemerkte, solange der Text unveraendert ist, sonst neu bestimmen
local function SegsFor(holder, field, text, oldLang, getRev)
    local segs = rawget(holder, field)
    if type(segs) == "table" then
        local r = Render(segs, oldLang)
        if r == text or (r:gsub("·", "-"):gsub("–", "-")) == text then return segs end
    end
    local rev, prefixes, pidx = getRev()
    segs = Segments(rev, prefixes, text, pidx)
    rawset(holder, field, segs)
    return segs
end

function UI:Relabel(oldLang)
    local rev, prefixes, pidx
    local function getRev()
        if not rev then
            rev = ReverseMap(oldLang)
            prefixes = {}
            for v, k in pairs(rev) do if #v >= 6 then prefixes[#prefixes + 1] = { v = v, k = k } end end
            table.sort(prefixes, function(a, b) return #a.v > #b.v end)
            pidx = {}
            for _, p in ipairs(prefixes) do
                local h = p.v:sub(1, 6)
                local b = pidx[h]
                if not b then b = {} pidx[h] = b end
                b[#b + 1] = p
            end
        end
        return rev, prefixes, pidx
    end
    local newLang = LP:Language()
    local n = 0
    -- 3.12.93: Schlüssel vorher gesammelt (in einer Pause kann ein neuer Text dazukommen); Abgabe nur in der Testroutine ("svc")
    local list = {}
    for fs in pairs(UI.texts) do list[#list + 1] = fs end
    for li = 1, #list do
        local fs = list[li]
        if li % 5 == 0 then LP:Yield("svc") end
        if fs.GetText then
            local text = fs:GetText()
            local segs = text and text ~= "" and SegsFor(fs, "_lpSegs", text, oldLang, getRev)
            if segs then
                local new = Render(segs, newLang)
                if new ~= text then fs:SetText(new) n = n + 1 end
            end
            -- Schrift der neuen Sprache (Kyrillisch, Koreanisch, Chinesisch)
            if fs.GetFont and fs.SetFont and not rawget(fs, "_lpFixedFont") then
                local _, size, flags = fs:GetFont()
                pcall(fs.SetFont, fs, LP.FONT, size or 12, flags or "")
            end
        end
    end
    local blist = {}
    for b in pairs(UI.buttons) do blist[#blist + 1] = b end
    for bi = 1, #blist do
        local b = blist[bi]
        if bi % 5 == 0 then LP:Yield("svc") end
        UI.FitLabel(b)
        if type(rawget(b, "tip")) == "string" and not rawget(b, "tipFn") then
            local segs = SegsFor(b, "_lpTipSegs", b.tip, oldLang, getRev)
            if segs then b.tip = Render(segs, newLang) end
        end
    end
    return n
end

------------------------------------------------------------------------
-- Menue fuer einen Schritt (Rechtsklick): zurueckstellen, ignorieren, abbrechen
------------------------------------------------------------------------
local menu
function UI:StepMenu(anchor, step)
    if not CreateFrame then return end
    local C = LP.colors
    if not menu then
        menu = CreateFrame("Frame", "LevelPilotStepMenu", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
        menu:SetSize(196, 112)
        menu:SetFrameStrata("DIALOG")
        menu:EnableMouse(true)
        self:Skin(menu, C.panel, C.accent)
        menu.title = self:Text(menu, 11, C.text)
        menu.title:SetPoint("TOPLEFT", 10, -8)
        menu.title:SetWidth(176)
        menu.title:SetJustifyH("LEFT")
        menu.later = self:Button(menu, L["Zurückstellen (30 min)"], 176, 22, function()
            if menu.step then LP.Engine:Later(menu.step) end
            menu:Hide()
        end, L["Der Schritt verschwindet für 30 Minuten aus der Route."])
        menu.later:SetPoint("TOPLEFT", 10, -30)
        menu.ignore = self:Button(menu, L["Quest ignorieren"], 176, 22, function()
            if menu.step then LP.Engine:Skip(menu.step) end
            menu:Hide()
        end, L["Die Quest wird nicht mehr geplant (rückgängig: /lp zurück oder Zentrale » Route)."])
        menu.ignore:SetPoint("TOPLEFT", 10, -56)
        menu.cancel = self:Button(menu, L["Abbrechen"], 176, 22, function() menu:Hide() end)
        menu.cancel:SetPoint("TOPLEFT", 10, -82)
        menu:SetScript("OnHide", function() menu.step = nil end)
        if UISpecialFrames then table.insert(UISpecialFrames, "LevelPilotStepMenu") end   -- Esc schliesst
    end
    menu.step = step
    menu.title:SetText((self:StepText(step, false):match("^[^\n]*") or ""):sub(1, 60))
    -- Quest-Schritte: ignorieren; andere Schritte: nur ueberspringen
    local isQuest = step.id and (step.t == "ACCEPT" or step.t == "COMPLETE" or step.t == "TURNIN")
    menu.ignore.label:SetText(isQuest and L["Quest ignorieren"] or L["Überspringen"])
    menu:ClearAllPoints()
    menu:SetPoint("TOPLEFT", anchor, "TOPRIGHT", 4, 0)
    menu:Show()
end

