-- GuildSentinel - Links.lua
-- Vernetzung mit allen Addons von GoldSentinel. GuildSentinel erkennt, welche installiert sind, öffnet sie mit
-- einem Klick und nutzt ihre Daten:
--   * RaidMaster     – Berufe, Twinks, Rollen aus der Skillung, nächster Raid (Termine), Erstkills (Meilensteine)
--   * AH Analyzer Pro – Marktwert für Biete/Suche und für die Ergebnisse der Abklingzeiten
--   * ThreatSentinel – eigene Rolle (Tank in Verteidigungshaltung / Bärengestalt, gewählte Rolle)
--   * BuffSentinel   – erkennt Klassen-Dienste (Portale, Beschwören, Schlösser knacken …) über das Zauberbuch
--   * LevelPilot     – Elite-Quests für die Gruppensuche, Mitspieler mit derselben Elite-Quest
-- Dazu teilt jeder mit GuildSentinel, welche dieser Addons er hat (und welche Version) – so sieht die
-- Gildenleitung, wer was nutzt und wer eine alte Version hat.

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local K = {}
ns.Links = K

K.LIST = {
	{ key = "RaidMaster", name = "RaidMaster", slash = "RAIDMASTER", what = N["DKP, Raids, Loot"] },
	-- AH Analyzer Pro heisst inzwischen AHSentinel (Ordner AHSentinel); der Schlüssel bleibt für den Abgleich gleich
	{ key = "AHAnalyzerPro", name = "AH Analyzer Pro", slash = "AHANALYZERPRO", what = N["Auktionshaus"], folders = { "AHSentinel", "AHAnalyzerPro" } },
	{ key = "BuffSentinel", name = "BuffSentinel", slash = "BUFFSENTINEL", what = N["Buffs, Procs, Cooldowns"] },
	{ key = "ThreatSentinel", name = "ThreatSentinel", slash = "THREATSENTINEL", what = N["Aggro für Tanks"] },
	{ key = "LevelPilot", name = "LevelPilot", slash = "LEVELPILOT", what = N["Leveling-Route"] },
}

local GetMeta = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
local IsLoaded = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded

-- Andere Addons (globale Tabellen). K.ext ist nur für die Testroutine: Ersatz-Objekte statt der echten Addons
-- (K.ext.loaded = { [Ordner] = true/false } für die Erkennung). Normal leer – dann gilt immer das echte Global.
K.ext = nil
local function Ext(name)
	local x = K.ext
	if x and x[name] ~= nil then
		if x[name] == false then return nil end
		return x[name]
	end
	return _G[name]
end
K.Ext = Ext

-- Ordnernamen eines Eintrags (meist nur der Schlüssel selbst)
local function Folders(key)
	for _, a in ipairs(K.LIST) do
		if a.key == key and a.folders then return a.folders end
	end
	return { key }
end

-- geladener Ordner zu einem Schlüssel (oder nil)
function K:Folder(key)
	local over = K.ext and K.ext.loaded
	if over then
		for _, f in ipairs(Folders(key)) do if over[f] then return f end end
		if over[key] == false then return nil end
	end
	if not IsLoaded then return nil end
	for _, f in ipairs(Folders(key)) do
		local ok, loaded = pcall(IsLoaded, f)
		if ok and loaded then return f end
	end
	return nil
end

function K:Loaded(key)
	return self:Folder(key) ~= nil
end

function K:Version(key)
	local folder = GetMeta and self:Folder(key)
	if not folder then return nil end
	local ok, v = pcall(GetMeta, folder, "Version")
	return ok and v or nil
end

-- meine GoldSentinel-Addons: { [key] = Version }
function K:Mine()
	local out = {}
	for _, a in ipairs(self.LIST) do
		local v = self:Version(a.key)
		if v then out[a.key] = v end
	end
	return out
end

function K:Open(key)
	for _, a in ipairs(self.LIST) do
		if a.key == key and SlashCmdList and SlashCmdList[a.slash] then
			local ok = pcall(SlashCmdList[a.slash], "")
			return ok
		end
	end
	return false
end

------------------------------------------------------------
-- Wer in der Gilde hat welches Addon? (kommt mit "HI"/"VER" und beim Abgleich)
------------------------------------------------------------
function K:Store(name, list)
	local g = ns.guild
	if not g or type(list) ~= "table" then return end
	local clean = {}
	for _, a in ipairs(self.LIST) do
		if type(list[a.key]) == "string" then clean[a.key] = list[a.key]:sub(1, 20) end
	end
	g.addons[name] = { t = ns.Now(), a = clean }
	ns:Fire("GS_ADDONS")
end

-- { { key, name, users = { { name, v } }, newest } }
function K:Usage()
	local out = {}
	local g = ns.G()
	local function num(v)
		local a, b, c = tostring(v):match("(%d+)%.(%d+)%.?(%d*)")
		return (tonumber(a) or 0) * 1000000 + (tonumber(b) or 0) * 1000 + (tonumber(c) or 0)
	end
	for _, a in ipairs(self.LIST) do
		local users, newest = {}, nil
		local mine = self:Version(a.key)
		if mine then users[#users + 1] = { name = ns.Me(), v = mine } end
		for name, e in pairs(g.addons) do
			if not ns.Same(name, ns.Me()) and e.a[a.key] and (ns.Roster.byName[name] or not next(ns.Roster.byName)) then
				users[#users + 1] = { name = name, v = e.a[a.key] }
			end
		end
		for _, u in ipairs(users) do if not newest or num(u.v) > num(newest) then newest = u.v end end
		for _, u in ipairs(users) do u.old = newest and num(u.v) < num(newest) end
		table.sort(users, function(x, y) return x.name < y.name end)
		out[#out + 1] = { key = a.key, name = a.name, what = L[a.what], users = users, newest = newest, mine = mine }
	end
	return out
end

------------------------------------------------------------
-- AH Analyzer Pro: Marktwert
------------------------------------------------------------
function K:MarketValue(itemID)
	local A = Ext("AHAnalyzerPro")
	if type(A) ~= "table" or type(A.GetMarketValue) ~= "function" or not itemID or itemID <= 0 then return nil end
	local ok, v = pcall(A.GetMarketValue, A, itemID)
	if ok and type(v) == "number" and v > 0 then return v end
	return nil
end

------------------------------------------------------------
-- ThreatSentinel: eigene Rolle ("tank", "heal", "dps" oder nil)
------------------------------------------------------------
function K:ThreatRole()
	local DB = Ext("ThreatSentinelDB")
	if not self:Loaded("ThreatSentinel") or type(DB) ~= "table" then return nil end
	local key = (UnitName("player") or "?") .. " - " .. (GetRealmName and GetRealmName() or "?")
	local prof = DB.profiles and DB.profiles[(DB.chars and DB.chars[key]) or key]
	local r = prof and prof.myRole
	if r == "HEALER" then return "heal" end
	if r == "DAMAGER" then return "dps" end
	-- Tank-Haltung / Bärengestalt / Zorn der Gerechtigkeit: ThreatSentinel ist dann aktiv
	local _, cf = UnitClass("player")
	if (cf == "WARRIOR" or cf == "DRUID" or cf == "PALADIN") and GetShapeshiftForm then
		local form = GetShapeshiftForm()
		if cf == "WARRIOR" and form == 2 then return "tank" end
		if cf == "DRUID" and form == 1 then return "tank" end
	end
	return nil
end

------------------------------------------------------------
-- BuffSentinel: kennt der Charakter einen Zauber?
------------------------------------------------------------
function K:KnowsSpell(id)
	local BS = Ext("BuffSentinel")
	if type(BS) == "table" and type(BS.KnowsSpellID) == "function" then
		local ok, known = pcall(BS.KnowsSpellID, id)
		if ok and known ~= nil then return known and true or false end
	end
	-- moderner Client: C_SpellBook zuerst
	if C_SpellBook and C_SpellBook.IsSpellKnown then
		local ok, known = pcall(C_SpellBook.IsSpellKnown, id)
		if ok and known ~= nil then return known and true or false end
	end
	if IsSpellKnown then
		local ok, known = pcall(IsSpellKnown, id)
		if ok then return known and true or false end
	end
	if IsPlayerSpell then return IsPlayerSpell(id) and true or false end
	return false
end

------------------------------------------------------------
-- LevelPilot: Elite-Quests und Mitspieler
------------------------------------------------------------
function K:EliteQuests()
	local LP = Ext("LevelPilot")
	if type(LP) ~= "table" or type(LP.Social) ~= "table" or type(LP.Social.MyEliteQuests) ~= "function" then return {} end
	local ok, ids = pcall(LP.Social.MyEliteQuests, LP.Social)
	if not ok or type(ids) ~= "table" then return {} end
	local out = {}
	for _, id in ipairs(ids) do
		local title
		if C_QuestLog and C_QuestLog.GetTitleForQuestID then title = C_QuestLog.GetTitleForQuestID(id) end
		if not title and LP.QuestDB and LP.QuestDB.Get then
			local ok2, q = pcall(LP.QuestDB.Get, LP.QuestDB, id)
			if ok2 and type(q) == "table" then title = q.name end
		end
		out[#out + 1] = { id = id, title = title or ("#" .. id) }
	end
	return out
end

-- Mitspieler (mit LevelPilot) mit derselben Elite-Quest: { [Quest-ID] = { { name, level } } }
function K:EliteMatches()
	local LP = Ext("LevelPilot")
	if type(LP) ~= "table" or type(LP.Social) ~= "table" or type(LP.Social.Matches) ~= "function" then return {} end
	local ok, m = pcall(LP.Social.Matches, LP.Social)
	return (ok and type(m) == "table") and m or {}
end

------------------------------------------------------------
-- RaidMaster: nächster Raid, Erstkills
------------------------------------------------------------
function K:NextRaid()
	if ns.Test and ns.Test:Active() then return ns.Test:FakeRaid() end
	local rm = _G.RaidMaster
	local su = type(rm) == "table" and type(rm.db) == "table" and rm.db.signup
	if type(su) ~= "table" or type(su.start) ~= "number" then return nil end
	if su.start < ns.Now() - 3 * 3600 then return nil end
	if type(su.title) == "string" and su.title:find("^TEST ") then return nil end
	local n = 0
	for _, e in ipairs(su.list or {}) do if e.status == "an" then n = n + 1 end end
	return { title = su.title or L["Raid"], t = su.start, signed = n, max = su.max }
end

function K:FirstKills()
	if ns.Test and ns.Test:Active() then return {} end
	local rm = _G.RaidMaster
	local fk = type(rm) == "table" and type(rm.db) == "table" and type(rm.db.data) == "table" and rm.db.data.firstKills
	if type(fk) ~= "table" then return {} end
	local out = {}
	for id in pairs(fk) do
		local name
		local b = rm.Data and rm.Data.Bosses and rm.Data.Bosses[id]
		if b and b.name then name = b.name end
		local kb = rm.db.data.knownBosses and rm.db.data.knownBosses[id]
		if not name and kb then name = kb.n end
		out[#out + 1] = { id = id, name = name or ("#" .. tostring(id)) }
	end
	table.sort(out, function(a, b) return a.name < b.name end)
	return out
end

-- meine Addons beim Einloggen mitteilen (mit dem Gruß "HI" und als Antwort "VER")
ns:Listen("GS_LOGIN", function()
	C_Timer.After(14, function()
		if not ns.guild or not ns.Me() then return end
		ns.G().addons[ns.Me()] = { t = ns.Now(), a = K:Mine() }
		ns.Comm:Send("ADDONS", { a = K:Mine() })
	end)
end)
ns.Comm:Register("ADDONS", function(sender, d)
	K:Store(sender, d.a)
end)
ns.Comm:Register("ADDONSQ", function(sender, d)
	ns.Comm:Send("ADDONS", { a = K:Mine() }, "WHISPER", sender)
end)
