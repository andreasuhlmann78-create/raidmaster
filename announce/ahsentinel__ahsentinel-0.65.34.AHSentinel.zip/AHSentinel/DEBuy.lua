if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Sammelkauf zum Entzaubern (ab 0.65.34, Anweisung "Sammelkauf zum Entzaubern", bewusst einfach)
--
-- Reiter Kaufen -> Einkauf: Knopf "Entzaubern lohnt" zeigt aus der letzten Suche nur Teile (Rüstung/Waffen, nicht
-- stapelbar), deren Entzauberungswert den Kaufpreis um mindestens die Mindestrendite übersteigt (Standard 20 %),
-- und mindestens 10c Gewinn je Teil. Sortiert nach Gewinn; Spalten Gewinn und Rendite %.
-- Kaufen wie beim Sniper: jede Mausrad-Raste über der Liste bzw. ein Klick auf "Nächstes kaufen" kauft das nächste
-- Teil von oben. Vor jedem Kauf: Angebot noch da, Preis nicht höher - sonst überspringen. In WoW Forever muss jeder
-- Einzelkauf aus einem Tastendruck kommen: eine Raste je Teil (erste Raste lädt die Angebote, falls nötig).
-- Grenzen: "höchstens X Gold" (Standard 5g), "Mindestrendite %" (Standard 20 %), fest 10c Gewinn je Teil.
-- Stopp bei Grenze, vollen Taschen oder Kampf. Unter 10 echten Entzauberungen der Gruppe: Wert minus 10 %.
-- Nur auf Klick/Raste, nie automatisch; Protokoll KAUF (ohne Namen). Kein Fertigkeits-Filter (Forever: ab
-- Verzauberkunst 1 ist alles entzauberbar).
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local DB = A.DEBuy or {}
A.DEBuy = DB

DB.MIN_PROFIT = 10              -- fest: mindestens 10c Gewinn je Teil
DB.SAFETY = 0.10                -- Abschlag unter 10 echten Entzauberungen
DB.MAX_STEPS = { 10000, 50000, 100000, 200000, 500000 }   -- 1g, 5g, 10g, 20g, 50g
DB.ROI_STEPS = { 10, 20, 30, 50, 100 }

DB.session = DB.session or { bought = 0, paid = 0, expected = 0 }
DB.skipped = DB.skipped or {}   -- [itemID] = true: in dieser Sitzung übersprungen (weg/teurer)

local function Settings() return A.db and A.db.settings or {} end
function DB:MaxGold()
    local v = Settings().deBuyMax
    return (type(v) == "number" and v > 0) and v or 50000
end
function DB:MinRoi()
    local v = Settings().deBuyRoi
    return (type(v) == "number" and v >= 0) and v or 20
end
local function Cycle(list, cur)
    local idx = 1
    for i, v in ipairs(list) do if v == cur then idx = i end end
    return list[idx % #list + 1]
end
function DB:CycleMax() A.db.settings.deBuyMax = Cycle(self.MAX_STEPS, self:MaxGold()); return A.db.settings.deBuyMax end
function DB:CycleRoi() A.db.settings.deBuyRoi = Cycle(self.ROI_STEPS, self:MinRoi()); return A.db.settings.deBuyRoi end

-- Entzauberungswert für den Kauf (nach Gebühren), mit Sicherheitsabschlag unter 10 echten Entzauberungen
function DB:Value(itemID)
    local D = A.Disenchant
    if not (D and D.DealValue) then return nil end
    local v, net, complete, basis, n = D:DealValue(itemID)
    if not v or not complete or not net or net <= 0 then return nil end
    if (n or 0) < (D.FEW_DATA or 10) then net = math.floor(net * (1 - self.SAFETY) + 0.5) end
    return net, basis, n
end

-- Rechnung für ein Teil zum Preis price: Gewinn, Rendite in %, ok (über beiden Grenzen)
function DB:Judge(itemID, price)
    local value = self:Value(itemID)
    if not (value and price and price > 0) then return nil end
    local profit = value - price
    local roi = profit / price * 100
    return profit, roi, profit >= self.MIN_PROFIT and roi >= self:MinRoi(), value
end

-- Kandidaten aus der letzten Suche im Einkauf (B.results): nur nicht stapelbare, entzauberbare Teile
function DB:Candidates(rows)
    rows = rows or (A.Buy and A.Buy.results) or {}
    local out = {}
    local D = A.Disenchant
    for _, r in ipairs(rows) do
        local id = r.itemID
        if id and r.price and r.price > 0 and not self.skipped[id] and not A:IsCommodityItem(id) and D and D:Prior(id) then
            local profit, roi, ok, value = self:Judge(id, r.price)
            if ok then
                out[#out + 1] = { itemID = id, itemKey = r.itemKey, name = r.name or A:GetItemName(id), price = r.price,
                    qty = r.qty, quality = r.quality, profit = profit, roi = roi, value = value }
            end
        end
    end
    table.sort(out, function(a, b)
        if a.profit ~= b.profit then return a.profit > b.profit end
        return a.itemID < b.itemID
    end)
    return out
end

local function FreeSlots()
    if A.Mailer and A.Mailer.FreeSlots then return A.Mailer.FreeSlots() end
    return 1
end

-- billigstes kaufbares Einzelangebot (fremd, Sofortkauf, nicht schon gekauft)
local function BestListing(listings)
    local best
    for _, l in ipairs(listings or {}) do
        if l.auctionID and l.buyout and l.buyout > 0 and not l.own and not l.used and (l.qty or 1) == 1 then
            if not best or l.buyout < best.buyout then best = l end
        end
    end
    return best
end

-- Ein Tastendruck / eine Raste / ein Klick: das nächste Teil von oben
-- Rückgabe: ok, Meldung, Zustand ("loading", "bought", "skipped", "stop", "empty")
function DB:Next()
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."], "stop" end
    if A:InCombat() then return false, L["Im Kampf wird nichts gekauft."], "stop" end
    local B = A.Buy
    local list = self:Candidates()
    local top = list[1]
    if not top then return false, L["Nichts, was sich zum Entzaubern lohnt (Mindestrendite, mind. 10c Gewinn)."], "empty" end
    if self.session.paid + top.price > self:MaxGold() then
        return false, string.format(L["Grenze erreicht: höchstens %s."], A:FormatMoney(self:MaxGold())), "stop"
    end
    if FreeSlots() <= 0 then return false, L["Taschen voll."], "stop" end
    -- Angebote des Teils laden (erste Raste), danach kaufen
    local d = B and B.detail
    if not (d and d.itemID == top.itemID and not d.loading and d.listings) then
        if B.search or (B.wanted and B.wanted.kind == "items") then return false, L["Angebote werden geladen - gleich nochmal."], "loading" end
        B:Open(top.itemKey or top.itemID, top.name)
        return true, string.format(L["Angebote für %s werden geladen - nochmal drehen/klicken zum Kaufen."], top.name or "?"), "loading"
    end
    local l = BestListing(d.listings)
    -- Angebot weg oder teurer als gelistet: überspringen
    if not l or l.buyout > top.price then
        self.skipped[top.itemID] = true
        self:Log("ÜBERSPRUNGEN", top.itemID, l and l.buyout or 0, top.value)
        return false, string.format(L["Übersprungen: %s (Angebot weg oder teurer)."], top.name or "?"), "skipped"
    end
    local profit, roi, ok, value = self:Judge(top.itemID, l.buyout)
    if not ok then
        self.skipped[top.itemID] = true
        return false, string.format(L["Übersprungen: %s (lohnt nicht mehr)."], top.name or "?"), "skipped"
    end
    local okB, msg = B:BuyItem(l)
    if not okB then return false, msg, "stop" end
    self.session.bought = self.session.bought + 1
    self.session.paid = self.session.paid + l.buyout
    self.session.expected = self.session.expected + profit
    -- für das Entzauber-Fenster (zuerst gekaufte Teile) und die Abrechnung in der Buchhaltung
    A.db.deBuys = A.db.deBuys or {}
    table.insert(A.db.deBuys, { t = time(), itemID = top.itemID, paid = l.buyout, value = value })
    while #A.db.deBuys > 500 do table.remove(A.db.deBuys, 1) end
    self:Log("KAUF", top.itemID, l.buyout, value)
    -- kein weiteres Angebot zu diesem Preis: Teil ist erledigt, die nächste Raste nimmt das nächste Teil
    local nxt = BestListing(d.listings)
    if not nxt or nxt.buyout > top.price then self.skipped[top.itemID] = true end
    A:Fire("DEBUY_CHANGED")
    return true, string.format(L["Gekauft zum Entzaubern: %s für %s (erwartet +%s, %d %%)."], top.name or "?", A:FormatMoney(l.buyout),
        A:FormatMoney(profit), math.floor(roi + 0.5)), "bought"
end

function DB:Log(kind, itemID, price, value)
    if A.Diag then
        A.Diag:Add(kind == "KAUF" and "KAUF" or "KAUF", string.format("Entzaubern-Sammelkauf %s · Item %d · Preis %d · Wert %d",
            kind == "KAUF" and "gekauft" or "übersprungen", itemID or 0, price or 0, value or 0))
    end
end

function DB:StatusText()
    local s = self.session
    return string.format(L["Gekauft %d · %s · erwartet +%s"], s.bought, A:FormatMoney(s.paid), A:FormatMoney(s.expected))
end

function DB:Reset()
    self.session = { bought = 0, paid = 0, expected = 0 }
    self.skipped = {}
    A:Fire("DEBUY_CHANGED")
end
