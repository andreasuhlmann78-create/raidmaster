if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.8 - Preise und Preisverlauf im Item-Tooltip
--
-- Überall, wo WoW einen Item-Tooltip zeigt (Taschen, Auktionshaus,
-- Chat-Links, Listen anderer Addons, unsere eigenen Tabellen):
--   * zusätzliche Zeilen: aktueller Preis (mit % vom Marktwert),
--     Marktwert (Median 14 Tage), Trend 24 Std., Händlerpreis
--   * ein kleines Preisdiagramm direkt unter dem Tooltip
-- Beides lässt sich in den Optionen ein- und ausschalten.
-- Fehler in diesem Modul dürfen den Tooltip nie kaputt machen (pcall).
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local TT = {}
A.Tooltip = TT

local CW, CH = 240, 92                  -- Größe des Diagramms
local PAD_L, PAD_R, PAD_T, PAD_B = 6, 6, 20, 16

-- wählbare Zeiträume für das Diagramm (0 = aus)
TT.PERIODS = { 0, 1, 7, 30 }
local PERIOD_LABEL = { [1] = "24 Std.", [7] = "7 Tage", [30] = "30 Tage" }

function TT:Settings()
    local s = A.db and A.db.settings
    return s
end

function TT:ChartDays()
    local s = self:Settings()
    if not s then return 0 end
    local d = s.tooltipChartDays
    if d == nil then d = 7 end
    return d
end

function TT:PeriodLabel(days)
    days = days or self:ChartDays()
    if days == 0 then return L["aus"] end
    return L[PERIOD_LABEL[days] or "7 Tage"]
end

function TT:CycleChartDays()
    local s = self:Settings()
    if not s then return end
    local cur, i = self:ChartDays(), 1
    for k, d in ipairs(self.PERIODS) do if d == cur then i = k end end
    i = (i % #self.PERIODS) + 1
    s.tooltipChartDays = self.PERIODS[i]
    return s.tooltipChartDays
end

-- ------------------------------------------------------------
-- Diagramm-Fenster (wird einmal gebaut und wiederverwendet)
-- ------------------------------------------------------------
local chart

local function GetChart()
    if chart then return chart end
    local UI, C = A.UI, A.UI.C
    local f = CreateFrame("Frame", "AHAnalyzerProTooltipChart", UIParent)
    f:SetSize(CW, CH)
    f:SetFrameStrata("TOOLTIP")
    f:SetClampedToScreen(true)
    f:EnableMouse(false)
    UI:Box(f, { 0.03, 0.03, 0.05, 0.92 }, C.border)
    f:Hide()

    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    f.title:SetPoint("TOPLEFT", 6, -5)
    f.title:SetJustifyH("LEFT")
    f.high = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.high:SetPoint("TOPRIGHT", -6, -5)
    f.high:SetJustifyH("RIGHT")
    f.low = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.low:SetPoint("BOTTOMRIGHT", -6, 3)
    f.low:SetJustifyH("RIGHT")
    f.from = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    f.from:SetPoint("BOTTOMLEFT", 6, 3)
    f.from:SetJustifyH("LEFT")

    f.lines, f.dots, f.used = {}, {}, { lines = 0, dots = 0 }
    f.canRotate = true

    function f:Clear()
        for _, t in ipairs(self.lines) do t:Hide() end
        for _, t in ipairs(self.dots) do t:Hide() end
        self.used.lines, self.used.dots = 0, 0
        if self.avg then self.avg:Hide() end
    end

    function f:Dot(x, y, size, r, g, b, a)
        self.used.dots = self.used.dots + 1
        local t = self.dots[self.used.dots]
        if not t then
            t = self:CreateTexture(nil, "OVERLAY")
            self.dots[self.used.dots] = t
        end
        t:SetColorTexture(r, g, b, a or 1)
        t:SetSize(size, size)
        t:ClearAllPoints()
        t:SetPoint("CENTER", self, "BOTTOMLEFT", x, y)
        t:Show()
    end

    function f:Line(x1, y1, x2, y2, r, g, b)
        local dx, dy = x2 - x1, y2 - y1
        local len = math.sqrt(dx * dx + dy * dy)
        if len < 0.5 then return end
        if self.canRotate then
            self.used.lines = self.used.lines + 1
            local t = self.lines[self.used.lines]
            if not t then
                t = self:CreateTexture(nil, "ARTWORK")
                self.lines[self.used.lines] = t
            end
            t:SetColorTexture(r, g, b, 0.95)
            t:ClearAllPoints()
            t:SetSize(len, 2)
            t:SetPoint("CENTER", self, "BOTTOMLEFT", (x1 + x2) / 2, (y1 + y2) / 2)
            local ok = t.SetRotation and pcall(t.SetRotation, t, math.atan2(dy, dx))
            if ok then
                t:Show()
                return
            end
            t:Hide()
            self.canRotate = false
        end
        -- Rückfall ohne Drehen: Linie aus kleinen Punkten
        local steps = math.min(40, math.max(2, math.floor(len / 2)))
        for i = 0, steps do
            self:Dot(x1 + dx * i / steps, y1 + dy * i / steps, 2, r, g, b, 0.95)
        end
    end

    chart = f
    return f
end

-- Preispunkte des Zeitraums
local function Points(itemID, days)
    local out = {}
    local limit = time() - days * 86400
    for _, e in ipairs(A:GetHistory(itemID)) do
        if e.t >= limit and e.p and e.p > 0 and not e.u then table.insert(out, e) end      -- ohne unbestätigte (Lockangebote)
    end
    return out
end

function TT:HideChart(owner)
    if chart and (owner == nil or chart.owner == owner) then
        chart:Hide()
        chart.owner = nil
    end
end

function TT:ShowChart(tooltip, itemID)
    local days = self:ChartDays()
    if days == 0 then return self:HideChart() end
    local points = Points(itemID, days)
    if #points < 2 then return self:HideChart() end

    local f = GetChart()
    local C = A.UI.C
    f:Clear()

    local w = CW
    local tw = tooltip.GetWidth and tooltip:GetWidth()
    if tw and tw > w then w = tw end
    f:SetWidth(w)

    local minP, maxP = points[1].p, points[1].p
    for _, e in ipairs(points) do
        if e.p < minP then minP = e.p end
        if e.p > maxP then maxP = e.p end
    end
    local lo, hi = minP, maxP
    if hi == lo then lo, hi = lo * 0.9, hi * 1.1 + 1 end
    local minT, maxT = points[1].t, points[#points].t
    if maxT == minT then maxT = minT + 1 end

    local plotW, plotH = w - PAD_L - PAD_R, CH - PAD_T - PAD_B
    local function X(t) return PAD_L + (t - minT) / (maxT - minT) * plotW end
    local function Y(p) return PAD_B + (p - lo) / (hi - lo) * plotH end

    -- Linie beim Marktwert (Median der gezeigten Preise)
    local values = {}
    for i, e in ipairs(points) do values[i] = e.p end
    local avg = A.Median(values)
    if not f.avg then f.avg = f:CreateTexture(nil, "BORDER") end
    f.avg:SetColorTexture(1, 0.8, 0.2, 0.35)
    f.avg:ClearAllPoints()
    f.avg:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", PAD_L, Y(avg))
    f.avg:SetSize(plotW, 1)
    f.avg:Show()

    -- Steigt der Preis -> grün, fällt er -> rot, sonst Akzentfarbe
    local first, last = points[1].p, points[#points].p
    local col = C.accent
    if last > first * 1.02 then col = C.green elseif last < first * 0.98 then col = C.red end

    local px, py
    for _, e in ipairs(points) do
        local x, y = X(e.t), Y(e.p)
        if px then f:Line(px, py, x, y, col[1], col[2], col[3]) end
        px, py = x, y
    end
    f:Dot(px, py, 5, 1, 1, 1, 1)          -- aktueller Preis

    f.title:SetText("|cff00d1d1AHSentinel|r  " .. string.format(L["Preisverlauf (%s)"], self:PeriodLabel(days)))
    f.high:SetText(A:FormatMoney(maxP, true))
    f.low:SetText(A:FormatMoney(minP, true))
    f.from:SetText(date("%d.%m.", minT) .. "  -  " .. date("%d.%m.", maxT))

    -- unter den Tooltip, oder darüber, wenn unten kein Platz ist
    f:ClearAllPoints()
    local bottom = tooltip.GetBottom and tooltip:GetBottom()
    if bottom and bottom < CH + 10 then
        f:SetPoint("BOTTOMLEFT", tooltip, "TOPLEFT", 0, 2)
    else
        f:SetPoint("TOPLEFT", tooltip, "BOTTOMLEFT", 0, -2)
    end
    f.owner = tooltip
    f:Show()
end

-- ------------------------------------------------------------
-- Zusätzliche Zeilen im Tooltip
-- ------------------------------------------------------------
function TT:AddLines(tooltip, itemID)
    local s = self:Settings()
    local showInfo = not (s and s.tooltipInfo == false)
    local vendor = (not s or s.tooltipVendor ~= false) and A:GetVendorPrice(itemID) or nil
    -- beim Händler zeigt WoW den Verkaufspreis selbst an
    if vendor and type(MerchantFrame) == "table" and MerchantFrame.IsShown and MerchantFrame:IsShown() then vendor = nil end
    if vendor and vendor <= 0 then vendor = nil end
    if not showInfo and not vendor then return end
    tooltip:AddLine(" ")
    -- Addon in einer anderen Sprache als der Client: Item-Namen in der Sprache des Addons zeigen
    -- (den Titel des Tooltips schreibt WoW immer in der Sprache des Clients)
    local N = A.Names
    if N and N.DisplayLocale and N:DisplayLocale() ~= N:ClientLocale() then
        local nm = N:Get(itemID)
        if nm then tooltip:AddLine("|cff00d1d1AHSentinel|r  " .. nm, 1, 1, 1) end
    end
    if not showInfo then
        tooltip:AddDoubleLine("|cff00d1d1AHSentinel|r  " .. L["Händlerpreis"], A:FormatMoney(vendor), 1, 1, 1, 1, 1, 1)
        return
    end
    local cur = A:GetCurrent(itemID)
    if not cur then
        tooltip:AddLine(L["AHSentinel: noch keine Preisdaten"], 0.6, 0.6, 0.6)
        if vendor then tooltip:AddDoubleLine(L["Händlerpreis"], A:FormatMoney(vendor), 0.8, 0.8, 0.8, 1, 1, 1) end
        TT:AddExtraLines(tooltip, itemID)
        return
    end
    local pct = A:GetMarketPercent(itemID, cur)
    local priceText = A:FormatMoney(cur)
    if pct then priceText = priceText .. "  (" .. A:FormatMarketPercent(pct) .. ")" end
    tooltip:AddDoubleLine("|cff00d1d1AHSentinel|r  " .. L["Preis"], priceText, 1, 1, 1, 1, 1, 1)
    local mv = A:GetMarketValue(itemID)
    if mv then
        tooltip:AddDoubleLine(L["Marktwert (Median 14 Tage)"], A:FormatMoney(mv), 0.8, 0.8, 0.8, 1, 1, 1)
    end
    -- Realer Wert (die eine Preisfunktion) mit Quelle; Shift: jeder Bestandteil
    local okR, rv, rp, rinfo, vendorWins = pcall(A.RealValue, A, itemID, 1)
    if okR and rv then
        local src = vendorWins and L["Händler"] or (rinfo and (rinfo.source == "sale" and L["eigener Verkauf"]
            or (rinfo.source == "ah" and L["AH aktuell"] or L["Markt"]))) or ""
        local extra = (rinfo and rinfo.old) and (" |cffff9933" .. L["Preis alt"] .. "|r") or ""
        tooltip:AddDoubleLine(L["Realer Wert (nach Gebühren)"], A:FormatMoney(rv) .. " |cff999999" .. src .. "|r" .. extra, 0.8, 0.8, 0.8, 1, 1, 1)
        local isShift = A:API("IsShiftKeyDown")
        if isShift and isShift() and rinfo then
            if rinfo.sale then tooltip:AddDoubleLine("   " .. L["eigener Verkauf (14 Tage)"], A:FormatMoney(rinfo.sale), 0.6, 0.6, 0.6, 0.8, 0.8, 0.8) end
            if rinfo.current then tooltip:AddDoubleLine("   " .. L["günstigstes Angebot"] .. (rinfo.unsure and (" (" .. L["Angebot unsicher"] .. ")") or ""),
                A:FormatMoney(rinfo.current), 0.6, 0.6, 0.6, 0.8, 0.8, 0.8) end
            if rinfo.median then tooltip:AddDoubleLine("   " .. L["Median 14 Tage"], A:FormatMoney(rinfo.median), 0.6, 0.6, 0.6, 0.8, 0.8, 0.8) end
            if rp and not vendorWins then tooltip:AddDoubleLine("   " .. L["Gebühr"], A:FormatMoney(rp - (rv or rp)), 0.6, 0.6, 0.6, 0.8, 0.8, 0.8) end
        end
    end
    -- Verkaufbarkeit: wie viel sich pro Tag verkauft und ob man dem Marktwert trauen kann
    if mv and A.LiquidityText then
        local ok, txt = pcall(A.LiquidityText, A, itemID)
        if ok and txt then tooltip:AddLine(txt, 0.75, 0.75, 0.75) end
    end
    local trend = A:GetTrend(itemID, 86400)
    if trend then
        tooltip:AddDoubleLine(L["Trend 24 Std."], A:FormatPercent(trend), 0.8, 0.8, 0.8, 1, 1, 1)
    end
    if vendor then
        local color = (vendor > cur) and "|cff33dd55" or ""
        tooltip:AddDoubleLine(L["Händlerpreis"], color .. A:FormatMoney(vendor) .. (color ~= "" and "|r" or ""), 0.8, 0.8, 0.8, 1, 1, 1)
    end
    TT:AddExtraLines(tooltip, itemID)
    local w = A.db.watchlist[itemID]
    if w and (w.buyBelow or w.sellAbove) then
        local parts = {}
        if w.buyBelow then table.insert(parts, L["Kaufen <"] .. " " .. A:FormatMoney(w.buyBelow, true)) end
        if w.sellAbove then table.insert(parts, L["Verkaufen >"] .. " " .. A:FormatMoney(w.sellAbove, true)) end
        tooltip:AddDoubleLine(L["Watchlist"], table.concat(parts, "  "), 0.8, 0.8, 0.8, 1, 1, 1)
    end
end

-- Entzaubern im Tooltip: zwei klar getrennte Werte
--   "Entzaubern tatsächlich (Ø aus N)": nur echte Entzauberungen (eigene + geteilte), aktueller AH-Preis je Material
--   "Entzaubern geschätzt (Tabelle)":    D:GetValue (Tabelle verrechnet mit Ergebnissen)
-- detail = je Material eine Zeile und "nach Gebühren" (Einstellung, Standard an)
function TT:DisenchantLines(itemID, detail)
    local D = A.Disenchant
    local lines = {}            -- { left, right, dim }
    local function priceText(r)
        if not r.price then return L["kein Preis"] end
        local t = "AH " .. A:FormatMoney(r.price)
        if r.age then t = t .. " (" .. A:FormatAgo(time() - r.age) .. ")" end
        if r.mv and r.mv ~= r.price then t = t .. " · " .. string.format(L["Markt %s"], A:FormatMoney(r.mv)) end
        return t
    end
    local function share(r) return r.share and ("= " .. A:FormatMoney(math.floor(r.share + 0.5))) or "+?" end
    -- tatsächlich
    local av, acomplete, n, arows = D:ActualValue(itemID)
    if av then
        local label = string.format(L["Entzaubern tatsächlich (Ø aus %d)"], n)
        if n < D.FEW_DATA then label = label .. " " .. L["(wenig Daten)"] end
        table.insert(lines, { label, A:FormatMoney(av) .. (acomplete and "" or " +?") })
        if detail then
            for _, r in ipairs(arows) do
                table.insert(lines, { string.format("   %s  %d/%d × Ø %.1f · %s", A:GetItemName(r.id) or ("#" .. r.id), r.times, n,
                    r.total / r.times, priceText(r)), share(r), true })
            end
            table.insert(lines, { "   " .. L["nach Gebühren"], A:FormatMoney(D:ActualNet(av, arows, n)) .. (acomplete and "" or " +?"), true })
        end
    end
    -- geschätzt
    local v, complete, yield = D:GetValue(itemID)
    if v then
        table.insert(lines, { L["Entzaubern geschätzt (Tabelle)"], "~" .. A:FormatMoney(v) .. (complete and "" or " +?") })
        if detail then
            for _, r in ipairs(D:EstimateRows(itemID) or {}) do
                table.insert(lines, { string.format("   %s  %d%% × Ø %.1f · %s", A:GetItemName(r.id) or ("#" .. r.id),
                    math.floor(r.chance * 100 + 0.5), r.avg, priceText(r)), share(r), true })
            end
            table.insert(lines, { "   " .. L["nach Gebühren"], "~" .. A:FormatMoney(D:NetValue(v, yield)) .. (complete and "" or " +?"), true })
        end
    end
    -- womit die Schnäppchen rechnen
    if detail and (av or v) then
        local _, _, _, basis = D:DealValue(itemID)
        if basis then
            table.insert(lines, { "   " .. (basis == "actual" and L["Schnäppchen rechnen mit: tatsächlich"]
                or L["Schnäppchen rechnen mit: geschätzt"]), "", true })
        end
    end
    return lines
end

-- Kurzform (0.65.26, Wunsch des Nutzers): EINE Zeile "Entzaubern: erwarteter Gewinn ~X" (Wert nach Gebühren),
-- dahinter klein der Vergleich mit dem Verkauf des Items und die Quelle ("(Ø 12)" = aus 12 Entzauberungen,
-- "(T)" = Tabelle). Die ganze Rechnung läuft weiter (DisenchantLines), Shift zeigt sie.
-- zurück: { left, right, net, basis, n, sellNet } oder nil
function TT:DisenchantShort(itemID)
    local D = A.Disenchant
    local v, net, complete, basis, n = D:DealValue(itemID)
    if not v then return nil end
    local mark = (basis == "actual") and string.format("(Ø %d)", n) or "(T)"
    -- Befund 9. Nov. 10:31: das ist der Entzauberungswert (hängt nur von der Gruppe ab), kein Gewinn
    local left = L["Entzauberungswert"]
    local sellNet = A:RealValue(itemID, 1)
    if sellNet then
        left = left .. "  " .. ((net > sellNet) and ("|cff33dd55" .. L["lohnt mehr als Verkauf"] .. "|r")
            or ("|cffff9933" .. L["Verkauf bringt mehr"] .. "|r"))
    end
    local res = { left = left, right = "~" .. A:FormatMoney(net) .. (complete and "" or " +?") .. " |cff999999" .. mark .. "|r",
        net = net, basis = basis, n = n, sellNet = sellNet }
    -- Gewinn beim Kauf: Wert - Kaufpreis (Kaufpreis aus der Zeile im Addon, beim Händler, sonst günstigstes Angebot)
    local buy, how = self:BuyPriceFor(itemID)
    if buy then
        local g = net - buy
        res.buy, res.gain = buy, g
        res.gainLeft = how == "list" and L["Gewinn beim Kauf"] or (how == "vendor" and L["Gewinn beim Kauf (Händler)"]
            or L["Gewinn beim Kauf (günstigstes Angebot)"])
        res.gainRight = (g >= 0 and ("|cff33dd55" .. A:FormatMoney(g)) or ("|cffff5544-" .. A:FormatMoney(-g))) .. "|r"
            .. " |cff999999(" .. A:FormatMoney(net) .. " − " .. A:FormatMoney(buy) .. ")|r"
    end
    return res
end

-- Kaufpreis für "Gewinn beim Kauf": zuerst die Zeile, über der die Maus im Addon steht (Kaufliste, Sniper,
-- Schnäppchen: TT.buyContext), dann beim Händler dessen Preis, sonst das günstigste aktuelle Angebot (frisch)
TT.buyContext = nil
function TT:BuyPriceFor(itemID)
    local c = self.buyContext
    if c and c.itemID == itemID and c.price and c.price > 0 then return c.price, "list" end
    local atMerchant = type(MerchantFrame) == "table" and MerchantFrame.IsShown and MerchantFrame:IsShown()
    if atMerchant then
        local v = A:GetVendorBuyPrice(itemID)
        if v and v > 0 then return v, "vendor" end
    end
    local cur, _, t = A:GetCurrent(itemID)
    if cur and cur > 0 and t and time() - t <= A.PRICE_OLD_HOURS * 3600 then return cur, "ah" end
    return nil
end

-- Block "Entzaubern – Materialien (AHSentinel)" im Aussehen von "Mögliche Materialien": Icon · Name · Dropchance ·
-- Wert pro Stück (AH-Preis aus dem letzten Scan, sonst Marktwert). Chance aus derselben Quelle wie die Kurzzeile.
-- zurück: { { icon, name, chance (0-1), price, id }, ... }
function TT:DisenchantMats(itemID)
    local D = A.Disenchant
    local _, _, _, basis, n = D:DealValue(itemID)
    local out = {}
    if basis == "actual" then
        local _, _, nn, rows = D:ActualValue(itemID)
        for _, r in ipairs(rows or {}) do
            out[#out + 1] = { id = r.id, chance = r.times / nn, price = r.price, avg = r.total / r.times, source = r.source, unsure = r.unsure }
        end
    else
        for _, r in ipairs(D:EstimateRows(itemID) or {}) do
            out[#out + 1] = { id = r.id, chance = r.chance, price = r.price, avg = r.avg, min = r.min, max = r.max, source = r.source, unsure = r.unsure }
        end
    end
    for _, m in ipairs(out) do
        m.name = A:GetItemName(m.id) or ("#" .. m.id)
        m.icon = A.GetItemIcon and A:GetItemIcon(m.id) or nil
    end
    table.sort(out, function(a, b) return a.chance > b.chance end)
    return out, basis, n
end

-- Einstellung: "short" (nur die Zeile), "mats" (mit Materialien, Standard), "all" (ganze Aufstellung)
function TT:DEMode()
    local s = self:Settings() or {}
    local m = s.tooltipDEMode
    if m == "short" or m == "mats" or m == "all" then return m end
    if s.tooltipDEDetail == false then return "short" end     -- alte Einstellung (0.65.22-0.65.25)
    return "mats"
end

function TT:AddDisenchantLines(tooltip, itemID, mode)
    mode = mode or self:DEMode()
    if A.Spieltest and A.Spieltest.activeUntil then
        pcall(A.Spieltest.OnDETooltip, A.Spieltest, itemID, self:DisenchantLines(itemID, true))
    end
    local isShift = A:API("IsShiftKeyDown")      -- über A:API: die Testroutine ersetzt nie die Blizzard-Funktion
    local shift = isShift and isShift()
    if mode == "all" or shift then
        for _, l in ipairs(self:DisenchantLines(itemID, true)) do
            if l[3] then tooltip:AddDoubleLine(l[1], l[2], 0.6, 0.6, 0.6, 0.8, 0.8, 0.8)
            else tooltip:AddDoubleLine(l[1], l[2], 0.8, 0.8, 0.8, 1, 1, 1) end
        end
        return
    end
    local short = self:DisenchantShort(itemID)
    if not short then return end
    tooltip:AddDoubleLine(short.left, short.right, 0.8, 0.8, 0.8, 1, 1, 1)
    if short.gainLeft then tooltip:AddDoubleLine("   " .. short.gainLeft, short.gainRight, 0.8, 0.8, 0.8, 1, 1, 1) end
    -- Disenchantry zeigt seinen eigenen Materialblock: dann keinen zweiten
    if mode == "mats" and not A:DisenchantryLoaded() then
        local mats = self:DisenchantMats(itemID)
        if #mats > 0 then
            tooltip:AddLine(L["Entzaubern – Materialien (AHSentinel)"], 1, 0.82, 0)
            for _, m in ipairs(mats) do
                local icon = m.icon and ("|T" .. tostring(m.icon) .. ":14:14:0:0|t ") or ""
                local pct = m.chance * 100
                -- gleicher Preis wie in der Summe (D:MatPrice); Quelle dabei: AH aktuell / Markt / eigener Verkauf
                local src = m.source == "ah" and L["AH aktuell"] or (m.source == "sale" and L["eigener Verkauf"] or L["Markt"])
                if m.unsure then src = src .. " |cffff9933(" .. L["Angebot unsicher"] .. ")|r" end
                -- Menge: aus der Tabelle "min–max", aus echten Entzauberungen der Durchschnitt
                local qtyText = (m.min and m.max) and ((m.min == m.max) and tostring(m.min) or (m.min .. "–" .. m.max)) or string.format("%.1f", m.avg or 1)
                tooltip:AddDoubleLine(string.format("%s%s  %s%% × %s", icon, m.name, pct >= 10 and string.format("%d", pct + 0.5)
                    or string.format("%.1f", pct), qtyText), m.price and (A:FormatMoney(m.price) .. " |cff999999" .. src .. "|r")
                    or L["kein Preis"], 1, 1, 1, 1, 1, 1)
            end
        end
    end
end

-- Zusatzzeilen: beim Händler kaufen, Entzauberungswert, Bestand der Twinks
function TT:AddExtraLines(tooltip, itemID)
    local s = self:Settings() or {}
    local atMerchant = type(MerchantFrame) == "table" and MerchantFrame.IsShown and MerchantFrame:IsShown()
    local buy = A:GetVendorBuyPrice(itemID)
    if buy and not atMerchant then
        tooltip:AddDoubleLine(L["Beim Händler kaufen"], A:FormatMoney(buy), 0.8, 0.8, 0.8, 1, 1, 1)
    end
    if s.tooltipDE ~= false and A.Disenchant then
        pcall(self.AddDisenchantLines, self, tooltip, itemID)
    end
    if s.tooltipChance ~= false and A.Comfort then
        local chance = A.Comfort:ChanceText(itemID)
        if chance then tooltip:AddDoubleLine(L["Verkaufschance (deine)"], chance, 0.8, 0.8, 0.8, 1, 1, 1) end
    end
    if s.tooltipChars ~= false and A.Chars then
        local list, total = A.Chars:ItemCounts(itemID)
        local others = 0
        for _, c in ipairs(list) do if not c.me then others = others + 1 end end
        if others > 0 then
            local parts = {}
            for k, c in ipairs(list) do
                if k > 4 then table.insert(parts, "..."); break end
                local n = c.bags + c.bank
                local where = (c.bank > 0 and c.bags == 0) and L[" (Bank)"] or ""
                table.insert(parts, c.name .. " " .. n .. where)
            end
            tooltip:AddDoubleLine(string.format(L["Bestand (%d)"], total), table.concat(parts, ", "), 0.8, 0.8, 0.8, 1, 1, 1)
        end
    end
end

-- Item-ID aus Tooltip-Daten oder Tooltip-Link
-- WoW Forever: geschützte Werte ("secret values") nie vergleichen, zerlegen oder als Schlüssel benutzen
local function AnySecret(...)
    local G = _G.GoldSentinelGame
    return G and G.AnySecret and G.AnySecret(...) or false
end

local function ItemIDOf(tooltip, data)
    if type(data) == "table" and type(data.id) == "number" then
        if AnySecret(data.id) then return nil end
        return data.id
    end
    if tooltip.GetItem then
        local ok, _, link = pcall(tooltip.GetItem, tooltip)
        if ok and type(link) == "string" and not AnySecret(link) then
            local id = link:match("item:(%d+)")
            if id then return tonumber(id) end
        end
    end
    return nil
end

local MAIN_TIPS = {}      -- Tooltips, unter denen das Diagramm erscheinen darf

function TT:Handle(tooltip, data)
    if not A.db or type(tooltip) ~= "table" or not tooltip.AddLine then return end
    local itemID = ItemIDOf(tooltip, data)
    if not itemID then return end
    -- jede Tooltip-Anzeige nur einmal ergänzen. Nicht nur am Item festmachen: Manche Clients
    -- (z. B. TBC Anniversary) bauen den Tooltip neu auf, ohne OnTooltipCleared auszulösen -
    -- dann fehlen unsere Zeilen wieder, und das erkennen wir an der Zeilenzahl.
    local n = tooltip.NumLines and tooltip:NumLines() or 0
    if tooltip.__ahapItem == itemID and tooltip.__ahapN and n >= tooltip.__ahapN then return end
    tooltip.__ahapItem = itemID
    self:AddLines(tooltip, itemID)
    tooltip.__ahapN = tooltip.NumLines and tooltip:NumLines() or 0
    if MAIN_TIPS[tooltip] then self:ShowChart(tooltip, itemID) end
    -- Größe an die neuen Zeilen anpassen (sonst bleiben sie unsichtbar)
    if tooltip.__ahapN > n and tooltip.IsShown and tooltip:IsShown() and tooltip.Show then tooltip:Show() end
end

local function Cleared(tooltip)
    tooltip.__ahapItem, tooltip.__ahapN = nil, nil
    TT:HideChart(tooltip)
end

-- ------------------------------------------------------------
-- Einhängen (neue Clients: TooltipDataProcessor, ältere: OnTooltipSetItem)
-- ------------------------------------------------------------
function TT:Install()
    if self.installed then return end
    self.installed = true
    for _, tip in ipairs({ GameTooltip, ItemRefTooltip }) do
        if type(tip) == "table" then
            MAIN_TIPS[tip] = true
            if tip.HookScript then
                pcall(tip.HookScript, tip, "OnTooltipCleared", Cleared)
                pcall(tip.HookScript, tip, "OnHide", Cleared)
            end
        end
    end
    local handler = function(tooltip, data)
        local ok, err = pcall(TT.Handle, TT, tooltip, data)
        if not ok then
            A:ReportError("Tooltip", err)          -- jeden Fehler melden, der Chat-Hinweis bleibt einmalig
            if not TT.reported then
                TT.reported = true
                A:Print("Tooltip: " .. tostring(err))
            end
        end
    end
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, handler)
        self.mode = "TooltipDataProcessor"
    else
        local tips = { GameTooltip, ItemRefTooltip, ShoppingTooltip1, ShoppingTooltip2 }
        for _, tip in ipairs(tips) do
            if type(tip) == "table" and tip.HookScript then
                pcall(tip.HookScript, tip, "OnTooltipSetItem", function(t) handler(t) end)
                if not MAIN_TIPS[tip] then pcall(tip.HookScript, tip, "OnTooltipCleared", Cleared) end
            end
        end
        self.mode = "OnTooltipSetItem"
    end
    -- zusätzlich direkt an den Befehlen, die einen Item-Tooltip füllen: falls der Weg oben
    -- auf einem Client nicht greift (doppelte Zeilen verhindert Handle)
    local hooked = 0
    for _, tip in ipairs({ GameTooltip, ItemRefTooltip }) do
        if type(tip) == "table" then
            for _, m in ipairs({ "SetBagItem", "SetInventoryItem", "SetHyperlink", "SetItemByID", "SetAuctionItem",
                "SetAuctionSellItem", "SetMerchantItem", "SetBuybackItem", "SetLootItem", "SetInboxItem", "SetSendMailItem",
                "SetTradePlayerItem", "SetTradeTargetItem", "SetQuestItem", "SetQuestLogItem", "SetGuildBankItem" }) do
                if type(tip[m]) == "function" and pcall(hooksecurefunc, tip, m, function(t) handler(t) end) then hooked = hooked + 1 end
            end
        end
    end
    if hooked > 0 then self.mode = self.mode .. "+Set*" end
end

function TT:GetDebugText()
    return "Modus=" .. tostring(self.mode) .. ", Zeilen=" .. ((A.db and A.db.settings.tooltipInfo == false) and "aus" or "an")
        .. ", Händlerpreis=" .. ((A.db and A.db.settings.tooltipVendor == false) and "aus" or "an")
        .. ", Diagramm=" .. self:PeriodLabel()
end

A:On("READY", function() TT:Install() end)
