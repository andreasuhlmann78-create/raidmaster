-- LevelPilot - Geführte Wegmessung (/lp wegmessung) für das Messwerkzeug GSWegMess (Supervisor 16.11. 00:48)
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- GSWegMess (Prüfsystem, shared/messtest) schreibt passiv mit, an welchen Zeichen das Spiel Ebenen erkennen lässt. Dieses
-- Modul führt den Spieler Schritt für Schritt durch die vier Testläufe aus der GSWegMess-Anleitung: welche Strecke laufen,
-- wann markieren. "Markieren & weiter" setzt eine Notiz über GSWegMess.Mark (öffentliche Funktion des Werkzeugs; GSWegMess
-- selbst wird nicht verändert). Wo ein Ziel bekannt ist, zeigt der Pfeil hin (Auktionshaus, Bethor Iceshard, Höhleneingang).
-- Läuft GSWegMess nicht, startet es auf Knopfdruck (GSWegMess.Start); fehlt es, sagt LevelPilot, wo es liegt.

local _, LP = ...
local L = LP.L
local WM = {}
LP:RegisterModule("WegMessung", WM)

-- Ziele: Unterstadt-Auktionshaus (wie Test UC-W1), Bethor Iceshard (NPC 1498 aus dem Datenpaket), naechste bekannte Hoehle
local AH = { 1458, 64.3, 35.9 }
local function NpcPos(id)
    local n = _G.LevelPilotData and LevelPilotData.N and LevelPilotData.N[id]
    local s = n and n.s and n.s[1]
    if s then return { s[1], s[2], s[3] } end
end
local function NearestCave()
    local Ca = LP.Caves
    if not (Ca and Ca.All) then return nil end
    local pi, pn, pw = LP.Geo:Player()
    local best, bd
    for _, c in ipairs(Ca:All() or {}) do
        if pi and c.inst == pi then
            local d = LP.Geo:Dist(pn, pw, c.n, c.w)
            if not bd or d < bd then best, bd = c, d end
        end
    end
    if not best then return nil end
    local x, y = LP.Geo:ToMap(best.map, best.inst, best.n, best.w)
    if not x then return nil end
    return { best.map, x, y, best.name }
end

-- Ortsnamen in der Sprache des Spiels (Tabelle AreaNames, Kartennamen, NPC-Namen aus dem Datenpaket)
local function Names()
    local G = LP.Graph
    local function area(key, map)
        local n = G and G.SubName and G.SubName("#" .. key)
        if n and n ~= "#" .. key then return n end
        return map and LP.Geo:MapName(map) or key
    end
    return {
        uc = area("1497", 1458), mq = area("1497:Magic Quarter"), ruins = area("1497:Ruins of Lordaeron"),
        tb = area("1638", 1456), mulgore = LP.Geo:MapName(1412),
        bethor = (LP.Names and LP.Names.Npc and LP.Names:Npc(1498)) or "Bethor Iceshard",
    }
end
WM.Names = Names

-- Laeufe: { Titel, Titel-Namen, { { Text, Text-Namen, Notiz, Ziel-Funktion (optional) }, ... } }
WM.RUNS = {
    { "%s: Auktionshaus -> %s und zurück", { "uc", "mq" }, {
        { "Geh zum Auktionshaus von %s (Pfeil). Dort „Markieren & weiter“.", { "uc" }, "L1 Auktionshaus", function() return AH, L["Auktionshaus"] end },
        { "Lauf zu %s (%s, Pfeil). Dort markieren.", { "bethor", "mq" }, "L1 Bethor Iceshard", function() return NpcPos(1498), Names().bethor end },
        { "Lauf zurück zum Auktionshaus. Dort markieren.", {}, "L1 zurück am Auktionshaus", function() return AH, L["Auktionshaus"] end },
    } },
    { "%s: Aufzug hinunter, anderer Aufzug hinauf", { "uc" }, {
        { "Geh hinauf (%s) zu einem Aufzug. Markieren, BEVOR du einsteigst.", { "ruins" }, "L2 Aufzug oben vor dem Einsteigen" },
        { "Fahre hinunter. Markieren, sobald du unten ausgestiegen bist.", {}, "L2 Aufzug unten ausgestiegen" },
        { "Geh durch die Stadt zu einem ANDEREN Aufzug. Markieren, bevor du einsteigst.", {}, "L2 anderer Aufzug unten vor dem Einsteigen" },
        { "Fahre hinauf. Markieren, sobald du oben ausgestiegen bist.", {}, "L2 anderer Aufzug oben ausgestiegen" },
    } },
    { "%s: Aufzug von unten nach oben", { "tb" }, {
        { "Geh in %s zum Fuss eines Aufzugs von %s. Markieren, bevor du einsteigst.", { "mulgore", "tb" }, "L3 Aufzug unten vor dem Einsteigen" },
        { "Fahre hinauf. Markieren, sobald du oben ausgestiegen bist.", {}, "L3 Aufzug oben ausgestiegen" },
    } },
    { "Eine Höhle hinein und hinaus", {}, {
        { "Geh zum Eingang einer Höhle (Pfeil: nächster bekannter Eingang). Am Eingang markieren.", {}, "L4 Höhleneingang draussen",
          function() local c = NearestCave() return c, c and c[4] or nil end },
        { "Geh hinein, bis ganz nach hinten. Dort markieren.", {}, "L4 Höhle hinten" },
        { "Geh wieder hinaus ins Freie. Draussen markieren.", {}, "L4 wieder draussen" },
    } },
}
-- Text mit Ortsnamen
local function Fill(fmt, keys)
    local n, args = Names(), {}
    for i, k in ipairs(keys or {}) do args[i] = n[k] or "?" end
    if #args == 0 then return L[fmt] end
    return L(fmt, unpack(args))
end
WM.Fill = Fill

WM.state = nil      -- { run = Nummer, step = Nummer, marks = Anzahl }

function WM.Tool() return GSWegMess end      -- globale Tabelle des Messwerkzeugs (nur lesen/aufrufen)
local function Tool() return WM.Tool() end
function WM.ToolReady() local t = Tool() return t and t.Running and t.Start and t.Mark and true or false end

local function Steps() local r = WM.state and WM.RUNS[WM.state.run] return r and r[3] end

-- Ziel des aktuellen Schritts im Guide (Pfeil); ohne Ziel bleibt das bisherige Ziel unveraendert
local function Guide()
    local st = Steps() and Steps()[WM.state.step]
    local fn = st and st[4]
    if not fn then return end
    local ok, pos, title = pcall(fn)
    if ok and pos and _G.LevelPilotAPI and _G.LevelPilotAPI.NavigateTo then
        _G.LevelPilotAPI.NavigateTo(pos[1], pos[2], pos[3], title or L["Wegmessung"])
    end
end

function WM:Start()
    if not Tool() then
        LP:Reply(L["Wegmessung: Das Messwerkzeug GSWegMess fehlt. Es liegt im Prüfsystem (shared/messtest/GSWegMess.zip) – entpacken nach Interface/AddOns, dann /reload."])
        return false
    end
    self.state = { run = 1, step = 1, marks = 0 }
    if not Tool().Running() then pcall(Tool().Start) end
    self:Show()
    Guide()
    return true
end

-- "Markieren & weiter": Notiz in GSWegMess, naechster Schritt (am Ende eines Laufs der naechste Lauf)
function WM:Mark()
    local st = self.state
    local steps = Steps()
    if not (st and steps) then return end
    local note = steps[st.step][3]
    local t = Tool()
    if t and not t.Running() then pcall(t.Start) end
    if t and t.Mark(note) then st.marks = st.marks + 1 end
    self:Advance()
end

function WM:Advance()
    local st = self.state
    if not st then return end
    st.step = st.step + 1
    if st.step > #(Steps() or {}) then st.run, st.step = st.run + 1, 1 end
    if st.run > #self.RUNS then return self:Finish() end
    self:Show()
    Guide()
end

function WM:SkipRun()
    local st = self.state
    if not st then return end
    local t = Tool()
    if t and t.Running() then pcall(t.Mark, ("L%d übersprungen"):format(st.run)) end
    st.run, st.step = st.run + 1, 1
    if st.run > #self.RUNS then return self:Finish() end
    self:Show()
    Guide()
end

function WM:Finish()
    local marks = self.state and self.state.marks or 0
    self.state = nil
    if self.frame then self.frame:Hide() end
    local t = Tool()
    if t and t.Running() and t.Stop then pcall(t.Stop, "LevelPilot fertig") end
    LP:Reply(L("Wegmessung fertig (%d Markierungen). Jetzt /reload und die Datei SavedVariables/GSWegMess.lua schicken.", marks))
end

------------------------------------------------------------------------
-- Fenster
------------------------------------------------------------------------
function WM:Frame()
    if self.frame then return self.frame end
    local UI = LP.UI
    local f = CreateFrame("Frame", "LevelPilotWegMessung", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    f:SetSize(400, 140)
    f:SetPoint("TOP", 0, -120)
    f:SetFrameStrata("DIALOG")
    if UI and UI.Skin then UI:Skin(f) end
    f.title = UI:Text(f, 13)
    f.title:SetPoint("TOPLEFT", 12, -10)
    f.title:SetWidth(376)
    f.text = UI:Text(f, 12)
    f.text:SetPoint("TOPLEFT", 12, -46)
    f.text:SetWidth(376)
    f.mark = UI:Button(f, L["Markieren & weiter"], 140, 22, function() WM:Mark() end)
    f.mark:SetPoint("BOTTOMLEFT", 12, 10)
    f.skip = UI:Button(f, L["Lauf überspringen"], 120, 22, function() WM:SkipRun() end)
    f.skip:SetPoint("BOTTOM", 20, 10)
    f.stop = UI:Button(f, L["Beenden"], 90, 22, function() WM:Finish() end)
    f.stop:SetPoint("BOTTOMRIGHT", -12, 10)
    self.frame = f
    return f
end

function WM:Show()
    local st = self.state
    local run = st and self.RUNS[st.run]
    if not run then return end
    local f = self:Frame()
    local step = run[3][st.step]
    f.title:SetText(L("Wegmessung Lauf %d/%d: %s · Schritt %d/%d", st.run, #self.RUNS, Fill(run[1], run[2]), st.step, #run[3]))
    f.text:SetText(Fill(step[1], step[2]))
    f:Show()
end

function WM:Init() end
