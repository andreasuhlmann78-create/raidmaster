-- BuffSentinel – Diagnose-Protokoll (aus der GoldSentinel-Vorlage shared/vorlage/__ADDON__/Diag.lua)
-- Copyright (c) 2026 GoldSentinel. All Rights Reserved.
--
-- Wozu: Fehler, die nur im echten Spiel auftreten (gesperrte Auren, langsame Anzeige, Fehlerschleifen), schreibt
-- BuffSentinel selbst mit. Der Spieler sieht das Protokoll mit /bsen protokoll – oder es geht automatisch als
-- "GSDIAG1"-Zeichenkette (BuffSentinelDB.diagExport) über die SavedVariables und den RaidMasterUploader an die Prüfung.
--
-- Benutzung im Code:
--   BS.Diag("FEHLER", "Event UNIT_AURA: …")       -- Art, Text, optional Dauer in ms
--   BS.Timed("Anzeige", fn, ...)                   -- misst fn; über BS.DIAG_SLOW_MS -> Eintrag LANGSAM
-- Gleiche Art + gleicher Text direkt hintereinander werden nur gezählt (×N) – keine Schleife im Protokoll.
--
-- Regeln: KEINE Spieler-, Charakter-, Gilden- oder Realmnamen (das Protokoll landet im öffentlichen Repo).
--         In der Testroutine schreibt das Protokoll nur in die Sandbox-Datenbank; beim Ausloggen wird dann nichts abgelegt.

local ADDON, BS = ...
local L = BS.L

BS.DIAG_MAX = 200          -- höchstens so viele Einträge, älteste fallen weg
BS.DIAG_SLOW_MS = 16       -- ein Frame bei 60 fps
BS.DIAG_PREFIX = "GSDIAG1"
BS.DIAG_EXPORT_MAX = 60000 -- Zeichen in der SavedVariables-Zeichenkette

local function Stamp() return date and date("%d.%m. %H:%M") or "" end
local function Clean(s)
    if BS.IsSecret(s) then return "?" end
    s = tostring(s or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("[\r\n|]", " ")
    return s
end

local function Store()
    local g = BS.gdb
    if type(g) ~= "table" then return nil end
    if type(g.diag) ~= "table" then g.diag = {} end
    if type(g.diag.entries) ~= "table" then g.diag.entries = {} end
    if type(g.diag.sessions) ~= "table" then g.diag.sessions = {} end
    return g.diag
end

-- Einen Eintrag schreiben. Gleiche Art + gleicher Text direkt hintereinander -> nur Zähler erhöhen.
function BS.Diag(kind, text, ms)
    local d = Store()
    if not d then return end
    kind, text = Clean(kind):upper(), Clean(text)
    if #text > 300 then text = text:sub(1, 300) end
    local e = d.entries[1]
    if type(e) == "table" and e.k == kind and e.t == text then
        e.n = (e.n or 1) + 1
        e.z = Stamp()
        if ms then e.ms = math.max(e.ms or 0, math.floor(ms + 0.5)) end
        return e
    end
    e = { k = kind, t = text, z = Stamp(), n = 1, ms = ms and math.floor(ms + 0.5) or nil, v = BS.version }
    table.insert(d.entries, 1, e)
    for i = #d.entries, BS.DIAG_MAX + 1, -1 do d.entries[i] = nil end
    return e
end

local function Clock() return debugprofilestop and debugprofilestop() or ((GetTime and GetTime() or 0) * 1000) end

-- fn messen; langsamer als ein Frame -> LANGSAM. Fehler laufen wie bisher an den Aufrufer weiter.
function BS.Timed(name, fn, ...)
    local t0 = Clock()
    local res = { pcall(fn, ...) }
    local ms = Clock() - t0
    if ms > BS.DIAG_SLOW_MS then BS.Diag("LANGSAM", name, ms) end
    if not res[1] then error(res[2], 0) end
    return (unpack or table.unpack)(res, 2)
end

-- Sitzung beim Einloggen vermerken (nur Stufe, Klasse, Spielversion – kein Name)
function BS.DiagSession()
    local d = Store()
    if not d then return end
    local lvl = UnitLevel and UnitLevel("player") or 0
    local _, class = UnitClass("player")
    table.insert(d.sessions, 1, { z = Stamp(), lvl = BS.IsSecret(lvl) and 0 or lvl, class = class or "?",
        v = BS.version, f = BS.flavor })
    for i = #d.sessions, 21, -1 do d.sessions[i] = nil end
end

-- Zusatzzeilen: Zustand, der bei Fehlern im Spiel hilft
local function Extra()
    local out = {}
    local E = BS.errors or { count = 0, byArea = {} }
    out[#out + 1] = string.format(L.DIAG_ERRORS_SESSION, E.count or 0)
    for area, n in pairs(E.byArea or {}) do out[#out + 1] = "  " .. Clean(area) .. ": " .. n end
    out[#out + 1] = string.format(L.DIAG_STATE, tostring(BS.flavor), BS:Locked() and L.YES or L.NO,
        BS.hasCombatLog and L.YES or L.NO, BS.auraDenied or 0)
    return out
end

-- Das Protokoll als Text (für das Kopierfenster und den Export)
function BS.DiagText()
    local d = Store() or { entries = {}, sessions = {} }
    local G = GoldSentinelGame
    local out = {}
    local function add(s) out[#out + 1] = s end
    add(string.format(L.DIAG_HEADER, ADDON, tostring(BS.version), Stamp()))
    add(string.format("Client %s · %s", tostring(GetLocale and GetLocale() or "?"), G and G.Status and Clean(G.Status()) or "?"))
    add(string.format(L.DIAG_SESSIONS, #d.sessions))
    for i = 1, math.min(#d.sessions, 10) do
        local s = d.sessions[i]
        add(string.format("  %s L%s %s v%s %s", tostring(s.z or ""), tostring(s.lvl), tostring(s.class), tostring(s.v), tostring(s.f or "")))
    end
    add("")
    add(L.DIAG_SECTION)
    for _, line in ipairs(Extra()) do add("  " .. Clean(line)) end
    add("")
    add(string.format(L.DIAG_ENTRIES, #d.entries))
    for _, e in ipairs(d.entries) do
        add(string.format("[%s] %s%s %s%s", tostring(e.z or ""), tostring(e.k or "?"), (e.n or 1) > 1 and (" ×" .. e.n) or "",
            tostring(e.t or ""), e.ms and (" · " .. e.ms .. " ms") or ""))
    end
    return table.concat(out, "\n")
end

-- Zeichenkette für den Uploader (wie GSTEST1): Präfix, Addon, Version, dann der Text
function BS.DiagExport()
    local text = BS.DiagText()
    if #text > BS.DIAG_EXPORT_MAX then text = text:sub(1, BS.DIAG_EXPORT_MAX) end
    return BS.DIAG_PREFIX .. "|" .. ADDON .. "|" .. tostring(BS.version) .. "|" .. text
end

function BS.ShowDiag()
    local text = BS.DiagText()
    if BS.Selftest and BS.Selftest.ShowReport then
        BS.Selftest:ShowReport(text, L.DIAG_TITLE)
    else
        for line in text:gmatch("[^\n]+") do BS.Print(line) end
    end
end

-- automatisches Senden an/aus (Standard: an)
function BS.DiagSendEnabled()
    return not (BS.gdb and BS.gdb.diagSend == false)
end

function BS.SetDiagSend(on)
    if not BS.gdb then return end
    BS.gdb.diagSend = on and true or false
    if not on then BS.gdb.diagExport = nil end
end

-- Beim Ausloggen / /reload die Export-Zeichenkette in die SavedVariables legen (nicht während der Testroutine)
function BS:PLAYER_LOGOUT()
    if not self.gdb or (BS.Selftest and BS.Selftest.running) then return end
    if not BS.DiagSendEnabled() then self.gdb.diagExport = nil; return end
    local ok, s = pcall(BS.DiagExport)
    if ok then self.gdb.diagExport = s end
end
