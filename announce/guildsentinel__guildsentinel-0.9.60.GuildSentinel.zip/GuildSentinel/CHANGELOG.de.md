# GuildSentinel – Änderungen

## 0.9.60
- Raid-Bereitschaft ohne Schätzung: „raidfähig in n Wochen (aus x Spielern, y Tage gemessen)“ statt „beim jetzigen Tempo in ~n Wochen“. Unter 3 Spielern mit gemessenem Tempo oder unter 7 Tagen Messung steht „noch zu wenig Daten“ (auch im Bericht an Discord keine Wochenzahl). Das Tempo wird jetzt durch die wirklich gemessenen Tage geteilt (höchstens 14; vorher immer durch 14).
- Stufen-Zuwachs: die Stufe, mit der ein Mitglied beitritt, zählt nicht mehr als Aufstieg (neue Mitglieder hatten eine Stufe zu viel – Rangliste „Stufen in den letzten 7 Tagen“ und Raid-Bereitschaft).
- „Erster auf Höchststufe“: stammt das Datum nur aus der Mitgliederliste (kein eigenes Ereignis), steht „spätestens am <Tag>“ statt eines genauen Zeitpunkts.
- Bewerber-Tooltip: „Erstmals“ steht gleich unter dem Namen (vorher ganz unten).
- Protokoll beim Zusammenführen der Gildendaten nennt die Einträge je altem Schlüssel („vorher 802 = 479 + 323“).
- Für den Entwickler: Testroutine prüft L5 (Hauptzahl oben in jedem Tooltip mit Zahlen, T317) statt es zu überspringen.

## 0.9.59
- Gildendaten ohne Realm: Auf WoW Forever liefert das Spiel je Charakter einen anderen Heimat-Realm – dieselbe Gilde lag dadurch unter mehreren Schlüsseln (Mitglieder, Protokoll, Verwaltung getrennt). Jetzt gilt „Fraktion + Gilde“. Alte Einträge werden beim Einloggen einmal zusammengeführt: nichts doppelt, frühere Beitrittszeit, neuere Stände gewinnen; die alten Daten bleiben als Sicherung (guildsOld), Zahlen vorher/nachher im Protokoll (/gs protokoll, Zeile GILDE). „Meine Woche“ zeigt die Charaktere aller Heimat-Realms.
- Seite Mitglieder: wird nach dem Öffnen des Fensters in einem eigenen Bild vorgebaut, das erste Anwählen füllt nur noch; die Zahlen der Liste werden je Anwählen einmal gerechnet (vorher bis zu dreimal). Bei einem langsamen Anwählen nennt das Protokoll die Teile (lesen/filtern/sortieren, Zeilen, Zahlen, Einzelheiten).
- Rekrutierung: statt des weissen Blocks „Platzhalter: {gilde} {fraktion} …“ ein kleiner Knopf „Platzhalter (?)“ – der Tooltip nennt jeden Platzhalter mit Bedeutung (Werbung, automatische Antwort, Begrüssung, Absage). „Leer lassen = Standardtext“ steht grau im leeren Werbefeld.
- Lesbarkeit: die gewählte Zeile einer Liste hat jetzt einen Akzentstreifen links und eine schwächere Fläche (graue und rote Schrift blieb darauf zu schwach); Versionsnummer in der Titelleiste heller; jede Spalte hat eine Überschrift.
- „Wer ist frei“: „Frei melden“ und „Nicht mehr frei“ stehen in eigener Zeile (ragten in 6 von 10 Sprachen aus dem Fenster); der Absage-Text hat Hinweis und Knopf unter dem Feld.
- Entwickler-Befehle (sync test, protokoll, clienttest, debug) stehen in Hilfe und Befehlsliste nur noch im Entwicklermodus.
- Gemeinsame Dateien: GoldSentinelSync 3 und GoldSentinelTakt 3.
- Für den Entwickler: Testroutine misst zuerst 10 s die Umgebung (Ort, Ping, Bilder/s; Zeile „Umgebung“ im Bericht), vergleicht auch die geteilten Daten (Sync-Adressbuch, Sync- und Markt-Speicher) vor/nach dem Lauf (SHARED) und prüft Lesbarkeit L1–L8 (T311–T318) sowie Bedienelemente im Fenster (T319). Gefunden und behoben: T293 legte im echten Marktspeicher ein leeres Fach an.

## 0.9.58
- Leistung: Ab 100 Mitgliedern liest GuildSentinel die Mitgliederliste als Aufgabe des gemeinsamen Takts – am Stück nur das Lesen, die Notizen in Portionen, Vergleich am Ende. Vorher lief alles in einem Bild (im Spiel 16 ms bei 500 Mitgliedern, alle 30 Sekunden). Während der Portionen bleibt der Main aus der Notiz stehen (kein Flackern).
- Leistung: Notizen wie „Twink von X“, deren Main nicht mehr in der Gilde ist, liefen bei jedem Lesen für jeden Twink einmal über die ganze Liste. Jetzt wird das Ergebnis je Name gemerkt (im Nachbau 500 Mitglieder: 216 ms → 5 ms).
- Titelleiste rechts im Stil des Fensters: flaches Schliessen-X (statt Blizzard-X), „Unterstützen“ zurückhaltend als kleines Münz-Symbol mit Tooltip (statt grauem Knopf), Gildeninfo mit Abstand – alles gleich hoch und auf einer Linie.
- Für den Entwickler: Testroutine prüft das gemeinsame Sync-Adressbuch auf Testnamen (T308), die Titelleiste (T309) und dass jede Spieler-Funktion ohne Entwicklermodus erreichbar ist (T310); T138 misst Median aus 3 Läufen und das längste Bild in Portionen.

## 0.9.57
- Neue Optionen nach Vorbild AHSentinel (Einstellungen > Optionen): links die Bereiche (Allgemein, Chat & Tooltip, Ansagen, Gruppensuche, Rekrutierung, Daten & Abgleich, Funktionen: Gemeinschaft, Funktionen: Gilde & Raid, Leitung), rechts nur die Optionen des gewählten Bereichs in einer Spalte, ohne Scrollen. Oben ein Suchfeld über alle Bereiche (z. B. „ton“). Jede Zeile: kurze Beschriftung, rechts ein Knopf „an“/„aus“ (bzw. eine Knopfreihe), die Erklärung im Tooltip. „Standard“ je Bereich, Seltenes unter „Weitere“.
- Jede Option steht genau einmal da. Schalter, die bei ihrem eigenen Text stehen (automatische Antwort, Begrüssung, Bewerbungsfragen, Mindestalter, Werbe-Kanäle, Rolle in der Gruppensuche, Beförderung, Aufstellung), bleiben dort – in den Optionen springt ein Verweis direkt hin. Die Werbe-Erinnerung und „Alte Bewerbungen löschen“ sind von der Seite Rekrutierung in die Optionen umgezogen; dort öffnet ein Knopf „Optionen“ den Bereich Rekrutierung (ebenso auf der Seite Gruppensuche).
- Eine ausgeschaltete Funktion öffnet beim Anklicken direkt ihren Bereich in den Optionen.
- Alle gespeicherten Einstellungen bleiben unverändert gültig (gleiche Felder wie vorher).
- Für den Entwickler: Prüflisten-Punkt „OPT Optionen am Bild“ (dafür ist der im Spiel erledigte Punkt „Rechtsklick-Menü“ entfernt); Testroutine prüft jede Option (T307a–e) und meldet, welche alten Spiel-Funktionen der Client hat (T306).

## 0.9.56
- Fehlerbehebung: Der Wochenrückblick im Gildenchat meldete Erstkills, die es nie gab. Ursache: GuildSentinel las die Erstkills von RaidMaster, während RaidMasters Testroutine lief – und damit dessen Testdaten. Jetzt liest GuildSentinel während der Testroutine eines anderen Addons (und während der eigenen) gar keine Daten anderer Addons. Ein Erstkill zählt nur noch mit Eintrag im Raid-Protokoll (Boss-Kill mit Zeit), als Datum gilt die Zeit aus dem Protokoll.
- Einmalige Bereinigung: Erstkill-Meilensteine ohne Beleg im Raid-Protokoll werden beim nächsten Einloggen (mit RaidMaster) entfernt und mit Datum im Protokoll (/gs protokoll) vermerkt; auch die zweite Kopie auf anderen Rechnern der Gilde entfernt sie beim Abgleich. Ein echter späterer Kill wird wieder eingetragen.
- Ansagen im Gildenchat werden zurückgehalten, solange ein anderes GoldSentinel-Addon seine Testroutine laufen lässt.
- Einzahl/Mehrzahl im Wochenrückblick in allen Sprachen: „1 neues Mitglied“, „1 Stufe“, „1 neuer 60er“ (Russisch mit drei Formen).
- Neu für andere Addons: GuildSentinelAPI.TestRunning().
- Für den Entwickler: die Testroutine ruft UpdateAddOnMemoryUsage nicht mehr auf (im Spiel selbst ein Ruckler von 51,5 ms); der Bericht nennt stattdessen den angelegten Speicher je Bereich und die fünf grössten Prüfungen. Das Diagnose-Protokoll rechnet die Marktnetz-Zeilen höchstens einmal je Minute und in der Testroutine gar nicht (ging bei jedem Aufruf über alle Items des Marktspeichers – im Spiel ein Bild von 45 ms in T188 und 43 ms in T198).

## 0.9.55
- Robuster bei beschädigten Gildendaten: Abgleich-Antwort, Termine, Dank und Online-Tage überspringen kaputte Einträge, statt mit einem Lua-Fehler abzubrechen (gefunden, weil die Testroutine jetzt im Takt läuft und Zeitgeber dazwischen arbeiten). Beim Einloggen werden kaputte Dank-Einträge entfernt.
- Für den Entwickler: die Testroutine macht keine ganze Speicherbereinigung mehr (leistung.md Bau-Regel 2) und nennt, wie lange die Speichermessung selbst dauert; T118 prüft jetzt auch alle Zeitgeber- und Abgleich-Wege mit kaputten Daten.

## 0.9.54
- Schneller bei grossen Gilden: „Inaktive“ (Leitung, Übersicht, Aufräumen) rechnete bei vielen Mitgliedern quadratisch – bei 500 Mitgliedern spürbar (Ruckler). Jetzt in einem Durchgang, Ergebnis gleich.
- Einstellungen: die Sprachauswahl ist breit genug für „wie der Spiel-Client (Deutsch)“.
- Eingabefelder: ist ein Text oder Hinweis länger als das Feld, zeigt der Tooltip beim Darüberfahren den ganzen Text (bisher hing der Tooltip am Rand und kam fast nie).
- Gildenerfolge: zu lange Zeilen („fehlt: …“) ganz im Tooltip.
- Auswahlen und Tabellen in längeren Sprachen: Zahlen werden nie abgeschnitten (Beute-Wünsche, Zugänge, Aufräumen, Übersicht-Kacheln zweizeilig, Empfehlung bei den Probemitgliedern, „Wer ist frei“). „Höchststufe behalten“ beim Aufräumen steht jetzt unter den Auswahlen. Koreanisch: Beute-Wunsch mit der Zahl vorne.
- Gemeinsame Datei GoldSentinelTakt (Version 1, unverändert aus shared/): die Testroutine läuft jetzt im gemeinsamen Takt gegen Ruckeln.
- Für den Entwickler: Testroutine hält zwischen Seiten, Reitern, Funktionen und Lagen an (im Spiel bis 355 ms am Stück); Speicher getrennt nach GuildSentinel und allen Addons; T82 zählt gemeinsame Dateien aus dem eigenen Ordner mit zurückgehaltenem Präfix als echt und nennt immer, was nicht von GuildSentinel kam; Berichte enthalten keine Namen aus dem Fenster.

## 0.9.53
- Tooltips im Hauptfenster stehen jetzt neben dem Fenster, auf Höhe des Elements (rechts, bei zu wenig Platz links). Bisher verdeckten sie in Listen und Seitenleiste andere Knöpfe desselben Fensters.
- Tabellen: Spalten wachsen bis zur Breite ihrer Überschrift und ihrer Zahlen – Zahlen und Zeiten werden nie mehr abgeschnitten (z. B. „frei bis 18:36“ in „Wer ist frei“, „Stufe“ auf Russisch, „Raid-Ziel“ auf Italienisch). Ist eine Zelle mit Text trotzdem zu lang, zeigt der Tooltip der Zeile den ganzen Text.
- Spanisch: Auswahl „offline seit … Tagen“ (Verwaltung) breiter; Russisch: „noch %d Tage“ kürzer, Zahl zuerst.
- Für den Entwickler: Die Testroutine hält im Bereich K jetzt zwischen den Schritten an (im Spiel waren es 843,8 ms in einem Stück). Ursache: ein Merker für Testwerte blieb nach der ersten Prüfung damit stehen und verhinderte jedes Anhalten danach. Meldungen zu Tooltips und abgeschnittenen Texten nennen jetzt den Text des Knopfs statt „Button in ?“. T285 prüft mit einem echten Eingabefeld (kein Fehler für Spieler). T82 („nichts gesendet“) nennt jetzt, wer gesendet hat (eigene Datei, gemeinsamer Baustein oder anderes Addon, mit Präfix und Kanal, ohne Inhalt); nur eigene Sendungen sind ein Fehler. Während der Testroutine gehen Nachrichten anderer Addons in der gemeinsamen Warteschlange jetzt normal hinaus (bisher zurückgehalten und verworfen). Mehrere Prüfungen liefen in Spanisch und Chinesisch rot, ohne Fehler im Addon – korrigiert.

## 0.9.52
- Korrektur: Als Gildenmeister (oder Offizier) waren im Rechtsklick-Menü „Befördern“, „Degradieren“, „Rang setzen …“ und „Aus der Gilde entfernen“ grau mit „Nicht über den eigenen Rang …“. Ursache: GuildSentinel suchte den eigenen Rang nur unter genau der Schreibweise des eigenen Namens; schreibt die Gildenliste den Namen anders (Gross/klein, Leerzeichen, in WoW Forever Vor- und Nachname), blieb der eigene Rang unbekannt. Jetzt wird der eigene Eintrag auch so gefunden, sonst kommt der Rang direkt vom Spiel. Ist er wirklich noch nicht geladen, steht dort „Eigener Rang noch nicht geladen – gleich noch einmal versuchen.“ und die Gildenliste wird neu angefordert.
- Dasselbe betraf die Vorschläge zum Entfernen inaktiver Mitglieder (mit unbekanntem Rang wurden auch höhere Ränge vorgeschlagen), die Twink-Rang-Vorschläge und die Erkennung „Gildenmeister“. Alle nutzen jetzt denselben Weg.
- Gemeinsame Marktdatei GoldSentinelMarkt auf Version 10 (unverändert aus shared/: Zeitprüfung öfter, kein Ruckler beim Weitergeben).
- „/gs protokoll“ zeigt eine Zeile „RANG eigener Rang: Weg=…“ (ohne Namen), damit sichtbar ist, wie der eigene Rang gefunden wurde.
- Für den Entwickler: Die Testroutine meldet Lua-Fehler, die eine Prüfung nebenbei auslöst, jetzt als eigene FEHLER-Zeile. Zwei Prüfungen (Aufräumen alter Bewerbungen) lösten bei offenem Fenster Lua-Fehler aus („Roster.lua:124 … 'alts'“) – das war ein Fehler der Prüfung selbst, nicht des Addons; behoben.

## 0.9.51
- Für den Entwickler: „/gs testroutine alles“ – alle automatischen Prüfungen auf einmal (Testroutine und die messbaren Spiel-Prüfpunkte), mit Fortschritt im Chat („Bereich 3 von 11 …“) und einer Zusammenfassung („x von y bestanden, z nicht prüfbar – Gründe“). Die Routine läuft jetzt in kleinen Portionen über viele Bilder statt in einem Stück; „/gs testroutine stop“ bricht sauber ab. Wird mitten im Lauf ausgeloggt oder neu geladen, setzt GuildSentinel zuerst alle Testdaten zurück – vor allem anderen, was beim Ausloggen gespeichert wird.
- Prüfliste (/gs prüfliste): jeder Punkt mit „Wo“, nummerierten Schritten (ein Handgriff je Schritt, Namen wie im Spiel), was du sehen solltest, und was es kostet.
- Für Spieler ändert sich nichts.

## 0.9.50
- Für den Entwickler: Prüfliste im Spiel („/gs prüfliste“, nur im Entwicklermodus) mit dem gemeinsamen Baustein GoldSentinelPruefliste (unverändert aus shared/). 14 offene Prüfpunkte mit genauer Anweisung („Das tust du … / Das musst du sehen …“); die meisten haken sich selbst ab, sobald die Funktion im Spiel wirklich benutzt wurde (Werbung gepostet, Bewerber eingeladen, Befördern bestätigt, Sperrliste, Tooltip, Notiz-Verlauf, Testroutine ohne Fehler …). Ergebnis auch in „/gs protokoll“. Für Spieler ändert sich nichts.
- Entwickler-Tests: test/run_pruefliste.lua (jede Stelle, die einen Punkt abhakt, über den echten Weg; ohne Entwicklermodus wirkungslos), T303.

## 0.9.49
- Gemeinsame Datei GoldSentinelDev.lua auf Version 2 (unverändert aus shared/): die Entwickler-Erkennung enthält keinen Charakternamen mehr im Klartext. Für Spieler ändert sich nichts.

## 0.9.48
- /gs clienttest: Die Probe zur Sperrliste hinterlässt jetzt in jedem Fall genau den Zustand von vorher (auch wenn es noch gar keine Sperrliste gab). Im normalen Spiel ändert sich dadurch nichts.
- Entwickler-Tests: test/run_clienttest.lua um diesen Fall erweitert.

## 0.9.47
- Neu: „/gs clienttest“ – geführter Test im Spiel. Geht die offenen Prüfpunkte der letzten Versionen durch (Werbetexte, Grenze für automatische Antworten, Bewerberliste, Sperrliste, Rückkehrer, Notiz-Verlauf, Seiten später bauen, Ruckler, Tooltip, Datenschutz), prüft alles Messbare selbst und fragt nur viermal kurz nach (OK / Nicht OK / Überspringen). Ergebnis: eine Zeile je Punkt in „/gs protokoll“. Der Test schickt keine Nachrichten, ändert keine Gildendaten und läuft nicht im Kampf.
- Entwickler-Tests: test/run_clienttest.lua (alle Antworten, Lua-Fehler in einem Punkt, keine Nachricht, Daten unverändert).

## 0.9.46
- Schneller beim ersten Öffnen: Das Fenster baut jetzt nur die Seite, die du anwählst – die anderen erst, wenn du sie zum ersten Mal öffnest. Vorher entstanden beim ersten Öffnen alle Seiten auf einmal (über 800 Fensterteile und 1300 Texte/Bilder in einem Bild); jetzt sind es für die Startseite 48 und 125. Im Nachbau: erstes Öffnen 14,8 ms -> 2,8 ms. Diagnose-Protokoll: „Seite bauen <Seite>“, falls eine Seite länger als ein Bild braucht.
- Entwickler-Tests: test/run_g4.lua erweitert (nur die angewählte Seite gebaut, jede nur einmal, mit Gegenprobe), Messskript test/perf_open.lua.

## 0.9.45
- Neu: Rückkehrer. Kommt ein Mitglied nach mindestens 30 Tagen wieder online (und war auch kein anderer Charakter desselben Spielers da), steht es im Verlauf („ist nach langer Pause zurück – nach N Tagen“), und Offiziere sehen im Chat „Rückkehrer: … – willkommen heißen?“. Nur während der Sitzung, nicht beim ersten Lesen nach dem Einloggen (sonst wären alle „zurück“, die in deiner Abwesenheit gespielt haben).
- Neu: Notiz-Änderungen im Verlauf (Mitglieder > Verlauf): „öffentliche Notiz geändert“ und „Offiziersnotiz geändert“ mit alt → neu. Offiziersnotizen nur, wenn du sie lesen kannst.
- Entwickler-Tests: T300a–b, test/run_return.lua (11 Prüfungen mit Gegenproben).

## 0.9.44
- Neu: Sperrliste (Leitung > Sperrliste, nur Offiziere). Name und Grund eintragen; die Liste geht nur an Offiziere mit GuildSentinel. GuildSentinel schreibt einem gesperrten Spieler NIE – es warnt nur die eigene Leitung:
  - Bewirbt er sich: Er wird erfasst (Status „auf Sperrliste“), bekommt aber keine automatische Antwort und keine Fragen; im Chat steht ein Hinweis (höchstens alle 10 Minuten).
  - Einladen über GuildSentinel ist gesperrt (Meldung mit Grund).
  - Tritt er trotzdem bei: rote Warnung im Chat der Offiziere.
  - Im Spieler-Tooltip steht bei Offizieren „Auf der Sperrliste: <Grund>“.
- Entwickler-Tests: T299a–d (mit Gegenproben), test/run_ban.lua (Abgleich unter Offizieren, Seite). Neue Testskripte zählen jetzt auch abgefangene Fehler als Fehlermeldungen.

## 0.9.43
- Datenschutz: Nennt ein Bewerber sein Alter in einer Flüsternachricht oder Antwort („ich bin 15“, „17 Jahre“, „I'm 16“), wird die Zahl vor dem Speichern unkenntlich gemacht („ich bin …“). Stufen („lvl 60“, „Stufe 52“) und andere Zahlen bleiben. Das Ergebnis der Altersfrage („16+ / unter 16 / unklar“) wird wie bisher gespeichert.
- Neue Option unter Rekrutierung > Antworten & Begrüßung: „Abgeschlossene Bewerbungen nach 90 Tagen löschen“ (Standard an, mit Erklärung beim Darüberfahren). Wird etwas gelöscht, steht eine Zeile im eigenen Chat.
- Entwickler-Tests: T297c, T298a–b (mit Gegenproben).

## 0.9.42
- Neu im Spieler-Tooltip bei Gildenmitgliedern: „In der Gilde seit <Datum>“ und „Zuletzt befördert/degradiert: <Datum> (<Rang>)“ – soweit GuildSentinel es weiss (frühester bekannter Beitritt, Gilden-Verlauf).
- Abgeschlossene Bewerbungen (beigetreten, abgelehnt, abgelehnt wegen Alter) werden 90 Tage nach der letzten Nachricht automatisch gelöscht. Offene Bewerbungen bleiben, bis ein Offizier entscheidet.
- Diagnose-Protokoll: Fensteraufbau („Fenster aufbauen“) und das Lesen der Mitgliederliste („Mitgliederliste lesen“) werden gemessen; dauert es länger als ein Bild, steht ein Eintrag LANGSAM im Protokoll (um seltene Ruckler zuzuordnen).
- Entwickler-Tests: T297a–b, test/run_g4.lua, Messskript test/perf_events.lua.

## 0.9.41
- Rekrutierung > Bewerber: Wer wegen der Grenze für automatische Antworten (höchstens 5 in 10 Minuten) nicht automatisch angeschrieben wurde, steht jetzt mit dem Status „selbst anschreiben“ in der Liste; der Tooltip erklärt warum. Sobald du ihn selbst anflüsterst, fällt die Markierung weg.
- Schreibt ein schon bekannter Bewerber das Stichwort erneut, während die Grenze voll ist, steht jetzt auch dafür eine Zeile im Chat („automatische Antwort pausiert …“) – höchstens einmal je Name in 10 Minuten. Vorher bekam er weder Antwort noch du einen Hinweis.
- Spalte „Status“ der Bewerberliste etwas breiter, damit lange Angaben ganz sichtbar sind.
- Entwickler-Tests: T296d–e (mit Gegenproben), test/run_g3.lua erweitert.

## 0.9.40
- Schutz vor Flüster-Fluten (G-3): Automatische Antworten und Bewerbungsfragen an Fremde gehen höchstens an 5 neue Gesprächspartner in 10 Minuten (zusätzlich zur Grenze „einmal je 10 Minuten je Name“). Darüber geht nichts automatisch hinaus – im eigenen Chat steht „Neuer Bewerber: <Name> – automatische Antworten pausiert …, bitte selbst anschreiben.“ Alle Bewerber werden weiter erfasst. Die Grenze gleitet: sobald eine Antwort älter als 10 Minuten ist, ist wieder Platz.
- Korrektur: Ein schon bekannter Bewerber, der einfach weiterschreibt, bekam alle 10 Minuten wieder den festen Antworttext. Jetzt nur noch, wenn er das Stichwort erneut schreibt. Antworten auf die Bewerbungsfragen laufen wie bisher.
- Marktdaten-Netz: gemeinsame Datei GoldSentinelMarkt.lua auf Version 7 (unverändert aus shared/): Weitergeben eines Scans in Portionen und mit viel weniger Speicher (statt bis 7,5 MB etwa 2,8 MB, gleiches Ergebnis) – ohne AHSentinel lief sonst die alte Fassung mit langem Ruckler.
- Entwickler-Tests (G-1): alte Tests run_v6/v7/v8 nachgeführt (12 rote Prüfungen: Online-Filter-Auswahl, kein eigener Gruppensuche-Kanal seit 0.9.20, Sprachwahl über uiLang). Neues Skript test/run_alle.sh lässt alle Tests mit Gesamtzahl laufen und zählt auch rote Einzelprüfungen (vorher nur Abbrüche). Neu: T296a–c, test/run_g3.lua (20 Fremde in einer Minute).

## 0.9.39
- Neu (GS-W2): Knopf „Vorschlag wählen“ auf der Rekrutierungsseite öffnet eine Auswahl fertiger Werbetexte: Standardtext der Phase, Kurz und knapp, Aufbau – zusammen aufbauen, Raid – Kader ausbauen, Freundlich und gemütlich, Mit Discord-Tag, Ohne Discord. Jeder Eintrag zeigt die Zeichenzahl, beim Darüberfahren den fertig eingesetzten Text. Die zur Phase (Aufbau/Raid) passenden Vorschläge stehen oben. Erst der Klick ersetzt den Text im Feld.
- GS-W1: Jeder Vorschlag (auch der mit Discord-Tag) endet wieder mit „– flüstert mir: /w <Name> gilde“, in jeder Sprache mit dem eigenen Wort. Ein eigener Text ohne diesen Teil bekommt einen gelben Hinweis; „Übernehmen“ hängt ihn an – nie ungefragt.
- Kürzen auf die Chat-Länge (255 Zeichen): zuerst die Klassenliste, dann der Discord-Satz, dann der Anfang des Textes – der Flüster-Teil bleibt immer ganz.
- Korrekturen: Chinesisch – beim Weglassen des Discord-Tags in der Klammer （…） fiel der ganze Rest samt Flüster-Teil weg. Beim Kürzen konnten am Ende chinesische Zeichen halb abgeschnitten werden. Portugiesisch: alle Texte sagen jetzt gleich „sussurre para mim“.
- Marktdaten-Netz: gemeinsame Datei GoldSentinelMarkt.lua auf Version 4 (unverändert aus shared/): Export der letzten 6 Scans, höchstens 1,5 MB; „Marktdaten teilen“ aus stoppt auch eine schon geplante Antwort an die Gilde.
- Entwickler-Tests: T295a–g (T-GSW1/T-GSW2), T247 angepasst, T291 verlangt Version 3 oder neuer.

## 0.9.38
- Marktdaten-Netz: gemeinsame Datei GoldSentinelMarkt.lua auf Version 2 aktualisiert. Sie liest einen Vollscan nicht mehr ein zweites Mal, wenn AHSentinel geladen ist (AHSentinel reicht seinen Scan weiter) – Version 1 liess das Spiel beim AHSentinel-Vollscan und im Sniper ruckeln. Kleinere Sende-Warteschlange, Gilden-Zusammenfassung höchstens stündlich, ausverkaufte Items im Export.
- Der Haken „Marktdaten teilen“ zeigt jetzt, ob das Netz wirklich läuft: Hat ein anderes GoldSentinel-Addon es ausgeschaltet, ist der Haken aus und ein kurzer Hinweis sagt es.
- Entwickler-Tests: T291 erweitert (Version 2, FeedStart/Feed), T294 (Haken folgt dem Netz).

## 0.9.37
- Neu: Marktdaten-Netz (gemeinsame Datei GoldSentinelMarkt.lua, gleich in allen GoldSentinel-Addons). Macht irgendein Addon oder der Spieler einen Vollscan im Auktionshaus, wird er in kleinen Portionen mitgelesen (nie im Kampf, nie ein eigener Scan) – je Item tiefster Stückpreis, Menge und Anzahl Auktionen, dazu der gemessene Absatz zwischen zwei Scans. Keine Namen: Besitzer, Bieter und Itemnamen werden nie gelesen. Anonym geteilt mit der Gilde und dem GoldSentinel-Netz, nur die eigene Fraktion. Standard an, ohne Abfrage; Einstellungen > „Marktdaten teilen (anonym, nur Preise)“ schaltet es aus (dann wird nichts gelesen und nichts gesendet). Ohne Auktionshaus-Schnittstelle (Era/TBC) bleibt es still.
- Diagnose-Protokoll: Zeilen „MARKT-NETZ“ (Version, an/aus, mitgelesene Scans, gesendet/empfangen, Speicher) – ohne Namen.
- Korrektur: Gildenverwaltung > Einladen (und das Mitglieder-Menü) beachten jetzt auch die Alters-Sperre – Bewerber „abgelehnt (Alter)“ lassen sich auch dort nicht einladen.
- Entwickler-Tests: T291–T293 (MN4), T289f; Offline-Ladetest mit und ohne die Markt-Datei.

## 0.9.36
- Neu (GA1): Altersfrage „Wie alt bist du?“ für Bewerber. Ist ein Mindestalter eingestellt (Rekrutierung > Texte, Standard 16, 0 = aus), wird sie IMMER als letzte Frage gestellt, auch bei eigener Fragenliste. Antwort „17“, „ich bin 17“, „17 Jahre“ -> normal weiter. Unter dem Mindestalter: nette Absage per Flüstern („Danke für dein Interesse an <Gilde>! Wir nehmen leider erst ab 16 Jahren auf. Viel Spass weiterhin in Azeroth!“ – Text einstellbar), Status „abgelehnt (Alter)“, „In die Gilde einladen“ gesperrt. Keine Zahl oder „bald 16“ -> keine automatische Absage, Status „Alter unklar“ für einen Offizier.
- Datenschutz: Das genaue Alter und der Antworttext werden nie gespeichert, geteilt oder protokolliert – nur „16+“ / „unter 16“ / „unklar“.
- Neu (GA2): In der Rekrutierungsphase Aufbau sagt der Standard-Werbetext das auch: „<Gilde> (Fraktion) ist im Aufbau und sucht Mitstreiter aller Klassen – entspannt, hilfsbereit, deutschsprachig, Raidziel …“. Neuer Platzhalter {phase} („im Aufbau“ / „fast raidbereit“ / „raidbereit“). Ein eigener Werbetext ohne {gesucht} oder {phase} bekommt einen gelben Hinweis mit Knopf „Übernehmen“ (setzt den Standardtext der Phase). Der fertige Chat-Text steht direkt über dem Knopf „Werbung vorbereiten“.
- Entwickler-Tests: T289a–e (T-GA1a–e), T290a–c (T-GA2a–c); Offline-Ablauf mit Alter 17 / 15 / „bald 16“.

## 0.9.35
- Die Zusammenfassung für Uploader und Discord-Bot (GuildSentinelDB.raidReady, beim Ausloggen) hat jetzt das Feld „vorschlag“: die Rekrutierungsphase, die GuildSentinel gerade vorschlägt („build“ / „trans“ / „raid“, dieselben Wörter wie „phase“); fehlt, wenn kein Vorschlag offen ist oder er mit „Später“ zurückgestellt wurde. Ohne Namen. Der Bot kann dann „GuildSentinel schlägt Phase … vor – im Spiel bestätigen“ posten.
- Entwickler-Test: T288 (T-RP-V).

## 0.9.34
- Neu: Befehlsliste beim Tippen. Tippst du /gs (oder /guildsentinel) in den Chat, erscheint über dem Eingabefeld die Liste ALLER Befehle mit kurzer Beschreibung. Jeder Buchstabe filtert („/gs w“ = wo, weg, werbung), deutsche und englische Befehlswörter gehen beide, Befehle mit Zusatz zeigen ihn („danke <Name>“), die meistbenutzten stehen oben. Mausklick oder Tab wählt einen Eintrag aus, Enter führt ihn aus. Das Chat-Eingabefeld wird nie beschrieben. Entwickler-Befehle nur für den Entwickler. Abschalten unter Einstellungen > „Befehlsliste beim Tippen von /gs“.
- Befehlsliste und /gs-Befehl benutzen ein und dieselbe Befehlstabelle – die Liste hat dadurch immer alle Befehle.
- Baustein unverändert aus AHSentinel übernommen (CmdHint).
- Entwickler-Tests: T282–T287 (T-BL1–T-BL6). TU1-Lagen-Katalog um Gruppensuche, Termine, Umfragen und Sync sowie um die Lagen „Kanal verweigert Addon-Nachrichten“, „Mitspieler mit alter Version“ und „Gilde gewechselt“ erweitert (11 Funktionen x 9 Lagen).

## 0.9.33
- Korrektur: Der Knopf im Fenster „Gilden-Aktion“ (Befördern, Degradieren, Entfernen, Leitung) tat nichts, wenn die Einstellung „Aktion bei Tastendruck“ (ActionButtonUseKeyDown) aus war – das Drücken setzte „wartet“, das Loslassen blockierte dann den Befehl, nach 6 Sekunden stand immer „Nicht ausgeführt“. GuildSentinel reagiert jetzt nur in der Phase, in der das Spiel den Befehl ausführt (Drücken oder Loslassen, je nach Einstellung); ein Klick = genau ein Befehl.
- Entwickler-Tests: T281 (T-GA1, beide Einstellungen) in der Testroutine; Offline-Testclient mit Einstellung an und aus.

## 0.9.32
- Entwickler-Testroutine (/gs testroutine) so erweitert, dass Fehler wie das geblockte Einladen nicht wieder durchrutschen:
  - TU1 Lagen-Katalog: 1 / 50 / 500 Mitglieder, viele offline, ohne Rechte / Offizier / Gildenmeister, Vor- und Nachnamen mit gleichen Vornamen, ohne Gilde – jede Lage durch Werbetext, Bewerber einladen, Verwaltung, Mitglieder-Menü, Mitgliederliste, Beförderung, Aufstellung/Raidfähigkeit und Berufe (T270).
  - TU2 Abläufe wie ein Spieler: Bewerber -> einladen -> keine Systemmeldung / Meldung -> entfernen; Befördern ohne Antwort, wiederholen, Bestätigung; /reload mittendrin; Werbung ohne Kanal (T271).
  - TU3 Standardwerte: jedes Feld leer bzw. ab Werk ergibt, was der Spieler meint (T272).
  - TU4 Grundregeln mit 1000 Zufallsfällen (fester Startwert 4711, 10 Portionen): nie eine geschützte Gilden-Funktion direkt, Status erst nach Bestätigung des Spiels, Rang-Schritte nie über den eigenen Rang, Werbung ohne "|", nichts echt gesendet (T273a–T273j).
  - TU5 echte Daten nur lesen: doppelte Einträge, Twink als eigener Main, unvollständiger Rang-Verlauf – Verletzungen ins Diagnose-Protokoll ohne Namen (T275).
  - TU6 Regressionen: jeder Befund seit dem 1.11. hat einen bleibenden Test; Bericht "Regressionen: n von m" (T276). TU8 Berichtszeile je Bereich (T279). T280 für RV7.
- Geschützte Gilden-Funktionen, die über ns.Act liefen, zählen in der Routine jetzt ebenfalls als FEHLER.
- Für Spieler keine Änderungen.

## 0.9.31
- Neu: Rekrutierung in Phasen (Mitglieder > Aufstellung). Aufbau (Standard für jede Gilde): {gesucht} in der Werbung wird zu „Mitstreiter aller Klassen“ – die Aufstellung wird nicht benutzt. Übergang: „Mitstreiter aller Klassen, besonders <bis 3 Lücken>“. Raid: die Lücken der Aufstellung wie bisher. Eigene Werbetexte bleiben; {gesucht} folgt der Phase.
- Die Vorgaben der Aufstellung werden nie gelöscht, umgerechnet oder überschrieben; die Seite sagt „die Vorgaben oben gelten ab Phase Raid“. Ändern nur Gildenmeister und Offiziere, jede Änderung mit Name und Zeit im Verlauf (letzte 50, nur im Spiel).
- Raidfähigkeit für einen Ziel-Raid (Onyxias Hort 40, Molten Core 40, Barrow Deeps 10, Hyjalgipfel 20 und weitere; TBC: Karazhan 10, Gruuls Unterschlupf 25 …): aktive Mains (Stufe ≥ Mindeststufe der Aufstellung und in den letzten 14 Tagen online; Twinks nur mit „Twinks mitzählen“) gegen die Raidgrösse, dazu Tanks und Heiler (aus der Aufstellung, auf die Raidgrösse umgerechnet; sonst Grösse/10 und Grösse/5). Angezeigt auf Aufstellung, Rekrutierung und Übersicht: „Raidfähig (Onyxias Hort): 23 von 40 aktiv auf Stufe 55+ · Tanks 2/4 · Heiler 5/10 · Phase Aufbau“, mit Schätzung aus dem Leveling-Rennen („beim jetzigen Tempo in ~x Wochen“, bei weniger als 7 Tagen Daten „messe noch“).
- Ab 60 % bekommen die Offiziere den Vorschlag „Übergang“, ab 100 % „Raid“ (im Fenster und einmal im Offizierschat, nur einer sagt an) mit „Bestätigen“ / „Später“. Nichts schaltet automatisch. Zurück erst nach 7 Tagen unter der Schwelle der aktuellen Phase.
- Chronik-Meilenstein „Gilde ist raidfähig (<Raid>)“, optional mit Ansage im Gildenchat (Einstellungen, Standard an, nur einer sagt an).
- Beim Ausloggen wird eine Zusammenfassung ohne Namen für Uploader und Discord-Bot abgelegt (GuildSentinelDB.raidReady).
- Entwickler-Testroutine: T261–T269 (T-RP1–T-RP9) neu; T244/T246 laufen jetzt in der Phase Raid.

## 0.9.30
- Neu: Rechtsklick-Menü auf Mitglieder (Mitgliederliste, Inaktive, Wer ist wo, Bewerber, Listen der Leitung): Flüstern, In die Gruppe einladen, Befördern, Degradieren, Rang setzen …, Twink zuordnen …, Notiz bearbeiten, Offiziersnotiz bearbeiten, Abwesenheit eintragen, Danke sagen, Pate zuweisen …, Aus der Gilde entfernen (mit Rückfrage), Gildenleitung übergeben (nur Gildenmeister, mit Passwort). Was dein Rang nicht darf, steht grau mit Grund da; im Kampf „nicht im Kampf“.
- Geschützte Gilden-Aktionen werden nie mehr direkt aufgerufen (Lehre aus der Einladen-Korrektur in 0.9.29): Befördern, Degradieren, Entfernen und Gildenleitung – aus dem Menü, der Gildenverwaltung, den Beförderungs-Vorschlägen und den Sammelaktionen – öffnen das neue Fenster „Gilden-Aktion“. Du klickst dort den Knopf, Blizzards eigener Befehl (/gpromote, /gdemote, /gremove, /gleader) führt aus. Namen mit Leerzeichen gehen.
- Rang setzen: jeder Schritt ist ein eigener Klick („Befördern – noch 2 Stufen bis Offizier“), nie über den eigenen Rang, nie zum Gildenmeister.
- Ein Schritt gilt erst als erledigt, wenn das Spiel ihn bestätigt (Systemmeldung oder neuer Rang in der Gildenliste); ohne Bestätigung nach 6 Sekunden: „Nicht ausgeführt“, der Schritt lässt sich wiederholen. Jede bestätigte Rang-Änderung kommt in den Rang-Verlauf (wer, wen, von -> nach, Zeit).
- Mehrfachauswahl: Shift/Strg-Klick in der Mitgliederliste, dann Rechtsklick: alle befördern oder degradieren – je Mitglied ein Klick („3 von 5 erledigt“).
- Beförderung: neue Option „Twinks bekommen den Rang ihres Mains vorgeschlagen“ (nur Vorschlag, Schritt für Schritt).
- Leitung > Rangrechte: Knopf „Ränge im Spiel bearbeiten“ öffnet Blizzards Rang-Fenster.
- Entwickler-Testroutine: T254–T260 (Menü nach Rechten, kein geschützter Aufruf, Name mit Leerzeichen, Rang-Schritte, Bestätigung, Twink-Vorschlag, Mehrfachauswahl) neu; T64, T174, T194, T195, T213 angepasst. Der Offline-Testclient lehnt geschützte Gilden-Funktionen jetzt wie WoW Forever ab.

## 0.9.29
- Korrektur (WoW Forever): „In die Gilde einladen“ (Rekrutierung > Bewerber und Gildenverwaltung) löst nicht mehr „GuildSentinel wurde geblockt … der Blizzard-UI vorbehalten“ aus. Das Spiel verbietet Addons das direkte Einladen in die Gilde, auch mit Mausklick. Jetzt kommt „/ginvite <Name>“ in die Chat-Eingabe und du drückst Enter – Blizzards eigener Befehl verschickt die Einladung. Namen mit Leerzeichen gehen so, wie sie sind.
- Der Bewerber steht erst auf „eingeladen“, wenn das Spiel die Einladung bestätigt („Ihr habt X eingeladen …“), nicht mehr gleich nach dem Klick.
- Eigene Werbetexte mit {tag} ohne Gedankenstrich: Ohne Tag oder Discord-Link fällt „(Tag {tag})“ samt Klammer weg und ein eigener Satz mit {tag} ganz; sonst wird nur {tag} geleert.
- Entwickler-Testroutine: T253 (Einladen nur über die Chat-Eingabe, Status erst nach der Bestätigung) neu; T174, T194 und T251 erweitert.

## 0.9.28
- Seite Rekrutierung: neuer Knopf „Vorschlag 2“ – ein zweiter Werbetext, der den Server-Tag eures Discords nennt („… Discord: <Link> – erkennbar am Tag XY.“). Der Standard-Werbetext bleibt unverändert.
- Neues Feld „Server-Tag“ neben dem Discord-Link und neuer Platzhalter {tag}. Ohne Tag oder ohne Discord-Link fällt der Tag-Teil ganz weg.
- Tipp unter dem Discord-Link: eine dauerhafte Einladung verwenden (läuft nie ab, unbegrenzte Nutzungen); wer klickt, sieht vor dem Beitritt das Serverprofil der Gilde.
- Entwickler-Testroutine: T251 (Vorschlag 2 mit/ohne Link und Tag, DE/EN/RU) und T252 (Einladungs-Tipp) neu.

## 0.9.27
- Russische Werbung: „Пишите мне“ beginnt jetzt gross, auch wenn der Discord-Teil wegfällt.
- Entwickler-Testroutine: T250 prüft auch den alten Standardtext in der Sprache des Clients.

## 0.9.26
- Werbung ohne Discord: Der Satz nach dem entfernten Discord-Teil beginnt jetzt gross („… deutschsprachig. Flüstert mir: …“).
- Wer den alten Standard-Werbetext unverändert gespeichert hatte, bekommt einmalig den neuen Standard (mit dem neuen {gesucht} läse er sich holprig). Eigene, abweichende Texte bleiben.
- Entwickler-Testroutine: T249 (Zähler „wird gekürzt“) und T250 neu; T248 umbenannt.

## 0.9.25
- **Neuer Standard-Werbetext**: „{gilde} ({fraktion}) sucht {gesucht} für Dungeons und Raids – entspannt, hilfsbereit, deutschsprachig. Discord: {discord} – flüstert mir: /w {name} gilde“ (in allen Sprachen sinngemäss). Wer einen eigenen Werbetext gespeichert hat, behält ihn; ein leeres Feld nimmt den neuen Standard.
  - Neuer Platzhalter **{fraktion}** ({faction}): Horde oder Allianz in der Sprache des Spiels.
  - **{gesucht}** ist jetzt nur die Liste („Heiler, Krieger und Magier“); fehlt nichts: „neue Mitglieder“. Stand „{gesucht}“ in einem eigenen Text allein, bitte „Gesucht:“ selbst davorschreiben.
  - **{discord}**: Ohne Discord-Link fällt der ganze Teil „Discord: … – “ weg. Direkt nach „Discord:“ steht nur der Link; überall sonst (eigene Texte, Antwort, Willkommen) wie bisher „Discord: <Link>“.
- Der Längenzähler zählt vor dem Kürzen und wird rot mit „wird gekürzt“, wenn die Werbung länger als 251 Zeichen ist.
- Entwickler-Testroutine: T244–T248 neu.

## 0.9.24
- Gildenwerbung: Eine lange Werbung wird von der Chat-Eingabe nicht mehr abgeschnitten und zählt dann nie als gepostet. Der Werbetext ist auf 251 Zeichen begrenzt (Platz für „/<Kanal> “), der Zähler zeigt „(n/251)“, und genau der Text in der Chat-Eingabe zählt, sobald er im Kanal erscheint. Umlaute und andere Sonderzeichen werden nie halbiert.
- Entwickler-Testroutine: T242–T243 neu.

## 0.9.23
- **Gildenwerbung nicht mehr blockiert**: WoW Forever verbietet Addons, selbst in Chat-Kanäle zu schreiben („Aktion blockiert“) – auch aus einem Klick. Der Knopf heisst jetzt „Werbung vorbereiten“: Er schreibt „/<Kanal> <Text>“ in die Chat-Eingabe, du sendest mit Enter (alle Spielversionen). Als gepostet (Wartezeiten, „zuletzt gepostet“, Erinnerung) zählt die Werbung erst, wenn dein Text im Kanal erscheint.
- Gruppensuche: Eine Gildensuche kann nur der Suchende selbst beenden; bei Suchen für den ganzen Server reicht sein Name in den Daten (sie kommen über das Netz weitergegeben).
- Gilden-Berufsliste: Die Diagnose-Zeile sagt jetzt, warum Offline-Mitglieder (nicht) eingeblendet wurden (schon an, keine Funktion, Kampf, Gildenfenster offen, 5-Minuten-Sperre …); ist die Liste beim zweiten Lesen nicht mehr lesbar, werden die Einstellungen trotzdem zurückgesetzt.
- Entwickler-Testroutine: T239–T241 neu.

## 0.9.22
- **Rezepte je Mitglied**: Auf der Seite Berufe zeigt ein Klick auf ein Mitglied, WELCHE Rezepte es in diesem Beruf kann – mit Zurück-Knopf, Item-Links und Tooltips, und „Herstellen anfragen“ für das gewählte Rezept.
  - **Filterleiste nach Art**, nur Arten, die vorkommen, mit Anzahl und „Alle“ zuerst: Schmiedekunst, Lederverarbeitung, Schneiderei nach Platz (Kopf, Brust, Hände, Waffen …), Alchemie nach Heil-/Mana-/Erholungs-/Schutztränken, Elixieren, Fläschchen, Ölen, Transmutationen, Reagenzien, Ingenieurskunst nach Sprengstoff, Geräten, Zielfernrohren, Verzauberkunst nach Ziel-Platz, Kochen/Erste Hilfe nach Essen und Verbänden. Die Leiste bricht um, wenn der Platz nicht reicht.
  - Die Art wird auf deinem PC aus dem Item (Platz, Klasse) oder dem Rezeptnamen bestimmt – es muss nichts Neues gesendet werden, Daten älterer Versionen gehen auch („Sonstiges“, wenn unbekannt).
  - In WoW Forever geht Blizzards Rezept-Kategorie als neues, optionales Feld mit; ältere Versionen übergehen es.
  - Das Suchfeld filtert auch die Rezepte eines Mitglieds; Filter und Suche lassen sich kombinieren.
- Gruppensuche „ganzer Server“: Gruppenänderungen und Antworten auf Nachfragen gehen nur noch an die Gruppe; ins Flüster-Netz geht eine Suche nur beim Start und beim Beenden.
- Entwickler-Testroutine: T231–T238 neu.

## 0.9.21
- **GoldSentinelSync 2 (Flüster-Netz)**: Die gemeinsame Sync-Datei erreicht jetzt auch Spieler mit GoldSentinel-Addons ausserhalb von Gilde und Gruppe – per Flüstern über andere Spieler, die sie haben (gedrosselt, kein Chat-Spam; „kein Spieler … online“ wird ausgeblendet).
  - **Was ins Netz geht**: nur die Gruppensuche für den ganzen Server (neue Suche und Beenden). Alles andere bleibt in der Gilde (Berufe, Termine, Brett, Umfragen, Danke, Zugänge …), in der Gruppe oder im Flüstern an einen Spieler.
  - Gruppensuche: „ganzer Server“ ist zurück – die Suche geht an die Gilde, die Gruppe und ins Netz.
  - Bekannte Mitspieler des Netzes bleiben über /reload erhalten (GuildSentinelDB.gsSync: nur Namen, Zeiten, Version; bleibt auf deinem PC).
- **GoldSentinelTest 2**: Fehlerberichte an den Entwickler teilen (nur mit Zustimmung, /gstest).
- Diagnose-Protokoll: neue Zeile „NETZ …“ (ohne Namen).
- Entwickler-Testroutine: T225–T230 neu.

## 0.9.20
- **Addon-Nachrichten für alle Spielversionen**: GuildSentinel nutzt jetzt die gemeinsame Sync-Datei von GoldSentinel. Gesendet wird nur noch über die Gilde, die eigene Gruppe bzw. den Raid und Flüstern – nie mehr über einen eigenen Chat-Kanal (WoW Forever stellt Addon-Nachrichten dort nicht zu). Nachrichten älterer GuildSentinel-Versionen anderer Spieler werden weiter verstanden. Wer noch 0.9.19 oder älter hat, empfängt die Nachrichten von 0.9.20 nicht mehr – bitte aktualisieren.
  - Der eigene Kanal „GuildSentinelLFG“ wird nicht mehr betreten (einmal verlassen, falls man drin ist) – ein Kanalplatz wird frei.
  - Gruppensuche: „Gilde und Gruppe“ ersetzt „ganzer Server“ – die Suche geht an die Gilde und an die eigene Gruppe bzw. den Raid. Die Einstellung „Suchen vom ganzen Server“ entfällt.
  - Werbung: Nur noch Blizzard-Kanäle (Allgemein, Handel, LokaleVerteidigung, SucheNachGruppe …) sind wählbar; Addon- und Spielerkanäle sind ausgeblendet.
  - „/gs sync test“ zeigt, wer antwortet („N Antworten (Gilde a, Gruppe b)“); die Einstellungen zeigen die Zahl der Mitspieler mit GuildSentinel in der letzten Stunde.
- **Berufe**: Wer einen Beruf bei offenem Fenster hochlevelt, sendet nicht mehr bei jeder Stufe an die Gilde (höchstens alle 5 Minuten und beim Schliessen des Fensters); neue Rezepte gehen weiter sofort. Das Diagnose-Protokoll läuft dadurch nicht mehr voll.
- Gilden-Berufsliste mit Offline-Mitgliedern: GuildSentinel wartet jetzt immer auf das Spiel, bevor es liest und die Einstellung zurücksetzt.
- Blizzards Gilden-Rezepte: Das Öffnen der Gilden-Ansicht startet die Abfragen je Beruf höchstens alle 10 Minuten neu, und kein Rezept wird am selben Tag zweimal gefragt.
- Empfangene Berufsdaten anderer Spieler werden in der Tiefe geprüft; kaputte Daten führen in Tooltips und Herstellen-Anfragen zu keinem Fehler mehr.
- Diagnose-Protokoll: Zeilen für Addon-Nachrichten (Wege, Mitspieler, gesendet/empfangen/verworfen, Kanal verweigert).
- Entwickler-Testroutine: T214–T224 neu; in Tests nur noch Platzhalter-Namen.

## 0.9.19
- **Berufe kommen automatisch in beide Richtungen an**: Die Berufe eines Mitglieds konnten auf einer Seite hängen bleiben. Behoben:
  - GuildSentinel schickt deine eigenen Berufe jetzt immer selbst, auch wenn RaidMaster installiert ist (vorher schwieg es und verliess sich auf RaidMaster).
  - Namen werden überall gleich abgeglichen (Realm-Zusatz, Gross-/Kleinschreibung, Vorname allein in WoW Forever): Daten liegen und erscheinen unter dem Namen aus der Gildenliste. Ältere Einträge in anderer Schreibweise werden einmal zusammengeführt (neuere Daten gewinnen).
  - Jedes Mitglied mit GuildSentinel schickt seine eigenen Berufe 10–60 Sekunden nach dem Einloggen, wenn sie neu oder älter als 24 Stunden sind – nicht mehr nur über das eine Mitglied, das beim Abgleich antwortet.
- **Vollautomatisch** (keine Option, kein Knopf, nie im Kampf):
  - Die Gilden-Berufsliste des Spiels wird auch mit Offline-Mitgliedern gelesen (die Einstellung „Offline-Mitglieder anzeigen“ wird kurz eingeschaltet und zurückgesetzt).
  - Neue Rezepte kommen sofort dazu, wenn du sie lernst – ohne Berufsfenster.
  - Rezepte ohne Fenster prüfen: Rezepte, die die Gilde schon kennt, werden mit der Zauber-Prüfung des Spiels geprüft – nur, wenn eine Probe richtig antwortet.
  - Blizzards Gilden-Rezepte (wer in der Gilde welches Rezept kann) werden abgefragt, wo das Spiel es erlaubt, einmal am Tag je Beruf; sonst gelesen, wenn du diese Ansicht selbst öffnest.
- **Seite Berufe**: Ein gewählter Beruf ohne bekannte Daten sagt jetzt, wie viele Mitglieder ihn haben („2 Gildenmitglieder haben Alchimie …“), statt des allgemeinen Hinweises. Die Spalte „Wer“ zeigt „1 von 4“; Mitglieder, die nur das Spiel kennt, erscheinen mit „Rezepte unbekannt“ und lassen sich anflüstern; darunter „+2 weitere laut Spiel“.
- Gildenliste: Zugeklappte Berufe werden höchstens alle 5 Minuten aufgeklappt, und das Ereignis, das dabei kommt, startet kein neues Lesen (kein Kreislauf).
- Befördern aus der Aktivität und die Sammelaktionen nutzen jetzt zuerst die moderne Spielfunktion (wie die Gildenverwaltung).
- Diagnose-Protokoll: Zeilen für eingelesene, gesendete, empfangene, angezeigte und aussortierte Berufe (nur Zahlen, keine Spielernamen) und eine Zusammenfassung.
- Entwickler-Testroutine: T201–T213 neu.

## 0.9.18
- **Berufe aller Mitglieder**: Das Spiel kann seine Gilden-Berufsliste mit zugeklappten Berufen liefern, dann fand GuildSentinel keine Namen. Jetzt klappt es zugeklappte Berufe kurz auf, liest sie und klappt sie wieder zu (nur ausserhalb des Kampfs und solange Blizzards Gildenfenster zu ist). Wo das Spiel das nicht kann, zeigt die Seite Berufe, wie viele Mitglieder einen Beruf haben (z. B. „2/5“: 2 kennt GuildSentinel, 5 laut Spiel).
- **Gildenverwaltung**: Aktionen und Rangnamen nutzen jetzt auf jedem Client die richtige Spielfunktion (Classic Era, TBC Anniversary, WoW Forever). Der Verwaltungsknopf weicht unter das Gildenfenster aus, solange Blizzards Mitglied-Details oder Rangfenster offen sind, und verdeckt sie nie.
- Entwickler-Testroutine: T190 erweitert (zugeklappte Berufe), neu T200 (alte Clients ohne C_GuildInfo); Bereich K prüft auch Blizzards Gilden-Popups.

## 0.9.17
anweisung-gildenverwaltung.txt (Wunsch des Nutzers, 9. Nov.):
- **Neues Fenster "Gildenverwaltung"** (Admin.lua) für Gildenleitung und Offiziere: Knopf "Verwaltung (GuildSentinel)" neben Blizzards Gildenfenster (J bleibt; eigener Frame, nur geankert, Blizzard-Fenster nur per HookScript, Communities beim Laden angehängt) und `/gs verwaltung`.
  - Einladen (Name oder Ziel), Befördern/Degradieren (Rang vorher -> nachher, nie über den eigenen Rang), Rauswerfen (mit Rückfrage).
  - Gildenleitung übergeben: nur Gildenmeister, gesperrt bis zum richtigen Passwort, danach zwei Rückfragen.
  - Jeder Knopf nach den Rechten im Spiel (ns.API: IsGuildLeader, CanGuildInvite/Promote/Demote/Remove, CanEditOfficerNote). Lokale Zugriffsliste des Gildenmeisters (GuildSentinelDB.admin, nie gesendet, nicht im Protokoll).
  - Passwort: zweimal eingeben, nur Prüfsumme mit Salz, maskiert, 3 Fehlversuche -> 5 Minuten Sperre, ändern nur mit dem alten.
  - Aktionen nur aus dem Klick bzw. der Bestätigung, nie im Kampf, über ns.Act; Testmodus nur "[Test]". Diagnose-Protokoll: VERWALTUNG ohne Namen.
- Testroutine: T192–T198 (Rechte, gesperrt, Aktionen mit richtigem Namen, Passwort, Sperre, Prüfsumme, keine Namen), T199 im Spiel; Bereich K kennt die neuen Fenster (ns.RegisterUI).

## 0.9.16
Wunsch des Nutzers: Berufe der Mitglieder und neuer Mitglieder automatisch einlesen.
- **Berufe aller Mitglieder automatisch**: Wo das Spiel die Berufe der Gilde selbst kennt (Gilden-Berufsliste, GetGuildTradeSkillInfo – über ns.API, fehlt sie, passiert nichts), liest GuildSentinel die Stufen aller Mitglieder, auch ohne GuildSentinel. Höchstens alle 5 Minuten, nicht im Kampf nötig, nur lesen. Rezepte kommen weiter nur von Spielern mit GuildSentinel bzw. RaidMaster, die ihr Berufsfenster geöffnet haben; deren Angaben gehen immer vor (Einträge aus der Gildenliste: t = 0, g = true).
- **Neue Mitglieder**: Wer der Gilde beitritt, während er online ist, schickt seine Berufe sofort (bisher erst beim nächsten Einloggen).
- Diagnose-Protokoll: einmal je Sitzung "Gilden-Berufsliste: n Zeilen, … Mitglieder" – so zeigt sich, ob die Spielversion die Liste liefert.
- Testroutine: T190 (Gildenliste über ns.API nachgestellt), T191 (im Spiel).

## 0.9.15
Empfehlung der Prüf-Sitzung (Nachricht vom 9. Nov.): Diagnose-Protokoll wie in der Vorlage.
- **Diagnose-Protokoll** (Diag.lua): GuildSentinel schreibt Probleme mit, die nur im echten Spiel auftreten – langsame Seiten (über 16 ms), blockierte Aktionen mit Aufrufort (debugstack bei ADDON_ACTION_BLOCKED/FORBIDDEN), Fehler (gleiche nur gezählt). Keine Spieler-, Gilden- oder Realmnamen. `/gs protokoll` zeigt es zum Kopieren; beim Ausloggen bzw. /reload liegt es als GSDIAG1 in GuildSentinelDB.diagExport (Uploader -> #testberichte). Im Testmodus und während der Testroutine wird nichts geschrieben.
- Testroutine: T188 (Protokoll: Einträge, Zähler, Export, keine Namen), T189 (im Spiel).
- Zum Befund "4× ADDON_ACTION_BLOCKED UNKNOWN() mit 0.9.13": Der Aufrufort stand schon im Testbericht (Professions.lua:346 OpenModern <- Pages.lua:1505, Timer nach dem Berufe-Knopf) und ist seit 0.9.14 behoben.

## 0.9.14
Befunde aus der Testroutine im Spiel (Launch-Abend WoW Forever, offen-guildsentinel.txt Punkt 3) und
anweisung-testroutine-oberflaeche.txt:
- **T143 Grosse Gilden**: Übersicht und Leitung ruckeln nicht mehr bei Hunderten Mitgliedern. Main/Twink wird je Seitenaufbau nur einmal berechnet (Roster:Memo), die Übersicht gruppiert in einem Durchgang – mit 500 Mitgliedern etwa 25× schneller.
- **Berufe-Knopf (WoW Forever)**: kein "Aktion blockiert" mehr (Fehlerbericht vom Launch). Geht das Berufsfenster nicht auf, kommt ein Hinweis, statt die geschützte Funktion C_TradeSkillUI.OpenTradeSkill aus einem Timer aufzurufen.
- **T118 Chronik/Erfolge**: kaputte Berufsdaten lassen die Seite nicht mehr abstürzen (Typprüfung, Prof:All überspringt kaputte Einträge).
- **T45 Termin ansagen**: im Testmodus auch ohne echte Gilde nur "[Test]" im Chat (ns.Announce nutzt ns.InGuild); gesendet wird weiterhin nichts.
- **T154**: Der Fall läuft unabhängig von den Einstellungen des Spielers (Funktion "Danke" aus, schon gedankt) und zeigt im Ergebnis, was GuildSentinel ausgibt.
- Testroutine: neuer Bereich K "Oberfläche im echten Client" (T182 Tooltips verdecken keine Knöpfe, T183 kein Überlappen mit anderen Fenstern, T184 im Bildschirm, T185 Texte passen, T186 Spielwerte plausibel, T187 keine Fehlerschleifen); T143 nennt die langsamste Seite.

## 0.9.13
- **Sprache für alle wählbar**: Einstellungen > Allgemein > "Sprache". Beim Start nimmt GuildSentinel weiter die Sprache des Spiel-Clients; wählbar sind auf jedem Client Deutsch, Englisch, Französisch, Spanisch (Spanien/Mexiko), Italienisch und Portugiesisch (Russisch, Koreanisch und Chinesisch auf einem Client in dieser Sprache). GuildSentinel lädt nach der Wahl neu; "Wie der Spiel-Client" stellt zurück. Ersetzt die Wahl nur für den Entwickler aus 0.9.12.
- Testroutine: T122 beachtet die gewählte Sprache, T127 prüft jetzt im Spiel alle geladenen Sprachen auf Vollständigkeit.

## 0.9.12
- Nur für den Entwickler: Unter Einstellungen > Testmodus lässt sich die Sprache zwischen Deutsch, Englisch und der Sprache des Spiel-Clients umschalten (für Screenshots); GuildSentinel lädt danach neu. Für Spieler ändert sich nichts – GuildSentinel nimmt immer die Sprache des Spiel-Clients.

## 0.9.11
Aufträge der Prüf-Sitzung (offen-guildsentinel.txt, anweisung-guildsentinel-gildenbank.txt):
- **Bank-Charakter: Bestand an Discord** (freiwillig, ab Werk aus): Auf dem Bank-Charakter der Gilde unter Einstellungen > Allgemein "Bank-Charakter (Bestand an Discord)" anhaken. Beim Öffnen von Bank, Briefkasten und – wo es sie gibt – Gildenbank liest GuildSentinel dann Taschen, Bank, Post-Anhänge und Gildenbankfächer (nur lesen, nie im Kampf, in kleinen Schritten). Der RaidMaster-Uploader schickt den Bestand mit dem nächsten Upload mit, der RaidMaster-Bot zeigt ihn in #gildenbank und bei /bank. Gilden ohne RaidMaster-Bot merken nichts davon.
- **Twink-Notizen mit Vor- und Nachnamen** (WoW Forever) auf koreanischen und chinesischen Clients, bei denen der Name vor der Kennzeichnung steht ("Testa Beispiel의 부캐릭터"), werden wieder erkannt.
- **Main wechseln** entfernt die alte Kennzeichnung jetzt ganz – mit Vor- und Nachnamen und in der Sprache des Clients ("Alt: Vorname Nachname", "Reroll de …") –, statt Reste in der Notiz stehen zu lassen.
- **Termin-Abgleich**: Ein kaputter Eintrag verwirft nicht mehr die übrigen Termine desselben Pakets.
- Alle Spielfunktionen, die GuildSentinel braucht, werden jetzt an einer Stelle gewählt (API.lua, moderne API zuerst, alte als Rückfall). Für Spieler ändert sich nichts.
- Testroutine (Entwickler): echte Sendungen sind im Bericht jetzt ein FEHLER (T82), jede Aktion mit Folgen wird auf den einen Weg über ns.Act geprüft (T174), neue Fälle für Export, Termin-Ansage, Vor- und Nachnamen und den Bank-Charakter (T31, T45, T154, T175–T181); die Fälle, die früher eine Blizzard-Funktion ersetzt hätten (T92, T93b, T96b, T97b, T99, T114, T159, T161, T166), laufen jetzt auch im Spiel – über ns.API.

## 0.9.10
- **Twink-Notizen in der Sprache des Clients**: Notizen, die GuildSentinel selbst schreibt ("Reroll de …", "… 的分身" usw.), werden auf französischen, spanischen, italienischen, portugiesischen, koreanischen und chinesischen Clients wieder erkannt. Wo die Kennzeichnung nicht in die kurze Gildennotiz passt (Russisch), schreibt GuildSentinel die Kurzform "Alt: Name".
- **AHSentinel** (früher AH Analyzer Pro) wird unter dem neuen Ordnernamen erkannt (Seite Addons, Marktwerte).
- **Bewerber-Flüstern im Kampf** (WoW Forever): Mehr als 30 Flüsternachrichten in einem Kampf werden jetzt im Hinweis mitgezählt, statt still wegzufallen.
- Robuster bei beschädigten Daten: fehlerhafte Termin-Abgleiche und kaputte Termin- oder Danke-Einträge lösen keine Fehler mehr aus.
- Testmodus (nur Entwickler): betritt oder verlässt den Server-Kanal nicht mehr, sendet nach "Testmodus beenden" nichts Verzögertes mehr und lässt die echten Einstellungen (letzte Werbung, Frei-Meldung, Meine Woche) unberührt.
- Neu für den Entwickler: `/gs testroutine` (Knopf "Alles testen" unter Einstellungen > Testmodus) prüft alle Funktionen und speichert einen Bericht für die Prüfung von GoldSentinel; die Diagnose zeigt den Fehlerzähler. Für Spieler ändert sich nichts.

Ältere Versionen: siehe LIESMICH.txt.
