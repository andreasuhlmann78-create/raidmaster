-- GuildSentinel - UI.lua
-- Bausteine für die Oberfläche (flache, dunkle Optik wie ThreatSentinel), Hauptfenster und Minimap-Knopf.
-- Alles ist per Maus bedienbar; die Seiten selbst stehen in Pages.lua.

local ADDON, ns = ...
local L = ns.L
local UI = {}
ns.UI = UI

local WHITE = "Interface\\Buttons\\WHITE8x8"
local BACKDROP = BackdropTemplateMixin and "BackdropTemplate" or nil
local A = ns.ACCENT
UI.WHITE = WHITE
UI.BACKDROP = BACKDROP

UI.pages = {}         -- { key, title, icon, build(panel), onShow(panel, arg) }
UI.linkBoxes = {}     -- Eingabefelder, die Shift-Klick-Links annehmen

------------------------------------------------------------
-- Grundformen
------------------------------------------------------------
function UI.Box(f, r, g, b, a, br, bg, bb, ba)
	if not f.SetBackdrop then return end
	f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	f:SetBackdropColor(r or 0.08, g or 0.09, b or 0.12, a or 1)
	f:SetBackdropBorderColor(br or 0.2, bg or 0.22, bb or 0.27, ba or 1)
end

function UI:Label(parent, text, font, r, g, b)
	local fs = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlight")
	fs:SetJustifyH("LEFT")
	fs:SetText(text or "")
	if r then fs:SetTextColor(r, g, b) end
	return fs
end

function UI:Header(parent, text)
	local fs = self:Label(parent, text, "GameFontNormal")
	fs:SetTextColor(A[1], A[2], A[3])
	return fs
end

------------------------------------------------------------
-- Knopf
------------------------------------------------------------
-- flacher Knopf für die Titelleiste (24 × 24, ohne Rahmen; Hintergrund nur beim Darüberfahren)
function UI.TitleButton(parent, onClick)
	local b = CreateFrame("Button", nil, parent)
	b:SetSize(24, 24)
	b.bg = b:CreateTexture(nil, "BACKGROUND")
	b.bg:SetAllPoints()
	b.bg:SetTexture(WHITE)
	b.bg:SetVertexColor(1, 1, 1, 0)
	b:SetScript("OnClick", function(self, button) if onClick then onClick(self, button) end end)
	return b
end

function UI:Button(parent, text, w, h, onClick, primary)
	local b = CreateFrame("Button", nil, parent, BACKDROP)
	b:SetSize(w or 120, h or 24)
	local base = primary and { A[1] * 0.45, A[2] * 0.45, A[3] * 0.45 } or { 0.13, 0.15, 0.19 }
	UI.Box(b, base[1], base[2], base[3], 1, primary and A[1] or 0.25, primary and A[2] or 0.28, primary and A[3] or 0.34, primary and 0.9 or 1)
	b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	b.text:SetPoint("CENTER")
	b.text:SetText(text or "")
	b.SetText = function(self, t) self.text:SetText(t) end
	b.GetText = function(self) return self.text:GetText() end
	local hl = b:CreateTexture(nil, "HIGHLIGHT")
	hl:SetPoint("TOPLEFT", 1, -1)
	hl:SetPoint("BOTTOMRIGHT", -1, 1)
	hl:SetTexture(WHITE)
	hl:SetVertexColor(1, 1, 1, 0.08)
	b:SetScript("OnClick", function(self, button) if onClick then onClick(self, button) end end)
	b:SetScript("OnEnable", function(self) self.text:SetTextColor(1, 1, 1) end)
	b:SetScript("OnDisable", function(self) self.text:SetTextColor(0.45, 0.45, 0.48) end)
	return b
end

-- Befund 3 (Ingametest 17.11., T182): Tooltips im Hauptfenster verdeckten Knöpfe desselben Fensters (Zeilen der Listen,
-- Kopfzeilen, Seitenleiste). Jetzt stehen sie NEBEN dem Fenster, auf Höhe des Elements (rechts, bei zu wenig Platz links).
-- Elemente ausserhalb des Hauptfensters behalten ihren Anker (fallback).
function UI.TipOwner(owner, fallback)
	local f = UI.frame
	local inside = false
	if f and owner and f.IsVisible and f:IsVisible() then
		local p, n = owner, 0
		while p and n < 40 do
			if p == f then inside = true break end
			p = p.GetParent and p:GetParent() or nil
			n = n + 1
		end
	end
	if not inside then GameTooltip:SetOwner(owner, fallback or "ANCHOR_RIGHT") return end
	GameTooltip:SetOwner(owner, "ANCHOR_NONE")
	GameTooltip:ClearAllPoints()
	local top, ftop = owner:GetTop(), f:GetTop()
	local dy = (type(top) == "number" and type(ftop) == "number" and not ns.IsSecret(top) and not ns.IsSecret(ftop)) and math.min(0, top - ftop) or 0
	local right, sw = f:GetRight(), UIParent:GetWidth()
	local scale = (f:GetEffectiveScale() or 1) / (UIParent:GetEffectiveScale() or 1)
	if type(right) == "number" and type(sw) == "number" and right * scale + 330 > sw then
		GameTooltip:SetPoint("TOPRIGHT", f, "TOPLEFT", -4, dy)
	else
		GameTooltip:SetPoint("TOPLEFT", f, "TOPRIGHT", 4, dy)
	end
end

function UI.Tip(widget, title, text)
	widget:HookScript("OnEnter", function(self)
		ns.UI.TipOwner(self, "ANCHOR_RIGHT")
		GameTooltip:AddLine(title, 1, 1, 1)
		if text then GameTooltip:AddLine(text, 0.8, 0.8, 0.8, true) end
		GameTooltip:Show()
	end)
	widget:HookScript("OnLeave", function() GameTooltip:Hide() end)
end

------------------------------------------------------------
-- Häkchen
------------------------------------------------------------
function UI:Check(parent, label, get, set)
	local c = CreateFrame("Button", nil, parent)
	c:SetSize(22, 22)
	local box = CreateFrame("Frame", nil, c, BACKDROP)
	box:SetSize(16, 16)
	box:SetPoint("LEFT", 2, 0)
	UI.Box(box, 0.06, 0.07, 0.09, 1, 0.35, 0.38, 0.45, 1)
	local mark = box:CreateTexture(nil, "OVERLAY")
	mark:SetPoint("TOPLEFT", 3, -3)
	mark:SetPoint("BOTTOMRIGHT", -3, 3)
	mark:SetTexture(WHITE)
	mark:SetVertexColor(A[1], A[2], A[3], 1)
	c.text = c:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	c.text:SetPoint("LEFT", box, "RIGHT", 6, 0)
	c.text:SetText(label or "")
	c:SetHitRectInsets(0, -(c.text:GetStringWidth() + 10), 0, 0)
	c.Refresh = function() mark:SetShown(get() and true or false) end
	c:SetScript("OnClick", function()
		set(not get())
		c.Refresh()
	end)
	c:SetScript("OnShow", function()
		c:SetHitRectInsets(0, -(c.text:GetStringWidth() + 10), 0, 0)
		c.Refresh()
	end)
	c.Refresh()
	return c
end

------------------------------------------------------------
-- Eingabefeld (einzeilig oder mehrzeilig, mit grauem Platzhalter)
------------------------------------------------------------
function UI:Edit(parent, w, h, placeholder, multi, maxLetters)
	local holder = CreateFrame("Frame", nil, parent, BACKDROP)
	holder:SetSize(w or 200, h or 24)
	UI.Box(holder, 0.04, 0.05, 0.07, 1, 0.25, 0.28, 0.34, 1)
	local e = CreateFrame("EditBox", nil, holder)
	e:SetPoint("TOPLEFT", 6, multi and -5 or 0)
	e:SetPoint("BOTTOMRIGHT", -6, multi and 5 or 0)
	e:SetFontObject(ChatFontNormal)
	e:SetAutoFocus(false)
	e:SetMultiLine(multi and true or false)
	e:SetMaxLetters(maxLetters or 255)
	if multi then e:SetJustifyV("TOP") end
	local ph = e:CreateFontString(nil, "OVERLAY", "GameFontDisable")
	ph:SetPoint("TOPLEFT", 0, multi and -1 or -6)
	ph:SetPoint("RIGHT")
	ph:SetJustifyH("LEFT")
	if not multi then
		-- einzeilig: langer Platzhalter wird mit "…" gekürzt statt umzubrechen; ganzer Text als Tooltip
		ph:SetWordWrap(false)
		if ph.SetNonSpaceWrap then ph:SetNonSpaceWrap(false) end
		ph:SetHeight(14)
		-- Ingametest 17.11. 19:27 (T185 WARNUNG recruit>texts, progress>achv …): der Tooltip hing nur am Rahmen, die Maus ist aber über
		-- dem Eingabefeld (das die Maus fängt) – er kam praktisch nie. Jetzt am Feld selbst, und auch für einen eingetragenen Text, der
		-- breiter ist als das Feld (ganzer Text im Tooltip, solange man nicht gerade schreibt).
		local meter
		local function FullTip(owner)
			local full
			if ph:IsShown() and ph:IsTruncated() then
				full = placeholder
			elseif not e:HasFocus() then
				local t = e:GetText()
				if type(t) == "string" and t ~= "" and not ns.IsSecret(t) then
					if not meter then
						meter = holder:CreateFontString(nil, "OVERLAY")
						meter:SetFontObject(ChatFontNormal)
						meter:Hide()
					end
					meter:SetText(t)
					local sw, w = meter:GetStringWidth(), e:GetWidth()
					if type(sw) == "number" and type(w) == "number" and sw > w then full = t end
				end
			end
			if full and full ~= "" then
				ns.UI.TipOwner(owner, "ANCHOR_TOP")
				GameTooltip:SetText(full, 1, 1, 1, 1, true)
				GameTooltip:Show()
			end
		end
		holder:SetScript("OnEnter", function() FullTip(holder) end)
		holder:SetScript("OnLeave", function() GameTooltip:Hide() end)
		e:SetScript("OnEnter", function() FullTip(e) end)
		e:SetScript("OnLeave", function() GameTooltip:Hide() end)
	end
	ph:SetText(placeholder or "")
	local function UpdatePh() ph:SetShown(e:GetText() == "" and not e:HasFocus()) end
	e:SetScript("OnEditFocusGained", function(self) UpdatePh(); holder:SetBackdropBorderColor(A[1], A[2], A[3], 1) end)
	e:SetScript("OnEditFocusLost", function(self)
		UpdatePh()
		holder:SetBackdropBorderColor(0.25, 0.28, 0.34, 1)
		if holder.onCommit then holder.onCommit(self:GetText()) end
	end)
	e:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
	e:SetScript("OnEnterPressed", function(self)
		if multi then self:Insert("\n") return end
		if holder.onEnter then holder.onEnter(self:GetText()) end
		self:ClearFocus()
	end)
	e:SetScript("OnTextChanged", function(self, user)
		UpdatePh()
		if holder.onChange then holder.onChange(self:GetText(), user) end
	end)
	holder:EnableMouse(true)
	holder:SetScript("OnMouseDown", function() e:SetFocus() end)
	holder.edit = e
	holder.ph = ph
	holder.SetText = function(_, t) e:SetText(t or ""); UpdatePh() end
	holder.GetText = function() return e:GetText() end
	holder.ClearFocus = function() e:ClearFocus() end
	holder.SetEnabled = function(_, on)
		e:SetEnabled(on)
		e:SetTextColor(on and 1 or 0.5, on and 1 or 0.5, on and 1 or 0.5)
	end
	UpdatePh()
	return holder
end

-- Shift-Klick auf ein Item fügt den Link in unser Eingabefeld ein
function UI:AcceptLinks(holder)
	self.linkBoxes[#self.linkBoxes + 1] = holder.edit
end

if hooksecurefunc and ChatEdit_InsertLink then
	hooksecurefunc("ChatEdit_InsertLink", function(link)
		if type(link) ~= "string" then return end
		for _, e in ipairs(UI.linkBoxes) do
			if e:HasFocus() then e:Insert(link) return end
		end
	end)
end

------------------------------------------------------------
-- Auswahlliste (eigenes Menü, kein UIDropDownMenu)
------------------------------------------------------------
local menu, catcher

local function CloseMenu()
	if menu then menu:Hide() end
	if catcher then catcher:Hide() end
end
UI.CloseMenu = CloseMenu

local function OpenMenu(anchor, items, current, onSelect)
	if not menu then
		catcher = CreateFrame("Button", nil, UIParent)
		catcher:SetAllPoints(UIParent)
		catcher:SetFrameStrata("FULLSCREEN")
		catcher:SetScript("OnClick", CloseMenu)
		menu = CreateFrame("Frame", "GuildSentinelMenu", UIParent, BACKDROP)
		menu:SetFrameStrata("FULLSCREEN_DIALOG")
		UI.Box(menu, 0.07, 0.08, 0.11, 0.98, A[1], A[2], A[3], 0.6)
		menu.buttons = {}
		-- Escape schliesst nur die Auswahl: solange sie offen ist, steht sie statt des Hauptfensters
		-- in der Liste der Fenster, die das Spiel mit Escape schliesst
		menu:SetScript("OnHide", function()
			if catcher then catcher:Hide() end
			UI:SetEscTarget(false)
		end)
	end
	-- lange Listen in Spalten zu höchstens 20 Einträgen (z. B. alle Dungeons in TBC oder WoW Forever)
	local n = #items
	local rows = math.min(n, 20)
	local cols = math.max(1, math.ceil(n / 20))
	if menu.SetClampedToScreen then menu:SetClampedToScreen(true) end
	-- erst alle Texte setzen, dann die Breite nach dem längsten Eintrag
	local w = math.max(anchor:GetWidth(), 140)
	for i = 1, n do
		local b = menu.buttons[i]
		if not b then
			b = CreateFrame("Button", nil, menu)
			b:SetHeight(20)
			b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
			b.text:SetPoint("LEFT", 8, 0)
			b.text:SetPoint("RIGHT", -8, 0)
			b.text:SetJustifyH("LEFT")
			b.text:SetWordWrap(false)
			local hl = b:CreateTexture(nil, "HIGHLIGHT")
			hl:SetAllPoints()
			hl:SetTexture(WHITE)
			hl:SetVertexColor(A[1], A[2], A[3], 0.25)
			menu.buttons[i] = b
		end
		local it = items[i]
		b.text:SetText((it.value == current and "|TInterface\\Buttons\\UI-CheckBox-Check:14|t" or "    ") .. it.text)
		w = math.max(w, (b.text:GetStringWidth() or 0) + 24)
		b:SetScript("OnClick", function() CloseMenu(); onSelect(it.value, it) end)
		-- Maus darüber: ganzer Text (z. B. fertiger Werbetext eines Vorschlags)
		if it.tip then
			b:SetScript("OnEnter", function(self)
				ns.UI.TipOwner(self, "ANCHOR_RIGHT")
				GameTooltip:AddLine(it.tip, 1, 1, 1, true)
				GameTooltip:Show()
			end)
			b:SetScript("OnLeave", function() GameTooltip:Hide() end)
		else
			b:SetScript("OnEnter", nil)
			b:SetScript("OnLeave", nil)
		end
		b:Show()
	end
	w = math.min(w, 420)
	for i = 1, n do
		local b = menu.buttons[i]
		local col, row = math.floor((i - 1) / rows), (i - 1) % rows
		b:ClearAllPoints()
		b:SetPoint("TOPLEFT", 1 + col * w, -2 - row * 20)
		b:SetWidth(w - 2)
	end
	for i = n + 1, #menu.buttons do menu.buttons[i]:Hide() end
	menu:SetSize(w * cols, rows * 20 + 4)
	menu:ClearAllPoints()
	menu:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -2)
	catcher:Show()
	menu:Show()
	UI:SetEscTarget(true)
end

-- menuOpen = true: Escape schliesst die Auswahlliste; false: wieder das Hauptfenster
function UI:SetEscTarget(menuOpen)
	if not UISpecialFrames then return end
	local function Remove(name)
		for i = #UISpecialFrames, 1, -1 do if UISpecialFrames[i] == name then table.remove(UISpecialFrames, i) end end
	end
	Remove("GuildSentinelMenu")
	Remove("GuildSentinelFrame")
	table.insert(UISpecialFrames, menuOpen and "GuildSentinelMenu" or "GuildSentinelFrame")
end

function UI:PopupMenu(anchor, items, onSelect)
	OpenMenu(anchor, items, nil, onSelect)
end

-- items(): { { value, text } }
function UI:Dropdown(parent, w, items, get, set)
	local b = CreateFrame("Button", nil, parent, BACKDROP)
	b:SetSize(w or 150, 24)
	UI.Box(b, 0.04, 0.05, 0.07, 1, 0.25, 0.28, 0.34, 1)
	b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	b.text:SetPoint("LEFT", 8, 0)
	b.text:SetPoint("RIGHT", -20, 0)
	b.text:SetJustifyH("LEFT")
	b.text:SetWordWrap(false)
	local arrow = b:CreateTexture(nil, "OVERLAY")
	arrow:SetSize(14, 14)
	arrow:SetPoint("RIGHT", -4, 0)
	arrow:SetTexture("Interface\\ChatFrame\\ChatFrameExpandArrow")
	arrow:SetRotation(-math.pi / 2)
	local hl = b:CreateTexture(nil, "HIGHLIGHT")
	hl:SetPoint("TOPLEFT", 1, -1)
	hl:SetPoint("BOTTOMRIGHT", -1, 1)
	hl:SetTexture(WHITE)
	hl:SetVertexColor(1, 1, 1, 0.06)
	-- Ingametest 17.11. 19:27 (T185): "wie der Spiel-Client (Deutsc…" – mit b.maxW wächst die Auswahl bis zur Breite ihres Textes
	-- (höchstens maxW; ohne maxW feste Breite wie bisher)
	b.baseW = w or 150
	local function Fit()
		if not b.maxW then return end
		b.text:SetFontObject(GameFontHighlight)
		local sw = b.text:GetStringWidth()
		if type(sw) ~= "number" or ns.IsSecret(sw) then return end
		local nw = math.min(math.max(b.baseW, math.ceil(sw) + 30), b.maxW)
		if math.abs((b:GetWidth() or 0) - nw) > 0.5 then b:SetWidth(nw) end
		-- 0.9.57 (OPT-ALLE, esMX "como el cliente del juego (Español (México))"): passt der Text auch in maxW nicht, kleinere Schrift
		if sw + 30 > b.maxW + 0.5 then b.text:SetFontObject(GameFontHighlightSmall) end
	end
	b.Refresh = function()
		local cur = get()
		for _, it in ipairs(items()) do
			if it.value == cur then b.text:SetText(it.text) Fit() return end
		end
		b.text:SetText("")
		Fit()
	end
	b:SetScript("OnClick", function(self)
		if menu and menu:IsShown() then CloseMenu() return end
		OpenMenu(self, items(), get(), function(v)
			set(v)
			b.Refresh()
		end)
	end)
	b:SetScript("OnShow", b.Refresh)
	return b
end

------------------------------------------------------------
-- Reiter innerhalb einer Seite
------------------------------------------------------------
function UI:Tabs(parent, list, onSelect)
	local bar = CreateFrame("Frame", nil, parent)
	bar:SetHeight(26)
	bar.buttons = {}
	local x = 0
	for i, t in ipairs(list) do
		local b = CreateFrame("Button", nil, bar)
		b:SetHeight(26)
		b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
		b.text:SetPoint("CENTER")
		b.text:SetText(t.text)
		b:SetWidth(b.text:GetStringWidth() + 28)
		b:SetPoint("LEFT", x, 0)
		x = x + b:GetWidth() + 4
		b.line = b:CreateTexture(nil, "ARTWORK")
		b.line:SetTexture(WHITE)
		b.line:SetPoint("BOTTOMLEFT")
		b.line:SetPoint("BOTTOMRIGHT")
		b.line:SetHeight(2)
		b.line:SetVertexColor(A[1], A[2], A[3], 1)
		local hl = b:CreateTexture(nil, "HIGHLIGHT")
		hl:SetAllPoints()
		hl:SetTexture(WHITE)
		hl:SetVertexColor(1, 1, 1, 0.05)
		b:SetScript("OnClick", function() bar:Select(t.key) end)
		b.key = t.key
		bar.buttons[i] = b
	end
	local base = bar:CreateTexture(nil, "BACKGROUND")
	base:SetTexture(WHITE)
	base:SetPoint("BOTTOMLEFT")
	base:SetPoint("BOTTOMRIGHT")
	base:SetHeight(1)
	base:SetVertexColor(0.25, 0.28, 0.34, 1)
	-- Reiter ausgeschalteter Funktionen ausblenden (t.feature)
	function bar:Layout()
		local px = 0
		for i, b in ipairs(self.buttons) do
			local on = ns.Feature(list[i].feature)
			b:SetShown(on)
			b:ClearAllPoints()
			if on then
				b:SetPoint("LEFT", px, 0)
				px = px + b:GetWidth() + 4
			end
		end
		if self.current and not self:IsVisible(self.current) then
			local first = self:FirstVisible()
			if first then self:Select(first) end
		end
	end
	function bar:IsVisible(key)
		for i, b in ipairs(self.buttons) do
			if b.key == key then return ns.Feature(list[i].feature) end
		end
		return false
	end
	function bar:FirstVisible()
		for i, b in ipairs(self.buttons) do
			if ns.Feature(list[i].feature) then return b.key end
		end
	end
	function bar:Select(key)
		if not self:IsVisible(key) then key = self:FirstVisible() or key end
		self.current = key
		for _, b in ipairs(self.buttons) do
			local sel = b.key == key
			b.line:SetShown(sel)
			if sel then b.text:SetTextColor(1, 1, 1) else b.text:SetTextColor(0.6, 0.62, 0.66) end
		end
		onSelect(key)
	end
	-- Zähler hinter dem Reiternamen (z. B. "Bewerber (3)")
	function bar:SetLabel(key, text)
		for _, b in ipairs(self.buttons) do
			if b.key == key then
				b.text:SetText(text)
				b:SetWidth(b.text:GetStringWidth() + 28)
			end
		end
		self:Layout()
	end
	-- Breiten beim Anzeigen neu messen: beim allerersten Aufbau nach dem Einloggen ist die Schrift
	-- manchmal noch nicht geladen, dann sind die Reiter zu schmal und überlappen
	function bar:Remeasure()
		for _, b in ipairs(self.buttons) do b:SetWidth(b.text:GetStringWidth() + 28) end
		self:Layout()
	end
	bar:SetScript("OnShow", function(self) self:Remeasure() end)
	UI.tabBars = UI.tabBars or {}
	table.insert(UI.tabBars, bar)
	bar:Layout()
	return bar
end

------------------------------------------------------------
-- Liste mit Spalten, Sortierung, Auswahl und Bildlauf
------------------------------------------------------------
-- cols: { { key, title, width (nil = Rest), align, icon = true } }
-- opts: render(item) -> { Texte je Spalte }, icon(item) -> Textur, key(item), onClick(item, button),
--       onEnter(row, item), onSort(key), rowH, empty = Text bei leerer Liste
function UI:List(parent, cols, opts)
	opts = opts or {}
	local rowH = opts.rowH or 20
	local f = CreateFrame("Frame", nil, parent, BACKDROP)
	UI.Box(f, 0.06, 0.07, 0.09, 1, 0.18, 0.2, 0.25, 1)
	f.data, f.offset, f.rows = {}, 0, {}
	f.cols, f.noHeader = cols, opts.noHeader and true or nil   -- für die Prüfung Lesbarkeit (L2/L6, Testroutine T313/T314)

	local headerH = opts.noHeader and 0 or 22
	local header = CreateFrame("Frame", nil, f, BACKDROP)
	header:SetPoint("TOPLEFT", 1, -1)
	header:SetPoint("TOPRIGHT", -1, -1)
	header:SetHeight(math.max(headerH, 1))
	if headerH > 0 then UI.Box(header, 0.1, 0.11, 0.15, 1, 0, 0, 0, 0) else header:Hide() end

	local body = CreateFrame("Frame", nil, f)
	body:SetPoint("TOPLEFT", 1, -1 - headerH)
	body:SetPoint("BOTTOMRIGHT", -11, 1)
	body:SetClipsChildren(true)

	-- Bildlaufleiste
	local bar = CreateFrame("Slider", nil, f, BACKDROP)
	bar:SetPoint("TOPRIGHT", -2, -2 - headerH)
	bar:SetPoint("BOTTOMRIGHT", -2, 2)
	bar:SetWidth(7)
	bar:SetOrientation("VERTICAL")
	UI.Box(bar, 0.04, 0.05, 0.07, 1, 0, 0, 0, 0)
	local thumb = bar:CreateTexture(nil, "OVERLAY")
	thumb:SetTexture(WHITE)
	thumb:SetVertexColor(0.35, 0.38, 0.45, 1)
	thumb:SetSize(7, 30)
	bar:SetThumbTexture(thumb)
	bar:SetValueStep(1)
	if bar.SetObeyStepOnDrag then bar:SetObeyStepOnDrag(true) end
	bar:SetMinMaxValues(0, 0)
	bar:SetValue(0)
	bar:SetScript("OnValueChanged", function(_, v)
		v = math.floor(v + 0.5)
		if v ~= f.offset then f.offset = v; f:Draw() end
	end)

	-- Spaltenpositionen
	-- Befund 3 (Ingametest 17.11., T185): feste Spalten wachsen bis zur Breite ihrer Überschrift und ihrer Zahlen (c.grow, nur
	-- wachsend, damit nichts springt); Zahlen und Überschriften werden nie gekürzt, die freie Spalte bekommt den Rest
	local function Layout(width)
		local fixed, flex = 0, 0
		for _, c in ipairs(cols) do
			if c.width then fixed = fixed + math.max(c.width, c.grow or 0) else flex = flex + 1 end
		end
		local rest = math.max(40, (width - fixed - 8 * #cols) / math.max(flex, 1))
		local x = 6
		for _, c in ipairs(cols) do
			c.x = x
			c.w = c.width and math.max(c.width, c.grow or 0) or math.max(rest, c.grow or 0)   -- freie Spalte: mindestens ihre Überschrift
			x = x + c.w + 8
		end
	end
	local function Grow(c, need)
		if c.width and need > (c.w or c.width) + 0.5 and need > (c.grow or 0) then c.grow = math.ceil(need) return true end
		return false
	end

	local headButtons = {}
	local function BuildHeader()
		for i, c in ipairs(cols) do
			local hb = headButtons[i]
			if not hb then
				hb = CreateFrame("Button", nil, header)
				hb.text = hb:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
				hb.text:SetAllPoints()
				hb.text:SetJustifyH(c.align or "LEFT")
				hb.text:SetTextColor(0.75, 0.78, 0.82)
				hb:SetScript("OnClick", function()
					if c.sort and opts.onSort then opts.onSort(c.sort) end
				end)
				headButtons[i] = hb
			end
			hb:SetPoint("TOPLEFT", c.x, 0)
			hb:SetSize(c.w, headerH)
			local arrow = ""
			if f.sortKey and c.sort == f.sortKey then arrow = f.sortDesc and " |TInterface\\Buttons\\Arrow-Down-Up:10|t" or " |TInterface\\Buttons\\Arrow-Up-Up:10|t" end
			hb.text:SetText(c.title .. arrow)
			local sw = hb.text:GetStringWidth()
			if type(sw) == "number" and not ns.IsSecret(sw) then
				if c.width then
					if Grow(c, sw + 4) then f.needLayout = true end
				elseif sw + 4 > (c.w or 0) + 0.5 and sw + 4 > (c.grow or 0) then
					c.grow = math.ceil(sw + 4); f.needLayout = true
				end
			end
		end
	end

	local function MakeRow(i)
		local r = CreateFrame("Button", nil, body)
		r:SetHeight(rowH)
		r:SetPoint("TOPLEFT", 0, -(i - 1) * rowH)
		r:SetPoint("RIGHT")
		r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
		r.bg = r:CreateTexture(nil, "BACKGROUND")
		r.bg:SetAllPoints()
		r.bg:SetTexture(WHITE)
		r.sel = r:CreateTexture(nil, "BORDER")
		r.sel:SetAllPoints()
		r.sel:SetTexture(WHITE)
		-- 0.9.59 L1 (Kontrast, T311): die Fläche der gewählten Zeile war so hell (Akzent 22 %), dass graue und rote Schrift darauf
		-- unter 4,5:1 fiel (Nachbau: grau 3,7:1). Jetzt schwache Fläche (6 %, grau 4,6:1, rot 4,6:1 mit Streifen) und ein
		-- Akzentstreifen links, damit die Wahl gut sichtbar bleibt.
		r.sel:SetVertexColor(A[1], A[2], A[3], 0.06)
		r.sel:Hide()
		r.selBar = r:CreateTexture(nil, "ARTWORK")
		r.selBar:SetPoint("TOPLEFT")
		r.selBar:SetPoint("BOTTOMLEFT")
		r.selBar:SetWidth(3)
		r.selBar:SetTexture(WHITE)
		r.selBar:SetVertexColor(A[1], A[2], A[3], 1)
		r.selBar:Hide()
		local hl = r:CreateTexture(nil, "HIGHLIGHT")
		hl:SetAllPoints()
		hl:SetTexture(WHITE)
		hl:SetVertexColor(1, 1, 1, 0.06)
		r.cells = {}
		for k, c in ipairs(cols) do
			local fs = r:CreateFontString(nil, "OVERLAY", opts.font or "GameFontHighlightSmall")
			fs:SetJustifyH(c.align or "LEFT")
			fs:SetWordWrap(false)
			r.cells[k] = fs
			if c.icon then
				r.icon = r:CreateTexture(nil, "ARTWORK")
				r.icon:SetSize(rowH - 4, rowH - 4)
			end
		end
		r:SetScript("OnClick", function(self, button)
			if not self.item then return end
			f.selectedKey = opts.key and opts.key(self.item) or self.item
			f:Draw()
			if opts.onClick then opts.onClick(self.item, button) end
		end)
		-- Befund 3 (Ingametest 17.11., T185): eine gekürzte Zelle zeigt ihren ganzen Text im Tooltip der Zeile
		-- (Entscheid zu gekürzten Tabellenzellen, AHSentinel T750: Zahlen nie kürzen, der Tooltip zeigt genau den ganzen Text)
		function r:CutCells()
			local out = {}
			for k, fs in ipairs(self.cells) do
				local t = fs:IsShown() and fs:GetText() or nil
				if type(t) == "string" and t ~= "" and not ns.IsSecret(t) then
					local cut = fs.IsTruncated and fs:IsTruncated()
					if cut == nil then
						local sw, w = fs:GetStringWidth(), fs:GetWidth()
						cut = type(sw) == "number" and type(w) == "number" and sw > w + 1
					end
					if cut then out[#out + 1] = { fs = fs, k = k, text = t } end
				end
			end
			return out
		end
		function r:ShowsFull(fs)
			for _, x in ipairs(self.lastCut or {}) do if x.fs == fs then return true end end
			return false
		end
		r:SetScript("OnEnter", function(self)
			if not self.item then return end
			if opts.onEnter then opts.onEnter(self, self.item) end
			local cutList = self:CutCells()
			self.lastCut = cutList
			if #cutList > 0 then
				if not (GameTooltip:IsShown() and GameTooltip:GetOwner() == self) then
					ns.UI.TipOwner(self, "ANCHOR_RIGHT")
				end
				for _, x in ipairs(cutList) do
					local title = cols[x.k] and cols[x.k].title or ""
					GameTooltip:AddLine((title ~= "" and (title .. ": ") or "") .. x.text, 1, 1, 1, true)
				end
				GameTooltip:Show()
			end
		end)
		r:SetScript("OnLeave", function() GameTooltip:Hide() end)
		return r
	end

	local emptyText = body:CreateFontString(nil, "OVERLAY", "GameFontDisable")
	emptyText:SetPoint("TOPLEFT", 12, -14)
	emptyText:SetPoint("RIGHT", -12, 0)
	emptyText:SetJustifyH("LEFT")

	function f:Visible()
		return math.max(1, math.floor((body:GetHeight() or rowH) / rowH))
	end

	function f:Draw()
		local width = body:GetWidth()
		if not width or width < 10 then return end
		f.needLayout = false
		Layout(width)
		if headerH > 0 then BuildHeader() end
		local n = self:Visible()
		local maxOff = math.max(0, #self.data - n)
		if self.offset > maxOff then self.offset = maxOff end
		bar:SetMinMaxValues(0, maxOff)
		bar:SetValue(self.offset)
		bar:SetShown(maxOff > 0)
		thumb:SetHeight(math.max(20, (body:GetHeight() or 100) * n / math.max(n, #self.data)))
		for i = 1, n do
			local r = self.rows[i] or MakeRow(i)
			self.rows[i] = r
			local item = self.data[self.offset + i]
			r.item = item
			if item then
				local texts = opts.render(item) or {}
				for k, c in ipairs(cols) do
					local fs = r.cells[k]
					local x = c.x
					if c.icon and r.icon then
						r.icon:ClearAllPoints()
						r.icon:SetPoint("LEFT", c.x, 0)
						r.icon:SetTexture(opts.icon and opts.icon(item) or nil)
						r.icon:SetShown(opts.icon and opts.icon(item) ~= nil)
						x = x + rowH
					end
					fs:ClearAllPoints()
					fs:SetPoint("LEFT", x, 0)
					fs:SetWidth(c.w - (x - c.x))
					fs:SetText(texts[k] or "")
					-- Zahlen nie kürzen: Spalte mit Zahl wächst (einmal neu anordnen, siehe unten)
					local t = texts[k]
					if c.width and type(t) == "string" and t:find("%d") then
						local sw = fs:GetStringWidth()
						if type(sw) == "number" and not ns.IsSecret(sw) and Grow(c, sw + (x - c.x) + 2) then f.needLayout = true end
					end
				end
				r.bg:SetVertexColor(1, 1, 1, ((self.offset + i) % 2 == 0) and 0.025 or 0)
				local key = opts.key and opts.key(item) or item
				r.sel:SetShown(self.selectedKey ~= nil and key == self.selectedKey)
				r.selBar:SetShown(r.sel:IsShown())
				r:Show()
			else
				r:Hide()
			end
		end
		for i = n + 1, #self.rows do self.rows[i]:Hide() end
		emptyText:SetText(#self.data == 0 and (opts.empty or "") or "")
		-- eine Spalte ist gewachsen: genau einmal neu zeichnen (Grow wächst nur, also endet es)
		if f.needLayout and not f.inRelayout then
			f.inRelayout = true
			self:Draw()
			f.inRelayout = false
		end
	end

	-- Text bei leerer Liste ändern (z. B. je nach gewähltem Beruf)
	f.emptyText = emptyText
	function f:SetEmpty(text)
		opts.empty = text
		emptyText:SetText(#(self.data or {}) == 0 and (text or "") or "")
	end

	function f:SetData(data, sortKey, sortDesc)
		self.data = data or {}
		self.sortKey, self.sortDesc = sortKey, sortDesc
		self:Draw()
	end

	function f:Selected()
		if self.selectedKey == nil then return nil end
		for _, item in ipairs(self.data) do
			local key = opts.key and opts.key(item) or item
			if key == self.selectedKey then return item end
		end
		return nil
	end

	function f:ClearSelection()
		self.selectedKey = nil
		self:Draw()
	end

	f:EnableMouseWheel(true)
	f:SetScript("OnMouseWheel", function(self, delta)
		local maxOff = math.max(0, #self.data - self:Visible())
		self.offset = math.max(0, math.min(maxOff, self.offset - delta * 3))
		self:Draw()
	end)
	f:SetScript("OnSizeChanged", function(self) self:Draw() end)
	f:SetScript("OnShow", function(self) self:Draw() end)
	return f
end

------------------------------------------------------------
-- Längerer Text mit Bildlauf (nur lesen)
------------------------------------------------------------
local function AttachWheel(scroll)
	scroll:EnableMouseWheel(true)
	scroll:SetScript("OnMouseWheel", function(self, delta)
		local max = self:GetVerticalScrollRange() or 0
		local v = math.max(0, math.min(max, (self:GetVerticalScroll() or 0) - delta * 40))
		self:SetVerticalScroll(v)
	end)
end

function UI:ScrollText(parent, w, h)
	local holder = CreateFrame("Frame", nil, parent, BACKDROP)
	holder:SetSize(w, h)
	UI.Box(holder, 0.04, 0.05, 0.07, 1, 0.2, 0.22, 0.27, 1)
	local scroll = CreateFrame("ScrollFrame", nil, holder)
	scroll:SetPoint("TOPLEFT", 10, -8)
	scroll:SetPoint("BOTTOMRIGHT", -10, 8)
	local child = CreateFrame("Frame", nil, scroll)
	child:SetSize(w - 20, 10)
	scroll:SetScrollChild(child)
	local fs = child:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	fs:SetPoint("TOPLEFT")
	fs:SetWidth(w - 24)
	fs:SetJustifyH("LEFT")
	fs:SetJustifyV("TOP")
	if fs.SetSpacing then fs:SetSpacing(3) end
	AttachWheel(scroll)
	holder.SetText = function(_, t)
		fs:SetText(t or "")
		child:SetHeight(math.max(10, (fs:GetStringHeight() or 10) + 4))
		scroll:SetVerticalScroll(0)
	end
	holder.GetText = function() return fs:GetText() end
	return holder
end

------------------------------------------------------------
-- Großes Eingabefeld mit Bildlauf (Regeln schreiben, Export kopieren)
------------------------------------------------------------
function UI:ScrollEdit(parent, w, h, maxLetters, placeholder)
	local holder = CreateFrame("Frame", nil, parent, BACKDROP)
	holder:SetSize(w, h)
	UI.Box(holder, 0.04, 0.05, 0.07, 1, 0.25, 0.28, 0.34, 1)
	local scroll = CreateFrame("ScrollFrame", nil, holder)
	scroll:SetPoint("TOPLEFT", 8, -6)
	scroll:SetPoint("BOTTOMRIGHT", -8, 6)
	local e = CreateFrame("EditBox", nil, scroll)
	e:SetMultiLine(true)
	e:SetAutoFocus(false)
	e:SetFontObject(ChatFontNormal)
	e:SetWidth(w - 20)
	e:SetMaxLetters(maxLetters or 3000)
	scroll:SetScrollChild(e)
	AttachWheel(scroll)
	local ph = holder:CreateFontString(nil, "OVERLAY", "GameFontDisable")
	ph:SetPoint("TOPLEFT", 10, -8)
	ph:SetPoint("RIGHT", -10, 0)
	ph:SetJustifyH("LEFT")
	ph:SetText(placeholder or "")
	local function UpdatePh() ph:SetShown(e:GetText() == "" and not e:HasFocus()) end
	e:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
	e:SetScript("OnEditFocusGained", function() UpdatePh(); holder:SetBackdropBorderColor(A[1], A[2], A[3], 1) end)
	e:SetScript("OnEditFocusLost", function() UpdatePh(); holder:SetBackdropBorderColor(0.25, 0.28, 0.34, 1) end)
	e:SetScript("OnTextChanged", function(self, user)
		UpdatePh()
		if scroll.UpdateScrollChildRect then scroll:UpdateScrollChildRect() end
		if holder.onChange then holder.onChange(self:GetText(), user) end
	end)
	-- Cursor sichtbar halten
	e:SetScript("OnCursorChanged", function(_, _, y, _, ch)
		local top = scroll:GetVerticalScroll() or 0
		local hgt = scroll:GetHeight() or h
		y = -(y or 0)
		if y < top then scroll:SetVerticalScroll(y)
		elseif y + (ch or 14) > top + hgt then scroll:SetVerticalScroll(y + (ch or 14) - hgt) end
	end)
	holder:EnableMouse(true)
	holder:SetScript("OnMouseDown", function() e:SetFocus() end)
	holder.edit = e
	holder.ph = ph
	-- neuer Text beginnt immer oben (sonst ist die erste Zeile abgeschnitten)
	local function ToTop()
		if e.SetCursorPosition then e:SetCursorPosition(0) end
		scroll:SetVerticalScroll(0)
	end
	holder.SetText = function(_, t)
		e:SetText(t or "")
		UpdatePh()
		ToTop()
		C_Timer.After(0, ToTop)
	end
	holder.GetText = function() return e:GetText() end
	holder.SetEnabled = function(_, on)
		e:SetEnabled(on)
		e:SetTextColor(on and 1 or 0.6, on and 1 or 0.6, on and 1 or 0.6)
	end
	holder.SelectAll = function() e:SetFocus(); e:HighlightText() end
	UpdatePh()
	return holder
end

------------------------------------------------------------
-- Eingabe-Dialog
------------------------------------------------------------
StaticPopupDialogs["GUILDSENTINEL_INPUT"] = {
	text = "%s",
	button1 = OKAY,
	button2 = CANCEL,
	hasEditBox = 1,
	maxLetters = 60,
	OnShow = function(self, data)
		local eb = self.editBox or self.EditBox
		if eb then eb:SetText(data and data.default or ""); eb:SetFocus() end
	end,
	OnAccept = function(self, data)
		local eb = self.editBox or self.EditBox
		if data and data.fn and eb then data.fn(eb:GetText()) end
	end,
	EditBoxOnEnterPressed = function(self)
		local parent = self:GetParent()
		local data = parent.data
		if data and data.fn then data.fn(self:GetText()) end
		parent:Hide()
	end,
	EditBoxOnEscapePressed = function(self) self:GetParent():Hide() end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
}

function UI:Ask(text, default, fn)
	StaticPopup_Show("GUILDSENTINEL_INPUT", text, nil, { default = default, fn = fn })
end

-- maskierte Eingabe (Passwort der Gildenverwaltung). Der Text wird nie gespeichert oder ausgegeben; das Eingabefeld
-- des Dialogs wird beim Schliessen wieder normal und leer.
local function SecretBox(self) return self.editBox or self.EditBox end
StaticPopupDialogs["GUILDSENTINEL_SECRET"] = {
	text = "%s",
	button1 = OKAY,
	button2 = CANCEL,
	hasEditBox = 1,
	maxLetters = 40,
	OnShow = function(self)
		local eb = SecretBox(self)
		if eb then eb:SetText(""); pcall(function() eb:SetPassword(true) end); eb:SetFocus() end
	end,
	OnHide = function(self)
		local eb = SecretBox(self)
		if eb then eb:SetText(""); pcall(function() eb:SetPassword(false) end) end
	end,
	OnAccept = function(self, data)
		local eb = SecretBox(self)
		local t = eb and eb:GetText() or ""
		-- nächster Dialog erst nach dem Schliessen dieses Dialogs (sonst schliesst ihn das Spiel gleich wieder)
		if data and data.fn then C_Timer.After(0.1, function() data.fn(t) end) end
	end,
	EditBoxOnEnterPressed = function(self)
		local parent = self:GetParent()
		local data, t = parent.data, self:GetText()
		parent:Hide()
		if data and data.fn then C_Timer.After(0.1, function() data.fn(t) end) end
	end,
	EditBoxOnEscapePressed = function(self) self:GetParent():Hide() end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
}

function UI:AskSecret(text, fn)
	StaticPopup_Show("GUILDSENTINEL_SECRET", text, nil, { fn = fn })
end

-- eigene Fenster für die Prüfung der Oberfläche (Testroutine Bereich K)
ns.uiFrames = ns.uiFrames or {}
function ns.RegisterUI(f)
	if f then ns.uiFrames[#ns.uiFrames + 1] = f end
end

StaticPopupDialogs["GUILDSENTINEL_CONFIRM"] = {
	text = "%s",
	button1 = YES,
	button2 = NO,
	OnAccept = function(self, data) if data and data.fn then data.fn() end end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
}

function UI:Confirm(text, fn)
	StaticPopup_Show("GUILDSENTINEL_CONFIRM", text, nil, { fn = fn })
end

-- Hinweisfenster mit längerem Text (Willkommens-Leitfaden, Export für Discord …)
-- editable = true: Text markier- und kopierbar
function UI:Info(title, text, editable)
	local f = self.infoFrame
	if not f then
		f = CreateFrame("Frame", "GuildSentinelInfo", UIParent, BACKDROP)
		f:SetSize(560, 440)
		f:SetPoint("CENTER", 0, 40)
		f:SetFrameStrata("DIALOG")
		f:SetClampedToScreen(true)
		f:SetMovable(true)
		f:EnableMouse(true)
		f:RegisterForDrag("LeftButton")
		f:SetScript("OnDragStart", function() f:StartMoving() end)
		f:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)
		UI.Box(f, 0.05, 0.06, 0.08, 0.98, A[1], A[2], A[3], 0.8)
		tinsert(UISpecialFrames, "GuildSentinelInfo")
		f.title = UI:Label(f, "", "GameFontNormalLarge")
		f.title:SetPoint("TOPLEFT", 16, -14)
		f.text = UI:ScrollText(f, 528, 330)
		f.text:SetPoint("TOPLEFT", 16, -44)
		f.edit = UI:ScrollEdit(f, 528, 330, 20000)
		f.edit:SetPoint("TOPLEFT", 16, -44)
		f.ok = UI:Button(f, OKAY or "OK", 140, 28, function() f:Hide() end, true)
		f.ok:SetPoint("BOTTOMRIGHT", -16, 14)
		f.sel = UI:Button(f, L["Alles markieren"], 140, 28, function() f.edit.SelectAll() end)
		f.sel:SetPoint("RIGHT", f.ok, "LEFT", -8, 0)
		self.infoFrame = f
	end
	f.title:SetText(title or "")
	f.text:SetShown(not editable)
	f.edit:SetShown(editable and true or false)
	f.sel:SetShown(editable and true or false)
	if editable then f.edit:SetText(text or "") else f.text:SetText(text or "") end
	f:Show()
end

------------------------------------------------------------
-- Hauptfenster
------------------------------------------------------------
function UI:AddPage(page)
	self.pages[#self.pages + 1] = page
	-- Reihenfolge in der Navigation (page.order, kleiner = weiter oben)
	table.sort(self.pages, function(a, b) return (a.order or 50) < (b.order or 50) end)
end

-- G-4: Aufbau des Fensters messen (beim ersten Öffnen über 800 Frames und 1300 Schriften/Texturen in einem Bild – Verdacht,
-- dass daher die seltenen Spitzen kommen). Länger als ein Bild -> Eintrag LANGSAM "Fenster aufbauen" im Diagnose-Protokoll.
function UI:Build()
	if ns.Timed then return ns.Timed("Fenster aufbauen", self.BuildNow, self) end
	return self:BuildNow()
end

function UI:BuildNow()
	local f = CreateFrame("Frame", "GuildSentinelFrame", UIParent, BACKDROP)
	f:SetSize(980, 620)
	f:SetPoint("CENTER")
	f:SetFrameStrata("HIGH")
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:EnableMouse(true)
	f:SetToplevel(true)
	UI.Box(f, 0.05, 0.06, 0.08, 0.97, A[1], A[2], A[3], 0.7)
	f:Hide()
	tinsert(UISpecialFrames, "GuildSentinelFrame")

	-- Titelleiste
	local title = CreateFrame("Frame", nil, f, BACKDROP)
	title:SetPoint("TOPLEFT", 1, -1)
	title:SetPoint("TOPRIGHT", -1, -1)
	title:SetHeight(36)
	UI.Box(title, 0.09, 0.11, 0.15, 1, 0, 0, 0, 0)
	title:EnableMouse(true)
	title:RegisterForDrag("LeftButton")
	title:SetScript("OnDragStart", function() f:StartMoving() end)
	title:SetScript("OnDragStop", function()
		f:StopMovingOrSizing()
		local p, _, rp, x, y = f:GetPoint()
		ns.db.framePoint = { p, rp, x, y }
	end)
	local icon = title:CreateTexture(nil, "ARTWORK")
	icon:SetSize(24, 24)
	icon:SetPoint("LEFT", 10, 0)
	icon:SetTexture(ns.ICON)
	local tt = title:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	tt:SetPoint("LEFT", icon, "RIGHT", 8, 0)
	tt:SetText(ns.TITLE .. "  |cff9aa0a6v" .. ns.version .. "|r")   -- 0.9.59 L1: grau 808080 hatte 4,3:1 auf der Titelleiste, jetzt 6,4:1
	-- 0.9.58 (Befund Nutzer 18.11. 13:46 "oben rechts das ist nichts schönes"): rechts in der Titelleiste im Stil des Fensters –
	-- flaches Schliessen-X (statt rot-goldenem Blizzard-X), "Unterstützen" zurückhaltend als kleines Münz-Symbol mit Tooltip (statt
	-- grauem Knopf), Gildeninfo mit Abstand. Alle drei gleich hoch (24) und auf derselben Mittellinie.
	self.closeBtn = UI.TitleButton(title, function() f:Hide() end)
	self.closeBtn:SetPoint("RIGHT", -6, 0)
	self.closeBtn.label = self.closeBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	self.closeBtn.label:SetPoint("CENTER", 0, 1)
	self.closeBtn.label:SetText("X")
	self.closeBtn.label:SetTextColor(0.62, 0.66, 0.74)
	self.closeBtn:HookScript("OnEnter", function(s)
		s.label:SetTextColor(1, 1, 1)
		s.bg:SetVertexColor(0.55, 0.16, 0.16, 0.9)
	end)
	self.closeBtn:HookScript("OnLeave", function(s)
		s.label:SetTextColor(0.62, 0.66, 0.74)
		s.bg:SetVertexColor(1, 1, 1, 0)
	end)
	UI.Tip(self.closeBtn, CLOSE or L["Schließen"])
	-- Spenden: kleines Symbol, öffnet sich nur auf Klick (Tooltip sagt, was es ist)
	self.donateBtn = UI.TitleButton(title, function() ns.Donate.Show() end)
	self.donateBtn:SetPoint("RIGHT", self.closeBtn, "LEFT", -8, 0)
	self.donateBtn.icon = self.donateBtn:CreateTexture(nil, "ARTWORK")
	self.donateBtn.icon:SetSize(16, 16)
	self.donateBtn.icon:SetPoint("CENTER")
	self.donateBtn.icon:SetTexture("Interface\\Icons\\INV_Misc_Coin_01")
	self.donateBtn.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	self.donateBtn.icon:SetAlpha(0.55)
	self.donateBtn.isDonate = true
	self.donateBtn:HookScript("OnEnter", function(s)
		s.icon:SetAlpha(1)
		s.bg:SetVertexColor(1, 1, 1, 0.10)
		ns.UI.TipOwner(s, "ANCHOR_BOTTOM")
		GameTooltip:SetText(L["Addon unterstützen"], 1, 1, 1)
		GameTooltip:AddLine(L["Öffnet das Fenster mit den Möglichkeiten, GuildSentinel zu unterstützen."], 0.8, 0.8, 0.8, true)
		GameTooltip:Show()
	end)
	self.donateBtn:HookScript("OnLeave", function(s)
		s.icon:SetAlpha(0.55)
		s.bg:SetVertexColor(1, 1, 1, 0)
		GameTooltip:Hide()
	end)
	self.guildText = title:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	self.guildText:SetPoint("RIGHT", self.donateBtn, "LEFT", -16, 0)
	self.guildText:SetPoint("LEFT", tt, "RIGHT", 16, 0)
	self.guildText:SetJustifyH("RIGHT")
	self.guildText:SetWordWrap(false)

	-- Navigation
	local nav = CreateFrame("Frame", nil, f, BACKDROP)
	nav:SetPoint("TOPLEFT", 1, -37)
	nav:SetPoint("BOTTOMLEFT", 1, 1)
	nav:SetWidth(176)
	UI.Box(nav, 0.07, 0.08, 0.11, 1, 0, 0, 0, 0)

	local content = CreateFrame("Frame", nil, f)
	content:SetPoint("TOPLEFT", nav, "TOPRIGHT", 12, -10)
	content:SetPoint("BOTTOMRIGHT", -12, 12)
	self.content = content

	self.frame, self.panels, self.tabs = f, {}, {}
	for i, page in ipairs(self.pages) do
		local panel = CreateFrame("Frame", nil, content)
		panel:SetAllPoints()
		panel:Hide()
		-- GS-N2: Seiten erst beim ersten Anwählen bauen (vorher entstanden beim ersten Öffnen alle Seiten in einem Bild:
		-- über 800 Frames und 1300 Schriften/Texturen). Gemessen im Nachbau mit test/perf_open.lua.
		self.panels[i] = panel

		local tab = CreateFrame("Button", nil, nav)
		tab:SetSize(174, 34)
		tab:SetPoint("TOPLEFT", 1, -10 - (i - 1) * 36)
		tab.bg = tab:CreateTexture(nil, "BACKGROUND")
		tab.bg:SetAllPoints()
		tab.bg:SetTexture(WHITE)
		tab.bg:SetVertexColor(A[1], A[2], A[3], 0)
		tab.bar = tab:CreateTexture(nil, "ARTWORK")
		tab.bar:SetTexture(WHITE)
		tab.bar:SetPoint("TOPLEFT")
		tab.bar:SetPoint("BOTTOMLEFT")
		tab.bar:SetWidth(3)
		tab.bar:SetVertexColor(A[1], A[2], A[3], 1)
		tab.bar:Hide()
		local hl = tab:CreateTexture(nil, "HIGHLIGHT")
		hl:SetAllPoints()
		hl:SetTexture(WHITE)
		hl:SetVertexColor(1, 1, 1, 0.06)
		tab.icon = tab:CreateTexture(nil, "ARTWORK")
		tab.icon:SetSize(20, 20)
		tab.icon:SetPoint("LEFT", 14, 0)
		tab.icon:SetTexture(page.icon)
		tab.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
		tab.text = tab:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
		tab.text:SetPoint("LEFT", tab.icon, "RIGHT", 10, 0)
		tab.text:SetText(L[page.title])
		tab.badge = tab:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
		tab.badge:SetPoint("RIGHT", -12, 0)
		tab:SetScript("OnClick", function() UI:Select(i) end)
		self.tabs[i] = tab
	end

	-- unten in der Navigation: Abgleich-Status
	self.syncText = nav:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	self.syncText:SetPoint("BOTTOMLEFT", 12, 10)
	self.syncText:SetPoint("RIGHT", -8, 0)
	self.syncText:SetJustifyH("LEFT")

	f:SetScript("OnShow", function()
		if ns.GuildRoster then ns.GuildRoster() end
		UI:RefreshHeader()
		if UI.current then UI:Select(UI.current) end
		UI:Prebuild()
	end)
	f:SetScript("OnHide", function() CloseMenu(); ns:Fire("GS_HIDE") end)

	local pt = ns.db.framePoint
	if pt then
		f:ClearAllPoints()
		f:SetPoint(pt[1], UIParent, pt[2], pt[3], pt[4])
	end
	self:LayoutNav()
	self:Select(1)
end

-- Seite sichtbar? (page.feature = eine Funktion, page.features = eine von mehreren)
function UI:PageOn(page)
	-- ohne Gilde: nur die Seiten, die auch allein Sinn ergeben (Übersicht zeigt dann einen Hinweis)
	if not ns.InGuild() then
		if page.noGuild == "always" then return true end
		if not page.noGuild then return false end
	end
	if page.officer and not ns.IsOfficer() then return false end
	if page.features then
		for _, f in ipairs(page.features) do if ns.Feature(f) then return true end end
		return false
	end
	return ns.Feature(page.feature)
end

-- Navigation neu ordnen: ausgeschaltete Seiten verschwinden
function UI:LayoutNav()
	if not self.tabs then return end
	local y = 0
	for i, page in ipairs(self.pages) do
		local on = self:PageOn(page)
		local tab = self.tabs[i]
		tab:SetShown(on)
		tab:ClearAllPoints()
		if on then
			tab:SetPoint("TOPLEFT", 1, -10 - y * 36)
			y = y + 1
		end
	end
	if self.current and not self:PageOn(self.pages[self.current]) then self:Select(1) end
end

function UI:PageIndex(key)
	for i, p in ipairs(self.pages) do
		if p.key == key then return i end
	end
	return 1
end

function UI:Select(i, arg)
	if not self.panels then return end
	-- Seitenaufbau mit Zwischenspeicher für Main/Twink (bei grossen Gilden viel schneller)
	-- Dauer messen: länger als ein Bild -> Eintrag LANGSAM im Diagnose-Protokoll (Diag.lua)
	local key = self.pages[i] and self.pages[i].key or tostring(i)
	local page = self.pages[i]
	local wasBuilt = self.panels[i] and self.panels[i].built
	local t0 = debugprofilestop and debugprofilestop() or 0
	if page then page.lastParts = nil end
	if ns.Timed then ns.Timed("Seite " .. key, ns.Roster.Memo, ns.Roster, self.SelectNow, self, i, arg)
	else ns.Roster:Memo(self.SelectNow, self, i, arg) end
	-- G-4a: bei LANGSAM die Teile dazu (Seite gebaut in diesem Bild? Teile des Füllens)
	local dt = (debugprofilestop and debugprofilestop() or 0) - t0
	self.lastSelect = { key = key, ms = dt, built = not wasBuilt, parts = page and page.lastParts }
	if ns.Diag and dt > (ns.DIAG_SLOW_MS or 16) then
		ns.Diag("LANGSAM", string.format("Seite %s Teile: %s%s", key, (not wasBuilt) and "mit Aufbau der Seite, " or "", page and page.lastParts or "-"), dt)
	end
end

function UI:SelectNow(i, arg)
	for k, panel in ipairs(self.panels) do
		local sel = (k == i)
		local tab = self.tabs[k]
		tab.bg:SetVertexColor(A[1], A[2], A[3], sel and 0.16 or 0)
		tab.bar:SetShown(sel)
		if sel then tab.text:SetTextColor(1, 1, 1) else tab.text:SetTextColor(0.72, 0.74, 0.78) end
		if not sel and panel:IsShown() then
			panel:Hide()
			if self.pages[k].onHide then self.pages[k].onHide(panel) end
		end
	end
	self.current = i
	local panel = self.panels[i]
	self:EnsureBuilt(i)
	panel:Show()
	if self.pages[i].onShow then self.pages[i].onShow(panel, arg) end
	self:RefreshHeader()
end

-- Seite i bauen, falls noch nicht geschehen (GS-N2). Länger als ein Bild -> LANGSAM "Seite bauen <key>" im Protokoll.
function UI:EnsureBuilt(i)
	local panel, page = self.panels and self.panels[i], self.pages[i]
	if not panel or not page or panel.built then return end
	panel.built = true
	if ns.Timed then ns.Timed("Seite bauen " .. tostring(page.key), page.build, panel) else page.build(panel) end
end

-- G-4a (23.11.2026, Diagnose 0.9.58: 7× "LANGSAM Seite members" 17–22 ms bei 9 Mitgliedern): beim ersten Anwählen lief das
-- Bauen der Seite UND das Füllen im selben Bild ("Seite members" enthält "Seite bauen members"). Nach dem Öffnen des Fensters
-- baut der gemeinsame Takt die Seite Mitglieder (unsichtbar) in einem eigenen Bild vor; das erste Anwählen füllt dann nur noch.
-- Wird sie schon vorher angewählt, baut sie wie bisher sofort.
UI.PREBUILD = { "members" }
function UI:Prebuild()
	if self.prebuildJob or not self.panels then return end
	local todo = {}
	for _, key in ipairs(UI.PREBUILD) do
		for i, p in ipairs(self.pages) do
			if p.key == key and self.panels[i] and not self.panels[i].built and self:PageOn(p) then todo[#todo + 1] = i end
		end
	end
	if #todo == 0 then return end
	local T = _G.GoldSentinelTakt
	local function BuildOne(i)
		if self.panels[i].built then return end
		ns.Roster:Memo(function() self:EnsureBuilt(i) end)
		self.panels[i]:Hide()
		self.prebuilt = (self.prebuilt or 0) + 1
	end
	if T and T.Start then
		self.prebuildJob = T.Start({ name = "Seiten vorbauen", owner = "GuildSentinel", timeout = 10,
			fn = function()
				for _, i in ipairs(todo) do
					T.Sleep(0)                                 -- eigenes Bild: nie im Bild des Öffnens
					if self.frame and self.frame:IsShown() then T.NoYield(function() BuildOne(i) end) end
				end
			end,
			onDone = function() self.prebuildJob = nil end })
	else
		C_Timer.After(0, function() for _, i in ipairs(todo) do if self.frame and self.frame:IsShown() then BuildOne(i) end end end)
	end
end

function UI:IsPageShown(key)
	return self.frame and self.frame:IsShown() and self.pages[self.current] and self.pages[self.current].key == key
end

function UI:RefreshHeader()
	if not self.frame then return end
	return ns.Roster:Memo(self.RefreshHeaderNow, self)
end

function UI:RefreshHeaderNow()
	local gname = ns.DisplayGuildName()
	if gname then
		local total, online = ns.Roster:Stats()
		self.guildText:SetText(string.format("|cffffd100<%s>|r  %s", gname, string.format(L["%d Mitglieder, %d online"], total, online)))
	else
		self.guildText:SetText(L["Du bist in keiner Gilde."])
	end
	for i, page in ipairs(self.pages) do
		local b = page.badge and page.badge() or ""
		self.tabs[i].badge:SetText(b)
	end
	local s = ns.Sync and ns.Sync.lastSync or 0
	local users = ns.Count(ns.Comm.users)
	self.syncText:SetText(string.format(L["%d mit GuildSentinel online"], users) .. "\n" .. (s > 0 and L["Abgleich läuft automatisch"] or ""))
end

function UI:Toggle()
	if not self.frame then self:Build() end
	self.frame:SetShown(not self.frame:IsShown())
end

function UI:Open(key, arg)
	if not self.frame then self:Build() end
	local page = self.pages[self:PageIndex(key)]
	if page and not self:PageOn(page) then
		if not ns.InGuild() then
			ns:Print(L["Diese Seite gibt es nur, wenn du in einer Gilde bist."])
			key = "home"
		else
			ns:Print(L["Diese Funktion ist ausgeschaltet (Einstellungen > Funktionen)."])
			-- OPT-ALLE: gleich im Bereich dieser Funktion öffnen
			key, arg = "settings", page.feature and ("feat:" .. page.feature) or "feat"
		end
	end
	self.frame:Show()
	self:Select(self:PageIndex(key), arg)
end

ns:Listen("GS_ROSTER", function() UI:RefreshHeader(); UI:LayoutNav() end)
-- Gilde beigetreten oder verlassen: Navigation neu, ausgeblendete Seite verlassen
ns:On("PLAYER_GUILD_UPDATE", function()
	C_Timer.After(1.5, function()
		if not UI.frame then return end
		UI:RefreshHeader()
		UI:LayoutNav()
		local cur = UI.current and UI.pages[UI.current]
		if UI.frame:IsShown() and cur and not UI:PageOn(cur) then UI:Select(UI:PageIndex("home")) end
	end)
end)
ns:Listen("GS_FEATURES", function()
	for _, bar in ipairs(UI.tabBars or {}) do bar:Layout() end
	UI:LayoutNav()
	if UI.frame and UI.frame:IsShown() and UI.current then UI:Select(UI.current) end
end)
ns:Listen("GS_USERS", function() UI:RefreshHeader() end)
ns:Listen("GS_APPS", function() UI:RefreshHeader() end)
ns:Listen("GS_RECRUIT", function() UI:RefreshHeader(); UI:UpdateMinimapGlow() end)

------------------------------------------------------------
-- Minimap-Knopf
------------------------------------------------------------
function UI:CreateMinimap()
	local b = CreateFrame("Button", "GuildSentinelMinimapButton", Minimap)
	b:SetSize(31, 31)
	b:SetFrameStrata("MEDIUM")
	b:SetFrameLevel(8)
	b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
	local bg = b:CreateTexture(nil, "BACKGROUND")
	bg:SetSize(20, 20)
	bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
	bg:SetPoint("TOPLEFT", 7, -5)
	local icon = b:CreateTexture(nil, "ARTWORK")
	icon:SetSize(17, 17)
	icon:SetTexture(ns.ICON)
	icon:SetPoint("TOPLEFT", 7, -6)
	local border = b:CreateTexture(nil, "OVERLAY")
	border:SetSize(53, 53)
	border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
	border:SetPoint("TOPLEFT")
	b.glow = b:CreateTexture(nil, "OVERLAY", nil, 2)
	b.glow:SetSize(34, 34)
	b.glow:SetPoint("CENTER", 0, 0)
	b.glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
	b.glow:SetBlendMode("ADD")
	b.glow:SetVertexColor(A[1], A[2], A[3], 1)
	b.glow:Hide()

	b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	b:RegisterForDrag("LeftButton")
	b:SetScript("OnClick", function(_, mb)
		if mb == "RightButton" then
			ns.Recruit:Post()
		else
			UI:Toggle()
		end
	end)
	b:SetScript("OnDragStart", function(s)
		s:SetScript("OnUpdate", function()
			local mx, my = Minimap:GetCenter()
			local cx, cy = GetCursorPosition()
			local sc = Minimap:GetEffectiveScale()
			ns.db.minimapAngle = math.deg(math.atan2(cy / sc - my, cx / sc - mx))
			UI:PlaceMinimap()
		end)
	end)
	b:SetScript("OnDragStop", function(s) s:SetScript("OnUpdate", nil) end)
	b:SetScript("OnEnter", function(s)
		ns.UI.TipOwner(s, "ANCHOR_LEFT")
		GameTooltip:AddLine(ns.TITLE)
		if IsInGuild() then
			local total, online = ns.Roster:Stats()
			GameTooltip:AddLine(string.format(L["%d Mitglieder, %d online"], total, online), 0.8, 0.8, 0.8)
			local apps = #ns.Recruit:Applicants()
			if apps > 0 then GameTooltip:AddLine(string.format(L["%d offene Bewerbungen"], apps), A[1], A[2], A[3]) end
			if ns.Recruit:Due() then GameTooltip:AddLine(L["Gildenwerbung ist wieder fällig"], 1, 0.82, 0) end
		end
		GameTooltip:AddLine(" ")
		GameTooltip:AddLine(L["Linksklick: Fenster öffnen"], 1, 1, 1)
		GameTooltip:AddLine(L["Rechtsklick: Gildenwerbung posten"], 1, 1, 1)
		GameTooltip:AddLine(L["Ziehen: Knopf verschieben"], 0.7, 0.7, 0.7)
		GameTooltip:Show()
	end)
	b:SetScript("OnLeave", function() GameTooltip:Hide() end)
	self.minimap = b
	self:UpdateMinimap()
end

function UI:PlaceMinimap()
	local b = self.minimap
	if not b then return end
	local a = math.rad(ns.db.minimapAngle or 200)
	local r = (Minimap:GetWidth() / 2) + 10
	b:ClearAllPoints()
	b:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
end

function UI:UpdateMinimap()
	if not self.minimap then return end
	self.minimap:SetShown(ns.db.minimapShow)
	self:PlaceMinimap()
	self:UpdateMinimapGlow()
end

function UI:UpdateMinimapGlow()
	if not self.minimap then return end
	local due = ns.Recruit:Due() or #ns.Recruit:Applicants() > 0
	self.minimap.glow:SetShown(due and true or false)
end
ns:Listen("GS_APPS", function() UI:UpdateMinimapGlow() end)

function UI:Login()
	self:CreateMinimap()
end
