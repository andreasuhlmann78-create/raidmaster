-- GuildSentinel - Pages.lua
-- Die Seiten im Fenster: Mitglieder, Rekrutierung, Berufe, Einstellungen.

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local UI = ns.UI
local A = ns.ACCENT

local GREEN, GRAY, GOLD, ORANGE = "|cff40d860", "|cff8a8f99", "|cffffd100", "|cffff9933"

local function Gray(t) return GRAY .. tostring(t) .. "|r" end
-- Spaltentitel der Stufenbereiche (Classic 1–29 … 60, TBC 1–39 … 70)
local function BandTitle(i)
	local b = ns.Game.BANDS[i]
	if not b then return "" end
	return b.min == b.max and tostring(b.min) or (b.min .. "–" .. b.max)
end

-- Seite neu zeichnen, wenn sie sichtbar ist
local function WhenShown(key, fn)
	return function(...)
		if UI:IsPageShown(key) then fn(...) end
	end
end

------------------------------------------------------------
-- Seite: Mitglieder
------------------------------------------------------------
local M = { key = "members", order = 10, icon = "Interface\\Icons\\Spell_Holy_PrayerOfFortitude" }
M.title = N["Mitglieder"]
M.filter = { text = "", online = false, alts = true, sort = "seen", desc = true }
M.view = "list"
M.inactiveDays = 30

local LOG_TEXT = {
	join = { GREEN, N["beigetreten"] },
	leave = { ORANGE, N["hat die Gilde verlassen"] },
	kick = { "|cffff5555", N["wurde entfernt"] },
	promote = { "|cff66b3ff", N["befördert"] },
	demote = { ORANGE, N["degradiert"] },
	maxlevel = { GOLD, N["hat die Maximalstufe erreicht"] },
	rules = { "|cff66b3ff", N["hat die Gildenregeln bestätigt"] },
	["return"] = { GREEN, N["ist nach langer Pause zurück"] },
	pnote = { "|cffaaaaaa", N["öffentliche Notiz geändert"] },
	onote = { "|cffaaaaaa", N["Offiziersnotiz geändert"] },
}

function M.build(p)
	M.panel = p
	M.tabs = UI:Tabs(p, {
		{ key = "list", text = L["Liste"] },
		{ key = "where", text = L["Wer ist wo"], feature = "where" },
		{ key = "log", text = L["Verlauf"] },
		{ key = "inactive", text = L["Inaktiv"] },
		{ key = "online", text = L["Online-Zeiten"], feature = "times" },
		{ key = "promo", text = L["Beförderung"], feature = "promo" },
		{ key = "comp", text = L["Aufstellung"], feature = "comp" },
		{ key = "export", text = L["Export"] },
	}, function(key) M.view = key; M:Refresh() end)
	M.tabs:SetPoint("TOPLEFT")
	M.tabs:SetPoint("TOPRIGHT")

	-- Liste ------------------------------------------------
	local v = CreateFrame("Frame", nil, p)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	M.listView = v

	local search = UI:Edit(v, 200, 24, L["Suchen (Name, Notiz, Zone)"])
	search:SetPoint("TOPLEFT")
	search.onChange = function(t) M.filter.text = t; M:Refresh() end

	local classDD = UI:Dropdown(v, 130, function()
		local items = { { value = false, text = L["Alle Klassen"] } }
		for _, c in ipairs(ns.Roster:Classes()) do items[#items + 1] = { value = c, text = ns.Colored(ns.ClassName(c), c) } end
		return items
	end, function() return M.filter.class or false end, function(val) M.filter.class = val or nil; M:Refresh() end)
	classDD:SetPoint("LEFT", search, "RIGHT", 8, 0)

	local rankDD = UI:Dropdown(v, 140, function()
		local items = { { value = false, text = L["Alle Ränge"] } }
		for _, r in ipairs(ns.Roster:Ranks()) do items[#items + 1] = { value = r.ri, text = r.name } end
		return items
	end, function() if M.filter.ri == nil then return false end return M.filter.ri end, function(val)
		if val == false then M.filter.ri = nil else M.filter.ri = val end
		M:Refresh()
	end)
	rankDD:SetPoint("LEFT", classDD, "RIGHT", 8, 0)

	local onl = UI:Check(v, L["Nur online"], function() return M.filter.online end, function(val) M.filter.online = val; M:Refresh() end)
	onl:SetPoint("LEFT", rankDD, "RIGHT", 12, 0)
	local alts = UI:Check(v, L["Twinks zeigen"], function() return M.filter.alts end, function(val) M.filter.alts = val; M:Refresh() end)
	alts:SetPoint("LEFT", onl, "RIGHT", 90, 0)

	-- Zähler in eigener Zeile unter den Filtern (sonst überlappt er die Kästchen)
	M.stats = UI:Label(v, "", "GameFontHighlightSmall")
	M.stats:SetPoint("TOPLEFT", 2, -30)
	M.stats:SetJustifyH("LEFT")

	M.list = UI:List(v, {
		{ key = "name", title = L["Name"], width = 190, sort = "name" },
		{ key = "level", title = L["Stufe"], width = 40, align = "CENTER", sort = "level" },
		{ key = "class", title = L["Klasse"], width = 90, sort = "class" },
		{ key = "rank", title = L["Rang"], width = 110, sort = "rank" },
		{ key = "seen", title = L["Online / Zone"], width = 150, sort = "seen" },
		{ key = "note", title = L["Notiz"] },
	}, {
		key = function(e) return e.name end,
		render = function(e)
			local main = ns.Roster:MainOf(e.name)
			local name = ns.Colored(e.name, e.class)
			if main then name = "  " .. name .. " " .. Gray("(" .. main .. ")") end
			if M.multi[e.name] then name = "|TInterface\\Buttons\\UI-CheckBox-Check:14|t" .. name end
			local seen = e.online and (GREEN .. (e.zone or L["online"]) .. "|r") or Gray(ns.Ago(e.seen))
			local away = ns.Social:IsAway(e.name)
			if away then seen = seen .. " " .. ORANGE .. string.format(L["(weg bis %s)"], date(L["%d.%m."], away.u)) .. "|r" end
			local note = e.note or ""
			local own = ns.G().notes[e.name]
			if own and own ~= "" then note = (note ~= "" and (note .. "  ") or "") .. GOLD .. own .. "|r" end
			return { name, tostring(e.level), ns.ClassName(e.class), e.rank or "", seen, note }
		end,
		onClick = function(e, button)
			-- Shift/Strg-Klick: Mehrfachauswahl (RV8); normaler Klick hebt sie auf
			if button ~= "RightButton" then
				if (IsShiftKeyDown and IsShiftKeyDown()) or (IsControlKeyDown and IsControlKeyDown()) then
					M.multi[e.name] = not M.multi[e.name] or nil
					M.list:Draw()
				elseif next(M.multi) then
					wipe(M.multi)
					M.list:Draw()
				end
			end
			M:ShowDetail(e)
			if button == "RightButton" then M:Menu(e) end
		end,
		onEnter = function(row, e)
			ns.UI.TipOwner(row, "ANCHOR_CURSOR")
			GameTooltip:AddLine(ns.Colored(e.name, e.class))
			GameTooltip:AddLine(string.format("%s %d %s", L["Stufe"], e.level, ns.ClassName(e.class)), 1, 1, 1)
			if e.onote and e.onote ~= "" then GameTooltip:AddLine(L["Offiziersnotiz: "] .. e.onote, 0.8, 0.8, 0.8, true) end
			local alts = ns.Roster:AltsOf(e.name)
			if #alts > 0 then GameTooltip:AddLine(L["Twinks: "] .. table.concat(alts, ", "), 0.8, 0.8, 0.8, true) end
			local pr = ns.Prof:Of(e.name)
			if pr then
				for prof, x in pairs(pr.p or {}) do GameTooltip:AddDoubleLine(prof, tostring(x.r or "?"), 0.8, 0.8, 0.8, 1, 1, 1) end
			end
			GameTooltip:AddLine(L["Rechtsklick: Aktionen"], 0.5, 0.5, 0.5)
			GameTooltip:Show()
		end,
		onSort = function(key)
			if M.filter.sort == key then M.filter.desc = not M.filter.desc else M.filter.sort, M.filter.desc = key, (key == "level" or key == "seen") end
			M:Refresh()
		end,
		empty = L["Noch keine Gildendaten – kurz warten oder die Gildenliste (J) einmal öffnen."],
	})
	M.list:SetPoint("TOPLEFT", 0, -46)
	M.list:SetPoint("BOTTOMRIGHT", 0, 158)

	-- Details unten
	local d = CreateFrame("Frame", nil, v, UI.BACKDROP)
	d:SetPoint("BOTTOMLEFT")
	d:SetPoint("BOTTOMRIGHT")
	d:SetHeight(150)
	UI.Box(d, 0.07, 0.08, 0.11, 1, 0.18, 0.2, 0.25, 1)
	M.detail = d
	d.title = UI:Label(d, "", "GameFontNormalLarge")
	d.title:SetPoint("TOPLEFT", 12, -10)
	d.info = UI:Label(d, "", "GameFontHighlightSmall")
	d.info:SetPoint("TOPLEFT", d.title, "BOTTOMLEFT", 0, -6)
	d.info:SetWidth(440)
	d.info:SetJustifyV("TOP")
	d.note = UI:Edit(d, 300, 24, L["Eigene Notiz (nur für dich)"])
	d.note:SetPoint("BOTTOMLEFT", 12, 10)
	d.note.onCommit = function(t)
		if not M.selected or not ns.guild then return end
		t = ns.Trim(t)
		ns.guild.notes[M.selected] = (t ~= "") and t or nil
		M.list:Draw()
	end
	d.note.onEnter = d.note.onCommit

	local bx = -10
	local function Btn(text, fn)
		local b = UI:Button(d, text, 130, 24, fn)
		b:SetPoint("TOPRIGHT", bx, -10)
		return b
	end
	d.whisper = Btn(L["Anflüstern"], function() if M.selected then ns.Recruit:Whisper(M.selected) end end)
	bx = -146
	d.invite = Btn(L["In Gruppe einladen"], function()
		if M.selected then ns.InviteParty(M.selected) end
	end)
	bx = -10
	d.setMain = UI:Button(d, L["Twink von …"], 130, 24, function()
		if not M.selected then return end
		local name = M.selected
		UI:Ask(string.format(L["Wessen Twink ist %s? (Name des Mains)"], name), ns.Roster:MainOf(name) or "", function(main)
			main = ns.Trim(main)
			if main == "" then return end
			ns.Roster:SetMain(name, main)
		end)
	end)
	d.setMain:SetPoint("TOPRIGHT", -10, -40)
	d.isMain = UI:Button(d, L["Ist ein Main"], 130, 24, function()
		if M.selected then ns.Roster:SetMain(M.selected, "") end
	end)
	d.isMain:SetPoint("TOPRIGHT", -146, -40)
	UI.Tip(d.setMain, L["Twink festlegen"], L["Gilt für alle in der Gilde mit GuildSentinel. Steht in der Notiz 'Twink von Name', erkennt GuildSentinel das auch selbst."])
	d.thank = UI:Button(d, L["Danke sagen"], 130, 24, function()
		if not M.selected then return end
		local name = M.selected
		UI:Ask(string.format(L["Wofür dankst du %s? (optional)"], name), "", function(why) ns.Social:Thank(name, why) end)
	end)
	d.thank:SetPoint("TOPRIGHT", -10, -70)
	d.away = UI:Button(d, L["Abwesend …"], 130, 24, function()
		if not M.selected then return end
		local name = M.selected
		UI:Ask(string.format(L["Wie viele Tage ist %s weg? (0 = wieder da)"], name), "14", function(t)
			local days = tonumber(ns.Trim(t):match("^(%d+)"))
			if days then ns.Social:SetAway(name, days, "") else ns:Print(L["Bitte eine Zahl eingeben (Tage, 0 = wieder da)."]) end
		end)
	end)
	d.away:SetPoint("TOPRIGHT", -146, -70)
	d.mentor = UI:Button(d, L["Pate …"], 130, 24, function()
		if not M.selected then return end
		local name = M.selected
		UI:Ask(string.format(L["Wer wird Pate von %s? (leer = keiner)"], name), ns.Social:MentorOf(name) or ns.Me(), function(m) ns.Social:SetMentor(name, m) end)
	end)
	d.mentor:SetPoint("TOPRIGHT", -10, -100)
	d.writeNote = UI:Button(d, L["In Gildennotiz"], 130, 24, function()
		if M.selected and ns.Social:WriteNote(M.selected) then
			ns:Print(L["Gildennotiz eingetragen."])
			M:ShowDetail(ns.Roster.byName[M.selected])
		end
	end)
	d.writeNote:SetPoint("TOPRIGHT", -146, -100)
	UI.Tip(d.writeNote, L["In Gildennotiz"], L["Schreibt 'Twink von …' in die öffentliche Gildennotiz – dann sehen es auch alle ohne GuildSentinel."])
	M:ShowDetail(nil)

	-- Verlauf ---------------------------------------------
	M.logList = UI:List(p, {
		{ key = "t", title = L["Zeit"], width = 110 },
		{ key = "n", title = L["Name"], width = 160 },
		{ key = "k", title = L["Ereignis"], width = 220 },
		{ key = "x", title = L["Details"] },
	}, {
		render = function(e)
			local info = LOG_TEXT[e.k] or { "", e.k }
			local r = ns.G().roster[e.n]
			local x = e.x
			if e.k == "kick" and x then x = L["von "] .. x end
			if e.k == "maxlevel" and x then x = L["Stufe "] .. x end
			if e.k == "return" and x then x = string.format(L["nach %d Tagen"], tonumber(x) or 0) end
			return { ns.Date(e.t), ns.Colored(e.n or "?", r and r.c), info[1] .. L[info[2]] .. "|r", x and tostring(x) or "" }
		end,
		empty = L["Noch keine Ereignisse. GuildSentinel merkt sich ab jetzt, wer kommt und geht."],
	})
	M.logList:SetPoint("TOPLEFT", 0, -34)
	M.logList:SetPoint("BOTTOMRIGHT")

	-- Inaktiv ---------------------------------------------
	local iv = CreateFrame("Frame", nil, p)
	iv:SetPoint("TOPLEFT", 0, -34)
	iv:SetPoint("BOTTOMRIGHT")
	M.inactiveView = iv
	local lbl = UI:Label(iv, L["Nicht online seit mindestens"])
	lbl:SetPoint("TOPLEFT", 0, -5)
	local dd = UI:Dropdown(iv, 120, function()
		return {
			{ value = 14, text = L["14 Tagen"] }, { value = 30, text = L["30 Tagen"] },
			{ value = 60, text = L["60 Tagen"] }, { value = 90, text = L["90 Tagen"] },
		}
	end, function() return M.inactiveDays end, function(val) M.inactiveDays = val; M:Refresh() end)
	dd:SetPoint("LEFT", lbl, "RIGHT", 8, 0)
	local hint = UI:Label(iv, L["Zählt nur, wenn auch kein Twink des Spielers online war."], "GameFontDisableSmall")
	hint:SetPoint("LEFT", dd, "RIGHT", 12, 0)
	M.inactiveList = UI:List(iv, {
		{ key = "name", title = L["Name"], width = 160 },
		{ key = "level", title = L["Stufe"], width = 40, align = "CENTER" },
		{ key = "rank", title = L["Rang"], width = 120 },
		{ key = "seen", title = L["Zuletzt online"], width = 130 },
		{ key = "note", title = L["Notiz"] },
	}, {
		key = function(e) return e.name end,
		render = function(e)
			return { ns.Colored(e.name, e.class), tostring(e.level), e.rank or "", Gray(ns.Ago(e.seen)), e.note or "" }
		end,
		onClick = function(e, button) if button == "RightButton" then M:Menu(e) end end,
		empty = L["Niemand – alle waren in letzter Zeit online."],
	})
	M.inactiveList:SetPoint("TOPLEFT", 0, -32)
	M.inactiveList:SetPoint("BOTTOMRIGHT")

	M:BuildOnline(p)
	M:BuildPromo(p)
	M:BuildComp(p)
	M:BuildWhere(p)
	M:BuildExport(p)
	M.tabs:Select("list")
end

-- Online-Zeiten: Wochentag x Stunde
function M:BuildOnline(p)
	local v = CreateFrame("Frame", nil, p)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	self.onlineView = v
	local h = UI:Header(v, L["Wann sind die meisten online?"])
	h:SetPoint("TOPLEFT", 0, -2)
	self.onlineInfo = UI:Label(v, "", "GameFontHighlightSmall")
	self.onlineInfo:SetPoint("TOPRIGHT", 0, -4)
	self.onlineInfo:SetJustifyH("RIGHT")
	local CELL, GAP, LEFT, TOP = 29, 1, 34, -46
	self.cells = {}
	for hr = 0, 23 do
		if hr % 3 == 0 then
			local lab = UI:Label(v, string.format("%02d", hr), "GameFontDisableSmall")
			lab:SetPoint("BOTTOMLEFT", v, "TOPLEFT", LEFT + hr * (CELL + GAP) + 2, TOP + 2)
		end
	end
	for d = 1, 7 do
		local lab = UI:Label(v, ns.Activity.WEEKDAYS[d], "GameFontHighlightSmall")
		lab:SetPoint("TOPLEFT", 0, TOP - (d - 1) * (CELL + GAP) - 8)
		self.cells[d] = {}
		for hr = 0, 23 do
			local c = CreateFrame("Frame", nil, v)
			c:SetSize(CELL, CELL)
			c:SetPoint("TOPLEFT", LEFT + hr * (CELL + GAP), TOP - (d - 1) * (CELL + GAP))
			c.tex = c:CreateTexture(nil, "ARTWORK")
			c.tex:SetAllPoints()
			c.tex:SetTexture(UI.WHITE)
			c.num = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
			c.num:SetPoint("CENTER")
			c:EnableMouse(true)
			c:SetScript("OnEnter", function(self)
				if not self.data then return end
				ns.UI.TipOwner(self, "ANCHOR_TOP")
				GameTooltip:AddLine(string.format(L["%s %02d–%02d Uhr"], ns.Activity.WEEKDAYS[d], hr, (hr + 1) % 24), 1, 1, 1)
				if self.data.n > 0 then
					GameTooltip:AddLine(string.format(L["Ø %.1f Spieler online (%d Messungen)"], self.data.avg, self.data.n), 0.8, 0.8, 0.8)
				else
					GameTooltip:AddLine(L["noch keine Messung"], 0.6, 0.6, 0.6)
				end
				GameTooltip:Show()
			end)
			c:SetScript("OnLeave", function() GameTooltip:Hide() end)
			self.cells[d][hr] = c
		end
	end
	self.onlineBest = UI:Label(v, "", "GameFontHighlight")
	self.onlineBest:SetPoint("TOPLEFT", 0, TOP - 7 * (CELL + GAP) - 14)
	self.onlineBest:SetWidth(760)
	self.onlineHint = UI:Label(v, Gray(L["GuildSentinel zählt alle 5 Minuten, wie viele Spieler online sind (Twinks zählen nicht extra). Die Messungen aller in der Gilde mit dem Addon werden zusammengelegt."]), "GameFontHighlightSmall")
	self.onlineHint:SetPoint("TOPLEFT", self.onlineBest, "BOTTOMLEFT", 0, -10)
	self.onlineHint:SetWidth(760)
end

function M:RefreshOnline()
	local grid, max = ns.Activity:Grid()
	for d = 1, 7 do
		for hr = 0, 23 do
			local c, data = self.cells[d][hr], grid[d][hr]
			c.data = data
			if data.n == 0 then
				c.tex:SetVertexColor(0.1, 0.11, 0.14, 1)
				c.num:SetText("")
			else
				local f = max > 0 and (data.avg / max) or 0
				c.tex:SetVertexColor(0.1 + A[1] * 0.85 * f, 0.12 + A[2] * 0.8 * f, 0.14 + A[3] * 0.6 * f, 1)
				c.num:SetText(string.format("%d", math.floor(data.avg + 0.5)))
			end
		end
	end
	local best = ns.Activity:Best(3)
	if #best == 0 then
		self.onlineBest:SetText(Gray(L["Noch zu wenig Messungen – die Übersicht füllt sich in den nächsten Tagen."]))
	else
		local t = {}
		for _, b in ipairs(best) do t[#t + 1] = string.format(L["%s %02d Uhr (Ø %.1f)"], ns.Activity.WEEKDAYS[b.wd], b.h, b.avg) end
		self.onlineBest:SetText(L["Beste Zeiten: "] .. GREEN .. table.concat(t, ", ") .. "|r")
	end
	self.onlineInfo:SetText(string.format(L["%d Messungen · jetzt %d online"], ns.Activity:Measurements(), ns.Activity:OnlinePlayers()))
end

-- Beförderung: Regeln je Rang und Vorschläge
function M:BuildPromo(p)
	local v = CreateFrame("Frame", nil, p)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	self.promoView = v
	local h = UI:Header(v, L["Regeln je Rang"])
	h:SetPoint("TOPLEFT", 0, -2)
	local hint = UI:Label(v, Gray(L["Vorschlag, sobald alles erfüllt ist. Online-Tage: an wie vielen der letzten 14 Tage der Spieler (oder einer seiner Twinks) online war."]), "GameFontHighlightSmall")
	hint:SetPoint("LEFT", h, "RIGHT", 12, 0)
	hint:SetPoint("RIGHT", v, "RIGHT", 0, 0)
	self.promoRows = {}
	self.promoHolder = CreateFrame("Frame", nil, v)
	self.promoHolder:SetPoint("TOPLEFT", 0, -24)
	self.promoHolder:SetPoint("RIGHT")
	self.promoHolder:SetHeight(26 * 6)
	self.promoNone = UI:Label(self.promoHolder, "", "GameFontHighlightSmall")
	self.promoNone:SetPoint("TOPLEFT", 0, -6)
	self.promoList = UI:List(v, {
		{ key = "name", title = L["Vorschlag"], width = 170 },
		{ key = "level", title = L["Stufe"], width = 40, align = "CENTER" },
		{ key = "rank", title = L["Befördern"], width = 220 },
		{ key = "days", title = L["In der Gilde"], width = 90 },
		{ key = "active", title = L["Online-Tage"] },
	}, {
		key = function(x) return x.name end,
		render = function(x)
			return { ns.Colored(x.name, x.class), tostring(x.level), x.rank .. " > " .. GREEN .. x.to .. "|r",
				string.format(L["%d Tage"], x.days), string.format(L["%d von 14"], x.active) }
		end,
		onClick = function() M.promoBtn:SetEnabled(M.promoList:Selected() ~= nil and ns.CanPromote()) end,
		empty = L["Gerade niemand – oder es ist noch keine Regel eingeschaltet."],
	})
	self.promoList:SetPoint("TOPLEFT", 0, -24 - 26 * 6 - 12)
	self.promoList:SetPoint("BOTTOMRIGHT", 0, 50)
	self.promoBtn = UI:Button(v, L["Befördern"], 150, 28, function()
		local x = M.promoList:Selected()
		if x then
			UI:Confirm(string.format(L["%s zum Rang %s befördern?"], x.name, x.to), function() ns.Promote:Apply(x) end)
		end
	end, true)
	self.promoBtn:SetPoint("BOTTOMRIGHT", 0, 4)
	self.promoAlt = UI:Check(v, L["Twinks bekommen den Rang ihres Mains vorgeschlagen"], function() return ns.db.altRank and true or false end,
		function(val) ns.db.altRank = val and true or nil; ns:Fire("GS_PROMO") end)
	self.promoAlt:SetPoint("BOTTOMLEFT", 0, 22)
	self.promoInfo = UI:Label(v, "", "GameFontHighlightSmall")
	self.promoInfo:SetPoint("BOTTOMLEFT", 0, 4)
	self.promoInfo:SetPoint("RIGHT", self.promoBtn, "LEFT", -12, 0)
end

function M:PromoRow(i)
	local row = self.promoRows[i]
	if row then return row end
	local hld = self.promoHolder
	row = CreateFrame("Frame", nil, hld)
	row:SetHeight(26)
	row:SetPoint("TOPLEFT", 0, -(i - 1) * 26)
	row:SetPoint("RIGHT")
	row.on = UI:Check(row, "", function() return row.ri and ns.Promote:Rule(row.ri).on end, function(val) if row.ri then ns.Promote:SetRule(row.ri, "on", val) end end)
	row.on:SetPoint("LEFT", 0, 0)
	row.label = UI:Label(row, "", "GameFontHighlight")
	row.label:SetPoint("LEFT", row.on, "RIGHT", 4, 0)
	row.label:SetWidth(230)
	local function Num(x, field, text)
		local lab = UI:Label(row, text, "GameFontHighlightSmall")
		lab:SetPoint("LEFT", x, 0)
		local e = UI:Edit(row, 44, 22, "0")
		e:SetPoint("LEFT", lab, "RIGHT", 6, 0)
		e.edit:SetNumeric(true)
		e.edit:SetMaxLetters(3)
		e.onCommit = function(t) if row.ri then ns.Promote:SetRule(row.ri, field, tonumber(t) or 0) end end
		e.onEnter = e.onCommit
		return e
	end
	row.days = Num(270, "days", L["ab Tagen in der Gilde"])
	row.level = Num(450, "level", L["ab Stufe"])
	row.active = Num(560, "active", L["Online-Tage (von 14)"])
	self.promoRows[i] = row
	return row
end

function M:RefreshPromo()
	local ranks = ns.Promote:Ranks()
	for i, r in ipairs(ranks) do
		if i > 6 then break end
		local row = self:PromoRow(i)
		row.ri = r.ri
		local rule = ns.Promote:Rule(r.ri)
		row.label:SetText(r.name .. " > " .. r.to)
		for _, f in ipairs({ "days", "level", "active" }) do
			if not row[f].edit:HasFocus() then row[f]:SetText(tostring(rule[f] or 0)) end
		end
		row.on.Refresh()
		row:Show()
	end
	for i = #ranks + 1, #self.promoRows do self.promoRows[i]:Hide() end
	self.promoNone:SetText(#ranks == 0 and Gray(L["Mit deinem Rang kannst du niemanden befördern."]) or "")
	self.promoList:SetData(ns.Promote:Candidates())
	self.promoBtn:SetEnabled(self.promoList:Selected() ~= nil and ns.CanPromote())
	self.promoInfo:SetText(Gray(L["Die Regeln gelten nur bei dir. Befördert wird immer von Hand, Schritt für Schritt."]))
end

-- Aufstellung: Klassen und Rollen je Stufenbereich, Raid-Ziel, was fehlt
function M:BuildComp(p)
	local v = CreateFrame("Frame", nil, p)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	self.compView = v
	local lab = UI:Label(v, L["Für den Raid zählen ab Stufe"], "GameFontHighlight")
	lab:SetPoint("TOPLEFT", 0, -5)
	local dd = UI:Dropdown(v, 70, function()
		local out = {}
		for _, l in ipairs(ns.Game.PROMOTE_LEVELS) do out[#out + 1] = { value = l, text = tostring(l) } end
		return out
	end, function() return ns.Comp:Settings().min end, function(val) ns.Comp:SetSetting("min", val); M:Refresh() end)
	dd:SetPoint("LEFT", lab, "RIGHT", 8, 0)
	local alts = UI:Check(v, L["Twinks mitzählen"], function() return ns.Comp:Settings().alts end, function(val) ns.Comp:SetSetting("alts", val and true or false); M:Refresh() end)
	alts:SetPoint("LEFT", dd, "RIGHT", 14, 0)
	self.compList = UI:List(v, {
		{ key = "label", title = L["Klasse / Rolle"], width = 150 },
		{ key = "b1", title = BandTitle(1), width = 56, align = "CENTER" },
		{ key = "b2", title = BandTitle(2), width = 56, align = "CENTER" },
		{ key = "b3", title = BandTitle(3), width = 56, align = "CENTER" },
		{ key = "b4", title = BandTitle(4), width = 56, align = "CENTER" },
		{ key = "raid", title = L["Für den Raid"], width = 90, align = "CENTER" },
		{ key = "want", title = L["Raid-Ziel"], width = 80, align = "CENTER" },
		{ key = "miss", title = L["Fehlt"] },
	}, {
		key = function(r) return r.key end,
		render = function(r)
			local label = r.role and (GOLD .. r.label .. "|r") or ns.Colored(r.label, r.key)
			local raid = tostring(r.raid)
			if r.role and r.guessed > 0 then raid = raid .. Gray(string.format(L[" (%d geschätzt)"], r.guessed)) end
			local miss = ""
			if r.want then miss = r.missing > 0 and (ORANGE .. string.format(L["%d fehlen"], r.missing) .. "|r") or (GREEN .. L["genug"] .. "|r") end
			return { label, tostring(r.bands[1]), tostring(r.bands[2]), tostring(r.bands[3]), tostring(r.bands[4]), raid,
				r.want and tostring(r.want) or Gray("–"), miss }
		end,
		onClick = function(r, button)
			if not r.want then return end
			UI:Ask(string.format(L["Raid-Ziel für %s (0–40):"], r.label), tostring(r.want), function(t) ns.Comp:SetWant(r.key, t) end)
		end,
		onEnter = function(row, r)
			ns.UI.TipOwner(row, "ANCHOR_CURSOR")
			GameTooltip:AddLine(r.label, 1, 1, 1)
			if r.want then GameTooltip:AddLine(L["Klicken: Raid-Ziel ändern"], 0.7, 0.7, 0.7) end
			if r.role then GameTooltip:AddLine(L["Rolle: selbst gewählt (GuildSentinel), aus der Skillung (RaidMaster) oder geschätzt nach Klasse. Tanks werden nie geschätzt."], 0.7, 0.7, 0.7, true) end
			GameTooltip:Show()
		end,
		empty = L["Noch keine Gildendaten."],
	})
	self.compList:SetPoint("TOPLEFT", 0, -32)
	self.compList:SetPoint("RIGHT")
	self.compList:SetHeight(12 * 20 + 26)
	self.compWanted = UI:Label(v, "", "GameFontHighlight")
	self.compWanted:SetPoint("TOPLEFT", self.compList, "BOTTOMLEFT", 0, -12)
	self.compWanted:SetWidth(780)
	self.compHint = UI:Label(v, Gray(L["Der Platzhalter {gesucht} im Werbetext wird zu den drei größten Lücken. {berufe} nennt Berufe, in denen wichtige Rezepte fehlen (Seite Berufe > Lücken)."]), "GameFontHighlightSmall")
	self.compHint:SetPoint("TOPLEFT", self.compWanted, "BOTTOMLEFT", 0, -8)
	self.compHint:SetWidth(780)

	-- Rekrutierung in Phasen (RP): Phase und Ziel-Raid (ändern nur GM/Offiziere), Fortschritt, Vorschlag
	local RPx = ns.RaidReady
	local pl = UI:Label(v, L["Rekrutierungsphase:"], "GameFontNormal")
	pl:SetPoint("TOPLEFT", self.compHint, "BOTTOMLEFT", 0, -14)
	self.rpPhase = UI:Dropdown(v, 130, function()
		return { { value = "build", text = RPx.PhaseName("build") }, { value = "trans", text = RPx.PhaseName("trans") }, { value = "raid", text = RPx.PhaseName("raid") } }
	end, function() return RPx:Phase() end, function(val) RPx:Set(val); M:Refresh() end)
	self.rpPhase:SetPoint("LEFT", pl, "RIGHT", 8, 0)
	local rl = UI:Label(v, L["Ziel-Raid:"], "GameFontNormal")
	rl:SetPoint("LEFT", self.rpPhase, "RIGHT", 16, 0)
	self.rpRaid = UI:Dropdown(v, 200, function()
		local out = {}
		for _, r in ipairs(RPx.RAIDS) do out[#out + 1] = { value = r.key, text = L[r.n] .. " (" .. r.size .. ")" } end
		return out
	end, function() return RPx:State().raid end, function(val) RPx:Set(nil, val); M:Refresh() end)
	self.rpRaid:SetPoint("LEFT", rl, "RIGHT", 8, 0)
	self.rpProgress = UI:Label(v, "", "GameFontHighlight")
	self.rpProgress:SetPoint("TOPLEFT", pl, "BOTTOMLEFT", 0, -12)
	self.rpProgress:SetWidth(780)
	self.rpProgress:SetJustifyH("LEFT")
	self.rpSuggest = UI:Label(v, "", "GameFontHighlight")
	self.rpSuggest:SetPoint("TOPLEFT", self.rpProgress, "BOTTOMLEFT", 0, -10)
	self.rpOk = UI:Button(v, L["Bestätigen"], 110, 22, function() RPx:Confirm(); M:Refresh() end, true)
	self.rpOk:SetPoint("LEFT", self.rpSuggest, "RIGHT", 10, 0)
	self.rpLater = UI:Button(v, L["Später"], 90, 22, function() RPx:Later(); M:Refresh() end)
	self.rpLater:SetPoint("LEFT", self.rpOk, "RIGHT", 6, 0)
end

function M:RefreshComp()
	self.compList:SetData(ns.Comp:Table())
	local RPx = ns.RaidReady
	local w = ns.Comp:WantedText()
	local b = ns.Craft:WantedText()
	-- was {gesucht} in der Werbung ergibt: hängt von der Rekrutierungsphase ab (RP1)
	local wanted
	if RPx:Phase() == "raid" then
		wanted = w ~= "" and (GREEN .. ns.Comp:WantedList() .. "|r") or Gray(string.format(L["{gesucht} wird zu „%s“ – es fehlt nichts."], L["neue Mitglieder"]))
	else
		wanted = GREEN .. RPx:Wanted() .. "|r" .. Gray("  (" .. string.format(L["Phase %s – die Vorgaben oben gelten ab Phase Raid"], RPx.PhaseName(RPx:Phase())) .. ")")
	end
	self.compWanted:SetText(L["Für die Werbung: "] .. wanted .. (b ~= "" and ("  " .. GREEN .. b .. "|r") or ""))
	local m = RPx:Measure()
	self.rpProgress:SetText(RPx:ProgressText(m) .. "  " .. (m.pct >= 100 and GREEN or GOLD) .. m.pct .. "%|r")
	local off = ns.IsOfficer()
	self.rpPhase:SetEnabled(off); self.rpRaid:SetEnabled(off)
	local to, dir = RPx:Pending()
	if to then
		self.rpSuggest:SetText(GOLD .. string.format(dir == "down" and L["Vorschlag: zurück zur Phase %s (seit 7 Tagen unter der Schwelle)."] or L["Vorschlag: Phase %s (Erfüllungsgrad %d%%)."], RPx.PhaseName(to), m.pct) .. "|r")
	elseif not off then
		self.rpSuggest:SetText(Gray(L["Die Phase stellen Gildenmeister und Offiziere ein."]))
	else
		self.rpSuggest:SetText(Gray(L["Kein Vorschlag – umgeschaltet wird nur nach Bestätigung eines Offiziers."]))
	end
	self.rpOk:SetShown(to ~= nil); self.rpLater:SetShown(to ~= nil)
end

-- Wer ist wo: Online-Mitglieder nach Zone
function M:BuildWhere(p)
	local v = CreateFrame("Frame", nil, p)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	self.whereView = v
	self.whereInfo = UI:Label(v, "", "GameFontHighlightSmall")
	self.whereInfo:SetPoint("TOPLEFT", 0, -4)
	self.whereList = UI:List(v, {
		{ key = "name", title = L["Zone / Name"], width = 260 },
		{ key = "level", title = L["Stufe"], width = 50, align = "CENTER" },
		{ key = "class", title = L["Klasse"], width = 100 },
		{ key = "main", title = L["Main"], width = 130 },
		{ key = "x", title = L["Status"] },   -- 0.9.59 L6 (T314): jede Spalte beschriftet
	}, {
		key = function(r) return r.head and ("#" .. r.zone) or r.e.name end,
		render = function(r)
			if r.head then
				return { (r.mine and GREEN or GOLD) .. r.zone .. "|r" .. Gray(" (" .. r.n .. ")") .. (r.mine and Gray(" – " .. L["deine Zone"]) or ""), "", "", "", "" }
			end
			local e = r.e
			local away = ns.Social:Away(e.name) and (ORANGE .. L["abwesend gemeldet"] .. "|r") or ""
			return { "   " .. ns.Colored(e.name, e.class), tostring(e.level), ns.ClassName(e.class), ns.Roster:MainOf(e.name) or "", away }
		end,
		onClick = function(r, button)
			if r.head then return end
			M.whereWhisper:SetEnabled(true)
			M.whereInvite:SetEnabled(true)
			if button == "RightButton" then M:Menu(r.e) end
		end,
		empty = L["Gerade ist niemand online."],
	})
	self.whereList:SetPoint("TOPLEFT", 0, -24)
	self.whereList:SetPoint("BOTTOMRIGHT", 0, 40)
	local function Sel() local r = M.whereList:Selected(); return r and not r.head and r.e.name end
	self.whereWhisper = UI:Button(v, L["Anflüstern"], 130, 28, function() local n = Sel(); if n then ns.Recruit:Whisper(n) end end)
	self.whereWhisper:SetPoint("BOTTOMLEFT", 0, 4)
	self.whereInvite = UI:Button(v, L["In Gruppe einladen"], 150, 28, function()
		ns.InviteParty(Sel())
	end)
	self.whereInvite:SetPoint("LEFT", self.whereWhisper, "RIGHT", 8, 0)
	self.whereSvc = UI:Label(v, "", "GameFontHighlightSmall")
	self.whereSvc:SetPoint("LEFT", self.whereInvite, "RIGHT", 14, 0)
	self.whereSvc:SetPoint("RIGHT", 0, 0)
end

function M:RefreshWhere()
	local rows = ns.Social:ZoneRows()
	self.whereList:SetData(rows)
	local zones, n = 0, 0
	for _, r in ipairs(rows) do if r.head then zones = zones + 1 else n = n + 1 end end
	self.whereInfo:SetText(Gray(string.format(L["%d online in %d Zonen – praktisch zum Treffen, Beschwören und für Weltbosse."], n, zones)))
	local r = self.whereList:Selected()
	self.whereWhisper:SetEnabled(r ~= nil and not r.head)
	self.whereInvite:SetEnabled(r ~= nil and not r.head)
	local offers = ns.Board:Offers()
	local t = {}
	for _, o in ipairs(offers) do
		for _, k in ipairs(o.keys) do if k == "summon" or k:find("^port_") then t[#t + 1] = o.name .. ": " .. ns.Board:ServiceName(k) end end
	end
	self.whereSvc:SetText(#t > 0 and (Gray(L["Gerade im Angebot: "]) .. table.concat(t, ", ")) or "")
end

-- Export der Mitgliederliste
M.exportFmt = "text"
M.exportMains = true

function M:BuildExport(p)
	local v = CreateFrame("Frame", nil, p)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	self.exportView = v
	local dd = UI:Dropdown(v, 170, function()
		return { { value = "text", text = L["Als Text"] }, { value = "csv", text = L["Als Tabelle (CSV)"] } }
	end, function() return M.exportFmt end, function(val) M.exportFmt = val; M:RefreshExport() end)
	dd:SetPoint("TOPLEFT")
	local mains = UI:Check(v, L["Twinks beim Main aufführen"], function() return M.exportMains end, function(val) M.exportMains = val; M:RefreshExport() end)
	mains:SetPoint("LEFT", dd, "RIGHT", 14, 0)
	local sel = UI:Button(v, L["Alles markieren"], 140, 24, function() M.exportBox.SelectAll() end, true)
	sel:SetPoint("TOPRIGHT")
	local hint = UI:Label(v, Gray(L["Markieren, dann Strg+C zum Kopieren."]), "GameFontHighlightSmall")
	hint:SetPoint("RIGHT", sel, "LEFT", -10, 0)
	self.notesBtn = UI:Button(v, L["Twinks in Gildennotizen eintragen"], 240, 24, function()
		local list = ns.Social:NotesToWrite()
		if #list == 0 then ns:Print(L["Alle Twinks stehen schon in den Gildennotizen."]) return end
		local q = #list == 1 and string.format(L["Bei %s 'Twink von …' in die öffentliche Gildennotiz schreiben?"], list[1])
			or string.format(L["Bei %d Twinks 'Twink von …' in die öffentliche Gildennotiz schreiben?"], #list)
		UI:Confirm(q, function() ns.Social:WriteAllNotes() end)
	end)
	self.notesBtn:SetPoint("TOPLEFT", 0, -32)
	local nh = UI:Label(v, Gray(L["Schreibt 'Twink von …' in die öffentliche Gildennotiz – dann sehen es auch alle ohne GuildSentinel."]), "GameFontHighlightSmall")
	nh:SetPoint("LEFT", self.notesBtn, "RIGHT", 10, 0)
	nh:SetPoint("RIGHT", 0, 0)
	nh:SetJustifyH("LEFT")
	self.exportBox = UI:ScrollEdit(v, 780, 450, 100000)
	self.exportBox:SetPoint("TOPLEFT", 0, -64)
	self.exportBox:SetPoint("BOTTOMRIGHT")
end

function M:ExportText(fmt, mainsOnly)
	local list = ns.Roster:Filtered({ sort = "name" })
	local out = {}
	local function Profs(name)
		local pr = ns.Prof:Of(name)
		local t = {}
		for prof, x in pairs(pr and pr.p or {}) do t[#t + 1] = prof .. " " .. (x.r or "?") end
		table.sort(t)
		return table.concat(t, ", ")
	end
	if fmt == "csv" then
		out[1] = table.concat({ L["Name"], L["Stufe"], L["Klasse"], L["Rang"], L["Main"], L["Berufe"], L["Zuletzt online"], L["Notiz"] }, ";")
		for _, e in ipairs(list) do
			local main = ns.Roster:MainOf(e.name) or ""
			local seen = e.online and L["online"] or (e.seen and e.seen > 0 and date(L["%d.%m.%Y"], e.seen) or "")
			local note = (e.note or ""):gsub(";", ",")
			out[#out + 1] = table.concat({ e.name, e.level, ns.ClassName(e.class), e.rank or "", main, Profs(e.name), seen, note }, ";")
		end
	else
		out[1] = string.format(L["Mitglieder von <%s> – Stand %s"], ns.DisplayGuildName() or "", ns.Date())
		out[2] = ""
		for _, e in ipairs(list) do
			if not mainsOnly or not ns.Roster:IsAlt(e.name) then
				local line = string.format("%s (%d %s, %s)", e.name, e.level, ns.ClassName(e.class), e.rank or "")
				if mainsOnly then
					local alts = {}
					for _, a in ipairs(ns.Roster:AltsOf(e.name)) do
						local x = ns.Roster.byName[a]
						alts[#alts + 1] = x and string.format("%s (%d %s)", a, x.level, ns.ClassName(x.class)) or a
					end
					if #alts > 0 then line = line .. " – " .. L["Twinks: "] .. table.concat(alts, ", ") end
				else
					local main = ns.Roster:MainOf(e.name)
					if main then line = line .. " – " .. L["Twink von "] .. main end
				end
				local pr = Profs(e.name)
				if pr ~= "" then line = line .. " – " .. L["Berufe: "] .. pr end
				out[#out + 1] = line
			end
		end
	end
	return table.concat(out, "\n")
end

function M:RefreshExport()
	if not self.exportBox then return end
	self.exportBox:SetText(self:ExportText(self.exportFmt, self.exportMains))
end

function M:ShowDetail(e)
	local d = self.detail
	if not d then return end
	self.selected = e and e.name or nil
	local on = e ~= nil
	for _, b in ipairs({ d.whisper, d.invite, d.setMain, d.isMain, d.thank }) do b:SetEnabled(on) end
	local isMe = e and ns.Same(e.name, ns.Me())
	d.thank:SetEnabled(on and not isMe)
	d.away:SetEnabled(on and (isMe or ns.IsOfficer()))
	d.mentor:SetEnabled(on and ns.IsOfficer())
	-- ausgeschaltete Funktionen: Knopf ausblenden
	d.thank:SetShown(ns.Feature("thanks"))
	d.away:SetShown(ns.Feature("away"))
	d.mentor:SetShown(ns.Feature("mentor"))
	local main = e and ns.Roster:MainOf(e.name)
	d.writeNote:SetEnabled(on and main ~= nil and ns.Social:CanWriteNotes() and ns.Social:NoteWithMain(e.note, main) ~= ns.Trim(e.note))
	d.note:SetEnabled(on)
	if not e then
		d.title:SetText(Gray(L["Wähle ein Mitglied aus der Liste."]))
		d.info:SetText("")
		d.note:SetText("")
		return
	end
	d.title:SetText(ns.Colored(e.name, e.class) .. "  " .. Gray(string.format("%s %d %s · %s", L["Stufe"], e.level, ns.ClassName(e.class), e.rank or "")))
	local lines = {}
	local main = ns.Roster:MainOf(e.name)
	if main then
		lines[#lines + 1] = L["Twink von "] .. ns.Colored(main, ns.G().roster[main] and ns.G().roster[main].c)
	else
		local alts = ns.Roster:AltsOf(e.name)
		if #alts > 0 then
			local t = {}
			for _, a in ipairs(alts) do t[#t + 1] = ns.Colored(a, ns.G().roster[a] and ns.G().roster[a].c) end
			lines[#lines + 1] = L["Twinks: "] .. table.concat(t, ", ")
		end
	end
	local pr = ns.Prof:Of(e.name)
	if pr and pr.p then
		local t = {}
		for prof, x in pairs(pr.p) do t[#t + 1] = prof .. " " .. (x.r or "?") end
		table.sort(t)
		lines[#lines + 1] = L["Berufe: "] .. table.concat(t, ", ")
	end
	if e.online then
		lines[#lines + 1] = GREEN .. L["online"] .. "|r – " .. (e.zone or "")
	else
		lines[#lines + 1] = L["Zuletzt online: "] .. ns.Ago(e.seen)
	end
	local r = ns.G().roster[e.name]
	local join = ns.Jubilee:JoinDate(e.name)
	if join then lines[#lines + 1] = L["In der Gilde seit: "] .. date(L["%d.%m.%Y"], join) end
	local att = {}
	for _, a in ipairs(ns.Attune.LIST) do
		local st = ns.Attune:Status(e.name, a.key)
		if st ~= nil then att[#att + 1] = (st and GREEN or ORANGE) .. a.short .. "|r" end
	end
	if #att > 0 then lines[#lines + 1] = L["Raid-Zugänge: "] .. table.concat(att, " ") end
	if ns.Rules:HasRules() then
		lines[#lines + 1] = ns.Rules:Acked(e.name) and (GREEN .. L["Gildenregeln bestätigt"] .. "|r") or Gray(L["Gildenregeln noch nicht bestätigt"])
	end
	local extra = {}
	local away = ns.Social:IsAway(e.name)
	if away then extra[#extra + 1] = ORANGE .. string.format(L["Abwesend bis %s"], date(L["%d.%m.%Y"], away.u)) .. "|r" .. ((away.note ~= "") and (" – " .. away.note) or "") end
	local mentor = ns.Social:MentorOf(e.name)
	if mentor then extra[#extra + 1] = L["Pate: "] .. mentor end
	local mentees = ns.Social:Mentees(e.name)
	if #mentees > 0 then extra[#extra + 1] = L["Pate von: "] .. table.concat(mentees, ", ") end
	local thx = 0
	for _, x in ipairs(ns.Social:ThanksTop(30)) do if x.name == (ns.Roster:MainOf(e.name) or e.name) then thx = x.n end end
	if thx > 0 then extra[#extra + 1] = string.format(L["%d× Danke (30 Tage)"], thx) end
	if #extra > 0 then lines[#lines + 1] = table.concat(extra, " · ") end
	d.info:SetText(table.concat(lines, "\n"))
	d.note:SetText(ns.G().notes[e.name] or "")
end

-- Rechtsklick-Menü auf ein Mitglied (RV1/RV2): Flüstern, Gruppe, Ränge, Twinks, Notizen, Abwesenheit, Danke, Pate,
-- Entfernen, Gildenleitung. Was das Spiel nicht erlaubt, steht grau mit Grund da. Geschützte Gilden-Aktionen laufen nie
-- direkt, sondern über den sicheren Knopf im Fenster "Gilden-Aktion" (GuildAct.lua, Lehre aus GV1).
M.multi = {}   -- Mehrfachauswahl (Shift/Strg-Klick): [Name] = true

local function MenuAnchor()
	if not M.menuAnchor then
		M.menuAnchor = CreateFrame("Frame", nil, UIParent)
		M.menuAnchor:SetSize(170, 1)
	end
	local x, y = GetCursorPosition()
	local sc = UIParent:GetEffectiveScale()
	M.menuAnchor:ClearAllPoints()
	M.menuAnchor:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", x / sc, y / sc)
	return M.menuAnchor
end

-- Menü anzeigen; Einträge mit off = Grund sind grau und sagen beim Klick nur den Grund
local function ShowMenu(items, handlers)
	local shown = {}
	for _, it in ipairs(items) do
		shown[#shown + 1] = { value = it.value, text = it.off and (Gray(it.text .. "  (" .. it.off .. ")")) or it.text, off = it.off }
	end
	UI:PopupMenu(M.menuAnchor or MenuAnchor(), shown, function(val, it)
		if it and it.off then ns:Print(it.off) return end
		local h = handlers[val]
		if h then h() end
	end)
end

local function CanRight(fname)
	if ns.Test and ns.Test:Active() then return true end
	local f = _G[fname]
	if type(f) ~= "function" then return false end
	local ok, r = pcall(f)
	return ok and r and not ns.IsSecret(r) and true or false
end

-- Einträge für ein Mitglied: { value, text, off = Grund } (für Menü und Testroutine)
function M.MenuItems(name)
	local e = ns.Roster.byName[name]
	local Ad, GA = ns.Admin, ns.GuildAct
	local items = {}
	local function add(value, text, off) items[#items + 1] = { value = value, text = text, off = off or nil } end
	local me = ns.Same(name, ns.Me())
	add("whisper", L["Flüstern"], me and L["Das bist du."] or nil)
	add("party", L["In die Gruppe einladen"], me and L["Das bist du."] or nil)
	if not e then
		-- kein Mitglied (z. B. Bewerber): in die Gilde einladen über die Chat-Eingabe
		add("ginvite", L["In die Gilde einladen"], not ns.CanInvite() and L["Dein Rang hat dieses Recht im Spiel nicht."] or nil)
		return items, e
	end
	local combat = ns.InCombat() and L["nicht im Kampf"] or nil
	local a = Ad.Allowed(e)
	local r = Ad.Rights()
	local function why(ok, right)
		if me then return L["Das bist du."] end
		if combat then return combat end
		if ok then return nil end
		-- GS-RANG-1: eigener Rang unbekannt -> das sagen statt "nicht über den eigenen Rang"
		if right and a.unknown then return L["Eigener Rang noch nicht geladen – gleich noch einmal versuchen."] end
		return right and L["Nicht über den eigenen Rang und nie zum Gildenmeister."] or L["Dein Rang hat dieses Recht im Spiel nicht."]
	end
	add("promote", e.ri and e.ri > 0 and (L["Befördern"] .. " (" .. Ad.RankName(e.ri) .. " -> " .. Ad.RankName(e.ri - 1) .. ")") or L["Befördern"], why(a.promote, r.promote))
	add("demote", e.ri and (L["Degradieren"] .. " (" .. Ad.RankName(e.ri) .. " -> " .. Ad.RankName(e.ri + 1) .. ")") or L["Degradieren"], why(a.demote, r.demote))
	add("setrank", L["Rang setzen …"], why(a.promote or a.demote, r.promote or r.demote))
	add("alts", L["Twink zuordnen …"])
	add("note", L["Notiz bearbeiten"], not CanRight("CanEditPublicNote") and L["Dein Rang hat dieses Recht im Spiel nicht."] or nil)
	add("onote", L["Offiziersnotiz bearbeiten"], not r.officer and L["Dein Rang hat dieses Recht im Spiel nicht."] or nil)
	add("away", L["Abwesenheit eintragen"], (not me and not ns.IsOfficer()) and L["Abwesenheit für andere können nur Offiziere eintragen."] or nil)
	if ns.Feature("thanks") then add("thank", L["Danke sagen"], me and L["Das bist du."] or nil) end
	add("mentor", L["Pate zuweisen …"])
	add("remove", L["Aus der Gilde entfernen"], why(a.remove, r.remove))
	if r.leader then add("leader", L["Gildenleitung übergeben"], why(a.leader, true)) end
	return items, e
end

-- Rang-Liste unter dem eigenen Rang (für "Rang setzen")
function M.RankItems(name)
	local e = ns.Roster.byName[name]
	local Ad, GA = ns.Admin, ns.GuildAct
	local out = {}
	local my = GA.MyRank()
	if not e or my == nil then return out end
	for ri = my + 1, Ad.NumRanks() - 1 do
		if ri ~= e.ri then
			local steps, why = GA.RankSteps(name, ri)
			local text = Ad.RankName(ri)
			if steps then
				text = text .. "  " .. Gray(string.format(ri < e.ri and L["Befördern – %d Stufen"] or L["Degradieren – %d Stufen"], #steps))
			end
			out[#out + 1] = { value = ri, text = text, off = not steps and GA.Reason(why) or nil }
		end
	end
	return out
end

local function EditNote(name, officer)
	local e = ns.Roster.byName[name]
	if not e then return end
	local fname = officer and "GuildRosterSetOfficerNote" or "GuildRosterSetPublicNote"
	UI:Ask(string.format(officer and L["Offiziersnotiz für %s:"] or L["Notiz für %s:"], name), (officer and e.onote or e.note) or "", function(t)
		t = ns.Trim(t or ""):sub(1, 31)
		local fn = _G[fname]
		if not fn or not e.index then return end
		if not ns.Blocked(L["Gildennotiz"] .. " " .. name .. ": " .. t) then ns.Act(fname, fn, e.index, t) end
		if ns.GuildRoster then C_Timer.After(1, function() ns.GuildRoster() end) end
	end)
end

-- Mehrfachauswahl: Befördern/Degradieren für alle Ausgewählten, je Mitglied ein Klick (RV8)
function M.MultiNames(kind)
	local out = {}
	for n in pairs(M.multi) do
		local e = ns.Roster.byName[n]
		local a = e and ns.Admin.Allowed(e) or {}
		if a[kind] then out[#out + 1] = n end
	end
	table.sort(out)
	return out
end

function M:Menu(e)
	local name = type(e) == "table" and e.name or e
	if type(name) ~= "string" then return end
	-- (Prüflisten-Punkt MENU seit 0.9.57 entfernt: im Spiel erledigt 17.11.)
	MenuAnchor()
	local GA = ns.GuildAct
	-- Mehrfachauswahl: eigenes kleines Menü
	if M.multi[name] and next(M.multi, next(M.multi)) then
		local n = 0
		for _ in pairs(M.multi) do n = n + 1 end
		local pro, de = M.MultiNames("promote"), M.MultiNames("demote")
		local combat = ns.InCombat() and L["nicht im Kampf"] or nil
		ShowMenu({
			{ value = "promote", text = string.format(L["Befördern (%d von %d ausgewählt)"], #pro, n), off = combat or (#pro == 0 and L["Dein Rang hat dieses Recht im Spiel nicht."]) or nil },
			{ value = "demote", text = string.format(L["Degradieren (%d von %d ausgewählt)"], #de, n), off = combat or (#de == 0 and L["Dein Rang hat dieses Recht im Spiel nicht."]) or nil },
			{ value = "clear", text = L["Auswahl aufheben"] },
		}, {
			promote = function() GA:Run("promote", pro) end,
			demote = function() GA:Run("demote", de) end,
			clear = function() wipe(M.multi); M:Refresh() end,
		})
		return
	end
	local items, me = M.MenuItems(name)
	ShowMenu(items, {
		whisper = function() ns.Recruit:Whisper(name) end,
		party = function() ns.InviteParty(name) end,
		ginvite = function() ns.Recruit:Invite(name) end,
		promote = function() ns.Admin.Promote(me) end,
		demote = function() ns.Admin.Demote(me) end,
		setrank = function()
			-- Auswahl eines Rangs: Werte sind Zahlen, darum eigener Aufruf
			UI:PopupMenu(M.menuAnchor, (function()
				local t = {}
				for _, it in ipairs(M.RankItems(name)) do t[#t + 1] = { value = it.value, text = it.off and Gray(it.text .. "  (" .. it.off .. ")") or it.text, off = it.off } end
				return t
			end)(), function(ri, it)
				if it and it.off then ns:Print(it.off) return end
				GA:SetRank(name, ri)
			end)
		end,
		alts = function()
			ShowMenu({
				{ value = "main", text = L["Main wählen …"] },
				{ value = "ismain", text = L["Twink lösen (ist ein Main)"] },
			}, {
				main = function()
					UI:Ask(string.format(L["Wessen Twink ist %s? (Name des Mains)"], name), ns.Roster:MainOf(name) or "", function(main)
						main = ns.Trim(main)
						if main ~= "" then ns.Roster:SetMain(name, main) end
					end)
				end,
				ismain = function() ns.Roster:SetMain(name, "") end,
			})
		end,
		note = function() EditNote(name, false) end,
		onote = function() EditNote(name, true) end,
		away = function()
			UI:Ask(string.format(L["Wie viele Tage ist %s weg? (0 = wieder da)"], name), "14", function(t)
				local days = tonumber(ns.Trim(t):match("^(%d+)"))
				if days then ns.Social:SetAway(name, days, "") else ns:Print(L["Bitte eine Zahl eingeben (Tage, 0 = wieder da)."]) end
			end)
		end,
		thank = function()
			UI:Ask(string.format(L["Wofür dankst du %s? (optional)"], name), "", function(why) ns.Social:Thank(name, why) end)
		end,
		mentor = function()
			UI:Ask(string.format(L["Wer wird Pate von %s? (leer = keiner)"], name), ns.Social:MentorOf(name) or ns.Me(), function(m) ns.Social:SetMentor(name, m) end)
		end,
		remove = function()
			UI:Confirm(string.format(L["Wirklich %s aus der Gilde entfernen?"], name), function() ns.Admin.Remove(me) end)
		end,
		leader = function()
			if not ns.Admin.unlocked then
				ns:Print(L["Gesperrt – erst das Passwort eingeben."])
				ns.Admin:Open()
				return
			end
			UI:Confirm(string.format(L["Gildenleitung wirklich an %s übergeben? Du verlierst den Rang Gildenmeister."], name), function() ns.Admin.SetLeader(me) end)
		end,
	})
end

-- für andere Seiten (Bewerber, Leitung): Menü zu einem Namen
function ns.MemberMenu(name) M:Menu(name) end
ns.MembersPage = M

function M:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	self.listView:SetShown(self.view == "list")
	self.logList:SetShown(self.view == "log")
	self.inactiveView:SetShown(self.view == "inactive")
	self.onlineView:SetShown(self.view == "online")
	self.promoView:SetShown(self.view == "promo")
	self.compView:SetShown(self.view == "comp")
	self.exportView:SetShown(self.view == "export")
	self.whereView:SetShown(self.view == "where")
	if self.view == "list" then
		-- G-4a: Teile messen (Liste lesen/filtern/sortieren, Zeilen setzen, Zahlen, Einzelheiten) – im Protokoll bei LANGSAM
		local Ms = debugprofilestop
		local t0 = Ms and Ms() or 0
		local f = self.filter
		local data = ns.Roster:Filtered({ text = f.text, online = f.online, class = f.class, ri = f.ri, alts = f.alts, sort = f.sort, desc = f.desc })
		local t1 = Ms and Ms() or 0
		self.list:SetData(data, f.sort, f.desc)
		local t2 = Ms and Ms() or 0
		local total, online, mains, mainsOnline, max = ns.Roster:Stats()
		self.stats:SetText(string.format(L["%d Charaktere · %d Spieler · %d online · %d auf Maximalstufe"], total, mains, online, max))
		local t3 = Ms and Ms() or 0
		if self.selected and ns.Roster.byName[self.selected] then self:ShowDetail(ns.Roster.byName[self.selected]) end
		local t4 = Ms and Ms() or 0
		self.lastParts = string.format("lesen/filtern/sortieren %.1f ms (%d Zeilen), Zeilen setzen %.1f ms, Zahlen %.1f ms, Einzelheiten %.1f ms",
			t1 - t0, #data, t2 - t1, t3 - t2, t4 - t3)
	elseif self.view == "log" then
		self.logList:SetData(ns.G().log)
	elseif self.view == "inactive" then
		self.inactiveList:SetData(ns.Roster:Inactive(self.inactiveDays))
	elseif self.view == "online" then
		self:RefreshOnline()
	elseif self.view == "promo" then
		self:RefreshPromo()
	elseif self.view == "comp" then
		self:RefreshComp()
	elseif self.view == "where" then
		self:RefreshWhere()
	elseif self.view == "export" then
		if not self.exportBox.edit:HasFocus() then self:RefreshExport() end
	end
end

M.onShow = function(_, arg)
	if type(arg) == "string" and M.tabs then M.tabs:Select(arg) else M:Refresh() end
end
ns:Listen("GS_SOCIAL", WhenShown("members", function() M:Refresh() end))
ns:Listen("GS_BOARD", WhenShown("members", function() if M.view == "where" then M:Refresh() end end))
ns:Listen("GS_ROSTER", WhenShown("members", function() M:Refresh() end))
ns:Listen("GS_LOG", WhenShown("members", function() M:Refresh() end))
ns:Listen("GS_PROF", WhenShown("members", function() M:Refresh() end))
ns:Listen("GS_ACTIVITY", WhenShown("members", function() if M.view == "online" then M:Refresh() end end))
ns:Listen("GS_PROMO", WhenShown("members", function() if M.view == "promo" then M:Refresh() end end))
ns:Listen("GS_COMP", WhenShown("members", function() if M.view == "comp" then M:Refresh() end end))
ns:Listen("GS_ATTUNE", WhenShown("members", function() if M.view == "list" then M:Refresh() end end))
UI:AddPage(M)

------------------------------------------------------------
-- Seite: Rekrutierung
------------------------------------------------------------
local R = { key = "recruit", feature = "recruit", order = 50, icon = "Interface\\Icons\\Ability_Warrior_BattleShout" }

-- Platzhalter mit Bedeutung (Befund Nutzer 19.11. 09:00): nur im Tooltip eines kleinen Knopfs, nie als Block auf der Seite
R.PLACEHOLDER_TEXT = {
	gilde = N["{gilde} – Name der Gilde"],
	fraktion = N["{fraktion} – Horde oder Allianz"],
	name = N["{name} – dein Charakter (zum Anflüstern)"],
	discord = N["{discord} – Discord-Link aus den Einstellungen"],
	tag = N["{tag} – Discord-Server-Tag"],
	mitglieder = N["{mitglieder} – Zahl der Mitglieder"],
	online = N["{online} – Mitglieder gerade online"],
	gesucht = N["{gesucht} – was der Gilde fehlt (Aufstellung)"],
	phase = N["{phase} – wofür die Gilde gerade sucht"],
	berufe = N["{berufe} – Berufe mit fehlenden Rezepten"],
	spieler = N["{spieler} – Name des Bewerbers bzw. neuen Mitglieds"],
	alter = N["{alter} – das verlangte Mindestalter"],
}
R.AD_PLACEHOLDERS = { "gilde", "fraktion", "name", "discord", "tag", "mitglieder", "online", "gesucht", "phase", "berufe" }
function R.PlaceholderTip(keys)
	local lines = {}
	for _, k in ipairs(keys) do lines[#lines + 1] = L[R.PLACEHOLDER_TEXT[k]] end
	return table.concat(lines, "\n")
end
function R.PlaceholderButton(parent, keys)
	local b = UI:Button(parent, L["Platzhalter"] .. " (?)", 110, 20, function() end)
	b:HookScript("OnEnter", function(self)
		UI.TipOwner(self, "ANCHOR_RIGHT")
		GameTooltip:AddLine(L["Platzhalter"], 1, 1, 1)
		GameTooltip:AddLine(L["Werden beim Senden durch den Wert ersetzt."], 0.8, 0.8, 0.8, true)
		for _, k in ipairs(keys) do GameTooltip:AddLine(L[R.PLACEHOLDER_TEXT[k]], 1, 0.82, 0) end
		GameTooltip:Show()
	end)
	b:HookScript("OnLeave", function() GameTooltip:Hide() end)
	b.keys = keys
	return b
end
R.title = N["Rekrutierung"]
R.view = "ad"
R.showAll = false
R.badge = function()
	local n = #ns.Recruit:Applicants()
	return n > 0 and (GREEN .. n .. "|r") or ""
end

local function DbText(key)
	return function() return ns.db[key] or "" end
end

function R.build(p)
	R.panel = p
	R.tabs = UI:Tabs(p, {
		{ key = "ad", text = L["Werbung"] },
		{ key = "apps", text = L["Bewerber"] },
		{ key = "texts", text = L["Antworten & Begrüßung"] },
		{ key = "rules", text = L["Gildenregeln"] },
	}, function(key) R.view = key; R:Refresh() end)
	R.tabs:SetPoint("TOPLEFT")
	R.tabs:SetPoint("TOPRIGHT")

	-- Werbung ---------------------------------------------
	local ad = CreateFrame("Frame", nil, p)
	ad:SetPoint("TOPLEFT", 0, -34)
	ad:SetPoint("BOTTOMRIGHT")
	R.adView = ad

	local h1 = UI:Header(ad, L["Werbetext"])
	h1:SetPoint("TOPLEFT", 0, 0)
	R.rpLine = UI:Label(ad, "", "GameFontHighlightSmall")
	R.rpLine:SetPoint("LEFT", h1, "RIGHT", 12, 0)
	R.rpLine:SetPoint("RIGHT", ad, "RIGHT", 0, 0)
	R.rpLine:SetJustifyH("LEFT")
	-- Befund Nutzer 19.11. 09:00: graue Hilfszeile "Leer lassen = Standardtext" im leeren Feld (vor dem Standardtext)
	R.adEdit = UI:Edit(ad, 520, 76, L["Leer lassen = Standardtext"] .. ":\n" .. ns.Recruit:DefaultAd(), true, 255)
	R.adEdit:SetPoint("TOPLEFT", h1, "BOTTOMLEFT", 0, -6)
	R.adEdit.onChange = function(t, user) if user then ns.db.adText = t; R:Preview() end end
	-- Befund Nutzer 19.11. 09:00 ("Platzhalter: {gilde} …" als weisser Block wirkt wie Technik): nur ein kleiner Knopf, die Liste mit
	-- Bedeutung im Tooltip
	local ph = R.PlaceholderButton(ad, R.AD_PLACEHOLDERS)
	ph:SetPoint("TOPLEFT", R.adEdit, "TOPRIGHT", 14, 0)
	R.adPh = ph
	-- GS-W2: Auswahl fertiger Vorschläge (Name · Zeichen, Maus darüber = fertiger Text); ersetzt das Feld erst nach Klick
	R.sugg2 = UI:Button(ad, L["Vorschlag wählen"], 130, 20, function(self)
		local Rc = ns.Recruit
		local items = {}
		for _, s in ipairs(Rc:Suggestions()) do
			local raw = Rc:SuggestionText(s) or Rc:DefaultAd()
			local filled = Rc:Build(raw)
			items[#items + 1] = { value = s.id, text = L[s.label] .. Gray("  · " .. string.format(L["%d Zeichen"], #filled)), tip = filled }
		end
		UI:PopupMenu(self, items, function(id)
			for _, s in ipairs(Rc.SUGGESTIONS) do
				if s.id == id then
					ns.db.adText = Rc:SuggestionText(s)
					R.adEdit:SetText(ns.db.adText or "")
					R:Preview()
					ns.PLHit("GSW2", s.id .. ", " .. #Rc:AdText() .. " Zeichen")
				end
			end
		end)
	end)
	R.sugg2:SetPoint("TOPLEFT", ph, "BOTTOMLEFT", 0, -4)
	-- GA2: eigener Text ohne {gesucht}/{phase} -> gelber Hinweis mit "Übernehmen" (Standardtext der Phase)
	R.adHint = UI:Label(ad, "", "GameFontHighlightSmall")
	R.adHint:SetPoint("LEFT", R.sugg2, "RIGHT", 10, 0)
	R.adHint:SetWidth(470)
	R.adHint:SetJustifyH("LEFT")
	R.adAdopt = UI:Button(ad, L["Übernehmen"], 100, 20, function()
		-- GS-W1 (c): fehlt der Flüster-Teil, wird nur er angehängt; sonst (GA2) Standardtext der Phase
		if ns.Recruit:OwnAdWithoutWhisper() then
			ns.Recruit:AppendWhisper()
			R.adEdit:SetText(ns.db.adText or "")
			ns.PLHit("GSW1", ns.Recruit.HasWhisper(ns.db.adText or "") and "/w angehängt" or "ohne /w")
		else
			ns.db.adText = nil
			R.adEdit:SetText("")
		end
		R:Preview()
	end)
	R.adAdopt:SetPoint("LEFT", R.adHint, "RIGHT", 6, 0)

	local h2 = UI:Header(ad, L["Vorschau"])
	h2:SetPoint("TOPLEFT", R.adEdit, "BOTTOMLEFT", 0, -14)
	R.preview = UI:Label(ad, "", "GameFontHighlight")
	R.preview:SetPoint("TOPLEFT", h2, "BOTTOMLEFT", 0, -6)
	R.preview:SetWidth(740)
	R.preview:SetJustifyV("TOP")
	R.length = UI:Label(ad, "", "GameFontDisableSmall")
	R.length:SetPoint("LEFT", h2, "RIGHT", 10, 0)

	local h3 = UI:Header(ad, L["Discord-Einladung"])
	h3:SetPoint("TOPLEFT", h2, "BOTTOMLEFT", 0, -48)
	R.discord = UI:Edit(ad, 320, 24, "discord.gg/…")
	R.discord:SetPoint("TOPLEFT", h3, "BOTTOMLEFT", 0, -6)
	R.discord.onChange = function(t, user) if user then ns.db.discord = ns.Trim(t); R:Preview() end end
	-- Server-Tag der Gilde auf Discord (für {tag}, z. B. in Vorschlag 2)
	R.tagLabel = UI:Label(ad, L["Server-Tag:"], "GameFontNormalSmall")
	R.tagLabel:SetPoint("LEFT", R.discord, "RIGHT", 12, 0)
	R.tag = UI:Edit(ad, 70, 24, "")
	R.tag:SetPoint("LEFT", R.tagLabel, "RIGHT", 6, 0)
	R.tag.onChange = function(t, user) if user then ns.db.discordTag = ns.Trim(t); R:Preview() end end
	-- Tipp zur Einladung (nur Text, der Link wird nicht geprüft)
	R.discordTip = UI:Label(ad, Gray(L["Tipp: eine dauerhafte Einladung verwenden (läuft nie ab, unbegrenzte Nutzungen). Wer klickt, sieht vor dem Beitritt das Serverprofil der Gilde."]), "GameFontHighlightSmall")
	R.discordTip:SetPoint("TOPLEFT", R.discord, "BOTTOMLEFT", 0, -3)
	R.discordTip:SetWidth(740)
	R.discordTip:SetJustifyH("LEFT")

	local h4 = UI:Header(ad, L["Kanäle"])
	h4:SetPoint("TOPLEFT", R.discordTip, "BOTTOMLEFT", 0, -12)
	R.chanHint = UI:Label(ad, Gray(L["Jeder Klick legt die Werbung für einen Kanal in die Chat-Eingabe, der nächste Klick nimmt den nächsten."]), "GameFontHighlightSmall")
	R.chanHint:SetPoint("LEFT", h4, "RIGHT", 10, 0)
	R.chanHolder = CreateFrame("Frame", nil, ad)
	R.chanHolder:SetPoint("TOPLEFT", h4, "BOTTOMLEFT", 0, -4)
	R.chanHolder:SetSize(740, 50)
	R.chanChecks = {}

	-- OPT-ALLE 18.11.: "Erinnern, wenn die Werbung wieder fällig ist" und die Minuten stehen jetzt in den Optionen (Bereich
	-- Rekrutierung); hier ein Knopf, der dort öffnet
	R.optBtn = ns.Options.Button(ad, "rekrut")
	R.optBtn:SetPoint("TOPLEFT", R.chanHolder, "BOTTOMLEFT", 0, -8)

	R.postBtn = UI:Button(ad, L["Werbung vorbereiten"], 300, 36, function() ns.Recruit:Post(); R:Refresh() end, true)
	R.postBtn:SetPoint("BOTTOMLEFT", 0, 4)
	-- GA2: fertiger Chat-Text direkt über dem Knopf
	R.postPreview = UI:Label(ad, "", "GameFontHighlightSmall")
	R.postPreview:SetPoint("BOTTOMLEFT", R.postBtn, "TOPLEFT", 0, 4)
	R.postPreview:SetWidth(740)
	R.postPreview:SetJustifyH("LEFT")
	R.postPreview:SetMaxLines(2)
	R.postStatus = UI:Label(ad, "", "GameFontHighlight")
	R.postStatus:SetPoint("LEFT", R.postBtn, "RIGHT", 14, 0)
	R.postStatus:SetWidth(440)

	-- Bewerber --------------------------------------------
	local apps = CreateFrame("Frame", nil, p)
	apps:SetPoint("TOPLEFT", 0, -34)
	apps:SetPoint("BOTTOMRIGHT")
	R.appsView = apps
	local STATUS = {
		new = GREEN .. L["neu"] .. "|r", invited = "|cff66b3ff" .. L["eingeladen"] .. "|r",
		declined = Gray(L["abgelehnt"]), joined = GOLD .. L["beigetreten"] .. "|r",
		agedecl = Gray(L["abgelehnt (Alter)"]),
	}
	-- eine Zeile der Bewerberliste (eigene Funktion, damit die Testroutine die Anzeige prüfen kann)
	function R.AppRender(x)
		local a = x.a
		local nq = #ns.Recruit:Questions()
		local qa = (a.qa and #a.qa > 0) and ((a.qdone and GREEN or "") .. #a.qa .. "/" .. nq .. (a.qdone and "|r" or "")) or (a.qi and Gray(L["fragt …"]) or Gray("–"))
		local st = STATUS[a.st] or a.st or ""
		if a.st == "new" and a.age == "unclear" then st = GOLD .. L["Alter unklar"] .. "|r" end
		-- G40-1 (a): wegen der Grenze für automatische Antworten nicht angeschrieben
		if a.st == "new" and a.noAuto then st = GOLD .. L["selbst anschreiben"] .. "|r" end
		-- Sperrliste (GS-N1 3) geht vor
		if ns.Lead and ns.Lead.Banned and ns.Lead:Banned(x.name) then st = "|cffff6060" .. L["auf Sperrliste"] .. "|r" end
		return { ns.Colored(x.name, a.c), a.c and ns.ClassName(a.c) or Gray("?"), a.msg or "", qa, Gray(ns.Ago(a.last or a.t)), st }
	end
	R.appList = UI:List(apps, {
		{ key = "name", title = L["Name"], width = 130 },
		{ key = "class", title = L["Klasse"], width = 90 },
		{ key = "msg", title = L["Nachricht"] },
		{ key = "qa", title = L["Antworten"], width = 80, align = "CENTER" },
		{ key = "t", title = L["Wann"], width = 90 },
		{ key = "st", title = L["Status"], width = 110 },   -- 110: "abgelehnt (Alter)", "selbst anschreiben" ganz sichtbar
	}, {
		key = function(x) return x.name end,
		render = function(x) return R.AppRender(x) end,
		onClick = function(x, button)
			R:UpdateAppButtons()
			if button == "RightButton" and x and x.name and ns.MemberMenu then ns.MemberMenu(x.name) end
		end,
		onEnter = function(row, x)
			ns.UI.TipOwner(row, "ANCHOR_CURSOR")
			GameTooltip:AddLine(ns.Colored(x.name, x.a.c))
			-- 0.9.59 L5 (T317): die Zahl (seit wann) gleich unter dem Namen, Nachricht und Antworten darunter (stand vorher als letzte Zeile)
			GameTooltip:AddLine(L["Erstmals: "] .. ns.Date(x.a.t), 0.7, 0.7, 0.7)
			if x.a.msg then GameTooltip:AddLine(x.a.msg, 1, 1, 1, true) end
			local ban = ns.Lead and ns.Lead.Banned and ns.Lead:Banned(x.name)
			if ban then
				GameTooltip:AddLine(string.format(L["Auf der Sperrliste: %s"], ban.r ~= "" and ban.r or L["ohne Grund"]), 1, 0.38, 0.38, true)
			end
			if x.a.noAuto then
				GameTooltip:AddLine(string.format(L["Nicht automatisch angeschrieben (höchstens %d automatische Antworten in %d Minuten) – bitte selbst anflüstern."],
					ns.Recruit.AUTO_MAX, ns.Recruit.AUTO_WINDOW / 60), 1, 0.82, 0, true)
			end
			for _, qa in ipairs(x.a.qa or {}) do
				GameTooltip:AddLine(qa.q, 1, 0.82, 0, true)
				GameTooltip:AddLine(qa.a, 1, 1, 1, true)
			end
			GameTooltip:Show()
		end,
		empty = L["Noch keine Bewerber. Wer dich mit einem Stichwort (z. B. 'gilde') anflüstert, landet hier."],
	})
	R.appList:SetPoint("TOPLEFT")
	R.appList:SetPoint("BOTTOMRIGHT", 0, 40)
	local function Sel() local x = R.appList:Selected(); return x and x.name end
	R.appInvite = UI:Button(apps, L["In die Gilde einladen"], 170, 28, function() local n = Sel(); if n then ns.Recruit:Invite(n) end end, true)
	R.appInvite:SetPoint("BOTTOMLEFT", 0, 4)
	R.appWhisper = UI:Button(apps, L["Anflüstern"], 120, 28, function() local n = Sel(); if n then ns.Recruit:Whisper(n) end end)
	R.appWhisper:SetPoint("LEFT", R.appInvite, "RIGHT", 8, 0)
	R.appDecline = UI:Button(apps, L["Ablehnen"], 110, 28, function() local n = Sel(); if n then ns.Recruit:SetStatus(n, "declined") end end)
	R.appDecline:SetPoint("LEFT", R.appWhisper, "RIGHT", 8, 0)
	R.appRemove = UI:Button(apps, L["Entfernen"], 110, 28, function()
		local n = Sel()
		if n then ns.Recruit:Remove(n); R.appList:ClearSelection() end
	end)
	R.appRemove:SetPoint("LEFT", R.appDecline, "RIGHT", 8, 0)
	local all = UI:Check(apps, L["Erledigte zeigen"], function() return R.showAll end, function(v) R.showAll = v; R:Refresh() end)
	all:SetPoint("BOTTOMRIGHT", -110, 8)

	-- Texte -----------------------------------------------
	local tx = CreateFrame("Frame", nil, p)
	tx:SetPoint("TOPLEFT", 0, -34)
	tx:SetPoint("BOTTOMRIGHT")
	R.textView = tx

	local c1 = UI:Check(tx, L["Bewerbern automatisch antworten"], function() return ns.db.autoReply end, function(v) ns.db.autoReply = v end)
	c1:SetPoint("TOPLEFT", 0, 0)
	R.replyEdit = UI:Edit(tx, 560, 60, ns.Recruit:DefaultReply(), true, 255)
	R.replyEdit:SetPoint("TOPLEFT", c1, "BOTTOMLEFT", 2, -4)
	R.replyEdit.onChange = function(t, user) if user then ns.db.replyText = t; R:TextPreviews() end end
	R.replyPrev = UI:Label(tx, "", "GameFontHighlightSmall")
	R.replyPrev:SetPoint("TOPLEFT", R.replyEdit, "BOTTOMLEFT", 0, -4)
	R.replyPrev:SetWidth(740)
	R.replyPh = R.PlaceholderButton(tx, { "spieler", "gilde", "discord" })
	R.replyPh:SetPoint("LEFT", c1.text, "RIGHT", 14, 0)   -- neben dem Schalter (rechts vom Feld verdeckten es dessen Tooltips, T182)

	local h5 = UI:Header(tx, L["Stichwörter für Bewerbungen (mit Komma getrennt)"])
	h5:SetPoint("TOPLEFT", R.replyPrev, "BOTTOMLEFT", -2, -18)
	R.kwEdit = UI:Edit(tx, 560, 24, ns.Recruit:DefaultKeywords())
	R.kwEdit:SetPoint("TOPLEFT", h5, "BOTTOMLEFT", 2, -6)
	R.kwEdit.onChange = function(t, user) if user then ns.db.keywords = t end end

	local c2 = UI:Check(tx, L["Neue Mitglieder im Gildenchat begrüßen"], function() return ns.db.welcome end, function(v) ns.db.welcome = v end)
	c2:SetPoint("TOPLEFT", R.kwEdit, "BOTTOMLEFT", -2, -22)
	R.welEdit = UI:Edit(tx, 560, 60, ns.Recruit:DefaultWelcome(), true, 255)
	R.welEdit:SetPoint("TOPLEFT", c2, "BOTTOMLEFT", 2, -4)
	R.welEdit.onChange = function(t, user) if user then ns.db.welcomeText = t; R:TextPreviews() end end
	R.welPrev = UI:Label(tx, "", "GameFontHighlightSmall")
	R.welPrev:SetPoint("TOPLEFT", R.welEdit, "BOTTOMLEFT", 0, -4)
	R.welPrev:SetWidth(740)
	local wh = UI:Label(tx, Gray(L["Haben mehrere das Addon, begrüßt nur einer."]), "GameFontHighlightSmall")
	wh:SetPoint("TOPLEFT", R.welPrev, "BOTTOMLEFT", 0, -8)
	R.welPh = R.PlaceholderButton(tx, { "spieler", "gilde", "discord" })
	R.welPh:SetPoint("LEFT", wh, "RIGHT", 10, 0)

	local c3 = UI:Check(tx, L["Bewerbungsfragen stellen (nach der automatischen Antwort, eine nach der anderen)"], function() return ns.db.askQuestions end, function(v) ns.db.askQuestions = v end)
	c3:SetPoint("TOPLEFT", wh, "BOTTOMLEFT", -2, -16)
	R.qEdit = UI:ScrollEdit(tx, 560, 80, 1200, ns.Recruit:DefaultQuestions())
	R.qEdit:SetPoint("TOPLEFT", c3, "BOTTOMLEFT", 2, -4)
	R.qEdit.onChange = function(t, user) if user then ns.db.questions = t end end
	local qh = UI:Label(tx, Gray(L["Eine Frage pro Zeile, höchstens 6. Die Antworten stehen beim Bewerber (Maus über den Namen)."]), "GameFontHighlightSmall")
	qh:SetPoint("LEFT", R.qEdit, "RIGHT", 10, 0)
	qh:SetWidth(170)
	-- GA1: Mindestalter (Altersfrage als letzte Frage), Absage-Text
	local ma = UI:Label(tx, L["Mindestalter (0 = aus):"], "GameFontNormalSmall")
	ma:SetPoint("TOPLEFT", R.qEdit, "BOTTOMLEFT", 0, -10)
	R.minAge = UI:Edit(tx, 40, 22, "16")
	R.minAge:SetPoint("LEFT", ma, "RIGHT", 6, 0)
	R.minAge.onChange = function(t, user)
		if not user then return end
		local n = tonumber(ns.Trim(t))
		if n and n >= 0 and n <= 99 then ns.db.minAge = math.floor(n) end
	end
	local mh = UI:Label(tx, Gray(L["Die Altersfrage kommt immer als letzte Frage. Gespeichert wird nur das Ergebnis, nie das Alter."]), "GameFontHighlightSmall")
	mh:SetPoint("LEFT", R.minAge, "RIGHT", 10, 0)
	mh:SetWidth(480)
	R.ageEdit = UI:Edit(tx, 560, 22, ns.Recruit:DefaultAgeReject())
	R.ageEdit:SetPoint("TOPLEFT", ma, "BOTTOMLEFT", 0, -8)
	R.ageEdit.onChange = function(t, user) if user then ns.db.ageRejectText = t end end
	-- 0.9.59: Hinweis und Platzhalter-Knopf UNTER dem Feld (rechts vom 560 breiten Feld ragte der Knopf aus dem Fenster, T319)
	local ah = UI:Label(tx, Gray(L["Absage unter dem Mindestalter."]), "GameFontHighlightSmall")
	ah:SetPoint("TOPLEFT", R.ageEdit, "BOTTOMLEFT", 0, -6)
	R.agePh = R.PlaceholderButton(tx, { "spieler", "gilde", "alter" })
	R.agePh:SetPoint("LEFT", ah, "RIGHT", 10, 0)
	-- GS-N1: "Abgeschlossene Bewerbungen nach 90 Tagen löschen" steht seit OPT-ALLE (18.11.) in den Optionen > Rekrutierung
	R.optBtn2 = ns.Options.Button(tx, "rekrut")
	R.optBtn2:SetPoint("LEFT", R.agePh, "RIGHT", 12, 0)   -- in derselben Zeile (darunter ragte er in esMX unten aus dem Fenster, T319)

	-- Gildenregeln ---------------------------------------
	local rv = CreateFrame("Frame", nil, p)
	rv:SetPoint("TOPLEFT", 0, -34)
	rv:SetPoint("BOTTOMRIGHT")
	R.rulesView = rv
	local rh = UI:Header(rv, L["Gildenregeln"])
	rh:SetPoint("TOPLEFT", 0, 0)
	R.rulesSub = UI:Label(rv, "", "GameFontHighlightSmall")
	R.rulesSub:SetPoint("LEFT", rh, "RIGHT", 12, 0)
	R.rulesEdit = UI:ScrollEdit(rv, 780, 300, ns.Rules.MAX, L["Hier die Gildenregeln eintragen – z. B. Umgangston, Loot, Raidtermine, Gildenbank, Discord."])
	R.rulesEdit:SetPoint("TOPLEFT", rh, "BOTTOMLEFT", 0, -8)
	R.rulesSave = UI:Button(rv, L["Speichern und an alle schicken"], 240, 28, function()
		UI:Confirm(L["Neue Fassung der Gildenregeln an alle schicken? Alle müssen sie dann neu bestätigen."], function()
			ns.Rules:Save(R.rulesEdit:GetText())
		end)
	end, true)
	R.rulesSave:SetPoint("TOPLEFT", R.rulesEdit, "BOTTOMLEFT", 0, -8)
	R.rulesShow = UI:Button(rv, L["Regeln anzeigen"], 150, 28, function() ns.Rules:ShowPopup(true) end)
	R.rulesShow:SetPoint("LEFT", R.rulesSave, "RIGHT", 8, 0)
	R.rulesStatus = UI:Label(rv, "", "GameFontHighlightSmall")
	R.rulesStatus:SetPoint("TOPLEFT", R.rulesSave, "BOTTOMLEFT", 0, -12)
	R.rulesStatus:SetWidth(780)
	R.rulesStatus:SetJustifyV("TOP")

	R.tabs:Select("ad")
end

function R:Preview()
	local text = ns.Recruit:AdText()
	-- unbekannte Platzhalter rot markieren, damit man sie vor dem Posten sieht
	local marked, bad = text:gsub("{(%w+)}", "|cffff4040{%1}|r")
	if self.postPreview then self.postPreview:SetText(Gray(L["Im Chat: "]) .. marked) end
	if self.adHint then
		local noW = ns.Recruit:OwnAdWithoutWhisper()
		local own = ns.Recruit:OwnAdWithoutWanted()
		local hint = noW and L["Dein Text sagt nicht, wie man sich meldet – „/w {name} gilde“ anhängen?"]
			or (own and L["Dein Text nennt die gesuchten Klassen nicht – {gesucht} einfügen oder Standardtext der Phase übernehmen"]) or nil
		self.adHint:SetText(hint and ("|cffffd100" .. hint .. "|r") or "")
		self.adAdopt:SetShown(hint ~= nil)
	end
	self.preview:SetText(marked .. (bad > 0 and ("\n|cffff4040" .. L["Unbekannter Platzhalter – wird so gepostet. Erlaubt: {gilde}, {fraktion}, {name}, {discord}, {tag}, {mitglieder}, {online}, {gesucht}, {phase}, {berufe}"] .. "|r") or ""))
	-- höchstens Rc.AD_MAX (Platz für "/<Kanal> " in der Chat-Eingabe); Länge VOR dem Kürzen zählen
	local raw = #ns.Recruit:AdRaw()
	local max = ns.Recruit.AD_MAX
	if raw > max then
		self.length:SetText(string.format("|cffff4040(%d/%d) %s|r", raw, max, L["wird gekürzt"]))
	else
		self.length:SetText(string.format("(%d/%d)", raw, max))
	end
end

function R:TextPreviews()
	self.replyPrev:SetText(Gray(L["Vorschau: "]) .. ns.Recruit:ReplyPreview())
	self.welPrev:SetText(Gray(L["Vorschau: "]) .. ns.Recruit:WelcomePreview())
end

function R:BuildChannels()
	for _, c in ipairs(self.chanChecks) do c:Hide() end
	local list = ns.Recruit:Joined()
	if #list == 0 then
		self.noChan = self.noChan or UI:Label(self.chanHolder, Gray(L["Du bist in keinem Chatkanal."]), "GameFontHighlightSmall")
		self.noChan:SetPoint("TOPLEFT", 0, -6)
		self.noChan:Show()
		return
	end
	if self.noChan then self.noChan:Hide() end
	for i, ch in ipairs(list) do
		local c = self.chanChecks[i]
		if not c then
			c = UI:Check(self.chanHolder, "", function() return c and c.short and ns.Recruit:IsTarget(c.short) end, function(v) if c and c.short then ns.Recruit:SetTarget(c.short, v) end end)
			self.chanChecks[i] = c
		end
		c.short = ch.short
		c.text:SetText(ch.id .. ". " .. ch.short)
		c:SetHitRectInsets(0, -(c.text:GetStringWidth() + 10), 0, 0)
		c:ClearAllPoints()
		local col, row = (i - 1) % 4, math.floor((i - 1) / 4)
		c:SetPoint("TOPLEFT", col * 185, -row * 24)
		c.Refresh()
		c:Show()
	end
end

function R:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	self.adView:SetShown(self.view == "ad")
	self.appsView:SetShown(self.view == "apps")
	self.textView:SetShown(self.view == "texts")
	self.rulesView:SetShown(self.view == "rules")
	local n = #ns.Recruit:Applicants()
	self.tabs:SetLabel("apps", n > 0 and string.format(L["Bewerber (%d)"], n) or L["Bewerber"])
	if self.view == "ad" then
		if not self.adEdit.edit:HasFocus() then self.adEdit:SetText(ns.db.adText or "") end
		if not self.discord.edit:HasFocus() then self.discord:SetText(ns.db.discord or "") end
		if not self.tag.edit:HasFocus() then self.tag:SetText(ns.db.discordTag or "") end
		self.rpLine:SetText(Gray(ns.RaidReady:ProgressText()))
		self:Preview()
		ns.Recruit:EnsureTargets()
		self:BuildChannels()
		self:UpdatePost()
	elseif self.view == "apps" then
		self.appList:SetData(ns.Recruit:Applicants(self.showAll))
		self:UpdateAppButtons()
	elseif self.view == "rules" then
		self:RefreshRules()
	else
		if not self.replyEdit.edit:HasFocus() then self.replyEdit:SetText(ns.db.replyText or "") end
		if not self.welEdit.edit:HasFocus() then self.welEdit:SetText(ns.db.welcomeText or "") end
		if not self.kwEdit.edit:HasFocus() then self.kwEdit:SetText(ns.db.keywords or "") end
		if not self.qEdit.edit:HasFocus() then self.qEdit:SetText(ns.db.questions or "") end
		if self.minAge and not self.minAge.edit:HasFocus() then self.minAge:SetText(tostring(ns.Recruit:MinAge())) end
		if self.ageEdit and not self.ageEdit.edit:HasFocus() then self.ageEdit:SetText(ns.db.ageRejectText or "") end
		self:TextPreviews()
	end
end

function R:RefreshRules()
	local Ru = ns.Rules
	local r = Ru:Current()
	local can = Ru:CanEdit()
	if not self.rulesEdit.edit:HasFocus() then self.rulesEdit:SetText(r.text or "") end
	self.rulesEdit:SetEnabled(can)
	self.rulesSave:SetEnabled(can)
	self.rulesShow:SetEnabled(Ru:HasRules())
	if Ru:HasRules() then
		self.rulesSub:SetText(Gray(string.format(L["Fassung %d · von %s · %s"], r.v, r.by or "?", ns.Date(r.t))))
		local yes, no = Ru:Status()
		local miss = {}
		for i, n in ipairs(no) do
			if i > 25 then miss[#miss + 1] = string.format(L["… und %d weitere"], #no - 25) break end
			local x = ns.Roster.byName[n]
			miss[#miss + 1] = ns.Colored(n, x and x.class)
		end
		self.rulesStatus:SetText(string.format(L["Bestätigt: %s%d|r von %d Spielern."], GREEN, #yes, #yes + #no)
			.. (#no > 0 and ("\n" .. L["Noch nicht bestätigt (ohne GuildSentinel geht das nicht): "] .. table.concat(miss, ", ")) or ""))
	else
		self.rulesSub:SetText(Gray(L["Noch keine Regeln."]))
		self.rulesStatus:SetText(Gray(L["Wer GuildSentinel hat, sieht die Regeln beim Einloggen und bestätigt sie mit einem Klick. Neue Mitglieder auch."]))
	end
	if not can then self.rulesStatus:SetText(self.rulesStatus:GetText() .. "\n" .. Gray(L["Nur Offiziere können die Gildenregeln ändern."])) end
end

function R:UpdatePost()
	local Rc = ns.Recruit
	local c, wait, soonest = Rc:NextTarget()
	local gw = Rc:GlobalWait()
	if #Rc:Targets() == 0 then
		self.postBtn:SetText(L["Werbung vorbereiten"])
		self.postBtn:Disable()
		self.postStatus:SetText(ORANGE .. L["Wähle oben mindestens einen Kanal."] .. "|r")
		return
	end
	if c and gw == 0 then
		self.postBtn:SetText(string.format(L["Vorbereiten für %s"], c.short))
		self.postBtn:Enable()
	else
		self.postBtn:SetText(L["Werbung vorbereiten"])
		self.postBtn:Disable()
	end
	local last = ns.db.lastAdTime or 0
	local status = last > 0 and (L["Zuletzt gepostet: "] .. ns.Ago(last)) or L["Heute noch nicht gepostet."]
	if not c and wait then status = status .. "  " .. string.format(L["Nächster Kanal in %d s"], wait)
	elseif gw > 0 then status = status .. "  " .. string.format(L["Bitte %d s warten"], gw) end
	if Rc:Due() then status = GOLD .. L["Wieder fällig! "] .. "|r" .. status end
	-- vorbereitet, aber noch nicht gesendet
	if Rc.prepared and GetTime() - Rc.prepared.t <= Rc.PREPARED_FOR then
		status = GOLD .. string.format(L["Steht im Chat für %s – mit Enter senden."], Rc.prepared.short) .. "|r\n" .. status
	end
	self.postStatus:SetText(status)
end

function R:UpdateAppButtons()
	local x = self.appList:Selected()
	local has = x ~= nil
	self.appInvite:SetEnabled(has and ns.CanInvite() and x.a.st ~= "joined" and x.a.st ~= "agedecl"
		and not (ns.Lead and ns.Lead.Banned and ns.Lead:Banned(x.name)))
	self.appWhisper:SetEnabled(has)
	self.appDecline:SetEnabled(has and x.a.st ~= "declined")
	self.appRemove:SetEnabled(has)
end

R.onShow = function(_, arg)
	-- OPT-ALLE: Verweise der Optionen öffnen jeden Reiter direkt (vorher nur "apps")
	if arg == "apps" or arg == "ad" or arg == "texts" or arg == "rules" then R.tabs:Select(arg) else R:Refresh() end
end
ns:Listen("GS_APPS", WhenShown("recruit", function() R:Refresh() end))
ns:Listen("GS_RULES", WhenShown("recruit", function() if R.view == "rules" then R:Refresh() end end))
ns:Listen("GS_RECRUIT", WhenShown("recruit", function() R:Refresh() end))
-- Countdown aktualisieren
C_Timer.NewTicker(1, function()
	if UI:IsPageShown("recruit") and R.view == "ad" then R:UpdatePost() end
end)
UI:AddPage(R)

------------------------------------------------------------
-- Seite: Berufe
------------------------------------------------------------
local P = { key = "prof", features = { "prof", "cooldowns" }, order = 40, icon = "Interface\\Icons\\Trade_BlackSmithing" }
P.title = N["Berufe"]
P.query = ""
P.selProf = nil

P.view = "dir"
P.reqMine = false

function P.build(p)
	P.panel = p
	P.tabs = UI:Tabs(p, {
		{ key = "dir", text = L["Verzeichnis"], feature = "prof" },
		{ key = "req", text = L["Nachfrage"], feature = "prof" },
		{ key = "gaps", text = L["Lücken"], feature = "prof" },
		{ key = "cd", text = L["Abklingzeiten"], feature = "cooldowns" },
	}, function(key) P.view = key; P:Refresh() end)
	P.tabs:SetPoint("TOPLEFT")
	P.tabs:SetPoint("TOPRIGHT")
	local root = p
	local dv = CreateFrame("Frame", nil, root)
	dv:SetPoint("TOPLEFT", 0, -34)
	dv:SetPoint("BOTTOMRIGHT")
	P.dirView = dv
	p = dv
	local search = UI:Edit(p, 320, 26, L["Rezept oder Item suchen, z. B. 'Feuerwiderstand'"])
	search:SetPoint("TOPLEFT")
	search.onChange = function(t) P.query = t; P:Refresh() end
	P.search = search

	P.mine = UI:Label(p, "", "GameFontHighlightSmall")
	P.mine:SetPoint("TOPLEFT", search, "BOTTOMLEFT", 0, -8)
	P.mine:SetWidth(520)
	P.mine:SetJustifyV("TOP")

	-- Platz für den sicheren Knopf "Nächsten Beruf einlesen" (liegt auf UIParent, siehe unten)
	P.slot = CreateFrame("Frame", nil, p)
	P.slot:SetSize(240, 28)
	P.slot:SetPoint("TOPRIGHT", 0, 0)
	P.slotHint = UI:Label(p, Gray(L["Oder: jedes Berufsfenster einmal selbst öffnen."]), "GameFontHighlightSmall")
	P.slotHint:SetPoint("TOPRIGHT", P.slot, "BOTTOMRIGHT", 0, -6)

	P.profList = UI:List(p, {
		{ key = "name", title = L["Beruf"] },
		{ key = "count", title = L["Wer"], width = 76, align = "RIGHT" },
	}, {
		key = function(x) return x.name end,
		-- bekannt "von" laut Gilden-Berufsliste des Spiels (wenn das Spiel mehr kennt als GuildSentinel)
		render = function(x) return { x.name, ns.Prof:CountText(x, Gray) } end,
		onEnter = function(row, x)
			if x.total and x.total > x.count then
				ns.UI.TipOwner(row, "ANCHOR_RIGHT")
				GameTooltip:AddLine(x.name)
				GameTooltip:AddLine(string.format(L["%d bekannt, %d laut Gilden-Berufsliste des Spiels."], x.count, x.total), 1, 1, 1, true)
				GameTooltip:Show()
			end
		end,
		onClick = function(x)
			P.selProf = x.name
			P.member, P.kind = nil, nil
			P.query = ""
			P.search:SetText("")
			P:Refresh()
		end,
		empty = L["Noch keine Berufe bekannt."],
	})
	P.profList:SetPoint("TOPLEFT", 0, -62)
	P.profList:SetPoint("BOTTOMLEFT", 0, 40)
	P.profList:SetWidth(210)

	P.results = UI:List(p, {
		{ key = "a", title = L["Rezept"] },
		{ key = "b", title = L["Wer"], width = 150 },
		{ key = "c", title = L["Beruf"], width = 120 },
		{ key = "d", title = L["Stufe"], width = 50, align = "CENTER" },
		{ key = "e", title = L["Status"], width = 90 },
	}, {
		key = function(x) return (x.recipe or "") .. "|" .. x.name end,
		render = function(x)
			local onlineChar = ns.Roster:OnlineChar(x.name)
			local status = onlineChar and (GREEN .. (onlineChar == x.name and L["online"] or (L["als "] .. onlineChar)) .. "|r") or Gray(L["offline"])
			if P.query ~= "" then
				return { x.recipe, ns.Colored(x.name, x.class), x.prof, tostring(x.rank or ""), status }
			end
			-- nur aus der Gilden-Berufsliste des Spiels (Stufe ohne Rezepte)
			local rec = x.g and Gray(L["Rezepte unbekannt"]) or string.format(L["%d Rezepte"], x.n or 0)
			return { rec, ns.Colored(x.name, x.class), P.selProf or "", tostring(x.r or ""), status }
		end,
		-- Klick auf ein Mitglied mit Rezepten: seine Rezeptliste für diesen Beruf (sonst nur auswählen zum Anflüstern)
		onClick = function(x)
			if P.query == "" and P.selProf and x and not x.recipe and (x.n or 0) > 0 then
				P:OpenMember(x.name)
				return
			end
			P:UpdateButtons()
		end,
		onEnter = function(row, x)
			if x.id and x.id > 0 then
				ns.UI.TipOwner(row, "ANCHOR_CURSOR")
				GameTooltip:SetHyperlink("item:" .. x.id)
				GameTooltip:Show()
			elseif not x.recipe and (x.n or 0) > 0 then
				ns.UI.TipOwner(row, "ANCHOR_CURSOR")
				GameTooltip:AddLine(L["Klicken: Rezepte anzeigen"], 1, 1, 1)
				GameTooltip:Show()
			end
		end,
		empty = L["Suche oben nach einem Rezept oder wähle links einen Beruf."],
	})
	P.results:SetPoint("TOPLEFT", P.profList, "TOPRIGHT", 10, 0)
	P.results:SetPoint("BOTTOMRIGHT", 0, 40)

	-- Rezepte eines Mitglieds: Zurück-Knopf, Filterleiste nach Art (bricht um), Liste
	local mv = CreateFrame("Frame", nil, p)
	mv:SetPoint("TOPLEFT", P.profList, "TOPRIGHT", 10, 0)
	mv:SetPoint("BOTTOMRIGHT", 0, 40)
	mv:Hide()
	P.memberView = mv
	P.back = UI:Button(mv, L["< Zurück"], 90, 22, function() P:CloseMember() end)
	P.back:SetPoint("TOPLEFT")
	P.memberTitle = UI:Label(mv, "", "GameFontNormal")
	P.memberTitle:SetPoint("LEFT", P.back, "RIGHT", 10, 0)
	P.memberTitle:SetPoint("RIGHT", mv, "RIGHT", 0, 0)
	P.memberTitle:SetJustifyH("LEFT")
	P.bar = CreateFrame("Frame", nil, mv)
	P.bar:SetPoint("TOPLEFT", P.back, "BOTTOMLEFT", 0, -6)
	P.bar:SetPoint("RIGHT", mv, "RIGHT", 0, 0)
	P.bar:SetHeight(22)
	P.bar.buttons = {}
	P.recipes = UI:List(mv, {
		{ key = "a", title = L["Rezept"] },
		{ key = "b", title = L["Art"], width = 150 },
	}, {
		key = function(x) return x.recipe .. "|" .. (x.kind or "") end,
		render = function(x) return { P.ItemCell(x.id, x.recipe), Gray(ns.Kinds.Label(x.kind)) } end,
		onClick = function() P:UpdateButtons() end,
		onEnter = function(row, x)
			if x.id and x.id > 0 then
				ns.UI.TipOwner(row, "ANCHOR_CURSOR")
				GameTooltip:SetHyperlink("item:" .. x.id)
				GameTooltip:Show()
			end
		end,
		empty = "",
	})
	P.recipes:SetPoint("TOPLEFT", P.bar, "BOTTOMLEFT", 0, -6)
	P.recipes:SetPoint("BOTTOMRIGHT", mv, "BOTTOMRIGHT", 0, 0)

	P.ask = UI:Button(p, L["Herstellen anfragen"], 180, 28, function()
		-- Rezeptliste eines Mitglieds: gewähltes Rezept anfragen, sonst das Mitglied anflüstern
		if P.member then
			local r = P.recipes:Selected()
			if r then ns.Prof:AskCraft(r) else ns.Recruit:Whisper(ns.Roster:OnlineChar(P.member) or P.member) end
			return
		end
		local x = P.results:Selected()
		if not x then return end
		if x.recipe then ns.Prof:AskCraft(x) else ns.Recruit:Whisper(ns.Roster:OnlineChar(x.name) or x.name) end
	end, true)
	P.ask:SetPoint("BOTTOMRIGHT", 0, 4)
	P.infoText = Gray(L["Die Liste füllt sich, wenn Gildenmitglieder mit GuildSentinel ihre Berufsfenster öffnen."])
	P.info = UI:Label(p, P.infoText, "GameFontHighlightSmall")
	P.info:SetPoint("BOTTOMLEFT", 0, 12)
	P.info:SetPoint("RIGHT", P.ask, "LEFT", -12, 0)

	P:BuildReq(root)
	P:BuildGaps(root)
	P:BuildCd(root)
	P.tabs:Select("dir")
end

local function ItemCell(id, name)
	if id and id > 0 then
		local n, _, q = ns.Item(id)
		local c = ITEM_QUALITY_COLORS and q and ITEM_QUALITY_COLORS[q]
		return (c and c.hex or "|cffffffff") .. (n or name or ("item:" .. id)) .. "|r"
	end
	return name or "?"
end

P.ItemCell = ItemCell       -- (die Rezeptliste eines Mitglieds in P.build ruft sie erst beim Zeichnen auf)

-- Rezeptliste eines Mitglieds öffnen/schliessen
function P:OpenMember(name)
	self.member, self.kind = name, nil
	self.recipes:ClearSelection()
	self:Refresh()
end
function P:CloseMember()
	self.member, self.kind = nil, nil
	self:Refresh()
end

-- Filterleiste: "Alle n" und je Art "Art n", nur Arten, die vorkommen; bricht um, wenn die Breite nicht reicht
P.BAR_H, P.BAR_GAP = 22, 4
function P:LayoutBar(kinds, counts, total)
	local bar = self.bar
	local items = { { key = nil, text = string.format("%s %d", L["Alle"], total) } }
	for _, k in ipairs(kinds) do items[#items + 1] = { key = k, text = string.format("%s %d", ns.Kinds.Label(k), counts[k] or 0) } end
	local width = bar:GetWidth()
	if not width or width < 50 then width = 420 end
	local x, y, rows = 0, 0, 1
	for i, it in ipairs(items) do
		local b = bar.buttons[i]
		if not b then
			b = UI:Button(bar, "", 60, self.BAR_H, function(btn) P.kind = btn.kindKey; P.recipes:ClearSelection(); P:Refresh() end)
			bar.buttons[i] = b
		end
		b.kindKey = it.key
		b:SetText(it.text)
		local w = math.ceil(b.text:GetStringWidth()) + 16
		if w > width then w = width end
		b:SetWidth(w)
		if x > 0 and x + w > width then
			x, y, rows = 0, y + self.BAR_H + self.BAR_GAP, rows + 1
		end
		b:ClearAllPoints()
		b:SetPoint("TOPLEFT", bar, "TOPLEFT", x, -y)
		b.lx, b.ly, b.lw = x, y, w           -- Lage für die Testroutine (Bereich K)
		-- gewählte Art hervorheben
		local sel = (self.kind == it.key)
		b.text:SetTextColor(sel and 1 or 0.85, sel and 0.82 or 0.85, sel and 0 or 0.85)
		b:Show()
		x = x + w + self.BAR_GAP
	end
	for i = #items + 1, #bar.buttons do bar.buttons[i]:Hide() end
	bar:SetHeight(rows * self.BAR_H + (rows - 1) * self.BAR_GAP)
	bar.rows, bar.lwidth = rows, width
	return #items, rows
end

-- Rezept-Nachfrage
function P:BuildReq(root)
	local v = CreateFrame("Frame", nil, root)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	self.reqView = v
	self.rItem = UI:Edit(v, 280, 24, L["Item-Name oder Shift-Klick auf ein Item"])
	self.rItem:SetPoint("TOPLEFT")
	UI:AcceptLinks(self.rItem)
	self.rCount = UI:Edit(v, 50, 24, "1")
	self.rCount:SetPoint("LEFT", self.rItem, "RIGHT", 6, 0)
	self.rCount.edit:SetNumeric(true)
	self.rNote = UI:Edit(v, 230, 24, L["Notiz (optional)"], false, 100)
	self.rNote:SetPoint("LEFT", self.rCount, "RIGHT", 6, 0)
	local add = UI:Button(v, L["Wunsch eintragen"], 170, 24, function() P:AddRequest() end, true)
	add:SetPoint("LEFT", self.rNote, "RIGHT", 8, 0)
	self.rItem.onEnter = function() P:AddRequest() end
	local mine = UI:Check(v, L["Nur was ich herstellen kann"], function() return P.reqMine end, function(val) P.reqMine = val; P:Refresh() end)
	mine:SetPoint("TOPLEFT", self.rItem, "BOTTOMLEFT", -2, -8)
	self.reqList = UI:List(v, {
		{ key = "item", title = L["Gewünscht"], icon = true },
		{ key = "c", title = L["Anzahl"], width = 55, align = "CENTER" },
		{ key = "by", title = L["Von"], width = 110 },
		{ key = "who", title = L["Wer kann es"], width = 150 },
		{ key = "st", title = L["Status"], width = 130 },
		{ key = "t", title = L["Wann"], width = 80 },
	}, {
		rowH = 22,
		key = function(r) return r.id end,
		icon = function(r) return (r.i or 0) > 0 and ns.ItemIcon(r.i) or nil end,
		render = function(r)
			local who = ns.Craft:WhoCanCraft(r.i, r.n)
			local whoText = #who == 0 and (ORANGE .. L["niemand"] .. "|r") or table.concat(who, ", ")
			if ns.Craft:CanICraft(r.i, r.n) then whoText = GREEN .. L["du"] .. "|r" .. (#who > 1 and (Gray(" +" .. (#who - 1))) or "") end
			local st
			if r.done then st = GREEN .. L["erledigt"] .. "|r"
			elseif r.taker then st = "|cff66b3ff" .. string.format(L["macht %s"], r.taker) .. "|r"
			else st = Gray(L["offen"]) end
			local note = (r.note and r.note ~= "") and Gray(" – " .. r.note) or ""
			return { ItemCell(r.i, r.n) .. note, tostring(r.c), r.by, whoText, st, Gray(ns.Ago(r.t)) }
		end,
		onClick = function() P:UpdateButtons() end,
		onEnter = function(row, r)
			if (r.i or 0) > 0 then
				ns.UI.TipOwner(row, "ANCHOR_CURSOR")
				GameTooltip:SetHyperlink("item:" .. r.i)
				GameTooltip:Show()
			end
		end,
		empty = L["Keine offenen Wünsche. Trag oben ein, was du hergestellt haben möchtest – die Handwerker der Gilde bekommen einen Hinweis."],
	})
	self.reqList:SetPoint("TOPLEFT", 0, -62)
	self.reqList:SetPoint("BOTTOMRIGHT", 0, 40)
	self.rTake = UI:Button(v, L["Übernehme ich"], 150, 28, function()
		local r = P.reqList:Selected()
		if r then ns.Craft:Take(r.id) end
	end, true)
	self.rTake:SetPoint("BOTTOMLEFT", 0, 4)
	self.rWhisper = UI:Button(v, L["Anflüstern"], 120, 28, function()
		local r = P.reqList:Selected()
		if not r then return end
		local to = ns.Same(r.by, ns.Me()) and r.taker or r.by
		if to then ns.Recruit:Whisper(ns.Roster:OnlineChar(to) or to) end
	end)
	self.rWhisper:SetPoint("LEFT", self.rTake, "RIGHT", 8, 0)
	self.rDone = UI:Button(v, L["Erledigt"], 110, 28, function()
		local r = P.reqList:Selected()
		if r then ns.Craft:Done(r.id) end
	end)
	self.rDone:SetPoint("LEFT", self.rWhisper, "RIGHT", 8, 0)
	self.rRemove = UI:Button(v, L["Entfernen"], 110, 28, function()
		local r = P.reqList:Selected()
		if r then ns.Craft:Remove(r.id); P.reqList:ClearSelection() end
	end)
	self.rRemove:SetPoint("LEFT", self.rDone, "RIGHT", 8, 0)
end

function P:AddRequest()
	local text = ns.Trim(self.rItem:GetText())
	if text == "" then return end
	local id = ns.FindItemID(text)
	local name = text:match("%[(.-)%]") or text
	ns.Craft:Request(id or 0, name or text, tonumber(self.rCount:GetText()) or 1, self.rNote:GetText())
	self.rItem:SetText("")
	self.rCount:SetText("")
	self.rNote:SetText("")
	self.rItem:ClearFocus()
end

-- Berufe-Lücken
function P:BuildGaps(root)
	local v = CreateFrame("Frame", nil, root)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	self.gapView = v
	self.gapSummary = UI:Label(v, "", "GameFontHighlight")
	self.gapSummary:SetPoint("TOPLEFT", 0, -4)
	self.gapSummary:SetWidth(780)
	self.gapList = UI:List(v, {
		{ key = "item", title = L["Wichtiges Rezept"], icon = true },
		{ key = "prof", title = L["Beruf"], width = 130 },
		{ key = "who", title = L["Wer kann es"], width = 300 },
	}, {
		rowH = 22,
		key = function(x) return x.i end,
		icon = function(x) return ns.ItemIcon(x.i) end,
		render = function(x)
			local who = #x.who == 0 and (ORANGE .. L["niemand"] .. "|r") or (GREEN .. table.concat(x.who, ", ") .. "|r")
			return { ItemCell(x.i, x.name) .. (x.custom and Gray(L[" (ergänzt)"]) or ""), x.prof, who }
		end,
		onClick = function() P:UpdateButtons() end,
		onEnter = function(row, x)
			ns.UI.TipOwner(row, "ANCHOR_CURSOR")
			GameTooltip:SetHyperlink("item:" .. x.i)
			GameTooltip:Show()
		end,
	})
	self.gapList:SetPoint("TOPLEFT", 0, -28)
	self.gapList:SetPoint("BOTTOMRIGHT", 0, 40)
	self.gItem = UI:Edit(v, 280, 26, L["Weiteres Rezept: Shift-Klick auf das Item"])
	self.gItem:SetPoint("BOTTOMLEFT", 0, 6)
	UI:AcceptLinks(self.gItem)
	self.gAdd = UI:Button(v, L["Beobachten"], 120, 26, function()
		local id = ns.FindItemID(P.gItem:GetText())
		if id then if ns.Craft:Watch(id) then P.gItem:SetText("") end else ns:Print(L["Item nicht gefunden – bitte per Shift-Klick einfügen."]) end
	end)
	self.gAdd:SetPoint("LEFT", self.gItem, "RIGHT", 8, 0)
	self.gRemove = UI:Button(v, L["Nicht mehr beobachten"], 180, 26, function()
		local x = P.gapList:Selected()
		if x and x.custom then ns.Craft:Unwatch(x.i); P.gapList:ClearSelection() end
	end)
	self.gRemove:SetPoint("BOTTOMRIGHT", 0, 6)
end

-- Abklingzeiten
function P:BuildCd(root)
	local v = CreateFrame("Frame", nil, root)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	self.cdView = v
	self.cdInfo = UI:Label(v, "", "GameFontHighlightSmall")
	self.cdInfo:SetPoint("TOPLEFT", 0, -4)
	self.cdInfo:SetWidth(780)
	self.cdList = UI:List(v, {
		{ key = "name", title = L["Abklingzeit"] },
		{ key = "who", title = L["Wer"], width = 150 },
		{ key = "ready", title = L["Bereit"], width = 110 },
		{ key = "val", title = L["Marktwert"], width = 120, align = "RIGHT" },
		{ key = "on", title = L["Status"], width = 80 },
	}, {
		key = function(x) return x.who .. x.key end,
		render = function(x)
			local ready = x.isReady and (GREEN .. ns.Cooldowns:ReadyText(x) .. "|r") or Gray(ns.Cooldowns:ReadyText(x))
			local val = x.value and ns.Money(x.value) or Gray("–")
			return { x.name, ns.Colored(x.who, x.class), ready, val, x.online and (GREEN .. L["online"] .. "|r") or Gray(L["offline"]) }
		end,
		onClick = function() P:UpdateButtons() end,
		empty = L["Noch keine Abklingzeiten bekannt. Wer Transmutation, Mondstoff oder einen Salzstreuer hat, meldet sie mit GuildSentinel automatisch."],
	})
	self.cdList:SetPoint("TOPLEFT", 0, -24)
	self.cdList:SetPoint("BOTTOMRIGHT", 0, 40)
	self.cdAsk = UI:Button(v, L["Anfragen"], 140, 28, function()
		local x = P.cdList:Selected()
		if x then ns.Cooldowns:Ask(x) end
	end, true)
	self.cdAsk:SetPoint("BOTTOMRIGHT", 0, 4)
	self.cdRescan = UI:Button(v, L["Meine neu lesen"], 150, 28, function() ns.Cooldowns:Scan(true) end)
	self.cdRescan:SetPoint("BOTTOMLEFT", 0, 4)
end

-- sicherer Knopf: öffnet per Klick das nächste Berufsfenster (CastSpellByName dürfen Addons nicht)
function P:SecureButton()
	if self.sb then return self.sb end
	local tpl = "SecureActionButtonTemplate" .. (UI.BACKDROP and ("," .. UI.BACKDROP) or "")
	local b = CreateFrame("Button", "GuildSentinelProfButton", UIParent, tpl)
	b:SetSize(240, 28)
	b:SetFrameStrata("DIALOG")
	UI.Box(b, A[1] * 0.45, A[2] * 0.45, A[3] * 0.45, 1, A[1], A[2], A[3], 0.9)
	b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	b.text:SetPoint("CENTER")
	local hl = b:CreateTexture(nil, "HIGHLIGHT")
	hl:SetPoint("TOPLEFT", 1, -1)
	hl:SetPoint("BOTTOMRIGHT", -1, 1)
	hl:SetTexture(UI.WHITE)
	hl:SetVertexColor(1, 1, 1, 0.08)
	b:RegisterForClicks("AnyUp", "AnyDown")
	b:SetAttribute("type", "spell")
	b:SetScript("PreClick", function(self)
		if ns.InCombat() then return end
		local nxt = ns.Prof:NextToOpen()
		if not nxt then
			ns.Prof.scanned = {}
			nxt = ns.Prof:NextToOpen()
		end
		self:SetAttribute("spell", nxt)
		ns.Prof.announce = true
	end)
	b:SetScript("PostClick", function(self)
		local want = self:GetAttribute("spell")
		-- Forever: öffnet der Zauber das Berufsfenster nicht, nur einen Hinweis geben. C_TradeSkillUI.OpenTradeSkill
		-- ist dort geschützt – aus einem Timer aufgerufen meldet das Spiel "Aktion blockiert" (Launch-Bericht 0.9.13).
		if ns.Game.MODERN_PROFESSIONS and want then
			C_Timer.After(0.8, function()
				if not ns.Prof.TradeWindowShown() then
					ns:Print(string.format(L["%s ging nicht auf – bitte den Beruf einmal selbst öffnen (Zauberbuch oder Berufe-Fenster)."], want))
				end
			end)
		end
		C_Timer.After(1, function() P:UpdateSecure() end)
	end)
	b:Hide()
	self.sb = b
	return b
end

function P:UpdateSecure()
	if ns.InCombat() then return end
	local b = self:SecureButton()
	local shown = self.panel and self.panel:IsVisible() and UI:IsPageShown("prof") and self.view == "dir"
	if not shown then
		b:Hide()
		b:ClearAllPoints()
		return
	end
	local list = ns.Prof:Openable()
	if #list == 0 then
		b:Hide()
		self.slotHint:SetText(Gray(L["Keine Berufe mit Rezeptfenster gelernt."]))
		return
	end
	local nxt = ns.Prof:NextToOpen() or list[1]
	b.text:SetText(string.format(L["%s einlesen"], nxt))
	b:ClearAllPoints()
	b:SetPoint("TOPRIGHT", self.slot, "TOPRIGHT")
	b:Show()
	self.slotHint:SetText(Gray(L["Oder: jedes Berufsfenster einmal selbst öffnen."]))
end

ns:On("PLAYER_REGEN_DISABLED", function()
	-- vor dem Kampf verstecken (im Kampf dürfte man sichere Knöpfe nicht mehr anfassen)
	if P.sb then P.sb:Hide(); P.sb:ClearAllPoints() end
end)
ns:On("PLAYER_REGEN_ENABLED", function() P:UpdateSecure() end)

function P:MineText()
	local me = ns.Prof:Of(ns.Me())
	if not me or not me.p or not next(me.p) then
		return ORANGE .. L["Deine Berufe sind noch nicht eingelesen."] .. "|r"
	end
	local t = {}
	for prof, x in pairs(me.p) do
		local n = x.n and #x.n or 0
		t[#t + 1] = prof .. " " .. (x.r or "?") .. (n > 0 and Gray(" (" .. n .. ")") or "")
	end
	table.sort(t)
	return L["Deine Berufe: "] .. table.concat(t, ", ")
end

function P:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	self.dirView:SetShown(self.view == "dir")
	self.reqView:SetShown(self.view == "req")
	self.gapView:SetShown(self.view == "gaps")
	self.cdView:SetShown(self.view == "cd")
	local open = ns.Craft:OpenCount()
	self.tabs:SetLabel("req", open > 0 and string.format(L["Nachfrage (%d)"], open) or L["Nachfrage"])
	if self.view == "cd" then
		local list = ns.Cooldowns:List()
		self.cdList:SetData(list)
		local ready = 0
		for _, x in ipairs(list) do if x.isReady and x.online then ready = ready + 1 end end
		self.cdInfo:SetText(Gray(string.format(L["%d Abklingzeiten bekannt, %d gerade bereit und online."], #list, ready))
			.. (ns.Links:Loaded("AHAnalyzerPro") and "" or ("  " .. Gray(L["Mit AH Analyzer Pro steht der Marktwert dabei."]))))
		self:UpdateButtons()
		self:UpdateSecure()
		return
	elseif self.view == "req" then
		self.reqList:SetData(ns.Craft:Requests(self.reqMine))
		self:UpdateButtons()
		self:UpdateSecure()
		return
	elseif self.view == "gaps" then
		local gaps = ns.Craft:Gaps()
		local missing = 0
		for _, x in ipairs(gaps) do if #x.who == 0 then missing = missing + 1 end end
		self.gapList:SetData(gaps)
		local b = ns.Craft:WantedText()
		self.gapSummary:SetText(string.format(L["%d von %d wichtigen Rezepten kann in der Gilde niemand herstellen."], missing, #gaps)
			.. (b ~= "" and ("  " .. Gray(L["Für die Werbung ({berufe}): "]) .. GREEN .. b .. "|r") or ""))
		self:UpdateButtons()
		self:UpdateSecure()
		return
	end
	self.mine:SetText(self:MineText())
	local profs = ns.Prof:ProfNames()
	self.profList:SetData(profs)
	local more
	-- Rezeptliste eines Mitglieds (Suchfeld filtert in seiner Liste)
	self.memberView:SetShown(self.member ~= nil)
	self.results:SetShown(self.member == nil)
	if self.member and self.selProf then
		local rows, counts, kinds, total = ns.Prof:MemberRecipes(self.member, self.selProf, self.kind, self.query)
		if self.kind and not counts[self.kind] then
			self.kind = nil
			rows, counts, kinds, total = ns.Prof:MemberRecipes(self.member, self.selProf, nil, self.query)
		end
		self.memberTitle:SetText(ns.Colored(self.member, (ns.Prof:Of(self.member) or {}).c) .. Gray(" · " .. self.selProf))
		self:LayoutBar(kinds, counts, total)
		local any = select(4, ns.Prof:MemberRecipes(self.member, self.selProf, nil, nil)) > 0
		self.recipes:SetEmpty(any and L["Keine passenden Rezepte."] or ns.Prof:MemberEmpty(self.member))
		self.recipes:SetData(rows)
		self.info:SetText(self.infoText)
		self:UpdateButtons()
		self:UpdateSecure()
		return
	end
	if self.query ~= "" then
		self.profList:ClearSelection()
		self.results:SetEmpty(L["Suche oben nach einem Rezept oder wähle links einen Beruf."])
		self.results:SetData(ns.Prof:Find(self.query))
		self.ask:SetText(L["Herstellen anfragen"])
	else
		-- Leertext je nach Zustand: Beruf gewählt, aber noch niemand mit Daten -> wie viele laut Spiel
		local list, empty
		list, empty, more = ns.Prof:DirView(self.selProf)
		self.results:SetEmpty(empty)
		self.results:SetData(list)
		if self.selProf then self.ask:SetText(L["Anflüstern"]) end
	end
	self.info:SetText(more and Gray(more) or self.infoText)
	ns.Prof:TellView()
	self:UpdateButtons()
	self:UpdateSecure()
end

function P:UpdateButtons()
	if self.member then
		local r = self.recipes:Selected()
		self.ask:SetText(r and L["Herstellen anfragen"] or L["Anflüstern"])
		self.ask:SetEnabled(true)
	else
		self.ask:SetEnabled(self.results:Selected() ~= nil)
	end
	local r = self.reqList and self.reqList:Selected()
	if self.rTake then
		local open = r and not r.done
		self.rTake:SetEnabled(open and not r.taker and not ns.Same(r.by, ns.Me()) and true or false)
		self.rWhisper:SetEnabled(r ~= nil and (not ns.Same(r.by, ns.Me()) or r.taker ~= nil))
		self.rDone:SetEnabled(open and ns.Craft:CanEdit(r) and true or false)
		self.rRemove:SetEnabled(r ~= nil and ns.Craft:CanEdit(r))
	end
	if self.cdAsk then
		local x = self.cdList:Selected()
		self.cdAsk:SetEnabled(x ~= nil and not ns.Same(x.who, ns.Me()))
	end
	if self.gRemove then
		local x = self.gapList:Selected()
		self.gRemove:SetEnabled(x ~= nil and x.custom and true or false)
	end
end

P.onShow = function(_, arg)
	if type(arg) == "string" and arg ~= "" then
		P.tabs:Select("dir")
		P.search:SetText(arg)
		P.query = arg
	end
	P:Refresh()
end
P.badge = function()
	local n = 0
	for _, r in ipairs(ns.Craft:Requests(true)) do if not r.taker then n = n + 1 end end
	return n > 0 and (GREEN .. n .. "|r") or ""
end
P.onHide = function() P:UpdateSecure() end
ns:Listen("GS_HIDE", function() P:UpdateSecure() end)
ns:Listen("GS_PROF", WhenShown("prof", function() P:Refresh() end))
ns:Listen("GS_CRAFT", WhenShown("prof", function() P:Refresh() end))
ns:Listen("GS_CD", WhenShown("prof", function() if P.view == "cd" then P:Refresh() end end))
ns:Listen("GS_ITEMS", WhenShown("prof", function() if P.view ~= "dir" then P:Refresh() end end))
ns:Listen("GS_CRAFT", function() UI:RefreshHeader() end)
ns:Listen("GS_ROSTER", WhenShown("prof", function() P.results:Draw() end))
UI:AddPage(P)

------------------------------------------------------------
-- Seite: Einstellungen
------------------------------------------------------------
local S = { key = "settings", noGuild = true, order = 90, icon = "Interface\\Icons\\INV_Misc_Gear_01" }
ns.SettingsPage = S
S.title = N["Einstellungen"]

function S.build(root)
	S.panel = root
	-- Reiter: Optionen, Testmodus (OPT-ALLE 18.11.: "Allgemein" und "Funktionen" sind jetzt EIN Optionen-Fenster mit Bereichen links,
	-- Suche oben, einer Spalte rechts – Options.lua; gespeichert wird in denselben Feldern wie vorher)
	S.tabs = UI:Tabs(root, {
		{ key = "gen", text = L["Optionen"] },
		{ key = "test", text = L["Testmodus"], feature = "dev" },
	}, function(key) S.view = key; S:ShowView() end)
	S.tabs:SetPoint("TOPLEFT", 0, 0)
	S.tabs:SetPoint("TOPRIGHT", 0, 0)
	local function View()
		local f = CreateFrame("Frame", nil, root)
		f:SetPoint("TOPLEFT", 0, -38)
		f:SetPoint("BOTTOMRIGHT", 0, 0)
		f:Hide()
		return f
	end
	S.gen, S.test = View(), View()
	S:BuildTest(S.test)
	ns.Options:Build(S.gen)
end

-- Testmodus
function S:BuildTest(p)
	local h = UI:Header(p, L["Testmodus"])
	h:SetPoint("TOPLEFT", 0, 0)
	local info = UI:Label(p, Gray(L["Der Testmodus füllt GuildSentinel mit einer erfundenen Gilde: Mitglieder mit Twinks, Zonen, Angebote am Brett, Termine, Abklingzeiten, Dank-Punkte, Meilensteine, eine Gruppensuche und eine Umfrage. Im Testmodus wird nichts gesendet – kein Addon-Abgleich, kein Gildenchat, kein Flüstern, keine Einladung. Was sonst in den Chat ginge, steht mit [Test] in deinem Chatfenster. Beim Ausschalten sind deine echten Daten unverändert wieder da."]), "GameFontHighlightSmall")
	info:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -6)
	info:SetWidth(760)
	info:SetJustifyV("TOP")
	S.testBtn = UI:Button(p, "", 200, 30, function()
		if ns.Test:Active() then ns.Test:Stop() else ns.Test:Start() end
	end, true)
	S.testBtn:SetPoint("TOPLEFT", info, "BOTTOMLEFT", 0, -14)
	S.testRun = UI:Button(p, L["Alles durchklicken"], 180, 30, function() ns.Test:RunAll() end)
	S.testRun:SetPoint("LEFT", S.testBtn, "RIGHT", 8, 0)
	UI.Tip(S.testRun, L["Alles durchklicken"], L["Öffnet jede Seite und jeden Reiter einmal und löst alle Ereignisse aus. Fehler stehen danach im Chat."])
	-- Testroutine (TestRoutine.lua): alle Prüfungen mit Bericht – gleiche Wirkung wie /gs testroutine
	S.testRoutine = UI:Button(p, L["Alles testen"], 160, 30, function() if ns.Routine then ns.Routine:Slash("") end end)
	S.testRoutine:SetPoint("LEFT", S.testRun, "RIGHT", 8, 0)
	UI.Tip(S.testRoutine, L["Alles testen"], L["Prüft alle Funktionen und schreibt einen Bericht (Kopierfenster). Nichts wird gesendet, deine echten Daten bleiben unverändert."])
	S.testState = UI:Label(p, "", "GameFontHighlight")
	S.testState:SetPoint("LEFT", S.testRoutine, "RIGHT", 12, 0)

	local h2 = UI:Header(p, L["Ereignisse auslösen"])
	h2:SetPoint("TOPLEFT", S.testBtn, "BOTTOMLEFT", 0, -20)
	S.testEvBtns = {}
	for i, ev in ipairs(ns.Test.EVENTS) do
		local b = UI:Button(p, L[ev.n], 240, 26, function() ns.Test:Trigger(ev.key) end)
		local col, row = (i - 1) % 3, math.floor((i - 1) / 3)
		b:SetPoint("TOPLEFT", h2, "BOTTOMLEFT", col * 250, -8 - row * 32)
		S.testEvBtns[#S.testEvBtns + 1] = b
	end
	-- Diagnose: welcher Spielclient, welches Berufsfenster
	S.testDiag = UI:Label(p, "", "GameFontHighlightSmall")
	S.testDiag:SetPoint("TOPLEFT", h2, "BOTTOMLEFT", 0, -16 - math.ceil(#ns.Test.EVENTS / 3) * 32)
end

function S:DiagText()
	local G = ns.Game
	local client = G.FOREVER and "WoW Forever" or (G.TBC and "TBC Classic / Anniversary" or "Classic Era")
	local line = string.format(L["Spielclient: %s (%d) · Berufsfenster: %s"], client, G.toc, ns.Prof:WindowKind())
	-- gemeinsame Erkennung (GoldSentinelGame): Spielversion, API, geschützte Werte – wie /gsgame
	if GoldSentinelGame and GoldSentinelGame.Status then line = line .. "\n" .. GoldSentinelGame.Status() end
	-- abgefangene Fehler (Fehlerzähler) mit den letzten drei Meldungen
	local e = ns.errors or { n = 0, last = {} }
	line = line .. "\n" .. string.format(L["Fehler: %d"], e.n)
	for i = 1, math.min(3, #e.last) do line = line .. "\n  " .. tostring(e.last[i].wo) .. ": " .. tostring(e.last[i].msg) end
	return line
end

function S:ShowView()
	local v = self.view or "gen"
	self.gen:SetShown(v == "gen")
	self.test:SetShown(v == "test")
	if v == "gen" then ns.Options:Layout() end
	self:Refresh()
end

function S:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	local active = ns.Test:Active()
	self.testBtn:SetText(active and L["Testmodus beenden"] or L["Testmodus starten"])
	if self.testDiag then self.testDiag:SetText(Gray(self:DiagText())) end
	self.testState:SetText(active and (ORANGE .. L["Testmodus läuft – nichts wird gesendet."] .. "|r") or Gray(L["aus"]))
	for _, b in ipairs(self.testEvBtns) do b:SetEnabled(active) end
	ns.Options:Refresh()
end

-- arg: "test" = Testmodus; "gen" = Optionen; "feat" / "feat:<Funktion>" = Bereich der Funktionen (alte Aufrufe);
-- "opt:<Bereich>" = dieser Bereich (Optionen-Knöpfe anderer Seiten)
S.onShow = function(_, arg)
	local O = ns.Options
	if type(arg) == "string" and arg:find("^opt:") then
		O.sec = arg:sub(5); arg = "gen"
	elseif arg == "feat" then
		O.sec = "funk1"; arg = "gen"
	elseif type(arg) == "string" and arg:find("^feat:") then
		O.sec = O.SectionOfFeature(arg:sub(6)); arg = "gen"
	end
	if arg == "gen" and O.search then O.search:SetText("") end
	S.tabs:Select(arg or S.view or "gen")
end
ns:Listen("GS_USERS", WhenShown("settings", function() S:Refresh() end))
ns:Listen("GS_TEST", WhenShown("settings", function() S:Refresh() end))
ns:Listen("GS_FEATURES", WhenShown("settings", function() S:Refresh() end))
UI:AddPage(S)
