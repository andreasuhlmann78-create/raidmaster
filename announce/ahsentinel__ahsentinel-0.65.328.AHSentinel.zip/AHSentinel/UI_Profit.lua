if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.7 - Tab "Profit"
--   links:  Flipping-Rechner
--   rechts: Schnäppchen - wahlweise
--           * unter dem Marktwert (Median 14 Tage),
--           * unter dem Händlerpreis (kaufen, beim NPC verkaufen = sicherer Gewinn), oder
--           * unter dem Entzauberungswert (kaufen und entzaubern)
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local CreateFrame, C_Timer = A.OwnCreateFrame or CreateFrame, A.OwnTimer or C_Timer      -- VS-BILD-2 (0.65.320): eigene Skripte/Zeitgeber je Bild messen (nur während einer Vollscan-Messung)
local L = A.L
local UI = A.UI
local C = UI.C


-- Farbcodes entfernen (HP-2: graue Zeile für alte Preise)
local function NoColor(t)
    return (tostring(t or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
end

local function BuildProfit(parent)
    local p = CreateFrame("Frame", nil, parent)
    p.threshold = 20
    -- HP-4 (Nutzer 14.11. 10:42): Ansichten "Marktwert" und "Flips" ausgeblendet -> Standard ist "Unter Händlerpreis"
    p.mode = "vendor"     -- "vendor", "de", "bid" (sichtbar); "market"/"flip" nur noch im Hintergrund (Tests, Lernen)

    -- ---------------- Rechner ----------------
    local calc = CreateFrame("Frame", nil, p)
    -- UI-CLEAN1-B (UI-Prüfung: "Frame 300×500 ragt aus Reiter profit 932×480 unten 20 px", Modern): Höhe folgt dem Reiter
    calc:SetPoint("TOPLEFT", 0, 0)
    calc:SetPoint("BOTTOMLEFT", 0, 0)
    calc:SetWidth(300)
    UI:Box(calc, C.panel, C.border)

    local ct = UI:Label(calc, L["Flipping-Rechner"], "GameFontNormalLarge", C.text)
    ct:SetPoint("TOPLEFT", 14, -12)
    local cs = UI:Label(calc, L["Billig kaufen, teurer wieder einstellen.\nPreise pro Stück in Gold, Silber und Kupfer."], "GameFontDisableSmall", C.textDim)
    cs:SetPoint("TOPLEFT", ct, "BOTTOMLEFT", 0, -6)

    local function field(labelText, placeholder, y)
        local l = UI:Label(calc, labelText, "GameFontHighlightSmall", C.textDim)
        l:SetPoint("TOPLEFT", 14, y)
        local e = UI:EditBox(calc, 130, 22, placeholder)
        e:SetPoint("TOPRIGHT", -14, y + 4)
        e:SetScript("OnTextChanged", function() p:Calculate() end)
        e:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
        return e
    end

    -- Preise in Gold / Silber / Kupfer
    local function moneyField(labelText, y)
        local l = UI:Label(calc, labelText, "GameFontHighlightSmall", C.textDim)
        l:SetPoint("TOPLEFT", 14, y)
        local m = UI:MoneyInput(calc, function() p:Calculate() end)
        m:SetPoint("TOPRIGHT", -14, y + 4)
        m:SetOnEnter(function(self) self:ClearFocus() end)
        return m
    end
    p.buyBox = moneyField(L["Einkaufspreis"], -76)
    p.sellBox = moneyField(L["Verkaufspreis"], -106)
    p.qtyBox = field(L["Menge"], "1", -136)
    p.feeBox = field(L["AH-Gebühr in %"], "5", -166)

    local line = calc:CreateTexture(nil, "ARTWORK")
    line:SetColorTexture(unpack(C.border))
    line:SetPoint("TOPLEFT", 14, -200)
    line:SetPoint("TOPRIGHT", -14, -200)
    line:SetHeight(1)

    local function resultRow(labelText, y)
        local l = UI:Label(calc, labelText, "GameFontHighlightSmall", C.textDim)
        l:SetPoint("TOPLEFT", 14, y)
        local v = UI:Label(calc, "-", "GameFontHighlight", C.text)
        v:SetPoint("TOPRIGHT", -14, y)
        v:SetJustifyH("RIGHT")
        return v
    end
    p.rCost = resultRow(L["Einkauf gesamt"], -214)
    p.rGross = resultRow(L["Verkauf brutto"], -238)
    p.rFee = resultRow(L["AH-Gebühr"], -262)
    p.rProfit = resultRow(L["Gewinn"], -292)
    p.rMargin = resultRow(L["Marge"], -316)

    local note = UI:Label(calc, A:IsForever()
        and L["Hinweis: WoW Forever - beim Verkauf 5 % (neutrales AH 15 %),\ndie Einzahlung kommt beim Verkauf zurück.\nKaufen und Einstellen machst du selbst im AH."]
        or L["Hinweis: Die Einstellgebühr (Deposit) ist nicht\nenthalten. Kaufen und Einstellen machst du\nselbst im Auktionshaus."], "GameFontDisableSmall", C.textDim)
    note:SetPoint("BOTTOMLEFT", 14, 14)

    function p:Calculate()
        local buy = self.buyBox:GetCopper()
        local sell = self.sellBox:GetCopper()
        local qty = tonumber(self.qtyBox:GetText()) or 1
        local feeText = (self.feeBox:GetText() or ""):gsub(",", ".")
        local fee = tonumber(feeText) or 5
        if not buy or not sell or qty <= 0 then
            for _, v in ipairs({ self.rCost, self.rGross, self.rFee, self.rProfit, self.rMargin }) do v:SetText("-") end
            return
        end
        local cost = buy * qty
        local gross = sell * qty
        local feeAmount = gross * fee / 100
        -- Gebühren klassisch (auch Forever): beim Verkauf nur die 5 %, kein Minimum (die Einzahlung kommt zurück)
        local profit = gross - feeAmount - cost
        self.rCost:SetText(A:FormatMoney(cost))
        self.rGross:SetText(A:FormatMoney(gross))
        self.rFee:SetText(A:FormatMoney(feeAmount))
        self.rProfit:SetText(profit >= 0 and A:FormatMoney(profit) or ("|cffff5544" .. L["Verlust|r "] .. A:FormatMoney(profit)))
        self.rMargin:SetText(A:FormatPercent(cost > 0 and (profit / cost * 100) or nil))
    end

    -- ---------------- Schnäppchen ----------------
    local right = CreateFrame("Frame", nil, p)
    right:SetPoint("TOPLEFT", calc, "TOPRIGHT", 14, 0)
    right:SetPoint("BOTTOMRIGHT", 0, 0)

    local rt = UI:Label(right, L["Schnäppchen"], "GameFontNormalLarge", C.text)
    rt:SetPoint("TOPLEFT", 0, -3)         -- UI-CLEAN1 (D): Titel mittig zu den 22 px hohen Knöpfen, die oben bündig stehen

    -- Umschalter: unter Marktwert / unter Händlerpreis
    p.marketBtn = UI:Button(right, L["Unter Marktwert"], 130, 22, function()
        p.mode = "market"
        p:Refresh()
    end)
    p.marketBtn:SetPoint("TOPLEFT", rt, "TOPRIGHT", 16, 3)    -- UI-CLEAN1 (D): oben bündig im Bereich (vorher 9 px darüber)
    p.marketBtn.tooltip = L["Items, die gerade deutlich unter ihrem Marktwert (Median 14 Tage) angeboten werden"]
    p.vendorBtn = UI:Button(right, L["Unter Händlerpreis"], 140, 22, function()
        p.mode = "vendor"
        p:Refresh()
    end)
    p.vendorBtn:SetPoint("TOPLEFT", rt, "TOPRIGHT", 16, 3)    -- HP-4: erster sichtbarer Knopf an der Stelle von "Marktwert"
    p.deBtn = UI:Button(right, L["Unter Entzauberwert"], 150, 22, function()
        p.mode = "de"
        p:Refresh()
    end)
    p.deBtn:SetPoint("LEFT", p.vendorBtn, "RIGHT", 6, 0)
    p.deBtn.tooltip = L["Grüne/blaue/epische Ausrüstung, die billiger ist als ihr Entzauberungswert\n(Ø Ertrag an Staub, Essenzen und Splittern nach AH-Gebühr - Richtwerte)."]
    p.vendorBtn.tooltip = L["Items, die im Auktionshaus billiger sind, als ein Händler dafür zahlt.\nKaufen und beim Händler verkaufen = sicherer Gewinn."]
    p.bidBtn = UI:Button(right, L["Gebote"], 90, 22, function()
        p.mode = "bid"
        p:Refresh()
    end)
    p.bidBtn:SetPoint("LEFT", p.deBtn, "RIGHT", 6, 0)
    p.flipBtn = UI:Button(right, L["Flips"], 70, 22, function()
        p.mode = "flip"
        p:Refresh()
    end)
    p.flipBtn:SetPoint("LEFT", p.bidBtn, "RIGHT", 6, 0)
    p.flipBtn.tooltip = L["Flip-Empfehlungen: Items, die regelmäßig angeboten werden und gerade\ndeutlich unter Marktwert liegen - kaufen und wieder einstellen lohnt sich.\nSterne = Umschlag (wie oft das Item im Auktionshaus ist und verkauft wird)."]
    p.bidBtn.tooltip = L["Auktionen, deren nächstes Gebot weit unter dem Marktwert liegt.\nGesammelt beim Komplett-Scan (klassisches Auktionshaus) und bei jeder Suche im Einkauf.\nKlick auf ein Item: im Einkauf öffnen und dort bieten."]

    -- HP-4 (Nutzer 14.11. 10:42 "so bringt das nichts"): "Marktwert" und "Flips" rechnen gegen den Median der ANGEBOTSpreise,
    -- Gewinn/Tag ist nicht gemessen -> Knöpfe ausgeblendet (wie MR1 "Flippen"). Rechnung und Daten bleiben (Lernen, Testbericht,
    -- Tests über die versteckten Knöpfe). Zurück erst, wenn der Rechenkern echte Verkäufe je Item misst (MARKT-KERN-Grenzen).
    p.marketBtn:Hide(); p.flipBtn:Hide()
    p.hiddenViews = { market = true, flip = true }

    -- TB184-U3: Ansichten für die UI-Prüfung (nur Umschalten, kein Kauf) - nur die sichtbaren (HP-4)
    for _, x in ipairs({ { p.vendorBtn, "vendor", L["Unter Händlerpreis"] }, { p.deBtn, "de", L["Unter Entzauberwert"] },
        { p.bidBtn, "bid", L["Gebote"] } }) do
        local mode = x[2]
        x[1].uiaView, x[1].uiaActive = x[3], function() return p.mode == mode end
    end

    p.subtitle = UI:Label(right, "", "GameFontDisableSmall", C.textDim)
    p.subtitle:SetPoint("TOPLEFT", rt, "BOTTOMLEFT", 0, -6)
    p.subtitle:SetWidth(600)

    p.thresholdLabel = UI:Label(right, L["Mindestens unter Marktwert:"], "GameFontHighlightSmall", C.textDim)
    p.thresholdLabel:SetPoint("TOPLEFT", 0, -44)
    p.thresholdButtons = {}
    local prev = p.thresholdLabel
    for _, value in ipairs({ 10, 20, 30, 50 }) do
        local b = UI:Button(right, value .. "%", 50, 22, function()
            p.threshold = value
            p:Refresh()
        end)
        b:SetPoint("LEFT", prev, "RIGHT", 6, 0)
        b.value = value
        table.insert(p.thresholdButtons, b)
        prev = b
    end
    -- unsichere Marktwerte (selten angeboten, Mondpreise) sind normalerweise ausgeblendet
    p.unsureBtn = UI:Button(right, L["auch unsichere"], 120, 22, function()
        p.showUnsure = not p.showUnsure
        p:Refresh()
    end)
    p.unsureBtn:SetPoint("LEFT", prev, "RIGHT", 16, 0)
    p.unsureBtn.tooltip = L["Normal ausgeblendet: Items, die selten angeboten werden oder sich kaum verkaufen -\nihr 'Marktwert' sind oft nur Mondpreise einzelner Angebote. Klick: trotzdem zeigen."]

    p.table = UI:Table(right, {
        columns = {
            { key = "name", title = L["Item"], width = 170 },                    -- UI-CLEAN1 (D, 0.65.328): Zahlen-Spalten schmaler, Namen +62 px
            { key = "price", title = L["Sofortkauf"], width = 82, align = "RIGHT",
              tooltip = L["Günstigster Sofortkaufpreis im Auktionshaus beim letzten Scan"] },
            { key = "ref", title = L["Marktwert"], width = 82, align = "RIGHT" },
            { key = "discount", title = L["darunter"], width = 48, align = "RIGHT" },
            { key = "profit", title = L["Gewinn/Stück"], width = 82, align = "RIGHT" },
            { key = "dayProfit", title = L["Gewinn/Tag"], width = 82, align = "RIGHT",
              tooltip = L["Erwarteter Gewinn pro Tag: Gewinn pro Stück x wie viel sich pro Tag verkauft (geschätzt aus den Scans)"] },
        },
        rows = 16,
        rowHeight = 22,
        sortKey = "dayProfit",
        sortAsc = false,
        cell = function(item, key)
            local v
            if key == "name" then v = UI.ItemName(item)
            elseif key == "discount" and item.vendorDeal then
                -- HP-2: in "Händlerpreis" zeigt diese Spalte die Menge (Stücke unter dem Händlerpreis; "≥" = mindestens)
                v = (item.atLeast and "≥ " or "") .. tostring(item.quantity or 1)
            elseif key == "discount" then v = string.format("|cff33dd55-%.0f%%|r", item.discount)
            elseif key == "dayProfit" then v = item.dayProfit and A:FormatMoney(math.floor(item.dayProfit)) or "-"
            else v = A:FormatMoney(item[key]) end
            -- HP-2: Preise älter als 30 Min. grau
            if item.stale and key ~= "name" then v = "|cff888888" .. NoColor(v) .. "|r" end
            return v
        end,
        sortValue = function(item, key)
            if key == "name" then return string.lower(UI.ItemName(item)) end
            return item[key]
        end,
        onClick = function(item)
            if item.bidDeal then
                -- Gebot: im Einkauf öffnen, dort bieten
                if UI.OpenBuyFor then UI:OpenBuyFor(item.itemID) end
                return
            end
            p.buyBox:SetCopper(item.price)
            p.sellBox:SetCopper(item.ref)
            p.feeBox:SetText((item.vendorDeal or item.deDeal) and "0" or "5")
            p:Calculate()
        end,
        action = {
            text = "+", width = 26,
            tooltip = L["Händlerpreis: als Sniper-Ziel (kauft alles unter dem Händlerpreis)\nEntzauberwert: als Sniper-Ziel bis \"Lohnt bis\" (Menge und Budget wie geplant)\nGebote: zur Watchlist"],
            onClick = function(item)
                if item.deDeal then
                    -- HP-3: wie Markt > Entzaubern "Kaufen": Max = "Lohnt bis", Menge und Budget aus der Planung (vorher
                    -- Max = Wert − 1c, also ohne Gewinn); kauft selbst nichts
                    if item.deRow and A.MarketView and A.MarketView.BuyDE then A.MarketView:BuyDE(item.deRow) end
                elseif item.vendorDeal then
                    -- HP-2: Max/Stück = Händlerpreis − 1c (nie ≥ Händlerpreis, SK1-o), Menge = die Stücke unter dem Händlerpreis,
                    -- Budget = Σ ihrer Preise (vorher Menge über ALLE Preisstufen und Budget = Max × Menge)
                    -- Ohne genaue Stufen ("≥"): Menge unbekannt -> alles unter dem Händlerpreis, höchstens die angebotene Gesamtmenge
                    -- (max. 1000), Budget = Max × Menge; jedes Stück bringt beim Händler sicher Gewinn (Kauf nie ≥ Händlerpreis)
                    -- Budget nie über der Item-Grenze (je Item 10 % des Golds, Entscheid Supervisor 21:48)
                    local maxPrice, qty, budget = A:VendorTargetPlan(item.itemID, item.ref, item.quantity, item.cost, item.atLeast)
                    if not maxPrice then
                        A:Print(L["Kein Sniper-Ziel: dein Budget je Item (10 % des Golds) reicht nicht für ein Stück."])
                        return
                    end
                    local _, msg = A.Sniper:SetTarget(tostring(item.itemID), maxPrice, qty, budget)
                    A:Print(msg)
                else
                    local _, msg = A.Watchlist:Add(tostring(item.itemID), item.price, math.floor(item.ref))
                    A:Print(msg)
                end
            end,
        },
        emptyText = L["Keine Schnäppchen gefunden.\nDafür braucht es Scans über mehrere Tage."],
    })
    p.table:Fill(0, -76, 0, 4)

    -- Schnäppchen unter dem Marktwert (mind. 3 Preise in den letzten 14 Tagen)
    local function MarketDeals(threshold)
        local out = {}
        local limit = time() - A.MARKET_DAYS * 86400
        for itemID in pairs(A.db.marketData) do
            A:Pause()
            local price = A:GetCurrent(itemID)
            local mv = A:GetMarketValue(itemID)
            if price and mv and mv > 0 then
                local n = 0
                local F, nF = A:HF(itemID)
                for i = nF, 1, -1 do
                    if F[(i - 1) * 5 + 1] < limit or n >= 3 then break end
                    if F[(i - 1) * 5 + 5] % 2 == 0 then n = n + 1 end
                end
                local discount = (mv - price) / mv * 100
                if n >= 3 and discount >= threshold then
                    table.insert(out, {
                        itemID = itemID, name = A:GetItemName(itemID),
                        price = price, ref = mv, discount = discount,
                        profit = A:NetSale(itemID, A:RealPrice(itemID, { noCurrent = true }) or mv, 1) - price - A:ExpectedDepositLoss(itemID, 1),
                    })
                end
            end
        end
        return out
    end

    -- Schnäppchen unter dem Händlerpreis (nur aktuelle Preise)
    local function VendorDeals()
        local out = {}
        -- HP-2: EINE Rechnung (A:VendorDeals): Menge = Stücke unter dem Händlerpreis je Preisstufe, Gewinn gesamt = Σ über
        -- genau diese Stücke, Alter der Daten am Namen (älter als 30 Min. grau)
        for _, d in ipairs(A:FindVendorDeals()) do
            local mins = math.floor((d.age or 0) / 60)
            table.insert(out, {
                itemID = d.itemID, price = d.price, ref = d.vendor,
                -- Name fest (noLiveName), sonst ersetzte UI.ItemName ihn ohne das Alter
                name = (A:GetItemName(d.itemID) or d.name or ("#" .. d.itemID)) .. A:QualityTierMarkup(d.itemID)
                    .. "  |cffaaaaaa(" .. string.format(L["vor %d Min."], mins) .. ")|r", noLiveName = true,
                discount = d.pct, profit = d.profit, quantity = d.quantity, total = d.total, cost = d.cost,
                atLeast = d.atLeast, age = d.age, stale = (d.age or 0) > 1800, vendorDeal = true,
            })
        end
        return out
    end

    -- Schnäppchen unter dem Entzauberungswert (nur aktuelle Preise)
    -- HP-3 (Nutzer 10:36): dieselbe Regel und dieselben Treffer wie Markt > Entzaubern (MV:BuildDE = MV:DEOffer: "Lohnt bis"
    -- aus dem Rechenkern, Mindestgewinn, Preisleiter, Absatz der Materialien, Budget). Eine Zahl für beide Ansichten.
    local function DisenchantDeals()
        local out = {}
        local MV = A.MarketView
        if not (MV and MV.BuildDE) then return out end
        for _, r in ipairs(MV:BuildDE()) do
            local net, avg = r.net or 0, r.avg or r.price or 0
            table.insert(out, {
                itemID = r.itemID, name = A:GetItemName(r.itemID) or ("#" .. r.itemID), price = r.price, ref = net,
                discount = net > 0 and (net - avg) / net * 100 or 0, profit = math.floor((r.unitGold or 0) + 0.5),
                quantity = r.qty, total = r.profit or 0, deDeal = true, deRow = r,
            })
        end
        return out
    end

    local function mark(b, on, text)
        b:SetText(on and ("> " .. text .. " <") or text)
        -- Breite an den (übersetzten) Text anpassen
        local fs = b.label or (b.GetFontString and b:GetFontString())
        local w = fs and fs.GetStringWidth and fs:GetStringWidth()
        if w and w > 0 then b:SetWidth(math.max(80, math.floor(w + 22))) end
    end

    -- Restzeit eines Gebots (bezogen auf jetzt)
    local function BidTime(e)
        local left = (e.endsBy or 0) - time()
        if left < 1800 then return "|cffff5544" .. L["< 30 Min."] .. "|r" end
        if left < 7200 then return "|cffffcc33" .. L["< 2 Std."] .. "|r" end
        if left < 43200 then return L["< 12 Std."] end
        return L["> 12 Std."]
    end

    local function FlipDeals(threshold)
        local out = A.Extras:GetFlipDeals(threshold)
        for _, d in ipairs(out) do
            d.name = d.name .. "  |cffffd100" .. string.rep("*", d.stars or 1) .. "|r"
        end
        return out
    end

    local function BidDeals(threshold)
        local out = A:GetBidDeals(threshold)
        for _, d in ipairs(out) do
            d.name = d.name .. "  |cffaaaaaa(" .. BidTime(d) .. "|cffaaaaaa)|r"
        end
        return out
    end

    function p:Refresh()
        local mode = self.mode
        local vendor, de, bid, flip = (mode == "vendor"), (mode == "de"), (mode == "bid"), (mode == "flip")
        -- kurze Namen, damit fünf Ansichten in eine Zeile passen (Erklärung im Tooltip)
        mark(self.marketBtn, mode == "market", L["Marktwert"])
        mark(self.vendorBtn, vendor, L["Händlerpreis"])
        mark(self.deBtn, de, L["Entzauberwert"])
        mark(self.bidBtn, bid, L["Gebote"])
        mark(self.flipBtn, flip, L["Flips"])
        -- Vergleichswert-Spalte je nach Modus benennen (über den Schlüssel, nicht die Position)
        for _, hb in ipairs(self.table.headerCells) do
            if hb.col.key == "price" then
                hb.col.title = bid and L["Nächstes Gebot"] or L["Sofortkauf"]
                hb.col.tooltip = bid and L["So viel musst du mindestens bieten (pro Stück)"] or L["Günstigster Sofortkaufpreis im Auktionshaus beim letzten Scan"]
            end
            if hb.col.key == "dayProfit" then        -- HP-3: Entzaubern zeigt den Gewinn der geplanten Menge (wie Markt > Entzaubern)
                hb.col.title = (de or vendor) and L["Gewinn gesamt"] or L["Gewinn/Tag"]
                hb.col.tooltip = (de and L["Gewinn für die geplante Menge – dieselbe Zahl wie in Markt > Entzaubern"])
                    or (vendor and L["Gewinn über alle Stücke unter dem Händlerpreis: Σ (Händlerpreis − Stückpreis)"])
                    or L["Erwarteter Gewinn pro Tag: Gewinn pro Stück x wie viel sich pro Tag verkauft (geschätzt aus den Scans)"]
            end
            if hb.col.key == "discount" then         -- HP-2: in "Händlerpreis" die Menge
                hb.col.title = vendor and L["Menge"] or L["darunter"]
                hb.col.tooltip = vendor and L["Stücke unter dem Händlerpreis (genau je Preisstufe; ≥ = mindestens, genaue Stufen fehlen)"] or nil
            end
            if hb.col.key == "ref" then
                hb.col.title = (vendor and L["Händlerpreis"]) or (de and L["Entzauberwert"]) or L["Marktwert"]
                hb.col.tooltip = (vendor and L["Was ein Händler für das Item zahlt"])
                    or (de and L["Wert beim Entzaubern: tatsächlicher Ø aus echten Entzauberungen (ab 10), sonst geschätzt (Tabelle).\nWelcher Wert gilt, steht im Item-Tooltip."])
                    or L["Marktwert = Median der letzten 14 Tage"]
            end
        end
        for _, b in ipairs(self.thresholdButtons) do
            if mode ~= "market" and mode ~= "bid" and mode ~= "flip" then b:Hide() else b:Show() end
            b.label:SetTextColor(unpack(b.value == self.threshold and C.accent or C.text))
        end
        if vendor then
            self.thresholdLabel:Hide()
            self.subtitle:SetText(L["Im Auktionshaus billiger als beim Händler (Preise der letzten 2 Std.).\n+ = Sniper-Ziel anlegen, das alle diese Angebote kauft."])
        elseif flip then
            self.thresholdLabel:Show()
            self.subtitle:SetText(L["Kaufen und wieder einstellen: regelmäßig angeboten, gerade günstig, Gewinn nach AH-Anteil.\nSterne = Umschlag. Sortiert nach erwartetem Gewinn."])
        elseif bid then
            self.thresholdLabel:Show()
            self.subtitle:SetText(L["Gebote weit unter dem Marktwert (Restzeit in Klammern). Wer bietet, gewinnt erst am Ende der Auktion.\nKlick auf ein Item: im Einkauf öffnen und bieten."])
        elseif de then
            self.thresholdLabel:Hide()
            self.subtitle:SetText(L["Billiger als der Entzauber-Wert, mit Mindestgewinn - dieselbe Liste wie Markt > Entzaubern (Preise der letzten 2 Std.).\n+ = Sniper-Ziel bis \"Lohnt bis\" mit geplanter Menge und Budget."])
        else
            self.thresholdLabel:Show()
            self.subtitle:SetText(L["Items, die aktuell deutlich unter ihrem Marktwert liegen (Median 14 Tage, mind. 3 Preise)."])
        end
        -- TB125-4: der Reiter rechnet nie beim Öffnen - Liste im Hintergrund (Portionen), sofort den letzten Stand zeigen
        local threshold, showUnsure = self.threshold, self.showUnsure
        local function compute()
            local out = {}
            if vendor then out = VendorDeals() elseif de then out = DisenchantDeals()
            elseif bid then out = BidDeals(threshold)
            elseif flip then out = FlipDeals(threshold) else out = MarketDeals(threshold) end
            -- unglaubwürdige Gewinne (1000 % und mehr, Mondpreise, kaum verkauft) nicht anzeigen
            -- HP-3: Entzaubern nicht nochmals filtern (sonst andere Treffer als Markt > Entzaubern; DEOffer prüft selbst)
            -- HP-2: Händlerpreis ebenso (EINE Rechnung mit "Heute tun"/Markt; Schutz = bestätigter, plausibler Händlerpreis)
            if not (de or vendor) then out = A:WithoutAbsurd(out, showUnsure) end
            -- Gewinn pro Tag: was sich wirklich dreht, steht oben
            for _, d in ipairs(out) do
                A:Pause()
                if d.vendorDeal then
                    d.dayProfit = d.total or ((d.profit or 0) * math.max(1, d.quantity or 1))   -- HP-2: Gewinn gesamt (genau je Stufe)
                elseif d.deDeal then
                    d.dayProfit = d.total or 0          -- HP-3: Gewinn der geplanten Menge (wie Markt > Entzaubern), Spalte "Gewinn gesamt"
                elseif d.itemID then
                    d.dayProfit = A:ProfitPerDay(d.itemID, d.profit, d.quantity, d.price)
                end
            end
            return out
        end
        local out, ready = {}, true
        if A.db then
            self.cacheName = "profit:" .. tostring(mode) .. ":" .. tostring(threshold) .. ":" .. tostring(showUnsure and 1 or 0)
            local v
            v, ready = A:CachedValue(self.cacheName, A:DataVersion(), compute, false, true)
            out = v or {}
        end
        if self.table.empty then
            -- HP-3: Grund je Ansicht (vorher immer "braucht Scans über mehrere Tage", auch wenn es 10 Tage Scans gab)
            local why
            if not ready and #out == 0 then why = L["Wird berechnet ..."]
            elseif de then why = (A.MarketView and A.MarketView.DEEmptyText) and A.MarketView:DEEmptyText() or nil
            elseif vendor then why = L["Zurzeit nichts im Auktionshaus billiger als beim Händler (Preise der letzten 2 Std.)."] end
            self.table.empty:SetText(why or L["Keine Schnäppchen gefunden.\nDafür braucht es Scans über mehrere Tage."])
        end
        self.unsureBtn:SetText(self.showUnsure and ("> " .. L["auch unsichere"] .. " <") or L["auch unsichere"])
        if vendor or de then self.unsureBtn:Hide() else self.unsureBtn:Show() end
        self.table:SetData(out, true)
        self:Calculate()
    end

    return p
end

UI:RegisterTab("profit", "Profit", 5, BuildProfit)
-- TB125-4: fertige Hintergrund-Rechnung -> sichtbaren Reiter neu zeichnen (nur Anzeige)
A:On("CACHE_UPDATED", function(name)
    if type(name) ~= "string" or name:sub(1, 7) ~= "profit:" then return end
    local tab = UI:GetTab("profit")
    local p = tab and tab.panel
    if p and p.IsShown and p:IsShown() and p.cacheName == name and p.Refresh then pcall(p.Refresh, p) end
end)
