local _, ns = ...

-- Prüfliste im Spiel (Entscheid des Nutzers 16.11.2026 06:47, Auftrag PRÜFLISTE IM SPIEL; Form TR-ALLE 17.11.2026 07:36):
-- die Punkte, die nur im echten Spiel prüfbar sind. Alles, was ohne Hand geht, läuft in "/ps testroutine alles" (Punkt 1).
-- Jeder Punkt: Wo · Schritte (ein Handgriff je Schritt, Namen wie im Spiel) · Was du siehst · Kosten. Wo das Addon es messen
-- kann, merkt es den Punkt selbst (ns.PLHit an der Stelle, wo die Funktion wirklich benutzt wurde); sonst "OK"/"Nicht OK".
-- Nur im Entwicklermodus (GoldSentinelDev); für Spieler wirkungslos. Gemeinsamer Baustein: GoldSentinelPruefliste.lua (shared/).

local PLMOD = {}
ns.PrueflisteMod = PLMOD

-- Wo / Schritte / Kosten stehen in "todo", Was du siehst in "expect" (das Fenster zeigt "Das tust du" / "Das musst du sehen").
local function Todo(where, steps, cost)
    local out = { "Wo: " .. where }
    for i, s in ipairs(steps) do out[#out + 1] = i .. ". " .. s end
    out[#out + 1] = "Kosten: " .. cost
    return table.concat(out, "\n")
end
PLMOD.Todo = Todo

-- opening the profession window: two actions, two steps
local OPEN_P = "Drücke die Taste P – das Zauberbuch öffnet sich."
local OPEN_ICON = "Klicke im Zauberbuch auf das Symbol deines Berufs (Reiter „Allgemein“)."

PLMOD.POINTS = {
    { id = "TR", title = "Automatische Prüfung laufen lassen", since = "0.9.63",
      todo = Todo("irgendwo, nicht im Kampf", {
          OPEN_P,
          OPEN_ICON,
          "Tippe in den Chat: /ps testroutine alles",
          "Warte, bis im Chat „Testroutine fertig“ steht. Nicht kämpfen, Spiel offen lassen.",
      }, "kein Gold, ca. 1 Minute"),
      expect = "Im Chat: „Testroutine fertig: …“ und darunter „Ergebnis: … von … bestanden · 0 Fehler · …“. Der Punkt hakt sich selbst ab." },
    { id = "OFFEN", title = "Fenster öffnet mit dem Beruf", since = "0.9.47",
      todo = Todo("irgendwo", {
          OPEN_P,
          OPEN_ICON,
      }, "kein Gold, 10 Sekunden"),
      expect = "Rechts neben dem Berufsfenster erscheint das Fenster „ProfessionSentinel“, ohne dass du etwas klickst. Hakt sich selbst ab." },
    { id = "STIL", title = "Aussehen des dunklen Stils", since = "0.9.47",
      todo = Todo("Berufsfenster offen", {
          "Schau dir das Fenster „ProfessionSentinel“ an: oben die Reiter Jetzt · Skillen · Gold · Rezepte.",
          "Klicke jeden der vier Reiter einmal an.",
      }, "kein Gold, 1 Minute"),
      expect = "Dunkler, flacher Hintergrund, nichts abgeschnitten oder überlappt. Gefällt es dir: „OK“. Sonst „Nicht OK“ (zurück zum alten Aussehen: /ps stil)." },
    { id = "WECHSEL", title = "Berufswechsel merkt den Reiter", since = "0.9.49",
      todo = Todo("eine Figur mit zwei Berufen", {
          "Öffne den ersten Beruf (Taste P, Symbol des Berufs).",
          "Klicke im Fenster „ProfessionSentinel“ auf den Reiter „Gold“.",
          "Öffne den zweiten Beruf.",
          "Klicke dort auf den Reiter „Skillen“.",
          "Öffne wieder den ersten Beruf.",
      }, "kein Gold, 1 Minute"),
      expect = "Beim ersten Beruf ist sofort wieder „Gold“ gewählt, ohne dass kurz der andere Beruf aufblitzt. Hakt sich selbst ab; blitzt etwas auf: „Nicht OK“." },
    { id = "JETZT", title = "Karte „Nächster Skillpunkt“ anklicken", since = "0.9.47",
      todo = Todo("Berufsfenster offen", {
          "Klicke im Fenster „ProfessionSentinel“ auf den Reiter „Jetzt“.",
          "Klicke auf die Karte „Nächster Skillpunkt“.",
      }, "kein Gold, 10 Sekunden"),
      expect = "Im Berufsfenster ist genau dieses Rezept ausgewählt. Hakt sich selbst ab." },
    { id = "WEG", title = "Weg zum Lehrer zeigen", since = "0.9.57",
      todo = Todo("irgendwo draussen (nicht in einer Instanz)", {
          "Klicke im Fenster „ProfessionSentinel“ auf den Reiter „Skillen“.",
          "Klicke darunter auf „Lehrer“.",
          "Klicke auf den ersten Lehrer der Liste.",
      }, "kein Gold, 10 Sekunden"),
      expect = "Im Chat: „Wegpunkt gesetzt: <Name> – <Ort>“ mit (LevelPilot) oder (TomTom); ohne beide ein Punkt auf der Karte. Hakt sich selbst ab." },
    { id = "SPUR", title = "Skillspur im Berufsfenster", since = "0.9.54",
      todo = Todo("Berufsfenster offen", {
          "Schau auf die Rezeptliste im Berufsfenster von Blizzard (links).",
          "Fahre mit der Maus über eine Rezeptzeile.",
      }, "kein Gold, 30 Sekunden"),
      expect = "Unter jeder Rezeptzeile eine feine Linie, rechts eine Zahl (orange = sichere Punkte, gelb/grün = Chance in %). Nichts verdeckt Namen oder Anzahl. Passt es: „OK“." },
    { id = "VORMERKEN", title = "Rezept vormerken", since = "0.9.52",
      todo = Todo("Berufsfenster offen", {
          "Klicke im Fenster „ProfessionSentinel“ auf den Reiter „Rezepte“.",
          "Klicke auf ein gelerntes Rezept – unten öffnen sich die Details.",
          "Klicke unten auf „Vormerken“.",
      }, "kein Gold, 20 Sekunden"),
      expect = "Im Chat: „Vorgemerkt: 1× <Rezept>“, unten die Leiste „Warteschlange 1 · …“. Hakt sich selbst ab." },
    { id = "HAENDLER", title = "Fehlendes beim Händler kaufen", since = "0.9.52",
      todo = Todo("bei einem Händler für Handwerkswaren (z. B. Faden, Phiolen) – vorgemerktes Rezept aus Punkt „Rezept vormerken“", {
          "Sprich den Händler an (Rechtsklick), sein Fenster ist offen.",
          "Klicke im Fenster „ProfessionSentinel“ unten auf die Leiste „Warteschlange …“.",
          "Klicke auf „Fehlendes beim Händler kaufen“.",
      }, "wenige Silber (nur was dem vorgemerkten Rezept fehlt), 1 Minute"),
      expect = "Genau die fehlende Menge kommt in deine Taschen, nicht mehr. Hakt sich selbst ab (Zahl der Käufe in der Notiz)." },
    { id = "ESL1", title = "AHS-Liste anlegen", since = "0.9.63",
      todo = Todo("Berufsfenster offen, AHSentinel ist an", {
          "Klicke im Fenster „ProfessionSentinel“ auf den Reiter „Rezepte“.",
          "Klicke auf ein gelerntes Rezept – unten öffnen sich die Details.",
          "Klicke unten mit LINKS auf „AHS-Liste“.",
          "Klicke danach mit RECHTS auf „AHS-Liste“.",
      }, "kein Gold, 30 Sekunden"),
      expect = "Im Chat je eine Meldung von AHSentinel, dass die Einkaufsliste angelegt ist (rechts: nur was dir fehlt). Hakt sich selbst ab." },
    { id = "WARN", title = "Warnfenster mit drei Knöpfen", since = "0.9.60",
      todo = Todo("Berufsfenster offen", {
          "Tippe in den Chat: /ps warnprobe",
          "Lies das Fenster – es ist nur eine Probe, es wird nichts hergestellt.",
          "Klicke im Fenster auf „Abbrechen“.",
      }, "kein Gold, 20 Sekunden"),
      expect = "Ein Ton, ein Fenster „PROBE – Verlust! …“ mit drei Knöpfen: „Trotzdem herstellen“, „Stattdessen: …“, „Abbrechen“; Text vollständig lesbar. Dann „OK“." },
    { id = "TOOLTIP", title = "Tooltip: Verkaufschance und Marktlage", since = "0.9.61",
      todo = Todo("Berufsfenster offen, AHSentinel ist an und hat das Auktionshaus heute einmal gescannt", {
          "Klicke im Fenster „ProfessionSentinel“ auf den Reiter „Gold“.",
          "Fahre mit der Maus über die ersten Zeilen.",
          "Halte dabei die Umschalttaste (Shift) gedrückt – der Tooltip wird ausführlich.",
      }, "kein Gold, 30 Sekunden"),
      expect = "Mit Shift: „Erwartet (verkauft sich zu x %)“ oder ein grauer Satz „AHSentinel lernt noch …“; ohne Shift ggf. eine Zeile zur Marktlage (z. B. „Markt überflutet …“). Hakt sich selbst ab, sobald so eine Zeile kam." },
    -- OPT-ALLE (18.11.): the point "MINIMAP" (since 0.9.13) is part of it – its right-click now opens the options window
    -- (at most 14 points, hinweis-pruefliste-im-spiel)
    { id = "OPT", title = "Optionen am Bild", since = "0.9.70",
      todo = Todo("irgendwo", {
          "Klicke das Buch-Symbol an der Minimap mit rechts an.",
          "Klicke im Fenster „ProfessionSentinel-Optionen“ links auf „Hilfen & Daten“.",
          "Tippe oben rechts in das Suchfeld: alarm",
          "Klicke auf „Schließen“.",
      }, "kein Gold, 1 Minute"),
      expect = "Links drei Bereiche, rechts nur deren Optionen, nichts abgeschnitten oder überlappt; die Suche zeigt „Rezept-Alarm“ unter „Hilfen & Daten“. Findest du jede Einstellung schnell: „OK“." },
    { id = "KAMPF", title = "Kein Fehler im Kampf", since = "0.9.63",
      todo = Todo("draussen bei einem leichten Gegner, Fenster „ProfessionSentinel“ offen", {
          "Greife einen Gegner an.",
          "Fahre im Kampf mit der Maus über ein Rezept in deinen Taschen (z. B. „Muster: …“).",
          "Beende den Kampf.",
      }, "kein Gold, 1 Minute"),
      expect = "Keine rote Fehlermeldung, kein „Aktion blockiert“. Hakt sich nach dem Kampf selbst ab." },
}

-- the list of the developer (registered on first use: the BattleTag check needs the logged-in game)
function PLMOD.List()
    if PLMOD.list then return PLMOD.list end
    local G = _G.GoldSentinelPruefliste
    if not (type(G) == "table" and type(G.Register) == "function" and ns.IsDev and ns.IsDev()) then return nil end
    PLMOD.list = G:Register("ProfessionSentinel", {
        db = function() return ProfessionSentinelDB end,
        version = ns.VERSION,
        points = PLMOD.POINTS,
    })
    return PLMOD.list
end

-- the test routine never ticks a point off (its own test of the Prüfliste replaces this)
function PLMOD.Quiet()
    local TR = ns.TestRoutine
    return TR and TR.IsRunning and TR:IsRunning() or false
end
local function Quiet() return PLMOD.Quiet() end

-- the function was really used: the point is done (only for the developer, never during the test routine)
function ns.PLHit(id, note)
    if Quiet() then return false end
    local l = PLMOD.List()
    if not l then return false end
    local ok, r = pcall(l.Hit, l, id, note)
    return ok and r or false
end

-- a measured failure: the point shows "Fehler (erkannt)" with the note
function ns.PLFail(id, note)
    if Quiet() then return false end
    local l = PLMOD.List()
    if not l then return false end
    local ok, r = pcall(l.Set, l, id, "fehler", note)
    if ok and r and l.frame and l.frame:IsShown() then pcall(l.Refresh, l) end
    return ok and r or false
end

-- Ingametest 0.9.72 (MITTEL 4): the RESULT of a whole test run renews its point every time (state, time, note) – also while
-- a run is still counted as running and also when the point is already done (Hit renews only an open point; same cause as
-- ThreatSentinel 2.5.20). A player's own "OK"/"Nicht OK" stays unless the run found an error.
function ns.PLRefresh(id, state, note)
    local l = PLMOD.List()
    if not l then return false end
    local cur = l:State(id)
    if state ~= "fehler" and (cur == "ok" or cur == "nok") then return false end
    local ok, r = pcall(l.Set, l, id, state, note)
    if ok and r and l.frame and l.frame:IsShown() then pcall(l.Refresh, l) end
    return ok and r or false
end

-- /ps prüfliste
function PLMOD.Open()
    local l = PLMOD.List()
    if not l then return false end
    return l:Open()
end

-- lines for the test report (empty for players)
function PLMOD.ReportLines()
    local l = PLMOD.List()
    if not l then return {} end
    local ok, lines = pcall(l.ReportLines, l)
    return ok and lines or {}
end

-- point KAMPF: a fight with the panel open and no ProfessionSentinel error in it
local combat = { active = false }
PLMOD.combat = combat
function PLMOD.OnCombat(started)
    if started then
        local panel = _G.ProfessionSentinelPanel
        combat.active = panel and panel.IsShown and panel:IsShown() or false
        combat.errors = ns.errorCount or 0
        return
    end
    if not combat.active then return end
    combat.active = false
    local n = (ns.errorCount or 0) - (combat.errors or 0)
    if n == 0 then ns.PLHit("KAMPF", "Kampf ohne Fehler") else ns.PLFail("KAMPF", n .. " Fehler im Kampf") end
end
if CreateFrame then
    local f = CreateFrame("Frame")
    pcall(f.RegisterEvent, f, "PLAYER_REGEN_DISABLED")
    pcall(f.RegisterEvent, f, "PLAYER_REGEN_ENABLED")
    f:SetScript("OnEvent", function(_, event) PLMOD.OnCombat(event == "PLAYER_REGEN_DISABLED") end)
end
