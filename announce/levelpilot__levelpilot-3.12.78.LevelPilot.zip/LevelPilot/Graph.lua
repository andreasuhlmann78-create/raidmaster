-- LevelPilot - Wegenetz & Wegfindung
-- Knoten: Weltpunkte (Kontinent, Nord, West, Zone). Kanten: gelaufene Wege (eigene
-- oder von anderen Spielern), Zonenuebergaenge, Schiffe. Suche: A*.
-- Regel fuer "nur moegliche Wege": Ohne bekannte Kante darf der Weg nur INNERHALB
-- einer Zone per Luftlinie verbunden werden. Zonenwechsel nur ueber Uebergaenge
-- oder gelaufene Wege.

local _, LP = ...
local L = LP.L
local Graph = {}
LP:RegisterModule("Graph", Graph)

local CELL       = 100    -- Rasterzelle fuer die Umgebungssuche (Yards)
local SNAP       = 10     -- Punkte naeher als das werden zusammengelegt
local VIRT_RANGE = 260    -- Luftlinien-Verbindung zu gelaufenen Knoten in dieser Reichweite
local VIRT_MULT  = 1.45   -- Luftlinie ist unsicher -> teurer
local RUN_SPEED  = 7      -- Yards pro Sekunde (fuer Schiffs-/Wartezeiten)
local MAX_NODES  = 40000
local MAX_NET_NODES = 30000
local MAX_EXPAND = 8000
local STATIC_BASE = 10000000   -- IDs der Startdatenbank-Wege (nicht gespeichert)
local ROAD_BASE = 20000000     -- 3.12.50 ST-2: IDs der Strassen-Knoten (>= STATIC_BASE: wie das Startnetz nie gespeichert)

local G            -- gespeicherte Daten (LP.db.graph)
local adj = {}     -- [id] = { [nachbar] = kante }
local grid = {}    -- ["inst:cn:cw"] = { id, ... }
local nodes = {}   -- Laufzeit-Knoten (gespeicherte + Uebergaenge)
local gwByZone = {}
local gwEdges = {}
local staticCount, staticEdges = 0, 0

------------------------------------------------------------------------
-- Hilfen
------------------------------------------------------------------------
local function CellKey(inst, n, w)
    return inst .. ":" .. math.floor(n / CELL) .. ":" .. math.floor(w / CELL)
end

local virtCache, virtCount = {}, 0     -- 3.12.24: Luftlinien-Nachbarn je Knoten (leer bei jeder Aenderung)
local function GridAdd(id, nd)
    if virtCount > 0 then virtCache, virtCount = {}, 0 end
    local k = CellKey(nd[1], nd[2], nd[3])
    local list = grid[k]
    if not list then list = {} grid[k] = list end
    list[#list + 1] = id
end

local function EdgeKey(a, b)
    if a < b then return a .. ":" .. b end
    return b .. ":" .. a
end

local function Link(a, b, e)
    adj[a] = adj[a] or {}
    adj[b] = adj[b] or {}
    adj[a][b] = e
    adj[b][a] = e
end

local function Dist(a, b)
    local dn, dw = a[2] - b[2], a[3] - b[3]
    return math.sqrt(dn * dn + dw * dw)
end

------------------------------------------------------------------------
-- Aufbau
------------------------------------------------------------------------
local lvIdx = {}
local MAX_LVS = 4000          -- hoechstens so viele verschiedene Ebenen-Angaben (Karte|drinnen|Unterzone)

function Graph:Init()
    LP.db.graph = LP.db.graph or {}
    G = LP.db.graph
    G.nodes = G.nodes or {}
    G.edges = G.edges or {}
    G.nextId = G.nextId or 1
    G.count = G.count or 0
    if type(G.blocked) ~= "table" then G.blocked = {} end      -- 3.12.10: gesperrte Kanten (Sackgassen) [Schluessel] = { t, why }
    G.netCount = G.netCount or 0
    -- W3D: Ebenen-Angaben nur einmal speichern (Liste), am Knoten nur die Nummer – haelt die SavedVariables klein
    if type(G.lvs) ~= "table" then G.lvs = {} end
    wipe(lvIdx)
    -- 3.12.38 W3D: aeltere, uebersetzte Unterzonen-Namen in sprachfreie Schluessel umschreiben (Nummern bleiben gleich)
    for i, name in ipairs(G.lvs) do
        local neu = Graph.LvSprachfrei(name)
        if neu ~= name then G.lvs[i] = neu end
        if not lvIdx[G.lvs[i]] then lvIdx[G.lvs[i]] = i end
    end

    wipe(adj) wipe(grid) wipe(nodes) wipe(gwByZone) wipe(gwEdges)
    Graph.staticLoaded = nil
    for id, nd in pairs(G.nodes) do
        if type(nd) == "table" and type(nd.k) == "string" then nd.k = Graph.LvSprachfrei(nd.k) end   -- 3.12.38 W3D
        nodes[id] = nd
        GridAdd(id, nd)
    end
    for _, e in pairs(G.edges) do
        if nodes[e[1]] and nodes[e[2]] then Link(e[1], e[2], e) end
    end
    self:BuildGateways()
    self:LoadStatic(LP.Seed and LP.Seed.paths, LP.SeedWege)
    Graph.FreeOtherRoads()               -- 3.12.53 ST-5: nur die Strassen der eigenen Spielversion behalten
    self:LoadRoads()                     -- 3.12.50 ST-2: Strassen des Kontinents, auf dem der Spieler ist (in Portionen)
    if not Graph.roadEvents then         -- anderer Kontinent (Schiff, Zeppelin, Ruhestein): dessen Strassen beim Betreten
        Graph.roadEvents = true
        local function load() Graph:LoadRoads() end
        LP:On("PLAYER_ENTERING_WORLD", load)
        LP:On("ZONE_CHANGED_NEW_AREA", load)
    end
    -- 3.12.17 einmalig: lose Enden bestehender Wegstuecke an das Netz haengen (nichts geht verloren)
    -- 3.12.23 einmalig: lange gerade Stuecke aus aelteren Versionen in Stuecke <= 25 Yards teilen, danach nochmals
    -- lose Enden anhaengen
    -- 3.12.24: in Portionen im Hintergrund (vorher am Stueck beim Einloggen)
    -- 3.12.25: wer 3.12.23 schon gestartet hat (joinVer 2), bei dem sind auch Luecken von 25–80 Yards geteilt; diese
    -- Stuecke werden erkannt und als unsicher markiert (joinVer 3)
    local ver = G.joinVer or 0
    if ver < 3 then
        LP.Jobs.Start("graphfix", "graph", function()
            if ver < 2 then
                Graph:Densify()
                Graph:JoinLooseEnds()
            else
                Graph:MarkSplitGaps()
            end
        end, function(ok, err)
            if ok then G.joinVer = 3 else LP:Error(L["Wegnetz verbinden"], err) end
        end, { graph = true })
    end
end

-- 3.12.23: gespeicherte Kanten laenger als SEG_MAX Yards teilen. Die Kanten stammen aus gelaufenen Spuren, die
-- aeltere Versionen mit bis zu 6 Yards Abweichung zu geraden Stuecken vereinfacht haben; die Zwischenpunkte liegen
-- auf dieser Linie (kein neues Gelaende). Knoten nur bis 1000 unter der Hoechstzahl. Rueckgabe: geteilte Kanten.
Graph.SEG_MAX = 25
-- 3.12.24: geteilt werden nur Kanten ueber DENSIFY_MIN Yards. Laenger als die alte Sprunggrenze (80 Yards) kann
-- eine Kante nur durch die alte Vereinfachung gelaufener Spuren entstehen (bis 6 Yards Abweichung), nie durch eine
-- einzelne Luecke zwischen zwei Aufzeichnungen.
Graph.DENSIFY_MIN = 80
local DENSIFY_KINDS = { r = true, s = true, w = true }
function Graph:Densify(maxLen)
    maxLen = maxLen or self.SEG_MAX
    local list = {}
    for key, e in pairs(G.edges) do
        local a, b = nodes[e[1]], nodes[e[2]]
        if DENSIFY_KINDS[e[3]] and a and b and a[1] == b[1] and a[4] and a[4] == b[4]
           and LP.Geo:ContinentOf(a[4]) ~= a[4] then
            local len = math.sqrt((b[2] - a[2]) ^ 2 + (b[3] - a[3]) ^ 2)
            if len > maxLen + 0.5 then list[#list + 1] = { key = key, e = e, len = len } end
        end
    end
    table.sort(list, function(x, y) return x.key < y.key end)
    local split = 0
    for _, it in ipairs(list) do
        LP:Yield("graph")
        local e = it.e
        if G.edges[it.key] == e then                      -- sonst inzwischen geaendert
            local k = math.ceil(it.len / maxLen)
            if it.len <= self.DENSIFY_MIN then
                -- 3.12.24: 25–80 Yards kann auch eine Luecke zwischen zwei Aufzeichnungen sein (3.12.17–3.12.22):
                -- nicht teilen, nur als unsicher markieren (etwas teurer, bis der Weg nochmals gelaufen wird)
                e.u = 1
            elseif G.count + k > MAX_NODES - 1000 then
                break
            else
                local a, b = nodes[e[1]], nodes[e[2]]
                local fromNet = e[3] == "s"
                local cur, last = e, e[2]
                for j = 1, k - 1 do
                    -- 3.12.24: erst pruefen, dann den Knoten anlegen (kein verwaister Knoten)
                    if not cur or G.edges[EdgeKey(cur[1], cur[2])] ~= cur then break end
                    local t = j / k
                    local id = G.nextId
                    G.nextId = id + 1
                    local nd = { a[1], math.floor((a[2] + t * (b[2] - a[2])) * 10 + 0.5) / 10,
                                 math.floor((a[3] + t * (b[3] - a[3])) * 10 + 0.5) / 10, a[4], 1 }
                    if fromNet then nd.net = true G.netCount = G.netCount + 1 end
                    G.nodes[id], nodes[id] = nd, nd
                    G.count = G.count + 1
                    GridAdd(id, nd)
                    self:SplitEdge(cur, id)
                    cur = G.edges[EdgeKey(id, last)]
                end
                split = split + 1
            end
        end
    end
    if split > 0 then LP:Fire("GRAPH_CHANGED") end
    return split
end

-- 3.12.25: von 3.12.23 geteilte Luecken (25–80 Yards) wiederfinden: eine Kette aus Knoten mit genau zwei Kanten,
-- exakt auf einer Linie und in gleichen Abstaenden (so legt Densify die Punkte; gelaufene Punkte liegen nie so genau),
-- insgesamt 25–80 Yards lang. Ihre Kanten werden als unsicher markiert (nichts wird geloescht). Rueckgabe: Ketten.
local function Deg(id) local d = 0 for _ in pairs(adj[id] or {}) do d = d + 1 end return d end
local function Others(id, not1)
    for v in pairs(adj[id] or {}) do if v ~= not1 then return v end end
end
-- ist m ein von Densify gelegter Mittelpunkt zwischen a und b?
local function Mid(a, m, b)
    local A, M, B = nodes[a], nodes[m], nodes[b]
    if not (A and M and B) then return false end
    local d1 = math.sqrt((M[2] - A[2]) ^ 2 + (M[3] - A[3]) ^ 2)
    local d2 = math.sqrt((B[2] - M[2]) ^ 2 + (B[3] - M[3]) ^ 2)
    if d1 < 1 or math.abs(d1 - d2) > 0.3 then return false end
    -- Abstand von M zur Linie A–B
    local dn, dw = B[2] - A[2], B[3] - A[3]
    local len = math.sqrt(dn * dn + dw * dw)
    if len < 1 then return false end
    return math.abs((M[2] - A[2]) * dw - (M[3] - A[3]) * dn) / len <= 0.2
end
function Graph:MarkSplitGaps()
    local seen, chains = {}, 0
    local ids = {}
    for id in pairs(G.nodes) do ids[#ids + 1] = id end
    table.sort(ids)
    for _, id in ipairs(ids) do
        LP:Yield("graph")
        if not seen[id] and Deg(id) == 2 then
            local a = next(adj[id])
            local b = Others(id, a)
            if a and b and Mid(a, id, b) then
                -- Kette in beide Richtungen verlaengern, solange die Punkte gleich weit auf der Linie liegen
                local chain = { id }
                seen[id] = true
                local left, prevL = a, id
                while Deg(left) == 2 and not seen[left] do
                    local nx = Others(left, prevL)
                    if not nx or not Mid(prevL, left, nx) then break end
                    seen[left] = true
                    table.insert(chain, 1, left)
                    prevL, left = left, nx
                end
                local right, prevR = b, id
                while Deg(right) == 2 and not seen[right] do
                    local nx = Others(right, prevR)
                    if not nx or not Mid(prevR, right, nx) then break end
                    seen[right] = true
                    chain[#chain + 1] = right
                    prevR, right = right, nx
                end
                local A, B = nodes[left], nodes[right]
                local len = A and B and math.sqrt((B[2] - A[2]) ^ 2 + (B[3] - A[3]) ^ 2) or 0
                if len > self.SEG_MAX and len <= self.DENSIFY_MIN then
                    table.insert(chain, 1, left)
                    chain[#chain + 1] = right
                    for k = 2, #chain do
                        local e = G.edges[EdgeKey(chain[k - 1], chain[k])]
                        if e then e.u = 1 end
                    end
                    chains = chains + 1
                end
            end
        end
    end
    return chains
end

-- lose Enden (Knoten mit nur einer Kante) an die naechste Kante bis JOIN Yards haengen; Rueckgabe Anzahl
function Graph:JoinLooseEnds()
    local ends = {}
    for id in pairs(G.nodes) do
        local deg = 0
        for _ in pairs(adj[id] or {}) do deg = deg + 1 end
        if deg == 1 then ends[#ends + 1] = id end
    end
    table.sort(ends)
    local n = 0
    for _, id in ipairs(ends) do
        LP:Yield("graph")
        if nodes[id] and self:Join(id, { [id] = true }) then n = n + 1 end
    end
    if n > 0 then LP:Fire("GRAPH_CHANGED") end
    return n
end

Graph.SEED_STEP = 120          -- Yards: Startwege bekommen hoechstens so weit auseinander einen Knoten (Rest an der Kante)
-- Startwegnetz in Kartenkoordinaten (Data/Wege.lua, 3.12.37): nur im WoW-Forever-Client, denn die Wege wurden dort
-- gelaufen und Karten wie Mulgore sind in Forever anders als in Classic (warcraft.wiki.gg "Forever map comparison").
function Graph.SeedWegeAktiv()
    local g = _G.GoldSentinelGame
    if g and g.flavor and g.flavor ~= "unknown" then return g.IsForever and true or false end
    return true
end

-- Wege der Startdatenbank: { {inst, n1, w1, zone1, n2, w2, zone2, anzahl}, ... }
-- wege (optional): { [Karte] = { { Laeufe, x1, y1, x2, y2, ... }, ... } } in Kartenkoordinaten 0-100
-- 3.12.37: ein frueher geladenes Startnetz ganz entfernen (Knoten, Raster, Startweg-Kanten auch an eigenen Knoten),
-- bevor neu geladen wird – sonst ueberschrieben neue Startknoten alte mit derselben Nummer
local function ClearStatic()
    for u, nb in pairs(adj) do
        for v, e in pairs(nb) do
            if e[3] == "seed" or e[3] == "road" or (type(v) == "number" and v >= STATIC_BASE) then nb[v] = nil end
        end
        if type(u) == "number" and u >= STATIC_BASE then adj[u] = nil end
    end
    for id in pairs(nodes) do
        if type(id) == "number" and id >= STATIC_BASE then nodes[id] = nil end
    end
    for k, list in pairs(grid) do
        local keep = {}
        for _, id in ipairs(list) do if not (type(id) == "number" and id >= STATIC_BASE) then keep[#keep + 1] = id end end
        grid[k] = #keep > 0 and keep or nil
    end
    virtCache, virtCount = {}, 0
end

function Graph:LoadStatic(segments, wege)
    if Graph.staticLoaded then ClearStatic() end
    Graph.staticLoaded = true
    staticCount, staticEdges = 0, 0
    -- 3.12.50 ST-2: Strassen gehoeren zu den festen Wegen – mit dem Startnetz neu (Graph:Init leert alles, ClearStatic auch)
    Graph.roadStat = {}
    Graph.roadGen = (Graph.roadGen or 0) + 1
    Graph.detour = {}                          -- 3.12.51 LW-1: Umweg-Faktoren neu messen
    Graph.seedWegeStat = nil
    if type(segments) ~= "table" then segments = {} end
    local nextId = STATIC_BASE
    local function node(inst, n, w, zone)
        local id = self:Nearest(inst, n, w, SNAP, zone, function(i) return i >= STATIC_BASE end)
        if id then return id end
        nextId = nextId + 1
        nodes[nextId] = { inst, n, w, zone ~= 0 and zone or nil, 1, static = true }
        GridAdd(nextId, nodes[nextId])
        staticCount = staticCount + 1
        return nextId
    end
    for _, s in ipairs(segments) do
        local a = node(s[1], s[2], s[3], s[4])
        local b = node(s[1], s[5], s[6], s[7])
        if a ~= b then
            Link(a, b, { a, b, "seed", s[8] or 1 })
            staticEdges = staticEdges + 1
        end
    end
    if type(wege) ~= "table" or not Graph.SeedWegeAktiv() then return end
    -- Startwegnetz in Portionen (beim Einloggen nie am Stueck: ~14 000 Punkte). Die Punkte sind schon beim Erzeugen
    -- zusammengelegt (8 Yards); gleiche Koordinaten = derselbe Knoten (Tabelle statt Umkreissuche).
    Graph.seedGen = (Graph.seedGen or 0) + 1
    local gen = Graph.seedGen
    local Geo = LP.Geo
    local st = { karten = 0, wege = 0, kanten = 0, knoten = 0, eigen = 0, ohneKarte = 0, fertig = false }
    Graph.seedWegeStat = st
    LP.Jobs.Start("seedwege", "graph", function()
        local byKey = {}
        for map, list in pairs(wege) do
            local b = type(list) == "table" and Geo and Geo.Bounds and Geo:Bounds(map)
            if not b then
                st.ohneKarte = st.ohneKarte + 1
            else
                st.karten = st.karten + 1
                for _, w in ipairs(list) do
                    if gen ~= Graph.seedGen then return end          -- Wegnetz neu aufgebaut: dieser Lauf ist veraltet
                    local runs = tonumber(w[1]) or 1
                    -- Knoten nur an den Enden des Weges und alle SEED_STEP Yards; die Punkte dazwischen haengen an der
                    -- Kante (e.pts) und kommen erst beim Zusammensetzen des Weges dazu. So bleibt die Suche schnell.
                    local function nodeAt(i)
                        local key = map .. ":" .. tostring(w[i]) .. ":" .. tostring(w[i + 1])
                        local id = byKey[key]
                        if id then return id end
                        local inst, n, ww = Geo:ToWorld(map, w[i], w[i + 1])
                        if not inst then return nil end
                        -- eigener (gelaufener/geteilter) Knoten schon da? Dann diesen nehmen: das Startnetz fuellt
                        -- nur Luecken und verdoppelt das eigene Netz nicht (Kante nur im Speicher, nie gespeichert)
                        local own = self:Nearest(inst, n, ww, SNAP, map, function(i2) return i2 > 0 and i2 < STATIC_BASE end)
                        if own then
                            id = own
                            st.eigen = st.eigen + 1
                        else
                            nextId = nextId + 1
                            id = nextId
                            nodes[id] = { inst, n, ww, map, 1, static = true }
                            GridAdd(id, nodes[id])
                            staticCount = staticCount + 1
                            st.knoten = st.knoten + 1
                        end
                        byKey[key] = id
                        return id
                    end
                    local startId = nodeAt(2)
                    local mids, acc = {}, 0
                    local pi, pn, pw = Geo:ToWorld(map, w[2], w[3])
                    for i = 4, #w - 1, 2 do
                        local ci, cn, cw = Geo:ToWorld(map, w[i], w[i + 1])
                        if not (ci and pi) then break end
                        acc = acc + math.sqrt((cn - pn) ^ 2 + (cw - pw) ^ 2)
                        if i >= #w - 1 or acc >= Graph.SEED_STEP then
                            local endId = nodeAt(i)
                            if startId and endId and startId ~= endId and not (adj[startId] and adj[startId][endId]) then
                                Link(startId, endId, { startId, endId, "seed", runs, pts = #mids > 0 and mids or nil, len = acc })
                                staticEdges = staticEdges + 1
                                st.kanten = st.kanten + 1
                            end
                            startId, mids, acc = endId, {}, 0
                        else
                            mids[#mids + 1] = cn
                            mids[#mids + 1] = cw
                        end
                        pi, pn, pw = ci, cn, cw
                    end
                    st.wege = st.wege + 1
                    LP:Yield("graph")
                end
            end
        end
    end, function(ok, err)
        if gen ~= Graph.seedGen then return end
        if ok then
            st.fertig = true
            -- innere Punkte und Kreuzungen markieren (mindestens zwei Nachbarn, alle aus dem Startwegnetz, alle Kanten
            -- Startwege): sie suchen keine Luftlinien; nur Enden des Startnetzes und eigene Knoten tun das
            local inner = 0
            for id = STATIC_BASE + 1, nextId do
                local nd, a = nodes[id], adj[id]
                if nd and a then
                    local n2, okAll = 0, true
                    for v, e in pairs(a) do
                        n2 = n2 + 1
                        if e[3] ~= "seed" or type(v) ~= "number" or v < STATIC_BASE then okAll = false end
                    end
                    nd.si = (n2 >= 2 and okAll) or nil
                    if nd.si then inner = inner + 1 end
                end
            end
            st.innen = inner
            -- die Rohdaten (~1,4 MB) werden nach dem Aufbau nicht mehr gebraucht (Graph:Init laeuft einmal je Einloggen)
            if LP.SeedWege == wege then LP.SeedWege = nil end
            LP:Fire("GRAPH_CHANGED")
        else
            LP:Error(L["Wegnetz verbinden"], err)
        end
    end, { graph = true })
end

------------------------------------------------------------------------
-- 3.12.50 ST-2: Strassennetz aus den Spieldateien von WoW Forever (Data/Strassen.lua = GoldSentinelStrassen, erzeugt mit
-- raidmaster/shared/werkzeuge/strassen aus den Bodentexturen; Welt-Yards je Kontinent wie C_Map.GetWorldPosFromMapPos).
-- Wie das Startwegnetz: Knoten an Kreuzungen/Enden und alle SEED_STEP Yards, Punkte dazwischen an der Kante (pts), nie
-- gespeichert oder geteilt. ST-4: nur der Kontinent, auf dem der Spieler ist, in Portionen; der andere beim ersten Betreten.
-- Kosten: Strasse wie ein gelaufener Weg (gleiches Tempo); billiger ist sie gegenueber der unsicheren Luftlinie
-- (1,45 × Gelaende). Graph.ROAD_COST wird mit ST-3 gemessen (bis dahin Verdacht).
------------------------------------------------------------------------
Graph.ROAD_COST = 1.0
Graph.roadStat = Graph.roadStat or {}
Graph.roadGen = Graph.roadGen or 0
-- 3.12.53 ST-5: Strassen je Spielversion. WoW Forever = GoldSentinelStrassen (Forever-Client), Classic Era =
-- GoldSentinelStrassenEra (aus dem Anniversary-Client, Grundwelt Karten 0/1; Entscheid des Nutzers 16.11. 09:08). Andere
-- Spielversionen (TBC Classic …): keine Strassen.
function Graph.RoadData()
    if Graph.SeedWegeAktiv() then return _G.GoldSentinelStrassen, "Forever" end
    local g = _G.GoldSentinelGame
    if g and g.flavor == "era" then return _G.GoldSentinelStrassenEra, "Era" end
    return nil
end
function Graph.RoadsAktiv() return Graph.RoadData() ~= nil end
-- die Daten der anderen Spielversion werden nicht gebraucht: freigeben (Speicher, einmal beim Aufbau)
function Graph.FreeOtherRoads()
    local _, welche = Graph.RoadData()
    if welche ~= "Forever" then _G.GoldSentinelStrassen = nil end
    if welche ~= "Era" then _G.GoldSentinelStrassenEra = nil end
end

function Graph:LoadRoads(inst)
    if inst == nil then inst = LP.Geo:Player() end
    local R = Graph.RoadData()
    local k = inst ~= nil and type(R) == "table" and type(R.karten) == "table" and R.karten[inst]
    if type(k) ~= "table" then return false end
    if Graph.roadStat[inst] then return false end                     -- schon geladen oder in Arbeit
    local gen = Graph.roadGen
    local st = { knoten = 0, kanten = 0, eigen = 0, ohneZone = 0, innen = 0, fertig = false, yards = 0, stuecke = 0,
                 gleich = 0, doppelt = 0 }   -- Stuecke = Kanten-Kandidaten; gleich = Anfang = Ende; doppelt = Paar schon verbunden
    Graph.roadStat[inst] = st
    local Geo = LP.Geo
    local base = ROAD_BASE + inst * 5000000
    local p, e = k.p, k.e
    LP.Jobs.Start("strassen" .. inst, "graph", function()
        local byIdx, nextId = {}, base
        local function newNode(n, w)
            -- eigener oder Startnetz-Knoten an derselben Stelle: diesen nehmen (keine Verdopplung)
            local zone = Geo.ZoneAt and Geo:ZoneAt(inst, n, w)
            local own = zone and self:Nearest(inst, n, w, SNAP, zone, function(i2) return i2 > 0 and i2 < ROAD_BASE end)
            if own then st.eigen = st.eigen + 1 return own end
            nextId = nextId + 1
            nodes[nextId] = { inst, n, w, zone, 1, static = true }
            GridAdd(nextId, nodes[nextId])
            staticCount = staticCount + 1
            st.knoten = st.knoten + 1
            if not zone then st.ohneZone = st.ohneZone + 1 end
            return nextId
        end
        local function at(i)
            local id = byIdx[i]
            if id then return id end
            id = newNode(p[2 * i - 1], p[2 * i])
            byIdx[i] = id
            return id
        end
        for ki, line in ipairs(e) do
            if gen ~= Graph.roadGen then return end                    -- Netz neu aufgebaut: dieser Lauf ist veraltet
            local startId = at(line[1])
            local mids, acc = {}, 0
            local pn, pw = p[2 * line[1] - 1], p[2 * line[1]]
            for j = 2, #line do
                local i = line[j]
                local cn, cw = p[2 * i - 1], p[2 * i]
                local d = math.sqrt((cn - pn) ^ 2 + (cw - pw) ^ 2)
                acc = acc + d
                st.yards = st.yards + d
                if j == #line or acc >= Graph.SEED_STEP then
                    local endId = (j == #line) and at(i) or newNode(cn, cw)
                    st.stuecke = st.stuecke + 1
                    if startId and endId and startId == endId then
                        st.gleich = st.gleich + 1                -- Ring an einem Knoten (Anfang = Ende des Linienzugs)
                    elseif startId and endId and adj[startId] and adj[startId][endId] then
                        st.doppelt = st.doppelt + 1              -- zweite Strasse zwischen denselben zwei Knoten: die kuerzere gilt
                        local old = adj[startId][endId]
                        if old[3] == "road" and acc < (old.len or math.huge) then
                            Link(startId, endId, { startId, endId, "road", 1, pts = #mids > 0 and mids or nil, len = acc })
                            st.kuerzer = (st.kuerzer or 0) + 1
                        end
                    elseif startId and endId then
                        Link(startId, endId, { startId, endId, "road", 1, pts = #mids > 0 and mids or nil, len = acc })
                        staticEdges = staticEdges + 1
                        st.kanten = st.kanten + 1
                    end
                    startId, mids, acc = endId, {}, 0
                else
                    mids[#mids + 1] = cn
                    mids[#mids + 1] = cw
                end
                pn, pw = cn, cw
            end
            if ki % 4 == 0 then LP:Yield("graph") end
        end
        st.letzte = nextId
    end, function(ok, err)
        if gen ~= Graph.roadGen then return end
        if ok then
            -- innere Punkte und Kreuzungen (nur Strassen als Nachbarn): keine eigenen Luftlinien-Suchen (wie Startnetz)
            for id = base + 1, st.letzte or base do
                local nd, a = nodes[id], adj[id]
                if nd and a then
                    local n2, okAll = 0, true
                    for v, ed in pairs(a) do
                        n2 = n2 + 1
                        if ed[3] ~= "road" or type(v) ~= "number" or v < ROAD_BASE then okAll = false end
                    end
                    nd.si = (n2 >= 2 and okAll) or nil
                    if nd.si then st.innen = st.innen + 1 end
                end
            end
            st.fertig = true
            Graph.detour = {}                -- LW-1: Umweg-Faktoren mit Strassen neu messen
            LP:Fire("GRAPH_CHANGED")
        else
            Graph.roadStat[inst] = nil
            LP:Error(L["Wegnetz verbinden"], err)
        end
    end, { graph = true })
    return true
end

-- Diagnose: "STRASSEN Kontinent 1 … Knoten, … Kanten, … yd"
function Graph.RoadText()
    local parts = {}
    for inst, st in pairs(Graph.roadStat or {}) do
        parts[#parts + 1] = ("Kontinent %s %d Knoten (%d an eigenen, %d ohne Zone, %d innen), %d Kanten (von %d Stücken: %d Ring, %d doppelt, davon %d kürzer ersetzt), %d yd%s"):format(tostring(inst),
            st.knoten, st.eigen, st.ohneZone, st.innen, st.kanten, st.stuecke, st.gleich, st.doppelt, st.kuerzer or 0, math.floor(st.yards + 0.5),
            st.fertig and "" or " (lädt)")
    end
    local R, welche = Graph.RoadData()
    if #parts == 0 then
        return R and ("STRASSEN (" .. welche .. ") noch nicht geladen") or "STRASSEN keine (nur WoW Forever und Classic Era)"
    end
    table.sort(parts)
    return "STRASSEN (" .. tostring(welche) .. ") " .. table.concat(parts, " · ")
end

------------------------------------------------------------------------
-- 3.12.51 LW-1: Umweg-Faktor je Zone = wie viel länger ein BEKANNTER Weg (gelaufen, Startnetz, Strassen; Graph:PathKnown)
-- im Mittel ist als die Luftlinie. 3.12.52 (ST-3): vorher wurde der Weg der normalen Wegsuche gemessen – die geht im offenen
-- Gelände gerade (Luftlinie 1,45 ist billiger als jeder Umweg), Faktor ~1,0, gelaufen sind es im Median 1,48 (ST-3 an
-- 5445 Paaren der Spielerwege). Gemessen an bis zu DETOUR_PAIRS Paaren bekannter Knoten der Zone (300–2000 yd Luftlinie,
-- feste Auswahl), einmal je Zone und Sitzung, im Hintergrund (Portionen).
-- Median, begrenzt auf DETOUR_MIN..DETOUR_MAX. Solange nicht gemessen bzw. zu wenig Knoten: DETOUR_DEFAULT (Verdacht).
-- Die Planung (Reihenfolge, 2-opt, Fokus-Zone, Flugentscheid) rechnet damit statt mit der reinen Luftlinie.
------------------------------------------------------------------------
Graph.DETOUR_DEFAULT, Graph.DETOUR_MIN, Graph.DETOUR_MAX = 1.25, 1.0, 1.8
Graph.DETOUR_PAIRS, Graph.DETOUR_TRIES, Graph.DETOUR_MIN_PAIRS = 12, 80, 5
Graph.detour = Graph.detour or {}

-- Faktor, Anzahl Paare (0 = Annahme); misst beim ersten Bedarf im Hintergrund
function Graph:Detour(zone)
    if not zone then return Graph.DETOUR_DEFAULT, 0 end
    local d = Graph.detour[zone]
    if d and d.f then return d.f, d.n end
    if not d then self:MeasureDetour(zone) end
    return Graph.DETOUR_DEFAULT, 0
end

-- reine Rechnung (Testroutine): Median der Verhältnisse, begrenzt; nil bei zu wenig Paaren
function Graph.DetourOf(ratios)
    if #ratios < Graph.DETOUR_MIN_PAIRS then return nil end
    local r = {}
    for i, v in ipairs(ratios) do r[i] = v end
    table.sort(r)
    local m = #r % 2 == 1 and r[(#r + 1) / 2] or (r[#r / 2] + r[#r / 2 + 1]) / 2
    return math.max(Graph.DETOUR_MIN, math.min(Graph.DETOUR_MAX, m))
end

function Graph:MeasureDetour(zone)
    local rec = { pending = true }
    Graph.detour[zone] = rec
    local det = Graph.detour
    LP.Jobs.Start("umweg" .. zone, "graph", function()
        local ids, k = {}, 0
        for id, nd in pairs(nodes) do
            k = k + 1
            if nd[4] == zone and type(id) == "number" and id > 0 then ids[#ids + 1] = id end
            if k % 500 == 0 then LP:Yield("graph") end
        end
        table.sort(ids)
        rec.knoten = #ids
        local ratios, tries, seed = {}, 0, zone % 9973 + 1
        local function rnd(m) seed = (seed * 16807) % 2147483647 return seed % m + 1 end
        while #ids >= 2 and #ratios < Graph.DETOUR_PAIRS and tries < Graph.DETOUR_TRIES do
            tries = tries + 1
            -- 3.12.52: zweiter Knoten aus der Umgebung des ersten (300–2000 yd), sonst trifft ein Zufallspaar in grossen
            -- Zonen fast nie den Bereich
            local a = nodes[ids[rnd(#ids)]]
            local cand = {}
            if a then
                for _, v in ipairs(self:Near(a[1], a[2], a[3], 2000, zone) or {}) do
                    local nv = nodes[v]
                    if nv and type(v) == "number" and v > 0 and Dist(a, nv) >= 300 then cand[#cand + 1] = v end
                end
                table.sort(cand)
            end
            local b = #cand > 0 and nodes[cand[rnd(#cand)]] or nil
            if a and b and a[1] == b[1] then
                local d = Dist(a, b)
                if d >= 300 and d <= 2000 then
                    local p = self:PathKnown(a[1], a[2], a[3], zone, b[1], b[2], b[3], zone, 3000)
                    if p then
                        local len = 0
                        for i = 2, #p do len = len + Dist(p[i - 1], p[i]) end
                        ratios[#ratios + 1] = len / d
                    end
                end
            end
            LP:Yield("graph")
        end
        rec.paare, rec.versuche = #ratios, tries
        rec.f = Graph.DetourOf(ratios) or Graph.DETOUR_DEFAULT
        rec.n = Graph.DetourOf(ratios) and #ratios or 0
    end, function(ok, err)
        if det ~= Graph.detour then return end               -- inzwischen neu aufgebaut
        rec.pending = nil
        if not ok then rec.f, rec.n = Graph.DETOUR_DEFAULT, 0 rec.err = tostring(err) end
    end, { graph = true })
end

-- Diagnose: "UMWEG je Zone: Brachland 1,18 (12 Paare) · Mulgore 1,25 (Annahme) …"
function Graph.DetourText()
    local parts = {}
    for zone, d in pairs(Graph.detour or {}) do
        if d.f then
            parts[#parts + 1] = ("%s %s (%s)"):format(LP.Geo:MapName(zone) or tostring(zone), (("%.2f"):format(d.f):gsub("%.", ",")),
                d.n > 0 and (d.n .. " Paare") or ("Annahme, " .. tostring(d.knoten or 0) .. " Knoten"))
        end
    end
    table.sort(parts)
    return "UMWEG je Zone (bekannter Weg/Luftlinie): " .. (#parts > 0 and table.concat(parts, " · ") or "noch nichts gemessen")
end

-- Zonenuebergaenge als Laufzeit-Knoten (negative IDs, nicht gespeichert)
function Graph:BuildGateways()
    local faction = LP:PlayerFaction()
    local gid = -1
    for _, g in ipairs(LP.Gateways or {}) do
        local mapA, xA, yA, mapB, xB, yB, kind, secs, fac, name = unpack(g)
        if not fac or fac == faction then
            local iA, nA, wA = LP.Geo:ToWorld(mapA, LP.Geo:FromData(mapA, xA, yA))   -- 3.12.55 LW-5: Forever-Rahmen
            local iB, nB, wB = LP.Geo:ToWorld(mapB, LP.Geo:FromData(mapB, xB, yB))
            if iA and iB then
                local a, b = gid, gid - 1
                gid = gid - 2
                nodes[a] = { iA, nA, wA, mapA, 0, gw = true, name = name }
                nodes[b] = { iB, nB, wB, mapB, 0, gw = true, name = name }
                GridAdd(a, nodes[a]) GridAdd(b, nodes[b])
                gwByZone[mapA] = gwByZone[mapA] or {}
                gwByZone[mapB] = gwByZone[mapB] or {}
                table.insert(gwByZone[mapA], a)
                table.insert(gwByZone[mapB], b)
                local e = { a, b, kind == "walk" and "g" or kind, 1, secs = secs, name = name }
                gwEdges[#gwEdges + 1] = e
                Link(a, b, e)
            end
        end
    end
end

------------------------------------------------------------------------
-- Suche in der Umgebung
------------------------------------------------------------------------
function Graph:Near(inst, n, w, radius, zone)
    local out = {}
    local r = math.ceil(radius / CELL)
    local cn, cw = math.floor(n / CELL), math.floor(w / CELL)
    for dn = -r, r do
        for dw = -r, r do
            local list = grid[inst .. ":" .. (cn + dn) .. ":" .. (cw + dw)]
            if list then
                for i = 1, #list do
                    local id = list[i]
                    local nd = nodes[id]
                    if nd and (not zone or nd[4] == zone) then
                        local d = math.sqrt((nd[2] - n) ^ 2 + (nd[3] - w) ^ 2)
                        if d <= radius then out[#out + 1] = id end
                    end
                end
            end
        end
    end
    return out
end

-- 3.12.24: fuer Luftlinien in der Wegsuche je Rasterzelle (100 Yards) nur die naechsten VIRT_PER_CELL Knoten.
-- Bei dichten Wegnetzen (Punkte alle 12–25 Yards) lieferte Near() hunderte Knoten je Schritt der Suche, und jede
-- Luftlinie wurde gegen die Gelaendekarte geprueft – das liess das Spiel nach dem Einloggen einfrieren.
Graph.VIRT_PER_CELL = 2
function Graph:NearSparse(inst, n, w, radius, zone, out)
    out = out or {}
    local per = self.VIRT_PER_CELL
    local r = math.ceil(radius / CELL)
    local cn, cw = math.floor(n / CELL), math.floor(w / CELL)
    local r2 = radius * radius
    for dn = -r, r do
        for dw = -r, r do
            local list = grid[inst .. ":" .. (cn + dn) .. ":" .. (cw + dw)]
            if list then
                local b1, d1, b2, d2
                for i = 1, #list do
                    local id = list[i]
                    local nd = nodes[id]
                    if nd and (not zone or nd[4] == zone) then
                        local dd = (nd[2] - n) ^ 2 + (nd[3] - w) ^ 2
                        if dd <= r2 then
                            if not d1 or dd < d1 then b2, d2 = b1, d1 b1, d1 = id, dd
                            elseif per > 1 and (not d2 or dd < d2) then b2, d2 = id, dd end
                        end
                    end
                end
                if b1 then out[#out + 1] = b1 end
                if b2 and per > 1 then out[#out + 1] = b2 end
            end
        end
    end
    return out
end

------------------------------------------------------------------------
-- W3D (Entwurf, unveroeffentlicht): Ebenen-Schluessel je Knoten. nil = draussen (wie bisher, ein Schluessel je Zone);
-- drinnen "i:<Unterzone>". Zusammenlegen (SNAP), Anhaengen (Join) und Luftlinien nur innerhalb desselben Schluessels;
-- drinnen keine Luftlinien zwischen Knoten. Welche Zeichen die Ebene wirklich trennen, klaert die Messung (GSWegMess);
-- darum ist die Schluessel-Funktion austauschbar (Graph.LevelKey).
------------------------------------------------------------------------
-- Schalter (Supervisor 15.11. 20:15): bis die Messung (GSWegMess) belegt, dass Karte + Unterzone + drinnen die Ebenen trennt,
-- bleibt W3D AUS. Aus = Verhalten genau wie 3.12.35; nur die Ebenen-Angabe (nd.lv) wird schon mitgespeichert und exportiert.
LP.W3D = LP.W3D or false
function Graph.On() return LP.W3D == true end

-- 3.12.38 W3D sprachfrei (Supervisor 21:48): GetSubZoneText ist uebersetzt ("Magieviertel" / "The Magic Quarter"). Fuer Orte
-- mit Ebenen gibt es eine Tabelle Data/AreaNames.lua (wago.tools AreaTable + WMOAreaTable, Zweig wowf):
-- LP.AreaNames = { ["<Schluessel>"] = { deDE = "Name", enUS = "Name", ..., alt = { weitere Namen derselben Ebene } } },
-- Schluessel "<AreaID>" bzw. "<AreaID>:<enUS-Name>" (Supervisor 22:03: gleiche AreaID + gleicher enUS-Name = gleiche Ebene;
-- Unterstadt hat zwei Gebaeude mit "Magieviertel" / "Das Magieviertel"). Ein bekannter Name wird zu "#<Schluessel>",
-- ein unbekannter bleibt der Name selbst (wie bisher).
local subIdx
local function SubIndex()
    if subIdx then return subIdx end
    subIdx = {}
    local function add(n, key)
        -- gleicher Name fuer zwei Schluessel (z. B. "Darnassus" = Stadt und Raum): immer der kleinere (feste Wahl,
        -- unabhaengig von der Reihenfolge von pairs). Die Karte steht ohnehin vorn in der Ebenen-Angabe.
        if type(n) == "string" and n ~= "" and (not subIdx[n] or key < subIdx[n]) then subIdx[n] = key end
    end
    for key, names in pairs(LP.AreaNames or {}) do
        if type(names) == "table" then
            key = tostring(key)
            for loc, n in pairs(names) do
                if loc == "alt" and type(n) == "table" then
                    for _, a in ipairs(n) do add(a, key) end
                else
                    add(n, key)
                end
            end
        end
    end
    return subIdx
end
function Graph.ResetSubIndex() subIdx = nil end
function Graph.SubKey(sub)
    if type(sub) ~= "string" or sub == "" then return "" end
    local id = SubIndex()[sub]
    return id and ("#" .. id) or sub
end
-- Anzeige: "#<Schluessel>" -> Name in der Sprache des Spiels (sonst Englisch); andere Texte unveraendert
function Graph.SubName(sub)
    if type(sub) ~= "string" then return sub end
    local key = sub:match("^#(.+)$")
    local names = key and LP.AreaNames and LP.AreaNames[key]
    if type(names) ~= "table" then return sub end
    local loc = GetLocale and GetLocale()
    if type(names[loc]) == "string" then return names[loc] end
    if type(names.enUS) == "string" then return names.enUS end
    return key:match(":(.+)$") or sub
end
-- "Karte|d|Name" -> "Karte|d|#ID" (unbekannte Namen und schon umgeschriebene Angaben bleiben)
function Graph.LvSprachfrei(lv)
    if type(lv) ~= "string" then return lv end
    local head, sub = lv:match("^([^|]*|[^|]*)|(.*)$")
    if not head or sub == "" or sub:sub(1, 1) == "#" then return lv end
    local k = Graph.SubKey(sub)
    return k == sub and lv or (head .. "|" .. k)
end

-- Ebenen-Angabe am Spieler: "Karte|d|Unterzone" (d = drinnen) bzw. "Karte|o|Unterzone" (draussen)
function Graph.LevelInfo()
    local S = LP.SafeValue
    local map = C_Map and C_Map.GetBestMapForUnit and S(C_Map.GetBestMapForUnit("player")) or 0
    local indoors = IsIndoors and S(IsIndoors()) and true or false
    local sub = GetSubZoneText and S(GetSubZoneText()) or ""
    return tostring(map or 0) .. "|" .. (indoors and "d" or "o") .. "|" .. Graph.SubKey(tostring(sub or "")), indoors
end

-- Nummer einer Ebenen-Angabe (neu angelegt, solange Platz ist)
function Graph.LvId(lv)
    if type(lv) ~= "string" or not G then return nil end
    local i = lvIdx[lv]
    if i then return i end
    if #G.lvs >= MAX_LVS then return nil end
    G.lvs[#G.lvs + 1] = lv
    lvIdx[lv] = #G.lvs
    return #G.lvs
end
-- Ebenen-Angabe eines Knotens als Text (nil = keine)
function Graph.LvName(nd)
    local v = nd and nd.lv
    if type(v) == "string" then return v end
    return v and G and G.lvs and G.lvs[v] or nil
end

-- Schluessel fuer das Wegnetz: nil = draussen (wie bisher), drinnen die Ebenen-Angabe
function Graph.LevelKey()
    local lv, indoors = Graph.LevelInfo()
    if not indoors then return nil end
    return lv
end

-- Aufzug: mittlere Wartezeit = halber Takt (TransportAnimation, Konzept W3D 3b): Unterstadt 16,7 s, Donnerfels 30 s
Graph.LIFT_WAIT = { [1458] = 8.4, [1456] = 15 }
Graph.LIFT_WAIT_DEFAULT = 15
Graph.LIFT_SECS = 3          -- so lange (Sekunden) in 2D fast still, waehrend die Ebene wechselt = Aufzug
Graph.LIFT_MOVE = 8          -- Yards: so wenig Bewegung in 2D gilt als "still"
local function SameKey(a, b) return (a and a.k) == (b and b.k) end
local function Inside(nd, zone) return Graph.On() and ((nd and nd.k ~= nil) or Graph.INDOOR_ZONES[zone] == true) end
-- Zonen, die ganz aus Raeumen auf mehreren Ebenen bestehen: dort nie Luftlinien zwischen Knoten, auch fuer aeltere
-- Knoten ohne Schluessel (Unterstadt: eine Karte fuer Ring, Viertel, Kanaele – wago.tools UiMap, Supervisor 15.11.)
Graph.INDOOR_ZONES = { [1458] = true }
Graph.SameKey = SameKey

function Graph:Nearest(inst, n, w, radius, zone, filter)
    local best, bestD
    for _, id in ipairs(self:Near(inst, n, w, radius, zone)) do
        local nd = nodes[id]
        if filter and not filter(id) then nd = nil end
        if nd then
        local d = math.sqrt((nd[2] - n) ^ 2 + (nd[3] - w) ^ 2)
        if not bestD or d < bestD then best, bestD = id, d end
        end
    end
    return best, bestD
end

------------------------------------------------------------------------
-- Hinzufuegen (aus Aufzeichnung oder vom Netzwerk)
------------------------------------------------------------------------
function Graph:AddNode(inst, n, w, zone, fromNet, key, lv)
    -- W3D: nur Knoten derselben Ebene zusammenlegen (aus: Schluessel immer nil -> wie bisher)
    if not Graph.On() then key = nil end
    local id = self:Nearest(inst, n, w, SNAP, zone, function(i) return i > 0 and i < STATIC_BASE and nodes[i] and nodes[i].k == key end)
    if id then
        local nd = nodes[id]
        nd[5] = (nd[5] or 0) + 1
        if lv and not nd.lv then nd.lv = Graph.LvId(lv) end
        return id, false
    end
    if G.count >= MAX_NODES then return nil end
    if fromNet and G.netCount >= MAX_NET_NODES then return nil end
    id = G.nextId
    G.nextId = id + 1
    local nd = { inst, math.floor(n * 10 + 0.5) / 10, math.floor(w * 10 + 0.5) / 10, zone, 1 }
    nd.k = key
    nd.lv = Graph.LvId(lv)    -- W3D: Ebenen-Angabe der Aufzeichnung als Nummer (auch bei W3D aus gespeichert)
    if fromNet then nd.net = true G.netCount = G.netCount + 1 end
    G.nodes[id] = nd
    nodes[id] = nd
    G.count = G.count + 1
    GridAdd(id, nd)
    return id, true
end

-- kind: "r" = selbst gelaufen, "s" = von anderen Spielern, "w" = geschwommen
-- consent: Urheber hat das Wegstueck fuer die Startdatenbank freigegeben
function Graph:AddEdge(a, b, kind, consent)
    if not a or not b or a == b then return false end
    local key = EdgeKey(a, b)
    local e = G.edges[key]
    if e then
        e[4] = (e[4] or 1) + 1
        e.u = nil                                         -- nochmals gelaufen: sicher
        if kind == "r" and e[3] == "s" then e[3] = "r" end
        if consent then e.c = true end
        return false
    end
    e = { a, b, kind, 1, c = consent or nil }
    G.edges[key] = e
    Link(a, b, e)
    return true
end

-- 3.12.17: Wegstuecke verbinden. Liegt ein neuer Knoten bis JOIN Yards neben einer bestehenden Kante (nicht an
-- ihrem Ende), wird die Kante dort geteilt und der Knoten eingehaengt – so haengen Anfang und Ende eines neuen
-- Wegstuecks und Kreuzungen am bestehenden Netz (vorher zerfiel das Netz einer Zone in viele Teile).
Graph.JOIN = 10
local JOIN_SEARCH = 70          -- Knoten in dieser Reichweite liefern die Kandidaten-Kanten

-- naechste gespeicherte Kante (gleiche Zone) zum Punkt, ohne Kanten an den Knoten in skip
function Graph:NearestEdge(inst, n, w, zone, radius, skip)
    local best, bestD, bestT
    local seen = {}
    for _, id in ipairs(self:Near(inst, n, w, JOIN_SEARCH, zone)) do
        if adj[id] and not (skip and skip[id]) then
            for v, e in pairs(adj[id]) do
                local key = (type(v) == "number" and v > 0 and id > 0) and EdgeKey(id, v) or nil
                if key and not seen[key] and G.edges[key] == e and not (skip and skip[v]) then
                    seen[key] = true
                    local a, b = nodes[e[1]], nodes[e[2]]
                    local want = skip and skip.k        -- W3D: nur Kanten der Ebene des neuen Knotens (nil = draussen)
                    if a and b and a[4] == zone and b[4] == zone and a.k == want and b.k == want then
                        local dn, dw = b[2] - a[2], b[3] - a[3]
                        local len2 = dn * dn + dw * dw
                        if len2 > 0 then
                            local t = ((n - a[2]) * dn + (w - a[3]) * dw) / len2
                            if t > 0 and t < 1 then
                                local d = math.sqrt((a[2] + t * dn - n) ^ 2 + (a[3] + t * dw - w) ^ 2)
                                if d <= radius and (not bestD or d < bestD) then best, bestD, bestT = e, d, t end
                            end
                        end
                    end
                end
            end
        end
    end
    return best, bestD, bestT
end

-- Kante e am Knoten mid teilen: a–b wird a–mid und mid–b (Herkunft, Anzahl, Freigabe und Sperre bleiben)
function Graph:SplitEdge(e, mid)
    local a, b = e[1], e[2]
    if not mid or mid == a or mid == b then return false end
    local key = EdgeKey(a, b)
    if G.edges[key] ~= e then return false end
    G.edges[key] = nil
    if adj[a] then adj[a][b] = nil end
    if adj[b] then adj[b][a] = nil end
    local blocked = G.blocked and G.blocked[key]
    if blocked then G.blocked[key] = nil end
    for _, pair in ipairs({ { a, mid }, { mid, b } }) do
        local k = EdgeKey(pair[1], pair[2])
        local old = G.edges[k]
        if old then
            old[4] = math.max(old[4] or 1, e[4] or 1)
        else
            local ne = { pair[1], pair[2], e[3], e[4] or 1, c = e.c, u = e.u }
            G.edges[k] = ne
            Link(pair[1], pair[2], ne)
        end
        if blocked then G.blocked[k] = { t = blocked.t, why = blocked.why } end
    end
    return true
end

-- neuen Knoten an die naechste Kante haengen (skip: Knoten, deren Kanten nicht in Frage kommen)
function Graph:Join(id, skip)
    local nd = nodes[id]
    if not nd or not nd[4] then return false end
    -- W3D: nur an Kanten derselben Ebene anhaengen
    skip = skip or {}
    skip.k = nd.k
    local e = self:NearestEdge(nd[1], nd[2], nd[3], nd[4], self.JOIN, skip)
    if not e then return false end
    return self:SplitEdge(e, id)
end

-- Polylinie: { {inst, n, w, zone, zeit, k = Schluessel, lv = Ebenen-Angabe, fall = faellt}, ... }
function Graph:AddPolyline(points, kind, fromNet, consent)
    local prev, added, joined = nil, 0, 0
    local prevP
    for _, p in ipairs(points) do
        local id, created = self:AddNode(p[1], p[2], p[3], p[4], fromNet, p.k, p.lv)
        -- neuer Knoten: an eine bestehende Kante anhaengen (nicht an die eben gelegte)
        if id and created and self:Join(id, prev and { [prev] = true } or nil) then joined = joined + 1 end
        if prev and id and self:AddEdge(prev, id, kind, consent) then
            added = added + 1
            -- W3D: Kante zwischen zwei Ebenen = Tor. Sturz dazwischen: nur nach unten (Einbahn prev -> id);
            -- 2D fast still >= LIFT_SECS: Aufzug (Wartezeit in den Kosten)
            if Graph.On() and nodes[prev] and nodes[id] and nodes[prev].k ~= nodes[id].k then
                local e = G.edges[EdgeKey(prev, id)]
                if e then
                    e.g = true
                    if prevP and (prevP.fall or p.fall) then e.ow = prev end
                    local dt = (prevP and prevP[5] and p[5]) and (p[5] - prevP[5]) or 0
                    if prevP and dt >= Graph.LIFT_SECS and Dist(prevP, p) <= Graph.LIFT_MOVE then
                        e.lift = true
                        e.wait = Graph.LIFT_WAIT[p[4]] or Graph.LIFT_WAIT_DEFAULT
                        e.ow = nil
                    end
                end
            end
        end
        prevP = p
        prev = id or prev
    end
    if added > 0 or joined > 0 then LP:Fire("GRAPH_CHANGED") end
    return added, joined
end

-- 3.12.10: Kante als Sackgasse sperren (gespeichert, wird bei der Wegsuche nicht mehr genommen)
function Graph:Block(a, b, why)
    if type(a) ~= "number" or type(b) ~= "number" or a == b then return false end
    G.blocked = type(G.blocked) == "table" and G.blocked or {}
    G.blocked[EdgeKey(a, b)] = { t = time and time() or 0, why = why or "FEST" }
    return true
end
function Graph:Unblock(a, b)
    if G.blocked and type(a) == "number" and type(b) == "number" then G.blocked[EdgeKey(a, b)] = nil end
end
function Graph:IsBlocked(a, b)
    return type(a) == "number" and type(b) == "number" and G.blocked and G.blocked[EdgeKey(a, b)] ~= nil or false
end

function Graph:Stats()
    local edges, yards = 0, 0
    for _, e in pairs(G.edges) do
        local a, b = nodes[e[1]], nodes[e[2]]
        if a and b then
            edges = edges + 1
            yards = yards + Dist(a, b)
        end
    end
    return { nodes = G.count, netNodes = G.netCount, edges = edges, yards = yards, gateways = #gwEdges,
             seedNodes = staticCount, seedEdges = staticEdges }
end

function Graph:NodeById(id) return nodes[id] end
function Graph:Count() return G.count or 0 end         -- 3.12.24: Anzahl Wegpunkte ohne Zaehlschleife
function Graph:Neighbors(id) return adj[id] end      -- Testroutine (T235)

------------------------------------------------------------------------
-- A*-Suche
------------------------------------------------------------------------
-- Binaerer Heap
local function HeapPush(h, item, prio)
    local n = #h + 1
    h[n] = { item, prio }
    while n > 1 do
        local p = math.floor(n / 2)
        if h[p][2] <= h[n][2] then break end
        h[p], h[n] = h[n], h[p]
        n = p
    end
end

local function HeapPop(h)
    local top = h[1]
    if not top then return nil end
    local last = h[#h]
    h[#h] = nil
    if #h > 0 then
        h[1] = last
        local n = 1
        while true do
            local l, r, s = n * 2, n * 2 + 1, n
            if h[l] and h[l][2] < h[s][2] then s = l end
            if h[r] and h[r][2] < h[s][2] then s = r end
            if s == n then break end
            h[s], h[n] = h[n], h[s]
            n = s
        end
    end
    return top[1], top[2]
end

local function EdgeCost(e, a, b)
    local d = Dist(a, b)
    local k = e[3]
    if k == "boat" or k == "zep" or k == "tram" or k == "portal" then
        return (e.secs or 120) * RUN_SPEED + d * 0.05
    elseif k == "w" then
        return d * 1.8
    elseif k == "s" then
        return d * 1.05
    elseif k == "seed" then
        return (e.len or d) * 0.98            -- 3.12.37: Laenge entlang der Punkte an der Kante
    elseif k == "road" then
        return (e.len or d) * Graph.ROAD_COST  -- 3.12.50 ST-2: Strasse aus den Spieldateien (Laenge entlang der Punkte)
    elseif k == "g" then
        return d
    end
    -- selbst gelaufen: oft gelaufene Wege leicht bevorzugen; unsichere Kante (moegliche Luecke) etwas teurer
    return d * ((e[4] or 1) >= 3 and 0.95 or 1.0) * (e.u and 1.25 or 1)
end

-- Luftlinie quer ueber unbekanntes Gelaende (Berge, Felsen, Wasser) ist teurer. So gewinnen
-- gelaufene Wege durch Tunnel, Paesse und um Berge herum. Werte zwischen festen Knoten werden
-- zwischengespeichert (die Gelaendekarte aendert sich nicht).
local TERRAIN_PENALTY = 1.6
local DANGER_MULT = 25        -- Wegstueck durch Gebiet mit zu starken Mobs: so viel teurer
local TERRAIN_MIN = 80        -- Yards: kuerzere Luftlinien ohne Pruefung (kurze Spruenge queren keinen Berg)
local unkCache, unkCount = {}, 0
local function VirtCost(a, b, zone, ka, kb)
    local d = Dist(a, b)
    local c = d * VIRT_MULT
    if d > TERRAIN_MIN and zone and LP.Terrain and LP.Terrain.Unknown then
        local key = (type(ka) == "number" and type(kb) == "number") and (ka < kb and ka .. ":" .. kb or kb .. ":" .. ka) or nil
        local u = key and unkCache[key]
        if not u then
            local ok, v = pcall(LP.Terrain.Unknown, LP.Terrain, zone, a, b)
            u = ok and v or 0
            if key then
                if unkCount > 60000 then wipe(unkCache) unkCount = 0 end
                unkCache[key] = u
                unkCount = unkCount + 1
            end
        end
        c = c * (1 + TERRAIN_PENALTY * u)
    end
    return c
end
function Graph:ClearTerrainCache() wipe(unkCache) unkCount = 0 end
-- 3.12.30 SP1: Groesse der Zwischenspeicher (Diagnose): Luftlinien-Nachbarn, Gelaende-Pruefungen
function Graph:CacheSizes() return virtCount, unkCount end

-- Liefert eine Liste von Punkten {inst, n, w, zone} und die Art ("graph"/"direct"/nil).
-- Jeder Punkt traegt in .via die Art der Kante, ueber die er erreicht wurde
-- ("v" = Luftlinie, sonst die Kantenart aus dem Wegenetz, "g" = Zonenuebergang).
-- knownOnly (3.12.35 UC-W1): nur gelaufene/geteilte Kanten und Uebergaenge; Luftlinie nur vom Start zum ersten und
-- vom letzten Knoten zum Ziel, jeweils hoechstens LP.Nav.ARRIVE Yards (genau die Regel von Nav.Known)
-- W3D: sKey/gKey (optional) = Ebene von Start/Ziel; dann Anschluss nur an Knoten dieser Ebene (false/nil = egal)
function Graph:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone, maxExpand, knownOnly, sKey, gKey)
    local S = { sInst, sn, sw, sZone }
    local T = { gInst, gn, gw, gZone }
    local ARRIVE = (LP.Nav and LP.Nav.ARRIVE) or 40

    -- Ziel direkt in derselben Zone und nah: Luftlinie genuegt
    if sInst == gInst and sZone == gZone and Dist(S, T) < (knownOnly and ARRIVE + 0.001 or 60)
       and not (Graph.On() and sKey and gKey and sKey ~= gKey) then          -- W3D: andere Ebene -> nie direkt
        return { S, { gInst, gn, gw, gZone, via = "v" } }, "direct", Dist(S, T)
    end

    local function nodeOf(id)
        if id == "S" then return S end
        if id == "T" then return T end
        return nodes[id]
    end

    local function heuristic(nd)
        if nd[1] ~= gInst then return 0 end
        return Dist(nd, T)
    end

    -- Pflichtregel: Wegstuecke durch Gebiete mit Mobs ab Spielerlevel + 3 meiden (Umweg, wenn es einen gibt)
    local Dg = LP.Danger
    local lim = Dg and Dg.pathRule and Dg.Limit and Dg:Limit()
    local function guarded(a, b, cost, kind)
        if not lim or a[1] ~= b[1] or kind == "boat" or kind == "zep" or kind == "tram" or kind == "portal" then return cost end
        if Dg:Segment(a[1], a[2], a[3], b[2], b[3]) >= lim then return cost * DANGER_MULT end
        return cost
    end

    local gScore = { S = 0 }
    local came = {}
    local via = {}
    local open = {}
    local closed = {}
    HeapPush(open, "S", heuristic(S))
    local expanded = 0

    local function relax(u, v, cost, kind)
        local tentative = gScore[u] + cost
        if gScore[v] == nil or tentative < gScore[v] then
            gScore[v] = tentative
            came[v] = u
            via[v] = kind
            HeapPush(open, v, tentative + heuristic(nodeOf(v)))
        end
    end

    -- Luftlinie: Gelaende nur pruefen, wenn sie ueberhaupt kuerzer sein kann als das Bekannte
    -- (die Pruefung macht sie nur teurer, nie billiger)
    local function relaxVirt(u, v, a, b, zone, ka, kb)
        local base = Dist(a, b) * VIRT_MULT
        local known = gScore[v]
        if known and gScore[u] + base >= known then return end
        relax(u, v, guarded(a, b, VirtCost(a, b, zone, ka, kb), "v"), "v")
    end

    while true do
        local u = HeapPop(open)
        if not u then break end
        if u == "T" then break end
        if not closed[u] then
            closed[u] = true
            expanded = expanded + 1
            if expanded > (maxExpand or MAX_EXPAND) then break end
            if expanded % 2 == 0 then LP:Yield("graph") end   -- teure Knoten (viele Nachbarn, Gelaende): oft pruefen
            local un = nodeOf(u)

            -- gespeicherte Kanten
            if u ~= "S" and adj[u] then
                for v, e in pairs(adj[u]) do
                    -- 3.12.10: als Sackgasse gesperrte Kanten nicht mehr nehmen
                    if not closed[v] and not (G.blocked and type(u) == "number" and type(v) == "number" and G.blocked[EdgeKey(u, v)])
                       and not (e.ow and e.ow ~= u) then        -- W3D: Sturz nur in Fallrichtung
                        local c = EdgeCost(e, un, nodes[v])
                        if e.lift then c = c + (e.wait or Graph.LIFT_WAIT_DEFAULT) * RUN_SPEED end   -- W3D: Aufzug warten
                        if (e[3] == "seed" or e[3] == "road") and lim then   -- 3.12.50: Strassen wie Startwege
                            -- 3.12.37: Startwege liegen fest – Mob-Level entlang der Kante einmal je Stand der Gefahrenkarte
                            local nv = nodes[v]
                            if e.dg ~= Dg.gen or not Dg:Ready() then
                                local a = nodes[e[1]]
                                local q, mx = e.pts, 0
                                local ln, lw = a[2], a[3]
                                for i = 1, (q and #q or 0), 2 do
                                    mx = math.max(mx, Dg:Segment(a[1], ln, lw, q[i], q[i + 1]))
                                    ln, lw = q[i], q[i + 1]
                                end
                                local b = nodes[e[2]]
                                e.dv = math.max(mx, Dg:Segment(a[1], ln, lw, b[2], b[3]))
                                e.dg = Dg:Ready() and Dg.gen or nil
                            end
                            relax(u, v, (un[1] == nv[1] and e.dv >= lim) and c * DANGER_MULT or c, e[3])
                        else
                            relax(u, v, guarded(un, nodes[v], c, e[3]), e[3])
                        end
                    end
                end
            end

            -- Luftlinien nur innerhalb derselben Zone
            -- 3.12.37: innere Punkte und Kreuzungen des Startwegnetzes (nur Startwege als Nachbarn) suchen keine
            -- Luftlinien: sie liegen auf bekannten Wegen, die die Suche ohnehin entlanggeht; Luftlinien gehen von den
            -- Enden des Startnetzes und von eigenen Knoten aus. Sonst pruefte jede Suche durchs Brachland hunderte Umkreise
            -- mit der Gelaendekarte (Orgrimmar -> Wegkreuz 52 ms statt < 16 ms).
            local zone, inst = un[4], un[1]
            if zone and un.si then
                -- Luftlinie zum Ziel nur aus der Naehe (VIRT_RANGE); weiter weg fuehren Startwege, Enden des Startnetzes
                -- und eigene Knoten hin (sonst eine Gelaendepruefung je Punkt des Startnetzes in der Zielzone)
                if zone == gZone and inst == gInst and not closed["T"] and Dist(un, T) <= (knownOnly and ARRIVE or VIRT_RANGE) then
                    relaxVirt(u, "T", un, T, zone)
                end
            elseif zone then
                local near = type(u) == "number" and virtCache[u]
                if not near then
                    near = self:NearSparse(inst, un[2], un[3], VIRT_RANGE, zone)
                    if type(u) == "number" then
                        if virtCount > 50000 then virtCache, virtCount = {}, 0 end
                        virtCache[u], virtCount = near, virtCount + 1
                    end
                end
                for _, v in ipairs(near) do
                    local nv = nodes[v]
                    -- W3D: Luftlinie zwischen Knoten nur draussen und in derselben Ebene; drinnen nur vom Start aus bis ARRIVE
                    local inside = (u ~= "S" and Inside(un, zone)) or Inside(nv, zone)
                    local okVirt
                    if u == "S" then okVirt = ((not knownOnly and not inside) or Dist(un, nv) <= ARRIVE)
                                              and (not sKey or not Graph.On() or nv.k == sKey)
                    else okVirt = not knownOnly and not inside and SameKey(un, nv) end
                    if v ~= u and not closed[v] and okVirt then
                        relaxVirt(u, v, un, nv, zone, u, v)
                    end
                end
                local gws = gwByZone[zone]
                if gws then
                    for _, v in ipairs(gws) do
                        local inside = (u ~= "S" and Inside(un, zone)) or (Graph.On() and Graph.INDOOR_ZONES[zone] == true)   -- W3D
                        if v ~= u and not closed[v] and nodes[v][1] == inst
                           and ((not knownOnly and not inside) or (u == "S" and Dist(un, nodes[v]) <= ARRIVE)) then
                            relaxVirt(u, v, un, nodes[v], zone, u, v)
                        end
                    end
                end
                if zone == gZone and inst == gInst and not closed["T"] and (not gKey or not Graph.On() or (u ~= "S" and un.k == gKey))
                   and ((not knownOnly and not (u ~= "S" and Inside(un, zone))) or (u ~= "S" and Dist(un, T) <= ARRIVE)) then
                    relaxVirt(u, "T", un, T, zone)
                end
            end
        end
    end

    if gScore["T"] == nil then
        if knownOnly then return nil end
        -- kein moeglicher Weg bekannt: Luftlinie als Notloesung
        if sInst == gInst then return { S, { gInst, gn, gw, gZone, via = "v" } }, "direct", Dist(S, T) end
        return nil
    end

    -- Kopien der Knoten (die gespeicherten Knoten bleiben unveraendert) mit Kantenart
    local path, cur = {}, "T"
    while cur do
        local nd = nodeOf(cur)
        local e = came[cur] and adj[came[cur]] and adj[came[cur]][cur]
        table.insert(path, 1, { nd[1], nd[2], nd[3], nd[4], via = via[cur], gw = nd.gw, name = nd.name, secs = e and e.secs,
                                id = type(cur) == "number" and cur or nil })
        -- 3.12.37: Punkte an einer Startweg-Kante (gespeichert von e[1] nach e[2]) zwischen came[cur] und cur einfuegen
        local q = e and e.pts
        if q then
            local fwd = e[1] == came[cur]
            local n = #q / 2
            for k = 1, n do
                local j = fwd and (n - k + 1) or k
                table.insert(path, 1, { nd[1], q[2 * j - 1], q[2 * j], nd[4], via = e[3] })
            end
        end
        cur = came[cur]
    end
    return path, "graph", gScore["T"]
end

------------------------------------------------------------------------
-- Hoehlen: Ziel drinnen -> erst zum Eingang, dann hinein; Start drinnen -> erst hinaus
------------------------------------------------------------------------
local function Mark(points, first)
    for i = first or 1, #points do points[i].cave = true end
    return points
end

local function Append(out, points, skipFirst)
    for i = skipFirst and 2 or 1, #points do out[#out + 1] = points[i] end
end

-- 3.12.75 ROUTE-Q R3W: Abkuerzung am Anfang des Weges. Die Suche schliesst den Spieler per Luftlinie an KNOTEN an, nicht an
-- die Strecke dazwischen. Laeuft eine Strasse dicht am Spieler vorbei, fuehrte der Weg erst zum Knoten (z. B. 33 yd) und dann auf
-- der Strasse zurueck – Pfeil zeigte nach wenigen Schritten zurueck (Tal der Pruefungen -> Klingenhuegel). Hier: der spaeteste
-- Wegpunkt, der hoechstens maxD Yards Luftlinie vom Start liegt und den Weg dorthin um mindestens 15 yd verkuerzt, wird direkt
-- angesteuert (Punkte dazwischen fallen weg). Nur gleiche Welt und Zone des Ziels, nicht durch Gebiete mit zu starken Mobs, nie auf ein Tor
-- selbst (wohl aber ueber ein Tor hinaus und zurueck: Haarnadel am Zonenrand).
Graph.SHORTCUT = 60
function Graph.ShortcutStart(path, maxD)
    if not path or #path < 3 then return path, 0 end
    maxD = maxD or Graph.SHORTCUT
    local S = path[1]
    local Dg = LP.Danger
    local lim = Dg and Dg.pathRule and Dg.Limit and Dg:Limit()
    local acc, best = 0, nil
    for j = 2, #path do
        local a, b = path[j - 1], path[j]
        if a[1] ~= S[1] or b[1] ~= S[1] or b.cave then break end
        acc = acc + Dist(a, b)
        if acc > maxD * 4 then break end
        if j >= 3 then
            local d = Dist(S, b)
            -- ueber ein Tor hinaus und zurueck in dieselbe Zone (Haarnadel am Zonenrand) darf abgekuerzt werden
            if d <= maxD and acc >= d + 15 and not b.gw and (b[4] == S[4] or not b[4] or not S[4])
               and not (lim and Dg:Segment(S[1], S[2], S[3], b[2], b[3]) >= lim) then
                best = j
            end
        end
    end
    if not best then return path, 0 end
    local out = { S }
    for j = best, #path do out[#out + 1] = path[j] end
    return out, best - 2
end

-- 3.12.76 ROUTE-Q R3W: Schleifen/Haarnadeln irgendwo im Weg entfernen. Kommt der Weg innerhalb von hoechstens 30 Wegpunkten
-- wieder auf <= near Yards an einen frueheren Punkt zurueck und ist das Stueck dazwischen mindestens minSave Yards lang, faellt es
-- weg (Eierjagd, Brachland: 55 yd hin und auf derselben Strasse zurueck). Nicht ueber Tore/Hoehlen/andere Welt, nicht durch Gebiete
-- mit zu starken Mobs.
function Graph.RemoveLoops(path, near, minSave)
    if not path or #path < 4 then return path, 0 end
    near, minSave = near or 15, minSave or 30
    local Dg = LP.Danger
    local lim = Dg and Dg.pathRule and Dg.Limit and Dg:Limit()
    local out, removed, i = { path[1] }, 0, 1
    while i < #path do
        local a = path[i]
        local best, acc = nil, 0
        for j = i + 1, math.min(#path, i + 30) do
            local p, q = path[j - 1], path[j]
            if q[1] ~= a[1] or q.gw or q.cave or p.gw or p.cave then break end
            acc = acc + Dist(p, q)
            if j >= i + 2 and Dist(a, q) <= near and acc - Dist(a, q) >= minSave
               and not (lim and Dg:Segment(a[1], a[2], a[3], q[2], q[3]) >= lim) then
                best = j
            end
        end
        if best then
            removed = removed + (best - i - 1)
            i = best
        else
            i = i + 1
        end
        out[#out + 1] = path[i]
    end
    return out, removed
end

-- 3.12.35 UC-W1: Weg nur ueber bekannte (gelaufene/geteilte) Kanten. Fuer Staedte mit mehreren Ebenen (Undercity):
-- die normale Suche nimmt kurze Luftlinien quer ueber Ebenen und gilt dann als "Weg unbekannt", obwohl ein gelaufener
-- Weg existiert. Ohne Hoehlen-Zwischenziele (dort bleibt die normale Suche).
function Graph:PathKnown(sInst, sn, sw, sZone, gInst, gn, gw, gZone, maxExpand)
    return self:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone, maxExpand, true)
end

-- maxExpand: hoechstens so viele Suchschritte (je Suche, 3.12.25; vorher eine globale Variable)
function Graph:Path(sInst, sn, sw, sZone, gInst, gn, gw, gZone, maxExpand)
    local Caves = LP.Caves
    local sc = Caves and Caves.At and Caves:At(sInst, sn, sw, gn, gw, true)
    local tc = Caves and Caves.At and Caves:At(gInst, gn, gw, sn, sw)
    if (not sc and not tc) or (sc and tc and Caves:Same(sc, tc)) then
        return self:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone, maxExpand)
    end
    local out, total = {}, 0
    local ci, cn, cw, cz = sInst, sn, sw, sZone
    if sc then
        -- drinnen: auf dem Weg zum Eingang (Innenraum, keine Gelaendefuehrung)
        local p, _, c = self:PathRaw(ci, cn, cw, cz, sc.inst, sc.n, sc.w, sc.map or cz, maxExpand)
        if not p then return self:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone, maxExpand) end
        Mark(p, 1)
        p[#p].cave = nil                       -- der Eingang selbst liegt draussen
        Append(out, p, false)
        total = total + (c or 0)
        ci, cn, cw, cz = sc.inst, sc.n, sc.w, sc.map or cz
    end
    if tc then
        local p, _, c = self:PathRaw(ci, cn, cw, cz, tc.inst, tc.n, tc.w, tc.map or gZone, maxExpand)
        if not p then return self:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone, maxExpand) end
        Append(out, p, #out > 0)
        total = total + (c or 0)
        local inner, _, c2 = self:PathRaw(tc.inst, tc.n, tc.w, tc.map or gZone, gInst, gn, gw, gZone, maxExpand)
        if not inner then inner, c2 = { { tc.inst, tc.n, tc.w, tc.map }, { gInst, gn, gw, gZone, via = "v" } }, 0 end
        Mark(inner, 2)
        Append(out, inner, true)
        total = total + (c2 or 0)
    else
        local p, _, c = self:PathRaw(ci, cn, cw, cz, gInst, gn, gw, gZone, maxExpand)
        if not p then return self:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone, maxExpand) end
        Append(out, p, #out > 0)
        total = total + (c or 0)
    end
    return out, "cave", total
end

------------------------------------------------------------------------
-- 3.12.12: Wegdaten zum Einsenden (/lp wege) und automatischer Versand (GSWEGE1, ueber die SavedVariables)
-- Inhalt: gelernte Kanten je Zone als Koordinatenfolgen (Zonenkarte, 1 Nachkommastelle, Punkte > 5 Yards
-- auseinander), Herkunft (selbst/geteilt), wie oft gelaufen; gesperrte Kanten; korrigierte NPC-Orte;
-- FEST-Ereignisse der letzten 7 Tage. Nie Spieler-, Charakter- oder Gildennamen.
------------------------------------------------------------------------
Graph.WEGE_PREFIX = "GSWEGE1"
Graph.WEGE_MAX = 200 * 1024             -- Zeichen in LevelPilotDB.wegeExport (aeltestes zuerst gekuerzt)
local WEGE_GAP = 5                      -- Yards: naehere Punkte werden ausgelassen
local FEST_DAYS = 7

local function R1(v) return math.floor((v or 0) * 10 + 0.5) / 10 end
local function MapXY(nd)
    local zone = nd[4]
    if not zone then return nil end
    local x, y = LP.Geo:ToMap(zone, nd[1], nd[2], nd[3])
    if not x then return nil end
    return R1(x), R1(y)
end

-- 3.12.17: Kontinentkarten (Flug, Schiff) gehoeren nicht zu den Wegdaten
local function IsContinent(map)
    return map ~= nil and LP.Geo:ContinentOf(map) == map
end
Graph.IsContinent = IsContinent

-- Ketten aus Kanten (gleiche Zone, gleiche Herkunft); filter(key, e) waehlt die Kanten aus
local function Chains(filter)
    local byZone = {}
    for key, e in pairs(G.edges or {}) do
        local a, b = G.nodes[e[1]], G.nodes[e[2]]
        if type(a) == "table" and type(b) == "table" and a[4] and a[4] == b[4] and not IsContinent(a[4])
           and (not filter or filter(key, e)) then
            local src = (e[3] == "s") and "geteilt" or "selbst"
            local z = byZone[a[4]] or {}
            byZone[a[4]] = z
            local g = z[src] or { adj = {}, edges = {} }
            z[src] = g
            g.adj[e[1]] = g.adj[e[1]] or {}
            g.adj[e[2]] = g.adj[e[2]] or {}
            g.adj[e[1]][e[2]] = e
            g.adj[e[2]][e[1]] = e
            g.edges[#g.edges + 1] = key
        end
    end
    local out = {}
    for zone, srcs in pairs(byZone) do
        local list = {}
        for src, g in pairs(srcs) do
            local used = {}
            local function deg(id) local n = 0 for _ in pairs(g.adj[id]) do n = n + 1 end return n end
            local function walk(start, nextId)
                local ids, cur, prev, runs = { start }, nextId, start, 0
                local e0 = g.adj[start][nextId]
                runs = e0[4] or 1
                used[EdgeKey(start, nextId)] = true
                while cur do
                    ids[#ids + 1] = cur
                    if deg(cur) ~= 2 then break end
                    local nx
                    for v in pairs(g.adj[cur]) do if v ~= prev and not used[EdgeKey(cur, v)] then nx = v end end
                    if not nx then break end
                    used[EdgeKey(cur, nx)] = true
                    runs = math.max(runs, g.adj[cur][nx][4] or 1)
                    prev, cur = cur, nx
                end
                -- Punkte: Zonenkarte, 1 Nachkommastelle, nur > WEGE_GAP Yards auseinander (Endpunkt immer)
                local pts, last, lvs, anyLv = {}, nil, {}, false
                for i, id in ipairs(ids) do
                    local nd = G.nodes[id]
                    if nd and (i == #ids or not last or Dist(last, nd) > WEGE_GAP) then
                        local x, y = MapXY(nd)
                        if x then
                            pts[#pts + 1] = x pts[#pts + 1] = y last = nd
                            local lvName = Graph.LvName(nd)
                            lvs[#lvs + 1] = lvName or ""         -- W3D: Ebenen-Angabe je Punkt (fuer die Auswertung)
                            if lvName then anyLv = true end
                        end
                    end
                end
                if #pts >= 4 then list[#list + 1] = { p = pts, src = src, n = runs, lv = anyLv and lvs or nil } end
            end
            for id in pairs(g.adj) do
                if deg(id) ~= 2 then
                    for v in pairs(g.adj[id]) do if not used[EdgeKey(id, v)] then walk(id, v) end end
                end
            end
            for id in pairs(g.adj) do            -- reine Ringe
                for v in pairs(g.adj[id]) do if not used[EdgeKey(id, v)] then walk(id, v) end end
            end
        end
        if #list > 0 then out[#out + 1] = { map = zone, name = LP.Geo:MapName(zone), edges = list } end
    end
    table.sort(out, function(a, b) return a.map < b.map end)
    return out
end

-- alle bzw. nur neue/geaenderte Daten seit dem letzten Versand (sent = LP.db.wegeSent)
function Graph:WegeData(sent, zoneFilter)
    local now = time and time() or 0
    local function edgeNew(key, e)
        if zoneFilter then
            local a = G.nodes[e[1]]
            if not (a and zoneFilter(a[4])) then return false end
        end
        return not sent or (sent.e[key] or 0) < (e[4] or 1)
    end
    local data = { zones = Chains(edgeNew), blocked = {}, npc = {}, fest = {} }
    for key, b in pairs(G.blocked or {}) do
        local ia, ib = key:match("^(%d+):(%d+)$")
        local a, c = G.nodes[tonumber(ia or "")], G.nodes[tonumber(ib or "")]
        if a and c and (not sent or not sent.b[key]) and (not zoneFilter or zoneFilter(a[4])) then
            local x1, y1 = MapXY(a)
            local x2, y2 = MapXY(c)
            if x1 and x2 then data.blocked[#data.blocked + 1] = { map = a[4], p = { x1, y1, x2, y2 }, why = tostring(b.why or "FEST"), t = b.t, key = key } end
        end
    end
    for id, r in pairs(type(LP.db.npcPos) == "table" and LP.db.npcPos or {}) do
        if type(r) == "table" and (not sent or (sent.n[id] or 0) < (r.t or 0)) and (not zoneFilter or zoneFilter(r[1])) then
            -- 3.12.17: old/new einheitlich [x, y] (Karte in map; liegt der Ort im Datenpaket auf einer anderen Karte,
            -- zusaetzlich oldMap). Ort im Datenpaket: der naechste Fundort auf derselben Karte (nicht der erste).
            -- nopack: NPC hat im Datenpaket keinen Ort (z. B. neue Forever-NPCs) – kein "nicht da".
            local o = LP.Recorder and LP.Recorder.PackSpawn and LP.Recorder.PackSpawn(id, { r[1], r[2] or 0, r[3] or 0 })
            if not o and type(r.o) == "table" then o = r.o end
            data.npc[#data.npc + 1] = { id = id, map = r[1], new = { R1(r[2]), R1(r[3]) },
                                        old = o and { R1(o[2]), R1(o[3]) } or nil,
                                        oldMap = o and o[1] ~= r[1] and o[1] or nil,
                                        nopack = not o or nil, t = r.t }
        end
    end
    table.sort(data.npc, function(a, b) return a.id < b.id end)
    for _, f in ipairs(type(LP.db.festLog) == "table" and LP.db.festLog or {}) do
        if type(f) == "table" and (f.t or 0) >= now - FEST_DAYS * 86400 and (not sent or (f.t or 0) > (sent.f or 0))
           and (not zoneFilter or zoneFilter(f.map)) then
            data.fest[#data.fest + 1] = { map = f.map, x = f.x, y = f.y, t = f.t, blocked = f.blocked and true or false }
        end
    end
    return data
end

-- Zone fuer "/lp wege <Zone>": UiMapID oder Teil des Namens
local function ZoneFilter(arg)
    if not arg or arg == "" then return nil end
    local id = tonumber(arg)
    if id then return function(m) return m == id end end
    arg = arg:lower()
    return function(m) local n = m and LP.Geo:MapName(m) return n and n:lower():find(arg, 1, true) ~= nil end
end

function Graph:WegeText(arg)
    local filter = ZoneFilter(arg)
    local d = self:WegeData(nil, filter)
    local out = {}
    local env = _G.GoldSentinelTest and _G.GoldSentinelTest.Env and _G.GoldSentinelTest.Env() or {}
    out[#out + 1] = string.format("LevelPilot %s – Wegdaten · %s · Client %s (%s)", LP.version, date("%d.%m.%Y %H:%M"),
        tostring(env.client), tostring(env.build))
    local edges = 0
    for _, z in ipairs(d.zones) do
        out[#out + 1] = string.format("Zone %d %s: %d Wege", z.map, tostring(z.name), #z.edges)
        for _, e in ipairs(z.edges) do
            edges = edges + 1
            local pts = {}
            for i = 1, #e.p, 2 do pts[#pts + 1] = string.format("%.1f,%.1f", e.p[i], e.p[i + 1]) end
            out[#out + 1] = "  " .. e.src .. " " .. e.n .. "x: " .. table.concat(pts, " ")
        end
    end
    out[#out + 1] = string.format("Gesperrt: %d", #d.blocked)
    for _, b in ipairs(d.blocked) do
        out[#out + 1] = string.format("  Zone %d: %.1f,%.1f %.1f,%.1f %s %s", b.map, b.p[1], b.p[2], b.p[3], b.p[4], b.why,
            b.t and date("%d.%m.%Y %H:%M", b.t) or "?")
    end
    out[#out + 1] = string.format("NPC-Orte: %d", #d.npc)
    for _, n in ipairs(d.npc) do
        out[#out + 1] = string.format("  NPC %d Zone %d: %s -> %.1f,%.1f", n.id, n.map,
            n.old and ((n.oldMap and ("Zone " .. n.oldMap .. " ") or "") .. string.format("%.1f,%.1f", n.old[1], n.old[2]))
                or L["nicht im Datenpaket"], n.new[1], n.new[2])
    end
    out[#out + 1] = string.format("FEST (7 Tage): %d", #d.fest)
    for _, f in ipairs(d.fest) do
        out[#out + 1] = string.format("  Zone %s: %.1f,%.1f %s%s", tostring(f.map), f.x or 0, f.y or 0,
            f.t and date("%d.%m.%Y %H:%M", f.t) or "?", f.blocked and " gesperrt" or "")
    end
    local text = table.concat(out, "\n")
    if #text > 120000 then
        text = text:sub(1, 120000) .. "\n… " .. L["gekürzt – /lp wege <Zone> zeigt eine einzelne Zone"]
    end
    return text, edges
end

function Graph:ShowWege(arg)
    local text = self:WegeText(arg)
    LP.Backup:ShowText(L["Wegdaten"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."]
        .. " " .. L["Wird auch automatisch gemeldet."], text)
end

-- beim Ausloggen und /reload: neue/geaenderte Wegdaten als GSWEGE1 in LevelPilotDB.wegeExport
function Graph:WegeExport()
    if not LP.db.wegeAuto then return false end
    if LP.Virtual and LP.Virtual.active then return false end
    local GT = _G.GoldSentinelTest
    if not (GT and GT.Encode) or type(LevelPilotDB) ~= "table" then return false end
    local sent = type(LP.db.wegeSent) == "table" and LP.db.wegeSent or {}
    sent.e = type(sent.e) == "table" and sent.e or {}
    sent.b = type(sent.b) == "table" and sent.b or {}
    sent.n = type(sent.n) == "table" and sent.n or {}
    local d = self:WegeData(sent)
    if #d.zones == 0 and #d.blocked == 0 and #d.npc == 0 and #d.fest == 0 then return false end
    -- Groesse begrenzen: Zonen nur so viele, wie unter die Grenze passen (der Rest kommt beim naechsten Mal)
    local list = type(LevelPilotDB.wegeExport) == "table" and LevelPilotDB.wegeExport or {}
    LevelPilotDB.wegeExport = list
    local rep = { f = 1, kind = "wege", addon = "LevelPilot", version = LP.version, time = time(),
                  id = string.format("LevelPilot-wege-%d-%06x", time(), math.random(0, 0xFFFFFF)),
                  env = GT.Env and GT.Env() or nil, zones = {}, blocked = {}, npc = d.npc, fest = d.fest }
    for _, b in ipairs(d.blocked) do rep.blocked[#rep.blocked + 1] = { map = b.map, p = b.p, why = b.why, t = b.t } end
    local budget = self.WEGE_MAX - 4096
    local function size() return #GT.Encode(rep) end
    local taken = {}
    for _, z in ipairs(d.zones) do
        rep.zones[#rep.zones + 1] = z
        if size() > budget then rep.zones[#rep.zones] = nil break end
        taken[#taken + 1] = z.map
    end
    local s = self.WEGE_PREFIX .. GT.Encode(rep)
    list[#list + 1] = s
    local total = 0
    for _, x in ipairs(list) do total = total + #x end
    while total > self.WEGE_MAX and #list > 1 do total = total - #table.remove(list, 1) end
    -- als versandt merken (nur, was im Bericht steht)
    local inZone = {}
    for _, m in ipairs(taken) do inZone[m] = true end
    for key, e in pairs(G.edges or {}) do
        local a = G.nodes[e[1]]
        if a and inZone[a[4]] then sent.e[key] = e[4] or 1 end
    end
    for _, b in ipairs(d.blocked) do sent.b[b.key] = true end
    for _, n in ipairs(d.npc) do sent.n[n.id] = n.t or 0 end
    for _, f in ipairs(d.fest) do if (f.t or 0) > (sent.f or 0) then sent.f = f.t end end
    LP.db.wegeSent = sent
    return true, #s
end

LP:On("PLAYER_LOGOUT", function() LP.Try("Wegdaten", Graph.WegeExport, Graph) end)
