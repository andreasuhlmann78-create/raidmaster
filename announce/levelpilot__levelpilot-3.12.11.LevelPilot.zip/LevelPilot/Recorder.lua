-- LevelPilot - Aufzeichnung
-- 1) Quests: Questgeber, Position, Level, Zielorte (Hotspots), Abgabe-NPC
-- 2) Dienste: Haendler, Reparatur, Gasthaus
-- 3) Wege: tatsaechlich gelaufene Strecken -> sichere Kanten im Wegenetz
--
-- Datenformat LP.db.qdb[id]:
--   n = Name, l = Level, f = "A"/"H", s = {map,x,y,npc}, e = {map,x,y,npc},
--   o = { [zielIndex] = { {map,x,y,anzahl}, ... } }, item = Start per Gegenstand,
--   t = Zeitstempel, net = von anderem Spieler, by = Anzahl Bestaetigungen

local _, LP = ...
local R = {}
LP:RegisterModule("Recorder", R)

local function Round1(v) return math.floor(v * 10 + 0.5) / 10 end

local function PlayerMapPoint()
    local _, _, _, map, x, y = LP.Geo:Player()
    if not map then return nil end
    return { map, Round1(x), Round1(y) }
end

local function FactionCode()
    return LP:PlayerFaction() == "Horde" and "H" or "A"
end

------------------------------------------------------------------------
-- Quest-Aufzeichnung
------------------------------------------------------------------------
local pendingStart = {}  -- [questID] = {map,x,y,npc,item}
local lastProgress = {}  -- [questID] = { [obj] = erfuellt }

function R:Entry(id, create)
    -- virtuelle Reise: nie in die echte Questdatenbank schreiben (Wegwerf-Eintrag fuer Aufrufer)
    if LP.Virtual and LP.Virtual.active then return create and {} or nil end
    local e = LP.db.qdb[id]
    if not e and create then
        e = { t = LP:Now() }
        LP.db.qdb[id] = e
    end
    return e
end

-- Eigene Beobachtung uebernimmt Vorrang vor Netzwerkdaten
local function Own(e)
    if e.net then e.net = nil end
    e.t = LP:Now()
end

local function NpcName()
    if UnitExists("questnpc") then return LP.SafeValue(UnitName("questnpc")) end
    if UnitExists("npc") then return LP.SafeValue(UnitName("npc")) end
    return nil
end

function R:OnQuestDetail()
    if LP.Virtual and LP.Virtual.active then return end   -- virtuelle Reise: nichts aufzeichnen
    if not LP.db.recordQuests then return end
    local id = GetQuestID and GetQuestID()
    if not id or id == 0 then return end
    local pt = PlayerMapPoint()
    if not pt then return end
    local npc = NpcName()
    pt[4] = npc
    pendingStart[id] = { pt = pt, item = not npc, title = GetTitleText() }
end

function R:OnQuestAccepted(logIndex, questID)
    if LP.Virtual and LP.Virtual.active then return end   -- virtuelle Reise: nichts aufzeichnen
    if not LP.db.recordQuests or not questID or questID == 0 then return end
    local title, level
    if logIndex then title, level = LP.API.Entry(logIndex) end
    local p = pendingStart[questID]
    local e = self:Entry(questID, true)
    local isNew = not e.n
    Own(e)
    e.n = title or (p and p.title) or e.n
    e.l = (level and level > 0) and level or e.l
    e.f = FactionCode()
    if p then
        e.s = p.pt
        e.item = p.item or nil
    end
    pendingStart[questID] = nil
    LP.QuestDB:Invalidate(questID)
    self:ScanProgress()   -- Ausgangsstand der Ziele merken
    LP:Fire("QUEST_RECORDED", questID, isNew)
end

function R:OnQuestComplete()
    if LP.Virtual and LP.Virtual.active then return end   -- virtuelle Reise: nichts aufzeichnen
    if not LP.db.recordQuests then return end
    local id = GetQuestID and GetQuestID()
    if not id or id == 0 then return end
    local pt = PlayerMapPoint()
    if not pt then return end
    pt[4] = NpcName()
    local e = self:Entry(id, true)
    Own(e)
    e.n = e.n or GetTitleText()
    e.e = pt
    LP.QuestDB:Invalidate(id)
    LP:Fire("QUEST_RECORDED", id, false)
end

-- Fortschritt eines Questziels -> Hotspot an der aktuellen Position
local function AddHotspot(e, obj, pt)
    e.o = e.o or {}
    local list = e.o[obj] or {}
    e.o[obj] = list
    for _, h in ipairs(list) do
        if h[1] == pt[1] and math.abs(h[2] - pt[2]) < 3 and math.abs(h[3] - pt[3]) < 3 then
            local c = (h[4] or 1)
            h[2] = Round1((h[2] * c + pt[2]) / (c + 1))
            h[3] = Round1((h[3] * c + pt[3]) / (c + 1))
            h[4] = math.min(c + 1, 50)
            return
        end
    end
    if #list < 5 then
        list[#list + 1] = { pt[1], pt[2], pt[3], 1 }
    end
end

function R:ScanProgress()
    if not LP.db.recordQuests then return end
    if LP.Virtual and LP.Virtual.active then return end   -- virtuelle Reise: nichts aufzeichnen (Bericht 3.9.0: qdb[7734])
    for _, q in ipairs(LP.API.Quests()) do
        local questID = q.id
        do
            local prev = lastProgress[questID] or {}
            local now = {}
            for o, ob in ipairs(LP.API.Objectives(q.index)) do
                local have = ob.have or (ob.finished and 1 or 0)
                now[o] = have
                if prev[o] and have > prev[o] then
                    local pt = PlayerMapPoint()
                    if pt then
                        local e = self:Entry(questID, true)
                        AddHotspot(e, o, pt)
                        LP.QuestDB:Invalidate(questID)
                    elseif LP.char.inDungeon and LP.char.inDungeon ~= 0 then
                        -- Fortschritt in einer Instanz: Quest gehoert zu diesem Dungeon (lernt neue Forever-Quests)
                        local e = self:Entry(questID, false)
                        if e and not e.dg then
                            e.dg = LP.char.inDungeon
                            LP.QuestDB:Invalidate(questID)
                        end
                    end
                end
            end
            lastProgress[questID] = now
        end
    end
end

-- NPC bietet eine geplante Quest nicht an -> fuer 15 Minuten nicht mehr planen
function R:CheckOffered(available)
    local step = LP.Engine and LP.Engine:Current()
    if not step or step.t ~= "ACCEPT" or not step.id then return end
    if not LP.Geo:DistToMapPoint(step.map, step.x, step.y) then return end
    if LP.Geo:DistToMapPoint(step.map, step.x, step.y) > 25 then return end
    for _, id in ipairs(available) do
        if id == step.id then return end
    end
    LP.char.notOffered[step.id] = LP:Now()
    LP.Planner:Replan()
end

------------------------------------------------------------------------
-- Dienste (Haendler / Reparatur / Gasthaus)
------------------------------------------------------------------------
function R:RecordService(kind)
    if LP.Virtual and LP.Virtual.active then return end   -- virtuelle Reise: nichts aufzeichnen
    local pt = PlayerMapPoint()
    local name = LP.SafeValue(UnitName("npc"))
    if not pt or not name then return end
    local key = name .. "@" .. pt[1]
    local v = LP.db.vendors[key] or {}
    v.map, v.x, v.y, v.name = pt[1], pt[2], pt[3], name
    -- NPC-ID merken: damit kann der Name in jeder Sprache angezeigt werden
    local guid = UnitGUID and LP.SafeValue(UnitGUID("npc"))
    local nid = guid and strsplit and tonumber(select(6, strsplit("-", guid)) or "")
    if nid then v.id = nid end
    v.f = FactionCode()
    if kind == "merchant" then
        v.vendor = true
        if CanMerchantRepair and CanMerchantRepair() then v.repair = true end
    elseif kind == "inn" then
        v.inn = true
    end
    LP.db.vendors[key] = v
    LP.QuestDB:InvalidateServices()
end

------------------------------------------------------------------------
-- Flugpunkte (beim Oeffnen der Flugkarte)
------------------------------------------------------------------------
function R:RecordTaxi()
    if LP.Virtual and LP.Virtual.active then return end   -- virtuelle Reise: nichts aufzeichnen
    if not (C_TaxiMap and C_TaxiMap.GetAllTaxiNodes) then return end
    local mapID = GetTaxiMapID and GetTaxiMapID()
    if not mapID then return end
    local ok, list = pcall(C_TaxiMap.GetAllTaxiNodes, mapID)
    if not ok or type(list) ~= "table" then return end
    local reachable = Enum.FlightPathState and Enum.FlightPathState.Reachable
    local current = Enum.FlightPathState and Enum.FlightPathState.Current
    for _, node in ipairs(list) do
        if node.name and node.position then
            local x, y = node.position:GetXY()
            local key = node.name
            local tx = LP.db.taxi[key] or {}
            local oldX, oldY, oldMap = tx.x, tx.y, tx.map
            tx.name, tx.map, tx.x, tx.y = node.name, mapID, Round1(x * 100), Round1(y * 100)
            tx.known = nil
            -- hier steht man: exakter Eichpunkt (Zonenposition des Flugmeisters)
            if node.state == current and current then
                local _, _, _, pmap, px, py = LP.Geo:Player()
                if pmap then tx.zmap, tx.zx, tx.zy = pmap, Round1(px), Round1(py) end
            elseif oldMap ~= tx.map or oldX ~= tx.x or oldY ~= tx.y then
                tx.zmap, tx.zx, tx.zy = nil, nil, nil       -- Knoten neu oder verschoben: neu eichen
                LP.Geo:ResetTaxi()
            end
            LP.db.taxi[key] = tx
            if node.state == reachable or node.state == current then LP.char.taxiKnown[key] = true end
        end
    end
end

------------------------------------------------------------------------
-- Weg-Aufzeichnung
------------------------------------------------------------------------
local trail = {}          -- { {inst, n, w, zone, t}, ... }
local lastMove = 0
local SAMPLE_DIST = 12    -- Yards zwischen zwei Punkten
local JUMP_DIST = 80      -- Sprung -> Teleport/Ruhestein: Spur trennen
local FLUSH_POINTS = 40
local RDP_EPS = 6

-- Ramer-Douglas-Peucker (eigene Umsetzung)
local function PerpDist(p, a, b)
    local dn, dw = b[2] - a[2], b[3] - a[3]
    local len2 = dn * dn + dw * dw
    if len2 == 0 then return math.sqrt((p[2] - a[2]) ^ 2 + (p[3] - a[3]) ^ 2) end
    local t = ((p[2] - a[2]) * dn + (p[3] - a[3]) * dw) / len2
    t = math.max(0, math.min(1, t))
    local cn, cw = a[2] + t * dn, a[3] + t * dw
    return math.sqrt((p[2] - cn) ^ 2 + (p[3] - cw) ^ 2)
end

local function Simplify(pts, first, last, eps, out)
    local maxD, idx = 0, nil
    for i = first + 1, last - 1 do
        local d = PerpDist(pts[i], pts[first], pts[last])
        if d > maxD then maxD, idx = d, i end
    end
    if idx and maxD > eps then
        Simplify(pts, first, idx, eps, out)
        out[#out] = nil
        Simplify(pts, idx, last, eps, out)
    else
        out[#out + 1] = pts[first]
        out[#out + 1] = pts[last]
    end
end

function R:FlushTrail(discard)
    local pts = trail
    trail = {}
    if discard or #pts < 2 then return end
    -- Spur nach Zone und Schwimmen aufteilen, damit Kanten sauber zugeordnet sind
    local simple = {}
    Simplify(pts, 1, #pts, RDP_EPS, simple)
    local swim = false
    for _, p in ipairs(pts) do if p.swim then swim = true break end end
    local added = LP.Graph:AddPolyline(simple, swim and "w" or "r", false)
    if added > 0 then LP:Fire("PATH_RECORDED", simple) end
end

local function CanRecord()
    if not LP.db.recordPaths then return false end
    if UnitOnTaxi("player") or UnitIsDeadOrGhost("player") then return false end
    if IsInInstance and IsInInstance() then return false end
    if UnitInVehicle and UnitInVehicle("player") then return false end
    return true
end

function R:SamplePath()
    if LP.Virtual and LP.Virtual.active then return end   -- virtuelle Reise: nichts aufzeichnen
    if not CanRecord() then
        if #trail > 0 then self:FlushTrail(false) end
        return
    end
    local inst, n, w, map = LP.Geo:Player()
    if not inst then return end
    local now = GetTime()
    local last = trail[#trail]
    if last then
        local d = LP.Geo:Dist(last[2], last[3], n, w)
        if last[1] ~= inst or d > JUMP_DIST then
            self:FlushTrail(false)
        elseif d < SAMPLE_DIST then
            if now - lastMove > 6 and #trail > 1 then self:FlushTrail(false) end
            return
        end
    end
    lastMove = now
    trail[#trail + 1] = { inst, n, w, map, now, swim = IsSwimming and IsSwimming() or nil }
    if #trail >= FLUSH_POINTS then
        local keep = trail[#trail]
        self:FlushTrail(false)
        trail[1] = keep
    end
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
------------------------------------------------------------------------
-- 3.12.11: echte Orte von Questgebern (beim Ansprechen steht man direkt neben dem NPC). Damit werden falsche
-- Koordinaten aus dem Datenpaket korrigiert (z. B. in WoW Forever veraenderte Zonen).
------------------------------------------------------------------------
function R:RecordNpc()
    if LP.Virtual and LP.Virtual.active then return end
    if not LP.db.recordQuests then return end
    local guid = UnitGUID and LP.SafeValue(UnitGUID("npc"))
    local id = type(guid) == "string" and guid:match("^Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")
    id = tonumber(id)
    local pt = PlayerMapPoint()
    if not id or not pt then return end
    LP.db.npcPos = type(LP.db.npcPos) == "table" and LP.db.npcPos or {}
    local old = LP.db.npcPos[id]
    if old and old[1] == pt[1] and math.abs(old[2] - pt[2]) < 0.5 and math.abs(old[3] - pt[3]) < 0.5 then
        old.c = math.min((old.c or 1) + 1, 999)
        return
    end
    local N = LevelPilotData and LevelPilotData.N
    local s = N and N[id] and N[id].s and N[id].s[1]
    LP.db.npcPos[id] = { pt[1], pt[2], pt[3], t = LP:Now(), c = 1, o = s and { s[1], s[2], s[3] } or nil }
    LP.QuestDB:Invalidate()
    if LP.QuestDB.InvalidateServices then LP.QuestDB:InvalidateServices() end
end

function R:Init()
    LP:On("QUEST_DETAIL", function() R:OnQuestDetail() R:RecordNpc() end)
    for _, ev in ipairs({ "QUEST_PROGRESS", "QUEST_GREETING", "GOSSIP_SHOW" }) do LP:On(ev, function() R:RecordNpc() end) end
    LP:On("QUEST_ACCEPTED", function(_, a, b)
        local logIndex, questID = LP.API.AcceptedArgs(a, b)
        R:OnQuestAccepted(logIndex, questID)
    end)
    LP:On("QUEST_COMPLETE", function() R:OnQuestComplete() R:RecordNpc() end)
    LP:On("QUEST_LOG_UPDATE", function() LP:Throttle("rec_progress", 1, function() R:ScanProgress() end) end)
    LP:On("MERCHANT_SHOW", function() R:RecordService("merchant") end)
    LP:On("TAXIMAP_OPENED", function() R:RecordTaxi() end)
    LP:On("CONFIRM_BINDER", function() R:RecordService("inn") end)
    -- Ruhestein gebunden: Ort merken (fuer die Ruhestein-Planung)
    LP:On("HEARTHSTONE_BOUND", function()
        local pt = PlayerMapPoint()
        if pt then
            LP.char.bind = { map = pt[1], x = pt[2], y = pt[3], name = GetBindLocation and GetBindLocation() or "?" }
            LP.Planner:Replan()
        end
    end)
    -- echte EP bei der Abgabe (WoW Forever kann von Classic abweichen, z.B. Dungeon-Quests)
    LP:On("QUEST_TURNED_IN", function(_, questID, xp)
        if not LP.db.recordQuests or not questID or type(xp) ~= "number" or xp <= 0 then return end
        local e = R:Entry(questID, true)
        local st = LP.Planner.inLog and LP.Planner.inLog[questID]
        e.n = e.n or (st and st.title)
        e.x, e.xl = xp, UnitLevel("player") or 1
        LP.QuestDB:Invalidate(questID)
    end)
    LP:On("PLAYER_DEAD", function()
        -- Tod kurz nach der Spur (z.B. Sturz) -> die letzten Punkte sind kein sicherer Weg
        R:FlushTrail(true)
    end)
    LP:On("GOSSIP_SHOW", function()
        if UnitExists("npc") and C_GossipInfo and C_GossipInfo.GetOptions then
            for _, o in ipairs(C_GossipInfo.GetOptions() or {}) do
                if o.type == "binder" or (o.icon and tostring(o.icon):find("Binder")) then
                    R:RecordService("inn")
                end
            end
        end
        if C_GossipInfo and C_GossipInfo.GetAvailableQuests then
            local ids = {}
            for _, q in ipairs(C_GossipInfo.GetAvailableQuests() or {}) do ids[#ids + 1] = q.questID end
            R:CheckOffered(ids)
        end
    end)
    LP:On("PLAYER_ENTERING_WORLD", function() R:ScanProgress() end)
    LP:Ticker("path", 1, function() R:SamplePath() end)
end
