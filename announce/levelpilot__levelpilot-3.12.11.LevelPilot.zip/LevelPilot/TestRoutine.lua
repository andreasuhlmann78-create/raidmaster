-- LevelPilot - Testroutine (/lp testroutine), Bericht über GoldSentinelTest
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Nur im Testmodus (LP:DevOnly). Läuft in Häppchen (höchstens 8 ms je Bild), nur ausserhalb des Kampfes.
-- Echte Daten: Sicherung vorher, Wiederherstellung in place nachher, Vergleich je Hauptschlüssel ("Sandbox").
-- Aktionen mit Folgen (Kaufen, Reparieren, Anlegen, Quests, Flug, Senden …) laufen über LP.Act und werden
-- während des Laufs nur mitgeschrieben (LP.Act.dry). Es wird keine Blizzard-Funktion ersetzt: Simulationen
-- laufen über setfenv auf eigene Funktionen, über eigene Tabellen (LP.API, LP.Game) und Köderwerte.
-- Ergebnisse nur über T:Check / T:Skip / T:Client. Testfall-IDs wie in testroutine-levelpilot.txt.

local _, LP = ...
local L = LP.L
local TR = {}
LP.TestRoutine = TR

local NOT_YET = "noch nicht automatisiert – folgt"
local ONLY_FOREVER = "LevelPilot nur für WoW Forever"

------------------------------------------------------------------------
-- Testfälle (ID, Bereich, Name) – über alle Versionen gleich
------------------------------------------------------------------------
TR.IDS = {
    { "T01", "A", "alle Module gestartet" },
    { "T02", "A", "Dateien ohne Modul geladen" },
    { "T03", "A", "Version .toc = Code" },
    { "T04", "A", "Version Datenpaket .toc = Code" },
    { "T05", "A", "Interface-Nummer passt zum Client" },
    { "T06", "A", "GoldSentinelGame Version 2" },
    { "T07", "A", "GoldSentinelTest geladen und angemeldet" },
    { "T08", "A", "echte Erkennung" },
    { "T09", "A", "Weichen mit SetTestFlavor(\"forever\")" },
    { "T10", "A", "Weichen mit SetTestFlavor(\"era\")" },
    { "T11", "A", "Weichen mit SetTestFlavor(\"tbc\")" },
    { "T12", "A", "Weichen mit SetTestFlavor(\"retail\")" },
    { "T13", "A", "SetTestFlavor(nil) stellt alles zurück" },
    { "T14", "A", "ohne GoldSentinelGame" },
    { "T15", "A", "Reihenfolge in der .toc" },
    { "T16", "B", "Fenster-Befehle" },
    { "T17", "B", "Modus-Befehle" },
    { "T18", "B", "Wegpunkt und Suche" },
    { "T19", "B", "Sprache per Befehl" },
    { "T20", "B", "Teilen, Gruppe, Bilanz" },
    { "T21", "B", "Protokoll, Diagnose, Messung, Selbsttest" },
    { "T22", "B", "Reise-Befehle" },
    { "T23", "B", "Debug, Zurück, Reset" },
    { "T24", "B", "unbekannter Befehl" },
    { "T25", "B", "Guide-Fenster LevelPilotFrame" },
    { "T26", "B", "Schritt-Menü LevelPilotStepMenu" },
    { "T27", "B", "Hinweise oben (Toasts) LevelPilotToasts" },
    { "T28", "B", "Minimap-Button LevelPilotMinimapButton" },
    { "T29", "B", "Pfeil LevelPilotArrow" },
    { "T30", "B", "Zentrale LevelPilotCenter, alle 8 Reiter" },
    { "T31", "B", "jede Option der Zentrale einmal an und aus" },
    { "T32", "B", "alle 12 Stepper" },
    { "T33", "B", "Sprachknöpfe" },
    { "T34", "B", "Zentrale » Daten: Knöpfe" },
    { "T35", "B", "Fenster der virtuellen Reise LevelPilotVirtualFrame" },
    { "T36", "B", "Gruppen-Panel LevelPilotGroupPanel" },
    { "T37", "B", "Aktionsleiste und Tastenbelegung" },
    { "T38", "B", "Spenden-Fenster" },
    { "T39", "B", "Planung" },
    { "T40", "B", "Planner:KillXPFormula – Werte" },
    { "T41", "B", "Planner:GreyLevel" },
    { "T42", "B", "Planner:GreenXPFactor / KillXP ohne Messung" },
    { "T43", "B", "Dungeon-Faktoren" },
    { "T44", "B", "Questlevel bei Quest-Kills" },
    { "T45", "B", "Speedrun-Filter" },
    { "T46", "B", "Dungeon-Übersicht" },
    { "T47", "B", "Diagnose" },
    { "T48", "B", "Engine-Funktionen" },
    { "T49", "B", "Automatik Annehmen/Abgeben/Gossip" },
    { "T50", "B", "Navigation" },
    { "T51", "B", "Wegenetz Graph" },
    { "T52", "B", "Gelände Terrain" },
    { "T53", "B", "Höhlen Caves" },
    { "T54", "B", "Gefahr Danger" },
    { "T55", "B", "Geo" },
    { "T56", "B", "QuestDB" },
    { "T57", "B", "Namen" },
    { "T58", "B", "Recorder (Aufzeichnung)" },
    { "T59", "B", "Comm: Kodieren und Empfangen" },
    { "T60", "B", "Comm: Begrenzung je Absender" },
    { "T61", "B", "Comm: Senden" },
    { "T62", "B", "Comm: Zonen-Abgleich" },
    { "T63", "B", "Gruppe (LvPilotG)" },
    { "T64", "B", "Social (Teilen, Gruppensuche, Partner)" },
    { "T65", "B", "Session" },
    { "T66", "B", "Comfort" },
    { "T67", "B", "Supply (Vorräte, Belohnung anlegen)" },
    { "T68", "B", "Advisor (Assistent)" },
    { "T69", "B", "Hints" },
    { "T70", "B", "Pins (Karte, Fundstellen)" },
    { "T71", "B", "Plates (Namensplaketten)" },
    { "T72", "B", "Tooltips" },
    { "T73", "B", "Calib (Lernwerte)" },
    { "T74", "B", "Calib: EP-Messung je Kill" },
    { "T75", "B", "Protocol (Fehler-Protokoll)" },
    { "T76", "B", "Backup (Sichern/Laden)" },
    { "T77", "B", "Measure (/lp messen)" },
    { "T78", "B", "Sprache: Hilfsfunktionen" },
    { "T79", "B", "Core-Hilfen" },
    { "T80", "B", "alle Ereignisse einmal" },
    { "T81", "B", "alle Ticker einmal" },
    { "T82", "B", "OnUpdate-Treiber" },
    { "T83", "B", "virtuelle Reise kurz" },
    { "T84", "B", "virtuelle Reise 1–60, beide Modi" },
    { "T85", "B", "Reise abbrechen" },
    { "T86", "B", "Datenpaket-Inhalt" },
    { "T87", "B", "Werkzeuge ausserhalb des Spiels (Tools/: Sicherung.ps1, Wiederherstellen.ps1, lp_sammeln.py …)" },
    { "T88", "C", "API.ItemCooldown mit geschützten start/duration (Ruhestein)" },
    { "T89", "C", "Recorder:RecordService mit geschütztem UnitName(\"npc\")" },
    { "T90", "C", "Tooltip-Hook OnShow mit geschütztem GameTooltipTextLeft1:GetText() und geschütztem tt:GetUnit()" },
    { "T91", "C", "Calib:OnLoot mit geschütztem Beute-Text" },
    { "T92", "C", "CHAT_MSG_ADDON mit geschütztem prefix/msg/sender (Comm und Group)" },
    { "T93", "C", "Plates:ForUnit mit geschütztem UnitName/UnitGUID" },
    { "T94", "C", "Calib:ReadTarget / OnXPUpdate mit geschütztem UnitLevel/UnitXP" },
    { "T95", "C", "Measure-Zeile mit geschütztem UnitClassification" },
    { "T96", "C", "Calib:ObserveUnit mit geschützter GUID und geschütztem Level" },
    { "T97", "C", "Namensvergleich mit geschütztem Namen" },
    { "T98", "C", "EP-Anzeige mit geschütztem UnitXP/UnitXPMax (UI-Ticker im Kampf)" },
    { "T99", "C", "geschützte Werte im echten Kampf" },
    { "T100", "C", "Questlog-Funktionen" },
    { "T101", "C", "API.GreenRange ohne C_QuestLog.GetTrivialRange und GetQuestGreenRange" },
    { "T102", "C", "Händler" },
    { "T103", "C", "Gegenstände" },
    { "T104", "C", "Taschen" },
    { "T105", "C", "Talentpunkte" },
    { "T106", "C", "Hints Known ohne IsSpellKnown/IsPlayerSpell" },
    { "T107", "C", "Gruppensuche ohne ChatFrame_OpenChat" },
    { "T108", "C", "Addon-Kanal ohne ChatFrame_RemoveChannel" },
    { "T109", "C", "Jäger ohne GetPetHappiness/GetPetFoodTypes" },
    { "T110", "C", "Metadaten und AddOns" },
    { "T111", "C", "Senden ohne C_ChatInfo" },
    { "T112", "C", "weitere alte Globals ohne Prüfung" },
    { "T113", "C", "Names: collectgarbage wirft" },
    { "T114", "C", "Aktionsleiste im Kampf" },
    { "T115", "C", "Belohnung anlegen und Hinweis-Knöpfe im Kampf" },
    { "T116", "C", "Testroutine und Kampf" },
    { "T117", "C", "ADDON_ACTION_BLOCKED für LevelPilot" },
    { "T118", "C", "Kampflog nicht angemeldet" },
    { "T119", "D", "Laden in Classic Era" },
    { "T120", "D", "Hinweis \"für WoW Forever gebaut\"" },
    { "T121", "D", "Weichen auf dem alten Weg" },
    { "T122", "D", "TBC und Retail" },
    { "T123", "E", "Neuinstallation (leere SavedVariables)" },
    { "T124", "E", "Migration Speedrun-Strenge (3.10)" },
    { "T125", "E", "Migration Sprache" },
    { "T126", "E", "Migration Protokoll" },
    { "T127", "E", "Überlagerung der Flugpunkte nach einem Abbruch" },
    { "T128", "E", "alte Fassung (Beispieldaten im Test)" },
    { "T129", "E", "beschädigte Einträge (nil, falscher Typ)" },
    { "T130", "E", "Datenpaket fehlt, falsches Format, zu alt" },
    { "T131", "E", "QuestieDB vorhanden, aber zu alt oder unvollständig" },
    { "T132", "E", "Einstellungen pro Charakter" },
    { "T133", "F", "Schlüssel in jeder Sprache vorhanden" },
    { "T134", "F", "Formatplatzhalter" },
    { "T135", "F", "Format mit Werten" },
    { "T136", "F", "jede Sprache aktivieren, Hauptfenster öffnen" },
    { "T137", "F", "Sprachen ohne Schrift" },
    { "T138", "F", "Namen je Sprache" },
    { "T139", "F", "Texte von GoldSentinelGame" },
    { "T140", "G", "gemeinsame Dateien mit anderen GoldSentinel-Addons" },
    { "T141", "G", "keine globalen Namen überschrieben" },
    { "T142", "G", "Fehler-Handler-Kette" },
    { "T143", "G", "Schnittstellen zu anderen GoldSentinel-Addons" },
    { "T144", "G", "Questie mit und ohne" },
    { "T145", "G", "Addon-Präfixe angemeldet" },
    { "T146", "H", "UI:Refresh (Ticker 1 s)" },
    { "T147", "H", "Engine:CheckSteps (Ticker 0,5 s)" },
    { "T148", "H", "Navigations-Treiber (OnUpdate alle 0,05 s: Nav:Recalc(false), Pfeil, Minikarte)" },
    { "T149", "H", "Pins-Treiber und Weltkarte" },
    { "T150", "H", "Planner:Replan(true) (Ticker 15 s und bei Ereignissen)" },
    { "T151", "H", "Graph:Path für eine lange Route (Orgrimmar -> Wegkreuz)" },
    { "T152", "H", "Drosselung bei \"vom Weg ab\"" },
    { "T153", "H", "Plaketten, Tooltip und Beobachtung je Einheit" },
    { "T154", "H", "Comm" },
    { "T155", "H", "Planung je Reiseschritt" },
    { "T156", "H", "alle 1-s-Ticker zusammen (ui, caves, recorder, session)" },
    { "T157", "H", "Speicher" },
    { "T158", "I", "absichtlicher Fehler über LP:Safe" },
    { "T159", "I", "Lua-Fehler ausserhalb eines pcall" },
    { "T160", "I", "Fehler in einem Ereignis-Handler" },
    { "T161", "I", "Fehler in einem LP:Fire-Listener" },
    { "T162", "I", "Modul-Startfehler in der Diagnose" },
    { "T163", "I", "Ticker-Fehler" },
    { "T164", "I", "Fehler der virtuellen Reise" },
    { "T165", "I", "Bericht gespeichert und datenschutzkonform" },
    { "T166", "I", "Testfall-IDs eindeutig und vollständig" },
    { "T167", "J", "[V Schritt 1] GoldSentinelGame unverändert und vor allen eigenen Dateien" },
    { "T168", "J", "[V Schritt 1] G.Status() in der Diagnose" },
    { "T169", "J", "[V Schritt 1] Namensvergleiche über G.SameName" },
    { "T170", "J", "[V Schritt 2.1] Datenpaket-Version passt" },
    { "T171", "J", "[V Launch] Interface-Nummer in beiden .toc" },
    { "T172", "J", "[Z1a] EP je Kill nach Levelunterschied" },
    { "T173", "J", "[Z1b] Abschlag für grüne Monster nur in Forever" },
    { "T174", "J", "[Z1c] Weg-Kills mit mittlerem Monsterlevel" },
    { "T175", "J", "[Z1d] Quest-Kills mit Questlevel" },
    { "T176", "J", "[Z2] Dungeon-Werte Forever 0,36 / 1,5, Classic 1,0" },
    { "T177", "J", "[Z3] Messung EP je Kill: geschützt, erholt, Gruppe" },
    { "T178", "J", "[Z4] Gruppen-EP-Hinweis in Forever" },
    { "T179", "J", "[Z5a] \"Zeit bis 60\" klar beschriftet" },
    { "T180", "J", "[Z5b] beide Modi vergleichen, echter Modus bleibt" },
    { "T181", "J", "[Z5c] Reisebericht nennt die Herkunft der Werte" },
    { "T182", "J", "[Z NICHT ÄNDERN] EP-Tabelle und Regeln unverändert" },
    { "T183", "J", "[Z Test 1] Zeiten 1–60 Normal und Speedrun" },
    { "T184", "J", "[K1] /lp reise bericht ohne Lua-Fehler (global L)" },
    { "T185", "J", "[K2] Ruhestein-Abklingzeit mit geschützten Werten" },
    { "T186", "J", "[K3] Recorder: geschützter NPC-Name" },
    { "T187", "J", "[K4] Tooltip-Titel und GetUnit geschützt" },
    { "T188", "J", "[K5] Calib:OnLoot geschützt" },
    { "T189", "J", "[K6] CHAT_MSG_ADDON geschützt (Comm und Group)" },
    { "T190", "J", "[K7] collectgarbage in Names mit pcall" },
    { "T191", "J", "[K8] Hints Known ohne Rückgabe true" },
    { "T192", "J", "[K9] Gruppen-Text ohne ChatFrame_OpenChat" },
    { "T193", "J", "[K10] Kanal ausblenden ohne ChatFrame_RemoveChannel" },
    { "T194", "J", "[K11] GreenRange mit UnitQuestTrivialLevelRange" },
    { "T195", "J", "[K12] Talent- und Jägerfunktionen" },
    { "T196", "J", "[K13] Dropraten ohne Kampflog" },
    { "T197", "J", "[K14] Navigation: 0,5 s Mindestpause auch bei \"off\", nicht neu rechnen auf Flügen" },
    { "T198", "J", "[K15] alle Ticker in LP:Safe" },
    { "T199", "J", "[K16] Protokoll mit beschädigtem Eintrag startet" },
    { "T200", "J", "[K17] Measure: UnitClassification geschützt" },
    { "T201", "J", "[K18] Tooltips nutzen LP.API.IsQuestDone" },
    { "T202", "J", "[K19] eigene Erkennung auf LP.Game umgeleitet" },
    { "T203", "J", "[K20] Mindestversion des Datenpakets" },
    { "T204", "J", "[K Frage] Standardwerte mit echten Folgen" },
    { "T205", "J", "[R] Datenpaket nur in der gemeinsamen ZIP" },
    -- 3.12.5: Grundeinstellung der Automatiken und einmalige Hinweise (anweisung-levelpilot-automatiken.txt)
    { "T206", "J", "[A1] Neuinstallation: Reparieren/Flug an, Nachkaufen/Belohnung aus" },
    { "T207", "J", "[A1] Bestehende Einstellungen bleiben" },
    { "T208", "J", "[A2a] Hinweis Nachkaufen einmal, nichts gekauft" },
    { "T209", "J", "[A2b] Hinweis Belohnung einmal, nichts gewählt oder angelegt" },
    { "T210", "J", "[A2c] Option an -> kein Hinweis" },
    { "T211", "J", "[A2d] Im Kampf -> kein Hinweis" },
    { "T212", "J", "[3.12.5-1] Drop-Messung: erneut geöffnete Leiche zählt nicht doppelt" },
    -- 3.12.6: offen-Punkt 2 (Berufszauber im Client)
    { "T213", "J", "[3.12.6-2] Berufszauber: C_SpellBook und IsPlayerSpell im Client" },
    -- 3.12.7: Routenbefund aus Mulgore und Lua-Fehler in CheckNav
    { "T214", "J", "[3.12.7-1] Abgabebereite Quests in der Nähe zuerst (Mulgore Fall 1 und 2)" },
    { "T215", "J", "[3.12.7-2] Kein Ziel und keine Linie im Gebirge (unplausible Orte)" },
    { "T216", "J", "[3.12.7-3] Protokoll CheckNav mit geschützten Werten" },
    -- 3.12.8: Thunder Bluff und Mulgore zusammen planen, Vorrang-Ziele nie vor nahe Abgaben
    { "T217", "J", "[3.12.8-1] Thunder Bluff und Mulgore: ein Fokus, kein FOKUS-Eintrag, Vorrang-Ziel nach nahen Abgaben" },
    -- 3.12.9: Linie nur über bekannte Wege
    { "T218", "J", "[3.12.9-1] Wegnetz statt Luftlinie: ohne bekannten Weg keine Linie, nur Pfeil \"Weg unbekannt\"" },    -- 3.12.10: Sackgassen nur aus reiner Laufzeit
    { "T219", "J", "[3.12.10-1] FEST nur bei Laufzeit: 10 min AFK, 2 min stehen + 1 min laufen, 4 min im Kreis" },    -- 3.12.11: echte NPC-Orte
    { "T220", "J", "[3.12.11-1] Echter Ort eines Questgebers korrigiert das Ziel" },
}
TR.SHORT = { T01 = true, T02 = true, T03 = true, T04 = true, T06 = true, T07 = true, T08 = true, T39 = true,
             T50 = true, T56 = true, T133 = true }

------------------------------------------------------------------------
-- Hilfen
------------------------------------------------------------------------
local IMPL, SKIP, CLIENT = {}, {}, {}
TR.IMPL, TR.SKIP, TR.CLIENT = IMPL, SKIP, CLIENT

local function G() return LP.Game end
local function Count(t) local n = 0 for _ in pairs(type(t) == "table" and t or {}) do n = n + 1 end return n end
local function Near(a, b, eps) return type(a) == "number" and math.abs(a - b) <= (eps or 0.01) end
local function Ms() return debugprofilestop and debugprofilestop() or (GetTime() * 1000) end
local function S(v) return tostring(v) end

-- body ausführen, danach restore() – auch im Fehlerfall – und den Fehler weitergeben
local function Guard(body, restore)
    local ok, a, b, c = pcall(body)
    restore()
    if not ok then error(a, 0) end
    return a, b, c
end

-- Simulierte Spielversion (GoldSentinelGame.SetTestFlavor), immer zurück
local function WithFlavor(fl, body)
    local g = G()
    if not g or not g.SetTestFlavor then error("GoldSentinelGame fehlt", 0) end
    g.SetTestFlavor(fl)
    return Guard(body, function() g.SetTestFlavor(nil) end)
end

-- Einstellung vorübergehend setzen (über LP.db), immer zurück
local function WithSetting(map, body)
    local old = {}
    for k, v in pairs(map) do old[k] = { LP.db[k] } LP.db[k] = v end
    return Guard(body, function() for k, o in pairs(old) do LP.db[k] = o[1] end end)
end

-- calib.killxp / dungeonxp leer (gemessene Werte ausblenden), immer zurück
local function WithEmptyCalib(body)
    local c = LevelPilotDB and type(LevelPilotDB.calib) == "table" and LevelPilotDB.calib
    if not c then return body() end
    local kx, dx = c.killxp, c.dungeonxp
    c.killxp, c.dungeonxp = {}, nil
    return Guard(body, function() c.killxp, c.dungeonxp = kx, dx end)
end

-- Umgebung eigener Funktionen umleiten (setfenv). fake[k] == false bedeutet nil. _G wird nie beschrieben.
local function WithEnv(funcs, fake, body)
    local proxy = setmetatable({}, {
        __index = function(_, k)
            local v = fake[k]
            if v ~= nil then if v == false then return nil end return v end
            return _G[k]
        end,
        __newindex = function(_, k, v) _G[k] = v end,
    })
    local saved = {}
    for i, f in ipairs(funcs) do
        if type(f) == "function" then saved[i] = getfenv(f) setfenv(f, proxy) end
    end
    return Guard(body, function()
        for i, f in ipairs(funcs) do if saved[i] then setfenv(f, saved[i]) end end
    end)
end
TR.WithEnv = WithEnv

-- flache Kopie einer C_-Tabelle ohne bestimmte Felder (für WithEnv)
local function Without(tbl, ...)
    if type(tbl) ~= "table" then return false end
    local t = {}
    for k, v in pairs(tbl) do t[k] = v end
    for i = 1, select("#", ...) do t[(select(i, ...))] = nil end
    return t
end

-- Köderwerte: gelten innerhalb von body als geschützt (nur LP.Game, synchron, immer zurück)
local function WithSecret(baits, body)
    local g = G()
    if not g then error("GoldSentinelGame fehlt", 0) end
    local set = {}
    for _, v in ipairs(baits) do set[v] = true end
    local orig = g.IsSecret
    g.IsSecret = function(v) return (v ~= nil and set[v] == true) or orig(v) end
    return Guard(body, function() g.IsSecret = orig end)
end

-- simulierter Kampf über LP:InCombat
local function WithCombat(state, body)
    local old = LP.testCombat
    LP.testCombat = state
    return Guard(body, function() LP.testCombat = old end)
end

local function Act() return LP.Act end
local function ActMark() return #LP.Act.log end
local function ActSince(mark, name)
    local n = 0
    for i = mark + 1, #LP.Act.log do if not name or LP.Act.log[i].name == name then n = n + 1 end end
    return n
end

local function Meta(addon, field)
    local f = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
    if not f then return nil end
    local ok, v = pcall(f, addon, field)
    return ok and v or nil
end

------------------------------------------------------------------------
-- A. Laden und Erkennung
------------------------------------------------------------------------
local MODULES = { "Actions", "Advisor", "Backup", "Calib", "Caves", "Center", "Comfort", "Comm", "Danger", "Engine", "Geo",
    "Graph", "Group", "Hints", "Measure", "Names", "Nav", "Pins", "Planner", "Plates", "Protocol", "QuestDB", "Recorder",
    "SelfTest", "Session", "Social", "Supply", "Terrain", "Tooltips", "UI", "Virtual" }

IMPL.T01 = function()
    local have, missing = {}, {}
    for _, m in ipairs(LP.modules) do have[m.name] = true end
    for _, n in ipairs(MODULES) do if not have[n] then missing[#missing + 1] = n end end
    local init = {}
    for n in pairs(LP.initErrors or {}) do init[#init + 1] = n end
    if #missing > 0 or #init > 0 or #LP.modules ~= #MODULES then
        return false, string.format("%d Module, fehlend: %s, Startfehler: %s", #LP.modules, table.concat(missing, ","),
            table.concat(init, ",")), #MODULES .. " Module, keine Startfehler"
    end
    return true, #LP.modules .. " Module"
end

IMPL.T02 = function()
    local miss = {}
    for _, k in ipairs({ "API", "Act", "Donate", "Seed", "Dungeons", "Gateways", "CaveSeed", "CaveForeverMaps", "LocaleEN" }) do
        if type(LP[k]) ~= "table" then miss[#miss + 1] = k end
    end
    local n = 0
    for _, c in ipairs({ "en", "fr", "es", "mx", "pt", "it", "ru", "ko", "cn", "tw" }) do if type(LP.Locales[c]) == "table" then n = n + 1 end end
    if #miss > 0 or n ~= 10 or _G.LevelPilot ~= LP then
        return false, "fehlend: " .. table.concat(miss, ",") .. " · Übersetzungen " .. n, "alle Tabellen, 10 Übersetzungen"
    end
    return true, "10 Übersetzungen"
end

IMPL.T03 = function()
    local toc = Meta("LevelPilot", "Version")
    return toc == LP.version, S(toc), LP.version
end

IMPL.T04 = function()
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return true, "Datenpaket LevelPilot_Data fehlt" end
    local toc = Meta("LevelPilot_Data", "Version")
    return toc == d.version and d.format == 1, S(toc) .. " / " .. S(d.version) .. " / Format " .. S(d.format), "gleich, Format 1"
end
CLIENT.T05 = "/dump select(4, GetBuildInfo()) – steht die Zahl in beiden .toc? Addon-Liste: LevelPilot nicht 'veraltet'"

IMPL.T06 = function()
    local g = _G.GoldSentinelGame
    if type(g) ~= "table" then return false, "fehlt", "Version 2" end
    local miss = {}
    for _, k in ipairs({ "IsSecret", "AnySecret", "Safe", "InCombat", "Short", "CleanName", "SameName", "Status", "SetTestFlavor", "Recalc" }) do
        if type(g[k]) ~= "function" then miss[#miss + 1] = k end
    end
    local ok = g.version == 2 and LP.Game == g and #miss == 0 and g.flavor ~= nil and type(SlashCmdList.GOLDSENTINELGAME) == "function"
    return ok, "Version " .. S(g.version) .. (#miss > 0 and (" fehlt: " .. table.concat(miss, ",")) or ""), "Version 2, alles vorhanden"
end

IMPL.T07 = function()
    local GT = _G.GoldSentinelTest
    if type(GT) ~= "table" then return false, "fehlt", "geladen" end
    local reg = GT.registry and GT.registry.LevelPilot
    local ok = (GT.version or 0) >= 1 and reg and reg.db == LevelPilotDB and type(LevelPilotDB.gsTest) == "table"
    return ok and true or false, "Version " .. S(GT.version) .. (reg and " angemeldet" or " nicht angemeldet"), "angemeldet mit LevelPilotDB"
end

IMPL.T08 = function()
    local g = G()
    if not g then return false, "GoldSentinelGame fehlt", "vorhanden" end
    if g.flavor == "forever" then
        local ok = g.IsModern and g.HasSecrets and not g.IsOldAPI and LP.API.modern == true and LP.API.Forever() == true
        return ok and true or false, g.Status(), "Forever, modern"
    end
    if g.flavor == "era" then
        local ok = g.IsOldAPI and LP.API.modern == false
        return ok and true or false, g.Status(), "Era, alte API"
    end
    return true, g.Status()
end

local function FlavorBlock(fl)
    return function()
        return WithEmptyCalib(function()
            return WithSetting({ questLogMax = 0, dungeonMobXP = 0, dungeonQuestXP = 0, forever = true }, function()
                return WithFlavor(fl, function()
                    local g, P = G(), LP.Planner
                    local f, mq = LP.API.Forever(), LP.API.MaxQuests()
                    local dg, dq, gr = P:DungeonXPFactor(), P:DungeonQuestFactor(), P:GreenXPFactor(-3)
                    local note = LP.Social.ForeverGroupNote("x")
                    local got = string.format("Forever %s, Questlog %d, Dungeon %.2f/%.2f, grün %.2f", S(f), mq, dg, dq, gr)
                    if fl == "forever" then
                        return f == true and mq == 40 and Near(dg, 0.36) and Near(dq, 1.5) and Near(gr, 0.85) and note ~= "x", got,
                            "Forever true, 40, 0.36/1.50, 0.85, Gruppenhinweis"
                    elseif fl == "retail" then
                        return g.IsModern and not g.IsForever and f == false and mq == 20, got, "modern, nicht Forever, 20"
                    else
                        local okT = (fl ~= "tbc") or g.IsTBC
                        return okT and g.IsOldAPI and f == false and mq == 20 and Near(dg, 1) and Near(dq, 1) and Near(gr, 1) and note == "x",
                            got, "alt, Forever false, 20, 1/1, 1"
                    end
                end)
            end)
        end)
    end
end
local flavorBefore
IMPL.T09 = function() flavorBefore = G() and G().flavor return FlavorBlock("forever")() end
IMPL.T10 = FlavorBlock("era")
IMPL.T11 = FlavorBlock("tbc")
IMPL.T12 = FlavorBlock("retail")
IMPL.T13 = function()
    local g = G()
    if not g then return false, "GoldSentinelGame fehlt", "vorhanden" end
    local st = g.Status()
    return (flavorBefore == nil or g.flavor == flavorBefore) and not st:find("%[Test%]"), g.flavor .. " · " .. st, S(flavorBefore)
end

IMPL.T14 = function()
    local saved = LP.Game
    LP.Game = nil
    return Guard(function()
        local a = LP.SafeValue(5) == 5
        local b = LP.SameName("Rokan-Realm", "Rokan") == true and LP.SameName("Rokan-Realm", "rokan") == false
        return a and b, "SafeValue " .. S(a) .. ", SameName " .. S(b), "beide true"
    end, function() LP.Game = saved end)
end
SKIP.T15 = "wird von addon-check geprüft"

------------------------------------------------------------------------
-- B. Funktionen
------------------------------------------------------------------------
local function Slash(msg) SlashCmdList.LEVELPILOT(msg) end

IMPL.T17 = function()
    local real = LP.char.mode
    return Guard(function()
        Slash("speed")
        local a = LP.char.mode == "speed" and LP.Planner:IsSpeed()
        Slash("normal")
        local b = LP.char.mode == "normal" and not LP.Planner:IsSpeed()
        return a and b, "speed " .. S(a) .. ", normal " .. S(b), "beide true"
    end, function() LP.Planner:SetMode(real) end)
end

IMPL.T19 = function()
    local before = LP.db.language
    return Guard(function()
        local r1 = LP:SetLanguage(nil)
        local r2 = LP:SetLanguage("xx")
        return r1 == false and r2 == false, "ohne Kürzel " .. S(r1) .. ", xx " .. S(r2), "false, false"
    end, function() LP.db.language = before LP:ResetLanguageCache() end)
end

IMPL.T23 = function()
    local mark = ActMark()
    local pos = { LP.db.framePos, LP.db.arrowPos, LP.db.centerPos }
    return Guard(function()
        Slash("reset")
        local n = ActSince(mark, "ReloadUI")
        return n == 1, "ReloadUI mitgeschrieben: " .. n, "1 (nicht ausgeführt)"
    end, function() LP.db.framePos, LP.db.arrowPos, LP.db.centerPos = pos[1], pos[2], pos[3] end)
end

IMPL.T24 = function()
    local was = LP.UI:IsShown()
    Slash("xyz") Slash("xyz")
    return LP.UI:IsShown() == was, S(LP.UI:IsShown()), S(was)
end

IMPL.T27 = function()
    LP.UI:Toast({ key = "test", sev = 1, text = "Test" })
    LP.UI:ClearToasts()
    return true
end

IMPL.T30 = function()
    local f = _G.LevelPilotCenter
    local wasShown = f and f:IsShown()
    return Guard(function()
        if not wasShown then LP.Center:Toggle() end
        for _, k in ipairs({ "route", "dungeons", "data", "share", "assist", "comfort", "extras", "settings" }) do LP.Center:Select(k) end
        local esc = false
        for _, n in ipairs(UISpecialFrames or {}) do if n == "LevelPilotCenter" then esc = true end end
        return esc, "8 Reiter, Escape " .. S(esc), "Escape schliesst"
    end, function() if f and not wasShown then f:Hide() end end)
end

IMPL.T38 = function()
    local t = LP.Donate.AddonTitle()
    return t == "LevelPilot", S(t), "LevelPilot"
end

IMPL.T39 = function()
    if (UnitLevel("player") or 1) >= 60 then return true, "Level 60" end
    LP.Planner:BuildCandidates()
    LP.Planner:Replan(true)
    local st, cur = LP.Engine:Steps(), LP.Engine:Current()
    return #st > 0 and cur and cur.key ~= nil and cur.t ~= nil, #st .. " Schritte, Zustand " .. S(LP.Planner.state), "> 0 Schritte"
end

local KXP = { { 20, 20, 145 }, { 20, 22, 159.5 }, { 20, 24, 174 }, { 20, 25, 174 }, { 20, 17, 105.45 }, { 20, 14, 65.91 },
              { 20, 13, 0 }, { 5, 1, 14 }, { 60, 60, 345 }, { 60, 64, 414 }, { 60, 48, 86.25 }, { 60, 47, 0 } }
IMPL.T40 = function()
    local bad = {}
    for _, e in ipairs(KXP) do
        local v = LP.Planner:KillXPFormula(e[1], e[2])
        if not Near(v, e[3], 0.01) then bad[#bad + 1] = string.format("(%d,%d)=%.2f statt %.2f", e[1], e[2], v, e[3]) end
    end
    return #bad == 0, #bad == 0 and "12 Werte" or table.concat(bad, "; "), "alle 12 Werte"
end

IMPL.T41 = function()
    local P, bad = LP.Planner, {}
    for _, e in ipairs({ { 5, 0 }, { 6, 1 }, { 10, 4 }, { 39, 31 }, { 40, 31 }, { 60, 47 } }) do
        if P:GreyLevel(e[1]) ~= e[2] then bad[#bad + 1] = e[1] .. "->" .. S(P:GreyLevel(e[1])) end
    end
    return #bad == 0, table.concat(bad, ", "), "5->0, 6->1, 10->4, 39->31, 40->31, 60->47"
end

IMPL.T42 = function()
    return WithEmptyCalib(function()
        return WithSetting({ forever = true }, function()
            return WithFlavor("forever", function()
                local P = LP.Planner
                local g3, g2 = P:GreenXPFactor(-3), P:GreenXPFactor(-2)
                local k17, k18 = P:KillXP(20, 17), P:KillXP(20, 18)
                return Near(g3, 0.85) and Near(g2, 1) and Near(k17, 89.64) and Near(k18, 118.64),
                    string.format("%.2f %.2f %.2f %.2f", g3, g2, k17, k18), "0.85 1.00 89.64 118.64"
            end)
        end)
    end)
end

IMPL.T43 = function()
    return WithEmptyCalib(function()
        return WithFlavor("forever", function()
            local P = LP.Planner
            local r = {}
            WithSetting({ dungeonMobXP = 0, forever = true }, function() r[1], r[2] = P:DungeonXPFactor() end)
            WithSetting({ dungeonMobXP = 50, forever = true }, function() r[3], r[4] = P:DungeonXPFactor() end)
            WithSetting({ dungeonQuestXP = 200, forever = true }, function() r[5], r[6] = P:DungeonQuestFactor() end)
            local ok = Near(r[1], 0.36) and r[2] == "auto" and Near(r[3], 0.5) and r[4] == "set" and Near(r[5], 2) and r[6] == "set"
            return ok, string.format("%.2f %s · %.2f %s · %.2f %s", r[1], S(r[2]), r[3], S(r[4]), r[5], S(r[6])), "0.36 auto · 0.50 set · 2.00 set"
        end)
    end)
end

IMPL.T44 = function()
    local P = LP.Planner
    local a, b = P:QuestKillLevel({ level = 18 }, 20), P:QuestKillLevel({}, 20)
    return a == 18 and b == 20, S(a) .. ", " .. S(b), "18, 20"
end

IMPL.T47 = function()
    local txt = table.concat(LP.Planner:DiagLines(), "\n")
    local ok = txt:find("Version " .. LP.version, 1, true) or txt:find(LP.version, 1, true)
    return ok and (not G() or txt:find(G().Status(), 1, true)) and true or false, "Diagnose " .. #txt .. " Zeichen", "Version und G.Status()"
end

IMPL.T50 = function()
    LP.Nav:Recalc(true)
    if not LP.Nav.target then return true, "kein Ziel (Schritt ohne Ort)" end
    local d = LP.Nav.RemainingDistance and LP.Nav:RemainingDistance()
    if not LP.Nav.hasPath then return false, S(LP.Nav.pathError), "Weg gefunden" end
    return type(d) == "number" and d >= 0, "Weg " .. (d and LP:FormatDist(d) or "?"), "Zahl >= 0"
end

IMPL.T55 = function()
    local Geo = LP.Geo
    local i, n, w = Geo:ToWorld(1411, 0.5, 0.5)
    local cont = Geo.ContinentOf and Geo:ContinentOf(1411)
    local name = Geo:MapName(1411)
    return i ~= nil and type(name) == "string" and name ~= "" and (cont == nil or cont == 1414),
        "Kontinent " .. S(cont) .. ", Name " .. S(name), "1414, Name"
end

IMPL.T56 = function()
    local c = LP.QuestDB:Counts()
    local q = LP.QuestDB:Get(844) or LP.QuestDB:Get(7)
    local ok = type(c) == "table" and type(c.pack) == "number" and type(c.seed) == "number" and type(c.own) == "number"
    return ok and (q == nil or q.name ~= nil), string.format("Paket %s, Start %s, eigene %s", S(c.pack), S(c.seed), S(c.own)), "Zahlen"
end

IMPL.T57 = function()
    local st = LP.Names:StatusText()
    return type(st) == "string" and st ~= "", st, "nicht leer"
end

IMPL.T60 = function()
    local rate = LP.Comm.RateOk
    if not rate then return false, "Comm.RateOk fehlt", "zugänglich" end
    local who = "LPTest-" .. tostring(math.random(100000, 999999))
    local r80, r81
    for i = 1, 81 do local r = rate(who) if i == 80 then r80 = r elseif i == 81 then r81 = r end end
    return r80 == true and r81 == false, "80: " .. S(r80) .. ", 81: " .. S(r81), "80: true, 81: false"
end

IMPL.T63 = function()
    local Gp = LP.Group
    local who = "LPTester-Test"
    local saved = Gp.members[who:match("^([^%-]+)")]
    return Guard(function()
        Gp:OnMessage("S\t5\t10\tGOTO\t0\ttext", who)
        local m = Gp.members["LPTester"]
        local ok = m and m.level == 5 and m.pct == 10 and m.text == "text"
        return ok and true or false, ok and "Mitglied erkannt" or "nicht erkannt", "level 5, pct 10, text"
    end, function() Gp.members["LPTester"] = saved end)
end

IMPL.T65 = function()
    local M = LP.Session.Money
    local a, b, c = M(12345), M(250), M(5)
    local sum = LP.Session:SummaryText()
    return a == "1g 23s" and b == "2s 50c" and c == "5c" and type(sum) == "string", a .. " · " .. b .. " · " .. c, "1g 23s · 2s 50c · 5c"
end

IMPL.T66 = function()
    local D = LP.Comfort.Dur
    local a, b = D(59), D(nil)
    local mark = ActMark()
    -- Reparieren mit simuliertem Händler: nur mitschreiben
    WithSetting({ autoRepair = true }, function()
        WithEnv({ LP.Comfort.Repair }, { CanMerchantRepair = function() return true end,
            GetRepairAllCost = function() return 100, true end, GetMoney = function() return 100000 end }, function()
            LP.Comfort:Repair()
        end)
    end)
    local n = ActSince(mark, "RepairAllItems")
    return b == "?" and type(a) == "string" and n == 1, "Dur(59) " .. a .. ", Reparieren mitgeschrieben " .. n, "?, 1"
end

IMPL.T67 = function()
    local needs = LP.Supply:Needs()
    local mark = ActMark()
    local pend = LP.Supply.EquipRewards
    -- Nachkaufen mit simuliertem Händler: nur API.MerchantBuy im Protokoll (über LP.Act)
    WithSetting({ restock = true }, function()
        local plan = { { index = 1, id = 4540, purchases = 1, perBuy = 5, price = 25, name = "Test" } }
        local origPlan = LP.Supply.Plan
        LP.Supply.Plan = function() return plan, 25 end
        Guard(function()
            WithEnv({ LP.Supply.Restock }, { MerchantFrame = { IsShown = function() return true end } }, function()
                LP.Supply:Restock()
            end)
        end, function() LP.Supply.Plan = origPlan end)
    end)
    local n = ActSince(mark, "MerchantBuy")
    return type(needs) == "table" and n >= 1 and pend ~= nil, #needs .. " Bedarf, Kauf mitgeschrieben " .. n, ">= 1 mitgeschrieben"
end

IMPL.T68 = function()
    LP.Advisor:Run()
    return type(LP.Advisor.hints) == "table", #LP.Advisor.hints .. " Hinweis(e)", "Liste"
end

IMPL.T73 = function()
    local t = LP.Calib:KillXPText()
    return type(t) == "string" and t ~= "", t, "Text"
end

IMPL.T75 = function()
    local Pr = LP.Protocol
    local n0 = Pr:Count()
    Pr:Add("error", "LP-Testroutine Protokoll")
    Pr:Add("error", "LP-Testroutine Protokoll")
    local n1 = Pr:Count()
    -- Eintrag wieder entfernen (Sandbox stellt am Ende ohnehin alles zurück)
    local entries = Pr:Entries()
    for i = #entries, 1, -1 do
        local e = entries[i]
        if type(e) == "table" and type(e.msg) == "string" and e.msg:find("LP-Testroutine", 1, true) then table.remove(entries, i) end
    end
    return n1 - n0 <= 1, "neu: " .. (n1 - n0), "höchstens 1 (gleiche Meldung zusammengefasst)"
end

IMPL.T77 = function()
    local t = LP.Measure:Text()
    return type(t) == "string" and (not G() or t:find(G().Status(), 1, true) ~= nil), #t .. " Zeichen (Text nicht im Bericht)", "enthält G.Status()"
end

IMPL.T79 = function()
    local a = LP.HasBit(2 ^ 32 + 1, 2 ^ 32) == true and LP.HasBit(5, 2) == false and LP.HasBit(0, 1) == false
    local b = LP:SameZoneName("Das Brachland", "Brachland") == true and LP:SameZoneName("Durotar", "Mulgore") == false
    local c = LP:FormatDist(2000) == "1.8 km" and LP.TagHash("Ab c#1") == LP.TagHash("abc#1")
    -- LP:Fire: ein fehlerhafter Zuhörer bricht nicht ab
    local ran = false
    local key = "LP_TEST_FIRE"
    LP.callbacks[key] = { function() error("LP-Testfehler Fire") end, function() ran = true end }
    local before = LP.errorCount
    LP:Fire(key)
    LP.callbacks[key] = nil
    LP.errorCount = before
    return a and b and c and ran, string.format("Bits %s, Zonen %s, Format %s, Fire %s", S(a), S(b), S(c), S(ran)), "alle true"
end

IMPL.T81 = function()
    local names, bad = {}, {}
    for _, t in ipairs(LP.tickers or {}) do
        names[#names + 1] = t.name
        if t.name ~= "journey" then
            local ok, err = pcall(t.fn)
            if not ok then bad[#bad + 1] = t.name .. ": " .. tostring(err) end
        end
    end
    return #bad == 0 and #names > 0, #names .. " Ticker" .. (#bad > 0 and (" – " .. table.concat(bad, "; ")) or ""), "kein Fehler"
end

IMPL.T86 = function()
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return true, "kein Datenpaket" end
    local ok = type(d.Q) == "table" and type(d.N) == "table" and next(d.Q) ~= nil
    return ok, "Quests " .. Count(d.Q), "Tabellen gefüllt"
end
SKIP.T87 = "ausserhalb des Spiels"

------------------------------------------------------------------------
-- C. Forever-Sonderfälle (Köder, fehlende Funktionen, Kampfsperre)
------------------------------------------------------------------------
local BAIT_N1, BAIT_N2 = 987654.25, 987655.25

IMPL.T88 = function()
    local fakeC = Without(C_Container, "GetItemCooldown") or {}
    fakeC.GetItemCooldown = function() return BAIT_N1, BAIT_N2 end
    return WithSecret({ BAIT_N1, BAIT_N2 }, function()
        return WithEnv({ LP.API.ItemCooldown }, { C_Container = fakeC, GetItemCooldown = false }, function()
            local v = LP.API.ItemCooldown(LP.API.HEARTHSTONE or 6948)
            return type(v) == "number" and v >= 0, "Rückgabe " .. S(v), "Zahl >= 0 (letzter lesbarer Wert oder 0)"
        end)
    end)
end

IMPL.T91 = function()
    local item = 999001
    local s = LevelPilotDB.calib or {}
    LevelPilotDB.calib = s
    s.drops = type(s.drops) == "table" and s.drops or {}
    local savedDrop = s.drops[item]
    s.drops[item] = { k = 1, g = 0 }
    local msg = "Ihr bekommt Beute: |cffffffff|Hitem:" .. item .. "::::::::|h[x]|h|r"
    local savedW = LP.Calib.testWanted
    LP.Calib.testWanted = { [item] = { npc = { [1] = true } } }
    return Guard(function()
        WithSecret({ msg }, function() LP.Calib:OnLoot(msg) end)
        return s.drops[item].g == 0, "Stück " .. S(s.drops[item].g), "0 (Köder nicht verarbeitet)"
    end, function() s.drops[item] = savedDrop LP.Calib.testWanted = savedW end)
end
IMPL.T188 = IMPL.T91

IMPL.T97 = function()
    local bait = "LPTestKoeder Name"
    return WithSecret({ bait }, function()
        local a = LP.SameName(bait, "x")
        local b = G().Short(bait)
        return a == false and b == nil, "SameName " .. S(a) .. ", Short " .. S(b), "false, nil"
    end)
end

IMPL.T101 = function()
    local fakeQ = Without(C_QuestLog, "GetTrivialRange") or false
    return WithEnv({ LP.API.GreenRange }, { C_QuestLog = fakeQ, GetQuestGreenRange = false, UnitQuestTrivialLevelRange = false }, function()
        local R = LP.API.GreenRange
        local a, b, c, d = R(5), R(20), R(45), R(60)
        return a == 5 and b == 7 and c == 10 and d == 13, a .. "," .. b .. "," .. c .. "," .. d, "5,7,10,13"
    end)
end
IMPL.T194 = IMPL.T101

IMPL.T102 = function()
    local API = LP.API
    return WithEnv({ API.MerchantCount, API.MerchantAvailable, API.MerchantLink, API.MerchantBuy, API.MerchantItem },
        { GetMerchantNumItems = false, C_MerchantFrame = false, GetMerchantItemLink = false, BuyMerchantItem = false,
          GetMerchantItemInfo = false }, function()
        local ok = API.MerchantCount() == 0 and API.MerchantAvailable() == false and API.MerchantLink(1) == nil
            and API.MerchantBuy(1, 1) == false and API.MerchantItem(1) == nil
        return ok, ok and "alle Rückfälle" or "falscher Rückfall", "0/false/nil/false/nil"
    end)
end

IMPL.T103 = function()
    local API = LP.API
    return WithEnv({ API.ItemInfo, API.IsEquippable, API.SellPrice, API.ItemSpell },
        { C_Item = false, GetItemInfo = false, IsEquippableItem = false, GetItemSpell = false }, function()
        local ok = API.ItemInfo(6948) == nil and API.IsEquippable(6948) == false and API.SellPrice(6948) == 0 and API.ItemSpell(6948) == nil
        return ok, ok and "alle Rückfälle" or "falscher Rückfall", "nil/false/0/nil"
    end)
end

IMPL.T104 = function()
    local API = LP.API
    return WithEnv({ API.BagSlots, API.BagFree, API.BagLink, API.BagItem, API.UseBagItem },
        { C_Container = false, GetContainerNumSlots = false, GetContainerNumFreeSlots = false, GetContainerItemLink = false,
          GetContainerItemInfo = false, UseContainerItem = false }, function()
        local f1, f2 = API.BagFree(0)
        local ok = API.BagSlots(0) == 0 and f1 == 0 and f2 == 0 and API.BagLink(0, 1) == nil and API.BagItem(0, 1) == nil
            and API.UseBagItem(0, 1) == nil
        return ok, ok and "alle Rückfälle" or "falscher Rückfall", "0/0,0/nil/nil/nil"
    end)
end

IMPL.T106 = function()
    local known = LP.Hints.Known
    if not known then return false, "Hints.Known fehlt", "zugänglich" end
    return WithEnv({ known }, { C_SpellBook = false, IsSpellKnown = false, IsPlayerSpell = false }, function()
        local r = known(3273)
        return r == nil, "Rückgabe " .. S(r), "nil (unbekannt – kein Hinweis)"
    end)
end
IMPL.T191 = IMPL.T106

IMPL.T107 = function()
    local mark = ActMark()
    local So = LP.Social
    local origText = So.GroupText
    So.GroupText = function() return "LFG Test" end
    return Guard(function()
        local line = WithEnv({ So.OpenGroupChat }, { ChatFrame_OpenChat = false }, function() return So:OpenGroupChat({}) end)
        local n = ActSince(mark, "OpenChat")
        local hasUtil = ChatFrameUtil and ChatFrameUtil.OpenChat
        return line ~= nil and (n == 1 or not hasUtil), "Zeile " .. S(line ~= nil) .. ", mitgeschrieben " .. n, "Zeile, OpenChat mitgeschrieben"
    end, function() So.GroupText = origText end)
end
IMPL.T192 = IMPL.T107

IMPL.T115 = function()
    local mark = ActMark()
    WithSetting({ autoEquipRewards = true }, function()
        WithEnv({ LP.Supply.EquipRewards }, { InCombatLockdown = function() return true end }, function() LP.Supply:EquipRewards() end)
    end)
    local n = ActSince(mark, "Equip")
    return n == 0, "mitgeschrieben " .. n, "0"
end

IMPL.T116 = function()
    local r = WithCombat(true, function() return TR:CanStart(true) end)
    return r == false, "Start erlaubt: " .. S(r), "false"
end

IMPL.T117 = function()
    local Pr = LP.Protocol
    local list = LP.handlers.ADDON_ACTION_BLOCKED
    if not list then return false, "kein Handler", "Handler angemeldet" end
    local n0 = Pr:Count()
    for _, fn in ipairs(list) do pcall(fn, "ADDON_ACTION_BLOCKED", "LevelPilot", "LPTestAktion") end
    local n1 = Pr:Count()
    local entries = Pr:Entries()
    for i = #entries, 1, -1 do
        local e = entries[i]
        local txt = type(e) == "table" and (tostring(e.msg or "") .. tostring(e.a1 or "") .. tostring(e.args and e.args[1] or ""))
        if txt and txt:find("LPTestAktion", 1, true) then table.remove(entries, i) end
    end
    return n1 > n0, "neu: " .. (n1 - n0), "Eintrag 'blocked'"
end

IMPL.T118 = function()
    local g = G()
    local reg = LP.eventFrame:IsEventRegistered("COMBAT_LOG_EVENT_UNFILTERED") and true or false
    if g and g.IsModern then
        return LP.handlers.COMBAT_LOG_EVENT_UNFILTERED == nil and not reg, "angemeldet " .. S(reg), "nicht angemeldet (Forever)"
    end
    return reg, "angemeldet " .. S(reg), "angemeldet (alter Client)"
end
CLIENT.T99 = "/lp testroutine kampf, dann allein einen Gegner töten – Fehlerzähler vorher/nachher gleich"

------------------------------------------------------------------------
-- D. Alte Clients
------------------------------------------------------------------------
CLIENT.T119 = "Classic Era mit 'Veraltete AddOns laden' starten, dann /lp testroutine – keine Lua-Fehler beim Laden, T01 OK"
IMPL.T120 = function()
    local g = G()
    if not g then return false, "GoldSentinelGame fehlt", "vorhanden" end
    return true, g.Status() .. (g.IsForever and "" or " – LevelPilot ist für WoW Forever gebaut, alter Client nur Ladeprüfung")
end
IMPL.T121 = function()
    local g = G()
    local want = g and (g.IsModern and true or false) or (C_QuestLog and C_QuestLog.GetInfo ~= nil)
    return LP.API.modern == want, "API.modern " .. S(LP.API.modern), S(want) .. " (laut GoldSentinelGame)"
end
SKIP.T122 = ONLY_FOREVER

------------------------------------------------------------------------
-- E. Daten (Testtabellen über LP:LoadSaved, danach wieder die echten Tabellen)
------------------------------------------------------------------------
local function WithLoad(acc, char, body)
    return Guard(function() LP:LoadSaved(acc, char) return body(acc, char) end,
        function() LP:LoadSaved(LevelPilotDB, LevelPilotCharDB) end)
end

IMPL.T123 = function()
    return WithLoad({}, {}, function(acc, char)
        local miss = {}
        for k in pairs(LP.DEFAULTS) do if acc[k] == nil and LP.DEFAULTS[k] ~= nil then miss[#miss + 1] = k end end
        for k in pairs(LP.CHAR_DEFAULTS) do if char[k] == nil then miss[#miss + 1] = "char." .. k end end
        local ok = #miss == 0 and acc.speedLevelV2 == true and acc.language == "auto"
        return ok, #miss == 0 and "alle Standardwerte" or ("fehlend: " .. table.concat(miss, ",")), "alle Standardwerte"
    end)
end
IMPL.T206 = function()
    return WithLoad({}, {}, function(acc)
        local ok = acc.autoRepair == true and acc.autoFly == true and acc.restock == false and acc.autoEquipRewards == false
        return ok, string.format("autoRepair %s, autoFly %s, restock %s, autoEquipRewards %s", S(acc.autoRepair), S(acc.autoFly),
            S(acc.restock), S(acc.autoEquipRewards)), "true, true, false, false"
    end)
end
IMPL.T207 = function()
    return WithLoad({ autoRepair = false, autoFly = false, restock = true }, {}, function(acc)
        local ok = acc.autoRepair == false and acc.autoFly == false and acc.restock == true
        return ok, string.format("autoRepair %s, autoFly %s, restock %s", S(acc.autoRepair), S(acc.autoFly), S(acc.restock)), "false, false, true"
    end)
end
IMPL.T204 = function()
    local D = LP.DEFAULTS
    local ok = D.autoRepair == true and D.autoFly == true and D.restock == false and D.autoEquipRewards == false
    return ok, string.format("restock %s, autoEquipRewards %s, autoRepair %s, autoFly %s", S(D.restock), S(D.autoEquipRewards),
        S(D.autoRepair), S(D.autoFly)), "false, false, true, true (Entscheid des Nutzers 3.12.5)"
end

IMPL.T124 = function()
    local a, b
    WithLoad({ speedLevel = 3 }, {}, function(acc) a = acc.speedLevel end)
    WithLoad({ speedLevel = 3, speedLevelV2 = true }, {}, function(acc) b = acc.speedLevel end)
    return a == 2 and b == 3, S(a) .. ", " .. S(b), "2, 3"
end
IMPL.T125 = function()
    local a
    WithLoad({ language = "xx" }, {}, function(acc) a = acc.language end)
    return a == "auto", S(a), "auto"
end
IMPL.T126 = function()
    local M = LP.Protocol.Migrate
    if not M then return false, "Protocol.Migrate fehlt", "vorhanden" end
    local r = M({ k = "zone", msg = "… Das Brachland (1413), Brachland" })
    return r == "drop", S(r), "drop"
end
IMPL.T132 = function()
    local acc = { autoAccept = true }
    return WithLoad(acc, {}, function()
        LP.db.ownSettings = true
        LP.db.autoAccept = false
        local a = acc.autoAccept == true and LP.db.autoAccept == false
        LP.db.ownSettings = false
        local b = LP.db.autoAccept == true
        return a and b, "Charakter " .. S(a) .. ", Konto wieder " .. S(b), "true, true"
    end)
end
IMPL.T199 = function()
    local Pr = LP.Protocol
    local s = LevelPilotDB.protocolLog
    if type(s) ~= "table" then return true, "kein Protokoll" end
    local entries = s.entries
    entries[#entries + 1] = { k = nil, msg = 5 }
    return Guard(function() Pr:LoadEntries() return true, "Laden ohne Fehler" end,
        function() for i = #entries, 1, -1 do if entries[i] and entries[i].msg == 5 then table.remove(entries, i) end end end)
end
IMPL.T203 = function()
    local Q = LP.QuestDB
    return Q.OlderThan("1.5.0", Q.MIN_PACK) == true and Q.OlderThan("1.6.0", Q.MIN_PACK) == false,
        "Mindestversion " .. S(Q.MIN_PACK), "1.5.0 zu alt, 1.6.0 ok"
end
IMPL.T170 = function()
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return true, "kein Datenpaket" end
    return LP.QuestDB.OlderThan(d.version, "1.6.0") == false, S(d.version), ">= 1.6.0"
end

------------------------------------------------------------------------
-- F. Sprachen
------------------------------------------------------------------------
local CODES = { "en", "fr", "es", "mx", "pt", "it", "ru", "ko", "cn", "tw" }
local function Placeholders(s)
    local out = {}
    for p in tostring(s):gsub("%%%%", ""):gmatch("%%[%-%+ #0]*%d*%.?%d*[sdif]") do out[#out + 1] = p:sub(-1) end
    return table.concat(out)
end

IMPL.T133 = function()
    local res, bad = {}, 0
    for _, code in ipairs(CODES) do
        local t = LP.Locales[code]
        local fb = LP.LanguageInfo[code] and LP.LanguageInfo[code].fallback
        local miss, ex = 0, nil
        for k in pairs(LP.usedKeys or {}) do
            if k ~= "" and not k:find("^%s*$") and not ((t and t[k]) or (fb and LP.Locales[fb] and LP.Locales[fb][k])) then
                miss = miss + 1 ex = ex or k
            end
        end
        if miss > 0 then bad = bad + 1 res[#res + 1] = code .. " " .. miss .. " (" .. tostring(ex):sub(1, 30) .. ")" end
    end
    return bad == 0, bad == 0 and (Count(LP.usedKeys) .. " benutzte Schlüssel in allen Sprachen") or table.concat(res, "; "), "0 fehlend"
end

IMPL.T134 = function()
    local res = {}
    for _, code in ipairs(CODES) do
        for k, v in pairs(LP.Locales[code] or {}) do
            if type(k) == "string" and type(v) == "string" and Placeholders(k) ~= Placeholders(v) then
                res[#res + 1] = code .. ": " .. k:sub(1, 30)
            end
        end
    end
    return #res == 0, #res == 0 and "keine Abweichung" or (#res .. ": " .. table.concat(res, "; "):sub(1, 200)), "0 Abweichungen"
end

IMPL.T135 = function()
    local bad = {}
    local VAL = { s = "x", d = 3, i = 3, f = 1.5 }
    for _, code in ipairs(CODES) do
        for k in pairs(LP.Locales[code] or {}) do
            if type(k) == "string" and k:find("%", 1, true) then
                local args = {}
                for c in Placeholders(k):gmatch(".") do args[#args + 1] = VAL[c] end
                -- nur echte Formattexte (der deutsche Schlüssel selbst lässt sich formatieren)
                if pcall(string.format, k, unpack(args)) then
                    local ok = pcall(string.format, LP.LocaleLookup(code, k), unpack(args))
                    if not ok then bad[#bad + 1] = code .. ": " .. k:sub(1, 30) end
                end
            end
        end
    end
    return #bad == 0, #bad == 0 and "alle formatierbar" or table.concat(bad, "; "):sub(1, 200), "kein Formatfehler"
end

IMPL.T137 = function()
    local bad = {}
    for _, l in ipairs(LP.LANGUAGES) do
        if not LP:CanDisplay(l.code) then
            local before = LP.db.language
            local r = LP:SetLanguage(l.code)
            LP.db.language = before
            LP:ResetLanguageCache()
            if r ~= false then bad[#bad + 1] = l.code end
        end
    end
    return #bad == 0, #bad == 0 and "ok" or table.concat(bad, ","), "SetLanguage gibt false zurück"
end

IMPL.T139 = function()
    local g = G()
    if not g or not g.Text then return true, "keine Texte" end
    local t = g.Text("game")
    return type(t) == "string" and t ~= "", S(t), "Text"
end

------------------------------------------------------------------------
-- G. Zusammenspiel
------------------------------------------------------------------------
IMPL.T140 = function()
    local loaded = {}
    local f = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
    for _, a in ipairs({ "GuildSentinel", "RaidMaster", "ThreatSentinel", "BuffSentinel", "ProfessionSentinel", "AHSentinel" }) do
        if f and f(a) then loaded[#loaded + 1] = a end
    end
    local GT, g = _G.GoldSentinelTest, _G.GoldSentinelGame
    local ok = g and g.version >= 2 and GT and GT.version >= 1 and LP.Game == g and GT.registry.LevelPilot ~= nil
    return ok and true or false, "geladen: " .. (#loaded > 0 and table.concat(loaded, ", ") or "keine"), "gemeinsame Dateien ok"
end
IMPL.T141 = function()
    local ok = _G.LevelPilot == LP and SLASH_LEVELPILOT1 == "/lp" and type(SlashCmdList.LEVELPILOT) == "function"
    return ok, ok and "ok" or "überschrieben", "eigene Namen"
end
SKIP.T143 = "keine Schnittstelle – LevelPilot nutzt keine anderen GoldSentinel-Addons"
IMPL.T145 = function()
    local f = C_ChatInfo and C_ChatInfo.IsAddonMessagePrefixRegistered
    if not f then return true, "keine Abfrage möglich" end
    local a, b = f("LvPilot2"), f("LvPilotG")
    return a and b and true or false, S(a) .. ", " .. S(b), "true, true"
end

------------------------------------------------------------------------
-- H. Leistung (je 20 Aufrufe, Median und Höchstwert)
------------------------------------------------------------------------
local function Bench(fn, n)
    local t = {}
    for i = 1, n or 20 do local a = Ms() fn() t[i] = Ms() - a end
    table.sort(t)
    return t[math.floor(#t / 2) + 1], t[#t]
end
local function BenchCheck(fn, limit, n)
    return function()
        local med, max = Bench(fn, n)
        return med < limit, string.format("Median %.2f ms, Höchstwert %.2f ms", med, max), string.format("Median < %g ms", limit)
    end
end
IMPL.T146 = BenchCheck(function() LP.UI:Refresh() end, 2)
IMPL.T147 = BenchCheck(function() LP.Engine:CheckSteps() end, 2)
IMPL.T150 = BenchCheck(function() LP.Planner:Replan(true) end, 16, 5)
IMPL.T157 = function()
    collectgarbage("collect")
    local kb = collectgarbage("count")
    local grow = TR.memStart and (kb - TR.memStart) or 0
    local usage
    if UpdateAddOnMemoryUsage and ((C_AddOns and C_AddOns.GetAddOnMemoryUsage) or GetAddOnMemoryUsage) then
        pcall(UpdateAddOnMemoryUsage)
        local ok, kb2 = pcall((C_AddOns and C_AddOns.GetAddOnMemoryUsage) or GetAddOnMemoryUsage, "LevelPilot")
        usage = ok and kb2 or nil
    end
    return grow < 1024, string.format("Zuwachs %.0f KB (ab dem Start der Prüfungen)%s", grow,
        usage and string.format(", LevelPilot %.0f KB", usage) or ""), "< 1024 KB"
end

------------------------------------------------------------------------
-- I. Fehlerzählung
------------------------------------------------------------------------
IMPL.T158 = function()
    local n0 = LP.errorCount
    local msg = "LP-Testfehler Safe " .. tostring(math.random(1000, 9999))
    local r = LP:Safe("Testroutine", function() error(msg, 0) end)
    local inErr = LP.errors[msg] == true
    local gt = false
    local s = LevelPilotDB.gsTest
    if s and type(s.errors) == "table" then
        for k, e in pairs(s.errors) do if type(e) == "table" and e.wo == "Testroutine" then gt = true s.errors[k] = nil end end
    end
    local ok = r == false and LP.errorCount == n0 + 1 and inErr and (gt or not LP.trackingErrors)
    LP.errors[msg] = nil
    return ok, string.format("Rückgabe %s, Zähler +%d, GoldSentinelTest %s", S(r), LP.errorCount - n0, S(gt)), "false, +1, true"
end
IMPL.T160 = function()
    local list = LP.handlers.PLAYER_XP_UPDATE
    if not list then return true, "kein Handler" end
    local n0, ran = LP.errorCount, false
    table.insert(list, 1, function() error("LP-Testfehler Ereignis", 0) end)
    table.insert(list, function() ran = true end)
    return Guard(function()
        LP.eventFrame:GetScript("OnEvent")(LP.eventFrame, "PLAYER_XP_UPDATE", "player")
        return LP.errorCount == n0 + 1 and ran, "Zähler +" .. (LP.errorCount - n0) .. ", übrige liefen " .. S(ran), "+1, true"
    end, function()
        table.remove(list, 1) table.remove(list)
        LP.errors["LP-Testfehler Ereignis"] = nil
    end)
end
IMPL.T161 = function()
    local n0, ran = LP.errorCount, false
    local key = "LP_TEST_FIRE2"
    LP.callbacks[key] = { function() error("LP-Testfehler Fire", 0) end, function() ran = true end }
    LP:Fire(key)
    LP.callbacks[key] = nil
    return LP.errorCount == n0 + 1 and ran, "Zähler +" .. (LP.errorCount - n0) .. ", nächster lief " .. S(ran), "+1, true"
end
IMPL.T163 = function()
    local n0 = LP.errorCount
    local msg = "LP-Testfehler Ticker"
    LP:Safe("ticker-test", function() error(msg, 0) end)
    LP:Safe("ticker-test", function() error(msg, 0) end)
    local ok = LP.errorCount == n0 + 2
    LP.errors[msg] = nil
    return ok, "Zähler +" .. (LP.errorCount - n0), "+2 (Chatmeldung nur einmal)"
end
IMPL.T198 = function()
    local n = 0
    for _, t in ipairs(LP.tickers or {}) do if t.name ~= "journey" then n = n + 1 end end
    return n == 13, n .. " Ticker über LP:Ticker", "13 (ohne Reise)"
end
SKIP.T205 = "vor dem Push mit addon-check"

------------------------------------------------------------------------
-- J. Regressionstests (wiederverwendete Prüfungen unter eigener ID)
------------------------------------------------------------------------
IMPL.T167 = IMPL.T06
IMPL.T168 = IMPL.T47
IMPL.T172 = IMPL.T40
IMPL.T173 = function()
    local P = LP.Planner
    return P.FOREVER_GREEN == 0.85 and P.GREEN_DIFF == 3, S(P.FOREVER_GREEN) .. " / " .. S(P.GREEN_DIFF), "0.85 / 3"
end
IMPL.T175 = IMPL.T44
IMPL.T176 = function()
    local P = LP.Planner
    return P.FOREVER_DG_MOB == 0.36 and P.FOREVER_DG_QUEST == 1.5, S(P.FOREVER_DG_MOB) .. " / " .. S(P.FOREVER_DG_QUEST), "0.36 / 1.5"
end
IMPL.T178 = function()
    return WithSetting({ forever = true }, function()
        return WithFlavor("forever", function()
            local t = LP.Social.ForeverGroupNote("x")
            local want = L["Ein viel höheres Gruppenmitglied kann dafür sorgen, dass alle 0 EP bekommen."]
            return t:sub(-#want) == want, "Hinweis " .. S(t ~= "x"), "endet mit dem Gruppen-EP-Hinweis"
        end)
    end)
end
IMPL.T182 = function()
    local f = LP.Comfort.XPNeed
    if not f then return false, "Comfort.XPNeed fehlt", "zugänglich" end
    local sum, n = 0, 0
    for l = 1, 59 do local v = f(l) if v then sum, n = sum + v, n + 1 end end
    return sum == 4084700 and n == 59, sum .. " in " .. n .. " Einträgen", "4084700 in 59"
end
IMPL.T185 = IMPL.T88
IMPL.T202 = function()
    local g = G()
    if not g then return true, "ohne GoldSentinelGame: Einstellung" end
    return WithSetting({ forever = true }, function()
        local a = WithFlavor("forever", function() return LP.API.Forever() end)
        local b = WithFlavor("era", function() return LP.API.Forever() end)
        return a == true and b == false, "forever " .. S(a) .. ", era " .. S(b), "true, false"
    end)
end

------------------------------------------------------------------------
-- J. 3.12.5: einmalige Hinweise auf Nachkaufen und Belohnung anlegen
------------------------------------------------------------------------
local PLAN = { { index = 1, id = 4540, purchases = 1, perBuy = 5, price = 25, name = "Test" } }

-- Hinweis-Zustand des Charakters vorübergehend leeren
local function WithOptState(body)
    local Su = LP.Supply
    local savedHints, savedPending = LP.char.optHints, Su.optPending
    LP.char.optHints, Su.optPending = {}, {}
    return Guard(body, function() LP.char.optHints, Su.optPending = savedHints, savedPending end)
end
-- Hinweise des Anbieters abfragen (ohne den Assistenten laufen zu lassen)
local function OptHintsShown()
    local list = {}
    LP.Supply.OptHintsProvider(function(key, sev, text, action, label, action2)
        list[#list + 1] = { key = key, action = action, action2 = action2 }
    end)
    return list
end

IMPL.T208 = function()
    return WithOptState(function()
        return WithSetting({ restock = false }, function()
            local mark = ActMark()
            local first = LP.Supply:CheckRestockHint(PLAN)
            local shown1 = #OptHintsShown()
            LP.Supply.optPending = {}                 -- Händler geschlossen, Sitzung geht weiter
            local second = LP.Supply:CheckRestockHint(PLAN)
            local bought = ActSince(mark, "MerchantBuy")
            return first == true and shown1 == 1 and second == false and bought == 0,
                string.format("erster Besuch %s (%d Hinweis), zweiter %s, gekauft %d", S(first), shown1, S(second), bought),
                "true (1), false, 0"
        end)
    end)
end

IMPL.T209 = function()
    local link = "|cff1eff00|Hitem:999002::::::::|h[Test]|h|r"
    local A = LP.Advisor
    local orig = A.UpgradeValue
    A.UpgradeValue = function(_, l) if l == link then return 10 end return orig(A, l) end
    return Guard(function()
        return WithOptState(function()
            return WithSetting({ autoEquipRewards = false }, function()
                local mark = ActMark()
                local first = LP.Supply:CheckRewardHint({ link })
                local shown = #OptHintsShown()
                LP.Supply.optPending = {}
                local second = LP.Supply:CheckRewardHint({ link })
                local acted = ActSince(mark, "Equip") + ActSince(mark, "GetQuestReward")
                return first == true and shown == 1 and second == false and acted == 0,
                    string.format("erste %s (%d Hinweis), zweite %s, gewählt/angelegt %d", S(first), shown, S(second), acted),
                    "true (1), false, 0"
            end)
        end)
    end, function() A.UpgradeValue = orig end)
end

IMPL.T210 = function()
    return WithOptState(function()
        return WithSetting({ restock = true, autoEquipRewards = true }, function()
            local a = LP.Supply:CheckRestockHint(PLAN)
            LP.Supply.optPending.restock = { text = "x" }          -- schon vorgemerkt, dann eingeschaltet
            local shown = #OptHintsShown()
            return a == false and shown == 0, "Hinweis " .. S(a) .. ", gezeigt " .. shown, "false, 0"
        end)
    end)
end

IMPL.T211 = function()
    return WithOptState(function()
        return WithSetting({ restock = false }, function()
            LP.Supply:CheckRestockHint(PLAN)
            local inCombat = WithCombat(true, function() return #OptHintsShown() end)
            local later = WithCombat(false, function() return #OptHintsShown() end)
            return inCombat == 0 and later == 1, "im Kampf " .. inCombat .. ", danach " .. later, "0, 1"
        end)
    end)
end

-- 3.12.5 offen-Punkt 1: dieselbe Leiche zweimal öffnen zählt Kill und Stück nur einmal
IMPL.T212 = function()
    local Ca = LP.Calib
    if not Ca.ResetLooted then return false, "Calib.ResetLooted fehlt", "zugänglich" end
    local item, npc = 999003, 99901
    local guid = "Creature-0-1-1-1-" .. npc .. "-0000ABCDEF"
    local s = LevelPilotDB.calib or {}
    LevelPilotDB.calib = s
    s.drops = type(s.drops) == "table" and s.drops or {}
    local saved, savedW = s.drops[item], Ca.testWanted
    s.drops[item] = nil
    Ca.testWanted = { [item] = { npc = { [npc] = true } } }
    local fake = {
        GetNumLootItems = function() return 1 end,
        GetLootSlotLink = function() return "|cffffffff|Hitem:" .. item .. "::::::::|h[x]|h|r" end,
        GetLootSourceInfo = function() return guid, 2 end,
        UnitExists = function() return false end,
    }
    return Guard(function()
        -- 3.12.6: Stück zählen erst bei der Beutemeldung (was liegen bleibt, zählt nicht)
        local link = "|cffffffff|Hitem:" .. item .. "::::::::|h[x]|h|r"
        local selfMsg = (LOOT_ITEM_SELF_MULTIPLE and LOOT_ITEM_SELF_MULTIPLE:gsub("%%%d?%$?s", link, 1):gsub("%%%d?%$?d", "2", 1))
            or ("Ihr bekommt Beute: " .. link .. "x2.")
        WithEnv({ Ca.OnLootOpened, Ca.IsPickpocket }, fake, function()
            Ca:OnLootOpened()
            Ca:OnLoot(selfMsg)
            Ca:OnLootClosed()
            Ca:OnLootOpened()          -- erneut geöffnet: dieselbe Leiche, keine neue Beutemeldung
            Ca:OnLootClosed()
        end)
        local d = s.drops[item] or { k = 0, g = 0 }
        return d.k == 1 and d.g == 2, "Kills " .. d.k .. ", Stück " .. d.g, "Kills 1, Stück 2"
    end, function() s.drops[item] = saved Ca.testWanted = savedW Ca.ResetLooted(guid) end)
end

------------------------------------------------------------------------
-- 3.12.6: weitere Hilfen
------------------------------------------------------------------------
-- Funktion vorübergehend durch einen Zähler ersetzen (Addon-Tabelle, nie _G). pass = true: Original danach aufrufen
local function WithCounter(tbl, key, body, pass)
    local orig = tbl[key]
    local n = 0
    tbl[key] = function(...)
        n = n + 1
        if pass and orig then return orig(...) end
    end
    return Guard(function() return body(function() return n end) end, function() tbl[key] = orig end)
end

-- Text in einem Fenster suchen (FontStrings in allen Unterfenstern)
local function FindText(frame, text, depth)
    if not frame or (depth or 0) > 12 then return false end
    if frame.GetRegions then
        for _, r in ipairs({ frame:GetRegions() }) do
            local t = r and r.GetText and r:GetText()
            if type(t) == "string" and t:find(text, 1, true) then return true end
        end
    end
    if frame.GetChildren then
        for _, c in ipairs({ frame:GetChildren() }) do
            if FindText(c, text, (depth or 0) + 1) then return true end
        end
    end
    return false
end

-- Einträge in der Fehlerliste von GoldSentinelTest (dieses Addon) zählen/entfernen
local function GTErrors(where, remove)
    local s = LevelPilotDB.gsTest
    local n = 0
    if s and type(s.errors) == "table" then
        for k, e in pairs(s.errors) do
            if type(e) == "table" and (where == nil or e.wo == where or tostring(e.msg):find(where, 1, true)) then
                n = n + 1
                if remove then s.errors[k] = nil end
            end
        end
    end
    return n
end

-- Protokoll-Einträge mit einem Text entfernen
local function DropProtocol(text)
    local entries = LP.Protocol:Entries()
    local n = 0
    for i = #entries, 1, -1 do
        local e = entries[i]
        if type(e) == "table" and tostring(e.msg or ""):find(text, 1, true) then table.remove(entries, i) n = n + 1 end
    end
    return n
end

local function HandlerList(ev) return LP.handlers[ev] or {} end
local function CallHandlers(ev, ...)
    for _, fn in ipairs(HandlerList(ev)) do fn(ev, ...) end
end

-- Kill mit EP-Meldung simulieren (Calib): Ziellevel tl, EP-Gewinn gain. Rückgabe calib.killxp
local function SimKill(tl, gain, fake)
    local Ca = LP.Calib
    local L0 = UnitLevel("player") or 1
    local xp = 100
    local f = {
        UnitLevel = function(u) if u == "target" then return tl end return L0 end,
        UnitExists = function() return true end,
        UnitIsPlayer = function() return false end,
        UnitXP = function() return xp end,
        UnitXPMax = function() return 1000000 end,
        IsInGroup = function() return false end,
        GetXPExhaustion = function() return nil end,
        IsInInstance = function() return false, "none" end,
    }
    for k, v in pairs(fake or {}) do f[k] = v end
    Ca.ResetKillXP()
    return Guard(function()
        WithEnv({ Ca.ReadTarget, Ca.OnXPUpdate, Ca.OnKillXPMessage }, f, function()
            Ca:ReadTarget()
            Ca:OnXPUpdate()
            xp = xp + gain
            if f.SetXP then f.SetXP() end
            Ca:OnXPUpdate()
            Ca:OnKillXPMessage()
        end)
    end, function() Ca.ResetKillXP() end)
end

------------------------------------------------------------------------
-- C. Forever-Sonderfälle (3.12.6)
------------------------------------------------------------------------
IMPL.T89 = function()
    local R = LP.Recorder
    local bait = "LPTestKoeder Haendler"
    local plain = "LPTestHaendler"
    local before = Count(LP.db.vendors)
    -- ohne Schutz wird der Händler erkannt (Gegenprobe), mit Schutz nicht
    local function rec(name)
        return WithEnv({ R.RecordService }, { UnitName = function() return name end, UnitGUID = function() return nil end,
            CanMerchantRepair = function() return false end }, function() R:RecordService("merchant") end)
    end
    local pos = LP.Geo:Player() ~= nil
    WithSecret({ bait }, function() rec(bait) end)
    local secretN = Count(LP.db.vendors)
    rec(plain)
    local plainN = Count(LP.db.vendors)
    for k, v in pairs(LP.db.vendors) do if type(v) == "table" and v.name == plain then LP.db.vendors[k] = nil end end
    LP.QuestDB:InvalidateServices()
    local ok = secretN == before and (plainN == before + 1 or not pos)
    return ok, string.format("geschützt %+d, Gegenprobe %+d", secretN - before, plainN - before), "geschützt +0, Gegenprobe +1"
end
IMPL.T186 = IMPL.T89

IMPL.T90 = function()
    local bait, baitUnit = "LPTestKoeder Kiste", "LPTestKoeder Einheit"
    local added = 0
    local tt = {
        GetUnit = function() return bait, baitUnit end,
        GetItem = function() return nil end,
        GetOwner = function() return UIParent end,
        AddLine = function() added = added + 1 end,
        Show = function() end,
    }
    local left = { GetText = function() return bait end }
    return WithSecret({ bait, baitUnit }, function()
        return WithEnv({ LP.Tooltips.OnShowObject, LP.Tooltips.OnUnit }, { GameTooltipTextLeft1 = left }, function()
            LP.Tooltips.OnShowObject(tt)
            tt.lpObjectDone = nil
            LP.Tooltips.OnUnit(tt)
            return added == 0, "Zeilen " .. added, "0"
        end)
    end)
end
IMPL.T187 = IMPL.T90

-- CHAT_MSG_ADDON mit geschützten Werten: weder Comm noch Group verarbeiten etwas (Gegenprobe ohne Schutz)
IMPL.T92 = function()
    local Gp = LP.Group
    local who = "LPTester-Test"
    local prefixC, prefixG = "LvPilot2", "LvPilotG"
    local msgG = "S\t5\t10\tGOTO\t0\ttext"
    local recv0 = LP.db.net and LP.db.net.recv
    return WithCounter(LP.Comm, "Receive", function(nC)
        return WithCounter(Gp, "OnMessage", function(nG)
            WithSecret({ prefixC, prefixG, who, "LPTestNachricht", msgG }, function()
                CallHandlers("CHAT_MSG_ADDON", prefixC, "LPTestNachricht", "WHISPER", who)
                CallHandlers("CHAT_MSG_ADDON", prefixG, msgG, "PARTY", who)
            end)
            local secretC, secretG = nC(), nG()
            -- Gegenprobe ohne Schutz: beide würden verarbeiten
            CallHandlers("CHAT_MSG_ADDON", prefixC, "LPTestNachricht", "WHISPER", "LPTester2-Test")
            CallHandlers("CHAT_MSG_ADDON", prefixG, msgG, "PARTY", "LPTester2-Test")
            local plainC, plainG = nC() - secretC, nG() - secretG
            local recv1 = LP.db.net and LP.db.net.recv
            local ok = secretC == 0 and secretG == 0 and plainC == 1 and plainG == 1 and recv0 == recv1
            return ok, string.format("geschützt Comm %d Group %d · Gegenprobe Comm %d Group %d", secretC, secretG, plainC, plainG),
                "geschützt 0/0 · Gegenprobe 1/1"
        end)
    end)
end
IMPL.T189 = IMPL.T92

-- Testkandidat für die Namensplaketten: Questziel "LPTestwolf getötet"
local function PlateCand()
    return { { id = 999101, title = "LPTest", byNpc = {}, objs = { { text = "LPTestwolf getötet: 0/8", have = 0, need = 8,
        finished = false, type = "monster" } } } }
end
IMPL.T93 = function()
    local bait = "LPTestwolf"
    local cand = PlateCand()
    local fake = { UnitName = function() return bait end, UnitGUID = function() return "LPTestKoeder GUID" end,
                   UnitIsPlayer = function() return false end, UnitIsDead = function() return false end }
    local plain = WithEnv({ LP.Plates.ForUnit }, fake, function() return LP.Plates:ForUnit("target", true, cand) end)
    local secret = WithSecret({ bait, "LPTestKoeder GUID" }, function()
        return WithEnv({ LP.Plates.ForUnit }, fake, function() return LP.Plates:ForUnit("target", true, cand) end)
    end)
    return secret == nil and plain ~= nil, "geschützt " .. S(secret ~= nil) .. ", Gegenprobe " .. S(plain ~= nil), "kein Treffer, Gegenprobe Treffer"
end

-- EP-Messung je Kill: echte Werte messen, geschützte nicht
IMPL.T74 = function()
    local P = LP.Planner
    local L0 = UnitLevel("player") or 1
    if L0 >= 60 then return true, "Level 60 – keine EP" end
    local f = P:KillXPFormula(L0, L0)
    return WithEmptyCalib(function()
        local c = LevelPilotDB.calib
        SimKill(L0, f)
        local k = c.killxp and c.killxp[0]
        local n1, r1 = k and k.n or 0, k and k.n > 0 and k.sum / k.n or 0
        SimKill(L0, f, { GetXPExhaustion = function() return 500 end })
        local n2 = c.killxp and c.killxp[0] and c.killxp[0].n or 0
        SimKill(L0, f, { IsInGroup = function() return true end })
        local n3 = c.killxp and c.killxp[0] and c.killxp[0].n or 0
        local ok = n1 == 1 and Near(r1, 1, 0.01) and n2 == 1 and n3 == 1
        return ok, string.format("gemessen %d (Verhältnis %.2f), erholt %+d, Gruppe %+d", n1, r1, n2 - n1, n3 - n2), "1 (1.00), +0, +0"
    end)
end

IMPL.T94 = function()
    local L0 = UnitLevel("player") or 1
    if L0 >= 60 then return true, "Level 60 – keine EP" end
    local f = LP.Planner:KillXPFormula(L0, L0)
    local baitL, baitXP = "LPTestKoeder Level", "LPTestKoeder EP"
    return WithEmptyCalib(function()
        local c = LevelPilotDB.calib
        -- geschütztes Ziellevel
        WithSecret({ baitL }, function()
            SimKill(L0, f, { UnitLevel = function(u) if u == "target" then return baitL end return L0 end })
        end)
        local n1 = Count(c.killxp)
        -- geschützte EP
        WithSecret({ baitXP }, function()
            SimKill(L0, f, { UnitXP = function() return baitXP end })
        end)
        local n2 = Count(c.killxp)
        return n1 == 0 and n2 == 0, "Messungen: Level geschützt " .. n1 .. ", EP geschützt " .. n2, "0, 0"
    end)
end

IMPL.T95 = function()
    local bait = "LPTestKoeder Klasse"
    local line = WithSecret({ bait }, function()
        return WithEnv({ LP.Measure.UnitLine }, { UnitExists = function() return true end, UnitIsPlayer = function() return false end,
            UnitClassification = function() return bait end, UnitGUID = function() return nil end, UnitLevel = function() return 5 end,
            UnitName = function() return "LPTest" end }, function() return LP.Measure.UnitLine("target") end)
    end)
    local ok = type(line) == "string" and not line:find(bait, 1, true) and line:find(" ? ", 1, true) ~= nil
    return ok, ok and "\"?\" statt des Werts" or S(line), "\"?\""
end
IMPL.T200 = IMPL.T95

-- erstes Paket-NPC mit Levelbereich (für die Gegenprobe)
local function PackNpcWithLevel()
    local N = _G.LevelPilotData and _G.LevelPilotData.N
    if type(N) ~= "table" then return nil end
    local n = 0
    for id, e in pairs(N) do
        n = n + 1
        if type(e) == "table" and type(e.lo) == "number" and e.lo > 0 and e.lo < 55 then return id, e end
        if n > 2000 then break end
    end
    return nil
end
IMPL.T96 = function()
    local Ca = LP.Calib
    local id, npc = PackNpcWithLevel()
    local guid = "Creature-0-1-1-1-" .. (id or 99902) .. "-0000ABCDEF"
    local lv = npc and ((npc.hi or npc.lo) + 3) or 10
    local c = LevelPilotDB.calib or {}
    LevelPilotDB.calib = c
    c.mobs = type(c.mobs) == "table" and c.mobs or {}
    local saved = c.mobs[id or 99902]
    c.mobs[id or 99902] = nil
    local fake = { UnitExists = function() return true end, UnitIsPlayer = function() return false end,
                   UnitPlayerControlled = function() return false end,
                   UnitGUID = function() return guid end, UnitLevel = function() return lv end }
    return Guard(function()
        WithSecret({ guid }, function() WithEnv({ Ca.ObserveUnit }, fake, function() Ca:ObserveUnit("target") end) end)
        local a = c.mobs[id or 99902] == nil
        WithSecret({ lv }, function() WithEnv({ Ca.ObserveUnit }, fake, function() Ca:ObserveUnit("target") end) end)
        local b = c.mobs[id or 99902] == nil
        WithEnv({ Ca.ObserveUnit }, fake, function() Ca:ObserveUnit("target") end)
        local plain = c.mobs[id or 99902] ~= nil
        return a and b and (plain or not id), string.format("GUID geschützt %s, Level geschützt %s, Gegenprobe %s",
            a and "nichts" or "gelernt", b and "nichts" or "gelernt", plain and "gelernt" or "nichts"), "nichts, nichts, gelernt"
    end, function() c.mobs[id or 99902] = saved end)
end

IMPL.T98 = function()
    local bx, bm = "LPTestKoeder EP", "LPTestKoeder EPmax"
    return WithSecret({ bx, bm }, function()
        return WithEnv({ LP.PlayerXP }, { UnitXP = function() return bx end, UnitXPMax = function() return bm end }, function()
            local xp, mx, readable = LP:PlayerXP()
            LP.Comfort:TimerText()
            LP.Comfort:TimeTo60()
            LP.Comfort:TimeToLevel()
            LP.UI:Refresh()
            return readable == false and xp == 0 and mx == 1, string.format("lesbar %s, EP %s/%s", S(readable), S(xp), S(mx)),
                "lesbar false, 0/1, kein Lua-Fehler"
        end)
    end)
end

IMPL.T100 = function()
    local API = LP.API
    local fakeQ = Without(C_QuestLog, "GetNumQuestLogEntries", "GetQuestObjectives", "GetQuestTagInfo", "IsQuestFlaggedCompleted",
        "GetLogIndexForQuestID") or false
    return WithEnv({ API.NumEntries, API.Objectives, API.QuestTag, API.IsQuestDone, API.LogIndexForQuest, API.Entry },
        { C_QuestLog = fakeQ, GetNumQuestLogEntries = false, GetNumQuestLeaderBoards = false, GetQuestTagInfo = false,
          IsQuestFlaggedCompleted = false, GetQuestLogTitle = false }, function()
        local n, o, t, d, i = API.NumEntries(), API.Objectives(1), API.QuestTag(999104), API.IsQuestDone(1), API.LogIndexForQuest(1)
        local ok = n == 0 and type(o) == "table" and #o == 0 and t == nil and d == false and i == nil
        return ok, string.format("%s, %s Ziele, %s, %s, %s", S(n), S(type(o) == "table" and #o), S(t), S(d), S(i)), "0, 0 Ziele, nil, false, nil"
    end)
end

-- Selbsttest-Prüfung "Schnittstellen" mit fehlenden Funktionen
local function InterfacesCheck(fake)
    local fn
    for _, c in ipairs(LP.SelfTest.CHECKS or {}) do if c.name == "Schnittstellen" then fn = c.fn end end
    if not fn then return nil end
    local res = WithEnv({ fn }, fake, function() return LP.SelfTest:RunCheck("Schnittstellen") end)
    local t = {}
    for _, r in ipairs(res or {}) do t[#t + 1] = r.text end
    return table.concat(t, " ")
end

IMPL.T105 = function()
    local API = LP.API
    local fake = { UnitCharacterPoints = false, GetUnspentTalentPoints = false }
    return WithEnv({ API.TalentPoints }, fake, function()
        local p = API.TalentPoints()
        local talentHint = false
        WithSetting({ advTalents = true }, function()
            LP.Advisor:Run()
            for _, h in ipairs(LP.Advisor.hints or {}) do if h.key == "talents" then talentHint = true end end
        end)
        local diag = InterfacesCheck(fake) or ""
        local ok = p == nil and not talentHint and diag:find(L["Talentpunkte"], 1, true) ~= nil
        return ok, string.format("Punkte %s, Hinweis %s, Diagnose %s", S(p), S(talentHint),
            diag:find(L["Talentpunkte"], 1, true) and "nennt Talentpunkte" or "ohne Eintrag"), "nil, false, nennt Talentpunkte"
    end)
end

IMPL.T108 = function()
    local Comm = LP.Comm
    if not Comm.JoinChannel then return false, "Comm.JoinChannel fehlt", "zugänglich" end
    local removed = 0
    local cf = { RemoveChannel = function() removed = removed + 1 end }
    return WithSetting({ shareChannel = true }, function()
        return WithEnv({ Comm.JoinChannel }, { ChatFrame_RemoveChannel = false, NUM_CHAT_WINDOWS = 1, ChatFrame1 = cf,
            _G = setmetatable({ ChatFrame1 = cf }, { __index = _G }),
            GetChannelName = function() return 7 end }, function()
            Comm.JoinChannel()
            return removed == 1, "frame:RemoveChannel " .. removed .. "×", "1×"
        end)
    end)
end
IMPL.T193 = IMPL.T108

IMPL.T109 = function()
    local Su, H = LP.Supply, LP.Hints
    local fake = { GetPetHappiness = false, GetPetFoodTypes = false, UnitClass = function() return "Jäger", "HUNTER" end,
                   UnitExists = function() return true end }
    WithSetting({ restockPetFood = true, hintClass = true }, function()
        WithEnv({ Su.Needs, H.ClassReminders }, fake, function()
            Su:Needs()
            H.ClassReminders(function() end)
        end)
    end)
    local diag = InterfacesCheck(fake) or ""
    local a = diag:find(L["Zufriedenheit des Begleiters"], 1, true) ~= nil
    local b = diag:find(L["Futter des Begleiters"], 1, true) ~= nil
    return a and b, "Diagnose: Zufriedenheit " .. S(a) .. ", Futter " .. S(b), "beide als nicht verfügbar"
end

IMPL.T110 = function()
    local D, Nm, Pr = LP.Donate, LP.Names, LP.Protocol
    local used = 0
    local a = WithEnv({ D.AddonTitle }, { C_AddOns = false, GetAddOnMetadata = function() used = used + 1 return "|cffffb238LevelPilot|r" end },
        function() return D.AddonTitle() end)
    local b = WithEnv({ D.AddonTitle }, { C_AddOns = false, GetAddOnMetadata = false }, function() return D.AddonTitle() end)
    WithEnv({ Nm.Load }, { C_AddOns = false, LoadAddOn = false }, function() Nm:Load("xx") Nm:Load(LP:Language()) end)
    if Pr.Memory then WithEnv({ Pr.Memory }, { UpdateAddOnMemoryUsage = false }, function() Pr.Memory() end) end
    local ok = a == "LevelPilot" and used == 1 and b == "LevelPilot"
    return ok, string.format("alt %s (%d×), ohne beide %s", S(a), used, S(b)), "LevelPilot (1×), LevelPilot"
end

IMPL.T111 = function()
    local Gp, Se = LP.Group, LP.Session
    if not Gp.Send then return false, "Group.Send fehlt", "zugänglich" end
    return WithSetting({ groupSync = true }, function()
        local mark = ActMark()
        WithEnv({ Gp.Send, Gp.InGroup }, { C_ChatInfo = false, SendAddonMessage = function() end, IsInGroup = function() return true end },
            function() Gp.Send("R") end)
        local a = ActSince(mark, "SendAddonMessage")
        mark = ActMark()
        WithEnv({ Gp.Send, Gp.InGroup }, { C_ChatInfo = false, SendAddonMessage = false, IsInGroup = function() return true end },
            function() Gp.Send("R") end)
        local b = ActSince(mark, "SendAddonMessage")
        mark = ActMark()
        WithEnv({ Se.Summary }, { C_ChatInfo = false, SendChatMessage = false, IsInGuild = function() return true end },
            function() Se:Summary(true) end)
        local c = ActSince(mark, "SendChatMessage")
        return a == 1 and b == 0 and c == 0, string.format("alt %d, ohne beide %d, Bilanz %d", a, b, c), "1, 0, 0"
    end)
end

-- Flug-Schritt vorgeben (Engine:Current, Addon-Tabelle)
local function FlyStep(body)
    local E = LP.Engine
    local orig = E.Current
    E.Current = function() return { t = "FLY", text = "LPTestflugpunkt", key = "LPTestFlug" } end
    return Guard(body, function() E.Current = orig end)
end

-- weitere alte Globals, je einzeln weg
IMPL.T112 = function()
    local E, C, A, Su, H, Ac = LP.Engine, LP.Comfort, LP.Advisor, LP.Supply, LP.Hints, LP.Actions
    local step = { t = "COMPLETE", id = 999105, key = "LPTest" }
    local cases = {
        { { E.HandleGreeting }, "GetNumActiveQuests", function() E.HandleGreeting() end },
        { { E.HandleGreeting }, "GetActiveTitle", function() E.HandleGreeting() end },
        { { E.HandleGreeting }, "SelectActiveQuest", function() E.HandleGreeting() end },
        { { E.HandleGreeting }, "GetNumAvailableQuests", function() E.HandleGreeting() end },
        { { C.Repair }, "GetRepairAllCost", function() C:Repair() end, { CanMerchantRepair = function() return true end } },
        { { A.Checks.Durability }, "GetInventoryItemDurability", function() A.Checks.Durability(function() end) end },
        { { A.Checks.Ammo }, "GetInventoryItemCount", function() A.Checks.Ammo(function() end) end,
          { UnitClass = function() return "Jäger", "HUNTER" end, GetInventoryItemLink = function() return "item:2504" end } },
        { { Su.Needs }, "GetItemInfoInstant", function() Su:Needs() end,
          { C_Item = Without(C_Item, "GetItemInfoInstant") or false, UnitClass = function() return "Jäger", "HUNTER" end,
            GetInventoryItemLink = function() return "item:2504" end } },
        { { C.AutoFly }, "NumTaxiNodes", function() FlyStep(function() C:AutoFly() end) end },
        { { C.AutoFly }, "TaxiNodeName", function() FlyStep(function() C:AutoFly() end) end },
        { { H.LearnTrainerCosts }, "GetNumTrainerServices", function() H:LearnTrainerCosts() end },
        { { H.ClassReminders }, "GetWeaponEnchantInfo", function() H.ClassReminders(function() end) end,
          { UnitClass = function() return "Schurke", "ROGUE" end } },
        { { Ac.ItemFor }, "GetQuestLogSpecialItemInfo", function() Ac.ItemFor(step) end },
        { { Ac.Update }, "GetItemIcon", function() Ac:Update() end, { C_Item = Without(C_Item, "GetItemIconByID") or false } },
    }
    local bad = {}
    WithSetting({ autoTurnin = true, autoAccept = true, autoRepair = true, autoFly = true, advDurability = true, advAmmo = true,
                  restockAmmo = true, hintClass = true }, function()
        for _, c in ipairs(cases) do
            local fake = { [c[2]] = false }
            for k, v in pairs(c[4] or {}) do fake[k] = v end
            local ok, err = pcall(WithEnv, c[1], fake, c[3])
            if not ok then bad[#bad + 1] = c[2] .. ": " .. tostring(err):sub(1, 80) end
        end
    end)
    return #bad == 0, #bad == 0 and (#cases .. " Fälle ohne Fehler") or table.concat(bad, "; "), "kein Lua-Fehler"
end

IMPL.T113 = function()
    local Nm = LP.Names
    local threw = 0
    return WithEnv({ Nm.Init }, { collectgarbage = function() threw = threw + 1 error("LP-Testfehler collectgarbage", 0) end }, function()
        local ok, err = pcall(Nm.Init, Nm)
        local st = Nm:StatusText()
        return ok and type(st) == "string", ok and ("Laden zu Ende" .. (threw > 0 and ", collectgarbage warf" or "")) or tostring(err),
            "Laden läuft zu Ende"
    end)
end
IMPL.T190 = IMPL.T113

IMPL.T114 = function()
    local Ac = LP.Actions
    local btn = _G.LevelPilotTargetButton
    if not btn then return false, "LevelPilotTargetButton fehlt", "vorhanden" end
    -- Zustand vorher/nachher vergleichen (der sichere Knopf selbst wird nie verändert)
    local function state()
        return tostring(btn.GetAttribute and btn:GetAttribute("macrotext")), btn:IsShown() and true or false,
            Ac.bar and Ac.bar:IsShown() and true or false
    end
    local m1, s1, b1 = state()
    local touched = 0
    local fake = { InCombatLockdown = function() return true end }
    WithEnv({ Ac.Update }, fake, function()
        WithCounter(LP.Engine, "Current", function(n)
            Ac:Update()
            touched = n()
        end)
    end)
    local m2, s2, b2 = state()
    local inCombat = touched == 0 and m1 == m2 and s1 == s2 and b1 == b2
    -- nach dem Kampf: PLAYER_REGEN_ENABLED holt die Aktualisierung nach
    local runs = WithCounter(Ac, "Update", function(n)
        for _, fn in ipairs(HandlerList("PLAYER_REGEN_ENABLED")) do pcall(fn, "PLAYER_REGEN_ENABLED") end
        return n()
    end, true)
    return inCombat and runs >= 1, string.format("im Kampf: Schritt gelesen %d×, Knopf %s · danach %d Aktualisierung", touched,
        inCombat and "unverändert" or "verändert", runs), "0×, unverändert · danach >= 1"
end

------------------------------------------------------------------------
-- J. Regressionstests (3.12.6)
------------------------------------------------------------------------
IMPL.T169 = function()
    return WithFlavor("forever", function()
        local a = LP.SameName("Rokan", "Rokan Steinwacht")
        local b = LP.SameName("Rokan Steinwacht", "Rokan Eisenfaust")
        local me = UnitName("player")
        local realm = GetRealmName and GetRealmName() or "Realm"
        local own = tostring(me) .. "-" .. tostring(realm):gsub("%s", "")
        local members = Count(LP.Group.members)
        local c = WithCounter(LP.Comm, "Receive", function(n)
            CallHandlers("CHAT_MSG_ADDON", "LvPilot2", "LPTestNachricht", "WHISPER", own)
            CallHandlers("CHAT_MSG_ADDON", "LvPilotG", "S\t5\t10\tGOTO\t0\ttext", "PARTY", own)
            return n()
        end)
        local m2 = Count(LP.Group.members)
        return a == true and b == false and c == 0 and m2 == members, string.format("%s, %s, eigene Nachricht: Comm %d, Group %+d",
            S(a), S(b), c, m2 - members), "true, false, 0, +0"
    end)
end

CLIENT.T171 = "/dump select(4, GetBuildInfo()) – Nummer in LevelPilot.toc und LevelPilot_Data.toc, 16001 bleibt drin"

IMPL.T177 = function()
    local P, Ca = LP.Planner, LP.Calib
    local a = { IMPL.T74() }
    local b = { IMPL.T94() }
    local L0 = UnitLevel("player") or 1
    if L0 >= 60 or L0 < 6 then return a[1] and b[1] and true or false, "Level " .. L0 .. " – Messung auf Stufe -3 nicht möglich" end
    return WithEmptyCalib(function()
        return WithSetting({ forever = true }, function()
            return WithFlavor("forever", function()
                local f = P:KillXPFormula(L0, L0 - 3)
                for _ = 1, 20 do SimKill(L0 - 3, math.floor(f * 0.7 + 0.5)) end
                local r = Ca:KillXPRatio(-3)
                local g, measured = P:GreenXPFactor(-3)
                local txt = Ca:KillXPText()
                local ok = a[1] and b[1] and r ~= nil and Near(g, r, 0.001) and measured == true and txt:find("20", 1, true) ~= nil
                return ok and true or false, string.format("T74 %s, T94 %s, Stufe -3: %.2f (%s), %s", S(a[1]), S(b[1]), g or 0,
                    S(measured), txt), "OK, OK, Messwert ersetzt 0.85, gemessen 20"
            end)
        end)
    end)
end

IMPL.T179 = function()
    local key = "aus deinen EP der letzten Stunde – gilt für jeden Modus (Normal und Speedrun)"
    local miss = {}
    for _, code in ipairs(CODES) do
        local t = LP.Locales[code]
        local fb = LP.LanguageInfo[code] and LP.LanguageInfo[code].fallback
        if not ((t and t[key]) or (fb and LP.Locales[fb] and LP.Locales[fb][key])) then miss[#miss + 1] = code end
    end
    local f = _G.LevelPilotCenter
    local wasShown = f and f:IsShown()
    local shown = Guard(function()
        if not (f and f:IsShown()) then LP.Center:Toggle() end
        LP.Center:Select("comfort")
        return FindText(_G.LevelPilotCenter, L[key])
    end, function() if _G.LevelPilotCenter and not wasShown then _G.LevelPilotCenter:Hide() end end)
    return #miss == 0 and shown, "angezeigt " .. S(shown) .. (#miss > 0 and (", fehlt in " .. table.concat(miss, ",")) or ", alle 10 Sprachen"),
        "angezeigt, alle 10 Sprachen"
end

IMPL.T184 = function()
    local B = LP.Backup
    local ok, err = pcall(Slash, "reise bericht")
    local f = _G.LevelPilotBackupFrame
    local titled = f and FindText(f, L["Virtuelle Reise – Bericht"]) or false
    if f then f:Hide() end
    return ok and titled, ok and ("Titel übersetzt " .. S(titled)) or tostring(err), "kein Fehler, Titel übersetzt"
end

IMPL.T195 = function()
    local a = { IMPL.T105() }
    local b = { IMPL.T109() }
    return a[1] and b[1] and true or false, "T105 " .. S(a[1]) .. ", T109 " .. S(b[1]), "beide OK"
end
CLIENT.T195 = "/dump UnitCharacterPoints, /dump GetUnspentTalentPoints, /dump GetPetHappiness, /dump GetPetFoodTypes – Ergebnis zurückmelden"
CLIENT.T213 = "/dump C_SpellBook.IsSpellKnown(3273) und /dump IsPlayerSpell(3273) – Erste Hilfe gelernt? Beide Antworten zurückmelden"

-- K13: Dropraten ohne Kampflog (3.12.6: Kill bei der EP-Meldung, Stück über CHAT_MSG_LOOT)
IMPL.T196 = function()
    local Ca = LP.Calib
    local g = G()
    if not (g and g.IsModern) then return true, "alter Client: Kampflog wie bisher" end
    local item, npc = 999006, 99906
    local guid = "Creature-0-1-1-1-" .. npc .. "-0000ABCD01"
    local guid2 = "Creature-0-1-1-1-" .. npc .. "-0000ABCD02"
    local s = LevelPilotDB.calib or {}
    LevelPilotDB.calib = s
    s.drops = type(s.drops) == "table" and s.drops or {}
    local saved, savedW = s.drops[item], Ca.testWanted
    s.drops[item] = nil
    Ca.testWanted = { [item] = { npc = { [npc] = true } } }
    local link = "|cffffffff|Hitem:" .. item .. "::::::::|h[x]|h|r"
    local tguid = guid
    local target = { UnitExists = function() return true end, UnitGUID = function() return tguid end, UnitIsDead = function() return true end }
    local loot = {
        GetNumLootItems = function() return 1 end,
        GetLootSlotLink = function() return link end,
        GetLootSourceInfo = function() return tguid, 2 end,
        UnitExists = function() return false end,
    }
    local selfMsg = (LOOT_ITEM_SELF_MULTIPLE and LOOT_ITEM_SELF_MULTIPLE:gsub("%%%d?%$?s", link, 1):gsub("%%%d?%$?d", "2", 1))
        or ("Ihr bekommt Beute: " .. link .. "x2.")
    local function D() local d = s.drops[item] or { k = 0, g = 0 } return d.k, d.g end
    return Guard(function()
        -- 1) Kill bei der EP-Meldung, Leiche ohne Beute (nie geöffnet)
        WithEnv({ Ca.OnXPKill }, target, function() Ca:OnXPKill() end)
        local k1, g1 = D()
        -- 2) zweite Leiche: EP-Meldung, dann plündern (Kill nicht doppelt), Beutemeldung x2
        tguid = guid2
        WithEnv({ Ca.OnXPKill }, target, function() Ca:OnXPKill() end)
        WithEnv({ Ca.OnLootOpened, Ca.IsPickpocket }, loot, function() Ca:OnLootOpened() end)
        Ca:OnLoot(selfMsg)
        Ca:OnLootClosed()
        local k2, g2 = D()
        -- 3) erneut geöffnet, Tasche voll: nichts kommt an -> keine Stück
        WithEnv({ Ca.OnLootOpened, Ca.IsPickpocket }, loot, function() Ca:OnLootOpened() end)
        Ca:OnLootClosed()
        local k3, g3 = D()
        -- 4) geschützte GUID bei der EP-Meldung -> kein Kill
        tguid = "Creature-0-1-1-1-" .. npc .. "-0000ABCD03"
        WithSecret({ tguid }, function() WithEnv({ Ca.OnXPKill }, target, function() Ca:OnXPKill() end) end)
        local k4 = D()
        local ok = k1 == 1 and g1 == 0 and k2 == 2 and g2 == 2 and k3 == 2 and g3 == 2 and k4 == 2
        return ok, string.format("ohne Beute %d/%d · geplündert %d/%d · liegen gelassen %d/%d · geschützt %d", k1, g1, k2, g2, k3, g3, k4),
            "1/0 · 2/2 · 2/2 · 2 (Kills/Stück)"
    end, function()
        s.drops[item] = saved
        Ca.testWanted = savedW
        Ca.ResetLooted(guid) Ca.ResetLooted(guid2) Ca.ResetLooted(tguid)
    end)
end

IMPL.T201 = function()
    local Tt, Q = LP.Tooltips, LP.QuestDB
    local I = _G.LevelPilotData and _G.LevelPilotData.I
    local item
    local n = 0
    for id in pairs(type(I) == "table" and I or {}) do
        n = n + 1
        local info = Q:ItemQuests(id)
        if info and info.starts and #info.starts > 0 then item = id break end
        if n > 3000 then break end
    end
    if not item then return true, "kein Gegenstand, der eine Quest startet (ohne Datenpaket)" end
    return WithSetting({ tooltips = true }, function()
        return WithCounter(LP.API, "IsQuestDone", function(calls)
            Tt:ItemLines(item)
            Tt:IsProtected(item)
            return calls() >= 1, "LP.API.IsQuestDone " .. calls() .. "×", ">= 1×"
        end, true)
    end)
end

------------------------------------------------------------------------
-- B. Funktionen (3.12.6)
------------------------------------------------------------------------
local function Shown(name) local f = _G[name] return f and f:IsShown() and true or false end
local function Hide(name) local f = _G[name] if f then f:Hide() end end

-- alle Slash-Befehle in pcall: Fehlerliste
local function SlashAll(list)
    local bad = {}
    for _, m in ipairs(list) do
        local ok, err = pcall(Slash, m)
        if not ok then bad[#bad + 1] = "\"" .. m .. "\": " .. tostring(err):sub(1, 80) end
    end
    return bad
end

IMPL.T16 = function()
    local ui0, ce0, compact0 = LP.UI:IsShown(), Shown("LevelPilotCenter"), LP.db.compactMode
    local bad = SlashAll({ "" })
    local ui1 = LP.UI:IsShown()
    bad = SlashAll({ "" })
    local ce = {}
    for _, m in ipairs({ "zentrale", "center" }) do
        local a = Shown("LevelPilotCenter")
        for _, e in ipairs(SlashAll({ m })) do bad[#bad + 1] = e end
        ce[#ce + 1] = Shown("LevelPilotCenter") ~= a
    end
    for _, m in ipairs({ "kompakt", "kompakt", "compact", "compact" }) do for _, e in ipairs(SlashAll({ m })) do bad[#bad + 1] = e end end
    local donate = {}
    for _, m in ipairs({ "spenden", "donate", "support" }) do
        for _, e in ipairs(SlashAll({ m })) do bad[#bad + 1] = e end
        local f = LP.Donate.frame or _G.LevelPilotDonateFrame
        donate[#donate + 1] = f == nil or f:IsShown()
        if f then f:Hide() end
    end
    if LP.UI:IsShown() ~= ui0 then LP.UI:Toggle() end
    if Shown("LevelPilotCenter") ~= ce0 then LP.Center:Toggle() end
    local ok = #bad == 0 and ui1 ~= ui0 and ce[1] and ce[2] and LP.db.compactMode == compact0 and donate[1] and donate[2] and donate[3]
    return ok and true or false, #bad > 0 and table.concat(bad, "; ") or string.format("Guide wechselt %s, Zentrale %s/%s, kompakt gleich %s",
        S(ui1 ~= ui0), S(ce[1]), S(ce[2]), S(LP.db.compactMode == compact0)), "alles wechselt, kompakt wie vorher"
end

IMPL.T18 = function()
    local P = LP.Planner
    local old = P.priority
    return Guard(function()
        local bad = SlashAll({ "way 45.5 60.2" })
        local p1 = P.priority
        local a = p1 and p1.t == "GOTO" and Near(p1.x, 45.5, 0.01) and Near(p1.y, 60.2, 0.01)
        for _, e in ipairs(SlashAll({ "weg 10 20" })) do bad[#bad + 1] = e end
        local p2 = P.priority
        local b = p2 and p2.t == "GOTO" and Near(p2.x, 10, 0.01) and Near(p2.y, 20, 0.01)
        for _, e in ipairs(SlashAll({ "find repar", "such flug", "find xyz" })) do bad[#bad + 1] = e end
        local pos = LP.Geo:Player() ~= nil
        return #bad == 0 and ((a and b) or not pos) and true or false,
            #bad > 0 and table.concat(bad, "; ") or ("way " .. S(a) .. ", weg " .. S(b)), "GOTO 45.5/60.2 und 10/20, kein Fehler"
    end, function() P.priority = old pcall(P.Replan, P) end)
end

IMPL.T20 = function()
    local mark = ActMark()
    local bad = SlashAll({ "teilen", "share", "gruppe", "lfg", "bilanz", "summary", "bilanz gilde", "summary guild" })
    local guild = IsInGuild and IsInGuild() and ((C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage) and true or false
    local sent = ActSince(mark, "SendChatMessage")
    local push = ActSince(mark, "QuestLogPushQuest")
    local share = LP.Social:ShareList()
    local sum = LP.Session:Summary(false)
    local want = L("LevelPilot-Bilanz: %d Level, %d Quests, %s, %s aktiv gespielt", 0, 0, "", ""):match("^[^:]+")
    local ok = #bad == 0 and (guild and sent == 2 or (not guild and sent == 0)) and (push == 0 or #share > 0)
        and type(sum) == "string" and sum:sub(1, #want) == want
    return ok and true or false, #bad > 0 and table.concat(bad, "; ") or string.format("Gilde %s: %d mitgeschrieben, Teilen %d, Bilanz %s",
        S(guild), sent, push, sum:sub(1, #want)), "Gilde nur mit Gilde, Bilanz-Text"
end

IMPL.T21 = function()
    local Pr = LP.Protocol
    local f = function() return _G.LevelPilotBackupFrame end
    local opened = {}
    local bad = {}
    for _, m in ipairs({ "protokoll", "log", "diag", "diagnose", "plan", "messen", "measure", "test", "selbsttest" }) do
        if f() then f():Hide() end
        for _, e in ipairs(SlashAll({ m })) do bad[#bad + 1] = e end
        if m == "protokoll" or m == "messen" or m == "test" then opened[#opened + 1] = f() and f():IsShown() or false end
        if f() then f():Hide() end
    end
    for _, e in ipairs(SlashAll({ "protokoll leer" })) do bad[#bad + 1] = e end
    local n = Pr:Count()
    local ok = #bad == 0 and n == 0 and opened[1] and opened[2] and opened[3]
    return ok and true or false, #bad > 0 and table.concat(bad, "; ") or string.format("Kopierfenster %s/%s/%s, Protokoll danach %d",
        S(opened[1]), S(opened[2]), S(opened[3]), n), "Fenster auf und zu, Protokoll 0"
end

IMPL.T22 = function()
    local V = LP.Virtual
    if not LP:IsDev() then
        local bad = SlashAll({ "reise hier" })
        local was = V.active
        if V.active then V:Abort() end
        return #bad == 0 and not was, "ohne Testmodus: Reise gestartet " .. S(was), "nichts"
    end
    local bad = SlashAll({ "reise hier", "reise stop", "reise zuschauen", "reise stopp", "reise bericht", "journey report" })
    Hide("LevelPilotBackupFrame") Hide("LevelPilotVirtualFrame")
    local active = V.active
    if V.active then V:Abort() end
    local sb = V.s and V.s.sandboxDiff
    local ok = #bad == 0 and not active and (sb == nil or #sb == 0)
    return ok, #bad > 0 and table.concat(bad, "; ") or ("Reise aktiv " .. S(active) .. ", Sandbox " .. (sb and #sb == 0 and "OK" or "?")),
        "aus, Sandbox OK (\"reise vergleich\" nur mit /lp testroutine reise)"
end

IMPL.T25 = function()
    local UI = LP.UI
    local db = LP.db
    local saved = { db.compactMode, db.stepsShown, db.scale, db.locked }
    local was = UI:IsShown()
    return Guard(function()
        UI:Toggle() UI:Toggle()
        local same = UI:IsShown() == was
        if not UI:IsShown() then UI:Toggle() end
        for _, v in ipairs({ true, false }) do db.compactMode = v UI:ApplySettings() UI:Refresh() end
        for _, v in ipairs({ 1, 5, 10 }) do db.stepsShown = v UI:ApplySettings() UI:Refresh() end
        for _, v in ipairs({ 0.6, 1.6 }) do db.scale = v UI:ApplySettings() UI:Refresh() end
        for _, v in ipairs({ true, false }) do db.locked = v UI:ApplySettings() end
        local grip = type(UI.CreateSizeGrip) == "function"
        local cur = LP.Engine:Current()
        local txt = cur and UI:StepText(cur, false)
        local ok = same and grip and (cur == nil or (type(txt) == "string" and txt ~= ""))
        return ok, string.format("Toggle zweimal gleich %s, Text %s", S(same), cur and S(txt ~= "") or "kein Schritt"), "kein Fehler, Text"
    end, function()
        db.compactMode, db.stepsShown, db.scale, db.locked = saved[1], saved[2], saved[3], saved[4]
        UI:ApplySettings()
        if UI:IsShown() ~= was then UI:Toggle() end
    end)
end

IMPL.T26 = function()
    local E, UI = LP.Engine, LP.UI
    local step = E:Current()
    if not step then return true, "kein Schritt geplant" end
    if step.t == "LEVEL" or step.key == "NODATA" or step.key == "NOPOS" or step.key == "DGIN" then
        return true, "aktueller Schritt lässt sich nicht überspringen (" .. tostring(step.t) .. ")"
    end
    local saved = {}
    for _, k in ipairs({ "ignored", "doneKeys", "notOffered", "dungeonRun" }) do saved[k] = LP.Backup.DeepCopy(LP.char[k] or {}) end
    local lastIgn = E.lastIgnored
    local function planned()
        for _, s in ipairs(E:Steps()) do if s.key == step.key then return true end end
        return false
    end
    return Guard(function()
        UI:StepMenu(nil, step)
        local menuShown = Shown("LevelPilotStepMenu")
        Hide("LevelPilotStepMenu")
        E:Skip(step)
        local gone = not planned()
        local quest = step.id and (step.t == "ACCEPT" or step.t == "COMPLETE" or step.t == "TURNIN")
        if quest then E:Unignore() else LP.char.doneKeys[step.key] = nil end
        LP.Planner:Replan(true)
        local back = planned()
        E:Later(step)
        local later = E:IsLater(step.key) and not planned()
        E.later[step.key] = nil
        E:ResetIgnored()
        return menuShown and gone and back and later, string.format("Menü %s, übersprungen %s, wieder geplant %s, zurückgestellt %s",
            S(menuShown), S(gone), S(back), S(later)), "Menü, übersprungen, wieder geplant, zurückgestellt"
    end, function()
        E.later[step.key] = nil
        E.lastIgnored = lastIgn
        for k, v in pairs(saved) do
            local cur = LP.char[k]
            if type(cur) == "table" then
                for kk in pairs(cur) do if v[kk] == nil then cur[kk] = nil end end
                for kk, vv in pairs(v) do cur[kk] = vv end
            end
        end
        pcall(LP.Planner.Replan, LP.Planner, true)
    end)
end

IMPL.T28 = function()
    local b = _G.LevelPilotMinimapButton
    if not b then return false, "Minimap-Button fehlt", "vorhanden" end
    local was, angle = LP.db.showMinimapBtn, LP.db.minimapAngle
    return Guard(function()
        LP.db.showMinimapBtn = false LP.UI:ApplySettings()
        local off = not b:IsShown()
        LP.db.showMinimapBtn = true LP.UI:ApplySettings()
        local on = b:IsShown() and true or false
        return off and on and LP.db.minimapAngle == angle, "aus versteckt " .. S(off) .. ", an sichtbar " .. S(on), "versteckt, sichtbar, Winkel gleich"
    end, function() LP.db.showMinimapBtn = was LP.UI:ApplySettings() end)
end

IMPL.T29 = function()
    local a = _G.LevelPilotArrow
    local was = LP.db.showArrow
    return Guard(function()
        LP.db.showArrow = false
        LP.Nav:Refresh()
        local hidden = not a or not a:IsShown()
        LP.db.showArrow = true
        LP.Nav:Refresh()
        return hidden, "aus versteckt " .. S(hidden), "versteckt"
    end, function() LP.db.showArrow = was pcall(LP.Nav.Refresh, LP.Nav) end)
end

-- Zentrale öffnen und alle Reiter einmal aufbauen
local function WithCenter(body)
    local f = _G.LevelPilotCenter
    local was = f and f:IsShown()
    return Guard(function()
        if not (_G.LevelPilotCenter and _G.LevelPilotCenter:IsShown()) then LP.Center:Toggle() end
        for _, k in ipairs({ "route", "dungeons", "data", "share", "assist", "comfort", "extras", "settings" }) do LP.Center:Select(k) end
        return body()
    end, function() if _G.LevelPilotCenter and not was then _G.LevelPilotCenter:Hide() end end)
end

IMPL.T31 = function()
    return WithCenter(function()
        local list, seen = {}, {}
        for i = #(LP.Center.toggles or {}), 1, -1 do
            local t = LP.Center.toggles[i]
            if not seen[t.key] then seen[t.key] = true list[#list + 1] = t end
        end
        local mark = ActMark()
        local bad, changed = {}, {}
        for _, t in ipairs(list) do
            local before = LP.db[t.key]
            local ok1, e1 = pcall(t.button.Click, t.button)
            local mid = LP.db[t.key]
            local ok2, e2 = pcall(t.button.Click, t.button)
            if not ok1 or not ok2 then bad[#bad + 1] = t.key .. ": " .. tostring(e1 or e2):sub(1, 60)
            elseif LP.db[t.key] ~= before then changed[#changed + 1] = t.key
            elseif (not mid) == (not before) then bad[#bad + 1] = t.key .. ": schaltet nicht" end
        end
        local joins = ActSince(mark, "JoinTemporaryChannel")
        local real = 0
        for i = mark + 1, #LP.Act.log do if LP.Act.log[i].name ~= "JoinTemporaryChannel" and LP.Act.log[i].name ~= "SendAddonMessage" then real = real + 1 end end
        local ok = #bad == 0 and #changed == 0 and #list >= 60
        return ok, string.format("%d Schalter, Fehler: %s, nicht zurück: %s, Kanal-Beitritt mitgeschrieben %d", #list,
            #bad > 0 and table.concat(bad, "; ") or "keine", #changed > 0 and table.concat(changed, ",") or "keine", joins),
            ">= 60 Schalter, alle zweimal, Wert wie vorher"
    end)
end

IMPL.T32 = function()
    return WithCenter(function()
        local bad = {}
        local list = {}
        local seen = {}
        for i = #(LP.Center.steppers or {}), 1, -1 do
            local st = LP.Center.steppers[i]
            if not seen[st.label] then seen[st.label] = true list[#list + 1] = st end
        end
        for _, st in ipairs(list) do
            -- Seite des Steppers zeigen (die Anzeige wird nur auf der sichtbaren Seite erneuert)
            for k, p in pairs(LP.Center.pages or {}) do if p == st.page then LP.Center:Select(k) end end
            local v0 = st.get()
            local ok, err = pcall(function()
                local steps = math.ceil((st.max - st.min) / st.step) + 2
                for _ = 1, steps do st.plus:Click() end
                if math.abs(st.get() - st.max) > 1e-6 then error("Maximum " .. tostring(st.get()) .. " statt " .. st.max, 0) end
                local txt = st.val:GetText()
                if txt ~= string.format(st.fmt, st.get()) then error("Text " .. tostring(txt), 0) end
                for _ = 1, steps do st.minus:Click() end
                if math.abs(st.get() - st.min) > 1e-6 then error("Minimum " .. tostring(st.get()) .. " statt " .. st.min, 0) end
                txt = st.val:GetText()
                if txt ~= string.format(st.fmt, st.get()) then error("Text " .. tostring(txt), 0) end
            end)
            st.set(v0)
            if not ok then bad[#bad + 1] = tostring(st.label):sub(1, 30) .. ": " .. tostring(err) end
            if st.get() ~= v0 then bad[#bad + 1] = tostring(st.label):sub(1, 30) .. ": nicht zurück" end
        end
        LP.UI:ApplySettings()
        LP.Center:Refresh()
        -- im Code gibt es 11 Stepper; einen zwölften "Vorräte" hat die Zentrale nicht (Mengen kommen aus den Grundwerten)
        return #bad == 0 and #list >= 11, #list .. " Stepper" .. (#bad > 0 and (": " .. table.concat(bad, "; ")) or ""),
            "alle Stepper (11 im Code), Grenzen halten, Text = format(Wert)"
    end)
end

IMPL.T33 = function()
    return WithCenter(function()
        LP.Center:Select("comfort")
        local n = 0
        for _, l in ipairs(LP.LANGUAGES) do if LP:CanDisplay(l.code) then n = n + 1 end end
        local btn = 0
        for _, e in ipairs(LP.Center.langButtons or {}) do if e.button:IsShown() then btn = btn + 1 end end
        return btn == n + 1, "Knöpfe " .. S(btn) .. ", anzeigbare Sprachen " .. n, "1 + anzeigbare Sprachen"
    end)
end

IMPL.T34 = function()
    return WithCenter(function()
        LP.Center:Select("data")
        local bad = {}
        local B = LP.Backup
        for _, fn in ipairs({ function() LP.QuestDB:Reconnect() end, function() LP.Planner:Diagnose() end,
                              function() LP.Protocol:Show() end, function() LP.SelfTest:Show(false) end,
                              function() B:ShowExport() end, function() B:ShowImport() end }) do
            local ok, err = pcall(fn)
            if not ok then bad[#bad + 1] = tostring(err):sub(1, 80) end
            Hide("LevelPilotBackupFrame")
        end
        local jb = LP.Center.journeyButtons or {}
        local vis = 0
        for _, b in ipairs(jb) do if b:IsShown() then vis = vis + 1 end end
        local want = LP:IsDev() and #jb or 0
        return #bad == 0 and #jb == 3 and vis == want, string.format("Fehler %d, Reiseknöpfe %d sichtbar von %d", #bad, vis, #jb),
            "kein Fehler, 3 Reiseknöpfe nur im Testmodus"
    end)
end

IMPL.T36 = function()
    local Gp = LP.Group
    local who = "LPTester-Test"
    local saved = Gp.members.LPTester
    return Guard(function()
        Gp:OnMessage("S\t5\t10\tGOTO\t0\ttext", who)
        Gp:Refresh()
        local st = Gp:Status(Gp.members.LPTester or {})
        local shared = Gp:SharedQuests()
        local panel = _G.LevelPilotGroupPanel
        local inGroup = IsInGroup and IsInGroup() or false
        local hidden = inGroup or not panel or not panel:IsShown()
        return hidden and (shared == nil or type(shared) == "table"), "Status " .. S(st) .. ", Panel ohne Gruppe versteckt " .. S(hidden), "kein Fehler, versteckt"
    end, function() Gp.members.LPTester = saved pcall(Gp.Refresh, Gp) end)
end

IMPL.T37 = function()
    local Ac = LP.Actions
    local was = LP.db.showActionBar
    return Guard(function()
        LP.db.showActionBar = false Ac:Update()
        LP.db.showActionBar = true Ac:Update()
        local m = Ac.MacroText({ "Kobold", "Wolf" })
        local long = {}
        for i = 1, 30 do long[i] = "Sehr langer Name eines Gegners Nummer " .. i end
        local m2 = Ac.MacroText(long)
        local b1 = _G["BINDING_NAME_CLICK LevelPilotTargetButton:LeftButton"]
        local b2 = _G["BINDING_NAME_CLICK LevelPilotItemButton:LeftButton"]
        local ok = m:sub(1, 12) == "/cleartarget" and m:find("/targetexact Kobold", 1, true) ~= nil and #m2 <= 255 and b1 ~= nil and b2 ~= nil
        return ok, string.format("Makro %d Zeichen, lang %d Zeichen, Tasten %s/%s", #m, #m2, S(b1 ~= nil), S(b2 ~= nil)),
            "/cleartarget … /targetexact Kobold, <= 255, Tasten gesetzt"
    end, function() LP.db.showActionBar = was pcall(Ac.Update, Ac) end)
end

IMPL.T45 = function()
    local P = LP.Planner
    local d = _G.LevelPilotData
    if type(d) ~= "table" or type(d.Q) ~= "table" then return true, "kein Datenpaket" end
    local real = LP.char.mode
    local speed0 = LP.db.speedLevel
    return Guard(function()
        local bad = {}
        for _, lv in ipairs({ 1, 2, 3 }) do
            LP.db.speedLevel = lv
            P:SetMode("speed")
            local ok, err = pcall(P.Replan, P, true)
            if not ok then bad[#bad + 1] = lv .. ": " .. tostring(err):sub(1, 60) end
        end
        LP.db.speedLevel = 2
        P:Replan(true)
        local escort, protectedSkipped = nil, nil
        for id in pairs(P.speedSkip) do
            local q = d.Q[id]
            if type(q) == "table" and q.tg == 84 then escort = id end
            if P:IsProtected(id) then protectedSkipped = id end
        end
        if #bad > 0 then return false, table.concat(bad, "; "), "kein Fehler" end
        if not escort then return true, "keine Eskortenquest im Bereich – Stufen 1–3 ohne Fehler, keine Klassenquest übersprungen: " .. S(protectedSkipped == nil) end
        return protectedSkipped == nil, "Eskorte " .. escort .. " übersprungen, Klassenquest übersprungen: " .. S(protectedSkipped), "Eskorte ja, Klassenquest nein"
    end, function() LP.db.speedLevel = speed0 P:SetMode(real) end)
end

IMPL.T46 = function()
    local P = LP.Planner
    local ov = P:DungeonOverview()
    local n = type(ov) == "table" and #ov or 0
    for _, d in ipairs(LP.Dungeons or {}) do P:DungeonUsable(d.area or d.id or d[1]) break end
    P:PlanInstance(LP:PlayerLevel() or 1)
    local rows = WithCenter(function()
        LP.Center:Select("dungeons")
        return FindText(_G.LevelPilotCenter, L["Dungeons"]) or n == 0
    end)
    return type(ov) == "table" and rows and true or false, n .. " Dungeons in der Übersicht", "Liste, Reiter zeigt Zeilen"
end

IMPL.T48 = function()
    local E = LP.Engine
    local id = 999301
    local ign = LP.char.ignored
    local saved = ign[id]
    ign[id] = true
    return Guard(function()
        local want = E:WantQuest(id, "LPTest")
        E:CheckSteps()
        local dg = E:InDungeon()
        local inInst = IsInInstance and select(1, IsInInstance())
        E:UpdateInstance()
        return want == false and (dg == false or (inInst and true or false)), "WantQuest " .. S(want) .. ", Dungeon " .. S(dg), "false, false"
    end, function() ign[id] = saved end)
end

IMPL.T49 = function()
    local id = 999302
    local mark = ActMark()
    local choices = 0
    local selActive = {}
    local gossip = {
        GetActiveQuests = function() return { { title = "Fertig", questID = 999303, isComplete = true } } end,
        GetAvailableQuests = function() return { { title = "Neu", questID = id } } end,
        SelectActiveQuest = function(q) selActive[#selActive + 1] = q end,
        SelectAvailableQuest = function() end,
    }
    local fake = {
        GetQuestID = function() return id end, GetTitleText = function() return "LPTest" end,
        IsQuestCompletable = function() return true end, GetNumQuestChoices = function() return choices end,
        C_GossipInfo = gossip, IsShiftKeyDown = function() return false end,
    }
    local list = {}
    for _, ev in ipairs({ "QUEST_DETAIL", "QUEST_PROGRESS", "QUEST_COMPLETE", "GOSSIP_SHOW", "QUEST_GREETING" }) do
        for _, fn in ipairs(HandlerList(ev)) do list[#list + 1] = fn end
    end
    list[#list + 1] = LP.Engine.HandleGossip
    list[#list + 1] = LP.Engine.HandleGreeting
    local origWant = LP.Engine.WantQuest
    local ign = LP.char.ignored
    local savedIgn = ign[id]
    return Guard(function()
        LP.Engine.WantQuest = function(_, qid) return qid == id and not ign[id] end
        local r = {}
        WithEnv(list, fake, function()
            WithSetting({ autoAccept = true, autoTurnin = true }, function()
                local m = ActMark()
                CallHandlers("QUEST_DETAIL")
                r.accept = ActSince(m, "AcceptQuest")
                m = ActMark()
                WithSetting({ autoAccept = false }, function() CallHandlers("QUEST_DETAIL") end)
                r.acceptOff = ActSince(m, "AcceptQuest")
                for _, c in ipairs({ 0, 1, 2 }) do
                    choices = c
                    m = ActMark()
                    CallHandlers("QUEST_COMPLETE")
                    r["c" .. c] = ActSince(m, "GetQuestReward")
                end
                m = ActMark()
                CallHandlers("GOSSIP_SHOW")
                local first = LP.Act.log[m + 1]
                r.gossip = first and first.name or "-"
                ign[id] = true
                m = ActMark()
                CallHandlers("QUEST_DETAIL")
                r.ignored = ActSince(m, "AcceptQuest")
            end)
        end)
        local ok = r.accept == 1 and r.acceptOff == 0 and r.c0 == 1 and r.c1 == 1 and r.c2 == 0 and r.gossip == "SelectActiveQuest" and r.ignored == 0
        return ok, string.format("Annehmen %d/%d, Belohnung 0:%d 1:%d 2:%d, Gossip zuerst %s, ignoriert %d", r.accept, r.acceptOff,
            r.c0, r.c1, r.c2, r.gossip, r.ignored), "1/0, 1 1 0, SelectActiveQuest, 0"
    end, function() LP.Engine.WantQuest = origWant ign[id] = savedIgn end)
end

IMPL.T51 = function()
    local Gr, Geo = LP.Graph, LP.Geo
    local st = Gr:Stats()
    local i1, n1, w1 = Geo:ToWorld(1411, 0.52, 0.44)
    local i2, n2, w2 = Geo:ToWorld(1454, 0.45, 0.55)
    if not i1 then return false, "Geo:ToWorld(1411) liefert nichts", "Weltkoordinaten" end
    local path = i2 and Gr:Path(i1, n1, w1, 1411, i2, n2, w2, 1454)
    local near = Gr:Near(i1, n1, w1, 2000, 1411)
    local nearest = Gr:Nearest(i1, n1, w1, 4000, 1411)
    local s0 = st.nodes or st.count or 0
    local id1 = Gr:AddNode(i1, n1 + 37, w1 + 41, 1411)
    local id2 = Gr:AddNode(i1, n1 + 77, w1 + 81, 1411)
    local added = Gr:AddEdge(id1, id2, "s")
    local st2 = Gr:Stats()
    -- Startwege: so viele, wie die Startdatenbank enthält (Data/Seed.lua, zurzeit leer – die Wege kommen aus dem Wegenetz)
    local seedN = #((LP.Seed and LP.Seed.paths) or {})
    local seedOk = (seedN == 0 and (st.seedEdges or 0) == 0) or (st.seedEdges or 0) > 0
    local st2n = st2.nodes or st2.count or 0
    local ok = seedOk and type(path) == "table" and type(near) == "table" and nearest ~= nil and id1 and id2 and added and st2n >= s0
    return ok and true or false, string.format("Startwege %s (Startdatenbank %d), Weg %s Punkte, Knoten nah %d, neu %s/%s", S(st.seedEdges), seedN,
        S(type(path) == "table" and #path), type(near) == "table" and #near or 0, S(id1), S(id2)), "Startwege > 0, Weg, Knoten"
end

IMPL.T52 = function()
    local T = LP.Terrain
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return true, "kein Datenpaket" end
    local a = T:Available(1411)
    _G.LevelPilotData = nil
    local b = Guard(function() return T:Available(1411) end, function() _G.LevelPilotData = d end)
    local i, n, w = LP.Geo:ToWorld(1411, 0.4, 0.4)
    local i2, n2, w2 = LP.Geo:ToWorld(1411, 0.6, 0.6)
    local seg = T:Segment(1411, { i, n, w }, { i2, n2, w2 })
    local ref = T:Refine({ { i, n, w, 1411 }, { i2, n2, w2, 1411 } })
    T:Unknown(1411, { i, n, w }, { i2, n2, w2 })
    T:Clear()
    LP.Graph:ClearTerrainCache()
    return a == true and b == false and type(ref) == "table", "mit Paket " .. S(a) .. ", ohne " .. S(b) .. ", Strecke " .. S(seg ~= nil),
        "true, false, Punkte"
end

IMPL.T53 = function()
    local Cv = LP.Caves
    local a, b, c = Cv:Count()
    local i, n, w = LP.Geo:ToWorld(1411, 0.33, 0.77)
    local isNew = Cv:Store({ i = i, en = n, ew = w, cn = n + 30, cw = w + 30, r = 60 })
    Cv:Rebuild()
    local a2, b2, c2 = Cv:Count()
    Cv:At(i, n + 30, w + 30)
    Cv:Same({ inst = i, cn = n, cw = w, r = 60 }, { inst = i, cn = n + 5, cw = w, r = 60 })
    Cv:All() Cv:Rebuild() Cv:Tick()
    return type(a) == "number" and type(b) == "number" and type(c) == "number" and isNew and b2 == b + 1,
        string.format("%s/%s/%s -> %s/%s/%s", S(a), S(b), S(c), S(a2), S(b2), S(c2)), "3 Zahlen, +1"
end

IMPL.T54 = function()
    local Dg, Geo = LP.Danger, LP.Geo
    local L0 = UnitLevel("player") or 1
    Dg:Ready()
    local id, npc = PackNpcWithLevel()
    if npc then Dg:MobLevel(npc, id) end
    local i, n, w = Geo:ToWorld(1411, 0.5, 0.5)
    local i2, n2, w2 = Geo:ToWorld(1411, 0.4, 0.3)
    Dg:At(i, n, w) Dg:AtMap(1411, 0.5, 0.5) Dg:Route(i, n, w, n2, w2) Dg:Segment(i, n, w, n2, w2)
    Dg:OK(L0, L0) Dg:Limit(L0)
    local path = { { i, n, w, 1411 }, { i2, n2, w2, 1411 } }
    Dg:PathDanger(path)
    Dg:GrindSpot(i, n, w, L0, 300)
    local grey = L0 - LP.Planner:GreyLevel(L0)
    local minLevel = math.max(1, L0 - 3)
    local kills, sum = Dg:WayKills(path, L0, grey, 120, minLevel)
    local avg = kills > 0 and sum / kills or nil
    local ok = type(kills) == "number" and (kills == 0 or (avg >= minLevel and avg <= L0 + 2))
    return ok, string.format("Weg-Kills %d, Mittel %s", kills, avg and string.format("%.1f", avg) or "–"), "Mittel zwischen " .. minLevel .. " und " .. (L0 + 2)
end

IMPL.T58 = function()
    local R, API = LP.Recorder, LP.API
    local id = 999401
    local saved = LP.db.qdb[id]
    return Guard(function()
        local e = R:Entry(id, true)
        local own = LP.db.qdb[id] == e and e.net == nil
        local a1, a2 = API.AcceptedArgs(1234, nil)
        local b1, b2 = API.AcceptedArgs(3, 1234)
        R:ScanProgress() R:FlushTrail(true) R:SamplePath()
        local n0 = Count(LP.db.vendors)
        WithEnv({ R.RecordService }, { UnitName = function() return nil end }, function() R:RecordService("merchant") end)
        local none = Count(LP.db.vendors) == n0
        local ok = own and a2 == 1234 and a1 == API.LogIndexForQuest(1234) and b1 == 3 and b2 == 1234 and none
        return ok, string.format("Eintrag %s, (1234,nil)->(%s,%s), (3,1234)->(%s,%s), ohne NPC %s", S(own), S(a1), S(a2), S(b1), S(b2),
            none and "nichts" or "angelegt"), "eigener Eintrag, (LogIndex,1234), (3,1234), nichts"
    end, function() LP.db.qdb[id] = saved end)
end

-- leere Sandbox-Questdatenbank
local function WithQdb(tbl, body)
    local saved = LP.db.qdb
    LP.db.qdb = tbl
    LP.QuestDB:Invalidate()
    return Guard(body, function() LP.db.qdb = saved LP.QuestDB:Invalidate() end)
end

IMPL.T59 = function()
    local Comm = LP.Comm
    local sender = "LPTest-Realm"
    local id = 299501
    local i, n, w = LP.Geo:ToWorld(1411, 0.5, 0.5)
    local test = { [id] = { n = "LPTestquest", l = 12, f = "H", s = { i, n, w }, o = { [1] = { { i, n + 20, w + 20 } } } } }
    local msgs = WithQdb(test, function() return Comm:EncodeQuest(id) end) or {}
    local bad = {}
    local res = WithQdb({}, function()
        for _, m in ipairs(msgs) do local ok, err = pcall(Comm.Receive, Comm, m, sender) if not ok then bad[#bad + 1] = err end end
        local r = LP.db.qdb[id]
        local got = r and r.net == true and r.n == "LPTestquest" and r.l == 12 and r.f == "H" and r.o ~= nil
        -- eigener Eintrag: nur Bestätigung
        LP.db.qdb[id + 1] = { n = "Eigen", l = 5, f = "H", by = 0 }
        local enc = WithQdb({ [id + 1] = { n = "Eigen", l = 7, f = "A" } }, function() return Comm:EncodeQuest(id + 1) end)
        LP.db.qdb[id + 1] = { n = "Eigen", l = 5, f = "H", by = 0 }
        for _, m in ipairs(enc or {}) do pcall(Comm.Receive, Comm, m, sender) end
        local o = LP.db.qdb[id + 1]
        local ownOk = o.by == 1 and o.l == 5 and o.f == "H" and o.net == nil
        -- ungültige Quests
        local n0 = Count(LP.db.qdb)
        for _, m in ipairs({ "Q\t299503\t12\tX\t\t\tName\t0", "Q\t0\t12\tH\t\t\tName\t0", "Q\t299504\t99\tH\t\t\tName\t0" }) do
            local ok, err = pcall(Comm.Receive, Comm, m, sender) if not ok then bad[#bad + 1] = err end
        end
        local invalidOk = Count(LP.db.qdb) == n0
        return { got = got, own = ownOk, invalid = invalidOk }
    end)
    -- jede Art gültig und kaputt (Wirkung landet in der Sandbox)
    local item
    for k in pairs((_G.LevelPilotData and _G.LevelPilotData.I) or {}) do item = k break end
    local mob, npc = PackNpcWithLevel()
    local kinds = {
        { "H\t3.12.6", "H" },
        { "Z\t1411", "Z\tx" },
        { "E\t1411\t12\t" .. id, "E\tx\ty" },
        { "C\t" .. (i or 0) .. "\t" .. math.floor(n or 0) .. "\t" .. math.floor(w or 0) .. "\t1411\t" .. math.floor((n or 0) + 30) .. "\t" .. math.floor((w or 0) + 30) .. "\t60", "C\t1\t2" },
        { item and ("D\t" .. item .. "\t10\t5\t2") or "D\t1\t10\t5", "D\tx\t1" },
        { mob and ("M\t" .. mob .. "\t" .. npc.lo .. "\t" .. (npc.lo + 1)) or "M\t1\t1\t2", "M\t1\t70\t1" },
        { "F\t3\t3000\t90", "F\t0" },
        { "P\t" .. (i or 0) .. "\t" .. math.floor(n or 0) .. "," .. math.floor(w or 0) .. ",1411;" .. math.floor((n or 0) + 10) .. "," .. math.floor((w or 0) + 10) .. ",1411\t1", "P\t0\tzz" },
    }
    local leak = 0
    WithQdb({}, function()
        for _, k in ipairs(kinds) do
            local ok1, e1 = pcall(Comm.Receive, Comm, k[1], sender)
            local q0 = Count(LP.db.qdb)
            local c0 = select(1, LP.Caves:Count())
            local ok2, e2 = pcall(Comm.Receive, Comm, k[2], sender)
            if not ok1 then bad[#bad + 1] = k[1]:sub(1, 1) .. ": " .. tostring(e1):sub(1, 60) end
            if not ok2 then bad[#bad + 1] = k[2]:sub(1, 1) .. " kaputt: " .. tostring(e2):sub(1, 60) end
            if Count(LP.db.qdb) ~= q0 or select(1, LP.Caves:Count()) ~= c0 then leak = leak + 1 end
        end
    end)
    if LP.Social and LP.Social.partners then LP.Social.partners.LPTest = nil end
    local ok = #bad == 0 and res.got and res.own and res.invalid and leak == 0
    return ok and true or false, string.format("Quest übernommen %s, eigene nur bestätigt %s, ungültig verworfen %s, kaputt ohne Eintrag %s%s",
        S(res.got), S(res.own), S(res.invalid), S(leak == 0), #bad > 0 and (" · Fehler: " .. table.concat(bad, "; ")) or ""), "alles true, kein Fehler"
end

IMPL.T61 = function()
    local Comm = LP.Comm
    local mark = ActMark()
    local snap = Comm:QueueSnapshot()
    return Guard(function()
        Comm:Queue("H\tLPTest", "PARTY")
        Comm:Broadcast({ "H\tLPTest2" }, "lptest")
        for _ = 1, 3 do if Comm.SendNext then Comm:SendNext() end end
        Comm:Hello()
        Comm:Rejoin()
        local st = Comm:Stats()
        local sends, prefixOk = 0, true
        for i = mark + 1, #LP.Act.log do
            local e = LP.Act.log[i]
            if e.name == "SendAddonMessage" then sends = sends + 1 if e.a1 ~= "LvPilot2" and e.a1 ~= "LvPilotG" then prefixOk = false end end
        end
        return type(st) == "table" and st.sent ~= nil and st.recv ~= nil and prefixOk,
            string.format("mitgeschrieben %d, Präfix %s, Stats sent/recv %s/%s", sends, prefixOk and "LvPilot2" or "falsch", S(st.sent), S(st.recv)),
            "nur mitgeschrieben, Präfix LvPilot2, Stats"
    end, function() Comm:QueueRestore(snap) end)
end

IMPL.T62 = function()
    local Comm = LP.Comm
    local mark = ActMark()
    local snap = Comm:QueueSnapshot()
    return Guard(function()
        Comm:RequestZone(1411, true)
        Comm:ReplyZone("LPTest", 1411)
        Comm:OnZoneRequest("LPTest", 1411)
        for _ = 1, 5 do if Comm.SendNext then Comm:SendNext() end end
        local n = ActSince(mark)
        return n >= 1, "mitgeschrieben " .. n, ">= 1"
    end, function() Comm:QueueRestore(snap) end)
end

IMPL.T64 = function()
    local So = LP.Social
    local mark = ActMark()
    local saved = So.partners and So.partners.LPTester
    return Guard(function()
        local list = So:ShareList()
        local step = { t = "COMPLETE", id = 999601, elite = true, q = "LPTest", key = "LPTestElite" }
        local text = So:GroupText(step)
        local line = So:OpenGroupChat(step)
        local r = {}
        WithSetting({ findPartners = true }, function()
            So:OnMessage({ "E", "1411", "12", "999601" }, "LPTester-Test")
            r.on = So.partners.LPTester ~= nil
            So:Matches()
            So.partners.LPTester = nil
            So:Announce()
        end)
        WithSetting({ findPartners = false }, function()
            So:OnMessage({ "E", "1411", "12", "999601" }, "LPTester-Test")
            r.off = So.partners.LPTester == nil
        end)
        local real = 0
        local ok = type(list) == "table" and (text == nil or text:find("^LF[GM]") ~= nil) and r.on and r.off
        return ok and true or false, string.format("Teilen %d, Text %s, Partner an %s, aus ignoriert %s", #list, S(text and text:sub(1, 3)),
            S(r.on), S(r.off)), "Liste, LFG/LFM, an erkannt, aus ignoriert"
    end, function() if So.partners then So.partners.LPTester = saved end end)
end

IMPL.T69 = function()
    local H = LP.Hints
    local up = H:UpcomingClassQuests()
    H:TrainerCost(LP:PlayerLevel() or 1)
    H:RidingTrainer()
    H:LearnTrainerCosts()
    local keys = { "hintClassQuests", "hintClass", "hintTrainer", "hintMount", "hintProfessions" }
    local bad = {}
    for _, k in ipairs(keys) do
        for _, v in ipairs({ true, false }) do
            local ok, err = pcall(WithSetting, { [k] = v }, function() LP.Advisor:Run() end)
            if not ok then bad[#bad + 1] = k .. ": " .. tostring(err):sub(1, 60) end
        end
    end
    LP.Advisor:Run()
    return type(up) == "table" and #bad == 0, #up .. " Klassenquests" .. (#bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "Liste, kein Fehler"
end

IMPL.T70 = function()
    local Pi = LP.Pins
    Pi:Refresh()
    local ok = type(Pi.areas) == "table" and type(Pi.objects) == "table" and type(Pi.avail) == "table"
    Pi:NearestObject() Pi:CheckAlert() Pi:UpdateMinimap() Pi:UpdateWorldMap()
    local bad = {}
    for _, k in ipairs({ "mapAreas", "mapAvailable", "objPins", "objArrow", "objAlert" }) do
        for _, v in ipairs({ false, true }) do
            local okc, err = pcall(WithSetting, { [k] = v }, function() Pi:Refresh() Pi:UpdateMinimap() Pi:UpdateWorldMap() Pi:CheckAlert() end)
            if not okc then bad[#bad + 1] = k .. ": " .. tostring(err):sub(1, 60) end
        end
    end
    Pi:Refresh()
    return ok and #bad == 0, string.format("Gebiete %d, Fundstellen %d, verfügbar %d", Count(Pi.areas), Count(Pi.objects), Count(Pi.avail))
        .. (#bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "Tabellen, kein Fehler"
end

IMPL.T71 = function()
    local Pl = LP.Plates
    Pl:ForUnit("target")
    Pl:UpdateAll()
    local o = Pl:OpenObjectives()
    Pl:Refresh()
    local bad = {}
    for _, k in ipairs({ "platesQuest", "platesAll" }) do
        for _, v in ipairs({ false, true }) do
            local ok, err = pcall(WithSetting, { [k] = v }, function() Pl:Refresh() Pl:UpdateAll() end)
            if not ok then bad[#bad + 1] = k .. ": " .. tostring(err):sub(1, 60) end
        end
    end
    Pl:Refresh()
    return type(o) == "table" and #bad == 0, #o .. " offene Ziele" .. (#bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "kein Fehler"
end

IMPL.T72 = function()
    local Tt = LP.Tooltips
    return WithSetting({ tooltips = true }, function()
        local u = Tt:UnitLines("player")
        -- Questgegenstand einer Quest im Log
        local item
        for qid, st in pairs(LP.Planner.inLog or {}) do
            local q = LP.QuestDB:Get(qid)
            for _, o in ipairs(q and q.obj or {}) do if o.item and not st.complete then item = o.item break end end
            if item then break end
        end
        local lines = item and Tt:ItemLines(item)
        Tt:ObjectLines("Testobjekt")
        Tt:IsProtected(6948)
        local tdp = TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and true or false
        local ok = u == nil and (item == nil or type(lines) == "table")
        return ok, string.format("Spieler %s, Questgegenstand %s, Hook über %s", S(u), item and S(lines ~= nil) or "keiner im Log",
            tdp and "TooltipDataProcessor" or "HookScript"), "nil, Zeilen"
    end)
end

IMPL.T76 = function()
    local B = LP.Backup
    local test = {
        qdb = { [999701] = { n = "LPTest1", l = 3, f = "H" }, [999702] = { n = "LPTest2", l = 4, f = "A" } },
        vendors = { ["LPTest@1411"] = { map = 1411, x = 0.5, y = 0.5, name = "LPTest", vendor = true } },
        taxi = { ["LPTestflug"] = { map = 1411, x = 0.4, y = 0.4 } },
        caves = {}, graph = { nodes = {}, edges = {} },
    }
    local savedF = {}
    for k in pairs(test) do savedF[k] = LP.db[k] end
    local okI, msg, export, ok2, msg2, ok3, sumOk
    Guard(function()
        for k, v in pairs(test) do LP.db[k] = v end
        export = B:Export()
        for _, k in ipairs({ "qdb", "vendors", "taxi", "caves" }) do LP.db[k] = {} end
        okI, msg = B:Import(export)
        sumOk = Count(LP.db.qdb) == 2 and Count(LP.db.vendors) == 1 and Count(LP.db.taxi) == 1
        ok2, msg2 = B:Import("kaputt")
        local bad = export:gsub("^(%w+):(%x)", function(f, c) return f .. ":" .. (c == "0" and "1" or "0") end)
        ok3 = B:Import(bad)
    end, function() for k, v in pairs(savedF) do LP.db[k] = v end LP.QuestDB:Invalidate() LP.QuestDB:InvalidateServices() end)
    -- SaveCopy / CheckOnLoad mit Test-Tabellen (die echten bleiben unberührt)
    local fakeDB = { qdb = { [1] = { n = "a" } }, vendors = {}, taxi = {}, caves = {}, calib = {}, graph = { nodes = {} } }
    local bigBackup = { t = 1, count = 1000000, data = {} }
    local fakeChar = { backup = bigBackup }
    WithEnv({ B.SaveCopy }, { LevelPilotDB = fakeDB, LevelPilotCharDB = fakeChar }, function() B:SaveCopy() end)
    local kept = fakeChar.backup == bigBackup
    local db2 = { qdb = {}, vendors = {}, taxi = {}, caves = {}, calib = {}, graph = { nodes = {} } }
    local char2 = { backup = { t = 1, count = 3, data = { qdb = { [1] = { n = "a" }, [2] = { n = "b" }, [3] = { n = "c" } }, vendors = {}, taxi = {} } } }
    local restoredBefore = B.restored
    WithEnv({ B.CheckOnLoad }, { LevelPilotDB = db2, LevelPilotCharDB = char2 }, function() B:CheckOnLoad() end)
    B.restored = restoredBefore
    local healed = Count(db2.qdb) == 3
    local bad = {}
    for _, fn in ipairs({ function() B:ShowExport() end, function() B:ShowImport() end, function() B:ShowText("LPTest", "LPTest", "LPTest") end,
                          function() return B:Info() end }) do
        local ok, err = pcall(fn)
        if not ok then bad[#bad + 1] = tostring(err):sub(1, 60) end
        Hide("LevelPilotBackupFrame")
    end
    local nothing = type(msg) == "string" and msg:find(L["Ergänzt: %d Quests, %d Händler, %d Flugpunkte, %d Wegstücke. Nichts wurde gelöscht."]
        :match("([^.]+)%.$") or "Nichts wurde gelöscht", 1, true) ~= nil
    local ok = okI and sumOk and nothing and ok2 == false and msg2 == L["Das ist kein LevelPilot-Sicherungstext."] and ok3 == false and kept and healed and #bad == 0
    return ok and true or false, string.format("Import %s (Anzahlen %s), kaputt %s, Prüfsumme %s, Kopie behalten %s, wiederhergestellt %s%s",
        S(okI), S(sumOk), S(ok2), S(ok3), S(kept), S(healed), #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""),
        "true (gleich), false, false, true, true"
end

IMPL.T78 = function()
    local t = L("%d Module gestartet", 3)
    local client = LP:ClientLanguage()
    local loc = GetLocale and GetLocale() or "enUS"
    local map = { deDE = "de", enUS = "en", enGB = "en", frFR = "fr", esES = "es", esMX = "mx", ptBR = "pt", itIT = "it", ruRU = "ru",
                  koKR = "ko", zhCN = "cn", zhTW = "tw" }
    LP:CanDisplay(client)
    local path = LP:FontFor(client)
    LP:FontWorks(path)
    local fixed = LP:FixText("LPTest")
    local fs = LP.UI:Text(UIParent, 11)
    LP:RegisterText(fs, "LPTest")
    LP:ApplyFont(fs, 11)
    fs:Hide()
    local ok = t:find("3", 1, true) ~= nil and (map[loc] == nil or map[loc] == client)
    return ok, "Text " .. t .. ", Client " .. S(client) .. " (" .. S(loc) .. ")", "enthält 3, Sprache passt"
end

IMPL.T80 = function()
    local skip = { ADDON_LOADED = true, PLAYER_LOGIN = true, CHAT_MSG_ADDON = true, COMBAT_LOG_EVENT_UNFILTERED = true,
                   PLAYER_LOGOUT = true }
    local args = { UNIT_QUEST_LOG_CHANGED = { "player" }, NAME_PLATE_UNIT_ADDED = { "nameplate1" }, NAME_PLATE_UNIT_REMOVED = { "nameplate1" },
                   PLAYER_ENTERING_WORLD = { false, false }, UNIT_INVENTORY_CHANGED = { "player" }, QUEST_ACCEPTED = { 0 },
                   QUEST_TURNED_IN = { 0, 0, 0 }, CHAT_MSG_LOOT = { "" }, PLAYER_XP_UPDATE = { "player" } }
    local n0 = LP.errorCount
    local onEvent = LP.eventFrame:GetScript("OnEvent")
    local evs = {}
    for ev in pairs(LP.handlers) do if not skip[ev] then evs[#evs + 1] = ev end end
    table.sort(evs)
    local mark = ActMark()
    local list = {}
    for _, ev in ipairs(evs) do
        local before = LP.errorCount
        onEvent(LP.eventFrame, ev, unpack(args[ev] or {}))
        if LP.errorCount > before then list[#list + 1] = ev end
    end
    local real = LP.Act.real
    return LP.errorCount == n0, #evs .. " Ereignisse" .. (#list > 0 and (", Fehler bei: " .. table.concat(list, ",")) or ""), "Fehlerzähler unverändert"
end

IMPL.T82 = function()
    local bad = {}
    for _, n in ipairs({ "nav", "pins" }) do
        local d = LP.drivers and LP.drivers[n]
        local fn = d and d:GetScript("OnUpdate")
        if not fn then bad[#bad + 1] = n .. ": kein Treiber"
        else
            local ok, err = pcall(fn, d, 0.1)
            if not ok then bad[#bad + 1] = n .. ": " .. tostring(err):sub(1, 60) end
        end
    end
    local map = WorldMapFrame and WorldMapFrame:IsShown()
    if map then local ok, err = pcall(LP.Pins.UpdateWorldMap, LP.Pins) if not ok then bad[#bad + 1] = "Weltkarte: " .. tostring(err) end end
    return #bad == 0, #bad == 0 and ("Navigation und Pins" .. (map and ", Weltkarte offen" or ", Weltkarte zu (Hooks nicht geprüft)")) or table.concat(bad, "; "),
        "kein Fehler"
end

------------------------------------------------------------------------
-- Virtuelle Reisen (vorab im Ablauf gestartet – Warten geht nur ausserhalb einer Prüfung, siehe TR:Journeys)
------------------------------------------------------------------------
local JOURNEY_SKIP = "virtuelle Reise nicht gelaufen (nur im Testmodus, nicht auf Level 60)"
local LONG_ONLY = "nur mit /lp testroutine reise (Reise 1–60 in beiden Modi, dauert einige Minuten)"
local function J(k) return TR.journey and TR.journey[k] end

IMPL.T83 = function()
    local r = J("short")
    if not r then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local s = r.s or {}
    local rep = tostring(r.report or "")
    local sbLine = L["Sandbox: echte Daten unverändert (OK)"]
    local ok = (s.steps or 0) > 0 and type(s.sandboxDiff) == "table" and #s.sandboxDiff == 0 and rep:find(sbLine, 1, true) ~= nil
        and r.after.char and not r.after.taxiMeta and r.after.quests
    return ok and true or false, string.format("%d Schritte, Sandbox %s, danach LP.char echt %s, Flugpunkte ohne Überlagerung %s, API.Quests Original %s",
        s.steps or 0, (type(s.sandboxDiff) == "table" and #s.sandboxDiff == 0) and "OK" or "FEHLER", S(r.after.char), S(not r.after.taxiMeta),
        S(r.after.quests)), "Schritte > 0, alles zurück"
end

IMPL.T35 = function()
    local w = J("window")
    if not w then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local ok = w.pause == L["Weiter"] and w.resume == L["Pause"] and w.watch == L["Schnell"] and w.fast == L["Zuschauen"]
        and w.afterStop and w.report
    return ok and true or false, string.format("Pause→%s→%s, Zuschauen→%s→%s, nach Stopp nur Bericht/Schliessen %s, Bericht %s",
        S(w.pause), S(w.resume), S(w.watch), S(w.fast), S(w.afterStop), S(w.report)), "Beschriftungen wechseln, danach nur Bericht"
end

IMPL.T85 = function()
    local a = J("abort")
    if not a then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local ok = a.realChar and a.realTaxi and a.restored
    return ok and true or false, string.format("während: echter Charakter %s, Flugpunkte ohne Überlagerung %s · nach Abbruch zurück %s%s",
        S(a.realChar), S(a.realTaxi), S(a.restored), a.left and (" (umgeleitet: " .. a.left .. ")") or ""), "true, true, true"
end

IMPL.T155 = function()
    local r = J("short")
    if not r then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local s = r.s or {}
    local per = (s.planMs or 0) / math.max(1, s.planN or 1)
    return per < 16, string.format("%.2f ms je Planung (%d)", per, s.planN or 0), "< 16 ms"
end

IMPL.T174 = function()
    local r = J("speed")
    if not r then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local s = r.s or {}
    -- ohne Erholt-Bonus (der verdoppelt Monster-EP und gehört nicht zur Rechnung mit dem Monsterlevel)
    local k, xp = s.wayKills or 0, (s.wayXP or 0) - (s.wayBonus or 0)
    local L0 = s.startLevel or (UnitLevel("player") or 1)
    local Lmax = s.level or (L0 + 2)
    local cap = LP.Planner:KillXP(Lmax, Lmax)
    if k == 0 then return false, string.format("keine Weg-Kills im Speedrun (Level %d–%d)", L0, Lmax), "Weg-Kills > 0" end
    local per = xp / k
    return per <= cap, string.format("%d Weg-Kills (Level %d–%d), %.1f EP je Kill ohne Erholt-Bonus (Grenze %.1f)", k, L0, Lmax, per, cap),
        "EP je Kill <= KillXP(Level, Level)"
end

IMPL.T181 = function()
    local r = J("short")
    if not r then return true, TR.journey and TR.journey.why or JOURNEY_SKIP end
    local head = L("Werte: Kills/Min %s · EP je Kill %s · Dungeon-Faktoren %s", "\1", "\1", "\1"):match("^([^\1]*)")
    local found = tostring(LP.Virtual.lastReport or r.report or ""):find(head, 1, true) ~= nil
    return found, "Zeile \"" .. head .. "…\" " .. (found and "vorhanden" or "fehlt"), "vorhanden"
end

local function LongCheck()
    local l = J("long")
    if not l then return false, TR.journey and TR.journey.longWhy or "lange Reise nicht beendet", "Normal und Speedrun" end
    local hn, hs = (l.normal or 0) / 3600, (l.speed or 0) / 3600
    local ok = hs < hn and hn >= 50 and hn <= 400 and hs >= 50 and hs <= 400 and l.mode == l.modeBefore and l.text ~= nil
    return ok, tostring(l.text) .. string.format(" (Modus danach %s)", S(l.mode)), "Speedrun < Normal, beide 50–400 h, Modus unverändert"
end
IMPL.T84, IMPL.T180, IMPL.T183 = LongCheck, LongCheck, LongCheck
TR.LONG = { T84 = true, T180 = true, T183 = true }

-- Reisen nacheinander laufen lassen (im Ablauf, ausserhalb jeder Prüfung). wait(cond, sek) gibt die Kontrolle ab.
function TR:Journeys(wait, long)
    local V = LP.Virtual
    self.journey = {}
    if not V or not LP:IsDev() then self.journey.why = JOURNEY_SKIP return end
    local L0 = UnitLevel("player") or 1
    if V.active then self.journey.why = "virtuelle Reise lief schon" return end
    local API, Geo = LP.API, LP.Geo
    local orig = { Quests = API.Quests, Objectives = API.Objectives, IsQuestDone = API.IsQuestDone, GeoPlayer = Geo.Player,
                   HearthReady = API.HearthReady }
    local function run(opts, during)
        local res = {}
        opts.silent = true
        opts.onDone = function(rep, s) res.report, res.s, res.done = rep, s, true end
        V:Start(opts.where or "here", opts)
        if not V.active then return nil end
        if during then pcall(during, res) end
        wait(function() return res.done or not V.active end, opts.maxSec or 240)
        if V.active then V:Stop() end
        wait(function() return res.done end, 3)
        -- nur die geprüften Werte behalten (Speicher, T157)
        local s = res.s or {}
        res.s = { steps = s.steps, sandboxDiff = s.sandboxDiff, planMs = s.planMs, planN = s.planN, wayKills = s.wayKills,
                  wayXP = s.wayXP, wayBonus = s.wayBonus, startLevel = s.startLevel, level = s.level }
        res.report = res.report and tostring(res.report):sub(1, 4000)
        res.after = { char = LP.char == LevelPilotCharDB,
                      taxiMeta = type(LevelPilotDB.taxi) == "table" and getmetatable(LevelPilotDB.taxi) ~= nil,
                      quests = API.Quests == orig.Quests }
        return res
    end
    if L0 < 60 and not self.abort then
        -- T83/T155/T181: kurze Reise über den Ticker
        self.journey.short = run({ maxLevel = math.min(60, L0 + 2) })
        -- T174: dasselbe im Speedrun
        -- unter Level 10 etwas länger: am Anfang bringen Wege selten Monster, die sich lohnen
        if not self.abort then self.journey.speed = run({ maxLevel = math.min(60, L0 + (L0 < 10 and 5 or 2)), mode = "speed" }) end
    else
        self.journey.why = L0 >= 60 and "Level 60 – keine Reise ab hier" or self.abort
    end
    -- T35: Fenster der Reise (Knöpfe; Zuschauen öffnet keine Weltkarte)
    if not self.abort and L0 < 60 then
        local w = {}
        local res = run({ maxLevel = math.min(60, L0 + 1), maxSec = 1 }, function()
            V:ShowWindow()
            local win = V.Window and V.Window()
            if not win then return end
            local click = function(b)
                local fn = b:GetScript("OnClick")
                if fn then WithEnv({ fn }, { ToggleWorldMap = false }, function() fn(b, "LeftButton") end) end
            end
            click(win.bPause) w.pause = win.bPause.label:GetText()
            click(win.bPause) w.resume = win.bPause.label:GetText()
            click(win.bWatch) w.watch = win.bWatch.label:GetText()
            click(win.bWatch) w.fast = win.bWatch.label:GetText()
            click(win.bStop)
            w.afterStop = not win.bPause:IsShown() and not win.bWatch:IsShown() and not win.bStop:IsShown()
            local rb = win.bReport
            if rb then click(rb) end
            w.report = _G.LevelPilotBackupFrame and _G.LevelPilotBackupFrame:IsShown() or false
            Hide("LevelPilotBackupFrame")
            win:Hide()
        end)
        if res then self.journey.window = w end
    end
    -- T85: Abbruch mitten in der Reise
    if not self.abort and L0 < 60 then
        local a = {}
        V:Start("here", { silent = true, maxLevel = math.min(60, L0 + 2) })
        if V.active then
            wait(function() return false end, 1)
            a.realChar = V:RealChar() == LevelPilotCharDB
            a.realTaxi = getmetatable(V:RealTaxi() or {}) == nil
            V:Abort()
            local left = {}
            if API.Quests ~= orig.Quests then left[#left + 1] = "API.Quests" end
            if API.Objectives ~= orig.Objectives then left[#left + 1] = "API.Objectives" end
            if API.IsQuestDone ~= orig.IsQuestDone then left[#left + 1] = "API.IsQuestDone" end
            if Geo.Player ~= orig.GeoPlayer then left[#left + 1] = "Geo.Player" end
            if API.HearthReady ~= orig.HearthReady then left[#left + 1] = "API.HearthReady" end
            a.restored = #left == 0 and LP.char == LevelPilotCharDB
            a.left = #left > 0 and table.concat(left, ", ") or nil
            self.journey.abort = a
        end
    end
    -- T84/T180/T183: 1–60 in beiden Modi (nur "/lp testroutine reise")
    if long and not self.abort then
        local l = { modeBefore = LP.char.mode }
        local started = V:CompareModes(function(n, s, text) l.normal, l.speed, l.text = n, s, text end, 60)
        if started then
            wait(function() return l.text ~= nil end, 3600)
            if V.active then V:Stop() end
        end
        l.mode = LP.char.mode
        if l.text then self.journey.long = l else self.journey.longWhy = "lange Reise nicht beendet" end
    end
end

------------------------------------------------------------------------
-- E. Daten (3.12.6)
------------------------------------------------------------------------
IMPL.T127 = function()
    local V = LP.Virtual
    local real = { ["LPTestflug"] = { map = 1411 } }
    local overlay = V.MakeOverlay(real)
    overlay.LPTestVirtuell = { map = 1 }
    local isReal = V.RealTaxiOf(overlay) == real
    -- SaveCopy speichert die echte Liste (Test-Tabellen, die echten bleiben unberührt)
    local fakeDB = { qdb = { [1] = { n = "a" } }, vendors = {}, taxi = overlay, caves = {}, calib = {}, graph = { nodes = {} } }
    local fakeChar = {}
    WithEnv({ LP.Backup.SaveCopy }, { LevelPilotDB = fakeDB, LevelPilotCharDB = fakeChar }, function() LP.Backup:SaveCopy() end)
    local savedReal = fakeDB.taxi == real
    local copy = fakeChar.backup and fakeChar.backup.data and fakeChar.backup.data.taxi
    local copyReal = type(copy) == "table" and copy.LPTestflug ~= nil and copy.LPTestVirtuell == nil
    return isReal and savedReal and copyReal, string.format("RealTaxiOf echt %s, Konto echt %s, Kopie ohne Reise-Einträge %s",
        S(isReal), S(savedReal), S(copyReal)), "true, true, true"
end

-- Beispiel-DB im Stand vor 3.8/3.10
local OLD_DB = function()
    return {
        qdb = { [999801] = { n = "Alt", l = 5, f = "H", s = { 1, 100, 100 } } },
        speedLevel = 3, calib = { kills = {} },
        protocolLog = { entries = { { k = "zone", msg = "… Das Brachland (1413), Brachland" }, { k = "session", msg = "L1 L5 3" } } },
    }, { mode = "normal" }
end

IMPL.T128 = function()
    local acc, char = OLD_DB()
    return WithLoad(acc, char, function()
        local bad = {}
        for _, fn in ipairs({ function() LP.Planner:Replan(true) end, function() LP.Calib:KillXPText() end,
                              function() LP.Protocol:LoadEntries() end, function() LP.Virtual:Report() end }) do
            local ok, err = pcall(fn)
            if not ok then bad[#bad + 1] = tostring(err):sub(1, 80) end
        end
        local filled = acc.speedLevelV2 == true and type(char.levelTimes) == "table" and type(char.fpVisited) == "table"
        local measured = LP.Calib:KillXPMeasured()
        return #bad == 0 and filled and measured == false, string.format("ergänzt %s, gemessen %s%s", S(filled), S(measured),
            #bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "ergänzt, false, kein Fehler"
    end)
end

IMPL.T129 = function()
    local acc = {
        qdb = { [123] = "kaputt", [124] = { n = 5, l = "x" } }, graph = 5, taxi = "x", vendors = { [1] = false }, caves = { 1 },
        calib = { killxp = { [-3] = { n = "a" } } }, protocolLog = { entries = { { k = nil, msg = 5 } } }, net = { peers = 7 },
    }
    local char = { ignored = "x", levelTimes = { [5] = "x" }, bind = 3 }
    return WithLoad(acc, char, function()
        local bad = {}
        local calls = {
            { "QuestDB:Counts", function() LP.QuestDB:Counts() LP.QuestDB:Get(123) LP.QuestDB:Get(124) end },
            { "Planner:Replan", function() LP.Planner:Replan(true) end },
            { "Center", function() WithCenter(function() LP.Center:Select("data") LP.Center:Select("route") end) end },
            { "Backup", function() LP.Backup:Count(acc) LP.Backup:Export() end },
            { "Protocol", function() LP.Protocol:LoadEntries() end },
            { "Calib", function() LP.Calib:KillXPRatio(-3) LP.Calib:KillXPText() end },
            { "Comm", function() LP.Comm:EncodeQuest(123) LP.Comm:EncodeQuest(124) end },
            { "Virtual", function() LP.Virtual:Fingerprint() end },
            { "Comfort", function() LP.Comfort:LevelTimesText() end },
        }
        for _, c in ipairs(calls) do
            local ok, err = pcall(c[2])
            if not ok then bad[#bad + 1] = c[1] .. ": " .. tostring(err):sub(1, 70) end
        end
        -- SaveCopy mit denselben Tabellen (ohne die echten zu berühren)
        local okS, errS = pcall(WithEnv, { LP.Backup.SaveCopy }, { LevelPilotDB = acc, LevelPilotCharDB = char }, function() LP.Backup:SaveCopy() end)
        if not okS then bad[#bad + 1] = "SaveCopy: " .. tostring(errS):sub(1, 70) end
        return #bad == 0, #bad == 0 and "alle Aufrufe ohne Fehler" or table.concat(bad, "; "), "kein Lua-Fehler"
    end)
end

IMPL.T130 = function()
    local Q = LP.QuestDB
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return true, "kein Datenpaket installiert" end
    local CP = Q.ConnectPack
    if not CP then return false, "QuestDB.ConnectPack fehlt", "zugänglich" end
    local scheduled
    local function conn(data)
        return WithEnv({ CP }, { _G = { LevelPilotData = data }, C_Timer = { After = function(_, fn) scheduled = fn end } },
            function() return CP() end)
    end
    local r = {}
    return Guard(function()
        WithSetting({ usePack = true }, function()
            local ok1, i1 = conn(nil)
            r.miss = ok1 == false and i1 == L["nicht installiert"]
            local ok2, i2 = conn(setmetatable({ format = 2 }, { __index = d }))
            r.fmt = ok2 == false and i2 == L["unbekanntes Format "] .. "2"
            local warned = Q.packWarned
            Q.packWarned = false
            scheduled = nil
            local ok3 = conn(setmetatable({ version = "1.5.0" }, { __index = d }))
            r.old = ok3 == true and scheduled ~= nil
            scheduled = nil
            conn(setmetatable({ version = "1.5.0" }, { __index = d }))
            r.once = scheduled == nil
            Q.packWarned = warned
        end)
        -- Kurztest-Prüfung (T04) ohne Paket
        _G.LevelPilotData = nil
        local _, b = Guard(function() return IMPL.T04() end, function() _G.LevelPilotData = d end)
        r.short = b == "Datenpaket LevelPilot_Data fehlt"
        Q:Reconnect()
        r.back = Q.pack == true
        local ok = r.miss and r.fmt and r.old and r.once and r.short and r.back
        return ok and true or false, string.format("fehlt %s, Kurztest %s, Format 2 %s, 1.5.0 läuft mit einem Hinweis %s/%s, danach Paket %s",
            S(r.miss), S(r.short), S(r.fmt), S(r.old), S(r.once), S(r.back)), "alles true"
    end, function() _G.LevelPilotData = d pcall(Q.Reconnect, Q) end)
end
IMPL.T203 = function()
    local Q = LP.QuestDB
    return Q.OlderThan("1.5.0", Q.MIN_PACK) == true and Q.OlderThan("1.6.0", Q.MIN_PACK) == false,
        "Mindestversion " .. S(Q.MIN_PACK), "1.5.0 zu alt, 1.6.0 ok"
end

IMPL.T131 = function()
    local Q = LP.QuestDB
    local CQ = Q.ConnectQuestie
    if not CQ then return false, "QuestDB.ConnectQuestie fehlt", "zugänglich" end
    -- Ersatz nur in der Umgebung der Funktion: ein echtes Questie bleibt unberührt
    local function conn(lib) return WithEnv({ CQ }, { _G = { LibQuestieDB = lib } }, function() return CQ() end) end
    return Guard(function()
        return WithSetting({ useQuestie = true }, function()
            local ok1, i1 = conn({ RequireContract = function() return false, "LPTest" end })
            local ok2, i2 = conn({ RequireContract = function() return true end })
            local a = ok1 == false and tostring(i1):sub(1, #L["Version zu alt ("]) == L["Version zu alt ("]
            local b = ok2 == false and i2 == L["Schnittstelle unvollständig"]
            return a and b, "alt: " .. tostring(i1) .. " · ohne Tabelle: " .. tostring(i2) ..
                (_G.LibQuestieDB and " · echtes Questie geladen (nicht ersetzt)" or ""), "Version zu alt (…) · Schnittstelle unvollständig"
        end)
    end, function() pcall(Q.Reconnect, Q) end)
end

------------------------------------------------------------------------
-- F. Sprachen (3.12.6)
------------------------------------------------------------------------
local function CutLabels()
    local bad = {}
    for b in pairs(LP.UI.buttons or {}) do
        local fs = b.label
        if fs and b:IsShown() and fs.GetStringWidth and b.GetWidth then
            local tw, bw = fs:GetStringWidth() or 0, b:GetWidth() or 0
            if bw > 0 and tw > bw - 2 then bad[#bad + 1] = tostring(fs:GetText()) end
        end
    end
    return bad
end

IMPL.T136 = function()
    local before = LP.db.language
    local bad = {}
    local n = 0
    return Guard(function()
        for _, l in ipairs(LP.LANGUAGES) do
            if LP:CanDisplay(l.code) then
                n = n + 1
                local ok, err = pcall(function()
                    LP:SetLanguage(l.code)
                    if LP:Language() ~= l.code then error("Sprache " .. LP:Language(), 0) end
                    if not LP.UI:IsShown() then LP.UI:Toggle() LP.UI:Toggle() end
                    LP.UI:Refresh()
                    WithCenter(function() end)
                    LP.Backup:ShowText("LPTest", "LPTest", "LPTest") Hide("LevelPilotBackupFrame")
                    LP.Protocol:Show() Hide("LevelPilotBackupFrame")
                    if LP:IsDev() and LP.Virtual.ShowWindow then LP.Virtual:ShowWindow() Hide("LevelPilotVirtualFrame") end
                    local cut = CutLabels()
                    if #cut > 0 then error("abgeschnitten: " .. table.concat(cut, ", "):sub(1, 80), 0) end
                end)
                if not ok then bad[#bad + 1] = l.code .. ": " .. tostring(err) end
            end
        end
        return #bad == 0, n .. " Sprachen" .. (#bad > 0 and (" · " .. table.concat(bad, "; ")) or ""), "kein Fehler, nichts abgeschnitten"
    end, function()
        LP.db.language = before
        LP:ResetLanguageCache()
        pcall(LP.SetLanguage, LP, before)
        LP.db.language = before
    end)
end

IMPL.T138 = function()
    local st = LP.Names:StatusText()
    local ok = type(st) == "string" and (st:find("ok", 1, true) or st:find(L["geladen"], 1, true)
        or st == L["nicht nötig (Englisch)"]) ~= nil
    local en = LP.Names.LOCALE_OF and LP.Names.LOCALE_OF.en
    local it = LP.Names.LOCALE_OF and LP.Names.LOCALE_OF.it
    local same = en == nil or en == it
    return ok and same, st:sub(1, 80) .. (en and (" · en/it: " .. S(en) .. "/" .. S(it)) or ""), "ok/geladen, en und it englisch"
end

------------------------------------------------------------------------
-- G. Zusammenspiel (3.12.6)
------------------------------------------------------------------------
IMPL.T142 = function()
    if not geterrorhandler then return true, "kein Fehler-Handler" end
    local h = geterrorhandler()
    local msg = "Interface/AddOns/LevelPilot/Test.lua:1: LP-Testfehler Handlerkette"
    local gt0, pr0 = GTErrors("LP-Testfehler Handlerkette"), LP.Protocol:Count()
    pcall(h, msg)
    local gt1 = GTErrors("LP-Testfehler Handlerkette", true)
    local pr = DropProtocol("LP-Testfehler Handlerkette")
    local bug = _G.BugGrabber and "BugGrabber geladen (bekommt die Meldung weiter)" or "ohne BugGrabber (Teil übersprungen)"
    local ok = gt1 > gt0 and pr >= 1
    return ok, string.format("GoldSentinelTest %d, Protokoll %d · %s", gt1 - gt0, pr, bug), "beide >= 1"
end

IMPL.T144 = function()
    local Q = LP.QuestDB
    local r = {}
    if _G.LibQuestieDB or _G.QuestieLoader then
        WithSetting({ usePack = false, useQuestie = true }, function()
            Q:Reconnect()
            local c = Q:Counts()
            r.with = Q.questie == true and (c.questie or 0) > 0
        end)
        Q:Reconnect()
        return r.with and true or false, "mit Questie: aktiv " .. S(r.with), "aktiv, Quests > 0"
    end
    WithSetting({ usePack = false, useQuestie = true }, function()
        Q:Reconnect()
        r.info = tostring(Q.questieInfo or "")
    end)
    Q:Reconnect()
    local ok = r.info:find(L["nicht installiert"], 1, true) ~= nil
    return ok, "ohne Questie: " .. r.info:sub(1, 60) .. " (Teil mit Questie übersprungen)", "nicht installiert"
end

------------------------------------------------------------------------
-- H. Leistung (3.12.6)
------------------------------------------------------------------------
IMPL.T148 = function()
    local d = LP.drivers and LP.drivers.nav
    local fn = d and d:GetScript("OnUpdate")
    if not fn then return false, "Navigations-Treiber fehlt", "vorhanden" end
    local med, max = Bench(function() fn(d, 0.05) end)
    local t0 = Ms()
    LP.Nav:Recalc(true)
    local full = Ms() - t0
    return med < 2 and full < 16, string.format("Median %.2f ms, Höchstwert %.2f ms, Recalc(true) %.2f ms", med, max, full), "Median < 2 ms, Recalc < 16 ms"
end

IMPL.T149 = function()
    local d = LP.drivers and LP.drivers.pins
    local fn = d and d:GetScript("OnUpdate")
    if not fn then return false, "Pins-Treiber fehlt", "vorhanden" end
    local med, max = Bench(function() fn(d, 0.05) end)
    local wm = Bench(function() LP.Pins:UpdateWorldMap() end, 5)
    return med < 2 and wm < 16, string.format("OnUpdate Median %.2f ms (max %.2f), Weltkarte %.2f ms", med, max, wm), "< 2 ms, < 16 ms"
end

IMPL.T151 = function()
    local Geo = LP.Geo
    local i1, n1, w1 = Geo:ToWorld(1454, 0.45, 0.55)
    local i2, n2, w2 = Geo:ToWorld(1413, 0.52, 0.30)
    if not (i1 and i2) then return false, "Koordinaten fehlen", "Orgrimmar und Wegkreuz" end
    local med, max = Bench(function() LP.Graph:Path(i1, n1, w1, 1454, i2, n2, w2, 1413) end, 5)
    return med < 16, string.format("Median %.2f ms, Höchstwert %.2f ms", med, max), "< 16 ms"
end

-- Drosselung abseits des Weges (Nav.recalcCount)
local function OffPathThrottle()
    local N, Geo = LP.Nav, LP.Geo
    N:Recalc(true)
    local path = N:PathInfo()
    if not path or not path[1] or not path[2] then return true, "kein Weg (Schritt ohne Ort) – Drosselung nicht messbar" end
    local a, b = path[1], path[2]
    local dn, dw = b[2] - a[2], b[3] - a[3]
    local len = math.sqrt(dn * dn + dw * dw)
    if len < 1 then dn, dw, len = 1, 0, 1 end
    local pn, pw = b[2] - dw / len * 100, b[3] + dn / len * 100      -- 100 Yards seitlich
    local origPlayer = Geo.Player
    local t = GetTime() + 10
    local onTaxi = false
    local fake = { GetTime = function() return t end, UnitOnTaxi = function() return onTaxi end }
    return Guard(function()
        local inst = a[1]
        Geo.Player = function() return inst, pn, pw, a[4] end
        local c0 = N.recalcCount or 0
        WithEnv({ N.Recalc }, fake, function()
            for _ = 1, 20 do t = t + 0.05 N:Recalc(false) end
        end)
        local n1 = (N.recalcCount or 0) - c0
        -- auf dem Flug nie
        onTaxi = true
        pn, pw = pn + 150, pw + 150
        t = t + 5
        local c1 = N.recalcCount or 0
        WithEnv({ N.Recalc }, fake, function()
            for _ = 1, 20 do t = t + 0.05 N:Recalc(false) end
        end)
        local n2 = (N.recalcCount or 0) - c1
        return n1 <= 2 and n2 == 0, string.format("vom Weg ab: %d Neuberechnungen in 1 s, auf dem Flug %d", n1, n2), "<= 2, 0"
    end, function() Geo.Player = origPlayer pcall(N.Recalc, N, true) end)
end
IMPL.T152 = OffPathThrottle
IMPL.T197 = OffPathThrottle

IMPL.T153 = function()
    local h = HandlerList("NAME_PLATE_UNIT_ADDED")
    local a = Bench(function() for _, fn in ipairs(h) do fn("NAME_PLATE_UNIT_ADDED", "nameplate1") end end)
    local b = Bench(function() LP.Tooltips:UnitLines("target") end)
    local c = Bench(function() LP.Calib:ObserveUnit("target") end)
    return a < 1 and b < 1 and c < 0.5, string.format("Plakette %.3f ms, Tooltip %.3f ms, Beobachtung %.3f ms", a, b, c), "< 1, < 1, < 0.5 ms"
end

IMPL.T154 = function()
    local Comm = LP.Comm
    local msg = "Q\t299901\t12\tH\t\t\tLPTestquest\t0"
    local snap = Comm:QueueSnapshot()
    local a, b
    WithQdb({}, function()
        a = Bench(function() Comm:Receive(msg, "LPTest-Realm") end)
    end)
    return Guard(function()
        b = Bench(function() Comm:SendNext() end)
        return a < 1 and b < 0.5, string.format("Empfang %.3f ms, Senden %.3f ms", a, b), "< 1 ms, < 0.5 ms"
    end, function() Comm:QueueRestore(snap) end)
end

IMPL.T156 = function()
    local names = { ui = true, caves = true, recorder = true, session = true }
    local fns = {}
    for _, t in ipairs(LP.tickers or {}) do if names[t.name] then fns[#fns + 1] = t.fn end end
    if #fns == 0 then return false, "Ticker nicht gefunden", "ui, caves, recorder, session" end
    local med, max = Bench(function() for _, fn in ipairs(fns) do fn() end end)
    return med < 3, string.format("%d Ticker, Summe Median %.2f ms, Höchstwert %.2f ms", #fns, med, max), "Summe < 3 ms"
end

------------------------------------------------------------------------
-- I. Fehlerzählung (3.12.6)
------------------------------------------------------------------------
IMPL.T159 = function()
    if not geterrorhandler then return true, "kein Fehler-Handler" end
    local msg = "Interface/AddOns/LevelPilot/Test.lua:1: LP-Testfehler"
    local gt0 = GTErrors("LP-Testfehler")
    pcall(geterrorhandler(), msg)
    local gt = GTErrors("LP-Testfehler", true) - gt0
    local pr = DropProtocol("LP-Testfehler")
    return gt >= 1 and pr >= 1, string.format("GoldSentinelTest %d, Protokoll %d", gt, pr), "beide >= 1"
end

IMPL.T162 = function()
    LP.initErrors = LP.initErrors or {}
    LP.initErrors.LPTestModul = "LP-Testfehler Start"
    return Guard(function()
        local a = IMPL.T01()
        local diag = table.concat(LP.Planner:DiagLines(), "\n")
        local b = diag:find("LPTestModul", 1, true) ~= nil
        return a == false and b, "T01 meldet FEHLER " .. S(a == false) .. ", Diagnose zeigt ihn " .. S(b), "true, true"
    end, function() LP.initErrors.LPTestModul = nil end)
end

IMPL.T164 = function()
    local V = LP.Virtual
    if not V.Note then return false, "Virtual.Note fehlt", "zugänglich" end
    if V.active then return true, "Reise läuft – nicht geprüft" end
    local savedS = V.s
    V.s = { problems = {}, seen = {}, level = 1, protoErrors = 0 }
    local gt0 = GTErrors("Reise")
    local pr0 = LP.Protocol:Count(true)
    return Guard(function()
        for i = 1, 6 do V.Note("error", "LP-Testfehler Reise " .. i) end
        local gt = GTErrors("Reise", true) - gt0
        local pr = DropProtocol("LP-Testfehler Reise")
        local tracking = LP.trackingErrors
        local ok = pr == 5 and (gt == 5 or not tracking)
        return ok, string.format("Protokoll %d, GoldSentinelTest %d (je Reise höchstens 5)", pr, gt), "5, 5"
    end, function() V.s = savedS end)
end

------------------------------------------------------------------------
-- J. 3.12.7: Route in Mulgore (Befund aus dem Spiel) und CheckNav
------------------------------------------------------------------------
-- Schritt an einem Kartenpunkt (Mulgore 1412, Koordinaten von WoW Forever)
local function MulgoreStep(t, id, x, y, key)
    local i, n, w = LP.Geo:ToWorld(1412, x, y)
    return { t = t, id = id, map = 1412, x = x, y = y, inst = i, n = n, w = w, key = key or (t .. ":" .. tostring(id)) }
end

IMPL.T214 = function()
    local P = LP.Planner
    local fake = { inLog = { [780] = { complete = true }, [757] = { complete = true }, [3376] = { complete = true },
                             [761] = { complete = true }, [756] = { complete = true }, [772] = { complete = false } } }
    -- Fall 1: Spieler Red Cloud Mesa 54.1/83.9, drei Abgaben in Camp Narache, weites Ziel bei 62/58
    local pi, pn, pw = LP.Geo:ToWorld(1412, 54.1, 83.9)
    if not pi then return true, "Mulgore-Karte nicht verfügbar" end
    local steps1 = { MulgoreStep("FP", nil, 62, 58, "FP:LPTest"), MulgoreStep("ACCEPT", 753, 48.8, 80.9),
                     MulgoreStep("TURNIN", 3376, 44.2, 77.0), MulgoreStep("TURNIN", 780, 44.5, 77.5),
                     MulgoreStep("TURNIN", 757, 43.9, 76.7) }
    P.NearTurninsFirst(fake, steps1, pi, pn, pw)
    local f1 = steps1[1].t == "TURNIN" and steps1[2].t == "TURNIN" and steps1[3].t == "TURNIN" and steps1[4].key == "FP:LPTest"
    -- Fall 2: Spieler 39.3/46.2, zwei Abgaben in Bloodhoof (südöstlich), offene Quest und weites Ziel im Nordwesten
    local qi, qn, qw = LP.Geo:ToWorld(1412, 39.3, 46.2)
    local steps2 = { MulgoreStep("COMPLETE", 745, 30, 32), MulgoreStep("COMPLETE", 772, 46.5, 61.0),
                     MulgoreStep("TURNIN", 761, 47.6, 60.6), MulgoreStep("TURNIN", 756, 46.7, 60.2) }
    P.NearTurninsFirst(fake, steps2, qi, qn, qw)
    local f2 = steps2[1].t == "TURNIN" and steps2[2].t == "TURNIN" and steps2[3].id == 745
    -- weit entfernte Abgabe (> NEAR_TURNIN) bleibt, wo die Planung sie hingestellt hat
    local steps3 = { MulgoreStep("ACCEPT", 753, 48.8, 80.9), MulgoreStep("TURNIN", 761, 20, 15) }
    P.NearTurninsFirst(fake, steps3, pi, pn, pw)
    local f3 = steps3[1].t == "ACCEPT"
    return f1 and f2 and f3, string.format("Fall 1 Abgaben vorn %s, Fall 2 Abgaben vorn %s, weite Abgabe unverändert %s (Nähe %d Yards)",
        S(f1), S(f2), S(f3), P.NEAR_TURNIN), "true, true, true"
end

-- unbekannte Zelle (kein begehbarer Boden in der Umgebung) auf einer Karte suchen
local function UnknownSpot(map, block)
    local Tr = LP.Terrain
    for y = 5, 95, 2 do
        for x = 5, 95, 2 do
            local all = true
            for dy = -(block or 0), block or 0 do
                for dx = -(block or 0), block or 0 do
                    if Tr:Walkable(map, x + dx, y + dy) ~= false then all = false break end
                end
                if not all then break end
            end
            if all then return x, y end
        end
    end
    return nil
end

IMPL.T215 = function()
    local Q, Tr = LP.QuestDB, LP.Terrain
    -- a) aufgezeichnete Abgabe weit neben dem Datenpaket wird nicht bevorzugt, eine passende schon
    local function base() return { ends = { { 1412, 46.2, 63.3, "Kauth" } }, starts = {}, objectives = {} } end
    local far = Q.Merge(base(), { starts = {}, ends = { { 1412, 62, 58 } }, objectives = {} })
    local near = Q.Merge(base(), { starts = {}, ends = { { 1412, 46.4, 63.0 } }, objectives = {} })
    local a = far.ends[1][2] == 46.2 and near.ends[1][2] == 46.4
    if Tr:Walkable(1412, 46.2, 63.3) == nil then
        return a, "Merge " .. S(a) .. " · ohne Geländekarte (kein Datenpaket): Gebirgsprüfung nicht möglich", "Merge true"
    end
    -- b) Händler/Gastwirt im Gebirge (Aufzeichnung ohne begehbaren Boden) wird nicht angeboten
    local x, y = UnknownSpot(1412, 1)
    local key = "LPTestGebirge@1412"
    local saved = LP.db.vendors[key]
    local b, c = false, false
    Guard(function()
        if x then
            LP.db.vendors[key] = { map = 1412, x = x, y = y, name = "LPTestGebirge", inn = true, vendor = true }
            Q:InvalidateServices()
            b = true
            for _, v in ipairs(Q:ServiceNPCs().inn or {}) do if v.name == "LPTestGebirge" then b = false end end
        end
    end, function() LP.db.vendors[key] = saved Q:InvalidateServices() end)
    -- c) Luftlinie quer über unbekanntes Gelände: keine Linie (nur Pfeil)
    local bx, by = UnknownSpot(1412, 4)
    if bx then
        local i1, n1, w1 = LP.Geo:ToWorld(1412, bx - 4, by - 4)
        local i2, n2, w2 = LP.Geo:ToWorld(1412, bx + 4, by + 4)
        c = LP.Nav.Blocked({ { i1, n1, w1, 1412 }, { i2, n2, w2, 1412 } }) == true
    end
    local walk = Tr:Walkable(1412, 46.2, 63.3) == true            -- Bloodhoof (Datenpaket): begehbar
    local ok = a and walk and (b or not x) and (c or not bx)
    return ok, string.format("Merge %s, Bloodhoof begehbar %s, Gastwirt im Gebirge ausgeblendet %s, Linie über Gebirge unterdrückt %s",
        S(a), S(walk), x and S(b) or "keine Gebirgszelle", bx and S(c) or "kein grosses Gebirge"), "alles true"
end

IMPL.T216 = function()
    local Pr, N = LP.Protocol, LP.Nav
    local pi, pn, pw = LP.Geo:Player()
    if not pi then return true, "keine Position" end
    local bm, bs = "LPTestKoeder Bewegung", "LPTestKoeder Tempo"
    local savedT = N.target
    N.target = { key = "LPTestNav", inst = pi, n = pn + 500, w = pw, label = "LPTest" }
    return Guard(function()
        return WithSecret({ bm, bs }, function()
            return WithEnv({ Pr.CheckNav }, { IsPlayerMoving = function() return bm end, GetUnitSpeed = function() return bs end,
                UnitAffectingCombat = function() return false end }, function()
                local ok, err = pcall(Pr.CheckNav, Pr)
                return ok, ok and "kein Fehler, Vergleich übersprungen" or tostring(err), "kein Lua-Fehler"
            end)
        end)
    end, function() N.target = savedT end)
end

IMPL.T217 = function()
    local P, Pr, Geo = LP.Planner, LP.Protocol, LP.Geo
    local pi, pn, pw = Geo:ToWorld(1456, 45, 55)
    if not pi then return true, "Karte Thunder Bluff nicht verfügbar" end
    -- 3 Aufgaben in Thunder Bluff, 6 in Mulgore
    local tasks = {}
    for k = 1, 3 do local t = MulgoreStep("ACCEPT", 299700 + k, 50, 50) t.map = 1456 t.inst, t.n, t.w = Geo:ToWorld(1456, 40 + k * 4, 50) t.value = 1 tasks[#tasks + 1] = t end
    for k = 1, 6 do local t = MulgoreStep("COMPLETE", 299710 + k, 40 + k, 60) t.value = 1 tasks[#tasks + 1] = t end
    local savedFocus, savedZone, savedTasks = P.focus, LP.char.focusZone, P.lastTasks
    local savedPlayer = Geo.Player
    return Guard(function()
        LP.char.focusZone = nil
        P.focus = nil
        local f1 = P:ChooseFocus(tasks, pi, pn, pw, 1456, {})
        P.focus = 1412
        local f2 = P:ChooseFocus(tasks, pi, pn, pw, 1456, {})
        local same = P.ZoneOf(1456) == 1412 and f1 == 1412 and f2 == 1412
        -- Fokus-Wächter: Spieler in Thunder Bluff, Fokus Mulgore -> kein Eintrag
        P.lastTasks = tasks
        Geo.Player = function() return pi, pn, pw, 1456, 45, 55 end
        local n0 = Pr:Count(true)
        WithEnv({ Pr.CheckFocus }, { GetTime = function() return 1e9 end, UnitOnTaxi = function() return false end }, function() Pr:CheckFocus() end)
        local logged = Pr:Count(true) - n0
        -- Vorrang-Ziel (Klassentrainer in Thunder Bluff) nicht vor nahe Abgaben
        local steps = { { t = "TURNIN", nearTurnin = true, key = "TURNIN:1" }, { t = "TURNIN", nearTurnin = true, key = "TURNIN:2" },
                        { t = "ACCEPT", key = "ACCEPT:3" } }
        P.InsertPriority(steps, { t = "GOTO", key = "PRIO:TRAIN:8" })
        local prioOk = steps[3].key == "PRIO:TRAIN:8" and steps[1].t == "TURNIN"
        local ok = same and logged == 0 and prioOk
        return ok, string.format("Fokus aus Thunder Bluff %s/%s, Wächter-Einträge %d, Vorrang-Ziel an Stelle %s", S(f1), S(f2), logged,
            prioOk and "3 (nach den Abgaben)" or "falsch"), "1412/1412, 0, nach den Abgaben"
    end, function()
        P.focus, LP.char.focusZone, P.lastTasks = savedFocus, savedZone, savedTasks
        Geo.Player = savedPlayer
    end)
end

IMPL.T218 = function()
    local N, Geo = LP.Nav, LP.Geo
    local function P(x, y, via, map) local i, n, w = Geo:ToWorld(map or 1412, x, y) return { i, n, w, map or 1412, via = via } end
    if not Geo:ToWorld(1412, 50, 50) then return true, "Mulgore-Karte nicht verfügbar" end
    -- a) Mulgore Fall 1: Red Cloud Mesa -> 62/58 nur als Luftlinie (kein gelaufener Weg) -> keine Linie
    local a = N.Known({ P(54.1, 83.9), P(50, 35, "v"), P(62, 58, "v") }) == false
    -- Mulgore Fall 2: 39.3/46.2 -> Schleife 30/32 als Luftlinie -> keine Linie
    local b = N.Known({ P(39.3, 46.2), P(30, 32, "v") }) == false
    -- b) bekannter Weg: kurzes erstes Stück, gelaufene Kanten, kurzes letztes Stück -> Linie
    local p1 = P(46.0, 63.0)
    local p2 = { p1[1], p1[2] + 20, p1[3], 1412 }
    local p3 = { p1[1], p1[2] + 300, p1[3] + 50, 1412, via = "s" }
    local p4 = { p1[1], p1[2] + 600, p1[3] + 80, 1412, via = "r" }
    local p5 = { p1[1], p1[2] + 630, p1[3] + 80, 1412, via = "v" }
    local c = N.Known({ p1, p2, p3, p4, p5 }) == true
    -- Ziel ohne Netzanschluss: letztes Stück 200 Yards Luftlinie -> keine Linie
    local p6 = { p1[1], p1[2] + 800, p1[3] + 80, 1412, via = "v" }
    local d = N.Known({ p1, p2, p3, p4, p6 }) == false
    -- c) Thunder Bluff mit Aufzug: ohne gelaufene Aufzugskante bleibt der Weg unbekannt, mit Kante bekannt
    local t1 = P(30, 30, nil, 1456)
    local up = { t1[1], t1[2] + 25, t1[3], 1456, via = "v" }
    local lift = { t1[1], t1[2] + 25, t1[3] + 5, 1456, via = "s" }
    local trainer = { t1[1], t1[2] + 60, t1[3] + 5, 1456, via = "v" }
    local e = t1[1] and N.Known({ t1, up, { t1[1], t1[2] + 200, t1[3], 1456, via = "v" } }) == false
    local f = t1[1] and N.Known({ t1, up, lift, trainer }) == true
    local ok = a and b and c and d and (not t1[1] or (e and f))
    return ok, string.format("Mulgore 1 %s, Mulgore 2 %s, bekannter Weg %s, Ziel ohne Netz %s, Aufzug ohne/mit Kante %s/%s",
        S(a), S(b), S(c), S(d), S(e), S(f)), "alles true"
end

IMPL.T219 = function()
    local N, Geo, Gr = LP.Nav, LP.Geo, LP.Graph
    local pi, pn, pw = Geo:Player()
    if not pi then return true, "keine Position" end
    local tgt = { key = "LPTestFest", inst = pi, n = pn + 500, w = pw, label = "LPTest" }
    local savedT, savedP, savedKey = N.target, Geo.Player, N.stuckKey
    local cn, cw = pn, pw
    local px, py = cn, cw
    local afk = false
    local fake = { UnitIsAFK = function() return afk end, UnitIsDeadOrGhost = function() return false end,
                   UnitOnTaxi = function() return false end }
    -- Szenario: Liste { Sekunden, Art } mit Art "steh", "kreis"; AFK-Schalter je Szenario
    local function run(plan, isAfk)
        N.ResetStuck()
        afk = isAfk and true or false
        local now, ang = 1000, 0
        px, py = cn + 30, cw                                   -- Kreis um (cn, cw), Start am zielnächsten Punkt
        return WithCounter(N, "OnStuck", function(fired)
            WithEnv({ N.StuckTick, N.Excluded }, fake, function()
                for _, part in ipairs(plan) do
                    for _ = 1, part[1] do
                        now = now + 1
                        if part[2] == "kreis" then
                            ang = ang + 0.25
                            px, py = cn + 30 * math.cos(ang), cw + 30 * math.sin(ang)
                        end
                        N:StuckTick(now)
                    end
                end
            end)
            return fired()
        end)
    end
    return Guard(function()
        N.target = tgt
        Geo.Player = function() return pi, px, py, nil end
        local a = run({ { 600, "kreis" } }, true)                          -- 10 min AFK (auch wenn sich etwas bewegt)
        local a2 = run({ { 600, "steh" } }, false)                         -- 10 min stehen
        local b = run({ { 120, "steh" }, { 60, "kreis" } }, false)          -- 2 min stehen, dann 1 min laufen
        local c = run({ { 250, "kreis" } }, false)                         -- 4 min im Kreis ohne Annäherung
        -- Kante sperren: die Wegsuche nimmt sie nicht mehr
        local i1 = Gr:AddNode(pi, pn + 3000, pw + 3000)
        local i2 = Gr:AddNode(pi, pn + 3100, pw + 3000)
        Gr:AddEdge(i1, i2, "s")
        local before = Gr:IsBlocked(i1, i2)
        Gr:Block(i1, i2, "FEST")
        local after = Gr:IsBlocked(i1, i2)
        local p = Gr:PathRaw(pi, pn + 3000, pw + 3000, nil, pi, pn + 3100, pw + 3000, nil)
        local usesEdge = false
        for _, q in ipairs(p or {}) do if q.via == "s" then usesEdge = true end end
        Gr:Unblock(i1, i2)
        local ok = a == 0 and a2 == 0 and b == 0 and c == 1 and not before and after and not usesEdge
        return ok, string.format("10 min AFK %d, 10 min stehen %d, 2+1 min %d, 4 min Kreis %d (FEST), Kante gesperrt %s, danach gemieden %s",
            a, a2, b, c, S(after), S(not usesEdge)), "0, 0, 0, 1, true, true"
    end, function()
        N.target, Geo.Player, N.stuckKey = savedT, savedP, savedKey
        N.ResetStuck()
    end)
end

IMPL.T220 = function()
    local R, Q, Geo = LP.Recorder, LP.QuestDB, LP.Geo
    local N = _G.LevelPilotData and _G.LevelPilotData.N
    local npc = 6747                                    -- Gastwirt Kauth (Bloodhoof), Abgabe von „Eine unvollendete Aufgabe“
    if type(N) ~= "table" or not N[npc] then return true, "kein Datenpaket" end
    local pi = Geo:ToWorld(1412, 47.0, 61.0)
    if not pi then return true, "Mulgore-Karte nicht verfügbar" end
    LP.db.npcPos = type(LP.db.npcPos) == "table" and LP.db.npcPos or {}
    local saved = LP.db.npcPos[npc]
    local savedPlayer = Geo.Player
    return Guard(function()
        LP.db.npcPos[npc] = nil
        Geo.Player = function() local i, n, w = Geo:ToWorld(1412, 47.0, 61.0) return i, n, w, 1412, 47.0, 61.0 end
        WithEnv({ R.RecordNpc }, { UnitGUID = function() return "Creature-0-1-1-1-" .. npc .. "-0000ABCD99" end }, function() R:RecordNpc() end)
        local rec = LP.db.npcPos[npc]
        Q:Invalidate()
        local q = Q:Get(1656)
        local e = q and q.ends and q.ends[1]
        local used = e and e[1] == 1412 and math.abs(e[2] - 47.0) < 0.01 and math.abs(e[3] - 61.0) < 0.01
        -- geschützte GUID: nichts gemerkt
        LP.db.npcPos[npc] = nil
        local bait = "LPTestKoeder GUID"
        WithSecret({ bait }, function()
            WithEnv({ R.RecordNpc }, { UnitGUID = function() return bait end }, function() R:RecordNpc() end)
        end)
        local none = LP.db.npcPos[npc] == nil
        local ok = rec ~= nil and used and none
        return ok and true or false, string.format("gemerkt %s (Datenpaket %s), Abgabeziel aus dem echten Ort %s, geschützt nichts %s",
            S(rec ~= nil), rec and rec.o and string.format("%.1f/%.1f", rec.o[2], rec.o[3]) or "-", S(used), S(none)), "true, true, true"
    end, function()
        LP.db.npcPos[npc] = saved
        Geo.Player = savedPlayer
        Q:Invalidate()
    end)
end

------------------------------------------------------------------------
-- Ablauf
------------------------------------------------------------------------
local function GT() return _G.GoldSentinelTest end
local AREAS = "abcdefghij"

function TR:CanStart(silent)
    if LP:InCombat() then
        if not silent then LP:Print(L["Testroutine nur ausserhalb des Kampfes."]) end
        return false
    end
    if LP.Virtual and LP.Virtual.active then
        if not silent then LP:Print(L["Testroutine: Es läuft gerade eine virtuelle Reise."]) end
        return false
    end
    if self.running then
        if not silent then LP:Print(L["Testroutine läuft bereits."]) end
        return false
    end
    if not GT() then
        if not silent then LP:Print(L["GoldSentinelTest.lua fehlt – keine Testroutine möglich."]) end
        return false
    end
    return true
end

-- eine Prüfung eintragen
local function RunOne(T, e)
    local id, area, name = e[1], e[2], e[3]
    if TR.LONG[id] and not TR.long then
        T:Skip(id, area, name, LONG_ONLY)
    elseif IMPL[id] then
        local fn = IMPL[id]
        local autoOK, autoText
        -- erster Rückgabewert immer als true/false (nil aus "a and b" darf nicht als OK gelten)
        local passed = T:Check(id, area, name, function()
            local a, b, c = fn()
            if a then autoOK, autoText = true, b return true, b end
            return false, b, c
        end)
        -- automatischer Teil OK, Rest im Client (auto + halb): zusätzlich als "im Client prüfen" eintragen
        if passed and CLIENT[id] and T.results[#T.results] and T.results[#T.results].id == id then
            T.results[#T.results].status = "CLIENT"
            T.counts.ok, T.counts.client = T.counts.ok - 1, T.counts.client + 1
            T.results[#T.results].anleitung = CLIENT[id] .. " (automatischer Teil OK" .. (autoText and (": " .. tostring(autoText)) or "") .. ")"
        end
    elseif CLIENT[id] then T:Client(id, area, name, CLIENT[id])
    elseif SKIP[id] then T:Skip(id, area, name, SKIP[id])
    else
        TR.notYet = (TR.notYet or 0) + 1
        T:Skip(id, area, name, NOT_YET)
    end
end

-- Sandbox: echte Daten sichern / in place zurückschreiben / vergleichen
local function Copy(v) return LP.Backup.DeepCopy(v) end
local function RestoreInto(cur, saved)
    for k in pairs(cur) do if saved[k] == nil then cur[k] = nil end end
    for k, v in pairs(saved) do
        if type(v) == "table" and type(cur[k]) == "table" and getmetatable(cur[k]) == nil then RestoreInto(cur[k], v)
        else cur[k] = v end
    end
end

local function Snapshot()
    local sb = { acc = {}, char = Copy(LevelPilotCharDB), enc = {}, encChar = nil }
    for k, v in pairs(LevelPilotDB) do if k ~= "gsTest" then sb.acc[k] = Copy(v) end end
    sb.debug, sb.mode = LP.debug, LP.char.mode
    local P = LP.Planner
    sb.focus, sb.priority, sb.leftZones = P.focus, P.priority, P.leftZones and Copy(P.leftZones)
    sb.queue = LP.Comm.QueueSnapshot and LP.Comm:QueueSnapshot() or nil
    sb.language = LP.db.language
    return sb
end

local function Restore(sb)
    local accSaved = {}
    for k, v in pairs(sb.acc) do accSaved[k] = Copy(v) end
    accSaved.gsTest = LevelPilotDB.gsTest                       -- der neue Bericht bleibt stehen
    RestoreInto(LevelPilotDB, accSaved)
    RestoreInto(LevelPilotCharDB, Copy(sb.char))
    LP:LoadSaved(LevelPilotDB, LevelPilotCharDB)
    LP.debug = sb.debug
    local P = LP.Planner
    P.focus, P.priority = sb.focus, sb.priority
    if sb.leftZones then P.leftZones = sb.leftZones end
end

local function Diff(sb, yield)
    local Enc = GT().Encode
    local bad = {}
    local keys = {}
    for k in pairs(sb.acc) do keys[k] = true end
    for k in pairs(LevelPilotDB) do if k ~= "gsTest" then keys[k] = true end end
    for k in pairs(keys) do
        if Enc(sb.acc[k]) ~= Enc(LevelPilotDB[k]) then bad[#bad + 1] = tostring(k) end
        yield()
    end
    if Enc(sb.char) ~= Enc(LevelPilotCharDB) then bad[#bad + 1] = "LevelPilotCharDB" end
    if LP.char ~= LevelPilotCharDB then bad[#bad + 1] = "LP.char" end
    if type(LevelPilotDB.taxi) == "table" and getmetatable(LevelPilotDB.taxi) ~= nil then bad[#bad + 1] = "taxi (Überlagerung)" end
    if LP.db.language ~= sb.language then bad[#bad + 1] = "language" end
    table.sort(bad)
    return #bad == 0 and "OK" or ("FEHLER: " .. table.concat(bad, ", "))
end

-- Beobachtung echter Spielereignisse während des Laufs
local watch = CreateFrame("Frame")
local WATCH = { PLAYER_REGEN_DISABLED = "Kampf begonnen", QUEST_TURNED_IN = "echtes Spielereignis während des Tests",
                PLAYER_LEVEL_UP = "echtes Spielereignis während des Tests", QUEST_ACCEPTED = "echtes Spielereignis während des Tests",
                TAXIMAP_OPENED = "echtes Spielereignis während des Tests" }
watch:SetScript("OnEvent", function(_, ev) if TR.running and not TR.abort then TR.abort = WATCH[ev] end end)

-- direkte Aufrufe an LP.Act vorbei zählen (nur während des Laufs; hooksecurefunc ersetzt nichts)
local hooked = false
TR.direct = 0
local function InstallHooks()
    if hooked or not hooksecurefunc then return end
    hooked = true
    local function count() if TR.running then TR.direct = TR.direct + 1 end end
    for _, n in ipairs({ "BuyMerchantItem", "RepairAllItems", "TakeTaxiNode", "AcceptQuest", "CompleteQuest", "GetQuestReward",
                         "EquipItemByName", "QuestLogPushQuest" }) do
        if type(_G[n]) == "function" then pcall(hooksecurefunc, n, count) end
    end
end

function TR:Run(area, long)
    if not LP:DevOnly() or not self:CanStart() then return end
    area = area and area:upper() or nil
    if area and not AREAS:upper():find(area, 1, true) then area = nil end
    local A = LP.Act
    self.running, self.abort, self.direct, self.notYet, self.long = true, nil, 0, 0, long and true or false
    LP.testGen = LP.testGen + 1
    A.dry, A.log, A.dryCount = true, {}, 0
    local realBefore = A.real
    InstallHooks()
    for ev in pairs(WATCH) do pcall(watch.RegisterEvent, watch, ev) end
    local errBefore = LP.errorCount
    local T = GT().Begin("LevelPilot", LP.version, LevelPilotDB)
    LP:Print(L["Testroutine läuft – bitte stillstehen …"])
    local sb = Snapshot()
    collectgarbage("collect")
    self.memStart = collectgarbage("count")          -- nach der Sicherung (die Kopie zählt nicht als Zuwachs)

    local sliceStart = Ms()
    local co
    local function yield()
        if Ms() - sliceStart > 8 then coroutine.yield() end
    end
    local function body()
        -- virtuelle Reisen vorab (Warten ausserhalb jeder Prüfung)
        self.journey = nil
        if not area or area == "B" or area == "H" or area == "J" then
            self:Journeys(function(cond, maxSec)
                local t0 = GetTime()
                while not cond() and GetTime() - t0 < maxSec and not self.abort do coroutine.yield() end
            end, self.long)
            -- Speicher (T157) ab hier: die Reisen füllen einmalig Zwischenspeicher (Wegenetz, Gefahrenkarte) und der
            -- letzte Reisebericht bleibt absichtlich für /lp reise bericht stehen
            collectgarbage("collect")
            self.memStart = collectgarbage("count")
        end
        for _, e in ipairs(self.IDS) do
            if (not area or e[2] == area) and e[1] ~= "T165" and e[1] ~= "T166" then
                if self.abort then T:Skip(e[1], e[2], e[3], self.abort)
                else RunOne(T, e) end
                yield()
            end
        end
        -- Sandbox zurück und vergleichen
        local ok, err = pcall(Restore, sb)
        local sandbox = ok and Diff(sb, yield) or ("FEHLER: " .. tostring(err))
        -- Testfehler aus der Fehlerliste von GoldSentinelTest entfernen (sonst gelten sie als echte Fehler)
        local s = LevelPilotDB.gsTest
        if s and type(s.errors) == "table" then
            for k, v in pairs(s.errors) do
                local m = type(v) == "table" and tostring(v.msg) or ""
                if m:find("LP-Testfehler", 1, true) or (type(v) == "table" and v.wo == "Testroutine") then s.errors[k] = nil end
            end
        end
        pcall(LP.Protocol.LoadEntries, LP.Protocol)
        -- T166: IDs eindeutig und vollständig
        if not area or area == "I" then
            T:Check("T166", "I", "Testfall-IDs eindeutig und vollständig", function()
                local seen, dup, miss = {}, {}, {}
                for _, r in ipairs(T.results) do
                    if seen[r.id] then dup[#dup + 1] = r.id end
                    seen[r.id] = true
                end
                for _, e in ipairs(self.IDS) do
                    if (not area or e[2] == area) and e[1] ~= "T165" and e[1] ~= "T166" and not seen[e[1]]
                       and not (#T.results >= GT().MAX_RESULTS) then miss[#miss + 1] = e[1] end
                end
                return #dup == 0 and #miss == 0, "doppelt: " .. table.concat(dup, ",") .. " fehlend: " .. table.concat(miss, ","), "keine"
            end)
        end
        local extra = { sandbox = sandbox, sprache = LP:Language(), spielsprache = GetLocale(), fehlerzaehler = LP.errorCount,
                        fehlerEindeutig = Count(LP.errors), initFehler = Count(LP.initErrors),
                        datenpaket = _G.LevelPilotData and _G.LevelPilotData.version, modus = LP.char.mode,
                        bereich = area or "alle", echteAktionen = (A.real - realBefore) + self.direct,
                        nichtAutomatisiert = self.notYet }
        -- T165: Bericht ohne Namen (vor Finish geprüft)
        if not area or area == "I" then
            T:Check("T165", "I", "Bericht gespeichert und datenschutzkonform", function()
                local enc = GT().Encode(T:Report(extra))
                local me = UnitName("player")
                local guild = GetGuildInfo and GetGuildInfo("player")
                local leak = (type(me) == "string" and me ~= "" and enc:find(me, 1, true)) or
                             (type(guild) == "string" and guild ~= "" and enc:find(guild, 1, true))
                local acts = (A.real - realBefore) + self.direct
                return not leak and acts == 0, "Namen im Bericht: " .. S(leak and true or false) .. ", echte Aktionen: " .. acts,
                    "keine Namen, 0 echte Aktionen"
            end)
        end
        local text = T:Finish(extra)
        -- Platzhalter zählen nicht als bestanden: eigene Zeile direkt unter der Zählung
        text = text:gsub("(OK %d+ · FEHLER %d+ · [^\n]*)", "%1\n" .. string.format("nicht automatisiert: %d", self.notYet), 1)
        text = text .. "\n" .. string.format("Sprache: %s (Spiel %s) · Datenpaket: %s", LP:Language(), tostring(GetLocale()),
            _G.LevelPilotData and tostring(_G.LevelPilotData.version) or "fehlt")
        text = text .. "\n" .. string.format("Fehlerzähler LevelPilot: %d (vor dem Test %d, eindeutig %d), Modulstartfehler: %d",
            LP.errorCount, errBefore, Count(LP.errors), Count(LP.initErrors))
        text = text .. "\n" .. (sandbox == "OK" and "echte Daten unverändert: OK" or ("echte Daten unverändert: " .. sandbox:gsub("^FEHLER: ", "FEHLER – ")))
        text = text .. "\n" .. string.format("mitgeschriebene Aktionen: %d · echte Aktionen: %d", A.dryCount, (A.real - realBefore) + self.direct)
        text = text .. "\n" .. "Bitte /reload"
        self.lastText = text
        LP.testGen = LP.testGen + 1
        for ev in pairs(WATCH) do pcall(watch.UnregisterEvent, watch, ev) end
        -- Nachlauf: Trockenlauf noch 5 s, dann Warteschlange von Comm auf den Stand vor dem Test
        C_Timer.After(5, function()
            A.dry = false
            if sb.queue and LP.Comm.QueueRestore then LP.Comm:QueueRestore(sb.queue) end
            self.running = false
        end)
        pcall(LP.ResetLanguageCache, LP)
        pcall(LP.Planner.BuildCandidates, LP.Planner)
        pcall(LP.Planner.Replan, LP.Planner, true)
        pcall(LP.Nav.Recalc, LP.Nav, true)
        pcall(LP.UI.Refresh, LP.UI)
        pcall(LP.Center.Refresh, LP.Center)
        LP.Backup:ShowText(L["Testroutine"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."]
            .. " " .. L["Wird auch automatisch gemeldet."], text)
        LP:Print(L["Bericht gespeichert – wird beim nächsten /reload oder Ausloggen an die Prüfung gemeldet"])
    end
    co = coroutine.create(body)
    local ticker
    ticker = C_Timer.NewTicker(0.05, function()
        sliceStart = Ms()
        local ok, err = coroutine.resume(co)
        if not ok then
            ticker:Cancel()
            A.dry = false
            pcall(Restore, sb)
            self.running = false
            LP.testGen = LP.testGen + 1
            for ev in pairs(WATCH) do pcall(watch.UnregisterEvent, watch, ev) end
            LP:Error("Testroutine", err)
        elseif coroutine.status(co) == "dead" then
            ticker:Cancel()
        end
    end)
end

-- Kurztest für alle Spieler (/lp test): nur lesende Prüfungen, gleicher Bericht
function TR:Short()
    if not GT() then LP.SelfTest:Run() return end
    local T = GT().Begin("LevelPilot", LP.version, LevelPilotDB)
    for _, e in ipairs(self.IDS) do if self.SHORT[e[1]] then RunOne(T, e) end end
    local text = T:Finish({ bereich = "kurz", sprache = LP:Language(), spielsprache = GetLocale(), fehlerzaehler = LP.errorCount,
        datenpaket = _G.LevelPilotData and _G.LevelPilotData.version })
    text = text .. "\n" .. string.format("Sprache: %s (Spiel %s) · Datenpaket: %s", LP:Language(), tostring(GetLocale()),
        _G.LevelPilotData and tostring(_G.LevelPilotData.version) or "fehlt")
    text = text .. "\n" .. string.format("Fehlerzähler LevelPilot: %d (eindeutig %d), Modulstartfehler: %d", LP.errorCount,
        Count(LP.errors), Count(LP.initErrors))
    LP.Backup:ShowText(L["Selbsttest"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."]
        .. " " .. L["Wird auch automatisch gemeldet."], text)
    return text
end

-- Halbautomatische Beobachtung (Launch-Abend): 2 Minuten, Aktionen mit Folgen nur mitgeschrieben (haendler, quest, flug)
local OBSERVE = { kampf = false, haendler = true, quest = true, flug = true, trainer = false, gruppe = false }
function TR:Observe(kind)
    if not LP:DevOnly() then return end
    if self.running then LP:Print(L["Testroutine läuft bereits."]) return end
    local A = LP.Act
    local dry = OBSERVE[kind]
    self.running = true
    local err0, mark = LP.errorCount, #A.log
    if dry then A.dry = true end
    LP:Print(L("Beobachtung „%s“ läuft 2 Minuten – jetzt die Aktion im Spiel ausführen.", kind))
    C_Timer.After(120, function()
        if dry then A.dry = false end
        self.running = false
        local names = {}
        for i = mark + 1, #A.log do names[#names + 1] = tostring(A.log[i].name) end
        LP:Print(L("Beobachtung „%s“ beendet: neue Fehler %d, mitgeschriebene Aktionen: %s", kind, LP.errorCount - err0,
            #names > 0 and table.concat(names, ", ") or "–"))
    end)
end

function TR:Command(arg)
    arg = arg and arg:lower():gsub("^%s+", ""):gsub("%s+$", "") or ""
    if arg == "" then return self:Run(nil) end
    if #arg == 1 and AREAS:find(arg, 1, true) then return self:Run(arg) end
    if OBSERVE[arg] ~= nil then return self:Observe(arg) end
    if arg == "reise" or arg == "journey" then return self:Run(nil, true) end
    LP:Print(L["Testroutine: /lp testroutine [a–j | kampf | haendler | quest | flug | trainer | gruppe]"])
end
