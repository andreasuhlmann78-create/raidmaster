# LevelPilot changelog

## 3.5.3
- Changed: the language selection only offers languages your game can display. LevelPilot measures it:
  a missing font draws every character as an identical box, so if all sample characters of a language
  are as wide as a surely missing character, that language is hidden. On European and Russian clients
  Korean and Chinese are hidden; on clients that have those fonts everything stays available.
- A saved language that can't be displayed falls back to "Automatic"; /lp lang refuses it with a reason.
- Fixed: language buttons keep their own script font (e.g. "Русский" no longer turned into boxes).

## 3.5.2
- Fixed: no more language mix. Vendor, innkeeper and flight master names, enemy names in the safe mode
  warning, the navigation arrow, nameplate texts and time units (h/min) now follow the chosen language.
  Hint pop-ups in the old language are closed when you switch.
- Fixed: buttons shrink their font instead of cutting off long words (e.g. Russian "Automatic").
- Fixed: the status bar measures its real text height, so long status lines are no longer cut off.
- Fixed: Russian font has no middle dot "·" – it is replaced, no more empty boxes.
- New: if a language pack can't be loaded, LevelPilot says why (most often: WoW must be fully restarted
  once after new AddOn folders were added – /reload is not enough). /lp diag shows the language packs.

## 3.5.1
- Packaging: one single download (LevelPilot.zip) now contains the addon, the data package and all
  language packs. Extract everything into Interface/AddOns.

## 3.5.0
- New: quest, NPC, item, object and zone names follow the language you choose in LevelPilot – no longer
  the language of your game client. Translations come from QuestieDB (GPLv3) as language packs in the
  data package (LevelPilot Data 1.5.0: LevelPilot_Data_deDE, _frFR, _esES, _esMX, _ptBR, _ruRU, _koKR,
  _zhCN, _zhTW). Only the packs that are needed are loaded. English uses the names of the data package;
  Italian has no Questie translation and shows English names.
- Quest objectives from the quest log are shown in the chosen language as well ("Name: 3/7").
- In your game's own language, the titles the game shows are kept; quests not yet in your log no longer
  appear in English.
- Target macros keep the names the game knows, so targeting still works in any language.

## 3.4.5
- Fixed: switching the language now updates every label in the guide window and the control center
  immediately – no /reload needed – and switching back restores everything. Words that share one
  translation (e.g. German "Austausch" and "Teilen" are both "Compartir" in Spanish) no longer come
  back wrong. Steps, hints and data source info are rebuilt in the new language as well.

## 3.4.4
- Changed: vendors now get every grey item – weapons, armour and junk. Items whose data the game had
  not loaded yet (often weapons from earlier sessions) used to stay in the bags; they are now sold too.
  Only items needed for a running quest or that start a quest are kept. The chat message shows the
  real amount earned.

## 3.4.3
- Fixed: the guide window header no longer cuts off text. The zone name has its own line across the
  full width, the "Normal / Skip / Replan" buttons moved to a separate row, and the XP line wraps
  instead of being hidden behind the buttons.
- Fixed: the status bar grows with its text and keeps clear of the resize grip.
- Fixed: the replan button showed an empty box (the ↻ glyph is missing in the game fonts) – it now uses
  an arrow icon. Arrows "→" in texts were replaced by "»" for the same reason.

## 3.4.2
- New: **Support** button in the guide window's title bar (a coin icon when the window is narrow), a
  "Support the addon" line in Settings and `/lp donate` (also `/lp spenden`, `/lp support`). It shows the
  PayPal link to copy – it never opens on its own and never posts anything in chat.

## 3.4.1
- New: error log for testers. LevelPilot quietly notes Lua errors, wrongly detected zones, unknown
  position, planning in the wrong zone, missing paths, being stuck, very long steps, deaths, slow
  planning and login/logout. `/lp protokoll` shows it as text to copy; it stays on your computer and
  contains no names or login data. Can be switched off under Extras.

## 3.4.0
- New control center tab "Extras": quest item locations with arrow and alert, quest tooltips, automatic
  restocking of food/water/ammo/pet food, auto-equip of reward upgrades, gold per hour, best level times,
  time estimates, rested/hearthstone status, "where was I?" on login, turn-in reminders, logout summary,
  corpse arrow, class quest and trainer cost hints, mount gold planning, quest sharing, group finder
  text, elite partner search, compact mode and per-character settings.
- Fixed: corpse arrow position, gold per hour counting.
