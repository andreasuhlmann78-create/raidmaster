-- LevelPilot - Rechenzeit: Messung je Modul, Notbremse, Arbeit in Portionen (3.12.24)
--
-- Befund 10. Nov. 2026: Auf einem Charakter mit dichtem Wegnetz (viel gelaufen, Orgrimmar/Brachland) fror das Spiel
-- nach dem Einloggen ein. Darum:
--   * LP.Jobs   – schwere Arbeit (Wegsuche, Wegnetz teilen/verbinden) laeuft in einer Coroutine, je Bild hoechstens
--                 BUDGET_MS Millisekunden, danach geht es im naechsten Bild weiter.
--   * LP.Perf   – misst die Rechenzeit je Modul (Route, Wegnetz, Netz-Empfang, Quests, Anzeige, ...), die ersten
--                 60 Sekunden nach dem Einloggen getrennt, fuer das Diagnose-Protokoll.
--   * Notbremse – dauert ein Aufruf laenger als BRAKE_MS oder summiert sich in 5 s mehr als BRAKE_SUM_MS, ruht die
--                 Funktion 60 s: eine Chatzeile, ein Eintrag LANGSAM im Diagnose-Protokoll (ohne Namen).
local ADDON, LP = ...
local L = LP.L

-- 3.12.30 SP1: angelegter Lua-Speicher (KB) waehrend eines Aufrufs; faellt der Wert (Muellabfuhr lief), zaehlt 0
local gcount = collectgarbage
local function MemKB()
    if not gcount then return 0 end
    local ok, v = pcall(gcount, "count")
    return ok and tonumber(v) or 0
end

local function Clock()
    if debugprofilestop then return debugprofilestop() end
    return (os and os.clock and os.clock() or 0) * 1000
end

------------------------------------------------------------------------
-- Messung je Modul
------------------------------------------------------------------------
local Perf = { BRAKE_MS = 50, BRAKE_SUM_MS = 1000, BRAKE_WINDOW = 5, BRAKE_PAUSE = 60, LOGIN_SECS = 60 }
LP.Perf = Perf
Perf.clock = Clock                 -- Testroutine: eigene Uhr einsetzbar
Perf.mem = MemKB                   -- Testroutine: eigene Speichermessung einsetzbar
Perf.stats = {}                    -- [modul] = { n, ms, max, ln, lms, lmax }
Perf.windows = {}                  -- [key] = { t0, sum }
Perf.paused = {}                   -- [key] = Ende der Pause (GetTime)
Perf.said = {}                     -- [key] = true: Chatzeile in dieser Sitzung schon gezeigt
Perf.loginT = nil

-- sichtbare Modulnamen (Schluessel der Sprachtabelle)
Perf.NAMES = {
    route = "Routenberechnung", path = "Wegsuche", graph = "Wegnetz", net = "Netz-Empfang",
    quests = "Questauswertung", ui = "Anzeige", nav = "Navigation", record = "Aufzeichnung", proto = "Protokoll",
    start = "Start", advisor = "Assistent", backup = "Sicherung",
}

local function Now() return GetTime and GetTime() or 0 end

function Perf.InLogin()
    return Perf.loginT ~= nil and Now() - Perf.loginT <= Perf.LOGIN_SECS
end

-- 3.12.97 (Ingametest 3.12.95 T261 a): in den ersten 60 s zusätzlich je Bereich nach Auftrag/Schlüssel (z. B. graph: umweg1413,
-- strassen, eigeneKetten) – so zeigt T261, welche Arbeit im Bereich bleibt
Perf.loginKeys = {}                 -- [modul][schlüssel] = { n, ms, max }
local function KeyName(key)
    key = tostring(key)
    local base, num = key:match("^(%a+)(%d+)t?$")
    return base and (base .. "*") or key                -- umweg1411, umweg1413 -> umweg* (je Zone getrennt wäre zu lang)
end
Perf.KeyName = KeyName
function Perf.Add(mod, ms, kb, key)
    local s = Perf.stats[mod]
    if not s then s = { n = 0, ms = 0, max = 0, ln = 0, lms = 0, lmax = 0, kb = 0 } Perf.stats[mod] = s end
    s.n, s.ms = s.n + 1, s.ms + ms
    if kb and kb > 0 then s.kb = (s.kb or 0) + kb end
    if ms > s.max then s.max = ms end
    -- Testroutine (trocken): zaehlt nicht zu den ersten 60 s nach dem Einloggen
    if Perf.InLogin() and not (LP.Act and LP.Act.dry) then
        s.ln, s.lms = s.ln + 1, s.lms + ms
        if ms > s.lmax then s.lmax = ms end
        if key ~= nil then
            local m = Perf.loginKeys[mod]
            if not m then m = {} Perf.loginKeys[mod] = m end
            local k = KeyName(key)
            local e = m[k]
            if not e then e = { n = 0, ms = 0, max = 0 } m[k] = e end
            e.n, e.ms = e.n + 1, e.ms + ms
            if ms > e.max then e.max = ms end
        end
    end
end

function Perf.Paused(key)
    local t = Perf.paused[key]
    if not t then return false end
    if Now() >= t then Perf.paused[key] = nil return false end
    return true
end

-- Notbremse pruefen; info: kurze Angaben fuer das Protokoll (Ziele, Punkte, Zone) – nie Namen
function Perf.Check(key, ms, info)
    local now = Now()
    local w = Perf.windows[key]
    if not w or now - w.t0 > Perf.BRAKE_WINDOW then w = { t0 = now, sum = 0 } Perf.windows[key] = w end
    w.sum = w.sum + ms
    local over = ms > Perf.BRAKE_MS and ("%d ms"):format(math.floor(ms))
        or (w.sum > Perf.BRAKE_SUM_MS and ("%d ms in %d s"):format(math.floor(w.sum), Perf.BRAKE_WINDOW))
    if not over then return false end
    Perf.paused[key] = now + Perf.BRAKE_PAUSE
    Perf.windows[key] = nil
    Perf.brakes = (Perf.brakes or 0) + 1
    local name = L[Perf.NAMES[key] or key]
    if not Perf.said[key] and not (LP.Virtual and LP.Virtual.active) then
        Perf.said[key] = true
        LP:Print(L("%s pausiert (zu aufwendig) – weiter in 60 Sekunden.", name))
    end
    if LP.Protocol and LP.Protocol.Add then
        local _, _, _, map = LP.Geo and LP.Geo:Player()
        pcall(LP.Protocol.Add, LP.Protocol, "brake",
            ("%s %s%s · Zone %s · Pause 60 s"):format(Perf.NAMES[key] or key, over, info and (" · " .. info) or "", tostring(map or "?")))
    end
    return true
end

-- 3.12.25: Hintergrund-Arbeit in Portionen: nur die laengste Portion zaehlt (ueber BRAKE_MS -> Pause)
function Perf.CheckSlice(key, ms, info)
    if ms > Perf.BRAKE_MS then return Perf.Check(key, ms, info) end
    return false
end

-- waehrend einer Pause verworfene Aufrufe (Diagnose) und Nachholen nach der Pause
Perf.skipped = {}
Perf.after = {}                    -- [key] = Funktion, die nach der Pause einmal laeuft
local function Skip(key)
    Perf.skipped[key] = (Perf.skipped[key] or 0) + 1
    local fn = Perf.after[key]
    if fn and not Perf.afterSet then Perf.afterSet = {} end
    if fn and not Perf.afterSet[key] and C_Timer and C_Timer.After then
        Perf.afterSet[key] = true
        local wait = math.max(0.1, (Perf.paused[key] or Now()) - Now() + 0.1)
        C_Timer.After(wait, function()
            Perf.afterSet[key] = nil
            if not Perf.Paused(key) then pcall(fn) end
        end)
    end
end
Perf.Skip = Skip

-- Funktion messen; brake = true: Notbremse fuer diesen Schluessel. Rueckgabe wie fn (oder nichts, wenn pausiert).
function Perf.Run(key, mod, brake, fn, ...)
    if brake and Perf.Paused(key) and (Perf.testBrake or not (LP.Act and LP.Act.dry)) then Skip(key) return end
    -- 3.12.33 LP-D1: laeuft der Aufruf in einer Portion (LP.Jobs) und gibt dazwischen an das Spiel ab, zaehlt die
    -- Pause nicht mit (vorher: Wanduhr ueber mehrere Bilder, z. B. "Questauswertung 495 ms" nach dem Einloggen)
    local J = LP.Jobs
    local j = J and J.Current and J.Current()
    local p0 = j and (j.paused or 0) or 0
    local t0, m0 = Perf.clock(), Perf.mem()
    local r = { fn(...) }
    local ms = Perf.clock() - t0 - ((j and (j.paused or 0) or 0) - p0)
    if ms < 0 then ms = 0 end
    Perf.Add(mod, ms, Perf.mem() - m0, key)
    -- waehrend der Testroutine keine Notbremse (ausser im Test der Notbremse selbst)
    if brake and (Perf.testBrake or not (LP.Act and LP.Act.dry)) then Perf.Check(key, ms, Perf.info and Perf.info(key)) end
    return unpack(r)
end

-- Methode einer eigenen Tabelle ummanteln (nie Blizzard-Funktionen). bypass(args): true = ohne Bremse (Nutzer klickt)
function Perf.Wrap(tbl, method, key, mod, brake, bypass)
    if type(tbl) ~= "table" or type(tbl[method]) ~= "function" then return end
    local orig = tbl[method]
    if tbl["_perf_" .. method] then return end
    tbl["_perf_" .. method] = orig
    tbl[method] = function(...)
        if bypass and bypass(...) then return Perf.Run(key, mod, false, orig, ...) end
        return Perf.Run(key, mod, brake, orig, ...)
    end
end

-- 3.12.33 LP-D1: Hoechstwert ueber einem Bild (16 ms) rot
Perf.FRAME_MS = 16
function Perf.MaxText(ms)
    local v = math.floor(ms or 0)
    -- rot fuer farbige Anzeigen; im Text zum Kopieren (Farben entfernt) steht der Hinweis dahinter
    if (ms or 0) > Perf.FRAME_MS then return "|cffff5555" .. v .. " (über 16 ms)|r" end
    return tostring(v)
end

-- Zeilen fuer das Diagnose-Protokoll
function Perf.DiagLines()
    local out = {}
    local keys = {}
    for k in pairs(Perf.stats) do keys[#keys + 1] = k end
    table.sort(keys, function(a, b) return Perf.stats[a].ms > Perf.stats[b].ms end)
    local parts, login = {}, {}
    for _, k in ipairs(keys) do
        local s = Perf.stats[k]
        parts[#parts + 1] = ("%s %d ms/%d× max %s"):format(Perf.NAMES[k] or k, math.floor(s.ms), s.n, Perf.MaxText(s.max))
        if s.ln > 0 then login[#login + 1] = ("%s %d ms max %s"):format(Perf.NAMES[k] or k, math.floor(s.lms), Perf.MaxText(s.lmax)) end
    end
    out[#out + 1] = "ZEIT " .. (#parts > 0 and table.concat(parts, " · ") or "keine Messung")
    out[#out + 1] = "ZEIT erste 60 s nach dem Einloggen: " .. (#login > 0 and table.concat(login, " · ") or "keine Messung")
    local paused = {}
    for k in pairs(Perf.paused) do if Perf.Paused(k) then paused[#paused + 1] = Perf.NAMES[k] or k end end
    local skipped = {}
    for k, n in pairs(Perf.skipped) do skipped[#skipped + 1] = (Perf.NAMES[k] or k) .. " " .. n end
    table.sort(skipped)
    out[#out + 1] = "ZEIT in Pausen verworfen: " .. (#skipped > 0 and table.concat(skipped, ", ") or "nichts")
    out[#out + 1] = ("ZEIT Notbremse %d× · pausiert: %s · Hintergrund-Arbeit: %d laufend, %d fertig, längste Portion %d ms")
        :format(Perf.brakes or 0, #paused > 0 and table.concat(paused, ", ") or "nichts", LP.Jobs.Count(),
            LP.Jobs.done or 0, math.floor(LP.Jobs.maxSlice or 0))
    return out
end

-- 3.12.30 SP1 / 3.12.34 L-1: Speicher-Zeilen fuer das Diagnose-Protokoll. mem = Pr.MemInfo() in KB:
-- luaLogin/luaNow/luaPeak = collectgarbage("count") (alle Addons), login/now/peak/ms = LevelPilot auf Befehl.
-- "angelegt" = Lua-Speicher, den die Module seit dem Einloggen angelegt haben (wird groesstenteils wieder frei: Muell);
-- "Bestand" = Groesse der Zwischenspeicher, die bleiben. Keine volle Muellabfuhr (das liesse das Spiel stocken).
function Perf.MemLines(mem)
    mem = mem or {}
    local function MB(kb) return kb and kb > 0 and ("%.1f MB"):format(kb / 1024) or "?" end
    local out = {}
    -- 3.12.34 L-1: Lua gesamt (alle Addons) alle 5 Min. billig gemessen; LevelPilot allein nur beim Öffnen des Protokolls
    out[#out + 1] = ("SPEICHER Lua gesamt (alle Addons, alle 5 Min.) nach dem Einloggen %s · aktuell %s · Höchstwert %s")
        :format(MB(mem.luaLogin), MB(mem.luaNow), MB(mem.luaPeak))
    out[#out + 1] = ("SPEICHER LevelPilot (gemessen beim Öffnen des Protokolls) aktuell %s · Höchstwert %s · Speicher-Messung %s")
        :format(MB(mem.now), MB(mem.peak), mem.ms and ("%.0f ms"):format(mem.ms) or "noch keine")
    local keys, sum = {}, 0
    for k, s in pairs(Perf.stats) do if (s.kb or 0) > 0 then keys[#keys + 1] = k sum = sum + s.kb end end
    table.sort(keys, function(a, b) return Perf.stats[a].kb > Perf.stats[b].kb end)
    local parts = {}
    for _, k in ipairs(keys) do parts[#parts + 1] = ("%s %s"):format(Perf.NAMES[k] or k, MB(Perf.stats[k].kb)) end
    out[#out + 1] = "SPEICHER angelegt je Modul seit dem Einloggen (Summe " .. MB(sum) .. "): "
        .. (#parts > 0 and table.concat(parts, " · ") or "keine Messung")
    local G, Q, D, P = LP.Graph, LP.QuestDB, LP.Danger, LP.Planner
    local virt, unk = 0, 0
    if G and G.CacheSizes then virt, unk = G:CacheSizes() end
    local logN = 0
    for _ in pairs(P and P.inLog or {}) do logN = logN + 1 end
    out[#out + 1] = ("SPEICHER Bestand: Wegpunkte %d · Luftlinien-Nachbarn %d · Geländeprüfungen %d · Gefahren-Strecken %d · Quests entschlüsselt %d · Aufgaben %d · Questlog %d")
        :format(G and G.Count and G:Count() or 0, virt or 0, unk or 0, D and D.CacheSize and D:CacheSize() or 0,
            Q and Q.CacheSize and Q:CacheSize() or 0, #(P and P.lastTasks or {}), logN)
    return out
end

-- Angaben fuer LANGSAM (ohne Namen)
function Perf.info(key)
    local P, G = LP.Planner, LP.Graph
    local nodes = G and G.Count and G:Count() or 0
    if key == "route" and P then
        return ("Aufgaben %d · Kandidaten %d · Questlog %d · Wegpunkte %d"):format(#(P.lastTasks or {}),
            P.diag and P.diag.candidates or 0, P.inLog and (function() local n = 0 for _ in pairs(P.inLog) do n = n + 1 end return n end)() or 0, nodes)
    end
    return ("Wegpunkte %d"):format(nodes)
end

-- nach dem Start der Module: Hauptfunktionen messen (eigene Tabellen)
function Perf.Setup()
    if Perf.ready then return end
    Perf.ready = true
    local P = LP.Planner
    -- Routenberechnung: Notbremse; ein Klick des Nutzers (verbose) rechnet immer
    Perf.Wrap(P, "Replan", "route", "route", true, function(_, verbose) return verbose end)
    -- 3.12.25: waehrend der Pause verworfene Planung danach einmal nachholen
    Perf.after.route = function() P:Replan() end
    Perf.Wrap(P, "BuildCandidates", "quests", "quests", false)
    Perf.Wrap(LP.Comm, "Receive", "net", "net", true)
    Perf.Wrap(LP.UI, "Refresh", "ui", "ui", false)
    Perf.Wrap(LP.Engine, "CheckSteps", "nav", "nav", false)
    Perf.Wrap(LP.Nav, "Recalc", "nav", "nav", false)
    Perf.Wrap(LP.Recorder, "SamplePath", "record", "record", false)
    -- 3.12.34 L-1 (d): Assistent-Prüfung (30-s-Ticker, liest Ausrüstung/Taschen) mitmessen – im Nachbau max 8,6 ms
    Perf.Wrap(LP.Advisor, "Run", "advisor", "advisor", false)
    if LP.Protocol then
        for _, m in ipairs({ "CheckZone", "CheckFocus", "CheckStep" }) do Perf.Wrap(LP.Protocol, m, "proto", "proto", false) end
    end
end

------------------------------------------------------------------------
-- Arbeit in Portionen
------------------------------------------------------------------------
local Jobs = { BUDGET_MS = 4, list = {}, done = 0, maxSlice = 0 }
LP.Jobs = Jobs
Jobs.sync = false            -- true: sofort und am Stueck rechnen (Testumgebung, virtuelle Reise)
Jobs.manual = false          -- 3.12.93: true = der Treiber ruht (Testroutine: Tests treiben ihre Portionen selbst an)
-- 3.12.93: diese Aufträge startet der Code des Spiels (Ereignis/OnUpdate) während der Testroutine nicht (am Stück = Ruckeln, siehe LP.TRLive)
Jobs.LIVE_SKIP = { navpath = true, navplan = true }

function Jobs.Count()
    local n = 0
    for _ in pairs(Jobs.list) do n = n + 1 end
    return n
end

function Jobs.Running(name) return Jobs.list[name] ~= nil end

-- Ist der laufende Code eine Portion? (fuer LP:Yield) – auch innerhalb einer Takt-Aufgabe (Coroutinen von PCall/Sliced)
function Jobs.Current()
    local co = coroutine.running()
    if not co then return nil end
    local Takt = _G.GoldSentinelTakt
    local tj = Takt and Takt.byCo and Takt.byCo[co]
    for _, j in pairs(Jobs.list) do
        if j.co == co or (tj and j.takt == tj) then return j end
    end
    return nil
end

-- name: eindeutiger Name (ein neuer Auftrag gleichen Namens ersetzt den alten); fn laeuft in einer Coroutine;
-- done(ok, ...) bekommt das Ergebnis. mod: Modul fuer die Zeitmessung. kinds: Stellen, an denen abgegeben werden
-- darf (LP:Yield(kind)); nur Stellen, die sicher nicht in einem pcall liegen (Lua 5.1 kann dort nicht abgeben).
-- 3.12.95: Aufträge, die anderer Code während der Pause einer freigegebenen Rechnung der Testroutine startet, werden zurückgestellt
-- statt verworfen (bis 3.12.94 verworfen: z. B. Umweg-Messung blieb "in Arbeit", Strassen einer Karte "geladen", Orte "im Bau" –
-- bis zum Neuaufbau). Sie starten, wenn die Testroutine endet (Jobs.FlushDeferred); ein neuerer Start gleichen Namens ersetzt sie.
Jobs.deferred = {}
local function Defer(name, mod, fn, done, kinds, takt)
    local TRp = LP.TestRoutine
    Jobs.deferred[name] = { mod = mod, fn = fn, done = done, kinds = kinds, takt = takt }
    if TRp then TRp.deferred = (TRp.deferred or 0) + 1 end
end
function Jobs.FlushDeferred()
    local d = Jobs.deferred
    Jobs.deferred = {}
    local names = {}
    for name in pairs(d) do names[#names + 1] = name end
    table.sort(names)
    for _, name in ipairs(names) do
        local a = d[name]
        local ok, err = pcall(a.takt and Jobs.StartTakt or Jobs.Start, name, a.mod, a.fn, a.done, a.kinds)
        if not ok then LP:Error(name, err) end
    end
    return #names
end

function Jobs.Start(name, mod, fn, done, kinds)
    -- 3.12.93: Testroutine – während eine freigegebene Rechnung einer Prüfung pausiert, startet anderer Code keine Aufträge
    local TRp = LP.TestRoutine
    if TRp and Jobs.LIVE_SKIP[name] and LP.TRLive and LP.TRLive() then TRp.skipped = (TRp.skipped or 0) + 1 return end
    if TRp and TRp.coopPause then Defer(name, mod, fn, done, kinds, false) return end
    Jobs.deferred[name] = nil
    if Jobs.sync or not coroutine or (LP.Virtual and LP.Virtual.active) then
        local t0 = Clock()
        -- 3.12.93: in einer freigegebenen Rechnung der Testroutine (TR.Coop) darf fn an LP:Yield-Stellen abgeben (pcall kann das nicht)
        local TR = LP.TestRoutine
        local coop = LP.CoopHere and LP.CoopHere()
        local p0 = TR and TR.pausedMs or 0
        local res = { (coop and TR.PCall or pcall)(fn) }
        Jobs.lastCpu = Clock() - t0 - (coop and ((TR.pausedMs or 0) - p0) or 0)
        Jobs.lastMax = Jobs.lastCpu
        Perf.Add(mod, Jobs.lastCpu, nil, name)
        if done then done(unpack(res)) end
        return
    end
    Jobs.list[name] = { co = coroutine.create(fn), done = done, mod = mod, started = Now(), slices = 0, cpu = 0,
                        kinds = kinds or { graph = true } }
end

function Jobs.Cancel(name)
    local j = Jobs.list[name]
    if j and j.takt and _G.GoldSentinelTakt then _G.GoldSentinelTakt.Cancel(j.takt, "abgebrochen") end
    Jobs.list[name] = nil
end

-- 3.12.92 (Plan 3.12.92 Punkt 3, Hinweis GoldSentinelTakt): wie Jobs.Start, aber die Portionen treibt der gemeinsame Takt
-- (GoldSentinelTakt: je Bild höchstens Budget, Zeitlimit, Messung längstes Bild mit Etikett, erkennt pcall/sort/gsub im Stapel und
-- gibt dort nicht ab). Eintrag in Jobs.list bleibt, damit Running/Cancel/Current/Yield gleich funktionieren.
-- done(ok, ...) wie bei Jobs.Start; bei Abbruch (neuer Auftrag gleichen Namens, Cancel) kein done.
Jobs.TAKT_BUDGET = 4
function Jobs.StartTakt(name, mod, fn, done, kinds)
    local Takt = _G.GoldSentinelTakt
    local TRp = LP.TestRoutine
    if TRp and Jobs.LIVE_SKIP[name] and LP.TRLive and LP.TRLive() then TRp.skipped = (TRp.skipped or 0) + 1 return end      -- 3.12.93: wie Jobs.Start
    if TRp and TRp.coopPause then Defer(name, mod, fn, done, kinds, true) return end                                    -- 3.12.95
    Jobs.deferred[name] = nil
    if Jobs.sync or not coroutine or (LP.Virtual and LP.Virtual.active) or not (Takt and Takt.Start) then
        return Jobs.Start(name, mod, fn, done, kinds)
    end
    if Jobs.list[name] then Jobs.Cancel(name) end
    local entry = { mod = mod, kinds = kinds or { graph = true }, started = Now(), slices = 0, cpu = 0, done = done }
    entry.takt = Takt.Start({
        name = name, owner = "LevelPilot", budget = Jobs.TAKT_BUDGET, timeout = 120, fn = fn,
        onPortion = function(job, ms)
            entry.slices, entry.cpu = entry.slices + 1, entry.cpu + ms
            if ms > (entry.max or 0) then entry.max = ms end
            Perf.Add(mod, ms, nil, name)
            if ms > Jobs.maxSlice then Jobs.maxSlice = ms end
        end,
        onDone = function(job)
            if Jobs.list[name] ~= entry then return end            -- abgebrochen/ersetzt
            Jobs.list[name] = nil
            Jobs.done = Jobs.done + 1
            Jobs.lastCpu, Jobs.lastMax = entry.cpu, entry.max or 0
            Jobs.lastSummary = Takt.Summary(job)
            if not entry.done then return end
            local ok, err
            if job.state == "fertig" then
                local r = job.result or { n = 0 }
                ok, err = pcall(entry.done, true, unpack(r, 1, r.n or #r))
            else
                ok, err = pcall(entry.done, false, tostring(job.err or job.state))
            end
            if not ok then LP:Error(name, err) end
        end,
    })
    entry.co = entry.takt and entry.takt.co
    Jobs.list[name] = entry
end

-- 3.12.93: den gemeinsamen Takt von Hand einmal antreiben (Tests). Aufgaben, deren Coroutine gerade läuft (z. B. die Testroutine
-- selbst, die hier von Hand antreibt), nimmt der Takt in diesem Aufruf nicht dran: eine laufende Coroutine kann nicht fortgesetzt
-- werden – der Takt würde die Aufgabe sonst mit "cannot resume non-suspended coroutine" als Fehler beenden.
function Jobs.TaktTick()
    local Takt = _G.GoldSentinelTakt
    if not (Takt and Takt.Tick and type(Takt.jobs) == "table") then return end
    local hidden = {}
    for i = #Takt.jobs, 1, -1 do
        local job = Takt.jobs[i]
        if type(job) == "table" and type(job.co) == "thread" and coroutine.status(job.co) ~= "suspended" then
            table.remove(Takt.jobs, i)
            hidden[#hidden + 1] = job
        end
    end
    local ok, err = pcall(Takt.Tick)
    for i = #hidden, 1, -1 do
        local job = hidden[i]
        if job.state == "laeuft" then Takt.jobs[#Takt.jobs + 1] = job end
    end
    -- war die Liste beim Antreiben leer, hat sich der Takt-Rahmen schlafen gelegt: für die zurückgelegten Aufgaben wecken
    if #hidden > 0 and #Takt.jobs > 0 and Takt.Wake then Takt.Wake() end
    if not ok then error(err, 0) end
end

-- ein Bild: jede Portion bekommt ihren Anteil am Budget
function Jobs.Step(fromDriver)
    -- 3.12.93: während der Testroutine treiben nur die Tests ihre Portionen an (vollständig gemessen, kein Test-Auftrag in fremden Bildern)
    if fromDriver and Jobs.manual then return end
    local n = Jobs.Count()
    if n == 0 then return end
    local each = Jobs.BUDGET_MS / n
    -- 3.12.25: Namen vorher kopieren – eine Portion kann einen neuen Auftrag starten (neuer Schluessel waehrend pairs)
    local names = {}
    local takt = 0
    for name, j in pairs(Jobs.list) do
        if j.takt then takt = takt + 1 else names[#names + 1] = name end
    end
    -- 3.12.92: Takt-Aufträge (Tests treiben hier von Hand an; im Spiel treibt der Takt selbst)
    if takt > 0 and not fromDriver and _G.GoldSentinelTakt and _G.GoldSentinelTakt.Tick then
        for _ = 1, #(_G.GoldSentinelTakt.jobs or {}) do Jobs.TaktTick() end
    end
    for _, name in ipairs(names) do
        local j = Jobs.list[name]
        if j then
            j.sliceStart, j.budget = Perf.clock(), each
            local m0 = Perf.mem()
            local res = { coroutine.resume(j.co) }
            local ms = Perf.clock() - j.sliceStart
            local kb = Perf.mem() - m0
            j.slices, j.cpu = j.slices + 1, j.cpu + ms
            if ms > (j.max or 0) then j.max = ms end
            Perf.Add(j.mod, ms, kb, name)
            if ms > Jobs.maxSlice then Jobs.maxSlice = ms end
            if coroutine.status(j.co) == "dead" then
                if Jobs.list[name] == j then Jobs.list[name] = nil end
                Jobs.done = Jobs.done + 1
                Jobs.lastCpu, Jobs.lastMax = j.cpu, j.max or 0
                if j.done then
                    local ok, err = pcall(j.done, unpack(res))
                    if not ok then LP:Error(name, err) end
                end
            end
        end
    end
end

-- in langen Schleifen aufrufen: gibt an das Spiel ab, wenn das Budget dieses Bildes verbraucht ist
function Jobs.Yield(kind)
    local j = Jobs.Current()
    if not j or (kind and not j.kinds[kind]) then return false end
    if j.takt then return _G.GoldSentinelTakt.Check(kind) end   -- 3.12.92: Takt gibt ab (Budget, Stapel-Prüfung)
    if Perf.clock() - (j.sliceStart or 0) >= (j.budget or Jobs.BUDGET_MS) then
        local t = Perf.clock()
        coroutine.yield()
        j.paused = (j.paused or 0) + (Perf.clock() - t)     -- 3.12.33 LP-D1: Pausenzeit (fuer Perf.Run)
        return true
    end
    return false
end

-- Antrieb: jedes Bild
local driver = CreateFrame and CreateFrame("Frame")
if driver then
    driver:SetScript("OnUpdate", function() Jobs.Step(true) end)   -- Takt-Aufträge treibt der Takt selbst
    LP.drivers = LP.drivers or {}
    LP.drivers.jobs = driver
end
