-- ThreatSentinel - Options.lua
-- Einstellungsfenster (nur ausserhalb des Kampfs) und Minimap-Knopf. Alles per Maus bedienbar.

local ADDON, ns = ...
local API = ns.API   -- Blizzard-Funktionen nur über ns.API (API.lua)
local L = ns.L

local O = {}
ns.Options = O
table.insert(ns.modules, O)

local WHITE = "Interface\\Buttons\\WHITE8X8"
local BACKDROP = BackdropTemplateMixin and "BackdropTemplate" or nil
local ACCENT = { 0.25, 0.65, 1 }

------------------------------------------------------------
-- Farbauswahl
------------------------------------------------------------
-- Übernehmen / Abbrechen für eine Farbe (getrennt, damit die Testroutine sie ohne Farbfenster prüfen kann)
local function ColorCallbacks(c, onChange, getRGB)
	local r, g, b = c[1], c[2], c[3]
	local function apply()
		local nr, ng, nb = getRGB()
		c[1], c[2], c[3] = nr, ng, nb
		onChange()
	end
	local function cancel()
		c[1], c[2], c[3] = r, g, b
		onChange()
	end
	return apply, cancel, r, g, b
end

local function OpenColor(c, onChange)
	local apply, cancel, r, g, b = ColorCallbacks(c, onChange, function() return ColorPickerFrame:GetColorRGB() end)
	if ColorPickerFrame.SetupColorPickerAndShow then
		ColorPickerFrame:SetupColorPickerAndShow({ r = r, g = g, b = b, hasOpacity = false, swatchFunc = apply, cancelFunc = cancel })
	else
		ColorPickerFrame:Hide()
		ColorPickerFrame.hasOpacity = false
		ColorPickerFrame.func = apply
		ColorPickerFrame.cancelFunc = cancel
		ColorPickerFrame.previousValues = { r, g, b }
		ColorPickerFrame:SetColorRGB(r, g, b)
		ColorPickerFrame:Show()
	end
end

O._ColorCallbacks = ColorCallbacks   -- Test-Zugang (Testroutine T91)


------------------------------------------------------------
-- Ton-Auswahl
------------------------------------------------------------
local PICK_COL_W, PICK_ROW_H = 180, 18

function O:OpenSoundPicker(title, key, onChange)
	local p = self.picker
	if not p then
		p = CreateFrame("Frame", "ThreatSentinelSoundPicker", self.frame or UIParent, BACKDROP)
		if ns.RegisterUI then ns.RegisterUI(p, "Tonauswahl") end   -- Oberflächen-Prüfung (UICheck.lua)
		p:SetFrameStrata("FULLSCREEN_DIALOG")
		p:SetClampedToScreen(true)
		p:EnableMouse(true)
		p:SetMovable(true)
		p:RegisterForDrag("LeftButton")
		p:SetScript("OnDragStart", p.StartMoving)
		p:SetScript("OnDragStop", p.StopMovingOrSizing)
		if p.SetBackdrop then
			p:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
			p:SetBackdropColor(0.05, 0.06, 0.08, 0.98)
			p:SetBackdropBorderColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.9)
		end
		tinsert(UISpecialFrames, "ThreatSentinelSoundPicker")
		p.title = p:CreateFontString(nil, "OVERLAY", "GameFontNormal")
		p.title:SetPoint("TOPLEFT", 12, -10)
		p.title:SetTextColor(ACCENT[1], ACCENT[2], ACCENT[3])
		p.help = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
		p.help:SetPoint("TOPLEFT", 12, -28)
		p.help:SetText(L.SP_HELP)
		local close = CreateFrame("Button", nil, p, "UIPanelCloseButton")
		close:SetPoint("TOPRIGHT", -2, -2)
		p.rows = {}

		local function row(col, y, text)
			local r = CreateFrame("Button", nil, p)
			r:SetSize(PICK_COL_W - 6, PICK_ROW_H)
			r:SetPoint("TOPLEFT", 10 + (col - 1) * PICK_COL_W, y)
			r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
			local hl = r:CreateTexture(nil, "HIGHLIGHT")
			hl:SetAllPoints()
			hl:SetTexture(WHITE)
			hl:SetVertexColor(1, 1, 1, 0.08)
			r.sel = r:CreateTexture(nil, "BACKGROUND")
			r.sel:SetAllPoints()
			r.sel:SetTexture(WHITE)
			r.sel:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.3)
			r.sel:Hide()
			r.text = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
			r.text:SetPoint("LEFT", 4, 0)
			r.text:SetPoint("RIGHT", -2, 0)
			r.text:SetJustifyH("LEFT")
			if r.text.SetWordWrap then r.text:SetWordWrap(false) end
			r.text:SetText(text)
			return r
		end

		local maxY = 0
		for col, g in ipairs(ns.SOUND_GROUPS) do
			local hdr = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
			hdr:SetPoint("TOPLEFT", 14 + (col - 1) * PICK_COL_W, -50)
			hdr:SetText(L["SG_" .. g])
			local y = -68
			for _, snd in ipairs(ns.SOUNDS) do
				if snd.group == g and ns:SoundAvailable(snd) then
					local r = row(col, y, L["SND_" .. snd.key] or snd.key)
					r.value = snd.key
					r:SetScript("OnClick", function(_, mb)
						if mb ~= "RightButton" then
							ns.db[p.key] = snd.key
							if p.onChange then p.onChange() end
							O:RefreshPicker()
						end
						ns.Alerts:Play(snd.key, "pick" .. GetTime(), true)
					end)
					p.rows[#p.rows + 1] = r
					y = y - PICK_ROW_H
				end
			end
			if g == "ts" then
				-- eigener Ton (WoW-Sound-ID oder Datei)
				y = y - 8
				local r = row(col, y, L.SND_CUSTOM)
				r.custom = true
				r:SetScript("OnClick", function(_, mb)
					local cur = ns.db[p.key]
					if mb == "RightButton" then
						if type(cur) == "string" and cur:sub(1, #ns.CUSTOM_PREFIX) == ns.CUSTOM_PREFIX then
							ns.Alerts:Play(cur, "pick" .. GetTime(), true)
						end
						return
					end
					-- Auswahl kurz ausblenden, damit sie das Eingabefeld nicht verdeckt;
					-- data als 4. Wert: steht schon in OnShow zur Verfügung
					p:Hide()
					StaticPopup_Show("THREATSENTINEL_CUSTOMSOUND", nil, nil, { key = p.key, reopen = true })
				end)
				p.rows[#p.rows + 1] = r
				p.customRow = r
				y = y - PICK_ROW_H
				p.customHelp = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
				p.customHelp:SetPoint("TOPLEFT", 14 + (col - 1) * PICK_COL_W, y - 4)
				p.customHelp:SetWidth(PICK_COL_W - 10)
				p.customHelp:SetJustifyH("LEFT")
				p.customHelp:SetText(L.SP_CUSTOM_HELP)
				y = y - 4 - p.customHelp:GetStringHeight()
			end
			maxY = math.min(maxY, y)
		end
		p:SetSize(20 + #ns.SOUND_GROUPS * PICK_COL_W, -maxY + 16)
		self.picker = p
	end
	p.key, p.onChange = key, onChange
	p.title:SetText(string.format(L.SP_TITLE, title))
	p:ClearAllPoints()
	p:SetPoint("CENTER", self.frame or UIParent, "CENTER", 0, 0)
	self:RefreshPicker()
	p:Show()
end

function O:RefreshPicker()
	local p = self.picker
	if not p or not p.key then return end
	local cur = ns.db[p.key]
	local isCustom = type(cur) == "string" and cur:sub(1, #ns.CUSTOM_PREFIX) == ns.CUSTOM_PREFIX
	for _, r in ipairs(p.rows) do
		local sel = (r.custom and isCustom) or (r.value ~= nil and r.value == cur)
		r.sel:SetShown(sel)
		if r.custom then
			r.text:SetText(isCustom and ns:SoundLabel(cur) or L.SND_CUSTOM)
		end
	end
end

------------------------------------------------------------
-- OPT-ALLE (Entscheid des Nutzers 18.11.2026 10:27, Vorbild AHSentinel OPT-1):
-- links Bereiche, rechts nur die Optionen des gewählten Bereichs (eine Spalte, höchstens O.MAX_ROWS Zeilen, kein Scrollen),
-- oben ein Suchfeld über alle Bereiche. Jede Zeile: kurze Beschriftung, rechts Schalter/Wert, Erklärung im Tooltip.
-- Häufig gebraucht zuerst, Seltenes unter "Weitere". Jede Option genau EINMAL (O.ROWS, Test T-OPT1); die gespeicherten
-- Werte (Schlüssel in ns.db) sind dieselben wie vorher – nur die Anzeige ist neu geordnet.
-- Leistung: die Zeilen eines Bereichs entstehen erst, wenn der Bereich zum ersten Mal gezeigt wird.
------------------------------------------------------------
O.W, O.H = 760, 520
O.NAV_W, O.ROW_H, O.LABEL_W = 170, 32, 196
O.CONTENT_X, O.TOP_Y = 182, -84
O.MAX_ROWS = 12

local function IsModern() return ns.isModern end
local function IsDev() return ns:IsDev() end
local function IsWarrior() return ns.class == "WARRIOR" end
local function ScaleSetter(which) return function(v) ns.Mover:SetScale(which, v) end end
local function RoleLabel(v) if v == "AUTO" then return L.ROLE_AUTO end return L[v] end

-- Bereiche (Reihenfolge = häufig gebraucht zuerst); help = Erklärung des Bereichs (Tooltip am "?")
O.SECTIONS = {
	{ id = "general", label = "TAB_GENERAL" },
	{ id = "plates", label = "TAB_PLATES" },
	{ id = "alerts", label = "TAB_ALERTS" },
	{ id = "sounds", label = "TAB_SOUNDS", help = "O_SOUND_HELP" },
	{ id = "display", label = "TAB_DISPLAY", help = "O_METER_HELP" },
	{ id = "group", label = "TAB_GROUP", help = "O_GROUP_HELP", help2 = function() return ns.DmgMeter.allowed and L.O_DMG_HELP or L.O_DMG_NOLOG end },
	{ id = "keys", label = "TAB_KEYS", help = "O_KEY_HELP" },
	{ id = "sync", label = "TAB_SYNC", help = "O_SYNC_HELP" },
	{ id = "colors", label = "H_COLORS" },
	{ id = "dev", label = "OL_SEC_DEV", show = IsDev },
}
-- alte Seiten-Nummern (OpenPage/Select von Meldungen, Testassistent, Testroutine) -> Bereich
O.PAGE_SECTION = { "general", "plates", "sounds", "alerts", "keys", "sync", "display", "group" }

-- Jede Option genau einmal. kind: check | slider | choice | color | sound | edit | button | buttons | keybind | info.
-- label = kurze Beschriftung (OL_*), tip = Erklärung (bisherige lange Texte), adv = unter "Weitere", show = nur wenn wahr.
O.ROWS = {
	-- Allgemein
	{ id = "enabled", sec = "general", kind = "check", key = "enabled", label = "OL_ENABLED", tip = "O_ENABLED" },
	{ id = "activeOnlyTank", sec = "general", kind = "check", key = "activeOnlyTank", label = "OL_ONLYTANK", tip = "O_ONLYTANK" },
	{ id = "activeSolo", sec = "general", kind = "check", key = "activeSolo", label = "OL_SOLO", tip = "O_SOLO" },
	{ id = "autoEnableNameplates", sec = "general", kind = "check", key = "autoEnableNameplates", label = "OL_AUTONP", tip = "O_AUTONP",
		onChange = function(v) if v and not API.InCombatLockdown() then ns:SetCVarSafe("nameplateShowEnemies", "1") end end },
	{ id = "myRole", sec = "general", kind = "choice", key = "myRole", values = { "AUTO", "HEALER", "DAMAGER" }, labelOf = RoleLabel,
		label = "OL_MYROLE", tip = "O_MYROLE" },
	{ id = "preset", sec = "general", kind = "buttons", label = "OL_PRESET", tip = "OT_PRESET", items = {
		{ text = "PRESET_quiet", fn = function() ns:ApplyPreset("quiet") end },
		{ text = "PRESET_standard", fn = function() ns:ApplyPreset("standard") end },
		{ text = "PRESET_loud", fn = function() ns:ApplyPreset("loud") end } } },
	{ id = "minimapShow", sec = "general", kind = "check", key = "minimapShow", label = "OL_MINIMAP", tip = "O_MINIMAP" },
	{ id = "cmdHint", sec = "general", kind = "check", key = "cmdHint", label = "OL_CMDHINT", tip = "O_CMDHINT",
		onChange = function(v) if not v and ns.CmdHint then ns.CmdHint:Hide() end end },
	{ id = "donate", sec = "general", kind = "button", label = "O_DONATE", tip = "OT_DONATE", text = "OL_DONATE_BTN",
		fn = function() ns.Donate.Show() end },
	{ id = "sharedProfile", sec = "general", adv = true, kind = "check", label = "OL_SHARED", tip = "O_SHARED", noDefault = true,
		get = function() return ns:IsSharedProfile() end,
		set = function(v) local dlg = StaticPopup_Show("THREATSENTINEL_RELOAD"); if dlg then dlg.data = v end end },
	{ id = "tauntOverride", sec = "general", adv = true, kind = "edit", key = "tauntOverride", label = "OL_TAUNTNAME", tip = "O_TAUNTNAME",
		onCommit = function() ns:UpdateSpells(); O:RefreshDetected() end },
	{ id = "detected", sec = "general", adv = true, kind = "info", label = "OL_DETECTED", tip = "O_DETECTED",
		value = function() return (ns.tauntSpell or L.NONE) .. " / " .. (ns.aoeSpell or L.NONE) end,
		tipText = function() return string.format(L.O_DETECTED, ns.tauntSpell or L.NONE, ns.aoeSpell or L.NONE) end },
	{ id = "threatMode", sec = "general", adv = true, kind = "choice", key = "threatMode", values = { "AUTO", "DISPLAY" }, show = IsModern,
		labelOf = function(v) return v == "DISPLAY" and L.O_THREATMODE_DISPLAY or L.O_THREATMODE_AUTO end,
		label = "O_THREATMODE", tip = "OT_THREATMODE" },
	{ id = "blizzThreat", sec = "general", adv = true, kind = "check", key = "blizzThreat", show = IsModern,
		label = "OL_BLIZZTHREAT", tip = "O_BLIZZTHREAT", tip2 = "O_BLIZZTHREAT_NOTE" },
	{ id = "threatCheck", sec = "general", adv = true, kind = "button", label = "O_THREATCHECK", tip = "OT_THREATCHECK", text = "OL_CHECK_BTN",
		fn = function() ns.ThreatAccess:Report() end },
	{ id = "diagSend", sec = "general", adv = true, kind = "check", key = "diagSend", label = "OL_DIAG", tip = "O_DIAG" },
	{ id = "diagShow", sec = "general", adv = true, kind = "button", label = "OL_DIAG_SHOW", tip = "O_DIAG_SHOW", text = "OL_SHOW_BTN",
		fn = function() if ns.ShowDiag then ns.ShowDiag() end end },
	{ id = "marketShare", sec = "general", adv = true, kind = "check", key = "marketShare", label = "OL_MARKET", tip = "O_MARKET" },
	-- Entwickler
	{ id = "testCenter", sec = "dev", kind = "button", label = "OL_TESTCENTER", tip = "O_TEST_CENTER", text = "OL_OPEN_BTN", show = IsDev,
		fn = function() O.frame:Hide(); ns.Test:ToggleWindow() end },
	{ id = "dungeonCheck", sec = "dev", kind = "check", key = "dungeonCheck", label = "OL_DUNGEON", tip = "O_DUNGEON", show = IsDev },
	{ id = "dungeonCheckRaid", sec = "dev", kind = "check", key = "dungeonCheckRaid", label = "O_DUNGEON_RAID", tip = "O_DUNGEON_RAID", show = IsDev },
	{ id = "dungeonShots", sec = "dev", kind = "check", key = "dungeonShots", label = "OL_DUNGEON_SHOTS", tip = "O_DUNGEON_SHOTS", show = IsDev },
	{ id = "dungeonLast", sec = "dev", kind = "button", label = "OL_DUNGEON_LAST", tip = "O_DUNGEON_LAST", text = "OL_SHOW_BTN", show = IsDev,
		fn = function() O.frame:Hide(); ns.Log:ShowSummary() end },
	-- Plaketten
	{ id = "heldPlateAlpha", sec = "plates", kind = "slider", key = "heldPlateAlpha", min = 0, max = 100, step = 5, fmt = "%d %%", pct = true,
		label = "OL_HELDALPHA", tip = "O_HELDALPHA" },
	{ id = "heldHealthAlpha", sec = "plates", kind = "slider", key = "heldHealthAlpha", min = 0, max = 100, step = 5, fmt = "%d %%", pct = true,
		label = "OL_HELDHEALTH", tip = "O_HELDHEALTH" },
	{ id = "heldScale", sec = "plates", kind = "slider", key = "heldScale", min = 50, max = 100, step = 5, fmt = "%d %%", pct = true,
		label = "OL_HELDSCALE", tip = "O_HELDSCALE" },
	{ id = "warnThreshold", sec = "plates", kind = "slider", key = "warnThreshold", min = 50, max = 100, step = 5, fmt = "%d %%",
		label = "OL_WARN", tip = "O_WARN" },
	{ id = "warnBlink", sec = "plates", kind = "check", key = "warnBlink", label = "OL_WARNBLINK", tip = "O_WARNBLINK" },
	{ id = "loosePulse", sec = "plates", kind = "check", key = "loosePulse", label = "OL_PULSE", tip = "O_PULSE" },
	{ id = "looseFire", sec = "plates", kind = "check", key = "looseFire", label = "OL_FIRE", tip = "O_FIRE" },
	{ id = "looseScale", sec = "plates", kind = "slider", key = "looseScale", min = 100, max = 150, step = 5, fmt = "%d %%", pct = true,
		label = "OL_SCALE", tip = "O_SCALE" },
	{ id = "showHints", sec = "plates", kind = "check", key = "showHints", label = "O_HINTS", tip = "O_HINTS" },
	{ id = "effectGlow", sec = "plates", kind = "check", key = "effectGlow", label = "OL_GLOW", tip = "O_GLOW" },
	-- Hinweis 18.11. 11:15 (Spieler nie über Testwege): Vorschau der Plaketten/Meldungen für Spieler hier, nicht nur in der Testzentrale.
	-- Aus beim Schliessen der Einstellungen und bei Kampfbeginn (das Fenster schliesst im Kampf) – nie echte Warnungen verdecken.
	{ id = "preview", sec = "plates", kind = "check", label = "OL_PREVIEW", tip = "OT_PREVIEW", noDefault = true,
		get = function() return ns.testMode and true or false end,
		set = function(v) if ns.Test and ns.Test.SetDemo then ns.Test:SetDemo(v); O.previewFromOptions = v end end },
	{ id = "outOfCombatMode", sec = "plates", adv = true, kind = "choice", key = "outOfCombatMode", values = { "normal", "faded" },
		labelOf = function(v) return v == "faded" and L.OOC_FADED or L.OOC_NORMAL end, label = "OL_OOC", tip = "O_OOC" },
	{ id = "borderSize", sec = "plates", adv = true, kind = "slider", key = "borderSize", min = 1, max = 6, step = 1, fmt = "%d",
		label = "O_BORDER", tip = "O_BORDER" },
	{ id = "deficitThreshold", sec = "plates", adv = true, kind = "slider", key = "deficitThreshold", min = 50, max = 100, step = 5, fmt = "%d %%",
		label = "OL_DEFICIT", tip = "O_DEFICIT", tipArg = function() return ns:DeficitText() end },
	{ id = "showSunder", sec = "plates", adv = true, kind = "check", key = "showSunder", label = "OL_SUNDER", tip = "O_SUNDER", show = IsWarrior },
	{ id = "showTankStripe", sec = "plates", adv = true, kind = "check", key = "showTankStripe", label = "OL_STRIPE", tip = "O_STRIPE" },
	{ id = "ignoreCC", sec = "plates", adv = true, kind = "check", key = "ignoreCC", label = "OL_IGNORECC", tip = "O_IGNORECC" },
	{ id = "petsSafe", sec = "plates", adv = true, kind = "check", key = "petsSafe", label = "OL_PETS", tip = "O_PETS" },
	{ id = "effectStrength", sec = "plates", adv = true, kind = "slider", key = "effectStrength", min = 50, max = 200, step = 10, fmt = "%d %%",
		label = "OL_STRENGTH", tip = "O_STRENGTH" },
	-- Farben
	{ id = "colorDD", sec = "colors", kind = "color", key = "colorDD", label = "C_DD", tip = "OT_COLOR" },
	{ id = "colorHealer", sec = "colors", kind = "color", key = "colorHealer", label = "C_HEALER", tip = "OT_COLOR" },
	{ id = "colorWarn", sec = "colors", kind = "color", key = "colorWarn", label = "C_WARN", tip = "OT_COLOR" },
	{ id = "colorRegain", sec = "colors", kind = "color", key = "colorRegain", label = "C_REGAIN", tip = "OT_COLOR" },
	{ id = "colorClaimed", sec = "colors", kind = "color", key = "colorClaimed", label = "C_CLAIMED", tip = "OT_COLOR" },
	-- Töne
	{ id = "sound", sec = "sounds", kind = "check", key = "sound", label = "O_SOUND", tip = "O_SOUND" },
	{ id = "soundDD", sec = "sounds", kind = "sound", key = "soundDD", label = "S_DD", tip = "OT_SOUND" },
	{ id = "soundHealer", sec = "sounds", kind = "sound", key = "soundHealer", label = "S_HEALER", tip = "OT_SOUND" },
	{ id = "soundWarn", sec = "sounds", kind = "sound", key = "soundWarn", label = "OL_S_WARN", tip = "S_WARN" },
	{ id = "soundResist", sec = "sounds", kind = "sound", key = "soundResist", label = "S_RESIST", tip = "OT_SOUND" },
	{ id = "regainSound", sec = "sounds", kind = "check", key = "regainSound", label = "OL_REGAINSOUND", tip = "O_REGAINSOUND" },
	{ id = "soundRegain", sec = "sounds", kind = "sound", key = "soundRegain", label = "S_REGAIN", tip = "OT_SOUND" },
	{ id = "soundEmergency", sec = "sounds", kind = "sound", key = "soundEmergency", label = "S_EMERG", tip = "OT_SOUND" },
	{ id = "soundDDWarn", sec = "sounds", kind = "sound", key = "soundDDWarn", label = "OL_S_DDWARN", tip = "S_DDWARN" },
	{ id = "soundChannel", sec = "sounds", kind = "choice", key = "soundChannel", values = { "Master", "SFX", "Ambience", "Dialog" },
		labelOf = function(v) return v end, label = "O_CHANNEL_SOUND", tip = "OT_CHANNEL_SOUND" },
	-- Meldungen
	{ id = "chatChannel", sec = "alerts", kind = "choice", key = "chatChannel", values = { "TANKS", "BOSS", "GROUP", "SELF", "OFF" },
		labelOf = function(v) return L["CHS_" .. v] end, tipOf = function(v) return L["CH_" .. v] end, label = "O_CHAT", tip = "OT_CHAT" },
	{ id = "announceResist", sec = "alerts", kind = "check", key = "announceResist", label = "O_RESIST", tip = "O_RESIST" },
	{ id = "announceCC", sec = "alerts", kind = "check", key = "announceCC", label = "OL_CC", tip = "O_CC" },
	{ id = "regainText", sec = "alerts", kind = "check", key = "regainText", label = "OL_REGAINTEXT", tip = "O_REGAINTEXT" },
	{ id = "centerSize", sec = "alerts", kind = "slider", key = "centerSize", min = 12, max = 32, step = 1, fmt = "%d",
		label = "OL_CENTERSIZE", tip = "OT_CENTER" },
	{ id = "centerY", sec = "alerts", kind = "slider", key = "centerY", min = -200, max = 400, step = 10, fmt = "%d",
		label = "OL_CENTERY", tip = "O_CENTERY" },
	{ id = "centerTest", sec = "alerts", kind = "button", label = "OL_CENTERTEST", tip = "OT_CENTER", text = "OL_SHOW_BTN",
		fn = function() ns.Alerts:Center(L.O_CENTERTEST, { 1, 0.6, 0.2 }, 2, "test") end },
	{ id = "aoeHint", sec = "alerts", kind = "check", key = "aoeHint", label = "O_AOE", tip = "O_AOE" },
	{ id = "healerRange", sec = "alerts", kind = "check", key = "healerRange", label = "OL_HEALERRANGE", tip = "O_HEALERRANGE" },
	{ id = "emergency", sec = "alerts", kind = "check", key = "emergency", label = "OL_EMERG", tip = "O_EMERG" },
	{ id = "ccMinDuration", sec = "alerts", adv = true, kind = "slider", key = "ccMinDuration", min = 0, max = 5, step = 0.5, fmt = "%.1f",
		label = "OL_CCMIN", tip = "O_CCMIN" },
	{ id = "aoeThreshold", sec = "alerts", adv = true, kind = "slider", key = "aoeThreshold", min = 2, max = 8, step = 1, fmt = "%d",
		label = "OL_AOETHR", tip = "O_AOETHR" },
	{ id = "emergencyHP", sec = "alerts", adv = true, kind = "slider", key = "emergencyHP", min = 10, max = 60, step = 5, fmt = "%d %%",
		label = "OL_EMERGHP", tip = "O_EMERGHP" },
	{ id = "healerHeuristic", sec = "alerts", adv = true, kind = "check", key = "healerHeuristic", label = "OL_HEURISTIC", tip = "O_HEURISTIC" },
	-- Anzeigen
	{ id = "hud", sec = "display", kind = "check", key = "hud", label = "H_HUD", tip = "O_HUD" },
	{ id = "hudHealer", sec = "display", kind = "check", key = "hudHealer", label = "OL_HUD_HEALER", tip = "O_HUD_HEALER" },
	{ id = "meter", sec = "display", kind = "check", key = "meter", label = "H_METER", tip = "O_METER" },
	{ id = "meterOnlyTank", sec = "display", kind = "check", key = "meterOnlyTank", label = "OL_METER_ONLYTANK", tip = "O_METER_ONLYTANK" },
	{ id = "meterOnlyCombat", sec = "display", kind = "check", key = "meterOnlyCombat", label = "OL_METER_ONLYCOMBAT", tip = "O_METER_ONLYCOMBAT" },
	{ id = "ddView", sec = "display", kind = "check", key = "ddView", label = "OL_DD", tip = "O_DD" },
	{ id = "ddSound", sec = "display", kind = "check", key = "ddSound", label = "O_DDSOUND", tip = "O_DDSOUND" },
	{ id = "move", sec = "display", kind = "button", label = "OL_MOVE", tip = "O_MOVE", text = "OL_START_BTN", fn = function() ns.Mover:Start() end },
	{ id = "resetPos", sec = "display", kind = "button", label = "O_RESETPOS", tip = "O_RESETPOS", text = "OL_RESET_BTN",
		fn = function() ns:ResetPositions() end },
	{ id = "hudScale", sec = "display", adv = true, kind = "slider", key = "hudScale", min = 50, max = 250, step = 5, fmt = "%d %%", pct = true,
		set = ScaleSetter("hud"), label = "O_HUDSCALE", tip = "O_HUDSCALE" },
	{ id = "hudMaxRows", sec = "display", adv = true, kind = "slider", key = "hudMaxRows", min = 1, max = 10, step = 1, fmt = "%d",
		label = "OL_HUDROWS", tip = "O_HUDROWS" },
	{ id = "meterRows", sec = "display", adv = true, kind = "slider", key = "meterRows", min = 3, max = 12, step = 1, fmt = "%d",
		label = "OL_METER_ROWS", tip = "O_METER_ROWS" },
	{ id = "meterScale", sec = "display", adv = true, kind = "slider", key = "meterScale", min = 50, max = 250, step = 5, fmt = "%d %%", pct = true,
		set = ScaleSetter("meter"), label = "O_METERSCALE", tip = "O_METERSCALE" },
	{ id = "meterWidth", sec = "display", adv = true, kind = "slider", key = "meterWidth", min = 160, max = 400, step = 10, fmt = "%d",
		label = "O_METERWIDTH", tip = "O_METERWIDTH" },
	{ id = "ddScale", sec = "display", adv = true, kind = "slider", key = "ddScale", min = 50, max = 250, step = 5, fmt = "%d %%", pct = true,
		set = ScaleSetter("dd"), label = "O_DDSCALE", tip = "O_DDSCALE" },
	{ id = "ddWidth", sec = "display", adv = true, kind = "slider", key = "ddWidth", min = 120, max = 400, step = 10, fmt = "%d",
		label = "O_DDWIDTH", tip = "O_DDWIDTH" },
	{ id = "ddWarn", sec = "display", adv = true, kind = "slider", key = "ddWarn", min = 50, max = 100, step = 5, fmt = "%d %%",
		label = "O_DDWARN", tip = "O_DDWARN" },
	-- Gruppe
	{ id = "memberView", sec = "group", kind = "check", key = "memberView", label = "OL_MEMBERVIEW", tip = "O_MEMBERVIEW" },
	{ id = "memberSelfWarn", sec = "group", kind = "check", key = "memberSelfWarn", label = "OL_MEMBERWARN", tip = "O_MEMBERWARN" },
	{ id = "specCheck", sec = "group", kind = "check", key = "specCheck", label = "OL_SPECCHECK", tip = "O_SPECCHECK",
		onChange = function() ns:ClearRoleCache(); O:RefreshRoles() end },
	{ id = "roles", sec = "group", kind = "info", label = "H_ROLES", tip = "H_ROLES",
		value = function() return O:RolesShort() end, tipText = function() ns:ClearRoleCache(); return ns.Specs and ns.Specs:ListText(10) or L.NONE end },
	{ id = "dmgMeter", sec = "group", kind = "check", key = "dmgMeter", label = "OL_DMG", tip = "O_DMG" },
	{ id = "dmgMeterGroupOnly", sec = "group", kind = "check", key = "dmgMeterGroupOnly", label = "OL_DMG_GROUPONLY", tip = "O_DMG_GROUPONLY" },
	{ id = "dmgMeterTank", sec = "group", kind = "check", key = "dmgMeterTank", label = "O_DMG_TANK", tip = "O_DMG_TANK" },
	{ id = "dmgRows", sec = "group", adv = true, kind = "slider", key = "dmgRows", min = 3, max = 12, step = 1, fmt = "%d",
		label = "OL_DMG_ROWS", tip = "O_DMG_ROWS" },
	{ id = "dmgScale", sec = "group", adv = true, kind = "slider", key = "dmgScale", min = 50, max = 250, step = 5, fmt = "%d %%", pct = true,
		set = ScaleSetter("dmg"), label = "O_DMG_SCALE", tip = "O_DMG_SCALE" },
	{ id = "dmgWidth", sec = "group", adv = true, kind = "slider", key = "dmgWidth", min = 160, max = 400, step = 10, fmt = "%d",
		label = "O_DMG_WIDTH", tip = "O_DMG_WIDTH" },
	-- Tasten
	{ id = "keyTaunt", sec = "keys", kind = "keybind", which = "taunt", label = "O_KEY_TAUNT", tip = "O_KEY_HELP", noDefault = true },
	{ id = "keyAoe", sec = "keys", kind = "keybind", which = "aoe", label = "O_KEY_AOE", tip = "O_KEY_HELP", noDefault = true },
	-- Tank-Sync
	{ id = "sync", sec = "sync", kind = "check", key = "sync", label = "O_SYNC", tip = "O_SYNC_HELP" },
	{ id = "ownerGrace", sec = "sync", kind = "slider", key = "ownerGrace", min = 0, max = 6, step = 0.5, fmt = "%.1f",
		label = "OL_GRACE", tip = "O_GRACE" },
	{ id = "syncUsers", sec = "sync", kind = "info", label = "OL_SYNCUSERS", tip = "O_SYNCUSERS",
		value = function() return O:SyncShort() end, tipText = function() return O:SyncText() end },
	{ id = "syncRefresh", sec = "sync", kind = "button", label = "OL_SYNC_REFRESH", tip = "O_SYNCUSERS", text = "O_SYNC_REFRESH",
		fn = function() ns.Sync:Hello(true); O:RefreshSync() end },
}

-- Text (Locale-Schlüssel oder Funktion)
local function T(k) if type(k) == "function" then return k() end return k and (L[k] or k) or "" end
O._T = T

function O:RowById(id)
	for _, r in ipairs(self.ROWS) do if r.id == id then return r end end
end

function O:RowVisible(r)
	if r.show and not r.show() then return false end
	local sec = self:SectionById(r.sec)
	if sec and sec.show and not sec.show() then return false end
	return true
end

function O:SectionById(id)
	for _, s in ipairs(self.SECTIONS) do if s.id == id then return s end end
end

-- Tooltip-Text einer Zeile (Erklärung)
function O:RowTip(r)
	if r.tipText then return r.tipText() end
	local t = T(r.tip)
	if r.tipArg then t = string.format(t, r.tipArg()) end
	if r.tip2 then t = t .. "\n\n" .. T(r.tip2) end
	return t
end

-- Suchtext: Beschriftung, Erklärung, Knopftexte und Bereichsname (klein geschrieben)
function O:RowSearchText(r)
	local parts = { T(r.label), self:RowTip(r) }
	if r.text then parts[#parts + 1] = T(r.text) end
	if r.values then for _, v in ipairs(r.values) do parts[#parts + 1] = r.labelOf(v) or "" end end
	if r.items then for _, it in ipairs(r.items) do parts[#parts + 1] = T(it.text) end end
	local sec = self:SectionById(r.sec)
	if sec then parts[#parts + 1] = T(sec.label) end
	return string.lower(table.concat(parts, " "))
end

------------------------------------------------------------
-- Regler ohne Fenster (Testroutine TU3: Bereich, Raster, Eingabe) – dieselbe Rechnung wie der Regler im Fenster
------------------------------------------------------------
local function SliderWrite(r, v)
	v = math.max(r.min, math.min(r.max, v))
	v = math.floor(v / r.step + 0.5) * r.step
	local stored = r.pct and (v / 100) or v
	if r.set then r.set(stored) else ns.db[r.key] = stored end
	return v
end

local function SliderCommitFn(r, after)
	return function(e)
		local n = tonumber((e:GetText() or ""):gsub(",", "."):match("^%s*(%-?[%d%.]+)"))
		if n then
			SliderWrite(r, n)
			ns:ApplySettings()
			if after then after() end
		end
		e:ClearFocus()
	end
end

local function EditCommitFn(r)
	return function(s)
		local v = strtrim(s:GetText() or "")
		if ns.db[r.key] ~= v then
			ns.db[r.key] = v
			if r.onCommit then r.onCommit(v) end
		end
	end
end

-- O.sliderSpec / O.editSpec wie bisher (TU3-D3/D4), jetzt aus der Liste – ohne dass ein Fenster gebaut sein muss
function O:BuildSpecs()
	self.sliderSpec, self.editSpec = {}, {}
	for _, r in ipairs(self.ROWS) do
		if r.kind == "slider" then
			self.sliderSpec[r.key] = { min = r.min, max = r.max, step = r.step, pct = r.pct, commit = SliderCommitFn(r) }
		elseif r.kind == "edit" then
			self.editSpec[r.key] = { commit = EditCommitFn(r) }
		end
	end
end
O:BuildSpecs()

------------------------------------------------------------
-- Zeilen bauen (erst beim ersten Zeigen)
------------------------------------------------------------
local function ShowTip(owner, title, text)
	if not GameTooltip then return end
	GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
	GameTooltip:SetText(title, 1, 0.82, 0)
	if text and text ~= "" then GameTooltip:AddLine(text, 1, 1, 1, true) end
	GameTooltip:Show()
end
local function HideTip() if GameTooltip then GameTooltip:Hide() end end

local function Button(parent, text, w, h, onClick)
	local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
	b:SetSize(w, h or 22)
	b:SetText(text)
	b:SetScript("OnClick", onClick)
	local fs = b:GetFontString()
	if fs then
		if fs.SetWordWrap then fs:SetWordWrap(false) end
		-- lange Übersetzungen: kleiner schreiben statt abschneiden
		if (fs:GetStringWidth() or 0) > w - 10 and GameFontHighlightSmall then b:SetNormalFontObject(GameFontHighlightSmall) end
	end
	return b
end

-- Schalter: EIN Knopf für an/aus (grünes "An" / graues "Aus")
local function ToggleText(on) return on and ("|cff40ff40" .. L.OL_ON .. "|r") or ("|cffa0a0a0" .. L.OL_OFF .. "|r") end

function O:BuildRow(r)
	local f = CreateFrame("Frame", nil, self.content)
	f:SetSize(self.W - self.CONTENT_X - 14, self.ROW_H - 2)
	f:Hide()
	f:EnableMouse(true)
	local title = T(r.label)
	f:SetScript("OnEnter", function(s) ShowTip(s, title, O:RowTip(r)) end)
	f:SetScript("OnLeave", HideTip)
	local lab = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	lab:SetPoint("LEFT", 0, 0)
	lab:SetWidth(self.LABEL_W)
	lab:SetJustifyH("LEFT")
	if lab.SetWordWrap then lab:SetWordWrap(false) end
	lab:SetText(title)
	-- OPT (c)/(g): eine Zeile ohne Umbruch; zu lange Texte (andere Sprachen) kleiner schreiben, nie abschneiden
	if (lab:GetStringWidth() or 0) > self.LABEL_W and GameFontHighlightSmall then lab:SetFontObject(GameFontHighlightSmall) end
	r.ui = { f = f, label = lab }
	local x = self.LABEL_W + 8
	local refresh
	local function tipOn(ctrl) ctrl:SetScript("OnEnter", function(s) ShowTip(s, title, O:RowTip(r)) end); ctrl:SetScript("OnLeave", HideTip) end
	local kind = r.kind
	if kind == "check" then
		local b = Button(f, "", 80, 22, nil)
		b:SetPoint("LEFT", x, 0)
		local function get() if r.get then return r.get() end return ns.db[r.key] and true or false end
		b:SetScript("OnClick", function()
			local v = not get()
			if r.set then r.set(v) else ns.db[r.key] = v end
			if r.onChange then r.onChange(v) end
			ns:ApplySettings()
			b:SetText(ToggleText(get()))
		end)
		tipOn(b)
		refresh = function() b:SetText(ToggleText(get())) end
		r.ui.ctrl = b
	elseif kind == "slider" then
		local s = CreateFrame("Slider", nil, f, BACKDROP)
		s:SetOrientation("HORIZONTAL")
		s:SetSize(150, 16)
		s:SetPoint("LEFT", x, 0)
		if s.SetBackdrop then
			s:SetBackdrop({ bgFile = "Interface\\Buttons\\UI-SliderBar-Background", edgeFile = "Interface\\Buttons\\UI-SliderBar-Border",
				tile = true, tileSize = 8, edgeSize = 8, insets = { left = 3, right = 3, top = 6, bottom = 6 } })
		end
		s:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
		s:SetMinMaxValues(r.min, r.max)
		s:SetValueStep(r.step)
		if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
		local minus = Button(f, "-", 20, 18, function() s:SetValue(math.max(r.min, s:GetValue() - r.step)) end)
		minus:SetPoint("LEFT", s, "RIGHT", 4, 0)
		local plus = Button(f, "+", 20, 18, function() s:SetValue(math.min(r.max, s:GetValue() + r.step)) end)
		plus:SetPoint("LEFT", minus, "RIGHT", 2, 0)
		local eb = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
		eb:SetSize(46, 18)
		eb:SetPoint("LEFT", plus, "RIGHT", 8, 0)
		eb:SetAutoFocus(false)
		eb:SetJustifyH("CENTER")
		local unit = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		unit:SetPoint("LEFT", eb, "RIGHT", 4, 0)
		unit:SetText(r.fmt:find("%%%%") and "%" or "")
		local numFmt = r.fmt:gsub(" ?%%%%", "")
		local function show(v) if not eb:HasFocus() then eb:SetText(string.format(numFmt, v)) end end
		local busy = false
		s:SetScript("OnValueChanged", function(_, v)
			if busy then return end
			show(SliderWrite(r, v))
			ns:ApplySettings()
		end)
		local commit = SliderCommitFn(r, function() refresh() end)
		eb:SetScript("OnEditFocusGained", function(e) e:HighlightText() end)
		eb:SetScript("OnEnterPressed", commit)
		eb:SetScript("OnEscapePressed", function(e) e:ClearFocus() end)
		eb:SetScript("OnEditFocusLost", function() refresh() end)
		tipOn(s)
		refresh = function()
			local v = ns.db[r.key]
			if type(v) ~= "number" then return end
			if r.pct then v = v * 100 end
			busy = true
			s:SetValue(v)
			busy = false
			show(v)
		end
		r.ui.ctrl, r.ui.edit = s, eb
	elseif kind == "choice" then
		-- Auswahl = Knopfreihe; die gewählte Möglichkeit hervorgehoben
		local n = #r.values
		local total = self.W - self.CONTENT_X - 14 - x - 4
		local bw = math.floor((total - (n - 1) * 3) / n)
		local btns = {}
		for i, v in ipairs(r.values) do
			local b = Button(f, r.labelOf(v), bw, 22, function()
				ns.db[r.key] = v
				ns:ApplySettings()
				refresh()
			end)
			b:SetPoint("LEFT", x + (i - 1) * (bw + 3), 0)
			if r.tipOf then
				b:SetScript("OnEnter", function(s) ShowTip(s, r.labelOf(v), r.tipOf(v)) end)
				b:SetScript("OnLeave", HideTip)
			else
				tipOn(b)
			end
			btns[i] = b
		end
		refresh = function()
			for i, v in ipairs(r.values) do
				local sel = ns.db[r.key] == v
				btns[i]:SetText((sel and "|cffffd100" or "|cffa0a0a0") .. r.labelOf(v) .. "|r")
			end
		end
		r.ui.btns = btns
	elseif kind == "color" then
		local sw = CreateFrame("Button", nil, f, BACKDROP)
		sw:SetSize(36, 18)
		sw:SetPoint("LEFT", x, 0)
		if sw.SetBackdrop then
			sw:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
			sw:SetBackdropBorderColor(1, 1, 1, 0.8)
		end
		refresh = function()
			local c = ns.db[r.key]
			if sw.SetBackdropColor and type(c) == "table" then sw:SetBackdropColor(c[1], c[2], c[3], 1) end
		end
		sw:SetScript("OnClick", function() OpenColor(ns.db[r.key], function() refresh(); ns:ApplySettings() end) end)
		tipOn(sw)
		r.ui.ctrl = sw
	elseif kind == "sound" then
		local b = Button(f, "", 200, 22, nil)
		b:SetPoint("LEFT", x, 0)
		refresh = function()
			b:SetText(ns:SoundLabel(ns.db[r.key]))
			local fs = b:GetFontString()
			if fs then fs:SetWidth(186); if fs.SetWordWrap then fs:SetWordWrap(false) end end
		end
		b:SetScript("OnClick", function() O:OpenSoundPicker(title, r.key, refresh) end)
		tipOn(b)
		local t = Button(f, L.O_PLAY, 54, 22, function() ns.Alerts:Play(ns.db[r.key], "test" .. GetTime(), true) end)
		t:SetPoint("LEFT", b, "RIGHT", 4, 0)
		r.ui.ctrl = b
	elseif kind == "edit" then
		local e = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
		e:SetSize(200, 20)
		e:SetPoint("LEFT", x + 6, 0)
		e:SetAutoFocus(false)
		local commit = EditCommitFn(r)
		e:SetScript("OnEnterPressed", function(s) commit(s); s:ClearFocus() end)
		e:SetScript("OnEscapePressed", function(s) s:SetText(ns.db[r.key] or ""); s:ClearFocus() end)
		e:SetScript("OnEditFocusLost", commit)
		tipOn(e)
		refresh = function() if not e:HasFocus() then e:SetText(ns.db[r.key] or "") end end
		r.ui.ctrl = e
	elseif kind == "button" then
		local b = Button(f, T(r.text), 160, 22, function() r.fn(); O:RefreshAll() end)
		b:SetPoint("LEFT", x, 0)
		tipOn(b)
		r.ui.ctrl = b
	elseif kind == "buttons" then
		local n = #r.items
		local bw = math.floor((self.W - self.CONTENT_X - 14 - x - 4 - (n - 1) * 3) / n)
		for i, it in ipairs(r.items) do
			local b = Button(f, T(it.text), bw, 22, function() it.fn(); O:RefreshAll() end)
			b:SetPoint("LEFT", x + (i - 1) * (bw + 3), 0)
			tipOn(b)
		end
	elseif kind == "keybind" then
		local btn = Button(f, "", 250, 22, nil)
		btn:SetPoint("LEFT", x, 0)
		btn:RegisterForClicks("AnyUp")
		btn:EnableKeyboard(false)
		local which = r.which
		local function update()
			local k = ns.Taunt:GetKey(which)
			btn:SetText(k and ((GetBindingText and GetBindingText(k)) or k) or L.O_KEY_NONE)
		end
		function btn:Done() self.waiting = false; self:EnableKeyboard(false); update() end
		function btn:Bind(key)
			local mods = (IsAltKeyDown() and "ALT-" or "") .. (IsControlKeyDown() and "CTRL-" or "") .. (IsShiftKeyDown() and "SHIFT-" or "")
			local full = mods .. key
			local current = GetBindingAction and GetBindingAction(full) or ""
			self:Done()
			if current ~= "" and current ~= ns.Taunt.BIND[which] then
				-- schon belegt: erst nachfragen
				local name = _G["BINDING_NAME_" .. current] or current
				local text = (GetBindingText and GetBindingText(full)) or full
				local dlg = StaticPopup_Show("THREATSENTINEL_REBIND", text, name)
				if dlg then dlg.data = { which = which, key = full, refresh = update } end
				return
			end
			ns.Taunt:SetKey(which, full)
			update()
		end
		local MOUSE = { MiddleButton = "BUTTON3", Button4 = "BUTTON4", Button5 = "BUTTON5" }
		btn:SetScript("OnClick", function(s, mb)
			if API.InCombatLockdown() then return end
			if s.waiting then
				if MOUSE[mb] then s:Bind(MOUSE[mb]) else s:Done() end
				return
			end
			s.waiting = true
			s:SetText(L.O_KEY_PRESS)
			s:EnableKeyboard(true)
		end)
		btn:SetScript("OnKeyDown", function(s, key)
			if not s.waiting then return end
			if key == "LSHIFT" or key == "RSHIFT" or key == "LCTRL" or key == "RCTRL" or key == "LALT" or key == "RALT" then return end
			if key == "ESCAPE" then s:Done() return end
			if key == "DELETE" or key == "BACKSPACE" then ns.Taunt:SetKey(which, nil); s:Done() return end
			s:Bind(key)
		end)
		btn:SetScript("OnHide", function(s) if s.waiting then s:Done() end end)
		tipOn(btn)
		refresh = update
		r.ui.ctrl = btn
	elseif kind == "info" then
		local v = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		v:SetPoint("LEFT", x, 0)
		v:SetWidth(self.W - self.CONTENT_X - 14 - x - 4)
		v:SetJustifyH("LEFT")
		if v.SetWordWrap then v:SetWordWrap(false) end
		refresh = function() v:SetText(r.value() or "") end
		r.ui.value = v
	end
	r.ui.refresh = refresh
	if refresh then refresh() end
	return f
end

-- kurze Werte für Info-Zeilen (ganze Liste im Tooltip)
function O:SyncText()
	local lines = {}
	for _, u in ipairs(ns.Sync:Users()) do
		lines[#lines + 1] = string.format("%s - %s %s", u.name, L[u.role] or u.role, (u.ver and u.ver ~= "") and ("(v" .. u.ver .. ")") or "")
	end
	return #lines > 0 and table.concat(lines, "\n") or L.NONE
end
function O:SyncShort() return string.format(L.OL_N_PLAYERS, #ns.Sync:Users()) end
function O:RolesShort()
	local t = ns.Specs and ns.Specs:ListText(10) or ""
	local n = 0
	for _ in tostring(t):gmatch("[^\n]+") do n = n + 1 end
	return string.format(L.OL_N_PLAYERS, n)
end

------------------------------------------------------------
-- Hauptfenster
------------------------------------------------------------
function O:Build()
	local f = CreateFrame("Frame", "ThreatSentinelOptions", UIParent, BACKDROP)
	if ns.RegisterUI then ns.RegisterUI(f, "Einstellungen") end   -- Oberflächen-Prüfung (UICheck.lua)
	f:SetSize(self.W, self.H)
	f:SetPoint("CENTER")
	f:SetFrameStrata("DIALOG")
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:EnableMouse(true)
	if f.SetBackdrop then
		f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
		f:SetBackdropColor(0.05, 0.06, 0.08, 0.97)
		f:SetBackdropBorderColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.7)
	end
	f:Hide()
	tinsert(UISpecialFrames, "ThreatSentinelOptions")

	-- Titelleiste
	local title = CreateFrame("Frame", nil, f, BACKDROP)
	title:SetPoint("TOPLEFT", 1, -1)
	title:SetPoint("TOPRIGHT", -1, -1)
	title:SetHeight(34)
	if title.SetBackdrop then
		title:SetBackdrop({ bgFile = WHITE })
		title:SetBackdropColor(0.09, 0.11, 0.15, 1)
	end
	title:EnableMouse(true)
	title:RegisterForDrag("LeftButton")
	title:SetScript("OnDragStart", function() f:StartMoving() end)
	title:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)
	local icon = title:CreateTexture(nil, "ARTWORK")
	icon:SetSize(22, 22)
	icon:SetPoint("LEFT", 10, 0)
	icon:SetTexture("Interface\\Icons\\Ability_Warrior_DefensiveStance")
	local tt = title:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	tt:SetPoint("LEFT", icon, "RIGHT", 8, 0)
	tt:SetText("|cff3fa7ffThreat|rSentinel  |cff808080v" .. ns.version .. "|r")
	local close = CreateFrame("Button", nil, title, "UIPanelCloseButton")
	close:SetPoint("RIGHT", -2, 0)
	close:SetScript("OnClick", function() f:Hide() end)

	-- links: Bereiche
	local nav = CreateFrame("Frame", nil, f, BACKDROP)
	nav:SetPoint("TOPLEFT", 1, -35)
	nav:SetPoint("BOTTOMLEFT", 1, 1)
	nav:SetWidth(self.NAV_W)
	if nav.SetBackdrop then
		nav:SetBackdrop({ bgFile = WHITE })
		nav:SetBackdropColor(0.07, 0.08, 0.11, 1)
	end
	self.content = f
	self.frame = f
	self.navBtns = {}
	for i, sec in ipairs(self.SECTIONS) do
		local tab = CreateFrame("Button", nil, nav)
		tab:SetSize(self.NAV_W - 2, 30)
		tab.bg = tab:CreateTexture(nil, "BACKGROUND")
		tab.bg:SetAllPoints()
		tab.bg:SetTexture(WHITE)
		tab.bg:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3], 0)
		tab.bar = tab:CreateTexture(nil, "ARTWORK")
		tab.bar:SetTexture(WHITE)
		tab.bar:SetPoint("TOPLEFT")
		tab.bar:SetPoint("BOTTOMLEFT")
		tab.bar:SetWidth(3)
		tab.bar:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3], 1)
		tab.bar:Hide()
		local hl = tab:CreateTexture(nil, "HIGHLIGHT")
		hl:SetAllPoints()
		hl:SetTexture(WHITE)
		hl:SetVertexColor(1, 1, 1, 0.06)
		tab.text = tab:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
		tab.text:SetPoint("LEFT", 14, 0)
		tab.text:SetWidth(self.NAV_W - 20)
		tab.text:SetJustifyH("LEFT")
		if tab.text.SetWordWrap then tab.text:SetWordWrap(false) end
		tab.label = T(sec.label)
		tab.text:SetText(tab.label)
		if (tab.text:GetStringWidth() or 0) > self.NAV_W - 20 and GameFontHighlightSmall then tab.text:SetFontObject(GameFontHighlightSmall) end
		tab.secId = sec.id
		tab:SetScript("OnClick", function()
			O.section, O.advanced = sec.id, false
			if O.search then O.search:SetText(""); O.search:ClearFocus() end
			O:Layout()
		end)
		self.navBtns[i] = tab
	end

	-- oben: Suche über alle Bereiche (OPT b), Bereichsname, Hilfe "?" und "Standard"
	local search = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
	search:SetSize(260, 22)
	search:SetPoint("TOPLEFT", self.CONTENT_X + 6, -44)
	search:SetAutoFocus(false)
	search:SetScript("OnTextChanged", function() O:Layout() end)
	search:SetScript("OnEnterPressed", function(s) s:ClearFocus() end)
	search:SetScript("OnEscapePressed", function(s) s:SetText(""); s:ClearFocus() end)
	local ph = search:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	ph:SetPoint("LEFT", 4, 0)
	ph:SetText(L.OL_SEARCH)
	search.placeholder = ph
	self.search = search
	self.searchInfo = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	self.searchInfo:SetPoint("LEFT", search, "RIGHT", 10, 0)
	self.searchInfo:SetWidth(170)
	self.searchInfo:SetJustifyH("LEFT")
	self.help = Button(f, "?", 24, 22, nil)
	self.help:SetPoint("TOPRIGHT", -112, -44)
	self.help:SetScript("OnEnter", function(s)
		local sec = O:SectionById(O.section)
		local text = sec and sec.help and T(sec.help) or ""
		if sec and sec.help2 then text = text .. "\n\n" .. sec.help2() end
		ShowTip(s, sec and T(sec.label) or "", text)
	end)
	self.help:SetScript("OnLeave", HideTip)
	self.defaultBtn = Button(f, L.OL_DEFAULT, 96, 22, function() O:ResetSection(O.section); O:RefreshAll() end)
	self.defaultBtn:SetPoint("TOPRIGHT", -12, -44)
	self.defaultBtn:SetScript("OnEnter", function(s) ShowTip(s, L.OL_DEFAULT, L.OT_DEFAULT) end)
	self.defaultBtn:SetScript("OnLeave", HideTip)
	self.headers = {}

	-- "Weitere" bzw. "Zurück" (Experten-Zeilen des Bereichs)
	self.moreBtn = Button(f, "", 200, 22, function() O.advanced = not O.advanced; O:Layout() end)
	self.moreBtn:Hide()

	f:SetScript("OnShow", function() O:RefreshAll() end)
	-- Vorschau aus den Einstellungen endet mit dem Fenster (auch bei Kampfbeginn: PLAYER_REGEN_DISABLED schliesst es)
	f:SetScript("OnHide", function()
		if O.previewFromOptions and ns.testMode and ns.Test and ns.Test.SetDemo then ns.Test:SetDemo(false) end
		O.previewFromOptions = nil
	end)
	self.section = self.section or "general"
	self.advanced = false
	self:Layout()
end

-- Überschrift für die Suche (je Bereich eine)
function O:Header(i)
	local h = self.headers[i]
	if not h then
		h = self.frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
		h:SetTextColor(ACCENT[1], ACCENT[2], ACCENT[3])
		h:SetWidth(self.W - self.CONTENT_X - 14)
		h:SetJustifyH("LEFT")
		self.headers[i] = h
	end
	return h
end

-- Zeilen eines Bereichs (sichtbar, ohne bzw. nur "Weitere")
function O:SectionRows(secId, adv)
	local list = {}
	for _, r in ipairs(self.ROWS) do
		if r.sec == secId and (r.adv and true or false) == (adv and true or false) and self:RowVisible(r) then list[#list + 1] = r end
	end
	return list
end

function O:Layout()
	if not self.frame then return end
	local q = self.search and string.lower(strtrim(self.search:GetText() or "")) or ""
	if self.search and self.search.placeholder then self.search.placeholder:SetShown(q == "" and not self.search:HasFocus()) end
	for _, r in ipairs(self.ROWS) do if r.ui then r.ui.f:Hide() end end
	for _, h in ipairs(self.headers) do h:Hide() end
	self.moreBtn:Hide()
	local y, lines, shown, hits = self.TOP_Y, 0, {}, {}
	local function place(r)
		if not r.ui then self:BuildRow(r) end
		r.ui.f:ClearAllPoints()
		r.ui.f:SetPoint("TOPLEFT", self.frame, "TOPLEFT", self.CONTENT_X + 6, y)
		r.ui.f:Show()
		if r.ui.refresh then r.ui.refresh() end
		y, lines = y - self.ROW_H, lines + 1
		shown[#shown + 1] = r
	end
	if q == "" then
		local main = self:SectionRows(self.section, false)
		local adv = self:SectionRows(self.section, true)
		for _, r in ipairs(self.advanced and adv or main) do if lines < self.MAX_ROWS - 1 then place(r) end end
		if #adv > 0 then
			self.moreBtn:SetText(self.advanced and L.OL_BACK or string.format(L.OL_MORE, #adv))
			self.moreBtn:ClearAllPoints()
			self.moreBtn:SetPoint("TOPLEFT", self.frame, "TOPLEFT", self.CONTENT_X + 6, y - 4)
			self.moreBtn:Show()
			lines = lines + 1
		end
		self.searchInfo:SetText("")
	else
		local total, nh = 0, 0
		for _, sec in ipairs(self.SECTIONS) do
			local list = {}
			for _, r in ipairs(self.ROWS) do
				if r.sec == sec.id and self:RowVisible(r) and self:RowSearchText(r):find(q, 1, true) then list[#list + 1] = r end
			end
			hits[sec.id] = #list
			total = total + #list
			if #list > 0 and lines < self.MAX_ROWS - 1 then
				nh = nh + 1
				local h = self:Header(nh)
				h:ClearAllPoints()
				h:SetPoint("TOPLEFT", self.frame, "TOPLEFT", self.CONTENT_X + 6, y - 6)
				h:SetText(T(sec.label))
				h:Show()
				y, lines = y - 22, lines + 0.7
				for _, r in ipairs(list) do if lines < self.MAX_ROWS then place(r) end end
			end
		end
		self.searchInfo:SetText(total == 0 and L.OL_NOTHING or string.format(L.OL_HITS, total))
	end
	-- Bereichsknöpfe: gewählter Bereich hervorgehoben, bei Suche die Trefferzahl
	local y2 = -8
	for _, tab in ipairs(self.navBtns) do
		local sec = self:SectionById(tab.secId)
		local vis = not (sec.show and not sec.show())
		tab:SetShown(vis)
		if vis then
			tab:ClearAllPoints()
			tab:SetPoint("TOPLEFT", 1, y2)
			y2 = y2 - 32
			local sel = q == "" and tab.secId == self.section
			tab.bg:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3], sel and 0.18 or 0)
			tab.bar:SetShown(sel)
			if sel then tab.text:SetTextColor(1, 1, 1) else tab.text:SetTextColor(0.75, 0.75, 0.78) end
			local n = hits[tab.secId]
			tab.text:SetText(tab.label .. ((q ~= "" and n and n > 0) and (" (" .. n .. ")") or ""))
		end
	end
	local sec = self:SectionById(self.section)
	self.help:SetShown(q == "" and sec and sec.help ~= nil)
	self.defaultBtn:SetShown(q == "")
	self.shownRows = shown
	self.shownLines = lines
end

-- "Standard"-Knopf: alle Werte dieses Bereichs auf den Standard (Tasten und Profil-Wahl ausgenommen)
function O:ResetSection(secId)
	local n = 0
	for _, r in ipairs(self.ROWS) do
		if r.sec == secId and r.key and not r.noDefault and ns.defaults[r.key] ~= nil then
			local d = ns.defaults[r.key]
			if type(d) == "table" then ns.db[r.key] = CopyTable(d) else ns.db[r.key] = d end
			if r.kind == "slider" and r.set then r.set(ns.db[r.key]) end
			n = n + 1
		end
	end
	ns:ApplySettings()
	return n
end

-- Bereich wählen (id) oder alte Seiten-Nummer (1..8)
function O:Select(i)
	local id = type(i) == "number" and self.PAGE_SECTION[i] or i
	if not self:SectionById(id) then return end
	self.section, self.advanced = id, false
	if self.search then self.search:SetText("") end
	self:Layout()
	self:RefreshAll()
end

-- Optionen öffnen, direkt im passenden Bereich (OPT e) – Bereich als id oder alte Seiten-Nummer
function O:OpenSection(id)
	if API.InCombatLockdown() then ns:Print(L.NOT_IN_COMBAT) return end
	if not self.frame then self:Build() end
	self.frame:Show()
	if ns.UIAvoidBlizzard then ns.UIAvoidBlizzard(self.frame) end
	self:Select(id)
end
O.OpenPage = O.OpenSection

function O:RefreshAll()
	if not self.frame then return end
	for _, r in ipairs(self.ROWS) do
		if r.ui and r.ui.refresh and r.ui.f:IsShown() then r.ui.refresh() end
	end
end

function O:RefreshDetected() self:RefreshAll() end
function O:RefreshSync() self:RefreshAll() end
function O:RefreshRoles() self:RefreshAll() end
function O:RefreshTestButton() end

function O:Toggle()
	if not self.frame then self:Build() end
	if self.frame:IsShown() then
		self.frame:Hide()
	elseif API.InCombatLockdown() then
		ns:Print(L.NOT_IN_COMBAT)
	else
		self.frame:Show()
		-- nicht über offene Blizzard-Fenster (Charakterfenster, Händler …) öffnen
		if ns.UIAvoidBlizzard then ns.UIAvoidBlizzard(self.frame) end
	end
end

------------------------------------------------------------
-- Minimap-Knopf
------------------------------------------------------------
function O:CreateMinimap()
	local b = CreateFrame("Button", "ThreatSentinelMinimapButton", Minimap)
	if ns.RegisterUI then ns.RegisterUI(b, "Minimap-Knopf", "hud") end   -- Oberflächen-Prüfung (UICheck.lua)
	b:SetSize(31, 31)
	b:SetFrameStrata("MEDIUM")
	b:SetFrameLevel(8)
	b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
	local bg = b:CreateTexture(nil, "BACKGROUND")
	bg:SetSize(20, 20)
	bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
	bg:SetPoint("TOPLEFT", 7, -5)
	local icon = b:CreateTexture(nil, "ARTWORK")
	icon:SetSize(17, 17)
	icon:SetTexture("Interface\\Icons\\Ability_Warrior_DefensiveStance")
	icon:SetPoint("TOPLEFT", 7, -6)
	local border = b:CreateTexture(nil, "OVERLAY")
	border:SetSize(53, 53)
	border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
	border:SetPoint("TOPLEFT")

	b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	b:RegisterForDrag("LeftButton")
	b:SetScript("OnClick", function(_, mb)
		if mb == "RightButton" and ns:IsDev() then ns.Test:ToggleWindow() else O:Toggle() end
	end)
	b:SetScript("OnDragStart", function(s)
		s:SetScript("OnUpdate", function()
			local mx, my = Minimap:GetCenter()
			local cx, cy = GetCursorPosition()
			local sc = Minimap:GetEffectiveScale()
			ns.db.minimapAngle = math.deg(math.atan2(cy / sc - my, cx / sc - mx))
			O:PlaceMinimap()
		end)
	end)
	b:SetScript("OnDragStop", function(s) s:SetScript("OnUpdate", nil) end)
	b:SetScript("OnEnter", function(s)
		GameTooltip:SetOwner(s, "ANCHOR_LEFT")
		GameTooltip:AddLine("|cff3fa7ffThreat|rSentinel")
		GameTooltip:AddLine(L.MM_TIP1, 1, 1, 1)
		if ns:IsDev() then GameTooltip:AddLine(L.MM_TIP2, 1, 1, 1) end
		GameTooltip:AddLine(L.MM_TIP3, 0.7, 0.7, 0.7)
		GameTooltip:Show()
	end)
	b:SetScript("OnLeave", function() GameTooltip:Hide() end)
	self.minimap = b
	self:UpdateMinimap()
end

function O:PlaceMinimap()
	local b = self.minimap
	if not b then return end
	local a = math.rad(ns.db.minimapAngle or 220)
	local r = (Minimap:GetWidth() / 2) + 10
	b:ClearAllPoints()
	b:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
end

function O:UpdateMinimap()
	if not self.minimap then return end
	self.minimap:SetShown(ns.db.minimapShow)
	self:PlaceMinimap()
end

------------------------------------------------------------
-- Start
------------------------------------------------------------
StaticPopupDialogs["THREATSENTINEL_REBIND"] = {
	text = L.KEY_REBIND,
	button1 = YES,
	button2 = NO,
	OnAccept = function(self)
		local d = self.data
		if d then
			ns.Taunt:SetKey(d.which, d.key)
			if d.refresh then d.refresh() end
		end
	end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
}

local function PopupEditBox(self)
	return self.editBox or self.EditBox or (self.GetEditBox and self:GetEditBox())
end

local function AcceptCustom(self)
	local eb = PopupEditBox(self)
	local d = self.data
	if not eb or not d then return end
	local text = strtrim(eb:GetText() or "")
	if text == "" then return end
	ns.db[d.key] = ns.CUSTOM_PREFIX .. text
	ns.Alerts:Play(ns.db[d.key], "pick" .. GetTime(), true)
	O:RefreshPicker()
	O:RefreshAll()
end

StaticPopupDialogs["THREATSENTINEL_CUSTOMSOUND"] = {
	text = L.SP_CUSTOM_PROMPT,
	button1 = OKAY,
	button2 = CANCEL,
	hasEditBox = true,
	maxLetters = 200,
	OnShow = function(self)
		local eb = PopupEditBox(self)
		if not eb then return end
		local cur = self.data and ns.db[self.data.key]
		if type(cur) == "string" and cur:sub(1, #ns.CUSTOM_PREFIX) == ns.CUSTOM_PREFIX then
			eb:SetText(cur:sub(#ns.CUSTOM_PREFIX + 1))
		else
			eb:SetText("")
		end
		eb:SetFocus()
		eb:HighlightText()
	end,
	OnAccept = AcceptCustom,
	EditBoxOnEnterPressed = function(eb)
		local parent = eb:GetParent()
		AcceptCustom(parent)
		parent:Hide()
	end,
	EditBoxOnEscapePressed = function(eb) eb:GetParent():Hide() end,
	-- danach die Ton-Auswahl wieder zeigen
	OnHide = function(self)
		if self.data and self.data.reopen and O.picker and O.frame and O.frame:IsShown() then
			O.picker:Show()
			O:RefreshPicker()
		end
	end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
}

StaticPopupDialogs["THREATSENTINEL_RELOAD"] = {
	text = L.O_RELOAD,
	button1 = YES,
	button2 = NO,
	OnAccept = function(self) ns:UseSharedProfile(self.data and true or false) end,
	OnCancel = function() O:RefreshAll() end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
}

-- Hinweis 18.11. 11:15: auch über das Einstellungsfenster des Spiels erreichbar (Seite "ThreatSentinel" mit Knopf)
function O:BuildSettingsPage()
	if self.settingsPanel then return self.settingsPanel end
	local p = CreateFrame("Frame")
	p.name = "ThreatSentinel"
	local title = p:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 16, -16)
	title:SetText("ThreatSentinel " .. tostring(ns.version))
	local btn = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
	btn:SetSize(200, 24)
	btn:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -12)
	btn:SetText(L.OL_SETTINGS_OPEN)
	btn:SetScript("OnClick", function()
		if HideUIPanel and SettingsPanel and SettingsPanel.IsShown and SettingsPanel:IsShown() then HideUIPanel(SettingsPanel) end
		if InterfaceOptionsFrame and InterfaceOptionsFrame.IsShown and InterfaceOptionsFrame:IsShown() and HideUIPanel then HideUIPanel(InterfaceOptionsFrame) end
		O:Toggle()
	end)
	p.openButton = btn
	if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
		local category = Settings.RegisterCanvasLayoutCategory(p, "ThreatSentinel")
		Settings.RegisterAddOnCategory(category)
		self.settingsCategory = category
	elseif InterfaceOptions_AddCategory then
		InterfaceOptions_AddCategory(p)
	end
	self.settingsPanel = p
	return p
end

function O:Login()
	self:CreateMinimap()
	pcall(self.BuildSettingsPage, self)
end

ns:On("PLAYER_REGEN_DISABLED", function()
	if O.frame and O.frame:IsShown() then O.frame:Hide() end
end)
