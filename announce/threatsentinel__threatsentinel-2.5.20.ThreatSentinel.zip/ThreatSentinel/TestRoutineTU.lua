-- ThreatSentinel - TestRoutineTU.lua
-- Umfassende Tests (Bereich U), Anweisung der Prüf-Sitzung vom 13.11.2026 (auftraege/ThreatSentinel/
-- anweisung-tests-umfassend.txt, TU1–TU9) und Befehlsliste (BL, T-BL1–T-BL6).
--   /ts testroutine u      nur dieser Bereich (vollständig mit /ts testroutine: dann zählt auch TU6 alle Bereiche)
--
-- Bedrohung ist ein Kampf-Addon: Fehler treten in Kampflagen auf (Tankwechsel, Spott, geheime Werte), nicht in
-- Einzeltests. Darum laufen hier ganze Lagen durch ALLE betroffenen Teile (T:Tick = Auswertung, Plaketten, Meldungen,
-- Töne, HUD; Aggrometer; Sync) – mit einer Erwartung je Lage und Teil.
--   TU1 Lagen-Katalog          TU2 Abläufe wie ein Spieler     TU3 Standardwerte
--   TU4 Grundregeln mit Zufallsdaten (1000 Fälle, fester Startwert, 10 Portionen à 100, je Bild eine Portion)
--   TU5 echte Daten (Diagnose-Protokoll und Testprotokoll nur lesen; im Spiel prüft Threat.lua dieselben Regeln
--       live und schreibt "GRUNDREGEL VERLETZT …" ins Diagnose-Protokoll)
--   TU6 Regressionen (jeder Befund seit dem 3.11. -> sein bleibender Test; "Regressionen: n von m vorhanden")
--   TU7 Formen des Spiels (Forever/Era/TBC, geheime Werte, deDE/enUS, Skalierung)
--   TU8 Bericht: je Bereich "OK n · FEHLER n · SKIP n" (R:TULines, TestRoutine.lua R:Finish)
--   TU9 offline: dieselbe Routine läuft im nachgebauten Spiel (berichte/ThreatSentinel/offline/)
-- Regeln wie in TestRoutine.lua: keine Blizzard-Funktion wird ersetzt (nur ns.API-Einträge und eigene Felder),
-- Aktionen mit Folgen nur mitgeschrieben, Sandbox nach dem Bereich zurück.

local ADDON, ns = ...
local L = ns.L
local R = ns.Routine
local H = R.H
local C, K, CL = H.C, H.K, H.CL
local Swap, UnswapAll, Scene, WithAPI, NIL, Ret, SECRET = H.Swap, H.UnswapAll, H.Scene, H.WithAPI, H.NIL, H.Ret, H.SECRET
local S, Clean, Ms, Counter, Copy = H.S, H.Clean, H.Ms, H.Counter, H.Copy
local Area = H.Area

local TU_NAMES = {
	TU1 = "Lagen-Katalog", TU2 = "Abläufe wie ein Spieler", TU3 = "Standardwerte", TU4 = "Grundregeln (Zufall)",
	TU5 = "Echte Daten", TU6 = "Regressionen", TU7 = "Formen des Spiels",
}
local TU_ORDER = { "TU1", "TU2", "TU3", "TU4", "TU5", "TU6", "TU7" }
R.TU_SEED = 20261113
R.TU_CASES, R.TU_PORTION = 1000, 20   -- TR-ALLE: Portion klein genug für höchstens R.FRAME_MS (5 ms) je Bild

------------------------------------------------------------
-- Zählung je Bereich (TU8)
------------------------------------------------------------
function R:TUReset()
	self.tu = {}
	for _, k in ipairs(TU_ORDER) do self.tu[k] = { ok = 0, fehler = 0, skip = 0, why = {} } end
	self.tuDefaults, self.tuRandom, self.tuReg = nil, nil, nil
end
R:TUReset()

local function Bump(tu, kind, why)
	local t = R.tu and R.tu[tu]
	if not t then return end
	t[kind] = t[kind] + 1
	if why then t.why[#t.why + 1] = why end
end
-- Prüfung eines TU-Bereichs (Bereich "U" im Bericht)
local function TC(tu, id, name, fn)
	local ok = C(id, "U", tu .. " " .. name, fn)
	Bump(tu, ok and "ok" or "fehler")
	return ok
end
local function TK(tu, id, name, why)
	K(id, "U", tu .. " " .. name, why)
	Bump(tu, "skip", id .. ": " .. why)
end
local function TCL(tu, id, name, how)
	CL(id, "U", tu .. " " .. name, how)
	Bump(tu, "skip", id .. ": im Client prüfen")
end

-- TU8: Zeilen für den Bericht (und Felder im GSTEST1-Bericht)
function R:TULines(extra)
	local out = {}
	local ran = false
	for _, k in ipairs(TU_ORDER) do
		local t = self.tu and self.tu[k]
		if t and (t.ok + t.fehler + t.skip) > 0 then ran = true end
	end
	if not ran then return out end
	out[#out + 1] = "Umfassende Tests (TU8):"
	for _, k in ipairs(TU_ORDER) do
		local t = self.tu[k]
		local line = string.format("%s %s: OK %d · FEHLER %d · SKIP %d", k, TU_NAMES[k], t.ok, t.fehler, t.skip)
		if #t.why > 0 then line = line .. " (" .. table.concat(t.why, "; ") .. ")" end
		out[#out + 1] = "  " .. line
		if extra then extra[k:lower()] = string.format("OK %d · FEHLER %d · SKIP %d", t.ok, t.fehler, t.skip) end
	end
	out[#out + 1] = "  TU9 Offline: dieselbe Routine im nachgebauten Spiel (berichte/ThreatSentinel/offline/)"
	if self.tuReg then
		out[#out + 1] = "  " .. self.tuReg
		if extra then extra.regressionen = self.tuReg end
	end
	if self.tuRandom then
		out[#out + 1] = "  " .. self.tuRandom
		if extra then extra.zufall = self.tuRandom end
	end
	if self.tuDefaults and extra then extra.standardwerte = self.tuDefaults end
	return out
end

------------------------------------------------------------
-- Zufall mit festem Startwert (eigener Generator, math.random bleibt unberührt)
------------------------------------------------------------
local function NewRand(seed)
	local x = seed % 2147483647
	if x <= 0 then x = x + 2147483646 end
	return function(a, b)
		x = (x * 16807) % 2147483647
		if not a then return x / 2147483647 end
		return a + (x % (b - a + 1))
	end
end
R.NewRand = NewRand

------------------------------------------------------------
-- Lage = Kulisse + Schritte; nach jedem Schritt ein ganzer Durchlauf T:Tick (Modus VOLL, wie im Spiel).
-- Ergebnis: Zustände je Schritt, Meldungen (OnLoose/OnWarn/OnRegain), Töne, Mitte-Meldungen, HUD, Aggrometer.
------------------------------------------------------------
local function DbSet(map)
	local saved = {}
	for k, v in pairs(map) do saved[k] = { ns.db[k] }; ns.db[k] = v end
	return function() for k, box in pairs(saved) do ns.db[k] = box[1] end end
end

-- Ergebnis-Text einer Lage: "HELD,LOOSE>HELD | L1 W0 R1 T1 | Meter Anna"
local function RunLage(def)
	local sc = Scene.New(def.mobs or 1)
	if def.setup then def.setup(sc) end
	local errBefore, blockedBefore = ns.errorCount or 0, #(ns.blocked or {})
	local res = Scene.Run(sc, function()
		local restore = DbSet(def.db or {})
		local saveMode = ns.db.threatMode
		ns.db.threatMode = "AUTO"
		ns.simAccess = def.sim or "open"
		local ok, r = pcall(function()
			local loose = Counter(ns.Alerts, "OnLoose")
			local warn = Counter(ns.Alerts, "OnWarn")
			local regain = Counter(ns.Alerts, "OnRegain")
			if def.inside then def.inside(sc) end
			local seq = {}
			local steps = def.steps or { function() end }
			for i, step in ipairs(steps) do
				step(sc, i)
				ns.Threat:Tick()
				local st = {}
				for m = 1, sc.nMobs do st[m] = S(ns.mobs["tsfake" .. m] and ns.mobs["tsfake" .. m].state or "-") end
				seq[#seq + 1] = table.concat(st, ",")
			end
			local meter = ""
			if def.meter then
				local list = ns.Meter:Collect() or {}
				meter = " | Meter " .. S(list[1] and list[1].name)
			end
			local extra = def.extra and (" | " .. def.extra(sc)) or ""
			return string.format("%s | L%d W%d R%d T%d%s%s", table.concat(seq, ">"), loose.n, warn.n, regain.n, sc.plays, meter, extra)
		end)
		ns.db.threatMode = saveMode
		restore()
		if not ok then error(r, 0) end
		return r
	end)
	local errs = (ns.errorCount or 0) - errBefore
	local blocked = #(ns.blocked or {}) - blockedBefore
	if errs > 0 then res = res .. " | Lua-Fehler " .. errs end
	if blocked > 0 then res = res .. " | gesperrt " .. blocked end
	return res
end
R.RunLage = RunLage

-- Kulissen-Hilfen
local function Raid(sc, n)
	sc.raid = n
	sc.group = {}
	sc.alias.raid1 = "player"
	for i = 2, n do
		sc.units["raid" .. i] = { name = "Raider" .. i, player = true, class = (i % 4 == 0) and "PRIEST" or "MAGE",
			role = (i % 4 == 0) and "HEALER" or "DAMAGER", combat = true, power = 0 }
	end
	sc.units.raid2.role, sc.units.raid2.class, sc.units.raid2.power = "TANK", "WARRIOR", 1
end

-- Der Katalog: modern = Forever/Retail-API (geheime Werte möglich), sonst Era/TBC
local function Catalog(modern)
	local thr = 90
	local LAGEN = {
		{ id = "L01", name = "solo, ab Werk (nur in der Gruppe aktiv)",
			setup = function(sc) sc.group = {} end, want = "- | L0 W0 R0 T0" },
		{ id = "L02", name = "solo mit 'auch solo aktiv'",
			setup = function(sc) sc.group = {} end, db = { activeSolo = true }, want = "HELD | L0 W0 R0 T0" },
		{ id = "L03", name = "Gruppe: einer gehalten, DD und Heiler haben Aggro",
			mobs = 3, meter = true,
			setup = function(sc)
				sc.alias.target = "tsfake1"
				Scene.Hold(sc, "tsfake1", "player", { party1 = 40 })
				Scene.Hold(sc, "tsfake2", "party1")
				Scene.Hold(sc, "tsfake3", "party2")
			end,
			want = "HELD,LOOSE,LOOSE | L2 W0 R0 T2 | Meter Anna" },
		{ id = "L04", name = "Schlachtzug 40, 10 Mobs, 3 lose",
			mobs = 10,
			setup = function(sc)
				Raid(sc, 40)
				for i = 1, 10 do Scene.Hold(sc, "tsfake" .. i, "player") end
				Scene.Hold(sc, "tsfake2", "raid5"); Scene.Hold(sc, "tsfake5", "raid8"); Scene.Hold(sc, "tsfake9", "raid13")
				Scene.Hold(sc, "tsfake7", "raid2")      -- zweiter Tank
			end,
			want = "HELD,LOOSE,HELD,HELD,LOOSE,HELD,OTHERTANK,HELD,LOOSE,HELD | L3 W0 R0 T3" },
		{ id = "L05", name = "Tankwechsel: anderer Tank übernimmt und gibt zurück",
			steps = {
				function() end,
				function(sc) Scene.Hold(sc, "tsfake1", "party3") end,
				function(sc) Scene.Hold(sc, "tsfake1", "player") end,
			},
			want = "HELD>OTHERTANK>HELD | L0 W0 R0 T0" },
		{ id = "L06", name = "Spott: DD hat Aggro, Tank holt zurück",
			steps = {
				function(sc) Scene.Hold(sc, "tsfake1", "party1") end,
				function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = 100 }) end,
			},
			want = "LOOSE>WARN | L1 W0 R1 T1" },
		{ id = "L07", name = "Bedrohung zurücksetzen (Verblassen, Totstellen, Unsichtbarkeit) und Mob ohne Bedrohung",
			steps = {
				function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = 50 }) end,
				function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = 95 }) end,   -- bald Aggro
				function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = 0 }) end,    -- verblasst
				function(sc) Scene.Hold(sc, "tsfake1", "party1") end,                    -- DD hat Aggro
				function(sc) Scene.Hold(sc, "tsfake1", "player") end,                    -- DD totgestellt -> zum Tank
				function(sc) sc.threat.tsfake1 = {}; sc.alias.tsfake1target = nil end,   -- Mob setzt zurück
			},
			want = "HELD>WARN>HELD>LOOSE>HELD>IDLE | L1 W1 R1 T1" },
		{ id = "L08", name = "mehrere Ziele: gehalten, bald Aggro, lose, anderer Tank, Begleiter",
			mobs = 5,
			setup = function(sc)
				sc.units.pet = { name = "Wolf" }
				Scene.Hold(sc, "tsfake2", "player", { party1 = thr + 5 })
				Scene.Hold(sc, "tsfake3", "party2")
				Scene.Hold(sc, "tsfake4", "party3")
				Scene.Hold(sc, "tsfake5", "pet")
			end,
			db = { petsSafe = true },
			want = "HELD,WARN,LOOSE,OTHERTANK,PETHELD | L1 W0 R0 T1" },
		{ id = "L09", name = "Begleiter hält Mob, 'Begleiter sicher' aus",
			setup = function(sc) sc.units.pet = { name = "Wolf" }; Scene.Hold(sc, "tsfake1", "pet") end,
			db = { petsSafe = false },
			want = "LOOSE | L1 W0 R0 T1" },
		{ id = "L10", name = "Ziel wechselt schnell (3x DD, 3x zurück)",
			steps = (function()
				local t = {}
				for i = 1, 6 do
					t[i] = function(sc) Scene.Hold(sc, "tsfake1", (i % 2 == 1) and "party1" or "player") end
				end
				return t
			end)(),
			want = "LOOSE>HELD>LOOSE>HELD>LOOSE>HELD | L3 W0 R3 T3" },
		{ id = "L11", name = "Grenzen: 89 %, Warnschwelle 90 %, Nahkampf 109 % (unter 110), dann Aggro",
			steps = {
				function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = 89 }) end,
				function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = 90 }) end,
				function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = 109 }) end,
				function(sc) Scene.Hold(sc, "tsfake1", "party1", { player = 91 }) end,
			},
			db = { warnThreshold = 90 },
			want = "HELD>WARN>WARN>LOOSE | L1 W1 R0 T1" },
		{ id = "L12", name = "Mitspieler mit alter Version (Sync ohne Version / ohne Abklingzeit): Spott wird erkannt",
			setup = function(sc) Scene.Hold(sc, "tsfake1", "party1") end,
			inside = function(sc)
				ns.Sync:Handle("Grimbar", "H:TANK")                                   -- Version 1: ohne Version
				ns.Sync:Handle("Grimbar", "T:" .. sc.units.tsfake1.guid)              -- ohne Abklingzeit
			end,
			db = { sync = true },
			extra = function(sc)
				local m = ns.mobs.tsfake1
				local r = ns.syncRoles.Grimbar
				return "übernommen " .. S(m.claimedBy) .. ", Rolle " .. S(r and r.role)
			end,
			want = "LOOSE | L0 W0 R0 T0 | übernommen Grimbar, Rolle TANK" },
	}
	if modern then
		LAGEN[#LAGEN + 1] = { id = "L13", name = "Forever: Bedrohung im Kampf geheim -> Modus ANZEIGE, keine eigene Entscheidung",
			setup = function(sc) sc.secret = true; Scene.Hold(sc, "tsfake1", "party1") end,
			extra = function() return "Modus " .. ns:ThreatMode() end,
			want = "IDLE | L0 W0 R0 T0 | Modus DISPLAY" }
		LAGEN[#LAGEN + 1] = { id = "L14", name = "keine Bedrohungs-Schnittstelle (moderne API): ANZEIGE statt eigener Rechnung",
			setup = function(sc) Scene.Hold(sc, "tsfake1", "party1"); sc.noThreatApi = true end,
			extra = function() return "Modus " .. ns:ThreatMode() end,
			want = "IDLE | L0 W0 R0 T0 | Modus DISPLAY" }
	else
		LAGEN[#LAGEN + 1] = { id = "L14", name = "keine Bedrohungs-Schnittstelle (alte API): Ersatz über das Ziel des Mobs",
			setup = function(sc) Scene.Hold(sc, "tsfake1", "party1"); sc.noThreatApi = true end,
			extra = function() return "Modus " .. ns:ThreatMode() end,
			want = "LOOSE | L1 W0 R0 T1 | Modus FULL" }
	end
	return LAGEN
end
R.TUCatalog = Catalog

-- Lage ausführen (sc.noThreatApi: die Kulisse liefert keine Bedrohungs-Einträge, siehe unten)
local function RunOne(def) return RunLage(def) end

-- Scene.Map kennt noThreatApi nicht: Einträge nach dem Aufbau entfernen
do
	local origMap = Scene.Map
	Scene.Map = function(sc)
		local map = origMap(sc)
		if sc.noThreatApi then
			map.UnitDetailedThreatSituation = NIL
			map.UnitThreatSituation = NIL
		end
		return map
	end
end

local function CatalogCheck(tu, prefix, modern, label)
	local bad, n = {}, 0
	for _, def in ipairs(Catalog(modern)) do
		n = n + 1
		local ok, got = pcall(RunOne, def)
		got = ok and got or ("Lua: " .. tostring(got))
		if got ~= def.want then bad[#bad + 1] = def.id .. " " .. def.name .. ": ist '" .. got .. "', soll '" .. def.want .. "'" end
	end
	return #bad == 0, (#bad == 0) and (n .. " Lagen wie erwartet" .. (label and (" (" .. label .. ")") or "")) or Clean(table.concat(bad, " || ")),
		n .. " Lagen, jede wie in der Tabelle"
end

------------------------------------------------------------
-- TU1 Lagen-Katalog (jede Lage ein eigener Fall, damit der Bericht die Lage nennt)
------------------------------------------------------------
local function TU1()
	for _, def in ipairs(Catalog(ns.isModern)) do
		TC("TU1", "TU1-" .. def.id, def.name, function()
			local got = RunOne(def)
			return got == def.want, Clean(got), Clean(def.want)
		end)
	end
	TC("TU1", "TU1-L04t", "Schlachtzug 40 mit 40 Mobs: ein Durchlauf < 8 ms", function()
		local sc = Scene.New(40)
		Raid(sc, 40)
		for i = 1, 40, 3 do Scene.Hold(sc, "tsfake" .. i, "raid" .. (3 + i % 30)) end
		local v, n, later, wait = Scene.Run(sc, function()
			ns.simAccess = "open"
			ns.Threat:Tick()
			ns.Threat.maxWait = 0
			local ms = H.Time(3, function() ns.Threat:Tick() end)   -- 3 statt 10 Wiederholungen: kürzeres Bild (NP-TS16-1, leistung.md)
			return ms, ns.Threat.lastEvaluated, ns.Threat.lastDeferred, ns.Threat.maxWait
		end)
		return v < 8, string.format("%.2f ms (bewertet %s, später %s; Stand höchstens %s Durchläufe alt = %.2f s)", v, S(n), S(later),
			S(wait), (tonumber(wait) or 0) * ns.Threat.TICK), "< 8 ms"
	end)
	TC("TU1", "TU1-L04b", "Schlachtzug 40 mit 40 Mobs: Zeitbudget je Durchlauf, jeder Mob kommt der Reihe nach dran", function()
		local sc = Scene.New(40)
		Raid(sc, 40)
		local T = ns.Threat
		local got = Scene.Run(sc, function()
			ns.simAccess = "open"
			local clock = 0
			Swap(T, "Clock", function() clock = clock + 1; return clock end)   -- jede Zeitabfrage = 1 ms
			local per, ticks, seenTwice = {}, 0, false
			local evals = {}
			for k = 1, 10 do
				T:Tick()
				ticks = k
				per[#per + 1] = S(T.lastEvaluated)
				local all, twice = true, false
				for unit, m in pairs(ns.mobs) do
					if m.evalNr == T.tickNr then evals[unit] = (evals[unit] or 0) + 1 end
					if not m.evalNr then all = false end
					if (evals[unit] or 0) > 1 then twice = true end
				end
				-- Reihenfolge: kein Mob ein zweites Mal, solange ein anderer noch nie dran war
				if twice and not all then seenTwice = true end
				if all then break end
			end
			UnswapAll()
			local nMobs = 0
			for _ in pairs(ns.mobs) do nMobs = nMobs + 1 end
			return string.format("Budget %s ms, mind. %s · je Durchlauf %s · alle %d nach %d Durchläufen · keiner doppelt, solange einer fehlt %s · Stand höchstens %s Durchläufe alt (%.2f s)",
				S(T.BUDGET_MS), S(T.MIN_EVAL), table.concat(per, "/"), nMobs, ticks, S(not seenTwice), S(T.lastWait), (T.lastWait or 0) * T.TICK)
		end)
		local want = "Budget 3 ms, mind. 4 · je Durchlauf 6/6/6/6/6/6/6 · alle 40 nach 7 Durchläufen · keiner doppelt, solange einer fehlt true · Stand höchstens 6 Durchläufe alt (1.50 s)"
		return got == want, got, want
	end)
end

------------------------------------------------------------
-- TU2 Abläufe wie ein Spieler
------------------------------------------------------------
local function Flow(name, fn)
	local real0, err0, blk0 = R.realCalls or 0, ns.errorCount or 0, #(ns.blocked or {})
	local ok, a, b, c = pcall(fn)
	local real, errs, blk = (R.realCalls or 0) - real0, (ns.errorCount or 0) - err0, #(ns.blocked or {}) - blk0
	if not ok then return false, "Lua: " .. Clean(a), "kein Fehler" end
	local tail = string.format(" · echt %d, Fehler %d, gesperrt %d", real, errs, blk)
	if real > 0 or errs > 0 or blk > 0 then return false, S(b) .. tail, S(c) .. " · echt 0, Fehler 0, gesperrt 0" end
	return a, S(b) .. tail, S(c) .. " · echt 0, Fehler 0, gesperrt 0"
end

local function TU2()
	TC("TU2", "TU2-A1", "Kampf beginnt, während die Anzeigen verschoben werden", function()
		return Flow("A1", function()
			local MV = ns.Mover
			local was = ns.moveMode
			if not was then MV:Toggle() end
			local during = ns.moveMode
			-- das Spiel meldet den Kampfbeginn (alle Empfänger von PLAYER_REGEN_DISABLED wie im Spiel)
			MV:Stop()
			local after = ns.moveMode
			if was then MV:Toggle() end
			local got = "verschieben " .. S(during) .. " -> Kampf -> " .. S(after)
			return during == true and after == false, got, "verschieben true -> Kampf -> false"
		end)
	end)
	TC("TU2", "TU2-A2", "/reload mitten im Kampf: kein VOLL ohne Kampfbeginn, keine Meldung, kein Plakettenzugriff", function()
		return Flow("A2", function()
			local TA = ns.ThreatAccess
			local sc = Scene.New(2)
			Scene.Hold(sc, "tsfake1", "party1")
			local saveModern = ns.isModern
			ns.isModern = true
			local ok, res = pcall(Scene.Run, sc, function()
				ns.threatAccess, ns.simAccess = "unknown", nil
				TA.inFight, TA.openSeen, TA.secretSeen, TA.openVotes, TA.checked = false, false, false, 0, false
				local loose = Counter(ns.Alerts, "OnLoose")
				ns.Threat:Tick(); ns.Threat:Tick()
				return string.format("%s/%s, Meldungen %d", S(ns.threatAccess), ns:ThreatMode(), loose.n)
			end)
			ns.isModern = saveModern
			if not ok then error(res, 0) end
			return res == "unknown/DISPLAY, Meldungen 0", res, "unknown/DISPLAY, Meldungen 0"
		end)
	end)
	TC("TU2", "TU2-A3", "Gruppe verlassen mitten im Kampf: keine neuen Meldungen, kein Fehler", function()
		return Flow("A3", function()
			local sc = Scene.New(2)
			Scene.Hold(sc, "tsfake1", "party1")
			Scene.Hold(sc, "tsfake2", "party2")
			local res = Scene.Run(sc, function()
				ns.simAccess = "open"
				local loose = Counter(ns.Alerts, "OnLoose")
				ns.Threat:Tick()
				local a = loose.n
				-- Gruppe weg: die Mitspieler gibt es nicht mehr (die Kulisse antwortet wie das Spiel)
				local gone = function(u) return u == "player" or (type(u) == "string" and u:find("^tsfake")) and true or false end
				local b = WithAPI({ IsInGroup = Ret(false), GetNumSubgroupMembers = Ret(0), GetNumGroupMembers = Ret(0),
					UnitExists = function(u) return gone(u) end }, function()
					ns:UpdateGroup()
					ns.Threat:Tick(); ns.Threat:Tick()
					return loose.n
				end)
				return string.format("Meldungen vorher %d, danach %d, Gruppe %d", a, b, #ns.groupUnits)
			end)
			return res == "Meldungen vorher 2, danach 2, Gruppe 1", res, "Meldungen vorher 2, danach 2, Gruppe 1"
		end)
	end)
	TC("TU2", "TU2-A4", "Warnton: über der Schwelle, darunter, wieder darüber – kein Dauerton", function()
		return Flow("A4", function()
			local steps = {}
			local pcts = { 50, 95, 95, 95, 50, 50, 95, 95 }
			for i, p in ipairs(pcts) do steps[i] = function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = p }) end end
			local got = RunLage({ steps = steps, db = { soundWarn = "ts_regain", warnThreshold = 90 } })
			local want = "HELD>WARN>WARN>WARN>HELD>HELD>WARN>WARN | L0 W2 R0 T2"
			return got == want, got, want
		end)
	end)
	TC("TU2", "TU2-A5", "Spott, Mob bleibt lose (Spott verfehlt), dann geholt: genau eine Meldung, ein Zurück", function()
		return Flow("A5", function()
			local steps = {
				function(sc) Scene.Hold(sc, "tsfake1", "party2") end,
				function(sc) Scene.Hold(sc, "tsfake1", "party2") end,     -- Spott verfehlt, Heiler hat weiter Aggro
				function(sc) Scene.Hold(sc, "tsfake1", "party2") end,
				function(sc) Scene.Hold(sc, "tsfake1", "player") end,
			}
			local got = RunLage({ steps = steps })
			local want = "LOOSE>LOOSE>LOOSE>HELD | L1 W0 R1 T1"
			return got == want, got, want
		end)
	end)
end

------------------------------------------------------------
-- TU3 Standardwerte
------------------------------------------------------------
local function DefaultsList()
	local keys = {}
	for k in pairs(ns.defaults) do keys[#keys + 1] = k end
	table.sort(keys)
	local parts = {}
	for _, k in ipairs(keys) do
		local v = ns.defaults[k]
		if type(v) == "table" then
			local n = 0
			for _ in pairs(v) do n = n + 1 end
			parts[#parts + 1] = k .. "={" .. n .. "}"
		else
			parts[#parts + 1] = k .. "=" .. tostring(v)
		end
	end
	return parts
end

local function EnsureOptions()
	local O = ns.Options
	if not O.sliderSpec and O.Build and not O.frame then pcall(O.Build, O) end
	return O
end

local function TU3()
	TC("TU3", "TU3-D1", "Neuinstallation: jedes Feld hat seinen Standard (Liste im Bericht)", function()
		local fresh = {}
		ns._MergeDefaults(fresh, ns.defaults)
		local d = H.Diff(fresh, ns.defaults, "db")
		local parts = DefaultsList()
		R.tuDefaults = table.concat(parts, ", ")
		return d == nil, #parts .. " Felder mit Standard" .. (d and (", abweichend " .. d) or ""), "alle Felder = Standard"
	end)
	-- Befund 18.11. (TU3-D2 43,4 ms in einem Bild): in Teilen zu R.TU3_CHUNK Feldern, dazwischen darf abgegeben werden;
	-- TU3-D2 selbst fasst zusammen (alle Felder geprüft, keine Abweichung)
	local d2keys, d2bad, d2n = {}, {}, 0
	for k in pairs(ns.defaults) do d2keys[#d2keys + 1] = k end
	table.sort(d2keys)
	local d2parts = math.ceil(#d2keys / R.TU3_CHUNK)
	for part = 1, d2parts do
		local a, b = (part - 1) * R.TU3_CHUNK + 1, math.min(#d2keys, part * R.TU3_CHUNK)
		TC("TU3", "TU3-D2-" .. part, string.format("Leeres oder falsches Feld -> Standard, Teil %d von %d", part, d2parts), function()
			local bad = {}
			for x = a, b do
				local k = d2keys[x]
				local v = ns.defaults[k]
				for _, broken in ipairs({ "nil", "typ" }) do
					local t = Copy(ns.defaults)
					if broken == "nil" then t[k] = nil else t[k] = (type(v) == "string") and 5 or "kaputt" end
					ns._MergeDefaults(t, ns.defaults)
					if H.Diff(t[k], v, k) then bad[#bad + 1] = k .. "(" .. broken .. ")" end
				end
				d2n = d2n + 1
			end
			for _, x in ipairs(bad) do d2bad[#d2bad + 1] = x end
			return #bad == 0, #bad == 0 and ((b - a + 1) .. " Felder") or table.concat(bad, ", "), "jedes Feld leer/falsch -> Standard"
		end)
	end
	TC("TU3", "TU3-D2", "Leeres oder falsches Feld -> Standard (was der Spieler meint)", function()
		return #d2bad == 0 and d2n == #d2keys, #d2bad == 0 and (d2n .. " von " .. #d2keys .. " Feldern in " .. d2parts .. " Teilen")
			or table.concat(d2bad, ", "), "jedes Feld leer/falsch -> Standard"
	end)
	TC("TU3", "TU3-D3", "Regler: Standardwert liegt im Bereich und auf dem Raster", function()
		local O = EnsureOptions()
		local spec = O.sliderSpec
		if not spec then return false, "keine Regler gefunden", "Regler der Einstellungen" end
		local bad, n = {}, 0
		for key, sp in pairs(spec) do
			n = n + 1
			local v = ns.defaults[key]
			if type(v) ~= "number" then bad[#bad + 1] = key .. " ohne Zahl"
			else
				if sp.pct then v = v * 100 end
				local onGrid = math.abs((v - sp.min) / sp.step - math.floor((v - sp.min) / sp.step + 0.5)) < 1e-6
				if v < sp.min - 1e-6 or v > sp.max + 1e-6 or not onGrid then
					bad[#bad + 1] = string.format("%s=%s (%s..%s/%s)", key, S(v), S(sp.min), S(sp.max), S(sp.step))
				end
			end
		end
		return #bad == 0 and n > 0, n .. " Regler" .. (#bad > 0 and (": " .. table.concat(bad, ", ")) or " im Bereich"), "alle Regler im Bereich"
	end)
	TC("TU3", "TU3-D4", "Eingabefeld leer oder Unsinn: Wert bleibt, nichts kaputt", function()
		local O = EnsureOptions()
		local spec = O.sliderSpec or {}
		local bad, n = {}, 0
		local fake = function(text) return { GetText = function() return text end, ClearFocus = function() end } end
		for key, sp in pairs(spec) do
			if sp.commit and ns.db[key] ~= nil then
				n = n + 1
				local before = ns.db[key]
				for _, input in ipairs({ "", "   ", "abc", "%s" }) do
					local ok = pcall(sp.commit, fake(input))
					if not ok or ns.db[key] ~= before then bad[#bad + 1] = key .. " '" .. input .. "'" end
					ns.db[key] = before
				end
			end
		end
		-- Textfeld Spott-Name: leer = automatisch (Klassen-Spott)
		local e = O.editSpec and O.editSpec.tauntOverride
		local save = ns.db.tauntOverride
		if e then
			Swap(ns, "UpdateSpells", function() end)
			Swap(O, "RefreshDetected", function() end)
			pcall(e.commit, fake("   "))
			if ns.db.tauntOverride ~= "" then bad[#bad + 1] = "tauntOverride '   ' -> '" .. S(ns.db.tauntOverride) .. "'" end
			UnswapAll()
		end
		ns.db.tauntOverride = save
		return #bad == 0 and n > 0, n .. " Regler-Felder" .. (#bad > 0 and (": " .. table.concat(bad, ", ")) or " unverändert, Spott-Name leer = automatisch"),
			"leer/Unsinn ändert nichts"
	end)
	TC("TU3", "TU3-D5", "Ab Werk in der Gruppe: Aggroverlust mit Ton, Vorwarnung ohne Ton, Sync an", function()
		local fresh = {}
		ns._MergeDefaults(fresh, ns.defaults)
		local saveDb = ns.db
		ns.db = fresh
		local ok, got = pcall(RunLage, { mobs = 2, setup = function(sc)
			Scene.Hold(sc, "tsfake1", "party1")
			Scene.Hold(sc, "tsfake2", "player", { party2 = 95 })
		end })
		local f = fresh
		ns.db = saveDb
		if not ok then error(got, 0) end
		got = got .. string.format(" | Sync %s, Ton %s, Aggro-Ton %s, Vorwarn-Ton %s", S(f.sync), S(f.sound),
			S(f.soundDD ~= "none" and f.soundHealer ~= "none"), S(f.soundWarn))
		local want = "LOOSE,WARN | L1 W0 R0 T1 | Sync true, Ton true, Aggro-Ton true, Vorwarn-Ton none"
		return got == want, got, want
	end)
end

------------------------------------------------------------
-- TU4 Grundregeln mit Zufallsdaten
------------------------------------------------------------
-- Was das Addon nach den Regeln tun MUSS (unabhängig vom Code berechnet)
local function Oracle(c)
	if c.dead then return "IDLE" end
	if c.secret then return "IDLE" end
	if not c.holder then return "IDLE" end
	if c.holder == "player" then
		local maxOther = 0
		for u, p in pairs(c.others) do
			local safe = (u == "party3") or (u == "pet" and c.petsSafe)
			if not safe and p > maxOther then maxOther = p end
		end
		return maxOther >= c.thr and "WARN" or "HELD"
	end
	if c.holder == "party3" then return "OTHERTANK" end
	if c.holder == "pet" then return c.petsSafe and "PETHELD" or "LOOSE" end
	return "LOOSE"
end
R.TUOracle = Oracle

local HOLDERS = { false, "player", "player", "player", "party1", "party2", "party3", "pet" }
local OTHERS = { "party1", "party2", "party3", "pet" }

local function NewCase(rnd, k)
	local c = { k = k, holder = HOLDERS[rnd(1, #HOLDERS)] or nil, others = {}, petsSafe = rnd(0, 1) == 1,
		dead = rnd(1, 20) == 1, thr = 50 + 5 * rnd(0, 10), secret = ns.isModern and rnd(1, 10) == 1 or false }
	for _, u in ipairs(OTHERS) do
		if u ~= c.holder and rnd(1, 3) > 1 then c.others[u] = rnd(0, 109) end
	end
	-- zweite Auswertung: neue Werte (Überschreiten der Schwelle)
	c.others2 = {}
	for u, p in pairs(c.others) do c.others2[u] = math.max(0, math.min(109, p + rnd(-30, 30))) end
	return c
end

local function CaseText(c)
	local o = {}
	for _, u in ipairs(OTHERS) do if c.others[u] then o[#o + 1] = u .. " " .. c.others[u] .. ">" .. c.others2[u] end end
	return string.format("Fall %d: Halter %s, %s, Schwelle %d, Begleiter sicher %s, tot %s, geheim %s", c.k, S(c.holder),
		#o > 0 and table.concat(o, " ") or "keine anderen", c.thr, S(c.petsSafe), S(c.dead), S(c.secret))
end

-- eine Portion Fälle in EINER Kulisse; liefert Verletzungen und Zeit
local function Portion(rnd, from, to)
	local bad = {}
	local sc = Scene.New(1)
	sc.units.pet = { name = "Wolf" }
	local t0 = Ms()
	Scene.Run(sc, function()
		local saveThr, savePets, saveMode = ns.db.warnThreshold, ns.db.petsSafe, ns.db.threatMode
		local saveWarned = ns.DD and ns.DD.warned
		ns.db.threatMode = "AUTO"
		local loose = Counter(ns.Alerts, "OnLoose", false)
		local warn = Counter(ns.Alerts, "OnWarn", false)
		local ok, err = pcall(function()
			for k = from, to do
				local c = NewCase(rnd, k)
				ns.db.warnThreshold, ns.db.petsSafe = c.thr, c.petsSafe
				ns.threatAccess, ns.simAccess = "open", "open"
				sc.secret, sc.units.tsfake1.dead = c.secret, c.dead
				Scene.Hold(sc, "tsfake1", c.holder or nil, c.others)
				wipe(ns.owners)
				local m = { unit = "tsfake1" }
				ns.mobs.tsfake1 = m
				loose.n, warn.n = 0, 0
				local errBefore = ns.errorCount or 0
				local okE, e = pcall(ns.Threat.Evaluate, ns.Threat, "tsfake1", m)
				local want = Oracle(c)
				local function fail(why) bad[#bad + 1] = CaseText(c) .. " -> " .. why end
				if not okE then fail("Lua: " .. tostring(e))
				elseif m.state ~= want then fail("ist " .. S(m.state) .. ", soll " .. want)
				elseif (want == "LOOSE") ~= (loose.n == 1) then fail("Meldungen " .. loose.n .. " bei " .. want)
				elseif type(m.maxOther) == "number" and m.maxOther < 0 then fail("Wert < 0")
				elseif ns.Threat:RuleViolation(m) then fail("Grundregel " .. S(ns.Threat:RuleViolation(m)))
				elseif (ns.errorCount or 0) ~= errBefore then fail("Fehlerzähler")
				else
					-- zweite Auswertung: Warnung GENAU beim Überschreiten der Schwelle
					if c.holder == "player" and not c.dead and not c.secret then
						Scene.Hold(sc, "tsfake1", "player", c.others2)
						local c2 = { holder = "player", others = c.others2, petsSafe = c.petsSafe, thr = c.thr }
						local want2 = Oracle(c2)
						warn.n = 0
						local okE2, e2 = pcall(ns.Threat.Evaluate, ns.Threat, "tsfake1", m)
						local crossed = (want == "HELD" and want2 == "WARN") and 1 or 0
						if not okE2 then fail("Lua (2.): " .. tostring(e2))
						elseif m.state ~= want2 then fail("2. ist " .. S(m.state) .. ", soll " .. want2)
						elseif warn.n ~= crossed then fail("Warnungen " .. warn.n .. ", soll " .. crossed)
						end
					end
					-- DD-Ansicht mit denselben Zahlen (auch geheim): nie ein Lua-Fehler
					local D = ns.DD
					if D and D.f and D.ShowSecret then
						local p = c.others.party1 or 0
						local okD, eD = pcall(WithAPI, {}, function()
							if c.secret then D:ShowSecret(p, SECRET, SECRET) else D:ShowSecret(p, (p >= 100) and 3 or 0, p >= 100) end
						end)
						if not okD then fail("DD-Ansicht: " .. tostring(eD)) end
					end
				end
				if ns.isModern and c.secret then ns.threatAccess = "open" end
			end
		end)
		ns.db.warnThreshold, ns.db.petsSafe, ns.db.threatMode = saveThr, savePets, saveMode
		if ns.DD then ns.DD.warned = saveWarned; if ns.DD.f then ns.DD.f:Hide() end end
		if not ok then bad[#bad + 1] = "Portion " .. from .. "–" .. to .. ": Lua " .. tostring(err) end
	end)
	return bad, Ms() - t0
end
R.TUPortion = Portion

-- Fortsetzung: je Aufruf (= je Bild) eine Portion; danach die Auswertung
local function TU4Continuation()
	local rnd = NewRand(R.TU_SEED)
	local k, bad, worst, portions = 1, {}, 0, 0
	local blk0, real0 = #(ns.blocked or {}), R.realCalls or 0
	return function()
		if k <= R.TU_CASES then
			local to = math.min(R.TU_CASES, k + R.TU_PORTION - 1)
			local b, ms = Portion(rnd, k, to)
			for _, x in ipairs(b) do if #bad < 5 then bad[#bad + 1] = x end end
			portions = portions + 1
			if ms > worst then worst = ms end
			k = to + 1
			return true
		end
		R.tuRandom = string.format("Zufall: Startwert %d, %d Fälle in %d Portionen, langsamste Portion %.1f ms",
			R.TU_SEED, R.TU_CASES, portions, worst)
		TC("TU4", "TU4-G1", "Grundregeln: Zustand, Meldung, Warnung beim Überschreiten, Werte >= 0, kein Lua-Fehler (" .. R.TU_CASES .. " Fälle)", function()
			return #bad == 0, #bad == 0 and (R.TU_CASES .. " Fälle ohne Verletzung") or Clean(table.concat(bad, " || ")),
				"0 Verletzungen (Startwert " .. R.TU_SEED .. ")"
		end)
		TC("TU4", "TU4-G2", "je Bild höchstens " .. R.FRAME_LIMIT .. " ms (Portion à " .. R.TU_PORTION .. " Fälle)", function()
			return worst <= R.FRAME_LIMIT, string.format("langsamste Portion %.1f ms", worst), "<= " .. R.FRAME_LIMIT .. " ms"
		end)
		TC("TU4", "TU4-G3", "keine geschützte Aktion, nichts Echtes ausgeführt", function()
			local blk, real = #(ns.blocked or {}) - blk0, (R.realCalls or 0) - real0
			return blk == 0 and real == 0, string.format("gesperrt %d, echt %d", blk, real), "gesperrt 0, echt 0"
		end)
		return false
	end
end

------------------------------------------------------------
-- TU5 Echte Daten (nur lesen)
------------------------------------------------------------
local function DiagEntries()
	local d = ThreatSentinelDB and ThreatSentinelDB.diag
	return (type(d) == "table" and type(d.entries) == "table") and d.entries or {}
end

local function TU5()
	TC("TU5", "TU5-E1", "Diagnose-Protokoll: keine Namen, keine Lua-Fehler und keine verletzte Grundregel in dieser Version", function()
		local entries = DiagEntries()
		local names = {}
		if ns.playerName and ns.playerName ~= "" then names[#names + 1] = ns.playerName end
		for n in pairs(ns.groupNames or {}) do if type(n) == "string" and #n > 2 then names[#names + 1] = n end end
		local bad, fights, lesbar, rules = {}, 0, 0, 0
		for _, e in ipairs(entries) do
			local t = tostring(e.t or "")
			for _, n in ipairs(names) do
				if t:find(n, 1, true) then bad[#bad + 1] = "Name in " .. S(e.k) end
			end
			if e.v == ns.version then
				if e.k == "FEHLER" then bad[#bad + 1] = "FEHLER: " .. t:sub(1, 60) end
				if e.k == "GRUNDREGEL" then rules = rules + 1; bad[#bad + 1] = t:sub(1, 80) end
			end
			if e.k == "KAMPF" then fights = fights + (e.n or 1) end
			if e.k == "LESBAR-PLAKETTEN" or e.k == "LESBAR" then lesbar = lesbar + (e.n or 1) end
		end
		local got = string.format("%d Einträge, %d Kämpfe, %d LESBAR, Grundregel verletzt %d", #entries, fights, lesbar, rules)
		return #bad == 0, #bad == 0 and got or Clean(got .. ": " .. table.concat(bad, "; ")), "keine Namen, 0 Fehler, 0 Grundregel"
	end)
	local log = ThreatSentinelDB and ThreatSentinelDB.testlog
	local events = type(log) == "table" and type(log.events) == "table" and log.events or {}
	if #events == 0 then
		TK("TU5", "TU5-E2", "Testprotokoll eines echten Kampfs nachrechnen", "kein aufgezeichneter Kampf (Testprotokoll leer – /ts log an, dann kämpfen)")
	else
		TC("TU5", "TU5-E2", "Testprotokoll eines echten Kampfs nachrechnen", function()
			local bad, states, loose, lastT = {}, 0, 0, nil
			for i, line in ipairs(events) do
				local t, typ, rest = line:match("^([%d%.%-]+)|(%u+)|(.*)$")
				if t then
					t = tonumber(t)
					if typ == "META" then lastT = nil
					else
						if lastT and t and t + 0.01 < lastT then bad[#bad + 1] = "Zeit rückwärts in Zeile " .. i end
						lastT = t or lastT
					end
					if typ == "STATE" then
						states = states + 1
						local to = rest:match("to=([%u]+)")
						if to == "LOOSE" then
							loose = loose + 1
							local role = rest:match("role=([%u]+)")
							if not role or role == "NIL" then bad[#bad + 1] = "LOOSE ohne Rolle in Zeile " .. i end
						end
					elseif typ == "ERROR" then
						bad[#bad + 1] = "Lua-Fehler in Zeile " .. i
					end
				end
				if #bad >= 5 then break end
			end
			local got = string.format("%d Zeilen, %d Zustände, %d lose", #events, states, loose)
			return #bad == 0, #bad == 0 and got or (got .. ": " .. table.concat(bad, "; ")), "Zeit vorwärts, LOOSE mit Rolle, keine Lua-Fehler"
		end)
	end
	TC("TU5", "TU5-E3", "Grundregel-Wächter im Spiel: Verletzung -> 'GRUNDREGEL VERLETZT' im Diagnose-Protokoll, ohne Namen", function()
		local T = ns.Threat
		local written = {}
		Swap(ns, "Diag", function(kind, text) written[#written + 1] = tostring(kind) .. " " .. tostring(text) end)
		local saveSeen, saveMember = T.ruleSeen, ns.memberNow
		T.ruleSeen, ns.memberNow = {}, false
		local ok, res = pcall(function()
			local m = { state = "WARN", maxOther = 40, warnStatus = false, name = "Testmob 1" }
			local r1 = T:CheckRules(m)
			T:CheckRules(m)                                          -- zweimal: nur einmal je Kampf
			local r2 = T:CheckRules({ state = "HELD", maxOther = 95 })
			local r3 = T:CheckRules({ state = "LOOSE", alerted = false })
			local r4 = T:CheckRules({ state = "HELD", maxOther = 20 })
			return string.format("%s %s %s %s, Zeilen %d", S(r1), S(r2), S(r3), S(r4), #written)
		end)
		T.ruleSeen, ns.memberNow = saveSeen, saveMember
		UnswapAll()
		if not ok then error(res, 0) end
		local named = false
		for _, w in ipairs(written) do if w:find("Testmob", 1, true) then named = true end end
		local want = "G1 G2 G4 nil, Zeilen 3"
		return res == want and not named and written[1] and written[1]:find("^GRUNDREGEL VERLETZT G1") ~= nil,
			Clean(res .. (written[1] and (" · " .. written[1]) or "")), want .. " (einmal je Regel, ohne Namen)"
	end)
end

------------------------------------------------------------
-- TU6 Regressionen: jeder Befund seit dem 3.11. -> bleibender Test (Zuordnung; die Tests selbst stehen in A–K, U)
------------------------------------------------------------
R.REGRESSIONS = {
	{ "03.11-1 Zustand 'unknown' in Forever", { "T164", "T166", "T166b" } },
	{ "03.11-2 Modus ANZEIGE: keine eigenen Entscheidungen", { "T153", "T168", "T110" } },
	{ "03.11-3 Blizzard-Anzeigen bei 'immer nur Anzeige'", { "T170" } },
	{ "03.11-4 Selbsttest mit G.SetTestFlavor", { "T05" } },
	{ "03.11-5 Kampflog und Meter in alten Clients", { "T176", "T111" } },
	{ "2.4.4-1 Ladefehler 2.4.1–2.4.3", { "T01", "T-L1" } },
	{ "2.4.4-2 Nahtstelle ns.API", { "T104", "T106", "T155" } },
	{ "2.4.4-3 Stille Fehler melden", { "T141", "T142", "T143" } },
	{ "2.4.4-4 Fehler beim Zurücksetzen legt das Addon still", { "T-R4" } },
	{ "2.4.4-5a T131/T161 fehlten", { "T131", "T161" } },
	{ "2.4.4-5b Bildschirmfoto nicht über ns.Act", { "T-R5b" } },
	{ "2.4.4-5c Testroutine-Knöpfe für jeden Spieler", { "T-R5c" } },
	{ "2.4.5-1 Übersprungene Testfälle ('noch nicht')", { "T-R13", "T122", "T128" } },
	{ "2.4.5-2 T106 und die C_-Tabellen", { "T106" } },
	{ "Launch T22 Name ohne Realm", { "T22" } },
	{ "09.11 Aggrometer nach Aggro sortieren", { "T-A1", "T-A2", "T-A3", "T-A4", "T-A5" } },
	{ "2.5.2-1 Log-Auswertung nach /reload", { "T139b" } },
	{ "2.5.2-2 LESBAR misst leere Liste", { "T-A6b" } },
	{ "2.5.2-3 Stufe 3 (Schätzung) ohne Quelle in Forever", { "T-A3", "T-A8" } },
	{ "2.5.2-4 Kopf 'Reihenfolge: sicher' nur nach Rolle", { "T167", "T-A7" } },
	{ "09.11 Sync nicht über eigene Kanäle", { "T-SY2", "T76" } },
	{ "09.11 GoldSentinelTest 2", { "T-GT1", "T-GT2" } },
	{ "2.5.2 T153 Kulisse lesbar", { "T153" } },
	{ "2.5.2 T180/T181 Rahmenname, Testzentrale über Blizzard-Fenstern", { "T180", "T181" } },
	{ "P1 Modus springt im Kampf", { "T-P1", "T-P1b" } },
	{ "P3 Gruppe zählt Begleiter", { "T-P3" } },
	{ "T135 GoldSentinelGame Version 3", { "T132" } },
	{ "2.5.4-1 Sprachtest legt das Addon still", { "T-L1", "T-L2" } },
	{ "Q4 Aggro-Warnung mit lesbarem isTanking/Status", { "T-Q4", "T169" } },
	{ "2.5.4-3 'kein Weg' zählt als verworfen", { "T-SY2" } },
	{ "2.5.4-4 LESBAR misst Ziel des Mobs nicht", { "T-A6" } },
	{ "Q1 T144 falscher Alarm", { "T-Q1", "T144" } },
	{ "Q2 Simulationen ohne Ort", { "T-Q2" } },
	{ "Q3 Hinweiszeile", { "T-Q3" } },
	{ "Q5 Sync im Kampf nachholen", { "T-Q5" } },
	{ "2.5.6-1 'nachgeholt' zählt nicht Gesendetes", { "T-Q5" } },
	{ "2.5.8-1 T-K2 im Client immer FEHLER", { "T-K2", "T-K2b", "T-K2c", "T-K2d" } },
	{ "2.5.8-2 T-G1 in Forever FEHLER", { "T-G1" } },
	{ "2.5.8-3 Spott-Grund ohne Filter", { "T-W1" } },
	{ "Sync-Anweisungen: nie eigener Kanal, geschützter Absender, alte Version", { "T-SY2", "T76", "TU1-L12" } },
	{ "14.11 SYNC gemeinsamer Sync (Senden nur Gruppe, Empfang, alte Version, kein Kanal, Netz)",
		{ "T-SYNC", "T-GS1", "T-GS2", "T-GS3", "T-GS4", "T-GS5", "T-N1", "T-N2", "T-N3", "T-N4" } },
	{ "2.5.11-2 T-MN2 konnte echte Marktdaten beschreiben", { "T-MN2" } },
	{ "TS-T1 T-GS2 liess erfundenen Mitspieler zurück", { "T-TS-T1" } },
	{ "T-3 Chat-Flut bei schnell wechselnder Aggro", { "T-T3" } },
	{ "T-2 Leistung im Kampf messen", { "T-T2" } },
	{ "TS-N1 Nutzen: Heiler-HUD, Aggrometer nur im Kampf", { "T-N1a", "T-N1b" } },
	{ "BL Befehlsliste beim Tippen", { "T-BL1", "T-BL2", "T-BL3", "T-BL4", "T-BL5", "T-BL6" } },
	{ "TR-ALLE Testroutine alles: Pausen je Bild, Abbrechen, Ausloggen", { "T-TR1", "T-TR2", "T-TR3", "TU4-G2" } },
	{ "NP-TS16-1 Portion länger als 5 ms trotz Angabe 'höchstens 5 ms'", { "T-TR1", "T-TR4" } },
	{ "2.5.16 TU1-L04t Schlachtzug 40: 10,3 ms in einem Durchlauf", { "TU1-L04t", "TU1-L04b", "T-T2b" } },
	{ "Prüfliste im Spiel: Punkte, nur Entwickler, jede Stelle meldet", { "T-PL1", "T-PL2", "T-PL3" } },
	{ "TR-ALLE Nachtrag D: Fenster-Prüfung vormerken und von selbst nachholen", { "T-D1", "T-D2" } },
	{ "18.11. Testdaten nie zu anderen Addons (GuildSentinel/RaidMaster-Vorfall)", { "T-TD1", "T-TD2" } },
	{ "18.11. Ingametest: T-PL2, Prüfliste alter Stand, T131/TU3-D2 über 40 ms", { "T-PL2", "T131", "TU3-D2", "T-K2d" } },
}

local function TU6Check()
	TC("TU6", "TU6-R1", "Regressionen: jeder Befund hat seinen Test, der Test lief", function()
		local seen = R.seen or {}
		local full = seen.T01 ~= nil   -- Bereich A gelaufen = ganzer Lauf
		if not full then return true, "nur Bereich U gelaufen – Zählung mit /ts testroutine", "vollständiger Lauf" end
		local have, missing, failed, client = 0, {}, {}, {}
		for _, reg in ipairs(R.REGRESSIONS) do
			local ran, allOk = 0, true
			for _, id in ipairs(reg[2]) do
				local st = seen[id]
				if st == "OK" then ran = ran + 1
				elseif st == "FEHLER" then ran = ran + 1; allOk = false
				elseif st == "CLIENT" then client[#client + 1] = id
				elseif st == "SKIP" and (id == "T-K2" or id == "T180" or id == "T181" or id == "T-A7") then client[#client + 1] = id
				end
			end
			if ran > 0 or #client > 0 then have = have + 1 else missing[#missing + 1] = reg[1] end
			if not allOk then failed[#failed + 1] = reg[1] end
		end
		R.tuReg = string.format("Regressionen: %d von %d vorhanden", have, #R.REGRESSIONS)
		local got = R.tuReg .. (#client > 0 and (", nur im Client: " .. table.concat(client, " ")) or "")
		if #missing > 0 then got = got .. ", fehlt: " .. table.concat(missing, "; ") end
		if #failed > 0 then got = got .. ", Test FEHLER: " .. table.concat(failed, "; ") end
		return #missing == 0 and #failed == 0, Clean(got), "alle vorhanden, alle OK"
	end)
end

local function TU6Tests()
	TC("TU6", "T-R4", "Regression 2.4.4-4: Fehler in einem Schritt der Routine gibt das Addon frei", function()
		local save = { ns.routineRunning, ns.actLog, R.running, R.cont }
		ns.routineRunning, R.running = true, true
		R:OnStepError("TS-Test: Fehler beim Zurücksetzen", true)
		local got = string.format("routineRunning %s, actLog %s, running %s", S(ns.routineRunning), S(ns.actLog), S(R.running))
		ns.routineRunning, ns.actLog, R.running, R.cont = save[1], save[2], save[3], save[4]
		local want = "routineRunning false, actLog nil, running false"
		return got == want, got, want
	end)
	TC("TU6", "T-R5b", "Regression 2.4.4-5b: Bildschirmfoto läuft über ns.Act (im Test nur mitgeschrieben)", function()
		local LG, root = ns.Log, ThreatSentinelDB
		local save = { root.testlog, LG.on, LG.lastShot, LG.shotCount, LG.shotsBlocked, LG.auto }
		root.testlog = { on = true, shots = true, meta = {}, events = {} }
		LG.on, LG.lastShot, LG.shotCount, LG.shotsBlocked, LG.auto = true, -1000, 0, false, false
		local before = ns.actLog and ns.actLog.n.shot or 0
		local ok, err = pcall(LG.Shot, LG, "tu-test", nil)
		local after = ns.actLog and ns.actLog.n.shot or 0
		root.testlog, LG.on, LG.lastShot, LG.shotCount, LG.shotsBlocked, LG.auto = save[1], save[2], save[3], save[4], save[5], save[6]
		if not ok then error(err, 0) end
		if not Screenshot then return true, "kein Screenshot im Client", "-" end
		return after - before == 1, "mitgeschrieben " .. (after - before), "mitgeschrieben 1, echt 0"
	end)
	TC("TU6", "T-R5c", "Regression 2.4.4-5c: Knöpfe der Testroutine nur für den Entwickler", function()
		local TM = ns.Test
		local parent = R.tuDummy or CreateFrame("Frame", nil, UIParent)
		R.tuDummy = parent
		parent:Hide()
		local close = R.tuDummyClose or CreateFrame("Button", nil, parent)
		R.tuDummyClose = close
		Swap(ns, "IsDev", function() return false end)
		local a = TM:AddRoutineButtons(parent, close)
		UnswapAll()
		Swap(ns, "IsDev", function() return true end)
		local b = TM:AddRoutineButtons(parent, close)
		UnswapAll()
		local got = "Spieler " .. a .. ", Entwickler " .. b
		local want = "Spieler 0, Entwickler " .. (#R.AREAS + 1)
		return got == want, got, want
	end)
	TC("TU6", "T-R13", "Regression 2.4.5-1: kein Fall nur 'noch nicht automatisiert'", function()
		local run = R:RunObject()
		local n = 0
		for _, e in ipairs(run and run.results or {}) do
			if e.status == "SKIP" and tostring(e.grund or ""):find("noch nicht", 1, true) then n = n + 1 end
		end
		return n == 0 and (R.notAuto or 0) == 0, "nicht automatisiert " .. (R.notAuto or 0) .. ", 'noch nicht' " .. n, "0 / 0"
	end)
end

------------------------------------------------------------
-- TU7 Formen des Spiels
------------------------------------------------------------
local function TU7()
	local G = GoldSentinelGame
	for _, f in ipairs({ "forever", "era", "tbc" }) do
		TC("TU7", "TU7-F-" .. f, "Lagen-Katalog im Client " .. f, function()
			local saveAccess, saveChecked = ns.threatAccess, ns.ThreatAccess.checked
			local ok, a, b, c = pcall(H.WithFlavor, f, function()
				if not ns.isModern then ns.threatAccess = "open" end
				return CatalogCheck("TU7", f, ns.isModern, f)
			end)
			ns.threatAccess, ns.ThreatAccess.checked = saveAccess, saveChecked
			if not ok then error(a, 0) end
			return a, b, c
		end)
	end
	TC("TU7", "TU7-S1", "Sprachen deDE und enUS: Meldungen ohne Platzhalter-Fehler, Lagen gleich", function()
		local bad = {}
		local saveLoc = ns.activeLocale
		for _, code in ipairs({ "deDE", "enUS" }) do
			ns:ApplyLocale(code)
			local okC, a, b = pcall(CatalogCheck, "TU7", code, ns.isModern, code)
			if not okC then bad[#bad + 1] = code .. ": Lua " .. tostring(a)
			elseif not a then bad[#bad + 1] = code .. ": " .. tostring(b) end
			-- Meldungstexte mit Zahl/Name formatieren
			for _, key in ipairs({ "LOOSE", "TAUNT_CD", "CLAIMED", "OWNER", "AOE_HINT", "EMERGENCY", "SELF_AGGRO", "MSG_CC_DUR" }) do
				local fmt = L[key]
				if type(fmt) == "string" then
					local okF = pcall(string.format, fmt, 3, 4, 5)
					local okS = pcall(string.format, fmt, "x", "y", "z")
					if not okF and not okS then bad[#bad + 1] = code .. " " .. key end
				end
			end
		end
		ns:ApplyLocale(saveLoc)
		return #bad == 0, #bad == 0 and "deDE und enUS" or Clean(table.concat(bad, "; ")), "beide Sprachen wie erwartet"
	end)
	if H.Shown and ns.UICheck and ns.UICheck.Available and ns.UICheck.Available() then
		TC("TU7", "TU7-K1", "Skalierung 80 % und 150 %: HUD, Aggrometer und DD-Ansicht ganz im Bild", function()
			local U = ns.UICheck
			local bad = {}
			local save = { ns.db.hudScale, ns.db.meterScale, ns.db.ddScale }
			local shown = {}
			for _, k in ipairs({ "HUD", "Meter", "DD" }) do shown[k] = ns[k] and ns[k].f and ns[k].f:IsShown() end
			for _, sc in ipairs({ 0.8, 1.5 }) do
				ns.db.hudScale, ns.db.meterScale, ns.db.ddScale = sc, sc, sc
				ns:ApplySettings()
				for _, k in ipairs({ "HUD", "Meter", "DD" }) do
					local f = ns[k] and ns[k].f
					if f then
						f:Show()
						local r = U.Rect(f)
						local ur = U.Rect(UIParent)
						if r and ur and (r.l < ur.l - 1 or r.r > ur.r + 1 or r.b < ur.b - 1 or r.t > ur.t + 1) then
							bad[#bad + 1] = string.format("%s bei %d %%", k, sc * 100)
						end
					end
				end
			end
			ns.db.hudScale, ns.db.meterScale, ns.db.ddScale = save[1], save[2], save[3]
			ns:ApplySettings()
			for _, k in ipairs({ "HUD", "Meter", "DD" }) do
				local f = ns[k] and ns[k].f
				if f then if shown[k] then f:Show() else f:Hide() end end
			end
			return #bad == 0, #bad == 0 and "im Bild" or table.concat(bad, ", "), "alle ganz im Bild"
		end)
	else
		TCL("TU7", "TU7-K1", "Skalierung 80 % und 150 %: Anzeigen ganz im Bild", "/ts testroutine u im echten Client (Rechtecke)")
	end
end

------------------------------------------------------------
-- BL Befehlsliste (T-BL1–T-BL6)
------------------------------------------------------------
local function Entries(list)
	local out = {}
	for _, it in ipairs(list) do out[#out + 1] = it.entry[1] end
	return table.concat(out, ",")
end

local function BL()
	local CH = ns.CmdHint
	TC("TU6", "T-BL1", "Befehlsliste: jeder Befehl des Handlers steht in der Liste, der Handler führt genau ihn aus", function()
		Swap(ns, "IsDev", function() return true end)
		local list = CH:List("")
		local inList = {}
		for _, it in ipairs(list) do inList[it.entry] = true end
		local bad = {}
		local hits = {}
		for _, other in ipairs(ns.COMMANDS) do
			local me = other
			Swap(me, "run", function() hits[#hits + 1] = me end)
		end
		for _, c in ipairs(ns.COMMANDS) do
			if not inList[c] then bad[#bad + 1] = "nicht in der Liste: " .. c[1] end
			local forms = { c[1], c[2] }
			for _, a in ipairs(c.alias or {}) do forms[#forms + 1] = a end
			for _, form in ipairs(forms) do
				wipe(hits)
				SlashCmdList.THREATSENTINEL(form)
				if #hits ~= 1 or hits[1] ~= c then bad[#bad + 1] = "'" .. form .. "' -> " .. (hits[1] and hits[1][1] or "nichts") end
			end
		end
		UnswapAll()
		-- unbekannt / leer -> Einstellungen
		local opt = 0
		Swap(ns.Options, "Toggle", function() opt = opt + 1 end)
		SlashCmdList.THREATSENTINEL("")
		SlashCmdList.THREATSENTINEL("gibtsnicht")
		UnswapAll()
		if opt ~= 2 then bad[#bad + 1] = "leer/unbekannt -> Einstellungen " .. opt .. "x" end
		return #bad == 0, #bad == 0 and (#ns.COMMANDS .. " Befehle, Liste " .. #list) or table.concat(bad, "; "),
			"alle Befehle in der Liste, jede Form genau ihr Eintrag"
	end)
	TC("TU6", "T-BL2", "Befehlsliste: Filtern mit jedem Buchstaben, meistbenutzte oben", function()
		Swap(ns, "IsDev", function() return true end)
		local saveLoc, saveUse = ns.activeLocale, ns.db.cmdUse
		ns.activeLocale = "deDE"
		ns.db.cmdUse = {}
		local r = {}
		r[1] = Entries(CH:List("ver"))
		r[2] = #CH:List("te")
		r[3] = Entries(CH:List("lo"))
		r[4] = #CH:List("x")
		r[5] = #CH:List("")
		ns.db.cmdUse = { bedrohung = 5, spenden = 2 }
		local top = CH:List("")
		r[6] = top[1].entry[1] .. "," .. top[2].entry[1]
		ns.activeLocale = "enUS"
		r[7] = Entries(CH:List("thr"))
		UnswapAll()
		Swap(ns, "IsDev", function() return false end)
		ns.activeLocale = "deDE"
		ns.db.cmdUse = {}
		r[8] = Entries(CH:List(""))
		UnswapAll()
		ns.activeLocale, ns.db.cmdUse = saveLoc, saveUse
		local got = table.concat({ r[1], S(r[2]), r[3], S(r[4]), S(r[5]), r[6], r[7], r[8] }, " | ")
		local want = "verschieben | 19 | protokoll,log,log an,log aus,log bericht,log bilder,log leeren | 0 | " .. #ns.COMMANDS
			.. " | bedrohung,spenden | bedrohung | einstellungen,bedrohung,verschieben,protokoll,spenden,sync test"
		return got == want, got, want
	end)
	TC("TU6", "T-BL3", "Befehlsliste: Klick wählt (Kopf 'Enter = …'), Enter führt aus, Liste bleibt beim Klick offen", function()
		Swap(ns, "IsDev", function() return true end)
		local saveLoc, saveSel, saveClick, saveInstant = ns.activeLocale, CH.selected, CH.clickAt, CH.instantClose
		ns.activeLocale = "deDE"
		local moved = 0
		Swap(ns.Mover, "Toggle", function() moved = moved + 1 end)
		local opt = 0
		Swap(ns.Options, "Toggle", function() opt = opt + 1 end)
		local r = {}
		local ok, err = pcall(function()
			CH:Show(nil, "ver")
			local item = CH.items[1]
			CH:Select(item, true)                                 -- Mausklick
			r[1] = CH.frame.head:GetText() == string.format(L.CH_ENTER, "/ts verschieben")
			CH.instantClose = true
			CH.editBox = "box"
			CH:OnFocusLost("box")                                 -- Fokusverlust direkt nach dem Klick
			r[2] = CH.frame:IsShown()
			SlashCmdList.THREATSENTINEL("ver")                    -- Enter mit unvollständigem Wort
			r[3] = moved == 1 and opt == 0
			r[4] = CH:Selection() == nil
			-- alte Auswahl (> 10 s) gilt nicht mehr
			CH:Select(item, false)
			CH.selected.t = CH.selected.t - 11
			SlashCmdList.THREATSENTINEL("ver")
			r[5] = moved == 1 and opt == 1
			-- Tab wählt den nächsten
			CH:Show(nil, "log")
			CH.selected = nil
			CH:SelectNext(1); local a = CH:Selection().item.entry[1]
			CH:SelectNext(1); local b = CH:Selection().item.entry[1]
			r[6] = a .. ">" .. b
		end)
		CH:Hide()
		CH.selected, CH.clickAt, CH.instantClose, CH.editBox = saveSel, saveClick, saveInstant, nil
		ns.activeLocale = saveLoc
		UnswapAll()
		if not ok then error(err, 0) end
		local got = table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]), S(r[6]) }, " ")
		local want = "true true true true true protokoll>log"
		return got == want, got, want .. " (Kopf, offen, ausgeführt, Auswahl weg, alte Auswahl verfällt, Tab)"
	end)
	TC("TU6", "T-BL4", "Befehlsliste: das Chatfeld wird nie beschrieben (nur HookScript, SetFocus)", function()
		local box = R.tuBox or CreateFrame("EditBox", nil, UIParent)
		R.tuBox = box
		box:Hide()
		local calls = { set = 0, insert = 0, script = 0, hook = 0, focus = 0 }
		local text = "/ts be"
		-- nur die eigene Test-Box bekommt Zähler (eigenes Objekt, kein Blizzard-Feld)
		box.GetText = function() return text end
		box.SetText = function() calls.set = calls.set + 1 end
		box.Insert = function() calls.insert = calls.insert + 1 end
		box.SetScript = function() calls.script = calls.script + 1 end
		box.SetFocus = function() calls.focus = calls.focus + 1 end
		box.IsShown = function() return true end
		local hooks = {}
		box.HookScript = function(_, ev, fn) calls.hook = calls.hook + 1; hooks[ev] = fn end
		local saveHooked = CH.hooked[box]
		CH.hooked[box] = nil
		local ok, err = pcall(function()
			CH:HookBox(box)
			hooks.OnTextChanged(box)
			local shown = CH.frame and CH.frame:IsShown()
			CH:Select(CH.items[1], true)
			hooks.OnTabPressed(box)
			CH.instantClose = true
			CH.clickAt = nil
			hooks.OnEditFocusLost(box)
			return shown
		end)
		CH.instantClose = nil
		CH:Hide()
		CH.selected = nil
		CH.hooked[box] = saveHooked
		for _, k in ipairs({ "GetText", "SetText", "Insert", "SetScript", "SetFocus", "IsShown", "HookScript" }) do box[k] = nil end
		if not ok then error(err, 0) end
		local got = string.format("Liste %s, SetText %d, Insert %d, SetScript %d, HookScript %d, SetFocus %d", S(err),
			calls.set, calls.insert, calls.script, calls.hook, calls.focus)
		local good = err == true and calls.set == 0 and calls.insert == 0 and calls.script == 0 and calls.hook == 4 and calls.focus >= 1
		return good, got, "Liste true, SetText 0, Insert 0, SetScript 0, HookScript 4, SetFocus >= 1"
	end)
	TC("TU6", "T-BL5", "Befehlsliste: Entwickler-Befehle nur für den Entwickler", function()
		local dev = 0
		for _, c in ipairs(ns.COMMANDS) do if c.dev then dev = dev + 1 end end
		Swap(ns, "IsDev", function() return false end)
		local a = CH:List("")
		local leak = 0
		for _, it in ipairs(a) do if it.entry.dev then leak = leak + 1 end end
		UnswapAll()
		Swap(ns, "IsDev", function() return true end)
		local b = #CH:List("")
		UnswapAll()
		local got = string.format("Spieler %d (davon Entwickler %d), Entwickler %d", #a, leak, b)
		local want = string.format("Spieler %d (davon Entwickler 0), Entwickler %d", #ns.COMMANDS - dev, #ns.COMMANDS)
		return got == want, got, want
	end)
	TC("TU6", "T-BL6", "Befehlsliste: alle Sprachen, Beschreibungen ohne Platzhalter-Fehler", function()
		local bad = {}
		for code, tbl in pairs(ns.LOCALES) do
			for _, c in ipairs(ns.COMMANDS) do
				local t = rawget(tbl, c[3])
				if type(t) ~= "string" or t == "" then bad[#bad + 1] = code .. " fehlt " .. c[3]
				else
					local n = select(2, t:gsub("%%s", ""))
					local want = c.descArg and 1 or 0
					if n ~= want then bad[#bad + 1] = code .. " " .. c[3] .. " %s " .. n end
					if c.descArg and not pcall(string.format, t, c.descArg) then bad[#bad + 1] = code .. " " .. c[3] .. " format" end
				end
			end
			for _, k in ipairs({ "CH_ENTER", "CH_NOMATCH", "O_CMDHINT" }) do
				if type(rawget(tbl, k)) ~= "string" then bad[#bad + 1] = code .. " fehlt " .. k end
			end
		end
		return #bad == 0, #bad == 0 and "deDE und enUS vollständig" or table.concat(bad, "; "), "alle Texte da, Platzhalter passen"
	end)
end

------------------------------------------------------------
-- SYNC: gemeinsame Datei GoldSentinelSync (T-SYNC, T-GS1–T-GS5, T-N1–T-N4). Ersetzt werden nur Einträge von
-- GoldSentinelSync.api und eigene Felder, nie Blizzard-Funktionen. Was ein Test in die Warteschlange der Datei legt,
-- nimmt er wieder heraus (es darf nichts wirklich gesendet werden).
------------------------------------------------------------
local function SYNC()
	local G = rawget(_G, "GoldSentinelSync")
	local Sy = ns.Sync
	if type(G) ~= "table" then
		C("T-SYNC", "U", "Sync über GoldSentinelSync: Senden und Empfangen", function() return false, "GoldSentinelSync fehlt", "geladen" end)
		return
	end
	-- Senden: echter Weg bis in die Warteschlange der Datei (ns.Act kurz echt), nur PARTY/RAID
	local function SendCase(inRaid)
		local q0, n0 = #G.queue, #G.netQueue
		local saveLog, saveSync = ns.actLog, ns.db.sync
		Swap(G.api, "inGuild", function() return true end)
		Swap(G.api, "inGroup", function() return true end)
		Swap(G.api, "inRaid", function() return inRaid end)
		Swap(G.api, "send", function() return false end)       -- falls doch etwas gepumpt würde: nichts geht raus
		ns.actLog, ns.db.sync = nil, true
		local ok, r = pcall(WithAPI, { IsInGroup = Ret(true), IsInRaid = Ret(inRaid), InCombatLockdown = Ret(false) },
			function() return Sy:Send("H:TANK:tu-test") end)
		ns.actLog, ns.db.sync = saveLog, saveSync
		local new = {}
		for i = #G.queue, q0 + 1, -1 do table.insert(new, 1, table.remove(G.queue, i)) end
		local netNew = #G.netQueue - n0
		for i = #G.netQueue, n0 + 1, -1 do table.remove(G.netQueue, i) end
		UnswapAll()
		if not ok then error(r, 0) end
		local d = {}
		for _, e in ipairs(new) do d[#d + 1] = S(e.dist) .. (e.prefix == Sy.PREFIX and "" or ("?" .. S(e.prefix))) end
		local first = new[1] and new[1].msg or ""
		return string.format("%s %s Netz %d Kopf %s", S(r), table.concat(d, "+"), netNew,
			S(first:match("^#S1:%w+:%w+:H:TANK:tu%-test$") ~= nil))
	end
	C("T-SYNC", "U", "Sync über GoldSentinelSync: Senden nur an Gruppe/Schlachtzug, Empfang über den Endpunkt", function()
		local a = SendCase(false)
		local b = SendCase(true)
		ns.syncRoles.Grimbar = nil
		Sy:OnReceive("H:TANK:2.5.13", "Grimbar", "PARTY")
		local r = ns.syncRoles.Grimbar
		ns.syncRoles.Grimbar = nil                                    -- TS-T1: erfundenen Mitspieler wieder entfernen
		local got = a .. " | " .. b .. " | empfangen " .. S(r and r.role)
		local want = "true PARTY Netz 0 Kopf true | true RAID Netz 0 Kopf true | empfangen TANK"
		return got == want, got, want .. " (keine GUILD, kein CHANNEL, kein WHISPER)"
	end)
	C("T-GS1", "U", "Senden geht über ep:Send (scope group), nie CHANNEL", function()
		local captured
		Swap(Sy.ep, "Send", function(_, msg, opts) captured = S(msg) .. " " .. S(opts and opts.scope); return true, 1 end)
		local saveLog, saveSync = ns.actLog, ns.db.sync
		ns.actLog, ns.db.sync = nil, true
		local ok, r = pcall(WithAPI, { IsInGroup = Ret(true), IsInRaid = Ret(false), InCombatLockdown = Ret(false) },
			function() return Sy:Send("T:-:8") end)
		ns.actLog, ns.db.sync = saveLog, saveSync
		UnswapAll()
		if not ok then error(r, 0) end
		local paths = {}
		for _, combo in ipairs({ { true, true, false }, { true, false, true }, { false, false, false } }) do
			Swap(G.api, "inGuild", function() return combo[1] end)
			Swap(G.api, "inRaid", function() return combo[2] end)
			Swap(G.api, "inGroup", function() return combo[3] or combo[2] end)
			local p = {}
			for _, x in ipairs(G.Paths({ scope = "group" })) do p[#p + 1] = x[1] end
			paths[#paths + 1] = #p > 0 and table.concat(p, "+") or "-"
			UnswapAll()
		end
		local got = S(captured) .. " | " .. table.concat(paths, ",")
		local want = "T:-:8 group | RAID,PARTY,-"
		return got == want, got, want
	end)
	C("T-GS2", "U", "Empfang über ep:OnMessage, fehlender Absender wird vertragen", function()
		local before = ns.errorCount or 0
		local st = { G.stats.received, Sy.ep.stats.received }
		-- TS-T1: erfundenen Mitspieler "tuzz" und seinen Dubletten-Schlüssel nicht in der gemeinsamen Datei lassen
		local hadPeer, seenLen = G.peers.tuzz, #G.seenList
		ns.syncRoles.Grimbar = nil
		local ok, err = pcall(G.OnAddonMessage, Sy.PREFIX, "#S1:tuzz:1:H:TANK:2.5.13", "PARTY", nil)
		G.stats.received, Sy.ep.stats.received = st[1], st[2]
		G.peers.tuzz = hadPeer
		for i = #G.seenList, seenLen + 1, -1 do G.seen[table.remove(G.seenList, i)] = nil end
		if not ok then return false, "Lua: " .. tostring(err), "kein Fehler" end
		local got = string.format("Fehler +%d, übernommen %s", (ns.errorCount or 0) - before, S(ns.syncRoles.Grimbar ~= nil))
		return got == "Fehler +0, übernommen false", got, "Fehler +0, übernommen false (ohne Namen nichts zuordnen)"
	end)
	C("T-GS3", "U", "alte Nachricht ohne Kopf (ThreatSentinel bis 2.5.12) wird verstanden", function()
		local st = { G.stats.received, Sy.ep.stats.received }
		ns.syncRoles.Grimbar = nil
		local ok, err = pcall(G.OnAddonMessage, Sy.PREFIX, "H:TANK:2.5.12", "PARTY", "Grimbar-Realm")
		G.stats.received, Sy.ep.stats.received = st[1], st[2]
		if not ok then return false, "Lua: " .. tostring(err), "kein Fehler" end
		local r = ns.syncRoles.Grimbar
		ns.syncRoles.Grimbar = nil                                    -- TS-T1
		local got = S(r and r.role) .. " " .. S(r and r.ver)
		return got == "TANK 2.5.12", got, "TANK 2.5.12"
	end)
	C("T-GS4", "U", "kein eigener Kanal: Endpunkt mit bisheriger Kennung, keine Kanal-Wege", function()
		local paths = {}
		for _, sc in ipairs({ "group", "guild", "all" }) do
			for _, x in ipairs(G.Paths({ scope = sc })) do if x[1] == "CHANNEL" then paths[#paths + 1] = sc end end
		end
		local got = string.format("Kennung %s, Endpunkt %s, Kanal-Wege %d", S(Sy.ep and Sy.ep.prefix), S(G.byAddon[ADDON] == Sy.ep), #paths)
		local want = "Kennung ThreatSentinel, Endpunkt true, Kanal-Wege 0"
		return got == want, got, want
	end)
	C("T-GS5", "U", "/ts sync test gibt eine Zeile aus", function()
		local lines = {}
		Swap(ns, "Print", function(_, t) lines[#lines + 1] = tostring(t) end)
		Swap(G, "Ping", function(_, cb) cb({ guild = 1, group = 2, total = 3 }) end)
		local ok, err = pcall(SlashCmdList.THREATSENTINEL, "sync test")
		UnswapAll()
		if not ok then error(err, 0) end
		local last = lines[#lines] or ""
		local want = string.format(L.SYNC_PING_RESULT, 3, 1, 2)
		return last == want, Clean(last), want
	end)
	C("T-TS-T1", "U", "Regression TS-T1: kein erfundener Mitspieler bleibt zurück (Sync-Datei und Rollen)", function()
		local seenTu = 0
		for k in pairs(G.seen) do if tostring(k):find("tuzz", 1, true) then seenTu = seenTu + 1 end end
		local got = string.format("Mitspieler tuzz %s, Dubletten-Schlüssel %d, Rolle Grimbar %s", S(G.peers.tuzz ~= nil), seenTu,
			S(ns.syncRoles.Grimbar ~= nil))
		local want = "Mitspieler tuzz false, Dubletten-Schlüssel 0, Rolle Grimbar false"
		return got == want, got, want
	end)
	C("T-N1", "U", "GoldSentinelSync Version 2 nach dem Laden", function()
		return (tonumber(G.VERSION) or 0) >= 2, "Version " .. S(G.VERSION), ">= 2"
	end)
	C("T-N2", "U", "ep:UseStorage: bekannte Mitspieler in ThreatSentinelDB.gsSync (oder bei einem anderen Addon)", function()
		local t = ThreatSentinelDB and ThreatSentinelDB.gsSync
		local got = string.format("gsSync %s, Speicher %s", S(type(t) == "table"), S(G.store ~= nil))
		return got == "gsSync true, Speicher true", got, "gsSync true, Speicher true"
	end)
	C("T-N3", "U", "Rollen und Spotts nie ins Flüster-Netz (scope group)", function()
		local n0 = #G.netQueue
		local a = SendCase(false)
		return #G.netQueue == n0 and a:find("Netz 0", 1, true) ~= nil, a, "Netz 0"
	end)
	C("T-N4", "U", "Diagnose: Zeilen der gemeinsamen Datei mit NETZ, ohne Spielernamen", function()
		local lines = ns.DiagExtra()
		local netz, named = false, false
		for _, l in ipairs(lines) do
			if l:find("^NETZ") then netz = true end
			if ns.playerName and ns.playerName ~= "" and l:find(ns.playerName, 1, true) then named = true end
		end
		return netz and not named, "NETZ " .. S(netz) .. ", Name " .. S(named), "NETZ true, Name false"
	end)
end

------------------------------------------------------------
-- T-3 Chat-Grenze und T-2 Leistungsmessung (2.5.14)
------------------------------------------------------------
local function CHATPERF()
	local A = ns.Alerts
	C("T-T3", "U", "Chat-Meldungen: 10 Aggro-Wechsel in 3 s -> höchstens 1 Meldung je Text, nach 5 s wieder", function()
		local save = { ns.db.chatChannel, A.chatLast, A.chatHeld }
		ns.db.chatChannel, A.chatLast, A.chatHeld = "GROUP", {}, 0
		local now = 1000
		local t0 = ns.actLog and ns.actLog.n.chat or 0
		local ok, err = pcall(WithAPI, { IsInGroup = Ret(true), IsInRaid = Ret(false) }, function()
			Swap(ns.Test, "IsTesting", function() return false end)
			Swap(A, "Clock", function() return now end)
			for i = 1, 10 do now = 1000 + i * 0.3; A._GroupChat("Aggro: TS-Testmob") end
			local mid = (ns.actLog and ns.actLog.n.chat or 0) - t0
			A._GroupChat("Aggro: TS-Anderer")                       -- andere Meldung: kommt
			now = 1000 + 3 + 5.1
			A._GroupChat("Aggro: TS-Testmob")                       -- nach 5 s wieder erlaubt
			return mid
		end)
		UnswapAll()
		local total = (ns.actLog and ns.actLog.n.chat or 0) - t0
		local held = A.chatHeld
		ns.db.chatChannel, A.chatLast, A.chatHeld = save[1], save[2], save[3]
		if not ok then error(err, 0) end
		local got = string.format("10 Wechsel -> %d, gesamt %d, zurückgehalten %d", err, total, held)
		local want = "10 Wechsel -> 1, gesamt 3, zurückgehalten 9"
		return got == want, got, want
	end)
	C("T-T2b", "U", "Leistung im Kampf: Zeile LEISTUNG nennt, wie alt der Stand der Gegner höchstens war (Zeitbudget 2.5.17)", function()
		local P, T = ns.perf, ns.Threat
		local save = {}
		for k, v in pairs(P) do save[k] = v end
		local saveLast, saveWait, saveRun = ns.perfLast, T.maxWait, ns.routineRunning
		Swap(ns, "Diag", function() end)
		Swap(ns, "PLHit", function() end); Swap(ns, "PLFail", function() end)
		local ok, res = pcall(function()
			ns.PerfStart()
			ns.routineRunning = false
			ns.PerfAdd("Durchlauf (T:Tick)", 4)
			ns.routineRunning = saveRun
			T.maxWait = 3
			return ns.PerfStop()
		end)
		ns.routineRunning = saveRun
		UnswapAll()
		for k in pairs(P) do P[k] = save[k] end
		ns.perfLast, T.maxWait = saveLast, saveWait
		if not ok then error(res, 0) end
		local got = S(res):match("· Stand.*$") or S(res)
		local want = "· Stand der Gegner höchstens 3 Durchläufe alt (0.75 s)"
		return got == want, got, want
	end)
	C("T-T2", "U", "Leistung im Kampf: längster Rahmen je Kampf, Zeile LEISTUNG ohne Namen", function()
		local P = ns.perf
		local save = {}
		for k, v in pairs(P) do save[k] = v end
		local saveLast = ns.perfLast
		local lines = {}
		local t = 50
		Swap(ns, "Diag", function(kind, text) lines[#lines + 1] = tostring(kind) .. " " .. tostring(text) end)
		Swap(ns, "PerfClock", function() return t end)
		local saveRun = ns.routineRunning
		local ok, res = pcall(function()
			ns.PerfStart()
			ns.routineRunning = false                               -- PerfAdd misst während der Routine sonst nicht
			ns.PerfAdd("UNIT_THREAT_LIST_UPDATE", 3); ns.PerfAdd("Durchlauf (T:Tick)", 5)   -- Bild 1: 8 ms
			t = 50.02; ns.PerfAdd("Plaketten-Effekte", 12); ns.PerfAdd("UNIT_AURA", 6)     -- Bild 2: 18 ms
			t = 50.04; ns.PerfAdd("Abfrage Kontrolle (CheckCC)", 1)                       -- Bild 3: 1 ms
			ns.routineRunning = saveRun
			return ns.PerfStop()
		end)
		ns.routineRunning = saveRun
		UnswapAll()
		for k in pairs(P) do P[k] = save[k] end
		ns.perfLast = saveLast
		if not ok then error(res, 0) end
		local want = "Kampf: längster Rahmen durch ThreatSentinel 18.0 ms (Plaketten-Effekte), über 16 ms: 1 von 3 Rahmen"
		local got = S(res) .. " · Diag " .. #lines
		local named = ns.playerName and S(res):find(ns.playerName, 1, true)
		return res == want and #lines == 1 and not named, got, want .. " · Diag 1"
	end)
end

------------------------------------------------------------
-- TS-N1 Nutzen-Ausbau (2.5.15): Heiler-HUD, Aggrometer nur im Kampf
------------------------------------------------------------
local function NUTZEN()
	C("T-N1a", "U", "Heiler sehen im HUD, wer Aggro hat (DD nicht, Option aus = nicht)", function()
		local function shownLine(l) return l and l.IsShown and l:IsShown() and l.GetText end
		local function run(role, opt)
			local sc = Scene.New(2)
			sc.tank = false
			sc.units.player.role = role
			Scene.Hold(sc, "tsfake1", "party1")
			Scene.Hold(sc, "tsfake2", "party3")
			return Scene.Run(sc, function()
				local save = { ns.db.hudHealer, ns.db.hud, ns.db.myRole, ns.db.memberView, ns.lastTankT, ns.tankAtPull }
				ns.db.hudHealer, ns.db.hud, ns.db.myRole, ns.db.memberView = opt, true, role, true
				ns.lastTankT, ns.tankAtPull = -1000, false
				ns.simAccess = "open"
				local ok, err = pcall(function() ns.Threat:Tick() end)
				local shown = ns.HUD.f and ns.HUD.f:IsShown() or false
				local l1 = ns.HUD.f and ns.HUD.f.lines and ns.HUD.f.lines[1]
				local line = (shownLine(l1) and l1:GetText()) or ""
				line = tostring(line):find(sc.units.party1.name, 1, true) and "Opfer" or ("ohne Opfer: " .. tostring(line))
				ns.db.hudHealer, ns.db.hud, ns.db.myRole, ns.db.memberView, ns.lastTankT, ns.tankAtPull =
					save[1], save[2], save[3], save[4], save[5], save[6]
				if ns.HUD.f then ns.HUD.f:Hide() end
				if not ok then error(err, 0) end
				return string.format("%s %s", S(ns.memberNow), S(shown)), line
			end)
		end
		local a, la = run("HEALER", true)
		local b = run("HEALER", false)
		local c = run("DAMAGER", true)
		local got = string.format("Heiler an: %s · Heiler aus: %s · DD: %s · Zeile %s", a, b, c, S(la))
		local want = "Heiler an: true true · Heiler aus: true false · DD: true false · Zeile Opfer"
		return got == want, Clean(got), want
	end)
	C("T-N1b", "U", "Aggrometer 'nur im Kampf': ausserhalb verborgen, im Kampf sichtbar, Option aus wie bisher", function()
		local function run(opt, combat)
			local sc = Scene.New(1)
			sc.alias.target = "tsfake1"
			sc.units.player.combat = combat
			return Scene.Run(sc, function()
				local save = { ns.db.meterOnlyCombat, ns.db.meter, ns.db.meterOnlyTank }
				ns.db.meterOnlyCombat, ns.db.meter, ns.db.meterOnlyTank = opt, true, false
				ns.simAccess = "open"
				local ok, err = pcall(ns.Meter.Tick, ns.Meter)
				local shown = ns.Meter.f and ns.Meter.f:IsShown() or false
				ns.db.meterOnlyCombat, ns.db.meter, ns.db.meterOnlyTank = save[1], save[2], save[3]
				if ns.Meter.f then ns.Meter.f:Hide() end
				if not ok then error(err, 0) end
				return S(shown)
			end)
		end
		local got = string.format("an/aussen %s, an/Kampf %s, aus/aussen %s", run(true, false), run(true, true), run(false, false))
		local want = "an/aussen false, an/Kampf true, aus/aussen true"
		return got == want, got, want
	end)
end

------------------------------------------------------------
-- MN4 Marktdaten-Netz (shared/GoldSentinelMarkt.lua): lädt mit/ohne Datei, Schalter aus, ohne AH-API
------------------------------------------------------------
local function MN()
	local GM = rawget(_G, "GoldSentinelMarkt")
	C("T-MN1", "U", "Marktdaten-Netz: Addon läuft mit und ohne die gemeinsame Datei", function()
		local with = type(GM) == "table" and GM.hosts and GM.hosts[ADDON] == ThreatSentinelDB
			and type(ThreatSentinelDB.gsMarkt) == "table"
		_G.GoldSentinelMarkt = nil
		local ok, a, line, extraOk = pcall(function()
			local r = ns:AttachMarket()
			ns:ApplyMarketShare()
			local okE = pcall(ns.DiagExtra)
			return r, ns:MarketLine(), okE
		end)
		_G.GoldSentinelMarkt = GM
		if not ok then return false, "Lua: " .. tostring(a), "kein Fehler" end
		local got = string.format("mit Datei %s · ohne: Anmelden %s, Zeile '%s', Diagnose %s", S(with), S(a), S(line), S(extraOk))
		local want = "mit Datei true · ohne: Anmelden false, Zeile 'MARKT-NETZ: nicht geladen', Diagnose true"
		return got == want, got, want
	end)
	if type(GM) ~= "table" then
		K("T-MN2", "U", "Marktdaten-Netz: Schalter aus -> kein Lesen, kein Annehmen", "GoldSentinelMarkt nicht geladen")
		K("T-MN3", "U", "Marktdaten-Netz: kein Lua-Fehler ohne Auktionshaus-API", "GoldSentinelMarkt nicht geladen")
	else
		C("T-MN2", "U", "Marktdaten-Netz: Schalter aus -> kein Lesen, kein Annehmen (Gegenprobe mit Schalter an)", function()
			local st = GM.Stats()
			-- Test-Item, das es nicht gibt; Eintrag vorher sichern und am Ende wiederherstellen (nie echte Daten verändern)
			local ID = 999991
			local function B36(n)
				n = math.floor(tonumber(n) or 0)
				if n == 0 then return "0" end
				local d, out = "0123456789abcdefghijklmnopqrstuvwxyz", ""
				while n > 0 do local r = n % 36; out = d:sub(r + 1, r + 1) .. out; n = (n - r) / 36 end
				return out
			end
			local fac = GM.api.faction()
			local store = GM.store
			local ftab = store and store.f and store.f[fac]
			local hadF = ftab ~= nil
			local savedItem = ftab and ftab.i and ftab.i[ID]
			local savedTn = ftab and ftab.tn
			local save = { ns.db.marketShare, ThreatSentinelDB.gsMarktAus, GM.lastEv, GM.readAt, GM.reader,
				st.dropped.aus, st.accepted, st.received, GM.outbox, GM.feedUntil, st.dropped.zeit }
			local ok, res = pcall(function()
				GM.outbox = {}
				local msg = "S:" .. fac .. ":" .. B36(GM.api.time()) .. ":" .. B36(ID) .. ",1,1,1"
				-- Gegenprobe: Schalter an -> die Nachricht wird angenommen
				ns.db.marketShare = true
				ns:ApplyMarketShare()
				local acc0 = st.accepted
				if GM.IsShareOn() then GM.OnMessage(msg, "Netz") end
				local onAcc = st.accepted - acc0
				local f2 = store and store.f and store.f[fac]
				if f2 and f2.i then f2.i[ID] = nil end
				-- Schalter aus
				ns.db.marketShare = false
				ns:ApplyMarketShare()
				local on = GM.IsShareOn()
				GM.lastEv, GM.readAt, GM.feedUntil = nil, nil, nil
				GM.OnReplicate()                                   -- ein Vollscan beginnt
				local read = GM.readAt ~= nil or GM.reader ~= nil
				local acc = st.accepted
				GM.OnMessage(msg, "Netz")                          -- fremde Daten kommen an
				local stored = f2 and f2.i and f2.i[ID] ~= nil
				return string.format("an: angenommen %d · aus: teilen %s, liest %s, angenommen %d, gespeichert %s",
					onAcc, S(on), S(read), st.accepted - acc, S(stored))
			end)
			-- echte Daten zurück
			local f3 = store and store.f and store.f[fac]
			if f3 then
				if f3.i then f3.i[ID] = savedItem end
				f3.tn = savedTn
				if not hadF then store.f[fac] = nil end
			end
			ns.db.marketShare, ThreatSentinelDB.gsMarktAus, GM.lastEv, GM.readAt, GM.reader = save[1], save[2], save[3], save[4], save[5]
			st.dropped.aus, st.accepted, st.received, GM.outbox, GM.feedUntil, st.dropped.zeit = save[6], save[7], save[8], save[9], save[10], save[11]
			ns:ApplyMarketShare()
			if not ok then return false, "Lua: " .. tostring(res), "kein Fehler" end
			local want = "an: angenommen 1 · aus: teilen false, liest false, angenommen 0, gespeichert false"
			-- ist das Teilen in einem anderen GoldSentinel-Addon aus, gibt es keine Gegenprobe
			if res:find("^an: angenommen 0") and not GM.IsShareOn() then
				want = "an: angenommen 0 · aus: teilen false, liest false, angenommen 0, gespeichert false"
			end
			return res == want, res, want
		end)
		C("T-MN3", "U", "Marktdaten-Netz: kein Lua-Fehler ohne Auktionshaus-API (alte Clients)", function()
			local st = GM.Stats()
			local save = { GM.lastEv, GM.readAt, GM.reader, GM.askAt, GM.answerAt, GM.outbox, st.aborted }
			Swap(GM.api, "ah", function() return nil end)
			if GM.api.ahs then Swap(GM.api, "ahs", function() return false end) end   -- v2: liest nicht, wenn AHSentinel geladen ist
			local saveFeed = GM.feedUntil
			GM.feedUntil = nil
			local ok, res = pcall(function()
				GM.askAt, GM.answerAt, GM.outbox = nil, nil, {}
				GM.lastEv, GM.readAt = nil, nil
				GM.OnReplicate()
				local wants = GM.IsShareOn() and GM.readAt ~= nil
				if GM.readAt then GM.readAt = 0 end
				GM.Tick()
				return string.format("Lesen vorgemerkt %s, Leser %s", S(wants or not GM.IsShareOn()), S(GM.reader ~= nil))
			end)
			UnswapAll()
			GM.feedUntil = saveFeed
			GM.lastEv, GM.readAt, GM.reader, GM.askAt, GM.answerAt, GM.outbox, st.aborted = save[1], save[2], save[3], save[4], save[5], save[6], save[7]
			if not ok then return false, "Lua: " .. tostring(res), "kein Fehler" end
			local want = "Lesen vorgemerkt true, Leser false"
			return res == want, res, want
		end)
	end
	C("T-MN4", "U", "Marktdaten-Netz: Zeile im Testbericht und in der Diagnose (ohne Namen)", function()
		local line = ns:MarketLine()
		local pat = "^MARKT%-NETZ: v%d+, [a-z]+, mitgelesene Scans %d+, gesendet %d+ / empfangen %d+, Speicher %d+ KB$"
		local inDiag = false
		for _, l in ipairs(ns.DiagExtra()) do if l == line then inDiag = true end end
		local named = ns.playerName and line:find(ns.playerName, 1, true)
		return line:match(pat) ~= nil and inDiag and not named, line .. (inDiag and " · in der Diagnose" or " · fehlt in der Diagnose"),
			"MARKT-NETZ: Version, an/aus, Scans, gesendet/empfangen, Speicher"
	end)
end

------------------------------------------------------------
-- TR-ALLE (2.5.16): "/ts testroutine alles" – Pausen je Bild, Abbrechen, Ausloggen; Prüfliste im Spiel
------------------------------------------------------------
local function PRUEF()
	C("T-TR1", "U", "Testroutine alles: Abgabe VOR einer Prüfung, sobald 2 ms im Bild verbraucht sind; Bild-Dauer gemessen", function()
		local MaybeYield, Timed = H.MaybeYield, R.Timed
		local keys = { "co", "frameStart", "noYield", "yields", "FRAME_MS", "portions", "portionMax", "portionMaxAt",
			"portionsOver", "slowChecks", "stepStart", "lastCheckId" }
		local save = {}
		for _, k in ipairs(keys) do save[k] = R[k] end
		local clock = 0
		local r = {}
		local ok, err = pcall(function()
			Swap(R, "Now", function() return clock end)   -- eigene Uhr der Routine (keine Blizzard-Funktion)
			R.FRAME_MS = R.FRAME_MS_STD
			R.portions, R.portionMax, R.portionMaxAt, R.portionsOver, R.slowChecks = 0, 0, nil, 0, {}
			-- (1) 3 ms verbraucht, nächste Prüfung braucht 4 ms -> Abgabe VOR ihr, sie läuft im nächsten Bild
			clock = 3
			local ran = false
			local co = coroutine.create(function() Timed("NB1", function() ran = true; clock = clock + 4 end) end)
			R.co, R.frameStart, R.noYield = co, 0, 0
			coroutine.resume(co)
			r[#r + 1] = (coroutine.status(co) == "suspended" and not ran) and "Abgabe vor NB1 (Uhr 3)" or ("keine Abgabe, Uhr " .. clock)
			R.frameStart = clock
			coroutine.resume(co)
			r[#r + 1] = string.format("NB1 im nächsten Bild %s (%d ms)", S(ran), clock - 3)
			-- (2) Gegenprobe alte Regel (5 ms, Abgabe erst danach): keine Abgabe vor NB2 -> Bild 7 ms
			R.FRAME_MS = 5
			clock = 3
			R.stepStart = 0
			local co2 = coroutine.create(function() Timed("NB2", function() clock = clock + 4 end) end)
			R.co, R.frameStart = co2, 0
			coroutine.resume(co2)
			R:PortionDone()
			r[#r + 1] = string.format("alte Regel: Bild %.0f ms, über 5 ms %d", R.portionMax, R.portionsOver)
			R.FRAME_MS = R.FRAME_MS_STD
			-- (3) eine Prüfung allein 6 ms -> mit Namen
			R.co = nil
			Timed("NB3", function() clock = clock + 6 end)
			r[#r + 1] = "allein: " .. table.concat(R.slowChecks, ",")
			-- (4) in WithAPI/Szene nie, ausserhalb der eigenen Coroutine nie
			local co3 = coroutine.create(function() MaybeYield(); return "durch" end)
			R.co, R.frameStart, R.noYield = co3, clock - 10, 1
			local _, res = coroutine.resume(co3)
			R.co, R.noYield = nil, 0
			MaybeYield()
			r[#r + 1] = "Szene " .. S(res) .. ", ausserhalb durch"
			-- (5) die Zusammenfassung nennt das gemessene längste Bild
			local line = string.format(L.TR_SUMMARY, 1, 1, 0, 0, 0, 0, R.portions, R.portionMax, tostring(R.portionMaxAt), R.FRAME_LIMIT, R.portionsOver)
			r[#r + 1] = "Zusammenfassung nennt 7.0 ms " .. S(line:find("7.0", 1, true) ~= nil) .. " bei NB2 " .. S(line:find("NB2", 1, true) ~= nil)
		end)
		UnswapAll()
		for _, k in ipairs(keys) do R[k] = save[k] end
		if not ok then error(err, 0) end
		local got = table.concat(r, " · ")
		local want = "Abgabe vor NB1 (Uhr 3) · NB1 im nächsten Bild true (4 ms) · alte Regel: Bild 7 ms, über 5 ms 1 · allein: NB3 6.0 ms"
			.. " · Szene durch, ausserhalb durch · Zusammenfassung nennt 7.0 ms true bei NB2 true"
		return got == want, got, want
	end)
	C("T-TR4", "U", "Testroutine: Gesamtdauer je Bereich (Summe seiner Bilder) getrennt vom längsten Bild (leistung.md Regel 8)", function()
		local keys = { "portions", "portionMax", "portionMaxAt", "portionsOver", "stepStart", "areaMs", "curLetter", "lastCheckId" }
		local save = {}
		for _, k in ipairs(keys) do save[k] = R[k] end
		local clock = 100
		Swap(R, "Now", function() return clock end)
		local ok, res = pcall(function()
			R.portions, R.portionMax, R.portionMaxAt, R.portionsOver, R.areaMs = 0, 0, nil, 0, {}
			R.curLetter, R.lastCheckId = "B", "B1"
			R.stepStart = clock; clock = clock + 3; R:PortionDone()      -- Bild 1: 3 ms in B
			R.stepStart = clock; clock = clock + 4; R:PortionDone()      -- Bild 2: 4 ms in B
			R.curLetter, R.lastCheckId = "C", "C7"
			R.stepStart = clock; clock = clock + 6; R:PortionDone()      -- Bild 3: 6 ms in C
			local b, c = R.areaMs.B, R.areaMs.C
			return string.format("B %d ms/%d Bilder · C %d ms/%d · längstes %d ms bei %s · über 5 ms %d",
				b.ms, b.frames, c.ms, c.frames, R.portionMax, tostring(R.portionMaxAt), R.portionsOver)
		end)
		UnswapAll()
		for _, k in ipairs(keys) do R[k] = save[k] end
		if not ok then error(res, 0) end
		local want = "B 7 ms/2 Bilder · C 6 ms/1 · längstes 6 ms bei C7 · über 5 ms 1"
		return res == want, res, want
	end)
	C("T-TR2", "U", "Testroutine: 'alles'/'all' startet alles, 'stop' bricht ab (läuft nicht: Hinweis)", function()
		local starts, said = {}, {}
		Swap(R, "Start", function(_, only, alles) starts[#starts + 1] = S(only) .. "/" .. S(alles) end)
		Swap(R, "Say", function(_, m) said[#said + 1] = tostring(m) end)
		local saveRun, saveStop = R.running, R.stopReq
		local ok, err = pcall(function()
			R:Command("alles"); R:Command("all"); R:Command("u")
			R.running = true; R:Command("stop")
			starts[#starts + 1] = "stopReq " .. S(R.stopReq)
			R.stopReq = false
			R.running = false; R:Command("abbrechen")
		end)
		R.running, R.stopReq = saveRun, saveStop
		UnswapAll()
		if not ok then error(err, 0) end
		local got = table.concat(starts, " · ") .. " | " .. S(said[1] == L.TR_STOPPING) .. " " .. S(said[2] == L.TR_NOT_RUNNING)
		local want = "nil/true · nil/true · U/nil · stopReq true | true true"
		return got == want, got, want
	end)
	C("T-TR3", "U", "Testroutine: /reload oder Ausloggen mitten im Lauf – echte Daten zurück; Zusammenfassung mit gemessenem längstem Bild", function()
		local hasLogout = ns:HasHandler("PLAYER_LOGOUT")
		local okF, line = pcall(string.format, L.TR_SUMMARY, 250, 256, 33, 16, 17, 6, 283, 4.2, "T-K2", 5, 0)
		local okP, prog = pcall(string.format, L.TR_PROGRESS, "A", 1, 12)
		local got = string.format("Ausloggen-Handler %s · Zusammenfassung %s · Fortschritt %s", S(hasLogout),
			S(okF and line:find("250", 1, true) ~= nil and line:find("283", 1, true) ~= nil), S(okP and prog:find("12", 1, true) ~= nil))
		local want = "Ausloggen-Handler true · Zusammenfassung true · Fortschritt true"
		return got == want, got, want
	end)

	C("T-D1", "U", "Nachtrag D: Fenster-Prüfung vorgemerkt – gilt höchstens 7 Tage, dann verfällt sie (keine Sperre ohne Zeitlimit)", function()
		local save = ThreatSentinelDB.trPending
		local said = {}
		Swap(R, "Say", function(_, m) said[#said + 1] = tostring(m) end)
		local r = {}
		local ok, err = pcall(function()
			ThreatSentinelDB.trPending = { t = time() - 3600, ref = "Test" }
			r[1] = S(R:PendingWindow() ~= nil)
			ThreatSentinelDB.trPending = { t = time() - (R.PENDING_DAYS * 86400 + 60), ref = "Test" }
			r[2] = S(R:PendingWindow() ~= nil) .. " " .. S(ThreatSentinelDB.trPending == nil) .. " " .. S(said[1] == L.TR_PENDING_EXPIRED)
			ThreatSentinelDB.trPending = nil
			r[3] = S(R:PendingWindow() ~= nil)
		end)
		UnswapAll()
		ThreatSentinelDB.trPending = save
		if not ok then error(err, 0) end
		local got = "1 Std.: " .. r[1] .. " · 7 Tage + 1 Min.: " .. r[2] .. " · nichts vorgemerkt: " .. r[3]
		local want = "1 Std.: true · 7 Tage + 1 Min.: false true true · nichts vorgemerkt: false"
		return got == want, got, want
	end)
	if ns.UICheck and ns.UICheck.Available() then
		C("T-D2", "U", "Nachtrag D: Spielfenster geöffnet -> Fenster-Prüfung läuft von selbst, eigener Bericht, Fenster wieder wie vorher", function()
			local save = ThreatSentinelDB.trPending
			local name = "ThreatSentinelTestSpielfenster"
			local fake = R.fakeBlizz or CreateFrame("Frame", nil, UIParent)
			R.fakeBlizz = fake
			fake:SetSize(300, 300); fake:ClearAllPoints(); fake:SetPoint("CENTER"); fake:Show()
			local checks, said = {}, {}
			local tf, of = ns.Test.frame, ns.Options.frame
			local before = {}
			for _, f in ipairs({ tf, of }) do if f then before[#before + 1] = S(f:IsShown()) .. "/" .. string.format("%.2f", f:GetAlpha()) end end
			rawset(_G, name, fake)
			-- Befund 18.11. (im Spiel "T186=false"): Ergebnis hing von den gerade offenen Fenstern ab (im selben Lauf bewies T-K2
			-- einen vollen Bildschirm). Die Prüfung des MECHANISMUS läuft darum abgeschirmt: nur das Test-"Spielfenster" zählt
			-- (eigene Liste ns.UI_BLIZZARD und die gemeinsame Fensterliste nur für diesen einen, synchronen Aufruf ersetzt, danach zurück).
			local saveBlizz, saveGS = ns.UI_BLIZZARD, rawget(_G, "GoldSentinelUIFrames")
			ns.UI_BLIZZARD = { name }
			rawset(_G, "GoldSentinelUIFrames", {})
			local GT = GoldSentinelTest
			Swap(GT, "Begin", function() return {
				Check = function(_, id, _, _, fn)
					local ok, a, b = pcall(fn)
					checks[#checks + 1] = id .. "=" .. S(ok and a) .. ((ok and a) and "" or (" (" .. Clean(ok and b or a) .. ")"))
				end,
				Finish = function() end } end)
			Swap(R, "Say", function(_, m) said[#said + 1] = tostring(m) end)
			local okC, res = pcall(function()
				ThreatSentinelDB.trPending = { t = time(), ref = "Test" }
				return R:DoCatchUp(name, true)
			end)
			UnswapAll()
			ns.UI_BLIZZARD = saveBlizz
			rawset(_G, "GoldSentinelUIFrames", saveGS)
			rawset(_G, name, nil)
			fake:Hide()
			local after = {}
			for _, f in ipairs({ tf, of }) do if f then after[#after + 1] = S(f:IsShown()) .. "/" .. string.format("%.2f", f:GetAlpha()) end end
			local cleared = ThreatSentinelDB.trPending == nil
			ThreatSentinelDB.trPending = save
			if not okC then return false, Clean(res), "kein Fehler" end
			local got = string.format("Bericht %s · vorgemerkt gelöscht %s · Meldung %s · Fenster wie vorher %s",
				table.concat(checks, ","), S(cleared), S(said[1] and said[1]:find(name, 1, true) ~= nil),
				S(table.concat(before, " ") == table.concat(after, " ")))
			local want = "Bericht T186=true · vorgemerkt gelöscht true · Meldung true · Fenster wie vorher true"
			return got == want, got, want
		end)
	else
		K("T-D2", "U", "Nachtrag D: Spielfenster geöffnet -> Fenster-Prüfung läuft von selbst", "nur im echten Client (Fenster, Rechtecke)")
	end

	C("T-TD1", "U", "Testdaten (18.11.): ThreatSentinelAPI.TestRunning() ist true, solange die eigene Routine Testdaten hat", function()
		local save = ns.routineRunning
		local r1 = ThreatSentinelAPI.TestRunning()
		ns.routineRunning = false
		local r2 = ThreatSentinelAPI.TestRunning()
		ns.routineRunning = save
		local got = "während der Routine " .. S(r1) .. " · danach " .. S(r2)
		return got == "während der Routine true · danach false", got, "während der Routine true · danach false"
	end)
	C("T-TD2", "U", "Testdaten (18.11.): fremde Werte (Markt, TSMess) werden nie gelesen, solange ein anderes Addon testet", function()
		-- ein "anderes Addon im Test": vorhandene API nur ersetzen, sonst vorübergehend eine angelegt (danach wieder weg)
		local name = "RaidMasterAPI"
		local api = rawget(_G, name)
		local made = false
		if type(api) ~= "table" then api = {}; rawset(_G, name, api); made = true end
		local saveF = api.TestRunning
		api.TestRunning = function() return true end
		local byId = {}
		for _, p in ipairs(ns.PL_POINTS) do byId[p.id] = p end
		local ok, res = pcall(function()
			local busy = table.concat(ns:ForeignTestRunning(), ",")
			local line = ns:MarketLine()
			return string.format("testet: %s · Markt-Zeile %s · Prüfliste MARKT %s · TSMESS %s", busy,
				S(line:find("nicht gelesen", 1, true) ~= nil), S(byId.MARKT.auto()), S(byId.TSMESS.auto()))
		end)
		api.TestRunning = saveF
		if made then rawset(_G, name, nil) end
		if not ok then error(res, 0) end
		local busyNow = #ns:ForeignTestRunning()
		local want = "testet: RaidMaster · Markt-Zeile true · Prüfliste MARKT nil · TSMESS nil"
		return res == want and (made == false or busyNow == 0), res, want
	end)

	local PLG = rawget(_G, "GoldSentinelPruefliste")
	C("T-PL1", "U", "Prüfliste: höchstens 14 Punkte, jeder mit Wo / nummerierten Schritten / Kosten / was du siehst", function()
		local bad, ids = {}, {}
		local pts = ns.PL_POINTS or {}
		for _, p in ipairs(pts) do
			local words = 0
			for _ in tostring(p.title or ""):gmatch("%S+") do words = words + 1 end
			local t = tostring(p.todo or "")
			if ids[p.id] then bad[#bad + 1] = p.id .. " doppelt" end
			ids[p.id] = true
			if words == 0 or words > 8 then bad[#bad + 1] = p.id .. " Titel " .. words .. " Wörter" end
			if not t:find("^Wo: ") then bad[#bad + 1] = p.id .. " ohne 'Wo:'" end
			if not t:find("\n1%. ") then bad[#bad + 1] = p.id .. " ohne Schritt 1" end
			if not t:find("\nKosten: ") then bad[#bad + 1] = p.id .. " ohne 'Kosten:'" end
			if tostring(p.expect or "") == "" then bad[#bad + 1] = p.id .. " ohne 'Das musst du sehen'" end
			if not p.since then bad[#bad + 1] = p.id .. " ohne Version" end
			local lines = select(2, t:gsub("\n", "\n")) + 1
			if lines > 7 then bad[#bad + 1] = p.id .. " " .. lines .. " Zeilen" end
		end
		local got = string.format("%d Punkte, %s", #pts, #bad == 0 and "alle vollständig" or table.concat(bad, "; "))
		return #pts >= 1 and #pts <= 14 and #bad == 0, got, "1–14 Punkte, alle vollständig"
	end)
	C("T-PL2", "U", "Prüfliste: nur im Entwicklermodus angemeldet, sonst wirkungslos (kein Treffer, nichts gespeichert)", function()
		if type(PLG) ~= "table" then return false, "GoldSentinelPruefliste fehlt", "geladen" end
		local saveList, saveReg = ns.PL, PLG.lists and PLG.lists.ThreatSentinel
		local saveStore = ThreatSentinelDB.pruefliste
		local r = {}
		local ok, err = pcall(function()
			Swap(ns, "IsDev", function() return false end)
			Swap(PLG, "IsDev", function() return false end)
			r[1] = S(ns:PLRegister()) .. " " .. S(ns:PLHit("TR-ALLE", "x", true))
			UnswapAll()
			Swap(ns, "IsDev", function() return true end)
			-- Befund 18.11.: im Spiel war TR-ALLE schon "erkannt" gespeichert -> Hit lieferte false. Frischer Speicher für die Prüfung.
			ThreatSentinelDB.pruefliste = nil
			local l = ns:PLRegister()
			r[2] = S(l ~= nil) .. " " .. S(l and #l.points)
			ns:PLResetSession()
			r[3] = S(ns:PLHit("TR-ALLE", "Test")) .. " " .. S(ns:PLHit("TR-ALLE", "Test", true)) .. " " .. S(l and (l:State("TR-ALLE")))
			r[4] = S(ns:PLHit("TR-ALLE", "nochmal", true))
			-- neuer Lauf: Zeitpunkt und Notiz werden erneuert (Befund 18.11. Punkt 5); "OK" des Spielers bleibt
			local st = ThreatSentinelDB.pruefliste.p
			st["TR-ALLE"].t = 1
			local saveRun = ns.routineRunning
			ns.routineRunning = false
			r[5] = S(ns:PLRefresh("TR-ALLE", "Lauf 2")) .. " " .. S(st["TR-ALLE"].t > 1) .. " " .. S(st["TR-ALLE"].n)
			l:Set("TR-ALLE", "ok", "Spieler")
			r[6] = S(ns:PLRefresh("TR-ALLE", "Lauf 3")) .. " " .. S(st["TR-ALLE"].s)
			ns.routineRunning = saveRun
		end)
		UnswapAll()
		ns.PL = saveList
		if PLG.lists then PLG.lists.ThreatSentinel = saveReg end
		ThreatSentinelDB.pruefliste = saveStore
		ns:PLResetSession()
		if not ok then error(err, 0) end
		local got = table.concat(r, " · ")
		local want = "nil false · true " .. #ns.PL_POINTS .. " · false true auto · false · true true Lauf 2 · false ok"
		return got == want, got, want
	end)
	C("T-PL3", "U", "Prüfliste: jede Stelle meldet ihren Punkt (Leistung, Spott-Grund, Sync, HUD, Aggrometer, Assistent, Messdaten)", function()
		local hits, seenHit = {}, {}
		local function add(k) if not seenHit[k] then seenHit[k] = true; hits[#hits + 1] = k end end
		local function rec(_, id) add(id) end
		local function fail(_, id) add(id .. "!") end
		local Sy = ns.Sync
		local saveP = {}
		for k, v in pairs(ns.perf) do saveP[k] = v end
		local saveLast, saveRun, savePend, saveCaught = ns.perfLast, ns.routineRunning, Sy.pending, Sy.stats.caught
		local GSS = rawget(_G, "GoldSentinelSync")
		local hadTS = rawget(_G, "TSMessDB")
		local ok, err = pcall(function()
			Swap(ns, "PLHit", rec); Swap(ns, "PLFail", fail)
			Swap(ns, "Diag", function() end); Swap(ns, "Print", function() end)
			-- Leistung: 8 ms -> erledigt, 18 ms -> Fehler
			local t = 50
			Swap(ns, "PerfClock", function() return t end)
			for _, ms in ipairs({ 8, 18 }) do
				ns.PerfStart(); ns.routineRunning = false
				ns.PerfAdd("Test", ms); t = t + 0.02
				ns.routineRunning = saveRun
				ns.PerfStop()
			end
			-- Spott-Grund: bekannt -> erledigt, "anderer Grund" -> Fehler
			local saveExtra = ns.Log.whyExtra
			ns.Log.whyExtra = { ["Testgrund"] = true }
			local known = ns.Log:KnownWhy("Testgrund")
			ns.Log.whyExtra = saveExtra
			ns.Log:WhyCheck(known, "Testgrund")
			ns.Log:WhyCheck(ns.Log:KnownWhy("ganz unbekannte Meldung"), "ganz unbekannte Meldung")
			-- Sync-Test: Antwort kommt
			if type(GSS) == "table" then
				Swap(GSS, "Ping", function(_, cb) cb({ total = 2, guild = 1, group = 1 }) end)
				Sy:PingTest()
			end
			-- Rolle mit Version (alte Version ohne: kein Treffer)
			Sy:Handle("Grimbar", "H:TANK")
			Sy:Handle("Grimbar", "H:TANK:" .. ns.version)
			ns.syncRoles.Grimbar = nil; ns:ClearRoleCache()
			-- nachgeholt
			Sy.pending = { h = "H:TANK:" .. ns.version }
			Swap(Sy, "Send", function() return true end)
			Sy:Flush()
			Sy.pending, Sy.stats.caught = savePend, saveCaught
			-- Assistent: Plaketten-Schritt im Modus ANZEIGE übersprungen
			Swap(ns, "ThreatMode", function() return "DISPLAY" end)
			local step
			for i, st in ipairs(ns.Guide.STEPS) do if st.id == "held" then step = i end end
			Swap(ns.Guide, "Render", function() end)
			local saveGuide, saveStart, saveDone = ns.db.guide, ns.Guide.stepStart, ns.Guide.doneAt
			ns.db.guide = { results = {} }
			local okG, eG = pcall(ns.Guide.Enter, ns.Guide, step)
			ns.db.guide, ns.Guide.stepStart, ns.Guide.doneAt = saveGuide, saveStart, saveDone
			if not okG then error(eG, 0) end
		end)
		UnswapAll()
		for k in pairs(ns.perf) do ns.perf[k] = saveP[k] end
		ns.perfLast, ns.routineRunning, Sy.pending, Sy.stats.caught = saveLast, saveRun, savePend, saveCaught
		ns.syncRoles.Grimbar = nil
		if not ok then error(err, 0) end
		-- Spott des anderen Tanks übernommen (Szene wie T49)
		local sc = Scene.New(1)
		Scene.Hold(sc, "tsfake1", "party1")
		local ok2, err2 = pcall(Scene.Run, sc, function()
			local saveSync = ns.db.sync
			ns.db.sync = true
			Swap(ns, "PLHit", rec)
			Counter(ns.Alerts, "OnLoose", false)
			ns.Sync.claims[sc.units.tsfake1.guid] = { name = "Grimbar", t = GetTime() }
			ns.Threat:Evaluate("tsfake1", ns.mobs.tsfake1)
			ns.Sync.claims[sc.units.tsfake1.guid] = nil
			ns.db.sync = saveSync
			UnswapAll()
		end)
		UnswapAll()
		if not ok2 then error(err2, 0) end
		-- Heiler-HUD im Kampf (Szene wie T-N1a)
		local sc2 = Scene.New(2)
		sc2.tank = false
		sc2.units.player.role = "HEALER"
		Scene.Hold(sc2, "tsfake1", "party1")
		Scene.Hold(sc2, "tsfake2", "party3")
		local ok3, err3 = pcall(Scene.Run, sc2, function()
			local save = { ns.db.hudHealer, ns.db.hud, ns.db.myRole, ns.db.memberView, ns.lastTankT, ns.tankAtPull }
			ns.db.hudHealer, ns.db.hud, ns.db.myRole, ns.db.memberView = true, true, "HEALER", true
			ns.lastTankT, ns.tankAtPull = -1000, false
			ns.simAccess = "open"
			Swap(ns, "PLHit", rec)
			local okT, e = pcall(function() ns.Threat:Tick() end)
			UnswapAll()
			ns.db.hudHealer, ns.db.hud, ns.db.myRole, ns.db.memberView, ns.lastTankT, ns.tankAtPull =
				save[1], save[2], save[3], save[4], save[5], save[6]
			if ns.HUD.f then ns.HUD.f:Hide() end
			if not okT then error(e, 0) end
		end)
		UnswapAll()
		if not ok3 then error(err3, 0) end
		-- Aggrometer ausserhalb des Kampfs (Szene wie T-N1b)
		local sc3 = Scene.New(1)
		sc3.alias.target = "tsfake1"
		sc3.units.player.combat = false
		local ok4, err4 = pcall(Scene.Run, sc3, function()
			local save = { ns.db.meterOnlyCombat, ns.db.meter, ns.db.meterOnlyTank }
			ns.db.meterOnlyCombat, ns.db.meter, ns.db.meterOnlyTank = false, true, false
			ns.simAccess = "open"
			Swap(ns, "PLHit", rec)
			local okM, e = pcall(ns.Meter.Tick, ns.Meter)
			UnswapAll()
			ns.db.meterOnlyCombat, ns.db.meter, ns.db.meterOnlyTank = save[1], save[2], save[3]
			if ns.Meter.f then ns.Meter.f:Hide() end
			if not okM then error(e, 0) end
		end)
		UnswapAll()
		if not ok4 then error(err4, 0) end
		-- Messdaten: auto() der Punkte MARKT und TSMESS
		local byId = {}
		for _, p in ipairs(ns.PL_POINTS) do byId[p.id] = p end
		local GM = rawget(_G, "GoldSentinelMarkt")
		if type(GM) == "table" then
			Swap(GM, "Stats", function() return { scans = 1 } end)
			if byId.MARKT.auto() == true then add("MARKT") end
			UnswapAll()
		end
		if hadTS == nil then
			_G.TSMessDB = { lines = { "1.0|U|target|1|3|100|100|1000|1|1|" } }
			local okA, r = pcall(byId.TSMESS.auto)
			_G.TSMessDB = nil
			if okA and r == true then add("TSMESS") end
		else
			add("TSMESS")   -- echte Messdaten vorhanden: nur lesen, nicht ersetzen
		end
		local got = table.concat(hits, ",")
		local want = "LEISTUNG,LEISTUNG!,SPOTT-GRUND,SPOTT-GRUND!" .. (type(GSS) == "table" and ",SYNC-TEST" or "")
			.. ",SYNC-ROLLE,SYNC-NACH,TESTASSIST,SYNC-SPOTT,HEILER-HUD,METER-KAMPF" .. (type(GM) == "table" and ",MARKT" or "") .. ",TSMESS"
		return got == want, got, want
	end)
end

------------------------------------------------------------
-- Bereich U
------------------------------------------------------------
Area.U = function()
	TU1()
	TU2()
	TU3()
	TU5()
	TU6Tests()
	BL()
	MN()
	SYNC()
	CHATPERF()
	NUTZEN()
	PRUEF()
	TU7()
	local tu4 = TU4Continuation()
	-- zuerst die Zufalls-Portionen (je Bild eine), am Ende die Regressionszählung (braucht alle Ergebnisse)
	return function()
		if tu4() then return true end
		TU6Check()
		return false
	end
end
