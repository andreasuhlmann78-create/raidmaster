-- ThreatSentinel - Alerts.lua
-- Töne, Hinweise in der Bildschirmmitte (mit Wichtigkeit), Chat-Meldungen, Spott-Widerstand
-- mit Ersatz-Spott, Tank kontrolliert, Flächenspott, Notfall, Heiler ausser Reichweite,
-- einmaliger Hinweis auf eine ungebundene Spott-Taste.

local ADDON, ns = ...
local L = ns.L

local A = {}
ns.Alerts = A
table.insert(ns.modules, A)

A.extras = {}

local MEDIA = "Interface\\AddOns\\" .. ADDON .. "\\Media\\"

-- Töne, frei wählbar. Gruppen: eigene ThreatSentinel-Töne, Geräusche (Hupe, Sirene ...),
-- Töne aus WoW und ein eigener Ton (WoW-Sound-ID oder eigene Datei).
-- Eigene kurze Töne (ts_*) klingen anders als DBM/BigWigs-Ansagen und Ready-Checks.
ns.SOUNDS = {
	{ key = "none", group = "ts" },
	{ key = "ts_healer", group = "ts", file = MEDIA .. "healer.ogg" },
	{ key = "ts_dd", group = "ts", file = MEDIA .. "dd.ogg" },
	{ key = "ts_resist", group = "ts", file = MEDIA .. "resist.ogg" },
	{ key = "ts_regain", group = "ts", file = MEDIA .. "regain.ogg" },
	{ key = "ts_warn", group = "ts", file = MEDIA .. "warn.ogg" },
	{ key = "ts_emergency", group = "ts", file = MEDIA .. "emergency.ogg" },
	{ key = "fx_hupe", group = "fx", file = MEDIA .. "fx_hupe.ogg" },
	{ key = "fx_doppelhupe", group = "fx", file = MEDIA .. "fx_doppelhupe.ogg" },
	{ key = "fx_alarmhupe", group = "fx", file = MEDIA .. "fx_alarmhupe.ogg" },
	{ key = "fx_engel", group = "fx", file = MEDIA .. "fx_engel.ogg" },
	{ key = "fx_frosch", group = "fx", file = MEDIA .. "fx_frosch.ogg" },
	{ key = "fx_nebelhorn", group = "fx", file = MEDIA .. "fx_nebelhorn.ogg" },
	{ key = "fx_sirene", group = "fx", file = MEDIA .. "fx_sirene.ogg" },
	{ key = "fx_alarm", group = "fx", file = MEDIA .. "fx_alarm.ogg" },
	{ key = "fx_glocke", group = "fx", file = MEDIA .. "fx_glocke.ogg" },
	{ key = "fx_gong", group = "fx", file = MEDIA .. "fx_gong.ogg" },
	{ key = "fx_pfiff", group = "fx", file = MEDIA .. "fx_pfiff.ogg" },
	{ key = "fx_trommel", group = "fx", file = MEDIA .. "fx_trommel.ogg" },
	{ key = "fx_doppelpiep", group = "fx", file = MEDIA .. "fx_doppelpiep.ogg" },
	{ key = "fx_ping", group = "fx", file = MEDIA .. "fx_ping.ogg" },
	{ key = "raidwarning", group = "wow", kit = "RAID_WARNING", id = 8959 },
	{ key = "readycheck", group = "wow", kit = "READY_CHECK", id = 8960 },
	{ key = "alarm", group = "wow", kit = "ALARM_CLOCK_WARNING_3", id = 12889 },
	{ key = "alarm2", group = "wow", kit = "ALARM_CLOCK_WARNING_2" },
	{ key = "bosswhisper", group = "wow", kit = "UI_RAID_BOSS_WHISPER_WARNING" },
	{ key = "bossemote", group = "wow", kit = "RAID_BOSS_EMOTE_WARNING" },
	{ key = "pvpqueue", group = "wow", kit = "PVP_THROUGH_QUEUE" },
	{ key = "tell", group = "wow", kit = "TELL_MESSAGE" },
	{ key = "mapping", group = "wow", kit = "MAP_PING" },
	{ key = "invite", group = "wow", kit = "IG_PLAYER_INVITE" },
	{ key = "click", group = "wow", kit = "IG_MAINMENU_OPTION_CHECKBOX_ON", id = 856 },
	{ key = "quest", group = "wow", kit = "IG_QUEST_LIST_COMPLETE", id = 878 },
}
ns.SOUND_GROUPS = { "ts", "fx", "wow" }
-- Ordner für eigene Dateien (ausserhalb des Addon-Ordners, damit ein Update sie nicht löscht)
ns.CUSTOM_SOUND_DIR = "Interface\\AddOns\\ThreatSentinel_Sounds\\"
ns.CUSTOM_PREFIX = "custom:"

-- Gibt es den WoW-Ton in diesem Client? (nicht jeder Client kennt jeden Namen)
function ns:SoundAvailable(s)
	if s.file or s.id or s.key == "none" then return true end
	return s.kit and SOUNDKIT and SOUNDKIT[s.kit] ~= nil or false
end

function ns:SoundByKey(key)
	for _, s in ipairs(ns.SOUNDS) do
		if s.key == key then return s end
	end
end

-- Anzeigename eines gespeicherten Tons
function ns:SoundLabel(key)
	if type(key) ~= "string" then return L.SND_none end
	if key:sub(1, #ns.CUSTOM_PREFIX) == ns.CUSTOM_PREFIX then
		return string.format(L.SND_CUSTOM_IS, key:sub(#ns.CUSTOM_PREFIX + 1))
	end
	return L["SND_" .. key] or key
end

-- Eigener Ton: Zahl = WoW-Sound-ID (SoundKit), sonst Datei. Ein Name ohne Pfad liegt im Ordner
-- Interface\AddOns\ThreatSentinel_Sounds, ohne Endung wird .ogg angenommen.
local function CustomPath(text)
	if text:find("[\\/]") then return (text:gsub("/", "\\")) end
	if not text:find("%.%a+$") then text = text .. ".ogg" end
	return ns.CUSTOM_SOUND_DIR .. text
end

local function PlayCustom(text, channel)
	text = strtrim(text or "")
	if text == "" then return nil end
	local n = tonumber(text)
	local ok, willPlay
	if n then
		-- WoW-Sound-ID (z. B. von wowhead.com/sounds); sonst als Datei-ID versuchen
		if ns.Log.on then A.lastSoundFile = "id:" .. n end
		ok, willPlay = pcall(PlaySound, n, channel)
		if not ok or (not ns.IsSecret(willPlay) and not willPlay) then ok, willPlay = pcall(PlaySoundFile, n, channel) end
	else
		local path = CustomPath(text)
		if ns.Log.on then A.lastSoundFile = path:match("[^\\]+$") end
		ok, willPlay = pcall(PlaySoundFile, path, channel)
	end
	return ok, willPlay
end

local lastSound = {}

-- Rückgabe: true/false (vom Spiel abgespielt?) oder nil, wenn nichts versucht wurde
function A:Play(key, throttleKey, force)
	local db = ns.db
	if not key or key == "none" or (not db.sound and not force) then return end
	local now = GetTime()
	local tk = throttleKey or key
	if lastSound[tk] and now - lastSound[tk] < 0.8 then return end
	lastSound[tk] = now
	local channel = db.soundChannel or "Master"
	local ok, willPlay
	if type(key) == "string" and key:sub(1, #ns.CUSTOM_PREFIX) == ns.CUSTOM_PREFIX then
		ok, willPlay = PlayCustom(key:sub(#ns.CUSTOM_PREFIX + 1), channel)
		if ok == nil then return end
	else
		local s = ns:SoundByKey(key)
		if not s then return end
		if s.file then
			if ns.Log.on then A.lastSoundFile = s.file:match("[^\\]+$") end
			ok, willPlay = pcall(PlaySoundFile, s.file, channel)
		else
			local id = (s.kit and SOUNDKIT and SOUNDKIT[s.kit]) or s.id
			if ns.Log.on then A.lastSoundFile = "kit:" .. tostring(id) end
			if not id then return end
			ok, willPlay = pcall(PlaySound, id, channel)
		end
	end
	if not ok or ns.IsSecret(willPlay) then return false end
	return willPlay and true or false
end

-- Wichtigkeit der Meldungen in der Mitte: eine wichtigere wird nicht von einer unwichtigeren verdrängt
local PRIORITY = { aoe = 2, remote = 3, resist = 4, cc = 4, emerg = 5, self = 5, test = 6 }

------------------------------------------------------------
-- Hinweis in der Bildschirmmitte
------------------------------------------------------------
function A:Init()
	if not self.cleuAllowed then ns:Compat("combatlog", "fallback") end
	local f = CreateFrame("Frame", "ThreatSentinelCenter", UIParent)
	f:SetSize(700, 40)
	f:SetFrameStrata("HIGH")
	f.text = f:CreateFontString(nil, "OVERLAY")
	f.text:SetPoint("CENTER")
	-- dunkler Hintergrund, nur während Tests (damit die Meldung auf den Knöpfen lesbar ist)
	f.bg = f:CreateTexture(nil, "BACKGROUND")
	f.bg:SetTexture("Interface\\Buttons\\WHITE8X8")
	f.bg:SetVertexColor(0, 0, 0, 0.7)
	f.bg:SetPoint("TOPLEFT", f.text, "TOPLEFT", -14, 8)
	f.bg:SetPoint("BOTTOMRIGHT", f.text, "BOTTOMRIGHT", 14, -8)
	f.bg:Hide()
	f:Hide()
	f:SetScript("OnUpdate", function(self)
		local left = (self.expire or 0) - GetTime()
		if left <= 0 then
			self:Hide()
		elseif left < 0.4 then
			self:SetAlpha(left / 0.4)
		else
			self:SetAlpha(1)
		end
	end)
	self.center = f
	self:ApplySettings()

	-- Abfrage "Tank kontrolliert" alle 0.1 Sekunden
	local poll = CreateFrame("Frame")
	local acc = 0
	poll:SetScript("OnUpdate", function(_, elapsed)
		acc = acc + elapsed
		if acc < 0.1 then return end
		acc = 0
		A:CheckCC()
	end)
end

function A:ApplySettings()
	local f, db = self.center, ns.db
	if not f then return end
	f:ClearAllPoints()
	f:SetPoint("CENTER", UIParent, "CENTER", 0, db.centerY or 120)
	f.text:SetFont(STANDARD_TEXT_FONT, db.centerSize or 20, "OUTLINE")
end

function A:Center(text, c, duration, key)
	local f = self.center
	if not f then return end
	local now = GetTime()
	if f:IsShown() and (f.expire or 0) > now and f.key ~= key then
		if (PRIORITY[f.key] or 1) > (PRIORITY[key] or 1) then return end
	end
	f.text:SetText(text)
	f.text:SetTextColor(c[1], c[2], c[3])
	-- Tests und Beispiele vor den Einstellungs- und Testfenstern zeigen, sonst unter ihnen
	local testing = key == "test" or (ns.Test and ns.Test.frame and ns.Test.frame:IsShown())
	f:SetFrameStrata(testing and "FULLSCREEN_DIALOG" or "HIGH")
	f.bg:SetShown(testing and true or false)
	f.key = key
	f.expire = now + (duration or 2)
	f:Show()
end

function A:ClearCenter(key)
	if self.center and (not key or self.center.key == key) then self.center:Hide() end
end

-- Chat-Meldung. Kanäle:
--   GROUP  Gruppe/Raid      BOSS  Gruppe/Raid, aber nur im Bosskampf
--   TANKS  nur an andere Tanks (per Tank-Sync, nichts im Chat)
--   SELF   nur an dich      OFF   aus
-- Während Tests geht alles nur an dich.
local function GroupChat(msg, test)
	local ch = ns.db.chatChannel
	if ch == "OFF" or ch == "TANKS" then return end
	if test or ns.Test:IsTesting() then
		ns.Test:Say(L.TEST_CHAT .. " " .. msg)
		return
	end
	if ch == "SELF" or not IsInGroup() then
		if ch == "SELF" then ns:Print(msg) end
		return
	end
	if ch == "BOSS" and not ns:IsBossFight() then return end
	local ok = pcall(SendChatMessage, msg, IsInRaid() and "RAID" or "PARTY")
	-- gesperrt (z. B. in Forever-Instanzen): die anderen Tanks bekommen es trotzdem per Sync
	ns:Compat("chat", ok and "ok" or "off")
end

------------------------------------------------------------
-- Aggro verloren / zurück
------------------------------------------------------------
function A:OnLoose(m)
	if ns.testMode then return end
	local db = ns.db
	if ns.memberNow then
		-- Gruppen-Ansicht (DD / Heiler): nur warnen, wenn ich selbst die Aggro habe
		if m.victimIsMe and db.memberSelfWarn then
			local key = (ns:MyRole() == "HEALER") and db.soundHealer or db.soundDD
			self:Play(key, "selfAggro")
			self:Center(string.format(L.SELF_AGGRO, ns.Safe(m.name, nil) or "?"), db.colorHealer, 2, "self")
		end
		return
	end
	if ns.Guide then ns.Guide:Signal("loose") end
	if m.victimRole == "HEALER" then
		self:Play(db.soundHealer, "looseHealer")
	else
		self:Play(db.soundDD, "looseDD")
	end
end

-- Vorwarnung (gelber Rand): optional ein eigener Ton
function A:OnWarn(m)
	if ns.testMode or ns.memberNow then return end
	local db = ns.db
	if db.soundWarn and db.soundWarn ~= "none" then self:Play(db.soundWarn, "warn") end
end

function A:OnRegain(unit, m)
	ns.Plates:Flash(unit)
	if ns.memberNow then return end
	if ns.Guide and not ns.testMode then ns.Guide:Signal("regain") end
	if ns.db.regainSound and not ns.testMode then self:Play(ns.db.soundRegain, "regain") end
	if ns.db.regainText then self:Center(L.C_REGAIN, ns.db.colorRegain, 1, "regain") end
end

------------------------------------------------------------
-- Auswertung pro Durchlauf (aufgerufen von Threat.lua)
------------------------------------------------------------
function A:Evaluate(loose, heldOnMe)
	local db = ns.db
	wipe(self.extras)
	-- Gruppen-Ansicht: Flächenspott, Notfall und Heiler-Reichweite sind Tank-Hinweise
	if ns.memberNow then
		if self.emergFrame then self.emergFrame:Hide() end
		return
	end
	local inCombat = UnitAffectingCombat("player")

	-- Flächenspott
	if db.aoeHint and ns.aoeSpell and #loose >= db.aoeThreshold and ns.SpellCD(ns.aoeSpell) == 0 then
		self:Center(string.format(L.AOE_HINT, ns.aoeSpell), { 1, 0.5, 0 }, 0.6, "aoe")
	end

	-- Notfall
	if db.emergency and inCombat and heldOnMe >= 1 then
		local hp = self:HealthPercent()
		if hp ~= nil and self.emergFrame then self.emergFrame:Hide() end
		if hp == nil then
			self:EmergencyFallback()
		elseif hp <= db.emergencyHP then
			for _, n in ipairs(ns.defensives) do
				if ns.SpellCD(n) == 0 then
					self:Center(string.format(L.EMERGENCY, n), { 1, 0.2, 0.2 }, 0.6, "emerg")
					if not self.emergShown then
						self.emergShown = true
						self:Play(db.soundEmergency, "emerg")
					end
					break
				end
			end
		else
			self.emergShown = false
		end
	elseif self.emergFrame then
		self.emergFrame:Hide()
	end

	-- Heiler ausser Reichweite
	if db.healerRange and inCombat and IsInGroup() then
		local count = 0
		for _, u in ipairs(ns.groupUnits) do
			if count >= 2 then break end
			if UnitIsPlayer(u) and not UnitIsUnit(u, "player") and UnitIsConnected(u)
				and not UnitIsDeadOrGhost(u) and ns:GetRole(u) == "HEALER" then
				local inRange, checked = UnitInRange(u)
				inRange, checked = ns.Safe(inRange, true), ns.Safe(checked, false)
				if checked and not inRange then
					count = count + 1
					self.extras[#self.extras + 1] = { text = string.format(L.HEALER_OOR, UnitName(u) or "?"), c = { 1, 0.8, 0.2 } }
				end
			end
		end
	end
end

------------------------------------------------------------
-- Eigenes Leben (Notfall). nil = geschützt
------------------------------------------------------------
function A:HealthPercent()
	local hp, max = UnitHealth("player"), UnitHealthMax("player")
	if ns.IsSecret(hp, "health") or ns.IsSecret(max, "health") then return nil end
	ns:Compat("health", "ok")
	if not max or max <= 0 then return 100 end
	return hp / max * 100
end

-- Ersatz für den Notfall-Hinweis, wenn das Leben geschützt ist:
-- Ein Hinweisfenster, dessen Sichtbarkeit das Spiel selbst aus dem geschützten Lebenswert
-- berechnet (Kurve: unter der Schwelle sichtbar, darüber unsichtbar). Das Addon rechnet
-- dabei nie selbst mit dem Wert. Fehlt diese Möglichkeit im Client, ist der Hinweis aus.
function A:EmergencyFallback()
	local db = ns.db
	local spell
	for _, n in ipairs(ns.defensives) do
		if ns.SpellCD(n) == 0 then spell = n break end
	end
	if not spell then
		if self.emergFrame then self.emergFrame:Hide() end
		return
	end
	if self.emergFrame and self.emergFrame.curveHP ~= db.emergencyHP then
		self.emergFrame:Hide()
		self.emergFrame = nil
	end
	if not self.emergFrame and not self.emergFailed then
		local ok = pcall(function()
			local curve = C_CurveUtil.CreateCurve()
			if Enum and Enum.LuaCurveType and curve.SetType then curve:SetType(Enum.LuaCurveType.Step) end
			curve:AddPoint(0, 1)
			curve:AddPoint(db.emergencyHP / 100, 0)
			curve:AddPoint(1, 0)
			local f = CreateFrame("Frame", nil, UIParent)
			f:SetSize(500, 40)
			f:SetFrameStrata("HIGH")
			f.text = f:CreateFontString(nil, "OVERLAY")
			f.text:SetPoint("CENTER")
			f.curve = curve
			f.curveHP = db.emergencyHP
			-- Probe: muss ohne Fehler laufen
			f:SetAlpha(UnitHealthPercent("player", false, curve))
			self.emergFrame = f
		end)
		if not ok then self.emergFailed = true end
	end
	if not self.emergFrame then
		ns:Compat("health", "off")
		return
	end
	ns:Compat("health", "fallback")
	local f = self.emergFrame
	f:ClearAllPoints()
	f:SetPoint("CENTER", UIParent, "CENTER", 0, (db.centerY or 120) - 40)
	f.text:SetFont(STANDARD_TEXT_FONT, db.centerSize or 20, "OUTLINE")
	f.text:SetTextColor(1, 0.2, 0.2)
	f.text:SetText(string.format(L.EMERGENCY, spell))
	pcall(function() f:SetAlpha(UnitHealthPercent("player", false, f.curve)) end)
	f:Show()
end

------------------------------------------------------------
-- Spott widerstanden (Kampflog). Gewirkte Spotts erkennt Tracker.lua.
-- Ohne Kampflog (WoW Forever) prüft Tracker.lua den Widerstand über die Bedrohung.
------------------------------------------------------------
local lastResist = 0

-- Erster bereiter Ersatz-Spott (Krieger: Spöttischer Schlag, sonst Herausforderungsruf / -gebrüll)
function A:ReadyBackup()
	for _, n in ipairs(ns.backupSpells or {}) do
		if n ~= ns.tauntSpell and ns.SpellCD(n) == 0 then return n end
	end
end

function A:OnResist(dstName, dstGUID, test, via)
	local now = GetTime()
	if not test and now - lastResist < 1.5 then return end
	lastResist = now
	if not test and ns.Guide then ns.Guide:Signal("resist") end
	if ns.Log.on then
		pcall(function()
			ns.Log:E("RESIST", "id", ns.Log:Id(dstGUID), "by", UnitName(ns:TankUnit()),
				"via", test and "test" or (via or "log"))
		end)
	end
	local db = ns.db
	self:Play(db.soundResist, test and ("testResist" .. now) or "resist")
	local backup = self:ReadyBackup()
	local text = backup and string.format(L.RESIST_BACKUP, backup) or L.RESIST_SELF
	self:Center(text, { 1, 0.3, 0.3 }, 2, test and "test" or "resist")
	if db.announceResist then GroupChat(string.format(L.MSG_RESIST, dstName or "?"), test) end
	-- Pet-Spott (nur Test) nie an die Gruppe melden
	if not test and ns.tauntMode ~= "pet" then ns.Sync:Send("R:" .. (dstGUID or "")) end
end

-- In Retail/Forever (Clients mit geschützten Werten) ist das Kampflog der Blizzard-Oberfläche
-- vorbehalten: Schon das Anmelden löst "ThreatSentinel wurde geblockt" aus - pcall verhindert das
-- NICHT. Deshalb dort gar nicht anmelden; Widerstand prüft Tracker.lua über die Bedrohung.
-- Erkennung über die Interface-Nummer: Classic Era (115xx) und TBC (205xx) erlaubt,
-- WoW Forever (16001) und Retail (ab 110000) nicht.
A.cleuAllowed = (select(4, GetBuildInfo()) or 0) < 16000
A.cleuRegistered = A.cleuAllowed and ns:On("COMBAT_LOG_EVENT_UNFILTERED", function()
	if not ns.tauntSpell or ns.simSecret or not CombatLogGetCurrentEventInfo then return end
	local ok, _, sub, _, srcGUID, _, _, _, dstGUID, dstName, _, _, _, spellName = pcall(CombatLogGetCurrentEventInfo)
	if not ok then return end
	ns:Compat("combatlog", "ok")
	if ns.tauntMode == "pet" and not ns:PetTankActive() then return end
	local tankGUID = ns.tauntMode == "pet" and UnitGUID("pet") or ns.playerGUID
	if srcGUID ~= tankGUID or spellName ~= ns.tauntSpell then return end
	if sub == "SPELL_MISSED" then A:OnResist(dstName, dstGUID, false, "log") end
end) and true or false

-- Gesperrte Aktionen dieses Addons mitzählen (Diagnose und Bericht)
ns.blocked = {}
local function OnBlocked(_, addon, func)
	if addon ~= ADDON then return end
	ns.blocked[#ns.blocked + 1] = tostring(func or "?")
	ns:ReportError("ADDON_ACTION_BLOCKED: " .. tostring(func or "?"))
end
ns:On("ADDON_ACTION_BLOCKED", OnBlocked)
ns:On("ADDON_ACTION_FORBIDDEN", OnBlocked)

function A:CombatLogWorks()
	return self.cleuRegistered and CombatLogGetCurrentEventInfo ~= nil and not ns.simSecret
end

------------------------------------------------------------
-- Tank kontrolliert
------------------------------------------------------------
function A:GetLossOfControl()
	local ok, text, remaining = pcall(A.ReadLossOfControl)
	if ok then return text, remaining end
end

function A.ReadLossOfControl()
	if C_LossOfControl and C_LossOfControl.GetActiveLossOfControlDataCount then
		local n = ns.Safe(C_LossOfControl.GetActiveLossOfControlDataCount(), 0) or 0
		for i = 1, n do
			local d = C_LossOfControl.GetActiveLossOfControlData(i)
			if type(d) == "table" and not ns.IsSecret(d.locType) and d.locType ~= "SCHOOL_INTERRUPT" then
				return ns.Safe(d.displayText, nil), ns.Safe(d.timeRemaining, nil)
			end
		end
	end
end

function A:AnnounceCC(text, dur, test)
	local db = ns.db
	local msg
	if text and dur then
		msg = string.format(L.MSG_CC_DUR, text, math.floor(dur + 0.5))
	elseif text then
		msg = string.format(L.MSG_CC, text)
	else
		msg = L.MSG_CC_PLAIN
	end
	if db.chatChannel ~= "OFF" or test then
		self:Center(msg, { 1, 0.3, 0.3 }, 2, test and "test" or "cc")
		GroupChat(msg, test)
	end
	if not test then ns.Sync:Send("X:" .. (text or "")) end
end

function A:CheckCC()
	local db = ns.db
	-- "Tank kontrolliert" nur als Tank melden, nie in der Gruppen-Ansicht (DD / Heiler)
	if not db or not db.announceCC or ns.testMode or ns.memberNow or not ns:IsActive() then self.ccState = nil return end
	if not UnitAffectingCombat("player") or UnitIsDeadOrGhost("player") then self.ccState = nil return end
	if ns.Safe(HasFullControl(), true) then self.ccState = nil return end
	if self.ccState then return end
	self.ccState = true

	local text, dur = self:GetLossOfControl()
	if dur and dur < db.ccMinDuration then return end
	self:AnnounceCC(text, dur)
end

------------------------------------------------------------
-- Meldungen von anderen Tanks
------------------------------------------------------------
local function ForMe()
	return ns:IsTankStance() or ns.Test:IsTesting()
end

function A:RemoteResist(name)
	if not ForMe() then return end
	self:Center(string.format(L.REMOTE_RESIST, name), { 1, 0.4, 0.2 }, 2.5, "remote")
	self:Play(ns.db.soundResist, "remoteResist")
end

function A:RemoteCC(name)
	if not ForMe() then return end
	self:Center(string.format(L.REMOTE_CC, name), { 1, 0.4, 0.2 }, 2.5, "remote")
	self:Play(ns.db.soundEmergency, "remoteCC")
end

------------------------------------------------------------
-- Einmaliger Hinweis: Spott-Taste noch nicht belegt
-- erscheint beim ersten Betreten einer Instanz, nie im Kampf, danach nie wieder
------------------------------------------------------------
StaticPopupDialogs["THREATSENTINEL_BINDKEY"] = {
	text = L.KEY_HINT,
	button1 = L.KEY_HINT_YES,
	button2 = L.KEY_HINT_NO,
	OnAccept = function() ns.Options:OpenPage(5) end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
}

local hintPending = false
function A:CheckKeyHint()
	local db = ns.db
	if not db or db.keyHintDone or not ns.tauntSpell or ns.tauntMode == "pet" then return end
	local inInstance = IsInInstance()
	if not inInstance then return end
	if ns.Taunt:GetKey("taunt") then db.keyHintDone = true return end
	if InCombatLockdown() then hintPending = true return end
	hintPending = false
	db.keyHintDone = true
	StaticPopup_Show("THREATSENTINEL_BINDKEY")
	if ns.Log.on then ns.Log:E("KEYHINT", "shown", 1, "where", GetRealZoneText and GetRealZoneText() or "?") end
end

ns:On("PLAYER_ENTERING_WORLD", function()
	C_Timer.After(4, function() A:CheckKeyHint() end)
end)

ns:On("PLAYER_REGEN_ENABLED", function()
	if hintPending then C_Timer.After(1, function() A:CheckKeyHint() end) end
end)
