-- ThreatSentinel - TestRoutine.lua
-- Automatische Testroutine ("auf Herz und Nieren"), nur für den Entwickler (GoldSentinelDev).
--   /ts testroutine            alle Bereiche A bis J
--   /ts testroutine a … j      nur ein Bereich
--   /ts testroutine halb       Liste der halbautomatischen Schritte
--   /ts testroutine letzte     letzten gespeicherten Bericht zeigen
-- Ergebnisse nur über GoldSentinelTest (T:Check / T:Skip / T:Client). IDs wie in testroutine-threatsentinel.txt.
--
-- Regeln (nachtrag-testroutinen.txt):
--   * Keine Blizzard-Funktion wird ersetzt. Ersetzt werden nur Felder eigener Tabellen (ns, Module), immer am Ende
--     des Bereichs zurückgesetzt. Was sich nur über eine ersetzte Blizzard-Funktion prüfen liesse, ist ÜBERSPRUNGEN
--     (mit Grund) oder IM CLIENT PRÜFEN.
--   * Aktionen mit Folgen (Chat, Addon-Nachrichten, CVars, Tastenbelegung, Neuladen, Betrachten, Töne) laufen im
--     Addon über ns.Act. Während der Routine schreibt ns.Act nur mit. Echte Aufrufe werden über hooksecurefunc gezählt
--     (Erwartung 0).
--   * Geschützte Werte: Köderwert ns.testBait, den ns.IsSecret als geschützt erkennt (issecretvalue bleibt unberührt).
--   * Sandbox: ThreatSentinelDB und der Laufzustand werden vorher kopiert und nach jedem Bereich in dieselben Tabellen
--     zurückgeschrieben (ns.db bleibt mit den gespeicherten Daten verbunden).

local ADDON, ns = ...
local L = ns.L

local R = {}
ns.Routine = R

local AREAS = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J" }
R.AREAS = AREAS
local RUN                     -- laufender Durchlauf (GoldSentinelTest-Objekt)

------------------------------------------------------------
-- Hilfen
------------------------------------------------------------
local function InCombat()
	return (InCombatLockdown and InCombatLockdown()) or (UnitAffectingCombat and UnitAffectingCombat("player")) or false
end

local function Ms()
	if debugprofilestop then return debugprofilestop() end
	return GetTime() * 1000
end

local function Copy(v, seen)
	if type(v) ~= "table" then return v end
	seen = seen or {}
	if seen[v] then return seen[v] end
	local t = {}
	seen[v] = t
	for k, x in pairs(v) do t[Copy(k, seen)] = Copy(x, seen) end
	return t
end

local function IsGsKey(k) return type(k) == "string" and k:sub(1, 2) == "gs" end

-- dst in-place auf den Stand von src bringen (dieselben Tabellen bleiben erhalten)
local function RestoreInto(dst, src, top)
	for k in pairs(dst) do
		if src[k] == nil and not (top and IsGsKey(k)) then dst[k] = nil end
	end
	for k, v in pairs(src) do
		if not (top and IsGsKey(k)) then
			if type(v) == "table" and type(dst[k]) == "table" then RestoreInto(dst[k], v)
			else dst[k] = Copy(v) end
		end
	end
end

-- erster abweichender Pfad oder nil
local function Diff(a, b, path, top)
	if type(a) ~= type(b) then return path end
	if type(a) ~= "table" then
		if a ~= b then return path end
		return nil
	end
	for k, v in pairs(a) do
		if not (top and IsGsKey(k)) then
			local d = Diff(v, b[k], path .. "." .. tostring(k))
			if d then return d end
		end
	end
	for k in pairs(b) do
		if not (top and IsGsKey(k)) and a[k] == nil then return path .. "." .. tostring(k) end
	end
	return nil
end

local function Eq(a, b) return a == b end
local function Near(a, b, tol) return type(a) == "number" and type(b) == "number" and math.abs(a - b) <= (tol or 0.01) end
local function S(v) if v == nil then return "nil" end return tostring(v) end

-- Testnamen nie im Bericht (auch erfundene werden durch <Name> ersetzt)
local FAKE = { "Grimbar", "Torben", "Anna" }
local function Clean(v)
	local s = S(v)
	for _, n in ipairs(FAKE) do s = s:gsub(n, "<Name>") end
	if ns.playerName and ns.playerName ~= "" then s = s:gsub(ns.playerName:gsub("%p", "%%%0"), "<Name>") end
	return s
end

------------------------------------------------------------
-- Ersetzen eigener Felder (nie _G, nie Blizzard-Tabellen)
------------------------------------------------------------
local swaps = {}
local function Swap(tbl, key, value)
	assert(type(tbl) == "table" and not rawequal(tbl, _G), "Swap: nur eigene Tabellen")
	swaps[#swaps + 1] = { tbl, key, rawget(tbl, key) }
	tbl[key] = value
end
local function UnswapAll()
	for i = #swaps, 1, -1 do
		local s = swaps[i]
		s[1][s[2]] = s[3]
		swaps[i] = nil
	end
end

------------------------------------------------------------
-- Köderwert für geschützte Werte
------------------------------------------------------------
local function NewBait()
	local p, mt
	if newproxy then
		p = newproxy(true)
		mt = getmetatable(p)
	else
		p, mt = {}, {}
		setmetatable(p, mt)
	end
	local function boom() error("secret value used", 2) end
	for _, k in ipairs({ "__add", "__sub", "__mul", "__div", "__mod", "__unm", "__concat", "__lt", "__le", "__len", "__index", "__newindex", "__call" }) do
		mt[k] = boom
	end
	mt.__tostring = function() return "SECRET" end
	return p
end
local SECRET = NewBait()

------------------------------------------------------------
-- Echte Aktionen zählen (hooksecurefunc ersetzt nichts und verseucht nichts)
------------------------------------------------------------
R.realCalls = 0
local hooked = false
local function InstallHooks()
	if hooked or not hooksecurefunc then return end
	hooked = true
	local function count() if R.inArea then R.realCalls = R.realCalls + 1 end end
	for _, name in ipairs({ "SendChatMessage", "SendAddonMessage", "SetCVar", "SetBinding", "SaveBindings", "NotifyInspect", "Screenshot", "ReloadUI" }) do
		if type(_G[name]) == "function" then pcall(hooksecurefunc, name, count) end
	end
	if C_ChatInfo and type(C_ChatInfo.SendAddonMessage) == "function" then pcall(hooksecurefunc, C_ChatInfo, "SendAddonMessage", count) end
	if C_ChatInfo and type(C_ChatInfo.SendChatMessage) == "function" then pcall(hooksecurefunc, C_ChatInfo, "SendChatMessage", count) end
	if C_CVar and type(C_CVar.SetCVar) == "function" then pcall(hooksecurefunc, C_CVar, "SetCVar", count) end
end

------------------------------------------------------------
-- Sandbox
------------------------------------------------------------
local NS_KEYS = { "testMode", "liveTest", "simSecret", "simAccess", "threatAccess", "isModern", "isRetail", "flavor",
	"errorCount", "lastError", "errorNoticed", "memberNow", "aggroLeader", "tankAtPull", "moveMode", "class",
	"tauntSpell", "tauntMode", "routineSelfTest" }
local NS_TABLES = { "syncRoles", "fakeNames", "cdTrack", "compat", "blocked", "owners" }
local CVARS = { "nameplateShowEnemies", "threatShowNumeric", "threatWarning" }

local function GetCV(name)
	local ok, v
	if C_CVar and C_CVar.GetCVar then ok, v = pcall(C_CVar.GetCVar, name)
	elseif GetCVar then ok, v = pcall(GetCVar, name) end
	if ok then return v end
end

local function ModTables()
	local list = {}
	local TA, Sy, K, DM, A = ns.ThreatAccess, ns.Sync, ns.Track, ns.DmgMeter, ns.Alerts
	if TA then list.TA = { TA, { "checked", "attempts", "announced", "wantBlizzard", "lastProbe", "tempNone" } } end
	if Sy then list.Sync = { Sy, { "claims", "taunts", "cd" } } end
	if K then list.Track = { K, { "sunder", "cc", "ccSince", "ccBreak" } } end
	if DM then list.DM = { DM, { "total", "cur", "showTotal" } } end
	if A then list.Alerts = { A, { "extras" } } end
	if ns.Log then list.Log = { ns.Log, { "on" } } end
	if ns.Specs then list.Specs = { ns.Specs, { "pending", "lastInspect", "failed" } } end
	if ns.Test then list.Test = { ns.Test, { "clientSim" } } end
	return list
end

local function FrameStates()
	local out = {}
	for _, k in ipairs({ "HUD", "Meter", "DD", "DmgMeter" }) do
		local m = ns[k]
		if m and m.f then out[k] = m.f:IsShown() and true or false end
	end
	return out
end

function R:TakeSandbox()
	local sb = { db = {}, ns = {}, nsT = {}, mod = {}, cvars = {}, keys = {} }
	for k, v in pairs(ThreatSentinelDB or {}) do
		if not IsGsKey(k) then sb.db[k] = Copy(v) end
	end
	sb.dbRef, sb.profile = ThreatSentinelDB, ns.db
	for _, k in ipairs(NS_KEYS) do sb.ns[k] = { ns[k] } end
	for _, k in ipairs(NS_TABLES) do sb.nsT[k] = Copy(ns[k] or {}) end
	for name, e in pairs(ModTables()) do
		local saved = {}
		for _, f in ipairs(e[2]) do saved[f] = { Copy(e[1][f]) } end
		sb.mod[name] = saved
	end
	for _, c in ipairs(CVARS) do sb.cvars[c] = GetCV(c) end
	if ns.Taunt and ns.Taunt.BIND and GetBindingKey then
		for which, cmd in pairs(ns.Taunt.BIND) do
			local k1, k2 = GetBindingKey(cmd)
			sb.keys[which] = tostring(k1) .. "/" .. tostring(k2)
		end
	end
	sb.frames = FrameStates()
	self.sb = sb
end

function R:RestoreSandbox()
	local sb = self.sb
	if not sb then return end
	-- gespeicherte Daten: dieselbe Tabelle wie vorher
	ThreatSentinelDB = sb.dbRef
	RestoreInto(ThreatSentinelDB, sb.db, true)
	ns.db = sb.profile
	for _, k in ipairs(NS_KEYS) do ns[k] = sb.ns[k][1] end
	for _, k in ipairs(NS_TABLES) do
		if type(ns[k]) ~= "table" then ns[k] = {} end
		RestoreInto(ns[k], sb.nsT[k])
	end
	for name, e in pairs(ModTables()) do
		local saved = sb.mod[name]
		if saved then
			for f, box in pairs(saved) do
				local v = box[1]
				if type(v) == "table" and type(e[1][f]) == "table" then RestoreInto(e[1][f], v)
				else e[1][f] = Copy(v) end
			end
		end
	end
	if GoldSentinelGame and GoldSentinelGame.SetTestFlavor then pcall(GoldSentinelGame.SetTestFlavor, nil) end
	ns.testBait = nil
	-- Anzeigen wie vorher
	for k, shown in pairs(sb.frames or {}) do
		local m = ns[k]
		if m and m.f then if shown then m.f:Show() else m.f:Hide() end end
	end
	if ns.UpdateSpells then pcall(ns.UpdateSpells, ns) end
end

-- nach der Wiederherstellung: stimmt alles?
function R:CheckSandbox()
	local sb = self.sb
	local d = Diff(ThreatSentinelDB or {}, sb.db, "ThreatSentinelDB", true)
	if d then return false, d end
	if ns.db ~= sb.profile or ThreatSentinelDB ~= sb.dbRef then return false, "ns.db getrennt" end
	if ns.profileName and ThreatSentinelDB.profiles and ThreatSentinelDB.profiles[ns.profileName] ~= ns.db then
		return false, "ns.db ~= profiles[profil]"
	end
	return true
end

function R:CheckCVars()
	for _, c in ipairs(CVARS) do
		if GetCV(c) ~= self.sb.cvars[c] then return false, c end
	end
	return true
end

function R:CheckKeys()
	if not (ns.Taunt and ns.Taunt.BIND and GetBindingKey) then return true end
	for which, cmd in pairs(ns.Taunt.BIND) do
		local k1, k2 = GetBindingKey(cmd)
		local now = tostring(k1) .. "/" .. tostring(k2)
		if now ~= self.sb.keys[which] then return false, which end
	end
	return true
end

------------------------------------------------------------
-- Prüfungen
------------------------------------------------------------
local function C(id, area, name, fn) RUN:Check(id, area, name, fn) end
local function K(id, area, name, why) RUN:Skip(id, area, name, why) end
local function CL(id, area, name, how) RUN:Client(id, area, name, how) end

local NO_STUB = "nur mit ersetzter Blizzard-Funktion prüfbar (verboten, nachtrag Punkt 1) – Nahtstelle ns.API fehlt"

-- Ausgabe einer Funktion abfangen (ns:Print, TM:Say)
local function Capture(fn)
	local lines = {}
	Swap(ns, "Print", function(_, msg) lines[#lines + 1] = tostring(msg) end)
	if ns.Test then Swap(ns.Test, "Say", function(_, msg) lines[#lines + 1] = "[Test] " .. tostring(msg) end) end
	local ok, err = pcall(fn)
	UnswapAll()
	if not ok then error(err, 0) end
	return lines
end

local function Has(lines, text)
	if not text then return false end
	for _, l in ipairs(lines) do if l:find(text, 1, true) then return true end end
	return false
end

local function FormatStem(fmt)
	-- fester Anfang eines Formattexts (bis zum ersten Platzhalter), zum Wiederfinden in der Ausgabe
	return (fmt or ""):match("^([^%%]*)") or ""
end

local function WithFlavor(f, fn)
	local G = GoldSentinelGame
	G.SetTestFlavor(f)
	ns.isModern = G.IsModern and true or false
	local ok, a, b, c = pcall(fn)
	G.SetTestFlavor(nil)
	ns.isModern = G.IsModern and true or false
	if not ok then error(a, 0) end
	return a, b, c
end

------------------------------------------------------------
-- A. Laden und Erkennung
------------------------------------------------------------
local Area = {}

Area.A = function()
	local G = GoldSentinelGame
	C("T01", "A", "Alle Dateien und Module geladen", function()
		local need = { "L", "Game", "Plates", "Donate", "Alerts", "DD", "DmgMeter", "Guide", "HUD", "Log", "Meter", "Mover",
			"Options", "Specs", "Sync", "Taunt", "Test", "Threat", "ThreatAccess", "Track", "Routine" }
		local miss = {}
		for _, k in ipairs(need) do if ns[k] == nil then miss[#miss + 1] = k end end
		if not GoldSentinelTest then miss[#miss + 1] = "GoldSentinelTest" end
		if #miss > 0 then return false, table.concat(miss, ","), "nichts fehlt" end
		return #ns.modules == 16, "#modules=" .. #ns.modules, "16"
	end)
	C("T02", "A", "Version .toc = Code", function()
		local get = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
		local toc = get and get(ADDON, "Version")
		return toc == ns.version, S(toc), ns.version
	end)
	C("T03", "A", "GoldSentinelGame Version 2", function()
		if not G then return false, "fehlt", "vorhanden" end
		local miss = {}
		for _, k in ipairs({ "flavor", "IsModern", "IsOldAPI", "HasSecrets", "IsSecret", "AnySecret", "Safe", "InCombat",
			"Short", "CleanName", "SameName", "Status", "SetTestFlavor", "Recalc" }) do
			if G[k] == nil then miss[#miss + 1] = k end
		end
		for _, k in ipairs({ "IsEra", "IsForever", "IsTBC", "IsWrath", "IsTitan", "IsCata", "IsMists", "IsRetail" }) do
			if G[k] == nil then miss[#miss + 1] = k end
		end
		if #miss > 0 then return false, table.concat(miss, ","), "alles vorhanden" end
		if G.version ~= 2 or G.apiVersion ~= 2 then return false, S(G.version) .. "/" .. S(G.apiVersion), "2/2" end
		return ns.Game == G and type(G.Status()) == "string", "ns.Game", "GoldSentinelGame"
	end)
	C("T04", "A", "Erkennung echt", function()
		local A, DM, TA = ns.Alerts, ns.DmgMeter, ns.ThreatAccess
		if ns.isModern ~= (G.IsModern and true or false) then return false, "isModern " .. S(ns.isModern), S(G.IsModern) end
		if ns.isRetail ~= (G.IsRetail and true or false) then return false, "isRetail " .. S(ns.isRetail), S(G.IsRetail) end
		if ns.flavor ~= G.flavor then return false, S(ns.flavor), S(G.flavor) end
		if A.cleuAllowed ~= (not ns.isModern) or A.cleuRegistered ~= A.cleuAllowed then return false, "cleu " .. S(A.cleuAllowed) .. "/" .. S(A.cleuRegistered), S(not ns.isModern) end
		if DM.allowed ~= (not ns.isModern) then return false, "DM.allowed " .. S(DM.allowed), S(not ns.isModern) end
		if not ns.isModern and (ns.threatAccess ~= "open" or TA.checked ~= true) then return false, S(ns.threatAccess) .. "/" .. S(TA.checked), "open/true" end
		return true, (ns.isModern and "modern" or "alt") .. "/" .. S(ns.flavor)
	end)
	C("T05", "A", "Simulation G.SetTestFlavor – GoldSentinelGame", function()
		local want = { forever = { "IsForever", "IsModern" }, era = { "IsEra", "IsOldAPI" }, tbc = { "IsTBC", "IsOldAPI" }, retail = { "IsRetail", "IsModern" } }
		local bad
		for f, keys in pairs(want) do
			G.SetTestFlavor(f)
			for _, k in ipairs(keys) do if not G[k] then bad = f .. ":" .. k end end
			if not (tostring(G.Status()):lower()):find("[test]", 1, true) then bad = f .. ":Status ohne [Test]" end
			G.SetTestFlavor(nil)
			if bad then break end
		end
		return bad == nil, bad or "ok", "alle Simulationen richtig"
	end)
	C("T06", "A", "Simulation – Weichen des Addons (ohne Kampfsperre-Teile)", function()
		local db, cls = ns.db, ns.class
		local saveAcc, saveMode = ns.threatAccess, db.threatMode
		local bad
		for _, f in ipairs({ "forever", "era", "tbc", "retail" }) do
			WithFlavor(f, function()
				local modern = ns.isModern
				ns.threatAccess = "unknown"
				db.threatMode = "AUTO"
				if ns:ThreatMode() ~= "FULL" then bad = f .. ": unknown ausserhalb Kampf " .. ns:ThreatMode() end
				db.threatMode = "DISPLAY"
				local m = ns:ThreatMode()
				if modern and m ~= "DISPLAY" then bad = f .. ": DISPLAY erzwungen -> " .. m end
				if not modern and m ~= "FULL" then bad = f .. ": alt DISPLAY -> " .. m end
				ns.class = "DRUID"
				local t = ns:DeficitText()
				if modern and t ~= L.DEFICIT_OTHER then bad = f .. ": Druide " .. S(t) end
				if not modern and t ~= L.DEFICIT_DRUID then bad = f .. ": Druide " .. S(t) end
				ns.class = cls
			end)
			ns.threatAccess, db.threatMode = saveAcc, saveMode
			if bad then break end
		end
		ns.class = cls
		return bad == nil, bad or "ok", "Weichen wie angegeben"
	end)
	C("T07", "A", "Beim Laden festgelegte Weichen bleiben", function()
		local A, DM = ns.Alerts, ns.DmgMeter
		local a1, a2, a3 = A.cleuAllowed, A.cleuRegistered, DM.allowed
		local b1, b2, b3 = WithFlavor(ns.isModern and "era" or "forever", function() return A.cleuAllowed, A.cleuRegistered, DM.allowed end)
		return a1 == b1 and a2 == b2 and a3 == b3, "Kampflog/Meter: Simulation erst nach /reload", "unverändert"
	end)
	C("T08", "A", "Weichen wieder echt", function()
		G.SetTestFlavor(nil)
		local st = tostring(G.Status())
		return ns.isModern == (G.IsModern and true or false) and not st:lower():find("[test]", 1, true), S(ns.isModern), S(G.IsModern)
	end)
	C("T09", "A", "Ereignisse angemeldet", function()
		local miss = {}
		for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "NAME_PLATE_UNIT_ADDED",
			"NAME_PLATE_UNIT_REMOVED", "UNIT_THREAT_LIST_UPDATE", "CHAT_MSG_ADDON", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_HEALTH",
			"GROUP_ROSTER_UPDATE", "UNIT_PET", "UNIT_AURA", "UPDATE_SHAPESHIFT_FORM", "ADDON_ACTION_BLOCKED", "ADDON_ACTION_FORBIDDEN",
			"SPELLS_CHANGED", "INSPECT_READY" }) do
			if not ns:HasHandler(e) then miss[#miss + 1] = e end
		end
		if #miss > 0 then return false, table.concat(miss, ","), "alle angemeldet" end
		local cleu = ns:HasHandler("COMBAT_LOG_EVENT_UNFILTERED")
		if cleu ~= (not ns.isModern) then return false, "Kampflog " .. S(cleu), S(not ns.isModern) end
		local okOn, res = pcall(ns.On, ns, "TS_GIBT_ES_NICHT", function() end)
		return okOn and res == false, S(res), "false"
	end)
	C("T10", "A", "Befehle angemeldet", function()
		return SLASH_THREATSENTINEL1 == "/ts" and SLASH_THREATSENTINEL2 == "/threatsentinel"
			and type(SlashCmdList.THREATSENTINEL) == "function" and SlashCmdList.GOLDSENTINELGAME ~= nil
			and SlashCmdList.GOLDSENTINELDEV ~= nil, "ok", "/ts, /threatsentinel, /gsgame, /gsdev"
	end)
	CL("T11", "A", "Interface-Nummer des Clients in der .toc", "Interface steht in der Kopfzeile des Berichts; die Prüf-Sitzung vergleicht sie mit ## Interface (am Launch-Tag /dump select(4, GetBuildInfo()))")
end

------------------------------------------------------------
-- B. Jede Funktion des Addons
------------------------------------------------------------
Area.B = function()
	local TA, A, Sy = ns.ThreatAccess, ns.Alerts, ns.Sync
	C("T12", "B", "ns.IsSecret / ns.Safe", function()
		ns.testBait = SECRET
		ns.simSecret = true
		local r = { ns.IsSecret(5, "auras"), ns.IsSecret(nil, "auras"), ns.IsSecret(5), ns.IsSecret(5, "gibtsnicht") }
		local s1, s2 = ns.Safe(5, 0, "auras")
		ns.simSecret = false
		local s3, s4 = ns.Safe(5, 0, "auras")
		local bait = ns.IsSecret(SECRET) and ns.IsSecret(SECRET, "auras")
		ns.testBait = nil
		local ok = r[1] == true and r[2] == false and r[3] == false and r[4] == false and s1 == 0 and s2 == true
			and s3 == 5 and s4 == false and bait
		return ok, string.format("%s %s %s %s | %s %s | %s %s | Köder %s", S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(s1), S(s2), S(s3), S(s4), S(bait)),
			"true false false false | 0 true | 5 false | Köder true"
	end)
	C("T13", "B", "ns:Compat / ResetCompat", function()
		ns:Compat("guid", "ok"); ns:Compat("guid", "off"); ns:Compat("guid", "ok")
		local c = ns.compat.guid
		local ok = c and c.mode == "ok" and c.worst == "off"
		ns:ResetCompat()
		return ok and next(ns.compat) == nil, c and (c.mode .. "/" .. c.worst), "ok/off, danach leer"
	end)
	C("T14", "B", "ns.SpellName / ns.SpellIcon", function()
		return ns.SpellName(355) ~= nil and ns.SpellIcon(355) ~= nil, "355", "Name und Symbol"
	end)
	K("T15", "B", "ReadCooldown / ns.SpellCD", NO_STUB .. " (GetSpellCooldown)")
	C("T16", "B", "ns:BaseCooldown (gelernter Wert hat Vorrang)", function()
		ns.db.cdLearned = ns.db.cdLearned or {}
		ns.db.cdLearned.TestSpott = 7
		local v = ns:BaseCooldown("TestSpott")
		ns.db.cdLearned.TestSpott = nil
		local none = ns:BaseCooldown("GibtsNicht")
		return v == 7 and none == nil, S(v) .. "/" .. S(none), "7/nil"
	end)
	K("T17", "B", "ns.SpellInRange", NO_STUB .. " (IsSpellInRange)")
	K("T18", "B", "ns.Aura / ns:FindAura", NO_STUB .. " (UnitBuff/UnitDebuff, C_UnitAuras)")
	K("T19", "B", "ns:MobKey", NO_STUB .. " (UnitGUID)")
	C("T20", "B", "ns:SameUnit (echte Einheiten)", function()
		local a, b = ns:SameUnit("player", "player"), ns:SameUnit("player", "tsfake1")
		return a == true and b == false, S(a) .. "/" .. S(b), "true/false"
	end)
	C("T21", "B", "ns:SpellbookHas mit leerem Namen", function()
		local a, b = ns:SpellbookHas(""), ns:SpellbookHas(nil)
		return not a and not b, S(a) .. "/" .. S(b), "false/false"
	end)
	C("T22", "B", "ns:FullName (eigener Charakter)", function()
		local n = ns:FullName("player")
		return type(n) == "string" and n ~= "" and not n:find("-", 1, true), type(n) == "string" and "<Name>" or S(n), "<Name> ohne Realm"
	end)
	C("T23", "B", "ns:FormName / ns:SpecName", function()
		local a, b = ns:FormName(), ns:SpecName()
		return type(a) == "string" and type(b) == "string", "Text", "Text"
	end)
	C("T24", "B", "ns:UpdateSpells mit eigenem Spott", function()
		ns.db.tauntOverride = "TestSpott"
		ns:UpdateSpells()
		local ok = ns.tauntSpell == "TestSpott" and ns.tauntMode == "hostile"
		local got = S(ns.tauntSpell) .. "/" .. S(ns.tauntMode)
		ns.db.tauntOverride = ""
		ns:UpdateSpells()
		return ok, got, "TestSpott/hostile"
	end)
	C("T26", "B", "IsTankStance liefert einen Wahrheitswert", function()
		local v = ns:IsTankStance()
		return v == true or v == false, S(v), "true/false"
	end)
	C("T27", "B", "TankUnit / PetTankActive", function()
		local u = ns:TankUnit()
		local p = ns:PetTankActive()
		if ns.tauntMode ~= "pet" and p then return false, "PetTankActive true", "nur bei Pet-Spott" end
		return u == "player" or u == "pet", S(u), "player/pet"
	end)
	C("T28", "B", "IsActive / IsMemberMode", function()
		ns.db.enabled = false
		local a = ns:IsActive()
		local m = ns:IsMemberMode()
		ns.db.enabled = true
		ns.testMode = true
		local b = ns:IsActive()
		local mb = ns:IsMemberMode()
		ns.testMode = false
		return a == false and m == false and b == true and mb == false, S(a) .. S(m) .. S(b) .. S(mb), "false false true false"
	end)
	C("T31", "B", "MyRole / GetRole", function()
		ns.db.myRole = "HEALER"
		local r1 = ns:IsTankStance() and "TANK" or ns:MyRole()
		ns.db.myRole = "DAMAGER"
		local r2 = ns:IsTankStance() and "TANK" or ns:MyRole()
		ns:ClearRoleCache()
		local g = ns:GetRole("player")
		local okG = g == "TANK" or g == "HEALER" or g == "DAMAGER" or g == "PET"
		return (r1 == "HEALER" or r1 == "TANK") and (r2 == "DAMAGER" or r2 == "TANK") and okG, S(r1) .. "/" .. S(r2) .. "/" .. S(g), "HEALER/DAMAGER/Rolle"
	end)
	C("T32", "B", "Profile: geteiltes Profil (ReloadUI nur mitgeschrieben)", function()
		local before = ns.actLog.n.reload or 0
		ns:UseSharedProfile(true)
		local a = ThreatSentinelDB.chars[ns.charKey] == "Global" and ThreatSentinelDB.profiles.Global ~= nil and ns:IsSharedProfile()
		ns:UseSharedProfile(false)
		local b = ThreatSentinelDB.chars[ns.charKey] == ns.charKey and not ns:IsSharedProfile()
		local n = (ns.actLog.n.reload or 0) - before
		return a and b and n == 2, "ReloadUI " .. n .. "x mitgeschrieben", "2x, Profile richtig"
	end)
	C("T33", "B", "Voreinstellungen", function()
		for name, p in pairs(ns.PRESETS) do
			ns:ApplyPreset(name)
			for k, v in pairs(p) do if ns.db[k] ~= v then return false, name .. "." .. k, S(v) end end
		end
		local before = Copy(ns.db)
		ns:ApplyPreset("gibtsnicht")
		local d = Diff(ns.db, before, "db")
		return d == nil, d or "ok", "unverändert"
	end)
	C("T34", "B", "Positionen zurücksetzen", function()
		ns:ResetPositions()
		for _, k in ipairs({ "hudPoint", "ddPoint", "meterPoint", "dmgPoint" }) do
			if ns.db[k] == ns.defaults[k] then return false, k .. " dieselbe Tabelle", "Kopie" end
			if Diff(ns.db[k], ns.defaults[k], k) then return false, k, "wie Standard" end
		end
		return true
	end)
	C("T35", "B", "ns:IsBossFight ohne Fehler", function()
		local v = ns:IsBossFight()
		return v == true or v == false, S(v), "true/false"
	end)
	C("T36", "B", "Slash-Unterbefehle", function()
		local hits = {}
		local function mark(n) return function() hits[#hits + 1] = n end end
		Swap(ns.Log, "Command", mark("log")); Swap(ns.Test, "ToggleWindow", mark("test")); Swap(ns.Guide, "Start", mark("guide"))
		Swap(ns.Donate, "Show", mark("donate")); Swap(ns.ThreatAccess, "Report", mark("threat")); Swap(ns.Mover, "Toggle", mark("move"))
		Swap(ns.Options, "Toggle", mark("options")); Swap(ns.Routine, "Command", mark("routine"))
		local cases = { { "log status", "log" }, { "test", "test" }, { "guide", "guide" }, { "assistent", "guide" }, { "spenden", "donate" },
			{ "donate", "donate" }, { "support", "donate" }, { "bedrohung", "threat" }, { "threat", "threat" }, { "BEDROHUNG", "threat" },
			{ "verschieben", "move" }, { "move", "move" }, { "", "options" }, { "unbekannt", "options" }, { "testroutine x", "routine" } }
		local bad
		for _, c in ipairs(cases) do
			wipe(hits)
			SlashCmdList.THREATSENTINEL(c[1])
			if #hits ~= 1 or hits[1] ~= c[2] then bad = "'" .. c[1] .. "' -> " .. table.concat(hits, ",") break end
		end
		UnswapAll()
		return bad == nil, bad or "ok", "genau das richtige Ziel 1x"
	end)
	C("T37", "B", "ns:ThreatMode – Tabelle (ausserhalb des Kampfs)", function()
		local save = { ns.simAccess, ns.threatAccess, ns.db.threatMode, ns.isModern }
		local bad
		local function want(sim, acc, mode, modern, exp)
			ns.simAccess, ns.threatAccess, ns.db.threatMode, ns.isModern = sim, acc, mode, modern
			local m = ns:ThreatMode()
			if m ~= exp then bad = string.format("%s/%s/%s/%s -> %s", S(sim), S(acc), S(mode), S(modern), m) end
		end
		want("none", "open", "AUTO", true, "OFF"); want("secret", "open", "AUTO", true, "DISPLAY"); want("open", "open", "AUTO", true, "FULL")
		want(nil, "secret", "AUTO", true, "DISPLAY"); want(nil, "none", "AUTO", true, "OFF")
		want(nil, "open", "DISPLAY", true, "DISPLAY"); want(nil, "open", "DISPLAY", false, "FULL")
		want("open", "secret", "AUTO", true, "DISPLAY")   -- T173: Simulation "lesbar" übersteuert keine echte Sperre
		ns.simAccess, ns.threatAccess, ns.db.threatMode, ns.isModern = save[1], save[2], save[3], save[4]
		return bad == nil, bad or "ok", "Tabelle wie angegeben"
	end)
	C("T38", "B", "TA:ModeText", function()
		for _, m in ipairs({ "FULL", "DISPLAY", "OFF" }) do
			local t = TA:ModeText(m)
			if not t or t:find("^TA_MODE_") then return false, m .. " -> " .. S(t), "Text" end
		end
		return true
	end)
	C("T39", "B", "TA:Read ohne Ziel (echte API)", function()
		local f, s, miss = TA:Read("tsfake1")
		if not UnitDetailedThreatSituation and not UnitThreatSituation then return miss == true, S(miss), "missing" end
		return f == false and s == false and miss == false, S(f) .. S(s) .. S(miss), "false false false"
	end)
	C("T40", "B", "TA:Probe ohne Kampf ohne Wirkung", function()
		local before = { TA.checked, TA.attempts, ns.threatAccess }
		TA.checked = false
		TA:Probe({ "tsfake1" })
		local after = { TA.attempts, ns.threatAccess }
		return after[1] == before[2] and after[2] == before[3], S(after[1]) .. "/" .. S(after[2]), "unverändert"
	end)
	C("T42", "B", "TA:Set / Store", function()
		local shown = 0
		Swap(A, "Center", function(_, text) if text == L.TA_NOTE_DISPLAY then shown = shown + 1 end end)
		TA.announced = false
		ns.db.enabled = true
		TA:Set("secret")
		TA:Set("secret")
		UnswapAll()
		local st = ThreatSentinelDB.threatAccess
		local ok = ns.threatAccess == "secret" and TA.checked == true and type(st) == "table" and st.state == "secret"
			and type(st.date) == "string" and st.date:match("^%d%d%d%d%-%d%d%-%d%d %d%d:%d%d$") and type(st.build) == "string"
			and st.build:find("%(") and shown == 1
		return ok and true or false, string.format("%s, Hinweis %dx, %s", S(ns.threatAccess), shown, S(st and st.date)), "secret, Hinweis 1x, JJJJ-MM-TT HH:MM"
	end)
	C("T43", "B", "Neuer Kampf setzt die Prüfung zurück", function()
		TA.checked, TA.attempts, TA.announced = true, 5, true
		ns:Fire("PLAYER_REGEN_DISABLED")
		local got = S(TA.checked) .. "/" .. S(TA.attempts) .. "/" .. S(TA.announced)
		if ns.isModern then return TA.checked == false and TA.attempts == 0 and TA.announced == false, got, "false/0/false" end
		return TA.checked == true and TA.attempts == 5, got, "unverändert (alte API)"
	end)
	C("T44", "B", "ApplyBlizzard nur mitgeschrieben", function()
		local before = ns.actLog.n.cvar or 0
		ns.db.enabled, ns.db.blizzThreat = true, false
		TA.wantBlizzard = true
		TA:ApplyBlizzard()
		local n1 = (ns.actLog.n.cvar or 0) - before
		return n1 == 0 and TA.wantBlizzard == true, "blizzThreat aus: " .. n1 .. " CVar", "0, Wunsch bleibt"
	end)
	C("T45", "B", "Bedrohung prüfen – ausserhalb des Kampfs", function()
		local lines = Capture(function() TA:Report() end)
		local ok = Has(lines, FormatStem(L.TA_R_MODE)) and Has(lines, L.TA_R_NOCOMBAT) and Has(lines, FormatStem(L.TA_R_ERRORS))
			and (ns.isModern or Has(lines, L.TA_R_OLDAPI))
			and (Has(lines, FormatStem(L.TA_R_LAST)) or Has(lines, L.TA_R_NEVER))
		return ok, #lines .. " Zeilen", "Modus, Status, ausserhalb Kampf, zuletzt, Fehler"
	end)
	CL("T46", "B", "Bedrohung prüfen – im Kampf", "Mob angreifen, im Kampf /ts bedrohung: Status und Prozent (oder 'geschützt') erscheinen, kein Lua-Fehler")
	C("T47", "B", "TA:Login übernimmt den gespeicherten Zustand", function()
		local bad
		for _, c in ipairs({ { "open", "open" }, { "secret", "secret" }, { "none", "unknown" } }) do
			ThreatSentinelDB.threatAccess = { state = c[1], date = "2026-11-03 10:00", build = "x (1)" }
			ns.threatAccess = ns.isModern and "unknown" or "open"
			TA:Login()
			local exp = ns.isModern and c[2] or "open"
			if ns.threatAccess ~= exp then bad = c[1] .. " -> " .. S(ns.threatAccess) end
		end
		return bad == nil, bad or "ok", "open/secret übernommen, none nicht (alt immer open)"
	end)
	C("T51", "B", "Reihenfolge loser Mobs (SortLoose)", function()
		local list = {
			{ id = 1, mark = 0, victimRole = "DAMAGER", looseSince = 1 },
			{ id = 2, mark = 7, victimRole = "DAMAGER", looseSince = 5 },
			{ id = 3, mark = 8, victimRole = "DAMAGER", looseSince = 9 },
			{ id = 4, mark = 0, victimRole = "HEALER", looseSince = 8 },
			{ id = 5, mark = 0, victimRole = "DAMAGER", looseSince = 0 },
		}
		table.sort(list, ns.Threat.SortLoose)
		local ids = {}
		for i, e in ipairs(list) do ids[i] = e.id end
		local got = table.concat(ids, ",")
		return got == "3,2,4,5,1", got, "3,2,4,5,1"
	end)
	C("T60", "B", "Initial", function()
		local I = ns.Plates._Initial
		ns.testBait = SECRET
		local r = { I("Grimbar"), I("ärger"), I(""), I(nil), I(SECRET) }
		ns.testBait = nil
		-- string.upper kennt im Spiel keine Umlaute: "ä" bleibt "ä" (erlaubt); wichtig ist ein ganzes UTF-8-Zeichen
		local uml = r[2] == "Ä" or r[2] == "ä"
		return r[1] == "G" and uml and r[3] == "" and r[4] == "" and r[5] == "", r[1] .. "|" .. r[2] .. "|" .. r[3] .. "|" .. r[4] .. "|" .. r[5], "G|Ä|||"
	end)
	C("T62", "B", "Töne: Liste und Play (nur mitgeschrieben)", function()
		local bad
		for _, s in ipairs(ns.SOUNDS) do
			if s.key and ns:SoundByKey(s.key) ~= s then bad = "SoundByKey " .. s.key break end
			local lbl = ns:SoundLabel(s.key)
			if not lbl or lbl == s.key and s.key ~= "none" then bad = "SoundLabel " .. s.key break end
		end
		if bad then return false, bad, "jeder Ton auffindbar" end
		local r1 = A:Play("none", "trTest1")
		local before = ns.actLog.n.sound or 0
		ns.db.sound = true
		A:Play("fx_frosch", "trTest2" .. GetTime(), true)
		local n = (ns.actLog.n.sound or 0) - before
		return r1 == nil and n >= 1, "none -> " .. S(r1) .. ", Ton mitgeschrieben " .. n .. "x", "nil, mitgeschrieben"
	end)
	C("T63", "B", "Meldung in der Mitte: Vorrang", function()
		if not A.center then return false, "kein Rahmen", "Rahmen" end
		A:Center("tr-test", { 1, 1, 1 }, 2, "test")
		A:Center("tr-aoe", { 1, 1, 1 }, 2, "aoe")
		local t = A.center.text:GetText()
		A:ClearCenter("aoe")
		local still = A.center:IsShown()
		A:ClearCenter("test")
		return t == "tr-test" and still, S(t) .. "/" .. S(still), "tr-test/true"
	end)
	C("T64", "B", "Chat-Kanäle gehen nie hinaus", function()
		local before = ns.actLog.n.chat or 0
		local said = 0
		local lines
		for _, ch in ipairs({ "TANKS", "BOSS", "GROUP", "SELF", "OFF" }) do
			ns.db.chatChannel = ch
			ns.db.announceResist = true
			lines = Capture(function() A:OnResist("Grimbar", nil, true); A:AnnounceCC(nil, nil, true) end)
			for _, l in ipairs(lines) do if l:find(L.TEST_CHAT, 1, true) then said = said + 1 end end
		end
		local n = (ns.actLog.n.chat or 0) - before
		return n == 0 and said > 0, "Chat " .. n .. "x, Test-Zeilen " .. said, "0x, nur an dich"
	end)
	C("T73", "B", "Sync:Handle", function()
		Sy:Handle("Grimbar", "H:TANK:2.4.1")
		local r = ns.syncRoles.Grimbar
		local a = r and r.role == "TANK" and r.ver == "2.4.1"
		Sy:Handle("Grimbar", "T:Creature-1:10")
		local c = Sy.claims["Creature-1"]
		local b = c and c.name == "Grimbar" and Sy.cd.Grimbar and Near(Sy.cd.Grimbar - GetTime(), 10, 0.5)
		Sy.claims["-"] = nil
		Sy:Handle("Grimbar", "T:-:5")
		local d = Sy.claims["-"] == nil
		Sy:Handle("Grimbar", "kaputt"); Sy:Handle("Grimbar", nil)
		return (a and b and d) and true or false, S(a) .. "/" .. S(b) .. "/" .. S(d), "true/true/true"
	end)
	C("T74", "B", "Sync:Send (nur mitgeschrieben)", function()
		ns.db.sync = false
		local r0 = Sy:Send("H:TEST")
		ns.db.sync = true
		local before = ns.actLog.n.addonmsg or 0
		local r1 = Sy:Send("H:TEST")
		local n = (ns.actLog.n.addonmsg or 0) - before
		if IsInGroup() then
			return r0 == nil and r1 == true and n == 1, S(r0) .. "/" .. S(r1) .. "/" .. n, "nil/true/1 (mitgeschrieben)"
		end
		return r0 == nil and r1 == nil and n == 0, S(r0) .. "/" .. S(r1) .. "/" .. n, "nil/nil/0 (keine Gruppe)"
	end)
	C("T75", "B", "Tank-Liste", function()
		ns.syncRoles.Grimbar = { role = "TANK", t = GetTime() }
		ns.fakeNames.Grimbar = true   -- wie die Testzentrale: erfundener Tank gilt als in der Gruppe
		local a = Sy:IsTank("Grimbar")
		local list = Sy:Tanks()
		local has = false
		for _, n in ipairs(list or {}) do if n == "Grimbar" then has = true end end
		ns.db.sync = false
		local n0 = Sy:NumTanks()
		ns.db.sync = true
		return a and has and n0 == 0, S(a) .. "/" .. S(has) .. "/" .. S(n0), "true/true/0"
	end)
	C("T76", "B", "Addon-Nachrichten: falscher Prefix und geschützter Absender", function()
		ns.syncRoles.Grimbar = nil
		ns.testBait = SECRET
		ns:Fire("CHAT_MSG_ADDON", "FremdesAddon", "H:TANK:1", "PARTY", "Grimbar")
		ns:Fire("CHAT_MSG_ADDON", Sy.PREFIX, SECRET, "PARTY", "Grimbar")
		ns:Fire("CHAT_MSG_ADDON", Sy.PREFIX, "H:TANK:1", "PARTY", SECRET)
		ns.testBait = nil
		local none = ns.syncRoles.Grimbar == nil
		ns:Fire("CHAT_MSG_ADDON", Sy.PREFIX, "H:TANK:1", "PARTY", "Grimbar")
		local got = ns.syncRoles.Grimbar ~= nil
		return none and got, S(none) .. "/" .. S(got), "ignoriert/übernommen"
	end)
	C("T81", "B", "Rolle aus Talentpunkten", function()
		local F = ns.Specs._RoleFromPoints
		local r = { F("WARRIOR", { 0, 5, 31 }, 36), F("PALADIN", { 31, 0, 0 }, 31), F("DRUID", { 0, 31, 0 }, 31), F("PRIEST", { 0, 0, 31 }, 31), F("WARRIOR", { 1, 2, 3 }, 6) }
		return r[1] == "TANK" and r[2] == "HEALER" and r[3] == "FERAL" and r[4] == "DAMAGER" and r[5] == nil,
			table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]) }, "/"), "TANK/HEALER/FERAL/DAMAGER/nil"
	end)
	C("T86", "B", "Schadensmeter: Kurzzahlen und Weiche", function()
		local Sh = ns.DmgMeter._Short
		local r = { Sh(999), Sh(1234), Sh(12345), Sh(2500000) }
		local ok = r[1] == "999" and r[2] == "1.2k" and r[3] == "12k" and r[4] == "2.5M"
		return ok and ns.DmgMeter.allowed == (not ns.isModern), table.concat(r, "/") .. " allowed=" .. S(ns.DmgMeter.allowed), "999/1.2k/12k/2.5M"
	end)
	C("T87", "B", "Anzeigen verschieben: Grösse begrenzt", function()
		ns.Mover:SetScale("hud", 9)
		local a = ns.db.hudScale
		ns.Mover:SetScale("hud", 0.1)
		local b = ns.db.hudScale
		return Near(a, 2.5) and Near(b, 0.5), S(a) .. "/" .. S(b), "2.5/0.5"
	end)
	C("T89", "B", "Einstellungsfenster und alle Seiten", function()
		local O = ns.Options
		if not O.frame then O:Build() end
		local wasShown = O.frame:IsShown()
		O.frame:Show()
		for i = 1, 8 do O:Select(i) end
		O:RefreshAll()
		if not wasShown then O.frame:Hide() end
		return true
	end)
	C("T93", "B", "Testzentrale: Texte und Zugriff-Simulation", function()
		local TM = ns.Test
		if not TM.frame then TM:Build() end
		local d, c, r = TM:DiagText(), TM:CompatText(), TM:ReportText()
		if type(d) ~= "string" or type(c) ~= "string" or type(r) ~= "string" then return false, "Text fehlt", "Texte" end
		local bad
		Capture(function()
			for _, st in ipairs({ "open", "secret", "none" }) do
				TM:SetAccessSim(st)
				local exp = ({ open = "FULL", secret = "DISPLAY", none = "OFF" })[st]
				if ns.threatAccess ~= "secret" and ns:ThreatMode() ~= exp then bad = st .. " -> " .. ns:ThreatMode() end
			end
			TM:SetAccessSim(nil)
		end)
		if A.ClearCenter then A:ClearCenter("test") end
		return bad == nil, bad or "ok", "open/secret/none -> FULL/DISPLAY/OFF"
	end)
	C("T94", "B", "Testprotokoll: Werte", function()
		local V = ns.Log.Val
		ns.testBait = SECRET
		local r = { V(SECRET), V(true), V(1.234), V(nil), V(5) }
		ns.testBait = nil
		return r[1] == "SECRET" and r[2] == "1" and r[3] == "1.23" and r[4] == "-" and r[5] == "5", table.concat(r, "/"), "SECRET/1/1.23/-/5"
	end)
	C("T95", "B", "Spenden-Knopf: Sprache", function()
		local D = ns.Donate
		local save = D.locale
		D.locale = "deDE"; local de = D.Text("title")
		D.locale = "enUS"; local en = D.Text("title")
		D.locale = save
		return type(de) == "string" and type(en) == "string" and de ~= en, "de/en verschieden", "verschieden"
	end)
	C("T96", "B", "/gsgame und /gsdev aufrufbar", function()
		local okA = pcall(SlashCmdList.GOLDSENTINELGAME, "")
		return okA, "ok", "kein Fehler"
	end)
	for _, id in ipairs({ "T25", "T29", "T30", "T41", "T48", "T49", "T50", "T52", "T53", "T54", "T55", "T56", "T57", "T58", "T59",
		"T61", "T65", "T66", "T67", "T68", "T69", "T70", "T71", "T72", "T77", "T78", "T79", "T80", "T82", "T83", "T84", "T85",
		"T88", "T90", "T91", "T92" }) do
		K(id, "B", "Funktionsprüfung mit Test-Einheiten/Plaketten", NO_STUB)
	end
end

------------------------------------------------------------
-- C. Forever-Sonderfälle (simuliert)
------------------------------------------------------------
Area.C = function()
	C("T102", "C", "Chat-Argumente geschützt", function()
		local before = ns.errorCount
		ns.testBait = SECRET
		ns:Fire("CHAT_MSG_ADDON", ns.Sync.PREFIX, SECRET, "PARTY", SECRET)
		ns.testBait = nil
		return ns.errorCount == before, "Fehler +" .. (ns.errorCount - before), "kein Fehler"
	end)
	C("T111", "C", "Kampflog auf der modernen API nicht angemeldet", function()
		local reg = ns:HasHandler("COMBAT_LOG_EVENT_UNFILTERED")
		if ns.isModern then
			return reg == false and ns.Alerts.cleuRegistered == false and ns.DmgMeter.allowed == false, S(reg), "nicht angemeldet"
		end
		return reg == true and ns.Alerts.cleuRegistered == true and ns.DmgMeter.allowed == true, S(reg), "Gegenprobe: angemeldet"
	end)
	for _, id in ipairs({ "T97", "T98", "T99", "T100", "T101", "T103" }) do
		K(id, "C", "Geschützte Werte aus Blizzard-Funktionen", NO_STUB)
	end
	for _, id in ipairs({ "T104", "T105", "T106", "T107", "T108" }) do
		K(id, "C", "Fehlende alte Funktionen", NO_STUB .. " (Globals auf nil setzen)")
	end
	CL("T109", "C", "Keine geschützten Aktionen im Kampf", "Im Kampf: Einstellungen öffnen (Hinweis 'nicht im Kampf'), /ts move (verweigert); danach /ts test > Bericht: Blocked: none")
	CL("T110", "C", "Plaketten im Kampf in ANZEIGE/AUS", "Forever, Modus ANZEIGE: Pull mit 3+ Mobs – nichts leuchtet, Plaketten unverändert; nach dem Kampf wieder normal")
end

------------------------------------------------------------
-- D. Alte Clients
------------------------------------------------------------
Area.D = function()
	if ns.isModern then
		for _, id in ipairs({ "T112", "T113", "T114", "T115", "T116" }) do K(id, "D", "Alter Client", "nur Classic Era / TBC") end
		K("T117", "D", "Gegenprobe im echten Spiel", "nur Classic Era / TBC")
		return
	end
	C("T112", "D", "Bedrohung offen, Modus immer VOLL", function()
		local save = ns.db.threatMode
		ns.db.threatMode = "DISPLAY"
		local m = ns:ThreatMode()
		ns.db.threatMode = save
		return ns.threatAccess == "open" and ns.ThreatAccess.checked == true and m == "FULL", S(ns.threatAccess) .. "/" .. m, "open/FULL"
	end)
	K("T113", "D", "Ersatz über das Ziel des Mobs", NO_STUB)
	K("T114", "D", "Auren über UnitBuff/UnitDebuff", NO_STUB)
	K("T115", "D", "Sync im Kampf nicht gesperrt", NO_STUB .. " (InCombatLockdown)")
	C("T116", "D", "Spott je Client", function()
		if ns.class ~= "PALADIN" then return true, "Klasse " .. S(ns.class) .. " (nur Paladin prüfbar)" end
		local G = GoldSentinelGame
		if G.IsEra then return ns.tauntSpell == nil, S(ns.tauntMode), "Era: kein Spott" end
		return ns.tauntMode == nil or ns.tauntMode == "friendly", S(ns.tauntMode), "TBC: friendly (wenn gelernt)"
	end)
	CL("T117", "D", "Gegenprobe im echten Spiel", "/ts guide mit Pet oder in der Gruppe: lose Mobs leuchten, gehaltene ausgeblendet, Ton bei Aggroverlust; Kampflog: Schadensmeter zählt, widerstandener Spott wird gemeldet, kein 'Addon geblockt'")
end

------------------------------------------------------------
-- E. Daten
------------------------------------------------------------
Area.E = function()
	C("T118", "E", "Neuinstallation", function()
		local keep = ThreatSentinelDB
		ThreatSentinelDB = nil
		local ok, err = pcall(function()
			ns:InitDB()
			local DB = ThreatSentinelDB
			local p = DB.profiles[DB.chars[ns.charKey]]
			if type(p) ~= "table" or p.schema ~= 9 then error("Profil/Schema " .. S(p and p.schema)) end
			for k, v in pairs(ns.defaults) do
				if type(v) ~= "table" and p[k] ~= v then error("Standard " .. k) end
			end
			local lines = Capture(function() ns.ThreatAccess:Report() end)
			if not Has(lines, L.TA_R_NEVER) then error("TA_R_NEVER fehlt") end
		end)
		ThreatSentinelDB = keep
		ns:InitDB()
		if not ok then return false, Clean(err), "Profil mit Standardwerten, Schema 9" end
		return true
	end)
	C("T119", "E", "Migration aus Schema 1", function()
		local db = { heldPlateAlpha = 0, chatChannel = "GROUP", soundHealer = "raidwarning", soundDD = "alarm", soundRegain = "click",
			soundResist = "readycheck", hudPoint = { "CENTER", "UIParent", "CENTER", 320, -120 }, meterPoint = { "CENTER", "UIParent", "CENTER", 320, 60 },
			hudScale = 1.3, hudLocked = false, soundEmergency = "ts_emergency", soundDDWarn = "ts_warn", regainSound = true,
			colorWarn = { 1, 0.9, 0 }, colorDD = { 1, 0.55, 0 }, looseScale = 1.25, borderSize = 3 }
		ns._MergeDefaults(db, ns.defaults)
		ns:Migrate(db)
		local d = ns.defaults
		local checks = {
			{ "heldPlateAlpha", db.heldPlateAlpha == 0.35 }, { "chatChannel", db.chatChannel == "TANKS" },
			{ "soundHealer", db.soundHealer == "fx_engel" }, { "soundDD", db.soundDD == "fx_frosch" },
			{ "soundRegain", db.soundRegain == d.soundRegain }, { "soundResist", db.soundResist == "none" or db.soundResist == d.soundResist },
			{ "hudPoint", Diff(db.hudPoint, d.hudPoint, "") == nil }, { "meterPoint", Diff(db.meterPoint, d.meterPoint, "") == nil },
			{ "meterScale", db.meterScale == 1.3 and db.ddScale == 1.3 }, { "hudLocked", db.hudLocked == true },
			{ "soundDDWarn", db.soundDDWarn == "none" }, { "soundEmergency", db.soundEmergency == "none" }, { "regainSound", db.regainSound == false },
			{ "colorWarn", db.colorWarn[1] == 1 and db.colorWarn[2] == 0.5 and db.colorWarn[3] == 0 },
			{ "colorDD", db.colorDD[1] == 1 and db.colorDD[2] == 0.1 and db.colorDD[3] == 0.1 },
			{ "looseScale", db.looseScale == 1.4 }, { "borderSize", db.borderSize == 4 }, { "schema", db.schema == 9 },
		}
		for _, c in ipairs(checks) do if not c[2] then return false, c[1] .. " = " .. S(db[c[1]]), "migriert" end end
		return true
	end)
	C("T120", "E", "Migration aus Schema 5 und 9", function()
		local db5 = { schema = 5, soundHealer = "ts_healer", soundDD = "ts_dd" }
		ns._MergeDefaults(db5, ns.defaults); ns:Migrate(db5)
		local db9 = { schema = 9, soundHealer = "quest", colorDD = { 0, 0, 1, 1 } }
		ns._MergeDefaults(db9, ns.defaults); ns:Migrate(db9)
		local ok = db5.soundHealer == "fx_engel" and db5.soundDD == "fx_frosch" and db9.soundHealer == "quest" and db9.colorDD[3] == 1
		return ok, S(db5.soundHealer) .. "/" .. S(db5.soundDD) .. "/" .. S(db9.soundHealer), "fx_engel/fx_frosch/quest"
	end)
	C("T121", "E", "Alte gespeicherte Bedrohungs-Erkennung", function()
		for _, v in ipairs({ false, { state = "none" }, { state = "secret", date = nil } }) do
			ThreatSentinelDB.threatAccess = v or nil
			ns.ThreatAccess:Login()
			Capture(function() ns.ThreatAccess:Report() end)
		end
		return true
	end)
	K("T122", "E", "Beschädigte Einträge", "nicht automatisch: InitDB mit falschen Typen würde Login-Teile der Module auf echten Rahmen auslösen; Typprüfung in Migrate ist ein eigener Auftrag")
end

------------------------------------------------------------
-- F. Sprachen
------------------------------------------------------------
local function Placeholders(s)
	local out = {}
	for p in tostring(s):gmatch("%%[%-%d%.]*[%a%%]") do out[#out + 1] = p end
	return table.concat(out, " ")
end

Area.F = function()
	local LOC = ns.LOCALES
	C("T123", "F", "Gleiche Schlüssel in en und de", function()
		local n, miss = 0, nil
		for k in pairs(LOC.enUS) do n = n + 1; if LOC.deDE[k] == nil then miss = "de fehlt " .. k end end
		for k in pairs(LOC.deDE) do if LOC.enUS[k] == nil then miss = "en fehlt " .. k end end
		return miss == nil, miss or (n .. " Schlüssel"), "gleich"
	end)
	C("T124", "F", "Zusammengesetzte Schlüssel vorhanden", function()
		local keys = { "TA_MODE_FULL", "TA_MODE_DISPLAY", "TA_MODE_OFF", "PRESET_quiet", "PRESET_standard", "PRESET_loud", "TANK", "HEALER", "DAMAGER", "PET" }
		for _, c in ipairs({ "TANKS", "BOSS", "GROUP", "SELF", "OFF" }) do keys[#keys + 1] = "CH_" .. c end
		for _, f in ipairs(ns.COMPAT_ORDER) do
			for _, p in ipairs({ "CP_", "CPF_", "CPO_", "CPH_" }) do keys[#keys + 1] = p .. f end
		end
		for _, s in ipairs({ "unknown", "open", "secret", "none" }) do keys[#keys + 1] = "TA_STATE_" .. s end
		for _, s in ipairs({ "real", "open", "secret", "none" }) do keys[#keys + 1] = "TEST_ACC_" .. s end
		for _, k in ipairs(keys) do
			if rawget(LOC.enUS, k) == nil or rawget(LOC.deDE, k) == nil then return false, k, "in en und de" end
		end
		return true, #keys .. " Schlüssel"
	end)
	C("T125", "F", "Formatplatzhalter gleich", function()
		for k, v in pairs(LOC.enUS) do
			local d = LOC.deDE[k]
			if type(v) == "string" and type(d) == "string" and Placeholders(v) ~= Placeholders(d) then
				return false, k .. ": " .. Placeholders(v) .. " / " .. Placeholders(d), "gleich"
			end
		end
		return true
	end)
	K("T126", "F", "Im Code benutzte Schlüssel", "vor dem Push per Skript geprüft (manuell)")
	C("T127", "F", "Aktive Sprache: Hauptfenster", function()
		local O, TM = ns.Options, ns.Test
		if not O.frame then O:Build() end
		local w = O.frame:IsShown()
		O.frame:Show(); for i = 1, 8 do O:Select(i) end
		if not w then O.frame:Hide() end
		if not TM.frame then TM:Build() end
		TM:ReportText()
		return true, GetLocale()
	end)
	K("T128", "F", "Andere Sprache aktivieren", "Sprachumschaltung (devLocale) ist noch nicht eingebaut")
	C("T129", "F", "Gemeinsame Dateien liefern Text", function()
		local G = GoldSentinelGame
		local ok = type(G.Status()) == "string"
		return ok, "Status", "Text"
	end)
end

------------------------------------------------------------
-- G. Zusammenspiel
------------------------------------------------------------
local OWN_FRAMES = { "ThreatSentinelCenter", "ThreatSentinelDD", "ThreatSentinelDmgMeter", "ThreatSentinelGuide", "ThreatSentinelHUD",
	"ThreatSentinelSummary", "ThreatSentinelMeter", "ThreatSentinelMoveBar", "ThreatSentinelSoundPicker", "ThreatSentinelOptions",
	"ThreatSentinelMinimapButton", "ThreatSentinelTauntButton", "ThreatSentinelAoeButton", "ThreatSentinelPreview", "ThreatSentinelReport",
	"ThreatSentinelTest" }

Area.G = function()
	C("T130", "G", "Globale Namen gehören ThreatSentinel", function()
		local map = { ThreatSentinelCenter = ns.Alerts.center, ThreatSentinelHUD = ns.HUD.f, ThreatSentinelMeter = ns.Meter.f,
			ThreatSentinelDD = ns.DD.f, ThreatSentinelDmgMeter = ns.DmgMeter.f, ThreatSentinelOptions = ns.Options.frame,
			ThreatSentinelTest = ns.Test.frame, ThreatSentinelReport = ns.Test.report }
		for name, obj in pairs(map) do
			if obj and _G[name] ~= obj then return false, name, "eigenes Objekt" end
		end
		return type(ThreatSentinelDB) == "table" and BINDING_HEADER_THREATSENTINEL ~= nil, "ok"
	end)
	C("T132", "G", "Gemeinsame GoldSentinelGame-Fassung", function()
		local G = _G.GoldSentinelGame
		return type(G) == "table" and (G.version or 0) >= 2 and ns.Game == G, "Version " .. S(G and G.version), ">= 2"
	end)
	C("T133", "G", "Slash- und Prefix-Kollisionen", function()
		for k, v in pairs(_G) do
			if type(k) == "string" and k:match("^SLASH_") and v == "/ts" and not k:match("^SLASH_THREATSENTINEL%d") then
				return false, k, "/ts nur ThreatSentinel"
			end
		end
		if C_ChatInfo and C_ChatInfo.IsAddonMessagePrefixRegistered then
			local ok, r = pcall(C_ChatInfo.IsAddonMessagePrefixRegistered, ns.Sync.PREFIX)
			if ok and r == false then return false, "Prefix nicht angemeldet", "angemeldet" end
		end
		return true
	end)
	K("T134", "G", "Schnittstellen zu den anderen Addons", "keine Schnittstelle")
	CL("T135", "G", "Mehrere GoldSentinel-Addons gleichzeitig", "Mit RaidMaster, GuildSentinel, BuffSentinel, ProfessionSentinel laden, /reload, /gsgame: eine Zeile, Version 2; /ts testroutine g")
end

------------------------------------------------------------
-- H. Leistung
------------------------------------------------------------
local function Time(n, fn)
	local t = Ms()
	for _ = 1, n do fn() end
	return (Ms() - t) / n
end

Area.H = function()
	K("T136", "H", "T:Tick mit 10/40 Testmobs", NO_STUB .. " (Testmobs)")
	C("T137", "H", "Anzeigen (echter Zustand, je 50x)", function()
		local parts = {}
		local worst
		local function m(name, fn, limit)
			local v = Time(50, fn)
			parts[#parts + 1] = string.format("%s %.2f", name, v)
			if v > limit then worst = name end
		end
		m("Meter", function() ns.Meter:Tick() end, 1)
		m("DD", function() ns.DD:Tick() end, 0.5)
		m("HUD", function() ns.HUD:Update({}, {}) end, 0.5)
		m("DmgMeter", function() ns.DmgMeter:Tick() end, 1)
		m("CheckCC", function() ns.Alerts:CheckCC() end, 0.1)
		m("Specs", function() ns.Specs:Step() end, 1)
		return worst == nil, table.concat(parts, ", ") .. " ms", "unter den Grenzen"
	end)
	K("T138", "H", "Bildweise OnUpdate", NO_STUB .. " (Testplaketten)")
	C("T139", "H", "Protokoll-Auswertung", function()
		local v = Time(5, function() ns.Log:Analyze() end)
		return v < 16, string.format("%.2f ms", v), "< 16 ms"
	end)
	C("T140", "H", "Speicher bei T:Tick", function()
		collectgarbage("collect")
		local before = collectgarbage("count")
		for _ = 1, 200 do ns.Threat:Tick() end
		collectgarbage("collect")
		local grow = collectgarbage("count") - before
		return grow < 100, string.format("%.0f KB", grow), "< 100 KB"
	end)
end

------------------------------------------------------------
-- I. Fehlerzählung und Diagnose
------------------------------------------------------------
Area.I = function()
	C("T141", "I", "Absichtlicher Fehler wird gezählt", function()
		local n, last = ns.errorCount, ns.lastError
		ns.routineSelfTest = true
		ns:ReportError("TS-Selbsttest")
		ns.routineSelfTest = nil
		local ok = ns.errorCount == n + 1 and ns.lastError == "TS-Selbsttest"
		local lines = Capture(function() ns.ThreatAccess:Report() end)
		local rep = Has(lines, string.format(L.TA_R_ERRORS, ns.errorCount))
		ns.errorCount, ns.lastError = n, last
		return ok and rep, S(ok) .. "/" .. S(rep), "gezählt und angezeigt"
	end)
	C("T142", "I", "Fehler in einem Teil hält den Durchlauf nicht an", function()
		local n = ns.errorCount
		local meter = 0
		local realMeter = ns.Meter.Tick
		Swap(ns.DD, "Tick", function() error("TS-Selbsttest DD") end)
		Swap(ns.Meter, "Tick", function(...) meter = meter + 1; return realMeter(...) end)
		ns.routineSelfTest = true
		local active = ns:IsActive()
		ns.Threat:Tick()
		ns.routineSelfTest = nil
		UnswapAll()
		local diff = ns.errorCount - n
		ns.errorCount = n
		return diff >= 1 and meter >= 1, "Fehler +" .. diff .. ", Meter " .. meter .. "x (aktiv " .. S(active) .. ")", "Fehler gezählt, Meter läuft"
	end)
	C("T143", "I", "Fehler in einem Ereignis-Handler", function()
		local n = ns.errorCount
		local ran = false
		local bad = function() error("TS-Selbsttest Handler") end
		local good = function() ran = true end
		ns:On("PLAYER_ALIVE", bad); ns:On("PLAYER_ALIVE", good)
		ns.routineSelfTest = true
		ns:Fire("PLAYER_ALIVE")
		ns.routineSelfTest = nil
		ns:Off("PLAYER_ALIVE", bad); ns:Off("PLAYER_ALIVE", good)
		local diff = ns.errorCount - n
		ns.errorCount = n
		return diff == 1 and ran, "Fehler +" .. diff .. ", übrige " .. S(ran), "+1, übrige laufen"
	end)
	C("T144", "I", "Hinweis einmal pro Sitzung", function()
		if not ns.isModern then return true, "alte API: kein Hinweis" end
		local n, last, noticed = ns.errorCount, ns.lastError, ns.errorNoticed
		ns.errorNoticed = nil
		ns.routineRunning = false   -- IsTesting aus, damit der Hinweis käme (Ausgabe abgefangen)
		ns.routineSelfTest = true
		local lines = Capture(function() ns:ReportError("TS-Selbsttest 1"); ns:ReportError("TS-Selbsttest 2") end)
		ns.routineSelfTest = nil
		ns.routineRunning = true
		local c = 0
		for _, l in ipairs(lines) do if l:find(L.ERR_NOTICE, 1, true) then c = c + 1 end end
		ns.errorCount, ns.lastError, ns.errorNoticed = n, last, noticed
		return c == 1, c .. "x", "1x"
	end)
	C("T145", "I", "Gesperrte Aktion wird gezählt", function()
		local n, nb = ns.errorCount, #ns.blocked
		ns.routineSelfTest = true
		ns:Fire("ADDON_ACTION_BLOCKED", ADDON, "TestFunc")
		ns:Fire("ADDON_ACTION_BLOCKED", "FremdesAddon", "TestFunc")
		ns.routineSelfTest = nil
		local ok = #ns.blocked == nb + 1 and ns.errorCount == n + 1
		local added = #ns.blocked - nb
		while #ns.blocked > nb do table.remove(ns.blocked) end
		ns.errorCount = n
		return ok, "blocked +" .. added, "+1 (fremdes Addon nichts)"
	end)
	C("T146", "I", "Fehlerschritt im Testassistenten", function()
		local step
		for _, s in ipairs(ns.Guide.STEPS) do if s.id == "errors" then step = s end end
		if not step then return false, "Schritt fehlt", "errors" end
		return true, "vorhanden"
	end)
	K("T147", "I", "Lua-Fehler ausserhalb von pcall", "würde einen echten Fehler im Fehlerfenster/BugSack des Spielers auslösen; GoldSentinelTest.TrackErrors ist angemeldet (siehe Core.lua)")
end

------------------------------------------------------------
-- J. Regressionstests
------------------------------------------------------------
Area.J = function()
	local TA = ns.ThreatAccess
	CL("T148", "J", "Kein Ersatz über das Ziel des Mobs (modern)", "Forever: Mob ohne Bedrohungsdaten bleibt IDLE (Diagnose 'Bedrohung am Ziel'), kein Leuchten")
	CL("T149", "J", "Kein stilles IDLE bei geschützten Werten", "Forever, erster Kampf: /ts bedrohung zeigt 'geschützt', Hinweis 1x")
	K("T150", "J", "Geschützte Namen nie als Schlüssel", NO_STUB .. " (UnitName)")
	C("T151", "J", "Textfunktionen ohne geschützte Werte", function()
		ns.testBait = SECRET
		local i = ns.Plates._Initial(SECRET)
		ns.testBait = nil
		return i == "", "Initial '" .. i .. "'", "''"
	end)
	K("T152", "J", "Leere Aurenliste im Kampf = unbekannt", NO_STUB)
	K("T153", "J", "Blizzard-Plaketten im Kampf nicht anfassen", NO_STUB .. " (siehe T110 im Client)")
	CL("T154", "J", "Taint im Modus VOLL", "Pull mit 3+ Mobs im Modus VOLL, danach /ts test > Bericht: 'Blocked: none'; kein 'ThreatSentinel hat eine Aktion blockiert'")
	C("T155", "J", "Moderne API überall wie Retail", function()
		if not ns.isModern then return true, "alte API (nur F)" end
		local cls = ns.class
		ns.class = "DRUID"
		local t = ns:DeficitText()
		ns.class = cls
		return t == L.DEFICIT_OTHER, S(t), "DEFICIT_OTHER"
	end)
	K("T156", "J", "Sync-Kampfsperre echt", NO_STUB .. " (InCombatLockdown)")
	CL("T157", "J", "Erkennung einmal pro Kampf, Zustand gespeichert", "Forever: zwei Kämpfe hintereinander, danach /ts bedrohung: 'zuletzt erkannt' mit Datum und Build")
	C("T158", "J", "Bedrohung prüfen zeigt geschützte Werte nie", function()
		ns.testBait = SECRET
		local s = TA._Shown(SECRET)
		ns.testBait = nil
		local a, b = TA._Shown(86.25), TA._Shown(3)
		return s == L.TA_PROTECTED and (a == "86.2" or a == "86.3") and b == "3", S(s) .. "/" .. S(a) .. "/" .. S(b), "geschützt/86.2/3"
	end)
	C("T159", "J", "'Voll' nicht erzwingbar", function()
		local save = { ns.threatAccess, ns.db.threatMode, ns.simAccess }
		ns.threatAccess, ns.simAccess = "secret", nil
		local bad
		for _, m in ipairs({ "AUTO", "DISPLAY", "FULL" }) do
			ns.db.threatMode = m
			if ns:ThreatMode() ~= "DISPLAY" then bad = m end
		end
		ns.threatAccess, ns.db.threatMode, ns.simAccess = save[1], save[2], save[3]
		return bad == nil, bad or "ok", "immer DISPLAY"
	end)
	C("T160", "J", "Drei Zustände simulierbar (Knopftext)", function()
		local TM = ns.Test
		if not TM.frame then TM:Build() end
		local saveAcc = ns.threatAccess
		ns.threatAccess = "open"
		local texts = {}
		Capture(function()
			for _, st in ipairs({ "open", "secret", "none" }) do
				TM:SetAccessSim(st)
				texts[#texts + 1] = TM.accBtn:GetText()
			end
			TM:SetAccessSim(nil)
		end)
		ns.threatAccess = saveAcc
		if ns.Alerts.ClearCenter then ns.Alerts:ClearCenter("test") end
		return texts[1] == L.TEST_ACC_open and texts[2] == L.TEST_ACC_secret and texts[3] == L.TEST_ACC_none, table.concat(texts, "/"), "TEST_ACC_open/secret/none"
	end)
	C("T162", "J", "G.Status in Diagnose und Bericht", function()
		local st = GoldSentinelGame.Status()
		local TM = ns.Test
		if not TM.frame then TM:Build() end
		local d, r = TM:DiagText(), TM:ReportText()
		local lines = Capture(function() TA:Report() end)
		return d:find(st, 1, true) ~= nil and r:find(st, 1, true) ~= nil and Has(lines, st), "Diagnose/Bericht/Bedrohung", "enthalten G.Status()"
	end)
	C("T163", "J", "Kein InterfaceOptions_AddCategory/EasyMenu", function()
		-- Prüfung im Quelltext vor dem Push (Skript); hier nur: Optionen bauen ohne Fehler
		if not ns.Options.frame then ns.Options:Build() end
		return true, "Optionen gebaut"
	end)
	K("T164", "J", "'unknown' + Fehlschlag -> 'secret'", NO_STUB .. " (UnitDetailedThreatSituation); Code geprüft: Threat.lua Bedingung ~= secret und ~= none (2.4.3)")
	C("T165", "J", "MAX_ATTEMPTS-Konstante und neuer Kampf", function()
		if not ns.isModern then return true, "alte API (nur F R)" end
		ns.threatAccess, TA.tempNone = "none", true
		ns:Fire("PLAYER_REGEN_DISABLED")
		return TA.MAX_ATTEMPTS == 40 and ns.threatAccess == "unknown", S(TA.MAX_ATTEMPTS) .. "/" .. S(ns.threatAccess), "40/unknown"
	end)
	C("T166", "J", "'unknown' ausserhalb des Kampfs = VOLL", function()
		local save = { ns.threatAccess, ns.simAccess, ns.db.threatMode }
		ns.threatAccess, ns.simAccess, ns.db.threatMode = "unknown", nil, "AUTO"
		local m = ns:ThreatMode()
		ns.threatAccess, ns.simAccess, ns.db.threatMode = save[1], save[2], save[3]
		return m == "FULL", m, "FULL (im Kampf DISPLAY: im Client prüfen)"
	end)
	CL("T166b", "J", "'unknown' im Kampf ergibt ANZEIGE", "Forever, erster Kampf nach dem Login: Testzentrale-Diagnose 'Bedrohungsmodus' zeigt ANZEIGE, bis die Prüfung ein Ergebnis hat")
	CL("T167", "J", "Aggrometer sortiert im Modus ANZEIGE nicht", "Gruppe, Modus ANZEIGE: Reihenfolge Tank, dann Gruppe – nicht nach Bedrohung")
	C("T168", "J", "Kein Vorsprung-Text im Modus ANZEIGE", function()
		local M = ns.Meter
		if not M.f then return false, "kein Aggrometer", "Rahmen" end
		local shown = M.f:IsShown()
		local saveSim = ns.simAccess
		ns.simAccess = "secret"
		M:Render({ { name = "Torben", class = "WARRIOR", pull = 100, tanking = true, isTank = true, status = 2, me = true },
			{ name = "Anna", class = "PRIEST", pull = 50 } }, "Test", true)
		local lead = M.f.lead:GetText()
		local r, g, b = M.f.rows[1]:GetStatusBarColor()
		ns.simAccess = saveSim
		if not shown then M.f:Hide() end
		local neutral = Near(r, 0.45, 0.02) and Near(g, 0.6, 0.02) and Near(b, 0.85, 0.02)
		return (lead == nil or lead == "") and neutral, "Vorsprung '" .. S(lead) .. "', Farbe " .. string.format("%.2f,%.2f,%.2f", r or 0, g or 0, b or 0), "leer, neutral"
	end)
	C("T169", "J", "Neutrale Balkenfarbe der DD-Ansicht im Modus ANZEIGE", function()
		local D = ns.DD
		if not D.f then return false, "keine DD-Ansicht", "Rahmen" end
		local shown = D.f:IsShown()
		local saveSim = ns.simAccess
		ns.simAccess = "secret"
		D:ShowSecret(80, 3)
		local r, g, b = D.f.bar:GetStatusBarColor()
		ns.simAccess = saveSim
		if not shown then D.f:Hide() end
		return Near(r, 0.45, 0.02) and Near(g, 0.6, 0.02) and Near(b, 0.85, 0.02), string.format("%.2f,%.2f,%.2f", r or 0, g or 0, b or 0), "0.45,0.60,0.85"
	end)
	C("T170", "J", "Blizzard-Anzeigen bei 'immer nur Anzeige' (mitgeschrieben)", function()
		if not ns.isModern then return true, "alte API (nur F R)" end
		local before = ns.actLog.n.cvar or 0
		ns.threatAccess, ns.simAccess = "open", nil
		ns.db.enabled, ns.db.blizzThreat, ns.db.threatMode = true, true, "DISPLAY"
		ns.db.blizzOrig = nil
		ns:ApplySettings()
		local n = (ns.actLog.n.cvar or 0) - before
		local note = rawget(ns.LOCALES.enUS, "O_BLIZZTHREAT_NOTE") and rawget(ns.LOCALES.deDE, "O_BLIZZTHREAT_NOTE")
		-- n == 0 ist richtig, wenn die CVars schon auf dem Zielwert stehen
		return note and true or false, "CVar " .. n .. "x mitgeschrieben", "Hinweistext en/de"
	end)
	C("T171", "J", "Knopf 'Client simulieren: Forever / echt'", function()
		local TM = ns.Test
		if not TM.frame then TM:Build() end
		if not TM.clientBtn then return false, "Knopf fehlt", "vorhanden" end
		local m1, m2
		Capture(function()
			TM:SetClientSim(true); m1 = ns.isModern
			TM:SetClientSim(false); m2 = ns.isModern
		end)
		return m1 == true and m2 == (GoldSentinelGame.IsModern and true or false), S(m1) .. "/" .. S(m2), "true/echt"
	end)
	C("T172", "J", "Ausgeschaltetes Addon meldet nichts", function()
		local shown = 0
		Swap(ns.Alerts, "Center", function() shown = shown + 1 end)
		ns.db.enabled = false
		TA.announced = false
		TA:Set("secret")
		UnswapAll()
		ns.db.enabled = true
		return shown == 0, shown .. "x", "kein Hinweis"
	end)
	C("T173", "J", "Simulation 'open' übersteuert keine echte Sperre", function()
		local save = { ns.threatAccess, ns.simAccess }
		ns.threatAccess, ns.simAccess = "secret", "open"
		local m = ns:ThreatMode()
		ns.threatAccess, ns.simAccess = save[1], save[2]
		return m == "DISPLAY", m, "DISPLAY"
	end)
	CL("T174", "J", "UnitIsUnit nur über ns:SameUnit", "Forever, Gruppe im Kampf: kein Lua-Fehler (Testzentrale-Diagnose 'Fehler: 0')")
	C("T175", "J", "Log.lua und Specs.lua nutzen ns.IsSecret", function()
		ns.testBait = SECRET
		local v = ns.Log.Val(SECRET)
		ns.testBait = nil
		return v == "SECRET", S(v), "SECRET"
	end)
	C("T176", "J", "TBC Anniversary / Classic Era – Kampflog und Meter aktiv", function()
		if ns.isModern then return true, "moderne API: Kampflog aus (richtig)" end
		local A = ns.Alerts
		return A.cleuAllowed == true and A.cleuRegistered == true and ns.DmgMeter.allowed == true and #ns.blocked == 0,
			string.format("%s/%s/%s blocked=%d", S(A.cleuAllowed), S(A.cleuRegistered), S(ns.DmgMeter.allowed), #ns.blocked), "true/true/true blocked=0"
	end)
	CL("T176b", "J", "Alter Client: Kampf in der Gruppe", "Classic Era und TBC Anniversary: Schadens-/Heilmeter zählt, widerstandener Spott wird gemeldet, kein 'Addon geblockt' – Ergebnis dem Nutzer melden")
	CL("T177", "J", "Launch-Tag: Interface-Nummer und erster Kampf", "/dump select(4, GetBuildInfo()); im ersten Kampf /ts bedrohung -> Modus im Bericht")
	K("T178", "J", "Lua-Syntaxprüfung", "vor dem Push mit addon_check.py (manuell)")
end

------------------------------------------------------------
-- Ablauf
------------------------------------------------------------
function R:Say(msg) ns:Print("|cffffd100[Testroutine]|r " .. tostring(msg)) end

local function RunArea(letter)
	local fn = Area[letter]
	if not fn then return end
	R.inArea = true
	local ok, err = pcall(fn)
	R.inArea = false
	if not ok then RUN:Check("X" .. letter, letter, "Bereich " .. letter .. " abgebrochen", function() error(err, 0) end) end
	-- Stubs immer am Ende des Bereichs zurücksetzen und prüfen
	local open = #swaps
	UnswapAll()
	RUN:Check("S" .. letter, letter, "Stubs zurückgesetzt", function() return open == 0, open, 0 end)
	-- Sandbox zurück (Tickers sehen zwischen den Bereichen die echten Daten)
	ns.routineRunning = false
	R:RestoreSandbox()
	ns.routineRunning = true
end

function R:Finish(stopped)
	ns.routineRunning = false
	ns.actLog = nil
	UnswapAll()
	self:RestoreSandbox()
	-- alles schliessen, was die Routine geöffnet hat
	if ns.Test and ns.Test.frame and not self.testWasShown then ns.Test.frame:Hide() end
	if ns.Options and ns.Options.frame and not self.optWasShown then ns.Options.frame:Hide() end
	if ns.Alerts and ns.Alerts.ClearCenter then ns.Alerts:ClearCenter("test") end
	local sbOk, sbWhere = self:CheckSandbox()
	local cvOk, cvWhere = self:CheckCVars()
	local kOk, kWhere = self:CheckKeys()
	local simOk = not ns.testMode and not ns.liveTest and not ns.moveMode and ns.simSecret == self.sb.ns.simSecret[1]
		and ns.simAccess == self.sb.ns.simAccess[1] and ns.isModern == self.sb.ns.isModern[1] and ns.testBait == nil
	local real = self.realCalls
	local acts = {}
	for k, n in pairs(self.lastAct or {}) do acts[#acts + 1] = k .. "=" .. n end
	table.sort(acts)
	local function res(ok, where) return ok and "OK" or ("FEHLER (" .. tostring(where) .. ")") end
	local last = ThreatSentinelDB and ThreatSentinelDB.threatAccess
	local extra = {
		sandbox = res(sbOk, sbWhere), cvars = res(cvOk, cvWhere), tasten = res(kOk, kWhere),
		simulationen = simOk and "OK" or "FEHLER", stubs = (#swaps == 0) and "OK" or "FEHLER",
		echte_aktionen = tostring(real), mitgeschrieben = table.concat(acts, " "),
		fehlerzaehler = tostring(ns.errorCount or 0), blockiert = tostring(#(ns.blocked or {})),
		bedrohung = string.format("%s / %s / gespeichert: %s", S(ns.threatAccess), ns:ThreatMode(),
			type(last) == "table" and (S(last.state) .. " " .. S(last.date) .. " " .. S(last.build)) or "-"),
		abgebrochen = stopped and tostring(stopped) or nil,
	}
	local text = RUN:Finish(extra)
	text = text .. "\n" .. table.concat({
		"echte Daten unverändert: " .. extra.sandbox,
		"CVars unverändert: " .. extra.cvars,
		"Tastenbelegung unverändert: " .. extra.tasten,
		"Simulationen zurückgesetzt: " .. extra.simulationen,
		"Stubs zurückgesetzt: " .. extra.stubs,
		"Echte Aktionen während der Routine: " .. real .. " (erwartet 0) · nur mitgeschrieben: " .. (extra.mitgeschrieben ~= "" and extra.mitgeschrieben or "-"),
		"Fehlerzähler: " .. extra.fehlerzaehler .. " · gesperrte Aktionen: " .. extra.blockiert,
		"Bedrohung: " .. extra.bedrohung,
		"Kampflog/Meter: Simulation erst nach /reload",
		stopped and ("Abgebrochen: " .. tostring(stopped)) or nil,
	}, "\n")
	text = Clean(text)
	self.lastText = text
	RUN = nil
	self.running = false
	if ns.Test and ns.Test.ShowText then ns.Test:ShowText(text, L.TR_TITLE) end
	self:Say(L.TR_SAVED)
	self:Say(L.TR_RELOAD)
end

function R:Start(only)
	if self.running then self:Say(L.TR_RUNNING) return end
	if not ns:RequireDev() then return end
	if InCombat() then ns:Print(L.NOT_IN_COMBAT) return end
	if not GoldSentinelTest or not GoldSentinelTest.Begin then self:Say("GoldSentinelTest fehlt") return end
	InstallHooks()
	self.running = true
	self.realCalls = 0
	self.testWasShown = ns.Test.frame and ns.Test.frame:IsShown() or false
	self.optWasShown = ns.Options.frame and ns.Options.frame:IsShown() or false
	RUN = GoldSentinelTest.Begin("ThreatSentinel", ns.version, ThreatSentinelDB)
	self:TakeSandbox()
	ns.actLog = { n = {} }
	self.lastAct = ns.actLog.n
	ns.routineRunning = true
	local list = only and { only } or AREAS
	self:Say(string.format(L.TR_STARTED, only or "A–J"))
	local i = 0
	local function step()
		i = i + 1
		local letter = list[i]
		if not letter then R:Finish() return end
		if InCombat() then
			for j = i, #list do RUN:Skip("X" .. list[j], list[j], "Bereich " .. list[j], L.TR_COMBAT) end
			R:Say(L.TR_COMBAT)
			R:Finish(L.TR_COMBAT)
			return
		end
		RunArea(letter)
		C_Timer.After(0, step)
	end
	C_Timer.After(0, step)
end

local HALF = { "TR_HALF_1", "TR_HALF_2", "TR_HALF_3", "TR_HALF_4", "TR_HALF_5", "TR_HALF_6", "TR_HALF_7", "TR_HALF_8", "TR_HALF_9" }

function R:Command(arg)
	arg = strtrim((arg or ""):lower())
	if arg == "" then
		self:Start(nil)
	elseif arg:match("^[a-j]$") then
		self:Start(arg:upper())
	elseif arg == "halb" or arg == "half" then
		if not ns:RequireDev() then return end
		self:Say(L.TR_HALF_TITLE)
		for _, k in ipairs(HALF) do ns:Print(L[k]) end
	elseif arg == "letzte" or arg == "last" then
		if not ns:RequireDev() then return end
		if self.lastText and ns.Test.ShowText then ns.Test:ShowText(self.lastText, L.TR_TITLE)
		else self:Say(L.TR_NO_LAST) end
	else
		self:Say(L.TR_USAGE)
	end
end
