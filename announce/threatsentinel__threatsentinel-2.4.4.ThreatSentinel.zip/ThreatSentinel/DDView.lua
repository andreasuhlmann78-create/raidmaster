-- ThreatSentinel - DDView.lua
-- Kleiner Balken für Spieler, die nicht tanken: eigene Bedrohung auf dem Ziel, Warnung ab Schwelle.

local ADDON, ns = ...
local L = ns.L

local D = {}
ns.DD = D
table.insert(ns.modules, D)

local WHITE = "Interface\\Buttons\\WHITE8X8"

function D:Init()
	local f = CreateFrame("Frame", "ThreatSentinelDD", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	f:SetSize(190, 22)
	f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	f:SetBackdropColor(0.03, 0.04, 0.06, 0.6)
	f:SetBackdropBorderColor(0.25, 0.65, 1, 0.5)
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", function(self) self:StartMoving() end)
	f:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		ns.Mover:SavePoint(self, "ddPoint")
	end)

	f.bar = CreateFrame("StatusBar", nil, f)
	f.bar:SetPoint("TOPLEFT", 2, -2)
	f.bar:SetPoint("BOTTOMRIGHT", -2, 2)
	f.bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
	f.bar:SetMinMaxValues(0, 100)
	f.text = f.bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	f.text:SetPoint("CENTER")
	f:Hide()
	self.f = f
	ns.Mover:Attach(f, "dd")
	self:ApplySettings()
end

function D:ApplySettings()
	local f, db = self.f, ns.db
	local p = db.ddPoint
	f:ClearAllPoints()
	f:SetPoint(p[1], UIParent, p[3], p[4], p[5])
	f:SetWidth(db.ddWidth or 190)
	f:SetScale(db.ddScale or 1)
	f:EnableMouse(ns:Unlocked())
end

-- Geschützter Wert (Forever): Balken und Zahl zeigt das Spiel selbst an,
-- die Farbe kommt aus dem Bedrohungsstatus (1 = über 100 %, 2/3 = du hast Aggro).
function D:ShowSecret(value, status)
	local f, db = self.f, ns.db
	ns:Compat("threatValues", "fallback")
	f.bar:SetValue(value)
	if ns:ThreatMode() == "DISPLAY" then
		-- Modus ANZEIGE: Wert nur durchreichen, neutrale Farbe, keine Schwellwerte, kein Ton
		f.bar:SetStatusBarColor(0.45, 0.6, 0.85)
		if not pcall(f.text.SetFormattedText, f.text, L.DD_THREAT_SECRET, value) then f.text:SetText(value) end
		self.warned = false
		f:Show()
		return
	end
	status = ns.Safe(status, 0) or 0
	local warn = status >= 1
	if status >= 2 then
		f.bar:SetStatusBarColor(1, 0.1, 0.1)
		f.text:SetText(L.DD_AGGRO)
	else
		if warn then f.bar:SetStatusBarColor(1, 0.15, 0.15) else f.bar:SetStatusBarColor(0.2, 0.85, 0.3) end
		-- geschützte Zahl: nicht selbst formatieren, das Spiel zeigt sie an
		if not pcall(f.text.SetFormattedText, f.text, L.DD_THREAT_SECRET, value) then f.text:SetText(value) end
	end
	-- Modus ANZEIGE: keine Töne nach Schwellwerten
	if warn and not self.warned and db.ddSound and ns:ThreatMode() == "FULL" then
		self.warned = true
		ns.Alerts:Play(db.soundDDWarn, "ddWarn")
	elseif not warn then
		self.warned = false
	end
	f:Show()
end

function D:Show(value, isTanking)
	local f, db = self.f, ns.db
	value = math.max(0, value or 0)
	f.bar:SetValue(math.min(value, 100))
	local r, g, b
	if isTanking then
		r, g, b = 1, 0.1, 0.1
		f.text:SetText(L.DD_AGGRO)
	else
		if value >= db.ddWarn then r, g, b = 1, 0.15, 0.15
		elseif value >= db.ddWarn * 0.75 then r, g, b = 1, 0.8, 0.1
		else r, g, b = 0.2, 0.85, 0.3 end
		f.text:SetText(string.format(L.DD_THREAT, math.floor(value + 0.5)))
	end
	f.bar:SetStatusBarColor(r, g, b)

	local warn = isTanking or value >= db.ddWarn
	if warn and not self.warned and db.ddSound and not ns.testMode and ns:ThreatMode() == "FULL" then
		self.warned = true
		ns.Alerts:Play(db.soundDDWarn, "ddWarn")
	elseif not warn and value < db.ddWarn - 10 then
		self.warned = false
	end
	f:Show()
end

function D:Tick()
	local f, db = self.f, ns.db
	if not f then return end

	if ns.testMode and db.ddView then
		local v = (math.sin(GetTime() * 0.8) * 0.5 + 0.5) * 105
		self:Show(v, v > 100)
		return
	end

	-- Verschieben: immer zeigen (auch als Tank), mit Beispielwert
	if ns.moveMode then
		f.bar:SetValue(65)
		f.bar:SetStatusBarColor(1, 0.8, 0.1)
		f.text:SetText(L.DD_DRAG)
		f:Show()
		return
	end

	if not db.enabled or not db.ddView or ns:IsTankStance() then f:Hide() return end
	if ns:ThreatMode() == "OFF" then f:Hide() return end

	if ns:Unlocked() and not UnitAffectingCombat("player") then
		f.bar:SetValue(0)
		f.text:SetText(L.DD_DRAG)
		f:Show()
		return
	end

	if (not IsInGroup() and not ns.liveTest) or not UnitAffectingCombat("player") or not ns.Safe(UnitCanAttack("player", "target"), false) then
		f:Hide()
		return
	end

	local ok, isTanking, status, scaled = pcall(UnitDetailedThreatSituation, "player", "target")
	if not ok then f:Hide() return end
	-- Modus ANZEIGE: auch lesbare Werte nur durchreichen (keine eigenen Schwellwerte)
	if ns:ThreatMode() == "DISPLAY" and not ns.IsSecret(scaled) and scaled ~= nil then
		self:ShowSecret(scaled, status)
		return
	end
	if ns.IsSecret(scaled, "threatValues") or ns.IsSecret(isTanking) then
		if not ns.IsSecret(scaled, "threatValues") and scaled == nil then f:Hide() return end
		self:ShowSecret(scaled, status)
		return
	end
	if not status and not scaled then f:Hide() return end
	self:Show(scaled or 0, isTanking)
end
