# LevelPilot – Änderungen (Deutsch)

Ältere Versionen stehen in CHANGELOG.md (Englisch).

## 3.12.75
- Pfeil und Weg ruhiger: Der Weg wechselt beim Laufen nur noch, wenn der neue deutlich kürzer ist (mindestens 30 Yards bzw. 10 %).
  Vorher sprang er zwischen gleich guten Varianten hin und her – die Entfernung stieg kurz, der Pfeil drehte.
- Kein Umweg mehr über einen Wegpunkt neben dir: Läuft eine Strasse dicht an dir vorbei, führt der Weg direkt auf sie statt erst
  zu einem Knoten und dann zurück.
- Testroutine: neuer Test T337.

## 3.12.74
- Quests höchstens 2 Stufen über dir (vorher 3): keine orangen Quests mehr, die dich in ein zu hohes Gebiet schicken. In der
  virtuellen Reise 1–60 ist das zudem etwas schneller.
- Testroutine: neuer Test T336.

## 3.12.73
- Questgeber in der Nähe zuerst: Steht ein Questgeber mit einer annehmbaren Quest höchstens 150 Yards entfernt, zeigt der Guide
  zuerst ihn – vor weiter entfernten Zielen und vor Binden, Flugpunkt oder Ruhestein. Auch knapp ausserhalb des Startgebiets
  wird er mitgenommen.
- Testroutine: neuer Test T335.

## 3.12.72
- Orte aus den Spieldateien (Datenpaket 1.6.3): LevelPilot kennt jetzt zu jedem Punkt der Karte den Ort, wie er an der Minikarte
  steht (Nordhaintal, Goldhain, Tal der Prüfungen …) – für Classic Era und WoW Forever getrennt. Das Startgebiet ist jetzt genau
  dieser Ort (z. B. Nordhaintal mit Echokammmine und Weinbergen) statt einer gerechneten Grenze.
- Testroutine: neuer Test T334.

## 3.12.71
- Startgebiet (Classic Era und WoW Forever): Unter Stufe 6 bleibt die Route im Startgebiet (Nordhain, Coldridgetal, Schattenhain,
  Tal der Prüfungen, Todesend, Camp Narache), solange es dort etwas zu tun gibt – kein Ziel im ersten Dorf, kein Binden, kein
  Flugpunkt vorher. Startgebiete anderer Völker sind kein Ziel mehr (vorher lief z. B. ein Ork mit Stufe 4 nach Mulgore).
- Binden im Gasthaus nur noch, wenn es auf dem Weg liegt (höchstens 60 Yards Umweg). Vorher stand „Binden“ in Nordhain als
  Schritt 1 vor allen nahen Questgebern (Gasthaus Goldhain).
- Fehler behoben: Der Weg sprang beim Laufen zwischen zwei Varianten hin und her (Entfernung stieg, Pfeil drehte), wenn eine
  Gerade die Ecke eines Gebiets mit zu starken Monstern streifte. Gebiete werden jetzt lückenlos geprüft.
- Der Pfeil schaltet über einen Wegpunkt weiter, der schon hinter dir liegt.
- Testroutine: neue Tests T332 und T333.

## 3.12.70
- Fehler behoben: Ein Ziel, das du selbst wählst (/lp navi, /lp weg, /lp suche, Kartenmarkierung, ein anderes Addon), steht jetzt
  immer oben im Guide, und der Pfeil zeigt dorthin – vorher kam eine fertige Quest in der Nähe zuerst. Vorschläge des Assistenten
  kommen weiter nach nahen Abgaben.
- Testroutine: neuer Test T331.

## 3.12.69
- Fehler behoben: Navi-Suche und /lp suche beachten Gross-/Kleinschreibung jetzt auch bei Umlauten, Akzenten und Kyrillisch nicht
  mehr („/lp navi 50 50 ödland“ findet das Ödland, russische Namen in jeder Schreibweise).
- Fehler behoben: In /lp protokoll stand in der Zeile REISE „(nil)“ statt der Quelle des Tempos und ein Punkt statt eines Kommas.
- Testroutine: neuer Test T330.

## 3.12.68
- Startwegnetz für 6 weitere Zonen (LW-4), aus den Wegen, die LevelPilot-Spieler gelaufen und eingesandt haben (ohne Namen):
  Durotar, Tirisfal, Silberwald, Vorgebirge des Hügellands, Tausend Nadeln, Steinkrallengebirge (vorher: Mulgore, Brachland,
  Donnerfels). Neue Charaktere bekommen dort sofort echte Wege. Nur WoW Forever. In der virtuellen Reise 1–60 sinkt der Anteil
  des Weges ohne bekannten Weg von etwa 80 % auf etwa 67 %.
- Messlatte (LW-7 e): Der Bericht der virtuellen Reise vergleicht jede Stufe mit deiner Bestzeit über alle Charaktere (ohne Namen).
- Testroutine: neuer Test T329.

## 3.12.67
- Flugpreise (LW-8): Beim Öffnen der Flugkarte merkt sich LevelPilot den Preis, den das Spiel für jedes erreichbare Ziel nennt.
  Der Reiseplan zeigt ihn dann („Flug nach X, 1s 20c (2:10)“); ohne Messung „Preis unbekannt“. Die Preise sind deine eigene
  Messung, je Spielversion gespeichert.
- Testroutine: neuer Test T328.

## 3.12.66
- Speedrun bis Stufe 10 (LW-7 d, standardmässig aus): Ist Sterben und Auferstehen beim Geistheiler nahe am Ziel klar schneller als
  Laufen (mindestens 3 Minuten, auch wenn das Sterben lange dauert), zeigt der Reiseplan einen gelben Hinweis „Speedrun-Trick: …
  spart ~X min – kostet Haltbarkeit“. Nur ein Hinweis, nie ein Routenschritt. Schalter: Einstellungen, „Speedrun: „Tod als Reise“
  vorschlagen“.
- Datenpaket 1.6.2: Friedhöfe (Geistheiler) aus Questie (GPL), auch für Classic Era umgerechnet.
- Testroutine: neuer Test T327.

## 3.12.65
- Route (LW-2b): Im Normalmodus zählt bei Quests jetzt auch die Zeit, nicht nur die Strecke – eine weit entfernte Quest mit kurzer
  Aufgabe zählt weniger, wie im Speedrun. Ausgelassen wird im Normalmodus nichts. Gemessen mit der virtuellen Reise 1–60 für 18
  Charaktere (6 Völker × 3 Klassen): 15 schneller, 3 langsamer, im Median 3 h 17 min weniger, bei 17 von 18 weniger Laufen.
- Classic Era (LW-5 E1/E5): LevelPilot und LevelPilot Data laden jetzt im Classic-Era-Client (Interface 16001 und 11509 in einer
  .toc, gemessen: WoW Forever und Classic Era nehmen sie beide an, nichts „veraltet“). Classic Era ist neu – bitte melden, was
  dort nicht stimmt. Die Prüfliste im Spiel (/lp prüfliste, nur Testmodus) hat in Classic Era eigene 6 Punkte.
- Testroutine: neue Tests T325, T326.

## 3.12.64
- Töte-Ziele (LW-7a): In der Nähe eines Töte-Ziels mit 3 oder mehr Gegner-Gruppen führt der Pfeil („Gegner – Rundgang“) jetzt
  von Gruppe zu Gruppe – immer zur nächsten noch nicht besuchten (besucht ab 30 Yards). Sind alle besucht, beginnt die Runde
  von vorn (Gegner erscheinen wieder). Fundstellen von Questgegenständen haben Vorrang. Schalter: „Pfeil zur nächsten Fundstelle“.
- Testroutine: neuer Test T324.

## 3.12.63
- Navi und Route zusammen (NAV-4): Der Reiseplan nach Zeit steht jetzt auch unter dem nächsten Routenschritt, wenn er weit weg
  ist (ab 1500 Yards oder auf einem anderen Kontinent) – ein Rechenweg für Navi und Route. Nach einer Neuplanung behält derselbe
  Schritt seinen Plan (kein Flackern).
- Schnittstelle für andere Addons, Version 2 (LevelPilotAPI): NavigateToNearest(art), StopNavigation() (nur Ziele, die ein
  Addon gesetzt hat, nie die eigenen des Spielers), GetNavigation() (eine Kopie: Karte, Koordinaten, Titel, Reisezeit,
  Reiseplan) und TravelTime(karte, x, y, rückruf). NavigateTo zeigt jetzt auch den Reiseplan. LevelPilot ändert nie Daten
  anderer Addons.
- Testroutine: neuer Test T323.

## 3.12.62
- Navi unterwegs (NAV-3): Führt der Weg zu einem Navi-Ziel trotzdem an Gegnern ab deinem Level + 3 vorbei (die Wegsuche meidet
  solche Gebiete schon, wo es geht), zeigt der Reiseplan eine rote Zeile „Vorsicht: Gegner bis Stufe X auf dem Weg“. Am
  Navi-Ziel (/lp navi, /lp weg, /lp suche, Kartenmarkierung) meldet LevelPilot jetzt „Navi: angekommen – weiter mit der Route.“
- Testroutine: neuer Test T322.

## 3.12.61
- Route (LW-2a): Die nächsten 8 Schritte nach dem ersten stehen jetzt in der genau kürzesten Reihenfolge (nach Wegkosten), mit
  denselben Regeln (annehmen vor erledigen vor abgeben, der Questlog läuft nie über). Vorher machte das ein schnelles
  Näherungsverfahren (2-opt); es lag in den gemessenen Beispielen schon nahe am Besten, die genaue Reihenfolge spart, wo es geht,
  noch etwas.
- Testroutine: neuer Test T321.

## 3.12.60
- Navigator, Weltkarte (NAV-1c): eine Markierung auf der Weltkarte setzen (Kartenmarkierung des Spiels), und LevelPilot führt
  hin, mit Reiseplan unter dem Ziel. Markierung entfernen beendet dieses Navi, „/lp navi aus“ ebenso. Schalter: Einstellungen,
  „Navi zur Markierung auf der Weltkarte“ (an). In einem Client ohne Kartenmarkierung passiert nichts.
- Testroutine: neuer Test T320.

## 3.12.59
- Navigator, Suche nach Namen (NAV-1b): „/lp navi gornek“, „/lp navi flammenschlund“, „/lp navi brachland“ – NPCs (Questgeber,
  Händler, auch Gegner), Dungeon-Eingänge und Zonen, in der Sprache des Spiels, von LevelPilot oder Englisch. NPCs der anderen
  Fraktion werden ausgelassen; je NPC zählt der nächste Fundort. Ein Treffer: LevelPilot führt sofort hin. Mehrere: die 5
  schnellsten mit Reisezeit („/lp navi 2“ wählt Nummer 2). Die Namensliste entsteht einmal beim ersten Gebrauch, in Portionen.
- Fehler behoben: „/lp navi händler“ und „trainer“ wurden nicht erkannt (seit 3.12.54).
- Testroutine: neuer Test T319.

## 3.12.58
- Navigator, Schritt 2 (NAV-2): Reiseplan nach ZEIT. Für jedes Hinführ-Ziel (/lp navi, /lp weg, /lp suche) rechnet LevelPilot
  jetzt die ganze Kette mit Sekunden je Teilstück: Laufen/Reiten entlang des Wegnetzes, Flug (wenn schneller, gemessene
  Flugzeiten), Schiff, Zeppelin, Tiefenbahn und den Ruhestein, wenn er bereit und schneller ist. Der Guide zeigt das unter dem
  Ziel, zum Beispiel „Reise ~6:36: 20 Yards laufen (0:03) → Zeppelin → Tirisfal (6:30) → 21 Yards laufen (0:03)“, alle 10
  Sekunden neu gerechnet (verbleibende Zeit). In kleinen Portionen gerechnet, kein Ruckeln.
- Annahme, wird gemessen: Ladebildschirm nach dem Ruhestein auf einen anderen Kontinent 20 Sekunden.
- Testroutine: neuer Test T318.

## 3.12.57
- Classic Era, Schritt 4 (LW-5 E4, vorbereitet – im Era-Client noch nicht im Spiel geprüft): Was nur auf WoW Forever Sinn hat,
  richtet sich jetzt nach der Spielversion. In einem anderen Client (Classic Era) erscheint der Schalter „Server WoW Forever“
  nicht (er wirkt dort nicht), die Daten-Seite spricht nicht mehr von neuen WoW-Forever-Quests, Quests werden nicht als NEU
  markiert, und der Selbsttest warnt bei Classic Era nicht mehr. WoW Forever bleibt unverändert.
- Ebenfalls geprüft, ohne Änderung: Startdatenbank (leer), Datenpaket (Classic-Daten, seit 3.12.55 zurückgerechnet),
  Startwegnetz und Forever-Strassen (nur im Forever-Client), Forever-Regeln (Questlog 40, Dungeon-EP) folgen schon der Spielversion.
- Testroutine: neuer Test T317.

## 3.12.56
- Classic Era, Schritt 3 (LW-5 E3, vorbereitet – im Era-Client noch nicht im Spiel geprüft): Im Classic-Era-Client hält
  LevelPilot seine kontoweit gesammelten Daten getrennt von WoW Forever (gelaufene Wege, gelernte Quests, Flugpunkte,
  Händler, Kalibrierung, Austausch und Einstellungen) – sonst bekäme ein Era-Charakter die Forever-Wege und die neuen
  Forever-Quests. Gemeinsam bleiben: Diagnose-Protokoll, Wegdaten-Export, Testberichte, Prüfliste, Marktdaten. WoW Forever liest und schreibt genau dieselben Daten wie bisher; nichts wird verschoben oder geht verloren.
- Testroutine: neuer Test T316.

## 3.12.55
- Classic Era, Schritt 2 (LW-5 E2, vorbereitet – im Era-Client noch nicht im Spiel geprüft): Datenpaket und eigene Daten von
  LevelPilot liegen im Kartenrahmen von WoW Forever. Vier Zonen haben in Forever andere Kartengrenzen (Mulgore, Östliche
  Pestländer, Rotkammgebirge, Sturmwind). Im Classic-Era-Client rechnet LevelPilot sie jetzt beim Laden einmal zurück (NPCs,
  Objekte, Erkundungsziele, Dungeon-Eingänge, Briefkästen; ebenso Zonenübergänge, Geländekarten und die Startpunkte der
  virtuellen Reise). Gegen die Originalwerte von Questie geprüft: Abweichung im Median 0,04 % der Karte. WoW Forever bleibt
  unverändert.
- Testroutine: neuer Test T315.
- Die Strassen für Classic Era stammen jetzt aus dem echten Classic-Era-Client 1.15.9 (99,6–99,99 % gleich wie vorher aus Anniversary).

## 3.12.54
- Navigator, erster Schritt (NAV-1a): ein Befehl /lp navi. „/lp navi 45 60 Brachland“ führt zu Koordinaten, auch in einer
  anderen Zone (Zonenname in der Sprache des Spiels oder von LevelPilot, der Anfang genügt); „/lp navi briefkasten“
  (gasthaus, flug, bank, auktion, händler, reparatur, trainer) zum nächsten Dienst; „/lp navi aus“ beendet, die Route geht weiter.
- Der nächste Dienst wird jetzt nach Wegkosten (Umweg der Zone) gewählt, nicht nach Luftlinie.
- Fehler behoben: das englische Wort „repair“ wurde von /lp suche nicht erkannt.
- Testroutine: neuer Test T314.

## 3.12.53
- Strassen auch für Classic Era (ST-5): ein Strassennetz der Grundwelt (Kalimdor, Östliche Königreiche), mit eigenem Werkzeug aus
  dem Anniversary-Client gelesen (dieselbe Welt, 93–96 % der Strassen stimmen mit WoW Forever überein). LevelPilot lädt die
  Strassen der eigenen Spielversion und gibt die anderen frei. Hinweis: LevelPilot selbst läuft noch nicht auf Classic Era
  (kommt mit LW-5).
- Das Diagnose-Protokoll nennt die Version: „STRASSEN (Forever) …“.

## 3.12.52
- Korrektur zu 3.12.51: Der Umweg-Faktor je Zone wird jetzt an BEKANNTEN Wegen gemessen (gelaufene Wege, Startnetz, Strassen).
  3.12.51 mass am Weg der Wegsuche selbst – der geht im offenen Gelände gerade, rund 1,0, während die gelaufenen Wege der
  Spieler rund 1,5-mal so lang wie die Luftlinie sind (gemessen an 5445 Paaren der eingesandten Wege). Die Paare werden jetzt
  in der Umgebung gesucht (300–2000 Yards), damit auch grosse Zonen genug Paare haben. Bis gemessen: 1,25 wie bisher.

## 3.12.51
- Planung mit echten Wegkosten statt Luftlinie (LW-1): LevelPilot misst je Zone, wie viel länger der Weg der Wegsuche ist als
  die Luftlinie (Strassen, gelaufene Wege, Gelände; Median aus bis zu 12 Paaren, im Hintergrund, 1,0–1,8, bis gemessen 1,25).
  Reihenfolge der Schritte, Fokus-Zone, der Zeitfaktor im Speedrun und der Flugentscheid rechnen damit. Zonen mit Bergen und
  Schluchten (Tausend Nadeln, Alterac) wirken nicht mehr näher, als sie sind. Das Diagnose-Protokoll zeigt „UMWEG je Zone …“.
- Testroutine: neuer Test T313.

## 3.12.50
- Strassen aus den Spieldateien (WoW Forever): LevelPilot kennt jetzt die Strassen von Kalimdor und den Östlichen Königreichen
  (mit eigenem Werkzeug aus den Bodentexturen des Forever-Clients gewonnen, rund 200 000 Yards). Die Wegsuche folgt ihnen
  wie gelaufenen Wegen; geladen wird in kleinen Portionen nur der Kontinent, auf dem du bist. Nicht gespeichert, nicht
  geteilt. Das Diagnose-Protokoll zeigt „STRASSEN …“.
- Testroutine: neuer Test T312.

## 3.12.49
- Fliegen nach Zeit statt nach Strecke (LW-3): LevelPilot vergleicht die Laufzeit mit der Zeit über den Flugmeister (hinlaufen,
  ansprechen, Flug, weiterlaufen) und fliegt nur, wenn das mindestens 30 Sekunden schneller ist. Die Flugzeit kommt aus deinen
  gemessenen Flügen (ab 3 Flügen, Flüge von Mitspielern helfen), sonst aus einer Annahme. Tempo am Boden: dein gemessenes
  Reittier-Tempo, sonst zu Fuss. Das Diagnose-Protokoll zeigt den letzten Vergleich („REISE …“).
- Testroutine: neuer Test T311.

## 3.12.48
- Messung der Laufwege (Grundlage für bessere Wege, LW-6): je Schritt die Luftlinie, die bis zur Ankunft tatsächlich gelaufene
  Strecke, die Zeit auf dem Weg und am Ziel, die Art des Pfads (Wegnetz / Gelände / Luftlinie / unbekannt); Neuplanungen mit
  Richtungswechsel; Leerlauf ohne Ziel; EP je Stunde für jedes Level. Gespeichert werden nur Summen je Zone und je Level (je
  Charakter). AFK, Tod, Flüge, Teleporte, die virtuelle Reise und die Testroutine zählen nicht. Ergebnis: Zeilen „LAUFWEG“
  und „EP/h je Level“ im Diagnose-Protokoll (/lp protokoll).
- Testroutine: neuer Test T310.
- Gemeinsame Datei GoldSentinelDev.lua (Version 2, Prüfsummen statt Namen) jetzt dabei: die Prüfliste im Spiel (Testmodus)
  geht auch ohne andere GoldSentinel-Addons.

## 3.12.47
- Nur Testmodus (für Spieler unsichtbar): Prüfliste im Spiel /lp prüfliste (auch /lp pruefliste) mit dem gemeinsamen
  GoldSentinel-Baustein GoldSentinelPruefliste. 14 offene Punkte „im Client prüfen“ in sinnvoller Reihenfolge; das Fenster
  zeigt zum nächsten offenen Punkt immer, was zu tun ist und was du sehen musst. Die meisten Punkte merken selbst, dass sie
  erledigt sind (Hinweis gezeigt, Plus beim Händler gesetzt, Messung gemacht); nur „hinschauen und bestätigen“ braucht „OK“ /
  „Nicht OK“. Testläufe und die virtuelle Reise markieren nie etwas. Das Ergebnis steht im Diagnose-Protokoll.
- Testroutine: neuer Test T309.

## 3.12.46
- Neuer Befehl /lp wegmessung: geführte Wegmessung für das Messwerkzeug GSWegMess (Unterstadt Auktionshaus -> Magieviertel
  und zurück, Aufzüge in Unterstadt, Aufzug in Donnerfels, eine Höhle). Ein kleines Fenster sagt, welche Strecke du laufen und
  wann du markieren sollst; „Markieren & weiter“ schreibt eine Notiz in GSWegMess, der Pfeil zeigt zu bekannten Zielen.
  GSWegMess bleibt unverändert; fehlt es, sagt LevelPilot, wo es liegt.
- Testroutine: neuer Test T308.

## 3.12.45
- Neuer Befehl /lp clienttest: ein geführter Test der neuesten Funktionen im Spiel (Ebenen-Angabe, Startwegnetz, sprachfreie
  Ebenen, Erholt-Hinweis, Waffenfertigkeit, Waffenmeister, abgegraste Stelle, Händler-Upgrades, Talent-Vorschlag,
  Schnittstelle für andere Addons). Was im Spiel messbar ist, prüft LevelPilot selbst; ein kleines Fenster fragt nur dort,
  wo du hinschauen musst (ein Satz, Knöpfe „OK“ / „Nicht OK“ / „Überspringen“). Ergebnis: eine Zeile je Punkt in /lp diag.
- Testroutine: neuer Test T307.

## 3.12.44
- Neue Schnittstelle für andere Addons: LevelPilotAPI.NavigateTo(uiMapID, x, y, Titel) – LevelPilot führt zu diesem Ort wie
  zu eigenen Zielen (Pfeil, Weg, Flüge). ProfessionSentinel nutzt sie für „Nächster Lehrer – Weg zeigen“. Siehe README.
- Testroutine: neuer Test T306.

## 3.12.43
- Talent-Vorschlag: Der Hinweis „Talentpunkt(e) frei“ nennt jetzt auch den nächsten Punkt aus LevelPilots eigenem
  Level-Build für deine Klasse, mit einem Satz warum (z. B. „Heldenhafter Stoß kostet weniger Wut – du schlägst ihn öfter“).
  Ein Build je Klasse (51 Punkte), geprüft gegen die Talentbäume von WoW Forever; waffenabhängige Talente richten sich nach
  deiner angelegten Waffe. Nur ein Vorschlag – nichts wird automatisch gelernt, das Talentfenster bleibt unverändert.
  Begründungen auf Deutsch und Englisch.
- Testroutine: neuer Test T305.

## 3.12.42
- Händlerfenster: Waren, die für deine Klasse ein Upgrade wären, bekommen oben links ein Plus-Zeichen (gleiche Bewertung wie
  „Mögliches Upgrade“: Werte deiner Klasse, Rüstungsart, Level, benutzbar). Nur markieren – gekauft wird nichts. Nur im
  Kauf-Reiter, wandert beim Blättern mit. Schalter: Zentrale » Assistent » „Ausrüstungs-Upgrades“.
- Testroutine: neuer Test T304.

## 3.12.41
- Abgegraste Stelle: Stehst du 3 Minuten am Ziel einer Töte- oder Sammelquest ohne Fortschritt (nicht AFK), fragt der
  Assistent, ob die Stelle abgegrast ist, und zeigt, wie weit die nächste Stelle entfernt ist. „Andere Stelle“ merkt die
  Stelle 20 Minuten lang als leer, und LevelPilot plant die nächste. Nichts passiert von selbst – du entscheidest.
  Schalter: Zentrale » Assistent » „Abgegraste Stelle“.
- Testroutine: neuer Test T303.

## 3.12.40
- Neuer Hinweis im Assistenten: Liegt eine Waffe (grün oder besser) einer Art in der Tasche, die du noch nicht gelernt
  hast, nennt LevelPilot den Waffenmeister, der sie lehrt (eigene Fraktion, der nächste zuerst), mit „Hinführen“ – etwa
  10 Silber (Stangenwaffen ab Level 20, etwa 1 Gold). Nur Waffenarten, die deine Klasse auf WoW Forever lernen darf;
  Schalter: Zentrale » Assistent » „Waffenfertigkeit“.
- Testroutine: neuer Test T302.

## 3.12.39
- Zwei neue Hinweise im Assistenten (Wünsche von Spielern aus vergleichbaren Level-Führern; beide abschaltbar unter
  Zentrale » Assistent):
  - Erholt-Bonus: Gehst du ausserhalb von Gasthaus oder Hauptstadt AFK, schlägt LevelPilot vor, im Gasthaus auszuloggen –
    dort wächst der Erholt-Bonus 4× so schnell (doppelte EP für Monster). Mit „Hinführen“ zum nächsten Gasthaus.
  - Waffenfertigkeit: Liegt die Fertigkeit der angelegten Waffe 25 oder mehr unter dem Höchstwert (z. B. neue Questwaffe),
    verfehlst du öfter – LevelPilot sagt es, damit du an leichteren Gegnern üben kannst.
- Testroutine: neue Tests T300 und T301.

## 3.12.38
- Vorbereitung für die Führung über Stockwerke (bleibt aus bis zur Messung): Die Ebene eines Wegpunkts wird jetzt
  sprachunabhängig gespeichert. Unterzonen-Namen (z. B. „Magieviertel“, „Das Magieviertel“, „Magic Quarter“) werden über
  eine kleine Tabelle aller 11 Spielsprachen auf einen Schlüssel abgebildet (öffentliche Gebietstabellen, Zweig WoW Forever;
  nur Städte mit mehreren Ebenen). Schon gespeicherte Angaben werden beim Laden umgestellt. Hinweise zeigen weiter den Namen
  in deiner Spielsprache.
- Testroutine: neuer Test T299.

## 3.12.37
- Startwegnetz für Mulgore, Brachland und Donnerfels: LevelPilot bringt jetzt eigene Koordinatenlisten gelaufener Wege
  mit (aus den eingesandten Wegdaten von LevelPilot-Spielern, ohne Namen; keine Spieldateien, keine Kartenbilder). Neue
  Charaktere bekommen dort sofort Wege entlang echter Pfade statt nur Luftlinien. Selbst gelaufene Wege werden mit
  genutzt; das Startwegnetz wird nie gespeichert und nie geteilt. Nur im WoW-Forever-Client (die Karten von Classic
  Era/TBC sind anders); nach dem Einloggen in kleinen Portionen geladen (kein Ruckeln).
- Testroutine: neuer Test T298 (Startwegnetz geladen, nichts gespeichert).

## 3.12.36
- Vorbereitung für bessere Führung in Städten mit mehreren Stockwerken und in Höhlen (Unterstadt, Donnerfels): Beim Laufen
  speichert LevelPilot jetzt auch, auf welcher Ebene ein Wegpunkt liegt (Karte, drinnen/draussen und Unterzone, z. B.
  „Magieviertel“). Jeder Ebenen-Name wird nur einmal gespeichert, der Wegpunkt behält nur seine Nummer – die gespeicherten
  Daten bleiben klein. Die geteilten Wegdaten (Export) enthalten diese Ebenen-Angabe je Punkt.
- Die Führung selbst bleibt unverändert: die neue Trennung der Ebenen, Aufzüge (mit Wartezeit), Sprung-Stellen (nur nach
  unten) und Hinweise wie „Aufzug nehmen (nach …)“ sind eingebaut, aber ausgeschaltet, bis Messungen im Spiel belegen, dass
  die Unterzone die Ebenen wirklich trennt.
- GoldSentinelMarkt.lua Version 7 (unverändert aus dem gemeinsamen Ordner).
- Testroutine: neuer Test T297 (Ebenen-Angabe wird gespeichert, Führung unverändert).

## 3.12.35
- Undercity: kein „Weg unbekannt“ mehr, wenn ein gelaufener Weg zum Ziel existiert. Die Wegsuche nahm in der Stadt mit
  mehreren Ebenen kurze Luftlinien quer über die Ebenen – solche Wege gelten als unbekannt. Findet die normale Suche nur
  so einen Weg, sucht LevelPilot jetzt einen Weg nur über gelaufene und geteilte Wege und nimmt diesen (z. B. vom
  Auktionshaus zu Bethor Iceshard im Magieviertel). Gilt überall, nicht nur in Undercity.
- Testroutine: neuer Test T296 (mit dem eigenen Wegnetz); Offline-Routine: Prüfung mit den eingesandten Wegdaten von
  Undercity.

## 3.12.34
- Kein Ruckler mehr alle 5 Minuten: LevelPilot hat alle 5 Minuten den Speicher ALLER Addons messen lassen
  (UpdateAddOnMemoryUsage) – das kann bei vielen Addons hunderte Millisekunden dauern. Jetzt misst der 5-Minuten-Takt nur
  den gesamten Lua-Speicher (billig). Den Speicher von LevelPilot allein misst es nur noch, wenn du das Fehler-Protokoll
  öffnest; die Diagnose zeigt dazu, wie lange diese Messung gedauert hat.
- Diagnose: „SPEICHER Lua gesamt (alle Addons, alle 5 Min.)“ und „SPEICHER LevelPilot (gemessen beim Öffnen des
  Protokolls)“; je Sitzung steht jetzt „Lua gesamt“. Die Assistent-Prüfung (alle 30 s) wird jetzt auch in der
  Zeitmessung gezeigt.
- Klick auf „Neu planen“ direkt nach einem Stufenaufstieg oder Sprachwechsel rechnet in kleinen Portionen statt am Stück
  (vorher bis rund 26 ms in einem Bild).
- GoldSentinelMarkt.lua Version 6 (unverändert aus der gemeinsamen Ablage).
- Testroutine: neue Tests T294 (5-Minuten-Takt ohne teure Messung) und T295 (Klick mit kalten Zwischenspeichern).

## 3.12.33
- Zeitmessung richtig: Läuft eine Rechnung in kleinen Portionen über mehrere Bilder, zählt die Wartezeit dazwischen nicht
  mehr als Rechenzeit. Daher kam die Angabe „Questauswertung 495 ms“ nach dem Einloggen – gerechnet wurden nur einige ms.
  In der Diagnose steht ein Höchstwert über 16 ms jetzt mit „(über 16 ms)“ dahinter (rot, wo Farben gezeigt werden).
- Questauswertung beim Stufenaufstieg und nach dem Umschalten von „Server WoW Forever“ bzw. „Dungeon-Quests einplanen“
  läuft jetzt auch in Portionen statt am Stück.
- Kompaktmodus (eine Zeile): Gibt es Quests zum späteren Abgeben, steht „+n später abgeben“ grün hinter dem Schritt;
  die Questnamen zeigt der Tooltip.
- Die Zeile „MELDUNGEN: …“ in Diagnose und Testbericht erscheint in der eingestellten Sprache.
- Testroutine: neue Tests T292 (Zeitmessung mit Portionen, Questauswertung Stufe 31) und T293 (Kompaktmodus).

## 3.12.32
- Routenplanung viel schneller: Die Prüfung, ob der Weg zu einer Aufgabe durch Gebiete mit zu starken Gegnern führt,
  kostete fast die ganze Planungszeit. Sie rechnet jetzt dieselben Punkte ohne Umweg und hört auf, sobald die Grenze
  erreicht ist. Im Wald von Elwynn (Allianz, Stufe 10) sinkt eine Planung von rund 26 ms auf rund 4 ms – kein Ruckeln mehr.
- Testroutine: neuer Test T291 (schnelle Rechnung = bisherige Rechnung auf 2000 Strecken); T150 prüft jetzt auch den
  Höchstwert (unter 33 ms).

## 3.12.31
- Neuer Schalter „Meldungen“ (Zentrale → Einstellungen, oben). Aus = LevelPilot meldet nichts mehr von selbst: keine
  Chat-Hinweise, nichts in der Bildschirmmitte, kein Ton, keine Einblendungen, keine Hinweise des Assistenten
  (z. B. „Erste Hilfe kannst du hier lernen“, Trainer, Reittier, offene Abgaben, „Wo war ich?“, Bilanz beim Ausloggen,
  Questgegenstand in der Nähe). Antworten auf deine eigenen Befehle und Klicks (z. B. /lp diag, /lp find,
  „Im Kampf nicht möglich.“) kommen weiter. Der Guide mit Schritten, Pfeil und Pfadlinie bleibt. Standard: an.
- Alle Meldungen laufen über eine einzige Weiche; Testbericht und Diagnose zeigen „MELDUNGEN: an/aus · unterdrückt n ·
  durchgerutscht n“.
- GoldSentinelMarkt.lua Version 4 (unverändert aus der gemeinsamen Ablage).
- Testroutine: neuer Test T290 (Schalter „Meldungen“).

## 3.12.30
- Fertige Quests bleiben sichtbar: Liegt die Abgabe weit weg (ausserhalb der Zone, in der du gerade questest), steht
  in der Liste der Hinweis „Später abgeben: Quest (Zone)“ – in der letzten angezeigten Zeile, auch im Dungeon. Die
  Grundregel-Prüfung zählt ihn als Abgabe-Schritt (vorher meldete die Diagnose „Quest … fertig, aber kein
  Abgabe-Schritt“). Überspringen oder Zurückstellen entfernt den Hinweis nicht.
- Diagnose (/lp diag): Speicher nach dem Einloggen, aktuell und Höchstwert, dazu der Speicher, den jedes Modul seit dem
  Einloggen angelegt hat, und die Grösse der Zwischenspeicher. Auch je Sitzung in der Sitzungsliste.
- GoldSentinelMarkt.lua Version 3 (unverändert aus der gemeinsamen Ablage).
- Testroutine: neue Tests T288 (fertige Quest mit ferner Abgabe) und T289 (Speicher-Messung). T220 meldete auf der
  Allianz fälschlich FEHLER (Hordequest) und ist dort jetzt „nicht prüfbar“.
- Offline-Testroutine für die Prüfung im Repo (berichte/LevelPilot/offline/run_offline.py).

## 3.12.29
- GoldSentinelMarkt.lua Version 2 (unverändert aus der gemeinsamen Ablage): Ist AHSentinel geladen, liest die Datei
  dessen Vollscans nicht ein zweites Mal – kein Ruckeln mehr beim Vollscan und im Sniper. Ausverkaufte Items im Export.
- Testroutine: T283 stellt den Zustand „ein anderes Addon gibt gerade einen Scan weiter“ (feedUntil) mit zurück und hängt
  nicht davon ab, ob AHSentinel geladen ist; neuer Regressionstest T287.

## 3.12.28
Marktdaten-Netz (gemeinsam mit allen GoldSentinel-Addons).
- Neu dabei: GoldSentinelMarkt.lua (unverändert aus der gemeinsamen Ablage). Macht irgendein Addon im Auktionshaus einen
  Vollscan, liest LevelPilot ihn still mit (tiefster Stückpreis, Menge, Anzahl Auktionen je Item) und teilt die Preise
  anonym mit Gilde und Netz. Keine Namen, keine Abfrage, LevelPilot startet selbst nie einen Scan. Läuft je Client nur
  einmal, egal wie viele GoldSentinel-Addons installiert sind. Ohne Auktionshaus-API (Era, TBC) bleibt es still aus.
- Schalter „Marktdaten teilen (anonym, nur Preise)“ in der Zentrale unter Austausch, Standard an.
- Testbericht und Diagnose: Zeile „MARKT-NETZ: Version, an/aus, mitgelesene Scans, gesendet/empfangen, Speicher“.
- Zentrale: Der Schalter „Befehlsliste beim Tippen von /lp“ lag auf derselben Stelle wie „Einstellungen nur für diesen
  Charakter“ und hat eigene Zeile bekommen.
- Testroutine: neue Fälle T282–T286 (mit/ohne Datei, Schalter aus, ohne Auktionshaus-API, Berichtzeile, Schalter-Stellen).
- Richtigstellung zu 3.12.26: umgesetzt sind TU1–TU8. Die Offline-Routine (TU9) folgt in einer eigenen Version.

## 3.12.27
Befehlsliste beim Tippen.
- Tippst du /lp (oder /levelpilot) in den Chat, erscheint über dem Eingabefeld die Liste ALLER LevelPilot-Befehle mit
  kurzer Beschreibung in deiner Sprache. Jeder weitere Buchstabe filtert („/lp w“ -> weg, wege …); meistbenutzte oben.
- Klick oder Tab wählt einen Eintrag aus, Enter führt ihn aus. Das Chatfeld wird nie beschrieben. Ausschalten in der
  Zentrale (Anzeige: „Befehlsliste beim Tippen von /lp“).
- Slash-Handler und Liste benutzen eine Befehlstabelle – jeder Befehl, den der Handler kennt, steht in der Liste;
  Entwickler-Befehle nur für den Entwickler.
- Testroutine: neue Fälle T276–T281 (T-BL1–T-BL6).

## 3.12.26
Umfassende Tests (TU1–TU8; TU9 Offline-Routine folgt), damit im Spiel gefundene Fehler nicht wiederkommen.
- TU1 Lagen: jedes Volk und jede Klasse deiner Fraktion mit Stufe 1, 12, 30 und 58 läuft durch die Questauswahl
  (Fraktion, Klasse, Volk, Stufe, Startgebiet); Queststand erledigt / im Log / fehlgeschlagen / abgebrochen (T269).
- TU2 Abläufe wie ein Spieler: /reload unterwegs, Planmodus wechseln, Tod -> Geistheiler -> weiter, automatische
  Abgabe mit einer oder mehreren Belohnungen; am Ende keine Lua-Fehler und nichts Echtes ausgeführt (T270).
- TU3 Standardwerte: jede Option ab Werk, Liste im Testbericht (T271).
- TU4 Grundregeln mit 1000 Zufallsfällen (fester Startwert, in Portionen): kein Weg über Gelände, das die
  Geländekarte als unbegehbar kennt, nie automatisch eine Belohnung bei mehreren zur Wahl, Zeitschätzungen 0–6 h,
  keine geschützte Aktion im Kampf (T272).
- TU5 echte Daten (nur lesen): alle 10 Minuten werden Questlog und gemessene Werte gegen den Plan geprüft;
  Verletzungen stehen im Diagnose-Protokoll als „GRUNDREGEL VERLETZT …“ (T274).
- TU6 Regressionen: jeder Befund seit dem 1. November hat einen bleibenden Test; Zeile „Regressionen: n von m
  vorhanden“ (T273).
- TU7 Formen des Spiels: Forever, Era, TBC, Deutsch und Englisch, Fenster bei 80 % Skalierung (T275).
- TU8: Der Testbericht zeigt je Bereich TU1–TU7 eine Zeile.

## 3.12.25
- Notbremse der Routenplanung: Bei Planung in Portionen im Hintergrund zählt nur die längste Portion (über 50 ms),
  nicht die Summe – eine lange Planung in kleinen Portionen pausiert die Route nicht mehr. Eine während einer Pause
  gewünschte Planung wird danach einmal nachgeholt, statt verworfen.
- Die Suchschritt-Grenze der kurzen Wegprüfung in der Planung gilt nur für diese Suche (vorher ein globaler Wert, der
  nach einer abgebrochenen Planung auf 1200 stehen bleiben konnte – lange Wegsuchen fanden dann bis /reload keinen Weg).
- LANGSAM-Einträge der Notbremse werden von den eigenen Planungs-Einträgen nicht mehr gelöscht.
- Wegnetz: Hat 3.12.23 schon Lücken von 25–80 Yards geteilt, werden diese Stücke einmal erkannt (Punkte genau auf
  einer Linie in gleichen Abständen) und als unsicher markiert; gelöscht wird nichts.
- Hintergrund-Arbeit: Eine Portion darf sicher einen neuen Auftrag starten.
- Diagnose-Protokoll: In einer Pause verworfene Aufrufe werden gezählt („ZEIT in Pausen verworfen“).
- Testroutine: neue Fälle T266–T268, T262 erweitert.

## 3.12.24
Behoben: Das Spiel konnte nach dem Einloggen auf einem Charakter mit grossem aufgezeichnetem Wegnetz einfrieren
(CPU über 100 %).
- Ursache: Die Wegsuche verband jeden Suchschritt per Luftlinie mit hunderten Wegpunkten in der Nähe und prüfte jede
  Linie gegen die Geländekarte. Mit dem dichteren Wegnetz (Punkte alle 12–25 Yards, geteilte alte Stücke in 3.12.23)
  dauerte eine Suche mehrere hundert Millisekunden. Sie lief nach jeder Planung erneut, abseits des Weges alle 0,5 s,
  und jede von Gildenmitgliedern empfangene Quest leerte zudem den Zwischenspeicher der Suche.
- Die Wegsuche nimmt für Luftlinien jetzt höchstens zwei Wegpunkte je 100-Yards-Feld und merkt sie sich; empfangene
  Quests leeren den Zwischenspeicher nicht mehr (die Geländekarte kommt aus dem Datenpaket).
- Schwere Arbeit läuft in Portionen im Hintergrund (höchstens 4 ms je Bild): Wegsuche, Geländeführung, automatische
  Routenplanung und die einmalige Aufbereitung des Wegnetzes. Ein Klick von dir plant weiterhin sofort.
- Notbremse: Braucht ein Teil mehr als 50 ms am Stück oder mehr als 1 s in 5 s, pausiert er 60 s – eine Chatzeile und
  ein Eintrag LANGSAM im Diagnose-Protokoll (Teil, Zeit, Anzahl Ziele und Wegpunkte, Zone).
- Abseits des Weges wartet LevelPilot nach einer teuren Suche länger (bis 10 s), statt alle 0,5 s zu suchen.
- Die Planung prüft den ersten Weg nur mit einer kurzen Suche.
- Diagnose-Protokoll: Rechenzeit je Teil (Route, Wegsuche, Wegnetz, Netz-Empfang, Quests, Anzeige …), die ersten 60 s
  nach dem Einloggen getrennt. Beim Ausloggen wird das Protokoll als GSDIAG1 in die Speicherdatei geschrieben (für die
  Testberichte, ohne Namen; LevelPilotDB.diagSend = false schaltet es ab).
- Wegnetz: geteilt werden nur Stücke über 80 Yards (25–80 Yards kann eine Lücke zwischen zwei Aufzeichnungen sein –
  als unsicher markiert, bis es nochmals gelaufen wird); kein verwaister Punkt, wenn das Teilen scheitert.
- Testroutine: neue Fälle T261–T265 (T-LAG1–T-LAG4), T148 misst die Portionen.

## 3.12.23
- Zonen-Anfragen und Mitspielersuche ohne Prüfsumme des Absenders (LevelPilot bis 3.12.21) werden nicht mehr
  angenommen – ein Weitergeber konnte sie unter seinem Namen in seine Gilde bringen. Spieler mit 3.12.21 bekommen bis
  zu ihrem Update keine Zonen-Antworten und keine Mitspieler-Hinweise von anderen.
- Wegaufzeichnung: Position alle 0,5 s; eine Lücke über 25 Yards zwischen zwei Positionen (Ruckler, Teleport, sehr
  schnell) trennt den Weg, statt sie als gerade Linie zu speichern.
- Einmal nach dem Update werden lange gerade Wegstücke älterer Versionen in Stücke von höchstens 25 Yards geteilt
  (auf der gelaufenen Linie), danach werden lose Enden nochmals verbunden.
- Testroutine: neue Fälle T259, T260; T254 erweitert.

## 3.12.22
- Die Austausch-Einstellungen werden genau eingehalten: Gilde, Gruppe und Flüster-Netz nur, wenn eingeschaltet. Das
  Netz geht nur mit, wenn Gilde und Gruppe beide an sind (GoldSentinelSync kennt noch kein „nur Netz“).
- Zonen-Anfragen und die Mitspielersuche für Elite-Quests gehen nur an Gilde und Gruppe und tragen eine Prüfsumme des
  Absendernamens. Übers Netz weitergegebene Nachrichten (Absender = Weitergeber) werden nicht beachtet – keine Antwort
  an den Falschen, kein falscher Name im Mitspieler-Hinweis.
- Zonen-Antworten haben höchstens 25 Nachrichten (der Rest bei der nächsten Anfrage) und gehen nur, wenn die
  gemeinsame Warteschlange aller GoldSentinel-Addons fast leer ist.
- Aufzeichnungen, die nicht gesendet werden konnten (kein Weg), gehen später in derselben Sitzung noch hinaus.
- Testroutine: eigene leere Warteschlangen; Nachrichten anderer Addons werden während des Tests nicht mehr gesendet.
- Diagnose-Protokoll: kein „Schritt seit 25 min aktiv“ mehr, solange du in einer Hauptstadt stehst (Bank,
  Auktionshaus, Post) oder im Dungeon bist; keine Fokus-Meldung, wenn der aktuelle Schritt in deiner Zone liegt; keine
  Zonen-Meldung in Höhlen ohne eigene Karte.
- Testroutine: neue Fälle T254–T258, T243 erweitert.

## 3.12.21
Datenaustausch über die gemeinsame Datei GoldSentinelSync (Version 2) statt über einen eigenen Chat-Kanal.
- In WoW Forever kommen Addon-Nachrichten in eigenen Chat-Kanälen nie an. LevelPilot betritt den Kanal
  „LevelPilotNet“ nicht mehr und verlässt ihn einmal (frei werdender Kanalplatz).
- Gesendet wird über Gilde, Gruppe/Schlachtzug und das neue Flüster-Netz von GoldSentinelSync 2 (erreicht alle Spieler
  mit LevelPilot über die Gilden hinaus): aufgezeichnete Quests, Wege, Höhlen, Flüge, Zonen-Anfragen und Lebenszeichen.
  Nur Gilde und Gruppe: Beute- und Gegnerwerte (häufig) und der Gruppenmodus (Stufe, Schritt, Quests – nur die Gruppe).
  Die Mitspielersuche für Elite-Quests (falls eingeschaltet) geht wie bisher über den Kanal jetzt ins Netz.
  Zonen-Antworten gehen per Flüstern an den Fragenden.
- Ältere LevelPilot-Versionen anderer Spieler werden weiter verstanden (gleiche Kennung).
- Bekannte Mitspieler des Netzes bleiben über /reload erhalten (LevelPilotDB.gsSync, nur Namen und Zeiten, nur lokal).
  Frühere Absendernamen in der Speicherdatei stehen jetzt nur noch als Prüfsumme.
- /lp sync test: „N Antworten (Gilde a, Gruppe b)“. Diagnose-Protokoll: SYNC-/NETZ-Zeilen (ohne Namen),
  NOT_ALLOWED_IN_CHANNEL wird gezählt.
- Zentrale, Reiter Austausch: „Über das Flüster-Netz“ statt Addon-Kanal, Mitspieler online statt Kanalstatus.
- GoldSentinelTest 2: Fehlerberichte an den Entwickler teilen (nur mit Zustimmung, /gstest).
- Testroutine: neue Fälle T242–T253; T92, T108, T111, T169 angepasst.

## 3.12.20
- Gemeinsame Datei GoldSentinelGame.lua Version 3 (nur Kommentare, keine Spielernamen in den Beispielen).
- Keine echten Charakternamen in den eigenen Dateien: Tests verwenden „Testa Beispiel“, der Entwickler-Charakter
  steht nur noch als Prüfsumme im Code.

## 3.12.19
- Weitere Abfragen werden vor der Benutzung auf geschützte Werte geprüft: Blickrichtung (Pfeil, Minikarte), drinnen
  (Höhlen, Kartenradius), Erholung, Laufgeschwindigkeit sowie die Stufe von Spieler und Begleiter. Eine geschützte
  Stufe fällt auf die zuletzt lesbare zurück.
- Testroutine: neuer Fall T241. T128 prüft alte Daten jetzt ohne die eigenen Messungen (im Spiel stand vorher
  „gemessen true“). Absichtliche Testfehler von T158–T163 erhöhen den Fehlerzähler im Bericht nicht mehr.

## 3.12.18
- Die eigenen Tooltips verdecken die Knöpfe nicht mehr (Unterstützen, Zentrale, Normal, Überspringen …). Sie stehen
  neben dem Fenster, zu dem der Knopf gehört – rechts, ohne Platz links, sonst darunter – auf Höhe des Knopfs. Gilt
  für Leitfenster, Schrittliste, Assistent-Zeile, Grössen-Griff, Aktionsleiste und Pfeil.
- Testroutine: neuer Fall T240.

## 3.12.17
Bessere Wegdaten (aus der Auswertung der eingesandten Wegdaten).
- Neue Wegstücke werden ans bestehende Netz gehängt: liegen Anfang, Ende oder eine Kreuzung bis 10 Yards neben einem
  bekannten Weg, wird dieser dort geteilt und verbunden. Lose Enden bestehender Wege werden nach dem Update einmal
  verbunden (es geht nichts verloren).
- Wegpunkte werden mindestens alle 25 Yards und bei jeder Richtungsänderung über 30° gespeichert (vorher hatten
  gerade Stücke von einigen hundert Yards keinen Punkt dazwischen).
- Auf der Kontinentkarte (Flug, Schiff) werden keine Wege aufgezeichnet oder gesendet.
- Wegdaten (/lp wege, GSWEGE1): Orte der Questgeber alt/neu beide als [x, y], "oldMap", wenn das Datenpaket den NPC
  auf einer anderen Karte hat, als Ort im Datenpaket der nächste auf derselben Karte (nicht der erste), "nopack" für
  NPCs ohne Ort im Datenpaket.
- Datenpaket 1.6.1: Orte von Gordo (10666, Tirisfal) und Bluff Runner Windstrider (10881, Thunder Bluff) für WoW
  Forever korrigiert.
- Testroutine: neue Fälle T235–T239.

## 3.12.16
Graue Gegenstände werden automatisch verkauft, ohne Knopf.
- Öffnet sich ein Händlerfenster, verkauft LevelPilot alle grauen Gegenstände mit Verkaufswert von selbst (ausserhalb
  des Kampfes, ein Gegenstand alle 0,2 s, Stopp beim Schliessen des Händlerfensters oder bei Kampfbeginn). Gesperrte
  Gegenstände und solche, die eine Quest braucht, bleiben. Danach eine Chatzeile: „N graue Gegenstände verkauft für …“
  – keine Zeile, wenn nichts verkauft wurde.
- Option „Graue Gegenstände beim Händler verkaufen“ (ab Werk an) in der Zentrale, oder /lp grau zum Umschalten.
- LevelPilot legt nichts auf oder neben das Händlerfenster. Hinweis: der Knopf „Verkaufen: 0 Items (0)“ am
  Händlerfenster stammt von AHSentinel, nicht von LevelPilot.
- Testroutine: neue Fälle T230–T234 (Option an/aus, nur Qualität 0, Abbruch bei MERCHANT_CLOSED, im Kampf nichts,
  im Test nur mitgeschrieben). Fälle, die in der aktuellen Lage nicht prüfbar sind (z. B. Level 60, kein Datenpaket,
  kein Ziel), zählen jetzt als „übersprungen“ mit Grund statt als „OK“.

## 3.12.15
Die Testroutine prüft die Oberfläche (aus der GoldSentinel-Vorlage).
- Neue Datei UICheck.lua: alle LevelPilot-Fenster sind angemeldet (Leitfenster, Zentrale, Sicherung, Gruppenfeld,
  virtueller Durchlauf, Spenden, Schrittmenü, Aktionsleiste, Pfeil).
- Neuer Bereich K in /lp testroutine (T224–T229): eigene Tooltips verdecken keine Knöpfe, kein Überlappen mit
  Blizzard- oder anderen GoldSentinel-Fenstern, Fenster ganz im Bildschirm, Knopfbeschriftungen nicht abgeschnitten,
  Werte plausibel, keine Fehlerschleifen (kein Lua-Fehler öfter als 10-mal je Sitzung).
- Plausibilität: die Anzahl fertiger Quests im Questlog stimmt mit der Anzahl „Abgeben“-Schritte in der Liste
  überein; auch Questanzahl, Stufe und Kartenposition werden geprüft. T224–T227 laufen nur im echten Client.

## 3.12.14
- Behoben: Lua-Fehler „attempt to perform boolean test on a secret boolean value“ (Session.lua, in WoW Forever
  hundertfach). UnitIsAFK liefert dort zeitweise einen geschützten Wert; dann zählt nur noch der eigene Leerlauf.
- Alle übrigen Abfragen mit Wahrheits- oder Zahlenwert (Flug, tot/Geist, Kampf, Fahrzeug, Ziel vorhanden,
  Spielerposition, EP und Erholt-Bonus) werden vor der Benutzung auf geschützte Werte geprüft.
- Testroutine: neuer Fall T223 (geschützte Wahrheitswerte aus UnitIsAFK & Co.).

## 3.12.13
Ausnahme während der Pause (Entscheid des Nutzers): erst die Zone fertig machen.
- Hast du in der Zone, in der du stehst (mit ihrer Hauptstadt), noch offene Quests, bleibt die Planung dort. Erst
  danach geht es gesammelt in die nächste Zone. Abgaben in einer anderen Zone sind kein Grund mehr, die Zone zu
  verlassen. Ausgenommen sind Quests, die für dein Level zu gefährlich oder nicht erreichbar sind.
- Testroutine: neuer Fall T222 (offene Quests in Mulgore vor Abgaben im Brachland).

## 3.12.12
Genaue Wege, Schritt 4 (Ausnahme während der Pause, Entscheid des Nutzers): Wegdaten zum Einsenden.
- Neuer Befehl /lp wege (oder /lp wege <Zone>): zeigt die gelernten Wege je Zone als Koordinatenfolgen (Herkunft
  selbst/geteilt, wie oft gelaufen), gesperrte Wegstücke, korrigierte Orte von Questgebern und FEST-Ereignisse der
  letzten 7 Tage als markierbaren Text – ohne Spieler-, Charakter- oder Gildennamen.
- Automatisch: Beim Ausloggen und /reload legt LevelPilot neue und geänderte Wegdaten (Kennung GSWEGE1, höchstens
  200 KB) in seinen gespeicherten Daten bereit; der RaidMaster-Uploader kann sie wie die Testberichte mitnehmen.
  Abschaltbar in der Zentrale unter Austausch („Wegdaten automatisch senden“, ab Werk an).
- Testroutine: neuer Fall T221 (Text, GSWEGE1, nur Neues, abschaltbar, keine Namen).

## 3.12.11
Genaue Wege, Schritt 3 (Ausnahme während der Pause, Entscheid des Nutzers): echte Orte der Questgeber.
- Sprichst du einen Questgeber an (Quest annehmen, abgeben, Gespräch), merkt sich LevelPilot seinen echten Ort und
  nimmt ihn künftig statt der Koordinaten aus dem Datenpaket – falsche Ziele in veränderten Forever-Zonen werden so
  korrigiert. Die Orte sind wie alle gesammelten Daten im Charakter gesichert.
- Wege lernen (jede gelaufene Strecke), Wege und Höhlen mit Gruppe und Gilde teilen und Flüge bei langen Strecken
  waren schon vorhanden und bleiben unverändert.
- Testroutine: neuer Fall T220 (echter Ort eines Questgebers, geschützte Werte).

## 3.12.10
Genaue Wege, Schritt 2 (Ausnahme während der Pause, Entscheid des Nutzers): aus Sackgassen lernen.
- „FEST“ zählt nur noch reine Laufzeit: Die Uhr läuft nur, solange du dich wirklich bewegst. Stehen hält sie an
  (setzt nichts in Gang); AFK, tot/Geist, Kampf, Flug, offene Händler-, Post-, Auktions-, Berufs- und Lehrerfenster,
  Ladebildschirm und /reload zählen nie. Erst nach 4 Minuten Laufen ohne Annäherung ans Ziel gilt ein Weg als FEST.
- Bei FEST merkt sich LevelPilot das Wegstück als gesperrt und sucht einen anderen Weg; ist keiner bekannt, zeigt nur
  noch der Pfeil die Richtung.
- Testroutine: neuer Fall T219 (10 min AFK, 2 min stehen und 1 min laufen, 4 min im Kreis, gesperrte Kante).

## 3.12.9
Genaue Wege, Schritt 1 (Ausnahme während der Pause, Entscheid des Nutzers): Wegnetz statt Luftlinie.
- Die Route wird nur noch über bekannte Wege gezeichnet: gelaufene oder geteilte Wegstücke, Zonenübergänge und
  Höhlen. Als Luftlinie gilt nur das erste und das letzte kurze Stück (bis 40 Yards).
- Ist kein Weg bekannt, zeichnet LevelPilot keine Linie mehr – der Pfeil zeigt die Richtung zum Ziel mit dem Hinweis
  „Weg unbekannt“. Lieber keine Linie als eine falsche (nie mehr übers Gebirge).
- Das Wegnetz wächst aus gelaufenen Wegen; eigene Koordinatenlisten für Mulgore, Brachland und Thunder Bluff
  folgen, sobald genug aufgezeichnet ist.
- Testroutine: neuer Fall T218 (Mulgore Fall 1 und 2, Ziel ohne Netz, Thunder Bluff mit Aufzug).

## 3.12.8
Ausnahme während der Pause (Entscheid des Nutzers): Route in Thunder Bluff und Mulgore.
- Hauptstädte gehören für die Planung zu ihrer Zone (Thunder Bluff – Mulgore, Orgrimmar – Durotar, Undercity –
  Tirisfal, Stormwind – Elwynn, Ironforge – Dun Morogh, Darnassus – Teldrassil). In WoW Forever haben die Städte
  keine Elternzone; bisher lag der Fokus darum oft in der falschen Karte. Die Reihenfolge der Aufgaben beider Karten
  richtet sich nach dem Weg.
- Der Fokus folgt dem Spieler: liegt die alte Fokus-Zone weit hinter dir, wechselt er in die Zone, in der du stehst.
- Der Fokus-Wächter im Fehler-Protokoll plant selbst neu, statt die Meldung immer wieder zu schreiben; gemeldet wird
  nur noch einmal, wenn das nicht hilft.
- Vorrang-Ziele (Trainer, Beruf, Händler …) stehen nie mehr vor abgabebereiten Quests in der Nähe. Kommt man einem
  Vorrang-Ziel minutenlang nicht näher (z. B. Trainer oben in Thunder Bluff), zeigt LevelPilot nur noch den Pfeil.
- Testroutine: neuer Fall T217 (Thunder Bluff und Mulgore, Fokus-Wächter, Vorrang-Ziel nach nahen Abgaben).

## 3.12.7
Ausnahme während der Pause (Entscheid des Nutzers): Route in Mulgore und Lua-Fehler im Fehler-Protokoll.
- Abgabebereite Quests in der Nähe (bis 900 Yards) kommen jetzt immer zuerst – vor Flugmeister, Binden, Ruhestein
  und weiten Zielen; die nächste zuerst. Eine Abgabe ganz in der Nähe wird auch dann geplant, wenn die Gefahrenkarte
  den Ort als zu gefährlich einstuft (du stehst schon dort).
- Aufgezeichnete Orte (eigene, Startdatenbank, von anderen Spielern) gelten nur noch vor dem Datenpaket, wenn sie dazu
  passen; liegen sie weit daneben, nimmt LevelPilot die Orte aus dem Datenpaket. Aufgezeichnete Händler und Gastwirte
  ohne begehbaren Boden in der Umgebung (z. B. mitten im Gebirge) werden nicht mehr angeboten.
- Führt ein Wegstück als Luftlinie über überwiegend unbekanntes Gelände (Gebirge, Felsen), zeichnet LevelPilot keine
  Linie mehr; der Pfeil zeigt dann direkt die Richtung zum Ziel.
- Fehler-Protokoll: kein Lua-Fehler mehr durch geschützte Werte (Bewegung/Tempo) in WoW Forever („attempt to compare
  a secret number value“).
- Testroutine: neue Fälle T214 (Abgaben in der Nähe zuerst, Mulgore Fall 1 und 2), T215 (kein Ziel und keine Linie
  im Gebirge) und T216 (Protokoll mit geschützten Werten).

## 3.12.6
Offene Punkte der Prüfung vom 3. November 2026 (Nachprüfung 3.12.5).
- Dropraten auf WoW Forever genauer: Der Kill zählt jetzt schon bei der Monster-EP-Meldung (totes Ziel), auch wenn
  die Leiche keine Beute hat – die Rate fällt dadurch nicht mehr zu hoch aus. Stückzahlen zählen erst, wenn der
  Gegenstand wirklich in der Tasche ankommt (Beute-Meldung); bleibt etwas bei voller Tasche liegen, zählt es erst
  beim späteren Aufheben. Jede Leiche zählt nur einmal, geschützte Werte werden nie benutzt.
- Berufs- und Klassenhinweise: Antwortet die erste Zauber-Abfrage mit „nicht bekannt“, fragt LevelPilot auch die
  übrigen (IsPlayerSpell) – kein falscher Hinweis zu Erste Hilfe/Kochen mehr.
- Belohnungs-Hinweis: Ist die Gegenstandsinfo beim Öffnen der Belohnung noch nicht geladen, prüft LevelPilot nach
  einer Sekunde noch einmal.
- Beschädigte gespeicherte Einträge (falscher Typ) werden beim Laden übersprungen oder ersetzt statt Lua-Fehler zu
  verursachen; gültige gesammelte Daten bleiben unverändert.
- Geschützte Werte: EP-Anzeige, Zeit bis 60, Gruppenstand und Erholt-Hinweis rechnen nie mit geschützten EP;
  Tooltips, Messung und Gegner-Zeilen prüfen geschützte Einheiten.
- Fehler, die bisher still abgefangen wurden (virtuelle Reise, Sicherung beim Ausloggen, Protokoll-Prüfungen), werden
  jetzt an die GoldSentinel-Prüfung gemeldet. Die Diagnose zeigt Modul-Startfehler.
- Planungszeit der virtuellen Reise zählt nur noch die Rechenzeit (Pausen zwischen den Bildern nicht mehr).
- Testroutine (Testmodus): alle Testfälle automatisiert (vorher 96 Platzhalter), Zählung „nicht automatisiert“ im
  Bericht, neue Client-Fälle T171, T195 und T213 (Berufszauber), lange Reisen mit /lp testroutine reise.
  Im Kopierfenster der Hinweis „Wird auch automatisch gemeldet.“ (alle Sprachen).

## 3.12.5
Grundeinstellung nach Entscheid des Nutzers, offene Punkte der Prüfung vom 3. November 2026 und neue Testroutine.
- Grundeinstellung: Automatisch reparieren und Auto-Flug sind ab Werk wieder an; Vorräte nachkaufen und
  Questbelohnung anlegen bleiben aus. Bestehende Einstellungen ändern sich nicht – wer 3.12.4 neu installiert hat,
  schaltet Reparieren und Auto-Flug in der Zentrale ein (Komfort).
- Neue einmalige Hinweise: beim ersten Händler, bei dem LevelPilot nachkaufen würde (Nachkaufen aus), und bei der
  ersten Questbelohnung, die ein Upgrade ist (Anlegen aus), zeigt LevelPilot einmal, dass es die Option gibt – mit
  „Einstellungen“ und „Später erinnern“ (frühestens 3 Level später). Es wird nichts gekauft, gewählt oder angelegt;
  nie im Kampf, nie mehr, sobald die Option an ist. Auch die Begrüssung „Wo war ich?“ zeigt einmal einen Tipp.
- Dropraten auf WoW Forever: Wird dieselbe Leiche erneut geöffnet (Tasche voll, Fenster geschlossen), zählen Kill und
  Stückzahl nicht doppelt; ein Beutefenster mit geschütztem Link wird ausgelassen statt einen Kill ohne Beute zu
  zählen; Taschendiebstahl (Ziel lebt noch) zählt nicht als Kill.
- Klassenhinweise: Antwortet keine Zauber-Funktion, behauptet LevelPilot nicht mehr, Erste Hilfe/Kochen fehle.
- Erkennung: Meldet GoldSentinelGame „nicht modern“, folgt LevelPilot dem (eigene Erkennung nur ohne GoldSentinelGame).
- Alle Zeitgeber laufen geschützt über LP:Ticker (Neuplanung, Assistent, Partnersuche, Datenaustausch, Reise).
- Fehlende Übersetzung des Protokolleintrags „Datenpaket veraltet“ ergänzt (alle Sprachen).
- Robustheit: Fehlende Spielfunktionen (Reparaturkosten, Haltbarkeit, Munition, Questgeber-Begrüssung,
  Gegenstandsinfo) führen nicht mehr zu Lua-Fehlern.
- Aktionen mit echten Folgen (Kaufen, Verkaufen, Reparieren, Anlegen, Quests, Flug, Senden, Einladen, Neuladen)
  laufen über eine Stelle (LP.Act); im normalen Spiel ändert sich nichts.
- Neue Testroutine für den Entwickler (Testmodus): /lp testroutine [a–j] und Knopf „Alles testen“; Sandbox für
  deine Daten, Aktionen werden nur mitgeschrieben. /lp test (für alle) schreibt jetzt einen maschinenlesbaren
  Bericht. Berichte und Lua-Fehler werden für die GoldSentinel-Prüfung gespeichert (GoldSentinelTest.lua, ohne Namen).
