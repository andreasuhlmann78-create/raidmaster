-- ============================================================
-- Donate.lua – Spenden-Knopf (PayPal) von GoldSentinel
-- Funktioniert in jeder WoW-Version (Retail, Classic, Anniversary, Era, WoW Forever),
-- ohne fremde Bibliotheken. WoW kann keine Webseiten öffnen: das Fenster zeigt den
-- Link markiert zum Kopieren (Strg+C), dann im Browser einfügen.
-- Nicht aufdringlich: öffnet sich nur auf Klick oder per Befehl (/lp spenden), nie von selbst.
--
-- In LevelPilot: Design von LP.UI, Texte über LP.L (alle Sprachen in den Locale-Dateien).
--   LP.Donate.Show()                              Fenster öffnen
--   LP.Donate.CreateButton(parent, breite, höhe)  Knopf „Unterstützen“ (öffnet das Fenster)
-- ============================================================

local ADDON_NAME, LP = ...
local L = LP.L
local D = {}
LP.Donate = D

D.URL = "https://www.paypal.com/ncp/payment/46R68N2BF7BTY"
D.SIGN = "- GoldSentinel"
D.ICON = nil                         -- nil = Goldmünzen-Icon von Blizzard

local BACKDROP_TEMPLATE = BackdropTemplateMixin and "BackdropTemplate" or nil

-- Name des Addons aus der .toc (ohne Farbcodes)
local function AddonTitle()
    local get = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
    local t = get and get(ADDON_NAME, "Title") or ADDON_NAME
    return (tostring(t or ADDON_NAME):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
end
D.AddonTitle = AddonTitle

-- die vier Texte (Übersetzungen in den Locale-Dateien)
local function T(key)
    if key == "title" then return L["%s unterstützen"] end
    if key == "button" then return L["Unterstützen"] end
    if key == "thanks" then return L["Danke, dass du %s unterstützt! Jede Spende hilft mir, mehr Zeit in neue Funktionen und schnelle Fehlerbehebungen zu stecken."] end
    if key == "hint" then return L["Strg+C kopiert den PayPal-Link - dann im Browser einfügen."] end
    return key
end
D.Text = T

local frame

local function Build()
    local UI, C = LP.UI, LP.colors
    local f = CreateFrame("Frame", ADDON_NAME .. "DonateFrame", UIParent, BACKDROP_TEMPLATE)
    f:SetSize(470, 210)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:SetToplevel(true)
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    UI:Skin(f, C.panel, C.border)
    local name = f.GetName and f:GetName()
    if UISpecialFrames and name then table.insert(UISpecialFrames, name) end     -- Esc schließt

    local brand = UI:Text(f, 10, C.muted)
    brand:SetPoint("TOPLEFT", 14, -10)
    brand:SetText("|cffffb238LEVEL|r|cff3dd694PILOT|r")

    f.title = UI:Text(f, 14, C.text)
    f.title:SetPoint("TOPLEFT", 14, -24)
    f.title:SetWidth(400)

    local close = UI:Button(f, "x", 20, 20, function() f:Hide() end, L["Schliessen"])
    close:SetPoint("TOPRIGHT", -6, -6)

    local icon = f:CreateTexture(nil, "ARTWORK")
    icon:SetSize(36, 36)
    icon:SetPoint("TOPLEFT", 16, -54)
    f.icon = icon

    f.text = UI:Text(f, 12, C.text)
    f.text:SetPoint("TOPLEFT", icon, "TOPRIGHT", 12, 0)
    f.text:SetWidth(394)
    f.text:SetJustifyH("LEFT")
    if f.text.SetWordWrap then f.text:SetWordWrap(true) end

    local box = CreateFrame("Frame", nil, f, BACKDROP_TEMPLATE)
    box:SetSize(438, 26)
    box:SetPoint("TOPLEFT", 16, -122)
    UI:Skin(box, C.row, C.accent)
    local eb = CreateFrame("EditBox", nil, box)
    eb:SetPoint("TOPLEFT", 8, -3)
    eb:SetPoint("BOTTOMRIGHT", -8, 3)
    eb:SetAutoFocus(false)
    eb:SetFontObject(ChatFontNormal or GameFontHighlight)
    -- nur zum Kopieren: Änderungen sofort zurücknehmen
    eb:SetScript("OnTextChanged", function(self, user)
        if user and self:GetText() ~= D.URL then self:SetText(D.URL) self:HighlightText() end
    end)
    eb:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    eb:SetScript("OnEscapePressed", function() f:Hide() end)
    eb:SetScript("OnEnterPressed", function() f:Hide() end)
    f.edit = eb

    f.hint = UI:Text(f, 10, C.muted)
    f.hint:SetPoint("TOPLEFT", box, "BOTTOMLEFT", 2, -8)
    f.hint:SetWidth(438)

    f.sign = UI:Text(f, 11, C.accent)
    f.sign:SetPoint("BOTTOMRIGHT", -16, 14)
    f.sign:SetText(D.SIGN)
    f:Hide()
    return f
end

function D.Show()
    frame = frame or Build()
    local title = AddonTitle()
    frame.title:SetText(string.format(T("title"), title))
    frame.text:SetText(string.format(T("thanks"), title))
    frame.hint:SetText(T("hint"))
    frame.icon:SetTexture(D.ICON or "Interface\\Icons\\INV_Misc_Coin_01")
    frame:Show()
    frame.edit:SetText(D.URL)
    frame.edit:SetFocus()
    frame.edit:HighlightText()
    return frame
end

function D.Toggle()
    if frame and frame:IsShown() then frame:Hide() else D.Show() end
end

function D.Frame() return frame end

-- Knopf „Unterstützen“ für Titelleiste, Optionen o. Ä. (im Design von LevelPilot)
function D.CreateButton(parent, width, height)
    local b = LP.UI:Button(parent, T("button"), width or 100, height or 22, function() D.Show() end,
        string.format(T("title"), AddonTitle()) .. "\nPayPal")
    -- lange Wörter (andere Sprachen): Knopf passt sich der Beschriftung an
    if b.label and b.label.GetStringWidth then
        local need = (b.label:GetStringWidth() or 0) + 16
        if need > b:GetWidth() then b:SetWidth(need) end
    end
    return b
end
