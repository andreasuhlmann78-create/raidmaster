local _, ns = ...
local L = ns.L

-- Disenchant value of a crafted item (for "Gold verdienen" and "Herstellen & Entzaubern").
--
-- Source: AHSentinel (GoldSentinel). It learns from every disenchant and shares the results with
-- every player who has AHSentinel, so its drop chances follow the real ones on the server.
-- Without AHSentinel: the classic table with the starting values (green armour 75 % dust, 20 % essence,
-- 5 % shard; weapons the other way round) and AH prices from TSM/Auctionator – no learning.
--
-- DE.Value(itemID) -> gross (copper, before the 5 % AH cut), complete, yield, own, shared, source
--   yield = { { materialID, chance 0-1, average count }, ... }

local DE = {}
ns.Disenchant = DE

---------------------------------------------------------------------------
-- Enchanters only: what do you want to do with enchanting? (asked once per character)
--   "gold" – make gold by disenchanting (bargains, craft & disenchant, drop chances)
--   "sell" – sell enchants to other players (material cost per enchant)
--   "both"
-- Disenchant values only count for characters with enchanting who chose "gold" or "both".
---------------------------------------------------------------------------
DE.ENCHANTING = 333

function DE.IsEnchanter()
    if ns.Sim and ns.Sim.enchanter ~= nil then return ns.Sim.enchanter end
    local c = ns.Char and ns.Char()
    return c and c.profs and c.profs[DE.ENCHANTING] ~= nil or false
end

function DE.Goal()
    if ns.Sim and ns.Sim.goal then return ns.Sim.goal end
    local c = ns.Char and ns.Char()
    return c and c.enchantGoal or nil
end

-- not answered yet: show everything until the player decides
function DE.WantsGold()
    if not DE.IsEnchanter() then return false end
    local g = DE.Goal()
    return g == nil or g == "gold" or g == "both"
end

function DE.WantsSell()
    if not DE.IsEnchanter() then return false end
    local g = DE.Goal()
    return g == nil or g == "sell" or g == "both"
end

function DE.SetGoal(goal)
    local c = ns.Char and ns.Char()
    if c then c.enchantGoal = goal end
    if ns.Sim then ns.Sim.goal = nil end
    ns.Print(string.format(L.GOAL_SET, L["GOAL_" .. goal:upper()]))
    if ns.RefreshAll then ns.RefreshAll() end
end

-- small question window with three buttons
local ask
function DE.AskGoal()
    if not ask then
        ask = CreateFrame("Frame", "ProfessionSentinelGoalFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
        ask:SetSize(400, 150)
        ask:SetPoint("CENTER", 0, 140)
        ask:SetFrameStrata("DIALOG")
        if ask.SetBackdrop then
            ask:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
                edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32,
                insets = { left = 11, right = 12, top = 12, bottom = 11 } })
        end
        ask.text = ask:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        ask.text:SetPoint("TOP", 0, -22)
        ask.text:SetWidth(360)
        ask.text:SetText(L.GOAL_QUESTION)
        local function btn(goal, x)
            local b = CreateFrame("Button", nil, ask, "UIPanelButtonTemplate")
            b:SetSize(116, 24)
            b:SetPoint("BOTTOM", x, 20)
            b:SetText(L["GOAL_" .. goal:upper()])
            b:SetScript("OnClick", function() ask:Hide(); DE.SetGoal(goal) end)
            b:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
                GameTooltip:AddLine(L["GOAL_" .. goal:upper() .. "_TIP"], 1, 1, 1, true)
                GameTooltip:Show()
            end)
            b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        end
        btn("gold", -122)
        btn("sell", 0)
        btn("both", 122)
        local close = CreateFrame("Button", nil, ask, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", -4, -4)
        ask:Hide()
    end
    ask:Show()
end

---------------------------------------------------------------------------
-- Selling enchants: price = material cost + your surcharge (at least your minimum profit),
-- rounded up to a full silver (under 1 gold) or to 10 silver
---------------------------------------------------------------------------
function DE.SellPrice(cost)
    if not cost or cost <= 0 then return nil end
    local markup = (ns.db and ns.db.vzMarkup) or 20
    local minProfit = (ns.db and ns.db.vzMinProfit) or 0
    local price = math.max(cost * (1 + markup / 100), cost + minProfit)
    local step = price < 10000 and 100 or 1000
    return math.ceil(price / step - 1e-9) * step
end

local function ParseMoney(text)
    text = (text or ""):lower():gsub(",", ".")
    local g = tonumber(text:match("([%d%.]+)%s*g")) or 0
    local s = tonumber(text:match("([%d%.]+)%s*s")) or 0
    local c = tonumber(text:match("([%d%.]+)%s*c")) or 0
    if g == 0 and s == 0 and c == 0 then
        local n = tonumber(text:match("^%s*([%d%.]+)%s*$"))
        if n then g = n end          -- a plain number means gold
    end
    return math.floor(g * 10000 + s * 100 + c + 0.5)
end
DE.ParseMoney = ParseMoney

local function EditPopup(key, title, current, apply)
    if not StaticPopupDialogs then return end
    StaticPopupDialogs[key] = {
        text = title, button1 = OKAY or "OK", button2 = CANCEL or "Cancel",
        hasEditBox = true, timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
        OnShow = function(self)
            local eb = self.editBox or self.EditBox
            if eb then eb:SetText(current()); eb:HighlightText() end
        end,
        OnAccept = function(self)
            local eb = self.editBox or self.EditBox
            if eb then apply(eb:GetText()) end
            if ns.RefreshAll then ns.RefreshAll() end
        end,
        EditBoxOnEnterPressed = function(self)
            local parent = self:GetParent()
            apply(self:GetText())
            parent:Hide()
            if ns.RefreshAll then ns.RefreshAll() end
        end,
    }
    StaticPopup_Show(key)
end

function DE.EditMarkup()
    EditPopup("PROFESSIONSENTINEL_VZ_MARKUP", L.VZ_MARKUP_ASK,
        function() return tostring(ns.db.vzMarkup or 20) end,
        function(t)
            local n = tonumber(((t or ""):gsub(",", "."):gsub("%%", "")))
            if n and n >= 0 and n <= 1000 then ns.db.vzMarkup = n end
        end)
end

function DE.EditMinProfit()
    EditPopup("PROFESSIONSENTINEL_VZ_MIN", L.VZ_MIN_ASK,
        function() return ns.Prices.MoneyPlain(ns.db.vzMinProfit or 0) end,
        function(t) ns.db.vzMinProfit = math.max(0, ParseMoney(t)) end)
end

-- ask once per session if the character has enchanting and has not decided yet
local asked = false
function DE.CheckAsk()
    if asked or not DE.IsEnchanter() or DE.Goal() ~= nil or (ns.Sim and ns.Sim.enchanter ~= nil) then return end
    asked = true
    if C_Timer then C_Timer.After(3, DE.AskGoal) else DE.AskGoal() end
end

-- Materials
local STRANGE, SOUL, VISION, DREAM, ILLUSION = 10940, 11083, 11137, 11176, 16204
local LMAGIC, GMAGIC, LASTRAL, GASTRAL = 10938, 10939, 10998, 11082
local LMYSTIC, GMYSTIC, LNETHER, GNETHER, LETERNAL, GETERNAL = 11134, 11135, 11174, 11175, 16202, 16203
local SGLIMMER, LGLIMMER, SGLOW, LGLOW = 10978, 11084, 11138, 11139
local SRADIANT, LRADIANT, SBRILLIANT, LBRILLIANT, NEXUS = 11177, 11178, 14343, 14344, 20725

-- Green: { up to item level, dust, avg dust, essence, avg essence, shard }
local UNCOMMON = {
    { 15, STRANGE, 1.5, LMAGIC, 1.5, SGLIMMER },
    { 20, STRANGE, 2.5, GMAGIC, 1.5, SGLIMMER },
    { 25, STRANGE, 5.0, LASTRAL, 1.5, SGLIMMER },
    { 30, SOUL, 1.5, GASTRAL, 1.5, LGLIMMER },
    { 35, SOUL, 3.5, LMYSTIC, 1.5, SGLOW },
    { 40, VISION, 1.5, GMYSTIC, 1.5, LGLOW },
    { 45, VISION, 3.5, LNETHER, 1.5, SRADIANT },
    { 50, DREAM, 1.5, GNETHER, 1.5, LRADIANT },
    { 55, DREAM, 3.5, LETERNAL, 1.5, SBRILLIANT },
    { 60, ILLUSION, 1.5, GETERNAL, 1.5, LBRILLIANT },
    { 65, ILLUSION, 3.5, GETERNAL, 2.5, LBRILLIANT },
}
-- Blue: { up to item level, shard }
local RARE = {
    { 25, SGLIMMER }, { 30, LGLIMMER }, { 35, SGLOW }, { 40, LGLOW },
    { 45, SRADIANT }, { 50, LRADIANT }, { 55, SBRILLIANT }, { 65, LBRILLIANT },
}
-- Epic: { from, to item level, material, avg count }
local EPIC = {
    { 40, 45, SRADIANT, 3 }, { 46, 50, LRADIANT, 3 }, { 51, 55, SBRILLIANT, 3 },
    { 56, 60, NEXUS, 1 }, { 61, 94, NEXUS, 1.5 },
}

DE.GREEN_DUST, DE.GREEN_ESSENCE, DE.GREEN_SHARD = 0.75, 0.20, 0.05

local NOT_DE = { INVTYPE_BODY = true, INVTYPE_TABARD = true, INVTYPE_BAG = true, INVTYPE_AMMO = true, INVTYPE_QUIVER = true, [""] = true }

-- AHSentinel available?
function DE.AHS()
    local A = _G.AHAnalyzerPro
    return A and A.Disenchant and A.Disenchant.GetValue and A.Disenchant or nil
end

---------------------------------------------------------------------------
-- Item info (crafted items are often not cached yet: request them, refresh once they arrive)
---------------------------------------------------------------------------
local requested = {}
local refreshTimer
local loader = CreateFrame("Frame")
pcall(loader.RegisterEvent, loader, "GET_ITEM_INFO_RECEIVED")
loader:SetScript("OnEvent", function(_, _, itemID)
    if not requested[itemID] or refreshTimer or not C_Timer then return end
    refreshTimer = true
    C_Timer.After(1, function()
        refreshTimer = nil
        if ns.RefreshAll then ns.RefreshAll() end
    end)
end)

local function ItemInfo(itemID)
    if not GetItemInfo then return nil end
    local info = { pcall(GetItemInfo, itemID) }
    if not info[1] or not info[2] then
        if not requested[itemID] then
            requested[itemID] = true
            if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, itemID) end
        end
        return nil
    end
    -- quality, item level, equip location, class
    return info[4], info[5], info[10], info[13]
end

-- Starting values (fallback without AHSentinel)
function DE.Prior(itemID)
    local quality, ilvl, equipLoc, classID = ItemInfo(itemID)
    if not quality or quality < 2 or quality > 4 or not ilvl then return nil end
    if classID ~= 2 and classID ~= 4 then return nil end
    if NOT_DE[equipLoc or ""] then return nil end
    local weapon = (classID == 2)
    if quality == 2 then
        if ilvl < 5 then return nil end
        for _, b in ipairs(UNCOMMON) do
            if ilvl <= b[1] then
                local pDust, pEss = DE.GREEN_DUST, DE.GREEN_ESSENCE
                if weapon then pDust, pEss = DE.GREEN_ESSENCE, DE.GREEN_DUST end
                return { { b[2], pDust, b[3] }, { b[4], pEss, b[5] }, { b[6], DE.GREEN_SHARD, 1 } }
            end
        end
    elseif quality == 3 then
        if ilvl < 11 then return nil end
        for _, b in ipairs(RARE) do
            if ilvl <= b[1] then
                if b[2] == LBRILLIANT and ilvl >= 56 then return { { LBRILLIANT, 0.995, 1 }, { NEXUS, 0.005, 1 } } end
                return { { b[2], 1, 1 } }
            end
        end
    else
        for _, b in ipairs(EPIC) do
            if ilvl >= b[1] and ilvl <= b[2] then return { { b[3], 1, b[4] } } end
        end
    end
    return nil
end

---------------------------------------------------------------------------
-- Expected value (gross, before the 5 % cut)
---------------------------------------------------------------------------
function DE.Value(itemID)
    if not itemID or not DE.WantsGold() then return nil end
    -- test mode: fixed values
    if ns.Sim and ns.Sim.de and ns.Sim.de[itemID] ~= nil then
        local v = ns.Sim.de[itemID]
        if v == false then return nil end
        return v, true, nil, 0, 0, "Test"
    end
    local D = DE.AHS()
    if D then
        local ok, v, complete, yield, own, shared = pcall(D.GetValue, D, itemID)
        if ok and v then return v, complete, yield, own or 0, shared or 0, "AHSentinel" end
        if ok then return nil end
    end
    local yield = DE.Prior(itemID)
    if not yield then return nil end
    local value, complete, any = 0, true, false
    for _, e in ipairs(yield) do
        local p = ns.Prices.AH(e[1])
        if p then value = value + e[2] * e[3] * p; any = true
        elseif e[2] >= 0.05 then complete = false end
    end
    if not any then return nil end
    return math.floor(value + 0.5), complete, yield, 0, 0, "table"
end

-- Can the item be disenchanted at all (independent of prices)?
function DE.IsDisenchantable(itemID)
    if ns.Sim and ns.Sim.de and ns.Sim.de[itemID] ~= nil then return ns.Sim.de[itemID] ~= false end
    local D = DE.AHS()
    if D and D.Prior then
        local ok, prior = pcall(D.Prior, D, itemID)
        return ok and prior ~= nil
    end
    return DE.Prior(itemID) ~= nil
end

---------------------------------------------------------------------------
-- Statistics for the "Entzaubern" tab (only with AHSentinel)
---------------------------------------------------------------------------
-- { { key, label, own, shared, rows = { { id, chance, prior, avg } } } }
function DE.Groups()
    local D = DE.AHS()
    if not (D and D.Groups and D.YieldForKey) then return nil end
    local ok, groups = pcall(D.Groups, D)
    if not ok or not groups then return {} end
    local out = {}
    for _, g in ipairs(groups) do
        local y, prior = D:YieldForKey(g.key)
        if y then
            local q, from, to, weapon = D:KeyInfo(g.key)
            local priorBy = {}
            for _, e in ipairs(prior or {}) do priorBy[e[1]] = e[2] end
            local rows = {}
            for _, e in ipairs(y) do rows[#rows + 1] = { id = e[1], chance = e[2], avg = e[3], prior = priorBy[e[1]] or 0 } end
            table.sort(rows, function(a, b) return a.chance > b.chance end)
            out[#out + 1] = { key = g.key, quality = q, from = from, to = to, weapon = weapon,
                              own = g.own or 0, shared = g.shared or 0, rows = rows }
        end
    end
    return out
end

function DE.Totals()
    local D = DE.AHS()
    if not D then return nil end
    local own = D.TotalLearned and select(1, D:TotalLearned()) or 0
    local shared, players = 0, 0
    if D.TotalShared then shared, players = D:TotalShared() end
    return own, shared, players
end

-- AH bargains from AHSentinel: items currently cheaper than their disenchant value after the cut
function DE.Deals(max)
    local D = DE.AHS()
    if not (D and D.FindDeals) then return nil end
    local ok, list = pcall(D.FindDeals, D)
    if not ok or type(list) ~= "table" then return {} end
    table.sort(list, function(a, b) return (a.profit or 0) > (b.profit or 0) end)
    if max and #list > max then
        for i = #list, max + 1, -1 do list[i] = nil end
    end
    return list
end
