-- ThreatSentinel - Meter.lua
-- Aggrometer: Bedrohungsliste deines Ziels.
-- Jeder Wert zeigt, wie nah ein Spieler am Ziehen der Aggro ist: 100 % = er zieht jetzt.
-- Die Classic-Regel ist eingerechnet (Nahkampf zieht bei 110 %, Fernkampf bei 130 % der Tank-Bedrohung).
-- Als Tank siehst du deinen Vorsprung auf den Spieler, der am nächsten dran ist.

local ADDON, ns = ...
local API = ns.API   -- Blizzard-Funktionen nur über ns.API (API.lua)
local L = ns.L

local M = {}
ns.Meter = M
table.insert(ns.modules, M)

local WHITE = "Interface\\Buttons\\WHITE8X8"
local BAR_TEX = "Interface\\TargetingFrame\\UI-StatusBar"
local ROW_H = 16
local SCALE_MAX = 110   -- 100 % (= zieht) sitzt kurz vor dem Balkenende

-- Klassen, die meist im Nahkampf stehen (nur für den Ersatz, falls das Spiel keinen Anteil liefert)
local MELEE = { WARRIOR = true, ROGUE = true, PALADIN = true, DRUID = true, SHAMAN = false }

function M:Init()
	local f = CreateFrame("Frame", "ThreatSentinelMeter", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	if ns.RegisterUI then ns.RegisterUI(f, "Aggrometer", "hud") end   -- Oberflächen-Prüfung (UICheck.lua)
	f:SetSize(ns.db.meterWidth or 230, 26)
	f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	f:SetBackdropColor(0.03, 0.04, 0.06, 0.6)
	f:SetBackdropBorderColor(0.25, 0.65, 1, 0.5)
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", function(self) self:StartMoving() end)
	f:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		ns.Mover:SavePoint(self, "meterPoint")
	end)

	f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	f.title:SetPoint("TOPLEFT", 6, -5)
	f.title:SetPoint("TOPRIGHT", -96, -5)
	f.title:SetJustifyH("LEFT")
	if f.title.SetWordWrap then f.title:SetWordWrap(false) end
	f.lead = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	f.lead:SetPoint("TOPRIGHT", -6, -5)
	f.lead:SetWidth(88)
	f.lead:SetJustifyH("RIGHT")
	if f.lead.SetWordWrap then f.lead:SetWordWrap(false) end
	-- Modus ANZEIGE: kleine zweite Kopfzeile "Reihenfolge: sicher / ~ geschätzt"
	f.order = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	f.order:SetPoint("TOPLEFT", 6, -18)
	f.order:SetPoint("TOPRIGHT", -6, -18)
	f.order:SetJustifyH("LEFT")
	if f.order.SetWordWrap then f.order:SetWordWrap(false) end
	f.order:SetText("")

	f.rows = {}
	f:Hide()
	self.f = f
	ns.Mover:Attach(f, "meter")
	self:ApplySettings()
end

function M:ApplySettings()
	local f, db = self.f, ns.db
	if not f then return end
	local p = db.meterPoint
	f:ClearAllPoints()
	f:SetPoint(p[1], UIParent, p[3], p[4], p[5])
	f:SetWidth(self:Width())
	for _, r in ipairs(f.rows) do self:LayoutRow(r) end
	f:SetScale(db.meterScale or 1)
	f:EnableMouse(ns:Unlocked())
end

function M:Width()
	return math.max(160, math.min(400, ns.db.meterWidth or 230))
end

-- Breite einer Zeile und Lage der 100-%-Markierung (die Breite ist einstellbar)
function M:LayoutRow(r)
	local w = self:Width() - 8
	r:SetSize(w, ROW_H - 2)
	r.mark:ClearAllPoints()
	r.mark:SetPoint("TOP", r, "TOPLEFT", w * 100 / SCALE_MAX, 0)
	r.mark:SetPoint("BOTTOM", r, "BOTTOMLEFT", w * 100 / SCALE_MAX, 0)
end

function M:Row(i)
	local f = self.f
	local r = f.rows[i]
	if r then return r end
	r = CreateFrame("StatusBar", nil, f)
	r:SetPoint("TOPLEFT", 4, -20 - (i - 1) * ROW_H)
	r:SetStatusBarTexture(BAR_TEX)
	r:SetMinMaxValues(0, SCALE_MAX)
	r.bg = r:CreateTexture(nil, "BACKGROUND")
	r.bg:SetAllPoints()
	r.bg:SetTexture(WHITE)
	r.bg:SetVertexColor(1, 1, 1, 0.06)
	-- Markierung bei 100 %: hier zieht der Spieler die Aggro
	r.mark = r:CreateTexture(nil, "OVERLAY")
	r.mark:SetTexture(WHITE)
	r.mark:SetVertexColor(1, 0.3, 0.3, 0.6)
	r.mark:SetWidth(1)
	r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	r.name:SetPoint("LEFT", 4, 0)
	r.name:SetPoint("RIGHT", -44, 0)
	r.name:SetJustifyH("LEFT")
	if r.name.SetWordWrap then r.name:SetWordWrap(false) end
	r.value = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	r.value:SetPoint("RIGHT", -4, 0)
	self:LayoutRow(r)
	f.rows[i] = r
	return r
end

local function ClassColor(class)
	local c = class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
	if c then return c.r, c.g, c.b end
	return 0.6, 0.6, 0.6
end

-- Anteil bis zum Ziehen (100 = zieht). Das Spiel liefert ihn direkt (scaled);
-- sonst Ersatz aus dem Rohwert mit der 110/130-%-Regel.
local function PullPercent(u, scaled, raw, class)
	if scaled then return scaled end
	if not raw then return 0 end
	local melee = (not API.UnitIsPlayer(u)) or MELEE[class or ""]
	return raw / (melee and 110 or 130) * 100
end
M._PullPercent = PullPercent   -- Test-Zugang (Testroutine T83)

------------------------------------------------------------
-- Modus ANZEIGE (WoW Forever, geschützte Werte): Reihenfolge nach Aggro, beste verfügbare Stufe
--   Stufe 1 (sicher): wer die Aggro hat - Ziel des Mobs (targettarget), sonst isTanking, nur wenn nicht geschützt
--   Stufe 2 (sicher, grob): Bedrohungsstufe 3/2/1/0, nur wenn lesbar
--   Stufe 3 (geschätzt, "~"): Schaden x Faktor + Heilung x 0,5 / Gegner aus diesem Kampf (Schadens-/Heilmeter)
--   ohne all das: Tank (Rolle) zuerst, dann die Gruppe (wie bisher)
-- Die Balken zeigen weiter die echten Werte; nur die Reihenfolge ändert sich.
-- Dämpfung: höchstens alle 0,5 s neu sortieren, Schätzungen tauschen erst ab 10 % Unterschied.
------------------------------------------------------------
M.SORT_GAP = 0.5
M.EST_MARGIN = 0.10
M.sortT = 0
M.prevRank = {}      -- Einheit -> Platz bei der letzten Sortierung
M.orderKind = nil    -- "sure", "est", "role"

local function Readable(v) return v ~= nil and not ns.IsSecret(v) end

-- Schaden und Heilung dieses Kampfs (nur mit Kampflog; WoW Forever: keine Quelle -> nil)
function M:Estimates()
	local DMm = ns.DmgMeter
	local s = DMm and DMm.cur
	if not s or (s.ended and GetTime() - (s.last or 0) > 10) then return nil end
	if not next(s.dmg or {}) and not next(s.heal or {}) then return nil end
	return s.dmg or {}, s.heal or {}
end

-- klassische Faustregeln, nur was ThreatSentinel sicher erkennt (sonst x1)
function M:ThreatFactor(u, class)
	if class == "ROGUE" then return 0.71 end
	if class == "WARRIOR" then
		if ns:SameUnit(u, "player") then return ns:IsTankStance() and 1.3 or 1 end
		return ns:GetRole(u) == "TANK" and 1.3 or 1
	end
	if class == "DRUID" and ns:HasBearForm(u) then return 1.3 end
	if class == "PALADIN" then
		local found, readable = ns:FindAura(u, "HELPFUL", { [25780] = true, [20925] = true })
		if readable and found then return 1.6 end   -- Zorn der Gerechtigkeit (grob auf den ganzen Schaden)
	end
	return 1
end

local function EnemyCount()
	local n = 0
	for _, m in pairs(ns.mobs or {}) do
		if m.unit and ns.Safe(API.UnitAffectingCombat(m.unit), false) then n = n + 1 end
	end
	return math.max(1, n)
end

-- eingefügt statt table.sort: die gedämpfte Vergleichsregel muss nicht streng geordnet sein
local function InsertionSort(list, before)
	for i = 2, #list do
		local e, j = list[i], i
		while j > 1 and before(e, list[j - 1]) do
			list[j] = list[j - 1]
			j = j - 1
		end
		list[j] = e
	end
end

-- Liste im Modus ANZEIGE ordnen. Rückgabe: Art der Reihenfolge ("sure", "est", "role") und was lesbar war.
function M:OrderDisplay(list)
	local now = GetTime()
	local seen = { holder = false, status = false, tanking = false, estimate = false, unit = "target" }
	-- P2 (Diagnose): greift der Mob mich selbst an? ja / nein / geschützt (ohne Namen)
	do
		local ok, v = pcall(API.UnitIsUnit, "targettarget", "player")
		if not ok then seen.attacksMe = "?"
		elseif ns.IsSecret(v) then seen.attacksMe = "geschützt"
		else seen.attacksMe = v and "ja" or "nein" end
		local okE, ex = pcall(API.UnitExists, "targettarget")
		if okE and not ns.IsSecret(ex) and not ex then seen.attacksMe = "kein Ziel" end
	end

	-- Stufe 1: Ziel des Mobs
	local ttReadable = false
	local okE, exists = pcall(API.UnitExists, "targettarget")
	if okE and Readable(exists) then
		ttReadable = true
		for _, e in ipairs(list) do
			if exists then
				local ok, same = pcall(API.UnitIsUnit, "targettarget", e.unit)
				if ok and Readable(same) then e.holder = same and true or false else ttReadable = false end
			else
				e.holder = false
			end
		end
	end
	seen.holder = ttReadable
	if not ttReadable then
		-- Ersatz: isTanking, falls lesbar
		local all = #list > 0
		for _, e in ipairs(list) do if not Readable(e.rawTanking) then all = false end end
		seen.tanking = all
		for _, e in ipairs(list) do e.holder = all and (e.rawTanking and true or false) or nil end
	else
		local all = #list > 0
		for _, e in ipairs(list) do if not Readable(e.rawTanking) then all = false end end
		seen.tanking = all
	end

	-- Stufe 2: Bedrohungsstufe
	local statusAll = #list > 0
	for _, e in ipairs(list) do
		local st = Readable(e.rawStatus) and type(e.rawStatus) == "number" and e.rawStatus or nil
		if not st and API.UnitThreatSituation then
			local ok, v = pcall(API.UnitThreatSituation, e.unit, "target")
			if ok and Readable(v) and type(v) == "number" then st = v end
		end
		e.level = st
		if st == nil then statusAll = false end
	end
	seen.status = statusAll

	-- Stufe 3: Schätzung
	local dmg, heal = self:Estimates()
	if dmg then
		seen.estimate = true
		local enemies = EnemyCount()
		for _, e in ipairs(list) do
			local name = e.key
			local d = (name and (dmg[name] or 0)) or 0
			local h = (name and (heal[name] or 0)) or 0
			e.est = d * self:ThreatFactor(e.unit, e.class) + h * 0.5 / enemies
		end
	end

	-- Dämpfung: innerhalb von 0,5 s die letzte Reihenfolge behalten
	local prev = self.prevRank
	local same = now - self.sortT < self.SORT_GAP
	if same then
		for _, e in ipairs(list) do if not prev[e.unit] then same = false break end end
	end
	local usedEst = false
	if same then
		InsertionSort(list, function(a, b) return prev[a.unit] < prev[b.unit] end)
		usedEst = self.orderKind == "est"
		for _, e in ipairs(list) do e.estimated = self.lastEstimated and self.lastEstimated[e.unit] or nil end
	else
		local margin = self.EST_MARGIN
		InsertionSort(list, function(a, b)
			if seen.holder or seen.tanking then
				if (a.holder or false) ~= (b.holder or false) then return a.holder and true or false end
			end
			if a.level and b.level and a.level ~= b.level then return a.level > b.level end
			if a.est and b.est then
				local hi = math.max(a.est, b.est)
				if hi > 0 then
					local close = math.abs(a.est - b.est) <= hi * margin
					local pa, pb = prev[a.unit], prev[b.unit]
					if close and pa and pb then
						if pa ~= pb then usedEst = true; a.estimated, b.estimated = true, true end
						return pa < pb
					end
					if a.est ~= b.est then
						usedEst = true
						a.estimated, b.estimated = true, true
						return a.est > b.est
					end
				end
			end
			if (a.tankRole or false) ~= (b.tankRole or false) then return a.tankRole and true or false end
			return a.idx < b.idx
		end)
		self.sortT = now
		wipe(prev)
		self.lastEstimated = {}
		for i, e in ipairs(list) do
			prev[e.unit] = i
			self.lastEstimated[e.unit] = e.estimated
		end
	end
	local kind
	if usedEst then kind = "est"
	elseif seen.holder or seen.tanking or seen.status then kind = "sure"
	else kind = "role" end
	self.orderKind = kind
	self.seen = seen
	return kind, seen
end

-- Einmal je Kampf ins Diagnose-Protokoll: was ist im Modus ANZEIGE lesbar? (keine Namen)
function M:MeasureOnce(seen)
	if self.measured or not ns.Diag or not seen then return end
	self.measured = true
	local function yn(v) return v and "ja" or "nein" end
	ns.Diag("LESBAR", string.format("Ziel-des-Mobs=%s · Stufe=%s · isTanking=%s · Schätzung=%s · Einheit=%s · greift-mich-an=%s",
		yn(seen.holder), yn(seen.status), yn(seen.tanking), yn(seen.estimate), tostring(seen.unit or "?"), tostring(seen.attacksMe or "?")))
end
ns:On("PLAYER_REGEN_DISABLED", function() M.measured = false end)

-- Liefert die Liste und ob die Werte geschützt sind.
-- Geschützt (Forever, z. B. bei Bossen): keine Sortierung nach Wert möglich -
-- der Tank steht oben, die Zahlen zeigt das Spiel selbst an, die Farbe kommt aus dem Status.
function M:Collect()
	local list, secret = {}, false
	-- Modus ANZEIGE: auch lesbare Werte nur durchreichen (keine eigene Sortierung / Vergleiche)
	local display = ns:ThreatMode() == "DISPLAY"
	for _, u in ipairs(ns.groupUnits) do
		local ok, isTanking, status, scaled, raw = pcall(API.UnitDetailedThreatSituation, u, "target")
		if ok and (display or ns.IsSecret(scaled, "threatValues") or ns.IsSecret(raw, "threatValues") or ns.IsSecret(isTanking)) then
			secret = true
			if ns.IsSecret(scaled, "threatValues") or scaled ~= nil then
				local name = API.UnitName(u)
				if not ns.IsSecret(name) and not name then name = "?" end
				local class = API.UnitIsPlayer(u) and select(2, API.UnitClass(u)) or nil
				if ns.IsSecret(class) then class = nil end
				list[#list + 1] = {
					name = name, class = ns.Safe(class, nil), pull = scaled, secret = true,
					tanking = ns.Safe(isTanking, false), status = ns.Safe(status, 0) or 0,
					me = ns:SameUnit(u, "player"), isTank = ns:SameUnit(u, ns:TankUnit()),
					tankRole = ns:GetRole(u) == "TANK",
					unit = u, rawTanking = isTanking, rawStatus = status, key = ns:FullName(u),
				}
			end
		elseif ok and status and (scaled or raw) then
			local name = ns.Safe(API.UnitName(u), nil) or "?"
			local class
			if API.UnitIsPlayer(u) then
				class = ns.Safe(select(2, API.UnitClass(u)), nil)
			else
				name = name .. " (" .. L.PET .. ")"
			end
			list[#list + 1] = {
				name = name, class = class, pull = PullPercent(u, scaled, raw, class),
				tanking = isTanking, me = ns:SameUnit(u, "player"), isTank = ns:SameUnit(u, ns:TankUnit()),
			}
		end
	end
	if secret and display then
		-- Modus ANZEIGE: Reihenfolge nach Aggro mit der besten verfügbaren Stufe (siehe OrderDisplay)
		ns:Compat("threatValues", "fallback")
		for i, e in ipairs(list) do e.secret = true; e.idx = i end
		local _, seen = self:OrderDisplay(list)
		self:MeasureOnce(seen)
		return list, true
	end
	self.orderKind = nil
	if secret then
		ns:Compat("threatValues", "fallback")
		for _, e in ipairs(list) do e.secret = true end
		table.sort(list, function(a, b)
			if a.tanking ~= b.tanking then return a.tanking end
			return (a.status or 0) > (b.status or 0)
		end)
		return list, true
	end
	table.sort(list, function(a, b)
		if a.tanking ~= b.tanking then return a.tanking end
		return a.pull > b.pull
	end)
	return list, false
end

local TEST_LIST
local function TestList()
	if not TEST_LIST then
		TEST_LIST = {
			{ name = ns.playerName or "Du", class = ns.class, pull = 100, tanking = true, me = true },
			{ name = "Torben", class = "ROGUE", pull = 80 },
			{ name = "Mira", class = "MAGE", pull = 62 },
			{ name = "Anna", class = "PRIEST", pull = 41 },
			{ name = "Grimbar", class = "WARRIOR", pull = 30 },
			{ name = "Wolf (" .. L.PET .. ")", pull = 12 },
		}
	end
	-- leichte Bewegung, damit man die Balken arbeiten sieht
	local t = GetTime()
	TEST_LIST[2].pull = 80 + math.sin(t * 0.9) * 18
	TEST_LIST[3].pull = 62 + math.sin(t * 0.6 + 1) * 14
	return TEST_LIST
end

function M:Render(list, targetName, secret)
	local f, db = self.f, ns.db
	-- geschützter Name: unverändert anzeigen (nicht formatieren)
	if ns.IsSecret(targetName) then f.title:SetText(targetName)
	else f.title:SetText(string.format(L.METER_TITLE, targetName or "?")) end

	-- Vorsprung des Tanks: wie weit der nächste Spieler noch vom Ziehen entfernt ist
	local tank, best = nil, 0
	for _, e in ipairs(list) do
		if e.tanking then tank = e elseif not secret and e.pull > best then best = e.pull end
	end
	if ns:ThreatMode() == "DISPLAY" then
		-- Modus ANZEIGE: keine eigene Bewertung (kein Vorsprung, keine Warnung)
		f.lead:SetText("")
	elseif secret then
		-- Werte geschützt: kein Vorsprung berechenbar, nur Warnung aus dem Status
		local danger = tank and tank.isTank and (tank.status or 0) == 2
		f.lead:SetText(danger and L.METER_LEAD_NONE or "")
		f.lead:SetTextColor(1, 0.3, 0.3)
	elseif tank and tank.isTank then
		local lead = 100 - best
		if lead <= 5 then
			f.lead:SetText(L.METER_LEAD_NONE)
			f.lead:SetTextColor(1, 0.3, 0.3)
		else
			f.lead:SetText(string.format(L.METER_LEAD, math.floor(lead + 0.5)))
			if lead < 20 then f.lead:SetTextColor(1, 0.85, 0.2)
			else f.lead:SetTextColor(0.3, 1, 0.4) end
		end
	else
		f.lead:SetText("")
	end

	-- Anzeigen: die obersten Zeilen, du selbst immer dabei
	local maxRows = db.meterRows
	local shown = {}
	for i = 1, math.min(#list, maxRows) do shown[i] = list[i] end
	local meShown = false
	for _, e in ipairs(shown) do if e.me then meShown = true end end
	if not meShown then
		for _, e in ipairs(list) do
			if e.me then shown[math.min(#shown + 1, maxRows)] = e break end
		end
	end

	local display = ns:ThreatMode() == "DISPLAY"
	local orderText = ""
	if display and secret and self.orderKind then
		orderText = self.orderKind == "est" and L.METER_ORDER_EST or self.orderKind == "sure" and L.METER_ORDER_SURE
			or L.METER_ORDER_ROLE
	end
	f.order:SetText(orderText)
	local top = orderText ~= "" and 32 or 20
	for i, e in ipairs(shown) do
		local r = self:Row(i)
		r:ClearAllPoints()
		r:SetPoint("TOPLEFT", 4, -top - (i - 1) * ROW_H)
		local cr, cg, cb = ClassColor(e.class)
		r:SetStatusBarColor(cr, cg, cb, 0.85)
		if ns.IsSecret(e.name) then r.name:SetText(e.name)
		else r.name:SetText((e.estimated and "~" or "") .. (e.me and "> " or "") .. e.name) end
		if display then
			-- Modus ANZEIGE: Werte nur durchreichen, neutrale Farbe, keine Schwellwerte
			r:SetStatusBarColor(0.45, 0.6, 0.85, 0.85)
			r:SetValue(e.pull)
			if not pcall(r.value.SetFormattedText, r.value, "%.0f%%", e.pull) then r.value:SetText(e.pull) end
			r.value:SetTextColor(1, 1, 1)
		elseif e.tanking then
			r:SetValue(100)
			r.value:SetText(L.METER_AGGRO)
			r.value:SetTextColor(1, 0.35, 0.35)
		elseif e.secret then
			-- geschützter Wert: Balken und Zahl setzt das Spiel, Farbe aus dem Status
			r:SetValue(e.pull)
			-- geschützte Zahl: nicht selbst formatieren, das Spiel zeigt sie an
			if not pcall(r.value.SetFormattedText, r.value, "%.0f%%", e.pull) then r.value:SetText(e.pull) end
			if (e.status or 0) >= 1 then r.value:SetTextColor(1, 0.35, 0.35) else r.value:SetTextColor(1, 1, 1) end
		else
			r:SetValue(math.min(e.pull, SCALE_MAX))
			r.value:SetText(string.format("%d%%", math.floor(e.pull + 0.5)))
			if e.pull >= ns.db.warnThreshold then r.value:SetTextColor(1, 0.35, 0.35)
			else r.value:SetTextColor(1, 1, 1) end
		end
		r:Show()
	end
	for i = #shown + 1, #f.rows do f.rows[i]:Hide() end
	f:SetHeight(top + 4 + #shown * ROW_H)
	f:Show()
end

function M:Tick()
	local f, db = self.f, ns.db
	if not f then return end
	-- Testmodus und Verschieben: Beispielliste (auch als Tank / wenn ausgeschaltet beim Verschieben)
	if ns.moveMode or (ns.testMode and db.enabled and db.meter) then
		self:Render(TestList(), L.TEST_TARGET)
		return
	end

	if db.meterOnlyTank and not ns:IsTankStance() then f:Hide() return end
	-- Modus AUS (Bedrohungsdaten nicht verfügbar): ausblenden
	if ns:ThreatMode() == "OFF" then f:Hide() return end

	if not db.enabled or not db.meter then f:Hide() return end

	if ns:Unlocked() and not API.UnitAffectingCombat("player") then
		f.title:SetText(L.METER_DRAG)
		f.lead:SetText("")
		f.order:SetText("")
		for i = 1, #f.rows do f.rows[i]:Hide() end
		f:SetHeight(24)
		f:Show()
		return
	end

	if not API.UnitExists("target") or not ns.Safe(API.UnitCanAttack("player", "target"), false) or ns.Safe(API.UnitIsDeadOrGhost("target"), true) then
		f:Hide()
		return
	end
	local list, secret = self:Collect()
	if #list == 0 then f:Hide() return end
	self:Render(list, API.UnitName("target"), secret)
end
