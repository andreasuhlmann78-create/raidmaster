# GuildSentinel – Changelog

## 0.9.1
- Test mode is now developer-only: the Settings > Test mode tab and `/gs test` only appear for the developer account. Nothing else changes for players.

## 0.9.0
- **Who's free** (Group finder): one click flags you as free for dungeon, raid, quest group or PvP for 1, 2 or 4 hours. Everyone with GuildSentinel sees who is free, with level, item level and zone. Inside dungeons, raids and battlegrounds you automatically show as busy.
- After posting a group search, GuildSentinel tells you how many guild members are free for it right now.
- **Item level** with "I'll join": the searcher sees it in the replies and in chat.
- **Bulk actions** (Leadership, officers): remove inactive players by rule or promote several suggestions at once – always a checklist first, one step per click.
- **GRM import** (Leadership): alts, join dates and personal notes from Guild Roster Manager, with a preview.

## 0.8.3
- New **Support** button (PayPal link to copy) in the title bar and under Settings > General, also `/gs donate`. Opens only on click.

## 0.8.2
- Guild achievements: singular for the first weekly goal; names that are too long use a smaller font.
- Professions: old raw-material entries (e.g. Felweed as "Alchemy") are removed automatically.

## 0.8.1
- Settings > Features in three columns; probation advice follows the 40 % rule; overview counts departures like Leadership; My week markers and singulars; chronicle without duplicates; loot wishes preselect a dungeon; removing a question asks first; raw materials leave the watch list.

## 0.8.0
- All WoW client languages; Classic Era, WoW Forever and TBC Classic / Anniversary; Overview, Leadership, My week, loot wishes, questions, guild achievements, chronicle, weekly recap, welcome guide, features on/off.
