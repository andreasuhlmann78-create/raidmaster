-- GuildSentinel - PagesLead.lua
-- Seite "Leitung" (nur für Offiziere): Probezeit, Abgänge mit Grund, Offiziersnotizen mit Verlauf, Rangrechte.

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local UI = ns.UI

local GREEN, GRAY, GOLD, ORANGE = "|cff40d860", "|cff8a8f99", "|cffffd100", "|cffff9933"
local function Gray(t) return GRAY .. tostring(t) .. "|r" end
local function WhenShown(key, fn)
	return function(...) if UI:IsPageShown(key) then fn(...) end end
end

local Le = { key = "lead", feature = "lead", officer = true, order = 60, icon = "Interface\\Icons\\INV_Misc_Book_11" }
Le.title = N["Leitung"]
Le.view = "prob"

local function View(p)
	local v = CreateFrame("Frame", nil, p)
	v:SetPoint("TOPLEFT", 0, -34)
	v:SetPoint("BOTTOMRIGHT")
	v:Hide()
	return v
end

function Le.build(p)
	Le.panel = p
	Le.tabs = UI:Tabs(p, {
		{ key = "prob", text = L["Probezeit"] },
		{ key = "gone", text = L["Abgänge"] },
		{ key = "notes", text = L["Offiziersnotizen"] },
		{ key = "ranks", text = L["Rangrechte"] },
		{ key = "bulk", text = L["Sammelaktionen"] },
		{ key = "grm", text = L["GRM-Import"] },
	}, function(key) Le.view = key; Le:Refresh() end)
	Le.tabs:SetPoint("TOPLEFT", 0, 0)
	Le.tabs:SetPoint("TOPRIGHT", 0, 0)
	Le.views = {}
	Le:BuildProbation(View(p))
	Le:BuildGone(View(p))
	Le:BuildNotes(View(p))
	Le:BuildRanks(View(p))
	Le:BuildBulk(View(p))
	Le:BuildGRM(View(p))
end

------------------------------------------------------------
-- Sammelaktionen: Prüfliste, dann ein Schritt pro Klick
------------------------------------------------------------
Le.bulk = { mode = "kick", days = 90, minRi = nil, keepMax = true }

function Le:BuildBulk(v)
	self.views.bulk = v
	local B = self.bulk
	local mode = UI:Dropdown(v, 230, function()
		return { { value = "kick", text = L["Inaktive entfernen"] }, { value = "promote", text = L["Vorschläge befördern"] } }
	end, function() return B.mode end, function(val) B.mode = val; Le:BulkReload() end)
	mode:SetPoint("TOPLEFT", 0, -2)
	self.bulkDays = UI:Dropdown(v, 170, function()
		local out = {}
		for _, d in ipairs(ns.Bulk.DAYS) do out[#out + 1] = { value = d, text = string.format(L["offline seit %d Tagen"], d) } end
		return out
	end, function() return B.days end, function(val) B.days = val; Le:BulkReload() end)
	self.bulkDays:SetPoint("LEFT", mode, "RIGHT", 8, 0)
	self.bulkRank = UI:Dropdown(v, 190, function()
		local out = {}
		for _, r in ipairs(ns.Roster:Ranks()) do
			if r.ri > 0 then out[#out + 1] = { value = r.ri, text = string.format(L["ab Rang %s"], r.name) } end
		end
		return out
	end, function() return B.minRi end, function(val) B.minRi = val; Le:BulkReload() end)
	self.bulkRank:SetPoint("LEFT", self.bulkDays, "RIGHT", 8, 0)
	self.bulkKeep = UI:Check(v, L["Höchststufe behalten"], function() return B.keepMax end, function(val) B.keepMax = val; Le:BulkReload() end)
	self.bulkKeep:SetPoint("LEFT", self.bulkRank, "RIGHT", 10, 0)
	self.bulkInfo = UI:Label(v, "", "GameFontHighlightSmall")
	self.bulkInfo:SetPoint("TOPLEFT", 0, -34)
	self.bulkInfo:SetWidth(780)
	self.bulkInfo:SetJustifyH("LEFT")
	self.bulkList = UI:List(v, {
		{ key = "on", title = "", width = 30, align = "CENTER" },
		{ key = "name", title = L["Name"], width = 150 },
		{ key = "level", title = L["Stufe"], width = 50, align = "CENTER" },
		{ key = "rank", title = L["Rang"], width = 130 },
		{ key = "x", title = L["Details"], width = 200 },
		{ key = "main", title = L["Main"] },
	}, {
		key = function(x) return x.name end,
		render = function(x)
			local mark = x.off and Gray("–") or (GREEN .. "+|r")
			local det = x.to and string.format(L["→ %s · %d Tage dabei"], x.to, x.days or 0) or string.format(L["offline seit %d Tagen"], x.days or 0)
			return { mark, ns.Colored(x.name, x.class), tostring(x.level), x.rank or "", det, x.main or Gray("–") }
		end,
		onClick = function(x) if x and not ns.Bulk.queue then x.off = not x.off; Le.bulkList:Draw(); Le:BulkButtons() end end,
		empty = L["Niemand passt zu dieser Regel."],
	})
	self.bulkList:SetPoint("TOPLEFT", 0, -56)
	self.bulkList:SetPoint("BOTTOMRIGHT", 0, 40)
	self.bulkAll = UI:Button(v, L["Alle an/aus"], 120, 26, function()
		local data = Le.bulkList.data or {}
		local anyOn = false
		for _, x in ipairs(data) do if not x.off then anyOn = true end end
		for _, x in ipairs(data) do x.off = anyOn end
		Le.bulkList:Draw(); Le:BulkButtons()
	end)
	self.bulkAll:SetPoint("BOTTOMLEFT", 0, 4)
	self.bulkStart = UI:Button(v, L["Prüfliste übernehmen"], 180, 26, function()
		local names = {}
		for _, x in ipairs(Le.bulkList.data or {}) do if not x.off then names[#names + 1] = x.name end end
		if #names == 0 then return end
		local q = B.mode == "kick" and L["%d Spieler aus der Gilde entfernen? Danach führt jeder Klick auf „Nächster“ einen Schritt aus."]
			or L["%d Spieler befördern? Danach führt jeder Klick auf „Nächster“ einen Schritt aus."]
		UI:Confirm(string.format(q, #names), function() ns.Bulk:Start(B.mode, names) end)
	end, true)
	self.bulkStart:SetPoint("LEFT", self.bulkAll, "RIGHT", 8, 0)
	self.bulkNext = UI:Button(v, L["Nächster"], 220, 26, function() ns.Bulk:Step() end, true)
	self.bulkNext:SetPoint("LEFT", self.bulkStart, "RIGHT", 8, 0)
	self.bulkCancel = UI:Button(v, L["Abbrechen"], 110, 26, function() ns.Bulk:Cancel() end)
	self.bulkCancel:SetPoint("LEFT", self.bulkNext, "RIGHT", 8, 0)
end

-- Prüfliste neu aufbauen (alle angehakt)
function Le:BulkReload()
	local B = self.bulk
	if not B.minRi then
		local ranks = ns.Roster:Ranks()
		B.minRi = ranks[#ranks] and ranks[#ranks].ri or 1
		if #ranks >= 2 then B.minRi = ranks[#ranks - 1].ri end
	end
	local list = B.mode == "kick" and ns.Bulk:KickCandidates(B.days, B.minRi, B.keepMax) or ns.Bulk:PromoteCandidates()
	self.bulkData = list
	if self.bulkList then self.bulkList:SetData(list) end
	self:Refresh()
end

function Le:BulkButtons()
	if not self.bulkList then return end
	local B = self.bulk
	local q = ns.Bulk.queue
	local on = 0
	for _, x in ipairs(self.bulkList.data or {}) do if not x.off then on = on + 1 end end
	local kick = B.mode == "kick"
	self.bulkDays:SetShown(kick)
	self.bulkRank:SetShown(kick)
	self.bulkKeep:SetShown(kick)
	self.bulkAll:SetEnabled(q == nil and #(self.bulkList.data or {}) > 0)
	self.bulkStart:SetEnabled(q == nil and on > 0 and (kick and ns.Bulk:CanKick() or (not kick and ns.CanPromote())))
	self.bulkNext:SetEnabled(q ~= nil)
	self.bulkCancel:SetEnabled(q ~= nil)
	if q then
		self.bulkNext:SetText(string.format(L["Nächster: %s (%d übrig)"], ns.Bulk:Next() or "", ns.Bulk:Remaining()))
		self.bulkInfo:SetText(GOLD .. string.format(q.mode == "kick" and L["Entfernen läuft: %d von %d erledigt. Jeder Klick auf „Nächster“ führt einen Schritt aus."]
			or L["Befördern läuft: %d von %d erledigt. Jeder Klick auf „Nächster“ führt einen Schritt aus."], q.done, q.total) .. "|r")
	else
		self.bulkNext:SetText(L["Nächster"])
		local rule = kick and string.format(L["Regel: offline seit mindestens %d Tagen (auch kein Twink online), nicht abwesend gemeldet, Rang unter deinem."], B.days)
			or L["Regel: die Beförderungs-Vorschläge nach euren Regeln (Mitglieder > Befördern)."]
		self.bulkInfo:SetText(Gray(rule) .. "  " .. string.format(L["%d von %d ausgewählt – Klick auf eine Zeile wählt ab oder an."], on, #(self.bulkList.data or {})))
	end
end

------------------------------------------------------------
-- Import aus Guild Roster Manager
------------------------------------------------------------
Le.grm = { alts = true, joins = true, notes = true }

function Le:BuildGRM(v)
	self.views.grm = v
	local h = UI:Header(v, L["Daten aus Guild Roster Manager (GRM) übernehmen"])
	h:SetPoint("TOPLEFT", 0, 0)
	self.grmInfo = UI:Label(v, "", "GameFontHighlightSmall")
	self.grmInfo:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -6)
	self.grmInfo:SetWidth(780)
	self.grmInfo:SetJustifyH("LEFT")
	local G = self.grm
	local c1 = UI:Check(v, L["Twinks"], function() return G.alts end, function(val) G.alts = val end)
	c1:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -46)
	local c2 = UI:Check(v, L["Beitrittsdaten"], function() return G.joins end, function(val) G.joins = val end)
	c2:SetPoint("LEFT", c1, "RIGHT", 120, 0)
	local c3 = UI:Check(v, L["Notizen (nur für dich)"], function() return G.notes end, function(val) G.notes = val end)
	c3:SetPoint("LEFT", c2, "RIGHT", 140, 0)
	self.grmText = UI:ScrollText(v, 780, 260)
	self.grmText:SetPoint("TOPLEFT", h, "BOTTOMLEFT", 0, -78)
	self.grmText:SetPoint("BOTTOMRIGHT", 0, 40)
	self.grmBtn = UI:Button(v, L["Übernehmen"], 160, 26, function()
		local p = ns.Bulk:GRMPreview()
		if not p then return end
		UI:Confirm(L["Diese Daten aus GRM übernehmen? Was in GuildSentinel schon eingetragen ist, bleibt."], function()
			ns.Bulk:GRMImport(Le.grm)
			Le:Refresh()
		end)
	end, true)
	self.grmBtn:SetPoint("BOTTOMLEFT", 0, 4)
	local hint = UI:Label(v, Gray(L["Tipp: Nach dem Import kannst du GRM ausschalten – GuildSentinel teilt Twinks und Beitrittsdaten mit der Gilde."]), "GameFontHighlightSmall")
	hint:SetPoint("LEFT", self.grmBtn, "RIGHT", 12, 0)
end

function Le:RefreshGRM()
	local p = ns.Bulk:GRMPreview()
	if not p then
		self.grmInfo:SetText(ORANGE .. (ns.Bulk:GRMLoaded() and L["GRM ist geladen, hat aber keine Daten zu dieser Gilde."]
			or L["Guild Roster Manager ist nicht geladen. Aktiviere GRM im Addon-Menü, lade neu (/reload) und öffne diesen Reiter wieder."]) .. "|r")
		self.grmText:SetText("")
		self.grmBtn:SetEnabled(false)
		return
	end
	self.grmInfo:SetText(string.format(L["Gefunden in GRM (%s): %d Twinks, %d Beitrittsdaten, %d Notizen, die in GuildSentinel noch fehlen."], p.guild, #p.alts, #p.joins, #p.notes))
	local lines = {}
	if #p.alts > 0 then
		lines[#lines + 1] = GOLD .. L["Twinks"] .. "|r"
		for _, x in ipairs(p.alts) do lines[#lines + 1] = "   " .. string.format(L["%s ist Twink von %s"], x.name, x.main) end
	end
	if #p.joins > 0 then
		lines[#lines + 1] = GOLD .. L["Beitrittsdaten"] .. "|r"
		for _, x in ipairs(p.joins) do lines[#lines + 1] = "   " .. x.name .. ": " .. ns.Date(x.t) end
	end
	if #p.notes > 0 then
		lines[#lines + 1] = GOLD .. L["Notizen (nur für dich)"] .. "|r"
		for _, x in ipairs(p.notes) do lines[#lines + 1] = "   " .. x.name .. ": " .. x.text end
	end
	if #lines == 0 then lines[1] = GREEN .. L["Alles schon übernommen – GRM hat nichts Neues."] .. "|r" end
	self.grmText:SetText(table.concat(lines, "\n"))
	self.grmBtn:SetEnabled(#p.alts + #p.joins + #p.notes > 0)
end

------------------------------------------------------------
-- Probezeit
------------------------------------------------------------
function Le:BuildProbation(v)
	self.views.prob = v
	self.probInfo = UI:Label(v, "", "GameFontHighlight")
	self.probInfo:SetPoint("TOPLEFT", 0, -5)
	local change = UI:Button(v, L["Probezeit ändern"], 150, 24, function()
		UI:Ask(L["Wie viele Tage dauert die Probezeit?"], tostring(ns.Lead:ProbationDays()), function(t) ns.Lead:SetProbationDays(t) end)
	end)
	change:SetPoint("TOPRIGHT", 0, 0)
	self.probList = UI:List(v, {
		{ key = "name", title = L["Name"], width = 150 },
		{ key = "level", title = L["Stufe"], width = 50, align = "CENTER" },
		{ key = "days", title = L["Dabei seit"], width = 90, align = "CENTER" },
		{ key = "online", title = L["Online-Tage"], width = 90, align = "CENTER" },
		{ key = "events", title = L["Termine"], width = 70, align = "CENTER" },
		{ key = "thanks", title = L["Danke"], width = 60, align = "CENTER" },
		{ key = "mentor", title = L["Pate"], width = 110 },
		{ key = "advice", title = L["Empfehlung"] },
	}, {
		key = function(x) return x.name end,
		render = function(x)
			local adv = ns.Lead:AdviceText(x)
			if x.advice == "promote" then adv = GREEN .. adv .. "|r" elseif x.advice == "talk" then adv = ORANGE .. adv .. "|r" else adv = Gray(adv) end
			return { ns.Colored(x.name, x.class), tostring(x.level), string.format(L["%d Tagen"], x.days), string.format("%d (%d%%)", x.online, math.floor((x.pct or 0) * 100 + 0.5)), tostring(x.events),
				tostring(x.thanks), x.mentor or Gray("–"), adv }
		end,
		onClick = function() Le:UpdateButtons() end,
		empty = L["Gerade ist niemand in der Probezeit."],
	})
	self.probList:SetPoint("TOPLEFT", 0, -32)
	self.probList:SetPoint("BOTTOMRIGHT", 0, 70)
	local function Sel() local x = self.probList:Selected(); return x and x.name end
	self.probPromote = UI:Button(v, L["Befördern"], 140, 26, function()
		local n = Sel()
		if n then UI:Confirm(string.format(L["%s jetzt befördern?"], n), function() ns.Promote:Promote(n) end) end
	end, true)
	self.probPromote:SetPoint("BOTTOMLEFT", 0, 36)
	self.probMentor = UI:Button(v, L["Pate vorschlagen"], 160, 26, function()
		local n = Sel()
		if not n then return end
		local m, ov = ns.Lead:SuggestMentor(n)
		if not m then ns:Print(L["Kein passender Pate gefunden – es braucht noch ein paar Tage Online-Zeiten."]) return end
		UI:Confirm(string.format(L["%s als Pate für %s? (gleiche Online-Zeiten: %d%%)"], m, n, math.floor((ov or 0) * 100 + 0.5)), function() ns.Social:SetMentor(n, m) end)
	end)
	self.probMentor:SetPoint("LEFT", self.probPromote, "RIGHT", 8, 0)
	self.probNote = UI:Button(v, L["Notiz schreiben"], 150, 26, function()
		local n = Sel()
		if n then UI:Ask(string.format(L["Offiziersnotiz zu %s:"], n), "", function(t) ns.Lead:AddNote(n, t) end) end
	end)
	self.probNote:SetPoint("LEFT", self.probMentor, "RIGHT", 8, 0)
	local hint = UI:Label(v, Gray(L["Empfehlung nach Ablauf: Befördern, wenn jemand an mindestens 40 % der Tage online war (mindestens 3), sonst ein Gespräch. Befördert wird immer von Hand."]), "GameFontHighlightSmall")
	hint:SetPoint("BOTTOMLEFT", 0, 4)
	hint:SetPoint("RIGHT")
	hint:SetJustifyH("LEFT")
end

------------------------------------------------------------
-- Abgänge
------------------------------------------------------------
function Le:BuildGone(v)
	self.views.gone = v
	self.goneInfo = UI:Label(v, "", "GameFontHighlight")
	self.goneInfo:SetPoint("TOPLEFT", 0, -5)
	self.goneList = UI:List(v, {
		{ key = "name", title = L["Name"], width = 150 },
		{ key = "l", title = L["Stufe"], width = 50, align = "CENTER" },
		{ key = "r", title = L["Rang"], width = 110 },
		{ key = "t", title = L["Wann"], width = 120 },
		{ key = "k", title = L["Art"], width = 90 },
		{ key = "reason", title = L["Grund"] },
	}, {
		key = function(x) return x.name end,
		render = function(x)
			return { ns.Colored(x.name, x.c), x.l and tostring(x.l) or "?", x.r or Gray("?"), ns.Date(x.t),
				x.k == "kick" and (ORANGE .. L["entfernt"] .. "|r") or L["verlassen"], (x.reason and x.reason ~= "") and x.reason or Gray(L["kein Grund eingetragen"]) }
		end,
		onClick = function() Le:UpdateButtons() end,
		empty = L["In den letzten 180 Tagen hat niemand die Gilde verlassen."],
	})
	self.goneList:SetPoint("TOPLEFT", 0, -32)
	self.goneList:SetPoint("BOTTOMRIGHT", 0, 40)
	self.goneReason = UI:Button(v, L["Grund eintragen"], 160, 26, function()
		local x = self.goneList:Selected()
		if x then UI:Ask(string.format(L["Warum hat %s die Gilde verlassen?"], x.name), x.reason or "", function(t) ns.Lead:SetGoneReason(x.name, t) end) end
	end, true)
	self.goneReason:SetPoint("BOTTOMLEFT", 0, 4)
	local hint = UI:Label(v, Gray(L["Gründe und Notizen sehen nur Offiziere mit GuildSentinel."]), "GameFontHighlightSmall")
	hint:SetPoint("LEFT", self.goneReason, "RIGHT", 12, 0)
end

------------------------------------------------------------
-- Offiziersnotizen
------------------------------------------------------------
function Le:BuildNotes(v)
	self.views.notes = v
	local search = UI:Edit(v, 280, 24, L["Spieler suchen"])
	search:SetPoint("TOPLEFT")
	search.onChange = function(t) Le.noteQuery = t; Le:Refresh() end
	self.notePlayers = UI:List(v, {
		{ key = "name", title = L["Spieler"], width = 170 },
		{ key = "n", title = L["Notizen"], width = 70, align = "CENTER" },
	}, {
		key = function(x) return x.name end,
		render = function(x) return { ns.Colored(x.name, x.class), x.n > 0 and tostring(x.n) or Gray("–") } end,
		onClick = function() Le:RefreshNotes() end,
		empty = L["Keine Spieler gefunden."],
	})
	self.notePlayers:SetPoint("TOPLEFT", 0, -32)
	self.notePlayers:SetPoint("BOTTOMLEFT", 0, 0)
	self.notePlayers:SetWidth(280)
	self.noteTitle = UI:Label(v, "", "GameFontNormalLarge")
	self.noteTitle:SetPoint("TOPLEFT", 296, -4)
	self.noteList = UI:List(v, {
		{ key = "t", title = L["Wann"], width = 110 },
		{ key = "by", title = L["Von"], width = 100 },
		{ key = "text", title = L["Notiz"] },
	}, {
		key = function(x) return x.id end,
		render = function(x) return { Gray(ns.Date(x.t)), x.by, x.text } end,
		onEnter = function(row, x)
			GameTooltip:SetOwner(row, "ANCHOR_CURSOR")
			GameTooltip:AddLine(x.by .. " · " .. ns.Date(x.t), 0.7, 0.7, 0.7)
			GameTooltip:AddLine(x.text, 1, 1, 1, true)
			GameTooltip:Show()
		end,
		onClick = function() Le:UpdateButtons() end,
		empty = L["Noch keine Notizen zu diesem Spieler."],
	})
	self.noteList:SetPoint("TOPLEFT", 296, -32)
	self.noteList:SetPoint("BOTTOMRIGHT", 0, 40)
	self.noteAdd = UI:Button(v, L["Notiz hinzufügen"], 160, 26, function()
		local x = self.notePlayers:Selected()
		if x then UI:Ask(string.format(L["Offiziersnotiz zu %s:"], x.name), "", function(t) ns.Lead:AddNote(x.name, t) end) end
	end, true)
	self.noteAdd:SetPoint("BOTTOMLEFT", 296, 4)
	self.noteDel = UI:Button(v, L["Notiz löschen"], 140, 26, function()
		local x, n = self.noteList:Selected(), self.notePlayers:Selected()
		if x and n then UI:Confirm(L["Diese Notiz löschen?"], function() ns.Lead:DeleteNote(n.name, x.id) end) end
	end)
	self.noteDel:SetPoint("LEFT", self.noteAdd, "RIGHT", 8, 0)
end

function Le:RefreshNotes()
	local x = self.notePlayers:Selected()
	if x then
		self.noteTitle:SetText(ns.Colored(x.name, x.class))
		self.noteList:SetData(ns.Lead:Notes(x.name))
	else
		self.noteTitle:SetText(Gray(L["Wähle links einen Spieler."]))
		self.noteList:SetData({})
	end
	self:UpdateButtons()
end

------------------------------------------------------------
-- Rangrechte
------------------------------------------------------------
function Le:BuildRanks(v)
	self.views.ranks = v
	self.rankInfo = UI:Label(v, "", "GameFontHighlightSmall")
	self.rankInfo:SetPoint("TOPLEFT", 0, -5)
	self.rankInfo:SetPoint("RIGHT")
	self.rankInfo:SetJustifyH("LEFT")
	self.rankText = UI:ScrollText(v, 780, 440)
	self.rankText:SetPoint("TOPLEFT", 0, -30)
	self.rankText:SetPoint("BOTTOMRIGHT")
end

function Le:RefreshRanks()
	local ranks, labels, readable = ns.Lead:RankRights()
	if not readable or #labels == 0 then
		self.rankInfo:SetText(Gray(L["Die Rangrechte kann das Spiel nur der Gildenleitung zeigen (Recht 'Gilde verwalten'). Ränge:"]))
		local t = {}
		for _, r in ipairs(ranks) do t[#t + 1] = r.ri .. ": " .. r.name end
		self.rankText:SetText(table.concat(t, "\n"))
		return
	end
	self.rankInfo:SetText(Gray(L["Welcher Rang darf was? (Bezeichnungen aus dem Spiel; ändern geht im Gildenfenster des Spiels)"]))
	local lines = {}
	for _, lab in ipairs(labels) do
		local who = {}
		for _, r in ipairs(ranks) do if r.flags[lab.i] then who[#who + 1] = r.name end end
		lines[#lines + 1] = GOLD .. lab.text .. "|r: " .. (#who > 0 and table.concat(who, ", ") or Gray(L["niemand"]))
	end
	self.rankText:SetText(table.concat(lines, "\n"))
end

------------------------------------------------------------
-- Anzeige
------------------------------------------------------------
function Le:UpdateButtons()
	if not self.probList then return end
	local p = self.probList:Selected()
	self.probPromote:SetEnabled(p ~= nil and ns.CanPromote())
	self.probMentor:SetEnabled(p ~= nil)
	self.probNote:SetEnabled(p ~= nil)
	self.goneReason:SetEnabled(self.goneList:Selected() ~= nil)
	self.noteAdd:SetEnabled(self.notePlayers:Selected() ~= nil)
	self.noteDel:SetEnabled(self.noteList:Selected() ~= nil)
end

function Le:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	for key, v in pairs(self.views) do v:SetShown(key == self.view) end
	if self.view == "prob" then
		local list = ns.Lead:Probation()
		local due = 0
		for _, x in ipairs(list) do if x.due then due = due + 1 end end
		self.probInfo:SetText(string.format(L["Probezeit: %d Tage · %d in der Probezeit · %d fällig"], ns.Lead:ProbationDays(), #list, due))
		self.probList:SetData(list)
	elseif self.view == "gone" then
		local list = ns.Lead:Gone(180)
		local d30 = 0
		for _, x in ipairs(list) do if x.t >= ns.Now() - 30 * 86400 then d30 = d30 + 1 end end
		self.goneInfo:SetText(string.format(L["%d Abgänge in den letzten 30 Tagen, %d in 180 Tagen"], d30, #list))
		self.goneList:SetData(list)
	elseif self.view == "notes" then
		local q = ns.Trim(self.noteQuery):lower()
		local list, seen = {}, {}
		for _, x in ipairs(ns.Lead:NotedPlayers()) do seen[x.name] = x end
		for _, e in ipairs(ns.Roster.list) do
			if q == "" or e.name:lower():find(q, 1, true) then
				local x = seen[e.name]
				list[#list + 1] = { name = e.name, class = e.class, n = x and x.n or 0 }
			end
		end
		-- Notizen zu Ehemaligen
		for name, x in pairs(seen) do
			if not ns.Roster.byName[name] and (q == "" or name:lower():find(q, 1, true)) then
				list[#list + 1] = { name = name, n = x.n }
			end
		end
		table.sort(list, function(a, b) if (a.n > 0) ~= (b.n > 0) then return a.n > 0 end return a.name < b.name end)
		self.notePlayers:SetData(list)
		self:RefreshNotes()
	elseif self.view == "ranks" then
		self:RefreshRanks()
	elseif self.view == "bulk" then
		if not self.bulkData then self:BulkReload() return end
		self:BulkButtons()
	elseif self.view == "grm" then
		self:RefreshGRM()
	end
	self:UpdateButtons()
end

Le.onShow = function(_, arg)
	Le.tabs:Select(arg or Le.view or "prob")
end
ns:Listen("GS_LEAD", WhenShown("lead", function() Le:Refresh() end))
ns:Listen("GS_BULK", WhenShown("lead", function()
	-- nach einer Sammelaktion die Prüfliste neu aufbauen
	if not ns.Bulk.queue then Le.bulkData = nil end
	Le:Refresh()
end))
ns:Listen("GS_ROSTER", WhenShown("lead", function() Le:Refresh() end))
ns:Listen("GS_SOCIAL", WhenShown("lead", function() if Le.view == "prob" then Le:Refresh() end end))
UI:AddPage(Le)
