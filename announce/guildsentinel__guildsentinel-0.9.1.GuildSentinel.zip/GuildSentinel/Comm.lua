-- GuildSentinel - Comm.lua
-- Addon-Nachrichten in der Gilde: Serializer, gedrosselte Warteschlange, Mehrteil-Nachrichten.

local ADDON, ns = ...
local Comm = {}
ns.Comm = Comm

Comm.PREFIX = "GuildSentinel"
Comm.handlers = {}
Comm.users = {}          -- [Name] = { v = Version, t = zuletzt gesehen }
-- über den eigenen Chatkanal (ganzer Server, auch andere Gilden) sind nur diese Nachrichten erlaubt
Comm.channelTypes = { LFG = true, LFGX = true, LFGQ = true }

------------------------------------------------------------
-- Serializer (ohne loadstring: Strings, Zahlen, Booleans, Tabellen)
------------------------------------------------------------
local function esc(s)
	return (s:gsub("~", "~0"):gsub("%^", "~1"):gsub("|", "~2"):gsub("\n", "~3"):gsub("\t", "~4"):gsub("\r", ""))
end

local UNESC = { ["0"] = "~", ["1"] = "^", ["2"] = "|", ["3"] = "\n", ["4"] = "\t" }
local function unesc(s)
	return (s:gsub("~(%d)", UNESC))
end

local function encode(v, out)
	local t = type(v)
	if t == "string" then
		out[#out + 1] = "s" .. esc(v) .. "^"
	elseif t == "number" then
		out[#out + 1] = "n" .. tostring(v) .. "^"
	elseif t == "boolean" then
		out[#out + 1] = v and "T" or "F"
	elseif t == "table" then
		out[#out + 1] = "{"
		for k, val in pairs(v) do
			local kt, vt = type(k), type(val)
			if (kt == "string" or kt == "number") and (vt == "string" or vt == "number" or vt == "boolean" or vt == "table") then
				encode(k, out)
				encode(val, out)
			end
		end
		out[#out + 1] = "}"
	end
end

function Comm.Serialize(v)
	local out = {}
	encode(v, out)
	return table.concat(out)
end

local function decode(s, pos, depth)
	if depth > 20 then error("deep") end
	local c = s:sub(pos, pos)
	if c == "s" then
		local e = s:find("^", pos + 1, true)
		if not e then error("str") end
		return unesc(s:sub(pos + 1, e - 1)), e + 1
	elseif c == "n" then
		local e = s:find("^", pos + 1, true)
		if not e then error("num") end
		return tonumber(s:sub(pos + 1, e - 1)), e + 1
	elseif c == "T" then
		return true, pos + 1
	elseif c == "F" then
		return false, pos + 1
	elseif c == "{" then
		local t = {}
		pos = pos + 1
		while true do
			local nc = s:sub(pos, pos)
			if nc == "}" then return t, pos + 1 end
			if nc == "" then error("table") end
			local k, v
			k, pos = decode(s, pos, depth + 1)
			v, pos = decode(s, pos, depth + 1)
			if k ~= nil then t[k] = v end
		end
	end
	error("token " .. tostring(c))
end

function Comm.Deserialize(s)
	if not s or s == "" then return nil end
	local ok, v = pcall(decode, s, 1, 0)
	if ok then return v end
	return nil
end

------------------------------------------------------------
-- Senden (gedrosselt, damit der Server nichts verschluckt)
------------------------------------------------------------
local queueHigh, queueLow = {}, {}
local ticker
local MAX_LEN = 250
local CHUNK = 230
local counter = 0

-- Der Server drosselt Addon-Nachrichten je Präfix (kurzer Schub, danach etwa eine pro Sekunde).
-- Darum: Eimer mit Marken, die langsam nachfüllen; gedrosselte Nachrichten werden später wiederholt.
local MAX_TOKENS, REGEN = 8, 1.0
local tokens, lastRegen = MAX_TOKENS, 0
local RETRY = { [3] = true, [8] = true }   -- AddonMessageThrottle, ChannelThrottle

local function SendNext()
	local now = GetTime()
	tokens = math.min(MAX_TOKENS, tokens + (now - lastRegen) * REGEN)
	lastRegen = now
	local q = (#queueHigh > 0) and queueHigh or queueLow
	local item = q[1]
	if not item then
		if ticker then ticker:Cancel(); ticker = nil end
		return
	end
	if tokens < 1 then return end
	if item.channel == "GUILD" and not IsInGuild() then table.remove(q, 1) return end
	local target = item.target
	if item.channel == "CHANNEL" then
		-- eigener Chatkanal (Gruppensuche für den ganzen Server): Nummer erst beim Senden bestimmen
		local id = GetChannelName and GetChannelName(item.target) or 0
		if not id or id == 0 then table.remove(q, 1) return end
		target = id
	end
	local r = ns.SendAddonMessage(Comm.PREFIX, item.msg, item.channel, target)
	if (r == false or RETRY[r]) and (item.tries or 0) < 5 then
		item.tries = (item.tries or 0) + 1
		tokens = 0
		return
	end
	table.remove(q, 1)
	tokens = tokens - 1
end

local function Enqueue(msg, channel, target, high)
	local q = high and queueHigh or queueLow
	q[#q + 1] = { msg = msg, channel = channel, target = target }
	if not ticker then
		SendNext()
		ticker = C_Timer.NewTicker(0.2, SendNext)
	end
end

-- Nachrichten, die zu einer abschaltbaren Funktion gehören (ist sie aus, wird nichts gesendet und nichts angenommen)
Comm.FEATURE = {
	LFG = "group", LFGJ = "group", LFGQ = "group", LFGX = "group", FREE = "group", FREEQ = "group",
	EVT = "events", EVTR = "events", EVTS = "events",
	SVC = "board", SVCS = "board", MKT = "board",
	POLL = "poll", POLLS = "poll", POLLX = "poll", VOTE = "poll",
	ATT = "attune", ATTS = "attune",
	GOAL = "goals", MILES = "goals",
	THX = "thanks", THXS = "thanks",
	PROF = "prof", CREQ = "prof",
	CD = "cooldowns", CDS = "cooldowns",
	RULES = "recruit", RACK = "recruit", RACKS = "recruit", WEL = "recruit",
	AWAY = "away", MENT = "mentor",
	ACT = "times",
	ADDONS = "addons", ADDONSQ = "addons", ADDALL = "addons",
	ONOTE = "lead", ONOTES = "lead", GONE = "lead", PROB = "lead",
	GEAR = "gear", GEARS = "gear",
	ASK = "ask", ASKS = "ask",
}

-- Typ, Daten, Kanal ("GUILD" oder "WHISPER"), Ziel, hohe Priorität
function Comm:Send(msgType, data, channel, target, high)
	-- Testmodus: nichts verlassen lassen
	if ns.Test and ns.Test:Active() then return end
	if not ns.Feature(Comm.FEATURE[msgType]) then return end
	channel = channel or "GUILD"
	if channel == "GUILD" and not IsInGuild() then return end
	if channel == "CHANNEL" and (not target or not Comm.channelTypes[msgType]) then return end
	if channel == "WHISPER" and (not target or target == "") then return end
	local payload = msgType .. "\t" .. Comm.Serialize(data or {})
	if #payload <= MAX_LEN then
		Enqueue(payload, channel, target, high)
		return
	end
	counter = counter + 1
	local id = tostring(counter) .. tostring(math.random(100, 999))
	local total = math.ceil(#payload / CHUNK)
	for i = 1, total do
		Enqueue("~M\t" .. id .. "\t" .. i .. "\t" .. total .. "\t" .. payload:sub((i - 1) * CHUNK + 1, i * CHUNK), channel, target, high)
	end
end

function Comm:Register(msgType, fn)
	self.handlers[msgType] = fn
end

function Comm:Pending()
	return #queueHigh + #queueLow
end

------------------------------------------------------------
-- Empfangen
------------------------------------------------------------
local parts = {}     -- [Absender..id] = { total, got, t, [i] = Text }

local function Dispatch(sender, payload, channel)
	local msgType, body = payload:match("^([^\t]+)\t(.*)$")
	if not msgType then return end
	local fn = Comm.handlers[msgType]
	if not fn then return end
	if not ns.Feature(Comm.FEATURE[msgType]) then return end
	if ns.Test and ns.Test:Active() then return end
	if channel == "CHANNEL" and not Comm.channelTypes[msgType] then return end
	local data = Comm.Deserialize(body)
	if type(data) ~= "table" then return end
	if channel ~= "CHANNEL" then Comm:Seen(sender) end
	local ok, err = pcall(fn, sender, data, channel)
	if not ok and ns.debug then ns:Print("|cffff4040" .. msgType .. ":|r " .. tostring(err)) end
end

ns:On("CHAT_MSG_ADDON", function(prefix, msg, channel, sender)
	if prefix ~= Comm.PREFIX or type(msg) ~= "string" then return end
	sender = ns.Short(sender)
	if not sender or sender == ns.Me() then return end
	if channel ~= "GUILD" and channel ~= "WHISPER" and channel ~= "CHANNEL" then return end
	if msg:sub(1, 3) == "~M\t" then
		local id, i, total, chunk = msg:match("^~M\t([^\t]+)\t(%d+)\t(%d+)\t(.*)$")
		i, total = tonumber(i), tonumber(total)
		if not id or not i or not total or total > 400 then return end
		local key = sender .. id
		local p = parts[key]
		if not p then
			p = { total = total, got = 0, t = GetTime() }
			parts[key] = p
		end
		if not p[i] then
			p[i] = chunk
			p.got = p.got + 1
		end
		if p.got >= p.total then
			parts[key] = nil
			local full = {}
			for k = 1, p.total do full[k] = p[k] or "" end
			Dispatch(sender, table.concat(full), channel)
		end
		return
	end
	Dispatch(sender, msg, channel)
end)

-- alte, unvollständige Teile aufräumen
C_Timer.NewTicker(60, function()
	local now = GetTime()
	for k, p in pairs(parts) do
		if now - p.t > 120 then parts[k] = nil end
	end
end)

------------------------------------------------------------
-- Wer nutzt GuildSentinel? (Version)
------------------------------------------------------------
function Comm:Setup()
	if ns.RegisterPrefix then ns.RegisterPrefix(self.PREFIX) end
end

function Comm:Seen(name, v)
	self.users[name] = self.users[name] or {}
	if v then self.users[name].v = v end
	self.users[name].t = ns.Now()
end

Comm:Register("HI", function(sender, d, channel)
	Comm:Seen(sender, d.v)
	if channel == "GUILD" then
		-- kurz antworten, damit der Neue weiß, wer das Addon hat
		C_Timer.After(math.random(1, 8), function() Comm:Send("VER", { v = ns.version }, "WHISPER", sender) end)
	end
	ns:Fire("GS_USERS")
end)

Comm:Register("VER", function(sender, d)
	Comm:Seen(sender, d.v)
	ns:Fire("GS_USERS")
end)

ns:Listen("GS_LOGIN", function()
	if not IsInGuild() then return end
	C_Timer.After(12, function() Comm:Send("HI", { v = ns.version }) end)
end)

-- neuere Version unterwegs?
function Comm:NewestVersion()
	local best = ns.version
	local function num(v)
		local a, b, c = tostring(v):match("(%d+)%.(%d+)%.?(%d*)")
		return (tonumber(a) or 0) * 10000 + (tonumber(b) or 0) * 100 + (tonumber(c) or 0)
	end
	for _, u in pairs(self.users) do
		if u.v and num(u.v) > num(best) then best = u.v end
	end
	return best, num(best) > num(ns.version)
end

------------------------------------------------------------
-- Nur einer macht es: Ansagen im Gildenchat (Meilensteine, Jubiläen ...)
-- Alle Addon-Nutzer sehen dasselbe Ereignis. Jeder wartet kurz; wer zuerst "ich mach's" (CLM) schickt,
-- sagt an. Kommen zwei Ansprüche gleichzeitig, gewinnt der alphabetisch erste Name.
------------------------------------------------------------
Comm.claims = {}     -- [Schlüssel] = { t = GetTime(), by = Name }
Comm.CLAIM_TTL = 300

Comm:Register("CLM", function(sender, d)
	if type(d.k) ~= "string" then return end
	local c = Comm.claims[d.k]
	if not c or GetTime() - c.t > Comm.CLAIM_TTL or sender < c.by then
		Comm.claims[d.k] = { t = GetTime(), by = sender }
	end
	ns:Fire("GS_CLAIM", d.k, sender)
end)

function ns.Claim(key, fn, maxDelay)
	C_Timer.After(0.5 + math.random() * (maxDelay or 4), function()
		local c = Comm.claims[key]
		if c and GetTime() - c.t < Comm.CLAIM_TTL then return end
		Comm.claims[key] = { t = GetTime(), by = ns.Me() }
		Comm:Send("CLM", { k = key }, "GUILD", nil, true)
		C_Timer.After(2, function()
			local c2 = Comm.claims[key]
			if c2 and c2.by ~= ns.Me() then return end
			fn()
		end)
	end)
end

-- Text in den Gildenchat
function ns.Announce(text)
	text = ns.Trim(text)
	if text == "" or not IsInGuild() then return end
	if #text > 255 then text = text:sub(1, 252) .. "..." end
	ns.Chat(text, "GUILD")
end
