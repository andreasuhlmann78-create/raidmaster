# LevelPilot Data

Optionales Datenpaket für das Addon **LevelPilot**. Es enthält die Classic-Questdaten
(Quests, Questgeber, Ziele, Fundorte, Händler, Flugmeister sowie die Dungeon-Eingänge und
welche Quests in welchem Dungeon erledigt werden) für Stufe 1–60, umgerechnet
auf die Karten von WoW Forever. Ist es installiert, kennt LevelPilot vom ersten Login an alle
Classic-Quests.

Die neuen Quests von WoW Forever sind hier **nicht** enthalten – die lernt LevelPilot beim
Spielen und über seine eigene Datenbank.

## Namen in allen Sprachen (seit 1.5.0, ab 1.6.0 im Datenpaket selbst)
Die Dateien `Data/Names_deDE.lua`, `_frFR`, `_esES`, `_esMX`, `_ptBR`, `_ruRU`, `_koKR`, `_zhCN` und `_zhTW`
enthalten die Namen von Quests, NPCs, Gegenständen, Objekten und Zonen in der jeweiligen Sprache.
Die Daten liegen in Funktionen; LevelPilot baut nur die Sprachen auf, die gebraucht werden
(eingestellte Sprache und Sprache des Spiels).
- Quelle: [QuestieDB](https://github.com/Questie/QuestieDB), Ordner `l10n/Forever` (fehlende Einträge aus
  `l10n/Classic`) und die Zonen-Übersetzungen von Questie, **GNU GPL v3**.
- Generator: `Tools/gen_names.lua`. Italienisch gibt es bei Questie nicht, dort zeigt LevelPilot die
  englischen Namen aus diesem Paket.

## Herkunft und Lizenz
- Quelle: [Questie](https://github.com/Questie/Questie), Version v11.38.0
  (Commit `454b9d072965ee8f1a881429260fcf1fac8d60f7`), veröffentlicht unter der
  **GNU General Public License v3**.
- Änderungen: Questies Korrekturen und Sperrlisten angewendet, Dungeon-Zuordnung je Quest
  ergänzt, Quest-EP (Questie-EP-Tabelle), Elite-Rang der Gegner, Quest-Art (Elite/Eskorte) und
  Geländekarten je Zone (aus allen Spawnpunkten und Patrouillenwegen) (aus Questies Zonenangabe bzw. den Fundorten der Questziele), auf die für LevelPilot nötigen
  Felder gekürzt, eigenes kompaktes Format, Koordinaten für Mulgore, Östliche Pestländer,
  Rotkammgebirge und Sturmwind auf die geänderten Forever-Karten umgerechnet. 1.6.1: Orte von NPC 10666 (Tirisfal)
  und 10881 (Thunder Bluff) nach den im Spiel gemessenen Orten auf WoW Forever korrigiert.
- Dieses Paket steht unter der **GNU GPL v3** (`LICENSE.txt`). Du darfst es nutzen,
  weitergeben und verändern, solange es unter derselben Lizenz bleibt.
- Quelltext: Die Datendateien in `Data\` sind lesbarer Lua-Code. Der Generator, mit dem sie
  aus Questie erzeugt wurden, liegt in `Tools\`.

LevelPilot Data ist ein eigenständiges Addon und kein offizielles Produkt des Questie-Teams.
