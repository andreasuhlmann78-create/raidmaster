-- LevelPilot Data
-- Copyright (C) 2026 GoldSentinel
-- Die enthaltenen Daten stammen aus Questie (https://github.com/Questie/Questie), Version v11.38.0,
-- und wurden fuer LevelPilot gekuerzt, umgeformt und auf WoW-Forever-Koordinaten umgerechnet.
--
-- This program is free software: you can redistribute it and/or modify it under the terms of the
-- GNU General Public License as published by the Free Software Foundation, either version 3 of the
-- License, or (at your option) any later version. This program is distributed in the hope that it
-- will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
-- FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details
-- (LICENSE.txt).
--
-- Datenformat (oeffentlich, damit auch andere Addons es nutzen koennen):
--   LevelPilotData.Q[questID] = { n=Name, l=Questlevel, rl=Mindestlevel, r=Volksmaske, c=Klassenmaske,
--       sn/so/si = Start bei NPCs/Objekten/Gegenstand, en/eo = Abgabe bei NPCs/Objekten,
--       ob = { k={{npc,text}}, o={{objekt,text}}, i={{gegenstand,text}}, c={{{npcs},text}}, e={text,orte} },
--       pg/ps = Vorquests (alle/eine), ex = schliesst aus, nx = Folgequest, pa = Elternquest,
--       sf = Sonderflags (1 = wiederholbar), sk = Beruf, rp = Ruf, d = Beschreibung,
--       z = Dungeon (AreaID aus D), wenn die Quest in einer Instanz erledigt wird,
--       x = Quest-EP (Grundwert), tg = Quest-Art (1 Elite, 81 Dungeon, 84 Eskorte, ...), es = Eskorte,
--       su = Gegenstand vom Questgeber, rs = benoetigte Gegenstaende (oft zum Benutzen) }
--   LevelPilotData.N[npcID] = { n=Name, s={{uiMapID, x, y, x, y, ...}}, f="A"/"H"/"AH",
--       v=Dienste (1 Haendler, 2 Reparatur, 4 Flugmeister, 8 Gasthaus, 16 Trainer, 32 Bank, 64 Auktionshaus),
--       sb = Titel des Trainers (z.B. "Warrior Trainer"), lo/hi = Level,
--       rk = Rang (1 Elite, 2 seltene Elite, 3 Boss, 4 selten) }
--   LevelPilotData.O[objektID] = { n=Name, s={{uiMapID, x, y, ...}} }
--   LevelPilotData.I[gegenstandID] = { n=Name, dn={npcs}, dob={objekte} }
--   LevelPilotData.F[Fraktion].q[questID] = Abweichungen je Fraktion
--   LevelPilotData.D[areaID] = { n=Name, e={{uiMapID, x, y}, ...} }  Dungeon-Eingaenge
--   LevelPilotData.MB = { {uiMapID, x, y}, ... }  Briefkaesten
--   LevelPilotData.T[uiMapID] = Gelaendekarte TG x TG (Standard 100), 2 Bit je Zelle, 3 Zellen je
--       Base64-Zeichen, zeilenweise: 0 unbekannt, 1 begehbar (Spawnpunkte), 2 Strasse (Patrouillenwege)
--   Koordinaten: WoW-Forever-Kartenkoordinaten (0-100) der jeweiligen uiMapID.

LevelPilotData = {
    version = "1.6.1",
    format  = 1,
    source  = "Questie v11.38.0 (GPLv3)",
    license = "GNU GPL v3",
    Q = {}, N = {}, O = {}, I = {}, F = {}, D = {}, T = {}, MB = {},
}
