-- LevelPilot - Measure (/lp messen)
-- Messroutine fuer die Test-Umgebung: liest im Stehen alles aus dem echten Spiel, was sich ohne Bewegung
-- pruefen laesst, und zeigt es als Text zum Kopieren. Nur lesen: schreibt nichts, aendert nichts, sendet nichts.
-- Die Ausgabe ist ein Entwickler-Bericht (fest auf Deutsch, wie Protokoll-Eintraege fuer GoldSentinel).

local _, LP = ...
local L = LP.L
local M = {}
LP:RegisterModule("Measure", M)

-- Karten, deren Daten die Test-Umgebung nachbildet: Kalimdor- und Oestliche-Koenigreiche-Zonen (Classic 1411-1458),
-- die beiden Kontinente und die Flugkarte
local MAPS = { 1414, 1415, 1464 }
for id = 1411, 1458 do MAPS[#MAPS + 1] = id end

local function F(v, d)
    if v == nil then return "-" end
    if type(v) == "number" then
        if not d and v == math.floor(v) then return string.format("%d", v) end
        return string.format("%." .. (d or 1) .. "f", v)
    end
    return tostring(v)
end

local function NpcId(guid)
    if not guid then return nil end
    -- Creature-0-[Server]-[Instanz]-[Zone]-[NPC-ID]-[Spawn]
    local kind, id = guid:match("^(%a+)%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")
    if kind ~= "Creature" and kind ~= "Vehicle" then return nil end
    return tonumber(id)
end

local function PackNpc(id)
    local N = LevelPilotData and LevelPilotData.N
    return id and N and N[id]
end

-- ein Gegner (Ziel oder Namensplakette): echtes Level gegen Datenpaket
local function UnitLine(unit)
    if not LP.SafeValue(UnitExists(unit)) or LP.SafeValue(UnitIsPlayer(unit)) then return nil end
    local id = NpcId(LP.SafeValue(UnitGUID(unit)))
    local lv = LP.SafeValue(UnitLevel(unit))
    local cls = UnitClassification and LP.SafeValue(UnitClassification(unit)) or "?"
    local hostile = UnitCanAttack and LP.SafeValue(UnitCanAttack("player", unit)) and "feindlich" or "freundlich"
    local npc = PackNpc(id)
    local pack = "nicht im Datenpaket"
    if npc then
        pack = string.format("Paket %s-%s rk=%s f=%s", F(npc.lo, 0), F(npc.hi or npc.lo, 0), F(npc.rk, 0), npc.f and npc.f ~= "" and npc.f or "-")
        local dl = LP.Danger and LP.Danger:MobLevel(npc, id)
        pack = pack .. " Gefahrwert=" .. F(dl, 0)
    end
    local diff = ""
    if npc and npc.lo and lv and lv > 0 then
        local hi = npc.hi or npc.lo
        if lv < npc.lo or lv > hi then diff = " ABWEICHUNG" end
    end
    return string.format("  %s (npc %s) L%s %s %s · %s%s", LP.SafeValue(UnitName(unit)) or "?", F(id, 0), F(lv, 0), cls, hostile, pack, diff)
end

M.UnitLine = UnitLine          -- Testroutine

function M:Text()
    local out = {}
    local function W(s, ...) out[#out + 1] = select("#", ...) > 0 and string.format(s, ...) or s end
    local Geo, D, P = LP.Geo, LP.Danger, LP.Planner
    local level = LP:PlayerLevel() or UnitLevel("player") or 1

    W("LevelPilot – Messung · v%s · %s", LP.version, date("%d.%m.%Y %H:%M"))
    local ver, build, _, toc = GetBuildInfo()
    W("Client %s (%s, toc %s) · WoW Forever: %s · Datenpaket: %s", F(ver), F(build), F(toc),
        LP.API.Forever() and "ja" or "nein", LevelPilotData and "geladen" or "FEHLT")
    if LP.Game then W(LP.Game.Status()) end
    W("Testmodus: %s · BattleTag vom Spiel geliefert: %s", LP:IsDev() and "an" or "aus", LP.devTagSeen and "ja" or "nein")
    if LP.Virtual and LP.Virtual.active then W("ACHTUNG: virtuelle Reise läuft – Messung zeigt die echten Daten, Route ist die der Reise") end

    -- Spieler
    W("")
    W("== Spieler")
    local _, race = UnitRace("player")
    local _, class = UnitClass("player")
    local xp, xpMax = LP:PlayerXP()
    local rested = GetXPExhaustion and LP.SafeValue(GetXPExhaustion()) or 0
    W("%s %s L%d · EP %d/%d · erholt %d · Fraktion %s", F(race), F(class), level, xp or 0, xpMax or 0, rested or 0, F(UnitFactionGroup("player")))
    local inst, n, w, map, x, y = Geo:Player()
    W("Position: Karte %s (%s) %s / %s · Welt inst %s n %s w %s", F(map), F(map and Geo:MapName(map)), F(x, 2), F(y, 2), F(inst, 0), F(n, 0), F(w, 0))
    W("Zone: %s · Unterzone: %s · echte Zone: %s", F(GetZoneText()), F(GetSubZoneText()), F(GetRealZoneText()))
    W("Grüne Spanne: %s · Bewegung: %s", F(LP.API.GreenRange(level), 0), (GetUnitSpeed and F(GetUnitSpeed("player"), 1)) or "-")

    -- Gefahr am Standort
    W("")
    W("== Gefahrenkarte (Pflichtregel Mobs >= Level + %d)", D and D.MAX_DIFF or 3)
    if D and inst then
        local v = D:At(inst, n, w)
        W("Hier: höchstes Mob-Level %s (Grenze %d) %s", v == D.TOWN and "Ort der anderen Fraktion" or F(v, 0), D:Limit(level), D:OK(v, level) and "(OK)" or "ZU STARK")
        local gi, gn, gw, glv = D:GrindSpot(inst, n, w, level)
        if gi then W("Grind-Platz: %d Yards entfernt, Mob-Level %d", math.floor(Geo:Dist(n, w, gn, gw) + 0.5), glv)
        else W("Grind-Platz: keiner im Umkreis von 1500 Yards") end
    else
        W("keine Position oder Gefahrenkarte")
    end

    -- Ziel und Namensplaketten: echtes Mob-Level gegen das Datenpaket
    W("")
    W("== Gegner in Sichtweite (echt gegen Datenpaket)")
    local seen, cnt = {}, 0
    local tl = UnitLine("target")
    if tl then W("Ziel:") W(tl) seen[LP.SafeValue(UnitGUID("target")) or ""] = true end
    if C_NamePlate and C_NamePlate.GetNamePlates then
        for _, plate in ipairs(C_NamePlate.GetNamePlates() or {}) do
            local unit = plate.namePlateUnitToken or (plate.UnitFrame and plate.UnitFrame.unit)
            local g = unit and LP.SafeValue(UnitGUID(unit))
            if g and not seen[g] and cnt < 15 then
                local line = UnitLine(unit)
                if line then
                    if cnt == 0 then W("Namensplaketten:") end
                    W(line) cnt = cnt + 1
                end
                seen[g] = true
            end
        end
    end
    if not tl and cnt == 0 then W("keine (Tipp: Namensplaketten mit V einschalten oder einen Gegner anklicken)") end

    -- Questlog
    W("")
    W("== Questlog")
    local quests = LP.API.Quests()
    W("%d Quests", #quests)
    for _, e in ipairs(quests) do
        local q = LP.QuestDB and LP.QuestDB:Get(e.id)
        local mob = q and P.QuestMobLevel and P.QuestMobLevel(q)
        W("[%d] %s L%s%s · Paket: %s · Mob-Level %s%s", e.id, e.title or "?", F(e.level, 0),
            e.complete and " fertig" or (e.failed and " gescheitert" or ""),
            q and ("L" .. F(q.level, 0) .. " EP " .. F(q.xp, 0)) or "FEHLT",
            F(mob, 0), mob and D and not D:OK(mob, level) and " ZU STARK" or "")
        for oi, o in ipairs(LP.API.Objectives(e.index) or {}) do
            local po = q and q.objectives and q.objectives[oi]
            W("    %s %s/%s %s%s", o.finished and "(OK)" or "-", F(o.have, 0), F(o.need, 0), F(o.text),
                po and string.format(" · Paket: %s%s", F(po.kind), po.mobLevel and (" Mob L" .. po.mobLevel .. (po.elite and " Elite" or "")) or "") or "")
        end
    end

    -- Route
    W("")
    W("== Route (erste 10 Schritte)")
    local steps = P.steps or {}
    for i = 1, math.min(10, #steps) do
        local s = steps[i]
        local txt = LP.UI and LP.UI.StepText and LP.UI:StepText(s) or (s.text or "")
        txt = tostring(txt):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("\n", " ")
        local dv = D and s.map and s.x and D:AtMap(s.map, s.x, s.y)
        -- der Schritttext enthaelt schon die Entfernung (beim ersten Schritt die Weglaenge)
        W("%d. %s %s · Karte %s %s/%s · Gefahr %s", i, F(s.t), txt, F(s.map), F(s.x, 1), F(s.y, 1), F(dv, 0))
    end
    if #steps == 0 then W("keine Schritte") end
    local skip, ns = {}, 0
    for id, lv in pairs(P.mobSkip or {}) do ns = ns + 1 if ns <= 20 then skip[#skip + 1] = id .. "(L" .. tostring(lv) .. ")" end end
    W("Wegen Mob-Regel zurückgestellt: %d %s", ns, table.concat(skip, " "))
    local ms = P.mobStats or {}
    W("Zähler: Quest %d · Orte %d · Annahme %d · Route %d · Weg %d · Abgabe %d", ms.quest or 0, ms.spots or 0, ms.accept or 0, ms.route or 0, ms.path or 0, ms.turnin or 0)

    -- Ignoriert / zurueckgestellt
    local ig = {}
    for id in pairs(LP.char and LP.char.ignored or {}) do ig[#ig + 1] = tostring(id) end
    table.sort(ig)
    W("Ignoriert: %d %s", #ig, table.concat(ig, " "))

    -- Flugpunkte
    W("")
    W("== Flugpunkte")
    local ok, all = Geo:TaxiUsable()
    W("%d bekannt, %d verortet", all, ok)
    local taxi = (LP.Virtual and LP.Virtual.RealTaxi and LP.Virtual:RealTaxi()) or (LP.db and LP.db.taxi) or {}
    local names = {}
    for k in pairs(taxi) do names[#names + 1] = k end
    table.sort(names)
    for _, k in ipairs(names) do
        local tx = taxi[k]
        if type(tx) == "table" then
            local zm, zx, zy = Geo:TaxiPoint(tx)
            W("  %s · Flugkarte %s %s/%s · Zone %s (%s) %s/%s", k, F(tx.map), F(tx.x, 1), F(tx.y, 1), F(zm), F(zm and Geo:MapName(zm)), F(zx, 1), F(zy, 1))
        end
    end

    -- Karten
    W("")
    W("== Karten (Name · Typ · Eltern · Grenzen)")
    local bad = 0
    for _, id in ipairs(MAPS) do
        local info = C_Map.GetMapInfo(id)
        local b = Geo:Bounds(id)
        if info then
            W("  %d %s · %s · %s · %s", id, F(info.name), F(info.mapType, 0), F(info.parentMapID, 0),
                b and string.format("inst %d %.0f/%.0f-%.0f/%.0f", b.inst, b.top, b.left, b.bottom, b.right) or "KEINE")
            if not b and id ~= 1464 then bad = bad + 1 end
        end
    end
    W("Karten ohne Grenzen (ohne Flugkarte): %d", bad)

    -- Ruhestein
    W("")
    W("== Ruhestein")
    local bind = LP.char and LP.char.bind
    W("Gebunden: %s · gespeichert: %s · Abklingzeit %s s · Stein im Gepäck: %s",
        F(GetBindLocation and GetBindLocation()), bind and string.format("%s %s/%s", F(bind.map), F(bind.x, 1), F(bind.y, 1)) or "-",
        F(LP.API.ItemCooldown(LP.API.HEARTHSTONE), 0), LP.API.ItemCount(LP.API.HEARTHSTONE) > 0 and "ja" or "nein")

    -- Lernwerte
    W("")
    W("== Gelernte Werte")
    if LP.Calib then
        W(LP.Calib:StatusText())
        W(LP.Calib:FlightText())
        W(LP.Calib:LearnText())
    end
    local lt = (LP.Virtual and LP.Virtual:RealChar() or LP.char or {}).levelTimes or {}
    local row = {}
    for l = 1, 60 do if lt[l] then row[#row + 1] = string.format("L%d %dm", l, math.floor(lt[l] / 60 + 0.5)) end end
    W("Level-Zeiten: %s", #row > 0 and table.concat(row, " · ") or "-")

    return (table.concat(out, "\n"):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
end

function M:Show()
    local ok, text = pcall(self.Text, self)
    if not ok then text = "LevelPilot – Messung: Fehler\n" .. tostring(text) end
    LP.Backup:ShowText(L["LevelPilot – Messung"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."], text)
end
