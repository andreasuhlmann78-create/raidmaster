-- LevelPilot - Namen aus dem Spiel in der eingestellten Sprache
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Quest-, NPC-, Gegenstands-, Objekt- und Zonennamen kommen sonst aus dem Spiel (Sprache des Clients)
-- oder aus dem Datenpaket (Englisch). Mit den Sprachpaketen LevelPilot_Data_<Sprache> (Uebersetzungen
-- aus QuestieDB, GPLv3) zeigt LevelPilot sie in der eingestellten Sprache. Die Pakete werden nur bei
-- Bedarf geladen: fuer die eingestellte Sprache und fuer die Sprache des Spiels (Ziel-Makros brauchen
-- die Namen so, wie das Spiel sie kennt).
-- Englisch: Namen aus dem Datenpaket. Italienisch: keine Questie-Daten, daher Englisch.

local _, LP = ...
local L = LP.L
local Nm = {}
LP:RegisterModule("Names", Nm)

local LOCALE_OF = { de = "deDE", fr = "frFR", es = "esES", mx = "esMX", pt = "ptBR", ru = "ruRU",
                    ko = "koKR", cn = "zhCN", tw = "zhTW" }
Nm.LOCALE_OF = LOCALE_OF

-- englische Zonennamen (uiMapID) fuer Englisch und Italienisch
local ZONE_EN = {
    [1411] = "Durotar", [1412] = "Mulgore", [1413] = "The Barrens", [1416] = "Alterac Mountains",
    [1417] = "Arathi Highlands", [1418] = "Badlands", [1419] = "Blasted Lands", [1420] = "Tirisfal Glades",
    [1421] = "Silverpine Forest", [1422] = "Western Plaguelands", [1423] = "Eastern Plaguelands",
    [1424] = "Hillsbrad Foothills", [1425] = "The Hinterlands", [1426] = "Dun Morogh", [1427] = "Searing Gorge",
    [1428] = "Burning Steppes", [1429] = "Elwynn Forest", [1430] = "Deadwind Pass", [1431] = "Duskwood",
    [1432] = "Loch Modan", [1433] = "Redridge Mountains", [1434] = "Stranglethorn Vale", [1435] = "Swamp of Sorrows",
    [1436] = "Westfall", [1437] = "Wetlands", [1438] = "Teldrassil", [1439] = "Darkshore", [1440] = "Ashenvale",
    [1441] = "Thousand Needles", [1442] = "Stonetalon Mountains", [1443] = "Desolace", [1444] = "Feralas",
    [1445] = "Dustwallow Marsh", [1446] = "Tanaris", [1447] = "Azshara", [1448] = "Felwood", [1449] = "Un'Goro Crater",
    [1450] = "Moonglade", [1451] = "Silithus", [1452] = "Winterspring", [1453] = "Stormwind City",
    [1454] = "Orgrimmar", [1455] = "Ironforge", [1456] = "Thunder Bluff", [1457] = "Darnassus", [1458] = "Undercity",
}
Nm.ZONE_EN = ZONE_EN

local tried = {}
Nm.status = {}          -- [Sprachcode des Spiels] = "geladen" oder Grund, warum es fehlt
local warned = {}

-- Namen einer Sprache bereitstellen (einmal je Sitzung); true = Daten vorhanden.
-- 1) im Datenpaket LevelPilot_Data (ab 1.6.0): Daten liegen in einer Funktion und werden erst jetzt aufgebaut
-- 2) aeltere Sprach-Addons LevelPilot_Data_<Sprache> (1.5.0), falls noch vorhanden
function Nm:Load(lang)
    local loc = LOCALE_OF[lang]
    if not loc then return false end
    _G.LevelPilotNames = _G.LevelPilotNames or {}
    local all = _G.LevelPilotNames
    if all[loc] then self.status[loc] = "ok" return true end
    if not tried[loc] then
        tried[loc] = true
        local loader = type(_G.LevelPilotNamesLoad) == "table" and _G.LevelPilotNamesLoad[loc]
        if type(loader) == "function" then
            local ok, d = pcall(loader)
            if ok and type(d) == "table" then all[loc] = d end
            _G.LevelPilotNamesLoad[loc] = nil          -- Funktion freigeben, die Tabelle bleibt
        end
        if not all[loc] then
            local load = (C_AddOns and C_AddOns.LoadAddOn) or LoadAddOn
            if load then pcall(load, "LevelPilot_Data_" .. loc) end
        end
        self.status[loc] = all[loc] and "ok" or (_G.LevelPilotData and "OLD_DATA" or "NO_DATA")
    end
    local ok = all[loc] ~= nil
    -- nur melden, wenn die Namen sonst sichtbar in der falschen Sprache stuenden
    if not ok and not warned[loc] and lang == LP:Language() and lang ~= LP:ClientLanguage() then
        warned[loc] = true
        LP:Print(L("Namen auf %s fehlen – bitte das Datenpaket LevelPilot_Data aus der aktuellen LevelPilot.zip installieren.", loc))
        if LP.Protocol then pcall(LP.Protocol.Add, LP.Protocol, "error", "Namen " .. loc .. ": " .. tostring(self.status[loc])) end
    end
    return ok
end

-- Zustand fuer die Diagnose
function Nm:StatusText()
    local parts = {}
    for _, lang in ipairs({ LP:Language(), LP:ClientLanguage() }) do
        local loc = LOCALE_OF[lang]
        if loc and not parts[loc] then
            self:Load(lang)
            parts[loc] = true
            parts[#parts + 1] = loc .. " " .. (self.status[loc] == "ok" and L["geladen"] or tostring(self.status[loc]))
        end
    end
    if #parts == 0 then return L["nicht nötig (Englisch)"] end
    return table.concat(parts, ", ")
end

function Nm:Available(lang)
    return lang == "en" or lang == "it" or self:Load(lang)
end

local function Pack(kind, id)
    local d = _G.LevelPilotData
    local t = type(d) == "table" and d[kind]
    local e = t and t[id]
    return e and e.n or nil
end

-- Name in einer Sprache (Standard: eingestellte Sprache); nil = unbekannt
function Nm:Get(kind, id, lang)
    if not id then return nil end
    lang = lang or LP:Language()
    if lang == "en" or lang == "it" then
        if kind == "Z" then return ZONE_EN[id] end
        return Pack(kind, id)
    end
    if not self:Load(lang) then return nil end
    local d = _G.LevelPilotNames[LOCALE_OF[lang]]
    return d and d[kind] and d[kind][id] or nil
end

function Nm:Quest(id, lang) return self:Get("Q", id, lang) end
function Nm:Npc(id, lang) return self:Get("N", id, lang) end
function Nm:Item(id, lang) return self:Get("I", id, lang) end
function Nm:Object(id, lang) return self:Get("O", id, lang) end

-- Name, wie ihn das Spiel kennt (fuer /targetexact): Sprache des Clients
function Nm:NpcClient(id) return self:Get("N", id, LP:ClientLanguage()) end

-- Zonenname nur, wenn die eingestellte Sprache nicht die des Spiels ist (sonst kennt das Spiel ihn selbst)
function Nm:Zone(map)
    if LP:Language() == LP:ClientLanguage() then return nil end
    return self:Get("Z", map)
end

-- Eingestellte Sprache weicht von der des Spiels ab?
function Nm:Foreign() return LP:Language() ~= LP:ClientLanguage() end

------------------------------------------------------------------------
-- Questziele im Questlog in der eingestellten Sprache
------------------------------------------------------------------------
local KIND_TYPE = { kill = "monster", item = "item", object = "object", explore = "event" }

-- Ziel der Daten -> Ziel des Spiels (gleiche Art der Reihe nach); fehlt die Art, nach Position
function Nm.ClientIndex(q, objs)
    local byType, out = {}, {}
    for oi, o in ipairs(objs) do
        if o.type then
            byType[o.type] = byType[o.type] or {}
            table.insert(byType[o.type], oi)
        end
    end
    local count = {}
    for di, o in ipairs(q.objectives or {}) do
        local t = KIND_TYPE[o.kind]
        if t and byType[t] then
            count[t] = (count[t] or 0) + 1
            out[di] = byType[t][count[t]]
        elseif #objs == #(q.objectives or {}) then
            out[di] = di
        end
    end
    return out
end

-- Anzeigetexte der Ziele einer Quest im Log: { [Index im Spiel] = Text }
function Nm:ObjectiveTexts(questID, objs)
    local out = {}
    if not self:Foreign() then return out end
    local q = LP.QuestDB and LP.QuestDB:Get(questID)
    if not q then return out end
    local map = Nm.ClientIndex(q, objs)
    for di, o in ipairs(q.objectives or {}) do
        local ci = map[di]
        local ob = ci and objs[ci]
        if ob and ob.need and ob.need > 0 then
            local name
            if o.kind == "item" then name = self:Item(o.item)
            elseif o.kind == "kill" and o.ids and #o.ids == 1 then name = self:Npc(o.ids[1])
            elseif o.kind == "object" and o.objId then name = self:Object(o.objId) end
            if name then
                if o.kind == "kill" then out[ci] = L("%s getötet: %d/%d", name, ob.have or 0, ob.need)
                else out[ci] = string.format("%s: %d/%d", name, ob.have or 0, ob.need) end
            end
        end
    end
    return out
end

------------------------------------------------------------------------
-- Sprachwechsel
------------------------------------------------------------------------
function Nm:LanguageChanged()
    self:Load(LP:Language())
    if LP.Geo and LP.Geo.ResetNames then LP.Geo:ResetNames() end
    if LP.QuestDB then
        LP.QuestDB:Invalidate()
        if LP.QuestDB.InvalidateServices then LP.QuestDB:InvalidateServices() end
        if LP.QuestDB.ResetItemIndex then LP.QuestDB:ResetItemIndex() end
    end
    if LP.Nav and LP.Nav.ResetNames then LP.Nav:ResetNames() end
    if LP.Plates and LP.Plates.Refresh then pcall(LP.Plates.Refresh, LP.Plates) end
    if LP.Pins and LP.Pins.Refresh then pcall(LP.Pins.Refresh, LP.Pins) end
end

function Nm:Init()
    self:Load(LP:Language())
    self:Load(LP:ClientLanguage())
    -- Sprachen, die dieses Spiel nicht anzeigen kann (Schrift fehlt), werden nie gebraucht: Speicher freigeben
    local loaders = _G.LevelPilotNamesLoad
    if type(loaders) == "table" then
        for code, loc in pairs(LOCALE_OF) do
            if loaders[loc] and not LP:CanDisplay(code) then loaders[loc] = nil end
        end
        pcall(collectgarbage, "step", 2000)
    end
end
