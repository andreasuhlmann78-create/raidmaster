-- LevelPilot - Aktionsleiste
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Zwei sichere Knoepfe (auch im Kampf benutzbar, auf Tasten legbar):
--   Ziel anvisieren   Makro, das die Questgegner bzw. den Questgeber des aktuellen Schritts
--                     anvisiert und mit einem Totenkopf markiert
--   Gegenstand        benutzt den Questgegenstand des aktuellen Schritts (bzw. den Ruhestein)
-- Sichere Knoepfe duerfen im Kampf nicht veraendert werden: Aenderungen warten bis nach dem Kampf.

local _, LP = ...
local L = LP.L
local A = {}
LP:RegisterModule("Actions", A)

local SIZE = 34
local bar, btnTarget, btnItem
local pending = false
A.state = { targets = {}, item = nil }

BINDING_HEADER_LEVELPILOT = "LevelPilot"
_G["BINDING_NAME_CLICK LevelPilotTargetButton:LeftButton"] = L["Questziel anvisieren"]
_G["BINDING_NAME_CLICK LevelPilotItemButton:LeftButton"] = L["Questgegenstand benutzen"]

------------------------------------------------------------------------
-- Was soll anvisiert / benutzt werden?
------------------------------------------------------------------------
local function TargetsFor(step)
    local names, seen = {}, {}
    local function add(n)
        if n and n ~= "" and not seen[n] and #names < 3 then seen[n] = true names[#names + 1] = n end
    end
    if not step then return names end
    if step.t == "COMPLETE" and step.id then
        local q = LP.QuestDB:Get(step.id)
        local st = LP.Planner.inLog[step.id]
        for oi, o in ipairs(q and q.objectives or {}) do
            local idx = o.idx or oi
            if not (st and st.objDone[idx]) then
                for _, m in ipairs(o.mobs or {}) do add(m) end
            end
        end
    elseif step.npc then
        add(step.npc)
    end
    return names
end

local function BagHas(id)
    return id and LP.API.ItemCount(id) > 0
end

local function ItemFor(step)
    if not step then return nil end
    if step.item and BagHas(step.item) then return step.item end
    if step.t ~= "COMPLETE" or not step.id then return nil end
    -- Questgegenstand laut Spiel (falls der Client das anbietet)
    local st = LP.Planner.inLog[step.id]
    if st and GetQuestLogSpecialItemInfo then
        local ok, link = pcall(GetQuestLogSpecialItemInfo, st.index)
        local id = ok and link and tonumber(tostring(link):match("item:(%d+)"))
        if id and BagHas(id) then return id end
    end
    -- laut Questdaten: Gegenstand vom Questgeber oder benoetigter Gegenstand mit Benutzen-Wirkung
    local q = LP.QuestDB:Get(step.id)
    if q then
        local cands = {}
        if q.sourceItem then cands[#cands + 1] = q.sourceItem end
        for _, id in ipairs(q.reqItems or {}) do cands[#cands + 1] = id end
        for _, id in ipairs(cands) do
            if BagHas(id) and LP.API.ItemSpell(id) then return id end
        end
    end
    return nil
end

local function MacroText(names)
    local lines = { "/cleartarget" }
    for _, n in ipairs(names) do lines[#lines + 1] = "/targetexact " .. n end
    lines[#lines + 1] = "/run if UnitExists('target') and not UnitIsDead('target') and not GetRaidTargetIndex('target') then SetRaidTarget('target',8) end"
    local text = table.concat(lines, "\n")
    while #text > 255 and #lines > 3 do
        table.remove(lines, #lines - 1)
        text = table.concat(lines, "\n")
    end
    return text
end
A.MacroText = MacroText

------------------------------------------------------------------------
-- Knoepfe
------------------------------------------------------------------------
local function Tooltip(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    if self == btnTarget then
        GameTooltip:AddLine(L["Questziel anvisieren"], 1, 1, 1)
        for _, n in ipairs(A.state.targets) do GameTooltip:AddLine(n, 0.8, 0.8, 0.8) end
    else
        GameTooltip:AddLine(L["Questgegenstand benutzen"], 1, 1, 1)
        if A.state.item then
            local name = (C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(A.state.item))
                         or (GetItemInfo and GetItemInfo(A.state.item)) or ("#" .. A.state.item)
            GameTooltip:AddLine(name, 0.8, 0.8, 0.8)
        end
    end
    GameTooltip:AddLine(L["Taste festlegen: Optionen » Tastenbelegung » LevelPilot"], 0.6, 0.6, 0.6, true)
    GameTooltip:Show()
end

local function MakeButton(name, icon)
    local b = CreateFrame("Button", name, bar, "SecureActionButtonTemplate")
    b:SetSize(SIZE, SIZE)
    b:RegisterForClicks("AnyUp", "AnyDown")
    local tex = b:CreateTexture(nil, "ARTWORK")
    tex:SetAllPoints()
    tex:SetTexture(icon)
    b.icon = tex
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetTexture("Interface\\Buttons\\ButtonHilight-Square")
    hl:SetBlendMode("ADD")
    b:SetScript("OnEnter", Tooltip)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b.attrs = {}
    return b
end

local function SetAttr(b, k, v)
    b.attrs[k] = v
    b:SetAttribute(k, v)
end

local function Build()
    bar = CreateFrame("Frame", "LevelPilotActionBar", UIParent)
    bar:SetSize(SIZE, SIZE * 2 + 4)
    bar:SetMovable(true)
    bar:EnableMouse(true)
    bar:RegisterForDrag("LeftButton")
    bar:SetClampedToScreen(true)
    bar:SetScript("OnDragStart", function(self) if IsShiftKeyDown() then self:StartMoving() end end)
    bar:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        LP.db.actionPos = { p, rp, x, y }
    end)
    local pos = LP.db.actionPos
    if pos then
        bar:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
    elseif LevelPilotFrame then
        local x, y = LevelPilotFrame:GetRight(), LevelPilotFrame:GetTop()
        if x and y then bar:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", x + 6, y) else bar:SetPoint("CENTER", 300, 0) end
    else
        bar:SetPoint("CENTER", 300, 0)
    end
    btnTarget = MakeButton("LevelPilotTargetButton", "Interface\\Icons\\Ability_Hunter_SniperShot")
    btnTarget:SetPoint("TOP", bar, "TOP", 0, 0)
    SetAttr(btnTarget, "type", "macro")
    btnItem = MakeButton("LevelPilotItemButton", "Interface\\Icons\\INV_Misc_QuestionMark")
    btnItem:SetPoint("TOP", btnTarget, "BOTTOM", 0, -4)
    SetAttr(btnItem, "type", "item")
    A.bar, A.btnTarget, A.btnItem = bar, btnTarget, btnItem
end

A.ItemFor = ItemFor          -- Testroutine

function A:Update()
    if not bar then return end
    if InCombatLockdown() then pending = true return end
    pending = false
    local step = LP.Engine:Current()
    local show = LP.db.showActionBar and LP.UI:IsShown()
    local names = TargetsFor(step)
    local item = ItemFor(step)
    self.state.targets, self.state.item = names, item
    if show and #names > 0 then
        SetAttr(btnTarget, "macrotext", MacroText(names))
        btnTarget:Show()
    else
        btnTarget:Hide()
    end
    if show and item then
        SetAttr(btnItem, "item", "item:" .. item)
        local icon = (C_Item and C_Item.GetItemIconByID and C_Item.GetItemIconByID(item)) or (GetItemIcon and GetItemIcon(item))
        if icon then btnItem.icon:SetTexture(icon) end
        btnItem:Show()
    else
        btnItem:Hide()
    end
    if show and (#names > 0 or item) then bar:Show() else bar:Hide() end
end

function A:Init()
    Build()
    local function soon() LP:Throttle("actions", 0.5, function() A:Update() end) end
    LP:Listen("PLAN_CHANGED", soon)
    LP:On("BAG_UPDATE_DELAYED", soon)
    LP:On("PLAYER_REGEN_ENABLED", function() if pending then A:Update() end end)
    C_Timer.After(2, function() A:Update() end)
end
