-- LevelPilot – Prüfung der Oberfläche im echten Client (Testroutine, Bereich K: T224–T229)
-- Copyright (c) 2026 GoldSentinel. All Rights Reserved.
--
-- Übernommen aus der Vorlage (shared/vorlage/__ADDON__/UICheck.lua, Fälle T18–T23) und an LevelPilot angepasst.
-- Anlass (Live-Test 5. Nov. 2026): eigene Tooltips verdeckten Knöpfe, Fenster lagen übereinander, Anzeigen rechneten
-- mit falschen Spielwerten, ein Fehler kam 588×. Offline sieht man das nicht – darum prüft die Testroutine es im
-- Spiel selbst. Nur lesen, nichts verändern.
--
-- Benutzung:
--   LP.RegisterUI(frame, "Name")                 -- eigenes Fenster anmelden (die bekannten meldet U.Collect an)
--   LP.Plausible("Name", function() return ok, ist, soll end)   -- Spielwert-Prüfung für T228
-- Andere GoldSentinel-Addons melden ihre Fenster in der globalen Liste GoldSentinelUIFrames an (T225 prüft gegeneinander).

local ADDON, LP = ...

LP.uiFrames = LP.uiFrames or {}
LP.plausible = LP.plausible or {}
LP.UI_LOOP_LIMIT = 10                       -- dieselbe Fehlermeldung öfter in einer Sitzung -> Fehlerschleife (T229)

-- Blizzard-Fenster, an die GoldSentinel-Addons andocken (dürfen nicht überdeckt werden)
LP.UI_BLIZZARD = { "ProfessionsFrame", "TradeSkillFrame", "CraftFrame", "MerchantFrame", "AuctionHouseFrame",
                   "AuctionFrame", "MailFrame", "QuestLogFrame", "WorldMapFrame", "CharacterFrame", "GossipFrame", "QuestFrame" }

-- eigene Fenster (global benannt, werden zum Teil erst beim ersten Öffnen gebaut)
local OWN = {
    { "LevelPilotFrame", "Guide" }, { "LevelPilotCenter", "Zentrale" }, { "LevelPilotBackupFrame", "Kopierfenster" },
    { "LevelPilotGroupPanel", "Gruppe" }, { "LevelPilotVirtualFrame", "Virtuelle Reise" },
    { "LevelPilotDonateFrame", "Unterstützen" }, { "LevelPilotStepMenu", "Schritt-Menü" },
    { "LevelPilotActionBar", "Aktionsleiste" }, { "LevelPilotArrow", "Pfeil" },
}

GoldSentinelUIFrames = GoldSentinelUIFrames or {}

function LP.RegisterUI(frame, name)
    if not frame then return end
    for _, e in ipairs(LP.uiFrames) do if e.frame == frame then return end end
    local e = { frame = frame, name = name or (frame.GetName and frame:GetName()) or ADDON }
    LP.uiFrames[#LP.uiFrames + 1] = e
    GoldSentinelUIFrames[#GoldSentinelUIFrames + 1] = { frame = frame, name = e.name, addon = ADDON }
end

function LP.Plausible(name, fn) LP.plausible[#LP.plausible + 1] = { name = name, fn = fn } end

local U = {}
LP.UICheck = U

-- bekannte eigene Fenster anmelden (sobald es sie gibt)
function U.Collect()
    for _, o in ipairs(OWN) do
        local f = _G[o[1]]
        if type(f) == "table" then LP.RegisterUI(f, o[2]) end
    end
end

-- Ist der echte Client da (Rechtecke, Kinder, Tooltip)? Sonst werden die Fälle ehrlich übersprungen.
function U.Available()
    U.Collect()
    local f = LP.uiFrames[1] and LP.uiFrames[1].frame
    if not (f and type(f.GetRect) == "function" and type(f.GetChildren) == "function"
        and type(GameTooltip) == "table" and type(GameTooltip.GetRect) == "function"
        and type(UIParent) == "table" and type(UIParent.GetRect) == "function") then return false end
    local ok, l = pcall(UIParent.GetRect, UIParent)
    return ok and type(l) == "number"
end

function U.Rect(f)
    if not (f and f.GetRect) then return nil end
    local ok, l, b, w, h = pcall(f.GetRect, f)
    if not ok or type(l) ~= "number" or type(w) ~= "number" or w <= 0 or h <= 0 then return nil end
    local s = f.GetEffectiveScale and f:GetEffectiveScale() or 1
    return { l = l * s, b = b * s, r = (l + w) * s, t = (b + h) * s }
end

-- Fläche der Überschneidung (0 = keine). Ein Pixel Rand gilt als "angedockt", nicht als Überlappen.
function U.Overlap(a, c)
    if not (a and c) then return 0 end
    local w = math.min(a.r, c.r) - math.max(a.l, c.l) - 1
    local h = math.min(a.t, c.t) - math.max(a.b, c.b) - 1
    return (w > 0 and h > 0) and w * h or 0
end

local function Shown(f) return f and f.IsVisible and f:IsVisible() and true or false end

local function Name(f)
    local n = f and f.GetName and f:GetName()
    if n then return n end
    local t = f and f.GetText and f:GetText()
    if not t and f and f.label and f.label.GetText then t = f.label:GetText() end
    return t and ("'" .. tostring(t) .. "'") or tostring(f and f.GetObjectType and f:GetObjectType() or "?")
end

-- alle sichtbaren Nachfahren eines Fensters
function U.Descendants(f, out)
    out = out or {}
    if not (f and f.GetChildren) then return out end
    for _, c in ipairs({ f:GetChildren() }) do
        if Shown(c) then out[#out + 1] = c U.Descendants(c, out) end
    end
    return out
end

local function IsControl(f)
    return f.IsObjectType and (f:IsObjectType("Button") or f:IsObjectType("EditBox") or f:IsObjectType("CheckButton")
        or f:IsObjectType("Slider")) and true or false
end

-- T224: kein eigener Tooltip verdeckt einen Knopf desselben Fensters
function U.TooltipsCoverNothing()
    local problems, tested = {}, 0
    for _, e in ipairs(LP.uiFrames) do
        if Shown(e.frame) then
            local all = U.Descendants(e.frame)
            for _, el in ipairs(all) do
                local enter = el.GetScript and el:GetScript("OnEnter")
                if enter then
                    tested = tested + 1
                    pcall(enter, el)
                    local tip = Shown(GameTooltip) and U.Rect(GameTooltip)
                    if tip then
                        for _, other in ipairs(all) do
                            if other ~= el and IsControl(other) and U.Overlap(tip, U.Rect(other)) > 0 then
                                problems[#problems + 1] = e.name .. ": " .. Name(el) .. " verdeckt " .. Name(other)
                                break
                            end
                        end
                    end
                    local leave = el:GetScript("OnLeave")
                    if leave then pcall(leave, el) end
                    if GameTooltip.Hide then GameTooltip:Hide() end
                end
            end
        end
    end
    return problems, tested
end

-- T225: eigene sichtbare Fenster überdecken weder Blizzard-Fenster noch Fenster anderer GoldSentinel-Addons
function U.WindowsOverlapNothing()
    local problems, tested = {}, 0
    for _, e in ipairs(LP.uiFrames) do
        local mine = Shown(e.frame) and U.Rect(e.frame)
        if mine then
            for _, bn in ipairs(LP.UI_BLIZZARD) do
                local bf = _G[bn]
                if Shown(bf) then
                    tested = tested + 1
                    if U.Overlap(mine, U.Rect(bf)) > 0 then problems[#problems + 1] = e.name .. " überdeckt " .. bn end
                end
            end
            for _, o in ipairs(GoldSentinelUIFrames) do
                if o.addon ~= ADDON and Shown(o.frame) then
                    tested = tested + 1
                    if U.Overlap(mine, U.Rect(o.frame)) > 0 then
                        problems[#problems + 1] = e.name .. " überdeckt " .. tostring(o.name) .. " (" .. tostring(o.addon) .. ")"
                    end
                end
            end
        end
    end
    return problems, tested
end

-- T226: sichtbare Fenster liegen ganz im Bildschirm
function U.InsideScreen()
    local problems, tested, screen = {}, 0, U.Rect(UIParent)
    for _, e in ipairs(LP.uiFrames) do
        local r = Shown(e.frame) and U.Rect(e.frame)
        if r and screen then
            tested = tested + 1
            if r.l < screen.l - 1 or r.b < screen.b - 1 or r.r > screen.r + 1 or r.t > screen.t + 1 then
                problems[#problems + 1] = e.name .. " ragt aus dem Bildschirm"
            end
        end
    end
    return problems, tested
end

-- T227: Beschriftungen von Knöpfen sind nicht abgeschnitten (andere Texte nur als Hinweis)
function U.TextFits()
    local problems, hints, tested = {}, {}, 0
    for _, e in ipairs(LP.uiFrames) do
        if Shown(e.frame) then
            for _, el in ipairs(U.Descendants(e.frame)) do
                -- LevelPilot-Knöpfe tragen ihre Beschriftung in .label (UI:Button), Blizzard-Knöpfe in GetFontString
                local fs = (el.GetFontString and el:GetFontString()) or (IsControl(el) and el.label)
                if fs and fs.IsTruncated then
                    tested = tested + 1
                    if fs:IsTruncated() then problems[#problems + 1] = e.name .. ": " .. Name(el) .. " Beschriftung abgeschnitten" end
                end
                for _, region in ipairs(el.GetRegions and { el:GetRegions() } or {}) do
                    if region ~= fs and region.IsObjectType and region:IsObjectType("FontString") and region.IsTruncated and Shown(region) then
                        tested = tested + 1
                        if region:IsTruncated() then hints[#hints + 1] = Name(el) .. ": Text gekürzt" end
                    end
                end
            end
        end
    end
    return problems, tested, hints
end

-- T228: angezeigte Spielwerte plausibel (Prüfungen meldet LevelPilot mit LP.Plausible an)
function U.ValuesPlausible()
    local problems = {}
    for _, p in ipairs(LP.plausible) do
        local ok, good, got, want = pcall(p.fn)
        if not ok then problems[#problems + 1] = p.name .. ": Lua-Fehler " .. tostring(good)
        elseif good == false then problems[#problems + 1] = p.name .. ": " .. tostring(got) .. " (erwartet " .. tostring(want) .. ")" end
    end
    return problems, #LP.plausible
end

-- T229: keine Fehlerschleife – dieselbe Meldung in dieser Sitzung höchstens UI_LOOP_LIMIT× (GoldSentinelTest-Fehlerliste)
local baseline = nil
local function ErrorList()
    local s = type(LevelPilotDB) == "table" and LevelPilotDB.gsTest
    return s and type(s.errors) == "table" and s.errors or {}
end
function U.SessionBaseline()
    baseline = {}
    for k, e in pairs(ErrorList()) do if type(e) == "table" then baseline[k] = e.count or 0 end end
end
function U.NoErrorLoops()
    local problems, n = {}, 0
    for k, e in pairs(ErrorList()) do
        if type(e) == "table" then
            n = n + 1
            local now = (e.count or 0) - ((baseline and baseline[k]) or 0)
            if now > LP.UI_LOOP_LIMIT then problems[#problems + 1] = now .. "× " .. tostring(e.wo) .. ": " .. tostring(e.msg):sub(1, 80) end
        end
    end
    return problems, n
end

------------------------------------------------------------------------
-- Spielwerte (T228)
------------------------------------------------------------------------
local function Secret(v) return LP.Game and LP.Game.IsSecret and LP.Game.IsSecret(v) end

LP.Plausible("Stufe des Charakters", function()
    local lvl = UnitLevel and UnitLevel("player")
    if type(lvl) ~= "number" or Secret(lvl) then return true, "nicht lesbar" end
    return lvl >= 1 and lvl <= 60, lvl, "1–60"
end)

-- "N fertig" im Kopf des Guides = Anzahl "Abgeben" in der Liste (Anlass: "2 fertig", aber kein Abgeben oben)
LP.Plausible("Questlog: fertig = Abgeben in der Liste", function()
    local ready, turnin, missing = 0, {}, {}
    for _, st in ipairs(LP.Engine and LP.Engine.Steps and LP.Engine:Steps() or {}) do
        if st.t == "TURNIN" and st.id then turnin[st.id] = true end
    end
    local ign = LP.char and LP.char.ignored or {}
    for id, st in pairs(LP.Planner.inLog or {}) do
        if st.complete then
            ready = ready + 1
            -- ignorierte Quests und Quests ohne bekannte Abgabe stehen absichtlich nicht in der Liste
            local q = LP.QuestDB:Get(id)
            local noEnd = not q or not q.ends or #q.ends == 0
            if not turnin[id] and not ign[id] and not noEnd then missing[#missing + 1] = tostring(id) end
        end
    end
    local n = 0
    for _ in pairs(turnin) do n = n + 1 end
    return #missing == 0, string.format("%d fertig, %d Abgeben%s", ready, n, #missing > 0 and (" – ohne Abgeben: " .. table.concat(missing, ",")) or ""),
        "jede fertige Quest mit Abgabe-Ort als „Abgeben“ in der Liste"
end)

LP.Plausible("Questlog: Anzahl = Spiel", function()
    local active = 0
    for _ in pairs(LP.Planner.inLog or {}) do active = active + 1 end
    local count = 0
    local n = LP.API.NumEntries() or 0
    for i = 1, n do
        local title, _, header, _, _, qid = LP.API.Entry(i)
        if title and not header and type(qid) == "number" and not Secret(qid) and qid > 0 then count = count + 1 end
    end
    return active == count, active .. " im Guide", count .. " im Spiel"
end)

LP.Plausible("Position auf der Karte", function()
    local inst, _, _, map, x, y = LP.Geo:Player()
    if not inst then return true, "keine Position (Instanz/Ladebildschirm)" end
    return type(x) == "number" and type(y) == "number" and x >= 0 and x <= 100 and y >= 0 and y <= 100 and map ~= nil,
        string.format("%s %.1f/%.1f", tostring(map), x or -1, y or -1), "Karte, 0–100"
end)

LP:On("PLAYER_LOGIN", function()
    U.SessionBaseline()
    if C_Timer then C_Timer.After(5, U.Collect) end
end)
