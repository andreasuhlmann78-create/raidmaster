-- LevelPilot - Tooltip-Hinweise
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- * Gegner: "Quest X – Ebereber getoetet: 3/10" bzw. Gegenstand, den er fallen laesst
-- * Gegenstaende in den Taschen: "Fuer Quest X (2/5)", "Startet die Quest X"
-- * Objekte in der Welt (Kisten, Pflanzen ...): Questziel, wenn der Spieler an einer bekannten
--   Fundstelle steht oder der Name im Questziel vorkommt
-- Questgegenstaende werden nie automatisch verkauft (siehe IsProtected).

local _, LP = ...
local L = LP.L
local Tt = {}
LP:RegisterModule("Tooltips", Tt)

local PREFIX = "|cffffb238LevelPilot|r  "
local OBJ_TOOLTIP_RANGE = 12      -- Yards

local function ItemID(link)
    if type(link) == "number" then return link end
    return link and tonumber(link:match("item:(%d+)")) or nil
end

local function QuestName(id)
    local st = LP.Planner.inLog[id]
    if st and st.title then return st.title end
    local q = LP.QuestDB:Get(id)
    return q and q.name or ("#" .. id)
end

local function Done(id)
    return LP.API.IsQuestDone(id) and true or false
end

------------------------------------------------------------------------
-- Inhalte
------------------------------------------------------------------------
function Tt:UnitLines(unit)
    if not LP.db.tooltips or not LP.Plates then return nil end
    local list = LP.Plates:ForUnit(unit, true)
    if not list then return nil end
    local out = {}
    for _, e in ipairs(list) do
        out[#out + 1] = PREFIX .. (e.title or "?") .. ":  " .. (e.text or (e.have .. "/" .. e.need))
    end
    return out
end

function Tt:ItemLines(itemID)
    if not LP.db.tooltips or not itemID then return nil end
    local info = LP.QuestDB:ItemQuests(itemID)
    if not info then return nil end
    local out = {}
    local name = LP.Plates and LP.Plates.ItemName and LP.Plates.ItemName(itemID)
    for _, qid in ipairs(info.needs or {}) do
        local st = LP.Planner.inLog[qid]
        if st and not st.complete then
            local prog = ""
            for _, o in ipairs(LP.API.Objectives(st.index) or {}) do
                if name and o.text and o.text:find(name, 1, true) and o.need then prog = " (" .. (o.have or 0) .. "/" .. o.need .. ")" end
            end
            out[#out + 1] = PREFIX .. L("Für Quest „%s“", QuestName(qid)) .. prog
        end
    end
    for _, qid in ipairs(info.starts or {}) do
        if not Done(qid) and not LP.Planner.inLog[qid] then
            out[#out + 1] = PREFIX .. "|cff4ddb80" .. L("Startet die Quest „%s“", QuestName(qid)) .. "|r"
        end
    end
    return #out > 0 and out or nil
end

-- Gegenstand darf nicht automatisch verkauft oder als "kann weg" vorgeschlagen werden
function Tt:IsProtected(itemID)
    local info = itemID and LP.QuestDB:ItemQuests(itemID)
    if not info then return false end
    for _, qid in ipairs(info.needs or {}) do
        if LP.Planner.inLog[qid] then return true end
    end
    for _, qid in ipairs(info.starts or {}) do
        if not Done(qid) then return true end
    end
    return false
end

function Tt:ObjectLines(title)
    if not LP.db.tooltips or not title or title == "" then return nil end
    local out = {}
    -- an einer bekannten Fundstelle der laufenden Quest
    local pi, pn, pw = LP.Geo:Player()
    if pi and LP.Pins then
        for _, e in ipairs(LP.Pins.objects or {}) do
            local p = e.p
            local i, n, w = LP.Geo:ToWorld(p[1], p[2], p[3])
            if i == pi and LP.Geo:Dist(pn, pw, n, w) <= OBJ_TOOLTIP_RANGE then
                out[1] = PREFIX .. (e.text or L["Questgegenstand"])
                return out
            end
        end
    end
    -- Name im Questziel ("Raetselhafte Kiste untersucht: 0/1")
    for _, o in ipairs(LP.Plates and LP.Plates:OpenObjectives() or {}) do
        if not o.finished and o.text and #title >= 4 and o.text:find(title, 1, true) then
            out[#out + 1] = PREFIX .. (o.title or "?") .. ":  " .. o.text
        end
    end
    return #out > 0 and out or nil
end

------------------------------------------------------------------------
-- Einhaengen
------------------------------------------------------------------------
local function Add(tt, lines)
    if not lines then return end
    for _, l in ipairs(lines) do tt:AddLine(l, 1, 1, 1, true) end
    tt:Show()
end

local function OnUnit(tt)
    local _, unit = tt:GetUnit()
    unit = LP.SafeValue(unit)                -- moderner Client: Einheit kann geschuetzt sein
    if unit then Add(tt, Tt:UnitLines(unit)) end
end
Tt.OnUnit = OnUnit

-- Objekte in der Welt: Tooltip ohne Einheit und ohne Gegenstand (fuer die Testroutine zugaenglich)
function Tt.OnShowObject(tt)
    -- erster Rueckgabewert von GetUnit ist der (moeglicherweise geschuetzte) Name: nur die Einheit pruefen
    local _, unit = tt:GetUnit()
    if LP.SafeValue(unit) or (LP.Game and LP.Game.IsSecret(unit)) or tt:GetItem() then return end
    -- nur Tooltips der Spielwelt (Besitzer UIParent), nicht von Knoepfen und Fenstern
    if tt.GetOwner and tt:GetOwner() ~= UIParent then return end
    if tt.lpObjectDone then return end
    local left = _G["GameTooltipTextLeft1"]
    local title = left and LP.SafeValue(left:GetText())
    local lines = Tt:ObjectLines(title)
    if lines then
        tt.lpObjectDone = true
        Add(tt, lines)
    end
end

local function OnItem(tt)
    local _, link = tt:GetItem()
    Add(tt, Tt:ItemLines(ItemID(link)))
end

function Tt:Init()
    if not GameTooltip then return end
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, function(tt) if tt == GameTooltip then OnUnit(tt) end end)
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tt) if tt == GameTooltip or tt == ItemRefTooltip then OnItem(tt) end end)
    else
        GameTooltip:HookScript("OnTooltipSetUnit", OnUnit)
        GameTooltip:HookScript("OnTooltipSetItem", OnItem)
    end
    -- Objekte in der Welt: Tooltip ohne Einheit und ohne Gegenstand
    GameTooltip:HookScript("OnShow", function(tt) Tt.OnShowObject(tt) end)
    GameTooltip:HookScript("OnHide", function(tt) tt.lpObjectDone = nil end)
end
