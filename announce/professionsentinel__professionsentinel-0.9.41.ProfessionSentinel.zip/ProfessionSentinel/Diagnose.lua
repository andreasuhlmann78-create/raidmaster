local ADDON, ns = ...
local L = ns.L

-- Diagnostic log (/ps protokoll), modelled on the LevelPilot protocol and shared/vorlage Diag.lua.
-- The addon writes down by itself what only shows in the real game:
--   KLICK      a click on a recipe: recipe, spell ID, RecipeID, way, ms until selected, success (UI.lastClick)
--   AUFBAU     the collected rebuild of the panel (UI.RunPendingRefresh): how often, how long, trigger event
--   LANGSAM    a step slower than one frame (16 ms): UI:Refresh, AD.Update, Plan
--   ÜBERLAPPT  no free place next to the profession window, or the panel overlaps AHSentinel's window
--   FEHLER     Lua errors of the addon (ns.CountError and the GoldSentinelTest counter), the same error only counted
-- The kind codes are stable identifiers (also for the review); the texts come from Locales.lua.
-- Ring buffer of ns.DIAG_MAX entries in ProfessionSentinelDB.diag, newest first (a repeated entry is counted). On /reload or logout the log is
-- written as one "GSDIAG1" string to ProfessionSentinelDB.diagExport, so the RaidMasterUploader can take it like
-- the GSTEST1 reports. Format (one line head, then the text lines):
--   GSDIAG1|ProfessionSentinel|<version>|<client>|<interface>|<YYYY-MM-DD HH:MM>
--   <text of /ps protokoll>
-- No player, character, guild or realm names: every known name is replaced by "<Name>" (public repository).
-- Measuring only with debugprofilestop through ns.API (missing -> nothing is measured); no influence on the logic.

local D = {}
ns.Diagnose = D

ns.DIAG_MAX = 200            -- entries in the ring buffer
ns.DIAG_SLOW_MS = 16         -- one frame at 60 fps
ns.DIAG_PREFIX = "GSDIAG1"
ns.DIAG_EXPORT_MAX = 24000   -- characters of the GSDIAG1 string (whole lines, oldest entries drop out first)
D.KINDS = { "KLICK", "AUFBAU", "LANGSAM", "ÜBERLAPPT", "FEHLER" }

local function Now() return time and time() or 0 end

local function IsSecret(v) return ns.IsSecret and ns.IsSecret(v) or false end

-- one line of plain text: no colour codes, no line breaks, no "|" (separator of the head line)
local function Clean(s, max)
    if IsSecret(s) then return "?" end
    s = tostring(s == nil and "" or s)
    s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", ""):gsub("[\r\n|]", " ")
    if max and #s > max then s = s:sub(1, max) end
    return s
end
D.Clean = Clean

local function Round(ms)
    if type(ms) ~= "number" or ms ~= ms then return nil end
    return math.floor(ms * 10 + 0.5) / 10
end

local function ReplacePlain(s, find, repl)
    local out, i = {}, 1
    while true do
        local a, b = s:find(find, i, true)
        if not a then break end
        out[#out + 1] = s:sub(i, a - 1)
        out[#out + 1] = repl
        i = b + 1
    end
    out[#out + 1] = s:sub(i)
    return table.concat(out)
end

---------------------------------------------------------------------------
-- Storage (ProfessionSentinelDB.diag); a damaged entry never causes a Lua error
---------------------------------------------------------------------------
local function Store()
    local db = ns.db
    if type(db) ~= "table" then return nil end
    local d = db.diag
    if type(d) ~= "table" then d = {}; db.diag = d end
    if type(d.entries) ~= "table" then d.entries = {} end
    if type(d.sessions) ~= "number" then d.sessions = 0 end
    if type(d.seenErr) ~= "table" then d.seenErr = {} end
    return d
end
D.Store = Store

---------------------------------------------------------------------------
-- Names that must never leave the computer: player, realm, guild, every saved character
---------------------------------------------------------------------------
function D.Names()
    local out, seen = {}, {}
    local function add(n)
        if IsSecret(n) or type(n) ~= "string" or #n < 3 or seen[n] then return end
        seen[n] = true
        out[#out + 1] = n
    end
    if ns.PlayerName then local ok, n = pcall(ns.PlayerName); if ok then add(n) end end
    local A = ns.API
    if A.GetRealmName then local ok, r = pcall(A.GetRealmName); if ok then add(r) end end
    if A.GetGuildInfo then local ok, g = pcall(A.GetGuildInfo, "player"); if ok then add(g) end end
    local chars = ns.db and type(ns.db.chars) == "table" and ns.db.chars or {}
    for key in pairs(chars) do
        if type(key) == "string" then
            add(key)
            add(key:match("^([^-]+)"))
            add(key:match("^[^-]+%-(.+)$"))
        end
    end
    table.sort(out, function(a, b) return #a > #b end)      -- "Name-Realm" before "Name"
    return out
end

function D.Scrub(s, names)
    s = tostring(s or "")
    for _, n in ipairs(names or D.Names()) do
        if s:find(n, 1, true) then s = ReplacePlain(s, n, "<Name>") end
    end
    return s
end

---------------------------------------------------------------------------
-- Writing
---------------------------------------------------------------------------
-- kind: one of D.KINDS; text: one line; ms: duration (optional); add: number added to the entry's counter "a"
-- The same kind and text again only counts up (n, latest time, highest ms) and moves the entry to the top:
-- repeated rebuilds, clicks or errors never flood the log (no loops), the buffer holds different events.
function ns.Diag(kind, text, ms, add)
    -- the test routine never writes into the real log; its own cases switch D.testSink on (with a sandboxed db.diag)
    if not D.testSink and ns.TestRoutine and ns.TestRoutine.IsRunning and ns.TestRoutine:IsRunning() then return nil end
    local d = Store()
    if not d then return nil end
    kind, text = Clean(kind, 20), Clean(text, 240)
    local list = d.entries
    local found, idx
    for i = 1, #list do
        local x = list[i]
        if type(x) == "table" and x.k == kind and x.t == text then found, idx = x, i; break end
    end
    local r = Round(ms)
    if found then
        found.n = (tonumber(found.n) or 1) + 1
        found.z = Now()
        -- the highest value per version (a new version starts again) and the last value (review 0.9.33, 7d)
        if found.v ~= ns.VERSION then found.v, found.ms = ns.VERSION, nil end
        if r then found.ms = math.max(tonumber(found.ms) or 0, r); found.l = r end
        if type(add) == "number" then found.a = (tonumber(found.a) or 0) + add end
        if idx > 1 then table.remove(list, idx); table.insert(list, 1, found) end
        return found
    end
    local e = { k = kind, t = text, z = Now(), n = 1, ms = r, l = r, v = ns.VERSION, a = type(add) == "number" and add or nil }
    table.insert(list, 1, e)
    for i = #list, ns.DIAG_MAX + 1, -1 do list[i] = nil end
    return e
end

-- clock for the measurements (nil when the client has no debugprofilestop: then nothing is measured)
function ns.DiagClock()
    local f = ns.API and ns.API.debugprofilestop
    if not f then return nil end
    local ok, t = pcall(f)
    return ok and type(t) == "number" and t or nil
end

-- a measured step: slower than one frame -> LANGSAM with its name
function ns.DiagSlow(name, t0)
    if not t0 then return end
    -- inside a portioned rebuild a step may span several frames: the rebuild measures each portion itself
    if ns.UI and ns.UI.InBuild and ns.UI.InBuild() then return end
    local t1 = ns.DiagClock()
    if t1 and t1 - t0 > ns.DIAG_SLOW_MS then
        ns.diagSlowCount = (ns.diagSlowCount or 0) + 1      -- the play test (S7) counts them
        ns.Diag("LANGSAM", name, t1 - t0)
    end
end

-- KLICK from UI.lastClick (after every SelectInBlizzard)
function D.Click(c, r)
    if type(c) ~= "table" then return end
    local name = "?"
    if r and ns.RecipeName then
        local ok, n = pcall(ns.RecipeName, r)
        if ok and n then name = n end
    end
    local text = string.format(L.DG_CLICK, Clean(name, 60), tostring(c.spell or "-"), tostring(c.recipeID or "-"),
        tostring(c.way or "?"), c.ok and L.DG_YES or L.DG_NO)
    return ns.Diag("KLICK", text, c.ms)
end

-- AUFBAU: one collected rebuild (trigger event, how many requests were collected, duration)
function D.Build(event, requests, ms)
    return ns.Diag("AUFBAU", event or "?", ms, tonumber(requests) or 0)
end

-- ÜBERLAPPT
function D.Overlap(text)
    return ns.Diag("ÜBERLAPPT", text)
end

-- FEHLER from ns.CountError (caught errors)
function ns.DiagError(where, err)
    return ns.Diag("FEHLER", D.Scrub(Clean(where, 60) .. ": " .. Clean(err, 180)))
end

-- uncaught Lua errors and blocked actions are counted by GoldSentinelTest (gsTest.errors): take the new ones over
local SYNC_WO = { Lua = true, ADDON_ACTION_BLOCKED = true, ADDON_ACTION_FORBIDDEN = true }
function D.SyncErrors()
    local s = ns.db and ns.db.gsTest
    if type(s) ~= "table" or type(s.errors) ~= "table" then return 0 end
    local d = Store()
    if not d then return 0 end
    local added = 0
    for key, e in pairs(s.errors) do
        if type(key) == "string" and type(e) == "table" and SYNC_WO[e.wo] then
            local cnt = tonumber(e.count) or 1
            local seen = tonumber(d.seenErr[key]) or 0
            if cnt < seen then seen = 0 end            -- the counter was sent and started again
            if cnt > seen then
                local entry = ns.Diag("FEHLER", D.Scrub(Clean(e.wo, 30) .. ": " .. Clean(e.msg, 180)))
                if entry then entry.n = (tonumber(entry.n) or 1) + (cnt - seen - 1) end
                d.seenErr[key] = cnt
                added = added + 1
            end
        end
    end
    for key in pairs(d.seenErr) do
        if s.errors[key] == nil then d.seenErr[key] = nil end
    end
    return added
end

---------------------------------------------------------------------------
-- Text
---------------------------------------------------------------------------
local function Stamp(t, fmt)
    if not (date and type(t) == "number") then return "?" end
    local ok, s = pcall(date, fmt or "%d.%m. %H:%M:%S", t)
    return ok and s or "?"
end

local function YesNo(v) return v and L.DG_YES or L.DG_NO end

-- settings that differ from the defaults (values only: switches and numbers)
function D.ChangedSettings()
    local db, def = ns.db, ns.DEFAULTS or {}
    local out = {}
    if type(db) ~= "table" then return out end
    for k, v in pairs(def) do
        if type(v) ~= "table" and db[k] ~= nil and db[k] ~= v and type(db[k]) ~= "table" then
            out[#out + 1] = k .. "=" .. Clean(db[k], 20)
        end
    end
    if type(db.filters) == "table" and db.filters.missing then out[#out + 1] = "filters.missing=true" end
    if type(db.panelMode) == "string" then out[#out + 1] = "panelMode=" .. Clean(db.panelMode, 20) end
    table.sort(out)
    return out
end

local function ClientInfo()
    local version, build, _, iface = "?", "?", nil, nil
    if GetBuildInfo then
        local ok, v, b, _, i = pcall(GetBuildInfo)
        if ok then version, build, iface = v or "?", b or "?", i end
    end
    return Clean(version, 20), Clean(build, 20), tostring(iface or ns.Interface or "?")
end

local function DockedText()
    local UI = ns.UI
    if not (UI and UI.IsShown and UI:IsShown()) then return "–" end
    local f = UI.dockedTo
    if not f then return L.DG_DOCK_FREE end
    if UI.lastDock and f == UI.lastDock then
        local n = f.GetName and f:GetName()
        return L.DG_DOCK_AHS .. ((type(n) == "string" and n ~= "") and (" (" .. n .. ")") or "")
    end
    local n = f.GetName and f:GetName()
    return (type(n) == "string" and n ~= "") and n or "?"
end

local function EntryLine(e)
    local s = string.format("[%s] %s%s %s", Stamp(e.z), tostring(e.k or "?"), (tonumber(e.n) or 1) > 1 and (" ×" .. e.n) or "",
        tostring(e.t or ""))
    if tonumber(e.a) and e.a > 0 then s = s .. " · " .. string.format(L.DG_REQUESTS, e.a) end
    if tonumber(e.ms) then
        s = s .. " · " .. string.format("%.1f ms", e.ms)
        if tonumber(e.l) and math.abs(e.l - e.ms) > 0.05 then s = s .. " " .. string.format(L.DG_LAST, e.l) end
        if e.v then s = s .. " (v" .. tostring(e.v) .. ")" end
    end
    return s
end

-- the whole log as lines (names already replaced)
function D.Lines()
    D.SyncErrors()
    local d = Store() or { entries = {}, sessions = 0 }
    local out = {}
    local function add(s) out[#out + 1] = s end
    local version, build, iface = ClientInfo()
    add(string.format(L.DG_HEAD, ADDON, tostring(ns.VERSION), Stamp(Now(), "%d.%m.%Y %H:%M")))
    add(string.format(L.DG_CLIENT, tostring(ns.Flavor or "?"), version, build, iface,
        tostring(GetLocale and GetLocale() or "?")))
    add(string.format(L.DG_SESSIONS, d.sessions or 0, Stamp(d.since, "%d.%m.%Y")))
    local set = D.ChangedSettings()
    add(string.format(L.DG_SETTINGS, #set > 0 and table.concat(set, ", ") or L.DG_NONE))
    add("")
    add(L.DG_SECTION_DIAG)
    local src = ns.Prices and ns.Prices.SourceName and ns.Prices.SourceName()
    add("  " .. string.format(L.DG_PRICE, src or L.DG_NONE))
    add("  " .. string.format(L.DG_PANEL, YesNo(ns.UI and ns.UI.IsShown and ns.UI:IsShown())))
    add("  " .. string.format(L.DG_DOCK, DockedText()))
    local UI = ns.UI or {}
    add("  " .. string.format(L.DG_REFRESH, tonumber(UI.refreshRequests) or 0, tonumber(UI.refreshRuns) or 0))
    local GT = _G.GoldSentinelTest
    local errs = 0
    local s = ns.db and ns.db.gsTest
    if type(s) == "table" and type(s.errors) == "table" then
        for _, e in pairs(s.errors) do if type(e) == "table" then errs = errs + (tonumber(e.count) or 1) end end
    end
    add("  " .. string.format(L.DG_ERRORS, errs))
    if GT and GT.Pending and ns.db then
        local ok, n = pcall(GT.Pending, ns.db)
        add("  " .. string.format(L.DG_PENDING, ok and tonumber(n) or 0))
    end
    add("")
    local list = {}
    for _, e in ipairs(d.entries) do if type(e) == "table" then list[#list + 1] = e end end
    add(string.format(L.DG_SECTION_ENTRIES, #list, ns.DIAG_MAX))
    if #list == 0 then add(L.DG_EMPTY) end
    for _, e in ipairs(list) do add(EntryLine(e)) end
    local names = D.Names()
    for i, line in ipairs(out) do out[i] = D.Scrub(line, names) end
    return out
end

function D.Text()
    return table.concat(D.Lines(), "\n")
end

-- GSDIAG1 string for the saved variables (head line, then whole text lines up to ns.DIAG_EXPORT_MAX characters)
function D.Export()
    local version, build, iface = ClientInfo()
    local client = Clean(tostring(ns.Flavor or "?") .. " " .. version .. " " .. build, 60)
    local head = table.concat({ ns.DIAG_PREFIX, ADDON, Clean(ns.VERSION, 20), client, Clean(iface, 12),
        Stamp(Now(), "%Y-%m-%d %H:%M") }, "|")
    local out, size = { head }, #head
    for _, line in ipairs(D.Lines()) do
        if size + #line + 1 > ns.DIAG_EXPORT_MAX then break end
        out[#out + 1] = line
        size = size + #line + 1
    end
    return table.concat(out, "\n")
end

---------------------------------------------------------------------------
-- Window (selectable text; no global frame names)
---------------------------------------------------------------------------
local win
local function CreateWindow()
    local tmpl = BackdropTemplateMixin and "BackdropTemplate" or nil
    win = CreateFrame("Frame", nil, UIParent, tmpl)
    if ns.RegisterUI then ns.RegisterUI(win, "Diagnose-Protokoll") end
    win:Hide()
    win:SetSize(660, 520)
    win:SetPoint("CENTER")
    win:SetFrameStrata("DIALOG")
    win:SetClampedToScreen(true)
    win:SetMovable(true)
    win:EnableMouse(true)
    win:RegisterForDrag("LeftButton")
    win:SetScript("OnDragStart", win.StartMoving)
    win:SetScript("OnDragStop", win.StopMovingOrSizing)
    if win.SetBackdrop then
        win:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32,
            insets = { left = 11, right = 12, top = 12, bottom = 11 } })
    end
    local title = win:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOP", 0, -16)
    win.title = title
    local hint = win:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    hint:SetPoint("TOPLEFT", 20, -36)
    hint:SetPoint("RIGHT", -20, 0)
    hint:SetJustifyH("LEFT")
    win.hint = hint

    local sf = CreateFrame("ScrollFrame", nil, win)
    sf:SetPoint("TOPLEFT", 20, -62)
    sf:SetPoint("BOTTOMRIGHT", -20, 46)
    sf:EnableMouseWheel(true)
    local eb = CreateFrame("EditBox", nil, sf)
    eb:SetMultiLine(true)
    eb:SetAutoFocus(false)
    eb:SetFontObject(ChatFontNormal or GameFontHighlightSmall)
    eb:SetWidth(610)
    eb:SetScript("OnEscapePressed", function() win:Hide() end)
    eb:SetScript("OnTextChanged", function(self, user)
        if user then self:SetText(win.text or "") end      -- read only
    end)
    sf:SetScrollChild(eb)
    sf:SetScript("OnMouseWheel", function(self, delta)
        local max = self.GetVerticalScrollRange and self:GetVerticalScrollRange() or 0
        local v = (self.GetVerticalScroll and self:GetVerticalScroll() or 0) - delta * 40
        if v < 0 then v = 0 elseif v > max then v = max end
        if self.SetVerticalScroll then self:SetVerticalScroll(v) end
    end)
    win.eb = eb

    local sel = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
    sel:SetSize(160, 22)
    sel:SetPoint("BOTTOMLEFT", 18, 16)
    sel:SetText(L.AT_SELECT_ALL)
    sel:SetScript("OnClick", function() eb:SetFocus(); eb:HighlightText() end)
    win.selectAll = sel
    local close = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
    close:SetSize(120, 22)
    close:SetPoint("BOTTOMRIGHT", -18, 16)
    close:SetText(CLOSE or L.DG_CLOSE)
    close:SetScript("OnClick", function() win:Hide() end)
    win.close = close
end

function D.Frame() return win end

function D.Show()
    if not win then CreateWindow() end
    win.title:SetText(L.DG_TITLE)
    win.hint:SetText(L.DG_HINT)
    win.text = D.Text()
    win.eb:SetText(win.text)
    win.eb:SetCursorPosition(0)
    win:Show()
    win.eb:SetFocus()
    win.eb:HighlightText()
    return win
end

function D.Hide() if win then win:Hide() end end

---------------------------------------------------------------------------
-- Events: count sessions, write the GSDIAG1 string on /reload or logout (never during the test routine)
---------------------------------------------------------------------------
function D.OnLogin()
    local d = Store()
    if not d then return end
    d.sessions = d.sessions + 1
    if type(d.since) ~= "number" then d.since = Now() end
end

function D.OnLogout()
    if ns.TestRoutine and ns.TestRoutine.IsRunning and ns.TestRoutine:IsRunning() then return false end
    if type(ns.db) ~= "table" then return false end
    local ok, s = pcall(D.Export)
    if ok and type(s) == "string" then ns.db.diagExport = s; return true end
    return false
end

local frame = ns.AddEventFrame(CreateFrame("Frame"), "Diagnose")
frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("PLAYER_LOGOUT")
frame:SetScript("OnEvent", function(_, event)
    if not ns.db then return end
    if event == "PLAYER_LOGIN" then D.OnLogin()
    elseif event == "PLAYER_LOGOUT" then D.OnLogout() end
end)
