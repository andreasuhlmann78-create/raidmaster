local _, ns = ...
local L = ns.L

-- Market knowledge for crafting and the gold ranking (order PM1–PM7 of the review, 13 Nov. 07:10;
-- raidmaster shared/wissen/markt-strategie.md section 8g, wirtschaft-forever.md, AHSentinel/API.md).
--   PM1 both directions: per recipe "crafting pays (+x)" OR "sell the reagents raw (+y)" – the AH value of the
--       reagents after 5 % against the product.
--   PM2 real market prices: reagents over the price ladder for the NEEDED quantity, vendor reagents at the vendor
--       price, the product at the achievable price (5 %, deposit), output = mean of min/max; cooldown recipes
--       (transmutes, mooncloth, salt): profit per cooldown, not per click.
--   PM3 no fake profits: prices older than 6 h, buy-out (whole ladder > 150 % of the market value), thin market
--       (< 5 offers of the product) or profit > 300 % -> no number but "check data" / "thin market" / "buy-out" (grey).
--   PM4 one number with AHSentinel: when its API is loaded, values ONLY through AHSentinel.API (MaterialCost,
--       NetSale, Price and – once AHSentinel has them – WorthUpTo and MarketState). Never a second own calculation.
--       Without AHSentinel the same rules are applied here.
--   PM5 levelling wave: a hint per level band from the market state (falls / rises / peak), raid food and potions as
--       a filter before the raid start (9 Dec.). Direction only, no fixed percentages (not measured yet, MA6).
--   PM6 check of the recommendations: "crafting pays" is noted with time and expected proceeds when you craft it;
--       a sale (own mail) counts as a hit; per profession the hit rate. Under 60 % from 20 cases on the gold
--       number gets "unsure".
-- Nothing here buys, sells or sends anything; the mail is only read (invoices of own auctions).

local MK = {}
ns.Market = MK

MK.OLD_SECONDS = 6 * 3600       -- PM3: prices older than 6 hours
MK.BUYOUT_FACTOR = 1.5          -- PM3: the whole ladder above 150 % of the market value = buy-out
MK.THIN_OFFERS = 5              -- PM3: fewer than 5 offers of the product = thin market
MK.MAX_PCT = 300                -- PM3: more than 300 % profit = check the data
MK.LADDER_REST = 1.5            -- quantity above the known steps: 1.5 × the last step (like AHSentinel's ladder)
MK.MAX_CRAFTS = 20              -- ladder for at most 20 crafts at once
MK.RAID_START = "20261209"      -- WoW Forever: raid start 9 Dec. 2026
MK.BANDS = { { 1, 25 }, { 26, 45 }, { 46, 60 } }
MK.BAND_MIN = 3                 -- a band hint needs at least 3 products of that band with a trend
MK.HIT_MIN_CASES = 20           -- PM6: from 20 cases on …
MK.HIT_MIN_RATE = 0.60          -- … under 60 % hits -> "unsure"
MK.HIT_DAYS = 7                 -- a crafted product not sold within 7 days counts as a miss
MK.HIT_KEEP = 200               -- at most 200 open notes (saved variables stay small)
-- cooldown recipes besides the transmutes (spell IDs): mooncloth, refined deeprock salt (salt shaker)
MK.COOLDOWN_SPELLS = { [18560] = true, [19566] = true }

local function PS() return ns.PriceSource end
local function Now() return (time and time()) or 0 end
local function Num(v) return type(v) == "number" and v == v and v or nil end
function MK.Today() return date and date("%Y%m%d") or "20000101" end

-- a function of AHSentinel's API that is new and optional (WorthUpTo, MarketState): no diagnostic line while missing
local function OptApi(name)
    local api = PS().API()
    local fn = api and api[name]
    return type(fn) == "function" and fn or nil
end
MK.OptApi = OptApi

-- with AHSentinel's API every value comes from it (PM4); old AHSentinel without API: as before
function MK.UsesAPI() return PS().API() ~= nil and not (ns.Sim and ns.Sim.prices) end

-- test data: ns.Sim.market[itemID] = { ladder = { {price, qty}, ... }, offers, age (s), market, state, trend }
local function SimEntry(itemID)
    local m = ns.Sim and ns.Sim.market
    return type(m) == "table" and m[itemID] or nil
end

---------------------------------------------------------------------------
-- Price ladder: { {price per piece, pieces}, ... } ascending, number of offers, source.
-- AHSentinel's API has no ladder (its MaterialCost walks the ladder itself), auxForever, Auctionator, Auctioneer
-- and TSM publish none to other addons: then nil and the single price is used (marked "no ladder").
---------------------------------------------------------------------------
function MK.Ladder(itemID)
    local m = SimEntry(itemID)
    if m then
        if type(m.ladder) == "table" and #m.ladder > 0 then return m.ladder, m.offers or #m.ladder, "Test" end
        return nil, m.offers
    end
    return nil
end

-- cost to BUY qty pieces in the AH over the ladder (PM2); returns total, { ladder, short }
function MK.BuyCost(itemID, qty)
    qty = math.max(1, math.floor(tonumber(qty) or 1))
    local ladder = MK.Ladder(itemID)
    if ladder then
        local left, total, last = qty, 0, nil
        for _, st in ipairs(ladder) do
            local p, q = Num(st[1]), Num(st[2]) or 0
            if p then
                local take = math.min(left, q)
                total = total + take * p
                left = left - take
                last = p
                if left <= 0 then break end
            end
        end
        if last then
            local short = left > 0
            if short then total = total + left * math.floor(last * MK.LADDER_REST) end
            return total, { ladder = true, short = short }
        end
    end
    local unit = ns.Prices.BuyAH(itemID)
    if not unit then return nil end
    return unit * qty, { ladder = false }
end

---------------------------------------------------------------------------
-- Market state of an item: { state = "normal"|"aufkauf"|"flut"|"duenn"|"alt"|nil, trend = "faellt"|"steigt"|
-- "spitze"|nil, offers, age (s), market }. AHSentinel.API.MarketState decides when it exists; otherwise from the
-- age of the price, the offers and the ladder against the market value. Once per pass.
---------------------------------------------------------------------------
local function InfoRaw(itemID)
    local info = {}
    local m = SimEntry(itemID)
    if m then
        info.state, info.trend, info.age, info.market = m.state, m.trend, Num(m.age), Num(m.market)
        local ladder, offers = MK.Ladder(itemID)
        info.offers, info.ladder = Num(offers), ladder
    elseif not (ns.Sim and ns.Sim.prices) then
        local fn = MK.UsesAPI() and OptApi("MarketState")
        if fn then
            local s, t = PS().Call("AHSentinel.API.MarketState", fn, itemID)
            if type(s) == "string" then info.state = s end
            if type(t) == "string" then info.trend = t end
            info.api = true
        end
        local _, _, _, age = ns.Prices.AH(itemID)
        info.age = Num(age)
        local ladder, offers = MK.Ladder(itemID)
        info.offers, info.ladder = Num(offers), ladder
    end
    if not info.state then
        if info.age and info.age > MK.OLD_SECONDS then info.state = "alt"
        elseif info.ladder and info.market and info.ladder[1] and info.ladder[1][1] > info.market * MK.BUYOUT_FACTOR then
            info.state = "aufkauf"
        elseif info.offers and info.offers < MK.THIN_OFFERS then info.state = "duenn" end
    end
    return info
end
MK.InfoRaw = InfoRaw

function MK.Info(itemID)
    local pass = ns.Prices.Pass()
    if pass then
        pass.mk = pass.mk or {}
        local c = pass.mk[itemID]
        if c then return c end
        local info = InfoRaw(itemID)
        pass.mk[itemID] = info
        return info
    end
    return InfoRaw(itemID)
end

-- market state -> flag of a calculation (no number): "old" / "buyout" / "thin"; "flut" (flooding) is no flag
MK.FLAG_OF = { alt = "old", aufkauf = "buyout", duenn = "thin" }

---------------------------------------------------------------------------
-- Recipe helpers
---------------------------------------------------------------------------
function MK.IsCooldown(r)
    if not r then return false end
    if MK.COOLDOWN_SPELLS[r.spell] then return true end
    local en = r.nameEN or ""
    return en:find("^Transmute") ~= nil
end

function MK.Made(r) return ((r.outMin or 1) + (r.outMax or r.outMin or 1)) / 2 end

-- how many crafts the calculation is for: what the market takes in ~2 days (1 … 20), a cooldown recipe 1
function MK.Crafts(r)
    if not r or not r.out or MK.IsCooldown(r) then return 1 end
    local pass = ns.Prices.Pass()
    local cap
    if pass then
        pass.cap = pass.cap or {}
        cap = pass.cap[r.out]
        if cap == nil then cap = PS().SellCap(r.out) or false; pass.cap[r.out] = cap end
        cap = cap or nil
    else
        cap = PS().SellCap(r.out)
    end
    return math.max(1, math.min(MK.MAX_CRAFTS, cap or 1))
end

-- AHSentinel.API.MaterialCost for crafts × the product (PM4): per craft and per reagent; nil when the API has no
-- value or knows the recipe with other reagents (then the own way with AHSentinel's prices)
function MK.ApiMaterialCost(r, crafts)
    if not (r and r.out and MK.UsesAPI()) then return nil end
    local fn = OptApi("MaterialCost")
    if not fn then return nil end
    local qty = math.max(1, math.floor(crafts * (r.outMin or 1)))
    local total, list = PS().Call("AHSentinel.API.MaterialCost", fn, r.out, qty)
    total = Num(total)
    if not total or type(list) ~= "table" then return nil end
    local byId = {}
    for _, e in ipairs(list) do
        if type(e) == "table" and Num(e.itemID) then
            local b = byId[e.itemID] or { qty = 0, cost = 0 }
            b.qty, b.cost, b.source = b.qty + (Num(e.qty) or 0), b.cost + (Num(e.cost) or 0), e.source
            byId[e.itemID] = b
        end
    end
    local n = 0
    for i = 1, #(r.reagents or {}), 2 do
        if not byId[r.reagents[i]] then MK.apiMismatch = r.spell; return nil end
        n = n + 1
    end
    local m = 0
    for _ in pairs(byId) do m = m + 1 end
    if m ~= n then MK.apiMismatch = r.spell; return nil end
    return total / crafts, byId
end

-- net value of n pieces when sold in the AH (5 %, deposit), memo per pass
function MK.NetSale(itemID, n)
    local pass = ns.Prices.Pass()
    local key = itemID .. ":" .. n
    if pass then
        pass.mkNet = pass.mkNet or {}
        local c = pass.mkNet[key]
        if c ~= nil then return c or nil end
        local v = PS().NetSale(itemID, n)
        pass.mkNet[key] = Num(v) or false
        return Num(v)
    end
    return Num((PS().NetSale(itemID, n)))
end

-- PM1: what the reagents of one craft bring when sold raw (AH net; vendor reagents at their price – you would not
-- buy them); nil if a value is missing
function MK.RawValue(res)
    local total = 0
    for _, part in ipairs(res.parts or {}) do
        if part.origin == "vendor" then
            total = total + (part.unit or 0) * part.count
        else
            local v = MK.NetSale(part.id, part.count)
            if not v then return nil end
            total = total + v
        end
    end
    return total
end

---------------------------------------------------------------------------
-- The market part of a recipe calculation (called by Prices.Recipe for every recipe with a product):
-- sets res.crafts, res.cooldown, res.rawNet, res.craftAdv, res.direction, res.pct, res.flag, res.trend, res.unsure
---------------------------------------------------------------------------
function MK.Judge(res, r)
    if not (res and r and r.out) then return res end
    res.cooldown = MK.IsCooldown(r) or nil
    if not res.known then return res end
    local net = res.bestNet or res.net or 0
    -- PM1: crafting against selling the reagents raw
    local raw = MK.RawValue(res)
    if raw then
        res.rawNet = raw
        res.craftAdv = (net + res.cost) - raw
        res.direction = res.craftAdv >= 0 and "craft" or "raw"
    end
    -- PM3: no number from stale, bought-out or thin data, nor beyond 300 %
    local flag
    local pi = MK.Info(r.out)
    res.trend, res.state = pi.trend, pi.state
    if res.valueSource == "ah" or res.bestVia == "de" then flag = MK.FLAG_OF[pi.state or ""] end
    for _, part in ipairs(res.parts or {}) do
        if not flag and (part.origin == "ah" or part.origin == "farm") then
            local f = MK.FLAG_OF[MK.Info(part.id).state or ""]
            if f == "old" or f == "buyout" then flag = f end
        end
    end
    if res.cost > 0 then
        res.pct = math.floor(net / res.cost * 100 + 0.5)
        if not flag and res.pct > MK.MAX_PCT then flag = "check" end
    end
    res.flag = flag
    -- PM6: the hit rate of this profession
    res.unsure = MK.Unsure(r.prof) or nil
    return res
end

-- the text of a flag ("check data" …) for rows, tooltip and details
function MK.FlagText(flag)
    if flag == "old" then return L.MK_OLD end
    if flag == "buyout" then return L.MK_BUYOUT end
    if flag == "thin" then return L.MK_THIN end
    if flag == "check" then return L.MK_CHECK end
    return nil
end

-- "Crafting pays +x" / "Sell the reagents raw +y" (coloured); nil without a direction
function MK.DirectionText(pr, plain)
    if not (pr and pr.direction) then return nil end
    local P = ns.Prices
    if pr.direction == "raw" then
        local s = string.format(L.MK_RAW, P.MoneyPlain(-pr.craftAdv))
        return plain and s or ("|cffff8040" .. s .. "|r")
    end
    local x = (pr.bestNet or pr.net or 0) > 0 and (pr.bestNet or pr.net) or pr.craftAdv
    local s = string.format(L.MK_CRAFT, P.MoneyPlain(x))
    return plain and s or ("|cff40c040" .. s .. "|r")
end

---------------------------------------------------------------------------
-- PM5: level bands and raid consumables
---------------------------------------------------------------------------
function MK.MinLevel(itemID)
    local ok, _, _, _, _, minLevel = pcall(ns.ItemInfo, itemID)
    if ok and type(minLevel) == "number" then return minLevel end
    return nil
end

function MK.Band(level)
    if not level then return nil end
    for i, b in ipairs(MK.BANDS) do
        if level <= b[2] then return i end
    end
    return #MK.BANDS
end

-- the band of a recipe's product: its required level, otherwise the band from the skill (300 skill ≈ level 60)
function MK.RecipeBand(r)
    local lvl = r.out and MK.MinLevel(r.out)
    if not lvl or lvl <= 0 then lvl = math.max(1, math.floor((r.req or 1) / 5)) end
    return MK.Band(lvl)
end

-- { { band = i, from, to, trend, n } } for the bands where most products (≥ 3) share one direction
function MK.BandHints(entries)
    local count = {}
    for _, e in ipairs(entries or {}) do
        local pr = e.price
        if pr and pr.trend then
            local b = MK.RecipeBand(e.recipe)
            if b then
                count[b] = count[b] or { n = 0 }
                count[b].n = count[b].n + 1
                count[b][pr.trend] = (count[b][pr.trend] or 0) + 1
            end
        end
    end
    local out = {}
    for b = 1, #MK.BANDS do
        local c = count[b]
        if c and c.n >= MK.BAND_MIN then
            for _, t in ipairs({ "faellt", "spitze", "steigt" }) do
                if (c[t] or 0) * 2 > c.n then
                    out[#out + 1] = { band = b, from = MK.BANDS[b][1], to = MK.BANDS[b][2], trend = t, n = c.n }
                    break
                end
            end
        end
    end
    return out
end

function MK.BandText(h)
    local key = (h.trend == "faellt" and "MK_BAND_FALLS") or (h.trend == "spitze" and "MK_BAND_PEAK") or "MK_BAND_RISES"
    return string.format(L[key], h.from, h.to)
end

-- raid food and potions: cooking and alchemy products for level 50 and up (or from skill 250 on)
MK.RAID_PROFS = { [185] = true, [171] = true }
function MK.IsRaidConsumable(r)
    if not (r and r.out and MK.RAID_PROFS[r.prof]) then return false end
    if MK.IsCooldown(r) then return false end
    local lvl = MK.MinLevel(r.out)
    if lvl and lvl > 0 then return lvl >= 50 end
    return (r.req or 0) >= 250
end

-- the raid filter is offered in WoW Forever up to the raid start
function MK.RaidFilterOffered() return ns.IsForever == true and MK.Today() <= MK.RAID_START end
function MK.RaidFilterOn() return MK.RaidFilterOffered() and ns.db and ns.db.goldRaid == true end

---------------------------------------------------------------------------
-- PM6: check of the recommendations (saved: ns.db.pmHits = { open = { {i, p, t, e, c} }, prof = { [p] = {h, n} },
-- seen = { [key] = time } })
---------------------------------------------------------------------------
local function Hits()
    local db = ns.db
    if not db then return nil end
    local h = db.pmHits
    if type(h) ~= "table" then h = {}; db.pmHits = h end
    h.open = type(h.open) == "table" and h.open or {}
    h.prof = type(h.prof) == "table" and h.prof or {}
    h.seen = type(h.seen) == "table" and h.seen or {}
    return h
end
MK.Hits = Hits

local function Count(h, prof, hit)
    local p = h.prof[prof] or { h = 0, n = 0 }
    p.n = p.n + 1
    if hit then p.h = p.h + 1 end
    h.prof[prof] = p
end

-- an own craft: note it when the calculation said "crafting pays" with a number
function MK.OnCraft(r, now)
    if not (r and r.out) then return false end
    local P = ns.Prices
    local ok, pr = pcall(P.Recipe, r, true)
    if not (ok and pr and pr.known and not pr.flag and pr.direction == "craft" and (pr.bestNet or 0) > 0) then return false end
    local h = Hits()
    if not h then return false end
    local made = MK.Made(r)
    h.open[#h.open + 1] = { i = r.out, p = r.prof, t = now or Now(),
        e = math.floor((pr.bestNet + pr.cost) / made + 0.5), c = math.floor(pr.cost / made + 0.5) }
    while #h.open > MK.HIT_KEEP do table.remove(h.open, 1) end
    return true
end

-- open notes older than 7 days: a miss
function MK.Expire(now)
    local h = Hits()
    if not h then return 0 end
    now = now or Now()
    local n = 0
    for k = #h.open, 1, -1 do
        local o = h.open[k]
        if now - (o.t or 0) > MK.HIT_DAYS * 86400 then
            Count(h, o.p, false)
            table.remove(h.open, k)
            n = n + 1
        end
    end
    return n
end

-- a sale of an own auction (invoice): the oldest open note of that item; hit when the piece brought at least its cost
function MK.OnSale(itemID, netPerPiece, key, now)
    local h = Hits()
    if not (h and itemID) then return nil end
    now = now or Now()
    if key then
        if h.seen[key] then return nil end
        h.seen[key] = now
        for k, t in pairs(h.seen) do if now - t > 31 * 86400 then h.seen[k] = nil end end
    end
    for k, o in ipairs(h.open) do
        if o.i == itemID then
            local hit = (netPerPiece or 0) >= (o.c or 0)
            Count(h, o.p, hit)
            table.remove(h.open, k)
            return hit
        end
    end
    return nil
end

-- hits, cases of a profession
function MK.HitRate(prof)
    local h = ns.db and type(ns.db.pmHits) == "table" and ns.db.pmHits
    local p = h and type(h.prof) == "table" and h.prof[prof]
    if type(p) ~= "table" then return 0, 0 end
    return p.h or 0, p.n or 0
end

function MK.Unsure(prof)
    local hits, n = MK.HitRate(prof)
    return n >= MK.HIT_MIN_CASES and hits / n < MK.HIT_MIN_RATE
end

-- per profession "Schneiderei 12/20 (60 %)" for the test report
function MK.HitReport()
    local out = {}
    local h = ns.db and type(ns.db.pmHits) == "table" and ns.db.pmHits
    for prof, p in pairs(h and type(h.prof) == "table" and h.prof or {}) do
        if type(p) == "table" and (p.n or 0) > 0 then
            local name = ns.ProfById[prof] and ns.ProfById[prof].name or tostring(prof)
            out[#out + 1] = string.format("%s %d/%d (%d %%)", name, p.h or 0, p.n, math.floor((p.h or 0) / p.n * 100 + 0.5))
        end
    end
    table.sort(out)
    return #out > 0 and table.concat(out, ", ") or "noch keine Fälle"
end

-- item ID by name (the invoice only has the name): products of the recipes
local function ItemByName(name)
    if type(name) ~= "string" then return nil end
    for id in pairs(ns.ByOutput or {}) do
        if ns.ItemName(id) == name then return id end
    end
    return nil
end
MK.ItemByName = ItemByName

-- pieces of an invoice: count when the client gives it; in WoW Forever the field "buyout" holds the quantity and
-- "bid" the total (rule book section 2, raw line 9 Nov.: 8082 / 18 / 100 / 404 / count 18)
function MK.InvoicePieces(buyout, count)
    if type(count) == "number" and count > 0 then return count end
    if ns.IsForever and type(buyout) == "number" and buyout > 0 and buyout < 10000 then return buyout end
    return 1
end

-- read the invoices of the mailbox (seller: own auction sold); nothing is opened, taken or deleted
function MK.ReadInvoices()
    local num = ns.API.GetInboxNumItems
    local inv = ns.API.GetInboxInvoiceInfo
    if not (num and inv) then return 0 end
    local okN, n = pcall(num)
    if not okN or type(n) ~= "number" then return 0 end
    local found = 0
    for i = 1, n do
        local ok, kind, itemName, _, bid, buyout, deposit, consignment, _, _, _, count = pcall(inv, i)
        -- protected values (WoW Forever): asked first, never compared
        local secret = ok and ns.IsSecret and (ns.IsSecret(kind) or ns.IsSecret(itemName) or ns.IsSecret(bid))
        if ok and not secret and type(kind) == "string" and kind == "seller" and type(itemName) == "string"
            and type(bid) == "number" then
            local id = MK.ItemByName(itemName)
            if id then
                -- bid = total of the sale, consignment = the AH's 5 %; the deposit comes back and is no proceeds
                local pieces = MK.InvoicePieces(buyout, count)
                local net = (bid - (type(consignment) == "number" and consignment or 0)) / pieces
                local key = table.concat({ itemName, bid, tonumber(deposit) or 0, tonumber(consignment) or 0, pieces }, "|")
                if MK.OnSale(id, net, key) ~= nil then found = found + 1 end
            end
        end
    end
    MK.Expire()
    return found
end

---------------------------------------------------------------------------
-- TU5: the basic rules on the real data (read only). Violations go into the diagnostic log
-- ("GRUNDREGEL VERLETZT …", no player names) – after a price change at most every 10 minutes, in portions.
---------------------------------------------------------------------------
-- violations of one recipe calculation: list of texts (empty = all rules hold)
function MK.CheckRules(r, pr)
    local bad = {}
    if not (r and pr) then return bad end
    if (r.yellow or 0) > 0 and not ((r.req or 0) <= (r.yellow or 0) and r.yellow <= (r.green or 0) and (r.green or 0) <= (r.grey or 0)) then
        bad[#bad + 1] = string.format("Farbstufen %s/%s/%s/%s", tostring(r.req), tostring(r.yellow), tostring(r.green), tostring(r.grey))
    end
    if not (pr.known and r.out) then return bad end
    if math.abs((pr.value - pr.cost) - pr.net) > 1 then
        bad[#bad + 1] = string.format("Gewinn %d ≠ Wert %d − Zutaten %d", pr.net, pr.value, pr.cost)
    end
    if pr.valueAH and pr.ahCut and pr.valueSource == "ah" and not pr.worthUpTo then
        local cut = PS().Cut(math.floor(pr.valueAH / MK.Made(r) + 0.5)) * MK.Made(r)
        if math.abs(cut - pr.ahCut) > MK.Made(r) then
            bad[#bad + 1] = string.format("AH-Anteil %d statt %d (5 %%)", pr.ahCut, cut)
        end
    end
    if pr.pct and pr.pct > MK.MAX_PCT and not pr.flag then
        bad[#bad + 1] = string.format("Gewinn %d %% ohne Hinweis", pr.pct)
    end
    local pi = MK.Info(r.out)
    if pi.offers and pi.offers < MK.THIN_OFFERS and pr.valueSource == "ah" and not pr.flag then
        bad[#bad + 1] = string.format("%d Angebote ohne Hinweis", pi.offers)
    end
    return bad
end

MK.CHECK_EVERY = 600
MK.CHECK_PORTION = 40
function MK.CheckReal(done)
    if MK.checking then return false end
    -- never during the test routine (its test data are no real data); its case TU5 switches it on itself
    if ns.TestRoutine and ns.TestRoutine.Running and ns.TestRoutine.Running() and not MK.testCheck then return false end
    local now = Now()
    if MK.lastCheck and now - MK.lastCheck < MK.CHECK_EVERY then return false end
    if not (ns.Scan and ns.Prices and ns.Prices.SourceName()) then return false end
    MK.lastCheck, MK.checking = now, true
    local list = {}
    for _, p in ipairs(ns.Scan:PlayerProfessions() or {}) do
        for _, r in ipairs(ns.ByProf[p.id] or {}) do
            if r.out and ns.IsLearned and ns.IsLearned(r) then list[#list + 1] = r end
        end
    end
    local i, found = 0, 0
    local function step()
        local stop = math.min(#list, i + MK.CHECK_PORTION)
        ns.Prices.InPass(function()
            for k = i + 1, stop do
                local r = list[k]
                local ok, pr = pcall(ns.Prices.Recipe, r, true)
                if ok and pr then
                    for _, b in ipairs(MK.CheckRules(r, pr)) do
                        found = found + 1
                        if ns.Diag then pcall(ns.Diag, "GRUNDREGEL", "VERLETZT " .. tostring(r.spell) .. ": " .. b) end
                    end
                end
            end
        end)
        i = stop
        if i < #list and ns.API.TimerAfter then
            ns.API.TimerAfter(0.1, step)
        else
            MK.checking = false
            MK.lastFound = found
            if done then done(found, #list) end
        end
    end
    step()
    return true
end

---------------------------------------------------------------------------
-- Events: own invoices (PM6) and the check after a price change (TU5)
---------------------------------------------------------------------------
local frame = ns.AddEventFrame and ns.AddEventFrame(CreateFrame("Frame"), "Market") or CreateFrame("Frame")
pcall(frame.RegisterEvent, frame, "MAIL_INBOX_UPDATE")
frame:SetScript("OnEvent", function(_, event)
    if not (ns.Flavor and ns.db) then return end
    if event == "MAIL_INBOX_UPDATE" then
        local ok, err = pcall(MK.ReadInvoices)
        if not ok and ns.CountError then ns.CountError("Market:ReadInvoices", err) end
    end
end)
MK.frame = frame
