local _, ns = ...
local L = ns.L

-- Adds "learned / not learned" info to recipe item tooltips (vendors, auction house, bags).

-- Material tooltip: which recipes use this item, which of them you know (also raid materials such
-- as Lava Core or Fiery Core – every reagent of the client data counts)
function ns.ReagentLines(tooltip, itemID)
    local list = ns.ByReagent and ns.ByReagent[itemID]
    if not list or #list == 0 then return end
    if tooltip.__psItem == itemID then return end
    tooltip.__psItem = itemID
    local c = ns.Char()
    local byProf, known, total = {}, {}, 0
    for _, r in ipairs(list) do
        total = total + 1
        byProf[r.prof] = (byProf[r.prof] or 0) + 1
        if c and c.profs[r.prof] and ns.IsLearned(r) then known[#known + 1] = r end
    end
    local parts = {}
    for prof, n in pairs(byProf) do parts[#parts + 1] = ns.ProfName(prof) .. " " .. n end
    table.sort(parts)
    tooltip:AddLine(" ")
    tooltip:AddLine("|cff3fc7ebProfessionSentinel:|r " .. string.format(L.REAGENT_USED, total, table.concat(parts, ", ")), 0.8, 0.8, 0.8, true)
    if #known > 0 then
        table.sort(known, function(a, b) return (a.yellow or 0) > (b.yellow or 0) end)
        local names = {}
        for i, r in ipairs(known) do
            if i > 4 then names[#names + 1] = string.format(L.MORE, #known - 4); break end
            names[#names + 1] = ns.RecipeName(r)
        end
        tooltip:AddLine(L.REAGENT_YOU_KNOW .. ": |cffffffff" .. table.concat(names, ", ") .. "|r", 0.6, 0.6, 0.6, true)
    end
end

local function AddLines(tooltip, itemID)
    -- protected value: never use it – asked first, before any test or comparison of itemID
    if ns.IsSecret(itemID) or type(itemID) ~= "number" then return end
    if not ns.Flavor or not ns.db or not ns.db.tooltip then return end
    if tooltip.__psItem == itemID then return end
    local r = ns.ByRecipeItem[itemID]
    if not r then
        if ns.db.reagentTooltip ~= false then ns.ReagentLines(tooltip, itemID) end
        return
    end
    tooltip.__psItem = itemID
    local c = ns.Char()
    local rank = c and c.profs[r.prof] and c.profs[r.prof].rank
    rank = ns.EffectiveRank(rank)
    local UI = ns.UI
    -- tooltip variant A (9 Nov. 17:55): block 1 "Pattern · missing / learnable from …", block 2 the verdict of the
    -- crafted item (the same profit as the panel), no material block; the rest with Shift
    local learned = ns.IsLearned(r)
    local st
    if learned then st = "|cff7f7f7f" .. L.TT_LEARNED .. "|r"
    elseif rank and (r.req or 0) > 1 and rank < r.req then
        st = "|cffff4040" .. L.TT_MISSING .. " · " .. string.format(L.TT_LEARNABLE_FROM, r.req) .. "|r"
    elseif rank then st = "|cff1eff00" .. L.TT_LEARNABLE .. "|r"
    else st = "|cffff4040" .. L.TT_MISSING .. "|r" end
    tooltip:AddLine(" ")
    tooltip:AddDoubleLine("|cff3fc7ebProfessionSentinel:|r " .. L.TT_PATTERN .. " · " .. st,
        (UI and UI.TipColour and not learned) and UI.TipColour(r, rank) or "", 0.8, 0.8, 0.8, 1, 1, 1)
    if UI and UI.TipVerdict and ns.Prices and r.out then
        local ok, pr = pcall(ns.Prices.Recipe, r, true)
        if ok and pr then UI.TipVerdict(tooltip, r, pr, nil) end
    end
    if not (UI and UI.ShiftDown and UI.ShiftDown()) then
        tooltip:AddLine(L.TT_SHIFT_HINT, 0.5, 0.5, 0.5)
        tooltip:Show()
        return
    end
    local knownBy, missingBy = ns.Scan:CharsFor(r.spell, r.prof)
    local me = ns.PlayerName()           -- remembered at login, never a protected value (combat)
    local function others(list)
        local out = {}
        for _, n in ipairs(list) do if n ~= me then out[#out + 1] = n end end
        return out
    end
    knownBy, missingBy = others(knownBy), others(missingBy)
    -- WoW Forever supply camps: cost in Merchant's Favor (and reputation)
    local FV = ns.Favor
    if FV and FV.Active() then
        local ri
        for _, x in ipairs(r.recipeItems or {}) do if x.id == itemID then ri = x end end
        local ct = ri and FV.CostText(ri)
        if ct then
            tooltip:AddLine(L.FAVOR_COST .. ": " .. ct, 0.8, 0.8, 0.8, true)
            local rep = ri.fr and ri.fr > 0 and ns.RepLine(FV.Faction(ri.fa), ri.fr)
            if rep then tooltip:AddLine(rep, 1, 1, 1, true) end
        end
    end
    local GU = ns.Guild
    local crafters = GU and GU.Crafters(r)
    if crafters and #crafters > 0 then tooltip:AddLine(L.GUILD_CRAFTERS .. ": " .. GU.CraftersText(crafters), 0.6, 0.6, 0.6, true) end
    if #knownBy > 0 then tooltip:AddLine(L.KNOWN_BY .. ": |cffffffff" .. table.concat(knownBy, ", ") .. "|r", 0.6, 0.6, 0.6, true) end
    if #missingBy > 0 then tooltip:AddLine(L.MISSING_BY .. ": |cffffffff" .. table.concat(missingBy, ", ") .. "|r", 0.6, 0.6, 0.6, true) end
    tooltip:Show()
end

local function ItemIDFromTooltip(tooltip, data)
    if data then
        local id = data.id
        if ns.IsSecret(id) then return nil end           -- IsSecret first, then compare
        if id ~= nil then return id end
    end
    if tooltip.GetItem then
        local _, link = tooltip:GetItem()
        if not ns.IsSecret(link) and type(link) == "string" then return tonumber(link:match("item:(%d+)")) end
    end
end
ns.TooltipItemID = ItemIDFromTooltip
ns.TooltipAddLines = AddLines

local hooked = {}
local function HookTooltip(tt)
    if not tt or hooked[tt] then return end
    hooked[tt] = true
    tt:HookScript("OnTooltipCleared", function(self) self.__psItem = nil end)
    if not (TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall) then
        pcall(tt.HookScript, tt, "OnTooltipSetItem", function(self) AddLines(self, ItemIDFromTooltip(self)) end)
    end
end

local f = ns.AddEventFrame(CreateFrame("Frame"), "Tooltip")
f:RegisterEvent("PLAYER_LOGIN")
local done = false
f:SetScript("OnEvent", function()
    if not ns.Flavor or done then return end
    done = true
    ns.TooltipHooked = true
    for _, tt in ipairs({ GameTooltip, ItemRefTooltip, ShoppingTooltip1, ShoppingTooltip2 }) do HookTooltip(tt) end
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tooltip, data)
            AddLines(tooltip, ItemIDFromTooltip(tooltip, data))
        end)
    end
end)
