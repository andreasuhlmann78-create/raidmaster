-- LevelPilot - Hoehlen, Minen, Tunnel
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Ein Ziel in einer Hoehle liegt auf der Karte oft mitten im Berg. Der Weg muss zuerst zum
-- Eingang und erst dann hinein; umgekehrt aus der Hoehle heraus erst zum Eingang.
--
-- Lernen: Wechselt der Spieler von draussen nach drinnen (IsIndoors, kein Gasthaus/Stadt,
-- keine Instanz), ist die letzte Stelle draussen der Eingang. Der dann begangene Innenraum
-- (Mitte, Radius) gehoert dazu. Kommt man an einer weit entfernten Stelle wieder heraus (Tunnel,
-- zweiter Ausgang), wird auch diese als Eingang desselben Innenraums gespeichert.
-- Speicher: LP.db.caves (Weltkoordinaten), geteilt ueber den Datenaustausch, gesichert wie alle
-- gesammelten Daten. Gelernte Eingaenge haben Vorrang vor den Startwerten.

local _, LP = ...
local L = LP.L
local Ca = {}
LP:RegisterModule("Caves", Ca)

local MIN_DEPTH = 35          -- Yards: so weit muss man hinein, damit es als Hoehle zaehlt
local ENTRY_GAP = 30          -- Yards: letzte Position draussen hoechstens so weit vor dem Wechsel
local MERGE = 30              -- Yards: Eingaenge naeher als das sind derselbe Eingang
local SECOND_EXIT = 45        -- Yards: Ausgang weiter weg als das = eigener Eingang (Tunnel)
local R_MIN, R_MAX = 20, 300  -- Yards: Innenraum-Radius
local NEAR_ENTRANCE = 20      -- Yards: so nah am Eingang gilt man noch als draussen

local list = {}               -- alle bekannten Eingaenge (Laufzeit)
local session, lastOut = nil, nil

local function Dist(n1, w1, n2, w2) return LP.Geo:Dist(n1, w1, n2, w2) end

local function Key(inst, n, w)
    return string.format("%d:%d:%d", inst, math.floor(n / 10 + 0.5), math.floor(w / 10 + 0.5))
end

------------------------------------------------------------------------
-- Aufbau der Liste: Startwerte, Startdatenbank, eigene und empfangene
------------------------------------------------------------------------
local function AddEntry(e) list[#list + 1] = e end

local function FromSeed()
    local tf = LP.API and LP.API.Forever and LP.API.Forever() and LP.CaveForeverMaps or {}
    for _, s in ipairs(LP.CaveSeed or {}) do
        local map, ex, ey, cx, cy, rp, name = s[1], s[2], s[3], s[4], s[5], s[6], s[7]
        local t = tf[map]
        if t then
            ex, ey = t[1] * ex + t[2], t[3] * ey + t[4]
            cx, cy = t[1] * cx + t[2], t[3] * cy + t[4]
            rp = rp * t[1]
        end
        local i, en, ew = LP.Geo:ToWorld(map, ex, ey)
        local ci, cn, cw = LP.Geo:ToWorld(map, cx, cy)
        local _, rn, rw = LP.Geo:ToWorld(map, cx + rp, cy)
        if i and ci == i and rn then
            AddEntry({ inst = i, n = en, w = ew, map = map, cn = cn, cw = cw, r = Dist(cn, cw, rn, rw), name = name, src = "base" })
        end
    end
end

local function FromStored(t, src)
    for _, c in pairs(t or {}) do
        if type(c) == "table" and c.i and c.en and c.cn then
            AddEntry({ inst = c.i, n = c.en, w = c.ew, map = c.m, cn = c.cn, cw = c.cw, r = c.r or 60,
                       name = c.name, src = src or (c.net and "net" or "own"), count = c.c or 1 })
        end
    end
end

function Ca:Rebuild()
    wipe(list)
    FromStored(LP.db.caves)
    local seed = LP.Seed and LP.Seed.caves
    if seed then FromStored(seed, "seed") end
    -- Startwerte nur, wo noch kein gelernter Eingang liegt
    local before = #list
    FromSeed()
    for i = #list, before + 1, -1 do
        local s = list[i]
        for j = 1, before do
            local o = list[j]
            if o.inst == s.inst and Dist(o.n, o.w, s.n, s.w) < MERGE * 2 then table.remove(list, i) break end
        end
    end
end

function Ca:All() return list end

function Ca:Count()
    local own, net = 0, 0
    for _, c in pairs(LP.db.caves or {}) do if c.net then net = net + 1 else own = own + 1 end end
    return #list, own, net
end

------------------------------------------------------------------------
-- Abfrage: liegt ein Punkt in einer Hoehle? Bei mehreren Eingaengen der zum Bezugspunkt naechste.
-- player = true: Startpunkt des Spielers (dann muss das Spiel "drinnen" melden, falls es das kann)
------------------------------------------------------------------------
function Ca:At(inst, n, w, refN, refW, player)
    if not inst or #list == 0 then return nil end
    if player and IsIndoors and not LP.Indoors() then return nil end
    local best, bestD
    for _, c in ipairs(list) do
        if c.inst == inst and Dist(n, w, c.cn, c.cw) <= c.r and Dist(n, w, c.n, c.w) > NEAR_ENTRANCE then
            local d = refN and Dist(refN, refW, c.n, c.w) or 0
            if not bestD or d < bestD then best, bestD = c, d end
        end
    end
    return best
end

-- gleicher Innenraum? (zwei Eingaenge derselben Hoehle)
function Ca:Same(a, b)
    if not a or not b then return a == b end
    if a == b then return true end
    return a.inst == b.inst and Dist(a.cn, a.cw, b.cn, b.cw) < math.min(a.r, b.r)
end

------------------------------------------------------------------------
-- Speichern / Zusammenfuehren
------------------------------------------------------------------------
-- c = { i, en, ew, m, cn, cw, r }; net = von einem anderen Spieler
function Ca:Store(c, net)
    LP.db.caves = LP.db.caves or {}
    local db = LP.db.caves
    for _, o in pairs(db) do
        if o.i == c.i and Dist(o.en, o.ew, c.en, c.ew) < MERGE then
            if net and not o.net then
                o.by = (o.by or 0) + 1                 -- eigene Beobachtung bleibt, nur bestaetigen
                return false
            end
            if not net and o.net then
                -- eigene Beobachtung ersetzt empfangene
                o.net, o.by = nil, nil
                o.en, o.ew, o.cn, o.cw, o.r, o.m, o.c = c.en, c.ew, c.cn, c.cw, c.r, c.m, 1
                return true
            end
            -- gleiche Herkunft: Mittelwert, Innenraum waechst mit
            local k = math.min(o.c or 1, 20)
            o.en = (o.en * k + c.en) / (k + 1)
            o.ew = (o.ew * k + c.ew) / (k + 1)
            o.cn = (o.cn * k + c.cn) / (k + 1)
            o.cw = (o.cw * k + c.cw) / (k + 1)
            o.r = math.min(R_MAX, math.max(o.r or R_MIN, c.r))
            o.c = (o.c or 1) + 1
            return false
        end
    end
    local key = Key(c.i, c.en, c.ew)
    db[key] = { i = c.i, en = c.en, ew = c.ew, m = c.m, cn = c.cn, cw = c.cw, r = c.r, c = 1,
                net = net or nil, t = LP:Now() }
    return true, key
end

local function Learned(entry, exit, sess)
    local cn, cw = sess.sn / sess.cnt, sess.sw / sess.cnt
    local r = 0
    for _, p in ipairs(sess.pts) do r = math.max(r, Dist(cn, cw, p[1], p[2])) end
    r = math.max(R_MIN, math.min(R_MAX, r + 12))
    local new = {}
    local function add(p)
        local c = { i = p[1], en = p[2], ew = p[3], m = p[4], cn = cn, cw = cw, r = r }
        local isNew, key = Ca:Store(c, false)
        if isNew then new[#new + 1] = key end
    end
    add(entry)
    if exit and exit[1] == entry[1] and Dist(exit[2], exit[3], entry[2], entry[3]) > SECOND_EXIT then add(exit) end
    Ca:Rebuild()
    for _, key in ipairs(new) do LP:Fire("CAVE_LEARNED", key) end
    LP:Debug("Hoehle gelernt: " .. #new .. " neu, Radius " .. math.floor(r))
end

------------------------------------------------------------------------
-- Beobachten (jede Sekunde)
------------------------------------------------------------------------
local function CanWatch()
    if not LP.db.recordPaths then return false end
    if LP.SafeValue(UnitOnTaxi("player")) or LP.SafeValue(UnitIsDeadOrGhost("player")) then return false end
    if IsInInstance and IsInInstance() then return false end
    return IsIndoors ~= nil
end

function Ca:Tick()
    if not CanWatch() then session, lastOut = nil, nil return end
    local inst, n, w, map = LP.Geo:Player()
    if not inst then return end
    local now = GetTime()
    local resting = LP.Resting()
    if LP.Indoors() then
        if resting then session = nil return end         -- Gasthaus, Stadt: kein Hoehleneingang
        if not session then
            local ok = lastOut and now - lastOut[5] <= 4 and lastOut[1] == inst
                       and Dist(lastOut[2], lastOut[3], n, w) <= ENTRY_GAP
            session = { entry = ok and lastOut or nil, pts = {}, sn = 0, sw = 0, cnt = 0, far = 0 }
        end
        if session.entry then
            local last = session.pts[#session.pts]
            if not last or Dist(last[1], last[2], n, w) >= 5 then
                session.pts[#session.pts + 1] = { n, w }
                session.sn, session.sw, session.cnt = session.sn + n, session.sw + w, session.cnt + 1
                session.far = math.max(session.far, Dist(session.entry[2], session.entry[3], n, w))
            end
        end
    else
        if session and session.entry and session.far >= MIN_DEPTH and session.cnt >= 4 then
            LP:Safe("Höhle", Learned, session.entry, { inst, n, w, map }, session)
        end
        session = nil
        lastOut = { inst, n, w, map, now }
    end
end

function Ca:Init()
    LP.db.caves = LP.db.caves or {}
    self:Rebuild()
    LP:Ticker("caves", 1, function() Ca:Tick() end)
    LP:Listen("CAVES_CHANGED", function() Ca:Rebuild() end)
end
