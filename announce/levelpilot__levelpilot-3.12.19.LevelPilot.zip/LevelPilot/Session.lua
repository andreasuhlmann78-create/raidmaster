-- LevelPilot - Sitzung: aktive Zeit, Gold pro Stunde, Bestzeiten, Zeit-Schaetzungen, Erholt-Bonus,
-- Ruhestein, "Wo war ich?", Abgaben-Erinnerung, Bilanz beim Ausloggen
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.

local _, LP = ...
local L = LP.L
local Se = {}
LP:RegisterModule("Session", Se)

local IDLE = 300              -- Sekunden ohne Bewegung, EP und Gold: Zeit zaehlt nicht mehr
local WINDOW = 3600           -- Gold der letzten (aktiven) Stunde
local clock = 0               -- aktive Spielzeit dieser Sitzung (ohne AFK)
local lastActive = 0          -- GetTime() der letzten Aktivitaet
local lastPos
local goldSamples, goldTotal = {}, 0
local lastMoney
Se.stats = { levels = 0, quests = 0, gold = 0, deaths = 0, start = 0 }
local progress = {}           -- [quest:ziel] = { t0 (aktive Zeit), have0, t, have }

------------------------------------------------------------------------
-- Aktive Zeit
------------------------------------------------------------------------
function Se:Clock() return clock end

local function Active() lastActive = GetTime() end
Se.MarkActive = Active

-- 3.12.14: UnitIsAFK ist in Forever zeitweise geschuetzt -> dann nur der eigene Leerlauf-Zaehler (IDLE)
function Se:IsAFK()
    if UnitIsAFK and LP.SafeValue(UnitIsAFK("player")) then return true end
    return GetTime() - lastActive > IDLE
end

local function Tick()
    local inst, n, w = LP.Geo:Player()
    if inst and lastPos and (lastPos[1] ~= inst or LP.Geo:Dist(lastPos[2], lastPos[3], n, w) > 2) then Active() end
    if inst then lastPos = { inst, n, w } end
    if not Se:IsAFK() then clock = clock + 1 end
end

------------------------------------------------------------------------
-- Gold
------------------------------------------------------------------------
function Se.Money(copper)
    copper = math.floor(copper or 0)
    local g, s = math.floor(copper / 10000), math.floor(copper / 100) % 100
    if g > 0 then return string.format("%dg %02ds", g, s) end
    if s > 0 then return string.format("%ds %02dc", s, copper % 100) end
    return string.format("%dc", copper % 100)
end

local function OnMoney()
    local m = GetMoney and GetMoney() or 0
    if lastMoney then
        local d = m - lastMoney
        if d > 0 then
            goldTotal = goldTotal + d
            goldSamples[#goldSamples + 1] = { clock, goldTotal, d }
        end
        Se.stats.gold = Se.stats.gold + d
        Active()
    end
    lastMoney = m
end

-- Einnahmen pro aktive Stunde (Beute, Verkaeufe, Questbelohnungen); nil = zu wenig gespielt
function Se:GoldPerHour()
    while #goldSamples > 0 and goldSamples[1][1] < clock - WINDOW do table.remove(goldSamples, 1) end
    if clock < 300 then return nil end
    local sum = 0
    for _, s in ipairs(goldSamples) do sum = sum + s[3] end
    local span = math.max(300, math.min(clock, WINDOW))
    return sum / span * 3600
end

------------------------------------------------------------------------
-- Bestzeiten je Level (ueber alle Charaktere des Accounts)
------------------------------------------------------------------------
local function OnLevelUp(newLevel)
    Se.stats.levels = Se.stats.levels + 1
    local old = (newLevel or LP:RealLevel() or 2) - 1
    local spent = LP.char.levelTimes and LP.char.levelTimes[old]
    if not spent or spent < 30 then return end
    LP.db.bestLevel = LP.db.bestLevel or {}
    local best = LP.db.bestLevel[old]
    local me = UnitName("player") or "?"
    local Dur = LP.Comfort.Dur
    if not best then
        LP.db.bestLevel[old] = { t = spent, who = me }
    elseif spent < best.t then
        LP:Print(L("Level %d in %s – neuer Bestwert (%s schneller als %s)", old, Dur(spent), Dur(best.t - spent), best.who or "?"))
        LP.db.bestLevel[old] = { t = spent, who = me }
    else
        LP:Print(L("Level %d in %s – Bestwert %s (%s)", old, Dur(spent), Dur(best.t), best.who or "?"))
    end
end

function Se:BestText(level)
    local b = LP.db.bestLevel and LP.db.bestLevel[level]
    if not b then return nil end
    return L("Bestwert %s (%s)", LP.Comfort.Dur(b.t), b.who or "?")
end

------------------------------------------------------------------------
-- Zeit-Schaetzung je Ziel und fuer die Zone
------------------------------------------------------------------------
local KIND_UNIT = { monster = 40, item = 55, object = 30 }

local function TrackProgress()
    local now = clock
    for id, st in pairs(LP.Planner.inLog or {}) do
        if st.index and not st.complete then
            for oi, o in ipairs(LP.API.Objectives(st.index) or {}) do
                local k = id .. ":" .. oi
                local p = progress[k]
                if not p then
                    progress[k] = { t0 = now, have0 = o.have or 0, t = now, have = o.have or 0 }
                elseif (o.have or 0) ~= p.have then
                    p.t, p.have = now, o.have or 0
                end
            end
        end
    end
end

-- Sekunden bis das Ziel fertig ist (eigenes Tempo, sonst Erfahrungswert)
function Se:ObjectiveETA(id, oi, o)
    if not o or o.finished or not o.need then return 0 end
    local left = o.need - (o.have or 0)
    if left <= 0 then return 0 end
    local p = progress[id .. ":" .. oi]
    local per = KIND_UNIT[o.type or ""] or 45
    if p and p.have > p.have0 and p.t > p.t0 then per = (p.t - p.t0) / (p.have - p.have0) end
    return left * per
end

function Se:QuestETA(id)
    local st = LP.Planner.inLog[id]
    if not st or not st.index or st.complete then return nil end
    local sum = 0
    for oi, o in ipairs(LP.API.Objectives(st.index) or {}) do sum = sum + self:ObjectiveETA(id, oi, o) end
    return sum > 0 and sum or nil
end

-- Rest der aktuellen Zone: offene Ziele + 30 s je Annahme/Abgabe
function Se:ZoneETA()
    local focus = LP.Planner.focus
    if not focus then return nil end
    local sum, n = 0, 0
    for _, s in ipairs(LP.Engine:Steps()) do
        if LP.Planner.ZoneOf(s.map) == focus then
            if s.t == "COMPLETE" and s.id then sum = sum + (self:QuestETA(s.id) or 0) n = n + 1
            elseif s.t == "ACCEPT" or s.t == "TURNIN" then sum = sum + 30 n = n + 1 end
        end
    end
    if n < 2 then return nil end
    return sum
end

function Se:EtaText(step)
    if not LP.db.showEta or not step or step.t ~= "COMPLETE" or not step.id then return nil end
    local s = self:QuestETA(step.id)
    if not s then return nil end
    -- Weg dorthin gehoert dazu (zu Fuss ~7 Yards/s, ab Level 40 mit Reittier schneller)
    if step == LP.Engine:Current() and LP.Nav and LP.Nav.RemainingDistance then
        local d = LP.Nav:RemainingDistance()
        if d and d > 50 then s = s + d / (LP:PlayerLevel() >= 40 and 11 or 7) end
    end
    return L("ca. %s", LP.Comfort.Dur(s))
end

------------------------------------------------------------------------
-- Kopfzeile: Erholt-Bonus, Ruhestein, Zone
------------------------------------------------------------------------
function Se:ExtraText()
    local parts = {}
    if LP.db.showRested and GetXPExhaustion then
        local r = LP.SafeValue(GetXPExhaustion())
        if type(r) == "number" and r > 0 then
            local k = r >= 10000 and string.format("%.0fk", r / 1000) or string.format("%.1fk", r / 1000)
            parts[#parts + 1] = L("Erholt %s", k)
        end
    end
    if LP.db.showHearthCD and LP.API.ItemCount(LP.API.HEARTHSTONE) > 0 then
        local cd = LP.API.ItemCooldown(LP.API.HEARTHSTONE)
        parts[#parts + 1] = cd > 0 and L("Ruhestein %s", LP.Comfort.Dur(cd)) or L["Ruhestein bereit"]
    end
    if LP.db.showEta then
        local z = self:ZoneETA()
        if z then parts[#parts + 1] = L("Zone ca. %s", LP.Comfort.Dur(z)) end
    end
    return #parts > 0 and table.concat(parts, " · ") or nil
end

local function RestedHint(add)
    if not LP.db.showRested or not LP.Resting() then return end
    local r = GetXPExhaustion and LP.SafeValue(GetXPExhaustion()) or 0
    if type(r) ~= "number" then r = 0 end
    local _, mx = LP:PlayerXP()
    local max = mx * 1.5
    if LP:RealLevel() < 60 and r < max then
        add("rested", LP.Advisor.SEV_INFO, L["Erholungsgebiet: Wenn du hier ausloggst, sammelst du Erholt-Bonus (doppelte EP für Monster)."])
    end
end

------------------------------------------------------------------------
-- "Wo war ich?" beim Einloggen
------------------------------------------------------------------------
function Se:WelcomeText()
    local steps = LP.Engine:Steps()
    if #steps == 0 then return nil end
    local lines = { L["|cffffb238LevelPilot|r – Willkommen zurück!"] }
    local focus = LP.Planner.focus
    if focus then lines[#lines + 1] = L("Zone: %s", LP.Geo:MapName(focus)) end
    for i = 1, math.min(3, #steps) do
        local t = LP.UI:StepText(steps[i], false):match("^[^\n]*") or ""
        lines[#lines + 1] = i .. ") " .. t
    end
    local turnins = 0
    for _, st in pairs(LP.Planner.inLog or {}) do if st.complete then turnins = turnins + 1 end end
    if turnins > 0 then lines[#lines + 1] = L("Fertige Quests zum Abgeben: %d", turnins) end
    return table.concat(lines, "\n")
end

-- einmalige Zeile in der Begruessung (3.12.5): Nachkaufen und Belohnung anlegen sind ab Werk aus
function Se:OptionTip()
    if LP.db.optTipShown then return nil end
    LP.db.optTipShown = true
    if LP.db.restock and LP.db.autoEquipRewards then return nil end      -- beides schon an: kein Tipp noetig
    return L["Tipp: Nachkaufen und Belohnung anlegen sind ab Werk aus – einschalten in der Zentrale."]
end

------------------------------------------------------------------------
-- Abgaben nicht vergessen
------------------------------------------------------------------------
local lastZone

function Se:OpenTurnins(map)
    local list = {}
    for id, st in pairs(LP.Planner.inLog or {}) do
        if st.complete then
            local q = LP.QuestDB:Get(id)
            local e = q and q.ends and q.ends[1]
            if e and e[1] == map then list[#list + 1] = st.title or (q and q.name) or ("#" .. id) end
        end
    end
    return list
end

local function OnZoneChange()
    local _, _, _, map = LP.Geo:Player()
    if not map then return end
    local old = lastZone
    lastZone = map
    if not LP.db.turninReminder or not old or old == map then return end
    local list = Se:OpenTurnins(old)
    if #list == 0 then return end
    -- plant die Route ohnehin gleich zurueck? dann kein Hinweis
    for i, s in ipairs(LP.Engine:Steps()) do
        if i > 5 then break end
        if s.t == "TURNIN" and s.map == old then return end
    end
    local msg = L("%d fertige Quest(s) in %s noch nicht abgegeben: %s", #list, LP.Geo:MapName(old), table.concat(list, ", "))
    LP:Print(msg)
    if UIErrorsFrame and UIErrorsFrame.AddMessage then UIErrorsFrame:AddMessage(msg, 1, 0.55, 0.2) end
    Se.lastReminder = msg
end

------------------------------------------------------------------------
-- Bilanz
------------------------------------------------------------------------
function Se:SummaryText()
    local st = self.stats
    local gold = st.gold >= 0 and Se.Money(st.gold) or ("-" .. Se.Money(-st.gold))
    return L("LevelPilot-Bilanz: %d Level, %d Quests, %s, %s aktiv gespielt", st.levels, st.quests, gold,
             LP.Comfort.Dur(clock))
end

function Se:Summary(toGuild)
    local text = self:SummaryText()
    LP:Print(text)
    -- nur auf Befehl des Spielers (/lp bilanz gilde); moderner Client: C_ChatInfo.SendChatMessage
    local send = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
    if toGuild and IsInGuild and IsInGuild() and send then
        LP.Act.Call("SendChatMessage", send, text, "GUILD")
    end
    return text
end

------------------------------------------------------------------------
-- Nach dem Tod: Pfeil zur Leiche
------------------------------------------------------------------------
local corpseTipShown = false

function Se:CorpseTarget()
    if not (UnitIsGhost and LP.SafeValue(UnitIsGhost("player"))) then corpseTipShown = false return nil end
    if not (C_DeathInfo and C_DeathInfo.GetCorpseMapPosition) then return nil end
    local _, _, _, map = LP.Geo:Player()
    if not map then return nil end
    local pos = C_DeathInfo.GetCorpseMapPosition(map)
    if not (pos and pos.GetXY) then return nil end
    local x, y = pos:GetXY()
    if not x or not y or (x == 0 and y == 0) then return nil end
    local i, n, w = LP.Geo:ToWorld(map, x * 100, y * 100)
    if not i then return nil end
    if not corpseTipShown then
        corpseTipShown = true
        local pi, pn, pw = LP.Geo:Player()
        local d = pi == i and LP.Geo:Dist(pn, pw, n, w) or nil
        if LP:RealLevel() <= 10 and d and d > 500 then
            LP:Print(L["Tipp: Bis Level 10 hat der Geistheiler keine Nachwirkungen – bei weitem Weg lohnt er sich (kostet Haltbarkeit)."])
        end
    end
    return { inst = i, n = n, w = w, map = map, key = "CORPSE", label = L["Zur Leiche"] }
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
function Se:Init()
    if LP.Nav and LP.Nav.AddOverride then LP.Nav:AddOverride(function() return Se:CorpseTarget() end, 100) end
    lastActive = GetTime()
    lastMoney = GetMoney and GetMoney() or 0
    Se.stats.start = GetTime()
    LP:Ticker("session", 1, Tick)
    LP:On("PLAYER_MONEY", OnMoney)
    LP:On("PLAYER_XP_UPDATE", Active)
    LP:On("PLAYER_LEVEL_UP", function(_, lvl) C_Timer.After(0.3, function() OnLevelUp(lvl) end) end)
    LP:On("QUEST_TURNED_IN", function() Se.stats.quests = Se.stats.quests + 1 Active() end)
    LP:On("PLAYER_DEAD", function() Se.stats.deaths = Se.stats.deaths + 1 end)
    LP:On("QUEST_LOG_UPDATE", function() LP:Throttle("session_prog", 1, TrackProgress) Active() end)
    LP:On("ZONE_CHANGED_NEW_AREA", function() C_Timer.After(1, OnZoneChange) end)
    LP:On("PLAYER_CAMPING", function() if LP.db.logoutSummary then Se:Summary(LP.db.summaryGuild) end end)
    LP:On("PLAYER_ENTERING_WORLD", function(_, isLogin, isReload)
        local _, _, _, map = LP.Geo:Player()
        lastZone = lastZone or map
        if isLogin and LP.db.welcomeSummary then
            C_Timer.After(6, function()
                local t = Se:WelcomeText()
                local tip = Se:OptionTip()
                if t and tip then t = t .. "\n" .. tip elseif tip then t = tip end
                if t then LP:Print(t) end
            end)
        end
    end)
    if LP.Advisor and LP.Advisor.AddProvider then LP.Advisor:AddProvider(RestedHint) end
end
