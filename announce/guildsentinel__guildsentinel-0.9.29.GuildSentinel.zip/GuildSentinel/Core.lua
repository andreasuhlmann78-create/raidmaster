-- GuildSentinel - Core.lua
-- Grundlagen: Datenbank, Ereignisse, Hilfsfunktionen, Slash-Befehle.
--
-- GuildSentinelDB = {
--   settings = { ... },                        -- für alle Charaktere gleich (Fenster, Minimap ...)
--   guilds = { ["Realm|Gilde"] = G },          -- je Gilde eigene Daten
-- }
-- G = {
--   roster   = { [Name] = { c, l, r, ri, z, no, on, seen, first } }   -- letzter bekannter Stand
--   log      = { { t, k, n, x } }               -- Verlauf (beigetreten, verlassen, befördert ...)
--   notes    = { [Name] = "Eigene Notiz" }      -- nur für mich
--   alts     = { [Twink] = { m = Main, t, by } } -- Twinks (in der Gilde geteilt)
--   mine     = { [Name] = { c, l } }            -- meine eigenen Charaktere in dieser Gilde
--   prof     = { [Name] = { c, t, p = { [Beruf] = { r, m, n = { Rezepte } } } } }
--   apps     = { [Name] = { t, msg, c, st } }   -- Bewerber
-- }

local ADDON, ns = ...
local L = ns.L
local N = ns.N

ns.version = "0.9.29"
ns.ICON = "Interface\\Icons\\INV_Shirt_GuildTabard_01"
ns.HEX = "4fd18a"
ns.ACCENT = { 0.31, 0.82, 0.54 }
ns.TITLE = "|cff4fd18aGuild|rSentinel"

------------------------------------------------------------
-- Standardwerte
------------------------------------------------------------
ns.defaults = {
	lang = "auto",             -- Sprache: "auto" (Spielsprache), "de" oder "en"
	minimapShow = true,
	minimapAngle = 200,
	framePoint = nil,
	-- Rekrutierung
	adText = "",
	adTargets = {},            -- gewählte Kanäle (Kurzname, klein geschrieben)
	adInterval = 15,           -- Minuten bis zur Erinnerung
	adRemind = true,
	keywords = "",
	autoReply = true,
	replyText = "",
	welcome = true,
	welcomeText = "",
	discord = "",
	askQuestions = true,       -- Bewerbungsfragen stellen
	questions = "",            -- eine Frage pro Zeile (leer = Standardfragen)
	tooltip = true,            -- Infos im Spieler-Tooltip
	chatMain = true,           -- Gildenchat: Main-Name hinter Twinks
	onlineMain = true,         -- "ist online": Main dazu
	annGoal = true,            -- Wochenziel geschafft: Ansage
	annMiles = true,           -- Gilden-Meilensteine: Ansage
	annReview = true,          -- Wochenrückblick im Gildenchat
	-- Anzeige
	showOffline = true,
	showAlts = true,
	-- Ansagen im Gildenchat (es sagt immer nur einer an, auch wenn mehrere das Addon haben)
	annLevels = true,          -- Stufen-Meilensteine
	annMilestones = { [10] = true, [20] = true, [30] = true, [40] = true, [50] = true, [60] = true },
	annFirst = true,           -- "Erster der Gilde auf 60"
	annJubilee = true,         -- Jubiläen (1, 3, 6 Monate, 1 Jahr)
	rulesPopup = true,         -- neue Gildenregeln beim Einloggen zeigen
	-- Gruppensuche
	lfgNotify = true,          -- Hinweis, wenn eine passende Suche kommt
	lfgServer = true,          -- (bis 0.9.19: Suchen vom ganzen Server über einen eigenen Kanal; ungenutzt)
	lfgSound = true,
	-- Funktionen ein/aus ([Schlüssel] = false heißt aus; alles andere an)
	features = {},
	-- Testmodus (erfundene Gilde, nichts wird gesendet)
	testMode = false,
	-- Diagnose-Protokoll beim Ausloggen für den RaidMaster-Uploader ablegen (Diag.lua, GuildSentinelDB.diagExport)
	diagSend = true,
	-- Bank-Charakter: Bestand an Discord (pro Charakter, ["Realm|Name"] = true; ab Werk für niemanden an)
	bankChars = {},
}

ns.guildDefaults = {
	roster = {}, log = {}, notes = {}, alts = {}, mine = {}, prof = {},
	gname = {},                -- { n = Anzeigename, t, by }  (legt nur der Gildenmeister fest; leer = Name aus dem Spiel)
	apps = {},
	levels = {},               -- [Name] = { [Stufe] = Zeit }  (wann erreicht, soweit gesehen)
	race = {},                 -- { first60 = { n, t } }
	attune = {},               -- [Name] = { t, k = { mc = true, ... } }
	act = {},                  -- [Halbstunden-Nr.] = Spieler online
	days = {},                 -- [Name] = { [Tag-Nr.] = true }  (an welchen Tagen online)
	firstSeen = {},            -- [Name] = Zeit (frühester bekannter Beitritt, in der Gilde geteilt)
	rules = { v = 0, t = 0, text = "", by = "" },
	rulesAck = {},             -- [Name] = { v, t }
	ann = {},                  -- [Schlüssel] = Zeit  (schon angesagt)
	promo = {},                -- [Rang-Index] = { on, days, level, active }
	lfg = {},                  -- [id] = Suche (Gruppensuche)
	roles = {},                -- [Name] = { r = Rolle, t }  (selbst gewählt, geteilt)
	comp = {},                 -- Aufstellung: { min, alts, want = { ... } }
	polls = {},                -- [id] = Umfrage
	creq = {},                 -- [id] = Herstellungswunsch
	craftWatch = {},           -- [Item-ID] = Beruf-Zauber-ID (zusätzlich beobachtete Rezepte)
	away = {},                 -- [Name] = { u = bis, note, t, by }  (Abwesenheit)
	mentor = {},               -- [Neuling] = { m = Pate, t, by }
	thanks = {},               -- [id] = { from, to, t, why }  (Dank-Punkte)
	svc = {},                  -- [Name] = { t, u, k = { Dienste }, x }  (Dienste-Brett)
	market = {},               -- [id] = Biete/Suche
	events = {},               -- [id] = Gildentermin
	cds = {},                  -- [Name] = { t, k = { [Abklingzeit] = bereit ab } }
	goal = {},                 -- Wochenziel { target, t, by }
	goalDone = {},             -- [Woche] = Zeit
	miles = {},                -- [Meilenstein] = Zeit
	addons = {},               -- [Name] = { t, a = { [Addon] = Version } }  (Addons von GoldSentinel)
	onotes = {},               -- [Name] = { [id] = Offiziersnotiz }      (nur Offiziere)
	gone = {},                 -- [Name] = Abgang mit Grund
	probation = {},            -- { days, t, by }  Probezeit
	hours = {},                -- [Main] = { [Wochenstunde] = Messungen online }
	gear = {},                 -- [id] = Beute-Wunsch
	ask = {},                  -- [id] = Frage an die Gilde
	review = {},               -- [Woche] = Zeit (Wochenrückblick angesagt)
}

------------------------------------------------------------
-- Funktionen ein- und ausschalten
------------------------------------------------------------
-- Was aus ist, verschwindet aus dem Fenster, sendet nichts und nimmt nichts an.
-- n = Name (deutscher Schlüssel), d = kurze Beschreibung
ns.FEATURES = {
	{ key = "group", n = N["Gruppensuche"], d = N["Suchen in der Gilde oder auf dem ganzen Server"] },
	{ key = "events", n = N["Gildentermine"], d = N["PvP-Abend, Treffen, Dungeon-Nacht – mit Erinnerung"] },
	{ key = "board", n = N["Brett"], d = N["Dienste (Portale, Beschwören …) und Biete/Suche"] },
	{ key = "poll", n = N["Umfragen"], d = N["Offiziere fragen, alle stimmen ab"] },
	{ key = "race", n = N["Leveling-Rennen"], d = N["Rangliste und Stufen-Ansagen"] },
	{ key = "attune", n = N["Zugänge & Schlüssel"], d = N["Raid-Zugänge und Dungeon-Schlüssel teilen"] },
	{ key = "goals", n = N["Gildenziele"], d = N["Wochenziel und Gilden-Meilensteine"] },
	{ key = "thanks", n = N["Dank-Punkte"], d = N["Danke sagen, Rangliste der Hilfsbereiten"] },
	{ key = "prof", n = N["Berufe"], d = N["Verzeichnis, Nachfrage, Lücken"] },
	{ key = "cooldowns", n = N["Abklingzeiten"], d = N["Transmutation, Mondstoff … teilen"] },
	{ key = "recruit", n = N["Rekrutierung"], d = N["Werbung, Bewerber, Begrüßung, Gildenregeln"] },
	{ key = "where", n = N["Wer ist wo"], d = N["Online-Mitglieder nach Zone"] },
	{ key = "away", n = N["Abwesenheit"], d = N["Abwesend melden, nicht inaktiv"] },
	{ key = "mentor", n = N["Paten"], d = N["Ansprechpartner für Neue"] },
	{ key = "times", n = N["Online-Zeiten"], d = N["Wann sind die meisten online?"] },
	{ key = "promo", n = N["Beförderung"], d = N["Vorschläge nach euren Regeln"] },
	{ key = "comp", n = N["Aufstellung"], d = N["Klassen und Rollen, Raid-Ziel"] },
	{ key = "addons", n = N["Addons"], d = N["Addons von GoldSentinel: wer nutzt was"] },
	{ key = "lead", n = N["Leitung"], d = N["Probezeit, Abgänge, Offiziersnotizen, Rangrechte"] },
	{ key = "home", n = N["Übersicht"], d = N["Gilden-Gesundheit auf einen Blick"] },
	{ key = "myweek", n = N["Meine Woche"], d = N["Gesperrte Instanzen, Dailies, Raid-Vorbereitung"] },
	{ key = "gear", n = N["Beute-Wünsche"], d = N["Wer braucht was aus welchem Dungeon?"] },
	{ key = "ask", n = N["Fragen an die Gilde"], d = N["Wer weiss …? – Antworten bringen Danke-Punkte"] },
	{ key = "chronicle", n = N["Chronik und Erfolge"], d = N["Zeitleiste der Gilde, Gildenerfolge, Wochenrückblick"] },
}

-- Entwickler (Testmodus): erkannt über GoldSentinelDev.lua (gemeinsam mit allen GoldSentinel-Addons)
function ns.IsDev()
	return GoldSentinelDev and GoldSentinelDev:IsDev() and true or false
end

function ns.Feature(key)
	if not key then return true end
	if key == "dev" then return ns.IsDev() end
	local f = ns.db and ns.db.features
	return not (f and f[key] == false)
end

-- Chat-Nachrichten und Aktionen mit Wirkung im Spiel – im Testmodus nur anzeigen, nie ausführen
-- "|" ist im Chat ein Steuerzeichen: einzelne Striche aus Texten (z. B. der Werbung) entschärfen,
-- echte Item-Links (|c…|H…|h[…]|h|r) bleiben erhalten
-- Text auf höchstens n Bytes kürzen, ohne ein UTF-8-Zeichen zu zerschneiden (Umlaute, Kyrillisch, Koreanisch …);
-- mit "..." am Ende, wenn gekürzt wurde
function ns.CutBytes(text, n)
	text = tostring(text or "")
	if #text <= n then return text end
	local cut = n - 3
	-- nicht mitten in einem Mehrbyte-Zeichen enden (Folgebytes 0x80–0xBF)
	while cut > 0 do
		local b = text:byte(cut + 1)
		if not b or b < 0x80 or b >= 0xC0 then break end
		cut = cut - 1
	end
	return text:sub(1, cut) .. "..."
end

function ns.ChatSafe(text)
	text = tostring(text or "")
	text = text:gsub("|([^cHhr])", "/%1"):gsub("|$", "/")
	return text
end

-- Eine Stelle für alles mit Wirkung im Spiel: Chat, Addon-Nachrichten, Einladen, Entfernen, Befördern,
-- Gildennotiz, Kanal betreten/verlassen, Flüsterfenster, Töne. Normal wird fn(...) einfach aufgerufen.
-- Während der Testroutine (nur Entwickler, TestRoutine.lua) ist ns.actRecorder gesetzt: dann wird nur
-- mitgeschrieben und nichts ausgeführt (ns.actLastFn: welche Funktion es gewesen wäre – für die Rückfall-Tests).
function ns.Act(what, fn, ...)
	local rec = ns.actRecorder
	if rec then
		ns.actLastFn = fn
		pcall(rec, what, ...)
		return nil
	end
	if type(fn) ~= "function" then return nil end
	return fn(...)
end

function ns.Chat(text, kind, target)
	text = ns.ChatSafe(text)
	if ns.Test and ns.Test:Active() then ns.Test:Log(kind, target, text) return end
	-- moderner Client (WoW Forever): C_ChatInfo.SendChatMessage, sonst das alte Global (beides über ns.API)
	local send = ns.ChatSender()
	if send then ns.Act("SendChatMessage", send, text, kind, nil, target) end
end

function ns.Blocked(what)
	if ns.Test and ns.Test:Active() then ns.Test:Log("ACTION", nil, what) return true end
	return false
end

function ns.InviteParty(name)
	local fn = (C_PartyInfo and C_PartyInfo.InviteUnit) or InviteUnit
	if name and fn and not ns.Blocked(L["In die Gruppe einladen"] .. ": " .. name) then ns.Act("InviteUnit", fn, name) end
end

-- Kampfsperre: InCombatLockdown(); die Testroutine kann sie über ns.testCombat nachstellen (true/false)
function ns.InCombat()
	if ns.testCombat ~= nil then return ns.testCombat and true or false end
	return InCombatLockdown and InCombatLockdown() and true or false
end

-- Verzögert ausführen, aber nicht mehr, wenn der Testmodus inzwischen gewechselt hat (sonst ginge z. B. eine im
-- Testmodus geplante Antwort nach "Testmodus beenden" echt hinaus)
function ns.Later(sec, fn)
	local gen = ns.Test and ns.Test.gen or 0
	C_Timer.After(sec, function()
		if (ns.Test and ns.Test.gen or 0) ~= gen then return end
		fn()
	end)
end

-- Sprache der Oberfläche: beim Start die des Spiel-Clients; wählbar unter Einstellungen > Allgemein
-- (settings.uiLang, nil = wie der Spiel-Client). Locales.lua: ns.LANGS, ns.SetLanguage, ns.LangAvailable.
-- Die alte Einstellung settings.lang (vor 0.6) wird weiter nicht beachtet.
ns.LATIN_LANGS = { de = true, en = true, frFR = true, esES = true, esMX = true, itIT = true, ptBR = true }
function ns.ApplyLang()
	ns.SetLanguage(ns.db and ns.db.uiLang)
end
function ns.LangName(l)
	for _, x in ipairs(ns.LANGS or {}) do if x[1] == l then return x[2] end end
	return tostring(l)
end
-- wählbar: lateinische Schrift immer, sonst nur die Sprache des Clients (Schriftzeichen)
function ns.LangChoices()
	local out, client = {}, ns.ClientLang()
	for _, x in ipairs(ns.LANGS or {}) do
		if (ns.LATIN_LANGS[x[1]] or x[1] == client) and ns.LangAvailable(x[1]) then out[#out + 1] = x end
	end
	return out
end
function ns.SetUiLang(l)
	if not ns.db then return end
	if not (l and ns.LangAvailable(l)) then l = nil end
	if ns.db.uiLang == l then return end
	ns.db.uiLang = l
	ns:Print(string.format(L["Sprache: %s – GuildSentinel lädt neu."], l and ns.LangName(l) or L["wie der Spiel-Client"]))
	if ReloadUI then C_Timer.After(1, ReloadUI) end
end

function ns.SetFeature(key, on)
	ns.db.features = ns.db.features or {}
	if on then ns.db.features[key] = nil else ns.db.features[key] = false end
	ns:Fire("GS_FEATURES", key, on)
end

------------------------------------------------------------
-- Kompatibilität
------------------------------------------------------------
ns.GetItemInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo
ns.SendAddonMessage = (C_ChatInfo and C_ChatInfo.SendAddonMessage) or SendAddonMessage
ns.RegisterPrefix = (C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix) or RegisterAddonMessagePrefix
ns.GuildRoster = (C_GuildInfo and C_GuildInfo.GuildRoster) or GuildRoster

------------------------------------------------------------
-- Ereignisse
------------------------------------------------------------
local frame = CreateFrame("Frame")
ns.eventFrame = frame
local handlers = {}
local listeners = {}

-- Fehlerzähler: abgefangene Fehler zählen (letzte 10, Text gekürzt, ohne eigenen Namen) und an GoldSentinelTest
-- melden (gemeinsame Testberichte aller GoldSentinel-Addons). Ausgabe im Chat wie bisher nur mit /gs debug.
ns.errors = { n = 0, last = {} }
function ns.CountError(where, err)
	where = tostring(where or "?")
	local msg = (type(err) == "string") and err or tostring(err)
	local me = ns.Me and ns.Me()
	if type(me) == "string" and me ~= "" then msg = msg:gsub(me:gsub("%p", "%%%0"), "<name>") end
	if #msg > 200 then msg = msg:sub(1, 200) .. "…" end
	local e = ns.errors
	e.n = e.n + 1
	table.insert(e.last, 1, { wo = where, msg = msg })
	while #e.last > 10 do table.remove(e.last) end
	local GT = _G.GoldSentinelTest
	if GT and GT.Error then pcall(GT.Error, "GuildSentinel", where, msg) end
	if ns.Diag then pcall(ns.Diag, "FEHLER", where .. ": " .. msg) end
	if ns.debug then ns:Print("|cffff4040" .. where .. ":|r " .. msg) end
end

function ns:On(event, fn)
	if not handlers[event] then
		handlers[event] = {}
		-- pcall: nicht jedes Ereignis gibt es in jeder Spielversion (Classic Era, WoW Forever, TBC)
		if not event:find("^GS_") then pcall(frame.RegisterEvent, frame, event) end
	end
	table.insert(handlers[event], fn)
end

frame:SetScript("OnEvent", function(_, event, ...)
	local list = handlers[event]
	if not list then return end
	for _, fn in ipairs(list) do
		local ok, err = pcall(fn, ...)
		if not ok then ns.CountError(event, err) end
	end
end)

-- interne Nachrichten (Seiten aktualisieren usw.)
function ns:Listen(name, fn)
	listeners[name] = listeners[name] or {}
	table.insert(listeners[name], fn)
end

function ns:Fire(name, ...)
	for _, fn in ipairs(listeners[name] or {}) do
		local ok, err = pcall(fn, ...)
		if not ok then ns.CountError(name, err) end
	end
end

------------------------------------------------------------
-- Hilfsfunktionen
------------------------------------------------------------
function ns:Print(msg)
	DEFAULT_CHAT_FRAME:AddMessage(ns.TITLE .. ": " .. tostring(msg))
end

-- WoW Forever (moderner Client): im Kampf können Namen, GUIDs und Spell-IDs "secret values" sein.
-- Damit darf man nicht rechnen, vergleichen oder gsub aufrufen – vorher prüfen.
-- über GoldSentinelGame (gemeinsam mit allen GoldSentinel-Addons); eigener Rückfall, falls die Datei fehlt
local GSG = _G.GoldSentinelGame
function ns.IsSecret(v)
	-- ns.API.IsSecret: GoldSentinelGame.IsSecret (sonst issecretvalue); fehlt beides, gibt es keine geschützten Werte
	local f = ns.API and ns.API.IsSecret
	if f and f(v) then return true end
	-- Testroutine: Köderwerte, die wie geschützte Werte behandelt werden (issecretvalue selbst bleibt unberührt)
	local bait = ns.testSecret
	if bait and v ~= nil and bait[v] then return true end
	return false
end

function ns.Short(name)
	if GSG then return GSG.Short(name) end
	if type(name) ~= "string" or ns.IsSecret(name) then return nil end
	return (name:gsub("%-.*$", ""))
end

function ns.Me()
	return ns.Short(UnitName("player"))
end

-- Vorname allein: in WoW Forever haben Charaktere Vor- UND Nachnamen ("Testa Beispiel").
-- Ein Vorname allein passt, wenn er in der Gilde eindeutig ist (sonst wäre unklar, wer gemeint ist).
local function FirstWord(s) return s:match("^(%S+)") end
local function UniqueFirst(first)
	local R = ns.Roster
	if not (R and R.list and #R.list > 0) then return true end
	local n = 0
	for _, e in ipairs(R.list) do
		local f = FirstWord((e.name or ""):lower())
		if f == first then n = n + 1 end
	end
	return n <= 1
end

function ns.Same(a, b)
	if not a or not b then return false end
	if GSG then
		if not GSG.SameName(a, b) then return false end
		-- Vorname allein (Forever): nur, wenn er in der Gilde eindeutig ist
		local sa, sb = GSG.Short(a), GSG.Short(b)
		if sa and sb and sa:lower() ~= sb:lower() then
			return UniqueFirst((sa:lower():match("^(%S+)")))
		end
		return true
	end
	a, b = ns.Short(a), ns.Short(b)
	if not a or not b then return false end
	a = a:lower():gsub("^%s+", ""):gsub("%s+$", "")
	b = b:lower():gsub("^%s+", ""):gsub("%s+$", "")
	if a == b then return true end
	if not (ns.Game and ns.Game.FOREVER) then return false end
	-- Forever: "Testa" passt zu "Testa Beispiel", wenn einer der beiden nur den Vornamen hat und er eindeutig ist
	if a:find(" ") and b:find(" ") then return false end
	local fa, fb = FirstWord(a), FirstWord(b)
	return fa ~= nil and fa == fb and UniqueFirst(fa)
end

-- exakter Vergleich (ohne "Vorname allein"): für die Prüfung, ob eine Addon-Nachricht wirklich vom genannten
-- Spieler kommt. In Classic Era und TBC gleich wie ns.Same.
function ns.SameExact(a, b)
	local pa, pb = ns.Proper(a), ns.Proper(b)
	return pa ~= nil and pb ~= nil and pa ~= "" and pa:lower() == pb:lower()
end

-- Name schön schreiben: "aRTHAS" -> "Arthas", "testa beispiel" -> "Testa Beispiel"
-- (jedes Wort mit grossem Anfangsbuchstaben, Umlaute bleiben)
local function CapWord(w)
	local first = w:match("^[%z\1-\127\194-\244][\128-\191]*") or w:sub(1, 1)
	return first:upper() .. w:sub(#first + 1):lower()
end
function ns.Proper(name)
	if GSG then return GSG.CleanName(name) end
	name = ns.Short(name)
	if not name or name == "" then return name end
	name = name:gsub("^%s+", ""):gsub("%s+$", ""):gsub("%s+", " ")
	return (name:gsub("%S+", CapWord))
end

-- Gildenmitglied zu einem eingegebenen Namen: exakt, sonst (Forever) per eindeutigem Vornamen
function ns.FindMember(name)
	local R = ns.Roster
	if not R or not name then return nil end
	local p = ns.Proper(name)
	if not p then return nil end
	if R.byName[p] then return R.byName[p] end
	for _, e in ipairs(R.list or {}) do
		if ns.Same(e.name, p) then return e end
	end
	return nil
end

function ns.Now()
	return GetServerTime and GetServerTime() or time()
end

local function MergeDefaults(dst, src)
	for k, v in pairs(src) do
		if type(v) == "table" then
			if type(dst[k]) ~= "table" then dst[k] = {} end
			MergeDefaults(dst[k], v)
		elseif dst[k] == nil then
			dst[k] = v
		end
	end
end
ns.MergeDefaults = MergeDefaults
ns.MergeDefaults = MergeDefaults

function ns.Copy(t)
	if type(t) ~= "table" then return t end
	local c = {}
	for k, v in pairs(t) do c[k] = ns.Copy(v) end
	return c
end

function ns.Count(t)
	local n = 0
	for _ in pairs(t or {}) do n = n + 1 end
	return n
end

function ns.Trim(s)
	return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

-- Klassenfarbe als Hex
function ns.ClassHex(classFile)
	local c = classFile and (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)[classFile]
	if not c then return "ffffff" end
	if c.colorStr then return c.colorStr:sub(3) end
	return string.format("%02x%02x%02x", c.r * 255, c.g * 255, c.b * 255)
end

function ns.ClassName(classFile)
	if not classFile then return "" end
	return (LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[classFile]) or classFile
end

function ns.Colored(name, classFile)
	return "|cff" .. ns.ClassHex(classFile) .. tostring(name) .. "|r"
end

-- "vor 3 Tagen", "vor 2 Std." …
function ns.Ago(t)
	if not t or t <= 0 then return L["unbekannt"] end
	local d = ns.Now() - t
	if d < 60 then return L["gerade eben"] end
	if d < 3600 then return string.format(L["vor %d Min."], math.floor(d / 60)) end
	if d < 86400 then return string.format(L["vor %d Std."], math.floor(d / 3600)) end
	local days = math.floor(d / 86400)
	if days == 1 then return L["gestern"] end
	if days < 60 then return string.format(L["vor %d Tagen"], days) end
	return string.format(L["vor %d Monaten"], math.floor(days / 30))
end

function ns.Date(t)
	return date(L["%d.%m. %H:%M"], t or ns.Now())
end

function ns.ItemID(link)
	if type(link) == "number" then return link end
	return type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil
end

-- Item-ID aus einer Eingabe: Link, Zahl oder Name (Name: Spiel-Cache, Taschen, bekannte Rezepte der Gilde)
function ns.FindItemID(text)
	text = ns.Trim(text)
	if text == "" then return nil end
	local id = ns.ItemID(text) or (text:match("^%d+$") and tonumber(text))
	if id then return id end
	local name = text:match("^%[(.-)%]$") or text
	local low = name:lower()
	for _, fn in ipairs({ C_Item and C_Item.GetItemInfo, GetItemInfo }) do
		local ok, _, link = pcall(fn, name)
		if ok and link then return ns.ItemID(link) end
	end
	-- Taschen
	local C = C_Container
	local slots = (C and C.GetContainerNumSlots) or GetContainerNumSlots
	local getLink = (C and C.GetContainerItemLink) or GetContainerItemLink
	if slots and getLink then
		for bag = 0, (NUM_BAG_SLOTS or 4) do
			for slot = 1, (slots(bag) or 0) do
				local link = getLink(bag, slot)
				local n = link and link:match("%[(.-)%]")
				if n and n:lower() == low then return ns.ItemID(link) end
			end
		end
	end
	-- Rezepte und Einträge, die die Gilde kennt
	for _, e in pairs(ns.G().prof or {}) do
		for _, p in pairs(e.p or {}) do
			for i, n in ipairs(p.n or {}) do
				if type(n) == "string" and n:lower() == low and p.i and p.i[i] then return p.i[i] end
			end
			for _, iid in ipairs(p.i or {}) do
				local n = ns.Item(iid)
				if n and n:lower() == low then return iid end
			end
		end
	end
	for _, e in pairs(ns.G().market or {}) do
		if e.n and e.n:lower() == low and (e.i or 0) > 0 then return e.i end
	end
	return nil
end

-- Flüsternachricht vorbereiten (der Spieler schickt sie selbst ab). link wird als echter Item-Link eingefügt.
-- Im Testmodus nur anzeigen: die Namen der Testgilde sind erfunden, es könnte sie auf dem Server geben.
function ns.OpenWhisper(name, before, link, after)
	before, after = before or "", after or ""
	if ns.Test and ns.Test:Active() then
		ns.Test:Log("WHISPER", name, before .. (link or "") .. after)
		return
	end
	-- Namen mit Leerzeichen (WoW Forever: Vor- und Nachname): "/w Vorname Nachname" würde nur den Vornamen
	-- als Empfänger lesen – darum das Flüsterfenster direkt für den Namen öffnen und den Text einfügen
	if name and name:find(" ") and ChatFrame_SendTell then
		ns.Act("ChatFrame_SendTell", ChatFrame_SendTell, name)
		if ns.actRecorder then return end
		local eb = ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow()
		if eb then
			eb:Insert(before)
			if link then eb:Insert(link) end
			eb:Insert(after)
		end
		return
	end
	if not ChatFrame_OpenChat then return end
	if not link then ns.Act("ChatFrame_OpenChat", ChatFrame_OpenChat, "/w " .. name .. " " .. before .. after) return end
	ns.Act("ChatFrame_OpenChat", ChatFrame_OpenChat, "/w " .. name .. " " .. before)
	if ns.actRecorder then return end
	local eb = ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow()
	if eb then
		eb:Insert(link)
		eb:Insert(after)
	end
end

-- Item-Infos (kann beim ersten Mal leer sein, dann kommt GET_ITEM_INFO_RECEIVED)
function ns.Item(id)
	if not id or id == 0 then return nil end
	local name, link, quality, _, _, _, _, _, _, icon = ns.GetItemInfo(id)
	return name, link, quality, icon
end

function ns.ItemIcon(id)
	local _, _, _, icon = ns.Item(id)
	if not icon and GetItemIcon then icon = GetItemIcon(id) end
	return icon or "Interface\\Icons\\INV_Misc_QuestionMark"
end

ns:On("GET_ITEM_INFO_RECEIVED", function()
	if ns.itemTimer then return end
	ns.itemTimer = true
	C_Timer.After(0.5, function() ns.itemTimer = nil; ns:Fire("GS_ITEMS") end)
end)

-- Text mit {platzhaltern} füllen
function ns.Fill(text, vars)
	return (tostring(text or ""):gsub("{(%w+)}", function(k)
		local v = vars[k]
		if v == nil then return "{" .. k .. "}" end
		return tostring(v)
	end))
end

------------------------------------------------------------
-- Gilde und Rechte
------------------------------------------------------------
-- Geldbetrag (Kupfer) als Text: 12g 34s 5k
function ns.Money(copper)
	copper = math.floor(tonumber(copper) or 0)
	local g, s, c = math.floor(copper / 10000), math.floor((copper % 10000) / 100), copper % 100
	local out = {}
	if g > 0 then out[#out + 1] = g .. "|cffffd100g|r" end
	if s > 0 then out[#out + 1] = s .. "|cffc7c7cfs|r" end
	if c > 0 or #out == 0 then out[#out + 1] = c .. "|cffeda55fc|r" end
	return table.concat(out, " ")
end

local function Testing() return ns.Test and ns.Test:Active() end

-- in einer Gilde? (im Testmodus immer – in der erfundenen Testgilde)
function ns.InGuild()
	if Testing() then return true end
	return ns.API.IsInGuild and ns.API.IsInGuild() and true or false
end

function ns.GuildName()
	if Testing() then return ns.Test:GuildName() end
	if not IsInGuild() then return nil end
	return (GetGuildInfo("player"))
end

-- Gildenmeister (Rang 0)? Im Testmodus bin ich der Gildenmeister der Testgilde
function ns.IsGM()
	if Testing() then return true end
	if not IsInGuild() then return false end
	if IsGuildLeader and IsGuildLeader() then return true end
	local me = ns.Roster and ns.Roster.byName[ns.Me()]
	return me and me.ri == 0 or false
end

-- Name der Gilde für Anzeigen und Texte: den legt der Gildenmeister fest, sonst der Name aus dem Spiel
-- (ns.GuildName() bleibt der Name aus dem Spiel – damit werden die Daten gespeichert)
function ns.DisplayGuildName()
	local g = ns.guild
	local n = g and g.gname and g.gname.n
	if type(n) == "string" and n ~= "" then return n end
	return ns.GuildName()
end

-- Offizier: darf Offiziersnotizen BEARBEITEN, entfernen oder befördern (nur lesen reicht nicht).
-- Alles über ns.API: moderner Client (C_GuildInfo) zuerst, die alten Globals als Rückfall.
function ns.IsOfficer()
	if Testing() then return true end
	local A = ns.API
	if not (A.IsInGuild and A.IsInGuild()) then return false end
	if A.C_CanEditOfficerNote and A.C_CanEditOfficerNote() then return true end
	if A.CanEditOfficerNote and A.CanEditOfficerNote() then return true end
	if A.CanGuildRemove and A.CanGuildRemove() then return true end
	if A.CanGuildPromote and A.CanGuildPromote() then return true end
	return false
end

function ns.CanInvite()
	if Testing() then return true end
	local A = ns.API
	return A.IsInGuild and A.IsInGuild() and A.CanGuildInvite and A.CanGuildInvite() and true or false
end

function ns.CanPromote()
	if Testing() then return true end
	local A = ns.API
	return A.IsInGuild and A.IsInGuild() and A.CanGuildPromote and A.CanGuildPromote() and true or false
end

------------------------------------------------------------
-- Datenbank
------------------------------------------------------------
local EMPTY = {}
for k in pairs(ns.guildDefaults) do EMPTY[k] = {} end

-- aktuelle Gilde (ohne Gilde: leere Tabelle, die nicht gespeichert wird)
function ns.G()
	return ns.guild or EMPTY
end

function ns:SetupGuild()
	-- im Testmodus nichts anlegen: ns.GuildName() liefert dann die erfundene Testgilde, die nie gespeichert wird
	-- (beim Beenden des Testmodus wird die Gilde neu bestimmt)
	if Testing() then return end
	local gname = ns.GuildName()
	if not gname then
		ns.guild, ns.guildKey = nil, nil
		return
	end
	local realm = GetRealmName and GetRealmName() or ""
	local key = realm .. "|" .. gname
	if ns.guildKey == key then return end
	GuildSentinelDB.guilds[key] = GuildSentinelDB.guilds[key] or {}
	local g = GuildSentinelDB.guilds[key]
	MergeDefaults(g, ns.guildDefaults)
	-- 0.3.0: keine Gildenbank mehr in GuildSentinel – alte Daten entfernen
	g.bank, g.bankLocal, g.wishes, g.don, g.cfg, g.names = nil, nil, nil, nil, nil, nil
	ns.guild, ns.guildKey = g, key
	-- mich selbst als eigenen Charakter merken
	local _, classFile = UnitClass("player")
	local me = ns.Me()
	if me then g.mine[me] = { c = classFile, l = UnitLevel("player") } end   -- nil, falls der Name geschützt ist
	ns:Fire("GS_GUILD")
end

ns:On("ADDON_LOADED", function(name)
	if name ~= ADDON then return end
	GuildSentinelDB = GuildSentinelDB or {}
	GuildSentinelDB.settings = GuildSentinelDB.settings or {}
	GuildSentinelDB.guilds = GuildSentinelDB.guilds or {}
	MergeDefaults(GuildSentinelDB.settings, ns.defaults)
	ns.db = GuildSentinelDB.settings
	-- gemeinsame Testberichte: Lua-Fehler von GuildSentinel auch im normalen Spiel zählen (GuildSentinelDB.gsTest)
	if _G.GoldSentinelTest and GoldSentinelTest.TrackErrors then
		pcall(GoldSentinelTest.TrackErrors, "GuildSentinel", ns.version, GuildSentinelDB)
	end
	-- 0.9.12 hatte die Wahl nur für den Entwickler (devLang): übernehmen
	if ns.db.devLang then ns.db.uiLang = ns.db.uiLang or ns.db.devLang; ns.db.devLang = nil end
	ns.ApplyLang()
	if ns.Comm then ns.Comm:Setup() end
end)

ns:On("PLAYER_LOGIN", function()
	ns:SetupGuild()
	if ns.UI then ns.UI:Login() end
	if IsInGuild() and ns.GuildRoster then ns.GuildRoster() end
	ns:Fire("GS_LOGIN")
end)

-- Gildeninfo kommt manchmal erst etwas später
ns:On("PLAYER_GUILD_UPDATE", function()
	C_Timer.After(1, function() ns:SetupGuild() end)
end)
ns:On("GUILD_ROSTER_UPDATE", function()
	if not ns.guild then ns:SetupGuild() end
end)

------------------------------------------------------------
-- Slash-Befehle (alles geht auch per Maus im Fenster)
------------------------------------------------------------
SLASH_GUILDSENTINEL1 = "/gs"
SLASH_GUILDSENTINEL2 = "/guildsentinel"
SlashCmdList.GUILDSENTINEL = function(msg)
	msg = ns.Trim(msg)
	local cmd, rest = msg:match("^(%S*)%s*(.-)$")
	cmd = (cmd or ""):lower()
	if cmd == "" then
		if ns.UI then ns.UI:Toggle() end
	elseif cmd == "berufe" or cmd == "prof" then
		ns.Prof:ReadNext()
	elseif cmd == "suche" or cmd == "find" then
		if ns.UI then ns.UI:Open("prof", rest) end
	elseif cmd == "gruppe" or cmd == "group" or cmd == "lfg" then
		if ns.UI then ns.UI:Open("group") end
	elseif cmd == "fortschritt" or cmd == "progress" or cmd == "rennen" then
		if ns.UI then ns.UI:Open("progress") end
	elseif cmd == "zugang" or cmd == "attune" then
		if ns.UI then ns.UI:Open("progress", "attune") end
	elseif cmd == "termine" or cmd == "events" or cmd == "termin" then
		if ns.UI then ns.UI:Open("events") end
	elseif cmd == "brett" or cmd == "board" then
		if ns.UI then ns.UI:Open("board") end
	elseif cmd == "wo" or cmd == "where" then
		if ns.UI then ns.UI:Open("members", "where") end
	elseif cmd == "danke" or cmd == "thanks" then
		if rest == "" then ns:Print(L["/gs danke <Name>"])
		elseif not ns.FindMember(rest) then ns:Print(string.format(L["%s ist nicht in der Gilde."], ns.Proper(rest)))
		else ns.Social:Thank(rest) end
	elseif cmd == "weg" or cmd == "away" then
		local days, note = rest:match("^(%d+)%s*(.*)$")
		if days then ns.Social:SetAway(nil, tonumber(days), note) else ns.Social:SetAway(nil, 0, "") end
	elseif cmd == "umfrage" or cmd == "poll" then
		if ns.UI then ns.UI:Open("poll") end
	elseif cmd == "regeln" or cmd == "rules" then
		ns.Rules:ShowPopup(true)
	elseif cmd == "werbung" or cmd == "ad" then
		-- Seite öffnen; gepostet wird mit dem Knopf dort oder per Rechtsklick auf den Minimap-Knopf
		if ns.UI then ns.UI:Open("recruit", "ad") end
	elseif cmd == "spenden" or cmd == "donate" or cmd == "support" then
		ns.Donate.Show()
	elseif cmd == "test" then
		-- Testmodus nur für den Entwickler (GoldSentinelDev); alle anderen bekommen einen Hinweis
		if not (GoldSentinelDev and GoldSentinelDev:Require("GuildSentinel")) then return end
		if ns.Test:Active() then ns.Test:Stop() else ns.Test:Start() end
		if ns.UI then ns.UI:Open("settings", "test") end
	elseif cmd == "testroutine" then
		-- Testroutine (TestRoutine.lua) nur für den Entwickler
		if not (GoldSentinelDev and GoldSentinelDev:Require("GuildSentinel")) then return end
		if ns.Routine then ns.Routine:Slash(rest) end
	elseif cmd == "verwaltung" or cmd == "admin" then
		-- Gildenverwaltung (Admin.lua): nur Gildenleitung und Offiziere
		if ns.Admin then ns.Admin:Toggle() end
	elseif cmd == "sync" then
		-- /gs sync test: wer mit GuildSentinel antwortet
		ns.Comm:PingTest()
	elseif cmd == "protokoll" or cmd == "log" or cmd == "diag" then
		-- Diagnose-Protokoll (Diag.lua) zum Kopieren
		if ns.ShowDiag then ns.ShowDiag() end
	elseif cmd == "debug" then
		ns.debug = not ns.debug
		ns:Print("debug " .. tostring(ns.debug))
	else
		ns:Print(L["Befehle: /gs, /gs gruppe, /gs termine, /gs brett, /gs wo, /gs umfrage, /gs fortschritt, /gs zugang, /gs regeln, /gs danke <Name>, /gs weg <Tage>, /gs suche <Rezept>, /gs werbung, /gs spenden"] .. ", /gs verwaltung, /gs protokoll, /gs sync test" .. (ns.IsDev() and ", /gs test, /gs testroutine" or ""))
	end
end
