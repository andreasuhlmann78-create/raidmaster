local ADDON, ns = ...
local L = ns.L

ns.ADDON = ADDON
ns.Recipes = {}        -- array of recipe tables
ns.BySpell = {}        -- spellID -> recipe
ns.ByProf = {}         -- skillLineID -> { recipes... }
ns.ByRecipeItem = {}   -- recipe itemID -> recipe
ns.ByOutput = {}       -- crafted itemID -> { recipes... }
ns.ByName = {}         -- lower-case name (de/en) -> recipe
ns.ProfById = {}
ns.Professions = ns.Professions or {}
ns.Items = ns.Items or {}
ns.NPCs = ns.NPCs or {}
ns.DataMeta = ns.DataMeta or {}

-- Source bits (must match gen_addon_data.py)
ns.SRC = { TRAINER = 1, AUTO = 2, VENDOR = 4, DROP = 8, WORLDDROP = 16, QUEST = 32, CONTAINER = 64, UNKNOWN = 128 }

-- Item quality colours: grey, white, green, blue, purple, legendary, artifact
ns.QUALITY_HEX = { [0] = "9d9d9d", [1] = "ffffff", [2] = "1eff00", [3] = "0070dd", [4] = "a335ee", [5] = "ff8000", [6] = "e6cc80" }

function ns.QualityRGB(q)
    local hex = ns.QUALITY_HEX[q or 1] or "ffffff"
    return tonumber(hex:sub(1, 2), 16) / 255, tonumber(hex:sub(3, 4), 16) / 255, tonumber(hex:sub(5, 6), 16) / 255
end

function ns.Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff3fc7ebProfession|r|cffffd100Sentinel|r: " .. tostring(msg))
end

function ns.FlavorName()
    if ns.IsForever then return L.FLAVOR_FOREVER end
    if ns.IsEra then return L.FLAVOR_ERA end
    return "?"
end

---------------------------------------------------------------------------
-- API compatibility helpers
---------------------------------------------------------------------------
function ns.GetItemIcon(itemID)
    if C_Item and C_Item.GetItemIconByID then
        local icon = C_Item.GetItemIconByID(itemID)
        if icon then return icon end
    end
    if GetItemIcon then return GetItemIcon(itemID) end
    return 134400 -- question mark
end

function ns.GetSpellIcon(spellID)
    if C_Spell and C_Spell.GetSpellTexture then
        local t = C_Spell.GetSpellTexture(spellID)
        if t then return t end
    end
    if GetSpellTexture then return GetSpellTexture(spellID) end
    return 134400
end

function ns.GetItemLink(itemID)
    if C_Item and C_Item.GetItemInfo then return (select(2, C_Item.GetItemInfo(itemID))) end
    if GetItemInfo then return (select(2, GetItemInfo(itemID))) end
end

function ns.GetItemCount(itemID)
    if C_Item and C_Item.GetItemCount then return C_Item.GetItemCount(itemID, true) or 0 end
    if GetItemCount then return GetItemCount(itemID, true) or 0 end
    return 0
end

-- Names: the data ships German names; on other clients prefer the live client name.
function ns.ItemName(itemID)
    local d = ns.Items[itemID]
    if not ns.isGerman then
        local name
        if C_Item and C_Item.GetItemNameByID then name = C_Item.GetItemNameByID(itemID)
        elseif GetItemInfo then name = GetItemInfo(itemID) end
        if name then return name end
    end
    return d and d[1] or ("Item " .. itemID)
end

function ns.ItemQuality(itemID)
    local d = ns.Items[itemID]
    return d and d[2] or 1
end

function ns.RecipeName(r)
    if ns.isGerman then return r.name end
    return (r.nameEN and r.nameEN ~= "") and r.nameEN or r.name
end

function ns.ProfName(profID)
    local p = ns.ProfById[profID]
    if not p then return "?" end
    if ns.isGerman then return p.name end
    return ns.ProfessionNamesEN[profID] or p.name
end

---------------------------------------------------------------------------
-- Learned state (single place, test mode can override it)
---------------------------------------------------------------------------
function ns.IsLearned(r)
    if ns.Sim and ns.Sim.known == "all" then return true end
    if ns.Sim and ns.Sim.known == "none" then return false end
    return ns.Scan and ns.Scan:IsKnown(r.spell) or false
end

---------------------------------------------------------------------------
-- Build lookup tables from the compact generated rows
---------------------------------------------------------------------------
local indexed = false
local function BuildIndex()
    if indexed or not ns.RecipeRows then return end
    indexed = true
    for _, p in ipairs(ns.Professions) do
        ns.ProfById[p.id] = p
        ns.ByProf[p.id] = {}
    end
    for i, row in ipairs(ns.RecipeRows) do
        local r = {
            spell = row[1], prof = row[2], name = row[3], nameEN = row[4], cat = row[5], catOrder = row[6],
            req = row[7], yellow = row[8], green = row[9], grey = row[10],
            out = row[11] ~= 0 and row[11] or nil, outMin = row[12], outMax = row[13],
            src = row[14], isNew = row[15] == 1, ench = row[16] == 1,
            reagents = row[17], recipeItems = row[18], skillUps = row[19] or 1, learnLevel = row[20], index = i,
        }
        -- Rarity: recipe item first, otherwise the crafted item.
        local q
        if r.recipeItems[1] then q = ns.ItemQuality(r.recipeItems[1].id) end
        if not q and r.out then q = ns.ItemQuality(r.out) end
        r.quality = q or 1
        r.searchText = (r.name .. " " .. (r.nameEN or "") .. " " .. (r.cat or "")):lower()
        ns.Recipes[#ns.Recipes + 1] = r
        ns.BySpell[r.spell] = r
        if ns.ByProf[r.prof] then table.insert(ns.ByProf[r.prof], r) end
        for _, ri in ipairs(r.recipeItems) do ns.ByRecipeItem[ri.id] = r end
        if r.out then
            ns.ByOutput[r.out] = ns.ByOutput[r.out] or {}
            table.insert(ns.ByOutput[r.out], r)
        end
        ns.ByName[r.name:lower()] = r
        if r.nameEN and r.nameEN ~= "" then ns.ByName[r.nameEN:lower()] = r end
    end
    -- Sort like the client window: category order, then skill (highest first), then name.
    for _, list in pairs(ns.ByProf) do
        table.sort(list, function(a, b)
            if (a.cat or "") ~= (b.cat or "") then
                if a.catOrder ~= b.catOrder then return a.catOrder < b.catOrder end
                return (a.cat or "") < (b.cat or "")
            end
            if a.yellow ~= b.yellow then return a.yellow > b.yellow end
            return a.name < b.name
        end)
    end
end
ns.BuildIndex = BuildIndex

---------------------------------------------------------------------------
-- Saved variables
---------------------------------------------------------------------------
local DEFAULTS = {
    tooltip = true,
    lifeline = true,
    best = true,
    panelOpen = true,
    filters = { missing = false },
    collapsed = {},
    chars = {},
    vzMarkup = 20,      -- selling enchants: surcharge on the material cost in %
    vzMinProfit = 0,    -- selling enchants: at least this much profit per enchant (copper)
    deMargin = 20,      -- disenchanting: minimum margin in % for the sniper prices
}

local function CopyDefaults(src, dst)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then dst[k] = {} end
            CopyDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

function ns.CharKey()
    local name = UnitName("player") or "?"
    local realm = GetRealmName and GetRealmName() or ""
    return name .. "-" .. realm
end

function ns.Char()
    return ns.db and ns.db.chars[ns.CharKey()]
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON then
        ProfessionSentinelDB = ProfessionSentinelDB or {}
        ns.db = ProfessionSentinelDB
        CopyDefaults(DEFAULTS, ns.db)
        BuildIndex()
    elseif event == "PLAYER_LOGIN" then
        if not ns.Flavor then
            ns.Print(string.format(L.UNSUPPORTED, ns.Interface or 0))
            return
        end
        local key = ns.CharKey()
        ns.db.chars[key] = ns.db.chars[key] or { known = {}, profs = {} }
        local c = ns.db.chars[key]
        c.known = c.known or {}
        c.profs = c.profs or {}
        local _, class = UnitClass("player")
        c.class = class
        c.faction = UnitFactionGroup("player")
        c.flavor = ns.Flavor
        if ns.Scan then ns.Scan:Init() end
    end
end)

SLASH_PROFESSIONSENTINEL1 = "/ps"
SLASH_PROFESSIONSENTINEL2 = "/professionsentinel"
SlashCmdList.PROFESSIONSENTINEL = function(msg)
    msg = (msg or ""):lower():match("^%s*(.-)%s*$")
    if not ns.Flavor then
        ns.Print(string.format(L.UNSUPPORTED, ns.Interface or 0))
        return
    end
    if msg == "test" then
        if ns.TestMode then ns.TestMode:Toggle() end
    elseif msg == "selftest" then
        if ns.TestMode then ns.TestMode:RunSelfTest(true) end
    elseif msg == "line" then
        ns.db.lifeline = not ns.db.lifeline
        ns.Print(L.LL_OPTION .. ": " .. (ns.db.lifeline and "|cff40c040an/on|r" or "|cffff4040aus/off|r"))
        if ns.Lifeline then ns.Lifeline.RefreshBlizzard() end
        if ns.UI then ns.UI:Refresh() end
    elseif msg == "ziel" or msg == "goal" then
        if ns.Disenchant then ns.Disenchant.AskGoal() end
    elseif msg == "help" or msg == "?" then
        ns.Print(L.TEST_HELP)
    else
        if ns.UI then ns.UI:Toggle() end
    end
end
