if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - MarketCore.lua (anweisung-markt-reiter, Teil F Stufe 1 "Vertrauen": MA2, MA1, MA3, Ü1–Ü3)
--
-- MA2 Empfehlungs-Protokoll: jede gezeigte Kauf-Empfehlung (Weg, Item, Preis, Vorhersage, Zeit) wird gespeichert und
--     nach Ablauf (24 Std.) mit dem Scan nachgeprüft: Treffer = Preis danach >= Kaufpreis (Kauf war nicht zu teuer),
--     Fehler = |Preis danach - Vorhersage| / Vorhersage. Je Weg: Fälle, Trefferquote, mittlerer Fehler (letzte 50).
--     Speicher klein: Zähler + letzte 200 offene Fälle. Freigabe (Teil D): >= 20 Fälle und >= 60 % -> frei, darunter
--     gesperrt (Protokoll "WEG GESPERRT"), < 20 Fälle -> "lernt noch".
-- MA1 Verkauf vs. Abbruch an den EIGENEN Auktionen (Wahrheit): verschwindet eine eigene Auktion mit langer Restzeit,
--     rät die Erkennung "verkauft", ausser dasselbe Item mit derselben Menge ist neu da ("neu eingestellt"). Die echte
--     Ursache (Verkauf / eigener Abbruch) kommt aus der Buchhaltung bzw. dem Abbrechen -> Fehlerquote.
-- MA3 Händlerpreis: Tabelle gegen das Spiel (A:GetVendorPrice zählt Abweichungen; Händler-Weg nur mit bestätigtem Preis).
-- Ü1 Testbericht-Abschnitt "MARKT-KERN"; Ü2 Grenzwerte; Ü3 Plausibilität.
-- Neue Tabelle db.core (ändert keine anderen Daten). Testroutine: MK.testDB.
-- ============================================================
AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local MK = {}
A.Core = MK

MK.CHECK_AFTER = 24 * 3600
MK.NOTE_GAP = 6 * 3600
MK.MAX_RECS = 200
MK.LAST = 50
MK.FREE_MIN = 20
MK.FREE_PCT = 0.60
MK.WAYS = { "flip", "snipe", "de", "craft", "vendor" }
MK.LONG = 2 * 3600

local function NewDB() return { v = 1, recs = {}, res = {}, err = {}, ma1 = { n = 0, wrong = 0 }, locked = {} } end
MK.NewDB = NewDB
local function Now() return MK.now or time() end
function MK:Store()
    if self.testDB then return self.testDB end
    if not A.db or A:Simulated() then return nil end
    if A.TestRoutine and A.TestRoutine.running then return nil end
    A.db.core = A.db.core or NewDB()
    local d = A.db.core
    d.recs, d.res, d.err, d.ma1, d.locked = d.recs or {}, d.res or {}, d.err or {}, d.ma1 or { n = 0, wrong = 0 }, d.locked or {}
    return d
end
function MK:Data() if self.testDB then return self.testDB end return A.db and A.db.core end

-- ------------------------------------------------------------
-- MA2
-- ------------------------------------------------------------
MK.notedAt = MK.notedAt or {}
function MK:Note(way, itemID, price, pred)
    local db = self:Store()
    if not (db and way and itemID and price and price > 0 and pred and pred > 0) then return false end
    local now = Now()
    local key = way .. ":" .. itemID
    if self.notedAt[key] and now - self.notedAt[key] < self.NOTE_GAP then return false end
    self.notedAt[key] = now
    db.recs[#db.recs + 1] = string.format("%s;%d;%d;%d;%d", way, itemID, now, math.floor(price), math.floor(pred))
    while #db.recs > self.MAX_RECS do table.remove(db.recs, 1) end
    return true
end
local function PriceBetween(itemID, from, to)
    local F, n = A:HF(itemID)
    for i = 1, n do
        local b = (i - 1) * 5
        local t, p = F[b + 1], F[b + 2]
        if t >= from and t <= to and F[b + 5] % 2 == 0 and p and p > 0 then return p end
        if t > to then break end
    end
end
-- MA2-B: Wert "danach" je Weg. flip/snipe: späterer AH-Preis des Items; de: Netto-Materialwert jetzt (Materialpreise
-- nach 24 Std. × Ausbeute, D:DealValue); vendor: vom Spiel bestätigter Händlerpreis (MA3). nil = noch nicht messbar.
function MK:TruthValue(way, id, t)
    if way == "de" then
        local D = A.Disenchant
        if not (D and D.DealValue) then return nil end
        local ok, v, net, complete = pcall(D.DealValue, D, id)
        if ok and v and net and net > 0 and complete then return net end
        return nil
    elseif way == "vendor" then
        if not (A.vendorChecked and A.vendorChecked[id]) then return nil end
        local ok, vp = pcall(A.GetVendorPrice, A, id)
        if ok and vp and vp > 0 then return vp end
        return nil
    end
    return PriceBetween(id, t + self.CHECK_AFTER - 3600, t + self.CHECK_AFTER + 6 * 3600)
end
function MK:Resolve(now, pause)
    local db = self:Store()
    if not db then return 0 end
    now = now or Now()
    local keep, n = {}, 0
    local recs = db.recs
    db.recs = {}                -- während der Pausen neu gemerkte Empfehlungen landen hier und bleiben erhalten
    for _, s in ipairs(recs) do
        if pause then A:Pause() end
        local way, id, t, price, pred = s:match("^(%a+);(%d+);(%d+);(%d+);(%d+)$")
        id, t, price, pred = tonumber(id), tonumber(t), tonumber(price), tonumber(pred)
        local done = false
        if t and now >= t + self.CHECK_AFTER then
            -- MA2-B: je Weg die passende Wahrheit (markt-strategie 8g, Teil C)
            local q = self:TruthValue(way, id, t)
            if q then
                local hit = (way == "vendor") and q > price or (way ~= "vendor" and q >= price)
                local e = math.min(9.99, math.abs(q - pred) / pred)
                local r = (db.res[way] or "") .. (hit and "1" or "0")
                if #r > self.LAST then r = r:sub(-self.LAST) end
                db.res[way] = r
                local el = db.err[way] or {}
                el[#el + 1] = math.floor(e * 1000 + 0.5)
                while #el > self.LAST do table.remove(el, 1) end
                db.err[way] = el
                n, done = n + 1, true
            elseif now >= t + 2 * self.CHECK_AFTER then done = true end
        end
        if not done then keep[#keep + 1] = s end
    end
    for _, s in ipairs(db.recs) do keep[#keep + 1] = s end
    db.recs = keep
    for _, w in ipairs(self.WAYS) do self:WayState(w) end
    return n
end
-- Fälle, Quote, mittlerer Fehler (Anteil)
function MK:Quote(way)
    local db = self:Data()
    local r = db and db.res and db.res[way] or ""
    local hit = 0
    for i = 1, #r do if r:sub(i, i) == "1" then hit = hit + 1 end end
    local el, sum = db and db.err and db.err[way] or {}, 0
    for _, v in ipairs(el) do sum = sum + v end
    return #r, #r > 0 and hit / #r or nil, #el > 0 and sum / #el / 1000 or nil
end
-- Teil D: "frei" / "gesperrt" / "lernt" (n von 20)
function MK:WayState(way)
    local n, q = self:Quote(way)
    if n < self.FREE_MIN then return "lernt", n end
    local db = self:Store() or self:Data()
    if q < self.FREE_PCT then
        if db and not db.locked[way] then
            db.locked[way] = true
            if A.Diag and not self.testDB then pcall(A.Diag.Add, A.Diag, "WEG GESPERRT", string.format("%s %d %%", way, math.floor(q * 100 + 0.5))) end
        end
        return "gesperrt", n
    end
    if db then db.locked[way] = nil end
    return "frei", n
end

-- Empfehlungen aus dem Markt-Reiter und dem Sniper notieren (nur gezeigte, je Item und Weg höchstens 1-mal je 6 Std.)
local VIEW_WAY = { flip = "flip", vendor = "vendor", de = "de", gaps = "flip", crowded = "flip" }
function MK:NoteRows(view, rows)
    local way = VIEW_WAY[view]
    if not way then return 0 end
    local n = 0
    for _, r in ipairs(rows or {}) do
        local buy = r.price or r.buy
        local pred = r.upto and (r.net or r.value or r.sell) or (r.sell or r.sellPrice or r.value or r.vendor)
        if r.itemID and buy and pred and not r.implausible and self:Note(way, r.itemID, buy, pred) then n = n + 1 end
    end
    return n
end

-- ------------------------------------------------------------
-- FG: Freigaben (Teil D) in den Markt-Zeilen anwenden. Vorher sind alle Zeilen gemerkt (NoteRows) - auch die eines
-- gesperrten oder lernenden Wegs, sonst käme ein Weg nie zu seinen 20 Fällen bzw. nie wieder frei.
--  gesperrt -> Zeilen ausblenden, Kopf "Weg <x> gesperrt (Treffer y %)"
--  lernt    -> Zeilen grau "lernt noch (n von 20)", keine Kauf-Empfehlung (kein goldenes Signal)
--  Absatz-Ansichten (Flippen, Lücken, Überfüllt) erst mit MA1-Freigabe, sonst grau "lernt noch (n von 30)"
-- Rückgabe: Zeilen, Kopf-Text oder nil
-- ------------------------------------------------------------
local WAY_LABEL = { flip = "Flippen", vendor = "Händler", de = "Entzaubern" }
local SALES_VIEW = { flip = true, gaps = true, crowded = true }
function MK:ApplyRelease(view, rows)
    local way = VIEW_WAY[view]
    if not way then return rows, nil end
    local st, n = self:WayState(way)
    if st == "gesperrt" then
        local _, q = self:Quote(way)
        return {}, string.format(L["Weg %s gesperrt (Treffer %d %%)"], L[WAY_LABEL[way] or way], math.floor((q or 0) * 100 + 0.5))
    end
    local note, head
    if st == "lernt" then
        note = string.format(L["lernt noch (%d von %d)"], n, self.FREE_MIN)
        head = string.format(L["Weg %s lernt noch (%d von %d Fällen) – Zahlen nur geschätzt"], L[WAY_LABEL[way] or way], n, self.FREE_MIN)
    elseif SALES_VIEW[view] then
        local ok, m = self:SalesReleased()
        if not ok then
            note = string.format(L["lernt noch (%d von %d)"], m, 30)
            head = string.format(L["Absatz lernt noch (%d von %d eigenen Fällen) – Zahlen nur geschätzt"], m, 30)
        end
    end
    if note then
        for _, r in ipairs(rows or {}) do
            r.learning, r.recommend, r.safety = true, false, "niedrig"
            r.coreNote = r.coreNote or note
        end
    end
    return rows, head
end

-- MR1/MR3 (Phase 7, Vorschlag A Teil 1): Fusszeile "Treffer je Weg" für den Markt-Reiter - je Weg (MA2) frei mit Quote und
-- Fällen, lernt (n von 20) oder gesperrt mit Quote. Nur Anzeige (MK:Quote/MK:WayState).
local WAY_NAME = { flip = "Flippen", snipe = "Sniper", de = "Entzaubern", craft = "Herstellen", vendor = "Händler" }
function MK:QuoteLine()
    local parts = {}
    for _, w in ipairs(self.WAYS) do
        local st, n = self:WayState(w)
        local _, q = self:Quote(w)
        local name = L[WAY_NAME[w] or w]
        if st == "frei" then parts[#parts + 1] = string.format("%s |cff33dd55%d %%|r (%d)", name, math.floor((q or 0) * 100 + 0.5), n)
        elseif st == "gesperrt" then parts[#parts + 1] = string.format("%s |cffff5544%d %%|r", name, math.floor((q or 0) * 100 + 0.5))   -- rot = gesperrt (Tooltip)
        else parts[#parts + 1] = string.format("%s |cff888888%d/%d|r", name, n, self.FREE_MIN) end
    end
    return L["Treffer je Weg:"] .. " " .. table.concat(parts, " · ")
end

-- FL-1: Budget je Item (Kupfer); probe = Weg lernt noch -> nur PROBE_SHARE davon
function MK:ItemBudget(probe)
    local K = A.Comfort
    local money = self.testMoney or (GetMoney and GetMoney()) or 0
    local cap = money * ((K and K.TODAY_ITEM_SHARE) or 0.10)
    if probe then cap = cap * ((K and K.PROBE_SHARE) or 0.10) end
    return math.floor(cap)
end
-- SK1-r (FL-1): Vorschlag-Einsatz je Item ≤ Budget je Item (gezeigte Heute-Liste). Zurück: n, ok, bad, Beispiele
function MK:CheckTodayBudget(rows)
    local n, ok, bad, ex = 0, 0, 0, {}
    for _, r in ipairs(rows or {}) do
        if (r.capital or 0) > 0 then
            n = n + 1
            local cap = self:ItemBudget(r.learning)
            if r.capital <= cap + 1 then ok = ok + 1 else
                bad = bad + 1
                if #ex < 3 then ex[#ex + 1] = string.format("Item %s: Einsatz %d > Budget %d%s", tostring(r.itemID), r.capital, cap, r.learning and " (lernt)" or "") end
            end
        end
    end
    return n, ok, bad, ex
end
-- MH1310: Freigaben und Ü3 auch in "Heute tun" (Zeilen aus Comfort:TodayActions, Feld kind)
local TODAY_WAY = { flip = "flip", bid = "flip", de = "de", vendor = "vendor" }
function MK:ApplyTodayRelease(rows)
    local out, grey = {}, {}
    local salesOK, m = self:SalesReleased()
    for _, r in ipairs(rows or {}) do
        local way = TODAY_WAY[r.kind or ""]
        local keep, note = true, nil
        if way then
            local st, n = self:WayState(way)
            if st == "gesperrt" then keep = false
            elseif st == "lernt" then note = string.format(L["lernt noch (%d von %d)"], n, self.FREE_MIN)
            elseif way == "flip" and not salesOK then note = string.format(L["lernt noch (%d von %d)"], m, 30) end
            -- Ü3 in Heute: Gewinn > 300 % -> Daten prüfen, keine Empfehlung
            local buy, unit = r.price, r.unitGold
            if keep and buy and buy > 0 and unit then
                local why = self:Implausible(unit / buy * 100)
                if why then note = L["unplausibel"] .. ": " .. why; r.implausible = why end
            end
        end
        -- FL-1 (Gold-Sicherheit): Kauf-Vorschlag eines lernenden Wegs -> höchstens eine kleine Probe (10 % des Budgets je
        -- Item); jeder Kauf höchstens das Budget je Item (10 % des Golds). Zu klein für ein Stück -> Zeile fällt weg.
        if keep and way and r.price and r.price > 0 and r.qty then
            local cap = self:ItemBudget(note ~= nil)
            if r.price * r.qty > cap then
                local q = math.floor(cap / r.price)
                if q < 1 then keep = false
                else
                    r.qty, r.capital = q, r.price * q
                    if r.unitGold then r.gold = math.floor(r.unitGold * q) end
                    if r.retext then r.text = r.retext(q) end
                    r.probe = note ~= nil or nil
                end
            end
        end
        if keep then
            if note then
                r.learning, r.recommend, r.safety, r.coreNote = true, false, "niedrig", note
                grey[#grey + 1] = r
            else out[#out + 1] = r end
        end
    end
    -- TB170-1 (T72): FL-1 kürzt Mengen -> Gewinn kleiner -> je Gruppe neu nach Gewinn sortieren (Aufträge oben bleiben oben)
    local function byGold(a, b)
        if (a.pin and true or false) ~= (b.pin and true or false) then return a.pin and true or false end
        return (a.gold or 0) > (b.gold or 0)
    end
    table.sort(out, byGold)
    table.sort(grey, byGold)
    for _, r in ipairs(grey) do out[#out + 1] = r end        -- graue Zeilen (keine Empfehlung) nach unten
    return out
end

-- ------------------------------------------------------------
-- MA1 (eigene Auktionen als Wahrheit)
-- ------------------------------------------------------------
MK.ownPrev, MK.guess, MK.truthWait = MK.ownPrev or {}, MK.guess or {}, MK.truthWait or {}
MK.TRUTH_WAIT = 600            -- MA1-B: Wahrheit, die VOR der Vermutung kommt, 10 Min. aufheben
local function Long(o)
    local tl = o.timeLeft
    if type(tl) ~= "number" then return false end
    if tl <= 4 then return tl >= 3 end              -- Blizzard-Stufen 1..4 (3 = 2–12 Std., 4 = > 12 Std.)
    return tl > MK.LONG                             -- Sekunden
end
function MK:OnOwned(list)
    local now, cur, newSig = Now(), {}, {}
    for _, o in ipairs(list or {}) do
        if o.auctionID and not o.sold then
            cur[o.auctionID] = o
            -- MA1-B (b): "neu eingestellt" nur aus auctionIDs, die vorher NICHT da waren
            if not self.ownPrev[o.auctionID] then
                local sig = tostring(o.itemID) .. ":" .. tostring(o.qty)
                newSig[sig] = (newSig[sig] or 0) + 1
            end
        end
    end
    for aid, o in pairs(self.ownPrev) do
        if not cur[aid] and Long(o) and not self.guess[aid] then
            local sig = tostring(o.itemID) .. ":" .. tostring(o.qty)
            local relist = (newSig[sig] or 0) > 0
            if relist then newSig[sig] = newSig[sig] - 1 end            -- eine neue Auktion erklärt nur EINE verschwundene
            self.guess[aid] = { g = relist and "neu" or "verkauft", t = now }
            -- MA1-B (a): Wahrheit kam schon vorher (Abbruch/Verkauf feuern vor der neuen Liste) -> jetzt werten
            local w = self.truthWait[aid]
            if w then self.truthWait[aid] = nil; self:Truth(aid, w.truth) end
        end
    end
    for aid, w in pairs(self.truthWait) do if now - w.t > self.TRUTH_WAIT then self.truthWait[aid] = nil end end
    self.ownPrev = cur
end
function MK:Truth(aid, truth)
    local g = aid and self.guess[aid]
    local db = self:Store()
    if not db then return false end
    if not g then
        -- MA1-B (a): Vermutung fehlt noch -> Wahrheit aufheben, bis die neue Liste die Vermutung bildet
        if aid then self.truthWait[aid] = { truth = truth, t = Now() } end
        return false
    end
    self.guess[aid] = nil
    local right = (g.g == "verkauft" and truth == "verkauft") or (g.g == "neu" and truth == "abgebrochen")
    db.ma1.n = db.ma1.n + 1
    if not right then db.ma1.wrong = db.ma1.wrong + 1 end
    return right
end
function MK:MA1Rate()
    local db = self:Data()
    local m = db and db.ma1
    if not (m and m.n > 0) then return 0, nil end
    return m.n, m.wrong / m.n
end
-- Absatz-Freigabe (Teil D): >= 30 eigene Fälle und Fehlerquote <= 20 %
function MK:SalesReleased()
    local n, r = self:MA1Rate()
    return n >= 30 and r and r <= 0.20 or false, n
end
A:On("OWN_AUCTION_SOLD", function(o) if o and o.auctionID then pcall(MK.Truth, MK, o.auctionID, "verkauft") end end)
A:On("AUCTION_CANCELLED", function(c) if c and c.auctionID then pcall(MK.Truth, MK, c.auctionID, "abgebrochen") end end)

-- ------------------------------------------------------------
-- RK2-A: EINE Rechnung für "Lohnt bis" (Entzaubern). Alle Stellen (Tooltip, Einkauf-Markierung, Warnschutz, Sniper-Ziele,
-- Markt "Entzaubern", Markt-Kaufgrenze, Sammelkauf, API) rufen diese Funktionen auf.
--   Lohnt bis je Stück = Netto-Wert × min( 1 / (1 + Mindestrendite), 1 − Sicherheitsmarge )
--   Sicherheitsmarge (RK5) = gelernte Marge (Ln:Margin "d"); ohne Lernen: 10 % unter 10 echten Entzauberungen, sonst 0.
--   Die strengere Grenze gewinnt; die Mindestrendite gilt damit immer.
-- ------------------------------------------------------------
function MK:MinRoi(itemID)
    local DEB = A.DEBuy
    return (DEB and DEB.DEMinRoi and DEB:DEMinRoi(itemID)) or A.DE_MIN_GAIN or 30
end
function MK:BaseMargin(n)
    local Ln = A.Learn
    if Ln and Ln.On and Ln:On() then
        if self.batchMargin and time() - (self.batchT or 0) < 60 then return self.batchMargin end
        local ok, m = pcall(Ln.Margin, Ln, "d")
        return (ok and type(m) == "number") and m or 0
    end
    local D, DEB = A.Disenchant, A.DEBuy
    if (n or 0) < ((D and D.FEW_DATA) or 10) then return (DEB and DEB.SAFETY) or 0.10 end
    return 0
end
-- RK5 (Antwort Supervisor 18:39, Vorschlag angenommen): Risiko-Wahl ändert NUR die Sicherheitsmarge.
--   normal (Standard) = heutige Marge (gemessener Fehler, Untergrenze wie bisher) -> keine Änderung für alle, die nichts wählen
--   vorsichtig = normal + 10 Punkte · mutig = normal − 5 Punkte, nie unter 5 % (und nie über normal)
--   Mindestrendite je Gruppe (DE30b) und 0,9 × Netto gelten in JEDER Stufe (LimitFromNet).
MK.RISKS = { "vorsichtig", "normal", "mutig" }
function MK:Risk()
    local r = A.db and A.db.settings and A.db.settings.risk
    return (r == "vorsichtig" or r == "mutig") and r or "normal"
end
function MK:AdjustMargin(m, risk)
    risk = risk or self:Risk()
    if risk == "vorsichtig" then return math.min(0.9, m + 0.10) end
    if risk == "mutig" then return math.max(m - 0.05, math.min(m, 0.05)) end
    return m
end
function MK:SafetyMargin(n)
    return self:AdjustMargin(self:BaseMargin(n), self.riskOverride)
end
-- Beispiel für die Einstellungen: "Lohnt bis" je Stufe für einen Netto-Wert (Standard 10s, 50 eigene Entzauberungen)
function MK:RiskExample(net, n)
    net, n = net or 1000, n or 50
    local out = {}
    for _, r in ipairs(self.RISKS) do
        self.riskOverride = r
        local ok, v = pcall(self.LimitFromNet, self, net, n, nil)
        out[r] = ok and v or nil
    end
    self.riskOverride = nil
    return out
end
-- für Schleifen über viele Items (Markt "Entzaubern"): Marge einmal rechnen
function MK:BeginBatch()
    local Ln = A.Learn
    self.batchMargin, self.batchT = nil, time()
    if Ln and Ln.On and Ln:On() then
        local ok, m = pcall(Ln.Margin, Ln, "d")
        self.batchMargin = (ok and type(m) == "number") and m or 0
    end
end
function MK:EndBatch() self.batchMargin = nil end
-- SN-M (Messung Prüf-Sitzung 14.11. 01:20, 462 Käufe): Kaufpreis/Wert 0,8–0,9 bringt nur +18 %, > 0,9 ≈ 0 % ->
-- harte Obergrenze: nie mehr als 0,9 × Netto-Wert (gilt für jede Entzauber-Kaufgrenze, auch Sniper-Ziele)
MK.DE_MAX_SHARE = 0.9
-- ------------------------------------------------------------
-- RK6 Halte-Risiko (anweisung-markt-reiter RK6; Antwort Supervisor 21:02 F1–F3, 21:33 G1/G2).
-- Wert beim nächsten Login = Wert jetzt × (1 + Band-Trend × Tage bis zum nächsten Login). Richtung nur aus einem BELEGTEN
-- MA4-Band (sonst 0 %, "lernt noch"). ANNAHME RK6 bis zur Messung: fällt -5 %/Tag; Spitze = jetzt verkaufen, nie halten,
-- nie mit Haltedauer kaufen (Faktor 0); ruhig/steigt 0 % (Steigen nie als Gewinn). Nur wenn der Verkauf > 1 Tag dauert.
-- Rückgabe: Faktor (0..1), Richtung oder nil, Tage bis zum nächsten Login
-- ------------------------------------------------------------
MK.RK6_FALL_PER_DAY = 0.05
function MK:HoldFactor(itemID, saleDays, now)
    if not (itemID and saleDays and saleDays > 1) then return 1, nil end
    local W = A.Waves
    local okT, dir = false, nil
    if W and W.ItemTrend then okT, dir = pcall(W.ItemTrend, W, itemID, now) end
    if not (okT and dir) then return 1, nil end
    if dir == "spitze" then return 0, dir end
    if dir ~= "faellt" then return 1, dir end
    local days = 1
    local Act = A.Activity
    if Act and Act.Rhythm then
        local okR, r = pcall(Act.Rhythm, Act, now)
        if okR and r and r.days then days = r.days end
    end
    return math.max(0, 1 - self.RK6_FALL_PER_DAY * days), dir, days
end
-- Entzaubern: gehalten werden die Materialien - Verkaufsdauer des wichtigsten Materials (Wert × Stück je Entzauberung)
function MK:DEHoldFactor(itemID)
    local W = A.Waves
    if not (W and W.ItemTrend) then return 1 end
    local okT, dir = pcall(W.ItemTrend, W, itemID)
    if not (okT and dir) or dir == "ruhig" or dir == "steigt" then return 1, dir end      -- billig zuerst: meist keine Wirkung
    local D = A.Disenchant
    local okM, mats = false, nil
    if D and D.PerPartMats then okM, mats = pcall(D.PerPartMats, D, itemID) end
    local main, best = nil, 0
    for _, m in ipairs((okM and mats) or {}) do
        local okP, p = pcall(D.MatPrice, D, m.id)
        local v = (okP and p or 0) * (m.per or 0)
        if v > best then main, best = m, v end
    end
    local days = 1
    if main then
        local okO, v = pcall(A.SellOutlook, A, main.id, math.max(1, math.ceil(main.per or 1)))
        if okO and v and v.wait then days = v.wait end
    end
    return self:HoldFactor(itemID, days)
end

function MK:LimitFromNet(net, n, itemID)
    if not (net and net > 0) then return nil end
    -- RK6: Halte-Risiko auf den Netto-Wert (nur belegte Bänder; Spitze -> kein "Lohnt bis")
    if itemID then
        local okH, hf = pcall(self.DEHoldFactor, self, itemID)
        if okH and hf and hf < 1 then
            net = math.floor(net * hf)
            if net <= 0 then return nil end
        end
    end
    -- RK4: Weg Entzaubern abgewählt bzw. (mit Item) keine eigene Figur kann es entzaubern -> kein "Lohnt bis"
    if not A:WayOn("de") then return nil end
    local D = A.Disenchant
    if itemID and D and D.WayDE and not D:WayDE(itemID) then return nil end
    local r, m = self:MinRoi(itemID) / 100, self:SafetyMargin(n)
    -- Rechenkern S2/V2: hält eine Kaufpreis-Stufe ihren Mindestgewinn nicht (eigene Zählung + Tabelle), Grenze dort
    -- senken - nie über DE_MAX_SHARE (0,9). Testroutine: fest 0,9 (ausser im eigenen Test mit Ersatz-Daten)
    local share = self.DE_MAX_SHARE
    local Kn = A.Kern
    if Kn and Kn.BuyShareCap and (Kn.testDB or not (A.InTestRoutine and A:InTestRoutine())) then
        local okS, sc = pcall(Kn.BuyShareCap, Kn, r)
        if okS and type(sc) == "number" and sc < share then share = sc end
    end
    if share <= 0 then return nil end                 -- S2-B3: keine Stufe hält den Mindestgewinn -> kein "Lohnt bis"
    local cap = math.floor(net * share)
    if 1 / (1 + r) <= 1 - m then return math.min(cap, math.floor(net / (1 + r))) end     -- Mindestrendite ist strenger (wie bisher gerechnet)
    return math.min(cap, math.floor(net * (1 - m)))
end
-- je Stück: Lohnt bis, Netto-Wert, sicher (vollständig und frisch), Info { stale, complete, basis, n, v }
function MK:DELimit(itemID, nParts)
    local D = A.Disenchant
    if not (D and D.DealValue and itemID) then return nil end
    if D.WayDE and not D:WayDE(itemID) then return nil end              -- RK4: Weg abgewählt oder keine Verzauberkunst
    local ok, v, net, complete, basis, n = pcall(D.DealValue, D, itemID)
    if not (ok and v and net and net > 0) then return nil end
    local okS, stale = pcall(D.StaleMain, D, itemID)
    stale = (okS and stale) and true or false
    if nParts and nParts > 1 and D.BatchNet then
        local okB, bn = pcall(D.BatchNet, D, itemID, nParts)
        if okB and bn and bn < net then net = bn end
    end
    if net <= 0 then return nil end
    return self:LimitFromNet(net, n, itemID), net, (complete and not stale) and true or false,
        { stale = stale, complete = complete and true or false, basis = basis, n = n or 0, v = v }
end
-- Betrag für qty Stück (je Stück × qty), Weg, "sicher"/"unsicher", je Stück, Info
function MK:WorthUpTo(itemID, qty, nParts)
    local per, net, sure, info = self:DELimit(itemID, nParts)
    if not per then return nil end
    qty = math.max(1, math.floor(tonumber(qty) or 1))
    return per * qty, "disenchant", sure and "sicher" or "unsicher", per, info
end
-- Selbsttest/Ü3: alle Stellen liefern für dasselbe Item denselben Betrag? Rückgabe: Liste { itemID, werte = {stelle = betrag} }
function MK:LimitSources(itemID)
    local out = {}
    local per, net, sure, info = self:DELimit(itemID)
    if not per then return out end
    out.kern = per
    local TT, D, DEB, API = A.Tooltip, A.Disenchant, A.DEBuy, A.API or (AHSentinel and AHSentinel.API)
    if TT and TT.DisenchantVerdict then local ok, r = pcall(TT.DisenchantVerdict, TT, itemID); if ok and r and r.limit then out.tooltip = r.limit end end
    if sure and D and D.WorthLimit then local ok, l = pcall(D.WorthLimit, D, itemID); if ok and l then out.einkauf = l end end
    if D and D.DealLimit then local ok, l = pcall(D.DealLimit, D, itemID); if ok and l then out.markt = l end end
    if sure and DEB and DEB.Value then local ok, l = pcall(DEB.Value, DEB, itemID, 1); if ok and l then out.sammelkauf = l end end
    local MV = A.MarketView
    if MV and MV.DELimitFor then local ok, l = pcall(MV.DELimitFor, MV, itemID); if ok and l then out.marktgrenze = l end end
    -- RK2-B: angezeigte Markt-Zeile "Entzaubern" (1 Stück), ihre Detailzeile und das Sniper-Entzauberziel
    if sure and MV and MV.DERowLimit then local l = MV:DERowLimit(itemID); if l then out.marktzeile = l end end
    if sure and MV and MV.DEDetailLimit and info.n ~= nil then
        local okP, pv = pcall(D.PlannedValue, D, itemID, 1)
        if okP and pv then local ok, l = pcall(MV.DEDetailLimit, MV, pv, info.n, itemID); if ok and l then out.detail = l end end
    end
    local Sn = A.Sniper
    if sure and Sn and Sn.UpdateDETargets then
        local t = { de = true, kind = "item", itemID = itemID, maxPrice = per + 1 }
        local okS = pcall(Sn.UpdateDETargets, Sn, { t }, true)          -- still: keine Chat-Zeile, kein SNIPER_CHANGED
        if okS then out.sniper = t.maxPrice end
    end
    if not info.stale and API and API.WorthUpTo then local ok, l = pcall(API.WorthUpTo, itemID, 1); if ok and l then out.api = l end end
    return out
end
function MK:LimitMismatch(itemID)
    local src = self:LimitSources(itemID)
    if not src.kern then return nil end
    local bad = {}
    for k, v in pairs(src) do if v ~= src.kern then bad[#bad + 1] = k .. "=" .. tostring(v) end end
    if #bad == 0 then return nil end
    table.sort(bad)
    return "Lohnt bis " .. tostring(src.kern) .. " · abweichend: " .. table.concat(bad, ", ")
end

-- ------------------------------------------------------------
-- Ü3 Plausibilität: Rückgabe nil oder Grund
-- ------------------------------------------------------------
function MK:Implausible(profitPct, salesPerHour, offerQty, productOffers)
    if profitPct and profitPct > 300 then return L["Gewinn > 300 % – Daten prüfen"] end
    if salesPerHour and offerQty and offerQty > 0 and salesPerHour > offerQty * 0.25 then return L["Absatz > 25 % des Angebots je Stunde – unplausibel"] end
    if productOffers and productOffers < 5 then return L["dünner Markt (< 5 Angebote)"] end
    return nil
end
-- Ü3 in den Markt-Zeilen: unplausible Vorschläge markieren (Spalte "Stand") und nicht als Empfehlung nachprüfen
function MK:MarkRows(view, rows)
    if not VIEW_WAY[view] then return 0 end
    local n = 0
    for _, r in ipairs(rows or {}) do
        local buy = r.price or r.buy
        local pred = r.upto and (r.net or r.value or r.sell) or (r.sell or r.sellPrice or r.value or r.vendor)
        if r.itemID and buy and buy > 0 and pred then
            local _, qty = A:GetCurrent(r.itemID)
            local pct = (pred - buy) / buy * 100
            local why = self:Implausible(pct, r.salesPerHour, qty, r.productOffers)     -- Produkt-Angebote nur bei Herstellen
            if why then
                r.implausible = why
                r.state = L["unplausibel"] .. ": " .. why
                r.coreNote, r.recommend = r.state, false
                n = n + 1
            end
        end
    end
    return n
end

-- ------------------------------------------------------------
-- Ü1/Ü2: Testbericht-Abschnitt "MARKT-KERN"
-- ------------------------------------------------------------
function MK:Report()
    local out = { "MARKT-KERN (Ü1):" }
    for _, w in ipairs(self.WAYS) do
        local n, q, e = self:Quote(w)
        local st = self:WayState(w)
        out[#out + 1] = string.format("  Weg %s: Fälle %d · Treffer %s · mittlerer Fehler %s · %s%s", w, n, q and string.format("%d %%", math.floor(q * 100 + 0.5)) or "-",
            e and string.format("%d %%", math.floor(e * 100 + 0.5)) or "-", st, (st == "frei" and q and q < 0.70) and " (unter Ziel 70 %)" or "")
        if st == "gesperrt" then out[#out + 1] = string.format("  Ü2 VERFEHLT: Weg %s Trefferquote unter 60 %%", w) end
        if st == "frei" and e and e > 0.15 then out[#out + 1] = string.format("  Ü2 VERFEHLT: Weg %s mittlerer Fehler über 15 %%", w) end
    end
    local n1, r1 = self:MA1Rate()
    out[#out + 1] = string.format("  MA1 eigene Auktionen geprüft %d · Fehlerquote %s%s", n1, r1 and string.format("%d %%", math.floor(r1 * 100 + 0.5)) or "-",
        (r1 and n1 >= 30 and r1 > 0.20) and " · Ü2 VERFEHLT (> 20 %)" or "")
    out[#out + 1] = string.format("  MA3 Händlerpreise vom Spiel bestätigt %d · abweichend von der Tabelle %d", A.vendorCheckedCount or 0, A.vendorDiffCount or 0)
    -- MA4: Stufenbänder nach benötigter Stufe (Waves.lua W:LevelBands, einmal je Tag im Hintergrund)
    local Wv = A.Waves
    local okB, bands = false, nil
    if Wv and Wv.LevelBands then okB, bands = pcall(Wv.LevelBands, Wv) end
    if okB and bands then
        for _, b in ipairs(bands) do
            if b.belegt then
                out[#out + 1] = string.format("  MA4 Band %s: belegt (%d Tage, %d Items) · Richtung %s · 3 Tage %s · letzter Tag %s · ANNAHME fällt/steigt ±5 %%", b.key, b.days, b.items,
                    tostring(b.dir), b.d3 and string.format("%+.1f %%", b.d3 * 100) or "-", b.d1 and string.format("%+.1f %%", b.d1 * 100) or "-")
            else
                out[#out + 1] = string.format("  MA4 Band %s: messe noch (%d von %d Tagen mit ≥ %d Items; %d Items)", b.key, b.days, Wv.MA4_MIN_DAYS, Wv.MA4_MIN_ITEMS, b.items)
            end
        end
    else
        out[#out + 1] = "  MA4 Stufenbänder: wird berechnet (Hintergrund, einmal je Tag)"
    end
    -- MR4 (Supervisor 00:34): die Lage-Zeile so, wie sie im Markt-Reiter steht (Kopf, 1. Zeile) - zum Wiederfinden im Spiel
    local MVr = A.MarketView
    if MVr and MVr.LageLine then
        local okL, ll = pcall(MVr.LageLine, MVr)
        if okL and ll then
            out[#out + 1] = "  MR4 LAGE-ZEILE (Markt-Reiter > Kopf oben, 1. Zeile; Bänder als farbige Abschnitte): "
                .. ll:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
        end
    end
    -- RK6 / F1: Annahme und gemessener Verlauf je Band (Index jetzt gegen den letzten Eintrag vorher)
    if Wv and Wv.BandHistory then
        local okH, hist = pcall(Wv.BandHistory, Wv)
        local parts = {}
        for key, l in pairs((okH and hist) or {}) do
            -- RK6-F1b: nur zwei Einträge derselben Kette (gleiche Basis) vergleichen; Tage zwischen den Datentagen
            -- (letzter Eintrag gegen den jüngsten früheren Datentag derselben Kette)
            local b, a = l[#l], nil
            for i = #l - 1, 1, -1 do
                local e = l[i]
                if b and b[4] and e[4] == b[4] and e[5] and b[5] and e[5] < b[5] then a = e; break end
            end
            if a then
                local days = math.max(1, math.floor((b[5] - a[5]) / 86400 + 0.5))
                local ch = a[2] > 0 and (b[2] / a[2] - 1) or 0
                parts[#parts + 1] = string.format("%s %s -> %s: %+.1f %% in %d Tagen (%+.1f %%/Tag, Richtung vorher %s)", key, date("%d.%m.", a[5]), date("%d.%m.", b[5]),
                    ch * 100, days, ch * 100 / days, tostring(a[3]))
            end
        end
        table.sort(parts)
        out[#out + 1] = string.format("  RK6 ANNAHME fällt %d %%/Tag, Spitze = verkaufen, ruhig/steigt 0 %% · gemessen: %s", math.floor(self.RK6_FALL_PER_DAY * 100 + 0.5),
            #parts > 0 and table.concat(parts, " · ") or "noch keine zwei Tage mit belegtem Band")
    end
    -- MR7 (Supervisor 21:48): Trefferquote "nächstes Login vorhergesagt vs. wirklich" je Woche (nur gelernte Vorhersagen)
    local Act = A.Activity
    if Act and Act.RhythmHits then
        local okH, wk = pcall(Act.RhythmHits, Act)
        local parts = {}
        for _, w in ipairs((okH and wk) or {}) do parts[#parts + 1] = string.format("Woche %s: %d von %d", w[1], w[2], w[3]) end
        out[#out + 1] = "  MR7 nächstes Login vorhergesagt vs. wirklich (ANNAHMEN 50 % je Wochentag, einige Tage = 2, gespielt ab 10 Min.): "
            .. (#parts > 0 and table.concat(parts, " · ") or "noch keine gelernte Vorhersage geprüft")
    end
    -- V4: Tages-/Wochenzyklus je Band - nur Messung, nicht angezeigt, bis belegt (≥ 3 Wochen, ≥ 80 % gleiche Richtung)
    if Wv and Wv.CycleStatus then
        local okC, st = pcall(Wv.CycleStatus, Wv)
        for _, r in ipairs((okC and st) or {}) do
            local function one(x, name)
                if r.weeks < Wv.V4_WEEKS then return string.format("%s messe (%d von %d Wochen)", name, r.weeks, Wv.V4_WEEKS) end
                return string.format("%s %s (%d %% gleich%s)", name, x.belegt and "BELEGT" or "nicht belegt", math.floor(x.share * 100 + 0.5),
                    x.belegt and (" · " .. x.pattern) or "")
            end
            out[#out + 1] = string.format("  V4 Band %s: %s · %s (ANNAHMEN ±1 %%, ≥ 20 Werte; nur Messung)", r.key, one(r.h, "Tageszyklus"), one(r.d, "Wochenzyklus"))
        end
    end
    -- G1: Zuordnung der Entzauber-Materialien zu den Bändern (ohne benötigte Stufe)
    if Wv and Wv.BANDS and Wv.MAT_BAND then
        local parts = {}
        for _, band in ipairs(Wv.BANDS) do
            local bi = Wv.MAT_BAND[band.key]
            parts[#parts + 1] = string.format("%s -> %s (%d Materialien)", band.key, bi and Wv.LBANDS[bi].key or "-", #band.mats)
        end
        out[#out + 1] = "  MA4 Materialien ohne Stufe (Herkunft, G1): " .. table.concat(parts, " · ")
    end
    local last = A.db and A.db.lastScanTime
    out[#out + 1] = string.format("  letzter Vollscan/Scan: %s", last and date("%d.%m. %H:%M", last) or "-")
    local db = self:Data()
    out[#out + 1] = string.format("  offene Empfehlungen %d", db and #(db.recs or {}) or 0)
    return out
end

-- ------------------------------------------------------------
-- TU5 ECHTE DATEN (nur lesen): Grundregeln (TU4) an den eigenen Daten. Ändert nichts, führt nichts aus.
-- "/ahs testroutine echt" (mit Chat-Ergebnis) und still nach jedem Vollscan (Hintergrund, in Portionen).
-- Verletzungen ins Diagnose-Protokoll "GRUNDREGEL VERLETZT" (Item-ID und Zahlen, keine Namen).
-- ------------------------------------------------------------
MK.REAL_MAX_BAD = 50
local function GoodMoney(v) return type(v) == "number" and v == v and v >= 0 and v < math.huge and v == math.floor(v) end
function MK:RealBad(id, bad, txt)
    bad[#bad + 1] = id .. ": " .. txt
    if A.Diag and not self.testDB then pcall(A.Diag.Add, A.Diag, "GRUNDREGEL VERLETZT", "Item " .. id .. " · " .. txt) end
end
function MK:RealCheckItem(id, bad)
    local Se, D = A.Seller, A.Disenchant
    -- TB138b-3: keine neue Hilfsfunktion je Item (Müll je Vollscan)
    local p = A:GetCurrent(id)
    if p ~= nil and not GoodMoney(p) then self:RealBad(id, bad, "Preis " .. tostring(p)) end
    local mv = A:GetMarketValue(id)
    if mv ~= nil and not GoodMoney(mv) then self:RealBad(id, bad, "Marktwert " .. tostring(mv)) end
    -- RK2: ein "Lohnt bis" (teuer: nur die ersten REAL_DE_MAX Entzauber-Teile je Lauf)
    -- NP152-3: je Lauf nur REAL_DE_MAX Teile, reihum (nächster Lauf die nächsten) - eine Prüfung legt ~160 KB an
    if D and D.Prior and (self.realDE or 0) < self.REAL_DE_MAX and D:Prior(id) then
        self.realDESeen = (self.realDESeen or 0) + 1
        if self.realDESeen > (self.realDEOffset or 0) then
            self.realDE = (self.realDE or 0) + 1
            local okM, m = pcall(self.LimitMismatch, self, id)
            if okM and m then self:RealBad(id, bad, m) end
        end
    end
    -- Vorschlag nie unter günstigstem fremdem − Unterbietung (ausser eigenes günstigstes, Ausreisser, dünne Leiter mit
    -- gelerntem Normalpreis, Preis von Hand)
    local pr = Se and Se.prices and Se.prices[id]
    if pr and pr.lowestOther and Se:IsPriceFresh(id) and Se:AutoApplyAllowed(id) then
        local okS, v, why = pcall(Se.SuggestRaw, Se, id)
        if okS then
            if not (GoodMoney(v) and v >= 1) then self:RealBad(id, bad, "Vorschlag " .. tostring(v))
            else
                local u = Se:Undercut(pr.lowestOther, id)
                local own = pr.lowestOwn and pr.lowestOwn <= pr.lowestOther
                local w = tostring(why)
                local exempt = own or w:find(L["Marktwert – einzelnes teures Angebot (Ausreisser)"], 1, true) or
                    (w:find(L["Normalpreis (gelernt) - Konkurrenz liegt über deinem Maximum"], 1, true) and not Se:LadderFull(pr))
                if not exempt and v < u then self:RealBad(id, bad, string.format("Vorschlag %d unter günstigstem %d − Unterbietung (%d)", v, pr.lowestOther, u)) end
            end
        end
    end
end
MK.REAL_DE_MAX = 10          -- D3/NP152-3: "ein Lohnt bis" (teuer) je Lauf 10 Entzauber-Teile, reihum
function MK:RealCheck(verbose)
    -- TU5-Doppelmeldung: läuft schon ein Lauf, meldet DIESER das Ergebnis (einmal); keine zweite Meldung
    if self.realRunning then
        if verbose then self.realVerbose = true end
        return false
    end
    if not (A.db and A.db.marketData) then return false end
    self.realRunning, self.realVerbose = true, verbose and true or nil
    A:Job("core:realcheck", function()
        local n, bad, i = 0, {}, 0
        self.realDE, self.realDESeen = 0, 0
        local ok, err = A:PCall(function()          -- A:PCall: Pausen innerhalb sind erlaubt (pcall bräche beim yield ab)
            for id in pairs(A.db.marketData) do
                i = i + 1
                -- D3 (DG1300: core:realcheck 240 ms): jede Prüfung eine eigene Portion, gelernte Marge einmal je 200 Items
                if i % 200 == 1 then self:BeginBatch() end
                A:Pause()
                if #bad >= self.REAL_MAX_BAD then break end
                n = n + 1
                self:RealCheckItem(id, bad)
            end
        end)
        self:EndBatch()
        -- reihum: nächster Lauf beginnt nach den heute geprüften; am Ende der Liste wieder vorne
        if (self.realDE or 0) < self.REAL_DE_MAX then self.realDEOffset = 0 else self.realDEOffset = (self.realDEOffset or 0) + self.REAL_DE_MAX end
        -- Sniper: nie über Budget, nie mehr als die Menge, Max-Preis ganzzahlig
        local Sn = A.Sniper
        local db = A.db and A.db.sniper
        for key, t in pairs((db and db.targets) or {}) do
            if t.maxPrice and not GoodMoney(t.maxPrice) then bad[#bad + 1] = tostring(key) .. ": Max-Preis " .. tostring(t.maxPrice) end
            if (t.spent or 0) > (t.budget or 0) and (t.budget or 0) > 0 then bad[#bad + 1] = string.format("%s: ausgegeben %d über Budget %d", tostring(key), t.spent or 0, t.budget or 0) end
            if (t.bought or 0) > (t.qty or 0) and (t.qty or 0) > 0 then bad[#bad + 1] = string.format("%s: gekauft %d über Menge %d", tostring(key), t.bought or 0, t.qty or 0) end
        end
        self.lastReal = { t = time(), n = n, bad = #bad, first = bad[1], err = (not ok) and tostring(err) or nil }
        self.realRunning = nil
        local say = self.realVerbose
        self.realVerbose = nil
        if not ok and A.Diag then pcall(A.Diag.Add, A.Diag, "FEHLER", "core:realcheck: " .. tostring(err)) end
        if say then
            A:Print(string.format(L["Echte Daten (TU5): %d Items geprüft, %d Verletzungen%s"], n, #bad, bad[1] and (" – " .. bad[1]) or ""))
        end
    end)
    return true
end
A:On("SCAN_FINISHED", function()
    if (A.TestRoutine and A.TestRoutine.running) or A.lastScanKind ~= "Vollscan" then return end
    pcall(MK.RealCheck, MK, false)
end)

-- Nachprüfen nach jedem Scan (klein, ohne Pause nötig: höchstens 200 Fälle)
A:On("SCAN_FINISHED", function()
    if (A.TestRoutine and A.TestRoutine.running) or not MK:Store() then return end
    -- 0.65.110 (Ruckeln): Nachprüfen in einer Hintergrund-Aufgabe, je Empfehlung eine mögliche Portion
    A:Job("core:resolve", function()
        local ok, err = A:PCall(MK.Resolve, MK, nil, true)
        if not ok and A.Diag then pcall(A.Diag.Add, A.Diag, "FEHLER", "core:resolve: " .. tostring(err)) end
    end)
end)
