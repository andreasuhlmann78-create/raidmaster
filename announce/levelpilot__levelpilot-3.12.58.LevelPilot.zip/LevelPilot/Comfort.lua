-- LevelPilot - Komfort
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Haendler-Automatik (graue Gegenstaende verkaufen, reparieren), automatisch zum geplanten
-- Ziel fliegen, Zeitanzeige (EP pro Stunde, Zeit bis zum naechsten Level und bis 60),
-- Wegpunkte per Befehl und "Finde naechsten" (Haendler, Trainer, Bank, Briefkasten ...).
-- Shift gedrueckt halten pausiert alle Automatiken.

local _, LP = ...
local L = LP.L
local C = {}
LP:RegisterModule("Comfort", C)

local function Paused() return IsShiftKeyDown() end

local function Money(copper)
    copper = math.floor(copper or 0)
    local g, s, c = math.floor(copper / 10000), math.floor(copper / 100) % 100, copper % 100
    if g > 0 then return string.format("%dg %ds %dc", g, s, c) end
    if s > 0 then return string.format("%ds %dc", s, c) end
    return c .. "c"
end
C.Money = Money

------------------------------------------------------------------------
-- Haendler
------------------------------------------------------------------------
function C:Repair()
    if not LP.db.autoRepair or not (CanMerchantRepair and CanMerchantRepair()) or not GetRepairAllCost then return end
    local cost, can = GetRepairAllCost()
    if not cost or cost <= 0 then return end
    if not can or (GetMoney and GetMoney() < cost) then
        LP:Print(L("Nicht genug Gold zum Reparieren (%s nötig).", Money(cost)))
        return
    end
    LP.Act.Call("RepairAllItems", RepairAllItems)
    LP:Print(L("Repariert für %s.", Money(cost)))
end

-- Qualitaet eines Gegenstands in der Tasche – auch wenn das Spiel sie (noch) nicht liefert
local GREY_COLOR = "|cff9d9d9d"
local function Quality(it)
    local q = it.quality
    if q and q >= 0 then return q end
    if C_Item and C_Item.GetItemQualityByID and it.id then
        local ok, v = pcall(C_Item.GetItemQualityByID, it.id)
        if ok and v then return v end
    end
    -- Farbe im Link: alte Clients "|cff9d9d9d", neuere "|cnIQ0:"
    if it.link and (it.link:find(GREY_COLOR, 1, true) or it.link:find("|cnIQ0:", 1, true)) then return 0 end
    local get = (C_Item and C_Item.GetItemInfo) or GetItemInfo
    local r = get and { get(it.link or it.id) } or {}
    return r[3]
end

-- Alle grauen Gegenstaende verkaufen – Waffen, Ruestung und Plunder. Ausnahme: Gegenstaende, die eine
-- laufende Quest braucht oder die eine Quest starten, gesperrte Plaetze und Gegenstaende ohne Verkaufswert.
-- Auch Gegenstaende, deren Preis das Spiel noch nicht geladen hat, werden verkauft (vorher blieben vor allem
-- Waffen aus aelteren Sitzungen liegen). Kein Knopf am Haendlerfenster (3.12.16): der Verkauf laeuft beim
-- Oeffnen von selbst, Option "autoSellGrey" (ab Werk an, /lp grau).
C.SELL_STEP = 0.2       -- Sekunden zwischen zwei Verkaeufen
C.merchantOpen = false

local function Sellable(it)
    return it and not it.noValue and not it.locked and Quality(it) == 0
        and not (LP.Tooltips and LP.Tooltips:IsProtected(it.id))
end

function C:GreyList()
    local list = {}
    for bag = 0, 4 do
        for slot = 1, LP.API.BagSlots(bag) do
            local it = LP.API.BagItem(bag, slot)
            if Sellable(it) then list[#list + 1] = { bag, slot, it.id } end
        end
    end
    return list
end

-- Verkaufslauf: gibt die Liste zurueck (oder nil, wenn nichts zu tun ist). Ein Gegenstand je Schritt, Abbruch,
-- sobald das Haendlerfenster zu ist (MERCHANT_CLOSED) oder ein Kampf beginnt.
function C:SellGrey()
    if not LP.db.autoSellGrey or LP:InCombat() or not C.merchantOpen then return nil end
    local list = C:GreyList()
    if #list == 0 then return nil end
    local run = { list = list, sold = 0 }
    C.sellRun = run
    local before = GetMoney and LP.SafeValue(GetMoney()) or 0
    local i = 0
    local function done()
        if C.sellRun == run then C.sellRun = nil end
        run.done = true
        if run.sold == 0 then return end
        C_Timer.After(0.6, function()
            local now = GetMoney and LP.SafeValue(GetMoney()) or 0
            local gain = type(now) == "number" and type(before) == "number" and now - before or 0
            LP:Print(L("%d graue Gegenstände verkauft für %s.", run.sold, Money(math.max(0, gain))))
        end)
    end
    local function step()
        if C.sellRun ~= run then return done() end
        i = i + 1
        local e = list[i]
        if not e or not C.merchantOpen or LP:InCombat() or not LP.db.autoSellGrey then return done() end
        local it = LP.API.BagItem(e[1], e[2])
        if Sellable(it) and it.id == e[3] then
            LP.Act.Call("Sell", LP.API.UseBagItem, e[1], e[2])
            run.sold = run.sold + 1
        end
        C_Timer.After(C.SELL_STEP, step)
    end
    step()
    return run
end

------------------------------------------------------------------------
-- Automatisch fliegen
------------------------------------------------------------------------
function C:AutoFly()
    if not LP.db.autoFly or Paused() then return end
    local step = LP.Engine:Current()
    if not step or step.t ~= "FLY" or not step.text then return end
    local dest = step.text
    if NumTaxiNodes and TaxiNodeName then
        for i = 1, NumTaxiNodes() do
            local name = TaxiNodeName(i)
            if name == dest or (name and name:find(dest, 1, true)) then
                if not TaxiNodeGetType or TaxiNodeGetType(i) == "REACHABLE" then
                    LP:Print(L("Fliege nach %s.", name))
                    LP.Act.Call("TakeTaxiNode", TakeTaxiNode, i)
                    return true
                end
            end
        end
    end
    if C_TaxiMap and C_TaxiMap.GetAllTaxiNodes and GetTaxiMapID then
        local ok, list = pcall(C_TaxiMap.GetAllTaxiNodes, GetTaxiMapID())
        for _, node in ipairs(ok and list or {}) do
            if node.name == dest and node.slotIndex and node.state == (Enum.FlightPathState and Enum.FlightPathState.Reachable) then
                LP:Print(L("Fliege nach %s.", node.name))
                LP.Act.Call("TakeTaxiNode", TakeTaxiNode, node.slotIndex)
                return true
            end
        end
    end
    return false
end

------------------------------------------------------------------------
-- Zeitanzeige
------------------------------------------------------------------------
-- EP je Level (Classic); fuer die Schaetzung bis 60
local XPNEED = { 400, 900, 1400, 2100, 2800, 3600, 4500, 5400, 6500, 7600, 8800, 10100, 11400, 12900, 14400,
    16000, 17700, 19400, 21300, 23200, 25200, 27300, 29400, 31700, 34000, 36400, 38900, 41400, 44300, 47400,
    50800, 54500, 58600, 62800, 67100, 71600, 76100, 80800, 85700, 90700, 95800, 101000, 106300, 111800,
    117500, 123200, 129100, 135100, 141200, 147500, 153900, 160400, 167100, 173900, 180800, 187900, 195000,
    202300, 209800 }
C.XPNeed = function(l) return XPNEED[l] end      -- fuer die Testroutine (Tabelle unveraendert)
local WINDOW = 3600          -- EP der letzten Stunde
local samples = {}           -- { {zeit, gesamt-EP der Sitzung}, ... }
local sessionXP = 0
local lastLevel, lastXP, lastMax
local sessionStart

-- aktive Spielzeit (ohne AFK, siehe Session.lua); ohne Session-Modul die normale Uhr
local function Clock()
    if LP.Session and LP.Session.Clock then return LP.Session:Clock() end
    return GetTime()
end

local function Track()
    local level = LP:PlayerLevel() or 1
    local xp, max, readable = LP:PlayerXP()
    if not readable then return end          -- geschuetzt: diesen Stand auslassen (sonst falscher Zuwachs)
    local now = Clock()
    if lastLevel then
        local gained
        if level > lastLevel then
            gained = (lastMax - lastXP) + xp
        else
            gained = xp - lastXP
        end
        if gained > 0 then sessionXP = sessionXP + gained end
    end
    lastLevel, lastXP, lastMax = level, xp, max
    samples[#samples + 1] = { now, sessionXP }
    while #samples > 2 and samples[2][1] < now - WINDOW do table.remove(samples, 1) end
end

-- EP pro Stunde (nil, solange zu wenig gespielt wurde)
function C:XPPerHour()
    local now = Clock()
    local first = samples[1]
    if not first then return nil end
    local span = now - first[1]
    if span < 300 or sessionXP <= 0 then return nil end
    return (sessionXP - first[2]) / span * 3600
end

function C:TimeToLevel()
    local rate = self:XPPerHour()
    if not rate or rate <= 0 then return nil end
    local xp, mx = LP:PlayerXP()
    local need = mx - xp
    return need / rate * 3600
end

function C:TimeTo60()
    local rate = self:XPPerHour()
    local level = LP:PlayerLevel() or 1
    if not rate or rate <= 0 or level >= 60 then return nil end
    local xp, mx = LP:PlayerXP()
    local need = mx - xp
    for l = level + 1, 59 do need = need + (XPNEED[l] or 0) end
    return need / rate * 3600
end

local function Dur(secs)
    if not secs then return "?" end
    secs = math.floor(secs)
    if secs >= 3600 then return L("%d h %02d min", math.floor(secs / 3600), math.floor(secs / 60) % 60) end
    return L("%d min", math.max(1, math.floor(secs / 60)))
end
C.Dur = Dur

-- kurze Anzeige fuer den Kopf des Guide-Fensters
function C:TimerText()
    if not LP.db.showTimer then return nil end
    local rate = self:XPPerHour()
    if not rate then return nil end
    local k = rate >= 10000 and string.format("%.0fk", rate / 1000) or string.format("%.1fk", rate / 1000)
    local text = L("%s EP/h · Level in %s", k, Dur(self:TimeToLevel()))
    local gold = LP.Session and LP.Session:GoldPerHour()
    if gold and gold > 0 then text = text .. " · " .. LP.Session.Money(gold) .. "/h" end
    return text
end

function C:LevelTimesText()
    local lines = {}
    local t = LP.char.levelTimes or {}
    local lv = {}
    for l in pairs(t) do lv[#lv + 1] = l end
    table.sort(lv)
    for i = math.max(1, #lv - 9), #lv do
        local l = lv[i]
        local best = LP.Session and LP.Session:BestText(l)
        lines[#lines + 1] = L("Level %d » %d: %s", l, l + 1, Dur(t[l])) .. (best and ("  |cff9c9ea6(" .. best .. ")|r") or "")
    end
    return table.concat(lines, "\n")
end

------------------------------------------------------------------------
-- Wegpunkt & Finde naechsten
------------------------------------------------------------------------
local function Navigate(map, x, y, text, key)
    local i, n, w = LP.Geo:ToWorld(map, x, y)
    if not i then LP:Reply(L["Für diesen Ort ist keine Karte bekannt."]) return end
    LP.Planner.priority = { t = "GOTO", map = map, x = x, y = y, inst = i, n = n, w = w, text = text, key = key }
    LP.Planner:Replan()
    C.PlanNavi()
end
C.Navigate = Navigate

-- 3.12.58 NAV-2: Reiseplan nach Zeit fuer das Hinfuehr-Ziel (Planner.priority), in Portionen; das Ergebnis steht am
-- Ziel (navPlan, navText) und erscheint im Guide unter dem Schritt. Alle C.NAV_EVERY Sekunden neu (verbleibende Zeit).
C.NAV_EVERY = 10
function C.PlanNavi()
    local P = LP.Planner
    local t = P and P.priority
    if not (t and t.inst and P.TravelPlan) then return false end
    local i, n, w, map = LP.Geo:Player()
    if not i then return false end
    LP.Jobs.Start("navplan", "nav", function() return P:TravelPlan(i, n, w, map, t) end, function(ok, plan)
        if not ok or P.priority ~= t then return end
        t.navPlan, t.navText, t.navAt = plan, plan and P.PlanText(plan) or nil, GetTime()
        if LP.UI and LP.UI.Refresh then LP.UI:Refresh() end
    end, { graph = true })
    return true
end

function C:SetWaypoint(x, y)
    local _, _, _, map = LP.Geo:Player()
    map = map or (C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player"))
    if not map or not x or not y then LP:Reply(L["Wegpunkt: /lp way X Y (Koordinaten der aktuellen Karte)"]) return end
    Navigate(map, x, y, L("Wegpunkt %.1f, %.1f", x, y), string.format("WAY:%d:%.1f:%.1f", map, x, y))
    local d = LP.Geo:DistToMapPoint(map, x, y)
    LP:Reply(L("Wegpunkt gesetzt: %s %.1f, %.1f (%s)", LP.Geo:MapName(map), x, y, d and LP:FormatDist(d) or "?"))
end

-- englische Klassennamen wie in den Trainer-Titeln der Daten
local CLASS_EN = { WARRIOR = "Warrior", PALADIN = "Paladin", HUNTER = "Hunter", ROGUE = "Rogue", PRIEST = "Priest",
                   SHAMAN = "Shaman", MAGE = "Mage", WARLOCK = "Warlock", DRUID = "Druid" }

C.KINDS = {
    { key = "repair",  label = "Reparatur" },
    { key = "vendor",  label = "Händler" },
    { key = "trainer", label = "Klassentrainer" },
    { key = "inn",     label = "Gasthaus" },
    { key = "flight",  label = "Flugmeister" },
    { key = "bank",    label = "Bank" },
    { key = "auction", label = "Auktionshaus" },
    { key = "mailbox", label = "Briefkasten" },
}
local WORDS = {
    repair = { "repar", "repair" },   -- 3.12.54: englisch "repair" enthält "repar" nicht vendor = { "händ", "hand", "vendor", "verk" }, trainer = { "train", "lehr" },
    inn = { "gast", "inn", "binden" }, flight = { "flug", "flight", "fly" }, bank = { "bank" },
    auction = { "auk", "auc" }, mailbox = { "brief", "mail", "post" },
}

------------------------------------------------------------------------
-- 3.12.54 NAV-1a: ein Befehl für den Navigator. /lp navi X Y [Zone] (Koordinaten, auch in einer anderen Zone),
-- /lp navi <Dienst> (nächster Briefkasten, Gasthaus … – nach Wegkosten, LW-1), /lp navi aus (beenden).
-- Ziele laufen wie alle Hinführ-Ziele über Planner.priority (Pfeil, Weg, Flüge; oben im Guide).
------------------------------------------------------------------------
C.ZONE_MIN, C.ZONE_MAX = 1411, 1460          -- uiMap-Bereich der Classic-/Forever-Zonen (Kontinente 1414/1415 ausgenommen)
local function Norm(s) return (tostring(s or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")) end
-- Zone zu einem Namen (Name in der Sprache des Spiels oder der eingestellten Sprache; Anfang genügt, genauer Treffer zuerst)
function C.ZoneByName(name)
    local want = Norm(name)
    if want == "" then return nil end
    local prefix
    for map = C.ZONE_MIN, C.ZONE_MAX do
        if map ~= 1414 and map ~= 1415 then
            for _, nm in ipairs({ LP.Geo:MapName(map), LP.Names and LP.Names.Zone and LP.Names:Zone(map) }) do
                local n = Norm(nm)
                if n ~= "" and n ~= tostring(map) then
                    if n == want then return map end
                    if not prefix and n:sub(1, #want) == want then prefix = map end
                end
            end
        end
    end
    return prefix
end

C.NAVI_OFF = { aus = true, off = true, stop = true, stopp = true, ende = true, ["end"] = true }
function C:Navi(text)
    local t = Norm(text)
    if t == "" then LP:Reply(L["Navi: /lp navi X Y [Zone] · /lp navi briefkasten | gasthaus | flug | bank | auktion | händler | reparatur | trainer · /lp navi aus"]) return end
    if C.NAVI_OFF[t] then
        local p = LP.Planner.priority
        if p and p.key and (p.key:find("^WAY:") or p.key:find("^PRIO:")) then
            LP.Planner.priority = nil
            LP.Planner:Replan()
            LP:Reply(L["Navi beendet – weiter mit der Route."])
        else
            LP:Reply(L["Kein Navi-Ziel aktiv."])
        end
        return "aus"
    end
    local x, y, zone = t:match("^([%d%.]+)[%s,]+([%d%.]+)%s*(.*)$")
    x, y = tonumber(x), tonumber(y)
    if x and y then
        if x < 0 or x > 100 or y < 0 or y > 100 then LP:Reply(L["Navi: Koordinaten von 0 bis 100."]) return end
        if zone == "" then self:SetWaypoint(x, y) return "weg" end
        local map = C.ZoneByName(zone)
        if not map then LP:Reply(L("Navi: Zone „%s“ nicht gefunden.", zone)) return end
        Navigate(map, x, y, L("Wegpunkt %.1f, %.1f", x, y) .. " · " .. LP.Geo:MapName(map), string.format("WAY:%d:%.1f:%.1f", map, x, y))
        LP:Reply(L("Navi: %s %.1f, %.1f", LP.Geo:MapName(map), x, y))
        return "weg", map
    end
    return self:FindNearest(t)
end

function C:FindNearest(what)
    what = (what or ""):lower()
    local kind
    for k, words in pairs(WORDS) do
        for _, wd in ipairs(words) do if what:find(wd, 1, true) then kind = k end end
    end
    if not kind then
        LP:Reply(L["Finde nächsten: /lp find reparatur | händler | trainer | gasthaus | flug | bank | auktion | briefkasten"])
        return
    end
    self:Find(kind)
end

function C:Find(kind)
    local filter
    local label
    for _, k in ipairs(self.KINDS) do if k.key == kind then label = L[k.label] end end
    if kind == "trainer" then
        local _, cls = UnitClass("player")
        local want = CLASS_EN[cls] and (CLASS_EN[cls] .. " Trainer")
        filter = function(v) return v.sub and want and v.sub == want end
    end
    local v, d = LP.QuestDB:NearestService(kind, filter)
    if not v then
        LP:Reply(L("Kein %s auf diesem Kontinent bekannt.", label or kind))
        return
    end
    Navigate(v.map, v.x, v.y, (label or kind) .. ": " .. (kind == "mailbox" and L["Briefkasten"] or (v.name or "?")),
        "PRIO:" .. kind .. ":" .. v.map)
    LP:Reply(L("Am nächsten – %s: %s, %s (%s)", label or kind, kind == "mailbox" and L["Briefkasten"] or (v.name or "?"),
        LP.Geo:MapName(v.map), LP:FormatDist(d)))
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
function C:Init()
    if C_Timer and C_Timer.NewTicker then
        C_Timer.NewTicker(C.NAV_EVERY, function()
            local t = LP.Planner and LP.Planner.priority
            if t and t.navAt and not (LP.Act and LP.Act.dry) and not LP.Jobs.Running("navplan") then C.PlanNavi() end
        end)
    end
    LP:On("MERCHANT_SHOW", function()
        C.merchantOpen = true
        if Paused() then return end
        C:Repair()
        C:SellGrey()
    end)
    LP:On("MERCHANT_CLOSED", function() C.merchantOpen = false C.sellRun = nil end)
    LP:On("TAXIMAP_OPENED", function() C_Timer.After(0.2, function() C:AutoFly() end) end)

    sessionStart = GetTime()
    Track()
    LP:On("PLAYER_XP_UPDATE", function() Track() LP:Fire("TIMER_CHANGED") end)
    LP:On("PLAYER_LEVEL_UP", function(_, newLevel)
        -- Zeit fuer das abgeschlossene Level merken
        local old = (newLevel or LP:PlayerLevel() or 2) - 1
        local spent = (LP.char.levelAcc or 0) + (GetTime() - (C.levelStart or sessionStart))
        LP.char.levelTimes = LP.char.levelTimes or {}
        LP.char.levelTimes[old] = math.floor(spent)
        LP.char.levelAcc = 0
        C.levelStart = GetTime()
        C_Timer.After(0.2, Track)
    end)
    C.levelStart = GetTime()
    LP:On("PLAYER_LOGOUT", function()
        LP.char.levelAcc = (LP.char.levelAcc or 0) + (GetTime() - (C.levelStart or sessionStart))
    end)
end
