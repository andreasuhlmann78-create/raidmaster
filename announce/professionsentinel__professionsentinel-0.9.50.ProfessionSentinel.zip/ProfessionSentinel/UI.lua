local _, ns = ...
local L = ns.L

-- Panel docked to the profession window of the running game version:
--   WoW Forever: ProfessionsFrame (Blizzard_Professions, Retail-style)
--   Classic Era: TradeSkillFrame (Blizzard_TradeSkillUI) and CraftFrame (Blizzard_CraftUI, enchanting)
-- Two tabs:
--   Recipes  – every recipe of the open profession: learned ones greyed out, missing ones in rarity colour,
--              each with the lifeline (crafts until yellow / green / grey); right-click = waypoint to a vendor
--   Trainers – all trainers of the profession by rank (up to 150 / 225 / 300, specialisations) with zone,
--              coordinates and faction; click = waypoint

local UI = {}
ns.UI = UI

local PANEL_WIDTH = 420
local ROW_HEIGHT = 28

local panel, scrollBox, scrollBar, searchBox, summary, testBadge, infoText
-- portioned rebuild: hands the rest to the next frame when the frame budget is used (no-op outside of it)
local function Yield() if UI.Yield then UI.Yield() end end
local tabRecipes, tabTrainers, tabRanking, tabDisenchant, tabPlan, tabFavor, tabGoldList
local collapsed
local currentHost -- frame the panel is docked to (nil = free-floating test mode)

-- four tabs, one question each (UI rework 2, 15 Nov.): Now (F1: the next step), Skill up (F2: plan, ranking,
-- trainers), Gold (F3: crafting pays, enchanter), Recipes (F4: collection, Händlergunst). The views of a tab are a small
-- switch below the tabs; no view was dropped (mapping table in the report 0.9.47).
UI.MODE_GROUP = { now = "now", recipes = "recipes", favor = "recipes", plan = "skill", ranking = "skill", trainers = "skill",
    gold = "gold", disenchant = "gold" }
UI.GROUP_DEFAULT = { now = "now", recipes = "recipes", skill = "plan", gold = "gold" }
UI.TAB_ORDER = { "now", "skill", "gold", "recipes" }
UI.ACCENT = { 0.25, 0.78, 0.92 }
function UI.GroupOfMode(m) return UI.MODE_GROUP[m] or "recipes" end

local function Mode()
    local m = ns.db and ns.db.panelMode
    if m == "trainers" and ns.HasSourceData == false then return "recipes" end
    if m == "trainers" or m == "ranking" or m == "plan" or m == "gold" or m == "now" then return m end
    if m == "disenchant" and ns.Disenchant and ns.Disenchant.IsEnchanter() then return m end
    if m == "favor" and ns.Favor and ns.Favor.Active() then return m end      -- WoW Forever only
    if m == nil then return "now" end      -- start page (UI rework 2: tab "Jetzt", question F1)
    return "recipes"
end

---------------------------------------------------------------------------
-- Current profession and rank
---------------------------------------------------------------------------
-- Modern client (WoW Forever, Retail): skill of the open profession.
-- In WoW Forever the child info of the window can report 0 (or a stale value) while the real skill sits in the
-- base info or in GetProfessionInfo (0.9.14 in the game: cooking 110/150 read as 0). So every source of THIS
-- profession is read and the highest valid value (> 0) wins: skill only goes up. No valid value -> nil
-- ("skill unknown"), never a made-up 0.
local function ValidRank(v)
    return type(v) == "number" and v > 0 and v or nil
end

function UI.BestRank(prof, infos)
    local rank, maxRank
    local function take(r, m)
        r, m = ValidRank(r), ValidRank(m)
        if r and (not rank or r > rank) then rank = r end
        if m and (not maxRank or m > maxRank) then maxRank = m end
    end
    for _, info in ipairs(infos or {}) do
        if type(info) == "table" then take(info.skillLevel, info.maxSkillLevel) end
    end
    if prof and ns.API.TradeSkillGetProfessionInfoBySkillLineID then
        local ok, info = pcall(ns.API.TradeSkillGetProfessionInfoBySkillLineID, prof)
        if ok and type(info) == "table" then take(info.skillLevel, info.maxSkillLevel) end
    end
    if prof and ns.Scan then take(ns.Scan:Rank(prof)) end      -- GetProfessions / GetProfessionInfo / skill lines
    if rank and maxRank and maxRank < rank then maxRank = nil end
    return rank, maxRank
end

local function ForeverProfession()
    local A = ns.API
    if not (A.TradeSkillGetChildProfessionInfo or A.TradeSkillGetBaseProfessionInfo) then return nil end
    local prof
    local child, base
    if A.TradeSkillGetChildProfessionInfo then
        local ok, info = pcall(A.TradeSkillGetChildProfessionInfo)
        if ok and type(info) == "table" and info.professionID then
            child = info
            prof = ns.ResolveProf(info.professionID) or ns.ResolveProf(info.parentProfessionID)
        end
    end
    if A.TradeSkillGetBaseProfessionInfo then
        local ok, info = pcall(A.TradeSkillGetBaseProfessionInfo)
        if ok and type(info) == "table" and info.professionID then
            local bp = ns.ResolveProf(info.professionID)
            if not prof then prof = bp end
            if bp == prof then base = info end
        end
    end
    if not prof then return nil end
    local rank, maxRank = UI.BestRank(prof, { child, base })
    return prof, rank, maxRank
end
UI.ForeverProfession = ForeverProfession

local function EraProfession()
    if currentHost == CraftFrame and ns.API.GetCraftDisplaySkillLine then
        local name, rank, maxRank = ns.API.GetCraftDisplaySkillLine()
        return ns.MatchProfession(name), rank, maxRank
    end
    if ns.API.GetTradeSkillLine then
        local name, rank, maxRank = ns.API.GetTradeSkillLine()
        return ns.MatchProfession(name), rank, maxRank
    end
end

local function CurrentProfession()
    local prof, rank, maxRank
    if ns.Sim and ns.Sim.prof then
        prof = ns.Sim.prof
        rank, maxRank = ns.Scan:Rank(prof)
    elseif ns.UsesModernProfessions then
        prof, rank, maxRank = ForeverProfession()
    else
        prof, rank, maxRank = EraProfession()
    end
    if prof and not rank then
        local r, m = ns.Scan:Rank(prof)
        rank, maxRank = ValidRank(r), maxRank or ValidRank(m)
    end
    return prof, ns.EffectiveRank(rank), maxRank
end
UI.CurrentProfession = CurrentProfession

local function IsLearned(r)
    if ns.IsLearned(r) then return true end
    if ns.Sim and ns.Sim.known then return false end
    -- WoW Forever: ask the open profession window directly
    if ns.UsesModernProfessions and ns.API.TradeSkillGetRecipeInfo and not (ns.Sim and ns.Sim.prof) then
        local linked = ns.API.TradeSkillIsTradeSkillLinked and ns.API.TradeSkillIsTradeSkillLinked()
        if not linked then
            local info = ns.API.TradeSkillGetRecipeInfo(r.spell)
            if info and info.learned then
                local c = ns.Char(); if c then c.known[r.spell] = true end
                return true
            end
        end
    end
    return false
end

---------------------------------------------------------------------------
-- Colours and texts
---------------------------------------------------------------------------
local DIFF = { red = "ff4040", orange = "ff8040", yellow = "ffd23f", green = "40c040", grey = "808080", white = "ffffff" }

local function SkillLevelsText(r)
    local parts = {}
    if (r.req or 0) > 1 then parts[#parts + 1] = "|cff" .. DIFF.orange .. r.req .. "|r" end
    if (r.yellow or 0) > 0 then
        parts[#parts + 1] = "|cff" .. DIFF.yellow .. r.yellow .. "|r"
        parts[#parts + 1] = "|cff" .. DIFF.green .. r.green .. "|r"
        parts[#parts + 1] = "|cff" .. DIFF.grey .. r.grey .. "|r"
    end
    return table.concat(parts, "  ")
end

local function MoneyText(copper)
    if not copper or copper <= 0 then return "" end
    if GetCoinTextureString then return GetCoinTextureString(copper) end
    return string.format("%dg %ds %dc", copper / 10000, (copper / 100) % 100, copper % 100)
end

---------------------------------------------------------------------------
-- Sources (Trainer / Vendor / Drop ...) with zone and coordinates
---------------------------------------------------------------------------
local function NPCLine(id)
    local WP = ns.Waypoint
    local n = ns.NPCs[id]
    if not n then return "NPC " .. id, true end
    local name, sub, lvl = n[1], n[4], n[5]
    local s = name
    if sub then s = s .. " |cff9d9d9d<" .. sub .. ">|r" end
    local extra = {}
    if lvl then extra[#extra + 1] = L.LEVEL .. " " .. lvl end
    local where = WP.LocationText(id)
    if where then extra[#extra + 1] = where end
    if #extra > 0 then s = s .. " |cffb0b0b0(" .. table.concat(extra, ", ") .. ")|r" end
    return s, (n[3] == nil) or WP.IsFriendly(id)
end

function UI:AddSourceLines(tt, r)
    local S = ns.SRC
    if bit.band(r.src, S.TRAINER) ~= 0 then
        tt:AddLine((r.req or 0) > 1 and string.format(L.SRC_TRAINER_AT, r.req) or L.SRC_TRAINER, 1, 1, 1)
    end
    if bit.band(r.src, S.AUTO) ~= 0 then tt:AddLine(L.SRC_AUTO, 1, 1, 1) end
    for _, ri in ipairs(r.recipeItems) do
        local q = ns.ItemQuality(ri.id)
        local line = "|cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(ri.id) .. "|r"
        if ri.rs then line = line .. "  |cffb0b0b0(" .. L.REQ .. " " .. ri.rs .. ")|r" end
        tt:AddLine(line)
        local favor = ns.Favor and ri.fv ~= nil
        local rep = ns.RepLine(favor and ns.Favor.Faction(ri.fa) or ri.fa, ri.fr)
        -- supply-camp recipes: the reputation comes from guides (beta) until the game shows it
        if rep and favor then rep = rep .. " |cff9d9d9d" .. L.FAVOR_GUIDE .. "|r" end
        if rep then tt:AddLine("   " .. rep) end
        if ri.v then
            local sorted = {}
            for _, id in ipairs(ri.v) do
                local s, ok = NPCLine(id)
                if ok then table.insert(sorted, 1, { s, ok }) else sorted[#sorted + 1] = { s, ok } end
            end
            for i, e in ipairs(sorted) do
                if i <= 4 then
                    tt:AddLine("   " .. L.SRC_VENDOR .. ": " .. e[1] .. (e[2] and "" or " |cffff6060[" .. L.OTHER_FACTION .. "]|r"), 0.85, 0.85, 0.85)
                end
            end
            if #ri.v > 4 then tt:AddLine("   " .. string.format(L.MORE, #ri.v - 4), 0.6, 0.6, 0.6) end
            -- WoW Forever supply camps: paid with Merchant's Favor, not gold
            local favorText = ns.Favor and ns.Favor.CostText(ri)
            if favorText then
                tt:AddLine("   " .. favorText)
            elseif ri.bp then
                tt:AddLine("   " .. MoneyText(ri.bp), 1, 1, 1)
            end
        end
        if ri.d then
            if (ri.dn or 0) > 15 then
                tt:AddLine("   " .. string.format(L.SRC_WORLDDROP, ri.dn), 0.85, 0.85, 0.85)
            else
                for i, id in ipairs(ri.d) do
                    if i <= 4 then tt:AddLine("   " .. L.SRC_DROP .. ": " .. (NPCLine(id)), 0.85, 0.85, 0.85) end
                end
                if (ri.dn or #ri.d) > 4 then tt:AddLine("   " .. string.format(L.MORE, (ri.dn or #ri.d) - 4), 0.6, 0.6, 0.6) end
            end
        end
        if ri.qr then tt:AddLine("   " .. string.format(L.SRC_QUEST, ri.qr), 0.85, 0.85, 0.85) end
        if ri.o then tt:AddLine("   " .. string.format(L.SRC_CONTAINER, ri.o), 0.85, 0.85, 0.85) end
        if not (ri.v or ri.d or ri.qr or ri.o) then
            tt:AddLine("   " .. (ns.HasSourceData == false and L.SRC_RETAIL or L.SRC_UNKNOWN), 0.6, 0.6, 0.6)
        end
    end
end

local function LifelineTooltipLines(tt, r, rank)
    local LL = ns.Lifeline
    local c = rank and LL and LL.Calc(r, rank)
    if not c then return end
    tt:AddLine(" ")
    tt:AddLine(L.LL_TITLE, 1, 0.82, 0)
    local parts = {}
    local function add(key, n, exact)
        if n then parts[#parts + 1] = "|cff" .. LL.HEX[key] .. L["LL_" .. key:upper()] .. " " .. (exact and "" or "≈") .. math.floor(n + 0.5) .. "×|r" end
    end
    add("yellow", c.toYellow, true)
    add("green", c.toGreen, c.toYellow and c.toGreen and r.green <= r.yellow)
    add("grey", c.toGrey, false)
    if #parts > 0 then
        tt:AddLine(table.concat(parts, "   "))
    else
        tt:AddLine(c.textColored)
    end
    tt:AddLine(L.LL_TIP_EXACT, 0.6, 0.6, 0.6, true)
end

-- Tooltips of elements inside our windows go BESIDE the window, never over it (Spieltest S8 / T206: with
-- ANCHOR_RIGHT they covered the close button and other buttons of the panel). Right of the window (right of
-- AHSentinel's docked window, if it sits there); if there is no room on the right, left of the window.
-- Elements outside our windows (button on the profession window) keep ANCHOR_RIGHT.
UI.TIP_ROOM = 320          -- room a tooltip needs on the right side (UIParent units)

local function IsInside(f, win)
    local n = 0
    while f and n < 30 do
        if f == win then return true end
        f = f.GetParent and f:GetParent() or nil
        n = n + 1
    end
    return false
end

function UI.ScreenWidth() return UIParent and UIParent.GetWidth and UIParent:GetWidth() or nil end

-- puts an already owned tooltip beside the window (right, or left if there is no room on the right)
function UI.PlaceTooltip(tt, win)
    tt = tt or GameTooltip
    win = win or panel
    tt:ClearAllPoints()
    -- the outermost of our window and AHSentinel's docked window on each side
    local right, left = win, win
    local dock = UI.GetAHSDockFrame()      -- only counted if it sits right beside the window
    if dock and dock.GetLeft and win.GetRight then
        local dl, wr, dr, wl = dock:GetLeft(), win:GetRight(), dock:GetRight(), win:GetLeft()
        if dl and wr and dl >= wr - 2 then right = dock end
        if dr and wl and dr <= wl + 2 then left = dock end
    end
    local screenW = UI.ScreenWidth() or 0
    local r = right.GetRight and right:GetRight()
    local k = 1
    if right.GetEffectiveScale and UIParent and UIParent.GetEffectiveScale then
        local ui = UIParent:GetEffectiveScale()
        if ui and ui > 0 then k = (right:GetEffectiveScale() or ui) / ui end
    end
    if not r or screenW <= 0 or screenW - r * k >= UI.TIP_ROOM then
        tt:SetPoint("TOPLEFT", right, "TOPRIGHT", 4, 0)
        return "right"
    end
    tt:SetPoint("TOPRIGHT", left, "TOPLEFT", -4, 0)
    return "left"
end

function UI.TooltipBeside(owner, win, tt)
    tt = tt or GameTooltip
    win = win or panel
    if not (win and win.IsShown and win:IsShown() and IsInside(owner, win)) then
        tt:SetOwner(owner, "ANCHOR_RIGHT")
        return "owner"
    end
    tt:SetOwner(owner, "ANCHOR_NONE")
    return UI.PlaceTooltip(tt, win)
end

-- Blizzard templates (UICheckButtonTemplate, UIPanelButtonTemplate) may show their own tooltip with ANCHOR_RIGHT:
-- after their OnEnter (HookScript, nothing replaced) a tooltip owned by the element is moved beside the panel.
function UI.GuardTemplateTooltip(f)
    if not (f and f.HookScript) then return end
    f:HookScript("OnEnter", function(self)
        local tt = GameTooltip
        if tt and tt.IsShown and tt:IsShown() and tt.GetOwner and tt:GetOwner() == self then UI.PlaceTooltip(tt, panel) end
    end)
end

-- origin of a reagent made from others: "from Linen Cloth"
function UI.CraftOriginText(via)
    local names = {}
    for _, id in ipairs(via or {}) do names[#names + 1] = ns.ItemName(id) end
    return string.format(L.ORIGIN_FROM, #names > 0 and table.concat(names, ", ") or "?")
end

-- "Prices: AHSentinel" / "Prices: own", and – if AHSentinel measures it – the gold per hour when crafting
function UI.PriceLine()
    local PS = ns.PriceSource
    local line = PS.SourceText()
    local gph = PS.GoldPerHour("craft")
    if gph then line = line .. "  ·  " .. string.format(L.GPH_CRAFT, ns.Prices.MoneyPlain(gph)) end
    return line
end

-- Tooltip variant A (decision of the user 9 Nov. 17:55, like AHSentinel's tooltip): without Shift three blocks –
--   1 head: name, "place · status", colour dot + crafts to the next colour
--   2 verdict: worth crafting / not / unsure with the ONE profit per craft (the same function as the panel and the
--     gold ranking: Prices.Recipe(r, true).bestNet), then sell / disenchant (the better one first), vendor, skill up
--   3 materials: sum, one line per reagent with origin, price per craft and bag count
-- With Shift: the whole calculation, skill levels and chance, sources, guild, price source. No ranking places and no
-- explanation texts (they are in the panel).
function UI.ShiftDown() return IsShiftKeyDown and IsShiftKeyDown() and true or false end

-- the ONE profit per craft (nil = unsure: no prices or a price missing) and the calculation it comes from
function UI.Profit(r)
    local P = ns.Prices
    local pr = P.Recipe(r, true)
    if not (pr.known and r.out and P.SourceName()) then return nil, pr end
    -- stale, bought-out or thin data or more than 300 %: no number anywhere (Market.lua PM3)
    if pr.flag then return nil, pr end
    return pr.bestNet or pr.net, pr
end

local function Dot(hex) return "|cff" .. hex .. "●|r" end

function UI.TipHead(tt, r, rank, learned)
    local qr, qg, qb = ns.QualityRGB(r.quality)
    tt:AddLine(ns.RecipeName(r), qr, qg, qb)
    local key, label = UI.SlotGroup(r)
    local state = UI.RecipeState(r, rank, learned)
    local left = UI.GroupLabel(key, label) .. " · " .. L["TT_" .. state:upper()]
    tt:AddDoubleLine(left, UI.TipColour(r, rank), 0.75, 0.75, 0.75, 1, 1, 1)
end

-- skill colour as a dot + crafts to the next colour ("green ≈13×"), "grey", or "from 150"
function UI.TipColour(r, rank)
    local LL = ns.Lifeline
    local c = rank and LL and LL.Calc(r, rank)
    if not c then return "" end
    if c.state == "grey" then return Dot(LL.HEX.grey) .. " |cff9d9d9d" .. L.LL_GREY .. "|r" end
    if c.state == "red" then return "|cffff4040" .. string.format(L.TT_FROM, r.req or 0) .. "|r" end
    if c.target and c.crafts then
        return Dot(LL.HEX[c.target]) .. " |cff" .. LL.HEX[c.target] .. L["LL_" .. c.target:upper()] .. " "
            .. (c.exact and "" or "≈") .. c.crafts .. "×|r"
    end
    return ""
end

-- main material of a recipe for "material per point": the reagent with the largest amount
local function MainMaterial(r)
    local best, n = nil, 0
    for i = 1, #(r.reagents or {}), 2 do
        if (r.reagents[i + 1] or 0) > n then best, n = r.reagents[i], r.reagents[i + 1] end
    end
    return best
end

function UI.TipVerdict(tt, r, pr, rank)
    local P, AD = ns.Prices, ns.Advisor
    tt:AddLine(" ")
    if r.out then
        local profit = UI.Profit(r)
        local MK = ns.Market
        if profit == nil then
            local ft = pr and pr.flag and MK and MK.FlagText(pr.flag)
            tt:AddDoubleLine("|TInterface\\RaidFrame\\ReadyCheck-Waiting:0|t " .. (ft or L.TT_UNSURE), "?", 0.62, 0.62, 0.62, 0.62, 0.62, 0.62)
        elseif profit > 0 then
            tt:AddDoubleLine("|TInterface\\RaidFrame\\ReadyCheck-Ready:0|t " .. L.TT_WORTH, AD.NetColored(profit), 0.25, 0.75, 0.25)
        else
            tt:AddDoubleLine("|TInterface\\RaidFrame\\ReadyCheck-NotReady:0|t " .. L.TT_NOT_WORTH, AD.NetColored(profit), 1, 0.38, 0.38)
        end
        -- sell and disenchant, the better way first and in colour
        local ways = {}
        if pr.valueAHNet then ways[#ways + 1] = { L.TT_SELL, pr.valueAHNet, pr.bestVia ~= "de" } end
        if pr.deValue then ways[#ways + 1] = { L.TT_DE, pr.deValue, pr.bestVia == "de" } end
        table.sort(ways, function(x, y) if x[3] ~= y[3] then return x[3] end return x[2] > y[2] end)
        for _, w in ipairs(ways) do
            if w[3] and #ways > 1 then
                tt:AddDoubleLine(w[1], P.Money(w[2]), 1, 0.82, 0, 1, 1, 1)
            else
                tt:AddDoubleLine(w[1], P.Money(w[2]), 0.8, 0.8, 0.8, 0.8, 0.8, 0.8)
            end
        end
        if (pr.valueVendor or 0) > 0 then
            tt:AddDoubleLine(L.TT_VENDOR, P.Money(pr.valueVendor), 0.55, 0.55, 0.55, 0.55, 0.55, 0.55)
        end
        -- market knowledge (PM1/PM2/PM6): sell the reagents raw instead, per cooldown, unsure hit rate
        if MK and not pr.flag then
            if pr.direction == "raw" then tt:AddLine(MK.DirectionText(pr)) end
            if pr.cooldown then tt:AddLine(L.MK_PER_CD_LINE, 0.66, 0.61, 0.52) end
            if pr.highMargin then tt:AddLine(L.MK_HIGH, 1, 0.82, 0) end
            if pr.unsure then tt:AddLine(L.MK_UNSURE_LINE, 0.62, 0.62, 0.62) end
        end
    end
    -- skill up: material per point in the base material (grey: no points)
    if rank and AD then
        local pts = AD.ColourPoints(r, rank)
        if pts > 0 then
            local per = AD.BaseMats(r) / pts
            local mat = MainMaterial(r)
            tt:AddDoubleLine(L.TT_SKILL, string.format(L.TT_PER_POINT, AD.Num1(per), mat and ns.ItemName(mat) or "?"),
                0.8, 0.8, 0.8, 1, 1, 1)
        else
            tt:AddDoubleLine(L.TT_SKILL, L.LL_GREY, 0.55, 0.55, 0.55, 0.55, 0.55, 0.55)
        end
    end
end

function UI.TipMaterials(tt, r, pr)
    local P = ns.Prices
    tt:AddLine(" ")
    tt:AddLine(L.TT_MATERIALS .. ((pr and pr.cost > 0) and (" · " .. P.MoneyPlain(pr.cost) .. (pr.known and "" or " ?")) or ""),
        0.6, 0.6, 0.6)
    for idx = 1, #r.reagents, 2 do
        local id, need = r.reagents[idx], r.reagents[idx + 1]
        local have = ns.GetItemCount(id)
        local q = ns.ItemQuality(id)
        local part = pr and pr.parts[(idx + 1) / 2]
        local origin = ""
        if part then
            origin = part.origin == "craft" and UI.CraftOriginText(part.via) or part.origin == "vendor" and L.ORIGIN_VENDOR
                or L.ORIGIN_AH
        end
        local left = "|T" .. ns.GetItemIcon(id) .. ":0|t |cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(id) .. "|r"
            .. (need > 1 and (" ×" .. need) or "") .. (origin ~= "" and ("  |cff8a8a8a" .. origin .. "|r") or "")
        local col = have >= need and "1eff00" or "ff6060"
        local right = (part and part.known and (P.Money(part.unit * need) .. "  ") or "") .. "|cff" .. col .. have .. "/" .. need .. "|r"
        tt:AddDoubleLine(left, right)
    end
end

-- only with Shift: the whole calculation, skill levels and chance, sources, guild, price source
function UI.TipDetails(tt, r, rank, pr, deMode)
    local P = ns.Prices
    local levels = SkillLevelsText(r)
    tt:AddLine(" ")
    if levels ~= "" then tt:AddDoubleLine(L.SKILL_LEVELS, levels, 1, 0.82, 0) end
    local chance = rank and ns.Lifeline.Chance(r, rank) or 0
    if rank and chance > 0 then tt:AddDoubleLine(L.TT_CHANCE, math.floor(chance * 100 + 0.5) .. " %", 0.8, 0.8, 0.8, 1, 1, 1) end
    if pr then
        tt:AddLine(" ")
        tt:AddDoubleLine(L.COST, P.Money(pr.cost) .. (pr.known and "" or " |cffff6060(?)|r"), 0.66, 0.61, 0.52, 1, 1, 1)
        if pr.valueAH then
            tt:AddDoubleLine(L.SELL_AH, P.Money(pr.valueAH), 0.66, 0.61, 0.52, 1, 1, 1)
            tt:AddDoubleLine(L.AH_CUT, "−" .. P.Money(pr.ahCut), 0.66, 0.61, 0.52, 1, 0.38, 0.38)
            if pr.depositRisk then
                tt:AddDoubleLine(L.DEPOSIT_RISK, "−" .. P.Money(pr.depositRisk), 0.66, 0.61, 0.52, 1, 0.38, 0.38)
            end
            tt:AddDoubleLine(L.SELL_AH_NET, P.Money(pr.valueAHNet), 0.66, 0.61, 0.52, 1, 1, 1)
        end
        if pr.valueVendor then tt:AddDoubleLine(L.SELL_VENDOR, P.Money(pr.valueVendor), 0.66, 0.61, 0.52, 0.6, 0.6, 0.6) end
        if pr.deGross then
            -- disenchanting: expected materials, then the 5 % cut when selling them
            local label = L.DE_VALUE
            if (pr.deShared or 0) > 0 then label = string.format(L.DE_VALUE_SHARED, pr.deOwn or 0, pr.deShared)
            elseif (pr.deOwn or 0) > 0 then label = string.format(L.DE_VALUE_OWN, pr.deOwn) end
            tt:AddDoubleLine(label, P.Money(pr.deGross) .. (pr.deComplete == false and " |cffff6060+?|r" or ""), 0.66, 0.61, 0.52, 1, 1, 1)
            for _, y in ipairs(pr.deYield or {}) do
                if y[2] >= 0.005 then
                    tt:AddDoubleLine("   |T" .. ns.GetItemIcon(y[1]) .. ":0|t " .. ns.ItemName(y[1]),
                        string.format(L.DE_CHANCE, math.floor(y[2] * 100 + 0.5), ns.Advisor.Num1(y[3])), 0.66, 0.61, 0.52, 0.8, 0.8, 0.8)
                end
            end
            tt:AddDoubleLine(L.DE_CUT, "−" .. P.Money(pr.deCut), 0.66, 0.61, 0.52, 1, 0.38, 0.38)
            if pr.deSafety then
                tt:AddDoubleLine(L.DE_SAFETY, "−" .. P.Money(pr.deSafety), 0.66, 0.61, 0.52, 1, 0.38, 0.38)
            end
            tt:AddDoubleLine(L.DE_NETVALUE .. (pr.deEstimated and (" " .. L.DE_ESTIMATED) or ""), P.Money(pr.deValue), 0.66, 0.61, 0.52, 1, 1, 1)
        end
        -- selling enchants: your price
        local DEm = ns.Disenchant
        if r.ench and r.prof == DEm.ENCHANTING and DEm.WantsSell() then
            local sp = pr.known and DEm.SellPrice(pr.cost)
            if sp then
                tt:AddDoubleLine(string.format(L.VZ_SURCHARGE, ns.db.vzMarkup or 20), "+" .. P.Money(sp - pr.cost), 0.66, 0.61, 0.52, 0.25, 0.75, 0.25)
                tt:AddDoubleLine(L.VZ_PRICE, P.Money(sp), 1, 0.82, 0, 1, 1, 1)
                tt:AddDoubleLine(L.VZ_PRICE_OWNMATS, P.Money(sp - pr.cost), 0.66, 0.61, 0.52, 1, 1, 1)
                tt:AddLine(L.VZ_WHISPER_HINT, 0.25, 0.78, 0.92)
            else
                tt:AddLine(L.VZ_NO_PRICE, 1, 0.38, 0.38)
            end
        end
        if pr.known and r.out then
            tt:AddDoubleLine(L.NET_CRAFT, ns.Advisor.NetColored(pr.net), 1, 1, 1)
            -- the AH share (5 %) and the expected deposit loss are already taken off
            if pr.valueSource == "ah" and P.FeeApplies() and pr.ahCut then
                tt:AddDoubleLine(L.NET_FEE_PART, "−" .. P.Money(pr.ahCut), 0.66, 0.61, 0.52, 1, 0.38, 0.38)
            end
            if pr.deNet then tt:AddDoubleLine(L.NET_DE, ns.Advisor.NetColored(pr.deNet), 1, 1, 1) end
            if pr.deNet and P.FeeApplies() and pr.deCut then
                tt:AddDoubleLine(L.NET_FEE_PART, "−" .. P.Money(pr.deCut), 0.66, 0.61, 0.52, 1, 0.38, 0.38)
            end
            if pr.deNet and (pr.value > 0 or pr.deNet > 0) then
                local via = pr.bestVia == "de" and L.VIA_DE or pr.bestVia == "vendor" and L.VIA_VENDOR or L.VIA_AH
                tt:AddDoubleLine(L.BEST_USE, "|cffffd100" .. via .. "|r", 1, 0.82, 0)
            end
            local chance = ns.Lifeline.Chance(r, rank or 0)
            if rank and chance > 0 then
                tt:AddDoubleLine(L.NET_POINT, ns.Advisor.NetColored(pr.net / (chance * (r.skillUps or 1))), 1, 1, 1)
            end
        end
        -- what sells: at most what the market takes in ~2 days (AHSentinel's sales per day)
        if r.out then
            local cap = ns.PriceSource.SellCap(r.out)
            if cap == 0 then tt:AddLine(L.SELL_HARDLY, 1, 0.5, 0.25)
            elseif cap then tt:AddLine(string.format(L.SELL_CAP, cap), 0.66, 0.61, 0.52) end
        end
        tt:AddLine(UI.PriceLine(), 0.54, 0.5, 0.44)
    end
    -- sources
    tt:AddLine(" ")
    tt:AddLine(L.SOURCES, 1, 0.82, 0)
    UI:AddSourceLines(tt, r)
    local best, kind = ns.Waypoint.BestSourceNPC(r)
    if best then tt:AddLine(kind == "drop" and L.WP_RIGHTCLICK_DROP or L.WP_RIGHTCLICK, 0.25, 0.78, 0.92) end
    -- guild (GuildSentinel / RaidMaster data)
    local GU = ns.Guild
    local crafters = GU and GU.Crafters(r)
    if crafters then
        tt:AddLine(" ")
        if #crafters > 0 then
            tt:AddLine(L.GUILD_CRAFTERS .. ": " .. GU.CraftersText(crafters), 1, 0.82, 0, true)
        else
            tt:AddLine(L.GUILD_NOBODY, 1, 0.5, 0.25)
        end
    end
end

function UI:ShowRecipeTooltip(owner, r, rank, deMode)
    UI.lastTip = { owner = owner, r = r, rank = rank, deMode = deMode }
    local tt = GameTooltip
    UI.TooltipBeside(owner, nil, tt)
    local P = ns.Prices
    local pr = P and (r.out or #(r.reagents or {}) > 0) and P.Recipe(r, true) or nil
    UI.TipHead(tt, r, rank, IsLearned(r))
    if pr then UI.TipVerdict(tt, r, pr, rank) end
    if #(r.reagents or {}) > 0 then UI.TipMaterials(tt, r, pr) end
    if UI.ShiftDown() then
        UI.TipDetails(tt, r, rank, pr, deMode)
    else
        tt:AddLine(" ")
        tt:AddLine(L.TT_SHIFT_HINT, 0.5, 0.5, 0.5)
    end
    tt:Show()
end

local function ShowTrainerTooltip(owner, id, rankKey)
    local WP = ns.Waypoint
    local n = ns.NPCs[id]
    if not n then return end
    local tt = GameTooltip
    UI.TooltipBeside(owner, nil, tt)
    tt:AddLine(n[1], 1, 1, 1)
    if n[4] then tt:AddLine("<" .. n[4] .. ">", 0.7, 0.7, 0.7) end
    tt:AddLine(L["RANK_" .. rankKey] or L.RANK_0, 1, 0.82, 0)
    for _, rk in ipairs(WP.RANKS) do
        if rk.key == rankKey and rk.req then tt:AddLine(string.format(L.RANK_REQ, rk.req, rk.level), 0.8, 0.8, 0.8) end
    end
    local where = WP.LocationText(id)
    if where then tt:AddLine(where, 1, 1, 1) end
    if n[3] and not WP.IsFriendly(id) then tt:AddLine(L.OTHER_FACTION, 1, 0.4, 0.4) end
    if WP.Has(id) then tt:AddLine(L.WP_CLICK, 0.25, 0.78, 0.92) end
    tt:Show()
end

---------------------------------------------------------------------------
-- Selecting a learned recipe in the Blizzard window
---------------------------------------------------------------------------
-- Blizzard's recipe list of the modern profession window (own function, so the test routine can hand in a stand-in)
function UI.BlizzardRecipeList()
    return ProfessionsFrame and ProfessionsFrame.CraftingPage and ProfessionsFrame.CraftingPage.RecipeList
end

function UI.EraSearchBox() return TradeSkillFrameEditBox end

-- Selects line i of the old profession window (own function: the test routine never touches the real selection)
function UI.ApplyTradeSkillSelection(i)
    if TradeSkillFrame_SetSelection then TradeSkillFrame_SetSelection(i) end
    if TradeSkillFrame_Update then TradeSkillFrame_Update() end
end

-- Opens the recipe even if the profession window hides it (search text, collapsed category); says so if it fails.
local function FindTradeSkill(wanted)
    for i = 1, (ns.API.GetNumTradeSkills and ns.API.GetNumTradeSkills() or 0) do
        local name = ns.API.GetTradeSkillInfo(i)
        if name and wanted[name:lower()] then return i end
    end
end

-- Modern client: the recipe ID of the open window, found by ProfessionSentinel itself (no AHSentinel needed).
-- Our data keeps the Classic spell ID; the window lists its recipes under its own recipe IDs. When the window opens
-- (or its list changes) the IDs of GetAllRecipeIDs are read once into a table name / result item -> recipe ID.
-- A click then takes the window's own ID: by name (German or English), else by result item, else the recipe ID
-- the window reports for the spell ID. nil = not in this window. (0.9.19 in the game: the spell ID was used when
-- the window also knew it, and the window only jumped there much later.)
local recipeMap
function UI.InvalidateRecipeMap() recipeMap = nil end

-- the list keeps the data of the last drawn view (rows, entries with their calculations) until the next drawing;
-- the test routine lets go of it after its run (test data are no part of the memory measurement T145)
function UI.ReleaseList()
    if scrollBox and scrollBox.SetDataProvider and CreateTreeDataProvider then scrollBox:SetDataProvider(CreateTreeDataProvider()) end
end

-- Profession events. The recipe-ID table is read again only when the window opens or switches profession
-- (TRADE_SKILL_SHOW, TRADE_SKILL_DATA_SOURCE_CHANGED) or a recipe was learned (Scan: NEW_RECIPE_LEARNED) –
-- not on every TRADE_SKILL_LIST_UPDATE (those come many times per second). A profession switch is also caught
-- by the profession stored in the table (UI.RecipeMap).
local MAP_EVENTS = { TRADE_SKILL_SHOW = true, TRADE_SKILL_DATA_SOURCE_CHANGED = true }
local LIST_EVENTS = { TRADE_SKILL_LIST_UPDATE = true, TRADE_SKILL_UPDATE = true, CRAFT_UPDATE = true }
function UI.OnProfessionEvent(event)
    if MAP_EVENTS[event] then UI.InvalidateRecipeMap() end
    -- list events are handled by Scan (storm protection, full refresh only on real changes); here they only
    -- matter for a visible panel – and never right after our own scan
    if LIST_EVENTS[event] then
        if not UI.PanelVisible() then return end
        if ns.Scan and ns.Scan.Now and ns.Scan.InQuiet and ns.Scan.InQuiet() then return end
    end
    UI.RequestRefresh(event)
end

local function CurrentBaseProfession()
    if not ns.API.TradeSkillGetBaseProfessionInfo then return nil end
    local ok, i = pcall(ns.API.TradeSkillGetBaseProfessionInfo)
    return ok and type(i) == "table" and i.professionID or nil
end

local function RecipeInfo(id)
    local ok, i = pcall(ns.API.TradeSkillGetRecipeInfo, id)
    return ok and type(i) == "table" and i or nil
end

function UI.RecipeMap()
    local prof = CurrentBaseProfession()
    if recipeMap and recipeMap.prof == prof then return recipeMap end
    UI.recipeMapBuilds = (UI.recipeMapBuilds or 0) + 1
    local A = ns.API
    local m = { byName = {}, learnedName = {}, ids = {}, byOut = nil, prof = prof }
    if A.TradeSkillGetAllRecipeIDs and A.TradeSkillGetRecipeInfo then
        local ok, all = pcall(A.TradeSkillGetAllRecipeIDs)
        for _, id in ipairs(ok and type(all) == "table" and all or {}) do
            local i = RecipeInfo(id)
            if i and not i.isDummyRecipe and not i.isRecraft then
                m.ids[#m.ids + 1] = id
                if type(i.name) == "string" then
                    local k = i.name:lower()
                    -- prefer a learned entry if a name appears twice
                    if not m.byName[k] or (i.learned and not m.learnedName[k]) then
                        m.byName[k], m.learnedName[k] = id, i.learned and true or nil
                    end
                end
            end
        end
    end
    recipeMap = m
    return m
end

-- result item -> recipe ID, read only when a name does not match (one schematic per recipe, once)
local function ByOutput(m, itemID)
    if not itemID or not ns.API.TradeSkillGetRecipeSchematic then return nil end
    if not m.byOut then
        m.byOut = {}
        for _, id in ipairs(m.ids) do
            local ok, sc = pcall(ns.API.TradeSkillGetRecipeSchematic, id, false)
            if ok and type(sc) == "table" and sc.outputItemID and not m.byOut[sc.outputItemID] then m.byOut[sc.outputItemID] = id end
        end
    end
    return m.byOut[itemID]
end

function UI.ModernRecipeID(r)
    local A = ns.API
    if not (r and A.TradeSkillGetRecipeInfo) then return r and r.spell end
    local m = UI.RecipeMap()
    local id = (r.name and m.byName[r.name:lower()]) or (r.nameEN and m.byName[r.nameEN:lower()]) or ByOutput(m, r.out)
    if id then return id end
    local own = r.spell and RecipeInfo(r.spell)
    if own then return own.recipeID or r.spell end
    return nil
end

-- recipe shown in the window's schematic right now (read only)
function UI.ShownModernRecipe()
    local cp = ProfessionsFrame and ProfessionsFrame.CraftingPage
    local form = cp and cp.SchematicForm
    if form and form.GetRecipeInfo then
        local ok, i = pcall(form.GetRecipeInfo, form)
        if ok and type(i) == "table" then return i.recipeID end
    end
end

local function SelectRecipe(r)
    if ns.UsesModernProfessions then
        local id = UI.ModernRecipeID(r)
        if not (ns.API.TradeSkillOpenRecipe and id) then ns.Print(L.SELECT_FAIL); return false end
        -- a search text in the profession window can hide the recipe: clear it (Blizzard's own box, only its text)
        local list = UI.BlizzardRecipeList()
        local sb = list and list.SearchBox
        if sb and sb.GetText and sb.SetText and (sb:GetText() or "") ~= "" then sb:SetText("") end
        local t0 = debugprofilestop and debugprofilestop() or 0
        -- like AHSentinel: select through the window's own list first (jumps there in the same frame);
        -- C_TradeSkillUI.OpenRecipe only as fallback (in WoW Forever it jumps there much later)
        local ok, way = false, "OpenRecipe"
        local info = RecipeInfo(id)
        if list and list.SelectRecipe and info then
            ok = pcall(list.SelectRecipe, list, info, true)
            if ok then way = "Liste" end
        end
        if not ok then ok = pcall(ns.API.TradeSkillOpenRecipe, id) end
        -- check right away (same frame): does the window show it?
        local shown = UI.ShownModernRecipe()
        UI.lastClick = { spell = r.spell, recipeID = id, way = way, ok = ok and (shown == nil or shown == id),
            shown = shown, ms = (debugprofilestop and debugprofilestop() or 0) - t0 }
        if not ok then ns.Print(L.SELECT_FAIL) end
        return ok
    end
    local wanted = { [r.name:lower()] = true }
    if r.nameEN then wanted[r.nameEN:lower()] = true end
    if CraftFrame and currentHost == CraftFrame and ns.API.GetNumCrafts then
        for i = 1, ns.API.GetNumCrafts() do
            local name = ns.API.GetCraftInfo(i)
            if name and wanted[name:lower()] then
                if CraftFrame_SetSelection then CraftFrame_SetSelection(i) end
                if CraftFrame_Update then CraftFrame_Update() end
                return true
            end
        end
    elseif ns.API.GetNumTradeSkills then
        local i = FindTradeSkill(wanted)
        if not i then
            -- hidden by the search text or a collapsed category: clear the filter, open all categories, look again
            if ns.API.SetTradeSkillItemNameFilter then pcall(ns.API.SetTradeSkillItemNameFilter, "") end
            local eb = UI.EraSearchBox and UI.EraSearchBox()
            if eb and eb.GetText and eb.SetText and (eb:GetText() or "") ~= "" then eb:SetText("") end
            if ns.API.ExpandTradeSkillSubClass then pcall(ns.API.ExpandTradeSkillSubClass, 0) end
            i = FindTradeSkill(wanted)
        end
        if i then
            UI.ApplyTradeSkillSelection(i)
            return true
        end
    end
    ns.Print(L.SELECT_FAIL)
    return false
end

-- every click on a recipe: select it in the profession window, then write it to the diagnostic log (KLICK).
-- The modern way fills UI.lastClick itself; the old ways (list by name) get theirs here.
local function SelectInBlizzard(r)
    UI.lastClick = nil
    local t0 = ns.DiagClock and ns.DiagClock()
    local ok = SelectRecipe(r)
    if not UI.lastClick then
        local t1 = ns.DiagClock and ns.DiagClock()
        UI.lastClick = { spell = r and r.spell, way = ns.UsesModernProfessions and "OpenRecipe" or "Liste",
            ok = ok and true or false, ms = (t0 and t1) and (t1 - t0) or nil }
    end
    if ns.Diagnose then pcall(ns.Diagnose.Click, UI.lastClick, r) end
    if ns.Spieltest and ns.Spieltest.IsOn() then pcall(ns.Spieltest.OnClick, UI.lastClick) end
    return ok
end
UI.SelectInBlizzard = SelectInBlizzard

---------------------------------------------------------------------------
-- List rows
---------------------------------------------------------------------------
local function RowIcon(r)
    if r.out then return ns.GetItemIcon(r.out) end
    return ns.GetSpellIcon(r.spell)
end

local function InitHeader(button, node)
    local data = node:GetData()
    if not button.label then
        button:SetHeight(ROW_HEIGHT)
        button.bg = button:CreateTexture(nil, "BACKGROUND")
        button.bg:SetAllPoints()
        button.bg:SetColorTexture(1, 1, 1, 0.06)
        button.arrow = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        button.arrow:SetPoint("LEFT", 4, 0)
        button.label = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        button.label:SetPoint("LEFT", 20, 0)
        button.label:SetPoint("RIGHT", -60, 0)
        button.label:SetJustifyH("LEFT")
        button.label:SetWordWrap(false)
        button.count = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        button.count:SetPoint("RIGHT", -6, 0)
        button:SetHighlightTexture("Interface\\Buttons\\UI-Listbox-Highlight2", "ADD")
        button:GetHighlightTexture():SetAlpha(0.2)
    end
    button.label:SetText(data.name)
    button.count:SetText(data.countText or (data.known .. "/" .. data.total))
    button.arrow:SetText(node:IsCollapsed() and "+" or "-")
    button:SetScript("OnClick", function()
        node:ToggleCollapsed()
        local key = data.key or data.name
        if key == "guild-nobody" then
            collapsed[key] = node:IsCollapsed() and true or false   -- collapsed by default: remember "open" as false
        else
            collapsed[key] = node:IsCollapsed() or nil
        end
        button.arrow:SetText(node:IsCollapsed() and "+" or "-")
    end)
    button:SetScript("OnEnter", data.tip and function(self)
        UI.TooltipBeside(self)
        GameTooltip:AddLine(data.name, 1, 0.82, 0)
        GameTooltip:AddLine(data.tip, 1, 1, 1, true)
        GameTooltip:Show()
    end or nil)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

-- Both recipe and trainer rows use the same pooled Button: create every widget once,
-- and each initializer sets (or hides) all of them.
local function EnsureRow(button)
    if button.name then return end
    button:SetHeight(ROW_HEIGHT)
    button.check = button:CreateTexture(nil, "OVERLAY")
    button.check:SetSize(14, 14)
    button.check:SetPoint("TOPLEFT", 4, -3)
    button.check:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready")
    button.icon = button:CreateTexture(nil, "ARTWORK")
    button.icon:SetSize(16, 16)
    button.icon:SetPoint("TOPLEFT", 22, -2)
    button.name = button:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    button.name:SetPoint("LEFT", button.icon, "RIGHT", 6, 0)
    button.name:SetPoint("RIGHT", button, "RIGHT", -70, 0)
    button.name:SetJustifyH("LEFT")
    button.name:SetWordWrap(false)
    button.new = button:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    button.new:SetPoint("TOPRIGHT", -38, -4)
    button.new:SetTextColor(0.25, 0.78, 0.92)
    button.skill = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    button.skill:SetPoint("TOPRIGHT", -6, -4)
    button.skill:SetJustifyH("RIGHT")
    button.line = ns.Lifeline.Create(button, 2)
    button.line:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 44, 5)
    button.line:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -112, 5)
    button.hint = button:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
    button.hint:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -6, 2)
    button.hint:SetWidth(104)
    button.hint:SetJustifyH("RIGHT")
    button.hint:SetWordWrap(false)
    button.where = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    button.where:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 44, 3)
    button.where:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -6, 3)
    button.where:SetJustifyH("LEFT")
    button.where:SetWordWrap(false)
    button:SetHighlightTexture("Interface\\Buttons\\UI-Listbox-Highlight2", "ADD")
    button:GetHighlightTexture():SetAlpha(0.25)
    -- left click on press: a rebuild between press and release can no longer swallow it
    button:RegisterForClicks(unpack(UI.ROW_CLICKS))
    -- shopping list, vendor goods: amount field + "Buy" (only shown on those rows with a vendor open)
    button.qty = CreateFrame("EditBox", nil, button, "InputBoxTemplate")
    button.qty:SetSize(34, 16)
    button.qty:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -62, 1)
    button.qty:SetAutoFocus(false)
    button.qty:SetNumeric(true)
    button.qty:SetMaxLetters(4)
    button.qty:SetJustifyH("RIGHT")
    button.qty:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    button.qty:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    button.qty:Hide()
    button.buy = CreateFrame("Button", nil, button, "UIPanelButtonTemplate")
    button.buy:SetSize(56, 18)
    button.buy:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -2, 0)
    button.buy:SetText(L.PLAN_BUY_BTN)
    button.buy:Hide()
end

-- amount per reagent the player typed (until the plan changes); default = what is missing
UI.buyQty = {}

-- the anchor of the detail line only changes when the amount field appears or goes (rows are reused a lot)
local function HideBuy(button)
    if not button.buyShown then return end
    button.buyShown = false
    button.qty:Hide(); button.buy:Hide()
    button.where:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -6, 3)
end

local function ShowBuy(button, data)
    local id = data.buyItem
    if not button.buyShown then
        button.buyShown = true
        button.where:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -104, 3)
        button.qty:Show()
        button.buy:Show()
    end
    local n = UI.buyQty[id] or data.buyDefault or 1
    button.qty:SetScript("OnTextChanged", nil)
    button.qty:SetText(tostring(n))
    button.qty:SetScript("OnTextChanged", function(self, user)
        if user then UI.buyQty[id] = tonumber(self:GetText()) end
    end)
    button.buy:SetScript("OnClick", function()
        button.qty:ClearFocus()
        local want = tonumber(button.qty:GetText()) or 0
        if ns.Plan and ns.Plan.BuyAmount then ns.Plan.BuyAmount(id, want) end
        UI.buyQty[id] = nil
    end)
    button.buy:SetScript("OnEnter", function(self)
        local want = tonumber(button.qty:GetText()) or 0
        local q = ns.Plan and ns.Plan.Quote and ns.Plan.Quote(id, want)
        UI.TooltipBeside(self)
        GameTooltip:AddLine(L.PLAN_BUY_BTN, 1, 0.82, 0)
        if q then
            GameTooltip:AddDoubleLine(string.format(L.PLAN_BUY_TIP_AMOUNT, q.bought), ns.Prices.Money(q.spent), 1, 1, 1, 1, 1, 1)
            if q.rounded then GameTooltip:AddLine(L.PLAN_BUY_TIP_ROUNDED, 0.25, 0.78, 0.92, true) end
            if #q.calls > 1 then GameTooltip:AddLine(string.format(L.PLAN_BUY_TIP_CALLS, #q.calls), 0.7, 0.7, 0.7, true) end
        else
            GameTooltip:AddLine(L.PLAN_VENDOR_NOT_SOLD, 1, 0.38, 0.38, true)
        end
        GameTooltip:Show()
    end)
    button.buy:SetScript("OnLeave", function() GameTooltip:Hide() end)
end
UI.ShowBuy, UI.HideBuy = ShowBuy, HideBuy

local function InitRecipeRow(button, data)
    local r = data.recipe
    local learned = data.learned
    button.where:Hide()
    button.icon:Show()
    button.icon:SetTexture(RowIcon(r))
    button.icon:SetDesaturated(learned)
    button.icon:SetAlpha(learned and 0.5 or 1)
    button.check:SetShown(learned)
    local qr, qg, qb = ns.QualityRGB(r.quality)
    -- 3.3 (UI rework 2): name only – no place number, no star (the star stays at ONE place: the Blizzard list)
    button.name:SetText(ns.RecipeName(r))
    if learned and not data.suggest then
        -- leicht ausgegraut: rarity colour mixed with grey and dimmed
        button.name:SetTextColor(qr * 0.4 + 0.3, qg * 0.4 + 0.3, qb * 0.4 + 0.3)
        button.name:SetAlpha(0.6)
    else
        button.name:SetTextColor(qr, qg, qb)
        button.name:SetAlpha(1)
    end
    if data.suggest and not learned then
        button.new:SetText("|cff3fc7eb" .. L.TAG_LEARN .. "|r")
    else
        button.new:SetText(r.isNew and L.NEW_TAG or "")
    end
    local lvl = (r.req or 0) > 1 and r.req or (r.yellow or 0)
    local calc = ns.Lifeline.Calc(r, data.rank)
    local stateHex = calc and ns.Lifeline.HEX[calc.state] or "ffffff"
    button.skill:SetText(lvl > 0 and ("|cff" .. stateHex .. lvl .. "|r") or "")
    button.skill:SetAlpha(learned and 0.6 or 1)
    if data.suggest then
        -- 3.3: colour dot, name, ONE number on the right for the tab (Skill up: "6×", Gold: "+20s"); the lifeline bar
        -- only in the tab Skill up; origin of the materials in the tooltip
        if UI.GroupOfMode(Mode()) == "skill" then ns.Lifeline.Update(button.line, r, data.rank, false) else button.line:Hide() end
        button.skill:SetText("|cff" .. stateHex .. "●|r")
        local e = data.entry
        if e then
            if data.planStep then
                button.hint:SetText("|cffffd100" .. data.planStep.crafts .. "×|r")
            elseif data.sell then
                local pr = e.price
                local sp = pr and pr.known and ns.Disenchant.SellPrice(pr.cost)
                button.hint:SetText(sp and ("|cff40c040" .. L.VZ_PRICE_SHORT .. " " .. ns.Prices.MoneyPlain(sp) .. "|r")
                    or ("|cffffd100" .. L.MAT_COST .. " " .. (pr and pr.cost > 0 and ns.Prices.MoneyPlain(pr.cost) or "?") .. "?|r"))
            elseif data.de then
                button.hint:SetText(ns.Advisor.NetColored(e.deNet))
            elseif data.matLevel then
                -- tab "Skill up" (U3): the ONE number is the material per skill point (base material, no gold)
                button.hint:SetText(e.matValue and ("|cffffffff" .. string.format(L.ROW_PER_POINT, ns.Advisor.Num1(e.matValue)) .. "|r") or "")
            elseif data.gold then
                local pr, MK = e.price, ns.Market
                local flagText = pr and pr.flag and MK and MK.FlagText(pr.flag)
                if flagText then
                    -- stale, bought-out, thin or > 300 %: no number (PM3)
                    button.hint:SetText("|cff9d9d9d" .. flagText .. "|r")
                elseif data.raw and MK then
                    -- loss with the reagents in the bags: sell them raw (PM1)
                    button.hint:SetText(MK.DirectionText(pr))
                else
                    -- best way like AHSentinel ("sell" / "DE") and the cap of what sells in ~2 days
                    local way = e.via == "de" and L.WAY_DE or L.WAY_SELL
                    -- what sells in ~2 days is in the tooltip (3.3: one number per row); "hardly sells" stays as a word
                    local cap = e.sellCap == 0 and (" |cffff8040" .. L.WAY_HARDLY .. "|r") or ""
                    if pr and pr.cooldown then cap = " |cffa89c84" .. L.MK_PER_CD .. "|r" end
                    -- under the minimum profit: grey (no recommendation)
                    local net = e.belowMin and ("|cff9d9d9d" .. ns.Prices.MoneyPlain(e.net, true) .. "|r") or ns.Advisor.NetColored(e.net)
                    local unsure = (pr and pr.unsure) and (" |cff9d9d9d" .. L.MK_UNSURE .. "|r") or ""
                    -- over 300 % without a second sign: the number with a yellow hint (answer F1)
                    local high = (pr and pr.highMargin) and (" |cffffd100" .. L.MK_HIGH_SHORT .. "|r") or ""
                    button.hint:SetText(net .. " |cffa89c84" .. way .. "|r" .. cap .. unsure .. high)
                end
            else
                button.hint:SetText(ns.Advisor.ValueColored(e))
            end
        else
            button.hint:SetText("|cffffd100" .. (data.reason or "") .. "|r")
        end
        button.hint:SetAlpha(1)
        button.hint:Show()
        button.skill:SetAlpha(1)
        button.icon:SetDesaturated(false)
        button.icon:SetAlpha(1)
    else
        -- tab "Recipes" (3.3, UI rework 2): name, ONE status word (learnable / missing / new), the source as a small
        -- symbol and ONE number on the right: the skill level in the colour of your skill. The profit is in the tab Gold,
        -- in the details and the tooltip (the same function UI.Profit).
        button.line:Hide()
        button.skill:SetText(lvl > 0 and ("|cff" .. stateHex .. lvl .. "|r") or "")
        local state = UI.RecipeState(r, data.rank, learned)
        if state == "learnable" then button.new:SetText("|cff1eff00" .. L.TT_LEARNABLE .. "|r")
        elseif state == "missing" then button.new:SetText("|cffff6060" .. L.TT_MISSING .. "|r") end
        button.hint:SetText(UI.SourceIcons(r))
        button.hint:SetAlpha(learned and 0.7 or 1)
        button.hint:Show()
    end
    button:SetScript("OnEnter", function(self)
        UI:ShowRecipeTooltip(self, r, data.rank, data.de)
        -- plan step: the range "from -> to" (the row shows only "6×", 3.3)
        if data.planStep and GameTooltip and GameTooltip.AddLine then
            GameTooltip:AddLine(string.format(L.PLAN_STEP_RANGE, data.planStep.from, data.planStep.to), 1, 0.82, 0)
            GameTooltip:Show()
        end
    end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    button:SetScript("OnClick", function(_, mouse)
        if mouse == "RightButton" and data.sell then
            ns.Disenchant.WhisperOffer(r)
            return
        end
        if mouse == "RightButton" then
            local id = ns.Waypoint.BestSourceNPC(r)
            if id then ns.Waypoint.Set(id, ns.NPCs[id][1] .. " – " .. ns.RecipeName(r)) end
            return
        end
        if IsModifiedClick and IsModifiedClick("CHATLINK") then
            local link = r.recipeItems[1] and ns.GetItemLink(r.recipeItems[1].id) or (r.out and ns.GetItemLink(r.out))
            if link and ChatEdit_InsertLink then ChatEdit_InsertLink(link) end
            return
        end
        -- the details belong to the tab "Recipes" only (review 0.9.38, point 3)
        if UI.ShowDetails and UI.GroupOfMode(Mode()) == "recipes" then UI.ShowDetails(r) end
        if learned and not (ns.Sim and ns.Sim.prof) then SelectInBlizzard(r) end
    end)
end

local function InitTrainerRow(button, data)
    local WP = ns.Waypoint
    local id = data.npc
    local n = ns.NPCs[id]
    local friendly = (n and n[3] == nil) or WP.IsFriendly(id)
    button.check:Hide()
    button.line:Hide()
    button.hint:Hide()
    button.icon:Show()
    local fac = n and n[3]
    if fac == "H" then button.icon:SetTexture("Interface\\TargetingFrame\\UI-PVP-Horde")
    elseif fac == "A" then button.icon:SetTexture("Interface\\TargetingFrame\\UI-PVP-Alliance")
    else button.icon:SetTexture("Interface\\Minimap\\Tracking\\Profession") end
    button.icon:SetDesaturated(false)
    button.icon:SetAlpha(friendly and 1 or 0.4)
    button.name:SetText((n and n[1] or ("NPC " .. id)) .. (n and n[4] and (" |cff9d9d9d<" .. n[4] .. ">|r") or ""))
    button.name:SetTextColor(1, 1, 1)
    button.name:SetAlpha(friendly and 1 or 0.45)
    button.new:SetText("")
    button.skill:SetText(n and n[5] and ("|cffb0b0b0" .. L.LEVEL .. " " .. n[5] .. "|r") or "")
    button.skill:SetAlpha(friendly and 1 or 0.45)
    local where = WP.LocationText(id) or ""
    if data.dist then where = string.format(L.TRAINER_YARDS, math.floor(data.dist / 10 + 0.5) * 10, where) end
    if not friendly and fac then where = where .. "  |cffff6060[" .. L.OTHER_FACTION .. "]|r" end
    button.where:SetText("|cffd0c0a0" .. where .. "|r")
    button.where:SetAlpha(friendly and 1 or 0.6)
    button.where:Show()
    button:SetScript("OnEnter", function(self) ShowTrainerTooltip(self, id, data.rankKey) end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    button:SetScript("OnClick", function() WP.Set(id, n and n[1]) end)
end

-- Simple info rows (disenchant tab): icon, name, value top right, detail line below, tooltip
local function InitInfoRow(button, data)
    button.check:Hide()
    button.line:Hide()
    button.hint:Hide()
    button.icon:SetShown(data.icon ~= nil)
    if data.icon then button.icon:SetTexture(data.icon) end
    button.icon:SetDesaturated(false)
    button.icon:SetAlpha(1)
    button.name:SetText(data.text or "")
    button.name:SetTextColor(1, 1, 1)
    button.name:SetAlpha(1)
    button.new:SetText("")
    button.skill:SetText(data.value or "")
    button.skill:SetAlpha(1)
    button.where:SetText(data.detail or "")
    button.where:SetAlpha(1)
    button.where:Show()
    if data.buyItem then ShowBuy(button, data) end
    button:SetScript("OnEnter", function(self)
        UI.TooltipBeside(self)
        if data.itemID then GameTooltip:SetItemByID(data.itemID) end
        for _, l in ipairs(data.tip or {}) do
            if type(l) == "table" then GameTooltip:AddDoubleLine(l[1], l[2], 0.8, 0.8, 0.8, 1, 1, 1)
            else GameTooltip:AddLine(l, 1, 1, 1, true) end
        end
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    button:SetScript("OnClick", function()
        if data.onClick then data.onClick(); return end
        if data.itemID and IsModifiedClick and IsModifiedClick("CHATLINK") then
            local link = ns.GetItemLink(data.itemID)
            if link and ChatEdit_InsertLink then ChatEdit_InsertLink(link) end
        end
    end)
end

local function InitRow(button, node)
    EnsureRow(button)
    button.psNode = node            -- UI.UpdateVisibleRows draws the row again from it
    local data = node:GetData()
    HideBuy(button)
    if data.npc then InitTrainerRow(button, data)
    elseif data.info then InitInfoRow(button, data)
    else InitRecipeRow(button, data) end
end

local function MatchesSearch(r, text)
    if text == "" then return true end
    if r.searchText:find(text, 1, true) then return true end
    if r.out and ns.ItemName(r.out):lower():find(text, 1, true) then return true end
    for i = 1, #r.reagents, 2 do
        if ns.ItemName(r.reagents[i]):lower():find(text, 1, true) then return true end
    end
    return false
end

---------------------------------------------------------------------------
-- Refresh
---------------------------------------------------------------------------
local ROW2_Y = -54
local function PlaceRow(list, width)
    for i, t in ipairs(list) do
        t:SetWidth(width)
        t:ClearAllPoints()
        if i == 1 then t:SetPoint("TOPLEFT", panel, "TOPLEFT", 12, ROW2_Y) else t:SetPoint("LEFT", list[i - 1], "RIGHT", 2, 0) end
        t:Show()
    end
end

-- flat button in the style of AHSentinel (UI rework 2: no grey Blizzard buttons): text, a light highlight on mouse-over,
-- an accent line below when selected
function UI.FlatButton(parent, w, h, small)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(w, h)
    local fs = b:CreateFontString(nil, "OVERLAY", small and "GameFontHighlightSmall" or "GameFontHighlight")
    fs:SetPoint("CENTER", b, "CENTER", 0, 1)
    if b.SetFontString then b:SetFontString(fs) end
    b.fs = fs
    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.08)
    b.bar = b:CreateTexture(nil, "ARTWORK")
    b.bar:SetColorTexture(UI.ACCENT[1], UI.ACCENT[2], UI.ACCENT[3], 1)
    b.bar:SetHeight(small and 1 or 2)
    b.bar:SetPoint("BOTTOMLEFT", b, "BOTTOMLEFT", 4, 0)
    b.bar:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -4, 0)
    b.bar:Hide()
    return b
end
function UI.SetSelected(b, on)
    b.selected = on and true or false
    if b.bar then b.bar:SetShown(on and true or false) end
    if b.fs and b.fs.SetTextColor then
        if on then b.fs:SetTextColor(UI.ACCENT[1], UI.ACCENT[2], UI.ACCENT[3]) else b.fs:SetTextColor(0.75, 0.75, 0.75) end
    end
end

---------------------------------------------------------------------------
-- Details of the tab "Recipes" (UI rework U2): a click on a row shows below the list what the big tooltip used to
-- show – materials with origin, net sale, profit, best way, sales, source of the recipe, buttons "Craft" and
-- "Shopping list". The numbers come from the same functions as tooltip and gold ranking (UI.Profit).
---------------------------------------------------------------------------
UI.DETAILS_HEIGHT = 150
local details

-- the source as small symbols (tab Recipes): trainer, vendor, Händlergunst, drop, quest
UI.SOURCE_ICON = {
    trainer = "Interface\\GossipFrame\\TrainerGossipIcon", vendor = "Interface\\GossipFrame\\VendorGossipIcon",
    favor = "Interface\\Icons\\INV_Misc_Coin_02", drop = "Interface\\Icons\\INV_Misc_Bag_10",
    quest = "Interface\\GossipFrame\\AvailableQuestIcon",
}
function UI.SourceKinds(r)
    local S, out = ns.SRC, {}
    if not S then return out end
    if bit.band(r.src or 0, S.TRAINER) ~= 0 then out[#out + 1] = "trainer" end
    if bit.band(r.src or 0, S.VENDOR) ~= 0 then out[#out + 1] = "vendor" end
    for _, ri in ipairs(r.recipeItems or {}) do
        if ri.fv ~= nil then out[#out + 1] = "favor"; break end
    end
    if bit.band(r.src or 0, S.DROP + S.WORLDDROP) ~= 0 then out[#out + 1] = "drop" end
    if bit.band(r.src or 0, S.QUEST) ~= 0 then out[#out + 1] = "quest" end
    return out
end
function UI.SourceIcons(r)
    local parts = {}
    for i, k in ipairs(UI.SourceKinds(r)) do
        if i > 3 then break end
        parts[#parts + 1] = "|T" .. UI.SOURCE_ICON[k] .. ":12:12|t"
    end
    return table.concat(parts, "")
end

function UI.SourceShort(r)
    local S, parts = ns.SRC, {}
    if bit.band(r.src or 0, S.TRAINER) ~= 0 then
        parts[#parts + 1] = (r.req or 0) > 1 and string.format(L.SRC_TRAINER_AT, r.req) or L.SRC_TRAINER
    end
    if bit.band(r.src or 0, S.VENDOR) ~= 0 then parts[#parts + 1] = L.SRC_VENDOR end
    for _, ri in ipairs(r.recipeItems or {}) do
        if ri.fv ~= nil then parts[#parts + 1] = L.FAVOR_TAB; break end
    end
    if bit.band(r.src or 0, S.DROP + S.WORLDDROP) ~= 0 then parts[#parts + 1] = L.SRC_DROP end
    if bit.band(r.src or 0, S.QUEST) ~= 0 then parts[#parts + 1] = (string.format(L.SRC_QUEST, 1):gsub("%s*%(.*%)", "")) end
    if bit.band(r.src or 0, S.AUTO) ~= 0 then parts[#parts + 1] = L.SRC_AUTO end
    return table.concat(parts, ", ")
end

-- the lines of the details (pure: also for the test routine); returns title, lines, profit
function UI.DetailLines(r, rank)
    local P, PS = ns.Prices, ns.PriceSource
    local profit, pr = UI.Profit(r)
    local lines = {}
    -- materials with origin
    for idx = 1, #(r.reagents or {}), 2 do
        local id, need = r.reagents[idx], r.reagents[idx + 1]
        local part = pr and pr.parts[(idx + 1) / 2]
        local origin = part and (part.origin == "craft" and UI.CraftOriginText(part.via) or part.origin == "vendor" and L.ORIGIN_VENDOR or L.ORIGIN_AH) or ""
        local have = ns.GetItemCount(id)
        lines[#lines + 1] = string.format("%d× %s |cff8a8a8a%s|r  %s  |cff%s%d/%d|r", need, ns.ItemName(id), origin,
            (part and part.known) and P.MoneyPlain(part.unit * need) or "?", have >= need and "1eff00" or "ff6060", have, need)
    end
    if r.out and pr then
        if pr.valueAHNet then lines[#lines + 1] = L.TT_SELL .. ": " .. P.MoneyPlain(pr.valueAHNet) end
        if pr.deValue then lines[#lines + 1] = L.TT_DE .. ": " .. P.MoneyPlain(pr.deValue) end
        local MK = ns.Market
        if profit then
            lines[#lines + 1] = L.DT_PROFIT .. ": " .. ns.Advisor.NetColored(profit) .. "  |cffa89c84"
                .. (pr.bestVia == "de" and L.WAY_DE or L.WAY_SELL) .. "|r"
                .. (pr.cooldown and ("  |cffa89c84" .. L.MK_PER_CD .. "|r") or "")
                .. (pr.unsure and ("  |cff9d9d9d" .. L.MK_UNSURE .. "|r") or "")
            if pr.highMargin then lines[#lines + 1] = "|cffffd100" .. L.MK_HIGH .. "|r" end
        else
            local ft = pr.flag and MK and MK.FlagText(pr.flag)
            lines[#lines + 1] = L.DT_PROFIT .. ": |cff9d9d9d" .. (ft or L.TT_UNSURE) .. "|r"
        end
        -- both directions (PM1): crafting against selling the reagents raw
        if MK and not pr.flag and pr.direction then lines[#lines + 1] = MK.DirectionText(pr) end
        local cap = PS.SellCap(r.out)
        if cap == 0 then lines[#lines + 1] = "|cffff8040" .. L.SELL_HARDLY .. "|r"
        elseif cap then lines[#lines + 1] = string.format(L.SELL_CAP, cap) end
    end
    local src = UI.SourceShort(r)
    if src ~= "" then lines[#lines + 1] = L.DT_SOURCE .. ": " .. src end
    return ns.RecipeName(r), lines, profit
end

-- buy what is missing for one craft: vendor reagents at an open vendor, AH reagents into AHSentinel's sniper
function UI.BuyForRecipe(r, n)
    n = n or 1
    local need = {}
    for i = 1, #(r.reagents or {}), 2 do need[r.reagents[i]] = (need[r.reagents[i]] or 0) + r.reagents[i + 1] * n end
    local list = ns.Advisor.Shopping({ reagents = need })
    local PL = ns.Plan
    local bought = 0
    if PL.MerchantOpen and PL.MerchantOpen() then
        for _, e in ipairs(list) do
            if e.missing > 0 and e.origin == "vendor" then bought = bought + (PL.BuyAmount(e.id, e.missing) or 0) end
        end
    end
    local targets = PL.SniperTargets(list)
    if #targets > 0 and ns.Disenchant.SendToSniper then
        ns.Disenchant.SendToSniper(targets, ns.RecipeName(r), L.PLAN_SNIPE_DONE)
    end
    return bought, #targets
end

local function CreateDetails()
    if details then return details end
    local tmpl = BackdropTemplateMixin and "BackdropTemplate" or nil
    details = CreateFrame("Frame", nil, panel, tmpl)
    details:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 8, 22)
    details:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -6, 22)
    details:SetHeight(UI.DETAILS_HEIGHT)
    if details.SetBackdrop then
        details:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = true, tileSize = 16, edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
        if details.SetBackdropColor then details:SetBackdropColor(0, 0, 0, 0.6) end
    end
    details.title = details:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    details.title:SetPoint("TOPLEFT", 10, -8)
    details.title:SetPoint("RIGHT", details, "RIGHT", -30, 0)
    details.title:SetJustifyH("LEFT")
    details.title:SetWordWrap(false)
    details.body = details:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    details.body:SetPoint("TOPLEFT", details.title, "BOTTOMLEFT", 0, -4)
    details.body:SetPoint("BOTTOMRIGHT", details, "BOTTOMRIGHT", -10, 32)
    details.body:SetJustifyH("LEFT")
    details.body:SetJustifyV("TOP")
    details.close = CreateFrame("Button", nil, details, "UIPanelCloseButton")
    details.close:SetSize(22, 22)
    details.close:SetPoint("TOPRIGHT", details, "TOPRIGHT", -2, -2)
    details.close:SetScript("OnClick", function() UI.HideDetails() end)
    details.craft = CreateFrame("Button", nil, details, "UIPanelButtonTemplate")
    details.craft:SetSize(110, 22)
    details.craft:SetPoint("BOTTOMLEFT", details, "BOTTOMLEFT", 8, 6)
    details.craft:SetText(L.DT_CRAFT)
    details.craft:SetScript("OnClick", function()
        local r = details.recipe
        if r and ns.Today and ns.Today.Craft then ns.Today.Craft({ recipe = r, count = 1 }) end
    end)
    details.shop = CreateFrame("Button", nil, details, "UIPanelButtonTemplate")
    details.shop:SetSize(130, 22)
    details.shop:SetPoint("LEFT", details.craft, "RIGHT", 6, 0)
    details.shop:SetText(L.DT_SHOP)
    details.shop:SetScript("OnClick", function() if details.recipe then UI.BuyForRecipe(details.recipe, 1) end end)
    UI.GuardTemplateTooltip(details.craft)
    UI.GuardTemplateTooltip(details.shop)
    details:Hide()
    return details
end
UI.DetailsFrame = function() return details end

-- the list makes room for the details (and gets it back when they close)
local function LayoutDetails(show)
    if not (panel and panel.Inset) then return end
    panel.Inset:ClearAllPoints()
    panel.Inset:SetPoint("TOPLEFT", panel, "TOPLEFT", 8, -106)
    panel.Inset:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -6, show and (22 + UI.DETAILS_HEIGHT + 4) or 22)
end

function UI.RefreshDetails()
    if not (details and details.recipe and details:IsShown()) then return end
    local r = details.recipe
    local _, rank = CurrentProfession()
    local title, lines = UI.DetailLines(r, rank)
    details.title:SetText(title)
    details.body:SetText(table.concat(lines, "\n"))
    details.craft:SetEnabled(IsLearned(r) and true or false)
end

function UI.ShowDetails(r)
    if not panel then return end
    CreateDetails()
    details.recipe = r
    UI.selected = r
    LayoutDetails(true)
    details:Show()
    UI.RefreshDetails()
end

function UI.HideDetails()
    UI.selected = nil
    if details then details.recipe = nil; details:Hide() end
    LayoutDetails(false)
end

local function UpdateTabs()
    if not UI.mainTabs then return end
    local m = Mode()
    local g = UI.GroupOfMode(m)
    -- the details belong to the tab "Recipes"
    if details and details:IsShown() then
        if m ~= "recipes" then details:Hide(); LayoutDetails(false) else UI.RefreshDetails() end
    elseif m == "recipes" and details and details.recipe then
        details:Show(); LayoutDetails(true); UI.RefreshDetails()
    end
    -- the number of missing recipes in the AH (recipe alarm) on the tab "Recipes" instead of a chat list (U8)
    local AL = ns.Alerts
    local alarm = AL and ns.db.recipeAlert ~= false and #(AL.found or {}) or 0
    for _, b in ipairs(UI.mainTabs) do
        local label = b.label .. ((b.group == "recipes" and alarm > 0) and (" |cffffd100" .. alarm .. "|r") or "")
        b:SetText(label)
        UI.SetSelected(b, b.group == g)
    end
    -- views of the tab (a small switch below the tabs, left of the search)
    for _, t in ipairs({ tabRecipes, tabRanking, tabPlan, tabTrainers, tabDisenchant, tabFavor, tabGoldList }) do t:Hide() end
    for _, b in ipairs(UI.filterButtons or {}) do b:Hide() end
    tabPlan:SetText(L.PLAN_TAB); UI.SetSelected(tabPlan, m == "plan")
    tabRanking:SetText(L.RANKING_TAB); UI.SetSelected(tabRanking, m == "ranking")
    tabTrainers:SetText(L.TRAINERS); UI.SetSelected(tabTrainers, m == "trainers")
    tabGoldList:SetText(L.GOLD_VIEW); UI.SetSelected(tabGoldList, m == "gold")
    tabDisenchant:SetText(L.DE_TAB); UI.SetSelected(tabDisenchant, m == "disenchant")
    tabRecipes:SetText(L.RECIPES_TAB); UI.SetSelected(tabRecipes, m == "recipes")
    tabFavor:SetText(L.FAVOR_TAB); UI.SetSelected(tabFavor, m == "favor")
    searchBox:SetShown(g ~= "now")
    if g == "now" then
        -- no switch: the cards are the whole tab
    elseif g == "skill" then
        local list = { tabPlan, tabRanking }
        if ns.HasSourceData ~= false then list[#list + 1] = tabTrainers end     -- Retail: no trainer data
        PlaceRow(list, 76)
    elseif g == "gold" then
        local list = { tabGoldList }
        if ns.Disenchant and ns.Disenchant.IsEnchanter() then list[#list + 1] = tabDisenchant end
        PlaceRow(list, 100)
    else
        -- tab "Recipes": ONE switch for the filter (All / Learned / Learnable / Missing) and, in WoW Forever, the
        -- Händlergunst view (one level, no second row of buttons)
        local list = {}
        for _, b in ipairs(UI.filterButtons) do list[#list + 1] = b end
        if ns.Favor and ns.Favor.Active() then list[#list + 1] = tabFavor end
        PlaceRow(list, #list > 4 and 50 or 58)
        if m == "favor" then for _, b in ipairs(UI.filterButtons) do UI.SetSelected(b, false) end end
    end
end

-- filter buttons of the tab "Recipes": All · Learned · Learnable · Missing (with numbers)
function UI.UpdateFilterButtons(counts)
    if not UI.filterButtons then return end
    local show = UI.RecipeFilter()
    counts = counts or UI.recipeCounts or {}
    local all = show.learned and show.learnable and show.missing
    for _, b in ipairs(UI.filterButtons) do
        local on = (b.key == "all" and all) or (b.key ~= "all" and show[b.key] and not all)
        if Mode() == "favor" then on = false end
        local n = b.key == "all" and ((counts.learned or 0) + (counts.learnable or 0) + (counts.missing or 0)) or counts[b.key]
        b:SetText(b.label .. (n and (" " .. n) or ""))
        UI.SetSelected(b, on)
    end
end

function UI.ClickFilter(key)
    if Mode() == "favor" then ns.db.panelMode = "recipes" end      -- the filter belongs to the recipe list
    local show = UI.RecipeFilter()
    if key == "all" then
        show.learned, show.learnable, show.missing = true, true, true
    else
        local all = show.learned and show.learnable and show.missing
        if all then show.learned, show.learnable, show.missing = false, false, false end
        show[key] = not show[key]
        if not (show.learned or show.learnable or show.missing) then show[key] = true end
    end
    UI:Refresh()
end

---------------------------------------------------------------------------
-- Groups of the tab "Recipes" by place, like in the game (UI rework U2): from the equip slot of the product
-- (GetItemInfoInstant), otherwise its item class/subclass – never from the recipe name. Enchants: the game's category.
---------------------------------------------------------------------------
UI.SLOT_GROUP = {
    INVTYPE_HEAD = "HEAD", INVTYPE_SHOULDER = "SHOULDER", INVTYPE_CHEST = "CHEST", INVTYPE_ROBE = "CHEST",
    INVTYPE_WAIST = "WAIST", INVTYPE_LEGS = "LEGS", INVTYPE_HAND = "HANDS", INVTYPE_FEET = "FEET",
    INVTYPE_CLOAK = "BACK", INVTYPE_WRIST = "WRIST", INVTYPE_BODY = "SHIRT", INVTYPE_TABARD = "SHIRT",
    INVTYPE_BAG = "BAG", INVTYPE_QUIVER = "BAG",
    INVTYPE_WEAPON = "WEAPON", INVTYPE_2HWEAPON = "WEAPON", INVTYPE_WEAPONMAINHAND = "WEAPON",
    INVTYPE_WEAPONOFFHAND = "WEAPON", INVTYPE_RANGED = "WEAPON", INVTYPE_RANGEDRIGHT = "WEAPON",
    INVTYPE_THROWN = "WEAPON", INVTYPE_SHIELD = "OFFHAND", INVTYPE_HOLDABLE = "OFFHAND",
    INVTYPE_FINGER = "JEWEL", INVTYPE_NECK = "JEWEL", INVTYPE_TRINKET = "JEWEL",
    INVTYPE_AMMO = "AMMO",
}
-- consumables (class 0) by subclass: potion, elixir, flask, scroll, food, item enhancement, bandage
UI.CONSUMABLE_GROUP = { [1] = "POTION", [2] = "ELIXIR", [3] = "FLASK", [4] = "SCROLL", [5] = "FOOD", [6] = "ENHANCE",
    [7] = "BANDAGE" }
UI.GROUP_ORDER = { "HEAD", "SHOULDER", "CHEST", "WAIST", "LEGS", "HANDS", "FEET", "BACK", "WRIST", "SHIRT", "WEAPON",
    "OFFHAND", "JEWEL", "BAG", "AMMO", "POTION", "ELIXIR", "FLASK", "TRANSMUTE", "FOOD", "SCROLL", "ENHANCE", "BANDAGE",
    "TRADEGOODS", "USE", "OTHER" }

-- group key of a recipe (and the label for enchants: the game's category)
function UI.SlotGroup(r)
    if not r.out then return "ENCH:" .. (r.cat or ""), r.cat end
    local equipLoc, classID, subclassID = ns.ItemSlotInfo(r.out)
    local g = equipLoc and UI.SLOT_GROUP[equipLoc]
    if g then return g end
    if classID == 0 then return UI.CONSUMABLE_GROUP[subclassID] or "USE" end
    if classID == 1 then return "BAG" end
    if classID == 2 then return "WEAPON" end
    if classID == 6 then return "AMMO" end
    if classID == 7 then
        -- alchemy: transmutations (a trade good made from another trade good, e.g. Arcanite Bar)
        if r.prof == 171 and r.reagents and r.reagents[1] and select(2, ns.ItemSlotInfo(r.reagents[1])) == 7 then
            return "TRANSMUTE"
        end
        return "TRADEGOODS"
    end
    if classID == 4 or classID == 15 then return "USE" end
    return "OTHER"
end

function UI.GroupLabel(key, label)
    if label then return label end
    return L["GRP_" .. key] or L.GRP_OTHER
end

-- filter of the tab "Recipes": learned / learnable now / missing (not learnable yet); default learned + learnable
function UI.RecipeState(r, rank, learned)
    if learned then return "learned" end
    if rank and (r.req or 0) <= rank then return "learnable" end
    return "missing"
end
function UI.RecipeFilter()
    local f = ns.db.filters.show
    if type(f) ~= "table" then
        f = { learned = true, learnable = true, missing = false }
        ns.db.filters.show = f
    end
    return f
end

local function RefreshRecipes(prof, rank, maxRank, text)
    local show = UI.RecipeFilter()
    local onlyMissing = not show.learned
    local dp = CreateTreeDataProvider()
    local cats, order = {}, {}
    local total, known = 0, 0
    local counts = { learned = 0, learnable = 0, missing = 0 }
    for _, r in ipairs(ns.ByProf[prof] or {}) do
        Yield()
        local learned = IsLearned(r)
        local state = UI.RecipeState(r, rank, learned)
        counts[state] = counts[state] + 1
        total = total + 1
        if learned then known = known + 1 end
        if MatchesSearch(r, text) and (show[state] or text ~= "") then
            local key, label = UI.SlotGroup(r)
            local c = cats[key]
            if not c then
                c = { name = UI.GroupLabel(key, label), key = key, items = {}, known = 0, total = 0 }
                cats[key] = c
                order[#order + 1] = c
            end
            c.total = c.total + 1
            if learned then c.known = c.known + 1 end
            c.items[#c.items + 1] = { recipe = r, learned = learned, rank = rank }
        end
    end
    -- recipe alarm: recipes you or your characters miss that are in the AH right now (AHSentinel)
    local AL = ns.Alerts
    if AL and ns.db.recipeAlert ~= false and text == "" then
        local found = AL.FromCurrent()
        local mine = {}
        for _, f in ipairs(found) do if f.recipe.prof == prof then mine[#mine + 1] = f end end
        if #mine > 0 then
            local ha = dp:Insert({ header = true, key = "alerts", name = L.ALERT_GROUP, countText = tostring(#mine), tip = L.ALERT_EXPLAIN })
            for _, f in ipairs(mine) do
                local q = ns.ItemQuality(f.itemID)
                ha:Insert({ info = true, itemID = f.itemID, icon = ns.GetItemIcon(f.itemID),
                    text = "|cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(f.itemID) .. "|r",
                    value = ns.Prices.Money(f.price),
                    detail = "|cffd0c0a0" .. string.format(L.ALERT_WHO, table.concat(f.who, ", ")) .. "|r",
                    onClick = function() AL.ToSniper(f) end, tip = { " ", L.ALERT_CLICK } })
            end
            if collapsed["alerts"] then ha:SetCollapsed(true) end
        end
    end

    -- recipes in your bags (all professions): who needs them – or nobody
    if AL and text == "" then
        local bag = AL.BagRecipes()
        if #bag > 0 then
            local hbg = dp:Insert({ header = true, key = "bag-recipes", name = L.BAG_GROUP, countText = tostring(#bag), tip = L.BAG_EXPLAIN })
            for _, b in ipairs(bag) do
                local q = ns.ItemQuality(b.itemID)
                local detail
                if #b.who > 0 then
                    detail = "|cff40c040" .. string.format(L.BAG_NEEDED, table.concat(b.who, ", ")) .. "|r"
                else
                    local worth = b.ah and (L.ORIGIN_AH .. " ~" .. ns.Prices.MoneyPlain(b.ah)) or (b.vendor and (L.ORIGIN_VENDOR .. " " .. ns.Prices.MoneyPlain(b.vendor))) or ""
                    detail = "|cffffd100" .. L.BAG_NOBODY .. (worth ~= "" and (" – " .. worth) or "") .. "|r"
                end
                hbg:Insert({ info = true, itemID = b.itemID, icon = ns.GetItemIcon(b.itemID),
                    text = "|cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(b.itemID) .. "|r" .. (b.count > 1 and (" ×" .. b.count) or ""),
                    value = "|cffb0b0b0" .. ns.ProfName(b.recipe.prof) .. "|r", detail = detail })
            end
            if collapsed["bag-recipes"] then hbg:SetCollapsed(true) end
        end
    end

    -- ranking top 10 on top (only without a search)
    local AD = ns.Advisor
    if AD and ns.db.best ~= false and text == "" and rank then
        local ranking = AD.current.ranking or {}
        if #ranking > 0 then
            local priced = ranking[1].netPerPoint ~= nil
            local h = dp:Insert({ header = true, key = "ranking-top",
                name = AD.STAR .. " " .. (priced and L.LEVEL_TOP or L.RANKING_TOP),
                countText = "", tip = priced and L.LEVEL_EXPLAIN or L.RANKING_EXPLAIN })
            local shown = 0
            for _, e in ipairs(ranking) do
                if not (onlyMissing and e.learned) then
                    h:Insert({ recipe = e.recipe, learned = e.learned, rank = rank, suggest = true,
                        place = e.place, entry = e, reason = AD.Reason(e, true) })
                    shown = shown + 1
                    if shown >= 10 then break end
                end
            end
            if collapsed["ranking-top"] then h:SetCollapsed(true) end
        end
    end
    -- guild cooldowns of this profession (GuildSentinel)
    local GU = ns.Guild
    local cds = GU and text == "" and GU.Cooldowns(prof)
    if cds and #cds > 0 then
        local hc = dp:Insert({ header = true, key = "cooldowns", name = L.CD_GROUP, countText = "", tip = L.CD_EXPLAIN })
        for _, c in ipairs(cds) do
            local parts = {}
            for i, e in ipairs(c.list) do
                if i > 6 then parts[#parts + 1] = string.format(L.MORE, #c.list - 6); break end
                parts[#parts + 1] = (e.online and "|cffffffff" or "|cff9d9d9d") .. e.name .. "|r " .. GU.LeftText(e.left)
            end
            hc:Insert({ info = true, icon = ns.GetItemIcon(c.key == "transmute" and 12360 or c.key == "mooncloth" and 14342 or 15846),
                text = c.label, value = "", detail = table.concat(parts, " · ") })
        end
        if collapsed["cooldowns"] then hc:SetCollapsed(true) end
    end
    -- groups in the game's order (head to feet, then bags, consumables, trade goods, other)
    local rankOf = {}
    for i, k in ipairs(UI.GROUP_ORDER) do rankOf[k] = i end
    table.sort(order, function(a, b)
        local ra, rb = rankOf[a.key] or 99, rankOf[b.key] or 99
        if ra ~= rb then return ra < rb end
        return a.name < b.name
    end)
    UI.recipeCounts = counts
    UI.UpdateFilterButtons(counts)
    for _, c in ipairs(order) do
        local header = dp:Insert({ header = true, key = "grp:" .. c.key, name = c.name, known = c.known, total = c.total })
        for _, item in ipairs(c.items) do header:Insert(item) end
        if collapsed["grp:" .. c.key] and text == "" then header:SetCollapsed(true) end
    end
    -- recipes nobody in the guild knows (needs GuildSentinel / RaidMaster data); collapsed by default
    local nobody = GU and text == "" and GU.NobodyKnows(prof)
    if nobody and #nobody > 0 then
        local hn = dp:Insert({ header = true, key = "guild-nobody", name = L.GUILD_NOBODY_GROUP, countText = tostring(#nobody), tip = L.GUILD_NOBODY_EXPLAIN })
        for _, r in ipairs(nobody) do hn:Insert({ recipe = r, learned = IsLearned(r), rank = rank }) end
        if collapsed["guild-nobody"] ~= false then hn:SetCollapsed(true) end
    end
    scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
    local rankText = rank and string.format("   %s: %d%s", L.YOUR_SKILL, rank, maxRank and maxRank > 0 and ("/" .. maxRank) or "") or ""
    summary:SetText(string.format("%d/%d %s%s", known, total, L.KNOWN, rankText))
end

-- "Heute herstellen": the most profitable crafts of all professions, one click = next step
local function InsertToday(dp, text)
    local TD = ns.Today
    if not TD or text ~= "" then return end
    local list = TD.Candidates()
    local P = ns.Prices
    local ht = dp:Insert({ header = true, key = "today", name = L.TODAY_GROUP, countText = tostring(#list),
        tip = P and P.SourceName() and L.TODAY_EXPLAIN or L.GOLD_NONE })
    for _, e in ipairs(list) do
        Yield()
        local r = e.recipe
        local q = ns.ItemQuality(r.out)
        ht:Insert({ info = true, itemID = r.out, icon = ns.GetItemIcon(r.out),
            text = "|cffffd100" .. e.count .. "×|r |cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(r.out) .. "|r",
            value = ns.Advisor.NetColored(e.net),
            detail = "|cff40c0ff>> " .. TD.StepText(e) .. "|r  |cffb0b0b0" .. string.format(L.TODAY_PER_CRAFT, P.MoneyPlain(e.perCraft, true)) .. "|r",
            onClick = function() TD.Run(e) end,
            tip = { ns.RecipeName(r) .. " – " .. ns.ProfName(r.prof), " ", L.TODAY_CLICK, " ", L.TODAY_EXPLAIN } })
    end
    -- WoW Forever, option (off by default): the best Waylaid Crate – gold per favor point
    local FV = ns.Favor
    local best = FV and FV.BestCrate()
    if best then
        ht:Insert({ info = true, itemID = best.crate.id, icon = ns.GetItemIcon(best.crate.id),
            text = "|cff66ccff" .. ns.ItemName(best.crate.id) .. "|r",
            value = "|cffd0c0a0" .. string.format(L.FAVOR_PER_POINT, P.MoneyPlain(best.perFavor)) .. "|r",
            detail = "|cffb0b0b0" .. string.format(L.FAVOR_CRATE_GIVES, best.favor) .. " · "
                .. string.format(L.FAVOR_CRATE_BEST, best.best.count, ns.ItemName(best.best.id), P.MoneyPlain(best.best.cost)) .. "|r",
            onClick = function() UI:SetMode("favor") end,
            tip = { L.FAVOR_TODAY_EXPLAIN, " ", L.FAVOR_TODAY_CLICK } })
    end
    if #list == 0 and not best then
        ht:Insert({ info = true, text = "|cffb0b0b0" .. (P and P.SourceName() and L.TODAY_NONE or L.GOLD_NONE) .. "|r" })
    end
    if collapsed["today"] then ht:SetCollapsed(true) end
end

---------------------------------------------------------------------------
-- Tab "Jetzt" (UI rework 2, question F1 "what do I do NOW?"): at most three cards, each with ONE number, ONE sentence
-- and ONE click – next skill point, best gold recipe now, a single recipe in the AH (instead of the sum, P-4) – plus a
-- card at the skill cap and the cooldowns as one small line. Everything else stays in the other tabs.
---------------------------------------------------------------------------
UI.CAP_SOON = 5        -- "skill cap soon" this many points before the cap
-- caps that a trainer lifts (the last cap of a game version has no next rank: no card)
UI.CAPS = { [75] = true, [150] = true, [225] = true }

-- the missing materials of one craft (names, at most two) or nil when everything is in the bags
function UI.MissingMaterials(r, n)
    local out = {}
    for i = 1, #(r.reagents or {}), 2 do
        local id, need = r.reagents[i], r.reagents[i + 1] * (n or 1)
        local have = ns.GetItemCount(id, false) or 0
        if have < need then out[#out + 1] = (need - have) .. "× " .. ns.ItemName(id) end
    end
    if #out == 0 then return nil end
    if #out > 2 then out = { out[1], out[2], "…" } end
    return table.concat(out, ", ")
end

-- the cap card: nil, "soon" or "reached" (only where trainer ranks exist, not in Retail)
function UI.CapState(rank, maxRank)
    if ns.IsRetail or not (rank and maxRank and UI.CAPS[maxRank]) then return nil end
    if rank >= maxRank then return "reached" end
    if maxRank - rank <= UI.CAP_SOON then return "soon" end
    return nil
end

local function RefreshNow(prof, rank, maxRank, text)
    local dp = CreateTreeDataProvider()
    local P, PL, AD, TD, AL = ns.Prices, ns.Plan, ns.Advisor, ns.Today, ns.Alerts
    local cards = 0
    -- 1. next skill point
    if rank and PL then
        local plan = PL.Build(prof, rank, maxRank)
        local first = plan and plan.steps and plan.steps[1]
        if first then
            local r = first.recipe
            local calc = ns.Lifeline and ns.Lifeline.Calc(r, rank)
            local crafts = calc and calc.crafts or first.crafts
            local detail
            if not first.learned then detail = L.NOW_SKILL_LEARN
            else
                local miss = UI.MissingMaterials(r, 1)
                detail = miss and string.format(L.NOW_SKILL_MATS, miss) or L.NOW_SKILL_MATS_OK
            end
            dp:Insert({ info = true, now = "skill", icon = RowIcon(r),
                text = "|cffffd100" .. L.NOW_SKILL .. ":|r |cffffffff" .. ns.RecipeName(r) .. "|r",
                value = crafts and ("|cffff8040" .. crafts .. "×|r") or "",
                detail = "|cffb0b0b0" .. detail .. "|r", recipe = r,
                onClick = function()
                    if first.learned then SelectInBlizzard(r) else UI:SetMode("plan") end
                end,
                tip = { L.NOW_SKILL_TIP } })
            cards = cards + 1
        end
    end
    -- 2. best gold recipe now (secured, the same number as tab Gold and AHSentinel)
    if TD and P and P.SourceName() then
        local list = TD.Candidates()
        local e = list[1]
        if e then
            local r = e.recipe
            local q = ns.ItemQuality(r.out)
            dp:Insert({ info = true, now = "gold", itemID = r.out, icon = ns.GetItemIcon(r.out),
                text = "|cffffd100" .. L.NOW_GOLD .. ":|r |cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. ns.ItemName(r.out) .. "|r",
                value = AD.NetColored(e.perCraft),
                detail = "|cffb0b0b0" .. string.format(L.NOW_GOLD_CLICK, TD.StepText(e)) .. "|r",
                onClick = function() TD.Run(e) end,
                tip = { L.NOW_GOLD_TIP } })
            cards = cards + 1
        end
    end
    -- 3. a single recipe in the AH (the cheapest one), never the sum
    if AL and ns.db.recipeAlert ~= false then
        local f = (AL.found or {})[1]
        if f then
            local who = table.concat(f.who or {}, ", ")
            dp:Insert({ info = true, now = "alarm", itemID = f.itemID, icon = ns.GetItemIcon(f.itemID),
                text = "|cffffd100" .. string.format(L.NOW_ALARM, who) .. ":|r |cffffffff" .. ns.ItemName(f.itemID) .. "|r",
                value = P and P.MoneyPlain(f.price) or "",
                detail = "", onClick = function() AL.ToSniper(f) end, tip = { L.NOW_ALARM_TIP } })
            cards = cards + 1
        end
    end
    -- skill cap soon / reached
    local cap = UI.CapState(rank, maxRank)
    if cap then
        -- the nearest trainer of the next rank with "show the way" (or the level hint, then no way)
        local WP = ns.Waypoint
        local line, npc = WP.NextTrainerLine(prof, rank, maxRank)
        dp:Insert({ info = true, now = "cap", icon = "Interface\\Icons\\INV_Misc_Book_09", npcTarget = npc,
            text = "|cffff8040" .. string.format(cap == "reached" and L.NOW_CAP or L.NOW_CAP_SOON, maxRank) .. "|r",
            value = "", detail = "|cffb0b0b0" .. (line and (line .. (npc and (" – " .. L.TRAINER_WAY) or "")) or L.NOW_CAP_TIP) .. "|r",
            onClick = function()
                if npc then WP.Set(npc, ns.NPCs[npc] and ns.NPCs[npc][1])
                elseif ns.HasSourceData ~= false then UI:SetMode("trainers") end
            end, tip = { L.NOW_CAP_TIP } })
    end
    if cards == 0 and not cap then
        dp:Insert({ info = true, now = "nothing", text = "|cffb0b0b0" .. L.NOW_NOTHING .. "|r" })
    end
    -- cooldowns (GuildSentinel) as one small line
    local GU = ns.Guild
    local cds = GU and GU.Cooldowns and GU.Cooldowns(prof)
    if cds and #cds > 0 then
        local parts = {}
        for _, c in ipairs(cds) do parts[#parts + 1] = c.label end
        dp:Insert({ info = true, now = "cd", text = "|cffb0b0b0" .. L.NOW_CD .. ": " .. table.concat(parts, " · ") .. "|r" })
    end
    scrollBox:SetDataProvider(dp)
    summary:SetText("")
end

local function RefreshRanking(prof, rank, maxRank, text)
    local AD = ns.Advisor
    local P = ns.Prices
    local dp = CreateTreeDataProvider()
    InsertToday(dp, text)
    local ranking = AD and AD.current.ranking or {}
    local learnedN, learnN = 0, 0

    -- 1. Levelling: material per skill point (pure amount; learned first, then not learned)
    local mat = AD and AD.current.mat or {}
    local h = dp:Insert({ header = true, key = "ranking", name = L.LEVEL_MAT_GROUP,
        countText = tostring(#mat), tip = L.LEVEL_MAT_EXPLAIN })
    local divider = false
    for _, e in ipairs(mat) do
        Yield()
        if e.learned then learnedN = learnedN + 1 else learnN = learnN + 1 end
        if MatchesSearch(e.recipe, text) then
            if not e.learned and not divider then
                divider = true
                h:Insert({ info = true, text = "|cff3fc7eb" .. L.LEVEL_MAT_NOTLEARNED .. "|r" })
            end
            h:Insert({ recipe = e.recipe, learned = e.learned, rank = rank, suggest = true, matLevel = true,
                place = e.matPlace, entry = e })
        end
    end
    if collapsed["ranking"] and text == "" then h:SetCollapsed(true) end

    scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
    local priceLine = UI.PriceLine()
    if not rank then
        summary:SetText(L.OPEN_PROF_FIRST)
    elseif #mat == 0 then
        summary:SetText(L.RANKING_NONE .. "\n" .. priceLine)
    else
        summary:SetText(string.format(L.RANKING_SUMMARY, #mat, rank, learnedN, learnN) .. "\n" .. priceLine)
    end
end

-- tab "Gold" (UI rework U5): what pays now – crafting by real profit (best way, amount by sales), then the way to
-- the disenchanting trade and the bargains (view "Disenchanting" for enchanters)
local function RefreshGold(prof, rank, maxRank, text)
    local AD, MK = ns.Advisor, ns.Market
    local dp = CreateTreeDataProvider()
    local gold = AD and AD.current.gold or {}
    -- market knowledge (PM1/PM3/PM5): "check data" apart, "sell the reagents raw" when they are in the bags,
    -- raid food and potions as a filter before the raid start
    local raidOn = MK and MK.RaidFilterOn()
    local good, hardly, raw, check = {}, {}, {}, {}
    for _, e in ipairs(gold) do
        if not raidOn or MK.IsRaidConsumable(e.recipe) then
            local pr = e.price
            if pr and pr.flag then check[#check + 1] = e
            elseif pr and pr.direction == "raw" and (e.craftable or 0) > 0 then raw[#raw + 1] = e
            elseif e.sellCap == 0 or e.net <= 0 then hardly[#hardly + 1] = e
            else good[#good + 1] = e end
        end
    end
    if MK and text == "" then
        for _, h in ipairs(MK.BandHints(gold)) do
            dp:Insert({ info = true, text = "|cffffd100" .. MK.BandText(h) .. "|r" })
        end
        if MK.RaidFilterOffered() then
            dp:Insert({ info = true, text = (raidOn and "|cff40c040" or "|cffa89c84") .. MK.RaidFilterText(raidOn) .. "|r",
                onClick = function() ns.db.goldRaid = not ns.db.goldRaid; UI:Refresh() end })
        end
    end
    local g = dp:Insert({ header = true, key = "gold", name = L.GOLD_GROUP, countText = tostring(#good),
        tip = #gold > 0 and L.GOLD_EXPLAIN or L.GOLD_NONE })
    for _, e in ipairs(good) do
        Yield()
        if MatchesSearch(e.recipe, text) then
            g:Insert({ recipe = e.recipe, learned = e.learned, rank = rank, suggest = true, gold = true,
                place = e.place, entry = e })
        end
    end
    if collapsed["gold"] and text == "" then g:SetCollapsed(true) end
    if #raw > 0 then
        local h = dp:Insert({ header = true, key = "gold-raw", name = L.MK_RAW_GROUP, countText = tostring(#raw), tip = L.MK_RAW_EXPLAIN })
        for _, e in ipairs(raw) do
            Yield()
            if MatchesSearch(e.recipe, text) then
                h:Insert({ recipe = e.recipe, learned = e.learned, rank = rank, suggest = true, gold = true, raw = true,
                    place = e.place, entry = e })
            end
        end
        if collapsed["gold-raw"] then h:SetCollapsed(true) end
    end
    if #check > 0 then
        local h = dp:Insert({ header = true, key = "gold-check", name = L.MK_CHECK_GROUP, countText = tostring(#check), tip = L.MK_CHECK_EXPLAIN })
        for _, e in ipairs(check) do
            Yield()
            if MatchesSearch(e.recipe, text) then
                h:Insert({ recipe = e.recipe, learned = e.learned, rank = rank, suggest = true, gold = true,
                    place = e.place, entry = e })
            end
        end
        if collapsed["gold-check"] ~= false then h:SetCollapsed(true) end
    end
    if #hardly > 0 then
        local h = dp:Insert({ header = true, key = "gold-hardly", name = L.GOLD_HARDLY_GROUP, countText = tostring(#hardly),
            tip = L.GOLD_HARDLY_EXPLAIN })
        for _, e in ipairs(hardly) do
            Yield()
            if MatchesSearch(e.recipe, text) then
                h:Insert({ recipe = e.recipe, learned = e.learned, rank = rank, suggest = true, gold = true,
                    place = e.place, entry = e })
            end
        end
        if collapsed["gold-hardly"] ~= false then h:SetCollapsed(true) end
    end
    -- disenchanting trade and bargains: the view of enchanters
    if ns.Disenchant and ns.Disenchant.IsEnchanter() and text == "" then
        dp:Insert({ info = true, text = "|cff3fc7eb" .. L.GOLD_TO_DE .. "|r", onClick = function() UI:SetMode("disenchant") end })
    end
    scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
    local pct = ns.PriceSource.MinProfitPct()
    summary:SetText((rank and "" or (L.OPEN_PROF_FIRST .. "\n")) .. UI.PriceLine() .. "  ·  " .. string.format(L.MIN_PROFIT_LINE, pct))
end

-- the next orange recipe once the current step turns yellow within 2 crafts (U3); nil otherwise
function UI.NextOrange(prof, first, rank)
    local AD = ns.Advisor
    if not (first and first.recipe and rank) then return nil end
    local r = first.recipe
    local left = (r.yellow or 0) - rank
    if left > 2 or left < 0 then return nil end
    local at = r.yellow
    -- from the values already there (review 0.9.38, point 1c): the material ranking of this profession, else the
    -- recipe list – the cheapest material per point among the recipes that are orange at "at"
    local entries = (AD.current.prof == prof and AD.current.mat) or nil
    local best, bestV
    if entries and #entries > 0 then
        for _, e in ipairs(entries) do
            if e.recipe ~= r and AD.Reachable(e.recipe, at) then
                local _, colour = AD.ColourPoints(e.recipe, at)
                if colour == "orange" then return e.recipe end
            end
        end
        return nil
    end
    for _, x in ipairs(ns.ByProf[prof] or {}) do
        if x ~= r and AD.Reachable(x, at) then
            local _, colour = AD.ColourPoints(x, at)
            if colour == "orange" then
                local v = AD.BaseMats(x)
                if not best or v < bestV then best, bestV = x, v end
            end
        end
    end
    return best
end

local function RefreshPlan(prof, rank, maxRank, text)
    local PL, P, AD = ns.Plan, ns.Prices, ns.Advisor
    local dp = CreateTreeDataProvider()
    if not rank then
        scrollBox:SetDataProvider(dp)
        summary:SetText(L.SKILL_UNKNOWN)      -- never plan from a made-up 0
        return
    end
    local plan = PL.Build(prof, rank, maxRank)

    -- next step (U4): skill -> end of the first step, recipe ×crafts, material per point, "learn" + where;
    -- shortly before it turns yellow (≤ 2 crafts) already the next orange recipe (U3)
    local first = plan.steps[1]
    if first then
        local hn = dp:Insert({ header = true, key = "plan-next", name = string.format(L.NEXT_STEP, rank, first.to), countText = "" })
        local pts = AD.ColourPoints(first.recipe, rank)
        local per = pts > 0 and AD.BaseMats(first.recipe) / pts or nil
        local detail = per and string.format(L.ROW_PER_POINT, AD.Num1(per)) or ""
        if not first.learned then detail = detail .. "  |cff3fc7eb" .. L.TAG_LEARN .. "|r" end
        hn:Insert({ recipe = first.recipe, learned = first.learned, rank = rank, suggest = true, place = 1,
            planStep = first, entry = { recipe = first.recipe } })
        local nextOrange = UI.NextOrange(prof, first, rank)
        if nextOrange then
            hn:Insert({ info = true, icon = RowIcon(nextOrange), text = string.format(L.NEXT_ORANGE, "|cffff8040" .. ns.RecipeName(nextOrange) .. "|r"),
                detail = "|cffb0b0b0" .. detail .. "|r", onClick = function() SelectInBlizzard(nextOrange) end })
        end
        -- not learned: where to learn it (waypoint on click)
        local unlearned
        for _, st in ipairs(plan.steps) do if not st.learned then unlearned = st; break end end
        local WP = ns.Waypoint
        local npc = unlearned and WP and WP.BestSourceNPC(unlearned.recipe)
        if npc and ns.NPCs[npc] then
            hn:Insert({ info = true, icon = "Interface\\Icons\\INV_Misc_Book_09",
                text = string.format(L.NEXT_LEARN_AT, ns.RecipeName(unlearned.recipe), ns.NPCs[npc][1]),
                detail = "|cffb0b0b0" .. (WP.LocationText(npc) or "") .. "|r",
                onClick = function() WP.Set(npc, ns.NPCs[npc][1] .. " – " .. ns.RecipeName(unlearned.recipe)) end })
        end
    end

    -- near the cap (25 points or less): the nearest trainer of the next rank as a step of the plan
    if maxRank and UI.CAPS[maxRank] and maxRank - rank <= 25 then
        local WP = ns.Waypoint
        local line, npc = WP.NextTrainerLine(prof, rank, maxRank)
        if line then
            local hl = dp:Insert({ header = true, key = "plan-trainer", name = string.format(L.NOW_CAP_SOON, maxRank), countText = "" })
            hl:Insert({ info = true, icon = "Interface\\Icons\\INV_Misc_Book_09", text = line, npcTarget = npc,
                detail = npc and ("|cffb0b0b0" .. L.TRAINER_WAY .. "|r") or "",
                onClick = npc and function() WP.Set(npc, ns.NPCs[npc] and ns.NPCs[npc][1]) end or nil })
        end
    end

    -- target (click: next cap)
    local ht = dp:Insert({ header = true, key = "plan-target", name = L.PLAN_HEADER, countText = "" })
    ht:Insert({ info = true, icon = "Interface\\Icons\\INV_Misc_Note_01",
        text = string.format(L.PLAN_TARGET_ROW, rank, plan.to), detail = "|cffb0b0b0" .. (ns.IsRetail and L.PLAN_TARGET_RETAIL or L.PLAN_TARGET_CLICK) .. "|r",
        onClick = function() PL.CycleTarget(prof, rank, maxRank) end, tip = { L.PLAN_EXPLAIN } })

    -- steps
    local hs = dp:Insert({ header = true, key = "plan-steps", name = L.PLAN_STEPS, countText = tostring(#plan.steps),
        tip = L.PLAN_EXPLAIN })
    for i, st in ipairs(plan.steps) do
        if MatchesSearch(st.recipe, text) then
            hs:Insert({ recipe = st.recipe, learned = st.learned, rank = st.from, suggest = true, place = i,
                planStep = st, entry = { price = P and P.SourceName() and P.Recipe(st.recipe) or nil, recipe = st.recipe } })
        end
    end
    if plan.reached < plan.to then
        hs:Insert({ info = true, text = "|cffff6060" .. string.format(L.PLAN_STUCK, plan.reached) .. "|r",
            detail = "|cffb0b0b0" .. L.PLAN_STUCK_HINT .. "|r" })
    end
    if collapsed["plan-steps"] and text == "" then hs:SetCollapsed(true) end

    -- shopping list + buttons
    local missingN = 0
    for _, e in ipairs(plan.list) do if e.missing > 0 then missingN = missingN + 1 end end
    local hb = dp:Insert({ header = true, key = "plan-shop", name = L.PLAN_SHOPPING, countText = missingN .. "/" .. #plan.list,
        tip = L.PLAN_SHOPPING_EXPLAIN })
    local merchant = PL.MerchantOpen()
    hb:Insert({ info = true, icon = "Interface\\Icons\\INV_Misc_Bag_10",
        text = (merchant and "|cff40c040" or "|cff808080") .. L.PLAN_VENDOR_BTN .. "|r",
        detail = "|cffb0b0b0" .. (merchant and string.format(L.PLAN_VENDOR_DETAIL, P.MoneyPlain(plan.totals.vendor)) or L.PLAN_NO_MERCHANT) .. "|r",
        onClick = merchant and PL.BuyFromVendor or nil })
    local hasSniper = ns.Disenchant.Sniper() ~= nil
    hb:Insert({ info = true, icon = "Interface\\Icons\\Ability_Hunter_SniperShot",
        text = (hasSniper and "|cff40c040" or "|cff808080") .. L.PLAN_SNIPE_BTN .. "|r",
        detail = "|cffb0b0b0" .. (hasSniper and string.format(L.PLAN_SNIPE_DETAIL, PL.TOLERANCE, P.MoneyPlain(plan.totals.ah)) or L.SNIPE_NEED_AHS) .. "|r",
        onClick = hasSniper and PL.ToSniper or nil, tip = { L.PLAN_SNIPE_TIP, " ", L.SNIPE_BUDGET } })
    for _, e in ipairs(plan.list) do
        Yield()
        local name = ns.ItemName(e.id)
        if text == "" or name:lower():find(text, 1, true) then
            local q = ns.ItemQuality(e.id)
            local origin = e.origin == "vendor" and L.ORIGIN_VENDOR or e.origin == "farm" and L.ORIGIN_FARM or L.ORIGIN_AH
            local price = e.known and string.format(L.PER_PIECE, P.MoneyPlain(e.unit)) or L.NO_PRICE
            hb:Insert({ info = true, itemID = e.id, icon = ns.GetItemIcon(e.id),
                buyItem = merchant and e.origin == "vendor" and e.id or nil, buyDefault = math.max(1, e.missing),
                text = "|cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. name .. "|r",
                value = e.missing > 0 and ("|cffff6060" .. string.format(L.PLAN_MISSING, e.missing) .. "|r") or ("|cff40c040" .. L.PLAN_HAVE_ALL .. "|r"),
                detail = "|cffd0c0a0" .. string.format(L.PLAN_ITEM_LINE, e.need, e.have, (ns.Advisor.ORIGIN_ICON[e.origin] or "") .. " " .. origin, price) .. "|r" })
        end
    end
    if collapsed["plan-shop"] and text == "" then hb:SetCollapsed(true) end

    scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
    local line = string.format(L.PLAN_SUMMARY, #plan.steps, plan.from, plan.reached)
    if plan.priced then
        line = line .. "\n" .. string.format(L.PLAN_COST, P.MoneyPlain(plan.cost), P.MoneyPlain(plan.value), AD.NetColored(plan.value - plan.cost))
    end
    summary:SetText(line)
end

---------------------------------------------------------------------------
-- WoW Forever: Merchant's Favor – planner (8.2), favor recipes of this profession with guild view (8.4),
-- crate calculator (8.3)
---------------------------------------------------------------------------
local function RefreshFavor(prof, rank, maxRank, text)
    local F, P = ns.Favor, ns.Prices
    local dp = CreateTreeDataProvider()
    local plan = F.Plan()
    local have = plan.have

    -- 1. planner: wish list and goals
    local hp = dp:Insert({ header = true, key = "favor-plan", name = L.FAVOR_PLAN,
        countText = have and string.format(L.FAVOR_HAVE_SHORT, have) or "", tip = L.FAVOR_PLAN_EXPLAIN })
    if #plan.items == 0 then
        hp:Insert({ info = true, text = "|cffb0b0b0" .. L.FAVOR_PLAN_EMPTY .. "|r" })
    end
    for _, it in ipairs(plan.items) do
        local ok = have and have >= it.n
        hp:Insert({ info = true, icon = it.kind == "recipe" and ns.GetItemIcon(it.ri.id) or "Interface\\Icons\\INV_Misc_Coin_17",
            itemID = it.kind == "recipe" and it.ri.id or nil,
            text = it.name, value = "|cff66ccff" .. it.n .. "|r",
            detail = "|cffb0b0b0" .. (it.kind == "goal" and L[it.goal.need] or L.FAVOR_CLICK_REMOVE) .. "|r",
            onClick = function()
                if it.kind == "recipe" then F.ToggleWish(it.ri.id) else F.ToggleGoal(it.goal.key) end
            end })
    end
    hp:Insert({ info = true, icon = "Interface\\Icons\\INV_Misc_Note_01",
        text = string.format(L.FAVOR_PLAN_TOTAL, plan.total),
        value = plan.total > 0 and (plan.missing > 0 and ("|cffff6060" .. string.format(L.FAVOR_MISSING, plan.missing) .. "|r")
            or ("|cff40c040" .. L.FAVOR_ENOUGH .. "|r")) or "",
        detail = "|cffb0b0b0" .. (have and string.format(L.FAVOR_HAVE_LINE, have) or L.FAVOR_BALANCE_UNKNOWN) .. "|r" })
    for _, g in ipairs(F.GOALS) do
        local on = F.IsGoal(g.key)
        if not on then
            hp:Insert({ info = true, icon = "Interface\\Icons\\INV_Misc_Coin_17",
                text = "|cff808080+ " .. L[g.label] .. "|r", value = "|cff66ccff" .. g.cost .. "|r",
                detail = "|cffb0b0b0" .. L[g.need] .. " · " .. L.FAVOR_GUIDE .. "|r",
                onClick = function() F.ToggleGoal(g.key) end })
        end
    end
    if collapsed["favor-plan"] and text == "" then hp:SetCollapsed(true) end

    -- 2. favor recipes of the open profession (click = on/off the wish list), with the guild view
    local recipes = prof and F.Recipes(prof) or {}
    local hr = dp:Insert({ header = true, key = "favor-recipes", name = string.format(L.FAVOR_RECIPES, prof and ns.ProfName(prof) or "?"),
        countText = tostring(#recipes), tip = L.FAVOR_RECIPES_EXPLAIN })
    if not prof then hr:Insert({ info = true, text = "|cffb0b0b0" .. L.OPEN_PROF_FIRST .. "|r" }) end
    for _, e in ipairs(recipes) do
        Yield()
        local r, ri = e.recipe, e.ri
        if MatchesSearch(r, text) then
            local learned = IsLearned(r)
            local wished = F.IsWished(ri.id)
            local parts = { string.format("%s %d", L.REQ, ri.rs or 0) }
            local rep = ri.fr and ri.fr > 0 and ns.RepInfo(F.Faction(ri.fa), ri.fr)
            if rep then parts[#parts + 1] = rep end
            local g = F.GuildKnows(r)
            if g then
                parts[#parts + 1] = (#g > 0) and (L.GUILD_CRAFTERS .. ": " .. ns.Guild.CraftersText(g, 3)) or ("|cffffd100" .. L.FAVOR_GUILD_NOBODY .. "|r")
            end
            local q = ns.ItemQuality(ri.id)
            hr:Insert({ info = true, itemID = ri.id, icon = ns.GetItemIcon(ri.id),
                text = (wished and "|cffffd100★|r " or "") .. "|cff" .. (learned and "808080" or (ns.QUALITY_HEX[q] or "ffffff")) .. ns.RecipeName(r) .. "|r",
                value = learned and ("|cff40c040" .. L.KNOWN .. "|r") or (e.cost and ("|cff66ccff" .. e.cost.n .. "|r") or "?"),
                detail = "|cffb0b0b0" .. table.concat(parts, " · ") .. "|r",
                tip = { F.CostText(ri) or "", " ", learned and L.KNOWN or (wished and L.FAVOR_WISH_OFF or L.FAVOR_WISH_ON) },
                onClick = (not learned) and function() F.ToggleWish(ri.id) end or nil })
        end
    end
    if collapsed["favor-recipes"] and text == "" then hr:SetCollapsed(true) end

    -- 3. crates: cheapest gold per favor point
    local crates = F.Crates()
    local hc = dp:Insert({ header = true, key = "favor-crates", name = L.FAVOR_CRATES, countText = tostring(#crates), tip = L.FAVOR_CRATES_EXPLAIN })
    hc:Insert({ info = true, icon = "Interface\\Icons\\INV_Misc_Note_01",
        text = L.FAVOR_TODAY_OPTION .. ": " .. (ns.db.todayCrates and "|cff40c040" .. L.ON .. "|r" or "|cff808080" .. L.OFF .. "|r"),
        detail = "|cffb0b0b0" .. L.FAVOR_TODAY_EXPLAIN .. "|r",
        onClick = function() F.ToggleTodayCrates() end })
    for _, c in ipairs(crates) do
        local name = ns.ItemName(c.crate.id)
        if text == "" or name:lower():find(text, 1, true) then
            local q = ns.ItemQuality(c.crate.id)
            local tip = { string.format(L.FAVOR_CRATE_FAVOR, c.favor) .. (c.est and (" " .. L.FAVOR_ESTIMATE) or ""), " ", L.FAVOR_CRATE_BUNDLES }
            local ORIGIN = { vendor = L.ORIGIN_VENDOR, ah = L.ORIGIN_AH, farm = L.ORIGIN_FARM, craft = L.ORIGIN_CRAFT }
            for _, b in ipairs(c.bundles) do
                tip[#tip + 1] = { string.format("%d× %s%s", b.count, ns.ItemName(b.id), b.enough and " |cff40c040✓|r" or ""),
                    b.known and (P.MoneyPlain(b.cost) .. " |cff9d9d9d(" .. (ORIGIN[b.origin] or "?") .. ")|r") or L.NO_PRICE }
            end
            tip[#tip + 1] = { L.FAVOR_CRATE_AH, c.crateAH and P.MoneyPlain(c.crateAH) or L.NO_PRICE }
            local detail
            if c.best then
                detail = string.format(L.FAVOR_CRATE_BEST, c.best.count, ns.ItemName(c.best.id), P.MoneyPlain(c.best.cost))
                if c.inBags == 0 and c.crateAH then detail = detail .. " + " .. string.format(L.FAVOR_CRATE_PLUS_AH, P.MoneyPlain(c.crateAH)) end
            else
                detail = L.NO_PRICE
            end
            if c.ready then detail = "|cff40c040" .. string.format(L.FAVOR_CRATE_READY, c.ready.count, ns.ItemName(c.ready.id)) .. "|r · " .. detail end
            hc:Insert({ info = true, itemID = c.crate.id, icon = ns.GetItemIcon(c.crate.id),
                text = (c.inBags > 0 and ("|cff40c040" .. c.inBags .. "×|r ") or "") .. "|cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. name .. "|r",
                value = c.perFavor and ("|cffd0c0a0" .. string.format(L.FAVOR_PER_POINT, P.MoneyPlain(c.perFavor)) .. "|r")
                    or ("|cff66ccff" .. c.favor .. "|r"),
                detail = "|cffb0b0b0" .. string.format(L.FAVOR_CRATE_GIVES, c.favor) .. (c.est and "*" or "") .. " · " .. detail .. "|r",
                tip = tip })
        end
    end
    if collapsed["favor-crates"] and text == "" then hc:SetCollapsed(true) end

    scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
    local src = P and P.SourceName()
    summary:SetText((have and string.format(L.FAVOR_HAVE_LINE, have) or L.FAVOR_BALANCE_UNKNOWN) .. "\n"
        .. (src and string.format(L.PRICE_SOURCE, src) or L.PRICE_NONE))
end

local QUALITY_WORD = { [2] = "DE_Q2", [3] = "DE_Q3", [4] = "DE_Q4" }

local function GroupTitle(g)
    local q = L[QUALITY_WORD[g.quality] or "DE_Q2"]
    local kind = g.quality == 2 and (" · " .. (g.weapon and L.DE_WEAPON or L.DE_ARMOR)) or ""
    return "|cff" .. (ns.QUALITY_HEX[g.quality] or "ffffff") .. q .. "|r" .. kind .. " · " .. string.format(L.DE_ILVL, g.from or 0, g.to or 0)
end

local function RefreshDisenchant(prof, rank, maxRank, text)
    local DE = ns.Disenchant
    local AD = ns.Advisor
    local P = ns.Prices
    local dp = CreateTreeDataProvider()
    local hasAHS = DE and DE.AHS() ~= nil
    local wantsGold, wantsSell = DE.WantsGold(), DE.WantsSell()

    -- goal of this enchanter (click to change)
    local goal = DE.Goal()
    local hg = dp:Insert({ header = true, key = "de-goal", name = L.GOAL_HEADER, countText = "" })
    hg:Insert({ info = true, icon = "Interface\\Icons\\Trade_Engraving",
        text = string.format(L.GOAL_CURRENT, L["GOAL_" .. goal:upper()]),
        detail = "|cffb0b0b0" .. L.GOAL_CLICK .. "|r", onClick = DE.AskGoal,
        tip = { L.GOAL_QUESTION, " ", L.GOAL_GOLD .. ": " .. L.GOAL_GOLD_TIP, L.GOAL_SELL .. ": " .. L.GOAL_SELL_TIP, L.GOAL_BOTH .. ": " .. L.GOAL_BOTH_TIP } })

    -- selling enchants: material cost of every learned enchant
    if wantsSell then
        local list = {}
        for _, id in ipairs(DE.EnchantProfs()) do
            for _, r in ipairs(ns.ByProf[id] or {}) do
                if ns.IsLearned(r) and r.ench and r.reagents and #r.reagents > 0 then list[#list + 1] = r end
            end
        end
        table.sort(list, function(a, b)
            if (a.yellow or 0) ~= (b.yellow or 0) then return (a.yellow or 0) > (b.yellow or 0) end
            return (a.name or "") < (b.name or "")
        end)
        local hs = dp:Insert({ header = true, key = "de-sell", name = L.SELL_GROUP, countText = tostring(#list), tip = L.SELL_EXPLAIN })
        for _, r in ipairs(list) do
            Yield()
            if MatchesSearch(r, text) then
                local erank = ns.Scan and ns.Scan:Rank(r.prof) or rank
                hs:Insert({ recipe = r, learned = true, rank = erank, suggest = true, sell = true,
                    entry = { price = P.Recipe(r), recipe = r } })
            end
        end
        if collapsed["de-sell"] and text == "" then hs:SetCollapsed(true) end
        -- your wish for the selling price
        hg:Insert({ info = true, icon = "Interface\\Icons\\INV_Misc_Coin_02",
            text = string.format(L.VZ_MARKUP_ROW, ns.db.vzMarkup or 20), detail = "|cffb0b0b0" .. L.GOAL_CLICK .. "|r",
            onClick = DE.EditMarkup, tip = { L.VZ_PRICE_EXPLAIN } })
        hg:Insert({ info = true, icon = "Interface\\Icons\\INV_Misc_Coin_01",
            text = string.format(L.VZ_MIN_ROW, P.MoneyPlain(ns.db.vzMinProfit or 0)), detail = "|cffb0b0b0" .. L.GOAL_CLICK .. "|r",
            onClick = DE.EditMinProfit, tip = { L.VZ_PRICE_EXPLAIN } })
    end

    if not wantsGold then
        scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
        summary:SetText(L.SELL_SUMMARY .. "\n" .. UI.PriceLine())
        return
    end

    -- minimum margin and the sniper buttons (AHSentinel)
    local hm = dp:Insert({ header = true, key = "de-sniper", name = L.SNIPE_HEADER, countText = "", tip = L.SNIPE_EXPLAIN })
    hm:Insert({ info = true, icon = "Interface\\Icons\\INV_Misc_Coin_02",
        text = string.format(L.DE_MARGIN_ROW, ns.db.deMargin or 20), detail = "|cffb0b0b0" .. L.GOAL_CLICK .. "|r",
        onClick = DE.EditMargin, tip = { L.DE_MARGIN_EXPLAIN } })
    local hasSniper = DE.Sniper() ~= nil
    hm:Insert({ info = true, icon = "Interface\\Icons\\Ability_Hunter_SniperShot",
        text = (hasSniper and "|cff40c040" or "|cff808080") .. L.SNIPE_ITEMS_BTN .. "|r",
        detail = "|cffb0b0b0" .. (hasSniper and L.SNIPE_ITEMS_DETAIL or L.SNIPE_NEED_AHS) .. "|r",
        onClick = hasSniper and DE.SnipeDeals or nil, tip = { L.SNIPE_ITEMS_TIP, " ", L.SNIPE_BUDGET } })
    hm:Insert({ info = true, icon = "Interface\\Icons\\INV_Fabric_Linen_01",
        text = (hasSniper and "|cff40c040" or "|cff808080") .. L.SNIPE_MATS_BTN .. "|r",
        detail = "|cffb0b0b0" .. (hasSniper and string.format(L.SNIPE_MATS_DETAIL, DE.SNIPE_RECIPES, DE.SNIPE_CRAFTS) or L.SNIPE_NEED_AHS) .. "|r",
        onClick = hasSniper and DE.SnipeReagents or nil, tip = { L.SNIPE_MATS_TIP, " ", L.SNIPE_BUDGET } })
    if collapsed["de-sniper"] and text == "" then hm:SetCollapsed(true) end

    -- 1. Bargains in the AH (from AHSentinel's latest prices)
    local deals = hasAHS and DE.Deals(30) or nil
    local h1 = dp:Insert({ header = true, key = "de-deals", name = L.DE_DEALS, countText = deals and tostring(#deals) or "–",
        tip = hasAHS and L.DE_DEALS_EXPLAIN or L.DE_NEED_AHS })
    for _, d in ipairs(deals or {}) do
        Yield()
        local name = ns.ItemName(d.itemID)
        if d.name and d.name ~= "" and name:find("^Item ") then name = d.name end
        if text == "" or name:lower():find(text, 1, true) then
            local q = ns.ItemQuality(d.itemID)
            h1:Insert({ info = true, itemID = d.itemID, icon = ns.GetItemIcon(d.itemID),
                text = "|cff" .. (ns.QUALITY_HEX[q] or "ffffff") .. name .. "|r" .. ((d.quantity or 1) > 1 and (" |cffb0b0b0×" .. d.quantity .. "|r") or ""),
                value = AD.NetColored(d.profit),
                detail = "|cffd0c0a0" .. string.format(L.DE_DEAL_LINE, P.MoneyPlain(d.price), P.MoneyPlain(d.net)) .. "|r",
                tip = { " ", { L.DE_DEAL_PRICE, P.Money(d.price) }, { L.DE_VALUE, P.Money(d.value) },
                        { L.DE_NETVALUE, P.Money(d.net) }, { L.NET_DE, AD.NetColored(d.profit) } } })
        end
    end
    if collapsed["de-deals"] and text == "" then h1:SetCollapsed(true) end

    -- 2. Craft & disenchant over all professions of this character
    local de = AD and AD.current.de or {}
    local h2 = dp:Insert({ header = true, key = "de-craft", name = L.DE_GROUP, countText = tostring(#de),
        tip = #de > 0 and L.DE_EXPLAIN or L.DE_NONE })
    for _, e in ipairs(de) do
        Yield()
        if MatchesSearch(e.recipe, text) then
            h2:Insert({ recipe = e.recipe, learned = e.learned, rank = rank, suggest = true, de = true,
                place = e.dePlace, entry = e })
        end
    end
    if collapsed["de-craft"] and text == "" then h2:SetCollapsed(true) end

    -- 3. Drop chances: learned (own + shared) against the starting values
    local groups = hasAHS and DE.Groups() or nil
    local h3 = dp:Insert({ header = true, key = "de-chances", name = L.DE_CHANCES, countText = groups and tostring(#groups) or "–",
        tip = hasAHS and L.DE_CHANCES_EXPLAIN or L.DE_NEED_AHS })
    if groups and #groups == 0 then
        h3:Insert({ info = true, text = "|cffb0b0b0" .. L.DE_NO_RESULTS .. "|r", detail = "|cffb0b0b0" .. L.DE_START_VALUES .. "|r" })
    end
    for _, g in ipairs(groups or {}) do
        Yield()
        local parts, tip = {}, { GroupTitle(g), " " }
        for _, row in ipairs(g.rows) do
            local nm = ns.ItemName(row.id)
            parts[#parts + 1] = string.format("%s %d%%", nm, math.floor(row.chance * 100 + 0.5))
            tip[#tip + 1] = { "|T" .. ns.GetItemIcon(row.id) .. ":0|t " .. nm,
                string.format(L.DE_CHANCE_VS, math.floor(row.chance * 100 + 0.5), math.floor(row.prior * 100 + 0.5), AD.Num1(row.avg)) }
        end
        tip[#tip + 1] = " "
        tip[#tip + 1] = string.format(L.DE_BASED_ON, g.own, g.shared)
        if text == "" or table.concat(parts, " "):lower():find(text, 1, true) then
            h3:Insert({ info = true, icon = ns.GetItemIcon(g.rows[1] and g.rows[1].id or 10940), text = GroupTitle(g),
                value = "|cffb0b0b0" .. string.format(L.DE_COUNT, g.own + g.shared) .. "|r",
                detail = "|cffd0c0a0" .. table.concat(parts, " · ") .. "|r", tip = tip })
        end
    end
    if collapsed["de-chances"] and text == "" then h3:SetCollapsed(true) end

    scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
    if hasAHS then
        local own, shared, players = DE.Totals()
        summary:SetText(string.format(L.DE_SUMMARY, own or 0, shared or 0, players or 0) .. "\n" .. L.DE_SOURCE_AHS)
    else
        summary:SetText(L.DE_SUMMARY_NOAHS)
    end
end

local function TrainerMatches(id, text)
    if text == "" then return true end
    local n = ns.NPCs[id]
    if not n then return false end
    local hay = ((n[1] or "") .. " " .. (n[4] or "") .. " " .. (ns.Waypoint.ZoneName(n) or "")):lower()
    return hay:find(text, 1, true) ~= nil
end

local function RefreshTrainers(prof, rank, maxRank, text)
    local WP = ns.Waypoint
    local dp = CreateTreeDataProvider()
    local list = (ns.Trainers and ns.Trainers[prof]) or {}
    local groups = {}
    for _, e in ipairs(list) do
        local id, rk = e[1], e[2]
        if TrainerMatches(id, text) then
            groups[rk] = groups[rk] or {}
            table.insert(groups[rk], id)
        end
    end
    local next = WP.NextRank(rank, maxRank)
    local pc, px, py = WP.PlayerPos()
    for _, rk in ipairs(WP.RANKS) do
        local ids = groups[rk.key]
        if ids and #ids > 0 then
            -- friendly trainers first, then the nearest (same continent), then by name (before 0.9.49 only by name)
            local dist = {}
            for _, id in ipairs(ids) do dist[id] = WP.Distance(id, pc, px, py) or math.huge end
            table.sort(ids, function(a, b)
                local fa, fb = WP.IsFriendly(a) or ns.NPCs[a][3] == nil, WP.IsFriendly(b) or ns.NPCs[b][3] == nil
                if fa ~= fb then return fa end
                if dist[a] ~= dist[b] then return dist[a] < dist[b] end
                return (ns.NPCs[a][1] or "") < (ns.NPCs[b][1] or "")
            end)
            local friendlyCount = 0
            for _, id in ipairs(ids) do if WP.IsFriendly(id) or ns.NPCs[id][3] == nil then friendlyCount = friendlyCount + 1 end end
            local title = L["RANK_" .. rk.key] or L.RANK_0
            if next and next.key == rk.key then title = "|cff40c040>> |r" .. title end
            local header = dp:Insert({
                header = true, key = "trainer-" .. rk.key, name = title,
                countText = friendlyCount .. "/" .. #ids,
                tip = rk.req and string.format(L.RANK_REQ, rk.req, rk.level) or nil,
            })
            for _, id in ipairs(ids) do header:Insert({ npc = id, rankKey = rk.key, dist = dist[id] ~= math.huge and dist[id] or nil }) end
            if collapsed["trainer-" .. rk.key] and text == "" then header:SetCollapsed(true) end
        end
    end
    scrollBox:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition)
    local line
    if next and rank then
        local rankName = (L["RANK_" .. next.key] or ""):gsub("%s*–.*$", "")  -- "Fachmann – bis 300" -> "Fachmann"
        line = string.format(L.NEXT_RANK, rankName, next.req, next.level, rank, maxRank or 0)
    elseif rank and maxRank and maxRank > 0 then
        line = string.format(L.MAX_RANK, rank, maxRank)
    else
        line = ""
    end
    if prof == 185 or prof == 129 or prof == 356 then line = line .. (line ~= "" and "\n" or "") .. L.SECONDARY_NOTE end
    local nt = WP.NextTrainerLine(prof, rank, maxRank)
    if nt then line = line .. (line ~= "" and "\n" or "") .. nt end
    summary:SetText(line)
end

-- Best recipe: recomputed on every refresh (also when the panel is closed), shown on the
-- profession window hint and as a star in the Blizzard list.
local bestHints = {}

-- width of the "Best:" line: from the left edge of the profession window to the button (cut only there)
UI.BEST_MARGIN = 12
function UI.BestHintWidth(hostLeft, buttonLeft)
    if not (hostLeft and buttonLeft) then return 340 end
    return math.max(120, buttonLeft - hostLeft - 8 - UI.BEST_MARGIN)
end
-- PS-DW1 (AHSentinel 0.65.170, user 15 Nov. 17:05): the line used to be as wide as the space up to the left edge of the
-- profession window – an invisible part of it lay over AHSentinel's button "Entzaubern (n)" bottom left and took its
-- clicks. Now the clickable area is only as wide as the text (at most the space available).
function UI.FitBestHint(b)
    local host, btn = b.host, b.button
    local w = UI.BestHintWidth(host and host.GetLeft and host:GetLeft(), btn and btn.GetLeft and btn:GetLeft())
    b:SetWidth(w)
    local tw = b.text and b.text.GetStringWidth and b.text:GetStringWidth()
    if type(tw) == "number" and tw > 0 then b:SetWidth(math.min(w, math.ceil(tw) + 4)) end
end

function UI:UpdateBest()
    local AD = ns.Advisor
    if not AD then return end
    local host = currentHost
    -- Era: the enchanting window has its own skill line
    if ns.IsEra and CraftFrame and CraftFrame:IsShown() then currentHost = CraftFrame
    elseif ns.IsEra and not currentHost and TradeSkillFrame and TradeSkillFrame:IsShown() then currentHost = TradeSkillFrame end
    local prof, rank = CurrentProfession()
    AD.UpdateCached(prof, rank)
    for _, b in pairs(bestHints) do
        local e = AD.current.bestLearned
        local top = AD.current.best
        if ns.db.best == false or not prof then
            b:Hide()
        elseif e then
            -- short (UI rework U6): "Best: <recipe>" – everything else is in the panel; cut with "…" only at the
            -- width of the window
            b.text:SetText(string.format(L.BEST_SHORT, "|cffffffff" .. ns.RecipeName(e.recipe) .. "|r"))
            UI.FitBestHint(b)
            b:Show()
        elseif top then
            -- nothing learned gives points: the best recipe to learn
            b.text:SetText(string.format(L.BEST_SHORT, "|cff3fc7eb" .. L.TAG_LEARN .. "|r |cffffffff" .. ns.RecipeName(top.recipe) .. "|r"))
            UI.FitBestHint(b)
            b:Show()
        else
            b:Hide()
        end
    end
    currentHost = host
end

-- Rows: left click on press (a rebuild between press and release can no longer swallow it), right click on release
UI.ROW_CLICKS = { "LeftButtonDown", "RightButtonUp" }

local DoRefresh                 -- forward (the panel content below)

-- Profession events come in bursts (TRADE_SKILL_LIST_UPDATE many times per second). Rebuilding the list each time
-- swallowed clicks. So they are collected and the panel is rebuilt at most once per REFRESH_DELAY seconds.
--
-- Crafting (review 9 Nov., Spieltest S7 "3 LANGSAM", diagnostic log: UI:Refresh up to 131 ms per crafted item):
--  * while crafting (UI.CRAFT_WINDOW seconds after an own craft) a request does NOT rebuild the list: only the
--    counters of the visible rows are brought up to date (skill, "N× to yellow", bags) – UI.UpdateVisibleRows;
--  * a real change (skill point, learned recipe) rebuilds at most once per UI.CRAFT_MIN_GAP seconds;
--  * when crafting ends, the list is rebuilt once;
--  * an event rebuild runs in portions over several frames (UI.FRAME_BUDGET ms of work per frame, coroutine),
--    nothing is shown before it is complete. A direct refresh (click, tab, search) runs at once as before and
--    cancels a running portioned rebuild.
UI.REFRESH_DELAY = 0.5
UI.CRAFT_WINDOW = 3          -- seconds after an own craft that count as "crafting"
UI.CRAFT_MIN_GAP = 2         -- while crafting: at most one rebuild per 2 s
UI.FRAME_BUDGET = 10         -- ms of rebuild work per frame
local refreshPending = false
local pendingEvent, pendingCount, pendingFull = nil, 0, false     -- diagnostic log: trigger and number of requests
local craftUntil, lastBuildAt, afterCraft = 0, nil, false
local buildCo, buildGen, sliceStart = nil, 0, nil

function UI.Now() return (GetTime and GetTime()) or 0 end
function UI.Crafting() return UI.Now() < craftUntil end

-- the rebuild coroutine is running (inner time measurements over several frames are not "slow")
function UI.InBuild() return buildCo ~= nil and coroutine.running() == buildCo end

-- inside a portioned rebuild: hand the rest of the work to the next frame when this frame's budget is used up.
-- Only called from code that runs directly in the rebuild (no pcall in between: Lua 5.1 cannot yield across it).
function UI.Yield()
    if not (buildCo and coroutine.running() == buildCo) then return end
    local t = ns.DiagClock and ns.DiagClock()
    if t and sliceStart and t - sliceStart >= UI.FRAME_BUDGET then coroutine.yield() end
end

local function After(sec, fn)
    if ns.API.TimerAfter then ns.API.TimerAfter(sec, fn) else fn() end
end

-- an own craft (UNIT_SPELLCAST_SUCCEEDED of a known recipe)
function UI.NoteCraft()
    craftUntil = UI.Now() + UI.CRAFT_WINDOW
    UI.crafts = (UI.crafts or 0) + 1
    -- when crafting ends: one rebuild, if something was held back
    After(UI.CRAFT_WINDOW + 0.05, function()
        if afterCraft and not UI.Crafting() then
            afterCraft = false
            UI.RequestRefresh("Herstellen fertig", true)
        end
    end)
end

-- only the counters of the visible rows (no rebuild): the row's skill is brought up to date and the row drawn again
function UI.UpdateVisibleRows()
    if not (scrollBox and scrollBox.ForEachFrame and panel and panel:IsShown()) then return 0 end
    local t0 = ns.DiagClock and ns.DiagClock()
    local _, rank = CurrentProfession()
    local n = 0
    scrollBox:ForEachFrame(function(f)
        local node = f.psNode
        local data = node and node.GetData and node:GetData()
        if data and not data.header then
            if data.recipe and data.rank ~= nil then
                data.rank = (ns.Scan and ns.Scan.Rank and ns.Scan:Rank(data.recipe.prof)) or rank or data.rank
            end
            InitRow(f, node)
            n = n + 1
        end
    end)
    UI.rowRuns = (UI.rowRuns or 0) + 1
    if t0 and ns.DiagSlow then ns.DiagSlow("UI:Zeilen", t0) end
    return n
end

-- one portion of the rebuild; the next one follows in the next frame
local function Step(gen, info)
    if gen ~= buildGen or not buildCo then return end      -- cancelled by a direct refresh
    local P = ns.Prices
    if P and P.BeginPass then P.BeginPass() end            -- memo per portion (nothing stale across frames)
    sliceStart = ns.DiagClock and ns.DiagClock()
    local ok, err = coroutine.resume(buildCo)
    local t1 = ns.DiagClock and ns.DiagClock()
    if P and P.EndPass then P.EndPass() end
    local ms = (sliceStart and t1) and (t1 - sliceStart) or 0
    info.slices, info.ms, info.max = info.slices + 1, info.ms + ms, math.max(info.max, ms)
    if sliceStart and ns.DiagSlow then ns.DiagSlow("UI:Aufbau (Teil)", sliceStart) end
    if ns.PerfNote then ns.PerfNote("Neuaufbau (Teil)", ms) end      -- A4: highest portion per path
    sliceStart = nil
    if gen ~= buildGen then return end
    if not ok then
        buildCo = nil
        if ns.CountError then ns.CountError("UI:Aufbau", err) end
        return
    end
    if coroutine.status(buildCo) ~= "dead" then
        After(0, function() Step(gen, info) end)
        return
    end
    buildCo = nil
    UI.lastBuild = info
    if ns.Lifeline then ns.Lifeline.RefreshBlizzard() end
    if ns.Diagnose then pcall(ns.Diagnose.Build, info.event or "-", info.count, info.ms) end
end

-- 3.1b profession switch: the view of the NEW profession at once – from the cache of its last complete build (or an empty
-- list), never the old profession's content while the portioned rebuild runs; fresh numbers follow in portions.
UI.viewCache = {}       -- "prof|mode" -> { dp, summary } (only complete builds without a search text)
function UI.ShowCachedFor()
    if not (panel and panel:IsShown()) then return false end
    local t0 = ns.DiagClock and ns.DiagClock()
    local prof, rank, maxRank = CurrentProfession()
    if not prof or prof == UI.shownProf then return false end
    UI.NoteProfession(prof)
    local m = Mode()
    local c = UI.viewCache[prof .. "|" .. m]
    UpdateTabs()
    local skillText = rank and (tostring(rank) .. ((maxRank and maxRank > 0) and ("/" .. maxRank) or "")) or ""
    panel:SetTitle(ns.ProfName(prof) .. (skillText ~= "" and (" " .. skillText) or ""))
    scrollBox:SetDataProvider(c and c.dp or CreateTreeDataProvider())
    summary:SetText(c and c.summary or "")
    UI.shownProf = prof
    UI.switches = (UI.switches or 0) + 1
    if t0 and ns.Perf then ns.Perf("Berufswechsel (sofort)", t0) end
    return true, c ~= nil
end

function UI.StartBuild(event, count)
    UI.ShowCachedFor()
    buildGen = buildGen + 1
    UI.refreshRuns = (UI.refreshRuns or 0) + 1
    lastBuildAt = UI.Now()
    local info = { event = event, count = count, slices = 0, ms = 0, max = 0, gen = buildGen, at = lastBuildAt }
    UI.buildLog = UI.buildLog or {}
    UI.buildLog[#UI.buildLog + 1] = info
    if #UI.buildLog > 50 then table.remove(UI.buildLog, 1) end
    buildCo = coroutine.create(function() UI:Refresh() end)      -- inside the build: UI:Refresh draws directly
    Step(buildGen, info)
    return info
end

function UI.Building() return buildCo ~= nil end

function UI.RunPendingRefresh()
    refreshPending = false
    local event, count, full = pendingEvent, pendingCount, pendingFull
    if UI.Crafting() then
        if not full then
            -- crafting, nothing real changed: only the counters of the visible rows; the rebuild comes afterwards
            pendingEvent, pendingCount = nil, 0
            afterCraft = true
            UI.UpdateVisibleRows()
            if ns.Lifeline then ns.Lifeline.RefreshBlizzard() end
            return
        end
        local wait = lastBuildAt and (lastBuildAt + UI.CRAFT_MIN_GAP - UI.Now()) or 0
        if wait > 0 then
            -- too soon after the last rebuild: counters now, the rebuild later
            refreshPending = true
            UI.UpdateVisibleRows()
            After(wait, function() UI.RunPendingRefresh() end)
            return
        end
    end
    pendingEvent, pendingCount, pendingFull = nil, 0, false
    UI.StartBuild(event, count)
end

-- event: name of the trigger (profession event), for the diagnostic log only; full: data really changed
function UI.RequestRefresh(event, full)
    UI.refreshRequests = (UI.refreshRequests or 0) + 1
    pendingCount = pendingCount + 1
    if full then pendingFull = true end
    if not pendingEvent then pendingEvent = event end
    if refreshPending then return end
    refreshPending = true
    if ns.API.TimerAfter then
        ns.API.TimerAfter(UI.REFRESH_DELAY, function() UI.RunPendingRefresh() end)
    else
        UI.RunPendingRefresh()
    end
end

-- drawn at once (whole) only while the test routine runs: its cases read the panel right after UI:Refresh
function UI.SyncRefresh()
    local TR = ns.TestRoutine
    return UI.SYNC == true or (TR and TR.Running and TR.Running()) or false
end

function UI:Refresh()
    if UI.InBuild() then return DoRefresh(self) end
    -- a direct refresh (click, tab, search, settings) replaces a running portioned rebuild; it is portioned as well
    -- (review 0.9.38, point 1a): the first portion runs at once in this frame – usually the whole work –, the rest
    -- follows in the next frames
    if buildCo then buildCo = nil; buildGen = buildGen + 1 end
    if not UI.SyncRefresh() and ns.API.TimerAfter then
        UI.StartBuild("direkt", 1)
        return
    end
    local t0 = ns.DiagClock and ns.DiagClock()
    if ns.Prices and ns.Prices.InPass then ns.Prices.InPass(DoRefresh, self) else DoRefresh(self) end
    if t0 and ns.DiagSlow then ns.DiagSlow("UI:Refresh", t0) end
end

DoRefresh = function(self)
    local tb = ns.DiagClock and ns.DiagClock()
    self:UpdateBest()
    if tb and ns.DiagSlow then ns.DiagSlow("UI:UpdateBest", tb) end      -- the protocol shows which part is slow
    if not panel or not panel:IsShown() then return end
    if UI.CheckDock then UI.CheckDock() end      -- AHSentinel's window may have appeared since the last docking
    if ns.Spieltest and ns.Spieltest.IsOn() then pcall(ns.Spieltest.OnDock) end
    UpdateTabs()
    testBadge:SetShown(ns.Sim ~= nil and (ns.Sim.rank ~= nil or ns.Sim.known ~= nil or ns.Sim.prof ~= nil))
    local prof, rank, maxRank = CurrentProfession()
    if not prof then
        panel:SetTitle(L.TITLE)
        summary:SetText(L.OPEN_PROF_FIRST)
        scrollBox:SetDataProvider(CreateTreeDataProvider())
        return
    end
    UI.NoteProfession(prof)
    local m = Mode()
    UpdateTabs()
    -- the head line always says for which profession and skill the numbers are ("Schneiderei 110/150")
    local skillText = rank and (tostring(rank) .. ((maxRank and maxRank > 0) and ("/" .. maxRank) or "")) or ""
    panel:SetTitle(ns.ProfName(prof) .. (skillText ~= "" and (" " .. skillText) or "") .. (m == "trainers" and (" – " .. L.TRAINERS) or m == "ranking" and (" – " .. L.RANKING_TAB)
        or m == "disenchant" and (" – " .. L.DE_TAB) or m == "plan" and (" – " .. L.PLAN_TAB)
        or m == "favor" and (" – " .. L.FAVOR_TAB) or m == "gold" and (" – " .. L.TAB_GOLD) or ""))
    local text = (searchBox:GetText() or ""):lower()
    local tm = ns.DiagClock and ns.DiagClock()
    if m == "now" then
        RefreshNow(prof, rank, maxRank, text)
    elseif m == "trainers" then
        RefreshTrainers(prof, rank, maxRank, text)
    elseif m == "plan" then
        RefreshPlan(prof, rank, maxRank, text)
    elseif m == "favor" and ns.Favor and ns.Favor.Active() then
        RefreshFavor(prof, rank, maxRank, text)
    elseif m == "disenchant" and ns.Disenchant and ns.Disenchant.IsEnchanter() then
        RefreshDisenchant(prof, rank, maxRank, text)
    elseif m == "gold" then
        RefreshGold(prof, rank, maxRank, text)
    elseif m == "ranking" then
        RefreshRanking(prof, rank, maxRank, text)
        if ns.Spieltest and ns.Spieltest.IsOn() then pcall(ns.Spieltest.OnRanking) end
    else
        RefreshRecipes(prof, rank, maxRank, text)
    end
    if tm and ns.DiagSlow then ns.DiagSlow("UI:Refresh/" .. tostring(m), tm) end
    -- a complete build: remembered for the next switch to this profession (3.1b)
    UI.shownProf = prof
    if text == "" then
        UI.viewCache[prof .. "|" .. m] = { dp = scrollBox:GetDataProvider(), summary = summary:GetText() }
    end
end

function UI:SetMode(mode)
    ns.db.panelMode = mode
    ns.db.groupMode = ns.db.groupMode or {}
    ns.db.groupMode[UI.GroupOfMode(mode)] = mode
    -- per profession the last tab (3.1b: cooking -> Skill up, tailoring -> Gold)
    local prof = UI.lastProf
    if prof then
        if type(ns.db.profTab) ~= "table" then ns.db.profTab = {} end
        ns.db.profTab[prof] = mode
    end
    self:Refresh()
end

-- the style: dark (default) or classic
function UI.Dark() return not (ns.db and ns.db.theme == "classic") end
function UI.ApplyTheme()
    if not (panel and panel.psDark) then return end
    panel.psDark:SetShown(UI.Dark())
end
function UI.ToggleTheme()
    ns.db.theme = UI.Dark() and "classic" or nil
    UI.ApplyTheme()
    ns.Print(L.OPT_THEME .. ": " .. ns.OnOffText(UI.Dark()))
end

-- opens with the profession window (default on; 3.1b)
function UI.AutoOpen() return not (ns.db and ns.db.autoOpen == false) end
function UI.ToggleAutoOpen()
    if UI.AutoOpen() then ns.db.autoOpen = false else ns.db.autoOpen = nil end
    ns.Print(L.OPT_AUTOOPEN .. ": " .. ns.OnOffText(UI.AutoOpen()))
end

-- profession switch: the tab used last with this profession (in the game; the test routine sets its tab itself)
function UI.NoteProfession(prof)
    if prof == UI.lastProf then return end
    UI.lastProf = prof
    local TR = ns.TestRoutine
    if TR and TR.IsRunning and TR:IsRunning() and not UI.profMemoryTest then return end
    local t = type(ns.db.profTab) == "table" and ns.db.profTab[prof]
    if type(t) == "string" and UI.MODE_GROUP[t] then ns.db.panelMode = t end
end

---------------------------------------------------------------------------
-- Panel
---------------------------------------------------------------------------
local function CreatePanel()
    panel = CreateFrame("Frame", "ProfessionSentinelPanel", UIParent, "ButtonFrameTemplate")
    if ns.RegisterUI then ns.RegisterUI(panel, "ProfessionSentinel-Panel") end      -- Bereich K der Testroutine
    panel:SetWidth(PANEL_WIDTH)
    panel:SetHeight(560)
    panel:SetFrameStrata("HIGH")
    panel:SetClampedToScreen(true)
    if ButtonFrameTemplate_HidePortrait then ButtonFrameTemplate_HidePortrait(panel) end
    if ButtonFrameTemplate_HideButtonBar then ButtonFrameTemplate_HideButtonBar(panel) end
    panel:SetTitle(L.TITLE)
    panel:Hide()
    -- dark flat style like AHSentinel (option; the classic Blizzard look stays: /ps stil)
    panel.psDark = panel:CreateTexture(nil, "BACKGROUND", nil, 7)
    panel.psDark:SetPoint("TOPLEFT", panel, "TOPLEFT", 3, -22)
    panel.psDark:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -3, 3)
    panel.psDark:SetColorTexture(0.06, 0.07, 0.09, 0.97)
    UI.ApplyTheme()
    if panel.CloseButton then
        panel.CloseButton:SetScript("OnClick", function()
            panel:Hide()      -- closed for now; it opens again with the profession window (option)
        end)
    end

    testBadge = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    testBadge:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -30, -6)
    testBadge:SetText("|cffff4040" .. L.TEST_ACTIVE .. "|r")
    testBadge:Hide()

    -- the four tabs (UI rework 2): real tabs with an accent line, one level; the views of a tab are a small switch below
    UI.mainTabs = {}
    for i, g in ipairs(UI.TAB_ORDER) do
        local b = UI.FlatButton(panel, 96, 24)
        b.group = g
        b.label = (g == "now" and L.TAB_NOW) or (g == "recipes" and L.TAB_RECIPES) or (g == "skill" and L.TAB_SKILL) or L.TAB_GOLD
        if i == 1 then b:SetPoint("TOPLEFT", panel, "TOPLEFT", 12, -26)
        else b:SetPoint("LEFT", UI.mainTabs[i - 1], "RIGHT", 4, 0) end
        b:SetScript("OnClick", function()
            local m = Mode()
            if UI.GroupOfMode(m) == g and g ~= "recipes" then return end       -- already there: keep the view
            local last = ns.db.groupMode and ns.db.groupMode[g]
            UI:SetMode((last and UI.MODE_GROUP[last] == g) and last or UI.GROUP_DEFAULT[g])
        end)
        UI.mainTabs[i] = b
    end
    UI.filterButtons = {}
    for i, k in ipairs({ "all", "learned", "learnable", "missing" }) do
        local b = UI.FlatButton(panel, 58, 20, true)
        b.key = k
        b.label = (k == "all" and L.F_ALL) or (k == "learned" and L.F_LEARNED) or (k == "learnable" and L.F_LEARNABLE) or L.F_MISSINGSHORT
        b:SetScript("OnClick", function() UI.ClickFilter(k) end)
        b:Hide()
        UI.filterButtons[i] = b
    end
    tabGoldList = UI.FlatButton(panel, 76, 20, true)
    tabGoldList:SetSize(100, 22)
    tabGoldList:SetScript("OnClick", function() UI:SetMode("gold") end)
    tabGoldList:Hide()

    tabRecipes = UI.FlatButton(panel, 76, 20, true)
    tabRecipes:SetSize(76, 22)
    tabRecipes:SetPoint("TOPLEFT", panel, "TOPLEFT", 12, -26)
    tabRecipes:SetScript("OnClick", function() UI:SetMode("recipes") end)
    tabRanking = UI.FlatButton(panel, 76, 20, true)
    tabRanking:SetSize(76, 22)
    tabRanking:SetPoint("LEFT", tabRecipes, "RIGHT", 4, 0)
    tabRanking:SetScript("OnClick", function() UI:SetMode("ranking") end)
    tabTrainers = UI.FlatButton(panel, 76, 20, true)
    tabPlan = UI.FlatButton(panel, 76, 20, true)
    tabPlan:SetSize(76, 22)
    tabPlan:SetPoint("LEFT", tabRanking, "RIGHT", 4, 0)
    tabPlan:SetScript("OnClick", function() UI:SetMode("plan") end)
    tabTrainers:SetSize(76, 22)
    tabTrainers:SetPoint("LEFT", tabPlan, "RIGHT", 4, 0)
    tabTrainers:SetScript("OnClick", function() UI:SetMode("trainers") end)
    tabDisenchant = UI.FlatButton(panel, 76, 20, true)
    tabDisenchant:SetSize(76, 22)
    tabDisenchant:SetPoint("LEFT", tabTrainers, "RIGHT", 4, 0)
    tabDisenchant:SetScript("OnClick", function() UI:SetMode("disenchant") end)
    tabFavor = UI.FlatButton(panel, 76, 20, true)
    tabFavor:SetSize(76, 22)
    tabFavor:SetPoint("LEFT", tabDisenchant, "RIGHT", 4, 0)
    tabFavor:SetScript("OnClick", function() UI:SetMode("favor") end)
    tabFavor:Hide()

    searchBox = CreateFrame("EditBox", nil, panel, "SearchBoxTemplate")
    searchBox:SetHeight(20)
    searchBox:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -14, -54)
    searchBox:SetWidth(148)
    searchBox:SetAutoFocus(false)
    if searchBox.Instructions then
        searchBox.Instructions:SetText(L.SEARCH)
        if searchBox.Instructions.SetWordWrap then searchBox.Instructions:SetWordWrap(false) end      -- one line only
    end
    searchBox:HookScript("OnTextChanged", function() UI:Refresh() end)

    -- (the check box "Missing only" is gone: db.filters.missing was read nowhere any more – the filter "Missing" of the
    -- switch shows exactly that; UI rework 2, "one filter field instead of 4 buttons + check box")

    -- template tooltips of the tabs and the check button go beside the panel too (Spieltest S8)
    for _, f in ipairs({ tabRecipes, tabRanking, tabPlan, tabTrainers, tabDisenchant, tabFavor, tabGoldList }) do
        UI.GuardTemplateTooltip(f)
    end
    for _, f in ipairs(UI.mainTabs) do UI.GuardTemplateTooltip(f) end
    for _, f in ipairs(UI.filterButtons) do UI.GuardTemplateTooltip(f) end

    summary = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    summary:SetPoint("TOPLEFT", panel, "TOPLEFT", 14, -80)
    summary:SetPoint("RIGHT", panel, "RIGHT", -12, 0)
    summary:SetJustifyH("LEFT")

    local inset = panel.Inset or panel
    if panel.Inset then
        panel.Inset:ClearAllPoints()
        panel.Inset:SetPoint("TOPLEFT", panel, "TOPLEFT", 8, -106)
        panel.Inset:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -6, 22)
        -- the background never takes clicks (only rows, buttons and the window itself)
        if panel.Inset.EnableMouse then panel.Inset:EnableMouse(false) end
    end

    scrollBox = CreateFrame("Frame", nil, inset, "WowScrollBoxList")
    scrollBox:SetPoint("TOPLEFT", inset, "TOPLEFT", 4, -4)
    scrollBox:SetPoint("BOTTOMRIGHT", inset, "BOTTOMRIGHT", -20, 4)
    scrollBar = CreateFrame("EventFrame", nil, inset, "MinimalScrollBar")
    scrollBar:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 4, 0)
    scrollBar:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 4, 0)

    local view = CreateScrollBoxListTreeListView(0)
    view:SetElementExtent(ROW_HEIGHT)
    view:SetElementFactory(function(factory, node)
        -- different frame types = separate frame pools, so headers and rows never share a frame
        if node:GetData().header then factory("CheckButton", InitHeader) else factory("Button", InitRow) end
    end)
    ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, scrollBar, view)

    infoText = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    infoText:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -10, 6)
    local qdate = (ns.DataMeta.questie or ""):match("%d%d%d%d%-%d%d%-%d%d") or "?"
    infoText:SetText(string.format(L.DATA_INFO, ns.FlavorName(), ns.DataMeta.build or "?", qdate))

    panel:SetScript("OnShow", function() UI:Refresh() end)
    panel:SetScript("OnHide", function() GameTooltip:Hide() end)
end

---------------------------------------------------------------------------
-- Docking next to the profession window
-- AHSentinel docks its profit window directly right of the profession window. ProfessionSentinel then docks right
-- of that window, otherwise right of the profession window. Only AHSentinel's interface
-- AHAnalyzerPro.Crafting:GetDockFrame() is used (visible frame or nil); older AHSentinel versions without it are left
-- alone (no frame search). Only our own panel moves, nothing of Blizzard or AHSentinel.
---------------------------------------------------------------------------
local DOCK_GAP = 2

-- AHSentinel's visible dock frame, or nil (no AHSentinel, older version, hidden, error)
function UI.GetAHSDockFrame()
    local A = ns.Foreign("AHAnalyzerPro")
    local C = type(A) == "table" and A.Crafting
    local get = type(C) == "table" and C.GetDockFrame
    if type(get) ~= "function" then return nil end
    local ok, f = pcall(get, C)
    if not ok or type(f) ~= "table" or f == panel then return nil end
    if f.IsShown and not f:IsShown() then return nil end
    return f
end

-- Rectangle of a frame in UIParent units: { l, r, t, b } or nil
local function Rect(f)
    if not (f and f.GetLeft and f.GetRight and f.GetTop and f.GetBottom) then return nil end
    local l, r, t, b = f:GetLeft(), f:GetRight(), f:GetTop(), f:GetBottom()
    if not (l and r and t and b) then return nil end
    local k = 1
    if f.GetEffectiveScale and UIParent and UIParent.GetEffectiveScale then
        local ui = UIParent:GetEffectiveScale()
        if ui and ui > 0 then k = (f:GetEffectiveScale() or ui) / ui end
    end
    return { l = l * k, r = r * k, t = t * k, b = b * k }
end
UI.Rect = Rect

local function Overlap(a, b)
    return a and b and a.l < b.r and b.l < a.r and a.b < b.t and b.b < a.t
end
UI.Overlap = Overlap

-- Where does the panel (width w, height h) go? Pure calculation, also used by the test routine.
-- host = rect of the profession window, dock = rect of AHSentinel's window or nil, sw/sh = screen size.
-- Order: right of the outermost window -> below AHSentinel's window -> left of the profession window ->
-- (no room anywhere) right of the outermost window as before.
-- Returns: point, "dock"|"host", relPoint, x, y, rect of the panel
function UI.DockPlacement(host, dock, w, h, sw, sh)
    local anchor = dock and "dock" or "host"
    local a = dock or host
    local function fits(r)
        return r.l >= 0 and r.r <= sw and r.b >= 0 and r.t <= sh and not Overlap(r, host) and not Overlap(r, dock)
    end
    local right = { l = a.r + DOCK_GAP, r = a.r + DOCK_GAP + w, t = a.t, b = a.t - h }
    if fits(right) then return "TOPLEFT", anchor, "TOPRIGHT", DOCK_GAP, 0, right, true end
    if dock then
        local below = { l = dock.l, r = dock.l + w, t = dock.b - DOCK_GAP, b = dock.b - DOCK_GAP - h }
        if fits(below) then return "TOPLEFT", "dock", "BOTTOMLEFT", 0, -DOCK_GAP, below, true end
    end
    local left = { l = host.l - DOCK_GAP - w, r = host.l - DOCK_GAP, t = host.t, b = host.t - h }
    if fits(left) then return "TOPRIGHT", "host", "TOPLEFT", -DOCK_GAP, 0, left, true end
    -- 7th value false: no free place found (diagnostic log ÜBERLAPPT)
    return "TOPLEFT", anchor, "TOPRIGHT", DOCK_GAP, 0, right, false
end

-- name of a frame for the diagnostic log (Blizzard/AHSentinel frame names only, never player data)
local function FrameLabel(f, fallback)
    local n = f and f.GetName and f:GetName()
    return (type(n) == "string" and n ~= "") and n or fallback
end

-- Diagnostic log: no free place (fitted == false), or the panel rectangle overlaps AHSentinel's window.
-- Pure apart from the log entry; panelRect/dockRect as from Rect(). Returns true when something was written.
function UI.DiagDock(fitted, panelRect, dockRect, hostLabel, dockLabel)
    if not ns.Diagnose then return false end
    local wrote = false
    if fitted == false then
        ns.Diagnose.Overlap(string.format(L.DG_OVERLAP_NOROOM, hostLabel or "?")); wrote = true
    end
    if panelRect and dockRect and Overlap(panelRect, dockRect) then
        ns.Diagnose.Overlap(string.format(L.DG_OVERLAP_AHS, dockLabel or L.DG_DOCK_AHS)); wrote = true
    end
    return wrote
end

-- Re-anchor when AHSentinel's window is shown or hidden (hook each of its frames once)
local hookedDocks = setmetatable({}, { __mode = "k" })
local function Redock()
    if panel and panel:IsShown() and currentHost then UI:AttachTo(currentHost) end
end
UI.Redock = Redock

local function HookDock(f)
    if not f or hookedDocks[f] or not f.HookScript then return end
    hookedDocks[f] = true
    pcall(f.HookScript, f, "OnShow", Redock)
    pcall(f.HookScript, f, "OnHide", Redock)
    pcall(f.HookScript, f, "OnSizeChanged", Redock)      -- AHSentinel's window grows/shrinks: move along
end

-- AHSentinel 0.65.11+: GetDockFrame(true) also returns the hidden frame. Hook it once, so we see it appear even
-- when it shows up later (e.g. on choosing a recipe). Older versions ignore the argument (visible frame or nil).
function UI.HookAHSDock()
    local A = ns.Foreign("AHAnalyzerPro")
    local C = type(A) == "table" and A.Crafting
    local get = type(C) == "table" and C.GetDockFrame
    if type(get) ~= "function" then return nil end
    local ok, f = pcall(get, C, true)
    if not ok or type(f) ~= "table" or f == panel then return nil end
    HookDock(f)
    return f
end

-- Called on our own Refresh/OnShow and on TRADE_SKILL_SHOW: hook a frame that was nil before, and re-dock when
-- AHSentinel's visible window differs from the one we are docked to.
function UI.PanelFrame() return panel end
function UI.dockedHost() return currentHost end
function UI.PanelVisible() return panel ~= nil and panel:IsShown() end
function UI.SummaryFont() return summary end         -- the line "Prices: … · Crafting: …/h" (area K, T235)

-- public for other addons (UI rework U9, agreed with AHSentinel): while our panel is open, AHSentinel hides its
-- profit window and asks ProfessionSentinel.IsPanelShown() (with pcall; the function may be missing)
_G.ProfessionSentinel = type(_G.ProfessionSentinel) == "table" and _G.ProfessionSentinel or {}
_G.ProfessionSentinel.IsPanelShown = function() return UI.PanelVisible() and true or false end
-- PS47-1: AHSentinel (Crafting.lua Cr:PSActive) reads the switch HERE, at the global table ProfessionSentinel – the same
-- answer as ProfessionSentinelAPI.IsEnabled: false when the player switched off opening with the profession window
-- (then AHSentinel shows its own profit window again)
_G.ProfessionSentinel.IsEnabled = function() return UI.AutoOpen() and true or false end

function UI.CheckDock()
    if not (panel and panel:IsShown() and currentHost) then return end
    UI.HookAHSDock()
    if (UI.GetAHSDockFrame() or false) ~= (UI.lastDock or false) then Redock() end
    -- still overlapping AHSentinel's window? (diagnostic log only)
    local dock = UI.lastDock
    if dock then pcall(UI.DiagDock, nil, Rect(panel), Rect(dock), nil, FrameLabel(dock, L.DG_DOCK_AHS)) end
end

local function DockPanel(host)
    UI.HookAHSDock()
    local dock = UI.GetAHSDockFrame()
    HookDock(dock)
    UI.lastDock = dock
    local hostRect, dockRect = Rect(host), dock and Rect(dock)
    local screen = Rect(UIParent)
    local w, h = panel:GetWidth() or PANEL_WIDTH, panel:GetHeight() or 560
    local point, rel, relPoint, x, y = "TOPLEFT", dock and "dock" or "host", "TOPRIGHT", DOCK_GAP, 0
    local placed, fitted
    if hostRect and screen and (dockRect or not dock) then
        point, rel, relPoint, x, y, placed, fitted = UI.DockPlacement(hostRect, dockRect, w, h, screen.r - screen.l, screen.t - screen.b)
    end
    UI.dockedTo = rel == "dock" and dock or host
    panel:SetPoint(point, UI.dockedTo, relPoint, x, y)
    pcall(UI.DiagDock, fitted, placed, dockRect, FrameLabel(host, "?"), FrameLabel(dock, L.DG_DOCK_AHS))
end

-- Dock the panel to a host frame (nil = free-floating in the screen centre, used by test mode)
function UI:AttachTo(host)
    if not panel then CreatePanel() end
    currentHost = host
    panel:ClearAllPoints()
    if host then
        panel:SetHeight(math.max(host:GetHeight() or 560, 460))
        DockPanel(host)
        panel:SetMovable(false)
        panel:RegisterForDrag()
    else
        UI.dockedTo = nil
        panel:SetPoint("CENTER", UIParent, "CENTER", 220, 0)
        panel:SetHeight(580)
        panel:SetMovable(true)
        panel:EnableMouse(true)
        panel:RegisterForDrag("LeftButton")
        panel:SetScript("OnDragStart", panel.StartMoving)
        panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
    end
end

function UI:Show(host)
    self:AttachTo(host)
    panel:Show()
    self:Refresh()
    -- AHSentinel may show its window in the same frame, after us: look again shortly after
    if host and C_Timer and C_Timer.After then
        C_Timer.After(0, Redock)
        C_Timer.After(0.3, Redock)
    end
end

function UI:Hide()
    if panel then panel:Hide() end
end

function UI:IsShown()
    return panel and panel:IsShown()
end

local function ActiveHost()
    if ns.UsesModernProfessions then
        return ProfessionsFrame and ProfessionsFrame:IsShown() and ProfessionsFrame or nil
    end
    if CraftFrame and CraftFrame:IsShown() then return CraftFrame end
    if TradeSkillFrame and TradeSkillFrame:IsShown() then return TradeSkillFrame end
end

function UI:Toggle()
    local host = ActiveHost()
    if panel and panel:IsShown() then
        panel:Hide()
        return
    end
    if not host and not (ns.Sim and ns.Sim.prof) then
        ns.Print(L.OPEN_PROF_FIRST)
        return
    end
    self:Show(host)
end

---------------------------------------------------------------------------
-- Hosts: toggle button + show/hide with the profession window
---------------------------------------------------------------------------
local hostsDone = {}

local function SetupHost(host)
    if not host or hostsDone[host] then return end
    hostsDone[host] = true
    collapsed = ns.db.collapsed or {}
    ns.db.collapsed = collapsed
    -- always visible on the profession window (hint 20:15, PS-DOCK1: AHSentinel hides its own profit window when
    -- ProfessionSentinel is loaded – this button always brings the panel back)
    local b = CreateFrame("Button", nil, host, "UIPanelButtonTemplate")
    b:SetSize(130, 22)
    b:SetPoint("TOPRIGHT", host, "BOTTOMRIGHT", -6, ns.UsesModernProfessions and 0 or 70)
    b:SetText(L.PS_BUTTON)
    b:SetScript("OnClick", function()
        if panel and panel:IsShown() and currentHost == host then
            panel:Hide()
        else
            UI:Show(host)
        end
    end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")      -- button on the profession window (not in our panel)
        GameTooltip:AddLine("ProfessionSentinel", 0.25, 0.78, 0.92)
        GameTooltip:AddLine(L.PS_BUTTON_TIP, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- "Best recipe" hint next to the button: click selects it in the profession window
    local hint = CreateFrame("Button", nil, host)
    hint:SetSize(340, 22)
    hint:SetPoint("RIGHT", b, "LEFT", -8, 0)
    hint.host, hint.button = host, b
    hint.text = hint:CreateFontString(nil, "OVERLAY", "GameFontHighlight")      -- bright and as large as Blizzard's rows
    hint.text:SetAllPoints()
    hint.text:SetJustifyH("RIGHT")
    hint.text:SetWordWrap(false)
    hint:SetScript("OnClick", function()
        -- learned: select it in the profession window; nothing learned useful: open the ranking
        local e = ns.Advisor and ns.Advisor.current.bestLearned
        if e then SelectInBlizzard(e.recipe) else UI:Show(host); UI:SetMode("ranking") end
    end)
    hint:SetScript("OnEnter", function(self)
        local AD = ns.Advisor
        local e = AD and (AD.current.bestLearned or AD.current.best)
        if e then UI:ShowRecipeTooltip(self, e.recipe, AD.current.rank) end
    end)
    hint:SetScript("OnLeave", function() GameTooltip:Hide() end)
    hint:Hide()
    bestHints[host] = hint

    host:HookScript("OnShow", function()
        if UI.AutoOpen() then UI:Show(host) end
    end)
    host:HookScript("OnHide", function()
        if currentHost == host and panel then panel:Hide() end
    end)
    if host:IsShown() and UI.AutoOpen() then UI:Show(host) end
    UI.hostButtons = UI.hostButtons or {}
    UI.hostButtons[host] = b
end

local loader = ns.AddEventFrame(CreateFrame("Frame"), "UI")
loader:RegisterEvent("ADDON_LOADED")
loader:RegisterEvent("PLAYER_LOGIN")
-- profession events differ between the clients (Retail has no TRADE_SKILL_UPDATE / CRAFT_UPDATE,
-- Classic Era no TRADE_SKILL_LIST_UPDATE): register each one only if the client knows it
for _, e in ipairs({ "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_DATA_SOURCE_CHANGED", "TRADE_SKILL_UPDATE", "CRAFT_UPDATE",
        "TRADE_SKILL_SHOW", "UNIT_SPELLCAST_SUCCEEDED", "MODIFIER_STATE_CHANGED" }) do
    pcall(loader.RegisterEvent, loader, e)
end
loader:SetScript("OnEvent", function(_, event, name, _, spell)
    if not ns.Flavor or not ns.db then return end
    if event == "MODIFIER_STATE_CHANGED" then
        -- Shift pressed or released over one of our recipe rows: the tooltip with or without the details
        local t, tt = UI.lastTip, GameTooltip
        if t and tt and tt.IsShown and tt:IsShown() and tt.GetOwner and tt:GetOwner() == t.owner then
            UI:ShowRecipeTooltip(t.owner, t.r, t.rank, t.deMode)
        end
        return
    end
    if event == "UNIT_SPELLCAST_SUCCEEDED" then
        -- an own craft of a known recipe: the crafting mode (counters only, one rebuild afterwards)
        if name ~= "player" or (ns.IsSecret and ns.IsSecret(spell)) then return end
        if type(spell) == "number" and ns.BySpell and ns.BySpell[spell] then
            UI.NoteCraft()
            -- check of the recommendations (Market.lua PM6): "crafting pays" is noted with the expected proceeds
            if ns.Market then pcall(ns.Market.OnCraft, ns.BySpell[spell]) end
        end
        return
    end
    collapsed = collapsed or ns.db.collapsed or {}
    if event == "ADDON_LOADED" then
        if name == "Blizzard_Professions" and ns.UsesModernProfessions then SetupHost(ProfessionsFrame)
        elseif name == "Blizzard_TradeSkillUI" and ns.IsEra then SetupHost(TradeSkillFrame)
        elseif name == "Blizzard_CraftUI" and ns.IsEra then SetupHost(CraftFrame) end
    elseif event == "PLAYER_LOGIN" then
        if ns.UsesModernProfessions and ProfessionsFrame then SetupHost(ProfessionsFrame) end
        if ns.IsEra and TradeSkillFrame then SetupHost(TradeSkillFrame) end
        if ns.IsEra and CraftFrame then SetupHost(CraftFrame) end
    else
        UI.OnProfessionEvent(event)
    end
end)
