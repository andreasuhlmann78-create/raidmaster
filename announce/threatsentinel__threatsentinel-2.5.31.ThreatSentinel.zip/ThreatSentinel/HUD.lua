-- ThreatSentinel - HUD.lua
-- Kleines Info-Fenster: Zähler der losen Mobs, wer angegriffen wird, zusätzliche Hinweise.
-- Reine Anzeige ohne Klicks, damit es im Kampf nicht stört.

local ADDON, ns = ...
local API = ns.API   -- Blizzard-Funktionen nur über ns.API (API.lua)
local L = ns.L

local H = {}
ns.HUD = H
table.insert(ns.modules, H)

local WHITE = "Interface\\Buttons\\WHITE8X8"
local ROW_H = 14

function H:Init()
	local f = CreateFrame("Frame", "ThreatSentinelHUD", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	if ns.RegisterUI then ns.RegisterUI(f, "HUD", "hud") end   -- Oberflächen-Prüfung (UICheck.lua)
	f:SetSize(220, 24)
	f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	f:SetBackdropColor(0.03, 0.04, 0.06, 0.55)
	f:SetBackdropBorderColor(0.25, 0.65, 1, 0.5)
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", function(self) self:StartMoving() end)
	f:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		ns.Mover:SavePoint(self, "hudPoint")
	end)
	f.header = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	f.header:SetPoint("TOPLEFT", 7, -5)
	f.lines = {}
	f:Hide()
	self.f = f
	ns.Mover:Attach(f, "hud")
	self:ApplySettings()
end

function H:ApplySettings()
	local f, db = self.f, ns.db
	local p = db.hudPoint
	f:ClearAllPoints()
	f:SetPoint(p[1], UIParent, p[3], p[4], p[5])
	f:SetScale(db.hudScale)
	f:EnableMouse(ns:Unlocked())
end

function H:Line(i)
	local f = self.f
	local l = f.lines[i]
	if not l then
		l = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		l:SetPoint("TOPLEFT", 9, -8 - ROW_H * i)
		l:SetWidth(204)
		l:SetJustifyH("LEFT")
		if l.SetWordWrap then l:SetWordWrap(false) end
		f.lines[i] = l
	end
	return l
end

-- loose = Liste loser Mobs oder nil (Addon inaktiv)
function H:Update(loose, extras)
	local f, db = self.f, ns.db
	if not f then return end
	local inCombat = API.UnitAffectingCombat("player")
	-- Gruppen-Ansicht: das HUD ist ein Tank-Werkzeug – ausser für Heiler (TS-N1, Option hudHealer): sie sehen damit,
	-- welcher Mitspieler gerade Aggro hat und wen sie zuerst heilen müssen (dieselbe Liste, keine zusätzliche Rechnung)
	local healerView = ns.memberNow and db.hudHealer and ns:MyRole() == "HEALER"
	local show = ns.moveMode or (db.hud and (not ns.memberNow or healerView) and (ns.testMode or ns:Unlocked() or (loose ~= nil and inCombat)))
	if not show then f:Hide() return end
	if healerView and inCombat and not ns.testMode and not ns.moveMode then ns:PLHit("HEILER-HUD", "im Kampf") end

	loose = loose or {}
	extras = extras or {}
	local n = 0

	if ns:Unlocked() and not inCombat and not ns.testMode then
		f.header:SetText(L.HUD_DRAG)
		f.header:SetTextColor(0.4, 0.8, 1)
	else
		f.header:SetText(string.format(L.LOOSE, #loose))
		if #loose > 0 then f.header:SetTextColor(1, 0.3, 0.3) else f.header:SetTextColor(0.4, 0.8, 1) end
		for i, m in ipairs(loose) do
			if i > db.hudMaxRows then break end
			n = n + 1
			local l = self:Line(n)
			local c = (m.victimRole == "HEALER") and db.colorHealer or db.colorDD
			local icon = m.mark and ("|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_" .. m.mark .. ":0|t ") or ""
			l:SetText(icon .. (m.name or "?") .. " " .. string.format(L.ARROW, m.victim or "?", L[m.victimRole or "DAMAGER"]))
			l:SetTextColor(c[1], c[2], c[3])
			l:Show()
		end
		for _, e in ipairs(extras) do
			n = n + 1
			local l = self:Line(n)
			l:SetText(e.text)
			l:SetTextColor(e.c[1], e.c[2], e.c[3])
			l:Show()
		end
	end
	for i = n + 1, #f.lines do f.lines[i]:Hide() end
	f:SetHeight(24 + ROW_H * n)
	f:Show()
	if #loose > 0 and ns.Guide and not ns.testMode then ns.Guide:Signal("hud") end
end
