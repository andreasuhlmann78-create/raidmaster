-- ThreatSentinel - Messung.lua (TS-M1, Messauftrag Supervisor 24.11.2026 13:33–13:35)
-- Copyright (C) 2026 GoldSentinel
--
-- Frage des Nutzers: Lässt sich die Aggro an den Namensplaketten in WoW Forever trotz geschützter Werte zeigen
-- (Blizzard-Plaketten aus, eigene an)? Hier wird NUR GEMESSEN, was möglich ist. Die Anzeige bleibt unverändert.
--
-- Zwei Teile:
--  1) Automatisch beim normalen Spielen, bei JEDEM Spieler (TS-M1-b, Entscheid des Nutzers 24.11. 14:09: "normale Spieler und
--     Offiziere liefern die Daten über den Uploader"), abschaltbar über die Option "Messdaten für die Entwicklung sammeln"
--     (ns.db.m1Collect, Standard EIN), NUR LESEN, ohne Meldung im Chat und ohne Fenster:
--     beim Betreten einer Instanz: (f) CVars rund um Plaketten/Aggro, (e) vorhandene Blizzard-Namen für geschützte Werte;
--     im Kampf, sobald Mobs Bedrohung haben: (d) jede Bedrohungs-Quelle einzeln, (b) Blizzard-Aggro an der Plakette
--     (aggroHighlight: vorhanden, von Blizzard gezeigt, an mir / nicht an mir), Ereignisse und Kampflog.
--     Je Kampf bzw. je Instanz höchstens EIN Durchlauf je Quelle, in EINEM Bild, mit gemessenen Kosten (Ziel ≤ 1 ms).
--     Nichts wird verändert: keine Plakette, keine Alpha/Farbe/Grösse, keine CVar, kein SetValue/SetText, kein Ziel,
--     nichts gesendet. ThreatSentinel setzt an aggroHighlight nur die Alpha (Nameplates.lua, nie Show/Hide) – IsShown
--     ist darum Blizzards eigener Zustand, auch nach der eigenen Abschwächung.
--  2) Auf Befehl des Nutzers (/ts messung kampf, Entwicklermodus): (a) geschützte Werte an einen eigenen, unsichtbaren
--     Test-Rahmen durchreichen und (c) einen eigenen Rahmen an eine Blizzard-Plakette hängen und Blizzard-Teile kurz
--     abschwächen/ausblenden – vor und im Kampf. Alles wird im selben Bild zurückgesetzt (Alpha und Sichtbarkeit wie vorher).
--
-- Ablage: account-weite SavedVariables ThreatSentinelDB.m1 (Datei WTF/Account/<Konto>/SavedVariables/ThreatSentinel.lua – die
-- liefert der Uploader; Charakter-Dateien kommen nicht an). Ringpuffer der letzten 20 Durchläufe, ältere als Zähler je Quelle
-- zusammengefasst (m1.sum), Umgebung (CVars, Namen) nur einmal je Version/Build (m1.env), Kopf mit Version, Build, Datum (m1.head).
-- Teil 2 (Befehle) bleibt nur im Entwicklermodus.
--
-- Keine Namen (Repo öffentlich): gespeichert werden nur Art (geschützt/lesbar/nil), Anzahlen, Instanz-ID, Rolle, Klasse.
-- Ablage: ThreatSentinelDB.m1 (höchstens M1.MAX_RUNS Einträge), Ausgabe: Diagnose-Protokoll (GSDIAG1) und /ts messung.

local ADDON, ns = ...
local API = ns.API
local L = ns.L

local M1 = {}
ns.M1 = M1
M1.MAX_RUNS = 20        -- gespeicherte Durchläufe (Kampf/Instanz/Befehl), neueste zuerst (TS-M1-b: Ringpuffer 20)
M1.SIZE_LIMIT = 20480   -- Byte: so viel darf ThreatSentinel.lua durch die Messung höchstens wachsen (TS-M1-b)
M1.PLATE_MAX = 10       -- höchstens so viele Plaketten je Durchlauf
M1.FIGHT_DELAY = 1.5    -- s nach Kampfbeginn: dann haben die Mobs Bedrohung
M1.RETRY_DELAY = 3      -- noch einmal, falls beim ersten Mal kein Mob mit Bedrohung da war
M1.FOLLOW_DELAY = 0.5   -- (c) folgt der eigene Rahmen der Plakette? zweite Lesung nach so vielen s
M1.COST_LIMIT = 1       -- ms je Bild (Auftrag TS-M1)

-- (f) CVars, die automatisch gelesen werden (nur lesen; "nicht vorhanden" ist ein Messergebnis, kein Raten).
-- Die vollständige Liste aus dem Client (C_Console.GetAllCommands) liest nur der Befehl /ts messung – sie ist zu teuer für
-- ein Bild im Spiel.
M1.CVARS = {
	"nameplateShowEnemies", "nameplateShowFriends", "nameplateShowAll", "nameplateShowEnemyMinions", "nameplateShowEnemyMinus",
	"nameplateShowFriendlyNPCs", "nameplateShowSelf", "nameplateShowOnlyNames", "nameplateMotion", "nameplateMaxDistance",
	"nameplateThreatDisplay", "ShowNamePlateLoseAggroFlash", "threatWarning", "threatShowNumeric", "threatPlaySounds",
}

-- (e) Namen für geschützte Werte bzw. Bedrohung: nur ob vorhanden (type), nie aufgerufen
M1.NAMES = {
	"issecretvalue", "issecrettable", "canaccessvalue", "canaccesssecrets", "secretwrap", "scrubsecretvalues",
	"C_CurveUtil", "C_CurveUtil.CreateColorCurve", "C_CurveUtil.CreateCurve", "C_DurationUtil", "C_StringUtil",
	"CreateColorCurve", "GetThreatStatusColor", "UnitThreatPercentageOfLead", "UnitThreatSituation",
	"UnitDetailedThreatSituation", "C_Console", "C_Console.GetAllCommands",
}

-- (b) Teile am UnitFrame der Plakette, die nach Aggro aussehen: nur ob vorhanden
M1.PLATE_KEYS = { "aggroHighlight", "ThreatIndicator", "threatIndicator", "AggroFlash", "aggroFlash" }

-- (d) Bedrohung am Zielrahmen: nur ob vorhanden / gezeigt / Text geschützt
M1.TARGET_NAMES = { "TargetFrameNumericalThreat", "TargetFrameNumericalThreatValue" }

------------------------------------------------------------
-- Hilfen
------------------------------------------------------------
local function Ms()
	if API.debugprofilestop then return API.debugprofilestop() end
	return (GetTime and GetTime() or 0) * 1000
end
local function Stamp() return date and date("%d.%m. %H:%M") or "" end

-- Art eines Werts: "nil", "geschützt" oder "lesbar" (mit Typ) – nie der Wert selbst (keine Namen, keine GUIDs)
function M1.Kind(v)
	if v == nil then return "nil" end
	if ns.IsSecret(v) then return "geschützt" end
	return "lesbar(" .. type(v) .. ")"
end
local Kind = M1.Kind

-- Aufruf in pcall; Ergebnis als Art jeder Rückgabe, "nicht vorhanden" oder "Fehler"
local function Call(fn, ...)
	if type(fn) ~= "function" then return "nicht vorhanden" end
	local r = { pcall(fn, ...) }
	if not r[1] then return "Fehler" end
	local out = {}
	for i = 2, math.max(2, #r) do out[#out + 1] = Kind(r[i]) end
	return table.concat(out, "/"), r
end

local function Lookup(name)
	local t = _G
	for part in name:gmatch("[^%.]+") do
		if type(t) ~= "table" then return nil end
		t = rawget(t, part)
	end
	return t
end

local function Bool(v)
	if v == nil then return "nil" end
	if ns.IsSecret(v) then return "geschützt" end
	return v and "ja" or "nein"
end

local function JoinMap(t)
	local keys = {}
	for k in pairs(t or {}) do keys[#keys + 1] = k end
	table.sort(keys)
	local out = {}
	for _, k in ipairs(keys) do out[#out + 1] = k .. " " .. t[k] end
	return #out > 0 and table.concat(out, ", ") or "-"
end

-- TS-M1-b: für alle Spieler, abschaltbar (ns.db.m1Collect); nie während der Testroutine (ausser im eigenen Test: inTest)
function M1:Allowed()
	if self.force then return true end
	if ns.routineRunning and not self.inTest then return false end
	if type(ThreatSentinelDB) ~= "table" then return false end
	return not (ns.db and ns.db.m1Collect == false)
end

function M1:Store()
	if type(ThreatSentinelDB) ~= "table" then return nil end
	local s = ThreatSentinelDB.m1
	if type(s) ~= "table" then s = {}; ThreatSentinelDB.m1 = s end
	s.runs = type(s.runs) == "table" and s.runs or {}
	s.cost = type(s.cost) == "table" and s.cost or { max = 0, n = 0, over = 0 }
	s.sum = type(s.sum) == "table" and s.sum or {}
	return s
end

-- Client-Build (ohne Namen)
function M1.Build()
	local gb = rawget(_G, "GetBuildInfo")
	if type(gb) ~= "function" then return "?" end
	local ok, ver, build = pcall(gb)
	if not ok then return "?" end
	return ns.BuildText and ns.BuildText(ver, build) or (tostring(ver) .. " · Build " .. tostring(build))
end

-- Ältere Durchläufe zusammenfassen: Zähler je Art und je Quelle=Ergebnis (m1.sum)
function M1:Summarize(s, r)
	local sum = s.sum
	local function inc(k) sum[k] = (sum[k] or 0) + 1 end
	inc("art " .. tostring(r.art))
	if type(r.q) == "string" then
		for pair in r.q:gmatch("([%w]+=[^;]+)") do
			if not pair:find("^tf=") then inc(pair) end
		end
	end
	local d = r.sources
	if type(d) == "table" then
		for _, k in ipairs({ "situation", "isTanking", "status", "scaled", "raw", "value", "situationPlayer", "lead", "color", "targetIsMe" }) do
			if d[k] ~= nil then inc(k .. "=" .. tostring(d[k])) end
		end
	end
	if type(r.p) == "string" then inc("Plakette " .. (r.p:match("aggroHighlight ([^·]+)") or "?")) end
	if type(r.plates) == "table" then for k, n in pairs(r.plates.ah or {}) do sum["aggroHighlight " .. k] = (sum["aggroHighlight " .. k] or 0) + n end end
end

function M1:Add(run)
	local s = self:Store()
	if not s then return end
	run.z, run.v = Stamp(), ns.version
	s.head = { v = ns.version, build = M1.Build(), z = date and date("%Y-%m-%d %H:%M") or "", flavor = ns.flavor }
	table.insert(s.runs, 1, run)
	for i = #s.runs, self.MAX_RUNS + 1, -1 do
		self:Summarize(s, s.runs[i])
		s.runs[i] = nil
	end
	return run
end

function M1:Cost(ms)
	local s = self:Store()
	if not s then return end
	local c = s.cost
	c.n = (c.n or 0) + 1
	if ms > (c.max or 0) then c.max = ms end
	if ms > self.COST_LIMIT then c.over = (c.over or 0) + 1 end
end

-- feindliche Plaketten (höchstens PLATE_MAX): { unit, plate, uf }
function M1:Plates()
	local out = {}
	local NP = API.C_NamePlate
	if not (NP and NP.GetNamePlates) then return out end
	local ok, list = pcall(NP.GetNamePlates)
	if not ok or type(list) ~= "table" then return out end
	for _, plate in ipairs(list) do
		if #out >= self.PLATE_MAX then break end
		local forbidden = plate.IsForbidden and plate:IsForbidden()
		local uf = not forbidden and plate.UnitFrame or nil
		local unit = plate.namePlateUnitToken or (uf and uf.unit)
		if type(unit) == "string" and not ns.IsSecret(unit) then
			local okA, can = pcall(API.UnitCanAttack, "player", unit)
			if okA and ns.Safe(can, false) then out[#out + 1] = { unit = unit, plate = plate, uf = uf } end
		end
	end
	return out
end

------------------------------------------------------------
-- (f) + (e): beim Betreten einer Instanz (einmal je Instanz-ID und Sitzung)
------------------------------------------------------------
function M1:ReadCVars(names)
	local present, absent = {}, {}
	local get = (API.C_CVar and API.C_CVar.GetCVar) or API.GetCVar
	for _, name in ipairs(names) do
		local ok, v = false, nil
		if get then ok, v = pcall(get, name) end
		if ok and v ~= nil then present[#present + 1] = name .. "=" .. (ns.IsSecret(v) and "geschützt" or tostring(v))
		else absent[#absent + 1] = name end
	end
	return present, absent
end

function M1:ReadNames()
	local out = {}
	for _, name in ipairs(self.NAMES) do
		local v = Lookup(name)
		out[#out + 1] = name .. "=" .. (v == nil and "nicht vorhanden" or type(v))
	end
	return out
end

M1.instSeen = {}
function M1:OnInstance()
	if not self:Allowed() then return end
	local okI, inInst = pcall(API.IsInInstance)
	if not okI or not ns.Safe(inInst, false) then return end
	local id
	if API.GetInstanceInfo then
		local r = { pcall(API.GetInstanceInfo) }
		if r[1] then id = r[9] end   -- Rückgabe 8 = Instanz-ID
	end
	id = (id ~= nil and not ns.IsSecret(id)) and tostring(id) or "?"
	if self.instSeen[id] then return end
	self.instSeen[id] = true
	local t0 = Ms()
	local present, absent = self:ReadCVars(self.CVARS)
	local names = self:ReadNames()
	local ms = Ms() - t0
	self:Cost(ms)
	-- TS-M1-b Grösse: CVars und Namen nur einmal je Version/Build/Spielversion speichern (m1.env); der Durchlauf hält nur, ob sie
	-- sich gegenüber dem gespeicherten Stand geändert haben
	local s = self:Store()
	local key = tostring(ns.version) .. "|" .. M1.Build() .. "|" .. tostring(ns.flavor)
	local sig = table.concat(present, ",") .. ";" .. table.concat(absent, ",") .. ";" .. table.concat(names, ",")
	local changed = "wie gespeichert"
	if s then
		local env = s.env
		local old = type(env) == "table" and (table.concat(env.cvars or {}, ",") .. ";" .. table.concat(env.cvarsAbsent or {}, ",") .. ";"
			.. table.concat(env.names or {}, ",")) or nil
		if type(env) ~= "table" or env.key ~= key or old ~= sig then
			changed = type(env) == "table" and "geändert" or "neu"
			s.env = { key = key, cvars = present, cvarsAbsent = absent, names = names, z = Stamp() }
		end
	end
	return self:Add({ art = "Instanz", inst = id, flavor = ns.flavor, envChanged = changed, ms = math.floor(ms * 100 + 0.5) / 100 })
end

------------------------------------------------------------
-- (d) + (b): im Kampf, ein Durchlauf in einem Bild
------------------------------------------------------------
function M1:ReadSources(unit)
	local d = {}
	local UTS, UDTS = API.UnitThreatSituation, API.UnitDetailedThreatSituation
	local status
	d.situation, status = Call(UTS, "player", unit)
	status = status and status[2]
	local k, r = Call(UDTS, "player", unit)
	d.detailed = k
	if r and r[1] then
		d.isTanking, d.status, d.scaled, d.raw, d.value = Kind(r[2]), Kind(r[3]), Kind(r[4]), Kind(r[5]), Kind(r[6])
	end
	d.situationPlayer = Call(UTS, "player")
	d.lead = Call(Lookup("UnitThreatPercentageOfLead"), "player", unit)
	if status ~= nil then d.color = Call(Lookup("GetThreatStatusColor"), status) else d.color = "ohne Stufe" end
	-- Ziel des Mobs
	d.targetExists = Call(API.UnitExists, unit .. "target")
	local okU, isMe = pcall(API.UnitIsUnit, unit .. "target", "player")
	d.targetIsMe = okU and Bool(isMe) or "Fehler"
	-- Bedrohung am Zielrahmen
	local tf = {}
	for _, name in ipairs(self.TARGET_NAMES) do
		local f = Lookup(name)
		if type(f) ~= "table" then tf[#tf + 1] = name .. "=nicht vorhanden"
		else
			local okS, shown = pcall(f.IsShown, f)
			local txt = "-"
			local fs = f.text or (f.GetText and f) or nil
			if fs and fs.GetText then local okT, t = pcall(fs.GetText, fs); txt = okT and Kind(t) or "Fehler" end
			tf[#tf + 1] = name .. "=gezeigt " .. (okS and Bool(shown) or "Fehler") .. ", Text " .. txt
		end
	end
	d.targetFrame = table.concat(tf, "; ")
	return d
end

function M1:ReadPlate(e, acc)
	local uf = e.uf
	if not uf then acc.forbidden = acc.forbidden + 1 return end
	for _, key in ipairs(self.PLATE_KEYS) do
		if type(uf[key]) == "table" then acc.keys[key] = (acc.keys[key] or 0) + 1 end
	end
	local ah = uf.aggroHighlight
	local okU, isMe = pcall(API.UnitIsUnit, e.unit .. "target", "player")
	local me = okU and isMe or nil
	local meKind = (me == nil and "unbekannt") or (ns.IsSecret(me) and "geschützt") or (me and "an mir" or "nicht an mir")
	if type(ah) ~= "table" or not ah.IsShown then return end
	local okS, shown = pcall(ah.IsShown, ah)
	local sKind = (not okS and "Fehler") or (ns.IsSecret(shown) and "geschützt") or (shown and "gezeigt" or "verborgen")
	local key = meKind .. ": " .. sKind
	acc.ah[key] = (acc.ah[key] or 0) + 1
end

function M1:FightPass()
	local f = self.fight
	if not f or f.passDone or not self:Allowed() then return end
	local t0 = Ms()
	local plates = self:Plates()
	if #plates == 0 then
		f.tries = (f.tries or 0) + 1
		local ms = Ms() - t0
		self:Cost(ms)
		if f.tries == 1 and C_Timer and not self.force then C_Timer.After(self.RETRY_DELAY, function() M1:FightPass() end) end
		return
	end
	f.passDone = true
	f.mobs = #plates
	f.sources = self:ReadSources(plates[1].unit)
	local acc = { keys = {}, ah = {}, forbidden = 0 }
	for _, e in ipairs(plates) do self:ReadPlate(e, acc) end
	f.plates = acc
	local ms = Ms() - t0
	f.ms = math.floor(ms * 100 + 0.5) / 100
	self:Cost(ms)
end

function M1:BeginFight()
	if not self:Allowed() then self.fight = nil return end
	local group = 0
	for _ in ipairs(ns.groupUnits or {}) do group = group + 1 end
	local inst = "draussen"
	local okI, inInst = pcall(API.IsInInstance)
	if okI and ns.Safe(inInst, false) and API.GetInstanceInfo then
		local r = { pcall(API.GetInstanceInfo) }
		if r[1] and r[9] ~= nil and not ns.IsSecret(r[9]) then inst = tostring(r[9]) end
	end
	local okR, role = pcall(ns.MyRole, ns)
	self.fight = { art = "Kampf", flavor = ns.flavor, mode = ns:ThreatMode(), inst = inst, group = group,
		role = okR and tostring(role) or "?", class = ns.class or "?", sit = 0, list = 0, sitUnit = nil, cleu = nil,
		blocked0 = #(ns.blocked or {}), errors0 = ns.errorCount or 0 }
	if not (ns.Alerts and ns.Alerts.cleuAllowed) then
		-- Kampflog bewusst nicht angemeldet (Alerts.cleuAllowed = false in neuen Clients); hier nichts anmelden
		self.fight.cleuDmg, self.fight.cleuCast = "nicht angemeldet (Anmelden löst in diesem Client \"geblockt\" aus, Alerts.lua)", "-"
	end
	if C_Timer and not self.force then
		C_Timer.After(self.FIGHT_DELAY, function() M1:FightPass() end)
		if self.armed then C_Timer.After(self.FIGHT_DELAY + 0.5, function() M1:CommandPass("im Kampf") end) end
	end
end

function M1:EndFight()
	local f = self.fight
	self.fight = nil
	if not f or not self:Allowed() then return end
	if not f.passDone and f.sit == 0 and f.list == 0 then return end   -- kein Mob mit Bedrohung: nichts zu berichten
	f.blocked = #(ns.blocked or {}) - (f.blocked0 or 0)
	f.errors = (ns.errorCount or 0) - (f.errors0 or 0)
	return self:Add(self:Pack(f))
end

-- TS-M1-b Grösse (≤ 20 KB für 20 Durchläufe): ein Kampf wird kurz als Texte gespeichert. Kürzel (Legende in jeder Ausgabe):
-- g = geschützt, - = nicht vorhanden, x = Fehler, l(Typ) = lesbar
M1.LEGEND = "Kürzel: g = geschützt, - = nicht vorhanden, x = Fehler, l(Typ) = lesbar, nil = nil; sit = UnitThreatSituation(player, Mob), "
	.. "det = UnitDetailedThreatSituation (5 Rückgaben), tank/st/sc/raw/val = deren isTanking/Stufe/Prozent/Roh/Wert, sitP = UnitThreatSituation(player), "
	.. "lead = UnitThreatPercentageOfLead, col = GetThreatStatusColor(Stufe), tEx/tMe = Ziel des Mobs vorhanden/ist ich, "
	.. "tf = Zielrahmen (TFNT = TargetFrameNumericalThreat, TFNTV = …Value)"
function M1.Short(text)
	text = tostring(text)
	text = text:gsub("geschützt", "g"):gsub("nicht vorhanden", "-"):gsub("Fehler", "x"):gsub("lesbar%(", "l(")
	return text
end
local SRC_KEYS = { { "situation", "sit" }, { "detailed", "det" }, { "isTanking", "tank" }, { "status", "st" }, { "scaled", "sc" },
	{ "raw", "raw" }, { "value", "val" }, { "situationPlayer", "sitP" }, { "lead", "lead" }, { "color", "col" },
	{ "targetExists", "tEx" }, { "targetIsMe", "tMe" } }
function M1:Pack(f)
	local Short = M1.Short
	local q
	if type(f.sources) == "table" then
		local parts = {}
		for _, k in ipairs(SRC_KEYS) do parts[#parts + 1] = k[2] .. "=" .. tostring(f.sources[k[1]]) end
		local tf = tostring(f.sources.targetFrame):gsub("TargetFrameNumericalThreatValue", "TFNTV"):gsub("TargetFrameNumericalThreat", "TFNT")
		parts[#parts + 1] = "tf=" .. tf
		q = Short(table.concat(parts, "; "))
	end
	local p
	if type(f.plates) == "table" then
		p = Short(string.format("Teile %s · aggroHighlight %s · verboten %d", JoinMap(f.plates.keys), JoinMap(f.plates.ah), f.plates.forbidden or 0))
	end
	return { art = "Kampf", mode = f.mode, inst = f.inst, group = f.group, role = f.role, class = f.class,
		mobs = f.mobs or 0, ms = f.ms, blocked = f.blocked, errors = f.errors, q = q, p = p,
		ev = Short(string.format("SITUATION_UPDATE %d (Einheit %s), LIST_UPDATE %d (Einheit %s)", f.sit or 0, tostring(f.sitUnit or "-"),
			f.list or 0, tostring(f.listUnit or "-"))),
		k = Short(tostring(f.cleuDmg or "kein Schaden gesehen") .. " · " .. tostring(f.cleuCast or "kein Zauber gesehen")) }
end

-- Ereignisse zählen (nur während eines gemessenen Kampfs; sonst ein Tabellen-Zugriff)
function M1:OnThreatEvent(event, unit)
	local f = self.fight
	if not f then return end
	if event == "UNIT_THREAT_SITUATION_UPDATE" then
		f.sit = f.sit + 1
		if not f.sitUnit then f.sitUnit = Kind(unit) end
	else
		f.list = f.list + 1
		if not f.listUnit then f.listUnit = Kind(unit) end
	end
end

-- Kampflog: je Kampf einmal ein Schaden und einmal ein Zauber (Spott und andere) – nur die Art der Felder
local DAMAGE = { SWING_DAMAGE = 12, SPELL_DAMAGE = 15, RANGE_DAMAGE = 15 }
function M1:OnCombatLog()
	local f = self.fight
	if not f or (f.cleuDmg and f.cleuCast) then return end
	local get = API.CombatLogGetCurrentEventInfo
	if not get then f.cleuDmg, f.cleuCast = "nicht vorhanden", "nicht vorhanden" return end
	local r = { pcall(get) }
	if not r[1] then f.cleuDmg = f.cleuDmg or "Fehler" return end
	local sub = r[3]
	if ns.IsSecret(sub) then f.cleuDmg = f.cleuDmg or "Ereignisname geschützt" return end
	local idx = DAMAGE[sub]
	if idx and not f.cleuDmg then
		f.cleuDmg = string.format("%s: Betrag %s, Quelle-GUID %s, Ziel-GUID %s", sub, Kind(r[idx + 1]), Kind(r[5]), Kind(r[9]))
	elseif sub == "SPELL_CAST_SUCCESS" and not f.cleuCast then
		f.cleuCast = string.format("SPELL_CAST_SUCCESS: Zauber-ID %s, Quelle-GUID %s, Ziel-GUID %s", Kind(r[13]), Kind(r[5]), Kind(r[9]))
	end
end

------------------------------------------------------------
-- 2) Auf Befehl: (a) Durchreichen, (c) eigener Rahmen an der Plakette – vor und im Kampf
------------------------------------------------------------
local WHITE = "Interface\\Buttons\\WHITE8X8"
function M1:TestFrame()
	if self.tf then return self.tf end
	local f = CreateFrame("Frame", nil, UIParent)
	f:SetSize(120, 30)
	f:SetPoint("TOPLEFT", UIParent, "TOPLEFT", -400, 400)   -- ausserhalb des Bildschirms
	f:SetAlpha(0)                                            -- unsichtbar
	f.bar = CreateFrame("StatusBar", nil, f)
	f.bar:SetSize(100, 10)
	f.bar:SetPoint("TOP")
	f.bar:SetStatusBarTexture(WHITE)
	f.bar:SetMinMaxValues(0, 100)
	f.text = f:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	f.text:SetPoint("BOTTOM")
	self.tf = f
	return f
end

-- (a) geschützte Werte unverändert an den eigenen Test-Rahmen
function M1:PassThrough(unit)
	local out = {}
	local f = self:TestFrame()
	local UDTS, UTS = API.UnitDetailedThreatSituation, API.UnitThreatSituation
	local okD, _, st, scaled = false, nil, nil, nil
	if UDTS then okD, _, st, scaled = pcall(UDTS, "player", unit) end
	local okS, sit = false, nil
	if UTS then okS, sit = pcall(UTS, "player", unit) end
	out[#out + 1] = "Werte: Prozent " .. (okD and Kind(scaled) or "Fehler") .. ", Stufe " .. (okS and Kind(sit) or "Fehler")
	local function try(label, fn, ...)
		local ok, err = pcall(fn, ...)
		out[#out + 1] = label .. "=" .. (ok and "geht" or ("Fehler: " .. tostring(err):gsub("[\r\n|]", " "):sub(1, 80)))
		return ok
	end
	if scaled ~= nil then
		if try("SetValue(Prozent)", f.bar.SetValue, f.bar, scaled) then
			local okG, v = pcall(f.bar.GetValue, f.bar)
			out[#out + 1] = "GetValue danach " .. (okG and Kind(v) or "Fehler")
		end
		if try("SetFormattedText(%.0f%%, Prozent)", f.text.SetFormattedText, f.text, "%.0f%%", scaled) then
			local okT, t = pcall(f.text.GetText, f.text)
			out[#out + 1] = "Text danach " .. (okT and Kind(t) or "Fehler")
		end
	end
	if sit ~= nil then
		try("SetText(Stufe)", f.text.SetText, f.text, sit)
		try("SetFormattedText(%d, Stufe)", f.text.SetFormattedText, f.text, "%d", sit)
		local color = Lookup("GetThreatStatusColor")
		if type(color) == "function" then
			local okC, r, g, b = pcall(color, sit)
			out[#out + 1] = "GetThreatStatusColor(Stufe)=" .. (okC and (Kind(r) .. "/" .. Kind(g) .. "/" .. Kind(b)) or "Fehler")
			if okC and r ~= nil then try("SetStatusBarColor(Farbe)", f.bar.SetStatusBarColor, f.bar, r, g, b) end
		else
			out[#out + 1] = "GetThreatStatusColor=nicht vorhanden"
		end
	end
	f.text:SetText("")
	return table.concat(out, " · ")
end

-- (c) eigener Rahmen an der Plakette, Blizzard-Teile kurz abschwächen/ausblenden, im selben Bild zurück
function M1:OwnPlate(e, label, done)
	local out = {}
	local plate, uf = e.plate, e.uf
	if not uf then return "Plakette verboten (IsForbidden)" end
	local own = self.own or CreateFrame("Frame", nil, UIParent)
	self.own = own
	local okP = pcall(own.SetParent, own, plate)
	pcall(own.ClearAllPoints, own)
	local okA = okP and pcall(own.SetPoint, own, "CENTER", plate, "CENTER", 0, 0)
	pcall(own.SetSize, own, 10, 10)
	pcall(own.Show, own)
	out[#out + 1] = "eigener Rahmen an Plakette=" .. ((okP and okA) and "geht" or "Fehler")
	for _, key in ipairs({ "name", "healthBar" }) do
		local part = uf[key]
		if type(part) == "table" and part.SetAlpha then
			local okG, a = pcall(part.GetAlpha, part)
			local okSet = pcall(part.SetAlpha, part, 0)
			if okG and a ~= nil and not ns.IsSecret(a) then pcall(part.SetAlpha, part, a) else pcall(part.SetAlpha, part, 1) end
			local okSh, shown = pcall(part.IsShown, part)
			local okH = pcall(part.Hide, part)
			if okSh and shown and not ns.IsSecret(shown) then pcall(part.Show, part) end
			out[#out + 1] = key .. ": SetAlpha=" .. (okSet and "geht" or "Fehler") .. ", Hide=" .. (okH and "geht" or "Fehler")
		end
	end
	local function center(f)
		local ok, x, y = pcall(f.GetCenter, f)
		if not ok or x == nil then return nil end
		if ns.IsSecret(x) or ns.IsSecret(y) then return "geschützt" end
		return x, y
	end
	local px, py = center(plate)
	local ox, oy = center(own)
	local function check()
		local px2, py2 = center(plate)
		local ox2, oy2 = center(own)
		local follows
		if px == "geschützt" or px2 == "geschützt" or ox == "geschützt" or ox2 == "geschützt" then follows = "geschützt"
		elseif px and px2 and ox and ox2 then
			follows = (math.abs((ox2 - px2) - (ox - px)) < 0.5 and math.abs((oy2 - py2) - (oy - py)) < 0.5) and "ja" or "nein"
		else follows = "keine Lage" end
		pcall(own.Hide, own)
		pcall(own.SetParent, own, UIParent)
		done("eigener Rahmen folgt der Plakette=" .. follows)
	end
	local text = table.concat(out, " · ")
	-- Testroutine (force): sofort prüfen, damit nach dem Testfall nichts mehr nachläuft
	if C_Timer and not self.force then C_Timer.After(self.FOLLOW_DELAY, check) else check() end
	return text
end

function M1:CommandPass(label)
	if not self:Allowed() then return end
	if label == "im Kampf" then self.armed = false end
	local plates = self:Plates()
	local run = { art = "Befehl", label = label, flavor = ns.flavor, mode = ns:ThreatMode(), mobs = #plates,
		blocked0 = #(ns.blocked or {}), errors0 = ns.errorCount or 0 }
	if #plates == 0 then
		run.a, run.c = "kein feindlicher Mob mit Plakette", "kein feindlicher Mob mit Plakette"
		run.blocked0, run.errors0 = nil, nil
		self:Add(run)
		if not self.force then ns:Print(string.format(L.M1_NONE, label)) end
		return run
	end
	local t0 = Ms()
	run.a = self:PassThrough(plates[1].unit)
	run.c = self:OwnPlate(plates[1], label, function(follow)
		run.cFollow = follow
		if run.c then run.c = run.c .. " · " .. follow end
		run.blocked = #(ns.blocked or {}) - (run.blocked0 or 0)
		run.errors = (ns.errorCount or 0) - (run.errors0 or 0)
		run.blocked0, run.errors0 = nil, nil
		if not M1.force then ns:Print(string.format(L.M1_DONE, label, run.blocked or 0)) end
		if label == "im Kampf" then ns:PLHit("M1", string.format("Mobs %d, gesperrt %d", run.mobs or 0, run.blocked or 0)) end
	end)
	if run.cFollow and not run.c:find(run.cFollow, 1, true) then run.c = run.c .. " · " .. run.cFollow end
	run.ms = math.floor((Ms() - t0) * 100 + 0.5) / 100
	self:Add(run)
	return run
end

-- /ts messung kampf: jetzt "vor dem Kampf" messen und für den nächsten Kampf vormerken
function M1:Arm()
	if not ns:RequireDev() then return end
	self:Register()
	self.armed = true
	ns:Print(L.M1_ARMED)
	if not ns.Safe(API.InCombatLockdown(), false) then self:CommandPass("vor dem Kampf")
	elseif self.fight then self:CommandPass("im Kampf") end
end

------------------------------------------------------------
-- Ausgabe (Diagnose-Protokoll und /ts messung)
------------------------------------------------------------

function M1:RunLines(r)
	local out = {}
	local head = string.format("%s %s · v%s", r.z or "", r.art or "?", tostring(r.v)) .. (r.flavor and (" · " .. tostring(r.flavor)) or "")
	if r.art == "Instanz" then
		out[#out + 1] = head .. string.format(" · Instanz-ID %s · Kosten %.2f ms · Umgebung %s", tostring(r.inst), r.ms or 0,
			tostring(r.envChanged or "-"))
	elseif r.art == "Kampf" then
		out[#out + 1] = head .. string.format(" · Modus %s · Instanz %s · Gruppe %d · Rolle %s · Klasse %s · Mobs %d · Kosten %s ms · gesperrt %d · Fehler %d",
			tostring(r.mode), tostring(r.inst), r.group or 0, tostring(r.role), tostring(r.class), r.mobs or 0,
			r.ms and string.format("%.2f", r.ms) or "-", r.blocked or 0, r.errors or 0)
		if r.q then
			-- TS-M1-b kurze Form
			out[#out + 1] = "  (d) " .. r.q
			out[#out + 1] = "  (d) Ereignisse: " .. tostring(r.ev) .. " · Kampflog: " .. tostring(r.k)
			if r.p then out[#out + 1] = "  (b) Plakette (Ziel des Mobs: Blizzard-Zustand): " .. r.p end
			return out
		elseif r.ev then
			out[#out + 1] = "  (d) kein feindlicher Mob mit Plakette gefunden · Ereignisse: " .. tostring(r.ev) .. " · Kampflog: " .. tostring(r.k)
			return out
		end
		local d = r.sources
		if d then
			out[#out + 1] = string.format("  (d) UnitThreatSituation(player, Mob)=%s · UnitDetailedThreatSituation=%s (isTanking %s, Stufe %s, Prozent %s, Roh %s, Wert %s)",
				tostring(d.situation), tostring(d.detailed), tostring(d.isTanking), tostring(d.status), tostring(d.scaled), tostring(d.raw), tostring(d.value))
			out[#out + 1] = string.format("  (d) UnitThreatSituation(player)=%s · UnitThreatPercentageOfLead=%s · GetThreatStatusColor(Stufe)=%s · Ziel des Mobs: vorhanden %s, ist ich %s",
				tostring(d.situationPlayer), tostring(d.lead), tostring(d.color), tostring(d.targetExists), tostring(d.targetIsMe))
			out[#out + 1] = "  (d) Zielrahmen: " .. tostring(d.targetFrame)
		else
			out[#out + 1] = "  (d) kein feindlicher Mob mit Plakette gefunden"
		end
		out[#out + 1] = string.format("  (d) Ereignisse: SITUATION_UPDATE %d (Einheit %s), LIST_UPDATE %d (Einheit %s) · Kampflog: %s · %s",
			r.sit or 0, tostring(r.sitUnit or "-"), r.list or 0, tostring(r.listUnit or "-"), tostring(r.cleuDmg or "kein Schaden gesehen"),
			tostring(r.cleuCast or "kein Zauber gesehen"))
		local p = r.plates
		if p then
			out[#out + 1] = string.format("  (b) Plakette: Teile %s · aggroHighlight (Ziel des Mobs: Blizzard-Zustand) %s · verboten %d",
				JoinMap(p.keys), JoinMap(p.ah), p.forbidden or 0)
		end
	else
		out[#out + 1] = head .. string.format(" · %s · Modus %s · Mobs %d · Kosten %s ms · gesperrt %s · Fehler %s", tostring(r.label),
			tostring(r.mode), r.mobs or 0, r.ms and string.format("%.2f", r.ms) or "-", tostring(r.blocked or "-"), tostring(r.errors or "-"))
		out[#out + 1] = "  (a) " .. tostring(r.a)
		out[#out + 1] = "  (c) " .. tostring(r.c)
	end
	return out
end

-- Zeilen für das Diagnose-Protokoll (maxRuns: höchstens so viele Durchläufe, neueste zuerst)
function M1:Lines(maxRuns)
	local s = type(ThreatSentinelDB) == "table" and type(ThreatSentinelDB.m1) == "table" and ThreatSentinelDB.m1 or nil
	local runs = s and s.runs or {}
	local c = s and s.cost or {}
	local h = s and s.head or {}
	local out = { string.format("TS-M1 Messung (alle Spieler, nur lesen; Option m1Collect %s): v%s · %s · %s · Durchläufe %d · Kosten je Bild max %.2f ms, über %d ms: %d von %d",
		(ns.db and ns.db.m1Collect == false) and "AUS" or "EIN", tostring(h.v), tostring(h.build), tostring(h.z),
		#runs, c.max or 0, self.COST_LIMIT, c.over or 0, c.n or 0) }
	out[#out + 1] = "  " .. self.LEGEND .. " · Ablage: ThreatSentinelDB.m1 (head, env, runs, sum, cost) in SavedVariables/ThreatSentinel.lua"
	local env = s and s.env
	if type(env) == "table" then
		out[#out + 1] = "  (f) CVars: " .. (#(env.cvars or {}) > 0 and table.concat(env.cvars, ", ") or "-")
		out[#out + 1] = "  (f) nicht vorhanden: " .. (#(env.cvarsAbsent or {}) > 0 and table.concat(env.cvarsAbsent, ", ") or "-")
		out[#out + 1] = "  (e) Namen: " .. table.concat(env.names or {}, ", ")
	end
	if s and type(s.sum) == "table" and next(s.sum) then
		local keys = {}
		for k in pairs(s.sum) do keys[#keys + 1] = k end
		table.sort(keys)
		local parts = {}
		for _, k in ipairs(keys) do parts[#parts + 1] = k .. " ×" .. s.sum[k] end
		out[#out + 1] = "  ältere zusammengefasst: " .. table.concat(parts, ", ")
	end
	for i = 1, math.min(#runs, maxRuns or #runs) do
		for _, line in ipairs(self:RunLines(runs[i])) do out[#out + 1] = line end
	end
	return out
end

-- /ts messung: Bericht zeigen; dazu einmal die vollständige CVar-Liste des Clients (Befehl, nicht automatisch)
function M1:Show()
	if not ns:RequireDev() then return end
	local lines = self:Lines()
	local CC = Lookup("C_Console")
	if type(CC) == "table" and type(CC.GetAllCommands) == "function" then
		local t0 = Ms()
		local ok, all = pcall(CC.GetAllCommands)
		local found = {}
		if ok and type(all) == "table" then
			for _, c in ipairs(all) do
				local name = type(c) == "table" and c.command
				if type(name) == "string" and not ns.IsSecret(name) then
					local low = name:lower()
					if low:find("nameplate", 1, true) or low:find("threat", 1, true) or low:find("aggro", 1, true) then found[#found + 1] = name end
				end
			end
		end
		table.sort(found)
		local present = self:ReadCVars(found)
		lines[#lines + 1] = string.format("(f) alle CVars des Clients mit nameplate/threat/aggro (%d, %.1f ms): %s", #found, Ms() - t0,
			#present > 0 and table.concat(present, ", ") or "-")
	else
		lines[#lines + 1] = "(f) C_Console.GetAllCommands nicht vorhanden – nur die feste Liste"
	end
	local text = table.concat(lines, "\n")
	if ns.Test and ns.Test.ShowText then ns.Test:ShowText(text, L.M1_TITLE) else ns:Print(text) end
	return text
end

------------------------------------------------------------
-- Ereignisse: bei jedem Spieler angemeldet (TS-M1-b); die Handler kosten ausser im gemessenen Kampf nur einen Tabellen-Zugriff
------------------------------------------------------------
function M1:Register()
	if self.registered then return false end
	self.registered = true
	ns:On("PLAYER_REGEN_DISABLED", function() M1:BeginFight() end)
	ns:On("PLAYER_REGEN_ENABLED", function() M1:EndFight() end)
	ns:On("PLAYER_ENTERING_WORLD", function() if C_Timer then C_Timer.After(2, function() M1:OnInstance() end) end end)
	ns:On("UNIT_THREAT_SITUATION_UPDATE", function(_, unit) M1:OnThreatEvent("UNIT_THREAT_SITUATION_UPDATE", unit) end)
	ns:On("UNIT_THREAT_LIST_UPDATE", function(_, unit) M1:OnThreatEvent("UNIT_THREAT_LIST_UPDATE", unit) end)
	if ns.Alerts and ns.Alerts.cleuAllowed then ns:On("COMBAT_LOG_EVENT_UNFILTERED", function() M1:OnCombatLog() end) end
	return true
end
ns:On("PLAYER_LOGIN", function() M1:Register() end)
