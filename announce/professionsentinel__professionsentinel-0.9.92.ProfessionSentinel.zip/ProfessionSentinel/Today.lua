local _, ns = ...
local L = ns.L

-- "Heute herstellen": the most profitable crafts of all your professions right now – and per row
-- always the next step, one click each:
--   1. buy missing vendor reagents (vendor open)        -> buys exactly what is missing
--   2. buy missing AH reagents                          -> AHSentinel quick buy (or its sniper)
--   3. open the profession window                       -> hint (WoW does not let addons open it)
--   4. craft                                            -> crafts the count in the open window
--   5. list the products                                -> AHSentinel's sell tab with the item
-- The heavy part (which recipes pay off) is collected in the background in portions and kept (PS-TC1); a call only
-- adds the count for your money and bags (<= 2 ms).
-- Count per recipe: at most TODAY_MAX, and the reagents of one row at most 20 % of your gold
-- (the same capital protection as AHSentinel's "Heute tun").
-- Public API for AHSentinel ("Heute tun"): ProfessionSentinelAPI.TodayCrafts(max)

local TD = {}
ns.Today = TD

TD.MAX_ROWS = 6
TD.TODAY_MAX = 5
TD.ITEM_SHARE = 0.20

local function Money() return GetMoney and GetMoney() or 0 end

local function BagCount(id) return ns.GetItemCount(id, false) end

-- Which profession window is open right now (data profession id) – nil if none
function TD.OpenProfession()
    local shown = (ns.Sim and ns.Sim.prof) or (ProfessionsFrame and ProfessionsFrame:IsShown())
        or (TradeSkillFrame and TradeSkillFrame:IsShown())
    if not shown then return nil end
    local UI = ns.UI
    if UI and UI.CurrentProfession then
        local ok, prof = pcall(UI.CurrentProfession, UI)
        if ok and prof then return prof end
    end
    return nil
end

-- Collection (the heavy part, PS-TC1): learned recipes of all your professions with a product, priced, net > 0 per
-- craft, the product sold in the AH, the minimum profit reached and secured (no flag, not "sell raw").
-- Returns list { recipe, price, cap } and skipped { [cause] = n }. Calls ns.Jobs.Yield() between two recipes: as a
-- job it works in portions of at most ns.Jobs.BUDGET ms per frame (measured in the game: 153 ms in one piece).
-- inBuild (PS-RUN-1 a): called directly in the panel's portioned build (TD.Collection while the test routine draws at once):
-- also hand over to the next frame there (UI.Yield, never across a pcall – only TD.Collection passes true)
function TD.Collect(inBuild)
    local AD, P = ns.Advisor, ns.Prices
    local list, skipped = {}, {}
    if not (AD and P and P.SourceName()) then return list, skipped end
    local seen = {}
    local profs = {}
    for _, p in ipairs(ns.Scan and ns.Scan:PlayerProfessions() or {}) do profs[#profs + 1] = p.id end
    if ns.Sim and ns.Sim.prof then profs[#profs + 1] = ns.Sim.prof end
    local PS = ns.PriceSource
    local pct = PS and PS.MinProfitPct() or 20
    local JY = ns.Jobs and ns.Jobs.Yield or function() end
    local function Yield()
        JY()
        if inBuild and ns.UI and ns.UI.Yield then ns.UI.Yield() end
    end
    -- not secured entries are shown nowhere (decision 13 Nov. 22:26), only counted with their cause for the test
    -- report / diagnostics: skipped[cause] = n
    local function Skip(cause) skipped[cause] = (skipped[cause] or 0) + 1 end
    for _, prof in ipairs(profs) do
        if not seen[prof] then
            seen[prof] = true
            local rank = ns.Scan:Rank(prof)
            if ns.EffectiveRank then rank = ns.EffectiveRank(rank) end
            for _, r in ipairs(ns.ByProf[prof] or {}) do
                if r.out and ns.IsLearned(r) and (rank == nil or AD.Reachable(r, rank)) then
                    -- the gold calculation (same as tooltip and gold ranking: market judgement included)
                    -- PS-P1: each recipe price is one measured piece of the job (the report shows the longest)
                    local J = ns.Jobs
                    -- PS-P1 (Ingametest 27.11.: one AHSentinel.API.WorthUpTo 18.4 ms): a new WorthUpTo alone in its slice –
                    -- hand over before (when this slice already worked) and after it; kept for the session (P.Worth)
                    if J and J.Running and J.Running() and P.WorthPending and P.WorthPending(r) then
                        J.Hand(J.HAND_BEFORE_MS)
                        local wt0 = J.PieceStart()
                        P.PrefetchWorth(r)
                        if wt0 then J.PieceEnd(wt0, r) end
                        J.Hand(0)
                    end
                    local pt0 = J and J.PieceStart and J.PieceStart()
                    local pr = P.Recipe(r, true)
                    if pt0 then J.PieceEnd(pt0, r) end
                    -- only what sells and earns the minimum profit; at most what sells in ~2 days (review 0.9.33, 5)
                    local cap = PS and PS.SellCap(r.out)
                    -- a flooded market (B5, answer 16 Nov. 01:18): "do not craft now" – the list never contradicts the tooltip
                    local flood = pr.state == "flut"
                    if pr.known and pr.flag then Skip(pr.flag)
                    elseif pr.known and pr.direction == "raw" then Skip("raw")
                    elseif pr.known and flood then Skip("flut") end
                    if pr.known and pr.net > 0 and pr.valueSource == "ah" and pr.cost > 0 and cap ~= 0 and not pr.flag
                        and pr.direction ~= "raw" and not flood
                        and pr.net >= pr.cost * pct / 100 then
                        list[#list + 1] = { recipe = r, price = pr, cap = cap }
                    end
                    Yield()
                end
            end
        end
    end
    return list, skipped
end

-- what the collection depends on (anything else changes only the count or the next step, computed on every call)
function TD.CacheKey()
    local S = ns.Sim
    local AD, P, PS = ns.Advisor, ns.Prices, ns.PriceSource
    return table.concat({ tostring(AD and AD.stamp), tostring(S), tostring(S and S.known), tostring(S and S.rank),
        tostring(S and S.prof), tostring(P and P.SourceName and P.SourceName()), tostring(PS and PS.MinProfitPct and PS.MinProfitPct()),
        tostring(ns.CharKey and ns.CharKey()), tostring(ns.Flavor) }, "|")
end

-- Cache (PS-TC1): answered in <= 2 ms; computed again as a job in portions after a scan/recipe/price change (ns.Advisor.
-- Invalidate) or when older than TD.CACHE_MAX seconds (prices of other sources move without a message). Until a new
-- collection is ready the last one is used (never an empty answer just because a recalculation is running).
TD.CACHE_MAX = 300
TD.WARM_DELAY = 2
TD.cache = nil      -- { list, skipped, key, at }

local function Now() return (GetTime and GetTime()) or 0 end

function TD.Rebuild()
    local key = TD.CacheKey()
    ns.Jobs.Add("heute", function()
        local list, skipped = TD.Collect()
        TD.cache = { list = list, skipped = skipped, key = key, at = Now() }
        TD.skipped = skipped
        TD.builds = (TD.builds or 0) + 1
        -- a visible "craft today" list shows the new numbers
        if not ns.Jobs.Sync() and ns.UI and ns.UI.PanelVisible and ns.UI.PanelVisible() and ns.UI.RequestRefresh then
            ns.UI.RequestRefresh("Heute herstellen")
        end
    end, { quiet = true, pass = true })
end

-- inputs changed (Advisor.Invalidate): collect again a moment later in the background (several changes -> one job)
local warmPending = false
function TD.Invalidate()
    if ns.Jobs.Sync() then return end
    if warmPending then return end
    warmPending = true
    ns.API.TimerAfter(TD.WARM_DELAY, function()
        warmPending = false
        TD.Rebuild()
    end)
end

-- the collection to use now: in the test routine always fresh; in the game the cache (computed again when stale)
function TD.Collection()
    if ns.Jobs.Sync() then
        local list, skipped = TD.Collect(true)
        TD.skipped = skipped
        return list
    end
    local c = TD.cache
    local key = TD.CacheKey()
    if not c or c.key ~= key or Now() - c.at > TD.CACHE_MAX then
        if not ns.Jobs.Pending("heute") then TD.Rebuild() end
    end
    return c and c.list or {}
end

-- PS-RUN-1 (a): inside the panel's portioned build, hand over to the next frame when its budget is used (no-op elsewhere;
-- every caller calls this directly, never inside a pcall)
local function UIYield() if ns.UI and ns.UI.Yield then ns.UI.Yield() end end

-- candidates: the collection with the count for the money you have and your bags; best total gain first
-- PS-I8 (T269, Ingametest 0.9.81: a call from the cache 3.0 ms, rule <= 2 ms): the choice of the best rows depends only on the
-- collection and your gold – every call went through the whole collection again. Kept per (collection table, gold, limits);
-- only the plan of the <= MAX_ROWS rows (your bags right now, the merchant) is made on every call, on fresh tables.
local chosen = { src = nil }
function TD.Candidates(countFn)
    local coll = TD.Collection()
    local money = Money()
    local base
    local c0 = chosen
    if c0.src == coll and c0.money == money and c0.max == TD.TODAY_MAX and c0.share == TD.ITEM_SHARE and c0.rows == TD.MAX_ROWS then
        base = c0.list
    else
        base = {}
        for _, c in ipairs(coll) do
            UIYield()
            local pr, cap = c.price, c.cap
            local count = TD.TODAY_MAX
            if cap then count = math.min(count, cap) end
            if money > 0 then count = math.min(count, math.floor(money * TD.ITEM_SHARE / pr.cost)) end
            if count >= 1 then
                base[#base + 1] = { recipe = c.recipe, price = pr, count = count, net = pr.net * count, perCraft = pr.net }
            end
        end
        table.sort(base, function(a, b) return a.net > b.net end)
        for i = #base, TD.MAX_ROWS + 1, -1 do base[i] = nil end
        chosen = { src = coll, money = money, max = TD.TODAY_MAX, share = TD.ITEM_SHARE, rows = TD.MAX_ROWS, list = base }
    end
    local out = {}
    for i, b in ipairs(base) do
        out[i] = { recipe = b.recipe, price = b.price, count = b.count, net = b.net, perCraft = b.perCraft }
    end
    for _, e in ipairs(out) do UIYield(); TD.Plan(e, countFn) end
    return out
end
function TD.ForgetChoice() chosen = { src = nil } end      -- test routine

-- what is missing for the count, and the next step
function TD.Plan(e, countFn)
    countFn = countFn or BagCount
    local r, P = e.recipe, ns.Prices
    e.missing, e.missingVendor, e.missingAH = {}, 0, 0
    for i = 1, #r.reagents, 2 do
        local id, n = r.reagents[i], r.reagents[i + 1]
        local need = n * e.count - (countFn(id) or 0)
        if need > 0 then
            -- made cheaper yourself ("craft"): buy its materials instead (review 0.9.33, point 4)
            for _, x in ipairs(P.ExpandNeed(id, need)) do
                local nb = x.id == id and x.count or (x.count - (countFn(x.id) or 0))
                if nb > 0 then
                    e.missing[#e.missing + 1] = { id = x.id, count = nb, origin = x.origin, unit = x.unit }
                    if x.origin == "vendor" then e.missingVendor = e.missingVendor + 1 else e.missingAH = e.missingAH + 1 end
                end
            end
        end
    end
    e.have = r.out and (countFn(r.out) or 0) or 0
    local merchant = ns.Plan and ns.Plan.MerchantOpen()
    if e.have >= e.count or (e.have > 0 and #e.missing > 0) then
        -- the batch is crafted (or products from earlier crafts are waiting): list them first
        e.step = "sell"
    elseif e.missingVendor > 0 and merchant then
        e.step = "vendor"
    elseif e.missingAH > 0 then
        e.step = "ah"
    elseif e.missingVendor > 0 then
        e.step = "goVendor"
    elseif TD.OpenProfession() == r.prof then
        e.step = "craft"
    elseif e.have > 0 then
        e.step = "sell"
    else
        e.step = "openProf"
    end
    return e
end

function TD.StepText(e)
    local P = ns.Prices
    if e.step == "vendor" then
        local sum = 0
        for _, m in ipairs(e.missing) do if m.origin == "vendor" then sum = sum + m.unit * m.count end end
        return string.format(L.TODAY_STEP_VENDOR, P.MoneyPlain(sum))
    elseif e.step == "ah" then
        local sum = 0
        for _, m in ipairs(e.missing) do if m.origin ~= "vendor" then sum = sum + m.unit * m.count end end
        return string.format(L.TODAY_STEP_AH, e.missingAH, P.MoneyPlain(sum))
    elseif e.step == "goVendor" then
        return L.TODAY_STEP_GOVENDOR
    elseif e.step == "craft" then
        return string.format(L.TODAY_STEP_CRAFT, e.count)
    elseif e.step == "sell" then
        return string.format(L.TODAY_STEP_SELL, e.have)
    end
    return string.format(L.TODAY_STEP_OPENPROF, ns.ProfName(e.recipe.prof))
end

---------------------------------------------------------------------------
-- Actions
---------------------------------------------------------------------------
local function AHS() return ns.Foreign("AHAnalyzerPro") end

-- buy the missing vendor reagents of one row at the open vendor
function TD.BuyVendor(e)
    local PL = ns.Plan
    if not (PL and PL.MerchantOpen()) then ns.Print(L.PLAN_NO_MERCHANT); return false end
    local saved = PL.current
    local list = {}
    for _, m in ipairs(e.missing) do
        if m.origin == "vendor" then list[#list + 1] = { id = m.id, missing = m.count, origin = "vendor" } end
    end
    PL.current = { list = list }
    local n = PL.BuyFromVendor()
    PL.current = saved
    return n > 0
end

-- AH reagents: AHSentinel's quick buy (search + one click per purchase, never above max price);
-- older AHSentinel: its sniper with market value + 10 %
function TD.BuyAH(e)
    local A = AHS()
    local Q = A and A.Today and A.Today.QuickBuy
    local done = 0
    for _, m in ipairs(e.missing) do
        if m.origin ~= "vendor" and m.unit and m.unit > 0 then
            local maxPrice = math.floor(m.unit * 1.10)
            if Q then
                local ok, err = pcall(Q, A.Today, m.id, m.count, maxPrice, ns.RecipeName(e.recipe))
                if ok then done = done + 1 else ns.CountError("AHSentinel:Today.QuickBuy", err) end
            end
        end
    end
    if done > 0 then return true end
    -- fallback: sniper targets
    local targets = {}
    for _, m in ipairs(e.missing) do
        if m.origin ~= "vendor" and m.unit and m.unit > 0 then
            targets[#targets + 1] = { id = m.id, maxPrice = math.floor(m.unit * 1.10), qty = m.count }
        end
    end
    if #targets == 0 then return false end
    return ns.Disenchant.SendToSniper(targets, ns.RecipeName(e.recipe), L.PLAN_SNIPE_DONE) > 0
end

---------------------------------------------------------------------------
-- Loss guard before crafting (order B4, model AHSentinel's guard when posting, decision 15 Nov. 19:15
-- "the warning is top – it simply has to work").
-- Right before a gold craft (a row of "craft today" / the "now" card / AHSentinel's "Heute tun") the price is computed
-- again: if the sale after the AH cut brings less than the materials cost (P.Recipe net < 0, market prices – real cost
-- basis only once AHSentinel delivers it, B1), a warning with raid-warning sound comes first:
--   [Craft anyway]  crafts at once, no lock and no second question (lesson POST-BLOCK1)
--   [Instead: X]    the best other row of "craft today" – offered only when it passes the SAME check right now, so the
--                   suggestion can never trigger the warning again (lesson WS-LOOP1); clicking it does that row's next step.
--                   Should the prices change before the click, that warning has no suggestion of its own (ends after one step)
--   [Cancel]
-- Crafts without a gold row (skill crafts: no price on the entry) are never questioned.
---------------------------------------------------------------------------
TD.WARN_KEY = "PROFESSIONSENTINEL_CRAFT_WARN"

-- nil = fine; otherwise { perCraft (negative), cost, value, count }
function TD.Loss(e)
    if not (e and e.recipe and e.price) then return nil end
    local P = ns.Prices
    if not (P and P.Recipe) then return nil end
    local pr = P.Recipe(e.recipe, true)
    if not (pr and pr.known and type(pr.net) == "number" and pr.cost and pr.cost > 0) then return nil end
    if pr.net >= 0 then return nil end
    return { perCraft = pr.net, cost = pr.cost, value = pr.value or 0, count = e.count or 1 }
end

-- the suggestion: the best other row that passes the same check now (nil when there is none)
function TD.Suggestion(e)
    for _, o in ipairs(TD.Candidates()) do
        if o.recipe ~= e.recipe and o.recipe.spell ~= e.recipe.spell and not TD.Loss(o) then return o end
    end
    return nil
end

function TD.WarnText(e, loss)
    local P = ns.Prices
    return string.format(L.TODAY_WARN, ns.RecipeName(e.recipe), P.MoneyPlain(loss.cost), P.MoneyPlain(loss.value),
        P.MoneyPlain(-loss.perCraft), loss.count, P.MoneyPlain(-loss.perCraft * loss.count))
end

function TD.Warn(e, loss, preview)
    -- a warning that comes from a suggestion click (prices changed in between) offers no further suggestion: the chain
    -- always ends after one step
    local sug = (not TD.fromSuggestion) and TD.Suggestion(e) or nil
    -- the sample (/ps warnprobe, point WARN of the Prüfliste): the same window with all three buttons, nothing is crafted
    if preview and not sug then sug = e end
    TD.warned = { entry = e, loss = loss, suggestion = sug }
    if ns.Alerts and ns.Alerts.PlaySound then ns.Alerts.PlaySound() end
    if FlashClientIcon then pcall(FlashClientIcon) end
    local text = (preview and L.TODAY_WARN_PREVIEW_HEAD or "") .. TD.WarnText(e, loss)
    if not (StaticPopupDialogs and StaticPopup_Show) then ns.Print(text); return false end
    local DE = ns.Disenchant
    StaticPopupDialogs[TD.WARN_KEY] = {
        text = DE and DE.PopupText and DE.PopupText(text) or text,
        button1 = L.TODAY_WARN_ANYWAY,
        button2 = CANCEL or L.TODAY_WARN_CANCEL,
        button3 = sug and string.format(L.TODAY_WARN_INSTEAD, ns.RecipeName(sug.recipe)) or nil,
        timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3, showAlert = true,
        OnAccept = preview and function() ns.Print(L.TODAY_WARN_PREVIEW) end or function() TD.Craft(e, true) end,
        OnAlt = preview and function() ns.Print(L.TODAY_WARN_PREVIEW) end or sug and function()
            TD.fromSuggestion = true
            local ok, err = pcall(TD.Run, sug)
            TD.fromSuggestion = nil
            if not ok then ns.CountError("Today.Suggestion", err) end
        end or nil,
    }
    StaticPopup_Show(TD.WARN_KEY)
    return false
end

-- /ps warnprobe: the real window with a made-up loss on a recipe of the open profession (nothing is crafted)
function TD.WarnPreview()
    local e = TD.Candidates()[1]
    if not e then
        local prof = TD.OpenProfession()
        for _, r in ipairs(prof and ns.ByProf and ns.ByProf[prof] or {}) do
            if ns.IsLearned and ns.IsLearned(r) then e = { recipe = r, count = 1, price = {} }; break end
        end
    end
    if not e then ns.Print(L.TODAY_WARN_PREVIEW_NONE); return false end
    TD.Warn(e, { perCraft = -1250, cost = 5000, value = 3750, count = 1 }, true)
    return true
end

-- craft in the open profession window (anyway = true: after "Craft anyway", no second check)
function TD.Craft(e, anyway)
    local r = e.recipe
    if TD.OpenProfession() ~= r.prof then ns.Print(string.format(L.TODAY_STEP_OPENPROF, ns.ProfName(r.prof))); return false end
    if not anyway then
        local loss = TD.Loss(e)
        if loss then return TD.Warn(e, loss) end
    end
    if ns.UsesModernProfessions and ns.CanAct("craft") then
        return ns.Act("craft", r.spell, e.count) and true or false
    end
    local wanted = { [r.name:lower()] = true }
    if r.nameEN and r.nameEN ~= "" then wanted[r.nameEN:lower()] = true end
    local A = ns.API
    if A.GetNumTradeSkills and A.GetTradeSkillInfo and ns.CanAct("tradeskill") then
        for i = 1, A.GetNumTradeSkills() do
            local name = A.GetTradeSkillInfo(i)
            if name and wanted[name:lower()] then
                return ns.Act("tradeskill", i, e.count) and true or false
            end
        end
    end
    ns.Print(L.TODAY_NOT_FOUND)
    return false
end

-- list the products: AHSentinel's quick sell, otherwise its sell tab with the item selected
function TD.Sell(e)
    local A = AHS()
    local id = e.recipe.out
    if A and A.Today and A.Today.QuickSell then
        local ok, err = pcall(A.Today.QuickSell, A.Today, id, e.have)
        if ok then return true end
        ns.CountError("AHSentinel:Today.QuickSell", err)
    end
    if A and A.UI and A.UI.SelectTab then
        local function try(where, fn, ...)
            local ok, r = pcall(fn, ...)
            if not ok then ns.CountError(where, r) end
            return ok and r or nil
        end
        if A.UI.Show then try("AHSentinel:UI.Show", A.UI.Show, A.UI) end
        try("AHSentinel:UI.SelectTab", A.UI.SelectTab, A.UI, "sell")
        local tab = A.UI.GetTab and try("AHSentinel:UI.GetTab", A.UI.GetTab, A.UI, "sell")
        if type(tab) == "table" and type(tab.panel) == "table" and tab.panel.Select then
            try("AHSentinel:UI.Select", tab.panel.Select, tab.panel, id)
        end
        return true
    end
    ns.Print(L.TODAY_NEED_AHS)
    return false
end

-- one click: the next step of a row
function TD.Run(e)
    if ns.FreshPrices then ns.FreshPrices() end          -- gold safety: the values of right now (Prices.lua)
    if ns.BlockedInCombat() then return false end
    TD.Plan(e)
    local ok
    if e.step == "vendor" then ok = TD.BuyVendor(e)
    elseif e.step == "ah" then ok = TD.BuyAH(e)
    elseif e.step == "craft" then ok = TD.Craft(e)
    elseif e.step == "sell" then ok = TD.Sell(e)
    elseif e.step == "goVendor" then ns.Print(L.TODAY_STEP_GOVENDOR)
    else ns.Print(string.format(L.TODAY_STEP_OPENPROF, ns.ProfName(e.recipe.prof))) end
    if C_Timer then C_Timer.After(1.5, function() if ns.RefreshAll then ns.RefreshAll() end end) end
    return ok
end

---------------------------------------------------------------------------
-- Public API for AHSentinel ("Heute tun") and other addons
--   ProfessionSentinelAPI.version = 2 (2: KnownRecipes, TodayCraftsReady; answers from a cache)
--   ProfessionSentinelAPI.TodayCrafts(max) -> list of {
--       itemID, recipeName, count, gold (net for all crafts, after 5 % AH cut), perCraft, cost (reagents per craft),
--       capital (money needed for the missing reagents), step ("vendor"|"ah"|"goVendor"|"craft"|"sell"|"openProf"),
--       stepText, run = function() – does the next step,
--       safe (true: PM3 secured – no stale/bought-out/thin data, not "sell raw"; not secured entries are never listed),
--       spellID, prof (profession ID), materials = { {itemID, count} per craft }, made (products per craft),
--       canCraft (learned and reachable with the current skill), cooldown (true for transmutes, mooncloth, salt),
--       highMargin (over 300 % without a second sign) }
---------------------------------------------------------------------------
_G.ProfessionSentinelAPI = _G.ProfessionSentinelAPI or {}
local API = _G.ProfessionSentinelAPI
API.version = 2
-- Hinweis 18.11.2026 06:45: true while our test routine runs (then our saved data may hold test data – other addons read
-- nothing of ProfessionSentinel meanwhile)
function API.TestRunning()
    local TR = ns.TestRoutine
    return (TR and TR.Running and TR.Running()) and true or false
end
function API.TodayCrafts(max)
    local t0 = ns.DiagClock and ns.DiagClock()
    local ok, list = (ns.TaktPCall or pcall)(TD.Candidates)      -- in a test-routine step it may hand over (Ingametest 0.9.72)
    if not ok then ns.CountError("API.TodayCrafts", list) end
    if not ok or type(list) ~= "table" then return {} end
    local out = {}
    for i, e in ipairs(list) do
        if max and i > max then break end
        local capital = 0
        for _, m in ipairs(e.missing) do capital = capital + (m.unit or 0) * m.count end
        local mats = {}
        for k = 1, #(e.recipe.reagents or {}), 2 do
            mats[#mats + 1] = { itemID = e.recipe.reagents[k], count = e.recipe.reagents[k + 1] }
        end
        out[#out + 1] = {
            itemID = e.recipe.out, recipeName = ns.RecipeName(e.recipe), count = e.count,
            gold = math.floor(e.net), perCraft = math.floor(e.perCraft), cost = math.floor(e.price.cost),
            capital = math.floor(capital), step = e.step, stepText = TD.StepText(e),
            run = function() return TD.Run(e) end,
            -- for AHSentinel's crafting chain (HK-P): secured, what is needed, can it be crafted
            safe = not e.price.flag and e.price.direction ~= "raw",
            spellID = e.recipe.spell, prof = e.recipe.prof, made = (e.recipe.outMin or 1),
            materials = mats, canCraft = true, cooldown = e.price.cooldown == true,
            highMargin = e.price.highMargin == true,
        }
    end
    if t0 then ns.Perf("API TodayCrafts", t0) end      -- self-check (PS-TC1): longest call, red over 16 ms
    return out
end

-- PS-DOCK1 (hint 20:15): false when the player switched ProfessionSentinel's panel off at the profession window
-- (option "open with the profession window") – then AHSentinel shows its own profit window again
function API.IsEnabled() return not (ns.UI and ns.UI.AutoOpen and not ns.UI.AutoOpen()) end

-- ready: the background collection exists (false right after logging in, for a few seconds)
function API.TodayCraftsReady() return TD.cache ~= nil end

---------------------------------------------------------------------------
-- PS-API1: ProfessionSentinelAPI.KnownRecipes(charKey) -> list, ready
--   charKey: nil = the logged-in character, otherwise the key AHSentinel uses for a remembered character ("Name-Realm").
--   list (read only, shared with the cache): per learned recipe with a product {
--       spellID, recipeID (= spellID), productID, made (products per craft, minimum), madeMax,
--       materials = { {itemID, count} per craft }, prof (profession ID), skill (the character's skill),
--       color ("orange"|"yellow"|"green"|"grey"|"red" = not yet learnable), yellow, green, grey (thresholds) }
--   ready: false while the list is still being built in the background (a few seconds after logging in or a change)
--   No names in the result, only IDs and numbers. Answered from a cache (<= 2 ms); built as a job in portions.
---------------------------------------------------------------------------
local KA = {}
ns.KnownAPI = KA
KA.cache = {}           -- charKey -> { list, key }
KA.ids = {}             -- charKey -> number (job names carry no names)

local function CharFor(charKey)
    local chars = ns.db and type(ns.db.chars) == "table" and ns.db.chars or {}
    local me = ns.CharKey and ns.CharKey()
    local key = charKey or me
    if ns.FindCharKey then key = ns.FindCharKey(key) end      -- the other addon's key with/without realm (Forever: realm empty)
    local c = chars[key]
    if type(c) ~= "table" or (c.flavor ~= nil and c.flavor ~= ns.Flavor) then return nil, key, key == me end
    return c, key, key == me
end

-- what the list depends on: learned recipes and skills (Advisor.Invalidate counts every such change in AD.stamp)
function KA.Key(charKey)
    local c, key, isMe = CharFor(charKey)
    local n = 0
    for _ in pairs(c and type(c.known) == "table" and c.known or {}) do n = n + 1 end
    local S = isMe and ns.Sim or nil
    return table.concat({ key, tostring(ns.Advisor and ns.Advisor.stamp), n, tostring(S), tostring(S and S.known),
        tostring(S and S.rank), tostring(ns.Flavor) }, "|")
end

function KA.Build(charKey)
    local c, _, isMe = CharFor(charKey)
    local out = {}
    if not c or type(c.profs) ~= "table" then return out end
    local LL = ns.Lifeline
    local Yield = ns.Jobs and ns.Jobs.Yield or function() end
    local profs = {}
    for prof in pairs(c.profs) do profs[#profs + 1] = prof end
    table.sort(profs)
    for _, prof in ipairs(profs) do
        local p = c.profs[prof]
        local rank = type(p) == "table" and tonumber(p.rank) or nil
        if isMe then
            rank = ns.Scan and ns.Scan:Rank(prof) or rank
            if ns.EffectiveRank then rank = ns.EffectiveRank(rank) end
        end
        for _, r in ipairs(ns.ByProf[prof] or {}) do
            local known
            if isMe then known = ns.IsLearned(r) else known = type(c.known) == "table" and c.known[r.spell] end
            if known and r.out then
                -- materials only in the list (never kept on the recipe: memory goes with the list, review T145)
                local mats = {}
                for k = 1, #(r.reagents or {}), 2 do mats[#mats + 1] = { itemID = r.reagents[k], count = r.reagents[k + 1] } end
                local calc = LL and rank and LL.Calc(r, rank)
                out[#out + 1] = {
                    spellID = r.spell, recipeID = r.spell, productID = r.out, made = r.outMin or 1, madeMax = r.outMax or r.outMin or 1,
                    materials = mats, prof = r.prof, skill = rank, color = calc and calc.state or nil,
                    yellow = r.yellow, green = r.green, grey = r.grey,
                }
            end
            Yield()
        end
    end
    return out
end

-- the list of one character again in the background (one job per character; the name carries no character name)
function KA.Schedule(charKey)
    local _, key = CharFor(charKey)
    if not KA.ids[key] then KA.nextId = (KA.nextId or 0) + 1; KA.ids[key] = KA.nextId end
    local jobName = "rezepte-api " .. KA.ids[key]
    if ns.Jobs.Pending(jobName) then return end
    ns.Jobs.Add(jobName, function()
        local k = KA.Key(charKey)
        KA.cache[key] = { list = KA.Build(charKey), key = k }
    end, { quiet = true })
end

function KA.Invalidate()
    if ns.Jobs.Sync() then return end
    -- the logged-in character's list again (others are built when asked for)
    local key = ns.CharKey and ns.CharKey()
    if key and KA.cache[key] then KA.Schedule(nil) end
end

function KA.Get(charKey)
    if ns.Jobs.Sync() then return KA.Build(charKey), true end
    local _, key = CharFor(charKey)
    local c = KA.cache[key]
    if c and c.key == KA.Key(charKey) then return c.list, true end
    KA.Schedule(charKey)
    if c then return c.list, false end      -- the last list until the new one is ready
    return {}, false
end

function API.KnownRecipes(charKey)
    local t0 = ns.DiagClock and ns.DiagClock()
    local ok, list, ready = (ns.TaktPCall or pcall)(KA.Get, charKey)      -- may hand over in a test-routine step (0.9.72)
    if not ok then ns.CountError("API.KnownRecipes", list); list, ready = {}, false end
    if t0 then ns.Perf("API KnownRecipes", t0) end
    return list, ready
end

-- warm up after logging in (AHSentinel asks every 15 minutes; the first answer should not be empty)
local warm = ns.AddEventFrame(CreateFrame("Frame"), "Today")
warm:RegisterEvent("PLAYER_LOGIN")
warm:SetScript("OnEvent", function()
    if ns.API.TimerAfter then
        ns.API.TimerAfter(10, function()
            if ns.Jobs.Sync() then return end
            TD.Rebuild()
            KA.Get(nil)
        end)
    end
end)
