-- GuildSentinel - Comm.lua
-- Addon-Nachrichten: Serializer, Mehrteil-Nachrichten, Typen. Senden und Empfangen über GoldSentinelSync.lua.

local ADDON, ns = ...
local L = ns.L
local Comm = {}
ns.Comm = Comm

Comm.PREFIX = "GuildSentinel"
Comm.handlers = {}
Comm.users = {}          -- [Name] = { v = Version, t = zuletzt gesehen }
-- über die Gruppe (auch Spieler anderer Gilden) und alte Kanäle sind nur diese Nachrichten erlaubt
Comm.channelTypes = { LFG = true, LFGX = true, LFGQ = true }

------------------------------------------------------------
-- Serializer (ohne loadstring: Strings, Zahlen, Booleans, Tabellen)
------------------------------------------------------------
local function esc(s)
	return (s:gsub("~", "~0"):gsub("%^", "~1"):gsub("|", "~2"):gsub("\n", "~3"):gsub("\t", "~4"):gsub("\r", ""))
end

local UNESC = { ["0"] = "~", ["1"] = "^", ["2"] = "|", ["3"] = "\n", ["4"] = "\t" }
local function unesc(s)
	return (s:gsub("~(%d)", UNESC))
end

local function encode(v, out)
	local t = type(v)
	if t == "string" then
		out[#out + 1] = "s" .. esc(v) .. "^"
	elseif t == "number" then
		out[#out + 1] = "n" .. tostring(v) .. "^"
	elseif t == "boolean" then
		out[#out + 1] = v and "T" or "F"
	elseif t == "table" then
		out[#out + 1] = "{"
		for k, val in pairs(v) do
			local kt, vt = type(k), type(val)
			if (kt == "string" or kt == "number") and (vt == "string" or vt == "number" or vt == "boolean" or vt == "table") then
				encode(k, out)
				encode(val, out)
			end
		end
		out[#out + 1] = "}"
	end
end

function Comm.Serialize(v)
	local out = {}
	encode(v, out)
	return table.concat(out)
end

local function decode(s, pos, depth)
	if depth > 20 then error("deep") end
	local c = s:sub(pos, pos)
	if c == "s" then
		local e = s:find("^", pos + 1, true)
		if not e then error("str") end
		return unesc(s:sub(pos + 1, e - 1)), e + 1
	elseif c == "n" then
		local e = s:find("^", pos + 1, true)
		if not e then error("num") end
		return tonumber(s:sub(pos + 1, e - 1)), e + 1
	elseif c == "T" then
		return true, pos + 1
	elseif c == "F" then
		return false, pos + 1
	elseif c == "{" then
		local t = {}
		pos = pos + 1
		while true do
			local nc = s:sub(pos, pos)
			if nc == "}" then return t, pos + 1 end
			if nc == "" then error("table") end
			local k, v
			k, pos = decode(s, pos, depth + 1)
			v, pos = decode(s, pos, depth + 1)
			if k ~= nil then t[k] = v end
		end
	end
	error("token " .. tostring(c))
end

function Comm.Deserialize(s)
	if not s or s == "" then return nil end
	local ok, v = pcall(decode, s, 1, 0)
	if ok then return v end
	return nil
end

------------------------------------------------------------
-- Senden und Empfangen über die gemeinsame Datei GoldSentinelSync.lua (seit 0.9.20)
-- Sie sendet nur über Gilde, Gruppe/Raid und Flüstern (nie über einen eigenen Kanal – in WoW Forever kommen
-- Addon-Nachrichten dort nicht an), drosselt für alle GoldSentinel-Addons zusammen, erkennt Dubletten und eigene
-- Nachrichten. Die Kennung "GuildSentinel" bleibt: Nachrichten alter Versionen anderer Spieler kommen weiter an.
-- Hier bleibt nur: Serializer, Teilen langer Nachrichten, Zuordnung zu den Nachrichtentypen.
------------------------------------------------------------
local Sync = _G.GoldSentinelSync
Comm.ep = Sync and Sync.Register(ADDON, Comm.PREFIX, ns.version) or nil
local MAX_LEN = Sync and Sync.MAX_PAYLOAD or 230
local CHUNK = MAX_LEN - 30          -- Platz für "~M\t<id>\t<i>\t<n>\t"
local counter = 0

-- Kanal-Wort von GuildSentinel -> Umfang der gemeinsamen Datei
--   "GUILD" -> nur Gilde · "GROUP" -> nur Gruppe/Raid · "WHISPER" -> an target · "ALL" -> Gilde und Gruppe
--   "NET"   -> Gilde, Gruppe und das Flüster-Netz von GoldSentinelSync 2 (alle Spieler mit GoldSentinel-Addons)
-- Ins Netz geht nur die Gruppensuche für den ganzen Server (LFG, LFGX). Alles andere ist gildenintern.
-- "CHANNEL" (eigener Kanal alter Versionen) gibt es nicht mehr: wird wie "GROUP" behandelt.
local function Opts(channel, target)
	if channel == "WHISPER" then return { target = target } end
	if channel == "GROUP" or channel == "CHANNEL" then return { scope = "group" } end
	if channel == "NET" then return nil end
	if channel == "ALL" then return { net = false } end
	return { scope = "guild" }
end
Comm.Opts = Opts

local function Out(msg, channel, target)
	if not Comm.ep then return false end
	return Comm.ep:Send(msg, Opts(channel, target))
end
-- Nachrichten, die zu einer abschaltbaren Funktion gehören (ist sie aus, wird nichts gesendet und nichts angenommen)
Comm.FEATURE = {
	LFG = "group", LFGJ = "group", LFGQ = "group", LFGX = "group", FREE = "group", FREEQ = "group",
	EVT = "events", EVTR = "events", EVTS = "events",
	SVC = "board", SVCS = "board", MKT = "board",
	POLL = "poll", POLLS = "poll", POLLX = "poll", VOTE = "poll",
	ATT = "attune", ATTS = "attune",
	GOAL = "goals", MILES = "goals",
	THX = "thanks", THXS = "thanks",
	PROF = "prof", CREQ = "prof",
	CD = "cooldowns", CDS = "cooldowns",
	RULES = "recruit", RACK = "recruit", RACKS = "recruit", WEL = "recruit",
	AWAY = "away", MENT = "mentor",
	ACT = "times",
	ADDONS = "addons", ADDONSQ = "addons", ADDALL = "addons",
	ONOTE = "lead", ONOTES = "lead", GONE = "lead", PROB = "lead",
	GEAR = "gear", GEARS = "gear",
	ASK = "ask", ASKS = "ask",
}

-- Typ, Daten, Kanal ("GUILD", "GROUP", "ALL" oder "WHISPER"), Ziel. (high: früher Vorrang in der eigenen
-- Warteschlange; die gemeinsame Datei hat eine Warteschlange für alle – der Wert wird nicht mehr gebraucht)
function Comm:Send(msgType, data, channel, target, high)
	-- Testmodus: nichts verlassen lassen
	if ns.Test and ns.Test:Active() then return end
	if not ns.Feature(Comm.FEATURE[msgType]) then return end
	channel = channel or "GUILD"
	if channel == "CHANNEL" then channel = "GROUP" end
	if channel == "GUILD" and not IsInGuild() then return end
	if (channel == "GROUP" or channel == "NET") and not Comm.channelTypes[msgType] then return end
	if channel == "WHISPER" and (not target or target == "") then return end
	local payload = msgType .. "\t" .. Comm.Serialize(data or {})
	if #payload <= MAX_LEN then
		Out(payload, channel, target)
		return
	end
	counter = counter + 1
	local id = tostring(counter) .. tostring(math.random(100, 999))
	local total = math.ceil(#payload / CHUNK)
	for i = 1, total do
		Out("~M\t" .. id .. "\t" .. i .. "\t" .. total .. "\t" .. payload:sub((i - 1) * CHUNK + 1, i * CHUNK), channel, target)
	end
end

function Comm:Register(msgType, fn)
	self.handlers[msgType] = fn
end

-- eigene Nachrichten, die noch in der gemeinsamen Warteschlange liegen
local function OurQueue()
	local out = {}
	for _, q in ipairs(Sync and Sync.queue or {}) do
		if q.prefix == Comm.PREFIX then out[#out + 1] = q end
	end
	return out
end
function Comm:Pending()
	return #OurQueue()
end
-- nur für die Testroutine: was gerade in der Warteschlange liegt (Vergleich vorher/nachher), danach aufräumen.
-- TestHold: während der Routine geht nichts hinaus (nur die Schnittstellen-Tabelle der gemeinsamen Datei wird ersetzt).
function Comm.TestMark()
	local set = {}
	for _, q in ipairs(OurQueue()) do set[q] = true end
	return set
end
function Comm.TestPending(mark)
	local n = 0
	for _, q in ipairs(OurQueue()) do if not mark[q] then n = n + 1 end end
	return n
end
function Comm.TestPurge(mark)
	if not Sync then return 0 end
	local n = 0
	for i = #Sync.queue, 1, -1 do
		local q = Sync.queue[i]
		if q.prefix == Comm.PREFIX and not mark[q] then table.remove(Sync.queue, i); n = n + 1 end
	end
	return n
end
function Comm.TestHold(on, onSend)
	if not Sync then return end
	if on and not Comm.heldSend then
		Comm.heldSend = Sync.api.send
		Sync.api.send = function(prefix, msg, dist, target)
			if onSend then onSend(prefix, msg, dist, target) end
			return true
		end
	elseif not on and Comm.heldSend then
		Sync.api.send = Comm.heldSend
		Comm.heldSend = nil
	end
end
-- alte Schnittstelle der Testroutine (zwei Warteschlangen) – jetzt: eigene Einträge in der gemeinsamen Warteschlange
function Comm.TestQueues() return OurQueue(), {} end

------------------------------------------------------------
-- Empfangen
------------------------------------------------------------
local parts = {}     -- [Absender..id] = { total, got, t, [i] = Text }

-- test = true nur aus der Testroutine (Comm.TestDispatch / Comm.TestOnAddon): ohne die Testmodus-Sperre und
-- ohne Comm:Seen, damit die Routine Pakete auf dem echten Weg prüfen kann
local function Dispatch(sender, payload, channel, test)
	local msgType, body = payload:match("^([^\t]+)\t(.*)$")
	if not msgType then return end
	local fn = Comm.handlers[msgType]
	if not fn then return end
	if not ns.Feature(Comm.FEATURE[msgType]) then return end
	if not test and ns.Test and ns.Test:Active() then return end
	-- über die Gruppe (auch Spieler anderer Gilden) bzw. alte Kanäle nur die Gruppensuche
	if (channel == "CHANNEL" or channel == "GROUP") and not Comm.channelTypes[msgType] then return end
	local data = Comm.Deserialize(body)
	if type(data) ~= "table" then return end
	if channel ~= "CHANNEL" and channel ~= "GROUP" and not test and sender then Comm:Seen(sender) end
	local ok, err = pcall(fn, sender, data, channel)
	if not ok then ns.CountError(msgType, err) end    -- ohne Absender (keine Namen in Fehlermeldungen)
end

-- Nachrichten ohne bekannten Absender (geschützter Name): nur Typen, die den Namen selbst mitbringen
Comm.noSender = { PROF = true }
Comm.dropped = {}

local function Dropped(why) Comm.dropped[why] = (Comm.dropped[why] or 0) + 1 end

-- Eingang (aus der gemeinsamen Datei oder der Testroutine). channel = Weg: GUILD, WHISPER, PARTY/RAID (-> "GROUP"),
-- CHANNEL (alte Versionen anderer Spieler; in Forever kommt dort nichts an)
local function OnAddon(prefix, msg, channel, sender, test)
	if ns.IsSecret(prefix) or ns.IsSecret(msg) then return end
	if prefix ~= Comm.PREFIX or type(msg) ~= "string" then return end
	if ns.IsSecret(sender) then sender = nil end
	sender = sender and ns.Short(sender) or nil
	if sender and sender == ns.Me() then return end
	if channel == "PARTY" or channel == "RAID" or channel == "INSTANCE_CHAT" then channel = "GROUP" end
	if channel ~= "GUILD" and channel ~= "WHISPER" and channel ~= "CHANNEL" and channel ~= "GROUP" then return end
	if msg:sub(1, 3) == "~M\t" then
		local id, i, total, chunk = msg:match("^~M\t([^\t]+)\t(%d+)\t(%d+)\t(.*)$")
		i, total = tonumber(i), tonumber(total)
		if not id or not i or not total or total > 400 then return end
		local key = (sender or "?") .. id
		local p = parts[key]
		if not p then
			p = { total = total, got = 0, t = GetTime() }
			parts[key] = p
		end
		if not p[i] then
			p[i] = chunk
			p.got = p.got + 1
		end
		if p.got >= p.total then
			parts[key] = nil
			local full = {}
			for k = 1, p.total do full[k] = p[k] or "" end
			if not sender and not Comm.noSender[(table.concat(full):match("^([^\t]+)\t"))] then Dropped("nosender") return end
			Dispatch(sender, table.concat(full), channel, test)
		end
		return
	end
	if not sender and not Comm.noSender[(msg:match("^([^\t]+)\t"))] then Dropped("nosender") return end
	Dispatch(sender, msg, channel, test)
end

if Comm.ep then
	Comm.ep:OnMessage(function(text, sender, dist) OnAddon(Comm.PREFIX, text, dist, sender) end)
end

-- bekannte Mitspieler des Flüster-Netzes über /reload merken (GuildSentinelDB.gsSync: nur Namen, Zeiten, Version; lokal)
ns:On("PLAYER_LOGIN", function()
	if Comm.ep and Comm.ep.UseStorage and type(GuildSentinelDB) == "table" then Comm.ep:UseStorage(GuildSentinelDB) end
end)

-- nur für die Testroutine (TestRoutine.lua, Entwickler): Pakete auf dem echten Weg zustellen, auch im Testmodus
function Comm.TestDispatch(sender, payload, channel) Dispatch(sender, payload, channel or "GUILD", true) end
function Comm.TestOnAddon(prefix, msg, channel, sender) OnAddon(prefix, msg, channel, sender, true) end

-- alte, unvollständige Teile aufräumen
C_Timer.NewTicker(60, function()
	local now = GetTime()
	for k, p in pairs(parts) do
		if now - p.t > 120 then parts[k] = nil end
	end
end)

------------------------------------------------------------
-- Wer nutzt GuildSentinel? (Version)
------------------------------------------------------------
function Comm:Setup()
	-- die Kennung meldet GoldSentinelSync.Register an (oben); ohne die Datei (sollte nie sein) wie früher
	if not self.ep and ns.RegisterPrefix then ns.RegisterPrefix(self.PREFIX) end
end

-- Mitspieler mit GuildSentinel, die sich in der letzten Stunde gemeldet haben (ohne Namen; gemeinsame Datei)
function Comm:Peers(seconds)
	return self.ep and self.ep:Peers(seconds or 3600) or 0
end

-- /gs sync test: wer antwortet? Ausgabe "N Antworten (Gilde a, Gruppe b)"
function Comm:PingTest(cb)
	if ns.Test and ns.Test:Active() then ns:Print("[Test] " .. L["Sync-Test"]) return end
	if not Sync then return end
	ns:Print(L["Sync-Test läuft …"])
	Sync.Ping(ADDON, function(r)
		local line = string.format(L["%d Antworten (Gilde %d, Gruppe %d)"], r.total or 0, r.guild or 0, r.group or 0)
		if r.nopath then line = line .. " – " .. L["weder in einer Gilde noch in einer Gruppe"] end
		ns:Print(line)
		if cb then cb(r, line) end
	end)
end

function Comm:Seen(name, v)
	self.users[name] = self.users[name] or {}
	if v then self.users[name].v = v end
	self.users[name].t = ns.Now()
end

Comm:Register("HI", function(sender, d, channel)
	Comm:Seen(sender, d.v)
	-- (nicht aus der Testroutine: die Antwort käme erst nach ihrem Ende und ginge dann wirklich hinaus)
	if channel == "GUILD" and sender and not (ns.Routine and ns.Routine.running) then
		-- kurz antworten, damit der Neue weiß, wer das Addon hat
		C_Timer.After(math.random(1, 8), function() Comm:Send("VER", { v = ns.version }, "WHISPER", sender) end)
	end
	ns:Fire("GS_USERS")
end)

Comm:Register("VER", function(sender, d)
	Comm:Seen(sender, d.v)
	ns:Fire("GS_USERS")
end)

ns:Listen("GS_LOGIN", function()
	if not IsInGuild() then return end
	C_Timer.After(12, function() Comm:Send("HI", { v = ns.version }) end)
end)

-- neuere Version unterwegs?
function Comm:NewestVersion()
	local best = ns.version
	local function num(v)
		local a, b, c = tostring(v):match("(%d+)%.(%d+)%.?(%d*)")
		return (tonumber(a) or 0) * 10000 + (tonumber(b) or 0) * 100 + (tonumber(c) or 0)
	end
	for _, u in pairs(self.users) do
		if u.v and num(u.v) > num(best) then best = u.v end
	end
	return best, num(best) > num(ns.version)
end

------------------------------------------------------------
-- Nur einer macht es: Ansagen im Gildenchat (Meilensteine, Jubiläen ...)
-- Alle Addon-Nutzer sehen dasselbe Ereignis. Jeder wartet kurz; wer zuerst "ich mach's" (CLM) schickt,
-- sagt an. Kommen zwei Ansprüche gleichzeitig, gewinnt der alphabetisch erste Name.
------------------------------------------------------------
Comm.claims = {}     -- [Schlüssel] = { t = GetTime(), by = Name }
Comm.CLAIM_TTL = 300

Comm:Register("CLM", function(sender, d)
	if type(d.k) ~= "string" then return end
	local c = Comm.claims[d.k]
	if not c or GetTime() - c.t > Comm.CLAIM_TTL or sender < c.by then
		Comm.claims[d.k] = { t = GetTime(), by = sender }
	end
	ns:Fire("GS_CLAIM", d.k, sender)
end)

function ns.Claim(key, fn, maxDelay)
	ns.Later(0.5 + math.random() * (maxDelay or 4), function()
		local c = Comm.claims[key]
		if c and GetTime() - c.t < Comm.CLAIM_TTL then return end
		Comm.claims[key] = { t = GetTime(), by = ns.Me() }
		Comm:Send("CLM", { k = key }, "GUILD", nil, true)
		ns.Later(2, function()
			local c2 = Comm.claims[key]
			if c2 and c2.by ~= ns.Me() then return end
			fn()
		end)
	end)
end

-- Text in den Gildenchat
function ns.Announce(text)
	text = ns.Trim(text)
	-- ns.InGuild: im Testmodus immer wahr (dann schreibt ns.Chat nur "[Test] …" und sendet nichts)
	if text == "" or not ns.InGuild() then return end
	if #text > 255 then text = text:sub(1, 252) .. "..." end
	ns.Chat(text, "GUILD")
end
