-- GuildSentinel - Bank.lua
-- Bestand des Bank-Charakters für Discord (#gildenbank, /bank).
--
-- Nur auf dem Bank-Charakter der Gilde und nur, wenn dort in den Einstellungen "Bank-Charakter (Bestand an Discord)"
-- angehakt ist (pro Charakter, ab Werk für niemanden). Dann liest GuildSentinel beim Öffnen der Bank die Taschen und
-- Bankfächer, beim Öffnen des Briefkastens die Anhänge und – falls die Spielversion sie hat – beim Öffnen der
-- Gildenbank deren Fächer. Teile, die gerade nicht gelesen werden, bleiben aus dem letzten Stand erhalten.
-- Der RaidMaster-Uploader auf dem PC schickt GuildSentinel.lua mit dem nächsten Upload an den Discord-Bot.
-- Richtung nur GuildSentinel -> Discord; nichts kommt zurück ins Spiel, und GuildSentinel ändert nichts an Bank,
-- Post oder Gildenbank (nur lesen).
--
-- Format GENAU wie RaidMasterDB.bank (RaidMaster/Bank.lua), damit der Bot denselben Leser benutzt:
--   GuildSentinelDB.bank = { c = Name des Bank-Charakters, t = Zeit beim Lesen, g = Gold (Kupfer),
--                            gb = Gold der Gildenbank (Kupfer) oder nil, src = "bank" | "mail" | "guild",
--                            i = { [Item-ID] = { n = Name, q = Qualität, c = Gesamtanzahl, ic = Symbol-ID,
--                                                w = { bag = x, bank = y, mail = z, guild = w } } } }
--
-- Alle Spielfunktionen über ns.API (API.lua): C_Container mit Rückfall auf die alten Funktionen (Classic Era/TBC).
-- Nie im Kampf; gelesen wird in Scheiben (ein Behälter, ein Brief bzw. ein Gildenbankfach pro Schritt).

local ADDON, ns = ...
local L = ns.L

local B = {}
ns.Bank = B

B.STEPS_PER_FRAME = 4          -- so viele Behälter/Briefe/Fächer je Bild
B.MAIL_ATTACHMENTS = 16        -- ATTACHMENTS_MAX_RECEIVE (Classic)
B.GUILD_SLOTS = 98             -- MAX_GUILDBANK_SLOTS_PER_TAB

------------------------------------------------------------
-- Bank-Charakter (pro Charakter, Schlüssel "Realm|Name")
------------------------------------------------------------
function B.CharKey()
	local me = ns.Me()
	if type(me) ~= "string" or me == "" then return nil end
	local realm = GetRealmName and GetRealmName() or ""
	if ns.IsSecret(realm) or type(realm) ~= "string" then realm = "" end
	return realm .. "|" .. me
end

function B.IsBankChar()
	local k = B.CharKey()
	local list = ns.db and ns.db.bankChars
	return k ~= nil and type(list) == "table" and list[k] == true
end

function B.SetBankChar(on)
	local k = B.CharKey()
	if not k or not ns.db then return end
	if type(ns.db.bankChars) ~= "table" then ns.db.bankChars = {} end
	ns.db.bankChars[k] = on and true or nil
	if on then ns:Print(L["Bank-Charakter: Öffne Bank und Briefkasten einmal – GuildSentinel liest den Bestand dann selbst."]) end
end

------------------------------------------------------------
-- Lesen
------------------------------------------------------------
local current            -- wird beim Lesen gefüllt: { [id] = {...} }

local function Add(where, link, count, icon)
	if type(link) ~= "string" or ns.IsSecret(link) then return end
	local id = ns.ItemID(link)
	if not id then return end
	count = tonumber(count) or 1
	if count < 1 then count = 1 end
	local e = current[id]
	if not e then
		local name, q
		if ns.API.GetItemInfo then
			local ok, n, _, qq = pcall(ns.API.GetItemInfo, link)
			if ok then name, q = n, qq end
		end
		if ns.IsSecret(name) then name = nil end
		e = { n = name or link:match("%[(.-)%]"), q = tonumber(q), c = 0, ic = (type(icon) == "number" or type(icon) == "string") and icon or nil, w = {} }
		current[id] = e
	end
	e.c = e.c + count
	e.w[where] = (e.w[where] or 0) + count
end

-- letzter Stand dieses Charakters (nur dann werden Teile übernommen)
local function Last()
	local b = GuildSentinelDB and GuildSentinelDB.bank
	if type(b) == "table" and b.c == ns.Me() and type(b.i) == "table" then return b end
	return nil
end

-- vorhandene Teile übernehmen (z. B. die Post, wenn nur die Bank gelesen wird)
local function Start(keep)
	current = {}
	local last = Last()
	for id, e in pairs(last and last.i or {}) do
		if type(e) == "table" and type(e.w) == "table" then
			for where, n in pairs(e.w) do
				if keep[where] and type(n) == "number" then
					local x = current[id]
					if not x then
						x = { n = e.n, q = e.q, c = 0, ic = e.ic, w = {} }
						current[id] = x
					end
					x.c = x.c + n
					x.w[where] = n
				end
			end
		end
	end
end

local function Finish(src, quiet, guildMoney)
	local last = Last()
	local b = {
		c = ns.Me(),
		t = ns.Now(),
		g = ns.API.GetMoney and ns.API.GetMoney() or (last and last.g) or 0,
		gb = last and last.gb or nil,
		src = src,
		i = current,
	}
	if guildMoney ~= nil then b.gb = guildMoney end
	GuildSentinelDB.bank = b
	current = nil
	local n = 0
	for _ in pairs(b.i) do n = n + 1 end
	if not quiet then
		ns:Print(string.format(L["Gildenbank-Bestand gelesen: %d verschiedene Items. Er kommt mit dem nächsten Upload in den Discord."], n))
	end
	ns:Fire("GS_BANK")
	return n
end

-- Schritte je Art: jede Funktion liest einen Behälter, einen Brief bzw. ein Gildenbankfach
local function BagSteps(where, from, to, out)
	for bag = from, to do
		out[#out + 1] = function()
			for slot = 1, ns.ContainerSlots(bag) do
				local link, count, icon = ns.ContainerSlot(bag, slot)
				if link then Add(where, link, count, icon) end
			end
		end
	end
end

local KEEP = {
	bank = { mail = true, guild = true },
	mail = { bag = true, bank = true, guild = true },
	guild = { bag = true, bank = true, mail = true },
}

local function Steps(kind)
	local A = ns.API
	local out = {}
	if kind == "bank" then
		local nb = NUM_BAG_SLOTS or 4
		BagSteps("bag", 0, nb, out)
		local bc = BANK_CONTAINER or -1
		BagSteps("bank", bc, bc, out)
		BagSteps("bank", nb + 1, nb + (NUM_BANKBAGSLOTS or 6), out)
	elseif kind == "mail" then
		local n = A.GetInboxNumItems and A.GetInboxNumItems() or 0
		for i = 1, (tonumber(n) or 0) do
			out[#out + 1] = function()
				for j = 1, (ATTACHMENTS_MAX_RECEIVE or B.MAIL_ATTACHMENTS) do
					local link = A.GetInboxItemLink and A.GetInboxItemLink(i, j)
					if link then
						local count, icon = 1, nil
						if A.GetInboxItem then
							local _, _, ic, cnt = A.GetInboxItem(i, j)
							count, icon = cnt or 1, ic
						end
						Add("mail", link, count, icon)
					end
				end
			end
		end
	elseif kind == "guild" then
		local tabs = A.GetNumGuildBankTabs and A.GetNumGuildBankTabs() or 0
		for tab = 1, (tonumber(tabs) or 0) do
			out[#out + 1] = function()
				for slot = 1, (MAX_GUILDBANK_SLOTS_PER_TAB or B.GUILD_SLOTS) do
					local link = A.GetGuildBankItemLink and A.GetGuildBankItemLink(tab, slot)
					if link then
						local icon, count
						if A.GetGuildBankItemInfo then icon, count = A.GetGuildBankItemInfo(tab, slot) end
						Add("guild", link, count or 1, icon)
					end
				end
			end
		end
	end
	return out
end

-- noch offen: Ein Lesevorgang läuft (nur einer gleichzeitig); im Kampf vorgemerkte Arten
B.running = nil
B.pending = {}

-- kind: "bank" | "mail" | "guild". now = true: alles sofort (Testroutine, Offline-Tests)
-- Rückgabe: true, wenn gelesen (now) bzw. gestartet/vorgemerkt wurde
function B.Scan(kind, now)
	if not KEEP[kind] or not B.IsBankChar() then return false end
	if ns.InCombat() then B.pending[kind] = true return true end
	if B.running then B.pending[kind] = true return true end
	local steps = Steps(kind)
	Start(KEEP[kind])
	local function Done()
		local gm
		if kind == "guild" and ns.API.GetGuildBankMoney then gm = ns.API.GetGuildBankMoney() end
		if ns.IsSecret(gm) then gm = nil end
		-- Post wird bei jeder Änderung des Briefkastens neu gelesen: Chatzeile nur einmal je Öffnen
		local quiet = kind == "mail" and B.mailTold
		if kind == "mail" then B.mailTold = true end
		Finish(kind, quiet, gm)
	end
	if now then
		for _, fn in ipairs(steps) do
			local ok, err = pcall(fn)
			if not ok then ns.CountError("Bank " .. kind, err) end
		end
		Done()
		return true
	end
	B.running = kind
	local i = 0
	local function Next()
		-- Kampf mitten im Lesen: abbrechen, nach dem Kampf neu (der alte Stand bleibt bis dahin)
		if ns.InCombat() then current = nil; B.running = nil; B.pending[kind] = true return end
		-- Fenster geschlossen: nicht weiterlesen (Bank-/Gildenbankfächer sind dann nicht mehr lesbar)
		if (kind == "bank" and not B.bankOpen) or (kind == "guild" and not B.guildOpen) then
			current = nil; B.running = nil
			return
		end
		for _ = 1, B.STEPS_PER_FRAME do
			i = i + 1
			local fn = steps[i]
			if not fn then
				B.running = nil
				Done()
				B.RunPending()
				return
			end
			local ok, err = pcall(fn)
			if not ok then ns.CountError("Bank " .. kind, err) end
		end
		C_Timer.After(0, Next)
	end
	Next()
	return true
end

-- nach dem Kampf bzw. nach einem Lesevorgang: Vorgemerktes lesen (now wie bei B.Scan)
function B.RunPending(now)
	if B.running or ns.InCombat() then return end
	for _, kind in ipairs({ "bank", "guild", "mail" }) do
		if B.pending[kind] then
			B.pending[kind] = nil
			if (kind ~= "bank" or B.bankOpen) and (kind ~= "guild" or B.guildOpen) and (kind ~= "mail" or B.mailOpen) then
				B.Scan(kind, now)
				if not now then return end
			end
		end
	end
end

------------------------------------------------------------
-- Ereignisse
------------------------------------------------------------
B.bankOpen, B.mailOpen, B.guildOpen = false, false, false

ns:On("BANKFRAME_OPENED", function()
	B.bankOpen = true
	if B.IsBankChar() then C_Timer.After(0.5, function() B.Scan("bank") end) end
end)
ns:On("BANKFRAME_CLOSED", function() B.bankOpen = false end)

ns:On("MAIL_SHOW", function() B.mailOpen = true; B.mailTold = false end)
ns:On("MAIL_CLOSED", function() B.mailOpen = false end)
ns:On("MAIL_INBOX_UPDATE", function()
	if not B.mailOpen or not B.IsBankChar() or B.mailWait then return end
	B.mailWait = true
	C_Timer.After(1, function() B.mailWait = nil; B.Scan("mail") end)
end)

ns:On("GUILDBANKFRAME_OPENED", function()
	B.guildOpen = true
	if not B.IsBankChar() or not ns.API.GetNumGuildBankTabs then return end
	-- alle Fächer beim Server anfragen, dann lesen
	if ns.API.QueryGuildBankTab then
		for tab = 1, (tonumber(ns.API.GetNumGuildBankTabs()) or 0) do pcall(ns.API.QueryGuildBankTab, tab) end
	end
	C_Timer.After(2, function() B.Scan("guild") end)
end)
ns:On("GUILDBANKFRAME_CLOSED", function() B.guildOpen = false end)

ns:On("PLAYER_REGEN_ENABLED", function() B.RunPending() end)
