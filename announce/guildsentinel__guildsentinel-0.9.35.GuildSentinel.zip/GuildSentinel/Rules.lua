-- GuildSentinel - Rules.lua
-- Gildenregeln: Die Gildenleitung schreibt die Regeln (Seite Rekrutierung > Regeln) und schickt sie an alle.
-- Wer GuildSentinel hat und die aktuelle Fassung noch nicht bestätigt hat, sieht sie beim Einloggen in einem
-- Fenster und bestätigt mit einem Klick. Im Verlauf steht, wer zugestimmt hat; die Leitung sieht, wer noch fehlt.
--
--   G.rules = { v = Fassung, t, text, by }
--   G.rulesAck[Name] = { v, t }

local ADDON, ns = ...
local L = ns.L
local Ru = {}
ns.Rules = Ru

Ru.MAX = 3000

function Ru:Current()
	return ns.G().rules
end

function Ru:HasRules()
	local r = self:Current()
	return r and (r.v or 0) > 0 and ns.Trim(r.text) ~= ""
end

function Ru:Acked(name)
	local r = self:Current()
	local a = ns.G().rulesAck[name or ns.Me()]
	return a and r and (a.v or 0) >= (r.v or 0) and (r.v or 0) > 0
end

function Ru:CanEdit()
	return ns.IsOfficer()
end

function Ru:Save(text)
	local g = ns.guild
	if not g then return end
	if not self:CanEdit() then ns:Print(L["Nur Offiziere können die Gildenregeln ändern."]) return end
	text = ns.Trim(text):sub(1, self.MAX)
	g.rules = { v = (g.rules.v or 0) + 1, t = ns.Now(), text = text, by = ns.Me() }
	-- wer sie schreibt, ist einverstanden
	g.rulesAck[ns.Me()] = { v = g.rules.v, t = ns.Now() }
	ns.Comm:Send("RULES", g.rules)
	ns.Comm:Send("RACK", { v = g.rules.v })
	ns:Print(string.format(L["Gildenregeln (Fassung %d) an alle geschickt."], g.rules.v))
	ns:Fire("GS_RULES")
end

function Ru:Ack()
	local g = ns.guild
	local r = self:Current()
	if not g or not r or (r.v or 0) == 0 then return end
	g.rulesAck[ns.Me()] = { v = r.v, t = ns.Now() }
	ns.Comm:Send("RACK", { v = r.v })
	ns.Roster:Log("rules", ns.Me(), r.v)
	ns:Fire("GS_RULES")
end

function Ru:Store(d)
	local g = ns.guild
	if not g or type(d.v) ~= "number" or type(d.text) ~= "string" then return false end
	if (g.rules.v or 0) >= d.v then return false end
	g.rules = { v = d.v, t = tonumber(d.t) or ns.Now(), text = d.text:sub(1, self.MAX), by = d.by or "?" }
	return true
end

ns.Comm:Register("RULES", function(sender, d)
	if Ru:Store(d) then
		ns:Fire("GS_RULES")
		if ns.db.rulesPopup and ns.Feature("recruit") and not Ru:Acked() then C_Timer.After(3, function() Ru:ShowPopup() end) end
	end
end)

local function StoreAck(name, v, t)
	local g = ns.guild
	if not g or type(v) ~= "number" then return false end
	local old = g.rulesAck[name]
	if old and (old.v or 0) >= v then return false end
	g.rulesAck[name] = { v = v, t = t or ns.Now() }
	return true
end

ns.Comm:Register("RACK", function(sender, d)
	if StoreAck(sender, d.v) then
		ns.Roster:Log("rules", sender, d.v)
		ns:Fire("GS_RULES")
	end
end)

-- beim Abgleich alle Bestätigungen auf einmal
ns.Comm:Register("RACKS", function(sender, d)
	if type(d.e) ~= "table" then return end
	local any
	for name, a in pairs(d.e) do
		if type(name) == "string" and type(a) == "table" and StoreAck(name, tonumber(a.v), tonumber(a.t)) then any = true end
	end
	if any then ns:Fire("GS_RULES") end
end)

-- Wer hat die aktuelle Fassung bestätigt? { yes = { Namen }, no = { Namen } } (nur Mains)
function Ru:Status()
	local yes, no = {}, {}
	local r = self:Current()
	for _, e in ipairs(ns.Roster.list) do
		if not ns.Roster:IsAlt(e.name) then
			local chars = { e.name }
			for _, alt in ipairs(ns.Roster:AltsOf(e.name)) do chars[#chars + 1] = alt end
			local ok
			for _, ch in ipairs(chars) do if self:Acked(ch) then ok = true end end
			if ok then yes[#yes + 1] = e.name else no[#no + 1] = e.name end
		end
	end
	table.sort(yes)
	table.sort(no)
	return yes, no
end

------------------------------------------------------------
-- Fenster mit den Regeln
------------------------------------------------------------
function Ru:ShowPopup(force)
	if not self:HasRules() then
		if force then ns:Print(L["Es gibt noch keine Gildenregeln."]) end
		return
	end
	if ns.InCombat() and not force then
		self.pendingPopup = true
		return
	end
	local UI = ns.UI
	local f = self.popup
	if not f then
		f = CreateFrame("Frame", "GuildSentinelRules", UIParent, UI.BACKDROP)
		f:SetSize(560, 460)
		f:SetPoint("CENTER", 0, 40)
		f:SetFrameStrata("DIALOG")
		f:SetClampedToScreen(true)
		f:SetMovable(true)
		f:EnableMouse(true)
		f:RegisterForDrag("LeftButton")
		f:SetScript("OnDragStart", function() f:StartMoving() end)
		f:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)
		UI.Box(f, 0.05, 0.06, 0.08, 0.98, ns.ACCENT[1], ns.ACCENT[2], ns.ACCENT[3], 0.8)
		tinsert(UISpecialFrames, "GuildSentinelRules")
		f.title = UI:Label(f, "", "GameFontNormalLarge")
		f.title:SetPoint("TOPLEFT", 16, -14)
		f.sub = UI:Label(f, "", "GameFontDisableSmall")
		f.sub:SetPoint("TOPLEFT", f.title, "BOTTOMLEFT", 0, -4)
		f.text = UI:ScrollText(f, 528, 330)
		f.text:SetPoint("TOPLEFT", 16, -58)
		f.ok = UI:Button(f, L["Gelesen und einverstanden"], 220, 30, function() Ru:Ack(); f:Hide() end, true)
		f.ok:SetPoint("BOTTOMRIGHT", -16, 14)
		f.later = UI:Button(f, L["Später"], 110, 30, function() f:Hide() end)
		f.later:SetPoint("RIGHT", f.ok, "LEFT", -8, 0)
		self.popup = f
	end
	local r = self:Current()
	f.title:SetText(string.format(L["Gildenregeln von <%s>"], ns.DisplayGuildName() or ""))
	f.sub:SetText(string.format(L["Fassung %d · von %s · %s"], r.v, r.by or "?", ns.Date(r.t)))
	f.text:SetText(r.text)
	local acked = self:Acked()
	f.ok:SetText(acked and L["Schließen"] or L["Gelesen und einverstanden"])
	f.later:SetShown(not acked)
	f:Show()
end

ns:On("PLAYER_REGEN_ENABLED", function()
	if Ru.pendingPopup then Ru.pendingPopup = nil; Ru:ShowPopup() end
end)

ns:Listen("GS_LOGIN", function()
	C_Timer.After(20, function()
		if ns.db.rulesPopup and ns.Feature("recruit") and Ru:HasRules() and not Ru:Acked() then Ru:ShowPopup() end
	end)
end)
