-- GuildSentinel - Diag.lua
-- Diagnose-Protokoll (Vorlage: raidmaster/shared/vorlage/__ADDON__/Diag.lua, Vorbild LevelPilot)
--
-- Wozu: Fehler, die nur im echten Spiel auftreten (langsame Seiten, blockierte Aktionen, Fehlerschleifen), schreibt
-- GuildSentinel selbst mit. Der Spieler öffnet das Protokoll mit /gs protokoll (Text zum Kopieren). Beim Ausloggen bzw.
-- /reload liegt es zusätzlich als "GSDIAG1"-Zeichenkette in GuildSentinelDB.diagExport; der RaidMaster-Uploader
-- schickt es nach #testberichte (-> GitHub, Prüf-Sitzung).
--
-- Einträge:
--   ns.Diag("KLICK", "Text", ms)      Art, Text, optional Dauer
--   ns.Timed("Seite home", fn, ...)    misst fn; länger als ns.DIAG_SLOW_MS -> Eintrag LANGSAM
--   FEHLER                             automatisch aus ns.CountError (gleicher Text nur gezählt)
--   BLOCKIERT                          ADDON_ACTION_BLOCKED/FORBIDDEN für GuildSentinel, mit Aufrufort (debugstack)
--
-- Regeln: KEINE Spieler-, Charakter-, Gilden- oder Realmnamen (das Protokoll landet im öffentlichen Repo):
--   der eigene Name wird schon in ns.CountError ersetzt; Texte hier sind Seiten-, Funktions- und Dateinamen.
--   Während Testmodus und Testroutine wird nichts geschrieben (die Sandbox der Routine bleibt unverändert).

local ADDON, ns = ...
local L = ns.L

ns.DIAG_MAX = 200          -- höchstens so viele Einträge, älteste fallen weg
ns.DIAG_SLOW_MS = 16       -- ein Bild bei 60 fps
ns.DIAG_PREFIX = "GSDIAG1"
ns.DIAG_EXPORT_MAX = 60000 -- Zeichen in der SavedVariables-Zeichenkette

local function Stamp() return date and date("%d.%m. %H:%M") or "" end
local function Clean(s)
	if ns.IsSecret and ns.IsSecret(s) then return "?" end
	s = tostring(s or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("[\r\n|]", " ")
	local me = ns.Me and ns.Me()
	if type(me) == "string" and me ~= "" and not (ns.IsSecret and ns.IsSecret(me)) then
		s = s:gsub(me:gsub("%p", "%%%0"), "<name>")
	end
	return s
end
ns.DiagClean = Clean

-- im Testmodus und während der Testroutine nichts schreiben
-- (ns.diagForce: nur die Testroutine, T188 – schreibt dann in eine Ersatz-Tabelle statt in die echten Daten)
local function Quiet()
	if ns.diagForce then return false end
	return (ns.Test and ns.Test.active) or (ns.Routine and ns.Routine.running) or false
end

local function Store()
	if not GuildSentinelDB then return nil end
	local d = GuildSentinelDB.diag
	if type(d) ~= "table" then d = { entries = {}, sessions = {} }; GuildSentinelDB.diag = d end
	if type(d.entries) ~= "table" then d.entries = {} end
	if type(d.sessions) ~= "table" then d.sessions = {} end
	return d
end

-- Einen Eintrag schreiben. Gleiche Art + gleicher Text direkt hintereinander -> nur Zähler erhöhen.
function ns.Diag(kind, text, ms)
	if Quiet() then return nil end
	local d = Store()
	if not d then return nil end
	kind, text = Clean(kind):upper(), Clean(text):sub(1, 240)
	local e = d.entries[1]
	if type(e) == "table" and e.k == kind and e.t == text then
		e.n = (e.n or 1) + 1
		e.z = Stamp()
		if ms then e.ms = math.max(e.ms or 0, math.floor(ms + 0.5)) end
		return e
	end
	e = { k = kind, t = text, z = Stamp(), n = 1, ms = ms and math.floor(ms + 0.5) or nil, v = ns.version }
	table.insert(d.entries, 1, e)
	for i = #d.entries, ns.DIAG_MAX + 1, -1 do d.entries[i] = nil end
	return e
end

local function Ms()
	if debugprofilestop then return debugprofilestop() end
	return (GetTime and GetTime() or 0) * 1000
end

-- fn messen; länger als ein Bild -> LANGSAM. Fehler laufen wie bisher weiter (kein eigenes pcall).
function ns.Timed(name, fn, ...)
	local t0 = Ms()
	local a, b, c = fn(...)
	local ms = Ms() - t0
	if ms > ns.DIAG_SLOW_MS then ns.Diag("LANGSAM", name, ms) end
	return a, b, c
end

-- Sitzung beim Einloggen vermerken (nur Stufe, Klasse, Spielversion – kein Name)
function ns.DiagSession()
	if Quiet() then return end
	local d = Store()
	if not d then return end
	local lvl = UnitLevel and UnitLevel("player") or 0
	if ns.IsSecret(lvl) then lvl = 0 end
	local _, class = UnitClass and UnitClass("player")
	local G = _G.GoldSentinelGame
	table.insert(d.sessions, 1, { z = Stamp(), lvl = lvl, class = class or "?", v = ns.version, f = G and G.flavor or "?" })
	for i = #d.sessions, 21, -1 do d.sessions[i] = nil end
end

-- Das Protokoll als Text
function ns.DiagText()
	local d = Store() or { entries = {}, sessions = {} }
	local G = _G.GoldSentinelGame
	local out = {}
	local function add(s) out[#out + 1] = s end
	add(string.format("%s-Protokoll v%s · %s", ADDON, tostring(ns.version), Stamp()))
	add(string.format("Client %s · %s", tostring(GetLocale and GetLocale() or "?"), G and G.Status and Clean(G.Status()) or "?"))
	add(string.format("Sitzungen: %d", #d.sessions))
	for i = 1, math.min(#d.sessions, 10) do
		local s = d.sessions[i]
		add(string.format("  %s L%s %s v%s %s", s.z or "", tostring(s.lvl), tostring(s.class), tostring(s.v), tostring(s.f or "")))
	end
	add("")
	add("== Diagnose")
	add(string.format("  Fehler in dieser Sitzung: %d", ns.errors and ns.errors.n or 0))
	local total = ns.Roster and ns.Roster.list and #ns.Roster.list or 0
	add(string.format("  Gildenliste: %d Einträge · Sprache %s · Testmodus %s", total, tostring(ns.lang), tostring(ns.Test and ns.Test.active or false)))
	-- Addon-Nachrichten (gemeinsame Datei GoldSentinelSync.lua): Wege, Mitspieler, Zähler – ohne Namen
	local Sync = _G.GoldSentinelSync
	if Sync and Sync.DiagLines then
		local ok, lines = pcall(Sync.DiagLines)
		if ok and type(lines) == "table" then for _, l in ipairs(lines) do add("  " .. Clean(l)) end end
	end
	-- Berufe: Einträge im Speicher, davon mit Rezepten, davon nur Stufe aus der Gilden-Berufsliste des Spiels (g)
	if ns.Prof and ns.Prof.StoreStats then
		local ok, n, rec, g = pcall(ns.Prof.StoreStats, ns.Prof)
		if ok then add(string.format("  Berufe: %d Einträge im Speicher, davon %d mit Rezepten, %d nur Stufe (Spiel)", n, rec, g)) end
	end
	add("")
	add(string.format("== Einträge (%d, neueste zuerst)", #d.entries))
	for _, e in ipairs(d.entries) do
		if type(e) == "table" then
			add(string.format("[%s] %s%s %s%s", e.z or "", e.k or "?", (e.n or 1) > 1 and (" ×" .. e.n) or "",
				e.t or "", e.ms and (" · " .. e.ms .. " ms") or ""))
		end
	end
	return table.concat(out, "\n")
end

-- Zeichenkette für den Uploader (wie GSTEST1): Präfix, Addon, Version, dann der Text
function ns.DiagExport()
	local text = ns.DiagText()
	if #text > ns.DIAG_EXPORT_MAX then text = text:sub(1, ns.DIAG_EXPORT_MAX) end
	return ns.DIAG_PREFIX .. "|" .. ADDON .. "|" .. tostring(ns.version) .. "|" .. text
end

function ns.ShowDiag()
	if ns.UI and ns.UI.Info then
		ns.UI:Info(L["Diagnose-Protokoll (zum Kopieren markieren)"], ns.DiagText(), true)
	else
		ns:Print(ns.DiagText())
	end
end

-- Aufrufort einer blockierten Aktion: nur Zeilen aus GuildSentinel, ohne Pfad davor
local function Where(stack)
	local lines = {}
	for line in tostring(stack or ""):gmatch("[^\n]+") do
		local f = line:match("AddOns[/\\]GuildSentinel[/\\]([^%]\"]+%.lua\"?%]?:%d+)")
		if f then lines[#lines + 1] = f:gsub("[\"%]]", "") end
		if #lines >= 4 then break end
	end
	return #lines > 0 and table.concat(lines, " < ") or "?"
end
ns.DiagWhere = Where

ns:On("ADDON_ACTION_BLOCKED", function(addon, func)
	if addon ~= ADDON then return end
	local stack = debugstack and debugstack(2, 20, 0) or ""
	ns.Diag("BLOCKIERT", tostring(func or "?") .. " @ " .. Where(stack))
end)
ns:On("ADDON_ACTION_FORBIDDEN", function(addon, func)
	if addon ~= ADDON then return end
	local stack = debugstack and debugstack(2, 20, 0) or ""
	ns.Diag("VERBOTEN", tostring(func or "?") .. " @ " .. Where(stack))
end)

ns:On("PLAYER_LOGIN", function() ns.DiagSession() end)

-- Addon-Nachrichten: einmal je Sitzung den Weg ("SYNC GoldSentinelSync … Wege: GUILD+PARTY"), danach alle 10 Minuten
-- die Zähler (gleiche Zeile direkt hintereinander zählt Diag nur hoch). Ohne Spielernamen.
local function SyncLines(first)
	local Sync = _G.GoldSentinelSync
	if not (Sync and Sync.DiagLines) then return end
	local ok, lines = pcall(Sync.DiagLines)
	if not ok or type(lines) ~= "table" then return end
	if first and lines[1] then ns.Diag("SYNC", (lines[1]:gsub("^SYNC%s*", ""))) end
	if lines[2] then ns.Diag("SYNC", (lines[2]:gsub("^SYNC%s*", ""))) end
end
ns:Listen("GS_LOGIN", function()
	C_Timer.After(60, function() SyncLines(true) end)
	C_Timer.NewTicker(600, function() SyncLines(false) end)
end)
-- Server verweigert Addon-Nachrichten in einem Kanal (alte Versionen anderer Addons): ins Protokoll
function ns.DiagChannelNotice(text)
	if ns.IsSecret(text) then return nil end
	if text == "NOT_ALLOWED_IN_CHANNEL" then return ns.Diag("SYNC", "Kanal verweigert Addon-Nachrichten (NOT_ALLOWED_IN_CHANNEL)") end
	return nil
end
ns:On("CHAT_MSG_CHANNEL_NOTICE", function(text) ns.DiagChannelNotice(text) end)

-- Beim Ausloggen / /reload die Export-Zeichenkette in die SavedVariables legen (nicht im Test; abschaltbar mit
-- settings.diagSend = false)
ns:On("PLAYER_LOGOUT", function()
	if not GuildSentinelDB or Quiet() then return end
	if ns.db and ns.db.diagSend == false then GuildSentinelDB.diagExport = nil return end
	local d = Store()
	if not d or #d.entries == 0 then GuildSentinelDB.diagExport = nil return end
	GuildSentinelDB.diagExport = ns.DiagExport()
end)
