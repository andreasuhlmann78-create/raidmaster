-- GuildSentinel - Cooldowns.lua
-- Abklingzeiten der Berufe teilen: Transmutation, Mondstoff, Salzstreuer … "Bei Testa in 2 Std. bereit."
-- Jeder mit GuildSentinel meldet seine eigenen Abklingzeiten (beim Einloggen, nach dem Herstellen und beim
-- Öffnen des Berufsfensters). Mit AH Analyzer Pro steht der Marktwert des Ergebnisses dabei.
--
--   G.cds[Name] = { t, k = { [Schlüssel] = bereit ab (Serverzeit, 0 = jetzt bereit) } }

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local Cd = {}
ns.Cooldowns = Cd

-- spell = Zauber (Abklingzeit über GetSpellCooldown), item = Gegenstand (GetItemCooldown); out = Ergebnis (für den Marktwert)
Cd.LIST = {
	{ key = "transmute", n = N["Transmutation (Arkanit)"], spells = { 17187, 17559, 17560, 17561, 17562, 17563, 17564, 17565, 17566 }, out = 12360 },
	{ key = "mooncloth", n = N["Mondstoff"], spells = { 18560 }, out = 14342 },
	{ key = "saltshaker", n = N["Salzstreuer (Geläutertes Tiefgesteinsalz)"], item = 15846, out = 15409 },
}
if ns.Game.TBC then Cd.LIST = ns.Game.TBC_COOLDOWNS end
Cd.BY_KEY = {}
for _, c in ipairs(Cd.LIST) do Cd.BY_KEY[c.key] = c end

local function SpellCd(id)
	if C_Spell and C_Spell.GetSpellCooldown then
		local info = C_Spell.GetSpellCooldown(id)
		if info then return info.startTime or 0, info.duration or 0 end
		return nil
	end
	if GetSpellCooldown then return GetSpellCooldown(id) end
	return nil
end

local function ItemCd(id)
	local fn = (C_Container and C_Container.GetItemCooldown) or GetItemCooldown
	if not fn then return nil end
	return fn(id)
end

local function HasItem(id)
	local fn = (C_Item and C_Item.GetItemCount) or GetItemCount
	return fn and (fn(id, true) or 0) > 0
end

-- meine Abklingzeiten: { [key] = bereit ab (Serverzeit) } – nur, was ich habe/kann
function Cd:Mine()
	local out = {}
	local nowT, nowS = GetTime(), ns.Now()
	for _, c in ipairs(self.LIST) do
		if not c.hidden then
			local start, dur
			if c.spells then
				for _, id in ipairs(c.spells) do
					if ns.Links:KnowsSpell(id) then
						start, dur = SpellCd(id)
						if start == nil then start, dur = 0, 0 end
						break
					end
				end
			elseif c.item and HasItem(c.item) then
				start, dur = ItemCd(c.item)
				if start == nil then start, dur = 0, 0 end
			end
			if start ~= nil then
				-- globale Abklingzeit (1,5 s) zählt nicht
				if (dur or 0) <= 2 or (start or 0) == 0 then
					out[c.key] = 0
				else
					out[c.key] = math.floor(nowS + (start + dur - nowT))
				end
			end
		end
	end
	return out
end

function Cd:Scan(force)
	local g = ns.guild
	if not ns.Feature("cooldowns") then return end
	if not g then return end
	local k = self:Mine()
	local old = g.cds[ns.Me()]
	local changed = force or not old
	if old and not changed then
		for key, v in pairs(k) do if math.abs((old.k[key] or -1) - v) > 60 then changed = true end end
		for key in pairs(old.k) do if k[key] == nil then changed = true end end
	end
	if not next(k) and not old then return end
	g.cds[ns.Me()] = { t = ns.Now(), k = k }
	if changed then
		ns.Comm:Send("CD", { k = k, t = ns.Now() })
		ns:Fire("GS_CD")
	end
end

local function StoreCd(name, t, k)
	local g = ns.guild
	if not g or type(name) ~= "string" or type(t) ~= "number" or type(k) ~= "table" then return false end
	local old = g.cds[name]
	if old and (old.t or 0) >= t then return false end
	local clean = {}
	for key, v in pairs(k) do if Cd.BY_KEY[key] and tonumber(v) then clean[key] = tonumber(v) end end
	g.cds[name] = { t = t, k = clean }
	return true
end
Cd.StoreCd = StoreCd

ns.Comm:Register("CD", function(sender, d)
	if StoreCd(sender, tonumber(d.t), d.k) then ns:Fire("GS_CD") end
end)
ns.Comm:Register("CDS", function(sender, d)
	if type(d.e) ~= "table" then return end
	local any
	for name, x in pairs(d.e) do
		if type(x) == "table" and not ns.Same(name, ns.Me()) and StoreCd(name, tonumber(x.t), x.k) then any = true end
	end
	if any then ns:Fire("GS_CD") end
end)

-- Liste: { { key, name, who, class, ready (Serverzeit), value } } – bereite zuerst
function Cd:List()
	local out = {}
	local now = ns.Now()
	for who, e in pairs(ns.G().cds) do
		local r = ns.Roster.byName[who]
		if r or ns.Same(who, ns.Me()) then
			for key, ready in pairs(e.k or {}) do
				local c = self.BY_KEY[key]
				if c then
					out[#out + 1] = { key = key, name = L[c.n], who = who, class = r and r.class, online = ns.Roster:OnlineChar(who) ~= nil,
						ready = ready, isReady = ready <= now, value = c.out and ns.Links:MarketValue(c.out), out = c.out }
				end
			end
		end
	end
	table.sort(out, function(a, b)
		if a.isReady ~= b.isReady then return a.isReady end
		if a.online ~= b.online then return a.online end
		if a.ready ~= b.ready then return a.ready < b.ready end
		return a.who < b.who
	end)
	return out
end

function Cd:ReadyText(x)
	if x.isReady then return L["bereit"] end
	local left = x.ready - ns.Now()
	if left < 3600 then return string.format(L["in %d Min."], math.ceil(left / 60)) end
	if left < 86400 then return string.format(L["in %d Std."], math.ceil(left / 3600)) end
	return string.format(L["in %d Tagen"], math.ceil(left / 86400))
end

function Cd:Ask(x)
	local to = ns.Roster:OnlineChar(x.who) or x.who
	local text = string.format(L["Hallo %s! Deine Abklingzeit für %s ist bereit – könntest du sie für mich nutzen? Mats bringe ich mit."], to, x.name)
	ns.OpenWhisper(to, text)
end

-- wann neu lesen
ns:Listen("GS_LOGIN", function() C_Timer.After(22, function() Cd:Scan(true) end) end)
ns:On("TRADE_SKILL_SHOW", function() C_Timer.After(1, function() Cd:Scan() end) end)
ns:On("UNIT_SPELLCAST_SUCCEEDED", function(unit, _, spellID)
	-- WoW Forever: Einheit oder Spell-ID können im Kampf "secret values" sein
	if ns.IsSecret(unit) or ns.IsSecret(spellID) then return end
	if unit ~= "player" then return end
	for _, c in ipairs(Cd.LIST) do
		for _, id in ipairs(c.spells or {}) do
			if id == spellID then C_Timer.After(1.5, function() Cd:Scan() end) return end
		end
	end
end)
ns:On("BAG_UPDATE_COOLDOWN", function()
	if Cd.pending then return end
	Cd.pending = true
	C_Timer.After(3, function() Cd.pending = false; Cd:Scan() end)
end)
