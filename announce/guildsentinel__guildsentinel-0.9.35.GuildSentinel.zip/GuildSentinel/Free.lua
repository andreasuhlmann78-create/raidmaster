-- GuildSentinel - Free.lua
-- "Bin frei für …": Mit einem Klick meldet man sich frei für Dungeon, Raid, Quest-Gruppe oder PvP.
-- Alle mit GuildSentinel sehen es in der Gruppensuche (Reiter "Wer ist frei"). In einer Instanz
-- (Dungeon, Raid, Schlachtfeld) gilt man automatisch als beschäftigt; danach ist man wieder frei.
-- Dazu die Gegenstandsstufe (Durchschnitt der angelegten Ausrüstung), die auch bei "Ich komme mit" mitgeht.
--
--   ns.db.freeBy[Charakter] = { k = { dungeon, raid, quest, pvp }, u = bis (Zeit) }   -- eigene Meldung je Charakter
--   Fr.list[Name] = { k, u, l, c, z, il, b = beschäftigt, t }              -- Meldungen der anderen (nicht gespeichert)

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local Fr = {}
ns.Free = Fr

Fr.KINDS = {
	{ key = "dungeon", n = N["Dungeon"] },
	{ key = "raid", n = N["Raid"] },
	{ key = "quest", n = N["Quest-Gruppe"] },
	{ key = "pvp", n = N["PvP"] },
}
Fr.DURATIONS = { 1, 2, 4 }   -- Stunden
Fr.list = {}

------------------------------------------------------------
-- Gegenstandsstufe
------------------------------------------------------------
local SLOTS = { 1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 }

-- Durchschnitt über alle Plätze (leere zählen als 0, Zweihänder zählt für die Nebenhand mit)
function ns.ItemLevel()
	if not GetInventoryItemLink then return nil end
	local sum, any = 0, false
	local mainLevel, twoHand = 0, false
	for _, slot in ipairs(SLOTS) do
		local link = GetInventoryItemLink("player", slot)
		if link then
			local _, _, _, ilvl, _, _, _, _, equipLoc = ns.GetItemInfo(link)
			ilvl = tonumber(ilvl) or 0
			sum = sum + ilvl
			any = true
			if slot == 16 then mainLevel = ilvl; twoHand = equipLoc == "INVTYPE_2HWEAPON" end
		end
	end
	if not any then return nil end
	if twoHand and not GetInventoryItemLink("player", 17) then sum = sum + mainLevel end
	return math.floor(sum / #SLOTS + 0.5)
end

------------------------------------------------------------
-- Eigene Meldung
------------------------------------------------------------
function Fr:KindName(k)
	for _, x in ipairs(self.KINDS) do if x.key == k then return L[x.n] end end
	return k
end

function Fr:KindsText(k)
	local t = {}
	for _, x in ipairs(self.KINDS) do if k and k[x.key] then t[#t + 1] = L[x.n] end end
	return table.concat(t, ", ")
end

-- in einer Instanz (Dungeon, Raid, Schlachtfeld, Arena)?
function Fr:InInstance()
	if not IsInInstance then return false end
	local inside, kind = IsInInstance()
	return inside and kind ~= "none" and true or false
end

local function Own(v)
	if not ns.db then return nil end
	local me = ns.Me()
	if not me then return nil end
	-- im Testmodus nur eine Test-Tabelle (die echte Meldung in den Einstellungen bleibt unberührt)
	local t
	if ns.Test and ns.Test:Active() then
		ns.Test.freeBy = ns.Test.freeBy or {}
		t = ns.Test.freeBy
	else
		ns.db.freeBy = ns.db.freeBy or {}
		t = ns.db.freeBy
	end
	if v ~= nil then t[me] = v or nil end
	return t[me]
end

function Fr:Mine()
	local f = Own()
	if not f or not f.u or f.u <= ns.Now() or not next(f.k or {}) then return nil end
	return f
end

local function Wire()
	local f = Fr:Mine()
	local _, cf = UnitClass("player")
	if not f then return { off = true } end
	return { k = f.k, u = f.u, l = UnitLevel("player"), c = cf, z = ns.Group and ns.Group:MyZone() or "", il = ns.ItemLevel(), b = Fr:InInstance() or nil }
end

function Fr:Send()
	if not ns.InGuild() or not ns.Feature("group") then return end
	ns.Comm:Send("FREE", Wire(), "GUILD", nil, true)
end

-- kinds = { dungeon = true, … }, hours = 1/2/4
function Fr:Set(kinds, hours)
	local k = {}
	for _, x in ipairs(self.KINDS) do if kinds and kinds[x.key] then k[x.key] = true end end
	if not next(k) then ns:Print(L["Bitte mindestens eine Sache wählen, für die du frei bist."]) return end
	hours = tonumber(hours) or 2
	local f = Own({ k = k, u = ns.Now() + hours * 3600 })
	self:Send()
	ns:Print(string.format(L["Du bist jetzt frei für: %s (bis %s)."], self:KindsText(k), date("%H:%M", f.u)))
	ns:Fire("GS_FREE")
end

function Fr:Clear()
	if not Own() then return end
	Own(false)
	ns.Comm:Send("FREE", { off = true }, "GUILD", nil, true)
	ns:Print(L["Du bist nicht mehr als frei gemeldet."])
	ns:Fire("GS_FREE")
end

------------------------------------------------------------
-- Meldungen der anderen
------------------------------------------------------------
function Fr:Store(sender, d)
	if type(d) ~= "table" then return end
	if d.off then self.list[sender] = nil return end
	local k = {}
	if type(d.k) == "table" then
		for _, x in ipairs(self.KINDS) do if d.k[x.key] then k[x.key] = true end end
	end
	local u = tonumber(d.u)
	if not next(k) or not u then self.list[sender] = nil return end
	self.list[sender] = { k = k, u = math.min(u, ns.Now() + 4 * 3600 + 60), l = tonumber(d.l) or 0, c = d.c,
		z = type(d.z) == "string" and d.z:sub(1, 40) or nil, il = tonumber(d.il), b = d.b and true or nil, t = ns.Now() }
end

ns.Comm:Register("FREE", function(sender, d)
	if ns.Same(sender, ns.Me()) then return end
	Fr:Store(sender, d)
	ns:Fire("GS_FREE")
end)

-- wer neu online kommt, fragt nach; wer frei ist, antwortet (leicht verzögert, damit nicht alle gleichzeitig)
ns.Comm:Register("FREEQ", function(sender)
	if ns.Same(sender, ns.Me()) or not Fr:Mine() then return end
	ns.Later(1 + math.random() * 4, function() Fr:Send() end)
end)

-- { { name, k, u, l, c, z, il, busy } } – nur wer online ist und dessen Meldung noch läuft
function Fr:List(kind)
	local out = {}
	local now = ns.Now()
	for name, x in pairs(self.list) do
		local e = ns.Roster.byName[name]
		local online = (e and e.online) or (ns.Test and ns.Test:Active())
		if x.u > now and online and (not kind or x.k[kind]) then
			out[#out + 1] = { name = name, k = x.k, u = x.u, l = (e and e.level) or x.l, c = (e and e.class) or x.c,
				z = ns.Group and ns.Group:ZoneOf(name, x.z) or x.z, il = x.il, busy = x.b }
		end
	end
	local mine = self:Mine()
	if mine and (not kind or mine.k[kind]) then
		local _, cf = UnitClass("player")
		out[#out + 1] = { name = ns.Me(), k = mine.k, u = mine.u, l = UnitLevel("player"), c = cf, z = ns.Group and ns.Group:MyZone(), il = ns.ItemLevel(), busy = self:InInstance() or nil, me = true }
	end
	table.sort(out, function(a, b)
		if (a.busy and 1 or 0) ~= (b.busy and 1 or 0) then return not a.busy end
		return a.name < b.name
	end)
	return out
end

-- Art einer Aktivität der Gruppensuche ("dungeon", "raid", "quest", "pvp" oder nil)
function Fr:KindOf(act)
	local a = ns.Group and ns.Group.BY_KEY[act]
	if not a then return nil end
	if a.raid then return "raid" end
	if a.min then return "dungeon" end
	if act == "quest" or act == "pvp" then return act end
	return nil
end

-- wie viele sind gerade frei (und nicht beschäftigt) für diese Aktivität?
function Fr:CountFor(act)
	local kind = self:KindOf(act)
	if not kind then return 0 end
	local n = 0
	for _, x in ipairs(self:List(kind)) do if not x.busy and not x.me then n = n + 1 end end
	return n
end

------------------------------------------------------------
-- automatisch: Instanz = beschäftigt, Ablauf, Abfrage beim Einloggen
------------------------------------------------------------
local lastInside
local function CheckInstance()
	local inside = Fr:InInstance()
	if inside ~= lastInside then
		lastInside = inside
		if Fr:Mine() then Fr:Send(); ns:Fire("GS_FREE") end
	end
end
ns:On("PLAYER_ENTERING_WORLD", function() C_Timer.After(2, CheckInstance) end)
ns:On("ZONE_CHANGED_NEW_AREA", function() C_Timer.After(1, CheckInstance) end)

ns:On("PLAYER_LOGIN", function()
	C_Timer.After(12, function()
		if ns.InGuild() and ns.Feature("group") then
			ns.Comm:Send("FREEQ", {}, "GUILD")
			if Fr:Mine() then Fr:Send() end
		end
	end)
end)

C_Timer.NewTicker(60, function()
	local now = ns.Now()
	local changed = false
	for name, x in pairs(Fr.list) do if x.u <= now then Fr.list[name] = nil; changed = true end end
	local own = Own()
	if own and (own.u or 0) <= now then Own(false); changed = true end
	if changed then ns:Fire("GS_FREE") end
end)

-- nach einer neuen Suche: Hinweis, wie viele gerade frei sind
do
	local G = ns.Group
	local orig = G.Post
	G.Post = function(self, act, ...)
		local s = orig(self, act, ...)
		if s then
			local n = Fr:CountFor(s.act)
			if n > 0 then
				ns:Print(string.format(L["%d aus der Gilde sind gerade frei für %s – siehe Gruppensuche > Wer ist frei."], n, Fr:KindName(Fr:KindOf(s.act))))
			end
		end
		return s
	end
end
