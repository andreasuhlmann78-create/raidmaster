-- GuildSentinel - RecipeKind.lua
-- Art eines Rezepts (Kopf, Brust, Waffen, Heiltränke, Elixiere, Verzaubern: Brust …) für die Seite Berufe:
-- Rezeptliste eines Mitglieds mit Filterleiste nach Art.
--
-- Woher die Art kommt (in dieser Reihenfolge):
--   1. Blizzard-Kategorie des Rezepts (Feld k, nur wo das Spiel sie liefert – WoW Forever, eigenes Fenster)
--   2. Item-ID (Feld i) über ns.API.GetItemInfoInstant: classID, subclassID, Rüstungsplatz (equipLoc) – in jeder Sprache
--   3. Namensmuster (Rezept- bzw. Itemname) für Deutsch, Englisch, Französisch, Spanisch, Italienisch, Portugiesisch,
--      Russisch – vor allem Verzauberkunst (keine Items) und Tränke
--   sonst "Sonstiges"
-- Keine neuen Pflichtfelder in den Sync-Daten: alte Sender (ohne i, s, k) ergeben "Sonstiges" bzw. die Namensmuster.
-- Ergebnisse je Item-ID bzw. Name werden zwischengespeichert (kein Rechnen je Bild).

local ADDON, ns = ...
local L = ns.L
local K = {}
ns.Kinds = K

------------------------------------------------------------
-- Arten: Schlüssel -> Anzeige (Locales) und Reihenfolge in der Filterleiste
------------------------------------------------------------
K.ORDER = {
	-- Rüstung und Waffen (Schmiedekunst, Lederverarbeitung, Schneiderei, Ingenieurskunst)
	"head", "neck", "shoulder", "chest", "back", "wrist", "hands", "waist", "legs", "feet", "finger", "trinket",
	"shield", "weapon1", "weapon2", "ranged", "bag", "ammo",
	-- Alchemie
	"healpot", "manapot", "rejuv", "protpot", "potion", "elixir", "flask", "oil", "transmute",
	-- Ingenieurskunst
	"explosive", "device", "scope", "parts",
	-- Verzauberkunst (Ziel-Platz)
	"ench_chest", "ench_wrist", "ench_back", "ench_feet", "ench_hands", "ench_weapon", "ench_2h", "ench_shield", "rod",
	-- Kochen, Erste Hilfe
	"food", "bandage",
	-- Material und Rest
	"reagent", "other",
}
K.RANK = {}
for i, k in ipairs(K.ORDER) do K.RANK[k] = i end

function K.Label(key)
	local t = {
		head = L["Kopf"], neck = L["Hals"], shoulder = L["Schultern"], chest = L["Brust"], back = L["Rücken"],
		wrist = L["Handgelenke"], hands = L["Hände"], waist = L["Taille"], legs = L["Beine"], feet = L["Füsse"],
		finger = L["Finger"], trinket = L["Schmuck"], shield = L["Schild"], weapon1 = L["Einhandwaffen"],
		weapon2 = L["Zweihandwaffen"], ranged = L["Fernkampf"], bag = L["Taschen"], ammo = L["Munition"],
		healpot = L["Heiltränke"], manapot = L["Manatränke"], rejuv = L["Erholungstränke"], protpot = L["Schutztränke"],
		potion = L["Tränke"], elixir = L["Elixiere"], flask = L["Fläschchen"], oil = L["Öle"], transmute = L["Transmutationen"],
		explosive = L["Sprengstoff"], device = L["Geräte"], scope = L["Zielfernrohre"], parts = L["Teile"],
		ench_chest = L["Brust"], ench_wrist = L["Armschiene"], ench_back = L["Umhang"], ench_feet = L["Stiefel"],
		ench_hands = L["Handschuhe"], ench_weapon = L["Waffe"], ench_2h = L["Zweihandwaffe"], ench_shield = L["Schild"],
		rod = L["Stäbe"], food = L["Essen"], bandage = L["Verbände"], reagent = L["Reagenzien"], other = L["Sonstiges"],
	}
	if type(key) == "string" and key:sub(1, 2) == "k:" then return key:sub(3) end     -- Blizzard-Kategorie
	return t[key] or L["Sonstiges"]
end

-- Sortierrang (Blizzard-Kategorien nach den eigenen Arten, alphabetisch)
function K.Rank(key)
	return K.RANK[key] or (#K.ORDER + 1)
end

------------------------------------------------------------
-- 2. Item-ID: Rüstungsplatz, Klasse, Unterklasse (GetItemInfoInstant, auch ohne Cache des Spiels)
------------------------------------------------------------
local EQUIP = {
	INVTYPE_HEAD = "head", INVTYPE_NECK = "neck", INVTYPE_SHOULDER = "shoulder", INVTYPE_CHEST = "chest",
	INVTYPE_ROBE = "chest", INVTYPE_BODY = "chest", INVTYPE_CLOAK = "back", INVTYPE_WRIST = "wrist", INVTYPE_HAND = "hands",
	INVTYPE_WAIST = "waist", INVTYPE_LEGS = "legs", INVTYPE_FEET = "feet", INVTYPE_FINGER = "finger",
	INVTYPE_TRINKET = "trinket", INVTYPE_SHIELD = "shield", INVTYPE_HOLDABLE = "shield",
	INVTYPE_WEAPON = "weapon1", INVTYPE_WEAPONMAINHAND = "weapon1", INVTYPE_WEAPONOFFHAND = "weapon1",
	INVTYPE_2HWEAPON = "weapon2", INVTYPE_RANGED = "ranged", INVTYPE_RANGEDRIGHT = "ranged", INVTYPE_THROWN = "ranged",
	INVTYPE_BAG = "bag", INVTYPE_AMMO = "ammo", INVTYPE_QUIVER = "bag",
}
K.EQUIP = EQUIP

-- Klassen (gleiche Nummern in Classic und Forever): 0 Verbrauch, 1 Behälter, 2 Waffe, 4 Rüstung, 5 Reagenz,
-- 6 Projektil, 7 Handwerkswaren, 11 Köcher, 15 Verschiedenes
-- Verbrauch, Unterklassen: 1 Trank, 2 Elixier, 3 Fläschchen, 5 Essen/Trinken, 6 Gegenstandsverbesserung (Öle,
-- Wetzsteine), 7 Verband
-- Handwerkswaren, Unterklassen (Classic): 1 Teile, 2 Sprengstoff, 3 Geräte
local function FromItem(id)
	local A = ns.API
	if not (A.GetItemInfoInstant and type(id) == "number" and id > 0) then return nil end
	local ok, itemID, _, _, equipLoc, _, classID, subclassID = pcall(A.GetItemInfoInstant, id)
	if not ok or not itemID or ns.IsSecret(classID) then return nil end
	if type(equipLoc) == "string" and EQUIP[equipLoc] then return EQUIP[equipLoc] end
	if classID == 2 then return "weapon1" end
	if classID == 1 or classID == 11 then return "bag" end
	if classID == 6 then return "ammo" end
	if classID == 0 then
		if subclassID == 1 then return "potion" end         -- genauer über den Namen (Heil-/Mana-/Erholung/Schutz)
		if subclassID == 2 then return "elixir" end
		if subclassID == 3 then return "flask" end
		if subclassID == 5 then return "food" end
		if subclassID == 6 then return "oil" end
		if subclassID == 7 then return "bandage" end
		return nil                                          -- Rest über den Namen (Sprengstoff, Zielfernrohr …)
	end
	if classID == 7 then
		if subclassID == 1 then return "parts" end
		if subclassID == 2 then return "explosive" end
		if subclassID == 3 then return "device" end
		return "reagent"
	end
	if classID == 5 then return "reagent" end
	return nil
end
K.FromItem = FromItem

------------------------------------------------------------
-- 3. Namensmuster (kleingeschrieben, ohne Umlaut-Sonderbehandlung; mehrere Sprachen nebeneinander)
------------------------------------------------------------
local P = {
	transmute = { "transmut", "трансмут" },
	rejuv = { "erholung", "verjüngung", "rejuvenation", "restorative", "rajeunissement", "rejuvenecimiento", "ringiovanimento",
		"rejuvenescimento", "омоложени" },
	heal = { "heil", "healing", "soins", "curación", "curacion", "cura", "лечени", "исцелени" },
	mana = { "mana", "маны" },
	prot = { "schutz", "protection", "protección", "protezione", "proteção", "защит" },
	elixir = { "elixier", "elixir", "élixir", "elisir", "эликсир" },
	flask = { "fläschchen", "flask", "flacon", "frasco", "tonico", "фляг" },
	potion = { "trank", "potion", "poción", "pocion", "pozione", "poção", "зелье" },
	oil = { "öl", "oil", "huile", "aceite", "olio", "óleo", "масло" },
	explosive = { "bombe", "sprengstoff", "dynamit", "bomb", "explosive", "dynamite", "grenade", "granate", "explosif",
		"explosivo", "esplosiv", "бомб", "динамит", "взрыв" },
	scope = { "zielfernrohr", "scope", "lunette", "mira", "mirino", "прицел" },
	ammo = { "munition", "kugel", "pfeil", "ammo", "shot", "bullet", "arrow", "balle", "flèche", "bala", "flecha", "пул", "стрел" },
	rod = { "rute", "rod", "baguette", "vara", "verga", "жезл" },
	bandage = { "verband", "bandage", "venda", "benda", "bandagem", "бинт" },
	enchant = { "verzaubern", "enchant", "enchanter", "encantar", "incanta", "чары", "зачаров" },
}
K.PATTERNS = P

-- Verzauberkunst: Ziel aus dem Namen ("Verzaubern: Brust – …", "Enchant Chest - …"). Zweihandwaffe vor Waffe prüfen.
local ENCH = {
	{ "ench_2h", { "zweihandwaffe", "2h weapon", "2h-waffe", "two-handed weapon", "arme à deux mains", "arma de dos manos",
		"arma a due mani", "arma de duas mãos", "двуручн" } },
	{ "ench_chest", { "brust", "chest", "torse", "pechera", "torso", "peito", "нагрудник" } },
	{ "ench_wrist", { "armschiene", "bracer", "bracelet", "brazal", "bracciale", "braçadeira", "наруч" } },
	{ "ench_back", { "umhang", "cloak", "cape", "capa", "mantello", "плащ" } },
	{ "ench_feet", { "stiefel", "boots", "bottes", "botas", "stivali", "ботин", "сапог" } },
	{ "ench_hands", { "handschuhe", "gloves", "gants", "guantes", "guanti", "luvas", "перчат" } },
	{ "ench_shield", { "schild", "shield", "bouclier", "escudo", "scudo", "щит" } },
	{ "ench_weapon", { "waffe", "weapon", "arme", "arma", "оружи" } },
}

local function Has(text, list)
	for _, w in ipairs(list) do
		if text:find(w, 1, true) then return true end
	end
	return false
end

local function FromName(name)
	if type(name) ~= "string" or name == "" or ns.IsSecret(name) then return nil end
	local t = name:lower()
	if Has(t, P.transmute) then return "transmute" end
	if Has(t, P.enchant) then
		for _, e in ipairs(ENCH) do
			if Has(t, e[2]) then return e[1] end
		end
		if Has(t, P.oil) then return "oil" end
		return "other"
	end
	if Has(t, P.rod) then return "rod" end
	if Has(t, P.rejuv) or (Has(t, P.heal) and Has(t, P.mana)) then return "rejuv" end
	if Has(t, P.flask) then return "flask" end
	if Has(t, P.elixir) then return "elixir" end
	if Has(t, P.potion) then
		if Has(t, P.heal) then return "healpot" end
		if Has(t, P.mana) then return "manapot" end
		if Has(t, P.prot) then return "protpot" end
		return "potion"
	end
	if Has(t, P.oil) then return "oil" end
	if Has(t, P.explosive) then return "explosive" end
	if Has(t, P.scope) then return "scope" end
	if Has(t, P.bandage) then return "bandage" end
	return nil
end
K.FromName = FromName

------------------------------------------------------------
-- Gesamt: Art eines Rezepts. cat = Blizzard-Kategorie (Feld k) oder nil
------------------------------------------------------------
K.cache = {}       -- "i:<id>|<name>" -> Art
function K.Of(name, itemID, cat)
	if type(cat) == "string" and cat ~= "" and not ns.IsSecret(cat) then return "k:" .. cat end
	itemID = tonumber(itemID) or 0
	local ck = itemID .. "|" .. tostring(name)
	local c = K.cache[ck]
	if c then return c end
	local kind = FromItem(itemID)
	-- Tränke: Item sagt "Trank", der Name sagt welcher; Verbrauch ohne Unterklasse: Name entscheidet
	local byName = FromName(name)
	if kind == "potion" and byName and (byName == "healpot" or byName == "manapot" or byName == "rejuv" or byName == "protpot") then
		kind = byName
	elseif byName == "transmute" or (byName and byName:sub(1, 5) == "ench_") then
		kind = byName                                         -- Rezeptname schlägt das Ergebnis-Item
	elseif not kind then
		kind = byName
	end
	kind = kind or "other"
	-- nur zwischenspeichern, wenn das Item bekannt ist (sonst später noch einmal versuchen)
	if itemID == 0 or ns.API.GetItemInfoInstant then K.cache[ck] = kind end
	return kind
end
