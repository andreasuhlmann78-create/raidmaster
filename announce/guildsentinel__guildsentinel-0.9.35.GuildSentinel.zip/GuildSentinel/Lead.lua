-- GuildSentinel - Lead.lua
-- Werkzeuge für die Gildenleitung (nur Offiziere sehen und teilen diese Daten):
--   * Offiziersnotizen mit Verlauf: längere, datierte Einträge je Spieler (die Gildennotiz hat nur 31 Zeichen).
--     Sie gehen per Flüstern nur an Offiziere mit GuildSentinel, nie an die ganze Gilde.
--   * Abgänge mit Grund: Wer geht oder entfernt wird, bleibt mit Datum, letzter Stufe und Rang in der Liste;
--     die Leitung kann einen Grund eintragen ("zu Gilde X gewechselt").
--   * Probezeit: Neue Mitglieder haben eine Probezeit (Standard 14 Tage). GuildSentinel zählt Online-Tage,
--     besuchte Termine und erhaltene Danke und schlägt danach "Befördern" oder "Gespräch" vor.
--   * Rangrechte: welcher Rang was darf (einladen, entfernen, Notizen …) – mit den Bezeichnungen des Spiels.
--   * Pate vorschlagen: wer zu ähnlichen Zeiten online ist wie der Neue (aus den Online-Zeiten je Spieler).
--
--   G.onotes[Name] = { [id] = { id, t, by, text, del } }
--   G.gone[Name]   = { t, k = "leave"/"kick", l, c, r, reason, rt }
--   G.probation    = { days, t, by }
--   G.hours[Main]  = { [Wochenstunde 0–167] = Anzahl Messungen online }

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local Le = {}
ns.Lead = Le

Le.PROBATION_DAYS = 14

------------------------------------------------------------
-- Wer ist Offizier? (oberste zwei Ränge – wie bei den anderen Leitungs-Funktionen)
------------------------------------------------------------
function Le:IsOfficerName(name)
	local e = ns.Roster.byName[name]
	return e and e.ri <= 1 or false
end

-- Offiziere mit GuildSentinel, die gerade online sind (ohne mich)
function Le:OnlineOfficers()
	local out = {}
	for name in pairs(ns.Comm.users or {}) do
		if not ns.Same(name, ns.Me()) and self:IsOfficerName(name) and ns.Roster:OnlineChar(name) then out[#out + 1] = name end
	end
	return out
end

function Le:SendOfficers(msgType, data)
	for _, name in ipairs(self:OnlineOfficers()) do ns.Comm:Send(msgType, data, "WHISPER", name) end
end

-- Nachricht von einem Offizier an mich als Offizier?
local function FromOfficer(sender)
	return ns.IsOfficer() and Le:IsOfficerName(sender)
end

------------------------------------------------------------
-- Offiziersnotizen
------------------------------------------------------------
local counter = 0

function Le:Notes(name)
	local out = {}
	for _, e in pairs(ns.G().onotes[name] or {}) do
		if not e.del then out[#out + 1] = e end
	end
	table.sort(out, function(a, b) return (a.t or 0) > (b.t or 0) end)
	return out
end

-- Spieler mit Notizen: { { name, n, last } }
function Le:NotedPlayers()
	local out = {}
	for name in pairs(ns.G().onotes) do
		local list = self:Notes(name)
		if #list > 0 then out[#out + 1] = { name = name, n = #list, last = list[1].t, text = list[1].text } end
	end
	table.sort(out, function(a, b) return (a.last or 0) > (b.last or 0) end)
	return out
end

function Le:AddNote(name, text)
	local g = ns.guild
	text = ns.Trim(text)
	if not g or not name or text == "" then return end
	if not ns.IsOfficer() then ns:Print(L["Offiziersnotizen können nur Offiziere schreiben."]) return end
	counter = counter + 1
	local e = { id = ns.Me() .. ns.Now() .. counter, t = ns.Now(), by = ns.Me(), text = text:sub(1, 400) }
	g.onotes[name] = g.onotes[name] or {}
	g.onotes[name][e.id] = e
	self:SendOfficers("ONOTE", { n = name, e = e })
	ns:Fire("GS_LEAD")
	return e
end

function Le:DeleteNote(name, id)
	local g = ns.guild
	local e = g and g.onotes[name] and g.onotes[name][id]
	if not e or not ns.IsOfficer() then return end
	e.del, e.t = true, ns.Now()
	self:SendOfficers("ONOTE", { n = name, e = e })
	ns:Fire("GS_LEAD")
end

local function StoreNote(name, e)
	local g = ns.guild
	if not g or type(name) ~= "string" or type(e) ~= "table" or type(e.id) ~= "string" or type(e.t) ~= "number" then return false end
	g.onotes[name] = g.onotes[name] or {}
	local old = g.onotes[name][e.id]
	if old and (old.t or 0) >= e.t and not (e.del and not old.del) then return false end
	g.onotes[name][e.id] = { id = e.id, t = e.t, by = type(e.by) == "string" and e.by or "?", text = type(e.text) == "string" and e.text:sub(1, 400) or "", del = e.del and true or nil }
	return true
end
Le.StoreNote = StoreNote

ns.Comm:Register("ONOTE", function(sender, d)
	if not FromOfficer(sender) then return end
	if StoreNote(d.n, d.e) then ns:Fire("GS_LEAD") end
end)
ns.Comm:Register("ONOTES", function(sender, d)
	if not FromOfficer(sender) or type(d.e) ~= "table" then return end
	local any
	for name, list in pairs(d.e) do
		if type(list) == "table" then for _, e in pairs(list) do if StoreNote(name, e) then any = true end end end
	end
	if type(d.g) == "table" then
		for name, x in pairs(d.g) do if Le.StoreGone(name, x) then any = true end end
	end
	if any then ns:Fire("GS_LEAD") end
end)

-- beim Abgleich: ein Offizier schickt einem anderen Offizier Notizen und Abgänge
function Le:SyncTo(to)
	if not ns.IsOfficer() or not self:IsOfficerName(to) then return end
	local g = ns.guild
	if not g or (not next(g.onotes) and not next(g.gone)) then return end
	ns.Comm:Send("ONOTES", { e = g.onotes, g = g.gone }, "WHISPER", to)
end

------------------------------------------------------------
-- Name der Gilde (Anzeige): legt nur der Gildenmeister fest, geht an alle in der Gilde
------------------------------------------------------------
function Le:SetGuildName(text)
	local g = ns.guild
	if not g then return false end
	if not ns.IsGM() then ns:Print(L["Den Gildennamen kann nur der Gildenmeister ändern."]) return false end
	local n = ns.Trim(text or ""):sub(1, 40)
	g.gname = { n = n, t = ns.Now(), by = ns.Me() }
	ns.Comm:Send("GNAME", g.gname)
	ns:Print(n ~= "" and string.format(L["Gildenname für GuildSentinel: %s"], n) or L["Gildenname: wieder der Name aus dem Spiel."])
	ns:Fire("GS_ROSTER")
	return true
end

ns.Comm:Register("GNAME", function(sender, d)
	local g = ns.guild
	if not g or type(d) ~= "table" or type(d.n) ~= "string" or type(d.t) ~= "number" then return end
	-- nur vom Gildenmeister annehmen
	local e = ns.Roster.byName[sender]
	if not e or e.ri ~= 0 then return end
	if g.gname and (g.gname.t or 0) >= d.t then return end
	g.gname = { n = d.n:sub(1, 40), t = d.t, by = sender }
	ns:Fire("GS_ROSTER")
end)

-- der Gildenmeister verteilt den Namen nach dem Einloggen (für alle, die neu dazugekommen sind)
ns:Listen("GS_LOGIN", function()
	C_Timer.After(25, function()
		local g = ns.guild
		if g and g.gname and g.gname.t and ns.IsGM() and ns.InGuild() then ns.Comm:Send("GNAME", g.gname) end
	end)
end)

------------------------------------------------------------
-- Abgänge mit Grund
------------------------------------------------------------
function Le:RecordGone(kind, name, t)
	local g = ns.guild
	if not g or not name then return end
	local r = g.roster[name] or {}
	local old = g.gone[name]
	g.gone[name] = { t = t or ns.Now(), k = kind, l = r.l, c = r.c, r = r.r, reason = old and old.reason or "", rt = old and old.rt or 0 }
	ns:Fire("GS_LEAD")
end

function Le:SetGoneReason(name, text)
	local g = ns.guild
	local x = g and g.gone[name]
	if not x then return end
	if not ns.IsOfficer() then ns:Print(L["Gründe können nur Offiziere eintragen."]) return end
	x.reason, x.rt = ns.Trim(text):sub(1, 120), ns.Now()
	self:SendOfficers("GONE", { n = name, x = x })
	ns:Fire("GS_LEAD")
end

local function StoreGone(name, x)
	local g = ns.guild
	if not g or type(name) ~= "string" or type(x) ~= "table" or type(x.t) ~= "number" then return false end
	local old = g.gone[name]
	if old and (old.rt or 0) >= (tonumber(x.rt) or 0) and (old.t or 0) >= x.t then return false end
	g.gone[name] = { t = math.max(x.t, old and old.t or 0), k = x.k == "kick" and "kick" or "leave", l = tonumber(x.l), c = x.c, r = x.r,
		reason = (old and (old.rt or 0) > (tonumber(x.rt) or 0)) and old.reason or (type(x.reason) == "string" and x.reason or ""),
		rt = math.max(tonumber(x.rt) or 0, old and old.rt or 0) }
	return true
end
Le.StoreGone = StoreGone

ns.Comm:Register("GONE", function(sender, d)
	if not FromOfficer(sender) then return end
	if StoreGone(d.n, d.x) then ns:Fire("GS_LEAD") end
end)

-- { { name, t, k, l, c, r, reason } } – neueste zuerst; wer zurückgekommen ist, fällt heraus
function Le:Gone(days)
	local limit = days and (ns.Now() - days * 86400) or 0
	local out = {}
	for name, x in pairs(ns.G().gone) do
		if x.t >= limit and not ns.Roster.byName[name] then
			out[#out + 1] = { name = name, t = x.t, k = x.k, l = x.l, c = x.c, r = x.r, reason = x.reason }
		end
	end
	table.sort(out, function(a, b) return a.t > b.t end)
	return out
end

-- jeden Abgang aus dem Verlauf mitschreiben
do
	local R = ns.Roster
	local orig = R.Log
	R.Log = function(self, kind, name, extra, t)
		orig(self, kind, name, extra, t)
		if kind == "leave" or kind == "kick" then Le:RecordGone(kind, name, t) end
	end
end

------------------------------------------------------------
-- Probezeit
------------------------------------------------------------
function Le:ProbationDays()
	local p = ns.G().probation
	return (p and tonumber(p.days)) or self.PROBATION_DAYS
end

function Le:SetProbationDays(n)
	local g = ns.guild
	if not g then return end
	if not ns.IsOfficer() then ns:Print(L["Die Probezeit können nur Offiziere ändern."]) return end
	n = tonumber(n)
	if not n or n < 1 or n > 120 then ns:Print(L["Bitte eine Zahl von 1 bis 120 eingeben."]) return end
	g.probation = { days = math.floor(n), t = ns.Now(), by = ns.Me() }
	ns.Comm:Send("PROB", g.probation)
	ns:Fire("GS_LEAD")
end

ns.Comm:Register("PROB", function(sender, d)
	local g = ns.guild
	if not g or not Le:IsOfficerName(sender) or type(d.t) ~= "number" then return end
	if g.probation and (g.probation.t or 0) >= d.t then return end
	g.probation = { days = tonumber(d.days) or Le.PROBATION_DAYS, t = d.t, by = d.by or sender }
	ns:Fire("GS_LEAD")
end)

-- Beitritt (frühester bekannter Zeitpunkt) eines Spielers
function Le:JoinTime(name)
	local g = ns.G()
	local t = g.firstSeen[name]
	if t and t > 0 then return t end
	local r = g.roster[name]
	return r and r.first and r.first > 0 and r.first or nil
end

-- Probezeit-Liste: Mains, die vor höchstens (Probezeit + 30) Tagen gekommen sind
-- { { name, class, level, join, days, online, events, thanks, due, advice } }
function Le:Probation()
	local g = ns.G()
	local now = ns.Now()
	local pd = self:ProbationDays()
	local out = {}
	for _, e in ipairs(ns.Roster.list) do
		local join = self:JoinTime(e.name)
		if join and not ns.Roster:IsAlt(e.name) and now - join <= (pd + 30) * 86400 and e.ri > 1 then
			local joinDay = math.floor(join / 86400)
			local online = 0
			for _, ch in ipairs(ns.Roster:AltsOf(e.name)) do
				for d in pairs(g.days[ch] or {}) do if d >= joinDay then online = online + 1 end end
			end
			for d in pairs(g.days[e.name] or {}) do if d >= joinDay then online = online + 1 end end
			local events = 0
			for _, ev in pairs(g.events or {}) do
				local r = ev.r and ev.r[e.name]
				if not ev.del and r and r.s == "yes" and ev.t >= join and ev.t < now then events = events + 1 end
			end
			local thanks = 0
			for _, t in pairs(g.thanks or {}) do
				if (ns.Roster:MainOf(t.to) or t.to) == e.name and t.t >= join then thanks = thanks + 1 end
			end
			local days = math.floor((now - join) / 86400)
			local due = days >= pd
			-- Regel: an mindestens 40 % der Tage seit dem Beitritt online (höchstens die letzten 60 Tage zählen), mindestens 3
			local span = math.max(1, math.min(days, 60))
			local pct = online / span
			local advice
			if not due then advice = "running"
			elseif online >= 3 and pct >= 0.4 then advice = "promote"
			else advice = "talk" end
			out[#out + 1] = { name = e.name, class = e.class, level = e.level, rank = e.rank, join = join, days = days, online = online, pct = pct,
				events = events, thanks = thanks, due = due, advice = advice, left = math.max(0, pd - days), mentor = ns.Social:MentorOf(e.name) }
		end
	end
	table.sort(out, function(a, b)
		if a.due ~= b.due then return a.due end
		return a.join < b.join
	end)
	return out
end

function Le:AdviceText(x)
	if x.advice == "promote" then return L["Befördern"] end
	if x.advice == "talk" then return L["Gespräch"] end
	return string.format(L["noch %d Tage"], x.left)
end

------------------------------------------------------------
-- Online-Zeiten je Spieler (für den Paten-Vorschlag) und Pate vorschlagen
------------------------------------------------------------
function Le:SampleHours()
	local g = ns.guild
	if not g then return end
	local d = date("*t", ns.Now())
	local how = ((d.wday - 1) * 24) + d.hour         -- 0 = Sonntag 0 Uhr … 167
	local seen = {}
	for _, e in ipairs(ns.Roster.list) do
		if e.online then
			local m = ns.Roster:MainOf(e.name) or e.name
			if not seen[m] then
				seen[m] = true
				g.hours[m] = g.hours[m] or {}
				g.hours[m][how] = math.min(9999, (g.hours[m][how] or 0) + 1)
			end
		end
	end
end
C_Timer.NewTicker(300, function() Le:SampleHours() end)

-- Übereinstimmung der Online-Zeiten (0–1)
function Le:Overlap(a, b)
	local ha, hb = ns.G().hours[a], ns.G().hours[b]
	if not ha or not hb then return 0 end
	local sa, sb, common = 0, 0, 0
	for h, n in pairs(ha) do sa = sa + n; common = common + math.min(n, hb[h] or 0) end
	for _, n in pairs(hb) do sb = sb + n end
	if sa == 0 or sb == 0 then return 0 end
	return common / math.min(sa, sb)
end

-- bester Pate für einen Neuen: kein Rekrut, regelmäßig online, ähnliche Zeiten; Hilfsbereitschaft zählt mit
function Le:SuggestMentor(name)
	local me = ns.Roster.byName[name]
	if not me then return nil end
	local thanks = {}
	for _, x in ipairs(ns.Social:ThanksTop(60)) do thanks[x.name] = x.n end
	local best, bestScore, bestOverlap
	local today = math.floor(ns.Now() / 86400)
	for _, e in ipairs(ns.Roster.list) do
		if not ns.Same(e.name, name) and not ns.Roster:IsAlt(e.name) and e.ri < me.ri and e.level >= math.min(me.level + 5, ns.Roster.MAX_LEVEL) then
			local active = 0
			for d in pairs(ns.G().days[e.name] or {}) do if d > today - 14 then active = active + 1 end end
			if active >= 4 then
				local ov = self:Overlap(name, e.name)
				local score = ov * 10 + math.min(active, 14) * 0.3 + math.min(thanks[e.name] or 0, 10) * 0.2
				if not best or score > bestScore then best, bestScore, bestOverlap = e.name, score, ov end
			end
		end
	end
	return best, bestOverlap
end

------------------------------------------------------------
-- Rangrechte (Bezeichnungen aus dem Spiel)
------------------------------------------------------------
function Le:RankRights()
	local ranks = {}
	local num = GuildControlGetNumRanks and GuildControlGetNumRanks() or 0
	-- Testmodus: die Ränge der Testgilde (die echten Rechte gehören zur echten Gilde)
	if ns.Test and ns.Test:Active() then num = 0 end
	if num == 0 then
		for _, r in ipairs(ns.Roster:Ranks()) do ranks[#ranks + 1] = { name = r.name, ri = r.ri } end
	else
		for i = 1, num do ranks[#ranks + 1] = { name = GuildControlGetRankName and GuildControlGetRankName(i) or ("#" .. i), ri = i - 1 } end
	end
	local labels = {}
	for i = 1, 20 do
		local t = _G["GUILDCONTROL_OPTION" .. i]
		if type(t) == "string" and t ~= "" then labels[#labels + 1] = { i = i, text = t } end
	end
	local readable = false
	for _, r in ipairs(ranks) do
		local flags
		if C_GuildInfo and C_GuildInfo.GuildControlGetRankFlags and not (ns.Test and ns.Test:Active()) then
			local ok, f = pcall(C_GuildInfo.GuildControlGetRankFlags, r.ri + 1)
			if ok and type(f) == "table" then flags = f end
		end
		if not flags and GuildControlSetRank and GuildControlGetRankFlags and not (ns.Test and ns.Test:Active()) then
			local ok = pcall(ns.Act, "GuildControlSetRank", GuildControlSetRank, r.ri + 1)
			if ok then
				local res = { pcall(GuildControlGetRankFlags) }
				if res[1] then table.remove(res, 1); flags = res end
			end
		end
		r.flags = flags or {}
		if flags and next(flags) then readable = true end
	end
	return ranks, labels, readable
end

------------------------------------------------------------
-- Willkommens-Leitfaden für Neue (einmal, in den ersten 7 Tagen)
------------------------------------------------------------
function Le:WelcomeText()
	local g = ns.G()
	local lines = {}
	lines[#lines + 1] = string.format(L["Willkommen in <%s>!"], ns.DisplayGuildName() or "")
	local rules = g.rules and g.rules.text or ""
	if rules ~= "" then
		local short = {}
		for line in rules:gmatch("[^\n]+") do if #short < 4 then short[#short + 1] = "  " .. line end end
		lines[#lines + 1] = ""
		lines[#lines + 1] = L["Das Wichtigste aus den Gildenregeln:"]
		for _, l in ipairs(short) do lines[#lines + 1] = l end
		lines[#lines + 1] = L["Alle Regeln: /gs regeln"]
	end
	local m = ns.Social:MentorOf(ns.Roster:MainOf(ns.Me()) or ns.Me())
	if m then
		lines[#lines + 1] = ""
		lines[#lines + 1] = string.format(L["Dein Pate ist %s – frag ruhig, wenn du etwas brauchst."], m)
	end
	lines[#lines + 1] = ""
	lines[#lines + 1] = L["So findest du dich zurecht:"]
	lines[#lines + 1] = L["  /gs – das Gildenfenster (Mitglieder, Termine, Gruppensuche …)"]
	lines[#lines + 1] = L["  /gs gruppe – Gruppe für einen Dungeon suchen oder mitkommen"]
	lines[#lines + 1] = L["  /gs termine – Gildentermine, zusagen per Klick"]
	lines[#lines + 1] = L["  /gs danke Name – Danke sagen, wenn dir jemand geholfen hat"]
	return table.concat(lines, "\n")
end

function Le:CheckWelcome()
	local g = ns.guild
	if not g or not ns.db then return end
	local me = ns.Me()
	local key = (ns.guildKey or "") .. "|" .. me
	ns.db.welcomed = ns.db.welcomed or {}
	if ns.db.welcomed[key] then return end
	local join = self:JoinTime(ns.Roster:MainOf(me) or me) or self:JoinTime(me)
	if not join or ns.Now() - join > 7 * 86400 then
		ns.db.welcomed[key] = true      -- schon länger da: nie zeigen
		return
	end
	ns.db.welcomed[key] = true
	ns.UI:Info(L["Willkommen!"], self:WelcomeText())
end

ns:Listen("GS_LOGIN", function()
	C_Timer.After(45, function()
		if ns.Test and ns.Test:Active() then return end
		Le:CheckWelcome()
	end)
end)
