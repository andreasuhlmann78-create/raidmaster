local _, ns = ...

-- Prices for the gold ranking. Every value comes through the price broker (PriceSource.lua): AHSentinel first,
-- then auxForever, Auctionator, Auctioneer, TSM, otherwise own calculation by the rule book
-- (raidmaster shared/wissen/wirtschaft-forever.md).
--   Value to calculate with: the cheapest offer of the last scan (rule book section 3), not the median.
--   Reagents:  the cheapest way – AH, vendor, or crafting from a known recipe (≤ 2 levels)
--   Product:   net sale (5 % cut and expected deposit loss off, at least the vendor value) × items per craft;
--              the value of a craft is the better of selling and disenchanting ("best way")
--   Disenchanting: AHSentinel's value (API), otherwise expected materials × their net value (stack sale)
-- ns.Items[id] = { name, quality, vendorSell, vendorBuyPerPiece (0 = no vendor), farmable }

local P = {}
ns.Prices = P

-- Auction house cut: 5 % of the sale price is kept by the auction house (neutral AH 15 %: PriceSource.CutPct)
P.AH_CUT = 0.05

-- WoW Forever (rule book section 1, measured 9 Nov.): 5 % of the sale price when sold; the deposit
-- (vendor price × quantity × 5 % per 2 h) comes back on a sale and is lost when the auction runs out – expected
-- cost deposit × (1 − p) / p. The old rule "max(5 %, 1s) per auction, never refunded" was wrong and is gone.
-- Other game versions (Era, TBC, Retail): 5 % cut on the sale, the deposit comes back (unchanged).
function P.FeeApplies()
    return ns.IsForever == true
end

function P.StackSize(itemID)
    -- old global first (exactly as before), C_Item.GetItemInfo in the modern client
    local ok, _, _, _, _, _, _, _, stack = pcall(ns.ItemInfo, itemID)
    if ok and type(stack) == "number" and stack > 0 then return stack end
    return 1
end

-- AH share of a sale of this total (copper): 5 % (neutral 15 %), rounded like AHSentinel. No minimum.
function P.AuctionFee(price)
    return ns.PriceSource.Cut(price)
end
P.OwnAuctionFee = P.AuctionFee

---------------------------------------------------------------------------
-- Pass memo (performance, diagnostic log 0.9.22: AD.Update 39 ms, UI:Refresh 101 ms in the game).
-- One update (AD.Update, UI:Refresh) evaluates a recipe up to three times (levelling, gold, disenchanting) and
-- asks AHSentinel for the same market values again and again. Inside one pass every AH value, recipe price and
-- bag count is computed once; the memo is thrown away when the pass ends (nothing goes stale).
---------------------------------------------------------------------------
local pass
-- Kept recipe prices (Nachbau with the real AHSentinel, Ingametest 0.9.66 point 2): one recipe price allocates about 11 KB
-- (parts, market ladder, AHSentinel answers); every build computed every recipe again – 6 MB per pass, 21 MB for the Gold
-- view, the garbage collector cleaned up in long frames. A recipe price only changes with the prices (scan, booking, price
-- source), the test simulation or the data (AD.stamp): kept over passes while all of them are the same, at most
-- P.KEEP_SECONDS. The key is computed once per pass (no strings per recipe).
P.KEEP_SECONDS = 60
local keep = { rec = {} }
function P.ClearKeep() keep = { rec = {} } end

-- Gold safety (review 17 Nov. 21:45): every click that buys, crafts or sets a sniper price computes with the values of right
-- now: for the rest of THIS frame kept answers of AHSentinel and kept recipe prices are not read – they are asked/computed
-- again and the fresh values are kept for the frames after. The next frame (a timer of 0 s) ends the fresh mode. Without a
-- timer everything kept is dropped instead. (Dropping everything in the game made every later build compute all anew:
-- Nachbau echt T81 up to 501 ms.)
function ns.FreshPrices()
    P.freshCount = (P.freshCount or 0) + 1
    if pass then pass.rec = {}; pass.ah = {} end            -- an open pass forgets its memo as well
    local PS = ns.PriceSource
    if not (ns.API and ns.API.TimerAfter) then
        if PS and PS.ClearValues then PS.ClearValues() end
        P.ClearKeep()
        return
    end
    local token = {}
    P.fresh = token
    if PS then PS.fresh = token end
    ns.API.TimerAfter(0, function()
        if P.fresh == token then P.fresh = nil end
        if PS and PS.fresh == token then PS.fresh = nil end
    end)
end
function P.Fresh() return P.fresh ~= nil end
-- the action is computed: the panel built after it reads the kept values again (UI DoRefresh)
function ns.EndFreshPrices()
    P.fresh = nil
    if ns.PriceSource then ns.PriceSource.fresh = nil end
end
local function KeepKey()
    local S, PS, AD = ns.Sim, ns.PriceSource, ns.Advisor
    return tostring(S) .. "|" .. tostring(S and S.prices) .. "|" .. tostring(PS and PS.changes) .. "|"
        .. tostring(P.SourceName and P.SourceName()) .. "|" .. tostring(AD and AD.stamp) .. "|" .. tostring(ns.db and ns.db.deMargin)
end
function P.BeginPass()
    if pass then pass.depth = pass.depth + 1; return end
    pass = { depth = 1, ah = {}, rec = {}, cnt = {}, hits = 0 }
    local now = (GetTime and GetTime()) or 0
    local key = KeepKey()
    if keep.key ~= key or not keep.at or now - keep.at >= P.KEEP_SECONDS or now < keep.at then
        keep = { key = key, at = now, rec = {} }
    end
    pass.keep = keep
end
function P.EndPass()
    if not pass then return end
    pass.depth = pass.depth - 1
    if pass.depth <= 0 then P.lastPassHits = pass.hits; pass = nil end
end
function P.Pass() return pass end

-- runs fn inside a pass; the pass always ends, also on a Lua error (which is passed on)
function P.InPass(fn, ...)
    -- already inside a pass (the portioned rebuild begins one per portion): same memo, no extra pcall
    -- (a portioned rebuild may hand over to the next frame inside fn; Lua 5.1 cannot do that across a pcall)
    if pass then return fn(...) end
    -- inside a background job (ns.Jobs): fn may hand over to the next frame (ns.Jobs.Yield) – never inside a pcall (Lua 5.1:
    -- "attempt to yield across metamethod/C-call boundary", Ingametest 0.9.66 "Aufgabe t279") and never with a memo that
    -- lasts over several frames: without a pass of its own (a job that wants the memo gets one per portion: opts.pass)
    if ns.Jobs and ns.Jobs.Running and ns.Jobs.Running() then return fn(...) end
    -- inside a Takt job of this addon (test routine step): fn may hand over; the memo lives only during each portion
    -- (GoldSentinelTakt.Sliced: BeginPass before and EndPass after every piece, never across frames)
    local job, TK = nil, nil
    if ns.TaktJob then job, TK = ns.TaktJob() end
    local res
    if job and TK.Sliced then
        res = { TK.Sliced(fn, P.BeginPass, P.EndPass, ...) }
    else
        P.BeginPass()
        res = { pcall(fn, ...) }
        P.EndPass()
    end
    if not res[1] then error(res[2], 0) end
    return unpack(res, 2)
end

---------------------------------------------------------------------------
-- Auction house value (copper) and which addon delivered it
---------------------------------------------------------------------------
local AHRaw
function P.AH(itemID)
    if ns.Sim and ns.Sim.prices then
        local v = ns.Sim.prices[itemID]
        if v then return v, "Test" end
    end
    if pass and itemID then
        local c = pass.ah[itemID]
        if c then pass.hits = pass.hits + 1; return c[1], c[2], c[3], c[4] end
        local v, src, kind, age = AHRaw(itemID)
        pass.ah[itemID] = { v, src, kind, age }
        return v, src, kind, age
    end
    return AHRaw(itemID)
end

-- the value to calculate with (cheapest offer of the last scan) from the first source that knows the item;
-- 4th value: age of the price in seconds (if the source tells it – Market.lua PM3 "older than 6 hours")
AHRaw = function(itemID)
    local v, src, kind, age = ns.PriceSource.Price(itemID)
    if v then return v, src, kind, age end
    return nil
end

-- label of the price source ("AHSentinel", "auxForever", "Auctionator", "Auctioneer", "TSM"); nil = own only
function P.SourceName()
    if ns.Sim and ns.Sim.prices then return "Test" end
    return ns.PriceSource.SourceName()
end

-- Vendor price: first what AHSentinel really saw at a vendor (current, exact for WoW Forever), then the data pack
function P.VendorBuy(itemID)
    local A = ns.Foreign("AHAnalyzerPro")
    if A and A.GetVendorBuyPrice then
        -- through the guard of the price broker: a failing AHSentinel is paused after 10 errors in a row (PS-RUN-1)
        local v = ns.PriceSource.CallCounted("AHAnalyzerPro.GetVendorBuyPrice", "AHSentinel:GetVendorBuyPrice", A.GetVendorBuyPrice, A, itemID)
        if type(v) == "number" and v > 0 then return v end
    end
    local d = ns.Items[itemID]
    if d and d[4] and d[4] > 0 then return d[4] end
    return nil
end

-- Price to BUY a reagent in the AH: the value to calculate with (cheapest offer of the last scan, else the market
-- value). Returns copper, "current" (last scan) | "market".
P.DE_SAFE_COUNT, P.DE_SAFETY = 10, 0.10
function P.BuyAH(itemID)
    local v, _, kind = P.AH(itemID)
    if not v then return nil end
    return v, (kind == "scan") and "current" or "market"
end

function P.VendorSell(itemID)
    local d = ns.Items[itemID]
    local v = d and d[3]
    if not v or v == 0 then
        local ok, _, _, _, _, _, _, _, _, _, _, sell = pcall(ns.ItemInfo, itemID)
        if ok and type(sell) == "number" and sell > 0 then v = sell end
    end
    return v and v > 0 and v or nil
end

function P.IsFarmable(itemID)
    local d = ns.Items[itemID]
    return d and d[5] == 1 or false
end

---------------------------------------------------------------------------
-- Cost of one reagent over the cheapest way: (copper per piece, origin "vendor" | "ah" | "farm" | "craft", known,
-- priceSrc "current"/"market", via = { itemIDs it is made of } for "craft")
---------------------------------------------------------------------------
function P.ReagentUnit(itemID)
    local unit, way, known, kind, via, recipe = ns.PriceSource.MaterialUnit(itemID)
    local farm = P.IsFarmable(itemID)
    if not unit then return 0, farm and "farm" or "ah", false end
    local origin = way
    if way == "ah" and farm then origin = "farm" end
    local priceSrc
    if way == "ah" then priceSrc = (kind == "scan" or kind == "current") and "current" or "market" end
    return unit, origin, known, priceSrc, via, recipe
end

-- what to buy for n pieces of a reagent: a reagent made cheaper by yourself ("craft") is broken down into the
-- materials of its recipe (like AHSentinel Cr:ExpandNeed) – the shopping lists buy linen cloth, not the bolt.
-- Returns a list of { id, count, origin, unit, known }
function P.ExpandNeed(itemID, n, out, depth)
    out, depth = out or {}, depth or 0
    local unit, origin, known, _, _, recipe = P.ReagentUnit(itemID)
    if origin == "craft" and recipe and depth < 3 then
        local made = ((recipe.outMin or 1) + (recipe.outMax or recipe.outMin or 1)) / 2
        local crafts = math.ceil(n / math.max(made, 1) - 1e-9)
        for i = 1, #(recipe.reagents or {}), 2 do
            P.ExpandNeed(recipe.reagents[i], crafts * (recipe.reagents[i + 1] or 1), out, depth + 1)
        end
        return out
    end
    for _, e in ipairs(out) do
        if e.id == itemID then e.count = e.count + n; return out end
    end
    out[#out + 1] = { id = itemID, count = n, origin = origin, unit = unit, known = known }
    return out
end

-- Full calculation for a recipe. Returns a table:
--   cost, value, net (per craft, copper), known (all prices found), parts = { {id, count, unit, origin, known} },
--   origins = { vendor = true, ah = true, farm = true }, valueSource "ah" | "vendor" | nil
local RecipeRaw
function P.Recipe(r, withDE)
    if pass and r then
        local k = withDE and 2 or 1
        local c = pass.rec[r]
        if c and c[k] then pass.hits = pass.hits + 1; return c[k] end
        local kc = pass.keep and pass.keep.rec[r]
        local res = kc and not P.Fresh() and kc[k]
        if res then
            P.keepHits = (P.keepHits or 0) + 1
        else
            -- Ingametest 0.9.72 (HOCH 1): own share in the memory meter of the panel (the price queries inside count apart)
            local mem = ns.UI and ns.UI.Mem
            if mem then mem.Begin("Rezeptpreis rechnen") end
            res = RecipeRaw(r, withDE)
            if mem then mem.End() end
            if pass.keep then
                kc = kc or {}
                kc[k] = res
                pass.keep.rec[r] = kc
            end
        end
        pass.rec[r] = c or {}
        pass.rec[r][k] = res
        return res
    end
    return RecipeRaw(r, withDE)
end

RecipeRaw = function(r, withDE)
    local PS, MK = ns.PriceSource, ns.Market
    local res = { cost = 0, value = 0, known = true, parts = {}, origins = {} }
    -- market knowledge (Market.lua PM2/PM4): the calculation is for the crafts the market takes (1 … 20, cooldown 1);
    -- with AHSentinel the reagent cost comes from its MaterialCost for exactly this product, otherwise every AH
    -- reagent over the price ladder for the needed quantity (not the cheapest single piece)
    -- (the levelling calculation without disenchanting – AD.Plan, AD.Ranking – stays at one craft and leaves the
    -- market judgement out: it only needs the reagent cost, and it runs for every skill point)
    local crafts = MK and r.out and withDE and MK.Crafts(r) or 1
    res.crafts = crafts
    local _, apiParts
    if MK and r.out and withDE then _, apiParts = MK.ApiMaterialCost(r, crafts) end
    res.apiCost = apiParts and true or nil
    for i = 1, #(r.reagents or {}), 2 do
        local id, n = r.reagents[i], r.reagents[i + 1]
        local unit, origin, known, priceSrc, via = P.ReagentUnit(id)
        local ap = apiParts and apiParts[id]
        local ladder, short
        if ap and ap.qty > 0 then
            unit, known = ap.cost / ap.qty, true
            origin = (ap.source == "vendor" and "vendor") or (ap.source == "craft" and "craft")
                or (P.IsFarmable(id) and "farm" or "ah")
        elseif MK and known and (origin == "ah" or origin == "farm") and MK.Ladder(id) then
            local need = n * crafts
            local total, info = MK.BuyCost(id, need)
            if total and info and info.ladder then
                unit, ladder, short = total / need, true, info.short or nil
                local vb = P.VendorBuy(id)
                if vb and vb < unit then unit, origin, ladder, short = vb, "vendor", nil, nil end
            end
        end
        res.parts[#res.parts + 1] = { id = id, count = n, unit = unit, origin = origin, known = known,
            priceSrc = priceSrc, via = via, ladder = ladder, short = short }
        res.origins[origin] = true
        res.cost = res.cost + unit * n
        if not known then res.known = false end
    end
    if r.out then
        local count = ((r.outMin or 1) + (r.outMax or r.outMin or 1)) / 2
        -- selling: net per piece (5 % cut and expected deposit loss already off, at least the vendor value) –
        -- NetSale is net: no second fee here
        local net1, info = PS.NetSale(r.out, 1)
        local vs = P.VendorSell(r.out)
        res.valueVendor = vs and vs * count or nil
        -- a real AH price only (AHSentinel gives the vendor value as "gross" when it has no AH price)
        if info and (info.gross or 0) > 0 and not (info.vendorWins and (info.cut or 0) == 0) then
            res.valueAH = info.gross * count
            res.ahCut = (info.cut or 0) * count
            res.depositRisk = (info.depositRisk or 0) > 0 and info.depositRisk * count or nil
            res.valueAHNet = res.valueAH - res.ahCut - (res.depositRisk or 0)
            res.priceKind = info.kind
        end
        if net1 then
            res.value = net1 * count
            res.valueSource = (info and info.vendorWins) and "vendor" or "ah"
        end
        -- one number with AHSentinel (PM4): its "Lohnt bis" (per piece, best exit after fees, holding risk and
        -- safety margin) as soon as AHSentinel.API.WorthUpTo exists
        -- (asked for ONE piece: the price per piece – answer F2 – is then the same whatever qty means)
        local worthFn = MK and MK.UsesAPI() and MK.OptApi("WorthUpTo")
        if worthFn then
            -- API.md 34: 1 amount, 2 way, 3 "sicher"/"unsicher", 4 measured safety 0–1 (nil = still learning), 5 price per piece.
            -- PS58-1: the chance is the 4th value; the 3rd is the fallback of older AHSentinel versions (only 3 values).
            local ret = { n = 0 }
            local function Keep(...) ret = { n = select("#", ...), ... } end
            Keep(PS.Call("AHSentinel.API.WorthUpTo", worthFn, r.out, 1))
            local w, way, text, conf = ret[1], ret[2], ret[3], ret[4]
            if type(w) == "number" and w > 0 then
                res.value = w * count
                res.valueSource = (way == "vendor") and "vendor" or "ah"
                local hasConf = ret.n >= 4
                local safety = hasConf and conf or text
                res.worthUpTo, res.worthWay, res.worthSafety = true, way, safety
                res.worthUnsure = (MK.WorthUnsure(text) or (type(conf) == "number" and MK.WorthUnsure(conf))) or nil
                -- B2: expected profit = profit × sale chance; with the 4th value nil = AHSentinel still learns this way
                if hasConf then
                    res.sellChance = type(conf) == "number" and MK.SellChance(conf) or nil
                    res.learning = (conf == nil) or nil
                else
                    res.sellChance = MK.SellChance(text)
                    res.learning = nil
                end
            end
        end
        res.ahFee = nil
        -- Disenchanting
        local DE = ns.Disenchant
        -- disenchanting only for enchanters who make gold (review 0.9.33, point 3); Retail: never (DE.WantsGold)
        local deOK = DE and withDE and DE.WantsGold and DE.WantsGold()
        if deOK then
            local g, n, own, src = PS.DisenchantValue(r.out)
            if g then
                -- AHSentinel's value: exactly its numbers
                res.deGross, res.deValue = g * count, n * count
                res.deCut = (g - n) * count
                res.deOwn, res.deSource, res.deComplete = own, "AHSentinel", true
                if DE.Value then
                    local _, _, yield = DE.Value(r.out)
                    res.deYield = yield
                end
            else
                local gross, complete, yield, ownN, shared, dsrc = DE.Value(r.out)
                if not gross and not PS.HasAHS() then
                    local enx = PS.EnchantrixValue(r.out)
                    if enx then gross, complete, dsrc = enx, true, "Enchantrix" end
                end
                if gross then
                    res.deGross = gross * count
                    -- the materials are sold in stacks: their net value (cut and deposit risk off)
                    if type(yield) == "table" and #yield > 0 then
                        local cut = 0
                        for _, y in ipairs(yield) do
                            local price = P.AH(y[1])
                            local netp = PS.NetPiece(y[1])
                            if price and netp then cut = cut + (y[2] or 0) * (y[3] or 0) * math.max(0, price - netp) end
                        end
                        res.deCut = cut * count
                    else
                        res.deCut = PS.Cut(res.deGross)
                    end
                    res.deValue = res.deGross - res.deCut
                    res.deComplete, res.deYield, res.deOwn, res.deShared, res.deSource = complete, yield, ownN, shared, dsrc
                    -- safety margin: under 10 real disenchants of the group the value is an estimate (own value only)
                    if dsrc ~= "Test" and (ownN or 0) + (shared or 0) < P.DE_SAFE_COUNT then
                        res.deSafety = res.deValue * P.DE_SAFETY
                        res.deValue = res.deValue - res.deSafety
                        res.deEstimated = true
                    end
                end
            end
        end
    end
    -- net = selling the product (AH or vendor); deNet = disenchanting it and selling the materials
    res.net = res.value - res.cost
    if res.deValue then res.deNet = res.deValue - res.cost end
    -- best way to use the product: AHSentinel's verdict, otherwise the better of the two
    local way, wayNet
    local DEm = ns.Disenchant
    if not res.worthUpTo and withDE and r.out and DEm and DEm.WantsGold and DEm.WantsGold() then way, wayNet = PS.BestWay(r.out) end
    if res.worthUpTo then
        -- AHSentinel's "Lohnt bis" already is the best exit
        res.bestNet = res.net
        res.bestVia = (res.worthWay == "disenchant") and "de" or res.valueSource
    elseif way then
        local count = ((r.outMin or 1) + (r.outMax or r.outMin or 1)) / 2
        res.bestNet = wayNet * count - res.cost
        res.bestVia = (way == "disenchant") and "de" or (res.valueSource or "ah")
    elseif res.deNet and (res.value <= 0 or res.deNet > res.net) then
        res.bestNet, res.bestVia = res.deNet, "de"
    else
        res.bestNet, res.bestVia = res.net, res.valueSource
    end
    -- both directions, no fake profits, hit rate (Market.lua PM1/PM3/PM6) – one place for tooltip, details and ranking
    if MK and r.out and withDE then MK.Judge(res, r) end
    return res
end

---------------------------------------------------------------------------
-- Money text: "+10s 80c", "−2s", "1g 5s"
---------------------------------------------------------------------------
function P.Money(copper, signed)
    if not copper then return "?" end
    local neg = copper < 0
    copper = math.floor(math.abs(copper) + 0.5)
    local g, s, c = math.floor(copper / 10000), math.floor((copper % 10000) / 100), copper % 100
    local parts = {}
    if g > 0 then parts[#parts + 1] = "|cffffd100" .. g .. "g|r" end
    if s > 0 then parts[#parts + 1] = "|cffc7c7cf" .. s .. "s|r" end
    if c > 0 or #parts == 0 then parts[#parts + 1] = "|cffc87533" .. c .. "c|r" end
    local txt = table.concat(parts, " ")
    if signed then txt = (neg and "−" or "+") .. txt elseif neg then txt = "−" .. txt end
    return txt
end

-- Plain version without colour codes (for compact hints)
function P.MoneyPlain(copper, signed)
    if not copper then return "?" end
    local neg = copper < 0
    copper = math.floor(math.abs(copper) + 0.5)
    local g, s, c = math.floor(copper / 10000), math.floor((copper % 10000) / 100), copper % 100
    local parts = {}
    if g > 0 then parts[#parts + 1] = g .. "g" end
    if s > 0 then parts[#parts + 1] = s .. "s" end
    if c > 0 or #parts == 0 then parts[#parts + 1] = c .. "c" end
    local txt = table.concat(parts, " ")
    if signed then txt = (neg and "−" or "+") .. txt elseif neg then txt = "−" .. txt end
    return txt
end

P.ORIGIN_COLOR = { ah = "d9a400", vendor = "9a9aa8", farm = "3aa83a", craft = "3fc7eb" }
