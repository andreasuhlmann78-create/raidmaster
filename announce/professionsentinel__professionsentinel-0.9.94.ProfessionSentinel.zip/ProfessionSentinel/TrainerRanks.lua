local ADDON, ns = ...

-- Ranks of profession trainers (Befund 21.11. 20:45: "Snarl" was shown as expert trainer – in the game he offers only
-- journeyman). The rank of a trainer is NEVER taken from the title (in WoW Forever the titles do not match). Sources, best first:
--   1. measured in the game: the ranks the trainer window offered (ns.db.trainerSeen[npcID], when opened),
--   2. the reference pages per profession (Data_TrainerRef.lua, goldgoblin "<beruf>-forever"),
--   3. otherwise "rank unknown" (0) – never guessed.
-- A trainer that teaches several ranks is listed under each of them. Only WoW Forever (other versions: no reference yet,
-- their data stay as they are – see the report 0.9.75).
local TR = {}
ns.TrainerRanks = TR

TR.WORDS = {
    { 4, { "fachmann", "artisan" } },
    { 3, { "experte", "expert" } },
    { 2, { "geselle", "journeyman" } },
    { 1, { "lehrling", "apprentice" } },
}

-- the rank of a trainer service by its name and sub text (nil: not a profession rank)
function TR.RankOfService(name, sub)
    local t = ((name or "") .. " " .. (sub or "")):lower()
    for _, w in ipairs(TR.WORDS) do
        for _, word in ipairs(w[2]) do
            if t:find(word, 1, true) then return w[1] end
        end
    end
    return nil
end

-- ranks of a trainer: list of keys (sorted) and the source ("gemessen" | "referenz" | nil = unknown)
function TR.RanksOf(prof, id)
    local seen = ns.db and ns.db.trainerSeen and ns.db.trainerSeen[id]
    if seen and seen.r and next(seen.r) then
        local l = {}
        for k in pairs(seen.r) do l[#l + 1] = k end
        table.sort(l)
        return l, "gemessen"
    end
    local ref = ns.TrainerRef and ns.TrainerRef[prof]
    local n = ns.NPCs and ns.NPCs[id]
    local mm = ref and n and ref[n[1]]
    if mm then
        local l = {}
        for k = mm[1], mm[2] do l[#l + 1] = k end
        return l, "referenz"
    end
    return nil
end

-- ns.Trainers rebuilt from the raw list: {id, rank} per rank taught, {id, 0} when unknown
function TR.Rebuild()
    if not ns.TrainerRef or not ns.Trainers then return false end
    TR.raw = TR.raw or ns.Trainers
    local out = {}
    for prof, list in pairs(TR.raw) do
        local l, seenId = {}, {}
        for _, e in ipairs(list) do
            local id = e[1]
            if not seenId[id] then
                seenId[id] = true
                local ranks = TR.RanksOf(prof, id)
                if ranks then
                    for _, k in ipairs(ranks) do l[#l + 1] = { id, k } end
                else
                    l[#l + 1] = { id, 0 }
                end
            end
        end
        out[prof] = l
    end
    ns.Trainers = out
    return true
end

-- the trainer window: note which profession ranks this trainer offers (also "already known" ones)
function TR.OnTrainerShow()
    if not (ns.db and TR.raw) then return end
    local A = ns.API
    if not (A.UnitGUID and A.GetNumTrainerServices and A.GetTrainerServiceInfo) then return end
    local guid = A.UnitGUID("npc")
    local id = guid and tonumber(guid:match("^%a+%-%d+%-%d+%-%d+%-%d+%-(%d+)%-"))
    if not id then return end
    local known = false
    for _, list in pairs(TR.raw) do
        for _, e in ipairs(list) do if e[1] == id then known = true end end
    end
    if not known then return end
    local found = {}
    for i = 1, (A.GetNumTrainerServices() or 0) do
        local name, sub = A.GetTrainerServiceInfo(i)
        local k = TR.RankOfService(name, sub)
        if k then found[k] = true end
    end
    if not next(found) then return end
    ns.db.trainerSeen = ns.db.trainerSeen or {}
    local e = ns.db.trainerSeen[id] or { r = {} }
    -- several visits: what one visit showed stays (a filter of the window may hide a rank)
    for k in pairs(found) do e.r[k] = true end
    e.t = time and time() or 0
    ns.db.trainerSeen[id] = e
    TR.Rebuild()
    if ns.Diag then ns.Diag("LEHRER", "gemessen " .. id) end
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("TRAINER_SHOW")
f:SetScript("OnEvent", function(_, ev)
    if ev == "PLAYER_LOGIN" then TR.Rebuild() else TR.OnTrainerShow() end
end)
