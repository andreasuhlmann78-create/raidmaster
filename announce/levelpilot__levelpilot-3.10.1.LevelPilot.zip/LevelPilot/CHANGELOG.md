# LevelPilot changelog

## 3.10.1
From GoldSentinel's reference "real game world" (Horde, WoW Forever).
- Alliance ships (Rut'theran–Auberdine, Auberdine–Menethil, Menethil–Theramore) are no longer planned for the Horde
  – they go through Alliance harbours.
- Zeppelins and ships take realistic time: average waiting time (half a cycle) + ride + loading screen (zeppelin
  about 6.5 min, ship about 6 min); the virtual journey now counts that time instead of a flat 2.4 minutes.
- Flights take time by distance (about 32 yards/s, flight routes 30 % longer than the straight line, plus take-off
  and landing) instead of a flat 2 minutes.
- Towns of the other faction (elite guards or NPCs from level 45) are blocked areas for every level and appear in
  the report as "town of the other faction" instead of "mob 63/65". Other NPCs of that faction (e.g. the
  farmers of Hillsbrad, quest targets for the Horde) count with their own level.
- Safety: skipping a step during a journey never writes into the real character.

## 3.10.0
Learning from the real game, and a virtual journey closer to it.
- New module Calib.lua learns from your play (numbers only, stored account-wide, never during a journey):
  kills per minute of your class (time between monster XP messages, breaks over 2 minutes excluded; used from
  20 measurements on) and the WoW Forever quest XP factor (your real quest XP against the Classic values of the
  data package; median, used from 5 quests on). /lp diag and the journey report show both.
- One time model for planning and the virtual journey: a kill objective takes kills ÷ kills per minute plus search
  time (before: 150 s in planning, 420 s in the journey). Starting values per class (hunter 2.2, warrior 1.7 …).
  Monster XP while questing counts fully; ways inside a quest area count 60 % (shared with other quests there);
  the way to a quest giver is shared among all quests taken there.
- Grinding only as a short gap and at a good spot: the step leads to the nearest place with monsters of your
  level (from the danger map), about 20 minutes, then replanning. The journey walks there.
- Virtual journey: rested XP and the real hearthstone cooldown are taken over ("journey from here"); rested XP
  doubles monster XP until used up.
- Sandbox check: a fingerprint of your real data (quests, waypoints, path sections, flight points, vendors,
  caves, ignored and turned-in quests, backup) before and after every journey; any difference is an error in the
  report and the error log. Journeys are logged as "REISE", not as play sessions.
- Report: comparison with your real level times (per level and average deviation, goal below 15 %).
- Speedrun default is now "medium" (a saved "strict" from the old default is switched once; choosing "strict"
  again keeps it).

## 3.9.1
From the in-game test report of 3.9.0.
- Fixed (data loss): all recorded flight points could be lost. "Journey from here" did its heavy setup inside the
  chat command; when the game aborted it ("script ran too long") halfway through, Stop set the flight point list
  to nothing, and the next backup copied the empty list. Now: the real data is remembered first, restoring never
  sets anything to nil, an overlay left behind is recognised and unwrapped, and the heavy setup runs inside the
  journey in small slices.
- Fixed (data safety): the character backup is now its own copy (not the same tables as the account), and before
  every backup update missing entries are restored from the old backup (only adds, never deletes).
- Fixed: the virtual journey wrote quest progress positions into the real quest database (qdb[7734]).
- Right-click on a step opens a menu (postpone 30 min / ignore quest / cancel) instead of ignoring at once;
  /lp zurück brings back the last ignored quest.
- Text windows (report, log, self-test) no longer keep the keyboard: Enter ends input, so the next chat command
  works with the first Enter (/lp reise bericht seemed to do nothing).
- Danger map: NPCs of the other faction count only as a group (guards), without the elite bonus – single quest
  givers and battleground NPCs (e.g. "mob 63" at the Alterac pass, "mob 62" at the Rebel Camp) no longer count.
- Watch mode draws the trail of the last steps (thicker, accent colour); the journey report places dangerous
  spots in the zone that contains them (no more y > 100).
- Lua errors inside the journey also go to the error log (up to 5 per journey).
- Finer slices in planning and the danger map against "script ran too long".
- Compact guide shows one distance; the current step shows the path length everywhere (no more 725 vs 755).
- /lp lang without a code shows the current language and only displayable languages; /lp weg confirms the
  waypoint; "Nearest – inn: …" wording.
- Chinese/Korean: the en dash "–" is replaced (no boxes); shorter labels for Portuguese ("Troca") and Russian
  ("Авто"); switching languages back and forth stays clean.

## 3.9.0
From the in-game test report of 3.8.1.
- New mandatory rule: the route never leads to targets where mobs are 3 or more levels above you (elite counts
  2 levels higher). New module Danger.lua builds a danger map from the data package (highest hostile mob level
  per 100-yard cell; dungeon elites at entrances and rare mobs excluded). Quests are accepted and done only when
  their mobs are doable; target spots, quest givers, turn-ins and flight masters in dangerous areas are skipped.
  Paths through such areas cost 25× in the path search (detour if one is known); the real path to the first
  target is checked and the target deferred if it leads through danger. Applies to normal play, speedrun and the
  virtual journey (with the journey's level). The journey report has a new section "Mobs ≥ +3".
- Step order: the chain is shortened with 2-opt and or-opt (accept before complete before turn-in, quest log
  never overflows) – e.g. Ratchet steps now come after the targets around the Crossroads. Accepts and turn-ins
  no longer get a strong distance bonus.
- Fewer zone hops: passing through a zone or landing after a flight no longer moves the focus there; single
  turn-ins count less when choosing a zone; a continent change at most every 3 levels; donation and war effort
  quests ("A Donation of Wool", "The Horde Needs …") are no longer planned.
- Speedrun: grind rate 1.5 kills per minute (was 2.2, too optimistic) so more quests pay off; hearthstone bind
  from 3 tasks in a zone.
- Flight points are always placed at their flight master's zone (no "Kalimdor" as a zone after flights).
- "script ran too long": the path search hands control back to the game every 5 expansions during the journey.
- Control center opens faster (zone overview reuses the last plan instead of recalculating everything).
- Watch mode: shows the path just walked on the world map and pauses 2 s after each finished step.
- Journey report: long straight lines show the start of the section in its own zone's coordinates.
- Safe mode is now stricter than the mandatory rule: avoids elites and mobs from your level + 1.

## 3.8.1
Found with GoldSentinel's real saved data (LevelPilot.lua from the WTF folder).
- Fixed: flights. The game stores flight points on the flight map (e.g. map 1464), which can't always be
  converted to world positions – then LevelPilot never planned a flight (0 flights in the in-game test).
  LevelPilot now calibrates the flight map itself: zone names in the flight point names plus the flight
  masters from the data package give shift and scale; each flight point gets its flight master's position.
  All 19 recorded Horde flight points in Kalimdor are located (within 40 yards). The flight point you stand
  at when opening the flight map is stored as an exact reference.
- Self-test: new check "Flights" (how many flight points are located and known).
- Error log: entries from 3.4–3.6 were stored in the language set at that time. Solved zone messages are
  removed, the others are converted and shown in the current language. "Not getting closer" is no longer
  reported while you hunt within 400 yards of a quest target.

## 3.8.0
Fixes from the in-game test report of 3.7.0. Route and path changes apply to normal play, not only to the
virtual journey.
- Route: quests in the other faction's home zones that are open to everyone (e.g. Westfall for the Horde),
  PvP quests and battleground quests (Alterac Valley, Warsong Gulch, Arathi Basin) are no longer planned.
- Route: fewer zone and continent hops. Below level 12 you stay on your own continent; a zone on another
  continent only becomes the focus with at least 5 tasks and clearly more value than anything left here.
- Speedrun: the way to a quest giver now only affects the order, not whether a quest is skipped – before,
  standing in a capital far from quest givers could leave you grinding for hours (L28–50 in Thunder Bluff).
- WoW Forever is the default: quest log 40, dungeon monster XP about 30 %, dungeon quest XP about ×2
  (setting "WoW Forever server" under Settings » Server & dungeons).
- Zone check: "Das Brachland" and "Brachland" count as the same zone (no more ZONE entries).
- Virtual journey: planning is spread over several frames ("script ran too long" is gone), Stop ends it at
  once, it uses flight paths and its own hearthstone cooldown, quest levels are coloured by the journey's
  level, "Journey from here" takes over your real quest log, the window shows the result after the end.
- Data safety: logging out or /reload during a virtual journey restores your real flight paths and
  character data first, so nothing virtual is ever saved.
- Error log: entries are stored as keys and shown in the current language, sorted newest first; the
  self-test shows log entries as a hint instead of OK. Obsolete "language pack MISSING" entries are removed.
- Display: settings hint no longer overlaps "Support the addon"; objective names instead of "?"; the time
  estimate includes the remaining path.

## 3.7.0
- New: self-test (/lp test or control center » Data » Self-test) checks all functions in the game – modules,
  data package, language and names, position and zone, planning, path to the current step, display, map,
  nameplates, target button, comfort, sharing, error log – and shows a report to copy.
- New: virtual journey 1–60 (/lp reise, or "Journey from here" with /lp reise hier). An imaginary character
  runs LevelPilot's whole route with the game's real map and path data: accepts, completes and turns in
  quests, earns XP by Classic rules, flies and uses the hearthstone. Your character does not move; nothing
  is recorded or shared. "Watch" shows every path on the world map, "Fast" computes straight through.
  The report lists missing paths, long straight lines per zone, stuck plans, levels and zones.
- Fixed: Searing Gorge had no zone transition – found by the virtual journey; it is now connected to the
  Burning Steppes through Blackrock Mountain.

## 3.6.0
- Fixed: translated quest, NPC, item, object and zone names did not appear in the game, because WoW only
  detects new AddOn folders after a full restart. The names are now part of the data package itself
  (LevelPilot Data 1.6.0, Data/Names_*.lua) – a /reload is enough, and there are only two folders again.
- Languages your game can't display are released from memory at login.
- Target button: uses the enemy names of your game's language (before, non-English games got the
  English names and /targetexact found nothing).
- The separate folders LevelPilot_Data_deDE … from 3.5.x are no longer needed and can be deleted.

## 3.5.3
- Changed: the language selection only offers languages your game can display. LevelPilot measures it:
  a missing font draws every character as an identical box, so if all sample characters of a language
  are as wide as a surely missing character, that language is hidden. On European and Russian clients
  Korean and Chinese are hidden; on clients that have those fonts everything stays available.
- A saved language that can't be displayed falls back to "Automatic"; /lp lang refuses it with a reason.
- Fixed: language buttons keep their own script font (e.g. "Русский" no longer turned into boxes).

## 3.5.2
- Fixed: no more language mix. Vendor, innkeeper and flight master names, enemy names in the safe mode
  warning, the navigation arrow, nameplate texts and time units (h/min) now follow the chosen language.
  Hint pop-ups in the old language are closed when you switch.
- Fixed: buttons shrink their font instead of cutting off long words (e.g. Russian "Automatic").
- Fixed: the status bar measures its real text height, so long status lines are no longer cut off.
- Fixed: Russian font has no middle dot "·" – it is replaced, no more empty boxes.
- New: if a language pack can't be loaded, LevelPilot says why (most often: WoW must be fully restarted
  once after new AddOn folders were added – /reload is not enough). /lp diag shows the language packs.

## 3.5.1
- Packaging: one single download (LevelPilot.zip) now contains the addon, the data package and all
  language packs. Extract everything into Interface/AddOns.

## 3.5.0
- New: quest, NPC, item, object and zone names follow the language you choose in LevelPilot – no longer
  the language of your game client. Translations come from QuestieDB (GPLv3) as language packs in the
  data package (LevelPilot Data 1.5.0: LevelPilot_Data_deDE, _frFR, _esES, _esMX, _ptBR, _ruRU, _koKR,
  _zhCN, _zhTW). Only the packs that are needed are loaded. English uses the names of the data package;
  Italian has no Questie translation and shows English names.
- Quest objectives from the quest log are shown in the chosen language as well ("Name: 3/7").
- In your game's own language, the titles the game shows are kept; quests not yet in your log no longer
  appear in English.
- Target macros keep the names the game knows, so targeting still works in any language.

## 3.4.5
- Fixed: switching the language now updates every label in the guide window and the control center
  immediately – no /reload needed – and switching back restores everything. Words that share one
  translation (e.g. German "Austausch" and "Teilen" are both "Compartir" in Spanish) no longer come
  back wrong. Steps, hints and data source info are rebuilt in the new language as well.

## 3.4.4
- Changed: vendors now get every grey item – weapons, armour and junk. Items whose data the game had
  not loaded yet (often weapons from earlier sessions) used to stay in the bags; they are now sold too.
  Only items needed for a running quest or that start a quest are kept. The chat message shows the
  real amount earned.

## 3.4.3
- Fixed: the guide window header no longer cuts off text. The zone name has its own line across the
  full width, the "Normal / Skip / Replan" buttons moved to a separate row, and the XP line wraps
  instead of being hidden behind the buttons.
- Fixed: the status bar grows with its text and keeps clear of the resize grip.
- Fixed: the replan button showed an empty box (the ↻ glyph is missing in the game fonts) – it now uses
  an arrow icon. Arrows "→" in texts were replaced by "»" for the same reason.

## 3.4.2
- New: **Support** button in the guide window's title bar (a coin icon when the window is narrow), a
  "Support the addon" line in Settings and `/lp donate` (also `/lp spenden`, `/lp support`). It shows the
  PayPal link to copy – it never opens on its own and never posts anything in chat.

## 3.4.1
- New: error log for testers. LevelPilot quietly notes Lua errors, wrongly detected zones, unknown
  position, planning in the wrong zone, missing paths, being stuck, very long steps, deaths, slow
  planning and login/logout. `/lp protokoll` shows it as text to copy; it stays on your computer and
  contains no names or login data. Can be switched off under Extras.

## 3.4.0
- New control center tab "Extras": quest item locations with arrow and alert, quest tooltips, automatic
  restocking of food/water/ammo/pet food, auto-equip of reward upgrades, gold per hour, best level times,
  time estimates, rested/hearthstone status, "where was I?" on login, turn-in reminders, logout summary,
  corpse arrow, class quest and trainer cost hints, mount gold planning, quest sharing, group finder
  text, elite partner search, compact mode and per-character settings.
- Fixed: corpse arrow position, gold per hour counting.
