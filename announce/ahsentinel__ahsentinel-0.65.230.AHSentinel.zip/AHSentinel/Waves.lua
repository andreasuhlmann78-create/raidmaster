if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Waves.lua (Rechenkern 0.66, Regel R4 der Prüf-Sitzung 14.11.)
-- Wellen je Stufenband: Die Levelwelle wandert ca. 1 Band je 1–2 Tage nach oben; ein Band fällt beim Durchziehen stark,
-- danach seitwärts. Band-Index = Mittel über die Entzauber-Materialien des Bands von (Tagesmedian / Tagesmedian am
-- ersten Tag des Fensters). Zustand: 2 Tage nacheinander > 15 % gefallen = "welle" (nicht kaufen/halten, zügig
-- verkaufen); die letzten 3 Tage je ±10 % = "durch"; sonst "offen". Nur Messung aus dem Preisverlauf (bestätigte Preise),
-- nichts gespeichert, nichts angezeigt (Anzeige erst mit dem neuen Markt-Reiter).
-- ============================================================
local A = AHAnalyzerPro
if not (A and A.On) then return end
local W = {}
A.Waves = W

-- Bänder nach den Entzauber-Materialien (Staub, Essenz, Splitter) - Itemstufe wie die Entzauber-Tabelle
W.BANDS = {
    { key = "5-25",  mats = { 10940, 10938, 10939, 10998, 10978 } },
    { key = "26-35", mats = { 11083, 11082, 11134, 11084, 11138 } },
    { key = "36-45", mats = { 11137, 11135, 11174, 11139, 11177 } },
    { key = "46-55", mats = { 11176, 11175, 16202, 11178, 14343 } },
    { key = "56-60", mats = { 16204, 16203, 14344, 20725 } },
}
W.DAYS = 10
W.FALL, W.FLAT = 0.15, 0.10

-- Tagesmediane (bestätigte Preise) eines Items: { [Tag] = Median }
function W:DailyMedians(itemID, from, to)
    local F, n = A:HF(itemID)
    local byDay = {}
    for i = 1, n do
        local b = (i - 1) * 5
        local t, p = F[b + 1], F[b + 2]
        if t >= from and (not to or t < to) and F[b + 5] % 2 == 0 and p and p > 0 then
            local d = math.floor((t - from) / 86400) + 1
            local l = byDay[d] or {}
            l[#l + 1] = p
            byDay[d] = l
        end
    end
    local out = {}
    for d, l in pairs(byDay) do out[d] = A.Median(l) end
    return out
end

-- Index je Tag (1..DAYS) eines Bands; nil wo kein Material an diesem Tag einen Preis hat
function W:BandIndex(band, now)
    now = now or time()
    -- WV1 (Prüf-Sitzung 09:35): nur GANZE Tage - der angefangene heutige Tag (nur Morgenpreise, Tageszyklus +2–4 %)
    -- verfälschte den Index; die DAYS Tage enden gestern
    local to = A:DayStart(now)
    local from = to - self.DAYS * 86400
    local sums, cnts = {}, {}
    for _, id in ipairs(band.mats) do
        local m = self:DailyMedians(id, from, to)
        local base
        for d = 1, self.DAYS do if m[d] then base = m[d]; break end end
        if base and base > 0 then
            for d = 1, self.DAYS do
                if m[d] then sums[d], cnts[d] = (sums[d] or 0) + m[d] / base, (cnts[d] or 0) + 1 end
            end
        end
    end
    local idx = {}
    for d = 1, self.DAYS do if cnts[d] then idx[d] = sums[d] / cnts[d] end end
    return idx
end

-- Zustand aus einer Index-Reihe (Tage mit Wert, älteste zuerst)
function W:StateOf(idx)
    local vals = {}
    for d = 1, self.DAYS do if idx[d] then vals[#vals + 1] = idx[d] end end
    local n = #vals
    if n < 3 then return "offen", vals end
    local f1 = vals[n - 1] > 0 and (vals[n] / vals[n - 1] - 1) or 0
    local f2 = vals[n - 2] > 0 and (vals[n - 1] / vals[n - 2] - 1) or 0
    if f1 < -self.FALL and f2 < -self.FALL then return "welle", vals end
    if n >= 4 then
        local flat = true
        for k = n - 2, n do
            if vals[k - 1] <= 0 or math.abs(vals[k] / vals[k - 1] - 1) > self.FLAT then flat = false end
        end
        if flat then return "durch", vals end
    end
    return "offen", vals
end

function W:States(now)
    local out = {}
    for _, band in ipairs(self.BANDS) do
        local ok, idx = pcall(self.BandIndex, self, band, now)
        local st, vals = "offen", {}
        if ok then st, vals = self:StateOf(idx) end
        out[#out + 1] = { key = band.key, state = st, days = #vals, last = vals[#vals] }
    end
    return out
end
-- Ist ein Item gerade in einem Band "in der Welle"? (für spätere Anzeige "nicht kaufen/halten")
function W:InWave(itemID, now)
    for _, band in ipairs(self.BANDS) do
        for _, id in ipairs(band.mats) do
            if id == itemID then
                local ok, idx = pcall(self.BandIndex, self, band, now)
                return ok and self:StateOf(idx) == "welle", band.key
            end
        end
    end
    return false
end

-- ------------------------------------------------------------
-- MA4 (anweisung-markt-reiter Teil C; Antwort Supervisor 21:02 F3): Stufenbänder nach BENÖTIGTER Stufe des Items
-- (1–25, 26–45, 46–60). Index je ganzem Tag (10 Tage, wie WV1) = Median über die Items des Bands von (Tagesmedian /
-- Tagesmedian am ersten Tag des Fensters, bestätigte Preise). BELEGT = mindestens 5 Tage mit je mindestens 20 Items.
-- Richtung nur aus einem belegten Band: Spitze = 3 Tage > +15 % (F1); fällt = 3 Tage < −5 % und letzter Tag < 0;
-- steigt = 3 Tage > +5 % (nur Hinweis); sonst ruhig. ANNAHME (fällt/steigt ±5 %, Supervisor 21:33 G2 einverstanden).
-- Nur Messung: wirkt (noch) nicht auf "Lohnt bis" (RK6 folgt). Rechnung im Hintergrund, einmal je Tag (A:Job, Portionen).
-- ------------------------------------------------------------
W.LBANDS = { { key = "1-25", lo = 1, hi = 25 }, { key = "26-45", lo = 26, hi = 45 }, { key = "46-60", lo = 46, hi = 60 } }
W.MA4_MIN_ITEMS, W.MA4_MIN_DAYS = 20, 5
W.MA4_FALL, W.MA4_RISE, W.MA4_SPIKE = 0.05, 0.05, 0.15

-- benötigte Stufe (nur aus dem Item-Cache des Spiels; nil = unbekannt oder ohne Stufe)
function W:ReqLevel(itemID)
    local GII = A:Global("GetItemInfo") or GetItemInfo
    if not GII then return nil end
    local ok, name, _, _, _, req = pcall(GII, itemID)
    if not (ok and name) then return nil end
    req = tonumber(req) or 0
    return req > 0 and req or nil
end
function W:LevelBandOf(req)
    if not req then return nil end
    for i, b in ipairs(self.LBANDS) do if req >= b.lo and req <= b.hi then return i, b end end
    return nil
end

-- Richtung einer Index-Reihe (Werte ältester zuerst)
function W:Direction(vals)
    local n = #vals
    if n < 4 then return "ruhig", nil, nil end
    local d1 = vals[n - 1] > 0 and (vals[n] / vals[n - 1] - 1) or 0
    local d3 = vals[n - 3] > 0 and (vals[n] / vals[n - 3] - 1) or 0
    if d3 > self.MA4_SPIKE then return "spitze", d1, d3 end
    if d3 < -self.MA4_FALL and d1 < 0 then return "faellt", d1, d3 end
    if d3 > self.MA4_RISE then return "steigt", d1, d3 end
    return "ruhig", d1, d3
end

-- Rechnung (in Portionen über A:Pause). items = Liste { {id, req}, ... } (Test) oder aus den Marktdaten.
function W:ComputeLevelBands(now, items)
    now = now or time()
    local to = A:DayStart(now)
    local from = to - self.DAYS * 86400
    if not items then
        items = {}
        for id in pairs((A.db and A.db.marketData) or {}) do
            A:Pause()
            local req = self:ReqLevel(id)
            if req then items[#items + 1] = { id, req } end
        end
    end
    local per = {}                                             -- [Band][Tag] = Liste der Verhältnisse
    local nItems = {}
    for _, it in ipairs(items) do
        A:Pause()
        local bi = self:LevelBandOf(it[2])
        if bi then
            local m = self:DailyMedians(it[1], from, to)
            local base
            for d = 1, self.DAYS do if m[d] then base = m[d]; break end end
            if base and base > 0 then
                nItems[bi] = (nItems[bi] or 0) + 1
                per[bi] = per[bi] or {}
                for d = 1, self.DAYS do
                    if m[d] then
                        local l = per[bi][d] or {}
                        l[#l + 1] = m[d] / base
                        per[bi][d] = l
                    end
                end
            end
        end
    end
    local out = {}
    for bi, b in ipairs(self.LBANDS) do
        local vals, days = {}, 0
        for d = 1, self.DAYS do
            local l = per[bi] and per[bi][d]
            if l and #l >= self.MA4_MIN_ITEMS then
                vals[#vals + 1] = A.Median(l)
                days = days + 1
            end
        end
        local belegt = days >= self.MA4_MIN_DAYS
        local dir, d1, d3
        if belegt then dir, d1, d3 = self:Direction(vals) end
        out[bi] = { key = b.key, items = nItems[bi] or 0, days = days, belegt = belegt, dir = dir, d1 = d1, d3 = d3, vals = vals }
    end
    return out
end

-- Stand der Bänder (einmal je Tag im Hintergrund neu); ohne Stand nil
function W:LevelBands(now)
    now = now or time()
    local day = A:DayStart(now)
    local c = self.ma4
    if c and c.day == day then return c.bands end
    if A.Job and A.HasJob and not A:HasJob("ma4") then
        A:Job("ma4", function()
            local bands = W:ComputeLevelBands(now)
            W.ma4 = { day = day, bands = bands }
        end)
    end
    return c and c.bands or nil
end

-- G1 (Antwort Supervisor 21:33): Entzauber-Materialien ohne Stufe bekommen das Band ihrer Herkunft aus W.BANDS
-- (5-25 -> 1–25; 26-35 und 36-45 -> 26–45; 46-55 und 56-60 -> 46–60). Handwerkswaren ohne Stufe: kein Band.
W.MAT_BAND = { ["5-25"] = 1, ["26-35"] = 2, ["36-45"] = 2, ["46-55"] = 3, ["56-60"] = 3 }
function W:MatBand(itemID)
    for _, band in ipairs(self.BANDS) do
        for _, id in ipairs(band.mats) do
            if id == itemID then local bi = self.MAT_BAND[band.key]; return bi, bi and self.LBANDS[bi] end
        end
    end
    return nil
end
-- Band eines Items: benötigte Stufe, sonst Material-Herkunft (G1); nil = kein Band
function W:ItemBand(itemID)
    local bi, b = self:LevelBandOf(self:ReqLevel(itemID))
    if bi then return bi, b end
    return self:MatBand(itemID)
end
-- Richtung des Bands eines Items: "faellt"/"steigt"/"spitze"/"ruhig" (nur belegte Bänder), sonst nil; 2. Wert Bandschlüssel
function W:ItemTrend(itemID, now)
    local bi, b = self:ItemBand(itemID)
    if not bi then return nil end
    local bands = self:LevelBands(now)
    local x = bands and bands[bi]
    if not (x and x.belegt) then return nil, b.key end
    return x.dir, b.key
end
