# LevelPilot – Änderungen (Deutsch)

Ältere Versionen stehen in CHANGELOG.md (Englisch).

## 3.12.6
Offene Punkte der Prüfung vom 3. November 2026 (Nachprüfung 3.12.5).
- Dropraten auf WoW Forever genauer: Der Kill zählt jetzt schon bei der Monster-EP-Meldung (totes Ziel), auch wenn
  die Leiche keine Beute hat – die Rate fällt dadurch nicht mehr zu hoch aus. Stückzahlen zählen erst, wenn der
  Gegenstand wirklich in der Tasche ankommt (Beute-Meldung); bleibt etwas bei voller Tasche liegen, zählt es erst
  beim späteren Aufheben. Jede Leiche zählt nur einmal, geschützte Werte werden nie benutzt.
- Berufs- und Klassenhinweise: Antwortet die erste Zauber-Abfrage mit „nicht bekannt“, fragt LevelPilot auch die
  übrigen (IsPlayerSpell) – kein falscher Hinweis zu Erste Hilfe/Kochen mehr.
- Belohnungs-Hinweis: Ist die Gegenstandsinfo beim Öffnen der Belohnung noch nicht geladen, prüft LevelPilot nach
  einer Sekunde noch einmal.
- Beschädigte gespeicherte Einträge (falscher Typ) werden beim Laden übersprungen oder ersetzt statt Lua-Fehler zu
  verursachen; gültige gesammelte Daten bleiben unverändert.
- Geschützte Werte: EP-Anzeige, Zeit bis 60, Gruppenstand und Erholt-Hinweis rechnen nie mit geschützten EP;
  Tooltips, Messung und Gegner-Zeilen prüfen geschützte Einheiten.
- Fehler, die bisher still abgefangen wurden (virtuelle Reise, Sicherung beim Ausloggen, Protokoll-Prüfungen), werden
  jetzt an die GoldSentinel-Prüfung gemeldet. Die Diagnose zeigt Modul-Startfehler.
- Planungszeit der virtuellen Reise zählt nur noch die Rechenzeit (Pausen zwischen den Bildern nicht mehr).
- Testroutine (Testmodus): alle Testfälle automatisiert (vorher 96 Platzhalter), Zählung „nicht automatisiert“ im
  Bericht, neue Client-Fälle T171, T195 und T213 (Berufszauber), lange Reisen mit /lp testroutine reise.
  Im Kopierfenster der Hinweis „Wird auch automatisch gemeldet.“ (alle Sprachen).

## 3.12.5
Grundeinstellung nach Entscheid des Nutzers, offene Punkte der Prüfung vom 3. November 2026 und neue Testroutine.
- Grundeinstellung: Automatisch reparieren und Auto-Flug sind ab Werk wieder an; Vorräte nachkaufen und
  Questbelohnung anlegen bleiben aus. Bestehende Einstellungen ändern sich nicht – wer 3.12.4 neu installiert hat,
  schaltet Reparieren und Auto-Flug in der Zentrale ein (Komfort).
- Neue einmalige Hinweise: beim ersten Händler, bei dem LevelPilot nachkaufen würde (Nachkaufen aus), und bei der
  ersten Questbelohnung, die ein Upgrade ist (Anlegen aus), zeigt LevelPilot einmal, dass es die Option gibt – mit
  „Einstellungen“ und „Später erinnern“ (frühestens 3 Level später). Es wird nichts gekauft, gewählt oder angelegt;
  nie im Kampf, nie mehr, sobald die Option an ist. Auch die Begrüssung „Wo war ich?“ zeigt einmal einen Tipp.
- Dropraten auf WoW Forever: Wird dieselbe Leiche erneut geöffnet (Tasche voll, Fenster geschlossen), zählen Kill und
  Stückzahl nicht doppelt; ein Beutefenster mit geschütztem Link wird ausgelassen statt einen Kill ohne Beute zu
  zählen; Taschendiebstahl (Ziel lebt noch) zählt nicht als Kill.
- Klassenhinweise: Antwortet keine Zauber-Funktion, behauptet LevelPilot nicht mehr, Erste Hilfe/Kochen fehle.
- Erkennung: Meldet GoldSentinelGame „nicht modern“, folgt LevelPilot dem (eigene Erkennung nur ohne GoldSentinelGame).
- Alle Zeitgeber laufen geschützt über LP:Ticker (Neuplanung, Assistent, Partnersuche, Datenaustausch, Reise).
- Fehlende Übersetzung des Protokolleintrags „Datenpaket veraltet“ ergänzt (alle Sprachen).
- Robustheit: Fehlende Spielfunktionen (Reparaturkosten, Haltbarkeit, Munition, Questgeber-Begrüssung,
  Gegenstandsinfo) führen nicht mehr zu Lua-Fehlern.
- Aktionen mit echten Folgen (Kaufen, Verkaufen, Reparieren, Anlegen, Quests, Flug, Senden, Einladen, Neuladen)
  laufen über eine Stelle (LP.Act); im normalen Spiel ändert sich nichts.
- Neue Testroutine für den Entwickler (Testmodus): /lp testroutine [a–j] und Knopf „Alles testen“; Sandbox für
  deine Daten, Aktionen werden nur mitgeschrieben. /lp test (für alle) schreibt jetzt einen maschinenlesbaren
  Bericht. Berichte und Lua-Fehler werden für die GoldSentinel-Prüfung gespeichert (GoldSentinelTest.lua, ohne Namen).
