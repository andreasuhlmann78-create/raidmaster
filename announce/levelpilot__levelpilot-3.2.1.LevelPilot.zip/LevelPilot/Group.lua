-- LevelPilot - Gruppenmodus
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- In einer Gruppe teilen LevelPilot-Spieler ihren Fortschritt: Level, EP, aktueller Schritt und
-- Quests im Log. Angezeigt wird das unter dem Guide-Fenster (gleich / voraus / zurueck), und der
-- Planer bevorzugt Quests, die auch Mitspieler haben, damit man sie gemeinsam erledigt.
-- Eigener Nachrichtenkanal, unabhaengig vom Datenaustausch.

local _, LP = ...
local L = LP.L
local G = {}
LP:RegisterModule("Group", G)

local PREFIX = "LvPilotG"
local SEP = "\t"
local SEND_EVERY = 30         -- Sekunden: regelmaessig senden (zusaetzlich bei Aenderungen)
local EXPIRE = 120            -- Sekunden ohne Nachricht: Mitspieler gilt als nicht mehr da
G.members = {}                -- [Name] = { level, pct, t, id, text, quests = {[id]=true}, seen }

local function Short(name) return name and (name:match("^([^%-]+)") or name) or "?" end

local function InGroup() return IsInGroup and IsInGroup() or false end

local function Channel()
    if IsInRaid and IsInRaid() then return "RAID" end
    return "PARTY"
end

local function Send(msg)
    if not InGroup() or not LP.db.groupSync then return end
    if C_ChatInfo and C_ChatInfo.SendAddonMessage then
        C_ChatInfo.SendAddonMessage(PREFIX, msg, Channel())
    elseif SendAddonMessage then
        SendAddonMessage(PREFIX, msg, Channel())
    end
end

-- eigenen Stand senden: S = Schritt, L = Quests im Log (in Teilen, Nachrichten sind auf 255 Zeichen begrenzt)
function G:Broadcast()
    if not InGroup() or not LP.db.groupSync then return end
    local step = LP.Engine:Current()
    local level, xp, max = UnitLevel("player") or 1, UnitXP("player") or 0, UnitXPMax("player") or 1
    local text = step and (LP.UI:StepText(step, false):match("^[^\n]*") or "") or ""
    text = text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("[\t|]", ""):sub(1, 90)
    Send(table.concat({ "S", level, math.floor(xp / math.max(1, max) * 100), step and step.t or "", step and step.id or 0, text }, SEP))
    local ids = {}
    for id in pairs(LP.Planner.inLog) do ids[#ids + 1] = id end
    table.sort(ids)
    local chunk = {}
    local function flush(last)
        Send(table.concat({ "L", last and "1" or "0", table.concat(chunk, ",") }, SEP))
        chunk = {}
    end
    for _, id in ipairs(ids) do
        chunk[#chunk + 1] = id
        if #chunk >= 30 then flush(false) end
    end
    flush(true)
end

function G:OnMessage(msg, sender)
    local name = Short(sender)
    if name == UnitName("player") then return end
    local parts = {}
    for p in (msg .. SEP):gmatch("(.-)" .. SEP) do parts[#parts + 1] = p end
    local m = self.members[name] or { quests = {}, pending = {} }
    self.members[name] = m
    m.seen = GetTime()
    if parts[1] == "S" then
        m.level = tonumber(parts[2]) or m.level
        m.pct = tonumber(parts[3]) or 0
        m.t = parts[4] ~= "" and parts[4] or nil
        m.id = tonumber(parts[5])
        if m.id == 0 then m.id = nil end
        m.text = (parts[6] or ""):sub(1, 90)
    elseif parts[1] == "L" then
        for id in (parts[3] or ""):gmatch("%d+") do m.pending[tonumber(id)] = true end
        if parts[2] == "1" then m.quests, m.pending = m.pending, {} end
    elseif parts[1] == "R" then
        LP:Throttle("group_send", 2, function() G:Broadcast() end)
        return
    end
    LP:Fire("GROUP_CHANGED")
    LP:Throttle("group_plan", 3, function() LP.Planner:Replan() end)
end

-- aktive Mitspieler (mit LevelPilot)
function G:Active()
    local list = {}
    if not InGroup() or not LP.db.groupSync then return list end
    local now = GetTime()
    for name, m in pairs(self.members) do
        if now - (m.seen or 0) <= EXPIRE then list[#list + 1] = { name = name, m = m } end
    end
    table.sort(list, function(a, b) return a.name < b.name end)
    return list
end

-- [questID] = Anzahl Mitspieler, die die Quest im Log haben
function G:SharedQuests()
    local list = self:Active()
    if #list == 0 then return nil end
    local out = {}
    for _, e in ipairs(list) do
        for id in pairs(e.m.quests or {}) do out[id] = (out[id] or 0) + 1 end
    end
    return out
end

-- Vergleich mit dem eigenen Stand
function G:Status(m)
    local my = LP.Engine:Current()
    if my and m.id and my.id == m.id then return "gleich" end
    local myLevel, myPct = UnitLevel("player") or 1, math.floor((UnitXP("player") or 0) / math.max(1, UnitXPMax("player") or 1) * 100)
    local a, b = (m.level or 0) * 100 + (m.pct or 0), myLevel * 100 + myPct
    if a > b + 15 then return "voraus" end
    if a < b - 15 then return "zurück" end
    return "gleich"
end

------------------------------------------------------------------------
-- Anzeige unter dem Guide-Fenster
------------------------------------------------------------------------
local panel, lines = nil, {}
local COLORS = { gleich = "|cff4ddb80", voraus = "|cffffb238", ["zurück"] = "|cff7fc8ff" }

function G:Refresh()
    if not panel then return end
    local list = self:Active()
    if #list == 0 or not LP.UI:IsShown() or LP.char.collapsed then panel:Hide() return end
    local w = LevelPilotFrame and LevelPilotFrame:GetWidth() or 300
    panel:SetWidth(w)
    for i, e in ipairs(list) do
        local fs = lines[i]
        if not fs then
            fs = LP.UI:Text(panel, 10, LP.colors.text)
            fs:SetPoint("TOPLEFT", 8, -6 - (i - 1) * 14)
            fs:SetWordWrap(false)
            lines[i] = fs
        end
        fs:SetWidth(w - 16)
        local st = self:Status(e.m)
        fs:SetText(string.format("%s%s|r  L%d %d%%  ·  %s  |cff9c9ea6(%s)|r", COLORS[st] or "", e.name, e.m.level or 0,
            e.m.pct or 0, e.m.text ~= "" and e.m.text or "–", L[st]))
        fs:Show()
    end
    for i = #list + 1, #lines do lines[i]:Hide() end
    panel:SetHeight(10 + #list * 14)
    panel:Show()
end

function G:Init()
    if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then C_ChatInfo.RegisterAddonMessagePrefix(PREFIX) end
    if LevelPilotFrame then
        panel = CreateFrame("Frame", "LevelPilotGroupPanel", LevelPilotFrame, BackdropTemplateMixin and "BackdropTemplate" or nil)
        panel:SetPoint("TOPLEFT", LevelPilotFrame, "BOTTOMLEFT", 0, -2)
        panel:SetHeight(24)
        LP.UI:Skin(panel, LP.colors.panel, LP.colors.border)
        panel:Hide()
    end
    LP:On("CHAT_MSG_ADDON", function(_, prefix, msg, _, sender)
        if prefix == PREFIX and msg and sender then G:OnMessage(msg, sender) end
    end)
    LP:On("GROUP_ROSTER_UPDATE", function()
        if not InGroup() then wipe(G.members) end
        Send("R")
        LP:Throttle("group_send", 2, function() G:Broadcast() end)
        LP:Fire("GROUP_CHANGED")
    end)
    LP:Listen("PLAN_CHANGED", function() LP:Throttle("group_send", 3, function() G:Broadcast() end) end)
    LP:Listen("GROUP_CHANGED", function() G:Refresh() end)
    LP:Listen("PLAN_CHANGED", function() G:Refresh() end)
    C_Timer.NewTicker(SEND_EVERY, function() G:Broadcast() G:Refresh() end)
end
