-- LevelPilot - Questdatenbank
-- Quellen in dieser Rangfolge (die erste, die etwas weiss, gewinnt):
--   1) Eigene Beobachtungen dieses Spielers (LP.db.qdb ohne net)
--   2) Mitgelieferte Startdatenbank (LP.Seed, eigene gesammelte Daten)
--   3) Daten anderer LevelPilot-Spieler (LP.db.qdb mit net)
--   4) Datenpaket "LevelPilot Data" (optional, separat installiert)
--   5) QuestieDB (optional, nur wenn kein Datenpaket da ist)
-- Die Grunddaten (4/5) liefern Vorquests, Volk/Klasse und alle Orte; die eigenen
-- Daten (1-3) gehen bei Orten vor, weil sie WoW-Forever-Aenderungen kennen.
--
-- Einheitliches Quest-Objekt:
--   { id, name, level, reqLevel, races, classes, raceSys, starts = {pt...}, ends = {pt...},
--     objectives = { {idx, text, spots={pt...}} }, pre, preAny, exclusive, nextInChain,
--     parent, repeatable, itemStart, skill, minRep, source, dungeon }
--   dungeon = AreaID aus LP.Dungeons, wenn die Quest in einer Instanz erledigt wird
--   xp = Grund-EP, elite = Elite-/Gruppenquest, escort = Eskorte (fuer den Speedrun)
--   pt = { map, x, y, name }

local _, LP = ...
local L = LP.L
local QDB = {}
LP:RegisterModule("QuestDB", QDB)

local cache = {}
local MAX_SPOTS = 24

QDB.questie, QDB.questieInfo = false, ""
QDB.pack, QDB.packInfo = false, ""

local PACK          -- LevelPilotData
local areaToUiMap   -- QuestieDB: AreaID -> uiMapID
local Q, NPC, OBJ, ITEM

------------------------------------------------------------------------
-- Datenpaket "LevelPilot Data"
------------------------------------------------------------------------
local function ConnectPack()
    if not LP.db.usePack then return false, L["in den Einstellungen ausgeschaltet"] end
    local d = _G.LevelPilotData
    if type(d) ~= "table" or type(d.Q) ~= "table" then return false, L["nicht installiert"] end
    if d.format ~= 1 then return false, L["unbekanntes Format "] .. tostring(d.format) end
    PACK = d
    local n = 0
    for _ in pairs(d.Q) do n = n + 1 end
    return true, "v" .. tostring(d.version) .. ", " .. n .. L[" Quests"]
end

------------------------------------------------------------------------
-- QuestieDB (optional)
------------------------------------------------------------------------
local function ConnectQuestie()
    if not LP.db.useQuestie then return false, L["in den Einstellungen ausgeschaltet"] end
    local lib = _G.LibQuestieDB
    if type(lib) ~= "table" then return false, L["nicht installiert"] end
    if type(lib.RequireContract) == "function" then
        local ok, msg = lib.RequireContract(4)
        if not ok then
            ok, msg = lib.RequireContract(3)
            if not ok then return false, L["Version zu alt ("] .. tostring(msg) .. ")" end
        end
    end
    Q, NPC, OBJ, ITEM = lib.Quest, lib.Npc, lib.Object, lib.Item
    if not (Q and NPC and OBJ) then return false, L["Schnittstelle unvollständig"] end
    areaToUiMap = {}
    pcall(function()
        local zoneDB = lib.Support and lib.Support.Get and lib.Support.Get("ZoneDB")
        local src = zoneDB and zoneDB.private and zoneDB.private.areaIdToUiMapId
        if type(src) == "string" then
            local fn = loadstring(src)
            local t = fn and fn()
            if type(t) == "table" then areaToUiMap = t end
        elseif type(src) == "table" then
            areaToUiMap = src
        end
    end)
    if not next(areaToUiMap) then return false, L["Zonendaten fehlen"] end
    return true, L["verbunden (Vertrag "] .. tostring(lib.contractVersion or "?") .. ")"
end

function QDB:Init()
    LP.Seed = LP.Seed or { quests = {}, vendors = {}, taxi = {}, paths = {} }
    PACK = nil
    self.pack, self.packInfo = ConnectPack()
    self.questie, self.questieInfo = false, L["nicht benötigt (Datenpaket aktiv)"]
    if not self.pack then
        self.questie, self.questieInfo = ConnectQuestie()
    end
    self:BuildPlayerMasks()
end

function QDB:Reconnect()
    wipe(cache)
    self:InvalidateServices()
    self:Init()
    LP:Fire("QDB_CHANGED")
end

------------------------------------------------------------------------
-- Volk & Klasse
------------------------------------------------------------------------
local CLASS_BITS = { WARRIOR = 1, PALADIN = 2, HUNTER = 4, ROGUE = 8, PRIEST = 16,
                     SHAMAN = 64, MAGE = 128, WARLOCK = 256, DRUID = 1024 }
-- Classic-Volksbits (Datenpaket): Mensch, Orc, Zwerg, Nachtelf, Untoter, Taure, Gnom, Troll
local CLASSIC_RACE_BITS = { [1] = 1, [2] = 2, [3] = 4, [4] = 8, [5] = 16, [6] = 32, [7] = 64, [8] = 128 }
local FACTION_MASK = { Alliance = 1 + 4 + 8 + 64, Horde = 2 + 16 + 32 + 128 }

function QDB:BuildPlayerMasks()
    local _, classFile = UnitClass("player")
    local _, _, raceID = UnitRace("player")
    self.classBit = CLASS_BITS[classFile]
    self.packRaceBit = raceID and CLASSIC_RACE_BITS[raceID]   -- nil fuer Skyborne
    self.questieRaceBit = nil
    local lib = _G.LibQuestieDB
    if self.questie and lib and lib.Enum then
        if lib.Enum.classKeys and lib.Enum.classKeys[classFile] then self.classBit = lib.Enum.classKeys[classFile] end
        if lib.Enum.raceMaskById and raceID then self.questieRaceBit = lib.Enum.raceMaskById[raceID] end
    end
end

-- Deckt eine Classic-Maske alle Voelker der Fraktion ab? (Skyborne gibt es in Classic-Daten nicht)
local function CoversFaction(mask)
    local fm = FACTION_MASK[LP:PlayerFaction()]
    for _, b in ipairs({ 1, 2, 4, 8, 16, 32, 64, 128 }) do
        if LP.HasBit(fm, b) and not LP.HasBit(mask, b) then return false end
    end
    return true
end

function QDB:RaceOk(races, sys)
    if not races or races == 0 then return true end
    if sys == "pack" then
        if self.packRaceBit then return LP.HasBit(races, self.packRaceBit) end
        return CoversFaction(races)
    elseif sys == "questie" then
        if self.questieRaceBit then return LP.HasBit(races, self.questieRaceBit) end
        return true
    end
    return true
end

function QDB:FitsPlayer(q)
    if not self:RaceOk(q.races, q.raceSys) then return false end
    if q.classes and q.classes ~= 0 and self.classBit and not LP.HasBit(q.classes, self.classBit) then return false end
    if q.faction and q.faction ~= "B" then
        local f = LP:PlayerFaction() == "Horde" and "H" or "A"
        if q.faction ~= f then return false end
    end
    return true
end

------------------------------------------------------------------------
-- Datenpaket lesen
------------------------------------------------------------------------
local function PackSpawns(s, name, out, limit)
    if type(s) ~= "table" then return end
    for _, z in ipairs(s) do
        local map = z[1]
        local count = (#z - 1) / 2
        local step = math.max(1, math.floor(count / limit))
        for i = 1, count, step do
            out[#out + 1] = { map, z[i * 2], z[i * 2 + 1], name }
            if #out >= limit * 3 then return end
        end
    end
end

local function FactionCode() return LP:PlayerFaction() == "Horde" and "H" or "A" end

-- Gegnerische Hauptstaedte (und Teldrassil) sind fuer die andere Fraktion praktisch unerreichbar
local ENEMY_MAPS = {
    Alliance = { [1454] = true, [1456] = true, [1458] = true },            -- Orgrimmar, Donnerfels, Unterstadt
    Horde    = { [1453] = true, [1455] = true, [1457] = true, [1438] = true }, -- Sturmwind, Eisenschmiede, Darnassus, Teldrassil
}
local function DropEnemyPoints(list)
    local enemy = ENEMY_MAPS[LP:PlayerFaction()]
    for i = #list, 1, -1 do
        if enemy[list[i][1]] then table.remove(list, i) end
    end
end

local function PackNpc(id, out, limit, friendlyOnly)
    local n = PACK.N[id]
    if not n then return end
    -- Questgeber der anderen Fraktion sind feindlich: nicht verwenden
    if friendlyOnly and n.f and n.f ~= "" and not n.f:find(FactionCode()) then return end
    PackSpawns(n.s, n.n, out, limit or 6)
end

local function PackObj(id, out, limit)
    local o = PACK.O[id]
    if o then PackSpawns(o.s, o.n, out, limit or 6) end
end

local function PackRaw(id)
    local q = PACK.Q[id]
    if not q then return nil end
    local fix = PACK.F and PACK.F[LP:PlayerFaction()]
    fix = fix and fix.q and fix.q[id]
    if not fix then return q end
    local m = {}
    for k, v in pairs(q) do m[k] = v end
    for k, v in pairs(fix) do
        if v == false then m[k] = nil else m[k] = v end
    end
    return m
end

local function FromPack(id)
    local r = PackRaw(id)
    if not r or not r.n then return nil end
    local q = {
        id = id, name = r.n, source = "pack", raceSys = "pack",
        level = r.l or 0, reqLevel = r.rl or 0, races = r.r or 0, classes = r.c or 0,
        pre = r.pg, preAny = r.ps, exclusive = r.ex, nextInChain = r.nx, parent = r.pa,
        specialFlags = r.sf or 0, skill = r.sk, minRep = r.rp, descr = r.d,
        starts = {}, ends = {}, objectives = {},
    }
    q.repeatable = LP.HasBit(q.specialFlags, 1)
    q.dungeon = r.z and LP.DungeonByArea[r.z]
    q.xp = r.x
    q.sourceItem = r.su
    q.reqItems = r.rs
    q.escort = r.es == 1 or r.tg == 84
    q.elite = r.tg == 1 or r.tg == 62 or r.tg == 41
    for _, n in ipairs(r.sn or {}) do PackNpc(n, q.starts, 4, true) end
    for _, o in ipairs(r.so or {}) do PackObj(o, q.starts, 4) end
    if r.si and #q.starts == 0 then q.itemStart = true end
    for _, n in ipairs(r.en or {}) do PackNpc(n, q.ends, 4, true) end
    for _, o in ipairs(r.eo or {}) do PackObj(o, q.ends, 4) end
    DropEnemyPoints(q.starts)
    DropEnemyPoints(q.ends)
    local ob = r.ob or {}
    local function Elite(id) local nn = PACK.N[id] return nn and nn.rk and nn.rk ~= 4 or false end
    local function Lvl(id) local nn = PACK.N[id] return nn and nn.lo end
    local function Name(id) local nn = PACK.N[id] return nn and nn.n end
    for _, o in ipairs(ob.k or {}) do
        local spots = {}
        PackNpc(o[1], spots, MAX_SPOTS)
        q.objectives[#q.objectives + 1] = { text = o[2], spots = spots, kind = "kill", elite = Elite(o[1]),
                                            mobLevel = Lvl(o[1]), mobs = { Name(o[1]) } }
    end
    for _, o in ipairs(ob.o or {}) do
        local spots = {}
        PackObj(o[1], spots, MAX_SPOTS)
        q.objectives[#q.objectives + 1] = { text = o[2], spots = spots, kind = "object" }
    end
    for _, o in ipairs(ob.i or {}) do
        local spots = {}
        local it = PACK.I[o[1]]
        local allElite = it and it.dn and #it.dn > 0 and not it.dob
        local easiest, mobs
        for _, nid in ipairs(it and it.dn or {}) do
            local lv = Lvl(nid)
            if lv and (not easiest or lv < easiest) then easiest = lv end
            mobs = mobs or {}
            if #mobs < 4 and Name(nid) then mobs[#mobs + 1] = Name(nid) end
        end
        if it then
            for i = 1, math.min(#(it.dn or {}), 6) do PackNpc(it.dn[i], spots, 4) end
            for i = 1, math.min(#(it.dob or {}), 6) do PackObj(it.dob[i], spots, 4) end
            for _, nid in ipairs(it.dn or {}) do if not Elite(nid) then allElite = false end end
        end
        q.objectives[#q.objectives + 1] = { text = o[2] or (it and it.n), spots = spots, kind = "item", elite = allElite or false,
                                            mobLevel = easiest, mobs = mobs, item = o[1] }
    end
    for _, o in ipairs(ob.c or {}) do
        local spots, mobs = {}, {}
        for _, n in ipairs(o[1] or {}) do
            PackNpc(n, spots, 6)
            if #mobs < 4 and Name(n) then mobs[#mobs + 1] = Name(n) end
        end
        q.objectives[#q.objectives + 1] = { text = o[2], spots = spots, kind = "kill", mobs = mobs }
    end
    for _, o in ipairs(q.objectives) do
        if o.elite then q.elite = true end
        if o.mobLevel and (not q.mobLevel or o.mobLevel > q.mobLevel) then q.mobLevel = o.mobLevel end
    end
    if ob.e then
        local spots = {}
        PackSpawns(ob.e[2], nil, spots, 4)
        q.objectives[#q.objectives + 1] = { text = ob.e[1], spots = spots, kind = "explore" }
    end
    return q
end

------------------------------------------------------------------------
-- QuestieDB lesen
------------------------------------------------------------------------
local function SpawnsToPoints(spawns, name, out, limit)
    if type(spawns) ~= "table" then return end
    for areaId, list in pairs(spawns) do
        local map = areaToUiMap[areaId]
        if map and type(list) == "table" then
            local step = math.max(1, math.floor(#list / limit))
            for i = 1, #list, step do
                local c = list[i]
                if type(c) == "table" and c[1] and c[1] >= 0 then
                    out[#out + 1] = { map, c[1], c[2], name }
                    if #out >= limit * 3 then return end
                end
            end
        end
    end
end

local function QNpc(id, out, limit, friendlyOnly)
    if friendlyOnly then
        local okF, fr = pcall(NPC.friendlyToFaction, id)
        local fac = LP:PlayerFaction() == "Horde" and "H" or "A"
        if okF and type(fr) == "string" and fr ~= "" and not fr:find(fac) then return end
    end
    local ok, spawns = pcall(NPC.spawns, id)
    local ok2, name = pcall(NPC.name, id)
    if ok then SpawnsToPoints(spawns, ok2 and name or nil, out, limit or 6) end
end

local function QObj(id, out, limit)
    local ok, spawns = pcall(OBJ.spawns, id)
    local ok2, name = pcall(OBJ.name, id)
    if ok then SpawnsToPoints(spawns, ok2 and name or nil, out, limit or 6) end
end

local function Field(id, key)
    local ok, v = pcall(Q.Get, id, key)
    if ok then return v end
    return nil
end

local function FromQuestie(id)
    if not Q then return nil end
    local name = Field(id, "name")
    if not name then return nil end
    local q = {
        id = id, name = name, source = "questie", raceSys = "questie",
        level = Field(id, "questLevel") or 0, reqLevel = Field(id, "requiredLevel") or 0,
        races = Field(id, "requiredRaces") or 0, classes = Field(id, "requiredClasses") or 0,
        pre = Field(id, "preQuestGroup"), preAny = Field(id, "preQuestSingle"),
        exclusive = Field(id, "exclusiveTo"), nextInChain = Field(id, "nextQuestInChain"),
        parent = Field(id, "parentQuest"), specialFlags = Field(id, "specialFlags") or 0,
        skill = Field(id, "requiredSkill"), minRep = Field(id, "requiredMinRep"),
        starts = {}, ends = {}, objectives = {},
    }
    q.repeatable = LP.HasBit(q.specialFlags, 1)
    local zs = Field(id, "zoneOrSort")
    if type(zs) == "number" and zs > 0 then q.dungeon = LP.DungeonByArea[zs] end
    local okX, xpv = pcall(function() return _G.LibQuestieDB.XP and _G.LibQuestieDB.XP.Get and _G.LibQuestieDB.XP.Get(id) end)
    if okX and type(xpv) == "number" then q.xp = xpv end
    local sb = Field(id, "startedBy") or {}
    for _, n in ipairs(sb[1] or {}) do QNpc(n, q.starts, 4, true) end
    for _, o in ipairs(sb[2] or {}) do QObj(o, q.starts, 4) end
    if sb[3] and #sb[3] > 0 and #q.starts == 0 then q.itemStart = true end
    local fb = Field(id, "finishedBy") or {}
    for _, n in ipairs(fb[1] or {}) do QNpc(n, q.ends, 4, true) end
    for _, o in ipairs(fb[2] or {}) do QObj(o, q.ends, 4) end
    DropEnemyPoints(q.starts)
    DropEnemyPoints(q.ends)
    local obj = Field(id, "objectives") or {}
    for _, o in ipairs(obj[1] or {}) do
        local spots = {} QNpc(o[1], spots, MAX_SPOTS)
        q.objectives[#q.objectives + 1] = { text = o[2], spots = spots, kind = "kill" }
    end
    for _, o in ipairs(obj[2] or {}) do
        local spots = {} QObj(o[1], spots, MAX_SPOTS)
        q.objectives[#q.objectives + 1] = { text = o[2], spots = spots, kind = "object" }
    end
    for _, o in ipairs(obj[3] or {}) do
        local spots = {}
        if ITEM then
            local okN, npcs = pcall(ITEM.npcDrops, o[1])
            if okN and type(npcs) == "table" then for i = 1, math.min(#npcs, 6) do QNpc(npcs[i], spots, 4) end end
            local okO, objs = pcall(ITEM.objectDrops, o[1])
            if okO and type(objs) == "table" then for i = 1, math.min(#objs, 6) do QObj(objs[i], spots, 4) end end
        end
        q.objectives[#q.objectives + 1] = { text = o[2], spots = spots, kind = "item" }
    end
    for _, o in ipairs(obj[5] or {}) do
        local spots = {}
        for _, n in ipairs(o[1] or {}) do QNpc(n, spots, 6) end
        q.objectives[#q.objectives + 1] = { text = o[3], spots = spots, kind = "kill" }
    end
    local trig = Field(id, "triggerEnd")
    if type(trig) == "table" and type(trig[2]) == "table" then
        local spots = {}
        for areaId, list in pairs(trig[2]) do
            local map = areaToUiMap[areaId]
            if map then for _, c in ipairs(list) do spots[#spots + 1] = { map, c[1], c[2] } end end
        end
        q.objectives[#q.objectives + 1] = { text = trig[1], spots = spots, kind = "explore" }
    end
    return q
end

------------------------------------------------------------------------
-- Eigene Daten: Beobachtung > Startdatenbank > andere Spieler
------------------------------------------------------------------------
local function RecordLayers(id)
    local own, net = nil, nil
    local r = LP.db.qdb[id]
    if r then if r.net then net = r else own = r end end
    local seed = LP.Seed.quests[id]
    return { own, seed, net }
end

-- Ebenen koennen leer sein (nil), daher feste Laenge 3 statt ipairs
local function Pick(layers, key)
    for i = 1, 3 do
        local l = layers[i]
        if l and l[key] ~= nil then return l[key] end
    end
    return nil
end

local function FromRecorded(id)
    local layers = RecordLayers(id)
    local name = Pick(layers, "n")
    if not name then return nil end
    local src = layers[1] and "own" or (layers[2] and "seed" or "net")
    local level = Pick(layers, "l")
    local q = {
        id = id, name = name, source = src, recorded = true,
        level = level or 0, reqLevel = Pick(layers, "rl") or math.max(1, (level or 1) - 4),
        faction = Pick(layers, "f"), itemStart = Pick(layers, "item"), dungeon = Pick(layers, "dg"),
        xpReal = Pick(layers, "x"), xpRealLvl = Pick(layers, "xl"),
        starts = {}, ends = {}, objectives = {},
    }
    local s, e = Pick(layers, "s"), Pick(layers, "e")
    if s then q.starts[1] = { s[1], s[2], s[3], s[4] } end
    if e then q.ends[1] = { e[1], e[2], e[3], e[4] } end
    -- Zielorte: jedes Ziel aus der besten Ebene, die es kennt
    local objIdx = {}
    for i = 1, 3 do
        local l = layers[i]
        if l and l.o then
            for idx, list in pairs(l.o) do
                if not objIdx[idx] then
                    local spots = {}
                    for _, h in ipairs(list) do spots[#spots + 1] = { h[1], h[2], h[3] } end
                    objIdx[idx] = true
                    q.objectives[#q.objectives + 1] = { idx = idx, spots = spots, kind = "rec" }
                end
            end
        end
    end
    return q
end

-- Grunddaten + eigene Daten: eigene Orte zuerst, Grunddaten ergaenzen
local function Merge(base, rec)
    if not rec then return base end
    if not base then return rec end
    if rec.name and base.name ~= rec.name then base.localName = rec.name end
    if (not base.level or base.level == 0) and rec.level then base.level = rec.level end
    if not base.dungeon and rec.dungeon then base.dungeon = rec.dungeon end
    if rec.xpReal then base.xpReal, base.xpRealLvl = rec.xpReal, rec.xpRealLvl end
    if #rec.starts > 0 then table.insert(base.starts, 1, rec.starts[1]) end
    if #rec.ends > 0 then table.insert(base.ends, 1, rec.ends[1]) end
    if #rec.objectives > 0 then
        local merged, have = {}, {}
        for _, o in ipairs(rec.objectives) do merged[#merged + 1] = o have[o.idx] = true end
        for i, o in ipairs(base.objectives) do
            o.idx = o.idx or i
            if not have[o.idx] then merged[#merged + 1] = o end
        end
        base.objectives = merged
    end
    base.recorded = true
    return base
end

------------------------------------------------------------------------
-- Oeffentliche Abfragen
------------------------------------------------------------------------
function QDB:Get(id)
    if not id then return nil end
    local q = cache[id]
    if q ~= nil then return q or nil end
    local base
    if PACK then
        local ok, res = pcall(FromPack, id)
        if ok then base = res end
    elseif self.questie then
        local ok, res = pcall(FromQuestie, id)
        if ok then base = res end
    end
    q = Merge(base, FromRecorded(id))
    -- nur selbst/gemeinsam aufgezeichnet, nicht in den Classic-Daten: neu auf WoW Forever
    if q and not base and PACK then q.isNew = true end
    cache[id] = q or false
    return q
end

function QDB:Invalidate(id)
    if id then cache[id] = nil else wipe(cache) end
end

function QDB:AllIds()
    local ids, seen = {}, {}
    local function add(id) if not seen[id] then seen[id] = true ids[#ids + 1] = id end end
    if PACK then
        for id in pairs(PACK.Q) do add(id) end
    elseif self.questie then
        local ok, list = pcall(Q.GetAllIds)
        if ok and type(list) == "table" then for _, id in ipairs(list) do add(id) end end
    end
    for id in pairs(LP.Seed.quests) do add(id) end
    for id in pairs(LP.db.qdb) do add(id) end
    return ids
end

-- Vorauswahl nach Level, Volk, Klasse
function QDB:QuickInfo(id)
    if PACK then
        local r = PackRaw(id)
        if r then
            return { level = r.l or 0, reqLevel = r.rl or 0, races = r.r or 0, classes = r.c or 0,
                     specialFlags = r.sf or 0, raceSys = "pack", dungeon = r.z and LP.DungeonByArea[r.z] }
        end
    elseif self.questie then
        local ok, name = pcall(Q.Get, id, "name")
        if ok and name then
            local zs = Field(id, "zoneOrSort")
            return { level = Field(id, "questLevel") or 0, reqLevel = Field(id, "requiredLevel") or 0,
                     races = Field(id, "requiredRaces") or 0, classes = Field(id, "requiredClasses") or 0,
                     specialFlags = Field(id, "specialFlags") or 0, raceSys = "questie",
                     dungeon = type(zs) == "number" and zs > 0 and LP.DungeonByArea[zs] or nil }
        end
    end
    local layers = RecordLayers(id)
    local level = Pick(layers, "l")
    if level or Pick(layers, "n") then
        return { level = level or 0, reqLevel = Pick(layers, "rl") or math.max(1, (level or 1) - 4), faction = Pick(layers, "f"),
                 dungeon = Pick(layers, "dg") }
    end
    return nil
end

------------------------------------------------------------------------
-- Dungeons
------------------------------------------------------------------------
-- Name eines Dungeons in der eingestellten Sprache: Deutsch aus den eigenen Daten; spricht man die
-- Sprache des Clients, liefert das Spiel den offiziellen Namen; sonst der englische Name
function LP:DungeonName(area)
    local d = area and LP.Dungeons[area]
    if not d then return nil end
    local lang = LP:Language()
    if lang == "de" then return d.name end
    if lang == LP:ClientLanguage() and C_Map and C_Map.GetAreaInfo then
        local ok, n = pcall(C_Map.GetAreaInfo, area)
        if ok and type(n) == "string" and n ~= "" then return n end
    end
    return d.en or d.name
end

-- Angaben zu einem Dungeon; Eingaenge aus dem Datenpaket gehen vor
function QDB:Dungeon(area)
    local d = area and LP.Dungeons[area]
    if not d then return nil end
    local pd = PACK and PACK.D and PACK.D[area]
    local e = (pd and pd.e and #pd.e > 0) and pd.e or d.e
    local name = LP:DungeonName(area)
    return { area = area, name = name, min = d.min, max = d.max, inst = d.inst, run = d.run,
             only = d.only, land = d.land, e = e }
end

-- Darf der Spieler diesen Dungeon betreten? (Fraktionssperre, Eingang nur in feindlicher Hauptstadt)
function QDB:DungeonAllowed(area)
    local d = self:Dungeon(area)
    if not d then return true end
    local fc = FactionCode()
    if d.only and d.only ~= fc then return false, L["nur "] .. (d.only == "A" and L["Allianz"] or "Horde") end
    local enemy = ENEMY_MAPS[LP:PlayerFaction()]
    local open = false
    for _, e in ipairs(d.e or {}) do if not enemy[e[1]] then open = true end end
    if d.e and #d.e > 0 and not open then return false, L["Eingang in feindlicher Hauptstadt"] end
    return true
end

-- Eingang im Gebiet der anderen Fraktion?
function QDB:DungeonHostile(area)
    local d = LP.Dungeons[area]
    return d and d.land and d.land ~= FactionCode() or false
end

-- Dungeon einer Quest (auch ohne vollstaendige Questdaten)
function QDB:QuestDungeon(id)
    local q = self:Get(id)
    if q then return q.dungeon end
    local info = self:QuickInfo(id)
    return info and info.dungeon
end

function QDB:Counts()
    local c = { pack = 0, questie = 0, seed = 0, own = 0, net = 0 }
    if PACK then for _ in pairs(PACK.Q) do c.pack = c.pack + 1 end end
    if self.questie then
        local ok, list = pcall(Q.GetAllIds)
        if ok and type(list) == "table" then c.questie = #list end
    end
    for _ in pairs(LP.Seed.quests) do c.seed = c.seed + 1 end
    for _, r in pairs(LP.db.qdb) do
        if r.net then c.net = c.net + 1 else c.own = c.own + 1 end
    end
    c.total = c.pack + c.questie + c.seed + c.own + c.net
    return c
end

------------------------------------------------------------------------
-- Dienst-NPCs (Reparatur, Haendler, Flugmeister, Gasthaus)
------------------------------------------------------------------------
local serviceCache = nil

function QDB:ServiceNPCs()
    if serviceCache then return serviceCache end
    serviceCache = { repair = {}, vendor = {}, flight = {}, inn = {}, trainer = {}, bank = {}, auction = {}, mailbox = {} }
    local fac = LP:PlayerFaction() == "Horde" and "H" or "A"
    local function add(v)
        if v.repair then table.insert(serviceCache.repair, v) end
        if v.vendor then table.insert(serviceCache.vendor, v) end
        if v.flight then table.insert(serviceCache.flight, v) end
        if v.inn then table.insert(serviceCache.inn, v) end
        if v.trainer then table.insert(serviceCache.trainer, v) end
        if v.bank then table.insert(serviceCache.bank, v) end
        if v.auction then table.insert(serviceCache.auction, v) end
    end
    -- eigene Aufzeichnung und Startdatenbank zuerst
    for _, v in pairs(LP.db.vendors) do if not v.f or v.f == fac then add(v) end end
    for _, v in pairs(LP.Seed.vendors or {}) do if not v.f or v.f == fac then add(v) end end

    if PACK then
        for _, n in pairs(PACK.N) do
            if n.v and n.f and n.f:find(fac) and n.s and n.s[1] then
                local z = n.s[1]
                add({ map = z[1], x = z[2], y = z[3], name = n.n, sub = n.sb,
                      vendor = LP.HasBit(n.v, 1), repair = LP.HasBit(n.v, 2),
                      flight = LP.HasBit(n.v, 4), inn = LP.HasBit(n.v, 8),
                      trainer = LP.HasBit(n.v, 16), bank = LP.HasBit(n.v, 32), auction = LP.HasBit(n.v, 64) })
            end
        end
        for _, mb in ipairs(PACK.MB or {}) do
            table.insert(serviceCache.mailbox, { map = mb[1], x = mb[2], y = mb[3], name = L["Briefkasten"], mailbox = true })
        end
    elseif self.questie then
        local lib = _G.LibQuestieDB
        local flags = lib and lib.Enum and lib.Enum.npcFlags
        if flags then
            local ok, ids = pcall(NPC.GetAllIds)
            if ok and type(ids) == "table" then
                for _, id in ipairs(ids) do
                    local okF, f = pcall(NPC.npcFlags, id)
                    if okF and f and f ~= 0 then
                        local v = {
                            repair = flags.REPAIR and LP.HasBit(f, flags.REPAIR),
                            vendor = flags.VENDOR and LP.HasBit(f, flags.VENDOR),
                            flight = flags.FLIGHT_MASTER and LP.HasBit(f, flags.FLIGHT_MASTER),
                            inn = flags.INNKEEPER and LP.HasBit(f, flags.INNKEEPER),
                        }
                        if v.repair or v.vendor or v.flight or v.inn then
                            local okR, friendly = pcall(NPC.friendlyToFaction, id)
                            if okR and type(friendly) == "string" and friendly:find(fac) then
                                local pts = {}
                                QNpc(id, pts, 1)
                                if pts[1] then
                                    v.map, v.x, v.y, v.name = pts[1][1], pts[1][2], pts[1][3], pts[1][4]
                                    add(v)
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    return serviceCache
end

function QDB:InvalidateServices() serviceCache = nil end

function QDB:NearestService(kind, filter)
    local list = self:ServiceNPCs()[kind] or {}
    local pi, pn, pw = LP.Geo:Player()
    if not pi then return nil end
    local best, bestD
    for _, v in ipairs(list) do
        local i, n, w = LP.Geo:ToWorld(v.map, v.x, v.y)
        if i == pi and (not filter or filter(v)) then
            local d = LP.Geo:Dist(pn, pw, n, w)
            if not bestD or d < bestD then best, bestD = v, d end
        end
    end
    return best, bestD
end
