-- LevelPilot - Prüfliste im Spiel (/lp prüfliste), nur Testmodus (Entscheid des Nutzers 16.11.2026 06:47, Supervisor 06:49)
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Nutzt den gemeinsamen Baustein GoldSentinelPruefliste.lua (unverändert aus shared/). Die Liste enthält die offenen Punkte
-- "im Client prüfen" (offen-levelpilot.txt, eigene Berichte), höchstens 14, in der Reihenfolge, in der man sie im Spiel am
-- besten nacheinander macht. Die meisten Punkte merken selbst, dass sie erledigt sind: M:Hit() steht im Code genau dort, wo
-- die Funktion wirklich benutzt wurde (Hinweis im Assistenten gezeigt, Plus am Händler gesetzt, Messung gemacht ...).
--
-- Testmodus: der Baustein fragt GoldSentinelDev. Seit 3.12.48 bringt LevelPilot GoldSentinelDev.lua (Version 2, Prüfsummen
-- statt Namen; Supervisor 16.11. 07:44) selbst mit; die neueste Kopie aller Addons gilt. LevelPilot meldet sich trotzdem erst
-- beim ersten Gebrauch an (Battle.net ist beim Laden manchmal noch nicht bereit).
-- Ohne Testmodus ist alles wirkungslos: keine Liste, kein Fenster, keine Rechnung (höchstens ein Versuch je 30 s).

local _, LP = ...
local L = LP.L
local M = {}
LP:RegisterModule("Pruefliste", M)

local function Now() return GetTime and GetTime() or 0 end
local function Perf() return LP.Perf end

-- Summe der Rechenzeit in den ersten 60 s nach dem Einloggen (alle Module), nil = keine Messung
local function LoginMs()
    local P = Perf()
    if not (P and P.stats) then return nil end
    local sum, any = 0, false
    for _, s in pairs(P.stats) do
        if (s.ln or 0) > 0 then sum, any = sum + (s.lms or 0), true end
    end
    return any and sum or nil
end
M.LoginMs = LoginMs

------------------------------------------------------------------------
-- Punkte (id = Kürzel aus offen-levelpilot.txt bzw. Testnummer, since = Version der Funktion)
------------------------------------------------------------------------
M.POINTS = {
    { id = "CT-1", title = "Client-Test einmal ganz durchlaufen", since = "3.12.45",
      todo = "Im Chat /lp clienttest tippen. Es erscheinen bis zu 3 Fragen – jede mit „OK“, „Nicht OK“ oder „Überspringen“ beantworten.",
      expect = "Chatzeile „Client-Test fertig: OK … · FEHLER 0 · …“. Steht bei FEHLER eine Zahl über 0: /lp diag, Zeile CLIENTTEST.",
      auto = function()
          local d = LP.db and LP.db.clientTest
          if type(d) ~= "table" or type(d.lines) ~= "table" or d.version ~= LP.version then return nil end
          local bad, open = 0, 0
          for _, l in ipairs(d.lines) do
              if tostring(l):find("^T%d+ FEHLER") then bad = bad + 1 elseif tostring(l):find("^T%d+ %?") then open = open + 1 end
          end
          if bad > 0 then return false, ("%d von %d FEHLER (Zeile CLIENTTEST in /lp diag)"):format(bad, #d.lines) end
          if open > 0 or #d.lines == 0 then return nil end
          return true, ("%d Punkte, FEHLER 0"):format(#d.lines)
      end },
    { id = "T300", title = "Hinweis Erholt-Bonus bei Pause", since = "3.12.39",
      todo = "Ausserhalb von Gasthaus und Hauptstadt stehen bleiben (nicht im Kampf) und im Chat /afk tippen. Danach /afk nochmals tippen.",
      expect = "Im Assistenten: „Pause? Im Gasthaus oder in einer Hauptstadt ausloggen …“ mit dem Knopf „Hinführen“ zum nächsten Gasthaus." },
    { id = "T304", title = "Plus-Zeichen beim Händler", since = "3.12.42",
      todo = "Einen Händler mit Rüstung oder Waffen ansprechen (z. B. Rüstungs- oder Waffenhändler in einer Stadt).",
      expect = "Teile, die für deine Klasse besser sind als das Angelegte, tragen oben links ein grünes Plus. Stimmt ein Plus nicht: „Nicht OK“." },
    { id = "T305", title = "Talent-Vorschlag im Assistenten", since = "3.12.43",
      todo = "Mit mindestens einem freien Talentpunkt (ab Level 10) in den Assistenten schauen.",
      expect = "Unter „… Talentpunkt(e) frei“ die Zeile „Vorschlag (Level-Build von LevelPilot): <Talent> x/y – <Grund>“; im Talentfenster (N) gibt es das Talent." },
    { id = "T302", title = "Hinweis Waffenmeister", since = "3.12.40",
      todo = "Eine grüne (oder bessere) Waffe einer Waffenart, die deine Klasse lernen darf, aber noch nicht kann, in die Tasche legen.",
      expect = "Im Assistenten: „<Waffe> in deiner Tasche: Waffenart „…“ noch nicht gelernt. Lernen beim Waffenmeister …“ mit Ort und Knopf „Hinführen“." },
    { id = "T301", title = "Hinweis Waffenfertigkeit", since = "3.12.39",
      todo = "Eine Waffe anlegen, deren Fertigkeit mindestens 25 unter dem Höchstwert liegt (z. B. gerade beim Waffenmeister gelernt).",
      expect = "Im Assistenten: „Waffenfertigkeit <Art>: x von y – du verfehlst öfter …“. Nach dem Üben (Abstand unter 25) verschwindet er." },
    { id = "T303", title = "Abgegraste Stelle", since = "3.12.41",
      todo = "Bei einer Quest mit Töte- oder Sammelziel an der angezeigten Stelle 3 Minuten bleiben, ohne dass der Zähler steigt (nicht /afk).",
      expect = "Im Assistenten: „Seit 3 Min. kein Fortschritt bei „…“ – Stelle abgegrast? …“ mit Knopf „Andere Stelle“; Klick -> Pfeil zeigt woanders hin." },
    { id = "GR1-K", title = "„+1 später abgeben“ im Kompaktmodus", since = "3.12.33",
      todo = "Eine Quest fertig haben, deren Abgabe in einer anderen Zone liegt, dann /lp kompakt tippen (nochmals /lp kompakt stellt zurück).",
      expect = "In der einen Zeile hinten grün „· +1 später abgeben“; Maus darüber zeigt den Questnamen." },
    { id = "UC-W1", title = "Weg in Unterstadt (Auktionshaus -> Lich)", since = "3.12.35",
      todo = "In Unterstadt beim Auktionshaus ein Ziel im Magieviertel wählen (Quest 405 abgeben oder /lp wegmessung, Lauf 1, Schritt 2).",
      expect = "Pfeil mit Entfernung OHNE „(Weg unbekannt)“; Linie auf der Minikarte durch die Stadt." },
    { id = "WM", title = "Wegmessung ganz durchlaufen", since = "3.12.46",
      todo = "GSWegMess installiert (shared/messtest), dann /lp wegmessung. Das kleine Fenster sagt jeden Schritt; am Ziel „Markieren & weiter“.",
      expect = "Am Ende Chatzeile „Wegmessung fertig (12 Markierungen) …“. Danach /reload und SavedVariables/GSWegMess.lua schicken." },
    { id = "L-1", title = "Speicher-Messung beim Protokoll", since = "3.12.34",
      todo = "Im Chat /lp protokoll tippen.",
      expect = "Im Text die Zeile „SPEICHER LevelPilot … Speicher-Messung x ms“ (Zahl merkt die Liste). Im Spiel-Profiler keine Spitzen alle 5 Min." },
    { id = "LAG1", title = "Krieger: erste 60 s nach dem Einloggen", since = "3.12.24",
      todo = "Mit dem Krieger einloggen, sofort losgehen, nach 2 Minuten /lp protokoll tippen.",
      expect = "Sofort laufen können, kein Stocken; Zeile „ZEIT erste 60 s nach dem Einloggen“ zusammen unter 1000 ms (merkt die Liste)." },
    { id = "PF-A", title = "Allianz: Planung unter 16 ms", since = "3.12.32",
      todo = "Mit einem Allianz-Charakter (z. B. Wald von Elwynn) 10 Minuten Quests machen, dann /lp protokoll tippen.",
      expect = "Zeile „ZEIT … Routenberechnung … max x“ mit x höchstens 16 (nicht rot). Die Liste prüft es selbst." },
    { id = "SP1-M", title = "Speicher nach 2–4 Stunden Spiel", since = "3.12.30",
      todo = "Normal 2 bis 4 Stunden spielen (ohne /reload), dann /lp protokoll tippen und den Text schicken.",
      expect = "Zeilen „SPEICHER … Bestand: Wegpunkte …“ – unter 50 000 Wegpunkten. Die Liste merkt es ab 2 Stunden Spielzeit." },
}

------------------------------------------------------------------------
-- Anmeldung beim Baustein (erst beim ersten Gebrauch, siehe oben)
------------------------------------------------------------------------
M.RETRY = 30
M.list, M.nextTry = nil, 0                               -- angemeldete Liste (nil = noch nicht), nächster Versuch
function M.DB() return LevelPilotDB end                  -- Speicherort des Zustands (Feld "pruefliste"); Testroutine ersetzt ihn
function M.Baustein() return _G.GoldSentinelPruefliste end
function M:List(force)
    if self.list then return self.list end
    local PL = M.Baustein()
    if type(PL) ~= "table" or type(PL.Register) ~= "function" or type(PL.IsDev) ~= "function" then return nil end
    if not force and Now() < self.nextTry then return nil end
    self.nextTry = Now() + M.RETRY
    if not PL.IsDev() then return nil end
    self.list = PL:Register("LevelPilot", { db = function() return M.DB() end, version = LP.version, points = M.POINTS })
    return self.list
end

-- Funktion wurde wirklich benutzt -> Punkt erledigt (nur wenn noch offen; OK/Nicht OK des Spielers bleiben)
-- Testroutine (trocken) und virtuelle Reise markieren nie etwas: nur echtes Spielen zählt
function M.Dry() return (LP.Act and LP.Act.dry) or (LP.Virtual and LP.Virtual.active) or false end
function M:Hit(id, note)
    if M.Dry() then return false end
    local l = self:List()
    if not l then return false end
    return l:Hit(id, note) == true
end
-- Messung zeigt einen Fehler -> "Fehler (erkannt)" (nur aus "offen"; ein späterer Hit macht den Punkt erledigt)
function M:Fail(id, note)
    if M.Dry() then return false end
    local l = self:List()
    if not (l and l.byId and l.byId[id]) then return false end
    if l:State(id) ~= "offen" then return false end
    return l:Set(id, "fehler", note) == true
end
function M:Check(id, good, note)
    if good then return self:Hit(id, note) end
    return self:Fail(id, note)
end

-- Beim Öffnen des Protokolls (/lp protokoll): Messwerte für L-1, LAG1, PF-A, SP1-M
M.SP1_SECS = 7200
function M:OnProtocol()
    if not self:List() then return end
    local mem = LP.Protocol and LP.Protocol.MemInfo and LP.Protocol.MemInfo() or {}
    if mem.ms then self:Hit("L-1", ("Speicher-Messung %.0f ms"):format(mem.ms)) end
    local P = Perf()
    local login = LoginMs()
    if login and select(2, UnitClass("player")) == "WARRIOR" then
        self:Check("LAG1", login < 1000, ("erste 60 s zusammen %d ms"):format(math.floor(login)))
    end
    local route = P and P.stats and P.stats.route
    if route and (route.n or 0) > 0 and LP:PlayerFaction() == "Alliance" then
        local mx = route.max or 0
        self:Check("PF-A", mx <= (P.FRAME_MS or 16), ("Routenberechnung max %d ms bei %d Läufen"):format(math.floor(mx), route.n))
    end
    if P and P.loginT and Now() - P.loginT >= M.SP1_SECS then
        local G = LP.Graph
        local nodes = G and G.Count and G:Count() or 0
        self:Check("SP1-M", nodes < 50000, ("nach %d Min.: Wegpunkte %d"):format(math.floor((Now() - P.loginT) / 60), nodes))
    end
end

-- Zeilen für den Testbericht (Protokoll/GSDIAG1): nur Kürzel und Zahlen
function M:ReportLines()
    local l = self:List()
    if not l then return {} end
    return l:ReportLines()
end

-- /lp prüfliste
function M:Open()
    if not LP:DevOnly() then return false end
    local l = self:List(true)
    if not l then
        LP:Reply(L["Prüfliste: Der gemeinsame Baustein meldet keinen Testmodus. Er braucht GoldSentinelDev (kommt mit RaidMaster oder einem anderen GoldSentinel-Addon) – /gsdev zeigt den Stand."])
        return false
    end
    return l:Open() == true
end

function M:Init() end
