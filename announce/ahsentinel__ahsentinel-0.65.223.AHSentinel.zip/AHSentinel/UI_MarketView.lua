if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Stufe 3: Reiter "Markt" ersetzt "Heute tun" (Anweisung der Prüf-Sitzung 10.11. 10:45, Entscheide des
-- Nutzers: die Liste aller Items "braucht niemand", Daten bleiben im Hintergrund; so einfach wie möglich)
--
-- M1 Eine Leiste mit 6 Ansichten: Heute (das bisherige "Heute tun") / Flippen / Händler / Lücken / Überfüllt / Trends.
--    Jede Ansicht: eine Erklärzeile, höchstens 20 Zeilen, je Zeile eine Zahl, Sicherheit als Farbe, ein Knopf.
-- M2 Die Liste aller Items ist aus der Anzeige verschwunden (Reiter "Alle Preise" ausgeblendet, Daten bleiben).
--    Nachschlagen über das Suchfeld oben.
-- M3 Detailbereich rechts (Klick auf eine Zeile oder Suche): Preis- und Angebotsverlauf, Preisleiter, eigene
--    Geschichte, gelernte Preisgrenzen, EINE Empfehlung mit Begründung, Knöpfe Watchlist / Einkaufsliste / Sniper.
-- M4 Lage-Zeile: Preis-Index aus einem Korb typischer Waren.
-- M5 Nachschub (Herstellen) bleibt in "Heute" (ProfessionSentinel oder eigene Rezeptliste).
-- M6 Einzige neue Option: "Standard-Ansicht".
--
-- NICHTS GEHT VERLOREN: Zeilen und Knöpfe von "Heute tun" (A.Today: Prüfen -> Kaufen -> Einstellen, nie ohne Klick),
-- QuickBuy/QuickSell (Zeilen oben), /ahs heute, UI:ShowToday. Rechnen in Portionen (A:Job, A:Pause).
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local UI = A.UI
local C = UI.C

local MV = {}
A.MarketView = MV

MV.VIEWS = { "heute", "lager", "flip", "vendor", "gaps", "crowded", "trends", "de" }
MV.LABELS = { heute = "Heute", lager = "Mein Lager", flip = "Flippen", vendor = "Händler", gaps = "Lücken", crowded = "Überfüllt", trends = "Trends", de = "Entzaubern" }
MV.EXPLAIN = {
    heute = "Deine Sachen zuerst (einstellen, neu einstellen, entzaubern, herstellen), darunter die besten Chancen. Der Knopf macht den nächsten Schritt.",
    lager = "Alles, was dir gehört (Taschen, Bank aller Figuren, eigene Auktionen): Menge, Wert jetzt nach Gebühren, bester Weg. Was beim Warten am meisten verliert, steht oben.",
    flip = "Unter deiner Kaufgrenze kaufen und wieder einstellen - sortiert nach Gewinn je Gold Einsatz und Tag.",
    vendor = "Sofortkauf unter dem Händlerpreis: kaufen und beim Händler verkaufen - sicherer Gewinn.",
    gaps = "Wenig Angebot, stetiger Absatz, Preis steigt - gute Zeit zum Einstellen. Was du im Lager hast, steht oben.",
    crowded = "Viel mehr Angebot als Absatz: lieber nicht einstellen - jede Rückkehr kostet die Einzahlung.",
    trends = "Echte Bewegungen über 7 und 30 Tage (nur wenn stabil). Fallende Leveling-Waren stehen oben.",
    de = "Teile, die nach dem Entzaubern mindestens 20 % Gewinn bringen – zum aktuellen Markt, nach Gebühren.",
}
MV.MAX_ROWS = 20
MV.DETAIL_W = 300
-- M4 Korb typischer Waren (Stoffe, Erze, Kräuter, Staub/Essenzen, Leder) - nur die, die im Markt vorkommen
MV.BASKET = { 2589, 2592, 4306, 4338, 14047, 2770, 2771, 2772, 3858, 10620, 2447, 765, 785, 2450, 3820, 3821, 3818,
    10940, 11083, 11137, 11176, 16204, 10938, 10998, 11082, 2318, 2319, 4234, 4304, 8170 }
local LEVELING = { cloth = true, leather = true, metal = true, herb = true }

-- MR1-V (Nutzer 16:25, Entscheide 13.11. 06:00/06:20): sichtbar nur, was belegt ist und eine Handlung hat - "Heute" und
-- "Entzaubern". Flippen, Händler, Lücken, Überfüllt, Trends laufen im Hintergrund weiter (Testbericht), sind aber nur mit der
-- Option "Experten: alle Ansichten" (Standard aus) zu sehen.
MV.SIMPLE = { heute = true, lager = true, de = true }
function MV:Expert()
    -- Testroutine: alle Ansichten (ihre Tests prüfen sie), ausser der Test der Ausblendung selbst (MV.testSimple)
    if A.InTestRoutine and A:InTestRoutine() and not self.testSimple then return true end
    return A.db and A.db.settings and A.db.settings.marketExpert == true
end
function MV:Visible(v) return self:Expert() or self.SIMPLE[v] == true end
function MV:VisibleViews()
    local out = {}
    for _, v in ipairs(self.VIEWS) do if self:Visible(v) then out[#out + 1] = v end end
    return out
end
function MV.HelpTop() return L["Hier steht nur, was sich mit deinen Daten lohnt."] end
function MV:DefaultView()
    local v = A.db and A.db.settings and A.db.settings.marketView
    for _, x in ipairs(self.VIEWS) do if x == v and self:Visible(x) then return v end end
    return "heute"
end

-- ------------------------------------------------------------
-- Daten der Ansichten (in Portionen gerechnet; Zeilen im Format von "Heute tun", damit der Knopf gleich arbeitet)
-- ------------------------------------------------------------
local function Fresh(t) return t and time() - t <= 2 * 86400 end

-- Sicherheit: "hoch" (grün) / "mittel" (gelb) / "niedrig" (grau)
function MV:Safety(itemID)
    local ok, reliable, l = pcall(A.IsReliable, A, itemID)
    if not ok then return "niedrig" end
    local conf = l and l.conf
    if reliable and conf == "hoch" then return "hoch" end
    if reliable then return "mittel" end
    return "niedrig"
end

-- K1 (Entscheid 10.11.): Kaufvorschläge einer Ansicht zusammen höchstens A:MarketCapitalPct() % des Golds; in der
-- Reihenfolge der Liste, ein nicht ganz passender Vorschlag wird gekürzt, sonst fällt er weg
function MV:CapRows(rows, money)
    money = money or (GetMoney and GetMoney() or 0)
    local cap = money * A:MarketCapitalPct() / 100
    local out, used = {}, 0
    for _, r in ipairs(rows) do
        local price = r.price
        if not (price and price > 0 and r.qty) then
            out[#out + 1] = r
        else
            local need = r.cost or price * r.qty                  -- D1: echte Kosten über die Preisleiter
            if used + need <= cap then
                used = used + need
                out[#out + 1] = r
            elseif r.refit then
                -- D2: auf das restliche Budget neu planen (Stufen der Preisleiter von unten)
                local r2 = (cap - used >= price) and r.refit(cap - used) or nil
                if r2 and r2.qty >= 1 and r2.cost <= cap - used then
                    used = used + r2.cost
                    out[#out + 1] = r2
                end
            else
                local q = math.floor((cap - used) / price)
                if q >= 1 then
                    r.gold = math.floor((r.unitGold or 0) * q)
                    r.qty = q
                    if r.retext then r.text = r.retext(q) end
                    used = used + price * q
                    out[#out + 1] = r
                end
            end
        end
    end
    return out, used, money
end

-- F3 (Befund Schein-Flip 10.11. 16:50): Selbsttest beim Aufbau - eine Flip-Zeile nur, wenn der Detailbereich für
-- dasselbe Item "kaufen bis X" mit derselben Rechnung sagt (gleiche Grenze, gleicher Wiederverkauf); sonst verwerfen
-- und Protokoll FLIP-WIDERSPRUCH
function MV:FlipConsistent(itemID, limit, resale)
    local ok, kind, _, _, fr = pcall(self.Advice, self, itemID)
    local same = ok and kind == "buy" and fr and fr.limit == limit and fr.resale == resale
    if not same and A.Diag then
        pcall(A.Diag.Add, A.Diag, "FLIP-WIDERSPRUCH", string.format("Item %s · Liste bis %s / %s · Detail %s bis %s / %s", tostring(itemID),
            tostring(limit), tostring(resale), tostring(ok and kind), tostring(fr and fr.limit), tostring(fr and fr.resale)))
    end
    return same and true or false
end

function MV:BuildFlip()
    local out = {}
    if not A:WayOn("flip") then self.reason.flip = L["Weg abgewählt (Einstellungen)."]; return out end
    local X = A.Extras
    if not (X and X.GetFlipDeals) then return out end
    local okF, flips = A:PCall(X.GetFlipDeals, X, 50)
    if not okF then return out end
    local Ln = A.Learn
    local money = GetMoney and GetMoney() or 0
    local cap = money * ((A.Comfort and A.Comfort.TODAY_ITEM_SHARE) or 0.2)
    for _, d in ipairs(flips) do
        A:Pause()
        local ok = A:IsReliable(d.itemID)
        if ok and Ln and Ln.On and Ln:On() and d.ref then
            local lim = Ln:BuyLimit(math.floor(d.ref * (1 - A:CutPct())), "e")
            if lim and d.price > lim then ok = false end
        end
        if ok then ok = self:FlipConsistent(d.itemID, d.limit, d.ref) end      -- H3/F3: Liste = Detail
        if ok then
            local pd, psrc = A:PerDayInfo(d.itemID)                       -- K2: plausibel, Quelle ehrlich
            local perDay = pd or 0
            local qty = math.max(1, math.min(math.floor(math.max(1, perDay)), d.quantity or 1))
            if d.qtyMax then qty = math.min(qty, d.qtyMax) end
            if d.price > 0 then qty = math.max(1, math.min(qty, math.floor(cap / d.price))) end
            local score = (d.profit / math.max(1, d.price)) * math.min(1, perDay)
            local function retext(q)
                return string.format(L["Kaufe %dx %s bis %s, wieder einstellen um %s (verkauft sich ~%s/Tag, %s)"], q, d.name or A:GetItemName(d.itemID),
                    A:FormatMoney(d.price), A:FormatMoney(d.ref), string.format("%.1f", perDay), psrc or "?")
            end
            out[#out + 1] = { kind = "flip", itemID = d.itemID, maxUnit = d.price, qty = qty, unit = A:GetSalePrice(d.itemID),
                gold = math.floor(d.profit * qty), score = score, safety = self:Safety(d.itemID), text = retext(qty),
                price = d.price, unitGold = d.profit, retext = retext,
                where = L["Einkauf"], run = function() A.UI:OpenBuyFor(d.itemID) end }
        end
    end
    table.sort(out, function(a, b) return a.score > b.score end)
    out = self:CapRows(out)
    self.reason.flip = L["Kein Flip unter deiner Kaufgrenze (realistischer Wiederverkauf aus Angebot und Absatz)."]
    return out
end

-- MR2 Mein Lager (anweisung-markt-reiter, Masterplan 4.2): alle eigene Ware - Taschen und Bank ALLER Figuren (Characters),
-- eigene Auktionen (Meine Auktionen, nicht verkauft). Je Item: Menge (wo), Wert jetzt = bester Weg nach Gebühren × Menge
-- (A:BestWay: Verkaufen/Entzaubern/Händler, eine Zahl wie überall) nur mit frischem Scan (≤ STOCK_FRESH s), sonst grau
-- "Scan nötig"; Sortierung: erwarteter Verlust bis zum nächsten Login zuerst (Trend der letzten 24 Std. × Wert, nur fallend),
-- danach Wert. Post (Briefkasten) kennt AHSentinel nicht als Bestand -> nicht enthalten (im Bericht genannt).
MV.STOCK_FRESH = 1800
function MV:StockItems()
    local items = {}
    local function add(id, field, n)
        if not (id and n and n > 0) then return end
        local e = items[id]
        if not e then e = { itemID = id, bags = 0, bank = 0, post = 0, ah = 0, cq = 0, cc = 0 }; items[id] = e end
        e[field] = e[field] + n
    end
    -- Post (Briefkasten, Stand beim letzten Öffnen: Books db.inboxSnap) und Herkunft (Einstand aus der Buchhaltung db.cb)
    local BK = A.Books
    local bdb = BK and BK.Data and BK:Data()
    local function addChar(key)
        local snap = bdb and bdb.inboxSnap and bdb.inboxSnap[key]
        for id, n in pairs((snap and snap.items) or {}) do add(id, "post", n) end
    end
    local function cost(e, key)
        local p = bdb and bdb.cb and bdb.cb[key]
        p = p and p[e.itemID]
        if p and (p.q or 0) > 0 then e.cq, e.cc = e.cq + p.q, e.cc + (p.c or 0) end
    end
    local keys = {}
    local Ch = A.Chars
    local db = Ch and A.db and A.db.chars
    -- nur Figuren, die dieses Auktionshaus erreichen (gleicher Server, gleiche Fraktion, falls bekannt)
    local me = Ch and Ch.Me and Ch:Me()
    for key, c in pairs(type(db) == "table" and db or {}) do
        if type(c) == "table" and (not me or ((c.realm == nil or c.realm == me.realm)
            and (c.faction == nil or me.faction == nil or c.faction == me.faction))) then
            for id, n in pairs(c.bags or {}) do add(id, "bags", n) end
            for id, n in pairs(c.bank or {}) do add(id, "bank", n) end
            addChar(key)
            keys[#keys + 1] = key
        end
    end
    -- eigene Auktionen: in dieser Sitzung gelesen (Meine Auktionen) -> genau; sonst die gemerkten laufenden (db.ownedEnds)
    local Se = A.Seller
    if Se and Se.ownedTime then
        for _, o in ipairs(Se.owned or {}) do
            if not o.sold then add(o.itemID, "ah", o.qty or 1) end
        end
    else
        local now = time()
        for _, e in ipairs((A.db and A.db.ownedEnds) or {}) do
            if (e.endsAt or 0) > now then add(e.itemID, "ah", e.qty or 1) end
        end
    end
    for _, e in pairs(items) do for _, key in ipairs(keys) do cost(e, key) end end
    return items
end
function MV:BuildStock()
    local out = {}
    local now = time()
    for id, e in pairs(self:StockItems()) do
        A:Pause()
        local qty = e.bags + e.bank + e.post + e.ah
        local okW, v, way = pcall(A.BestWay, A, id)
        if not okW then v, way = nil, nil end
        local _, _, t = A:GetCurrent(id)
        local fresh = t and (now - t) <= self.STOCK_FRESH
        local where = {}
        if e.bags > 0 then where[#where + 1] = string.format(L["Taschen %d"], e.bags) end
        if e.bank > 0 then where[#where + 1] = string.format(L["Bank %d"], e.bank) end
        if e.post > 0 then where[#where + 1] = string.format(L["Post %d"], e.post) end
        if e.ah > 0 then where[#where + 1] = string.format(L["Auktionen %d"], e.ah) end
        local value = (v and v > 0) and math.floor(v * qty + 0.5) or nil
        local okT, trend = pcall(A.GetTrend, A, id, 86400)
        local loss = (okT and trend and trend < 0 and value) and math.floor(value * (-trend) / 100 + 0.5) or 0
        local wayTxt = way == "de" and L["Entzaubern"] or (way == "vendor" and L["Händler"]) or (way == "sell" and L["Verkaufen"]) or nil
        local name = A:GetItemName(id) or ("#" .. id)
        if value and value > 0 then
            local help = {}
            if loss > 0 then help[#help + 1] = string.format(L["Preis fällt (24 Std. %d %%) - Warten bis morgen kostet etwa %s."], math.floor(trend + 0.5), A:FormatMoney(loss)) end
            if not fresh then help[#help + 1] = L["Wert aus dem letzten Scan - älter als 30 Minuten. Markt scannen für den Wert jetzt."] end
            -- Herkunft: Einstand aus der Buchhaltung (gekauft) - sonst Beute/ohne Kaufpreis
            if e.cq > 0 then help[#help + 1] = string.format(L["Herkunft: %d gekauft, Einstand %s je Stück"], e.cq, A:FormatMoney(math.floor(e.cc / e.cq + 0.5)))
            else help[#help + 1] = L["Herkunft: Beute oder ohne Kaufpreis"] end
            help = table.concat(help, "\n")
            -- ein Knopf je Zeile (bester Ausgang): nur was in den Taschen dieser Figur liegt, lässt sich direkt bewegen
            local bagsMe = (A.Seller and A.Seller.CountInBags and A.Seller:CountInBags(id)) or 0
            local btn = (way == "sell" and bagsMe > 0 and "sell") or (way == "de" and bagsMe > 0 and "de")
                or (way == "vendor" and bagsMe > 0 and "vendor") or "keep"
            out[#out + 1] = { kind = "stock", itemID = id, gold = fresh and value or nil, sortGold = value, loss = loss,
                help = help,
                costUnit = (e.cq > 0) and math.floor(e.cc / e.cq + 0.5) or nil,
                btn = btn, bagsMe = bagsMe, num = (not fresh) and A:FormatMoney(value) or nil, stale = not fresh,
                text = string.format("%d× %s%s", qty, name, wayTxt and (" – " .. wayTxt) or ""),
                state = fresh and table.concat(where, " · ") or ("|cff888888" .. L["Scan nötig"] .. "|r · " .. table.concat(where, " · ")),
                where = table.concat(where, " · ") }
        end
    end
    table.sort(out, function(a, b)
        if a.loss ~= b.loss then return a.loss > b.loss end
        return a.sortGold > b.sortGold
    end)
    for i, r in ipairs(out) do r.order = i end
    self.reason.lager = L["Kein Lager mit bekanntem Wert (Taschen/Bank einmal öffnen, Markt scannen)."]
    return out
end

MV.STOCK_BTN = { sell = "Einstellen", de = "Entzaubern", vendor = "Händler", keep = "Behalten" }
function MV:StockLabel(r)
    return L[self.STOCK_BTN[r.btn] or "Behalten"], r.btn ~= "keep"
end
-- Klick: Einstellen -> Zeile in "Heute tun" (Preisschutz, ein Klick stellt ein; T:QuickSell); Entzaubern -> Entzauber-Fenster;
-- Händler -> Hinweis (verkauft wird beim Händler); Behalten -> nichts. Nie ein Kauf/Einstellen ohne weiteren Klick.
function MV:StockClick(r)
    if r.btn == "sell" and A.Today and A.Today.QuickSell then return A.Today:QuickSell(r.itemID, r.bagsMe) end
    if r.btn == "de" and A.DEWindow and A.DEWindow.Show then return A.DEWindow:Show() end
    if r.btn == "vendor" then A:Print(L["Geh zu einem Händler - dort verkauft der Knopf rechts in dieser Zeile."]); return true end
    return false
end

function MV:BuildVendor()
    local out = {}
    if not A:WayOn("vendor") then self.reason.vendor = L["Weg abgewählt (Einstellungen)."]; return out end
    local okV, list = A:PCall(A.VendorFlipOffers, A, nil, self.MAX_ROWS)
    if not okV then return out end
    for _, d in ipairs(list) do
        local function retext(q)
            return string.format(L["Unter Händlerpreis: kaufen und beim Händler verkaufen - %dx %s ab %s, Händler zahlt %s"],
                q, d.name or A:GetItemName(d.itemID), A:FormatMoney(d.price), A:FormatMoney(d.vendor))
        end
        out[#out + 1] = { kind = "vendor", itemID = d.itemID, maxUnit = d.vendor - 1, qty = d.qty, vendor = d.vendor,
            gold = math.floor(d.profit or ((d.vendor - d.price) * d.qty)), safety = "hoch", text = retext(d.qty),
            price = d.price, unitGold = d.vendor - d.price, retext = retext,
            where = L["Einkauf"], run = function() A.UI:OpenBuyFor(d.itemID) end }
    end
    table.sort(out, function(a, b) return a.gold > b.gold end)
    out = self:CapRows(out)
    self.reason.vendor = L["Kein Sofortkauf unter dem Händlerpreis im letzten Scan."]
    return out
end

-- mittlere Angebotsmenge der letzten 7 Tage (aus dem Preisverlauf)
local function AvgQty(itemID, days)
    local F, nF = A:HF(itemID)
    local from = time() - (days or 7) * 86400
    local sum, n = 0, 0
    for i = nF, 1, -1 do
        if F[(i - 1) * 5 + 1] < from then break end
        local q = A.HQ(F, i)
        if q then sum, n = sum + q, n + 1 end
    end
    return n >= 2 and sum / n or nil, n
end

local function PerDay(itemID)
    local VS = A.FullScan
    if VS and VS.MeasuredRate then
        local ok, m = pcall(VS.MeasuredRate, VS, itemID)
        if ok and m then return m, true end
    end
    local ok, l = pcall(A.GetLiquidity, A, itemID)
    return ok and l and l.perDay or nil, false
end

function MV:BuildGaps()
    local out = {}
    local db = A.db
    if not db then return out end
    local Se = A.Seller
    for itemID in pairs(db.marketData) do
        A:Pause()
        local price, qty, t = A:GetCurrent(itemID)
        if price and qty and Fresh(t) and A:IsReliable(itemID) then
            local avg = AvgQty(itemID, 7)
            if avg and qty < avg * 0.5 then
                local trend = A:GetTrend(itemID, 7 * 86400)
                local perDay, measured = PerDay(itemID)
                if trend and trend > 0 and perDay and perDay >= 1 then
                    local have = Se and Se:CountInBags(itemID) or 0
                    local r = { itemID = itemID, gold = math.floor(perDay * price), have = have,
                        num = "+" .. math.floor(trend + 0.5) .. " %", safety = measured and "hoch" or "niedrig",
                        text = string.format(L["Wenig Angebot (%d statt Ø %d), Absatz ~%s/Tag%s, Preis steigt"], qty, math.floor(avg + 0.5),
                            string.format("%.1f", perDay), " (" .. (measured and L["gemessen"] or L["geschätzt"]) .. ")") }
                    if have > 0 then
                        r.kind, r.unit, r.count = "sell", A:GetSalePrice(itemID) or price, have
                        r.text = r.text .. " · " .. string.format(L["%d in der Tasche"], have)
                    else r.kind = "lookup" end
                    out[#out + 1] = r
                end
            end
        end
    end
    table.sort(out, function(a, b)
        if (a.have > 0) ~= (b.have > 0) then return a.have > 0 end
        return a.gold > b.gold
    end)
    self.reason.gaps = L["Keine Ware mit wenig Angebot (unter halbem 7-Tage-Ø), Absatz ab 1/Tag und steigendem Preis."]
    return out
end

-- H6 (Befund 12:55): nicht nur auf GEMESSENEN Absatz warten - bis dahin mit dem geschätzten rechnen (grau, "geschätzt").
-- Kandidaten: Taschen, eigene Auktionen, gehandelte/beobachtete Items und geflutete Waren des letzten Scans.
MV.CROWDED_DAYS = 2           -- Warteschlange länger als so viele Tage Absatz = überfüllt
MV.reason = {}
function MV:CrowdedCandidates()
    local Se = A.Seller
    local seen, cands = {}, {}
    local function add(id, n) if id and not seen[id] then seen[id] = true; cands[#cands + 1] = { id, n or 1 } end end
    local okB, bag = false, {}
    if Se and Se.GetBagItems then okB, bag = A:PCall(Se.GetBagItems, Se, true) end
    for _, e in ipairs(okB and bag or {}) do add(e.itemID, e.count) end
    for _, o in ipairs(Se and Se.owned or {}) do if not o.sold then add(o.itemID, o.qty) end end
    local Fc = A.Forecast
    if Fc and Fc.RelevantItems then
        local ok, set = pcall(Fc.RelevantItems, Fc)
        if ok then for id in pairs(set) do add(id, 1) end end
    end
    for id in pairs(A.db and A.db.marketData or {}) do
        A:Pause()
        if not seen[id] then
            local ok, why = pcall(A.FlipBlocked, A, id)
            if ok and why == "flood" then add(id, 1) end
        end
    end
    return cands
end

function MV:BuildCrowded()
    local out = {}
    for _, c in ipairs(self:CrowdedCandidates()) do
        A:Pause()
        local itemID, have = c[1], math.max(1, c[2] or 1)
        local ok, v = pcall(A.SellOutlook, A, itemID, have)
        local wait = ok and v and v.queue and v.perDay and v.perDay > 0 and (v.queue + have) / v.perDay or nil
        if ok and v and v.queue and (v.rare or (wait and wait > self.CROWDED_DAYS)) then
            local okL, loss = pcall(A.ExpectedDepositLoss, A, itemID, have, A.RELIST_MAX)
            local measured = v.perDaySource == "measured"
            local days = wait and math.floor(wait + 0.5) or nil
            out[#out + 1] = { kind = "lookup", itemID = itemID, warn = true, gold = math.floor((okL and loss) or 0), wait = wait or 9999,
                num = days and string.format(L["~%d Tage"], math.max(1, math.min(days, 999))) or L["kaum"],
                safety = measured and "mittel" or "niedrig",
                text = string.format(L["Nicht einstellen: %d im Angebot, Absatz ~%s/Tag - Einzahlungsrisiko %s"], v.queue,
                    v.perDay and string.format("%.1f", v.perDay) or "0", A:FormatMoney((okL and loss) or 0))
                    .. (measured and "" or (" (" .. L["geschätzt"] .. ")")) }
        end
    end
    table.sort(out, function(a, b) return (a.wait or 0) > (b.wait or 0) end)
    self.reason.crowded = L["Keines deiner Items (Taschen, Auktionen, gehandelt, beobachtet) ist überfüllt."]
    return out
end

-- Tage Preisverlauf (ältester Scan-Eintrag im Protokoll)
function MV:HistoryDays()
    local log = A.db and A.db.scanLog or {}
    local first = log[1] and log[1].t
    if not first then return 0 end
    return math.floor((time() - first) / 86400)
end

function MV:BuildTrends()
    local out = {}
    local db = A.db
    if not db then return out end
    local Fc = A.Forecast
    for itemID in pairs(db.marketData) do
        A:Pause()
        local _, _, t = A:GetCurrent(itemID)
        if Fresh(t) and A:IsReliable(itemID) then
            local t7, t30, t3 = A:GetTrend(itemID, 7 * 86400), A:GetTrend(itemID, 30 * 86400), A:GetTrend(itemID, 3 * 86400)
            -- stabil: 3 und 7 Tage (und 30 Tage, wenn es den Verlauf schon gibt) in dieselbe Richtung, mind. 10 %
            local stable = t7 and t3 and math.abs(t7) >= 10 and (t3 > 0) == (t7 > 0)
            if stable and t30 then stable = math.abs(t30) >= 10 and (t30 > 0) == (t7 > 0) and math.abs(t30) < 500 end
            if stable and math.abs(t7) < 500 then
                local g = Fc and Fc:Group(itemID) or "misc"
                local ref = t30 or t7
                local levelFall = LEVELING[g] and ref < 0
                out[#out + 1] = { kind = "lookup", itemID = itemID, gold = math.floor(math.abs(ref)), levelFall = levelFall,
                    num = t30 and string.format("%+d %% / %+d %%", math.floor(t7 + 0.5), math.floor(t30 + 0.5)) or string.format("%+d %%", math.floor(t7 + 0.5)),
                    safety = t30 and self:Safety(itemID) or "niedrig", warn = ref < 0,
                    text = t30 and string.format(levelFall and L["Leveling-Ware fällt: 7 Tage %+d %%, 30 Tage %+d %%"] or L["7 Tage %+d %%, 30 Tage %+d %%"],
                        math.floor(t7 + 0.5), math.floor(t30 + 0.5))
                        or string.format(L["7 Tage %+d %% (30 Tage noch nicht da)"], math.floor(t7 + 0.5)) }
            end
        end
    end
    table.sort(out, function(a, b)
        if a.levelFall ~= b.levelFall then return a.levelFall and true or false end
        return a.gold > b.gold
    end)
    local days = self:HistoryDays()
    self.reason.trends = days < 7 and string.format(L["Trends: braucht 7 Tage Verlauf, noch %d Tage."], 7 - days)
        or L["Keine stabile Bewegung über 3 und 7 Tage (mindestens 10 %)."]
    return out
end

-- ------------------------------------------------------------
-- Ansicht "Entzaubern" (Anweisung 10.11. 16:20, E1–E8): Teile, die nach dem Entzaubern mindestens X % Gewinn bringen
-- (Option, Standard 20 %, 10–50) - zum aktuellen Markt (D:DealValue mit D:MatPrice), nach Gebühren
-- ------------------------------------------------------------
MV.DE_MIN_DEFAULT = 20
function MV:DEMinPct()
    local v = tonumber(A.db and A.db.settings and A.db.settings.deMinGain)
    if not v then return self.DE_MIN_DEFAULT end
    return math.max(10, math.min(50, math.floor(v + 0.5)))
end
function MV:SetDEMinPct(v)
    v = tonumber(v)
    local p = v and math.max(10, math.min(50, math.floor(v + 0.5))) or self.DE_MIN_DEFAULT
    if A.db and A.db.settings then A.db.settings.deMinGain = p end
    self.cache.de = nil
    return p
end

-- Bestand eines Materials: Taschen + Bank + eigene laufende Auktionen
local function MatHave(id)
    local Le = A.Ledger
    if not (Le and Le.StockCounts) then return 0 end
    MV.haveCache = MV.haveCache or {}
    local c = MV.haveCache
    if not c.t or time() - c.t > 30 then
        local ok, counts = pcall(Le.StockCounts, Le)
        c.t, c.counts = time(), ok and counts or {}
    end
    return c.counts[id] or 0
end

-- Bewertung eines Teils zum Preis price: Zeile oder nil, Grund
-- D1–D5 (befund-markt-entzaubern-menge): Menge, Kosten und Gewinn über die Stufen der Preisleiter bis "lohnt bis",
-- höchstens bis capLeft (Kupfer, 25-%-Grenze K1), Wert je Teil mit der geplanten Menge (D:PlannedValue = Sammelkauf).
-- Felder: qty, cost (Summe Preis × Menge je Stufe), avg, profit (Summe (Wert − Preis) × Menge), pct = profit / cost
MV.DE_REPLAN = 3
function MV:Money() return GetMoney and GetMoney() or 0 end                       -- eigene Funktion (Seam für Tests)
function MV:ItemInfo(itemID)                                                      -- Seltenheit, Gegenstandsstufe (Seam)
    local ok, _, _, quality, ilvl = pcall(GetItemInfo, itemID)
    if ok then return quality, ilvl end
    return nil, nil
end
function MV:DEPlan(ladder, price, available, upto, capLeft)
    local steps, qty, cost = {}, 0, 0
    local src = (ladder and #ladder > 0) and ladder or { { price, math.max(1, available or 1) } }
    for _, st in ipairs(src) do
        local p, q = st[1], st[2] or 0
        if not p or p > upto then break end
        if capLeft then q = math.min(q, math.floor((capLeft - cost) / p)) end
        if q <= 0 then break end
        steps[#steps + 1] = { p, q }
        qty, cost = qty + q, cost + p * q
    end
    return steps, qty, cost
end
-- Menge von oben kürzen (teuerste Stufen zuerst weg)
local function TrimSteps(steps, maxQty)
    local out, left = {}, maxQty
    for _, st in ipairs(steps) do
        if left <= 0 then break end
        local q = math.min(st[2], left)
        out[#out + 1] = { st[1], q }
        left = left - q
    end
    return out
end
-- RK2-B: "lohnt bis" der Detailzeile (dieselbe Rechnung wie Zeile, Tooltip, Sammelkauf, Sniper, API)
function MV:DEDetailLimit(net, n, itemID)
    local MK = A.Core
    if MK and MK.LimitFromNet then return MK:LimitFromNet(net, n, itemID) end
    return math.floor(net / (1 + self:DEMinPct() / 100))
end
-- RK2-B: angezeigte Zeile für 1 Stück (für den Selbsttest / MK:LimitSources)
function MV:DERowLimit(itemID)
    local ok, r = pcall(self.DEOffer, self, itemID, 1, 1, math.huge)
    return ok and r and r.upto or nil
end
function MV:DEOffer(itemID, price, available, capLeft)
    local D = A.Disenchant
    if not (D and D.PlannedValue and price and price > 0) then return nil, "kein Wert" end
    local net1, basis, n = D:PlannedValue(itemID, 1)
    if not net1 then return nil, basis == "stale" and "Preise veraltet" or "kein Wert" end
    local minPct = self:DEMinPct()
    if (net1 - price) / price * 100 < minPct then return nil, "zu wenig Gewinn" end
    if capLeft == nil then
        capLeft = self:Money() * A:MarketCapitalPct() / 100        -- D2: höchstens 25 % des Golds (Option)
    end
    local ladder = A:OfferLadder(itemID)
    -- D3: Wert sinkt mit der geplanten Menge - planen, Wert mit dieser Menge neu rechnen, nochmal planen
    local net, upto, steps, qty, cost = net1
    for _ = 1, self.DE_REPLAN do
        -- RK2-B: "lohnt bis" aus der EINEN Rechnung (A.Core:LimitFromNet); deMinGain bleibt nur Filter "mindestens X %"
        local MK = A.Core
        if MK and MK.LimitFromNet then upto = MK:LimitFromNet(net, n, itemID) or 0          -- RK4/S2-B3: nie ersatzweise
        else upto = math.floor(net / (1 + minPct / 100)) end
        steps, qty, cost = self:DEPlan(ladder, price, available, upto, capLeft)
        if qty <= 1 then break end
        local n2 = D:PlannedValue(itemID, qty)
        if not n2 or n2 >= net then break end
        net = n2
    end
    if qty < 1 then return nil, (capLeft and capLeft < price) and "Budget" or "zu wenig Gewinn" end
    -- E4c: Absatz der Materialien nur als Sicherheitsnetz (erst über einen TAG Absatz inkl. Lager und eigener Auktionen)
    local mats = D:PerPartMats(itemID) or {}
    local slow, mainMat, mainShare, mainPer = nil, nil, 0, 0
    for _, m in ipairs(mats) do
        local okP, p = pcall(D.MatPrice, D, m.id)
        local share = (okP and p or 0) * m.per
        if share > mainShare then mainMat, mainShare, mainPer = m.id, share, m.per end
        if (m.chance or 0) >= 0.1 then
            local perDay = A:PerDayInfo(m.id)
            if perDay and perDay > 0 then
                local have = MatHave(m.id)
                if have + qty * m.per > perDay then
                    local q = math.floor(math.max(0, perDay - have) / m.per)
                    if q < qty then qty, slow = q, m.id end
                end
            end
        end
    end
    if qty < 1 then return nil, "Absatz" end
    steps = TrimSteps(steps, qty)
    cost, qty = 0, 0
    local profit = 0
    for _, st in ipairs(steps) do
        cost, qty = cost + st[1] * st[2], qty + st[2]
        profit = profit + (net - st[1]) * st[2]
    end
    local avg = math.floor(cost / qty + 0.5)
    local pct = cost > 0 and profit / cost * 100 or 0
    -- E4e: Preissturz/Flutung des wichtigsten Materials -> keine Zeile; frisch gestiegen -> Zeile gelb mit Hinweis
    local fresh, noRise, buyout
    if mainMat then
        local okB, why = pcall(A.FlipBlocked, A, mainMat)
        if okB and why then return nil, "Material " .. tostring(why) end
        local okH, h = pcall(A.PriceHints, A, mainMat)
        if okH and h and h.fresh then
            fresh = mainMat
            -- D4: Wert "ohne den Anstieg" (Hauptmaterial zum Marktwert) - nur Anzeige, gerechnet wird mit dem aktuellen Markt
            local okP, p = pcall(D.MatPrice, D, mainMat)
            local mv = A:GetMarketValue(mainMat)
            if okP and p and mv and mv < p then
                local cut = A:IsForever() and 0.05 or A:CutPct()
                noRise = math.floor(net - mainPer * (p - mv) * (1 - cut) + 0.5)
            end
        end
    end
    -- D6: Aufkauf bei einem Material -> mit dem alten Preis gerechnet (D:MatPrice), Hinweis in der Zeile
    for _, m in ipairs(mats) do
        local okBo, bo = pcall(A.BuyoutInfo, A, m.id)
        if okBo and bo then buyout = m.id; break end
    end
    local name = A:GetItemName(itemID) or ("#" .. itemID)
    local quality, ilvl = self:ItemInfo(itemID)
    -- D4: "hoch" nur mit echten Chancen UND ohne frisch gestiegenes Hauptmaterial
    local safety = basis == "actual" and "hoch" or "niedrig"
    if safety == "hoch" and (fresh or buyout) then safety = "mittel" end
    local r = { kind = "deoffer", itemID = itemID, price = price, qty = qty, cost = cost, avg = avg, profit = math.floor(profit + 0.5),
        unitGold = qty > 0 and profit / qty or 0, gold = math.floor(profit + 0.5), steps = steps,
        net = net, net1 = net1, pct = pct, upto = upto, basis = basis, n = n or 0, slow = slow, fresh = fresh, noRise = noRise, buyout = buyout,
        mainMat = mainMat, quality = quality, ilvl = ilvl, safety = safety, warn = nil }
    if not r.ilvl and A.UI and A.UI.RequestItemInfo then pcall(A.UI.RequestItemInfo, A.UI, itemID) end      -- D5b
    r.retext = function()
        if not r.ilvl then
            local q2, l2 = MV:ItemInfo(itemID)
            if l2 then r.ilvl, r.quality = l2, q2 end
        end
        local t = string.format(L["%s (Stufe %s): %dx bis %s (Ø %s) · Wert %s · Gewinn %s (%d %%) · %s"], name, tostring(r.ilvl or "?"), r.qty,
            A:FormatMoney(r.upto), A:FormatMoney(r.avg), A:FormatMoney(r.net), A:FormatMoney(r.profit), math.floor(r.pct + 0.5),
            basis == "actual" and string.format(L["echt aus %d"], n or 0) or L["Tabelle"])
        if (r.quality or 2) >= 3 then t = t .. " · " .. L["blau/violett: vor dem Entzaubern bestätigen"] end
        if slow then t = t .. " · |cffffcc00" .. L["Material verkauft sich langsamer als deine Menge"] .. "|r" end
        if fresh then
            t = t .. " · |cffffcc00" .. string.format(L["Wert hängt an frisch gestiegenem Preis von %s"], A:GetItemName(fresh) or "?") .. "|r"
            if noRise then t = t .. " · " .. string.format(L["ohne Anstieg: %s"], A:FormatMoney(noRise)) end
        end
        if buyout then t = t .. " · |cffffcc00" .. (A:BuyoutText(buyout) or "") .. "|r" end
        return t
    end
    r.text = r.retext()
    r.num = string.format("%d %%", math.floor(pct + 0.5))
    -- D2: kürzen auf ein kleineres Budget = neu planen (über die Leiter, nicht nur die Menge)
    r.refit = function(left)
        local ok2, r2 = pcall(MV.DEOffer, MV, itemID, price, available, left)
        return ok2 and r2 or nil
    end
    return r
end

function MV:BuildDE()
    local out = {}
    local D = A.Disenchant
    if not (D and A.db) then return out end
    MV.haveCache = nil
    local fresh = time() - (A.FRESH_SECONDS or 7200)
    local MK = A.Core
    if MK and MK.BeginBatch then MK:BeginBatch() end                 -- RK2-B: gelernte Marge einmal je Lauf
    -- HP-3: Zählung für den Grund einer leeren Liste (geprüfte Items, frische Preise, jüngster Preis)
    local st = { fresh = 0, checked = 0, newest = nil }
    for itemID in pairs(A.db.marketData) do
        A:Pause()
        local price, qty, t = A:GetCurrent(itemID)
        if price and t and t >= fresh then
            st.fresh = st.fresh + 1
            if not st.newest or t > st.newest then st.newest = t end
        end
        if price and t and t >= fresh and D:Prior(itemID) then
            local okI, _, _, quality = pcall(GetItemInfo, itemID)
            quality = okI and quality or 2
            if quality >= 2 and quality <= 4 and D:CanDisenchant(itemID) then
                st.checked = st.checked + 1
                local okR, r = pcall(self.DEOffer, self, itemID, price, qty)
                if okR and r then
                    -- MR1-V: Wert hochgerechnet (ungemessene Gruppe) -> Hinweis grau; gemessene Gruppen ohne Hinweis
                    local okB, _, _, _, basis = pcall(D.DealValue, D, itemID)
                    if okB and basis == "hochgerechnet" then
                        r.coreNote = string.format(L["hochgerechnet aus %d eigenen Entzauberungen"], D.extraN or 0)
                    end
                    out[#out + 1] = r
                end
            end
        end
    end
    if MK and MK.EndBatch then MK:EndBatch() end
    -- E2: beste zuerst nach Gewinn pro Gold Einsatz; E4d: Budget (K1)
    table.sort(out, function(a, b) return a.pct > b.pct end)
    out = self:CapRows(out)
    self.deStats = st
    self.reason.de = self:DEEmptyText(st)
    return out
end

-- HP-3 (Nutzer 10:36): Grund einer leeren Entzauber-Liste je Lage - derselbe Text in Markt > Entzaubern und Kaufen > Schnäppchen
function MV:DEEmptyText(st)
    st = st or self.deStats or {}
    if A.WayOn and not A:WayOn("de") then
        return L["Der Weg Entzaubern ist abgewählt (Optionen) - darum keine Entzauber-Schnäppchen."]
    end
    if (st.fresh or 0) == 0 then
        return L["Keine Preise der letzten 2 Std. - zuerst im Auktionshaus scannen."]
    end
    local mins = st.newest and math.max(0, math.floor((time() - st.newest) / 60)) or 0
    return string.format(L["Zurzeit nichts unter dem Entzauber-Wert mit mindestens %d %% Gewinn (geprüft: %d Items, die du entzaubern kannst; Preise vom Scan vor %d Min.)."],
        self:DEMinPct(), st.checked or 0, mins)
end

-- E5: Detail eines Entzauber-Teils
function MV:DEDetailLines(itemID)
    local D = A.Disenchant
    local out = {}
    if not D then return out end
    local mats, basis = D:PerPartMats(itemID)
    for _, m in ipairs(mats or {}) do
        if #out >= 4 then break end
        local okP, p, _, _, _, _, _, x = pcall(D.MatPrice, D, m.id)
        local hint = okP and x and A:PriceHintText(x.hints)
        out[#out + 1] = string.format("%s: %s × %.2f · %s%s", A:GetItemName(m.id) or ("#" .. m.id), string.format("%.1f %%", (m.chance or 0) * 100),
            (m.per or 0) / math.max(0.01, m.chance or 1), okP and p and A:FormatMoney(p) or "-", hint and (" · " .. hint) or "")
    end
    local _, key = D:Prior(itemID)
    if key then
        local nOwn, nShared = D:Combined(key)
        out[#out + 1] = string.format(L["Eigene Ergebnisse der Gruppe: %d (geteilt %d) · %s"], nOwn or 0, nShared or 0,
            basis == "actual" and L["Chancen echt"] or L["Chancen aus der Tabelle"])
    end
    -- D3: Detail zeigt denselben Wert wie die Zeile (Wert mit der geplanten Menge)
    local cur = self.deCurrent
    local row = (cur and cur.itemID == itemID) and cur or nil
    if not row then
        for _, r in ipairs((self.cache.de and self.cache.de.rows) or {}) do if r.itemID == itemID then row = r; break end end
    end
    local net, nDE = row and row.net, row and row.n
    if not net then local _, _, n0 = D:PlannedValue(itemID, 1); net, nDE = D:PlannedValue(itemID, 1), n0 end
    if net then
        out[#out + 1] = string.format(L["Wert nach Entzaubern %s · lohnt bis %s (%d %% Gewinn)"], A:FormatMoney(net),
            A:FormatMoney(self:DEDetailLimit(net, nDE, itemID)), self:DEMinPct())
    end
    if row and row.noRise then out[#out + 1] = string.format(L["ohne Anstieg: %s"], A:FormatMoney(row.noRise)) end
    if row and row.buyout then out[#out + 1] = A:BuyoutText(row.buyout) or nil end
    return out
end

-- E2/E6: "Kaufen" legt ein Sniper-Ziel an (Max = lohnt bis, Menge, Budget) - kauft selbst nichts (nie ohne Klick)
function MV:BuyDE(r)
    if not (r and A.Sniper) then return false end
    -- D2: Budget = genau die geplanten Kosten (Summe über die Preisleiter), Höchstpreis = "lohnt bis"
    local budget = r.cost or (r.upto * r.qty)
    local ok, msg = A.Sniper:SetTarget(tostring(r.itemID), r.upto, r.qty, budget, { de = true })
    self.deCurrent = r
    if msg then A:Print(msg) end
    return ok
end
-- E6: Fusszeile nur für den aktuellen Kauf
function MV:DEFooter(r)
    if not r then return L["Zeile wählen – hier steht dann der aktuelle Kauf."] end
    local D = A.Disenchant
    local parts = {}
    for _, m in ipairs((D and D:PerPartMats(r.itemID)) or {}) do
        if #parts >= 2 then break end
        parts[#parts + 1] = string.format("≈ %d %s", math.floor(m.per * r.qty + 0.5), A:GetItemName(m.id) or ("#" .. m.id))
    end
    -- D1/D5a: dieselbe Menge, Kosten und Gewinn wie die Zeile (Summe über die Stufen der Preisleiter)
    return string.format(L["%d Stück · %s · erwarteter Gewinn %s · %s"], r.qty, A:FormatMoney(r.cost or (r.price * r.qty)),
        A:FormatMoney(r.profit or math.floor(r.unitGold * r.qty)), table.concat(parts, " · "))
end

A:On("CACHE_UPDATED", function(name)
    if name == "today:10" and MV.todayDone then local f = MV.todayDone; MV.todayDone = nil; pcall(f) end
end)
MV.BUILDERS = { lager = "BuildStock", flip = "BuildFlip", vendor = "BuildVendor", gaps = "BuildGaps", crowded = "BuildCrowded", trends = "BuildTrends", de = "BuildDE" }
MV.cache = {}

function MV:Version()
    return table.concat({ A:DataVersion(), math.floor(time() / 300), A.Seller and A.Seller.owned and #A.Seller.owned or 0 }, "|")
end

-- Zeilen einer Ansicht (aus dem Zwischenspeicher; sonst im Hintergrund rechnen, onDone ruft danach auf)
function MV:Rows(view, fresh, onDone)
    if view == "heute" then
        -- TB118-1 (Markt-Reiter 1083 ms): der Reiter rechnet nie selbst - ohne fertigen Stand im Hintergrund rechnen,
        -- danach neu zeichnen (CACHE_UPDATED "today:10")
        local list, capital, money, ready = A.Comfort:TodayActions(10, fresh, true)
        if not ready then MV.todayDone = onDone end
        return list or {}, not ready, capital, money
    end
    local ver = self:Version()
    local c = self.cache[view]
    if c and c.version == ver and not fresh then return c.rows, false end
    if not A:HasJob("market:" .. view) then
        A:Job("market:" .. view, function()
            local ok, rows = A:PCall(MV[MV.BUILDERS[view]], MV)
            if not ok and A.ReportOnce then A:ReportOnce("MarketView:" .. view, "MarketView", tostring(rows)) end
            rows = ok and rows or {}
            while #rows > MV.MAX_ROWS do table.remove(rows) end
            MV.cache[view] = { version = ver, rows = rows }
            if A.Core then pcall(A.Core.MarkRows, A.Core, view, rows) end         -- Ü3: unplausible Zeilen markieren
            if A.Core then pcall(A.Core.NoteRows, A.Core, view, rows) end         -- MA2: gezeigte Empfehlungen nachprüfen
            MV.coreHead = MV.coreHead or {}
            MV.coreHead[view] = nil
            if A.Core and A.Core.ApplyRelease then                                  -- FG: Freigaben (Teil D)
                local okF, r2, head = pcall(A.Core.ApplyRelease, A.Core, view, rows)
                if okF and r2 then rows, MV.coreHead[view] = r2, head; MV.cache[view].rows = rows end
            end
            if onDone then pcall(onDone) end
        end)
    end
    return c and c.rows or {}, true
end

-- ------------------------------------------------------------
-- M4 Lage: Preis-Index aus dem Korb (Median der Verhältnisse jetzt / vor 1 bzw. 7 Tagen)
-- ------------------------------------------------------------
local function PriceAt(itemID, t)
    local F, n = A:HF(itemID)
    for i = n, 1, -1 do
        local b = (i - 1) * 5
        if F[b + 1] <= t and F[b + 2] > 0 and F[b + 5] % 2 == 0 then return F[b + 2] end
    end
    return nil
end
function MV:Index(now)
    now = now or time()
    local r1, r7 = {}, {}
    for _, id in ipairs(self.BASKET) do
        local cur = A:GetCurrent(id)
        if cur and cur > 0 then
            local p1, p7 = PriceAt(id, now - 86400), PriceAt(id, now - 7 * 86400)
            if p1 then r1[#r1 + 1] = cur / p1 end
            if p7 then r7[#r7 + 1] = cur / p7 end
        end
    end
    local function med(t) if #t < 3 then return nil end table.sort(t); return t[math.floor((#t + 1) / 2)] end
    local d1, d7 = med(r1), med(r7)
    return d1 and (d1 - 1) * 100 or nil, d7 and (d7 - 1) * 100 or nil, #r1
end
function MV:IndexText()
    local d1, d7 = self:Index()
    if not d1 then return L["Markt heute: noch zu wenig Daten (Korb typischer Waren)"] end
    local s = string.format(L["Markt heute %+.0f %%"], d1)
    if d7 then s = s .. " " .. string.format(L["(7 Tage %+.0f %%)"], d7) end
    return s
end

-- ------------------------------------------------------------
-- M3 Detail: eine Empfehlung mit Begründung
-- ------------------------------------------------------------
function MV:Advice(itemID)
    local Se, Ln = A.Seller, A.Learn
    local have = Se and Se:CountInBags(itemID) or 0
    local price = A:GetCurrent(itemID)
    if have > 0 then
        local ok, v = pcall(A.SellOutlook, A, itemID, have)
        if ok and v and (v.rare or (v.wait and v.wait > A.RARE_DAYS)) then
            local vendor = A:GetVendorPrice(itemID)
            return "hold", L["liegen lassen"], string.format(L["%d im Angebot, Absatz zu klein - jede Rückkehr kostet die Einzahlung%s."], v.queue or 0,
                (type(vendor) == "number" and vendor > 0) and (" (" .. L["Händler"] .. " " .. A:FormatMoney(vendor) .. ")") or "")
        end
        local okS, p = pcall(Se.Suggest, Se, itemID)
        p = okS and p or A:RealPrice(itemID)
        if p then
            return "sell", string.format(L["einstellen für %s"], A:FormatMoney(p)),
                string.format(L["%d in der Tasche, verkauft sich ~%s/Tag"], have, (ok and v and v.perDay) and string.format("%.1f", v.perDay) or "?")
        end
    end
    local Fc = A.Forecast
    if Fc and price then
        local okP, way, ev = pcall(Fc.BuyPrediction, Fc, itemID)
        -- Flip (Wiederverkauf): dieselbe Prüfung wie Heute/Flippen (A:FlipCheck) - Liste und Detail nie widersprüchlich
        local okF, fok, fr = pcall(A.FlipCheck, A, itemID, price)
        if okF and fr and (fr.why == "crash" or fr.why == "flood") then
            return "hold", L["liegen lassen"], fr.why == "crash" and L["Preissturz - der Marktwert ist veraltet, kein Wiederverkauf"]
                or L["Angebot geflutet (3× so viel wie üblich) - kein Wiederverkauf"]
        end
        if okF and fok and fr then
            return "buy", string.format(L["kaufen bis %s"], A:FormatMoney(fr.limit)),
                string.format(L["Wiederverkauf realistisch %s (Angebot und Absatz), Gewinn ~%s für %d Stück"], A:FormatMoney(fr.resale),
                    A:FormatMoney(math.max(0, fr.profit)), fr.qty), fr
        end
        if okP and ev and (way == "e" or way == "v") and okF and fr and fr.limit then
            ev = nil                -- Flip/Händler: die Flip-Prüfung hat schon "nein" gesagt
            return "hold", L["liegen lassen"], string.format(L["Preis %s über deiner Kaufgrenze %s"], A:FormatMoney(price), A:FormatMoney(math.max(0, fr.limit)))
        end
        if okP and ev then
            local lim = (Ln and Ln.BuyLimit) and Ln:BuyLimit(ev, way) or ev
            if way == "d" then lim = MV:DELimitFor(itemID) or lim end       -- RK2-A: eine Rechnung "Lohnt bis"
            if lim and lim > 0 then
                if price <= lim then
                    return "buy", string.format(L["kaufen bis %s"], A:FormatMoney(lim)),
                        string.format(L["erwarteter Netto-Wert %s (%s), Sicherheitsmarge eingerechnet"], A:FormatMoney(ev),
                            ({ e = L["wieder einstellen"], d = L["entzaubern"], v = L["Händler"] })[way] or way)
                end
                return "hold", L["liegen lassen"], string.format(L["Preis %s über deiner Kaufgrenze %s"], A:FormatMoney(price), A:FormatMoney(lim))
            end
        end
    end
    return "hold", L["liegen lassen"], L["zu wenig Daten für eine Empfehlung"]
end

-- Zeilen des Detailbereichs (Text). Rückgabe Liste von Strings
function MV:DetailLines(itemID)
    local out = {}
    local price, qty, t = A:GetCurrent(itemID)
    local mv = A:GetMarketValue(itemID)
    out[#out + 1] = string.format(L["Preis %s · Marktwert %s · Menge %s"], price and A:FormatMoney(price) or "-", mv and A:FormatMoney(mv) or "-", qty and tostring(qty) or "-")
    local t7, t30 = A:GetTrend(itemID, 7 * 86400), A:GetTrend(itemID, 30 * 86400)
    if t7 or t30 then out[#out + 1] = string.format(L["Trend 7 Tage %s · 30 Tage %s"], t7 and string.format("%+d %%", math.floor(t7 + 0.5)) or "-", t30 and string.format("%+d %%", math.floor(t30 + 0.5)) or "-") end
    -- Preisleiter (Vollscan)
    local VS = A.FullScan
    local s = VS and VS:Ladder(itemID)
    if s and s.steps and #s.steps > 0 then
        local parts = {}
        for i = 1, math.min(4, #s.steps) do parts[#parts + 1] = A:FormatMoney(s.steps[i][1]) .. ": " .. s.steps[i][2] end
        out[#out + 1] = L["Preisleiter: "] .. table.concat(parts, " · ")
    end
    -- eigene Geschichte
    local Le = A.Ledger
    if Le then
        local sold = Le.SoldCount and Le:SoldCount(itemID, 30) or 0
        local okR, posts, sales = pcall(Le.PostRate, Le, itemID, 30)
        local buy = Le.AverageBuyPrice and Le:AverageBuyPrice(itemID, 30)
        out[#out + 1] = string.format(L["Du (30 Tage): %d verkauft%s%s"], sold or 0,
            (okR and posts and posts > 0) and (" · " .. string.format(L["Quote %d/%d"], sales or 0, posts)) or "",
            buy and (" · " .. string.format(L["Einkauf Ø %s"], A:FormatMoney(buy))) or "")
    end
    -- gelernte Grenzen
    local Ln = A.Learn
    if Ln and Ln.Limits then
        local ok, mn, normal, mx = pcall(Ln.Limits, Ln, itemID)
        if ok and normal then
            out[#out + 1] = string.format(L["Gelernt: Min %s · Normal %s · Max %s"], mn and A:FormatMoney(mn) or "-", A:FormatMoney(normal), A:FormatMoney(mx))
        end
    end
    local okO, v = pcall(A.SellOutlook, A, itemID, 1)
    if okO and v and v.queue then
        out[#out + 1] = string.format(L["Warteschlange %d · Absatz ~%s/Tag%s"], v.queue, v.perDay and string.format("%.1f", v.perDay) or "?",
            v.perDaySource == "measured" and (" (" .. L["gemessen"] .. ")") or "")
    end
    return out
end

-- ------------------------------------------------------------
-- Oberfläche
-- ------------------------------------------------------------
local SAFETY_COLOR = { hoch = "33dd55", mittel = "ffcc33", niedrig = "999999" }

local function BuildMarketView(parent)
    local p = CreateFrame("Frame", nil, parent)
    local T = A.Today
    p.view = MV:DefaultView()

    local head = UI:TabTitle(p, L["Markt"], "market")
    p.lage = UI:Label(p, "", "GameFontHighlightSmall", C.textDim)
    p.lage:SetPoint("LEFT", head, "RIGHT", 160, 0)

    -- M2: Suche (Nachschlagen) oben rechts
    p.search = UI:EditBox(p, 220, 24, L["Item suchen ..."])
    p.search:SetPoint("TOPRIGHT", 0, 2)
    UI:AttachItemSearch(p.search, {})
    local function Lookup()
        local text = UI:GetItemInput(p.search)
        local id = tonumber(text) or (A.FindItemByName and A:FindItemByName(text))
        if id then p:ShowDetail(id) end
    end
    p.search:SetScript("OnEnterPressed", function(self) self:ClearFocus(); Lookup() end)
    p.search:HookScript("OnTextChanged", function(self) if self.itemID then Lookup() end end)

    -- M1: Leiste mit 8 Ansichten (MR2: "Mein Lager" nach "Heute") (E1: "Entzaubern" nach "Trends")
    p.viewBtns = {}
    for i, v in ipairs(MV.VIEWS) do
        local b = UI:Button(p, L[MV.LABELS[v]], 92, 24, function() p:SetView(v) end)
        b.tooltip = L[MV.EXPLAIN[v]]
        b.view = v
        b.uiaView, b.uiaActive = L[MV.LABELS[v]], function() return p.view == v end   -- TB184-U3: Ansicht für die UI-Prüfung
        p.viewBtns[v] = b
    end
    p.refreshBtn = UI:Button(p, L["Aktualisieren"], 110, 24, function() p.fresh = true; p:Refresh() end)
    -- MR1-V: nur sichtbare Ansichten in der Leiste (Experten: alle)
    function p:LayoutViews()
        local prev
        for _, v in ipairs(MV.VIEWS) do
            local b = self.viewBtns[v]
            b:ClearAllPoints()
            if MV:Visible(v) then
                if prev then b:SetPoint("LEFT", prev, "RIGHT", 4, 0) else b:SetPoint("TOPLEFT", 0, -30) end
                b:Show()
                prev = b
            else
                b:Hide()
            end
        end
        self.refreshBtn:ClearAllPoints()
        self.refreshBtn:SetPoint("LEFT", prev, "RIGHT", 10, 0)
    end
    p:LayoutViews()
    p.explain = UI:Label(p, "", "GameFontDisableSmall", C.textDim)
    p.explain:SetPoint("TOPLEFT", 0, -60)
    p.explain:SetPoint("RIGHT", p, "RIGHT", -(MV.DETAIL_W + 10), 0)
    p.explain:SetJustifyH("LEFT")
    if p.explain.SetWordWrap then p.explain:SetWordWrap(false) end

    p.table = UI:Table(p, {
        columns = {
            { key = "gold", title = L["Zahl"], width = 86, align = "RIGHT" },
            { key = "text", title = L["Was tun"], width = 250 },
            { key = "state", title = L["Stand"], width = 120 },
        },
        flex = "text",
        action = {
            text = "", width = 140,
            label = function(r)
                if r.kind == "deoffer" then return L["Kaufen"], true end
                if r.kind == "stock" then return MV:StockLabel(r) end
                if T and r.kind and r.kind ~= "lookup" then
                    local lab, active = T:Label(r)
                    if lab then return lab, active end
                end
                if r.itemID then return L["Details"], true end
                return nil, false
            end,
            onClick = function(r)
                if r.kind == "stock" then MV:StockClick(r); return end
                if r.kind == "deoffer" then
                    MV:BuyDE(r)
                    p.deSel = r
                    p:Refresh()
                    return
                end
                if T and r.kind and r.kind ~= "lookup" and T:Label(r) then
                    T:Click(r)
                    local s = T:State(r)
                    if s.dirty then s.dirty = nil; p:Refresh() else p.table:Render() end
                elseif r.itemID then p:ShowDetail(r.itemID) end
            end,
        },
        rows = 14, rowHeight = 24, noMenu = true, itemTooltip = false, idKey = "text",
        sortKey = "order", sortAsc = true,
        cell = function(r, key)
            if key == "gold" then
                if r.pin then return "|cffffcc33" .. L["Auftrag"] .. "|r" end
                if r.tip then return "|cff888888" .. L["Tipp"] .. "|r" end
                local col = SAFETY_COLOR[r.safety or "hoch"] or "33dd55"
                if r.warn then col = "ff5544" end
                if r.stale then col = "888888" end
                return "|cff" .. col .. (r.num or A:FormatMoney(r.gold or 0)) .. "|r"
            end
            -- Ü3/FG: unplausibel bzw. "lernt noch" grau in der Spalte Stand
            if key == "state" and r.coreNote then return "|cff888888" .. r.coreNote .. "|r" end
            if key == "state" and r.kind == "stock" then return r.state or "" end
            if key == "state" then return (T and r.kind and r.kind ~= "lookup") and T:Info(r) or (r.where or "") end
            return r[key] or ""
        end,
        sortValue = function(r, key)
            if key == "order" then return r.order or 0 end
            if key == "gold" then return (r.pin and math.huge) or (r.tip and -1) or r.gold or r.sortGold or 0 end
            return tostring(r[key] or "")
        end,
        -- Klick: Detailbereich (Item) bzw. wie bisher in den Reiter (Zeilen ohne Item)
        onClick = function(r)
            -- Heute: wie bisher in den passenden Reiter (nichts geht verloren); andere Ansichten: Detailbereich
            if r.kind == "deoffer" then p.deSel = r; p:ShowDetail(r.itemID); p:Refresh(); return end
            if r.itemID and not (p.view == "heute" and r.run) then return p:ShowDetail(r.itemID) end
            -- F4: Detailbereich folgt auch in "Heute" der gewählten Zeile (danach wie bisher in den Reiter)
            if r.itemID then p:ShowDetail(r.itemID) end
            if r.kind == "vendorsell" then
                A:Print(L["Geh zu einem Händler - dort verkauft der Knopf rechts in dieser Zeile."])
                return
            end
            if not r.run then
                A:Print(L["Für diesen Tipp gibt es kein Fenster - der Knopf rechts führt ihn aus."])
                return
            end
            local ok, err = pcall(r.run)
            if not ok then
                if A.Diag then pcall(A.Diag.Add, A.Diag, "HEUTE-KLICK", "Fehler " .. tostring(r.kind) .. ": " .. tostring(err):sub(1, 120)) end
                A:Print(L["Das hat nicht geklappt: "] .. tostring(err):sub(1, 120))
            end
        end,
        onHover = function(r)
            GameTooltip:SetOwner(UIParent, "ANCHOR_CURSOR")
            GameTooltip:SetText(r.text or "", 1, 1, 1, 1, true)
            if r.help then GameTooltip:AddLine(r.help, 0.8, 0.8, 0.8, true) end         -- MH-1: was die Zahl ist (ein Satz)
            if r.safety then GameTooltip:AddLine(L["Sicherheit: "] .. L[r.safety], 0.6, 0.6, 0.6) end
            GameTooltip:AddLine(L["Knopf rechts: nächster Schritt direkt hier. Klick auf die Zeile: Details rechts."], 0.6, 0.6, 0.6, true)
            GameTooltip:Show()
        end,
        emptyText = L["Gerade nichts in dieser Ansicht. Nach dem nächsten Scan (und mit offenem Auktionshaus) wieder hineinschauen."],
    })
    p.table:Fill(0, -78, -(MV.DETAIL_W + 10), 24)
    p.info = UI:Label(p, "", "GameFontDisableSmall", C.textDim)
    p.info:SetPoint("BOTTOMLEFT", 0, 4)
    p.info:SetPoint("RIGHT", p, "RIGHT", -(MV.DETAIL_W + 10), 0)
    p.info:SetJustifyH("LEFT")
    if p.info.SetWordWrap then p.info:SetWordWrap(false) end

    -- M3: Detailbereich rechts
    local d = CreateFrame("Frame", nil, p)
    UI:Box(d, C.panel, C.border)
    d:SetPoint("TOPRIGHT", 0, -78)
    d:SetPoint("BOTTOMRIGHT", 0, 4)
    d:SetWidth(MV.DETAIL_W)
    p.detail = d
    d.title = UI:Label(d, L["Details"], "GameFontNormal", C.heading)
    d.title:SetPoint("TOPLEFT", 8, -8)
    d.title:SetPoint("RIGHT", d, "RIGHT", -8, 0)
    if d.title.SetWordWrap then d.title:SetWordWrap(false) end
    -- Preis- und Angebotsverlauf übereinander (je 30 Balken, letzte 14 Tage)
    d.bars = { price = {}, qty = {} }
    local BAR_N, BAR_W, BAR_H = 30, 8, 34
    for k, key in ipairs({ "price", "qty" }) do
        local base = -30 - (k - 1) * (BAR_H + 8)
        for i = 1, BAR_N do
            local tex = d:CreateTexture(nil, "ARTWORK")
            tex:SetColorTexture(key == "price" and 0.2 or 0.4, key == "price" and 0.8 or 0.6, key == "price" and 0.8 or 1, 0.8)
            tex:SetSize(BAR_W - 1, 1)
            tex:SetPoint("BOTTOMLEFT", d, "TOPLEFT", 8 + (i - 1) * BAR_W, base - BAR_H)
            d.bars[key][i] = tex
        end
    end
    d.barLabel = UI:Label(d, L["Preis (oben) und Angebot (unten), 14 Tage"], "GameFontDisableSmall", C.textDim)
    d.barLabel:SetPoint("TOPLEFT", 8, -30 - 2 * (BAR_H + 8))
    d.lines = {}
    for i = 1, 7 do
        local fs = UI:Label(d, "", "GameFontHighlightSmall", C.text)
        fs:SetPoint("TOPLEFT", 8, -30 - 2 * (BAR_H + 8) - 6 - i * 16)
        fs:SetPoint("RIGHT", d, "RIGHT", -8, 0)
        if fs.SetWordWrap then fs:SetWordWrap(false) end
        d.lines[i] = fs
    end
    d.advice = UI:Label(d, "", "GameFontNormal", C.green)
    d.advice:SetPoint("TOPLEFT", d.lines[#d.lines], "BOTTOMLEFT", 0, -10)
    d.reason = UI:Label(d, "", "GameFontHighlightSmall", C.textDim)
    d.reason:SetPoint("TOPLEFT", d.advice, "BOTTOMLEFT", 0, -4)
    d.reason:SetPoint("RIGHT", d, "RIGHT", -8, 0)
    d.watchBtn = UI:Button(d, L["Watchlist"], 92, 22, function()
        if d.itemID and A.Watchlist then local _, msg = A.Watchlist:Add(tostring(d.itemID)); A:Print(msg) end
    end)
    d.watchBtn:SetPoint("BOTTOMLEFT", 8, 8)
    d.listBtn = UI:Button(d, L["Einkaufsliste"], 92, 22, function()
        if not (d.itemID and A.Lists) then return end
        local names = A.Lists:GetNames()
        local name = names[1]
        if not name then local _, _, created = A.Lists:Create(L["Markt"]); name = created end
        if name then local _, msg = A.Lists:AddItem(name, tostring(d.itemID), 1); A:Print(msg) end
    end)
    d.listBtn:SetPoint("LEFT", d.watchBtn, "RIGHT", 4, 0)
    d.sniperBtn = UI:Button(d, L["Sniper"], 92, 22, function()
        if not (d.itemID and A.Sniper) then return end
        local _, _, lim = MV:LimitFor(d.itemID)
        local ok, msg = A.Sniper:SetTarget(tostring(d.itemID), lim or A:GetMarketValue(d.itemID) or 1, 20, nil)
        A:Print(msg or (ok and L["Sniper-Ziel angelegt."] or ""))
    end)
    d.sniperBtn:SetPoint("LEFT", d.listBtn, "RIGHT", 4, 0)
    d.sniperBtn.tooltip = L["Sniper-Ziel mit der vorgeschlagenen Kaufgrenze anlegen."]
    d.chartBtn = UI:Button(d, L["Preisverlauf"], 284, 22, function() if d.itemID then UI:OpenChart(d.itemID) end end)
    d.chartBtn:SetPoint("BOTTOMLEFT", d.watchBtn, "TOPLEFT", 0, 4)

    function p:ClearDetail()
        d.itemID, d.kind = nil, nil
        d.title:SetText(L["Details"])
        for _, fs in ipairs(d.lines) do fs:SetText("") end
        d.advice:SetText(""); d.reason:SetText("")
        for i = 1, BAR_N do d.bars.price[i]:SetHeight(1); d.bars.qty[i]:SetHeight(1) end
    end

    function p:ShowDetail(itemID)
        d.itemID = itemID
        d.title:SetText(A:GetItemName(itemID) or ("#" .. itemID))
        -- Verlauf: 30 Zeitfenster über 14 Tage
        local F, nF = A:HF(itemID)
        local now = time()
        local from = now - 14 * 86400
        local slotP, slotQ = {}, {}
        for k = 1, nF do
            local b = (k - 1) * 5
            local et, ep = F[b + 1], F[b + 2]
            if et >= from and ep > 0 and F[b + 5] % 2 == 0 then
                local i = math.min(BAR_N, math.floor((et - from) / (14 * 86400) * BAR_N) + 1)
                slotP[i] = math.min(slotP[i] or math.huge, ep)
                slotQ[i] = math.max(slotQ[i] or 0, A.HQ(F, k) or 0)
            end
        end
        local maxP, maxQ = 0, 0
        for i = 1, BAR_N do maxP = math.max(maxP, slotP[i] or 0); maxQ = math.max(maxQ, slotQ[i] or 0) end
        for i = 1, BAR_N do
            d.bars.price[i]:SetHeight(maxP > 0 and math.max(1, (slotP[i] or 0) / maxP * BAR_H) or 1)
            d.bars.qty[i]:SetHeight(maxQ > 0 and math.max(1, (slotQ[i] or 0) / maxQ * BAR_H) or 1)
        end
        local lines = (p.view == "de") and MV:DEDetailLines(itemID) or MV:DetailLines(itemID)
        for i, fs in ipairs(d.lines) do fs:SetText(lines[i] or "") end
        local kind, advice, reason = MV:Advice(itemID)
        d.advice:SetText(advice or "")
        d.advice:SetTextColor(unpack((kind == "hold") and C.yellow or C.green))
        d.reason:SetText(reason or "")
        d.kind = kind
    end

    function p:SetView(v)
        if not MV:Visible(v) then v = "heute" end                 -- MR1-V: ausgeblendete Ansicht -> Heute
        -- H7: Detailbereich beim Ansichtswechsel leeren - danach zeigt er die erste Zeile der neuen Ansicht
        if self.view ~= v then self:ClearDetail(); self.deSel = nil end
        self.view = v
        self.fresh = nil
        self:Refresh()
    end

    function p:Refresh()
        if self.expertShown ~= MV:Expert() then self.expertShown = MV:Expert(); self:LayoutViews() end
        for v, b in pairs(self.viewBtns) do
            b.label:SetTextColor(unpack(v == self.view and C.accent or C.text))
        end
        local ch = MV.coreHead and MV.coreHead[self.view]
        self.explain:SetText((ch and ("|cffffcc33" .. ch .. "|r  ") or "") .. ((not MV:Expert()) and (MV.HelpTop() .. " ") or "") .. L[MV.EXPLAIN[self.view]])          -- FG: Kopf-Hinweis; MR1-V Satz
        self.lage:SetText(MV:IndexText())
        local view = self.view
        local userFresh = self.fresh
        local list, busy, capital, money = MV:Rows(view, self.fresh, function()
            if p:IsVisible() and p.view == view then p:Refresh() end
        end)
        self.fresh = nil
        local rows = {}
        for i, r in ipairs(list or {}) do
            if i > MV.MAX_ROWS and not r.pin then break end
            r.order = i
            rows[#rows + 1] = r
        end
        self.list = rows
        -- Zustände alter Zeilen nur beim Knopf "Aktualisieren" vergessen (sonst verlöre eine laufende Zeile ihren Schritt)
        if view == "heute" and userFresh and T and T.Prune then T:Prune(rows) end
        self.table:SetData(rows, true)
        -- H6: leere Ansicht nennt den Grund
        if self.table.empty then
            local why = (not busy and #rows == 0 and view ~= "heute") and MV.reason[view] or nil
            self.table.empty:SetText(why or L["Gerade nichts in dieser Ansicht. Nach dem nächsten Scan (und mit offenem Auktionshaus) wieder hineinschauen."])
        end
        local txt
        if busy then txt = L["Wird berechnet ..."]
        elseif view == "heute" then
            local sum = 0
            for _, r in ipairs(rows) do sum = sum + (r.gold or 0) end
            txt = string.format(L["%d Vorschläge, zusammen ca. %s"], #rows, A:FormatMoney(sum))
                .. "   |   " .. string.format(L["Kapitalbedarf: %s von %s (höchstens %d %%)"], A:FormatMoney(capital or 0), A:FormatMoney(money or 0), A:MarketCapitalPct())
        elseif view == "de" then
            -- E6 (Entscheid 16:17): nur der aktuelle Kauf (gewählte Zeile bzw. Sniper-Ziel aus dieser Ansicht), keine Summe
            txt = MV:DEFooter(self.deSel)
        else
            txt = string.format(L["%d Zeilen"], #rows)
        end
        if not A:IsAHOpen() then txt = txt .. "   |   |cffffcc33" .. L["Auktionshaus öffnen, um Käufe direkt auszuführen"] .. "|r" end
        self.info:SetText(txt)
        if not d.itemID and rows[1] and rows[1].itemID then self:ShowDetail(rows[1].itemID) end
    end

    -- Antworten vom Server abholen (Angebote geladen, Preis reserviert, eingestellt ...) - wie "Heute tun"
    local acc = 0
    p:SetScript("OnUpdate", function(self, dt)
        acc = acc + (dt or 0)
        if acc < 0.4 then return end
        acc = 0
        if not (T and self.list) then return end
        for _, r in ipairs(self.list) do if r.kind and r.kind ~= "lookup" then T:Update(r) end end
        self.table:Render()
    end)
    p:HookScript("OnShow", function(self) self:Refresh() end)
    -- für ältere Aufrufe (UI:ShowToday, Tests): Tabelle und Refresh wie das alte Fenster
    UI.marketView = p
    return p
end

-- Kaufgrenze für den Sniper-Knopf: erwarteter Netto-Wert × (1 − Marge)
function MV:LimitFor(itemID)
    local Fc, Ln = A.Forecast, A.Learn
    if not Fc then return nil end
    local ok, way, ev = pcall(Fc.BuyPrediction, Fc, itemID)
    if not (ok and ev) then return nil end
    if way == "d" then return way, ev, self:DELimitFor(itemID) or ev end     -- RK2-A
    return way, ev, (Ln and Ln.BuyLimit) and Ln:BuyLimit(ev, way) or ev
end
-- RK2-A: Kaufgrenze für Entzaubern = "Lohnt bis" aus A.Core (wie Tooltip, Einkauf, Sammelkauf, Sniper, API)
function MV:DELimitFor(itemID)
    local MK = A.Core
    if not (MK and MK.DELimit) then return nil end
    local lim = MK:DELimit(itemID)
    return lim
end

UI:RegisterTab("marketview", "Markt", 2, BuildMarketView)

-- Teil B der Testroutine: Zeilen je Ansicht (echte Daten, nur lesen) und Index
function MV:Report()
    local out, fields = { "Markt-Reiter (echte Daten):" }, {}
    local parts = {}
    for _, v in ipairs(self.VIEWS) do
        local n
        if v == "heute" then
            local ok, list = pcall(A.Comfort.TodayActions, A.Comfort, 10)
            n = ok and list and #list or nil
        else
            local ok, rows = pcall(self[self.BUILDERS[v]], self)
            n = ok and rows and math.min(#rows, self.MAX_ROWS) or nil
        end
        parts[#parts + 1] = string.format("%s %s", L[self.LABELS[v]], n and tostring(n) or "Fehler")
    end
    out[#out + 1] = "  Zeilen je Ansicht: " .. table.concat(parts, " · ")
    local d1, d7, n = self:Index()
    out[#out + 1] = string.format("  Index: heute %s · 7 Tage %s (%d Waren im Korb)", d1 and string.format("%+.1f %%", d1) or "-", d7 and string.format("%+.1f %%", d7) or "-", n or 0)
    fields.markt_zeilen = table.concat(parts, " | ")
    fields.markt_index = d1 and string.format("%+.1f/%s", d1, d7 and string.format("%+.1f", d7) or "-") or "-"
    return out, fields
end

-- ------------------------------------------------------------
-- "Heute tun" öffnet jetzt den Markt-Reiter, Ansicht "Heute" (/ahs heute, Übersicht, QuickBuy/QuickSell)
-- ------------------------------------------------------------
function UI:ShowToday()
    if GameTooltip and GameTooltip.Hide then GameTooltip:Hide() end
    if self.Show then pcall(self.Show, self) end
    self:SelectTab("marketview")
    local tab = self:GetTab("marketview")
    local p = tab and tab.panel
    if not p then return nil end
    if p.view ~= "heute" then p.view = "heute" end
    p:Show()
    p:Refresh()
    self.todayWin = p
    return p
end

-- D5b: nachgeladene Item-Daten -> "Stufe ?" in den Entzauber-Zeilen ersetzen und neu zeichnen
A:On("ITEMINFO_LOADED", function()
    local c = MV.cache and MV.cache.de
    local changed = false
    for _, r in ipairs(c and c.rows or {}) do
        if not r.ilvl and r.retext then
            local _, l = MV:ItemInfo(r.itemID)
            if l then r.text = r.retext(); changed = true end
        end
    end
    if changed then A:Fire("CACHE_UPDATED", "market:de") end
end)
