local _, ns = ...

-- Detects which game version is running and sets ns.Flavor:
--   "forever" = WoW Forever (interface 16000-19999, project WOW_PROJECT_CAMELOT)
--   "era"     = Classic Era / Hardcore (interface 11400-11599)
--   "retail"  = Retail (interface 100000+, e.g. 120105 = 12.1.5 Midnight; project WOW_PROJECT_MAINLINE)
--   nil       = not supported (TBC, Wrath, Cata, MoP Classic: the addon stays idle and says so once)
-- The detection itself lives in GoldSentinelGame.lua, shared by all GoldSentinel addons.
-- Only the matching data file (Data_Forever.lua / Data_Era.lua / Data_Retail.lua) loads its tables.

local G = _G.GoldSentinelGame

ns.ClientVersion = G.gameVersion
ns.ClientBuild = G.build
ns.Interface = G.interface

local SUPPORTED = { forever = true, era = true, retail = true }
local flavor = SUPPORTED[G.flavor or ""] and G.flavor or nil

ns.Flavor = flavor
ns.GameFlavor = G.flavor          -- also unsupported ones ("tbc", "wrath", ...) for the message
ns.IsForever = flavor == "forever"
ns.IsEra = flavor == "era"
ns.IsRetail = flavor == "retail"

-- Which profession window the client uses: Forever runs on the modern client like Retail
ns.UsesModernProfessions = ns.IsForever or ns.IsRetail

-- Retail has no QuestieDB data: no vendor/drop/quest sources, no trainer locations
ns.HasSourceData = not ns.IsRetail
