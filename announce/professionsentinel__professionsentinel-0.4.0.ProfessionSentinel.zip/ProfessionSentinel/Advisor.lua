local _, ns = ...
local L = ns.L

-- Ranking of recipes for levelling ("Rangliste"):
-- every recipe that gives skill points at your current skill – learned AND not yet learned –
-- sorted by MATERIAL PER SKILL POINT (lower = better):
--
--   material per point = reagents per craft / (skill-up chance × points per craft)
--
-- chance: orange 100 %, from yellow on it falls linearly to 0 % at grey (Classic rule);
-- grey recipes and recipes whose required skill you have not reached are left out.
-- Ties: learned before not learned, higher chance, craftable from your bags, more often craftable, name.
-- All reagents count the same (no prices yet).

local AD = {}
ns.Advisor = AD

AD.STAR = "|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1:0|t"

-- How often a recipe can be crafted from the bags (nil = no reagents known)
function AD.CraftableCount(r, countFn)
    countFn = countFn or function(id)
        if C_Item and C_Item.GetItemCount then return C_Item.GetItemCount(id, false) or 0 end
        if GetItemCount then return GetItemCount(id, false) or 0 end
        return 0
    end
    if not r.reagents or #r.reagents == 0 then return nil end
    local n = math.huge
    for i = 1, #r.reagents, 2 do
        local id, need = r.reagents[i], r.reagents[i + 1]
        if need and need > 0 then n = math.min(n, math.floor((countFn(id) or 0) / need)) end
    end
    return n == math.huge and nil or n
end

function AD.TotalReagents(r)
    local t = 0
    for i = 2, #(r.reagents or {}), 2 do t = t + (r.reagents[i] or 0) end
    return t
end

-- Evaluates one recipe for the given skill. Returns nil when it gives no points or cannot be crafted yet.
function AD.Evaluate(r, rank, countFn)
    if not r or not rank or (r.yellow or 0) <= 0 then return nil end
    -- learn level: known, or estimated by the data pipeline (many trainer recipes have none in the client)
    local need = ((r.req or 0) > 1 and r.req) or r.learnLevel or 0
    if need > 1 and rank < need then return nil end
    local p = ns.Lifeline.Chance(r, rank)
    if p <= 0 then return nil end
    local mats = AD.TotalReagents(r)
    if mats <= 0 then return nil end
    local points = p * (r.skillUps or 1)
    return {
        recipe = r,
        chance = p,
        points = points,
        mats = mats,
        perPoint = mats / points,
        craftable = AD.CraftableCount(r, countFn),
        orangeLeft = math.max(0, (r.yellow or 0) - rank),
        pointsLeft = math.max(0, (r.grey or 0) - rank),
    }
end

-- Source priority (for not learned recipes): trainer > friendly vendor > any vendor > drop/quest/chest
function AD.SourceScore(r)
    local S = ns.SRC
    if bit.band(r.src, S.TRAINER) ~= 0 or bit.band(r.src, S.AUTO) ~= 0 then return 4 end
    if bit.band(r.src, S.VENDOR) ~= 0 then
        local WP = ns.Waypoint
        if WP then
            for _, ri in ipairs(r.recipeItems or {}) do
                for _, id in ipairs(ri.v or {}) do
                    if WP.IsFriendly(id) then return 3 end
                end
            end
        end
        return 2
    end
    if bit.band(r.src, S.DROP + S.WORLDDROP + S.QUEST + S.CONTAINER) ~= 0 then return 1 end
    return 0
end

local function Better(a, b)
    -- 1. material per point (rounded to 0.01)
    local ma, mb = math.floor(a.perPoint * 100 + 0.5), math.floor(b.perPoint * 100 + 0.5)
    if ma ~= mb then return ma < mb end
    -- 2. learned first
    if a.learned ~= b.learned then return a.learned end
    -- 3. higher chance
    if a.chance ~= b.chance then return a.chance > b.chance end
    -- 4. craftable from bags
    local ca, cb = (a.craftable or 0) > 0, (b.craftable or 0) > 0
    if ca ~= cb then return ca end
    if (a.craftable or 0) ~= (b.craftable or 0) then return (a.craftable or 0) > (b.craftable or 0) end
    -- 5. not learned: better source
    if (a.source or 0) ~= (b.source or 0) then return (a.source or 0) > (b.source or 0) end
    return (a.recipe.name or "") < (b.recipe.name or "")
end
AD.Better = Better

-- Full ranking. learnedFn(r) -> bool, countFn(itemID) -> number (both optional, for tests)
function AD.Ranking(recipes, rank, learnedFn, countFn)
    learnedFn = learnedFn or ns.IsLearned
    local out = {}
    for _, r in ipairs(recipes or {}) do
        local e = AD.Evaluate(r, rank, countFn)
        if e then
            e.learned = learnedFn(r) and true or false
            if not e.learned then e.source = AD.SourceScore(r) end
            out[#out + 1] = e
        end
    end
    table.sort(out, Better)
    for i, e in ipairs(out) do e.place = i end
    return out
end

---------------------------------------------------------------------------
-- Cache for the open profession (panel, Blizzard list star, hint on the profession window)
---------------------------------------------------------------------------
AD.current = { prof = nil, rank = nil, ranking = {}, best = nil, bestLearned = nil }

function AD.Update(prof, rank)
    local c = AD.current
    c.prof, c.rank = prof, rank
    c.ranking, c.best, c.bestLearned = {}, nil, nil
    if not prof or not rank or not ns.ByProf[prof] then return c end
    c.ranking = AD.Ranking(ns.ByProf[prof], rank)
    c.best = c.ranking[1]
    for _, e in ipairs(c.ranking) do
        if e.learned then c.bestLearned = e; break end
    end
    return c
end

-- The star marks the best LEARNED recipe (the Blizzard list only shows learned ones)
function AD.IsBest(spell)
    local b = AD.current.bestLearned
    return b and b.recipe.spell == spell or false
end

function AD.Entry(r)
    for _, e in ipairs(AD.current.ranking or {}) do
        if e.recipe == r then return e end
    end
end

-- "2,0 Mat./Pkt · 100 % · 12× aus Taschen"
function AD.Reason(e, short)
    if not e then return "" end
    local per = string.format("%.1f", e.perPoint)
    if ns.isGerman then per = per:gsub("%.", ",") end
    local parts = { string.format(L.RANK_PER_POINT, per) }
    if not short then
        parts[#parts + 1] = string.format("%d %%", math.floor(e.chance * 100 + 0.5))
        if e.learned then
            if e.craftable and e.craftable > 0 then
                parts[#parts + 1] = string.format(L.BEST_CRAFTABLE, e.craftable)
            elseif e.craftable == 0 then
                parts[#parts + 1] = L.BEST_NO_MATS
            end
        end
    end
    return table.concat(parts, " · ")
end
