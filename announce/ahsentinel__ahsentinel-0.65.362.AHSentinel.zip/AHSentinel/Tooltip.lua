if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.8 - Preise und Preisverlauf im Item-Tooltip
--
-- Überall, wo WoW einen Item-Tooltip zeigt (Taschen, Auktionshaus,
-- Chat-Links, Listen anderer Addons, unsere eigenen Tabellen):
--   * zusätzliche Zeilen: aktueller Preis (mit % vom Marktwert),
--     Marktwert (Median 14 Tage), Trend 24 Std., Händlerpreis
--   * ein kleines Preisdiagramm direkt unter dem Tooltip
-- Beides lässt sich in den Optionen ein- und ausschalten.
-- Fehler in diesem Modul dürfen den Tooltip nie kaputt machen (pcall).
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local CreateFrame, C_Timer = A.OwnCreateFrame or CreateFrame, A.OwnTimer or C_Timer      -- VS-BILD-2 (0.65.320): eigene Skripte/Zeitgeber je Bild messen (nur während einer Vollscan-Messung)
local L = A.L

local TT = {}
A.Tooltip = TT

local CW, CH = 240, 92                  -- Größe des Diagramms
local PAD_L, PAD_R, PAD_T, PAD_B = 6, 6, 20, 16

-- wählbare Zeiträume für das Diagramm (0 = aus)
TT.PERIODS = { 0, 1, 7, 30 }
local PERIOD_LABEL = { [1] = "24 Std.", [7] = "7 Tage", [30] = "30 Tage" }

function TT:Settings()
    local s = A.db and A.db.settings
    return s
end

function TT:ChartDays()
    local s = self:Settings()
    if not s then return 0 end
    local d = s.tooltipChartDays
    if d == nil then d = 7 end
    return d
end

function TT:PeriodLabel(days)
    days = days or self:ChartDays()
    if days == 0 then return L["aus"] end
    return L[PERIOD_LABEL[days] or "7 Tage"]
end

function TT:CycleChartDays()
    local s = self:Settings()
    if not s then return end
    local cur, i = self:ChartDays(), 1
    for k, d in ipairs(self.PERIODS) do if d == cur then i = k end end
    i = (i % #self.PERIODS) + 1
    s.tooltipChartDays = self.PERIODS[i]
    return s.tooltipChartDays
end

-- ------------------------------------------------------------
-- Diagramm-Fenster (wird einmal gebaut und wiederverwendet)
-- ------------------------------------------------------------
local chart

local function GetChart()
    if chart then return chart end
    local UI, C = A.UI, A.UI.C
    local f = CreateFrame("Frame", "AHAnalyzerProTooltipChart", UIParent)
    f:SetSize(CW, CH)
    f:SetFrameStrata("TOOLTIP")
    f:SetClampedToScreen(true)
    f:EnableMouse(false)
    UI:Box(f, { 0.03, 0.03, 0.05, 0.92 }, C.border)
    f:Hide()

    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    f.title:SetPoint("TOPLEFT", 6, -5)
    f.title:SetJustifyH("LEFT")
    f.high = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.high:SetPoint("TOPRIGHT", -6, -5)
    f.high:SetJustifyH("RIGHT")
    f.low = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.low:SetPoint("BOTTOMRIGHT", -6, 3)
    f.low:SetJustifyH("RIGHT")
    f.from = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    f.from:SetPoint("BOTTOMLEFT", 6, 3)
    f.from:SetJustifyH("LEFT")

    f.lines, f.dots, f.used = {}, {}, { lines = 0, dots = 0 }
    f.canRotate = true

    function f:Clear()
        for _, t in ipairs(self.lines) do t:Hide() end
        for _, t in ipairs(self.dots) do t:Hide() end
        self.used.lines, self.used.dots = 0, 0
        if self.avg then self.avg:Hide() end
    end

    function f:Dot(x, y, size, r, g, b, a)
        self.used.dots = self.used.dots + 1
        local t = self.dots[self.used.dots]
        if not t then
            t = self:CreateTexture(nil, "OVERLAY")
            self.dots[self.used.dots] = t
        end
        t:SetColorTexture(r, g, b, a or 1)
        t:SetSize(size, size)
        t:ClearAllPoints()
        t:SetPoint("CENTER", self, "BOTTOMLEFT", x, y)
        t:Show()
    end

    function f:Line(x1, y1, x2, y2, r, g, b)
        local dx, dy = x2 - x1, y2 - y1
        local len = math.sqrt(dx * dx + dy * dy)
        if len < 0.5 then return end
        if self.canRotate then
            self.used.lines = self.used.lines + 1
            local t = self.lines[self.used.lines]
            if not t then
                t = self:CreateTexture(nil, "ARTWORK")
                self.lines[self.used.lines] = t
            end
            t:SetColorTexture(r, g, b, 0.95)
            t:ClearAllPoints()
            t:SetSize(len, 2)
            t:SetPoint("CENTER", self, "BOTTOMLEFT", (x1 + x2) / 2, (y1 + y2) / 2)
            local ok = t.SetRotation and pcall(t.SetRotation, t, math.atan2(dy, dx))
            if ok then
                t:Show()
                return
            end
            t:Hide()
            self.canRotate = false
        end
        -- Rückfall ohne Drehen: Linie aus kleinen Punkten
        local steps = math.min(40, math.max(2, math.floor(len / 2)))
        for i = 0, steps do
            self:Dot(x1 + dx * i / steps, y1 + dy * i / steps, 2, r, g, b, 0.95)
        end
    end

    chart = f
    return f
end

-- Preispunkte des Zeitraums
local function Points(itemID, days)
    local out = {}
    local limit = time() - days * 86400
    local F, n = A:HF(itemID)                       -- RF-M1: nur die Einträge im Zeitraum als Tabellen
    for i = 1, n do
        local b = (i - 1) * 5
        if F[b + 1] >= limit and F[b + 2] > 0 and F[b + 5] % 2 == 0 then out[#out + 1] = A.HistFlatRow(F, i) end   -- ohne unbestätigte (Lockangebote)
    end
    return out
end

function TT:HideChart(owner)
    if chart and (owner == nil or chart.owner == owner) then
        chart:Hide()
        chart.owner = nil
    end
end

function TT:ShowChart(tooltip, itemID)
    local days = self:ChartDays()
    if days == 0 then return self:HideChart() end
    local points = Points(itemID, days)
    if #points < 2 then return self:HideChart() end

    local f = GetChart()
    local C = A.UI.C
    local w = CW
    local tw = tooltip.GetWidth and tooltip:GetWidth()
    if tw and tw > w then w = tw end
    -- N3 (Tempo): gleiches Item, gleiche Daten, gleiche Breite -> nicht neu zeichnen, nur anhängen
    local drawKey = table.concat({ itemID, days, math.floor(w), A:DataVersion(), #points, points[#points].t }, "|")
    if f.drawKey == drawKey then
        f:ClearAllPoints()
        local bottom0 = tooltip.GetBottom and tooltip:GetBottom()
        if bottom0 and bottom0 < CH + 10 then f:SetPoint("BOTTOMLEFT", tooltip, "TOPLEFT", 0, 2)
        else f:SetPoint("TOPLEFT", tooltip, "BOTTOMLEFT", 0, -2) end
        f.owner = tooltip
        f:Show()
        return
    end
    f.drawKey = drawKey
    f:Clear()
    f:SetWidth(w)

    local minP, maxP = points[1].p, points[1].p
    for _, e in ipairs(points) do
        if e.p < minP then minP = e.p end
        if e.p > maxP then maxP = e.p end
    end
    local lo, hi = minP, maxP
    if hi == lo then lo, hi = lo * 0.9, hi * 1.1 + 1 end
    local minT, maxT = points[1].t, points[#points].t
    if maxT == minT then maxT = minT + 1 end

    local plotW, plotH = w - PAD_L - PAD_R, CH - PAD_T - PAD_B
    local function X(t) return PAD_L + (t - minT) / (maxT - minT) * plotW end
    local function Y(p) return PAD_B + (p - lo) / (hi - lo) * plotH end

    -- Linie beim Marktwert (Median der gezeigten Preise)
    local values = {}
    for i, e in ipairs(points) do values[i] = e.p end
    local avg = A.Median(values)
    if not f.avg then f.avg = f:CreateTexture(nil, "BORDER") end
    f.avg:SetColorTexture(1, 0.8, 0.2, 0.35)
    f.avg:ClearAllPoints()
    f.avg:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", PAD_L, Y(avg))
    f.avg:SetSize(plotW, 1)
    f.avg:Show()

    -- Steigt der Preis -> grün, fällt er -> rot, sonst Akzentfarbe
    local first, last = points[1].p, points[#points].p
    local col = C.accent
    if last > first * 1.02 then col = C.green elseif last < first * 0.98 then col = C.red end

    local px, py
    for _, e in ipairs(points) do
        local x, y = X(e.t), Y(e.p)
        if px then f:Line(px, py, x, y, col[1], col[2], col[3]) end
        px, py = x, y
    end
    f:Dot(px, py, 5, 1, 1, 1, 1)          -- aktueller Preis

    f.title:SetText("|cff00d1d1AHSentinel|r  " .. string.format(L["Preisverlauf (%s)"], self:PeriodLabel(days)))
    f.high:SetText(A:FormatMoney(maxP, true))
    f.low:SetText(A:FormatMoney(minP, true))
    f.from:SetText(date("%d.%m.", minT) .. "  -  " .. date("%d.%m.", maxT))

    -- unter den Tooltip, oder darüber, wenn unten kein Platz ist
    f:ClearAllPoints()
    local bottom = tooltip.GetBottom and tooltip:GetBottom()
    if bottom and bottom < CH + 10 then
        f:SetPoint("BOTTOMLEFT", tooltip, "TOPLEFT", 0, 2)
    else
        f:SetPoint("TOPLEFT", tooltip, "BOTTOMLEFT", 0, -2)
    end
    f.owner = tooltip
    f:Show()
end

-- ------------------------------------------------------------
-- Zusätzliche Zeilen im Tooltip
-- ------------------------------------------------------------
function TT:AddLines(tooltip, itemID)
    local bound = self.boundTip                                                   -- S3: gilt nur für diesen einen Tooltip
    self.boundTip = nil
    local s = self:Settings()
    local showInfo = not (s and s.tooltipInfo == false)
    local vendor = (not s or s.tooltipVendor ~= false) and A:GetVendorPrice(itemID) or nil
    -- beim Händler zeigt WoW den Verkaufspreis selbst an
    if vendor and type(MerchantFrame) == "table" and MerchantFrame.IsShown and MerchantFrame:IsShown() then vendor = nil end
    if vendor and vendor <= 0 then vendor = nil end
    if not showInfo and not vendor then return end
    tooltip:AddLine(" ")
    -- Addon in einer anderen Sprache als der Client: Item-Namen in der Sprache des Addons zeigen
    -- (den Titel des Tooltips schreibt WoW immer in der Sprache des Clients)
    local N = A.Names
    if N and N.DisplayLocale and N:DisplayLocale() ~= N:ClientLocale() then
        local nm = N:Get(itemID)
        if nm then tooltip:AddLine("|cff00d1d1AHSentinel|r  " .. nm, 1, 1, 1) end
    end
    if not showInfo then
        tooltip:AddDoubleLine("|cff00d1d1AHSentinel|r  " .. L["Händlerpreis"], A:FormatMoney(vendor), 1, 1, 1, 1, 1, 1)
        return
    end
    -- S3 (Befund 21.11. 06:35, seelengebundene Schwere Leinenhandschuhe: "Jetzt teuer – verkaufen", AH-Gewinn): Seelengebundenes kann
    -- nicht ins AH -> keine AH-Preis-, Verkaufs-, Gewinn- oder Zeitpunkt-Zeilen; nur Händlerpreis und Entzauberungswert.
    if bound then
        self:AddBoundLines(tooltip, itemID, vendor)
        return
    end
    -- Variante A (Anweisung 14:50): ohne Shift genau drei Blöcke - Preis, Urteil, Materialien.
    -- Alles andere (Realer Wert mit Rechnung, Median, Trend, Absatz, Händler, Verkaufschance, Twinks ...) mit Shift
    -- bzw. Einstellung "alles".
    local isShift = A:Global("IsShiftKeyDown")
    local shift = isShift and isShift() or false
    local all = shift or self:DEMode() == "all"
    local cur = A:GetCurrent(itemID)
    local mv = A:GetMarketValue(itemID)
    local bag = self:OwnBagTooltip()
    if not cur and not mv and not (A.MarketValueInfo and A:MarketValueInfo(itemID).all > 0) then
        tooltip:AddLine(L["AHSentinel: noch keine Preisdaten"], 0.6, 0.6, 0.6)
        if vendor then tooltip:AddDoubleLine(L["Händlerpreis"], A:FormatMoney(vendor), 0.8, 0.8, 0.8, 1, 1, 1) end
        self:AddBlock2(tooltip, itemID, all)
        TT:AddExtraLines(tooltip, itemID, all)
        return
    end
    -- Block 1 (AUFTRAG TOOLTIP 21.11. 09:20, TT1–TT4): Kopf, Gewinn (grün, grösser), Marktwert (Median 14 Tage),
    -- Marktwert (Scan hh:mm) - ersetzt "Preis" und "Verkaufen:"
    self:AddHeadBlock(tooltip, itemID, s)
    -- F2: eigene Verkaufsdauer als letzte Zeile von Block 1 (ohne Shift)
    local speedText, speedColor = nil, nil
    if A.Ledger and A.Ledger.SellSpeedText then
        local n = bag and A.Seller and A.Seller.CountInBags and A.Seller:CountInBags(itemID) or nil
        local okS, t, c, r = pcall(A.Ledger.SellSpeedText, A.Ledger, itemID, (n and n > 0) and n or nil)
        if okS then speedText, speedColor, self.speedQueue = t, c, r and r.queue end
    end
    if speedText then
        tooltip:AddDoubleLine(L["Verkauft sich:"], speedText, 0.8, 0.8, 0.8, speedColor[1], speedColor[2], speedColor[3])
        if all and self.speedQueue then tooltip:AddLine(A.Ledger.SpeedHelp(), 0.6, 0.6, 0.6, true) end
    end
    -- JK1: Zeitpunkt - eine Zeile, nur wenn belegt (eigene Ware: zuerst die Verkaufs-Varianten)
    self:AddTimingLine(tooltip, itemID, bag and "own" or "any", all)
    -- Block 2 und 3
    self:AddBlock2(tooltip, itemID, all)
    -- nur mit Shift: Realer Wert mit Quelle und Rechnung, Absatz, Trend, Händler
    if all then
        local okR, rv, rp, rinfo, vendorWins = pcall(A.RealValue, A, itemID, 1)
        if okR and rv then
            local src = vendorWins and L["Händler"] or (rinfo and (rinfo.source == "sale" and L["eigener Verkauf"]
                or (rinfo.source == "ah" and L["Scan"] or L["Markt"]))) or ""
            local extra = (rinfo and rinfo.old) and (" |cffff9933" .. L["Preis alt"] .. "|r") or ""
            -- NP-MK-1 (c): Weg "snipe" gesperrt -> Wert grau mit Hinweis statt als sichere Zahl
            local uns = A.Sniper and A.Sniper.SnipeUnsure and A.Sniper:SnipeUnsure()
            if uns then
                tooltip:AddDoubleLine(L["Realer Wert (nach Gebühren)"], "|cff999999≈ " .. A:FormatMoney(rv) .. " " .. src .. "|r" .. extra, 0.8, 0.8, 0.8, 0.6, 0.6, 0.6)
                tooltip:AddLine("   " .. uns, 0.6, 0.6, 0.6)
            else
                tooltip:AddDoubleLine(L["Realer Wert (nach Gebühren)"], A:FormatMoney(rv) .. " |cff999999" .. src .. "|r" .. extra, 0.8, 0.8, 0.8, 1, 1, 1)
            end
            if rinfo then
                -- eigener Ø-Verkaufspreis: nur Statistik (K3), gelb wenn mehr als 30 % unter dem Markt
                if rinfo.sale then
                    local low = rinfo.median and rinfo.median > 0 and rinfo.sale < rinfo.median * 0.7
                    tooltip:AddDoubleLine("   " .. L["eigener Verkauf (14 Tage)"] .. (low and (" |cffffcc33(" .. L["unter Markt"] .. ")|r") or ""),
                        A:FormatMoney(rinfo.sale), 0.6, 0.6, 0.6, low and 1 or 0.8, low and 0.8 or 0.8, low and 0.2 or 0.8)
                end
                if rinfo.current then tooltip:AddDoubleLine("   " .. L["günstigstes Angebot"] .. (rinfo.unsure and (" (" .. L["Angebot unsicher"] .. ")") or ""),
                    A:FormatMoney(rinfo.current), 0.6, 0.6, 0.6, 0.8, 0.8, 0.8) end
                if rinfo.median then tooltip:AddDoubleLine("   " .. L["Median 14 Tage"], A:FormatMoney(rinfo.median), 0.6, 0.6, 0.6, 0.8, 0.8, 0.8) end
                if rp and not vendorWins then tooltip:AddDoubleLine("   " .. L["Gebühr"], A:FormatMoney(rp - (rv or rp) - (rinfo.relistCost or 0)), 0.6, 0.6, 0.6, 0.8, 0.8, 0.8) end
                if rinfo.relistCost and rinfo.relistCost > 0 and not vendorWins then
                    tooltip:AddDoubleLine("   " .. string.format(rinfo.relistWhy == "own" and L["~%.1fx einstellen (deine Verkaufsquote)"]
                        or L["~%.1fx einstellen (wenig Absatz)"], rinfo.listings), "-" .. A:FormatMoney(rinfo.relistCost), 0.6, 0.6, 0.6, 0.8, 0.8, 0.8)
                end
            end
        end
        if mv and A.LiquidityText then
            local ok, txt = pcall(A.LiquidityText, A, itemID)
            if ok and txt then tooltip:AddLine(txt, 0.75, 0.75, 0.75) end
        end
        local trend = A:GetTrend(itemID, 86400)
        if trend then tooltip:AddDoubleLine(L["Trend 24 Std."], A:FormatPercent(trend), 0.8, 0.8, 0.8, 1, 1, 1) end
        if vendor then
            -- TU1-HAENDLER: unbestätigter, unplausibler Tabellenpreis zählt nicht -> grau mit kurzem Hinweis
            if not A:VendorSafe(itemID, vendor) then
                tooltip:AddDoubleLine(L["Händlerpreis"], "|cff888888" .. A:FormatMoney(vendor) .. " – " .. L["Händlerpreis unbestätigt"] .. "|r", 0.8, 0.8, 0.8, 1, 1, 1)
            else
                local color = (cur and vendor > cur) and "|cff33dd55" or ""
                tooltip:AddDoubleLine(L["Händlerpreis"], color .. A:FormatMoney(vendor) .. (color ~= "" and "|r" or ""), 0.8, 0.8, 0.8, 1, 1, 1)
            end
        end
    end
    TT:AddExtraLines(tooltip, itemID, all)
    local w = A.db.watchlist[itemID]
    if w and (w.buyBelow or w.sellAbove) then
        local parts = {}
        if w.buyBelow then table.insert(parts, L["Kaufen <"] .. " " .. A:FormatMoney(w.buyBelow, true)) end
        if w.sellAbove then table.insert(parts, L["Verkaufen >"] .. " " .. A:FormatMoney(w.sellAbove, true)) end
        tooltip:AddDoubleLine(L["Watchlist"], table.concat(parts, "  "), 0.8, 0.8, 0.8, 1, 1, 1)
    end
end

-- S3: Tooltip eines seelengebundenen Gegenstands? (Zeile "Seelengebunden"/"Accountgebunden" im Tooltip, wie WoW sie schreibt)
function TT:IsBoundTip(tooltip)
    if type(tooltip) ~= "table" then return false end
    local marks = {}
    for _, g in ipairs({ "ITEM_SOULBOUND", "ITEM_ACCOUNTBOUND", "ITEM_BNETACCOUNTBOUND", "ITEM_ACCOUNTBOUND_UNTIL_EQUIP" }) do
        local v = A:Global(g)
        if type(v) == "string" and v ~= "" and g ~= "ITEM_ACCOUNTBOUND_UNTIL_EQUIP" then marks[v] = true end
    end
    if not next(marks) then marks["Seelengebunden"], marks["Soulbound"] = true, true end
    local name = tooltip.GetName and tooltip:GetName()
    local n = tooltip.NumLines and tooltip:NumLines() or 0
    if not name then return false end
    for i = 2, math.min(n, 10) do
        local fs = _G[name .. "TextLeft" .. i]
        local t = fs and fs.GetText and fs:GetText()
        if t and marks[t] then return true end
    end
    return false
end
function TT:AddBoundLines(tooltip, itemID, vendor)
    tooltip:AddLine("|cff00d1d1AHSentinel|r  " .. L["Seelengebunden – nicht im AH verkaufbar"], 0.8, 0.8, 0.8)
    if vendor then tooltip:AddDoubleLine(L["Händlerpreis"], A:FormatMoney(vendor), 0.8, 0.8, 0.8, 1, 1, 1) end
    local s = self:Settings() or {}
    local D = A.Disenchant
    if s.tooltipDE ~= false and D and D.Prior and D:Prior(itemID) and D.DealValue then
        local ok, v, net, complete, basis, n = pcall(D.DealValue, D, itemID)
        if ok and v and net then
            local mark = (basis == "actual") and string.format("(Ø %d)", n or 0) or "(T)"
            local cmp = vendor and ((net > vendor) and (" |cff33dd55" .. L["lohnt mehr als Händler"] .. "|r") or (" |cffff9933" .. L["Händler bringt mehr"] .. "|r")) or ""
            tooltip:AddDoubleLine(L["Entzauberungswert"] .. cmp, "~" .. A:FormatMoney(net) .. (complete and "" or " +?") .. " |cff999999" .. mark .. "|r",
                0.8, 0.8, 0.8, 1, 1, 1)
        end
    end
end

-- ------------------------------------------------------------
-- AUFTRAG TOOLTIP 21.11. 09:20 (Nutzer): TT1 realer Gewinn mit Rechnung (TT2), Marktwert unbekannt (TT3), Scan alt (TT4)
-- ------------------------------------------------------------
TT.SCAN_OLD = 1800                     -- TT4: älter als 30 Min. -> "Scan alt", keine Kaufhinweise mit Rendite
-- TT1: Gewinn je Entzauberung = Materialien (eigene Anteile ab 30 Entzauberungen, sonst Vorgabe) × günstigstes Angebot im letzten
-- Scan − 5 % Gebühr (abgerundet) − Einzahlungsrisiko − Kaufpreis. Kein Abzug "Unterbieten", kein Korrekturfaktor, kein Mindestgewinn.
-- Jede Zeile ganze Kupfer, die Summe geht exakt auf (TT2). Rückgabe: { gross, fee, dep, net, buy, gain, lines, why }.
function TT:RealCalc(itemID)
    local D = A.Disenchant
    if not (D and D.Prior) then return nil end
    local prior, key = D:Prior(itemID)
    if not prior then return nil end
    local nowT = time()
    local rows, n, src = {}, nil, "vorgabe"
    local own = key and self:OwnDEStats(key)
    local mats
    if own and (own.n or 0) >= self.DE2_MIN then n, mats, src = own.n, own.mats, "own"
    elseif key and D.Combined then
        local okC, no, ns, m = pcall(D.Combined, D, key)
        if okC and ns > 0 and (no + ns) >= self.DE2_MIN then n, mats, src = no + ns, m, "guild" end
    end
    if mats then
        for id, m in pairs(mats) do if (m.total or 0) > 0 then rows[#rows + 1] = { id = id, qty = m.total / n } end end
    else
        for _, e in ipairs(prior) do
            if (e[2] or 0) > 0 then
                local lo = e[4] or math.floor((e[3] or 1) + 0.5)
                local hi = e[5] or lo
                rows[#rows + 1] = { id = e[1], qty = e[2] * (e[3] or ((lo + hi) / 2)) }
            end
        end
    end
    -- P1/P11 (Befund 21.11. 12:50/14:55: "1.12 × 23s88 = 26s87", gerechnet mit 1,125): Faktor auf 4 Stellen festlegen, mit genau
    -- diesem Faktor rechnen und ihn ungerundet zeigen - jede Zeile rechnet sich aus dem, was dasteht
    for _, r in ipairs(rows) do r.qty = tonumber(string.format("%.4f", r.qty)) end
    table.sort(rows, function(a, b) return a.qty > b.qty end)
    local res = { lines = {}, src = src, n = n, rows = rows }
    local gross, dep, oldest = 0, 0, nil
    for _, r in ipairs(rows) do
        local cur, _, t = A:GetCurrent(r.id)
        if not (cur and cur > 0) then
            res.why = string.format(L["Gewinn: Preis für %s fehlt"], A:GetItemName(r.id) or ("#" .. r.id))
            return res
        end
        r.price, r.val = cur, math.floor(r.qty * cur + 0.5)
        gross = gross + r.val
        if t and (not oldest or t < oldest) then oldest = t end
        if A:IsForever() then
            local per = A:AuctionSize(r.id) or 1
            local loss = A:ExpectedDepositLoss(r.id, per) or 0
            dep = dep + math.floor(r.qty * loss / math.max(1, per) + 0.5)
        end
    end
    -- Kaufpreis: Angebot unter der Maus / beim Händler, sonst das günstigste Angebot im letzten Scan
    local buy, how, buyT
    local c = self.buyContext
    if c and c.itemID == itemID and c.price and c.price > 0 then buy, how = c.price, "list"
    else
        local atMerchant = type(MerchantFrame) == "table" and MerchantFrame.IsShown and MerchantFrame:IsShown()
        local v = atMerchant and A:GetVendorBuyPrice(itemID)
        if v and v > 0 then buy, how = v, "vendor"
        else buy, _, buyT = A:GetCurrent(itemID); how = "scan" end
    end
    if buyT and (not oldest or buyT < oldest) then oldest = buyT end
    -- TT4: ein Preis der Rechnung älter als 30 Min. -> keine Rendite
    if oldest and nowT - oldest > self.SCAN_OLD then
        res.why = string.format(L["Scan alt – Preis vom %s"], date("%H:%M", oldest))
        res.old = oldest
        return res
    end
    local fee = math.floor(gross * A:CutPct())
    local net = gross - fee - dep
    res.gross, res.fee, res.dep, res.net = gross, fee, dep, net
    local comma = (A.uiLang or (GetLocale and GetLocale())) == "deDE"
    local function Q(x)
        local t = string.format("%.4f", x):gsub("0+$", "")
        local dec = t:match("%.(%d*)$") or ""
        if #dec < 2 then t = t .. string.rep("0", 2 - #dec) end
        if comma then t = t:gsub("%.", ",") end
        return t
    end
    local Ls = res.lines
    Ls[#Ls + 1] = { L["Rechnung je Entzauberung"] .. " (" .. ((src == "own" and string.format(L["bei dir (%d)"], n)) or (src == "guild" and string.format(L["Gilde (%d)"], n)) or L["Vorgabe"]) .. ")", "" }
    for _, r in ipairs(rows) do
        Ls[#Ls + 1] = { string.format("%s × %s à %s", Q(r.qty), A:GetItemName(r.id) or ("#" .. r.id), A:FormatMoney(r.price)), A:FormatMoney(r.val) }
    end
    Ls[#Ls + 1] = { L["Summe Materialien"], A:FormatMoney(gross) }
    Ls[#Ls + 1] = { string.format(L["Gebühr %d %%"], math.floor(A:CutPct() * 100 + 0.5)), "−" .. A:FormatMoney(fee) }
    if A:IsForever() then Ls[#Ls + 1] = { L["Einzahlungsrisiko"], "−" .. A:FormatMoney(dep) } end
    Ls[#Ls + 1] = { L["Wert nach Gebühren"], A:FormatMoney(net) }
    if buy and buy > 0 then
        res.buy, res.how = buy, how
        res.gain = net - buy
        local bl = (how == "list" and L["Kaufpreis (Angebot)"]) or (how == "vendor" and L["Kaufpreis (Händler)"]) or L["Kaufpreis (Scan)"]
        Ls[#Ls + 1] = { bl, "−" .. A:FormatMoney(buy) }
        Ls[#Ls + 1] = { L["Gewinn"], (res.gain >= 0 and "+" or "−") .. A:FormatMoney(math.abs(res.gain)) }
    end
    return res
end
-- Kopf: "AHSentinel", Gewinn (TT1, grün und grösser), Marktwert (Median 14 Tage) (TT3), Marktwert (Scan hh:mm) (TT4)
function TT:AddHeadBlock(tooltip, itemID, s)
    local LC = self.LABEL_COL
    tooltip:AddLine("|cff00d1d1AHSentinel|r")
    local D = A.Disenchant
    local deOK = (not s or s.tooltipDE ~= false) and D and D.Prior and D:Prior(itemID)
    if deOK then
        local okC, c = pcall(self.RealCalc, self, itemID)
        if okC and c then
            if c.gain then
                local txt = string.format(L["Gewinn %s"], (c.gain >= 0 and "+" or "−") .. A:FormatMoney(math.abs(c.gain)))
                local col = c.gain >= 0 and self.PROFIT_GREEN or self.PROFIT_RED
                tooltip:AddLine(txt, col[1], col[2], col[3])
                self.bigText = txt
            elseif c.why then
                tooltip:AddLine(c.why, 1, 0.6, 0.2)
            end
            if c.lines and #c.lines > 0 and c.gain then self.calcLines = c.lines end
        end
    end
    local mv = A:GetMarketValue(itemID)
    if mv then
        tooltip:AddDoubleLine(LC .. L["Marktwert (Median 14 Tage)"] .. "|r", A:FormatMoney(mv), 0.75, 0.75, 0.75, 1, 1, 1)
    else
        local info = A.MarketValueInfo and A:MarketValueInfo(itemID)
        if info and info.all > 0 then
            tooltip:AddDoubleLine(LC .. L["Marktwert (Median 14 Tage)"] .. "|r", L["nicht bekannt"], 0.75, 0.75, 0.75, 0.6, 0.6, 0.6)
            self.calcLines = self.calcLines or {}
            local t = string.format(L["Zu wenig Preise in den letzten 14 Tagen (nur %d, ältester vom %s)"], info.n, info.oldest and date("%d.%m.", info.oldest) or "-")
            table.insert(self.calcLines, 1, { t, "" })
        end
    end
    local cur, _, ct = A:GetCurrent(itemID)
    if cur and ct then
        if time() - ct > self.SCAN_OLD then
            tooltip:AddDoubleLine("|cffff9933" .. string.format(L["Scan alt – Preis vom %s"], date("%H:%M", ct)) .. "|r", A:FormatMoney(cur), 1, 0.6, 0.2, 1, 1, 1)
        else
            tooltip:AddDoubleLine(LC .. string.format(L["Marktwert (Scan %s)"], date("%H:%M", ct)) .. "|r", A:FormatMoney(cur), 0.75, 0.75, 0.75, 1, 1, 1)
        end
    end
end
-- TT2: Rechnung als Kasten rechts am Item-Tooltip (Nutzer 21.11.: kein Shift, WoW-Tooltips nehmen keine Maus an)
function TT:CalcBox()
    if self.calcBox then return self.calcBox end
    local ok, f = pcall(CreateFrame, "GameTooltip", "AHSentinelCalcTip", UIParent, "GameTooltipTemplate")
    if ok and f then self.calcBox = f end
    return self.calcBox
end
function TT:ShowCalc(tooltip)
    local lines = self.calcLines
    if not (lines and #lines > 0) then return self:HideCalc(tooltip) end
    local f = self:CalcBox()
    if not f then return end
    f:SetOwner(tooltip, "ANCHOR_NONE")
    f:ClearAllPoints()
    f:SetPoint("TOPLEFT", tooltip, "TOPRIGHT", 2, 0)
    for i, l in ipairs(lines) do
        if i == 1 then f:AddLine(l[1], 0.75, 0.75, 0.75)
        elseif l[2] == "" then f:AddLine(l[1], 0.75, 0.75, 0.75, true)
        else f:AddDoubleLine(l[1], l[2], 0.75, 0.75, 0.75, 1, 1, 1) end
    end
    f:Show()
    self.calcOwner = tooltip
end
function TT:HideCalc(tooltip)
    local f = self.calcBox
    if f and (not tooltip or self.calcOwner == tooltip) then f:Hide(); self.calcOwner = nil end
end
-- Gewinn-Zeile etwas grösser (Schrift des Item-Namens); beim Leeren des Tooltips zurück
function TT:ApplyBig(tooltip)
    local txt = self.bigText
    if not (txt and tooltip.GetName and tooltip.NumLines) then return end
    local name = tooltip:GetName()
    if not name then return end
    for i = 2, tooltip:NumLines() do
        local fs = _G[name .. "TextLeft" .. i]
        if fs and fs.GetText and fs:GetText() == txt then
            local font = _G.GameTooltipHeaderText or _G.GameFontNormalLarge
            if font and fs.SetFontObject and fs.GetFontObject then
                tooltip.__ahapBig = { fs = fs, old = fs:GetFontObject() }
                fs:SetFontObject(font)
            end
            return
        end
    end
end
function TT:RestoreBig(tooltip)
    local b = tooltip.__ahapBig
    if b and b.fs and b.old then pcall(b.fs.SetFontObject, b.fs, b.old) end
    tooltip.__ahapBig = nil
end

-- Block 2 (Urteil) und Block 3 (Materialien). Nicht entzauberbar: nur "Verkaufen:" (bzw. Händler, falls besser).
-- P5 (Nachprüfung 07:40): Entzauberwert nachprüfbar - einmal je Item und Tag ins Protokoll (ohne Namen):
-- Quelle, je Material Chance / Ø Menge / Preis netto, Ergebnis brutto und netto
TT.deLogged = {}
function TT:LogDEValue(itemID)
    if not (A.Diag and itemID) or (A.TestRoutine and A.TestRoutine.running) then return end
    local day = math.floor(time() / 86400)
    if self.deLogged[itemID] == day then return end
    local D = A.Disenchant
    if not (D and D.DealValue and D.Prior and D:Prior(itemID)) then return end
    local okV, v, net, _, basis, n = pcall(D.DealValue, D, itemID)
    if not (okV and v) then return end
    self.deLogged[itemID] = day
    local okM, mats = pcall(self.DisenchantMats, self, itemID)
    local parts = {}
    for _, m in ipairs(okM and mats or {}) do
        local netP = m.price and (A:IsForever() and (m.price - (A:FeePerPiece(m.id, m.price) or 0)) or m.price * (1 - A:CutPct()))
        parts[#parts + 1] = string.format("%s %.0f%% × %.2f à %s", tostring(m.id), (m.chance or 0) * 100, m.avg or 0,
            netP and tostring(math.floor(netP + 0.5)) or "?")
    end
    -- Hinweis c (08:20): einmal je Gruppe und Tag Tabelle gegen echte Ergebnisse
    pcall(function()
        local prior, key = D:Prior(itemID)
        if not (prior and key) then return end
        self.chanceLogged = self.chanceLogged or {}
        if self.chanceLogged[key] == day then return end
        self.chanceLogged[key] = day
        local nOwn, nShared, mats = D:Combined(key)
        local nn = (nOwn or 0) + (nShared or 0)
        local tab, real = {}, {}
        for _, e in ipairs(prior) do
            tab[#tab + 1] = string.format("%s %.0f%%", tostring(e[1]), (e[2] or 0) * 100)
            local m = mats and mats[e[1]]
            real[#real + 1] = string.format("%s %s", tostring(e[1]), (m and nn > 0) and string.format("%.0f%%", m.times / nn * 100) or "-")
        end
        A.Diag:Add("DE-CHANCEN", string.format("Gruppe %s · Tabelle %s · echt %s (%d)", key, table.concat(tab, "/"), table.concat(real, "/"), nn))
    end)
    pcall(A.Diag.Add, A.Diag, "ENTZAUBERWERT", string.format("Item %d · %s · %s · brutto %d · netto %d", itemID,
        basis == "actual" and string.format("eigene Ø aus %d", n or 0) or "Tabelle", table.concat(parts, ", "), math.floor(v + 0.5),
        math.floor((net or 0) + 0.5)))
end

function TT:AddBlock2(tooltip, itemID, all)
    local s = self:Settings() or {}
    if A.LogAbsatz then pcall(A.LogAbsatz, A, itemID) end
    pcall(self.LogDEValue, self, itemID)
    local D = A.Disenchant
    local deOK = s.tooltipDE ~= false and D and D.Prior and D:Prior(itemID)
    if deOK then
        -- TT1–TT6: Gewinn steht oben (AddHeadBlock); hier nur die Materialien (mit Shift dazu die Wege und Einzelheiten)
        local ok, n = pcall(self.AddDisenchantLines, self, tooltip, itemID, nil, all)
        if ok and n and n > 0 then
            if all then self:AddOutlookLine(tooltip, itemID) end
            return
        end
    end
    local okR, rv, _, _, vendorWins = pcall(A.RealValue, A, itemID, 1)
    if okR and rv then
        tooltip:AddLine(" ")
        -- LT1: Angebot unter der Maus (oder beim Händler) -> Gewinn je Stück auch für nicht entzauberbare Items
        local price, how = self:LivePrice(itemID)
        if how == "list" or how == "vendor" then self:AddProfitLine(tooltip, itemID, { sellNet = rv, sellVendor = vendorWins }, price) end
        -- TU1-TT-1: läuft oft ab -> nicht mehr versprechen als der Verkaufen-Reiter vorschlägt (netto, grau markiert)
        local Se = A.Seller
        local okX, xGross, xNet = false, nil, nil
        if not vendorWins and Se and Se.ExpiryOffer then okX, xGross, xNet = pcall(Se.ExpiryOffer, Se, itemID) end
        -- TT (21.11. 09:20): "Marktwert (Scan hh:mm)" oben ersetzt die Zeile "Verkaufen:"; der Händler bleibt, wenn er mehr zahlt
        if okX and xNet and xNet < rv then
            tooltip:AddLine("|cff999999" .. L["(läuft oft ab)"] .. "|r")
        elseif vendorWins then
            tooltip:AddDoubleLine(L["Händler:"], A:FormatMoney(rv), 0.75, 0.75, 0.75, 1, 1, 1)
        end
        -- D6c: Aufkauf erkannt -> Verkaufen zum aktuellen Preis, mit Hinweis
        local okBo, bo = pcall(A.BuyoutInfo, A, itemID)
        if okBo and bo then tooltip:AddLine("   " .. L["Preis künstlich hoch – eigene Bestände jetzt verkaufen"], 1, 0.8, 0)
        elseif Se and Se.HighGuess and Se:HighGuess(itemID) then
            -- TU1-TT-2: nur aus der Aufkauf-Leiter erkannt -> als Vermutung, grau-gelb
            tooltip:AddLine("   " .. L["Preis wohl künstlich hoch (Aufkauf-Leiter) – eigene Bestände jetzt verkaufen?"], 0.8, 0.75, 0.45)
        end
        self:AddBagTotal(tooltip, itemID)
        if all then self:AddOutlookLine(tooltip, itemID) end
    end
end

-- A5 (Angebot und Absatz): nur mit Shift eine kurze Begründung - "150 im AH · ~5/Tag · ~30 Tage · 4 Einstellungen"
function TT:OutlookText(itemID)
    local ok, v = pcall(A.SellOutlook, A, itemID, 1, (A:RealPrice(itemID)))
    if not (ok and v) then return nil end
    local parts = {}
    if v.queue then parts[#parts + 1] = string.format(L["%d im AH"], v.queue) end
    if v.perDay then
        parts[#parts + 1] = string.format(L["~%s/Tag"], v.perDay >= 10 and tostring(math.floor(v.perDay + 0.5)) or string.format("%.1f", v.perDay))
        -- V5: Quelle des Absatzes (gemessen aus dem Vollscan oder geschätzt)
        if v.perDaySource == "measured" then parts[#parts] = parts[#parts] .. " (" .. string.format(L["gemessen, %d Tage"], v.measuredDays or 0) .. ")"
        elseif v.perDaySource == "alle" then parts[#parts] = parts[#parts] .. " (" .. string.format(L["alle Spieler (mind. %d), %d Tage"], v.allPlayers or 0, v.measuredDays or 0) .. ")"
        elseif v.perDaySource == "market" or v.perDaySource == "market, Deckel" or v.perDaySource == "market, gelernt" then parts[#parts] = parts[#parts] .. " (" .. L["geschätzt"] .. ")" end
    end
    if v.wait then parts[#parts + 1] = string.format(L["~%d Tage"], math.max(1, math.floor(v.wait + 0.5))) end
    if v.rare then parts[#parts + 1] = L["verkauft sich kaum"]
    elseif v.listings then parts[#parts + 1] = string.format(v.listings == 1 and L["%d Einstellung"] or L["%d Einstellungen"], v.listings) end
    if v.hours then parts[#parts + 1] = string.format(L["Laufzeit %d Std."], v.hours) end      -- benutzte Laufzeit (Punkt 1)
    if v.perDayCapped then parts[#parts + 1] = L["unsicher (Absatz über dem Angebot begrenzt)"]       -- MU1-5
    elseif v.unsure then parts[#parts + 1] = L["unsicher (wenig Scans)"] end
    if #parts == 0 then return nil end
    return table.concat(parts, " · "), v
end

function TT:AddOutlookLine(tooltip, itemID)
    local text, v = self:OutlookText(itemID)
    if text then
        tooltip:AddLine("   " .. text, (v and v.rare) and 1 or 0.6, (v and v.rare) and 0.6 or 0.6, (v and v.rare) and 0.2 or 0.6)
    end
    -- Prognose-Journal P7 (nur mit Shift, ab 20 eigenen Fällen der Warengruppe)
    local Fc = A.Forecast
    if Fc then
        local ok, line = pcall(Fc.TooltipLine, Fc, itemID)
        if ok and line then tooltip:AddLine("   " .. line, 0.6, 0.6, 0.6) end
    end
    -- Stufe 2: Quelle und Sicherheit der gelernten Verkaufschance, Rhythmus (nur mit Shift, nur wenn etwas gelernt ist)
    local Ln = A.Learn
    if Ln and Ln.On and Ln:On() then
        local okC, p, info = pcall(Ln.Chance, Ln, itemID, 1, A:EvalHours(itemID, 1))
        if okC and p and info and info.src ~= "start" then
            -- Kalibrierung: korrigierte Zahl; solange nicht kalibriert mit "lernt noch" (grau)
            local Fcx = A.Forecast
            local shown, calOK = p, true
            if Fcx and Fcx.ShownChance then shown, calOK = Fcx:ShownChance(p) end
            local line = string.format(L["Verkaufschance zum Marktwert: %d %% (%s)"], math.floor(shown * 100 + 0.5), Ln:SourceText(info))
            if not calOK then line = line .. " · " .. L["lernt noch (nicht kalibriert)"] end
            tooltip:AddLine("   " .. line, 0.6, 0.6, 0.6)
        end
        local okR, r = pcall(Ln.Rhythm, Ln, itemID)
        if okR and r then tooltip:AddLine("   " .. L["Rhythmus: "] .. r, 0.6, 0.6, 0.6) end
    end
end

-- Wunsch des Nutzers (10.11. 06:13, Anweisung Gesamtwert): stapelbar und mindestens 2 Stück in den Taschen (ohne Bank)
-- -> Gesamtwert aller Stapel, dieselbe Rechnung wie "Verkaufen:" mit der ganzen Menge (A:RealValue)
function TT:BagCount(itemID)
    local f = A:Global("GetItemCount")
    if not f then local CI = A:Global("C_Item"); f = CI and CI.GetItemCount end
    local ok, n = pcall(function() return f and f(itemID) end)
    return (ok and type(n) == "number") and n or 0
end

-- Befund 08:35 (Zeile fehlt bei Seltsamem Staub, U2): hier stand das globale GetItemInfo ohne Rückfall auf
-- C_Item.GetItemInfo (alle anderen Dateien haben ihn) - fehlt es im Client, galt nichts als stapelbar. Jetzt A:StackSize.
function TT:IsStackable(itemID)
    local ok, stack = pcall(A.StackSize, A, itemID)
    return ok and type(stack) == "number" and stack > 1
end

TT.totalLogged = {}
function TT:AddBagTotal(tooltip, itemID)
    local n = self:BagCount(itemID)
    if n < 2 or not self:IsStackable(itemID) then return end
    local okT, total, _, _, vendorWins = pcall(A.RealValue, A, itemID, n)
    if not (okT and type(total) == "number") then
        local errText = okT and "kein Wert" or tostring(total)
        -- G2: nie still verschwinden - Ersatz "Verkaufen:" × n (bzw. Händler × n), einmal je Item und Sitzung ins Protokoll
        local ok1, one = pcall(A.RealValue, A, itemID, 1)
        local vendor = A:GetVendorPrice(itemID)
        total = (ok1 and type(one) == "number" and one * n) or ((type(vendor) == "number" and vendor > 0) and vendor * n) or nil
        if A.Diag and not self.totalLogged[itemID] then
            self.totalLogged[itemID] = true
            pcall(A.Diag.Add, A.Diag, "GESAMTWERT", string.format("Item %d · n %d · stapelbar ja · Fehler %s · Ersatz %s", itemID, n,
                errText:sub(1, 100), total and tostring(math.floor(total)) or "-"))
        end
        if not total then return end
    end
    tooltip:AddDoubleLine(string.format(L["%d in den Taschen:"], n), A:FormatMoney(total), 0.8, 0.8, 0.8, 1, 1, 1)
end

-- Entzaubern im Tooltip: zwei klar getrennte Werte
--   "Entzaubern tatsächlich (Ø aus N)": nur echte Entzauberungen (eigene + geteilte), aktueller AH-Preis je Material
--   "Entzaubern geschätzt (Tabelle)":    D:GetValue (Tabelle verrechnet mit Ergebnissen)
-- detail = je Material eine Zeile und "nach Gebühren" (Einstellung, Standard an)
function TT:DisenchantLines(itemID, detail)
    local D = A.Disenchant
    local lines = {}            -- { left, right, dim }
    local function priceText(r)
        if not r.price then return L["kein Preis"] end
        local t = "AH " .. A:FormatMoney(r.price)
        if r.age then t = t .. " (" .. A:FormatAgo(time() - r.age) .. ")" end
        if r.mv and r.mv ~= r.price then t = t .. " · " .. string.format(L["Markt %s"], A:FormatMoney(r.mv)) end
        return t
    end
    local function share(r) return r.share and ("= " .. A:FormatMoney(math.floor(r.share + 0.5))) or "+?" end
    -- tatsächlich
    local av, acomplete, n, arows = D:ActualValue(itemID)
    if av then
        local label = string.format(L["Entzaubern tatsächlich (Ø aus %d)"], n)
        if n < D.FEW_DATA then label = label .. " " .. L["(wenig Daten)"] end
        table.insert(lines, { label, A:FormatMoney(av) .. (acomplete and "" or " +?") })
        if detail then
            for _, r in ipairs(arows) do
                table.insert(lines, { string.format("   %s  %d/%d × Ø %.1f · %s", A:GetItemName(r.id) or ("#" .. r.id), r.times, n,
                    r.total / r.times, priceText(r)), share(r), true })
            end
            table.insert(lines, { "   " .. L["nach Gebühren"], A:FormatMoney(D:ActualNet(av, arows, n)) .. (acomplete and "" or " +?"), true })
        end
    end
    -- geschätzt
    local v, complete, yield = D:GetValue(itemID)
    if v then
        table.insert(lines, { L["Entzaubern geschätzt (Tabelle)"], "~" .. A:FormatMoney(v) .. (complete and "" or " +?") })
        if detail then
            for _, r in ipairs(D:EstimateRows(itemID) or {}) do
                table.insert(lines, { string.format("   %s  %d%% × Ø %.1f · %s", A:GetItemName(r.id) or ("#" .. r.id),
                    math.floor(r.chance * 100 + 0.5), r.avg, priceText(r)), share(r), true })
            end
            table.insert(lines, { "   " .. L["nach Gebühren"], "~" .. A:FormatMoney(D:NetValue(v, yield)) .. (complete and "" or " +?"), true })
        end
    end
    -- womit die Schnäppchen rechnen
    if detail and (av or v) then
        local _, _, _, basis = D:DealValue(itemID)
        if basis then
            table.insert(lines, { "   " .. (basis == "actual" and L["Schnäppchen rechnen mit: tatsächlich"]
                or L["Schnäppchen rechnen mit: geschätzt"]), "", true })
        end
    end
    return lines
end

-- Kurzform (0.65.26, Wunsch des Nutzers): EINE Zeile "Entzaubern: erwarteter Gewinn ~X" (Wert nach Gebühren),
-- dahinter klein der Vergleich mit dem Verkauf des Items und die Quelle ("(Ø 12)" = aus 12 Entzauberungen,
-- "(T)" = Tabelle). Die ganze Rechnung läuft weiter (DisenchantLines), Shift zeigt sie.
-- zurück: { left, right, net, basis, n, sellNet } oder nil
function TT:DisenchantShort(itemID)
    local D = A.Disenchant
    local v, net, complete, basis, n = D:DealValue(itemID)
    if not v then return nil end
    local mark = (basis == "actual") and string.format("(Ø %d)", n) or "(T)"
    -- Befund 9. Nov. 10:31: das ist der Entzauberungswert (hängt nur von der Gruppe ab), kein Gewinn
    local left = L["Entzauberungswert"]
    local sellNet, _, _, vendorWins = A:RealValue(itemID, 1)
    if sellNet then
        left = left .. "  " .. ((net > sellNet) and ("|cff33dd55" .. (vendorWins and L["lohnt mehr als Händler"] or L["lohnt mehr als Verkauf"]) .. "|r")
            or ("|cffff9933" .. (vendorWins and L["Händler bringt mehr"] or L["Verkauf bringt mehr"]) .. "|r"))
    end
    local res = { left = left, right = "~" .. A:FormatMoney(net) .. (complete and "" or " +?") .. " |cff999999" .. mark .. "|r",
        net = net, basis = basis, n = n, sellNet = sellNet }
    -- Gewinn beim Kauf: Wert - Kaufpreis (Kaufpreis aus der Zeile im Addon, beim Händler, sonst günstigstes Angebot)
    local buy, how = self:BuyPriceFor(itemID)
    if buy then
        local g = net - buy
        res.buy, res.gain = buy, g
        res.gainLeft = how == "list" and L["Gewinn beim Kauf"] or (how == "vendor" and L["Gewinn beim Kauf (Händler)"]
            or L["Gewinn beim Kauf (günstigstes Angebot)"])
        res.gainRight = (g >= 0 and ("|cff33dd55" .. A:FormatMoney(g)) or ("|cffff5544-" .. A:FormatMoney(-g))) .. "|r"
            .. " |cff999999(" .. A:FormatMoney(net) .. " − " .. A:FormatMoney(buy) .. ")|r"
    end
    return res
end

-- ------------------------------------------------------------
-- Entzauber-Urteil (Anweisung "Entzauber-Urteil", 9. Nov. 13:05): der Spieler sieht ohne Rechnen, ob es sich lohnt.
--   Gewinn    = Entzauberungswert (nach Gebühren, wie bisher) - Kaufpreis
--   Lohnt bis = Entzauberungswert / (1 + Mindestgewinn %)  (Mindestgewinn Entzaubern = DEB:DEMinRoi je Gruppe, DE30b: 20/25/30 %), abwärts
--   state     = "good" (Kaufpreis <= Lohnt bis), "bad" (sonst), "unsure" (Materialpreis fehlt oder unsicher)
-- zurück: { net, limit, buy, gain, state, how, sellNet, own } oder nil (nicht entzauberbar / kein Wert)
-- ------------------------------------------------------------
TT.ICON_GOOD = "|TInterface\\RaidFrame\\ReadyCheck-Ready:14:14:0:0|t "
TT.ICON_BAD = "|TInterface\\RaidFrame\\ReadyCheck-NotReady:14:14:0:0|t "

function TT:MinGainPct(itemID)
    local DEB = A.DEBuy
    return (DEB and DEB.DEMinRoi and DEB:DEMinRoi(itemID)) or A.DE_MIN_GAIN or 30
end

-- ist ein Material unsicher? (kein Preis, Angebot unsicher oder Markt nicht verlässlich)
function TT:MatsUnsure(itemID)
    local mats = self:DisenchantMats(itemID)
    for _, m in ipairs(mats) do
        if not m.price or m.unsure then return true end
        if A.IsReliable then
            local ok, rel = pcall(A.IsReliable, A, m.id)
            if ok and rel == false then return true end
        end
    end
    return false
end

-- eigenes Item in den Taschen (für die Zeile Verkauf/Entzaubern)?
function TT:OwnsItem(itemID)
    local f = A:Global("GetItemCount")
    if not f then return false end
    local ok, n = pcall(f, itemID)
    return ok and type(n) == "number" and n > 0
end

function TT:DisenchantVerdict(itemID)
    local D = A.Disenchant
    if not (D and D.DealValue) then return nil end
    local v, net, complete, _, nDE, corr = D:DealValue(itemID)
    if not v or not net then return nil end
    local res = { net = net, corr = corr }
    -- RK2-A: "Lohnt bis" aus der EINEN Rechnung (A.Core:LimitFromNet)
    local MK = A.Core
    -- RK4/S2-B3: liefert die eine Rechnung kein "Lohnt bis" (Weg aus, keine Verzauberkunst, keine Stufe hält den
    -- Mindestgewinn), gibt es auch hier keins - nie ersatzweise den Netto-Wert
    if MK and MK.LimitFromNet then res.limit = MK:LimitFromNet(net, nDE, itemID)
    else res.limit = math.floor(net / (1 + self:MinGainPct(itemID) / 100)) end
    -- MP2/LB3: Hauptmaterial älter als 6 Std. -> kein Betrag bei "Lohnt bis", Urteil "unsicher"
    local okS, stale = pcall(D.StaleMain, D, itemID)
    res.stale = okS and stale or false
    local unsure = (not complete) or self:MatsUnsure(itemID) or res.stale
    res.unsure = unsure and true or false                 -- TT1317: kein grünes Häkchen bei unsicheren Materialien
    local buy, how = self:BuyPriceFor(itemID)
    if buy then
        res.buy, res.how, res.gain = buy, how, net - buy
        if unsure then res.state = "unsure"
        elseif res.limit and buy <= res.limit then res.state = "good"
        else res.state = "bad" end
    elseif unsure then
        res.state = "unsure"
    end
    -- MH1310/FG: Weg Entzaubern nicht freigegeben -> keine grüne Empfehlung (Zahlen bleiben, grau)
    if MK and MK.WayState then
        local okW, st, n = pcall(MK.WayState, MK, "de")
        if okW then res.wayState, res.wayN = st, n end
    end
    res.own = self:OwnsItem(itemID)
    -- T-AB5: kann der Spieler selbst entzaubern (Weg an, Verzauberkunst)? Sonst ist Entzaubern nur Info
    if D.WayDE then
        local okW, w = pcall(D.WayDE, D, itemID)
        res.wayDE = not (okW and w == false)              -- Fehler beim Prüfen -> wie bisher "an"
        if res.wayDE == false then res.wayOff = A.WayOn and not A:WayOn("de") or false end
    end
    local _, _, _, vendorWins
    res.sellNet, _, _, vendorWins = A:RealValue(itemID, 1)
    res.sellVendor = vendorWins and true or false        -- Händler zahlt mehr bzw. "verkauft sich kaum" (Angebot/Absatz)
    return res
end

local function SignedMoney(v)
    if v >= 0 then return "+" .. A:FormatMoney(v) end
    return "−" .. A:FormatMoney(-v)
end
-- H8 (10.11.): Gewinn mit Prozent vom Kaufpreis ("+1s 20c (+12 %)")
local function GainText(gain, buy)
    if not (buy and buy > 0) then return SignedMoney(gain) end
    return string.format("%s (%s%d %%)", SignedMoney(gain), gain >= 0 and "+" or "−", math.floor(math.abs(gain) / buy * 100 + 0.5))
end
TT.GainText = GainText

-- die zwei Urteilszeilen (ohne Shift genau diese); own items: nur Verkauf/Entzaubern
-- Zeilen 3-4 (Nachträge 14:16/14:18): beide Wege mit Betrag nach Gebühr, der bessere zuerst und farbig
function TT:AddWayLines(tooltip, r)
    local de, sell = r.net, r.sellNet
    -- T-AB5 (Supervisor 22:32): ohne Verzauberkunst bzw. Weg aus -> Verkaufen/Händler normal, Entzaubern grau als Info mit Zusatz
    if r.wayDE == false then
        if sell then tooltip:AddDoubleLine(r.sellVendor and L["Händler:"] or L["Verkaufen:"], A:FormatMoney(sell), 1, 1, 1, 1, 1, 1) end
        tooltip:AddDoubleLine(r.wayOff and L["Entzaubern (Weg aus):"] or L["Entzaubern (mit Verzauberkunst):"], A:FormatMoney(de), 0.6, 0.6, 0.6, 0.6, 0.6, 0.6)
        return sell and 2 or 1
    end
    -- TT1317: Materialpreise unsicher -> Entzaubern grau ohne Häkchen ("Entzaubern: unsicher"), Verkaufen grau daneben
    if r.unsure then
        tooltip:AddDoubleLine(L["Entzaubern: unsicher"], A:FormatMoney(de), 0.6, 0.6, 0.6, 0.6, 0.6, 0.6)
        if sell then tooltip:AddDoubleLine(r.sellVendor and L["Händler:"] or L["Verkaufen:"], A:FormatMoney(sell), 0.6, 0.6, 0.6, 0.6, 0.6, 0.6) end
        return sell and 2 or 1
    end
    if not sell then
        tooltip:AddDoubleLine((r.state == "bad" and "" or self.ICON_GOOD) .. L["Entzaubern:"], A:FormatMoney(de), 0.2, 0.87, 0.33, 0.2, 0.87, 0.33)
        return 1
    end
    if de > sell then
        tooltip:AddDoubleLine((r.state == "bad" and "" or self.ICON_GOOD) .. L["Entzaubern:"], A:FormatMoney(de), 0.2, 0.87, 0.33, 0.2, 0.87, 0.33)
        tooltip:AddDoubleLine(r.sellVendor and L["Händler:"] or L["Verkaufen:"], A:FormatMoney(sell), 0.6, 0.6, 0.6, 0.6, 0.6, 0.6)
    else
        tooltip:AddDoubleLine(self.ICON_BAD .. (r.sellVendor and L["Händler bringt mehr:"] or L["Verkaufen bringt mehr:"]),
            A:FormatMoney(sell), 1, 0.6, 0.2, 1, 0.6, 0.2)
        tooltip:AddDoubleLine(L["Entzaubern:"], A:FormatMoney(de), 0.6, 0.6, 0.6, 0.6, 0.6, 0.6)
    end
    return 2
end

-- LT1/LT2 (Entscheid des Nutzers 13.11. 20:11/20:12): EINE Zeile "Gewinn: ±x / Stück" ersetzt die zwei Zeilen
-- "Entzaubern lohnt (nicht) …" und "Lohnt bis …". Gerechnet mit dem Stückpreis des Angebots unter der Maus (Kaufliste,
-- Sniper, Schnäppchen, Zeile im alten Blizzard-AH), beim Händler mit dessen Preis, sonst mit dem Preis oben im Tooltip
-- (Taschen: Marktwert). Bester Weg nach Gebühren: Entzaubern (korrigierte Materialpreise) / Verkaufen / Händler.
-- Rot bei Verlust, grün ab 0c. Alles andere im Tooltip bleibt.
function TT:LivePrice(itemID)
    local c = self.buyContext
    if c and c.itemID == itemID and c.price and c.price > 0 then return c.price, "list" end
    local atMerchant = type(MerchantFrame) == "table" and MerchantFrame.IsShown and MerchantFrame:IsShown()
    if atMerchant then
        local v = A:GetVendorBuyPrice(itemID)
        if v and v > 0 then return v, "vendor" end
    end
    local cur, mv = A:GetCurrent(itemID), A:GetMarketValue(itemID)
    if self:OwnBagTooltip() then return mv or cur, "market" end
    return cur or mv, "market"
end
-- bester Weg nach Gebühren je Stück: Wert, Weg ("de", "sell", "vendor")
function TT:BestWayValue(itemID, r)
    -- SN2115b: dieselbe Wahl wie A:BestWay (A:ChooseWay); r = Urteil mit denselben Eingaben (DealValue, RealValue)
    if not r then return A:BestWay(itemID) end
    -- T-AB5 (Entscheid Supervisor 16.11. 22:32): die Gewinn-Zeile folgt A:BestWay - Weg aus (RK4) oder ohne Verzauberkunst nur
    -- Verkaufen/Händler. "Entzaubern: x" bleibt als Info (LB2), grau mit Zusatz (TT:AddWayLines).
    local deNet = r.net
    if deNet and r.wayDE == false then deNet = nil end
    return A:ChooseWay(deNet, r.stale, r.sellNet, r.sellVendor)
end
TT.PROFIT_GREEN = { 0.2, 0.87, 0.33 }
TT.PROFIT_RED = { 1, 0.33, 0.27 }
function TT:ProfitLine(itemID, r, price)
    local best, way = self:BestWayValue(itemID, r)
    if not (best and price and price > 0) then return nil end
    local g = math.floor(best - price + 0.5)
    return string.format(L["Gewinn: %s / Stück"], SignedMoney(g)), g >= 0 and self.PROFIT_GREEN or self.PROFIT_RED, g, way
end
function TT:AddProfitLine(tooltip, itemID, r, price)
    if not price then price = self:LivePrice(itemID) end
    local txt, col = self:ProfitLine(itemID, r, price)
    if not txt then return 0 end
    tooltip:AddLine(txt, col[1], col[2], col[3])
    return 1
end
-- "Materialpreise korrigiert ×0,57 …" (0.65.111 S1) bleibt als eigene Zeile
function TT:AddCorrLine(tooltip, r)
    if r and r.corr and r.corr < 1 then
        tooltip:AddLine("   " .. string.format(L["Materialpreise korrigiert ×%s (deine Entzauberungen bringen weniger als das tiefste Angebot)"],
            string.format("%.2f", r.corr):gsub("%.", ",")), 0.6, 0.6, 0.6, true)
        return 1
    end
    return 0
end
-- Stückpreis einer Zeile im alten Blizzard-AH (BrowseButtonNItem), nur lesen; sonst nil
function TT:AHRowPrice(tooltip, itemID)
    local ok, price = pcall(function()
        local owner = tooltip.GetOwner and tooltip:GetOwner()
        if type(owner) ~= "table" or not owner.GetName then return nil end
        local name = owner:GetName()
        local G = _G.GoldSentinelGame
        if G and G.AnySecret and G.AnySecret(name) then return nil end
        local n = type(name) == "string" and tonumber(name:match("^BrowseButton(%d+)Item$") or name:match("^BrowseButton(%d+)$"))
        if not n then return nil end
        local getInfo, getOffset = A:Global("GetAuctionItemInfo"), A:Global("FauxScrollFrame_GetOffset")
        local sf = A:Global("BrowseScrollFrame")
        if not getInfo then return nil end
        local idx = n + ((getOffset and sf) and (getOffset(sf) or 0) or 0)
        local info = { getInfo("list", idx) }
        local count, buyout, id = info[3], info[10], info[17]
        if id and id ~= itemID then return nil end
        if type(count) == "number" and count > 0 and type(buyout) == "number" and buyout > 0 then return math.floor(buyout / count) end
        return nil
    end)
    return ok and price or nil
end

function TT:AddVerdictLines(tooltip, itemID, all)
    local r = self:DisenchantVerdict(itemID)
    if not r then return 0 end
    -- LT2: Gewinn-Zeile statt "Entzaubern lohnt (nicht)" und "Lohnt bis"; Wege-Zeilen bleiben
    local n = self:AddProfitLine(tooltip, itemID, r)
    -- LT3 (Nutzer 20:22): "Materialpreise korrigiert ×0,57" nur noch mit Shift (Korrektur bleibt aktiv)
    if all then n = n + self:AddCorrLine(tooltip, r) end
    return n + self:AddWayLines(tooltip, r)
end

-- JK1: "Jetzt günstig – kaufen" usw. (A.Timing), sonst keine Zeile; mit Shift bei zu wenig Daten "noch N Tage messen"
function TT:AddTimingLine(tooltip, itemID, mode, all)
    local TMg = A.Timing
    if not TMg then return 0 end
    local sig, why, extra = TMg:Signal(itemID, mode)
    local txt, r, g, b = TMg:Text(sig)
    if txt then tooltip:AddLine(txt, r, g, b); return 1 end
    if all and why == "tage" and extra then
        tooltip:AddLine(string.format(L["Rhythmus: noch %d Tage messen"], extra), 0.6, 0.6, 0.6)
        return 1
    end
    return 0
end

-- LB1/LB3: "Lohnt bis" - mit veraltetem Hauptmaterial ohne Betrag
function TT:AddLimitLine(tooltip, r)
    if not r.limit and not r.stale then return end          -- RK4/S2-B3: kein "Lohnt bis"
    if r.stale then
        tooltip:AddDoubleLine(L["Lohnt bis"], L["Preise veraltet – erst scannen"], 0.8, 0.8, 0.8, 1, 0.6, 0.2)
    else
        tooltip:AddDoubleLine(L["Lohnt bis"], A:FormatMoney(r.limit), 0.8, 0.8, 0.8, 1, 0.82, 0)
    end
    -- 0.65.111 S1: Quelle sichtbar, wenn mit dem erzielbaren (korrigierten) Materialpreis gerechnet wird
    if r.corr and r.corr < 1 then
        tooltip:AddLine("   " .. string.format(L["Materialpreise korrigiert ×%s (deine Entzauberungen bringen weniger als das tiefste Angebot)"],
            string.format("%.2f", r.corr):gsub("%.", ",")), 0.6, 0.6, 0.6, true)
    end
end

-- Tooltip eines eigenen Taschen-Platzes? (gesetzt in TT:Handle über den Besitzer des Tooltips)
function TT:OwnBagTooltip() return self.bagTooltip == true end

-- Besitzer ist ein Taschen-Knopf? Modern: GetBagID am Knopf; alt: Name "ContainerFrameNItemM"
function TT:IsBagOwner(tooltip)
    local ok, res = pcall(function()
        local owner = tooltip.GetOwner and tooltip:GetOwner()
        if type(owner) ~= "table" then return false end
        if owner.GetBagID then return true end
        local name = owner.GetName and owner:GetName()
        local G = _G.GoldSentinelGame
        if G and G.AnySecret and G.AnySecret(name) then return false end
        if type(name) == "string" and name:match("^ContainerFrame%d+Item%d+$") then return true end
        return false
    end)
    return ok and res or false
end

-- Kaufpreis für "Gewinn beim Kauf": zuerst die Zeile, über der die Maus im Addon steht (Kaufliste, Sniper,
-- Schnäppchen: TT.buyContext), dann beim Händler dessen Preis, sonst das günstigste aktuelle Angebot (frisch)
TT.buyContext = nil
function TT:BuyPriceFor(itemID)
    local c = self.buyContext
    if c and c.itemID == itemID and c.price and c.price > 0 then return c.price, "list" end
    local atMerchant = type(MerchantFrame) == "table" and MerchantFrame.IsShown and MerchantFrame:IsShown()
    if atMerchant then
        local v = A:GetVendorBuyPrice(itemID)
        if v and v > 0 then return v, "vendor" end
    end
    local cur, _, t = A:GetCurrent(itemID)
    if cur and cur > 0 and t and time() - t <= A.PRICE_OLD_HOURS * 3600 then return cur, "ah" end
    return nil
end

-- Block "Entzaubern – Materialien (AHSentinel)" im Aussehen von "Mögliche Materialien": Icon · Name · Dropchance ·
-- Wert pro Stück (AH-Preis aus dem letzten Scan, sonst Marktwert). Chance aus derselben Quelle wie die Kurzzeile.
-- zurück: { { icon, name, chance (0-1), price, id }, ... }
function TT:DisenchantMats(itemID)
    local D = A.Disenchant
    local _, _, _, basis, n = D:DealValue(itemID)
    local out = {}
    if basis == "actual" then
        local _, _, nn, rows = D:ActualValue(itemID)
        for _, r in ipairs(rows or {}) do
            out[#out + 1] = { id = r.id, chance = r.times / nn, price = r.price, avg = r.total / r.times, source = r.source, unsure = r.unsure, extra = r.extra }
        end
    else
        for _, r in ipairs(D:EstimateRows(itemID) or {}) do
            out[#out + 1] = { id = r.id, chance = r.chance, price = r.price, avg = r.avg, min = r.min, max = r.max, source = r.source, unsure = r.unsure, extra = r.extra }
        end
    end
    for _, m in ipairs(out) do
        m.name = A:GetItemName(m.id) or ("#" .. m.id)
        m.icon = A.GetItemIcon and A:GetItemIcon(m.id) or nil
    end
    table.sort(out, function(a, b) return a.chance > b.chance end)
    return out, basis, n
end

-- Einstellung: "short" (nur die Zeile), "mats" (mit Materialien, Standard), "all" (ganze Aufstellung)
function TT:DEMode()
    local s = self:Settings() or {}
    local m = s.tooltipDEMode
    if m == "short" or m == "mats" or m == "all" then return m end
    if s.tooltipDEDetail == false then return "short" end     -- alte Einstellung (0.65.22-0.65.25)
    return "mats"
end

-- Block 2 (Urteil + Wege) und Block 3 (Materialien, ohne Shift - Variante A). all = Shift bzw. Einstellung "alles":
-- dazu Rechnung und Preisquellen. Rückgabe: Anzahl Zeilen (0 = nicht entzauberbar / kein Wert)
function TT:AddDisenchantLines(tooltip, itemID, mode, all)
    mode = mode or self:DEMode()
    if A.Spieltest and A.Spieltest.activeUntil then
        pcall(A.Spieltest.OnDETooltip, A.Spieltest, itemID, self:DisenchantLines(itemID, true))
    end
    if all == nil then
        local isShift = A:Global("IsShiftKeyDown")      -- über A:API: die Testroutine ersetzt nie die Blizzard-Funktion
        all = (isShift and isShift()) or mode == "all"
    end
    -- TT (21.11. 09:20): ohne Shift keine Wege-Zeilen ("Entzaubern:/Verkaufen:") und keine zweite Gewinn-Zeile; mit Shift wie bisher
    local n = 0
    if all then
        local r = self:DisenchantVerdict(itemID)
        if r then n = n + self:AddCorrLine(tooltip, r) + self:AddWayLines(tooltip, r) end
    end
    -- Block 3: Materialien - immer, ausser Einstellung "kurz"
    if mode ~= "short" or all then
        n = n + self:AddMaterialBlock(tooltip, itemID, all)
    end
    if all then
        -- H8: Gewinn nach Verkauf der Materialien (realistischer Materialpreis, nach Gebühren) mit Prozent
        local r = self:DisenchantVerdict(itemID)
        if r and r.buy and r.gain then
            tooltip:AddDoubleLine(L["Gewinn nach Verkauf der Materialien:"], GainText(r.gain, r.buy), 0.8, 0.8, 0.8,
                r.gain >= 0 and 0.2 or 1, r.gain >= 0 and 0.87 or 0.33, r.gain >= 0 and 0.33 or 0.27)
        end
        local short = self:DisenchantShort(itemID)
        if short then
            tooltip:AddDoubleLine("   " .. short.left, short.right, 0.6, 0.6, 0.6, 0.8, 0.8, 0.8)
            if short.gainLeft then tooltip:AddDoubleLine("   " .. short.gainLeft, short.gainRight, 0.6, 0.6, 0.6, 0.8, 0.8, 0.8) end
        end
        for _, l in ipairs(self:DisenchantLines(itemID, true)) do
            if l[3] then tooltip:AddDoubleLine(l[1], l[2], 0.6, 0.6, 0.6, 0.8, 0.8, 0.8)
            else tooltip:AddDoubleLine(l[1], l[2], 0.8, 0.8, 0.8, 1, 1, 1) end
        end
    end
    return n
end

-- Block 3 (TT-DE1, Entscheid des Nutzers 15.11. 00:09/00:10): Kopf "Materialien", je Material eine Zeile nach der
-- WoW-Forever-Vorgabe (Tabelle, Entscheid 10.11.: Rüstung 75/20/5, Waffe 20/75/5, bis Itemstufe 15 80/20):
-- "<von>–<bis> <Material>  <Chance %>" (bei gleicher Zahl nur "1 Splitter"), rechts Preis je Stück nach Gebühr.
-- Keine gemessenen Prozente, kein "× Ø", keine Preisquelle "Scan" - die eigenen Messungen rechnen weiter im Hintergrund
-- (Lernen, Entzaubern-Wert) und stehen im Testbericht. all (Shift): dazu die Preisquelle je Material und die Quelle der Chancen.
function TT:ForeverMats(itemID)
    local D = A.Disenchant
    local prior = D:Prior(itemID)
    local out = {}
    for _, e in ipairs(prior or {}) do
        if (e[2] or 0) > 0 then
            local price, _, _, src, unsure, _, extra = D:MatPrice(e[1])
            local lo = e[4] or math.floor((e[3] or 1) + 0.5)
            local hi = e[5] or lo
            out[#out + 1] = { id = e[1], chance = e[2], min = lo, max = hi, price = price, source = src, unsure = unsure, extra = extra,
                name = A:GetItemName(e[1]) or ("#" .. e[1]), icon = A.GetItemIcon and A:GetItemIcon(e[1]) or nil }
        end
    end
    table.sort(out, function(a, b) return a.chance > b.chance end)
    return out
end

-- Text links einer Materialzeile: "1–2 Visionenstaub" bzw. "1 Großer leuchtender Splitter"
function TT:MatRangeText(m)
    local qty = (m.min == m.max) and tostring(m.min) or (tostring(m.min) .. "–" .. tostring(m.max))
    return qty .. " " .. m.name
end

-- TT-DE2 (Nutzer 10:59 "Variante B, aber ohne die 10s76"): neben der Forever-Vorgabe die ECHTEN Ergebnisse der Gruppe.
-- Grundlage: eigene Entzauberungen der Gruppe (deStats, ohne geteilte); erst wenn eigene < 30, die geteilten dazu ("Gilde (n)");
-- Anteil = Entzauberungen mit diesem Material / n. Unter 30 Fällen statt Prozent grau "noch n/30".
TT.DE2_MIN = 30
function TT:OwnDEStats(key) return A.db and A.db.deStats and A.db.deStats[key] end     -- eigene Funktion (Seam für Tests)
function TT:MeasuredShares(itemID)
    local D = A.Disenchant
    local _, key = D:Prior(itemID)
    if not key then return nil end
    local own = self:OwnDEStats(key)
    local nOwn = own and own.n or 0
    if nOwn >= self.DE2_MIN then
        local share = {}
        for id, m in pairs(own.mats or {}) do share[id] = (m.times or 0) / nOwn end
        return { label = string.format(L["bei dir (%d)"], nOwn), n = nOwn, share = share }
    end
    local okC, no, ns, mats = pcall(D.Combined, D, key)
    local n = okC and (no + ns) or nOwn
    if okC and ns > 0 and n >= self.DE2_MIN then
        local share = {}
        for id, m in pairs(mats or {}) do share[id] = (m.times or 0) / n end
        return { label = string.format(L["Gilde (%d)"], n), n = n, share = share }
    end
    return { label = string.format(L["bei dir (%d)"], nOwn), n = nOwn, few = true }
end
-- TT6 (21.11. 09:20): Kopf "Materialien | Vorgabe  Ø  Preis"; Beschriftungen hellgrau, Vorgabe-Werte in der Farbe von "Vorgabe",
-- Ø und Preise weiss, rechtsbündig untereinander (Spalten mit unsichtbarem Abstandhalter auf gleiche Breite, gemessen).
-- Preis = günstigstes Angebot im letzten Scan (dieselbe Zahl wie in der Rechnung). TT5: "<Material>-Preis seit dem letzten Scan
-- gestiegen" als eigene gelbe Zeile, gemessen an den Scans (nicht an der Uhr).
TT.LABEL_COL = "|cffbfbfbf"
TT.VORG_COL = "|cff9fc5e8"
TT.COL_GAP = 12
local measureFS
local function TextW(t)
    local ok, w = pcall(function()
        if not measureFS then
            local f = CreateFrame("Frame", nil, UIParent)
            measureFS = f:CreateFontString(nil, "OVERLAY", "GameTooltipText")
            if measureFS.Hide then measureFS:Hide() end
        end
        measureFS:SetText(t)
        return measureFS:GetStringWidth()
    end)
    return (ok and type(w) == "number") and w or 0
end
local function Pad(px)
    px = math.floor((px or 0) + 0.5)
    if px <= 0 then return "" end
    return "|TInterface\\AddOns\\" .. (A.ADDON_NAME or "AHSentinel") .. "\\Media\\blank:1:" .. px .. "|t"
end
TT.Pad, TT.TextW = Pad, TextW
-- Zeilen mit Spalten rechtsbündig: rows = { { left, { cell1, cell2, ... } }, ... } -> rechte Texte gleich breit
function TT:AlignCells(rows)
    local widths = {}
    for _, r in ipairs(rows) do
        for c, cell in ipairs(r[2]) do
            local w = TextW(cell)
            r.w = r.w or {}
            r.w[c] = w
            if not widths[c] or w > widths[c] then widths[c] = w end
        end
    end
    local out = {}
    for i, r in ipairs(rows) do
        local parts = {}
        for c, cell in ipairs(r[2]) do
            parts[#parts + 1] = (c > 1 and Pad(self.COL_GAP) or "") .. Pad((widths[c] or 0) - (r.w and r.w[c] or 0)) .. cell
        end
        out[i] = table.concat(parts)
    end
    return out
end
-- TT5: erstes Scan-Datum, seit dem der Preis über dem Schwellwert liegt, und Zeit des letzten Scans
function TT:RiseText(id, name)
    local x = A:PriceHints(id)
    if not (x and x.fresh) then return nil end
    local mv = A:GetMarketValue(id)
    local cur, _, t = A:GetCurrent(id)
    if not (mv and cur and t) then return nil end
    local since = A:HighSince(id, mv * A.HINT_FRESH)
    if not since then return nil end
    local first = time() - since
    if first >= t then return string.format(L["%s-Preis seit dem letzten Scan gestiegen"], name) end
    return string.format(L["%s-Preis seit dem Scan vom %s gestiegen"], name, date("%d.%m. %H:%M", first))
end
function TT:AddMaterialBlock(tooltip, itemID, all)
    local mats = self:ForeverMats(itemID)
    if #mats == 0 then return 0 end
    tooltip:AddLine(" ")
    local ms = self:MeasuredShares(itemID)
    local comma = (A.uiLang or (GetLocale and GetLocale())) == "deDE"
    local LC, VC = self.LABEL_COL, self.VORG_COL
    local rows = { { LC .. L["Materialien"] .. "|r", { VC .. L["Vorgabe"] .. "|r", LC .. "Ø" .. "|r", LC .. L["Preis"] .. "|r" } } }
    local rise = {}
    for _, m in ipairs(mats) do
        local icon = m.icon and ("|T" .. tostring(m.icon) .. ":14:14:0:0|t ") or ""
        local pct = m.chance * 100
        local pctText = (pct >= 10 or pct == math.floor(pct)) and string.format("%d %%", pct + 0.5) or string.format("%.1f %%", pct)
        if comma then pctText = pctText:gsub("%.", ",") end
        local mt
        if not ms or ms.few then mt = "|cff777777" .. string.format(L["noch %d/%d"], ms and ms.n or 0, self.DE2_MIN) .. "|r"
        else mt = "|cffffffff" .. string.format("%d %%", math.floor((ms.share[m.id] or 0) * 100 + 0.5)) .. "|r" end
        local cur = A:GetCurrent(m.id)
        local price = cur and ("|cffffffff" .. A:FormatMoney(cur) .. "|r") or ("|cff999999" .. L["kein Preis"] .. "|r")
        rows[#rows + 1] = { icon .. "|cffffffff" .. self:MatRangeText(m) .. "|r", { VC .. pctText .. "|r", mt, price } }
        local okR, rt = pcall(self.RiseText, self, m.id, m.name)
        if okR and rt then rise[#rise + 1] = rt end
        if all and m.extra and (m.extra.scan or m.extra.mv) then
            local x = m.extra
            m.detail = string.format(L["%s%s%s · Marktwert %s"], x.ladder and L["Preisleiter"] or (L["Scan"] .. " " .. (x.scan and A:FormatMoney(x.scan) or "-")),
                x.qty and x.qty > 0 and string.format(L[", %d Stück"], x.qty) or "",
                x.perDay and string.format(L[", Absatz ~%s/Tag"], string.format("%.0f", x.perDay)) or "", x.mv and A:FormatMoney(x.mv) or "-")
        end
    end
    local right = self:AlignCells(rows)
    local n = 0
    for i, r in ipairs(rows) do
        tooltip:AddDoubleLine(r[1], right[i], 0.75, 0.75, 0.75, 1, 1, 1)
        n = n + 1
        local m = mats[i - 1]
        if all and m and m.detail then tooltip:AddLine("      " .. m.detail, 0.6, 0.6, 0.6); n = n + 1 end
    end
    for _, rt in ipairs(rise) do tooltip:AddLine(rt, 1, 0.82, 0); n = n + 1 end
    if all then
        local D = A.Disenchant
        local okS, srcText = pcall(D.ChanceSource, D, itemID)
        if okS and srcText then tooltip:AddLine("   " .. srcText, 0.6, 0.6, 0.6, true); n = n + 1 end
    end
    return n
end

-- Zusatzzeilen (Variante A: nur mit Shift bzw. "alles"): beim Händler kaufen, Verkaufschance, Bestand der Twinks.
-- Entzaubern steht in Block 2/3 (TT:AddBlock2).
function TT:AddExtraLines(tooltip, itemID, all)
    if not all then return end
    local s = self:Settings() or {}
    local atMerchant = type(MerchantFrame) == "table" and MerchantFrame.IsShown and MerchantFrame:IsShown()
    local buy = A:GetVendorBuyPrice(itemID)
    if buy and not atMerchant then
        tooltip:AddDoubleLine(L["Beim Händler kaufen"], A:FormatMoney(buy), 0.8, 0.8, 0.8, 1, 1, 1)
    end
    if s.tooltipChance ~= false and A.Comfort then
        local chance = A.Comfort:ChanceText(itemID)
        if chance then tooltip:AddDoubleLine(L["Verkaufschance (deine)"], chance, 0.8, 0.8, 0.8, 1, 1, 1) end
    end
    -- Hinweis 10.11. (Anweisung Angebot und Absatz): Bestand als eigener Abschnitt mit Überschrift (sah sonst aus wie ein
    -- Material), zusammen mit dem Wert in den Taschen (nicht stapelbar: hier; stapelbar steht er schon in Block 2)
    local bagLine
    local n = self:BagCount(itemID)
    if n >= 2 and not self:IsStackable(itemID) then
        local okT, total = pcall(A.RealValue, A, itemID, n)
        if okT and total then bagLine = { string.format(L["%d in den Taschen:"], n), A:FormatMoney(total) } end
    end
    local charsText, charsTotal
    if s.tooltipChars ~= false and A.Chars then
        local list, total = A.Chars:ItemCounts(itemID)
        local others = 0
        for _, c in ipairs(list) do if not c.me then others = others + 1 end end
        if others > 0 then
            local parts = {}
            for k, c in ipairs(list) do
                if k > 4 then table.insert(parts, "..."); break end
                local cn = c.bags + c.bank
                local where = (c.bank > 0 and c.bags == 0) and L[" (Bank)"] or ""
                table.insert(parts, c.name .. " " .. cn .. where)
            end
            charsText, charsTotal = table.concat(parts, ", "), total
        end
    end
    if bagLine or charsText then
        tooltip:AddLine(" ")
        tooltip:AddDoubleLine(L["Im Besitz:"], charsTotal and tostring(charsTotal) or "", 0.6, 0.6, 0.6, 0.8, 0.8, 0.8)
        if bagLine then tooltip:AddDoubleLine("   " .. bagLine[1], bagLine[2], 0.8, 0.8, 0.8, 1, 1, 1) end
        if charsText then tooltip:AddLine("   " .. charsText, 0.8, 0.8, 0.8) end
    end
end

-- Item-ID aus Tooltip-Daten oder Tooltip-Link
-- WoW Forever: geschützte Werte ("secret values") nie vergleichen, zerlegen oder als Schlüssel benutzen
local function AnySecret(...)
    local G = _G.GoldSentinelGame
    return G and G.AnySecret and G.AnySecret(...) or false
end

local function ItemIDOf(tooltip, data)
    if type(data) == "table" and type(data.id) == "number" then
        if AnySecret(data.id) then return nil end
        return data.id
    end
    if tooltip.GetItem then
        local ok, _, link = pcall(tooltip.GetItem, tooltip)
        if ok and type(link) == "string" and not AnySecret(link) then
            local id = link:match("item:(%d+)")
            if id then return tonumber(id) end
        end
    end
    return nil
end

local MAIN_TIPS = {}      -- Tooltips, unter denen das Diagramm erscheinen darf

function TT:Handle(tooltip, data)
    if not A.db or type(tooltip) ~= "table" or not tooltip.AddLine then return end
    local itemID = ItemIDOf(tooltip, data)
    if not itemID then return end
    -- jede Tooltip-Anzeige nur einmal ergänzen. Nicht nur am Item festmachen: Manche Clients
    -- (z. B. TBC Anniversary) bauen den Tooltip neu auf, ohne OnTooltipCleared auszulösen -
    -- dann fehlen unsere Zeilen wieder, und das erkennen wir an der Zeilenzahl.
    local n = tooltip.NumLines and tooltip:NumLines() or 0
    if tooltip.__ahapItem == itemID and tooltip.__ahapN and n >= tooltip.__ahapN then return end
    tooltip.__ahapItem = itemID
    -- N3: Zeit je Block messen, wenn die Testroutine es verlangt (TT.prof = {})
    local prof, clock = self.prof, debugprofilestop
    local t0 = prof and clock and clock()
    self.bagTooltip = self:IsBagOwner(tooltip)
    -- LT1: Zeile im alten Blizzard-AH -> mit dem Stückpreis dieses Angebots rechnen (nur gelesen)
    local rowCtx
    if not (self.buyContext and self.buyContext.itemID == itemID) then
        local rp = self:AHRowPrice(tooltip, itemID)
        if rp then rowCtx = true; self.buyContext = { itemID = itemID, price = rp } end
    end
    self.calcLines, self.bigText = nil, nil
    local okL, errL = pcall(self.AddLinesCached, self, tooltip, itemID)
    if rowCtx then self.buyContext = nil end
    self.bagTooltip = nil
    if not okL then error(errL, 0) end
    local t1 = prof and clock and clock()
    tooltip.__ahapN = tooltip.NumLines and tooltip:NumLines() or 0
    -- TT7 (Nutzer 21.11. 09:18): kein Preisverlauf im Tooltip mehr (Fenster und alles andere behalten ihn); stattdessen die Rechnung (TT2)
    if MAIN_TIPS[tooltip] then
        pcall(self.ApplyBig, self, tooltip)
        pcall(self.ShowCalc, self, tooltip)
    end
    if prof and t0 then
        local t2 = clock()
        prof.lines = (prof.lines or 0) + (t1 - t0)
        prof.chart = (prof.chart or 0) + (t2 - t1)
        prof.n = (prof.n or 0) + 1
    end
    -- Größe an die neuen Zeilen anpassen (sonst bleiben sie unsichtbar)
    if tooltip.__ahapN > n and tooltip.IsShown and tooltip:IsShown() and tooltip.Show then tooltip:Show() end
end

-- ------------------------------------------------------------
-- Zwischenspeicher je Item (Befund 22:25 Punkt 3: Tooltip 2,33 ms, Ziel < 2 ms). Die fertigen Zeilen werden je
-- Item und Zustand gemerkt (Preisdaten-Version, Shift, Taschen-Tooltip, Händler, Kaufzeile, Einstellungen,
-- Watchlist) und höchstens CACHE_TTL Sekunden wiederverwendet. Der Shift-Teil wird nur mit Shift gerechnet (all).
-- ------------------------------------------------------------
TT.CACHE_TTL = 10
TT.CACHE_MAX = 200
TT.cache, TT.cacheN = {}, 0
TT.cacheStamp = 0            -- steigt bei Einstellungen, Watchlist, Taschen
function TT:InvalidateCache() self.cacheStamp = self.cacheStamp + 1; wipe(self.cache); self.cacheN = 0 end

-- Recorder: sammelt AddLine/AddDoubleLine, damit dieselben Zeilen später wieder eingefügt werden können
local Recorder = {}
Recorder.__index = Recorder
function Recorder:AddLine(...) self.lines[#self.lines + 1] = { 1, select("#", ...), ... } end
function Recorder:AddDoubleLine(...) self.lines[#self.lines + 1] = { 2, select("#", ...), ... } end
function Recorder:NumLines() return #self.lines end
function Recorder:GetOwner() if self.tip and self.tip.GetOwner then return self.tip:GetOwner() end end
function Recorder:IsShown() return false end
function Recorder:Show() end

local function Replay(tooltip, lines)
    for _, l in ipairs(lines) do
        if l[1] == 1 then tooltip:AddLine(unpack(l, 3, l[2] + 2)) else tooltip:AddDoubleLine(unpack(l, 3, l[2] + 2)) end
    end
end

function TT:CacheKey(itemID)
    local s = self:Settings() or {}
    local isShift = A:Global("IsShiftKeyDown")
    local all = (isShift and isShift()) or self:DEMode() == "all"
    local atMerchant = type(MerchantFrame) == "table" and MerchantFrame.IsShown and MerchantFrame:IsShown()
    local c = self.buyContext
    local w = A.db.watchlist and A.db.watchlist[itemID]
    return table.concat({ itemID, all and 1 or 0, self.bagTooltip and 1 or 0, atMerchant and 1 or 0,
        (c and c.itemID == itemID and c.price) or 0, A:DataVersion(), self.cacheStamp, tostring(A.uiLang),
        tostring(s.tooltipInfo), tostring(s.tooltipVendor), self:DEMode(), tostring(s.tooltipChance), tostring(s.tooltipChars),
        w and (tostring(w.buyBelow) .. "/" .. tostring(w.sellAbove)) or "-", self:BagCount(itemID), self.boundTip and "b" or "-" }, "|")
end

function TT:CacheEnabled()
    if A.Spieltest and A.Spieltest.activeUntil then return false end           -- Spieltest hängt sich in die Berechnung
    local TR = A.TestRoutine
    if ((TR and TR.running) or (A.SelfTest and A.SelfTest.running)) and not self.testCache then return false end
    return true
end

function TT:AddLinesCached(tooltip, itemID)
    local okB0, bound = pcall(self.IsBoundTip, self, tooltip)                     -- S3
    self.boundTip = okB0 and bound or nil
    if not self:CacheEnabled() then return self:AddLines(tooltip, itemID) end
    local ok, key = pcall(self.CacheKey, self, itemID)
    if not ok then return self:AddLines(tooltip, itemID) end
    local now = GetTime and GetTime() or time()
    local e = self.cache[key]
    if e and now - e.t <= self.CACHE_TTL then
        self.cacheHits = (self.cacheHits or 0) + 1
        self.calcLines, self.bigText = e.calc, e.big
        return Replay(tooltip, e.lines)
    end
    local rec = setmetatable({ lines = {}, tip = tooltip }, Recorder)
    local okB, err = pcall(self.AddLines, self, rec, itemID)
    Replay(tooltip, rec.lines)
    if not okB then error(err, 0) end
    if self.cacheN >= self.CACHE_MAX then wipe(self.cache); self.cacheN = 0 end
    if not e then self.cacheN = self.cacheN + 1 end
    self.cache[key] = { t = now, lines = rec.lines, calc = self.calcLines, big = self.bigText }
end

A:On("SETTINGS_CHANGED", function() TT:InvalidateCache() end)
A:On("WATCHLIST_CHANGED", function() TT:InvalidateCache() end)
A:On("DATA_CHANGED", function() TT:InvalidateCache() end)        -- z. B. neue eigene Entzauberung
A:On("DE_LEARNED", function() TT:InvalidateCache() end)
A:On("LEDGER_CHANGED", function() TT:InvalidateCache() end)
do
    local f = CreateFrame("Frame")
    for _, ev in ipairs({ "BAG_UPDATE_DELAYED", "BANKFRAME_CLOSED", "MERCHANT_SHOW", "MERCHANT_CLOSED" }) do pcall(f.RegisterEvent, f, ev) end
    f:SetScript("OnEvent", function() TT:InvalidateCache() end)
end

local function Cleared(tooltip)
    tooltip.__ahapItem, tooltip.__ahapN = nil, nil
    TT:HideChart(tooltip)
    pcall(TT.HideCalc, TT, tooltip)
    pcall(TT.RestoreBig, TT, tooltip)
end

-- ------------------------------------------------------------
-- Einhängen (neue Clients: TooltipDataProcessor, ältere: OnTooltipSetItem)
-- ------------------------------------------------------------
function TT:Install()
    if self.installed then return end
    self.installed = true
    for _, tip in ipairs({ GameTooltip, ItemRefTooltip }) do
        if type(tip) == "table" then
            MAIN_TIPS[tip] = true
            if tip.HookScript then
                pcall(tip.HookScript, tip, "OnTooltipCleared", Cleared)
                pcall(tip.HookScript, tip, "OnHide", Cleared)
            end
        end
    end
    local handler = function(tooltip, data)
        local ok, err = pcall(TT.Handle, TT, tooltip, data)
        if not ok then
            A:ReportError("Tooltip", err)          -- jeden Fehler melden, der Chat-Hinweis bleibt einmalig
            if not TT.reported then
                TT.reported = true
                A:Print("Tooltip: " .. tostring(err))
            end
        end
    end
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, handler)
        self.mode = "TooltipDataProcessor"
    else
        local tips = { GameTooltip, ItemRefTooltip, ShoppingTooltip1, ShoppingTooltip2 }
        for _, tip in ipairs(tips) do
            if type(tip) == "table" and tip.HookScript then
                pcall(tip.HookScript, tip, "OnTooltipSetItem", function(t) handler(t) end)
                if not MAIN_TIPS[tip] then pcall(tip.HookScript, tip, "OnTooltipCleared", Cleared) end
            end
        end
        self.mode = "OnTooltipSetItem"
    end
    -- zusätzlich direkt an den Befehlen, die einen Item-Tooltip füllen: falls der Weg oben
    -- auf einem Client nicht greift (doppelte Zeilen verhindert Handle)
    local hooked = 0
    for _, tip in ipairs({ GameTooltip, ItemRefTooltip }) do
        if type(tip) == "table" then
            for _, m in ipairs({ "SetBagItem", "SetInventoryItem", "SetHyperlink", "SetItemByID", "SetAuctionItem",
                "SetAuctionSellItem", "SetMerchantItem", "SetBuybackItem", "SetLootItem", "SetInboxItem", "SetSendMailItem",
                "SetTradePlayerItem", "SetTradeTargetItem", "SetQuestItem", "SetQuestLogItem", "SetGuildBankItem" }) do
                if type(tip[m]) == "function" and pcall(hooksecurefunc, tip, m, function(t) handler(t) end) then hooked = hooked + 1 end
            end
        end
    end
    if hooked > 0 then self.mode = self.mode .. "+Set*" end
end

function TT:GetDebugText()
    return "Modus=" .. tostring(self.mode) .. ", Zeilen=" .. ((A.db and A.db.settings.tooltipInfo == false) and "aus" or "an")
        .. ", Händlerpreis=" .. ((A.db and A.db.settings.tooltipVendor == false) and "aus" or "an")
        .. ", Diagramm=" .. self:PeriodLabel()
end

A:On("READY", function() TT:Install() end)
