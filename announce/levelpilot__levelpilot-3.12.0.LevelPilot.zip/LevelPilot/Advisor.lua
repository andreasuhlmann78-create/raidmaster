-- LevelPilot - Assistent
-- Prueft laufend den Zustand des Charakters und gibt Hinweise:
-- Haltbarkeit, Taschenplatz, Taschen-Upgrades, Munition, Talentpunkte, Trainer,
-- moegliche Ausruestungs-Upgrades, Empfehlung bei Questbelohnungen, voller Questlog.

local _, LP = ...
local L = LP.L
local A = {}
LP:RegisterModule("Advisor", A)

A.hints = {}        -- aktive Hinweise, sortiert nach Wichtigkeit
local shown = {}    -- [schluessel] = Stufe (Toast nur bei neuem/schlimmerem Zustand)

local SEV_INFO, SEV_WARN, SEV_BAD = 1, 2, 3
A.SEV_INFO, A.SEV_WARN, A.SEV_BAD = SEV_INFO, SEV_WARN, SEV_BAD

-- weitere Pruefungen aus anderen Modulen: fn(add) wie die Pruefungen unten
A.providers = {}
function A:AddProvider(fn) self.providers[#self.providers + 1] = fn end
function A:Soon() LP:Throttle("advisor", 2, function() A:Run() end) end

------------------------------------------------------------------------
-- Hilfen
------------------------------------------------------------------------
local API = LP.API
local ContainerSlots, ContainerFree, ContainerLink = API.BagSlots, API.BagFree, API.BagLink

local function NavigateTo(entry, label)
    if not entry then return end
    local i, n, w = LP.Geo:ToWorld(entry.map, entry.x, entry.y)
    LP.Planner.priority = {
        t = "GOTO", map = entry.map, x = entry.x, y = entry.y, inst = i, n = n, w = w,
        text = label .. ": " .. (entry.name or "?"), key = "PRIO:" .. (entry.name or "") .. entry.map,
    }
    LP.Planner:Replan()
end

local function ServiceAction(kind, label)
    local v, d = LP.QuestDB:NearestService(kind)
    if not v then return nil, nil end
    local where = (v.name or "?") .. ", " .. LP.Geo:MapName(v.map) .. " (" .. LP:FormatDist(d) .. ")"
    return where, function() NavigateTo(v, label) end
end

------------------------------------------------------------------------
-- Einzelne Pruefungen
------------------------------------------------------------------------
local DUR_SLOTS = { 1, 3, 5, 6, 7, 8, 9, 10, 16, 17, 18 }

local function CheckDurability(add)
    if not LP.db.advDurability then return end
    local minPct, broken = 100, 0
    for _, slot in ipairs(DUR_SLOTS) do
        local cur, max = GetInventoryItemDurability(slot)
        if cur and max and max > 0 then
            local pct = cur / max * 100
            if pct < minPct then minPct = pct end
            if cur == 0 then broken = broken + 1 end
        end
    end
    if minPct <= LP.db.durWarn then
        local sev = (broken > 0 or minPct <= 10) and SEV_BAD or SEV_WARN
        local where, action = ServiceAction("repair", L["Reparieren"])
        local text = broken > 0 and (broken .. L[" Teil(e) kaputt – sofort reparieren!"])
            or string.format(L["Ausrüstung bei %d%% – bald reparieren"], minPct)
        if where then text = text .. L["\nNächster Reparatur-Händler: "] .. where end
        add("dur", sev, text, action, action and L["Hinführen"])
    end
    A.durability = minPct
end

local function RecommendedBagSize(level)
    if level < 10 then return 6 end
    if level < 20 then return 8 end
    if level < 30 then return 10 end
    if level < 40 then return 12 end
    return 14
end

local function CheckBags(add)
    if not LP.db.advBags then return end
    local free, total, equipped, smallest = 0, 0, 0, nil
    for bag = 0, 4 do
        local slots = ContainerSlots(bag)
        if slots and slots > 0 then
            local f, family = ContainerFree(bag)
            if family == 0 then free = free + f end
            total = total + slots
            if bag > 0 then
                equipped = equipped + 1
                if not smallest or slots < smallest then smallest = slots end
            end
        end
    end
    A.bagFree, A.bagTotal = free, total
    if free <= LP.db.bagWarn then
        local where, action = ServiceAction("vendor", L["Verkaufen"])
        local text = (free == 0 and L["Taschen voll!"] or (L["Nur noch "] .. free .. L[" Taschenplätze frei"])) .. L[" – graue Gegenstände verkaufen"]
        if where then text = text .. L["\nNächster Händler: "] .. where end
        add("bags", free == 0 and SEV_BAD or SEV_WARN, text, action, action and L["Hinführen"])
    end
    local level = LP:PlayerLevel() or 1
    if level >= 5 and equipped < 4 then
        add("bagslots", SEV_INFO, (4 - equipped) .. L[" Taschenplatz/-plätze leer – kaufe oder lege Taschen an"])
    elseif smallest and level >= 10 and smallest < RecommendedBagSize(level) then
        add("bagsize", SEV_INFO, L["Taschen-Upgrade empfohlen: deine kleinste Tasche hat nur "] .. smallest
            .. L[" Plätze (für dein Level sind "] .. RecommendedBagSize(level) .. L["+ üblich)"])
    end
end

local function CheckAmmo(add)
    if not LP.db.advAmmo then return end
    local _, classFile = UnitClass("player")
    if classFile ~= "HUNTER" then return end
    local ranged = GetInventoryItemLink("player", 18)
    if not ranged then return end
    local _, _, _, _, _, _, _, _, equipLoc = API.ItemInfo(ranged)
    if equipLoc == "INVTYPE_THROWN" then return end
    local count = GetInventoryItemCount("player", 0) or 0
    A.ammo = count
    if count <= LP.db.ammoWarn then
        local where, action = ServiceAction("vendor", L["Munition kaufen"])
        local text = (count == 0 and L["Keine Munition!"] or (L["Nur noch "] .. count .. L[" Munition"])) .. L[" – nachkaufen"]
        if where then text = text .. L["\nNächster Händler: "] .. where end
        add("ammo", count == 0 and SEV_BAD or SEV_WARN, text, action, action and L["Hinführen"])
    end
end

local function CheckTalents(add)
    if not LP.db.advTalents then return end
    local points = API.TalentPoints()
    if points and points > 0 then
        add("talents", SEV_INFO, points .. L[" Talentpunkt(e) frei – Talente verteilen (Taste N)"])
    end
end

local function CheckTrainer(add)
    if not LP.db.advTrainer then return end
    local level = LP:PlayerLevel() or 1
    if level >= 2 and level % 2 == 0 and (LP.char.trainerLevel or 0) < level then
        add("trainer", SEV_INFO, L["Neue Fähigkeiten beim Klassentrainer verfügbar (Level "] .. level .. ")")
    end
end

local function CheckQuestLog(add)
    -- Dungeon-Quests, deren Zeit vorbei ist (grau oder Dungeon nicht betretbar)
    local level = LP:PlayerLevel() or 1
    for _, q in ipairs(API.Quests()) do
        local area = not q.complete and LP.QuestDB:QuestDungeon(q.id)
        if area then
            local info = LP.QuestDB:Get(q.id)
            local ql = info and info.level or 0
            local grey = ql > 0 and ql < level - API.GreenRange(level)
            if grey or not LP.Planner:DungeonUsable(area) or LP.Planner.dungeonDead[q.id] then
                local d = LP.QuestDB:Dungeon(area)
                add("dgq" .. q.id, SEV_INFO, L["Dungeon-Quest \""] .. (q.title or "?") .. "\" (" .. (d and d.name or L["Dungeon"])
                    .. L[") lohnt sich nicht mehr – im Questlog abbrechen, um Platz zu schaffen"])
            end
        end
    end
    local n, max = API.QuestCount(), API.MaxQuests()
    if n >= max - 2 then
        add("questlog", n >= max and SEV_WARN or SEV_INFO, L["Questlog fast voll ("] .. n .. "/" .. max .. L[") – graue oder liegengebliebene Quests abbrechen"])
    end
end

------------------------------------------------------------------------
-- Ausruestungs-Upgrades
------------------------------------------------------------------------
local SLOT_OF = {
    INVTYPE_HEAD = { 1 }, INVTYPE_NECK = { 2 }, INVTYPE_SHOULDER = { 3 }, INVTYPE_CHEST = { 5 },
    INVTYPE_ROBE = { 5 }, INVTYPE_WAIST = { 6 }, INVTYPE_LEGS = { 7 }, INVTYPE_FEET = { 8 },
    INVTYPE_WRIST = { 9 }, INVTYPE_HAND = { 10 }, INVTYPE_FINGER = { 11, 12 }, INVTYPE_TRINKET = { 13, 14 },
    INVTYPE_CLOAK = { 15 }, INVTYPE_WEAPON = { 16, 17 }, INVTYPE_2HWEAPON = { 16 }, INVTYPE_WEAPONMAINHAND = { 16 },
    INVTYPE_WEAPONOFFHAND = { 17 }, INVTYPE_SHIELD = { 17 }, INVTYPE_HOLDABLE = { 17 },
    INVTYPE_RANGED = { 18 }, INVTYPE_RANGEDRIGHT = { 18 }, INVTYPE_THROWN = { 18 }, INVTYPE_RELIC = { 18 },
}

-- Ruestungsklassen: 1 Stoff, 2 Leder, 3 Schwere Ruestung, 4 Platte, 6 Schild
local ARMOR = {
    WARRIOR = { 1, 2, 3, 6, plate = 40 }, PALADIN = { 1, 2, 3, 6, plate = 40 },
    HUNTER = { 1, 2, mail = 40 }, SHAMAN = { 1, 2, 6, mail = 40 },
    ROGUE = { 1, 2 }, DRUID = { 1, 2 }, PRIEST = { 1 }, MAGE = { 1 }, WARLOCK = { 1 },
}

local function CanWearArmor(subclass)
    local _, classFile = UnitClass("player")
    local level = LP:PlayerLevel() or 1
    local a = ARMOR[classFile]
    if not a then return true end
    if subclass == 0 then return true end           -- Verschiedenes (Schmuck, Umhang)
    for _, s in ipairs(a) do if s == subclass then return true end end
    if subclass == 4 and a.plate and level >= a.plate then return true end
    if subclass == 3 and a.mail and level >= a.mail then return true end
    return false
end

-- Wertgewichte je Klasse (Leveln): was der Klasse etwas bringt. Intelligenz fuer Krieger = 0,
-- Staerke fuer Magier = 0 usw. Ruestung und Waffen-DPS gehen mit ein.
local W = {
    WARRIOR = { STR = 1.0, AGI = 0.6, STA = 0.8, INT = 0,   SPI = 0.05, AP = 0.5, ARMOR = 0.025, DPS = 2.2 },
    PALADIN = { STR = 1.0, AGI = 0.4, STA = 0.8, INT = 0.5, SPI = 0.2,  AP = 0.5, ARMOR = 0.02, DPS = 2.0, SP = 0.3, HEAL = 0.2 },
    HUNTER  = { STR = 0.2, AGI = 1.0, STA = 0.6, INT = 0.3, SPI = 0.1,  AP = 0.3, RAP = 0.5, ARMOR = 0.015, DPS = 0.6, RDPS = 2.4 },
    ROGUE   = { STR = 0.5, AGI = 1.0, STA = 0.6, INT = 0,   SPI = 0,    AP = 0.5, ARMOR = 0.015, DPS = 2.4 },
    PRIEST  = { STR = 0,   AGI = 0,   STA = 0.5, INT = 1.0, SPI = 0.9,  SP = 0.9, HEAL = 0.5, MP5 = 1.5, ARMOR = 0.005, WDPS = 1.2 },
    SHAMAN  = { STR = 0.6, AGI = 0.4, STA = 0.6, INT = 0.8, SPI = 0.3,  AP = 0.4, SP = 0.6, MP5 = 1.0, ARMOR = 0.015, DPS = 1.8 },
    MAGE    = { STR = 0,   AGI = 0,   STA = 0.5, INT = 1.0, SPI = 0.6,  SP = 1.0, MP5 = 1.2, ARMOR = 0.005, WDPS = 1.2 },
    WARLOCK = { STR = 0,   AGI = 0,   STA = 0.9, INT = 0.8, SPI = 0.6,  SP = 1.0, MP5 = 1.0, ARMOR = 0.005, WDPS = 1.2 },
    DRUID   = { STR = 0.6, AGI = 0.6, STA = 0.6, INT = 0.7, SPI = 0.4,  AP = 0.4, SP = 0.5, HEAL = 0.3, MP5 = 1.0, ARMOR = 0.015, DPS = 1.0 },
}
local STATKEY = {
    ITEM_MOD_STRENGTH_SHORT = "STR", ITEM_MOD_AGILITY_SHORT = "AGI", ITEM_MOD_STAMINA_SHORT = "STA",
    ITEM_MOD_INTELLECT_SHORT = "INT", ITEM_MOD_SPIRIT_SHORT = "SPI", RESISTANCE0_NAME = "ARMOR",
    ITEM_MOD_ATTACK_POWER_SHORT = "AP", ITEM_MOD_RANGED_ATTACK_POWER_SHORT = "RAP",
    ITEM_MOD_SPELL_POWER_SHORT = "SP", ITEM_MOD_SPELL_DAMAGE_DONE_SHORT = "SP", ITEM_MOD_SPELL_HEALING_DONE_SHORT = "HEAL",
    ITEM_MOD_HEALING_DONE_SHORT = "HEAL", ITEM_MOD_MANA_REGENERATION_SHORT = "MP5", ITEM_MOD_POWER_REGEN0_SHORT = "MP5",
    ITEM_MOD_DAMAGE_PER_SECOND_SHORT = "DPS",
}
A.WEIGHTS = W

-- Haupt-Ruestungstyp je Klasse (1 Stoff, 2 Leder, 3 Schwere Ruestung, 4 Platte); ab Level 40 hoeher
local MAIN_ARMOR = { WARRIOR = { 3, 4 }, PALADIN = { 3, 4 }, HUNTER = { 2, 3 }, SHAMAN = { 2, 3 },
                     ROGUE = { 2, 2 }, DRUID = { 2, 2 }, PRIEST = { 1, 1 }, MAGE = { 1, 1 }, WARLOCK = { 1, 1 } }
local LOWER_ARMOR = 0.7       -- leichtere Ruestung als der Haupttyp zaehlt weniger
local MIN_GAIN = 2            -- so viel besser muss ein Upgrade mindestens sein

-- Wertung eines Gegenstands fuer die eigene Klasse; liefert Wertung, Werte-Tabelle
function A:ItemScore(link, slot)
    local _, classFile = UnitClass("player")
    local w = W[classFile] or W.WARRIOR
    local stats = API.ItemStats(link)
    if not stats then return nil end
    local score, vals = 0, {}
    for key, v in pairs(stats) do
        local k = STATKEY[key]
        if k and type(v) == "number" then
            vals[k] = (vals[k] or 0) + v
            local weight
            if k == "DPS" then
                if slot == 18 then weight = w.RDPS or w.WDPS or 0.3 else weight = w.DPS or 0.3 end
            else
                weight = w[k] or 0
            end
            score = score + v * weight
        end
    end
    local _, _, _, _, _, _, _, _, equipLoc, _, _, classID, subclassID = API.ItemInfo(link)
    local main = MAIN_ARMOR[classFile]
    if main and classID == 4 and subclassID and subclassID >= 1 and subclassID <= 4 and equipLoc ~= "INVTYPE_CLOAK" then
        local want = (LP:PlayerLevel() or 1) >= 40 and main[2] or main[1]
        if subclassID < want then score = score * LOWER_ARMOR end
    end
    return score, vals
end

local SHOW = { "STR", "AGI", "STA", "INT", "SPI" }
local SHOWNAME = { STR = "ITEM_MOD_STRENGTH_SHORT", AGI = "ITEM_MOD_AGILITY_SHORT", STA = "ITEM_MOD_STAMINA_SHORT",
                   INT = "ITEM_MOD_INTELLECT_SHORT", SPI = "ITEM_MOD_SPIRIT_SHORT" }

-- Bewertung eines Gegenstands fuer den Spieler: Verbesserung der Klassen-Wertung (oder nil, Grund)
function A:UpgradeValue(link)
    if not link then return nil end
    local _, _, quality, ilvl, reqLevel, _, _, _, equipLoc, _, _, classID, subclassID = API.ItemInfo(link)
    if not ilvl or not equipLoc or not SLOT_OF[equipLoc] then return nil end
    if (reqLevel or 0) > (LP:PlayerLevel() or 1) then return nil, "level" end
    if classID == 4 and not CanWearArmor(subclassID) then return nil, "armor" end
    local usable, why = API.CanUseItem(link)
    if not usable then return nil, why end
    -- schlechtester belegter Platz (bei Ringen/Schmuck/Einhand den schwaecheren ersetzen)
    local worst, worstScore, worstIlvl
    for _, slot in ipairs(SLOT_OF[equipLoc]) do
        local cur = GetInventoryItemLink("player", slot)
        local sc, il = 0, 0
        if cur then
            sc = self:ItemScore(cur, slot) or 0
            il = select(4, API.ItemInfo(cur)) or 0
        end
        if not worstScore or sc < worstScore then worst, worstScore, worstIlvl = slot, sc, il end
    end
    local newScore, vals = self:ItemScore(link, worst)
    if not newScore then
        -- keine Werte bekannt (noch nicht im Zwischenspeicher): nur Itemlevel
        local delta = ilvl - (worstIlvl or 0)
        return delta >= 3 and delta or nil, nil, ilvl, worstIlvl, classID
    end
    -- nur, was der Klasse etwas bringt: deutlich bessere Wertung
    local gain = newScore - (worstScore or 0)
    if gain < math.max(MIN_GAIN, (worstScore or 0) * 0.05) then return nil, "worse" end
    return gain, vals, ilvl, worstIlvl, classID
end

function A:StatSummary(vals)
    if not vals then return "" end
    local parts = {}
    local _, classFile = UnitClass("player")
    local w = W[classFile] or W.WARRIOR
    for _, k in ipairs(SHOW) do
        if vals[k] and vals[k] ~= 0 and (w[k] or 0) > 0 then
            parts[#parts + 1] = "+" .. vals[k] .. " " .. (_G[SHOWNAME[k]] or k)
        end
    end
    if vals.DPS then parts[#parts + 1] = string.format("%.1f DPS", vals.DPS) end
    return table.concat(parts, ", ")
end

-- Gegenstaende, die beim Einloggen schon in der Tasche liegen, werden nie als Upgrade vorgeschlagen
-- (man hat sie meist absichtlich dabei); nur, was danach dazukommt (Beute, Kauf, Post)
local LOGIN_WINDOW = 20        -- Sekunden nach dem Einloggen: alles in der Tasche gilt als "schon da"
local atLogin, loginT = {}, nil
local function SnapshotBags()
    for bag = 0, 4 do
        for slot = 1, (ContainerSlots(bag) or 0) do
            local link = ContainerLink(bag, slot)
            if link then atLogin[link] = true end
        end
    end
end
A.SnapshotBags = SnapshotBags
function A:ResetLogin() wipe(atLogin) loginT = GetTime() end

local function CheckUpgrades(add)
    if not LP.db.advUpgrades then return end
    if not loginT then loginT = GetTime() end
    if GetTime() - loginT <= LOGIN_WINDOW then SnapshotBags() end
    for bag = 0, 4 do
        for slot = 1, (ContainerSlots(bag) or 0) do
            local link = ContainerLink(bag, slot)
            if link and not atLogin[link] and API.IsEquippable(link) then
                local gain, vals = A:UpgradeValue(link)
                if gain then
                    local sum = A:StatSummary(vals)
                    add("up:" .. link, SEV_INFO,
                        L["Mögliches Upgrade für deine Klasse: "] .. link .. (sum ~= "" and ("\n" .. sum) or ""),
                        function()
                            if InCombatLockdown and InCombatLockdown() then
                                LP:Print(L["Im Kampf nicht möglich."])
                                return
                            end
                            API.Equip(link)
                        end, L["Anlegen"])
                end
            end
        end
    end
end

------------------------------------------------------------------------
-- Questbelohnung empfehlen
------------------------------------------------------------------------
function A:RecommendReward()
    local n = GetNumQuestChoices()
    if n <= 1 then return end
    local best, bestScore, reason
    for i = 1, n do
        local link = GetQuestItemLink("choice", i)
        if link then
            local gain, vals = self:UpgradeValue(link)
            local sell = select(11, API.ItemInfo(link)) or 0
            local score, why
            if gain and gain > 0 then
                score = 100000 + gain * 1000 + sell
                local sum = self:StatSummary(vals)
                why = L["Upgrade für deine Klasse"] .. (sum ~= "" and (" (" .. sum .. ")") or "")
            else
                -- nichts Passendes: was sich am besten verkaufen laesst
                score = sell
                why = L["höchster Verkaufswert"]
            end
            if not bestScore or score > bestScore then best, bestScore, reason = i, score, why end
        end
    end
    if best then
        local link = GetQuestItemLink("choice", best)
        LP:Print(L["Belohnungs-Empfehlung: "] .. (link or "?") .. " – " .. reason)
        if LP.UI and LP.UI.Toast then
            LP.UI:Toast({ key = "reward", sev = SEV_INFO, text = L["Belohnung: "] .. (link or "?") .. "\n" .. reason })
        end
    end
end

------------------------------------------------------------------------
-- Gesamtpruefung
------------------------------------------------------------------------
function A:Run()
    local list = {}
    local function add(key, sev, text, action, actionLabel)
        list[#list + 1] = { key = key, sev = sev, text = text, action = action, actionLabel = actionLabel }
    end
    CheckDurability(add)
    CheckBags(add)
    CheckAmmo(add)
    CheckTalents(add)
    CheckTrainer(add)
    CheckQuestLog(add)
    CheckUpgrades(add)
    for _, fn in ipairs(self.providers) do
        local ok, err = pcall(fn, add)
        if not ok then LP:Debug("Hinweis-Pruefung: " .. tostring(err)) end
    end
    table.sort(list, function(a, b) return a.sev > b.sev end)
    self.hints = list

    -- Toast nur fuer neue oder schlimmer gewordene Hinweise
    local active = {}
    for _, h in ipairs(list) do
        active[h.key] = true
        if (shown[h.key] or 0) < h.sev then
            shown[h.key] = h.sev
            if LP.UI and LP.UI.Toast then LP.UI:Toast(h) end
        end
    end
    for k in pairs(shown) do if not active[k] then shown[k] = nil end end
    LP:Fire("HINTS_CHANGED")
end

function A:Init()
    local function soon() LP:Throttle("advisor", 2, function() A:Run() end) end
    for _, ev in ipairs({ "UPDATE_INVENTORY_DURABILITY", "BAG_UPDATE_DELAYED", "PLAYER_LEVEL_UP",
                          "CHARACTER_POINTS_CHANGED", "PLAYER_EQUIPMENT_CHANGED", "QUEST_LOG_UPDATE",
                          "UNIT_INVENTORY_CHANGED", "MERCHANT_CLOSED" }) do
        LP:On(ev, soon)
    end
    LP:On("TRAINER_SHOW", function()
        LP.char.trainerLevel = LP:PlayerLevel() or 0
        soon()
    end)
    LP:On("MERCHANT_SHOW", function()
        -- am Haendler: Navigationsziel "Reparieren/Verkaufen" ist erreicht
        local p = LP.Planner.priority
        if p and p.key and p.key:find("^PRIO:") then
            LP.Planner.priority = nil
            LP.Planner:Replan()
        end
    end)
    -- Einloggen / Neuladen: Tascheninhalt merken (wird nicht vorgeschlagen)
    LP:On("PLAYER_ENTERING_WORLD", function(_, isLogin, isReload)
        if isLogin or isReload then
            A:ResetLogin()
            C_Timer.After(3, SnapshotBags)
        end
    end)
    C_Timer.After(5, function() A:Run() end)
    C_Timer.NewTicker(30, function() A:Run() end)
end
