-- LevelPilot - Grundnetz: Zonenuebergaenge, Paesse, Tunnel, Schiffe
-- Jeder Eintrag verbindet einen Punkt in Zone A mit einem Punkt in Zone B.
-- Innerhalb einer Zone sucht die Wegfindung Luftlinien zwischen Knoten; zwischen
-- Zonen nur ueber diese Uebergaenge (oder ueber selbst gelaufene Wege).
-- Koordinaten in WoW-Forever-Kartenkoordinaten. Bei Strassen und Paessen liegen beide Enden an
-- derselben Stelle der Zonengrenze (berechnet aus den Gelaendekarten beider Zonen: dort, wo
-- begehbares Gelaende beider Zonen aufeinandertrifft); Tunnel, Aufzuege und Bruecken verbinden
-- die beiden Enden. Selbst gelaufene Wege gehen immer vor.
--
-- Format: { mapA, xA, yA, mapB, xB, yB, art, sekunden, fraktion, name }
--   art: "walk" = zu Fuss, "boat" = Schiff, "zep" = Zeppelin, "tram" = Tiefenbahn, "portal" = Portal
--   sekunden: Reise-/Wartezeit (nur Schiff/Zeppelin): mittlere Wartezeit (halbe Taktzeit) + Fahrt + Ladebildschirm,
--   fraktion: "Alliance"/"Horde"/nil (Allianz-Schiffe fuehren durch Allianz-Haefen: fuer die Horde gesperrt)

local _, LP = ...

-- Karten-IDs
local DUROTAR, MULGORE, BARRENS = 1411, 1412, 1413
local ALTERAC, ARATHI, BADLANDS, BLASTED = 1416, 1417, 1418, 1419
local TIRISFAL, SILVERPINE, WPL, EPL = 1420, 1421, 1422, 1423
local HILLSBRAD, HINTERLANDS, DUNMOROGH, SEARING = 1424, 1425, 1426, 1427
local BURNING, ELWYNN, DEADWIND, DUSKWOOD = 1428, 1429, 1430, 1431
local LOCH, REDRIDGE, STV, SWAMP, WESTFALL, WETLANDS = 1432, 1433, 1434, 1435, 1436, 1437
local TELDRASSIL, DARKSHORE, ASHENVALE, NEEDLES = 1438, 1439, 1440, 1441
local STONETALON, DESOLACE, FERALAS, DUSTWALLOW = 1442, 1443, 1444, 1445
local TANARIS, AZSHARA, FELWOOD, UNGORO = 1446, 1447, 1448, 1449
local MOONGLADE, SILITHUS, WINTERSPRING = 1450, 1451, 1452
local STORMWIND, ORGRIMMAR, IRONFORGE, THUNDERBLUFF, DARNASSUS, UNDERCITY = 1453, 1454, 1455, 1456, 1457, 1458

LP.Gateways = {
    -- ================= Oestliche Koenigreiche =================
    { ELWYNN, 31.5, 48.5, STORMWIND, 73.5, 91.5, "walk", nil, nil, "Tor von Sturmwind" },
    { ELWYNN, 20.4, 80.3, WESTFALL, 62.0, 19.0, "walk", nil, nil, "Brücke Elwynn–Westfall" },
    { ELWYNN, 32.8, 85.6, DUSKWOOD, 19.6, 18.0, "walk", nil, nil, "Brücke Elwynn–Dämmerwald" },
    { ELWYNN, 93.5, 72.5, REDRIDGE, 2.5, 71.5, "walk", nil, nil, "Dreiecksweg (Rotkamm)" },
    { WESTFALL, 67.5, 62.5, DUSKWOOD, 7.5, 63.5, "walk", nil, nil, "Pfad zum Rabenhügel" },
    { DUSKWOOD, 45.0, 88.5, STV, 39.0, 2.0, "walk", nil, nil, "Straße ins Schlingendorntal" },
    { DUSKWOOD, 88.0, 41.0, DEADWIND, 31.0, 30.0, "walk", nil, nil, "Gebirgspass der Totenwinde" },
    { DEADWIND, 62.0, 75.0, SWAMP, 4.0, 62.0, "walk", nil, nil, "Pass zu den Sümpfen" },
    { SWAMP, 34.0, 66.0, BLASTED, 50.5, 7.0, "walk", nil, nil, "Straße zu den Verwüsteten Landen" },
    { REDRIDGE, 41.5, 7.5, BURNING, 78.5, 76.5, "walk", nil, nil, "Pfad zur Brennenden Steppe" },
    -- Sengende Schlucht hatte keinen Uebergang (gefunden mit der virtuellen Reise): durch den Schwarzfels
    -- (Blackrock Mountain) zur Brennenden Steppe. Classic-Koordinaten der beiden Eingaenge, im Spiel pruefen.
    { SEARING, 34.8, 84.0, BURNING, 29.5, 38.0, "walk", nil, nil, "Schwarzfels (Blackrock Mountain)" },
    { DUNMOROGH, 53.2, 35.0, IRONFORGE, 18.0, 51.0, "walk", nil, nil, "Tor von Eisenschmiede" },
    { DUNMOROGH, 84.6, 50.7, LOCH, 21.0, 76.0, "walk", nil, nil, "Tunnel Nordtorposten" },
    { LOCH, 25.5, 1.5, WETLANDS, 55.5, 85.5, "walk", nil, nil, "Dun Algaz" },
    { LOCH, 47.0, 77.0, BADLANDS, 46.0, 8.0, "walk", nil, nil, "Pass ins Ödland" },
    { WETLANDS, 51.0, 10.0, ARATHI, 43.5, 91.5, "walk", nil, nil, "Thandolübergang" },
    { ARATHI, 20.5, 29.5, HILLSBRAD, 82.5, 57.5, "walk", nil, nil, "Straße Arathi–Hügelland" },
    { HILLSBRAD, 87.5, 31.0, HINTERLANDS, 9.5, 59.0, "walk", nil, nil, "Pfad ins Hinterland" },
    { HILLSBRAD, 13.5, 46.5, SILVERPINE, 67.0, 77.5, "walk", nil, nil, "Straße Silberwald–Hügelland" },
    { HILLSBRAD, 55.0, 23.0, ALTERAC, 54.0, 82.0, "walk", nil, nil, "Pass ins Alteracgebirge" },
    { SILVERPINE, 67.5, 4.5, TIRISFAL, 54.0, 76.0, "walk", nil, nil, "Straße Tirisfal–Silberwald" },
    { TIRISFAL, 61.8, 65.0, UNDERCITY, 66.0, 1.0, "walk", nil, nil, "Ruinen von Lordaeron" },
    { TIRISFAL, 83.5, 70.0, WPL, 27.5, 57.5, "walk", nil, nil, "Das Bollwerk" },
    { WPL, 65.5, 32.5, EPL, 3.5, 42.5, "walk", nil, nil, "Thondroril" },
    { STORMWIND, 64.0, 8.0, IRONFORGE, 76.0, 51.0, "tram", 70, nil, "Tiefenbahn" },

    -- ================= Kalimdor =================
    { DUROTAR, 45.5, 12.0, ORGRIMMAR, 50.0, 92.0, "walk", nil, nil, "Tor von Orgrimmar" },
    { DUROTAR, 34.0, 42.5, BARRENS, 62.0, 19.0, "walk", nil, nil, "Brücke Durotar–Brachland" },
    { BARRENS, 39.5, 47.5, MULGORE, 62.5, 45.5, "walk", nil, nil, "Straße nach Mulgore" },
    { MULGORE, 37.5, 27.5, THUNDERBLUFF, 33.5, 2.5, "walk", nil, nil, "Aufzug Donnerfels" },
    { BARRENS, 48.5, 5.5, ASHENVALE, 70.5, 86.0, "walk", nil, nil, "Straße Brachland–Eschental" },
    { BARRENS, 34.0, 27.5, STONETALON, 71.0, 94.0, "walk", nil, nil, "Pass ins Steinkrallengebirge" },
    { BARRENS, 50.5, 78.5, DUSTWALLOW, 28.5, 47.5, "walk", nil, nil, "Straße zu den Düstermarschen" },
    { BARRENS, 44.5, 91.0, NEEDLES, 32.0, 22.0, "walk", nil, nil, "Die Große Plattform" },
    { ASHENVALE, 29.0, 13.0, DARKSHORE, 43.5, 92.0, "walk", nil, nil, "Straße Eschental–Dunkelküste" },
    { ASHENVALE, 53.5, 27.5, FELWOOD, 52.5, 91.5, "walk", nil, nil, "Straße zum Teufelswald" },
    { ASHENVALE, 94.5, 49.5, AZSHARA, 10.5, 76.5, "walk", nil, nil, "Pass nach Azshara" },
    { ASHENVALE, 42.5, 71.0, STONETALON, 80.0, 44.0, "walk", nil, nil, "Talondeep-Pfad (Tunnel)" },
    { STONETALON, 30.5, 77.5, DESOLACE, 54.5, 3.5, "walk", nil, nil, "Pass nach Desolace" },
    { DESOLACE, 42.5, 97.5, FERALAS, 44.5, 2.5, "walk", nil, nil, "Straße nach Feralas" },
    { FERALAS, 90.5, 47.5, NEEDLES, 9.5, 20.5, "walk", nil, nil, "Pfad nach Tausend Nadeln" },
    { NEEDLES, 75.5, 95.5, TANARIS, 52.5, 21.5, "walk", nil, nil, "Straße nach Tanaris" },
    { TANARIS, 33.5, 34.5, UNGORO, 82.5, 60.5, "walk", nil, nil, "Abstieg in den Krater" },
    { UNGORO, 18.5, 37.5, SILITHUS, 75.5, 39.5, "walk", nil, nil, "Pfad nach Silithus" },
    { FELWOOD, 64.5, 7.5, WINTERSPRING, 27.5, 34.5, "walk", nil, nil, "Holzschlundfeste (Tunnel)" },
    { FELWOOD, 65.0, 2.0, MOONGLADE, 36.0, 72.0, "walk", nil, nil, "Pfad zur Mondlichtung" },
    { TELDRASSIL, 55.0, 90.0, DARNASSUS, 85.0, 80.0, "portal", 5, nil, "Portal Rut'theran–Darnassus" },
    { TELDRASSIL, 34.5, 55.5, DARNASSUS, 83.5, 40.5, "walk", nil, nil, "Tor von Darnassus" },

    -- ================= Schiffe & Zeppeline =================
    { TELDRASSIL, 55.3, 94.5, DARKSHORE, 33.2, 40.0, "boat", 240, "Alliance", "Schiff Rut'theran–Auberdun" },
    { DARKSHORE, 32.5, 43.8, WETLANDS, 4.6, 57.0, "boat", 360, "Alliance", "Schiff Auberdun–Menethil" },
    { WETLANDS, 5.0, 63.5, DUSTWALLOW, 71.5, 56.5, "boat", 360, "Alliance", "Schiff Menethil–Theramore" },
    { STV, 25.8, 73.0, BARRENS, 63.7, 38.8, "boat", 360, nil, "Schiff Beutebucht–Ratschet" },
    { DUROTAR, 50.6, 12.6, TIRISFAL, 60.7, 58.8, "zep", 390, "Horde", "Zeppelin Orgrimmar–Unterstadt" },
    { DUROTAR, 50.8, 13.8, STV, 31.4, 29.3, "zep", 390, "Horde", "Zeppelin Orgrimmar–Grom'gol" },
    { TIRISFAL, 61.9, 59.1, STV, 31.4, 29.3, "zep", 390, "Horde", "Zeppelin Unterstadt–Grom'gol" },
}
