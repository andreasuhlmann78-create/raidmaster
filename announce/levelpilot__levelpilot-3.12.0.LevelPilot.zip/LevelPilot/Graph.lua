-- LevelPilot - Wegenetz & Wegfindung
-- Knoten: Weltpunkte (Kontinent, Nord, West, Zone). Kanten: gelaufene Wege (eigene
-- oder von anderen Spielern), Zonenuebergaenge, Schiffe. Suche: A*.
-- Regel fuer "nur moegliche Wege": Ohne bekannte Kante darf der Weg nur INNERHALB
-- einer Zone per Luftlinie verbunden werden. Zonenwechsel nur ueber Uebergaenge
-- oder gelaufene Wege.

local _, LP = ...
local Graph = {}
LP:RegisterModule("Graph", Graph)

local CELL       = 100    -- Rasterzelle fuer die Umgebungssuche (Yards)
local SNAP       = 10     -- Punkte naeher als das werden zusammengelegt
local VIRT_RANGE = 260    -- Luftlinien-Verbindung zu gelaufenen Knoten in dieser Reichweite
local VIRT_MULT  = 1.45   -- Luftlinie ist unsicher -> teurer
local RUN_SPEED  = 7      -- Yards pro Sekunde (fuer Schiffs-/Wartezeiten)
local MAX_NODES  = 40000
local MAX_NET_NODES = 30000
local MAX_EXPAND = 8000
local STATIC_BASE = 10000000   -- IDs der Startdatenbank-Wege (nicht gespeichert)

local G            -- gespeicherte Daten (LP.db.graph)
local adj = {}     -- [id] = { [nachbar] = kante }
local grid = {}    -- ["inst:cn:cw"] = { id, ... }
local nodes = {}   -- Laufzeit-Knoten (gespeicherte + Uebergaenge)
local gwByZone = {}
local gwEdges = {}
local staticCount, staticEdges = 0, 0

------------------------------------------------------------------------
-- Hilfen
------------------------------------------------------------------------
local function CellKey(inst, n, w)
    return inst .. ":" .. math.floor(n / CELL) .. ":" .. math.floor(w / CELL)
end

local function GridAdd(id, nd)
    local k = CellKey(nd[1], nd[2], nd[3])
    local list = grid[k]
    if not list then list = {} grid[k] = list end
    list[#list + 1] = id
end

local function EdgeKey(a, b)
    if a < b then return a .. ":" .. b end
    return b .. ":" .. a
end

local function Link(a, b, e)
    adj[a] = adj[a] or {}
    adj[b] = adj[b] or {}
    adj[a][b] = e
    adj[b][a] = e
end

local function Dist(a, b)
    local dn, dw = a[2] - b[2], a[3] - b[3]
    return math.sqrt(dn * dn + dw * dw)
end

------------------------------------------------------------------------
-- Aufbau
------------------------------------------------------------------------
function Graph:Init()
    LP.db.graph = LP.db.graph or {}
    G = LP.db.graph
    G.nodes = G.nodes or {}
    G.edges = G.edges or {}
    G.nextId = G.nextId or 1
    G.count = G.count or 0
    G.netCount = G.netCount or 0

    wipe(adj) wipe(grid) wipe(nodes) wipe(gwByZone) wipe(gwEdges)
    for id, nd in pairs(G.nodes) do
        nodes[id] = nd
        GridAdd(id, nd)
    end
    for _, e in pairs(G.edges) do
        if nodes[e[1]] and nodes[e[2]] then Link(e[1], e[2], e) end
    end
    self:BuildGateways()
    self:LoadStatic(LP.Seed and LP.Seed.paths)
end

-- Wege der Startdatenbank: { {inst, n1, w1, zone1, n2, w2, zone2, anzahl}, ... }
function Graph:LoadStatic(segments)
    staticCount, staticEdges = 0, 0
    if type(segments) ~= "table" then return end
    local nextId = STATIC_BASE
    local function node(inst, n, w, zone)
        local id = self:Nearest(inst, n, w, SNAP, zone, function(i) return i >= STATIC_BASE end)
        if id then return id end
        nextId = nextId + 1
        nodes[nextId] = { inst, n, w, zone ~= 0 and zone or nil, 1, static = true }
        GridAdd(nextId, nodes[nextId])
        staticCount = staticCount + 1
        return nextId
    end
    for _, s in ipairs(segments) do
        local a = node(s[1], s[2], s[3], s[4])
        local b = node(s[1], s[5], s[6], s[7])
        if a ~= b then
            Link(a, b, { a, b, "seed", s[8] or 1 })
            staticEdges = staticEdges + 1
        end
    end
end

-- Zonenuebergaenge als Laufzeit-Knoten (negative IDs, nicht gespeichert)
function Graph:BuildGateways()
    local faction = LP:PlayerFaction()
    local gid = -1
    for _, g in ipairs(LP.Gateways or {}) do
        local mapA, xA, yA, mapB, xB, yB, kind, secs, fac, name = unpack(g)
        if not fac or fac == faction then
            local iA, nA, wA = LP.Geo:ToWorld(mapA, xA, yA)
            local iB, nB, wB = LP.Geo:ToWorld(mapB, xB, yB)
            if iA and iB then
                local a, b = gid, gid - 1
                gid = gid - 2
                nodes[a] = { iA, nA, wA, mapA, 0, gw = true, name = name }
                nodes[b] = { iB, nB, wB, mapB, 0, gw = true, name = name }
                GridAdd(a, nodes[a]) GridAdd(b, nodes[b])
                gwByZone[mapA] = gwByZone[mapA] or {}
                gwByZone[mapB] = gwByZone[mapB] or {}
                table.insert(gwByZone[mapA], a)
                table.insert(gwByZone[mapB], b)
                local e = { a, b, kind == "walk" and "g" or kind, 1, secs = secs, name = name }
                gwEdges[#gwEdges + 1] = e
                Link(a, b, e)
            end
        end
    end
end

------------------------------------------------------------------------
-- Suche in der Umgebung
------------------------------------------------------------------------
function Graph:Near(inst, n, w, radius, zone)
    local out = {}
    local r = math.ceil(radius / CELL)
    local cn, cw = math.floor(n / CELL), math.floor(w / CELL)
    for dn = -r, r do
        for dw = -r, r do
            local list = grid[inst .. ":" .. (cn + dn) .. ":" .. (cw + dw)]
            if list then
                for i = 1, #list do
                    local id = list[i]
                    local nd = nodes[id]
                    if nd and (not zone or nd[4] == zone) then
                        local d = math.sqrt((nd[2] - n) ^ 2 + (nd[3] - w) ^ 2)
                        if d <= radius then out[#out + 1] = id end
                    end
                end
            end
        end
    end
    return out
end

function Graph:Nearest(inst, n, w, radius, zone, filter)
    local best, bestD
    for _, id in ipairs(self:Near(inst, n, w, radius, zone)) do
        local nd = nodes[id]
        if filter and not filter(id) then nd = nil end
        if nd then
        local d = math.sqrt((nd[2] - n) ^ 2 + (nd[3] - w) ^ 2)
        if not bestD or d < bestD then best, bestD = id, d end
        end
    end
    return best, bestD
end

------------------------------------------------------------------------
-- Hinzufuegen (aus Aufzeichnung oder vom Netzwerk)
------------------------------------------------------------------------
function Graph:AddNode(inst, n, w, zone, fromNet)
    local id = self:Nearest(inst, n, w, SNAP, zone, function(i) return i > 0 and i < STATIC_BASE end)
    if id then
        local nd = nodes[id]
        nd[5] = (nd[5] or 0) + 1
        return id, false
    end
    if G.count >= MAX_NODES then return nil end
    if fromNet and G.netCount >= MAX_NET_NODES then return nil end
    id = G.nextId
    G.nextId = id + 1
    local nd = { inst, math.floor(n * 10 + 0.5) / 10, math.floor(w * 10 + 0.5) / 10, zone, 1 }
    if fromNet then nd.net = true G.netCount = G.netCount + 1 end
    G.nodes[id] = nd
    nodes[id] = nd
    G.count = G.count + 1
    GridAdd(id, nd)
    return id, true
end

-- kind: "r" = selbst gelaufen, "s" = von anderen Spielern, "w" = geschwommen
-- consent: Urheber hat das Wegstueck fuer die Startdatenbank freigegeben
function Graph:AddEdge(a, b, kind, consent)
    if not a or not b or a == b then return false end
    local key = EdgeKey(a, b)
    local e = G.edges[key]
    if e then
        e[4] = (e[4] or 1) + 1
        if kind == "r" and e[3] == "s" then e[3] = "r" end
        if consent then e.c = true end
        return false
    end
    e = { a, b, kind, 1, c = consent or nil }
    G.edges[key] = e
    Link(a, b, e)
    return true
end

-- Polylinie: { {inst, n, w, zone}, ... }
function Graph:AddPolyline(points, kind, fromNet, consent)
    local prev, added = nil, 0
    for _, p in ipairs(points) do
        local id = self:AddNode(p[1], p[2], p[3], p[4], fromNet)
        if prev and id and self:AddEdge(prev, id, kind, consent) then added = added + 1 end
        prev = id or prev
    end
    if added > 0 then LP:Fire("GRAPH_CHANGED") end
    return added
end

function Graph:Stats()
    local edges, yards = 0, 0
    for _, e in pairs(G.edges) do
        local a, b = nodes[e[1]], nodes[e[2]]
        if a and b then
            edges = edges + 1
            yards = yards + Dist(a, b)
        end
    end
    return { nodes = G.count, netNodes = G.netCount, edges = edges, yards = yards, gateways = #gwEdges,
             seedNodes = staticCount, seedEdges = staticEdges }
end

function Graph:NodeById(id) return nodes[id] end

------------------------------------------------------------------------
-- A*-Suche
------------------------------------------------------------------------
-- Binaerer Heap
local function HeapPush(h, item, prio)
    local n = #h + 1
    h[n] = { item, prio }
    while n > 1 do
        local p = math.floor(n / 2)
        if h[p][2] <= h[n][2] then break end
        h[p], h[n] = h[n], h[p]
        n = p
    end
end

local function HeapPop(h)
    local top = h[1]
    if not top then return nil end
    local last = h[#h]
    h[#h] = nil
    if #h > 0 then
        h[1] = last
        local n = 1
        while true do
            local l, r, s = n * 2, n * 2 + 1, n
            if h[l] and h[l][2] < h[s][2] then s = l end
            if h[r] and h[r][2] < h[s][2] then s = r end
            if s == n then break end
            h[s], h[n] = h[n], h[s]
            n = s
        end
    end
    return top[1], top[2]
end

local function EdgeCost(e, a, b)
    local d = Dist(a, b)
    local k = e[3]
    if k == "boat" or k == "zep" or k == "tram" or k == "portal" then
        return (e.secs or 120) * RUN_SPEED + d * 0.05
    elseif k == "w" then
        return d * 1.8
    elseif k == "s" then
        return d * 1.05
    elseif k == "seed" then
        return d * 0.98
    elseif k == "g" then
        return d
    end
    -- selbst gelaufen: oft gelaufene Wege leicht bevorzugen
    return d * ((e[4] or 1) >= 3 and 0.95 or 1.0)
end

-- Luftlinie quer ueber unbekanntes Gelaende (Berge, Felsen, Wasser) ist teurer. So gewinnen
-- gelaufene Wege durch Tunnel, Paesse und um Berge herum. Werte zwischen festen Knoten werden
-- zwischengespeichert (die Gelaendekarte aendert sich nicht).
local TERRAIN_PENALTY = 1.6
local DANGER_MULT = 25        -- Wegstueck durch Gebiet mit zu starken Mobs: so viel teurer
local TERRAIN_MIN = 80        -- Yards: kuerzere Luftlinien ohne Pruefung (kurze Spruenge queren keinen Berg)
local unkCache, unkCount = {}, 0
local function VirtCost(a, b, zone, ka, kb)
    local d = Dist(a, b)
    local c = d * VIRT_MULT
    if d > TERRAIN_MIN and zone and LP.Terrain and LP.Terrain.Unknown then
        local key = (type(ka) == "number" and type(kb) == "number") and (ka < kb and ka .. ":" .. kb or kb .. ":" .. ka) or nil
        local u = key and unkCache[key]
        if not u then
            local ok, v = pcall(LP.Terrain.Unknown, LP.Terrain, zone, a, b)
            u = ok and v or 0
            if key then
                if unkCount > 60000 then wipe(unkCache) unkCount = 0 end
                unkCache[key] = u
                unkCount = unkCount + 1
            end
        end
        c = c * (1 + TERRAIN_PENALTY * u)
    end
    return c
end
function Graph:ClearTerrainCache() wipe(unkCache) unkCount = 0 end

-- Liefert eine Liste von Punkten {inst, n, w, zone} und die Art ("graph"/"direct"/nil).
-- Jeder Punkt traegt in .via die Art der Kante, ueber die er erreicht wurde
-- ("v" = Luftlinie, sonst die Kantenart aus dem Wegenetz, "g" = Zonenuebergang).
function Graph:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone)
    local S = { sInst, sn, sw, sZone }
    local T = { gInst, gn, gw, gZone }

    -- Ziel direkt in derselben Zone und nah: Luftlinie genuegt
    if sInst == gInst and sZone == gZone and Dist(S, T) < 60 then
        return { S, { gInst, gn, gw, gZone, via = "v" } }, "direct", Dist(S, T)
    end

    local function nodeOf(id)
        if id == "S" then return S end
        if id == "T" then return T end
        return nodes[id]
    end

    local function heuristic(nd)
        if nd[1] ~= gInst then return 0 end
        return Dist(nd, T)
    end

    -- Pflichtregel: Wegstuecke durch Gebiete mit Mobs ab Spielerlevel + 3 meiden (Umweg, wenn es einen gibt)
    local Dg = LP.Danger
    local lim = Dg and Dg.pathRule and Dg.Limit and Dg:Limit()
    local function guarded(a, b, cost, kind)
        if not lim or a[1] ~= b[1] or kind == "boat" or kind == "zep" or kind == "tram" or kind == "portal" then return cost end
        if Dg:Segment(a[1], a[2], a[3], b[2], b[3]) >= lim then return cost * DANGER_MULT end
        return cost
    end

    local gScore = { S = 0 }
    local came = {}
    local via = {}
    local open = {}
    local closed = {}
    HeapPush(open, "S", heuristic(S))
    local expanded = 0

    local function relax(u, v, cost, kind)
        local tentative = gScore[u] + cost
        if gScore[v] == nil or tentative < gScore[v] then
            gScore[v] = tentative
            came[v] = u
            via[v] = kind
            HeapPush(open, v, tentative + heuristic(nodeOf(v)))
        end
    end

    -- Luftlinie: Gelaende nur pruefen, wenn sie ueberhaupt kuerzer sein kann als das Bekannte
    -- (die Pruefung macht sie nur teurer, nie billiger)
    local function relaxVirt(u, v, a, b, zone, ka, kb)
        local base = Dist(a, b) * VIRT_MULT
        local known = gScore[v]
        if known and gScore[u] + base >= known then return end
        relax(u, v, guarded(a, b, VirtCost(a, b, zone, ka, kb), "v"), "v")
    end

    while true do
        local u = HeapPop(open)
        if not u then break end
        if u == "T" then break end
        if not closed[u] then
            closed[u] = true
            expanded = expanded + 1
            if expanded > MAX_EXPAND then break end
            if expanded % 5 == 0 then LP:Yield("graph") end   -- teure Knoten (viele Nachbarn, Gelaende): oft pruefen
            local un = nodeOf(u)

            -- gespeicherte Kanten
            if u ~= "S" and adj[u] then
                for v, e in pairs(adj[u]) do
                    if not closed[v] then
                        relax(u, v, guarded(un, nodes[v], EdgeCost(e, un, nodes[v]), e[3]), e[3])
                    end
                end
            end

            -- Luftlinien nur innerhalb derselben Zone
            local zone, inst = un[4], un[1]
            if zone then
                for _, v in ipairs(self:Near(inst, un[2], un[3], VIRT_RANGE, zone)) do
                    if v ~= u and not closed[v] then
                        relaxVirt(u, v, un, nodes[v], zone, u, v)
                    end
                end
                local gws = gwByZone[zone]
                if gws then
                    for _, v in ipairs(gws) do
                        if v ~= u and not closed[v] and nodes[v][1] == inst then
                            relaxVirt(u, v, un, nodes[v], zone, u, v)
                        end
                    end
                end
                if zone == gZone and inst == gInst and not closed["T"] then
                    relaxVirt(u, "T", un, T, zone)
                end
            end
        end
    end

    if gScore["T"] == nil then
        -- kein moeglicher Weg bekannt: Luftlinie als Notloesung
        if sInst == gInst then return { S, { gInst, gn, gw, gZone, via = "v" } }, "direct", Dist(S, T) end
        return nil
    end

    -- Kopien der Knoten (die gespeicherten Knoten bleiben unveraendert) mit Kantenart
    local path, cur = {}, "T"
    while cur do
        local nd = nodeOf(cur)
        local e = came[cur] and adj[came[cur]] and adj[came[cur]][cur]
        table.insert(path, 1, { nd[1], nd[2], nd[3], nd[4], via = via[cur], gw = nd.gw, name = nd.name, secs = e and e.secs })
        cur = came[cur]
    end
    return path, "graph", gScore["T"]
end

------------------------------------------------------------------------
-- Hoehlen: Ziel drinnen -> erst zum Eingang, dann hinein; Start drinnen -> erst hinaus
------------------------------------------------------------------------
local function Mark(points, first)
    for i = first or 1, #points do points[i].cave = true end
    return points
end

local function Append(out, points, skipFirst)
    for i = skipFirst and 2 or 1, #points do out[#out + 1] = points[i] end
end

function Graph:Path(sInst, sn, sw, sZone, gInst, gn, gw, gZone)
    local Caves = LP.Caves
    local sc = Caves and Caves.At and Caves:At(sInst, sn, sw, gn, gw, true)
    local tc = Caves and Caves.At and Caves:At(gInst, gn, gw, sn, sw)
    if (not sc and not tc) or (sc and tc and Caves:Same(sc, tc)) then
        return self:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone)
    end
    local out, total = {}, 0
    local ci, cn, cw, cz = sInst, sn, sw, sZone
    if sc then
        -- drinnen: auf dem Weg zum Eingang (Innenraum, keine Gelaendefuehrung)
        local p, _, c = self:PathRaw(ci, cn, cw, cz, sc.inst, sc.n, sc.w, sc.map or cz)
        if not p then return self:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone) end
        Mark(p, 1)
        p[#p].cave = nil                       -- der Eingang selbst liegt draussen
        Append(out, p, false)
        total = total + (c or 0)
        ci, cn, cw, cz = sc.inst, sc.n, sc.w, sc.map or cz
    end
    if tc then
        local p, _, c = self:PathRaw(ci, cn, cw, cz, tc.inst, tc.n, tc.w, tc.map or gZone)
        if not p then return self:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone) end
        Append(out, p, #out > 0)
        total = total + (c or 0)
        local inner, _, c2 = self:PathRaw(tc.inst, tc.n, tc.w, tc.map or gZone, gInst, gn, gw, gZone)
        if not inner then inner, c2 = { { tc.inst, tc.n, tc.w, tc.map }, { gInst, gn, gw, gZone, via = "v" } }, 0 end
        Mark(inner, 2)
        Append(out, inner, true)
        total = total + (c2 or 0)
    else
        local p, _, c = self:PathRaw(ci, cn, cw, cz, gInst, gn, gw, gZone)
        if not p then return self:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone) end
        Append(out, p, #out > 0)
        total = total + (c or 0)
    end
    return out, "cave", total
end
