# GuildSentinel – Änderungen

## 0.9.26
- Werbung ohne Discord: Der Satz nach dem entfernten Discord-Teil beginnt jetzt gross („… deutschsprachig. Flüstert mir: …“).
- Wer den alten Standard-Werbetext unverändert gespeichert hatte, bekommt einmalig den neuen Standard (mit dem neuen {gesucht} läse er sich holprig). Eigene, abweichende Texte bleiben.
- Entwickler-Testroutine: T249 (Zähler „wird gekürzt“) und T250 neu; T248 umbenannt.

## 0.9.25
- **Neuer Standard-Werbetext**: „{gilde} ({fraktion}) sucht {gesucht} für Dungeons und Raids – entspannt, hilfsbereit, deutschsprachig. Discord: {discord} – flüstert mir: /w {name} gilde“ (in allen Sprachen sinngemäss). Wer einen eigenen Werbetext gespeichert hat, behält ihn; ein leeres Feld nimmt den neuen Standard.
  - Neuer Platzhalter **{fraktion}** ({faction}): Horde oder Allianz in der Sprache des Spiels.
  - **{gesucht}** ist jetzt nur die Liste („Heiler, Krieger und Magier“); fehlt nichts: „neue Mitglieder“. Stand „{gesucht}“ in einem eigenen Text allein, bitte „Gesucht:“ selbst davorschreiben.
  - **{discord}**: Ohne Discord-Link fällt der ganze Teil „Discord: … – “ weg. Direkt nach „Discord:“ steht nur der Link; überall sonst (eigene Texte, Antwort, Willkommen) wie bisher „Discord: <Link>“.
- Der Längenzähler zählt vor dem Kürzen und wird rot mit „wird gekürzt“, wenn die Werbung länger als 251 Zeichen ist.
- Entwickler-Testroutine: T244–T248 neu.

## 0.9.24
- Gildenwerbung: Eine lange Werbung wird von der Chat-Eingabe nicht mehr abgeschnitten und zählt dann nie als gepostet. Der Werbetext ist auf 251 Zeichen begrenzt (Platz für „/<Kanal> “), der Zähler zeigt „(n/251)“, und genau der Text in der Chat-Eingabe zählt, sobald er im Kanal erscheint. Umlaute und andere Sonderzeichen werden nie halbiert.
- Entwickler-Testroutine: T242–T243 neu.

## 0.9.23
- **Gildenwerbung nicht mehr blockiert**: WoW Forever verbietet Addons, selbst in Chat-Kanäle zu schreiben („Aktion blockiert“) – auch aus einem Klick. Der Knopf heisst jetzt „Werbung vorbereiten“: Er schreibt „/<Kanal> <Text>“ in die Chat-Eingabe, du sendest mit Enter (alle Spielversionen). Als gepostet (Wartezeiten, „zuletzt gepostet“, Erinnerung) zählt die Werbung erst, wenn dein Text im Kanal erscheint.
- Gruppensuche: Eine Gildensuche kann nur der Suchende selbst beenden; bei Suchen für den ganzen Server reicht sein Name in den Daten (sie kommen über das Netz weitergegeben).
- Gilden-Berufsliste: Die Diagnose-Zeile sagt jetzt, warum Offline-Mitglieder (nicht) eingeblendet wurden (schon an, keine Funktion, Kampf, Gildenfenster offen, 5-Minuten-Sperre …); ist die Liste beim zweiten Lesen nicht mehr lesbar, werden die Einstellungen trotzdem zurückgesetzt.
- Entwickler-Testroutine: T239–T241 neu.

## 0.9.22
- **Rezepte je Mitglied**: Auf der Seite Berufe zeigt ein Klick auf ein Mitglied, WELCHE Rezepte es in diesem Beruf kann – mit Zurück-Knopf, Item-Links und Tooltips, und „Herstellen anfragen“ für das gewählte Rezept.
  - **Filterleiste nach Art**, nur Arten, die vorkommen, mit Anzahl und „Alle“ zuerst: Schmiedekunst, Lederverarbeitung, Schneiderei nach Platz (Kopf, Brust, Hände, Waffen …), Alchemie nach Heil-/Mana-/Erholungs-/Schutztränken, Elixieren, Fläschchen, Ölen, Transmutationen, Reagenzien, Ingenieurskunst nach Sprengstoff, Geräten, Zielfernrohren, Verzauberkunst nach Ziel-Platz, Kochen/Erste Hilfe nach Essen und Verbänden. Die Leiste bricht um, wenn der Platz nicht reicht.
  - Die Art wird auf deinem PC aus dem Item (Platz, Klasse) oder dem Rezeptnamen bestimmt – es muss nichts Neues gesendet werden, Daten älterer Versionen gehen auch („Sonstiges“, wenn unbekannt).
  - In WoW Forever geht Blizzards Rezept-Kategorie als neues, optionales Feld mit; ältere Versionen übergehen es.
  - Das Suchfeld filtert auch die Rezepte eines Mitglieds; Filter und Suche lassen sich kombinieren.
- Gruppensuche „ganzer Server“: Gruppenänderungen und Antworten auf Nachfragen gehen nur noch an die Gruppe; ins Flüster-Netz geht eine Suche nur beim Start und beim Beenden.
- Entwickler-Testroutine: T231–T238 neu.

## 0.9.21
- **GoldSentinelSync 2 (Flüster-Netz)**: Die gemeinsame Sync-Datei erreicht jetzt auch Spieler mit GoldSentinel-Addons ausserhalb von Gilde und Gruppe – per Flüstern über andere Spieler, die sie haben (gedrosselt, kein Chat-Spam; „kein Spieler … online“ wird ausgeblendet).
  - **Was ins Netz geht**: nur die Gruppensuche für den ganzen Server (neue Suche und Beenden). Alles andere bleibt in der Gilde (Berufe, Termine, Brett, Umfragen, Danke, Zugänge …), in der Gruppe oder im Flüstern an einen Spieler.
  - Gruppensuche: „ganzer Server“ ist zurück – die Suche geht an die Gilde, die Gruppe und ins Netz.
  - Bekannte Mitspieler des Netzes bleiben über /reload erhalten (GuildSentinelDB.gsSync: nur Namen, Zeiten, Version; bleibt auf deinem PC).
- **GoldSentinelTest 2**: Fehlerberichte an den Entwickler teilen (nur mit Zustimmung, /gstest).
- Diagnose-Protokoll: neue Zeile „NETZ …“ (ohne Namen).
- Entwickler-Testroutine: T225–T230 neu.

## 0.9.20
- **Addon-Nachrichten für alle Spielversionen**: GuildSentinel nutzt jetzt die gemeinsame Sync-Datei von GoldSentinel. Gesendet wird nur noch über die Gilde, die eigene Gruppe bzw. den Raid und Flüstern – nie mehr über einen eigenen Chat-Kanal (WoW Forever stellt Addon-Nachrichten dort nicht zu). Nachrichten älterer GuildSentinel-Versionen anderer Spieler werden weiter verstanden. Wer noch 0.9.19 oder älter hat, empfängt die Nachrichten von 0.9.20 nicht mehr – bitte aktualisieren.
  - Der eigene Kanal „GuildSentinelLFG“ wird nicht mehr betreten (einmal verlassen, falls man drin ist) – ein Kanalplatz wird frei.
  - Gruppensuche: „Gilde und Gruppe“ ersetzt „ganzer Server“ – die Suche geht an die Gilde und an die eigene Gruppe bzw. den Raid. Die Einstellung „Suchen vom ganzen Server“ entfällt.
  - Werbung: Nur noch Blizzard-Kanäle (Allgemein, Handel, LokaleVerteidigung, SucheNachGruppe …) sind wählbar; Addon- und Spielerkanäle sind ausgeblendet.
  - „/gs sync test“ zeigt, wer antwortet („N Antworten (Gilde a, Gruppe b)“); die Einstellungen zeigen die Zahl der Mitspieler mit GuildSentinel in der letzten Stunde.
- **Berufe**: Wer einen Beruf bei offenem Fenster hochlevelt, sendet nicht mehr bei jeder Stufe an die Gilde (höchstens alle 5 Minuten und beim Schliessen des Fensters); neue Rezepte gehen weiter sofort. Das Diagnose-Protokoll läuft dadurch nicht mehr voll.
- Gilden-Berufsliste mit Offline-Mitgliedern: GuildSentinel wartet jetzt immer auf das Spiel, bevor es liest und die Einstellung zurücksetzt.
- Blizzards Gilden-Rezepte: Das Öffnen der Gilden-Ansicht startet die Abfragen je Beruf höchstens alle 10 Minuten neu, und kein Rezept wird am selben Tag zweimal gefragt.
- Empfangene Berufsdaten anderer Spieler werden in der Tiefe geprüft; kaputte Daten führen in Tooltips und Herstellen-Anfragen zu keinem Fehler mehr.
- Diagnose-Protokoll: Zeilen für Addon-Nachrichten (Wege, Mitspieler, gesendet/empfangen/verworfen, Kanal verweigert).
- Entwickler-Testroutine: T214–T224 neu; in Tests nur noch Platzhalter-Namen.

## 0.9.19
- **Berufe kommen automatisch in beide Richtungen an**: Die Berufe eines Mitglieds konnten auf einer Seite hängen bleiben. Behoben:
  - GuildSentinel schickt deine eigenen Berufe jetzt immer selbst, auch wenn RaidMaster installiert ist (vorher schwieg es und verliess sich auf RaidMaster).
  - Namen werden überall gleich abgeglichen (Realm-Zusatz, Gross-/Kleinschreibung, Vorname allein in WoW Forever): Daten liegen und erscheinen unter dem Namen aus der Gildenliste. Ältere Einträge in anderer Schreibweise werden einmal zusammengeführt (neuere Daten gewinnen).
  - Jedes Mitglied mit GuildSentinel schickt seine eigenen Berufe 10–60 Sekunden nach dem Einloggen, wenn sie neu oder älter als 24 Stunden sind – nicht mehr nur über das eine Mitglied, das beim Abgleich antwortet.
- **Vollautomatisch** (keine Option, kein Knopf, nie im Kampf):
  - Die Gilden-Berufsliste des Spiels wird auch mit Offline-Mitgliedern gelesen (die Einstellung „Offline-Mitglieder anzeigen“ wird kurz eingeschaltet und zurückgesetzt).
  - Neue Rezepte kommen sofort dazu, wenn du sie lernst – ohne Berufsfenster.
  - Rezepte ohne Fenster prüfen: Rezepte, die die Gilde schon kennt, werden mit der Zauber-Prüfung des Spiels geprüft – nur, wenn eine Probe richtig antwortet.
  - Blizzards Gilden-Rezepte (wer in der Gilde welches Rezept kann) werden abgefragt, wo das Spiel es erlaubt, einmal am Tag je Beruf; sonst gelesen, wenn du diese Ansicht selbst öffnest.
- **Seite Berufe**: Ein gewählter Beruf ohne bekannte Daten sagt jetzt, wie viele Mitglieder ihn haben („2 Gildenmitglieder haben Alchimie …“), statt des allgemeinen Hinweises. Die Spalte „Wer“ zeigt „1 von 4“; Mitglieder, die nur das Spiel kennt, erscheinen mit „Rezepte unbekannt“ und lassen sich anflüstern; darunter „+2 weitere laut Spiel“.
- Gildenliste: Zugeklappte Berufe werden höchstens alle 5 Minuten aufgeklappt, und das Ereignis, das dabei kommt, startet kein neues Lesen (kein Kreislauf).
- Befördern aus der Aktivität und die Sammelaktionen nutzen jetzt zuerst die moderne Spielfunktion (wie die Gildenverwaltung).
- Diagnose-Protokoll: Zeilen für eingelesene, gesendete, empfangene, angezeigte und aussortierte Berufe (nur Zahlen, keine Spielernamen) und eine Zusammenfassung.
- Entwickler-Testroutine: T201–T213 neu.

## 0.9.18
- **Berufe aller Mitglieder**: Das Spiel kann seine Gilden-Berufsliste mit zugeklappten Berufen liefern, dann fand GuildSentinel keine Namen. Jetzt klappt es zugeklappte Berufe kurz auf, liest sie und klappt sie wieder zu (nur ausserhalb des Kampfs und solange Blizzards Gildenfenster zu ist). Wo das Spiel das nicht kann, zeigt die Seite Berufe, wie viele Mitglieder einen Beruf haben (z. B. „2/5“: 2 kennt GuildSentinel, 5 laut Spiel).
- **Gildenverwaltung**: Aktionen und Rangnamen nutzen jetzt auf jedem Client die richtige Spielfunktion (Classic Era, TBC Anniversary, WoW Forever). Der Verwaltungsknopf weicht unter das Gildenfenster aus, solange Blizzards Mitglied-Details oder Rangfenster offen sind, und verdeckt sie nie.
- Entwickler-Testroutine: T190 erweitert (zugeklappte Berufe), neu T200 (alte Clients ohne C_GuildInfo); Bereich K prüft auch Blizzards Gilden-Popups.

## 0.9.17
anweisung-gildenverwaltung.txt (Wunsch des Nutzers, 9. Nov.):
- **Neues Fenster "Gildenverwaltung"** (Admin.lua) für Gildenleitung und Offiziere: Knopf "Verwaltung (GuildSentinel)" neben Blizzards Gildenfenster (J bleibt; eigener Frame, nur geankert, Blizzard-Fenster nur per HookScript, Communities beim Laden angehängt) und `/gs verwaltung`.
  - Einladen (Name oder Ziel), Befördern/Degradieren (Rang vorher -> nachher, nie über den eigenen Rang), Rauswerfen (mit Rückfrage).
  - Gildenleitung übergeben: nur Gildenmeister, gesperrt bis zum richtigen Passwort, danach zwei Rückfragen.
  - Jeder Knopf nach den Rechten im Spiel (ns.API: IsGuildLeader, CanGuildInvite/Promote/Demote/Remove, CanEditOfficerNote). Lokale Zugriffsliste des Gildenmeisters (GuildSentinelDB.admin, nie gesendet, nicht im Protokoll).
  - Passwort: zweimal eingeben, nur Prüfsumme mit Salz, maskiert, 3 Fehlversuche -> 5 Minuten Sperre, ändern nur mit dem alten.
  - Aktionen nur aus dem Klick bzw. der Bestätigung, nie im Kampf, über ns.Act; Testmodus nur "[Test]". Diagnose-Protokoll: VERWALTUNG ohne Namen.
- Testroutine: T192–T198 (Rechte, gesperrt, Aktionen mit richtigem Namen, Passwort, Sperre, Prüfsumme, keine Namen), T199 im Spiel; Bereich K kennt die neuen Fenster (ns.RegisterUI).

## 0.9.16
Wunsch des Nutzers: Berufe der Mitglieder und neuer Mitglieder automatisch einlesen.
- **Berufe aller Mitglieder automatisch**: Wo das Spiel die Berufe der Gilde selbst kennt (Gilden-Berufsliste, GetGuildTradeSkillInfo – über ns.API, fehlt sie, passiert nichts), liest GuildSentinel die Stufen aller Mitglieder, auch ohne GuildSentinel. Höchstens alle 5 Minuten, nicht im Kampf nötig, nur lesen. Rezepte kommen weiter nur von Spielern mit GuildSentinel bzw. RaidMaster, die ihr Berufsfenster geöffnet haben; deren Angaben gehen immer vor (Einträge aus der Gildenliste: t = 0, g = true).
- **Neue Mitglieder**: Wer der Gilde beitritt, während er online ist, schickt seine Berufe sofort (bisher erst beim nächsten Einloggen).
- Diagnose-Protokoll: einmal je Sitzung "Gilden-Berufsliste: n Zeilen, … Mitglieder" – so zeigt sich, ob die Spielversion die Liste liefert.
- Testroutine: T190 (Gildenliste über ns.API nachgestellt), T191 (im Spiel).

## 0.9.15
Empfehlung der Prüf-Sitzung (Nachricht vom 9. Nov.): Diagnose-Protokoll wie in der Vorlage.
- **Diagnose-Protokoll** (Diag.lua): GuildSentinel schreibt Probleme mit, die nur im echten Spiel auftreten – langsame Seiten (über 16 ms), blockierte Aktionen mit Aufrufort (debugstack bei ADDON_ACTION_BLOCKED/FORBIDDEN), Fehler (gleiche nur gezählt). Keine Spieler-, Gilden- oder Realmnamen. `/gs protokoll` zeigt es zum Kopieren; beim Ausloggen bzw. /reload liegt es als GSDIAG1 in GuildSentinelDB.diagExport (Uploader -> #testberichte). Im Testmodus und während der Testroutine wird nichts geschrieben.
- Testroutine: T188 (Protokoll: Einträge, Zähler, Export, keine Namen), T189 (im Spiel).
- Zum Befund "4× ADDON_ACTION_BLOCKED UNKNOWN() mit 0.9.13": Der Aufrufort stand schon im Testbericht (Professions.lua:346 OpenModern <- Pages.lua:1505, Timer nach dem Berufe-Knopf) und ist seit 0.9.14 behoben.

## 0.9.14
Befunde aus der Testroutine im Spiel (Launch-Abend WoW Forever, offen-guildsentinel.txt Punkt 3) und
anweisung-testroutine-oberflaeche.txt:
- **T143 Grosse Gilden**: Übersicht und Leitung ruckeln nicht mehr bei Hunderten Mitgliedern. Main/Twink wird je Seitenaufbau nur einmal berechnet (Roster:Memo), die Übersicht gruppiert in einem Durchgang – mit 500 Mitgliedern etwa 25× schneller.
- **Berufe-Knopf (WoW Forever)**: kein "Aktion blockiert" mehr (Fehlerbericht vom Launch). Geht das Berufsfenster nicht auf, kommt ein Hinweis, statt die geschützte Funktion C_TradeSkillUI.OpenTradeSkill aus einem Timer aufzurufen.
- **T118 Chronik/Erfolge**: kaputte Berufsdaten lassen die Seite nicht mehr abstürzen (Typprüfung, Prof:All überspringt kaputte Einträge).
- **T45 Termin ansagen**: im Testmodus auch ohne echte Gilde nur "[Test]" im Chat (ns.Announce nutzt ns.InGuild); gesendet wird weiterhin nichts.
- **T154**: Der Fall läuft unabhängig von den Einstellungen des Spielers (Funktion "Danke" aus, schon gedankt) und zeigt im Ergebnis, was GuildSentinel ausgibt.
- Testroutine: neuer Bereich K "Oberfläche im echten Client" (T182 Tooltips verdecken keine Knöpfe, T183 kein Überlappen mit anderen Fenstern, T184 im Bildschirm, T185 Texte passen, T186 Spielwerte plausibel, T187 keine Fehlerschleifen); T143 nennt die langsamste Seite.

## 0.9.13
- **Sprache für alle wählbar**: Einstellungen > Allgemein > "Sprache". Beim Start nimmt GuildSentinel weiter die Sprache des Spiel-Clients; wählbar sind auf jedem Client Deutsch, Englisch, Französisch, Spanisch (Spanien/Mexiko), Italienisch und Portugiesisch (Russisch, Koreanisch und Chinesisch auf einem Client in dieser Sprache). GuildSentinel lädt nach der Wahl neu; "Wie der Spiel-Client" stellt zurück. Ersetzt die Wahl nur für den Entwickler aus 0.9.12.
- Testroutine: T122 beachtet die gewählte Sprache, T127 prüft jetzt im Spiel alle geladenen Sprachen auf Vollständigkeit.

## 0.9.12
- Nur für den Entwickler: Unter Einstellungen > Testmodus lässt sich die Sprache zwischen Deutsch, Englisch und der Sprache des Spiel-Clients umschalten (für Screenshots); GuildSentinel lädt danach neu. Für Spieler ändert sich nichts – GuildSentinel nimmt immer die Sprache des Spiel-Clients.

## 0.9.11
Aufträge der Prüf-Sitzung (offen-guildsentinel.txt, anweisung-guildsentinel-gildenbank.txt):
- **Bank-Charakter: Bestand an Discord** (freiwillig, ab Werk aus): Auf dem Bank-Charakter der Gilde unter Einstellungen > Allgemein "Bank-Charakter (Bestand an Discord)" anhaken. Beim Öffnen von Bank, Briefkasten und – wo es sie gibt – Gildenbank liest GuildSentinel dann Taschen, Bank, Post-Anhänge und Gildenbankfächer (nur lesen, nie im Kampf, in kleinen Schritten). Der RaidMaster-Uploader schickt den Bestand mit dem nächsten Upload mit, der RaidMaster-Bot zeigt ihn in #gildenbank und bei /bank. Gilden ohne RaidMaster-Bot merken nichts davon.
- **Twink-Notizen mit Vor- und Nachnamen** (WoW Forever) auf koreanischen und chinesischen Clients, bei denen der Name vor der Kennzeichnung steht ("Testa Beispiel의 부캐릭터"), werden wieder erkannt.
- **Main wechseln** entfernt die alte Kennzeichnung jetzt ganz – mit Vor- und Nachnamen und in der Sprache des Clients ("Alt: Vorname Nachname", "Reroll de …") –, statt Reste in der Notiz stehen zu lassen.
- **Termin-Abgleich**: Ein kaputter Eintrag verwirft nicht mehr die übrigen Termine desselben Pakets.
- Alle Spielfunktionen, die GuildSentinel braucht, werden jetzt an einer Stelle gewählt (API.lua, moderne API zuerst, alte als Rückfall). Für Spieler ändert sich nichts.
- Testroutine (Entwickler): echte Sendungen sind im Bericht jetzt ein FEHLER (T82), jede Aktion mit Folgen wird auf den einen Weg über ns.Act geprüft (T174), neue Fälle für Export, Termin-Ansage, Vor- und Nachnamen und den Bank-Charakter (T31, T45, T154, T175–T181); die Fälle, die früher eine Blizzard-Funktion ersetzt hätten (T92, T93b, T96b, T97b, T99, T114, T159, T161, T166), laufen jetzt auch im Spiel – über ns.API.

## 0.9.10
- **Twink-Notizen in der Sprache des Clients**: Notizen, die GuildSentinel selbst schreibt ("Reroll de …", "… 的分身" usw.), werden auf französischen, spanischen, italienischen, portugiesischen, koreanischen und chinesischen Clients wieder erkannt. Wo die Kennzeichnung nicht in die kurze Gildennotiz passt (Russisch), schreibt GuildSentinel die Kurzform "Alt: Name".
- **AHSentinel** (früher AH Analyzer Pro) wird unter dem neuen Ordnernamen erkannt (Seite Addons, Marktwerte).
- **Bewerber-Flüstern im Kampf** (WoW Forever): Mehr als 30 Flüsternachrichten in einem Kampf werden jetzt im Hinweis mitgezählt, statt still wegzufallen.
- Robuster bei beschädigten Daten: fehlerhafte Termin-Abgleiche und kaputte Termin- oder Danke-Einträge lösen keine Fehler mehr aus.
- Testmodus (nur Entwickler): betritt oder verlässt den Server-Kanal nicht mehr, sendet nach "Testmodus beenden" nichts Verzögertes mehr und lässt die echten Einstellungen (letzte Werbung, Frei-Meldung, Meine Woche) unberührt.
- Neu für den Entwickler: `/gs testroutine` (Knopf "Alles testen" unter Einstellungen > Testmodus) prüft alle Funktionen und speichert einen Bericht für die Prüfung von GoldSentinel; die Diagnose zeigt den Fehlerzähler. Für Spieler ändert sich nichts.

Ältere Versionen: siehe LIESMICH.txt.
