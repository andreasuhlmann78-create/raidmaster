local _, ns = ...

-- Background jobs with a time budget per frame (order A1/A4, review 15 Nov.: ProfessionSentinel peak 921 ms in one frame).
-- Model: AHSentinel A.jobs / RunJobs. Every heavy calculation outside the panel rebuild (recipe alarm after an AH scan,
-- "craft today" for AHSentinel, the recipe list for AHSentinel's crafting chains) runs as a job: a coroutine that works
-- at most J.BUDGET ms per frame for all jobs together and hands the rest to the next frame.
--   ns.Jobs.Add(name, fn, opts)   fn runs in the job; call ns.Jobs.Yield() between two steps (never inside a pcall:
--                                 Lua 5.1 cannot yield across it). opts.quiet: pauses while AHSentinel's sniper is in
--                                 quiet mode (A2, at most J.QUIET_MAX seconds); opts.pass: price memo per portion.
--   ns.Jobs.Yield()               inside a job: next frame when the budget is used up; outside a job: nothing.
-- The same name again: a job that has not started yet takes the new function; a running one finishes and then runs
-- once more with the new function (never two at the same time, never lost).
-- While the test routine runs (ns.UI.SyncRefresh) or without a timer a job runs at once in one piece – the cases read
-- the result right after the call. Tests of the job layer itself set J.SYNC = false.
-- Measurement (A4): ns.Perf(path, t0) keeps per path the last and the highest time and the highest time of the
-- current minute; a slice or call over 16 ms writes LANGSAM with the path name into the diagnostic log.

local J = {}
ns.Jobs = J

J.BUDGET = 6               -- ms of job work per frame (all jobs together)
J.SLOW_MS = 16             -- one frame at 60 fps
J.QUIET_MAX = 30 * 60      -- A2: pause for AHSentinel's sniper at most 30 minutes (no lock without a time limit)
J.QUIET_RECHECK = 1        -- seconds between two looks while paused
J.list = {}                -- pending jobs in order
J.stats = {}               -- name -> { runs, slices, ms, maxSlice, lastMs, paused }
J.SYNC = nil               -- nil: automatic; true/false: forced (tests)

local current, sliceStart, scheduled = nil, nil, false
local piece, lastStep, frameGap = nil, nil, nil

-- PS-P1 (Ingametest 0.9.85 "Aufgabe heute 27.2 ms"): what the slowest slice of each job was made of, so that the report
-- shows the cause instead of a guess – the measured pieces of the job (J.PieceStart/J.PieceEnd: count, sum, the longest
-- with its label), the memory before and after (more than 1 MB less = the collector swept inside this slice), the frame
-- before (about 33 ms = game in the background) and the frame rate. Fields, so that the test routine can drive them.
function J.Mem() return collectgarbage and collectgarbage("count") or nil end
function J.Fps()
    local TK = _G.GoldSentinelTakt
    return TK and TK.api and TK.api.fps and TK.api.fps() or nil
end
J.GC_KB = 1024             -- a drop of more than 1 MB in one slice: collector step (like UMG1)
-- a measured piece inside a job (e.g. one recipe price): t0 = J.PieceStart(), then J.PieceEnd(t0, what); outside a job nil
function J.PieceStart()
    if not (piece and current and coroutine.running() == current.co) then return nil end
    piece.calls = {}                -- PS-P1 Teil 2: foreign calls inside this piece (J.PieceCall from PriceSource)
    return J.Clock()
end
function J.PieceEnd(t0, what)
    if not (t0 and piece) then return end
    local t = J.Clock()
    if not t then return end
    local d = t - t0
    piece.n, piece.ms = piece.n + 1, piece.ms + d
    if d > piece.max or piece.n == 1 then
        piece.max, piece.what = math.max(piece.max, d), what
        -- the 3 longest foreign calls of the longest piece (name, time, count) and their sum
        local list, sum = {}, 0
        for name, c in pairs(piece.calls or {}) do list[#list + 1] = { name, c.ms, c.n }; sum = sum + c.ms end
        table.sort(list, function(a, b) return a[2] > b[2] end)
        for i = #list, 4, -1 do list[i] = nil end
        piece.whatCalls, piece.whatCallsMs = list, sum
    end
    piece.calls = nil
end
-- a foreign call (another addon) inside a measured piece: PriceSource asks only while a piece runs (J.InPiece)
function J.InPiece() return piece ~= nil and piece.calls ~= nil end
function J.PieceCall(name, ms)
    local calls = piece and piece.calls
    if not calls then return end
    local c = calls[name]
    if not c then c = { n = 0, ms = 0 }; calls[name] = c end
    c.n, c.ms = c.n + 1, c.ms + ms
end

-- clock (ms) and time (s): fields, so that the test routine can drive them (no Blizzard function is replaced)
function J.Clock() return ns.DiagClock and ns.DiagClock() or nil end
function J.Now() return (GetTime and GetTime()) or 0 end
local function Clock() return J.Clock() end
local function Now() return J.Now() end

function J.Sync()
    if J.SYNC ~= nil then return J.SYNC end
    local UI = ns.UI
    if UI and UI.SyncRefresh and UI.SyncRefresh() then return true end
    return not (ns.API and ns.API.TimerAfter)
end

function J.Running() return current ~= nil and coroutine.running() == current.co end

function J.Yield()
    if not (current and coroutine.running() == current.co) then
        if ns.TaktCheck then ns.TaktCheck() end     -- Takt job of this addon (test routine step), see UI.Yield
        return
    end
    local t = Clock()
    if t and sliceStart and t - sliceStart >= J.BUDGET then coroutine.yield() end
end

---------------------------------------------------------------------------
-- A2: AHSentinel's sniper quiet mode (only reading). Public API first (API.QuietOn, if AHSentinel offers it), else the
-- sniper's own state (quiet mode began at Sniper.quietSince, its limit Sniper.QUIET_MAX). Our own limit on top: after
-- J.QUIET_MAX seconds of pausing the jobs run again (in small portions) even if AHSentinel still reports quiet mode.
---------------------------------------------------------------------------
local quietSeen
function J.AHSQuiet()
    local on = false
    local t = ns.Foreign("AHSentinel")
    local api = type(t) == "table" and type(t.API) == "table" and t.API or nil
    if not api then
        local A = ns.Foreign("AHAnalyzerPro")
        api = type(A) == "table" and type(A.API) == "table" and A.API or nil
    end
    if api and type(api.QuietOn) == "function" then
        local ok, v = pcall(api.QuietOn)
        on = ok and v == true
    else
        local A = ns.Foreign("AHAnalyzerPro")
        local Sn = type(A) == "table" and type(A.Sniper) == "table" and A.Sniper or nil
        local since = Sn and tonumber(Sn.quietSince)
        local max = Sn and tonumber(Sn.QUIET_MAX) or J.QUIET_MAX
        on = since ~= nil and (Now() - since) < max
    end
    if not on then quietSeen = nil; return false end
    quietSeen = quietSeen or Now()
    if Now() - quietSeen >= J.QUIET_MAX then return false end      -- our own time limit
    return true
end
function J.ResetQuiet() quietSeen = nil end

---------------------------------------------------------------------------
-- Measurement per path (A4)
---------------------------------------------------------------------------
ns.perf = ns.perf or {}
-- the test routine's own calls are not game measurements (a case that checks the measurement sets J.recordTest)
function J.Recording()
    local TR = ns.TestRoutine
    if J.recordTest then return true end
    return not (TR and TR.IsRunning and TR:IsRunning())
end
function ns.PerfNote(path, ms)
    if type(ms) ~= "number" or not J.Recording() then return end
    local p = ns.perf[path]
    if not p then p = { n = 0, max = 0 }; ns.perf[path] = p end
    p.n, p.last = p.n + 1, ms
    if ms > p.max then p.max = ms end
    local minute = math.floor(Now() / 60)
    if p.minute ~= minute then p.minute, p.minuteMax = minute, 0 end
    if ms > p.minuteMax then p.minuteMax = ms end
    if ms > J.SLOW_MS and ns.Diag then
        ns.diagSlowCount = (ns.diagSlowCount or 0) + 1
        ns.Diag("LANGSAM", path, ms)
    end
end
function ns.Perf(path, t0)
    if not t0 then return end
    local t1 = Clock()
    if t1 then ns.PerfNote(path, t1 - t0) end
end

-- one line for the test report / diagnostic log: the slowest paths first, "!" over 16 ms
function ns.PerfLine(max)
    local list = {}
    for path, p in pairs(ns.perf) do list[#list + 1] = { path = path, max = p.max, n = p.n } end
    table.sort(list, function(a, b) return a.max > b.max end)
    local parts = {}
    for i, e in ipairs(list) do
        if i > (max or 6) then break end
        parts[#parts + 1] = string.format("%s %.1f ms%s ×%d", e.path, e.max, e.max > J.SLOW_MS and "!" or "", e.n)
    end
    return #parts > 0 and table.concat(parts, " · ") or "-"
end

---------------------------------------------------------------------------
-- Jobs
---------------------------------------------------------------------------
local function Stat(name)
    if not J.Recording() then return { runs = 0, slices = 0, ms = 0, maxSlice = 0 } end      -- thrown away
    local s = J.stats[name]
    if not s then s = { runs = 0, slices = 0, ms = 0, maxSlice = 0 }; J.stats[name] = s end
    return s
end

local function Find(name)
    for i, j in ipairs(J.list) do if j.name == name then return j, i end end
    return nil
end

local Step

local function Schedule(delay)
    if scheduled then return end
    scheduled = true
    ns.API.TimerAfter(delay or 0, Step)
end

local function Finish(j, ok, err)
    for i, x in ipairs(J.list) do if x == j then table.remove(J.list, i); break end end
    local s = Stat(j.name)
    s.runs, s.lastMs, s.lastSlices = s.runs + 1, j.ms, j.slices
    if not ok and ns.CountError then ns.CountError("Aufgabe " .. j.name, err) end
    if j.again then
        -- asked again while it ran: once more with the newest function
        local fn, opts = j.again, j.opts
        J.Add(j.name, fn, opts)
    end
end

local function RunSlice(j)
    local P = ns.Prices
    if j.opts.pass and P and P.BeginPass then P.BeginPass() end
    current = j
    piece = { n = 0, ms = 0, max = 0 }
    local kb0 = J.Mem()
    sliceStart = Clock()
    local ok, err = coroutine.resume(j.co)
    local t1 = Clock()
    local kb1 = J.Mem()
    current = nil
    local got = piece
    piece = nil
    if j.opts.pass and P and P.EndPass then P.EndPass() end
    local ms = (sliceStart and t1) and (t1 - sliceStart) or 0
    sliceStart = nil
    j.slices, j.ms = j.slices + 1, j.ms + ms
    local s = Stat(j.name)
    s.slices, s.ms = s.slices + 1, s.ms + ms
    if ms > s.maxSlice or not s.maxInfo then
        s.maxSlice = math.max(s.maxSlice, ms)
        s.maxInfo = { pieces = got.n, piecesMs = got.ms, pieceMax = got.max, what = got.what, kb0 = kb0, kb1 = kb1,
            gap = frameGap, fps = J.Fps(), calls = got.whatCalls, callsMs = got.whatCallsMs }
    end
    ns.PerfNote("Aufgabe " .. j.name, ms)
    if not ok then Finish(j, false, err); return ms end
    if coroutine.status(j.co) == "dead" then Finish(j, true) end
    return ms
end

Step = function()
    scheduled = false
    -- the frame before this one (Step runs once per frame while jobs wait): only between two frames in a row
    local t = Clock()
    frameGap = (t and lastStep and t >= lastStep and t - lastStep < 200) and (t - lastStep) or nil
    lastStep = (#J.list > 0) and t or nil
    if #J.list == 0 then return end
    local quiet = nil
    local used, paused = 0, 0
    local i = 1
    while i <= #J.list do
        local j = J.list[i]
        if j.opts.quiet then
            if quiet == nil then quiet = J.AHSQuiet() end
            if quiet then
                paused = paused + 1
                Stat(j.name).paused = (Stat(j.name).paused or 0) + 1
                i = i + 1
            else
                local before = #J.list
                used = used + RunSlice(j)
                if #J.list >= before and J.list[i] == j then i = i + 1 end
            end
        else
            local before = #J.list
            used = used + RunSlice(j)
            if #J.list >= before and J.list[i] == j then i = i + 1 end
        end
        if used >= J.BUDGET then break end
    end
    if #J.list == 0 then lastStep = nil end      -- the next job starts without a "frame before"
    if #J.list > 0 and not J.manual then
        -- only paused jobs left: look again in a second (no work every frame while the sniper runs)
        Schedule((paused > 0 and paused == #J.list) and J.QUIET_RECHECK or 0)
    end
    return used, paused
end

-- test routine: one frame by hand (J.manual = true: no timer is started, the case drives the frames)
function J.StepNow() scheduled = false; return Step() end

-- name: unique per kind of work; fn: the work; opts: { quiet = bool, pass = bool, onDone = fn(result) }
function J.Add(name, fn, opts)
    opts = opts or {}
    if J.Sync() then
        -- test routine / no timer: at once, in one piece
        local P = ns.Prices
        local t0 = Clock()
        local ok, res
        -- in a Takt job of this addon (test routine step) the work may hand over to the next frame (Ingametest 0.9.68 HOCH 1:
        -- T134/T67 – the pcall here held the whole job in one frame)
        local pc = ns.TaktPCall or pcall
        if opts.pass and P and P.InPass then ok, res = pc(P.InPass, fn) else ok, res = pc(fn) end
        if t0 then ns.Perf("Aufgabe " .. name, t0) end
        local s = Stat(name)
        s.runs = s.runs + 1
        if not ok and ns.CountError then ns.CountError("Aufgabe " .. name, res) end
        return nil
    end
    local j = Find(name)
    if j then
        if j.slices == 0 then
            j.co, j.opts = coroutine.create(fn), opts
        else
            j.again, j.opts = fn, opts
        end
        return j
    end
    j = { name = name, co = coroutine.create(fn), opts = opts, slices = 0, ms = 0, at = Now() }
    J.list[#J.list + 1] = j
    if not J.manual then Schedule(0) end
    return j
end

function J.Pending(name)
    if name then return Find(name) ~= nil end
    return #J.list > 0
end

-- drop everything (test routine restore, /reload not needed)
function J.Clear()
    J.list = {}
    scheduled = false
    lastStep = nil
end
-- test routine: the next slice without a "frame before" (the sandbox swaps the job list)
function J.ForgetFrame() lastStep = nil end

-- pending jobs go on (after the test routine handed the list back)
function J.Kick()
    if #J.list > 0 and not J.manual and ns.API and ns.API.TimerAfter then
        scheduled = false
        Schedule(0)
    end
end

-- PS-P1: " (darin 9 Stücke 5.1 ms, längstes 1.2 ms Heiltrank · übrig 22.1 ms · Speicher -3.1 MB = Bereinigung im Teil ·
-- Bild davor 33 ms, 30 Bilder/s)" – only measured values, nothing guessed
function J.Why(s)
    local m = s.maxInfo
    if type(m) ~= "table" then return nil end
    local out = {}
    if m.pieces > 0 then
        local what = ""
        if m.what ~= nil then
            local name = m.what
            if type(name) == "table" then
                local ok, n = pcall(ns.RecipeName, name)
                name = ok and n or nil
            end
            if name ~= nil then what = " " .. tostring(name) end
        end
        -- PS-P1 Teil 2: inside the longest piece the longest foreign calls and the rest (our own code)
        local calls = ""
        if type(m.calls) == "table" and #m.calls > 0 then
            local cl = {}
            for _, c in ipairs(m.calls) do cl[#cl + 1] = string.format("%s %.1f ms ×%d", tostring(c[1]), c[2], c[3]) end
            calls = string.format(" [fremd %.1f ms: %s; eigener Code %.1f ms]", m.callsMs or 0, table.concat(cl, ", "),
                math.max(0, m.pieceMax - (m.callsMs or 0)))
        end
        out[#out + 1] = string.format("darin %d Stücke %.1f ms, längstes %.1f ms%s%s", m.pieces, m.piecesMs, m.pieceMax, what, calls)
        out[#out + 1] = string.format("übrig %.1f ms", math.max(0, s.maxSlice - m.piecesMs))
    end
    if m.kb0 and m.kb1 then
        local d = (m.kb1 - m.kb0) / 1024
        out[#out + 1] = string.format("Speicher %+.1f MB%s", d, (m.kb0 - m.kb1 > J.GC_KB) and " = Bereinigung im Teil" or "")
    end
    if m.gap then out[#out + 1] = string.format("Bild davor %.0f ms", m.gap) end
    if m.fps then out[#out + 1] = string.format("%.0f Bilder/s", m.fps) end
    return #out > 0 and (" (" .. table.concat(out, " · ") .. ")") or nil
end

-- for the test report: "alarm 3 Teile 4.1 ms (max 2.0)"
function J.Line()
    local names = {}
    for n in pairs(J.stats) do names[#names + 1] = n end
    table.sort(names)
    local parts = {}
    for _, n in ipairs(names) do
        local s = J.stats[n]
        parts[#parts + 1] = string.format("%s ×%d, Teil max %.1f ms%s%s", n, s.runs, s.maxSlice,
            (s.maxSlice > J.SLOW_MS and J.Why(s)) or "", (s.paused or 0) > 0 and (", Ruhe " .. s.paused) or "")
    end
    return #parts > 0 and table.concat(parts, " · ") or "-"
end
