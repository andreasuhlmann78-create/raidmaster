if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Stufe 2: unsichtbare Lern-Datenbank und Selbstkorrektur (Anweisung der Prüf-Sitzung 10.11. 10:45,
-- Ziel des Nutzers: "nicht sichtbar, aber extrem nützlich", so einfach wie möglich)
--
-- Sichtbar wird nichts Neues - nur bessere Zahlen in dem, was es schon gibt (Tooltip, Preisvorschlag, Heute tun,
-- Wächter-Grenzen). Mit Shift: Quelle und Sicherheit. Option "Lernen" (Standard an) schaltet alles ab: dann rechnet
-- AHSentinel genau wie vor Stufe 2.
--
-- L1  Verkaufschance je Preislage (rel = Preis/Marktwert) und Laufzeit aus dem Prognose-Journal, abgelaufene und
--     abgebrochene Auktionen zählen als "nicht verkauft" (Zensur, nie weglassen).
-- L2  Schrumpfen: Item <- Warengruppe <- alle Spieler (Sync, ohne Namen, nur Zähler) <- Startwert (k = 10).
-- L3  Absatz: Vollscan-Messung zuerst; seltene eigene Verkäufe mit Croston/SBA; gelernter Faktor je Gruppe statt
--     des festen Deckels (SELL_CAP 20 %).
-- L4  Preisgrenzen je Item: Minimum / Normal (Chance ~80 %) / Maximum.
-- L5  Menge je Einstellung (Absatz × Laufzeit), Hinweis "noch N in der Tasche".
-- L6  Teurer neu einstellen (Meine Auktionen, nur Hinweis + Knopf).
-- L7  Kauf-Sicherheit: Marge je Strategie aus dem gemessenen Fehler, Tagesbudget solange die Trefferquote < 60 %.
-- L8  Verlustgrenze: gekaufte Ware, deren Marktwert um > 25 % fiel -> einmal Hinweis in Heute tun.
-- L9  Rhythmus (ab 21 Tagen, nur wenn stabil): günstige/teure Stunde und Wochentag.
-- L10 Selbstkorrektur je Woche oder 50 neue Fälle: Faktoren für Dauer und Chance, gedämpft ±30 %, Protokoll LERNEN.
-- L11 Ausprobieren (Option, Standard AUS): 1 von 10 Einstellungen +5 %, im Journal markiert.
--
-- SCHUTZ: nur die neue Tabelle db.learn. Buchhaltung, Entzauber-Daten, Preisverlauf und Prognose-Journal werden nur
-- gelesen. Testroutine: Ersatz Ln.testDB.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local CreateFrame, C_Timer = A.OwnCreateFrame or CreateFrame, A.OwnTimer or C_Timer      -- VS-BILD-2 (0.65.320): eigene Skripte/Zeitgeber je Bild messen (nur während einer Vollscan-Messung)
local L = A.L

local Ln = {}
A.Learn = Ln

Ln.K = 10                                   -- Startwert / Gruppe zählt wie 10 Fälle (wie beim Entzaubern)
Ln.START = { 0.75, 0.60, 0.50, 0.35, 0.20 } -- Startwert P(verkauft in 24 Std.) je Preislage (vermutet, wird überschrieben)
Ln.START_DUR = { [2] = 0.5, [8] = 0.75, [24] = 1 }
Ln.REL_REP = { 0.88, 0.94, 1.00, 1.065, 1.15 } -- Vertreter je Preislage für die Preisgrenzen
Ln.NORMAL_P = 0.8                           -- L4: Normalpreis = höchste Preislage mit Chance >= 80 %
Ln.MAX_FACTOR = 1.25
Ln.MIN_LIMIT_N = 10                         -- L4: erst ab so vielen Fällen (Item + Gruppe) gelernte Grenzen
Ln.CROSTON_ALPHA = 0.1
Ln.CROSTON_ZERO = 0.35                      -- L3: selten = mehr als 35 % der Tage ohne Verkauf
Ln.FACTOR_MIN_ITEMS = 5                     -- L3: gelernter Faktor je Gruppe ab so vielen gemessenen Items
Ln.MARGIN_MIN, Ln.MARGIN_START, Ln.MARGIN_N = 0.10, 0.20, 20
Ln.BUDGET_HIT = 0.6                         -- L7: Tagesbudget, solange die Trefferquote darunter liegt
Ln.LOSS_DROP = 0.25                         -- L8
Ln.RHYTHM_DAYS, Ln.RHYTHM_DIFF = 21, 0.10   -- L9
Ln.CORR_DAYS, Ln.CORR_CASES, Ln.CORR_STEP = 7, 50, 0.30   -- L10
Ln.EXPLORE_EVERY, Ln.EXPLORE_UP = 10, 1.05  -- L11
Ln.SHARE_MAX_N = 5000                       -- L2: Plausibilität geteilter Zähler
Ln.SHARE_EVERY = 20                         -- nach so vielen neuen abgeschlossenen Fällen teilen
Ln.SHARE_MAX_AGE = 90 * 86400

-- ------------------------------------------------------------
-- Schalter und Speicher
-- ------------------------------------------------------------
function Ln:On()
    if self.forceOff then return false end
    local s = A.db and A.db.settings
    return not (s and s.learn == false)
end

local function NewDB() return { v = 1, corr = {}, shared = {}, warned = {}, rhythm = {}, exploreN = 0, lastCorr = 0, corrCases = 0, sharedCases = 0 } end
function Ln:Real()
    local db = A.db
    if not db then return nil end
    if type(db.learn) ~= "table" then db.learn = NewDB() end
    return db.learn
end
function Ln:Store()
    if self.testDB then return self.testDB end
    if not A.db or A:Simulated() then return nil end
    return self:Real()
end
function Ln:Data()
    if self.testDB then return self.testDB end
    return A.db and A.db.learn
end
A:On("READY", function()
    pcall(Ln.Real, Ln)
    pcall(Ln.WarmFactors, Ln, true)                 -- RUCKEL-1: Faktoren zuerst
    -- RUCKEL-3 (0.65.320, Nachbau echte Daten: erstes Lesen des Journals 13 ms am Stück in cache:warm-today): beim Start vorab in
    -- Portionen lesen, vor den anderen Aufgaben
    if A.Job then
        A:Job("learn:buys", function() Ln:BuyEntries(true) end)
        if #A.jobs > 1 and A.jobs[#A.jobs].name == "learn:buys" then table.insert(A.jobs, 1, table.remove(A.jobs)) end
    end
end)

-- ------------------------------------------------------------
-- L1/L2 Verkaufschance je Preislage
-- ------------------------------------------------------------
local function Fc() return A.Forecast end

-- Zellen eines Items aus dem Ringpuffer (Item-Ebene nur live; Gruppe kommt aus Fc:Eval mit Zusammenfassung)
function Ln:ItemCells(itemID)
    local F = Fc()
    local f = F and F:Data()
    if not f then return {} end
    local key = #f.list .. ":" .. tostring(f.list[#f.list])
    self.itemCache = (self.itemCache and self.itemCache.key == key and self.itemCache.store == f) and self.itemCache
        or { key = key, store = f, items = nil }
    local c = self.itemCache
    if not c.items then
        c.items = {}
        for _, s in ipairs(f.list) do
            if s:sub(1, 1) == "P" then
                local e = F:Decode(s)
                local y = e and F:PostOutcome(e)
                if y ~= nil and e.rel and e.d then
                    local it = c.items[e.id] or {}
                    local rk = F:RelClass(e.rel) .. ":" .. F:DurKey(e.d)
                    local cell = it[rk] or { 0, 0, 0, 0, hs = {} }
                    cell[1], cell[2] = cell[1] + 1, cell[2] + y
                    if (e.sq or 0) > 0 and e.sh then cell[3], cell[4] = cell[3] + e.sh, cell[4] + 1; cell.hs[#cell.hs + 1] = e.sh end
                    it[rk] = cell
                    it.n = (it.n or 0) + 1
                    c.items[e.id] = it
                end
            end
        end
    end
    return c.items[itemID] or {}
end

-- Punkt 3: nur der Zwischenspeicher (Tooltip-Pfad), die Neuberechnung läuft im Hintergrund
function Ln:GroupCells(g)
    local F = Fc()
    if not F then return {} end
    local ok, R = pcall(F.EvalCached, F)
    local x = ok and R and R.P[g]
    return (x and x.rel) or {}
end

-- geteilte Zähler aller Spieler (Summe) je Gruppe und Zelle
function Ln:SharedCell(g, rk)
    local db = self:Data()
    local n, y = 0, 0
    for _, rec in pairs(db and db.shared or {}) do
        local c = rec.c and rec.c[g .. "|" .. rk]
        if c then n, y = n + c[1], y + c[2] end
    end
    return n, y
end

-- Rückgabe: Chance (0..1), Info { nItem, nGroup, nShared, src, hours }
function Ln:Chance(itemID, rel, hours, g)
    local F = Fc()
    if not F then return nil end
    g = g or F:Group(itemID)
    local c = F:RelClass(rel or 1)
    local d = F:DurKey(hours or 24)
    local rk = c .. ":" .. d
    local db = self:Data()
    local corr = db and db.corr and db.corr[g]
    local p0 = self.START[c] * (self.START_DUR[d] or 1) * ((corr and corr.p) or 1)
    p0 = math.max(0.01, math.min(0.99, p0))
    local ns, ys = self:SharedCell(g, rk)
    local pS = (ys + self.K * p0) / (ns + self.K)
    local gc = self:GroupCells(g)[rk]
    local ng, yg = gc and gc[1] or 0, gc and gc[2] or 0
    local pG = (yg + self.K * pS) / (ng + self.K)
    local ic = itemID and self:ItemCells(itemID)[rk]
    local ni, yi = ic and ic[1] or 0, ic and ic[2] or 0
    local p = (yi + self.K * pG) / (ni + self.K)
    local src = (ni >= self.K and "item") or (ng >= self.K and "group") or (ns >= self.K and "shared") or "start"
    -- Median-Dauer: Item (genau), sonst Mittel der Gruppe
    local hrs
    if ic and #ic.hs > 0 then
        table.sort(ic.hs)
        hrs = ic.hs[math.floor((#ic.hs + 1) / 2)]
    elseif gc and gc[4] > 0 then hrs = gc[3] / gc[4] end
    return p, { nItem = ni, nGroup = ng, nShared = ns, src = src, hours = hrs, cell = rk, group = g }
end

-- Text der Quelle (Tooltip mit Shift)
function Ln:SourceText(info)
    if not info then return nil end
    if info.src == "item" then return string.format(L["gelernt aus %d eigenen Verkäufen"], info.nItem) end
    if info.src == "group" then return string.format(L["gelernt aus der Warengruppe (%d Fälle)"], info.nGroup) end
    if info.src == "shared" then return string.format(L["gelernt von allen Spielern (%d Fälle)"], info.nShared) end
    return L["Startwert (noch nichts gelernt)"]
end

-- ------------------------------------------------------------
-- L3 Absatz: Croston/SBA für seltene eigene Verkäufe, gelernter Faktor je Gruppe
-- ------------------------------------------------------------
function Ln:LedgerEntries() return A.db and A.db.ledger and A.db.ledger.entries or {} end     -- eigene Funktion (Seam)

-- daily: Liste Stück je Tag (älteste zuerst). Rückgabe Absatz/Tag oder nil (nicht selten / zu wenig)
function Ln:CrostonRate(daily)
    local zeros, nz = 0, 0
    for _, q in ipairs(daily) do if q > 0 then nz = nz + 1 else zeros = zeros + 1 end end
    if nz < 3 or zeros / #daily <= self.CROSTON_ZERO then return nil end
    local a = self.CROSTON_ALPHA
    local z, p, gap
    for _, q in ipairs(daily) do
        gap = (gap or 0) + 1
        if q > 0 then
            if not z then z, p = q, gap
            else z, p = z + a * (q - z), p + a * (gap - p) end
            gap = 0
        end
    end
    return z / p * (1 - a / 2)
end

function Ln:Croston(itemID, now)
    if not self:On() then return nil end
    now = now or time()
    local days = 30
    local daily = {}
    for i = 1, days do daily[i] = 0 end
    local from = now - days * 86400
    local any = false
    for _, e in ipairs(self:LedgerEntries()) do
        if e.kind == "sale" and e.itemID == itemID and (e.t or 0) >= from then
            local i = math.min(days, math.floor(((e.t or 0) - from) / 86400) + 1)
            daily[i] = daily[i] + (e.qty or 1)
            any = true
        end
    end
    if not any then return nil end
    return self:CrostonRate(daily)
end

-- gelernter Faktor je Gruppe: Median (gemessen / alte Rohschätzung) über Items mit Vollscan-Messung
-- RUCKEL-1 (0.65.318, Nachbau mit den echten Daten: 32 ms am Stück, im Spiel mehr): vorher ging JEDE Gruppe einzeln über alle
-- gemessenen Items (VS:MeasuredRate je Item) - bis zu 8 Durchläufe je Stunde, jeder ohne Pause. Jetzt EIN Durchlauf für alle
-- Gruppen (gleiche Regel, gleiche Zahlen), und nach jedem Vollscan und zur vollen Stunde rechnet ihn die Hintergrund-Aufgabe
-- "learn:factor" in Portionen vor. Erst wenn die Tabelle für den aktuellen Schlüssel noch fehlt, rechnet der Aufruf selbst
-- (ein Durchlauf, wie bisher am Stück).
function Ln:FactorKey()
    local VS = A.FullScan
    local st = VS and VS:Data()
    if not (st and st.sold) then return nil end
    -- NP-AHS318-1 (0.65.320): Schlüssel aus dem Messstand (Zeit des letzten gültigen Vollscans) statt next(st.sold) - st.sold bleibt
    -- bestehen, next() lieferte fast immer dasselbe Item, neu gerechnet wurde nur zur vollen Stunde
    local first, hour = tostring(st.lastGood or 0), math.floor(time() / 3600)
    return first .. ":" .. hour, st, VS, first, hour
end
-- ein Durchlauf über alle gemessenen Items -> { key, f = { [g] = Median oder false }, n = { [g] = Anzahl } }
-- pause = true: in einer Hintergrund-Aufgabe (A:Pause je Item)
function Ln:BuildFactors(key, st, VS, pause, first, hour)
    local F = Fc()
    local byG = {}
    local reuse = {}                                      -- AHS-SP2 (iii) c): eine Tabelle für das gelesene x aller Items
    for id in pairs(st.sold) do
        if pause then A:Pause() end
        local m = VS:MeasuredRate(id, reuse)
        if m and F then
            local g = F:Group(id)
            local okL, l = pcall(A.GetLiquidity, A, id)
            -- TS111.2: gegen die UNABHÄNGIGE Schätzung (l.estimate), nie gegen den schon gemessenen perDay
            local est = okL and l and l.estimate
            if g and est and est > 0 then
                local r = byG[g]
                if not r then r = {}; byG[g] = r end
                r[#r + 1] = m / est
            end
        end
    end
    local fc = { key = key, f = {}, n = {}, first = first, hour = hour, st = st }
    for g, ratios in pairs(byG) do
        fc.n[g] = #ratios
        if #ratios >= self.FACTOR_MIN_ITEMS then
            table.sort(ratios)
            fc.f[g] = ratios[math.floor((#ratios + 1) / 2)]
        else
            fc.f[g] = false
        end
    end
    return fc
end
function Ln:MarketFactor(g)
    if not self:On() then return nil end
    local key, st, VS, first, hour = self:FactorKey()
    if not key then return nil end
    local fc = self.factorCache
    -- neuer Scan oder volle Stunde (gleiche Datentabelle): bis "learn:factor" fertig ist, gelten die Zahlen der letzten Rechnung
    -- (Sekunden; die Aufgabe ist begrenzt) - andere Datentabelle (z. B. Testroutine) oder noch nie gerechnet: sofort am Stück
    local hourOnly = fc and fc.key ~= key and fc.st == st
    if hourOnly and (A:HasJob("learn:factor") or self:WarmFactors()) then
        self.factorStale = (self.factorStale or 0) + 1
    elseif not fc and A:HasJob("learn:factor") and not (A.TestRoutine and A.TestRoutine.running) then
        -- E3 (Befund HOCH 21:45, Nachbau mit echten Daten: erster API.NetSale nach dem Laden 43,6 ms / 2,9 MB am Stück, ganz hier):
        -- die Faktoren werden beim Start schon in Portionen vorgerechnet ("learn:factor", vorne in der Reihe). Fragt jemand, bevor
        -- sie fertig sind, rechnet er sie nicht mehr am Stück nach - bis dahin ohne Faktor (wie bei einer Gruppe ohne Messung);
        -- sind sie da, rechnen alle Zwischenspeicher neu (A.waysVer, siehe WarmFactors).
        self.factorPending = (self.factorPending or 0) + 1
        return nil, 0
    elseif not (fc and fc.key == key) then
        fc = self:BuildFactors(key, st, VS, false, first, hour)
        self.factorCache = fc
        self.factorSync = (self.factorSync or 0) + 1          -- Testnaht/Auskunft: wie oft am Stück gerechnet
    end
    local f = fc.f[g]
    if f == nil then return nil, 0 end                         -- Gruppe ohne gemessenes Item (wie vorher: 0 Items)
    return f or nil, fc.n[g]
end
-- E3-Auflage (Supervisor 22:45, Punkt 3): true, solange MarketFactor ohne Faktor antwortet, weil die allererste Rechnung als
-- Hintergrund-Aufgabe noch läuft (nur dann; in der Testroutine wird am Stück gerechnet). Abnehmer: SellOutlook (v.provisional),
-- API (nil statt vorläufigem Wert), Sniper (wartet).
function Ln:FactorPending()
    if self.testPending ~= nil then return self.testPending end          -- Naht für die Testroutine (T906)
    if self.factorCache or (A.TestRoutine and A.TestRoutine.running) then return false end
    if not (A.HasJob and A:HasJob("learn:factor")) then return false end
    return self:On() and true or false
end
-- Hintergrund-Aufgabe: Faktoren für den aktuellen Schlüssel vorrechnen (nur wenn sie fehlen)
function Ln:WarmFactors(front)
    if not self:On() or A:HasJob("learn:factor") then return false end
    local key = self:FactorKey()
    if not key or (self.factorCache and self.factorCache.key == key) then return false end
    A:Job("learn:factor", function()
        local k, st, VS, first, hour = self:FactorKey()
        if not k or (self.factorCache and self.factorCache.key == k) then return end
        local ok, fc = A:PCall(self.BuildFactors, self, k, st, VS, true, first, hour)
        -- nur übernehmen, wenn der Schlüssel unterwegs gleich blieb und noch keiner am Stück gerechnet hat
        if ok and fc and self:FactorKey() == k and not (self.factorCache and self.factorCache.key == k) then
            local first = self.factorCache == nil
            self.factorCache = fc
            self.factorWarm = (self.factorWarm or 0) + 1
            -- E3: wurde vorher ohne Faktor geantwortet, alle Zwischenspeicher (Lohnt bis, Markt, Heute) neu rechnen lassen
            if first and (self.factorPending or 0) > 0 then
                A.waysVer = (A.waysVer or 0) + 1; self.factorPending = 0
                -- E3 (Prüfung 23:40): Abnehmer der API, die in dieser Zeit nil bekamen, erfahren, dass es jetzt Werte gibt
                -- (bestehender Grund "settings" - Vertrag Version 1 unverändert)
                if A.API and A.API.Notify then pcall(A.API.Notify, "settings") end
            end
        end
    end)
    -- front (beim Start): vor die anderen Aufgaben, damit deren erste Rechnung die Faktoren nicht am Stück braucht
    if front and #A.jobs > 1 and A.jobs[#A.jobs].name == "learn:factor" then table.insert(A.jobs, 1, table.remove(A.jobs)) end
    return true
end
do
    local tick = CreateFrame("Frame")
    local wait = 0
    tick:SetScript("OnUpdate", function(_, dt)
        wait = wait + (dt or 0)
        if wait < 30 then return end                               -- alle 30 s prüfen (zur vollen Stunde neu)
        wait = 0
        if A.db and not (A.TestRoutine and A.TestRoutine.running) then pcall(Ln.WarmFactors, Ln) end
    end)
end

-- ------------------------------------------------------------
-- L10 Selbstkorrektur
-- ------------------------------------------------------------
function Ln:Corr(g)
    local db = self:Data()
    local c = db and db.corr and db.corr[g]
    if not self:On() or not c then return 1, 1 end
    return c.d or 1, c.p or 1
end

-- gedämpft: höchstens ±CORR_STEP je Schritt, insgesamt 0,3 .. 3
local function Damp(old, target, step)
    local lo, hi = old * (1 - step), old * (1 + step)
    return math.max(0.3, math.min(3, math.max(lo, math.min(hi, target))))
end
Ln.Damp = Damp

function Ln:SelfCorrect(now, force, given)
    local db = self:Store()
    local F = Fc()
    if not (db and F and self:On()) then return 0 end
    now = now or time()
    -- X7 (Befund 0.65.86): Fälle vor der Behebung der Rechnungs-Zuordnung (0.65.88) lernen nicht mit
    if not db.x7Since then db.x7Since = now end
    -- (ein mitgegebenes Gesamt-Ergebnis enthält auch alte Fälle - deshalb immer die gefilterte Zählung)
    local ok, R = pcall(F.EvalSince, F, db.x7Since)
    if not (ok and R) then return 0 end
    local done = R.all.n
    if not force and now - (db.lastCorr or 0) < self.CORR_DAYS * 86400 and done - (db.corrCases or 0) < self.CORR_CASES then return 0 end
    local changed = 0
    for g, x in pairs(R.P) do
        if x.n >= 10 then
            local c = db.corr[g] or { d = 1, p = 1 }
            local oldD, oldP = c.d or 1, c.p or 1
            -- Chance: tatsächlich verkauft / vorhergesagt
            if x.sp > 0 then c.p = Damp(oldP, oldP * (x.sy / x.sp), self.CORR_STEP) end
            -- Dauer: Median tatsächlich / vorhergesagt (Histogramm, gedämpft)
            if x.durN >= 5 then
                local med = F.Median({}, x.dur, x.durN, F.DUR_B)
                if med then c.d = Damp(oldD, oldD * med, self.CORR_STEP) end
            end
            c.n, c.t = x.n, now
            db.corr[g] = c
            if math.abs(c.d - oldD) > 1e-6 or math.abs(c.p - oldP) > 1e-6 then
                changed = changed + 1
                if A.Diag and not self.testDB then
                    pcall(A.Diag.Add, A.Diag, "LERNEN", string.format("Gruppe %s · Dauer %.2f -> %.2f · Chance %.2f -> %.2f · N %d", g, oldD, c.d, oldP, c.p, x.n))
                end
            end
        end
    end
    db.lastCorr, db.corrCases = now, done
    if A.ResetOutlook then A:ResetOutlook() end
    return changed
end

-- ------------------------------------------------------------
-- L4 Preisgrenzen
-- ------------------------------------------------------------
-- Rückgabe min, normal, max, info (nil, wenn zu wenig gelernt)
function Ln:MarketValue(itemID) return A:GetMarketValue(itemID) end        -- eigene Funktion (Seam)
-- Händlerwert bzw. Einstandspreis (Einkauf der letzten 30 Tage oder Herstellkosten) - das Höhere
function Ln:BaseValue(itemID)
    local base = 0
    local vendor = A:GetVendorPrice(itemID)
    if type(vendor) == "number" and vendor > base then base = vendor end
    local Se = A.Seller
    local okC, cost = false, nil
    if Se and Se.CostPerPiece then okC, cost = pcall(Se.CostPerPiece, Se, itemID) end
    if okC and cost and cost > base then base = cost end
    return base
end

function Ln:Limits(itemID, hours)
    if not (self:On() and itemID) then return nil end
    local mv = self:MarketValue(itemID)
    if not mv or mv <= 0 then return nil end
    -- Laufzeit, mit der der Spieler einstellt (Standard-Laufzeit; andere Versionen 24 Std.)
    if not hours and A.DefaultDuration then
        local okD, h = pcall(A.DefaultDuration, A, itemID, 1)
        if okD then hours = h end
    end
    hours = hours or 24
    local F = Fc()
    local g = F and F:Group(itemID) or "misc"
    local normalRel, info0, nTotal
    for c = #self.REL_REP, 1, -1 do
        local p, info = self:Chance(itemID, self.REL_REP[c], hours, g)
        nTotal = info and (info.nItem + info.nGroup) or 0
        if p and p >= self.NORMAL_P then normalRel, info0 = self.REL_REP[c], info; break end
        info0 = info
    end
    if (nTotal or 0) < self.MIN_LIMIT_N then return nil end
    normalRel = normalRel or self.REL_REP[1]
    local normal = math.floor(mv * normalRel + 0.5)
    local max = math.floor(normal * self.MAX_FACTOR + 0.5)
    -- Minimum: Netto nach AH-Anteil und erwartetem Einzahlungsverlust mindestens Händlerwert bzw. Einstandspreis
    local base = self:BaseValue(itemID) or 0
    local loss = 0
    if A:IsForever() and A.ExpectedDepositLoss then
        local okN, n = pcall(A.ExpectedListings, A, itemID, 1, normal)
        if okN and n and n > 1 then
            local okL, l = pcall(A.ExpectedDepositLoss, A, itemID, 1, n)
            if okL and type(l) == "number" then loss = l end
        end
    end
    local min = math.ceil((base + loss) / math.max(0.01, 1 - A:CutPct()))
    if min <= 0 then min = nil end
    return min, normal, max, info0
end

-- ------------------------------------------------------------
-- L5 Menge je Einstellung
-- ------------------------------------------------------------
-- Rückgabe: Menge zum Einstellen, Rest in der Tasche (nil, wenn keine Grenze nötig/bekannt)
function Ln:PostCap(itemID, have, hours)
    if not (self:On() and itemID and have and have > 1) then return nil end
    local okO, v = pcall(A.SellOutlook, A, itemID, have)
    if not (okO and v and v.perDay and v.perDay > 0) then return nil end
    local cap = math.max(1, math.floor(v.perDay * (hours or 24) / 24 + 0.5))
    if cap >= have then return nil end
    return cap, have - cap
end

-- ------------------------------------------------------------
-- L6 Teurer neu einstellen
-- ------------------------------------------------------------
-- o: eigene Auktion, lowest: günstigstes fremdes Angebot. Rückgabe neuer Preis oder nil
function Ln:RelistHigher(o, lowest)
    if not (self:On() and o and o.unitPrice and lowest and lowest > o.unitPrice) then return nil end
    local Se = A.Seller
    local newPrice = Se and Se:Undercut(lowest, o.itemID) or (lowest - 1)
    -- TU1 (L-AUSREISSER, 0.65.296): nie über dem Verkaufen-Vorschlag neu einstellen - der erkennt Ausreisser (ein einzelnes Angebot
    -- 5× teurer) und Aufkauf; vorher schlug "teurer" 49s 99c vor, weil nur ein Angebot zu 50s im Markt stand (Marktwert 10s).
    if Se and Se.SuggestRaw and o.itemID then
        local okS, sug = pcall(Se.SuggestRaw, Se, o.itemID)
        if not (okS and type(sug) == "number" and sug > 0) then return nil end
        if Se.RoundPrice then sug = Se:RoundPrice(o.itemID, sug) or sug end
        -- AHS-I2 b (T875, Ingametest 23.11.: "teurer@980" statt @989): newPrice kam aus Se:Undercut mit der UNTERBIETEN-EINSTELLUNG des
        -- Spielers (z. B. 1 % -> 980) und war damit tiefer als der Vorschlag; V1 (Nutzer 21.11.) kennt nur EINE Regel -> neu einstellen
        -- zum Verkaufen-Vorschlag (V1: 1c unter der günstigsten Stufe), Undercut nur noch ohne Vorschlag
        newPrice = sug
    end
    if newPrice <= o.unitPrice then return nil end
    local qty = math.max(1, o.qty or 1)
    local dep = o.deposit or (o.itemID and A:ListingDeposit(o.itemID, qty, 24, 1)) or 0
    local gain = (newPrice - o.unitPrice) * qty
    if gain > dep + 0.10 * o.unitPrice * qty then return newPrice, gain, dep end
    return nil
end

-- ------------------------------------------------------------
-- L7 Kauf-Sicherheit: Marge und Tagesbudget je Strategie (e = Flip/Einstellen, d = Entzaubern, v = Händler)
-- ------------------------------------------------------------
-- RUCKEL-1 (0.65.318, Ingametest 17.11.: core:realcheck 21–58 ms und cache:today 16–34 ms je Schritt; Nachbau mit den echten
-- Daten: Learn:BuyStats las bei JEDEM Aufruf das ganze Journal (bis 3000 Einträge) mit Fc:Decode – aus MK:BeginBatch alle 200
-- Items und aus MK:FlipLimitFromNet je Item). Jetzt: die gelesenen Kauf-Einträge ("B") bleiben zwischengespeichert, solange das
-- Journal genau dasselbe ist. Geprüft wird das je Aufruf exakt: dieselbe Tabelle, dieselbe Länge und an jeder Stelle dieselbe
-- Zeichenkette (Vergleich ohne Lesen, billig). Fc:Decode hängt nur von der Zeichenkette ab -> gleiches Ergebnis wie vorher.
-- Die Einträge sind nur zum Lesen da (Aufrufer ändern sie nicht). Rückgabe: Liste { e, ... } in Journal-Reihenfolge.
Ln.buyCache = nil
function Ln:BuyEntries(pause)
    local F = Fc()
    local f = F and F:Data()
    local list = f and f.list
    if type(list) ~= "table" then return {} end
    local c = self.buyCache
    local n = #list
    if c and c.list == list and c.n == n then
        local snap, same = c.snap, true
        for i = 1, n do
            if snap[i] ~= list[i] then same = false; break end
        end
        if same then return c.entries end
    end
    -- neu aufbauen: schon gelesene Zeichenketten nicht nochmals lesen (gleiche Zeichenkette = gleiches Ergebnis), nur neue/geänderte
    local old = c and c.map or {}
    local snap, entries, map = {}, {}, {}
    for i = 1, n do
        local s = list[i]
        snap[i] = s
        if pause and i % 200 == 0 then A:Pause() end           -- RUCKEL-3: erstes Lesen beim Start in Portionen (Aufgabe learn:buys)
        if type(s) == "string" and s:sub(1, 1) == "B" then
            local e = map[s] or old[s]
            if e == nil then e = F:Decode(s) or false end
            map[s] = e
            if e then entries[#entries + 1] = e end
        end
    end
    self.buyCache = { list = list, n = n, snap = snap, entries = entries, map = map }
    self.buyCacheBuilds = (self.buyCacheBuilds or 0) + 1        -- Testnaht: wie oft neu gelesen
    return entries
end

function Ln:BuyStats(way)
    local F = Fc()
    local D = A.Disenchant
    local ratios, n, win = {}, 0, 0
    local sR, sE = 0, 0                                   -- KF2: Summen (Zufallsbeute: Summe statt Median)
    for _, e in ipairs(self:BuyEntries()) do
        do
            if e.r == "c" and (e.way or "e") == way and e.ev and e.ev > 0 then
                n = n + 1
                local ratio = (e.rv or 0) / (e.ev * (e.q or 1))
                -- Frage LB (Prüf-Sitzung 20:50): beim Entzaubern ist ev UNKORRIGIERT (Fc:DEPrediction), der angezeigte
                -- Wert aber schon mit dem Materialpreis-Faktor (S1, z. B. ×0,57) gerechnet. Ohne diese Anpassung
                -- steckte derselbe Fehlbetrag zweimal in "Lohnt bis" (Wert ×0,57 und Marge 1 − 0,59). Die Marge misst
                -- jetzt nur, was die Korrektur NICHT schon erklärt.
                if way == "d" and e.id and D and D.CorrectionFor then
                    local okC, f = pcall(D.CorrectionFor, D, e.id)
                    if okC and type(f) == "number" and f > 0 and f < 1 then ratio = ratio / f end
                end
                ratios[#ratios + 1] = ratio
                sR = sR + (e.rv or 0)
                sE = sE + (e.rv or 0) / math.max(1e-9, ratio)
                if (e.rv or 0) > (e.pr or 0) * (e.q or 1) then win = win + 1 end
            end
        end
    end
    -- Zusammenfassung (aus dem Ringpuffer gefallene Käufe)
    -- Nachtrag 06:50 (HOCH): "local _, st = F and F:Data()" lieferte st IMMER nil ("and" kürzt auf einen Wert) - die Zusammenfassung
    -- der aus dem Ringpuffer gefallenen Käufe floss nie in nAll/winAll ein
    local st
    if F then local _, s2 = F:Data(); st = s2 end
    local x = st and st.B and st.B[way]
    local nAll, winAll = n + (x and x.n or 0), win + (x and x.win or 0)
    return ratios, nAll, winAll, sR, sE
end

-- LANG-3 (Befund 19:08 Punkt 3, Nachbau mit echten Daten: T556/T579/T30.14 zu 50–60 % hier): Margin las bei JEDEM Aufruf alle
-- Käufe neu (BuyStats, je Entzauber-Kauf D:CorrectionFor) - je "Lohnt bis" mehrfach. Jetzt gemerkt, solange dieselben Käufe
-- (BuyEntries: dieselbe Liste), derselbe Scan, dieselbe Korrektur-Funktion und dieselben Grenzen gelten, höchstens 30 s.
function Ln:Margin(way)
    if not self:On() then return 0 end
    way = way or "e"
    local D = A.Disenchant
    -- Schlüssel ohne die Fall-Liste zu durchlaufen (BuyEntries prüft je Aufruf alle Einträge, im Nachbau mit echten Daten der
    -- grösste Teil von T556/T579): Liste (Tabelle), Länge und Änderungszähler Fc.listGen (jedes Anfügen/Ändern in Forecast.lua)
    local F = Fc()
    local f, st = nil, nil
    if F then f, st = F:Data() end
    local list = f and f.list
    local key = table.concat({ tostring(list), tostring(type(list) == "table" and #list or 0), tostring(F and F.listGen or 0), tostring(st),
        tostring(A.db and A.db.lastScanTime), tostring(D and D.CorrectionFor),
        tostring(self.MARGIN_N), tostring(self.MARGIN_MIN), tostring(self.MARGIN_START), tostring(self.BuyStats) }, "|")
    local mc = self.marginCache
    if not mc or mc.key ~= key or GetTime() - mc.t > 30 then mc = { key = key, t = GetTime() }; self.marginCache = mc end
    local hit = mc[way]
    if hit then return hit[1], hit[2] end
    local m, n = self:MarginCalc(way)
    mc[way] = { m, n }
    return m, n
end
function Ln:MarginCalc(way)
    local ratios, n, _, sR, sE = self:BuyStats(way or "e")
    if n < self.MARGIN_N or #ratios == 0 then return self.MARGIN_START, n end
    local med
    if (way or "e") == "d" and sE and sE > 0 then
        med = sR / sE                                     -- KF2: Entzaubern = Zufallsbeute -> Summe Erlös / Summe Erwartung
    else
        table.sort(ratios)
        med = ratios[math.floor((#ratios + 1) / 2)]
    end
    return math.max(self.MARGIN_MIN, math.min(0.5, 1 - med)), n
end

-- Kaufgrenze je Stück: erwarteter Netto-Wert × (1 − Marge)
function Ln:BuyLimit(value, way)
    if not (value and self:On()) then return value end
    return math.floor(value * (1 - (self:Margin(way))))
end

function Ln:BudgetPct()
    local s = A.db and A.db.settings
    local p = s and s.learnBudget
    if p == 0 or p == false then return nil end
    -- K1: Standard = Markt-Anteil des Golds (25 %), nie darüber
    local pct = tonumber(p) or A:MarketCapitalPct()
    return math.min(pct, A:MarketCapitalPct()) / 100
end

-- Rest des Tagesbudgets (Kupfer) oder nil (kein Budget nötig: Trefferquote >= 60 % oder Option aus)
function Ln:BudgetLeft(way, now)
    if not self:On() then return nil end
    local pct = self:BudgetPct()
    if not pct then return nil end
    local _, n, win = self:BuyStats(way)
    if n >= self.MARGIN_N and win / n >= self.BUDGET_HIT then return nil end
    local gold = GetMoney and GetMoney() or 0
    local limit = math.floor(gold * pct)
    local today = A:DayStart(now or time())
    local spent = 0
    local list = self:BuyEntries()                        -- RUCKEL-1: gelesene Kauf-Einträge (gleiche Reihenfolge)
    for i = #list, 1, -1 do
        local e = list[i]
        if (e.t or 0) < today then break end
        if (e.way or "e") == way then spent = spent + (e.pr or 0) * (e.q or 1) end
    end
    return math.max(0, limit - spent), limit, spent
end

-- ------------------------------------------------------------
-- L8 Verlustgrenze
-- ------------------------------------------------------------
-- offene Käufe, deren Marktwert seit dem Kauf um mehr als 25 % fiel (je Kauf einmal)
function Ln:LossWarnings(now, mark)
    if not self:On() then return {} end
    local db = self:Data()
    local out = {}
    for _, e in ipairs(self:BuyEntries()) do              -- RUCKEL-1: gelesene Kauf-Einträge
        do
            if e.r ~= "c" and e.mv and e.mv > 0 then
                local key = e.id .. ":" .. (e.t or 0)
                local cur = self:MarketValue(e.id)
                if cur and cur < e.mv * (1 - self.LOSS_DROP) and not (db and db.warned and db.warned[key]) then
                    local left = (e.q or 1) - (e.rq or 0)
                    local price = A:GetCurrent(e.id) or cur
                    local okN, now0 = pcall(A.NetSale, A, e.id, price, left)
                    if not okN then now0 = price * left end
                    local okW, wait = pcall(A.RealValue, A, e.id, left)
                    out[#out + 1] = { itemID = e.id, key = key, qty = left, buy = e.pr, mv0 = e.mv, mv = cur, sellNow = now0,
                        waitValue = okW and wait or nil }
                end
            end
        end
    end
    if mark then
        local st = self:Store()
        if st then for _, w in ipairs(out) do st.warned[w.key] = now or time() end end
    end
    return out
end

-- ------------------------------------------------------------
-- L9 Rhythmus (eigene Tabelle db.learn.rhythm, nur gehandelte/beobachtete Items)
-- Format je Item: "erster Tag;24 Stunden gerade Woche;24 ungerade;7 Wochentage gerade;7 ungerade" (Preis-EMA)
-- ------------------------------------------------------------
local function Slots(str, n)
    local t = {}
    for x in (str or ""):gmatch("([^,]*)") do t[#t + 1] = tonumber(x) end
    for i = #t + 1, n do t[i] = nil end
    local out = {}
    for i = 1, n do out[i] = t[i] end
    return out
end
local function Join(t, n)
    local o = {}
    for i = 1, n do o[i] = t[i] and tostring(t[i]) or "" end
    return table.concat(o, ",")
end
function Ln:RhythmRecord(itemID, price, t)
    local db = self:Store()
    if not (db and itemID and price and price > 0) then return end
    t = t or time()
    local first, he, ho, we, wo = (db.rhythm[itemID] or ""):match("^(%d*);([^;]*);([^;]*);([^;]*);([^;]*)$")
    first = tonumber(first) or math.floor(t / 86400)
    local hEven, hOdd, wEven, wOdd = Slots(he, 24), Slots(ho, 24), Slots(we, 7), Slots(wo, 7)
    local week = math.floor(t / (7 * 86400))
    local h = (tonumber(date("%H", t)) or 0) + 1
    local wd = tonumber(date("%w", t)) or 0
    wd = (wd == 0) and 7 or wd                     -- 1 = Montag
    local H, W = (week % 2 == 0) and hEven or hOdd, (week % 2 == 0) and wEven or wOdd
    H[h] = H[h] and math.floor(H[h] * 0.7 + price * 0.3 + 0.5) or price
    W[wd] = W[wd] and math.floor(W[wd] * 0.7 + price * 0.3 + 0.5) or price
    db.rhythm[itemID] = table.concat({ first, Join(hEven, 24), Join(hOdd, 24), Join(wEven, 7), Join(wOdd, 7) }, ";")
end

-- günstigste/teuerste Stelle zweier Hälften; stabil, wenn beide Hälften dieselbe Stelle (±tol) zeigen
local function Extremes(a, b, n, tol)
    local avg = {}
    local sum, cnt = 0, 0
    for i = 1, n do
        if a[i] and b[i] then avg[i] = (a[i] + b[i]) / 2; sum = sum + avg[i]; cnt = cnt + 1 end
    end
    if cnt < math.max(3, n / 2) then return nil end
    local mean = sum / cnt
    local function argmin(t) local k; for i = 1, n do if t[i] and (not k or t[i] < t[k]) then k = i end end return k end
    local function argmax(t) local k; for i = 1, n do if t[i] and (not k or t[i] > t[k]) then k = i end end return k end
    local lo, hi = argmin(avg), argmax(avg)
    if not (lo and hi) or (avg[hi] - avg[lo]) / mean <= Ln.RHYTHM_DIFF then return nil end
    local function near(x, y) local d = math.abs(x - y); d = math.min(d, n - d); return d <= tol end
    local la, lb, ha, hb = argmin(a), argmin(b), argmax(a), argmax(b)
    if not (la and lb and ha and hb and near(la, lo) and near(lb, lo) and near(ha, hi) and near(hb, hi)) then return nil end
    return lo, hi, (avg[hi] - avg[lo]) / mean
end

-- Rückgabe Text oder nil (zu wenig Daten / nicht stabil)
function Ln:Rhythm(itemID, now)
    if not self:On() then return nil end
    local db = self:Data()
    local str = db and db.rhythm and db.rhythm[itemID]
    if not str then return nil end
    local first, he, ho, we, wo = str:match("^(%d*);([^;]*);([^;]*);([^;]*);([^;]*)$")
    first = tonumber(first)
    if not first or math.floor((now or time()) / 86400) - first < self.RHYTHM_DAYS then return nil end
    local parts = {}
    local lo, hi = Extremes(Slots(he, 24), Slots(ho, 24), 24, 2)
    if lo then parts[#parts + 1] = string.format(L["günstig um %d Uhr, teuer um %d Uhr"], lo - 1, hi - 1) end
    local dlo, dhi = Extremes(Slots(we, 7), Slots(wo, 7), 7, 0)
    local DAYS = { L["Montag"], L["Dienstag"], L["Mittwoch"], L["Donnerstag"], L["Freitag"], L["Samstag"], L["Sonntag"] }
    if dlo then parts[#parts + 1] = string.format(L["günstig am %s, teuer am %s"], DAYS[dlo], DAYS[dhi]) end
    if #parts == 0 then return nil end
    return table.concat(parts, " · ")
end

A:On("SCAN_FINISHED", function(_, best, now)
    if not Ln:On() or (A.TestRoutine and A.TestRoutine.running) or type(best) ~= "table" then return end
    pcall(Ln.WarmFactors, Ln)                    -- RUCKEL-1: Faktoren nach dem Scan in Portionen vorrechnen
    local F = Fc()
    if not (F and F.RelevantItems) then return end
    -- 0.65.110 (Ruckeln): in einer Hintergrund-Aufgabe, je Item eine mögliche Portion
    A:Job("learn:rhythm", function()
        local ok, set = A:PCall(F.RelevantItems, F, now)
        if not ok or type(set) ~= "table" then return end
        -- Phase 8 Punkt 3: Raid-Vorrat (Tränke/Essen der Raid-Vorlage) immer mitmessen - sonst fehlt der Wochentag-Effekt
        local RS = A.RaidSupply
        if RS and RS.TrackIDs then
            local okT, ids = pcall(RS.TrackIDs, RS)
            for _, id in ipairs(okT and ids or {}) do set[id] = true end
        end
        for id in pairs(set) do
            A:Pause()
            local p = A.BestGet(best, id)              -- AHS-SP2 (ii): altes und neues Format
            if p then pcall(Ln.RhythmRecord, Ln, id, p, now) end
        end
    end)
end)

-- ------------------------------------------------------------
-- L11 Ausprobieren (Option, Standard aus): jede 10. Einstellung +5 %
-- ------------------------------------------------------------
function Ln:ExploreOn() return self:On() and A.db and A.db.settings and A.db.settings.learnExplore == true or false end

-- Preisvorschlag anpassen (Verkaufen-Reiter). Rückgabe Preis, true wenn erhöht
function Ln:ExplorePrice(itemID, price)
    if not (price and self:ExploreOn()) then return price, false end
    local db = self:Data()
    if not db then return price, false end
    if ((db.exploreN or 0) + 1) % self.EXPLORE_EVERY ~= 0 then return price, false end
    local up = math.floor(price * self.EXPLORE_UP + 0.5)
    self.explorePending = { itemID = itemID, price = up }
    return up, true
end

-- beim Einstellen (Prognose-Journal): zählen und den Test markieren
function Ln:TakeExplore(itemID, price)
    if not self:ExploreOn() then return false end
    local db = self:Store()
    if not db then return false end
    db.exploreN = (db.exploreN or 0) + 1
    local p = self.explorePending
    if p and p.itemID == itemID and math.abs((p.price or 0) - (price or 0)) <= 1 then
        self.explorePending = nil
        return true
    end
    return false
end

-- ------------------------------------------------------------
-- L2 Teilen (GoldSentinelSync, Nachricht "L", nur Zähler je Gruppe und Zelle, keine Namen)
-- ------------------------------------------------------------
function Ln:EncodeCells()
    local S = A.Sync
    local Enc = S and S.Enc
    local F = Fc()
    if not (Enc and F) then return {} end
    local ok, R = pcall(F.Eval, F)
    if not (ok and R) then return {} end
    local parts = {}
    for g, x in pairs(R.P) do
        for rk, c in pairs(x.rel or {}) do
            if c[1] > 0 then
                local cls, d = rk:match("^(%d):(%d+)$")
                parts[#parts + 1] = g .. "." .. cls .. "." .. d .. "~" .. Enc(math.min(c[1], self.SHARE_MAX_N)) .. "~" .. Enc(math.floor(math.min(c[2], c[1]) + 0.5))
            end
        end
    end
    return parts
end

local GROUPS = {}
for _, g in ipairs({ "de", "cloth", "leather", "metal", "herb", "consum", "gear2", "gear3", "misc" }) do GROUPS[g] = true end
Ln.rate = {}

-- Plausibilität: bekannte Gruppe/Klasse/Laufzeit, 0 < n <= SHARE_MAX_N, verkauft <= n, höchstens 1 Sendung je Minute
function Ln:HandleShared(sender, t, payload, now)
    if A.TestRoutine and A.TestRoutine.running and not self.testDB then return 0 end
    local db = self:Store()
    local Dec = A.Sync and A.Sync.Dec
    if not (db and Dec and sender and type(payload) == "string") then return 0 end
    now = now or time()
    if not t or t > now + 300 or t < now - self.SHARE_MAX_AGE then return 0 end
    local D = A.Disenchant
    if D and D.IsOwnChar and D:IsOwnChar(sender) then return 0 end
    local sk = (D and D.SenderKey) and D:SenderKey(sender) or "#?"
    local r = self.rate[sk]
    if r and now - r < 60 then return 0 end
    self.rate[sk] = now
    local cells, taken = {}, 0
    for part in payload:gmatch("[^;]+") do
        local g, cls, d, nEnc, yEnc = part:match("^(%a+%d?)%.(%d)%.(%d+)~(%w+)~(%w+)$")
        local n, y = Dec(nEnc or ""), Dec(yEnc or "")
        cls, d = tonumber(cls), tonumber(d)
        if g and GROUPS[g] and cls and cls >= 1 and cls <= 5 and (d == 2 or d == 8 or d == 24) and n and y
            and n > 0 and n <= self.SHARE_MAX_N and y >= 0 and y <= n then
            cells[g .. "|" .. cls .. ":" .. d] = { n, y }
            taken = taken + 1
        end
    end
    if taken > 0 then db.shared[sk] = { t = now, c = cells } end
    return taken
end

function Ln:Broadcast()
    local S = A.Sync
    if not (self:On() and S and S.IsEnabled and S:IsEnabled() and S:IsConnected() and S.Enqueue) then return false end
    local parts = self:EncodeCells()
    if #parts == 0 then return false end
    local head = "L:" .. S.Enc(time()) .. ":"
    local chunk, size = {}, #head
    for _, p in ipairs(parts) do
        if size + #p + 1 > S.MAX_MSG and #chunk > 0 then
            S.Enqueue(head .. table.concat(chunk, ";"))
            chunk, size = {}, #head
        end
        chunk[#chunk + 1] = p
        size = size + #p + 1
    end
    if #chunk > 0 then S.Enqueue(head .. table.concat(chunk, ";")) end
    self.lastShared = time()
    return true
end

function Ln:HandleRequest()
    if self.lastShared and time() - self.lastShared < 30 * 60 then return end
    if C_Timer and C_Timer.After then C_Timer.After(8 + math.random() * 25, function() Ln:Broadcast() end) end
end

-- nach neuen Ergebnissen: Selbstkorrektur (L10) und Teilen (L2) prüfen - höchstens einmal je Minute
A:On("LEDGER_CHANGED", function()
    if not Ln:On() or (A.TestRoutine and A.TestRoutine.running) then return end
    local now = time()
    if Ln.lastCheck and now - Ln.lastCheck < 60 then return end
    Ln.lastCheck = now
    local F = Fc()
    if not F then return end
    -- Punkt 3: Auswertung in Portionen im Hintergrund, danach Selbstkorrektur und Teilen mit diesem Ergebnis
    F:EvalInBackground(now, function(R)
        if not R then return end
        pcall(Ln.SelfCorrect, Ln, now, false, R)
        local db = Ln:Store()
        if db and R.all.n - (db.sharedCases or 0) >= Ln.SHARE_EVERY then
            db.sharedCases = R.all.n
            pcall(Ln.Broadcast, Ln)
        end
    end)
end)

-- ------------------------------------------------------------
-- Bericht "Lern-Datenbank" (Teil B, echte Daten, nur lesen)
-- ------------------------------------------------------------
-- LANG-3 (Nachbau echte Daten T325 59 ms, ein Drittel hier): in einer Hintergrund-Aufgabe alle 2000 Einträge abgeben (A:Pause;
-- ausserhalb einer Aufgabe ohne Wirkung, an einer C-Grenze zählt der Takt "Abgabe nicht möglich" statt abzubrechen)
local sizeN = 0
local function SizeOf(v, depth)
    depth = depth or 0
    if type(v) == "string" then return #v + 4 end
    if type(v) ~= "table" or depth > 8 then return 8 end
    local n = 4
    for k, x in pairs(v) do
        n = n + (type(k) == "string" and #k + 6 or 12) + SizeOf(x, depth + 1)
        sizeN = sizeN + 1
        if sizeN >= 2000 then sizeN = 0; A:Pause() end
    end
    return n
end
Ln.SizeOf = SizeOf

function Ln:Report()
    local out, fields = { "Lern-Datenbank (echte Daten):" }, {}
    out[#out + 1] = "  Lernen " .. (self:On() and "an" or "AUS (Option)") .. " · Ausprobieren " .. (self:ExploreOn() and "an" or "aus")
    local F = Fc()
    local ok, R = false, nil
    if F then ok, R = pcall(F.Eval, F) end
    if ok and R then
        local rows = {}
        for _, g in ipairs(F.GROUPS) do
            local x = R.P[g]
            if x and x.n > 0 then
                local cells = {}
                for c = 1, 5 do
                    local cell = x.rel and x.rel[c .. ":24"]
                    if cell and cell[1] > 0 then cells[#cells + 1] = string.format("%s %d/%d", ({ "≤0,90", "0,90–0,97", "0,97–1,03", "1,03–1,10", ">1,10" })[c], math.floor(cell[2] + 0.5), cell[1]) end
                end
                rows[#rows + 1] = string.format("%s %d Fälle%s", F.GROUP_NAMES[g], x.n, #cells > 0 and (" [24 Std.: " .. table.concat(cells, ", ") .. "]") or "")
            end
        end
        out[#out + 1] = "  Fälle je Gruppe und Preislage: " .. (#rows > 0 and table.concat(rows, " | ") or "noch keine")
        fields.lernen_faelle = (#rows > 0 and table.concat(rows, " | ") or "-"):sub(1, 400)
    end
    local db = self:Data() or {}
    local corr = {}
    for g, c in pairs(db.corr or {}) do corr[#corr + 1] = string.format("%s Dauer %.2f Chance %.2f (N %d)", g, c.d or 1, c.p or 1, c.n or 0) end
    table.sort(corr)
    out[#out + 1] = "  Selbstkorrektur (alt 1,00 -> neu): " .. (#corr > 0 and table.concat(corr, " · ") or "noch keine (ab 10 Fällen je Gruppe)")
    fields.lernen_korrektur = (#corr > 0 and table.concat(corr, " | ") or "-"):sub(1, 300)
    -- NP-AHS318-1: Absatz-Faktor - wie oft vorgerechnet (Aufgabe), am Stück gerechnet, Zahlen der letzten Rechnung genommen
    fields.lernen_faktor = string.format("vorgerechnet %d · am Stück %d · letzte Rechnung genommen %d", self.factorWarm or 0, self.factorSync or 0, self.factorStale or 0)
    local facs = {}
    if F then
        for _, g in ipairs(F.GROUPS) do
            local f, n = self:MarketFactor(g)
            if f then facs[#facs + 1] = string.format("%s %.2f (%d Items)", F.GROUP_NAMES[g], f, n or 0) end
        end
    end
    out[#out + 1] = string.format("  Markt-Absatz: alt \"halb verkauft\" + Deckel %d %% · gelernter Faktor je Gruppe: %s", math.floor(A.SELL_CAP * 100 + 0.5),
        #facs > 0 and table.concat(facs, ", ") or "noch keiner (ab 5 Items mit Vollscan-Messung)")
    -- Preisgrenzen der 10 meistgehandelten Items
    local cnt = {}
    for _, e in ipairs(self:LedgerEntries()) do if e.itemID then cnt[e.itemID] = (cnt[e.itemID] or 0) + 1 end end
    local top = {}
    for id, n in pairs(cnt) do top[#top + 1] = { id, n } end
    table.sort(top, function(x, y) return x[2] > y[2] end)
    local lim = {}
    for i = 1, math.min(10, #top) do
        local okL, mn, nr, mx = pcall(self.Limits, self, top[i][1])
        if okL and nr then lim[#lim + 1] = string.format("%d: Min %s · Normal %s · Max %s", top[i][1], mn and A:FormatMoney(mn) or "-", A:FormatMoney(nr), A:FormatMoney(mx)) end
    end
    out[#out + 1] = "  Preisgrenzen (10 meistgehandelte): " .. (#lim > 0 and table.concat(lim, " | ") or "noch keine (ab 10 Fällen)")
    fields.lernen_grenzen = (#lim > 0 and table.concat(lim, " | ") or "-"):sub(1, 400)
    local bud = {}
    -- TB138-5: Entzaubern nach DE30b (Mindestgewinn je Gruppe 20/25/30 %, Obergrenze 0,9 × Wert, kein Budget) -
    -- die gelernte Marge wirkt dort nur als Sicherheitsmarge (MK:LimitFromNet, die strengere Grenze gewinnt)
    do
        local m, n = self:Margin("d")
        local okR, rel = pcall(A.DETableReliable, A)
        bud[#bud + 1] = string.format("Entzaubern DE30b: Mindestgewinn je Gruppe %d/%d/%d %% (gut gemessen/ungemessen%s/schlecht), höchstens %d %% vom Wert, Sicherheitsmarge %d %% (N %d), kein Budget",
            A.DE_GAIN_PROVEN or 20, A.DE_GAIN_UNPROVEN or 25, A.DE_GAIN_BAD or 30, (okR and rel) and " – Tabelle verlässlich: 20" or "",
            math.floor(((A.Core and A.Core.DE_MAX_SHARE) or 0.9) * 100 + 0.5), math.floor(m * 100 + 0.5), n or 0)
    end
    for _, w in ipairs({ "e", "v" }) do
        local m, n = self:Margin(w)
        local left, limit = self:BudgetLeft(w)
        bud[#bud + 1] = string.format("%s Marge %d %% (N %d), Budget %s", ({ e = "Flip", v = "Händler" })[w], math.floor(m * 100 + 0.5), n or 0,
            left and (A:FormatMoney(left) .. " von " .. A:FormatMoney(limit)) or "frei")
    end
    out[#out + 1] = "  Kauf-Sicherheit: " .. table.concat(bud, " · ")
    fields.lernen_kauf = table.concat(bud, " | "):sub(1, 300)
    local shared = 0
    for _ in pairs(db.shared or {}) do shared = shared + 1 end
    local rhythm = 0
    for _ in pairs(db.rhythm or {}) do rhythm = rhythm + 1 end
    local size = SizeOf(db)
    out[#out + 1] = string.format("  Geteilt von %d Spielern · Rhythmus für %d Items · Speicher %d KB (Ziel < 1024 KB)", shared, rhythm, math.ceil(size / 1024))
    fields.lernen_speicher_kb = tostring(math.ceil(size / 1024))
    return out, fields
end
