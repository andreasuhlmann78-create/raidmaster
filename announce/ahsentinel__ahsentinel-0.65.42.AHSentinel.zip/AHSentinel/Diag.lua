if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Diagnose-Protokoll (ab 0.65.15, Vorbild: LevelPilot / shared/vorlage/Diag.lua)
--
-- Fehler, die nur im echten Spiel auftreten (langsame Klicks, Neuaufbauten, verdeckte Fenster, Fehlerschleifen),
-- schreibt das Addon selbst mit:
--   /ahs protokoll   -> Fenster mit markierbarem Text
--   beim Ausloggen / /reload -> "GSDIAG1"-Zeichenkette in AHSentinelDB.diagExport; der RaidMasterUploader schickt sie
--                               wie GSTEST1 nach Discord #testberichte -> GitHub
-- Einträge: EINSTELLEN (Gebühr beim Einstellen, Seller.lua), KLICK (Rezept, Rezept-ID, Weg, ms, Erfolg), AUFBAU (Liste, Auslöser, ms), LANGSAM (Schritt > 16 ms),
--           ÜBERLAPPT (fremder Rahmen über dem eigenen Fenster), FEHLER (gleicher Text nur gezählt)
-- Regeln: KEINE Spieler-, Charakter-, Gilden- oder Realmnamen (das Protokoll landet im öffentlichen Repo).
--         Während der Testroutine schreibt das Protokoll nur in die Sandbox (wird danach wiederhergestellt).
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local D = {}
A.Diag = D

D.MAX = 200            -- höchstens so viele Einträge, älteste fallen weg
D.SLOW_MS = 16         -- ein Frame bei 60 fps
D.PREFIX = "GSDIAG1"
D.EXPORT_MAX = 60000   -- Zeichen in der SavedVariables-Zeichenkette

local function Stamp() return date and date("%d.%m. %H:%M:%S") or "" end
local function Clean(s)
    s = tostring(s or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", ""):gsub("[\r\n|]", " ")
    return s
end

local function Store()
    local db = A.db
    if not db then return nil end
    -- während der Testroutine nur in eine Sandbox-Tabelle schreiben (absichtliche Testfehler nicht ins echte Protokoll)
    local TR = A.TestRoutine
    if TR and TR.running then
        if not D.sandbox or D.sandbox.run ~= TR.T then D.sandbox = { run = TR.T, entries = {}, sessions = {} } end
        return D.sandbox
    end
    if type(db.diag) ~= "table" then db.diag = { entries = {}, sessions = {} } end
    db.diag.entries = db.diag.entries or {}
    db.diag.sessions = db.diag.sessions or {}
    return db.diag
end
D.Store = Store

-- Eintrag schreiben. Gleiche Art + gleicher Text direkt hintereinander -> nur Zähler (keine Schleifen im Protokoll).
function D:Add(kind, text, ms)
    local d = Store()
    if not d then return nil end
    local G = _G.GoldSentinelGame
    if G and G.IsSecret and (G.IsSecret(text) or G.IsSecret(ms)) then return nil end   -- geschützte Werte nie verarbeiten
    kind, text = Clean(kind):upper(), Clean(text)
    if A.Spieltest and A.Spieltest.activeUntil then pcall(A.Spieltest.OnDiag, A.Spieltest, kind, ms) end
    local e = d.entries[1]
    if e and e.k == kind and e.t == text then
        e.n = (e.n or 1) + 1
        e.z = Stamp()
        if ms then e.ms = math.max(e.ms or 0, math.floor(ms + 0.5)) end
        return e
    end
    e = { k = kind, t = text, z = Stamp(), n = 1, ms = ms and math.floor(ms + 0.5) or nil, v = A.version }
    table.insert(d.entries, 1, e)
    for i = #d.entries, self.MAX + 1, -1 do d.entries[i] = nil end
    return e
end

-- Fehler: gleicher Ort + Text wird nur gezählt, auch wenn andere Einträge dazwischen liegen
function D:Error(where, msg)
    local d = Store()
    if not d then return end
    local text = Clean(where) .. ": " .. Clean(msg):sub(1, 160)
    for _, e in ipairs(d.entries) do
        if e.k == "FEHLER" and e.t == text then e.n = (e.n or 1) + 1; e.z = Stamp(); return e end
    end
    self.errorCount = (self.errorCount or 0) + 1
    return self:Add("FEHLER", text)
end

-- fn messen: langsamer als ein Frame -> LANGSAM
function D:Timed(name, fn, ...)
    local t0 = debugprofilestop and debugprofilestop() or 0
    local res = { pcall(fn, ...) }
    local ms = (debugprofilestop and debugprofilestop() or 0) - t0
    if ms > self.SLOW_MS then self:Add("LANGSAM", name, ms) end
    if not res[1] then error(res[2], 0) end
    return unpack(res, 2)
end

-- Sitzung beim Einloggen (nur Stufe, Klasse und Version, kein Name)
function D:Session()
    local d = Store()
    if not d then return end
    local lvl = UnitLevel and UnitLevel("player") or 0
    local _, class = UnitClass and UnitClass("player")
    table.insert(d.sessions, 1, { z = Stamp(), lvl = lvl, class = class or "?", v = A.version })
    for i = #d.sessions, 21, -1 do d.sessions[i] = nil end
end

-- Einstellungen, die vom Standard abweichen (nur Schlüssel und Wert, keine Namen)
function D:ChangedSettings()
    local out = {}
    local def = A.DEFAULTS and A.DEFAULTS.settings
    local cur = A.db and A.db.settings
    if not (def and cur) then return out end
    for k, v in pairs(cur) do
        local safe = type(v) == "number" or type(v) == "boolean"
            or (type(v) == "string" and ({ theme = 1, moneyStyle = 1, nameLocale = 1, uiLanguage = 1, undercut = 1 })[k])
        if safe and def[k] ~= v and k ~= "nameLocaleChosen" and k ~= "detachedWindow" then
            out[#out + 1] = k .. "=" .. tostring(v)
        end
    end
    table.sort(out)
    return out
end

local function Shown(f) return f and f.IsShown and f:IsShown() or false end

function D:Extra()
    local out = {}
    local db = A.db or {}
    out[#out + 1] = string.format("Preisquelle: Markt-Scan vor %s, %d Items, Preis-Sync %s", A.FormatAgo and A:FormatAgo(db.lastScanTime) or "?",
        A.CountTable and A:CountTable(db.marketData) or 0, (A.Sync and A.Sync.IsEnabled and A.Sync:IsEnabled()) and "an" or "aus")
    local Cr = A.Crafting
    local panel = Cr and Cr.GetDockFrame and Cr:GetDockFrame(true)
    out[#out + 1] = string.format("Fenster offen: Hauptfenster %s, Auktionshaus %s, Gewinn-Fenster %s, Berufsfenster %s",
        tostring(A.UI and A.UI.IsVisible and A.UI:IsVisible() or false), tostring(A.IsAHOpen and A:IsAHOpen() or false),
        tostring(Shown(panel)), tostring(Cr and Cr.kind or "zu"))
    if panel then
        local p, rel = panel:GetPoint(1)
        local relName = rel and rel.GetName and rel:GetName() or (rel and "ohne Namen") or "-"
        out[#out + 1] = string.format("Gewinn-Fenster angedockt an %s (Versatz %s)", tostring(relName), tostring(Cr.dockOffset))
    end
    local ch = self:ChangedSettings()
    out[#out + 1] = "Einstellungen geändert: " .. (#ch > 0 and table.concat(ch, ", ") or "keine")
    out[#out + 1] = string.format("Sprache: Client %s, Addon %s", tostring(GetLocale and GetLocale()), tostring(A.uiLang))
    out[#out + 1] = string.format("Fehler in dieser Sitzung: %d", self.errorCount or 0)
    return out
end

-- Das Protokoll als Text
function D:Text()
    local d = Store() or { entries = {}, sessions = {} }
    local G = _G.GoldSentinelGame
    local out = {}
    local function add(s) out[#out + 1] = s end
    add(string.format("AHSentinel-Protokoll v%s · %s", tostring(A.version), Stamp()))
    add(string.format("Client %s · Interface %s · %s", tostring(GetLocale and GetLocale()),
        tostring(GetBuildInfo and select(4, GetBuildInfo())), G and G.Status and Clean(G.Status()) or "?"))
    add(string.format("Sitzungen: %d", #d.sessions))
    for i = 1, math.min(#d.sessions, 10) do
        local s = d.sessions[i]
        add(string.format("  %s L%s %s v%s", s.z or "", tostring(s.lvl), tostring(s.class), tostring(s.v)))
    end
    add("")
    add("== Diagnose")
    local ok, extra = pcall(self.Extra, self)
    if ok then for _, line in ipairs(extra) do add("  " .. Clean(line)) end end
    add("")
    add(string.format("== Einträge (%d, neueste zuerst)", #d.entries))
    for _, e in ipairs(d.entries) do
        add(string.format("[%s] %s%s %s%s", e.z or "", e.k or "?", (e.n or 1) > 1 and (" ×" .. e.n) or "",
            e.t or "", e.ms and (" · " .. e.ms .. " ms") or ""))
    end
    return table.concat(out, "\n")
end

-- Zeichenkette für den Uploader (wie GSTEST1): Präfix, Addon, Version, dann der Text
function D:Export()
    local text = self:Text()
    if #text > self.EXPORT_MAX then text = text:sub(1, self.EXPORT_MAX) end
    return self.PREFIX .. "|AHSentinel|" .. tostring(A.version) .. "|" .. text
end

function D:Show()
    -- Der Protokolltext selbst bleibt deutsch (er geht an die Addon-Prüfung); der Hinweis steht in der Spielsprache
    local text = L["Diagnose für die Addon-Prüfung (der Text ist auf Deutsch)."] .. "\n\n" .. self:Text()
    if A.UI and A.UI.ShowTextWindow then A.UI:ShowTextWindow(L["AHSentinel-Protokoll (Strg+A, Strg+C zum Kopieren)"], text)
    else A:Print(text) end
end

-- ------------------------------------------------------------
-- Quellen
-- ------------------------------------------------------------
-- FEHLER: alles, was das Addon selbst meldet (GoldSentinelTest), zusätzlich ins Protokoll
local realReport = A.ReportError
function A:ReportError(where, msg)
    pcall(D.Error, D, where, msg)
    return realReport(self, where, msg)
end

-- KLICK: Rezept im Gewinn-Fenster angeklickt (Crafting.lua feuert CRAFT_RECIPE_CLICK)
A:On("CRAFT_RECIPE_CLICK", function(c)
    if type(c) ~= "table" then return end
    D:Add("KLICK", string.format("Rezept %s · Rezept-ID %s · Weg %s · %s", tostring(c.name), tostring(c.recipeID or "-"),
        tostring(c.way or "-"), c.ok and "gewählt" or "NICHT gewählt"), c.ms or 0)
end)

-- AUFBAU: Liste "Beste Rezepte" neu gerechnet (Crafting.lua feuert CRAFT_TOP_BUILT)
A:On("CRAFT_TOP_BUILT", function(reason, ms, n)
    -- ms = Zeit vom Start bis zum Ende (über mehrere Frames verteilt); einzelne Frames > 16 ms meldet der Job-Takt als LANGSAM
    D:Add("AUFBAU", string.format("Beste Rezepte (%s Rezepte) · Auslöser %s", tostring(n or "?"), tostring(reason or "-")), ms)
end)

-- ÜBERLAPPT: liegt ein fremder Rahmen mit Maus über dem Gewinn-Fenster? (kurz nach dem Öffnen geprüft)
function D:CheckOverlap(frame, label)
    if not (frame and frame:IsShown() and UIParent and UIParent.GetChildren) then return 0 end
    local l, b, w, h = frame:GetRect()
    if not (l and w) then return 0 end
    local s = frame:GetEffectiveScale()
    l, b, w, h = l * s, b * s, w * s, h * s
    local mine = { [frame] = true }
    local found = 0
    for _, c in ipairs({ UIParent:GetChildren() }) do
        if not mine[c] and c:IsShown() and c.IsMouseEnabled and c:IsMouseEnabled() then
            local cl, cb, cw, ch = c:GetRect()
            if cl and cw then
                local cs = c:GetEffectiveScale()
                cl, cb, cw, ch = cl * cs, cb * cs, cw * cs, ch * cs
                local ox = math.min(l + w, cl + cw) - math.max(l, cl)
                local oy = math.min(b + h, cb + ch) - math.max(b, cb)
                local bigger = cw >= UIParent:GetWidth() * 0.9      -- Vollbild-Rahmen zählen nicht
                if ox > 4 and oy > 4 and not bigger then
                    local above = (c:GetFrameStrata() == frame:GetFrameStrata() and c:GetFrameLevel() > frame:GetFrameLevel())
                        or (c.GetFrameStrata and ({ BACKGROUND = 1, LOW = 2, MEDIUM = 3, HIGH = 4, DIALOG = 5, FULLSCREEN = 6,
                            FULLSCREEN_DIALOG = 7, TOOLTIP = 8 })[c:GetFrameStrata()] or 0) > (({ BACKGROUND = 1, LOW = 2, MEDIUM = 3,
                            HIGH = 4, DIALOG = 5, FULLSCREEN = 6, FULLSCREEN_DIALOG = 7, TOOLTIP = 8 })[frame:GetFrameStrata()] or 0)
                    if above then
                        found = found + 1
                        self:Add("ÜBERLAPPT", string.format("%s überdeckt von %s", label, tostring(c:GetName() or c:GetObjectType())))
                    end
                end
            end
        end
    end
    return found
end

-- Sitzung und Export
local f = CreateFrame("Frame")
D.frame = f
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("PLAYER_LOGOUT")
f:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        pcall(D.Session, D)
    elseif event == "PLAYER_LOGOUT" then
        if not A.db or (A.TestRoutine and A.TestRoutine.running) then return end
        local ok, s = pcall(D.Export, D)
        if ok then A.db.diagExport = s end
    end
end)
