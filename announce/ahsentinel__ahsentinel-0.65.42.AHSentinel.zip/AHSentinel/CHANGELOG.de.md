# AHSentinel (früher AH Analyzer Pro) – Änderungen (deutsch)

Diese Datei ist die deutsche Zusammenfassung für Discord. Die ausführliche englische Fassung steht in CHANGELOG.md.

## 0.65.42
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.42** – Gebühren wie im klassischen WoW 🪙

• **Gemessen in Forever:** Beim Einstellen zahlst du eine **Einzahlung** (Händlerpreis × Menge × 5 % je 2 Std., mind. 1s je Auktion). Beim Verkauf gehen **5 %** ab und die **Einzahlung kommt zurück**. Läuft eine Auktion ab, ist die Einzahlung weg – das rechnet AHSentinel jetzt ein.
• **Buchhaltung:** Forever-Rechnungen werden richtig gelesen (Stückpreis, Menge). Alte Verkäufe werden **einmal neu berechnet** – nichts wird gelöscht.
• **Tooltip:** beide Wege mit Betrag, der bessere zuerst: „Entzaubern: 9s 35c“ / „Verkaufen: 8s 99c“.
• **Kein Ruckeln mehr** beim Herstellen („Beste Rezepte“ rechnet seltener und verteilt).

## 0.65.41
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.41** – sehen, ob es sich lohnt 🟢🔴

• **Tooltip:** statt Rechnung ein **farbiges Urteil**: grün „Entzaubern lohnt sich +2s 85c“, rot „Entzaubern lohnt nicht −65c“ oder grau „unsicher“ – darunter **„Lohnt bis 7s 79c“**. Materialien und Rechnung nur mit **Shift**.
• **Gewinn-Fenster:** Materialien über den **günstigsten Weg** (AH, Händler oder selbst herstellen, z. B. Leinenstoffballen aus Leinenstoff). Die Einkaufsliste kauft genau diese Zutaten.
• **Gewinn über den besten Weg:** Verkaufen oder Entzaubern – darunter „bester Weg: …“ und der andere Weg mit Betrag. „Beste Rezepte“ sortiert danach.

## 0.65.40
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.40** – Buchhaltung repariert 🧾

• Verkäufe von **vor 0.65.35** hatten in Forever die Gebühr doppelt abgezogen (z. B. negative Einnahmen „Heute“). Sie werden beim Einloggen **einmal korrigiert** – nichts wird gelöscht. Im Chat: „Buchhaltung: N alte Verkäufe korrigiert“.

## 0.65.39
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.39** – Feinschliff 🧹

• **Kategorien mit drei Ebenen** wie im Blizzard-AH (z. B. Waffen → Einhändig → Äxte).
• **Post an Twinks:** Kategorie per **Menü** wählen statt durch über 50 Einträge zu klicken.
• **Verkaufen:** Preis über dem 100-fachen Marktwert → Rückfrage (Tippfehler? Zahl ohne Zeichen = Gold).
• **Heute tun → unter Händlerpreis:** aus Scan/Suche wird mit **1 Stück** gerechnet – keine zu hohen Gewinne mehr.
• **Entzauber-Ergebnisse teilen:** grosse Statistiken kommen ganz an.
• **Spieltest** übersetzt; S7 zählt nur echtes Herstellen. Testroutine ersetzt keine Blizzard-Funktionen mehr.

## 0.65.38
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.38** – Werte, denen du trauen kannst 🎯

• **Nicht verkaufen kostet:** In Forever kostet jedes Einstellen die Gebühr. Der reale Wert zieht jetzt die erwarteten **Neu-Einstellungen** ab – aus deiner eigenen Verkaufsquote, sonst aus dem Absatz am Markt. Shift im Tooltip zeigt es.
• **Herstellen:** Eigene Materialien zählen mit dem, was du beim Verkauf bekämst; fehlende zum Sofortpreis, Händlerware zum Händlerpreis.
• **Vorhersage gegen Wirklichkeit:** Buchhaltung → Statistik zeigt **„Werte im Schnitt N % zu hoch/tief“** – je Item-Gruppe und gesamt.
• **Halbe Scans** gelten nie als vollständig, fehlende Items gelten nicht als weg.
• **Geteilte Preise** zählen nur, wenn sie zu deinen passen oder ein zweiter Mitspieler sie bestätigt.

## 0.65.37
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.37** – eigenes Entzauber-Fenster ✨

• **Kleines Entzauber-Fenster** (`/ahs entzaubern` oder Kaufen → „Entzaubern lohnt“ → „Entzauber-Fenster“): nächstes Teil mit Symbol, **„noch N“**, Knöpfe **Entzaubern / Überspringen / Statistik**.
• **Zuerst die gekauften Teile** aus dem Sammelkauf, dann die übrigen. Nach einem Sammelkauf öffnet es sich beim Schliessen des AH einmal von selbst.
• **Ein Klick = ein Teil** (sicherer Knopf, im Kampf gesperrt).
• **Schutz:** nie Set-Teile, Quest-Gegenstände oder Teile auf der Sperrliste (Rechtsklick aufs Symbol). Blaue/violette Teile und Teile, die sich deutlich besser verkaufen, erst nach **„Freigeben“**.
• **Statistik:** Entzauberungen heute/gesamt, Materialien und ihr Wert.
• **Buchhaltung → Entzaubern:** je Tag und gesamt: ausgegeben, Wert der Materialien (schon verkauftes zum echten Erlös), **Gewinn** und **Rendite %**. Eigene Teile getrennt, noch nicht entzauberte als „offen“.

## 0.65.36
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

📦 **AHSentinel 0.65.36** – Entzauber-Wächter 🔮

• Ist der **Schnäppchen-Wächter** an, sucht er bei offenem AH jede zweite Runde **Waffen und Rüstung**, die sich zum Entzaubern lohnen (gleiche Grenzen wie „Entzaubern lohnt“).
• Neue Funde meldet er einmal: **„N Teile mit über X % Rendite verfügbar“** – im Chat und auf dem Bildschirm, höchstens einmal pro Minute, nie im Kampf.
• Er **kauft nie selbst** – gekauft wird wie bisher unter Kaufen → „Entzaubern lohnt“. Abschalten mit dem Knopf **„Wächter-Meldung: AN/AUS“**.

## 0.65.35
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **AH-Gebühr im Gewinn-Fenster – eine sichtbare Annahme:** Die Gebühr hängt davon ab, wie viele Stück du je Auktion
  einstellst (mindestens 1s je Auktion). Das Fenster sagt es jetzt: "bei N Stück je Auktion (gelernt / selbst gewählt
  / vorsichtig)". Gelernt aus deinen eigenen Einstellungen (Median der letzten 10); ohne Daten 1 Stück. Klick darauf
  wechselt 1 / 5 / 20 (Stapel) / automatisch, gemerkt je Item. "Beste Rezepte", "Heute tun" und andere Addons rechnen
  mit derselben Annahme. Das Fenster springt nicht mehr zwischen zwei Rechnungen, wenn Item-Daten spät nachladen.
  (Beispiel: 1 Wollstoffballen zu 3s 97c, Material 3s 42c: Gebühr 1s, Verlust 45c; bei 20 je Auktion: 20c, +35c.)
- **Verkaufen: Menge = alles aus den Taschen** (nicht mehr die letzte Menge). Die Zahl änderst du selbst.
- **Buchhaltung (WoW Forever):** Ein Verkauf wird mit dem Gold gebucht, das die Post wirklich bringt – die Gebühr ist
  schon beim Einstellen gebucht, darum werden keine zweite Gebühr und keine Erstattung abgezogen. Die Werte der
  Rechnung gehen ins Diagnose-Protokoll (RECHNUNG). Abbrechen bucht jetzt die gemessene Erstattung. Era/TBC unverändert.
- Spieltest: neue Prüfung S10 – AH-Gebühr von AHSentinel = Blizzards "Einzahlen" bei gleicher Menge.

## 0.65.34
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Sammelkauf zum Entzaubern** (Reiter Kaufen → Einkauf): Der Knopf "Entzaubern lohnt" unter den Kategorien zeigt aus
  deiner Suche nur Teile (Rüstung/Waffen), deren Entzauberungswert den Preis um die Mindestrendite übersteigt, mit
  mindestens 10c Gewinn je Teil – nach Gewinn sortiert, mit Spalten Entzauberungswert, Gewinn und Rendite %.
  - Jede Mausrad-Raste über der Liste oder "Nächstes kaufen" kauft das nächste Teil von oben (die erste Raste lädt
    dessen Angebote). Vor jedem Kauf: Angebot noch da und nicht teurer – sonst übersprungen.
  - Grenzen: "höchstens X Gold" (Standard 5g) und "Rendite ab X %" (Standard 20 %). Stopp bei der Grenze, bei vollen
    Taschen oder im Kampf. Unter 10 echten Entzauberungen der Gruppe zählt der Wert 10 % weniger.
  - Statuszeile: "Gekauft N · bezahlt · erwartet +Gewinn". Nur auf deinen Klick/deine Raste, nie automatisch;
    Protokoll KAUF (ohne Namen). Kein Fertigkeits-Filter – in WoW Forever ist ab Verzauberkunst 1 alles entzauberbar.

## 0.65.33
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **AH-Gebühr im Gewinn-Fenster korrigiert:** Die Gebühr pro Stück ging davon aus, dass du immer einen vollen Stapel
  einstellst (z. B. 20 Wollstoffballen), und teilte die Mindestgebühr 1s durch 20 – so zeigte 1 Ballen zu 3s 98c 20c
  statt der echten 1s. Jetzt richtet sich die Gebühr danach, wie viele Stück du dieses Item zuletzt auf einmal
  eingestellt hast; ohne Erfahrung 1 Stück (volle Mindestgebühr 1s).

## 0.65.32
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauber-Tabelle aus Disenchantry:** Die Tabelle folgt jetzt Disenchantry 1.1.2 (MIT-Lizenz, Copyright (c) 2026
  x_Raven_x; Lizenztext in LICENSE-Disenchantry.txt), Grundlage warcraft.wiki.gg: Itemstufe 5–15 ohne Splitter (80/20),
  21–25 Rüstung 75/15/10, 51–65 Waffen 75/22/3, **WoW Forever: grüne Waffen Itemstufe 21–30 geben Grosse
  Magieessenz**, blaue Items ab Itemstufe 1 und bis 80, epische bis 88. Gruppen nach Itemstufe (wie in der Tabelle),
  nicht nach benötigter Stufe.
- Der Materialblock zeigt jetzt die Mengen aus der Tabelle ("1–2×"), aus echten Entzauberungen den Durchschnitt.
- **Disenchantry geladen:** AHSentinel zeigt keinen zweiten Materialblock.

## 0.65.31
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Ein Preis für alles:** AHSentinel bewertet jedes Item jetzt mit EINER Funktion – Tooltip, Gewinn-Fenster (Ergebnis
  und Materialien), Schnäppchen, Flips, "Heute tun", Entzaubern (Block und Wert), Inventarwert und der Vergleich mit dem
  Händler zeigen für dasselbe Item denselben Wert. Reihenfolge der Quellen: eigene Verkäufe der letzten 14 Tage, dann
  knapp unter dem günstigsten aktuellen Angebot (höchstens der Median), dann der Median 14 Tage. Angebote unter 10 % oder
  über 300 % des Medians zählen nicht. Bei Schnäppchen und Flips gilt das billige Angebot selbst nicht als Wiederverkaufswert.
- **Realer Wert im Tooltip:** neue Zeile "Realer Wert (nach Gebühren)" mit Quelle (eigener Verkauf / AH aktuell / Markt /
  Händler) und "Preis alt" nach 6 Stunden; mit Shift jeder Bestandteil (eigener Verkauf, günstigstes Angebot, Median, Gebühr).
- **Händlerpreis als Untergrenze:** Zahlt ein Händler mehr als das Auktionshaus nach Gebühren, gilt der Händlerpreis.
- Andere Addons (ProfessionSentinel) können dieselben Werte nutzen: `AHAnalyzerPro:RealPrice(itemID)` und
  `AHAnalyzerPro:RealValue(itemID, Menge)`; das alte `GetSalePrice` liefert jetzt denselben Wert.

## 0.65.30
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Preise je Server und Fraktion:** AHSentinel führt jetzt für jeden Server und jedes Auktionshaus eine eigene
  Preisliste – Horde, Allianz und die neutralen Auktionshäuser (Beutebucht, Gadgetzan, Ewige Warte). Eigene Scans und
  geteilte Preise landen nur in der Liste des Auktionshauses, an dem du stehst; Tooltips und Rechnungen nehmen die Liste
  deiner Fraktion (am neutralen Auktionshaus die neutrale).
- **Sync nur vom selben Auktionshaus:** Preis-Nachrichten tragen jetzt eine Kennung von Server und Fraktion; Preise
  einer anderen Fraktion oder eines anderen Servers und alte Nachrichten ohne Kennung werden verworfen. (Bitte
  aktualisieren – ältere Versionen tauschen mit 0.65.30 keine Preise mehr.)
- Deine bisherigen Preise bleiben für Server und Fraktion des aktuellen Charakters. Hast du Charaktere auf mehreren
  Servern oder Fraktionen, weist ein Hinweis darauf hin, dass die alten Preise gemischt sein können – der nächste Scan
  ersetzt sie.

## 0.65.29
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauberungswert statt "Gewinn":** Die Tooltip-Zeile heisst jetzt "Entzauberungswert ~X (T)" – er hängt nur von
  der Gruppe ab (Qualität, Itemstufe, Rüstung/Waffe) und ist für alle Items dieser Gruppe gleich. Neu darunter:
  "Gewinn beim Kauf: Wert − Kaufpreis" (grün/rot) mit dem Preis der Zeile, auf die du im Addon zeigst (Kaufliste,
  Sniper, Schnäppchen), beim Händler dessen Preis, sonst das günstigste aktuelle Angebot. In der Kaufliste steht
  "[Entzaubern lohnt]" nur, wenn Wert − Preis positiv ist.
- **Materialblock passt zum Wert:** Block und Wert rechnen jetzt mit demselben Preis je Material – eigene Verkäufe der
  letzten 14 Tage, sonst knapp unter dem günstigsten aktuellen Angebot (höchstens der Median), sonst der Median. Die
  Quelle steht dabei ("AH aktuell" / "Markt" / "eigener Verkauf"). Angebote unter 10 % oder über 300 % des Medians
  zählen nicht ("Angebot unsicher") – z. B. 22c für eine Grosse Mystikeressenz.
- **Entzauberungen teilen:** nach 10 neuen oder spätestens 2 Minuten nach der letzten, und beim Ausloggen.

## 0.65.28
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Öffnet mit dem Auktionshaus:** Das AHSentinel-Fenster öffnet sich, wenn du das Auktionshaus öffnest, und schliesst
  sich wieder mit ihm. War es vorher schon offen, bleibt es offen. Einstellung "Mit dem Auktionshaus öffnen und
  schliessen" (ab Werk an). Im Kampf drängt es sich nie auf.
- **Fenster immer im Bildschirm:** Das Hauptfenster bleibt ganz im Bildschirm – höchstens 90 % davon, Position an den
  Rand geklemmt, auch nach Änderung der UI-Skalierung oder Auflösung.
- **Sniper in WoW Forever:** Waren kaufst du mit zwei Rasten – 1. Raste reserviert den Preis, 2. Raste kauft (WoW
  Forever erlaubt die Reservierung nur mit Tastendruck). Die Statuszeile sagt das jetzt ("1. …: Preis reservieren ·
  2. …: kaufen", danach "Reserviert – nochmal … zum Kaufen (10 s)"), auch während der Sniper weitersucht; Hilfe und
  Tooltips angepasst. Die Gesamtzeile unter der Liste verschwindet beim Weitersuchen nicht mehr. Era/TBC unverändert.
- Spieltest: neue Prüfung S9 (Fenster öffnet und schliesst mit dem Auktionshaus).
- Testroutine (Entwickler): Prüfungen, die in diesem Client nicht gehen (kein BugSack, fehlende Item-Daten, kein echtes
  Layout), zählen als übersprungen, nie als OK oder FEHLER.

## 0.65.27
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzauber-Tabelle korrigiert** (Quelle: warcraft.wiki.gg, Classic-Entzaubertabellen): grüne Items bis Itemstufe
  15 geben keinen Splitter – Rüstung 80 % Staub / 20 % Essenz, Waffen 20 % / 80 %. Itemstufe 21–25 jetzt 75/15/10
  (Waffen 15/75/10), Itemstufe 51–65 Waffen 22/75/3; die übrigen Stufen bleiben 75/20/5.
- Materialien, die aus einer Gruppe nicht kommen können (z. B. ein Splitter aus Itemstufe 15), zählen nicht mehr mit –
  weder eigene (falsch erkannte) noch geteilte Ergebnisse.

## 0.65.26
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzaubern im Tooltip, kürzer:**
  - Eine Zeile "Entzaubern: erwarteter Gewinn ~X" (Wert nach Gebühren) mit kleinem Vergleich ("lohnt mehr als
    Verkauf" / "Verkauf bringt mehr") und der Quelle: "(Ø 12)" = aus 12 echten Entzauberungen (ab 10), "(T)" = Tabelle.
  - Darunter ein Block "Entzaubern – Materialien (AHSentinel)": Icon, Name, Dropchance und Wert pro Stück
    (AH-Preis aus dem letzten Scan, sonst Marktwert).
  - Mit gedrückter Shift-Taste erscheint die ganze Rechnung (tatsächlich und geschätzt, je Material, nach Gebühren).
  - Einstellung "Entzauber-Details im Tooltip": kurz / mit Materialien (Standard) / alles.
- **Entzauber-Ergebnisse mit allen AHSentinel-Nutzern teilen:** Jedes Entzaubern auf jedem Charakter wird
  automatisch gezählt (Twinks zählen als eigene) und über den öffentlichen Sync-Kanal geteilt ("nur Gilde" bleibt als
  Einstellung). Schutz: höchstens 6 Nachrichten je Absender und Minute, Materialien müssen zur Gruppe passen, 1–5
  Stück je Entzauberung, keine Sprünge, doppelte Meldungen zählen einmal. Absender werden nur als Kürzel gespeichert,
  nie mit Namen.

## 0.65.25
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Post abholen:** "Post abgeholt" zeigt jetzt das wirklich abgeholte Gold (z. B. 1g 56s 26c) statt 0. Das Spiel
  schreibt das Gold oft erst nach der Briefkasten-Aktualisierung gut; das Addon zählt jetzt den Betrag jeder abgeholten
  Post mit.
- "1 neue Rechnungen" → "1 neue Rechnung".

## 0.65.24
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Spieltest S5** prüft jetzt nur noch, was er soll: das Gewinn-Fenster gegen das Berufsfenster und ProfessionSentinel.
  Vorher zählte er auch das Hauptfenster über dem Auktionshaus, LevelPilot und unsichtbare Anker anderer Addons mit
  und meldete fälschlich FEHLER.

## 0.65.23
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Spieltest:** `/ahs spieltest an` – AHSentinel prüft die Test-Checkliste im Spiel selbst, sobald du die Lage
  herstellst, und meldet nur, was nicht stimmt (eine Chat-Zeile je Prüfung). Er öffnet nie selbst Fenster, kauft,
  stellt ein oder stellt her und tut im Kampf nichts. Aktiv bis /reload oder 2 Stunden.
  - S1 Gebühr im Verkaufen-Reiter · S2 echte Gebühr nach dem Einstellen · S3 Gewinn-Fenster · S4 Entzaubern im
    Tooltip · S5 Gewinn-Fenster überdeckt nichts · S6 Händler-Knopf · S7 Neuaufbau beim Herstellen von 5 Gegenständen
    · S8 keine blockierten Aufrufe.
  - `/ahs spieltest bericht` zeigt OK / FEHLER / offen und was für die offenen noch zu tun ist. Die Ergebnisse gehen
    auch ins Diagnose-Protokoll und in den Testbericht für die Addon-Prüfung (Bereich S). Keine Namen.
- Übrig gebliebene Datei (TestRoutine.lua.orig) aus dem Download entfernt.

## 0.65.22
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Entzaubern im Tooltip – tatsächlich und geschätzt, klar getrennt:**
  - "Entzaubern tatsächlich (Ø aus N)": nur aus echten Entzauberungen dieser Gruppe (eigene + geteilte): Summe der
    wirklich erhaltenen Materialien × aktueller AH-Preis aus dem letzten Scan ÷ N. Unter 10 Entzauberungen steht
    "(wenig Daten)" dabei, ohne Entzauberung fehlt die Zeile.
  - "Entzaubern geschätzt (Tabelle)": der bisherige Wert (Tabelle verrechnet mit den Ergebnissen).
  - Je Material eine Zeile: Chance (bzw. tatsächliche Häufigkeit "x/N") × Ø-Menge · AH-Preis aus dem letzten Scan (mit
    Alter) · Marktwert = Anteil; darunter "nach Gebühren" (WoW Forever: AH-Gebühr 5 %, mind. 1s pro Auktion).
  - Der Tooltip sagt, mit welchem Wert die Entzauber-Schnäppchen rechnen: ab 10 Entzauberungen mit dem tatsächlichen
    Ø, sonst mit der Schätzung.
  - Neue Einstellung "Entzaubern: je Material" (Standard an).

## 0.65.21
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Gebührenregel WoW Forever:** In Forever gibt es nur EINE Gebühr – die AH-Gebühr = 5 % vom Preis der Auktion,
  mindestens 1 Silber, pro Auktion (pro Stapel), bezahlt beim Einstellen. Eine separate Einstellgebühr gibt es nicht
  mehr. Beispiele: 3s 90c → 1s, 2s → 1s, 1g → 5s, Stapel 20 zu je 1c → einmal 1s.
- Die Zeile "Einstellgebühr (nicht erstattet)" fällt im Gewinn-Fenster und beim Verkaufen weg; es gibt nur noch
  "AH-Gebühr (5 %, mind. 1s)". Überall gleich gerechnet: Gewinn-Fenster, Verkaufen, "Heute tun", Schnäppchen,
  Flips, Entzauber-Werte, Händler-Vergleich, Gewinnrechner.
- Beim Einstellen kommt die wirklich abgezogene Gebühr ins Diagnose-Protokoll (Eintrag EINSTELLEN: Preis, Menge,
  Gebühr), um die Regel im Spiel zu bestätigen. Die Messung der Einstellgebühr aus 0.65.17–0.65.20 ist entfernt. Die
  Warnung, wenn die Gebühr mehr als 10 % vom Preis ausmacht, bleibt.
- Era, TBC und Retail unverändert (5 % beim Verkauf, Einstellgebühr kommt beim Verkauf zurück).

## 0.65.20
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Berufsfenster:** Die Liste „Beste Rezepte“ baut sich beim Herstellen höchstens alle 2 Sekunden neu auf (bisher bis
  zu 190-mal pro Sitzung); Öffnen und Berufswechsel bleiben sofort.
- **Sniper (WoW Forever):** Der Sniper reserviert Waren nicht mehr selbst ohne Tastendruck. WoW Forever hat das
  geblockt (einmal pro Sitzung „Aktion blockiert“). Waren kaufst du mit 2 Rasten: die 1. reserviert, die 2. kauft.
  Blockt WoW das in einem anderen Client, merkt sich das Addon das für diesen Client, auch nach /reload.
- **Post an Twinks:** Eine Regel mit Unterkategorie greift jetzt auch nach /reload am Briefkasten, ohne vorher im
  Auktionshaus gewesen zu sein. Regeln aus 0.65.11–0.65.17 werden wiedergefunden.
- **Einkauf:** Die Kategorie-Liste behält beim Tippen und Suchen ihre Scroll-Position, die gewählte Kategorie bleibt
  sichtbar. Bis das Auktionshaus einmal offen war, zeigen Classic Era, TBC und WoW Forever die klassische Reihenfolge
  (mit Projektil, Köcher, Reagenz).
- **Verkaufs-Meldung:** geht auch, wenn der Spieltext einen nummerierten Platzhalter hat („%1$s“).
- **Berufsfenster:** Ohne Reiterleiste dockt das Gewinn-Fenster direkt neben dem Fenster an (beim alten Fenster nur
  über dessen unsichtbaren Rand), nie über Sichtbarem. Ein Klick auf ein Rezept schaltet „Ungelernte zeigen“ nicht
  mehr ein. In Classic Era und TBC keine Leerzeile mehr, wo in WoW Forever die Einstellgebühr steht.
- **Einstellgebühr:** Die Warnung sagt, wenn die Gebühr beim Verkauf erstattet wird (Classic Era, TBC …). Im Testmodus
  wird nichts gemessen, eine Schätzung des alten Auktionshauses zählt nie als Messung, das Gold wird kurz nach dem
  Einstellen noch einmal geprüft, und die letzten 300 Messungen stehen im Diagnose-Protokoll (nur Zahlen, keine Namen).
  „Heute tun – Herstellen“ zieht die Gebühr für die ganze hergestellte Menge ab.
- Tooltip des Preisfelds zeigt in jeder Sprache g/s/c.
- Testroutine (nur für den Entwickler): neuer Bereich K (Oberfläche im echten Client: Tooltips, überlappende Fenster,
  Bildschirm, Beschriftungen, plausible Werte, Fehlerschleifen, T191–T197) und Tests T198–T202; gemerkte Rezepte,
  Fensterpositionen und Wächter-Daten bleiben während der Routine unverändert.

## 0.65.18
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Händler-Knopf verdeckt nichts mehr:** Der Knopf „Verkaufen: … Items“ sass unter dem Händlerfenster und verdeckte
  den Reiter „Rückkauf“. Er sitzt jetzt oben rechts über dem Händlerfenster, nie bei den Reitern „Händler“ / „Rückkauf“.
- **Nur wenn es etwas zu verkaufen gibt:** Statt „Verkaufen: 0 Items (0)“ ist der Knopf dann ganz weg.
- **Ab Werk aus mit LevelPilot:** Ist LevelPilot geladen und verkauft dort graue Items selbst (Option ab Werk an), bleibt
  der Knopf aus, bis du ihn in den Einstellungen („Knopf beim Händler“) selbst einschaltest. Deine Einstellung gewinnt immer.
- Testroutine (nur für den Entwickler): T186 prüft im Spiel, dass der Knopf keinen Reiter des Händlerfensters verdeckt
  (sonst FEHLER), T187 die Werkseinstellung mit und ohne LevelPilot.

## 0.65.17
> ⚠️ **Dies ist eine Beta-Version.** Fehler bitte in den Kommentaren auf CurseForge melden,
> am besten mit der Lua-Fehlermeldung und der WoW-Version, auf der du spielst.

- **Einstellgebühr wird gemessen:** Bei jedem Einstellen schreibt das Addon Item, Händlerpreis, Menge, Laufzeit, deinen
  Preis (pro Stück und gesamt), die Gebühr laut Spiel und die wirklich abgezogene Gebühr mit, dazu die Verhältnisse
  Gebühr/Preis und Gebühr/Händlerpreis – im Diagnose-Protokoll (`/ahs protokoll`, Eintrag EINSTELLEN) und im
  GSDIAG1-Export, ohne Namen. Nennt das Spiel keine Gebühr, gilt die zuletzt gemessene für dieses Item – nie geschätzt.
- **Warnung Einstellgebühr:** Macht die Gebühr mehr als 10 % vom Preis aus, ist zum Einstellen ein zweiter Klick nötig.
  Die Schwelle ist in den Einstellungen wählbar (aus / 5 / 10 / 20 / 30 %).
- **"Heute tun": unter Händlerpreis:** Angebote, deren Stückpreis unter dem Händlerverkaufspreis liegt (aus dem letzten
  Scan oder deiner aktuellen Suche), stehen als "Unter Händlerpreis: kaufen und beim Händler verkaufen" – Gewinn =
  (Händlerpreis − Kaufpreis) × Menge, ohne AH-Anteil. Erst ab 10 Silber Gewinn je Angebot (einstellbar: alle / 5s /
  10s / 50s / 1g), die besten 10, nach Gewinn sortiert. Items ohne Händlerpreis erscheinen nie, verschwundene Angebote
  werden ausgeblendet. Der Knopf kauft nur auf deinen Klick und sagt dann: beim Händler verkaufen.

## 0.65.16

- **Geschützte Werte:** Rezept-Auswahl und Diagnose-Protokoll übergehen geschützte Werte des Spiels, statt sie anzufassen.
- Testroutine (nur für den Entwickler), nach den bei LevelPilot bewährten Regeln: ehrliche Zählung (was im Client nicht prüfbar ist, zählt als übersprungen, nie als OK; der Bericht nennt „nicht automatisiert: N“ und listet alles, was im Spiel zu prüfen ist), jeder Fehler aus dem Spiel ist ein eigener Testfall (Rezept-Klick ohne vorherigen Klick, die 50 Sekunden), Köderwerte für geschützte Werte, das Test-Protokoll landet in einer Sandbox, Testfall-IDs sind eindeutig.

## 0.65.15

- **Diagnose-Protokoll:** `/ahs protokoll` öffnet ein Fenster mit markierbarem Protokoll – Version, Client, Sitzungen, geänderte Einstellungen, offene Fenster und wo das Gewinn-Fenster angedockt ist, dazu Einträge (neueste zuerst): KLICK (Rezept, Rezept-ID, Weg, Millisekunden, Erfolg), AUFBAU (Liste „Beste Rezepte“, Auslöser, Dauer), LANGSAM (jeder Schritt über 16 ms), ÜBERLAPPT (fremdes Fenster über dem Gewinn-Fenster) und FEHLER (gleiche nur gezählt). Beim Ausloggen wird es zusätzlich als „GSDIAG1“ für die Addon-Prüfung gespeichert. Keine Spieler-, Charakter-, Gilden- oder Realmnamen.

## 0.65.14

- **Berufsfenster (moderner Client):** Ein Klick auf ein Rezept in „Beste Rezepte“ wählt es sofort über die Rezeptliste des Berufsfensters und scrollt es in die Ansicht – im selben Moment, ohne auf einen Timer zu warten. Nur wenn das nicht geht, nimmt das Addon OpenRecipe des Spiels, prüft jeden Frame und meldet im Chat, wenn das Rezept nach 0,5 Sekunden nicht angezeigt wird.

## 0.65.13

- **WoW Forever – Gewinn am Berufsfenster:** Die Einstellgebühr (mindestens 1 Silber pro Auktion, wird nie erstattet) wird jetzt abgezogen und als eigene Zeile gezeigt: Gewinn = Wert × 0,95 − Material − Einstellgebühr (z. B. Kupferne Kettenhose 18c statt 1s 18c – gleich wie ProfessionSentinel). Die Liste „Beste Rezepte“ ist danach sortiert.
- **WoW Forever – Gebots-Schnäppchen** ziehen die Einstellgebühr fürs Weiterverkaufen ebenfalls ab.
- Classic Era, TBC und die anderen Versionen bleiben unverändert (dort kommt die Gebühr beim Verkauf zurück).

## 0.65.12

- **Berufsfenster – Klick auf ein Rezept in „Beste Rezepte“ öffnet es jetzt immer:**
  - Die Liste baut sich nicht mehr bei jedem Spiel-Ereignis neu auf: Ereignisse werden gesammelt, neu aufgebaut wird höchstens alle 0,4 s, nur wenn sich etwas geändert hat, und verteilt über mehrere Frames – ein Klick geht während des Aufbaus nicht mehr verloren.
  - Jede Zeile merkt sich ihr Rezept; beim Klick wird es im Berufsfenster neu gesucht. Verstecken es Suchtext, Filter oder eine zugeklappte Kategorie, werden diese zurückgesetzt und das Rezept trotzdem geöffnet.
  - Klappt es trotzdem nicht, kommt eine kurze Meldung im Chat.

## 0.65.11

- **Einkauf → Kategorien wie im Blizzard-Auktionshaus:** Jede Hauptkategorie hat jetzt ihre Unterkategorien (Waffen → Einhandäxte …, Rüstung → Stoff/Leder …, Verbrauchbares → Tränke …), mit Namen und Reihenfolge aus dem Spiel. Die Unterkategorien klappen unter der gewählten Hauptkategorie auf. Bis das Auktionshaus einmal offen war, nimmt das Addon die Item-Klassen des Spiels.
- **Preisfeld:** zeigt Gold/Silber/Kupfer immer als g/s/c („78c“, „3s 90c“), in jeder Sprache – nie mehr „k“, das wie „tausend“ aussah. Eingaben wie „78“, „78c“, „1s 20c“, „1g“ und das alte „78k“ gehen weiter.
- Für ProfessionSentinel: `AHAnalyzerPro.Crafting:GetDockFrame(true)` liefert das Gewinn-Fenster auch, solange es verborgen ist.

## 0.65.10

- **Berufsfenster (WoW Forever):** Das AHSentinel-Gewinn-Fenster verdeckt die Berufsreiter rechts am Berufsfenster nicht mehr – es dockt jetzt rechts neben der Reiterleiste an. Ohne solche Reiterleiste sitzt es wie bisher.

## 0.65.9

- **Berufsfenster:** neue Schnittstelle `AHAnalyzerPro.Crafting:GetDockFrame()` – liefert das sichtbare AHSentinel-Gewinn-Fenster neben dem Berufsfenster, sonst nil. ProfessionSentinel dockt damit rechts daneben an, statt darüber zu liegen. AHSentinel selbst bleibt direkt rechts am Blizzard-Berufsfenster.

## 0.65.8

- **Beschädigte gespeicherte Daten werden beim Einloggen repariert:** Einzelne kaputte Einträge (Preisverlauf, Charaktere, Sniper-Ziele, Buchhaltung, Einkaufslisten, Rezepte) werden entfernt, statt in einem Reiter oder Tooltip einen Lua-Fehler auszulösen. Gesunde Daten bleiben unverändert.
- Testroutine (nur für den Entwickler): zwei Prüfungen, die immer fehlschlugen, sind behoben (Wächter bei geschlossenem Auktionshaus, `/ahs scan` während der Routine); Optionen und Chat-Befehle laufen jetzt einzeln (kein „script ran too long“); viele weitere Prüfungen (Wächter-Kandidaten, Verkaufs-Meldung, Buchhaltung aus dem Test-Briefkasten, Neu einstellen, Händler, Berufe, Entzaubern, Charaktere, Preis-Sync, Datenübernahme und kaputte Daten, Tempo, geschützte AH-Aufrufe) und mit offenem Auktionshaus simulierter Warenkauf, Sniper-Vorab-Reservierung, Serie einstellen, Unterbieten und Scan in Portionen. Was in einem Client nicht prüfbar ist, steht jetzt als „übersprungen“ mit Grund statt als OK im Bericht.

## 0.65.7
- **Testroutine (nur Entwickler):** viele weitere Prüfungen – jede Option einmal an und aus, jeder Chat-Befehl, alle
  Zusatzfenster, Hauptfenster und Designs, Größe und Position, Einkauf- und Buchhaltungs-Rechnung, Sniper-Ziele und
  -Tasten, Wächter-Einstellungen, Watchlist, Taschen ohne alte Funktionen, Chat-Hilfen, Esc-Fenster im Kampf, Fehler
  in Hintergrund-Aufgaben, Übergang vom alten AH Analyzer Pro.
- Taschen, Postfach-Plätze und Preis-Teilen holen die Client-Funktionen jetzt über eine Stelle, damit die Testroutine
  fehlende Funktionen simulieren kann, ohne Blizzard-Funktionen anzufassen (kein Taint). Im normalen Spiel ändert sich
  nichts.
- Meldung "GoldSentinelTest.lua fehlt" ist jetzt übersetzt.

## 0.65.6

Korrekturen aus der Addon-Prüfung:
- **Scan-Start scheitert dauerhaft (WoW Forever, Retail):** Lehnt der Server den Scan-Start immer wieder ab, wird der Chat nicht mehr geflutet (vorher rund 240 Zeilen in 2 Minuten). Die Fehlermeldung kommt einmal, das Addon versucht es höchstens 3-mal neu (mindestens 2 Sekunden Abstand) und meldet dann einmal, dass der Scan nicht starten konnte. Der Wächter läuft sofort weiter.
- **Wächter:** Verwirft der Server Anfragen, während die kurze Pause eines Scan-Wunschs läuft, pausiert der Wächter jetzt wie gewollt die vollen 15 Minuten (vorher lief er nach 2 Minuten wieder). Bewusst keine Pause nur deshalb, weil ein Scan erlaubt ist: Sonst würde der Wächter bei Spielern, die nie scannen, dauerhaft ruhen.
- **Berufsfenster (moderner Client):** Das im Blizzard-Fenster gewählte Rezept wird jetzt wirklich erkannt (der Ereignisname war falsch) – der Zutaten-Knopf nimmt nie ein älteres Rezept.
- **Post an Twinks (WoW Forever):** Eine Regel nur mit dem eigenen Vornamen („Testa“ für „Testa Beispiel“) plant keine Post mehr an dich selbst.
- **WoW Forever, geschützte Werte:** Preis-Sync, Tooltip, Briefkasten-Fehlermeldungen, blockierte Aktionen und das Entzaubern-Lernen übergehen geschützte Werte („secret values“), statt einen Lua-Fehler zu riskieren.
- Vom Addon abgefangene Fehler werden jetzt auch für die Addon-Prüfung gezählt (GoldSentinelTest.lua); `/ahs debug` zeigt „Fehler seit Login · Berichte offen“. Die Chat-Meldungen bleiben wie bisher. Die Verkaufs-Meldung verschluckt Fehler nicht mehr still.
- Nur für den Entwickler: neue Testroutine `/ahs testroutine` (Bereiche a–j, `server`, `haendler`, `berufe`, `post`, `gildenbank`, `kampf`) mit gespeichertem Bericht. Deine echten Daten werden vorher gesichert und danach wiederhergestellt; Kaufen, Einstellen, Post, Händler und Preis-Sync sind nur simuliert. `/ahs test` und `/ahs test daten` sind Kurzformen.
- Fehlende Übersetzungen für das klassische Auktionshaus ergänzt.

## 0.65.5

Nachbesserungen aus der Addon-Prüfung:
- **Komplett-Scan hat Vorrang (WoW Forever, Retail):** Startest du den Scan, während der Server ausgelastet ist oder noch eine Wächter-Suche läuft, scheitert er nicht mehr – der Wächter pausiert, und der Scan startet von selbst, sobald der Server bereit ist (höchstens 2 Minuten). Ein abgelehnter Scan-Start wird genauso behandelt. Classic Era und TBC bleiben unverändert.
- **Berufsfenster:** In den alten Clients (Classic Era, TBC) werden Rezepte wieder höchstens alle 5 Sekunden gelesen, wie in 0.65.3. Im modernen Client kommt das gewählte Rezept direkt aus der Rezeptliste und wird beim Schließen vergessen – der Zutaten-Knopf nimmt nie ein altes Rezept.

## 0.65.4

Korrekturen aus der Addon-Prüfung:
- **Altes „AH Analyzer Pro“ (bis 0.61) noch installiert:** AHSentinel lädt nicht mehr daneben (beide nutzten dieselbe Tabelle – doppelte Ereignisse und Befehle, mögliche Lua-Fehler). Stattdessen kommt einmal im Chat die Bitte, den alten Ordner `AddOns\AHAnalyzerPro` zu löschen. Deine alten Daten werden vorher für AHSentinel gesichert. Der alte Ordner wird auch nicht mehr vor AHSentinel geladen.
- **Wächter (Classic Era, TBC):** wieder wie in 0.64.2 – keine Pause von bis zu 15 Minuten mehr, wenn der Server „kein Komplett-Scan“ meldet (das kann auch von einem anderen Addon kommen).
- **Wächter (WoW Forever, Retail):** Ist der Komplett-Scan fällig und verwirft der Server Anfragen, pausiert der Wächter, bis der Scan gelaufen ist (höchstens 15 Minuten).
- **Berufsfenster (moderner Client):** Eine direkt nach dem Öffnen noch leere Rezeptliste blockiert das Einlesen nicht mehr 5 Sekunden; der Zutaten-Knopf merkt sich das zuletzt gewählte Rezept; die Rezeptdetails werden nur einmal pro Beruf gelesen (weniger Ruckeln).
- `/ahs debug` zeigt, ob Händler-Kosten in Währung (z. B. Merchant's Favor) in diesem Client lesbar sind.

## 0.65.3

- **Der alte Ordner „AHAnalyzerPro“ ist nicht mehr dabei.** Es gibt nur noch den Ordner AHSentinel. Hast du AHSentinel schon einmal gestartet, sind deine alten Daten bereits übernommen und du kannst den Ordner „AHAnalyzerPro“ unter Interface\AddOns löschen.

## 0.65.2

- **GoldSentinelGame Version 2:** Die gemeinsame Versionserkennung setzt sich jetzt auch gegen frühe Fassungen durch, die andere GoldSentinel-Addons kurz mitgebracht hatten – keine Lua-Fehler, wenn mehrere Addons zusammen geladen sind.
- Händlerpreise: Fehlt im Spiel die Funktion für den Item-Link beim Händler, wird die Item-ID auf anderem Weg gelesen.

## 0.65.1

- **Gemeinsame Versionserkennung:** AHSentinel erkennt die Spielversion jetzt über **GoldSentinelGame** – dieselbe Erkennung, die nach und nach alle GoldSentinel-Addons bekommen. WoW Forever gilt dort immer als moderner Client, nie als Classic.
- Neu: `/gsgame` zeigt im Chat, welche Spielversion erkannt wurde; `/ahs debug` zeigt es ebenfalls.
- Für dich ändert sich sonst nichts.

## 0.65.0

**WoW Forever und Retail (moderner Client) – nichts bleibt mehr still leer:**
- **Berufsfenster:** Rezepte werden jetzt über die moderne Berufe-Schnittstelle (`C_TradeSkillUI`) gelesen, wenn die alte fehlt. Das Gewinn-Fenster neben dem Berufsfenster und die Herstell-Vorschläge in „Heute tun“ funktionieren damit auch dort. Ältere Spielversionen nutzen weiter den alten Weg.
- **Händlerpreise:** werden über `C_MerchantFrame` gelesen, wenn die alte Funktion fehlt. Artikel, die Währung oder Marken kosten (z. B. Merchant's Favor), werden mit ihren genauen Kosten gemerkt.
- **Raid-Vorrat:** Auf WoW Forever gilt die Classic-Vorlage (`/ahs raid`).
- **Wächter und der 15-Minuten-Komplett-Scan:** Lässt der Server nach einer Wächter-Runde den fälligen Komplett-Scan nicht zu, pausiert der Wächter, bis der Scan gelaufen ist.
- **Sniper:** Blockiert WoW den vorab reservierten Warenkauf (ohne Fehlermeldung, nur als Ereignis), schaltet sich „eine Raste kauft“ selbst ab und der Sniper kauft wieder mit zwei Rasten.
- Die Texte zur Einstellgebühr auf WoW Forever (0.64.2) gibt es jetzt in allen Sprachen.

## 0.64.2

- **WoW Forever: Einstellgebühr richtig eingerechnet.** Auf WoW Forever kostet jede Auktion **mindestens 1 Silber**, und die Gebühr gibt es **nie zurück**, auch nicht beim Verkauf. AHSentinel erkennt Forever jetzt selbst und zieht die Gebühr überall **immer** ab statt nur als Risiko bei Rücklauf: Flips, Verkaufsvorschläge in „Heute tun“, Herstellungs-Gewinne, Schnäppchen, Entzauber-Schnäppchen (Material wird im Stapel verkauft, Gebühr anteilig pro Stück), Händler-gegen-AH-Vergleich und Reiter Verkaufen (dort steht „nicht erstattet“).
- Vor allem **günstige Items** betrifft das: Bringt ein Item im AH 1s 50c und beim Händler 71c, bleiben nach 5 % und 1s Gebühr nur 42c – „Heute tun“ schlägt dann **„beim Händler verkaufen“** vor.
- Gebühr pro Stück = max(1 Silber, Gebühr eines vollen Stapels) ÷ Stapelgröße. In den anderen Spielversionen bleibt alles wie bisher (Gebühr wird beim Verkauf erstattet).
- Gewinnrechner: auf Forever ist 1 Silber Einstellgebühr enthalten.

## 0.64.1

- **„Heute tun“ schlägt Herstellen vor – auch ohne ProfessionSentinel:** AHSentinel merkt sich jetzt die Rezepte jedes Charakters, sobald du das Berufsfenster öffnest. „Heute tun“ schlägt dann die 2–3 lohnendsten Rezepte vor, die du **schon kannst** (Ergebnis verkauft sich gut, mindestens 10 % Gewinn nach AH-Anteil). Der Knopf **Zutaten kaufen** legt für jede fehlende Zutat aus dem Auktionshaus eine Kauf-Zeile an (10 % Preisspielraum, gekauft wird nur per Klick); Zutaten vom Händler stehen im Chat. Ist alles da: „Alles da – herstellen“.
- Ist ProfessionSentinel installiert, kommen dessen Vorschläge statt der eigenen (nichts doppelt).
- Wer einen Herstellungsberuf hat, aber ProfessionSentinel nicht, sieht unten in „Heute tun“ einen kleinen Tipp – **Ausblenden** entfernt ihn für immer.

## 0.64.0

**„Heute tun“ – kaufen und einstellen direkt in der Liste:**
- Jede Zeile hat jetzt einen **Knopf mit dem nächsten Schritt**, ohne Sprung in einen anderen Reiter:
  - Kauf-Vorschläge: **Prüfen** sucht das Item im Hintergrund. Danach steht in der Zeile das echte aktuelle Angebot („5× zu je 2g 40s = 12g“), und der Knopf heißt **Kaufen 12g**. Mehrere Einzel-Auktionen: **Kaufen (1/3)**, ein Klick pro Auktion (verlangt WoW). Waren im modernen Auktionshaus: Erst wird der Preis reserviert, dann **Bestätigen**.
  - **Nie teurer und nie mehr als vorgeschlagen**, der Kapitalschutz gilt weiter. Ist das Angebot weg oder teurer, steht „nicht mehr lohnend“ da, und es wird nichts gekauft.
  - Nach dem Kauf: Flips bekommen **Einstellen** (Preisvorschlag mit Preisschutz), Entzauber-Schnäppchen zeigen, wie viele in der Tasche sind, Händler-Schnäppchen sagen „Beim Händler verkaufen“.
  - Ware aus den Taschen: **Prüfen → Einstellen**. Zurückgekommene Auktionen: **Neu einstellen**, ein Klick pro Auktion.
- Ein Klick auf die Zeile selbst wechselt wie bisher in den Reiter.
- **Für andere Addons:** `AHAnalyzerPro.Today:QuickBuy(itemID, Menge, Höchstpreis, Text)` und `:QuickSell(itemID, Menge)` legen oben in „Heute tun“ eine Zeile an – gekauft wird nichts ohne deinen Klick.
- **ProfessionSentinel:** Seine Vorschläge „heute herstellen“ erscheinen in „Heute tun“. Der Knopf führt durch Zutaten kaufen, herstellen und einstellen.
- Die Entzaubern-Texte aus 0.63.0 gibt es jetzt in allen Sprachen.

## 0.63.4

- **Wächter nur noch bei belastbarem Marktwert:** Bisher meldete der Wächter auch „Schnäppchen“ bei 0–10 % vom Marktwert – fast immer, weil der Marktwert selbst falsch war (Mondpreis, seltenes Item, Preissturz). Weil der Wächter per Mausrad kauft, zählt jetzt nur noch ein Marktwert, dem man trauen kann.
- **Testmodus-Protokoll:** Käufe des Wächters stehen als „Sniper-Kauf (Wächter)“ mit Preis drin; Waren-Käufe aus Einkauf und Sniper ebenfalls mit Preis.

## 0.63.3

- **Qualitätsstufen (Retail):** Handwerksmaterial und hergestellte Items gibt es in mehreren Stufen – bisher standen z. B. dreimal „Bismut“ untereinander, ohne Unterschied. Jetzt steht das Stufen-Symbol hinter dem Namen (Einkauf, Markt, Verkaufen, Sniper, Buchhaltung …).
- **Rückmeldung nach Einstellen und Abbrechen:** Statt „Wird eingestellt …“ / „Wird abgebrochen …“ stehen zu bleiben, zeigt das Fenster jetzt „Eingestellt: …“ bzw. „Abgebrochen: …“.
- **Tagesbilanz:** zeigte „+ dein ganzes Gold seit gestern“, wenn das Spiel beim Einloggen kurz 0 Gold gemeldet hatte. Ein solcher 0-Wert zählt nicht mehr.
- **Testmodus-Protokoll:** Kauf von Waren (Retail) steht jetzt mit Preis drin, ein Sniper-Kauf als „Sniper-Kauf“ statt „Sofortkauf“.

## 0.63.2

- **Selbsttest in Retail:** brach mit „script ran too long“ ab (Retail stoppt Skripte, die zu lange am Stück laufen – bei rund 20 000 Items im Scan passiert das). Der Test legt jetzt regelmäßig kurze Pausen ein; der Sprachwechsel-Test prüft eine Sprache pro Bild.
- **Verkaufen bei geschlossenem Auktionshaus:** zeigte in Retail „Keine verkaufbaren Items in den Taschen“, obwohl die Taschen voll waren. Die Prüfung „kann man das einstellen?“ läuft jetzt nur noch bei offenem Auktionshaus.
- **Reagenzientasche (Retail):** Items darin zählen jetzt beim Verkaufen, Post an Twinks und Händler-Verkauf mit.

## 0.63.1

- **Retail (The War Within / Midnight, Interface 12.x): Item-Namen wieder da.** Im modernen Spiel gibt es die alten Funktionen `GetItemInfo`, `GetItemIcon` usw. nicht mehr – AHSentinel nimmt dort jetzt `C_Item`. Vorher stand überall „Item #12345“ statt des Namens (Einkauf, Preisverlauf, Tooltip, Testdaten).
- **Namen werden nachgeladen:** Der Komplett-Scan im modernen Auktionshaus liefert nur Item-IDs. Items, die dein Client noch nicht kennt, lädt AHSentinel jetzt gedrosselt im Hintergrund nach (40 pro Sekunde); die Listen aktualisieren sich von selbst.
- **Selbsttest „Suche nach Namen“** schlug in Retail fehl („'Item #251665' -> nil“). Er nimmt jetzt ein Item, dessen Name schon bekannt ist, und meldet sonst, wie viele Namen noch geladen werden.
- **Testmodus in Retail:** Die fiktiven Auktionen und Briefe brauchen Item-Namen – sie entstehen jetzt auch dort.
- Entzaubern: Zaubername über `C_Spell` (Retail).

## 0.63.0

- **Entzaubern – alle lernen gemeinsam:** Was beim Entzaubern herauskommt, teilt AHSentinel jetzt über den Preis-Sync mit allen Spielern, die das Addon haben (oder nur mit deiner Gilde, wenn du das eingestellt hast). Jeder schickt nur seine eigenen Zahlen, nichts wird doppelt gezählt. So stimmen die Dropchancen viel schneller mit der Wirklichkeit auf WoW Forever überein.
- **Neue Startwerte bei grünen Teilen:** 75 % Staub, 20 % Essenz, 5 % Splitter (Waffen umgekehrt: 75 % Essenz, 20 % Staub). Deine eigenen und die geteilten Ergebnisse passen die Werte danach an.
- Tooltip: „Entzaubern (Ø, 12 eigene, 340 geteilt)“ zeigt, auf wie vielen Entzauberungen der Wert beruht.
- Geteilt wird nur, welches Material wie oft herauskam – Unsinn (fremde Gegenstände, unmögliche Mengen) wird abgelehnt.
- ProfessionSentinel nutzt diese Werte für die Rangliste „Herstellen & Entzaubern“.

## 0.62.4

- **Stapelware zusammengefasst (klassisches Auktionshaus):** Im Einkauf bilden alle Angebote eines stapelbaren Items mit gleichem Stückpreis **eine Zeile mit der Summe** – z. B. 5 Stapel zu 20 stehen als „100“ da, mit Stückpreis und **Gesamtpreis** der Zeile.
- **Mehrere zusammen kaufen:** Zeile anklicken, mit **Shift+Linksklick** weitere Zeilen dazu. Rechts stehen Stückzahl, Anzahl Angebote und der Gesamtpreis deiner Auswahl. „Auswahl kaufen“ fragt einmal mit der Summe nach, danach kauft jeder Klick das nächste Angebot (WoW verlangt einen Klick pro Auktion).
- „Einzelne Angebote anzeigen“ schaltet zur bisherigen Liste zurück (dort auch Bieten). Das moderne Auktionshaus fasst Waren schon selbst nach Preis zusammen – dort gibst du einfach die Menge ein.

## 0.62.3

- **Item-Namen für WoW Forever:** Die eingebauten Namen von WoW Forever haben wieder Vorrang, die in 0.62.1 ergänzten TBC-Namen füllen nur noch Lücken. Rund 2000 Items, die in TBC umbenannt wurden, heißen in den anderen Sprachen wieder wie auf WoW Forever.

## 0.62.2

- **Test- und Entwicklerfunktionen ausgeblendet:** Selbsttest und Testmodus (Knopf „Test“, `/ahs test`, `/ahs testmodus`) gibt es jetzt nur noch für den Entwickler. Für alle anderen sieht das Addon gleich aus und funktioniert gleich, nur ohne diese Werkzeuge.

## 0.62.1

**Realistische Preise – wichtig für den frischen Server, auf dem die Preise jeden Tag fallen:**
- **Marktwert folgt dem Markt schneller:** Neuere Preise zählen stärker (Halbwertszeit 3 Tage) statt eines einfachen Medians über 14 Tage. Mondpreise wie „1666g 99s 98c“ zählen gar nicht mehr.
- **Preissturz wird erkannt:** Liegen die letzten zwei Scans (mind. 6 Std. auseinander) weit unter dem Marktwert, steht im Tooltip „Preis gerade eingebrochen“, und der Marktwert gilt als unsicher. Solche Items werden nicht mehr zum Kaufen, Flippen oder Verkaufen vorgeschlagen.
- **„Heute tun“ rechnet mit dem, was du wirklich bekommst:** höchstens 5 % über dem günstigsten aktuellen Angebot, nie mit dem alten Marktwert. Ist der AH-Preis bis nahe an den Händlerpreis gefallen, kommt der Vorschlag „beim Händler verkaufen“.
- **Gebote** werden nur noch bei sicherem Marktwert und nie auf Mondpreise vorgeschlagen.
- **Gewinn/Tag** bei den Schnäppchen zählt nur einen Teil der Tagesverkäufe (du bist nicht der einzige Verkäufer), höchstens die verfügbare Menge und was 20 % deines Golds kaufen.
- Die Übersicht zeigt keine Preise mit …99s 9xc mehr.

**Fehler behoben:**
- **Esc** schließt wieder den Preisverlauf statt des ganzen Auktionshauses (auch nach einem Sprachwechsel).
- **Testmodus:** Ein Sniper-Kauf per Mausrad steht jetzt im Protokoll und in der Buchhaltung.
- **Briefkasten:** neuer Knopf „Neu einstellen (N)“ für zurückgekommene Auktionen. Bildschirmmeldungen haben im Testmodus „[Test]“. Im Testmodus wird langsamer abgeholt, damit man „Anhalten“ ausprobieren kann. Zurückgekommene Test-Ware wird mitgezählt.
- `/ahs bilanz` zeigt kein „+ dein ganzes Gold seit gestern“ mehr, wenn das Gold von gestern nicht bekannt ist.
- Das Geldfeld zeigt bei jeder Eingabe, was verstanden wurde („= 5s“), nicht nur bei reinen Zahlen.
- Ein Item-Tooltip bleibt nicht mehr über einem neu geöffneten Fenster stehen („Heute tun“, Optionen …).
- Im Selbsttest stehen keine Symbol-Codes mehr in den Details.

**Sprachen:**
- **Rund 10 000 Item-Namen mehr in jeder Sprache**, auch alle Items aus Burning Crusade (Englisch: 25 800 statt 14 800). In einer englischen Oberfläche stehen keine deutschen Namen mehr.
- **Listen zeigen die Namen immer in der eingestellten Sprache** – Suchergebnisse, Sniper-Ziele, Beobachtungsliste, Einkaufslisten, Buchhaltung, Auktionen – auch direkt nach dem Wechsel, ohne neue Suche.
- Der Einkauf behält nach dem Sprachwechsel Kategorie, Suchtext und Filter.
- Optionen: Lange Beschriftungen (Französisch, Spanisch, Russisch) brechen in eine zweite Zeile um, statt abgeschnitten zu werden.
- Filter im Einkauf: kurze Platzhalter („St. ab / bis“, „Lvl min / max“), die sich nicht mehr überlappen.
- Chinesisch: „vereinfacht“ und „traditionell“ sind in der Sprachliste unterscheidbar. Item-Namen ohne chinesischen Namen werden ohne Umlaute geschrieben (ö → oe), weil die chinesische Schrift sie nicht hat.
- Selbsttest: Die Sprachprüfung findet jetzt auch abgeschnittene Beschriftungen und Namen in der falschen Sprache und zählt fehlende Item-Namen pro Sprache.

## 0.62.0

**AH Analyzer Pro heißt jetzt AHSentinel** – passend zur Sentinel-Familie (BuffSentinel, GuildSentinel, ThreatSentinel).

- **Deine Daten werden automatisch übernommen:** In der ZIP sind der neue Ordner `AHSentinel` und ein kleiner Ordner `AHAnalyzerPro`, der beim ersten Start nur deine alten Daten (Preise, Buchhaltung, Listen, Sniper-Ziele, Einstellungen) übergibt. Danach kannst du `AHAnalyzerPro` löschen.
- **Neuer Befehl `/ahs`** (auch `/ahsentinel`); `/ahp` geht weiterhin.
- Sonst bleibt alles gleich.

**Installieren:** beide Ordner aus der ZIP nach `Interface\AddOns` kopieren (den alten Ordner `AHAnalyzerPro` überschreiben), Spiel starten, fertig.

## 0.61.2

- **Eine Sprache für alles:** Item-Namen folgen jetzt der Sprache des Addons (außer du hast eine eigene Sprache für Item-Namen gewählt), und der Tooltip zeigt den Item-Namen in dieser Sprache, wenn sie von der Sprache des Spiels abweicht.
- **Sprachwechsel baut jedes Fenster neu auf:** neben dem Hauptfenster auch „Heute tun“, das Test-Fenster, die Regeln für „Post an Twinks“ und die Leiste am Briefkasten (auch bei offenem Briefkasten).
- **Selbsttest:** neue Prüfung „Sprachwechsel“ – jede Sprache des Addons einmal, danach mehrfach hin und her; Fenster, Reiter, Texte, Item-Namen und Tooltip müssen in der gewählten Sprache erscheinen, danach ist die alte Sprache wieder eingestellt.

## 0.61.1

- **Behoben: „Heute tun“ schlug unrealistische Käufe vor.** Seiten-Scans sehen oft nur einen Teil des Auktionshauses – das sah aus wie riesige Verkäufe. Verkäufe pro Tag werden jetzt nur noch zwischen **vollständigen** Scans geschätzt, jeder Rückgang zählt nur zur Hälfte (der Rest ist abgelaufen oder zurückgezogen), und es wird nie mehr als die Hälfte der üblichen Angebotsmenge angenommen. Auch „seit Scan“ vergleicht nur noch vollständige Scans.
- **Kapitalschutz:** Jeder Vorschlag in „Heute tun“ nutzt höchstens 20 % deines Golds, alle zusammen höchstens die Hälfte; das Fenster zeigt den Kapitalbedarf. Der Selbsttest prüft das.
- **Übersicht:** Anstiege auf ein Vielfaches des Marktwerts und Rückgänge von einem früheren Mondpreis erscheinen nicht mehr.
- **Briefkasten:** Die Knöpfe des Addons sitzen jetzt ordentlich in einer Leiste **neben** dem Briefkasten statt über dessen Rahmen. „Alles abholen“ gibt es nur, wenn WoW kein eigenes „Alle öffnen“ hat (und im Testmodus für die Test-Post), „Anhalten“ nur während des Abholens.
- **Ein Geldfeld statt drei:** „5s“, „1g 20s“, „4s 85k“ oder „1.5“ (= 1g 50s) eintippen; bei einer reinen Zahl steht dabei, wie sie verstanden wird („= 5g“). Kein Silber mehr im Gold-Feld.
- Kleinigkeiten: „Bieten“ ohne gewähltes Angebot sagt das, die Händler-Warnung beim Einstellen kommt nur noch, wenn es um etwas geht (mind. 1 Silber und 10 %), fiktive Auktionen erscheinen im Testmodus sofort, das Fenster „Heute tun“ schließt beim Sprung in den Reiter.

## 0.61.0

**Mehr Gewinn, weniger Schein-Schnäppchen:**

- **„Heute tun“** (Knopf in der Übersicht, `/ahp heute`): die Aktionen, die gerade am meisten Gold bringen, sortiert nach geschätztem Netto-Gewinn – unter Händlerpreis kaufen, Flips, Taschen verkaufen, unterbotene Auktionen, Neu einstellen, Entzauber- und Gebots-Schnäppchen. Ein Klick auf eine Zeile führt direkt in den passenden Reiter.
- **Verkaufbarkeit statt Angebotspreisen:** Aus deinen Scans schätzt das Addon jetzt, wie viel sich von einem Item wirklich pro Tag verkauft und ob man dem Marktwert trauen kann. Selten angebotene Items und **Mondpreise** (z. B. 2499g 99s 99c) erscheinen nicht mehr bei Schnäppchen, Flips und in der Übersicht (Knopf „auch unsichere“ zeigt sie trotzdem). Schnäppchen sind nach **Gewinn pro Tag** sortiert, der Tooltip zeigt „~N/Tag verkauft (geschätzt)“.
- **Netto-Gewinn mit Einstellgebühr:** Im klassischen Auktionshaus wird die Gebühr jetzt aus dem Händlerpreis geschätzt („ca.“) und beim ersten echten Einstellen genau gelernt. Gewinne ziehen die Gebühr ab, die bei Rücklauf verloren geht (nach deiner eigenen Verkaufsquote).

## 0.60.11

- **Briefkasten-Knöpfe antworten immer:** „Post abgeholt: …“ erscheint jetzt auch in der Bildschirmmitte, und ein leerer Briefkasten meldet „Nichts zum Abholen“, statt still zu bleiben.
- **„An Twinks“ ohne Regel** sagt das im Chat, bevor sich das Regel-Fenster öffnet.
- **Testmodus:** Der fiktive Brief „Auktion erfolgreich“ gehört jetzt zur verkauften fiktiven Auktion, und diese verschwindet aus „Meine Auktionen“, sobald der Erlös abgeholt ist – wie im Spiel.

## 0.60.10

- **Testmodus mit fiktiven Auktionen:** „Meine Auktionen“ zeigt im Test drei fiktive Auktionen (eine unterboten, eine günstigste, eine verkauft) und alles, was du im Test einstellst – Abbrechen und Unterbietung prüfen lassen sich so ohne echte Auktion ausprobieren. Der Selbsttest nimmt fürs Abbrechen eine fiktive Auktion, wenn du keine hast.
- **Test-Briefkasten:** Im Testmodus arbeiten die Briefkasten-Knöpfe des Addons mit fiktiver Post (verkauft, gewonnen, abgelaufen, abgebrochen, überboten, ein normaler Brief): automatisch abholen, „Alles“, Rechnungen in der Buchhaltung und „Neu einstellen“ lassen sich ausprobieren – deine echte Post bleibt unberührt.
- **Einkauf:** Beim Wechsel zu einem anderen Item werden Gebotsfeld und gewähltes Angebot zurückgesetzt (kein altes Gebot mehr im Feld). Die Kopfzeile zeigt günstigstes Angebot und Marktwert (Median 14 Tage) getrennt und sagt, wenn noch weitere Angebote geladen werden.
- **Sniper:** Angebote des vorigen Ziels stehen nicht mehr unter dem Namen des neuen.
- **Selbsttest:** Der Sniper-Test „kauft“ (simuliert) den kleinsten Stapel statt eines 2er-Stapels.
- **Preisverlauf:** lässt sich jetzt auch am Titel verschieben.

## 0.60.9

- **Meldung, wenn der Scan fertig ist:** groß in der Bildschirmmitte („AH-Scan fertig: N Items“) und mit Ton (wenn in den Optionen der Ton an ist) – du musst nicht mehr auf den Chat schauen. Ein Scan ohne Ergebnis wird dort ebenfalls gemeldet.

## 0.60.8

- **Behoben: keine Preiszeilen im Tooltip** auf manchen Clients (z. B. TBC Anniversary). Das Addon hängt sich jetzt an alle Wege, über die WoW einen Item-Tooltip füllt, und passt die Größe nach seinen Zeilen an. Der Selbsttest prüft jetzt den echten Taschen-Tooltip.
- **Esc schließt nur das oberste Fenster:** z. B. den Preisverlauf – Addon-Fenster und Auktionshaus bleiben offen (vorher ging mit einem Esc alles zu).
- **Preisverlauf:** Das X liegt nicht mehr auf dem Knopf „Alles“.
- **Testmodus** setzt jetzt auch Favoriten im Einkauf, die Liste zum Neu-Einstellen und die Post-Regeln zurück.
- **Deine eigene Suche geht vor:** Eine laufende Wächter-Runde wird abgebrochen, der Einkauf wartet nicht mehr („Warte auf den Wächter …“).
- Einkauf zeigt nach dem Kauf „Gekauft: …“ statt „Kauf wird ausgeführt …“.
- Übersicht: Preissprünge um das Zehnfache (fast immer Fehldaten) erscheinen nicht mehr als Anstieg oder Rückgang.
- Kleinigkeiten: Sniper-Käufe heißen im Testmodus-Protokoll „Sniper-Kauf“, die Einkaufslisten geben nach dem Löschen die Tastatur frei, „N Einträge“ überlappt nicht mehr, Option heißt kurz „Ablauf-Erinnerung“, Einstellgebühr im klassischen AH „beim Einstellen“ statt „?“, iLvl-Hinweis nur bei vorhandenen Treffern, Mausrad im Berichtsfenster schneller, Titel „Testbericht“.

## 0.60.7

- **Neuer Knopf „Test“** oben im Fenster (und in der Leiste im Auktionshaus): Selbsttest und der neue **Testmodus** in einem Fenster.
- **Testmodus:** Alle Funktionen von Hand mit deinen echten Auktionshaus-Daten ausprobieren – Kaufen, Bieten, Sniper (auch mit dem Mausrad), Einstellen, Abbrechen, Händler-Verkauf, Post abholen und verschicken. Jeder Handel ist **nur simuliert**: Der Befehl an den Server wird abgefangen und die Antwort des Servers nachgespielt – Meldungen, Buchhaltung und Sniper-Zähler verhalten sich wie echt. Beim Beenden sind alle Einstellungen und Daten (Listen, Buchhaltung, Sniper, Wächter, Verkaufen) wieder wie vorher – auch automatisch nach `/reload` oder einem Absturz. Ein Protokoll zeigt jede simulierte Aktion und kommt mit in den kopierten Bericht.
- ⚠️ Nur die Knöpfe des Addons sind simuliert – Blizzards eigene Knöpfe im Auktionshaus kaufen weiterhin echt. Auch: `/ahp testmodus`.

## 0.60.6

- **Selbsttest simuliert echten Handel:** Mit den echten Angeboten aus dem Auktionshaus spielt er jetzt Sofortkauf, Gebot, Sniper-Kauf, Einstellen und Abbrechen genau wie im Ernstfall durch – gleiches Angebot, gleicher Preis, gleicher Befehl. Nur der Befehl an den Server wird abgefangen: Es wird nichts gekauft, eingestellt oder abgebrochen, und am Ende prüft der Test, dass dein Gold unverändert ist. Meldungen im Chat sind dabei mit „[Simulation]“ markiert.
- **Selbsttest:** Der Wächter wird nach seiner Testrunde gleich wieder ausgeschaltet und blockiert die folgenden Server-Suchen nicht mehr.

## 0.60.5

- **Behoben (klassische Clients):** Beim Öffnen des Auktionshauses konnte der Lua-Fehler „attempt to compare number with nil“ kommen (Gebote nach einem Reload).
- **Kopfzeile:** „Sniper: an/aus“ und „Wächter: an/aus“ stimmen jetzt immer, auch nach dem Umschalten.
- **Selbsttest:** Läuft im Hintergrund noch ein Markt-Scan, laufen die Server-Suchen nicht mehr alle in die Zeitüberschreitung – beim Test mit gespeicherten Daten wird der Scan beendet, sonst wird auf ihn gewartet. Ein neuer Scan ist während des Tests gesperrt.
- **Selbsttest:** Danach sind Einstellungen, Wächter und Fenster (Reiter, oder geschlossen) zuverlässig wie vorher. Klappt etwas nicht, steht es im Bericht.
- **Textfenster** („Bericht kopieren“) öffnet sich immer vorne, beginnt oben und scrollt mit dem Mausrad zügig (mit Shift in großen Schritten).

## 0.60.4

- **Selbsttest mit gespeicherten Daten:** neuer Knopf „Mit gespeicherten Daten“ im Selbsttest-Fenster (oder `/ahp test daten`). Er testet mit den Auktionshaus-Daten, die du schon gescannt hast – **kein neuer Scan**. Er läuft sogar bei geschlossenem Auktionshaus, dann werden nur die Suchen beim Server übersprungen.

## 0.60.3

- **Behoben für TBC Anniversary (und andere klassische Clients):** „Meine Auktionen“ wurde nie aktualisiert, und manche Meldungen des Auktionshauses (z. B. „eingestellt“) kamen nicht an. Diese Clients kennen die Ereignis-Namen des neuen Auktionshauses, lösen sie beim klassischen aber nie aus – das Addon nutzt dort jetzt immer seine eigenen. Gefunden mit dem neuen Selbsttest.
- **Selbsttest:** Der kopierte Bericht lässt sich jetzt scrollen, die Ergebnisliste ist breiter – Maus über eine Zeile zeigt den ganzen Text.

## 0.60.2

- **Selbsttest:** Optionen → „Selbsttest“ oder `/ahp test` prüft alle Funktionen mit echten Daten aus deinem Auktionshaus: Markt-Scan (falls nötig), Marktdaten, alle Reiter, alle Auswertungen und echte Suchen beim Server (Einkauf, Preisprüfung, Sniper, Wächter, eigene Auktionen). Während des Tests sind **Kaufen, Bieten, Einstellen und Abbrechen gesperrt**, danach sind Einstellungen und Sniper-Ziele wie vorher. Das Ergebnis erscheint in einem Fenster, lässt sich als Bericht kopieren und wird gespeichert.

## 0.60.1

- **Echter Minikarten-Knopf:** Der Knopf sitzt jetzt wie bei anderen Addons an der Minikarte – mit der Maus **rund um die Minikarte ziehen**, die Position wird gespeichert. Funktioniert mit runden und eckigen Minikarten. Ein-/ausblenden in den Optionen oder mit `/ahp minimap`, `/ahp reset` holt ihn zurück.
- **Neues Icon:** eine goldene **Waage** – am Minikarten-Knopf, oben im Fenster und in der Addon-Liste.

## 0.60.0

**Aufgeräumtes Fenster – 5 Reiter statt 11:**

- **Übersicht · Kaufen · Verkaufen · Markt · Buchhaltung.** Was zusammengehört, steht jetzt als Unterreiter:
  Kaufen = Einkauf, Sniper, Wächter, Schnäppchen · Verkaufen = Einstellen, Meine Auktionen · Markt = Alle Preise, Watchlist.
  Alle Funktionen sind noch da, nichts ist weggefallen.
- **Preisverlauf im eigenen Fenster:** Ein Klick auf ein Item öffnet den Verlauf neben dem Addon – die Liste, aus der du kommst, bleibt genau, wo sie war. Das Fenster lässt sich verschieben und in der Größe ziehen.
- **Sniper und Wächter in der Kopfzeile:** auf einen Blick sehen, ob sie laufen, und mit einem Klick an- oder ausschalten (Rechtsklick öffnet ihren Reiter).
- **Merkt sich, wo du warst:** Das Addon öffnet sich im zuletzt benutzten Reiter, jeder Haupt-Reiter merkt sich seinen Unterreiter.

## 0.59.33

**Komfort-Update – zwölf kleine Dinge, die jeden Tag Klicks sparen:**

- **Stapelgröße und Anzahl Stapel** (klassisches Auktionshaus): z. B. 5 Stapel à 20 – wird pro Item gemerkt, auch für die Serie.
- **Post automatisch abholen:** Beim Öffnen des Briefkastens wird die Auktionspost gleich abgeholt (Shift beim Öffnen = diesmal nicht).
- **Mindestpreis pro Item:** Knopf „Min“ beim Verkaufen – darunter wird nie unterboten, die Serie wartet statt billig zu verkaufen.
- **Nur was mir fehlt:** Am Berufsfenster kommt nur die fehlende Menge auf die Einkaufsliste (Taschen, Bank und Twinks werden gezählt).
- **Alt-Klick auf ein Item** in den Taschen oder im Chat: öffnet den Preisverlauf, bei offenem Auktionshaus den Einkauf.
- **Verkaufschance im Tooltip:** wie viel von dem, was du eingestellt hast, verkauft wurde und wie lange es meist dauert.
- **Erinnerung bei ablaufenden Auktionen** und beim Einloggen, was seit dem letzten Besuch abgelaufen ist.
- **Favoriten im Einkauf:** Suchen speichern und mit einem Klick wieder ausführen.
- **Gold-Ziel** für alle Charaktere zusammen (Optionen oder `/ahp ziel 5000`).
- **Gildenbank-Wert** in der Buchhaltung (ab TBC).
- **Raid-Vorrat:** Einkaufsliste mit Tränken, Fläschchen, Elixieren und Buff-Food für eine Raidwoche (`/ahp raid`).
- **Preis-Sync nur mit der Gilde** als neue Option.

## 0.59.32

- **Keine absurden Gewinne mehr:** Items mit 1000 % Gewinn oder mehr (fast immer Fehldaten) erscheinen nicht mehr bei den Schnäppchen und nicht mehr unter „Größte Preisanstiege“.

## 0.59.31

- **Itemlevel als Suchfilter:** Felder „iLvl ab / bis“ im Einkauf und im Markt – filtern sofort, ohne neue Suche beim Server.

## 0.59.30

- **Schrott beim Händler verkaufen** mit einem Knopf (graue Items und alles, was beim Händler mehr bringt).
- **Vermögen:** Wert von Taschen, Bank und Twinks plus das Gold aller Charaktere.
- **Tagesbilanz beim Einloggen**, jederzeit mit `/ahp bilanz`.
- **Neu einstellen mit einem Klick** für abgelaufene Auktionen.
- **Flip-Empfehlungen**, **Post an Twinks**, **/ahp help** im Chat.
- Einkauf: iLvl für jedes Item · Verkaufen: Angebote erscheinen viel schneller.
