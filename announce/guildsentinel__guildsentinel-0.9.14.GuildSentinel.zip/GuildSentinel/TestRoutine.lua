-- GuildSentinel - TestRoutine.lua
-- Automatische Testroutine ("auf Herz und Nieren"), nur für den Entwickler (GoldSentinelDev).
--   /gs testroutine            alle Bereiche A bis J (gleich wie der Knopf "Alles testen" in Einstellungen > Testmodus)
--   /gs testroutine a … k      nur ein Bereich (k: Oberfläche im echten Client)
--   /gs testroutine whisperq   nur Anzeige: gemerkte Kampf-Flüsternachrichten und wie viele davon geschützt sind
-- IDs, Bereiche und Erwartungen wie in raidmaster/auftraege/GuildSentinel/testroutine-guildsentinel.txt (T01–T173),
-- dazu T174 (Aktionen nur über ns.Act) und T175–T181 (Bank-Charakter, anweisung-guildsentinel-gildenbank.txt).
-- Ergebnisse nur über GoldSentinelTest (Check / Skip / Client); der Bericht landet in GuildSentinelDB.gsTest.
--
-- Regeln (nachtrag-testroutinen.txt, gehen der Anweisung vor):
--   * Keine Blizzard-Funktion wird ersetzt, auch nicht vorübergehend. Ersetzt werden nur Felder eigener Tabellen
--     (ns, ns.API, Module, eigene Ersatz-Objekte) – über Swap(), immer wieder zurückgesetzt. Alte bzw. moderne
--     Clients ("Funktion fehlt") stellt die Routine über Einträge in ns.API nach (API.lua). Was sich so nicht
--     nachstellen lässt, ist ÜBERSPRUNGEN (mit Grund) oder IM CLIENT PRÜFEN.
--   * Aktionen mit Folgen laufen im Addon über ns.Act (Chat, Addon-Nachrichten, Einladen, Entfernen, Befördern,
--     Gildennotiz, Kanal, Flüsterfenster, Töne). Während der Routine ist ns.actRecorder gesetzt: nur mitschreiben.
--     Echte Aufrufe zählt ein hooksecurefunc (ersetzt nichts) – Erwartung 0.
--   * Geschützte Werte: Köderwerte in ns.testSecret, die ns.IsSecret als geschützt erkennt (issecretvalue bleibt
--     unberührt). Kampfsperre: ns.testCombat statt InCombatLockdown.
--   * Sandbox: GuildSentinelDB (ohne gsTest) und der Laufzustand werden vorher kopiert, am Ende verglichen und in
--     dieselben Tabellen zurückgeschrieben (ns.db und ns.guild bleiben mit den gespeicherten Daten verbunden).
--   * Berichte ohne Spieler-, Gilden- und Chatnamen. Erfundene Namen der Testgilde nur, wo der Fall sie braucht.

local ADDON, ns = ...
local L = ns.L

local R = {}
ns.Routine = R

R.AREAS = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K" }   -- K: Oberfläche im echten Client (0.9.14)
R.TOC_INTERFACES = { 11509, 11508, 16001, 20506, 20505 }    -- wie GuildSentinel.toc (Offline-Test vergleicht)
R.WAIT = 7.5                                                  -- Sekunden für die verzögerten Sendungen (T67, T167)

local RUN                 -- laufender Durchlauf (GoldSentinelTest-Objekt)
local ORANGE = "|cffff9933"

------------------------------------------------------------
-- Hilfen
------------------------------------------------------------
local function Ms()
	if debugprofilestop then return debugprofilestop() end
	return GetTime() * 1000
end

local function S(v)
	if v == nil then return "nil" end
	if ns.IsSecret(v) then return "<geschützt>" end
	return tostring(v)
end

local function Copy(v, seen)
	if type(v) ~= "table" then return v end
	seen = seen or {}
	if seen[v] then return seen[v] end
	local t = {}
	seen[v] = t
	for k, x in pairs(v) do t[Copy(k, seen)] = Copy(x, seen) end
	return t
end

-- dst in-place auf den Stand von src bringen (dieselben Tabellen bleiben erhalten); oben ohne gsTest
local function RestoreInto(dst, src, top)
	for k in pairs(dst) do
		if src[k] == nil and not (top and k == "gsTest") then dst[k] = nil end
	end
	for k, v in pairs(src) do
		if not (top and k == "gsTest") then
			if type(v) == "table" and type(dst[k]) == "table" then RestoreInto(dst[k], v)
			else dst[k] = Copy(v) end
		end
	end
end

-- abweichende Pfade (höchstens max), Gilden-Schlüssel und Namen anonymisiert
local function Anon(k, depth)
	if type(k) ~= "string" then return tostring(k) end
	if depth == 2 then return "<gilde>" end            -- guilds.<Realm|Gilde>
	if k:find("|") then return "<schlüssel>" end
	if k:match("^%u") and not k:match("^%u+$") then return "<name>" end
	return k
end
local function Diff(a, b, path, out, max, depth, top)
	if #out >= max then return end
	if type(a) ~= type(b) then out[#out + 1] = path return end
	if type(a) ~= "table" then
		if a ~= b then out[#out + 1] = path end
		return
	end
	for k, v in pairs(a) do
		if not (top and k == "gsTest") then
			Diff(v, b[k], path .. "." .. Anon(k, depth + 1), out, max, depth + 1)
		end
	end
	for k in pairs(b) do
		if not (top and k == "gsTest") and a[k] == nil then
			if #out >= max then return end
			out[#out + 1] = path .. "." .. Anon(k, depth + 1)
		end
	end
end

local function Has(list, x)
	for _, v in ipairs(list or {}) do if v == x then return true end end
	return false
end

local function Count(t) local n = 0 for _ in pairs(t or {}) do n = n + 1 end return n end

------------------------------------------------------------
-- Ersetzen eigener Felder (nie _G, nie Blizzard-Tabellen)
------------------------------------------------------------
local swaps = {}
local BLIZZ = { C_ChatInfo = true, C_GuildInfo = true, C_PartyInfo = true, C_Container = true, C_Item = true, C_Spell = true,
	C_SpellBook = true, C_QuestLog = true, C_AddOns = true, C_TradeSkillUI = true, C_Timer = true }
local function Swap(tbl, key, value)
	assert(type(tbl) == "table" and not rawequal(tbl, _G), "Swap: nur eigene Tabellen")
	for name in pairs(BLIZZ) do assert(not rawequal(tbl, _G[name]), "Swap: keine Blizzard-Tabelle") end
	swaps[#swaps + 1] = { tbl, key, rawget(tbl, key) }
	tbl[key] = value
end
local function UnswapTo(n)
	for i = #swaps, n + 1, -1 do
		local s = swaps[i]
		s[1][s[2]] = s[3]
		swaps[i] = nil
	end
end
local function UnswapAll() UnswapTo(0) end
-- fn mit vorübergehend ersetzten Feldern ausführen; danach immer zurück
local function With(list, fn)
	local mark = #swaps
	local ok, a, b, c = pcall(function()
		for _, x in ipairs(list) do Swap(x[1], x[2], x[3]) end
		return fn()
	end)
	UnswapTo(mark)
	if not ok then error(a, 0) end
	return a, b, c
end

------------------------------------------------------------
-- Köderwerte für geschützte Werte ("secret values")
------------------------------------------------------------
-- Jeder Köder ist ein eigenes Objekt, das bei jeder Rechnung, jedem Vergleich, Zerlegen oder Zusammensetzen einen
-- Lua-Fehler wirft – wie ein geschützter Wert in WoW Forever. ns.IsSecret erkennt ihn über ns.testSecret.
local function NewBait()
	local p, mt
	if newproxy then
		p = newproxy(true)
		mt = getmetatable(p)
	else
		p, mt = {}, {}
		setmetatable(p, mt)
	end
	local function boom() error("secret value used", 2) end
	for _, k in ipairs({ "__add", "__sub", "__mul", "__div", "__mod", "__unm", "__concat", "__lt", "__le", "__len", "__index", "__newindex", "__call" }) do
		mt[k] = boom
	end
	mt.__tostring = function() return "<geschützt>" end
	return p
end
local function Bait()
	local b = NewBait()
	ns.testSecret = ns.testSecret or {}
	ns.testSecret[b] = true
	return b
end

------------------------------------------------------------
-- Recorder: was hinausginge, wird nur gezählt (ns.Act); echte Aufrufe zählt hooksecurefunc
------------------------------------------------------------
R.rec = {}
R.real = 0
R.realBy = {}
local hooked = false
local function InstallHooks()
	if hooked or not hooksecurefunc then return end
	hooked = true
	local function counter(name)
		return function() if R.running then R.real = R.real + 1; R.realBy[name] = (R.realBy[name] or 0) + 1 end end
	end
	for _, name in ipairs({ "SendChatMessage", "SendAddonMessage", "GuildInvite", "GuildUninvite", "GuildPromote",
		"GuildRosterSetPublicNote", "InviteUnit", "JoinTemporaryChannel", "JoinChannelByName", "LeaveChannelByName",
		"ChatFrame_OpenChat", "ChatFrame_SendTell" }) do
		if type(_G[name]) == "function" then pcall(hooksecurefunc, name, counter(name)) end
	end
	for _, x in ipairs({ { "C_ChatInfo", "SendChatMessage" }, { "C_ChatInfo", "SendAddonMessage" }, { "C_GuildInfo", "Invite" },
		{ "C_GuildInfo", "Uninvite" }, { "C_GuildInfo", "Promote" }, { "C_PartyInfo", "InviteUnit" } }) do
		local t = _G[x[1]]
		if type(t) == "table" and type(t[x[2]]) == "function" then pcall(hooksecurefunc, t, x[2], counter(x[1] .. "." .. x[2])) end
	end
end
local function Recorded(what) return R.rec[what] or 0 end
local function RecTotal()
	local n = 0
	for _, v in pairs(R.rec) do n = n + v end
	return n
end

------------------------------------------------------------
-- Prüfungen (Bereichsfilter, Abbruch bei Kampf)
------------------------------------------------------------
local area                -- Bereich, der gerade läuft
local only                -- nur dieser Bereich (nil = alle)
local aborted

local function Want(a) return not only or only == a end

local function Check(id, a, name, fn)
	if not Want(a) then return end
	if aborted then RUN:Skip(id, a, name, "Kampf begonnen") return end
	RUN:Check(id, a, name, fn)
end
local function Skip(id, a, name, why)
	if not Want(a) then return end
	RUN:Skip(id, a, name, why)
end
local function Client(id, a, name, how)
	if not Want(a) then return end
	RUN:Client(id, a, name, how)
end

-- kleine Erwartungs-Helfer: liefern ok, ist, soll
local function Eq(ist, soll) return ist == soll, S(ist), S(soll) end
local function True(v, what) return v and true or false, what and (what .. "=" .. S(v)) or S(v), "true" end
local function NoErr(fn, ...)
	local ok, err = pcall(fn, ...)
	if not ok then return false, "Lua: " .. tostring(err), "kein Fehler" end
	return true
end

-- Fehlerzähler: Unterschied seit einem Stand
local function ErrMark() return ns.errors and ns.errors.n or 0 end

------------------------------------------------------------
-- Testmodus kurz verlassen (reine Abfragen wie ns.IsOfficer, die im Testmodus immer true liefern)
------------------------------------------------------------
local function Outside(fn)
	local T = ns.Test
	local was = T.active
	T.active = false
	local ok, a, b, c = pcall(fn)
	T.active = was
	if not ok then error(a, 0) end
	return a, b, c
end

------------------------------------------------------------
-- Seiten und Reiter
------------------------------------------------------------
local function Pages()
	local out = {}
	for i, p in ipairs(ns.UI.pages or {}) do out[#out + 1] = { i = i, page = p, key = p.key } end
	return out
end

local function TabsOf(i)
	local list = {}
	for _, bar in ipairs(ns.UI.tabBars or {}) do
		if bar:GetParent() == ns.UI.panels[i] then
			for _, b in ipairs(bar.buttons) do list[#list + 1] = { bar = bar, key = b.key } end
		end
	end
	return list
end

local function OpenAllPages()
	local UI = ns.UI
	if not UI.frame then UI:Build() end
	UI.frame:Show()
	local n, errs = 0, {}
	for _, p in ipairs(Pages()) do
		if UI:PageOn(p.page) then
			local ok, err = pcall(UI.Select, UI, p.i)
			n = n + 1
			if not ok then errs[#errs + 1] = p.key .. ": " .. tostring(err) end
		end
	end
	return n, errs
end

local function OpenAllTabs()
	local UI = ns.UI
	local n, errs = 0, {}
	for _, p in ipairs(Pages()) do
		if UI:PageOn(p.page) then
			pcall(UI.Select, UI, p.i)
			for _, t in ipairs(TabsOf(p.i)) do
				if t.bar:IsVisible(t.key) then
					n = n + 1
					local ok, err = pcall(t.bar.Select, t.bar, t.key)
					if not ok then errs[#errs + 1] = p.key .. ">" .. tostring(t.key) .. ": " .. tostring(err) end
				end
			end
		end
	end
	return n, errs
end
R.OpenAllPages, R.OpenAllTabs = OpenAllPages, OpenAllTabs

------------------------------------------------------------
-- A. LADEN UND ERKENNUNG
------------------------------------------------------------
local function GetMeta(addon, field)
	local fn = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
	if not fn then return nil end
	local ok, v = pcall(fn, addon, field)
	return ok and v or nil
end

local function Interface() return select(4, GetBuildInfo()) end

local function Real()
	-- echte Weichen aus GoldSentinelGame (ohne Test-Flavor)
	local G = GoldSentinelGame
	return { forever = G.IsForever, tbc = G.IsTBC, modern = G.IsModern, flavor = G.flavor }
end

local function Flavor(f)
	GoldSentinelGame.SetTestFlavor(f)
	ns.Game:Refresh()
end

function R:AreaA()
	local G = GoldSentinelGame
	local Game = ns.Game
	Check("T01", "A", "alle Dateien geladen", function()
		local missing = {}
		for _, k in ipairs({ "Game", "Comm", "RMI", "Links", "Roster", "Recruit", "Prof", "Race", "Jubilee", "Attune", "Group",
			"Free", "Activity", "Promote", "Rules", "Comp", "Craft", "Poll", "Tooltip", "Social", "Board", "Events", "Cooldowns",
			"Goals", "Lead", "Bulk", "Gear", "Ask", "Chronicle", "Sync", "Test", "UI", "Donate", "MyWeek", "Health",
			"ProgressPage", "BoardPage" }) do
			if type(ns[k]) ~= "table" then missing[#missing + 1] = k end
		end
		if not (ns.L and ns.N and ns.EN) then missing[#missing + 1] = "L/N/EN" end
		local keys = {}
		for _, p in ipairs(ns.UI.pages or {}) do keys[#keys + 1] = p.key end
		for _, k in ipairs({ "home", "members", "group", "events", "poll", "board", "myweek", "progress", "prof", "recruit", "lead", "addons", "settings" }) do
			if not Has(keys, k) then missing[#missing + 1] = "Seite " .. k end
		end
		if #keys ~= 13 then missing[#missing + 1] = "Seiten " .. #keys end
		return #missing == 0, table.concat(missing, ", "), "alles vorhanden"
	end)
	Check("T02", "A", "Version .toc = Code", function()
		local v = GetMeta("GuildSentinel", "Version")
		return v == ns.version, S(v), ns.version
	end)
	Check("T03", "A", "Interface-Nummer des Clients steht in der .toc", function()
		local n = Interface()
		return Has(R.TOC_INTERFACES, n), S(n), "in .toc (" .. table.concat(R.TOC_INTERFACES, ", ") .. ")"
	end)
	Check("T04", "A", "GoldSentinelGame", function()
		local bad = {}
		if G.version ~= 2 or G.apiVersion ~= 2 then bad[#bad + 1] = "version " .. S(G.version) end
		for _, f in ipairs({ "IsSecret", "AnySecret", "Safe", "InCombat", "Short", "CleanName", "SameName", "Status", "SetTestFlavor", "Recalc" }) do
			if type(G[f]) ~= "function" then bad[#bad + 1] = f end
		end
		if (G.Status() or "") == "" then bad[#bad + 1] = "Status leer" end
		return #bad == 0, table.concat(bad, ", "), "ja"
	end)
	Check("T05", "A", "Reihenfolge der gemeinsamen Dateien", function()
		local GT = GoldSentinelTest
		local reg = GT and GT.registry and GT.registry.GuildSentinel
		local ok = GoldSentinelDev and GoldSentinelDev.version == 1 and GT and (GT.version or 0) >= 1 and reg and reg.db == GuildSentinelDB
		return ok and true or false, "Dev " .. S(GoldSentinelDev and GoldSentinelDev.version) .. ", Test " .. S(GT and GT.version) .. ", registriert " .. S(reg ~= nil), "ja"
	end)
	local real = Real()
	Check("T06", "A", "echte Weichen", function()
		local bad = {}
		if Game.FOREVER ~= G.IsForever then bad[#bad + 1] = "FOREVER" end
		if Game.TBC ~= G.IsTBC then bad[#bad + 1] = "TBC" end
		if Game.MODERN ~= G.IsModern then bad[#bad + 1] = "MODERN" end
		if Game.MODERN_PROFESSIONS ~= Game.FOREVER then bad[#bad + 1] = "MODERN_PROFESSIONS" end
		if Game.toc ~= G.toc then bad[#bad + 1] = "toc" end
		if G.IsForever and not (G.flavor == "forever" and G.IsModern and G.HasSecrets) then bad[#bad + 1] = "Forever: flavor/modern/secrets" end
		if G.IsEra and G.IsModern then bad[#bad + 1] = "Era modern" end
		if G.IsTBC and G.IsModern then bad[#bad + 1] = "TBC modern" end
		return #bad == 0, table.concat(bad, ", ") .. " (" .. S(G.flavor) .. ")", "wie GoldSentinelGame"
	end)
	Check("T07", "A", "Simulation Forever", function()
		Flavor("forever")
		local ok = Game.FOREVER and Game.MODERN and Game.MODERN_PROFESSIONS and Game.BOTH_HYBRIDS
		local p = ns.Proper("rokan steinwacht")
		local st = G.Status()
		return (ok and p == "Rokan Steinwacht" and st:find("[", 1, true)) and true or false, "Proper=" .. S(p), "Rokan Steinwacht, [Test]"
	end)
	Check("T08", "A", "Simulation Era", function()
		Flavor("era")
		local p = ns.Proper("rokan steinwacht")
		local same = ns.Same("Rokan", "Rokan Steinwacht")
		return (not Game.FOREVER and not Game.MODERN and p == "Rokansteinwacht" and same == false), "Proper=" .. S(p) .. " Same=" .. S(same), "Rokansteinwacht, false"
	end)
	Check("T09", "A", "Simulation TBC", function()
		Flavor("tbc")
		return (Game.TBC and not Game.MODERN and Game.BOTH_HYBRIDS) and true or false, "TBC=" .. S(Game.TBC) .. " MODERN=" .. S(Game.MODERN), "TBC, nicht modern"
	end)
	Skip("T09b", "A", "Simulation TBC: Inhalte", "beim Laden festgelegt, siehe D / offline 20505")
	Check("T10", "A", "Simulation Retail", function()
		Flavor("retail")
		local n, errs = OpenAllPages()
		return (Game.MODERN and not Game.FOREVER and #errs == 0) and true or false, n .. " Seiten, " .. table.concat(errs, "; "), "modern, keine Fehler"
	end)
	Check("T11", "A", "zurück auf echt", function()
		Flavor(nil)
		local st = G.Status()
		local ok = Game.FOREVER == real.forever and Game.TBC == real.tbc and Game.MODERN == real.modern and not st:find("[", 1, true)
		return ok and true or false, S(G.flavor), S(real.flavor)
	end)
	Flavor(nil)
end

------------------------------------------------------------
-- B. JEDE FUNKTION (Testmodus mit Testgilde)
------------------------------------------------------------
local function G() return ns.guild end
local function Me() return ns.Me() end
local function Printed(fn)
	-- zählt, was ns:Print in fn ausgibt (eigenes Feld, keine Blizzard-Funktion)
	local out = {}
	With({ { ns, "Print", function(_, msg) out[#out + 1] = tostring(msg) end } }, fn)
	return out
end
local function AnyHas(list, pat)
	for _, s in ipairs(list) do if s:find(pat, 1, true) then return true end end
	return false
end

function R:AreaB()
	local T, UI, Ro, So = ns.Test, ns.UI, ns.Roster, ns.Social
	Check("T12", "B", "T:Start/T:Stop", function()
		local was = T.active
		if was then T:Stop() end
		local before = { ns.guild, ns.guildKey, Ro.list, ns.Comm.users, ns.Free.list }
		T:Start()
		local okStart = ns.guildKey == "TEST" and #Ro.list == #T.members
		T:Stop()
		local after = { ns.guild, ns.guildKey, Ro.list, ns.Comm.users, ns.Free.list }
		local same = true
		for i = 1, 5 do if before[i] ~= after[i] then same = false end end
		T:Start()
		return (okStart and same) and true or false, "Start " .. S(okStart) .. ", Bezüge gleich " .. S(same), "ja"
	end)
	Check("T13", "B", "nur Entwickler", function()
		return With({ { GoldSentinelDev, "IsDev", function() return false end } }, function()
			local feat = ns.Feature("dev")
			local active = T.active
			SlashCmdList.GUILDSENTINEL("test")
			return (feat == false and T.active == active) and true or false, "Feature(dev)=" .. S(feat), "false, Testmodus unverändert"
		end)
	end)
	Check("T14", "B", "Test-Ereignisse (13)", function()
		local bad = {}
		for _, ev in ipairs(T.EVENTS) do
			local ok, err = pcall(T.Trigger, T, ev.key)
			if not ok then bad[#bad + 1] = ev.key .. ": " .. tostring(err) end
		end
		if Count(G().thanks) == 0 then bad[#bad + 1] = "thanks" end
		if not ns.Free.list.Mira then bad[#bad + 1] = "free" end
		if not (G().cds.Thalia) then bad[#bad + 1] = "cooldown" end
		return #bad == 0, table.concat(bad, "; "), "je Ereignis OK"
	end)
	Check("T15", "B", "Hauptfenster", function()
		if not UI.frame then UI:Build() end
		UI.frame:Hide()
		UI:Toggle(); local a = UI.frame:IsShown()
		UI:Toggle(); local b = UI.frame:IsShown()
		UI.frame:Show()
		local esc = Has(UISpecialFrames, "GuildSentinelFrame")
		return (a and not b and esc) and true or false, S(a) .. "/" .. S(b) .. " Esc " .. S(esc), "true/false Esc true"
	end)
	Check("T16", "B", "alle 13 Seiten", function()
		local n, errs = OpenAllPages()
		return n == 13 and #errs == 0, n .. " " .. table.concat(errs, "; "), "13 ohne Fehler"
	end)
	Check("T17", "B", "alle Reiter", function()
		local n, errs = OpenAllTabs()
		return n >= 30 and #errs == 0, n .. " " .. table.concat(errs, "; "), ">= 30 ohne Fehler"
	end)
	Check("T18", "B", "Dialoge", function()
		UI:Info("x", "y", true)
		local f = UI.infoFrame
		local ok = f and f:IsShown()
		if f then f:Hide() end
		UI:Confirm("x", function() end)
		UI:Ask("x", "", function() end)
		UI:SetEscTarget(true); local m = Has(UISpecialFrames, "GuildSentinelMenu")
		UI:SetEscTarget(false); local fr = Has(UISpecialFrames, "GuildSentinelFrame") and not Has(UISpecialFrames, "GuildSentinelMenu")
		return (ok and m and fr) and true or false, "Info " .. S(ok) .. " Esc " .. S(m) .. "/" .. S(fr), "ja"
	end)
	Check("T19", "B", "Minimap-Knopf", function()
		local was = ns.db.minimapShow
		local b = _G.GuildSentinelMinimapButton
		ns.db.minimapShow = false; UI:UpdateMinimap(); local off = b and not b:IsShown()
		ns.db.minimapShow = true; UI:UpdateMinimap(); local on = b and b:IsShown()
		ns.db.minimapShow = was; UI:UpdateMinimap()
		local r0 = RecTotal()
		ns.Recruit:Post()
		return (b and off and on and RecTotal() == r0) and true or false, "Knopf " .. S(b ~= nil) .. " aus " .. S(off) .. " an " .. S(on), "versteckt/sichtbar, Recorder 0"
	end)
	Check("T20", "B", "Spenden", function()
		local D = ns.Donate
		D.Show()
		local f = D.Frame()
		local ok = f and f:IsShown() and f.edit:GetText() == D.URL and Has(UISpecialFrames, f:GetName())
		D.Hide()
		D.Toggle(); local a = D.IsShown(); D.Toggle(); local b = D.IsShown()
		return (ok and a and not b) and true or false, "Fenster " .. S(ok) .. " Toggle " .. S(a) .. "/" .. S(b), "ja"
	end)
	Check("T21", "B", "Ohne Gilde", function()
		return With({ { ns, "InGuild", function() return false end } }, function()
			local on = {}
			for _, p in ipairs(Pages()) do if UI:PageOn(p.page) then on[#on + 1] = p.key end end
			table.sort(on)
			local s = table.concat(on, ",")
			local n, errs = OpenAllPages()
			return s == "addons,home,myweek,settings" and #errs == 0, s, "addons,home,myweek,settings"
		end)
	end)
	Check("T22", "B", "alle Unterbefehle", function()
		local bad = {}
		local dbg = ns.debug
		for _, c in ipairs({ { "gruppe", "group" }, { "group", "group" }, { "lfg", "group" }, { "termine", "events" }, { "events", "events" },
			{ "brett", "board" }, { "board", "board" }, { "wo", "members" }, { "umfrage", "poll" }, { "poll", "poll" },
			{ "fortschritt", "progress" }, { "zugang", "progress" }, { "werbung", "recruit" }, { "suche Fläschchen", "prof" } }) do
			local ok, err = pcall(SlashCmdList.GUILDSENTINEL, c[1])
			if not ok then bad[#bad + 1] = c[1] .. ": " .. tostring(err)
			elseif not UI:IsPageShown(c[2]) then bad[#bad + 1] = c[1] .. " -> nicht " .. c[2] end
		end
		for _, c in ipairs({ "", "", "regeln", "spenden", "berufe", "debug", "debug", "xyz" }) do
			local ok, err = pcall(SlashCmdList.GUILDSENTINEL, c)
			if not ok then bad[#bad + 1] = c .. ": " .. tostring(err) end
		end
		if _G.GuildSentinelRules then _G.GuildSentinelRules:Hide() end
		ns.Donate.Hide()
		if (not ns.debug) ~= (not dbg) then bad[#bad + 1] = "debug" end
		if UI.frame then UI.frame:Show() end
		return #bad == 0, table.concat(bad, "; "), "jede Seite offen"
	end)
	Check("T23", "B", "/gs danke", function()
		local p1 = Printed(function() SlashCmdList.GUILDSENTINEL("danke") end)
		local p2 = Printed(function() SlashCmdList.GUILDSENTINEL("danke Niemandda") end)
		local n0 = Count(G().thanks)
		for id, t in pairs(G().thanks) do if t.from == Me() and t.to == "Mira" then G().thanks[id] = nil end end
		n0 = Count(G().thanks)
		SlashCmdList.GUILDSENTINEL("danke Mira")
		local ok = #p1 > 0 and AnyHas(p2, (L["%s ist nicht in der Gilde."]:gsub("%%s.*", ""))) and Count(G().thanks) == n0 + 1
		return ok and true or false, "Hinweise " .. #p1 .. "/" .. #p2 .. ", Danke " .. (Count(G().thanks) - n0), "Hinweis, +1"
	end)
	Check("T24", "B", "/gs weg", function()
		SlashCmdList.GUILDSENTINEL("weg 3 Urlaub")
		local a = G().away[Me()]
		local ok1 = a and math.abs(a.u - (ns.Now() + 3 * 86400)) < 60 and a.note == "Urlaub"
		SlashCmdList.GUILDSENTINEL("weg")
		local b = G().away[Me()]
		return (ok1 and b and b.u == 0) and true or false, "u ok " .. S(ok1) .. ", danach " .. S(b and b.u), "jetzt+3 Tage, dann 0"
	end)
	Check("T25", "B", "Roster:Scan", function()
		local s0 = Ro.scans or 0
		Ro:Scan()
		local all = true
		for _, m in ipairs(T.members) do if m.name and not Ro.byName[m.name] then all = false end end
		return (#Ro.list == #T.members and all and (Ro.scans or 0) >= s0) and true or false, #Ro.list .. "/" .. #T.members, "alle"
	end)
	Check("T26", "B", "Twinks aus Notiz", function()
		local a, b, c = Ro:MainOf("Rokwar"), Ro:MainOf("Mirabank"), Ro:MainOf("Gromsham")
		local ok = a == "Rokan" and b == "Mira" and c == "Grom" and Has(Ro:AltsOf("Rokan"), "Rokwar") and not Ro:IsAlt("Rokan")
		return ok, S(a) .. "," .. S(b) .. "," .. S(c), "Rokan,Mira,Grom"
	end)
	Check("T27", "B", "SetMain/SetMyMain", function()
		local r0 = Recorded("SendAddonMessage")
		Ro:SetMain("Durok", "grom", true); local a = Ro:MainOf("Durok")
		Ro:SetMain("Durok", "", true); local b = Ro:MainOf("Durok")
		Ro:SetMyMain(Me())
		local c = G().alts[Me()] and G().alts[Me()].m
		return (a == "Grom" and b == nil and c == "" and Recorded("SendAddonMessage") == r0) and true or false, S(a) .. "," .. S(b) .. "," .. S(c), "Grom,nil,''"
	end)
	Check("T28", "B", "Verlauf", function()
		T:Kick("Neuling")
		local k1 = G().log[1] and G().log[1].k
		T:Promote("Durok")
		local k2 = G().log[1] and G().log[1].k
		return (k1 == "leave" and k2 == "promote" and #G().log <= Ro.LOG_MAX) and true or false, S(k1) .. "," .. S(k2), "leave,promote"
	end)
	Check("T29", "B", "Systemmeldungen live", function()
		if type(ERR_GUILD_JOIN_S) ~= "string" then return true, "ERR_GUILD_JOIN_S fehlt (kein Fehler)" end
		local f = ns.eventFrame:GetScript("OnEvent")
		f(ns.eventFrame, "CHAT_MSG_SYSTEM", string.format(ERR_GUILD_JOIN_S, "Testneu"))
		return True(Ro.liveJoin and Ro.liveJoin.Testneu, "liveJoin")
	end)
	Check("T30", "B", "Listen", function()
		Ro:Ranks(); Ro:Classes(); Ro:Stats()
		local names = {}
		for _, e in ipairs(Ro:Filtered({ text = "rok" })) do names[#names + 1] = e.name end
		local inact = {}
		for _, e in ipairs(Ro:Inactive(30)) do inact[#inact + 1] = e.name end
		return (Has(names, "Rokan") and Has(names, "Rokwar") and Has(inact, "Brann")) and true or false,
			table.concat(names, ",") .. " | " .. table.concat(inact, ","), "Rokan,Rokwar | Brann"
	end)
	Check("T31", "B", "Export", function()
		local M
		for _, p in ipairs(Pages()) do if p.key == "members" then M = p.page end end
		if not (M and M.ExportText) then return false, "Seite Mitglieder fehlt", "Export" end
		local txt, csv = M:ExportText(nil, false), M:ExportText("csv", false)
		local function Lines(t) local n = 0 for _ in t:gmatch("[^\n]+") do n = n + 1 end return n end
		local n = #Ro.list
		return (txt ~= "" and Lines(txt) >= n and Lines(csv) >= n) and true or false, "Zeilen " .. Lines(txt) .. "/" .. Lines(csv), ">= " .. n
	end)
	Check("T32", "B", "Abwesenheit", function()
		So:SetAway(nil, 3, "x")
		So:SetAway("Rokan", 2, "")
		local twink = So:IsAway("Rokwar")
		So:SetAway("Rokan", 0, "")
		So:SetAway(nil, 0, "")
		local blocked = Outside(function()
			return With({ { ns, "IsOfficer", function() return false end } }, function()
				local before = G().away.Ylva
				Printed(function() So:SetAway("Ylva", 2, "") end)
				return G().away.Ylva == before
			end)
		end)
		return (twink ~= nil and blocked) and true or false, "Twink " .. S(twink ~= nil) .. " gesperrt " .. S(blocked), "ja"
	end)
	Check("T33", "B", "Paten", function()
		So:SetMentor("Lowbie", "rokan")
		local m = So:MentorOf("Lowbie")
		local list = {}
		for _, x in ipairs(So:Mentees("Rokan") or {}) do list[#list + 1] = type(x) == "table" and x.name or x end
		return (m == "Rokan" and Has(list, "Lowbie")) and true or false, S(m) .. " / " .. table.concat(list, ","), "Rokan / Lowbie"
	end)
	Check("T34", "B", "Danke", function()
		for id, t in pairs(G().thanks) do if t.from == Me() and t.to == "Thalia" then G().thanks[id] = nil end end
		local n0 = Count(G().thanks)
		So:Thank("Thalia", "Hilfe")
		local n1 = Count(G().thanks)
		So:Thank("Thalia", "Hilfe")
		So:Thank(Me(), "x")
		local n2 = Count(G().thanks)
		local top = So:ThanksTop(7)
		return (n1 == n0 + 1 and n2 == n1 and top[1] ~= nil) and true or false, (n1 - n0) .. "/" .. (n2 - n1), "1/0"
	end)
	Check("T35", "B", "Gildennotiz", function()
		local s = So:NoteWithMain("", "Rokan")
		local r0 = Recorded("GuildRosterSetPublicNote")
		So:WriteNote("Rokwar")
		So:WriteAllNotes()
		local want = string.format(L["Twink von %s"], "Rokan")
		if #want > So.NOTE_MAX then want = "Alt: Rokan" end
		return (s == want and #s <= So.NOTE_MAX and Recorded("GuildRosterSetPublicNote") == r0) and true or false, S(s), "Twink-Notiz, Recorder 0"
	end)
	Check("T36", "B", "Gildenchat mit Main", function()
		local _, text = So.ChatFilter(nil, "CHAT_MSG_GUILD", "hi", "Gromsham-Test")
		local ok1 = type(text) == "string" and text:find("[Grom]", 1, true) ~= nil
		local was = ns.db.chatMain
		ns.db.chatMain = false
		local r2 = So.ChatFilter(nil, "CHAT_MSG_GUILD", "hi", "Gromsham-Test")
		ns.db.chatMain = was
		return (ok1 and r2 == false) and true or false, S(ok1), "[Grom] davor, aus -> false"
	end)
	Check("T37", "B", "'ist online' mit Main", function()
		local fmt = ERR_FRIEND_ONLINE_SS or "|Hplayer:%s|h[%s]|h has come online."
		local _, text = So.SystemFilter(nil, "CHAT_MSG_SYSTEM", string.format(fmt, "Rokwar", "Rokwar"))
		local twinkTxt = string.format(L["Twink von %s"], "Rokan")
		return (type(text) == "string" and text:find(twinkTxt, 1, true)) and true or false, S(text ~= nil), "mit Twink-Hinweis"
	end)
	Check("T38", "B", "Tooltip-Zeilen", function()
		local TT = ns.Tooltip
		local l1 = TT:Lines("Rokwar")
		local l3 = TT:Lines("Niemanddaxy")
		local added = 0
		local fake = { AddLine = function() added = added + 1 end, Show = function() end }
		TT:Add(fake, "Rokwar")
		local was = ns.db.tooltip
		ns.db.tooltip = false
		local before = added
		TT:Add(fake, "Rokwar")
		ns.db.tooltip = was
		return (l1 and l1[1] and l1[1]:find("Rokan", 1, true) and l3 == nil and before > 0 and added == before) and true or false,
			"Zeilen " .. before .. ", aus +" .. (added - before), "Rokan, >0, aus 0"
	end)
	Check("T39", "B", "Tooltip-Haken", function()
		local TT = ns.Tooltip
		local want = (TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Unit) and "tdp" or "script"
		if not TT.hooked then TT:Hook() end
		return Eq(TT.hookWay, want)
	end)
	Check("T40", "B", "Gruppensuche", function()
		local Gp = ns.Group
		local s = Gp:Post("quest", { dps = true }, 1, "x", "guild")
		local mine = Gp:Mine()
		local wire = Gp:Wire(s)
		Gp:RolesText(s); Gp:Joins(s)
		local r0 = Recorded("InviteUnit")
		Gp:Invite("Grom")
		Gp:Close(s.id, true)
		return (mine == s and type(wire) == "table" and Gp:Mine() == nil and Recorded("InviteUnit") == r0) and true or false, "Mine " .. S(mine == s), "ja"
	end)
	Check("T41", "B", "Server-Kanal im Testmodus", function()
		local was = ns.db.lfgServer
		local r0 = Recorded("JoinChannel") + Recorded("LeaveChannelByName")
		local real0 = R.real
		ns.db.lfgServer = false; ns.Group:LeaveChannel()
		ns.db.lfgServer = true; ns.Group:JoinChannel()
		ns.SetFeature("group", false); ns.SetFeature("group", true)
		ns.db.lfgServer = was
		local r1 = Recorded("JoinChannel") + Recorded("LeaveChannelByName")
		return (r1 == r0 and R.real == real0) and true or false, (r1 - r0) .. " aufgezeichnet, " .. (R.real - real0) .. " echt", "0"
	end)
	Check("T42", "B", "Wer ist frei", function()
		local Fr = ns.Free
		Fr:Set({ dungeon = true }, 2)
		local m = Fr:Mine()
		Fr:KindsText({ dungeon = true }); Fr:CountFor("dungeon")
		Fr:Clear()
		return (m ~= nil and Fr:Mine() == nil) and true or false, "Mine " .. S(m ~= nil), "gesetzt, danach nil"
	end)
	Check("T43", "B", "Termine", function()
		local E = ns.Events
		local e = E:Create("Test", "dungeon", ns.Now() + 86400, 60, "")
		if not e then return false, "nicht angelegt", "Termin" end
		local c1 = E:Counts(e)
		E:Reply(e.id, "no")
		local c2 = E:Counts(e)
		local up = E:Upcoming()
		local can = E:CanEdit(e)
		E:Cancel(e.id)
		return (c1.yes == 1 and c2.no == 1 and #up > 0 and can) and true or false, c1.yes .. "/" .. c2.no, "1/1"
	end)
	Check("T44", "B", "Zeiteingabe", function()
		local E = ns.Events
		local a, b, c, d = E:ParseWhen("", "20:00"), E:ParseWhen("morgen", "20.30"), E:ParseWhen("tomorrow", "9"), E:ParseWhen("", "25:00")
		return (a and b and c and d == nil) and true or false, S(a ~= nil) .. S(b ~= nil) .. S(c ~= nil) .. S(d), "Zeiten, nil"
	end)
	Check("T45", "B", "Termin ansagen", function()
		local E = ns.Events
		UI:Open("events")
		local Ev
		for _, p in ipairs(Pages()) do if p.key == "events" then Ev = p.page end end
		local btn = Ev and Ev.detail and Ev.detail.announce
		if not btn then return false, "Knopf fehlt", "Ansage-Knopf" end
		local e = E:Create("Ansage", "dungeon", ns.Now() + 86400, 60, "")
		if not e then return false, "nicht angelegt", "Termin" end
		local r0, real0 = Recorded("SendChatMessage"), R.real
		local out = With({ { Ev.list, "Selected", function() return e end } }, function()
			return Printed(function() btn:GetScript("OnClick")(btn) end)
		end)
		E:Cancel(e.id)
		local test = AnyHas(out, "[Test]")
		return (test and Recorded("SendChatMessage") == r0 and R.real == real0) and true or false, "[Test] " .. S(test) .. ", Recorder " .. (Recorded("SendChatMessage") - r0), "[Test], 0"
	end)
	Check("T46", "B", "Umfragen", function()
		local Po = ns.Poll
		local p = Po:Create("Frage?", { "1", "2", "3", "4", "5", "6", "7", "8", "9" }, 1)
		if not p then return false, "nicht angelegt", "Umfrage" end
		Po:Vote(p.id, 2)
		local counts, total = Po:Results(p)
		Po:OpenUnvoted()
		Po:Close(p.id)
		return (#p.o == Po.MAX_OPTIONS and counts[2] == 1 and total == 1) and true or false, #p.o .. " Optionen, Stimmen " .. S(total), Po.MAX_OPTIONS .. ", 1"
	end)
	Check("T47", "B", "Dienste", function()
		local B = ns.Board
		local bad = {}
		for _, s in ipairs(B.SERVICES or {}) do if not B:ServiceName(s.key) then bad[#bad + 1] = s.key end end
		B:SetOffer({}, "x"); B:MyOffer(); B:ClearOffer()
		return #bad == 0, table.concat(bad, ","), "alle mit Namen"
	end)
	Check("T48", "B", "Biete/Suche", function()
		local B = ns.Board
		local item, name = T:Item("cloth")
		local e = B:Post("offer", item, name, 20, 0, "")
		if not e then return false, "nicht angelegt", "Eintrag" end
		local listed = false
		for _, x in ipairs(B:List("offer")) do if x == e then listed = true end end
		local can = B:CanEdit(e)
		B:Contact(e)
		B:Remove(e.id)
		return (listed and can) and true or false, "Liste " .. S(listed), "ja"
	end)
	Check("T49", "B", "Beute-Wünsche", function()
		local Ge = ns.Gear
		local act = ns.Group.ACTIVITIES and ns.Group.ACTIVITIES[1] and ns.Group.ACTIVITIES[1].key
		local e
		for k in pairs(ns.Group.BY_KEY or {}) do if not act then act = k end end
		e = Ge:Add(14047, "Runenstoff", act)
		if not e then return false, "nicht angelegt (" .. S(act) .. ")", "Eintrag" end
		Ge:Counts(); Ge:Mine(); Ge:Done(e.id); Ge:Remove(e.id)
		return true
	end)
	Check("T50", "B", "Fragen", function()
		local Ak = ns.Ask
		local e = Ak:Create("Wer weiss?")
		if not e then return false, "nicht angelegt", "Frage" end
		Ak:Answer(e.id, "Ich")
		local ok = e.answers and e.answers[Me()] ~= nil
		Ak:OpenCount(); Ak:Remove(e.id)
		return True(ok, "Antwort")
	end)
	Check("T51", "B", "Berufe-Daten", function()
		local P = ns.Prof
		P:Of("Thalia"); P:Overview(); P:ProfNames(); P:Openable(); P:NextToOpen()
		local f = P:Find("a")
		local wk = P:WindowKind()
		local want = ns.Game.MODERN_PROFESSIONS and "modern" or "klassisch"
		return (type(f) == "table" and type(wk) == "string") and true or false, S(wk), want
	end)
	Client("T52", "B", "Berufsfenster einlesen", "Jedes eigene Berufsfenster einmal öffnen, dann /gs testroutine b: Seite Berufe zeigt die eigenen Rezepte")
	Check("T53", "B", "Herstellung", function()
		local Cr = ns.Craft
		local imp = Cr.IMPORTANT and Cr.IMPORTANT[1]
		Cr:Gaps(); Cr:MissingProfs(); Cr:WantedText()
		local r = Cr:Request(imp and imp.i or 14047, "x", 1, "")
		if r then Cr:Take(r.id); Cr:Done(r.id); Cr:Remove(r.id) end
		return (imp ~= nil and r ~= nil) and true or false, "IMPORTANT " .. S(imp ~= nil), "ja"
	end)
	Check("T54", "B", "Abklingzeiten", function()
		local Cd = ns.Cooldowns
		Cd:Mine()
		local list = Cd:List()
		local t1 = Cd:ReadyText({ isReady = true })
		local t2 = Cd:ReadyText({ ready = ns.Now() + 1800 })
		local t3 = Cd:ReadyText({ ready = ns.Now() + 5 * 3600 })
		local t4 = Cd:ReadyText({ ready = ns.Now() + 2 * 86400 })
		return (type(list) == "table" and t1 and t2 and t3 and t4) and true or false, #list .. " Einträge", "Texte"
	end)
	Check("T55", "B", "Leveling-Rennen", function()
		local list = ns.Race:Ranking(true)
		ns.Race:First60()
		return #list > 0, #list .. " Einträge", "> 0"
	end)
	Check("T56", "B", "Jubiläen", function()
		local j = ns.Jubilee:JoinDate("Rokan")
		ns.Jubilee:Due()
		return True(j ~= nil, "Beitritt")
	end)
	Check("T57", "B", "Zugänge", function()
		local A = ns.Attune
		A:Mine(); A:Scan(true)
		local rows = A:Rows(1, true)
		A:Summary(rows); A:Groups()
		return type(rows) == "table", #rows .. " Zeilen", "Tabelle"
	end)
	Check("T58", "B", "Ziele", function()
		local Go = ns.Goals
		local ws = Go:WeekStart()
		local t0 = Go:Target()
		Go:SetTarget(30)
		local t1 = Go:Target()
		Go:WeekLevels(); Go:CheckWeek(); Go:CheckMiles()
		return (ws < ns.Now() and t1 == 30) and true or false, S(t1), "30"
	end)
	Check("T59", "B", "Chronik", function()
		local Ch = ns.Chronicle
		local tl = Ch:Timeline()
		Ch:ExportText(); Ch:Achievements(); Ch:ReviewText(Ch:WeekStats(ns.Now() - 7 * 86400, ns.Now())); Ch:CheckReview()
		return #tl > 0, #tl .. " Einträge", "> 0"
	end)
	Check("T60", "B", "Aufstellung", function()
		local C = ns.Comp
		local cls = C:Classes()
		local both = Has(cls, "PALADIN") and Has(cls, "SHAMAN")
		local r0 = Recorded("SendAddonMessage")
		C:Table(); C:Missing(); C:WantedText(3); C:ShareRole()
		local role = C:Role("Grom")
		local okH = (not ns.Game.BOTH_HYBRIDS) or both
		return (okH and role == "tank" and Recorded("SendAddonMessage") == r0) and true or false, "Hybride " .. S(both) .. " Grom " .. S(role), "tank"
	end)
	Check("T61", "B", "Online-Zeiten", function()
		local A = ns.Activity
		A:Sample(); A:Grid(); A:Best(3); A:Measurements()
		return True(type(A:ActiveDays("Durok")) == "number", "ActiveDays Zahl")
	end)
	Check("T62", "B", "Beförderung", function()
		local P = ns.Promote
		P:Rule(3)
		P:Candidates()
		local r0, real0 = Recorded("GuildPromote"), R.real
		P:Promote("Durok")
		return (Recorded("GuildPromote") == r0 and R.real == real0) and true or false, "aufgezeichnet " .. (Recorded("GuildPromote") - r0), "0 (ns.Blocked)"
	end)
	Check("T63", "B", "Leitung", function()
		local Le = ns.Lead
		Le:AddNote("Durok", "Notiz")
		local notes = Le:Notes("Durok")
		local id = notes and next(notes)
		if id then Le:DeleteNote("Durok", id) end
		Le:SetProbationDays(14); Le:Probation(); Le:SuggestMentor("Neuling")
		local r0 = Recorded("GuildControlSetRank")
		Le:RankRights()
		Le:WelcomeText()
		return (id ~= nil and Recorded("GuildControlSetRank") == r0) and true or false, "Notiz " .. S(id ~= nil), "ja, Recorder 0"
	end)
	Check("T64", "B", "Sammelaktionen", function()
		local Bk = ns.Bulk
		Bk:KickCandidates(30, 3, true); Bk:PromoteCandidates()
		local r0, real0 = Recorded("GuildUninvite"), R.real
		local n0 = #T.members
		Bk:Start("kick", { "Brann" })
		Bk:Step()
		Bk:Cancel()
		Bk:GRMLoaded(); Bk:GRMPreview()
		return (Recorded("GuildUninvite") == r0 and R.real == real0 and #T.members == n0 - 1) and true or false, "Mitglieder " .. (n0 - #T.members), "1 entfernt (Test), Recorder 0"
	end)
	Check("T65", "B", "Werbung", function()
		local Rc = ns.Recruit
		local t0 = ns.db.lastAdTime
		local txt = Rc:AdText()
		Rc:EnsureTargets(); Rc:Targets(); Rc:NextTarget(); Rc:GlobalWait()
		Rc:Post()
		return (txt ~= "" and ns.db.lastAdTime == t0) and true or false, "lastAdTime gleich " .. S(ns.db.lastAdTime == t0), "true (N4)"
	end)
	Check("T66", "B", "Bewerber", function()
		local Rc = ns.Recruit
		Rc.OnWhisper("hallo gilde guild", "Wanderer99-Test", nil)
		local a = G().apps.Wanderer99
		Rc:Invite("Wanderer99"); Rc:SetStatus("Wanderer99", "new"); Rc:Remove("Wanderer99")
		return (a ~= nil and G().apps.Wanderer99 == nil) and true or false, "Bewerber " .. S(a ~= nil), "angelegt, entfernt"
	end)
	Check("T68", "B", "Begrüssung", function()
		local Rc = ns.Recruit
		return (Rc:WelcomePreview() ~= "" and Rc:ReplyPreview() ~= "") and true or false, "Vorschau", "nicht leer"
	end)
	Check("T69", "B", "Regeln", function()
		local Ru = ns.Rules
		local v0 = Ru:Current().v or 0
		Ru:Save("Regel 1")
		local v1 = Ru:Current().v or 0
		Ru:Ack(); Ru:Status()
		Ru:ShowPopup(true)
		local f = _G.GuildSentinelRules
		local shown = f and f:IsShown()
		if f then f:Hide() end
		return (v1 == v0 + 1 and Ru:Acked() and shown) and true or false, "v " .. v0 .. "->" .. v1, "+1, bestätigt, Fenster"
	end)
	Check("T70", "B", "Addons-Liste", function()
		local K = ns.Links
		K:Mine()
		local u = K:Usage()
		K:Store("Mira", { RaidMaster = string.rep("9", 30) })
		local v = G().addons.Mira and G().addons.Mira.a.RaidMaster
		return (#u == #K.LIST and v and #v == 20) and true or false, #u .. " Einträge, Länge " .. S(v and #v), #K.LIST .. ", 20"
	end)
	Check("T71", "B", "Abgleich", function()
		local Sy = ns.Sync
		Sy:Digest(); Sy:MemData()
		local r0 = Recorded("SendAddonMessage")
		Sy:Request()
		return Eq(Recorded("SendAddonMessage") - r0, 0)
	end)
	Check("T72", "B", "Meine Woche", function()
		local MW = ns.MyWeek
		MW:Scan(); MW:Chars(); MW:Prep(); MW:PrepText(); MW:PlanText()
		return true
	end)
	Check("T73", "B", "Übersicht", function()
		local i = UI:PageIndex("home")
		UI:Select(i)
		return True(UI:IsPageShown("home"), "home")
	end)
	Check("T74", "B", "jede Option einmal an/aus", function()
		local keys = { "minimapShow", "tooltip", "rulesPopup", "chatMain", "onlineMain", "annLevels", "annFirst", "annJubilee",
			"annMiles", "annReview", "lfgNotify", "lfgSound", "lfgServer", "autoReply", "welcome", "askQuestions", "adRemind", "showOffline", "showAlts" }
		local before = {}
		for _, k in ipairs(keys) do before[k] = ns.db[k] end
		for _, k in ipairs(keys) do ns.db[k] = not before[k]; ns:Fire("GS_SETTINGS") end
		for _, k in ipairs(keys) do ns.db[k] = before[k] end
		if ns.SettingsPage and ns.SettingsPage.Refresh then ns.SettingsPage:Refresh() end
		local same = true
		for _, k in ipairs(keys) do if ns.db[k] ~= before[k] then same = false end end
		return True(same, "Werte wie vorher")
	end)
	Check("T75", "B", "jede Funktion aus/an", function()
		local bad = {}
		for _, f in ipairs(ns.FEATURES) do
			local was = ns.Feature(f.key)
			ns.SetFeature(f.key, false)
			if ns.Feature(f.key) then bad[#bad + 1] = f.key .. " bleibt an" end
			ns.SetFeature(f.key, true)
			if not ns.Feature(f.key) then bad[#bad + 1] = f.key .. " bleibt aus" end
			if not was then ns.SetFeature(f.key, false) end
		end
		return #bad == 0 and #ns.FEATURES == 24, #ns.FEATURES .. " " .. table.concat(bad, ","), "24 OK"
	end)
	-- Kommunikation
	local Comm = ns.Comm
	Check("T76", "B", "Serialize/Deserialize", function()
		local v = { a = "x\t|y~^ü", n = 1.5, t = true, f = false, e = {}, sub = { 1, 2, { z = "q" } } }
		local back = Comm.Deserialize(Comm.Serialize(v))
		local ok = back and back.a == v.a and back.n == 1.5 and back.t == true and back.f == false and type(back.e) == "table" and back.sub[3].z == "q"
		local bad = Comm.Deserialize("{s1^")
		return (ok and bad == nil) and true or false, "Rundweg " .. S(ok), "gleich, kaputt -> nil"
	end)
	Check("T77", "B", "lange Pakete", function()
		local got
		return With({ { Comm.handlers, "GSTESTLONG", function(_, d) got = d end } }, function()
			local payload = "GSTESTLONG\t" .. Comm.Serialize({ x = string.rep("a", 1200) })
			local chunks, n = {}, math.ceil(#payload / 230)
			for i = 1, n do chunks[i] = "~M\tlong1\t" .. i .. "\t" .. n .. "\t" .. payload:sub((i - 1) * 230 + 1, i * 230) end
			for i = n, 1, -1 do Comm.TestOnAddon(Comm.PREFIX, chunks[i], "GUILD", "Mira-Test") end
			local ok1 = got and #got.x == 1200
			got = nil
			Comm.TestOnAddon(Comm.PREFIX, "~M\tlong2\t1\t500\tx", "GUILD", "Mira-Test")
			return (ok1 and got == nil) and true or false, "Zusammenbau " .. S(ok1), "ja, >400 verworfen"
		end)
	end)
	Check("T78", "B", "alle Nachrichtentypen ohne Fehler", function()
		local e0 = ErrMark()
		local n = 0
		for msgType in pairs(Comm.handlers) do
			if msgType ~= "GSTESTLONG" then
				n = n + 1
				Comm.TestDispatch("Mira", msgType .. "\t" .. Comm.Serialize({}), "GUILD")
			end
		end
		return ErrMark() == e0, n .. " Typen, Fehler " .. (ErrMark() - e0), "0 Fehler"
	end)
	Check("T79", "B", "Kanal-Typen", function()
		local hit
		return With({ { Comm.handlers, "THX", function() hit = true end } }, function()
			Comm.TestDispatch("Fremd", "THX\t" .. Comm.Serialize({}), "CHANNEL")
			return hit == nil, S(hit), "ignoriert"
		end)
	end)
	Check("T80", "B", "Versionen", function()
		return With({ { Comm, "users", { Mira = { v = "0.9.100" } } } }, function()
			local best, newer = Comm:NewestVersion()
			return (best == "0.9.100" and newer) and true or false, S(best), "0.9.100 neuer (Zahlenvergleich)"
		end)
	end)
	Check("T81", "B", "Ansage-Anspruch", function()
		Comm.TestDispatch("Zed", "CLM\t" .. Comm.Serialize({ k = "gstest" }), "GUILD")
		Comm.TestDispatch("Abe", "CLM\t" .. Comm.Serialize({ k = "gstest" }), "GUILD")
		local by = Comm.claims.gstest and Comm.claims.gstest.by
		Comm.claims.gstest = nil
		return Eq(by, "Abe")
	end)
	R:BankCases()
end

------------------------------------------------------------
-- Bank-Charakter: Bestand an Discord (Bank.lua; anweisung-guildsentinel-gildenbank.txt Punkt 4)
-- Taschen, Bank, Post und Gildenbank werden über ns.API nachgestellt (keine Blizzard-Funktion ersetzt).
------------------------------------------------------------
local LINK_CLOTH = "|cffffffff|Hitem:14047::::::::60:::::|h[Runenstoff]|h|r"
local LINK_POT = "|cffffffff|Hitem:13446::::::::60:::::|h[Erheblicher Heiltrank]|h|r"

-- Ersatz-Taschen: { [bag] = { { link, Anzahl }, … } }
local function FakeBags(bags, modern)
	local A = ns.API
	local list = {
		{ A, "GetItemInfo", function(link) local n = type(link) == "string" and link:match("%[(.-)%]") return n, link, 1 end },
		{ A, "GetMoney", function() return 12345 end },
	}
	local function Num(bag) return bags[bag] and #bags[bag] or 0 end
	if modern then
		list[#list + 1] = { A, "C_GetContainerNumSlots", Num }
		list[#list + 1] = { A, "C_GetContainerItemInfo", function(bag, slot)
			local x = bags[bag] and bags[bag][slot]
			if x then return { hyperlink = x[1], stackCount = x[2], iconFileID = 134 } end
		end }
	else
		-- alter Client (Classic Era/TBC ohne C_Container)
		list[#list + 1] = { A, "C_GetContainerNumSlots", nil }
		list[#list + 1] = { A, "C_GetContainerItemInfo", nil }
		list[#list + 1] = { A, "GetContainerNumSlots", Num }
		list[#list + 1] = { A, "GetContainerItemInfo", function(bag, slot)
			local x = bags[bag] and bags[bag][slot]
			if x then return 134, x[2], false, 1, false, false, x[1] end
		end }
	end
	return list
end

local function Join(a, b) local out = {} for _, x in ipairs(a) do out[#out + 1] = x end for _, x in ipairs(b or {}) do out[#out + 1] = x end return out end

-- Format wie RaidMasterDB.bank: nur diese Schlüssel, c = Summe aller w
local function BankFormatOK(b)
	if type(b) ~= "table" or type(b.c) ~= "string" or type(b.t) ~= "number" or type(b.g) ~= "number" or type(b.i) ~= "table" then return false, "Kopf" end
	for k in pairs(b) do
		if k ~= "c" and k ~= "t" and k ~= "g" and k ~= "gb" and k ~= "src" and k ~= "i" then return false, "Schlüssel " .. tostring(k) end
	end
	for id, e in pairs(b.i) do
		if type(id) ~= "number" or type(e) ~= "table" or type(e.c) ~= "number" or type(e.w) ~= "table" then return false, "Eintrag" end
		local sum = 0
		for where, n in pairs(e.w) do
			if where ~= "bag" and where ~= "bank" and where ~= "mail" and where ~= "guild" then return false, "Ort " .. tostring(where) end
			sum = sum + n
		end
		if sum ~= e.c then return false, "Summe " .. id end
	end
	return true
end

function R:BankCases()
	-- echte Daten (Bestand, Bank-Charakter-Häkchen) danach immer zurück – die Sandbox prüft das am Ende
	local oldBank, oldChars = GuildSentinelDB.bank, ns.db.bankChars
	local ok, err = pcall(R.BankChecks, R)
	GuildSentinelDB.bank, ns.db.bankChars = oldBank, oldChars
	ns.Bank.pending, ns.Bank.running, ns.Bank.bankOpen, ns.Bank.mailTold = {}, nil, false, nil
	if not ok then error(err, 0) end
end

function R:BankChecks()
	local Bk = ns.Bank
	local BAGS = { [0] = { { LINK_CLOTH, 20 }, { LINK_POT, 2 } }, [BANK_CONTAINER or -1] = { { LINK_CLOTH, 40 } } }
	local function Reset() Bk.pending = {}; Bk.running = nil; Bk.bankOpen = false; Bk.mailTold = nil end
	Check("T175", "B", "Bank-Charakter aus: nichts gelesen", function()
		local before = GuildSentinelDB.bank
		ns.db.bankChars = {}
		local r = Bk.Scan("bank", true)
		Reset()
		return (r == false and GuildSentinelDB.bank == before) and true or false, "gelesen " .. S(r), "false, .bank unverändert"
	end)
	Check("T176", "B", "Bank simuliert: Format wie RaidMaster", function()
		ns.db.bankChars = {}
		Bk.SetBankChar(true)
		GuildSentinelDB.bank = nil
		local out = Printed(function() With(FakeBags(BAGS, true), function() Bk.Scan("bank", true) end) end)
		Reset()
		local b = GuildSentinelDB.bank
		local ok, why = BankFormatOK(b)
		local cloth = b and b.i[14047]
		local told = AnyHas(out, (L["Gildenbank-Bestand gelesen: %d verschiedene Items. Er kommt mit dem nächsten Upload in den Discord."]):format(2))
		ok = ok and b.src == "bank" and b.g == 12345 and cloth and cloth.c == 60 and cloth.w.bag == 20 and cloth.w.bank == 40
			and cloth.n == "Runenstoff" and b.c == Me() and told
		return ok and true or false, S(why) .. " Stoff " .. S(cloth and cloth.c), "Format OK, 60 (20+40), Chatzeile"
	end)
	Check("T177", "B", "nur Post gelesen: Bankteil bleibt", function()
		local A = ns.API
		local mail = {
			{ A, "GetInboxNumItems", function() return 1 end },
			{ A, "GetInboxItemLink", function(i, j) if i == 1 and j == 1 then return LINK_CLOTH end end },
			{ A, "GetInboxItem", function() return "x", nil, 134, 3 end },
		}
		With(Join(FakeBags({}, true), mail), function() Bk.Scan("mail", true) end)
		Reset()
		local b = GuildSentinelDB.bank
		local cloth = b and b.i[14047]
		local ok = BankFormatOK(b) and b.src == "mail" and cloth and cloth.w.bank == 40 and cloth.w.bag == 20 and cloth.w.mail == 3 and cloth.c == 63
		return ok and true or false, "Stoff " .. S(cloth and cloth.c), "63 (Bank 40 bleibt)"
	end)
	Check("T178", "B", "im Kampf geöffnet: erst nach dem Kampf", function()
		local t0 = GuildSentinelDB.bank and GuildSentinelDB.bank.t
		GuildSentinelDB.bank.t = 1
		local r, during, after
		With(FakeBags(BAGS, true), function()
			Bk.bankOpen = true
			With({ { ns, "testCombat", true } }, function() r = Bk.Scan("bank") end)
			during = GuildSentinelDB.bank.t
			Bk.RunPending(true)
			after = GuildSentinelDB.bank.t
		end)
		Reset()
		return (r == true and during == 1 and after ~= 1 and GuildSentinelDB.bank.src == "bank") and true or false,
			"im Kampf " .. S(during == 1 and "nicht gelesen" or "gelesen") .. ", danach " .. S(after ~= 1), "nicht gelesen, danach gelesen"
	end)
	Check("T179", "B", "alter Client ohne C_Container", function()
		local e0 = ErrMark()
		With(FakeBags(BAGS, false), function() Bk.Scan("bank", true) end)
		Reset()
		local b = GuildSentinelDB.bank
		local cloth = b and b.i[14047]
		return (ErrMark() == e0 and BankFormatOK(b) and cloth and cloth.c == 63) and true or false, "Stoff " .. S(cloth and cloth.c) .. ", Fehler " .. (ErrMark() - e0), "63 (Post bleibt), 0"
	end)
	Check("T181", "B", "Gildenbank simuliert", function()
		local A = ns.API
		local gb = {
			{ A, "GetNumGuildBankTabs", function() return 2 end },
			{ A, "GetGuildBankItemLink", function(tab, slot) if tab == 2 and slot == 5 then return LINK_POT end end },
			{ A, "GetGuildBankItemInfo", function() return 135, 5 end },
			{ A, "GetGuildBankMoney", function() return 999 end },
		}
		With(Join(FakeBags({}, true), gb), function() Bk.Scan("guild", true) end)
		Reset()
		local b = GuildSentinelDB.bank
		local pot = b and b.i[13446]
		local cloth = b and b.i[14047]
		local ok = BankFormatOK(b) and b.src == "guild" and b.gb == 999 and pot and pot.w.guild == 5 and pot.w.bag == 2 and cloth and cloth.c == 63
		return ok and true or false, "Trank " .. S(pot and pot.c) .. ", Gold " .. S(b and b.gb), "7 (2+5), 999"
	end)
	Client("T180", "B", "Bank-Charakter im Spiel", "Einstellungen > Allgemein: 'Bank-Charakter' anhaken, Bank und Briefkasten öffnen, /reload: Bestand erscheint in #gildenbank (sobald Uploader und Bot aus dem RaidMaster-Auftrag fertig sind)")
end

------------------------------------------------------------
-- C. FOREVER-SONDERFÄLLE (Köderwerte statt geschützter Werte, ns.testCombat statt Kampfsperre)
------------------------------------------------------------
local function FireEvent(ev, ...)
	local f = ns.eventFrame:GetScript("OnEvent")
	f(ns.eventFrame, ev, ...)
end

-- Fälle, die früher eine Blizzard-Funktion ersetzt hätten, laufen jetzt über ns.API (API.lua) – im Spiel ohne Folgen.
-- Offiziersrechte nachstellen: nur Einträge in ns.API (IsInGuild, C_CanEditOfficerNote, CanEditOfficerNote, …)
local function OfficerWith(api)
	local A = ns.API
	local list = {}
	for _, k in ipairs({ "IsInGuild", "C_CanEditOfficerNote", "CanEditOfficerNote", "CanGuildRemove", "CanGuildPromote" }) do
		list[#list + 1] = { A, k, api[k] }
	end
	return With(list, function() return Outside(ns.IsOfficer) end)
end
local function Yes() return true end
local function No() return false end

-- C_GuildInfo.CanEditOfficerNote fehlt bzw. die alten Globals fehlen (T97b, T159)
local function OfficerFallbacks()
	local a = OfficerWith({ IsInGuild = Yes, C_CanEditOfficerNote = Yes })              -- alte Globals fehlen
	local b = OfficerWith({ IsInGuild = Yes, CanEditOfficerNote = Yes })                -- nur alter Weg
	local c = OfficerWith({ IsInGuild = Yes })                                         -- alles fehlt
	return (a == true and b == true and c == false) and true or false, S(a) .. "/" .. S(b) .. "/" .. S(c), "true/true/false"
end

-- nur Offiziersnotizen LESEN (C_GuildInfo.CanViewOfficerNote) ist kein Offizier (T166, T114)
local function ViewOnlyNotOfficer()
	local r = OfficerWith({ IsInGuild = Yes, C_CanEditOfficerNote = No, CanEditOfficerNote = No, CanGuildRemove = No, CanGuildPromote = No })
	-- Paten und Abwesenheit für andere werden dann abgelehnt (ohne ns.IsOfficer-Ersatz, echter Weg über ns.API)
	local A = ns.API
	local g = ns.guild
	local m0, a0 = g.mentor.Lowbie, g.away.Ylva
	With({ { A, "IsInGuild", Yes }, { A, "C_CanEditOfficerNote", No }, { A, "CanEditOfficerNote", No }, { A, "CanGuildRemove", No }, { A, "CanGuildPromote", No } }, function()
		Printed(function()
			Outside(function()
				ns.Social:SetMentor("Lowbie", "Grom")
				ns.Social:SetAway("Ylva", 2, "")
			end)
		end)
	end)
	local kept = g.mentor.Lowbie == m0 and g.away.Ylva == a0
	return (r == false and kept) and true or false, "Offizier " .. S(r) .. ", abgelehnt " .. S(kept), "false, true"
end

-- C_ChatInfo.SendChatMessage fehlt -> altes SendChatMessage; beide fehlen -> kein Fehler (T96b, T161)
local function ChatFallback()
	local A = ns.API
	local old = A.SendChatMessage
	local r0 = Recorded("SendChatMessage")
	ns.actLastFn = nil
	With({ { A, "C_SendChatMessage", nil } }, function() Outside(function() ns.Chat("x", "GUILD") end) end)
	local usedOld = old ~= nil and ns.actLastFn == old
	local r1 = Recorded("SendChatMessage")
	local ok2 = pcall(With, { { A, "C_SendChatMessage", nil }, { A, "SendChatMessage", nil } }, function() Outside(function() ns.Chat("x", "GUILD") end) end)
	local r2 = Recorded("SendChatMessage")
	if not old then
		return (ok2 and r2 == r1) and true or false, "kein altes SendChatMessage, Fehler " .. S(not ok2), "kein Fehler"
	end
	return (usedOld and r1 == r0 + 1 and ok2 and r2 == r1) and true or false, "alt " .. S(usedOld) .. ", ohne beide +" .. (r2 - r1), "alt true, +0"
end

function R:AreaC()
	local So, Rc, Comm = ns.Social, ns.Recruit, ns.Comm
	Check("T83", "C", "Tooltip, geschützter Name", function()
		local e0 = ErrMark()
		local added = 0
		local tip = { AddLine = function() added = added + 1 end, Show = function() end, GetUnit = function() return nil, Bait() end }
		ns.Tooltip:Add(tip, Bait())
		return (ErrMark() == e0 and added == 0) and true or false, "Zeilen " .. added, "0, kein Fehler"
	end)
	Check("T84", "C", "Addon-Nachricht, geschützte Argumente", function()
		local e0 = ErrMark()
		Comm.TestOnAddon(Bait(), "VER\t{}", "GUILD", "Mira-Test")
		Comm.TestOnAddon(Comm.PREFIX, Bait(), "GUILD", "Mira-Test")
		Comm.TestOnAddon(Comm.PREFIX, "VER\t{}", "GUILD", Bait())
		return Eq(ErrMark() - e0, 0)
	end)
	Check("T85", "C", "Flüstern im Kampf (Warteschlange)", function()
		local q0, d0 = Rc.combatQueue, Rc.combatDropped
		Rc.combatQueue, Rc.combatDropped = {}, 0
		local apps0 = Count(ns.guild.apps)
		for i = 1, 31 do FireEvent("CHAT_MSG_WHISPER", Bait(), "Wanderer" .. i .. "-Test", "", "", "", "", 0, 0, "", 0, i, "Player-x") end
		local n, dropped = #Rc.combatQueue, Rc.combatDropped
		local apps1 = Count(ns.guild.apps)
		Rc.combatQueue, Rc.combatDropped = q0, d0
		return (n == 30 and dropped == 1 and apps1 == apps0) and true or false, n .. " gemerkt, " .. dropped .. " gezählt", "30 + 1, keine Bewerbung"
	end)
	Check("T86", "C", "Abklingzeit, geschützte Spell-ID", function()
		local e0 = ErrMark()
		FireEvent("UNIT_SPELLCAST_SUCCEEDED", "player", Bait(), Bait())
		return Eq(ErrMark() - e0, 0)
	end)
	Check("T87", "C", "Gildenchat-Filter, geschützter Autor", function()
		local r = So.ChatFilter(nil, "CHAT_MSG_GUILD", "hi", Bait())
		return Eq(r, false)
	end)
	Check("T88", "C", "Gildenchat-Filter, geschützter Text (N5)", function()
		local r = So.ChatFilter(nil, "CHAT_MSG_GUILD", Bait(), "Gromsham-Test")
		return Eq(r, false)
	end)
	Check("T89", "C", "Systemfilter, geschützter Text (N5)", function()
		local e0 = ErrMark()
		local r = So.SystemFilter(nil, "CHAT_MSG_SYSTEM", Bait())
		FireEvent("CHAT_MSG_SYSTEM", Bait())
		return (r == false and ErrMark() == e0) and true or false, S(r) .. ", Fehler " .. (ErrMark() - e0), "false, 0"
	end)
	Check("T90", "C", "geschützte GUID", function()
		local q0 = Rc.combatQueue
		Rc.combatQueue = {}
		FireEvent("CHAT_MSG_WHISPER", "hallo", "Wanderer77-Test", "", "", "", "", 0, 0, "", 0, 1, Bait())
		local n = #Rc.combatQueue
		Rc.combatQueue = q0
		return Eq(n, 1)
	end)
	Check("T91", "C", "eigener Name geschützt (N6)", function()
		return With({ { ns, "Me", function() return nil end } }, function()
			local ok1 = pcall(ns.SetupGuild, ns)
			local ok2 = pcall(ns.Tooltip.Lines, ns.Tooltip, "Rokan")
			return (ok1 and ok2) and true or false, "SetupGuild " .. S(ok1), "kein Fehler"
		end)
	end)
	Check("T92", "C", "fehlendes issecretvalue (ns.API.IsSecret nil)", function()
		return With({ { ns.API, "IsSecret", nil } }, function()
			local a = ns.IsSecret("x")
			local ok1 = pcall(ns.Tooltip.Lines, ns.Tooltip, "Rokwar")
			local ok2 = pcall(So.ChatFilter, nil, "CHAT_MSG_GUILD", "hi", "Gromsham-Test")
			local ok3 = pcall(So.SystemFilter, nil, "CHAT_MSG_SYSTEM", "x")
			local ok4 = pcall(ns.Short, "Rokan-Realm")
			return (a == false and ok1 and ok2 and ok3 and ok4) and true or false, S(a) .. " " .. S(ok1 and ok2 and ok3 and ok4), "false, kein Fehler"
		end)
	end)
	Check("T93", "C", "Zaubernamen", function()
		local fn = (C_Spell and C_Spell.GetSpellName) or GetSpellInfo
		return True(fn ~= nil, "Zaubername-API")
	end)
	Check("T93b", "C", "GetSpellInfo nil (über ns.API)", function()
		local A = ns.API
		local modern = A.C_GetSpellName ~= nil
		local ok1, n1 = pcall(With, { { A, "GetSpellInfo", nil } }, function() return ns.SpellName(2259) end)
		local ok2, n2 = pcall(With, { { A, "GetSpellInfo", nil }, { A, "C_GetSpellName", nil } }, function() return ns.SpellName(2259) end)
		local ok = ok1 and ok2 and n2 == nil and (not modern or n1 ~= nil)
		return ok and true or false, "C_Spell " .. S(modern) .. ": " .. S(n1 ~= nil) .. ", beide nil: " .. S(n2), (modern and "Name" or "nil") .. ", nil"
	end)
	Check("T94", "C", "Item aus Taschen", function() return NoErr(ns.FindItemID, "Runenstoff") end)
	Check("T95", "C", "beim Laden gebundene Ersatzwege", function()
		local bad = {}
		local function want(have, modern, old, name) if have ~= (modern or old) then bad[#bad + 1] = name end end
		want(ns.GetItemInfo, C_Item and C_Item.GetItemInfo, GetItemInfo, "GetItemInfo")
		want(ns.RegisterPrefix, C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix, RegisterAddonMessagePrefix, "RegisterPrefix")
		want(ns.GuildRoster, C_GuildInfo and C_GuildInfo.GuildRoster, GuildRoster, "GuildRoster")
		if not ns.SendAddonMessage then bad[#bad + 1] = "SendAddonMessage" end
		return #bad == 0, table.concat(bad, ","), "moderner Weg zuerst"
	end)
	Check("T96", "C", "ns.Chat geht über ns.Act", function()
		local r0 = Recorded("SendChatMessage")
		Outside(function() ns.Chat("x", "GUILD") end)
		return Eq(Recorded("SendChatMessage") - r0, 1)
	end)
	Check("T96b", "C", "SendChatMessage-Rückfall (über ns.API)", ChatFallback)
	Check("T97", "C", "Offiziersrechte (echter Weg)", function()
		return NoErr(function() Outside(ns.IsOfficer) end)
	end)
	Check("T97b", "C", "Offiziers-Globals nil (über ns.API)", OfficerFallbacks)
	Check("T98", "C", "KnowsSpell", function()
		return With({ { ns.Links, "ext", { BuffSentinel = false } } }, function() return NoErr(ns.Links.KnowsSpell, ns.Links, 1) end)
	end)
	Check("T99", "C", "Quest-Global nil (über ns.API)", function()
		local A = ns.API
		local ok1, a = pcall(With, { { A, "IsQuestFlaggedCompleted", nil } }, function() return ns.QuestDone(1) end)
		local ok2, b = pcall(With, { { A, "IsQuestFlaggedCompleted", nil }, { A, "C_IsQuestFlaggedCompleted", nil } }, function() return ns.QuestDone(1) end)
		local ok3 = pcall(With, { { A, "IsQuestFlaggedCompleted", nil } }, function() ns.Attune:Scan(true) end)
		return (ok1 and ok2 and ok3 and type(a) == "boolean" and b == false) and true or false, S(a) .. "/" .. S(b), "true|false / false"
	end)
	Check("T100", "C", "Flüsterfenster über ns.Act", function()
		local r0 = Recorded("ChatFrame_SendTell") + Recorded("ChatFrame_OpenChat")
		Outside(function() ns.OpenWhisper("Rokan Steinwacht", "x") end)
		return Eq(Recorded("ChatFrame_SendTell") + Recorded("ChatFrame_OpenChat") - r0, 1)
	end)
	Check("T101", "C", "Chatfilter-Haken / Kanal ausblenden", function()
		return NoErr(function() ns.Group:HideChannel(); So:HookChat() end)
	end)
	Check("T102", "C", "Berufs-Weg passt zum Client", function()
		return NoErr(ns.Prof.WindowKind, ns.Prof)
	end)
	Check("T103", "C", "Meine Woche ohne Fehler", function() return NoErr(ns.MyWeek.Scan, ns.MyWeek) end)
	Check("T104", "C", "Addon-Metadaten", function()
		local ok = NoErr(function() ns.Links:Loaded("GibtEsNicht"); ns.Links:Version("GibtEsNicht") end)
		return ok and ns.Links:Loaded("GibtEsNicht") == false, "false", "false ohne Fehler"
	end)
	Check("T105", "C", "Kampfsperre (simuliert)", function()
		local P = ns.ProfPage
		local res
		With({ { ns, "testCombat", true } }, function()
			local added = 0
			local fake = { AddLine = function() added = added + 1 end, Show = function() end,
				GetUnit = function() return "Rokwar", "mouseover" end }
			local wasModern = ns.Game.MODERN
			ns.Game.MODERN = true
			-- OnUnit wird über den echten Haken nicht erreicht; Kampfsperre steht vor jedem Zugriff
			local rulesShown
			local f = _G.GuildSentinelRules
			if f then f:Hide() end
			ns.Rules:ShowPopup(false)
			rulesShown = _G.GuildSentinelRules and _G.GuildSentinelRules:IsShown()
			local started = R:Start("", true)
			ns.Game.MODERN = wasModern
			res = { not rulesShown, started == false }
		end)
		return (res[1] and res[2]) and true or false, "Regeln zu " .. S(res[1]) .. ", Start abgelehnt " .. S(res[2]), "ja"
	end)
	Client("T106", "C", "echte Kampfsperre", "Berufe-Seite offen, Kampf beginnen: kein ADDON_ACTION_BLOCKED für GuildSentinel, nach dem Kampf ist der Knopf wieder da")
	Check("T107", "C", "Kampflog nicht benutzt", function()
		return Eq(ns.eventFrame:IsEventRegistered("COMBAT_LOG_EVENT_UNFILTERED") and true or false, false)
	end)
end

------------------------------------------------------------
-- D. ALTE CLIENTS
------------------------------------------------------------
function R:AreaD()
	local G = GoldSentinelGame
	local old = G.IsEra or G.IsTBC
	if not old then
		for _, id in ipairs({ "T108", "T109", "T110", "T111", "T112", "T114" }) do Skip(id, "D", "alter Client", "nicht dieser Client") end
		Skip("T113", "D", "Berufe klassisch", "nicht dieser Client")
		return
	end
	Skip("T108", "D", "Bereich B auf altem Weg", "siehe Bereich B in diesem Bericht (läuft ohne Simulation)")
	Check("T109", "D", "Namen alt", function()
		local p = ns.Proper("aRTHAS-Realm")
		return (p == "Arthas" and ns.Same("Rokan", "Rokan Steinwacht") == false) and true or false, S(p), "Arthas"
	end)
	Check("T110", "D", "Flüstern alt", function()
		local r0 = Recorded("ChatFrame_OpenChat")
		Outside(function() ns.OpenWhisper("Andreas", "Hallo!") end)
		return Eq(Recorded("ChatFrame_OpenChat") - r0, 1)
	end)
	Check("T111", "D", "Tooltip alt", function()
		local want = TooltipDataProcessor and "tdp" or "script"
		return Eq(ns.Tooltip.hookWay, want)
	end)
	Check("T112", "D", "Inhalte", function()
		local Game = ns.Game
		if G.IsTBC then
			return (Game.MAX_LEVEL == 70 and Game.RAID_SIZE == 25) and true or false, Game.MAX_LEVEL .. "/" .. Game.RAID_SIZE, "70/25"
		end
		return (Game.MAX_LEVEL == 60 and Game.RAID_SIZE == 40 and #ns.Cooldowns.LIST == 3) and true or false,
			Game.MAX_LEVEL .. "/" .. Game.RAID_SIZE .. "/" .. #ns.Cooldowns.LIST, "60/40/3"
	end)
	Client("T113", "D", "Berufe klassisch", "TradeSkillFrame (Era: auch Verzauberkunst über CraftFrame) öffnen: Seite Berufe gefüllt, Diagnose 'klassisch'")
	Check("T114", "D", "Offizier alt (Regression K1)", ViewOnlyNotOfficer)
end

------------------------------------------------------------
-- E. DATEN
------------------------------------------------------------
function R:AreaE()
	Check("T116", "E", "neue Gilde", function()
		local g = {}
		ns.MergeDefaults(g, ns.guildDefaults)
		local bad = {}
		for k in pairs(ns.guildDefaults) do if type(g[k]) ~= "table" then bad[#bad + 1] = k end end
		local r = g.rules
		if not (r.v and r.t and r.text and r.by) then bad[#bad + 1] = "rules" end
		return #bad == 0, Count(g) .. " Schlüssel " .. table.concat(bad, ","), "alle Tabellen"
	end)
	Check("T118", "E", "beschädigte Gildendaten", function()
		local g = ns.guild
		g.alts.Xbad = 5; g.away.Ybad = "x"; g.thanks.zbad = { from = nil }; g.events.bad = { t = "abc" }
		g.roster.Zbad = true; g.prof.Wbad = { p = 7 }; g.cds.Vbad = { k = "x" }; g.levels.Ubad = false
		g.polls.pbad = { o = nil }; g.market.mbad = { i = "x" }; g.mentor.Mbad = 1
		local ok0, n, errs = pcall(OpenAllPages)
		local ok1, m, errs2 = pcall(OpenAllTabs)
		local e0 = ErrMark()
		ns:Fire("GS_EVENTS"); ns:Fire("GS_POLL"); ns:Fire("GS_SOCIAL"); ns:Fire("GS_ROSTER"); ns:Fire("GS_BOARD")
		local fired = ErrMark() - e0
		if not ok0 then errs = { tostring(n) } end
		if not ok1 then errs2 = { tostring(m) } end
		for _, k in ipairs({ "alts", "away", "thanks", "roster", "prof", "cds", "levels", "polls", "market", "mentor" }) do
			for key in pairs(g[k]) do if type(key) == "string" and key:find("bad$") then g[k][key] = nil end end
		end
		g.events.bad = nil
		local all = {}
		for _, e in ipairs(errs) do all[#all + 1] = e end
		for _, e in ipairs(errs2) do all[#all + 1] = e end
		for i = 1, math.min(fired, 3) do all[#all + 1] = ns.errors.last[i].wo .. ": " .. ns.errors.last[i].msg end
		return #all == 0, table.concat(all, "; "), "0 Fehler"
	end)
	Check("T120", "E", "beschädigte Pakete", function()
		local Comm = ns.Comm
		local e0 = ErrMark()
		for msgType in pairs(Comm.handlers) do
			for _, d in ipairs({ { e = 5, n = {}, id = 7, t = "x", k = 1 }, { e = { x = 5 }, o = "x", v = {} } }) do
				Comm.TestDispatch("Mira", msgType .. "\t" .. Comm.Serialize(d), "GUILD")
			end
		end
		local list = {}
		for i = 1, math.min(ErrMark() - e0, 10) do list[#list + 1] = ns.errors.last[i].wo .. ": " .. ns.errors.last[i].msg end
		return ErrMark() == e0, (ErrMark() - e0) .. " " .. table.concat(list, " | "), "0"
	end)
	Check("T121", "E", "Grenzen", function()
		for i = 1, 450 do ns.Roster:Log("join", "Testlog" .. i) end
		local n = #ns.guild.log
		ns.Social:SetAway(nil, 1, string.rep("x", 120))
		local note = ns.guild.away[ns.Me()] and ns.guild.away[ns.Me()].note
		ns.Social:SetAway(nil, 0, "")
		return (n <= 400 and note and #note <= 80) and true or false, n .. " Log, Notiz " .. S(note and #note), "<=400, <=80"
	end)
	Skip("T115", "E", "Neuinstallation", "würde GuildSentinelDB neu anlegen; offline: jeder Lauf in test/ startet ohne GuildSentinelDB")
	Skip("T117", "E", "Migration", "offline in test/run_nilglobals.lua (Altlasten) und run_lang.lua (alte Spracheinstellung)")
	Skip("T119", "E", "beschädigte Einstellungen", "offline in test/run_nilglobals.lua")
end

------------------------------------------------------------
-- F. SPRACHEN
------------------------------------------------------------
local function Specs(s)
	local out = {}
	for x in tostring(s):gmatch("%%[-+#0-9.]*[sdifxXc%%]") do out[#out + 1] = x end
	return table.concat(out, " ")
end

function R:AreaF()
	local MAP = { deDE = "de", enUS = "en", enGB = "en" }
	local loc = GetLocale()
	Check("T122", "F", "Sprache wie Client (bzw. gewählt)", function()
		local chosen = ns.db.uiLang
		if chosen and ns.LangAvailable(chosen) then return Eq(ns.lang, chosen) end
		return Eq(ns.lang, MAP[loc] or loc)
	end)
	local tl = ns.T and ns.T[ns.lang]
	if ns.lang ~= "de" and ns.lang ~= "en" and tl then
		Check("T123", "F", "alle Schlüssel vorhanden", function()
			local miss = 0
			for k in pairs(ns.EN) do if not tl[k] then miss = miss + 1 end end
			return Eq(miss, 0)
		end)
	else
		Skip("T123", "F", "alle Schlüssel vorhanden", "Client-Sprache ist " .. S(ns.lang) .. " (Schlüssel bzw. Locales.lua)")
	end
	Check("T124", "F", "Formatplatzhalter", function()
		local bad = 0
		local first
		for k, v in pairs(ns.EN) do
			if not k:find("%%[dmYHM]") or k:find("%%d") then
				if Specs(k) ~= Specs(v) and not k:find("%%[mYHM]") then bad = bad + 1; first = first or k:sub(1, 40) end
			end
			if tl and tl[k] and Specs(tl[k]) ~= Specs(k) and not k:find("%%[mYHM]") then bad = bad + 1; first = first or k:sub(1, 40) end
		end
		return bad == 0, bad .. " " .. S(first), "0 Abweichungen"
	end)
	Check("T125", "F", "Sprache umschalten", function()
		local was = ns.lang
		local errs = {}
		for _, l in ipairs({ "de", "en", was }) do
			ns.lang = l
			local _, e = OpenAllPages()
			for _, x in ipairs(e) do errs[#errs + 1] = l .. ":" .. x end
		end
		ns.ApplyLang()
		return #errs == 0, table.concat(errs, "; "), "ohne Fehler"
	end)
	Check("T126", "F", "Merk-Schlüssel (N[...])", function()
		local miss = {}
		local function need(k) if k and not ns.EN[k] then miss[#miss + 1] = k end end
		for _, f in ipairs(ns.FEATURES) do need(f.n); need(f.d) end
		for _, e in ipairs(ns.Test.EVENTS) do need(e.n) end
		for _, s in ipairs(ns.Board.SERVICES or {}) do need(s.n) end
		for _, c in ipairs(ns.Cooldowns.LIST or {}) do need(c.n) end
		return #miss == 0, table.concat(miss, ", "), "alle in Locales.lua"
	end)
	-- seit 0.9.13 sind die Sprachen mit lateinischer Schrift immer geladen (wählbar), die übrigen nur für ihren Client
	Check("T127", "F", "übrige geladene Sprachen vollständig", function()
		local bad = {}
		for l, t in pairs(ns.T or {}) do
			local miss = 0
			for k in pairs(ns.EN) do if not t[k] then miss = miss + 1 end end
			if miss > 0 then bad[#bad + 1] = l .. " " .. miss end
		end
		local n = 0
		for _ in pairs(ns.T or {}) do n = n + 1 end
		return #bad == 0, n .. " Sprachen, fehlend: " .. (#bad > 0 and table.concat(bad, ", ") or "0"), "0 fehlend"
	end)
end

------------------------------------------------------------
-- G. ZUSAMMENSPIEL
------------------------------------------------------------
function R:AreaG()
	local K = ns.Links
	Check("T128", "G", "mehrere GoldSentinel-Addons", function()
		local list = {}
		for _, a in ipairs(K.LIST) do
			local v = K:Version(a.key)
			if v then list[#list + 1] = a.key .. " " .. v end
		end
		return (GoldSentinelGame.version == 2 and GoldSentinelDev.version == 1 and GoldSentinelTest) and true or false,
			#list > 0 and table.concat(list, ", ") or "keine weiteren", "Versionen 2/1"
	end)
	Check("T129", "G", "keine globalen Namen überschrieben", function()
		local ok = type(SlashCmdList.GUILDSENTINEL) == "function" and SLASH_GUILDSENTINEL1 == "/gs"
		return True(ok, "/gs")
	end)
	Check("T130", "G", "RaidMaster da / nicht da", function()
		local act = ns.RMI:Active()
		return Eq(act, false)  -- im Testmodus nie aktiv
	end)
	Check("T131", "G", "AH-Preise", function()
		local fake = { GetMarketValue = function() return 12345 end }
		local bad = { GetMarketValue = function() error("x") end }
		local a = With({ { K, "ext", { AHAnalyzerPro = fake } } }, function() return K:MarketValue(14047) end)
		local b = With({ { K, "ext", { AHAnalyzerPro = bad } } }, function() return K:MarketValue(14047) end)
		local c = With({ { K, "ext", { AHAnalyzerPro = false } } }, function() return K:MarketValue(14047) end)
		return (a == 12345 and b == nil and c == nil) and true or false, S(a) .. "," .. S(b) .. "," .. S(c), "12345,nil,nil"
	end)
	Check("T132", "G", "AH-Addon unter Ordner AHSentinel erkannt (N7)", function()
		local a = With({ { K, "ext", { loaded = { AHSentinel = true } } } }, function() return K:Loaded("AHAnalyzerPro") end)
		local b = With({ { K, "ext", { loaded = { AHAnalyzerPro = true } } } }, function() return K:Loaded("AHAnalyzerPro") end)
		return (a and b) and true or false, S(a) .. "," .. S(b), "true,true"
	end)
	Check("T133", "G", "BuffSentinel", function()
		local a = With({ { K, "ext", { BuffSentinel = { KnowsSpellID = function() return true end } } } }, function() return K:KnowsSpell(1) end)
		local b = With({ { K, "ext", { BuffSentinel = { KnowsSpellID = function() error("x") end } } } }, function() return K:KnowsSpell(1) end)
		return (a == true and type(b) == "boolean") and true or false, S(a) .. "," .. S(b), "true, Rückfall"
	end)
	Check("T134", "G", "ThreatSentinel", function()
		local key = (UnitName("player") or "?") .. " - " .. (GetRealmName and GetRealmName() or "?")
		local db = { profiles = { [key] = { myRole = "HEALER" } } }
		local a = With({ { K, "ext", { ThreatSentinelDB = db, loaded = { ThreatSentinel = true } } } }, function() return K:ThreatRole() end)
		local b = With({ { K, "ext", { ThreatSentinelDB = false, loaded = { ThreatSentinel = false } } } }, function() return K:ThreatRole() end)
		return (a == "heal" and b == nil) and true or false, S(a) .. "," .. S(b), "heal,nil"
	end)
	Check("T135", "G", "LevelPilot", function()
		local lp = { Social = { MyEliteQuests = function() return { 123 } end } }
		local a = With({ { K, "ext", { LevelPilot = lp } } }, function() return K:EliteQuests() end)
		local b = With({ { K, "ext", { LevelPilot = false } } }, function() return K:EliteQuests() end)
		return (#a == 1 and #b == 0) and true or false, #a .. "," .. #b, "1,0"
	end)
	Client("T136", "G", "Guild Roster Manager", "mit installiertem GRM: Leitung > GRM-Import zeigt Zahlen; ohne: kein Fehler")
	Skip("T137", "G", "ProfessionSentinel", "GuildSentinel nutzt keine Schnittstelle von ProfessionSentinel")
end

------------------------------------------------------------
-- H. LEISTUNG
------------------------------------------------------------
local function Time(fn, n)
	n = n or 1
	local t = Ms()
	for _ = 1, n do fn() end
	return (Ms() - t) / n
end

function R:AreaH()
	local T = ns.Test
	Check("T138", "H", "Roster:Scan mit 500 Mitgliedern", function()
		local add = {}
		for i = 1, 500 - #T.members do
			local m = { name = "Perf" .. i, class = "MAGE", level = 30, ri = 4, zone = "", online = false, off = 86400, note = (i % 3 == 0) and "Twink von Rokan" or "" }
			T.members[#T.members + 1] = m
			add[#add + 1] = m
		end
		local ms = Time(function() ns.Roster:Scan() end)
		R.big = true
		return ms < 16, string.format("%.1f ms", ms), "< 16 ms"
	end)
	Check("T139", "H", "Tooltip", function()
		local ms = Time(function() ns.Tooltip:Lines("Rokwar") end, 50)
		return ms < 2, string.format("%.2f ms", ms), "< 2 ms"
	end)
	Check("T140", "H", "Chatfilter", function()
		local ms = Time(function() ns.Social.ChatFilter(nil, "CHAT_MSG_GUILD", "hi", "Gromsham-Test"); ns.Social.SystemFilter(nil, "CHAT_MSG_SYSTEM", "x") end, 200)
		return ms < 2, string.format("%.3f ms", ms), "< 2 ms"
	end)
	Check("T141", "H", "Pakete", function()
		local v = { x = string.rep("a", 2000) }
		local ms = Time(function() ns.Comm.Deserialize(ns.Comm.Serialize(v)) end, 10)
		return ms < 2, string.format("%.2f ms", ms), "< 2 ms"
	end)
	Check("T142", "H", "Ticker-Arbeit", function()
		local ms = 0
		for _, fn in ipairs({ function() ns.Events:CheckReminders() end, function() ns.Activity:Sample() end,
			function() ns.Lead:SampleHours() end, function() ns.Recruit:Due() end, function() ns.Jubilee:Check() end }) do
			local t = Time(fn)
			if t > ms then ms = t end
		end
		return ms < 2, string.format("%.2f ms (höchster)", ms), "< 2 ms"
	end)
	Check("T143", "H", "Seiten mit 500 Mitgliedern", function()
		local worst, which = 0, "-"
		for _, p in ipairs(Pages()) do
			if ns.UI:PageOn(p.page) then
				local t = Time(function() ns.UI:Select(p.i) end)
				if t > worst then worst, which = t, p.key end
			end
		end
		return worst < 16, string.format("%.1f ms (langsamste: %s)", worst, which), "< 16 ms"
	end)
	Check("T144", "H", "Abgleich", function()
		local ms = Time(function() ns.Sync:Digest() end)
		return ms < 16, string.format("%.1f ms", ms), "< 16 ms"
	end)
	-- Testgilde wieder auf normale Grösse
	local keep = {}
	for _, m in ipairs(T.members) do if not tostring(m.name):find("^Perf%d") then keep[#keep + 1] = m end end
	T.members = keep
	ns.Roster:Scan()
	Skip("T145", "H", "Speicher", "Messung im Bericht unten (collectgarbage vor/nach)")
end

------------------------------------------------------------
-- I. FEHLERZÄHLUNG UND DIAGNOSE
------------------------------------------------------------
local function DropSelfTestErrors()
	local s = GuildSentinelDB and GuildSentinelDB.gsTest
	if s and type(s.errors) == "table" then
		for k, e in pairs(s.errors) do
			if type(e) == "table" and tostring(e.msg):find("GS-Selbsttest", 1, true) then s.errors[k] = nil end
		end
	end
end

function R:AreaI()
	Check("T146", "I", "Fehler in internem Ereignis", function()
		local e0 = ErrMark()
		-- nur einmal je Sitzung anmelden (sonst zählt ein zweiter Lauf jeden Fehler doppelt)
		if not R.selfListen then
			R.selfListen = true
			ns:Listen("GS_SELFTEST_ERR", function() if R.selfErr then error("GS-Selbsttest") end end)
		end
		R.selfErr = true
		ns:Fire("GS_SELFTEST_ERR")
		R.selfErr = false
		local last = ns.errors.last[1]
		local s = GuildSentinelDB.gsTest
		local inGT = false
		for _, e in pairs(s and s.errors or {}) do if type(e) == "table" and e.wo == "GS_SELFTEST_ERR" then inGT = true end end
		DropSelfTestErrors()
		return (ErrMark() == e0 + 1 and last and last.msg:find("GS-Selbsttest", 1, true) and inGT) and true or false,
			"+" .. (ErrMark() - e0) .. " GT " .. S(inGT), "+1, gemeldet"
	end)
	Check("T147", "I", "Fehler in Spiel-Ereignis und Paket", function()
		local e0 = ErrMark()
		if not R.selfOn then
			R.selfOn = true
			ns:On("GS_SELFTEST_EVT", function() if R.selfErr then error("GS-Selbsttest") end end)
		end
		R.selfErr = true
		FireEvent("GS_SELFTEST_EVT")
		With({ { ns.Comm.handlers, "GSSELF", function() error("GS-Selbsttest") end } }, function()
			ns.Comm.TestDispatch("Mira", "GSSELF\t{}", "GUILD")
		end)
		R.selfErr = false
		DropSelfTestErrors()
		return Eq(ErrMark() - e0, 2)
	end)
	Check("T148", "I", "Diagnose zeigt Fehler", function()
		local txt = ns.SettingsPage and ns.SettingsPage:DiagText() or ""
		return (txt:find(string.format(L["Fehler: %d"], ns.errors.n), 1, true) and txt:find(GoldSentinelGame.Status(), 1, true)) and true or false, "Diagnose", "mit Status und Fehlerzahl"
	end)
	Check("T174", "I", "Aktionen mit Folgen nur über ns.Act", function()
		-- jede Aktion mit Folgen ausserhalb des Testmodus auslösen: ns.Act muss sie mitschreiben, echt geht nichts hinaus
		-- (echte Aufrufe zählt hooksecurefunc; ein direkter Aufruf an ns.Act vorbei wäre hier ein FEHLER)
		local real0 = R.real
		local list = {
			{ "SendChatMessage", function() ns.Chat("x", "GUILD") end },
			{ "InviteUnit", function() ns.InviteParty("Rokan") end },
			{ "ChatFrame_OpenChat", function() ns.OpenWhisper("Rokan", "x") end },
			{ "GuildInvite", function() ns.Recruit:Invite("Wanderer98") end },
			{ "GuildPromote", function() ns.Promote:Promote("Durok") end },
		}
		local missing = {}
		With({ { ns, "CanInvite", Yes }, { ns, "CanPromote", Yes } }, function()
			for _, x in ipairs(list) do
				local r0 = Recorded(x[1])
				Outside(x[2])
				if Recorded(x[1]) ~= r0 + 1 then missing[#missing + 1] = x[1] end
			end
		end)
		local g = ns.guild
		if g and g.apps then g.apps.Wanderer98 = nil end
		local by = {}
		for k, v in pairs(R.realBy) do by[#by + 1] = k .. " " .. v end
		return (#missing == 0 and R.real == real0) and true or false,
			"nicht über ns.Act: " .. (#missing > 0 and table.concat(missing, ",") or "-") .. ", echt " .. (R.real - real0) .. (#by > 0 and (" (" .. table.concat(by, ", ") .. ")") or ""), "alle über ns.Act, echt 0"
	end)
	Check("T149", "I", "Fehler-Abgriff aktiv", function()
		local ok = GoldSentinelTest.registry.GuildSentinel ~= nil and (_G.GoldSentinelTestHooked == true or _G.GoldSentinelTestBG ~= nil)
		return True(ok, "registriert")
	end)
end

------------------------------------------------------------
-- J. REGRESSIONSTESTS
------------------------------------------------------------
local function MiniRoster(names, fn)
	local list, by = {}, {}
	for _, n in ipairs(names) do local e = { name = n, class = "MAGE", level = 60, ri = 3, note = "" }; list[#list + 1] = e; by[n] = e end
	return With({ { ns.Roster, "list", list }, { ns.Roster, "byName", by } }, fn)
end

function R:AreaJ()
	local So = ns.Social
	Check("T150", "J", "P1: Tooltip mit geschütztem Namen", function()
		Flavor("forever")
		local e0 = ErrMark()
		local ok = pcall(ns.Tooltip.Add, ns.Tooltip, { AddLine = function() end, Show = function() end }, Bait())
		Flavor(nil)
		return (ok and ErrMark() == e0) and true or false, S(ok), "kein Fehler"
	end)
	Check("T151", "J", "P2: ns.Proper Vor- und Nachname", function()
		Flavor("forever")
		local a, b = ns.Proper("rokan steinwacht"), ns.Proper("Rokan Steinwacht-WoWForever")
		Flavor(nil)
		return (a == "Rokan Steinwacht" and b == "Rokan Steinwacht") and true or false, S(a) .. "|" .. S(b), "Rokan Steinwacht"
	end)
	Check("T152", "J", "P2: Notiz mit zwei Wörtern", function()
		Flavor("forever")
		local r = MiniRoster({ "Rokan Steinwacht", "Mira Sonnenkind", "Mira Dunkelfeder", "Kurztwink" }, function()
			local Ro = ns.Roster
			return { Ro:MainFromNote("Kurztwink", "Twink von Rokan Steinwacht"), Ro:MainFromNote("Kurztwink", "alt of rokan steinwacht"),
				Ro:MainFromNote("Kurztwink", "Main: Rokan Steinwacht"), Ro:MainFromNote("Kurztwink", "Twink von Rokan"),
				Ro:MainFromNote("Kurztwink", "Twink von Mira"),
				-- Kennzeichnung in der Client-Sprache (koKR/zhCN/zhTW: Name davor), wie GuildSentinel sie schreibt
				Ro:MainFromNote("Kurztwink", string.format(L["Twink von %s"], "Rokan Steinwacht")) }
		end)
		Flavor(nil)
		local ok = r[1] == "Rokan Steinwacht" and r[2] == "Rokan Steinwacht" and r[3] == "Rokan Steinwacht" and r[4] == "Rokan Steinwacht" and r[5] == nil
			and r[6] == "Rokan Steinwacht"
		return ok, S(r[1]) .. "|" .. S(r[4]) .. "|" .. S(r[5]) .. "|" .. S(r[6]), "Rokan Steinwacht ×4, nil, Rokan Steinwacht"
	end)
	Check("T153", "J", "P2: ns.Same Vorname", function()
		Flavor("forever")
		local r = MiniRoster({ "Rokan Steinwacht", "Mira Sonnenkind", "Mira Dunkelfeder" }, function()
			return { ns.Same("Rokan", "Rokan Steinwacht"), ns.Same("Mira", "Mira Sonnenkind"), ns.Same("Rokan Steinwacht", "Rokan Felsbart") }
		end)
		Flavor("era")
		local e = ns.Same("Rokan", "Rokan Steinwacht")
		Flavor(nil)
		return (r[1] == true and r[2] == false and r[3] == false and e == false) and true or false, S(r[1]) .. S(r[2]) .. S(r[3]) .. S(e), "true false false false"
	end)
	Check("T154", "J", "P2: Twink/Main, Danke, Pate mit Vor- und Nachname", function()
		Flavor("forever")
		local g = ns.guild
		-- unabhängig von den Einstellungen des Spielers (Funktion "Danke" aus?) und von schon vorhandenem Dank heute
		-- (Launch-Bericht 0.9.13: im echten Client kam kein Dank zustande); was GuildSentinel ausgibt, steht im Ergebnis
		local r = With({ { ns, "Feature", function() return true end }, { g, "thanks", {} }, { g, "alts", {} }, { g, "mentor", {} } }, function()
		return MiniRoster({ "Rokan Steinwacht", "Kurztwink", "Mira Sonnenkind" }, function()
			local out = {}
			out.said = Printed(function()
				ns.Roster:SetMain("Kurztwink", "rokan", true)
				out.main = ns.Roster:MainOf("Kurztwink")
				local n0 = Count(g.thanks)
				So:Thank("rokan steinwacht", "x")
				for id, t in pairs(g.thanks) do
					if t.to == "Rokan Steinwacht" and t.why == "x" then out.thx = t.to; g.thanks[id] = nil end
				end
				out.n = Count(g.thanks) - n0
				So:SetMentor("Mira Sonnenkind", "Rokan")
				out.mentor = So:MentorOf("Mira Sonnenkind")
			end)
			return out
		end)
		end)
		Flavor(nil)
		local ok = r.main == "Rokan Steinwacht" and r.thx == "Rokan Steinwacht" and r.mentor == "Rokan Steinwacht"
		local said = ok and "" or (" – " .. table.concat(r.said or {}, " / "))
		return ok and true or false, S(r.main) .. "|" .. S(r.thx) .. "|" .. S(r.mentor) .. said, "Rokan Steinwacht ×3"
	end)
	Check("T155", "J", "P3: Flüstern mit Leerzeichen", function()
		local a0, b0 = Recorded("ChatFrame_SendTell"), Recorded("ChatFrame_OpenChat")
		Outside(function() ns.OpenWhisper("Rokan Steinwacht", "Hallo"); ns.OpenWhisper("Rokan", "Hallo") end)
		return (Recorded("ChatFrame_SendTell") == a0 + 1 and Recorded("ChatFrame_OpenChat") == b0 + 1) and true or false, "SendTell/OpenChat", "1/1"
	end)
	Skip("T156", "J", "P4a: Bewerber-Flüstern im Kampf", "wie T85")
	Skip("T157", "J", "P4b: Addon-Nachricht im Kampf", "wie T84")
	Skip("T158", "J", "P4c: Abklingzeit im Kampf", "wie T86")
	Check("T159", "J", "P5a: IsOfficer über C_GuildInfo", OfficerFallbacks)
	Skip("T160", "J", "P5b: KnowsSpell über C_SpellBook", "wie T98/T133")
	Check("T161", "J", "P6a: SendChatMessage-Rückfall", ChatFallback)
	Skip("T162", "J", "P6b: ChatFrame_RemoveChannel", "wie T101")
	Check("T163", "J", "GoldSentinelGame eingebaut", function()
		return (ns.Game.FOREVER == GoldSentinelGame.IsForever and ns.Proper("x") == GoldSentinelGame.CleanName("x")) and true or false, "gleich", "gleich"
	end)
	Skip("T164", "J", "Launch-Tag: Interface-Nummer", "wie T03")
	Check("T165", "J", "Ersatznamen der frühen Fassung", function()
		local G = GoldSentinelGame
		local ok = type(G.ProperName) == "function" and type(G.ShortName) == "function" and type(G.NormName) == "function"
			and pcall(G.SameName, "a", "b", function() return true end)
		return True(ok, "vorhanden")
	end)
	Check("T166", "J", "K1: CanViewOfficerNote allein", ViewOnlyNotOfficer)
	Client("T168", "J", "K2 im echten Kampf", "Mitspieler flüstert im Kampf 'gilde'; nach dem Kampf /gs testroutine whisperq und prüfen, ob Hinweis oder Bewerber erscheint")
	Check("T169", "J", "K3: Tooltip-Kampfsperre an MODERN", function()
		local function Lines(flavor)
			Flavor(flavor)
			local n = 0
			With({ { ns, "testCombat", true } }, function()
				local tip = { AddLine = function() n = n + 1 end, Show = function() end, GetUnit = function() return "Rokwar", "player" end }
				ns.Tooltip.OnUnit(tip)
			end)
			return n
		end
		local r = Lines("retail")
		local e = Lines("era")
		Flavor(nil)
		return (r == 0 and e > 0) and true or false, "retail " .. r .. ", era " .. e, "0, >0"
	end)
	Check("T170", "J", "K4: Absender exakt (AWAY/THX)", function()
		Flavor("forever")
		local r = MiniRoster({ "Rokan Steinwacht", ns.Me() }, function()
			local g = ns.guild
			g.away["Rokan Steinwacht"] = nil
			ns.Comm.TestDispatch("Rokan", "AWAY\t" .. ns.Comm.Serialize({ n = "Rokan Steinwacht", e = { u = ns.Now() + 999, note = "", t = ns.Now(), by = "Rokan" } }), "GUILD")
			local a = g.away["Rokan Steinwacht"]
			ns.Comm.TestDispatch("Rokan Steinwacht", "AWAY\t" .. ns.Comm.Serialize({ n = "Rokan Steinwacht", e = { u = ns.Now() + 999, note = "", t = ns.Now(), by = "Rokan Steinwacht" } }), "GUILD")
			local b = g.away["Rokan Steinwacht"]
			g.away["Rokan Steinwacht"] = nil
			return { a, b }
		end)
		Flavor(nil)
		return (r[1] == nil and r[2] ~= nil) and true or false, "Vorname " .. S(r[1] ~= nil) .. ", voll " .. S(r[2] ~= nil), "false, true"
	end)
	Skip("T171", "J", "K5: tools/luac5.1 -v", "Werkzeug im Repo (offline)")
	Skip("T172", "J", "RM2: Werkzeug nicht in der ZIP", "offline (unzip -l)")
	Skip("T173", "J", "N8: Offline-Test K2", "offline (test/run_forever95.lua)")
end

-- verzögerte Fälle (nach R.WAIT Sekunden): T67 und T167
function R:Deferred(stage)
	local Rc = ns.Recruit
	if stage == "plan" then
		R.d = {}
		if Want("B") then
			-- T67: Bewerber im Testmodus, sofort Testmodus beenden -> nach 7 s nichts gesendet
			R.d.r0 = Recorded("SendChatMessage") + Recorded("SendAddonMessage")
			ns.Test:Trigger("applicant")
			ns.Claim("gstest-later", function() ns.Chat("x", "GUILD") end, 0.1)
			ns.Test:Stop()
			ns.Test:Start()
		end
		if Want("J") then
			R.d.q0 = Rc.combatQueue
			Rc.combatQueue = { { Bait(), "A-Test", nil }, { "x", Bait(), nil }, { "gilde guild", "Wanderer55-Test", Bait() } }
			R.d.prints = {}
			Swap(ns, "Print", function(_, msg) R.d.prints[#R.d.prints + 1] = tostring(msg) end)
			R.d.swapMark = #swaps
			FireEvent("PLAYER_REGEN_ENABLED")
		end
		return
	end
	Check("T67", "B", "verzögerte Sendungen nach Stop (N3)", function()
		local n = Recorded("SendChatMessage") + Recorded("SendAddonMessage") - (R.d.r0 or 0)
		return Eq(n, 0)
	end)
	Check("T167", "J", "K2: Kampf-Flüstern bleibt geschützt", function()
		local app = ns.guild and ns.guild.apps.Wanderer55
		local hint = 0
		local want = string.format(L["%d Flüsternachricht(en) im Kampf nicht auswertbar – bitte den Chat prüfen."], 2)
		for _, p in ipairs(R.d.prints or {}) do if p:find(want, 1, true) then hint = hint + 1 end end
		Rc.combatQueue = R.d.q0 or {}
		return (app ~= nil and hint == 1) and true or false, "Bewerber " .. S(app ~= nil) .. ", Hinweise " .. hint, "true, 1"
	end)
end

------------------------------------------------------------
-- K. OBERFLÄCHE IM ECHTEN CLIENT (anweisung-testroutine-oberflaeche.txt, Fälle 1–6)
-- Nur lesen: Fenster öffnen, Tooltips zeigen und wieder schliessen, Lagen vergleichen. Ohne Bildschirm-Lage (nachgebautes
-- WoW in test/) werden die Fälle begründet übersprungen; die Rechenhilfen prüft test/run_uicheck.lua.
------------------------------------------------------------
local U = {}
R.UICheck = U

-- Lage in UIParent-Koordinaten: { l, b, w, h } oder nil (nicht sichtbar bzw. nicht gelayoutet)
function U.Rect(f)
	if not f then return nil end
	local okM, getRect = pcall(function() return f.GetRect end)
	if not okM or type(getRect) ~= "function" then return nil end
	local ok, l, b, w, h = pcall(getRect, f)
	if not ok or type(l) ~= "number" or type(b) ~= "number" or type(w) ~= "number" or type(h) ~= "number" or w <= 0 or h <= 0 then return nil end
	local s = 1
	local okS, es = pcall(function() return f:GetEffectiveScale() / UIParent:GetEffectiveScale() end)
	if okS and type(es) == "number" and es > 0 then s = es end
	return { l * s, b * s, w * s, h * s }
end

-- echte Überschneidung (Berühren an der Kante zählt nicht; 1 Pixel Spiel)
function U.Overlap(a, b)
	if not a or not b then return false end
	return a[1] + a[3] > b[1] + 1 and b[1] + b[3] > a[1] + 1 and a[2] + a[4] > b[2] + 1 and b[2] + b[4] > a[2] + 1
end

-- a liegt ganz in b (1 Pixel Spiel)
function U.Inside(a, b)
	if not a or not b then return true end
	return a[1] >= b[1] - 1 and a[2] >= b[2] - 1 and a[1] + a[3] <= b[1] + b[3] + 1 and a[2] + a[4] <= b[2] + b[4] + 1
end

local function Call(f, m, ...)
	local okM, fn = pcall(function() return f[m] end)
	if not okM or type(fn) ~= "function" then return nil end
	local ok, a, b, c, d = pcall(fn, f, ...)
	if ok then return a, b, c, d end
	return nil
end
U.Call = Call

local function Kind(f) return Call(f, "GetObjectType") or "?" end
function U.Name(f)
	local n = Call(f, "GetName")
	if type(n) == "string" and n ~= "" then return n end
	local t = Call(f, "GetText")
	if type(t) == "string" and t ~= "" and not ns.IsSecret(t) then return '"' .. t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):sub(1, 24) .. '"' end
	local p = Call(f, "GetParent")
	return Kind(f) .. (p and (" in " .. tostring(Call(p, "GetName") or "?")) or "")
end

-- sichtbare Nachfahren (Frames) eines Fensters
function U.Walk(f, out)
	out = out or {}
	local list = {}
	local okC, a = pcall(function() return { f:GetChildren() } end)
	if okC and type(a) == "table" then list = a end
	for _, c in ipairs(list) do
		if Call(c, "IsVisible") then
			out[#out + 1] = c
			U.Walk(c, out)
		end
	end
	return out
end

-- sichtbare Texte (FontStrings) eines Frames und seiner Nachfahren
function U.Texts(f)
	local out = {}
	local frames = U.Walk(f)
	table.insert(frames, 1, f)
	for _, x in ipairs(frames) do
		local okR, regs = pcall(function() return { x:GetRegions() } end)
		if okR and type(regs) == "table" then
			for _, r in ipairs(regs) do
				if Kind(r) == "FontString" and Call(r, "IsVisible") then out[#out + 1] = { fs = r, owner = x } end
			end
		end
	end
	return out
end

local function IsAncestor(a, b)          -- a ist Vorfahr von b
	local p = Call(b, "GetParent")
	local n = 0
	while p and n < 30 do
		if p == a then return true end
		p = Call(p, "GetParent")
		n = n + 1
	end
	return false
end

-- eigene Fenster, die gerade zu sehen sind
function U.OwnWindows()
	local out = {}
	for _, n in ipairs({ "GuildSentinelFrame", "GuildSentinelInfo", "GuildSentinelRules", "GuildSentinelMenu", "GuildSentinelProfButton" }) do
		local f = _G[n]
		if f and Call(f, "IsVisible") then out[#out + 1] = f end
	end
	return out
end

-- Lage messbar? (im nachgebauten WoW nicht)
local function Measurable()
	local UI = ns.UI
	if not UI.frame then UI:Build() end
	UI.frame:Show()
	return U.Rect(UI.frame) ~= nil and U.Rect(UIParent) ~= nil
end

-- Fall 1: Tooltip eines Elements verdeckt einen Knopf oder ein Eingabefeld desselben Fensters
function U.TooltipHits(win)
	local hits, tried = {}, 0
	for _, el in ipairs(U.Walk(win)) do
		local onEnter = Call(el, "GetScript", "OnEnter")
		if type(onEnter) == "function" then
			tried = tried + 1
			pcall(onEnter, el)
			local tip = GameTooltip
			local owner = Call(tip, "GetOwner")
			if Call(tip, "IsVisible") and owner == el then
				local tr = U.Rect(tip)
				for _, other in ipairs(U.Walk(win)) do
					local k = Kind(other)
					if other ~= el and (k == "Button" or k == "CheckButton" or k == "EditBox") and Call(other, "IsVisible")
						and not IsAncestor(other, el) and not IsAncestor(el, other) and U.Overlap(tr, U.Rect(other)) then
						hits[#hits + 1] = U.Name(el) .. " -> " .. U.Name(other)
						break
					end
				end
				if tr and not U.Inside(tr, U.Rect(UIParent)) then hits[#hits + 1] = U.Name(el) .. " -> ausserhalb des Bildschirms" end
			end
			local onLeave = Call(el, "GetScript", "OnLeave")
			if type(onLeave) == "function" then pcall(onLeave, el) end
			pcall(GameTooltip.Hide, GameTooltip)
		end
	end
	return hits, tried
end

-- Fall 4: abgeschnittene Texte (Knöpfe -> FEHLER, sonst WARNUNG)
function U.CutTexts(win)
	local btn, other = {}, {}
	for _, x in ipairs(U.Texts(win)) do
		local fs = x.fs
		local cut = Call(fs, "IsTruncated")
		if cut == nil then
			local sw, w = Call(fs, "GetStringWidth"), Call(fs, "GetWidth")
			local lines = Call(fs, "GetNumLines")
			cut = type(sw) == "number" and type(w) == "number" and w > 0 and (lines == nil or lines <= 1) and sw > w + 2
		end
		if cut then
			local k = Kind(x.owner)
			local label = U.Name(x.owner)
			if k == "Button" or k == "CheckButton" then btn[#btn + 1] = label else other[#other + 1] = label end
		end
	end
	return btn, other
end

-- Fenster anderer GoldSentinel-Addons und Blizzard-Fenster, an die GuildSentinel andockt
U.OTHER_WINDOWS = { "AHSentinelFrame", "ProfessionSentinelFrame", "RaidMasterFrame", "ThreatSentinelFrame", "BuffSentinelFrame",
	"LevelPilotFrame", "TradeSkillFrame", "ProfessionsFrame", "CraftFrame" }

local function ByPage(fn)
	-- jede Seite und jeden Reiter einmal öffnen und fn(Name) im Hauptfenster ausführen
	local UI = ns.UI
	for _, p in ipairs(Pages()) do
		if UI:PageOn(p.page) then
			pcall(UI.Select, UI, p.i)
			local tabs = TabsOf(p.i)
			if #tabs == 0 then fn(p.key) end
			for _, t in ipairs(tabs) do
				if t.bar:IsVisible(t.key) then
					pcall(t.bar.Select, t.bar, t.key)
					fn(p.key .. ">" .. tostring(t.key))
				end
			end
		end
	end
end

function R:AreaK()
	local UI = ns.UI
	local can = Measurable()
	local WHY = "nur im echten Client (Lage der Fenster nicht messbar)"
	if not can then
		Skip("T182", "K", "Tooltips verdecken keine Knöpfe", WHY)
		Skip("T183", "K", "kein Überlappen mit anderen Fenstern", WHY)
		Skip("T184", "K", "Fenster und Tooltips im Bildschirm", WHY)
		Skip("T185", "K", "Texte passen", WHY)
	else
		Check("T182", "K", "Tooltips verdecken keine Knöpfe", function()
			local all, n = {}, 0
			ByPage(function(key)
				local hits, tried = U.TooltipHits(UI.frame)
				n = n + tried
				for _, h in ipairs(hits) do all[#all + 1] = key .. ": " .. h end
			end)
			return #all == 0, n .. " Tooltips, verdeckt: " .. (#all > 0 and table.concat(all, "; ", 1, math.min(#all, 12)) or "0"), "0"
		end)
		Check("T183", "K", "kein Überlappen mit anderen Fenstern", function()
			local hits = {}
			for _, win in ipairs(U.OwnWindows()) do
				local r = U.Rect(win)
				for _, n in ipairs(U.OTHER_WINDOWS) do
					local o = _G[n]
					if o and o ~= win and Call(o, "IsVisible") and U.Overlap(r, U.Rect(o)) then hits[#hits + 1] = U.Name(win) .. " / " .. n end
				end
			end
			return #hits == 0, #hits > 0 and table.concat(hits, "; ") or "0", "0 (angedockt nebeneinander ist erlaubt)"
		end)
		Check("T184", "K", "Fenster und Tooltips im Bildschirm", function()
			local screen = U.Rect(UIParent)
			local out = {}
			for _, win in ipairs(U.OwnWindows()) do
				if not U.Inside(U.Rect(win), screen) then out[#out + 1] = U.Name(win) end
			end
			local mm = _G.GuildSentinelMinimapButton
			if mm and Call(mm, "IsVisible") and not U.Inside(U.Rect(mm), screen) then out[#out + 1] = U.Name(mm) end
			return #out == 0, #out > 0 and table.concat(out, ", ") or "0 ausserhalb", "0 ausserhalb (Tooltips: T182)"
		end)
		Check("T185", "K", "Texte passen", function()
			local btn, other = {}, {}
			ByPage(function(key)
				local b, o = U.CutTexts(UI.frame)
				for _, x in ipairs(b) do btn[#btn + 1] = key .. ": " .. x end
				for _, x in ipairs(o) do other[#other + 1] = key .. ": " .. x end
			end)
			local warn = #other > 0 and ("WARNUNG " .. #other .. " Texte zu lang: " .. table.concat(other, "; ", 1, math.min(#other, 10))) or "0 zu lang"
			if #btn > 0 then return false, "Knöpfe abgeschnitten: " .. table.concat(btn, "; ", 1, math.min(#btn, 10)) .. " · " .. warn, "0 abgeschnittene Knöpfe" end
			return true, warn, "0"
		end)
	end
	Check("T186", "K", "Spielwerte plausibel", function()
		local bad, seen = {}, {}
		-- Stufe
		local lv = UnitLevel("player")
		if not ns.IsSecret(lv) then
			seen[#seen + 1] = "Stufe " .. tostring(lv)
			if type(lv) ~= "number" or lv < 1 or lv > ns.Roster.MAX_LEVEL then bad[#bad + 1] = "Stufe " .. tostring(lv) .. " (max " .. ns.Roster.MAX_LEVEL .. ")" end
		end
		if GetMaxPlayerLevel then
			local m = GetMaxPlayerLevel()
			if type(m) == "number" and not ns.IsSecret(m) and m ~= ns.Roster.MAX_LEVEL then bad[#bad + 1] = "Höchststufe " .. ns.Roster.MAX_LEVEL .. " statt " .. m end
		end
		-- Berufe: gelernt -> Fertigkeit > 0 und <= Maximum; gespeicherter Stand nicht höher als der echte
		local skills = ns.Prof:ReadSkillLines()
		local real = R.saved and R.saved.guild and R.saved.guild.prof and R.saved.guild.prof[ns.Me()]
		for name, v in pairs(skills) do
			if not ns.IsSecret(name) and not ns.IsSecret(v.r) then
				seen[#seen + 1] = tostring(name) .. " " .. tostring(v.r)
				if type(v.r) ~= "number" or v.r <= 0 or (type(v.m) == "number" and v.m > 0 and v.r > v.m) then
					bad[#bad + 1] = tostring(name) .. " Fertigkeit " .. tostring(v.r) .. "/" .. tostring(v.m)
				end
				local st = type(real) == "table" and type(real.p) == "table" and real.p[name]
				if type(st) == "table" and type(st.r) == "number" and type(v.r) == "number" and st.r > v.r then
					bad[#bad + 1] = tostring(name) .. " gespeichert " .. st.r .. " > echt " .. v.r
				end
			end
		end
		-- Gilde: Anzahl in GuildSentinel = Anzahl laut Spiel (nur ausserhalb des Testmodus gelesen)
		local list = R.saved and R.saved.list
		if IsInGuild and IsInGuild() and GetNumGuildMembers and type(list) == "table" and #list > 0 then
			local total = GetNumGuildMembers()
			if type(total) == "number" and not ns.IsSecret(total) and total > 0 then
				seen[#seen + 1] = "Gilde " .. #list .. "/" .. total
				if math.abs(total - #list) > 1 then bad[#bad + 1] = "Mitglieder " .. #list .. " statt " .. total end
			end
		end
		-- Geld (Bank-Charakter)
		local money = ns.API.GetMoney and ns.API.GetMoney()
		if money ~= nil and not ns.IsSecret(money) and (type(money) ~= "number" or money < 0) then bad[#bad + 1] = "Geld " .. tostring(money) end
		return #bad == 0, (#bad > 0 and table.concat(bad, "; ") or "ok") .. " (" .. table.concat(seen, ", ", 1, math.min(#seen, 6)) .. ")", "plausibel"
	end)
	Check("T187", "K", "keine Fehlerschleifen", function()
		local loops = {}
		local s = GuildSentinelDB and GuildSentinelDB.gsTest
		for _, e in ipairs(GoldSentinelTest.ErrorList(s or {})) do
			if (e.count or 0) > 10 then loops[#loops + 1] = (e.count or 0) .. "× " .. tostring(e.wo) .. ": " .. tostring(e.msg):sub(1, 80) end
		end
		-- eigene Liste der letzten Fehler: 10 gleiche hintereinander deuten auf eine Schleife
		local same, last = 0, nil
		for _, e in ipairs(ns.errors and ns.errors.last or {}) do
			local k = tostring(e.wo) .. "|" .. tostring(e.msg)
			if k == last then same = same + 1 else same, last = 1, k end
		end
		if same >= 10 and ns.errors.n > 10 then loops[#loops + 1] = "10× hintereinander: " .. tostring(last):sub(1, 80) end
		return #loops == 0, #loops > 0 and table.concat(loops, " | ", 1, math.min(#loops, 5)) or "0", "keine Meldung mehr als 10×"
	end)
	pcall(GameTooltip.Hide, GameTooltip)
end

------------------------------------------------------------
-- Ablauf: Sandbox, Bereiche, Aufräumen, Bericht
------------------------------------------------------------
local AREA_FN = { A = "AreaA", B = "AreaB", C = "AreaC", D = "AreaD", E = "AreaE", F = "AreaF", G = "AreaG", H = "AreaH", I = "AreaI", J = "AreaJ", K = "AreaK" }

local function SaveState()
	local st = {
		db = Copy(GuildSentinelDB or {}),
		guild = ns.guild, guildKey = ns.guildKey, lang = ns.lang, debug = ns.debug,
		list = ns.Roster.list, byName = ns.Roster.byName, scans = ns.Roster.scans, liveJoin = ns.Roster.liveJoin,
		users = ns.Comm.users, claims = Copy(ns.Comm.claims), free = ns.Free.list,
		cq = ns.Recruit.combatQueue, cd = ns.Recruit.combatDropped, claimed = Copy(ns.Recruit.claimed), claimBy = Copy(ns.Recruit.claimBy),
		chatHooked = ns.Social.chatHooked, ttHooked = ns.Tooltip.hooked, errors = Copy(ns.errors),
		testActive = ns.Test.active, uiShown = ns.UI.frame and ns.UI.frame:IsShown(),
	}
	st.db.gsTest = nil
	local qh, ql = ns.Comm.TestQueues()
	st.qh, st.ql = #qh, #ql
	return st
end

local function RestoreState(st)
	UnswapAll()
	ns.actRecorder = nil
	ns.testSecret = nil
	ns.testCombat = nil
	if GoldSentinelGame.SetTestFlavor then GoldSentinelGame.SetTestFlavor(nil) end
	ns.Game:Refresh()
	-- Testmodus: aus, wenn die Routine ihn gestartet hat (sonst wieder frisch an)
	if ns.Test.active and not st.testActive then ns.Test:Stop() end
	ns.guild, ns.guildKey, ns.lang, ns.debug = st.guild, st.guildKey, st.lang, st.debug
	ns.Roster.list, ns.Roster.byName, ns.Roster.scans, ns.Roster.liveJoin = st.list, st.byName, st.scans, st.liveJoin
	ns.Comm.users, ns.Free.list = st.users, st.free
	wipe(ns.Comm.claims); for k, v in pairs(st.claims) do ns.Comm.claims[k] = v end
	ns.Recruit.combatQueue, ns.Recruit.combatDropped = st.cq, st.cd
	wipe(ns.Recruit.claimed); for k, v in pairs(st.claimed) do ns.Recruit.claimed[k] = v end
	wipe(ns.Recruit.claimBy); for k, v in pairs(st.claimBy) do ns.Recruit.claimBy[k] = v end
	ns.Social.chatHooked, ns.Tooltip.hooked = st.chatHooked, st.ttHooked
	-- Fehlerzähler: Selbsttest-Fehler nicht stehen lassen, echte behalten
	ns.errors.n, ns.errors.last = st.errors.n, st.errors.last
	-- nichts aus der Routine in der Sendewarteschlange lassen
	local qh, ql = ns.Comm.TestQueues()
	for i = #qh, st.qh + 1, -1 do table.remove(qh, i) end
	for i = #ql, st.ql + 1, -1 do table.remove(ql, i) end
	DropSelfTestErrors()
end

local function CompareAndRestore(st)
	local paths = {}
	Diff(GuildSentinelDB, st.db, "DB", paths, 10, 0, true)
	RestoreInto(GuildSentinelDB, st.db, true)
	ns.db = GuildSentinelDB.settings
	if #paths == 0 then return "OK", paths end
	return string.format("FEHLER (%d Pfade, wiederhergestellt)", #paths), paths
end

local function Finish(st)
	local mem0 = R.mem0
	local realBy = {}
	for k, v in pairs(R.realBy) do realBy[#realBy + 1] = k .. " " .. v end
	local recorded = RecTotal()
	-- T82: über die ganze Routine (jeder Bereich) darf nichts echt hinausgegangen sein, und in der Sendewarteschlange
	-- darf nichts aus der Routine liegen. Sonst FEHLER im Bericht (nicht nur eine Textzeile).
	local qh, ql = ns.Comm.TestQueues()
	local pend = #qh + #ql - (st.qh + st.ql)
	if pend < 0 then pend = 0 end
	RUN:Check("T82", "B", "nichts gesendet", function()
		return (R.real == 0 and pend == 0) and true or false,
			string.format("echt %d%s, Warteschlange +%d", R.real, #realBy > 0 and (" (" .. table.concat(realBy, ", ") .. ")") or "", pend), "echt 0, Warteschlange +0"
	end)
	R.running = false
	RestoreState(st)
	local sandbox, paths = CompareAndRestore(st)
	if sandbox ~= "OK" then
		RUN:Add("FEHLER", "SANDBOX", "-", "echte Daten verändert", { ergebnis = table.concat(paths, ", ") })
	end
	collectgarbage("collect")
	local memKB = collectgarbage("count") - (mem0 or 0)
	local text = RUN:Finish({ sandbox = sandbox })
	local GT = GoldSentinelTest
	local last = {}
	for i = 1, math.min(3, #ns.errors.last) do last[#last + 1] = ns.errors.last[i].wo .. ": " .. ns.errors.last[i].msg end
	local extra = {
		string.format("Sprache: %s (%s)", tostring(GetLocale()), tostring(ns.lang)),
		string.format("Fehlerzähler GuildSentinel: %d%s", ns.errors.n, #last > 0 and (" (letzte: " .. table.concat(last, " | ") .. ")") or ""),
		string.format("Recorder: %d echte Sendungen%s (%d nur aufgezeichnet)", R.real, #realBy > 0 and (" – " .. table.concat(realBy, ", ")) or "", recorded),
		"echte Daten unverändert: " .. sandbox,
		string.format("Speicher: %+d KB", math.floor(memKB + 0.5)),
		"",
		L["Bericht gespeichert – wird beim nächsten /reload oder Ausloggen an die Prüfung gemeldet."],
		L["Bitte jetzt /reload, damit alles sicher wie vorher ist."],
	}
	text = text .. "\n" .. table.concat(extra, "\n")
	if #text > 19000 then text = text:sub(1, 19000) .. "\n… gekürzt" end
	R.lastText = text
	local c = RUN.counts
	ns:Print(ORANGE .. string.format(L["Testroutine: OK %d · FEHLER %d · übersprungen %d · im Client prüfen %d"], c.ok, c.fehler, c.uebersprungen, c.client) .. "|r")
	ns:Print(L["Bericht gespeichert – wird beim nächsten /reload oder Ausloggen an die Prüfung gemeldet."])
	ns:Print(L["Bitte jetzt /reload, damit alles sicher wie vorher ist."])
	if ns.UI and ns.UI.Info then pcall(ns.UI.Info, ns.UI, L["Testroutine"], text, true) end
	if R.watch then R.watch:UnregisterAllEvents() end
	RUN = nil
	return text
end

-- Start. which: "" = alle, sonst ein Bereich (a … k). probe = nur prüfen, ob gestartet würde (T105)
function R:Start(which, probe)
	if ns.InCombat() then
		if not probe then ns:Print(L["Die Testroutine startet nicht im Kampf."]) end
		return false
	end
	if probe then return true end
	if R.running then ns:Print(L["Die Testroutine läuft schon."]) return false end
	which = (which or ""):upper()
	only = (which ~= "" and AREA_FN[which]) and which or nil
	aborted = false
	InstallHooks()
	collectgarbage("collect")
	R.mem0 = collectgarbage("count")
	R.rec, R.real, R.realBy = {}, 0, {}
	local st = SaveState()
	R.saved = st              -- echte Daten (Bereich K vergleicht Spielwerte damit)
	R.running = true
	RUN = GoldSentinelTest.Begin("GuildSentinel", ns.version, GuildSentinelDB)
	ns.actRecorder = function(what) R.rec[what] = (R.rec[what] or 0) + 1 end
	if not ns.Test.active then ns.Test:Start() end
	if not ns.Test.active then R.running = false; RestoreState(st); return false end
	-- Kampf mitten im Lauf: sauber abbrechen
	if not R.watch then R.watch = CreateFrame("Frame") end
	R.watch:RegisterEvent("PLAYER_REGEN_DISABLED")
	R.watch:SetScript("OnEvent", function() aborted = true end)
	for _, a in ipairs(R.AREAS) do
		if Want(a) and not aborted then
			area = a
			local ok, err = pcall(R[AREA_FN[a]], R)
			if not ok then RUN:Add("FEHLER", "AREA-" .. a, a, "Bereich abgebrochen", { lua = tostring(err) }) end
			UnswapAll()
			Flavor(nil)
			ns.testCombat = nil
		end
	end
	if aborted or not (Want("B") or Want("J")) then return Finish(st) end
	local ok, err = pcall(R.Deferred, R, "plan")
	if not ok then RUN:Add("FEHLER", "DEFERRED", "B", "verzögerte Fälle", { lua = tostring(err) }) end
	ns:Print(ORANGE .. string.format(L["Testroutine läuft – bitte %d Sekunden warten."], math.ceil(R.WAIT)) .. "|r")
	C_Timer.After(R.WAIT, function()
		if aborted then
			Skip("T67", "B", "verzögerte Sendungen", "Kampf begonnen")
			Skip("T167", "J", "Kampf-Flüstern", "Kampf begonnen")
		else
			local ok2, err2 = pcall(R.Deferred, R, "check")
			if not ok2 then RUN:Add("FEHLER", "DEFERRED", "B", "verzögerte Fälle", { lua = tostring(err2) }) end
		end
		Finish(st)
	end)
	return true
end

-- nur Anzeige für den Launch-Abend: gemerkte Kampf-Flüsternachrichten (nie der Inhalt)
function R:WhisperQueue()
	local q = ns.Recruit.combatQueue or {}
	local secret = 0
	for _, x in ipairs(q) do if ns.IsSecret(x[1]) or ns.IsSecret(x[2]) then secret = secret + 1 end end
	ns:Print(string.format(L["Kampf-Flüsternachrichten gemerkt: %d, davon geschützt: %d (dazu %d über der Grenze)"], #q, secret, ns.Recruit.combatDropped or 0))
	return #q, secret
end

function R:Slash(rest)
	if not (GoldSentinelDev and GoldSentinelDev:IsDev()) then return end
	rest = ns.Trim(rest or ""):lower()
	if rest == "whisperq" then return self:WhisperQueue() end
	return self:Start(rest)
end
