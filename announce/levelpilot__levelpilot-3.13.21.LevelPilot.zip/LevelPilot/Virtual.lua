-- LevelPilot - Virtuelle Reise: LevelPilot laesst einen gedachten Charakter seine eigene Route laufen
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Zum Testen im Spiel, ohne zu spielen: Der echte Charakter bewegt sich nicht, es wird nichts
-- angeklickt, angenommen oder gekauft. LevelPilot plant mit dem gedachten Charakter (Level, Position,
-- Questlog nur im Speicher), "geht" jeden Weg ueber sein Wegenetz, nimmt Quests an, erledigt und gibt sie
-- ab und sammelt EP nach den Classic-Regeln – bis Level 60.
-- Geprueft wird dabei mit den echten Karten- und Wegedaten des Spiels: Gibt es einen Weg? Ist er
-- plausibel (keine riesigen Luftlinien, keine Spruenge)? Bleibt der Plan haengen? Stimmen Zonen und Namen?
-- Waehrend der Reise wird nichts aufgezeichnet und nichts geteilt; die echten Daten bleiben unberuehrt.
-- Ansicht: "Zuschauen" zeigt jeden Weg auf der Weltkarte, "Schnell" rechnet ohne Pause durch.

local _, LP = ...
local L = LP.L
local V = {}
LP:RegisterModule("Virtual", V)

V.active = false
V.s = nil

-- EP je Level (Classic)
local XPNEED = { 400, 900, 1400, 2100, 2800, 3600, 4500, 5400, 6500, 7600, 8800, 10100, 11400, 12900, 14400,
    16000, 17700, 19400, 21300, 23200, 25200, 27300, 29400, 31700, 34000, 36400, 38900, 41400, 44300, 47400,
    50800, 54500, 58600, 62800, 67100, 71600, 76100, 80800, 85700, 90700, 95800, 101000, 106300, 111800,
    117500, 123200, 129100, 135100, 141200, 147500, 153900, 160400, 167100, 173900, 180800, 187900, 195000,
    202300, 209800 }
-- Startgebiete nach Volk
local START = {
    Human = { 1429, 48.2, 42.9 }, Dwarf = { 1426, 29.9, 71.2 }, Gnome = { 1426, 29.9, 71.2 },
    NightElf = { 1438, 58.6, 44.6 }, Orc = { 1411, 43.3, 68.5 }, Troll = { 1411, 43.3, 68.5 },
    Scourge = { 1420, 30.2, 71.7 }, Tauren = { 1412, 44.2, 76.1 },
}
local RUN = 7                  -- Yards pro Sekunde zu Fuss
local LONG_DIRECT = 1500       -- Luftlinie (ohne bekannten Weg) laenger als das wird notiert
V.GAP_MIN = 300                -- 3.13.2: Luftlinien ab dieser Länge zählen als Lücke (Lückenliste, nur V.gapStats)
local MAX_STEPS = 6000

------------------------------------------------------------------------
-- Gedachter Zustand und Umleitungen
------------------------------------------------------------------------
local saved = {}
local TRAIL_MAX = 400        -- Punkte der Spur beim Zuschauen
local TRANSIT_SECS = { zep = 390, boat = 360, tram = 150, portal = 30 }
local WAY_KILL_YARDS = 120   -- Speedrun: hoechstens ein Kill im Vorbeigehen je so viele Yards Weg
local WAY_KILL_TIME = 0.6    -- Anteil der normalen Kampfzeit (kein Hinlaufen, kein Suchen)
V.wayRateShare = nil         -- (Test) Monster am Weg nur, wenn sie so viel bringen wie Questen mit Wegen: ohne Gewinn
-- Monster ab so vielen Leveln unter dem Spieler sind grau (keine EP) - Classic-Formel
-- Abstand zum hoechsten grauen Level (fuer die Monster auf dem Weg) - gleiche Regel wie Planner:GreyLevel
local function MobGreyDiff(level) return level - LP.Planner:GreyLevel(level) end
local FLY_YPS, FLY_DETOUR, FLY_START = 32, 1.3, 30   -- Flug: Yards/s, Umweg der Flugroute, Start/Landung

local function QuestObjs(id)
    local q = LP.QuestDB:Get(id)
    local objs = {}
    for _, o in ipairs(q and q.objectives or {}) do
        if o.kind ~= "rec" then
            local name = o.text
            if LP.Names then
                if o.kind == "item" and o.item then name = LP.Names:Item(o.item) or name
                elseif o.kind == "kill" and o.ids and o.ids[1] then name = LP.Names:Npc(o.ids[1]) or name
                elseif o.kind == "object" and o.objId then name = LP.Names:Object(o.objId) or name end
            end
            if not name and o.kind == "item" and o.item then name = LP.API.ItemInfo(o.item) end
            objs[#objs + 1] = { text = (name or L["Ziel"]) .. ": 0/1", finished = false, have = 0, need = 1,
                                type = ({ kill = "monster", item = "item", object = "object", explore = "event" })[o.kind],
                                kind = o.kind, elite = o.elite }
        end
    end
    return objs, q
end

local OVERLAY = {}   -- Kennzeichen der Flugpunkt-Ueberlagerung (nie die echte Liste)

-- echte Flugpunkt-Liste, auch wenn (durch einen Abbruch) noch eine Ueberlagerung im Konto liegt
local function RealTaxiOf(t)
    local guard = 0
    while type(t) == "table" and guard < 5 do
        local mt = getmetatable(t)
        if not (mt and mt.lpOverlay == OVERLAY) then return t end
        t = mt.__index
        guard = guard + 1
    end
    return t
end

local function Install()
    local s = V.s
    local API, Geo = LP.API, LP.Geo
    -- zuerst die echten Daten merken: bricht das Spiel mitten im Einrichten ab ("script ran too long"),
    -- kann Uninstall alles zurueckstellen, ohne etwas zu verlieren
    -- 3.12.90 (Ingametest 3.12.89 T83/T85): nur beim ERSTEN Einrichten merken. Brach Install mittendrin ab (Fehler), lief es im
    -- naechsten Anlauf nochmals und merkte sich die schon umgeleiteten Funktionen als "echt" – nach der Reise blieb alles umgeleitet.
    if not saved.orig then
        saved.taxi = RealTaxiOf(LP.Acc().taxi) or {}   -- 3.12.56: Bereich der Spielversion
        saved.char = LP.char
        saved.Quests, saved.Objectives, saved.QuestCount = API.Quests, API.Objectives, API.QuestCount
        saved.IsQuestDone, saved.Player = API.IsQuestDone, Geo.Player
        saved.HearthReady = API.HearthReady
        saved.contInst, saved.contLevel = LP.Planner.contInst, LP.Planner.contLevel
        -- 3.13.13 LP-I8 (Nachbau Laptop-Daten, Stufe 30: zwei gleiche Reisen weichen ab Schritt 2 ab – Lauf 1 "questRate nil", Lauf 2
        -- "questRate 293,6" aus der Reise davor): die Quest-Rate der Planung steuert, welche Monster am Weg mitgenommen werden (EP, Zeit).
        -- Sie gehört zur Reise: beim Einrichten leer, danach der echte Wert zurück.
        saved.questRate = LP.Planner.questRate
        saved.orig = true
    end
    LP.Planner.contInst, LP.Planner.contLevel = nil, nil
    LP.Planner.questRate = nil
    -- eigener Ruhestein des gedachten Charakters: 60 min Abklingzeit in Spielzeit der Reise
    API.HearthReady = function() return not s.hearthAt or (s.clock - s.hearthAt) >= 3600 end
    API.Quests = function()
        local out = {}
        for i, q in ipairs(s.log) do
            out[#out + 1] = { index = i, id = q.id, title = q.title, complete = q.complete, failed = false, level = q.level }
        end
        return out
    end
    API.Objectives = function(index)
        local q = s.log[index]
        local out = {}
        for _, o in ipairs(q and q.objs or {}) do
            out[#out + 1] = { text = o.text, finished = o.finished, have = o.have, need = o.need, type = o.type }
        end
        return out
    end
    API.QuestCount = function() return #s.log end
    API.IsQuestDone = function(id)
        if s.done[id] then return true end
        if s.doneFallback then return s.doneFallback(id) end       -- ab hier: echte erledigte Quests zaehlen
        return false
    end
    Geo.Player = function()
        local i, n, w = Geo:ToWorld(s.map, s.x, s.y)
        return i, n, w, s.map, s.x, s.y
    end
    -- 3.12.90: die Ersatz-Funktionen merken – nach der Reise prueft die Sandbox, dass keine davon mehr eingesetzt ist
    V.repl = { ["API.Quests"] = API.Quests, ["API.Objectives"] = API.Objectives, ["API.QuestCount"] = API.QuestCount,
               ["API.IsQuestDone"] = API.IsQuestDone, ["Geo.Player"] = Geo.Player, ["API.HearthReady"] = API.HearthReady }
    -- eigener Charakter-Speicher: Fortschritt der echten Figur bleibt unberuehrt
    local real = saved.char or LP.char
    local c = {}
    for k, v in pairs(real) do
        if type(v) == "table" and k ~= "settings" then c[k] = {} else c[k] = v end
    end
    -- Modus der Reise: vorgegeben (Vergleich beider Modi) oder der echte - der echte Charakter bleibt unberuehrt
    c.bind, c.inDungeon, c.focusZone, c.mode = false, false, false, s.forceMode or real.mode
    -- ab hier: Fortschritt der echten Figur uebernehmen (erledigte Quests, Flugpunkte, Bindeort)
    if s.here then
        for k, v in pairs(real) do
            -- 3.12.90: nur in eigene Tabellen kopieren (bind/inDungeon/focusZone sind oben auf false gesetzt – war bind eine
            -- Tabelle, brach Install hier ab: "Virtual.lua:135 indexed assignment on field '?' (a boolean value)")
            if type(v) == "table" and k ~= "settings" and type(c[k]) == "table" then for kk, vv in pairs(v) do c[k][kk] = vv end end
        end
        c.bind = real.bind
    end
    LP.char = c
    s.char = c
    -- Flugpunkte: eigene Liste, die echte bleibt unveraendert (bekannte Knoten werden mitbenutzt)
    s.taxi = setmetatable({}, { __index = saved.taxi, lpOverlay = OVERLAY })
    LP.Acc().taxi = s.taxi
    -- Zonen-Gedaechtnis der Planung: eigenes fuer die Reise, das echte bleibt
    local P = LP.Planner
    if not saved.focusCounts then                     -- 3.12.90: nur beim ersten Einrichten merken (siehe oben)
        saved.leftZones, saved.focus = P.leftZones, P.focus
        saved.focusCounts = { P.focusChanges, P.focusReturns }
        -- 3.13.8 LP-T1 (belegt, Nachbau Stufe 6 Durotar): ein Vorrang-Ziel des echten Charakters (PRIO:TRAIN:6, Trainer) war beim Start
        -- der ersten Reise gesetzt und wurde von ihr verbraucht – die zweite gleiche Reise startete ohne es (Lauf 1: 31 Schritte 3228 s,
        -- Lauf 2: 29 Schritte 3217 s). Die Reise beginnt jetzt ohne die Vorrang-/Ausweich-Zustände des echten Charakters und gibt sie danach
        -- unverändert zurück.
        saved.priority, saved.exhausted, saved.mobSkip, saved.safeSkip = { P.priority }, P.exhausted, P.mobSkip, P.safeSkip
    end
    P.leftZones, P.focus, P.focusChanges, P.focusReturns = {}, nil, 0, 0
    P.priority, P.exhausted, P.mobSkip, P.safeSkip = nil, {}, {}, {}
    if LP.Graph then LP.Graph.detourV = {} end          -- 3.13.8 LP-T1: eigene Umweg-Faktoren der Reise (Graph.CurDetour)
    saved.installed = true
end

-- Zurueckstellen: nur, was wirklich gemerkt wurde - nie etwas auf nil setzen
local function Uninstall()
    local API, Geo = LP.API, LP.Geo
    if saved.Quests then API.Quests = saved.Quests end
    if saved.Objectives then API.Objectives = saved.Objectives end
    if saved.QuestCount then API.QuestCount = saved.QuestCount end
    if saved.IsQuestDone then API.IsQuestDone = saved.IsQuestDone end
    if saved.Player then Geo.Player = saved.Player end
    if saved.HearthReady then API.HearthReady = saved.HearthReady end
    if saved.leftZones then
        local P = LP.Planner
        if V.s then V.s.focusChanges, V.s.focusReturns = P.focusChanges, P.focusReturns end
        P.leftZones, P.focus = saved.leftZones, saved.focus
        P.focusChanges, P.focusReturns = saved.focusCounts[1], saved.focusCounts[2]
        if saved.priority then
            P.priority, P.exhausted, P.mobSkip, P.safeSkip = saved.priority[1], saved.exhausted, saved.mobSkip, saved.safeSkip
        end
        if LP.Graph then LP.Graph.detourV = nil end
    end
    if saved.Quests then LP.Planner.contInst, LP.Planner.contLevel = saved.contInst, saved.contLevel end
    if saved.orig then LP.Planner.questRate = saved.questRate end              -- 3.13.13 LP-I8
    if saved.char then LP.char = saved.char end
    if LevelPilotCharDB and LP.char ~= LevelPilotCharDB then LP.char = LevelPilotCharDB end   -- immer der echte Charakter
    -- Flugpunkte: die echte Liste zurueck (auch wenn eine Ueberlagerung uebrig ist)
    local real = saved.taxi or RealTaxiOf(LP.Acc().taxi)
    if type(real) ~= "table" then real = {} end
    LP.Acc().taxi = real
    wipe(saved)
end
V.RealTaxiOf = RealTaxiOf
-- nur Testroutine: Ueberlagerung wie waehrend einer Reise bauen
function V.MakeOverlay(real) return setmetatable({}, { __index = real, lpOverlay = OVERLAY }) end

------------------------------------------------------------------------
-- Ereignisse der Reise
------------------------------------------------------------------------
local function Note(kind, text)
    local s = V.s
    -- Lua-Fehler in der Reise auch ins Fehler-Protokoll (hoechstens 5 je Reise)
    if kind == "error" and (s.protoErrors or 0) < 5 then
        s.protoErrors = (s.protoErrors or 0) + 1
        if LP.Protocol then LP.Protocol:AddL("error", "Virtuelle Reise L%d: %s", s.level or 0, tostring(text):sub(1, 300)) end
        LP.Report("Reise", tostring(text):sub(1, 300))      -- auch an GoldSentinelTest (3.12.6)
    end
    local list = s.problems
    local key = kind .. text
    if s.seen[key] then s.seen[key].n = s.seen[key].n + 1 return end
    local e = { kind = kind, text = text, lvl = s.level, map = s.map, x = s.x, y = s.y, n = 1 }
    s.seen[key] = e
    list[#list + 1] = e
end
V.Note = Note                -- Testroutine (T164)

local function GainXP(xp)
    local s = V.s
    s.xp = s.xp + xp
    while s.level < 60 and s.xp >= s.xpMax do
        s.xp = s.xp - s.xpMax
        s.level = s.level + 1
        s.xpMax = XPNEED[s.level] or 1
        s.levelAt[s.level] = { t = s.clock, q = s.quests, zone = s.map }
        LP.Planner:BuildCandidates()
    end
    if s.level >= 60 then s.xp = 0 end
end

local function QuestXP(id)
    local d = _G.LevelPilotData
    local r = d and d.Q and d.Q[id]
    local base = r and r.x or 0
    local ql = r and r.l or V.s.level
    if base <= 0 then return math.floor(40 + V.s.level * 30) end
    local mult = math.max(1, math.min(10, 2 * (ql - V.s.level) + 20))
    return math.floor(base * mult / 10)
end

-- Weg gehen: Laenge ueber das Wegenetz; Auffaelligkeiten werden notiert
-- Fingerabdruck der echten Daten (Sandbox-Pruefung: vor und nach jeder Reise gleich?)
-- 3.13.12 LP-I1 (Ingametest 3.13.11: "Reisen" 44,0 ms in einem Stück; Nachbau Laptop-Daten: der Fingerabdruck vor der Reise zählt 27 000
-- Wegpunkte und 33 000 Wegstücke am Stück): diese beiden Tabellen zählen mit LP:Yield("svc") alle 2000 (wirkt nur in einer
-- freigegebenen Rechnung der Testroutine). Kam in einer Pause ein Wegstück oder Wegpunkt dazu bzw. fiel weg (Graph.edgeGen, Anzahl
-- der Wegpunkte), wird die Tabelle danach am Stück neu gezählt – das Ergebnis ist immer die genaue Anzahl. Andere Tabellen am Stück.
local function Count(t, sig)
    if type(t) ~= "table" then return 0 end
    local n, k = 0, nil
    local s0 = sig and sig()
    while true do
        k = next(t, k)
        if k == nil then return n end
        n = n + 1
        if sig and n % 2000 == 0 and coroutine.running() then
            LP:Yield("svc")
            if sig() ~= s0 then
                n = 0
                for _ in pairs(t) do n = n + 1 end
                return n
            end
        end
    end
end
local function GraphSig()
    local g = type(LevelPilotDB) == "table" and LP.Acc and LP.Acc().graph
    return tostring(LP.Graph and LP.Graph.edgeGen) .. ":" .. tostring(type(g) == "table" and g.count) .. ":" .. tostring(g)
end
function V:Fingerprint()
    local db = (LevelPilotDB and LP.Acc()) or {}   -- 3.12.56: Bereich der Spielversion
    local ch = LevelPilotCharDB or {}
    local g = type(db.graph) == "table" and db.graph or {}
    local taxi = RealTaxiOf(db.taxi)
    local bk = type(ch.backup) == "table" and ch.backup.data or {}
    return {
        { L["Quests"], Count(db.qdb) }, { L["Wegpunkte"], Count(g.nodes, GraphSig) }, { L["Wegstücke"], Count(g.edges, GraphSig) },
        { L["Flugpunkte"], Count(taxi) }, { L["Händler"], Count(db.vendors) }, { L["Höhlen"], Count(db.caves) },
        { L["ignorierte Quests"], Count(ch.ignored) }, { L["abgegebene Quests"], Count(ch.turnedIn) },
        { L["Sicherung: Flugpunkte"], Count(bk.taxi) }, { L["Sicherung: Quests"], Count(bk.qdb) },
    }
end
local function CompareFingerprint(a, b)
    local diff = {}
    for i, e in ipairs(a or {}) do
        local f = b and b[i]
        if f and f[2] ~= e[2] then diff[#diff + 1] = string.format("%s %d → %d", e[1], e[2], f[2]) end
    end
    return diff
end

-- Kontinent- und Flugkarten sind keine Zonen (z. B. "Kalimdor" nach einem Flug)
local function IsContinent(map)
    if not map or (LP.Names and LP.Names.ZONE_EN and LP.Names.ZONE_EN[map]) then return false end
    local c = LP.Geo:ContinentOf(map)
    return c == map or map == 1414 or map == 1415 or map == 1464 or map == 1465
end

-- 3.13.19 LP-R1 (Bericht der Reise 3.13.15: "Undercity 132.5,187.6", "Verwüstete Lande 83.7,-295.2"): Zone zu einer Weltposition. Belegt im
-- Nachbau (Reise 1–60): 4 Zeilen [WEG] … Luftlinie mit Werten ausserhalb 0–100 – die gefährlichste Stelle einer Luftlinie lag in keiner Zone
-- der Wegpunkte, und der Bericht nahm dann die Zone des Wegs. Jetzt: Zone über die Spielkarte (Geo:ZoneAt), sonst die Zone der Liste, in
-- deren Rahmen der Punkt am weitesten innen liegt (fest sortiert, wiederholbar). Ergebnis immer 0–100 oder nil.
function V.MapAt(inst, n, w)
    local G = LP.Geo
    local z = G.ZoneAt and G:ZoneAt(inst, n, w)
    if z then
        local x, y = G:ToMap(z, inst, n, w)
        if x and x >= 0 and x <= 100 and y >= 0 and y <= 100 then return z, x, y end
    end
    local ids = {}
    for id in pairs((LP.Names and LP.Names.ZONE_EN) or {}) do ids[#ids + 1] = id end
    table.sort(ids)
    local best, bx, by, bm
    for _, id in ipairs(ids) do
        local x, y = G:ToMap(id, inst, n, w)
        if x and x >= 0 and x <= 100 and y >= 0 and y <= 100 then
            local m = math.max(math.abs(x - 50), math.abs(y - 50))
            if not bm or m < bm then best, bx, by, bm = id, x, y, m end
        end
    end
    return best, bx, by
end

-- Pflichtregel "Mobs ab Level + 3": Verstoss notieren (Ziel = Ort/Quest, Weg = Wegstueck)
local function MobHit(kind, mob, what, map, x, y, via)
    local s = V.s
    if kind == "weg" then s.mobWay = s.mobWay + 1 else s.mobGoal = s.mobGoal + 1 end
    local key = kind .. tostring(what)
    for _, h in ipairs(s.mobHits) do if h.key == key then h.n = h.n + 1 return end end
    if #s.mobHits < 80 then
        s.mobHits[#s.mobHits + 1] = { key = key, kind = kind, mob = mob, lvl = s.level, what = tostring(what), map = map or s.map,
                                      x = x, y = y, via = via, n = 1 }
    end
end

local function CheckMobs(path, ti, tn, tw, map, what)
    local Dg = LP.Danger
    if not Dg then return end
    local s = V.s
    local lim = s.level + Dg.MAX_DIFF
    local st = s.current
    if st and (st.t == "COMPLETE" or st.t == "ACCEPT") and st.id then
        local q = LP.QuestDB:Get(st.id)
        local lv = q and not q.dungeon and LP.Planner.QuestMobLevel(q)
        if lv and lv >= lim then MobHit("quest", lv, what, map) return end
    end
    if st and st.t == "DUNGEON" then return end
    local dz = Dg:At(ti, tn, tw)
    if dz >= lim then MobHit("ziel", dz, what, map) return end
    -- wie die Planung: die ersten 150 Yards und der Weg hinaus aus einem Gebiet, in dem man schon steht, zaehlen nicht
    local worst, wi, wn, ww = Dg:PathDanger(path, 150, lim)
    if worst >= lim then
        -- Zone und Ort der gefaehrlichsten Stelle; Art der Verbindung dorthin
        local zm, via, bd = map, nil, nil
        for i = 2, #path do
            local a, b = path[i - 1], path[i]
            if a[1] == wi then
                local d = math.abs(a[2] - wn) + math.abs(a[3] - ww)
                if not bd or d < bd then bd, zm, via = d, a[4] or b[4] or map, b.via end
            end
        end
        local bx, by = LP.Geo:ToMap(zm, wi, wn, ww)
        -- Punkt liegt ausserhalb dieser Zone (z. B. y > 100): die Zone eines anderen Wegpunkts nehmen
        if not bx or bx < 0 or bx > 100 or by < 0 or by > 100 then
            for _, p in ipairs(path) do
                local z = p[4]
                local x2, y2
                if z then x2, y2 = LP.Geo:ToMap(z, wi, wn, ww) end
                if x2 and x2 >= 0 and x2 <= 100 and y2 >= 0 and y2 <= 100 then zm, bx, by = z, x2, y2 break end
            end
        end
        -- 3.13.19 LP-R1: liegt die Stelle in keiner Zone des Wegs (Luftlinie quer über eine dritte Zone), die Zone über die Lage suchen
        if not bx or bx < 0 or bx > 100 or by < 0 or by > 100 then
            local z2, x2, y2 = V.MapAt(wi, wn, ww)
            if z2 then zm, bx, by = z2, x2, y2 else bx, by = nil, nil end
        end
        MobHit("weg", worst, what, zm, bx, by, via)
    end
end

-- 3.12.68: Bestzeit je Stufe (LP.db.bestLevel, alle Charaktere) gegen die Reisezeit derselben Stufe
function V.BestRows(levelAt, best)
    best = best or (LP.db and LP.db.bestLevel) or {}
    local rows, sb, ss = {}, 0, 0
    for l = 1, 59 do
        local a, b = levelAt[l], levelAt[l + 1]
        local e = best[l]
        local bt = type(e) == "table" and tonumber(e.t)
        if a and b and bt and bt > 60 then
            local sim = b.t - a.t
            rows[#rows + 1] = { level = l, best = bt, sim = sim }
            sb, ss = sb + bt, ss + sim
        end
    end
    return rows, #rows > 0 and { best = sb, sim = ss } or nil
end

local function Travel(map, x, y, what)
    local s = V.s
    if not map or not x then return end
    local pi, pn, pw, pmap = LP.Geo:Player()
    local ti, tn, tw = LP.Geo:ToWorld(map, x, y)
    if pi and ti then
        local prevOK = LP.yieldOK              -- 3.13.17: Freigabe des Schritts danach wiederherstellen (vorher nil)
        LP.yieldOK = { graph = true }
        local path, kind = LP.Graph:Path(pi, pn, pw, pmap, ti, tn, tw, map)
        LP.yieldOK = prevOK
        if not path then
            Note("nopath", L("Kein Weg: %s » %s (%s)", LP.Geo:MapName(pmap), LP.Geo:MapName(map), tostring(what)))
            s.nopath = s.nopath + 1
        else
            local d = 0
            for i = 2, #path do
                local a, b = path[i - 1], path[i]
                if a[1] == b[1] then
                    local seg = math.sqrt((a[2] - b[2]) ^ 2 + (a[3] - b[3]) ^ 2)
                    d = d + seg
                    -- 3.13.2 (Auftrag 19.11. 11:00: "Anteil ohne Weg" je Version messbar): Strecke ohne bekannten Weg / gesamt
                    -- Zonenübergänge ("g": Verbindung zwischen zwei Zonen, keine gelaufene Strecke) zählen nicht
                    local noWay = b.via == "v" or kind == "direct"
                    if noWay or b.via ~= "g" then s.wayAll = (s.wayAll or 0) + seg end
                    if noWay then s.wayNo = (s.wayNo or 0) + seg end
                    if noWay and V.gapStats and seg >= V.GAP_MIN then
                        s.gaps = s.gaps or {}
                        local ka = math.floor(a[2] / 100) .. "," .. math.floor(a[3] / 100)
                        local kb = math.floor(b[2] / 100) .. "," .. math.floor(b[3] / 100)
                        local key = a[1] .. ":" .. (ka < kb and (ka .. ":" .. kb) or (kb .. ":" .. ka))
                        local g = s.gaps[key]
                        if not g then
                            local zm0 = a[4] or b[4] or map
                            if IsContinent(zm0) then zm0 = map end
                            g = { i = a[1], n1 = a[2], w1 = a[3], n2 = b[2], w2 = b[3], len = seg, n = 0, map = zm0 }
                            s.gaps[key] = g
                        end
                        g.n = g.n + 1
                    end
                    -- Abschnitt ohne bekannten Weg (Luftlinie): der Zone zuordnen, in der er beginnt
                    if (b.via == "v" or kind == "direct") and seg > LONG_DIRECT then
                        local zm = a[4] or b[4] or map
                        if IsContinent(zm) then zm = map end
                        local z = s.direct[zm] or { n = 0, max = 0 }
                        s.direct[zm] = z
                        z.n = z.n + 1
                        if seg > z.max then
                            -- Anfang des Wegstuecks in Koordinaten seiner Zone
                            local fx, fy = LP.Geo:ToMap(zm, a[1], a[2], a[3])
                            z.max, z.what, z.lvl, z.fx, z.fy = seg, what, s.level, fx or s.x, fy or s.y
                        end
                    end
                elseif b.via == "zep" or b.via == "boat" or b.via == "tram" or b.via == "portal" then
                    -- Zeppelin/Schiff: Wartezeit + Fahrt + Ladebildschirm (statt als Strecke gezaehlt)
                    local ts = b.secs or TRANSIT_SECS[b.via] or 300
                    s.clock = s.clock + ts
                    s.tTransit = (s.tTransit or 0) + ts
                else
                    d = d + 1000
                end
            end
            s.dist = s.dist + d
            local ws = d / (s.level >= 40 and RUN * 1.6 or RUN)
            s.clock = s.clock + ws
            s.tWalk = (s.tWalk or 0) + ws
            CheckMobs(path, ti, tn, tw, map, what)
            -- Speedrun: Monster, die auf dem Weg liegen und EP geben, im Vorbeigehen mitnehmen
            if LP.Planner:IsSpeed() and LP.Danger and not V.noWayKills then
                local grey = MobGreyDiff(s.level)
                -- nur Monster, die im Vorbeigehen mindestens so viele EP je Minute bringen wie das Questen
                -- (Questen mit Wegen: etwa die Haelfte der reinen Quest-Rate)
                local minLv
                local qr = LP.Planner.questRate
                if qr and qr > 0 and V.wayRateShare then
                    local need = qr * V.wayRateShare * WAY_KILL_TIME / (LP.Planner:KillXP(s.level, s.level) * LP.Planner:KillsPerMin())
                    if need >= 1 then minLv = s.level
                    elseif need > 0 then minLv = math.ceil(s.level - (1 - need) * (grey + 1)) end
                end
                local kills, sum, cand, cap = LP.Danger:WayKills(path, s.level, grey, WAY_KILL_YARDS, minLv)
                if (cand or 0) > 0 and cap == 0 then s.wayShort = (s.wayShort or 0) + 1 end   -- Weg kürzer als WAY_KILL_YARDS
                -- 3.13.8 LP-T1 (T174 belegen): Wege geprüft, Monster im Stufenband am Weg, durch die Untergrenze (Questen lohnt mehr) ausgelassen
                s.wayChecks = (s.wayChecks or 0) + 1
                s.wayCand = (s.wayCand or 0) + (cand or 0)
                if minLv then s.wayMinLv = minLv end
                if kills > 0 then
                    -- mittleres Level der Monster am Weg (viele gruene): EP nach Levelunterschied
                    local avg = sum / kills
                    local xp = math.floor(LP.Planner:KillXP(s.level, avg) * kills)
                    local bonus = math.min(xp, s.rested or 0)
                    s.rested = (s.rested or 0) - bonus
                    s.wayKills = (s.wayKills or 0) + kills
                    s.wayXP = (s.wayXP or 0) + xp + bonus
                    s.wayBonus = (s.wayBonus or 0) + bonus          -- Erholt-Anteil (Testroutine T174)
                    local ks = kills * 60 / LP.Planner:KillsPerMin() * WAY_KILL_TIME
                    s.clock = s.clock + ks
                    s.tWay = (s.tWay or 0) + ks
                    GainXP(xp + bonus)
                end
            end
            if V.watch then
                V.lastPath = path
                -- Spur der letzten Schritte fuer die Weltkarte (ein einzelner Schritt ist oft nur ein kurzer Strich)
                V.trail = V.trail or {}
                for i = (#V.trail > 0 and 2 or 1), #path do V.trail[#V.trail + 1] = path[i] end
                while #V.trail > TRAIL_MAX do table.remove(V.trail, 1) end
            end
        end
    elseif not ti then
        Note("nomap", L("Ziel ohne Weltkoordinaten: %s (%s)", LP.Geo:MapName(map), tostring(what)))
    end
    if map ~= s.map and not IsContinent(map) then
        local z = s.zones[#s.zones]
        if not z or z.map ~= map then
            local st = s.current
            s.zones[#s.zones + 1] = { map = map, lvl = s.level, what = what, t = st and st.t, id = st and st.id }
        end
    end
    s.map, s.x, s.y = map, x, y
end

local function LogIndex(id)
    for i, q in ipairs(V.s.log) do if q.id == id then return i, q end end
end

local last, same = nil, 0
-- ein Schritt der Reise; false = Reise zu Ende
local StepInner
-- 3.13.17 (Ingametest 3.13.16: Reise-Bilder bis 320 ms): belegt im Nachbau (lange Reise L1–60, Messung je LP.YPCall) – nach der Planung des
-- Schritts galt keine Freigabe mehr (LP.yieldOK = nil). Erledigt der Schritt ein Ziel, plant LP.Engine:Skip/Complete sofort neu
-- (Planner:Replan -> DoReplan); diese Planung lief dann ohne jede Abgabe am Stück (Nachbau bis 128 ms in einer Portion). Jetzt gilt die
-- Freigabe der Planung für den ganzen Schritt.
local function Step()
    local r = StepInner()
    LP.yieldOK = nil
    return r
end
StepInner = function()
    local s = V.s
    if s.level >= 60 then return false end
    if s.steps >= MAX_STEPS then Note("limit", L["Abbruch: zu viele Schritte"]) return false end
    s.steps = s.steps + 1
    local t0 = debugprofilestop and debugprofilestop() or 0
    local p0 = LP.yieldPaused or 0
    local m0 = collectgarbage("count")
    -- 3.13.21 LP-I3 (Prüfung 26.11. 13:12): Messzeile je Planung im Spiel – Wanduhr, Pausen je Art, Abgaben, Knoten, kalte Zwischenspeicher
    local GS, TRr = LP.Graph.stat, LP.TestRoutine
    -- (Aufträge laufen in der Reise über Jobs.JourneyPCall -> LP:Yield, ihre Pausen stecken in LP.yieldPaused)
    local q0 = { yn = LP.yieldN or 0, tp = TRr and TRr.pausedMs or 0,
                 exp = GS.exp, nm = GS.nearMiss, um = GS.unkMiss, uw = GS.unkWipe, nw = GS.nearWipe }
    LP.yieldOK = { plan = true, graph = true }
    local N = LP.Nav
    if N then N.holdRecalc, N.recalcPending, N.recalcPendingForce = true, nil, nil end
    -- 3.13.10 LP-T1-R: Trainerbesuch je Schritt prüfen (vorher vom 30-s-Ticker des Assistenten, abhängig von der Startzeit der Reise)
    if LP.Hints and LP.Hints.TrainerVisit and LP.db.hintTrainer ~= false then LP.PCall(LP.Hints.TrainerVisit, LP:PlayerLevel(), false) end   -- 3.13.15 LP-Y1: abgabefähig (LP.YPCall)
    LP.Planner:DoReplan()               -- direkt: in der Coroutine darf die Planung pausieren (Fehler: Sperre löst pcall(Step))
    if N then N.holdRecalc = nil end
    -- 3.13.17: Freigabe bleibt für den Rest des Schritts (Step setzt sie am Ende zurück)
    -- reine Rechenzeit (3.12.6): Pausen zwischen den Bildern zaehlen nicht
    local wall = debugprofilestop and (debugprofilestop() - t0) or 0
    local ms = math.max(0, wall - ((LP.yieldPaused or 0) - p0))
    s.planMs = (s.planMs or 0) + ms
    s.planN = (s.planN or 0) + 1
    -- 3.12.97 (Ingametest 3.12.95 T155: 28,5 -> 31,2 -> 40,5 ms, im Nachbau mit gleichen Daten 3.12.93 11,3 / 3.12.96 8,5 ms): je
    -- Planung Zeit und Speicher behalten – Median gegen Mittelwert zeigt Ausreisser (z. B. Speicherbereinigung im Planungsbild);
    -- Speicher fällt in der Planung = Bereinigung lief darin
    s.planList = s.planList or {}
    if #s.planList < 400 then
        local dm = collectgarbage("count") - m0
        s.planList[#s.planList + 1] = { ms = ms, kb = dm, lvl = s.level or (LP.PlayerLevel and LP:PlayerLevel()), map = s.map,
                                        step = s.steps, n = s.planN,   -- 3.12.98: wo die Ausreisser liegen (T155)
                                        wall = wall, yp = (LP.yieldPaused or 0) - p0, yn = (LP.yieldN or 0) - q0.yn,
                                        tp = (TRr and TRr.pausedMs or 0) - q0.tp, exp = GS.exp - q0.exp, nm = GS.nearMiss - q0.nm,
                                        um = GS.unkMiss - q0.um, uw = GS.unkWipe - q0.uw, nw = GS.nearWipe - q0.nw }
    end
    -- 3.12.98: zurückgehaltene Neuberechnung der Navigation jetzt (ausserhalb der Planungsmessung)
    if N and N.recalcPending then
        local force = N.recalcPendingForce
        N.recalcPending, N.recalcPendingForce = nil, nil
        N:Recalc(force)
    end
    local st = LP.Engine:Current()
    s.current = st
    if not st then
        Note("noroute", L("Keine Schritte geplant auf Level %d", s.level))
        GainXP(math.floor(LP.Planner:KillXP(s.level, s.level) * LP.Planner:KillsPerMin() * 10))   -- 10 Minuten Monster
        s.clock = s.clock + 600
        s.grind = s.grind + 1
        s.tGrind = (s.tGrind or 0) + 600
        return true
    end
    if st.key == "NODATA" or st.key == "NOPOS" then
        Note("noroute", L("Planung ohne Daten oder Position (%s) – Reise beendet", st.key))
        return false
    end
    local key = st.key .. ":" .. #s.log .. ":" .. s.level .. ":" .. s.xp
    if key == last then same = same + 1 else same, last = 0, key end
    if same >= 4 then
        Note("stall", L("Plan hängt bei %s „%s“ – übersprungen", st.t, tostring(st.q or st.text or st.key):sub(1, 50)))
        LP.Engine:Skip(st)
        s.skipped = s.skipped + 1
        same = 0
        return true
    end
    local what = st.q or st.text or st.npc or st.t
    if st.t == "ACCEPT" then
        Travel(st.map, st.x, st.y, what)
        if #s.log < LP.API.MaxQuests() and not LogIndex(st.id) then
            local objs, q = QuestObjs(st.id)
            s.log[#s.log + 1] = { id = st.id, title = st.q or (q and q.name) or ("#" .. st.id), level = q and q.level or s.level,
                                  complete = #objs == 0, objs = objs, elite = q and q.elite, escort = q and q.escort }
            s.accepted = s.accepted + 1
        else
            s.char.notOffered[st.id] = LP:Now()
        end
        s.clock = s.clock + 10
    elseif st.t == "COMPLETE" then
        local i, q = LogIndex(st.id)
        if not q then
            Note("error", L("Erledigen ohne Quest im Log: %s", tostring(st.q or st.id)))
            LP.Engine:Skip(st)
        else
            Travel(st.map, st.x, st.y, what)
            local P = LP.Planner
            local dq = LP.QuestDB:Get(st.id)
            local ci, cn, cw = LP.Geo:ToWorld(s.map, s.x, s.y)
            local r2 = P.BUNDLE_R * P.BUNDLE_R
            local function Near(po)
                if not (po and ci) then return nil end
                local best
                for _, pt in ipairs(P.ObjPoints(po)) do
                    if pt[1] == ci then
                        local a, b = pt[2] - cn, pt[3] - cw
                        local d = a * a + b * b
                        if not best or d < best then best = d end
                    end
                end
                return best
            end
            local function Finish(o)
                o.finished, o.have = true, o.need or 1
                o.text = o.text:gsub("0/1", "1/1")
            end
            -- das offene Ziel, das hier liegt (sonst das erste offene)
            local pick, pd
            for oi, o in ipairs(q.objs) do
                if not o.finished then
                    local d = Near(dq and dq.objectives and dq.objectives[oi]) or math.huge
                    if not pick or d < pd then pick, pd = oi, d end
                end
            end
            local secs, kills = 90, 3
            local main = pick and dq and dq.objectives and dq.objectives[pick]
            if pick then
                local o = q.objs[pick]
                Finish(o)
                -- gleiches Modell wie die Planung (Kills pro Minute der Klasse bzw. gemessen, Dropraten)
                secs, kills = P:ObjectiveCost(o.kind, o.elite, main, (o.need or 1) > 1 and o.need or nil)
                if pick == 1 and q.escort then secs = secs + 480 end
            end
            -- Buendeln: offene Ziele aller Quests im Log, die hier liegen, im selben Durchgang (ohne neue Suche;
            -- Kills derselben Gegner zaehlen fuer beide Ziele)
            if ci and not (dq and dq.dungeon) then
                local ids = {}
                for _, id in ipairs(main and main.ids or {}) do ids[id] = true end
                for _, q2 in ipairs(s.log) do
                    local d2 = q2.complete and nil or LP.QuestDB:Get(q2.id)
                    if d2 and not d2.dungeon then
                        for oi2, o2 in ipairs(q2.objs) do
                            local po = d2.objectives and d2.objectives[oi2]
                            local ml = po and po.mobLevel and (po.mobLevel + (po.elite and LP.Danger.ELITE_BONUS or 0))
                            local near = po and not o2.finished and not po.elite and (Near(po) or math.huge) <= r2
                            if near and (not ml or LP.Danger:OK(ml, s.level)) then
                                Finish(o2)
                                local _, k2 = P:ObjectiveCost(po.kind, false, po, (o2.need or 1) > 1 and o2.need or nil)
                                local same = false
                                for _, id in ipairs(po.ids or {}) do if ids[id] then same = true end end
                                local f = same and 0.5 or 1
                                local add = k2 * f * 60 / P:KillsPerMin() + ((po.kind == "object") and 30 or 0)
                                secs, kills = secs + add, kills + k2 * f
                                s.bundled = (s.bundled or 0) + 1
                                local all = true
                                for _, x in ipairs(q2.objs) do if not x.finished then all = false end end
                                q2.complete = all
                            end
                        end
                    end
                end
            end
            local done = true
            for _, o in ipairs(q.objs) do if not o.finished then done = false end end
            q.complete = done
            s.clock = s.clock + secs
            s.tObj = (s.tObj or 0) + secs
            -- Monster beim Questen: Level der Questgegner (sonst Questlevel)
            local xp = math.floor(P:KillXP(s.level, P:QuestKillLevel(dq, s.level)) * kills)
            local bonus = math.min(xp, s.rested or 0)          -- Erholungsbonus gilt auch fuer Monster beim Questen
            s.rested = (s.rested or 0) - bonus
            GainXP(xp + bonus)
        end
    elseif st.t == "TURNIN" then
        local i, q = LogIndex(st.id)
        Travel(st.map, st.x, st.y, what)
        if q then
            table.remove(s.log, i)
            s.done[st.id] = true
            s.char.turnedIn[st.id] = true
            s.quests = s.quests + 1
            local dq = LP.QuestDB:Get(st.id)
            GainXP(math.floor(QuestXP(st.id) * ((dq and dq.dungeon) and LP.Planner:DungeonQuestFactor() or 1)))
        else
            Note("error", L("Abgeben ohne Quest im Log: %s", tostring(st.q or st.id)))
            LP.Engine:Skip(st)
        end
        s.clock = s.clock + 10
    elseif st.t == "LEVEL" then
        if st.map and st.x then Travel(st.map, st.x, st.y, what) end   -- zur Stelle mit passenden Monstern
        local xp = math.floor(LP.Planner:KillXP(s.level, st.grindLevel or s.level) * LP.Planner:KillsPerMin() * 10)
        -- Erholungsbonus: doppelte Monster-EP, bis der Puffer aufgebraucht ist
        local bonus = math.min(xp, s.rested or 0)
        s.rested = (s.rested or 0) - bonus
        GainXP(xp + bonus)
        s.clock = s.clock + 600
        s.grind = s.grind + 1
        s.tGrind = (s.tGrind or 0) + 600
    elseif st.t == "FP" then
        Travel(st.map, st.x, st.y, what)
        -- Flugpunkt lernen: bekannter Knoten an dieser Stelle, sonst ein eigener Knoten am Flugmeister
        local fi, fn, fw = LP.Geo:ToWorld(st.map, st.x, st.y)
        local node, nd
        for name, tx in pairs(saved.taxi or {}) do
            if type(tx) == "table" and tx.map then
                local _, _, _, ti, tn, tw = LP.Geo:TaxiPoint(tx)
                if ti and ti == fi then
                    local d = LP.Geo:Dist(fn, fw, tn, tw)
                    if d < 200 and (not nd or d < nd) then node, nd = name, d end
                end
            end
        end
        if not node and st.npc then
            node = st.npc
            s.taxi[node] = { name = node, map = st.map, x = st.x, y = st.y }
        end
        if node and not s.char.taxiKnown[node] then s.fpGot = (s.fpGot or 0) + 1 end
        if node then s.char.taxiKnown[node] = true end
        s.char.fpVisited[(st.npc or "?") .. ":" .. tostring(st.map)] = true
        s.char.doneKeys[st.key] = true
        s.clock = s.clock + 10
    elseif st.t == "FLY" then
        Travel(st.map, st.x, st.y, what)
        local dest = LP.db.taxi and LP.db.taxi[st.text]
        local dm, dx, dy, di, dn, dw = LP.Geo:TaxiPoint(dest)
        -- Flugpunkte muss man erst holen (hinlaufen, Flugmeister ansprechen): nur zwischen geholten fliegen
        local known = s.char.taxiKnown or {}
        if not known[st.text] or (st.from and not known[st.from]) then
            s.flyUnknown = (s.flyUnknown or 0) + 1
            Note("fly", L("Flug über einen nicht geholten Flugpunkt: %s", tostring(not known[st.text] and st.text or st.from)))
            dm = nil
        end
        if dm then
            -- Flugdauer nach Strecke (Flugrouten machen Umwege) statt fest 2 Minuten
            local fi, fn, fw = LP.Geo:ToWorld(s.map, s.x, s.y)
            local secs = 120
            if fi and fi == di then
                local dist = LP.Geo:Dist(fn, fw, dn, dw)
                -- gelernte echte Flugdauer, sonst Annahme (Geschwindigkeit, Umweg, Start/Landung)
                secs = (LP.Calib and LP.Calib:FlightSecs(dist)) or (FLY_START + dist * FLY_DETOUR / FLY_YPS)
            end
            s.clock = s.clock + secs
            s.tFly = (s.tFly or 0) + secs
            s.flights = s.flights + 1
            s.map, s.x, s.y = dm, dx, dy
        else
            Note("fly", L("Flugziel unbekannt: %s", tostring(st.text)))
        end
        s.char.doneKeys[st.key] = true
    elseif st.t == "BIND" then
        Travel(st.map, st.x, st.y, what)
        s.char.bind = { map = st.map, x = st.x, y = st.y, name = st.text }
        s.char.doneKeys[st.key] = true
    elseif st.t == "HEARTH" then
        local b = s.char.bind
        if b and b.map then s.map, s.x, s.y = b.map, b.x, b.y s.clock = s.clock + 20 s.hearths = s.hearths + 1 s.hearthAt = s.clock end
        s.char.doneKeys[st.key] = true
    elseif st.t == "DUNGEON" and not st.inside then
        Travel(st.map, st.x, st.y, what)
        local n = 0
        for _, q in ipairs(s.log) do
            local dq = LP.QuestDB:Get(q.id)
            if dq and dq.dungeon and (dq.dungeon == st.area) then
                for _, o in ipairs(q.objs) do o.finished, o.have = true, 1 end
                q.complete = true
                n = n + 1
            end
        end
        if n == 0 then
            Note("dungeon", L("Dungeon ohne passende Quests im Log: %s", tostring(st.q)))
            LP.Engine:Skip(st)
        else
            s.dungeons[#s.dungeons + 1] = L("L%d %s (%d Quests)", s.level, tostring(st.q), n)
            s.clock = s.clock + 45 * 60 + 7 * 60 * n
            s.tDungeon = (s.tDungeon or 0) + 45 * 60 + 7 * 60 * n
            GainXP(math.floor(LP.Planner:KillXPFormula(s.level, s.level) * 60 * LP.Planner:DungeonXPFactor()))   -- 60 Kills, EP schon geteilt
        end
        s.char.dungeonRun[st.area] = s.level
    else
        if st.map and st.x then Travel(st.map, st.x, st.y, what) end
        s.char.doneKeys[st.key] = true
        LP.Engine:Skip(st)
    end
    return true
end
V.Step = Step

------------------------------------------------------------------------
-- Ablauf
------------------------------------------------------------------------
local ticker
-- 3.12.90 (Ingametest 3.12.89 T83/T85): nach dem Rueckbau darf keine Ersatz-Funktion der Reise mehr eingesetzt sein
function V.LeftRedirects()
    local API, Geo = LP.API, LP.Geo
    local cur = { ["API.Quests"] = API.Quests, ["API.Objectives"] = API.Objectives, ["API.QuestCount"] = API.QuestCount,
                  ["API.IsQuestDone"] = API.IsQuestDone, ["Geo.Player"] = Geo.Player, ["API.HearthReady"] = API.HearthReady }
    local left = {}
    for name, fn in pairs(V.repl or {}) do if cur[name] == fn then left[#left + 1] = name end end
    if LevelPilotCharDB and LP.char ~= LevelPilotCharDB then left[#left + 1] = "LP.char" end
    table.sort(left)
    return left
end

-- 3.13.14 LP-SB1: Zeilen zur Sandbox im Bericht – FEHLER (Änderung der echten Daten), HINWEIS (Empfang während der Reise) und
-- Schreibzugriffe mit Herkunft stehen getrennt (T391)
function V.SandboxLines(s)
    local out = {}
    local function A(x) out[#out + 1] = x end
    if s.sandboxDiff then
        if #s.sandboxDiff == 0 then A(L["Sandbox: echte Daten unverändert (OK)"])
        else A(L("FEHLER Sandbox: echte Daten verändert – %s", table.concat(s.sandboxDiff, ", "))) end
    else
        A(L["Sandbox: Prüfung am Ende der Reise"])
    end
    -- 3.13.14 LP-SB1: was andere Spieler während der Reise geschickt haben (wartet, wird danach eingespielt) – HINWEIS, kein FEHLER
    if s.heldNet and next(s.heldNet) then
        local kinds = {}
        for k, n in pairs(s.heldNet) do kinds[#kinds + 1] = k .. " " .. n end
        table.sort(kinds)
        A(L("HINWEIS Sandbox: während der Reise von anderen Spielern empfangen (Art Anzahl): %s – nach der Reise eingespielt, nichts verloren",
            table.concat(kinds, ", ")))
    end
    return out
end
-- 3.13.14 LP-SB1 a): neue Wegpunkte/Wegstücke im echten Netz während der Reise, mit Herkunft (Datei:Zeile des Aufrufers). Seit der
-- Empfang wartet, kann das nur eigener Code sein -> gehört zu den Änderungen (FEHLER), auch wenn die Anzahl am Ende gleich wäre.
function V.WritesText(s)
    if not (s.realWrites and next(s.realWrites)) then return nil end
    local w = {}
    for k, n in pairs(s.realWrites) do w[#w + 1] = k .. " ×" .. n end
    table.sort(w)
    return L("Schreibzugriffe auf das echte Wegnetz während der Reise: %s", table.concat(w, ", "))
end

local function Finish(reason)
    if LP.Nav then LP.Nav.holdRecalc, LP.Nav.recalcPending, LP.Nav.recalcPendingForce = nil, nil, nil end   -- 3.12.98: Sperre lösen
    if ticker then if ticker.Cancel then ticker:Cancel() end ticker = nil end V.token = (V.token or 0) + 1
    LP.yieldCo, LP.yieldOK = nil, nil
    -- zuerst die echten Daten zurueck (auch wenn danach etwas schiefgeht), dann pruefen und berichten
    V.active = false
    Uninstall()
    V.s.fpAfter = V:Fingerprint()
    V.s.sandboxDiff = CompareFingerprint(V.s.fpBefore, V.s.fpAfter)
    local wt = V.WritesText(V.s)
    if wt then V.s.sandboxDiff[#V.s.sandboxDiff + 1] = wt end
    for _, name in ipairs(V.LeftRedirects()) do V.s.sandboxDiff[#V.s.sandboxDiff + 1] = L("Umleitung geblieben: %s", name) end
    V.repl = nil
    if #V.s.sandboxDiff > 0 and LP.Protocol then
        LP.Protocol:AddL("sandbox", "Virtuelle Reise hat echte Daten verändert: %s", table.concat(V.s.sandboxDiff, ", "))
    end
    local okR, report = pcall(V.Report, V, reason)
    if not okR then
        LP.Report("Reise-Bericht", report)
        report = L("Bericht konnte nicht erstellt werden: %s", tostring(report))
    end
    V.lastReport = report
    LP.Planner:BuildCandidates()
    LP.Planner:Replan(true)
    if LP.Nav then LP.Nav:Recalc(true) end
    if LP.UI then LP.UI:Refresh() end
    V:UpdateWindow()
    if LP.Protocol then
        local p = 0
        for _, e in ipairs(V.s.problems) do if e.kind ~= "limit" then p = p + 1 end end
        LP.Protocol:AddL("journey", "Virtuelle Reise L%d–%d: %d Auffälligkeit(en)", V.s.startLevel, V.s.level, p)
    end
    LP:Reply(L["Virtuelle Reise beendet – Bericht mit „Bericht“ oder /lp reise bericht."])
    -- 3.13.14 LP-SB1: was während der Reise empfangen wurde, jetzt einspielen (nach dem Fingerabdruck, in Portionen)
    if LP.Comm and LP.Comm.ReplayHeld and LP.Comm.held and #LP.Comm.held > 0 then LP.Comm:ReplayHeld() end
    if V.onDone then local cb = V.onDone V.onDone = nil LP.Try("Reise-Abschluss", cb, report, V.s) return report end
    if not V.silent then LP.Backup:ShowText(L["Virtuelle Reise – Bericht"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."], report) end
    return report
end

-- startLevel: 1 = ab Startgebiet; "here" = ab aktuellem Level und Ort des echten Charakters
-- Schwere Arbeit beim Start (in der Reise selbst, nicht im Chat-Befehl - sonst "script ran too long"):
-- echtes Questlog lesen (Reise ab hier), einrichten, Quest-Kandidaten aufbauen
local function Prepare()
    local s = V.s
    if s.here and not s.logRead then
        LP.yieldOK = { plan = true }
        for qi, q in ipairs(LP.API.Quests()) do
            local objs = {}
            for _, o in ipairs(LP.API.Objectives(q.index)) do
                objs[#objs + 1] = { text = o.text or "?", finished = o.finished, have = o.have or 0, need = o.need or 1, type = o.type,
                                    kind = ({ monster = "kill", item = "item", object = "object", event = "explore" })[o.type or ""] or "item" }
            end
            local dq = LP.QuestDB:Get(q.id)
            s.log[#s.log + 1] = { id = q.id, title = q.title, level = q.level or s.level, complete = q.complete, objs = objs,
                                  elite = dq and dq.elite, escort = dq and dq.escort }
            if qi % 3 == 0 then LP:Yield("plan") end
        end
        s.logRead = true
    end
    if not saved.installed then Install() end
    LP.yieldOK = { plan = true }
    LP.Planner:BuildCandidates()
    LP.yieldOK = nil
    V.ready = true
end

-- 3.13.8 LP-T1: erlaubte Abgabestellen je Portion in der Testroutine (Nachbau: 20 -> Median 10 ms, 50 -> 22 ms je Portion).
-- 3.13.13: 32 – seit Aufträge in der Reise abgeben und die Freigabe über die Pause gilt, sind die Portionen viel kleiner. Nachbau
-- (Stufe 30, Laptop- und PC-Daten): mit 16 kam die kurze Reise in 240 s nur bis Schritt 19 und T381 wich ab (Lauf 2 mit warmen
-- Zwischenspeichern kam weiter); mit 32 ganze Reisen, T381 gleich, längste Portion 29,9 / 38,8 ms (vorher bis 450 ms).
-- 3.13.17 (Ingametest 3.13.16: Reise-Bilder bis 320 ms, 705 über 16 ms, 24 über 40 ms; Nachbau lange Reise L1–60: längstes 150,5 ms, 267 / 27):
-- belegt im Nachbau – ein Bild endete erst NACH der Portion, in der das Budget (8 ms) überschritten war, und eine Portion von 32 Abgabestellen
-- dauert an teuren Stellen lange (Mittel je Abstand: Planner.lua 437/942/956 0,5–0,7 ms -> 32 × 0,7 = 22 ms; Terrain 0,22 ms). Jetzt 8
-- Abgabestellen je Portion und je Bild nur so viele Portionen, dass das Bild voraussichtlich unter V.FRAME_TARGET bleibt (längste Portion
-- dieses Bildes als Vorhersage). Die Grenzen der Portionen bleiben gezählt; zwischen zwei Portionen im selben Bild läuft kein anderer Code.
-- 3.13.17 LP-TR3 (Ingametest 3.13.17: Reisen 1 086 s statt 992 s mit 3.13.16): mit 8 prüfte die Reise 4-mal so oft den Stapel auf C-Grenzen
-- (LP.YieldBlocked, Nachbau 16,7 µs je Prüfung = 13,5 % der Rechenzeit der Reise). Nachbau lange Reise ohne Messhülle: 8 -> Reisen 1 023 s,
-- längstes Bild 28,4 ms, ohne Speicherbereinigung 4 Bilder über 16 ms; 16 -> 912 s, 31,2 ms, 8 Bilder; keines über 40 ms. Gewählt: 16.
V.SLICE_CALLS = 16
V.FRAME_TARGET = 12          -- ms je Bild (Ziel: ganzes Bild <= 16 ms)
V.FRAME_RUNS = 256           -- höchstens so viele Portionen je Bild
V.ROUTINE_BUDGET = 10        -- 3.13.19: ms Rechenzeit der Reise je Bild in der Testroutine (abgegeben nach Uhr, s. Zeitgeber)
function V:Start(mode, opts)
    if self.active then return end
    opts = opts or {}
    -- 3.12.87: Orte (Häufung der Questgeber) einmal vor der Reise bauen, nicht in der ersten Planung der Reise (sonst zählt der
    -- einmalige Aufbau als Planungszeit eines Reiseschritts)
    if LP.Orte and LP.Orte.BuildNow and LP.Orte.Available() then LP.Orte.BuildNow() end
    local _, race = UnitRace("player")
    local here = (mode == "here")
    local level = here and LP:RealLevel() or 1
    local s = {
        level = level, xp = 0, xpMax = XPNEED[level] or 1, log = {}, done = {}, clock = 0, steps = 0,
        quests = 0, accepted = 0, dist = 0, nopath = 0, skipped = 0, grind = 0, flights = 0, hearths = 0,
        slowest = 0, problems = {}, seen = {}, zones = {}, levelAt = {}, dungeons = {}, direct = {}, gaps = {}, startLevel = level,
        mobHits = {}, mobGoal = 0, mobWay = 0,
        startTime = GetTime(),
    }
    s.here = here
    if here then
        local _, _, _, map, x, y = LP.Geo:Player()
        s.map, s.x, s.y = map, x, y
        local xp, mx, readable = LP:PlayerXP()                     -- 3.12.14: geschuetzte EP nie benutzen
        s.xp = xp
        if readable then s.xpMax = mx end
        s.rested = GetXPExhaustion and LP.SafeValue(GetXPExhaustion()) or 0      -- Erholungsbonus des echten Charakters
        if type(s.rested) ~= "number" then s.rested = 0 end
        -- 3.13.13 LP-I8: Erholungsbonus vorgeben (Testroutine T381: beide Läufe mit demselben Wert – in einer Stadt wächst er zwischen
        -- zwei Reisen, das gäbe mehr Bonus-EP im zweiten Lauf)
        if type(opts.rested) == "number" then s.rested = opts.rested end
        s.doneFallback = LP.API.IsQuestDone
        -- Ruhestein: echte Abklingzeit uebernehmen
        local cd = LP.API.ItemCooldown and LP.API.ItemCooldown(LP.API.HEARTHSTONE) or 0
        if cd and cd > 0 then s.hearthAt = -(3600 - cd) end
    end
    if not s.map then
        local st = (LP.Planner.RACE_START or START)[race] or START[race] or START.Human
        s.map, s.x, s.y = st[1], st[2], st[3]
        s.x, s.y = LP.Geo:FromData(s.map, s.x, s.y)       -- 3.12.55 LW-5: Startpunkte im Forever-Rahmen
    end
    s.forceMode = opts.mode
    s.fpBefore = self:Fingerprint()       -- Sandbox-Pruefung: echte Daten vorher
    self.s = s
    self.active = true
    self.ready = false
    self.watch = opts.watch and true or false
    self.silent = opts.silent
    self.paused = false
    self.stopRequested = false
    self.maxLevel = opts.maxLevel
    self.onDone = opts.onDone
    self.nextWatch = nil
    self.trail, self.lastPath = {}, nil
    last, same = nil, 0
    s.levelAt[level] = { t = 0, q = 0, zone = s.map }
    s.zones[1] = { map = s.map, lvl = level }
    LP:Reply(L("Virtuelle Reise ab Level %d in %s gestartet. Dein Charakter bewegt sich nicht; es wird nichts aufgezeichnet.", level, LP.Geo:MapName(s.map)))
    self:ShowWindow()
    V.token = (V.token or 0) + 1
    local token = V.token
    local function body()
        LP.MarkYieldBase()                -- 3.13.15 LP-Y1: Eichung der Prüfung auf C-Grenzen (LP.YieldBlocked)
        Prepare()                         -- Questlog lesen, einrichten, Kandidaten (darf pausieren)
        while V.active and not V.stopRequested do
            local more = Step()
            if not more or (V.maxLevel and V.s.level >= V.maxLevel) then break end
            if V.watch then coroutine.yield("watch") end
        end
    end
    local co = coroutine.create(body)
    LP.yieldCo = co
    V.pausedYieldOK = nil
    -- 3.13.13: jedes Bild statt alle 0,05 s – die Portionen der Reise sind jetzt klein (Aufträge geben in der Reise ab, s. Jobs.JourneyPCall);
    -- bei 0,05 s kam die Reise in der Testroutine in ihren 240 s nur noch bis Schritt 19 (Nachbau, vorher 65). Die Abgabestellen bleiben
    -- gezählt (LP.sliceCalls), wiederholbar wie bisher.
    ticker = C_Timer.NewTicker(0.001, function() LP:Safe("journey", function()
        if token ~= V.token or not V.active then return end
        if V.stopRequested then V.stopRequested = false Finish("stop") return end
        if V.paused then return end
        -- Zuschauen: nach jedem fertigen Schritt (nicht nach jedem Rechenhaeppchen) eine Weile stehen bleiben
        if V.watch and GetTime() < (V.nextWatch or 0) then return end
        LP.sliceStart = debugprofilestop and debugprofilestop() or 0
        -- 3.13.19 LP-TR3 (Ingametest 3.13.18: Reisen 985 s, aber 106 Bilder über 16 ms, nur 7 mit Bereinigung; längste Portion 23,4 ms):
        -- auch in der Testroutine nach ZEIT abgeben (wie ausserhalb), Budget V.ROUTINE_BUDGET je Bild. Die Stapelprüfung (LP.YieldBlocked)
        -- läuft nur noch einmal je Bild statt je gezählter Portion. Die festen Portionen (3.13.8 LP-T1) waren für die Wiederholbarkeit
        -- da; Gegenprobe 26.11.: drei Reisen L1–60 gleichzeitig mit Abgaben nach Uhr (also an verschiedenen Stellen) ergeben genau dasselbe
        -- (141 h 30, 2 344 Schritte, 814 Quests, 1 446 112 yd – wie am Stück). Was 3.13.8 verschieden machte (Empfang, questRate), ist seit
        -- 3.13.13/3.13.14 aus der Reise heraus. T381 prüft die Wiederholbarkeit weiter in jedem Lauf.
        local inRoutine = LP.TestRoutine and LP.TestRoutine.running
        LP.sliceBudget = inRoutine and V.ROUTINE_BUDGET or 8
        LP.sliceCalls = nil
        LP.sliceCount = 0
        -- 3.13.13: die Freigabe der Abgabe (LP.yieldOK) gilt über die Pause hinweg weiter. Bisher setzte der Zeitgeber sie nach jeder
        -- Portion auf nil – eine Planung gab dann nur in ihrer ersten Portion ab und rechnete den Rest am Stück (Nachbau Laptop-Daten,
        -- Stufe 30: Portionen der Reise bis 450 ms). Ausserhalb der Reise bleibt sie nil.
        LP.yieldOK = V.pausedYieldOK
        V.pausedYieldOK = nil
        -- 3.13.16 LP-TR2 (Ingametest 3.13.15: Reise 2,95 s je Schritt statt 0,19 s): in der Testroutine war je Bild nur EINE Portion von
        -- 32 Abgabestellen dran – seit die Wegsuchen in der Reise wirklich abgeben, sind das oft nur Bruchteile einer ms (Nachbau Stufe 30:
        -- 27 063 Portionen für 3 kurze Reisen, ~140 je Schritt). Jetzt je Bild weitere Portionen, solange das Budget (8 ms) reicht. Die
        -- Grenzen der Portionen bleiben gezählt; zwischen zwei Portionen im selben Bild läuft kein anderer Code.
        local ok, err
        local tickStart = LP.sliceStart
        local runs = 0
        local longest = 0
        local m0 = collectgarbage("count")
        repeat
            LP.sliceCount = 0
            local r0 = debugprofilestop and debugprofilestop() or 0
            ok, err = coroutine.resume(co)
            runs = runs + 1
            local now = debugprofilestop and debugprofilestop() or 1e9
            if now - r0 > longest then longest = now - r0 end
            if not (ok and err == nil and coroutine.status(co) == "suspended" and LP.sliceCalls and token == V.token and V.active
                    and not V.stopRequested and not V.paused and not V.watch) then break end
            -- 3.13.17: nächste Portion nur, wenn sie voraussichtlich noch ins Ziel passt (längste Portion dieses Bildes als Vorhersage)
        until (now - tickStart) + longest > V.FRAME_TARGET or runs >= V.FRAME_RUNS
        V.tickRuns = runs
        -- 3.13.16 LP-TR2: Bilder der Reise messen (Testroutine: Feld "reiseBilder")
        local ts = V.tickStats
        if ts and debugprofilestop then
            local ms = debugprofilestop() - tickStart
            ts.n = ts.n + 1
            if ms > ts.max then ts.max = ms end
            if ms > 16 then ts.o16 = ts.o16 + 1 end
            if ms > 40 then ts.o40 = ts.o40 + 1 end
            -- 3.13.17: Bilder über 16 ms, in denen der Speicher fiel (Speicherbereinigung des Spiels) getrennt zählen
            if ms > 16 and collectgarbage("count") < m0 - 1024 then ts.gc16 = (ts.gc16 or 0) + 1 end
            ts.lastLongest = longest
            if longest > (ts.portionMax or 0) then ts.portionMax = longest end
            ts.runs = ts.runs + runs
        end
        if ok and err == "watch" then V.nextWatch = GetTime() + (V.watchDelay or 2) end
        if ok and coroutine.status(co) == "suspended" then V.pausedYieldOK = LP.yieldOK end
        LP.yieldOK = nil
        if not ok then
            -- Fehler in einem Schritt: notieren, Schritt auslassen, weiter
            if LP.Nav then LP.Nav.holdRecalc = nil end        -- 3.12.98: Sperre der Navigation nie stehen lassen
            Note("error", L("Fehler in der Reise: %s", tostring(err)))
            pcall(LP.Engine.Skip, LP.Engine, V.s.current)
            co = coroutine.create(body)
            LP.yieldCo = co
        elseif coroutine.status(co) == "dead" then
            Finish(V.s.level >= 60 and "done" or "stop")
            return
        end
        if V.watch then
            if LP.Nav then pcall(LP.Nav.Recalc, LP.Nav, true) end
            if WorldMapFrame and WorldMapFrame:IsShown() and WorldMapFrame.SetMapID then pcall(WorldMapFrame.SetMapID, WorldMapFrame, V.s.map) end
            if LP.UI then pcall(LP.UI.Refresh, LP.UI) end
        end
        V:UpdateWindow()
    end) end)
end

-- Sofort zurueckbauen ohne Bericht und Neuplanung (Ausloggen, /reload): echte Tabellen muessen
-- gespeichert werden, nie die virtuellen Kopien
function V:Abort()
    if LP.Nav then LP.Nav.holdRecalc, LP.Nav.recalcPending, LP.Nav.recalcPendingForce = nil, nil, nil end   -- 3.12.98: Sperre lösen
    if not self.active then return end
    if ticker then if ticker.Cancel then ticker:Cancel() end ticker = nil end
    V.token = (V.token or 0) + 1
    LP.yieldCo, LP.yieldOK = nil, nil
    self.active = false
    Uninstall()
    local left = V.LeftRedirects()
    if #left > 0 and LP.Protocol then
        LP.Protocol:AddL("sandbox", "Virtuelle Reise hat echte Daten verändert: %s", table.concat(left, ", "))
    end
    V.lastLeft = #left > 0 and left or nil
    V.repl = nil
    -- 3.13.15 LP-SB1-b: auch nach einem Abbruch (Backup, Testroutine) einspielen, was während der Reise ankam – vorher wartete es bis zum
    -- Ende der nächsten Reise. Beim Ausloggen sofort am Stück (danach ist es weg); Anzahl und Zeit stehen in LP.db.net.logoutReplay.
    local C = LP.Comm
    if C and C.held and #C.held > 0 and C.ReplayHeld then
        if V.loggingOut then
            local t0 = debugprofilestop and debugprofilestop() or 0
            local n = #C.held
            C:ReplayHeld(true)
            if LP.db and LP.db.net then
                LP.db.net.logoutReplay = { n = n, ms = (debugprofilestop and debugprofilestop() or 0) - t0, t = time and time() or 0 }
            end
        else
            C:ReplayHeld()
        end
    end
end

-- echte Charakterdaten (auch waehrend einer Reise)
function V:RealChar() return (self.active and saved.char) or LP.char end
-- echte Flugpunkt-Liste (waehrend einer Reise liegt eine Ueberlagerung darueber)
function V:RealTaxi() return (self.active and saved.taxi) or RealTaxiOf(LevelPilotDB and LP.Acc().taxi) end

LP:On("PLAYER_LOGOUT", function() V.loggingOut = true V:Abort() V.loggingOut = nil end)

function V:Stop()
    if not self.active then return end
    if ticker and LP.yieldCo and coroutine.running() == LP.yieldCo then
        self.stopRequested = true          -- aus der Reise selbst: der naechste Takt beendet sie sauber
        self.paused = false
        return
    end
    -- Knopf / Befehl: sofort beenden; die angehaltene Planung wird verworfen
    V.token = (V.token or 0) + 1
    LP.yieldCo, LP.yieldOK = nil, nil
    return Finish("stop")
end

-- Beide Modi vergleichen: Reise 1-60 einmal Normal, einmal Speedrun (der echte Modus bleibt unberuehrt)
-- done(normalSecs, speedSecs, text) wird am Ende aufgerufen; ohne done erscheint die Zeile im Chat
function V:CompareModes(done, maxLevel)
    if self.active then return false end
    local tNormal
    local function finished(_, s2)
        local tSpeed = s2 and s2.clock or 0
        local pct = tNormal and tNormal > 0 and math.floor((tSpeed - tNormal) / tNormal * 100 + 0.5) or 0
        local function H(x) return string.format("%.1f", (x or 0) / 3600) end
        local text = L("Normal %s h · Speedrun %s h · Unterschied %+d %%", H(tNormal), H(tSpeed), pct)
        self.compareText = text
        if done then done(tNormal, tSpeed, text) else LP:Reply(text) end
    end
    self:Start("start", { mode = "normal", silent = true, maxLevel = maxLevel, onDone = function(_, s1)
        tNormal = s1 and s1.clock or 0
        C_Timer.After(1, function()
            if self.active then return end
            self:Start("start", { mode = "speed", silent = true, maxLevel = maxLevel, onDone = finished })
        end)
    end })
    return true
end

-- ganze Reise ohne Ticker (Selbsttest / Testumgebung)
-- keep = true: Reise danach nicht beenden (Testumgebung: Zustand untersuchen, dann V:Stop())
function V:RunAll(mode, maxLevel, keep, forceMode)
    self:Start(mode, { silent = true, mode = forceMode })
    if ticker then if ticker.Cancel then ticker:Cancel() end ticker = nil end V.token = (V.token or 0) + 1
    LP.yieldCo = nil
    Prepare()
    while self.active and self.s.level < (maxLevel or 60) do
        local ok, more = pcall(Step)
        if not ok and LP.Nav then LP.Nav.holdRecalc = nil end   -- 3.12.98
        if not ok then Note("error", L("Fehler in der Reise: %s", tostring(more))) LP.Engine:Skip(LP.Engine:Current()) more = true end
        if not more then break end
    end
    if keep then return end
    return Finish(self.s.level >= 60 and "done" or "stop")
end

------------------------------------------------------------------------
-- Bericht
------------------------------------------------------------------------
local function Dur(sec)
    sec = math.floor(sec or 0)
    return L("%d h %02d min", math.floor(sec / 3600), math.floor(sec / 60) % 60)
end

function V:Report(reason)
    local s = self.s
    if not s then return L["Noch keine virtuelle Reise."] end
    local out = {}
    local function add(l) out[#out + 1] = tostring(l):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "") end
    local _, class = UnitClass("player")
    local _, race = UnitRace("player")
    add(L("LevelPilot – virtuelle Reise · v%s · %s", LP.version, date("%d.%m.%Y %H:%M")))
    add(L("Charakter %s %s %s · Modus %s · Client %s · Sprache %s", tostring(race), tostring(class), tostring(LP:PlayerFaction()),
        (LP.Planner.IsSpeed and LP.Planner:IsSpeed()) and L["Speedrun"] or L["Normal"], tostring(GetLocale and GetLocale()), tostring(LP:Language())))
    add(L("Level %d » %d%s · Schritte %d · Quests %d abgegeben (%d angenommen) · Weg %.0f km · Flüge %d · Ruhestein %d",
        s.startLevel, s.level, reason == "stop" and L[" (abgebrochen)"] or "", s.steps, s.quests, s.accepted, s.dist * 0.9144 / 1000, s.flights, s.hearths))
    add(L("Geschätzte Spielzeit %s · Grinden %d× 10 min · übersprungen %d · ohne Weg %d · Planung im Schnitt %d ms je Schritt · Dauer %ds",
        Dur(s.clock), s.grind, s.skipped, s.nopath, math.floor((s.planMs or 0) / math.max(1, s.planN or 1)), math.floor(GetTime() - s.startTime)))
    -- woher die Werte kommen: gemessen oder geschaetzt
    do
        local Ca, P = LP.Calib, LP.Planner
        local kpm = Ca and Ca:KillsPerMin()
        local _, dgHow = P:DungeonXPFactor()
        local how = { set = L["eingestellt"], measured = L["gemessen"], auto = L["automatisch"] }
        add(L("Werte: Kills/Min %s · EP je Kill %s · Dungeon-Faktoren %s",
            kpm and L["gemessen"] or L["geschätzt"], (Ca and Ca:KillXPMeasured()) and L["gemessen"] or L["geschätzt"],
            how[dgHow] or L["automatisch"]))
    end
    -- Sandbox: echte Daten vor und nach der Reise (3.13.14: Zeilen aus V.SandboxLines, T391)
    for _, l in ipairs(V.SandboxLines(s)) do add(l) end
    -- gelernte Werte aus dem echten Spiel
    if LP.Calib then add(LP.Calib:StatusText()) add(LP.Calib:FlightText()) add(LP.Calib:LearnText()) end
    add(L("Flugpunkte geholt: %d · Flüge über nicht geholte Flugpunkte: %d (Ziel 0)", s.fpGot or 0, s.flyUnknown or 0))
    add(L("Questziele gebündelt (im selben Durchgang erledigt): %d", s.bundled or 0))
    do
        local P = LP.Planner
        local fc = (V.active and saved.installed) and P.focusChanges or (s.focusChanges or 0)
        local fr = (V.active and saved.installed) and P.focusReturns or (s.focusReturns or 0)
        add(L("Fokus-Zonen: %d Wechsel, davon %d zurück in eine schon besuchte Zone", fc, fr))
    end
    do
        local function H(x) return string.format("%.0f h", (x or 0) / 3600) end
        local known = (s.tWalk or 0) + (s.tTransit or 0) + (s.tFly or 0) + (s.tObj or 0) + (s.tWay or 0) + (s.tGrind or 0) + (s.tDungeon or 0)
        add(L("Zeitaufteilung: Laufen %s · Schiff/Zeppelin %s · Fliegen %s · Questziele %s · Monster auf dem Weg %s · Grinden %s · Dungeons %s · Rest %s",
            H(s.tWalk), H(s.tTransit), H(s.tFly), H(s.tObj), H(s.tWay), H(s.tGrind), H(s.tDungeon), H(math.max(0, s.clock - known))))
    end
    if (s.wayKills or 0) > 0 then
        add(L("Monster auf dem Weg mitgenommen: %d (%d EP) · Grinden: %d× 10 min", s.wayKills, s.wayXP or 0, s.grind))
    end
    add("")
    add(L("== Auffälligkeiten (%d)", #s.problems))
    if #s.problems == 0 then add(L["  keine"]) end
    local CODE = { nopath = L["KEIN WEG"], direct = L["LUFTLINIE"], stall = L["HÄNGT"], noroute = L["ROUTE"], error = L["FEHLER"],
                   fly = L["FLUG"], dungeon = L["DUNGEON"], nomap = L["KARTE"], limit = L["ABBRUCH"] }
    for _, e in ipairs(s.problems) do
        add(string.format("  [%s]%s L%d %s %.1f,%.1f | %s", CODE[e.kind] or e.kind, e.n > 1 and (" ×" .. e.n) or "", e.lvl,
            LP.Geo:MapName(e.map), e.x or 0, e.y or 0, e.text))
    end
    add("")
    add(L("== Mobs ≥ +3 (Ziele %d, Wegstücke %d – Zielwert 0)", s.mobGoal or 0, s.mobWay or 0))
    if #(s.mobHits or {}) == 0 then add(L["  keine"]) end
    local MK = { quest = L["QUEST"], ziel = L["ZIEL"], weg = L["WEG"] }
    for _, h in ipairs(s.mobHits or {}) do
        local where = h.x and string.format(" %.1f,%.1f", h.x, h.y) or ""
        local VIA = { v = L["Luftlinie"], g = L["Zonenübergang"], r = L["gelaufen"], seed = L["Wegenetz"], s = L["Wegenetz"], w = L["Wasser"] }
        local via = h.via and (", " .. (VIA[h.via] or h.via)) or ""
        local mob = (h.mob or 0) >= LP.Danger.TOWN and L["Ort der anderen Fraktion"] or (L["Mob"] .. " " .. h.mob)
        add(string.format("  [%s]%s L%d %s%s | %s (%s%s)", MK[h.kind] or h.kind, h.n > 1 and (" ×" .. h.n) or "", h.lvl,
            LP.Geo:MapName(h.map), where, h.what, mob, via))
    end
    local dz = {}
    for map, z in pairs(s.direct) do dz[#dz + 1] = { map = map, z = z } end
    table.sort(dz, function(a, b) return a.z.n > b.z.n end)
    add("")
    -- 3.13.2: Messgrösse je Version
    if (s.wayAll or 0) > 0 then
        add(L("Anteil der Strecke ohne bekannten Weg: %.1f %% (%d von %d km)", (s.wayNo or 0) / s.wayAll * 100,
            math.floor((s.wayNo or 0) / 1093.6 + 0.5), math.floor(s.wayAll / 1093.6 + 0.5)))
    end
    add(L("== Lange Luftlinien (über %d Yards ohne bekannten Weg) je Zone", LONG_DIRECT))
    if #dz == 0 then add(L["  keine"]) end
    for _, e in ipairs(dz) do
        add(L("  %s: %d×, längste %d Yards (L%d, von %.1f,%.1f zu „%s“)", LP.Geo:MapName(e.map), e.z.n, math.floor(e.z.max), e.z.lvl or 0,
            e.z.fx or 0, e.z.fy or 0, tostring(e.z.what)))
    end
    -- Abgleich mit den echten Level-Zeiten des Charakters
    if LP.Calib then
        local rows, dev = LP.Calib:CompareLevelTimes(s.levelAt)
        add("")
        add(L["== Abgleich mit deinen echten Level-Zeiten"])
        if #rows == 0 then add(L["  noch keine gespielten Level zum Vergleichen"]) end
        for _, r in ipairs(rows) do
            add(string.format("  L%-2d %s %s · %s %s · %+d %%", r.level, L["echt"], Dur(r.real), L["Reise"], Dur(r.sim),
                math.floor((r.sim - r.real) / r.real * 100 + 0.5)))
        end
        if dev then add(L("  mittlere Abweichung %d %% (Ziel unter 15 %%)", dev)) end
        -- 3.12.68 LW-7 (e) Messlatte aus eigenen Zahlen (Supervisor 14:14): Bestzeit je Stufe über alle Charaktere gegen die
        -- Reise (ohne Namen – der Bericht wird weitergegeben)
        local brows, bsum = V.BestRows(s.levelAt)
        add("")
        add(L["== Messlatte: Bestzeiten je Stufe (alle deine Charaktere)"])
        if #brows == 0 then add(L["  noch keine Bestzeiten"]) end
        for _, r in ipairs(brows) do
            add(string.format("  L%-2d %s %s · %s %s · %+d %%", r.level, L["Bestwert"], Dur(r.best), L["Reise"], Dur(r.sim),
                math.floor((r.sim - r.best) / r.best * 100 + 0.5)))
        end
        if bsum then add(L("  zusammen: Bestwerte %s · Reise %s (gleiche Stufen)", Dur(bsum.best), Dur(bsum.sim))) end
    end
    add("")
    add(L["== Level (Zeit seit Start, Quests, Zone)"])
    local lv = {}
    for l, e in pairs(s.levelAt) do lv[#lv + 1] = l end
    table.sort(lv)
    for _, l in ipairs(lv) do
        local e = s.levelAt[l]
        add(string.format("  L%-2d %s  Q%-4d %s", l, Dur(e.t), e.q, LP.Geo:MapName(e.zone)))
    end
    add("")
    add(L["== Zonen in Reihenfolge"])
    local z = {}
    for _, e in ipairs(s.zones) do z[#z + 1] = "L" .. e.lvl .. " " .. LP.Geo:MapName(e.map) end
    for i = 1, #z, 6 do add("  " .. table.concat(z, " » ", i, math.min(#z, i + 5))) end
    if #s.dungeons > 0 then
        add("")
        add(L["== Dungeons"])
        for _, d in ipairs(s.dungeons) do add("  " .. d) end
    end
    return table.concat(out, "\n")
end

------------------------------------------------------------------------
-- Fenster
------------------------------------------------------------------------
local win
function V:ShowWindow()
    if not CreateFrame or not LP.UI then return end
    if not win then
        local UI, C = LP.UI, LP.colors
        win = CreateFrame("Frame", "LevelPilotVirtualFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
        win:SetSize(330, 118)
        win:SetPoint("TOP", 0, -120)
        win:SetFrameStrata("DIALOG")
        win:EnableMouse(true)
        win:SetMovable(true)
        win:RegisterForDrag("LeftButton")
        win:SetScript("OnDragStart", win.StartMoving)
        win:SetScript("OnDragStop", win.StopMovingOrSizing)
        UI:Skin(win, C.panel, C.accent)
        win.title = UI:Text(win, 13, C.accent)
        win.title:SetPoint("TOPLEFT", 12, -10)
        win.title:SetText(L["Virtuelle Reise"])
        win.text = UI:Text(win, 11, C.text)
        win.text:SetPoint("TOPLEFT", 12, -30)
        win.text:SetWidth(306)
        local b1 = UI:Button(win, L["Pause"], 72, 22, function()
            V.paused = not V.paused
            V:UpdateWindow()
        end)
        b1:SetPoint("BOTTOMLEFT", 10, 10)
        win.bPause = b1
        local b2 = UI:Button(win, L["Zuschauen"], 76, 22, function()
            V.watch = not V.watch
            if V.watch and WorldMapFrame and not WorldMapFrame:IsShown() and ToggleWorldMap then pcall(ToggleWorldMap) end
            V:UpdateWindow()
        end, L["Zuschauen: jeder Weg wird auf der Weltkarte gezeigt (langsam). Schnell: ohne Pause durchrechnen."])
        b2:SetPoint("LEFT", b1, "RIGHT", 6, 0)
        win.bWatch = b2
        local b3 = UI:Button(win, L["Stopp"], 60, 22, function() V:Stop() end)
        b3:SetPoint("LEFT", b2, "RIGHT", 6, 0)
        win.bStop = b3
        local b4 = UI:Button(win, L["Bericht"], 70, 22, function()
            LP.Backup:ShowText(L["Virtuelle Reise – Bericht"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."],
                V.active and V:Report("running") or (V.lastReport or V:Report()))
        end)
        b4:SetPoint("LEFT", b3, "RIGHT", 6, 0)
        win.bReport = b4
        local close = UI:Button(win, "x", 20, 20, function() win:Hide() end, L["Schliessen"])
        close:SetPoint("TOPRIGHT", -6, -6)
    end
    win:Show()
    self:UpdateWindow()
end

V.Window = function() return win end          -- Testroutine (T35)

function V:UpdateWindow()
    if not win or not win:IsShown() then return end
    local s = self.s
    if not s then win.text:SetText("") return end
    local st = s.current
    local status = self.active and (self.paused and L["pausiert"] or (self.watch and L["zuschauen"] or L["schnell"])) or L["beendet"]
    win.text:SetText(L("Level %d · %d Quests · %d Schritte · %s", s.level, s.quests, s.steps, status)
        .. "\n" .. LP.Geo:MapName(s.map) .. (st and ("\n|cff9c9ea6" .. (LP.UI:StepText(st, false):match("^[^\n]*") or "") .. "|r") or "")
        .. "\n" .. L("Auffälligkeiten: %d", #s.problems))
    win.bPause.label:SetText(self.paused and L["Weiter"] or L["Pause"])
    win.bWatch.label:SetText(self.watch and L["Schnell"] or L["Zuschauen"])
    -- nach dem Ende nur noch Bericht und Schliessen
    local on = self.active
    win.bPause:SetShown(on) win.bWatch:SetShown(on) win.bStop:SetShown(on)
    if not on then win.text:SetText(L("Beendet: Level %d · %d Quests · %d Schritte", s.level, s.quests, s.steps) .. "\n" .. L("Auffälligkeiten: %d", #s.problems)) end
end

function V:Init()
    -- falls das Spiel mitten in einer Reise neu geladen wird: nichts bleibt umgeleitet
    LP:On("PLAYER_LOGOUT", function() if V.active then pcall(Uninstall) end end)
end
