-- ThreatSentinel - Alerts.lua
-- Töne, Hinweise in der Bildschirmmitte, Chat-Meldungen, Spott-Widerstand,
-- Tank kontrolliert, Flächenspott, Notfall, Heiler ausser Reichweite.

local ADDON, ns = ...
local L = ns.L

local A = {}
ns.Alerts = A
table.insert(ns.modules, A)

A.extras = {}

ns.SOUNDS = {
	{ key = "none" },
	{ key = "raidwarning", kit = "RAID_WARNING", id = 8959 },
	{ key = "readycheck", kit = "READY_CHECK", id = 8960 },
	{ key = "alarm", kit = "ALARM_CLOCK_WARNING_3", id = 12889 },
	{ key = "click", kit = "IG_MAINMENU_OPTION_CHECKBOX_ON", id = 856 },
	{ key = "quest", kit = "IG_QUEST_LIST_COMPLETE", id = 878 },
}

local lastSound = {}

function A:Play(key, throttleKey)
	local db = ns.db
	if not db.sound or not key or key == "none" then return end
	local now = GetTime()
	local tk = throttleKey or key
	if lastSound[tk] and now - lastSound[tk] < 0.8 then return end
	lastSound[tk] = now
	for _, s in ipairs(ns.SOUNDS) do
		if s.key == key then
			local id = (s.kit and SOUNDKIT and SOUNDKIT[s.kit]) or s.id
			if id then pcall(PlaySound, id, db.soundChannel or "Master") end
			return
		end
	end
end

------------------------------------------------------------
-- Hinweis in der Bildschirmmitte
------------------------------------------------------------
function A:Init()
	local f = CreateFrame("Frame", "ThreatSentinelCenter", UIParent)
	f:SetSize(700, 50)
	f:SetPoint("CENTER", UIParent, "CENTER", 0, 200)
	f:SetFrameStrata("HIGH")
	f.text = f:CreateFontString(nil, "OVERLAY")
	f.text:SetFont(STANDARD_TEXT_FONT, 26, "THICKOUTLINE")
	f.text:SetPoint("CENTER")
	f:Hide()
	f:SetScript("OnUpdate", function(self)
		local left = (self.expire or 0) - GetTime()
		if left <= 0 then
			self:Hide()
		elseif left < 0.4 then
			self:SetAlpha(left / 0.4)
		else
			self:SetAlpha(1)
		end
	end)
	self.center = f

	-- Abfrage "Tank kontrolliert" alle 0.1 Sekunden
	local poll = CreateFrame("Frame")
	local acc = 0
	poll:SetScript("OnUpdate", function(_, elapsed)
		acc = acc + elapsed
		if acc < 0.1 then return end
		acc = 0
		A:CheckCC()
	end)
end

function A:Center(text, c, duration, key)
	local f = self.center
	if not f then return end
	f.text:SetText(text)
	f.text:SetTextColor(c[1], c[2], c[3])
	f.key = key
	f.expire = GetTime() + (duration or 2)
	f:Show()
end

function A:ClearCenter(key)
	if self.center and (not key or self.center.key == key) then self.center:Hide() end
end

-- Meldung an Gruppe/Raid. Während Tests nur an dich (nie in den Gruppenchat).
local function GroupChat(msg, test)
	if ns.db.chatChannel == "OFF" then return end
	if test or ns.Test:IsTesting() then
		ns.Test:Say(L.TEST_CHAT .. " " .. msg)
		return
	end
	if ns.db.chatChannel ~= "GROUP" or not IsInGroup() then
		if ns.db.chatChannel == "SELF" then ns:Print(msg) end
		return
	end
	SendChatMessage(msg, IsInRaid() and "RAID" or "PARTY")
end

------------------------------------------------------------
-- Aggro verloren / zurück
------------------------------------------------------------
function A:OnLoose(m)
	if ns.testMode then return end
	local db = ns.db
	if m.victimRole == "HEALER" then
		self:Play(db.soundHealer, "looseHealer")
	else
		self:Play(db.soundDD, "looseDD")
	end
end

function A:OnRegain(unit, m)
	ns.Plates:Flash(unit)
	if ns.db.regainSound and not ns.testMode then self:Play(ns.db.soundRegain, "regain") end
end

------------------------------------------------------------
-- Auswertung pro Durchlauf (aufgerufen von Threat.lua)
------------------------------------------------------------
function A:Evaluate(loose, heldOnMe)
	local db = ns.db
	wipe(self.extras)
	local inCombat = UnitAffectingCombat("player")

	-- Flächenspott
	if db.aoeHint and ns.aoeSpell and #loose >= db.aoeThreshold and ns.SpellCD(ns.aoeSpell) == 0 then
		self:Center(string.format(L.AOE_HINT, ns.aoeSpell), { 1, 0.5, 0 }, 0.6, "aoe")
	end

	-- Notfall
	if db.emergency and inCombat and heldOnMe >= 1 then
		local max = UnitHealthMax("player")
		local hp = (max and max > 0) and (UnitHealth("player") / max * 100) or 100
		if hp <= db.emergencyHP then
			for _, n in ipairs(ns.defensives) do
				if ns.SpellCD(n) == 0 then
					self:Center(string.format(L.EMERGENCY, n), { 1, 0.2, 0.2 }, 0.6, "emerg")
					if not self.emergShown then
						self.emergShown = true
						self:Play("raidwarning", "emerg")
					end
					break
				end
			end
		else
			self.emergShown = false
		end
	end

	-- Heiler ausser Reichweite
	if db.healerRange and inCombat and IsInGroup() then
		local count = 0
		for _, u in ipairs(ns.groupUnits) do
			if count >= 2 then break end
			if UnitIsPlayer(u) and not UnitIsUnit(u, "player") and UnitIsConnected(u)
				and not UnitIsDeadOrGhost(u) and ns:GetRole(u) == "HEALER" then
				local inRange, checked = UnitInRange(u)
				if checked and not inRange then
					count = count + 1
					self.extras[#self.extras + 1] = { text = string.format(L.HEALER_OOR, UnitName(u) or "?"), c = { 1, 0.8, 0.2 } }
				end
			end
		end
	end
end

------------------------------------------------------------
-- Spott gewirkt / widerstanden (Kampflog)
------------------------------------------------------------
local lastResist = 0

function A:OnResist(dstName, dstGUID, test)
	local now = GetTime()
	if not test and now - lastResist < 1.5 then return end
	lastResist = now
	local db = ns.db
	self:Play(db.soundResist, test and ("testResist" .. now) or "resist")
	self:Center(L.RESIST_SELF, { 1, 0.3, 0.3 }, 1.5, "resist")
	if db.announceResist then GroupChat(string.format(L.MSG_RESIST, dstName or "?"), test) end
	if not test then ns.Sync:Send("R:" .. (dstGUID or "")) end
end

ns:On("COMBAT_LOG_EVENT_UNFILTERED", function()
	if not ns.tauntSpell then return end
	local _, sub, _, srcGUID, _, _, _, dstGUID, dstName, _, _, _, spellName = CombatLogGetCurrentEventInfo()
	if srcGUID ~= ns.playerGUID or spellName ~= ns.tauntSpell then return end
	if sub == "SPELL_CAST_SUCCESS" then
		ns.Sync:OnTaunt(dstGUID)
		if ns.Test:IsTesting() then ns.Test:Say(string.format(L.TEST_TAUNT_CAST, ns.tauntSpell, dstName or "?")) end
	elseif sub == "SPELL_MISSED" then
		A:OnResist(dstName, dstGUID)
	end
end)

------------------------------------------------------------
-- Tank kontrolliert
------------------------------------------------------------
function A:GetLossOfControl()
	if C_LossOfControl and C_LossOfControl.GetActiveLossOfControlDataCount then
		local n = C_LossOfControl.GetActiveLossOfControlDataCount() or 0
		for i = 1, n do
			local d = C_LossOfControl.GetActiveLossOfControlData(i)
			if type(d) == "table" and d.locType ~= "SCHOOL_INTERRUPT" then
				return d.displayText, d.timeRemaining
			end
		end
	end
end

function A:AnnounceCC(text, dur, test)
	local db = ns.db
	local msg
	if text and dur then
		msg = string.format(L.MSG_CC_DUR, text, math.floor(dur + 0.5))
	elseif text then
		msg = string.format(L.MSG_CC, text)
	else
		msg = L.MSG_CC_PLAIN
	end
	if db.chatChannel ~= "OFF" or test then
		self:Center(msg, { 1, 0.3, 0.3 }, 2, "cc")
		GroupChat(msg, test)
	end
	if not test then ns.Sync:Send("X:" .. (text or "")) end
end

function A:CheckCC()
	local db = ns.db
	if not db or not db.announceCC or ns.testMode or not ns:IsActive() then self.ccState = nil return end
	if not UnitAffectingCombat("player") or UnitIsDeadOrGhost("player") then self.ccState = nil return end
	if HasFullControl() then self.ccState = nil return end
	if self.ccState then return end
	self.ccState = true

	local text, dur = self:GetLossOfControl()
	if dur and dur < db.ccMinDuration then return end
	self:AnnounceCC(text, dur)
end

------------------------------------------------------------
-- Meldungen von anderen Tanks
------------------------------------------------------------
local function ForMe()
	return ns:IsTankStance() or ns.Test:IsTesting()
end

function A:RemoteResist(name)
	if not ForMe() then return end
	self:Center(string.format(L.REMOTE_RESIST, name), { 1, 0.4, 0.2 }, 2.5, "remote")
	self:Play(ns.db.soundResist, "remoteResist")
end

function A:RemoteCC(name)
	if not ForMe() then return end
	self:Center(string.format(L.REMOTE_CC, name), { 1, 0.4, 0.2 }, 2.5, "remote")
	self:Play("raidwarning", "remoteCC")
end
