-- ThreatSentinel - TauntButton.lua
-- Gesicherte Knöpfe für "Spott auf Mauszeiger" und "Flächenspott" mit eigener Tastenbelegung.
-- Die Knöpfe werden nur einmal ausserhalb des Kampfs angelegt, daher funktionieren sie im Kampf.

local ADDON, ns = ...
local L = ns.L

local Tb = {}
ns.Taunt = Tb
table.insert(ns.modules, Tb)

BINDING_HEADER_THREATSENTINEL = "ThreatSentinel"
_G["BINDING_NAME_CLICK ThreatSentinelTauntButton:LeftButton"] = L.BIND_TAUNT
_G["BINDING_NAME_CLICK ThreatSentinelAoeButton:LeftButton"] = L.BIND_AOE

Tb.BIND = {
	taunt = "CLICK ThreatSentinelTauntButton:LeftButton",
	aoe = "CLICK ThreatSentinelAoeButton:LeftButton",
}

local function RegisterClicks(btn)
	local down = GetCVarBool and GetCVarBool("ActionButtonUseKeyDown")
	btn:RegisterForClicks(down and "AnyDown" or "AnyUp")
end

function Tb:Init()
	self.taunt = CreateFrame("Button", "ThreatSentinelTauntButton", UIParent, "SecureActionButtonTemplate")
	self.taunt:SetAttribute("type", "macro")
	self.taunt:SetSize(1, 1)
	self.aoe = CreateFrame("Button", "ThreatSentinelAoeButton", UIParent, "SecureActionButtonTemplate")
	self.aoe:SetAttribute("type", "macro")
	self.aoe:SetSize(1, 1)
end

function Tb:UpdateMacros()
	if not self.taunt then return end
	if InCombatLockdown() then self.pending = true return end
	self.pending = false
	local t = ns.tauntSpell
	self.taunt:SetAttribute("macrotext", t and ("/cast [@mouseover,harm,nodead][harm,nodead] " .. t) or "")
	local a = ns.aoeSpell
	self.aoe:SetAttribute("macrotext", a and ("/cast " .. a) or "")
	RegisterClicks(self.taunt)
	RegisterClicks(self.aoe)
end

function Tb:GetKey(which)
	return GetBindingKey(self.BIND[which])
end

function Tb:SetKey(which, key)
	if InCombatLockdown() then return false end
	local cmd = self.BIND[which]
	local k1, k2 = GetBindingKey(cmd)
	if k1 then SetBinding(k1) end
	if k2 then SetBinding(k2) end
	if key then SetBinding(key, cmd) end
	SaveBindings(GetCurrentBindingSet())
	return true
end

ns:On("PLAYER_REGEN_ENABLED", function()
	if Tb.pending then Tb:UpdateMacros() end
end)

ns:On("CVAR_UPDATE", function()
	if Tb.taunt and not InCombatLockdown() then
		RegisterClicks(Tb.taunt)
		RegisterClicks(Tb.aoe)
	end
end)
