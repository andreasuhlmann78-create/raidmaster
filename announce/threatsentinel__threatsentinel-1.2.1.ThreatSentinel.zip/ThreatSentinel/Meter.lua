-- ThreatSentinel - Meter.lua
-- Aggrometer: Bedrohungsliste deines Ziels. Zeigt, wer wie nah an der Aggro ist,
-- und als Tank deinen Vorsprung auf den nächsten Spieler.

local ADDON, ns = ...
local L = ns.L

local M = {}
ns.Meter = M
table.insert(ns.modules, M)

local WHITE = "Interface\\Buttons\\WHITE8X8"
local BAR_TEX = "Interface\\TargetingFrame\\UI-StatusBar"
local WIDTH = 210
local ROW_H = 16
local SCALE_MAX = 130   -- Balkenlänge: 130 % der Tank-Bedrohung = voller Balken

function M:Init()
	local f = CreateFrame("Frame", "ThreatSentinelMeter", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	f:SetSize(WIDTH, 26)
	f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	f:SetBackdropColor(0.03, 0.04, 0.06, 0.6)
	f:SetBackdropBorderColor(0.25, 0.65, 1, 0.5)
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", function(self) self:StartMoving() end)
	f:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		local p, _, rp, x, y = self:GetPoint()
		ns.db.meterPoint = { p, "UIParent", rp, x, y }
	end)

	f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	f.title:SetPoint("TOPLEFT", 6, -5)
	f.title:SetPoint("TOPRIGHT", -60, -5)
	f.title:SetJustifyH("LEFT")
	if f.title.SetWordWrap then f.title:SetWordWrap(false) end
	f.lead = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	f.lead:SetPoint("TOPRIGHT", -6, -5)
	f.lead:SetJustifyH("RIGHT")

	f.rows = {}
	f:Hide()
	self.f = f
	self:ApplySettings()
end

function M:ApplySettings()
	local f, db = self.f, ns.db
	if not f then return end
	local p = db.meterPoint
	f:ClearAllPoints()
	f:SetPoint(p[1], UIParent, p[3], p[4], p[5])
	f:SetScale(db.hudScale)
	f:EnableMouse(not db.hudLocked)
end

function M:Row(i)
	local f = self.f
	local r = f.rows[i]
	if r then return r end
	r = CreateFrame("StatusBar", nil, f)
	r:SetSize(WIDTH - 8, ROW_H - 2)
	r:SetPoint("TOPLEFT", 4, -20 - (i - 1) * ROW_H)
	r:SetStatusBarTexture(BAR_TEX)
	r:SetMinMaxValues(0, SCALE_MAX)
	r.bg = r:CreateTexture(nil, "BACKGROUND")
	r.bg:SetAllPoints()
	r.bg:SetTexture(WHITE)
	r.bg:SetVertexColor(1, 1, 1, 0.06)
	-- Markierung bei 100 %: ab hier steht ein Spieler auf Höhe des Tanks
	r.mark = r:CreateTexture(nil, "OVERLAY")
	r.mark:SetTexture(WHITE)
	r.mark:SetVertexColor(1, 1, 1, 0.35)
	r.mark:SetWidth(1)
	r.mark:SetPoint("TOP", r, "TOPLEFT", (WIDTH - 8) * 100 / SCALE_MAX, 0)
	r.mark:SetPoint("BOTTOM", r, "BOTTOMLEFT", (WIDTH - 8) * 100 / SCALE_MAX, 0)
	r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	r.name:SetPoint("LEFT", 4, 0)
	r.name:SetPoint("RIGHT", -44, 0)
	r.name:SetJustifyH("LEFT")
	if r.name.SetWordWrap then r.name:SetWordWrap(false) end
	r.value = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	r.value:SetPoint("RIGHT", -4, 0)
	f.rows[i] = r
	return r
end

local function ClassColor(class)
	local c = class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
	if c then return c.r, c.g, c.b end
	return 0.6, 0.6, 0.6
end

function M:Collect()
	local list = {}
	for _, u in ipairs(ns.groupUnits) do
		local isTanking, status, _, raw = UnitDetailedThreatSituation(u, "target")
		if status and raw then
			local name = UnitName(u) or "?"
			local class
			if UnitIsPlayer(u) then
				class = select(2, UnitClass(u))
			else
				name = name .. " (" .. L.PET .. ")"
			end
			list[#list + 1] = {
				name = name, class = class, raw = raw,
				tanking = isTanking, me = UnitIsUnit(u, "player"),
			}
		end
	end
	table.sort(list, function(a, b)
		if a.tanking ~= b.tanking then return a.tanking end
		return a.raw > b.raw
	end)
	return list
end

local TEST_LIST
local function TestList()
	if not TEST_LIST then
		TEST_LIST = {
			{ name = ns.playerName or "Du", class = ns.class, raw = 100, tanking = true, me = true },
			{ name = "Torben", class = "ROGUE", raw = 92 },
			{ name = "Mira", class = "MAGE", raw = 78 },
			{ name = "Anna", class = "PRIEST", raw = 55 },
			{ name = "Grimbar", class = "WARRIOR", raw = 40 },
			{ name = "Wolf (" .. L.PET .. ")", raw = 18 },
		}
	end
	-- leichte Bewegung, damit man die Balken arbeiten sieht
	local t = GetTime()
	TEST_LIST[2].raw = 85 + math.sin(t * 0.9) * 20
	TEST_LIST[3].raw = 70 + math.sin(t * 0.6 + 1) * 15
	return TEST_LIST
end

function M:Render(list, targetName)
	local f, db = self.f, ns.db
	f.title:SetText(string.format(L.METER_TITLE, targetName or "?"))

	-- Vorsprung des Tanks auf den nächsten Spieler
	local tank, best = nil, 0
	for _, e in ipairs(list) do
		if e.tanking then tank = e elseif e.raw > best then best = e.raw end
	end
	if tank and tank.me then
		local lead = math.max(0, 100 - best)
		f.lead:SetText(string.format(L.METER_LEAD, math.floor(lead + 0.5)))
		if lead < 10 then f.lead:SetTextColor(1, 0.3, 0.3)
		elseif lead < 25 then f.lead:SetTextColor(1, 0.85, 0.2)
		else f.lead:SetTextColor(0.3, 1, 0.4) end
	else
		f.lead:SetText("")
	end

	-- Anzeigen: die obersten Zeilen, du selbst immer dabei
	local maxRows = db.meterRows
	local shown = {}
	for i = 1, math.min(#list, maxRows) do shown[i] = list[i] end
	local meShown = false
	for _, e in ipairs(shown) do if e.me then meShown = true end end
	if not meShown then
		for _, e in ipairs(list) do
			if e.me then shown[math.min(#shown + 1, maxRows)] = e break end
		end
	end

	for i, e in ipairs(shown) do
		local r = self:Row(i)
		local cr, cg, cb = ClassColor(e.class)
		r:SetStatusBarColor(cr, cg, cb, 0.85)
		r:SetValue(math.min(e.raw, SCALE_MAX))
		r.name:SetText((e.me and "> " or "") .. e.name)
		if e.tanking then
			r.value:SetText(L.METER_AGGRO)
			r.value:SetTextColor(1, 0.35, 0.35)
		else
			r.value:SetText(string.format("%d%%", math.floor(e.raw + 0.5)))
			if e.raw >= ns.db.warnThreshold then r.value:SetTextColor(1, 0.35, 0.35)
			else r.value:SetTextColor(1, 1, 1) end
		end
		r:Show()
	end
	for i = #shown + 1, #f.rows do f.rows[i]:Hide() end
	f:SetHeight(24 + #shown * ROW_H)
	f:Show()
end

function M:Tick()
	local f, db = self.f, ns.db
	if not f then return end
	if not db.enabled or not db.meter then f:Hide() return end

	if ns.testMode then
		self:Render(TestList(), L.TEST_TARGET)
		return
	end

	if db.meterOnlyTank and not ns:IsTankStance() then f:Hide() return end

	if not db.hudLocked and not UnitAffectingCombat("player") then
		f.title:SetText(L.METER_DRAG)
		f.lead:SetText("")
		for i = 1, #f.rows do f.rows[i]:Hide() end
		f:SetHeight(24)
		f:Show()
		return
	end

	if not UnitExists("target") or not UnitCanAttack("player", "target") or UnitIsDeadOrGhost("target") then
		f:Hide()
		return
	end
	local list = self:Collect()
	if #list == 0 then f:Hide() return end
	self:Render(list, UnitName("target"))
end
