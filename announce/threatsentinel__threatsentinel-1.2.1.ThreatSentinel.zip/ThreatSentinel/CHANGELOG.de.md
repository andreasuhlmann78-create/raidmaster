# ThreatSentinel – Änderungen

## 1.2.1
- Neuer Knopf **Unterstützen** (PayPal) in der Titelleiste des Einstellungsfensters und „Addon unterstützen“ auf der Seite Allgemein. Auch mit `/ts spenden`. Öffnet sich nie von selbst.

## 1.2.0
- Neue **Testzentrale** (Rechtsklick auf den Minimap-Knopf oder `/ts test`): Demo mit Vorschau-Plaketten, Live-Test solo, jede Meldung einzeln, Tank-Sync-Simulation und Diagnose
- Läuft auf Classic Era / Anniversary und TBC Anniversary sowie WoW Forever

## 1.1.0
- Erste Version: lose Mobs leuchten, gehaltene werden ausgeblendet, Spott auf Mauszeiger, Aggrometer, Tank-Sync
