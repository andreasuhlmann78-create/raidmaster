# AHSentinel (formerly AH Analyzer Pro) – Changelog

## 0.65.245
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Market tab "Today": the tooltip of a buy suggestion now shows its rank (gold per day per 1g invested) and its path with hit rate – released, still learning (cases of 20) or locked.

## 0.65.244
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Market tab: new line "Hit rate per path" above the footer – for flipping, sniper, disenchanting, crafting and vendor: green = released (rate and cases), grey = still learning (cases of 20), red = locked. Hover for the explanation.

## 0.65.243
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Market tab header: instead of one price index across all goods, the first line now shows each level band (1-25, 26-45, 46-60): its direction (falling / rising / peak / steady) once it is measured well enough, otherwise grey "measuring x/5". Bands with a detected buyout are marked orange, with the total at the end.

## 0.65.242
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Market tab detail: for an item without your own price data, the shared market data of other players is shown as "Network (other players)" with its age – marked as uncertain and never used for buying. Tooltip, prices and bookkeeping still use only your own data.

## 0.65.241
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Market tab: the header now says when the next full scan is possible ("Full scan possible in x min" / "now" / "running"); scanning more often gives better measurements. Only shown when full scan is enabled.
- The header now uses two lines (market index | play rhythm · full scan) – before, the text was longer than the space and was cut off.

## 0.65.240
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- With more than 4000 items in the auction house, the market-value cache was emptied every 10 minutes and recalculated. Its limit now follows the size of your last full scan (+20 %, at least 4000, at most 20 000), and new prices mark an entry as outdated instead of throwing it away. Less memory churn after a full scan.

## 0.65.239
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Less memory churn after a full scan (about a third less, measured): sorting long tables reuses its helper lists, and the sales history no longer creates throw-away tables for items you never posted.

## 0.65.238
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Level-band price history (test report) is now comparable from day to day: each day's value is chained on the same basis (before, a steady rise of 2 % per day was recorded as 0 %). No effect on prices or suggestions.
- The band history keeps 120 days, so a monthly cycle can be measured later.

## 0.65.237
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Developer measurement of slow events works again (it never measured because its clock was not yet defined).
- Internal: the clock of the background time budgets can be swapped in the test simulation (fixed measurement). No change in game.

## 0.65.236
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- The number of players behind "all players" sales data is a lower bound – it now reads "at least n".

## 0.65.235
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Plan after a longer break:** after at least 2 days away, "Since your last visit" also shows a short plan by the same rules
  as "My stock" and "Today": what to sell (with price), what to buy (with maximum price) and how much can stay. Display only.

## 0.65.234
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Daily and weekly cycles are measured:** in the background AHSentinel now measures, per level band, whether prices are
  typically higher or lower at certain hours or on certain weekdays. Measurement only (test report) – nothing is shown or
  recommended until a cycle has been confirmed over at least 3 weeks.

## 0.65.233
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Gold safety:** sniper targets created with "+" (bargains below vendor price or disenchant value) and "Buy" in Market >
  Disenchant never get a budget above your limit per item (10 % of your gold). If that is not enough for one piece, no target
  is created and a message says why.

## 0.65.232
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **"Before you go":** a button in the Market tab (and once per session shortly before your usual play time ends) shows the 3
  most important steps: what loses value until your next login (falling band), what you can post (24 hours if you are away
  for longer) and what can stay. Display only – nothing is bought or posted without your click.

## 0.65.231
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Holding risk:** if a level band is measurably falling (enough data), AHSentinel now lowers "Worth up to" for buys that take
  more than a day to sell (5 % per day until your next login – a cautious assumption until measured). In a price spike it never
  buys to hold and "My stock" says "sell now"; in a falling band "sell before you log out". Without enough band data nothing
  changes. Rising prices are never counted as profit.

## 0.65.230
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Level bands are measured:** AHSentinel now measures daily, per level band (1–25, 26–45, 46–60 by required level), whether
  prices fall, rise or spike – from your own scans, only once a band has enough data (5 days with 20 items each). For now this
  is measurement only (test report, interface for other addons); it does not change any buy limit yet.

## 0.65.229
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Duration that fits your play rhythm:** once AHSentinel has learned your rhythm, the Sell window preselects the duration –
  2 hours if you will probably play at least 2 more hours, otherwise 24 hours – and says why, with the deposit of both durations.
  Your own choice always wins for the rest of the session. Without learned rhythm nothing changes. Option "Preselect duration".

## 0.65.228
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Bookkeeping > Per item, disenchant rows:** the material lines in the tooltip now have the heading "Revenue:" – they are
  what the materials brought in, not profit.

## 0.65.227
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **"Since your last visit":** after a break of more than a day, AHSentinel shows once when you first open it: what sold (net,
  from the invoices), what came back (expired auctions), how the level bands changed – and buttons for the next steps ("My
  stock", "Today"). If the invoices are still in the mailbox, it says so. Can be turned off ("Don't show again" or in the options).

## 0.65.226
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sales per day from all players:** once the shared market tables contain data from all GoldSentinel players (part "all",
  per faction), AHSentinel uses it as prior knowledge for how much of an item sells per day: your own measurement always counts
  more (prior weight = 2 measurements); without your own measurement the cautious lower end of all players' range is used. Shown
  as "all players (n), x days" in the tooltip and market details. Without these data everything stays as before.

## 0.65.225
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Play rhythm:** AHSentinel learns roughly when you play next (from your logins and online minutes, from 14 days of data;
  otherwise 1 day) and shows it in the Market tab header ("Next login ~2 days (learned)"). You can also set it yourself in the
  options: automatic / daily / a few days a week / weekends only. For now this is information only; later it helps choose the
  auction duration and "Before you go".

## 0.65.224
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Below vendor price – exact numbers:** one calculation for Bargains, "Today", Market > Vendor and the sniper "+". Only vendor
  prices confirmed by the game count (no old table values). New column "Quantity" = pieces actually below the vendor price (per
  price step; "≥" = at least), "Total profit" = sum over exactly these pieces (before: total quantity of all price steps, inflated).
  The age of the prices is shown at the name; older than 30 minutes = grey.
- **"+" → sniper target:** max price = vendor price − 1 copper (never at or above the vendor price), quantity = these pieces,
  budget = their total price.
- Shortening to the budget now goes over the price steps (cheapest first) instead of cheapest price × quantity.

## 0.65.223
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Bargains > Below disenchant value = Market > Disenchant:** both views now use the same calculation and show the same items
  and numbers (planned quantity, total profit). The "+" button now creates the sniper target up to "Worth up to" with the planned
  quantity and budget – before it allowed buying up to the full value minus 1 copper, i.e. without profit.
- **Empty lists say why:** e.g. "Nothing below its disenchant value with at least 20 % profit right now (checked: 41 items …;
  prices from the scan 3 min ago)", "the disenchant option is turned off" or "no prices from the last 2 hours".
- For other addons: new `API.QuietOn()` (is the sniper in quiet mode?).

## 0.65.222
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Buy > Bargains without "Market value" and "Flips":** both views compared against the median of listed prices, not of prices
  actually paid, and their profit per day was not measured – so they often showed falling markets or items nobody buys. They are
  hidden until AHSentinel measures real sales per item. Bargains now opens with "Below vendor price"; "Below disenchant value",
  "Bids" and the flipping calculator stay.

## 0.65.221
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **"Today" explains budget cuts:** if a suggestion's quantity was reduced because of your budget, the row says so in one
  sentence. If suggestions were left out for the budget, a tip row at the end tells you how many and how big the budget is.
  The list stays sorted by profit.

## 0.65.220
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Your full scans now feed the shared market data:** after each full scan AHSentinel hands its lowest prices to the shared
  market file, so your guild's other addons (and AHSentinel's forecasts) can use them. Measured: at most about 2.4 MB of memory
  per scan, no longer frames. It respects the "share market data" switch.
- Less memory per scan: the data handed over is reused instead of rebuilt every time.

## 0.65.219
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **One refresh button everywhere:** both AHSentinel windows (main window and inside the auction house) have the same
  refresh button at the same place – top right, just left of Options. Click = refresh the current tab, Shift-click =
  recalculate everything.

## 0.65.218
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Shared market file updated to version 7 (uses less memory when sharing). Sharing your full-scan prices with other players
  stays off for now until it is measured within its memory limit.

## 0.65.217
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **One recipe list at the profession window:** if ProfessionSentinel is installed, AHSentinel no longer shows its own profit
  window next to the profession window – ProfessionSentinel is the profession addon and shows the same numbers from
  AHSentinel. "Materials as shopping list" and "Only what I'm missing" stay available through ProfessionSentinel. Without
  ProfessionSentinel everything stays as before.

## 0.65.216
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Today – one ranking for all ways:** when your gold budget (25 %) is shared between buy suggestions, the order is now gold
  per day per 1g invested times how reliable the way has been (its measured hit rate; while a way is still learning, a careful
  60 %). Suggestions that pay off faster and more surely get the budget first. The list itself stays sorted by profit.

## 0.65.215
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Price guard works in every path (player report):** "Adjust price" now suggests the smallest price that does NOT warn
  again – for rules after the 5 % fee (vendor, your purchase price, disenchant) it adds the fee (e.g. 9s 19c purchase ->
  9s 68c), rounded up to the item's grid. Before, the same warning came back endlessly. The text now uses the real numbers
  after the fee: "After the 5 % fee you get 8s 73c – that is 46c below your purchase price (9s 19c). Loss: ~1s 84c."
- **"Post anyway" posts first:** the guard posts directly in your click, before closing the window. If WoW still blocks it,
  the next click on "Post" posts this item at this price without another warning.

## 0.65.214
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Smoother after a full scan:** after a scan, AHSentinel asked the server about thousands of items it did not know yet in
  one go, which caused freezes of up to half a second. New item requests are now limited to 200 per second; known items are
  never limited. Names of new items appear a little later.

## 0.65.213
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Buy limit – choose your risk:** new setting "careful / normal / bold". It only changes the safety margin of the
  "Worth up to" buy limit: normal = as before (nothing changes if you don't choose), careful = 10 points more margin,
  bold = 5 points less (never below 5 %). The minimum profit and at most 90 % of the value always apply. The tooltip shows
  an example for an item worth 10s.

## 0.65.212
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper locked during a full scan:** while a full scan runs, the "Sniper mode" button is grey and switching it on or off
  (button, header, /ahs sniper) has no effect – the tooltip shows the remaining time. It unlocks when the scan ends, is
  cancelled or the auction house closes, at the latest after 120 seconds.
- **Sniper searches again right after the scan:** price checks of the Sell tab that you did not click (series, undercut
  check, re-checks) no longer take the search slot while the sniper is on; they wait until the sniper is off. A price check
  you click still goes first.

## 0.65.211
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper – lost races:** when several purchases are open and the server answers "item not found" (another buyer was
  faster), this now belongs to the youngest purchase (sent within the last second). That offer is never sent again; older
  open purchases stay open until the server or your gold confirms them.
- **Sniper status:** "Purchase confirmed (server briefly reported an internal error – no consequences)" no longer hides a
  waiting hit. "Hit! … to buy" comes first, the note is added at the end.

## 0.65.210
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profession window – shopping list (player report):** "Materials as shopping list" and "Only what I'm missing" said
  "added" but no list appeared when the profession name was empty or too long. The list name now falls back to
  "Professions" (or is shortened), and success is only reported when the list really has entries – otherwise you see the
  real error.
- **Disenchant window empty although items are in the bags:** when the game had not loaded an item's info yet, the
  window stayed empty until the bags changed. It now redraws as soon as the info arrives, and while items are left out it
  says why ("1 items left out: item info not loaded yet 1"). The diagnostic log notes each item with its reason (DE-LEER).

## 0.65.209
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper – faster next purchase:** after a confirmed purchase the server sends the updated offer list by itself. If it is
  complete, AHSentinel now uses it right away (same checks as a search: max price, budget, own and dead offers), so the
  next hit can be bought without waiting for the next search. The sniper report shows "confirmation -> next purchase"
  (average and longest).

## 0.65.208
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper – one click, one purchase (player request):** a large "Buy" button across the sniper column. It says what it
  buys: "Buy: 1× Shoulders … for 8s 50c" (only the name is shortened, never the amount). Commodities need two clicks by
  Blizzard's rules and the button says so: "Ask price (12× Linen Cloth)" -> "Confirm buy: 12× for 3s 00c". Without a hit
  it is grey with the reason and does not start a hidden search. States without blinking: ready, waiting for the server
  (dimmed), no hit (grey), bought (green for a moment). Same safety checks as the mouse wheel (max price, budget, one
  single purchase at a time, server ready); a double click does not buy twice.
- **Buy with:** new setting "Wheel + button" (default, everything as before) or "button only" (mouse wheel and keys stay
  free for the camera).

## 0.65.207
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Posting blocked by the game (ADDON_ACTION_BLOCKED):** if WoW blocks a post, AHSentinel now tells you "Posting needs a
  click – please click Post again" instead of "Posting …" and no longer locks the button for 5 seconds. The next click posts.
  The diagnostic log notes which way was used (button, series, Today, repost) and the version, so the cause can be found.
- **Quiet mode while sniping:** background calculations that had already started now also pause while the sniper searches,
  and continue where they stopped afterwards (nothing is lost; the 30-minute limit stays).

## 0.65.206
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Choose your ways:** in the settings you can turn off disenchanting, crafting, flipping and vendor flipping (green = on,
  grey = off, all on by default). A way that is off never shows up as a buy or craft suggestion – not in Today, the Market
  tab, the sniper or the tooltip "Worth up to".
- **Enchanting is detected automatically:** disenchanting only counts if one of your characters on this realm has the
  Enchanting skill for that item. Each character remembers its skill when you log in.
- **Safer disenchant limits:** when no purchase price keeps the minimum profit, there is now no "Worth up to" at all – before,
  a few places fell back to the full net value.
- Shared market file updated to version 6.

## 0.65.205
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profession window – both directions:** if a recipe loses money because your materials are worth more raw, the line
  "best way" now says so with the amount: "no profit – sell the materials raw (+1s 18c)". Same calculation as the profit
  shown above (your own materials count at what they would sell for, missing ones at the price ladder, vendor goods at the
  vendor price). Recipes that only use vendor materials keep "no way with profit".

## 0.65.204
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Market tab – new view "My stock":** everything you own on this auction house (bags and bank of all your characters on
  this realm, mail as seen at the last mailbox visit, your running auctions) in one list: amount per place, value now after fees (best way: sell, disenchant or
  vendor – the same number as everywhere else), the best way and one button (Post / Disenchant / Vendor / Keep). Items whose
  price is falling come first, with "waiting until tomorrow costs about …" in the tooltip. Without a scan from the last
  30 minutes the value is grey with "Scan needed". The tooltip shows the origin: how many you bought and your cost per
  item from the bookkeeping, or "loot or no purchase price".

## 0.65.203
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchant tooltip – your real results:** the "Materials" section shows next to the default chances what your own
  disenchants of this group really gave ("yours (659)": dust 73 %, essence 22 %, shard 6 %); with fewer than 30 of your
  own, guild results are used ("guild (n)") or it says "30 so far". Last line "Avg per disenchant … net" – the same number
  the disenchant value above uses. The rest of the tooltip is unchanged.

## 0.65.202
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sell tab – honest suggestion:** if disenchanting pays more than selling, a green line says so ("Disenchanting pays
  more (≈ 11s18 instead of 8s55) – do not post") and posting asks first. If the market is below your minimum price, it
  says plainly "Selling now means a loss: market 9s, your minimum 11s41 – wait or vendor (6s59)". Your minimum price is
  never undercut by rounding. Hovering "Expected profit" shows the calculation in one sentence.
- Shared market file updated to version 5.

## 0.65.201
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **My Auctions – "Cancel next undercut" works while prices are unknown:** instead of "no undercut auctions" the first
  click starts the price check of these items ("Prices are still being checked – try again in a moment"); the next click
  cancels one undercut auction. The header shows "? undercut" instead of "0" while prices are checked.
- Status "leave it" is short; the tooltip says why ("undercut by 2c – cancelling costs the fee"). The footer only shows
  when the list is filtered (otherwise it repeated the header).

## 0.65.200
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper never blocks you:** while you sell or search in another tab yourself, the sniper pauses its own searches for
  30 seconds ("Sniper paused – you are selling, resumes in n s"); a waiting hit can still be bought with the wheel.
- **Sniper window:** target names and status no longer cut off ("140/1000 · Rest 7g81", the rest in the tooltip); the
  "Today" line fits one line and names open hits so the numbers add up ("1 open"); German decimal comma.
- **Every "Internal auction error" is explained** in the sniper report (last request, open purchases, server ready
  before sending). If the purchase is confirmed right afterwards, it is no failure: the sniper says "Purchase confirmed
  (the server briefly reported an internal error – no effect)". Right after a purchase AHSentinel sends no other own
  request for 0.3 s.

## 0.65.199
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Market data network (first step):** AHSentinel now brings the shared GoldSentinel market file and receives market
  data from other GoldSentinel users (prices and quantities only, no names, no prompt). Option "Share market data" (on by
  default) turns it off. Your own full scans are not passed on yet – that would currently happen in one big step and
  stutter; it follows once it can run in small portions. Foreign values never overwrite your own scan and never trigger
  a purchase.
- **Disenchanting: fair cost per material.** The cost of a disenchanted item is now spread over its materials by what a
  disenchant of that group is expected to bring – not only by what this one disenchant happened to yield. Luck or bad
  luck shows up as its own line "Disenchant yield" in the ledger and counts toward trading profit. Totals add up to the
  copper. Applies to new disenchants only; older entries stay as they are.

## 0.65.198
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **The calculation core learns faster – without costs:** from full scans that run anyway, other players' single
  auctions become learning cases (gone early or still there, undercut or not). Whether "gone" means "sold" is calibrated
  on your own auctions per item group – no flat assumption. This path has its own check and is used as prior knowledge
  only once it beats its baseline. No extra server requests, no extra stutter.
- **Guild learns together:** case counters (per group, price level and day – no names, no single cases) are shared with
  guild members who use AHSentinel; only new cases count, each sender's counters as their own pot with its own check.
- Prior-knowledge tables from outside can now be loaded per cell; without them everything works as before.

## 0.65.197
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper quiet mode (on by default):** while the sniper is on and the auction house is open, only the sniper works.
  Background calculations (forecasts, caches, chains, market tables, learning) wait – after 30 minutes they continue in
  small steps. No automatic auction house requests besides the sniper: background price checks, automatic My Auctions
  refresh, the watcher and the scan wait until the sniper is off or the AH is closed (scan button greyed with the reason).
  Searches you click yourself still go first. Nothing is lost.
- **Targets without hits searched less often:** in quiet mode a target without any listing at or below its max price for
  10 minutes is searched at most every 30 seconds (none drops out); its tooltip says so.
- Sniper window: "Quiet mode: n tasks paused" (tooltip lists them). `/ahs quiet on|off` (German: `/ahs ruhe an|aus`).

## 0.65.196
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper: "Internal auction error" no longer loses good listings:** the error means "sent too fast", not "gone". The
  listing stays buyable; after 2 retries without a purchase (error or no reply) it pauses for 30 seconds ("Paused 30 s"),
  never 10 minutes. Fixed: an error after an earlier rejected purchase was ignored.
- **Sniper status:** "Server not ready yet (0.4 s) – notch waits" shows how long the server has been busy.
- **Smoother sniping:** while the sniper is armed and the auction house is open, forecast evaluation and cache rebuilds
  wait (at most 2 minutes). The sniper report shows the computing time per sniper event and per window refresh.

## 0.65.195
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper listing cleaned up:** a bought listing shows "bought" for 1 second, one that is surely gone shows "gone" for 1
  second – then the row disappears. On "Internal auction error" or without a reply the row stays ("Error – again" or "no
  reply") and can still be bought. Below the list: "bought n · snatched n · no reply n".

## 0.65.194
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper buys more reliably:** it only buys when the server is ready, and by default only one single purchase at a time
  (`/ahs einzelkauf aus` in developer mode turns that off). While a purchase awaits a reply, the sniper does not search – so
  the server drops fewer purchases ("Internal auction error").
- **Counter = server:** only purchases confirmed by the server are counted. If gold is gone but the confirmation is
  missing, the amount stays reserved in the budget but does not count as bought.
- **No 8-second pauses:** if a search gets no reply, the sniper searches again after the measured reply time (usually 2 s).
- **Amounts:** always without gaps, e.g. "2g 00s 64c" instead of "2g 64c".
- **My auctions:** "Cancel next undercut" is only active when there is an undercut auction; messages have their own line
  above the list.

## 0.65.193
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper window:** the "Level from/to" fields are wider, and placeholders that are too long are written smaller instead
  of being cut off. "n entries" above the listing no longer sits under the "Price history" button.

## 0.65.192
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Considerate sniper:** if your own search (or another addon's) replaces a sniper search, the sniper waits 1 second before
  searching again. At most 3 immediate retries in 10 seconds.
- **Sniper with several targets:** sent, not yet confirmed purchases of another target and purchases of a deleted target no
  longer lower a target's remaining budget.

## 0.65.191
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper target line:** short and fully readable ("15/1000 · 6 waiting · left 3g92"), the full line is in the tooltip.
  Purchases rejected by the server no longer count as "waiting".
- **Sniper report:** a hit that disappeared without a single notch is "no notch" instead of "others faster". The
  "round robin" check no longer counts gaps across a pause (full scan, your own click).

## 0.65.190
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper self-test never hangs:** `/ahs testroutine sniper` (developer) ends after 5 minutes at most. If the test purchase
  question gets no answer within 30 s, it continues without the test purchase. The test window shows "Step 2 of 4 ·
  waiting at most 110 s more".
- **Sniper report:** the lines "money per target" and "single purchases" are always in the report – "none" without
  purchases, otherwise also from the last real sniper session. After your own click in the auction house the report
  measures what held the sniper up.
- **Sniper with several targets:** when one target buys, the remaining budget of the other targets no longer drops with it.
  Gold that belongs to no target is deducted from the remainder and named ("… other spending included").
- **Sniper continues faster:** if the server drops a search or your own auction house search replaces it, the sniper
  searches again right away instead of waiting 8 seconds.
- **Sniper message:** if all matching listings are already sent, it says "All matching listings sent – 6 awaiting reply"
  instead of "Nothing below your max price".
- **Self-test:** no real market scan starts during the test routine anymore (its data stays complete).
- **Accounting:** past sales since your cut-off date are no longer lost when many new entries come in (until now, above
  4000 entries the oldest were dropped – revenue and sales went down retroactively).
- **Missing stock:** when the addon books out goods that are nowhere anymore (bags, bank, mailbox, auctions), it now says
  so in chat – with amount and cost. If the goods come back, it is undone.

## 0.65.189
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper never gets stuck on a market scan:** if evaluating a market scan fails with an error, the sniper no longer waits
  forever ("waiting: market scan running") but searches again right away.

## 0.65.188
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **My auctions – cancel advice:** the addon now calculates with the price it would really relist at (never below your
  minimum price). If the market is below your minimum price, it says "leave it" instead of "cancelling pays off" – no more
  lost deposit for relisting at the same price.

## 0.65.187
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper after a full scan:** while a full scan runs, the sniper calmly shows "Full scan running – about 30 s left (sniper
  waiting)". As soon as the full scan is done, the sniper searches again right away. If a full scan takes longer than
  2 minutes, the sniper searches anyway.
- **Sniper counts correctly:** a purchase is never counted twice, even if the server confirms it late. Several purchases
  at once again (as in 0.65.183). A rejected listing is checked again by the next search.
- **Today line in the sniper:** "Today: 162 hits · 67 with purchase · 95 missed · bought 70 pcs" – hits and pieces kept
  apart.

## 0.65.186
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper never sends a purchase twice:** a listing already sent or bought stays "sent" or "bought" even after the next
  search – the next notch takes the next listing. Until now the same listing was bought again after every search and
  rejected by the server.

## 0.65.185
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper for gear:** the server only accepts single purchases one after another. The sniper therefore sends only one
  purchase at a time and briefly waits for the reply (status "waiting for reply …") instead of sending dozens of purchases at
  once that the server discards. Progress "5/1000 bought · 1 awaiting reply · left 9g60" instead of "(+67 sent)".

## 0.65.184
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Collecting mail:** mail that is still loading ("Retrieving data") is no longer skipped – collecting waits briefly and
  continues by itself instead of reporting "No auction mail". The same message no longer appears several times in the
  middle of the screen. If more than 50 items are in the mailbox, the addon says so.

## 0.65.183
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper counts purchases correctly:** when many purchases succeed in quick succession, the sniper now counts them by the
  gold that was taken – even without a confirmation from the server. Successful purchases no longer count as failed, and the
  item is no longer paused because of them.
- **Budget holds:** the sniper also checks the budget against your real gold since the first purchase – it never buys
  beyond the budget.

## 0.65.182
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Clean-up prepared:** a new check walks through all windows and tabs (Classic and Modern, 100 % and 130 %) and finds
  overlaps, cut-off texts, buttons without a function and outdated texts. The findings will be cleaned up next.

## 0.65.181
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper no longer hangs:** if another part of the addon (price check, watcher, shopping) holds the search for more than 10
  seconds, the lock is released and the sniper keeps searching. The status line names who is blocking.

## 0.65.180
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Crafting chains switched on:** "Today" now suggests what is worth crafting – e.g. "Craft 12x Brown Linen Pants (+60c
  each)" – including intermediate products (linen cloth -> bolt -> pants -> disenchant). Only with at least 20 % profit,
  never at a loss.
- **One number:** chains now calculate exactly like "Best recipes" (same way, same profit).

## 0.65.179
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper buys with fewer notches:** while a purchase is on its way to the server, another notch no longer starts a new
  price check (it overtook the running purchase). If a purchase fails, the next notch asks for a smaller quantity right away.
- **No false loss warning for ingredients:** if a sniper target is an ingredient of one of your recipes (e.g. linen cloth),
  it now shows a grey "Ingredient for your recipes – see the profit window for the gain" instead of "every purchase loses".

## 0.65.178
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper fast again:** a cancelled purchase (price rose, listing gone) no longer slows down the searches. After a real
  server error the sniper is back at full pace after 10 seconds. The status line says in words why it is waiting and how
  many targets are active.
- **Fewer lost duels:** if the price rose before confirmation, the sniper no longer cancels and searches again – the next
  notch asks for a smaller quantity right away. Your full quantity stays the goal. Buying still only happens on your
  notch/key and never above your max price.
- **Shopping, X button:** resets search, filters, category and the list, closes the favourites menu and no longer stutters.
  If there is nothing to reset, X is grey.

## 0.65.177
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchant tooltip:** materials are shown plainly again, following the WoW Forever reference – e.g. "1–2 Vision Dust
  75 %" with the price per piece. No more calculation details ("× Ø", "Scan"); your own disenchants keep being learned in the
  background.
- **Test and measuring functions only for development:** test routine, self test, self checks, diagnostic log and timing
  measurements no longer run for normal players – less CPU time and memory.

## 0.65.176
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **More thorough sniper check (`/ahs testroutine sniper`):** at the open auction house the test now watches your own
  targets (a test target if you have none) and measures: pace (searches per minute against the server limit of 90),
  whether all targets get their turn, whether hits are correct (only up to the max price, marked gold), money safety
  (nothing sent; for the test purchase gold before − after = booked price), pauses (the sniper resumes by itself),
  missed hits and stutter (no frame longer than 33 ms). The result is at the very top of the report in a few plain sentences.
- Still nothing is bought without your wheel notch/key.

## 0.65.175
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper speed measured:** each sniper session (from switching on to off) is measured – searches, average and highest
  searches per minute, number of targets – only real sniper searches, never the test routine. The test report shows the last
  session. The row text is shorter ("12 s ago").
- **"Today":** a "price fell" row only appears if selling now is really worth it (at least 1s and more than waiting).

## 0.65.174
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper checks ALL targets:** every target in your list is searched in turn, equally often, as fast as the server allows
  (before, a target with hits was searched much more often and the others rarely). Each row shows "checked x s ago"; a row
  with a waiting hit is marked gold. Buying still only by click; budget and max per row apply. Test T727.

## 0.65.173
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Accounting:** the tooltip over "Profit" now shows exactly four lines – proceeds, invested, fees, profit – with the same
  numbers as the header. "Profit %" is simply profit ÷ invested of that line; if the line contains items without purchase
  price it shows "–" (the tooltip says how many). Profit and % never have different signs.
- **"Today":** rows that turned out "no longer worth it" are no longer shown; the flip part calculates in smaller steps.
- Full scan: slow event handlers of AHSentinel are now measured and named at the longest frame (to find the remaining stutter).

## 0.65.172
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Market tab simpler:** only "Today" and "Disenchant" are shown – Flip, Vendor, Gaps, Crowded and Trends are not backed by
  your own data yet and are hidden (option "Market: all views (experts)"). A sentence on top: only what pays off with your data.
  Test T723.
- **Disenchant:** groups you have not measured yet are extrapolated from your own disenchants (all measured groups together,
  at most +10 %, from 100 disenchants on) and marked grey "extrapolated from n own disenchants". Test T724.
- **"Today":** sorted by profit again after quantities were limited; calculates in smaller steps (less stutter). Interface
  "worth up to" returns the same value as the tooltip (also for vendor/auction way). Best recipes are not recalculated twice
  within 2 seconds. Tests T725, test routine fixes.

## 0.65.171
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Less stutter after a full scan:** the end of the scan measured the memory of ALL addons twice in one frame (several hundred
  ms with large saved data). This now only happens in the speed test. Test T721.
- **Self-check gold:** auction house and mailbox sessions now also measure the gold directly (start/end); money changes at an
  open auction house are no longer attributed to a vendor visit that did not close properly. Test T719.
- Self-check: disenchanting is no longer counted as "craft without recipe" (the spell name is shown); the daily balance uses 1 %
  of the turnover like the accounting; the disenchant button names what it would cover and tries other spots. Test T720.
- Test routine: a clear chat warning before it starts (about 2 minutes, please do nothing), a reminder if you open the mailbox
  or auction house meanwhile, and the longest frame in the report. Test T722.

## 0.65.170
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **"Today", gold safety:** a single buy suggestion uses at most 10 % of your gold; while a way is still learning (no own
  cases yet) only a small trial amount is suggested. New self-check. Test T718.
- **"Today" follows your own best way:** ingredients of a profitable crafting chain you know (e.g. bolts and thread for a
  pants recipe) are no longer suggested for sale; items worth more disenchanted get "Disenchant" instead of "sell at vendor";
  the number is now the profit (not the proceeds), with a short sentence on hover. Test T717.
- **Accounting:** "Profit %" of disenchant groups again counts only bought items (no more 477 %); the tooltip explains the
  part without purchase. Test T715.
- **Profit window:** no "Vendor pays more: 0c" and no "best way: vendor" when the vendor doesn't buy the item and every way
  loses – it says "no way with profit". Test T716.

## 0.65.169
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sell window:** "Expected profit" now subtracts what the goods cost you (average cost of your stock). Before it showed the
  whole proceeds as profit. Point at the line for a short explanation. New self-check. Test T714.
- **Sniper, new target:** amount empty = 1000, budget empty = 5g, max price is always yours to enter (no automatic price).
  Existing targets stay unchanged. Test T713.

## 0.65.168
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper, gold safety:** a number without unit in "Max/item" (and other max prices when buying) now means COPPER – "22" is
  22c, not 22g. Budgets stay gold ("6" = 6g). Price fields when SELLING need a unit ("13" is red "unit missing", posting is
  blocked until you write 13s). A max price above 50 × market value asks for confirmation (typo?). Test T710.
- **Sniper, gold safety:** the confirmed server price is now checked as average per item (total ÷ amount). Above your max the
  sniper does not buy and searches again – it then only takes the items within your max. New self-check "sniper buy ≤ max".
  Test T711.
- **Best recipes:** the list could stay empty ("No prices yet") – fixed; without an offer list the normal price is used. New
  self-check: list empty although a scan is younger than 1 hour. Test T712.
- **Sells:** the time estimate in the tooltip now uses your place in the queue: offers cheaper than you plus your items, at the
  usual sales pace ("fast (~2 h)" instead of "slow (~13 h)" when you are at the front). With Shift a short sentence explains it.
  New self-check: predicted vs. real sale time of your auctions. Test T709.

## 0.65.167
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Accounting, crafting:** a craft was only booked when the recipe was already in the "best recipes" cache. Otherwise the
  crafted item had no cost, and materials disenchanted from it showed the full revenue as profit. Now the recipe is also found
  in the open profession window or in the recipes remembered for this character. New self-check "craft booked". Test T708.
  Earlier bookings stay unchanged.
- **Profit window:** if disenchanting is the best way, the vendor amount is shown as "Vendor: 60c" (no longer "vendor pays more",
  which contradicted "best way: disenchant"). Test T707.

## 0.65.166
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Accounting, disenchant groups:** materials from new disenchants remember their price at the moment of disenchanting. The
  group tooltip shows separately "Price fell since disenchanting −x" (or rose) – how much waiting cost or earned you. Older stock
  has no such price and is not estimated. A short sentence explains the group number. Tests T705, T706.

## 0.65.165
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Best recipes:** ingredients you have to buy now cost the price at which the amount for a series of 20 crafts is really
  available (price ladder), not the cheapest single offer – no more fake profits like "Bolt of Woolen Cloth +1s 66c".
- **Crafting chains (preparation):** AHSentinel now calculates, after every scan, the crafting chains of your known recipes
  (buy → craft, also intermediates → sell or disenchant) and keeps only those with at least 20 % profit. Until they are fully
  checked they only appear in the test report, not in tooltips or the market tab. Test T704.

## 0.65.164
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Accounting, disenchanting:** the cost of a disenchanted item is now split onto the materials by their current market price.
  Before, the "realistic resale price" was used, which pushes slow-selling essences and shards down a lot – Soul Dust got far
  too much cost (about 6s instead of 4s per dust), the essences too little, so dust looked like a loss. Bookings already made
  stay unchanged. New self-check "split when disenchanting": warns if one material's cost differs by more than a third from the
  others (with numbers). Test T703.

## 0.65.163
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Stock (gold safety):** the "phantom stock" rule of 0.65.160 could book out your own running or returned auctions and AH
  purchases still in the mail as "missing". Now goods are only booked out when the mailbox AND your own auctions were seen
  after the last arrival (and after your auctions of that item ended) – also if only part is missing. Auctions from earlier
  sessions count as on hand. If booked-out goods arrive later (30 days), the booking is reversed with the old cost. Each
  booking-out and reversal gets a line in the repair log. Tests T699, T701, T663.
- **Accounting, disenchant groups:** profit and "Profit %" now come from the same items (before: profit +3g 50s green next to
  −4 %). The group tooltip shows ONE number (gold in − gold out), "of which items without purchase", and the materials only
  with amount and revenue – no misleading "loss per material". Test T702, self-check: group = revenue − cost.
- Test routine: the intentional test error (T131) no longer opens the Lua error window; your error handler is restored right
  after. Test report: no colour code in the self-check text.

## 0.65.162
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **New: "Disenchant (n)" button at the profession window** – opens the AHSentinel disenchant window without typing
  "/ahs entzaubern". n = disenchantable items in your bags (blocked items, equipment sets and quest items don't count); grey
  at 0. The button sits left of "Create All" when there is room, otherwise below the profession window – it never covers
  another button. Locked in combat. Test T700, self-check "disenchant button".

## 0.65.161
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Self-check:** the test routine never writes into the real mailbox or AH check sessions any more (before, a test at the open
  AH could cause a false deviation).
- **Worth up to (vendor):** buying at the vendor price earns nothing – the vendor way now uses a 20 % minimum profit.
- Test routine: after a fresh full scan, tests wait longer for their background tasks; with a full queue they are "skipped" with
  a reason instead of failing. New simulator run with the auction house open.

## 0.65.160
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Less stutter in "Today":** crafting suggestions from ProfessionSentinel are fetched at most every 15 minutes instead of
  after every scan (one step took up to 153 ms).
- **Stock:** goods that are nowhere any more (no bag, bank, mail or auction) and were not restocked for over a day are
  booked out – no more phantom stock. Test T699.
- Stock self-check: "more on hand than booked" (loot, gifts) is no longer an error, only grey info.

## 0.65.159
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Buy limit learns right away:** completed purchases of the last 30 days are recounted once (each exactly once), so the buy
  limit per price level works without waiting weeks. Test T697.
- **Mail self-check:** if the money has already left the mail after collecting, the state from the last mailbox read counts.
  Test T698.

## 0.65.158
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Calculation core step 3a:** one "worth up to" across all ways (disenchant, resale in the AH, vendor) – the best safe
  exit per item. The test report compares it with the numbers tooltip, market, bulk buy and sniper show today; all displays
  switch over once the differences are explained. Test T696.
- Auction house self-check also finds older bookings.

## 0.65.157
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Mail self-check fixed:** the mailbox check now counts every taken money by kind (AH sale, other AH mail, gold from
  players, COD) and only reports gold that cannot be explained or a sale without booking – no more false red results. Trade
  and the Sell window are checked more closely (written bookings, first row price and quantity).
- **Buy limit:** your own purchases count before the table (the table is only prior knowledge), profit per level as a sum.
  If no price level pays off, there is no "worth up to". Test report: predicted vs. achieved profit per level.

## 0.65.156
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Less stutter on full scans (part 2):** price ladders, tracking and checks after the scan no longer create new tables
  per item. From the third scan on, a full scan allocates about 13.8 MB in the test (before more than 60 MB),
  no background portion above 9 ms.
- **More accurate gold reconciliation:** counts only from the start of measurement (old bookings no longer dilute the 1 %
  limit), mail money counts on the day you collect it, and it is measured whether the deposit is part of the mail money.
  Tests T694, T695.
- Sell: notes are measured by height – nothing gets cut off any more.

## 0.65.155
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **AHSentinel checks itself:** while you play normally, the addon compares every booking with what really happened in the
  background: vendor, mail, auction house and trade against the gold change, stock against bags/bank/mail, the Sell window
  after every click, memory after every full scan and the profit displays against each other. Results in the test report
  ("Self-check" section) and in /ahs testroutine; the details window only shows a line when something is off. No need to
  note your gold any more. Tests T686–T693.

## 0.65.154
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Calculation core step 2:** market tables (recalculated daily) now ship with the addon and serve as prior knowledge
  while your own numbers are missing. The buy limit learns per price level: if a level does not reach the minimum profit,
  the limit is lowered there (never above 90 % of the value). If a disenchant material is in a wave (price falling), Sell
  shows "Wave: sell now". Tests T683–T685.

## 0.65.153
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Calculation core learns with honest checking (step 1):** a new learning layer counts every sales result per item
  group and price level (few cases -> towards prior knowledge, old cases count less). Each case is predicted first and only
  counted afterwards – so it shows whether the prediction really hits. Test report "MARKT-KERN" (hits, baseline, Brier).
  Nothing new is displayed yet. Tests T681, T682.
- **Cancel reason:** cancelling an auction now counts as "undercut" based on the cheapest OTHER offer of the last search
  (before, your own auction was often the cheapest -> never "undercut"). Test report: class 80–100 % before/since 0.65.128.
  Test T680.

## 0.65.152
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Books – disenchant materials per group:** in the "per item" list, dust, essences and shards of one level band are shown
  together in one line ("Disenchanting 26–35"); the tooltip lists the single materials. What counts is whether disenchanting a
  group pays off – not one material that just dropped in a wave. Test T679.
- Test routine: sales, disenchant, sync and full-scan tests (T285, T289, T291, T223, T272, T310) now run in game independent
  of your real learned data.

## 0.65.151
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Player trades booked:** buying or selling through the trade window now appears in the books – measured from gold and
  bags (source/way "player"). Gifts without gold are not booked as sales. Test T678.
- **Material waves:** the index only uses whole days – the partial current day (morning prices only) no longer distorts it.
  Test T677.
- "Today" calculates in smaller portions (less stutter). Test report: disenchant buy safety follows the group rules
  (20/25/30 %, no budget).

## 0.65.150
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Gold reconciliation as cash flow:** every gold change is now measured and assigned to where it happened (auction house,
  mail, vendor, player trade, trainer, flight master, loot, quest, other). Measured trading cash flow is reconciled against
  booked cash flow – money outside trading (quests, loot, trainer, flights) counts as explained. The test report lists the
  largest gaps per day with their places. Test T676.

## 0.65.149
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Less stutter after the full scan:** the market value calculation no longer creates helper tables per item. A scan now
  leaves about two thirds less memory garbage (test: 65 MB -> 18–23 MB), fewer garbage collections, and memory hardly grows
  per scan. Same values as before (6000 items compared). Test T675.
- **Sell:** notes are no longer cut off – as many as fully fit in 2 lines are shown, the rest in the "(i)" tooltip.
  "Far too expensive – sells at …" instead of "Price 120x above market".

## 0.65.148
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Vendor measured instead of assumed:** purchases, sales to the vendor (also by hand), buybacks and repairs are booked from
  the change in gold and bags – exactly the amount really paid. Failed purchases or repairs are no longer booked. Sales to the
  vendor now appear in the books (way "Vendor") instead of later as "missing". When the vendor closes, the visit is checked;
  any remainder shows as "vendor unclear". Tests T670–T674.
- **Sell – click hits the item you saw:** if the bag list is re-sorted right between hovering and clicking, the click still
  selects the item that was under the mouse. Tests T667/T668 now always run (substitute bags).

## 0.65.147
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sell – posting area tidied up:** no overlapping text any more. Every number has its own line: new "Expected profit"
  (green/red, grey while the addon is still learning the sell rate) and "Chance to sell" – the chance is no longer attached to
  the deposit line.
- "Proceeds after fees" is now honest: sale price minus AH cut. Possible returns only count in "Expected profit".
- Notes sit in a fixed area above the button: at most 2 lines, most important first, all others in the "(i)" tooltip.
  Shorter: "Vendor pays more: 1c", "Price 120x above market – sells at 25c". Test T669.

## 0.65.146
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sell – always the current AH state:** every selected item is searched on the server again right away (front of the
  queue), even if the last price is only a few minutes old. Until the answer arrives the old list is shown grey with
  "updating …"; when the server throttles, it shows in how many seconds it allows a search again – the search then runs
  by itself. After posting, cancelling or buying the selected item it searches again immediately.
- Every click in the Sell list is logged (item, selected before/after, errors, title). Test T668.

## 0.65.145
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sell – item selection:** an item chosen on the left now always appears on the right, even if a single step (price
  suggestion, duration, counting bags) fails; the error goes to the error log with item and step. Test T667.

## 0.65.144
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Safer stock check:** goods that may still be in the mailbox (AH purchase, mail from one of your characters,
  returned auction) are only booked out after the mailbox was seen afterwards – freshly bought goods not for 7 days.
  What 0.65.140–0.65.143 booked out too early as "missing" or "consumed" returns to stock once.
- Missing stock and goods sent to others are shown separately from own use (Details window, test report). Test T666.

## 0.65.143
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Mailbox by hand:** mail now counts even if you (or another addon) collect it yourself – invoices, expiry mail
  (deposit lost) and goods in the mailbox (count as present in the stock check).
- **Sales forecast:** the chance now comes from your counted rate per price level. On cancel (also via Blizzard's window)
  AHSentinel notes whether you were undercut and by how much. Tests T664, T665.
- Stock check: goods that are nowhere anymore (bags, bank, auction, mailbox) are booked out right away.

## 0.65.142
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Accounting – one profit:** the header now shows the same profit as the "Details" window (no second "profit with
  purchase"). Goods without a known purchase show in grey as "unknown origin".
- **Details:** return per route only shown as a number from 30 cases (grey "still learning" before); the gold check
  only warns in red once it is consistent (grey "being reconciled" before).

## 0.65.141
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Fixed: "Crafting.lua:515 attempt to index field" when building the crafting list.
- The test routine no longer writes real data while cleaning up (gold amount, full-scan measurement).
- Test T659 now also runs in the game (mailbox/crafting locks disabled for the test).

## 0.65.140
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Stock check fixed (important):** the check saw goods in bags and bank as "0 present". AHSentinel now counts with the
  stored snapshot of your bags and bank (bank as of the last visit). As long as the bank was never seen, nothing is
  booked out. What 0.65.136–0.65.139 wrongly booked out as "consumed" returns to stock once. Goods that are really
  missing are booked as removed (not in profit). Test T663.

## 0.65.139
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Calculation core (preparing 0.66):** AHSentinel measures market waves per level band (disenchanting materials):
  "in the wave" (2 days of strong falls), "through" (sideways) or open. Test report only for now. Test T662.

## 0.65.138
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Accounting – game costs:** repairs at a vendor are booked as game costs (not in the trading profit) and show in the
  "Details" window; the gold check adds up better. Guild bank repairs do not count. Test T661.

## 0.65.137
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Accounting – crafting:** when crafting, the cost of the reagents (e.g. vials from a vendor) moves into the crafted
  product – the later sale shows the real profit.
- **Sent mail:** goods sent to one of your characters keep their purchase cost; goods sent to other players count as
  own use. Sent or crafted vendor goods no longer count wrongly as "consumed". Test T660.

## 0.65.136
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Accounting – consumed vendor goods:** what you bought from a vendor and used up (food, water, ammo, reagents) leaves
  the stock and counts as own use – no more phantom stock. Test T659.

## 0.65.135
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Accounting – vendor purchases:** purchases from vendors are now booked (purchase with source "vendor", cost basis
  in stock, e.g. for crafting). The gold check adds up better. Test T658.

## 0.65.134
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Details – sell rate per sales chain:** cancelling and relisting cheaper no longer counts as "not sold" – only goods
  that expire and are not relisted. Test T657.

## 0.65.133
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Accounting – "Details" button:** opens its own window (Today / Week / Total, Total by default) with trading
  (profit), trading per hour (profit ÷ play time without AFK, from 2 h), own use, lost deposit, sell rate, return per
  route (disenchanting as the sum of all cases) and gold check. Otherwise the accounting tab looks as before. Test T656.

## 0.65.132
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Deposit – more precise:** a deposit only counts as lost when the expiry mail arrives or you cancel the auction –
  no longer after a fixed time. A refund read late (even days later) always resolves it. Test T654.

## 0.65.131
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Accounting – own use:** goods you bought and then equip or use as a bag are no longer trade goods: they leave the
  stock and do not count in the trading profit (separate "own use" expense, test report only). The accounting tab
  looks as before. Test T655.

## 0.65.130
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Accounting – deposit booked correctly:** the deposit paid when listing is held and no longer lowers the profit.
  When it comes back on a sale, it is not income. Only a lost deposit (expired/cancelled) is an expense – in the period
  it expired. Named as in the game (the client's "Deposit" text).
- Test report: held and lost deposits. Test T654.

## 0.65.129
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Less memory:** per-item caches (market value, sales rate, buyout) are limited and cleared every 10 minutes when
  too large. The tempo test shows their size. Test T653.

## 0.65.128
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sales forecast knows the price:** the chance to sell now comes from your real sales per price level (price
  relative to market value) – listing higher means a smaller chance. Without learned cases it stays as before.
- Test report: sales chains (expired/cancelled -> relisted -> sold counts as one case), with number of listings and
  price of the last vs. the first listing. Tests T651, T652.

## 0.65.127
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Accounting – phantom stock removed:** goods still in stock after the repair although they were sold are moved onto
  the invoices once (purchase cost there, not in stock). New: stock check against bags, bank and own auctions – if the
  stock shows more, the test report says so (reported only, nothing changed silently).
- **Gold reconciliation** now only covers the period with recorded gold amounts, over all characters; before that "learning".
- **Bargains tab** no longer calculates when opened but in the background (shows the last result immediately).
- **Sniper/disenchant:** buy limit never above 0.9 × value.
- The test routine no longer writes real gold amounts. Tempo test: startup parts with file:line, tooltip measurement
  notes garbage collection, cause of full-scan gaps, last full-scan measurement survives a reload.
- Test report: purchases per price level, disenchant breakdown from sums. Tests T649, T650.

## 0.65.126
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Empty lists:** the hint in an empty list (e.g. Market > Disenchant) now stays inside the list and wraps to its
  width instead of running across the screen.
- **"Test report" window:** very long reports are shown in parts (arrows top right, "Part x of y") instead of the
  window staying empty/black.
- **More honest sales forecast:** auctions you cancelled yourself no longer count as "not sold" (neither hit nor miss,
  not used for learning). On cancel AHSentinel notes whether you had been undercut. The test report shows the hit rate
  old/new and the sold share per price level.
- Test: the "Today" list with 5000 items is computed in small portions (T647). Tests T645–T648.

## 0.65.125
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Less stutter – compact price history in memory:** in game AHSentinel now keeps the price history as one compact
  number list per item instead of one table per price entry (tens of thousands fewer Lua objects; garbage collection
  has much less work). Saved data stays exactly as before; all values are unchanged.
- **Accounting – repair corrected:** for invoices that were booked twice next to pending sales, the purchase cost now
  goes onto the invoice (the goods are sold) instead of back into stock. If you already started 0.65.124, this is
  corrected once afterwards (backup kept). The repair only counts as done once it has run without errors.
- The tempo test shows the price history tables. Tests T643, T644.

## 0.65.124
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Accounting – profit only from confirmed sales:** auctions that sold but whose payment has not arrived by mail yet
  ("pending") no longer count in profit; they are shown separately as "in transit". Pending entries older than 24 h
  without an invoice are flagged in the tooltip.
- **Invoices in large lots:** an invoice for e.g. 72 items now confirms several small pending entries of the same item
  (summed by quantity) instead of booking a second sale.
- **One-time repair:** pending entries already covered by an invoice that was booked as a new sale are marked "replaced
  by invoice" (nothing deleted, a backup is kept). No more double counting between invoice and pending.
- Test report: profit old/new, number of resolved entries, gold reconciliation since the start date. Tests T640–T642.

## 0.65.123
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Shared command list:** the list while typing `/ahs` now comes from the shared GoldSentinel file
  (GoldSentinelCmdHint.lua), the same for all GoldSentinel addons. Use stays the same (click selects, Tab/Shift+Tab,
  Enter runs); your usage counters are kept.
- Speed test (`/ahs testroutine tempo`): memory of AHSentinel broken down by area (size and number of tables) in the
  test report.
- Tests T638, T639.

## 0.65.122
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchanting – final rules per material group:** 20 % minimum profit for groups your results prove and also for
  groups not measured yet, as long as the disenchant table matches your measured results (within ±10 %); 25 % only if
  the table deviates; 30 % for groups that measured badly. No budget cap per group. In the game you only see whether it
  pays or not – the rules appear only in the test report.
- Test T637 updated.

## 0.65.121
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchant value was corrected far too much (important):** the material price correction (×0.57) used the median of
  a random result – mostly cheap dust, rarely an expensive essence or shard. On average the prediction was right
  (≈ 0.96). Now the correction uses sums (total loot / total prediction, from 30 cases), so "Worth up to", the sniper
  maximum and the profit line are realistic again. The learned safety margin for disenchanting uses sums too.
- **Minimum profit for disenchanting per material group:** 20 % for groups your own results prove (≥ 30 purchases,
  total profit ≥ 20 %), 25 % for groups not proven yet (and at most 20 % of the disenchant budget per group to learn
  them), 30 % only for groups that measured badly. Weapons and armour of the same level band count together.
- Test report: total profit per group (loot / spent) and the minimum profit that applies.
- Tests T589, T637.

## 0.65.120
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **No more sync flood:** AHSentinel never fills the shared send queue above 10 messages; the rest waits in its own
  outbox and is sent bit by bit (during the test routine it waits). This also reduces stutter after a full scan.
- **Market tab opens instantly:** "Today" no longer calculates when the tab opens (was over 1 second); it calculates in
  the background and appears when ready.
- **Faster login/reload:** the compact price history is unpacked in small portions right after loading instead of all at
  once; nothing can get lost (logout during unpacking keeps the packed data).
- Sniper test: "no hits" because the market had nothing suitable is now SKIP with reasons; the sync queue shows its
  composition. Speed test: the last full-scan measurement survives a reload.
- Tests T634–T636.

## 0.65.119
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchanting needs at least 30 % profit (was 20 %):** your own results showed too many disenchant purchases without
  profit. "Worth up to", the sniper maximum for disenchant targets, the market view and the tooltip all use the same
  30 % now (value ÷ 1.3). A higher setting still applies; the general minimum profit for selling stays unchanged.
- Test T633.

## 0.65.118
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **New test part `/ahs testroutine tempo`:** measures the speed targets in the game – tooltip calculation, switching
  tabs, sniper reaction, buy per key press, longest frame with the auction house open, login/reload and memory of the
  full scan – and writes them into the test report (field "tempo"), with the slow spot if a target is missed.
- Full scan: the diagnostic log now says whether slow reading portions come from garbage collection.
- Tests T625–T632.

## 0.65.117
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper budget doubled after reset:** "Reset counter" now always sets the budget back to the amount you entered
  (a refill no longer stays in).
- **One "best way" for all numbers:** profit line, "… pays more" and "Max above sale value – every purchase loses about …"
  now all come from the same calculation (sell, disenchant, vendor after fees) – no more contradicting numbers.
- The calculation line "With … budget the sniper buys at most …" is gone from the target tooltip.
- **Sniper and scrolling:** the sniper measures whether the server answers searches without a key press. If not, the
  sniper shows "Scroll to search and buy · last search 12 s ago" and reminds you quietly after 10 s without scrolling.
- Test report: composition of the sync queue per prefix.
- Tests T621–T624.

## 0.65.116
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **"Worth up to" for disenchanting was too low:** the material price correction (e.g. ×0.57) was counted twice – once
  in the value and again in the learned safety margin (both measured the same shortfall of your own disenchants). The
  learned margin now only covers what the correction does not already explain. "Worth up to" (sniper max for
  disenchant targets, buy limits) is again value ÷ (1 + minimum profit), e.g. 10s -> 8s 33c instead of 5s 90c.
- Test T620.

## 0.65.115
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper acceptance test in the game:** `/ahs testroutine sniper` (auction house open). First it asks in its own
  window whether ONE real test purchase of 1 piece up to 5c is allowed – it only buys with your own mouse wheel notch or
  key; "No" skips it. Then, with buying locked, it watches the sniper for 2 minutes: hits stay visible (S1), counter and
  budget only count confirmed purchases (S2), pause is visible and "resume" works (S3), frame rate / longest frame /
  sync queue (S5) and reaction time (S6). The result goes into the test report like the other parts.
- Tests T613–T619.

## 0.65.114
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper never loses a real purchase:** if the server sends no answer, the sniper checks your gold after 30 s (gold
  down by the price -> counted). A confirmation that arrives late is still counted (up to 5 min). On the modern auction
  house an error message without a listing (e.g. from a search) no longer marks the purchase as failed.
- **Live tooltip (new):** hovering an offer (sniper list, buy list, bargains, classic auction house row) shows ONE line
  "Profit: −44c / each" (red) or "Profit: +2s 61c / each" (green) – with the price of exactly this offer and the best
  way after fees (sell, disenchant, vendor). It replaces "Disenchant worth it …" and "Worth up to …"; everything else
  stays. Bag tooltips use the market value. "Material prices corrected ×…" now only with Shift.
- **Buy list:** with a quality filter, items whose data loaded later now appear without a new search.
- **Test routine:** sync messages that arrive during the run are applied afterwards (no sandbox error, nothing lost).
- **Flip list:** list and detail always calculate with the same state (no "FLIP-WIDERSPRUCH").
- Diagnostics: "LANGSAM" names the longest single step (file:line); full-scan test waits up to 300 s.
- Tests T602–T612, T597 checks the uploaded fields.

## 0.65.113
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper counted failed purchases (important):** a sent single purchase now only counts – and only uses budget – when
  the server confirms it. Failed or unanswered purchases are not counted any more (before, a target could show "32/35
  bought" after 3 real purchases and then stopped searching). While a purchase waits for the answer the row shows
  "(+1 sent)". Classic auction house: every server answer is matched to the oldest open purchase.
- **Sniper pause visible:** after 3 failed purchases of the same item the target row and the status line show "paused
  until 19:58 – 3 purchases failed" (tooltip with the server's error text) and a "resume now" button appears.
- **Sniper list:** 3 failures in a row no longer empty the hit list – it stays visible as outdated until new results arrive.
- **Sniper target above sale value:** creating such a target gives one clear warning in chat (with warning sound).
- Tests T598–T601.

## 0.65.112
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Learned sales factor fixed:** since 0.65.111 every group factor showed 1.00 because the estimate was compared with
  itself. The independent estimate is kept separately again.
- **Stock value:** stock is valued at the achievable price – never above the market value (the value had jumped ×12
  through a single high resale price). The test report lists the largest stock items.
- **Less stutter in the full scan:** the tracking of auctions no longer creates a text and a table per auction (the
  garbage collector caused pauses of up to 821 ms).
- **Buy list:** the quality filter now also hides items whose quality is not loaded yet (white/grey items slipped through).
- **Tooltip:** a small positive profit below the minimum now reads "Disenchant: only +86c (+9 %) – below the minimum
  profit 20 %", without a green check mark at the value.
- Test report: market-core section also in the uploaded fields. Tests T592–T597.

## 0.65.111
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

Immediate fix of distorted numbers (your decision):
- **Disenchant value = achievable price:** your own disenchants measured that the material prices were assumed ~43 %
  too high (loot/prediction 0.60). The disenchant value is now corrected per group by this measured factor – for
  "worth up to", Sniper, Market, tooltip and Today. The tooltip shows "material prices corrected ×0.57".
- **Sales per day: measured before estimated** everywhere; an implausible estimate without a measurement now shows as
  unknown instead of an inflated number.
- Tests T240 (deposit on non-sale) and Today's sort check fixed; tests T589–T591.

## 0.65.110
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

Smoothness and reliability:
- **Compact price history (PD7, your decision):** entries older than 48 h are saved in a compact form – in the game the
  price history stays exactly as before. Safety: the first time the old entries are kept as a backup; at the next
  login everything is checked, only then the compact form is used. If a check fails, your data stays as it was and you
  get a message. "/ahs pd7" shows the status, "/ahs pd7 back" turns it off while the backup exists.
- **Less stutter:** work after a scan (market check, rhythm, forecast, material log, real-data check) runs in small
  portions in the background; "Today" splits its sections into portions; the scan evaluation pauses per row.
- **Sniper:** every failed purchase is logged with the server message; after 3 failures in a row the Sniper searches
  fresh instead of working through an old list. Disenchant targets show "still learning"/"way locked" in grey.
- **Sell chance:** the shown percentage is corrected by what really sold (e.g. 98 % predicted, 30 % sold -> 30 %) and
  marked "still learning (not calibrated)" until it is calibrated.
- **Log:** errors of the test routine are counted separately; error entries are no longer pushed out of the log.
- "/ahs testroutine echt" reports only once; tests T231, T253 and T52 no longer depend on your real learning data,
  T52 never tries to cancel.
- Tests T584–T588.

## 0.65.109
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

Fixes wrong numbers from the big test of 0.65.108:
- **Materials after a full scan:** a real price drop (e.g. the level wave) was stored as "unconfirmed bait" and the
  materials stayed "estimated, unsure". A full scan with at least 5 pieces on the cheapest step now counts as a real
  price. The diagnostic log lists source, age and reason per disenchant material after each scan.
- **Tooltip:** no green check mark for "Disenchant" when the material prices are unsure (grey "Disenchant: unsure").
- **No fake flips:** a resale price above the market value only counts with a full ladder (≥ 3 steps or ≥ 5 pieces) and
  sales of at least 1 per day – otherwise at most the market value.
- **Releases everywhere:** "Today" shows ways that are still learning or locked only grey at the bottom ("still
  learning (n of 20)") or not at all; profit over 300 % is marked "implausible". The tooltip shows "Disenchant pays"
  grey while the way is still learning.
- **Cancelled auctions:** AUCTION_CANCELED with an unknown/foreign auction ID (e.g. on a failed Sniper purchase) is no
  longer handled as your own cancel; the same ID only once.
- **Accounting:** if more than 30 % of the revenue has no purchase (cost basis missing), the header shows "Profit with
  purchase" large and "plus … without purchase – check cost basis" small and yellow. The test report lists those items
  with their likely origin.
- Tests T580–T583 (T-D1, T-TT1317, T-MH1310, T-BH1307); T223, T248, T431, T432 now independent of your real learned margin.

## 0.65.108
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Market tab "Disenchant" now uses the same "worth up to"** as tooltip, buy list, batch buy, Sniper and API (row and
  detail line). The "minimum profit" option is only a filter now. Sniper disenchant targets are always set exactly to
  "worth up to" (chat message only from 5 % change).
- **Market core measures correctly:**
  - Own auctions: a cancel or sale message that arrives before the new auction list is no longer lost.
    "Relisted" is only guessed from really new auctions (several equal stacks no longer confuse it).
  - Disenchant recommendations are checked against the material value 24 h later, vendor recommendations
    against the confirmed vendor price (no longer against the item's AH price).
- **Releases (part D) in the Market tab:** a way below 60 % hits is hidden ("Way … locked (hits n %)"); a way with
  fewer than 20 cases shows its rows grey "still learning (n of 20)"; Flipping, Gaps and Crowded stay grey until
  30 own sales are measured. Measuring continues in the background.
- Self test "Plausibility (Ü3)": no implausible row may be shown as a recommendation.
- Tests T573–T579 (T-MA1b/c, T-MA2c, T-FG1–T-FG3, T-RK2c).

## 0.65.107
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **One "worth up to" everywhere (disenchanting):** tooltip, buy list mark "[Disenchant pays]", warning guard, Sniper
  disenchant targets, Market tab "Disenchant", the Market buy limit, the batch buy and the API now use one single
  calculation. Before, the tooltip and the Market tab could show two different limits for the same item.
  - Worth up to = net value × the stricter of (1 / (1 + minimum return)) and (1 − learned safety margin).
    Without learning: 10 % margin below 10 real disenchants.
  - The batch buy no longer subtracts the minimum return a second time (items up to "worth up to" are bought).
  - Self test: "One worth up to per item" checks 20 scanned items – two different values = error.
- **Implausible suggestions** (profit over 300 %) are marked "implausible: …" in the Market tab and are not counted
  as recommendations.
- **Sniper: budget used up -> question.** When a target's budget is used up and a buyable hit appears, the next buy key
  press / wheel turn does not buy but asks: "Budget of X used up (n bought). Keep buying? Top up the budget by X."
  "Yes" (Enter) adds the original budget (at most what your gold allows), the next turn buys. "No" changes nothing.
  The question comes again every time the topped-up budget is used up. Max price and quantity stay unchanged.
- **One command table:** the /ahs handler now works only from the command list – every command it understands is in
  /ahs help and in the typing list (new there: doppelt, resetscan, messreihe, ahdebug, ah).
- **API:** WorthUpTo returns a 4th value (safety 0–1, nil = still learning) and a 5th value (price per piece); the 1st
  value stays the total for qty. MaterialCost walks the price ladder for the needed quantity. Trend words of
  MarketState documented in API.md.
- **Tests:** "/ahs testroutine echt" checks the basic rules on your own data (read only: suggestions, one "worth up
  to", Sniper budget); also runs quietly after every full scan and writes violations to the diagnostic log
  ("GRUNDREGEL VERLETZT"). New tests for market-core releases (59 % locked, 61 % free, 19 cases learning) and for
  auction mail with any sender.
- Tests T556–T572 (T-RK2a/b, T-Ü3b, T-SB1–T-SB6, T-BL1/5/6, T-API-PM2/PM3, T-TU5, T-TU7, T-BP-1113-1).

## 0.65.106
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Market core, step 1 "trust" (measurements for the new market tab):**
  - Every shown buy recommendation (flip, vendor, disenchant from the Market tab, Sniper hits) is remembered and checked
    24 hours later against the scan: hit rate and mean error per way. A way with at least 20 cases and less than 60 %
    hits is locked automatically (log "WEG GESPERRT"); below 20 cases it shows "still learning".
  - Sale vs. cancel: when one of your own auctions disappears with a long remaining time, the detection guesses "sold"
    or "re-posted"; the real cause (sale / your cancel) gives its error rate – the basis for releasing sales numbers.
  - Vendor prices: how many were confirmed by the game and how many differed from the remembered table.
  - New test report section "MARKT-KERN" with these numbers, limits marked "VERFEHLT" (missed).
- Tests T550–T555 (T-MA1–T-MA3, T-Ü1–T-Ü3).

## 0.65.105
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **No more posting too cheap when the market rises 125–150 %.** With a full price ladder (≥ 3 offers or ≥ 5 pieces)
  the suggestion is always just below the cheapest offer; your old learned price only applies to single outliers.
- **Warning guard (on by default):** clicking "Post" with a price more than 10 % below the cheapest offer (full ladder),
  more than 25 % below market value, or below the vendor/your purchase price: nothing is posted – raid warning sound,
  the button flashes red and a window asks: "Adjust price (…)" (Enter) / "Post anyway" / "Cancel", showing how much
  you would give away. Series and re-posting are stopped the same way. Buying above the target's max price, above
  "Worth up to" or more than 25 % above market value (without buyout) warns too – press again within 10 s to buy
  anyway. Options: warning guard on/off, sound on/off. Every warning is logged (WARNSCHUTZ).
- Tests T542–T549 (T-AB4d, T-WS1–T-WS6).

## 0.65.104
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Command list while typing "/ahs": a mouse click now selects a command, Enter runs it.** The list stays open after the
  click, the chat input gets the focus back, and the header shows "Enter = /ahs …". If you then press Enter with the
  beginning you typed (e.g. "/ahs ent"), the selected command runs. A selection is valid for 10 s; Tab selects the next
  entry. The chat input is still never written to (no taint).
- Tests T537–T541 (T-CH1–T-CH5).

## 0.65.103
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchant limits must be right:** "[Disenchant worth it]" in the buy list only when the price is at most "Worth up
  to" (minimum profit) with fresh material prices – before it appeared as soon as the value was above the price.
- **Sniper targets from disenchanting follow the limit:** if "Worth up to" changes by more than 5 % (new material
  prices), the max price is adjusted and reported once in chat.
- **Reference check in the test routine:** the groups 26–30, 31–35 and 36–40 are recalculated independently from the
  scan prices (cheapest − 1c × chance × average amount) and compared with the value the addon uses; more than 5 %
  difference is an ERROR naming the material, its source and age. One report line per group.
- **Vendor prices after the hotfix of 10.11.:** the game's own vendor price comes first; the remembered table is only a
  fallback and is updated when the game reports something else. Vendor flips only with a price confirmed by the game.
- **Minimum deposit 1c (announced for 17.11.):** measured automatically when posting – nothing fixed in the code.
- **AHSentinel.API:** new `WorthUpTo(itemID[, qty])` (same "Worth up to" as the tooltip) and `MarketState(itemID)`
  (normal / buyout / flood / thin / old) for ProfessionSentinel.
- Tests T530–T536 (T-HP1, T-HP2, API-PM, T-ST1–T-ST3).

## 0.65.102
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **My auctions: sold auctions disappear after "Refresh"** (and when you open the view); newly sold ones stay visible
  until the next click. The header still counts all sold auctions. New button "Sold: on/off" to show them.
- **Sell suggestion with a single expensive offer** (thin ladder ≥ 150 % of market value): market value instead of
  just under the outlier. "Post cheaper" is never shown while the competition is above the market value.
- **Vendor flips:** a vendor price above twice the market value is treated as wrong (e.g. Iron Grenade) – no vendor
  flip with it.
- **Comprehensive tests (TU1–TU4, TU6):** every market situation (normal, buyout, outlier, flood, thin, empty, old,
  falling/peak, wrong vendor price, relist) runs through the sell suggestion, ladder detection, hints, disenchant buy
  price and vendor check; player flows (typed price, three Sniper targets); default values of empty fields (listed in
  the test report); invariants with 1000 random ladders and random bookkeeping sequences. The test report has one line
  per area (TU1–TU7) and "Regressions: n of m present". Tests T513–T529.
- **Offline tests (TU9):** `tests/run_offline.sh` in the AHAnalyzerPro repository runs the test routine in a simulated
  game without WoW (Lua 5.1).

## 0.65.101
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sell suggestion follows a buyout.** If the whole price ladder is high (buyout or new market situation: cheapest
  offer ≥ 150 % of market value with at least 3 offers or 5 pieces), the suggestion is just below the cheapest offer –
  no longer your old learned price. Hint: "Buyout – sell high now, the price usually drops soon (2 h)" instead of
  "post cheaper"; the expiry counter is ignored in that case. "Sells only ~N" is hidden until the sales measurement is
  released.
- **A price you typed stays.** A finished price check no longer overwrites a price you entered by hand; changing the
  item or clicking "Suggestion"/"−1" makes it automatic again.
- **Sniper keeps several hits.** If two targets find hits at the same time, both stay buyable (best gap to the max
  price first, then the next); expired hits drop out. Status: "N more hits waiting".
- **Sniper quantity empty:** commodities buy as many as the budget allows ("Quantity: up to budget (N pcs)"), gear 1.
  Warning when quantity × max price is far below the budget.
- Tests T509–T512 (T-AB4c-a/b, T-SM1, T-SM2).

## 0.65.100
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Price history is compacted (smaller save file).** Full detail for 48 hours, then one value per hour up to 7 days,
  then one value per day up to 60 days; older entries are dropped. Items without new prices for 30 days keep only
  daily values. A compacted value is the median of that hour/day, so market values stay the same. Runs in small steps
  90 s after login; the test report shows the estimated size per area and the last compaction.
- **Duplicate repair is safe for commodities:** only "pending" bookings close in time are removed, never completed
  sales (one auction of a commodity is often sold piece by piece at the same price). Removed bookings are kept in a
  side list, and every repair is stored with date, version and count (test report).
- **Full scan check no longer locks forever:** the reference count expires after 24 hours, and two full scans in a row
  with a similar smaller count are accepted (market really smaller).
- **Old purchase price after a restart:** only counted from the oldest entry the disenchant log still covers.
- **Buyout:** the test log notes both prices when a buy calculation uses the price before the buyout.
- Tests: material prices in the test sandbox are always fresh (T223/T230/T425 no longer depend on your real prices);
  new T502–T508 (T-VF5f, T-MP2b, T-PD5c, T-PD7a, T-MP1, T-AB8c, T-AB4b).

## 0.65.99
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **An empty full scan changes nothing.** If the server answers a full scan with no or far too few auctions (under 30 %
  of the last valid one), no market, sales, rhythm or tracking data is taken over: "Full scan without answer – nothing
  taken over." Sales estimates only come from two valid full scans.
- **The Sniper pauses while a full scan is running** (about 30–90 s) – the full scan has priority. The 15-minute lock
  alone does not stop the Sniper. Status line: "waiting: full scan running".
- **Forecast: one case per purchase.** The same purchase could appear many times in the forecast journal. Purchases now
  carry their auction; repeated reports are not recorded again. Existing duplicates are set aside once (not deleted,
  kept in a side list) when the number of identical cases exceeds the purchases in the bookkeeping. Report: "Duplicates 0".
- Tests T499–T501 (T-PD5a/b, T-PD2); simulation test for "scan with commodities updates their price time" (T-MP1).

## 0.65.98
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper purchases are booked at once, even when you buy quickly in a row.** Before, the purchase event could arrive
  after the next purchase had started and was then only booked when the invoice came – disenchanting in between counted
  with cost 0. Every purchase is now remembered by its auction and booked when its event arrives; never twice.
- **Disenchanting an item without known origin** is marked "without purchase" instead of silently counting 0.
- **Correction after a restart (0.65.97) fixed:** material sales that received the cost of the corrected disenchants
  no longer count as "without purchase" – the return is right again and the 30 % warning disappears. Data already
  corrected by 0.65.97 is fixed once at login. Costs without a target (material passed on) are noted in the log.
- **Duplicate "pending" sale bookings from 0.65.93/0.65.94** (without the new ID) are now found and removed once
  (stock restored); real partial sales of the same size stay.
- Tests T491–T498 (T-AB8c/d, T-AB1b–d, T-VF5e, T-PD1a/b).

## 0.65.97
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Bookkeeping restart keeps purchase prices (opening balance).** Goods bought before a restart (bags, bank, mail,
  own auctions) keep their purchase price from the old data; only the profit counters start at 0. Goods without any
  purchase (loot) keep the value at the restart. A restart that lost the cost basis is corrected once at login:
  disenchants with cost 0 get the price paid for the item, and the cost moves to the materials (sold ones into the
  sales, the rest into stock). The diagnostic log notes how many bookings were corrected.
- **Plausibility checks:** warning in the profit tooltip if more than 30 % of revenue is "without purchase" or the
  disenchanting return is over 100 %; the test report shows an ERROR for disenchants with cost 0 of a bought item.
- **Gold reconciliation from the same moment as the bookkeeping** (later of day start and restart). Pending sales
  ("arrives by mail") are shown right there; "not booked" only appears above 1 % of turnover.
- **Profit % per item** only from pieces with a purchase (like the header).
- **Posting:** no more Lua error after a successful post. Before posting, AHSentinel checks that the item is still in
  the bag slot; otherwise "Already posted – no longer in your bags". The button stays locked until you select an item.
- **My auctions:** instead of "?" the status shows why the price is not checked yet (AH closed, waiting, Sniper
  searching, server throttling). Your own auctions are checked before the background material prices. Cancelling is
  logged step by step (test log), the cancelled row disappears at once.
- **Buyout (e.g. Soul Dust at 3× the price):** never a buy signal; for your own goods "Expensive now – sell … · Buyout
  – price may drop quickly".
- **Outdated prices:** every material with ≥ 25 % of the disenchant value must be fresh, not only the main material.
- Diagnostic log: type of the last scan in PREIS-ALT; posted vs. server price of your own auction (EIGENE-PREIS).
- Tests T484–T490 (T-AB1, T-AB2, T-AB4, T-AB5, T-AB7, T-AB8a/b).

## 0.65.96
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **AHSentinel now tells you when to buy and when to sell – but only when it knows it from its own measurements.**
  One tooltip line, only if proven: "Cheap now – buy (−x % below usual)", "Falling – wait", "Expensive now – sell
  (+x % above usual)" or (your own goods / Sell tab) "Don't sell now – better at <hour> (+x %)". Otherwise no line.
  The same line appears in the Buy and Sniper details and in the Sell tab (there only the selling variants).
- **Rhythm for all items from the scan:** once per hour each item's lowest price and quantity (sales = quantity drop)
  are stored compactly per hour of day and weekday (own weekly rhythm, e.g. raid days from 9.12.). Items without
  offers for 14 days are removed; even 5,000 items stay below 2 MB.
- **Honest:** only with a fresh price (≤ 30 min), never with a buyout flag or outdated material prices, only from
  ≥ 7 days of data and ≥ 3 values for this hour, and only if the deviation is ≥ 10 % and outside the item's normal
  fluctuation. "Buy" never into a fall: if the daily price has been falling for 2 days, it says "Falling – wait".
- **Every line is checked afterwards** (24 hours later or at the named time). A signal type with less than 60 % hits
  (from 20 cases) is hidden until it is better again. Hit rates are in the test report. With Shift and too little data:
  "Rhythm: N more days of measuring".
- Tests T477–T483 (T-JK1–T-JK6).

## 0.65.95
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **"Worth up to" in every tooltip of a disenchantable item** – also in your bags, bank, mail, chat links, at the
  vendor and in other windows (other players' gear, loot). It is shown to everyone, with or without Enchanting, and in
  the short tooltip mode too. In the bags it stands right above the two ways (disenchant / sell). The existing option
  "Disench.: on/off" switches the whole disenchant part off together.
- **Never decide with outdated material prices.** If the material that carries most of the disenchant value has no
  price newer than 6 hours: tooltip "Worth up to: Prices outdated – scan first" (no amount, verdict "unsure"), Sniper
  disenchant targets do not buy ("Material prices outdated – scan first"), and the Market "Disenchant" view offers no
  row. Sell values of your own stock still show the old price with the "old" hint.
- **Fresh material prices at the open AH:** after a scan and when you open the AH, the disenchant materials (up to 15,
  most used first) whose price is older than 30 minutes are fetched one by one (throttled). The diagnostic log notes
  the scan type, how many commodities the full scan contained and the price age of the three main materials (PREIS-ALT).
- **Buyout flag stays until disproven:** a material flagged as bought out keeps the price from before the buyout
  across sessions and days, until a newer scan shows the quantity back at ≥ 50 % or the price back at ≤ 120 %.
- **Bookkeeping fixes:** partial sales of the same auction booked by 0.65.92 or older are no longer booked a second time
  (existing doubles are repaired once at login, cost basis restored). Sync merge: positions of the same character
  bought on two computers are now added up (5 + 3 = 8 with both costs). The merge package also reads the older field
  names, and the merge report counts disenchants without a log entry.
- Tests T467–T476 (T-LB1–T-LB4, T-MP1–T-MP3, T-VF5c/d, T-ZM5).

## 0.65.94
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Bookkeeping: return next to the profit.** The head now shows "Profit X · Return Y %" (profit of goods you bought ÷
  what they cost you). Without any cost: "Return –".
- **Where you lose money** (tooltip of the profit): the business type (disenchanting, flipping, crafting, vendor
  goods) and the item with the biggest realised loss, with the amount – or "No losing business". The type comes from
  where the cost came from (AH purchase = flipping, from disenchanting = disenchanting); mixed or unclear = "unknown".
- **Honest about free goods:** profit from goods you never bought (loot, farming, quests) is shown separately in the
  head ("of which without purchase: X", only if any) and does not count in the return.
- Tests T463–T466 (T-BE1–T-BE4).

## 0.65.93
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix: partly sold auctions can be cancelled again.** For goods, the sold parts of an auction keep the same auction
  ID as the remaining active quantity. Cancelling (X in the row and "Cancel next undercut") picked a sold part and
  answered "This auction is already sold." Now the row cancels exactly its own entry and the active remainder is used.
- Bookkeeping: two partial sales of the same auction are both booked as "pending" (no longer skipped), the active
  remainder is not counted as sold.
- Tests T461–T462 (T-VF5a/b).

## 0.65.92
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Smoother fast full scan.** Processing after the full scan now uses a time budget per frame (default 4 ms,
  option 2/4/6/8 ms next to "Fast full scan" – smaller = smoother but longer). The tables per item are reused between
  scans and the digest no longer creates garbage per item, so there is far less memory churn. Everything that is
  rebuilt after the scan (market lists, caches) now runs in portions instead of all in one frame. The option text
  warns that it can still stutter until the next measurement.
- **Measurement extended:** frames per second per step, share of frames over 33 ms, and AHSentinel's own memory
  before/after (test report section "Full scan measurement"). New checks: no step with a frame over 16 ms, memory
  growth ≤ 10 MB.
- "Cancel next undercut" only ever cancels auctions with status "undercut", never "keep"; the test routine only
  touches its own test auction.
- Market values of 0 or less are no longer possible (a price of 0 is not stored); the self-test names the items.
- Test routine: the sniper's "last checked" time no longer counts as a sandbox error.
- Tests T458–T460 (T-VF1–T-VF3).

## 0.65.91
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Merge data from two computers.** If you played on two computers without syncing in between, the GoldSentinel
  uploader can hand AHSentinel the other computer's data (saved variable `AHSentinelMerge`). On the next login
  AHSentinel merges it once and empties it: disenchant results are combined without counting anything twice (only
  missing results are added – nothing is ever lost), purchases, bookings and forecast cases are combined, price
  history is combined per item, the newer full scan and character data win, and your settings on this computer stay.
  Chat: "Data from the other computer merged: …".
- Tests T454–T457 (T-ZM1–T-ZM4).

## 0.65.90
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper hit signal.** When the sniper finds a real hit, the screen edge glows gold 3 times (like the low-health
  glow). It stops when you buy, when the hit is gone, when you close the auction house, or after 4 s at the latest.
  No signal for dead offers, paused items, in combat or with the auction house closed; at most one signal every 3 s.
  Options: "Signal" on/off and colour (gold, green, blue) next to "Sound on hits". The glow never takes mouse clicks.
- Tests T450–T453 (T-SG1–T-SG4).

## 0.65.89
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **New bookkeeping: profit like the pros.** Buying is no longer a loss – what you buy sits in your stock at its
  purchase price, and profit is made when you sell: revenue after the 5 % cut − the purchase price of exactly what
  you sold − lost deposits. The ledger head now shows ONE number, "Profit", for today / 7 days / 30 days / since
  restart, with "Sold · Cost · Fees" below. Everything else is in the tooltip: cash, stock at cost and at market
  value, unrealised profit, pending sales and a check against your gold ("not booked: X").
- **Fresh start.** On the first login with this version the books start today. Your old data stays in the background
  (statistics, sell rates, forecasts keep using it) but never counts in the new books. Disenchant, learning,
  forecast and full-scan data are untouched. Items you already own get their realistic value at the start as cost,
  so selling old stock is neither pure profit nor a loss. `/ahs buchhaltung neu` starts the books again (asks first).
- **Cost per item and character (moving average).** Disenchanting moves the cost of the item onto the materials by
  their value; mail to your own alts carries the cost along. Items without a purchase (loot) have cost 0.
- **Sales count right away.** As soon as your own auction shows as sold (in Forever the chat message is protected),
  it is booked as "pending"; the invoice confirms it later – never twice. The test report measures the delay.
- "Per item": Sold, Revenue, Cost, Profit, Profit %.
- Tests T441–T449 (T-BP1–T-BP9).

## 0.65.88
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Market "Disenchant": cost and profit over the whole price ladder.** Each row now sums every ladder step up to
  "worth it up to": quantity, total cost, average price, total profit and return (sorted by it), e.g. "40x up to
  15s 43c (avg 12s 38c) · value 18s 55c · profit 2g 47s (50 %)". The quantity is filled from the cheapest step up to
  25 % of your gold (option); the sniper gets exactly this cost as budget and "worth it up to" as max price. Row and
  footer show the same quantity.
- **Value drops with your own quantity** – one function for market, batch buy and tooltip: the more parts you plan
  to buy, the lower the material value (planned quantity, not budget / price).
- **Safety at most "medium" when the main material just rose**, plus "without the rise: X" in the row and detail.
- **Buyout detection (someone buys up a material).** Quantity −70 % within 6 h and price +50 % over market value
  marks a buyout until quantity or price normalise. Buying (market, batch buy, "worth it up to") then uses the old
  price ("Buyout of X – valued at the old price"); selling stays at the current price with "price artificially high –
  sell your own stock now". The test report lists flagged materials (thresholds are measured).
- **"Level ?" fixed**: rows are redrawn when the item data arrives.
- **Shopping list: "~" rows (from the scan) with empty detail fixed.** Before the detail search, a scan row first
  gets its real item key via a browse search by name (suffix/item level). If the browse finds nothing, the row is
  removed right away ("No offers left – removed from the list"), also from "Disenchant worth it", and the scan does
  not bring it back until a newer scan lists it again. "~" rows older than 30 min no longer count for batch buy.
- **Forecast: sales from invoices are assigned again.** In Forever the mail arrives faster than 1 h, so the sale time
  was before the posting and the case counted as "not sold". Partial sales count as a share. The test report shows
  a per-case diagnosis (where each result comes from); the self-correction only learns from cases after this fix.
- **Disenchant forecast split up**: chance × quantity × rest (price etc.) per group in the test report.
- Background tasks yield ahead of time (a frame no longer gets budget + one long step); "Today" computed in smaller
  portions.
- Test routine: the real sync address book and a running sniper hit no longer count as sandbox errors; report paths
  never contain player names. Price tests replace all price sources. Batch buy uses the planned quantity.
- Tests T425–T440 (T-X3–T-X8, T-MD1–T-MD6, T-SR8a/b).

## 0.65.87
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix: Lua error on sale messages in WoW Forever.** Protected ("secret") chat and event values are never read any
  more (sale message, purchase, mail, posting and legacy AH events).
- **"Check undercuts" no longer freezes the game.** Only active auctions are checked, one search per item, without
  rebuilding the list after every item: the list is redrawn ONCE at the end. Every step is timed; steps over 50 ms
  appear in the log as LANGSAM.
- **Full scan measurement (for the big test).** The fast full scan now times every step (wait for the server, event,
  reading, digest, tracking, price history/rebuild), the longest gap between two frames (the real freeze), memory
  and garbage collections. The test routine part "server" starts one real fast full scan (read only) and reports it
  in the section "Full scan measurement"; a step or gap over 1 s is an ERROR naming the step. Nothing else changed in
  the full scan.
- **Fix: a single 2c offer no longer crushes material values.** The price ladder is capped only by the cleaned scan
  price, never by the raw minimum; without a cleaned price the ladder value counts as "market, unsure".
- **Fix: stock value too high after everything sold.** An empty list of own auctions (queried, all sold) now means
  "nothing in the AH"; old end times and the forecast journal are used only if the auctions were never queried.
- **Sniper: dead offers are hidden completely.** An offer whose purchase failed or that the server delivers again
  after "gone" disappears for the session (by auction ID, at most 48 h): not in the sniper, shopping list, undercut
  check, current price, price ladder from searches, "% market" or batch buying. Goods without auction ID: after 2
  failures. The status line shows "1 dead offer hidden (price, reason)", log SNIPER-TOT-AUSGEBLENDET. After 3 failed
  different auctions of the same item the item pauses for 10 minutes (log SNIPER-PAUSE). A new auction at the same
  price stays buyable.
- **"Cannot be disenchanted" no longer blocks a whole class.** Learned blocks are per item; a class (e.g. leather
  armor) only after 3 different items failed. Such items now show in "Blocked (N)" as "cannot be disenchanted
  (Forever)" with Release; `/ahs entzaubern freigeben` releases them too.
- Test routine: T410–T424 (T-0, T-UP1–3, T-VM1/2, T-X1, T-X2a/b, T-SR7a–c, T-ME10/11), coverage list extended.

## 0.65.86
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper: dead offers stay gone.** An offer whose purchase failed (e.g. "a higher bid already exists") is locked by
  its auction ID for 10 minutes: if the server delivers it again, it stays "gone" (red) and is never tried again. A
  new auction at the same price stays buyable. Goods without an auction ID: the same price and quantity are skipped
  for 60 s. Log SNIPER-SUCHE counts "dead delivered again".
- Test routine: T409 (T-SR6).

## 0.65.85
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix (important): no more fake flips.** The resale price never uses the estimated price of the part above the stored
  price ladder (the "11s 39c" for a box that sells at 4s came from there). Without a current price ladder there is no
  flip suggestion. The buy quantity is at most what is really offered up to the buy price.
- A flip row in Today/Flips appears only if the detail area says "buy up to X" with exactly the same calculation;
  otherwise it is dropped (log FLIP-WIDERSPRUCH). Clicking a row in Today now also shows it in the detail area.
- **Wands are never suggested for disenchanting** (not possible in WoW Forever). If disenchanting fails with "cannot be
  disenchanted", the item (and its class) is excluded everywhere from then on (log DE-NICHT-MOEGLICH).
- Test routine: T403–T408 (T-F1–T-F4, T-ME8, T-ME9).

## 0.65.84
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper searches by itself again:** the quick full scan (ReplicateItems) no longer blocks the sniper's item search;
  a running shopping search or price check blocks at most 20 s. Opening the AH (also after /reload) starts a search
  right away. Instead of "Nothing searched yet" the sniper shows its state: "next search in 12 s · last 40 s ago:
  5 hits" or "waiting: market scan running", plus "full scan lock N min left (sniper searches anyway)". Log
  SNIPER-SUCHE (target ID, offers, hits ≤ max, bought, block reason; no names).
- **"Purchase failed" only once:** the same offer is reported once; further failures within 30 s become one summary
  line. The failed offer is marked "gone" and never retried – the next wheel tick buys the next matching offer; if
  none is left, a new search starts.
- The warning "Max above sell value" uses the same value as the tooltip (for disenchant items the disenchant value).
- Test routine: T399–T402 (T-SR2–T-SR5).

## 0.65.83
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **New market view "Disenchant":** items that bring at least 20 % profit after disenchanting – at the current market,
  after fees. Per row: item (level), price now and quantity up to "worth it up to", value after disenchanting, profit
  per piece and %, safety (green = real results, grey = table). The "Buy" button sets a sniper target (max = worth it
  up to, quantity, budget) – nothing is bought without a click.
- Filters: only items your character can disenchant (enchanting skill), minimum profit 20 % (option 10–50 %), market
  budget (25 % of gold), no row if the main material crashed or is flooded; yellow if the value depends on a freshly
  risen material price. Material sales only as a safety net (more than one day of sales incl. your stock → shortened,
  yellow note).
- Detail on the right: materials with chance, average quantity, current price and hint; your own group results;
  "worth it up to". Footer: only the current purchase (selected row) – no sum of all rows.
- Test report: median time until sale per material (forecast journal).
- Test routine: T392–T398 (T-ME1–T-ME7).

## 0.65.82
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Prices from the current market (your decision):** values come from the current price ladder and sales only – no cap
  and no mixing with the market value (average). The market value is only a warning: "price just rose (for N h)",
  "price dropped (for N h)", "old (N h ago)" when the last scan is older than 2 h, "estimated" without any scan. The
  number itself is not changed. With Shift the source: "price ladder, 311 pcs, sales ~20/day · market value …".
- **Market uses at most 25 % of your gold (your decision):** all buy suggestions (Today, Flips, Vendor) together at
  most this share; the best profit per gold first, a suggestion that does not fit is shortened, otherwise dropped.
  Footer "Capital needed X of Y (at most 25 %)". Option "Market: at most % of gold" (default 25, at most 50); the
  daily budget per strategy follows it.
- **Implausible sales:** at most 2× the average quantity per day and 25 % of the current offer per hour; measured
  values above that are not used (log ABSATZ-UNPLAUSIBEL). Flip texts say "estimated" or "measured, N days".
- **Ledger header:** the stock tile shows "Stock X (in AH Y) − at start Z"; the tooltip computes "Cash + stock − stock
  at start = result". Purchases used for professions (trade goods bought and gone) are shown separately: "Trade ±A ·
  professions −B". Running own auctions also count from the forecast journal when the AH was not queried.
- Test routine: T371 (T-AM1), T384–T391 (T-AM3/4, T-K1–3, T-LG6–8).

## 0.65.81
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix (important): honest material prices for disenchanting.** The material price is the realistic sell price from
  the price ladder and sales (no longer capped at the market value). The tooltip says where it comes from: "Scan" only
  for scan values, otherwise "Market" or "price just rose (for N h)". If scan and market value are more than 50 % apart
  the price is grey "unsure"; with Shift both values are shown. A fresh jump (< 24 h) counts at most 1.5× the market
  value; after 24 h the ladder price counts (log MARKTWERT-CHECK). Bait offers (1–2 pieces far below the median) no
  longer pull down the market value from the price history.
- **Disenchant block list with a way back:** right-click asks first ("Yes / Skip just this once / Cancel"). New button
  "Blocked (N)" with a list to unblock single items or all. The empty window says how many items are blocked/skipped.
  `/ahs entzaubern freigeben` unblocks all.
- Speed: the full forecast evaluation no longer runs in the tooltip or after ledger changes; it is computed in the
  background in portions, the tooltip reads the cache.
- Full scan: "/ahs vollscan messen" measures a shorter interval once per session (asks first); the wait message no
  longer claims a server limit ("as a precaution, not measured yet").
- Buy forecast "resell" uses the realistic resale price. Sync: old scan announcements are cleaned up.
- Removed outdated fee texts and unused keys.
- Test routine: T369–T383 (T-HF9–11, H5, T-SK1/2/5, T-SP1–4, background check ≥ 16 ms, 3000-entry tooltip check),
  explanation line "learned vs. history" in the disenchant report.

## 0.65.80
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix (important): ledger stock.** "Result with stock" showed −9g 60s and "Stock −8s 22c" although about 4.7g of goods
  were in the bags. The stock value is now never negative: bags and bank at the realistic sell price after fees (at
  least the vendor price) plus your running auctions (listing price × 0.95, deposit already paid). The start of the
  day is saved as a list of items and valued at today's price too, so the tile shows the "result if everything is sold
  at today's price". The tile shows "Stock X (of which in AH Y)"; Per item has a new column "in AH".
- Disenchant settlement: per batch and in total – purchase, loot sold / in AH / stock, fees, result.
- **Fix (important): purchases booked exactly once.** A purchase event only books the purchase with the same
  auction ID (a late event could book a different purchase before); every auction at most once. Purchase invoices in
  Forever: quantity never 0, total from the invoice. Invoice and purchase message are matched by item and quantity
  even if the amount differs (the invoice amount counts, log KAUF-DOPPELT). `/ahs doppelt` lists possible old double
  entries; `/ahs doppelt bereinigen` cleans up clear pairs with a backup (`/ahs doppelt zurück` undoes it).
- Test routine: T364–T368 (T-LG1–T-LG5).

## 0.65.79
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Test routine never touches your disenchant data:** reset and restore tests (and the option test "reset
  disenchanting") now run only on substitute tables – including the backup `deBackup`.
- **Measured sales from the full scan were far too high (10–20×):** for goods (stackable), a partial purchase created a
  new signature, so the whole old stack counted as "gone". Goods are now compared by quantity per unit price (only price
  levels up to the lowest price + 2 %, re-listings at the same price are offset). Sales per day are only extrapolated
  after at least 6 hours of coverage; until then "too short". A plausibility limit (at most 2× the average quantity on
  offer) marks and logs implausible values. Rates from earlier versions (too short pairs) are no longer used.
- Full scan reading: the clock is checked every 25 entries with 5 ms per frame (goal: longest frame ≤ 8 ms).
- Test routine: the ranking check (T169) measures only the ranking job; other jobs are named. The disenchant count
  check only compares entries since counting started (no false alarm).
- Test routine: T360–T363 (T-W1, T-W2, T-W5).

## 0.65.78
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix (important): disenchant buys are valued realistically.** Material prices now use the same realistic resale
  price as flips (price ladder and sales per day), after the AH cut and expected deposit losses. Buying many pieces
  lowers the price: if your materials exceed two days of sales, each further day of sales counts one step lower on
  the ladder. Applies to the disenchant value, "Disenchanting pays", bulk buy and disenchant bargains.
- Tooltip: the verdict shows the profit with percent; with Shift "Profit after selling the materials: X (Y %)".
- Ledger -> Disenchant: settlement per purchase batch, e.g. "Batch 10.11.: paid 5g, sold Xg, stock Yg, fees Zg,
  result ±Wg" (mouse over shows all batches).
- **My Auctions:** "8 sold (4g 42s 77c, received 4g 20s 60c)" – received = per auction total × 0.95, rounded down.
  A footer shows the totals of the list per status; with Shift the summary tooltip shows today's total from the ledger.
- **Sniper:** "Result is outdated – bought in this search: 23 for 2g 30s · missed 13 – new search needed." The target
  row shows "50/100 bought · budget 5g used up" (or "budget left …") in full. When the budget is used up you get one
  chat message and a header line; the target stays in the list. The target tooltip explains how many pieces the
  budget allows.
- Test routine: T351–T359 (T-HF8, T-MS1–3, T-SN1–3).

## 0.65.77
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix (important): no more fake flips.** "Today" suggested e.g. "buy 4x Unstable Magic Particle up to 45s 97c, post
  again for 2g 3s" – but 855 pieces were on offer at 46–50s; 2g 3s was an outdated offer price. Now ONE realistic
  resale price is used everywhere (Today, Flip, details, watcher): the price at which fewer pieces wait in front of you
  than sell during your duration (price ladder of the full scan or the search), at most the learned normal price and
  the market value; without a ladder at most 15 % above the current lowest price.
- No flip during a price crash or when the supply is flooded (3× the usual amount) – such items show up in "Crowded".
- List and details never contradict each other: a buy row only appears if the details say "buy up to X" too.
- Honest flip profit: after the AH cut and expected deposit losses, quantity at most what you can sell in your share
  of the market.
- Market views no longer stay empty while sales are not yet measured: estimated sales are used and marked grey
  ("estimated"); an empty view says why. Switching views clears the details (or shows the first row).
- **My Auctions:** total of sold goods in the summary line (gross and after the AH cut).
- Test routine: T344–T350 (T-HF1–T-HF7).

## 0.65.76
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Full check after all steps:** `/ahs testroutine alles` runs the automatic part and then the server, professions
  and vendor parts one after the other. If a window is missing, one line says what to open; it waits up to 2 minutes
  and then continues.
- **Test report:** five summary lines at the top (OK/errors, what is left to do in the game, forecast hit rate,
  measured sales available for N items, storage). A coverage list maps every task and test case to its checks or
  says why it can only be checked in the game. Sections with real data: disenchanting, forecast quality, full scan,
  learning database, market tab, gear measurement. The sandbox compares all real tables (also journal, learning, full
  scan); storage sizes and loading time are in the report.
- **Measurement "gear in whole silver"** (`/ahs messreihe`, only with your agreement): with a few cheap grey/white gear
  items it posts at 1s 00c, 1s 01c, 1s 50c, 1s 99c, 2s, 10s 50c, 1g 00s 01c and once with a bid, plus one commodity at
  1s 99c – every posting is cancelled right away, every step is one click, at most 10 postings, costs shown first.
  The result goes into the log and the test report. The price rounding stays as it is until the measurement proves
  otherwise.
- Price sync: a partial price list from the network no longer stops a guild member with a full scan from answering.

## 0.65.75
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **New "Market" tab replaces "Today" (step 3):** one bar with 6 views – **Today** (the former "Today" list: your
  things first, then the best chances), **Flip** (below your buy limit, by profit per gold and day), **Vendor**
  (buyout below vendor price), **Gaps** (low supply, steady sales, rising price – your stock first), **Crowded**
  (don't post: far more supply than sales, days until sold, deposit risk) and **Trends** (stable 7/30-day moves,
  falling levelling goods first). Each view: one explanation line, at most 20 rows, one number, confidence as colour,
  one button – the button works exactly as before (check -> buy -> post, never without your click).
- **Details on the right:** click a row or search an item at the top: price and supply over 14 days, price ladder,
  your own history, learned price limits and ONE recommendation ("buy up to X" / "post for Y" / "leave it") with the
  reason; buttons Watchlist, Shopping list, Sniper (with the suggested limit), price history.
- **Market today:** a price index of typical goods at the top ("Market today +3 % (7 days +8 %)").
- The list of all items is gone from the tab bar (the data stays and all views use it); look items up via the search.
- `/ahs heute`, the Today button and other addons (ProfessionSentinel QuickBuy/QuickSell rows on top) open the Market
  tab on "Today". New option: "Market: default view".
- Test routine: new part "m" (market) and a section "Market tab" in the report.

## 0.65.74
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Learning database (step 2, invisible):** AHSentinel now learns in the background from your own results – nothing
  new to operate, only better numbers in what you already use. Option "Learning" (on) switches it all off again.
  - Chance to sell per price level (price ÷ market value) and duration; expired and cancelled auctions count as "not
    sold" (never left out). Few own cases are pulled towards the item group, then towards shared numbers of all
    players (sync, counts only, no names), then a start value.
  - Price limits per item: the Sell tab suggests the learned normal price when nobody competes or the competition is
    above your maximum; the minimum includes fee and expected deposit losses.
  - Sell tab: "only ~N sell in this duration – keep the rest in your bags". My Auctions: "higher possible" when the
    cheaper competition is gone (cancel only by your click).
  - Safer buying: watcher, bulk buy, flips and disenchant deals use a safety margin from the measured error (20 % until
    20 buys, then at least 10 %) and a daily budget per strategy (10 % of your gold) while its hit rate is below 60 %.
  - Today: a hint when something you bought fell more than 25 % in value ("sell now brings X, waiting expects Y").
  - Rare items: own sales estimated with Croston; market sales use a learned factor per group (from the full scan)
    instead of the fixed 20 % cap.
  - Self-correction every week or 50 new results (damped ±30 %, log "LERNEN"); rhythm (cheap/expensive hour and
    weekday) after 21 days, only when stable.
  - Option "Try higher (+5 %)" (off): every 10th posting suggests 5 % more to learn the price sensitivity.
- Tooltip (Shift): "Chance to sell at market value: 72 % (learned from 23 own sales)", rhythm if known.
- Test routine: new part "l" (learning) with fixed numbers; report and GSTEST1 get a section "Learning database".

## 0.65.73
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fast full scan (new option, off by default):** in the modern auction house (WoW Forever) the scan button can read
  all single auctions at once with their time left (ReplicateItems) instead of browsing page by page. Read in small
  portions, so the game stays smooth; at most every 15 minutes, otherwise the normal scan runs. `/ahs vollscan` starts
  it once. Prices, market value and history are fed exactly as before (lowest price, quantity; bait offers don't count).
- **Exact queue:** "how many are in front of me" now counts only the pieces at your price or cheaper (price ladder
  from the full scan) instead of all pieces of the item.
- **Real market sales measured:** between two full scans AHSentinel compares the auctions (quantity and buyout, no
  names): gone early with a long time left = bought or cancelled, gone with a short time left = expired (not a sale).
  After 3 days of data the tooltip (Shift) shows "~12/day (measured, 5 days)" instead of the old estimate; until then
  "(estimated)". Your own auctions are used as a cross-check (share of cancels).
- Era/TBC: unchanged (the old auction house has no full scan).
- Test routine: new part "v" (full scan) with fixed numbers; report and GSTEST1 get a section "Full scan" (timing per
  frame, throttling, meaning of the time-left stages, measured sales).

## 0.65.72
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Forecast journal (step 1 of "check every forecast"):** whenever you post, buy or disenchant, AHSentinel now notes
  in the background what it predicted at that moment (chance to sell within the duration, expected hours, number of
  postings, net value; for buys the planned way and value; for disenchanting the expected material value). Later it
  matches the result: sale invoices (oldest posting first, partial sales count proportionally), expired and cancelled
  auctions (counted as "not sold", never left out), loot from disenchanting, what became of bought items.
  No names, compact (at most 3000 entries, older than 60 days only in a small summary). Your ledger, disenchant
  results and price history are only read, never changed.
- **Tooltip (Shift):** once there are 20 own results in the item's group: "Forecasts for you: X % correct (N …)".
- **Test routine:** new part "p" (forecast) with fixed-number checks (Brier score, reliability table, FIFO, partial
  sale, expiry, cancel, ring buffer, size < 300 KB, no names); the report and the GSTEST1 export get a section
  "Forecast quality" from your real data (read only).
- Measurements: which replicate functions exist (only checked, never called), which fields the item search returns,
  and the lowest price/quantity per hour of the day for items you trade or watch (evaluated later).

## 0.65.71
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchant statistics:** rejected results (material outside the table) count as disenchanted and their loot counts,
  but they are shown separately: "(of which rejected N)". They never count for learning.
- **Restore disenchant results:** after a reset the button in the options becomes "Restore" and brings back the last
  backup exactly.
- **Faster tooltip:** the price chart under the tooltip is only redrawn when the item or its data changed.
- **Test routine:** the tooltip speed check shows the time per block; at the end of the report one line says what to
  do for the skipped parts (e.g. "open the auction house, then /ahs testroutine server").

## 0.65.70
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix: options overlapped** (e.g. "Self-test" over "Default duration"): there were more options than fit in two
  columns of 18 rows. Each option now gets its own place (20 per column, more columns if needed).
- **Your disenchant results are protected:** "Reset" (Options → Disenchant learned) asks with the number of results
  and saves a backup first. The test routine checks that disenchant data is unchanged after the run (count and
  quantity sums) and reports any difference.
- **Disenchanting:** loot without a single disenchant material (mob, chest, skinning) is never counted as a
  disenchant; the loot must arrive within 5 seconds.
- **Test routine:** new report section "Disenchanting (real data)" – per group own/shared results, rate per material
  against the table (unusual values marked), daily count check and plausibility; also in the GSTEST1 export. New checks
  for the whole chain (spell → loot → counted), learning formula with fixed numbers, shared results and values.
- Tooltip: chance source for disenchant group "up to 15" named correctly.

## 0.65.69
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix: ledger showed the price as quantity** (e.g. "sold 22000" for ONE cap): on some WoW Forever invoices field 5 is
  the price, not the quantity. It now only counts as quantity if it plausibly is one (never for gear). Saved sales are
  repaired once (backup kept, diagnostic log REPARATUR-MENGE).
- **Fix: positive fees in the ledger:** a refund on sale without a booked deposit (posted via Blizzard's window, another
  addon or before AHSentinel) is now covered by a matching deposit – net 0, like in the game. Postings through
  Blizzard's window or other addons are booked too. Old data is repaired once.
- **Disenchanting is counted on every way:** besides bag clicks and AHSentinel's window, macros and other addons
  (/use bag slot) are now recognised from the bag contents. Results with a material outside the table are no longer
  dropped silently (log DE-ABGELEHNT); every disenchant writes DE-GEZÄHLT or DE-VERPASST. Statistics: "today counted N
  · missed M".
- **Tooltip materials:** learned average quantity ("Ø 1.4"), the table range only with Shift; own and shared results
  named separately.

## 0.65.68
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix (0.65.66): with the 2-hour default duration almost everything looked unsellable** – the valuation counted up to
  six lost deposits for anything that does not sell within 14 hours (e.g. dust showed "vendor"). The Sell tab keeps
  2 hours; the valuation uses 24 hours when that costs the same deposit (minimum deposit), otherwise the default
  duration. With Shift the tooltip shows the duration used.
- **Buyout failed – clear message:** "offer is gone (probably already bought)" instead of "offer gone or not enough
  gold"; the game's message is shown, gold is only mentioned when you really lack it. A gone offer is marked, its
  button locked, and it leaves the shopping list. Diagnostic log line KAUF-FEHLER (no names).
- **Minimum bid:** +5 % only when someone has already bid; without a bidder the starting bid is the minimum. If no bid
  below the buyout is possible, the bid field is hidden.
- **Detail search finds nothing although the scan listed the item:** AHSentinel retries once without item level/suffix;
  if it stays empty the row leaves the shopping list (log line DETAIL-LEER).
- Interface for other addons: price source "scan" only if the price really was in the last scan.
- Test routine: button names with text and position; outdated fee texts removed.

## 0.65.67
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix: the line "110 in your bags: …" did not appear** (e.g. Strange Dust): the tooltip checked "stackable" with a
  game function that is missing on WoW Forever. It now works with every bag addon. If the total cannot be calculated,
  "Sell:" × quantity is shown instead and the diagnostic log gets one line GESAMTWERT.
- **Disenchant chances of green items on WoW Forever** follow the Forever guide (wow-professions.com): armor 75/20/5,
  weapons 20/75/5 (dust/essence/shard); up to item level 15 stays 80/20 without shard. Your own results still count more.
  Other game versions keep the table from warcraft.wiki.gg.
- **Tooltip:** "Materials (table + N own)" when your own disenchant results are included; with Shift the source of the
  chances. Diagnostic log: one line DE-CHANCEN per group and day (table vs. real results).

## 0.65.66
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **New option "Default duration" (standard: 2 hours on WoW Forever):** every new item in the Sell tab starts with it;
  a duration you pick by hand applies only to that posting. Series, repost and "Today" use it too, and so do all
  calculations. "24 h costs the same" remains only a hint.
- **Fix: "Today" told you to sell commodities to a vendor** (e.g. linen bolts) because it assumed 1 piece per auction:
  in the modern auction house a commodity is posted as ONE auction for any quantity – the minimum deposit is paid once.
  The old auction house (Era/TBC) keeps stacks.
- **Sales estimate for crowded items:** auctions on WoW Forever run at most 24 hours, so almost everything disappears
  every day even without a sale. The market sales rate is now capped at 20 % of the quantity in the last scan per day
  (assumption, checked in the diagnostic log). Your own experience (posted vs. sold, from 3 postings) comes first –
  the same number in tooltip, profit window and log.
- **Profit window:** shows the deposit per auction on WoW Forever (back on sale) and the expected number of listings
  with the expected deposit loss.
- **"Today": clicking a row** always does something visible – or shows a hint; errors are no longer swallowed.
- Diagnostic log: ABSATZ with raw rate, cap, own rate and duration; new ENTZAUBERWERT line (materials, chances, net).
- Test routine: watcher setting no longer touched (sandbox), result tooltips beside the window, T33 always with a
  reason, T52 checks "undercut" and "leave it" separately, T27 names the real reason, empty frames of other addons
  are only a hint.

## 0.65.65
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix: posting gear failed with "Internal auction error"** on WoW Forever: the server accepts single items (gear)
  only in whole silver. AHSentinel now rounds the price of single items down to whole silver (at least 1s) and shows it
  in the field; undercutting single items uses "−1 silver". Commodities keep copper prices.
- **Fix: dust and essences were "hardly selling"** (0.65.63): the sales rate now always comes from the market; your own
  sales only raise it, and anything you sell yourself regularly is never "hardly sells".
- **"Today" no longer stutters:** the disenchant deals loop now pauses in small portions; the diagnostic log shows the
  steps per frame for slow background tasks.
- **New: command list while typing:** type /ahs in chat and all commands appear above the input box – the ones you
  use most at the top; keep typing to filter, click to run. AHSentinel never writes into the chat box. Can be turned off
  in the options ("Command list while typing").

## 0.65.64
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Ledger: "Profit" is now called "Cash"** – it is income minus spending minus fees. Bought materials count as
  spending even if they are still in stock (e.g. cloth turned into dust by crafting and disenchanting).
- **New tile "Result incl. stock":** cash plus the change in stock value during the period (bags, bank and active
  auctions of this character, valued like "Sell:" in the tooltip). A stock value is saved at the first login of the day
  and at logout, with the prices of that time. Without a starting value it shows "–".
- **"Per item" has a column "in stock"** (pieces now).
- "1 sale" / "1 purchase" instead of "1 sales".
- **Tooltip:** a price that was not in the last scan is marked "(old)"; if a scan price was replaced as an outlier,
  the value used for the calculation is shown next to it.

## 0.65.63
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Selling is judged by supply and sales:** how many pieces are on the AH at your price or cheaper (without bait
  offers and your own auctions) and how many sell per day give the waiting time and the expected number of listings;
  every listing without a sale costs the deposit on WoW Forever. If it would take more than 7 days, the item "hardly
  sells" – selling is then not the best way (vendor or disenchant). One number everywhere: tooltip, profit window,
  best recipes, "Today" and the API. With Shift the tooltip shows the reason, e.g. "150 on the AH · ~5/day · ~30 days ·
  hardly sells". The sales estimate (disappeared = half sold) is an assumption and is checked in the diagnostic log.
- **Fix: "My auctions" showed wrong prices for active commodity auctions** (e.g. 0c or 2c per piece): the game reports
  the price per piece for active commodity auctions. Price, total, the "value" in the header and undercut detection
  are now correct.
- **Tooltip with Shift:** what you own has its own heading ("Owned:"), with the value in your bags and the stock of
  your other characters.

## 0.65.62
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Item tooltip shows the value of everything in your bags:** for stackable items with at least 2 in your bags, a
  second line under "Sell:" shows the total of all stacks (e.g. "386 in your bags: 2g 0s 72c"), calculated like "Sell:"
  for the whole quantity (or the vendor value if the vendor pays more). The bank is not counted.
- **Posting gear (single items) – diagnosis:** on WoW Forever posting gear through AHSentinel fails with "Internal
  auction error" while Blizzard's window works. AHSentinel now records in the diagnostic log what Blizzard's window
  sends to the server and what AHSentinel sends (types and numbers only, no names), so the call can be built the same way.
- **Real error message when posting fails:** the game's own message is shown (e.g. "Internal auction error") instead of
  "not enough gold or item not available"; failed attempts are written to the diagnostic log.
- **Sell tab:** an empty quantity field counts as 1 (it showed a grey 1 but refused to post).

## 0.65.61
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix: "Today" could miss suggestions and freeze for a moment after login** (diagnostic log: 413 ms in one frame).
  Background calculations could not pause inside a protected call (Lua 5.1), so "below vendor price" and flip
  suggestions were silently dropped and the rest ran in one go. They now pause correctly and nothing is lost.
- **Fix: Ledger → "Values right?" (forecast vs. sale) was wrong on WoW Forever:** the real price per piece was taken
  from the quantity field of the invoice ("real 1", +7800 %). Now total / quantity; existing sales are recalculated once.
- **Profit window, "Best recipes":** new prices from the sniper or sync alone rebuild the list at most every 30 seconds
  (before: every 2 seconds while sniping). Opening, switching professions, bags and ledger still update at once.

## 0.65.60
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Main window opens beside the auction house** instead of over it, as long as you have not moved it yourself
  (and there is room on the screen).
- **Faster item tooltips:** the AHSentinel lines are cached per item for a few seconds (price data, Shift, settings,
  watchlist and bags are part of the key); the Shift part is only calculated while Shift is held.
- **Test routine can be cancelled:** `/ahs testroutine stop` (or `abbrechen`) and the "Cancel" button in the result
  window stop the run; all data is restored and the report says "cancelled by user".
- Test routine: no real data is changed any more (owned auctions, seller entry, ledger, sniper day counter,
  disenchant log – each test now works on its own copy); sniper and watcher pause during the server searches and are
  restored to your own setting afterwards; a timeout now says why (queries per minute, search, sniper, watcher);
  sniper test sets the max below the cheapest offer; the overlap check only reports windows AHSentinel placed itself
  (windows you moved and invisible frames of other addons are hints).

## 0.65.59
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix: Ledger → Return (gold per hour) stopped with a Lua error** ("compare nil with number"): the start of a day is
  now calculated without time(table), which returns nothing in the client for "all time". Same fix for the ledger
  periods, the gold chart, the sniper day counter and the raid hint.
- **Faster:** the market list and "Today" no longer freeze for a moment with 5000+ items – they are kept in a cache and
  recalculated in the background in small portions after a scan or data change (the window updates itself).
- **Profit window and best recipes:** "Best recipes" rebuilds again after crafting (bag contents count as a change);
  the profit window never overlaps the profession window, not even its invisible border.
- **Tooltips of the AHSentinel windows** appear next to the window instead of over its buttons.
- Sale message: the game's text template is written to the diagnostic log once (no names).
- Test routine: no real data is changed any more during a run (activity, remembered recipes, auction size); sniper
  test only counts its own target and shows price, max and unit; new tests (offer 2c at max 1c -> no hit; start of day
  without time(table)); outdated tests adjusted (sale message with "%1$s", sync reception, tooltip check per language,
  own test window ignored in the overlap check, API events).

## 0.65.58
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Price sync reaches players outside your guild (GoldSentinelSync 2, whisper network):** AHSentinel now uses
  version 2 of the shared GoldSentinel sync file. Besides guild and group, it can reach other players with GoldSentinel
  addons by whispering; they pass it on. Known players are remembered locally (AHSentinelDB.gsSync, names and times only).
  - **What goes into the network:** only prices after your own scan, bundled – the most traded items first, at most
    20 messages and at most once every 30 minutes (the network sends at most 40 whispers per minute).
  - **Guild/group only:** the full price list, answers to price requests, item names and disenchant results.
  - "Only guild" in the options keeps everything in the guild (nothing goes into the network).
- **GoldSentinelTest 2:** share error reports with the developer (only with your consent, /gstest).
- Diagnostic log: new "NETZ" line (without player names).

## 0.65.57
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **One minimum profit for everything:** the automatic minimum price when selling and AHSentinel.API.MinProfitPct now
  use your setting "minimum return" (same as "Worth up to" in the tooltip, default 20 %).
- For addon authors: API.Price reports "scan" only when the value really comes from the last scan ("market" when an
  outlier was replaced by the median). API.md matches the clarified contract (MaterialCost = crafting cost of the product,
  "vendor" is not an AH price).
- Texts: cancelling an auction loses the deposit (also in WoW Forever); the "per auction" tooltip in the profit window
  shows the measured minimum deposit instead of a fixed 1s.
- Test routine: new tests for the whole tooltip (with/without Shift, not disenchantable), "real from 12 disenchants",
  price source in the materials block, "Purchase sent" via the real confirm path, no flip suggestion for items that rarely
  sell, and at most 3 rebuilds of "Best recipes" while crafting.

## 0.65.56
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Test routine: sync tests use guild messages only (no channel messages anywhere in the addon).

## 0.65.55
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Price sync works again (WoW Forever):** addon messages in custom chat channels never arrive in Forever (the server
  refuses them). AHSentinel no longer uses its own channel "AHAPSync" – it leaves it once (frees a channel slot) and
  shares prices, item names and disenchant results only via **guild and group/raid**, in all game versions. It uses the
  shared GoldSentinel file GoldSentinelSync.lua (same as the other GoldSentinel addons); messages from older
  AHSentinel versions are still understood.
- Honest status: "Sync via guild: N players" or "nobody with AHSentinel online".
- New: **/ahs sync test** – pings guild and group and shows "N replies (guild a, group b)".
- Diagnostic log: sync path, sent/received/dropped and refused channel messages.

## 0.65.54
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper at full speed:** while sniper mode is ON with open targets, the watcher pauses (no more taking turns).
  The watcher runs when the sniper is off or has no targets; watcher bargains can still be bought as before.
- **Targets by yield:** targets with hits in the last 10 minutes are searched more often; targets without hits at most
  every third round. No target drops out.
- **Measured:** the sniper shows "Today: N hits · N bought · N missed · avg reaction X s"; the target tooltip shows hits
  and buy rate. With 10+ hits and under 20 % bought: "Others are faster here – pick another target?" (yellow "!").
  The diagnostic log gets one SNIPER line per minute with the times per step (no names).

## 0.65.53
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Faster sniper, still by the rules:** every purchase still needs a real key press or mouse-wheel notch – the sniper
  never reserves or buys from a timer (the old "instant buy" that reserved in advance without a key press is gone).
  - Just keep scrolling: every notch does the next step. Notches while the price is being checked are ignored silently.
  - Confirming is blocked for only 0.05 s (reserving still 0.3 s).
  - Searches are spread evenly (at most 90 per minute) instead of bursting and then stalling.
  - Commodity hits count as current for 3 s only; older ones are searched again instead of reserved.
  - Only pieces at or below your max are reserved; if the server offers fewer pieces, exactly those are bought.
  - Another AH error (e.g. a search) no longer cancels a purchase that is on its way.
- AH cut rounded down as measured (6279 → 313).

## 0.65.52
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Ledger fix (WoW Forever): sales no longer booked twice.** After you took the gold, the same sale invoice was
  read again as a new sale (quantity counted twice, income −5 %). The invoice key no longer contains the mail gold,
  and an invoice without gold is never booked again if it was already booked. Total = field "bid" of the invoice
  (cross-checked with gold + AH cut − deposit while the gold is still in the mail). Existing duplicates are removed
  once at login ("Ledger: removed N duplicate sales") and kept as a backup.
- Diagnostic log: the item count of the price data now matches the status line (was 0 after logout).

## 0.65.51
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profit window and ProfessionSentinel:** while the ProfessionSentinel panel is open, the AHSentinel profit window
  hides (ProfessionSentinel shows the same numbers via AHSentinel.API) and comes back when the panel closes.
- **Sniper "Buy now" hint:** shown only once, for at most 2 seconds, above the action bars instead of twice in the
  middle of the screen over open windows.

## 0.65.50
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **For addon authors – public interface `AHSentinel.API` (version 1):** global `AHSentinel.API`, alias
  `AHAnalyzerPro.API`. Functions: `Price`, `NetSale`, `Deposit`, `CutPct`, `MaterialCost`, `DisenchantValue`, `BestWay`,
  `SellSpeed`, `MinProfitPct`, `GoldPerHour`, `LastScan`, `Subscribe` (calls `fn("scan"/"ledger"/"settings")`, at most
  once per 2 s). Every function is safe (never a Lua error, `nil` if unknown), amounts in copper. Details in `API.md`.
  The old functions (RealPrice, RealValue, AuctionFee, AHFee, ForeverAuctionFee, GetMarketValue, GetCurrent) stay.
- Automatic minimum price when selling: minimum profit now 20 % (same default as the interface).

## 0.65.49
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Ledger → Return:** new view with invested, earned, profit and return per business – flipping (buy and sell the
  same item), crafting (crafted items against material cost), disenchanting (the existing report) and raw goods
  (sold without buying). A sale counts to the business the item came from and to its day, not to when the mail arrives.
- **Gold per hour** per business and in total, plus "Your hourly wage today". Only active time counts (stored locally):
  at the AH and mailbox the time between your own actions, at most 2 min after the last one; crafting and
  disenchanting from the first to the last of a series. Breaks over 2 min, AFK and automatic scans/sniper/watcher runs
  do not count. Under 15 min measured: "too little data". Losses show red with a minus.
- **Raid start hint:** from Nov 25 at most once a day when opening the AH: "Raid start Dec 9: buy/craft consumables
  and their herbs cheaply now." Off after Dec 9.

## 0.65.48
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Automatic minimum price when selling:** the higher of the vendor price after the AH cut and your own cost per
  piece (purchases of the last 30 days, otherwise crafting cost) + 5 %. A minimum you set by hand still wins. If the
  competition is below it, the suggestion is the minimum and a yellow hint says "Market is below your minimum price –
  post at the minimum or wait" (plus "price falling" when the 24 h trend is below −10 %). You decide – the price field
  stays free.
- **Expired 3× in a row:** the sell tab shows a yellow hint with a cheaper suggestion, the vendor price and the
  deposits lost so far. Nothing happens automatically.

## 0.65.47
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Cancel only when it pays:** an undercut auction is only suggested for cancelling when reposting earns more than
  the lost deposit plus the new deposit's risk. A 1c undercut is now shown as grey "undercut – leave it" and
  "Cancel next undercut" skips it (buyers take the cheapest pieces first anyway). The row tooltip shows the math.
- **At most 90 searches per minute (WoW Forever):** all searches (sniper, watcher, scan, buy, price check) share one
  60-second window below the server limit of 100; the sniper has priority.
- **Neutral auction house (Booty Bay, Gadgetzan, Everlook): 15 % instead of 5 %** on sale – everywhere the cut is
  used. A formula deposit there is marked "(uncertain)" until measured.
- **Sniper:** if your max per piece is above the net sale value (last scan minus cut and deposit risk), a yellow hint
  shows the expected loss per piece. Nothing is blocked.

## 0.65.46
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Minimum deposit is measured, not fixed (WoW Forever):** Blizzard announced lowering the minimum deposit per
  auction from 1s to 1c. AHSentinel no longer hard-codes 1s: the deposit always comes from Blizzard first, the formula
  is only a fallback, and its minimum is learned when you post an auction whose formula deposit is under 1s
  (diagnostic log "MINDESTEINZAHLUNG gemessen=…"). Once 1c is measured, the duration preselection "24 h costs the
  same" drops out on its own.
- Profit window: the AH fee line no longer adds a 1s minimum (only 5 % on sale – the deposit comes back).

## 0.65.45
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Ledger fix (WoW Forever):** in a Forever sale invoice the field read as "price" is the **quantity** – 0.65.42 to
  0.65.44 swapped quantity and unit price (e.g. 91 pieces at 1s 84c instead of 184 pieces at 91c). Income was right,
  but average sale price, sell rate and speed were wrong. Fixed when reading invoices, and existing sales are
  corrected once at login ("Ledger: fixed N sales (quantity and unit price)"). Nothing is deleted.
- **Values come from your last scan:** the value of an item is the cheapest offer of your last scan (or a newer
  search) – no 1c off, no cap at the median. Only two safeguards: an obvious outlier (e.g. 1 piece for 1c) is
  replaced by the next real offer, and items missing from the last scan use the market median. Your own average sale
  price is statistics only (Shift in the tooltip, yellow if more than 30 % below the market).
- Tooltip materials show the source ("scan" / "market").

## 0.65.44
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Tooltip, clearer ("variant A"):** without Shift exactly three blocks –
  1. **Price:** "AHSentinel – Price 10s" (own items: market value), market value if different, "Sells: quickly (~3 h)".
  2. **Verdict:** "Disenchanting pays off / does not pay" with profit, "Worth up to", then both ways with amount (better
     one first). Own items: only the two ways. Not disenchantable: only "Sell:".
  3. **Materials:** "Materials (real, from N disenchants)" or "(table)", one line each with chance × quantity and price
     after fees – always, also when Disenchantry is installed (AHSentinel replaces it).
  Everything else (real value with calculation, median, trend, sales per day, vendor price, your sell chance, alts)
  with **Shift**. Setting "short" hides the materials, "everything" shows all without Shift.
- **Sniper:** "Purchase sent" when you confirm; "Bought" only when the server confirms (no more "Bought" followed by
  "failed – counter corrected"). "Price is being checked" only once per reservation. When the price is confirmed:
  a short sound (option "sound on hits"), the Buy button blinks and "Buy now: mouse wheel" appears (never in combat).
- **Bulk buy for disenchanting:** counted only when the purchase succeeds.
- **Profit window:** the "AH fee" line shows only the 5 %; expected re-postings or "vendor pays more" in a grey line.
- Faster: the ledger is indexed per item instead of read completely for every price.

## 0.65.43
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sell tab – duration preselected (WoW Forever):** 24 h when it costs no more than 2 h (minimum deposit, e.g. dust,
  cloth, herbs); otherwise by how fast the item usually sells for you (under 2 h -> 2 h, under 8 h -> 8 h); without data
  24 h if it costs hardly more, else 8 h. The reason is shown below the buttons; you can still change it.
- **How fast it sells:** measured from your ledger (posted -> sold, expired). Tooltip line "Sells: quickly (~3 h)",
  "slowly (~2 days)" or "hardly (often expires)"; without your own data the market sales per day as before.
- Items that hardly sell for you are no longer suggested for flipping or crafting ("Do today"); the Sell tab shows
  "Often expires – post cheaper or keep it." (no automatic price change).

## 0.65.42
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**Auction fees like in classic WoW (measured in WoW Forever) – this replaces the "max(5 %, 1s)" rule:**
- **Posting:** deposit = vendor price × quantity × 5 % per 2 hours (2/8/24 h = 5/20/60 %), at least 1s per auction
  in Forever. Blizzard's own value is used when the AH is open. **Selling:** 5 % of the price, the deposit comes back.
  Expired auctions lose the deposit – values and profits include the expected loss (from your sell rate).
- **Sell tab:** the deposit line is back, AH fee 5 %. **Profit window:** "AH fee 5 % + deposit (back on sale)".
- **Ledger:** Forever invoices are read correctly (the "price" is the unit price, the quantity is computed from the
  total). Sales booked by earlier versions are recalculated once at login ("Ledger: recalculated N sales"),
  nothing is deleted. The raw invoice values go to the diagnostic log once per session (RECHNUNG-ROH, no names).
- **Tooltip:** both ways with amount, the better one first: "Disenchant: 9s 35c" / "Sell: 8s 99c" (own items in your
  bags: only these two lines; in the AH below the verdict).
- **Best recipes no longer stutter:** rebuilt only while the profit window is visible, at most every 10 s while you
  craft, and only when prices or the recipe list really changed; reading all recipes is spread over frames.
- **For addon authors:** `AHAnalyzerPro:AuctionFee(total[, itemID, qty])` / `.AHFee` now return the expected selling
  costs of one auction (5 % + expected deposit loss). New: `AHAnalyzerPro:ListingDeposit(itemID, qty, hours, auctions)`.

## 0.65.41
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**See at a glance whether it pays off – no calculating:**
- **Tooltip – disenchant verdict:** instead of "Disenchant value" and "Profit when buying" there are two lines:
  green "Disenchanting pays off +2s 85c", red "Disenchanting does not pay −65c" or grey "Disenchant: uncertain"
  (a material price is missing or unreliable), and below "Worth up to 7s 79c" (= disenchant value / (1 + minimum
  return, default 20 %), rounded down). Materials, chances and the calculation only with **Shift**. For your own items
  in the bags: "Disenchanting is worth more than selling" or "Selling is worth more than disenchanting".
- **Profit window – best way:**
  - Materials over the cheapest way per reagent: AH, vendor, or crafting it yourself from a recipe you know
    (e.g. Bolt of Linen Cloth from 2 Linen Cloth), up to 2 levels. A small grey line says where it comes from.
    "Materials as shopping list" buys the reagents actually chosen (Linen Cloth instead of the bolt).
  - Value = the better of selling (AH fee max(5 %, 1s) per auction) and disenchanting (only if disenchantable).
  - "Profit" shows the best way, below "best way: disenchant/sell" and the other way with its amount.
    "Best recipes" sorts by it, with "dis."/"sell" behind the amount.

## 0.65.40
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Ledger repair (WoW Forever, once):** sales booked before 0.65.35 still carried the AH share and deposit from the
  invoice, so the fee was deducted twice (e.g. "Today" income below zero). They are corrected once at login
  (share and refund set to 0, the old values are kept as a backup, nothing is deleted). Chat: "Ledger: fixed N old
  sales". Era/TBC unchanged.

## 0.65.39
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Categories with three levels** like in the Blizzard AH (e.g. Weapons -> One-Handed -> Axes) in Buy; the third
  level appears under the chosen second one.
- **Mail rules:** the category is now chosen from a menu (expand a main category, then pick) instead of clicking
  through more than 50 entries.
- **Selling:** a price more than 100x the market value asks for a second click ("typo? a number without unit = gold").
- **Do today -> below vendor price:** from a scan or search only the cheapest price is known, so the profit is shown
  for 1 piece (the exact quantity comes with the item's listings). No more inflated profits.
- **Sharing disenchant results:** all parts of one sending count as one message (large statistics are no longer cut
  off); a second sending from the same player within a minute is ignored.
- **Playtest:** S7 counts only spells that are a recipe of the open profession; all playtest texts are translated.
- Test routine: no longer replaces any Blizzard function or frame during the tests (TakeInboxMoney, MailFrame,
  IsInGuild, ProfessionsFrame) – new check T242. Command help lists part k and /ahs playtest.
- Options tooltip: "short" now names the line "Disenchant value".
- For other addons: `AHAnalyzerPro:AuctionFee(total)` (also `.AHFee`) = AH fee of one auction in WoW Forever.
- Note: since 0.65.30 prices are kept per realm and faction; going back to 0.65.29 or older shows no prices until
  the next scan.

## 0.65.38
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**Values you can trust – the remaining points:**
- **Not selling costs money (WoW Forever):** every posting pays the AH fee, even if nothing sells. The real value
  now subtracts the expected re-postings: from your own sell rate of the last 30 days (from 3 postings), otherwise
  from the market (under 1 sale per day: up to one extra posting). Shift in the tooltip shows it
  ("~2.0x posting (your sell rate)"). Era/TBC unchanged.
- **Crafting:** materials you already own count at what you would get for them (real value after fees); missing
  ones at the buy-now price; vendor goods at the vendor price. The product's value uses the same real-value function.
- **Prediction vs. reality:** when posting, AHSentinel remembers its predicted price; when the sale arrives by mail it
  compares. Ledger -> Statistics shows "Deviation: values on average N % too high/low", per item group and in total;
  the diagnostic log gets a WERT entry (no names).
- **Incomplete scans** (stopped early or timed out) are marked: missing items are never treated as gone and the scan
  never counts as complete for sales estimates.
- **Shared prices** count only if they fit your own picture (10–300 % of your median) or a second player reports a
  similar price; until then they are stored as unconfirmed and do not count.

## 0.65.37
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Own small disenchant window** (`/ahs disenchant`, or Buy -> "Worth disenchanting" -> "Disenchant window"):
  icon and name of the next item, "N left to disenchant", buttons **Disenchant**, **Skip**, **Statistics**.
  Movable, position remembered. Opens by itself once after a bulk buy when you close the AH.
  - Order: items bought with the bulk buy first, then the other disenchantable items in your bags.
  - **Disenchant** is a secure button: one click = one item. Locked in combat, no taint.
  - Protection: never items in an equipment set, quest items or items on your block list (right-click the icon:
    "never disenchant"); only green to purple. Blue/purple items and items that clearly sell for more
    (more than 1.5x the disenchant value) need a click on **Release** first.
  - Statistics: disenchants today and in total, materials received, their value.
  - If Disenchantry is loaded, the window does not open by itself (one-time hint).
- **Ledger -> Disenchant:** per day and in total: spent on bulk-bought items, value of the materials received
  (real value after AH fee; material you already sold counts at the real proceeds), profit, number of items and
  return %. A bought item is matched to its disenchant (same item, within 14 days). Own items you disenchant are
  shown separately (material value only), items bought but not yet disenchanted as "still open".
- Tests and comments use invented character names only.

## 0.65.36
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchant watcher:** while the AH is open and the bargain watcher is on, every other watcher round searches
  weapons and armor and checks them with the same limits as "Worth disenchanting" (minimum return, at least 10c
  profit). New finds are reported once: "N items with over X % return available" in chat and on screen – at most
  once a minute, never in combat. It never buys; you buy in Buy -> "Worth disenchanting" as before.
  Switch it off with the new button "Watcher alert: ON/OFF" there.

## 0.65.35
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **AH fee in the profit window – one visible assumption:** the fee depends on how many pieces you post per auction
  (at least 1s per auction). The window now says it: "at N pieces per auction (learned / chosen / cautious)".
  Learned from your own postings (median of the last 10); without data 1 piece. Click it to switch 1 / 5 / 20 (stack)
  / automatic, remembered per item. "Best recipes", "Do today" and other addons use the same assumption. The window
  no longer switches between two calculations when item data loads late. (Example: 1 Bolt of Woolen Cloth at 3s 97c,
  materials 3s 42c: fee 1s, loss 45c; at 20 per auction: 20c, profit 35c.)
- **Selling: quantity = everything in your bags** (no longer the last quantity). You change the number yourself.
- **Ledger (WoW Forever):** a sale is booked with the gold the mail really brings – the fee was already booked when
  posting, so no second fee and no refund are deducted. The invoice values go to the diagnostic log (RECHNUNG).
  Cancelling an auction now books the measured refund. Era/TBC unchanged.
- Playtest: new check S10 – AHSentinel's AH fee equals Blizzard's "Deposit" for the same quantity.

## 0.65.34
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Bulk buying for disenchanting** (Buy tab → Buy): the button "Worth disenchanting" below the categories shows from
  your search only items (armor/weapons) whose disenchant value exceeds the price by the minimum return, with at
  least 10c profit per item – sorted by profit, with columns disenchant value, profit and return %.
  - Every mouse wheel notch over the list, or "Buy next", buys the next item from the top (the first notch loads its
    offers). Before each purchase: offer still there and not more expensive – otherwise skipped.
  - Limits: "at most X gold" (default 5g) and "return from X %" (default 20 %). Stops at the limit, with full bags
    or in combat. Below 10 real disenchants of the group the value counts 10 % less.
  - Status line: "Bought N · paid · expected +profit". Only on your click/notch, never automatic; logged as KAUF
    (no names). No skill filter – in WoW Forever everything can be disenchanted from Enchanting 1.

## 0.65.33
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **AH fee in the profit window corrected:** the fee per piece assumed you always post a full stack (e.g. 20 Bolts of
  Woolen Cloth) and split the 1s minimum fee by 20 – so 1 bolt at 3s 98c showed 20c instead of the real 1s. Now the fee
  follows how many pieces you last posted of this item at once; without experience 1 piece (full 1s minimum fee).

## 0.65.32
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchant table from Disenchantry:** the table now follows Disenchantry 1.1.2 (MIT license, Copyright (c) 2026
  x_Raven_x; license text in LICENSE-Disenchantry.txt), based on warcraft.wiki.gg: item level 5–15 without shards
  (80/20), 21–25 armor 75/15/10, 51–65 weapons 75/22/3, **WoW Forever: green weapons item level 21–30 give Greater
  Magic Essence**, blue items from item level 1 and up to 80, epics up to 88. Groups are by item level (as in the
  table), not by required level.
- The material block now shows the quantity range from the table ("1–2×"), from real disenchants the average.
- **Disenchantry loaded:** AHSentinel shows no second material block.

## 0.65.31
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **One price for everything:** AHSentinel now values every item with ONE function – tooltip, profit window
  (product and materials), bargains, flips, "Do today", disenchant (block and value), inventory value and the vendor
  comparison all show the same value for the same item. Order of sources: your own sales of the last 14 days, then
  just below the cheapest current offer (at most the median), then the 14-day median. Offers below 10 % or above 300 %
  of the median don't count. For bargains and flips the cheap offer itself is not used as resale value.
- **Real value in the tooltip:** new line "Real value (after fees)" with its source (own sales / AH now / market /
  vendor) and "price old" after 6 hours; hold Shift to see each part (own sales, cheapest offer, median, fee).
- **Vendor price as floor:** if a vendor pays more than the auction house after fees, the vendor price counts.
- Other addons (ProfessionSentinel) can use the same values: `AHAnalyzerPro:RealPrice(itemID)` and
  `AHAnalyzerPro:RealValue(itemID, qty)`; the old `GetSalePrice` now returns the same value.

## 0.65.30
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Prices per realm and faction:** AHSentinel now keeps a separate price list for every realm and auction house –
  Horde, Alliance and the neutral auction houses (Booty Bay, Gadgetzan, Everlook). Your own scans and synced prices only
  go into the list of the auction house you are at; tooltips and calculations use your faction's list (at a neutral
  auction house the neutral one).
- **Sync only from the same auction house:** price messages now carry a short code of realm and faction; prices from
  another faction or realm, and old messages without the code, are dropped. (Please update – older versions no longer
  exchange prices with 0.65.30.)
- Your existing prices are kept for the current character's realm and faction. If you have characters on several
  realms or factions, a note tells you that the old prices may be mixed – the next scan replaces them.

## 0.65.29
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchant value instead of "profit":** the tooltip line is now called "Disenchant value ~X (T)" – it depends only
  on the group (quality, item level, armor/weapon) and is the same for all items of that group. New below it:
  "Profit when buying: value − purchase price" (green/red) with the price of the row you point at in the addon
  (buy list, sniper, bargains), at a vendor his price, otherwise the cheapest current offer. In the buy list a mark
  "[disenchanting pays]" appears only if value − price is positive.
- **Material block matches the value:** block and value now use the same price per material – your own sales of the
  last 14 days, otherwise just below the cheapest current offer (at most the median), otherwise the median. The source
  is shown ("AH now" / "market" / "own sales"). Offers below 10 % or above 300 % of the median don't count ("offer
  doubtful") – e.g. 22c for a Greater Mystic Essence.
- **Sharing disenchants:** after 10 new ones, or at the latest 2 minutes after the last one, and on logout.

## 0.65.28
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Opens with the auction house:** the AHSentinel window opens when you open the auction house and closes again
  with it. If it was already open before, it stays open. Option "Open and close with the auction house" (on by
  default). Never pops up in combat.
- **Window always on screen:** the main window stays fully on screen – at most 90 % of the screen, position kept
  inside the edges, also after changing UI scale or resolution.
- **Sniper in WoW Forever:** commodities are bought with two notches – 1st notch reserves the price, 2nd notch buys
  (WoW Forever allows the reservation only from a key press). The status line now says so ("1. … reserve price ·
  2. … buy", then "reserved – again to buy (10 s)"), also while the sniper keeps searching; help and tooltips
  updated. The total line under the list no longer disappears while searching. Era/TBC unchanged.
- Playtest: new check S9 (window opens and closes with the auction house).
- Developer test routine: checks that can't run in this client (no BugSack, missing item data, no real layout) are
  counted as skipped, never as OK or ERROR.

## 0.65.27
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchant table corrected** (source: warcraft.wiki.gg, Classic disenchanting tables): green items up to item
  level 15 give no shard – armor 80 % dust / 20 % essence, weapons 20 % / 80 %. Item level 21–25 now 75/15/10
  (weapons 15/75/10), item level 51–65 weapons 22/75/3; the other levels stay 75/20/5.
- Materials that cannot come from a group (e.g. a shard from item level 15) are no longer counted – neither your own
  (wrongly detected) results nor shared ones.

## 0.65.26
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchant in the tooltip, shorter:**
  - One line "Disenchant: expected gain ~X" (value after fees) with a small comparison ("better than selling" /
    "selling pays more") and the source: "(Ø 12)" = from 12 real disenchants (from 10 on), "(T)" = table.
  - Below it a block "Disenchant – materials (AHSentinel)": icon, name, drop chance and value per piece (AH price from
    the last scan, otherwise market value).
  - Hold Shift to see the whole calculation (actual and estimated, per material, after fees).
  - Option "Disenchant details in tooltip": short / with materials (default) / everything.
- **Disenchant results shared with all AHSentinel users:** every disenchant on every character is counted
  automatically (your alts count as your own) and shared over the public sync channel ("guild only" stays an option).
  Protection: at most 6 messages per sender and minute, materials must match the group, 1–5 pieces per disenchant,
  no jumps, duplicate messages count once. Senders are stored only as a short code, never by name.

## 0.65.25
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Collecting mail:** "Mail collected" now shows the gold you really took (e.g. 1g 56s 26c) instead of 0. The game
  often credits the gold only after the mailbox update; the addon now counts the amount of each mail it collects.
- "1 new invoices" → "1 new invoice".

## 0.65.24
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Playtest S5** now only checks what it should: the profit window against the profession window and
  ProfessionSentinel. Before, it also counted the main window over the auction house, LevelPilot and invisible
  anchors of other addons and reported a false ERROR.

## 0.65.23
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Playtest:** `/ahs playtest on` (German: `/ahs spieltest an`) – AHSentinel checks the test checklist in the game
  itself as soon as you create the situation, and only reports what is wrong (one chat line per check). It never
  opens windows, buys, posts or crafts by itself, and does nothing in combat. Active until /reload or 2 hours.
  - S1 fee in the Sell tab · S2 real fee after posting · S3 profit window · S4 disenchant in the tooltip ·
    S5 profit window covers nothing · S6 vendor button · S7 rebuild while crafting 5 items · S8 no blocked actions.
  - `/ahs playtest report` lists OK / ERROR / open and what you still need to do for the open ones. Results also go to
    the diagnostic log and to the test report for the addon check (area S). No names.
- Removed a leftover file (TestRoutine.lua.orig) from the download.

## 0.65.22
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchanting in the tooltip – actual and estimated, clearly separated:**
  - "Disenchant actual (avg of N)": only from real disenchants of this group (yours + shared): sum of the materials
    you really got × current AH price from the last scan ÷ N. Below 10 disenchants it says "(little data)", without
    any disenchant the line is left out.
  - "Disenchant estimated (table)": the previous value (table blended with results).
  - One line per material: chance (or actual frequency "x/N") × average amount · AH price from the last scan (with
    age) · market value = share; below it "after fees" (WoW Forever: AH fee 5 %, at least 1s per auction).
  - The tooltip says which value the disenchant bargains use: the actual average from 10 disenchants on, otherwise the
    estimate.
  - New option "Disenchant: per material" (on by default).

## 0.65.21
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **WoW Forever fee rule:** Forever has only ONE fee – the AH fee = 5 % of the auction's price, at least 1 silver,
  per auction (per stack), paid when posting. There is no separate deposit any more. Examples: 3s 90c → 1s,
  2s → 1s, 1g → 5s, a stack of 20 at 1c each → 1s once.
- The row "Deposit (not refunded)" is gone from the profit window and the Sell tab; there is only "AH fee (5 %,
  min. 1s)". The same rule is used everywhere: profit window, Sell tab, "Do today", bargains, flips, disenchant
  values, vendor comparison, profit calculator.
- When posting, the fee really taken from your gold is written to the diagnostic log (entry EINSTELLEN: price,
  quantity, fee) to confirm the rule in the game. The deposit measuring of 0.65.17–0.65.20 is removed. The warning when the
  fee is more than 10 % of the price stays.
- Era, TBC and Retail are unchanged (5 % on sale, deposit refunded on sale).

## 0.65.20
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profession window:** the "Best recipes" list is rebuilt at most every 2 seconds while you craft (it was rebuilt
  up to 190 times in a session); opening and switching professions stay immediate.
- **Sniper (WoW Forever):** the sniper no longer reserves commodities on its own without a key press. WoW Forever
  blocked that call ("action blocked" once per session). Commodities are bought with 2 notches: the 1st reserves,
  the 2nd buys. If WoW blocks it on another client, the addon remembers that for this client, also after /reload.
- **Mail rules to alts:** a rule with a sub-category now also works after /reload at the mailbox without visiting the
  auction house first. Rules from 0.65.11–0.65.17 are found again.
- **Buy:** the category list keeps its scroll position while you type or search, and the selected category stays
  visible. Until the auction house is opened once, Classic Era, TBC and WoW Forever show the classic order (with
  Projectile, Quiver, Reagent).
- **Sale message:** also works when the game text uses a numbered placeholder ("%1$s").
- **Profession window:** without a tab bar the profit window docks directly next to the window (only over its
  invisible border on the old window), never over visible parts. Clicking a recipe no longer turns on "show unlearned".
  In Classic Era and TBC there is no empty line where the deposit line is (WoW Forever only).
- **Deposit:** the warning says when the deposit is refunded on sale (Classic Era, TBC …). Measurements are not taken
  in test mode, an estimate of the old auction house is never stored as a measurement, the money is checked again
  shortly after posting, and the last 300 measurements go into the diagnostic log (numbers only, no names).
  "Do today – craft" deducts the deposit for the whole crafted quantity.
- Price field tooltip shows g/s/c in every language.
- Developer test routine: new area K (interface in the real client: tooltips, overlapping windows, screen, labels,
  plausible values, error loops, T191–T197) and tests T198–T202; saved recipes, window positions and watcher data stay
  unchanged during the routine.

## 0.65.18
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Vendor button no longer covers anything:** the "Sell: … items" button sat below the merchant window and covered the
  "Buyback" tab. It now sits above the merchant window, top right – never next to the "Merchant" / "Buyback" tabs.
- **Only when there is something to sell:** instead of "Sell: 0 items (0)" the button is hidden.
- **Off by default with LevelPilot:** if LevelPilot is loaded and sells grey items itself (on by default there), the
  button stays off until you turn it on yourself in the options ("Button at vendors"). Your own setting always wins.
- Test routine (developer only): T186 checks in game that the button covers no tab of the merchant window (otherwise
  FAIL), T187 checks the default with and without LevelPilot.

## 0.65.17
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Deposit is measured:** every time you post, the addon notes item, vendor price, quantity, duration, your price
  (per piece and total), the deposit the game reports and the deposit really taken from your gold, plus the ratio
  deposit/price and deposit/vendor price – in the diagnostic log (`/ahs protokoll`, entry EINSTELLEN) and in the GSDIAG1
  export, without any names. If the game does not report a deposit, the last measured one for that item is used –
  never a guess.
- **Deposit warning:** if the deposit is more than 10 % of the price, posting asks for a second click. The threshold
  is adjustable in the options (off / 5 / 10 / 20 / 30 %).
- **"Do today": below vendor price:** offers whose price per piece is below the vendor sell price (from the last scan
  or your current search) are shown as "Below vendor price: buy and sell to a vendor" – profit = (vendor price −
  purchase price) × quantity, no AH cut. Only from 10 silver profit per offer (adjustable: all / 5s / 10s / 50s / 1g),
  the best 10, sorted by profit. Items without a vendor price never appear, offers that are gone are hidden. The
  button buys only on your click, then tells you to sell to a vendor.

## 0.65.16
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Protected values:** the recipe selection and the diagnostic log ignore protected game values instead of touching them.
- Developer test routine (developer only), following the rules that proved themselves for LevelPilot: honest counting
  (checks that cannot run in a client count as skipped, never as OK; the report states "not automated: N" and lists
  everything to check in the game), each bug found in the game is its own test (recipe click without a previous click,
  the 50-second delay), bait values for protected values, the test log goes to a sandbox, test IDs are unique.

## 0.65.15
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Diagnostic log:** `/ahs protokoll` (or `/ahs log`) opens a window with a copyable log – version, client, sessions,
  changed settings, open windows and where the profit window is docked, plus entries (newest first): CLICK (recipe,
  recipe ID, way, milliseconds, success), BUILD (best-recipes list, trigger, time), SLOW (any step over 16 ms),
  OVERLAP (another window covering the profit window) and ERROR (same error only counted). On logout it is also stored
  as "GSDIAG1" for the addon check. No player, character, guild or realm names.

## 0.65.14
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profession window (modern client):** clicking a recipe in "Best recipes" selects it right away through the
  recipe list of the profession window and scrolls it into view – in the same moment, without waiting for a timer.
  Only if that is not possible the game's OpenRecipe is used; the addon checks every frame and reports in the chat
  if the recipe is not shown within 0.5 seconds.

## 0.65.13
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **WoW Forever – profit next to the profession window:** the deposit (at least 1 silver per auction, never refunded)
  is now deducted and shown as its own line: profit = value × 0.95 − materials − deposit (e.g. Copper Chain Pants 18c
  instead of 1s 18c – the same as ProfessionSentinel). The best-recipes list is ranked with it.
- **WoW Forever – bid deals** also deduct the deposit for re-selling.
- Classic Era, TBC and other versions are unchanged (there the deposit comes back on sale).

## 0.65.12
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profession window – clicking a recipe in "Best recipes" now always opens it:**
  - the list no longer rebuilds on every game event: events are collected and the list is rebuilt at most every
    0.4 s, only when something changed, spread over several frames – a click is no longer lost during a rebuild;
  - each row remembers its recipe; the click looks up the recipe again in the profession window, and if a search text,
    filter or collapsed category hides it, these are reset and the recipe is opened anyway;
  - if it still cannot be opened, a short message appears in the chat.

## 0.65.11
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Buy → categories like the Blizzard auction house:** every main category now has its sub-categories
  (Weapons → One-Handed Axes …, Armor → Cloth/Leather …, Consumables → Potions …), with the names and order of the
  game. Sub-categories open under the selected main category. Until the auction house has been opened once, the
  addon uses the item classes of the game.
- **Price field:** always shows gold/silver/copper as g/s/c ("78c", "3s 90c") in every language – never "k", which
  read like "thousand". Typing "78", "78c", "1s 20c", "1g" and the old "78k" still works.
- For ProfessionSentinel: `AHAnalyzerPro.Crafting:GetDockFrame(true)` also returns the profit window while it is hidden.

## 0.65.10
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profession window (WoW Forever):** the AHSentinel profit window no longer covers the profession tabs on the right
  side of the profession window – it now docks to the right of the tab bar. Without such a tab bar it sits where it
  always did.

## 0.65.9
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profession window:** new interface `AHAnalyzerPro.Crafting:GetDockFrame()` – returns the visible AHSentinel profit
  window next to the profession window, otherwise nil. ProfessionSentinel uses it to dock to the right of it instead of
  lying on top of it. AHSentinel itself stays directly to the right of the Blizzard profession window.

## 0.65.8
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Damaged saved data is repaired on login:** single broken entries (price history, characters, sniper targets,
  ledger, lists, recipes) are removed instead of causing a Lua error in a tab or tooltip. Healthy data stays untouched.
- Developer test routine (only for the developer): two checks that always failed are fixed (watcher with the auction
  house closed, `/ahs scan` during the routine); options and chat commands now run one per step (no "script ran too long");
  many more checks (watcher candidates, sale message, ledger from the test mailbox, re-posting, vendor, professions,
  disenchanting, characters, sync, data migration and damaged data, speed, protected AH calls) and, with the auction
  house open, simulated commodity purchase, sniper pre-reservation, batch posting, undercut detection and scan slices.
  Checks that cannot run in a client are now reported as skipped with a reason instead of OK.

## 0.65.7
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Test routine (developer only):** many more checks – every option once on and off, every chat command, all extra
  windows, main window and designs, size and position, buying and ledger maths, sniper targets and keys, watcher
  settings, watchlist, bags without the old functions, chat helpers, Esc windows in combat, errors in background
  tasks, transition from the old AH Analyzer Pro.
- Bags, mail slots and price sync now look up the client functions through one place, so the test routine can
  simulate missing functions without touching Blizzard's (no taint). Nothing changes in normal play.
- Missing "GoldSentinelTest.lua" message is now translated.

## 0.65.6
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

Fixes from the addon check:
- **Scan start keeps failing (WoW Forever, Retail):** if the server rejects the scan start permanently, the chat is no
  longer flooded (before: about 240 lines in 2 minutes). The error is shown once, the addon retries at most 3 times
  (at least 2 seconds apart), then says once that the scan could not start. The watcher continues right away.
- **Watcher:** if the server drops requests during the short pause of a wanted scan, the watcher now pauses the full
  15 minutes as intended (before it resumed after 2 minutes). Deliberately no pause just because a scan is allowed:
  the watcher would otherwise rest forever for players who never scan.
- **Profession window (modern client):** the recipe chosen in Blizzard's window is now really recognised (the event
  name was wrong), so the ingredient button never uses an older recipe.
- **Mail to alts (WoW Forever):** a rule with your own first name only ("Testa" for "Testa Beispiel") no longer
  plans mail to yourself.
- **WoW Forever, protected values:** price sync, tooltip, mailbox errors, blocked actions and disenchant tracking
  ignore protected ("secret") values instead of risking a Lua error.
- Errors caught by the addon are now also counted for the addon check (GoldSentinelTest.lua); `/ahs debug` shows
  "Errors since login · Reports pending". The chat messages stay as before. Sale messages no longer swallow errors silently.
- Developer only: new test routine `/ahs testroutine` (areas a–j, `server`, `haendler`, `berufe`, `post`,
  `gildenbank`, `kampf`) with saved report. Your real data is saved before and restored afterwards; buying, posting,
  mail, vendor and price sync are only simulated. `/ahs test` and `/ahs test daten` are short forms.
- Missing translations for the classic auction house added.

## 0.65.5
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

Follow-up fixes from the addon check:
- **Full scan has priority (WoW Forever, Retail):** if you start the scan while the server is busy or a watcher search is
  still running, the scan no longer fails – the watcher pauses and the scan starts by itself as soon as the server is ready
  (at most 2 minutes). A rejected scan start works the same way. Classic Era and TBC are unchanged.
- **Profession window:** the old clients (Classic Era, TBC) read recipes at most every 5 seconds again, as in 0.65.3.
  In the modern client the chosen recipe is taken from the recipe list itself and forgotten when the window closes,
  so the ingredient button never uses an old recipe.

## 0.65.4
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

Fixes from the addon check:
- **Old "AH Analyzer Pro" (up to 0.61) still installed:** AHSentinel no longer loads next to it (both used the same
  global table – double events, double commands, possible Lua errors). Instead it asks once in chat to delete the old
  folder `AddOns\AHAnalyzerPro`. Your old data is saved for AHSentinel first. The old folder is no longer loaded before AHSentinel.
- **Watcher (Classic Era, TBC):** back to the behaviour of 0.64.2 – it no longer pauses for up to 15 minutes when the
  server reports "no full scan" (that can come from another addon).
- **Watcher (WoW Forever, Retail):** if the full scan is due and the server drops requests, the watcher pauses until the scan has run (at most 15 minutes).
- **Profession window (modern client):** a recipe list that is still empty right after opening no longer blocks reading for 5 seconds;
  the ingredient button remembers the last chosen recipe; recipe details are read only once per profession (less stutter).
- `/ahs debug` shows whether vendor costs in currency (e.g. Merchant's Favor) can be read in this client.

## 0.65.3
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **The old "AHAnalyzerPro" folder is no longer included.** AHSentinel is the only folder now.
  If you have started AHSentinel at least once, your old data is already in it and you can delete the folder "AHAnalyzerPro" from Interface\AddOns.

## 0.65.2
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **GoldSentinelGame version 2:** the shared game version detection now also wins against early versions
  that other GoldSentinel addons briefly shipped – no Lua errors when several addons are loaded together.
- Vendor prices: if the game has no item link function at the merchant, the item ID is read another way.

## 0.65.1
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Shared game version detection:** AHSentinel now uses **GoldSentinelGame**, the same detection all
  GoldSentinel addons get step by step. WoW Forever always counts as the modern client there, never as Classic.
- New: `/gsgame` shows in the chat which game version was detected; `/ahs debug` shows it too.
- Nothing else changes for you.

## 0.65.0
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**WoW Forever and Retail (modern client) – nothing stays silently empty any more:**
- **Profession window:** recipes are now read through the modern profession interface
  (`C_TradeSkillUI`) when the old one is missing – the profit panel next to the profession window and the
  crafting suggestions in "Today" work there too. Older game versions keep the old way.
- **Vendor prices:** read through `C_MerchantFrame` when the old function is missing. Items that cost
  a currency or tokens (e.g. Merchant's Favor) are remembered with their exact costs.
- **Raid supplies:** on WoW Forever the Classic raid template is used (`/ahs raid`).
- **Watcher and the 15-minute full scan:** if the server refuses the due full scan after a watcher
  round, the watcher pauses until the full scan has run.
- **Sniper:** if WoW blocks the pre-reserved goods purchase (no error, only a blocked-action event),
  "one notch buys" switches itself off and the sniper goes back to two notches.
- Translations for the WoW Forever deposit texts from 0.64.2 in all languages.

## 0.64.2
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **WoW Forever: listing fee counted correctly.** On WoW Forever every auction costs **at least
  1 silver** deposit, and it is **never refunded**, not even when the item sells. AHSentinel now
  detects Forever itself and always subtracts the fee instead of only as a risk for expired auctions:
  flips, sell suggestions in "Today", crafting profits, bargains, disenchant bargains (materials are
  sold in stacks, fee per piece), vendor-vs-AH comparison and the Sell tab (shows "not refunded").
- This mostly affects **cheap items**: an item worth 1s 50c in the AH and 71c at a vendor leaves only
  42c after 5 % and the 1s fee – "Today" then suggests **selling to a vendor**.
- Fee per piece = max(1 silver, deposit of a full stack) ÷ stack size. Other game versions are
  unchanged (the deposit is refunded on a sale).
- Profit calculator: on Forever the 1 silver deposit is included.

## 0.64.1
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **"Today" suggests crafting – even without ProfessionSentinel:** AHSentinel now remembers the
  recipes of each character when you open the profession window. "Today" then suggests the 2–3 most
  profitable recipes you **already know** (result sells well, at least 10 % profit after the AH cut).
  The button **Buy reagents** adds a buy row for every missing reagent from the auction house
  (10 % price margin, nothing bought without your click); reagents from vendors are named in the chat.
  When everything is there: "All there – craft".
- With ProfessionSentinel installed, its suggestions are used instead (no duplicates).
- Characters with a crafting profession but without ProfessionSentinel see a small tip at the bottom
  of "Today" – **Hide** removes it for good.

## 0.64.0
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**"Today" – buy and post right in the list:**
- Every row now has a **button with the next step**, no need to switch tabs:
  - Buy suggestions: **Check** looks up the item in the background; the row then shows the real
    current offer ("5x at 2g 40s each = 12g") and the button becomes **Buy 12g**. Several single
    auctions: **Buy (1/3)**, one click each (WoW needs one click per auction). Goods in the modern
    auction house: the price is reserved first, then **Confirm**.
  - **Never more expensive and never more than suggested**, and the capital protection still applies.
    If the offer is gone or more expensive, the row says "no longer worth it" and nothing is bought.
  - After buying: flips get **Post** (price suggestion with price protection), disenchant deals show
    how many are in your bags, vendor deals say "Sell to a vendor".
  - Items from your bags: **Check → Post**. Returned auctions: **Repost**, one click each.
- A click on the row itself still switches to the tab, as before.
- **For other addons:** `AHAnalyzerPro.Today:QuickBuy(itemID, qty, maxPrice, label)` and
  `:QuickSell(itemID, count)` add a row at the top of "Today" – nothing is bought without your click.
- **ProfessionSentinel:** its "craft today" suggestions appear in "Today"; the button walks you
  through buying the reagents, crafting and posting.
- Disenchant texts from 0.63.0 are now translated into all languages.

## 0.63.4
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Bargain watcher only with a reliable market value:** the watcher used to report "bargains" at 0–10 % of the market value – almost always because the market value itself was wrong (moon price, rare item, price crash). As the watcher buys with the mouse wheel, only a market value you can trust counts now.
- **Test mode log:** watcher purchases show as "Sniper buy (watcher)" with the price; goods bought from the buy tab and the sniper show the price too.

## 0.63.3
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Quality tiers (retail):** crafting reagents and crafted items come in several tiers – so far e.g. "Bismuth" showed three times with no difference. The tier icon now follows the name (buy, market, sell, sniper, ledger …).
- **Feedback after posting and cancelling:** instead of "Posting …" / "Cancelling …" staying forever, the window now shows "Posted: …" / "Cancelled: …".
- **Daily summary:** showed "+ all your gold since yesterday" when the game briefly reported 0 gold at login. Such a 0 value no longer counts.
- **Test mode log:** buying goods (retail) now shows the price, a sniper buy is logged as "Sniper buy" instead of "Buyout".

## 0.63.2
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Self-test on retail:** stopped with "script ran too long" (retail stops scripts that run too long in one go – with about 20,000 scanned items that happens). The test now pauses regularly; the language test checks one language per frame.
- **Sell tab with the auction house closed:** showed "No sellable items in your bags" on retail although the bags were full. The "can this be posted?" check now only runs while the auction house is open.
- **Reagent bag (retail):** items in it now count for selling, mail to alts and vendor selling.

## 0.63.1
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Retail (The War Within / Midnight, interface 12.x): item names are back.** The modern game no longer has the old `GetItemInfo`, `GetItemIcon` etc. – AHSentinel now uses `C_Item` there. Before, "Item #12345" showed instead of the name (buy tab, price history, tooltip, test data).
- **Names are loaded in the background:** the full scan of the modern auction house only returns item IDs. Items your client does not know yet are now requested in the background (40 per second); the lists update by themselves.
- **Self-test "Search by name"** failed on retail ("'Item #251665' -> nil"). It now picks an item whose name is already known and otherwise reports how many names are still loading.
- **Test mode on retail:** the fake auctions and mails need item names – they are created there now as well.
- Disenchanting: spell name via `C_Spell` (retail).

## 0.63.0
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchanting – everyone learns together:** what comes out of a disenchant is now shared through the price sync with every player who has AHSentinel (or only your guild if you set it so). Everyone sends only their own numbers, nothing is counted twice, so the drop chances match WoW Forever's real ones much sooner.
- **New starting values for green items:** 75 % dust, 20 % essence, 5 % shard (weapons the other way round: 75 % essence, 20 % dust). Your own and the shared results adjust them from there.
- Tooltip: "Disenchant (Ø, 12 own, 340 shared)" shows how many disenchants the value is based on.
- Only which material came out how often is shared – nonsense (foreign items, impossible amounts) is rejected.
- ProfessionSentinel uses these values for its "Craft & disenchant" ranking.

## 0.62.4
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Stackable goods combined (classic auction house):** in the buy tab, all offers of a stackable item
  with the same unit price form **one row with the sum** – e.g. 5 stacks of 20 show as "100", with the
  unit price and the **total price** of the row.
- **Buy several at once:** click a row, **Shift+click** adds more rows. The box on the right shows the
  pieces, the number of offers and the total of your selection. "Buy selection" asks once with the
  total, then every click buys the next offer (WoW needs one click per auction).
- "Show single offers" switches back to the old list (also for bidding). The modern auction house
  already combines goods by price – there you simply enter the quantity.

## 0.62.3
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Item names for WoW Forever:** the built-in names of WoW Forever come first again; the Burning
  Crusade names added in 0.62.1 only fill gaps. About 2,000 items that were renamed in TBC now show
  their Forever name again in the other languages.

## 0.62.2
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Test and developer functions are hidden:** the self-test and the test mode (button "Test",
  `/ahs test`, `/ahs testmode`) are only available to the developer now. For everybody else the
  addon looks and works the same, just without these tools.

## 0.62.1
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**Realistic prices – important for a fresh server, where prices fall every day:**
- **Market value follows the market faster:** newer prices count more (half-life 3 days) instead of a
  plain 14-day median, and silly prices like "1666g 99s 98c" no longer count at all.
- **Price crash detection:** if the last two scans (at least 6 hours apart) are both far below the market
  value, the item is marked "price just crashed" (tooltip) and its market value counts as uncertain.
  Such items are no longer suggested for buying, flipping or selling.
- **"Today" sells at what you really get:** at most 5 % above the cheapest current offer, never the old
  market value. If the AH price has crashed close to the vendor price, it suggests selling to a vendor.
- **Bids** are only suggested on items with a reliable market value and never on silly prices.
- **Profit/day** in bargains counts only a share of the daily sales (you are not the only seller),
  at most the available amount and what 20 % of your gold can buy.
- The overview no longer lists prices ending in …99s 9xc.

**Fixes:**
- **Esc** closes the price history again instead of the whole auction house (also after a language switch).
- **Test mode:** a sniper purchase with the mouse wheel now shows up in the test log and the ledger.
- **Mailbox:** new button "Repost (N)" for returned auctions; on-screen messages say "[Test]" in test
  mode; collecting is slower in test mode so you can try "Stop"; returned test goods are counted.
- `/ahs summary` no longer shows "+all your gold since yesterday" when yesterday's gold is unknown.
- The money field shows what it understood for every input ("= 5s"), not only for plain numbers.
- An item tooltip no longer stays on top of a newly opened window ("Today", options, ...).
- Self-test details no longer show raw icon codes.

**Languages:**
- **About 10,000 more item names in every language,** including all Burning Crusade items
  (English: 25,800 instead of 14,800). Lists no longer show German names in an English interface.
- **Lists always show names in the current language** – search results, sniper targets, watch list,
  shopping lists, ledger, auctions – also right after switching, without a new search.
- The buy tab keeps its category, search text and filters after a language switch.
- Options: long labels (French, Spanish, Russian) wrap into a second line instead of being cut off.
- Buy filters: short placeholders ("Lvl min / max") that no longer overlap.
- Chinese: "simplified" and "traditional" can be told apart in the language list; item names without a
  Chinese name are written without umlauts (ö → oe), which the Chinese font cannot show.
- Self-test: the language check now also finds cut-off option labels, list names in the wrong
  language and counts missing item names per language.

## 0.62.0
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**AH Analyzer Pro is now called AHSentinel** – part of the Sentinel family (BuffSentinel,
GuildSentinel, ThreatSentinel).

- **Your data is taken over automatically:** the download contains the new folder `AHSentinel`
  and a small `AHAnalyzerPro` folder that only hands your old data (prices, ledger, lists,
  sniper targets, settings) over on the first start. Afterwards you can delete `AHAnalyzerPro`.
- **New command `/ahs`** (also `/ahsentinel`); `/ahp` keeps working.
- Everything else stays the same.

**Install:** copy both folders from the ZIP into `Interface\AddOns` (overwrite the old
`AHAnalyzerPro` folder), start the game, done.

## 0.61.2
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **One language for everything:** item names now follow the addon language (unless you chose a
  separate item-name language), and the tooltip shows the item name in that language when it
  differs from the game client's.
- **Language switch rebuilds every window:** besides the main window also "Today", the test window,
  the mail-to-alts rules and the mailbox panel (even while the mailbox is open).
- **Self-test:** new check "language switch" - every addon language once and then back and forth
  several times; window, tabs, texts, item names and tooltip must appear in the chosen language,
  and the original language is restored afterwards.

## 0.61.1
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fixed: "Today" suggested unrealistic purchases.** Page-by-page scans often see only part of the
  auction house, which looked like huge sales. Sales per day are now only estimated between
  **complete** scans, count only half of each drop (the rest expired or was cancelled) and never
  more than half of what is usually listed. "Price change since scan" also compares complete scans only.
- **Capital protection:** each suggestion in "Today" uses at most 20 % of your gold, all of them
  together at most half; the window shows the capital needed. The self-test checks this.
- **Overview:** rises to several times the market value and drops from a former moon price are no
  longer listed.
- **Mailbox:** the addon's buttons now sit in a tidy panel **next to** the mailbox instead of over
  its frame. "Collect all" is only shown when WoW has no "Open all" button of its own (and in
  test mode for the test mail), "Stop" only while collecting.
- **One money field instead of three:** type "5s", "1g 20s", "4s 85c" or "1.5" (= 1g 50s); a plain
  number shows what it means ("= 5g"). No more silver ending up in the gold field.
- Smaller things: "Bid" without a selected listing says so, the vendor warning when posting only
  appears when it matters (at least 1 silver and 10 %), fictional auctions show up in test mode
  right away, the "Today" window closes when you jump to a tab.

## 0.61.0
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**More profit, fewer fake bargains:**

- **"Today" (button in the overview, `/ahp today`):** the actions that bring the most gold right
  now, ranked by estimated net gold - buy below vendor price, flips, selling what is in your bags,
  undercut auctions, items to repost, disenchant and bid deals. Click a row to jump straight to
  the right tab.
- **Sell-through instead of listing prices:** from your scans the addon now estimates how much of
  an item actually sells per day and whether its market value can be trusted. Items that are
  rarely listed or only have "moon prices" (like 2499g 99s 99c) are hidden from bargains, flips and
  the overview (button "also unsure" shows them). Bargains are sorted by **profit per day**, the
  tooltip shows "~N/day sold (estimated)".
- **Net profit with the posting fee:** on the classic auction house the fee is now estimated from
  the vendor price ("approx.") and learned exactly the first time you really post. Profits subtract
  the fee you lose when an auction comes back (based on your own sell rate).

## 0.60.11
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Mailbox buttons always answer:** "Mail collected: ..." now also appears in the middle of the
  screen, and an empty mailbox says "Nothing to collect" instead of staying silent.
- **"To alts" without a rule** says so in the chat before opening the rules window.
- **Test mode:** the fictional "sold" mail belongs to the fictional sold auction, and that auction
  disappears from "My auctions" once its money is collected - like in the game.

## 0.60.10
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Test mode with fictional auctions:** "My auctions" now shows three fictional auctions (one
  undercut, one cheapest, one sold) plus everything you post in test mode - so cancelling and the
  undercut check can be tried without a real auction. The self-test uses a fictional auction for
  "cancel" when you have none.
- **Test mailbox:** in test mode the mailbox buttons of the addon work with fictional mail (sold,
  won, expired, cancelled, outbid, a normal letter): auto-collect, "All", ledger invoices and the
  repost list can all be tried - your real mail stays untouched.
- **Buy tab:** the bid field and the selected listing are reset when you switch to another item
  (no more old bid in the field). The header shows the cheapest listing and the market value
  (median 14 days) separately, and says when more listings are still loading.
- **Sniper:** listings of the previous target are no longer shown under the new target's name.
- **Self-test:** the sniper test buys (simulated) the smallest stack instead of a 2-stack.
- **Price history window:** can be dragged by its title.

## 0.60.9
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Message when the scan is done:** a large message in the middle of the screen ("AH scan done:
  N items") plus a sound (if alert sounds are on in the options) - you no longer have to watch the
  chat. A scan without results is shown there too.

## 0.60.8
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fixed: no price lines in item tooltips** on some clients (e.g. TBC Anniversary). The addon
  now hooks every way WoW fills an item tooltip and resizes the tooltip after adding its lines.
  The self-test now checks the real bag tooltip.
- **Esc closes only the top window:** e.g. the price history window - the addon window and the
  auction house stay open (before, one Esc closed everything).
- **Price history window:** the close button no longer sits on top of the "All" button.
- **Test mode** now also restores search favorites, repost list and mail rules.
- **Your own searches come first:** a running watcher round is stopped so the buy tab no longer
  waits ("Waiting for the watcher ...").
- Buy tab shows "Bought: ..." instead of "Purchase in progress ..." when done.
- Overview: tenfold price jumps (almost always bogus data) are no longer listed as rises/drops.
- Smaller fixes: test mode log shows sniper buys as such, shopping lists release the keyboard after
  deleting a list, no "N entries" overlap in the lists window, shorter option label "Expiry
  reminder", posting fee on classic AH shows "when posting" instead of "?", iLvl filter hint only
  when there are results, faster mouse-wheel scrolling in the report window, report title
  "Test report".

## 0.60.7
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **New "Test" button** at the top of the window (and in the auction house bar): self-test and
  the new **test mode** in one window.
- **Test mode:** try every feature by hand with your real auction house data - buy, bid, sniper
  (mouse wheel too), post, cancel, vendor sale, collecting and sending mail. Every trade is only
  simulated: the command to the server is intercepted and the server's answer is played back, so
  messages, ledger and sniper counters behave like the real thing. All settings and data (lists,
  ledger, sniper, watcher, selling) are restored when you stop test mode - or automatically after
  a /reload or crash. A log shows every simulated action and is included in the copied report.
  Note: only the addon's buttons are simulated, Blizzard's own auction house buttons still buy
  for real. Also: `/ahp testmode`.

## 0.60.6
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Self-test simulates real trading:** with the real auction house listings it now runs instant
  buy, bid, sniper buy, posting and cancelling exactly like the real thing - same listing, same
  price, same command. The command to the server is intercepted, so nothing is bought, posted or
  cancelled; the test finally checks that your gold is unchanged. Chat messages during the
  simulation are marked "[Simulation]".
- **Self-test:** the watcher is switched off again right after its test round, so it no longer
  blocks the following server searches.

## 0.60.5
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fixed (classic clients):** a Lua error "attempt to compare number with nil" could appear when
  opening the auction house (bid tracking after a reload).
- **Watcher/Sniper status in the header** now always updates when you switch them on or off.
- **Self-test:** a market scan still running in the background no longer makes all server
  searches time out - in the "saved data" mode it is stopped, otherwise the test waits for it.
  Starting a scan during the test is blocked.
- **Self-test:** settings, the watcher and the window (tab, or closed) are restored reliably
  after the test; if something can't be restored, the report says so.
- **Text window** (copy report) now always opens in front, starts at the top and scrolls
  quickly with the mouse wheel (hold Shift for big steps).

## 0.60.4
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Self-test with saved data:** new button "With saved data" in the self-test window (or
  `/ahp test saved`). It tests with the auction house data you already scanned - no new scan.
  It even runs with the auction house closed; the server searches are then skipped.

## 0.60.3
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix for TBC Anniversary (and other classic clients):** "My auctions" never updated and some
  auction house messages (e.g. "auction posted") never arrived. These clients know the event names
  of the modern auction house but never fire them for the classic one; the addon now always uses
  its own events there. Found by the new self-test.
- **Self-test:** the copied report can now be scrolled, and the result list is wider - hover a
  row to see the full text.

## 0.60.2
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Self-test:** Options -> "Self-test" or `/ahp test` checks every feature with real data from
  your auction house: market scan (if needed), market data, every tab, all calculations and real
  server searches (Buy, price check, Sniper, Watcher, your auctions). Buying, bidding, posting and
  cancelling are locked while it runs; your settings and sniper targets are restored afterwards.
  The result is shown in a window, can be copied as a report and is saved in the SavedVariables.

## 0.60.1
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Real minimap button:** the button now sits on the minimap like with other addons - drag it
  around the minimap with the mouse, the position is saved. Works with round and square
  minimaps. Hide or show it in Options or with `/ahp minimap`; `/ahp reset` brings it back.
- **New icon:** a golden scale - on the minimap button, in the title bar and in the addon list.

## 0.60.0
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**Tidier window - 5 tabs instead of 11:**

- **Overview · Buy · Sell · Market · Ledger.** Related pages are now sub-tabs:
  Buy = Buy, Sniper, Watcher, Bargains · Sell = Post, My auctions · Market = All prices, Watchlist.
  Every feature is still there, nothing was removed.
- **Price history in its own window:** clicking an item opens the price history next to the
  addon - the list you came from stays exactly where it was. The window can be moved and resized.
- **Sniper and watcher in the title bar:** see at a glance whether they are running and turn them
  on or off with one click (right-click opens their tab).
- **Remembers where you were:** the addon opens on the tab you used last, and every main tab
  remembers its last sub-tab.

## 0.59.33
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**Comfort update - twelve small things that save clicks every day:**

- **Stack size and number of stacks** (classic auction house): in the Sell tab, choose e.g.
  5 stacks of 20. Remembered per item and used by "Post all".
- **Collect mail automatically:** opening the mailbox collects auction mail right away
  (hold Shift while opening to skip). Can be turned off in Options.
- **Minimum price per item:** the new "Min" button in the Sell tab remembers the current price
  as a floor. The suggestion never goes below it, and "Post all" waits instead of selling cheap.
- **Only what I'm missing:** next to your profession window, a new button puts only the missing
  materials on a shopping list - counting your bags, bank and alts.
- **Alt-click an item** in your bags or a link in chat: opens the price history, or the Buy tab
  while the auction house is open.
- **Sell rate in the tooltip:** how much of what you posted actually sold (last 60 days) and how
  long it usually took.
- **Expiring auctions:** a message when your auctions have less than 30 minutes left, and at
  login what expired since your last visit.
- **Favorites in the Buy tab:** save searches (text, category, level, iLvl, rarity) and run them
  again with one click.
- **Gold goal:** set a goal for all characters together (Options or `/ahp goal 5000`) and get a
  message when you reach it. The daily summary shows your progress.
- **Guild bank value:** new view Ledger -> "Guild bank" shows what is in your guild bank and what
  it is worth (TBC and later).
- **Raid supplies:** one click creates a shopping list with potions, flasks, elixirs and buff
  food for a raid week (Classic, TBC, Wrath) - with the total cost. Also `/ahp raid`.
- **Price sync with your guild only:** new option to share prices only with your guild.

## 0.59.32
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **No more absurd profits:** items that would show a profit of 1000 % or more (almost always
  bad data such as an outlier market value or placeholder prices) are no longer listed in the
  Profit tab (all views: market value, vendor, disenchant, bids, flips) and no longer appear
  under "Biggest price increases" in the Overview.

## 0.59.31
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Item level as a search filter:** the Buy tab and the Market tab now have "iLvl from" /
  "iLvl to" fields. They filter the results instantly, without a new search on the server,
  and also apply to the single listings of an item. In the Buy tab you can also search with
  only an iLvl range.

## 0.59.30
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sell junk at vendors:** at any vendor a button below the window sells grey items and
  everything a vendor pays more for than the auction house (after the AH cut). The tooltip
  lists what will be sold. Can be turned off in Options.
- **Inventory value:** new view **Ledger -> "Assets"** shows what your bags, bank and alts are
  worth (market value and vendor value), plus the gold of all characters.
- **Daily summary at login:** once a day the chat shows yesterday's profit, the last 7 days,
  the gold of all characters and how many items are waiting to be reposted. Any time with
  `/ahp summary`. Can be turned off in Options.
- **Repost with one click:** expired or cancelled auctions that came back by mail are
  remembered. In the Auctions tab, "Repost (n)" posts them again one click at a time,
  undercutting the current price, with price protection.
- **Flip recommendations:** new view **Profit -> "Flips"**: items that are listed regularly and
  are currently well below market value. Stars show the turnover, sorted by expected profit.
- **Mail to alts:** set rules like "Herbs -> Alchemist" (Options -> Mail to alts). At the mailbox
  the "To alts" button sends one mail per click with up to 12 matching stacks.
- **Buy tab:** the iLvl column now shows the item level for every item (also for items the
  game had not loaded yet) and can be sorted.
- **Sell tab - listings appear faster:** listings show up while they are still loading, a click
  on an item now goes before the bargain watcher and sniper, and hovering over an item already
  starts loading its listings.
- **Chat help:** `/ahp help` (or `/ahp ?`) lists all commands in the chat. Unknown commands show
  the list too.

## 0.59.29
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Bid sniping:** new view **Profit -> "Bids"** lists auctions whose next bid is far below
  market value, with the time left. They are collected during the full scan (classic auction
  house) and every search in the Buy tab. Click an item to open it in the Buy tab and bid.
  (Thanks paladriel for the idea!)
- **Price protection when posting:** warns if your price is far below market value or follows a
  suspiciously cheap single unit - a second click is then needed, and "Post all" skips such items.
  Threshold in Options (off / 20 / 30 / 40 / 50 %, default 40 %).
- **Sale notification:** as soon as one of your auctions sells you get a message with the
  proceeds after the AH cut and your profit compared to what you paid, plus a coin sound.
  Can be turned off in Options.

## 0.59.28
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Support button:** if you like the addon, you can now support it with a small donation.
  The "Support" button in the addon window (also in Options and via `/ahp donate`) shows the
  PayPal link ready to copy. Thank you!

## 0.59.27
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Own window by default:** the addon now opens in its own window, detached from the auction house.
  The "AH Analyzer" tab at the auction house shows/hides it. You can still embed it in the
  auction house window: Options -> "Show in auction house".
- **Resizable window:** drag the bottom-right corner to make it as big as you like - all lists
  grow with it. The size and position are saved. Text size: Options -> "Text and content size".
  "Positions" in the options resets window size and position.

## 0.59.26
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profit tab: column names fixed** (thanks paladriel!). The comparison column was renamed in the
  wrong place since the iLvl column was added - now "Market value" / "Vendor price" /
  "Disenchant value" are on the right column, and the price column is called **"Current buyout"**
  (cheapest buyout at the last scan), so it can't be mixed up with the 14-day market value.
- **"Search in auction house"** (right-click menu) now works on the classic auction house
  (Classic Era, WoW Forever, TBC, Wrath) - it opens the Browse tab and searches for the item.
  It also switches back from the AH Analyzer view first on every client.

## 0.59.25
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper shows the total amount** below the offer list: how many units of the sniped item
  will be bought in total (up to your target quantity, budget and gold), the total cost,
  the average price per unit and how many purchases (wheel notches) that takes.

## 0.59.24
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Mouse-wheel buying now also works over the addon window** (lists, charts, the whole
  AH Analyzer area): while a hit is waiting, the wheel buys it instead of scrolling.
  When nothing is waiting, the wheel scrolls the lists as usual.

## 0.59.23
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix: buying with the mouse wheel didn't work on the classic auction house** (Classic Era,
  WoW Forever, TBC, Wrath) since 0.59.20. There you can only buy what is in the auction house's
  current result list - and Sniper and Watcher kept searching on. Now, while a hit is waiting:
  it stays in the list (on the right result page, loaded in advance), the Sniper only re-checks it,
  the Watcher waits, and the sound keeps repeating until you buy it or it is gone.
- **Options -> "Sniper buys with" / "Watcher buys with":** choose mouse wheel (default) or your own
  key, separately for Sniper and Watcher hits. The same key for both buys whatever hit is waiting.

## 0.59.22
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Back button in the price history:** when you open an item's price history from another tab
  (e.g. Market, Overview, Buy, Watchlist), a "< Market" button next to the title takes you back -
  to the same page and sorting of the list you came from.

## 0.59.21
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Self-adjusting search speed - always at the limit of the server.** Where the server reports
  when it is ready (modern auction house and the classic one), the addon adds no delay of its own.
  Where it doesn't, the delay shrinks after every answer and doubles when the server drops a request,
  so Sniper, Watcher, Buy tab and price checks automatically run as fast as each WoW version allows.
  The Watcher no longer waits 2 seconds between rounds.

## 0.59.20
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper and Watcher search as often as the auction house allows.** The Sniper searches your
  targets, the Watcher looks for lucky bargains in the categories - they take turns
  (Sniper, Watcher, Sniper, ...) so neither one blocks the other.
  The Sniper's default interval is now "max." (Options -> "Sniper searches every").
- **After a hit the Sniper keeps searching:** the hit stays buyable with the mouse wheel / your key,
  and the sound repeats every few seconds as long as it is there (chat message only once).
- Your own actions always come first: a search in the Buy tab and price checks in the Sell tab.

## 0.59.19
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Watcher searches much more often:** instead of a fixed round every 20 seconds it now starts
  the next round as soon as the server allows (2 s pause). It takes turns with the Sniper and
  always lets your own searches in the Buy tab go first, so nothing else gets slower.
- **Watcher on the classic auction house** now reads all result pages - before it stopped after
  the first page and only saw the rarest (usually most expensive) items.
- **Bait offers (single items at the very bottom) are no longer shown** anywhere - not in Buy,
  Sniper, Sell price check or the Watcher list. They are still ignored for prices, and when buying
  commodities the price shown already includes them (the server always sells the cheapest units first).

## 0.59.18
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Pages in every table:** above each list there is now a page bar
  ("6280 entries  < 1 2 3 ... 370 >"). Click a number to jump straight to that page,
  < and > go one page back/forward. The mouse wheel and the scrollbar still work as before.
  Narrow lists show a compact "< 3 / 20 >".

## 0.59.17
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- In every item list (Buy, Market, Overview, Watchlist, Sell, Auctions, Profit, Charts,
  Ledger ...) clicking the **Item** column now sorts by **rarity first, then by name**
  (epic, rare, uncommon, common, poor - click again for the reverse order).
- New **iLvl** column in all item lists (item level of weapons and armor), sortable.

## 0.59.16
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Buy tab shows results **instantly**: clicking a category (e.g. Metal & Stone) immediately lists
  every item of that category from your last market scan (price and quantity in grey = not yet
  confirmed). The live search runs in the background and replaces them page by page with the
  real current offers - on the classic auction house that takes a few seconds per page.
- Clicking an item while a category search is still running now opens its offers right away
  instead of waiting for the category search to finish.

## 0.59.15
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Buy tab is much faster when switching categories (e.g. Herbs <-> Cooking):
  - a new search now cancels the running one immediately - before, it waited until the old
    search had read all its pages (several seconds each on the classic auction house);
  - results are remembered for 3 minutes, so switching back shows them instantly.
    The *Search* button (or Enter) always loads fresh data from the server.

## 0.59.14
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Classic Era / classic auction house:** "Your client does not support auction house search
  (SendBrowseQuery missing)" is gone - the classic auction house (Classic Era, TBC Anniversary,
  Wrath) is supported since 5.9.12; this is the first public release that includes it.
- **Size:** new option *Options -> Size in auction house* (100-160 %). Above 100 % the addon
  extends past the auction house to the right and down and everything (text included) gets
  bigger. A "<" button at the top leads back to the auction house. The separate window grows too.
- **Works next to TSM, Auctionator & co.:** the "AH Analyzer" tab now moves next to the
  right-most tab, including tabs that other addons add later - no more overlapping tabs.
  Clicking another addon's tab now closes the AH Analyzer view.
- Buy tab (classic auction house) now reads all result pages - before, it often showed only
  epic items.
- Tables: the scrollbar can be dragged with the mouse.

> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Fix (Classic auction house): the Buy tab only showed epic items - it stopped after the
  first result page. It now reads all pages (with a "page x of y" progress) and shows
  results while it is still searching.
- Tables: the scrollbar can now be dragged with the left mouse button, and clicking into
  the bar jumps there.
- Charts: tiny price changes no longer look like a crash; axis labels show silver/copper
  when needed.
- New tab **Buy** (right next to Overview) - works like the auction house's own Buy tab:
  - Search by name (part is enough) and/or category on the left (weapons, armor,
    containers, consumables, trade goods with cloth/leather/metal/herbs/cooking/
    elemental/enchanting, gems, recipes, miscellaneous), level from/to, rarity.
  - Results with available quantity, cheapest price per unit and % of market value.
  - Click an item to see all listings. Commodities: enter a quantity or click a price
    tier, "Buy now" gets the price from the server, "Confirm purchase" buys.
    Bait offers are marked. Gear: buyout (second click confirms) or place a bid.
  - Purchases are booked in the ledger right away. Sniper, price checks and the watcher
    wait while you search in the Buy tab.
- The addon window is now exactly as large as the auction house window (measured every
  time the auction house opens, also with UI scaling). Options > Window size: "like AH"
  switches it back on, - / + sets the size by hand.
- The addon window is always exactly as wide and as high as the auction house window
  (measured every time the auction house opens, UI scaling included; also the wide classic
  auction house). Options > Window size now only
  changes options, help and lists.
- Better use of space in every tab: lists and tables now stretch to the full width and
  height of the window (more rows, wider name column) - in the auction house and in the
  separate window. Fixed: the watchlist button and the chart item list reached past the
  bottom edge.
- No more stutter when scanning a big auction house: the scan only counts results while
  it runs, the evaluation afterwards (prices, bait check, names, price sync) runs in small
  portions over several frames, long lists are built and sorted in the background and at
  most once per second. In a test with 12,000 items the longest frame dropped from about
  660 ms to under 50 ms. Classic auction house: the full list is read in time slices too.
- Auction house view fills the whole auction house window (also the wider classic auction
  house in Classic Era / Anniversary), covers the classic search row and is no longer
  see-through.
- Nicer lists: every item list shows the item icon and the name in its rarity color;
  the cards in Overview and Ledger have icons and use the full width.
- Rarity is now a drop-down menu with check boxes (Poor, Common, Uncommon, Rare, Epic -
  any combination, e.g. only Uncommon and Epic) in the Buy tab and for sniper targets;
  older sniper targets keep their range. The sniper filter row (rarity, item level, level) is
  always visible now. New: rarity filter for the item list in Charts.
- Fresh look: every tab has its own icon in the title with a fading gold line; tables have
  a gradient header with a gold rule, a soft hover glow and a gold bar on the selected row;
  panels and cards get a subtle sheen and an inlaid border; charts show a soft gold area
  under the price line and highlight the current price.
- The separate addon window takes exactly the width and height of the auction house window.
- The sniper filter row (rarity, item level, level) is always visible.
- Auction house view: slightly narrower scan button so all eleven tabs fit in every language.

## 5.9.12
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Classic Era, TBC Anniversary and Wrath Classic:** the addon now works with the classic
  auction house. Fixes "Your client does not support the auction house search
  (SendBrowseQuery missing)".
  - Market scan reads the whole auction house at once (when the server allows it every
    15 minutes), otherwise page by page.
  - Price check, sniper (items and search terms), bargain watcher, buying, posting,
    your auctions and cancelling use the classic auction house functions.
  - Stackable goods are posted as full stacks (e.g. 35 linen cloth = one stack of 20,
    the rest with the next click). The deposit is not shown in the classic auction house.
- WoW Forever, Cataclysm Classic, Mists of Pandaria Classic and Retail are unchanged.

## 5.9.11
> ⚠️ **This is a beta version.** It may still contain bugs.
> If you run into any errors or unexpected behavior in-game, please report them in the comments on CurseForge, ideally with the Lua error message (if any) and the WoW version you play on.

- Updated version number to 5.9.11.
- Supports all WoW versions: Classic Era, WoW Forever, TBC Anniversary, Wrath Classic, Wrath Titan Reforged, Cataclysm Classic, Mists of Pandaria Classic and Retail.

## 5.9.1
- TOC: interface numbers for every WoW version (Classic Era, WoW Forever, TBC Anniversary,
  Wrath, Wrath Titan Reforged, Cataclysm, Mists of Pandaria Classic, Retail) - the addon
  is no longer listed as "out of date" there.

## 5.9
- Bait offers: a single unit at the very bottom of a commodity (linen cloth,
  copper bars ...) is treated as bait and ignored everywhere - sniper (no hit,
  status "bait offer"), sell suggestion and undercut check, market value,
  trends, bargains, EMAs and price sync. Gear is not affected.
- After every scan, suspiciously cheap commodities (below 70 % of market value)
  are stored as "unverified" and re-checked with a single search; the real
  price replaces them. Unverified prices never count and are not shared.
- Note: when buying commodities the server always sells the cheapest units
  first, so on a real hit the bait unit is bought along (and included in the
  planned cost).
- Charts: time-based EMAs over 6 hours, 1 day and 7 days (real prices only,
  from 10 prices on), markers where the 1-day EMA crosses the 7-day EMA,
  grey points for unverified prices. On/off button.
- New tab "Watcher" (bargain watcher) next to the sniper: searches trade goods
  (herbs, metal & stone, cloth, leather, enchanting, elemental, gems, cooking,
  optional consumables - never weapons/armor) for prices at or below x % of
  market value (default 50 %, minimum value per unit 10 copper). All categories
  run in one search, with automatic fallback to one category at a time. Every
  hit is verified (bait offers don't count), announced with sound and chat,
  and bought with the same mouse wheel / key as the sniper.
- Speed: search results are evaluated as soon as the server reports them,
  the server's own throttle is used instead of fixed waits (0.3 s instead of
  1.5-2 s between searches), automatic slow-down on errors. /ahp debug shows
  the speed.
- Sniper and watcher buy commodities with ONE mouse wheel notch: on a hit the
  price is fetched from the server in advance (and refreshed while the hit
  waits), the first notch buys right away. If the price has risen meanwhile,
  nothing is bought and a new search starts. If the server gives no price
  confirmation, it switches back to two notches by itself.
- In the auction house the options button is now a gear icon, so all ten tabs
  fit in every language.

## 5.8
- Disenchant values learn: every disenchant you do is recognised (spell + loot
  window) and remembered per group (quality, item level band, armor/weapon).
  The table values count as 10 imaginary disenchants; with each real one your
  results weigh more (50 % after 10, 83 % after 50, 91 % after 100), so chances
  and amounts move towards the reality on your server.
- The tooltip shows how many of your own results went into the value; the
  options show the total and can reset it.
- Starting values for green items as observed in the WoW Forever beta:
  70 % dust, 25 % essence, 5 % shards on every item level band (weapons
  mirrored: 70 % essence, 25 % dust).

## 5.7
- Mailbox: "Collect AH mail" takes gold and items from all auction mail with one
  click ("All" for every mail, COD is never paid). Invoices are booked first,
  stops when your bags are full.
- Sell tab: "Series" posts every bag item with a remembered price, one click per
  auction. Fresh prices are loaded at the start; items are skipped if the price
  falls below 70 % of your last price or a vendor pays more.
- Vendor buy prices are read automatically at every merchant: used for profession
  material costs, shopping lists (items cheaper at a vendor are not sniped) and
  shown in the tooltip.
- Alts & gold: gold, bags and bank of every character (account-wide). The tooltip
  shows how many your alts have; the Ledger tab has a "Gold" view with all
  characters and the gold of the last 30 days.
- Ledger "Statistics": sell-through per item, sales by time of day and weekday,
  best selling hours.
- Disenchant value (Classic table, estimates) in the tooltip and a new Profit view
  "Below disenchant value".

## 5.6
- Shopping lists: named lists of items and quantities. "Check prices" loads all
  listings at once, "As sniper targets" creates a target for every missing item
  (max price = 100/110/125/150 % of the market value). Items already in your bags
  are subtracted. Open via the Sniper tab, right-click on an item or `/ahp lists`.
- Professions: a window next to the profession frame (incl. Enchanting) shows
  material cost, value of the result and profit after the AH cut, plus the best
  recipes. "Materials as shopping list" puts the reagents for N crafts on a list.
- Help pages for all new tabs in all languages.

## 5.5
- New tab "Ledger": income (after the 5 % AH cut), spending, deposits and profit
  for today / 7 days / 30 days / all, per item or as a history.
  Sales and purchases are read from the invoices in your mailbox (just open it),
  sniper purchases and deposits are booked right away - nothing is counted twice.
- Sell tab warns when the price is below your average purchase price.

## 5.4
- New tab "Sell": items from your bags, price check, suggestion that undercuts the
  lowest listing (by 1 copper, 1 % or 5 %), quantity, duration, deposit, AH cut and
  proceeds. Warns (and asks for a second click) when a vendor pays more.
- New tab "Auctions": your auctions with status (lowest / tied / undercut / sold),
  "Check undercuts" and cancel with one click per auction.
- Tabs inside the auction house window shrink to fit in every language.

## 5.3
- Market value = median of the last 14 days (single outliers barely count).
- New column "% market" in the Market and Sniper tabs, coloured green to red.
- Vendor price in the item tooltip (can be turned off in the options).
- Profit tab: bargains below market value or below vendor price; a vendor bargain
  becomes a sniper target with one click. After every scan the chat shows how
  many items are listed below vendor price.
- Column headers explain themselves on mouse-over. CSV export has market value
  and vendor price.

## 4.9 – 5.2
- Prices and a small price chart in every item tooltip.
- The addon as its own tab inside the auction house window.
- Money shown with coin icons or letters.

## 4.8
- The addon now speaks the language of your WoW client: English, German, French,
  Spanish (EU/LA), Portuguese, Italian, Russian, Korean, Chinese (simplified/traditional).
- Language can be changed manually in the options or with `/ahp language`.

## 4.7
- German/English interface, item names follow the client language automatically.

## 4.6
- Built-in item name list for ~23,000 items in 10 languages (source: QuestieDB, wow-classic-items).

## 4.5
- Search items by name in any language, by item ID or by shift-clicking an item.
- Suggestions while typing, accents and upper/lower case don't matter.

## 4.4
- Two designs: "Classic" (looks like the WoW auction house) and "Modern".
- Options window, help for every tab, right-click menu on every item.

## 4.3
- Sniper: targets with max price per item, quantity, budget, rarity, item level and level filters.
- Searches targets on its own while the auction house is open; buy with the mouse wheel or your own key.

## 4.0 – 4.2
- Market scan, price history, trends, watchlist with alerts, charts, flipping calculator.
- Price sync between all players using the addon.
