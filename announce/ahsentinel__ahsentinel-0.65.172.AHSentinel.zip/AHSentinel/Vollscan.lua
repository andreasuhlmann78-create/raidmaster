if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Schnell-Vollscan mit Einzelauktionen (Anweisung der Prüf-Sitzung 10.11. 10:15, Messung M1 belegt:
-- ReplicateItems liefert in WoW Forever 180'368 Einzelauktionen mit Restzeit-Stufe, ohne Besitzer, ohne auctionID)
--
-- V1 Messungen ins Protokoll und in den Testbericht: M1b (Bedeutung der Restzeit-Stufen über eigene Auktionen),
--    M1c (Drosselung: Abstand, Antwort, Anzahl), M1d (Lesedauer, längster Frame, Portionen).
-- V2 Option "Schnell-Vollscan": der Scan-Knopf liest ReplicateItems in Portionen und verdichtet je Item: Mindestpreis,
--    Menge, Auktionen, Preisleiter, Stück je Restzeit-Stufe. Preisverlauf/Marktwert bekommen dieselben Eingaben wie
--    beim bisherigen Scan (Mindestpreis, Menge). Lockangebote (1 Stück ganz unten) zählen nicht.
--    Exakte Warteschlange Q(Preis) aus der Preisleiter.
-- V3 Speicher: nur die Zusammenfassung je Item (gehandelt/Watchlist/Sniper/Einkaufsliste + die 500 grössten).
-- V4 Verfolgung zwischen zwei Vollscans über Signaturen (Menge, Sofortkauf): vorzeitig weg (gekauft oder
--    abgebrochen), abgelaufen, neu. Absatz S_gemessen je Item/Tag (EWMA, Halbwertszeit 3 Tage).
-- V5 SellOutlook nimmt S_gemessen, sobald es >= 3 Tage Daten hat (Quelle "gemessen").
--
-- ReplicateItems ist ein Scan: NUR auf Auslösung durch den Spieler (Scan-Knopf, /ahs scan, /ahs vollscan), nie von
-- selbst. Altes Auktionshaus (Era/TBC) oder Funktion fehlt: der bisherige Scan.
-- Keine Namen: Besitzer werden nicht gelesen, Item-Namen nicht gespeichert.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local VS = {}
A.FullScan = VS

VS.MIN_GAP = 15 * 60          -- M1c offen: Blizzard-Wert ~15 Min. (vermutet) - bis gemessen nicht öfter
VS.TIMEOUT = 90               -- so lange auf REPLICATE_ITEM_LIST_UPDATE warten
VS.PAIR_MAX = 2 * 86400       -- grösserer Abstand zweier Vollscans zählt nicht für den Absatz
VS.HALF_DAYS = 3              -- EWMA-Halbwertszeit des Absatzes
VS.MEASURED_DAYS = 3          -- V5: so viele Tage Daten, bevor S_gemessen gilt
VS.MEASURED_PAIRS = 3
VS.TOP = 500                  -- V3: so viele umsatzstärkste Items zusätzlich (nach Zahl der Auktionen)
VS.READ_BUDGET = 5            -- W4: ms je Frame beim Lesen (Ziel längster Frame ≤ 8 ms)
VS.CHECK_EVERY = 25           -- W4: so oft die Uhr prüfen (Einträge)
VS.SIG_MAX = 60               -- Signaturen je Item (die billigsten)
VS.LADDER_EXACT = 5           -- Preisleiter: die ersten 5 Preise genau, dann Stufen in % des Mindestpreises
VS.LADDER_PCT = { 1.10, 1.25, 1.50, 2.00 }
VS.QUEUE_AGE = 2 * 86400      -- so lange gilt die Preisleiter für Q
-- Mindest-Restzeit je Stufe in Stunden (Blizzard-Standard kurz/mittel/lang/sehr lang). In Forever (2/8/24 Std.)
-- VERMUTET bis M1b belegt - der Testbericht zeigt die gemessenen Bereiche.
VS.STAGE_MIN_H = { 0, 0.5, 2, 12 }

-- ------------------------------------------------------------
-- Speicher (nur neue Tabelle db.fullScan; Testroutine: Ersatz VS.testDB)
-- ------------------------------------------------------------
local function NewDB() return { v = 1, ladder = {}, sigs = {}, sold = {}, m1b = {}, m1c = {}, m1d = {}, own = { gone = 0, sold = 0, checks = {} } } end
function VS:Real()
    local db = A.db
    if not db then return nil end
    if type(db.fullScan) ~= "table" then db.fullScan = NewDB() end
    return db.fullScan
end
function VS:Store()
    if self.testDB then return self.testDB end
    if not A.db or A:Simulated() then return nil end
    return self:Real()
end
function VS:Data()
    if self.testDB then return self.testDB end
    return A.db and A.db.fullScan
end
A:On("READY", function() pcall(VS.Real, VS) end)

-- ------------------------------------------------------------
-- Verfügbarkeit
-- ------------------------------------------------------------
function VS:API() return A:Global("C_AuctionHouse") end          -- eigene Funktion (Seam für Tests)
function VS:Available()
    if A.AH_LEGACY then return false end
    local C = self:API()
    return type(C) == "table" and type(C.ReplicateItems) == "function" and type(C.GetNumReplicateItems) == "function"
        and type(C.GetReplicateItemInfo) == "function"
end
function VS:Enabled()
    if not (A.db and A.db.settings and A.db.settings.fastScan == true) then return false end
    if A:Simulated() and not self.testDB then return false end         -- Testmodus: der normale (nachgespielte) Scan
    return self:Available()
end

-- ------------------------------------------------------------
-- V2 Start (nur auf Auslösung durch den Spieler)
-- ------------------------------------------------------------
function VS:Wait()
    local st = self:Data()
    local last = st and st.lastCall or 0
    local left = self.MIN_GAP - (time() - last)
    return left > 0 and left or 0
end

-- 5a (Nachprüfung 10.11.): ausdrücklicher Messweg für M1c - darf den Mindestabstand einmal je Sitzung unterschreiten,
-- nur nach Rückfrage (/ahs vollscan messen -> /ahs vollscan messen ja). Das Ergebnis steht in M1c (Abstand, Antwort).
function VS:MeasureCommand(arg)
    if self.measureUsed then A:Print(L["Messung kürzerer Abstände: nur einmal je Sitzung."]); return false end
    if arg ~= "ja" and arg ~= "yes" then
        local left = math.ceil(self:Wait() / 60)
        A:Print(string.format(L["Vollscan-Messung (M1c): jetzt trotz Mindestabstand scannen (noch %d Min.)? Bestätigen mit /ahs vollscan messen ja"], left))
        return false
    end
    local ok = self:Start(true)
    if ok then self.measureUsed = true end
    return ok
end

function VS:Start(force)
    if self.running then A:Print(L["Es läuft bereits ein Scan."]); return false end
    if not A:IsAHOpen() then A:Print(L["Bitte zuerst das Auktionshaus öffnen."]); return false end
    if not self:Available() then A:Print(L["Schnell-Vollscan gibt es in diesem Client nicht - der normale Scan läuft."]); return false end
    local st = self:Store()
    if not st then return false end
    local wait = self:Wait()
    if wait > 0 and not force then
        -- 5b: die Server-Grenze ist nicht belegt (M1c misst sie erst)
        A:Print(string.format(L["Schnell-Vollscan erst wieder in %d Min. (vorsichtshalber, noch nicht gemessen)."], math.ceil(wait / 60)))
        return false
    end
    local C = self:API()
    local gap = (st.lastCall and st.lastCall > 0) and (time() - st.lastCall) or nil
    local ok, err = pcall(C.ReplicateItems)
    st.lastCall = time()
    if not ok then
        self:NoteM1c(st, gap, "Fehler", 0, 0)
        A:Print(L["Scan konnte nicht gestartet werden: "] .. tostring(err))
        return false
    end
    self.running = { t0 = GetTime(), started = time(), gap = gap }
    self:MBegin(self.running)                                -- VM1
    if A.db then A.db.lastScanTime = time() end
    A:Print(L["Schnell-Vollscan gestartet ..."])
    A:Fire("SCAN_STARTED")
    if C_Timer and C_Timer.After then
        local run = self.running
        C_Timer.After(self.TIMEOUT, function()
            if VS.running == run and not run.reading then
                VS:MEnd(run.m, nil, 0)
                VS.running = nil
                VS:NoteM1c(st, gap, "keine Antwort", 0, VS.TIMEOUT)
                A:Print(L["Scan ohne Ergebnis beendet."])
                A:Fire("SCAN_FAILED")
            end
        end)
    end
    return true
end

-- M1c: Abstand zum letzten Aufruf, Antwort, Anzahl, Wartezeit (höchstens 30 Einträge)
function VS:NoteM1c(st, gap, result, n, wait)
    if not st then return end
    st.m1c = st.m1c or {}
    table.insert(st.m1c, string.format("%s;%s;%d;%.1f;%d", gap and tostring(math.floor(gap)) or "-", result, n or 0, wait or 0, time()))
    while #st.m1c > 30 do table.remove(st.m1c, 1) end
    if A.Diag then pcall(A.Diag.Add, A.Diag, "VOLLSCAN", string.format("M1c Abstand %s s · %s · %d Auktionen · Antwort nach %.1f s",
        gap and tostring(math.floor(gap)) or "-", result, n or 0, wait or 0)) end
end

-- ------------------------------------------------------------
-- Lesen in Portionen (M1d: kein Frame über 8 ms)
-- ------------------------------------------------------------
local Clock = debugprofilestop

-- ------------------------------------------------------------
-- VM1–VM3 (offen 10.11.): Zeitmessung je Schritt. Am Vollscan selbst ändert sich nichts ausser dieser Messung.
-- Je Schritt: Dauer (ms, Uhrzeit vom ersten bis letzten Aufruf) und längster Frame. Der längste Frame eines Schritts
-- ist die längste Lücke zwischen zwei OnUpdate-Aufrufen, in der dieser Schritt gearbeitet hat - das ist die echte
-- Hängezeit. Dazu Speicher vorher/nachher und erkannte Speicherbereinigungen (GC: "count" fällt um mehr als 1 MB).
-- ------------------------------------------------------------
VS.MEASURE_TAIL = 3           -- Sekunden nach dem Ende weiter Lücken messen (Nachlauf: Listen, Zwischenspeicher)
VS.MEASURE_HIST = 5           -- so viele Messungen bleiben gespeichert
VS.HANG_MS = 1000             -- Schritt oder Lücke darüber = FEHLER (VM2)
local function GCKB() local ok, v = pcall(collectgarbage, "count"); return (ok and tonumber(v)) or 0 end
local function Now() return Clock and Clock() or (GetTime() * 1000) end
VS.GCKB = GCKB

-- VF1d: AHSentinels eigener Speicher (UpdateAddOnMemoryUsage ist teuer: nur vor und nach dem Vollscan)
-- TB168-1 (Testbericht 0.65.168: "Nachlauf längster Frame 829 ms" bei jedem Scan): UpdateAddOnMemoryUsage misst ALLE Addons und
-- lief beim Ende des Scans ZWEIMAL im selben Bild (MEnd + vsLastMeasure) - mit grossen Gespeicherten Daten mehrere 100 ms.
-- Jetzt nur noch, wenn ausdrücklich gemessen wird (VS.MEASURE_OWN, z. B. "/ahs testroutine tempo"); sonst ganzer Lua-Speicher
-- (collectgarbage, billig).
VS.MEASURE_OWN = false
function VS:AddonKB()
    local upd, get = _G.UpdateAddOnMemoryUsage, _G.GetAddOnMemoryUsage or (_G.C_AddOns and _G.C_AddOns.GetAddOnMemoryUsage)
    if not (upd and get) then return nil end
    pcall(upd)
    local ok, kb = pcall(get, "AHSentinel")
    return ok and tonumber(kb) or nil
end
local function FPS() local f = _G.GetFramerate; if f then local ok, v = pcall(f); if ok then return tonumber(v) end end return nil end
function VS:MBegin(run, t)
    local m = { started = time(), steps = {}, order = {}, memBefore = GCKB(), gapMax = 0, gapStep = nil, gcN = 0, work = {},
        addonBefore = (not t and self.MEASURE_OWN) and self:AddonKB() or nil, fps0 = FPS(), fps = {}, slow33 = 0, ticks = 0 }
    m.lastKB = m.memBefore
    run.m = m
    self.curMeasure = m
    self:MSet(m, "Warten auf Server", t)
    return m
end

function VS:MStepObj(m, name)
    local s = m.steps[name]
    if not s then s = { ms = 0, max = 0, n = 0 }; m.steps[name] = s; m.order[#m.order + 1] = name end
    return s
end

-- Schritt beginnt: die Zeit seit der letzten Marke gehört dem bisherigen Schritt (t: nur für Tests)
function VS:MSet(m, name, t)
    if not m then return end
    t = t or Now()
    if m.step then m.work[m.step] = (m.work[m.step] or 0) + (t - (m.markT or t)) end
    m.step, m.markT = name, t
    self:MStepObj(m, name)
end

-- Dauer eines Schritts hinzufügen; frameMs = in EINEM Stück ohne Pause gelaufen (zählt auch als längster Frame)
function VS:MAdd(m, name, ms, frameMs)
    if not m then return end
    local s = self:MStepObj(m, name)
    s.ms = s.ms + (ms or 0)
    s.n = s.n + 1
    if frameMs and frameMs > s.max then s.max = frameMs end
end

-- je OnUpdate: Zeit je Schritt in diesem Frame -> längster Frame je Schritt; die Lücke zwischen zwei Frames gehört dem
-- Schritt mit dem grössten Anteil (Warten auf Server nur, wenn sonst keiner gearbeitet hat)
function VS:MTick(m, t)
    if m.step then m.work[m.step] = (m.work[m.step] or 0) + (t - (m.markT or t)) end
    m.markT = t
    local last = m.lastT
    m.lastT = t
    local kb = GCKB()
    local gcHere = m.lastKB and kb < m.lastKB - 1024
    if gcHere then m.gcN = m.gcN + 1 end
    m.lastKB = kb
    if m.memMax == nil or kb > m.memMax then m.memMax = kb end
    if last then
        local g = t - last
        local top, topW
        for name, w in pairs(m.work) do
            if w > self:MStepObj(m, name).max then m.steps[name].max = w end
            local busy = name ~= "Warten auf Server"
            local topBusy = top ~= nil and top ~= "Warten auf Server"
            if top == nil or (busy and (not topBusy or w > topW)) or (not busy and not topBusy and w > topW) then top, topW = name, w end
        end
        if g > m.gapMax then
            m.gapMax = g; m.gapStep = top or m.step
            -- TB125-1: Ursache der Lücke festhalten - Speicherbereinigung in diesem Bild? Hintergrund-Aufgabe (welche, wie lange,
            -- längster Schritt bis Datei:Zeile)? Sonst: Ereignis/anderes Addon ausserhalb der Aufgaben.
            local lf = A.lastJobFrame
            local recent = lf and lf.t and GetTime() - lf.t < 0.5
            m.gapWhy = string.format("Speicherbereinigung %s · Aufgaben %s", gcHere and "ja" or "nein",
                recent and string.format("%.0f ms (%s, %d Schritte%s)", lf.d or 0, tostring(lf.job), lf.n or 0,
                    lf.at and string.format(", längster %.0f ms bis %s", lf.ms or 0, tostring(lf.at)) or "") or "keine")
        end
        -- VF1e: Bilder/s je Schritt (Mittel, Minimum) und Anteil der Frames über 33 ms
        m.ticks = (m.ticks or 0) + 1
        if g > 33 then m.slow33 = (m.slow33 or 0) + 1 end
        local fps = FPS()
        local name = top or m.step
        if fps and name then
            m.fps = m.fps or {}
            local f = m.fps[name] or { sum = 0, n = 0, min = fps }
            f.sum, f.n = f.sum + fps, f.n + 1
            if fps < f.min then f.min = fps end
            m.fps[name] = f
        end
    end
    for k in pairs(m.work) do m.work[k] = nil end
end

function VS:MEnd(m, r, nItems)
    if not m or m.ended then return end
    m.ended = true
    m.memAfter = GCKB()
    if m.addonBefore then m.addonAfter = self:AddonKB() end
    m.auctions = r and r.n or 0
    m.valid = r and r.count or 0
    m.items = nItems or 0
    m.tailUntil = GetTime() + self.MEASURE_TAIL
    self:MSet(m, "Nachlauf")
    self.lastMeasure = m
    -- TB118-4: Kurzfassung überlebt den Reload (für "/ahs testroutine tempo"), klein und ohne Namen
    if A.db and not A:InTestRoutine() then          -- TB138b-2: nicht in der Testroutine
        A.db.vsLastMeasure = { t = time(), memBefore = m.memBefore, memAfter = m.memAfter, memMax = m.memMax, gcN = m.gcN,
            gapMax = m.gapMax, own = m.addonAfter, ownBefore = m.addonBefore }
    end
end

-- Abschluss nach dem Nachlauf: Protokoll + kleine Geschichte (nur Zahlen, keine Namen)
function VS:MFinal(m)
    self.curMeasure = nil
    m.final = true
    if A.SelfCheck and not A:InTestRoutine() then pcall(A.SelfCheck.OnScan, A.SelfCheck, m) end   -- SK1-h
    local parts = {}
    for _, name in ipairs(m.order) do
        local s = m.steps[name]
        parts[#parts + 1] = string.format("%s %.0f/%.0f", name, s.ms, s.max)
    end
    m.line = string.format("%d Auktionen · %d Items · Lücke %.0f ms (%s%s) · Speicher %.0f->%.0f KB · GC %d · %s",
        m.auctions or 0, m.items or 0, m.gapMax or 0, tostring(m.gapStep or "-"), m.gapWhy and (": " .. m.gapWhy) or "", m.memBefore or 0, m.memAfter or 0, m.gcN or 0,
        table.concat(parts, "; "))
    if A.Diag then pcall(A.Diag.Add, A.Diag, "VOLLSCAN", "Messung " .. m.line) end
    local st = self:Store()
    if st then
        st.vm = st.vm or {}
        -- TB125-5: Zahlen mitspeichern, damit der Tempo-Test die letzte Messung auch nach dem Reload auswerten kann
        table.insert(st.vm, { t = m.started, line = m.line, gap = math.floor(m.gapMax or 0), mb = m.memBefore, ma = m.memAfter, mx = m.memMax, gc = m.gcN,
            own = m.addonAfter, ownB = m.addonBefore })
        while #st.vm > self.MEASURE_HIST do table.remove(st.vm, 1) end
    end
    if A.db and m.memBefore and not A:InTestRoutine() then
        A.db.vsLastMeasure = { t = m.started or time(), memBefore = m.memBefore, memAfter = m.memAfter, memMax = m.memMax, gcN = m.gcN,
            gapMax = m.gapMax, own = m.addonAfter, ownBefore = m.addonBefore }
    end
end

-- VM2: Befunde (Schritt oder Lücke > 1 s) -> Liste { "Schrittname: x ms" }
function VS:MProblems(m)
    local out = {}
    if not m then return out end
    for _, name in ipairs(m.order) do
        local s = m.steps[name]
        if s.max > self.HANG_MS then out[#out + 1] = string.format("%s %.0f ms", name, s.max) end
    end
    if (m.gapMax or 0) > self.HANG_MS and #out == 0 then
        out[#out + 1] = string.format("%s %.0f ms", tostring(m.gapStep or "?"), m.gapMax)
    end
    return out
end

local gapFrame = CreateFrame("Frame")
gapFrame:SetScript("OnUpdate", function()
    local m = VS.curMeasure
    if not m then return end
    VS:MTick(m, Now())
    if m.ended and GetTime() >= (m.tailUntil or 0) then VS:MFinal(m) end
end)
VS.gapFrame = gapFrame
-- VF1 (Befund grosser Test 0.65.88: Frames bis 154 ms, +42 MB Müll, 3 GC-Pausen, "es hat sehr geruckelt"):
--   a) Zeitbudget je Frame einstellbar (Standard 4 ms, Option), Portionen nach gemessener Zeit
--   b) Müll vermeiden: die Tabellen je Item (q/b) bleiben zwischen zwei Vollscans liegen und werden wiederverwendet
--      (VS.pool), Verdichtung mit wiederverwendeten Hilfstabellen
--   c) Neuaufbau nach dem Vollscan in Portionen (A:FireSpread)
VS.BUDGETS = { 2, 4, 6, 8 }
function VS:FrameBudget()
    local v = A.db and A.db.settings and A.db.settings.vsBudget
    return (type(v) == "number" and v >= 1 and v <= 16) and v or 4
end
function VS:CycleBudget()
    local cur, nextV = self:FrameBudget(), self.BUDGETS[1]
    for i, v in ipairs(self.BUDGETS) do if v == cur then nextV = self.BUDGETS[i % #self.BUDGETS + 1] end end
    A.db.settings.vsBudget = nextV
    return nextV
end
VS.pool = VS.pool or {}
function VS:NewRead(C, n)
    local base = 0
    local ok, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, id0 = pcall(C.GetReplicateItemInfo, 0)
    if not (ok and id0) then base = 1 end                 -- 0- oder 1-basiert (je nach Client)
    local items = self.pool
    for _, it in pairs(items) do it.old, it.n = #it.q, 0 end
    return { C = C, n = n, i = 0, base = base, items = items, count = 0, maxMs = 0, frames = 0, ms = 0 }
end
-- nach dem Lesen: Reste des letzten Vollscans abschneiden, leere Items entfernen (damit gilt wieder #it.q = Anzahl)
function VS:TrimRead(r)
    local k = 0
    for id, it in pairs(r.items) do
        if (it.n or 0) == 0 then r.items[id] = nil
        else
            for j = it.n + 1, (it.old or 0) do it.q[j] = nil; it.b[j] = nil end
        end
        it.old = nil
        k = k + 1
        if k % 200 == 0 then A:Pause() end
    end
end

-- liest bis budget ms verbraucht sind; Rückgabe true = fertig. Je Item: q[k] Menge, b[k] = Sofortkauf*8 + Stufe
function VS:ReadPortion(r, budget)
    local C, t0 = r.C, Clock and Clock() or 0
    local kb0 = collectgarbage("count")                      -- RF: Spitze mit Speicherbereinigung? (Messung)
    local items = r.items
    local timeLeft = C.GetReplicateItemTimeLeft
    while r.i < r.n do
        local idx = r.i + r.base
        local ok, _, _, count, _, _, _, _, _, _, buyout, _, _, _, _, _, _, itemID = pcall(C.GetReplicateItemInfo, idx)
        if ok and itemID and type(buyout) == "number" and buyout > 0 then
            local stage = 0
            if timeLeft then
                local okT, s = pcall(timeLeft, idx)
                if okT and type(s) == "number" then stage = s end
            end
            local it = items[itemID]
            if not it then it = { q = {}, b = {}, n = 0, old = 0 }; items[itemID] = it end
            local k = (it.n or 0) + 1
            it.n = k
            it.q[k] = math.max(1, count or 1)
            it.b[k] = buyout * 8 + math.max(0, math.min(7, stage))
            r.count = r.count + 1
        end
        r.i = r.i + 1
        -- W4 (Befund 10.11. 13:50): längster Frame 15 ms bei Prüfung alle 200 Einträge -> alle 25 Einträge prüfen
        if r.i % self.CHECK_EVERY == 0 and Clock and Clock() - t0 >= budget then break end
    end
    local ms = Clock and (Clock() - t0) or 0
    if ms > 3 * budget then
        r.spikes = (r.spikes or 0) + 1
        if collectgarbage("count") < kb0 then r.gcSpikes = (r.gcSpikes or 0) + 1 end
    end
    r.frames = r.frames + 1
    r.ms = r.ms + ms
    if ms > r.maxMs then r.maxMs = ms end
    return r.i >= r.n
end

local evt = CreateFrame("Frame")
pcall(evt.RegisterEvent, evt, "REPLICATE_ITEM_LIST_UPDATE")
evt:SetScript("OnEvent", function()
    local run = VS.running
    if not run or run.reading then return end
    run.reading = true
    local m, e0 = run.m, Now()                                 -- VM1: Zeit bis zum Ereignis, Dauer des Aufrufs
    if m then VS:MAdd(m, "Warten auf Server", (GetTime() - run.t0) * 1000); VS:MSet(m, "Ereignis-Aufruf") end
    local C = VS:API()
    local okN, n = pcall(C.GetNumReplicateItems)
    n = (okN and tonumber(n)) or 0
    local wait = GetTime() - run.t0
    VS:NoteM1c(VS:Store(), run.gap, n > 0 and "neue Liste" or "leer", n, wait)
    if n == 0 then
        VS.running = nil
        if m then VS:MAdd(m, "Ereignis-Aufruf", Now() - e0, Now() - e0); VS:MEnd(m, nil, 0) end
        A:Print(L["Scan ohne Ergebnis beendet."])
        A:Fire("SCAN_FAILED")
        return
    end
    if m then local d = Now() - e0; VS:MAdd(m, "Ereignis-Aufruf", d, d) end
    A:Job("fullscan", function()
        if m then VS:MSet(m, "Einlesen") end
        local r = VS:NewRead(C, n)
        local r0 = Now()
        while not VS:ReadPortion(r, math.max(1, VS:FrameBudget() - 1)) do
            A:Fire("SCAN_PROGRESS", r.i, GetTime() - run.t0)
            A:Pause()
        end
        VS:TrimRead(r)
        if m then VS:MAdd(m, "Einlesen", Now() - r0, r.maxMs) end
        -- RF (TS116: Einlesen bis 152 ms): Ursache der Spitzen messen - Speicherbereinigung oder einzelne teure Aufrufe
        if (r.spikes or 0) > 0 and A.Diag then
            pcall(A.Diag.Add, A.Diag, "VOLLSCAN", string.format("Einlesen: %d Portionen über 3× Budget (%d ms), davon %d mit Speicherbereinigung, längste %.0f ms",
                r.spikes, VS:FrameBudget(), r.gcSpikes or 0, r.maxMs or 0))
        end
        local ok, err = A:PCall(VS.Finish, VS, r, run, time())
        if m then VS:MEnd(m, r, VS.lastItems) end
        -- G f / TB108 S2: sehr grosser Vorrat (> 20 MB geschätzt) nach dem Vollscan freigeben
        if (r.count or 0) * 36 > 20 * 1024 * 1024 then VS.pool = {} end
        if not ok and A.Diag then pcall(A.Diag.Add, A.Diag, "FEHLER", "Vollscan Finish: " .. tostring(err)) end
        VS.running = nil
        if not ok then A:Print(L["Fehler während des Scans: "] .. tostring(err)) end
    end, VS:FrameBudget())
end)

-- ------------------------------------------------------------
-- Verdichten je Item
-- ------------------------------------------------------------
-- it = { q = {...}, b = {...} } -> Zusammenfassung { min, qty, auc, bait, steps = { {Preis, Stück kumuliert}, ... }, st = {s1..s4} }
-- VF1b: Hilfstabellen der Verdichtung werden wiederverwendet (kein Müll je Item)
local scratchOrder, scratchUnit, scratchN, cmpQ = {}, {}, 0, nil
local function CmpOrder(x, y)
    local ux, uy = scratchUnit[x], scratchUnit[y]
    if ux ~= uy then return ux < uy end
    return cmpQ[x] > cmpQ[y]
end
-- NP152-3 (TB138b-3 Rest): reuse = Zusammenfassung desselben Items aus dem letzten Vollscan - Tabellen (auch die Stufen)
-- werden wiederverwendet statt je Scan neu angelegt (vorher ~9 MB Müll je Vollscan bei 6000 Items)
function VS:Digest(itemID, it, reuse)
    local n = #it.q
    local order, unit = scratchOrder, scratchUnit
    for k = 1, n do order[k] = k; unit[k] = math.floor(math.floor(it.b[k] / 8) / it.q[k]) end
    for k = n + 1, scratchN do order[k] = nil; unit[k] = nil end
    scratchN = n
    cmpQ = it.q
    table.sort(order, CmpOrder)
    -- Lockangebote wie bisher (A:MarkBait): führende 1-Stück-Angebote einer Ware, höchstens 5
    local first, bait = 1, 0
    if A:IsCommodityItem(itemID) then
        while first <= n and bait < 5 and it.q[order[first]] == 1 and first < n do first = first + 1; bait = bait + 1 end
    end
    local s = reuse
    if type(s) == "table" and type(s.steps) == "table" and type(s.st) == "table" then
        s.min, s.qty, s.auc, s.bait, s.maxPrice = unit[order[first]], 0, 0, bait, nil
        s.st[1], s.st[2], s.st[3], s.st[4] = 0, 0, 0, 0
    else
        s = { min = unit[order[first]], qty = 0, auc = 0, bait = bait, steps = {}, st = { 0, 0, 0, 0 } }
    end
    local steps, ns = s.steps, 0
    local exact, cum = 0, 0
    local pctI = 1
    for j = first, n do
        local k = order[j]
        local u, q = unit[k], it.q[k]
        s.qty, s.auc = s.qty + q, s.auc + 1
        local stage = it.b[k] % 8
        if stage >= 1 and stage <= 4 then s.st[stage] = s.st[stage] + q end
        cum = cum + q
        local last = ns > 0 and steps[ns] or nil
        if last and last[1] == u then last[2] = cum
        elseif exact < self.LADDER_EXACT then
            exact = exact + 1
            ns = ns + 1
            local st = steps[ns]
            if st then st[1], st[2], st[3] = u, cum, nil else steps[ns] = { u, cum } end
        else
            -- Stufen in % des Mindestpreises: letzte Stufe, deren Grenze den Preis enthält
            while pctI <= #self.LADDER_PCT and u > s.min * self.LADDER_PCT[pctI] do pctI = pctI + 1 end
            local bound = pctI <= #self.LADDER_PCT and math.floor(s.min * self.LADDER_PCT[pctI]) or nil
            if bound then
                if last and last[3] == bound then last[2] = cum
                else
                    ns = ns + 1
                    local st = steps[ns]
                    if st then st[1], st[2], st[3] = bound, cum, bound else steps[ns] = { bound, cum, bound } end
                end
            end
        end
    end
    for k = #steps, ns + 1, -1 do steps[k] = nil end
    return s
end

-- Stück zum Preis price oder billiger (aus der Preisleiter); exakt = Preis liegt innerhalb der genauen Stufen
function VS:LadderQueue(s, price)
    if not (s and price) then return nil end
    local q, exact = 0, false
    for _, step in ipairs(s.steps or {}) do
        if step[1] <= price then q = step[2]; exact = true else break end
    end
    if price >= (s.maxPrice or math.huge) then q = s.qty end
    return q, exact
end

local function EncodeLadder(s, t)
    local parts = {}
    for _, step in ipairs(s.steps) do parts[#parts + 1] = step[1] .. ":" .. step[2] end
    return table.concat({ math.floor((t - 1760000000) / 60), s.min, s.qty, s.auc, s.bait, table.concat(parts, ","), table.concat(s.st, ",") }, ";")
end
function VS:DecodeLadder(str)
    if type(str) ~= "string" then return nil end
    local t, mn, qty, auc, bait, steps, st = str:match("^(%-?%d+);(%d+);(%d+);(%d+);(%d+);([^;]*);([^;]*)$")
    if not t then return nil end
    local s = { t = 1760000000 + tonumber(t) * 60, min = tonumber(mn), qty = tonumber(qty), auc = tonumber(auc), bait = tonumber(bait), steps = {}, st = {} }
    for p, q in steps:gmatch("(%d+):(%d+)") do s.steps[#s.steps + 1] = { tonumber(p), tonumber(q) } end
    for x in st:gmatch("(%d+)") do s.st[#s.st + 1] = tonumber(x) end
    return s
end

-- Preisleiter eines Items (Arbeitsspeicher, sonst gespeichert) und Alter
function VS:Ladder(itemID)
    local m = self.mem and self.mem[itemID]
    if m then return m, time() - (self.memTime or 0) end
    local st = self:Data()
    local s = st and st.ladder and self:DecodeLadder(st.ladder[itemID])
    if s then return s, time() - s.t end
    return nil
end

-- V2: exakte Warteschlange zum Preis (ohne eigene Auktionen); nil, wenn keine frische Preisleiter
function VS:Queue(itemID, price)
    local s, age = self:Ladder(itemID)
    if not s or age > self.QUEUE_AGE then return nil end
    local q = price and self:LadderQueue(s, price) or s.qty
    local own = 0
    local Se = A.Seller
    for _, o in ipairs(Se and Se.owned or {}) do
        if not o.sold and o.itemID == itemID and (not price or (o.unitPrice or 0) <= price) then own = own + (o.qty or 0) end
    end
    return math.max(0, q - own), "vollscan"
end

-- ------------------------------------------------------------
-- V3/V4: welche Items verfolgt und gespeichert werden
-- ------------------------------------------------------------
function VS:TrackedSet(items)
    local set, n = {}, 0
    local function add(id) if type(id) == "number" and not set[id] then set[id] = true; n = n + 1 end end
    local Fc = A.Forecast
    if Fc and Fc.RelevantItems then
        local ok, s = pcall(Fc.RelevantItems, Fc)
        if ok then for id in pairs(s) do add(id) end end
    end
    local lists = A.db and A.db.lists and A.db.lists.items
    for _, l in pairs(lists or {}) do
        for _, e in pairs(l.entries or {}) do if type(e) == "table" then add(e.itemID) end end
    end
    -- die 500 grössten (nach Zahl der Auktionen); NP152-3: Hilfslisten wiederverwendet (keine Tabelle je Item)
    local big, cnt = self.bigIds or {}, self.bigCnt or {}
    self.bigIds, self.bigCnt = big, cnt
    for k in pairs(cnt) do cnt[k] = nil end
    local m = 0
    for id, it in pairs(items or {}) do m = m + 1; big[m] = id; cnt[id] = #it.q end
    for k = #big, m + 1, -1 do big[k] = nil end
    table.sort(big, function(x, y) return cnt[x] > cnt[y] end)
    for i = 1, math.min(self.TOP, m) do add(big[i]) end
    return set, n
end

-- Signaturen eines Items (TS111.1: OHNE Zeichenkette und Tabelle je Auktion - die Speicherbereinigung liess den Vollscan
-- bis 821 ms stocken). Schlüssel als Zahl: key = Sofortkauf * SIGM + Menge; Stufen-Schlüssel key * 8 + Stufe.
-- Rückgabe zwei WIEDERVERWENDETE Tabellen (gelten bis zum nächsten Aufruf): n[key] = Anzahl, s[key*8+Stufe] = Anzahl.
local SIGM = 65536
local SIG_BMAX = 2 ^ 33                      -- Sofortkauf darüber (> ~859'000 g) passt nicht exakt in die Zahl -> ignoriert
local sigN, sigS, sigList, sigOut = {}, {}, {}, {}
local function Wipe(t) for k in pairs(t) do t[k] = nil end end
local function SigKey(q, b) return b * SIGM + math.min(q, SIGM - 1) end
local function Sigs(it)
    Wipe(sigN); Wipe(sigS)
    for k = 1, #it.q do
        local q, b = it.q[k], math.floor(it.b[k] / 8)
        if b < SIG_BMAX then
            local key = SigKey(q, b)
            sigN[key] = (sigN[key] or 0) + 1
            local ks = key * 8 + it.b[k] % 8
            sigS[ks] = (sigS[ks] or 0) + 1
        end
    end
    return sigN, sigS
end
local function KeyParts(ks)
    local key = math.floor(ks / 8)
    local q = key % SIGM
    return q, (key - q) / SIGM, ks % 8
end
local function UnitOf(ks)
    local q, b = KeyParts(ks)
    return b / math.max(1, q)
end
local function CmpUnit(x, y) local ux, uy = UnitOf(x), UnitOf(y); if ux ~= uy then return ux < uy end return x < y end
-- gespeicherte Signaturliste: die SIG_MAX billigsten "Menge:Sofortkauf:Stufe:Anzahl" (Format unverändert)
local function EncodeSigs(_, ss)
    ss = ss or sigS
    local list, n = sigList, 0
    for ks in pairs(ss) do n = n + 1; list[n] = ks end
    for i = n + 1, #list do list[i] = nil end
    table.sort(list, CmpUnit)
    local out = sigOut                                   -- NP152-3: wiederverwendet
    for i = math.min(n, VS.SIG_MAX) + 1, #out do out[i] = nil end
    for i = 1, math.min(n, VS.SIG_MAX) do
        local ks = list[i]
        local q, b, stage = KeyParts(ks)
        out[i] = q .. ":" .. b .. ":" .. stage .. ":" .. ss[ks]
    end
    return table.concat(out, ",")
end
local function DecodeSigs(str)
    local out = {}
    for q, b, s, c in (str or ""):gmatch("(%d+):(%d+):(%d+):(%d+)") do
        out[#out + 1] = { tonumber(q), tonumber(b), tonumber(s), tonumber(c) }
    end
    return out
end
VS.EncodeSigs, VS.DecodeSigs, VS.Sigs, VS.SigKey = EncodeSigs, DecodeSigs, Sigs, SigKey
-- NP152-3: Signaturen in wiederverwendete flache Listen entschlüsseln (keine Tabelle je Signatur und Item)
local dQ, dB, dS, dC, dN = {}, {}, {}, {}, 0
local seenS, countS, levQ, levX, levBS = {}, {}, {}, {}, {}
local function DecodeFlat(str)
    local n = 0
    for q, b, st, c in (str or ""):gmatch("(%d+):(%d+):(%d+):(%d+)") do
        n = n + 1
        dQ[n], dB[n], dS[n], dC[n] = tonumber(q), tonumber(b), tonumber(st), tonumber(c)
    end
    for k = n + 1, dN do dQ[k], dB[k], dS[k], dC[k] = nil, nil, nil, nil end
    dN = n
    return n
end

-- V4: Scan A (gespeichert, Zeit tA) gegen Scan B (vollständig im Speicher). Rückgabe early, expired, new (Stück/Anzahl)
function VS:Compare(prevStr, it, d, itemID)
    local now = Sigs(it)
    local commodity = false
    if itemID and A.IsCommodityItem then
        local okC, c = pcall(A.IsCommodityItem, A, itemID)
        commodity = okC and c and true or false
    end
    local early, expired, gone = 0, 0, {}
    local seenA = seenS
    Wipe(seenA)
    local nA = DecodeFlat(prevStr)                    -- TS111.1: nur einmal entschlüsseln (NP152-3: flach)
    for i = 1, nA do
        local q, b, stage, c = dQ[i], dB[i], dS[i], dC[i]
        local key = SigKey(q, b)
        local have = now[key] or 0
        local used = seenA[key] or 0                 -- dieselbe Signatur mit mehreren Stufen: Bestand nur einmal verteilen
        local left = math.max(0, have - used)
        local g = math.max(0, c - left)
        seenA[key] = used + math.min(c, left)
        if g > 0 then
            local minH = self.STAGE_MIN_H[stage] or 0
            if minH * 3600 > d then early = early + g * q; gone[#gone + 1] = { q, b, g, "early" }
            else expired = expired + g * q; gone[#gone + 1] = { q, b, g, "expired" } end
        end
    end
    -- neu: in B mehr als in A
    local countA = countS
    Wipe(countA)
    for i = 1, nA do local key = SigKey(dQ[i], dB[i]); countA[key] = (countA[key] or 0) + dC[i] end
    local new = 0
    for key, n in pairs(now) do if n > (countA[key] or 0) then new = new + (n - (countA[key] or 0)) end end
    -- Menge in A (gespeicherte Signaturen) und B (alle Auktionen) für die Plausibilitätsgrenze
    local qtyA, qtyB = 0, 0
    for i = 1, nA do qtyA = qtyA + dQ[i] * dC[i] end
    for k = 1, #it.q do qtyB = qtyB + it.q[k] end
    if commodity then
        -- W2: Waren nach Menge je Stückpreis (die Signaturliste "gone" bleibt nur für die Gegenprobe eigener Auktionen)
        early, expired = self:CompareQty(prevStr, it, d, true)
    end
    return early, expired, new, gone, qtyA, qtyB
end

-- W2 (Befund 10.11. 13:50): Waren (stapelbar) - ein Teilkauf ergibt eine neue Signatur (Restmenge), darum je Stückpreis
-- die MENGE vergleichen: weg = max(0, Menge_A − Menge_B) je Preisstufe, nur Stufen bis Mindestpreis_B + QTY_TOL
-- (Käufer kaufen von unten; teurere Stufen ändern sich durch Abbrechen/Neu-Einstellen). Neue Einstellungen zum gleichen
-- Preis rechnen gegen (Menge_B darf steigen). Abgelaufen/vorzeitig nach der Restzeit-Stufe der Menge in A.
VS.QTY_TOL = 0.02
-- decoded = true: die flachen Listen (dQ/dB/dS/dC) enthalten prevStr schon (aus Compare)
function VS:CompareQty(prevStr, it, d, decoded)
    local nA = decoded and dN or DecodeFlat(prevStr)
    Wipe(levQ); Wipe(levX); Wipe(levBS)
    for i = 1, nA do
        local q, b, stage, c = dQ[i], dB[i], dS[i], dC[i]
        local unit = math.floor(b / math.max(1, q))
        levQ[unit] = (levQ[unit] or 0) + q * c
        levX[unit] = (levX[unit] or 0) + (((self.STAGE_MIN_H[stage] or 0) * 3600 <= d) and q * c or 0)
    end
    local levB, minB = levBS, nil
    for k = 1, #it.q do
        local q = it.q[k]
        local unit = math.floor(math.floor(it.b[k] / 8) / math.max(1, q))
        levB[unit] = (levB[unit] or 0) + q
        if not minB or unit < minB then minB = unit end
    end
    local limit = minB and (math.floor(minB * (1 + self.QTY_TOL)) + 1) or math.huge
    local early, expired = 0, 0
    for unit, lvq in pairs(levQ) do
        if unit <= limit then
            local g = math.max(0, lvq - (levB[unit] or 0))
            if g > 0 then
                local x = g * levX[unit] / lvq
                expired = expired + x
                early = early + (g - x)
            end
        end
    end
    return math.floor(early + 0.5), math.floor(expired + 0.5)
end

-- Absatz EWMA je Item: "Rate;Paare;erste Zeit;letzte Zeit;Stück vorzeitig weg;Stück abgelaufen[;offen weg;offen Sek.;unplausibel;alte Rate]"
-- W2: Hochrechnen erst ab MIN_COVER Sekunden Abdeckung (Summe der Paare) - bis dahin sammeln (offen) und Rate leer
-- ("zu kurz"). Plausibilitätsgrenze: beobachtet ≤ PLAUS_FACTOR × Ø-Menge im AH, sonst "unplausibel" (nicht verwendet).
-- Ältere Einträge (vor 0.65.78, aus kurzen Paaren hochgerechnet) behalten ihre Rate nur als "alte Rate".
VS.MIN_COVER = 6 * 3600
VS.PLAUS_FACTOR = 2
function VS:DecodeSold(str)
    if type(str) ~= "string" then return nil end
    local r, n, f, l, q, e, rest = str:match("^([%d%.]*);(%d+);(%d+);(%d+);(%d+);(%d+)(.*)$")
    if not n then return nil end
    local x = { rate = tonumber(r), pairs = tonumber(n), first = tonumber(f), last = tonumber(l), early = tonumber(q), expired = tonumber(e),
        pe = 0, pd = 0, bad = 0 }
    local pe, pd, bad, old = rest:match("^;(%d+);(%d+);(%d+);([%d%.]*)$")
    if pe then
        x.pe, x.pd, x.bad, x.oldRate = tonumber(pe), tonumber(pd), tonumber(bad), tonumber(old)
    else
        x.oldRate, x.rate = x.rate, nil          -- altes Format: Rate aus zu kurzen Paaren nicht mehr verwenden
    end
    return x
end
local function Num(v)
    if not v then return "" end
    return (string.format("%.2f", v):gsub("0+$", ""):gsub("%.$", ""))
end
local function EncodeSold(x)
    return string.format("%s;%d;%d;%d;%d;%d;%d;%d;%d;%s", Num(x.rate), x.pairs, x.first, x.last, x.early, x.expired,
        math.floor(x.pe or 0), math.floor(x.pd or 0), x.bad or 0, Num(x.oldRate))
end
VS.EncodeSold = EncodeSold
function VS:UpdateSold(st, itemID, early, expired, d, now, avgQty)
    now = math.floor(now)
    local x = self:DecodeSold(st.sold[itemID]) or { rate = nil, pairs = 0, first = now - d, last = now, early = 0, expired = 0, pe = 0, pd = 0, bad = 0 }
    x.pairs, x.last = x.pairs + 1, now
    x.early, x.expired = x.early + early, x.expired + expired
    x.pe, x.pd = (x.pe or 0) + early, (x.pd or 0) + d
    if x.pd >= self.MIN_COVER then
        local obs = x.pe / (x.pd / 86400)
        if avgQty and avgQty > 0 and obs > self.PLAUS_FACTOR * avgQty then
            x.bad = (x.bad or 0) + 1
            if A.Diag then pcall(A.Diag.Add, A.Diag, "VOLLSCAN", string.format("Absatz unplausibel: Item %d · %.0f/Tag bei Ø %d im AH (%.1f Std.)",
                itemID, obs, math.floor(avgQty), x.pd / 3600)) end
        else
            local alpha = 1 - 0.5 ^ ((x.pd / 86400) / self.HALF_DAYS)
            x.rate = x.rate and (x.rate + alpha * (obs - x.rate)) or obs
        end
        x.pe, x.pd = 0, 0
    end
    st.sold[itemID] = EncodeSold(x)
    return x
end

-- Abbruch-Faktor aus den eigenen Auktionen (Gegenprobe T-VS6): Anteil der eigenen "vorzeitig weg", die verkauft wurden
function VS:CancelFactor()
    local st = self:Data()
    local o = st and st.own
    if not o or (o.gone or 0) < 5 then return 1, o and o.gone or 0, o and o.sold or 0 end
    return math.max(0.2, math.min(1, (o.sold or 0) / o.gone)), o.gone, o.sold
end

-- V5: gemessener Absatz je Tag (ab MEASURED_DAYS Tagen und MEASURED_PAIRS Scan-Paaren), mit Abbruch-Faktor
function VS:MeasuredRate(itemID)
    local st = self:Data()
    local x = st and st.sold and self:DecodeSold(st.sold[itemID])
    if not x or not x.rate or x.pairs < self.MEASURED_PAIRS or (x.last - x.first) < self.MEASURED_DAYS * 86400 then return nil, x end
    local f = self:CancelFactor()
    local rate = x.rate * f
    -- K2 (Befund 10.11. 16:10): gemessen nur, wenn plausibel (≤ 2 × Ø-Menge, ≤ 25 % des aktuellen Angebots je Std.);
    -- sonst Rückfall auf die Schätzung, Protokoll ABSATZ-UNPLAUSIBEL
    local okL, l = pcall(A.GetLiquidity, A, itemID)
    local _, curQty = A:GetCurrent(itemID)
    local cap = A:PlausibleRate(okL and l and l.avgQty or nil, curQty)
    if cap and rate > cap then
        A:NoteImplausible(itemID, rate, "gemessen")
        return nil, x
    end
    return rate, x, math.floor((x.last - x.first) / 86400 + 0.5)
end

-- ------------------------------------------------------------
-- eigene Auktionen: M1b (Stufe -> Restzeit) und Gegenprobe
-- ------------------------------------------------------------
-- laufende eigene Einstellungen aus dem Prognose-Journal: { [itemID] = { {q, buyout, t, d}, ... } }
function VS:OwnRunning(now)
    local out = {}
    local Fc = A.Forecast
    local f = Fc and Fc:Data()
    for _, s in ipairs(f and f.list or {}) do
        if s:sub(1, 1) == "P" then
            local e = Fc:Decode(s)
            if e and e.id and (e.t or 0) <= now and now <= (e.t or 0) + (e.d or 24) * 3600 and e.r ~= "c" then
                local per = math.max(1, math.floor((e.q or 1) / math.max(1, e.a or 1)))
                out[e.id] = out[e.id] or {}
                table.insert(out[e.id], { q = per, b = (e.pr or 0) * per, t = e.t, d = e.d or 24 })
            end
        end
    end
    return out
end

function VS:NoteM1b(st, stage, hoursLeft)
    st.m1b = st.m1b or {}
    local key = tostring(stage)
    local x = st.m1b[key]
    local lo, hi, n = 999, 0, 0
    if x then lo, hi, n = x:match("^([%d%.]+);([%d%.]+);(%d+)$"); lo, hi, n = tonumber(lo), tonumber(hi), tonumber(n) end
    lo, hi, n = math.min(lo, hoursLeft), math.max(hi, hoursLeft), n + 1
    st.m1b[key] = string.format("%.1f;%.1f;%d", lo, hi, n)
end

-- ------------------------------------------------------------
-- Abschluss: verdichten, Preise wie beim bisherigen Scan, Verfolgung
-- ------------------------------------------------------------
-- PD5a: gültig, wenn es Items gibt und (falls bekannt) mindestens 30 % des letzten gültigen Vollscans
VS.VALID_SHARE = 0.30
function VS:ValidResult(nItems, ref)
    if (nItems or 0) <= 0 then return false end
    if ref and ref >= 100 and nItems < ref * self.VALID_SHARE then return false end
    return true
end
function VS:Finish(r, run, now)
    now = math.floor(now or time())
    local st = self:Store()
    local best, mem = {}, {}
    local nItems = 0
    local m = run and run.m                                    -- VM1
    if m then self:MSet(m, "Verdichtung") end
    local dMs, dMax = 0, 0
    local nCom = 0
    local spare = self.memSpare or {}
    self.memSpare = nil
    for itemID, it in pairs(r.items) do
        local d0 = Now()
        if A.IsCommodityItem and A:IsCommodityItem(itemID) then nCom = (nCom or 0) + 1 end   -- MP1: Waren im Vollscan?
        -- NP152-3: Tabellen aus dem VORLETZTEN Scan wiederverwenden (der letzte bleibt bis zum Ende gültig; ein
        -- unvollständiger Scan ändert so nichts Sichtbares - PD5a)
        local s = self:Digest(itemID, it, spare[itemID])
        local dd = Now() - d0
        dMs = dMs + dd
        if dd > dMax then dMax = dd end
        if s.qty > 0 then
            s.maxPrice = nil
            mem[itemID] = s
            -- TT1317: Menge auf der günstigsten Stufe (Lockangebote sind schon aussortiert) - eine echte Leiter ist kein Lockangebot
            best[itemID] = { price = s.min, qty = s.qty, minQty = s.steps[1] and s.steps[1][2] or 0 }
            nItems = nItems + 1
        end
        A:Pause()
    end
    if m then self:MAdd(m, "Verdichtung", dMs, dMax) end
    -- PD5a: leerer/unvollständiger Vollscan (Server antwortet mit fast nichts) ändert NICHTS: keine Markt-, Absatz-,
    -- Rhythmus- oder Verfolgungsdaten, zählt nicht als letzter gültiger Vollscan
    -- PD5c: Referenz altert (älter als 24 Std. gilt nicht mehr); zwei unvollständige hintereinander mit ähnlicher Zahl
    -- (± 20 %) = der Markt ist wirklich kleiner -> annehmen. Grund ins Protokoll VOLLSCAN.
    local ref = st and st.lastGoodItems
    local why
    if ref and st.lastGood and now - st.lastGood > 24 * 3600 then ref, why = nil, "Referenz älter als 24 Std." end
    local valid = self:ValidResult(nItems, ref)
    if not valid and ref and nItems > 0 then
        local prev = st.lowItems
        if prev and math.abs(nItems - prev) <= prev * 0.2 then valid, why = true, string.format("zweimal ähnlich wenig (%d/%d) – Markt kleiner", prev, nItems)
        else st.lowItems = nItems end
    end
    if valid and why and A.Diag then pcall(A.Diag.Add, A.Diag, "VOLLSCAN", string.format("%d Items angenommen: %s", nItems, why)) end
    if not valid then
        if A.Diag then pcall(A.Diag.Add, A.Diag, "VOLLSCAN", string.format("unvollständig: %d Items (letzter gültiger %s) – nichts übernommen", nItems, tostring(ref or "-"))) end
        A:Print(L["Vollscan ohne Antwort – nichts übernommen."])
        self.lastItems = nItems
        A:Fire("SCAN_FAILED")
        return false
    end
    if st then st.lastGood, st.lastGoodItems, st.lowItems = now, nItems, nil end
    self.memSpare = self.mem
    self.mem, self.memTime = mem, now
    -- M1d
    local m1d = string.format("%d;%d;%.0f;%.1f;%d;%d", r.n, r.count, r.ms, r.maxMs, r.frames, nItems)
    if st then
        st.m1d = st.m1d or {}
        table.insert(st.m1d, m1d)
        while #st.m1d > 10 do table.remove(st.m1d, 1) end
    end
    if A.Diag then pcall(A.Diag.Add, A.Diag, "VOLLSCAN", string.format("M1d %d Auktionen gelesen (%d gültig) · %.0f ms in %d Portionen · längster Frame %.1f ms · %d Items",
        r.n, r.count, r.ms, r.frames, r.maxMs, nItems)) end
    -- V4/V3 nur mit echtem Speicher
    if st then
        if m then self:MSet(m, "Verfolgung V4") end
        local t0 = Now()
        self:Track(st, r.items, mem, now)
        if m then self:MAdd(m, "Verfolgung V4", Now() - t0) end
    end
    -- Preisverlauf wie beim bisherigen Scan (A:ProcessBest); danach Neuaufbau Markt/Zwischenspeicher (SCAN_FINISHED)
    if A.ProcessBest then
        if m then self:MSet(m, "Preisverlauf+Neuaufbau") end
        local t0 = Now()
        A:ProcessBest(best, r.count, run and (GetTime() - run.t0) or 0, { replicate = true, done = function() VS.running = nil end })
        if m then self:MAdd(m, "Preisverlauf+Neuaufbau", Now() - t0) end
    end
    self.lastItems = nItems
    self.lastCommodities = nCom
    return nItems
end

function VS:Track(st, items, mem, now)
    now = math.floor(now)
    local set = self:TrackedSet(items)
    local own = self:OwnRunning(now)
    st.own = st.own or { gone = 0, sold = 0, checks = {} }
    local pairsN = 0
    for itemID in pairs(set) do
        local it = items[itemID] or { q = {}, b = {} }
        local prev = st.sigs[itemID]
        local tA, prevStr
        if type(prev) == "string" then
            local t, rest = prev:match("^(%d+)[%.%d]*|(.*)$")
            tA, prevStr = tonumber(t), rest
        end
        if tA and prevStr then
            local d = now - tA
            if d > 0 and d <= self.PAIR_MAX then
                local early, expired, _, gone, qtyA, qtyB = self:Compare(prevStr, it, d, itemID)
                self:UpdateSold(st, itemID, early, expired, d, now, ((qtyA or 0) + (qtyB or 0)) / 2)
                pairsN = pairsN + 1
                -- Gegenprobe: eigene Auktionen in A, die vorzeitig weg sind -> später mit den Verkaufsrechnungen vergleichen
                for _, g in ipairs(gone) do
                    if g[4] == "early" then
                        for _, o in ipairs(own[itemID] or {}) do
                            if o.q == g[1] and math.abs(o.b - g[2]) <= 1 then
                                table.insert(st.own.checks, string.format("%d;%d;%d;%d", itemID, g[1], tA, now))
                                break
                            end
                        end
                    end
                end
            end
        end
        if #it.q > 0 then
            local _, ss = Sigs(it)
            st.sigs[itemID] = now .. "|" .. EncodeSigs(nil, ss)
            if mem[itemID] then st.ladder[itemID] = EncodeLadder(mem[itemID], now) end
            -- M1b: eigene laufende Auktionen in der Liste finden (Signatur) -> Stufe gegen echte Restzeit
            for _, o in ipairs(own[itemID] or {}) do
                for k = 1, #it.q do
                    if it.q[k] == o.q and math.abs(math.floor(it.b[k] / 8) - o.b) <= 1 then
                        self:NoteM1b(st, it.b[k] % 8, math.max(0, (o.t + o.d * 3600 - now) / 3600))
                        break
                    end
                end
            end
        else
            st.sigs[itemID] = now .. "|"
        end
        A:Pause()
    end
    -- nicht mehr verfolgte Items aus dem Speicher (V3)
    for id in pairs(st.sigs) do if not set[id] then st.sigs[id] = nil end end
    for id in pairs(st.ladder) do if not set[id] then st.ladder[id] = nil end end
    while #st.own.checks > 200 do table.remove(st.own.checks, 1) end
    self:ResolveOwnChecks(st)
    return pairsN
end

-- Gegenprobe: eigene "vorzeitig weg" mit Verkaufsrechnung zwischen tA und tB (+ 1 Std. Post) = verkauft
function VS:LedgerEntries() return A.db and A.db.ledger and A.db.ledger.entries or {} end     -- eigene Funktion (Seam)
function VS:ResolveOwnChecks(st)
    local Le = A.Ledger
    local led = self:LedgerEntries()
    local keep = {}
    for _, c in ipairs(st.own.checks or {}) do
        local id, q, tA, tB = c:match("^(%d+);(%d+);(%d+);(%d+)$")
        id, q, tA, tB = tonumber(id), tonumber(q), tonumber(tA), tonumber(tB)
        if id then
            local sold = false
            for i = #led, 1, -1 do
                local e = led[i]
                if e.kind == "sale" and e.itemID == id then
                    local t = (Le and Le.SaleTime) and Le:SaleTime(e) or e.t
                    if t >= tA - 300 and t <= tB + 300 then sold = true; break end
                end
            end
            if sold then st.own.gone, st.own.sold = (st.own.gone or 0) + 1, (st.own.sold or 0) + 1
            elseif time() - tB > 3 * 3600 then st.own.gone = (st.own.gone or 0) + 1      -- 3 Std. ohne Rechnung: abgebrochen
            else keep[#keep + 1] = c end
        end
    end
    st.own.checks = keep
end
A:On("LEDGER_CHANGED", function()
    local st = VS:Store()
    if st and st.own and st.own.checks and #st.own.checks > 0 then pcall(VS.ResolveOwnChecks, VS, st) end
end)

-- ------------------------------------------------------------
-- Bericht "Vollscan" (Teil B, echte Daten, nur lesen)
-- ------------------------------------------------------------
function VS:Report()
    local st = self:Data() or {}
    local out, fields = { "Vollscan (echte Daten):" }, {}
    out[#out + 1] = string.format("  Verfügbar %s · Option %s · Altes Auktionshaus %s", self:Available() and "ja" or "nein",
        (A.db and A.db.settings and A.db.settings.fastScan) and "an" or "aus", A.AH_LEGACY and "ja" or "nein")
    local last = st.m1d and st.m1d[#st.m1d]
    if last then
        local n, c, ms, maxMs, frames, items = last:match("^(%d+);(%d+);([%d%.]+);([%d%.]+);(%d+);(%d+)$")
        out[#out + 1] = string.format("  Letzter Vollscan: %s Auktionen (%s gültig), %s Items · M1d %s ms in %s Portionen, längster Frame %s ms (Ziel ≤ 8)",
            n, c, items, ms, frames, maxMs)
        fields.vollscan_m1d = last
    else
        out[#out + 1] = "  Noch kein Vollscan (Option \"Schnell-Vollscan\" oder /ahs vollscan am offenen Auktionshaus)"
        fields.vollscan_m1d = "-"
    end
    local m1c = {}
    for _, e in ipairs(st.m1c or {}) do
        local gap, res, n, wait = e:match("^([^;]*);([^;]*);(%d+);([%d%.]+)")
        m1c[#m1c + 1] = string.format("%s→%s (%s, %ss)", gap == "-" and "erster" or (math.floor((tonumber(gap) or 0) / 60) .. " Min."), res or "?", n or "?", wait or "?")
    end
    out[#out + 1] = "  M1c Drosselung: " .. (#m1c > 0 and table.concat(m1c, " · ", math.max(1, #m1c - 7)) or "noch nicht gemessen")
    fields.vollscan_m1c = (#m1c > 0 and table.concat(m1c, " | ") or "-"):sub(1, 400)
    local m1b = {}
    for s = 1, 4 do
        local x = st.m1b and st.m1b[tostring(s)]
        if x then
            local lo, hi, n = x:match("^([%d%.]+);([%d%.]+);(%d+)$")
            m1b[#m1b + 1] = string.format("Stufe %d: %s–%s Std. (%s)", s, lo, hi, n)
        end
    end
    out[#out + 1] = "  M1b Restzeit-Stufen (eigene Auktionen): " .. (#m1b > 0 and table.concat(m1b, " · ") or "noch nicht gemessen (angenommen: Blizzard 0 / 0,5 / 2 / 12 Std.)")
    fields.vollscan_m1b = #m1b > 0 and table.concat(m1b, " | ") or "-"
    -- gemessener Absatz
    local nSold, nMeasured = 0, 0
    for id in pairs(st.sold or {}) do
        nSold = nSold + 1
        if self:MeasuredRate(id) then nMeasured = nMeasured + 1 end
    end
    local f, gone, sold = self:CancelFactor()
    out[#out + 1] = string.format("  Absatz gemessen: %d Items verfolgt, %d mit ≥ %d Tagen · Abbruch-Faktor %s (eigene vorzeitig weg %d, davon verkauft %d)",
        nSold, nMeasured, self.MEASURED_DAYS, gone >= 5 and string.format("%.2f", f) or "noch nicht messbar", gone, sold)
    fields.vollscan_absatz = string.format("%d/%d", nMeasured, nSold)
    fields.vollscan_abbruch = gone >= 5 and string.format("%.2f (%d/%d)", f, sold, gone) or string.format("- (%d)", gone)
    -- Vergleich gemessen vs. alte Schätzung, die 20 meistgehandelten Items
    local led = A.db and A.db.ledger and A.db.ledger.entries or {}
    local cnt = {}
    for _, e in ipairs(led) do if e.itemID and (e.kind == "sale" or e.kind == "buy" or e.kind == "deposit") then cnt[e.itemID] = (cnt[e.itemID] or 0) + 1 end end
    local top = {}
    for id, n in pairs(cnt) do top[#top + 1] = { id, n } end
    table.sort(top, function(x, y) return x[2] > y[2] end)
    local cmp = {}
    for i = 1, math.min(20, #top) do
        local id = top[i][1]
        local m, x = self:MeasuredRate(id)
        if x then
            local okL, l = pcall(A.GetLiquidity, A, id)
            local old = okL and l and l.estimate          -- TS111.2: unabhängige Schätzung
            local meas
            if x.rate then meas = string.format("%.1f", x.rate) .. (m and "" or " (zu kurz)")
            else meas = string.format("– (zu kurz: %.1f Std. von %d)", (x.pd or 0) / 3600, self.MIN_COVER / 3600) end
            if (x.bad or 0) > 0 then meas = meas .. string.format(" · %d× unplausibel", x.bad) end
            cmp[#cmp + 1] = string.format("%d: gemessen %s · geschätzt %s", id, meas, old and string.format("%.1f", old) or "-")
        end
    end
    out[#out + 1] = "  Vergleich (20 meistgehandelte): " .. (#cmp > 0 and table.concat(cmp, " | ") or "noch keine Messung")
    -- VM2: Vollscan-Messung (je Schritt Dauer/längster Frame in ms, längste Lücke, Auktionen/Items, Speicher; ohne Namen)
    local vl, vf = self:MeasureLines(self.lastMeasure)
    for _, l in ipairs(vl) do out[#out + 1] = l end
    for k, v in pairs(vf) do fields[k] = v end
    return out, fields
end

-- VM2: Zeilen und Exportfelder der letzten Messung (Sitzung) bzw. der gespeicherten Geschichte
function VS:MeasureLines(m)
    local out, fields = {}, {}
    if m and m.order then
        out[#out + 1] = "Vollscan-Messung:"
        local parts = {}
        for _, name in ipairs(m.order) do
            local s = m.steps[name]
            out[#out + 1] = string.format("  %s: %.0f ms, längster Frame %.0f ms%s", name, s.ms, s.max, s.max > self.HANG_MS and "  FEHLER > 1 s" or "")
            parts[#parts + 1] = string.format("%s %.0f/%.0f", name, s.ms, s.max)
        end
        out[#out + 1] = string.format("  längste Lücke zwischen zwei Frames: %.0f ms (%s)%s", m.gapMax or 0, tostring(m.gapStep or "-"),
            (m.gapMax or 0) > self.HANG_MS and "  FEHLER > 1 s" or "")
        -- VF1e: Bilder/s je Schritt
        local fp = {}
        for _, name in ipairs(m.order) do
            local f = m.fps and m.fps[name]
            if f and f.n > 0 then fp[#fp + 1] = string.format("%s Ø %.0f / min %.0f", name, f.sum / f.n, f.min) end
        end
        out[#out + 1] = string.format("  Bilder/s vorher %s · %s · Frames über 33 ms: %d von %d (Budget je Frame %d ms)",
            m.fps0 and string.format("%.0f", m.fps0) or "?", #fp > 0 and table.concat(fp, " · ") or "keine Messung", m.slow33 or 0, m.ticks or 0, self:FrameBudget())
        if m.addonBefore then
            out[#out + 1] = string.format("  Speicher AHSentinel: %.0f -> %.0f KB (ganzer Lua-Speicher %.0f -> %.0f KB)", m.addonBefore, m.addonAfter or m.addonBefore,
                m.memBefore or 0, m.memAfter or 0)
        end
        fields.vollscan_fps = (#fp > 0 and table.concat(fp, " | ") or "-"):sub(1, 400)
        fields.vollscan_ueber33 = string.format("%d/%d", m.slow33 or 0, m.ticks or 0)
        fields.vollscan_addon_kb = m.addonBefore and string.format("%.0f->%.0f", m.addonBefore, m.addonAfter or m.addonBefore) or "-"
        out[#out + 1] = string.format("  %d Auktionen (%d gültig) · %d Items · Speicher %.0f -> %.0f KB (höchstens %.0f) · Speicherbereinigungen %d%s",
            m.auctions or 0, m.valid or 0, m.items or 0, m.memBefore or 0, m.memAfter or m.memBefore or 0, m.memMax or 0, m.gcN or 0,
            m.final and "" or " · Nachlauf läuft noch")
        fields.vollscan_messung = table.concat(parts, " | "):sub(1, 600)
        fields.vollscan_luecke = string.format("%.0f ms (%s)%s", m.gapMax or 0, tostring(m.gapStep or "-"), m.gapWhy and (" · " .. m.gapWhy) or "")
        fields.vollscan_speicher = string.format("%.0f->%.0f KB, GC %d", m.memBefore or 0, m.memAfter or m.memBefore or 0, m.gcN or 0)
        local bad = self:MProblems(m)
        fields.vollscan_haenger = #bad > 0 and table.concat(bad, " | ") or "keiner > 1 s"
    else
        local st = self:Store()
        local h = st and st.vm
        local last = h and h[#h]
        out[#out + 1] = "Vollscan-Messung: " .. (last and ("letzte gespeichert: " .. tostring(last.line)) or "noch keine (Teil server mit offenem Auktionshaus)")
        fields.vollscan_messung = last and tostring(last.line):sub(1, 600) or "-"
    end
    return out, fields
end
