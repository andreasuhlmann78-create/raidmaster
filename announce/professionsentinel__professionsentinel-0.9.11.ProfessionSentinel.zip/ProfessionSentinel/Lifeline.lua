local _, ns = ...
local L = ns.L

-- "Lebenslinie": a thin line under every recipe (orange -> yellow -> green -> grey) with a marker
-- at your current skill and a hint how many crafts it takes until the next colour.
-- Uses the skill thresholds of the running game version (WoW Forever turns many recipes grey sooner).

local LL = {}
ns.Lifeline = LL

local COL = {
    orange = { 1.00, 0.50, 0.25 }, yellow = { 1.00, 0.82, 0.25 },
    green = { 0.25, 0.75, 0.25 }, grey = { 0.50, 0.50, 0.50 }, red = { 1.00, 0.25, 0.25 },
}
local HEX = { orange = "ff8040", yellow = "ffd23f", green = "40c040", grey = "a0a0a0", red = "ff4040" }
LL.HEX = HEX

---------------------------------------------------------------------------
-- Maths
---------------------------------------------------------------------------
-- Skill-up chance per craft (Classic rule): orange 100 %, from yellow on it falls linearly
-- to 0 % at grey: p = (grey - skill) / (grey - yellow).
function LL.Chance(r, skill)
    if skill < r.yellow then return 1 end
    if skill >= r.grey or r.grey <= r.yellow then return 0 end
    return (r.grey - skill) / (r.grey - r.yellow)
end

-- Expected number of crafts to raise the skill from `from` to `to` with this recipe (nil = impossible).
function LL.ExpectedCrafts(r, from, to)
    if to <= from then return 0 end
    local su = r.skillUps or 1
    local n, k, guard = 0, from, 0
    while k < to do
        local p = LL.Chance(r, k)
        if p <= 0 then return nil end
        n = n + 1 / p
        k = k + su
        guard = guard + 1
        if guard > 1000 then return nil end
    end
    return n
end

local function round(x) return math.floor(x + 0.5) end

-- Returns a table describing the recipe for the given skill, or nil when no thresholds are known.
-- { state = "red"|"orange"|"yellow"|"green"|"grey", target = colour name, crafts = n, exact = bool,
--   text = short hint, toYellow, toGreen, toGrey (expected crafts, nil if not applicable) }
function LL.Calc(r, rank)
    if not r or not rank or (r.yellow or 0) <= 0 or (r.grey or 0) <= 0 then return nil end
    local res = {}
    local req = (r.req or 0) > 1 and r.req or nil
    if rank < r.yellow then res.state = "orange"
    elseif rank < r.green then res.state = "yellow"
    elseif rank < r.grey then res.state = "green"
    else res.state = "grey" end
    if req and rank < req then res.state = "red" end

    if rank < r.yellow then res.toYellow = LL.ExpectedCrafts(r, rank, r.yellow) end
    if rank < r.green and r.green > r.yellow then res.toGreen = LL.ExpectedCrafts(r, rank, r.green) end
    if rank < r.grey then res.toGrey = LL.ExpectedCrafts(r, rank, r.grey) end

    if res.state == "red" then
        res.text = string.format(L.LL_FROM, req)
    elseif res.state == "grey" then
        res.text = L.LL_ISGREY
    elseif res.state == "orange" then
        -- orange gives a point every time: exact number
        if r.yellow >= r.grey then
            res.target, res.crafts = "grey", math.ceil((r.grey - rank) / (r.skillUps or 1))
        else
            res.target, res.crafts = "yellow", math.ceil((r.yellow - rank) / (r.skillUps or 1))
        end
        res.exact = true
    elseif res.state == "yellow" then
        if r.green >= r.grey then
            res.target, res.crafts = "grey", res.toGrey and round(res.toGrey)
        else
            res.target, res.crafts = "green", res.toGreen and round(res.toGreen)
        end
    else
        res.target, res.crafts = "grey", res.toGrey and round(res.toGrey)
    end
    if res.target and res.crafts then
        res.text = string.format(res.exact and L.LL_TO or L.LL_TO_APPROX, res.crafts, L["LL_" .. res.target:upper()])
        res.textColored = "|cff" .. HEX[res.target] .. res.text .. "|r"
    end
    res.textColored = res.textColored or ("|cff" .. HEX[res.state] .. (res.text or "") .. "|r")
    return res
end

-- Relative widths of the four zones and the marker position (0..1)
function LL.Layout(r, rank)
    local req = (r.req or 0) > 1 and r.req < r.yellow and r.req or nil
    local lo = req or math.max(0, r.yellow - math.max(r.grey - r.yellow, 10))
    local o = math.max(r.yellow - lo, 0)
    local y = math.max(r.green - r.yellow, 0)
    local g = math.max(r.grey - r.green, 0)
    local cap = math.max((r.grey - lo) * 0.12, 1)
    local total = o + y + g + cap
    local pos
    if not rank then pos = nil
    elseif rank >= r.grey then pos = (o + y + g + cap * 0.5) / total
    else pos = math.max(0, math.min(rank - lo, o + y + g)) / total end
    return { o / total, y / total, g / total, cap / total }, pos
end

---------------------------------------------------------------------------
-- Widget
---------------------------------------------------------------------------
local ORDER = { "orange", "yellow", "green", "grey" }

local function LayoutWidget(w)
    local width = w:GetWidth()
    if not width or width <= 0 or not w.fracs then return end
    local x = 0
    for i, seg in ipairs(w.segs) do
        local fw = width * w.fracs[i]
        seg:ClearAllPoints()
        if fw >= 0.5 then
            seg:SetPoint("TOPLEFT", w, "TOPLEFT", x, 0)
            seg:SetPoint("BOTTOMLEFT", w, "BOTTOMLEFT", x, 0)
            seg:SetWidth(fw)
            seg:Show()
        else
            seg:Hide()
        end
        x = x + fw
    end
    if w.pos then
        w.marker:ClearAllPoints()
        w.marker:SetPoint("CENTER", w, "LEFT", width * w.pos, 0)
        w.marker:Show()
    else
        w.marker:Hide()
    end
end

-- Creates a line widget on `parent`. Anchor it yourself; height defaults to 2.
function LL.Create(parent, height)
    local w = CreateFrame("Frame", nil, parent)
    w:SetHeight(height or 2)
    w.segs = {}
    for i, key in ipairs(ORDER) do
        local t = w:CreateTexture(nil, "ARTWORK")
        t:SetColorTexture(COL[key][1], COL[key][2], COL[key][3], 1)
        w.segs[i] = t
    end
    w.marker = w:CreateTexture(nil, "OVERLAY")
    w.marker:SetColorTexture(1, 1, 1, 1)
    w.marker:SetSize(2, (height or 2) + 5)
    w:SetScript("OnSizeChanged", LayoutWidget)
    return w
end

function LL.Update(w, r, rank, dim)
    if not r or (r.yellow or 0) <= 0 then w:Hide(); return end
    w.fracs, w.pos = LL.Layout(r, rank)
    w:SetAlpha(dim and 0.45 or 1)
    w:Show()
    LayoutWidget(w)
end

---------------------------------------------------------------------------
-- Test mode overrides (TestMode.lua sets ns.Sim)
---------------------------------------------------------------------------
function ns.EffectiveRank(rank)
    if ns.Sim and ns.Sim.rank then return ns.Sim.rank end
    return rank
end

---------------------------------------------------------------------------
-- Blizzard recipe list: WoW Forever (modern ProfessionsFrame, ScrollBox)
---------------------------------------------------------------------------
local function ForeverRank()
    if C_TradeSkillUI and C_TradeSkillUI.GetChildProfessionInfo then
        local info = C_TradeSkillUI.GetChildProfessionInfo()
        if info and info.skillLevel then return info.skillLevel end
    end
    if C_TradeSkillUI and C_TradeSkillUI.GetBaseProfessionInfo then
        local info = C_TradeSkillUI.GetBaseProfessionInfo()
        if info then return info.skillLevel end
    end
end

local function DecorateRow(frame, r, rank)
    if not ns.db or ns.db.lifeline == false or not r then
        if frame.psLine then frame.psLine:Hide(); frame.psHint:Hide() end
        return
    end
    if not frame.psLine then
        frame.psLine = LL.Create(frame, 2)
        frame.psHint = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalTiny")
        frame.psHint:SetJustifyH("RIGHT")
    end
    local line, hint = frame.psLine, frame.psHint
    line:ClearAllPoints()
    -- start the line under the recipe name (Forever: frame.Label, Era: the button's font string)
    local label = frame.Label
    if type(label) ~= "table" and frame.GetFontString then label = frame:GetFontString() end
    local x = 20
    if type(label) == "table" and label.GetLeft and frame.GetLeft then
        local ll, fl = label:GetLeft(), frame:GetLeft()
        if ll and fl then x = math.max(ll - fl, 4) end
    end
    line:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", x, 1)
    line:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -2, 1)
    hint:ClearAllPoints()
    hint:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -2, 3)
    rank = ns.EffectiveRank(rank)
    LL.Update(line, r, rank)
    local c = LL.Calc(r, rank)
    local star = (ns.Advisor and ns.db.best ~= false and ns.Advisor.IsBest(r.spell)) and (ns.Advisor.STAR .. " ") or ""
    hint:SetText(star .. (c and c.textColored or ""))
    hint:SetShown(c ~= nil or star ~= "")
end

local function DecorateForeverRow(frame, node)
    local data = node and node.GetData and node:GetData()
    local info = data and data.recipeInfo
    local r = info and ns.BySpell[info.recipeID]
    if not r then
        if frame.psLine then frame.psLine:Hide(); frame.psHint:Hide() end
        return
    end
    DecorateRow(frame, r, ForeverRank())
end

function LL.HookForever()
    if LL.foreverHooked or not ProfessionsFrame then return end
    local list = ProfessionsFrame.CraftingPage and ProfessionsFrame.CraftingPage.RecipeList
    local sb = list and list.ScrollBox
    if not sb or not ScrollUtil or not ScrollUtil.AddInitializedFrameCallback then return end
    LL.foreverHooked = true
    LL.foreverScrollBox = sb
    ScrollUtil.AddInitializedFrameCallback(sb, function(_, frame, node) DecorateForeverRow(frame, node) end, LL, true)
end

---------------------------------------------------------------------------
-- Blizzard recipe list: Classic Era (TradeSkillFrame / CraftFrame)
---------------------------------------------------------------------------
local function SpellFromLink(link)
    local id = link and (link:match("enchant:(%d+)") or link:match("spell:(%d+)"))
    return id and tonumber(id)
end

local function RecipeFromName(name)
    return name and ns.ByName[name:lower()]
end

local function UpdateEraTradeSkill()
    if not TradeSkillFrame or not TradeSkillFrame:IsShown() then return end
    if not (GetTradeSkillLine and GetTradeSkillInfo) then return end      -- old API missing: stay quiet
    local _, rank = GetTradeSkillLine()
    local shown = TRADE_SKILLS_DISPLAYED or 8
    for i = 1, shown do
        local btn = _G["TradeSkillSkill" .. i]
        if btn then
            local r
            if btn:IsShown() then
                local idx = btn:GetID()
                local name, kind = GetTradeSkillInfo(idx)
                if name and kind ~= "header" then
                    local spell = GetTradeSkillRecipeLink and SpellFromLink(GetTradeSkillRecipeLink(idx))
                    r = (spell and ns.BySpell[spell]) or RecipeFromName(name)
                end
            end
            if r then DecorateRow(btn, r, rank) elseif btn.psLine then btn.psLine:Hide(); btn.psHint:Hide() end
        end
    end
end

local function UpdateEraCraft()
    if not CraftFrame or not CraftFrame:IsShown() then return end
    if not (GetCraftDisplaySkillLine and GetCraftInfo) then return end
    local _, rank = GetCraftDisplaySkillLine()
    local shown = CRAFTS_DISPLAYED or 8
    for i = 1, shown do
        local btn = _G["Craft" .. i]
        if btn then
            local r
            if btn:IsShown() then
                local idx = btn:GetID()
                local name, _, kind = GetCraftInfo(idx)
                if name and kind ~= "header" then
                    local spell = GetCraftRecipeLink and SpellFromLink(GetCraftRecipeLink(idx))
                    r = (spell and ns.BySpell[spell]) or RecipeFromName(name)
                end
            end
            if r then DecorateRow(btn, r, rank) elseif btn.psLine then btn.psLine:Hide(); btn.psHint:Hide() end
        end
    end
end

function LL.HookEraTradeSkill()
    if LL.tsHooked or not TradeSkillFrame_Update then return end
    LL.tsHooked = true
    hooksecurefunc("TradeSkillFrame_Update", UpdateEraTradeSkill)
end

function LL.HookEraCraft()
    if LL.craftHooked or not CraftFrame_Update then return end
    LL.craftHooked = true
    hooksecurefunc("CraftFrame_Update", UpdateEraCraft)
end

-- Re-decorate visible rows (after skill changes or test mode changes)
function LL.RefreshBlizzard()
    if LL.foreverScrollBox and LL.foreverScrollBox.ForEachFrame then
        LL.foreverScrollBox:ForEachFrame(function(frame, node) DecorateForeverRow(frame, node) end)
    end
    UpdateEraTradeSkill()
    UpdateEraCraft()
end

local f = ns.AddEventFrame(CreateFrame("Frame"), "Lifeline")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(_, event, name)
    if not ns.Flavor then return end
    if event == "PLAYER_LOGIN" then
        if ns.UsesModernProfessions and ProfessionsFrame then LL.HookForever() end
        if ns.IsEra then LL.HookEraTradeSkill(); LL.HookEraCraft() end
    elseif name == "Blizzard_Professions" then
        LL.HookForever()
    elseif name == "Blizzard_TradeSkillUI" then
        LL.HookEraTradeSkill()
    elseif name == "Blizzard_CraftUI" then
        LL.HookEraCraft()
    end
end)
