if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Testroutine (ab 0.65.6)
-- Prüft das Addon "auf Herz und Nieren" nach auftraege/AHSentinel/testroutine-ahsentinel.txt und schreibt den
-- Bericht über GoldSentinelTest.lua in AHSentinelDB.gsTest (der RaidMasterUploader meldet ihn an die Prüfung).
--   /ahs testroutine            alles, was ohne Spieler-Handlung geht (Auktionshaus darf zu sein)
--   /ahs testroutine a ... j    nur ein Bereich
--   /ahs testroutine server     Auktionshaus offen: Scan, Suchen, simulierter Handel (bisheriger Selbsttest)
--   /ahs testroutine haendler | berufe | post | gildenbank | kampf   halbautomatische Teile
--   Kurzform: /ahs test = testroutine server, /ahs test daten = testroutine
-- Nur für den Entwickler (GoldSentinelDev). Sicher:
--   * echte Daten (AHSentinelDB) werden vorher gesichert, nachher verglichen und wiederhergestellt
--   * Kaufen, Bieten, Einstellen, Abbrechen, Post, Händler-Verkauf und Preis-Sync sind nur simuliert (A:Simulated)
--   * keine Blizzard-Funktion wird ersetzt: Simulationen laufen über eigene Nahtstellen
--     (A.apiOverride / A:API, A.testCombat / A:InCombat, A.AH-Proxy, Test-Briefkasten A.Inbox)
--   * im Kampf startet sie nicht; beginnt ein Kampf, bricht sie ab und stellt alles zurück
-- Testfall-IDs bleiben über alle Versionen gleich (T01 ... T152, neue ab T153).
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L
local ST, TM = A.SelfTest, A.TestMode

local TR = { running = false, rows = {}, log = {} }
A.TestRoutine = TR

local FAKE = 990000001                 -- Test-Item-IDs ab hier (SelfTest FAKE_ID0 + 1)
local LINEN = 2589                     -- Leinenstoff
local SLICE_MS = 40                    -- Retail: "script ran too long" vermeiden
local clock = debugprofilestop

local function G() return _G.GoldSentinelGame end
local function GTest() return _G.GoldSentinelTest end
local function Ms() return clock and clock() or (GetTime() * 1000) end

-- ------------------------------------------------------------
-- Hilfen
-- ------------------------------------------------------------
local function Copy(v)
    if type(v) ~= "table" then return v end
    local c = {}
    for k, x in pairs(v) do c[k] = Copy(x) end
    return c
end

local function Replace(target, source)
    if type(target) ~= "table" or type(source) ~= "table" then return end
    for k in pairs(target) do target[k] = nil end
    for k, v in pairs(source) do target[k] = v end
end

-- A.Print für die Dauer von fn abfangen; liefert die Zeilen (ohne Farbcodes)
local function Capture(fn, ...)
    local lines = {}
    local real = A.Print
    A.Print = function(_, msg) table.insert(lines, A:PlainText(tostring(msg))) end
    local res = { pcall(fn, ...) }
    A.Print = real
    if not res[1] then error(res[2], 0) end
    return lines, unpack(res, 2)
end
TR.Capture = Capture

-- Testwert, der wie ein geschützter Wert ("secret value") bei Vergleich, Verketten, Index und Länge einen Fehler wirft
local function Boom() error("geschützter Testwert benutzt", 2) end
local SECRET = setmetatable({}, { __index = Boom, __newindex = Boom, __concat = Boom, __lt = Boom, __le = Boom,
    __len = Boom, __call = Boom, __unm = Boom, __add = Boom, __sub = Boom, __mul = Boom, __div = Boom,
    __tostring = function() return "<geschützt>" end })
TR.SECRET = SECRET

-- fn mit simuliertem geschützten Wert ausführen: GoldSentinelGame.IsSecret (Addon-Tabelle, kein Blizzard-Global)
-- erkennt SECRET nur für die Dauer dieses einen synchronen Aufrufs.
local function WithSecret(fn, ...)
    local g = G()
    if not (g and g.IsSecret) then return pcall(fn, ...) end
    local real = g.IsSecret
    g.IsSecret = function(v) if v == SECRET then return true end return real(v) end
    local res = { pcall(fn, ...) }
    g.IsSecret = real
    return unpack(res)
end

local function Count(t) return A:CountTable(t) end

-- Prüfsumme grosser, nur gelesener Tabellen (statt einer Kopie)
local function Checksum(t)
    local n, h, newest = 0, 0, 0
    for id, e in pairs(t or {}) do
        n = n + 1
        if type(e) == "table" and type(e.history) == "table" then
            h = h + #e.history
            local last = e.history[#e.history]
            if type(last) == "table" and type(last.t) == "number" and last.t > newest then newest = last.t end
        end
    end
    return { n = n, h = h, newest = newest }
end

local function HasFakeIDs(t)
    for id in pairs(t or {}) do if type(id) == "number" and id >= 990000000 then return id end end
    return nil
end

-- ------------------------------------------------------------
-- Sandbox: echte Daten sichern, vergleichen, wiederherstellen
-- ------------------------------------------------------------
local NO_COPY = { marketData = true, names = true, gsTest = true, testRoutine = true }
-- Änderungen aus echten Spiel-Ereignissen (während der Routine läuft das Spiel weiter)
-- watcher.found: Zähler echter Wächter-Funde (der Wächter läuft im Spiel weiter, wenn das AH offen ist)
local ALLOWED = { "gsTest", "testRoutine", "marketData", "names", "namesSent", "vendorPrices", "selftest", "watcher.found",
    "sync.received", "sync.peers", "sync.lastReceived", "sync.lastScanTimeReceived", "sync.namesReceived" }
local ALLOWED_PART = {
    server = { "lastScanTime", "totalScans", "scanLog", "lastOwnScan" },
    haendler = { "vendorBuy", "vendorCost" },
}
-- beim ersten Lesen mit Standardwerten angelegt (normales Verhalten, keine Testdaten): nil -> Tabelle ist erlaubt
local LAZY = { ["watcher.binds"] = true, ["settings.lastSub"] = true, recipes = true, buyFavorites = true }
local function HasTestMarker(v)
    if type(v) == "string" then return v:find("AHS%-Test") ~= nil end
    if type(v) == "number" then return v >= 990000000 end
    if type(v) == "table" then
        for k, x in pairs(v) do if HasTestMarker(k) or HasTestMarker(x) then return true end end
    end
    return false
end
-- Schlüssel, die Namen tragen: im Bericht nur als Platzhalter
local NAME_KEYS = { chars = "<Charakter>", recipes = "<Charakter>", guildBank = "<Gilde>", deShared = "<Spieler>",
    peers = "<Spieler>" }

local function OwnCharKey()
    local Ch = A.Chars
    if Ch and Ch.Key then local ok, k = pcall(Ch.Key, Ch); if ok then return k end end
    return nil
end

local function PathText(segs)
    local out = {}
    for i, s in ipairs(segs) do
        local prev = segs[i - 1]
        if prev and NAME_KEYS[prev] then out[i] = NAME_KEYS[prev] else out[i] = tostring(s) end
    end
    return table.concat(out, ".")
end

function TR:IsAllowed(segs)
    local p = table.concat({ unpack(segs, 1, math.min(#segs, 2)) }, ".")
    local function match(list)
        for _, a in ipairs(list or {}) do
            if p == a or segs[1] == a then return true end
        end
        return false
    end
    if match(ALLOWED) or match(ALLOWED_PART[self.part]) then return true end
    -- eigener Charakter: Gold, Taschen, Bank kommen aus echten Spiel-Ereignissen
    if segs[1] == "chars" and segs[2] ~= nil and segs[2] == self.ownChar then return true end
    return false
end

local function Diff(a, b, segs, out, self)
    if #out >= 200 then return end
    if #segs > 0 and self:IsAllowed(segs) then return end
    if type(a) == "table" and type(b) == "table" then
        for k, v in pairs(a) do
            local s = { unpack(segs) }; s[#s + 1] = k
            Diff(v, b[k], s, out, self)
        end
        for k, v in pairs(b) do
            if a[k] == nil then
                local s = { unpack(segs) }; s[#s + 1] = k
                local lazy = LAZY[table.concat(s, ".")] and type(v) == "table" and not HasTestMarker(v)
                if not self:IsAllowed(s) and not lazy then table.insert(out, s) end
            end
        end
    elseif a ~= b then
        table.insert(out, { unpack(segs) })
    end
end

function TR:Backup()
    local db = A.db
    local b = { __missing = {} }
    for k, v in pairs(db) do
        if not NO_COPY[k] then b[k] = Copy(v) end
    end
    self.ownChar = OwnCharKey()
    self.sums = { market = Checksum(db.marketData), names = Count(db.names) }
    db.testRoutine = { backup = b, part = self.part, started = time() }
end

local function SetPath(root, segs, value)
    local t = root
    for i = 1, #segs - 1 do
        if type(t[segs[i]]) ~= "table" then t[segs[i]] = {} end
        t = t[segs[i]]
    end
    t[segs[#segs]] = value
end

local function GetPath(root, segs)
    local t = root
    for i = 1, #segs do
        if type(t) ~= "table" then return nil end
        t = t[segs[i]]
    end
    return t
end

-- vergleicht mit der Sicherung, schreibt Unterschiede zurück; liefert die Pfade (Text) der Unterschiede
function TR:CompareAndRestore()
    local db = A.db
    local tr = db and db.testRoutine
    local b = tr and tr.backup
    if not b then return { "Sicherung fehlt" } end
    local cur = {}
    for k, v in pairs(db) do if not NO_COPY[k] then cur[k] = v end end
    local diffs = {}
    Diff(b, cur, {}, diffs, self)
    local paths = {}
    for _, segs in ipairs(diffs) do
        if segs[1] ~= "__missing" then
            table.insert(paths, PathText(segs))
            local orig = GetPath(b, segs)
            if #segs == 1 and type(db[segs[1]]) == "table" and type(orig) == "table" then
                Replace(db[segs[1]], Copy(orig))     -- Tabellen nicht tauschen: Module halten Verweise
            else
                SetPath(db, segs, Copy(orig))
            end
        end
    end
    -- Testdaten dürfen auch in den erlaubten Teilen nicht landen
    local fake = HasFakeIDs(db.marketData)
    if fake then table.insert(paths, "marketData.<Test-ID>"); db.marketData[fake] = nil end
    return paths
end

-- nach /reload oder Absturz mitten in der Routine: Sicherung zurückschreiben
function TR:RecoverAfterReload()
    local db = A.db
    local tr = db and db.testRoutine
    if not (tr and tr.backup) then return false end
    self.part = tr.part
    self.ownChar = OwnCharKey()
    for k, v in pairs(tr.backup) do
        if k ~= "__missing" and not NO_COPY[k] then
            if type(db[k]) == "table" and type(v) == "table" then Replace(db[k], v) else db[k] = v end
        end
    end
    for k in pairs(db) do
        if not NO_COPY[k] and tr.backup[k] == nil then db[k] = nil end
    end
    local fake = HasFakeIDs(db.marketData)
    while fake do db.marketData[fake] = nil; fake = HasFakeIDs(db.marketData) end
    db.testRoutine = nil
    return true
end

A:On("READY", function()
    if A.db and A.db.testRoutine then
        local ok = pcall(TR.RecoverAfterReload, TR)
        if ok then A:Print(L["Testroutine vom letzten Mal abgebrochen - deine echten Daten sind wiederhergestellt."]) end
    end
end)

-- ------------------------------------------------------------
-- Laufzeit-Zustand (nicht in den SavedVariables)
-- ------------------------------------------------------------
function TR:SaveRuntime()
    local Sn, W, B, Se, Td, S = A.Sniper, A.Watcher, A.Buy, A.Seller, A.Today, A.Sync
    self.rt = {
        forceForever = A.forceForever, print = A.Print,
        snInstantFailed = Sn and Sn.instantFailed, snPending = Sn and Sn.pending, snExtra = Sn and Sn.extra,
        hold = W and W.holdForScan, opps = W and Copy(W.opps),
        bDetail = B and B.detail, sePendingPost = Se and Se.pendingPost,
        todayState = Td and Copy(Td.state), todayExtra = Td and Copy(Td.extra),
        syncChannel = S and S.channelId, syncQueue = S and S.queue and #S.queue or 0,
        syncStatus = S and S.status, heard = S and S.heardScanTime,
        aahLegacy = A.AH_LEGACY,
    }
end

function TR:RestoreRuntime()
    local r = self.rt
    if not r then return {} end
    self.rt = nil
    local problems = {}
    local function part(name, fn)
        local ok, err = pcall(fn)
        if not ok then table.insert(problems, name .. ": " .. tostring(err)) end
    end
    part("Flags", function()
        A.forceForever = r.forceForever
        A.apiOverride, A.testCombat = nil, nil
        A.AH_LEGACY = r.aahLegacy
        if A.Extras then A.Extras.testMyName = nil end
        local g = G()
        if g and g.SetTestFlavor then g.SetTestFlavor(nil) end
        A.Print = r.print
    end)
    part("Sniper", function()
        local Sn = A.Sniper
        if not Sn then return end
        Sn.instantFailed, Sn.pending, Sn.extra = r.snInstantFailed, r.snPending, r.snExtra
        Sn.result = nil
    end)
    part("Wächter", function()
        local W = A.Watcher
        if not W then return end
        W.holdForScan = r.hold
        if type(W.opps) == "table" and type(r.opps) == "table" then Replace(W.opps, r.opps) end
    end)
    part("Einkauf/Verkaufen", function()
        if A.Buy then A.Buy.detail = r.bDetail end
        if A.Seller then A.Seller.pendingPost = r.sePendingPost end
    end)
    part("Heute tun", function()
        local Td = A.Today
        if not Td then return end
        if type(r.todayState) == "table" then Replace(Td.state, r.todayState) end
        if type(r.todayExtra) == "table" then Replace(Td.extra, r.todayExtra) end
    end)
    part("Sync", function()
        local S = A.Sync
        if not S then return end
        S.channelId, S.status, S.heardScanTime = r.syncChannel, r.syncStatus, r.heard
        if S.queue and #S.queue > r.syncQueue then for i = #S.queue, r.syncQueue + 1, -1 do table.remove(S.queue, i) end end
    end)
    part("Scan-Wunsch", function() if A.DropScanWish and A.scanWanted then A:DropScanWish(false) end end)
    return problems
end

-- ------------------------------------------------------------
-- Nachweis "nichts wirklich ausgeführt": Zähler über hooksecurefunc (taint-frei, nur während der Routine)
-- ------------------------------------------------------------
TR.real = {}
local function Hook(tbl, name, label, cond)
    if not hooksecurefunc then return end
    local target = tbl and tbl[name] or (not tbl and _G[name])
    if type(target) ~= "function" then return end
    local ok = pcall(function()
        local fn = function(...)
            if not TR.running then return end
            if cond and not cond(...) then return end
            TR.real[label] = (TR.real[label] or 0) + 1
        end
        if tbl then hooksecurefunc(tbl, name, fn) else hooksecurefunc(name, fn) end
    end)
    return ok
end
local function MerchantOpen() return MerchantFrame and MerchantFrame.IsShown and MerchantFrame:IsShown() end
local function SyncPrefix(prefix) return prefix == "AHAP1" end
function TR:InstallCounters()
    if self.countersInstalled then return end
    self.countersInstalled = true
    Hook(nil, "SendMail", "SendMail")
    Hook(nil, "TakeInboxMoney", "TakeInboxMoney")
    Hook(nil, "TakeInboxItem", "TakeInboxItem")
    Hook(nil, "JoinTemporaryChannel", "JoinTemporaryChannel")
    Hook(nil, "LeaveChannelByName", "LeaveChannelByName")
    Hook(nil, "SetOverrideBindingClick", "SetOverrideBindingClick")
    if C_Container then Hook(C_Container, "UseContainerItem", "UseContainerItem", MerchantOpen)
    else Hook(nil, "UseContainerItem", "UseContainerItem", MerchantOpen) end
    if C_ChatInfo and C_ChatInfo.SendAddonMessage then Hook(C_ChatInfo, "SendAddonMessage", "SendAddonMessage", SyncPrefix)
    else Hook(nil, "SendAddonMessage", "SendAddonMessage", SyncPrefix) end
end

-- ------------------------------------------------------------
-- Ergebnisse (alle über GoldSentinelTest: T:Check / T:Skip / T:Client)
-- ------------------------------------------------------------
function TR:Row(status, id, area, name, detail)
    table.insert(self.rows, { group = tostring(area) .. " " .. tostring(id), name = name, status = status,
        detail = detail and A:PlainText(tostring(detail)) or "" })
    if ST and ST.window and ST.window:IsShown() then ST.window:Refresh() end
end

local function LastDetail(T, id)
    local e = T.results[#T.results]
    if not (e and e.id == id) then return "" end
    if e.lua then return "Lua: " .. e.lua end
    local d = e.ergebnis and ("ist: " .. e.ergebnis) or ""
    if e.erwartet then d = d .. " | soll: " .. e.erwartet end
    return d
end

-- Ehrliche Zählung (0.65.16): eine Prüfung, die im Client nicht möglich ist, gibt "SKIP", Grund zurück und zählt dann
-- als ÜBERSPRUNGEN statt als OK. Die Funktion läuft genau einmal; Lua-Fehler bleiben FEHLER.
function TR:Check(id, area, name, fn)
    local res = { pcall(fn) }
    if res[1] and res[2] == "SKIP" then return self:Skip(id, area, name, tostring(res[3] or "nicht prüfbar")) end
    local ok = self.T:Check(id, area, name, function()
        if not res[1] then error(res[2], 0) end
        return unpack(res, 2)
    end)
    self:Row(ok and "PASS" or "FAIL", id, area, name, LastDetail(self.T, id))
    return ok
end
function TR:Skip(id, area, name, reason)
    self.T:Skip(id, area, name, reason)
    self:Row("SKIP", id, area, name, reason)
end
function TR:Client(id, area, name, how)
    self.T:Client(id, area, name, how)
    self:Row("CLIENT", id, area, name, how)
end

-- Absichtlich erzeugte Fehler-Einträge wieder aus db.gsTest.errors entfernen (keine echten Fehler)
function TR:ClearTestErrors()
    local s = A.db and A.db.gsTest and A.db.gsTest.errors
    if type(s) ~= "table" then return end
    for k, e in pairs(s) do
        if type(k) == "string" and (k:find("AHS%-Test") or k:find("geschützter Testwert")) then s[k] = nil end
    end
end
local function ErrorEntry(where)
    local s = A.db and A.db.gsTest and A.db.gsTest.errors
    for k, e in pairs(s or {}) do
        if type(e) == "table" and e.wo == where and tostring(e.msg):find("AHS%-Test") then return e end
    end
    return nil
end

-- ------------------------------------------------------------
-- Ablauf
-- ------------------------------------------------------------
TR.PARTS = { auto = true, a = true, b = true, c = true, d = true, e = true, f = true, g = true, h = true, i = true, j = true, k = true,
    server = true, haendler = true, berufe = true, post = true, gildenbank = true, kampf = true }

function TR:Step(fn) table.insert(self.steps, fn) end

function TR:Start(part)
    if not A:RequireDev() then return false end
    part = (part == nil or part == "") and "auto" or tostring(part):lower()
    part = ({ ["händler"] = "haendler", haendler = "haendler", merchant = "haendler", professions = "berufe",
        mail = "post", guildbank = "gildenbank", combat = "kampf" })[part] or part
    if not self.PARTS[part] then
        A:Print(string.format(L["Unbekannter Teil der Testroutine: %s (a-j, server, haendler, berufe, post, gildenbank, kampf)"], part))
        return false
    end
    if self.running or (ST and ST.running) then A:Print(L["Selbsttest läuft schon ..."]); return false end
    if TM and TM.active then A:Print(L["Erst den Testmodus beenden."]); return false end
    if not A.db then return false end
    if A:InCombat() then A:Print(L["Im Kampf kann die Testroutine nicht starten."]); return false end
    local GT = GTest()
    if not (GT and GT.Begin) then A:Print(L["GoldSentinelTest.lua fehlt - Testroutine nicht möglich."]); return false end

    self.part = part
    self.rows = {}
    self.real = {}
    self.T = GT.Begin("AHSentinel", A.version, A.db)
    self.memBefore = collectgarbage("count")
    self.money0 = GetMoney and GetMoney() or 0
    self:InstallCounters()
    self:Backup()
    self:SaveRuntime()
    ST:SaveState()
    -- Schutz für die GANZE Routine: Handels-Proxy, Sperren der Kauf-Knöpfe, Test-Briefkasten, A:Simulated()
    ST:Lock()
    TM:InstallInbox()
    self.running = true
    self.wasArmed = A.Sniper and A.Sniper:IsArmed()
    if self.wasArmed then A.Sniper:SetArmed(false) end
    if A.Watcher and A.Watcher:IsEnabled() then A.Watcher:SetEnabled(false) end

    self.steps, self.pos, self.wait = {}, 0, nil
    self:BuildSteps(part)
    ST.results = self.rows
    if ST.ShowWindow then ST:ShowWindow() end
    A:Print(string.format(L["Testroutine gestartet (%s) - Kaufen, Einstellen, Post, Händler und Preis-Sync sind solange nur simuliert."], part))
    self:Next()
    return true
end

function TR:Next()
    local t0 = Ms()
    while self.running do
        if Ms() - t0 > SLICE_MS then
            C_Timer.After(0, function() if TR.running and not TR.wait then TR:Next() end end)
            return
        end
        self.pos = self.pos + 1
        local s = self.steps[self.pos]
        if not s then return self:Finish() end
        local ok, status, waitFn, timeout, checkFn = pcall(s, self)
        if not ok then
            self:Check("T000", "-", "Ablauf der Routine", function() error(status, 0) end)
        elseif status == "WAIT" then
            self.wait = { fn = waitFn, untilT = GetTime() + (timeout or 30), check = checkFn }
            return
        end
    end
end

function TR:Poll()
    local w = self.wait
    if not w then return end
    local okW, done = pcall(w.fn)
    if (okW and done) or not okW or GetTime() > w.untilT then
        self.wait = nil
        local timedOut = not (okW and done)
        local ok, err = pcall(w.check, timedOut, not okW and done or nil)
        if not ok then self:Check("T000", "-", "Ablauf der Routine (Warten)", function() error(err, 0) end) end
        return self:Next()
    end
end

-- Kampf begonnen: abbrechen, alles zurück
function TR:Abort(reason)
    if not self.running then return end
    self.wait = nil
    if reason == "Kampf begonnen" then self:Skip("T95", "C", "Routine und Kampf", reason)
    else self:Skip("T000", "-", "Abbruch", reason) end
    self.steps = {}
    self:Finish(true)
end

function TR:Finish(aborted)
    if not self.running then return end
    self.wait = nil
    local T = self.T
    if not aborted then
        -- Testfall-IDs eindeutig (jede ID genau einmal im Bericht)
        self:Check("T174", "I", "Testfall-IDs eindeutig", function()
            local seen, dup = {}, {}
            for _, r in ipairs(self.rows) do
                local id = tostring(r.group):match("(%S+)$")
                if id and id ~= "T000" then
                    if seen[id] then dup[#dup + 1] = id end
                    seen[id] = true
                end
            end
            return #dup == 0, #dup == 0 and "keine doppelten IDs" or ("doppelt: " .. table.concat(dup, ", ")), "jede ID einmal"
        end)
    end
    -- Nachweis "nichts wirklich ausgeführt" (2.5)
    if not aborted then
        self:Check("T157", "I", "Nichts wirklich ausgeführt (Gold, Post, Händler, Sync, Kanal)", function()
            local parts, bad = {}, 0
            for k, n in pairs(self.real) do
                if k ~= "SetOverrideBindingClick" then parts[#parts + 1] = k .. "=" .. n; bad = bad + n end
            end
            local m = GetMoney and GetMoney() or 0
            if m < self.money0 then parts[#parts + 1] = "Gold weniger"; bad = bad + 1 end
            return bad == 0, string.format("%d Befehle nur protokolliert, echte Aktionen: %s", ST.tradeLog and #ST.tradeLog or 0,
                #parts > 0 and table.concat(parts, ", ") or "0"), "0"
        end)
    end
    self.running = false
    -- Schutz und Zustand zurück
    local problems = {}
    local function part(name, fn)
        local ok, err = pcall(fn)
        if not ok then table.insert(problems, name .. ": " .. tostring(err)) end
    end
    part("Schutz", function() ST:Unlock() end)
    part("Briefkasten", function() TM:RemoveInbox(); wipe(TM.fakeMail); wipe(TM.fakeOwned); TM.mailMoney = 0 end)
    for _, p in ipairs(self:RestoreRuntime()) do table.insert(problems, p) end
    part("Zustand", function() ST:RestoreState() end)
    part("Sniper", function() if self.wasArmed and A.Sniper and not A.Sniper:IsArmed() then A.Sniper:SetArmed(true) end end)
    self:ClearTestErrors()
    local paths = self:CompareAndRestore()
    local again = #paths > 0 and self:CompareAndRestore() or {}
    if A.db then A.db.testRoutine = nil end
    if #problems > 0 then A:ReportError("Test:Wiederherstellen", table.concat(problems, "; ")) end
    local sandbox = "OK"
    if #paths > 0 then
        sandbox = string.format("FEHLER: %d Pfade, wiederhergestellt%s: %s", #paths, #again > 0 and " (nicht vollständig)" or "",
            table.concat(paths, ", ", 1, math.min(#paths, 12)))
    end
    collectgarbage("collect")
    local memKB = math.floor(collectgarbage("count") - (self.memBefore or 0))
    -- ehrliche Zählung: was nicht automatisch geprüft wurde, steht ausdrücklich im Bericht
    local notAuto, clientList = 0, {}
    for _, r in ipairs(self.rows) do
        if r.status == "SKIP" or r.status == "CLIENT" then notAuto = notAuto + 1 end
        if r.status == "CLIENT" then clientList[#clientList + 1] = r.group .. " " .. r.name end
    end
    local text = T:Finish({ sandbox = sandbox, teil = self.part, speicher_kb = tostring(memKB),
        nicht_automatisiert = tostring(notAuto) })
    text = text .. "\n" .. string.format("Nicht automatisiert: %d (übersprungen oder im Client prüfen)", notAuto)
    if #clientList > 0 then text = text .. "\nIm Client prüfen:\n  " .. table.concat(clientList, "\n  ") end
    text = text .. "\n" .. string.format("Sprache: %s · Addon-Sprache: %s · Auktionshaus: %s",
        tostring(GetLocale and GetLocale()), tostring(A.uiLang), A.AH_LEGACY and "klassisch" or "modern")
    if #problems > 0 then text = text .. "\nWiederherstellen: " .. table.concat(problems, "; ") end
    self.lastText = text
    local c = T.counts
    self.lastSummary = string.format(L["Testroutine fertig: %d OK, %d FEHLER, %d übersprungen, %d im Client prüfen."],
        c.ok, c.fehler, c.uebersprungen, c.client)
    self.notAutomated = notAuto
    A:Print((c.fehler == 0 and "|cff33dd55" or "|cffff5544") .. self.lastSummary .. "|r")
    A:Print(L["Bericht gespeichert – wird beim nächsten /reload oder Ausloggen an die Prüfung gemeldet."])
    A:Print(L["Bitte jetzt /reload."])
    if A.UI and A.UI.ShowTextWindow then pcall(A.UI.ShowTextWindow, A.UI, L["Testbericht"], text) end
    if ST.window then ST.window:Refresh() end
end

function TR:ReportText()
    return self.lastText or L["Noch kein Selbsttest gelaufen."]
end

local frame = CreateFrame("Frame")
TR.frame = frame
pcall(frame.RegisterEvent, frame, "PLAYER_REGEN_DISABLED")
frame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_REGEN_DISABLED" and TR.running then
        TR:Abort("Kampf begonnen")
        A:Print(L["Testroutine abgebrochen: Kampf begonnen. Deine Daten sind wiederhergestellt."])
    end
end)
local acc = 0
frame:SetScript("OnUpdate", function(_, dt)
    if not TR.running then return end
    acc = acc + (dt or 0)
    if acc < 0.25 then return end
    acc = 0
    TR:Poll()
end)

-- ============================================================
-- Testfälle
-- ============================================================
local function want(part, area)
    return part == "auto" or part == area
end

-- bisherige Selbsttest-Schritte über GoldSentinelTest laufen lassen (Adapter, testroutine 2.2)
local OLD_IDS = {
    ["Grundlagen/Einstellgebühr WoW Forever"] = { "T16", "B" },
    ["Scan/Markt-Scan"] = { "T20", "B" }, ["Scan/Marktdaten plausibel"] = { "T21", "B" },
    ["Oberfläche/Preisverlauf-Fenster"] = { "T26a", "B" }, ["Oberfläche/Optionen, Hilfe, Einkaufslisten"] = { "T26b", "B" },
    ["Oberfläche/Sprachwechsel (alle Sprachen, mehrfach)"] = { "T112", "F" },
    ["Auswertungen/Suche nach Namen"] = { "T15", "B" }, ["Auswertungen/Verkaufbarkeit"] = { "T14", "B" },
    ["Auswertungen/Heute tun"] = { "T72", "B" }, ["Auswertungen/Tooltip"] = { "T73", "B" },
    ["Auswertungen/Vermögen"] = { "T60", "B" },
    ["Server/Einkauf: Kategorie-Suche"] = { "T32", "B" }, ["Server/Einkauf: Angebote eines Items"] = { "T33", "B" },
    ["Server/Verkaufen: Preisprüfung"] = { "T48", "B" }, ["Server/Sniper: Suche (kauft nichts)"] = { "T40", "B" },
    ["Server/Wächter: eine Runde (kauft nichts)"] = { "T45", "B" }, ["Server/Eigene Auktionen"] = { "T51", "B" },
    ["Handel (simuliert)/Sofortkauf"] = { "T35", "B" }, ["Handel (simuliert)/Gebot"] = { "T36", "B" },
    ["Handel (simuliert)/Sniper-Kauf"] = { "T41", "B" }, ["Handel (simuliert)/Einstellen"] = { "T49", "B" },
    ["Handel (simuliert)/Abbrechen"] = { "T51b", "B" },
}
local TAB_LETTERS = "abcdefghijklmnop"

function TR:AddOldSteps(savedMode)
    ST.savedMode = savedMode
    local old = ST:Steps()
    local tabN = 0
    for idx, s in ipairs(old) do
        local key = s.group .. "/" .. s.name
        local map = OLD_IDS[key]
        local id, area
        if map then id, area = map[1], map[2]
        elseif s.group == "Oberfläche" and s.name:find("^Reiter") then
            tabN = tabN + 1
            id, area = "T25" .. TAB_LETTERS:sub(tabN, tabN), "B"
        else
            id, area = string.format("S%02d", idx), "B"
        end
        local name = s.group .. ": " .. s.name
        if s.name ~= "Übersetzungen" then        -- konnte nie fehlschlagen, ersetzt durch T113
            local function adapt(status, detail, expect)
                if status == "SKIP" then return self:Skip(id, area, name, detail or "") end
                return self:Check(id, area, name, function()
                    return status ~= "FAIL", detail ~= "" and detail or nil, status == "FAIL" and "bestanden" or nil
                end)
            end
            self:Step(function()
                if ST.ctx and ST.ctx.abort then return self:Skip(id, area, name, "früherer Schritt hat den alten Selbsttest beendet") end
                local ok, status, detail, waitFn, timeout, checkFn = pcall(s.run)
                if not ok then return self:Check(id, area, name, function() error(status, 0) end) end
                if status == "WAIT" then
                    return "WAIT", waitFn, timeout, function(timedOut, werr)
                        if timedOut then
                            return self:Check(id, area, name, function()
                                return false, werr and tostring(werr) or "keine Antwort", "Antwort in " .. tostring(timeout) .. " s"
                            end)
                        end
                        local ok2, st2, d2 = pcall(checkFn)
                        if not ok2 then return self:Check(id, area, name, function() error(st2, 0) end) end
                        return adapt(st2 or "PASS", d2)
                    end
                end
                return adapt(status or "PASS", detail)
            end)
        end
    end
end

-- HALB-Fälle mit offenem Auktionshaus (Teil "server"). Alles mit Folgen landet nur im Protokoll (ST.tradeLog).
function TR:AddServerSteps()
    local B = function(fn) self:Step(fn) end
    local Chk = function(...) return self:Check(...) end
    local Skp = function(...) return self:Skip(...) end
    local function TradeCount(fn)
        local n = 0
        for _, e in ipairs(ST.tradeLog or {}) do if e.fn == fn then n = n + 1 end end
        return n
    end
    local modern = not A.AH_LEGACY

    B(function()
        if not (A.UI.CanIntegrate and A.UI:CanIntegrate()) then return Skp("T27", "B", "Einbindung ins Auktionshaus", "Einbindung nicht möglich (kein AH-Rahmen)") end
        Chk("T27", "B", "Einbindung ins Auktionshaus", function()
            local UI, st = A.UI, A.db.settings
            local was = st.ahIntegration
            local res = { pcall(function()
                Capture(function() UI:SetIntegration(true) end)
                local host = UI.ahHost ~= nil
                Capture(function() UI:ShowInAH() end)
                Capture(function() UI:LeaveAH() end)
                Capture(function() UI:SetIntegration(false) end)
                Capture(SlashCmdList.AHANALYZERPRO, "ah")
                Capture(SlashCmdList.AHANALYZERPRO, "ahdebug")
                return host and UI.ahLastError == nil, string.format("Rahmen %s, Fehler %s", tostring(host), tostring(UI.ahLastError))
            end) }
            Capture(function() UI:SetIntegration(was and true or false) end)
            st.ahIntegration = was
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "Rahmen da, kein ahLastError"
        end)
    end)

    B(function()
        if not modern then return Skp("T37", "B", "Warenkauf simuliert", "keine Waren im alten AH") end
        Chk("T37", "B", "Warenkauf simuliert", function()
            local Bu = A.Buy
            local saved = { detail = Bu.detail, pending = Bu.pending, last = Bu.lastPurchase, conf = Bu.confirming }
            local money = GetMoney and GetMoney() or 0
            local s0, c0 = TradeCount("StartCommoditiesPurchase"), TradeCount("ConfirmCommoditiesPurchase")
            local res = { pcall(function()
                Bu.pending = nil
                Bu.detail = { itemID = LINEN, commodity = true, qty = 1, listings = { { qty = 5, price = 100 } } }
                -- echte Funktionen (die Routine sperrt Kaufen); der Server-Befehl landet über den Schutz-Proxy nur im Protokoll
                local okS = ST:RealFn("Buy", "StartCommodity")(Bu)
                A:SimulateAHEvent("COMMODITY_PRICE_UPDATED", 100, 100)
                local ready = Bu.pending and Bu.pending.state == "ready"
                local okC = ST:RealFn("Buy", "ConfirmCommodity")(Bu)
                return okS and ready and okC and TradeCount("StartCommoditiesPurchase") == s0 + 1
                    and TradeCount("ConfirmCommoditiesPurchase") == c0 + 1 and (GetMoney and GetMoney() or 0) == money,
                    string.format("Start %s, Preis da %s, Bestätigt %s (nur Protokoll)", tostring(okS), tostring(ready), tostring(okC))
            end) }
            Bu.detail, Bu.pending, Bu.lastPurchase, Bu.confirming = saved.detail, saved.pending, saved.last, saved.conf
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "Start und Bestätigen nur im Protokoll, Gold gleich"
        end)
    end)

    -- T42: Sniper scharf, ein paar Sekunden laufen lassen - nie ein Bestätigen ohne Klick
    B(function()
        local Sn = A.Sniper
        self.t42 = { targets = Copy(A.db.sniper.targets), c0 = TradeCount("ConfirmCommoditiesPurchase"),
            b0 = TradeCount("PlaceBid"), s0 = TradeCount("StartCommoditiesPurchase"), until_ = GetTime() + 8 }
        local mv = A:GetMarketValue(LINEN) or 10000
        Capture(function()
            Sn:SetTarget(tostring(LINEN), math.floor(mv * 2), 1, math.floor(mv * 4))
            Sn:SetArmed(true)
        end)
        return "WAIT", function() return GetTime() >= self.t42.until_ end, 12, function()
            local t = self.t42
            self.t42 = nil
            local starts = TradeCount("StartCommoditiesPurchase")
            Capture(function()
                Sn:SetArmed(false)
                if Sn.CancelPending then Sn:CancelPending() end
            end)
            A.db.sniper.targets = t.targets
            Chk("T42", "B", "Sniper-Vorab-Reservierung kauft nie ohne Klick", function()
                local c, b = TradeCount("ConfirmCommoditiesPurchase") - t.c0, TradeCount("PlaceBid") - t.b0
                -- WoW Forever blockt StartCommoditiesPurchase ohne Tastendruck: dort darf der Sniper gar nicht vorab reservieren
                local auto = starts - (t.s0 or 0)
                local foreverOK = not A:IsForever() or auto == 0
                return c == 0 and b == 0 and foreverOK, string.format("Bestätigen %d, Kauf/Gebot %d, Vorab-Reservierungen %d", c, b, auto),
                    A:IsForever() and "0, 0, 0 (Forever)" or "0, 0"
            end)
        end
    end)

    -- T50: Serie einstellen (Befehle nur im Protokoll)
    B(function()
        local Se = A.Seller
        self.t50 = { batch = Se.batch }
        local ok, msg = Capture(function() return Se:StartBatch() end)
        if not Se.batch then
            Se.batch = self.t50.batch
            self.t50 = nil
            return Chk("T50", "B", "Serie einstellen", function()
                return true, "keine Items mit gemerktem Preis - Start lehnt sauber ab", "ohne Fehler"
            end)
        end
        return "WAIT", function()
            local e = Se:BatchCurrent()
            local pr = e and Se.prices[e.itemID]
            return not e or (pr and pr.time >= Se.batch.started)
        end, 15, function()
            local posts = TradeCount("PostItem") + TradeCount("PostCommodity")
            for _ = 1, 2 do Capture(function() Se:BatchStep() end) end
            Capture(function() Se:StopBatch() end)
            Se.pendingPost = nil
            self.t50 = nil
            Chk("T50", "B", "Serie einstellen", function()
                local n = TradeCount("PostItem") + TradeCount("PostCommodity") - posts
                return Se.batch == nil, string.format("%d Einstell-Befehle nur im Protokoll, Serie beendet", n), "Serie danach nil"
            end)
        end
    end)

    -- T52: fiktive zu teure eigene Auktion -> unterboten; Abbrechen nur im Protokoll
    B(function()
        local Se = A.Seller
        if not ST.fakeOwned then return Skp("T52", "B", "Unterboten", "kein Schutz-Proxy für eigene Auktionen") end
        local mv = A:GetMarketValue(LINEN) or 100
        local fake = ST.FakeAuction(LINEN, 1, math.floor(mv * 1.5))
        table.insert(ST.fakeOwned, fake)
        self.t52 = { fake = fake, c0 = TradeCount("CancelAuction") }
        Capture(function() Se:QueryOwned() end)
        return "WAIT", function()
            for _, o in ipairs(Se.owned or {}) do if o.auctionID == fake.auctionID then return true end end
        end, 10, function()
            Capture(function() Se:CheckUndercuts() end)
        end
    end)
    B(function()
        local Se = A.Seller
        if not self.t52 then return end
        return "WAIT", function()
            local pr = Se.prices[LINEN]
            return pr and Se:IsPriceFresh(LINEN)
        end, 15, function(timedOut)
            local t = self.t52
            self.t52 = nil
            local o
            for _, x in ipairs(Se.owned or {}) do if x.auctionID == t.fake.auctionID then o = x end end
            Se:UpdateOwnedStatus()
            local ok, msg = Capture(function() return Se:CancelNextUndercut() end)
            ST.RemoveFake(ST.fakeOwned, t.fake.auctionID)
            Se.pendingCancel = nil
            Capture(function() Se:QueryOwned() end)
            Chk("T52", "B", "Unterboten", function()
                local pr = Se.prices[LINEN]
                local status = o and o.status
                local expect = (pr and pr.lowestOther) and "unterboten" or "günstigstes"
                return o ~= nil and status == expect, string.format("Status %s, Abbrechen-Befehle im Protokoll %d", tostring(status),
                    TradeCount("CancelAuction") - t.c0), expect
            end)
        end
    end)

    B(function()
        local m = A.jobMeasure
        A.jobMeasure = nil
        if not (m and m.frames and m.frames > 0) then
            return Skp("T126", "H", "Scan-Auswertung in Portionen", "keine Hintergrund-Arbeit gemessen (kein Scan im Teil server)")
        end
        Chk("T126", "H", "Scan-Auswertung in Portionen", function()
            return m.max <= (A.FRAME_BUDGET or 6) + 2, string.format("längste Portion %.1f ms in %d Frames", m.max, m.frames),
                "<= " .. ((A.FRAME_BUDGET or 6) + 2) .. " ms"
        end)
    end)

    B(function()
        if not A.AH_LEGACY then return Skp("T98", "D", "Server-Wege altes AH", "nur im alten Client (Classic Era, TBC)") end
        Chk("T98", "D", "Server-Wege altes AH", function()
            local n = TradeCount("PlaceBid") + TradeCount("PostAuction") + TradeCount("PostItem")
            return true, string.format("Scan, Suchen und Handel siehe bisheriger Selbsttest oben; %d Handels-Befehle nur im Protokoll", n),
                "wie 0.64.2"
        end)
    end)
end

function TR:BuildSteps(part)
    local B = function(fn) self:Step(fn) end
    local Chk = function(...) return self:Check(...) end
    local Skp = function(...) return self:Skip(...) end
    local Cli = function(...) return self:Client(...) end
    local g = G()
    local modern = not A.AH_LEGACY

    -- ---------------- A. Laden und Erkennung ----------------
    if want(part, "a") then B(function()
        Chk("T01", "A", "alle Module geladen", function()
            local miss = {}
            for _, k in ipairs({ "Sniper", "Watcher", "Buy", "Seller", "Ledger", "Lists", "Watchlist", "Crafting", "Disenchant",
                "Chars", "Mailer", "Extras", "Comfort", "Today", "Sync", "Names", "Tooltip", "UI", "SelfTest", "TestMode",
                "Inbox", "AH", "TestRoutine" }) do
                if A[k] == nil then miss[#miss + 1] = k end
            end
            for _, l in ipairs({ "frFR", "esES", "esMX", "ptBR", "itIT", "ruRU", "koKR", "zhCN", "zhTW", "enUS" }) do
                if type(A.T[l]) ~= "table" then miss[#miss + 1] = "Locale " .. l end
            end
            if A.Names and A.Names.HasBuiltin then
                for _, l in ipairs({ "enUS", "deDE", "frFR", "esES", "esMX", "ptBR", "ruRU", "koKR", "zhCN", "zhTW" }) do
                    if not A.Names:HasBuiltin(l) then miss[#miss + 1] = "Names " .. l end
                end
            end
            return #miss == 0, #miss == 0 and "alle da" or table.concat(miss, ", "), "keine fehlen"
        end)
        Chk("T02", "A", "Version .toc = Code", function()
            local get = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
            local v = get and get("AHSentinel", "Version")
            return v == A.version, tostring(v), A.version
        end)
        Chk("T03", "A", "Addon nicht veraltet", function()
            local info = (C_AddOns and C_AddOns.GetAddOnInfo) or GetAddOnInfo
            local iface = GetBuildInfo and select(4, GetBuildInfo())
            if not info then return "SKIP", "Client ohne GetAddOnInfo (Interface " .. tostring(iface) .. ")" end
            local _, _, _, loadable, reason = info("AHSentinel")
            return reason ~= "INTERFACE_VERSION", "Interface " .. tostring(iface) .. ", Grund " .. tostring(reason), "kein INTERFACE_VERSION"
        end)
        Chk("T04", "A", "gemeinsame Dateien", function()
            local D, T = _G.GoldSentinelDev, GTest()
            local bad = {}
            if not (g and g.version and g.version >= 2 and g.apiVersion) then bad[#bad + 1] = "GoldSentinelGame" end
            if g and type(g.Status) == "function" and type(g.Status()) ~= "string" then bad[#bad + 1] = "Status" end
            if g and g.IsForever and not g.IsModern then bad[#bad + 1] = "Forever nicht modern" end
            if not (D and (D.version or 0) >= 1) then bad[#bad + 1] = "GoldSentinelDev" end
            if not (T and T.version >= 1 and T.registry and T.registry["AHSentinel"]) then bad[#bad + 1] = "GoldSentinelTest/TrackErrors" end
            return #bad == 0, #bad == 0 and (g and g.Status() or "") or table.concat(bad, ", "), "alles erfüllt"
        end)
        Chk("T05", "A", "Weichen je Client simuliert", function()
            if not (g and g.SetTestFlavor) then return false, "SetTestFlavor fehlt" end
            local prevForce, before = A.forceForever, A:IsForever()
            A.forceForever = nil
            local bad = {}
            local ok, err = pcall(function()
                for _, f in ipairs({ "forever", "era", "tbc", "retail" }) do
                    g.SetTestFlavor(f)
                    if A:IsForever() ~= (f == "forever") then bad[#bad + 1] = f .. ": IsForever" end
                    if A:DepositRefunded() ~= (f ~= "forever") then bad[#bad + 1] = f .. ": DepositRefunded" end
                    if A:SaleFee(nil, 50, 1, 1) ~= (f == "forever" and 100 or 3) then bad[#bad + 1] = f .. ": SaleFee" end
                    if f == "forever" and A.Comfort:RaidSetKey() ~= "classic" then bad[#bad + 1] = "forever: RaidSetKey" end
                end
            end)
            g.SetTestFlavor(nil)
            A.forceForever = prevForce
            if not ok then error(err, 0) end
            if A:IsForever() ~= before then bad[#bad + 1] = "nach dem Test andere Erkennung" end
            if tostring(g.Status()):find("%[") then bad[#bad + 1] = "Status zeigt noch [Test]" end
            return #bad == 0, #bad == 0 and "RaidSetKey für era/tbc folgt WOW_PROJECT_ID" or table.concat(bad, "; "), "alles erfüllt"
        end)
        Chk("T06", "A", "Ladereihenfolge", function()
            local T = GTest()
            return T ~= nil and _G.GoldSentinelDev ~= nil and g ~= nil, nil, "Dev, Game, Test vor Locale.lua geladen"
        end)
        Chk("T07", "A", "AH-Weiche", function()
            local expectLegacy = (not (C_AuctionHouse and C_AuctionHouse.SendBrowseQuery)) and QueryAuctionItems ~= nil
            local realAH = ST.realAH or A.AH
            local ok = (A.AH_LEGACY and true or false) == (expectLegacy and true or false)
            if A.AH_LEGACY then ok = ok and realAH ~= C_AuctionHouse and realAH.SendBrowseQuery ~= nil
            else ok = ok and realAH == C_AuctionHouse end
            return ok, A.AH_LEGACY and "klassisch" or "modern", expectLegacy and "klassisch" or "modern"
        end)
        Chk("T08", "A", "Berufe-Weiche", function()
            local k = A.Crafting:TradeKind()
            local expect = GetNumTradeSkills and "trade" or "modern"
            return k == expect, k, expect
        end)
        if modern then Cli("T08c", "A", "Berufe-Weiche (Forever)", "/dump GetNumTradeSkills – muss nil sein, sonst liest das Addon die alte Liste") end
        Chk("T09", "A", "Tooltip-Weg", function()
            local m = A.Tooltip and A.Tooltip.mode
            local expect = TooltipDataProcessor and "TooltipDataProcessor" or "OnTooltipSetItem"
            return type(m) == "string" and m:find(expect, 1, true) ~= nil, tostring(m), expect
        end)
        Chk("T10", "A", "Chat-Befehle registriert", function()
            local ok = SLASH_AHANALYZERPRO1 == "/ahs" and SLASH_AHANALYZERPRO2 == "/ahsentinel" and SLASH_AHANALYZERPRO3 == "/ahp"
                and SLASH_AHANALYZERPRO4 == "/ahanalyzer" and type(SlashCmdList.AHANALYZERPRO) == "function"
                and SlashCmdList.GOLDSENTINELGAME ~= nil
            return ok, nil, "/ahs, /ahsentinel, /ahp, /ahanalyzer, /gsgame"
        end)
    end) end

    -- ---------------- B. Jede Funktion (Auswahl ohne Spieler-Handlung) ----------------
    if want(part, "b") then
        -- bisheriger Selbsttest mit gespeicherten Daten (Server-Teile werden übersprungen)
        if part == "auto" or part == "b" then
            if Count(A.db.marketData) > 0 then self:AddOldSteps(true)
            else B(function() Skp("S00", "B", "bisheriger Selbsttest", "keine gespeicherten Marktdaten - erst einmal scannen") end) end
        end
        B(function()
        Chk("T11", "B", "Geld anzeigen und lesen", function()
            local bad = {}
            for _, x in ipairs({ 1, 99, 10000, 1234567 }) do
                if A:ParseGold(A:FormatMoneyInput(x)) ~= x then bad[#bad + 1] = tostring(x) end
            end
            local s = A:FormatMoney(123456)
            if not (s:find("12") and s:find("34") and s:find("56")) then bad[#bad + 1] = "FormatMoney" end
            if A:PlainText("|cffff0000a|r|Tx:0|tb") ~= "ab" then bad[#bad + 1] = "PlainText" end
            return #bad == 0, table.concat(bad, ", "), "alle Rundläufe gleich"
        end)
        Chk("T12", "B", "Ereignis-Bus", function()
            local got
            A:On("AHS_TEST", function() error("AHS-Test Zuhörer") end)
            A:On("AHS_TEST", function(v) got = v end)
            Capture(function() A:Fire("AHS_TEST", 1) end)
            A.listeners["AHS_TEST"] = nil
            self:ClearTestErrors()
            return got == 1, tostring(got), "1 (zweiter Zuhörer läuft trotz Fehler im ersten)"
        end)
        Chk("T13", "B", "Preis-Kern mit Testdaten", function()
            local id, now = FAKE, time()
            local ok, err = pcall(function()
                A:RecordPrice(id, 100, 1, now - 1000)
                A:RecordPrice(id, 200, 1, now - 500)
                A:RecordPrice(id, 300, 1, now)
            end)
            local cur, n, mv = A:GetCurrent(id), #A:GetHistory(id), A:GetMarketValue(id)
            A.db.marketData[id] = nil
            if A.InvalidateMarket then pcall(A.InvalidateMarket, A, id) end
            if not ok then error(err, 0) end
            local good = cur == 300 and n == 3 and mv and mv >= 100 and mv <= 300
            return good and A.db.marketData[id] == nil, string.format("aktuell %s, Einträge %d, Marktwert %s", tostring(cur), n, tostring(mv)),
                "300, 3, 100–300"
        end)
        Chk("T17", "B", "Händler-Verkaufspreis", function()
            local p = A:GetVendorPrice(LINEN)
            return p == nil or (type(p) == "number" and p >= 0), tostring(p), "Zahl >= 0"
        end)
        Chk("T18", "B", "Händler-Scan mit Testhändler (moderner und alter Weg)", function()
            local db = A.db
            local items = {
                { id = FAKE + 10, price = 100, stack = 5, avail = -1 },
                { id = FAKE + 11, price = 100, stack = 1, avail = 3 },
                { id = FAKE + 12, price = 0, stack = 1, avail = -1, ext = true },
            }
            local cmf = { GetNumItems = function() return #items end,
                GetItemInfo = function(i) local e = items[i]; return e and { price = e.price, stackCount = e.stack, numAvailable = e.avail, hasExtendedCost = e.ext } end }
            local common = {
                GetMerchantItemLink = function(i) return items[i] and ("item:" .. items[i].id) end,
                GetMerchantItemCostInfo = function(i) return items[i] and items[i].ext and 1 or 0 end,
                GetMerchantItemCostItem = function(i) return nil, 2, "currency:3001", "Testwährung" end,
            }
            local results = {}
            for _, way in ipairs({ "modern", "alt" }) do
                local o = {}
                for k, v in pairs(common) do o[k] = v end
                if way == "modern" then o.C_MerchantFrame = cmf; o.GetMerchantNumItems = false; o.GetMerchantItemInfo = false
                else
                    o.C_MerchantFrame = false
                    o.GetMerchantNumItems = function() return #items end
                    o.GetMerchantItemInfo = function(i) local e = items[i]; return "x", nil, e.price, e.stack, e.avail, true, nil, e.ext end
                end
                A.apiOverride = o
                local ok, n = pcall(A.ScanMerchant, A)
                A.apiOverride = nil
                local c = db.vendorCost and db.vendorCost[FAKE + 12]
                results[way] = string.format("%s/%s/%s/%s", tostring(ok and n), tostring(db.vendorBuy[FAKE + 10]),
                    tostring(db.vendorBuy[FAKE + 11]), c and c.costs and c.costs[1] and (c.costs[1].kind .. ":" .. tostring(c.costs[1].id) .. "x" .. tostring(c.costs[1].amount)) or "nil")
                for k = 10, 12 do db.vendorBuy[FAKE + k] = nil; if db.vendorCost then db.vendorCost[FAKE + k] = nil end end
            end
            local want = "2/20/nil/currency:3001x2"
            return results.modern == want and results.alt == want, "modern " .. results.modern .. ", alt " .. results.alt, want
        end)
        Chk("T22", "B", "15-Minuten-Sperre", function()
            local saved = A.db.lastScanTime
            A.db.lastScanTime = time() - 100
            local rem, ready = A:GetCooldownRemaining(), A:IsScanReady()
            A.db.lastScanTime = saved
            return A.SCAN_COOLDOWN == 900 and rem >= 799 and rem <= 800 and not ready, tostring(rem), "800, gesperrt"
        end)
        Chk("T23", "B", "Anfrage-Drossel", function()
            local p = A.pace
            local errs, gap = p.errors, p.gap
            local r = A:QueryReady()
            A:QueryError()
            local grew = p.errors == errs + 1
            p.errors, p.gap = errs, gap
            return type(r) == "boolean" and A:QueryGap() >= 0 and grew, nil, "boolean, Abstand >= 0, Fehlerzähler +1"
        end)
        Chk("T29", "B", "Minikarten-Winkel", function()
            local st = A.db.settings
            local before = st.minimapAngle
            if not A.SetMinimapAngle then return true, "kein Minikarten-Knopf" end
            A:SetMinimapAngle(90)
            local v = st.minimapAngle
            A:SetMinimapAngle(before or 225)
            st.minimapAngle = before
            return v == 90, tostring(v), "90"
        end)
        Chk("T38", "B", "Einkauf-Favoriten", function()
            local K = A.Comfort
            local favs = K.FavDB()
            if #favs >= K.MAX_FAVS - 1 then return "SKIP", "Favoriten fast voll" end
            local saved = Copy(favs)
            local ok1 = K:AddFavorite({ text = "AHS-Test" })
            local ok2 = K:AddFavorite({ text = "AHS-Test" })
            Replace(favs, saved)
            return ok1 and not ok2, string.format("erst %s, doppelt %s", tostring(ok1), tostring(ok2)), "erst true, doppelt false"
        end)
        Chk("T47", "B", "Verkaufen rechnen", function()
            local Se = A.Seller
            if not (Se and Se.Undercut) then return "SKIP", "Undercut fehlt" end
            local u = Se:Undercut(1000)
            return type(u) == "number" and u < 1000 and u > 0 and Se:Undercut(1) >= 1, tostring(u), "< 1000, Undercut(1) >= 1"
        end)
        Chk("T61", "B", "Einkaufslisten", function()
            local Li = A.Lists
            local name = "AHS-Test"
            local existed = Li:Exists(name)
            if existed then return "SKIP", "Liste AHS-Test gab es schon" end
            Li:Create(name)
            Li:AddItem(name, tostring(LINEN), 5)
            local n = Li:Count(name)
            Li:Delete(name)
            return n == 1 and not Li:Exists(name), tostring(n), "1, danach weg"
        end)
        Chk("T68", "B", "Gold-Ziel", function()
            local K = A.Comfort
            local before = K:GoldGoal()
            Capture(function() K:GoalCommand("5000") end)
            local v = K:GoldGoal()
            Capture(function() K:GoalCommand("aus") end)
            local off = K:GoldGoal()
            K:SetGoldGoal(before)
            return v == 50000000 and off == nil, tostring(v) .. " / " .. tostring(off), "50000000 / nil"
        end)
        Chk("T70", "B", "Raid-Vorrat", function()
            local K, Li = A.Comfort, A.Lists
            local name = L["Raid-Vorrat"]
            local existed = Li:Exists(name)
            local key = K:RaidSetKey()
            if not key then
                local ok, msg = K:CreateRaidList(1)
                return ok == false, "keine Vorlage für diesen Client", "Meldung statt Liste"
            end
            local ok = K:CreateRaidList(1)
            local n = Li:Count(name)
            if not existed then Li:Delete(name) end
            return ok and n == #K.RAID_SETS[key], tostring(n), tostring(#K.RAID_SETS[key])
        end)
        Chk("T74", "B", "Item-Namen und Suche", function()
            local N = A.Names
            local de = N:Get(LINEN, "deDE")
            return de == "Leinenstoff" and N:ParseID("item:" .. LINEN) == LINEN and N:Resolve(tostring(LINEN)) == LINEN,
                tostring(de), "Leinenstoff, 2589"
        end)
        Chk("T75", "B", "Sync-Empfang (Testnachricht)", function()
            local S = A.Sync
            local sdb = A.db.sync
            if not (S and S.OnMessage and sdb) then return "SKIP", "Preis-Sync nicht geladen" end
            local saved = Copy(sdb)
            local heard = S.heardScanTime or 0
            sdb.enabled = true
            local ok, err = pcall(function()
                S:OnMessage("AHAP1", "H:" .. S.Enc(heard + 1), S:GuildOnly() and "GUILD" or "CHANNEL", "AHS-Testpeer-Realm")
            end)
            local after = S.heardScanTime or 0
            Replace(sdb, saved)
            S.heardScanTime = heard
            if not ok then error(err, 0) end
            return after == heard + 1, "heardScanTime +" .. tostring(after - heard), "+1, Daten danach wie vorher"
        end)
        Chk("T76", "B", "Sync senden nur simuliert, Kodierung", function()
            local S = A.Sync
            local bad = {}
            for _, n in ipairs({ 0, 1, 35, 36, 123456789 }) do
                if S.Dec(S.Enc(n)) ~= n then bad[#bad + 1] = tostring(n) end
            end
            return #bad == 0 and A:Simulated(), #bad == 0 and "Rundlauf ok, A:Simulated() = true" or table.concat(bad, ", "), "alle gleich"
        end)
        Chk("T78", "B", "Testmodus während der Routine abgelehnt", function()
            local lines, ok = Capture(function() return TM:Start() end)
            return ok == false and not TM.active, tostring(ok), "false"
        end)
        Chk("T79", "B", "Diagnose", function()
            local lines = Capture(function() A:PrintDebug() end)
            local all = table.concat(lines, "\n")
            local need = (g and g.Status and A:PlainText(g.Status())) or ""
            local errLine = A:PlainText(L["Fehler seit Login: %d · Berichte offen: %d"]):match("^[^%%]+") or "?"
            local good = all:find(A.version, 1, true) ~= nil and all:find(need, 1, true) ~= nil and all:find(errLine, 1, true) ~= nil
            return good, string.format("%d Zeilen", #lines), "Version, Spielversion, Fehlerzeile"
        end)
        end)
    end

    -- ---------------- B. Oberfläche, Optionen, Befehle, Rechnen (0.65.7) ----------------
    if want(part, "b") then
        local UI = A.UI
        local function Shown(f) return f and f.IsShown and f:IsShown() or false end
        local function Click(b, button)
            if not b then error("Knopf fehlt", 0) end
            local f = b:GetScript("OnClick")
            if not f then error("Knopf ohne OnClick", 0) end
            return f(b, button or "LeftButton")
        end
        local function Opt() UI:ShowOptions(); return UI.options end
        local function Eff(v) return v ~= false end          -- nil = Standard "an"
        local function HideAll()
            for _, k in ipairs({ "options", "helpWindow", "textWindow", "donateWindow", "listsWindow", "todayWin",
                "mailRulesWindow", "chartWin" }) do
                if UI[k] then UI[k]:Hide() end
            end
            if UI.HideMenu then UI:HideMenu() end
        end
        -- zurückgeschriebene Fenster-Werte auch anwenden (Grösse, Position, Zoom, Minikarten-Knopf)
        local function ApplyLayout()
            local st, f = A.db.settings, UI.frame
            if f then
                f.fitW = nil
                pcall(UI.FitToAH, UI)
                local pos = st.windowPos
                f:ClearAllPoints()
                if pos then f:SetPoint(pos.point or "CENTER", UIParent, pos.relPoint or "CENTER", pos.x or 0, pos.y or 0)
                else f:SetPoint("CENTER") end
            end
            if st.ahZoom and UI.SetAHZoom then pcall(UI.SetAHZoom, UI, st.ahZoom) end
            if A.SetMinimapButtonShown then A:SetMinimapButtonShown(not st.minimapHide) end
            if st.minimapAngle then A:SetMinimapAngle(st.minimapAngle) end
        end
        B(function()
        Chk("T24", "B", "Hauptfenster und Designs", function()
            local theme = A.db.settings.theme
            UI:Show(); local v1 = UI:IsVisible()
            UI:Hide(); local v2 = UI:IsVisible()
            UI:Toggle(); local v3 = UI:IsVisible()
            UI:SetTheme("modern"); UI:SetTheme("classic"); UI:SetTheme(theme or "classic")
            ApplyLayout()
            return v1 and not v2 and v3 and A.db.settings.theme == theme,
                string.format("%s/%s/%s, Design %s", tostring(v1), tostring(not v2), tostring(v3), tostring(A.db.settings.theme)),
                "zeigen/verstecken/umschalten, Design wie vorher"
        end)
        local extra = {
            { "T26c", "Hilfe (jede Seite)", function()
                local help = (A.uiLang == "deDE" and UI.HELP_DE) or A.HELP[A.uiLang] or UI.HELP_EN
                local n = 0
                for id in pairs(help or {}) do UI:ShowHelp(id); n = n + 1 end
                return Shown(UI.helpWindow) and n > 0, n .. " Seiten"
            end },
            { "T26d", "Einkaufslisten", function() UI:ShowLists(); local s = Shown(UI.listsWindow); UI:ToggleLists(); return s end },
            { "T26e", "Heute tun", function() UI:ShowToday(); return Shown(UI.todayWin) end },
            { "T26f", "Post-Regeln", function() UI:ShowMailRules(); return Shown(UI.mailRulesWindow) end },
            { "T26g", "Unterstützen", function() UI:ShowDonate(); return Shown(UI.donateWindow) end },
            { "T26h", "Textfenster", function() UI:ShowTextWindow("Test", "Test"); return Shown(UI.textWindow) end },
            { "T26i", "Item-Menü", function()
                local inList = A.Watchlist:Contains(LINEN)
                Capture(function()
                    for _, act in ipairs({ "chart", "watch", "watch", "sniper", "list" }) do
                        UI:ShowItemMenu(LINEN, UIParent); UI:OnMenuClick(act)
                    end
                    if A:IsAHOpen() then UI:ShowItemMenu(LINEN, UIParent); UI:OnMenuClick("ah") end
                end)
                return A.Watchlist:Contains(LINEN) == inList, "Watchlist danach wie vorher"
            end },
        }
        for _, w in ipairs(extra) do
            Chk(w[1], "B", "Zusatzfenster " .. w[2], function()
                local ok, detail = w[3]()
                HideAll()
                return ok and true or false, detail or (ok and "öffnet und schließt" or "nicht offen"), "öffnet und schließt"
            end)
        end
        Chk("T28", "B", "Größe, Zoom, Position", function()
            local st = A.db.settings
            local KEYS = { "scale", "windowPos", "buttonPos", "ahZoom", "windowSize", "minimapAngle", "minimapHide" }
            local saved = {}
            for _, k in ipairs(KEYS) do saved[k] = Copy(st[k]) end
            UI:SetScale((st.scale or 1) + 0.05); UI:SetScale((saved.scale or 1))
            if UI.SetAHZoom and UI.AHZoom then UI:SetAHZoom(UI:AHZoom()) end
            if UI.ResetWindowSize then UI:ResetWindowSize() end
            UI:ResetPosition()
            if A.ResetButtonPosition then Capture(A.ResetButtonPosition, A) end
            -- auch nil zurückschreiben (pairs überspringt nil: war ahZoom vorher nil, blieb der Testwert stehen)
            for _, k in ipairs(KEYS) do st[k] = saved[k] end
            ApplyLayout()
            return true, "ohne Fehler, Werte zurück"
        end)
        end)

        -- T30.xx: jede Option einmal an und aus (wie ein Klick im Optionsfenster)
        local OPTIONS = {
            { "01", "Design", function()
                local theme = A.db.settings.theme
                Click(Opt().modernBtn); local m = A.db.settings.theme
                Click(Opt().classicBtn); local c = A.db.settings.theme
                UI:SetTheme(theme or "classic")
                return m == "modern" and c == "classic", m .. "/" .. c
            end },
            { "02", "Im AH anzeigen", "ahBtn", "ahIntegration" },
            { "03", "Preis im Tooltip", "ttInfoBtn", "tooltipInfo" },
            { "04", "Preisverlauf im Tooltip", function()
                local before, steps = A.Tooltip:ChartDays(), {}
                for _ = 1, 8 do
                    Click(Opt().ttChartBtn)
                    steps[#steps + 1] = tostring(A.Tooltip:ChartDays())
                    if A.Tooltip:ChartDays() == before then break end
                end
                return A.Tooltip:ChartDays() == before and #steps > 1, table.concat(steps, ",")
            end },
            { "05", "Händlerpreis im Tooltip", "ttVendorBtn", "tooltipVendor" },
            { "06", "Twinks im Tooltip", "ttCharsBtn", "tooltipChars" },
            { "07", "Entzauberwert im Tooltip", "ttDEBtn", "tooltipDE" },
            { "40", "Mit dem Auktionshaus öffnen", "openAHBtn", "openWithAH" },
            { "39", "Entzauber-Details im Tooltip", function()
                local seen = {}
                for _ = 1, 3 do Click(Opt().ttDEDetailBtn); seen[#seen + 1] = A.Tooltip:DEMode() end
                return #seen == 3 and seen[1] ~= seen[2] and seen[2] ~= seen[3] and seen[3] ~= seen[1], table.concat(seen, ",")
            end },
            { "08", "Entzaubern zurücksetzen (Sandbox)", function()
                local stats, shared = Copy(A.db.deStats), Copy(A.db.deShared)
                local w = Opt()
                Click(w.deReset); local asked = w.deConfirm
                Click(w.deReset)
                local cleared = next(A.db.deStats or {}) == nil
                A.db.deStats, A.db.deShared = stats, shared
                return asked and cleared, "Rückfrage " .. tostring(asked) .. ", geleert " .. tostring(cleared)
            end },
            { "09", "Knöpfe am Briefkasten", "mailBtn", "mailButtons" },
            { "10", "Meldung bei Verkauf", "saleBtn", "saleAlert" },
            { "11", "Preisschutz", function()
                local before, seen = A.Seller:GuardPercent(), {}
                for _ = 1, #A.Seller.GUARD_STEPS do Click(Opt().guardBtn); seen[#seen + 1] = A.Seller:GuardPercent() end
                return A.Seller:GuardPercent() == before, table.concat(seen, ",")
            end },
            { "12", "Gewinn im Berufsfenster", "craftBtn", "craftPanel" },
            { "13", "Sprache des Addons", function()
                local v = A:UILanguageSetting()
                Click(Opt().uiLangBtn); local mid = A:UILanguageSetting()
                Click(Opt().uiLangBtn, "RightButton"); local back = A:UILanguageSetting()
                if back ~= v then A:SetUILanguage(v) end
                return mid ~= v and back == v, v .. " -> " .. mid .. " -> " .. back
            end },
            { "14", "Item-Namen-Sprache", function()
                local before, n = A.db.settings.nameLocale, 0
                repeat Click(Opt().langBtn); n = n + 1 until A.db.settings.nameLocale == before or n > 20
                return A.db.settings.nameLocale == before, n .. " Klicks bis zurück"
            end },
            { "15", "Geldanzeige", "moneyBtn", "moneyStyle", function(v) return v == "letters" end },
            { "16", "Fenstergröße", function()
                local sc = A.db.settings.scale or 1
                Click(Opt().scaleUp); Click(Opt().scaleDown)
                return math.abs((A.db.settings.scale or 1) - sc) < 0.001, tostring(A.db.settings.scale)
            end },
            { "17", "Schrift- und Inhaltsgröße", function()
                local z = A.db.settings.ahZoom or 1
                Click(Opt().zoomUp); local up = A.db.settings.ahZoom or 1
                Click(Opt().zoomDown); local down = A.db.settings.ahZoom or 1
                A.db.settings.ahZoom = z
                return (up > z or z >= 1.6) and math.abs(down - z) < 0.001, string.format("%.2f -> %.2f -> %.2f", z, up, down)
            end },
            { "18", "Ton", "soundBtn", "alertSound", function(v) return v and true or false end },
            { "19", "Preise teilen (nur simuliert)", function()
                local j, l = self.real.JoinTemporaryChannel or 0, self.real.LeaveChannelByName or 0
                local on = A.Sync:IsEnabled() and true or false
                Capture(Click, Opt().syncBtn); local mid = A.Sync:IsEnabled() and true or false
                Capture(Click, Opt().syncBtn)
                return mid ~= on and (self.real.JoinTemporaryChannel or 0) == j and (self.real.LeaveChannelByName or 0) == l,
                    "an/aus, Kanal-Beitritt/-Austritt 0"
            end },
            { "20", "nur Gilde", function()
                local gOnly = A.Sync:GuildOnly()
                Capture(Click, Opt().syncGuildBtn); local mid = A.Sync:GuildOnly()
                Capture(Click, Opt().syncGuildBtn)
                return mid ~= gOnly and A.Sync:GuildOnly() == gOnly, tostring(mid)
            end },
            { "21", "Sniper-Intervall", function()
                local v = A.db.sniper.interval or 0
                Click(Opt().snipeUp); local up = A.db.sniper.interval or 0
                Click(Opt().snipeDown); local down = A.db.sniper.interval or 0
                A.db.sniper.interval = v
                return up ~= v and down == v, string.format("%s -> %s -> %s", tostring(v), tostring(up), tostring(down))
            end },
            { "22", "Sniper-Taste (Mausrad)", function()
                local binds = Copy(A.db.sniper.binds)
                A.Sniper:UseMouseWheel("sniper")
                local wheel = A.Sniper:IsMouseWheelBind("sniper")
                A.db.sniper.binds = binds
                return wheel, A.Sniper:GetBindsText("sniper")
            end },
            { "23", "Wächter-Taste (Mausrad)", function()
                local binds = Copy(A.db.watcher.binds)
                A.Sniper:UseMouseWheel("watcher")
                local wheel = A.Sniper:IsMouseWheelBind("watcher")
                A.db.watcher.binds = binds
                return wheel, A.Sniper:GetBindsText("watcher")
            end },
            { "24", "Tagesbilanz + Jetzt zeigen", function()
                local v = A.db.settings.dailySummary
                Click(Opt().dailyBtn); local mid = A.db.settings.dailySummary
                Click(Opt().dailyBtn)
                Capture(Click, Opt().dailyNow)
                return Eff(mid) ~= Eff(v), "umgeschaltet"
            end },
            { "25", "Knopf beim Händler", "vendorBtn", "vendorButton", function() return UI:VendorButtonEnabled() end },  -- Standard hängt an LevelPilot
            { "26", "Post an Twinks (Regeln)", function()
                Click(Opt().rulesBtn)
                return Shown(UI.mailRulesWindow), "Regeln-Fenster"
            end },
            { "27", "Minikarte", function()
                local hide = A.db.settings.minimapHide and true or false
                Click(Opt().minimapBtn); local mid = A.db.settings.minimapHide and true or false
                Click(Opt().minimapBtn)
                return mid ~= hide and (A.db.settings.minimapHide and true or false) == hide, "aus/an"
            end },
            { "28", "Post automatisch abholen", "autoMailBtn", "autoCollect" },
            { "29", "Alt-Klick", "altClickBtn", "altClick" },
            { "30", "Verkaufschance im Tooltip", "chanceBtn", "tooltipChance" },
            { "31", "Ablauf-Erinnerung", "expiryBtn", "expiryReminder" },
            { "32", "Gold-Ziel setzen/löschen", function()
                Capture(function() A.Comfort:SetGoldGoal(5000 * 10000); A.Comfort:SetGoldGoal(nil) end)
                return A.Comfort:GoldGoal() == nil, "gesetzt und gelöscht"
            end },
            { "33", "Zeile Selbsttest nur für Dev", function()
                local b = Opt().selfTestBtn
                return b:IsShown() == (A:IsDev() and true or false), "sichtbar " .. tostring(b:IsShown())
            end },
            { "34", "CSV-Export", function()
                local lines = Capture(Click, Opt().exportBtn)
                if Count(A.db.marketData) == 0 then
                    return table.concat(lines, "\n"):find(A:PlainText(L["Noch keine Daten zum Exportieren. Erst einen Scan machen."]), 1, true) ~= nil,
                        "keine Daten: Hinweis"
                end
                return Shown(UI.textWindow), "Textfenster mit CSV"
            end },
            { "35", "Positionen", function()
                local st = A.db.settings
                local KEYS = { "windowPos", "windowSize", "buttonPos", "minimapAngle", "minimapHide" }
                local saved = {}
                for _, k in ipairs(KEYS) do saved[k] = Copy(st[k]) end
                Capture(Click, Opt().resetBtn)
                local reset = st.windowPos == nil and st.windowSize == nil
                for _, k in ipairs(KEYS) do st[k] = saved[k] end
                return reset, "zurückgesetzt " .. tostring(reset) .. ", Werte danach zurück"
            end },
            { "36", "Unterstützen", function() Click(Opt().donateBtn); return Shown(UI.donateWindow), "Fenster" end },
            { "37", "Warnung Einstellgebühr", function()
                local before, seen = A.Seller:FeeWarnPercent(), {}
                for _ = 1, #A.Seller.FEE_WARN_STEPS do Click(Opt().feeBtn); seen[#seen + 1] = A.Seller:FeeWarnPercent() end
                return A.Seller:FeeWarnPercent() == before, table.concat(seen, ",")
            end },
            { "38", "Unter Händlerpreis ab", function()
                local before, seen = A:VendorFlipMin(), {}
                for _ = 1, 5 do Click(Opt().vflipBtn); seen[#seen + 1] = A:VendorFlipMin() end
                return A:VendorFlipMin() == before, table.concat(seen, ",")
            end },
        }
        -- pro Option ein eigener Schritt (SLICE_MS, kein "script ran too long" bei mehreren UI:Rebuild)
        for _, o in ipairs(OPTIONS) do
        B(function()
            Chk("T30." .. o[1], "B", "Option " .. o[2], function()
                local st = A.db.settings
                local snap = Copy(st)
                local res = { pcall(function()
                    if type(o[3]) == "function" then return o[3]() end
                    local field, key, eff = o[3], o[4], o[5] or Eff
                    local v0 = eff(st[key])
                    Click(Opt()[field]); local v1 = eff(st[key])
                    Click(Opt()[field]); local v2 = eff(st[key])
                    return (v1 ~= v0) and (v2 == v0), string.format("%s: %s -> %s -> %s", key, tostring(v0), tostring(v1), tostring(v2))
                end) }
                -- Einstellungen genau wie vorher (nil/true-Unterschiede der Umschalter), Fenster zu
                for k, v in pairs(snap) do if k ~= "theme" and k ~= "uiLanguage" then st[k] = Copy(v) end end
                for k in pairs(st) do if snap[k] == nil then st[k] = nil end end
                if o[1] == "16" or o[1] == "17" or o[1] == "35" then ApplyLayout() end
                HideAll()
                if not res[1] then error(res[2], 0) end
                return res[2] and true or false, res[3], "umgeschaltet und zurück"
            end)
        end)
        end

        -- T31.xx: jeder Chat-Befehl (A:Print abgefangen)
        local function Has(lines, text) return table.concat(lines, "\n"):find(A:PlainText(text), 1, true) ~= nil end
        local CMDS = {
            { "01", "" }, { "02", "show" },
            -- Die Routine sperrt den Markt-Scan (ST:Lock). AH zu: für diesen einen Aufruf den echten Start einsetzen
            -- (er lehnt ab, weil das AH zu ist) und sofort zurückstellen. AH offen: Sperre bleibt, sonst liefe ein echter Scan.
            { "03", "scan", function(out, ahOpen)
                if ahOpen then return Has(out, L["Selbsttest läuft - ein Markt-Scan ist solange gesperrt."]) end
                return Has(out, L["Bitte zuerst das Auktionshaus öffnen."]) and not A:IsScanning()
            end, function(run)
                if A:IsAHOpen() or not ST.origScan then return run() end
                local locked = A.StartFullScan
                A.StartFullScan = ST.origScan
                local r = { pcall(run) }
                A.StartFullScan = locked
                if not r[1] then error(r[2], 0) end
                return unpack(r, 2)
            end },
            { "04", "export" }, { "05", "debug", function(out) return Has(out, g.Status()) end },
            { "06", "reset" }, { "07", "resetscan" }, { "08", "sync" }, { "09", "sync" }, { "10", "ahdebug" }, { "11", "ah" },
            { "12", "sniper" }, { "13", "sniper" }, { "14", "design" }, { "15", "design" }, { "16", "optionen" },
            { "17", "options" }, { "18", "spenden" }, { "19", "donate" }, { "20", "bilanz" }, { "21", "summary" },
            { "22", "ziel 5000", function() return A.Comfort:GoldGoal() == 50000000 end }, { "23", "ziel" },
            { "24", "ziel aus", function() return A.Comfort:GoldGoal() == nil end },
            { "25", "heute" }, { "26", "today" }, { "27", "minikarte" }, { "28", "minikarte" }, { "29", "raid" },
            { "30", "twinks" }, { "31", "sprache" }, { "32", "listen" }, { "33", "hilfe" }, { "34", "handbuch" },
            { "35", "xyz", function(out) return Has(out, string.format(L["Unbekannter Befehl: %s"], "xyz")) end },
        }
        -- pro Befehl ein eigener Schritt (SLICE_MS)
        for _, cmd in ipairs(CMDS) do
        B(function()
            if cmd[2] == "resetscan" and A:IsScanning() then
                Skp("T31." .. cmd[1], "B", "Befehl /ahs resetscan", "Markt-Scan läuft - würde ihn abbrechen")
            else
            Chk("T31." .. cmd[1], "B", "Befehl /ahs " .. cmd[2], function()
                local st = A.db.settings
                local snap = { goal = st.goldGoal, reached = st.goldGoalReached, ui = UI:IsVisible(), lang = st.uiLanguage or "auto",
                    theme = st.theme, raid = A.Lists:Exists(L["Raid-Vorrat"]), windowPos = Copy(st.windowPos),
                    windowSize = Copy(st.windowSize), buttonPos = Copy(st.buttonPos), minimapAngle = st.minimapAngle,
                    minimapHide = st.minimapHide, armed = A.Sniper:IsArmed() }
                local ahOpen = A:IsAHOpen()
                local function run() return pcall(Capture, SlashCmdList.AHANALYZERPRO, cmd[2]) end
                local res = { (cmd[4] or function(f) return f() end)(run) }
                local ok = res[1] and (not cmd[3] or cmd[3](res[2], ahOpen) and true or false)
                -- Folgen zurück (Sprache direkt setzen: nur ein Neuaufbau statt einer Runde durch alle Sprachen)
                if cmd[2] == "sprache" and A:UILanguageSetting() ~= snap.lang then A:SetUILanguage(snap.lang) end
                if cmd[2] == "raid" and not snap.raid and A.Lists:Exists(L["Raid-Vorrat"]) then A.Lists:Delete(L["Raid-Vorrat"]) end
                if (A.Sniper:IsArmed() and true or false) ~= (snap.armed and true or false) then A.Sniper:SetArmed(snap.armed and true or false) end
                st.goldGoal, st.goldGoalReached = snap.goal, snap.reached
                for _, k in ipairs({ "windowPos", "windowSize", "buttonPos", "minimapAngle", "minimapHide" }) do st[k] = snap[k] end
                if cmd[2] == "reset" then ApplyLayout() end
                if A.SetMinimapButtonShown then A:SetMinimapButtonShown(not st.minimapHide) end
                if st.theme ~= snap.theme then UI:SetTheme(snap.theme) end
                HideAll()
                if snap.ui then UI:Show() else UI:Hide() end
                if not res[1] then error(res[2], 0) end
                return ok, ok and "ohne Fehler" or (table.concat(res[2], " / "):sub(1, 120)), "erwartete Meldung"
            end)
            end
        end)
        end
        B(function() Skp("T31.36", "B", "Befehle test*/testmodus", "würde die laufende Routine stören") end)

        B(function()
        Chk("T34", "B", "Einkauf rechnen", function()
            local Bu = A.Buy
            local saved, savedP = Bu.detail, Bu.pending
            Bu.pending = nil
            Bu.detail = { itemID = FAKE, commodity = true, qty = 1,
                listings = { { qty = 5, price = 100 }, { qty = 10, price = 150 } } }
            local res = { pcall(function()
                local t8 = Bu:Quote(8)
                local t20 = Bu:Quote(20)
                local av = Bu:Available()
                Bu:SetQuantity(99)
                local q = Bu.detail.qty
                local m1, m2 = Bu:MinBid({ bid = 1000 }), Bu:MinBid({ minBid = 77 })
                local own = Bu.BuyItem(Bu, { own = true, auctionID = 1, buyout = 1 })
                return t8 == 950 and t20 == nil and av == 15 and q == 15 and m1 == 1050 and m2 == 77 and not own,
                    string.format("%s/%s/%d/%d/%s/%s", tostring(t8), tostring(t20), av, q, tostring(m1), tostring(m2))
            end) }
            Bu.detail, Bu.pending = saved, savedP
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "950/nil/15/15/1050/77"
        end)
        Chk("T39", "B", "Sniper-Ziele", function()
            local Sn = A.Sniper
            local targets = Copy(A.db.sniper.targets)
            local res = { pcall(function()
                local ok = Sn:SetTarget(tostring(LINEN), 500, 3, 2000)
                local t = Sn:GetTarget("i:" .. LINEN)
                local q = t and Sn:Remaining(t)
                local done = t and Sn:IsDone(t)
                if t then Sn:FilterText(t) end
                Sn:RemoveTarget("i:" .. LINEN)
                return ok and t ~= nil and q == 3 and done == false and Sn:GetTarget("i:" .. LINEN) == nil,
                    string.format("gesetzt %s, Rest %s, fertig %s", tostring(ok), tostring(q), tostring(done))
            end) }
            A.db.sniper.targets = targets
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "gesetzt, Rest 3, nicht fertig, entfernt"
        end)
        Chk("T43", "B", "Sniper-Tasten", function()
            local Sn = A.Sniper
            local name = Sn:KeyName("SHIFT-BUTTON4")
            local before = self.real.SetOverrideBindingClick or 0
            if not A:IsAHOpen() then Sn:ApplyBindings() end
            local set = (self.real.SetOverrideBindingClick or 0) - before
            return name == "Shift+" .. L["Maustaste 4"] and (A:IsAHOpen() or set == 0),
                string.format("%s, Tasten bei geschlossenem AH: %d", tostring(name), set), "Shift+" .. L["Maustaste 4"] .. ", 0"
        end)
        Chk("T44", "B", "Wächter-Einstellungen", function()
            local W = A.Watcher
            local saved = Copy(A.db.watcher)
            local res = { pcall(function()
                W:SetThreshold(40); W:SetMinValue(20); W:SetBudget(1000)
                for _, c in ipairs(W.CATS or {}) do W:ToggleCategory(c.key or c[1] or c); W:CategoryLabel(c.key or c[1] or c) end
                W:ModeLabel(); W:ActiveCategories()
                -- TR:Start schaltet den Wächter ab; für den Wartegrund hier nur das Feld setzen (kein Start einer Runde),
                -- Replace(A.db.watcher, saved) stellt es danach zurück
                A.db.watcher.enabled = true
                local why = W:WhyWaiting()
                A.db.watcher.enabled = false
                return A:IsAHOpen() or why == L["wartet auf das Auktionshaus"], tostring(why)
            end) }
            Replace(A.db.watcher, saved)
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], A:IsAHOpen() and "ohne Fehler" or L["wartet auf das Auktionshaus"]
        end)
        Chk("T54", "B", "Buchhaltung rechnen", function()
            local Le = A.Ledger
            local entries = Copy(A.db.ledger.entries)
            local res = { pcall(function()
                local s0 = Le:Summary("all").sales
                Le:Add({ kind = "buy", itemID = FAKE, qty = 2, amount = 200 })
                Le:Add({ kind = "sale", itemID = FAKE, qty = 1, amount = 300, cut = 15 })
                local s1 = Le:Summary("all").sales
                local sold, avg = Le:SoldCount(FAKE, 30), Le:AverageBuyPrice(FAKE, 30)
                Le:Stats("all"); Le:ByItem("all"); Le:PeriodStart("7")
                return s1 == s0 + 1 and sold == 1 and avg == 100, string.format("Verkäufe +%d, verkauft %d, Ø Kauf %s",
                    s1 - s0, sold, tostring(avg))
            end) }
            A.db.ledger.entries = entries
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "+1, 1, 100"
        end)
        Chk("T62", "B", "Watchlist", function()
            local Wl = A.Watchlist
            local had = Copy(A.db.watchlist[LINEN])
            local res = { pcall(function()
                local ok = Wl:Add(tostring(LINEN), 100, 500)
                local has = Wl:Contains(LINEN)
                Wl:SetBuyBelow(tostring(LINEN), 120); Wl:GetStatus(LINEN); Wl:CountAlerts()
                Capture(Wl.CheckAlerts, Wl, false)
                return ok and has, "hinzugefügt " .. tostring(ok)
            end) }
            A.db.watchlist[LINEN] = had
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "hinzugefügt und wieder wie vorher"
        end)
        end)
    end

    -- ---------------- C. Taschen, Addon-Info, Esc im Kampf (0.65.7) ----------------
    if want(part, "c") then B(function()
        Chk("T89", "C", "Taschen ohne alte Funktionen", function()
            local Se, X, M = A.Seller, A.Extras, A.Mailer
            local function run()
                if Se.InvalidateBags then Se:InvalidateBags() end
                local items = Se:GetBagItems()
                local cand = X:VendorCandidates()
                local free = M.FreeSlots and M.FreeSlots() or 0
                return #items, #cand, free
            end
            -- 1) alte Funktionen fehlen, C_Container da (moderner Weg)
            A.apiOverride = { GetContainerNumSlots = false, GetContainerItemInfo = false, GetContainerNumFreeSlots = false }
            local ok1, n1, c1, f1 = pcall(run)
            -- 2) gar nichts da (nur simuliert): leere Liste, kein Fehler
            A.apiOverride = { C_Container = false, GetContainerNumSlots = false, GetContainerItemInfo = false,
                GetContainerNumFreeSlots = false }
            local ok2, n2, c2, f2 = pcall(run)
            A.apiOverride = nil
            if Se.InvalidateBags then Se:InvalidateBags() end
            if not ok1 then error(n1, 0) end
            if not ok2 then error(n2, 0) end
            local modernOK = (C_Container == nil) or n1 > 0 or f1 > 0
            return modernOK and n2 == 0 and c2 == 0 and f2 == 0,
                string.format("C_Container: %d Items, %d frei · ohne alles: %d/%d/%d", n1, f1, n2, c2, f2), "Taschen gelesen; ohne alles 0/0/0"
        end)
        Chk("T92", "C", "Addon-Info und Chat-Hilfen", function()
            local S = A.Sync
            local f = S.GetSendFunction and S.GetSendFunction()      -- nur nachsehen, nie senden
            A.apiOverride = { C_ChatInfo = false }
            local f2 = S.GetSendFunction and S.GetSendFunction()
            A.apiOverride = { ChatFrame_RemoveChannel = false }
            local hid = S.HideChannelFromChat and S.HideChannelFromChat()
            -- C_AddOns fehlt (nachgespielt über A.apiOverride): Rückfall auf die alten globalen Funktionen
            A.apiOverride = { C_AddOns = false }
            local okMeta
            local okRun = pcall(function()
                local tbl = A:API("C_AddOns")
                local meta = (tbl and tbl.GetAddOnMetadata) or A:API("GetAddOnMetadata")
                local loaded = (tbl and tbl.IsAddOnLoaded) or A:API("IsAddOnLoaded")
                okMeta = tbl == nil and (meta == nil or meta("AHSentinel", "Version") == A.version)
                    and (loaded == nil or loaded("AHSentinel") ~= false)
            end)
            okMeta = okRun and okMeta
            A.apiOverride = nil
            return f ~= nil and (f2 == SendAddonMessage) and hid == false and okMeta,
                string.format("Senden %s, ohne C_ChatInfo %s, ohne RemoveChannel %s, Metadaten %s", tostring(f ~= nil),
                    f2 and "SendAddonMessage" or "nil", tostring(hid), tostring(okMeta)),
                "Rückfall SendAddonMessage, HideChannelFromChat kehrt zurück"
        end)
        -- ein Test-Rahmen für alle Läufe; Ablauf in pcall, danach immer Kampf aus und Rahmen versteckt
        local f = self.escTestFrame
        if not f then f = CreateFrame("Frame", nil, UIParent); self.escTestFrame = f end
        if not (f.SetPropagateKeyboardInput and f.EnableKeyboard) then
            Skp("T94", "C", "Esc-Fenster im Kampf", "Client ohne SetPropagateKeyboardInput")
        else
        Chk("T94", "C", "Esc-Fenster im Kampf", function()
            self.escCalls = 0
            if not self.escHooked then
                hooksecurefunc(f, "SetPropagateKeyboardInput", function() if A.testCombat then TR.escCalls = (TR.escCalls or 0) + 1 end end)
                self.escHooked = true
            end
            local ok, err = pcall(function()
                A.testCombat = true
                A.UI:EscCloses(f)
                f:Show(); f:Hide(); f:Show()
                local key = f:GetScript("OnKeyDown")
                if key then key(f, "A"); key(f, "ESCAPE") end
            end)
            A.testCombat = nil
            f:Hide()
            if f.EnableKeyboard then pcall(f.EnableKeyboard, f, false) end
            if not ok then error(err, 0) end
            return self.escCalls == 0, self.escCalls .. " Aufrufe im Kampf", "0"
        end)
        end
    end) end

    -- ---------------- I/J. Ergänzungen (0.65.7) ----------------
    if want(part, "i") then B(function()
        self.wantJobError = true
        A:Job("ahs-test-error", function() error("AHS-Test T129", 0) end)
    end)
    B(function()
        if not self.wantJobError then return end
        return "WAIT", function() return not A:HasJob("ahs-test-error") end, 5, function(timedOut)
            local e = ErrorEntry("Job:ahs-test-error")
            self.wantJobError = nil
            Chk("T129", "I", "Fehler in Hintergrund-Aufgabe wird gemeldet", function()
                return e ~= nil, e and "Eintrag da" or "kein Eintrag", "Eintrag wo = Job:ahs-test-error"
            end)
            self:ClearTestErrors()
        end
    end) end
    if want(part, "j") then B(function()
        if not (C_AddOns and C_AddOns.GetAddOnOptionalDependencies) then
            Skp("T143", "J", "Übergang vom alten AH Analyzer Pro", "Client ohne GetAddOnOptionalDependencies")
        else
        Chk("T143", "J", "Übergang vom alten AH Analyzer Pro", function()
            local get = C_AddOns.GetAddOnOptionalDependencies
            local deps = { get("AHSentinel") }
            for _, d in ipairs(deps) do if d == "AHAnalyzerPro" then return false, "OptionalDeps enthält AHAnalyzerPro", "nicht enthalten" end end
            return _G.AHAnalyzerPro == A and A.version ~= nil, #deps .. " OptionalDeps, AHAnalyzerPro = AHSentinel", "kein AHAnalyzerPro"
        end)
        end
        Cli("T143b", "J", "Alter Ordner AHAnalyzerPro zusätzlich vorhanden",
            "Ordner AddOns\\AHAnalyzerPro (bis 0.61) zusätzlich aktivieren: genau eine Meldung 'Bitte den alten Ordner ... löschen', keine doppelten /ahs-Befehle, keine Lua-Fehler")
    end) end

    -- ---------------- C. Forever-Sonderfälle (simuliert) ----------------
    if want(part, "c") then B(function()
        local function secretCheck(id, name, fn, verify)
            Chk(id, "C", name, function()
                local ok, err = WithSecret(fn)
                self:ClearTestErrors()
                if not ok then return false, tostring(err), "kein Lua-Fehler" end
                if verify then return verify() end
                return true
            end)
        end
        local Se, S, D, M, Sn = A.Seller, A.Sync, A.Disenchant, A.Mailer, A.Sniper
        local lastSale = Se and Se.lastSale
        secretCheck("T80", "Systemmeldung \"verkauft\" geschützt", function()
            Se.saleFrame:GetScript("OnEvent")(Se.saleFrame, "CHAT_MSG_SYSTEM", SECRET)
        end, function() return Se.lastSale == lastSale, nil, "lastSale unverändert" end)
        local peers = Count(A.db.sync and A.db.sync.peers)
        secretCheck("T81", "Addon-Nachricht Sync geschützt", function()
            local f = S.frame:GetScript("OnEvent")
            f(S.frame, "CHAT_MSG_ADDON", "AHAP1", SECRET, "CHANNEL", "Testpeer")
            f(S.frame, "CHAT_MSG_ADDON", "AHAP1", "H:1", "CHANNEL", SECRET)
        end, function()
            local e = A.db.gsTest and A.db.gsTest.errors
            for k in pairs(e or {}) do if k:find("^Sync|") and k:find("geschützt") then return false, "Sync-Fehler", "keiner" end end
            return Count(A.db.sync and A.db.sync.peers) == peers, nil, "peers unverändert"
        end)
        secretCheck("T82", "Zauber-Ereignis Entzaubern geschützt", function()
            D.evt:GetScript("OnEvent")(D.evt, "UNIT_SPELLCAST_SUCCEEDED", "player", "x", SECRET)
        end)
        secretCheck("T83", "Tooltip-Daten geschützt", function()
            local tip = { AddLine = function() error("Zeile hinzugefügt") end, NumLines = function() return 0 end }
            A.Tooltip:Handle(tip, { id = SECRET })
        end)
        secretCheck("T84", "Fehlermeldung am Briefkasten geschützt", function()
            local was = M.running
            M.running = true
            local ok, err = pcall(M.evt:GetScript("OnEvent"), M.evt, "UI_ERROR_MESSAGE", SECRET, SECRET)
            M.running = was
            if not ok then error(err, 0) end
        end)
        local inst = Sn and Sn.instantFailed
        secretCheck("T85", "Blockierte Aktion geschützt", function()
            Sn:OnEvent("ADDON_ACTION_BLOCKED", SECRET, SECRET)
        end, function() return Sn.instantFailed == inst, nil, "instantFailed unverändert" end)
        Chk("T86", "C", "Forever-Namen: Post-Regel an sich selbst", function()
            local X = A.Extras
            if not (X and X.IsMyself and g and g.SetTestFlavor) then return "SKIP", "IsMyself oder SetTestFlavor fehlt" end
            g.SetTestFlavor("forever")
            X.testMyName = "Rokan Steinwacht"
            local ok, me = pcall(X.IsMyself, "Rokan")
            local ok2, other = pcall(X.IsMyself, "Brakka")
            X.testMyName = nil
            g.SetTestFlavor(nil)
            return ok and ok2 and me == true and other == false, tostring(me) .. "/" .. tostring(other), "true/false"
        end)
        Chk("T87", "C", "Händler ohne alte Funktionen", function()
            A.apiOverride = { GetMerchantNumItems = false, GetMerchantItemInfo = false, GetMerchantItemLink = false,
                GetMerchantItemID = false, C_MerchantFrame = false, GetMerchantItemCostInfo = false }
            local ok, n = pcall(A.ScanMerchant, A)
            A.apiOverride = nil
            return ok and n == 0, tostring(n), "0 ohne Fehler"
        end)
        Chk("T88", "C", "Berufe ohne alte Funktionen", function()
            A.apiOverride = { GetNumTradeSkills = false }
            local k1 = A.Crafting:TradeKind()
            A.apiOverride = { GetNumTradeSkills = false, C_TradeSkillUI = false }
            local k2 = A.Crafting:TradeKind()
            A.apiOverride = nil
            local ts = C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs
            return k1 == (ts and "modern" or "trade") and k2 == "trade", k1 .. "/" .. k2, (ts and "modern" or "trade") .. "/trade"
        end)
        Chk("T90", "C", "Item-Aliase beim Laden", function()
            return A:StackSize(LINEN) >= 1 and A:GetItemIcon(LINEN) ~= nil, tostring(A:StackSize(LINEN)), "Stapel >= 1, Symbol da"
        end)
        Chk("T91", "C", "Post ohne Funktionen", function()
            A.apiOverride = { SendMail = false, ClickSendMailItemButton = false }
            local open = MailFrame and MailFrame:IsShown()
            local ok, r, msg = pcall(A.Extras.MailStep, A.Extras)
            A.apiOverride = nil
            if not ok then error(r, 0) end
            if not open then return r == false, tostring(msg), "Briefkasten zu -> false" end
            return r == false and msg == L["Dein Client unterstützt das Verschicken nicht."], tostring(msg), "Dein Client unterstützt ..."
        end)
        Chk("T93", "C", "Sniper-Tasten im Kampf", function()
            local Sn = A.Sniper
            local before = self.real.SetOverrideBindingClick or 0
            A.testCombat = true
            Sn:ApplyBindings()
            local pend = Sn.pendingBindings
            A.testCombat = false
            Sn.evt:GetScript("OnEvent")(Sn.evt, "PLAYER_REGEN_ENABLED")
            local after = Sn.pendingBindings
            A.testCombat = nil
            local set = (self.real.SetOverrideBindingClick or 0) - before
            return (SetOverrideBindingClick == nil) or (pend == true and after == false), string.format("im Kampf %s, danach %s, Tasten %d",
                tostring(pend), tostring(after), set), "true, false"
        end)
        Chk("T95", "C", "Routine-Start im Kampf abgelehnt", function()
            A.testCombat = true
            self.running = false
            local lines, ok = Capture(function() return TR.Start(TR, "a") end)
            self.running = true
            A.testCombat = nil
            return ok == false, tostring(ok), "false"
        end)
        Chk("T96", "C", "Kampflog nicht benutzt", function()
            local bad = {}
            for name, f in pairs({ Crafting = A.Crafting.evt, Extras = A.Extras.evt, Seller = A.Seller.saleFrame, Sniper = A.Sniper.evt,
                Disenchant = A.Disenchant.evt, Mailer = A.Mailer.evt, Comfort = A.Comfort.evt, Chars = A.Chars.evt,
                Sync = A.Sync.frame, Kern = A.eventFrame, Test = TR.frame }) do
                if f and f.IsEventRegistered and f:IsEventRegistered("COMBAT_LOG_EVENT_UNFILTERED") then bad[#bad + 1] = name end
            end
            return #bad == 0, #bad == 0 and "keiner" or table.concat(bad, ", "), "keiner"
        end)
    end) end

    -- ---------------- D. Alte Clients ----------------
    if want(part, "d") then B(function()
        if not A.AH_LEGACY then
            Skp("T97", "D", "Nachbildung altes AH", "nur im alten Client")
        else
            Chk("T97", "D", "Nachbildung altes AH", function()
                local AH = ST.realAH or A.AH
                local k = AH.MakeItemKey and AH.MakeItemKey(LINEN)
                return k and k.itemID == LINEN, tostring(k and k.itemID), tostring(LINEN)
            end)
        end
        Chk("T102", "D", "Raid-Vorrat je Version", function()
            local key = A.Comfort:RaidSetKey()
            local p = WOW_PROJECT_ID
            local expect
            if A:IsForever() then expect = "classic"
            elseif p == (WOW_PROJECT_CLASSIC or 2) then expect = "classic"
            elseif p == (WOW_PROJECT_BURNING_CRUSADE_CLASSIC or 5) then expect = "tbc"
            elseif p == (WOW_PROJECT_WRATH_CLASSIC or 11) then expect = "wrath" end
            return key == expect, tostring(key), tostring(expect)
        end)
        Chk("T103", "D", "keine Rückschritte zum letzten Bericht", function()
            local reps = A.db.gsTest and A.db.gsTest.reports
            return true, string.format("%d frühere Berichte (Vergleich macht die Prüf-Sitzung)", reps and #reps or 0)
        end)
    end) end

    -- ---------------- E. Daten ----------------
    if want(part, "e") then B(function()
        Chk("T104", "E", "Neuinstallation", function()
            local orig, origOld, migrated = AHSentinelDB, AHAnalyzerProDB, A.migratedFromOld
            local ok, err, res
            AHSentinelDB, AHAnalyzerProDB = nil, nil
            local lines
            ok, err = pcall(function()
                lines = Capture(function() A:InitDB() end)
                local d = A.db
                res = { d.dbVersion, d.settings.detachedWindow, d.sniper.fastSearch, d.settings.nameLocale }
            end)
            AHSentinelDB, AHAnalyzerProDB, A.db, A.migratedFromOld = orig, origOld, orig, migrated
            A:ApplyUILanguage()
            local GT = GTest()
            if GT then GT.TrackErrors("AHSentinel", A.version, A.db) end
            if not ok then error(err, 0) end
            return res[1] == 4 and res[2] == true and res[3] == true and res[4] == "auto",
                string.format("%s/%s/%s/%s", tostring(res[1]), tostring(res[2]), tostring(res[3]), tostring(res[4])), "4/true/true/auto"
        end)
        Chk("T105", "E", "Migration Datenbank 3 -> 4", function()
            local orig, migrated = AHSentinelDB, A.migratedFromOld
            local t1, t2 = time() - 2000, time() - 1000
            AHSentinelDB = { dbVersion = 3, marketData = { [LINEN] = { history = { { price = 100, time = t2, quantity = 1 },
                { price = 90, timestamp = t1, qty = 2 } } } } }
            local lines, h
            local ok, err = pcall(function()
                lines = Capture(function() A:InitDB() end)
                h = A.db.marketData[LINEN] and A.db.marketData[LINEN].history
            end)
            AHSentinelDB, A.db, A.migratedFromOld = orig, orig, migrated
            A:ApplyUILanguage()
            local GT = GTest()
            if GT then GT.TrackErrors("AHSentinel", A.version, A.db) end
            if not ok then error(err, 0) end
            local good = h and #h == 2 and h[1].t == t1 and h[1].p == 90 and h[1].q == 2 and h[2].p == 100
            return good and table.concat(lines, " "):find(A:PlainText(L["Datenbank auf Version 4 umgestellt."]), 1, true) ~= nil,
                h and (#h .. " Einträge") or "nil", "2 Einträge sortiert, Meldung"
        end)
        Chk("T109", "E", "Abbruch mitten im Test (Wiederherstellung)", function()
            return type(TR.RecoverAfterReload) == "function" and A.db.testRoutine and A.db.testRoutine.backup ~= nil, nil,
                "Sicherung liegt in AHSentinelDB.testRoutine"
        end)
    end) end

    -- ---------------- F. Sprachen ----------------
    if want(part, "f") then B(function()
        local LANGS = { "frFR", "esES", "esMX", "ptBR", "itIT", "ruRU", "koKR", "zhCN", "zhTW" }
        Chk("T110", "F", "Text-Schlüssel vollständig", function()
            local miss, parts = 0, {}
            for _, l in ipairs(LANGS) do
                local n = 0
                for k in pairs(A.EN) do if A.T[l][k] == nil then n = n + 1 end end
                miss = miss + n
                if n > 0 then parts[#parts + 1] = l .. " " .. n end
            end
            return miss == 0, miss == 0 and (Count(A.EN) .. " Schlüssel je Sprache") or table.concat(parts, ", "), "0 fehlend"
        end)
        Chk("T111", "F", "Formatplatzhalter", function()
            local function marks(s)
                local out = {}
                for m in tostring(s):gsub("%%%%", ""):gmatch("%%[%-%d%.]*[sdfi]") do out[#out + 1] = m:sub(-1) end
                return table.concat(out)
            end
            local bad = {}
            for k, en in pairs(A.EN) do
                local want = marks(k)
                if marks(en) ~= want then bad[#bad + 1] = "enUS: " .. k:sub(1, 30) end
                for _, l in ipairs(LANGS) do
                    local v = A.T[l][k]
                    if v and marks(v) ~= want then bad[#bad + 1] = l .. ": " .. k:sub(1, 30) end
                end
                if #bad > 10 then break end
            end
            return #bad == 0, #bad == 0 and "0 Abweichungen" or table.concat(bad, " | "), "0 Abweichungen"
        end)
        Chk("T113", "F", "Text-Werte gültig, Hilfeseiten", function()
            local bad = {}
            for k, v in pairs(A.EN) do if type(v) ~= "string" then bad[#bad + 1] = "enUS" end end
            for _, l in ipairs(LANGS) do
                for k, v in pairs(A.T[l]) do if type(v) ~= "string" then bad[#bad + 1] = l; break end end
            end
            local ref = A.HELP.deDE or A.HELP.enUS
            if type(ref) == "table" then
                for _, l in ipairs(LANGS) do
                    local h = A.HELP[l]
                    if type(h) == "table" and #h ~= #ref then bad[#bad + 1] = "Hilfe " .. l end
                end
            end
            return #bad == 0, table.concat(bad, ", "), "alles Text, gleiche Hilfeseiten"
        end)
        Chk("T114", "F", "Texte der gemeinsamen Dateien", function()
            local D = _G.GoldSentinelDev
            local a = g and g.Text("game")
            local b = D and D.Text and D:Text("blocked")
            return a ~= "game" and (b == nil or b ~= "blocked"), tostring(a), "übersetzter Text"
        end)
    end) end

    -- ---------------- G. Zusammenspiel ----------------
    if want(part, "g") then B(function()
        Chk("T115", "G", "gemeinsame Dateien nach Simulation wieder echt", function()
            if not (g and g.SetTestFlavor) then return "SKIP", "SetTestFlavor fehlt" end
            local f = g.flavor
            g.SetTestFlavor(f == "forever" and "era" or "forever")
            g.SetTestFlavor(nil)
            return g.flavor == f, tostring(g.flavor), tostring(f)
        end)
        Chk("T116", "G", "globale Namen", function()
            return _G.AHAnalyzerPro == A and A.version ~= nil and _G.AHSentinelDB == A.db, nil, "AHAnalyzerPro = A, AHSentinelDB = A.db"
        end)
        Chk("T117", "G", "ProfessionSentinel liest AHSentinel (QuickBuy/QuickSell, Händler-Kosten)", function()
            local Td = A.Today
            local ok1 = Td:QuickBuy(LINEN, 2, 100, "Test")
            local found
            for _, r in ipairs(Td.extra) do if r.key == "quick:" .. LINEN and r.pin then found = true end end
            local ok0 = Td:QuickBuy(LINEN, 2, 0, "Test")
            local lines, ok2 = Capture(function() return Td:QuickSell(LINEN) end)
            for i = #Td.extra, 1, -1 do
                local k = Td.extra[i].key
                if k == "quick:" .. LINEN or k == "quicksell:" .. LINEN then table.remove(Td.extra, i) end
            end
            Td.state["quick:" .. LINEN], Td.state["quicksell:" .. LINEN] = nil, nil
            if A.UI and A.UI.todayWin then A.UI.todayWin:Hide() end
            return ok1 and found and ok0 == false and ok2, nil, "Zeile mit pin, maxPrice 0 abgelehnt"
        end)
        Chk("T118", "G", "AHSentinel liest ProfessionSentinel (Stub, Fehler abgefangen)", function()
            local real = _G.ProfessionSentinelAPI
            local okA, okB
            _G.ProfessionSentinelAPI = { version = 1, TodayCrafts = function() error("AHS-Test PS") end }
            okA = pcall(A.Comfort.TodayActions, A.Comfort, 10)
            _G.ProfessionSentinelAPI = { version = 2 }
            okB = pcall(A.Comfort.TodayActions, A.Comfort, 10)
            _G.ProfessionSentinelAPI = real
            self:ClearTestErrors()
            return okA and okB and _G.ProfessionSentinelAPI == real, nil, "kein Fehler in TodayActions, echte API zurück"
        end)
    end) end

    -- ---------------- H. Leistung ----------------
    if want(part, "h") then B(function()
        local function measure(id, name, fn, n, limit)
            Chk(id, "H", name, function()
                local sum, max = 0, 0
                for i = 1, n do
                    local t = Ms()
                    fn()
                    local d = Ms() - t
                    sum = sum + d
                    if d > max then max = d end
                end
                local avg = sum / n
                return avg < limit, string.format("Mittel %.3f ms, höchstens %.2f ms (%d Items)", avg, max, Count(A.db.marketData)),
                    string.format("< %.2f ms", limit)
            end)
        end
        measure("T121", "Takt-Funktionen (Sniper, Wächter)", function() A.Sniper:Tick(); A.Watcher:Tick() end, 100, 0.4)
        measure("T123", "Heute tun (10)", function() A.Comfort:TodayActions(10) end, 3, 16)
        measure("T123b", "Marktliste", function() A:BuildItemList() end, 3, 16)
        measure("T125", "Zauber-Ereignis im Raid", function()
            A.Disenchant.evt:GetScript("OnEvent")(A.Disenchant.evt, "UNIT_SPELLCAST_SUCCEEDED", "raid5", "x", 1)
        end, 1000, 0.02)
        Chk("T127", "H", "Speicher", function()
            local kb = 0
            if UpdateAddOnMemoryUsage and GetAddOnMemoryUsage then
                UpdateAddOnMemoryUsage()
                kb = GetAddOnMemoryUsage("AHSentinel") or 0
            end
            return true, string.format("AHSentinel %.0f KB", kb)
        end)
    end) end

    -- ---------------- I. Fehlerzählung ----------------
    if want(part, "i") then B(function()
        Chk("T128", "I", "Fehler in Ereignis-Zuhörer wird gemeldet", function()
            A:On("AHS_TEST_ERROR", function() error("AHS-Test T128") end)
            Capture(function() A:Fire("AHS_TEST_ERROR") end)
            A.listeners["AHS_TEST_ERROR"] = nil
            local e = ErrorEntry("Fire:AHS_TEST_ERROR")
            self:ClearTestErrors()
            return e ~= nil, e and "Eintrag da" or "kein Eintrag", "Eintrag in gsTest.errors"
        end)
        Chk("T130", "I", "Verkaufs-Meldung: Fehler gemeldet statt verschluckt", function()
            local Se = A.Seller
            local raw = _G.ERR_AUCTION_SOLD_S
            if type(raw) ~= "string" then return "SKIP", "Client ohne ERR_AUCTION_SOLD_S" end
            -- Muster fehlt, obwohl der Text da ist -> die Verkaufs-Meldung geht für Spieler gar nicht
            if Se.SoldPattern and not Se.SoldPattern() then return false, "Muster fehlt für: " .. raw, "Muster aus ERR_AUCTION_SOLD_S" end
            self:ClearTestErrors()          -- GoldSentinelTest speichert höchstens MAX_ERRORS verschiedene Fehler
            local GT, n = _G.GoldSentinelTest, 0
            for _ in pairs(A.db.gsTest and A.db.gsTest.errors or {}) do n = n + 1 end
            if GT and GT.MAX_ERRORS and n >= GT.MAX_ERRORS then
                return "SKIP", string.format("Fehlerspeicher voll (%d von %d) - erst nach dem nächsten Bericht prüfbar", n, GT.MAX_ERRORS)
            end
            local real = Se.OnSold
            Se.OnSold = function() error("AHS-Test T130") end
            local msg = raw:gsub("%%%d?%$?s", "Leinenstoff")
            pcall(Se.saleFrame:GetScript("OnEvent"), Se.saleFrame, "CHAT_MSG_SYSTEM", msg)
            Se.OnSold = real
            local e = ErrorEntry("Verkauft")
            self:ClearTestErrors()
            return e ~= nil, e and "Eintrag da" or ("kein Eintrag (Text: " .. msg .. ")"), "Eintrag \"Verkauft\""
        end)
        Chk("T132", "I", "blockierte Aktion wird gemeldet", function()
            local f = _G.GoldSentinelTestFrame
            if not f then return false, "GoldSentinelTestFrame fehlt" end
            f:GetScript("OnEvent")(f, "ADDON_ACTION_BLOCKED", "AHSentinel", "AHS-Test()")
            local okS = pcall(A.Sniper.OnEvent, A.Sniper, "ADDON_ACTION_BLOCKED", "AHSentinel", "AHS-Test()")
            local s = A.db.gsTest.errors
            local found
            for k in pairs(s) do if k:find("ADDON_ACTION_BLOCKED", 1, true) and k:find("AHS-Test", 1, true) then found = true end end
            self:ClearTestErrors()
            return found and okS, nil, "Eintrag, Sniper ohne Fehler"
        end)
    end)
        if want(part, "i") then
            -- unbehandelter Lua-Fehler: wartet auf den Fehler-Abgriff von GoldSentinelTest
            B(function()
                C_Timer.After(0, function() error("AHS-Test T131") end)
                return "WAIT", function() return ErrorEntry("Lua") ~= nil end, 3, function(timedOut)
                    local found = ErrorEntry("Lua") ~= nil
                    self:ClearTestErrors()
                    self:Check("T131", "I", "unbehandelter Lua-Fehler wird gezählt", function()
                        -- ohne BugSack/BugGrabber und ohne Fehler-Handler kein Abgriff möglich: übersprungen, nie OK/FEHLER
                        -- (Entscheid der Prüf-Sitzung 9. Nov. 09:35)
                        if not found and not (_G.BugGrabber or (_G.geterrorhandler and _G.seterrorhandler)) then
                            return "SKIP", "kein Fehler-Abgriff im Client (BugSack/BugGrabber/seterrorhandler fehlen)"
                        end
                        return found, found and "gezählt" or "nicht gezählt", "Eintrag \"Lua\" (BugSack/Fehler-Abgriff)"
                    end)
                end
            end)
        end
    end

    -- ---------------- J. Regressionstests ----------------
    if want(part, "j") then B(function()
        Chk("T133", "J", "Raid-Vorrat in Forever", function()
            if not (g and g.SetTestFlavor) then return "SKIP", "SetTestFlavor fehlt" end
            g.SetTestFlavor("forever")
            local k = A.Comfort:RaidSetKey()
            g.SetTestFlavor(nil)
            return k == "classic", tostring(k), "classic"
        end)
        Chk("T136", "J", "Favor-Kosten: Format stabil", function()
            for id, c in pairs(A.db.vendorCost or {}) do
                if type(c) ~= "table" or type(c.costs) ~= "table" or c.gold == nil or c.qty == nil then
                    return false, "Eintrag " .. tostring(id), "{ gold, qty, costs, t }"
                end
                return A:GetVendorCost(id) == c, nil, "GetVendorCost = gespeicherte Tabelle"
            end
            return "SKIP", "keine Favor-Kosten gespeichert - erst einen Händler mit Währungs-Artikeln ansprechen (Format über T18 geprüft)"
        end)
        Chk("T137", "J", "Artikelanzahl über C_MerchantFrame", function()
            local cmf = { GetNumItems = function() return 1 end, GetItemInfo = function() return { price = 50, stackCount = 1, numAvailable = -1 } end }
            A.apiOverride = { GetMerchantNumItems = false, C_MerchantFrame = cmf, GetMerchantItemLink = function() return "item:" .. (FAKE + 20) end }
            local ok, n = pcall(A.ScanMerchant, A)
            A.apiOverride = nil
            local v = A.db.vendorBuy[FAKE + 20]
            A.db.vendorBuy[FAKE + 20] = nil
            return ok and n == 1 and v == 50, tostring(n) .. "/" .. tostring(v), "1/50"
        end)
        Chk("T139", "J", "Sniper ADDON_ACTION_BLOCKED", function()
            local Sn = A.Sniper
            local inst, pend = Sn.instantFailed, Sn.pending
            local db = A.db.sniper
            local instantSetting, blocked = db and db.instantBuy, db and db.instantBlocked
            Sn.pending = { auto = true, itemID = FAKE }
            local ok, err = pcall(Capture, Sn.OnEvent, Sn, "ADDON_ACTION_BLOCKED", "AHSentinel", "C_AuctionHouse.StartCommoditiesPurchase()")
            local p = Sn.pending
            Sn.instantFailed, Sn.pending = inst, pend
            if db then db.instantBuy, db.instantBlocked = instantSetting, blocked end
            if not ok then error(err, 0) end
            return p == nil, tostring(p), "pending nil"
        end)
        Chk("T140", "J", "Wächter-Pause wirkt (moderner Weg)", function()
            local W = A.Watcher
            local saved, legacy, drop, hold = A.db.lastScanTime, A.AH_LEGACY, A.lastThrottleDrop, W.holdForScan
            A.AH_LEGACY = false
            A.db.lastScanTime = 0
            W.holdForScan = nil
            W:OnThrottleDrop()
            local h1 = W:HoldingForScan()
            A.db.lastScanTime = time()
            local h2 = W:HoldingForScan()
            A.AH_LEGACY, A.db.lastScanTime, A.lastThrottleDrop, W.holdForScan = legacy, saved, drop, hold
            return h1 == true and h2 == false, tostring(h1) .. "/" .. tostring(h2), "true/false"
        end)
        Chk("T141", "J", "Pause ändert altes AH nicht", function()
            local W = A.Watcher
            local saved, legacy, hold = A.db.lastScanTime, A.AH_LEGACY, W.holdForScan
            A.AH_LEGACY = true
            A.db.lastScanTime = 0
            W.holdForScan = nil
            W:OnThrottleDrop()
            local h = W.holdForScan
            A.AH_LEGACY, A.db.lastScanTime, W.holdForScan = legacy, saved, hold
            return h == nil, tostring(h ~= nil), "keine Pause"
        end)
        if not A.AH_LEGACY then
            Cli("T142", "J", "Scan nicht vom Wächter blockiert", "Forever: Wächter an, Scan fällig -> /ahs scan startet den Scan")
            Cli("T138", "J", "Wächter und Server-Limit", "Forever: Wächter 2–3 Runden, dann /ahs scan: startet der Scan?")
        else
            Skp("T142", "J", "Scan nicht vom Wächter blockiert", "nur moderner Client")
        end
        Skp("T144", "J", "CurseForge Forever-Tag", "betrifft curseforge/upload.py im raidmaster-Repo, nicht das Addon – prüft die Prüf-Sitzung im Workflow")
        Chk("T145", "J", "Raid-Liste: alle Item-IDs vorhanden", function()
            local miss = {}
            local exists = (C_Item and C_Item.DoesItemExistByID) or (GetItemInfoInstant and function(id) return GetItemInfoInstant(id) ~= nil end)
            if not exists then return "SKIP", "Client ohne C_Item.DoesItemExistByID/GetItemInfoInstant" end
            local list = A.Comfort.RAID_SETS.classic
            for _, e in ipairs(list) do
                if not exists(e[1]) then miss[#miss + 1] = tostring(e[1]) end
            end
            -- nur GetItemInfoInstant und mehr als die Hälfte unbekannt: Item-Daten fehlen im Client -> übersprungen
            -- (Entscheid der Prüf-Sitzung 9. Nov. 09:35); einzelne fehlende IDs bleiben FEHLER
            if not (C_Item and C_Item.DoesItemExistByID) and #miss * 2 > #list then
                return "SKIP", "Item-Daten fehlen im Client (" .. #miss .. " von " .. #list .. " unbekannt)"
            end
            return #miss == 0, #miss == 0 and "alle vorhanden" or table.concat(miss, ", "), "alle vorhanden"
        end)
        if A:IsForever() then
            Cli("T145c", "J", "Raid-Vorrat passt zu Forever", "Passen die Schutztränke zu Barrow Deeps, Hyjalgipfel, Onyxia? (Punkt 5 nach dem Launch)")
            Cli("T149", "J", "Händler-Währungsfunktionen", "/dump GetMerchantItemCostInfo, /dump GetMerchantItemCostItem – fehlen sie, liest das Addon keine Favor-Kosten")
            Cli("T151", "J", "Interface-Nummer", "/dump select(4, GetBuildInfo()) – ist es nicht 16001, neue Nummer in AHSentinel.toc ergänzen")
        end
        Chk("T150", "J", "Erkennung über GoldSentinelGame", function()
            local prev = A.forceForever
            A.forceForever = nil
            local follows = (A:IsForever() == (g and g.IsForever == true))
            A.forceForever = true; local t = A:IsForever()
            A.forceForever = false; local f = A:IsForever()
            A.forceForever = prev
            return follows and t == true and f == false, nil, "folgt G.IsForever, Schalter gewinnt"
        end)
        -- neu ab 0.65.6
        Chk("T153", "J", "Scan-Start scheitert dauerhaft: höchstens 2 Chatzeilen, Wächter läuft weiter", function()
            local proxy = A.AH
            if not (ST.realAH and getmetatable(proxy)) then return false, "Handels-Proxy fehlt" end
            local W = A.Watcher
            local saved = { last = A.db.lastScanTime, legacy = A.AH_LEGACY, open = A.ahOpen, hold = W.holdForScan, round = W.round,
                start = A.StartFullScan, lastQ = A.pace.last, errs = A.pace.errors, gap = A.pace.gap }
            proxy.SendBrowseQuery = function() error("AHS-Test SendBrowseQuery") end
            proxy.IsThrottledMessageSystemReady = function() return true end
            A.AH_LEGACY, A.ahOpen, A.db.lastScanTime, W.holdForScan, W.round = false, true, 0, nil, nil
            A.StartFullScan = ST.origScan or A.StartFullScan
            local lines, res = {}, {}
            local ok, err = pcall(function()
                lines = Capture(function()
                    A:StartFullScan()
                    if A.scanWishTicker then A.scanWishTicker:Cancel(); A.scanWishTicker = nil end
                    for i = 1, 10 do
                        A.scanWishNext = 0
                        if A.scanWanted then A:TryWantedScan() end
                        if A.scanWishTicker then A.scanWishTicker:Cancel(); A.scanWishTicker = nil end
                    end
                end)
                res.wanted, res.hold = A.scanWanted, W:HoldingForScan()
            end)
            if A.DropScanWish then A:DropScanWish(false) end
            proxy.SendBrowseQuery, proxy.IsThrottledMessageSystemReady = nil, nil
            A.db.lastScanTime, A.AH_LEGACY, A.ahOpen, W.holdForScan, W.round = saved.last, saved.legacy, saved.open, saved.hold, saved.round
            A.StartFullScan = saved.start
            A.pace.last, A.pace.errors, A.pace.gap = saved.lastQ, saved.errs, saved.gap
            if not ok then error(err, 0) end
            return #lines <= 2 and res.wanted == nil and res.hold == false,
                string.format("%d Chatzeilen, Wunsch %s, Wächter-Pause %s", #lines, tostring(res.wanted ~= nil), tostring(res.hold)),
                "<= 2 Zeilen, Wunsch verworfen, keine Pause"
        end)
        Chk("T154", "J", "15-Minuten-Pause während eines Scan-Wunschs", function()
            local W = A.Watcher
            local hold = W.holdForScan
            W.holdForScan = nil
            W:HoldForScan(120)
            local m1 = W.holdForScan and W.holdForScan.max
            W:HoldForScan()
            local m2 = W.holdForScan and W.holdForScan.max
            W.holdForScan = hold
            return m1 == 120 and m2 == nil, tostring(m1) .. " -> " .. tostring(m2), "120 -> nil (15 Min.)"
        end)
        Chk("T155", "J", "Rezept-Auswahl im Berufsfenster: Ereignisname", function()
            local Cr = A.Crafting
            local nameOK = Cr.RECIPE_SELECTED_EVENT == "ProfessionsRecipeListMixin.Event.OnRecipeSelected"
            local hooked = (not (EventRegistry and EventRegistry.RegisterCallback)) or Cr.selectionHooked == true
            local before = Cr.lastModernRecipe
            Cr:OnRecipeSelected({ recipeID = 123456 })
            local got = Cr.lastModernRecipe
            Cr.lastModernRecipe = before
            return nameOK and hooked and got == 123456, string.format("Name %s, angemeldet %s", tostring(nameOK), tostring(hooked)), "ja, ja"
        end)
        if modern then
            Cli("T155c", "J", "Rezept-Auswahl (Forever)", "Rezept im Blizzard-Berufsfenster wählen -> /dump AHAnalyzerPro.Crafting.lastModernRecipe zeigt dessen ID")
        end
    end) end

    -- ---------------- Halbautomatische Teile ----------------
    -- ---------------- Ergänzungen 0.65.8 (fehlende Fälle aus testroutine-ahsentinel.txt) ----------------
    -- Jeder Fall ein eigener Schritt (SLICE_MS). HALB-Fälle laufen in ihrem Teil (server, berufe, haendler);
    -- im Teil "auto" stehen sie mit Hinweis als übersprungen im Bericht, damit nichts fehlt.
    local function Real(name) return self.real[name] or 0 end
    local function TradeCount(fn)
        local n = 0
        for _, e in ipairs(ST.tradeLog or {}) do if not fn or e.fn == fn then n = n + 1 end end
        return n
    end
    local HALB_SERVER = "HALB: Auktionshaus öffnen, dann /ahs testroutine server"

    if want(part, "b") then
        B(function()
        Chk("T46", "B", "Wächter-Kandidaten mit Testdaten", function()
            local W, Sn = A.Watcher, A.Sniper
            local opps, extra = Copy(W.opps), {}
            for k, v in pairs(Sn.extra) do extra[k] = v end
            local res = { pcall(function()
                W:AddCandidate({ itemID = FAKE + 20, price = 50, market = 200, pct = 25 })
                local found = false
                for _, o in ipairs(W:GetOpportunities()) do if o.itemID == FAKE + 20 then found = true end end
                local t = Sn.extra["w:" .. (FAKE + 20)]
                if t then t.created = (t.created or 0) - 100000 end
                W:Cleanup(); W:ClearTargets()
                local left = Sn.extra["w:" .. (FAKE + 20)]
                return found and left == nil, string.format("in der Liste %s, Ziel danach %s", tostring(found), left and "da" or "weg")
            end) }
            W.opps = opps
            for k in pairs(Sn.extra) do if extra[k] == nil then Sn.extra[k] = nil end end
            for k, v in pairs(extra) do Sn.extra[k] = v end
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "Kandidat gelistet, Cleanup/ClearTargets räumen"
        end)
        end)

        B(function()
        if not ERR_AUCTION_SOLD_S then return Skp("T53", "B", "Verkaufs-Meldung", "Client ohne ERR_AUCTION_SOLD_S") end
        Chk("T53", "B", "Verkaufs-Meldung", function()
            local Se = A.Seller
            local owned, last = Se.owned, Se.lastSale
            local name = A:GetItemName(LINEN)
            local o = { itemID = LINEN, name = name, qty = 2, buyout = 200, unitPrice = 100, auctionID = FAKE + 21 }
            Se.owned = { o }
            local lines = Capture(function()
                Se.saleFrame:GetScript("OnEvent")(Se.saleFrame, "CHAT_MSG_SYSTEM", ERR_AUCTION_SOLD_S:gsub("%%s", name))
            end)
            local got = Se.lastSale
            Se.owned, Se.lastSale = owned, last
            local said = table.concat(lines, "\n"):find(A:PlainText(L["Verkauft:"]), 1, true) ~= nil
            return got and got.itemID == LINEN and o.sold == true and said,
                string.format("Item %s, verkauft %s, Meldung %s", tostring(got and got.itemID), tostring(o.sold), tostring(said)),
                "lastSale.itemID gesetzt, o.sold, Meldung im Chat"
        end)
        end)

        B(function()
        Chk("T55", "B", "Buchhaltung aus Test-Briefkasten", function()
            local Le = A.Ledger
            local entries, seen = Copy(A.db.ledger.entries), Copy(A.db.ledger.seen)
            local mail = Copy(TM.fakeMail)
            local res = { pcall(function()
                TM:SeedMail()
                local n1 = Le:ScanInbox() or 0
                local n2 = Le:ScanInbox() or 0
                return n1 >= 2 and n2 == 0, string.format("erster Lauf %d, zweiter %d", n1, n2)
            end) }
            A.db.ledger.entries, A.db.ledger.seen = entries, seen
            wipe(TM.fakeMail); for _, m in ipairs(mail or {}) do table.insert(TM.fakeMail, m) end
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "Verkauf und Kauf gebucht, zweiter Lauf 0"
        end)
        end)

        B(function()
        Chk("T57", "B", "Neu einstellen", function()
            local X, Se = A.Extras, A.Seller
            local repost, batch = Copy(A.db.repost), Se.batch
            local res = { pcall(function()
                X:NoteReturned(FAKE + 22, 5)
                local n = X:RepostCount()
                local before = TradeCount()
                local ok, msg = X:RepostStep()
                Se.batch = batch
                return n >= 1 and TradeCount() == before, string.format("zum Neu-Einstellen %d, Klick: %s", n, tostring(msg))
            end) }
            A.db.repost = repost
            Se.batch = batch
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], ">= 1, nichts an den Server"
        end)
        end)

        B(function()
        Chk("T59", "B", "Händler-Verkauf (Kandidaten)", function()
            local list, total = A.Extras:VendorCandidates()
            local X = A.Extras
            local ok, msg = X:SellToVendor()                    -- ohne Händler: lehnt ab
            local atMerchant = X:IsAtMerchant()
            if atMerchant then X.selling = nil end
            return type(list) == "table" and (atMerchant or not ok) and Real("UseContainerItem") == 0,
                string.format("%d Kandidaten, ohne Händler abgelehnt %s", #list, tostring(not ok)), "ohne Fehler, nichts verkauft"
        end)
        if MerchantOpen() then
            Chk("T59b", "B", "Händler-Verkauf simuliert", function()
                local X = A.Extras
                local ok = X:SellToVendor()
                for _ = 1, 3 do X:SellStep() end
                X.selling = nil
                return Real("UseContainerItem") == 0, "UseContainerItem " .. Real("UseContainerItem"), "0"
            end)
        else
            Skp("T59b", "B", "Händler-Verkauf simuliert", "HALB: Händler ansprechen, dann /ahs testroutine haendler")
        end
        -- Oberfläche: eigener Knopf darf die Blizzard-Reiter "Händler" / "Rückkauf" nie verdecken
        if MerchantOpen() then
            Chk("T186", "B", "Händler-Knopf verdeckt keinen Reiter des Händlerfensters", function()
                local UI = A.UI
                if UI.UpdateVendorButton then UI:UpdateVendorButton() end
                local b = UI.vendorButton
                if not (b and b:IsShown()) then return true, "Knopf nicht sichtbar (aus oder nichts zu verkaufen)", "kein Reiter verdeckt" end
                local hit = UI:VendorButtonOverlap(b)
                return hit == nil, hit and ("verdeckt " .. hit) or "kein Reiter verdeckt", "kein Reiter verdeckt"
            end)
        else
            Skp("T186", "B", "Händler-Knopf verdeckt keinen Reiter des Händlerfensters", "HALB: Händler ansprechen, dann /ahs testroutine haendler")
        end
        end)

        B(function()
        Chk("T63", "B", "Berufe rechnen", function()
            local Cr = A.Crafting
            local p1, p2, out = FAKE + 30, FAKE + 31, FAKE + 32
            local saved = { mv = A.GetMarketValue, buy = A.GetVendorBuyPrice, sale = A.GetSalePrice, rel = A.IsReliable,
                recipes = Copy(A.db.recipes), lists = Copy(A.db.lists), api = Cr.API.ahstest }
            local res = { pcall(function()
                -- eigene Funktionen des Addons für Test-IDs umlenken (kein Blizzard-Global)
                A.GetMarketValue = function(s, id) if id == p1 then return 100 elseif id == p2 then return 300
                    elseif id == out then return 2000 end return saved.mv(s, id) end
                A.GetVendorBuyPrice = function(s, id) if id == p2 then return 50 end return saved.buy(s, id) end
                A.GetSalePrice = function(s, id) if id == out then return 2000 end return saved.sale(s, id) end
                A.IsReliable = function(s, id) if id == out then return true, { perDay = 4 } end return saved.rel(s, id) end
                local unit, atVendor = Cr:UnitPrice(p2, true)
                local key = A.Chars:Key()
                A.db.recipes[key] = A.db.recipes[key] or {}
                A.db.recipes[key]["AHS-Test"] = { t = time(), list = { { name = "AHS-Test Rezept", productID = out, made = 1,
                    reagents = { { p1, 2 }, { p2, 1 } } } } }
                local found
                for _, s in ipairs(Cr:TodaySuggestions(50)) do if s.productID == out then found = s end end
                -- Einkaufsliste über eine Test-Berufe-API (eigene Tabelle des Addons)
                Cr.API.ahstest = { info = function() return "AHS-Test Rezept", "optimal" end, link = function() return "item:" .. out end,
                    made = function() return 1, 1 end, numReagents = function() return 2 end,
                    reagent = function(_, r) local id = r == 1 and p1 or p2; return "x", r == 1 and 2 or 1, 0, "item:" .. id end,
                    title = function() return "AHS-Test Beruf" end, selected = function() return 1 end, num = function() return 1 end }
                local okL = Cr:ReagentsToList("ahstest", 1, 2)
                local exists = A.Lists:Exists("AHS-Test Beruf")
                return unit == 50 and atVendor and found and found.profit > 0 and okL and exists,
                    string.format("Händler %s/%s, Vorschlag %s, Liste %s", tostring(unit), tostring(atVendor),
                        found and A:FormatMoney(found.profit) or "nein", tostring(exists))
            end) }
            A.GetMarketValue, A.GetVendorBuyPrice, A.GetSalePrice, A.IsReliable = saved.mv, saved.buy, saved.sale, saved.rel
            A.db.recipes, A.db.lists = saved.recipes, saved.lists
            Cr.API.ahstest = saved.api
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "Händlerpreis billiger, Gewinn > 0, Liste angelegt"
        end)
        end)

        B(function()
        Chk("T65", "B", "Entzaubern lernen", function()
            local D = A.Disenchant
            local stats, shared = Copy(A.db.deStats), Copy(A.db.deShared)
            local res = { pcall(function()
                local prior = D:Prior(LINEN)          -- Leinenstoff: nicht entzauberbar
                local n0 = D:TotalLearned()
                local okR = pcall(D.Record, D, 2140, { { 10940, 2 } })     -- grüner Dolch -> Seltsamer Staub
                local n1 = D:TotalLearned()
                local y = D:Yield(2140)
                local v = D:GetValue(2140)
                local groups = D:Groups()
                return okR and n1 >= n0 and type(groups) == "table" and (prior == nil or prior == false or type(prior) == "table"),
                    string.format("gelernt %d -> %d, Gruppen %d, Wert %s", n0, n1, #groups, tostring(v))
            end) }
            A.db.deStats, A.db.deShared = stats, shared
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "ohne Fehler"
        end)
        end)

        B(function()
        Chk("T66", "B", "Charaktere", function()
            local Ch = A.Chars
            local chars = Copy(A.db.chars)
            local res = { pcall(function()
                local key = Ch:Key()
                Ch:RecordMoney(); Ch:ScanBags()
                local counts = Ch:ItemCounts(LINEN)
                local total = Ch:TotalMoney()
                local days = Ch:DailyTotals(7)
                Ch:ChangeSince(1)
                A.db.chars["AHS-Test-AHS-Test"] = { name = "AHS-Test", realm = "AHS-Test", money = 1, gold = {}, bags = {}, bank = {} }
                local okRm = Ch:Remove("AHS-Test-AHS-Test")
                local okMe = Ch:Remove(key)          -- eigener Charakter: abgelehnt
                -- Name und Realm nie in den Bericht
                return type(key) == "string" and key:find("-", 1, true) ~= nil and type(counts) == "table" and type(total) == "number"
                    and type(days) == "table" and okRm and not okMe and A.db.chars["AHS-Test-AHS-Test"] == nil,
                    string.format("Schlüssel Name-Realm, %d Tage, Testcharakter entfernt %s, eigener abgelehnt %s", #days,
                        tostring(okRm), tostring(not okMe))
            end) }
            A.db.chars = chars
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "alles ohne Fehler"
        end)
        end)

        B(function()
        Chk("T69", "B", "Verkaufschance und Ablauf-Erinnerung", function()
            local K = A.Comfort
            local ends, warned = Copy(A.db.ownedEnds), Copy(K.warned)
            local res = { pcall(function()
                K:BuildChances()
                local c = K:SellChance(LINEN)
                K:ChanceText(LINEN)
                K:OnOwnedRead({ { itemID = FAKE + 23, qty = 1, timeLeft = 1, auctionID = FAKE + 23, name = "AHS-Test" } })
                Capture(function() K:LoginExpiryCheck() end)
                K:ForgetOne(FAKE + 23)
                return c == nil or type(c) == "number" or type(c) == "table", "Chance " .. tostring(type(c))
            end) }
            A.db.ownedEnds, K.warned = ends, warned
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "ohne Fehler"
        end)
        end)

        B(function()
        Chk("T71", "B", "Alt-Klick ohne Alt", function()
            local UI = A.UI
            local before = UI.chartWin and UI.chartWin:IsShown()
            local r = A.Comfort:OnModifiedClick("item:" .. LINEN)
            local after = UI.chartWin and UI.chartWin:IsShown()
            return not r and (after and true or false) == (before and true or false), tostring(r), "nil, kein Fenster"
        end)
        Cli("T71b", "B", "Alt-Klick im Spiel", "Alt+Klick auf ein Taschen-Item: Preisverlauf (AH zu) bzw. Einkauf (AH offen)")
        end)

        B(function()
        Chk("T77", "B", "Sync an/aus/nur Gilde", function()
            local S = A.Sync
            local on, gOnly = S:IsEnabled() and true or false, S:GuildOnly() and true or false
            local j, l = Real("JoinTemporaryChannel"), Real("LeaveChannelByName")
            local t0 = S:GetStatusText()
            local res = { pcall(function()
                Capture(function() S:Toggle() end); local t1 = S:GetStatusText()
                Capture(function() S:Toggle() end)
                Capture(function() S:SetGuildOnly(not gOnly) end); local mid = S:GuildOnly() and true or false
                Capture(function() S:SetGuildOnly(gOnly) end)
                return t1 ~= t0 and mid ~= gOnly, string.format("Status %s -> %s", A:PlainText(t0), A:PlainText(t1))
            end) }
            local back = (S:IsEnabled() and true or false) == on and (S:GuildOnly() and true or false) == gOnly
            if not back then
                if (S:IsEnabled() and true or false) ~= on then Capture(function() S:Toggle() end) end
                if (S:GuildOnly() and true or false) ~= gOnly then Capture(function() S:SetGuildOnly(gOnly) end) end
            end
            if not res[1] then error(res[2], 0) end
            return res[2] and back and Real("JoinTemporaryChannel") == j and Real("LeaveChannelByName") == l,
                res[3], "Status ändert sich, Kanal 0, Werte wie vorher"
        end)
        end)

        -- HALB im Teil "server"
        if part ~= "server" then
            B(function()
            for _, c in ipairs({ { "T27", "Einbindung ins Auktionshaus" }, { "T37", "Warenkauf simuliert" },
                { "T42", "Sniper-Vorab-Reservierung kauft nie ohne Klick" }, { "T50", "Serie einstellen" },
                { "T52", "Unterboten" }, { "T126", "Scan-Auswertung in Portionen" } }) do
                Skp(c[1], c[1] == "T126" and "H" or "B", c[2], HALB_SERVER)
            end
            end)
        end
    end


    if want(part, "d") then B(function()
        if A.AH_LEGACY then
            Chk("T101", "D", "Alter Taschen- und Tooltip-Weg", function()
                local Se = A.Seller
                if Se.InvalidateBags then Se:InvalidateBags() end
                local items = Se:GetBagItems()
                return type(items) == "table", #items .. " Items", "Liste ohne Fehler"
            end)
            Skp("T98", "D", "Server-Wege altes AH", part == "server" and "siehe bisheriger Selbsttest (Scan, Suchen, Handel)" or HALB_SERVER)
        else
            for _, c in ipairs({ { "T98", "Server-Wege altes AH" }, { "T101", "Alter Taschen- und Tooltip-Weg" } }) do
                Skp(c[1], "D", c[2], "nur im alten Client (Classic Era, TBC)")
            end
        end
        if GetNumTradeSkills then
            Skp("T99", "D", "Alte Berufe-API", "HALB: Berufsfenster öffnen, dann /ahs testroutine berufe")
        else
            Skp("T99", "D", "Alte Berufe-API", "nur im alten Client (Classic Era, TBC)")
        end
        if A:API("GetMerchantItemInfo") then
            Skp("T100", "D", "Alter Händler-Weg", "HALB: Händler ansprechen, dann /ahs testroutine haendler")
        else
            Skp("T100", "D", "Alter Händler-Weg", "nur im alten Client (Classic Era, TBC)")
        end
    end) end

    if want(part, "e") then
        -- InitDB mit Testdaten: echte Datenbank, Sprache und Fehler-Zählung danach zurück
        local function SmallCopy()
            local db = {}
            for k, v in pairs(A.db) do if not NO_COPY[k] then db[k] = Copy(v) end end
            db.marketData, db.names = {}, {}
            return db
        end
        local function WithTestDB(build, fn)
            local real, realOld, migr = AHSentinelDB, AHAnalyzerProDB, A.migratedFromOld
            local realDB = A.db
            AHSentinelDB, AHAnalyzerProDB = build()
            A.migratedFromOld = nil
            local res = { pcall(fn) }
            AHSentinelDB, AHAnalyzerProDB, A.migratedFromOld = real, realOld, migr
            A.db = realDB
            A:ApplyUILanguage()
            local GT = GTest()
            if GT and GT.TrackErrors then pcall(GT.TrackErrors, "AHSentinel", A.version, A.db) end
            if not res[1] then error(res[2], 0) end
            return unpack(res, 2)
        end
        B(function()
        Chk("T106", "E", "Übernahme aus AH Analyzer Pro", function()
            return WithTestDB(function()
                return nil, { marketData = { [FAKE + 40] = { history = {} } }, dbVersion = 4, settings = {} }
            end, function()
                Capture(function() A:InitDB() end)
                local moved = type(AHSentinelDB) == "table" and AHSentinelDB.marketData and AHSentinelDB.marketData[FAKE + 40] ~= nil
                local mark = type(AHAnalyzerProDB) == "table" and AHAnalyzerProDB.migratedTo == "AHSentinel"
                local flag = A.migratedFromOld == true
                local first = AHSentinelDB
                A.migratedFromOld = nil
                Capture(function() A:InitDB() end)
                local again = A.migratedFromOld == true
                return moved and mark and flag and not again and AHSentinelDB == first,
                    string.format("übernommen %s, Vermerk %s, Hinweis %s, zweites Mal %s", tostring(moved), tostring(mark),
                        tostring(flag), tostring(again)), "übernommen, Vermerk, nur einmal"
            end)
        end)
        end)
        B(function()
        Chk("T107", "E", "kleine Migrationen", function()
            return WithTestDB(function()
                local db = SmallCopy()
                db.sniper.interval, db.sniper.fastSearch = 3, nil
                db.watcher.interval = 20
                db.lastScanTime = time() + 3600
                db.settings.detachedWindow, db.settings.ahIntegration = nil, true
                return db, nil
            end, function()
                Capture(function() A:InitDB() end)
                local d = A.db
                local gapOK = A.Watcher:Gap() < 20
                return d.sniper.interval == 0 and d.lastScanTime == 0 and d.settings.ahIntegration == false and gapOK,
                    string.format("Sniper %s, Scan-Zeit %s, im AH %s, Wächter-Pause %s", tostring(d.sniper.interval),
                        tostring(d.lastScanTime), tostring(d.settings.ahIntegration), tostring(A.Watcher:Gap())),
                    "0, 0, false, MIN_GAP"
            end)
        end)
        end)
        B(function()
        Chk("T108", "E", "beschädigte Einträge", function()
            return WithTestDB(function()
                local db = SmallCopy()
                db.marketData = { [1] = "kaputt", [2] = { history = nil }, [3] = { history = { { t = nil } } } }
                db.settings.lastSub = 5
                db.sniper.targets = { ["i:1"] = "x" }
                db.watcher.cats = nil
                db.vendorCost = { [1] = 5 }
                db.ledger.entries = { "x" }
                db.lists.items = db.lists.items or {}
                db.lists.items.x = 7
                db.chars = { x = true }
                db.deStats, db.sync.peers, db.recipes = nil, nil, 3
                return db, nil
            end, function()
                local errs = {}
                local function try(name, f, ...)
                    local ok, e = pcall(f, ...)
                    if not ok then errs[#errs + 1] = name .. ": " .. tostring(e):sub(1, 80) end
                end
                try("InitDB", function() Capture(function() A:InitDB() end) end)
                try("Heute tun", function() A.Comfort:TodayActions() end)
                try("Tooltip", function() if GameTooltip and GameTooltip.SetHyperlink then
                    GameTooltip:SetOwner(UIParent, "ANCHOR_NONE"); GameTooltip:SetHyperlink("item:" .. LINEN); GameTooltip:Hide() end end)
                try("Wächter", function() A.Watcher:Tick() end)
                try("Sniper", function() A.Sniper:Tick() end)
                try("Ablauf", function() Capture(function() A.Comfort:LoginExpiryCheck() end) end)
                try("Marktliste", function() A:GetMarketValue(1); A:GetMarketValue(3); A:GetHistory(2) end)
                return #errs == 0, #errs == 0 and "kein Lua-Fehler" or table.concat(errs, " | "), "kein Lua-Fehler"
            end)
        end)
        end)
    end

    if want(part, "g") then B(function()
        if type(_G.ProfessionSentinelAPI) == "table" and _G.ProfessionSentinelAPI.version == 1 then
            Chk("T119", "G", "echtes ProfessionSentinel geladen", function()
                local ok, rows = pcall(A.Comfort.TodayActions, A.Comfort)
                return ok, ok and (#(rows or {}) .. " Zeilen in Heute tun") or tostring(rows), "ohne Fehler"
            end)
        else
            Skp("T119", "G", "echtes ProfessionSentinel geladen", "HALB: ProfessionSentinel zusätzlich aktivieren")
        end
        local other = (C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded)
        local has = other and (other("Auctionator") or other("TradeSkillMaster"))
        if has and A:IsAHOpen() then
            Chk("T120", "G", "fremde AH-Addons", function()
                return A.UI.ahLastError == nil, tostring(A.UI.ahLastError), "kein UI.ahLastError"
            end)
        else
            Skp("T120", "G", "fremde AH-Addons", "HALB: Auctionator oder TSM aktiv und Auktionshaus offen")
        end
    end) end

    if want(part, "h") then
        B(function()
        if not (GameTooltip and GameTooltip.SetHyperlink and GameTooltip.SetOwner) then
            return Skp("T122", "H", "Tooltip schnell", "GameTooltip fehlt")
        end
        Chk("T122", "H", "Tooltip schnell", function()
            local st = A.db.settings
            local chart = st.tooltipChart
            local t0 = Ms()
            for _ = 1, 100 do
                GameTooltip:SetOwner(UIParent, "ANCHOR_NONE"); GameTooltip:SetHyperlink("item:" .. LINEN); GameTooltip:Hide()
            end
            local per = (Ms() - t0) / 100
            return per < 2, string.format("%.2f ms je Aufruf", per), "< 2 ms"
        end)
        end)
        B(function()
        if not A.Crafting.kind then
            return Skp("T124", "H", "Berufsliste (Zwischenspeicher)", "HALB: Berufsfenster öffnen, dann /ahs testroutine berufe")
        end
        Chk("T124", "H", "Berufsliste (Zwischenspeicher)", function()
            local Cr = A.Crafting
            local t0 = Ms(); Cr:ReadAll(Cr.kind); local a = Ms() - t0
            t0 = Ms(); Cr:ReadAll(Cr.kind); local b = Ms() - t0
            return Cr.kind ~= "modern" or b < 2, string.format("erstes Mal %.1f ms, zweites Mal %.1f ms", a, b), "zweites Mal < 2 ms"
        end)
        end)
    end

    if want(part, "j") then
        B(function()
        Chk("T146", "J", "KO 5a: leere Rezeptliste nicht gemerkt", function()
            local Cr = A.Crafting
            local kind, at, rem = Cr.kind, Cr.rememberedAt, Cr.Remember
            local res = { pcall(function()
                Cr.kind, Cr.rememberedAt = "modern", nil
                Cr.Remember = function() return 0 end
                Cr.evt:GetScript("OnEvent")(Cr.evt, "TRADE_SKILL_LIST_UPDATE")
                local empty = Cr.rememberedAt
                Cr.Remember = function() return 3 end
                Cr.evt:GetScript("OnEvent")(Cr.evt, "TRADE_SKILL_LIST_UPDATE")
                local full = Cr.rememberedAt
                return empty == nil and full ~= nil, string.format("leer %s, voll %s", tostring(empty), full and "gesetzt" or "nil")
            end) }
            Cr.kind, Cr.rememberedAt, Cr.Remember = kind, at, rem
            if Cr.panel and not kind then Cr.panel:Hide() end
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "leer nil, voll gesetzt"
        end)
        end)
        B(function()
        local Cr0 = A.Crafting
        if not (Cr0.ModernRecipeID and Cr0:TradeKind() == "modern" and Cr0:ModernRecipeID(1)) then
            return Skp("T147", "J", "KO 5b: Zutaten-Knopf ohne SchematicForm", "HALB: Berufsfenster (moderner Client) öffnen, dann /ahs testroutine berufe")
        end
        Chk("T147", "J", "KO 5b: Zutaten-Knopf ohne SchematicForm", function()
            local Cr = A.Crafting
            local last = Cr.lastModernRecipe
            local id = Cr:ModernRecipeID(1)
            Cr:OnRecipeSelected({ recipeID = id })
            local got = Cr.API.modern.selected()
            Cr.lastModernRecipe = last
            return got ~= nil, tostring(got), "Index des zuletzt gewählten Rezepts"
        end)
        end)
        B(function()
        if not (A.Crafting:TradeKind() == "modern" and A.Crafting:SchematicCacheSize() > 0) then
            return Skp("T148", "J", "KO 5c: Zwischenspeicher bleibt bei Listen-Ereignissen", "HALB: Berufsfenster (moderner Client) öffnen, dann /ahs testroutine berufe")
        end
        Chk("T148", "J", "KO 5c: Zwischenspeicher bleibt bei Listen-Ereignissen", function()
            local Cr = A.Crafting
            Cr.evt:GetScript("OnEvent")(Cr.evt, "TRADE_SKILL_LIST_UPDATE")
            local n1 = Cr:SchematicCacheSize()
            Cr.evt:GetScript("OnEvent")(Cr.evt, "TRADE_SKILL_LIST_UPDATE")
            local n2 = Cr:SchematicCacheSize()
            return n2 >= n1, string.format("%d -> %d Einträge", n1, n2), "nicht geleert"
        end)
        end)
        B(function()
        Chk("T159", "J", "GetDockFrame liefert den sichtbaren Frame bzw. nil", function()
            local Cr = A.Crafting
            if not Cr.GetDockFrame then return false, "Funktion fehlt", "AHAnalyzerPro.Crafting:GetDockFrame()" end
            local had, shown = Cr.panel ~= nil, Cr.panel and Cr.panel:IsShown()
            local res = { pcall(function()
                local f = Cr:EnsurePanel()
                f:Show(); local a = Cr:GetDockFrame()
                f:Hide(); local b = Cr:GetDockFrame()
                return a == f and b == nil, string.format("sichtbar: %s, versteckt: %s", a == f and "Frame" or tostring(a), tostring(b))
            end) }
            if Cr.panel then if shown then Cr.panel:Show() else Cr.panel:Hide() end end
            if not had and Cr.panel and not shown then Cr.panel:Hide() end
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "sichtbar: Frame, versteckt: nil"
        end)
        end)
        B(function()
        Chk("T160", "J", "Gewinn-Fenster neben der Reiterleiste, nie darüber", function()
            local Cr = A.Crafting
            -- eigene Testrahmen: "Berufsfenster" mit einer Reiterleiste, die rechts 40 Punkte herausragt
            local p = self.dockTestParent
            if not p then
                p = CreateFrame("Frame", nil, UIParent); p:SetSize(400, 300)
                local tabs = CreateFrame("Frame", nil, p); tabs:SetSize(44, 200)
                tabs:SetPoint("TOPLEFT", p, "TOPRIGHT", -4, -40)
                p.tabs = tabs
                self.dockTestParent = p
            end
            p:ClearAllPoints(); p:SetPoint("CENTER", UIParent, "CENTER", -300, 0); p:Show(); p.tabs:Show()
            local f = Cr:EnsurePanel()
            local wasShown, wasOffset = f:IsShown(), Cr.dockOffset
            local res = { pcall(function()
                Cr:Dock(f, p)
                local withTabs = Cr.dockOffset
                local fl = f:GetLeft() and f:GetLeft() * f:GetEffectiveScale()
                local tr = p.tabs:GetRight() * p.tabs:GetEffectiveScale()
                p.tabs:Hide()
                p:SetHitRectInsets(0, 0, 0, 0)
                Cr:Dock(f, p)
                local without = Cr.dockOffset
                -- altes Berufsfenster mit 34 Punkten unsichtbarem Rand: seit Punkt 10 (offen-ahsentinel) gilt x >= 0,
                -- nie über dem Fenster oder den Reitern (Entscheid der Prüf-Sitzung 9. Nov. 09:35)
                p:SetHitRectInsets(0, 34, 0, 0)
                Cr:Dock(f, p)
                local inset = Cr.dockOffset
                return fl and fl >= tr and without == 0 and inset and inset >= 0,
                    string.format("mit Reitern %+.0f (links %.0f, Reiter rechts %.0f), ohne Rand %+.0f, mit Rand 34 %+.0f",
                    withTabs or 0, fl or -1, tr, without or 0, inset or 0)
            end) }
            p:SetHitRectInsets(0, 0, 0, 0)
            p:Hide()
            -- echte Lage wiederherstellen
            Cr.dockOffset = wasOffset
            if Cr.kind and Cr.API[Cr.kind] then Cr:Dock(f, Cr.API[Cr.kind].frame()) end
            if not wasShown then f:Hide() end
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "linke Kante >= rechte Kante der Reiter; ohne Rand 0, mit Rand 34 -> x >= 0"
        end)
        end)
        B(function()
        Chk("T163", "J", "GetDockFrame(true) auch verborgen", function()
            local Cr = A.Crafting
            local had, shown = Cr.panel, Cr.panel and Cr.panel:IsShown()
            local res = { pcall(function()
                local f = Cr:EnsurePanel()
                f:Hide()
                local a, b = Cr:GetDockFrame(true), Cr:GetDockFrame()
                f:Show()
                local c, d = Cr:GetDockFrame(true), Cr:GetDockFrame()
                return a == f and b == nil and c == f and d == f,
                    string.format("verborgen: (true) %s / () %s, sichtbar: %s / %s", a == f and "Frame" or "nil",
                        b == f and "Frame" or "nil", c == f and "Frame" or "nil", d == f and "Frame" or "nil")
            end) }
            if Cr.panel then if shown then Cr.panel:Show() else Cr.panel:Hide() end end
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "verborgen: Frame / nil, sichtbar: Frame / Frame"
        end)
        end)
        B(function()
        Chk("T162", "J", "Preisfeld g/s/c in allen Sprachen, nie k", function()
            local lang = A.uiLang
            local bad = {}
            local ok, err = pcall(function()
                for _, l in ipairs({ "deDE", "enUS", "frFR", "esES", "esMX", "ptBR", "itIT", "ruRU", "koKR", "zhCN", "zhTW" }) do
                    A.uiLang = l
                    local a, b = A:FormatMoneyInput(78), A:FormatMoneyInput(390)
                    if a ~= "78c" or b ~= "3s 90c" then bad[#bad + 1] = l .. ": " .. a .. " / " .. b end
                end
            end)
            A.uiLang = lang
            if not ok then error(err, 0) end
            for text, want in pairs({ ["78"] = 780000, ["78c"] = 78, ["1s 20c"] = 120, ["1g"] = 10000, ["78k"] = 78 }) do
                if A:ParseGold(text) ~= want then bad[#bad + 1] = text .. " -> " .. tostring(A:ParseGold(text)) end
            end
            return #bad == 0, #bad == 0 and "78c, 3s 90c; Eingaben verstanden" or table.concat(bad, "; "),
                "78c / 3s 90c; 78=78g, 78c, 1s 20c, 1g, 78k=78c"
        end)
        end)
        B(function()
        local AC = _G.AuctionCategories
        if not (type(AC) == "table" and #AC > 0) then
            return Skp("T161", "J", "Kategorien wie im Blizzard-AH", "HALB: Auktionshaus einmal öffnen (lädt die Blizzard-Kategorien)")
        end
        Chk("T161", "J", "Kategorien wie im Blizzard-AH", function()
            local Bu = A.Buy
            Bu:BuildCategories()
            -- unsere Liste: Hauptkategorie -> Namen der Unterkategorien in Reihenfolge
            local mine, order = {}, {}
            for _, c in ipairs(Bu.CATS) do
                if c.key ~= "all" and not c.level then mine[c.key] = { name = Bu:CatText(c), subs = {} }; order[#order + 1] = c.key
                elseif c.level and c.parent and mine[c.parent] then table.insert(mine[c.parent].subs, Bu:CatText(c)) end
            end
            local bad, i = {}, 0
            for _, cat in ipairs(AC) do
                local hasClass = false
                for _, f in ipairs(cat.filters or {}) do if type(f) == "table" and f.classID then hasClass = true end end
                if cat.name and hasClass and not cat.implicitFilter then
                    i = i + 1
                    local m = mine[order[i] or ""]
                    if not m or m.name ~= cat.name then bad[#bad + 1] = cat.name .. ": fehlt/Reihenfolge"
                    else
                        local want = {}
                        for _, sub in ipairs(cat.subCategories or {}) do
                            local sh = false
                            for _, f in ipairs(sub.filters or {}) do if type(f) == "table" and f.classID then sh = true end end
                            if sub.name and sh then want[#want + 1] = sub.name end
                        end
                        if table.concat(want, "|") ~= table.concat(m.subs, "|") then
                            bad[#bad + 1] = string.format("%s: %d statt %d Unterkategorien", cat.name, #m.subs, #want)
                        end
                    end
                end
            end
            return #bad == 0, #bad == 0 and (i .. " Hauptkategorien gleich") or table.concat(bad, "; "), "gleich wie das Blizzard-AH"
        end)
        end)
        -- Klick auf ein Rezept (0.65.12): Test-Berufsliste über eine eigene Tabelle des Addons (Cr.API.ahstest)
        local function FakeProfession(opts)
            local st = { filtered = opts.filtered, collapsed = opts.collapsed, sel = nil, reveals = 0 }
            local names = { "AHS-Test A", "AHS-Test B", "AHS-Test C" }
            local function visible()
                local out = {}
                for _, n in ipairs(names) do
                    if not ((st.filtered and n ~= "AHS-Test A") or (st.collapsed and n == "AHS-Test C")) then out[#out + 1] = n end
                end
                return out
            end
            st.api = {
                num = function() return #visible() end,
                info = function(i) return visible()[i], "optimal" end,
                link = function() return nil end, made = function() return 1, 1 end, numReagents = function() return 0 end,
                reagent = function() return nil end, title = function() return "AHS-Test Beruf" end,
                selected = function() return st.sel end,
                select = function(i) st.sel = i end,
                find = function(r) for i, n in ipairs(visible()) do if n == r.name then return i end end end,
                reveal = function() st.filtered, st.collapsed, st.reveals = false, false, st.reveals + 1 end,
                frame = function() return nil end,
            }
            return st
        end
        local function RunSelect(id, name, opts, target)
            B(function()
                local Cr = A.Crafting
                local st = FakeProfession(opts)
                Cr.API.ahstest = st.api
                self.selTest = { st = st, lines = {}, real = A.Print }
                A.Print = function(_, msg) table.insert(self.selTest.lines, A:PlainText(tostring(msg))) end
                Cr:SelectRecipe({ kind = "ahstest", name = target, index = 3 })
                return "WAIT", function() return Cr.pendingSelect == nil end, 3, function()
                    local t = self.selTest
                    self.selTest = nil
                    A.Print = t.real
                    Cr.API.ahstest = nil
                    Chk(id, "J", name, function()
                        local n = t.st.sel and t.st.api.info(t.st.sel)
                        return n == target, string.format("gewählt %s, Filter zurückgesetzt %d-mal, Meldungen %d", tostring(n),
                            t.st.reveals, #t.lines), target
                    end)
                end
            end)
        end
        RunSelect("T165", "Suchtext im Berufsfenster aktiv: Klick öffnet trotzdem das Rezept", { filtered = true }, "AHS-Test B")
        RunSelect("T166", "Rezept in zugeklappter Kategorie: wird geöffnet", { collapsed = true }, "AHS-Test C")
        B(function()
        Chk("T164", "J", "kein Rahmen verdeckt eine Rezept-Zeile", function()
            local Cr = A.Crafting
            local f = Cr:EnsurePanel()
            local wasShown = f:IsShown()
            f:Show()
            local bad, checked = {}, 0
            local res = { pcall(function()
                for _, row in ipairs(f.top.rows or {}) do
                    local l, b, w, h = row:GetRect()
                    if l and w and w > 0 then
                        checked = checked + 1
                        local cx, cy = l + w / 2, b + h / 2
                        local function scan(fr, depth)
                            if depth > 5 then return end
                            for _, c in ipairs({ fr:GetChildren() }) do
                                if c ~= row and c:IsShown() then
                                    local isAncestor = false
                                    local p2 = row:GetParent()
                                    while p2 do if p2 == c then isAncestor = true end p2 = p2:GetParent() end
                                    local cl, cb, cw, ch = c:GetRect()
                                    if not isAncestor and cl and cx >= cl and cx <= cl + cw and cy >= cb and cy <= cb + ch
                                        and c.IsMouseEnabled and c:IsMouseEnabled() and c:GetFrameLevel() >= row:GetFrameLevel()
                                        and not (row:GetParent() == c:GetParent() and c:GetObjectType() == "Button") then
                                        bad[#bad + 1] = tostring(c:GetName() or c:GetObjectType())
                                    end
                                    scan(c, depth + 1)
                                end
                            end
                        end
                        scan(f, 1)
                    end
                end
            end) }
            if not wasShown then f:Hide() end
            if not res[1] then error(res[2], 0) end
            return #bad == 0, string.format("%d Zeilen geprüft, verdeckt: %s", checked, #bad == 0 and "keine" or table.concat(bad, ", ")),
                "keine fremden Rahmen mit Maus über den Zeilen"
        end)
        end)
        -- 20 Ereignisse in 1 s -> höchstens 3 Aufbauten; Klick während des Aufbaus öffnet das Rezept; < 16 ms pro Frame
        B(function()
            local Cr = A.Crafting
            local st = FakeProfession({})
            Cr.API.ahstest = st.api
            local f = Cr:EnsurePanel()
            self.thr = { st = st, kind = Cr.kind, shown = f:IsShown(), builds = Cr.topBuilds, t0 = GetTime(), n = 0,
                measure = A.jobMeasure }
            A.jobMeasure = { max = 0, frames = 0 }
            Cr.kind = "ahstest"
            f:Show()
            return "WAIT", function()
                local t = self.thr
                -- je Abfrage (alle 0,25 s) 5 Ereignisse: 20 in rund 1 s
                for _ = 1, 5 do
                    if t.n < 20 then
                        t.n = t.n + 1
                        Cr:RequestRefresh(true)
                        if t.n == 10 then Cr:SelectRecipe({ kind = "ahstest", name = "AHS-Test B", index = 2 }) end
                    end
                end
                return GetTime() - t.t0 >= 1.5 and not Cr.refreshPlanned and not Cr.topBuilding
            end, 6, function()
                local t = self.thr
                self.thr = nil
                local builds = Cr.topBuilds - t.builds
                local m = A.jobMeasure
                A.jobMeasure = t.measure
                Cr.kind = t.kind
                Cr.API.ahstest = nil
                Cr.pendingSelect = nil
                if not t.shown then f:Hide() end
                Cr.topDirty = true
                Chk("T167", "J", "Ereignisse gesammelt: höchstens 3 Neuaufbauten", function()
                    return builds >= 1 and builds <= 3, string.format("%d Ereignisse, %d Aufbauten", t.n, builds), "1 bis 3"
                end)
                Chk("T168", "J", "Klick während des Aufbaus öffnet das Rezept", function()
                    local n = t.st.sel and t.st.api.info(t.st.sel)
                    return n == "AHS-Test B", tostring(n), "AHS-Test B"
                end)
                Chk("T169", "H", "Aufbau der Rangliste < 16 ms pro Frame", function()
                    return (m.max or 0) < 16, string.format("längste Portion %.1f ms", m.max or 0), "< 16 ms"
                end)
            end
        end)
        B(function()
        Chk("T170", "J", "Forever: Einstellgebühr mind. 1s, nie erstattet, im Gewinn-Fenster abgezogen", function()
            local g2 = G()
            if not (g2 and g2.SetTestFlavor) then return false, "SetTestFlavor fehlt" end
            local Cr = A.Crafting
            local p1, out = FAKE + 50, FAKE + 51
            local saved = { mv = A.GetMarketValue, api = Cr.API.ahstest, force = A.forceForever }
            local res = { pcall(function()
                A.GetMarketValue = function(sf, id) if id == p1 then return 1000 elseif id == out then return 2000 end return saved.mv(sf, id) end
                Cr.API.ahstest = { info = function() return "AHS-Test Kettenhose", "optimal" end, link = function() return "item:" .. out end,
                    made = function() return 1, 1 end, numReagents = function() return 1 end,
                    reagent = function() return "x", 1, 0, "item:" .. p1 end, title = function() return "AHS-Test" end,
                    selected = function() return 1 end, select = function() end, num = function() return 1 end }
                A.forceForever = nil
                g2.SetTestFlavor("forever")
                local f20, f300 = A:ForeverAuctionFee(20), A:ForeverAuctionFee(6000)
                local rf = Cr:ReadRecipe("ahstest", 1)
                g2.SetTestFlavor("era")
                local re = Cr:ReadRecipe("ahstest", 1)
                local refunded = A:DepositRefunded()
                g2.SetTestFlavor(nil)
                -- Forever (Regel 9. Nov.): 2000 - max(5 %, 1s) = 1900 - 1000 Material = 900, keine Einstellgebühr; Era: 900
                return f20 == 100 and f300 == 300 and (rf.deposit or 0) == 0 and rf.profit == 900 and re.profit == 900 and refunded,
                    string.format("20c -> %s, 3s -> %s, Gewinn Forever %s (Gebühr %s), Era %s", A:FormatMoneyInput(f20),
                        A:FormatMoneyInput(f300), A:FormatMoneyInput(rf.profit), A:FormatMoneyInput(rf.deposit), A:FormatMoneyInput(re.profit))
            end) }
            A.GetMarketValue, Cr.API.ahstest, A.forceForever = saved.mv, saved.api, saved.force
            if g2.SetTestFlavor then g2.SetTestFlavor(nil) end
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "1s, 3s, Forever 8s (Gebühr 1s), Era 9s"
        end)
        end)
        B(function()
        Chk("T171", "J", "Klick ohne vorherigen Klick: Rezept sofort gewählt (Befund 5. Nov., 50 s)", function()
            local Cr = A.Crafting
            local st = FakeProfession({})
            Cr.API.ahstest = st.api
            local res = { pcall(function()
                Cr.lastClick = nil
                Cr:SelectRecipe({ kind = "ahstest", name = "AHS-Test C", index = 3 })
                local c = Cr.lastClick
                local n = st.sel and st.api.info(st.sel)
                return Cr.pendingSelect == nil and c and c.ok and c.ms < 500 and n == "AHS-Test C",
                    string.format("gleich gewählt: %s, %s ms, Weg %s", tostring(n), c and tostring(c.ms) or "-", c and tostring(c.way) or "-")
            end) }
            Cr.API.ahstest = nil
            Cr.pendingSelect = nil
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "im selben Aufruf gewählt, < 500 ms"
        end)
        end)
        B(function()
        Chk("T172", "J", "Diagnose-Protokoll: Einträge, Zähler, GSDIAG1, keine Namen", function()
            local Dg = A.Diag
            if not Dg then return false, "Diag.lua fehlt", "A.Diag" end
            local d = Dg.Store()
            local saved = Copy(d)
            local res = { pcall(function()
                d.entries = {}
                Dg:Add("KLICK", "Rezept AHS-Test · Rezept-ID 1", 12)
                Dg:Add("KLICK", "Rezept AHS-Test · Rezept-ID 1", 30)
                Dg:Error("AHS-Test", "Fehler x"); Dg:Error("AHS-Test", "Fehler x")
                A:Fire("CRAFT_TOP_BUILT", "TRADE_SKILL_LIST_UPDATE", 5, 3)
                local text = Dg:Text()
                local exp = Dg:Export()
                local me = UnitName and UnitName("player")
                local realm = GetRealmName and GetRealmName()
                -- Kopfzeilen (Client-Version, z. B. "WoW Forever") nicht mitprüfen: der Realm kann gleich heissen wie die Spielversion
                local body = text:gsub("^[^\n]*\n[^\n]*\n", "")
                local leak = (me and me ~= "" and text:find(me, 1, true)) or (realm and realm ~= "" and body:find(realm, 1, true))
                local klick, fehler = d.entries[3], d.entries[2]
                return klick and klick.n == 2 and klick.ms == 30 and fehler and fehler.n == 2 and d.entries[1].k == "AUFBAU"
                    and exp:sub(1, 19) == "GSDIAG1|AHSentinel|" and not leak,
                    string.format("%d Einträge, KLICK x%s (%s ms), FEHLER x%s, Export %s, Name im Text: %s", #d.entries,
                        tostring(klick and klick.n), tostring(klick and klick.ms), tostring(fehler and fehler.n), exp:sub(1, 19), leak and "JA" or "nein")
            end) }
            Replace(d, saved)
            self:ClearTestErrors()
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "gezählt, GSDIAG1|AHSentinel|, keine Namen"
        end)
        end)
        -- Befund 5. Nov.: Klick wählt erst nach 50 s -> spätestens nach 0,5 s entschieden, mit Meldung
        B(function()
            local Cr = A.Crafting
            local st = FakeProfession({})
            st.api.select = function() end                  -- das Berufsfenster reagiert nicht
            Cr.API.ahstest = st.api
            self.t173 = { lines = {}, real = A.Print, t0 = GetTime() }
            A.Print = function(_, msg) table.insert(self.t173.lines, A:PlainText(tostring(msg))) end
            Cr.lastClick = nil
            Cr:SelectRecipe({ kind = "ahstest", name = "AHS-Test B", index = 2 })
            return "WAIT", function() return Cr.pendingSelect == nil end, 3, function()
                local t = self.t173
                self.t173 = nil
                A.Print = t.real
                Cr.API.ahstest = nil
                Cr.pendingSelect = nil
                local secs = GetTime() - t.t0
                Chk("T173", "J", "Rezept wählt sich nicht: nach höchstens 0,5 s Meldung statt 50 s warten", function()
                    local c = Cr.lastClick
                    return c and c.ok == false and secs <= 1 and #t.lines >= 1,
                        string.format("entschieden nach %.2f s, Meldungen %d", secs, #t.lines), "<= 0,5 s (Takt 0,25 s), 1 Meldung"
                end)
            end
        end)
        B(function()
            if not modern then return end
            for _, c in ipairs({
                { "T175", "Rezept im ProfessionSentinel-Panel ohne vorherigen AHSentinel-Klick anklicken: Berufsfenster zeigt es in < 0,5 s (/ahs protokoll: KLICK ... gewählt)" },
                { "T176", "Rezept in AHSentinel \"Beste Rezepte\" anklicken, auch mit Suchtext im Berufsfenster: sofort gewählt, kein Chat-Hinweis" },
                { "T177", "Berufsfenster mit AHSentinel und ProfessionSentinel öffnen: nebeneinander, Berufsreiter frei, /ahs protokoll ohne ÜBERLAPPT" },
                { "T178", "Kupferne Kettenhose im Gewinn-Fenster: 18c Gewinn, Zeile Einstellgebühr 1s" },
                { "T179", "Auktionshaus öffnen, Einkauf -> Waffen: Unterkategorien gleich wie im Blizzard-AH" },
            }) do Cli(c[1], "J", "Im Spiel", c[2]) end
        end)
        B(function()
        Chk("T180", "J", "Köderwerte: Rezept-Auswahl und Protokoll verarbeiten geschützte Werte nicht", function()
            local Cr, Dg = A.Crafting, A.Diag
            local last = Cr.lastModernRecipe
            local d = Dg and Dg.Store()
            local n0 = d and #d.entries or 0
            local ok, err = WithSecret(function()
                Cr:OnRecipeSelected(SECRET)
                if Dg then Dg:Add("KLICK", SECRET, 5); Dg:Add("KLICK", "AHS-Test", SECRET) end
            end)
            local changed = Cr.lastModernRecipe ~= last
            Cr.lastModernRecipe = last
            local n1 = d and #d.entries or 0
            if not ok then error(err, 0) end
            return not changed and n1 == n0, string.format("Auswahl geändert %s, neue Einträge %d", tostring(changed), n1 - n0),
                "keine Wirkung, kein Lua-Fehler"
        end)
        end)
        -- 0.65.17: Einstellgebühr messen, Warnung, "Heute tun" unter Händlerpreis
        local FAKE_ID = 999990017
        B(function()
        Chk("T181", "J", "WoW Forever: nur EINE Gebühr = max(5 %, 1s) pro Auktion; andere Versionen 5 %", function()
            local saved = A.forceForever
            local res = { pcall(function()
                A.forceForever = true
                local f = {
                    A:ForeverAuctionFee(390), A:ForeverAuctionFee(200), A:ForeverAuctionFee(10000),
                    A:SaleFee(FAKE_ID, 1, 20, 1),                 -- Stapel 20 x 1c -> einmal 1s
                    A:SaleFee(FAKE_ID, 10000, 2, 2),              -- 2 Auktionen zu 1g -> 2 x 5s
                    A:ExpectedDepositLoss(FAKE_ID, 5),            -- keine Einstellgebühr
                    A.Seller:Deposit(FAKE_ID, 2, 1, true, nil),
                }
                A.forceForever = false
                f[#f + 1] = A:SaleFee(FAKE_ID, 200, 1)            -- Era/TBC/Retail: 5 % = 10c
                f[#f + 1] = A:SaleFee(FAKE_ID, 10000, 1)          -- 500c
                return f
            end) }
            A.forceForever = saved
            if not res[1] then error(res[2], 0) end
            local f = res[2]
            local want = { 100, 100, 500, 100, 1000, 0, 0, 10, 500 }
            local ok = true
            for k, v in ipairs(want) do if f[k] ~= v then ok = false end end
            local got = {}
            for k = 1, #want do got[k] = tostring(f[k]) end
            return ok, table.concat(got, ", "), table.concat(want, ", ")
        end)
        end)
        B(function()
        Chk("T182", "J", "Gebühr beim Einstellen: Protokoll EINSTELLEN mit Preis, Menge, Gebühr, ohne Namen", function()
            local Se, Dg = A.Seller, A.Diag
            local d = Dg and Dg.Store()
            local n0 = d and #d.entries or 0
            local ok, err = pcall(Se.RecordDeposit, Se, { itemID = FAKE_ID, qty = 5, auctions = 1, unitPrice = 1000, duration = 2, deposit = 250 }, 250)
            local e = d and #d.entries > n0 and d.entries[1]
            local text = e and (tostring(e.k) .. " " .. tostring(e.t)) or ""
            if e then table.remove(d.entries, 1) end
            if not ok then error(err, 0) end
            local fields = text:find("EINSTELLEN", 1, true) and text:find(tostring(FAKE_ID), 1, true) and text:find("5000", 1, true)
                and text:find("250", 1, true) and text:find("5.00", 1, true)
            local noName = not (UnitName and text:find(UnitName("player") or "\0", 1, true))
            return (not Dg) or (fields and noName and true or false), "Eintrag: " .. text, "Item, Menge 5, 5000 gesamt, Gebühr 250 (5.00 %)"
        end)
        end)
        B(function()
        Chk("T183", "J", "Einstellgebühr: Warnung ab 10 % vom Preis (einstellbar, 0 = aus)", function()
            local Se, st = A.Seller, A.db.settings
            local saved = st.feeWarnPct
            st.feeWarnPct = nil
            local a = Se:FeeTooHigh(200, 1000, 1)     -- 20 %
            local b = Se:FeeTooHigh(50, 1000, 1)      -- 5 %
            local c = Se:FeeTooHigh(150, 100, 10)     -- 15 % bei Menge 10
            st.feeWarnPct = 0
            local d = Se:FeeTooHigh(900, 1000, 1)
            st.feeWarnPct = saved
            return a and b == nil and c and d == nil and true or false,
                string.format("20%%: %s, 5%%: %s, 15%% Menge 10: %s, aus: %s", tostring(a), tostring(b), tostring(c), tostring(d)), "Warnung, keine, Warnung, keine"
        end)
        end)
        B(function()
        Chk("T184", "J", "Heute tun: Angebot unter Händlerpreis ergibt Zeile mit richtigem Gewinn, sonst keine", function()
            local Bu, db = A.Buy, A.db
            local saved = { md = db.marketData, res = Bu.results, rt = Bu.resultsTime, det = Bu.detail, vp = db.vendorPrices[FAKE_ID],
                vp2 = db.vendorPrices[FAKE_ID + 1], min = db.settings.vendorFlipMin }
            local res = { pcall(function()
                db.marketData, Bu.results = {}, {}
                db.vendorPrices[FAKE_ID] = 80
                Bu.detail = { itemID = FAKE_ID, commodity = true, time = time(), listings = { { price = 50, qty = 5, ownQty = 0 } } }
                local r1 = A:VendorFlipOffers(0, 10)
                local r1def = A:VendorFlipOffers(nil, 10)                -- Standard 10 Silber: 1s 50c reicht nicht
                Bu.detail.listings = { { price = 90, qty = 5, ownQty = 0 } }
                local r2 = A:VendorFlipOffers(0, 10)
                db.vendorPrices[FAKE_ID + 1] = nil
                Bu.detail = { itemID = FAKE_ID + 1, commodity = true, time = time(), listings = { { price = 1, qty = 5, ownQty = 0 } } }
                local okNoVendor = (A:GetVendorPrice(FAKE_ID + 1) or 0) == 0
                local r3 = A:VendorFlipOffers(0, 10)
                return r1, r1def, r2, r3, okNoVendor
            end) }
            db.marketData, Bu.results, Bu.resultsTime, Bu.detail = saved.md, saved.res, saved.rt, saved.det
            db.vendorPrices[FAKE_ID], db.vendorPrices[FAKE_ID + 1], db.settings.vendorFlipMin = saved.vp, saved.vp2, saved.min
            if not res[1] then error(res[2], 0) end
            local r1, r1def, r2, r3, okNoVendor = res[2], res[3], res[4], res[5], res[6]
            local row = r1[1]
            local good = row and row.itemID == FAKE_ID and row.profit == 150 and row.qty == 5 and #r1def == 0 and #r2 == 0
                and (#r3 == 0 or not okNoVendor)
            return good and true or false, string.format("Gewinn %s (%s), mit 10s-Grenze %d Zeilen, über Händlerpreis %d, ohne Händlerpreis %d",
                tostring(row and row.profit), row and A:FormatMoney(row.profit) or "-", #r1def, #r2, #r3),
                "+1s 50c (150), 0, 0, 0"
        end)
        end)
        B(function()
        Chk("T185", "J", "Heute tun: höchstens 10 Angebote unter Händlerpreis, nach Gewinn sortiert", function()
            local Bu, db = A.Buy, A.db
            local saved = { md = db.marketData, res = Bu.results, rt = Bu.resultsTime, det = Bu.detail }
            local vps = {}
            local res = { pcall(function()
                db.marketData, Bu.detail = {}, nil
                Bu.results, Bu.resultsTime = {}, time()
                for i = 1, 14 do
                    local id = FAKE_ID + 100 + i
                    vps[id] = db.vendorPrices[id]
                    db.vendorPrices[id] = 1000
                    table.insert(Bu.results, { itemID = id, price = 1000 - i * 50, qty = 1 })
                end
                return A:VendorFlipOffers(0, 10)
            end) }
            db.marketData, Bu.results, Bu.resultsTime, Bu.detail = saved.md, saved.res, saved.rt, saved.det
            for id in pairs(vps) do db.vendorPrices[id] = vps[id] end
            if not res[1] then error(res[2], 0) end
            local list = res[2]
            local sorted = true
            for i = 2, #list do if list[i].profit > list[i - 1].profit then sorted = false end end
            return #list == 10 and sorted and list[1].profit == 700, string.format("%d Zeilen, bester %s, sortiert %s", #list,
                tostring(list[1] and list[1].profit), tostring(sorted)), "10 Zeilen, bester 700"
        end)
        end)
        -- 0.65.18: Befunde der Prüfung 9. Nov. (offen-ahsentinel.txt Punkte 1-5, 9)
        B(function()
        Chk("T198", "J", "Sniper: Forever reserviert nie ohne Tastendruck, Blockade bleibt gespeichert", function()
            local Sn, g2 = A.Sniper, G()
            local db = A.db.sniper
            local saved = { inst = Sn.instantFailed, pend = Sn.pending, blocked = db.instantBlocked, setting = db.instantBuy }
            local res = { pcall(function()
                db.instantBuy, db.instantBlocked, Sn.instantFailed = true, nil, nil
                local fv, other
                if g2 and g2.SetTestFlavor then
                    g2.SetTestFlavor("forever"); fv = Sn:InstantEnabled()
                    g2.SetTestFlavor("era"); other = Sn:InstantEnabled()
                    g2.SetTestFlavor(nil)
                end
                -- WoW blockt den Aufruf: danach auch nach "/reload" (instantFailed weg) kein Sofortkauf
                Capture(function() Sn:OnEvent("ADDON_ACTION_BLOCKED", "AHSentinel", "C_AuctionHouse.StartCommoditiesPurchase()") end)
                Sn.instantFailed = nil
                local afterReload = Sn:InstantEnabled()
                return fv == false and other == true and afterReload == false and db.instantBlocked ~= nil,
                    string.format("Forever %s, Era %s, nach Blockade und Neuladen %s, gespeichert %s", tostring(fv), tostring(other),
                        tostring(afterReload), tostring(db.instantBlocked))
            end) }
            if g2 and g2.SetTestFlavor then g2.SetTestFlavor(nil) end
            Sn.instantFailed, Sn.pending, db.instantBlocked, db.instantBuy = saved.inst, saved.pend, saved.blocked, saved.setting
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], "Forever false, Era true, danach false, Interface gespeichert"
        end)
        end)
        B(function()
        Chk("T199", "J", "Verkaufs-Meldung: Muster auch mit %1$s", function()
            local Se = A.Seller
            if not Se.SoldPattern then return false, "Se.SoldPattern fehlt" end
            local p1 = Se.SoldPattern("Eure Auktion von %1$s wurde verkauft.")
            local p2 = Se.SoldPattern("A buyer has been found for your auction of %s.")
            local n1 = p1 and ("Eure Auktion von Leinenstoff wurde verkauft."):match(p1)
            local n2 = p2 and ("A buyer has been found for your auction of Linen Cloth."):match(p2)
            return n1 == "Leinenstoff" and n2 == "Linen Cloth", string.format("%s / %s", tostring(n1), tostring(n2)), "Leinenstoff / Linen Cloth"
        end)
        end)
        B(function()
        Chk("T200", "J", "Kategorie-Schlüssel gleich in beiden Quellen, alte Schlüssel gefunden", function()
            local Bu, X = A.Buy, A.Extras
            if not (Bu.GroupKey and Bu.MainKey and Bu.CatKey) then return false, "GroupKey/MainKey fehlen" end
            local bad = {}
            -- AuctionCategories: Rüstung -> Stoff mit mehreren Plätzen (inventoryType) = Rückfall Klasse 4 / Unterklasse 1
            local a = Bu.GroupKey({ { 4, 1, 5 }, { 4, 1, 7 }, { 4, 1, 20 } })
            if a ~= Bu.CatKey({ 4, 1 }) then bad[#bad + 1] = "Stoff " .. tostring(a) end
            local w = Bu.MainKey({ { 2, 0 }, { 2, 1 }, { 2, 7 } })
            if w ~= Bu.CatKey({ 2 }) then bad[#bad + 1] = "Waffen " .. tostring(w) end
            local multi = Bu.GroupKey({ { 2, 7 }, { 2, 0 }, { 2, 4 } })
            if multi ~= "c2_0-4-7" then bad[#bad + 1] = "mehrere " .. tostring(multi) end
            -- alter Schlüssel bis 0.65.17 ("…_<Platz>_<Anzahl>") findet die Kategorie über X:CatByKey
            local saved = Bu.CATS
            Bu.CATS = { { key = "all" }, { key = "c4_1", label = "AHS-Test", filters = { { 4, 1 } } } }
            local c = X:CatByKey("c4_1_5_3")
            Bu.CATS = saved
            if not c then bad[#bad + 1] = "alter Schlüssel nicht gefunden" end
            return #bad == 0, #bad == 0 and "gleich" or table.concat(bad, "; "), "Stoff = c4_1, Waffen = Klasse, alt gefunden"
        end)
        end)
        B(function()
        Chk("T201", "J", "Heute tun: gemerkte Rezepte bleiben unverändert (Sandbox recipes…prof)", function()
            local Cr = A.Crafting
            local list = Cr:KnownRecipes()
            local touched = 0
            for _, e in pairs((A.db.recipes or {})[A.Chars and A.Chars:Key() or ""] or {}) do
                for _, r in ipairs(type(e) == "table" and e.list or {}) do if r.prof ~= nil then touched = touched + 1 end end
            end
            if #list == 0 then return "SKIP", "keine gemerkten Rezepte (erst ein Berufsfenster öffnen)" end
            return touched == 0 and list[1].prof ~= nil, string.format("%d Rezepte, gespeichert mit prof: %d", #list, touched), "0"
        end)
        end)
        B(function()
        local tab = A.UI and A.UI.GetTab and A.UI:GetTab("buy")
        local p = tab and tab.panel
        if not (p and p.cats and p.Refresh) then return Skp("T202", "J", "Kategorie-Liste behält die Scroll-Position", "HALB: Reiter Einkauf einmal öffnen") end
        Chk("T202", "J", "Kategorie-Liste behält die Scroll-Position", function()
            local cat, off = p.cat, p.cats.offset
            local res = { pcall(function()
                p.cat = "all"
                p:Refresh()
                local maxOff = math.max(0, #(p.cats.items or {}) - (p.cats.numRows or 1))
                if maxOff == 0 then return "SKIP", "Liste passt ganz in die Spalte" end
                p.cats.offset = maxOff
                p:Refresh(); p:Refresh()
                return p.cats.offset == maxOff, string.format("offset %d nach 2x Refresh (soll %d)", p.cats.offset, maxOff), "gleich"
            end) }
            p.cat, p.cats.offset = cat, off
            p.catsSig = nil
            pcall(p.Refresh, p)
            if not res[1] then error(res[2], 0) end
            return res[2], res[3], res[4]
        end)
        end)
        B(function()
        Chk("T187", "J", "Händler-Knopf: ab Werk aus, wenn LevelPilot graue Items verkauft; eigene Einstellung gewinnt", function()
            local UI, s = A.UI, A.db.settings
            local savedOv, savedSet = A.apiOverride, s.vendorButton
            local res = { pcall(function()
                local lp = { IsAddOnLoaded = function(n) return n == "LevelPilot" end }
                local none = { IsAddOnLoaded = function() return false end }
                s.vendorButton = nil
                A.apiOverride = { C_AddOns = lp, LevelPilotDB = { settings = { autoSellGrey = true } } }
                local a = UI:VendorButtonEnabled()                 -- LevelPilot verkauft -> aus
                A.apiOverride = { C_AddOns = lp, LevelPilotDB = { settings = { autoSellGrey = false } } }
                local b = UI:VendorButtonEnabled()                 -- LevelPilot verkauft nicht -> an
                A.apiOverride = { C_AddOns = none, LevelPilotDB = false }
                local c = UI:VendorButtonEnabled()                 -- ohne LevelPilot -> an
                A.apiOverride = { C_AddOns = lp, LevelPilotDB = { settings = { autoSellGrey = true } } }
                s.vendorButton = true
                local d = UI:VendorButtonEnabled()                 -- selbst eingeschaltet -> an
                return a, b, c, d
            end) }
            A.apiOverride, s.vendorButton = savedOv, savedSet
            if not res[1] then error(res[2], 0) end
            local a, b, c, d = res[2], res[3], res[4], res[5]
            return (not a) and b and c and d, string.format("LevelPilot an %s, LevelPilot aus %s, ohne %s, selbst an %s",
                tostring(a), tostring(b), tostring(c), tostring(d)), "false, true, true, true"
        end)
        end)
        -- 0.65.22: Entzaubern im Tooltip - tatsächlicher Ø und Aufschlüsselung je Material
        B(function()
        Chk("T203", "J", "Entzaubern tatsächlich: 4 bekannte Entzauberungen -> Ø genau, Aufschlüsselung = geschätzter Wert", function()
            local D, TT = A.Disenchant, A.Tooltip
            local KEY, DUST, ESS, SHARD = "2:1:a", 10940, 10938, 10978
            local saved = { st = A.db.deStats, sh = A.db.deShared, prior = D.Prior, cur = A.GetCurrent, mv = A.GetMarketValue }
            local res = { pcall(function()
                -- 4 Entzauberungen: 2+2+1+2 Staub (4x), 1 Essenz (1x) -> Staub 7, Essenz 1
                A.db.deStats = { [KEY] = { n = 4, mats = { [DUST] = { times = 4, total = 7 }, [ESS] = { times = 1, total = 1 } } } }
                A.db.deShared = {}
                D.Prior = function(self, id) if id == FAKE_ID then return D:PriorForKey(KEY), KEY end return saved.prior(self, id) end
                local prices = { [DUST] = 100, [ESS] = 300 }
                A.GetCurrent = function(self, id) if prices[id] then return prices[id], 1, time() - 120 end return saved.cur(self, id) end
                A.GetMarketValue = function(self, id) if prices[id] then return prices[id] end if id == SHARD then return nil end return saved.mv(self, id) end
                local av, complete, n = D:ActualValue(FAKE_ID)
                local v = D:GetValue(FAKE_ID)
                local sum = 0
                for _, r in ipairs(D:EstimateRows(FAKE_ID)) do sum = sum + (r.share or 0) end
                local lines = TT and TT.DisenchantLines and TT:DisenchantLines(FAKE_ID, true) or {}
                local text = {}
                for _, l in ipairs(lines) do text[#text + 1] = l[1] .. " " .. l[2] end
                text = table.concat(text, " | ")
                -- ohne Daten: keine Zeile "tatsächlich"
                A.db.deStats = {}
                local none = D:ActualValue(FAKE_ID)
                return av, complete, n, v, sum, text, none
            end) }
            A.db.deStats, A.db.deShared, D.Prior, A.GetCurrent, A.GetMarketValue = saved.st, saved.sh, saved.prior, saved.cur, saved.mv
            if not res[1] then error(res[2], 0) end
            local av, complete, n, v, sum, text, none = res[2], res[3], res[4], res[5], res[6], res[7], res[8]
            -- (7 x Preis Staub + 1 x Preis Essenz) / 4 - Preis = realer Wert (A:PriceInfo, Sofortpreis knapp unter dem Angebot)
            local want = math.floor((7 * 99 + 1 * 299) / 4 + 0.5)
            local ok = av == want and complete and n == 4 and v and math.abs(sum - v) <= 1 and none == nil
                and text:find(string.format(L["Entzaubern tatsächlich (Ø aus %d)"], 4), 1, true) ~= nil
            return ok, string.format("tatsächlich %s aus %s, geschätzt %s = Summe %.0f, ohne Daten %s · %s", tostring(av), tostring(n),
                tostring(v), sum, tostring(none), text), "248 aus 4 ((7×99 + 1×299) / 4), Summe der Anteile = geschätzter Wert, ohne Daten keine Zeile"
        end)
        end)
        -- 0.65.23: Spieltest (Bereich S) - je Prüfung ein OK- und ein FEHLER-Fall mit nachgestellter Lage
        local function Both(id, name, okData, badData)
            B(function()
            Chk(id, "S", name, function()
                local E = A.Spieltest and A.Spieltest.Eval
                if not E then return false, "Spieltest fehlt", "A.Spieltest.Eval" end
                local key = name:match("^(S%d)")
                local okA, istA = E[key](okData)
                local okB, istB = E[key](badData)
                return okA == true and okB == false, string.format("OK-Fall: %s (%s) · FEHLER-Fall: %s (%s)", tostring(okA), tostring(istA),
                    tostring(okB), tostring(istB)), "OK-Fall OK, FEHLER-Fall FEHLER"
            end)
            end)
        end
        Both("T204", "S1 Gebühr im Verkaufen-Reiter",
            { forever = true, unit = 78, qty = 5, auctions = 1, cut = 100, depositShown = false },
            { forever = true, unit = 78, qty = 5, auctions = 1, cut = 20, depositShown = true })
        Both("T205", "S2 Gebühr echt",
            { measured = 500, shown = 500 }, { measured = 600, shown = 500 })
        Both("T206", "S3 Gewinn-Fenster",
            { forever = true, value = 2000, made = 1, stack = 1, net = 1900, cost = 1000, profit = 900, depositShown = false },
            { forever = true, value = 2000, made = 1, stack = 1, net = 1800, cost = 1000, profit = 800, depositShown = true })
        Both("T207", "S4 Entzaubern im Tooltip",
            { estSum = 216.4, estValue = 216, actualShown = true, n = 4, nCombined = 4 },
            { estSum = 180, estValue = 216, actualShown = true, n = 0, nCombined = 0 })
        Both("T208", "S5 Gewinn-Fenster überdeckt nichts",
            { problems = {}, tested = 2 }, { problems = { "Gewinn-Fenster überdeckt ProfessionsFrame" }, tested = 2 })
        Both("T209", "S6 Händler-Knopf",
            { shown = true, candidates = 3, enabled = true, lpSells = false, ownSetting = nil },
            { shown = true, candidates = 0, enabled = true, lpSells = true, ownSetting = nil, overlapTab = "MerchantFrameTab2" })
        Both("T210", "S7 Neuaufbau beim Herstellen",
            { builds = { 1, 3.5, 6 }, slow = {}, crafts = 5 }, { builds = { 1, 1.4, 1.8 }, slow = { 24 }, crafts = 5 })
        Both("T211", "S8 kein ADDON_ACTION_BLOCKED",
            { blocked = {} }, { blocked = { "BLOCKED PlaceAuctionBid()" } })
        B(function()
        Chk("T212", "S", "Spieltest-Ablauf: einmal je Lage, FEHLER bleibt, eine Chat-Zeile je Prüfung, Bericht offen/OK/FEHLER", function()
            local P = A.Spieltest
            local saved = { until_ = P.activeUntil, res = P.results, warned = P.warned, started = P.started, saved = P.saved, print = A.Print,
                blocked = P.blocked }
            local printed = 0
            local res = { pcall(function()
                A.Print = function() printed = printed + 1 end
                P.activeUntil, P.started, P.results, P.warned, P.saved, P.blocked = (GetTime and GetTime() or 0) + 60, time(), {}, {}, true, {}
                P:Result("S1", true, "100", "100")
                P:Result("S1", true, "200", "200")      -- schon OK: einmal je Lage (erster Wert bleibt)
                P:Result("S2", false, "600", "500")
                P:Result("S2", false, "700", "500")     -- zweiter FEHLER: keine weitere Chat-Zeile
                P:Result("S2", true, "500", "500")      -- FEHLER bleibt stehen
                P:Result("S3", nil)                      -- Lage nicht verwertbar: bleibt offen
                local lines, c = P:Lines()
                return c, P.results.S1.status .. "/" .. P.results.S1.ist, P.results.S2.status, P.results.S2.ist, lines
            end) }
            A.Print = saved.print
            P.activeUntil, P.results, P.warned, P.started, P.saved, P.blocked = saved.until_, saved.res, saved.warned, saved.started, saved.saved, saved.blocked
            if not res[1] then error(res[2], 0) end
            local c, s1, s2, ist2, lines = res[2], res[3], res[4], res[5], res[6]
            local needOK = lines[3] and lines[3].status == "offen" and lines[3].need ~= nil
            return c.ok == 1 and c.fehler == 1 and c.offen == #P.CHECKS - 2 and s1 == "OK/100" and s2 == "FEHLER" and ist2 == "600" and printed == 1 and needOK,
                string.format("OK %d, FEHLER %d, offen %d, S1 %s, S2 %s (%s), Chat-Zeilen %d", c.ok, c.fehler, c.offen, s1, s2, ist2, printed),
                "OK 1, FEHLER 1, Rest offen, S2 bleibt FEHLER mit erstem Wert, 1 Chat-Zeile, offen mit Lage"
        end)
        end)
        B(function()
        Chk("T213", "S", "S5 prüft nur Gewinn-Fenster gegen Berufsfenster und ProfessionSentinel (Befund 9. Nov. 08:12)", function()
            local P = A.Spieltest
            local function F(l, b, w, h, vis) return { GetRect = function() return l, b, w, h end, IsVisible = function() return vis ~= false end,
                GetHitRectInsets = function() return 0, 0, 0, 0 end } end
            local saved = { pf = _G.ProfessionsFrame, gs = _G.GoldSentinelUIFrames }
            local res = { pcall(function()
                local panel = F(500, 300, 300, 400)
                _G.ProfessionsFrame = F(100, 300, 390, 400)               -- links daneben
                _G.GoldSentinelUIFrames = {
                    { frame = F(810, 300, 300, 400), name = "Panel", addon = "ProfessionSentinel" },   -- rechts daneben
                    { frame = F(600, 400, 50, 50), name = "BuffSentinelAnchor_cd", addon = "BuffSentinel" },  -- anderes Addon: zählt nicht
                }
                local okD = P:S5Data(panel)
                _G.GoldSentinelUIFrames[1].frame = F(700, 300, 300, 400)   -- ProfessionSentinel darüber
                local badD = P:S5Data(panel)
                return okD, badD
            end) }
            _G.ProfessionsFrame, _G.GoldSentinelUIFrames = saved.pf, saved.gs
            if not res[1] then error(res[2], 0) end
            local okD, badD = res[2], res[3]
            if not (okD and badD) then return "SKIP", "UICheck nicht geladen" end
            local okA = P.Eval.S5(okD)
            local okB, istB = P.Eval.S5(badD)
            return okA == true and okB == false and okD.tested == 2, string.format("daneben: %s (%d geprüft), darüber: %s (%s)",
                tostring(okA), okD.tested, tostring(okB), tostring(istB)), "daneben OK (BuffSentinel ignoriert), ProfessionSentinel darüber FEHLER"
        end)
        end)
        B(function()
        Chk("T214", "J", "Post abholen: Gold gemeldet, auch wenn die Gutschrift erst nach MAIL_INBOX_UPDATE kommt (Befund 9. Nov. 08:19)", function()
            local M = A.Mailer
            local saved = { running = M.running, money = M.money, items = M.items, start = M.startMoney, waiting = M.waiting, last = M.lastAction,
                next = M.NextMail, take = _G.TakeInboxMoney, mf = _G.MailFrame, print = A.Print, screen = A.ScreenMessage, fire = A.Fire }
            local msgs = {}
            local res = { pcall(function()
                local mail = 15626                                         -- 1g 56s 26c
                _G.MailFrame = { IsShown = function() return true end }
                _G.TakeInboxMoney = function() end                         -- Gold kommt (noch) nicht an
                A.Print = function(_, m) msgs[#msgs + 1] = m end
                A.ScreenMessage, A.Fire = function() end, function() end
                M.running, M.money, M.items, M.waiting, M.lastAction = true, 0, 0, nil, 0
                M.startMoney = GetMoney and GetMoney() or 0
                local n = 0
                M.NextMail = function() n = n + 1; if n == 1 then return 1, mail, 0 end return nil end
                M:Step()                           -- holt das Gold
                M.waiting, M.lastAction = nil, 0   -- MAIL_INBOX_UPDATE vor PLAYER_MONEY
                M:Step()                           -- keine Post mehr -> Stop
                return M.running
            end) }
            M.running, M.money, M.items, M.startMoney, M.waiting, M.lastAction = saved.running, saved.money, saved.items, saved.start, saved.waiting, saved.last
            M.NextMail, _G.TakeInboxMoney, _G.MailFrame, A.Print, A.ScreenMessage, A.Fire = saved.next, saved.take, saved.mf, saved.print, saved.screen, saved.fire
            if not res[1] then error(res[2], 0) end
            local text = table.concat(msgs, " | ")
            local want = A:FormatMoney(15626)
            return res[2] == false and text:find(want, 1, true) ~= nil, text, "Meldung mit " .. want
        end)
        end)
        -- 0.65.26: Entzaubern im Tooltip kurz + Materialblock, Teilen mit allen (Schutz vor Unsinn)
        local function WithDE(nOwn, fn)
            local D = A.Disenchant
            local KEY, DUST, ESS = "2:1:a", 10940, 10938
            local saved = { st = A.db.deStats, sh = A.db.deShared, prior = D.Prior, cur = A.GetCurrent, mv = A.GetMarketValue,
                ov = A.apiOverride, mode = A.db.settings.tooltipDEMode, chars = A.db.chars, rate = D.rate }
            local res = { pcall(function()
                local dust = math.floor(nOwn * 1.75 + 0.5)
                A.db.deStats = nOwn > 0 and { [KEY] = { n = nOwn, mats = { [DUST] = { times = nOwn, total = dust }, [ESS] = { times = 1, total = 1 } } } } or {}
                A.db.deShared, D.rate = {}, {}
                D.Prior = function(self, id) if id == FAKE_ID then return D:PriorForKey(KEY), KEY end return saved.prior(self, id) end
                local prices = { [DUST] = 100, [ESS] = 300, [FAKE_ID] = 50 }
                A.GetCurrent = function(self, id) if prices[id] then return prices[id], 1, time() - 60 end return saved.cur(self, id) end
                A.GetMarketValue = function(self, id) if prices[id] then return prices[id] end return saved.mv(self, id) end
                return fn(D, KEY, DUST, ESS)
            end) }
            A.db.deStats, A.db.deShared, D.Prior, A.GetCurrent, A.GetMarketValue = saved.st, saved.sh, saved.prior, saved.cur, saved.mv
            A.apiOverride, A.db.settings.tooltipDEMode, A.db.chars, D.rate = saved.ov, saved.mode, saved.chars, saved.rate
            if not res[1] then error(res[2], 0) end
            return select(2, unpack(res))
        end
        -- Shift über die Naht A:API (nie die Blizzard-Funktion ersetzen), übrige Ersatzwerte der Sandbox behalten
        local function SetShift(on)
            local o = {}
            for k, v in pairs(A.apiOverride or {}) do o[k] = v end
            o.IsShiftKeyDown = function() return on end
            A.apiOverride = o
        end
        local function FakeTT()
            local t = { lines = {} }
            function t:AddDoubleLine(l, r) self.lines[#self.lines + 1] = tostring(l) .. " || " .. tostring(r) end
            function t:AddLine(l) self.lines[#self.lines + 1] = tostring(l) end
            return t
        end
        B(function()
        Chk("T215", "J", "Entzaubern-Tooltip kurz: eine Zeile = Wert nach Gebühren, Quelle wechselt bei 10, Materialblock, Shift = ganze Rechnung", function()
            local TT = A.Tooltip
            return WithDE(4, function(D)
                -- 4 Entzauberungen: Tabelle (T)
                local s4 = TT:DisenchantShort(FAKE_ID)
                local v4, _, yield = D:GetValue(FAKE_ID)
                local want4 = D:NetValue(v4, yield)
                A.db.settings.tooltipDEMode = "short"
                SetShift(false)
                local tShort = FakeTT(); TT:AddDisenchantLines(tShort, FAKE_ID)
                A.db.settings.tooltipDEMode = "mats"
                local tMats = FakeTT(); TT:AddDisenchantLines(tMats, FAKE_ID)
                local mats = TT:DisenchantMats(FAKE_ID)
                local matsOK = #mats >= 2
                for _, m in ipairs(mats) do if not (m.chance and m.chance > 0 and m.price and m.icon ~= nil) then matsOK = false end end
                SetShift(true)
                local tShift = FakeTT(); TT:AddDisenchantLines(tShift, FAKE_ID)
                local shiftText = table.concat(tShift.lines, " | ")
                -- 10 Entzauberungen: tatsächlich (Ø 10)
                A.db.deStats["2:1:a"] = { n = 10, mats = { [10940] = { times = 10, total = 18 }, [10938] = { times = 2, total = 2 } } }
                local s10 = TT:DisenchantShort(FAKE_ID)
                local av, _, n, rows = D:ActualValue(FAKE_ID)
                local want10 = D:ActualNet(av, rows, n)
                local ok = s4 and s4.net == want4 and s4.basis == "estimate" and s4.right:find("(T)", 1, true)
                    and (#tShort.lines == 1 or #tShort.lines == 2) and tShort.lines[1]:find(L["Entzauberungswert"], 1, true) and #tMats.lines >= 3 and matsOK
                    and shiftText:find(L["Entzaubern geschätzt (Tabelle)"], 1, true)
                    and s10 and s10.basis == "actual" and s10.net == want10 and s10.right:find("(Ø 10)", 1, true)
                return ok and true or false, string.format("4: %s %s · kurz %d Zeile(n), mit Materialien %d, Materialien ok %s · Shift %s · 10: %s %s",
                    tostring(s4 and s4.net), tostring(s4 and s4.right), #tShort.lines, #tMats.lines, tostring(matsOK),
                    shiftText:find(L["Entzaubern geschätzt (Tabelle)"], 1, true) and "ganze Rechnung" or "fehlt", tostring(s10 and s10.net),
                    tostring(s10 and s10.right)), "Tabelle bei 4 = NetValue, 1 Zeile kurz, Block mit Icon/Chance/Preis, Shift ganze Rechnung, tatsächlich ab 10"
            end)
        end)
        end)
        B(function()
        Chk("T216", "J", "Entzaubern teilen: Twink eigen, anderer Spieler geteilt (ohne Namen), Unsinn/Doppeltes/zu viel verworfen, nur Gilde nie Kanal", function()
            local S = A.Sync
            local Enc = S.Enc
            return WithDE(0, function(D, KEY, DUST, ESS)
                local function part(n, list)
                    local m = {}
                    for _, x in ipairs(list) do m[#m + 1] = Enc(x[1]) .. "," .. Enc(x[2]) .. "," .. Enc(x[3]) end
                    return KEY:gsub(":", ".") .. "~" .. Enc(n) .. "~" .. table.concat(m, ",")
                end
                local now = time()
                A.db.chars = { ["AHSTwink-AHSRealm"] = { name = "AHSTwink", realm = "AHSRealm" } }
                local twink = D:HandleShared("AHSTwink-AHSRealm", now, part(3, { { DUST, 3, 5 } }))
                local good = part(4, { { DUST, 4, 7 }, { ESS, 1, 1 } })
                local other = D:HandleShared("AHSFremder-AHSRealm", now, good)
                local dup = D:HandleShared("AHSFremder-AHSRealm", now, good)
                local wrongMat = D:HandleShared("AHSDritter-AHSRealm", now, part(2, { { 20725, 1, 1 } }))      -- Nexus passt nicht zu grün
                local tooMany = D:HandleShared("AHSVierter-AHSRealm", now, part(2, { { DUST, 2, 30 } }))       -- 15 je Entzauberung
                local spam = 0
                for i = 1, 8 do spam = spam + D:HandleShared("AHSSpammer-AHSRealm", now, part(i, { { DUST, i, i } })) end
                local names = false
                for k in pairs(A.db.deShared) do if not tostring(k):find("^#") or tostring(k):find("AHS", 1, true) then names = true end end
                local nOwn, nShared = D:Combined(KEY)
                -- nur Gilde: nie in den öffentlichen Kanal
                local savedG, savedCh, savedIn = A.db.sync.guildOnly, S.channelId, _G.IsInGuild
                A.db.sync.guildOnly, S.channelId, _G.IsInGuild = true, 5, function() return false end
                local d1 = S:Target()
                A.db.sync.guildOnly = nil
                local d2 = S:Target()
                A.db.sync.guildOnly, S.channelId, _G.IsInGuild = savedG, savedCh, savedIn
                local ok = twink == 0 and other == 1 and dup == 0 and wrongMat == 0 and tooMany == 0 and spam == 6 and not names
                    and nOwn == 0 and d1 == nil and d2 == "CHANNEL"
                return ok, string.format("Twink %d, anderer %d, doppelt %d, falsches Material %d, zu viel %d, Spam angenommen %d von 8, Namen gespeichert %s, nur Gilde %s, alle %s",
                    twink, other, dup, wrongMat, tooMany, spam, tostring(names), tostring(d1), tostring(d2)),
                    "0, 1, 0, 0, 0, 6, nein, nil, CHANNEL"
            end)
        end)
        end)
        B(function()
        Chk("T217", "J", "Entzaubern grün bis Itemstufe 15 ohne Splitter (80/20), ab 16 mit Splitter (Befund 9. Nov. 09:04)", function()
            local D = A.Disenchant
            local function fmt(p)
                local t = {}
                for _, e in ipairs(p or {}) do t[#t + 1] = e[1] .. "=" .. math.floor(e[2] * 100 + 0.5) .. "%" end
                return table.concat(t, " ")
            end
            local a1, w1, a2, a3 = D:PriorForKey("2:1:a"), D:PriorForKey("2:1:w"), D:PriorForKey("2:2:a"), D:PriorForKey("2:3:a")
            -- Braune Leinenhose (Rüstung bis 15): Staub 80, Essenz 20, kein Splitter; Wollcape (16-20): 75/20/5 mit Splitter
            local ok1 = #a1 == 2 and a1[1][1] == 10940 and a1[1][2] == 0.80 and a1[2][1] == 10938 and a1[2][2] == 0.20
            local okW = #w1 == 2 and w1[1][2] == 0.20 and w1[2][2] == 0.80
            local ok2 = #a2 == 3 and a2[3][1] == 10978 and a2[3][2] == 0.05
            local ok3 = #a3 == 3 and a3[3][2] == 0.10
            -- unplausible Splitter-Meldung für Stufe bis 15: geteilt verworfen, eigene nicht mitgezählt
            local saved = { st = A.db.deStats, sh = A.db.deShared, rate = D.rate }
            local res = { pcall(function()
                A.db.deStats = { ["2:1:a"] = { n = 3, mats = { [10940] = { times = 3, total = 5 }, [10978] = { times = 1, total = 1 } } } }
                A.db.deShared, D.rate = {}, {}
                local Enc = A.Sync.Enc
                local taken = D:HandleShared("AHSFremder-AHSRealm", time(), "2.1.a~" .. Enc(2) .. "~" .. Enc(10978) .. "," .. Enc(1) .. "," .. Enc(1))
                local _, _, mats = D:Combined("2:1:a")
                return taken, mats[10978] ~= nil
            end) }
            A.db.deStats, A.db.deShared, D.rate = saved.st, saved.sh, saved.rate
            if not res[1] then error(res[2], 0) end
            local taken, shardCounted = res[2], res[3]
            return ok1 and okW and ok2 and ok3 and taken == 0 and not shardCounted,
                string.format("bis 15 Rüstung: %s · Waffe: %s · 16-20: %s · 21-25: %s · Splitter geteilt %d, eigener gezählt %s",
                    fmt(a1), fmt(w1), fmt(a2), fmt(a3), taken, tostring(shardCounted)),
                "80/20 ohne Splitter, Waffe 20/80, 75/20/5, 75/15/10, Splitter verworfen"
        end)
        end)
        -- 0.65.28: Entscheide der Prüf-Sitzung 9. Nov. 09:35
        Both("T221", "S9 Hauptfenster mit dem Auktionshaus",
            { open = true, option = true, before = false, visible = true },
            { open = false, option = true, before = false, visible = true })
        B(function()
        Chk("T218", "J", "Forever: keine Reservierung ohne Tastendruck, Status 'nochmal drehen' mit Zeit, Reservierung läuft ab", function()
            local Sn = A.Sniper
            local g2 = _G.GoldSentinelGame
            if not (g2 and g2.SetTestFlavor) then return "SKIP", "SetTestFlavor fehlt" end
            local db = A.db.sniper
            local saved = { pending = Sn.pending, armed = db and db.armed, open = A.ahOpen, force = A.forceForever, print = A.Print }
            local res = { pcall(function()
                A.forceForever = nil
                g2.SetTestFlavor("forever")
                local instant = Sn:InstantEnabled()
                A.Print = function() end
                if db then db.armed = false end
                A.ahOpen = true
                local now = GetTime()
                Sn.pending = { state = "ready", started = now, auto = false, plan = { itemID = 2589, qty = 1, kind = "commodity" } }
                local status = Sn:GetStatusText() or ""
                Sn.pending.started = now - 11            -- Zeitlimit (10 s) vorbei
                Sn:Tick()
                local expired = Sn.pending == nil
                g2.SetTestFlavor(nil)
                return instant, status, expired
            end) }
            if g2.SetTestFlavor then g2.SetTestFlavor(nil) end
            Sn.pending, A.ahOpen, A.forceForever, A.Print = saved.pending, saved.open, saved.force, saved.print
            if db then db.armed = saved.armed end
            if not res[1] then error(res[2], 0) end
            local instant, status, expired = res[2], res[3], res[4]
            local plain = status:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
            local want = L["|cff33dd55Reserviert - nochmal %s zum Kaufen (%d s)|r"]:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):match("^([^%%]+)")
            return instant == false and plain:find(want, 1, true) ~= nil and plain:find("10 s", 1, true) ~= nil and expired,
                string.format("Sofortkauf %s, Status \"%s\", abgelaufen %s", tostring(instant), plain, tostring(expired)),
                "kein Sofortkauf, \"Reserviert - nochmal ... (10 s)\", nach 10 s verfallen"
        end)
        end)
        B(function()
        Chk("T219", "J", "Hauptfenster mit dem Auktionshaus: auf -> auf, zu -> zu, vorher offen bleibt offen, Option aus -> nichts", function()
            local UI = A.UI
            local st = A.db.settings
            local saved = { opt = st.openWithAH, show = UI.Show, hide = UI.Hide, vis = UI.IsVisible, auto = UI.autoOpened, was = UI.wasOpenBeforeAH }
            local visible = false
            local res = { pcall(function()
                UI.Show = function() visible = true end
                UI.Hide = function() visible = false end
                UI.IsVisible = function() return visible end
                local out = {}
                -- 1. AH auf -> auf, AH zu -> zu
                st.openWithAH = nil; visible = false
                UI:OnAHStateAuto(true, false); out[1] = visible
                UI:OnAHStateAuto(false, visible); out[2] = visible
                -- 2. vorher offen -> bleibt offen
                visible = true
                UI:OnAHStateAuto(true, true); UI:OnAHStateAuto(false, true); out[3] = visible
                -- 3. Option aus -> nichts
                st.openWithAH = false; visible = false
                UI:OnAHStateAuto(true, false); out[4] = visible
                UI:OnAHStateAuto(false, false); out[5] = visible
                return out
            end) }
            st.openWithAH = saved.opt
            UI.Show, UI.Hide, UI.IsVisible, UI.autoOpened, UI.wasOpenBeforeAH = saved.show, saved.hide, saved.vis, saved.auto, saved.was
            if not res[1] then error(res[2], 0) end
            local o = res[2]
            return o[1] == true and o[2] == false and o[3] == true and o[4] == false and o[5] == false,
                string.format("auf %s, zu %s, vorher offen %s, Option aus: %s/%s", tostring(o[1]), tostring(o[2]), tostring(o[3]),
                    tostring(o[4]), tostring(o[5])), "auf true, zu false, vorher offen true, Option aus false/false"
        end)
        end)
        B(function()
        Chk("T220", "J", "Hauptfenster bleibt im Bildschirm: höchstens 90 %, Position geklemmt", function()
            local UI = A.UI
            if not (UIParent and UIParent.GetWidth and CreateFrame) then return "SKIP", "kein UIParent" end
            local U = A.UIC and A.UIC.UICheck
            if U and U.LayoutReal and not U.LayoutReal() then return "SKIP", "kein echtes Layout (GetRect wertet Anker nicht aus)" end
            local f = CreateFrame("Frame", nil, UIParent)
            local sw, sh = UIParent:GetWidth(), UIParent:GetHeight()
            f:SetSize(sw * 1.5, sh * 1.5)
            f:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", sw * 0.8, -sh * 0.5)
            local res = { pcall(UI.EnsureOnScreen, UI, f) }
            local l, b, w, h = f:GetRect()
            local sc, ps = f:GetEffectiveScale(), UIParent:GetEffectiveScale()
            f:Hide()
            if not res[1] then error(res[2], 0) end
            if not l then return "SKIP", "keine Rechtecke (Client ohne Layout)" end
            local inside = l * sc >= -1 and b * sc >= -1 and (l + w) * sc <= sw * ps + 1 and (b + h) * sc <= sh * ps + 1
            local share = (w * sc) / (sw * ps)
            return inside and share <= 0.91, string.format("im Bildschirm %s, Breite %.0f %% (l %.0f b %.0f w %.0f h %.0f, Massstab %.2f/%.2f, Bildschirm %.0f x %.0f)",
                tostring(inside), share * 100, l, b, w, h, sc, ps, sw, sh),
                "ganz im Bildschirm, höchstens 90 %"
        end)
        end)
        -- 0.65.29: Entzauberungswert statt "Gewinn", Gewinn beim Kauf, Block = Summe, Ausreisser; Teilen nach 10 / 2 Minuten
        B(function()
        Chk("T223", "J", "Entzauberungswert gleich je Gruppe, Gewinn beim Kauf je Kaufpreis, Block-Anteile = Wert, Ausreisser zählt nicht", function()
            local TT = A.Tooltip
            return WithDE(4, function(D, KEY, DUST, ESS)
                local savedCur = A.GetCurrent
                local cur = A.GetCurrent
                -- Ausreisser: Essenz aktuell 2c bei Median 300c -> zählt nicht (Markt), unsicher
                A.GetCurrent = function(self, id) if id == ESS then return 2, 5, time() - 60 end return cur(self, id) end
                TT.buyContext = { itemID = FAKE_ID, price = 100 }
                local a = TT:DisenchantShort(FAKE_ID)
                TT.buyContext = { itemID = FAKE_ID, price = 1000 }
                local b = TT:DisenchantShort(FAKE_ID)
                TT.buyContext = nil
                local v = D:GetValue(FAKE_ID)
                local sum, essRow = 0, nil
                for _, r in ipairs(D:EstimateRows(FAKE_ID)) do sum = sum + (r.share or 0); if r.id == ESS then essRow = r end end
                A.GetCurrent = savedCur
                local ok = a and b and a.net == b.net and a.gain == a.net - 100 and b.gain == b.net - 1000 and a.left:find(L["Entzauberungswert"], 1, true)
                    and math.abs(sum - v) <= 1 and essRow and essRow.price == 300 and essRow.unsure == true and essRow.source == "market"
                return ok and true or false, string.format("Wert %s/%s, Gewinn %s/%s, Summe %.0f = %s, Essenz %s (%s, unsicher %s)",
                    tostring(a and a.net), tostring(b and b.net), tostring(a and a.gain), tostring(b and b.gain), sum, tostring(v),
                    tostring(essRow and essRow.price), tostring(essRow and essRow.source), tostring(essRow and essRow.unsure)),
                    "gleicher Wert, Gewinn = Wert - Kaufpreis, Summe = Wert, 2c-Angebot ignoriert (Markt 300c)"
            end)
        end)
        end)
        B(function()
        Chk("T222", "J", "Entzauberungen teilen: nach 10 neuen oder 2 Minuten nach der letzten, nicht vorher", function()
            local D = A.Disenchant
            local saved = { bc = D.BroadcastStats, un = D.unshared, last = D.lastRecordAt, st = A.db.deStats, prior = D.Prior, after = D.SHARE_AFTER }
            local sent = 0
            local res = { pcall(function()
                D.BroadcastStats = function(self) sent = sent + 1; self.unshared = 0; return true end
                D.SHARE_AFTER = 99999            -- Zeitgeber im Test nicht abwarten, ShareIfQuiet direkt aufrufen
                D.Prior = function(self, id) if id == FAKE_ID then return D:PriorForKey("2:2:a"), "2:2:a" end return saved.prior(self, id) end
                A.db.deStats, D.unshared = {}, 0
                for _ = 1, 3 do D:Record(FAKE_ID, { { 10940, 2 } }) end
                local after3 = sent
                local early = D:ShareIfQuiet(-1)          -- inzwischen kam eine neue: nicht teilen
                local quiet = D:ShareIfQuiet(D.lastRecordAt)
                local after2min = sent
                for _ = 1, 10 do D:Record(FAKE_ID, { { 10940, 2 } }) end
                return after3, early, after2min, sent
            end) }
            D.BroadcastStats, D.unshared, D.lastRecordAt, A.db.deStats, D.Prior, D.SHARE_AFTER = saved.bc, saved.un, saved.last, saved.st, saved.prior, saved.after
            if not res[1] then error(res[2], 0) end
            local after3, early, after2min, total = res[2], res[3], res[4], res[5]
            return after3 == 0 and not early and after2min == 1 and total == 2, string.format("nach 3: %d, zu früh: %s, nach 2 Min.: %d, nach 10 weiteren: %d",
                after3, tostring(early), after2min, total), "0, false, 1, 2"
        end)
        end)
        B(function()
        Chk("T152", "J", "pcall um alle AH-Aufrufe", function()
            local realAH = A.AH
            local W = A.Watcher
            local wsaved = Copy(A.db.watcher)              -- ganzer Wächter-Speicher (Sandbox-Befund "watcher.…")
            local function Fail() error("AHS-Test T152", 0) end
            local proxy = setmetatable({ SendBrowseQuery = Fail, SendSearchQuery = Fail, GetBrowseResults = Fail,
                GetItemSearchResultInfo = Fail, SendSellSearchQuery = Fail, IsThrottledMessageSystemReady = function() return true end },
                { __index = realAH })
            local errs = {}
            local function try(name, f, ...)
                local ok, e = pcall(f, ...)
                if not ok then errs[#errs + 1] = name .. ": " .. tostring(e):sub(1, 60) end
            end
            A.AH = proxy
            local lines = Capture(function()
                try("Einkauf", A.Buy.Search, A.Buy, { searchString = "AHS-Test" }, true)
                try("Sniper", A.Sniper.Search, A.Sniper, "i:" .. LINEN)
                try("Preisprüfung", A.Seller.CheckPrice, A.Seller, LINEN, true)
                try("Wächter", W.StartRound, W)
            end)
            A.AH = realAH
            W.round = nil
            Replace(A.db.watcher, wsaved)
            if A.Seller.queue then for i = #A.Seller.queue, 1, -1 do if A.Seller.queue[i] == LINEN then table.remove(A.Seller.queue, i) end end end
            self:ClearTestErrors()
            return #errs == 0, #errs == 0 and (#lines .. " Meldungen, kein Lua-Fehler") or table.concat(errs, " | "), "kein Lua-Fehler"
        end)
        end)
    end

    -- ---------------- K. Oberfläche im echten Client (UICheck.lua, Vorlage T18–T23) ----------------
    -- ohne echten Client ehrlich übersprungen, nie als OK gezählt; nur lesen
    if want(part, "k") then B(function()
        local U = A.UIC and A.UIC.UICheck
        if not U then return Skp("T191", "K", "Oberfläche im Client", "UICheck.lua nicht geladen") end
        local UI = A.UI
        local wasShown = UI and UI.frame and UI.frame:IsShown()
        if UI and UI.frame and not wasShown then UI.frame:Show() end         -- eigenes Fenster zum Prüfen öffnen
        local function List(problems) return #problems == 0 and "keine" or table.concat(problems, "; ") end
        local ui = {
            { "T191", "Eigene Tooltips verdecken keine Knöpfe", U.TooltipsCoverNothing },
            { "T192", "Kein Überlappen mit Blizzard- oder GoldSentinel-Fenstern", U.WindowsOverlapNothing },
            { "T193", "Fenster ganz im Bildschirm", U.InsideScreen },
            { "T194", "Beschriftungen von Knöpfen nicht abgeschnitten", U.TextFits },
            { "T195", "Angezeigte Spielwerte plausibel", U.ValuesPlausible, true },
            { "T196", "Keine Fehlerschleife (gleiche Meldung > 10×)", U.NoErrorLoops, true },
        }
        for _, c in ipairs(ui) do
            if not c[4] and not U.Available() then
                Skp(c[1], "K", c[2], "nur im echten Client (Fenster, Rechtecke, Tooltip)")
            else
                Chk(c[1], "K", c[2], function()
                    local problems, tested, hints = c[3]()
                    local info = List(problems) .. " · geprüft " .. tostring(tested)
                        .. (hints and #hints > 0 and (" · Hinweise: " .. table.concat(hints, "; ")) or "")
                    return #problems == 0, info, "keine"
                end)
            end
        end
        if UI and UI.frame and not wasShown then UI.frame:Hide() end
        if not (A.Crafting and A.Crafting.panel and A.Crafting.panel:IsShown()) then
            Cli("T197", "K", "Gewinn-Fenster am Berufsfenster",
                "Berufsfenster öffnen (mit und ohne ProfessionSentinel), dann /ahs testroutine k: T192 ohne \"überdeckt\", T195 ohne Fehler")
        end
    end) end

    if part == "server" then
        if not A:IsAHOpen() then
            B(function() Skp("S00", "B", "Teil server", "Auktionshaus nicht offen - erst öffnen, dann /ahs testroutine server") end)
        else
            B(function() A.jobMeasure = { max = 0, frames = 0 } end)
            self:AddOldSteps(false)
            self:AddServerSteps()
        end
    elseif part == "haendler" then
        B(function()
            if not MerchantOpen() then return Skp("T59b", "B", "Händler-Verkauf simuliert", "Händlerfenster nicht offen") end
            Chk("T59b", "B", "Händler-Verkauf simuliert", function()
                local X = A.Extras
                local before = Real("UseContainerItem")
                local ok, msg = Capture(function() return X:SellToVendor() end)
                for _ = 1, 3 do Capture(function() X:SellStep() end) end
                X.selling = nil
                return Real("UseContainerItem") == before, "UseContainerItem " .. (Real("UseContainerItem") - before), "0"
            end)
            if A:API("GetMerchantItemInfo") and not A:API("C_MerchantFrame") then
                Chk("T100", "D", "Alter Händler-Weg", function()
                    local n = A:ScanMerchant()
                    return (n or 0) > 0, tostring(n), "> 0 über GetMerchantItemInfo"
                end)
            else
                Skp("T100", "D", "Alter Händler-Weg", "nur im alten Client (Classic Era, TBC)")
            end
        end)
        B(function()
            if not MerchantOpen() then return Skp("T19", "B", "Händler echt", "Händlerfenster nicht offen") end
            Chk("T19", "B", "Händler echt", function()
                local n = A:ScanMerchant()
                return n > 0, tostring(n), "> 0"
            end)
            Chk("T135", "J", "Händler-Einkaufspreise", function()
                return Count(A.db.vendorBuy) > 0, tostring(Count(A.db.vendorBuy)), "> 0"
            end)
        end)
    elseif part == "berufe" then
        B(function()
            local Cr = A.Crafting
            if not Cr.kind then return Skp("T64", "B", "Berufsfenster echt", "Berufsfenster nicht offen") end
            Chk("T64", "B", "Berufsfenster echt", function()
                local n = Cr:Remember(Cr.kind)
                return (n or 0) > 0, tostring(Cr.kind) .. ", " .. tostring(n) .. " Rezepte", "> 0"
            end)
            if modern then
                Chk("T134", "J", "Berufsfenster in Forever nicht leer", function()
                    return Cr:TradeKind() == "modern", Cr:TradeKind(), "modern"
                end)
            end
        end)
        B(function()
            local Cr = A.Crafting
            if not Cr.kind then return Skp("T124", "H", "Berufsliste (Zwischenspeicher)", "Berufsfenster nicht offen") end
            if Cr.kind == "trade" or Cr.kind == "craft" then
                Chk("T99", "D", "Alte Berufe-API", function()
                    local n = Cr:Remember(Cr.kind)
                    return (n or 0) > 0, Cr.kind .. ", " .. tostring(n), "trade/craft, > 0"
                end)
            else
                Skp("T99", "D", "Alte Berufe-API", "nur im alten Client (Classic Era, TBC)")
            end
            Chk("T124", "H", "Berufsliste (Zwischenspeicher)", function()
                local t0 = Ms(); Cr:ReadAll(Cr.kind); local a = Ms() - t0
                t0 = Ms(); Cr:ReadAll(Cr.kind); local b = Ms() - t0
                return Cr.kind ~= "modern" or b < 2, string.format("erstes Mal %.1f ms, zweites Mal %.1f ms", a, b),
                    Cr.kind == "modern" and "zweites Mal < 2 ms" or "nur Messwert"
            end)
            if Cr.kind == "modern" then
                Chk("T147", "J", "KO 5b: Zutaten-Knopf ohne SchematicForm", function()
                    return Cr.API.modern.selected() ~= nil, tostring(Cr.API.modern.selected()),
                        "Rezept im Blizzard-Fenster gewählt -> Index (vorher ein Rezept anklicken)"
                end)
                Chk("T148", "J", "KO 5c: Zwischenspeicher bleibt bei Listen-Ereignissen", function()
                    Cr:ReadAll("modern")
                    local n1 = Cr:SchematicCacheSize()
                    Cr.evt:GetScript("OnEvent")(Cr.evt, "TRADE_SKILL_LIST_UPDATE")
                    Cr.evt:GetScript("OnEvent")(Cr.evt, "TRADE_SKILL_LIST_UPDATE")
                    local n2 = Cr:SchematicCacheSize()
                    return n1 > 0 and n2 >= n1, string.format("%d -> %d Einträge", n1, n2), "nicht geleert"
                end)
            end
        end)
    elseif part == "post" then
        B(function()
            if not (MailFrame and MailFrame:IsShown()) then return Skp("T56", "B", "Post abholen", "Briefkasten nicht offen") end
            TM:SeedMail()
            Chk("T56", "B", "Post abholen (Test-Briefkasten)", function()
                return A.Mailer:HasAHMail() == true, nil, "Test-Post erkannt"
            end)
            Chk("T58", "B", "Post an Twinks simuliert", function()
                local ok = pcall(A.Extras.MailPlan, A.Extras)
                return ok and (self.real.SendMail or 0) == 0, nil, "Plan ohne Fehler, SendMail 0"
            end)
        end)
    elseif part == "gildenbank" then
        B(function()
            local K = A.Comfort
            if not (K.GuildBankSupported and K:GuildBankSupported()) then return Skp("T67", "B", "Gildenbank", "nicht unterstützt") end
            Chk("T67", "B", "Gildenbank", function()
                local ok = K:ScanGuildBank()
                return ok, nil, "gelesen"
            end)
        end)
    elseif part == "kampf" then
        B(function()
            local s = A.db.gsTest and A.db.gsTest.errors
            local n = 0
            for _ in pairs(s or {}) do n = n + 1 end
            Chk("T158", "C", "Fehler aus dem letzten Kampf", function()
                return n == 0, n .. " Fehlerarten seit dem letzten Bericht", "0"
            end)
        end)
    end
end
