-- BuffSentinel - Data/Hunter.lua  (Feldbeschreibung siehe Data/Warrior.lua)

local ADDON, BS = ...
local L = BS.L
BS.ClassData = BS.ClassData or {}

-- Kampf-Aspekte (Gepard/Rudel zählen bewusst nicht – die will man im Kampf nicht haben)
local COMBAT_ASPECTS = { 13165, 13163, 34074, 61846, 109260 }

BS.ClassData.HUNTER = {
    specNames       = { L.BEAST_MASTERY, L.MARKSMANSHIP, L.SURVIVAL },
    specNamesModern = { L.BEAST_MASTERY, L.MARKSMANSHIP, L.SURVIVAL },
    icon = "Interface\\Icons\\Ability_Hunter_AspectOfTheMonkey",
    entries = {
        ----------------------------------------------------------------
        -- Classic-Familie
        ----------------------------------------------------------------
        { key = "aspect",      kind = "buff", spell = { 61846, 13165, 13163 }, auras = COMBAT_ASPECTS,
          label = L.ASPECT, alert = L.ALERT_ASPECT, mode = "combat" },
        { key = "trueshot",    kind = "buff", spell = 19506, specs = { 2 } },
        -- Vorrat (BS-N1): Munition knapp (nur mit Bogen, Schusswaffe oder Armbrust; Munition gibt es bis Wrath)
        { key = "ammo",        kind = "buff", supply = { ammo = true, low = 200, hint = L.SUPPLY_HINT_AMMO }, alertOnly = true, max = 3,
          label = L.SUPPLY_AMMO, alert = L.ALERT_AMMO, icon = "Interface\\Icons\\INV_Ammo_Arrow_02" },
        -- Tierfutter knapp (nur WoW Forever: Futterarten nur dort in den Spieldaten, BuffSentinelVorratDaten.lua): Futter, das der
        -- aktuelle Begleiter frisst, unter 10 -> Warnung; ohne Begleiter oder unbekannte Sprache nichts
        { key = "petfood",     kind = "buff", forever = true, alertOnly = true, iconSpell = 883, label = L.SUPPLY_PETFOOD,
          alert = L.ALERT_PETFOOD, supply = { petfood = true, low = 10, needSpell = 883, hint = L.SUPPLY_HINT_PETFOOD } },
        -- Begleiter fehlt oder ist tot (BS-N1 Punkt 2): Tier rufen (883) gelernt; nur ausserhalb des Kampfes, bis Cata
        { key = "pet",         kind = "buff", pet = { need = 883 }, alertOnly = true, max = 4, iconSpell = 883,
          label = L.PET_LABEL_HUNTER, alert = L.ALERT_PET },

        -- Procs
        { key = "mongoose",    kind = "proc", spell = 1495, trigger = "dodge", window = 5, reactive = true, max = 3 },
        { key = "counter",     kind = "proc", spell = 19306, trigger = "parry", window = 5, reactive = true, specs = { 3 }, max = 3 },
        { key = "killshot",    kind = "proc", spell = 53351, min = 3, targetBelow = 20 },
        { key = "killcommand", kind = "proc", spell = 34026, min = 2, max = 3, reactive = true },   -- Grundfähigkeit (ab Stufe 66), alle Skillungen
        { key = "lockload",    kind = "proc", spell = 53301, procAuras = { 56453 }, min = 3, specs = { 3 },
          talents = { "Lock and Load", "Sichern und Laden" }, alert = L.ALERT_EXPLOSIVE_SHOT },
        { key = "impsteady",   kind = "proc", spell = 19434, procAuras = { 53220 }, min = 3, specs = { 2 },
          talents = { "Improved Steady Shot", "Verbesserter zuverlässiger Schuss" }, alert = L.AIMED_SHOT },

        -- Cooldowns
        { key = "rapidfire",   kind = "cd", spell = 3045 },
        { key = "bestialwrath",kind = "cd", spell = 19574, specs = { 1 } },
        { key = "intimidation",kind = "cd", spell = 19577, specs = { 1 } },
        { key = "kcommand",    kind = "cd", spell = 34026, min = 4, specs = { 1 } },
        { key = "aimed",       kind = "cd", spell = 19434, specs = { 2 }, max = 3 },
        { key = "chimera",     kind = "cd", spell = 53209, min = 3, specs = { 2 } },
        { key = "readiness",   kind = "cd", spell = 23989, min = 2, specs = { 2 } },
        { key = "explosive",   kind = "cd", spell = 53301, min = 3, specs = { 3 } },
        { key = "blackarrow",  kind = "cd", spell = 3674,  min = 3, specs = { 3 } },
        { key = "multishot",   kind = "cd", spell = 2643 },
        { key = "arcaneshot",  kind = "cd", spell = 3044,  max = 3 },
        { key = "feign",       kind = "cd", spell = 5384 },
        { key = "freezetrap",  kind = "cd", spell = 1499 },
        { key = "deterrence",  kind = "cd", spell = 19263, specs = { 3 } },
        { key = "disengage",   kind = "cd", spell = 781 },
        { key = "summonhawk",  kind = "cd", spell = "Summon Hawk", forever = true },

        ----------------------------------------------------------------
        -- Moderne Familie (MoP, Retail)
        ----------------------------------------------------------------
        { key = "m_aspect",    kind = "buff", v = "modern", max = 5, spell = { 13165, 109260 }, auras = { 13165, 109260 },
          label = L.ASPECT, alert = L.ALERT_ASPECT, mode = "combat" },

        { key = "m_killshot",  kind = "proc", v = "modern", spell = 53351, targetBelow = 20 },
        { key = "m_lockload",  kind = "proc", v = "modern", spell = 53301, procAuras = { 56453 }, specs = { 3 } },
        { key = "m_fire",      kind = "proc", v = "modern", spell = 19434, procAuras = { 82926 }, specs = { 2 } },
        { key = "m_thrill",    kind = "proc", v = "modern", spell = 3044, procAuras = { 34720 }, talentSpell = 109306 },

        { key = "m_kcommand",  kind = "cd", v = "modern", spell = 34026, specs = { 1 } },
        { key = "m_bwrath",    kind = "cd", v = "modern", spell = 19574, specs = { 1 } },
        { key = "m_chimera",   kind = "cd", v = "modern", spell = 53209, specs = { 2 } },
        { key = "m_explosive", kind = "cd", v = "modern", spell = 53301, specs = { 3 } },
        { key = "m_blackarrow",kind = "cd", v = "modern", spell = 3674,  specs = { 3 } },
        { key = "m_rapidfire", kind = "cd", v = "modern", spell = 3045 },
        { key = "m_stampede",  kind = "cd", v = "modern", spell = 121818 },
        { key = "m_direbeast", kind = "cd", v = "modern", spell = 120679 },
        { key = "m_crows",     kind = "cd", v = "modern", spell = 131894 },
        { key = "m_glaive",    kind = "cd", v = "modern", spell = 117050 },
        { key = "m_barrage",   kind = "cd", v = "modern", spell = 120360 },
        { key = "m_counter",   kind = "cd", v = "modern", spell = 147362 },
        { key = "m_feign",     kind = "cd", v = "modern", spell = 5384 },
        { key = "m_deterrence",kind = "cd", v = "modern", spell = 19263 },
        { key = "m_disengage", kind = "cd", v = "modern", spell = 781 },
        { key = "m_freeze",    kind = "cd", v = "modern", spell = 1499 },
    },
}
