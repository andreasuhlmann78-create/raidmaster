if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.7 - Buchhaltung (Logik)
--
-- Was wird gebucht?
--   * Verkäufe   - aus den Rechnungen im Briefkasten ("Auktion erfolgreich"):
--                  Verkaufspreis, AH-Anteil (5 %), zurückerstattete Einstellgebühr
--   * Käufe      - aus den Rechnungen im Briefkasten ("Auktion gewonnen")
--                  und sofort bei Käufen über den Sniper (doppelt wird nie gezählt)
--   * Einstellgebühren - sofort beim Einstellen über den Tab Verkaufen
-- Der Briefkasten muss dafür geöffnet werden - die Rechnungen liest das
-- Addon automatisch, du musst nichts abholen oder anklicken.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
-- Retail 12.x: die alten Item-/Zauber-Funktionen gibt es nur noch in C_Item / C_Spell
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local A = AHAnalyzerPro
local string = A.SafeString or string          -- AHS-OVF1: string.format ohne 32-Bit-Überlauf (gleicher Text darunter)
local CreateFrame, C_Timer = A.OwnCreateFrame or CreateFrame, A.OwnTimer or C_Timer      -- VS-BILD-2 (0.65.320): eigene Skripte/Zeitgeber je Bild messen (nur während einer Vollscan-Messung)
local L = A.L

-- Briefkasten über A.Inbox (im Testmodus: Test-Briefkasten mit fiktiver Post)
local function GetInboxNumItems(...) return A.Inbox.GetInboxNumItems(...) end
local function GetInboxHeaderInfo(...) return A.Inbox.GetInboxHeaderInfo(...) end
local function GetInboxInvoiceInfo(...) return A.Inbox.GetInboxInvoiceInfo(...) end
local function GetInboxItem(...) return A.Inbox.GetInboxItem(...) end
local function GetInboxItemLink(...) return A.Inbox.GetInboxItemLink(...) end
local function TakeInboxMoney(...) return A.Inbox.TakeInboxMoney(...) end
local function TakeInboxItem(...) return A.Inbox.TakeInboxItem(...) end

local Le = {}
A.Ledger = Le

local KEEP_DAYS = 180          -- Buchungen älter als das werden gelöscht
local MAX_ENTRIES = 5000
local MATCH_WINDOW = 3 * 86400 -- Sniper-Kauf und Rechnung im Briefkasten gelten als derselbe Kauf
local AH_MAIL_DAYS = 30        -- so lange liegt Auktionspost im Briefkasten

local function DB()
    return A.db and A.db.ledger
end

-- ------------------------------------------------------------
-- Buchen
-- kind: "sale" (Verkauf, amount = Preis brutto, cut = AH-Anteil, refund = Einstellgebühr zurück)
--       "buy"  (Kauf, amount = bezahlter Preis)
--       "deposit" (Einstellgebühr, amount = Gebühr)
-- ------------------------------------------------------------
function Le:Add(e)
    local db = DB()
    if not db then return nil end
    e.t = e.t or time()
    e.qty = e.qty or 1
    e.amount = math.floor(e.amount or 0)
    if not e.name and e.itemID then e.name = A:GetItemName(e.itemID) end
    -- Werte stimmen, Punkt 10: beim Einstellen die Vorhersage merken, beim Verkauf vergleichen
    if e.kind == "deposit" and e.itemID and not e.pred then
        local ok, v = pcall(A.RealPrice, A, e.itemID, { noRelist = true })
        if ok and v then e.pred = math.floor(v + 0.5) end
    elseif e.kind == "sale" and e.itemID and e.src == "mail" then
        pcall(self.CompareSale, self, e)
    end
    table.insert(db.entries, e)
    -- Buchhaltung neu (BP2/BP4): Kauf, Rechnung, Einstellgebühr, Erstattung -> Kostenbasis / realisierter Gewinn
    local BK = A.Books
    if BK then
        if e.kind == "buy" and e.itemID then pcall(BK.OnBuy, BK, e.itemID, e.qty, e.amount, e.t)
        elseif e.kind == "sale" and e.itemID then
            pcall(BK.OnInvoice, BK, e.itemID, e.qty, e.amount, e.cut, e.t)
            if (e.refund or 0) > 0 then pcall(BK.OnFee, BK, -(e.refund), e.t, e.itemID) end
        elseif e.kind == "deposit" then pcall(BK.OnFee, BK, e.amount, e.t, e.itemID)
        elseif e.kind == "refund" then pcall(BK.OnFee, BK, -(e.amount or 0), e.t, e.itemID) end
    end
    -- Prognose-Journal (Stufe 1): Verkauf -> Ergebnis der Einstellung, Kauf -> neuer Eintrag (liest nur)
    if A.Forecast and (e.kind == "sale" or e.kind == "buy") then pcall(A.Forecast.OnLedger, A.Forecast, e) end
    -- B2b: Erstattung ohne gebuchte Einzahlung -> Einzahlung nachbuchen (netto 0)
    if e.kind == "sale" and e.itemID and (e.refund or 0) > 0 then
        local list = {}
        for _, x in ipairs(db.entries) do if x.itemID == e.itemID then list[#list + 1] = x end end
        local ok, added = pcall(self.CoverRefunds, self, list)
        if ok then
            for _, d in ipairs(added) do
                if d.t >= (e.t or 0) - 1 then table.insert(db.entries, #db.entries, d) end
            end
        end
    end
    self:Prune()
    A:Fire("LEDGER_CHANGED")
    return e
end

function Le:Prune()
    local db = DB()
    local cutoff = time() - KEEP_DAYS * 86400
    local list = db.entries
    if #list > MAX_ENTRIES or (list[1] and list[1].t < cutoff) then
        local keep = {}
        for _, e in ipairs(list) do if e.t >= cutoff then table.insert(keep, e) end end
        while #keep > MAX_ENTRIES do table.remove(keep, 1) end
        db.entries = keep
    end
    for key, t in pairs(db.seen) do
        if t < time() - (AH_MAIL_DAYS + 5) * 86400 then db.seen[key] = nil end
    end
end

-- Item-ID aus dem Namen in der Rechnung (Name in der Sprache des Clients)
local function ResolveName(name)
    if not name or name == "" then return nil end
    -- LANG-3 (Befund 19:08 Punkt 3; Nachbau mit echten Daten T250/T255/T268/T572 je 60–190 ms): die Test-Rechnungen nennen das Item
    -- "AHS-Testitem" (kein echtes Item, wie die Test-Marke in TR:HasTestMarker) - ohne diese Abkürzung suchte jede Rechnung alle Namen
    -- aller Sprachen durch, nur um nil zu bekommen. Echte Namen gehen den Weg wie bisher.
    if name:find("^AHS%-Test") then return nil end
    if GetItemInfo then
        local ok, _, link = pcall(GetItemInfo, name)
        if ok and type(link) == "string" then
            local id = tonumber(link:match("item:(%d+)"))
            if id then return id end
        end
    end
    if A.Names then
        -- LANG-3: eindeutiger exakter Name der Client-Sprache über das Verzeichnis (ohne Suche über alle Namen)
        local id = A.Names.ExactID and A.Names:ExactID(name)
        if id then return id end
        id = A.Names:Resolve(name)
        if id then return id end
    end
    return nil
end
Le.ResolveName = ResolveName                                           -- PM1-d: auch für Mailer (Menge aus Feld 5 plausibel prüfen)

-- ------------------------------------------------------------
-- Briefkasten lesen
-- ------------------------------------------------------------
function Le:ScanInbox()
    local db = DB()
    if not db or not A.Inbox.Available() or not (_G.GetInboxInvoiceInfo or A:Simulated()) then return 0 end
    local n = GetInboxNumItems() or 0
    local added = 0
    local now = time()
    local passSeen = {}
    local passBuy = {}                                -- KAUF-DOPPELT: gleiche Kauf-Rechnungen in diesem Durchgang
    for i = 1, n do
        local okH, _, _, sender, subject, money, cod, daysLeft = pcall(GetInboxHeaderInfo, i)
        -- PM1 (Befund 22.11. 08:50): Feld 10 ist etaMin (Minuten), die Menge steht in Feld 11 - vorher las count Feld 10
        local okI, invoiceType, itemName, playerName, bid, buyout, deposit, consignment, _, _, _, count = pcall(GetInboxInvoiceInfo, i)
        -- C3: einmal je Sitzung alle Rückgabewerte (Feldlage belegen), ohne Spielernamen (Feld 3)
        if okI and invoiceType == "seller" and not self.rawLogged and A.Diag then
            self.rawLogged = true
            local raw = { pcall(GetInboxInvoiceInfo, i) }
            local parts = {}
            for k = 2, math.max(#raw, 12) do
                if k - 1 ~= 3 then parts[#parts + 1] = (k - 1) .. "=" .. tostring(raw[k]) end
            end
            A.Diag:Add("RECHNUNG-ROH", table.concat(parts, ", "))
        end
        if okH and okI and (invoiceType == "seller" or invoiceType == "buyer") and itemName then
            -- Ankunftszeit aus der Restlaufzeit (Auktionspost bleibt 30 Tage)
            local arrived = now - math.floor(((AH_MAIL_DAYS - (daysLeft or AH_MAIL_DAYS)) * 86400) + 0.5)
            local hour = math.floor(arrived / 3600)
            count = count or 1
            local price = (invoiceType == "seller") and (buyout or bid or 0) or (bid or buyout or 0)
            local base = table.concat({ invoiceType, itemName, tostring(playerName or ""), tostring(price), tostring(count) }, "|")
            local key = base .. "|" .. hour
            local forever = A:IsForever() and invoiceType == "seller"
            local function seenAt(b) return db.seen[b .. "|" .. hour] or db.seen[b .. "|" .. (hour - 1)] or db.seen[b .. "|" .. (hour + 1)] end
            -- D1 (17:30): Forever-Schlüssel OHNE Post-Gold (nach dem Abholen ist das Gold 0 - sonst zweite Buchung):
            -- Rechnungsart|Item|bid|buyout|consignment|deposit, dazu die wievielte gleiche Rechnung in diesem Durchgang
            -- (zwei gleiche Rechnungen gleichzeitig im Briefkasten bleiben zwei Buchungen). Alte Schlüssel gelten weiter.
            local fkey, isDup
            if forever then
                local fb = table.concat({ "F", invoiceType, itemName, tostring(bid or 0), tostring(buyout or 0),
                    tostring(consignment or 0), tostring(deposit or 0) }, "|")
                passSeen[fb] = (passSeen[fb] or 0) + 1
                fkey = fb .. "#" .. passSeen[fb]
                local oldM = base .. "|m" .. tostring(money or 0)
                isDup = seenAt(fkey) or seenAt(oldM) or seenAt(base)
                -- Gold schon abgeholt: gab es diese Rechnung schon mit Gold (alte Buchung, alter Schlüssel)? -> nie neu
                if not isDup and not (type(money) == "number" and money > 0) and self:HasPaidTwin(itemName, price, consignment, deposit, arrived) then
                    isDup = true
                end
                if isDup then db.seen[fkey .. "|" .. hour] = db.seen[fkey .. "|" .. hour] or now end
            else
                -- KAUF-DOPPELT (0.65.322): zwei gleiche Rechnungen im selben Durchgang (zwei gleiche Käufe in derselben Stunde) sind
                -- zwei Rechnungen - Zähler je Durchgang wie bei Forever-Verkäufen; die erste prüft auch den alten Schlüssel ohne Zähler
                passSeen[base] = (passSeen[base] or 0) + 1
                local nb = passSeen[base]
                fkey = base .. "#" .. nb
                isDup = seenAt(fkey) or (nb == 1 and seenAt(base))
                key = fkey .. "|" .. hour
            end
            if not isDup then
                db.seen[forever and (fkey .. "|" .. hour) or key] = now
                local itemID = ResolveName(itemName)
                if invoiceType == "seller" then
                    if A:IsForever() then
                        -- Gebühren wie im klassischen WoW: beim Verkauf 5 % ab, Einzahlung zurück. Feldlage der Forever-
                        -- Rechnung (RECHNUNG-ROH 15:28, Regelwerk Abschnitt 2): Feld 4 (bid) = GESAMTPREIS, Feld 5 (buyout,
                        -- hier "price") = Menge, Feld 11 = Menge oder 0. Gesamt = bid; Gegenprobe Post-Gold + consignment
                        -- - deposit, solange das Gold noch in der Post ist.
                        local cut, dep = consignment or 0, deposit or 0
                        local total, qty, approx
                        local field11 = select(12, pcall(GetInboxInvoiceInfo, i))
                        local fromMoney = (type(money) == "number" and money > 0) and (money + cut - dep) or nil
                        if type(bid) == "number" and bid > 0 then
                            total = bid
                            if fromMoney and fromMoney ~= bid then approx = true end
                        else
                            total = fromMoney
                        end
                        if not fromMoney then approx = true end           -- Gold schon abgeholt: ohne Gegenprobe
                        if type(field11) == "number" and field11 >= 1 then qty = math.floor(field11 + 0.5)
                        elseif (count or 0) >= 1 then qty = count
                        else
                            -- B1 (Befund 09:15): Feld 5 nur als Menge, wenn es plausibel eine Menge ist
                            local q, isApprox = self:QtyFromField5(itemID, price, bid, total)
                            qty = q
                            if isApprox then approx = true end
                        end
                        if not qty or qty < 1 then qty, approx = 1, true end
                        if not total then total, approx = 0, true end
                        if not fromMoney and A.Diag then A.Diag:Add("RECHNUNG", "ohne Gold (schon abgeholt): Gesamt aus Feld 4") end
                        -- Plausibilität: consignment = 5 % vom Gesamtpreis (Rundung je Auktion)
                        if total > 0 and math.abs(cut - total * A:CutPct()) > math.max(3, qty * 0.05) then
                            approx = true
                            if A.Diag then A.Diag:Add("RECHNUNG", string.format("unplausibel: Gesamt %d, consignment %d (%d %% wären %d)",
                                total, cut, math.floor(A:CutPct() * 100 + 0.5), math.floor(total * A:CutPct()))) end
                        end
                        self:Add({ kind = "sale", t = arrived, itemID = itemID, name = itemName, qty = qty,
                                   amount = total, cut = cut, refund = dep, player = playerName, src = "mail", approx = approx,
                                   inv = { price = price, bid = bid, cut = cut, deposit = dep, money = money or 0, count = count,
                                           field11 = field11, qtyField = true } })
                        if A.Diag then
                            A.Diag:Add("RECHNUNG", string.format("Item %s · Menge %d (Feld 5 %s, Feld 11 %s) · Feld 4 %s · consignment %d · deposit %d · Post-Gold %d · gesamt %d · Stück %d · Feld 4 = Gesamt: %s",
                                tostring(itemID or "?"), qty, tostring(price), tostring(field11), tostring(bid), cut, dep, money or 0, total,
                                math.floor(total / qty + 0.5), fromMoney and (fromMoney == bid and "ja" or "nein") or "?"))
                        end
                    else
                        self:Add({ kind = "sale", t = arrived, itemID = itemID, name = itemName, qty = count,
                                   amount = price, cut = consignment or 0, refund = deposit or 0, player = playerName, src = "mail" })
                    end
                    added = added + 1
                else
                    -- LG5 (Befund 10.11. 14:15): Kauf-Rechnung - Menge nie 0; in Forever wie beim Verkauf Feld 4 = Gesamt,
                    -- Menge aus Feld 11 / count / Feld 5 (plausibel)
                    local qty, total = count, price
                    if A:IsForever() then
                        local field11 = select(12, pcall(GetInboxInvoiceInfo, i))
                        if type(bid) == "number" and bid > 0 then total = bid end
                        if type(field11) == "number" and field11 >= 1 then qty = math.floor(field11 + 0.5)
                        elseif not ((count or 0) >= 1) then
                            local okQ, q = pcall(self.QtyFromField5, self, itemID, buyout, bid, total)
                            qty = okQ and q or 1
                        end
                    end
                    if not qty or qty < 1 then qty = 1 end
                    -- KAUF-DOPPELT (0.65.322): dieselbe Rechnung ein zweites Mal gelesen (Schlüssel des Briefkastens anders, z. B. nach
                    -- dem Abholen)? Gleiches Item, Menge, Betrag, Ankunft ±SAME_INVOICE_S schon gebucht -> nicht nochmals. Gleiche Rechnungen
                    -- im selben Durchgang zählen einzeln (zwei gleiche Käufe = zwei Rechnungen = zwei Zeilen).
                    local pk = table.concat({ tostring(itemID or itemName), qty, total or 0, math.floor(arrived / 60) }, "|")
                    passBuy[pk] = (passBuy[pk] or 0) + 1
                    if self:InvoiceBookedCount(itemID, itemName, qty, total, arrived) >= passBuy[pk] then
                        if A.Diag then A.Diag:Add("KAUF-DOPPELT", string.format("verhindert: Rechnung schon gebucht · Item %s · %d Stück · %d",
                            tostring(itemID or "?"), qty, total or 0)) end
                    -- schon über den Sniper / Einkauf gebucht? Dann genau EINMAL (Betrag aus der Rechnung)
                    elseif not self:MatchInvoice(itemID, itemName, qty, total, arrived, playerName) then
                        self:Add({ kind = "buy", t = arrived, itemID = itemID, name = itemName, qty = qty,
                                   amount = total, player = playerName, src = "mail" })
                        added = added + 1
                    end
                end
            end
        end
    end
    if A.Forecast then pcall(A.Forecast.NoteMail, A.Forecast, now) end
    if added > 0 then
        A:Print(added == 1 and L["Buchhaltung: 1 neue Rechnung aus dem Briefkasten gebucht."]
            or string.format(L["Buchhaltung: %d neue Rechnungen aus dem Briefkasten gebucht."], added))
    end
    return added
end

-- D1: gibt es zu einer Rechnung ohne Gold (schon abgeholt) schon eine Buchung derselben Rechnung mit Gold?
-- Gleiche Menge (Feld 5), gleiches consignment und deposit, gleiches Item, höchstens 2 Std. auseinander.
function Le:HasPaidTwin(itemName, price, cut, dep, t)
    local itemID = ResolveName(itemName)
    for _, e in ipairs(DB().entries) do
        local inv = e.inv
        if e.kind == "sale" and inv and (inv.money or 0) > 0 and inv.price == price and inv.cut == (cut or 0)
            and inv.deposit == (dep or 0) and math.abs((e.t or 0) - t) <= 2 * 3600
            and ((itemID and e.itemID == itemID) or e.name == itemName) then
            return true
        end
    end
    return false
end

-- Rechnung (Kauf) einer schon gemeldeten Kaufbuchung zuordnen; true = zugeordnet (keine neue Buchung)
function Le:MatchInvoice(itemID, itemName, qty, total, arrived, playerName)
    local match, partial = self:FindUnmatchedBuy(itemID, itemName, qty, total, arrived)
    if match and partial then
        -- TB182-2 (c): Teil-Rechnung dem offenen Kauf zuordnen, Rest bleibt offen; sind alle Teile da, gilt die
        -- Summe der Rechnungen (wie "Rechnung gilt"), nie eine zweite Buchung
        match.mailQty = (match.mailQty or 0) + qty
        match.mailAmt = (match.mailAmt or 0) + (total or 0)
        match.mailT = arrived
        match.player = match.player or playerName
        if match.mailQty >= (match.qty or 0) then
            match.mail = true
            if match.mailAmt > 0 and match.mailAmt ~= match.amount then
                if A.Diag then A.Diag:Add("KAUF-DOPPELT", string.format("verhindert (Teil-Rechnungen): Item %s · %d Stück · Kaufmeldung %d · Rechnungen %d (Rechnungen gelten)",
                    tostring(itemID or "?"), match.qty or 0, match.amount or 0, match.mailAmt)) end
                match.eventAmount = match.eventAmount or match.amount
                match.amount = match.mailAmt
                A:Fire("LEDGER_CHANGED")
            end
        end
    elseif match then
        match.mail = true
        match.mailT = arrived                         -- KAUF-DOPPELT: Ankunft der Rechnung (zweites Lesen erkennen)
        match.player = match.player or playerName
        if match.amount ~= total and total and total > 0 then
            if A.Diag then A.Diag:Add("KAUF-DOPPELT", string.format("verhindert: Item %s · %d Stück · Kaufmeldung %d · Rechnung %d (Rechnung gilt)",
                tostring(itemID or "?"), qty, match.amount or 0, total)) end
            match.eventAmount = match.eventAmount or match.amount
            match.amount = total
            A:Fire("LEDGER_CHANGED")
        end
    end
    return match ~= nil
end

function Le:FindUnmatchedBuy(itemID, itemName, qty, amount, t)
    local loose, looseD, part, partD, exact, exactD
    for _, e in ipairs(DB().entries) do
        if e.kind == "buy" and (e.src == "sniper" or e.src == "buy") and not e.mail
            and math.abs(e.t - t) <= MATCH_WINDOW and ((itemID and e.itemID == itemID) or e.name == itemName) then
            local d = math.abs(e.t - t)
            if e.qty == qty and (e.mailQty or 0) == 0 then
                -- KAUF-DOPPELT: gleicher Betrag -> der zeitlich NÄCHSTE Kauf (vorher der älteste im Fenster: die Rechnung eines späteren
                -- gleichen Kaufs nahm dem früheren seine Zeile weg)
                if e.amount == amount then
                    if not exactD or d < exactD then exact, exactD = e, d end
                end
                -- LG5: gleicher Kauf mit anderem Betrag (Gebot statt Sofortkauf, Rundung) - der zeitlich nächste
                if not looseD or d < looseD then loose, looseD = e, d end
            elseif (e.qty or 0) > qty and (e.mailQty or 0) + qty <= e.qty then
                -- TB182-2 (c) (Supervisor 18:58): Teil-Rechnung (Ware von mehreren Verkäufern = je Verkäufer eine Rechnung,
                -- oder Teilkauf) gehört zum offenen Kauf mit grösserer Menge - der zeitlich nächste
                if not partD or d < partD then part, partD = e, d end
            end
        end
    end
    if exact then return exact end
    if loose then return loose end
    if part then return part, true end
    return nil
end

-- ------------------------------------------------------------
-- KAUF-DOPPELT (0.65.322, Befund AHSentinel 0.65.319, Supervisor MITTEL-HOCH): 118 Käufe standen doppelt in Journal und Buchhaltung
-- (Quelle sniper/watcher UND mail, gleiche Zeit). Ursache (Nachbau s281): die Rechnung kam an und wurde gelesen, BEVOR der Kauf des
-- Snipers gebucht war (Buchung wartet auf die Gold-Messung, TB182-2) -> keine Zuordnung, eigene "mail"-Buchung; danach buchte der
-- Sniper denselben Kauf noch einmal. Jetzt: (a) der Sniper-Kauf übernimmt eine schon gebuchte, noch nicht zugeordnete Rechnung desselben
-- Kaufs (gleiches Item und Menge, höchstens MAIL_FIRST_S älter) statt einer zweiten Zeile; (b) dieselbe Rechnung zweimal gelesen wird
-- nicht nochmals gebucht. Ein Kauf = eine Zeile.
-- ------------------------------------------------------------
Le.SAME_INVOICE_S = 10                -- dieselbe Rechnung: Ankunft aus "Tage übrig" auf Sekunden gleich; zwei gleiche Käufe liegen weiter auseinander
Le.MAIL_FIRST_S = 600
function Le:InvoiceBookedCount(itemID, itemName, qty, total, arrived)
    local n = 0
    for _, e in ipairs(DB().entries) do
        if e.kind == "buy" and ((itemID and e.itemID == itemID) or (not itemID and e.name == itemName)) and e.qty == qty then
            local t = (e.src == "mail" and e.t) or e.mailT
            local amt = (e.src == "mail" and e.amount) or (e.mailAmt or e.amount)
            if t and math.abs(t - arrived) <= self.SAME_INVOICE_S and amt == total then n = n + 1 end
        end
    end
    return n
end
-- schon gebuchte Rechnung (Quelle mail, keinem Kauf zugeordnet) zu einem gerade gemeldeten Kauf - die zeitlich nächste
function Le:FindMailFirst(itemID, qty, t)
    local best, bestD
    for _, e in ipairs(DB().entries) do
        if e.kind == "buy" and e.src == "mail" and not e.linked and e.itemID == itemID and e.qty == qty then
            local d = t - (e.t or 0)
            if d >= -self.SAME_INVOICE_S and d <= self.MAIL_FIRST_S and (not bestD or math.abs(d) < bestD) then best, bestD = e, math.abs(d) end
        end
    end
    return best
end

-- KAUF-DOPPELT (c): bestehende Doppel EINMAL bereinigen (db.kaufDoppeltFix). Doppel = Kauf mit Quelle "mail" (Rechnung, keinem Kauf
-- zugeordnet) UND ein Sniper-/Einkauf mit zugeordneter Rechnung (mail = true): gleiches Item, gleiche Menge, gleicher Betrag, höchstens
-- FIX_GAP_S auseinander - je Sniper-Kauf höchstens EIN Doppel. Entfernt wird nur die "mail"-Zeile (der Kauf bleibt einmal). Im Journal
-- dieselbe Regel für die Einträge B (Quelle mail gegen sniper/watcher/buy, gleiche Menge und gleicher Preis). Echte Käufe ohne Partner
-- bleiben. Zahlen vorher/nachher ins Protokoll (KAUF-DOPPELT) und nach db.kaufDoppeltFix.
Le.FIX_GAP_S = 300
function Le:FixDoubleBuys(pause)
    local root = A.db
    if not root or root.kaufDoppeltFix then return nil end
    local db = DB()
    if not db then return nil end
    local entries = db.entries
    local partners, used = {}, {}
    for i, e in ipairs(entries) do
        if e.kind == "buy" and (e.src == "sniper" or e.src == "buy") and e.mail and e.itemID then
            partners[e.itemID] = partners[e.itemID] or {}
            table.insert(partners[e.itemID], i)
        end
        if pause and i % 200 == 0 then A:Pause() end
    end
    local drop, nBefore, sum = {}, #entries, 0
    for i, e in ipairs(entries) do
        if e.kind == "buy" and e.src == "mail" and e.itemID and partners[e.itemID] then
            local best, bestD
            for _, j in ipairs(partners[e.itemID]) do
                local p = entries[j]
                local d = math.abs((p.t or 0) - (e.t or 0))
                local amt = p.mailAmt or p.amount
                if not used[p] and p.qty == e.qty and (amt == e.amount or p.amount == e.amount or p.eventAmount == e.amount) and d <= self.FIX_GAP_S
                    and (not bestD or d < bestD) then best, bestD = j, d end
            end
            if best then used[entries[best]] = true; drop[e] = true; sum = sum + (e.amount or 0) end
        end
        if pause and i % 200 == 0 then A:Pause() end
    end
    -- ohne Pause: erst jetzt die aktuelle Liste (in den Pausen dazugekommene Zeilen bleiben), Zeilen über ihre Tabelle erkannt
    local keep, nDrop = {}, 0
    for _, e in ipairs(db.entries) do if drop[e] then nDrop = nDrop + 1 else keep[#keep + 1] = e end end
    nBefore = #db.entries
    db.entries = keep
    -- Journal
    local jDrop, jBefore = 0, 0
    local F = A.Forecast
    local f = F and F.Store and F:Store()
    if f and f.list then
        local list0 = f.list
        jBefore = #f.list
        local dec, byId = {}, {}
        for i, x in ipairs(f.list) do
            if x:sub(1, 1) == "B" then
                local e = F:Decode(x)
                if e then
                    dec[i] = e
                    if e.src ~= "mail" then byId[e.id] = byId[e.id] or {}; table.insert(byId[e.id], i) end
                end
            end
            if pause and i % 200 == 0 then A:Pause() end
        end
        local jdrop, jused = {}, {}
        for i, e in pairs(dec) do
            if e.src == "mail" and byId[e.id] then
                local best, bestD
                for _, j in ipairs(byId[e.id]) do
                    local p = dec[j]
                    local d = math.abs((p.t or 0) - (e.t or 0))
                    if not jused[j] and p.q == e.q and p.pr == e.pr and d <= self.FIX_GAP_S + 60 and (not bestD or d < bestD) then best, bestD = j, d end
                end
                if best then jused[best] = true; jdrop[i] = true end
            end
        end
        -- nur, wenn das Journal in den Pausen dasselbe blieb (sonst beim nächsten Start; Kennzeichen bleibt dann aus)
        if f.list == list0 and #f.list == jBefore then
            local jkeep = {}
            for i, x in ipairs(f.list) do if not jdrop[i] then jkeep[#jkeep + 1] = x end end
            jDrop = #f.list - #jkeep
            if jDrop > 0 then f.list = jkeep; F.evalCache = nil end
        else
            jBefore = -1
        end
    end
    if jBefore < 0 then return nDrop, nil, sum end             -- Journal geändert: Kennzeichen nicht setzen, nächster Start rechnet nach
    root.kaufDoppeltFix = { t = time(), ledger = nDrop, ledgerBefore = nBefore, amount = sum, journal = jDrop, journalBefore = jBefore }
    local txt = string.format("bereinigt: Buchhaltung %d -> %d Zeilen (%d doppelte Käufe, zusammen %d Kupfer) · Journal %d -> %d Einträge (%d doppelte Käufe)",
        nBefore, #keep, nDrop, sum, jBefore, jBefore - jDrop, jDrop)
    if A.Diag then pcall(A.Diag.Add, A.Diag, "KAUF-DOPPELT", txt) end
    if nDrop > 0 or jDrop > 0 then A:Fire("LEDGER_CHANGED") end
    return nDrop, jDrop, sum
end
A:On("READY", function()
    if A:Simulated() or (A.db and A.db.kaufDoppeltFix) then return end
    if A.Job then A:Job("ledger:doppelt", function() Le:FixDoubleBuys(true) end) else pcall(Le.FixDoubleBuys, Le) end
end)

-- LG5: Kauf-Ereignisse genau einmal buchen - je auctionID höchstens einmal (Sitzung)
Le.bookedAuctions = Le.bookedAuctions or {}
function Le:BookPurchase(p, src, auctionID, force)
    if not p or p.booked then return false end
    if p.holdBook and not force then return false end            -- TB182-2: wartet auf die Gold-Messung (Le:BookMeasured)
    local id = auctionID or p.auctionID or (p.listing and p.listing.auctionID)
    if id and self.bookedAuctions[id] then
        p.booked = true
        if A.Diag then A.Diag:Add("KAUF-DOPPELT", string.format("verhindert: Auktion schon gebucht · Item %s · %d Stück · %d",
            tostring(p.itemID or "?"), p.qty or 1, p.cost or 0)) end
        return false
    end
    p.booked = true
    self.lastBookGT = GetTime and GetTime() or nil                   -- TB182-2: Messung "sauber"?
    if id then self.bookedAuctions[id] = true end
    -- KAUF-DOPPELT (a): die Rechnung war schneller - ihre Zeile wird zum Sniper-/Einkauf (Betrag der Rechnung gilt), keine zweite
    local mf = p.itemID and self:FindMailFirst(p.itemID, p.qty or 1, time())
    if mf then
        local svSrc = mf.src
        mf.src, mf.aid, mf.mail, mf.linked, mf.mailT = src, id, true, true, mf.t
        mf.eventAmount = p.cost
        if A.Diag then A.Diag:Add("KAUF-DOPPELT", string.format("verhindert: Rechnung vor dem Kauf gebucht · Item %s · %d Stück · Kauf %d · Rechnung %d (Rechnung gilt)",
            tostring(p.itemID), p.qty or 1, p.cost or 0, mf.amount or 0)) end
        local F = A.Forecast
        if F and F.RelinkBuy then pcall(F.RelinkBuy, F, p.itemID, mf.t, svSrc, src, id) end
        A:Fire("LEDGER_CHANGED")
        return true
    end
    self:Add({ kind = "buy", itemID = p.itemID, qty = p.qty, amount = p.cost, src = src, aid = id })   -- aid: Prognose PD2
    return true
end

-- LG5: mögliche Doppelbuchungen (nur lesen): Rechnung (src "mail") + Kaufmeldung (sniper/buy, ohne Rechnung) desselben
-- Items, gleiche Menge, höchstens 3 Tage auseinander - nur eindeutige Paare (je Rechnung genau eine Kaufmeldung)
function Le:FindDoubleBuys()
    local db = DB()
    local mails, events = {}, {}
    for idx, e in ipairs(db and db.entries or {}) do
        if e.kind == "buy" then
            if e.src == "mail" then mails[#mails + 1] = { idx, e }
            elseif (e.src == "sniper" or e.src == "buy") and not e.mail then events[#events + 1] = { idx, e } end
        end
    end
    local used, out = {}, {}
    for _, m in ipairs(mails) do
        local cand = {}
        for _, ev in ipairs(events) do
            local e = ev[2]
            if not used[ev[1]] and e.itemID == m[2].itemID and (e.qty == m[2].qty or (m[2].qty or 0) == 0)
                and math.abs((e.t or 0) - (m[2].t or 0)) <= MATCH_WINDOW then cand[#cand + 1] = ev end
        end
        if #cand == 1 then
            used[cand[1][1]] = true
            out[#out + 1] = { mail = m[2], event = cand[1][2] }
        end
    end
    return out
end

-- LG5: eindeutige Doppelbuchungen bereinigen - nur auf Befehl des Nutzers, vorher Sicherung (db.ledger.dupBackup);
-- die Rechnung bleibt (Betrag aus der Rechnung), die Kaufmeldung wird zur Sicherung verschoben. Rückgängig mit undo.
function Le:RepairDoubleBuys()
    local db = DB()
    if not db then return 0 end
    local pairsL = self:FindDoubleBuys()
    if #pairsL == 0 then return 0 end
    db.dupBackup = db.dupBackup or {}
    local drop = {}
    for _, p in ipairs(pairsL) do drop[p.event] = true end
    local keep, moved = {}, {}
    for _, e in ipairs(db.entries) do
        if drop[e] then moved[#moved + 1] = e else keep[#keep + 1] = e end
    end
    table.insert(db.dupBackup, { t = time(), entries = moved })
    for k in pairs(db.entries) do db.entries[k] = nil end
    for i, e in ipairs(keep) do db.entries[i] = e end
    for _, p in ipairs(pairsL) do
        if p.mail.qty == 0 then p.mail.qty = p.event.qty end
        if A.Diag then A.Diag:Add("KAUF-DOPPELT", string.format("bereinigt: Item %s · %d Stück · Kaufmeldung %d · Rechnung %d",
            tostring(p.event.itemID or "?"), p.event.qty or 1, p.event.amount or 0, p.mail.amount or 0)) end
    end
    self.itemIndex = nil
    A:Fire("LEDGER_CHANGED")
    return #moved
end
function Le:UndoRepairDoubleBuys()
    local db = DB()
    local b = db and db.dupBackup and db.dupBackup[#db.dupBackup]
    if not b then return 0 end
    for _, e in ipairs(b.entries) do table.insert(db.entries, e) end
    table.sort(db.entries, function(x, y) return (x.t or 0) < (y.t or 0) end)
    table.remove(db.dupBackup)
    self.itemIndex = nil
    A:Fire("LEDGER_CHANGED")
    return #b.entries
end
function Le:DoubleCommand(arg)
    if arg == "bereinigen" or arg == "repair" then
        local n = self:RepairDoubleBuys()
        A:Print(string.format(L["Buchhaltung: %d doppelte Kaufbuchungen bereinigt (Sicherung angelegt, rückgängig mit /ahs doppelt zurück)."], n))
    elseif arg == "zurück" or arg == "zurueck" or arg == "undo" then
        local n = self:UndoRepairDoubleBuys()
        A:Print(string.format(L["Buchhaltung: %d Kaufbuchungen aus der Sicherung zurückgeholt."], n))
    else
        local list = self:FindDoubleBuys()
        local qty, sum = 0, 0
        for _, p in ipairs(list) do qty = qty + (p.event.qty or 1); sum = sum + (p.event.amount or 0) end
        A:Print(string.format(L["Buchhaltung: %d mögliche Doppelbuchungen (%d Stück, %s). Bereinigen mit /ahs doppelt bereinigen."],
            #list, qty, A:FormatMoney(sum)))
        if A.Diag and #list > 0 then A.Diag:Add("KAUF-DOPPELT", string.format("gefunden: %d Paare · %d Stück · %d", #list, qty, sum)) end
    end
end

-- ------------------------------------------------------------
-- Auswertung
-- ------------------------------------------------------------
Le.PERIODS = {
    { key = "today", label = "Heute" },
    { key = "7", label = "7 Tage", days = 7 },
    { key = "30", label = "30 Tage", days = 30 },
    { key = "all", label = "Seit Neustart" },
}

function Le:PeriodStart(key)
    if key == "today" then
        return A:DayStart(time())
    end
    for _, p in ipairs(self.PERIODS) do
        if p.key == key and p.days then return time() - p.days * 86400 end
    end
    return 0
end

function Le:GetEntries(key)
    local from = self:PeriodStart(key)
    local out = {}
    for _, e in ipairs(DB().entries) do
        if e.t >= from then table.insert(out, e) end
    end
    return out
end

-- ------------------------------------------------------------
-- Abrechnung Entzaubern (Anweisung Sammelkauf E4, ab 0.65.38)
-- Je Tag und gesamt: ausgegeben für Sammelkauf-Teile, Wert der erhaltenen Materialien, Gewinn, Anzahl, Rendite %.
-- Zugeordnet werden Kauf und Entzauberung über ItemID + Zeitfenster (Disenchant.lua D:LogResult, 14 Tage).
-- Materialwert = reale Preisfunktion (A:PriceInfo über D:MatPrice): eigene Verkäufe der letzten 14 Tage zuerst,
-- also der echte Erlös, wenn das Material schon verkauft wurde; sonst der aktuelle reale Wert. Nach AH-Gebühr.
-- Entzauberungen eigener Teile (ohne Kauf) zählen getrennt (nur Materialwert).
-- ------------------------------------------------------------
local function DayKey(t)
    return A:DayStart(t)
end
Le.DayKey = DayKey

-- Materialwert einer Entzauberung (netto nach AH-Gebühr), complete = false wenn ein Preis fehlt
function Le:DisenchantLootValue(loot)
    local D = A.Disenchant
    local v, complete = 0, true
    for _, m in ipairs(loot or {}) do
        local p = D and D.MatPrice and D:MatPrice(m[1]) or nil
        if p then
            local qty = m[2] or 1
            local fee = A.FeePerPiece and A:FeePerPiece(m[1], p) or 0
            v = v + math.max(0, p - fee) * qty
        else
            complete = false
        end
    end
    return math.floor(v + 0.5), complete
end

function Le:DisenchantReport(key)
    local from = self:PeriodStart(key)
    local days, total = {}, { count = 0, spent = 0, value = 0, own = 0, ownValue = 0, incomplete = 0 }
    -- LANG-3/E1 (Nachbau mit echten Daten: 99 ms von 102 ms des Berichts "30", 2000 Entzauberungen): in Portionen abgeben - NUR in
    -- der Coroutine, die es erlaubt (Le.pauseCo, gesetzt vom Bericht der Hintergrund-Aufgabe; nie über ein fremdes pcall, Lua 5.1)
    local pco = self.pauseCo
    if pco and pco ~= coroutine.running() then pco = nil end
    for i, e in ipairs(A.db and A.db.deLog or {}) do
        if pco and i % 25 == 0 then A:Pause() end
        if (e.t or 0) >= from then
            local dk = DayKey(e.t)
            local d = days[dk]
            if not d then d = { day = dk, count = 0, spent = 0, value = 0, own = 0, ownValue = 0 }; days[dk] = d end
            local v, complete = self:DisenchantLootValue(e.loot)
            if not complete then total.incomplete = total.incomplete + 1 end
            if e.paid then
                d.count, d.spent, d.value = d.count + 1, d.spent + e.paid, d.value + v
                total.count, total.spent, total.value = total.count + 1, total.spent + e.paid, total.value + v
            else
                d.own, d.ownValue = d.own + 1, d.ownValue + v
                total.own, total.ownValue = total.own + 1, total.ownValue + v
            end
        end
    end
    local rows = {}
    for _, d in pairs(days) do
        d.profit = d.value - d.spent
        d.roi = d.spent > 0 and (d.profit / d.spent * 100) or nil
        rows[#rows + 1] = d
    end
    table.sort(rows, function(a, b) return a.day > b.day end)
    total.profit = total.value - total.spent
    total.roi = total.spent > 0 and (total.profit / total.spent * 100) or nil
    -- gekauft, noch nicht entzaubert
    total.open, total.openSpent = 0, 0
    for _, b in ipairs(A.db and A.db.deBuys or {}) do
        if not b.done and (b.t or 0) >= from then total.open, total.openSpent = total.open + 1, total.openSpent + (b.paid or 0) end
    end
    return rows, total
end

-- ------------------------------------------------------------
-- H8 (Korrektur 13:20): Abrechnung je Kauf-Charge (alle Sammelkauf-Teile eines Kauftags)
--   bezahlt = Σ Kaufpreis; Beute = Materialien der entzauberten Teile (deLog-Eintrag mit b.done == e.t)
--   verkauft = Verkäufe dieser Materialien ab dem Kauftag (Buchhaltung), der Reihe nach den Chargen
--   zugeteilt (älteste zuerst); Gebühren = AH-Anteil der zugeteilten Verkäufe + verlorene Einzahlungen
--   (je verkauftem Stück verteilt); Lager = Rest × realistischer Materialpreis nach Gebühr.
--   LG3: Rest zuerst in eigenen laufenden Auktionen (Angebotspreis × 0,95), dann Lager.
--   Ergebnis = verkauft + im AH + Lager − Gebühren − bezahlt. Nur lesen, nichts wird geändert.
-- ------------------------------------------------------------
function Le:DisenchantCharges()
    local buys = A.db and A.db.deBuys or {}
    local log = A.db and A.db.deLog or {}
    local charges, byDay, byDone = {}, {}, {}
    for _, b in ipairs(buys) do
        local dk = DayKey(b.t or 0)
        local c = byDay[dk]
        if not c then
            c = { day = dk, t = b.t or 0, paid = 0, parts = 0, done = 0, mats = {} }
            byDay[dk] = c; charges[#charges + 1] = c
        end
        if (b.t or 0) < c.t then c.t = b.t end
        c.paid, c.parts = c.paid + (b.paid or 0), c.parts + 1
        if b.done then byDone[tostring(b.itemID) .. ":" .. tostring(b.done)] = c end
    end
    for _, e in ipairs(log) do
        local c = e.paid and byDone[tostring(e.itemID) .. ":" .. tostring(e.t)]
        if c then
            c.done = c.done + 1
            for _, l in ipairs(e.loot or {}) do c.mats[l[1]] = (c.mats[l[1]] or 0) + (l[2] or 1) end
        end
    end
    table.sort(charges, function(a, b) return a.t < b.t end)
    local first = charges[1] and charges[1].t or 0
    -- Verkäufe und Einzahlungen je Material ab der ersten Charge
    local need = {}
    for _, c in ipairs(charges) do for id in pairs(c.mats) do need[id] = true end end
    local sales, lost = {}, {}
    local db = DB()
    for _, e in ipairs(db and db.entries or {}) do
        local id = e.itemID
        if id and need[id] and (e.t or 0) >= first then
            if e.kind == "sale" then
                local q = math.max(1, e.qty or 1)
                local list = sales[id] or {}; sales[id] = list
                list[#list + 1] = { t = e.t or 0, left = q, unit = self:SaleGross(e) / q, cut = (e.cut or 0) / q }
                lost[id] = (lost[id] or 0) - (e.refund or 0)
            elseif e.kind == "deposit" then lost[id] = (lost[id] or 0) + (e.amount or 0)
            elseif e.kind == "refund" then lost[id] = (lost[id] or 0) - (e.amount or 0) end
        end
    end
    local soldQty = {}
    for id, list in pairs(sales) do
        table.sort(list, function(a, b) return a.t < b.t end)
        local n = 0
        for _, s in ipairs(list) do n = n + s.left end
        soldQty[id] = n
    end
    local D = A.Disenchant
    -- LG3: eigene laufende Auktionen der Materialien (Stück und Wert je Stück, Angebotspreis × 0,95)
    local ahLeft, ahUnit = {}, {}
    local okP, _, ahQ, _, _, ahV = pcall(self.StockParts, self)
    if okP and ahQ then
        for id, q in pairs(ahQ) do
            if need[id] and q > 0 then ahLeft[id] = q; ahUnit[id] = (ahV and ahV[id] or 0) / q end
        end
    end
    for _, c in ipairs(charges) do
        c.sold, c.fees, c.stock, c.soldQty, c.stockQty, c.inAH, c.inAHQty = 0, 0, 0, 0, 0, 0, 0
        for id, q in pairs(c.mats) do
            local left = q
            for _, s in ipairs(sales[id] or {}) do
                if left <= 0 then break end
                if s.left > 0 and s.t >= c.t then
                    local take = math.min(left, s.left)
                    s.left, left = s.left - take, left - take
                    c.sold = c.sold + take * s.unit
                    c.fees = c.fees + take * s.cut
                    c.soldQty = c.soldQty + take
                    local l = math.max(0, lost[id] or 0)
                    if (soldQty[id] or 0) > 0 then c.fees = c.fees + take * l / soldQty[id] end
                end
            end
            if left > 0 and (ahLeft[id] or 0) > 0 then
                local take = math.min(left, ahLeft[id])
                ahLeft[id], left = ahLeft[id] - take, left - take
                c.inAHQty = c.inAHQty + take
                c.inAH = c.inAH + take * (ahUnit[id] or 0)
            end
            if left > 0 then
                c.stockQty = c.stockQty + left
                local p = D and D.MatPrice and D:MatPrice(id)
                if p then
                    local fee = A.FeePerPiece and A:FeePerPiece(id, p) or 0
                    c.stock = c.stock + left * math.max(0, p - fee)
                else c.incomplete = true end
            end
        end
        c.sold, c.fees, c.stock, c.inAH = math.floor(c.sold + 0.5), math.floor(c.fees + 0.5), math.floor(c.stock + 0.5), math.floor(c.inAH + 0.5)
        c.result = c.sold + c.inAH + c.stock - c.fees - c.paid
        c.open = c.parts - c.done
    end
    return charges
end

-- LG3: Summe über alle Chargen (Entzauber-Käufe insgesamt)
function Le:ChargeTotal(charges)
    local t = { paid = 0, sold = 0, inAH = 0, stock = 0, fees = 0, result = 0, parts = 0, done = 0 }
    for _, c in ipairs(charges or {}) do
        for k in pairs(t) do t[k] = t[k] + (c[k] or 0) end
    end
    return t
end
function Le:ChargeTotalLine(t)
    local res = t.result >= 0 and ("+" .. A:FormatMoney(t.result)) or ("−" .. A:FormatMoney(-t.result))
    return string.format(L["Entzauber-Käufe gesamt: %d Teile für %s · Beute verkauft %s, im AH %s, Lager %s · Gebühren %s · Ergebnis %s"],
        t.parts, A:FormatMoney(t.paid), A:FormatMoney(t.sold), A:FormatMoney(t.inAH), A:FormatMoney(t.stock), A:FormatMoney(t.fees), res)
end

function Le:ChargeLine(c)
    local res = c.result >= 0 and ("+" .. A:FormatMoney(c.result)) or ("−" .. A:FormatMoney(-c.result))
    local line = string.format(L["Charge %s: bezahlt %s, verkauft %s, im AH %s, Lager %s, Gebühren %s, Ergebnis %s"],
        date("%d.%m.", c.day), A:FormatMoney(c.paid), A:FormatMoney(c.sold), A:FormatMoney(c.inAH or 0), A:FormatMoney(c.stock), A:FormatMoney(c.fees), res)
    if (c.open or 0) > 0 then line = line .. string.format(L[" (%d Teile noch nicht entzaubert)"], c.open) end
    return line
end

-- ------------------------------------------------------------
-- Vorhersage gegen Wirklichkeit (Werte stimmen, Punkt 10)
-- Vorhersage = realer Preis pro Stück beim Einstellen (A:RealPrice), Wirklichkeit = Verkaufspreis pro Stück aus der
-- Rechnung. Abweichung = (Vorhersage - echt) / echt: positiv = Werte zu hoch. Je Item-Gruppe (Item-Klasse) und gesamt.
-- Diagnose-Protokoll: Eintrag WERT (ohne Namen), die Prüf-Sitzung wertet ihn über GSDIAG1 aus.
-- ------------------------------------------------------------
Le.DEV_DAYS = 7
local function ItemGroup(itemID)
    if not (GetItemInfo and itemID) then return nil end
    local classID = select(12, GetItemInfo(itemID))
    return classID
end
function Le:GroupName(classID)
    if classID == nil then return "?" end
    local f = A:Global("GetItemClassInfo")
    local n = f and f(classID)
    return n or ("#" .. tostring(classID))
end

-- Befund Protokoll 10.11. (WERT "echt 1"): In der Forever-Rechnung ist Feld 5 ("price") die MENGE (inv.qtyField),
-- der Gesamtpreis steht in e.amount (Feld 4). Sonst Klassik: inv.price = Gesamtpreis.
function Le:SaleGross(e)
    if e.inv and not e.inv.qtyField and e.inv.price then return e.inv.price end
    return e.amount or 0
end

function Le:CompareSale(e, quiet)
    local gross = self:SaleGross(e)
    local unit = gross / math.max(1, e.qty or 1)
    if unit <= 0 then return nil end
    local best
    for _, d in ipairs(DB().entries) do
        if d.kind == "deposit" and d.itemID == e.itemID and d.pred and d.t <= e.t and e.t - d.t <= self.DEV_DAYS * 86400 then
            if not best or d.t > best.t then best = d end
        end
    end
    if not best then return nil end
    e.pred = best.pred
    e.dev = (best.pred - unit) / unit
    e.grp = ItemGroup(e.itemID)
    if A.Diag and not quiet then
        A.Diag:Add("WERT", string.format("Gruppe %s · Item %d · vorhergesagt %d · echt %d · Abweichung %+d %%",
            tostring(e.grp or "?"), e.itemID, best.pred, math.floor(unit + 0.5), math.floor(e.dev * 100 + 0.5)))
    end
    return e.dev
end

-- Abweichung im Zeitraum: total = { n, avg }, groups = { { grp, name, n, avg } } (avg als Anteil, 0.08 = 8 % zu hoch)
function Le:Deviation(key)
    local total, by = { n = 0, sum = 0 }, {}
    for _, e in ipairs(self:GetEntries(key)) do
        if e.kind == "sale" and type(e.dev) == "number" then
            local d = math.max(-1, math.min(3, e.dev))         -- einzelne Ausreisser begrenzen
            total.n, total.sum = total.n + 1, total.sum + d
            local g = e.grp or "?"
            local b = by[g]
            if not b then b = { grp = g, n = 0, sum = 0 }; by[g] = b end
            b.n, b.sum = b.n + 1, b.sum + d
        end
    end
    total.avg = total.n > 0 and total.sum / total.n or nil
    local groups = {}
    for _, b in pairs(by) do
        b.avg = b.sum / b.n
        b.name = self:GroupName(b.grp ~= "?" and b.grp or nil)
        groups[#groups + 1] = b
    end
    table.sort(groups, function(a, b) return a.n > b.n end)
    return total, groups
end

function Le:DeviationText(key)
    local t, groups = self:Deviation(key)
    if not t.avg then return L["Abweichung: noch keine Verkäufe mit Vorhersage."] end
    local function one(avg)
        local pct = math.floor(math.abs(avg) * 100 + 0.5)
        if pct == 0 then return L["genau"] end
        return string.format(avg > 0 and L["%d %% zu hoch"] or L["%d %% zu tief"], pct)
    end
    local parts = {}
    for k = 1, math.min(3, #groups) do parts[#parts + 1] = string.format("%s %s (%d)", groups[k].name, one(groups[k].avg), groups[k].n) end
    return string.format(L["Abweichung: Werte im Schnitt %s (%d Verkäufe)"], one(t.avg), t.n)
        .. (#parts > 0 and ("  ·  " .. table.concat(parts, ", ")) or "")
end

-- ------------------------------------------------------------
-- Einmalige Reparatur alter Verkaufsbuchungen (Anweisung "Buchhaltung Reparatur", 9. Nov. 13:20)
-- Vor 0.65.35 trugen Forever-Verkäufe cut = consignment und refund = deposit der Rechnung (Gebühr doppelt).
-- Nur Forever, nur kind "sale", src "mail", ohne Feld "inv", mit cut > 0 oder refund > 0: Sicherung e.old, dann
-- cut = refund = 0 (amount bleibt). Nichts löschen. Schalter db.ledger.fixL1: läuft nie zweimal.
-- Rückgabe: Anzahl korrigierter Verkäufe (nil = schon gelaufen bzw. kein Forever)
-- ------------------------------------------------------------
function Le:FixL1(quiet)
    local db = DB()
    if not db or db.fixL1 then return nil end
    if not A:IsForever() then return nil end
    local n = 0
    for _, e in ipairs(db.entries or {}) do
        if e.kind == "sale" and e.src == "mail" and e.inv == nil and ((e.cut or 0) > 0 or (e.refund or 0) > 0) then
            e.old = { cut = e.cut, refund = e.refund }
            e.cut, e.refund = 0, 0
            n = n + 1
        end
    end
    db.fixL1 = 1
    if A.Diag then A.Diag:Add("MIGRATION", string.format("fixL1 N=%d", n)) end
    if n > 0 then
        if not quiet then A:Print(string.format(L["Buchhaltung: %d alte Verkäufe korrigiert (Gebühr war doppelt abgezogen)."], n)) end
        A:Fire("LEDGER_CHANGED")
    end
    return n
end
-- ------------------------------------------------------------
-- Buchhaltung wiederherstellen (Anweisung "Gebühren klassisch" D, 9. Nov. 14:30): fixL1 war ein Irrtum. In Forever
-- gilt die klassische Regel (5 % beim Verkauf ab, Einzahlung zurück) und die Rechnung meldet den STÜCKPREIS.
--   D1 Einträge mit e.old (fixL1): cut/refund zurück; Gesamt = cut / 5 % (ungefähr, ±19c) bzw. Preis × Menge
--   D2 Einträge mit inv (0.65.35-0.65.41): Gesamt = Post-Gold + cut - deposit
--   Menge = Gesamt / Stückpreis. Vorher alles in e.old2 sichern. Einmalig (db.fixL2), nur Forever.
-- ------------------------------------------------------------
function Le:FixL2(quiet)
    local db = DB()
    if not db or db.fixL2 then return nil end
    if not A:IsForever() then return nil end
    local n, approx = 0, 0
    for _, e in ipairs(db.entries or {}) do
        if e.kind == "sale" and e.src == "mail" and (e.old or e.inv) then
            e.old2 = { amount = e.amount, cut = e.cut, refund = e.refund, qty = e.qty }
            local unit, total, cut, dep, qty, isApprox
            if e.inv then
                unit = e.inv.price
                cut, dep = e.inv.cut or 0, e.inv.deposit or 0
                if (e.inv.money or 0) > 0 then total = e.inv.money + cut - dep end
                if (e.inv.count or 0) >= 1 then qty = e.inv.count end
            else
                unit = e.amount
                cut, dep = e.old.cut or 0, e.old.refund or 0
                if cut > 0 then total, isApprox = math.floor(cut / 0.05 + 0.5), true end
            end
            if not total then total = (unit or 0) * math.max(e.qty or 1, 1) end
            if not qty and unit and unit > 0 then qty = math.floor(total / unit + 0.5) end
            if not qty or qty < 1 then qty, isApprox = 1, true end
            e.amount, e.cut, e.refund, e.qty = math.floor(total + 0.5), cut, dep, qty
            if isApprox then e.approx = true; approx = approx + 1 end
            n = n + 1
        end
    end
    db.fixL2 = 1
    if A.Diag then A.Diag:Add("MIGRATION", string.format("fixL2 N=%d, ungefähr=%d", n, approx)) end
    if n > 0 then
        if not quiet then A:Print(string.format(L["Buchhaltung: %d Verkäufe neu berechnet (Gebühren wie im klassischen WoW)."], n)) end
        A:Fire("LEDGER_CHANGED")
    end
    return n, approx
end

-- ------------------------------------------------------------
-- fixL3 (Korrektur 15:40): fixL2 und 0.65.42-0.65.44 haben Menge und Stückpreis vertauscht - das Rechnungsfeld
-- "Preis" ist in Forever die MENGE. Einträge mit inv: qty = inv.price; von fixL2 aus e.old berechnete Einträge
-- (vor 0.65.35): qty = der damalige amount (e.old2.amount, das Mengenfeld). amount bleibt. Sicherung e.old3.
-- Einmalig (db.fixL3), nur Forever.
-- ------------------------------------------------------------
function Le:FixL3(quiet)
    local db = DB()
    if not db or db.fixL3 then return nil end
    if not A:IsForever() then return nil end
    local n = 0
    for _, e in ipairs(db.entries or {}) do
        if e.kind == "sale" and e.src == "mail" then
            local q
            if e.inv and (e.inv.count or 0) < 1 and (e.inv.price or 0) >= 1 then
                q = math.floor(e.inv.price + 0.5)
            elseif not e.inv and e.old and e.old2 and (e.old2.amount or 0) >= 1 then
                q = math.floor(e.old2.amount + 0.5)
            end
            if q and q ~= e.qty then
                e.old3 = { qty = e.qty, amount = e.amount }
                e.qty = q
                n = n + 1
            end
        end
    end
    db.fixL3 = 1
    if A.Diag then A.Diag:Add("MIGRATION", string.format("fixL3 N=%d", n)) end
    if n > 0 then
        if not quiet then A:Print(string.format(L["Buchhaltung: %d Verkäufe korrigiert (Menge und Stückpreis)."], n)) end
        A:Fire("LEDGER_CHANGED")
    end
    return n
end

-- fixL4 (D1, 17:30): Doppelbuchung derselben Verkaufsrechnung nach dem Abholen des Goldes (bis 0.65.51: Schlüssel
-- mit Post-Gold). Verkauf mit inv.money == 0, zu dem es eine Buchung desselben Items mit Gold > 0, gleicher Menge
-- (inv.price), gleichem consignment und deposit höchstens 2 Std. entfernt gibt -> aus den Buchungen nehmen und mit
-- Sicherung e.old4 in db.removed aufheben (nichts wegwerfen). Einmalig (db.fixL4), nur Forever.
function Le:FixL4(quiet)
    local db = DB()
    if not db or db.fixL4 then return nil end
    if not A:IsForever() then return nil end
    local paid = {}
    for _, e in ipairs(db.entries or {}) do
        if e.kind == "sale" and e.inv and (e.inv.money or 0) > 0 then paid[#paid + 1] = e end
    end
    local keep, n = {}, 0
    db.removed = db.removed or {}
    for _, e in ipairs(db.entries or {}) do
        local dup = false
        if e.kind == "sale" and e.src == "mail" and e.inv and (e.inv.money or 0) == 0 then
            for _, p in ipairs(paid) do
                if p ~= e and p.inv.price == e.inv.price and (p.inv.cut or 0) == (e.inv.cut or 0) and (p.inv.deposit or 0) == (e.inv.deposit or 0)
                    and math.abs((p.t or 0) - (e.t or 0)) <= 2 * 3600 and ((e.itemID and p.itemID == e.itemID) or p.name == e.name) then
                    dup = true
                    break
                end
            end
        end
        if dup then
            e.old4 = { qty = e.qty, amount = e.amount, cut = e.cut, refund = e.refund }
            e.removedAt = time()
            db.removed[#db.removed + 1] = e
            n = n + 1
        else
            keep[#keep + 1] = e
        end
    end
    if n > 0 then db.entries = keep end
    db.fixL4 = 1
    if A.Diag then A.Diag:Add("MIGRATION", string.format("fixL4 N=%d", n)) end
    if n > 0 then
        if not quiet then A:Print(string.format(L["Buchhaltung: %d doppelte Verkäufe entfernt."], n)) end
        A:Fire("LEDGER_CHANGED")
    end
    return n
end

-- B1 (Befund Buchhaltung 10.11. 09:15): "verkauft 22000" bei EINER Insignien-Kappe - Feld 5 ist bei diesen Rechnungen
-- der PREIS. Feld 5 gilt nur als Menge, wenn es keine Preisangabe ist (nicht = Feld 4, nicht ~ Gesamt bzw. Gesamt / 0,95)
-- und zum Item passt: Einzelstück (nicht stapelbar) -> immer 1; stapelbar -> Stückpreis Gesamt / Feld 5 im Bereich des
-- Marktwerts (1/5 bis 5-fach), ohne Marktwert ab 2 Stück angenommen. Rückgabe: Menge, ungefähr?
Le.realStackSize = A.StackSize
function Le:QtyFromField5(itemID, f5, bid, total)
    f5 = tonumber(f5)
    if not f5 or f5 < 1 then return 1, true end
    f5 = math.floor(f5 + 0.5)
    total = tonumber(total) or tonumber(bid) or 0
    local isPrice = (bid and f5 == bid) or (total > 0 and (math.abs(f5 - total) <= 1 or math.abs(f5 - total / 0.95) <= 1))
    if isPrice then return 1, true end
    -- Stapelgrösse nur, wenn die Item-Info schon bekannt ist (sonst gälte eine Ware als Einzelstück)
    local stack
    if itemID and GetItemInfo then
        local ok, name, _, _, _, _, _, _, st = pcall(GetItemInfo, itemID)
        if ok and name and type(st) == "number" then stack = st end
    end
    if A.StackSize ~= Le.realStackSize and itemID then stack = A:StackSize(itemID) end      -- Testroutine-Seam
    if stack and stack <= 1 then return 1, f5 ~= 1 end
    local mv = itemID and A:GetMarketValue(itemID)
    if total > 0 and mv and mv > 0 then
        local unit = total / f5
        if unit < mv / 5 or unit > mv * 5 then return 1, true end
    end
    return f5, false
end

-- PM1 (Befund 22.11. 08:50): EINE Funktion für die Menge einer Rechnung (Verkauf und Kauf), überall verwendet.
-- Feld 11 (count) >= 1 -> Menge; sonst Forever: Feld 5 (buyout = Menge, wirtschaft-forever §2), plausibel geprüft (QtyFromField5);
-- sonst 1 (ungefähr). Feld 10 (etaMin, Minuten) ist NIE die Menge. Zurück: Menge, ungefähr?
function Le:InvoiceQty(itemID, f5, bid, f11)
    if type(f11) == "number" and f11 >= 1 then return math.floor(f11 + 0.5), false end
    if A:IsForever() then
        local ok, q, ap = pcall(self.QtyFromField5, self, itemID, f5, bid, bid)
        if ok and q and q >= 1 then return q, ap end
    end
    return 1, true
end
-- PM1: gespeicherte Mengen aus Feld 10 (etaMin) bereinigen - einmalig, Zahlen ins Protokoll PM1-BEREINIGT
function Le:FixPM1()
    local db = DB()
    if not db or db.fixPM1 then return nil end
    local nSale, nBuy = 0, 0
    for _, e in ipairs(db.entries or {}) do
        local inv = e.inv
        if e.kind == "sale" and inv and (tonumber(inv.field11) or 0) < 1 and (tonumber(inv.count) or 0) >= 1 and e.qty == inv.count then
            local q = self:InvoiceQty(e.itemID, inv.price, inv.bid, inv.field11)
            if q ~= e.qty then e.oldPM1 = { qty = e.qty }; e.qty = q; nSale = nSale + 1 end
        elseif e.kind == "buy" and e.src == "mail" and (e.qty or 1) > 1 and not e.approx then
            -- Kauf-Rechnungen speicherten die Rohfelder nicht: Menge kann aus Feld 10 stammen -> als "ungefähr" kennzeichnen
            e.approx, e.pm1Unsure = true, true
            nBuy = nBuy + 1
        end
    end
    local SO, M = A.SaleOutcome, A.Mailer
    local nV, nShared, nInv = 0, 0, 0
    local so = A.db and A.db.saleObs
    if so and so.res then
        for id, r in pairs(so.res) do
            for k = #r, 1, -1 do if type(r[k]) == "string" and r[k]:match("^%d+;v;") then table.remove(r, k); nV = nV + 1 end end
            if #r == 0 then so.res[id] = nil end
        end
    end
    if A.db and A.db.saleShared then for _ in pairs(A.db.saleShared) do nShared = nShared + 1 end; A.db.saleShared = nil end
    for _, x in ipairs((A.db and A.db.invoices) or {}) do nInv = nInv + 1 end
    if A.db and A.db.invoices then
        for k, x in ipairs(A.db.invoices) do A.db.invoices[k] = x:gsub(";%d+$", ";0") end      -- Menge unbekannt (Gebühren-Prüfung braucht sie nicht)
    end
    if A.db and A.db.invoiceShared then A.db.invoiceShared = nil end
    db.fixPM1 = 1
    local txt = string.format(
        "Verkäufe Menge korrigiert %d · Kauf-Rechnungen als ungefähr markiert %d · Verkaufsfälle (verkauft) verworfen %d · Gilden-Verkaufsdaten verworfen %d Konten · Rechnungen Menge auf 0 %d",
        nSale, nBuy, nV, nShared, nInv)
    A:NoteFix("PM1", txt, { verkaeufe = nSale, kaeufeUngefaehr = nBuy, faelleVerworfen = nV, gildeKonten = nShared, rechnungen = nInv })   -- PM1-b
    if A.Diag then pcall(A.Diag.Add, A.Diag, "PM1-BEREINIGT", txt) end
    if nSale + nBuy > 0 then A:Fire("LEDGER_CHANGED") end
    return nSale, nBuy, nV, nShared, nInv
end

-- fixL6 (B1c): gespeicherte Verkäufe mit Menge = Preis reparieren (Sicherung e.old5, einmalig, Protokoll REPARATUR-MENGE).
-- Bewusst NICHT "Menge > Stapelgrösse" bei stapelbaren Waren: eine Ware ist EINE Auktion mit beliebiger Menge (162 Staub).
function Le:FixL6()
    local db = DB()
    if not db or db.fixL6 then return nil end
    local n = 0
    for _, e in ipairs(db.entries or {}) do
        if e.kind == "sale" and (e.qty or 1) > 1 then
            local q = e.qty
            local amount = e.amount or 0
            local bad = q == amount or math.abs(q - amount / 0.95) <= 1 or (e.inv and e.inv.bid and q == e.inv.bid)
            if not bad and e.itemID and GetItemInfo then
                local ok, name, _, _, _, _, _, _, st = pcall(GetItemInfo, e.itemID)
                if A.StackSize ~= Le.realStackSize then ok, name, st = true, "x", A:StackSize(e.itemID) end
                if ok and name and type(st) == "number" and st <= 1 then bad = true end
            end
            if bad then
                e.old5 = { qty = q }
                e.qty = 1
                n = n + 1
                if A.Diag then pcall(A.Diag.Add, A.Diag, "REPARATUR-MENGE", string.format("Item %s · alt %d · neu 1", tostring(e.itemID or "?"), q)) end
            end
        end
    end
    db.fixL6 = 1
    A:NoteFix("L6", "Verkäufe Menge = Preis -> 1", { verkaeufe = n })      -- PM1-b
    if n > 0 then A:Fire("LEDGER_CHANGED") end
    return n
end

-- B2b/B2d (Befund 09:15): Erstattung beim Verkauf ohne gebuchte Einzahlung (eingestellt über Blizzards Fenster, ein
-- anderes Addon oder vor dem Einbau) -> Einzahlung = nicht gedeckte Erstattung nachbuchen (src "rechnung", kurz vor dem
-- Verkauf). Netto 0 wie im Spiel. Zuordnung je Item zeitlich: frühere Einzahlungen (30 Tage) decken spätere Erstattungen.
-- Nachgebuchte Einzahlungen zählen nicht als Einstellung (PostRate, PostSizes nehmen nur src "post").
Le.REFUND_WINDOW = 30 * 86400
function Le:CoverRefunds(entries)
    entries = entries or (DB() and DB().entries) or {}
    local byItem = {}
    for _, e in ipairs(entries) do
        if e.itemID and (e.kind == "deposit" or (e.kind == "sale" and (e.refund or 0) > 0)) then
            local l = byItem[e.itemID]
            if not l then l = {}; byItem[e.itemID] = l end
            l[#l + 1] = e
        end
    end
    local added = {}
    for itemID, list in pairs(byItem) do
        table.sort(list, function(a, b) return (a.t or 0) < (b.t or 0) end)
        local pool = {}           -- { t, left }
        for _, e in ipairs(list) do
            if e.kind == "deposit" then
                pool[#pool + 1] = { t = e.t or 0, left = e.amount or 0 }
            else
                local need = e.refund or 0
                for _, d in ipairs(pool) do
                    if need <= 0 then break end
                    if d.left > 0 and (e.t or 0) - d.t <= self.REFUND_WINDOW then
                        local take = math.min(d.left, need)
                        d.left, need = d.left - take, need - take
                    end
                end
                if need > 0 then
                    added[#added + 1] = { kind = "deposit", itemID = itemID, qty = e.qty or 1, auctions = 1, amount = need,
                        src = "rechnung", t = (e.t or time()) - 1 }
                end
            end
        end
    end
    return added
end

function Le:FixL7()
    local db = DB()
    if not db or db.fixL7 then return nil end
    local added = self:CoverRefunds(db.entries)
    for _, d in ipairs(added) do table.insert(db.entries, d) end
    if #added > 0 then table.sort(db.entries, function(a, b) return (a.t or 0) < (b.t or 0) end) end
    db.fixL7 = 1
    if A.Diag then pcall(A.Diag.Add, A.Diag, "MIGRATION", string.format("fixL7 N=%d", #added)) end
    if #added > 0 then A:Fire("LEDGER_CHANGED") end
    return #added
end

-- fixL5 (Protokoll 10.11.): Vorhersage-Abweichung (e.dev) der Forever-Verkäufe wurde mit Feld 5 (= Menge) als Preis
-- gerechnet ("echt 1", +7800 %). Einmal neu rechnen, alte Werte in e.oldDev. Nur Forever, nur Einträge mit inv.qtyField.
function Le:FixL5()
    local db = DB()
    if not db or db.fixL5 then return nil end
    if not A:IsForever() then return nil end
    local n = 0
    for _, e in ipairs(db.entries or {}) do
        if e.kind == "sale" and e.inv and e.inv.qtyField and e.dev ~= nil then
            e.oldDev = e.dev
            e.dev, e.pred = nil, nil
            pcall(self.CompareSale, self, e, true)
            n = n + 1
        end
    end
    db.fixL5 = 1
    if A.Diag then A.Diag:Add("MIGRATION", string.format("fixL5 N=%d", n)) end
    if n > 0 then A:Fire("LEDGER_CHANGED") end
    return n
end

A:On("READY", function()
    -- zuerst die alten Reparaturen (still, falls sie noch nie liefen), dann fixL3, fixL4, fixL5
    pcall(Le.FixL1, Le, true)
    pcall(Le.FixL2, Le, true)
    pcall(Le.FixL3, Le)
    pcall(Le.FixL4, Le)
    pcall(Le.FixL5, Le)
    pcall(Le.FixL6, Le)
    pcall(Le.FixPM1, Le)                                                -- PM1: Mengen aus Feld 10 bereinigen
    pcall(Le.FixL7, Le)
    pcall(Le.BackfillFixLog, Le)                                       -- PM1-b
end)
-- PM1-b: PM1 lief vor 0.65.383 (Zahlen nur im Protokoll, inzwischen weg) -> aus den Buchungen zählen, was noch zählbar ist
function Le:BackfillFixLog()
    local db = DB()
    if not (db and db.fixPM1 and A.db) or (A.db.fixLog and A.db.fixLog.PM1) then return nil end
    local nSale, nBuy = 0, 0
    for _, e in ipairs(db.entries or {}) do
        if e.oldPM1 then nSale = nSale + 1 end
        if e.pm1Unsure then nBuy = nBuy + 1 end
    end
    A:NoteFix("PM1", string.format("nachgetragen aus den Buchungen: Verkäufe Menge korrigiert %d · Kauf-Rechnungen als ungefähr markiert %d (verworfene Verkaufsfälle, Gilden-Daten und Rechnungen sind nicht mehr zählbar)", nSale, nBuy),
        { verkaeufe = nSale, kaeufeUngefaehr = nBuy })
    return nSale, nBuy
end

-- ------------------------------------------------------------
-- Verkaufsdauer (Anweisung "Gebühren klassisch" F1): Einstellen (deposit, src post) und Verkauf (sale) je Item
-- zuordnen - zuerst eingestellt, zuerst verkauft. Abgelaufen = Einstellung ohne Verkauf nach ihrer Laufzeit
-- (e.hours, ohne Angabe 24 Std.). Ab 3 abgeschlossenen Einstellungen:
--   kaum     Anteil abgelaufen >= 60 %
--   schnell  Median bis zum Verkauf <= 12 Std.
--   langsam  sonst
-- Rückgabe: { speed, hours (Median), sold, expired, finished } oder nil (zu wenig eigene Daten)
-- ------------------------------------------------------------
Le.SPEED_DAYS = 30
Le.speedCache = {}
A:On("LEDGER_CHANGED", function() Le.speedCache = {}; Le.rateCache = {} end)
function Le:SellSpeed(itemID, now)
    local db = DB()
    if not (db and itemID) then return nil end
    if not now then
        local c = self.speedCache[itemID]
        local tick = math.floor(time() / 60)
        if c and c.n == #db.entries and c.tick == tick then return c.r end
        local r = self:SellSpeed(itemID, time())
        -- S92-JOBS (0.65.239): Eintrag je Item wiederverwenden (vorher je Item und Minute eine neue Tabelle)
        if c then c.n, c.tick, c.r = #db.entries, tick, r
        else self.speedCache[itemID] = { n = #db.entries, tick = tick, r = r } end
        return r
    end
    local from = now - self.SPEED_DAYS * 86400
    -- S92-JOBS (0.65.239): ohne eigene Einstellung im Zeitraum (fast alle Items) sofort - ohne Hilfstabellen
    local list = self:EntriesFor(itemID)
    local any = false
    for i = 1, #list do
        local e = list[i]
        if e.kind == "deposit" and e.src == "post" and e.itemID == itemID and e.t >= from then any = true; break end
    end
    if not any then return nil end
    local posts, sales = {}, {}
    for _, e in ipairs(list) do
        if e.itemID == itemID and e.t >= from then
            if e.kind == "deposit" and e.src == "post" then posts[#posts + 1] = e
            elseif e.kind == "sale" then sales[#sales + 1] = e end
        end
    end
    if #posts == 0 then return nil end
    table.sort(posts, function(a, b) return a.t < b.t end)
    table.sort(sales, function(a, b) return a.t < b.t end)
    local used, delays = {}, {}
    for _, sl in ipairs(sales) do
        local st = self.SaleTime and self:SaleTime(sl) or sl.t
        for k, p in ipairs(posts) do
            if not used[k] and p.t <= st then
                used[k] = true
                delays[#delays + 1] = (st - p.t) / 3600
                break
            end
        end
    end
    local expired = 0
    for k, p in ipairs(posts) do
        if not used[k] and p.t + (p.hours or 24) * 3600 < now then expired = expired + 1 end
    end
    local finished = #delays + expired
    if finished < 3 then return nil end
    table.sort(delays)
    local median = #delays > 0 and delays[math.floor((#delays + 1) / 2)] or nil
    local speed
    if expired / finished >= 0.6 then speed = "kaum"
    elseif median and median <= 12 then speed = "schnell"
    else speed = "langsam" end
    return { speed = speed, hours = median, sold = #delays, expired = expired, finished = finished }
end

-- SK1-n (VS-1): vorhergesagte vs. tatsächliche Verkaufsdauer je eigener Einstellung (Paarung wie SellSpeed, je Item).
-- Abweichung: verkauft deutlich später (> 2 × Vorhersage + 1 Std.) oder abgelaufen, obwohl in der Laufzeit vorhergesagt.
-- entries: Nahtstelle für die Testroutine. Zurück: n, ok, bad, Beispiele
function Le:SpeedCheck(days, entries, now)
    now = now or time()
    local from = now - (days or 14) * 86400
    local byItem = {}
    for _, e in ipairs(entries or (DB() and DB().entries) or {}) do
        if e.itemID and (e.t or 0) >= from then
            local b = byItem[e.itemID] or { posts = {}, sales = {} }
            byItem[e.itemID] = b
            if e.kind == "deposit" and e.src == "post" then b.posts[#b.posts + 1] = e
            elseif e.kind == "sale" then b.sales[#b.sales + 1] = e end
        end
    end
    local n, ok, bad, ex = 0, 0, 0, {}
    for id, b in pairs(byItem) do
        table.sort(b.posts, function(x, y) return x.t < y.t end)
        table.sort(b.sales, function(x, y) return x.t < y.t end)
        local used = {}
        for _, sl in ipairs(b.sales) do
            local st = self:SaleTime(sl)
            for k, p in ipairs(b.posts) do
                if not used[k] and p.t <= st then used[k] = { h = (st - p.t) / 3600 }; break end
            end
        end
        for k, p in ipairs(b.posts) do
            if p.pred then
                local run = p.hours or 24
                local u = used[k]
                local good, real
                if u then real = u.h; good = real <= 2 * p.pred + 1
                elseif p.t + run * 3600 < now then real = nil; good = p.pred > run
                end
                if good ~= nil then
                    n = n + 1
                    if good then ok = ok + 1 else
                        bad = bad + 1
                        if #ex < 3 then ex[#ex + 1] = string.format("Item %d: vorhergesagt %.1f Std., %s", id, p.pred, real and string.format("verkauft nach %.1f Std.", real) or "abgelaufen") end
                    end
                end
            end
        end
    end
    return n, ok, bad, ex
end

-- H6: Abläufe in Folge je Item (Einstellungen ohne Verkauf bis zum Ablauf, die jüngsten zuerst; laufende zählen
-- nicht, ein Verkauf beendet die Serie). Rückgabe: Anzahl, verlorene Einzahlungen (Kupfer)
function Le:ExpiryStreak(itemID, now)
    now = now or time()
    local from = now - self.SPEED_DAYS * 86400
    -- S92-JOBS (0.65.239): ohne eigene Einstellung im Zeitraum (fast alle Items) sofort - ohne Hilfstabellen
    local list = self:EntriesFor(itemID)
    local any = false
    for i = 1, #list do
        local e = list[i]
        if e.kind == "deposit" and e.src == "post" and e.itemID == itemID and e.t >= from then any = true; break end
    end
    if not any then return 0, 0 end
    local posts, sales = {}, {}
    for _, e in ipairs(list) do
        if e.itemID == itemID and e.t >= from then
            if e.kind == "deposit" and e.src == "post" then posts[#posts + 1] = e
            elseif e.kind == "sale" then sales[#sales + 1] = e end
        end
    end
    if #posts == 0 then return 0, 0 end
    table.sort(posts, function(a, b) return a.t < b.t end)
    table.sort(sales, function(a, b) return a.t < b.t end)
    local used = {}
    for _, sl in ipairs(sales) do
        local st = self.SaleTime and self:SaleTime(sl) or sl.t
        for k, p in ipairs(posts) do
            if not used[k] and p.t <= st then used[k] = true; break end
        end
    end
    local n, lost = 0, 0
    for k = #posts, 1, -1 do
        local p = posts[k]
        local over = p.t + (p.hours or 24) * 3600 < now
        if used[k] then break end
        if over then n = n + 1; lost = lost + (p.amount or 0) end
    end
    return n, lost
end

-- Text "schnell (~3 Std.)" / "langsam (~2 Tage)" / "kaum (läuft oft ab)" und Farbe
-- VS-1 (Feldstudie 15:38: 176 Staub ganz vorne in 7 Min. verkauft, Anzeige "langsam ~13 Std."): Dauer aus dem Platz in der
-- Warteschlange = (Stück vor mir zu meinem Preis + meine Stück) / Absatz je Std. Mein Preis = knapp unter dem günstigsten
-- (A:RealPrice − 1c), also stehen nur billigere vor mir. Zurück: Stunden, Laufzeit (Std.) oder nil (Absatz unbekannt)
function Le:QueueHours(itemID, qty, price)
    if not itemID then return nil end
    if not price then
        local okP, p = pcall(A.RealPrice, A, itemID)
        if okP and type(p) == "number" and p > 1 then price = p - 1 end
    end
    local ok, v = pcall(A.SellOutlook, A, itemID, math.max(1, qty or 1), price)
    if not (ok and v and v.queue and v.perDay and v.perDay > 0) then return nil end
    return (v.queue + math.max(1, qty or 1)) / v.perDay * 24, v.hours or 24, v
end
-- B3 (Befund 21.11. 18:45): Grundlage der Zahl - gemessen (Tage), alle Spieler (Spieler, Tage), eigene Verkäufe; sonst nil
-- (Schätzung "halb verkauft"/Deckel/Faktor -> keine Zahl zeigen)
function Le.QueueBasis(v)
    if not v then return nil end
    local src = v.perDaySource
    if src == "measured" and v.measuredDays then return string.format(L["gemessen %d Tage"], v.measuredDays) end
    if src == "alle" and v.allPlayers and v.measuredDays then return string.format(L["alle Spieler (mind. %d), %d Tage"], v.allPlayers, v.measuredDays) end
    if src == "own" or src == "own>market" then return L["deine Verkäufe"] end
    return nil
end
-- Satz zur Zahl (GRUNDSATZ NACHVOLLZIEHBAR, ≤ 20 Wörter)
function Le.SpeedHelp() return L["Zeit, bis die Angebote vor deinem Preis und deine Stück beim üblichen Absatz verkauft sind."] end
function Le:SellSpeedText(itemID, qty)
    local r = self:SellSpeed(itemID)
    -- VS-1: mit bekanntem Absatz zählt der Platz in der Warteschlange (nur eigene Ware oder mit eigener Verkaufs-Geschichte);
    -- "kaum" aus der eigenen Geschichte (Abläufe) bleibt stärker
    if not (r and r.speed == "kaum") and (r or qty) then
        local h, run, v = self:QueueHours(itemID, qty or 1)
        if h then
            -- B3 (Befund 21.11. 18:45): kein "~"; die Zahl nur mit ihrer Grundlage, sonst nur das Wort
            local basis = Le.QueueBasis(v)
            local function d(x)
                if not basis then return nil end
                local t = x < 1 and L["unter 1 Std."] or (x < 36 and string.format(L["%d Std."], math.floor(x + 0.5)) or string.format(L["%d Tage"], math.floor(x / 24 + 0.5)))
                return t .. ", " .. basis
            end
            local t = d(h)
            local q = { speed = h <= 12 and "schnell" or (h <= run and "normal" or "langsam"), hours = h, queue = true, basis = basis }
            if q.speed == "schnell" then return t and string.format(L["schnell (%s)"], t) or L["schnell"], { 0.2, 0.87, 0.33 }, q end
            if q.speed == "normal" then return t and string.format(L["in der Laufzeit (%s)"], t) or L["in der Laufzeit"], { 0.6, 0.87, 0.33 }, q end
            return t and string.format(L["langsam (%s)"], t) or L["langsam"], { 1, 0.8, 0.2 }, q
        end
    end
    if not r then return nil end
    -- B3: Median der eigenen Verkäufe mit Fallzahl; ohne Median nur das Wort
    local function dur(h)
        if not h then return nil end
        local t
        if h < 1 then t = L["unter 1 Std."]
        elseif h < 36 then t = string.format(L["%d Std."], math.floor(h + 0.5))
        else t = string.format(L["%d Tage"], math.floor(h / 24 + 0.5)) end
        return t .. ", " .. string.format(L["%d Verkäufe"], r.sold or 0)
    end
    if r.speed == "kaum" then return L["kaum (läuft oft ab)"], { 1, 0.33, 0.27 }, r end
    local dt = dur(r.hours)
    if r.speed == "schnell" then return dt and string.format(L["schnell (%s)"], dt) or L["schnell"], { 0.2, 0.87, 0.33 }, r end
    return dt and string.format(L["langsam (%s)"], dt) or L["langsam"], { 1, 0.8, 0.2 }, r
end

-- eigene Verkaufsquote eines Items: Einstellungen (Auktionen, älter als 2 Tage - laufende zählen nicht) und
-- Verkäufe (je Rechnung eine Auktion) der letzten days Tage. Rückgabe: posts, sales
Le.rateCache = {}
function Le:PostRate(itemID, days)
    local db = DB()
    local key = tostring(itemID) .. ":" .. tostring(days or 30)
    local c = db and self.rateCache[key]
    local tick = math.floor(time() / 60)
    if c and c.n == #db.entries and c.tick == tick then return c.posts, c.sales end
    local posts, sales = self:PostRateRaw(itemID, days)
    if db then self.rateCache[key] = { n = #db.entries, tick = tick, posts = posts, sales = sales } end
    return posts, sales
end
function Le:PostRateRaw(itemID, days)
    local now = time()
    local from, till = now - (days or 30) * 86400, now - 2 * 86400
    local posts, sales = 0, 0
    for _, e in ipairs(self:EntriesFor(itemID)) do
        if e.itemID == itemID and e.t >= from then
            if e.kind == "deposit" and e.src ~= "rechnung" and e.t <= till then posts = posts + math.max(1, e.auctions or 1)
            elseif e.kind == "sale" then sales = sales + 1 end
        end
    end
    return posts, sales
end

-- Summen: income (Verkäufe nach AH-Anteil), spent (Käufe), fees (Einstellgebühren minus Erstattungen), profit
-- LG7 (Befund 10.11. 16:00): Käufe, die ins Herstellen gingen. Je Handwerkswaren-Item (Klasse 7), das im Zeitraum gekauft
-- wurde: verbraucht = gekauft − verkauft − jetzt im Lager (Taschen, Bank, AH) − entzaubert, nie unter 0; bewertet zum Ø-Kaufpreis.
-- Rückgabe: Wert, Liste { itemID, qty, value }
function Le:IsReagent(itemID)
    local f = GetItemInfoInstant
    if not (f and itemID) then return false end
    local ok, _, _, _, _, _, classID = pcall(f, itemID)
    return ok and classID == 7 or false
end
function Le:CraftUse(key)
    local bought, sold = {}, {}
    for _, e in ipairs(self:GetEntries(key)) do
        if e.itemID then
            if e.kind == "buy" then
                local b = bought[e.itemID] or { qty = 0, amount = 0 }
                b.qty, b.amount = b.qty + (e.qty or 1), b.amount + (e.amount or 0)
                bought[e.itemID] = b
            elseif e.kind == "sale" then sold[e.itemID] = (sold[e.itemID] or 0) + (e.qty or 1) end
        end
    end
    local okC, counts = pcall(self.StockCounts, self)
    counts = okC and counts or {}
    local total, list = 0, {}
    for id, b in pairs(bought) do
        if b.qty > 0 and self:IsReagent(id) then
            local used = b.qty - (sold[id] or 0) - (counts[id] or 0)
            if used > 0 then
                local v = math.floor(b.amount / b.qty * used + 0.5)
                total = total + v
                list[#list + 1] = { itemID = id, qty = used, value = v }
            end
        end
    end
    table.sort(list, function(a, b) return a.value > b.value end)
    return total, list
end

function Le:Summary(key)
    local s = { income = 0, gross = 0, cut = 0, spent = 0, fees = 0, refunds = 0, sales = 0, buys = 0 }
    for _, e in ipairs(self:GetEntries(key)) do
        if e.kind == "sale" then
            s.gross = s.gross + e.amount
            s.cut = s.cut + (e.cut or 0)
            s.income = s.income + e.amount - (e.cut or 0)
            s.refunds = s.refunds + (e.refund or 0)
            s.sales = s.sales + 1
        elseif e.kind == "buy" then
            s.spent = s.spent + e.amount
            s.buys = s.buys + 1
        elseif e.kind == "deposit" then
            s.fees = s.fees + e.amount
        elseif e.kind == "refund" then
            s.refunds = s.refunds + (e.amount or 0)       -- Erstattung beim Abbrechen (L2)
        end
    end
    s.fees = s.fees - s.refunds
    s.profit = s.income - s.spent - s.fees
    return s
end

-- pro Item: verkauft, Erlös (nach AH-Anteil), gekauft, Kosten, Gebühren, Gewinn
-- ------------------------------------------------------------
-- Ergebnis mit Lager (Anweisung 10.11. 07:05, B2): Kasse + (Lagerwert jetzt - Lagerwert zu Beginn des Zeitraums).
-- Lagerwert = dieser Charakter (Taschen, Bank, eigene laufende Auktionen), bewertet wie "Verkaufen:" (A:RealValue,
-- nach Gebühren, mit Angebot und Absatz). Je Tag und Charakter ein Stand: beim ersten Einloggen des Tages (start) und
-- beim Ausloggen (last) - nur Zahlen, mit den Preisen von DAMALS (nie neu gerechnet).
--   db.ledger.stock[Tag (DayStart)][Charakter-Schlüssel] = { start = Kupfer, last = Kupfer }
-- ------------------------------------------------------------
-- LG1 (Befund 10.11. 14:05): Lager getrennt nach Tasche/Bank und eigenen aktiven Auktionen.
-- bags[id] = Stück in Taschen und Bank; ah[id] = Stück in eigenen laufenden Auktionen; ahValue = Σ Sofortkauf × (1 − AH-Anteil)
function Le:StockParts()
    local bags, ah, ahValue, ahKnown, ahVal = {}, {}, 0, true, {}
    local Ch = A.Chars
    local c = Ch and Ch.Me and Ch:Me()
    if c then
        for id, n in pairs(c.bags or {}) do bags[id] = (bags[id] or 0) + n end
        for id, n in pairs(c.bank or {}) do bags[id] = (bags[id] or 0) + n end
    end
    -- eigene laufende Auktionen: aus der letzten Abfrage, sonst aus den gemerkten Ablaufzeiten
    local keep = 100 - math.floor(A:CutPct() * 100 + 0.5)
    local Se = A.Seller
    local owned = Se and Se.owned
    local list = {}
    local now = time()
    -- X2 (Befund 0.65.86): "abgefragt, leer" (Se.ownedTime gesetzt, z. B. alles verkauft) ist eine echte Antwort -> im AH 0.
    -- Nur "nie abgefragt" (in dieser Sitzung keine Abfrage) fällt auf ownedEnds bzw. das Journal (LG8) zurück.
    local queried = Se and Se.ownedTime ~= nil and type(owned) == "table"
    if owned and #owned > 0 then
        for _, o in ipairs(owned) do if not o.sold and o.itemID then list[#list + 1] = o end end
    end
    if #list == 0 and not queried then
        for _, o in ipairs(A.db and A.db.ownedEnds or {}) do
            if o.itemID and (o.endsAt or 0) > now then list[#list + 1] = o end
        end
    end
    -- LG8 (Befund 10.11. 16:00): ohne Abfrage der eigenen Auktionen (AH zu) und ohne gemerkte Ablaufzeiten zählen die
    -- noch laufenden eigenen Einstellungen aus dem Prognose-Journal (offen, Laufzeit nicht vorbei)
    if #list == 0 and not queried then
        for _, o in ipairs(self:JournalRunning(now)) do list[#list + 1] = o end
    end
    for _, o in ipairs(list) do
        ah[o.itemID] = (ah[o.itemID] or 0) + (o.qty or 1)
        local v
        if o.buyout and o.buyout > 0 then
            v = math.floor(o.buyout * keep / 100)          -- Einzahlung ist schon bezahlt
        else
            local u = self:UnitStockValue(o.itemID)
            if u then v = u * (o.qty or 1) else ahKnown = false end
        end
        if v then ahValue = ahValue + v; ahVal[o.itemID] = (ahVal[o.itemID] or 0) + v end
    end
    return bags, ah, ahValue, ahKnown, ahVal
end

-- LG8: laufende eigene Einstellungen aus dem Prognose-Journal: { itemID, qty, buyout }
function Le:JournalRunning(now)
    local out = {}
    local Fc = A.Forecast
    local f = Fc and Fc.Data and Fc:Data()
    for _, str in ipairs(f and f.list or {}) do
        if str:sub(1, 1) == "P" then
            local e = Fc:Decode(str)
            if e and e.id and not e.r and not e.x and (e.t or 0) <= now and now <= (e.t or 0) + (e.d or 24) * 3600 then
                local q = math.max(1, math.floor(e.q or 1))
                out[#out + 1] = { itemID = e.id, qty = q, buyout = (e.pr or 0) * q }
            end
        end
    end
    return out
end

function Le:StockCounts()
    local bags, ah = self:StockParts()
    local counts = {}
    for id, n in pairs(bags) do counts[id] = (counts[id] or 0) + n end
    for id, n in pairs(ah) do counts[id] = (counts[id] or 0) + n end
    return counts
end

-- Wert je Stück im Lager: realistischer Verkaufspreis (H1, A:ResalePrice) nach Gebühren, mindestens Händlerpreis; nie negativ
Le.UNIT_TTL = 60
Le.unitCache = Le.unitCache or {}
function Le:UnitStockValue(id)
    local now = time()
    local c = self.unitCache[id]
    if c and now - c.t < self.UNIT_TTL then return c.v end
    local p
    if A.ResalePrice then
        local ok, rp = pcall(A.ResalePrice, A, id)
        if ok and type(rp) == "number" then p = rp end
    end
    -- TS111.3 (Lagerwert sprang ×12 in 1½ Std.): Lager mit der Preisregel "erzielbar" - nie über dem Marktwert.
    -- Der Wiederverkaufspreis darf über dem Marktwert liegen (volle Leiter, Absatz), der LAGERWERT nicht: sonst bewertet
    -- ein einzelnes teures Angebot oder eine kurzfristig hohe Leiter den ganzen Bestand.
    local okM, mv = pcall(A.GetMarketValue, A, id)
    mv = okM and type(mv) == "number" and mv > 0 and mv or nil
    if not p then p = mv
    elseif mv and p > mv then p = mv end
    local net
    if p and p > 0 then
        if A:IsForever() then net = p - (A:FeePerPiece(id, p) or 0) else net = p * (1 - A:CutPct()) end
    end
    local okV, vendor = pcall(A.GetVendorPrice, A, id)
    vendor = okV and type(vendor) == "number" and vendor or 0
    local v = math.max(net or 0, vendor)
    if not net and vendor <= 0 then v = nil end
    self.unitCache[id] = { t = now, v = v }
    return v
end

-- Wert einer Stückliste (Taschen/Bank): nie negativ
function Le:ValueOfCounts(counts)
    local total = 0
    for id, n in pairs(counts or {}) do
        if n > 0 then
            local u = self:UnitStockValue(id)
            if u and u > 0 then total = total + u * n end
        end
    end
    return math.floor(total + 0.5)
end

-- Lagerwert jetzt: gesamt, davon im AH
function Le:StockValue()
    local bags, _, ahValue = self:StockParts()
    local inBags = self:ValueOfCounts(bags)
    return inBags + ahValue, ahValue
end

-- Stückliste als Zeichenkette (Stand zu Beginn des Tages, damit er zum heutigen Preis neu bewertet werden kann)
function Le:EncodeCounts(counts)
    local parts = {}
    for id, n in pairs(counts or {}) do if n > 0 then parts[#parts + 1] = id .. ":" .. n end end
    table.sort(parts)
    return table.concat(parts, ",")
end
function Le:DecodeCounts(str)
    local out = {}
    for id, n in (str or ""):gmatch("(%d+):(%d+)") do out[tonumber(id)] = tonumber(n) end
    return out
end

local function CharKey()
    local Ch = A.Chars
    if not (Ch and Ch.Key) then return "?" end
    return (Ch:Key())
end

-- which: "start" (erstes Einloggen des Tages, nur wenn noch keiner da) oder "last" (Ausloggen, immer)
function Le:RecordStock(which, value)
    if A.TestRoutine and A.TestRoutine.running and not self.testStock then return end
    local db = DB()
    if not db then return end
    db.stock = db.stock or {}
    local day = A:DayStart(time())
    local d = db.stock[day] or {}
    db.stock[day] = d
    local key = CharKey()
    local e = d[key] or {}
    d[key] = e
    if which == "start" and e.start then return end
    local ok, v = true, value
    if not v then ok, v = pcall(self.StockValue, self) end
    if not (ok and type(v) == "number") then return end
    e[which] = v
    -- LG1: Stückliste dazu (nur zusätzlich), damit "Ergebnis mit Lager" beide Stände zum heutigen Preis bewertet
    local okC, counts = pcall(self.StockCounts, self)
    if okC and counts then
        if which == "start" then e.startCounts = self:EncodeCounts(counts)
        elseif not e.startCounts and not e.start then e.startCounts = self:EncodeCounts(counts) end
    end
    if which == "last" and not e.start then e.start = v end
    -- alte Tage aufräumen (älter als 60 Tage)
    local limit = day - 60 * 86400
    for k in pairs(db.stock) do if type(k) == "number" and k < limit then db.stock[k] = nil end end
end

-- Lagerwert-Änderung im Zeitraum: Summe über die Charaktere mit einem Stand zu Beginn; nil = noch kein Stand
function Le:StockChange(key)
    local db = DB()
    local stock = db and db.stock
    if not stock then return nil end
    local from = A:DayStart(self:PeriodStart(key))
    local days = {}
    for day in pairs(stock) do if type(day) == "number" and day >= from then days[#days + 1] = day end end
    table.sort(days)
    if key == "today" and days[1] ~= A:DayStart(time()) then return nil end
    local first, latest, firstCounts = {}, {}, {}
    for _, day in ipairs(days) do
        for char, e in pairs(stock[day]) do
            if first[char] == nil and e.start then first[char] = e.start; firstCounts[char] = e.startCounts end
            if e.last or e.start then latest[char] = e.last or e.start end
        end
    end
    local me = CharKey()
    local change, any = 0, false
    local info = { now = 0, inAH = 0, start = 0, oldStart = false }
    for char, start in pairs(first) do
        local now = latest[char]
        if char == me then
            local ok, v, inAH = pcall(self.StockValue, self)
            if ok and type(v) == "number" then now = v; info.now = v; info.inAH = inAH or 0 end
            -- LG1: Stand zu Beginn zum HEUTIGEN Preis (Stückliste), sonst der gespeicherte Wert (ältere Versionen)
            if firstCounts[char] then start = self:ValueOfCounts(self:DecodeCounts(firstCounts[char]))
            else info.oldStart = true end
            info.start = start
        end
        if now then change = change + (now - start); any = true end
    end
    if not any then return nil end
    return change, info
end

A:On("READY", function()
    if C_Timer and C_Timer.After then
        C_Timer.After(10, function() pcall(Le.RecordStock, Le, "start") end)
    else
        pcall(Le.RecordStock, Le, "start")
    end
end)
do
    local f = CreateFrame("Frame")
    f:RegisterEvent("PLAYER_LOGOUT")
    f:SetScript("OnEvent", function() pcall(Le.RecordStock, Le, "last") end)
end

function Le:ByItem(key)
    local by, list = {}, {}
    for _, e in ipairs(self:GetEntries(key)) do
        local id = e.itemID or e.name or "?"
        local r = by[id]
        if not r then
            r = { itemID = e.itemID, name = e.itemID and A:GetItemName(e.itemID) or e.name or "?", soldQty = 0, income = 0,
                  boughtQty = 0, spent = 0, fees = 0 }
            by[id] = r
            table.insert(list, r)
        end
        if e.kind == "sale" then
            r.soldQty = r.soldQty + e.qty
            r.income = r.income + e.amount - (e.cut or 0)
            r.fees = r.fees - (e.refund or 0)
        elseif e.kind == "buy" then
            r.boughtQty = r.boughtQty + e.qty
            r.spent = r.spent + e.amount
        elseif e.kind == "deposit" then
            r.fees = r.fees + e.amount
        elseif e.kind == "refund" then
            r.fees = r.fees - (e.amount or 0)
        end
    end
    -- B3: Stück jetzt (Taschen und Bank dieses Charakters, laufende Auktionen)
    local bags, ah = {}, {}
    pcall(function() bags, ah = self:StockParts() end)
    for _, r in ipairs(list) do
        r.profit = r.income - r.spent - r.fees
        r.stock = r.itemID and bags[r.itemID] or 0          -- LG4: Taschen und Bank
        r.inAH = r.itemID and ah[r.itemID] or 0              -- LG4: eigene laufende Auktionen
    end
    return list
end

-- ------------------------------------------------------------
-- Statistik: Verkaufsquote und beste Verkaufszeit
-- ------------------------------------------------------------
-- Zeitpunkt des Verkaufs: Rechnungen kommen ca. 1 Std. nach dem Verkauf
function Le:SaleTime(e)
    if e.src == "mail" then return e.t - 3600 end
    return e.t
end

-- items: pro Item eingestellt / verkauft / Quote / Ø Preis
-- hours[0..23], weekdays[1..7] (1 = Montag): Anzahl Verkäufe und Erlös
function Le:Stats(key)
    local by, items = {}, {}
    local hours, weekdays = {}, {}
    for h = 0, 23 do hours[h] = { n = 0, income = 0 } end
    for d = 1, 7 do weekdays[d] = { n = 0, income = 0 } end
    for _, e in ipairs(self:GetEntries(key)) do
        if e.kind == "sale" or (e.kind == "deposit" and e.src == "post") then
            local id = e.itemID or e.name or "?"
            local r = by[id]
            if not r then
                r = { itemID = e.itemID, name = e.itemID and A:GetItemName(e.itemID) or e.name or "?", posted = 0, sold = 0, income = 0 }
                by[id] = r
                table.insert(items, r)
            end
            if e.kind == "sale" then
                r.sold = r.sold + e.qty
                r.income = r.income + e.amount - (e.cut or 0)
                local t = self:SaleTime(e)
                local h = tonumber(date("%H", t))
                local wd = tonumber(date("%w", t))       -- 0 = Sonntag
                wd = (wd == 0) and 7 or wd
                hours[h].n = hours[h].n + 1
                hours[h].income = hours[h].income + e.amount - (e.cut or 0)
                weekdays[wd].n = weekdays[wd].n + 1
                weekdays[wd].income = weekdays[wd].income + e.amount - (e.cut or 0)
            else
                r.posted = r.posted + e.qty
            end
        end
    end
    for _, r in ipairs(items) do
        r.rate = (r.posted > 0) and math.min(100, r.sold / r.posted * 100) or nil
        r.avg = (r.sold > 0) and math.floor(r.income / r.sold + 0.5) or nil
    end
    -- beste Stunden (nach Anzahl Verkäufe)
    local best = {}
    for h = 0, 23 do if hours[h].n > 0 then table.insert(best, h) end end
    table.sort(best, function(a, b) return hours[a].n > hours[b].n end)
    return { items = items, hours = hours, weekdays = weekdays, best = best }
end

-- ------------------------------------------------------------
-- Index je itemID (offener Punkt 3, Leistung): die Buchungen eines Items, einmal gebaut und gemerkt. Neu gebaut, wenn
-- sich die Buchhaltung ändert (andere Liste, andere Länge, LEDGER_CHANGED). Le.indexBuilds zählt die Durchläufe.
-- ------------------------------------------------------------
Le.indexBuilds = 0
-- S92-JOBS (0.65.239): ohne Einträge eine gemeinsame leere Liste (vorher je Aufruf eine neue Tabelle, ~8000 je Vollscan);
-- nur lesbar - ein Schreibversuch ist ein Programmfehler und meldet sich
local EMPTY = setmetatable({}, { __newindex = function() error("Le:EntriesFor: leere Liste ist nur lesbar", 2) end })
function Le:EntriesFor(itemID)
    local db = DB()
    if not db then return EMPTY end
    local list = db.entries
    local ix = self.itemIndex
    if not ix or ix.list ~= list or ix.n ~= #list then
        ix = { list = list, n = #list, by = {} }
        for _, e in ipairs(list) do
            local id = e.itemID
            if id then
                local b = ix.by[id]
                if not b then b = {}; ix.by[id] = b end
                b[#b + 1] = e
            end
        end
        self.itemIndex = ix
        self.indexBuilds = self.indexBuilds + 1
    end
    return ix.by[itemID] or EMPTY
end
A:On("LEDGER_CHANGED", function() Le.itemIndex = nil end)

-- Durchschnittlicher Einkaufspreis pro Stück (für die Gewinnrechnung beim Verkaufen)
-- wie oft wurde das Item in den letzten x Tagen verkauft (eigene Verkäufe)
function Le:SoldCount(itemID, days)
    local from = time() - (days or 30) * 86400
    local n = 0
    for _, e in ipairs(self:EntriesFor(itemID)) do
        if e.kind == "sale" and e.itemID == itemID and e.t >= from then n = n + 1 end
    end
    return n
end

-- Stück je Auktion der letzten n eigenen Einstellungen dieses Items (L5, für die Gebühr im Gewinn-Fenster)
function Le:PostSizes(itemID, n)
    local out = {}
    local entries = self:EntriesFor(itemID)
    for i = #entries, 1, -1 do
        local e = entries[i]
        if e.kind == "deposit" and e.src == "post" and e.itemID == itemID and (e.qty or 0) > 0 then
            out[#out + 1] = math.max(1, math.floor((e.qty or 1) / math.max(1, e.auctions or 1) + 0.5))
            if #out >= (n or 10) then break end
        end
    end
    return out
end

-- Ø Verkaufspreis pro Stück (brutto) aus echten Verkäufen der letzten Tage
function Le:AverageSalePrice(itemID, days)
    local from = time() - (days or 14) * 86400
    local qty, sum = 0, 0
    for _, e in ipairs(self:EntriesFor(itemID)) do
        if e.kind == "sale" and e.itemID == itemID and e.t >= from and (e.qty or 0) > 0 then
            qty = qty + e.qty
            sum = sum + (e.amount or 0)
        end
    end
    if qty == 0 then return nil end
    return math.floor(sum / qty + 0.5), qty
end

function Le:AverageBuyPrice(itemID, days)
    local from = time() - (days or 30) * 86400
    local qty, cost = 0, 0
    for _, e in ipairs(self:EntriesFor(itemID)) do
        if e.kind == "buy" and e.itemID == itemID and e.t >= from then
            qty = qty + e.qty
            cost = cost + e.amount
        end
    end
    if qty == 0 then return nil end
    return math.floor(cost / qty + 0.5), qty
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
-- Einstellgebühr beim Einstellen über den Tab Verkaufen
-- (auch ohne Gebühr gebucht: zählt als "eingestellt" für die Verkaufsquote)
A:On("AUCTION_POSTED", function(p)
    if p and p.itemID then
        -- wirklich abgezogen (Gold vorher - nachher), sonst die erwartete Gebühr
        -- VS-1 Selbstkontrolle: vorhergesagte Dauer (Std.) beim Einstellen merken
        local okH, pred = pcall(Le.QueueHours, Le, p.itemID, (p.qty or 1) * (p.commodity and 1 or (p.auctions or 1)), p.unitPrice)
        Le:Add({ kind = "deposit", itemID = p.itemID, qty = p.qty or 1, auctions = p.auctions or 1, hours = p.duration and A.DURATION_HOURS[p.duration] or nil, amount = p.measured or p.deposit or 0, src = "post",
            pred = okH and pred and math.floor(pred * 10 + 0.5) / 10 or nil })
    end
end)

-- L2: Erstattung beim Abbrechen (gemessen: Gold nachher - vorher) buchen
A:On("AUCTION_CANCELLED", function(c)
    if not (c and c.money) then return end
    local function book()
        local now = GetMoney and GetMoney() or 0
        local back = now - c.money
        if back > 0 and back < 100000000 then
            Le:Add({ kind = "refund", itemID = c.itemID, qty = c.qty or 1, amount = back, src = "cancel" })
        end
        if A.Diag then A.Diag:Add("ABBRUCH", string.format("Item %s · Menge %d · Erstattung %d", tostring(c.itemID or "?"), c.qty or 1, math.max(0, back))) end
    end
    if C_Timer and C_Timer.After then C_Timer.After(0.5, book) else book() end
end)

local evt = CreateFrame("Frame")
local function Reg(e) A:RegisterAHEvent(evt, e) end
Reg("MAIL_SHOW")
Reg("MAIL_INBOX_UPDATE")
Reg("AUCTION_HOUSE_PURCHASE_COMPLETED")
Reg("COMMODITY_PURCHASE_SUCCEEDED")

local scanPending = false
evt:SetScript("OnEvent", function(_, event, arg1)
    if event == "MAIL_SHOW" or event == "MAIL_INBOX_UPDATE" then
        -- mehrere Ereignisse kurz hintereinander: einmal lesen
        if scanPending then return end
        scanPending = true
        C_Timer.After(0.5, function()
            scanPending = false
            local ok, err = pcall(Le.ScanInbox, Le)
            if not ok then A:Print(L["Buchhaltung: Fehler beim Lesen der Post: "] .. tostring(err)) end
        end)
    elseif event == "AUCTION_HOUSE_PURCHASE_COMPLETED" or event == "COMMODITY_PURCHASE_SUCCEEDED" then
        Le:OnPurchaseEvent(event, arg1)
    end
end)

-- Kauf über den Sniper oder den Reiter Einkauf: sofort buchen (die Rechnung im Briefkasten wird später zugeordnet).
-- LG5: Bei Auktionen nennt das Ereignis die auctionID - nur den Kauf mit genau dieser auctionID buchen (sonst konnte
-- ein späteres Ereignis einen anderen, nicht gebuchten Kauf erwischen); jede auctionID höchstens einmal.
-- PD1 (Befund PC-Daten 0.65.94): schnelle Sniper-Käufe hintereinander - das Kauf-Ereignis kam erst, als lastPurchase
-- schon der nächste Kauf war ("KAUF-DOPPELT ×14", gebucht erst über die Rechnung, Entzaubern vorher mit Kosten 0).
-- Darum jeden Kauf mit auctionID merken (bis 5 Min.) und das Ereignis über die auctionID zuordnen.
Le.pendingBuys = Le.pendingBuys or {}
local function PIdOf(p) return p and (p.auctionID or (p.listing and p.listing.auctionID)) end
function Le:NotePurchase(p, src)
    if not p then return end
    p.src = p.src or src
    local now = GetTime()
    for k, x in pairs(self.pendingBuys) do if now - (x.noted or 0) > 300 or x.booked then self.pendingBuys[k] = nil end end
    local id = PIdOf(p)
    if id then p.noted = now; self.pendingBuys[tostring(id)] = p end
end
function Le:OnPurchaseEvent(event, auctionID)
    local idOf = PIdOf
    local lp = A.Sniper and A.Sniper.lastPurchase
    local bp = A.Buy and A.Buy.lastPurchase
    local now = GetTime()
    if event == "AUCTION_HOUSE_PURCHASE_COMPLETED" and type(auctionID) == "number" then
        local pend = self.pendingBuys[tostring(auctionID)]
        if pend then
            self.pendingBuys[tostring(auctionID)] = nil
            if not pend.booked and pend.cost then self:BookPurchase(pend, pend.src or "sniper", auctionID) end
            return
        end
        for _, x in ipairs({ { lp, "sniper" }, { bp, "buy" } }) do
            local p = x[1]
            if p and not p.booked and p.cost and tostring(idOf(p)) == tostring(auctionID) then
                self:BookPurchase(p, x[2], auctionID)
                return
            end
        end
        if A.Diag then A.Diag:Add("KAUF-DOPPELT", "Kauf-Ereignis ohne passende eigene Kaufmeldung (Buchung über die Rechnung)") end
        return
    end
    if lp and not lp.booked and lp.cost and now - lp.time < 15 then self:BookPurchase(lp, "sniper") end
    if bp and not bp.booked and bp.cost and now - bp.time < 15 then self:BookPurchase(bp, "buy") end
end

-- TB182-2 (Auswertung Supervisor 18:30, 15.11.: AH gemessen −79g21, gebucht −87g17 -> 7g96 zu viel gebucht, fast nur Käufe).
-- Warenkäufe des Snipers wurden mit dem ANGEFRAGTEN Gesamtpreis (COMMODITY_PRICE_UPDATED) gebucht; was der Server wirklich
-- abzieht, sah die Buchung nie (Verdacht, zu messen: Server nimmt günstigere Einheiten / Teilmenge). Jetzt: BUY_GOLD_WAIT s nach
-- der Bestätigung die Gold-Änderung seit dem Senden messen. "Sauber" (kein anderer eigener Kauf unterwegs, Betrag 50–105 % des
-- angefragten) -> gebucht wird der GEMESSENE Betrag; sonst der angefragte. Jede Abweichung > 1 Kupfer: Diagnosezeile BUY-GOLD.
Le.BUY_GOLD_WAIT = 0.6
function Le:Money()
    if self.testMoney then return self.testMoney() end
    return GetMoney and GetMoney() or nil
end
-- reine Rechnung: welcher Betrag wird gebucht? Rückgabe Betrag, Grund ("gemessen"/"angefragt: …"), gemessen
function Le:MeasuredAmount(lp, moneyNow, clean)
    local cost = lp.cost or 0
    if not (lp.money0 and moneyNow) then return cost, "angefragt: ohne Gold-Messung", nil end
    local paid = lp.money0 - moneyNow
    if not clean then return cost, "angefragt: anderer Kauf unterwegs", paid end
    if paid <= 0 or paid < cost * 0.5 or paid > cost * 1.05 + 1 then return cost, "angefragt: Gold-Änderung unplausibel", paid end
    return paid, "gemessen", paid
end
function Le:OtherBuysInFlight(lp)
    local Sn = A.Sniper
    if Sn and Sn.inFlight then return true end
    if Sn and Sn.lastPurchase and Sn.lastPurchase ~= lp then return true end              -- schon ein neuerer Warenkauf
    if self.lastBookGT and lp.time and self.lastBookGT >= lp.time then return true end     -- anderer Kauf seither gebucht
    if Sn and Sn.itemBuys and #Sn.itemBuys > 0 then return true end
    local Bu = A.Buy
    if Bu and Bu.lastPurchase and Bu.lastPurchase ~= lp and not Bu.lastPurchase.booked and Bu.lastPurchase.time and GetTime() - Bu.lastPurchase.time < 5 then return true end
    return false
end
function Le:BookMeasured(lp)
    if not lp or lp.booked then return false end
    local amount, why, paid = self:MeasuredAmount(lp, self:Money(), not self:OtherBuysInFlight(lp))
    if paid and math.abs(paid - (lp.cost or 0)) > 1 and A.Diag and not (A.InTestRoutine and A:InTestRoutine()) then
        pcall(A.Diag.Add, A.Diag, "BUY-GOLD", string.format("Item %s · %d Stück · angefragt %d · Gold −%d · gebucht %d (%s)",
            tostring(lp.itemID or "?"), lp.qty or 0, lp.cost or 0, paid, amount, why))
    end
    lp.buyGold = { asked = lp.cost, paid = paid, why = why }
    lp.cost = amount
    lp.holdBook = nil
    return self:BookPurchase(lp, "sniper", nil, true)
end

-- Sniper-Warenkauf bestätigt (Sniper.lua PurchaseSucceeded): buchen, falls noch nicht geschehen
A:On("SNIPER_PURCHASE_DONE", function(lp)
    if not lp or lp.booked then return end
    if lp.holdBook then
        C_Timer.After(Le.BUY_GOLD_WAIT, function() pcall(Le.BookMeasured, Le, lp) end)
        return
    end
    Le:BookPurchase(lp, "sniper")
end)

function Le:GetDebugText()
    local db = DB()
    if not db then return "-" end
    return #db.entries .. " Buchungen, Briefkasten-API=" .. ((_G.GetInboxInvoiceInfo and L["ja"]) or L["nein"])
end
