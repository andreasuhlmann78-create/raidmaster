if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Kern.lua (Rechenkern 0.66, Schritt S1: Lernschicht + ehrliche Prüfung)
-- Bauplan anweisung-rechenkern-066.txt (Prüf-Sitzung 14.11. 09:10, freigegeben):
--   L1 Zählen statt annehmen: je Weg und Zelle (z. B. Verkauf: Warengruppe × Preisstufe) Fälle mit Ergebnis zählen.
--   L2 Wenige Fälle -> Richtung Vorwissen: Schätzung = (Treffer + k × Vorwissen) / (Fälle + k), k = 2.
--   L3 Zufallsbeute: Summe / Summe (hier: y ist schon ein Anteil 0..1, Summe der Treffer / Summe der Fälle).
--   L4 Alter: Fälle älter als 14 Tage zählen halb, älter als 30 Tage nicht mehr (Tages-Töpfe, älter -> gelöscht).
--   L5 Speicher: je Zelle und Tag nur zwei Zahlen (Fälle, Treffer) - keine Einzelfälle.
--   P1 Jeder Fall wird VOR dem Zählen vorhergesagt (nur aus Fällen davor = zeitlich getrennt, ohne den eigenen Fall).
--   P2 Grundlinie daneben ("immer nein"); Anzeige als Zahl erst, wenn neu die Grundlinie schlägt UND Brier < 0,20.
--   P3 Testbericht "MARKT-KERN": Treffer neu / Grundlinie / alt, Brier, n, seit wann.
--   P4 7 Tage unter der Grundlinie -> zurück auf das Vorwissen (Zeile rot im Testbericht).
-- Rechnet nur beim Ergebnis eines Falls (selten); Anzeigen lesen nur die Zähler. Testroutine: nie echte Daten.
-- ============================================================
local A = AHAnalyzerPro
local string = A.SafeString or string          -- AHS-OVF1: string.format ohne 32-Bit-Überlauf (gleicher Text darunter)
local CreateFrame, C_Timer = A.OwnCreateFrame or CreateFrame, A.OwnTimer or C_Timer      -- VS-BILD-2 (0.65.320): eigene Skripte/Zeitgeber je Bild messen (nur während einer Vollscan-Messung)
if not (A and A.On) then return end
local K = {}
A.Kern = K

K.PRIOR_K, K.HALF_DAYS, K.MAX_DAYS = 2, 14, 30
K.SHOW_MIN, K.BRIER_MAX, K.P4_DAYS, K.P4_MIN = 30, 0.20, 7, 10
local DAY = 86400

function K:Store()
    if self.testDB then return self.testDB end
    local db = A.db
    if not db then return nil end
    if type(db.kern) ~= "table" then db.kern = { v = 1, c = {}, e = {}, since = time() } end
    db.kern.c, db.kern.e = db.kern.c or {}, db.kern.e or {}
    return db.kern
end
function K.NewDB(t) return { v = 1, c = {}, e = {}, since = t or time() } end
local function Day(t) return A:DayStart(t or time()) end
-- L4: Gewicht eines Tages-Topfs
function K:Weight(day, now)
    local age = (Day(now) - day) / DAY
    if age > self.MAX_DAYS then return 0 end
    if age > self.HALF_DAYS then return 0.5 end
    return 1
end
-- Zähler einer Zelle (gewichtet): Fälle, Treffer
function K:Counts(way, cell, now)
    local st = self:Store()
    local w = st and st.c[way]
    local c = w and w[cell]
    if not c then return 0, 0 end
    local n, y = 0, 0
    for day, v in pairs(c) do
        local g = self:Weight(day, now)
        if g > 0 then n, y = n + g * v[1], y + g * v[2] end
    end
    return n, y
end
-- KERN-T1 (3) Vorwissen-Anschluss: Tabelle von aussen je Weg und Zelle (GoldSentinelMarktTabellen.kern[Weg][Zelle] =
-- { p = Anteil 0..1, n = Fälle }). Fehlt sie (oder Weg/Zelle), bleibt das Vorwissen wie bisher. Gewicht: ihr n, gegen das
-- bisherige Vorwissen mit k = 2 (eigene Zählung geht mit vielen Fällen vor, L2).
function K:TableCell(way, cell)
    local t = self:Tables()
    local w = t and type(t.kern) == "table" and t.kern[way]
    local c = type(w) == "table" and w[cell]
    if type(c) ~= "table" or type(c.p) ~= "number" or type(c.n) ~= "number" or c.n <= 0 then return nil end
    return math.max(0, math.min(1, c.p)), c.n
end
-- L2: Schätzung mit Vorwissen
function K:Estimate(way, cell, prior, now)
    local n, y = self:Counts(way, cell, now)
    prior = prior or 0
    local tp, tn = self:TableCell(way, cell)
    if tp then prior = (tp * tn + self.PRIOR_K * prior) / (tn + self.PRIOR_K) end
    return (y + self.PRIOR_K * prior) / (n + self.PRIOR_K), n
end
local function Bump(t, day, a, b)
    local v = t[day]
    if not v then v = { 0, 0 }; t[day] = v end
    v[1], v[2] = v[1] + a, v[2] + b
    return v
end
function K:Add(way, cell, y, t)
    local st = self:Store()
    if not st then return end
    st.c[way] = st.c[way] or {}
    st.c[way][cell] = st.c[way][cell] or {}
    Bump(st.c[way][cell], Day(t), 1, y)
end
-- Ein Fall mit Ergebnis y (0..1). prior = Vorwissen der Zelle, old = alte Vorhersage (falls bekannt), base = Grundlinie.
-- P1: Vorhersage aus den Zählern VOR diesem Fall; Bewertung je Tag (Brier, Treffer neu/Grundlinie/alt).
function K:Case(way, cell, y, prior, t, old, base)
    if A.InTestRoutine and A:InTestRoutine() and not self.testDB then return nil end
    local st = self:Store()
    if not (st and way and cell and y) then return nil end
    t = t or time()
    y = math.max(0, math.min(1, y))
    local p = self:Estimate(way, cell, prior, t)
    base = base or 0
    st.e[way] = st.e[way] or {}
    local d = Day(t)
    local ev = st.e[way][d]
    if not ev then ev = { 0, 0, 0, 0, 0, 0, 0, 0 }; st.e[way][d] = ev end
    -- ev: 1 n · 2 Brier neu · 3 Brier Grundlinie · 4 Treffer neu · 5 Treffer Grundlinie · 6 n alt · 7 Brier alt · 8 Treffer alt
    local sold = y >= 0.5
    ev[1] = ev[1] + 1
    ev[2] = ev[2] + (p - y) ^ 2
    ev[3] = ev[3] + (base - y) ^ 2
    if (p >= 0.5) == sold then ev[4] = ev[4] + 1 end
    if (base >= 0.5) == sold then ev[5] = ev[5] + 1 end
    if old then
        ev[6], ev[7] = ev[6] + 1, ev[7] + (old - y) ^ 2
        if (old >= 0.5) == sold then ev[8] = ev[8] + 1 end
    end
    self:Add(way, cell, y, t)
    st.first = st.first or {}
    st.first[way] = st.first[way] or d
    self:Prune(t)
    return p
end
-- KERN-T1: viele gleichartige Fälle auf einmal (fremde Auktionen eines Scan-Paars, Gilden-Zähler). n0 Fälle mit Ergebnis 0,
-- n1 Fälle mit Ergebnis y1 (0..1). P1: EINE Vorhersage aus den Zählern VOR dem Stapel. Bewertung wie K:Case, nur summiert:
-- Brier = n0·p² + n1·(p−y1)²; Treffer: p ≥ 0,5 trifft die Fälle mit y ≥ 0,5 usw.; Grundlinie "immer nein" (0).
function K:CaseBatch(way, cell, n0, n1, y1, prior, t)
    if A.InTestRoutine and A:InTestRoutine() and not self.testDB then return nil end
    local st = self:Store()
    n0, n1 = math.max(0, n0 or 0), math.max(0, n1 or 0)
    if not (st and way and cell) or n0 + n1 <= 0 then return nil end
    t = t or time()
    y1 = math.max(0, math.min(1, y1 or 1))
    local p = self:Estimate(way, cell, prior, t)
    st.e[way] = st.e[way] or {}
    local d = Day(t)
    local ev = st.e[way][d]
    if not ev then ev = { 0, 0, 0, 0, 0, 0, 0, 0 }; st.e[way][d] = ev end
    local hit1 = y1 >= 0.5
    ev[1] = ev[1] + n0 + n1
    ev[2] = ev[2] + n0 * p ^ 2 + n1 * (p - y1) ^ 2
    ev[3] = ev[3] + n1 * y1 ^ 2
    ev[4] = ev[4] + ((p >= 0.5) and 0 or n0) + (((p >= 0.5) == hit1) and n1 or 0)
    ev[5] = ev[5] + n0 + (hit1 and 0 or n1)
    st.c[way] = st.c[way] or {}
    st.c[way][cell] = st.c[way][cell] or {}
    Bump(st.c[way][cell], d, n0 + n1, n1 * y1)
    st.first = st.first or {}
    st.first[way] = st.first[way] or d
    self:Prune(t)
    return p
end
-- Bewertung einer Art: alle Tage (≤ MAX_DAYS) oder die letzten days Tage
function K:Eval(way, days, now)
    local st = self:Store()
    local r = { n = 0, bN = 0, bB = 0, hN = 0, hB = 0, nO = 0, bO = 0, hO = 0 }
    local evs = st and st.e[way]
    if not evs then return r end
    local from = Day(now) - ((days or self.MAX_DAYS) - 1) * DAY
    for d, ev in pairs(evs) do
        if d >= from then
            r.n, r.bN, r.bB, r.hN, r.hB = r.n + ev[1], r.bN + ev[2], r.bB + ev[3], r.hN + ev[4], r.hB + ev[5]
            r.nO, r.bO, r.hO = r.nO + (ev[6] or 0), r.bO + (ev[7] or 0), r.hO + (ev[8] or 0)
        end
    end
    return r
end
-- P4: Rückfall aufs Vorwissen, wenn eine Art 7 Tage LANG unter der Grundlinie liegt.
-- KERN-P4-1 (Supervisor 04:58): erst wenn der Weg an ≥ 7 Tagen bewertet ist (erster Bewertungstag ≤ heute − 6) und der BRIER
-- der letzten 7 Tage schlechter ist als der der Grundlinie (mind. P4_MIN Fälle). Vorher: Summe der letzten 7 Tage nach
-- Treffern - ein Weg mit EINEM Bewertungstag stand schon auf "Rückfall".
function K:Fallback(way, now)
    local r = self:Eval(way, self.P4_DAYS, now)
    local st = self:Store()
    local first = st and st.first and st.first[way]
    if not first or first > Day(now) - (self.P4_DAYS - 1) * DAY then return false, r end
    return r.n >= self.P4_MIN and r.bN > r.bB, r
end
-- P2: Zahl zeigen? (genug Fälle, schlägt die Grundlinie, Brier < 0,20, kein Rückfall)
-- KERN-P2-1 (Supervisor 04:58): "schlägt die Grundlinie" nach der GÜTE (Brier), nicht nach Treffern bei 0,5 - bei seltenen
-- Ereignissen (Weg markt, Quote ~5 %) trifft "immer nein" fast immer, eine gut kalibrierte Vorhersage nie >= 0,5. Treffer
-- bleiben als Zahl im Testbericht (P3).
function K:Show(way, now)
    local r = self:Eval(way, nil, now)
    if r.n < self.SHOW_MIN then return false, r, "lernt noch" end
    if self:Fallback(way, now) then return false, r, "Rückfall (7 Tage unter der Grundlinie)" end
    if r.bN >= r.bB then return false, r, "schlägt die Grundlinie nicht" end
    if r.bN / r.n >= self.BRIER_MAX then return false, r, "Brier zu hoch" end
    return true, r, "zeigen"
end
-- Schätzung für die Anzeige: nur wenn Show; sonst nil (Aufrufer bleibt bei der bisherigen Rechnung / grau)
function K:Value(way, cell, prior, now)
    if self:Fallback(way, now) then return nil, "rueckfall" end
    local ok = self:Show(way, now)
    if not ok then return nil, "lernt" end
    return (self:Estimate(way, cell, prior, now))
end
-- alte Tages-Töpfe löschen (> MAX_DAYS), höchstens einmal je Tag
function K:Prune(now)
    local st = self:Store()
    if not st then return end
    local today = Day(now)
    if st.pruned == today then return end
    st.pruned = today
    local limit = today - self.MAX_DAYS * DAY
    for _, w in pairs(st.c) do
        for cell, days in pairs(w) do
            for d in pairs(days) do if d < limit then days[d] = nil end end
            if next(days) == nil then w[cell] = nil end
        end
    end
    for _, evs in pairs(st.e) do for d in pairs(evs) do if d < limit then evs[d] = nil end end end
end
-- L5: Grösse (Zellen, Tages-Töpfe, geschätzte KB)
function K:Size()
    local st = self:Store()
    local cells, pots = 0, 0
    for _, w in pairs(st and st.c or {}) do for _, days in pairs(w) do cells = cells + 1; for _ in pairs(days) do pots = pots + 1 end end end
    for _, evs in pairs(st and st.e or {}) do for _ in pairs(evs) do pots = pots + 1 end end
    return cells, pots, math.floor(pots * 0.12 + cells * 0.08 + 0.5)
end

-- ------------------------------------------------------------
-- Verkauf (S1: zuerst die Verkaufschance, PR2): Zelle = Warengruppe : Preisstufe; Vorwissen = Quote der Gruppe
-- (eigene Zelle "g:<Gruppe>", selbst mit Vorwissen 0,3). Alte Vorhersage = die beim Einstellen gezeigte Chance (e.p).
-- ------------------------------------------------------------
K.SELL_PRIOR = 0.3
function K:SellCell(g, rel)
    local Fc = A.Forecast
    local cls = Fc and Fc.RelClass and Fc:RelClass(rel or 1) or 3
    return (g or "misc") .. ":" .. cls
end
function K:SellPrior(g, now)
    return (self:Estimate("sell", "g:" .. (g or "misc"), self.SELL_PRIOR, now))
end
function K:OnSellCase(e, y, now)
    if not (e and y) then return nil end
    local g = e.g or "misc"
    local prior = self:SellCellPrior(g, e.rel, now)          -- S2/A2: Tabelle der Preisstufe als Vorwissen
    local p = self:Case("sell", self:SellCell(g, e.rel), y, prior, now, e.p, 0)
    -- Gruppen-Quote ebenfalls zählen (nur Zähler, ohne eigene Bewertung)
    if p ~= nil then self:Add("sell", "g:" .. g, y, now) end
    return p
end
-- KERN-S1: späterer Teilverkauf eines schon gezählten Falls (e/u -> t): nur y nachtragen (Fälle +0, keine zweite Bewertung).
-- now = Ende der Laufzeit des Falls (KERN-S1b c: derselbe Tag-Topf, in dem der Fall steht)
function K:OnSellCorrect(e, dy, now)
    if not (e and dy and dy > 0) then return nil end
    if A.InTestRoutine and A:InTestRoutine() and not self.testDB then return nil end
    local st = self:Store()
    if not st then return nil end
    local g = e.g or "misc"
    st.c.sell = st.c.sell or {}
    for _, cell in ipairs({ self:SellCell(g, e.rel), "g:" .. g }) do
        st.c.sell[cell] = st.c.sell[cell] or {}
        Bump(st.c.sell[cell], Day(now), 0, dy)
    end
    return dy
end
-- KERN-S1 einmalig (wie RebuildBuys, S2-B4): Weg "sell" aus dem Journal neu aufbauen und je Fall das gemeldete Ergebnis (ky)
-- im Journal vermerken -> danach genau einmal je Fall. Fälle in Zeitfolge (Ende der Laufzeit) über OnSellCase.
-- KERN-S1b (Supervisor 05:52, HOCH): NUR die Tage, die das Journal abdeckt. Das Journal hält 3000 Einträge; ältere Fälle stehen
-- nur noch im Kern (beim ersten Füllen richtig gezählt). Grenztag G = Tag des Laufzeit-Endes der ältesten abgeschlossenen
-- Einstellung im Journal: Töpfe (Zellen inkl. g:, Bewertung) VOR G bleiben, nur Tage ≥ G werden geleert und neu gezählt;
-- Startdatum = min(behaltener erster Tag, neuer erster Tag). Kennzeichen filledSell3 (0.65.256 lief mit filledSell2 und hat
-- die Tage vor dem Journal schon gelöscht - das lässt sich nicht zurückholen).
function K:RebuildSell(force)
    local st = self:Store()
    local Fc = A.Forecast
    if not (st and Fc and Fc.Store) then return 0 end
    if st.filledSell3 and not force then return 0 end
    local f = Fc:Store()
    if not f then return 0 end
    local limit, cases = time() - self.MAX_DAYS * DAY, {}
    for i, s in ipairs(f.list or {}) do
        if s:sub(1, 1) == "P" then
            local e = Fc:Decode(s)
            local y = e and Fc:PostOutcome(e)
            if y ~= nil and (e.t or 0) >= limit then cases[#cases + 1] = { i = i, e = e, y = math.floor(y * 1000 + 0.5) / 1000, t = (e.t or 0) + (e.d or 24) * 3600 } end
        end
        if i % 200 == 0 then A:Pause() end
    end
    table.sort(cases, function(a, b) if a.t ~= b.t then return a.t < b.t end return a.i < b.i end)
    if #cases > 0 then
        local G = Day(cases[1].t)
        -- Töpfe ab G leeren (Zellen und Bewertung), davor behalten
        for cell, days in pairs((st.c and st.c.sell) or {}) do
            for d in pairs(days) do if d >= G then days[d] = nil end end
            if next(days) == nil then st.c.sell[cell] = nil end
        end
        local evs = st.e and st.e.sell
        local keptFirst
        for d in pairs(evs or {}) do
            if d >= G then evs[d] = nil elseif not keptFirst or d < keptFirst then keptFirst = d end
        end
        st.first = st.first or {}
        if st.first.sell and st.first.sell >= G then st.first.sell = keptFirst end
        for k, c in ipairs(cases) do
            local p = self:OnSellCase(c.e, c.y, c.t)
            if p ~= nil then
                c.e.ky = c.y
                Fc:PutEntry(f, c.i, c.e)
            end
            if k % 50 == 0 then A:Pause() end
        end
        if keptFirst and st.first.sell and keptFirst < st.first.sell then st.first.sell = keptFirst end
    end
    st.filledSell3 = time()
    return #cases
end
-- Verkaufschance für die Anzeige (nil = noch nicht belegt -> bisherige Rechnung)
function K:SellChance(itemID, rel, now)
    local Fc = A.Forecast
    local g = Fc and Fc.Group and Fc:Group(itemID) or "misc"
    return self:Value("sell", self:SellCell(g, rel), self:SellCellPrior(g, rel, now), now)
end
-- einmalig: abgeschlossene Einstellungen der letzten 30 Tage in Zeitfolge nachtragen (P1 bleibt ehrlich: jeder Fall wird
-- nur aus den davor gezählten vorhergesagt). Läuft als Hintergrund-Aufgabe in Portionen.
function K:Backfill()
    local st = self:Store()
    local Fc = A.Forecast
    if not (st and Fc and Fc.Data) or st.filled then return 0 end
    -- KERN-S1: Verkaufsfälle über den Neuaufbau (zählt jeden Fall einmal und vermerkt ky im Journal)
    local n = self:RebuildSell(true)
    st.filled = time()
    self:RebuildBuys()
    return n
end
-- S2-B4 (Prüfung 13:28): Wege buyk/buye (Summe/Summe, 0.65.157) einmal aus dem Journal neu aufbauen - die Zellen werden
-- dafür geleert und alle abgeschlossenen Käufe der letzten 30 Tage in Zeitfolge gezählt (auch die seit 0.65.157 schon
-- live gezählten: so zählt jeder Kauf genau einmal)
function K:RebuildBuys()
    local st = self:Store()
    local Fc = A.Forecast
    if not (st and Fc and Fc.Data) or st.filledBuy2 then return 0 end
    for _, w in ipairs({ "buyk", "buye", "buyp", "buyr" }) do st.c[w] = nil end
    local f = Fc:Data()
    local limit, list = time() - self.MAX_DAYS * DAY, {}
    for i, s in ipairs(f and f.list or {}) do
        if s:sub(1, 1) == "B" then
            local e = Fc:Decode(s)
            if e and e.r == "c" and (e.t or 0) >= limit then list[#list + 1] = e end
        end
        if i % 200 == 0 then A:Pause() end
    end
    table.sort(list, function(a, b) return (a.t or 0) < (b.t or 0) end)
    for i, e in ipairs(list) do
        self:OnBuyCase(e, e.t)
        if i % 50 == 0 then A:Pause() end
    end
    st.filledBuy2 = time()
    self.buyCapCache = nil
    return #list
end
-- S2: abgeschlossene Käufe der letzten 30 Tage einmalig nachtragen (V2)
function K:BackfillBuys()
    local st = self:Store()
    local Fc = A.Forecast
    if not (st and Fc and Fc.Data) or st.filledBuy then return 0 end
    local f = Fc:Data()
    local limit, n = time() - self.MAX_DAYS * DAY, 0
    for i, s in ipairs(f and f.list or {}) do
        if s:sub(1, 1) == "B" then
            local e = Fc:Decode(s)
            if e and e.r == "c" and (e.t or 0) >= limit then self:OnBuyCase(e, e.t); n = n + 1 end
        end
        if i % 200 == 0 then A:Pause() end
    end
    st.filledBuy = time()
    return n
end
A:On("READY", function()
    if A.InTestRoutine and A:InTestRoutine() then return end
    local st = K:Store()
    if st and st.filled and (not st.filledBuy2 or not st.filledSell3) and A.Job then
        A:Job("kern:backfill", function()
            if not st.filledBuy2 then local ok, err = A:PCall(K.RebuildBuys, K); if not ok and A.Diag then pcall(A.Diag.Add, A.Diag, "FEHLER", "kern:rebuild: " .. tostring(err)) end end
            -- KERN-S1: Weg "sell" einmalig neu aus dem Journal (falsche Zähler sonst 30 Tage)
            if not st.filledSell3 then
                local ok, n = A:PCall(K.RebuildSell, K)
                if A.Diag then pcall(A.Diag.Add, A.Diag, ok and "KERN" or "FEHLER", ok and string.format("Weg sell neu aufgebaut: %d Fälle (KERN-S1)", n or 0) or ("kern:rebuild-sell: " .. tostring(n))) end
            end
        end)
    elseif st and not st.filled and A.Job then
        A:Job("kern:backfill", function() local ok, err = A:PCall(K.Backfill, K); if not ok and A.Diag then pcall(A.Diag.Add, A.Diag, "FEHLER", "kern:backfill: " .. tostring(err)) end end)
    end
end)

-- P3: Testbericht-Zeilen "MARKT-KERN"
local function Pct(x) return x and string.format("%d %%", math.floor(x * 100 + 0.5)) or "-" end
-- lohnt (wahlweise): schon fertig berechneter LohntCheck (acc.done), z. B. in Portionen aus der Testroutine; sonst hier gerechnet.
function K:ReportLines(out, fields, lohnt)
    local st = self:Store()
    local names = { sell = "Verkaufschance", markt = "Markt (fremde Auktionen, KERN-T1)", gilde = "Gilde (geteilte Zähler, KERN-T1)" }
    for _, way in ipairs({ "sell", "markt", "gilde" }) do
        local show, r, why = self:Show(way)
        local fb, r7 = self:Fallback(way)
        local first = st and st.first and st.first[way]
        if r.n > 0 then
            out[#out + 1] = string.format("  MARKT-KERN %s: Treffer neu %s / Grundlinie (immer nein) %s / alt %s · Brier neu %.3f / Grundlinie %.3f / alt %s · n %d · seit %s · Anzeige: %s%s",
                names[way], Pct(r.hN / r.n), Pct(r.hB / r.n), r.nO > 0 and Pct(r.hO / r.nO) or "-", r.bN / r.n, r.bB / r.n,
                r.nO > 0 and string.format("%.3f", r.bO / r.nO) or "-", r.n, first and date("%d.%m.", first) or "-",
                show and "Zahl" or ("grau – " .. why), fb and string.format(" |cffff5544· P4 RÜCKFALL: 7 Tage unter der Grundlinie (Brier %.3f/%.3f)|r", r7.bN / math.max(1, r7.n), r7.bB / math.max(1, r7.n)) or "")
        else
            out[#out + 1] = string.format("  MARKT-KERN %s: noch keine Fälle (lernt noch)", names[way])
        end
        if fields then fields["kern_" .. way] = string.format("%d/%d/%d/%s", r.n, r.hN, r.hB, show and "zahl" or "grau") end
    end
    pcall(self.ReportMarket, self, out, fields)
    pcall(self.ReportS2, self, out, fields)
    if A.Ketten and A.Ketten.ReportLines then pcall(A.Ketten.ReportLines, A.Ketten, out, fields) end      -- S3b: Ketten nur im Bericht
    local okL, lc = true, lohnt
    if not (type(lc) == "table" and lc.done) then okL, lc = pcall(self.LohntCheck, self, 60) end
    if okL and lc then
        local ways = {}
        for k, v in pairs(lc.byWay) do ways[#ways + 1] = k .. " " .. v end
        table.sort(ways)
        out[#out + 1] = string.format("  MARKT-KERN Lohnt bis (S3, ein Wert über alle Wege): %d Items · bester Weg %s · Anzeigen gleich %d / mit anderer Zahl %d%s",
            lc.n, #ways > 0 and table.concat(ways, ", ") or "-", lc.same, lc.other, #lc.ex > 0 and (" (" .. table.concat(lc.ex, " | ") .. ")") or "")
        if fields then fields.kern_lohnt = string.format("%d/%d/%d", lc.n, lc.same, lc.other) end
    end
    local cells, pots, kb = self:Size()
    out[#out + 1] = string.format("  MARKT-KERN Speicher: %d Zellen · %d Tages-Töpfe · ~%d KB (Ziel < 300 KB)", cells, pots, kb)
end

-- ------------------------------------------------------------
-- KERN-T1 (1): Weg "markt" = fremde Auktionen aus aufeinanderfolgenden Vollscans (VS:MarketPairs). Eigener Weg mit eigener
-- Grundlinie und eigenem Brier (P1–P4), nie mit "sell" vermischt. Zelle wie beim Verkauf (Warengruppe : Preisstufe).
-- Ergebnis eines vorzeitig verschwundenen Angebots = Anteil "verkauft" der Gruppe, GEEICHT an den eigenen Auktionen
-- (Journal: vorzeitig weg = verkauft "s" oder abgebrochen "c"; Schätzung (s + k·f0) / (s + c + k), k = 2, f0 = Gegenprobe
-- der Vollscans VS:CancelFactor, ohne genug Fälle 0,5). Nie die pauschale Annahme "halb verkauft".
-- Fall-Länge: Scan-Abstand 5–60 Min. (VS.MKT_DMIN/MAX); die Summe der Abstände wird mitgezählt (mittlere Fall-Länge),
-- damit die Schätzung als Vorwissen auf 2 Std. umgerechnet werden kann: p2 = 1 − (1 − p)^(7200 / Ø Länge).
-- Unterboten (M-WL1): eigene Zähler "marktu" je Zelle :u1 / :u0 (nur Zähler, keine Anzeige).
-- Erst wenn "markt" die eigene Prüfung besteht (K:Show), ist er Vorwissen (L2) der eigenen Verkaufs-Zellen.
-- ------------------------------------------------------------
K.CAL_DAYS, K.CAL_TTL = 30, 3600
function K:Calibration(g, now)
    now = now or time()
    self.calCache = self.calCache or {}
    local c = self.calCache
    if not c.t or now - c.t > self.CAL_TTL or self.calDirty then
        c.t, c.by, self.calDirty = now, {}, nil
        local Fc = A.Forecast
        local f = Fc and Fc.Data and Fc:Data()
        local from = now - self.CAL_DAYS * 86400
        for _, s in ipairs(f and f.list or {}) do
            if s:sub(1, 1) == "P" then
                local okD, e = pcall(Fc.Decode, Fc, s)
                if okD and e and (e.t or 0) >= from and (e.r == "s" or e.r == "c") then
                    local x = c.by[e.g or "misc"]
                    if not x then x = { s = 0, c = 0 }; c.by[e.g or "misc"] = x end
                    if e.r == "s" then x.s = x.s + 1 else x.c = x.c + 1 end
                end
            end
        end
    end
    local VS = A.FullScan
    local f0 = 0.5
    if VS and VS.CancelFactor then
        local okF, ff, gone, src = pcall(VS.CancelFactor, VS, nil, g or "misc")   -- G10: je Gruppe ab 30 echten Fällen
        if okF and ff and ((gone or 0) >= 5 or src == "echt") then f0 = ff end
    end
    local x = c.by[g or "misc"] or { s = 0, c = 0 }
    return (x.s + self.PRIOR_K * f0) / (x.s + x.c + self.PRIOR_K), x.s + x.c, f0
end
function K:MarketBatch(itemID, rel, nStay, nGone, undercut, d, now)
    local Fc = A.Forecast
    local g = Fc and Fc.Group and Fc:Group(itemID) or "misc"
    local cell = self:SellCell(g, rel)
    local f = self:Calibration(g, now)
    local prior = self:Estimate("markt", "g:" .. g, self.SELL_PRIOR * 0.25, now)
    local p = self:CaseBatch("markt", cell, nStay, nGone, f, prior, now)
    if p == nil then return nil end
    local n = nStay + nGone
    local st = self:Store()
    st.c.markt["g:" .. g] = st.c.markt["g:" .. g] or {}
    Bump(st.c.markt["g:" .. g], Day(now), n, nGone * f)       -- Gruppen-Zelle (nur Zähler, Vorwissen der Zellen)
    st.mktLen = st.mktLen or { 0, 0 }
    st.mktLen[1], st.mktLen[2] = st.mktLen[1] + n, st.mktLen[2] + n * d
    st.c.marktu = st.c.marktu or {}
    local uc = cell .. (undercut and ":u1" or ":u0")
    st.c.marktu[uc] = st.c.marktu[uc] or {}
    Bump(st.c.marktu[uc], Day(now), n, nGone * f)
    return p
end
-- Testbericht: Fälle/Tag je Weg, geeichter Faktor je Gruppe, Unterboten-Vergleich, Fall-Länge
function K:ReportMarket(out, fields)
    local st = self:Store()
    if not st then return end
    local today = Day(time())
    local function perDay(way)
        local s, days = 0, {}
        for cell, pots in pairs(st.c[way] or {}) do
            if not cell:find("^g:") and not cell:find(":g:", 1, true) then
                for d, v in pairs(pots) do if d > today - 7 * DAY then s = s + v[1]; days[d] = true end end
            end
        end
        local nd = 0
        for _ in pairs(days) do nd = nd + 1 end
        return nd > 0 and s / nd or 0, nd
    end
    local ps, ns = perDay("sell")
    local pm, nm = perDay("markt")
    local pgl, ngl = perDay("gilde")
    out[#out + 1] = string.format("  MARKT-KERN Fälle je Tag (letzte 7 Tage): eigen %.1f (%d Tage) · Markt %.1f (%d Tage) · Gilde %.1f (%d Tage)", ps, ns, pm, nm, pgl, ngl)
    -- Phase 2.4/2.5: Datenstufe "alle Spieler" (Teil alle der Markt-Tabellen, Masterplan E)
    local t = self:Tables()
    local al = t and type(t.alle) == "table" and t.alle
    if al and al.v == 1 then
        local function count(part)
            local n, q, m = 0, 0, 0
            for _, r in pairs(type(part) == "table" and part or {}) do
                n = n + 1
                if type(r) == "table" and type(r[4]) == "number" and r[4] > q then q = r[4] end
                if type(r) == "table" and type(r[2]) == "number" then m = m + 1 end
            end
            return n, q, m
        end
        local nH, qH, mH = count(al.H)
        local nA, qA, mA = count(al.A)
        local f = tostring(A.marketKey or A:MarketKey(false)):match("|(%a+)$") or "?"
        out[#out + 1] = string.format("  MARKT-KERN alle Spieler (Vorwissen Absatz, k = 2): Horde %d Items (%d mit Absatz, mind. %d Spieler) · Allianz %d Items (%d mit Absatz, mind. %d Spieler) · %s Tage · eigene Seite %s",
            nH, mH, qH, nA, mA, qA, tostring(al.tage or "?"), f)
    else
        out[#out + 1] = "  MARKT-KERN alle Spieler: Teil \"alle\" noch nicht in der Markt-Tabelle (kommt mit der ersten Tagesdatei der Sammelstelle)"
    end
    local cal = {}
    for _, g in ipairs({ "de", "cloth", "leather", "metal", "herb", "consum", "gear2", "gear3", "misc" }) do
        local f, n = self:Calibration(g)
        cal[#cal + 1] = string.format("%s %.2f (n %d)", g, f, n)
    end
    local _, _, f0 = self:Calibration("misc")
    out[#out + 1] = "  MARKT-KERN geeichter Anteil verkauft je Gruppe (eigene vorzeitig weg, k = 2, Vorwissen " .. string.format("%.2f", f0) .. "): " .. table.concat(cal, " · ")
    local u = { [0] = { 0, 0 }, [1] = { 0, 0 } }
    for cell, pots in pairs(st.c.marktu or {}) do
        local k = cell:sub(-1) == "1" and 1 or 0
        for _, v in pairs(pots) do u[k][1], u[k][2] = u[k][1] + v[1], u[k][2] + v[2] end
    end
    local len = self:MarketLen()
    out[#out + 1] = string.format("  MARKT-KERN Wettlauf (M-WL1, fremde Auktionen): unterboten %s verkauft (n %d) · nicht unterboten %s (n %d) · Ø Fall-Länge %s",
        u[1][1] > 0 and Pct(u[1][2] / u[1][1]) or "-", u[1][1], u[0][1] > 0 and Pct(u[0][2] / u[0][1]) or "-", u[0][1],
        len and string.format("%d Min.", math.floor(len / 60 + 0.5)) or "-")
    if fields then fields.kern_markt_tag = string.format("%.1f/%.1f/%.1f", ps, pm, pgl) end
end
-- ------------------------------------------------------------
-- KERN-T1 (2) Gilden-Sync der Fälle (GoldSentinelSync, Nachricht "K", wie die Entzauber-Ergebnisse): nur Zähler je Weg,
-- Zelle und Tag (Fälle n, Treffer y in Zehnteln), keine Einzelfälle, keine Namen (Absender nur als Kürzel). Jede Sendung
-- enthält die kompletten Zähler der letzten SHARE_DAYS Tage; der Empfänger zählt nur den ZUWACHS gegenüber der letzten
-- Sendung dieses Absenders (nichts doppelt). Fremde Zähler = eigener Weg "gilde" (Zelle "<Weg>:<Zelle>") mit eigener
-- Grundlinie und P1–P4 (je Zuwachs EINE Vorhersage vorher, K:CaseBatch). Erst nach bestandener Prüfung Vorwissen der
-- eigenen Verkaufs-Zellen (vor "markt": gleiche Grösse "verkauft in der Laufzeit"). Drossel und Kampf: GoldSentinelSync.
-- ------------------------------------------------------------
K.SHARE_DAYS, K.SHARE_MAX_N, K.SHARE_EVERY, K.SHARE_SENDERS = 14, 5000, 1800, 30
local SHARE_WAYS = { s = "sell", m = "markt" }
local SHARE_CODE = { sell = "s", markt = "m" }
local SHARE_GROUPS = { de = true, cloth = true, leather = true, metal = true, herb = true, consum = true, gear2 = true, gear3 = true,
    misc = true }                                   -- = Warengruppen von Fc:Group
function K:EncodeShare(now)
    local S = A.Sync
    local Enc = S and S.Enc
    local st = self:Store()
    if not (Enc and st) then return {} end
    local today = Day(now)
    local parts = {}
    for way, code in pairs(SHARE_CODE) do
        for cell, pots in pairs(st.c[way] or {}) do
            local g, cls = cell:match("^(%a+%d?):(%d)$")
            if g and SHARE_GROUPS[g] then
                for d, v in pairs(pots) do
                    if d > today - self.SHARE_DAYS * DAY and v[1] >= 1 then
                        local n = math.min(math.floor(v[1] + 0.5), self.SHARE_MAX_N)
                        local y = math.min(math.floor(v[2] * 10 + 0.5), n * 10)
                        parts[#parts + 1] = code .. "." .. g .. "." .. cls .. "." .. Enc(math.floor(d / DAY)) .. "~" .. Enc(n) .. "~" .. Enc(y)
                    end
                end
            end
        end
    end
    table.sort(parts)
    return parts
end
function K:Broadcast(now)
    local S = A.Sync
    if not (S and S.IsEnabled and S:IsEnabled() and S:IsConnected() and S.Enqueue) then return false end
    if A.InTestRoutine and A:InTestRoutine() then return false end
    now = now or time()
    local parts = self:EncodeShare(now)
    if #parts == 0 then return false end
    self.lastShared = now
    local head = "K:" .. S.Enc(now) .. ":"
    local chunk, size = {}, #head
    for _, p in ipairs(parts) do
        if size + #p + 1 > S.MAX_MSG and #chunk > 0 then
            S.Enqueue(head .. table.concat(chunk, ";"))
            chunk, size = {}, #head
        end
        chunk[#chunk + 1] = p
        size = size + #p + 1
    end
    if #chunk > 0 then S.Enqueue(head .. table.concat(chunk, ";")) end
    return true
end
-- nach neuen Fällen: höchstens alle SHARE_EVERY Sekunden teilen
function K:MaybeShare(now)
    now = now or time()
    if self.lastShared and now - self.lastShared < self.SHARE_EVERY then return false end
    return self:Broadcast(now)
end
function K:HandleRequest()
    if self.lastShared and time() - self.lastShared < self.SHARE_EVERY then return end
    if C_Timer and C_Timer.After then C_Timer.After(10 + math.random() * 25, function() K:Broadcast() end) end
end
K.shareRate = K.shareRate or {}
-- Teilstücke eines Absenders (eine Sendung kann aus mehreren Nachrichten mit gleicher Zeit t bestehen)
function K:HandleShared(sender, t, payload, now)
    if A.InTestRoutine and A:InTestRoutine() and not self.testDB then return 0 end
    local st = self:Store()
    local Dec = A.Sync and A.Sync.Dec
    if not (st and Dec and sender and type(payload) == "string") then return 0 end
    now = now or time()
    if not t or t > now + 300 or t < now - self.MAX_DAYS * DAY then return 0 end
    local D = A.Disenchant
    if D and D.IsOwnChar and D:IsOwnChar(sender) then return 0 end      -- eigene Twinks zählen nicht als Gilde
    local sk = (D and D.SenderKey) and D:SenderKey(sender) or "#?"
    -- höchstens eine Sendung je Absender und Minute (Teilstücke derselben Sendung = gleiches t)
    local r = self.shareRate[sk]
    if r and r.t ~= t and now - r.at < 60 then return 0 end
    self.shareRate[sk] = { t = t, at = now }
    st.sh = st.sh or {}
    local rec = st.sh[sk]
    if not rec then
        local nS = 0
        for _ in pairs(st.sh) do nS = nS + 1 end
        if nS >= self.SHARE_SENDERS then return 0 end
        rec = { t = 0, c = {} }
        st.sh[sk] = rec
    end
    local today = Day(now)
    local taken = 0
    for part in payload:gmatch("[^;]+") do
        local code, g, cls, dEnc, nEnc, yEnc = part:match("^(%a)%.(%a+%d?)%.(%d)%.(%w+)~(%w+)~(%w+)$")
        local way = code and SHARE_WAYS[code]
        local dn, n, y10 = Dec(dEnc or ""), Dec(nEnc or ""), Dec(yEnc or "")
        cls = tonumber(cls)
        if way and g and SHARE_GROUPS[g] and cls and cls >= 1 and cls <= 5 and dn and n and y10 and n > 0
            and n <= self.SHARE_MAX_N and y10 >= 0 and y10 <= n * 10 then
            local d = dn * DAY
            if d <= today and d > today - self.MAX_DAYS * DAY then
                local key = code .. "." .. g .. "." .. cls .. "." .. dn
                local old = rec.c[key]
                local dN, dY = n - (old and old[1] or 0), (y10 - (old and old[2] or 0)) / 10
                if dN > 0 and dY >= 0 and dY <= dN then
                    local cell = way .. ":" .. g .. ":" .. cls
                    local prior = self:Estimate("gilde", way .. ":g:" .. g, self.SELL_PRIOR, now)
                    self:CaseBatch("gilde", cell, dN - dY, dY, 1, prior, math.min(now, d + DAY - 1))
                    st.c.gilde = st.c.gilde or {}
                    st.c.gilde[way .. ":g:" .. g] = st.c.gilde[way .. ":g:" .. g] or {}
                    Bump(st.c.gilde[way .. ":g:" .. g], Day(math.min(now, d + DAY - 1)), dN, dY)
                end
                rec.c[key] = { n, y10 }
                taken = taken + 1
            end
        end
    end
    if taken > 0 then
        rec.t = now
        for key in pairs(rec.c) do
            local dn = tonumber(key:match("%.(%d+)$"))
            if dn and dn * DAY <= today - self.MAX_DAYS * DAY then rec.c[key] = nil end
        end
    end
    return taken
end
-- Vorwissen aus "gilde" (Verkauf) für eine eigene Verkaufs-Zelle, nur nach bestandener Prüfung
function K:GuildPrior(g, rel, now)
    if not self:Show("gilde", now) then return nil end
    local cell = "sell:" .. self:SellCell(g, rel)
    local n = self:Counts("gilde", cell, now)
    if n <= 0 then return nil end
    return (self:Estimate("gilde", cell, (self:Estimate("gilde", "sell:g:" .. g, self.SELL_PRIOR, now)), now)), n
end

-- mittlere Fall-Länge (Sekunden) der "markt"-Fälle
function K:MarketLen()
    local st = self:Store()
    local m = st and st.mktLen
    if not (m and m[1] > 0) then return nil end
    return m[2] / m[1]
end
-- Vorwissen aus "markt" für eine eigene Verkaufs-Zelle (2 Std.), nur wenn "markt" die eigene Prüfung besteht
function K:MarketPrior(g, rel, now)
    if not self:Show("markt", now) then return nil end
    local len = self:MarketLen()
    if not len or len <= 0 then return nil end
    local p = self:Estimate("markt", self:SellCell(g, rel), (self:Estimate("markt", "g:" .. g, 0, now)), now)
    local n = self:Counts("markt", self:SellCell(g, rel), now)
    return 1 - (1 - math.max(0, math.min(1, p))) ^ (7200 / len), n
end

-- ------------------------------------------------------------
-- S2 / A2: Markt-Tabellen von aussen (GoldSentinelMarktTabellen.lua, täglich von der Prüf-Sitzung, im ZIP). Nur
-- Nachschlagen beim Gebrauch, nie rechnen. Fehlt die Tabelle oder ein Teil: alles läuft ohne (Vorwissen wie bisher).
-- ------------------------------------------------------------
function K:Tables()
    if self.tablesOverride ~= nil then return self.tablesOverride or nil end
    local t = _G.GoldSentinelMarktTabellen
    if type(t) ~= "table" or t.v ~= 1 then return nil end
    return t
end
-- Phase 2 / Masterplan E (Supervisor 20:52): Teil "alle" = Daten ALLER einsendenden Spieler (Bot-Sammelstelle) je Fraktion
-- (H/A) und Item: preis, absatzMin, absatzMax (Abgänge je Tag als Spanne, nil = nicht gemessen), quellen (Spieler, Untergrenze),
-- tage, scans. Nur Vorwissen (L2, k = 2) - eigene Zählung geht vor. Neutrales Auktionshaus: keine Daten (Teil nur H/A).
K.ALL_FIELDS = { "preis", "absatzMin", "absatzMax", "quellen", "tage", "scans" }
function K:AllItem(itemID)
    local t = self:Tables()
    local al = t and type(t.alle) == "table" and t.alle
    itemID = tonumber(itemID)
    if not (al and al.v == 1 and itemID) then return nil end
    local f = tostring(A.marketKey or A:MarketKey(false)):match("|(%a+)$")
    local part = (f == "Horde" and al.H) or (f == "Alliance" and al.A) or nil
    local r = type(part) == "table" and part[itemID]
    if type(r) ~= "table" then return nil end
    local idx = {}
    for i, name in ipairs(type(al.felder) == "table" and al.felder or self.ALL_FIELDS) do idx[name] = i end
    local function g(name)
        local i = idx[name]
        local v = i and r[i]
        return type(v) == "number" and v or nil
    end
    return { preis = g("preis"), min = g("absatzMin"), max = g("absatzMax"), quellen = g("quellen") or 0, tage = g("tage") or 0,
             scans = g("scans") or 0 }
end

-- Tabelle "verkauf": Quote der Preisstufe (gleiche Grenzen wie Fc.REL_B) einer Warengruppe, mit n
function K:TableSell(g, rel)
    local t = self:Tables()
    local rows = t and type(t.verkauf) == "table" and t.verkauf[g]
    if type(rows) ~= "table" then return nil end
    rel = rel or 1
    for _, r in ipairs(rows) do
        if type(r) == "table" and r.bis and rel <= r.bis then return r.quote, r.n or 0 end
    end
    return nil
end
-- Vorwissen einer Verkaufs-Zelle: Tabelle (Preisstufe) mit ihrem n, sonst die gezählte Gruppen-Quote
function K:SellCellPrior(g, rel, now)
    local gp = self:SellPrior(g, now)
    -- KERN-T1 (1): fremde Auktionen (Weg "markt", nur nach bestandener eigener Prüfung) vor der Gruppen-Quote
    local okM, mp = pcall(self.MarketPrior, self, g, rel, now)
    if okM and mp then gp = mp end
    local okG, gpr = pcall(self.GuildPrior, self, g, rel, now)              -- KERN-T1 (2): Gilde vor Markt
    if okG and gpr then gp = gpr end
    local q, n = self:TableSell(g, rel)
    if q and n and n > 0 then return (q * n + self.PRIOR_K * gp) / (n + self.PRIOR_K) end
    return gp
end

-- ------------------------------------------------------------
-- S2 / V2: Kaufgrenze lernt je Preisstufe (R3, SN-M). Stufe = Kaufpreis / Wert beim Kauf (Grenzen wie Tabelle "kaufen").
-- Jeder abgeschlossene Kauf (Fc: alle Stück zugeordnet) zählt seinen Gewinn (Erlös / Kaufpreis − 1) in seiner Stufe.
-- Grenze: höchste Stufe, deren Gewinn (eigene Zählung, Vorwissen = Tabelle) mindestens den Mindestgewinn erreicht -
-- nie über 0,9 × Wert. Ohne genug Fälle (< BUY_MIN je Stufe, eigene + Tabelle) bleibt 0,9.
-- ------------------------------------------------------------
K.BUY_BANDS, K.BUY_MIN = { 0.6, 0.7, 0.8, 0.9, 99 }, 10
-- S2-B1/B2 (Prüfung 12:35): Gewinn je Stufe als Summe/Summe (Σ Erlös / Σ Kaufpreis − 1, wie die Tabelle, L3/KF2); die
-- Tabelle ist nur Vorwissen mit Gewicht k = 2 (sie stammt aus denselben Käufen - sonst zählte jeder Fall doppelt);
-- BUY_MIN zählt nur EIGENE Fälle.
function K:BuyBand(share)
    for i, b in ipairs(self.BUY_BANDS) do if share <= b then return i end end
    return #self.BUY_BANDS
end
function K:OnBuyCase(e, now)
    if not (e and e.pr and e.pr > 0 and e.rv and e.rq and e.rq > 0) then return nil end
    local value = e.ev or e.mv
    if not (value and value > 0) then return nil end
    if A.InTestRoutine and A:InTestRoutine() and not self.testDB then return nil end
    local cost, rev = e.pr * e.rq, e.rv
    local band = self:BuyBand(e.pr / value)
    -- Selbstkontrolle (Grundsatz 11:24, P1): Vorhersage der Stufe VOR diesem Fall gegen das Ergebnis
    local pred = self:BuyGain(band, now)
    local real = rev / cost - 1
    if pred then
        self:Add("buyp", "b" .. band, pred, now)
        self:Add("buyr", "b" .. band, real, now)
    end
    self:Add("buyk", "b" .. band, cost, now)
    self:Add("buye", "b" .. band, rev, now)
    self.buyCapCache = nil
    return band, real
end
function K:TableBuy(band)
    local t = self:Tables()
    local rows = t and type(t.kaufen) == "table" and t.kaufen
    local r = type(rows) == "table" and rows[band]
    if type(r) == "table" and r.bis == self.BUY_BANDS[band] then return r.gewinn, r.n or 0 end
    return nil
end
-- geschätzter Gewinn einer Stufe und Zahl der EIGENEN Fälle (gewichtet nach Alter)
function K:BuyGain(band, now)
    local n, sk = self:Counts("buyk", "b" .. band, now)
    local _, se = self:Counts("buye", "b" .. band, now)
    local tg = self:TableBuy(band)
    if n <= 0 then return tg, 0 end
    if tg then
        local avg = sk / n                              -- Vorwissen = k "durchschnittliche" Käufe zum Tabellen-Gewinn
        return (se + self.PRIOR_K * avg * (1 + tg)) / (sk + self.PRIOR_K * avg) - 1, n
    end
    return se / sk - 1, n
end
-- Höchst-Anteil (Kaufpreis / Wert) für einen Mindestgewinn (z. B. 0,2): höchste Stufe, die ihn hält; nie über 0,9
function K:BuyShareCap(minGain, now)
    minGain = minGain or 0.2
    local key = math.floor(minGain * 1000 + 0.5)
    -- KAUFGRENZE-LECK (Ingametest 19.11. 16:50: Bericht "Grenze 0.90/0.90/0.90" bei eigenen Zahlen ≤0,9 realisiert +18 % < 20 %): der
    -- Zwischenspeicher (5 Min.) galt für JEDE Datenquelle. Prüfungen setzen kurz K.testDB (leere Ersatz-Zählung, mit Pausen); rechnete
    -- in dieser Zeit eine Hintergrund-Aufgabe (Heute tun, Markt, Wächter) ein "Lohnt bis", lag 0,9 aus den Ersatz-Daten im Speicher und
    -- galt danach bis 5 Min. auch für die echten Zahlen (Grenze 0,9 statt 0,8 -> "Lohnt bis" für Entzaubern zu hoch). Jetzt gilt er nur
    -- für dieselbe Zählung und dieselbe Tabelle.
    local st, tab = self:Store(), self.tablesOverride
    local c = self.buyCapCache
    if c and (c.st ~= st or c.tab ~= tab) then c = nil; self.buyCapCache = nil end
    if c and c[key] and time() - c.t < 300 then return c[key] end
    local cap = 0.9
    for band = 1, #self.BUY_BANDS - 1 do
        local g, n = self:BuyGain(band, now)
        if g and n >= self.BUY_MIN and g < minGain then
            -- S2-B3: hält schon die billigste Stufe den Mindestgewinn nicht -> 0 = kein Kauf
            cap = math.min(cap, band > 1 and self.BUY_BANDS[band - 1] or 0)
            break
        end
    end
    if not (c and time() - c.t < 300) then c = { t = time(), st = st, tab = tab }; self.buyCapCache = c end
    c[key] = cap
    return cap
end

-- ------------------------------------------------------------
-- S2 / V3: Welle -> "jetzt verkaufen" (nur Richtung, R4/RK6). Eigene Messung (Waves.lua, ≥ 3 Tage), sonst Tabelle.
-- Zwischenspeicher 10 Min. je Band (kein Rechnen beim Klick).
-- ------------------------------------------------------------
function K:WaveState(itemID, now)
    local W = A.Waves
    if not (W and W.BANDS) then return nil end
    local band
    for _, b in ipairs(W.BANDS) do for _, id in ipairs(b.mats) do if id == itemID then band = b end end end
    if not band then return nil end
    self.waveCache = self.waveCache or {}
    local c = self.waveCache[band.key]
    if c and time() - c.t < 600 then return c.st, band.key, c.src end
    local st, src = nil, nil
    local ok, idx = pcall(W.BandIndex, W, band, now)
    if ok then
        local s, vals = W:StateOf(idx)
        if #vals >= 3 then st, src = s, "eigen" end
    end
    if not st then
        local t = self:Tables()
        local w = t and type(t.wellen) == "table" and t.wellen[band.key]
        if type(w) == "table" and w.zustand then st, src = w.zustand, "tabelle" end
    end
    self.waveCache[band.key] = { t = time(), st = st, src = src }
    return st, band.key, src
end
function K:SellNow(itemID) return self:WaveState(itemID) == "welle" end
-- Testbericht S2: Tabellen, Kaufen je Stufe, Wellen
function K:ReportS2(out, fields)
    local t = self:Tables()
    if t then
        local parts = {}
        for _, k in ipairs({ "wellen", "verkauf", "entzaubern", "kaufen" }) do if type(t[k]) == "table" then parts[#parts + 1] = k end end
        -- KERN-R1 (Supervisor 04:58): auch "alle" (Items je Fraktion) und "kern" (Zellen je Weg) - zeigt, dass die Daten angekommen sind
        local function cnt(x) local c = 0; for _ in pairs(type(x) == "table" and x or {}) do c = c + 1 end; return c end
        if type(t.alle) == "table" then parts[#parts + 1] = string.format("alle (Horde %d, Allianz %d Items)", cnt(t.alle.H), cnt(t.alle.A)) end
        if type(t.kern) == "table" then
            local ws, total = {}, 0
            for w, cells in pairs(t.kern) do
                if type(cells) == "table" then local c = cnt(cells); total = total + c; ws[#ws + 1] = w .. " " .. c end
            end
            table.sort(ws)
            parts[#parts + 1] = string.format("kern (%d Zellen%s)", total, #ws > 0 and (": " .. table.concat(ws, ", ")) or "")
        end
        out[#out + 1] = string.format("  MARKT-KERN Tabellen (A2): erstellt %s, Daten bis %s · Teile: %s", date("%d.%m. %H:%M", t.erstellt or 0), date("%d.%m. %H:%M", t.datenBis or 0), table.concat(parts, ", "))
    else
        out[#out + 1] = "  MARKT-KERN Tabellen (A2): keine (läuft ohne)"
    end
    local bands = {}
    for band = 1, #self.BUY_BANDS do
        local g, n = self:BuyGain(band)
        local np, sp = self:Counts("buyp", "b" .. band)
        local _, sr = self:Counts("buyr", "b" .. band)
        bands[#bands + 1] = string.format("≤%s %s (eigen n %.0f%s)", band == #self.BUY_BANDS and "∞" or tostring(self.BUY_BANDS[band]), g and string.format("%+d %%", math.floor(g * 100 + 0.5)) or "-", n,
            np > 0 and string.format(", vorhergesagt %+d %% / realisiert %+d %%", math.floor(sp / np * 100 + 0.5), math.floor(sr / np * 100 + 0.5)) or "")
    end
    out[#out + 1] = string.format("  MARKT-KERN Kaufen je Stufe (V2, Kaufpreis/Wert -> Gewinn): %s · Grenze bei Mindestgewinn 20/25/30 %%: %.2f/%.2f/%.2f × Wert",
        table.concat(bands, " · "), self:BuyShareCap(0.2), self:BuyShareCap(0.25), self:BuyShareCap(0.3))
    local W = A.Waves
    if W and W.BANDS then
        local ws = {}
        for _, b in ipairs(W.BANDS) do
            local st, _, src = self:WaveState(b.mats[1])
            ws[#ws + 1] = string.format("%s %s (%s)", b.key, tostring(st or "-"), tostring(src or "-"))
        end
        out[#out + 1] = "  MARKT-KERN Wellen (V3, \"welle\" -> jetzt verkaufen): " .. table.concat(ws, " · ")
        if fields then fields.kern_wellen = table.concat(ws, " | "):sub(1, 200) end
    end
end

-- ------------------------------------------------------------
-- S3 (RK1/RK2), Schritt a: EIN "Lohnt bis" über alle Wege - bester Ausgang je Stück: Entzaubern (MK:DELimit, mit
-- DE30b-Mindestgewinn und V2-Grenze), Wiederverkauf im AH (A:FlipCheck: Preisleiter, Absatz, 5 %, Einzahlung, gelernte
-- Marge) und Händler (geprüfter Händlerpreis). Ein Zwischenspeicher je Datenstand. Die Anzeigen lesen in diesem Schritt
-- noch ihre bisherige Zahl; der Testbericht vergleicht sie mit diesem Wert (Selbstkontrolle "nie zwei Zahlen") - die
-- Umstellung aller Anzeigen folgt, sobald die Abweichungen erklärt sind.
-- ------------------------------------------------------------
K.lohntCache, K.lohntVer = {}, nil
K.VENDOR_MIN_GAIN = 0.2
function K:LohntBis(itemID)
    if not itemID then return nil end
    local ver = A.DataVersion and A:DataVersion() or 0
    if self.lohntVer ~= ver then self.lohntCache, self.lohntVer = {}, ver end
    local c = self.lohntCache[itemID]
    if c ~= nil then return c or nil end
    local best = { per = nil, way = nil, ways = {} }
    local function offer(way, per, sure)
        if type(per) ~= "number" or per <= 0 then return end
        per = math.floor(per)
        best.ways[way] = per
        if sure and (not best.per or per > best.per) then best.per, best.way = per, way end
    end
    local MK = A.Core
    if MK and MK.DELimit then
        local ok, per, net, sure = pcall(MK.DELimit, MK, itemID)
        if ok and per then offer("de", per, sure) end
    end
    if A.FlipCheck and A:WayOn("flip") then
        local ok, _, r = pcall(A.FlipCheck, A, itemID, nil)
        if ok and r and r.resale and r.limit then offer("ah", r.limit, true) end
    end
    -- S3-1 (Prüfung 14:10): Kauf zum Händlerpreis bringt 0 - auch hier der Mindestgewinn (Händler-Marge 20 %: v / 1,2)
    local v = A.GetVendorPrice and A:GetVendorPrice(itemID)
    if type(v) == "number" and v > 0 and A:WayOn("vendor") then offer("haendler", math.floor(v / (1 + self.VENDOR_MIN_GAIN)), true) end
    self.lohntCache[itemID] = best.per and best or false
    return best.per and best or nil
end
-- Selbstkontrolle S3: Anzeigen (MK:LimitSources - Tooltip, Markt, Sammelkauf, Sniper, API) - je Weg eine Zahl (MK:LimitCompare)
-- LANG-1 (0.65.323): in Portionen rechenbar - acc = Zwischenstand eines früheren Aufrufs, step = höchstens so viele Items je Aufruf
-- (acc.done = fertig). Ohne acc/step wie bisher alles in einem Aufruf. Die Item-Liste wird beim ersten Aufruf einmal festgelegt.
function K:LohntCheck(maxItems, acc, step)
    local MK = A.Core
    local md = A.db and A.db.marketData
    local out = acc or { n = 0, same = 0, other = 0, byWay = {}, ex = {} }
    if not (MK and MK.LimitSources and md) then out.done = true; return out end
    if not out.ids then
        out.ids, out.pos = {}, 1
        for id in pairs(md) do out.ids[#out.ids + 1] = id; if #out.ids >= (maxItems or 60) * 4 then break end end
    end
    local ids = out.ids
    local last = step and math.min(#ids, out.pos + step - 1) or #ids
    for i = out.pos, last do
        local id = ids[i]
        out.pos = i + 1
        if out.n >= (maxItems or 60) then out.pos = #ids + 1; break end
        local b = self:LohntBis(id)
        if b then
            out.n = out.n + 1
            out.byWay[b.way] = (out.byWay[b.way] or 0) + 1
            -- C / LOHNT-1 (0.65.324): dieselbe Regel wie S28 (MK:LimitCompare): Entzauber-Anzeigen = Entzauber-Grenze, API = dieser
            -- eine Wert. Ohne Entzauber-Grenze (Weg AH/Händler) wird die API direkt gefragt.
            local okS, src = pcall(MK.LimitSources, MK, id)
            src = okS and type(src) == "table" and src or {}
            if src.api == nil and not src.kern then
                local API = A.API or (AHSentinel and AHSentinel.API)
                if API and API.WorthUpTo then local okA, l = pcall(API.WorthUpTo, id, 1); if okA and l then src = { api = l } end end
            end
            local bad = MK.LimitCompare and MK:LimitCompare(id, src, b) or {}
            if #bad > 0 then
                if #out.ex < 3 then out.ex[#out.ex + 1] = string.format("Item %d: ein Wert %d (%s)%s · %s", id, b.per, b.way,
                    src.kern and (" · Entzaubern " .. src.kern) or "", table.concat(bad, ", ")) end
                out.other = out.other + 1
            else
                out.same = out.same + 1
            end
        end
    end
    out.done = out.pos > #ids or out.n >= (maxItems or 60)
    return out
end
