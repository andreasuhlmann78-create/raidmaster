if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.7 - Twinks und Goldverlauf
--
-- Für jeden Charakter (accountweit gespeichert):
--   * Gold und Goldverlauf (ein Punkt höchstens alle 30 Min.)
--   * Inhalt der Taschen und der Bank (Bank: beim Öffnen der Bank)
-- Damit zeigt der Tooltip, wie viele Stück deine Twinks haben,
-- und die Buchhaltung, wie sich dein Gold entwickelt.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local string = A.SafeString or string          -- AHS-OVF1: string.format ohne 32-Bit-Überlauf (gleicher Text darunter)
local CreateFrame, C_Timer = A.OwnCreateFrame or CreateFrame, A.OwnTimer or C_Timer      -- VS-BILD-2 (0.65.320): eigene Skripte/Zeitgeber je Bild messen (nur während einer Vollscan-Messung)
local L = A.L

local Ch = {}
A.Chars = Ch

local POINT_GAP = 1800         -- frühestens alle 30 Min. ein neuer Goldpunkt
local MAX_POINTS = 600
local KEEP_DAYS = 365

local function DB() return A.db and A.db.chars end

-- AHS-TB1-b (belegt 26.11.: WoW Forever liefert seit ~21.11. GetRealmName() = "" und GetNormalizedRealmName() = "", bis 20.11.
-- "CAMWOW EU4 Realm 6 PvP"): der Schlüssel einer Figur ("Name-Realm") wechselte am 21.11. auf "Name-" - jede Figur stand danach ZWEIMAL in
-- allen Tabellen je Figur (Gold doppelt gezählt). Jetzt hängt der Schlüssel nicht mehr von einer leeren Antwort ab:
--   1) GetRealmName() liefert einen Namen -> gilt und wird als Heimat-Realm gemerkt (A.db.homeRealm)
--   2) leer -> gemerkter Heimat-Realm; 3) noch keiner gemerkt -> der EINE Realm aller gespeicherten Figuren (sonst "")
-- Kommt der Name zurück, ist es derselbe Schlüssel wie vorher (keine dritte Kopie). Format "Name-Realm" unverändert (alte Versionen lesen es).
-- HINWEIS (Supervisor 26.11. 09:56, NIEDRIG): WoW Forever hat mehrere Heimat-Realms ("… Realm 6", "… Realm 2"). Solange der Name leer ist, landen
-- ALLE Figuren unter dem gemerkten Heimat-Realm - eine Figur gleichen Namens auf einem zweiten Realm würde mit der ersten vermischt. Beim Nutzer
-- heute nicht der Fall (ein Realm in den Daten); ändert sich das, braucht der Schlüssel ein anderes Unterscheidungsmerkmal (z. B. GUID).
function Ch.RealmFromData()
    local seen, one, n = {}, nil, 0
    for k, c in pairs(DB() or {}) do
        local r = type(c) == "table" and c.realm
        if type(r) ~= "string" or r == "" then r = type(k) == "string" and k:match("^[^%-]+%-(.+)$") end
        if r and r ~= "" and not seen[r] then seen[r] = true; one = r; n = n + 1 end
    end
    return n == 1 and one or nil
end
function Ch:Realm()
    local r = GetRealmName and GetRealmName() or ""
    if type(r) == "string" and r ~= "" then
        if A.db and A.db.homeRealm ~= r then A.db.homeRealm = r end
        return r
    end
    local home = A.db and A.db.homeRealm
    if type(home) == "string" and home ~= "" then return home end
    local d = Ch.RealmFromData()
    if d and A.db then A.db.homeRealm = d end
    return d or ""
end
function Ch:Key()
    local name = UnitName and UnitName("player") or "?"
    local realm = self:Realm()
    return name .. "-" .. realm, name, realm
end

function Ch:Me()
    local db = DB()
    if not db then return nil end
    local key, name, realm = self:Key()
    local c = db[key]
    if not c then
        c = { name = name, realm = realm, money = 0, gold = {}, bags = {}, bank = {} }
        db[key] = c
    end
    if UnitClass then
        local _, classFile = UnitClass("player")
        c.class = classFile
    end
    if UnitFactionGroup then c.faction = UnitFactionGroup("player") end
    return c, key
end

-- ------------------------------------------------------------
-- AHS-TB1-b: Doppel "Name-" (Realm leer, ab 21.11.) mit "Name-<Heimat-Realm>" ZUSAMMENFÜHREN (einmal je Paar, beim Laden)
-- Nichts wird verworfen: vorher Sicherung beider Einträge je Tabelle in A.db.tb1bBackup[Quelle] (nur beim ersten Mal).
-- Tabellen mit Figur-Schlüssel (alle im Code, Stand 0.65.406): chars, recipes, chains, books.cb, books.gold, books.flow, books.flowStart,
-- books.inboxSnap, books.opened, books.ownEq, ledger.stock[Tag], dazu books.log[].ch.
-- ------------------------------------------------------------
local function Copy(v, seen)
    if type(v) ~= "table" then return v end
    seen = seen or {}
    if seen[v] then return seen[v] end
    local o = {}
    seen[v] = o
    for k, x in pairs(v) do o[Copy(k, seen)] = Copy(x, seen) end
    return o
end
local function Newer(a, b, f)        -- Eintrag mit dem jüngeren Zeitfeld (nil-sicher)
    local ta, tb = type(a) == "table" and (a[f] or 0) or -1, type(b) == "table" and (b[f] or 0) or -1
    return (tb > ta) and b or a
end
-- Gold-Verlauf und Stand
local function MergeChar(dst, src)
    local g = {}
    for _, p in ipairs(src.gold or {}) do g[#g + 1] = p end
    for _, p in ipairs(dst.gold or {}) do g[#g + 1] = p end
    table.sort(g, function(x, y) return (x.t or 0) < (y.t or 0) end)
    dst.gold = g
    if (src.updated or 0) > (dst.updated or 0) then
        dst.money, dst.moneyE, dst.updated = src.money, src.moneyE, src.updated
        dst.bags = src.bags or dst.bags
    end
    if (src.bankTime or 0) > (dst.bankTime or 0) then dst.bank, dst.bankTime = src.bank, src.bankTime end
    for _, f in ipairs({ "class", "faction", "name", "enchant", "level" }) do if dst[f] == nil then dst[f] = src[f] end end
end
local function MergeCB(dst, src)                 -- Einstand: Menge und Kosten zusammen
    for id, p in pairs(src) do
        local d = dst[id]
        if type(d) ~= "table" then dst[id] = p
        elseif type(p) == "table" then
            d.q, d.c = (d.q or 0) + (p.q or 0), (d.c or 0) + (p.c or 0)
            if d.bt == nil then d.bt = p.bt end
        end
    end
end
local function MergeGoldBook(dst, src)
    if (src.startT or math.huge) < (dst.startT or math.huge) then dst.start, dst.startT = src.start, src.startT end
    if (src.lastT or 0) > (dst.lastT or 0) then dst.last, dst.lastT = src.last, src.lastT end
    if (src.day or 0) > (dst.day or 0) then dst.day, dst.dayStart = src.day, src.dayStart end
end
local function MergeFlow(dst, src)
    for day, fd in pairs(src) do
        local d = dst[day]
        if type(d) ~= "table" then dst[day] = fd
        elseif type(fd) == "table" then for ctx, v in pairs(fd) do d[ctx] = (d[ctx] or 0) + v end end
    end
end
local function MergeKeys(dst, src) for k, v in pairs(src) do if dst[k] == nil then dst[k] = v end end end
local function MergeRecipes(dst, src)
    for kind, r in pairs(src) do dst[kind] = Newer(dst[kind], r, "t") end
end
-- eine Tabelle [Figur] -> Wert zusammenführen; how = Funktion(dst, src) oder "newer:<feld>" / "min"
local function MergeIn(t, from, to, how, bk)
    if type(t) ~= "table" or t[from] == nil then return 0 end
    bk[#bk + 1] = { tbl = t, from = from, to = to, src = Copy(t[from]), dst = Copy(t[to]) }
    local s, d = t[from], t[to]
    if d == nil then t[to] = s
    elseif how == "min" then t[to] = math.min(s, d)
    elseif type(how) == "string" then t[to] = Newer(d, s, how:match("^newer:(.+)$"))
    elseif type(s) == "table" and type(d) == "table" then how(d, s) end
    t[from] = nil
    return 1
end
function Ch:MergeEmptyRealm()
    local db = A.db
    local chars = db and db.chars
    if type(chars) ~= "table" then return 0 end
    local realm = self:Realm()
    if realm == "" then return 0 end
    local pairsTodo = {}
    for k in pairs(chars) do
        local name = type(k) == "string" and k:match("^([^%-]+)%-$")
        if name then pairsTodo[#pairsTodo + 1] = { k, name .. "-" .. realm } end
    end
    if #pairsTodo == 0 then return 0 end
    table.sort(pairsTodo, function(x, y) return x[1] < y[1] end)
    local books, led = db.books or {}, db.ledger or {}
    db.tb1bBackup = db.tb1bBackup or {}
    local n = 0
    for _, pr in ipairs(pairsTodo) do
        local from, to = pr[1], pr[2]
        local bk = {}
        n = n + MergeIn(chars, from, to, MergeChar, bk)
        if type(chars[to]) == "table" then chars[to].realm = realm end
        MergeIn(db.recipes, from, to, MergeRecipes, bk)
        MergeIn(db.chains, from, to, "newer:t", bk)
        MergeIn(books.cb, from, to, MergeCB, bk)
        MergeIn(books.gold, from, to, MergeGoldBook, bk)
        MergeIn(books.flow, from, to, MergeFlow, bk)
        MergeIn(books.flowStart, from, to, "min", bk)
        MergeIn(books.inboxSnap, from, to, "newer:t", bk)
        MergeIn(books.opened, from, to, "newer:t", bk)
        MergeIn(books.ownEq, from, to, MergeKeys, bk)
        MergeIn(db.inboxSnap, from, to, "newer:t", bk)
        for _, d in pairs(type(led.stock) == "table" and led.stock or {}) do
            if type(d) == "table" then MergeIn(d, from, to, MergeKeys, bk) end
        end
        local logN, logIdx = 0, {}
        for i, e in ipairs(type(books.log) == "table" and books.log or {}) do
            if type(e) == "table" and e.ch == from then e.ch = to; logN = logN + 1; logIdx[#logIdx + 1] = i end
        end
        -- Sicherung (nur beim ersten Mal je Quelle; die Tabellen-Referenz selbst wird nicht gespeichert)
        if not db.tb1bBackup[from] then
            local entries = {}
            for _, b in ipairs(bk) do entries[#entries + 1] = { from = b.from, to = b.to, src = b.src, dst = b.dst } end
            db.tb1bBackup[from] = { t = time(), to = to, version = A.version, entries = entries, log = logN, logIdx = logIdx }
        end
        if A.Diag and A.Diag.Add then
            pcall(A.Diag.Add, A.Diag, "TB1-B", string.format("Figur zusammengeführt (Realm leer -> %s): %d Tabellen, %d Buchungen", realm, #bk, logN))
        end
    end
    A:Fire("CHARS_CHANGED")
    return n
end

-- ------------------------------------------------------------
-- Gold
-- ------------------------------------------------------------
-- AHS-TB1 (Ingametest 26.11.: "Gestern: nichts gebucht", aber "+46g 67s 16c seit gestern"; belegt mit den Daten des Nutzers): GetMoney()
-- liefert beim Ausloggen (und kurz nach dem Einloggen) 0. RecordMoney lief auch bei PLAYER_LOGOUT und schrieb diese 0 als Goldpunkt bzw.
-- ÜBER den letzten echten Punkt (< 30 Min.) - danach zeigte "seit gestern" das ganze Gold einer Figur als Zuwachs. Jetzt:
--   * eine 0 zählt nur, wenn sie aus PLAYER_MONEY kommt UND 2 s später noch gilt (dann Punkt mit e = true: echt alles ausgegeben)
--   * beim Ein-/Ausloggen nie eine 0 schreiben; alte 0-Punkte ohne e (vor 0.65.405) zählen nicht (ValidPoint)
function Ch.ValidPoint(g, i)
    local p = g and g[i]
    if not p then return false end
    return (p.m or 0) ~= 0 or p.e == true
end
local ValidPoint = Ch.ValidPoint
-- letzter gültiger Stand einer Figur (nil = keiner)
function Ch.LastValid(c)
    local g = c and c.gold or {}
    for i = #g, 1, -1 do if ValidPoint(g, i) then return g[i].m end end
    return nil
end
Ch.ZERO_CONFIRM = 2                -- Sekunden: eine 0 aus PLAYER_MONEY muss danach noch gelten
-- Naht für die Testroutine (Blizzard-GetMoney nie ersetzen - Taint)
function Ch.GameMoney() return GetMoney and GetMoney() or nil end
function Ch:RecordMoney(fromEvent, confirmed)
    local c = self:Me()
    local money = Ch.GameMoney()
    if not c or not money then return end
    local g = c.gold
    local last = g[#g]
    if money == 0 then
        -- direkt nach dem Einloggen / beim Ausloggen meldet das Spiel 0 Gold: nie als Stand nehmen
        if not fromEvent then return end
        -- aus PLAYER_MONEY: erst nach kurzer Wartezeit bestätigen (beim Ausloggen kommt die Bestätigung nie)
        if not confirmed then
            if C_Timer and C_Timer.After then C_Timer.After(self.ZERO_CONFIRM, function() if A.db then Ch:RecordMoney(true, true) end end) end
            return
        end
    end
    c.money = money
    c.moneyE = (money == 0) or nil
    c.updated = time()
    if last and time() - last.t < POINT_GAP and (ValidPoint(g, #g) or money ~= 0) then
        last.m = money             -- innerhalb von 30 Min.: letzten Punkt anpassen
        last.e = (money == 0) or nil
    elseif not last or last.m ~= money or time() - last.t > 86400 then
        table.insert(g, { t = time(), m = money, e = (money == 0) or nil })
    end
    local cutoff = time() - KEEP_DAYS * 86400
    while #g > MAX_POINTS or (g[1] and g[1].t < cutoff and #g > 1) do table.remove(g, 1) end
    A:Fire("CHARS_CHANGED")
end

-- ------------------------------------------------------------
-- Taschen und Bank zählen
-- ------------------------------------------------------------
local function CountContainers(list)
    local out = {}
    for _, bag in ipairs(list) do
        local n = 0
        if C_Container and C_Container.GetContainerNumSlots then n = C_Container.GetContainerNumSlots(bag) or 0
        elseif GetContainerNumSlots then n = GetContainerNumSlots(bag) or 0 end
        for slot = 1, n do
            local id, count
            if C_Container and C_Container.GetContainerItemInfo then
                local info = C_Container.GetContainerItemInfo(bag, slot)
                if info then id, count = info.itemID, info.stackCount end
            elseif GetContainerItemInfo then
                local _, c, _, _, _, _, link = GetContainerItemInfo(bag, slot)
                count = c
                id = link and tonumber(link:match("item:(%d+)"))
            end
            if id then out[id] = (out[id] or 0) + (count or 1) end
        end
    end
    return out
end

function Ch:ScanBags()
    local c = self:Me()
    if not c then return end
    local bags = {}
    for b = 0, (NUM_BAG_SLOTS or 4) do table.insert(bags, b) end
    c.bags = CountContainers(bags)
    c.updated = time()
    A:Fire("CHARS_CHANGED")
end

function Ch:ScanBank()
    local c = self:Me()
    if not c then return end
    local list = { BANK_CONTAINER or -1 }
    local first = (NUM_BAG_SLOTS or 4) + 1
    for b = first, first + (NUM_BANKBAGSLOTS or 6) - 1 do table.insert(list, b) end
    c.bank = CountContainers(list)
    c.bankTime = time()
    A:Fire("CHARS_CHANGED")
end

-- ------------------------------------------------------------
-- Abfragen
-- ------------------------------------------------------------
function Ch:GetAll()
    local out = {}
    local _, myKey = self:Me()
    for key, c in pairs(DB() or {}) do
        local items = 0
        for _, n in pairs(c.bags or {}) do items = items + n end
        for _, n in pairs(c.bank or {}) do items = items + n end
        table.insert(out, { key = key, name = c.name, realm = c.realm, money = Ch.MoneyOf(c, key), updated = c.updated,
                            bankTime = c.bankTime, items = items, class = c.class, me = (key == myKey) })
    end
    table.sort(out, function(a, b) return a.money > b.money end)
    return out
end

-- AHS-TB1: Stand je Figur = c.money; eine 0 ohne Bestätigung (alte Daten: 0 vom Ausloggen) -> letzter gültiger Goldpunkt.
-- AHS-TB1-b 3): gar kein gültiger Goldpunkt (z. B. Bank-Figur: alle Punkte 0 vom Ausloggen) -> Gold-Stand der Buchhaltung
-- (books.gold[Figur]: last, sonst dayStart, beide werden bei Login/Logout/Öffnen der Buchhaltung aus GetMoney geschrieben; 0 zählt nicht).
function Ch.MoneyOf(c, key)
    if not c then return 0 end
    if (c.money or 0) == 0 and not c.moneyE then
        local v = Ch.LastValid(c)
        if v then return v end
        local bg = key and A.db and A.db.books and A.db.books.gold and A.db.books.gold[key]
        if type(bg) == "table" then
            if (bg.last or 0) > 0 then return bg.last end
            if (bg.dayStart or 0) > 0 then return bg.dayStart end
        end
        return 0
    end
    return c.money or 0
end
function Ch:TotalMoney()
    local t = 0
    for key, c in pairs(DB() or {}) do t = t + Ch.MoneyOf(c, key) end
    return t
end

-- Bestand eines Items bei allen Charakteren: { {name, bags, bank, me}, ... }, Summe
function Ch:ItemCounts(itemID)
    local out, total = {}, 0
    local _, myKey = self:Me()
    for key, c in pairs(DB() or {}) do
        local b, k = (c.bags or {})[itemID] or 0, (c.bank or {})[itemID] or 0
        if b + k > 0 then
            table.insert(out, { name = c.name, bags = b, bank = k, me = (key == myKey) })
            total = total + b + k
        end
    end
    table.sort(out, function(a, b) return (a.bags + a.bank) > (b.bags + b.bank) end)
    return out, total
end

function Ch:Remove(key)
    local db = DB()
    local _, myKey = self:Me()
    if key == myKey then return false, L["Den eingeloggten Charakter kann man nicht entfernen."] end
    if not db[key] then return false, L["Charakter nicht gefunden."] end
    db[key] = nil
    A:Fire("CHARS_CHANGED")
    return true, L["Charakter entfernt: "] .. key
end

-- Gold aller Charaktere am Ende jedes Tages der letzten "days" Tage
-- (Wert eines Charakters = letzter bekannter Stand bis zu diesem Tag)
function Ch:DailyTotals(days)
    days = days or 30
    local out = {}
    local endOfToday = A:DayStart(time()) + 86399
    for d = days - 1, 0, -1 do
        local limit = endOfToday - d * 86400
        local total, known = 0, false
        for _, c in pairs(DB() or {}) do
            local v
            local g = c.gold or {}
            for i, p in ipairs(g) do
                if p.t > limit then break end
                if ValidPoint(g, i) then v = p.m end          -- AHS-TB1: 0 vom Ausloggen zählt nicht
            end
            if v then total = total + v; known = true end
        end
        table.insert(out, { t = limit, money = known and total or nil })
    end
    return out
end

-- Goldänderung seit einem Zeitpunkt: nur Charaktere, deren Gold damals schon bekannt war.
-- Rückgabe: Differenz oder nil (kein Vergleichswert)
function Ch:ChangeSince(limit)
    local diff, known = 0, false
    for _, c in pairs(DB() or {}) do
        local before, now
        local g = c.gold or {}
        for i, p in ipairs(g) do
            -- AHS-TB1: eine 0 ohne Bestätigung (Einloggen/Ausloggen, alte Daten) ist kein Stand
            if ValidPoint(g, i) then
                if p.t <= limit then before = p.m end
                now = p.m
            end
        end
        if before and now then diff = diff + (now - before); known = true end
    end
    return known and diff or nil
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
local evt = CreateFrame("Frame")
Ch.evt = evt            -- für die Testroutine (Ereignisse mit Testargumenten nachspielen)
for _, e in ipairs({ "PLAYER_MONEY", "BAG_UPDATE_DELAYED", "BAG_UPDATE", "BANKFRAME_OPENED", "PLAYERBANKSLOTS_CHANGED",
                     "PLAYERBANKBAGSLOTS_CHANGED", "PLAYER_LOGOUT", "PLAYER_LEAVING_WORLD", "PLAYER_CAMPING", "PLAYER_QUITING", "LOGOUT_CANCEL" }) do
    pcall(evt.RegisterEvent, evt, e)
end
local bankOpen, bagsDirty, bankDirty = false, false, false
evt:SetScript("OnEvent", function(_, event)
    if not A.db then return end
    if event == "PLAYER_MONEY" then Ch:RecordMoney(true)
    elseif event == "BAG_UPDATE" or event == "BAG_UPDATE_DELAYED" then bagsDirty = true
    elseif event == "BANKFRAME_OPENED" then bankOpen = true; Ch:ScanBank()
    elseif event == "PLAYERBANKSLOTS_CHANGED" or event == "PLAYERBANKBAGSLOTS_CHANGED" then bankDirty = true
    elseif event == "BANKFRAME_CLOSED" then bankOpen = false
    elseif event == "PLAYER_CAMPING" or event == "PLAYER_QUITING" then
        -- AHS-TB1 (Supervisor 10:32: 0 nicht bei jedem Ausloggen): Art des Endes merken - PLAYER_CAMPING = Ausloggen ins Menü (20 s Lager),
        -- PLAYER_QUITING = Spiel beenden (Countdown). Sofortiges Ende (Rasthof/Stadt) oder /reload melden keines von beiden.
        Ch.leaveKind = (event == "PLAYER_CAMPING") and "Ausloggen (Lager)" or "Spiel beenden"
    elseif event == "LOGOUT_CANCEL" then
        Ch.leaveKind = nil
    elseif event == "PLAYER_LEAVING_WORLD" then
        Ch.leaveMoney, Ch.leaveT = Ch.GameMoney(), GetTime and GetTime() or 0
    elseif event == "PLAYER_LOGOUT" then
        -- AHS-TB1 Messzeile (Supervisor 26.11. 09:05/10:32): GetMoney() beim Ausloggen, dazu beim Verlassen der Welt und die Art des Endes
        if A.Diag and A.Diag.Add then
            local c = Ch:Me()
            pcall(A.Diag.Add, A.Diag, "GOLD-LOGOUT", string.format("GetMoney beim Ausloggen %s · beim Verlassen der Welt %s · Art: %s · letzter echter Stand %s",
                tostring(Ch.GameMoney()), tostring(Ch.leaveMoney), Ch.leaveKind or "ohne Ankündigung (sofort, Verbindungsende oder /reload)",
                tostring(c and Ch.LastValid(c))))
        end
        Ch:RecordMoney(); Ch:ScanBags()
    end
end)
pcall(evt.RegisterEvent, evt, "BANKFRAME_CLOSED")
local acc = 0
evt:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    if acc < 1 then return end
    acc = 0
    if bagsDirty then bagsDirty = false; Ch:ScanBags() end
    if bankDirty then bankDirty = false; if bankOpen then Ch:ScanBank() end end
end)

-- RK4: Verzauberkunst je Figur merken (für "Entzaubern möglich" über alle eigenen Figuren)
function Ch:RecordSkills()
    local c = self:Me()
    local D = A.Disenchant
    if not (c and D and D.EnchantSkill) then return end
    local ok, sk = pcall(D.EnchantSkill, D)
    if ok and type(sk) == "number" then c.enchant = sk; D.accSkillT = nil end
end
pcall(evt.RegisterEvent, evt, "SKILL_LINES_CHANGED")
evt:HookScript("OnEvent", function(_, event) if event == "SKILL_LINES_CHANGED" and A.db then Ch:RecordSkills() end end)
A:On("READY", function()
    pcall(Ch.MergeEmptyRealm, Ch)                -- AHS-TB1-b: zuerst die Doppel zusammenführen (sonst schreibt RecordMoney in den neuen Schlüssel)
    if A.Diag and A.Diag.Add then
        local r = GetRealmName and GetRealmName() or ""
        pcall(A.Diag.Add, A.Diag, "REALM", (r == "" and "<leer>" or r) .. " · Schlüssel-Realm " .. tostring(Ch:Realm()))
    end
    Ch:RecordMoney()
    Ch:ScanBags()
    Ch:RecordSkills()
end)
