-- ThreatSentinel - TauntButton.lua
-- Gesicherte Knöpfe für "Spott auf Mauszeiger" und "Flächenspott" mit eigener Tastenbelegung.
-- Die Knöpfe werden nur einmal ausserhalb des Kampfs angelegt, daher funktionieren sie im Kampf.

local ADDON, ns = ...
local API = ns.API   -- Blizzard-Funktionen nur über ns.API (API.lua)
local L = ns.L

local Tb = {}
ns.Taunt = Tb
table.insert(ns.modules, Tb)

BINDING_HEADER_THREATSENTINEL = "ThreatSentinel"
_G["BINDING_NAME_CLICK ThreatSentinelTauntButton:LeftButton"] = L.BIND_TAUNT
_G["BINDING_NAME_CLICK ThreatSentinelAoeButton:LeftButton"] = L.BIND_AOE

Tb.BIND = {
	taunt = "CLICK ThreatSentinelTauntButton:LeftButton",
	aoe = "CLICK ThreatSentinelAoeButton:LeftButton",
}

local function RegisterClicks(btn)
	local down = GetCVarBool and GetCVarBool("ActionButtonUseKeyDown")
	btn:RegisterForClicks(down and "AnyDown" or "AnyUp")
end

function Tb:Init()
	self.taunt = CreateFrame("Button", "ThreatSentinelTauntButton", UIParent, "SecureActionButtonTemplate")
	if ns.RegisterUI then ns.RegisterUI(self.taunt, "Spott-Knopf", "hud") end   -- Oberflächen-Prüfung (UICheck.lua)
	self.taunt:SetAttribute("type", "macro")
	self.taunt:SetSize(1, 1)
	-- Zeitpunkt des Tastendrucks merken (Testassistent: Pet-Knurren per Taste vs. automatisch)
	self.taunt:HookScript("PreClick", function()
		Tb.lastClick = GetTime()
		if ns.Log.on then pcall(ns.Log.OnTauntPress, ns.Log) end
	end)
	self.aoe = CreateFrame("Button", "ThreatSentinelAoeButton", UIParent, "SecureActionButtonTemplate")
	if ns.RegisterUI then ns.RegisterUI(self.aoe, "Flächenspott-Knopf", "hud") end   -- Oberflächen-Prüfung (UICheck.lua)
	self.aoe:SetAttribute("type", "macro")
	self.aoe:SetSize(1, 1)
end

function Tb:UpdateMacros()
	if not self.taunt then return end
	if API.InCombatLockdown() then self.pending = true return end
	self.pending = false
	local t = ns.tauntSpell
	local text = ""
	if t and ns.tauntMode == "friendly" then
		-- Rechtschaffene Verteidigung: auf den Mitspieler, den der Mob (Mausziel bzw. Ziel) angreift.
		-- Zeigt die Maus direkt auf einen Mitspieler, wird er selbst genommen.
		text = "/cast [@mouseover,help,nodead][@mouseovertarget,help,nodead][@targettarget,help,nodead] " .. t
	elseif t then
		-- Spott auf den Mob; beim Paladin in Forever ist das Richturteil (wirkt nur mit Siegel der Wut)
		text = "/cast [@mouseover,harm,nodead][harm,nodead] " .. t
	end
	self.taunt:SetAttribute("macrotext", text)
	local a = ns.aoeSpell
	self.aoe:SetAttribute("macrotext", a and ("/cast " .. a) or "")
	RegisterClicks(self.taunt)
	RegisterClicks(self.aoe)
end

function Tb:GetKey(which)
	return GetBindingKey(self.BIND[which])
end

function Tb:SetKey(which, key)
	if API.InCombatLockdown() then return false end
	local cmd = self.BIND[which]
	local k1, k2 = GetBindingKey(cmd)
	if k1 then ns.Act("binding", SetBinding, k1) end
	if k2 then ns.Act("binding", SetBinding, k2) end
	if key then ns.Act("binding", SetBinding, key, cmd) end
	ns.Act("binding", SaveBindings, GetCurrentBindingSet())
	return true
end

ns:On("PLAYER_REGEN_ENABLED", function()
	if Tb.pending then Tb:UpdateMacros() end
end)

ns:On("CVAR_UPDATE", function()
	if Tb.taunt and not API.InCombatLockdown() then
		RegisterClicks(Tb.taunt)
		RegisterClicks(Tb.aoe)
	end
end)
