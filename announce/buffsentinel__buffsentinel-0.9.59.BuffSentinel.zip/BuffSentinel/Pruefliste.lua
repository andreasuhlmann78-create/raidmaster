-- BuffSentinel – Prüfliste im Spiel (Entscheid des Nutzers 16.11.2026 06:47; gemeinsamer Baustein GoldSentinelPruefliste.lua)
-- Copyright (c) 2026 GoldSentinel. All Rights Reserved.
--
-- Nur im Entwicklermodus (GoldSentinelDev): "/bsen prüfliste" öffnet die Liste der Punkte, die im echten Spiel geprüft werden
-- müssen. Jeder Punkt sagt genau, was zu tun ist und was zu sehen sein muss. Wo BuffSentinel es selbst erkennt, wird der Punkt
-- von selbst erledigt (BS.PLHit an der Stelle im Code, wo die Funktion wirklich gewirkt hat). Ohne Entwicklermodus: wirkungslos.
-- Höchstens 14 Punkte; nach der Prüfung durch die Prüf-Sitzung erledigte Punkte in der nächsten Version herausnehmen.

local ADDON, BS = ...
local L = BS.L

-- Reihenfolge = wie man es im Spiel am besten nacheinander macht (zuerst Stadt, dann Klassen-Punkte, zuletzt Gruppe/Kampf).
-- Aufbau jedes Punkts (TR-ALLE B, Nutzer 17.11. 07:36 – "ohne Vorwissen verständlich"): todo = "Wo:" + nummerierte Schritte
-- (ein Handgriff je Schritt) + "Kosten:"; expect = was wörtlich zu sehen ist. Die Texte der Knöpfe/Zeilen kommen aus L (genau
-- so, wie BuffSentinel sie zeigt). Platz im Fenster: höchstens 8 Zeilen für todo + expect zusammen.
local function Q(s) return "\"" .. tostring(s) .. "\"" end
local function Lines(...) return table.concat({ ... }, "\n") end

BS.PRUEF_POINTS = {
    { id = "DURA", title = "Reparatur-Erinnerung in der Stadt", since = "0.9.25",
      todo = Lines("Wo: in einer Hauptstadt (z. B. Orgrimmar), abgestiegen, nicht im Kampf.",
        "1. Drücke C und fahre mit der Maus über deine Rüstungsteile: dort steht \"Haltbarkeit x / y\".",
        "2. Ein Teil muss unter 30 % haben (z. B. \"Haltbarkeit 20 / 80\"). Sonst vorher draussen kämpfen.",
        "3. Bleib 2 Sekunden in der Stadt stehen.",
        "Kosten: kein Gold (Reparieren danach wie immer), ca. 1 Min."),
      expect = "Ein Knopf " .. Q(L.ALERT_DURA) .. " mit der Prozentzahl des schwächsten Teils (z. B. \"25%\"). "
        .. "Nach dem Reparieren beim Händler ist er weg." },
    { id = "READY", title = "Zeile beim Bereitschaftscheck", since = "0.9.26",
      todo = Lines("Wo: in einer Gruppe mit mindestens einem Mitspieler, du bist Gruppenleiter.",
        "1. Tippe in den Chat: /readycheck und drücke Enter.",
        "   (Bist du nicht Gruppenleiter: bitte den Leiter, einen Bereitschaftscheck zu starten.)",
        "Kosten: kein Gold, ca. 1 Min."),
      expect = "Eine Zeile im eigenen Chat: " .. Q(string.format(L.READY_MISSING, "…")) .. " oder " .. Q(L.READY_ALL_OK) },
    { id = "PERF", title = "Zeile LEISTUNG nach einem Kampf", since = "0.9.41",
      todo = Lines("Wo: draussen, wo es Gegner gibt.",
        "1. Greif einen Gegner an und kämpfe, bis der Kampf vorbei ist (ein Gegner reicht).",
        "2. Tippe in den Chat: /bsen protokoll und drücke Enter.",
        "Kosten: kein Gold, ca. 2 Min."),
      expect = "Im Protokoll eine Zeile \"LEISTUNG " .. string.format(L.PERF_LINE, 0.4, "…", 0, 812):gsub("0%.4", "…", 1)
        :gsub(": 0 ", ": … ", 1):gsub("812", "…", 1) .. "\". Der Punkt erledigt sich nach dem Kampf von selbst." },
    { id = "JAEGER", title = "Jäger: Munition und Tierfutter", since = "0.9.59",
      todo = Lines("Wo: an der Bank einer Hauptstadt (WoW Forever), kein Kampf; Jäger mit Begleiter.",
        "1. Bankier ansprechen; Pfeile/Kugeln ins Bankfach bis unter 200, Tierfutter bis unter 10.",
        "2. Warte 2 Sekunden. 3. Munition und Futter wieder aus dem Bankfach holen.",
        "4. Gesicht neben dem Bild des Begleiters gelb oder rot? Grün: warten, nicht füttern.",
        "Kosten: kein Gold, ca. 5–20 Min. (Warten auf gelb)."),
      expect = Q(L.ALERT_AMMO) .. " und " .. Q(L.ALERT_PETFOOD) .. " mit der Zahl; " .. Q(L.ALERT_PET_HAPPY) .. " mit "
        .. Q(L.PET_CONTENT) .. " oder " .. Q(L.PET_UNHAPPY) .. ". Erledigt erst, wenn beides erschienen ist." },
    { id = "PET", title = "Jäger/Hexer: Begleiter fehlt", since = "0.9.24",
      todo = Lines("Wo: irgendwo, abgestiegen, nicht im Kampf; Jäger oder Hexenmeister mit Begleiter.",
        "1. Schick den Begleiter weg (Jäger: Zauberbuch, Taste P, Zauber zum Wegschicken des Tiers;",
        "   Hexenmeister: Rechtsklick auf das Bild des Dämons > wegschicken). Jäger: NIE \"freigeben\"!",
        "2. Warte 3 Sekunden. 3. Ruf den Begleiter wieder (Jäger: \"Tier rufen\", Hexer: beschwören).",
        "Kosten: kein Gold (Hexenmeister: Beschwören kann 1 Seelensplitter kosten), ca. 1 Min."),
      expect = "Nach 3 Sekunden " .. Q(L.ALERT_PET) .. " (Hexenmeister: " .. Q(L.ALERT_DEMON) .. "); nach dem Rufen sofort weg." },
    { id = "INFIRE", title = "Priester: Inneres Feuer Aufladungen", since = "0.9.30",
      todo = Lines("Wo: draussen bei Gegnern; Priester, der \"Inneres Feuer\" kann.",
        "1. Wirke \"Inneres Feuer\" auf dich.",
        "2. Lass dich treffen, bis die Zahl auf dem Symbol oben rechts unter 5 ist. Beende den Kampf.",
        "3. Warte 2 Sekunden.",
        "Kosten: kein Gold, ca. 3 Min."),
      expect = "Ein Knopf " .. Q(L.ALERT_INNERFIRE_CHARGES) .. " mit der Restzahl; ein Klick darauf wirkt Inneres Feuer." },
    { id = "HEXER", title = "Hexer: Vorrat und Seelenstein", since = "0.9.58",
      todo = Lines("Wo: an der Bank einer Hauptstadt, in einer Gruppe, nicht im Kampf; Hexenmeister.",
        "1. Gesundheitsstein ins Freie ziehen und \"Ja\" klicken – oder Splitter ins Bankfach (unter 3).",
        "2. Warte 2 Sekunden. 3. Niemand in der Gruppe trägt einen Seelenstein: 2 Sekunden warten.",
        "4. Danach den Seelenstein auf einen Mitspieler legen und die Splitter zurückholen.",
        "Kosten: kein Gold (neuer Stein: 1 Seelensplitter), ca. 5 Min."),
      expect = Q(L.ALERT_HEALTHSTONE) .. " bzw. " .. Q(L.ALERT_SHARDS) .. ", dann " .. Q(L.ALERT_SOULSTONE)
        .. "; erledigt erst, wenn beides erschienen ist." },
    { id = "TOTEM", title = "Schamane: Totem fehlt", since = "0.9.40",
      todo = Lines("Wo: an der Bank einer Hauptstadt, nicht im Kampf; Schamane.",
        "1. Sprich den Bankier an und lege ein Totem (z. B. das Feuertotem) ins Bankfach.",
        "2. Warte 2 Sekunden. 3. Hol das Totem wieder aus dem Bankfach.",
        "4. Nur Wrath: ein Meistertotem nur im Relikt-Platz tragen – dann darf nichts erscheinen.",
        "Kosten: kein Gold, ca. 3 Min."),
      expect = "Ein Knopf " .. Q(L.ALERT_TOTEM) .. " mit dem Element (z. B. \"Feuer\"); mit Meistertotem keine Meldung." },
    { id = "WAFFE", title = "Schamane: Waffen-IDs messen", since = "0.9.20",
      todo = Lines("Wo: irgendwo, nicht im Kampf; Schamane mit Waffe ohne Verzauberung.",
        "1. Setze irgendein Totem und bleib 10 Sekunden stehen (nur Totem).",
        "2. Wirke deine Waffenverzauberung (Zauber \"Waffe des …\") und bleib 10 Sekunden (beides).",
        "3. Warte, bis das Totem von selbst verschwindet, dann noch 10 Sekunden (nur Waffe).",
        "Kosten: kein Gold, ca. 4 Min."),
      expect = "In /bsen protokoll drei Zeilen \"WAFFE mh=… oh=… totem=…\". Der Punkt erledigt sich von selbst." },
    { id = "REAG", title = "Reagenz knapp in der Gruppe", since = "0.9.27",
      todo = Lines("Wo: an der Bank einer Hauptstadt, in einer Gruppe, nicht im Kampf.",
        "1. Sprich den Bankier an. Lege das Reagenz ins Bankfach, bis unter 10 dabei sind (Paladin 20)",
        "   (Magier: Arkanes Pulver, Priester: Kerzen, Druide: Beeren/Dornwurz, Paladin: Symbole)",
        "2. Warte 2 Sekunden. 3. Hol das Reagenz wieder aus dem Bankfach.",
        "Kosten: kein Gold, ca. 3 Min."),
      expect = "Ein Knopf " .. Q(L.ALERT_REAGENT) .. " mit der Anzahl. Allein (ohne Gruppe) keine Meldung." },
    { id = "RESTOCK", title = "Nachkaufen beim Händler (ein Klick)", since = "0.9.47",
      todo = Lines("Wo: erst an der Bank einer Hauptstadt, dann bei einem Händler mit der Ware.",
        "1. Linksklick auf den Minimap-Knopf, Bereich " .. Q(L.OPT_AREA_HELPERS) .. ", " .. Q(L.OPT_RESTOCK) .. " auf " .. Q(L.ON) .. ".",
        "2. Bankier ansprechen, Ware ins Bankfach legen, bis sie knapp ist (wie bei JAEGER oder REAG).",
        "3. Sprich den Händler an. 4. Klicke EINMAL auf den Knopf unter dem Händlerfenster.",
        "5. Danach die Ware aus dem Bankfach zurückholen.",
        "Kosten: höchstens 1 Gold (Grenze), mindestens 1 Gold bleibt; ca. 5 Min."),
      expect = "Knopf " .. Q(string.format(L.RESTOCK_BUTTON, 0, "<Ware>", "<Preis>"):gsub("0×", "<Anzahl>×", 1))
        .. "; Klick kauft genau das." },
    { id = "RF", title = "Paladin: Zorn der Gerechtigkeit", since = "0.9.39",
      todo = Lines("Wo: in einer Gruppe; Paladin, nicht als Tank eingetragen,",
        "   die meisten Talentpunkte in Heilig oder Vergeltung (Taste N zeigt es).",
        "1. Wirke \"Zorn der Gerechtigkeit\" auf dich. 2. Warte 2 Sekunden.",
        "Kosten: kein Gold, ca. 1 Min."),
      expect = "Genau EINE Zeile im eigenen Chat: " .. Q((L.RF_HINT:match("^(.-,)") or L.RF_HINT) .. " …")
        .. " Nochmal wirken: keine zweite Zeile." },
    { id = "ENTZ", title = "Gegner entzaubern ausserhalb des Kampfes", since = "0.9.59",
      todo = Lines("Wo: draussen bei Gegnern, nicht im Kampf; Schamane, Priester, Magier, Jäger oder Druide.",
        "1. Such einen Gegner mit einem Buff (z. B. einen Zauberwirker mit Schild) und klicke ihn an.",
        "   Nicht angreifen. 2. Warte 2 Sekunden.",
        "Kosten: kein Gold, ca. 3 Min."),
      expect = "Ein Knopf " .. Q(L.ALERT_PURGE) .. " mit \"» <Name des Buffs>\". Im Kampf (WoW Forever) bleibt er aus. "
        .. "Der Punkt erledigt sich von selbst." },
    { id = "OPT", title = "Optionen am Bild", since = "0.9.58",
      todo = Lines("Wo: irgendwo, nicht im Kampf.",
        "1. Linksklick auf den Minimap-Knopf: links unter " .. Q(L.OPTIONS) .. " fünf Bereiche. Esc schliesst.",
        "2. Esc > Optionen > AddOns > BuffSentinel > " .. Q(L.OPT_OPEN_WINDOW) .. ": dasselbe Fenster.",
        "3. Jeden Bereich anklicken, nichts überlappt. Suchfeld " .. Q(L.OPT_SEARCH_EXAMPLE) .. ": Zeile aus "
          .. Q(L.OPT_AREA_HELPERS) .. ".",
        "Kosten: kein Gold, ca. 3 Min."),
      expect = "Jede Einstellung in unter 5 Sekunden gefunden, alles lesbar, Tooltip über jeder Zeile." },
}

-- Eintrag (Schlüssel) -> Punkt, der als erledigt gilt, sobald die Erinnerung im echten Spiel erschienen ist
BS.PRUEF_BY_KEY = {
    durability = "DURA", ammo = "JAEGER_A", pet = "PET", pethappy = "JAEGER_B", petfood = "JAEGER_B", innerfire_ch = "INFIRE",
    healthstone = "HEXER_A", shards = "HEXER_A", shardspace = "HEXER_A", soulstone = "HEXER_B", totems = "TOTEM",
    r_powder = "REAG", r_candle = "REAG", r_gotw = "REAG", r_symbol = "REAG",
}

-- Liste anmelden (beim Einloggen und beim Öffnen – der Entwicklermodus kann erst später eingeschaltet werden)
function BS:SetupPruefliste()
    local P = GoldSentinelPruefliste
    if not P or not P.Register then self.PL = nil; return nil end
    -- schon echt angemeldet? (die leere Liste ohne Entwicklermodus liefert für jedes Feld eine Funktion – darum auf Text prüfen)
    if self.PL and type(rawget(self.PL, "addon")) == "string" then return self.PL end
    self.PL = P:Register("BuffSentinel", { db = function() return BuffSentinelDB end, version = BS.version,
        points = BS.PRUEF_POINTS })
    return self.PL
end

-- kann jetzt überhaupt gemeldet werden? (billig, ohne Müll – Refresh fragt das vor dem Bau des Notiz-Texts)
function BS.PLReady()
    if BS.Selftest and BS.Selftest.running then return false end
    local PL = BS.PL
    return PL ~= nil and type(rawget(PL, "addon")) == "string" and PL.Hit ~= nil
end

-- Punkt als erledigt melden – nur im echten Spiel (nicht während der Testroutine), je Sitzung höchstens einmal je Punkt
BS.plSeen = {}
-- Punkte aus mehreren Teilen (0.9.58: HEXER = Vorrat + Seelenstein; 0.9.59: JAEGER = Munition + Begleiter/Futter, Platz für ENTZ):
-- erledigt erst, wenn ALLE Teile im Spiel erschienen sind
BS.PRUEF_PARTS = { HEXER_A = "HEXER", HEXER_B = "HEXER", JAEGER_A = "JAEGER", JAEGER_B = "JAEGER" }
function BS.PLHit(id, note)
    if not id or BS.plSeen[id] then return false end
    if BS.Selftest and BS.Selftest.running then return false end
    local whole = BS.PRUEF_PARTS[id]
    if whole then
        if not (BS.PL and BS.PL.Hit) then return false end
        BS.plSeen[id] = true
        for part, w in pairs(BS.PRUEF_PARTS) do if w == whole and not BS.plSeen[part] then return false end end
        return BS.PLHit(whole, note)
    end
    local PL = BS.PL
    if not PL or not PL.Hit then return false end
    BS.plSeen[id] = true
    local ok, r = pcall(PL.Hit, PL, id, note)
    return ok and r or false
end

-- Slash-Befehl (nur Entwickler; die Prüfung macht der Befehl selbst über GoldSentinelDev:Require)
function BS:OpenPruefliste()
    if not (GoldSentinelDev and GoldSentinelDev:Require("BuffSentinel")) then return false end
    local PL = self:SetupPruefliste()
    if PL and PL.Open then return PL:Open() end
    return false
end

-- Zeilen für Testbericht und Protokoll (leer ohne Entwicklermodus)
function BS:PrueflisteLines()
    local PL = self.PL
    if not PL or not PL.ReportLines then return {} end
    local ok, lines = pcall(PL.ReportLines, PL)
    return ok and type(lines) == "table" and lines or {}
end
