-- BuffSentinel – Nachkaufen beim Händler mit einem Klick (BS-E1, Entscheid des Nutzers 16.11.2026 07:10)
-- Copyright (c) 2026 GoldSentinel. All Rights Reserved.
--
-- Bei offenem Händler, der etwas verkauft, das gerade knapp ist (Munition, Reagenzien – nur Kaufbares), zeigt BuffSentinel EINEN
-- Knopf "Nachkaufen: 800× Scharfer Pfeil für 2s 40c". Ein Klick = genau dieser Kauf, vorher Menge und Preis sichtbar.
-- Regeln (Gold-Sicherheit):
--   * Funktion STANDARD AUS (Option "Nachkaufen-Knopf beim Händler"); Obergrenze je Kauf einstellbar (Standard 1g).
--   * Nie automatisch ohne Klick, nie über der Obergrenze, nie wenn das Gold nach dem Kauf unter 1g fiele, nie im Kampf.
--   * Nie doppelt: nach dem Klick grau, bis die Taschen sich gemeldet haben (BAG_UPDATE_DELAYED) oder 5 s vergangen sind.
--   * Menge bis zum Soll, höchstens volle Stapel (bzw. volle Verkaufspakete). Preis aus den Händlerdaten (Ruf-Rabatt eingerechnet).
--   * Pakete (z. B. Pfeile zu 200): je Paket ein Aufruf BuyMerchantItem(index) OHNE Menge – das kauft in jeder Spielversion genau
--     ein Paket (vor und nach Patch 4.1 gleich, warcraft.wiki.gg API:BuyMerchantItem). Einzelware: BuyMerchantItem(index, n) mit
--     n <= GetMerchantItemMaxStack(index). So kann ein anders gedeutetes "quantity" nie ein Vielfaches kaufen.
--   * Händler mit Sonderwährung (Marken/Ehre) oder ohne Preis: nie.

local ADDON, BS = ...
local L = BS.L
local API = BS.API

BS.RESTOCK_MIN_GOLD_AFTER = 10000                  -- 1g muss nach dem Kauf übrig bleiben (Kupfer)
BS.RESTOCK_LIMITS = { 10000, 20000, 50000, 100000, 200000, 500000 }   -- wählbare Obergrenzen je Kauf: 1g … 50g
BS.RESTOCK_BUSY_S = 5                              -- grau nach dem Klick höchstens so lange (falls keine Taschenmeldung kommt)

-- Soll je Eintrag (so viel soll nach dem Kauf da sein); fehlt der Eintrag hier, wird er nicht nachgekauft
BS.RESTOCK_TARGET = {
    ammo = 1000, r_powder = 20, r_candle = 20, r_gotw = 20, r_symbol = 100, r_divinity = 5, r_ankh = 5, r_rebirth = 5,
    feathers = 20, r_fishoil = 10, r_fishscale = 10, r_teleport = 10, r_portal = 10,
}

function BS:RestockOn() return self.gdb ~= nil and self.gdb.restock == true end
function BS:RestockLimit()
    local v = self.gdb and tonumber(self.gdb.restockLimit)
    return (v and v > 0) and v or BS.RESTOCK_LIMITS[1]
end

-- Geld als Text "2g 40s 5c" (ohne Symbole, nur Zahlen und Buchstaben der Sprache)
function BS.MoneyText(copper)
    copper = math.floor(tonumber(copper) or 0)
    local g, s, c = math.floor(copper / 10000), math.floor(copper / 100) % 100, copper % 100
    local out = {}
    if g > 0 then out[#out + 1] = g .. L.MONEY_G end
    if s > 0 then out[#out + 1] = s .. L.MONEY_S end
    if c > 0 or #out == 0 then out[#out + 1] = c .. L.MONEY_C end
    return table.concat(out, " ")
end

-- Händlerware an Index i: itemID, Name, Preis je Paket, Paketgrösse, Bestand (-1 = unbegrenzt), kaufbar, Sonderwährung
local function MerchantItem(i)
    local id = API.GetMerchantItemID and API.GetMerchantItemID(i)
    if not id and API.GetMerchantItemLink then
        local link = API.GetMerchantItemLink(i)
        id = type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil
    end
    local CM = API.C_MerchantFrame
    if CM and CM.GetItemInfo then
        local info = CM.GetItemInfo(i)
        if type(info) ~= "table" then return nil end
        return id, info.name, info.price, info.stackCount, info.numAvailable, info.isPurchasable ~= false, info.hasExtendedCost == true
    end
    if not API.GetMerchantItemInfo then return nil end
    local name, _, price, quantity, numAvailable, isPurchasable, _, extendedCost = API.GetMerchantItemInfo(i)
    return id, name, price, quantity, numAvailable, isPurchasable ~= false, extendedCost == true
end
BS.MerchantItem = MerchantItem      -- für die Testroutine (T247: Händlerdaten im echten Spiel lesen, nur lesen)

-- Ware des Eintrags: Munition = die angelegte Sorte (leerer Platz -> unbekannt, nichts); sonst das gezählte Item
function BS:RestockItemFor(e)
    if e.data.supply and e.data.supply.ammo then
        return API.GetInventoryItemID and API.GetInventoryItemID("player", 0) or nil
    end
    return self.supplyItem and self.supplyItem[e.key] or (e.data.supply and e.data.supply.item) or nil
end

-- Plan berechnen: erster knapper Eintrag, dessen Ware dieser Händler verkauft. Rückgabe Tabelle oder nil.
--   plan.ok = true -> kaufbar; sonst plan.why = "limit" | "gold" | "available" (mit Text für den grauen Knopf)
function BS:RestockPlan()
    if not self:RestockOn() or not self.merchantOpen then return nil end
    if API.UnitAffectingCombat("player") then return nil end
    local n = API.GetMerchantNumItems and tonumber(API.GetMerchantNumItems()) or 0
    if n <= 0 then return nil end
    local money = API.GetMoney and tonumber(API.GetMoney()) or 0
    local limit = self:RestockLimit()
    for _, e in ipairs(self.entries or {}) do
        local sp, target = e.data and e.data.supply, BS.RESTOCK_TARGET[e.key]
        local have = self.supplyCount and self.supplyCount[e.key]
        if sp and target and e.enabled and type(have) == "number" and have < (sp.low or 0) then
            local item = self:RestockItemFor(e)
            if item then
                for i = 1, n do
                    local id, name, price, batch, avail, purchasable, special = MerchantItem(i)
                    if id == item and purchasable and not special and type(price) == "number" and price > 0 then
                        batch = (type(batch) == "number" and batch >= 1) and math.floor(batch) or 1
                        local want = target - have
                        local units = math.floor(want / batch)                  -- ganze Pakete bzw. Stück bis zum Soll
                        if type(avail) == "number" and avail >= 0 then units = math.min(units, math.floor(avail / (batch > 1 and batch or 1))) end
                        local plan = { index = i, item = item, name = name or tostring(item), batch = batch, key = e.key, price = price }
                        if units <= 0 then plan.why = "available"; return plan end
                        -- Obergrenze und 1g-Rest: Menge so weit senken, dass beides hält
                        local maxByLimit = math.floor(limit / price)
                        local maxByGold = math.floor((money - BS.RESTOCK_MIN_GOLD_AFTER) / price)
                        local fit = math.min(units, maxByLimit, maxByGold)
                        if fit <= 0 then
                            plan.why = maxByGold <= 0 and "gold" or "limit"
                            plan.units, plan.count, plan.cost = units, units * batch, units * price
                            return plan
                        end
                        plan.units, plan.count, plan.cost, plan.ok = fit, fit * batch, fit * price, true
                        plan.cut = fit < units                                    -- weniger als bis zum Soll (Grenze/Gold)
                        return plan
                    end
                end
            end
        end
    end
    return nil
end

-- Kauf ausführen (nur aus dem Klick). Plan wird neu berechnet und muss dieselbe Ware am selben Platz sein.
function BS:RestockBuy(expect)
    if self.restockBusyUntil and API.GetTime() < self.restockBusyUntil then return 0 end
    local plan = self:RestockPlan()
    if not plan or not plan.ok then return 0 end
    if expect and (expect.item ~= plan.item or expect.index ~= plan.index) then return 0 end
    if plan.cost > self:RestockLimit() then return 0 end                            -- doppelte Sicherung
    local money = API.GetMoney and tonumber(API.GetMoney()) or 0
    if money - plan.cost < BS.RESTOCK_MIN_GOLD_AFTER then return 0 end
    local calls = 0
    -- Nachkontrolle (PLAYER_MONEY): wird mehr Gold abgezogen als angezeigt, schaltet sich die Funktion selbst aus
    self.restockCheck = { before = money, cost = plan.cost, untilT = API.GetTime() + BS.RESTOCK_BUSY_S }
    if plan.batch > 1 then
        for _ = 1, plan.units do API.BuyMerchantItem(plan.index); calls = calls + 1 end   -- je Aufruf genau ein Paket
    else
        local maxStack = API.GetMerchantItemMaxStack and tonumber(API.GetMerchantItemMaxStack(plan.index)) or 1
        if not maxStack or maxStack < 1 then maxStack = 1 end
        local left = plan.units
        while left > 0 do
            local q = math.min(left, maxStack)
            API.BuyMerchantItem(plan.index, q)
            calls, left = calls + 1, left - q
        end
    end
    self.restockBusyUntil = API.GetTime() + BS.RESTOCK_BUSY_S
    self.restockLast = plan
    BS.Print(string.format(L.RESTOCK_BOUGHT, plan.count, plan.name, BS.MoneyText(plan.cost)))
    if BS.PLHit then BS.PLHit("RESTOCK", string.format("%d× %s %s", plan.count, tostring(plan.item), BS.MoneyText(plan.cost))) end
    self:UpdateRestockButton()
    return calls
end

-- Knopf am Händlerfenster (kein geschützter Knopf nötig: Kaufen ist nicht gesperrt; nie im Kampf)
function BS:RestockButton()
    if self.restockBtn or not CreateFrame or not MerchantFrame then return self.restockBtn end
    local b = CreateFrame("Button", "BuffSentinelRestockButton", MerchantFrame, "UIPanelButtonTemplate")
    b:SetSize(300, 24)
    b:SetPoint("TOP", MerchantFrame, "BOTTOM", 0, -2)
    -- Rechtsklick öffnet die Optionen im Bereich "Hilfen" (OPT-ALLE e: Optionen dort, wo sie gebraucht werden)
    if b.RegisterForClicks then b:RegisterForClicks("LeftButtonUp", "RightButtonUp") end
    b:SetScript("OnClick", function(btn, mouse)
        if mouse == "RightButton" then if BS.OpenOptions then BS:OpenOptions("hilfen") end return end
        BS:RestockBuy(btn.plan)
    end)
    b:SetScript("OnEnter", function(btn)
        GameTooltip:SetOwner(btn, "ANCHOR_BOTTOM")
        GameTooltip:AddLine(L.RESTOCK_TITLE, 1, 0.82, 0)
        GameTooltip:AddLine(string.format(L.RESTOCK_TIP, BS.MoneyText(BS:RestockLimit())), 0.8, 0.8, 0.8, true)
        GameTooltip:AddLine(L.OPT_RIGHT_CLICK_OPTIONS, 0.6, 0.6, 0.6, true)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:Hide()
    self.restockBtn = b
    return b
end

function BS:UpdateRestockButton()
    local plan = self:RestockPlan()
    local b = plan and self:RestockButton() or self.restockBtn
    if not b then return plan end
    if not plan then b.plan = nil; b:Hide(); return nil end
    b.plan = plan
    local busy = self.restockBusyUntil and API.GetTime() < self.restockBusyUntil
    if plan.ok then
        b:SetText(string.format(L.RESTOCK_BUTTON, plan.count, plan.name, BS.MoneyText(plan.cost)))
        if busy then b:Disable() else b:Enable() end
    else
        local why = plan.why == "gold" and L.RESTOCK_NO_GOLD or plan.why == "limit" and L.RESTOCK_OVER_LIMIT or L.RESTOCK_NONE_LEFT
        b:SetText(string.format(L.RESTOCK_BLOCKED, plan.name, why))
        b:Disable()
    end
    b:Show()
    return plan
end

-- Gold-Nachkontrolle: mehr abgezogen als der angezeigte Preis (+1 Kupfer Rundung) -> Funktion AUS, Meldung, Protokoll
function BS:PLAYER_MONEY()
    local c = self.restockCheck
    if not c then return end
    if API.GetTime() > c.untilT then self.restockCheck = nil; return end
    local now = API.GetMoney and tonumber(API.GetMoney()) or c.before
    local spent = c.before - now
    if spent > c.cost + 1 then
        self.restockCheck = nil
        if self.gdb then self.gdb.restock = false end
        BS.Print(string.format(L.RESTOCK_MISMATCH, BS.MoneyText(spent), BS.MoneyText(c.cost)))
        if BS.Diag then BS.Diag("NACHKAUF", string.format("abgezogen %d statt %d Kupfer – Funktion ausgeschaltet", spent, c.cost)) end
        if self.restockBtn then self.restockBtn:Hide() end
    end
end

function BS:MERCHANT_SHOW()
    self.merchantOpen = true
    self.restockBusyUntil = nil
    self:UpdateRestockButton()
    -- vorgemerkte Händler-Prüfung der Testroutine nachholen (nur Entwicklermodus, TR-ALLE D)
    if self.Selftest and self.Selftest.OnWindow then pcall(self.Selftest.OnWindow, "merchant") end
end
function BS:MERCHANT_UPDATE()
    if self.merchantOpen then self:UpdateRestockButton() end
end
function BS:MERCHANT_CLOSED()
    self.merchantOpen = false
    self.restockBusyUntil = nil
    if self.restockBtn then self.restockBtn.plan = nil; self.restockBtn:Hide() end
end
-- nach dem Kauf: Taschen haben sich gemeldet -> wieder frei, neu planen (Aufruf aus BAG_UPDATE_DELAYED)
function BS:RestockAfterBags()
    if not self.merchantOpen then return end
    self.restockBusyUntil = nil
    self:UpdateRestockButton()
end
