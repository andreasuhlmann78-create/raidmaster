# Schnittstelle AHSentinel.API (Version 1) – Vertrag zwischen AHSentinel und anderen Addons

Festgelegt von der Prüf-Sitzung am 9.11.2026 (klargestellt 19:38), umgesetzt in AHSentinel ab 0.65.50 (Datei API.lua).
ProfessionSentinel (und künftig andere GoldSentinel-Addons) benutzen sie.

Hinweise zur Umsetzung in AHSentinel:
- `API.MinProfitPct()` = Einstellung "Mindestrendite" (Sammelkauf/Entzaubern, Standard 20) – dieselbe Grenze wie "Lohnt bis"
  im Tooltip und der automatische Mindestpreis beim Verkaufen.
- `API.GoldPerHour(kind)` rechnet über die letzten 30 Tage; `"ah"` = Flippen + Rohstoffe.
- `API.Deposit` gibt `nil` zurück, wenn weder Blizzard noch ein Händlerpreis bekannt ist.
- Der frühere interne Aufruf `AHAnalyzerPro:API(name)` funktioniert weiter (heisst intern jetzt `A:Global`).

## Zugriff
- Global `AHSentinel` (neuer Name) mit Feld `API`. Alias: `AHAnalyzerPro.API` (alter interner Name, bleibt bestehen).
- `AHSentinel.API.version` = 1. Neue Funktionen nur hinzufügen, nie Bedeutung oder Rückgabewerte ändern; bei
  Bruch Version 2 mit neuem Feld, Version 1 bleibt.
- Jede Funktion ist sicher: wirft nie einen Lua-Fehler (intern pcall), gibt `nil` zurück, wenn nichts bekannt ist.
- Alle Beträge in Kupfer (ganze Zahlen), je Stück, wenn nicht anders gesagt.

## Funktionen (Version 1)
| Funktion | Rückgabe |
|---|---|
| `API.Price(itemID)` | Preis je Stück, Quelle (`"scan"`, `"market"`, `"vendor"`), Alter in Sekunden. **`"vendor"` ist KEIN AH-Preis** (nur Händler-Ankaufpreis, wenn keine AH-Daten da sind) – wer einen AH-Preis braucht, fragt dann die nächste Quelle. `"scan"` nur, wenn der Wert wirklich aus dem letzten Scan stammt (bei Ausreisser-Ersatz durch den Median: `"market"`). |
| `API.NetSale(itemID, qty)` | Netto-Erlös gesamt für qty Stück nach 5 % (bzw. 15 % neutral) und erwartetem Einzahlungsverlust, mindestens Händlerwert; 2. Wert Tabelle `{ gross, cut, depositRisk, vendorWins }` |
| `API.Deposit(itemID, qty, hours)` | Einzahlung (Blizzard-Wert, sonst Formel nach Regelwerk, Minimum gemessen statt fest) |
| `API.CutPct()` | 0.05 (Fraktions-AH) oder 0.15 (neutral) |
| `API.MaterialCost(itemID, qty)` | **Herstellkosten des Items `itemID`** (das hergestellte Produkt, nicht eine Zutat) für `qty` Stück, gesamt, über den günstigsten Weg je Zutat, AH-Zutaten über die Preisleiter für die benötigte Menge (nicht günstigstes Einzelstück × Menge, API-PM3); 2. Wert Liste der Zutaten `{ { itemID, qty, source = "ah"/"vendor"/"craft", cost } }`. Für den Preis EINER Zutat `API.Price` benutzen. (Klarstellung 9.11.2026) |
| `API.DisenchantValue(itemID)` | Wert brutto je Entzauberung, Wert netto, Anzahl eigene Entzauberungen der Gruppe, Quelle (`"own"`, `"table"`); `nil` wenn nicht entzauberbar |
| `API.BestWay(itemID)` | `"sell"` oder `"disenchant"`, Netto-Wert dieses Wegs |
| `API.SellSpeed(itemID)` | Zustand (`"fast"`, `"slow"`, `"rare"`, `nil`), Median-Stunden bis Verkauf, Absatz pro Tag am Markt |
| `API.MinProfitPct()` | eingestellter Mindestgewinn in % (Standard 20) |
| `API.GoldPerHour(kind)` | Kupfer pro Stunde und gemessene Sekunden für `"craft"`, `"disenchant"`, `"flip"`, `"ah"`, `"all"` – `nil`, solange nicht gemessen (kommt mit H9) |
| `API.LastScan()` | Zeitpunkt des letzten Scans (time()), Anzahl Items |
| `API.WorthUpTo(itemID[, qty])` | "Lohnt bis" (Kupfer, für qty Stück, Standard 1) – dieselbe Zahl wie im Tooltip, im Markt, im Sammelkauf und im Sniper (eine Rechnung `A.Core:WorthUpTo`, RK2-A); 2. Wert Weg (`"disenchant"`, mit dem Rechenkern auch `"sell"`, `"craft"`), 3. Wert `"sicher"`/`"unsicher"`, 4. Wert Sicherheit 0–1 (gemessene Trefferquote dieses Wegs, `nil` = lernt noch), 5. Wert Stückpreis. **Der 1. Wert ist die SUMME für qty Stück** (Stückpreis × qty; Bedeutung seit Version 1 unverändert) – den Stückpreis liefert der 5. Wert. `nil`, wenn nichts bekannt oder die Preise veraltet sind. (ergänzt 13.11.2026, API-PM, API-PM2) |
| `API.MarketState(itemID)` | Marktlage `"normal"`, `"aufkauf"`, `"flut"`, `"duenn"` oder `"alt"`; 2. Wert Band-Trend (Richtung): `"faellt"`, `"steigt"`, `"spitze"` oder `"ruhig"`; `nil` = nicht gemessen (bis zum Rechenkern immer `nil`). (ergänzt 13.11.2026, API-PM, API-PM2) |
| `API.ReagentsToList(spellID, n, nurFehlend)` | legt aus dem Rezept `spellID` für `n` Herstellungen eine Einkaufsliste an (`nurFehlend` = nur was in Taschen/Bank fehlt); Rückgabe ok, Meldung, Listenname. (ergänzt 15.11.2026, PS-DOCK1, 0.65.217) |
| `API.QuietOn()` | `true`, wenn der Sniper gerade im Ruhemodus ist, sonst `false`. Nur lesen, ohne Nebenwirkung (Stand, den der Sniper selbst führt). (ergänzt 15.11.2026, Wunsch ProfessionSentinel, 0.65.223) |

## Ereignis
- AHSentinel ruft nach jedem Scan und jeder Buchungsänderung `AHSentinel.API.OnChanged`-Abonnenten auf:
  `AHSentinel.API.Subscribe(fn)` – `fn(reason)` mit `"scan"`, `"ledger"`, `"settings"`. Aufrufe gedrosselt (höchstens
  einmal je 2 s), nie im Kampf-kritischen Pfad.
