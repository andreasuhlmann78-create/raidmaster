if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.7 - Twinks und Goldverlauf
--
-- Für jeden Charakter (accountweit gespeichert):
--   * Gold und Goldverlauf (ein Punkt höchstens alle 30 Min.)
--   * Inhalt der Taschen und der Bank (Bank: beim Öffnen der Bank)
-- Damit zeigt der Tooltip, wie viele Stück deine Twinks haben,
-- und die Buchhaltung, wie sich dein Gold entwickelt.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local CreateFrame, C_Timer = A.OwnCreateFrame or CreateFrame, A.OwnTimer or C_Timer      -- VS-BILD-2 (0.65.320): eigene Skripte/Zeitgeber je Bild messen (nur während einer Vollscan-Messung)
local L = A.L

local Ch = {}
A.Chars = Ch

local POINT_GAP = 1800         -- frühestens alle 30 Min. ein neuer Goldpunkt
local MAX_POINTS = 600
local KEEP_DAYS = 365

local function DB() return A.db and A.db.chars end

function Ch:Key()
    local name = UnitName and UnitName("player") or "?"
    local realm = (GetRealmName and GetRealmName()) or ""
    return name .. "-" .. realm, name, realm
end

function Ch:Me()
    local db = DB()
    if not db then return nil end
    local key, name, realm = self:Key()
    local c = db[key]
    if not c then
        c = { name = name, realm = realm, money = 0, gold = {}, bags = {}, bank = {} }
        db[key] = c
    end
    if UnitClass then
        local _, classFile = UnitClass("player")
        c.class = classFile
    end
    if UnitFactionGroup then c.faction = UnitFactionGroup("player") end
    return c, key
end

-- ------------------------------------------------------------
-- Gold
-- ------------------------------------------------------------
-- AHS-TB1 (Ingametest 26.11.: "Gestern: nichts gebucht", aber "+46g 67s 16c seit gestern"; belegt mit den Daten des Nutzers): GetMoney()
-- liefert beim Ausloggen (und kurz nach dem Einloggen) 0. RecordMoney lief auch bei PLAYER_LOGOUT und schrieb diese 0 als Goldpunkt bzw.
-- ÜBER den letzten echten Punkt (< 30 Min.) - danach zeigte "seit gestern" das ganze Gold einer Figur als Zuwachs. Jetzt:
--   * eine 0 zählt nur, wenn sie aus PLAYER_MONEY kommt UND 2 s später noch gilt (dann Punkt mit e = true: echt alles ausgegeben)
--   * beim Ein-/Ausloggen nie eine 0 schreiben; alte 0-Punkte ohne e (vor 0.65.405) zählen nicht (ValidPoint)
function Ch.ValidPoint(g, i)
    local p = g and g[i]
    if not p then return false end
    return (p.m or 0) ~= 0 or p.e == true
end
local ValidPoint = Ch.ValidPoint
-- letzter gültiger Stand einer Figur (nil = keiner)
function Ch.LastValid(c)
    local g = c and c.gold or {}
    for i = #g, 1, -1 do if ValidPoint(g, i) then return g[i].m end end
    return nil
end
Ch.ZERO_CONFIRM = 2                -- Sekunden: eine 0 aus PLAYER_MONEY muss danach noch gelten
-- Naht für die Testroutine (Blizzard-GetMoney nie ersetzen - Taint)
function Ch.GameMoney() return GetMoney and GetMoney() or nil end
function Ch:RecordMoney(fromEvent, confirmed)
    local c = self:Me()
    local money = Ch.GameMoney()
    if not c or not money then return end
    local g = c.gold
    local last = g[#g]
    if money == 0 then
        -- direkt nach dem Einloggen / beim Ausloggen meldet das Spiel 0 Gold: nie als Stand nehmen
        if not fromEvent then return end
        -- aus PLAYER_MONEY: erst nach kurzer Wartezeit bestätigen (beim Ausloggen kommt die Bestätigung nie)
        if not confirmed then
            if C_Timer and C_Timer.After then C_Timer.After(self.ZERO_CONFIRM, function() if A.db then Ch:RecordMoney(true, true) end end) end
            return
        end
    end
    c.money = money
    c.moneyE = (money == 0) or nil
    c.updated = time()
    if last and time() - last.t < POINT_GAP and (ValidPoint(g, #g) or money ~= 0) then
        last.m = money             -- innerhalb von 30 Min.: letzten Punkt anpassen
        last.e = (money == 0) or nil
    elseif not last or last.m ~= money or time() - last.t > 86400 then
        table.insert(g, { t = time(), m = money, e = (money == 0) or nil })
    end
    local cutoff = time() - KEEP_DAYS * 86400
    while #g > MAX_POINTS or (g[1] and g[1].t < cutoff and #g > 1) do table.remove(g, 1) end
    A:Fire("CHARS_CHANGED")
end

-- ------------------------------------------------------------
-- Taschen und Bank zählen
-- ------------------------------------------------------------
local function CountContainers(list)
    local out = {}
    for _, bag in ipairs(list) do
        local n = 0
        if C_Container and C_Container.GetContainerNumSlots then n = C_Container.GetContainerNumSlots(bag) or 0
        elseif GetContainerNumSlots then n = GetContainerNumSlots(bag) or 0 end
        for slot = 1, n do
            local id, count
            if C_Container and C_Container.GetContainerItemInfo then
                local info = C_Container.GetContainerItemInfo(bag, slot)
                if info then id, count = info.itemID, info.stackCount end
            elseif GetContainerItemInfo then
                local _, c, _, _, _, _, link = GetContainerItemInfo(bag, slot)
                count = c
                id = link and tonumber(link:match("item:(%d+)"))
            end
            if id then out[id] = (out[id] or 0) + (count or 1) end
        end
    end
    return out
end

function Ch:ScanBags()
    local c = self:Me()
    if not c then return end
    local bags = {}
    for b = 0, (NUM_BAG_SLOTS or 4) do table.insert(bags, b) end
    c.bags = CountContainers(bags)
    c.updated = time()
    A:Fire("CHARS_CHANGED")
end

function Ch:ScanBank()
    local c = self:Me()
    if not c then return end
    local list = { BANK_CONTAINER or -1 }
    local first = (NUM_BAG_SLOTS or 4) + 1
    for b = first, first + (NUM_BANKBAGSLOTS or 6) - 1 do table.insert(list, b) end
    c.bank = CountContainers(list)
    c.bankTime = time()
    A:Fire("CHARS_CHANGED")
end

-- ------------------------------------------------------------
-- Abfragen
-- ------------------------------------------------------------
function Ch:GetAll()
    local out = {}
    local _, myKey = self:Me()
    for key, c in pairs(DB() or {}) do
        local items = 0
        for _, n in pairs(c.bags or {}) do items = items + n end
        for _, n in pairs(c.bank or {}) do items = items + n end
        table.insert(out, { key = key, name = c.name, realm = c.realm, money = Ch.MoneyOf(c), updated = c.updated,
                            bankTime = c.bankTime, items = items, class = c.class, me = (key == myKey) })
    end
    table.sort(out, function(a, b) return a.money > b.money end)
    return out
end

-- AHS-TB1: Stand je Figur = c.money; eine 0 ohne Bestätigung (alte Daten: 0 vom Ausloggen) -> letzter gültiger Goldpunkt
function Ch.MoneyOf(c)
    if not c then return 0 end
    if (c.money or 0) == 0 and not c.moneyE then return Ch.LastValid(c) or 0 end
    return c.money or 0
end
function Ch:TotalMoney()
    local t = 0
    for _, c in pairs(DB() or {}) do t = t + Ch.MoneyOf(c) end
    return t
end

-- Bestand eines Items bei allen Charakteren: { {name, bags, bank, me}, ... }, Summe
function Ch:ItemCounts(itemID)
    local out, total = {}, 0
    local _, myKey = self:Me()
    for key, c in pairs(DB() or {}) do
        local b, k = (c.bags or {})[itemID] or 0, (c.bank or {})[itemID] or 0
        if b + k > 0 then
            table.insert(out, { name = c.name, bags = b, bank = k, me = (key == myKey) })
            total = total + b + k
        end
    end
    table.sort(out, function(a, b) return (a.bags + a.bank) > (b.bags + b.bank) end)
    return out, total
end

function Ch:Remove(key)
    local db = DB()
    local _, myKey = self:Me()
    if key == myKey then return false, L["Den eingeloggten Charakter kann man nicht entfernen."] end
    if not db[key] then return false, L["Charakter nicht gefunden."] end
    db[key] = nil
    A:Fire("CHARS_CHANGED")
    return true, L["Charakter entfernt: "] .. key
end

-- Gold aller Charaktere am Ende jedes Tages der letzten "days" Tage
-- (Wert eines Charakters = letzter bekannter Stand bis zu diesem Tag)
function Ch:DailyTotals(days)
    days = days or 30
    local out = {}
    local endOfToday = A:DayStart(time()) + 86399
    for d = days - 1, 0, -1 do
        local limit = endOfToday - d * 86400
        local total, known = 0, false
        for _, c in pairs(DB() or {}) do
            local v
            local g = c.gold or {}
            for i, p in ipairs(g) do
                if p.t > limit then break end
                if ValidPoint(g, i) then v = p.m end          -- AHS-TB1: 0 vom Ausloggen zählt nicht
            end
            if v then total = total + v; known = true end
        end
        table.insert(out, { t = limit, money = known and total or nil })
    end
    return out
end

-- Goldänderung seit einem Zeitpunkt: nur Charaktere, deren Gold damals schon bekannt war.
-- Rückgabe: Differenz oder nil (kein Vergleichswert)
function Ch:ChangeSince(limit)
    local diff, known = 0, false
    for _, c in pairs(DB() or {}) do
        local before, now
        local g = c.gold or {}
        for i, p in ipairs(g) do
            -- AHS-TB1: eine 0 ohne Bestätigung (Einloggen/Ausloggen, alte Daten) ist kein Stand
            if ValidPoint(g, i) then
                if p.t <= limit then before = p.m end
                now = p.m
            end
        end
        if before and now then diff = diff + (now - before); known = true end
    end
    return known and diff or nil
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
local evt = CreateFrame("Frame")
Ch.evt = evt            -- für die Testroutine (Ereignisse mit Testargumenten nachspielen)
for _, e in ipairs({ "PLAYER_MONEY", "BAG_UPDATE_DELAYED", "BAG_UPDATE", "BANKFRAME_OPENED", "PLAYERBANKSLOTS_CHANGED",
                     "PLAYERBANKBAGSLOTS_CHANGED", "PLAYER_LOGOUT" }) do
    pcall(evt.RegisterEvent, evt, e)
end
local bankOpen, bagsDirty, bankDirty = false, false, false
evt:SetScript("OnEvent", function(_, event)
    if not A.db then return end
    if event == "PLAYER_MONEY" then Ch:RecordMoney(true)
    elseif event == "BAG_UPDATE" or event == "BAG_UPDATE_DELAYED" then bagsDirty = true
    elseif event == "BANKFRAME_OPENED" then bankOpen = true; Ch:ScanBank()
    elseif event == "PLAYERBANKSLOTS_CHANGED" or event == "PLAYERBANKBAGSLOTS_CHANGED" then bankDirty = true
    elseif event == "BANKFRAME_CLOSED" then bankOpen = false
    elseif event == "PLAYER_LOGOUT" then Ch:RecordMoney(); Ch:ScanBags() end
end)
pcall(evt.RegisterEvent, evt, "BANKFRAME_CLOSED")
local acc = 0
evt:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    if acc < 1 then return end
    acc = 0
    if bagsDirty then bagsDirty = false; Ch:ScanBags() end
    if bankDirty then bankDirty = false; if bankOpen then Ch:ScanBank() end end
end)

-- RK4: Verzauberkunst je Figur merken (für "Entzaubern möglich" über alle eigenen Figuren)
function Ch:RecordSkills()
    local c = self:Me()
    local D = A.Disenchant
    if not (c and D and D.EnchantSkill) then return end
    local ok, sk = pcall(D.EnchantSkill, D)
    if ok and type(sk) == "number" then c.enchant = sk; D.accSkillT = nil end
end
pcall(evt.RegisterEvent, evt, "SKILL_LINES_CHANGED")
evt:HookScript("OnEvent", function(_, event) if event == "SKILL_LINES_CHANGED" and A.db then Ch:RecordSkills() end end)
A:On("READY", function()
    Ch:RecordMoney()
    Ch:ScanBags()
    Ch:RecordSkills()
end)
