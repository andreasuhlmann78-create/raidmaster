# ProfessionSentinel – Changelog

## 0.8.2
- Internal: the developer autotest names the reason when the test-mode window does not open, and only toggles groups that have rows (no more false warnings for empty rankings). Nothing changes for players

## 0.8.1
- Retail: fixed the error "Attempt to register unknown event TRADE_SKILL_UPDATE" while loading – profession events are only registered if the client knows them

## 0.8.0
- **Retail** (12.1.5 Midnight, interface 120105): ProfessionSentinel now runs in regular WoW as well – with about **10,170 recipes of every expansion** straight from the Retail client
- In Retail **every expansion is its own profession with its own skill**, like the profession window (e.g. "Midnight Leatherworking", "Classic Leatherworking") – recipes, lifeline, ranking, levelling plan to the expansion's cap, reputation, recipe alarm and reagent tooltip work there
- Retail has no QuestieDB: no vendor, drop and trainer locations (the Trainers tab is hidden there); vendor goods like threads and dyes come from Classic, new vendor prices are read by AHSentinel when you visit a vendor
- Enchanting in Retail: only "sell enchants" – the disenchant tables do not apply there
- Vendor prices: where the data knows none, ProfessionSentinel uses the price AHSentinel read at the vendor (all game versions)

## 0.7.1
- Internal: automatic in-game test for the developer (opens every tab and button for each profession, catches Lua errors and writes a report). Nothing changes for players

## 0.7.0
- **Levelling plan** (new "Plan" tab): from your skill to 75/150/225/300 – which recipe how often, with a shopping list (missing after bags and bank). One click buys exactly what is missing at the open vendor, another puts the AH reagents into AHSentinel's sniper (market value + 10 %)
- **Reputation recipes:** the tooltip shows which reputation and standing is needed – green if you have it (also new Forever factions like Kirin Tor)
- **Recipe alarm:** when a recipe you or one of your characters misses is in the AH (AHSentinel scan) you get a message with a sound; the Recipes tab lists them on top, click = sniper. On/off: `/ps alarm`
- **Guild** (data from GuildSentinel / RaidMaster): who can craft the recipe (online first), group "Nobody in the guild knows" and the **cooldowns** (transmute, mooncloth, salt shaker)
- **Recipes in your bags:** who still needs them – or nobody (then sell); **reagent tooltip:** how many recipes use an item and which of them you know (raid materials like Lava Core too)
- **Sell enchants:** right-click whispers materials and price to the customer (also with their own materials)
- Levelling: profitable recipes with a low chance no longer win just because many crafts add up – profit counts per craft × chance

## 0.6.5
- Enchanting: at the **first login** a window asks for your goal – **make gold** (default, marked), **sell enchants** or **both**. It stays open until you picked one, and you close it yourself with "Done". Until then make gold applies. Change it later with `/ps ziel` or at the top of the "Enchanter" tab

## 0.6.4
- Enchanting: no question at login any more – the default is **make gold**. Switching to selling enchants or both is optional with `/ps ziel` or at the top of the "Enchanter" tab; once per character a short chat hint explains it

## 0.6.3
- Test mode and self-test (`/ps test`, `/ps selftest`) are now only available to the developer – like in AHSentinel. For everyone else the addon works exactly the same, just without these tools

## 0.6.2
- Enchanter: "Bargains in the AH" only lists items that keep your **minimum margin when disenchanting** – exactly the ones the sniper buys

## 0.6.1
- Only for enchanters with the goal "make gold" or "both": **buy with the sniper** – one click puts the bargains (items cheaper than disenchanted) or the AH reagents of your best "craft & disenchant" recipes into AHSentinel's sniper. Max price and amount are set, you only set the budget
- **Minimum margin when disenchanting** (default 20 %): you pay at most 80 % of what the materials bring after the AH cut
- Disenchanting only lives in the "Enchanter" tab now: "Making gold" in the other professions' ranking counts selling only again
- "Craft & disenchant" now covers the recipes of **all your professions**

## 0.6.0
- Enchanting: characters with enchanting are asked once what for – **make gold**, **sell enchants** or **both**. The enchanting part follows that choice, everything else stays the same. Change it any time with `/ps ziel` or in the new "Enchanter" tab
- **Make gold:** disenchant value of every craftable item (materials minus the 5 % AH cut). "Making gold" takes disenchanting when it brings more (DE); new group **"Craft & disenchant"** – buy reagents, craft, disenchant, sorted by profit
- "Enchanter" tab: **bargains in the AH** that cost less than they bring disenchanted, and the **learned drop chances** compared with the starting values
- Drop chances learn from every disenchant – yours and those of every player with AHSentinel. Starting values for green items: 75 % dust, 20 % essence, 5 % shard (weapons the other way round)
- **Sell enchants:** all your enchants with their material cost (AH or vendor prices) and your **selling price** – you set the surcharge in % and a minimum profit
- Levelling still counts selling only
- Test mode: simulate an enchanter and cycle through the three goals

## 0.5.1
- Profit calculation deducts the 5 % auction house cut from the sale price – ranking, making gold and net per point use what you actually receive
- If the vendor pays more after the cut, the vendor value counts
- Tooltip shows AH price, AH cut (5 %) and what you receive from the AH

## 0.5.0
- Gold in the ranking: "Levelling" sorted by gold per skill point, new group "Making gold" sorted by net profit per craft – grey recipes included
- Reagent costs: vendor items at the vendor price, everything else at the AH value (also farmed material); product at the higher of AH value and vendor sell value
- AH values from AHSentinel (otherwise TSM or Auctionator); without an AH addon the ranking stays on reagents per skill point
- Rows show where the reagents come from (AH / vendor / farm) and "+10s 80c/pt"; the tooltip breaks down every reagent with price, cost, sell value and net
- Test mode: "test prices" to try the gold ranking without an AH scan

## 0.4.0
- Levelling ranking: every recipe that gives points at your skill – learned and not learned – sorted by reagents per skill point (reagents ÷ chance of a point)
- New "Ranking" tab with the full list, top 10 on top of the "Recipes" tab; recipes you still have to learn are tagged [learn] with their source
- Star on the best learned recipe in Blizzard's recipe list, hint with place and reagents per point on the profession window (click selects it)
- Recipes far above your skill no longer count as orange: missing learn levels are estimated (WoW Forever from the Era level of the same recipe)
- Classic Era: Season of Discovery recipes removed (1267 real Era recipes)

## 0.3.0
- New "Trainers" tab: every trainer of the open profession by rank – Journeyman (to 150), Expert (to 225), Artisan (to 300), specialisations – with zone, coordinates and faction; your next rank is marked
- Vendors and drop mobs in the recipe tooltip now show zone and coordinates
- Click a trainer for a waypoint; right-click a recipe for a waypoint to the nearest vendor (TomTom if installed, otherwise the game's map pin)
- Zone names in the client's language; new WoW Forever zones (Isle of Zephras, Riverlands) supported
- Test mode: trainer and waypoint checks, "test waypoint" button

## 0.2.0
- Detects the game version from the client and adapts: WoW Forever (own recipes and skill levels – many recipes turn grey sooner) and Classic Era (classic profession and enchanting windows)
- Lifeline: a thin line under every recipe (orange → yellow → green → grey) with a marker at your skill and how many crafts it takes until the next colour – in Blizzard's recipe list and in the "All recipes" panel
- Tooltip shows crafts until yellow, green and grey
- Test mode (/ps test): diagnostics, simulated skill, simulated learned state, panel without profession window, self-test (/ps selftest)
- /ps line toggles the lifeline
- Fixed swapped skill levels on a few client recipes (e.g. Charged Scale of Onyxia)

## 0.1.0
- First release for WoW Forever (Interface 16001)
- "All recipes" panel docked to the profession window, grouped like the client's categories
- Learned recipes greyed out, missing recipes in rarity colour
- Tooltips with skill levels, reagents and recipe sources (trainer, vendor, drop, quest)
- Recipe item tooltips show learned / not learned for all your characters
- 2210 recipes, 934 of them new in WoW Forever
