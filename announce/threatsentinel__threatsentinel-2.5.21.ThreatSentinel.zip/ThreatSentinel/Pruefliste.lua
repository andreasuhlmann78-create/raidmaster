-- ThreatSentinel - Prüfliste im Spiel (nur Entwicklermodus)
-- Copyright (C) 2026 GoldSentinel
--
-- Auftrag hinweis-pruefliste-im-spiel-2026-11-16 und TR-ALLE (hinweis-testroutine-alles-2026-11-17): jeder Punkt "im Client
-- prüfen" als Punkt der gemeinsamen Prüfliste (GoldSentinelPruefliste.lua, unverändert aus shared/). Jeder Handpunkt sagt
-- Wo / nummerierte Schritte / Was du siehst / Kosten; danach merkt das Addon selbst, dass er erledigt ist (Hit), oder der
-- Spieler drückt "OK" bzw. "Nicht OK".
-- Ohne Entwicklermodus: ns.PL bleibt nil, ns:PLHit/ns:PLFail tun nichts (Spieler sehen nichts, keine Kosten).
-- Während der Testroutine zählt kein Treffer (nachgebaute Daten sind keine echte Benutzung) – ausser TR-ALLE selbst
-- (Finish, nach dem Zurücksetzen).

local ADDON, ns = ...

ns.PL = nil
local hitDone = {}   -- in dieser Sitzung schon gemeldet: weitere Aufrufe kosten nur einen Tabellen-Zugriff
local failDone = {}  -- in dieser Sitzung als Fehler erkannt: ein späterer guter Fall überschreibt das nicht
local function Wipe(t) for k in pairs(t) do t[k] = nil end end

-- Die Punkte (höchstens 14). todo: Wo / Schritte / Kosten; expect: was du siehst.
ns.PL_POINTS = {
	{ id = "TR-ALLE", title = "Testroutine: alles Automatische einmal", since = "2.5.16",
		todo = "Wo: irgendwo, nicht im Kampf.\n1. Tippe in den Chat: /ts testroutine alles\n2. Nichts tun, bis im Chat \"Zusammenfassung\" steht.\n3. Tippe /reload, damit der Bericht hochgeladen wird.\nKosten: kein Gold, ca. 1–2 Minuten.",
		expect = "Im Chat \"Bereich A (1 von 12)\" bis \"Bereich U (12 von 12)\", dann \"Zusammenfassung: … bestanden\", kein Lua-Fehler. Steht dort \"Noch offen: Fenster-Prüfung\": nichts tun – sie läuft beim nächsten Händler/Post/Karte von selbst, dann hakt sich der Punkt ab." },
	{ id = "ERA-TBC", title = "Era oder TBC: Testroutine und Kampf", since = "2.5.16",
		todo = "Wo: Classic Era oder TBC Anniversary, draussen bei einem Gegner.\n1. Tippe /ts testroutine alles und warte auf \"Zusammenfassung\".\n2. Greife einen Gegner an und besiege ihn.\n3. Schau dabei auf das Fenster \"Bedrohung: …\" (Aggrometer).\nKosten: kein Gold, ca. 3 Minuten.",
		expect = "Aggrometer wie bisher mit EINER Kopfzeile, kein \"Addon geblockt\", kein Lua-Fehler. Schritt 1 wird erkannt; stimmt Schritt 3 nicht: \"Nicht OK\"." },
	{ id = "SYNC-TEST", title = "Sync-Test mit zweitem Spieler", since = "2.5.13",
		todo = "Wo: in einer Gruppe mit einem Spieler, der ThreatSentinel ab 2.5.13 hat.\n1. Tippe /ts sync test\n2. Warte etwa 5 Sekunden.\nKosten: kein Gold, 1 Minute.",
		expect = "Im Chat: \"Sync-Test: N Antworten (Gilde a, Gruppe b)\" mit N mindestens 1. Wird erkannt, sobald jemand antwortet." },
	{ id = "SYNC-ROLLE", title = "Anderer Tank erscheint unter Tank-Sync", since = "2.5.13",
		todo = "Wo: in einer Gruppe mit einem zweiten Tank, der ThreatSentinel hat.\n1. Tippe /ts einstellungen\n2. Klicke auf den Reiter \"Tank-Sync\".\nKosten: kein Gold, 1 Minute.",
		expect = "Der andere Tank steht in der Liste (Rolle, Version). Wird erkannt, sobald seine Meldung ankommt." },
	{ id = "SYNC-SPOTT", title = "Spott des anderen Tanks: übernommen", since = "2.5.13",
		todo = "Wo: Dungeon mit einem zweiten Tank (beide mit ThreatSentinel).\n1. Zieht zusammen mehrere Gegner.\n2. Ein Gegner läuft von dir weg; der andere Tank spottet ihn.\nKosten: kein Gold, ein Kampf.",
		expect = "An der Namensplakette dieses Gegners steht der Name des anderen Tanks statt einer Warnung. Wird beim ersten Mal erkannt." },
	{ id = "SYNC-NACH", title = "Sync nach dem Kampf nachgeholt", since = "2.5.13",
		todo = "Wo: WoW Forever, in einer Gruppe mit einem Spieler mit ThreatSentinel.\n1. Kämpfe mindestens 30 Sekunden.\n2. Warte nach dem Kampf 2 Sekunden.\n3. Tippe /ts protokoll und such die Zeile \"Sync\".\nKosten: kein Gold, ein Kampf.",
		expect = "\"nachgeholt\" ist grösser als 0, nirgends \"Addon geblockt\". Wird erkannt, sobald nach dem Kampf etwas nachgeschickt wurde." },
	{ id = "MARKT", title = "Marktdaten: Vollscan wird mitgelesen", since = "2.5.13",
		todo = "Wo: beim Auktionator, mit einem Auktionshaus-Addon (z. B. AHSentinel).\n1. Öffne das Auktionshaus.\n2. Starte im Auktionshaus-Addon einen Vollscan und warte, bis er fertig ist.\n3. Tippe /ts protokoll und such die Zeile \"MARKT-NETZ\".\nKosten: kein Gold, ca. 5 Minuten.",
		expect = "\"mitgelesene Scans 1\" (oder mehr) und Speicher über 0 KB, kein Ruckeln. Wird von selbst erkannt.",
		auto = function()
			if #ns:ForeignTestRunning() > 0 then return nil end   -- nie aus Testdaten eines anderen Addons (Hinweis 18.11.)
			local GM = _G.GoldSentinelMarkt
			local st = type(GM) == "table" and type(GM.Stats) == "function" and GM.Stats() or nil
			local n = type(st) == "table" and tonumber(st.scans) or 0
			if n >= 1 then return true, "mitgelesene Scans " .. n end
			return nil
		end },
	{ id = "LESBAR", title = "Forever-Dungeon: Plaketten-Messung", since = "2.5.4",
		todo = "Wo: WoW Forever, ein Dungeon, du als Tank.\n1. Kämpfe einen Kampf mit mehreren Gegnern.\n2. Tippe nach dem Kampf /ts protokoll.\nKosten: kein Gold, ein Dungeon-Kampf.",
		expect = "Eine Zeile \"LESBAR-PLAKETTEN …\" nur mit Zahlen, ohne Namen. Wird erkannt, sobald die Zeile geschrieben ist." },
	{ id = "LEISTUNG", title = "Kampf ohne Ruckeln (höchstens 16 ms)", since = "2.5.14",
		todo = "Wo: ein Dungeon, du als Tank (jedes Spiel).\n1. Ziehe eine grosse Gruppe (3 oder mehr Gegner) und kämpfe.\n2. Tippe nach dem Kampf /ts protokoll und such die Zeile \"LEISTUNG\".\nKosten: kein Gold, ein Kampf.",
		expect = "\"längster Rahmen durch ThreatSentinel x ms\" mit x höchstens 16. Wird erkannt; über 16 ms steht hier \"Fehler (erkannt)\" mit dem Wert." },
	{ id = "SPOTT-GRUND", title = "Spott schlägt fehl: Grund wird gezeigt", since = "2.5.9",
		todo = "Wo: draussen, du als Tank mit Spott.\n1. Tippe /ts log an\n2. Spotte einen Gegner, der zu weit weg ist (über 30 Meter).\n3. Tippe /ts log bericht\nKosten: kein Gold, 2 Minuten.",
		expect = "In der Zusammenfassung \"Gründe: …\" mit dem Text des Spiels (z. B. \"Außer Reichweite\"). Steht dort \"anderer Grund\": hier \"Fehler (erkannt)\", der Text des Spiels steht im Chat – abschreiben und der ThreatSentinel-Sitzung (Claude) schicken." },
	{ id = "TSMESS", title = "Messung mit dem Mess-Addon TSMess", since = "2.5.15",
		todo = "Wo: WoW Forever, in einer Gruppe mit Tank. Mess-Addon TSMess installiert: GitHub raidmaster, Ordner shared/messtest, Datei TSMess.zip.\n1. Tippe /tsmess start\n2. Mach ein paar Kämpfe mit angewähltem Ziel.\n3. Tippe /tsmess stop, dann /reload.\nKosten: kein Gold, ca. 15 Minuten.",
		expect = "Die Datei TSMess.lua (SavedVariables) enthält Messzeilen. Wird erkannt, sobald TSMess Messungen hat.",
		auto = function()
			if #ns:ForeignTestRunning() > 0 then return nil end
			local db = _G.TSMessDB
			local lines = type(db) == "table" and type(db.lines) == "table" and db.lines or nil
			if not lines then return nil end
			local n = 0
			for _, l in ipairs(lines) do if type(l) == "string" and l:find("|U|", 1, true) then n = n + 1 end end
			if n > 0 then return true, n .. " Messzeilen" end
			return nil
		end },
	{ id = "HEILER-HUD", title = "Heiler sieht das HUD in der Gruppe", since = "2.5.15",
		todo = "Wo: in einer Gruppe, du als Heiler (Rolle Heiler).\n1. /ts einstellungen, Reiter \"Anzeigen\", Abschnitt \"Kleines HUD\": Haken \"Auch als Heiler: wer hat Aggro\" ist an.\n2. Kämpfe; ein Gegner greift einen Mitspieler an.\nKosten: kein Gold, ein Kampf.",
		expect = "Das HUD zeigt, wer Aggro hat. Wird erkannt, sobald das HUD dir als Heiler im Kampf erscheint." },
	{ id = "METER-KAMPF", title = "Aggrometer auch ausserhalb des Kampfs", since = "2.5.15",
		todo = "Wo: draussen, nicht im Kampf.\n1. Klicke einen Gegner an (als Ziel), ohne anzugreifen.\n2. Gegenprobe: /ts einstellungen, Reiter \"Anzeigen\", Abschnitt \"Aggrometer\": Haken \"Nur im Kampf\" setzen.\n3. Danach den Haken wieder entfernen.\nKosten: kein Gold, 2 Minuten.",
		expect = "Schritt 1: das Fenster \"Bedrohung: …\" ist zu sehen (wird von selbst erkannt). Schritt 2: es verschwindet. Stimmt Schritt 2 nicht: \"Nicht OK\"." },
	{ id = "TESTASSIST", title = "Testassistent in Forever: n/a statt Fehler", since = "2.5.4",
		todo = "Wo: WoW Forever, draussen.\n1. Tippe /ts assistent\n2. Folge den Schritten im Fenster bis zum Ende.\nKosten: kein Gold, ca. 5 Minuten.",
		expect = "Plaketten-, HUD- und Rückhol-Schritte zeigen \"n/a\", nicht \"fehlgeschlagen\". Wird beim ersten übersprungenen Schritt erkannt." },
}

-- Anmelden (bei PLAYER_LOGIN, SavedVariables sind dann geladen). Ohne Entwicklermodus bleibt ns.PL nil.
function ns:PLRegister()
	local PL = _G.GoldSentinelPruefliste
	if type(PL) ~= "table" or type(PL.Register) ~= "function" then ns.PL = nil return nil end
	if not ns:IsDev() then ns.PL = nil return nil end
	local ok, list = pcall(PL.Register, PL, "ThreatSentinel", {
		db = function() return ThreatSentinelDB end, version = ns.version, points = ns.PL_POINTS })
	ns.PL = (ok and type(list) == "table" and type(list.Hit) == "function" and list.byId) and list or nil
	Wipe(hitDone)
	Wipe(failDone)
	return ns.PL
end

-- Die Funktion wurde wirklich benutzt -> Punkt erledigt (nie während der Testroutine, ausser force)
function ns:PLHit(id, note, force)
	local list = ns.PL
	if not list or hitDone[id] or failDone[id] then return false end
	if ns.routineRunning and not force then return false end
	hitDone[id] = true
	local ok, r = pcall(list.Hit, list, id, note)
	return ok and r or false
end

-- Die Funktion wurde benutzt, aber das Ergebnis stimmt nicht -> "Fehler (erkannt)" mit Notiz (nie während der Testroutine)
function ns:PLFail(id, note)
	local list = ns.PL
	if not list or ns.routineRunning then return false end
	local okS, s = pcall(list.State, list, id)
	if okS and (s == "ok" or s == "nok") then return false end   -- Entscheid des Spielers bleibt
	local ok, r = pcall(list.Set, list, id, "fehler", note)
	if ok and r then failDone[id] = true end
	return ok and r or false
end

-- Befund 18.11. (Prüfliste zeigte nach einem neuen Lauf noch den alten Zeitpunkt): Ergebnis eines LAUFS (TR-ALLE, ERA-TBC)
-- immer mit dem neuesten Stand eintragen – auch wenn der Punkt schon "erkannt" war. "OK"/"Nicht OK" des Spielers bleiben.
function ns:PLRefresh(id, note)
	local list = ns.PL
	if not list or ns.routineRunning then return false end
	local okS, s = pcall(list.State, list, id)
	if not okS or s == "ok" or s == "nok" then return false end
	if s == "offen" or s == "fehler" then return ns:PLHit(id, note, true) end
	local ok, r = pcall(list.Set, list, id, "auto", note)
	if ok and r and list.frame and list.frame:IsShown() and list.Refresh then pcall(list.Refresh, list) end
	return ok and r or false
end

-- "/ts prüfliste" (nur Entwickler)
function ns:PLOpen()
	if not ns:RequireDev() then return end
	if not ns.PL then ns:PLRegister() end
	if ns.PL then ns.PL:Open() end
end

-- Zeilen für Testbericht und Diagnose-Protokoll (eine Kopfzeile + eine Zeile je Punkt)
function ns:PLLines()
	local list = ns.PL
	if not list or type(list.ReportLines) ~= "function" then return {} end
	local ok, lines = pcall(list.ReportLines, list)
	return ok and type(lines) == "table" and lines or {}
end

-- Test-Zugang (Testroutine): Sitzungs-Merker leeren
function ns:PLResetSession() Wipe(hitDone) Wipe(failDone) end

ns:On("PLAYER_LOGIN", function() ns:PLRegister() end)
