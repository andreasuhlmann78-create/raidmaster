# ThreatSentinel – Changelog

## 1.2.3
- Paladin taunt reworked (detected by spell ID, not by name):
  - TBC: Righteous Defense is cast on the ally the mob is attacking (mouseover mob, otherwise your target's target)
  - WoW Forever: Judgement only counts as a taunt with Seal of Fury active; without it the nameplate shows "Seal of Fury missing"
  - Removed Hand of Reckoning (does not exist before Wrath)
- Diagnostics show the paladin taunt type and whether Seal of Fury is active

## 1.2.2
- Fixed: the addon did not load in TBC Classic Anniversary 2.5.6 (unknown event stopped loading – /ts and the minimap button were missing). Unknown events are now skipped.
- Added interface 20506 (TBC Classic Anniversary 2.5.6), so the addon is no longer marked as out of date
- The arrow in "» Name (Role)" is now shown correctly (the old character was missing from the WoW font)
- Test centre: preview nameplates in two rows, no more overlapping
- Test messages stay visible when the demo is stopped

## 1.2.1
- New **Support** button (PayPal) in the title bar of the settings window and "Support the addon" on the General page. Also `/ts donate`. It never opens by itself.

## 1.2.0
- New **test centre** (right-click the minimap button or `/ts test`): demo with preview nameplates, solo live test, every alert on its own button, simulated tank sync and live diagnostics
- Runs on Classic Era / Anniversary and TBC Anniversary as well as WoW Forever

## 1.1.0
- First release: loose mobs light up, held mobs fade out, taunt on mouseover, threat meter, tank sync
