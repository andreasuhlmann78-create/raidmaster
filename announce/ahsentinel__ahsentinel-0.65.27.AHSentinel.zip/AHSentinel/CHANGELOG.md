# AHSentinel (formerly AH Analyzer Pro) – Changelog

## 0.65.27
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchant table corrected** (source: warcraft.wiki.gg, Classic disenchanting tables): green items up to item
  level 15 give no shard – armor 80 % dust / 20 % essence, weapons 20 % / 80 %. Item level 21–25 now 75/15/10
  (weapons 15/75/10), item level 51–65 weapons 22/75/3; the other levels stay 75/20/5.
- Materials that cannot come from a group (e.g. a shard from item level 15) are no longer counted – neither your own
  (wrongly detected) results nor shared ones.

## 0.65.26
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchant in the tooltip, shorter:**
  - One line "Disenchant: expected gain ~X" (value after fees) with a small comparison ("better than selling" /
    "selling pays more") and the source: "(Ø 12)" = from 12 real disenchants (from 10 on), "(T)" = table.
  - Below it a block "Disenchant – materials (AHSentinel)": icon, name, drop chance and value per piece (AH price from
    the last scan, otherwise market value).
  - Hold Shift to see the whole calculation (actual and estimated, per material, after fees).
  - Option "Disenchant details in tooltip": short / with materials (default) / everything.
- **Disenchant results shared with all AHSentinel users:** every disenchant on every character is counted
  automatically (your alts count as your own) and shared over the public sync channel ("guild only" stays an option).
  Protection: at most 6 messages per sender and minute, materials must match the group, 1–5 pieces per disenchant,
  no jumps, duplicate messages count once. Senders are stored only as a short code, never by name.

## 0.65.25
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Collecting mail:** "Mail collected" now shows the gold you really took (e.g. 1g 56s 26c) instead of 0. The game
  often credits the gold only after the mailbox update; the addon now counts the amount of each mail it collects.
- "1 new invoices" → "1 new invoice".

## 0.65.24
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Playtest S5** now only checks what it should: the profit window against the profession window and
  ProfessionSentinel. Before, it also counted the main window over the auction house, LevelPilot and invisible
  anchors of other addons and reported a false ERROR.

## 0.65.23
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Playtest:** `/ahs playtest on` (German: `/ahs spieltest an`) – AHSentinel checks the test checklist in the game
  itself as soon as you create the situation, and only reports what is wrong (one chat line per check). It never
  opens windows, buys, posts or crafts by itself, and does nothing in combat. Active until /reload or 2 hours.
  - S1 fee in the Sell tab · S2 real fee after posting · S3 profit window · S4 disenchant in the tooltip ·
    S5 profit window covers nothing · S6 vendor button · S7 rebuild while crafting 5 items · S8 no blocked actions.
  - `/ahs playtest report` lists OK / ERROR / open and what you still need to do for the open ones. Results also go to
    the diagnostic log and to the test report for the addon check (area S). No names.
- Removed a leftover file (TestRoutine.lua.orig) from the download.

## 0.65.22
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchanting in the tooltip – actual and estimated, clearly separated:**
  - "Disenchant actual (avg of N)": only from real disenchants of this group (yours + shared): sum of the materials
    you really got × current AH price from the last scan ÷ N. Below 10 disenchants it says "(little data)", without
    any disenchant the line is left out.
  - "Disenchant estimated (table)": the previous value (table blended with results).
  - One line per material: chance (or actual frequency "x/N") × average amount · AH price from the last scan (with
    age) · market value = share; below it "after fees" (WoW Forever: AH fee 5 %, at least 1s per auction).
  - The tooltip says which value the disenchant bargains use: the actual average from 10 disenchants on, otherwise the
    estimate.
  - New option "Disenchant: per material" (on by default).

## 0.65.21
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **WoW Forever fee rule:** Forever has only ONE fee – the AH fee = 5 % of the auction's price, at least 1 silver,
  per auction (per stack), paid when posting. There is no separate deposit any more. Examples: 3s 90c → 1s,
  2s → 1s, 1g → 5s, a stack of 20 at 1c each → 1s once.
- The row "Deposit (not refunded)" is gone from the profit window and the Sell tab; there is only "AH fee (5 %,
  min. 1s)". The same rule is used everywhere: profit window, Sell tab, "Do today", bargains, flips, disenchant
  values, vendor comparison, profit calculator.
- When posting, the fee really taken from your gold is written to the diagnostic log (entry EINSTELLEN: price,
  quantity, fee) to confirm the rule in the game. The deposit measuring of 0.65.17–0.65.20 is removed. The warning when the
  fee is more than 10 % of the price stays.
- Era, TBC and Retail are unchanged (5 % on sale, deposit refunded on sale).

## 0.65.20
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profession window:** the "Best recipes" list is rebuilt at most every 2 seconds while you craft (it was rebuilt
  up to 190 times in a session); opening and switching professions stay immediate.
- **Sniper (WoW Forever):** the sniper no longer reserves commodities on its own without a key press. WoW Forever
  blocked that call ("action blocked" once per session). Commodities are bought with 2 notches: the 1st reserves,
  the 2nd buys. If WoW blocks it on another client, the addon remembers that for this client, also after /reload.
- **Mail rules to alts:** a rule with a sub-category now also works after /reload at the mailbox without visiting the
  auction house first. Rules from 0.65.11–0.65.17 are found again.
- **Buy:** the category list keeps its scroll position while you type or search, and the selected category stays
  visible. Until the auction house is opened once, Classic Era, TBC and WoW Forever show the classic order (with
  Projectile, Quiver, Reagent).
- **Sale message:** also works when the game text uses a numbered placeholder ("%1$s").
- **Profession window:** without a tab bar the profit window docks directly next to the window (only over its
  invisible border on the old window), never over visible parts. Clicking a recipe no longer turns on "show unlearned".
  In Classic Era and TBC there is no empty line where the deposit line is (WoW Forever only).
- **Deposit:** the warning says when the deposit is refunded on sale (Classic Era, TBC …). Measurements are not taken
  in test mode, an estimate of the old auction house is never stored as a measurement, the money is checked again
  shortly after posting, and the last 300 measurements go into the diagnostic log (numbers only, no names).
  "Do today – craft" deducts the deposit for the whole crafted quantity.
- Price field tooltip shows g/s/c in every language.
- Developer test routine: new area K (interface in the real client: tooltips, overlapping windows, screen, labels,
  plausible values, error loops, T191–T197) and tests T198–T202; saved recipes, window positions and watcher data stay
  unchanged during the routine.

## 0.65.18
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Vendor button no longer covers anything:** the "Sell: … items" button sat below the merchant window and covered the
  "Buyback" tab. It now sits above the merchant window, top right – never next to the "Merchant" / "Buyback" tabs.
- **Only when there is something to sell:** instead of "Sell: 0 items (0)" the button is hidden.
- **Off by default with LevelPilot:** if LevelPilot is loaded and sells grey items itself (on by default there), the
  button stays off until you turn it on yourself in the options ("Button at vendors"). Your own setting always wins.
- Test routine (developer only): T186 checks in game that the button covers no tab of the merchant window (otherwise
  FAIL), T187 checks the default with and without LevelPilot.

## 0.65.17
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Deposit is measured:** every time you post, the addon notes item, vendor price, quantity, duration, your price
  (per piece and total), the deposit the game reports and the deposit really taken from your gold, plus the ratio
  deposit/price and deposit/vendor price – in the diagnostic log (`/ahs protokoll`, entry EINSTELLEN) and in the GSDIAG1
  export, without any names. If the game does not report a deposit, the last measured one for that item is used –
  never a guess.
- **Deposit warning:** if the deposit is more than 10 % of the price, posting asks for a second click. The threshold
  is adjustable in the options (off / 5 / 10 / 20 / 30 %).
- **"Do today": below vendor price:** offers whose price per piece is below the vendor sell price (from the last scan
  or your current search) are shown as "Below vendor price: buy and sell to a vendor" – profit = (vendor price −
  purchase price) × quantity, no AH cut. Only from 10 silver profit per offer (adjustable: all / 5s / 10s / 50s / 1g),
  the best 10, sorted by profit. Items without a vendor price never appear, offers that are gone are hidden. The
  button buys only on your click, then tells you to sell to a vendor.

## 0.65.16
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Protected values:** the recipe selection and the diagnostic log ignore protected game values instead of touching them.
- Developer test routine (developer only), following the rules that proved themselves for LevelPilot: honest counting
  (checks that cannot run in a client count as skipped, never as OK; the report states "not automated: N" and lists
  everything to check in the game), each bug found in the game is its own test (recipe click without a previous click,
  the 50-second delay), bait values for protected values, the test log goes to a sandbox, test IDs are unique.

## 0.65.15
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Diagnostic log:** `/ahs protokoll` (or `/ahs log`) opens a window with a copyable log – version, client, sessions,
  changed settings, open windows and where the profit window is docked, plus entries (newest first): CLICK (recipe,
  recipe ID, way, milliseconds, success), BUILD (best-recipes list, trigger, time), SLOW (any step over 16 ms),
  OVERLAP (another window covering the profit window) and ERROR (same error only counted). On logout it is also stored
  as "GSDIAG1" for the addon check. No player, character, guild or realm names.

## 0.65.14
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profession window (modern client):** clicking a recipe in "Best recipes" selects it right away through the
  recipe list of the profession window and scrolls it into view – in the same moment, without waiting for a timer.
  Only if that is not possible the game's OpenRecipe is used; the addon checks every frame and reports in the chat
  if the recipe is not shown within 0.5 seconds.

## 0.65.13
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **WoW Forever – profit next to the profession window:** the deposit (at least 1 silver per auction, never refunded)
  is now deducted and shown as its own line: profit = value × 0.95 − materials − deposit (e.g. Copper Chain Pants 18c
  instead of 1s 18c – the same as ProfessionSentinel). The best-recipes list is ranked with it.
- **WoW Forever – bid deals** also deduct the deposit for re-selling.
- Classic Era, TBC and other versions are unchanged (there the deposit comes back on sale).

## 0.65.12
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profession window – clicking a recipe in "Best recipes" now always opens it:**
  - the list no longer rebuilds on every game event: events are collected and the list is rebuilt at most every
    0.4 s, only when something changed, spread over several frames – a click is no longer lost during a rebuild;
  - each row remembers its recipe; the click looks up the recipe again in the profession window, and if a search text,
    filter or collapsed category hides it, these are reset and the recipe is opened anyway;
  - if it still cannot be opened, a short message appears in the chat.

## 0.65.11
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Buy → categories like the Blizzard auction house:** every main category now has its sub-categories
  (Weapons → One-Handed Axes …, Armor → Cloth/Leather …, Consumables → Potions …), with the names and order of the
  game. Sub-categories open under the selected main category. Until the auction house has been opened once, the
  addon uses the item classes of the game.
- **Price field:** always shows gold/silver/copper as g/s/c ("78c", "3s 90c") in every language – never "k", which
  read like "thousand". Typing "78", "78c", "1s 20c", "1g" and the old "78k" still works.
- For ProfessionSentinel: `AHAnalyzerPro.Crafting:GetDockFrame(true)` also returns the profit window while it is hidden.

## 0.65.10
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profession window (WoW Forever):** the AHSentinel profit window no longer covers the profession tabs on the right
  side of the profession window – it now docks to the right of the tab bar. Without such a tab bar it sits where it
  always did.

## 0.65.9
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profession window:** new interface `AHAnalyzerPro.Crafting:GetDockFrame()` – returns the visible AHSentinel profit
  window next to the profession window, otherwise nil. ProfessionSentinel uses it to dock to the right of it instead of
  lying on top of it. AHSentinel itself stays directly to the right of the Blizzard profession window.

## 0.65.8
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Damaged saved data is repaired on login:** single broken entries (price history, characters, sniper targets,
  ledger, lists, recipes) are removed instead of causing a Lua error in a tab or tooltip. Healthy data stays untouched.
- Developer test routine (only for the developer): two checks that always failed are fixed (watcher with the auction
  house closed, `/ahs scan` during the routine); options and chat commands now run one per step (no "script ran too long");
  many more checks (watcher candidates, sale message, ledger from the test mailbox, re-posting, vendor, professions,
  disenchanting, characters, sync, data migration and damaged data, speed, protected AH calls) and, with the auction
  house open, simulated commodity purchase, sniper pre-reservation, batch posting, undercut detection and scan slices.
  Checks that cannot run in a client are now reported as skipped with a reason instead of OK.

## 0.65.7
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Test routine (developer only):** many more checks – every option once on and off, every chat command, all extra
  windows, main window and designs, size and position, buying and ledger maths, sniper targets and keys, watcher
  settings, watchlist, bags without the old functions, chat helpers, Esc windows in combat, errors in background
  tasks, transition from the old AH Analyzer Pro.
- Bags, mail slots and price sync now look up the client functions through one place, so the test routine can
  simulate missing functions without touching Blizzard's (no taint). Nothing changes in normal play.
- Missing "GoldSentinelTest.lua" message is now translated.

## 0.65.6
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

Fixes from the addon check:
- **Scan start keeps failing (WoW Forever, Retail):** if the server rejects the scan start permanently, the chat is no
  longer flooded (before: about 240 lines in 2 minutes). The error is shown once, the addon retries at most 3 times
  (at least 2 seconds apart), then says once that the scan could not start. The watcher continues right away.
- **Watcher:** if the server drops requests during the short pause of a wanted scan, the watcher now pauses the full
  15 minutes as intended (before it resumed after 2 minutes). Deliberately no pause just because a scan is allowed:
  the watcher would otherwise rest forever for players who never scan.
- **Profession window (modern client):** the recipe chosen in Blizzard's window is now really recognised (the event
  name was wrong), so the ingredient button never uses an older recipe.
- **Mail to alts (WoW Forever):** a rule with your own first name only ("Rokan" for "Rokan Steinwacht") no longer
  plans mail to yourself.
- **WoW Forever, protected values:** price sync, tooltip, mailbox errors, blocked actions and disenchant tracking
  ignore protected ("secret") values instead of risking a Lua error.
- Errors caught by the addon are now also counted for the addon check (GoldSentinelTest.lua); `/ahs debug` shows
  "Errors since login · Reports pending". The chat messages stay as before. Sale messages no longer swallow errors silently.
- Developer only: new test routine `/ahs testroutine` (areas a–j, `server`, `haendler`, `berufe`, `post`,
  `gildenbank`, `kampf`) with saved report. Your real data is saved before and restored afterwards; buying, posting,
  mail, vendor and price sync are only simulated. `/ahs test` and `/ahs test daten` are short forms.
- Missing translations for the classic auction house added.

## 0.65.5
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

Follow-up fixes from the addon check:
- **Full scan has priority (WoW Forever, Retail):** if you start the scan while the server is busy or a watcher search is
  still running, the scan no longer fails – the watcher pauses and the scan starts by itself as soon as the server is ready
  (at most 2 minutes). A rejected scan start works the same way. Classic Era and TBC are unchanged.
- **Profession window:** the old clients (Classic Era, TBC) read recipes at most every 5 seconds again, as in 0.65.3.
  In the modern client the chosen recipe is taken from the recipe list itself and forgotten when the window closes,
  so the ingredient button never uses an old recipe.

## 0.65.4
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

Fixes from the addon check:
- **Old "AH Analyzer Pro" (up to 0.61) still installed:** AHSentinel no longer loads next to it (both used the same
  global table – double events, double commands, possible Lua errors). Instead it asks once in chat to delete the old
  folder `AddOns\AHAnalyzerPro`. Your old data is saved for AHSentinel first. The old folder is no longer loaded before AHSentinel.
- **Watcher (Classic Era, TBC):** back to the behaviour of 0.64.2 – it no longer pauses for up to 15 minutes when the
  server reports "no full scan" (that can come from another addon).
- **Watcher (WoW Forever, Retail):** if the full scan is due and the server drops requests, the watcher pauses until the scan has run (at most 15 minutes).
- **Profession window (modern client):** a recipe list that is still empty right after opening no longer blocks reading for 5 seconds;
  the ingredient button remembers the last chosen recipe; recipe details are read only once per profession (less stutter).
- `/ahs debug` shows whether vendor costs in currency (e.g. Merchant's Favor) can be read in this client.

## 0.65.3
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **The old "AHAnalyzerPro" folder is no longer included.** AHSentinel is the only folder now.
  If you have started AHSentinel at least once, your old data is already in it and you can delete the folder "AHAnalyzerPro" from Interface\AddOns.

## 0.65.2
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **GoldSentinelGame version 2:** the shared game version detection now also wins against early versions
  that other GoldSentinel addons briefly shipped – no Lua errors when several addons are loaded together.
- Vendor prices: if the game has no item link function at the merchant, the item ID is read another way.

## 0.65.1
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Shared game version detection:** AHSentinel now uses **GoldSentinelGame**, the same detection all
  GoldSentinel addons get step by step. WoW Forever always counts as the modern client there, never as Classic.
- New: `/gsgame` shows in the chat which game version was detected; `/ahs debug` shows it too.
- Nothing else changes for you.

## 0.65.0
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**WoW Forever and Retail (modern client) – nothing stays silently empty any more:**
- **Profession window:** recipes are now read through the modern profession interface
  (`C_TradeSkillUI`) when the old one is missing – the profit panel next to the profession window and the
  crafting suggestions in "Today" work there too. Older game versions keep the old way.
- **Vendor prices:** read through `C_MerchantFrame` when the old function is missing. Items that cost
  a currency or tokens (e.g. Merchant's Favor) are remembered with their exact costs.
- **Raid supplies:** on WoW Forever the Classic raid template is used (`/ahs raid`).
- **Watcher and the 15-minute full scan:** if the server refuses the due full scan after a watcher
  round, the watcher pauses until the full scan has run.
- **Sniper:** if WoW blocks the pre-reserved goods purchase (no error, only a blocked-action event),
  "one notch buys" switches itself off and the sniper goes back to two notches.
- Translations for the WoW Forever deposit texts from 0.64.2 in all languages.

## 0.64.2
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **WoW Forever: listing fee counted correctly.** On WoW Forever every auction costs **at least
  1 silver** deposit, and it is **never refunded**, not even when the item sells. AHSentinel now
  detects Forever itself and always subtracts the fee instead of only as a risk for expired auctions:
  flips, sell suggestions in "Today", crafting profits, bargains, disenchant bargains (materials are
  sold in stacks, fee per piece), vendor-vs-AH comparison and the Sell tab (shows "not refunded").
- This mostly affects **cheap items**: an item worth 1s 50c in the AH and 71c at a vendor leaves only
  42c after 5 % and the 1s fee – "Today" then suggests **selling to a vendor**.
- Fee per piece = max(1 silver, deposit of a full stack) ÷ stack size. Other game versions are
  unchanged (the deposit is refunded on a sale).
- Profit calculator: on Forever the 1 silver deposit is included.

## 0.64.1
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **"Today" suggests crafting – even without ProfessionSentinel:** AHSentinel now remembers the
  recipes of each character when you open the profession window. "Today" then suggests the 2–3 most
  profitable recipes you **already know** (result sells well, at least 10 % profit after the AH cut).
  The button **Buy reagents** adds a buy row for every missing reagent from the auction house
  (10 % price margin, nothing bought without your click); reagents from vendors are named in the chat.
  When everything is there: "All there – craft".
- With ProfessionSentinel installed, its suggestions are used instead (no duplicates).
- Characters with a crafting profession but without ProfessionSentinel see a small tip at the bottom
  of "Today" – **Hide** removes it for good.

## 0.64.0
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**"Today" – buy and post right in the list:**
- Every row now has a **button with the next step**, no need to switch tabs:
  - Buy suggestions: **Check** looks up the item in the background; the row then shows the real
    current offer ("5x at 2g 40s each = 12g") and the button becomes **Buy 12g**. Several single
    auctions: **Buy (1/3)**, one click each (WoW needs one click per auction). Goods in the modern
    auction house: the price is reserved first, then **Confirm**.
  - **Never more expensive and never more than suggested**, and the capital protection still applies.
    If the offer is gone or more expensive, the row says "no longer worth it" and nothing is bought.
  - After buying: flips get **Post** (price suggestion with price protection), disenchant deals show
    how many are in your bags, vendor deals say "Sell to a vendor".
  - Items from your bags: **Check → Post**. Returned auctions: **Repost**, one click each.
- A click on the row itself still switches to the tab, as before.
- **For other addons:** `AHAnalyzerPro.Today:QuickBuy(itemID, qty, maxPrice, label)` and
  `:QuickSell(itemID, count)` add a row at the top of "Today" – nothing is bought without your click.
- **ProfessionSentinel:** its "craft today" suggestions appear in "Today"; the button walks you
  through buying the reagents, crafting and posting.
- Disenchant texts from 0.63.0 are now translated into all languages.

## 0.63.4
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Bargain watcher only with a reliable market value:** the watcher used to report "bargains" at 0–10 % of the market value – almost always because the market value itself was wrong (moon price, rare item, price crash). As the watcher buys with the mouse wheel, only a market value you can trust counts now.
- **Test mode log:** watcher purchases show as "Sniper buy (watcher)" with the price; goods bought from the buy tab and the sniper show the price too.

## 0.63.3
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Quality tiers (retail):** crafting reagents and crafted items come in several tiers – so far e.g. "Bismuth" showed three times with no difference. The tier icon now follows the name (buy, market, sell, sniper, ledger …).
- **Feedback after posting and cancelling:** instead of "Posting …" / "Cancelling …" staying forever, the window now shows "Posted: …" / "Cancelled: …".
- **Daily summary:** showed "+ all your gold since yesterday" when the game briefly reported 0 gold at login. Such a 0 value no longer counts.
- **Test mode log:** buying goods (retail) now shows the price, a sniper buy is logged as "Sniper buy" instead of "Buyout".

## 0.63.2
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Self-test on retail:** stopped with "script ran too long" (retail stops scripts that run too long in one go – with about 20,000 scanned items that happens). The test now pauses regularly; the language test checks one language per frame.
- **Sell tab with the auction house closed:** showed "No sellable items in your bags" on retail although the bags were full. The "can this be posted?" check now only runs while the auction house is open.
- **Reagent bag (retail):** items in it now count for selling, mail to alts and vendor selling.

## 0.63.1
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Retail (The War Within / Midnight, interface 12.x): item names are back.** The modern game no longer has the old `GetItemInfo`, `GetItemIcon` etc. – AHSentinel now uses `C_Item` there. Before, "Item #12345" showed instead of the name (buy tab, price history, tooltip, test data).
- **Names are loaded in the background:** the full scan of the modern auction house only returns item IDs. Items your client does not know yet are now requested in the background (40 per second); the lists update by themselves.
- **Self-test "Search by name"** failed on retail ("'Item #251665' -> nil"). It now picks an item whose name is already known and otherwise reports how many names are still loading.
- **Test mode on retail:** the fake auctions and mails need item names – they are created there now as well.
- Disenchanting: spell name via `C_Spell` (retail).

## 0.63.0
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Disenchanting – everyone learns together:** what comes out of a disenchant is now shared through the price sync with every player who has AHSentinel (or only your guild if you set it so). Everyone sends only their own numbers, nothing is counted twice, so the drop chances match WoW Forever's real ones much sooner.
- **New starting values for green items:** 75 % dust, 20 % essence, 5 % shard (weapons the other way round: 75 % essence, 20 % dust). Your own and the shared results adjust them from there.
- Tooltip: "Disenchant (Ø, 12 own, 340 shared)" shows how many disenchants the value is based on.
- Only which material came out how often is shared – nonsense (foreign items, impossible amounts) is rejected.
- ProfessionSentinel uses these values for its "Craft & disenchant" ranking.

## 0.62.4
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Stackable goods combined (classic auction house):** in the buy tab, all offers of a stackable item
  with the same unit price form **one row with the sum** – e.g. 5 stacks of 20 show as "100", with the
  unit price and the **total price** of the row.
- **Buy several at once:** click a row, **Shift+click** adds more rows. The box on the right shows the
  pieces, the number of offers and the total of your selection. "Buy selection" asks once with the
  total, then every click buys the next offer (WoW needs one click per auction).
- "Show single offers" switches back to the old list (also for bidding). The modern auction house
  already combines goods by price – there you simply enter the quantity.

## 0.62.3
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Item names for WoW Forever:** the built-in names of WoW Forever come first again; the Burning
  Crusade names added in 0.62.1 only fill gaps. About 2,000 items that were renamed in TBC now show
  their Forever name again in the other languages.

## 0.62.2
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Test and developer functions are hidden:** the self-test and the test mode (button "Test",
  `/ahs test`, `/ahs testmode`) are only available to the developer now. For everybody else the
  addon looks and works the same, just without these tools.

## 0.62.1
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**Realistic prices – important for a fresh server, where prices fall every day:**
- **Market value follows the market faster:** newer prices count more (half-life 3 days) instead of a
  plain 14-day median, and silly prices like "1666g 99s 98c" no longer count at all.
- **Price crash detection:** if the last two scans (at least 6 hours apart) are both far below the market
  value, the item is marked "price just crashed" (tooltip) and its market value counts as uncertain.
  Such items are no longer suggested for buying, flipping or selling.
- **"Today" sells at what you really get:** at most 5 % above the cheapest current offer, never the old
  market value. If the AH price has crashed close to the vendor price, it suggests selling to a vendor.
- **Bids** are only suggested on items with a reliable market value and never on silly prices.
- **Profit/day** in bargains counts only a share of the daily sales (you are not the only seller),
  at most the available amount and what 20 % of your gold can buy.
- The overview no longer lists prices ending in …99s 9xc.

**Fixes:**
- **Esc** closes the price history again instead of the whole auction house (also after a language switch).
- **Test mode:** a sniper purchase with the mouse wheel now shows up in the test log and the ledger.
- **Mailbox:** new button "Repost (N)" for returned auctions; on-screen messages say "[Test]" in test
  mode; collecting is slower in test mode so you can try "Stop"; returned test goods are counted.
- `/ahs summary` no longer shows "+all your gold since yesterday" when yesterday's gold is unknown.
- The money field shows what it understood for every input ("= 5s"), not only for plain numbers.
- An item tooltip no longer stays on top of a newly opened window ("Today", options, ...).
- Self-test details no longer show raw icon codes.

**Languages:**
- **About 10,000 more item names in every language,** including all Burning Crusade items
  (English: 25,800 instead of 14,800). Lists no longer show German names in an English interface.
- **Lists always show names in the current language** – search results, sniper targets, watch list,
  shopping lists, ledger, auctions – also right after switching, without a new search.
- The buy tab keeps its category, search text and filters after a language switch.
- Options: long labels (French, Spanish, Russian) wrap into a second line instead of being cut off.
- Buy filters: short placeholders ("Lvl min / max") that no longer overlap.
- Chinese: "simplified" and "traditional" can be told apart in the language list; item names without a
  Chinese name are written without umlauts (ö → oe), which the Chinese font cannot show.
- Self-test: the language check now also finds cut-off option labels, list names in the wrong
  language and counts missing item names per language.

## 0.62.0
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**AH Analyzer Pro is now called AHSentinel** – part of the Sentinel family (BuffSentinel,
GuildSentinel, ThreatSentinel).

- **Your data is taken over automatically:** the download contains the new folder `AHSentinel`
  and a small `AHAnalyzerPro` folder that only hands your old data (prices, ledger, lists,
  sniper targets, settings) over on the first start. Afterwards you can delete `AHAnalyzerPro`.
- **New command `/ahs`** (also `/ahsentinel`); `/ahp` keeps working.
- Everything else stays the same.

**Install:** copy both folders from the ZIP into `Interface\AddOns` (overwrite the old
`AHAnalyzerPro` folder), start the game, done.

## 0.61.2
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **One language for everything:** item names now follow the addon language (unless you chose a
  separate item-name language), and the tooltip shows the item name in that language when it
  differs from the game client's.
- **Language switch rebuilds every window:** besides the main window also "Today", the test window,
  the mail-to-alts rules and the mailbox panel (even while the mailbox is open).
- **Self-test:** new check "language switch" - every addon language once and then back and forth
  several times; window, tabs, texts, item names and tooltip must appear in the chosen language,
  and the original language is restored afterwards.

## 0.61.1
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fixed: "Today" suggested unrealistic purchases.** Page-by-page scans often see only part of the
  auction house, which looked like huge sales. Sales per day are now only estimated between
  **complete** scans, count only half of each drop (the rest expired or was cancelled) and never
  more than half of what is usually listed. "Price change since scan" also compares complete scans only.
- **Capital protection:** each suggestion in "Today" uses at most 20 % of your gold, all of them
  together at most half; the window shows the capital needed. The self-test checks this.
- **Overview:** rises to several times the market value and drops from a former moon price are no
  longer listed.
- **Mailbox:** the addon's buttons now sit in a tidy panel **next to** the mailbox instead of over
  its frame. "Collect all" is only shown when WoW has no "Open all" button of its own (and in
  test mode for the test mail), "Stop" only while collecting.
- **One money field instead of three:** type "5s", "1g 20s", "4s 85c" or "1.5" (= 1g 50s); a plain
  number shows what it means ("= 5g"). No more silver ending up in the gold field.
- Smaller things: "Bid" without a selected listing says so, the vendor warning when posting only
  appears when it matters (at least 1 silver and 10 %), fictional auctions show up in test mode
  right away, the "Today" window closes when you jump to a tab.

## 0.61.0
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**More profit, fewer fake bargains:**

- **"Today" (button in the overview, `/ahp today`):** the actions that bring the most gold right
  now, ranked by estimated net gold - buy below vendor price, flips, selling what is in your bags,
  undercut auctions, items to repost, disenchant and bid deals. Click a row to jump straight to
  the right tab.
- **Sell-through instead of listing prices:** from your scans the addon now estimates how much of
  an item actually sells per day and whether its market value can be trusted. Items that are
  rarely listed or only have "moon prices" (like 2499g 99s 99c) are hidden from bargains, flips and
  the overview (button "also unsure" shows them). Bargains are sorted by **profit per day**, the
  tooltip shows "~N/day sold (estimated)".
- **Net profit with the posting fee:** on the classic auction house the fee is now estimated from
  the vendor price ("approx.") and learned exactly the first time you really post. Profits subtract
  the fee you lose when an auction comes back (based on your own sell rate).

## 0.60.11
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Mailbox buttons always answer:** "Mail collected: ..." now also appears in the middle of the
  screen, and an empty mailbox says "Nothing to collect" instead of staying silent.
- **"To alts" without a rule** says so in the chat before opening the rules window.
- **Test mode:** the fictional "sold" mail belongs to the fictional sold auction, and that auction
  disappears from "My auctions" once its money is collected - like in the game.

## 0.60.10
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Test mode with fictional auctions:** "My auctions" now shows three fictional auctions (one
  undercut, one cheapest, one sold) plus everything you post in test mode - so cancelling and the
  undercut check can be tried without a real auction. The self-test uses a fictional auction for
  "cancel" when you have none.
- **Test mailbox:** in test mode the mailbox buttons of the addon work with fictional mail (sold,
  won, expired, cancelled, outbid, a normal letter): auto-collect, "All", ledger invoices and the
  repost list can all be tried - your real mail stays untouched.
- **Buy tab:** the bid field and the selected listing are reset when you switch to another item
  (no more old bid in the field). The header shows the cheapest listing and the market value
  (median 14 days) separately, and says when more listings are still loading.
- **Sniper:** listings of the previous target are no longer shown under the new target's name.
- **Self-test:** the sniper test buys (simulated) the smallest stack instead of a 2-stack.
- **Price history window:** can be dragged by its title.

## 0.60.9
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Message when the scan is done:** a large message in the middle of the screen ("AH scan done:
  N items") plus a sound (if alert sounds are on in the options) - you no longer have to watch the
  chat. A scan without results is shown there too.

## 0.60.8
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fixed: no price lines in item tooltips** on some clients (e.g. TBC Anniversary). The addon
  now hooks every way WoW fills an item tooltip and resizes the tooltip after adding its lines.
  The self-test now checks the real bag tooltip.
- **Esc closes only the top window:** e.g. the price history window - the addon window and the
  auction house stay open (before, one Esc closed everything).
- **Price history window:** the close button no longer sits on top of the "All" button.
- **Test mode** now also restores search favorites, repost list and mail rules.
- **Your own searches come first:** a running watcher round is stopped so the buy tab no longer
  waits ("Waiting for the watcher ...").
- Buy tab shows "Bought: ..." instead of "Purchase in progress ..." when done.
- Overview: tenfold price jumps (almost always bogus data) are no longer listed as rises/drops.
- Smaller fixes: test mode log shows sniper buys as such, shopping lists release the keyboard after
  deleting a list, no "N entries" overlap in the lists window, shorter option label "Expiry
  reminder", posting fee on classic AH shows "when posting" instead of "?", iLvl filter hint only
  when there are results, faster mouse-wheel scrolling in the report window, report title
  "Test report".

## 0.60.7
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **New "Test" button** at the top of the window (and in the auction house bar): self-test and
  the new **test mode** in one window.
- **Test mode:** try every feature by hand with your real auction house data - buy, bid, sniper
  (mouse wheel too), post, cancel, vendor sale, collecting and sending mail. Every trade is only
  simulated: the command to the server is intercepted and the server's answer is played back, so
  messages, ledger and sniper counters behave like the real thing. All settings and data (lists,
  ledger, sniper, watcher, selling) are restored when you stop test mode - or automatically after
  a /reload or crash. A log shows every simulated action and is included in the copied report.
  Note: only the addon's buttons are simulated, Blizzard's own auction house buttons still buy
  for real. Also: `/ahp testmode`.

## 0.60.6
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Self-test simulates real trading:** with the real auction house listings it now runs instant
  buy, bid, sniper buy, posting and cancelling exactly like the real thing - same listing, same
  price, same command. The command to the server is intercepted, so nothing is bought, posted or
  cancelled; the test finally checks that your gold is unchanged. Chat messages during the
  simulation are marked "[Simulation]".
- **Self-test:** the watcher is switched off again right after its test round, so it no longer
  blocks the following server searches.

## 0.60.5
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fixed (classic clients):** a Lua error "attempt to compare number with nil" could appear when
  opening the auction house (bid tracking after a reload).
- **Watcher/Sniper status in the header** now always updates when you switch them on or off.
- **Self-test:** a market scan still running in the background no longer makes all server
  searches time out - in the "saved data" mode it is stopped, otherwise the test waits for it.
  Starting a scan during the test is blocked.
- **Self-test:** settings, the watcher and the window (tab, or closed) are restored reliably
  after the test; if something can't be restored, the report says so.
- **Text window** (copy report) now always opens in front, starts at the top and scrolls
  quickly with the mouse wheel (hold Shift for big steps).

## 0.60.4
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Self-test with saved data:** new button "With saved data" in the self-test window (or
  `/ahp test saved`). It tests with the auction house data you already scanned - no new scan.
  It even runs with the auction house closed; the server searches are then skipped.

## 0.60.3
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix for TBC Anniversary (and other classic clients):** "My auctions" never updated and some
  auction house messages (e.g. "auction posted") never arrived. These clients know the event names
  of the modern auction house but never fire them for the classic one; the addon now always uses
  its own events there. Found by the new self-test.
- **Self-test:** the copied report can now be scrolled, and the result list is wider - hover a
  row to see the full text.

## 0.60.2
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Self-test:** Options -> "Self-test" or `/ahp test` checks every feature with real data from
  your auction house: market scan (if needed), market data, every tab, all calculations and real
  server searches (Buy, price check, Sniper, Watcher, your auctions). Buying, bidding, posting and
  cancelling are locked while it runs; your settings and sniper targets are restored afterwards.
  The result is shown in a window, can be copied as a report and is saved in the SavedVariables.

## 0.60.1
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Real minimap button:** the button now sits on the minimap like with other addons - drag it
  around the minimap with the mouse, the position is saved. Works with round and square
  minimaps. Hide or show it in Options or with `/ahp minimap`; `/ahp reset` brings it back.
- **New icon:** a golden scale - on the minimap button, in the title bar and in the addon list.

## 0.60.0
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**Tidier window - 5 tabs instead of 11:**

- **Overview · Buy · Sell · Market · Ledger.** Related pages are now sub-tabs:
  Buy = Buy, Sniper, Watcher, Bargains · Sell = Post, My auctions · Market = All prices, Watchlist.
  Every feature is still there, nothing was removed.
- **Price history in its own window:** clicking an item opens the price history next to the
  addon - the list you came from stays exactly where it was. The window can be moved and resized.
- **Sniper and watcher in the title bar:** see at a glance whether they are running and turn them
  on or off with one click (right-click opens their tab).
- **Remembers where you were:** the addon opens on the tab you used last, and every main tab
  remembers its last sub-tab.

## 0.59.33
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

**Comfort update - twelve small things that save clicks every day:**

- **Stack size and number of stacks** (classic auction house): in the Sell tab, choose e.g.
  5 stacks of 20. Remembered per item and used by "Post all".
- **Collect mail automatically:** opening the mailbox collects auction mail right away
  (hold Shift while opening to skip). Can be turned off in Options.
- **Minimum price per item:** the new "Min" button in the Sell tab remembers the current price
  as a floor. The suggestion never goes below it, and "Post all" waits instead of selling cheap.
- **Only what I'm missing:** next to your profession window, a new button puts only the missing
  materials on a shopping list - counting your bags, bank and alts.
- **Alt-click an item** in your bags or a link in chat: opens the price history, or the Buy tab
  while the auction house is open.
- **Sell rate in the tooltip:** how much of what you posted actually sold (last 60 days) and how
  long it usually took.
- **Expiring auctions:** a message when your auctions have less than 30 minutes left, and at
  login what expired since your last visit.
- **Favorites in the Buy tab:** save searches (text, category, level, iLvl, rarity) and run them
  again with one click.
- **Gold goal:** set a goal for all characters together (Options or `/ahp goal 5000`) and get a
  message when you reach it. The daily summary shows your progress.
- **Guild bank value:** new view Ledger -> "Guild bank" shows what is in your guild bank and what
  it is worth (TBC and later).
- **Raid supplies:** one click creates a shopping list with potions, flasks, elixirs and buff
  food for a raid week (Classic, TBC, Wrath) - with the total cost. Also `/ahp raid`.
- **Price sync with your guild only:** new option to share prices only with your guild.

## 0.59.32
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **No more absurd profits:** items that would show a profit of 1000 % or more (almost always
  bad data such as an outlier market value or placeholder prices) are no longer listed in the
  Profit tab (all views: market value, vendor, disenchant, bids, flips) and no longer appear
  under "Biggest price increases" in the Overview.

## 0.59.31
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Item level as a search filter:** the Buy tab and the Market tab now have "iLvl from" /
  "iLvl to" fields. They filter the results instantly, without a new search on the server,
  and also apply to the single listings of an item. In the Buy tab you can also search with
  only an iLvl range.

## 0.59.30
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sell junk at vendors:** at any vendor a button below the window sells grey items and
  everything a vendor pays more for than the auction house (after the AH cut). The tooltip
  lists what will be sold. Can be turned off in Options.
- **Inventory value:** new view **Ledger -> "Assets"** shows what your bags, bank and alts are
  worth (market value and vendor value), plus the gold of all characters.
- **Daily summary at login:** once a day the chat shows yesterday's profit, the last 7 days,
  the gold of all characters and how many items are waiting to be reposted. Any time with
  `/ahp summary`. Can be turned off in Options.
- **Repost with one click:** expired or cancelled auctions that came back by mail are
  remembered. In the Auctions tab, "Repost (n)" posts them again one click at a time,
  undercutting the current price, with price protection.
- **Flip recommendations:** new view **Profit -> "Flips"**: items that are listed regularly and
  are currently well below market value. Stars show the turnover, sorted by expected profit.
- **Mail to alts:** set rules like "Herbs -> Alchemist" (Options -> Mail to alts). At the mailbox
  the "To alts" button sends one mail per click with up to 12 matching stacks.
- **Buy tab:** the iLvl column now shows the item level for every item (also for items the
  game had not loaded yet) and can be sorted.
- **Sell tab - listings appear faster:** listings show up while they are still loading, a click
  on an item now goes before the bargain watcher and sniper, and hovering over an item already
  starts loading its listings.
- **Chat help:** `/ahp help` (or `/ahp ?`) lists all commands in the chat. Unknown commands show
  the list too.

## 0.59.29
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Bid sniping:** new view **Profit -> "Bids"** lists auctions whose next bid is far below
  market value, with the time left. They are collected during the full scan (classic auction
  house) and every search in the Buy tab. Click an item to open it in the Buy tab and bid.
  (Thanks paladriel for the idea!)
- **Price protection when posting:** warns if your price is far below market value or follows a
  suspiciously cheap single unit - a second click is then needed, and "Post all" skips such items.
  Threshold in Options (off / 20 / 30 / 40 / 50 %, default 40 %).
- **Sale notification:** as soon as one of your auctions sells you get a message with the
  proceeds after the AH cut and your profit compared to what you paid, plus a coin sound.
  Can be turned off in Options.

## 0.59.28
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Support button:** if you like the addon, you can now support it with a small donation.
  The "Support" button in the addon window (also in Options and via `/ahp donate`) shows the
  PayPal link ready to copy. Thank you!

## 0.59.27
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Own window by default:** the addon now opens in its own window, detached from the auction house.
  The "AH Analyzer" tab at the auction house shows/hides it. You can still embed it in the
  auction house window: Options -> "Show in auction house".
- **Resizable window:** drag the bottom-right corner to make it as big as you like - all lists
  grow with it. The size and position are saved. Text size: Options -> "Text and content size".
  "Positions" in the options resets window size and position.

## 0.59.26
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Profit tab: column names fixed** (thanks paladriel!). The comparison column was renamed in the
  wrong place since the iLvl column was added - now "Market value" / "Vendor price" /
  "Disenchant value" are on the right column, and the price column is called **"Current buyout"**
  (cheapest buyout at the last scan), so it can't be mixed up with the 14-day market value.
- **"Search in auction house"** (right-click menu) now works on the classic auction house
  (Classic Era, WoW Forever, TBC, Wrath) - it opens the Browse tab and searches for the item.
  It also switches back from the AH Analyzer view first on every client.

## 0.59.25
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper shows the total amount** below the offer list: how many units of the sniped item
  will be bought in total (up to your target quantity, budget and gold), the total cost,
  the average price per unit and how many purchases (wheel notches) that takes.

## 0.59.24
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Mouse-wheel buying now also works over the addon window** (lists, charts, the whole
  AH Analyzer area): while a hit is waiting, the wheel buys it instead of scrolling.
  When nothing is waiting, the wheel scrolls the lists as usual.

## 0.59.23
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Fix: buying with the mouse wheel didn't work on the classic auction house** (Classic Era,
  WoW Forever, TBC, Wrath) since 0.59.20. There you can only buy what is in the auction house's
  current result list - and Sniper and Watcher kept searching on. Now, while a hit is waiting:
  it stays in the list (on the right result page, loaded in advance), the Sniper only re-checks it,
  the Watcher waits, and the sound keeps repeating until you buy it or it is gone.
- **Options -> "Sniper buys with" / "Watcher buys with":** choose mouse wheel (default) or your own
  key, separately for Sniper and Watcher hits. The same key for both buys whatever hit is waiting.

## 0.59.22
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Back button in the price history:** when you open an item's price history from another tab
  (e.g. Market, Overview, Buy, Watchlist), a "< Market" button next to the title takes you back -
  to the same page and sorting of the list you came from.

## 0.59.21
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Self-adjusting search speed - always at the limit of the server.** Where the server reports
  when it is ready (modern auction house and the classic one), the addon adds no delay of its own.
  Where it doesn't, the delay shrinks after every answer and doubles when the server drops a request,
  so Sniper, Watcher, Buy tab and price checks automatically run as fast as each WoW version allows.
  The Watcher no longer waits 2 seconds between rounds.

## 0.59.20
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Sniper and Watcher search as often as the auction house allows.** The Sniper searches your
  targets, the Watcher looks for lucky bargains in the categories - they take turns
  (Sniper, Watcher, Sniper, ...) so neither one blocks the other.
  The Sniper's default interval is now "max." (Options -> "Sniper searches every").
- **After a hit the Sniper keeps searching:** the hit stays buyable with the mouse wheel / your key,
  and the sound repeats every few seconds as long as it is there (chat message only once).
- Your own actions always come first: a search in the Buy tab and price checks in the Sell tab.

## 0.59.19
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Watcher searches much more often:** instead of a fixed round every 20 seconds it now starts
  the next round as soon as the server allows (2 s pause). It takes turns with the Sniper and
  always lets your own searches in the Buy tab go first, so nothing else gets slower.
- **Watcher on the classic auction house** now reads all result pages - before it stopped after
  the first page and only saw the rarest (usually most expensive) items.
- **Bait offers (single items at the very bottom) are no longer shown** anywhere - not in Buy,
  Sniper, Sell price check or the Watcher list. They are still ignored for prices, and when buying
  commodities the price shown already includes them (the server always sells the cheapest units first).

## 0.59.18
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Pages in every table:** above each list there is now a page bar
  ("6280 entries  < 1 2 3 ... 370 >"). Click a number to jump straight to that page,
  < and > go one page back/forward. The mouse wheel and the scrollbar still work as before.
  Narrow lists show a compact "< 3 / 20 >".

## 0.59.17
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- In every item list (Buy, Market, Overview, Watchlist, Sell, Auctions, Profit, Charts,
  Ledger ...) clicking the **Item** column now sorts by **rarity first, then by name**
  (epic, rare, uncommon, common, poor - click again for the reverse order).
- New **iLvl** column in all item lists (item level of weapons and armor), sortable.

## 0.59.16
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Buy tab shows results **instantly**: clicking a category (e.g. Metal & Stone) immediately lists
  every item of that category from your last market scan (price and quantity in grey = not yet
  confirmed). The live search runs in the background and replaces them page by page with the
  real current offers - on the classic auction house that takes a few seconds per page.
- Clicking an item while a category search is still running now opens its offers right away
  instead of waiting for the category search to finish.

## 0.59.15
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Buy tab is much faster when switching categories (e.g. Herbs <-> Cooking):
  - a new search now cancels the running one immediately - before, it waited until the old
    search had read all its pages (several seconds each on the classic auction house);
  - results are remembered for 3 minutes, so switching back shows them instantly.
    The *Search* button (or Enter) always loads fresh data from the server.

## 0.59.14
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Classic Era / classic auction house:** "Your client does not support auction house search
  (SendBrowseQuery missing)" is gone - the classic auction house (Classic Era, TBC Anniversary,
  Wrath) is supported since 5.9.12; this is the first public release that includes it.
- **Size:** new option *Options -> Size in auction house* (100-160 %). Above 100 % the addon
  extends past the auction house to the right and down and everything (text included) gets
  bigger. A "<" button at the top leads back to the auction house. The separate window grows too.
- **Works next to TSM, Auctionator & co.:** the "AH Analyzer" tab now moves next to the
  right-most tab, including tabs that other addons add later - no more overlapping tabs.
  Clicking another addon's tab now closes the AH Analyzer view.
- Buy tab (classic auction house) now reads all result pages - before, it often showed only
  epic items.
- Tables: the scrollbar can be dragged with the mouse.

> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- Fix (Classic auction house): the Buy tab only showed epic items - it stopped after the
  first result page. It now reads all pages (with a "page x of y" progress) and shows
  results while it is still searching.
- Tables: the scrollbar can now be dragged with the left mouse button, and clicking into
  the bar jumps there.
- Charts: tiny price changes no longer look like a crash; axis labels show silver/copper
  when needed.
- New tab **Buy** (right next to Overview) - works like the auction house's own Buy tab:
  - Search by name (part is enough) and/or category on the left (weapons, armor,
    containers, consumables, trade goods with cloth/leather/metal/herbs/cooking/
    elemental/enchanting, gems, recipes, miscellaneous), level from/to, rarity.
  - Results with available quantity, cheapest price per unit and % of market value.
  - Click an item to see all listings. Commodities: enter a quantity or click a price
    tier, "Buy now" gets the price from the server, "Confirm purchase" buys.
    Bait offers are marked. Gear: buyout (second click confirms) or place a bid.
  - Purchases are booked in the ledger right away. Sniper, price checks and the watcher
    wait while you search in the Buy tab.
- The addon window is now exactly as large as the auction house window (measured every
  time the auction house opens, also with UI scaling). Options > Window size: "like AH"
  switches it back on, - / + sets the size by hand.
- The addon window is always exactly as wide and as high as the auction house window
  (measured every time the auction house opens, UI scaling included; also the wide classic
  auction house). Options > Window size now only
  changes options, help and lists.
- Better use of space in every tab: lists and tables now stretch to the full width and
  height of the window (more rows, wider name column) - in the auction house and in the
  separate window. Fixed: the watchlist button and the chart item list reached past the
  bottom edge.
- No more stutter when scanning a big auction house: the scan only counts results while
  it runs, the evaluation afterwards (prices, bait check, names, price sync) runs in small
  portions over several frames, long lists are built and sorted in the background and at
  most once per second. In a test with 12,000 items the longest frame dropped from about
  660 ms to under 50 ms. Classic auction house: the full list is read in time slices too.
- Auction house view fills the whole auction house window (also the wider classic auction
  house in Classic Era / Anniversary), covers the classic search row and is no longer
  see-through.
- Nicer lists: every item list shows the item icon and the name in its rarity color;
  the cards in Overview and Ledger have icons and use the full width.
- Rarity is now a drop-down menu with check boxes (Poor, Common, Uncommon, Rare, Epic -
  any combination, e.g. only Uncommon and Epic) in the Buy tab and for sniper targets;
  older sniper targets keep their range. The sniper filter row (rarity, item level, level) is
  always visible now. New: rarity filter for the item list in Charts.
- Fresh look: every tab has its own icon in the title with a fading gold line; tables have
  a gradient header with a gold rule, a soft hover glow and a gold bar on the selected row;
  panels and cards get a subtle sheen and an inlaid border; charts show a soft gold area
  under the price line and highlight the current price.
- The separate addon window takes exactly the width and height of the auction house window.
- The sniper filter row (rarity, item level, level) is always visible.
- Auction house view: slightly narrower scan button so all eleven tabs fit in every language.

## 5.9.12
> ⚠️ **This is a beta version.** Please report errors in the comments on CurseForge,
> ideally with the Lua error message and the WoW version you play on.

- **Classic Era, TBC Anniversary and Wrath Classic:** the addon now works with the classic
  auction house. Fixes "Your client does not support the auction house search
  (SendBrowseQuery missing)".
  - Market scan reads the whole auction house at once (when the server allows it every
    15 minutes), otherwise page by page.
  - Price check, sniper (items and search terms), bargain watcher, buying, posting,
    your auctions and cancelling use the classic auction house functions.
  - Stackable goods are posted as full stacks (e.g. 35 linen cloth = one stack of 20,
    the rest with the next click). The deposit is not shown in the classic auction house.
- WoW Forever, Cataclysm Classic, Mists of Pandaria Classic and Retail are unchanged.

## 5.9.11
> ⚠️ **This is a beta version.** It may still contain bugs.
> If you run into any errors or unexpected behavior in-game, please report them in the comments on CurseForge, ideally with the Lua error message (if any) and the WoW version you play on.

- Updated version number to 5.9.11.
- Supports all WoW versions: Classic Era, WoW Forever, TBC Anniversary, Wrath Classic, Wrath Titan Reforged, Cataclysm Classic, Mists of Pandaria Classic and Retail.

## 5.9.1
- TOC: interface numbers for every WoW version (Classic Era, WoW Forever, TBC Anniversary,
  Wrath, Wrath Titan Reforged, Cataclysm, Mists of Pandaria Classic, Retail) - the addon
  is no longer listed as "out of date" there.

## 5.9
- Bait offers: a single unit at the very bottom of a commodity (linen cloth,
  copper bars ...) is treated as bait and ignored everywhere - sniper (no hit,
  status "bait offer"), sell suggestion and undercut check, market value,
  trends, bargains, EMAs and price sync. Gear is not affected.
- After every scan, suspiciously cheap commodities (below 70 % of market value)
  are stored as "unverified" and re-checked with a single search; the real
  price replaces them. Unverified prices never count and are not shared.
- Note: when buying commodities the server always sells the cheapest units
  first, so on a real hit the bait unit is bought along (and included in the
  planned cost).
- Charts: time-based EMAs over 6 hours, 1 day and 7 days (real prices only,
  from 10 prices on), markers where the 1-day EMA crosses the 7-day EMA,
  grey points for unverified prices. On/off button.
- New tab "Watcher" (bargain watcher) next to the sniper: searches trade goods
  (herbs, metal & stone, cloth, leather, enchanting, elemental, gems, cooking,
  optional consumables - never weapons/armor) for prices at or below x % of
  market value (default 50 %, minimum value per unit 10 copper). All categories
  run in one search, with automatic fallback to one category at a time. Every
  hit is verified (bait offers don't count), announced with sound and chat,
  and bought with the same mouse wheel / key as the sniper.
- Speed: search results are evaluated as soon as the server reports them,
  the server's own throttle is used instead of fixed waits (0.3 s instead of
  1.5-2 s between searches), automatic slow-down on errors. /ahp debug shows
  the speed.
- Sniper and watcher buy commodities with ONE mouse wheel notch: on a hit the
  price is fetched from the server in advance (and refreshed while the hit
  waits), the first notch buys right away. If the price has risen meanwhile,
  nothing is bought and a new search starts. If the server gives no price
  confirmation, it switches back to two notches by itself.
- In the auction house the options button is now a gear icon, so all ten tabs
  fit in every language.

## 5.8
- Disenchant values learn: every disenchant you do is recognised (spell + loot
  window) and remembered per group (quality, item level band, armor/weapon).
  The table values count as 10 imaginary disenchants; with each real one your
  results weigh more (50 % after 10, 83 % after 50, 91 % after 100), so chances
  and amounts move towards the reality on your server.
- The tooltip shows how many of your own results went into the value; the
  options show the total and can reset it.
- Starting values for green items as observed in the WoW Forever beta:
  70 % dust, 25 % essence, 5 % shards on every item level band (weapons
  mirrored: 70 % essence, 25 % dust).

## 5.7
- Mailbox: "Collect AH mail" takes gold and items from all auction mail with one
  click ("All" for every mail, COD is never paid). Invoices are booked first,
  stops when your bags are full.
- Sell tab: "Series" posts every bag item with a remembered price, one click per
  auction. Fresh prices are loaded at the start; items are skipped if the price
  falls below 70 % of your last price or a vendor pays more.
- Vendor buy prices are read automatically at every merchant: used for profession
  material costs, shopping lists (items cheaper at a vendor are not sniped) and
  shown in the tooltip.
- Alts & gold: gold, bags and bank of every character (account-wide). The tooltip
  shows how many your alts have; the Ledger tab has a "Gold" view with all
  characters and the gold of the last 30 days.
- Ledger "Statistics": sell-through per item, sales by time of day and weekday,
  best selling hours.
- Disenchant value (Classic table, estimates) in the tooltip and a new Profit view
  "Below disenchant value".

## 5.6
- Shopping lists: named lists of items and quantities. "Check prices" loads all
  listings at once, "As sniper targets" creates a target for every missing item
  (max price = 100/110/125/150 % of the market value). Items already in your bags
  are subtracted. Open via the Sniper tab, right-click on an item or `/ahp lists`.
- Professions: a window next to the profession frame (incl. Enchanting) shows
  material cost, value of the result and profit after the AH cut, plus the best
  recipes. "Materials as shopping list" puts the reagents for N crafts on a list.
- Help pages for all new tabs in all languages.

## 5.5
- New tab "Ledger": income (after the 5 % AH cut), spending, deposits and profit
  for today / 7 days / 30 days / all, per item or as a history.
  Sales and purchases are read from the invoices in your mailbox (just open it),
  sniper purchases and deposits are booked right away - nothing is counted twice.
- Sell tab warns when the price is below your average purchase price.

## 5.4
- New tab "Sell": items from your bags, price check, suggestion that undercuts the
  lowest listing (by 1 copper, 1 % or 5 %), quantity, duration, deposit, AH cut and
  proceeds. Warns (and asks for a second click) when a vendor pays more.
- New tab "Auctions": your auctions with status (lowest / tied / undercut / sold),
  "Check undercuts" and cancel with one click per auction.
- Tabs inside the auction house window shrink to fit in every language.

## 5.3
- Market value = median of the last 14 days (single outliers barely count).
- New column "% market" in the Market and Sniper tabs, coloured green to red.
- Vendor price in the item tooltip (can be turned off in the options).
- Profit tab: bargains below market value or below vendor price; a vendor bargain
  becomes a sniper target with one click. After every scan the chat shows how
  many items are listed below vendor price.
- Column headers explain themselves on mouse-over. CSV export has market value
  and vendor price.

## 4.9 – 5.2
- Prices and a small price chart in every item tooltip.
- The addon as its own tab inside the auction house window.
- Money shown with coin icons or letters.

## 4.8
- The addon now speaks the language of your WoW client: English, German, French,
  Spanish (EU/LA), Portuguese, Italian, Russian, Korean, Chinese (simplified/traditional).
- Language can be changed manually in the options or with `/ahp language`.

## 4.7
- German/English interface, item names follow the client language automatically.

## 4.6
- Built-in item name list for ~23,000 items in 10 languages (source: QuestieDB, wow-classic-items).

## 4.5
- Search items by name in any language, by item ID or by shift-clicking an item.
- Suggestions while typing, accents and upper/lower case don't matter.

## 4.4
- Two designs: "Classic" (looks like the WoW auction house) and "Modern".
- Options window, help for every tab, right-click menu on every item.

## 4.3
- Sniper: targets with max price per item, quantity, budget, rarity, item level and level filters.
- Searches targets on its own while the auction house is open; buy with the mouse wheel or your own key.

## 4.0 – 4.2
- Market scan, price history, trends, watchlist with alerts, charts, flipping calculator.
- Price sync between all players using the addon.
