-- LevelPilot - Questgebiete, Questgeber und Fundstellen auf Karte und Minikarte
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- * Questgebiete: wo die Gegner bzw. Gegenstaende der laufenden Quest zu finden sind, als
--   halbdurchsichtige Flaechen auf Minikarte und Weltkarte
-- * "!" fuer annehmbare Quests in der Naehe (Minikarte) bzw. in der gezeigten Zone (Weltkarte)
-- * Fundstellen von Questgegenstaenden am Boden (Kisten, Pflanzen, Erz ...): Symbol auf der
--   Minikarte (am Rand, wenn ausserhalb), Pfeil zur naechsten Fundstelle, kurzer Hinweis in der Naehe
-- Addons koennen nicht in die 3D-Welt zeichnen; das Spiel laesst Questgegenstaende selbst funkeln.

local _, LP = ...
local L = LP.L
local Pi = {}
LP:RegisterModule("Pins", Pi)

local AREA_TEX = "Interface\\CHARACTERFRAME\\TempPortraitAlphaMask"
local OBJ_TEX = "Interface\\GossipFrame\\ActiveQuestIcon"
local AVAIL_TEX = "Interface\\GossipFrame\\AvailableQuestIcon"
local AREA_YARDS = 45          -- Radius einer Questgebiet-Flaeche
local AVAIL_RANGE = 600        -- Yards: "!" auf der Minikarte bis zu dieser Entfernung
local OBJ_NEAR = 250           -- Yards: ab hier fuehrt der Pfeil zur naechsten Fundstelle
local OBJ_REACHED = 10         -- Yards: Fundstelle gilt als besucht
local OBJ_ALERT = 20           -- Yards: Hinweis "Questgegenstand in der Naehe"
local MAX_MM, MAX_WM = 60, 120

Pi.areas, Pi.objects, Pi.avail = {}, {}, {}
local visited, alerted = {}, {}
local currentKey

------------------------------------------------------------------------
-- Daten: offene Ziele der laufenden Quest
------------------------------------------------------------------------
local function World(p)
    if p.inst == nil then
        local i, n, w = LP.Geo:ToWorld(p[1], p[2], p[3])
        p.inst, p.n, p.w = i or false, n, w
    end
    return p.inst or nil, p.n, p.w
end

-- Ziel der Daten -> Ziel des Spiels (gleiche Art der Reihe nach); nil = unbekannt
local KIND_TYPE = { kill = "monster", item = "item", object = "object", explore = "event" }
local function ClientIndex(q, objs)
    local byType, out = {}, {}
    for oi, o in ipairs(objs) do
        if o.type then
            byType[o.type] = byType[o.type] or {}
            table.insert(byType[o.type], oi)
        end
    end
    local count = {}
    for di, o in ipairs(q.objectives or {}) do
        local t = KIND_TYPE[o.kind]
        if t and byType[t] then
            count[t] = (count[t] or 0) + 1
            out[di] = byType[t][count[t]]
        elseif #objs == #(q.objectives or {}) then
            out[di] = di
        end
    end
    return out
end

local function Build()
    wipe(Pi.areas) wipe(Pi.objects) wipe(Pi.avail)
    local step = LP.Engine and LP.Engine:Current()
    local key = step and step.key or nil
    if key ~= currentKey then currentKey = key wipe(visited) end
    if step and step.t == "COMPLETE" and step.id then
        local st = LP.Planner.inLog[step.id]
        local q = LP.QuestDB:Get(step.id)
        if st and q and not st.complete then
            local objs = st.index and LP.API.Objectives(st.index) or {}
            local map = ClientIndex(q, objs)
            local tr = LP.Names and LP.Names:ObjectiveTexts(step.id, objs) or {}
            for di, o in ipairs(q.objectives or {}) do
                local ci = map[di]
                local done = ci and objs[ci] and objs[ci].finished
                if not done and o.kind ~= "rec" then
                    local text = (ci and tr[ci]) or (ci and objs[ci] and objs[ci].text) or o.text
                    for si, p in ipairs(o.spots or {}) do
                        if p.obj then
                            Pi.objects[#Pi.objects + 1] = { p = p, key = step.id .. ":" .. di .. ":" .. si, text = text,
                                                            have = ci and objs[ci] and objs[ci].have, need = ci and objs[ci] and objs[ci].need }
                        else
                            Pi.areas[#Pi.areas + 1] = { p = p, text = text }
                        end
                    end
                    -- Gegenstand nur aus Objekten: auch das Gebiet zeigen
                end
            end
            for _, e in ipairs(Pi.objects) do Pi.areas[#Pi.areas + 1] = { p = e.p, text = e.text, obj = true } end
        end
    end
    for _, t in ipairs(LP.Planner.lastTasks or {}) do
        if t.t == "ACCEPT" and t.inst and t.map then
            Pi.avail[#Pi.avail + 1] = { inst = t.inst, n = t.n, w = t.w, map = t.map, x = t.x, y = t.y, name = t.q, level = t.level, id = t.id }
        end
    end
end
Pi.Build = Build

------------------------------------------------------------------------
-- Pfeil zur naechsten Fundstelle und Hinweis in der Naehe
------------------------------------------------------------------------
function Pi:NearestObject()
    if not LP.db.objArrow or #self.objects == 0 then return nil end
    local pi, pn, pw = LP.Geo:Player()
    if not pi then return nil end
    local best, bestD, anyNear
    for _, e in ipairs(self.objects) do
        local i, n, w = World(e.p)
        if i == pi then
            local d = LP.Geo:Dist(pn, pw, n, w)
            if d < OBJ_NEAR then anyNear = true end
            if d < OBJ_REACHED then visited[e.key] = true end
            if not visited[e.key] and (not bestD or d < bestD) then best, bestD = e, d end
        end
    end
    if not anyNear or not best then return nil end
    local i, n, w = World(best.p)
    return { inst = i, n = n, w = w, map = best.p[1], key = "OBJ:" .. best.key,
             label = L["Questgegenstand"], entry = best, dist = bestD }
end

function Pi:CheckAlert()
    if not LP.db.objAlert then return end
    local pi, pn, pw = LP.Geo:Player()
    if not pi then return end
    local now = GetTime()
    for _, e in ipairs(self.objects) do
        local i, n, w = World(e.p)
        if i == pi and LP.Geo:Dist(pn, pw, n, w) < OBJ_ALERT and (not alerted[e.key] or now - alerted[e.key] > 60) then
            alerted[e.key] = now
            local prog = (e.have and e.need) and (" (" .. e.have .. "/" .. e.need .. ")") or ""
            local msg = L["Questgegenstand in der Nähe"] .. prog
            LP:Screen(msg, 1, 0.82, 0.29, SOUNDKIT and SOUNDKIT.MAP_PING or 3175)     -- 3.12.31 ML1: ueber die Weiche
            self.lastAlert = msg
            return
        end
    end
end

------------------------------------------------------------------------
-- Minikarte
------------------------------------------------------------------------
local mm, mmTex = nil, {}

local function MMTex(i)
    local t = mmTex[i]
    if not t then
        t = mm:CreateTexture(nil, "ARTWORK")
        mmTex[i] = t
    end
    return t
end

function Pi:UpdateMinimap()
    if not mm then return end
    local used = 0
    local function place(inst, n, w, tex, size, r, g, b, a, clamp)
        if used >= MAX_MM then return end
        local x, y, half = LP.Nav:MinimapProject(inst, n, w)
        if not x then return end
        local dist = math.sqrt(x * x + y * y)
        local edge = half - size / 2 - 2
        if dist > edge then
            if not clamp then return end
            x, y = x / dist * edge, y / dist * edge
        end
        used = used + 1
        local t = MMTex(used)
        t:SetTexture(tex)
        t:SetSize(size, size)
        t:SetVertexColor(r, g, b, a)
        t:ClearAllPoints()
        t:SetPoint("CENTER", Minimap, "CENTER", x, y)
        t:Show()
    end
    local pi = LP.Geo:Player()
    if pi then
        if LP.db.mapAreas then
            local _, _, half = LP.Nav:MinimapProject(pi, 0, 0)
            local zoom = Minimap:GetZoom()
            local radius = LP.Indoors() and ({ [0] = 150, 120, 90, 60, 40, 25 })[zoom] or ({ [0] = 233.3, 200, 166.7, 133.3, 100, 66.7 })[zoom] or 200
            local size = half and (AREA_YARDS * 2 * half / radius) or 30
            for _, a in ipairs(self.areas) do
                if not a.obj then
                    local i, n, w = World(a.p)
                    if i then place(i, n, w, AREA_TEX, size, 1, 0.82, 0.29, 0.22) end
                end
            end
        end
        if LP.db.objPins then
            local nearest = self:NearestObject()
            for _, e in ipairs(self.objects) do
                local i, n, w = World(e.p)
                local isNext = nearest and nearest.entry == e
                if i then place(i, n, w, OBJ_TEX, isNext and 16 or 12, 1, 1, 1, visited[e.key] and 0.45 or 1, isNext) end
            end
        end
        if LP.db.mapAvailable then
            local _, pn, pw = LP.Geo:Player()
            for _, q in ipairs(self.avail) do
                if q.inst == pi and LP.Geo:Dist(pn, pw, q.n, q.w) < AVAIL_RANGE then
                    place(q.inst, q.n, q.w, AVAIL_TEX, 13, 1, 1, 1, 1, false)
                end
            end
        end
    end
    for i = used + 1, #mmTex do mmTex[i]:Hide() end
end

------------------------------------------------------------------------
-- Weltkarte
------------------------------------------------------------------------
local wmPool = {}

local function Canvas()
    return WorldMapFrame and WorldMapFrame.ScrollContainer and WorldMapFrame.ScrollContainer.Child
end

local function WMPin(i, canvas)
    local p = wmPool[i]
    if not p then
        p = CreateFrame("Frame", nil, canvas)
        p.tex = p:CreateTexture(nil, "ARTWORK")
        p.tex:SetAllPoints()
        p:SetScript("OnEnter", function(self)
            if not self.info then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine("LevelPilot")
            GameTooltip:AddLine(self.info, 1, 1, 1, true)
            GameTooltip:Show()
        end)
        p:SetScript("OnLeave", function() GameTooltip:Hide() end)
        wmPool[i] = p
    end
    return p
end

function Pi:UpdateWorldMap()
    local canvas = Canvas()
    if not canvas or not WorldMapFrame:IsShown() then return end
    local shown = WorldMapFrame:GetMapID()
    local w, h = canvas:GetWidth(), canvas:GetHeight()
    local scale = WorldMapFrame.ScrollContainer.GetCanvasScale and WorldMapFrame.ScrollContainer:GetCanvasScale() or 1
    local used = 0
    local function place(inst, n, ww, tex, size, r, g, b, a, info, mouse)
        if used >= MAX_WM or not shown then return end
        local x, y = LP.Geo:ToMap(shown, inst, n, ww)
        if not x or x < 0 or x > 100 or y < 0 or y > 100 then return end
        used = used + 1
        local p = WMPin(used, canvas)
        p:SetSize(size, size)
        p:SetScale(1 / scale)
        p:ClearAllPoints()
        p:SetPoint("CENTER", canvas, "TOPLEFT", x / 100 * w * scale, -y / 100 * h * scale)
        p.tex:SetTexture(tex)
        p.tex:SetVertexColor(r, g, b, a)
        p.info = info
        p:EnableMouse(mouse and true or false)
        p:SetFrameLevel(canvas:GetFrameLevel() + (mouse and 25 or 5))
        p:Show()
    end
    if LP.db.mapAreas then
        -- Flaechen in Kartengroesse: Radius in Yards -> Anteil der Kartenbreite
        local b = LP.Geo:Bounds(shown)
        local yardsWide = b and math.abs(b.left - b.right) or 2000
        local size = math.max(10, AREA_YARDS * 2 / yardsWide * w * scale)
        for _, a in ipairs(self.areas) do
            local i, n, ww = World(a.p)
            if i then place(i, n, ww, AREA_TEX, size, 1, 0.82, 0.29, 0.25, a.text, false) end
        end
    end
    if LP.db.objPins then
        for _, e in ipairs(self.objects) do
            local i, n, ww = World(e.p)
            if i then place(i, n, ww, OBJ_TEX, 14, 1, 1, 1, visited[e.key] and 0.45 or 1, e.text, true) end
        end
    end
    if LP.db.mapAvailable then
        for _, q in ipairs(self.avail) do
            place(q.inst, q.n, q.w, AVAIL_TEX, 16, 1, 1, 1, 1,
                  (q.name or "?") .. (q.level and q.level > 0 and (" [" .. q.level .. "]") or ""), true)
        end
    end
    for i = used + 1, #wmPool do wmPool[i]:Hide() end
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
function Pi:Refresh()
    Build()
    self:UpdateMinimap()
    self:UpdateWorldMap()
end

function Pi:Init()
    if Minimap then
        mm = CreateFrame("Frame", nil, Minimap)
        mm:SetAllPoints(Minimap)
        mm:SetFrameLevel(Minimap:GetFrameLevel() + 4)
    end
    LP.Nav:AddOverride(function() return Pi:NearestObject() end, 10)
    local t = 0
    local driver = CreateFrame("Frame")
    LP.drivers = LP.drivers or {}
    LP.drivers.pins = driver                 -- Testroutine (T82)
    driver:SetScript("OnUpdate", function(_, dt)
        t = t + dt
        if t < 0.1 then return end
        t = 0
        Pi:UpdateMinimap()
        Pi:CheckAlert()
    end)
    if WorldMapFrame then
        WorldMapFrame:HookScript("OnShow", function() Pi:UpdateWorldMap() end)
        local wt = 0
        WorldMapFrame:HookScript("OnUpdate", function(_, dt)
            wt = wt + dt
            if wt > 0.5 then wt = 0 Pi:UpdateWorldMap() end
        end)
    end
    local function soon() LP:Throttle("pins", 0.5, function() Pi:Refresh() end) end
    LP:Listen("PLAN_CHANGED", soon)
    LP:On("QUEST_LOG_UPDATE", soon)
    soon()
end
