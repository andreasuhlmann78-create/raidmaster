-- LevelPilot - Datensicherung
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- 1) Zweitkopie: WoW speichert Account- und Charakterdaten in getrennten Dateien. Beim Ausloggen
--    legt LevelPilot alle gesammelten Daten (Quests, Wege, Haendler, Flugpunkte) zusaetzlich im
--    Charakter ab. Fehlen die Accountdaten beim naechsten Start oder sind sie beschaedigt (WoW laedt
--    eine kaputte Datei nicht), werden sie automatisch aus der Kopie wiederhergestellt.
--    Eine Kopie wird nie durch einen deutlich kleineren Stand ersetzt.
-- 2) Sichern/Laden als Text: alle Daten als Text zum Kopieren in eine Datei, spaeter wieder
--    einfuegen (auch auf einem anderen PC). Beim Laden wird nur ergaenzt, nie geloescht. Der Text
--    wird mit einem eigenen Leser verarbeitet und nie als Code ausgefuehrt.

local ADDON, LP = ...
local L = LP.L
local B = {}
LP:RegisterModule("Backup", B)

local KEEP_RATIO = 0.9      -- Kopie nur ersetzen, wenn der neue Stand mindestens 90 % so gross ist
local RESTORE_RATIO = 0.5   -- Accountdaten unter 50 % der Kopie gelten als verloren/beschaedigt
local FORMAT = "LP1"

------------------------------------------------------------------------
-- Zaehlen
------------------------------------------------------------------------
local function Size(t)
    local n = 0
    if type(t) == "table" then for _ in pairs(t) do n = n + 1 end end
    return n
end

function B:Count(db)
    if type(db) ~= "table" then return 0 end
    local g = type(db.graph) == "table" and db.graph or {}
    return Size(db.qdb) + Size(db.vendors) + Size(db.taxi) + Size(g.nodes)
end

local function Describe(db)
    local g = type(db.graph) == "table" and db.graph or {}
    return string.format(L["%d Quests, %d Händler, %d Flugpunkte, %d Wegpunkte"],
        Size(db.qdb), Size(db.vendors), Size(db.taxi), Size(g.nodes))
end
B.Describe = Describe

------------------------------------------------------------------------
-- Zusammenfuehren (nur ergaenzen, nie loeschen)
------------------------------------------------------------------------
local function DeepCopy(v)
    if type(v) ~= "table" then return v end
    local t = {}
    for k, x in pairs(v) do t[k] = DeepCopy(x) end
    return t
end

B.DeepCopy = DeepCopy

local function MergeMap(dst, src)
    local added = 0
    if type(src) ~= "table" then return 0 end
    for k, v in pairs(src) do
        if dst[k] == nil then
            dst[k] = DeepCopy(v)
            added = added + 1
        elseif type(dst[k]) == "table" and type(v) == "table" then
            -- fehlende Felder ergaenzen, vorhandene behalten
            for fk, fv in pairs(v) do
                if dst[k][fk] == nil then dst[k][fk] = DeepCopy(fv) end
            end
        end
    end
    return added
end

-- Wegenetz roh zusammenfuehren (vor dem Start des Wegenetz-Moduls): Kennungen verschieben
local function MergeGraphRaw(dst, src)
    if type(src) ~= "table" or type(src.nodes) ~= "table" then return 0 end
    dst.nodes = dst.nodes or {}
    dst.edges = dst.edges or {}
    local offset = (dst.nextId or 1) - 1
    local maxId = 0
    for id, nd in pairs(src.nodes) do
        dst.nodes[id + offset] = DeepCopy(nd)
        if id > maxId then maxId = id end
    end
    local added = 0
    for _, e in pairs(src.edges or {}) do
        local a, b = e[1] + offset, e[2] + offset
        local key = a < b and (a .. ":" .. b) or (b .. ":" .. a)
        if not dst.edges[key] then
            local ne = DeepCopy(e)
            ne[1], ne[2] = a, b
            dst.edges[key] = ne
            added = added + 1
        end
    end
    dst.nextId = offset + maxId + 1
    dst.count = (dst.count or 0) + Size(src.nodes)
    dst.netCount = (dst.netCount or 0) + (src.netCount or 0)
    return Size(src.nodes)
end

------------------------------------------------------------------------
-- 1) Zweitkopie im Charakter
------------------------------------------------------------------------
-- Beim Laden: verlorene oder beschaedigte Accountdaten aus der Kopie wiederherstellen
function B:CheckOnLoad()
    local db, char = LevelPilotDB, LevelPilotCharDB
    local bk = type(char) == "table" and char.backup
    if type(bk) ~= "table" or type(bk.data) ~= "table" then return end
    local have, saved = self:Count(db), self:Count(bk.data)
    if saved == 0 then return end
    local d = bk.data
    -- Quests, Haendler, Flugpunkte: was nur in der Kopie steht, immer ergaenzen (loescht nichts)
    db.caves = db.caves or {}
    db.calib = type(db.calib) == "table" and db.calib or {}
    db.npcPos = type(db.npcPos) == "table" and db.npcPos or {}
    local added = MergeMap(db.qdb, d.qdb) + MergeMap(db.vendors, d.vendors) + MergeMap(db.taxi, d.taxi)
                  + MergeMap(db.caves, d.caves)
                  + (type(d.calib) == "table" and MergeMap(db.calib, d.calib) or 0)
                  + (type(d.npcPos) == "table" and MergeMap(db.npcPos, d.npcPos) or 0)
    if have >= saved * RESTORE_RATIO then
        if added > 0 then self.restored = { from = bk.t, before = have, after = self:Count(db), small = true } end
        return
    end
    db.graph = db.graph or {}
    local gHave = Size(db.graph.nodes)
    if gHave < Size(type(d.graph) == "table" and d.graph.nodes) * RESTORE_RATIO then
        -- Wegenetz aus der Kopie als Grundlage, neuere Punkte dieses Accounts anhaengen
        local current = db.graph
        db.graph = DeepCopy(d.graph)
        MergeGraphRaw(db.graph, current)
    end
    self.restored = { from = bk.t, before = have, after = self:Count(db) }
end

-- Beim Ausloggen: Kopie im Charakter aktualisieren (nie durch einen viel kleineren Stand)
function B:SaveCopy()
    -- waehrend einer virtuellen Reise erst die echten Tabellen zurueckholen
    if LP.Virtual and LP.Virtual.active then pcall(LP.Virtual.Abort, LP.Virtual) end
    local db, char = LevelPilotDB, LevelPilotCharDB
    if type(db) ~= "table" or type(char) ~= "table" then return end
    for _, k in ipairs({ "qdb", "vendors", "taxi", "caves", "calib", "npcPos" }) do
        if type(db[k]) ~= "table" then db[k] = {} end
        -- eine Ueberlagerung (virtuelle Reise) nie speichern: die echte Liste dahinter nehmen
        if getmetatable(db[k]) and LP.Virtual and LP.Virtual.RealTaxiOf then db[k] = LP.Virtual.RealTaxiOf(db[k]) end
    end
    -- erst heilen: was nur in der alten Sicherung steht, zurueck ins Konto (ergaenzt nur, loescht nie)
    local bk = type(char.backup) == "table" and char.backup
    local d = bk and type(bk.data) == "table" and bk.data
    if d then
        local added = MergeMap(db.qdb, d.qdb) + MergeMap(db.vendors, d.vendors) + MergeMap(db.taxi, d.taxi) + MergeMap(db.caves, d.caves)
                      + (type(d.calib) == "table" and MergeMap(db.calib, d.calib) or 0)
                      + (type(d.npcPos) == "table" and MergeMap(db.npcPos, d.npcPos) or 0)
        if added > 0 and LP.Protocol then
            LP.Protocol:AddL("error", "Sicherung: %d fehlende Einträge aus der Sicherung im Charakter ergänzt", added)
        end
    end
    local now = self:Count(db)
    local old = bk and bk.count or 0
    if now == 0 or now < old * KEEP_RATIO then return end
    -- eigene Kopie (nicht dieselben Tabellen): wird das Konto geleert, bleibt die Sicherung erhalten
    local graph = db.graph
    if d and type(d.graph) == "table" and Size(type(graph) == "table" and graph.nodes) < Size(d.graph.nodes) * KEEP_RATIO then
        graph = d.graph                     -- Wegenetz der Sicherung behalten, wenn das Konto viel weniger hat
    end
    char.backup = { t = time(), count = now, version = LP.version,
                    data = { qdb = DeepCopy(db.qdb), vendors = DeepCopy(db.vendors), taxi = DeepCopy(db.taxi),
                             graph = DeepCopy(graph), caves = DeepCopy(db.caves), calib = DeepCopy(db.calib), npcPos = DeepCopy(db.npcPos) } }
end

------------------------------------------------------------------------
-- 2) Sichern/Laden als Text
------------------------------------------------------------------------
-- Eigenes Format: s<laenge>:<text>  n<zahl>;  t / f  {<schluessel><wert>...}
local function Ser(v, out)
    local tv = type(v)
    if tv == "string" then
        out[#out + 1] = "s" .. #v .. ":" .. v
    elseif tv == "number" then
        out[#out + 1] = "n" .. string.format("%.10g", v) .. ";"
    elseif tv == "boolean" then
        out[#out + 1] = v and "t" or "f"
    elseif tv == "table" then
        out[#out + 1] = "{"
        for k, x in pairs(v) do
            local tk = type(k)
            if (tk == "string" or tk == "number") and type(x) ~= "function" then
                Ser(k, out)
                Ser(x, out)
            end
        end
        out[#out + 1] = "}"
    end
end

local function Parse(s)
    local pos, depth = 1, 0
    local function value()
        local c = s:sub(pos, pos)
        if c == "s" then
            local colon = s:find(":", pos, true)
            local len = colon and tonumber(s:sub(pos + 1, colon - 1))
            if not len then error(L["Text beschädigt (Zeichenkette)"]) end
            local str = s:sub(colon + 1, colon + len)
            if #str ~= len then error(L["Text unvollständig"]) end
            pos = colon + len + 1
            return str
        elseif c == "n" then
            local semi = s:find(";", pos, true)
            local num = semi and tonumber(s:sub(pos + 1, semi - 1))
            if not num then error(L["Text beschädigt (Zahl)"]) end
            pos = semi + 1
            return num
        elseif c == "t" then pos = pos + 1 return true
        elseif c == "f" then pos = pos + 1 return false
        elseif c == "{" then
            depth = depth + 1
            if depth > 40 then error(L["Text beschädigt (zu tief)"]) end
            pos = pos + 1
            local t = {}
            while s:sub(pos, pos) ~= "}" do
                if pos > #s then error(L["Text unvollständig"]) end
                local k = value()
                local x = value()
                if type(k) == "table" or type(k) == "boolean" then error(L["Text beschädigt (Schlüssel)"]) end
                t[k] = x
            end
            pos = pos + 1
            depth = depth - 1
            return t
        end
        error(L["Text beschädigt bei Zeichen "] .. pos)
    end
    local v = value()
    return v
end

-- Zeichen, die das Eingabefeld von WoW veraendern wuerde, umschreiben
local function Escape(s)
    return (s:gsub("[%%|\r\n]", function(c) return string.format("%%%02X", c:byte()) end))
end
local function Unescape(s)
    return (s:gsub("%%(%x%x)", function(h) return string.char(tonumber(h, 16)) end))
end

local function Checksum(s)
    local a, b = 1, 0
    for i = 1, #s, 7 do                      -- jedes 7. Zeichen: schnell genug fuer grosse Texte
        a = (a + s:byte(i)) % 65521
        b = (b + a) % 65521
    end
    return string.format("%04x%04x%06x", a % 65536, b % 65536, #s % 16777216)
end

function B:Export()
    local db = LP.db
    local payload = {}
    Ser({ v = LP.version, t = time(), qdb = db.qdb, vendors = db.vendors, taxi = db.taxi, graph = db.graph, caves = db.caves }, payload)
    local body = Escape(table.concat(payload))
    return FORMAT .. ":" .. Checksum(body) .. ":" .. body
end

-- liefert true, Beschreibung oder false, Fehler
function B:Import(text)
    text = (text or ""):gsub("^%s+", ""):gsub("%s+$", "")
    local fmt, sum, body = text:match("^(%w+):(%x+):(.*)$")
    if fmt ~= FORMAT then return false, L["Das ist kein LevelPilot-Sicherungstext."] end
    if Checksum(body) ~= sum then return false, L["Der Text ist unvollständig oder verändert (Prüfsumme stimmt nicht)."] end
    local ok, data = pcall(Parse, Unescape(body))
    if not ok or type(data) ~= "table" then return false, tostring(data) end
    local db = LP.db
    local q = MergeMap(db.qdb, data.qdb)
    local v = MergeMap(db.vendors, data.vendors)
    local tx = MergeMap(db.taxi, data.taxi)
    db.caves = db.caves or {}
    local cv = MergeMap(db.caves, data.caves)
    -- Wege ueber das Wegenetz einfuegen (doppelte Punkte werden zusammengelegt)
    local edges = 0
    local g = type(data.graph) == "table" and data.graph or {}
    if type(g.nodes) == "table" and type(g.edges) == "table" then
        for _, e in pairs(g.edges) do
            local a, b = g.nodes[e[1]], g.nodes[e[2]]
            if type(a) == "table" and type(b) == "table" then
                local ia = LP.Graph:AddNode(a[1], a[2], a[3], a[4], a.net)
                local ib = LP.Graph:AddNode(b[1], b[2], b[3], b[4], b.net)
                if LP.Graph:AddEdge(ia, ib, e[3] or "s", e.c) then edges = edges + 1 end
            end
        end
    end
    LP.QuestDB:Invalidate()
    LP.QuestDB:InvalidateServices()
    LP:Fire("QDB_CHANGED")
    LP:Fire("GRAPH_CHANGED")
    LP:Fire("CAVES_CHANGED")
    local msg = string.format(L["Ergänzt: %d Quests, %d Händler, %d Flugpunkte, %d Wegstücke. Nichts wurde gelöscht."], q, v, tx, edges)
    if cv > 0 then msg = msg .. " " .. L("Höhlen und Tunnel: %d", cv) end
    return true, msg
end

-- Fenster mit Textfeld zum Kopieren/Einfuegen
local box
local function Box()
    if box then return box end
    local f = CreateFrame("Frame", "LevelPilotBackupFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    f:SetSize(560, 360)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    LP.UI:Skin(f, LP.colors.panel, LP.colors.border)
    f.title = LP.UI:Text(f, 13, LP.colors.text)
    f.title:SetPoint("TOPLEFT", 14, -12)
    f.hint = LP.UI:Text(f, 11, LP.colors.muted)
    f.hint:SetPoint("TOPLEFT", 14, -32)
    f.hint:SetWidth(530)
    local sf = CreateFrame("ScrollFrame", "LevelPilotBackupScroll", f, "UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT", 14, -68)
    sf:SetPoint("BOTTOMRIGHT", -34, 46)
    local eb = CreateFrame("EditBox", nil, sf)
    eb:SetMultiLine(true)
    eb:SetMaxLetters(0)
    eb:SetAutoFocus(false)
    eb:SetFontObject(ChatFontNormal)
    eb:SetWidth(500)
    eb:SetScript("OnEscapePressed", function() f:Hide() end)
    -- Enter beendet die Eingabe im Textfeld (sonst landet das naechste Enter und der getippte Chat-Befehl hier
    -- statt im Chat - Bericht 3.9.0: "/lp reise bericht" schien nichts zu tun)
    eb:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    sf:SetScrollChild(eb)
    f.edit = eb
    f.ok = LP.UI:Button(f, L["Laden"], 90, 22, function()
        local ok, msg = B:Import(eb:GetText())
        LP:Reply((ok and "|cff4ddb80" or "|cffff5555") .. msg .. "|r")
        if ok then f:Hide() end
    end)
    f.ok:SetPoint("BOTTOMRIGHT", -14, 14)
    local close = LP.UI:Button(f, L["Schliessen"], 90, 22, function() f:Hide() end)
    close:SetPoint("RIGHT", f.ok, "LEFT", -8, 0)
    box = f
    return f
end

function B:ShowExport()
    local f = Box()
    f.title:SetText(L["Daten sichern"])
    f.hint:SetText(L["Strg+A, dann Strg+C drücken und den Text in eine Datei einfügen (z. B. LevelPilot-Sicherung.txt). "]
        .. L["Enthält "] .. Describe(LP.db) .. L[". Bei vielen Daten kann das Anzeigen einen Moment dauern."])
    f.ok:Hide()
    f:Show()
    f.edit:SetText(self:Export())
    f.edit:HighlightText()
    f.edit:SetFocus()
end

-- beliebigen Text zum Kopieren zeigen (z. B. Fehler-Protokoll)
function B:ShowText(title, hint, text)
    local f = Box()
    f.title:SetText(title)
    f.hint:SetText(hint)
    f.ok:Hide()
    f:Show()
    f:Raise()
    f.edit:SetText(text or "")
    f.edit:HighlightText()
    f.edit:SetFocus()
end

function B:ShowImport()
    local f = Box()
    f.title:SetText(L["Daten laden"])
    f.hint:SetText(L["Gesicherten Text einfügen (Strg+V) und „Laden“ drücken. Es wird nur ergänzt – vorhandene Daten bleiben erhalten."])
    f.ok:Show()
    f:Show()
    f.edit:SetText("")
    f.edit:SetFocus()
end

------------------------------------------------------------------------
-- Ereignisse
------------------------------------------------------------------------
LP:On("ADDON_LOADED", function(_, name)
    if name ~= ADDON then return end
    local ok, err = LP.Try("Sicherung CheckOnLoad", B.CheckOnLoad, B)
    if not ok then B.loadError = tostring(err) end
end)

LP:On("PLAYER_LOGOUT", function() LP.Try("Sicherung SaveCopy", B.SaveCopy, B) end)

function B:Init()
    if self.restored and self.restored.small then
        LP:Print(L["Aus der Sicherung im Charakter ergänzt: "] .. (self.restored.after - self.restored.before) .. L[" Einträge."])
    elseif self.restored then
        LP:Print(L["|cffffb238Gesammelte Daten fehlten oder waren beschädigt – automatisch aus der Sicherung im Charakter wiederhergestellt.|r Jetzt: "] .. Describe(LP.db))
    end
    if self.loadError then LP:Error(L["Sicherung"], self.loadError) end
    -- Kopie sofort verknuepfen: WoW schreibt sie bei jedem /reload und beim Ausloggen mit
    LP.Try("Sicherung SaveCopy", B.SaveCopy, B)
end

-- Text fuer die Zentrale
function B:Info()
    local c = (LP.Virtual and LP.Virtual.RealChar) and LP.Virtual:RealChar() or LP.char
    local bk = c and c.backup
    if type(bk) ~= "table" or not bk.t then return L["Sicherung im Charakter: noch keine (entsteht beim Ausloggen)"] end
    return L["Sicherung im Charakter: "] .. (bk.count or 0) .. L[" Einträge, Stand "] .. date("%d.%m.%Y %H:%M", bk.t)
end
