-- GuildSentinel - MyWeek.lua
-- Seite "Meine Woche": alles über die eigenen Charaktere (nur für dich, wird nicht verschickt).
--   * Wochenplan je Charakter: gesperrte Raids und heroische Dungeons mit Restzeit, erledigte Dailies heute
--   * Raid-Vorbereitung für den aktuellen Charakter: Zugänge, Fläschchen/Elixiere/Tränke in den Taschen,
--     Klassen-Reagenzien, Haltbarkeit der Ausrüstung und Widerstände (Feuer, Natur, Frost, Schatten, Arkan)
--
--   GuildSentinelDB.chars["Realm|Name"] = { c, l, t, saved = { { n, r = Ende, raid, d = Schwierigkeit } }, daily, dailyDay }

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local UI = ns.UI
local MW = {}
ns.MyWeek = MW

local GREEN, GRAY, GOLD, ORANGE, RED = "|cff40d860", "|cff8a8f99", "|cffffd100", "|cffff9933", "|cffff5555"
local function Gray(t) return GRAY .. tostring(t) .. "|r" end

------------------------------------------------------------
-- Eigene Charaktere
------------------------------------------------------------
-- 0.9.59: früh beim Einloggen liefert GetRealmName manchmal "" – dann entstanden Schlüssel "|Name" neben "Realm|Name" (Uploads
-- 23.11.: 3 Konten). Ohne Realm wird nichts gespeichert (beim nächsten Ereignis ist er da).
-- 0.9.64 (Hinweis Supervisor 26.11. 09:38, belegt: GetRealmName in WoW Forever seit ~21.11. DAUERHAFT ""): mit der Regel von 0.9.59
-- ("ohne Realm nichts speichern") wurde seit 21.11. gar nichts mehr gespeichert. Jetzt ns.CharKey: vorhandener Schlüssel "Realm|Name"
-- dieses Namens (genau einer), sonst "|Name".
local function Key(name)
	return ns.CharKey(MW:Store(), name)
end

function MW:Store()
	-- Testmodus: nur eine Kopie (die gespeicherten Charakterdaten bleiben unberührt)
	if ns.Test and ns.Test:Active() then
		ns.Test.chars = ns.Test.chars or ns.Copy(GuildSentinelDB.chars or {})
		return ns.Test.chars
	end
	GuildSentinelDB.chars = GuildSentinelDB.chars or {}
	return GuildSentinelDB.chars
end

function MW:Scan()
	if not GuildSentinelDB then return end
	local now = ns.Now()
	local _, cf = UnitClass("player")
	local saved = {}
	local num = GetNumSavedInstances and GetNumSavedInstances() or 0
	for i = 1, num do
		local name, _, reset, diff, locked, extended, _, isRaid, maxPlayers, diffName = GetSavedInstanceInfo(i)
		if name and (locked or extended) and (reset or 0) > 0 then
			saved[#saved + 1] = { n = name, r = now + reset, raid = isRaid and true or false, d = diffName, m = maxPlayers }
		end
	end
	local e = { c = cf, l = UnitLevel("player"), t = now, saved = saved }
	if GetDailyQuestsCompleted then
		e.daily = GetDailyQuestsCompleted()
		e.dailyDay = math.floor(now / 86400)
	end
	local k = Key()
	if not k then return end
	local st = self:Store()
	-- 0.9.65 (Supervisor 26.11. 10:32): seit ~21.11. bis zu 0.9.64 wurde nichts gespeichert (Realm leer). Erstes Speichern mit der
	-- neuen Regel merken – Charaktere mit älterem Stand zeigen "Stand vom …, Daten fehlen" statt "alles frei" (nichts Falsches zeigen).
	-- Nicht im Testmodus (Sandbox der Testroutine).
	if not (ns.Test and ns.Test:Active()) and GuildSentinelDB.myweekFixT == nil then GuildSentinelDB.myweekFixT = now end
	st[k] = e
	-- alter Eintrag ohne Realm für denselben Namen: durch diesen ersetzt (nicht, wenn das der Schlüssel selbst ist)
	if k ~= "|" .. ns.Me() and st["|" .. ns.Me()] then st["|" .. ns.Me()] = nil end
	ns:Fire("GS_MYWEEK")
end

-- { { name, c, l, saved = { … }, daily } } – aktueller Charakter zuerst
-- 0.9.59 (Auftrag 21.11. "ohne Realm zusammenführen"): auf WoW Forever haben die Charaktere EINES Servers verschiedene Heimat-Realms;
-- vorher zeigte die Liste nur die mit dem Realm des eingeloggten Charakters. Jetzt alle (Schlüssel bleibt "Realm|Name");
-- gibt es einen Namen zweimal, steht der Realm dahinter.
function MW:Chars()
	local now = ns.Now()
	local today = math.floor(now / 86400)
	local out = {}
	local names = {}
	for key in pairs(self:Store()) do
		local nm = type(key) == "string" and key:match("^.-|(.*)$")
		if nm then names[nm] = (names[nm] or 0) + 1 end
	end
	local myRealm = GetRealmName and GetRealmName() or "?"
	for key, e in pairs(self:Store()) do
		local realmOf, nm = nil, nil
		if type(key) == "string" then realmOf, nm = key:match("^(.-)|(.*)$") end
		-- "|Name" (ohne Realm, alter Fehler) nur zeigen, wenn es den Namen nicht auch mit Realm gibt
		if nm and realmOf == "" and names[nm] > 1 then nm = nil end
		if nm and type(e) == "table" then
			local name = nm
			local isMe = ns.Same(nm, ns.Me()) and realmOf == myRealm
			local dup = 0
			for k2 in pairs(self:Store()) do local r2, n2 = k2:match("^(.-)|(.*)$") if n2 == nm and r2 ~= "" then dup = dup + 1 end end
			if dup > 1 and not isMe then name = nm .. " (" .. realmOf .. ")" end
			local saved = {}
			for _, s in ipairs(e.saved or {}) do if (s.r or 0) > now then saved[#saved + 1] = s end end
			table.sort(saved, function(a, b) if a.raid ~= b.raid then return a.raid end return a.n < b.n end)
			-- 0.9.65: Stand vor dem ersten Speichern mit 0.9.64 -> Lücke (21.11. bis Update), nicht "alles frei"
			local fixT = GuildSentinelDB and GuildSentinelDB.myweekFixT
			local gap = type(fixT) == "number" and type(e.t) == "number" and e.t < fixT and e.t > 0
			out[#out + 1] = { name = name, c = e.c, l = e.l or 0, saved = saved, daily = (e.dailyDay == today) and e.daily or nil, me = isMe or (names[nm] == 1 and ns.Same(nm, ns.Me())),
				gap = gap and e.t or nil }
		end
	end
	table.sort(out, function(a, b)
		if a.me ~= b.me then return a.me end
		if a.l ~= b.l then return a.l > b.l end
		return a.name < b.name
	end)
	return out
end

local function Left(t)
	local s = t - ns.Now()
	if s < 3600 then return string.format(L["%d Min."], math.max(1, math.floor(s / 60))) end
	if s < 86400 then return string.format(L["%d Std."], math.floor(s / 3600)) end
	return string.format(L["%d T."], math.floor(s / 86400))
end

function MW:PlanText()
	local lines = {}
	for _, c in ipairs(self:Chars()) do
		local head = ns.Colored(c.name, c.c) .. Gray(" " .. c.l) .. (c.me and Gray(" · " .. L["dieser Charakter"]) or "")
		if c.daily then head = head .. Gray(" · " .. string.format(L["%d Dailies heute"], c.daily)) end
		lines[#lines + 1] = head
		if c.gap then
			-- Lücke: der gespeicherte Stand ist alt – nichts Falsches ("alles frei") zeigen
			lines[#lines + 1] = "   " .. ORANGE .. string.format(L["Stand vom %s – seit dem 21.11. bis Version 0.9.64 nicht gespeichert. Einmal mit diesem Charakter einloggen."], date(L["%d.%m."], c.gap)) .. "|r"
			for _, s in ipairs(c.saved) do
				local what = s.n .. ((s.d and s.d ~= "" and not s.raid) and (" (" .. s.d .. ")") or "")
				lines[#lines + 1] = "   " .. Gray(what .. " – " .. string.format(L["frei in %s"], Left(s.r)))
			end
		elseif #c.saved == 0 then
			lines[#lines + 1] = "   " .. GREEN .. L["nichts gesperrt – alles frei"] .. "|r"
		else
			for _, s in ipairs(c.saved) do
				local what = s.n .. ((s.d and s.d ~= "" and not s.raid) and (" (" .. s.d .. ")") or "")
				lines[#lines + 1] = "   " .. (s.raid and ORANGE or GOLD) .. what .. "|r" .. Gray(" – " .. string.format(L["frei in %s"], Left(s.r)))
			end
		end
		lines[#lines + 1] = ""
	end
	if #lines == 0 then return Gray(L["Noch keine Daten – einmal mit jedem Charakter einloggen."]) end
	lines[#lines + 1] = Gray(L["Charaktere erscheinen hier, sobald du dich einmal mit ihnen einloggst. Sperren liest das Spiel beim Einloggen und nach jedem Bosskill."])
	return table.concat(lines, "\n")
end

------------------------------------------------------------
-- Raid-Vorbereitung (aktueller Charakter)
------------------------------------------------------------
-- Klassen-Reagenzien: Item-ID, Mindestanzahl (wie bei RaidMaster)
MW.REAGENTS = {
	PRIEST = { { 17029, 5 } }, MAGE = { { 17020, 20 } }, DRUID = { { 17026, 10 }, { 17038, 1 } },
	PALADIN = { { 21177, 20 } }, SHAMAN = { { 17030, 1 } }, WARLOCK = { { 6265, 5 } },
}
MW.RESIST = { { 2, N["Feuer"] }, { 3, N["Natur"] }, { 4, N["Frost"] }, { 5, N["Schatten"] }, { 6, N["Arkan"] } }

local function BagItems()
	local out = {}
	local C = C_Container
	local slots = (C and C.GetContainerNumSlots) or GetContainerNumSlots
	local info = C and C.GetContainerItemInfo
	local link = (C and C.GetContainerItemLink) or GetContainerItemLink
	if not slots then return out end
	for bag = 0, (NUM_BAG_SLOTS or 4) do
		for slot = 1, (slots(bag) or 0) do
			local id, count
			if info then
				local x = info(bag, slot)
				if x then id, count = x.itemID or ns.ItemID(x.hyperlink), x.stackCount end
			elseif link then
				id = ns.ItemID(link(bag, slot))
				count = 1
			end
			if id then out[id] = (out[id] or 0) + (count or 1) end
		end
	end
	return out
end

function MW:Prep()
	local p = {}
	-- Verbrauchsgüter nach Art
	p.flask, p.elixir, p.potion = 0, 0, 0
	for id, n in pairs(BagItems()) do
		local x = { ns.GetItemInfo(id) }
		if x[12] == 0 then
			if x[13] == 3 then p.flask = p.flask + n elseif x[13] == 2 then p.elixir = p.elixir + n elseif x[13] == 1 then p.potion = p.potion + n end
		end
	end
	-- Reagenzien
	local _, cf = UnitClass("player")
	p.reagents = {}
	local count = (C_Item and C_Item.GetItemCount) or GetItemCount
	for _, r in ipairs(self.REAGENTS[cf] or {}) do
		p.reagents[#p.reagents + 1] = { id = r[1], need = r[2], have = count and count(r[1]) or 0 }
	end
	-- Haltbarkeit
	local minPct, sum, n = 100, 0, 0
	if GetInventoryItemDurability then
		for slot = 1, 18 do
			local cur, max = GetInventoryItemDurability(slot)
			if cur and max and max > 0 then
				local pct = cur / max * 100
				minPct = math.min(minPct, pct); sum = sum + pct; n = n + 1
			end
		end
	end
	p.durMin, p.durAvg = minPct, n > 0 and sum / n or 100
	-- Widerstände
	p.resist = {}
	for _, r in ipairs(self.RESIST) do
		local _, total = 0, 0
		if UnitResistance then _, total = UnitResistance("player", r[1]) end
		p.resist[#p.resist + 1] = { name = L[r[2]], v = total or 0 }
	end
	-- Zugänge (nur Raids)
	p.attune = {}
	for _, a in ipairs(ns.Attune:InGroup("raid")) do
		p.attune[#p.attune + 1] = { name = L[a.name], ok = ns.Attune:Status(ns.Me(), a.key) }
	end
	p.raid = ns.Links:NextRaid()
	return p
end


function MW:PrepText()
	local p = self:Prep()
	local lines = {}
	if p.raid then
		lines[#lines + 1] = GOLD .. string.format(L["Nächster Raid: %s – %s"], p.raid.title, ns.Date(p.raid.t)) .. "|r"
		lines[#lines + 1] = ""
	end
	-- Zeichen: grünes "+" = bereit, oranges/rotes "!" = fehlt oder zu wenig
	local function Mark(ok, bad) return ok and (GREEN .. "+|r ") or ((bad or ORANGE) .. "!|r ") end
	lines[#lines + 1] = L["Zugänge"]
	for _, a in ipairs(p.attune) do
		lines[#lines + 1] = "   " .. Mark(a.ok) .. a.name
	end
	lines[#lines + 1] = ""
	lines[#lines + 1] = L["In den Taschen"]
	lines[#lines + 1] = "   " .. Mark(p.flask > 0) .. string.format(L["%d Fläschchen"], p.flask)
	lines[#lines + 1] = "   " .. Mark(p.elixir > 0) .. string.format(p.elixir == 1 and L["%d Elixier"] or L["%d Elixiere"], p.elixir)
	lines[#lines + 1] = "   " .. Mark(p.potion >= 5) .. string.format(p.potion == 1 and L["%d Trank"] or L["%d Tränke"], p.potion)
	for _, r in ipairs(p.reagents) do
		lines[#lines + 1] = "   " .. Mark(r.have >= r.need) .. string.format(L["%s: %d (mindestens %d)"], ns.Craft:ItemName(r.id), r.have, r.need)
	end
	lines[#lines + 1] = ""
	local durOk = p.durMin >= 50
	lines[#lines + 1] = L["Ausrüstung"]
	lines[#lines + 1] = "   " .. Mark(durOk, RED) .. string.format(L["Haltbarkeit: schlechtestes Teil %d%%, Schnitt %d%%"], math.floor(p.durMin), math.floor(p.durAvg))
	local res = {}
	for _, r in ipairs(p.resist) do res[#res + 1] = r.name .. " " .. r.v end
	lines[#lines + 1] = "   " .. L["Widerstände: "]
	lines[#lines + 1] = "      " .. table.concat(res, " · ")
	lines[#lines + 1] = ""
	lines[#lines + 1] = Gray(L["Grünes + = bereit, oranges ! = fehlt oder zu wenig. Weltbuffs und Verzauberungen prüft RaidMaster beim Bereitschafts-Check."])
	return table.concat(lines, "\n")
end

------------------------------------------------------------
-- Einlesen
------------------------------------------------------------
ns:Listen("GS_LOGIN", function()
	if RequestRaidInfo then RequestRaidInfo() end
	C_Timer.After(8, function() MW:Scan() end)
end)
ns:On("UPDATE_INSTANCE_INFO", function() MW:Scan() end)
ns:On("BOSS_KILL", function() C_Timer.After(3, function() if RequestRaidInfo then RequestRaidInfo() end end) end)
ns:On("QUEST_TURNED_IN", function() C_Timer.After(2, function() MW:Scan() end) end)
ns:On("PLAYER_LEVEL_UP", function() C_Timer.After(2, function() MW:Scan() end) end)

------------------------------------------------------------
-- Seite
------------------------------------------------------------
local P = { key = "myweek", feature = "myweek", noGuild = true, order = 28, icon = "Interface\\Icons\\INV_Misc_Note_02" }
P.title = N["Meine Woche"]

function P.build(p)
	P.panel = p
	local h1 = UI:Header(p, L["Meine Charaktere"])
	h1:SetPoint("TOPLEFT", 0, 0)
	P.plan = UI:ScrollText(p, 382, 500)
	P.plan:SetPoint("TOPLEFT", h1, "BOTTOMLEFT", 0, -6)
	P.plan:SetPoint("BOTTOMLEFT", 0, 34)
	local h2 = UI:Header(p, L["Raid-Vorbereitung"])
	h2:SetPoint("TOPLEFT", 400, 0)
	P.prep = UI:ScrollText(p, 382, 500)
	P.prep:SetPoint("TOPLEFT", h2, "BOTTOMLEFT", 0, -6)
	P.prep:SetPoint("BOTTOMRIGHT", 0, 34)
	local b = UI:Button(p, L["Neu einlesen"], 150, 26, function()
		if RequestRaidInfo then RequestRaidInfo() end
		MW:Scan()
		P:Refresh()
	end)
	b:SetPoint("BOTTOMLEFT", 0, 0)
end

function P:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	self.plan:SetText(MW:PlanText())
	self.prep:SetText(MW:PrepText())
end

P.onShow = function() P:Refresh() end
local function WhenShown(fn) return function() if UI:IsPageShown("myweek") then fn() end end end
ns:Listen("GS_MYWEEK", WhenShown(function() P:Refresh() end))
ns:On("BAG_UPDATE_DELAYED", WhenShown(function() P:Refresh() end))
ns:On("UPDATE_INVENTORY_DURABILITY", WhenShown(function() P:Refresh() end))
UI:AddPage(P)
