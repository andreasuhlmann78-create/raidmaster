-- AHSentinel - Prüfliste im Spiel (nur Entwicklermodus)
-- Copyright (C) 2026 GoldSentinel
-- This file is part of AHSentinel. AHSentinel is free software: you can redistribute it and/or modify it under the terms
-- of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at
-- your option) any later version. See LICENSE.txt.
--
-- Entscheid des Nutzers 16.11.2026 06:47 (Supervisor 06:49): Für jeden Punkt "im Client prüfen" eine Prüfliste im Spiel mit dem
-- gemeinsamen Baustein GoldSentinelPruefliste.lua. Nur Entwicklermodus (/ahs entwickler an UND GoldSentinelDev), merkt selbst,
-- zeigt immer, was zu tun ist. Zuerst: Sniper-Abnahme 16.11. (vor dem CurseForge-Upload 18:00).
-- Ohne Entwicklermodus kostet nichts etwas: P:On() ist dann sofort false, Hit/Fail tun nichts.

local A = AHAnalyzerPro
local string = A.SafeString or string          -- AHS-OVF1: string.format ohne 32-Bit-Überlauf (gleicher Text darunter)
local P = {}
A.Pruefliste = P

P.ADDON = "AHSentinel"
-- Punkte in der Reihenfolge, in der der Nutzer sie im Spiel macht (höchstens 14). "since" = Version, ab der der Punkt gilt;
-- kommt ein Punkt mit neuer Fassung, ist er wieder offen.
-- TR-ALLE (Entscheid des Nutzers 17.11.2026 07:36, Supervisor 07:40): Alles, was ohne Hand geht, macht "/ahs testroutine alles"
-- (ein Punkt). Von Hand bleiben nur echter Klick, echtes Mausrad, echtes Gold (Testkauf ≤ 1 Gold, Auktion ≤ 10 Silber) und
-- Händler-Gold. Jeder Text nach Abschnitt B: Wo / nummerierte Schritte (ein Handgriff je Schritt, Knopfnamen wie im Spiel) /
-- was du siehst (wörtlich) / Kosten. Keine Fachwörter. Texte passen ins Fenster (T880 rechnet die Zeilen nach).
-- Nicht mehr von Hand (in "testroutine alles"): SN-TR, SN-GRENZE (T549/T559), ESL1 (T794/T842), SCHN-ALARM (T846/T870), VOLLSCAN,
-- WAECHTER-LAST, WAECHTER-FUND, UI-TEST, HILFE-GRP.
P.POINTS = {
    -- PL-305-1 (Supervisor 17.11.): Berufsfenster und Händler gehören zum Ablauf (Schritte 8 und 9), sonst „nicht prüfbar“
    { id = "TR-ALLES", title = "Alle automatischen Prüfungen", since = "0.65.307",
      todo = "Wo: Auktionshaus offen. 1. In den Chat: /ahs testroutine alles  2. Nichts anklicken, nicht weglaufen. 3. Chat: "
          .. "„… Berufsfenster …“: Beruf im Berufs-/Zauberbuch anklicken, dann ein Rezept. 4. Chat: „… nächsten Händler …“: "
          .. "Auktionshaus zu, zum Händler gehen, ansprechen (5 Min.). Abbrechen: /ahs testroutine stop",
      expect = "Chat: „Testroutine alles: 9 von 9 bestanden, 0 FEHLER …“ (ohne Beruf: „kein Beruf“, zählt nicht), dann Fenster "
          .. "„Testbericht“. Kosten: kein Gold, ca. 50 Min." },
    { id = "SN-BTN1", title = "Kauf-Knopf: echter Testkauf", since = "0.65.305",
      todo = "Wo: Auktionshaus. 1. Oben „Kaufen“, dann „Sniper“. 2. Feld „Name, ID oder Suchwort“: Leinenstoff. 3. Feld daneben "
          .. "(zeigt 1000): 1. 4. „Max/Stück:“ (Höchstpreis): 50s. 5. „Ziel setzen“. 6. „Sniper-Modus: AUS“ anklicken. 7. Breiter "
          .. "Knopf unten zeigt „Preis anfragen (1× Leinenstoff)“: 1 Klick. 8. Er zeigt „Kaufen bestätigen …“: 1 Klick.",
      expect = "Chat: „Gekauft: 1x Leinenstoff für …“. Eine rote Warnung „über dem Verkaufswert“ ist hier normal. "
          .. "Kosten: höchstens 50 Silber, 2 Min." },
    { id = "SN-RAD-B", title = "Mausrad: eine Raste = ein Kauf", since = "0.65.305",
      todo = "Wo: Auktionshaus, Sniper. 1. Knopf „Mausrad“ (neben „Sniper-Modus“) muss GRÜN sein, sonst anklicken. 2. Ziel "
          .. "wie eben: Leinenstoff, 1, 50s, „Ziel setzen“. 3. Breiter Knopf zeigt „Preis anfragen …“: EINE Raste am Mausrad. "
          .. "4. Er zeigt „Kaufen bestätigen …“: noch EINE Raste.",
      expect = "Chat: „Gekauft: 1x Leinenstoff für …“, genau 1 Stück. Kosten: höchstens 50 Silber, 2 Min." },
    { id = "SN-RAD-A", title = "Mausrad grau: kauft nie", since = "0.65.305",
      todo = "Wo: Auktionshaus, Sniper. 1. Knopf „Mausrad“ anklicken: er wird GRAU. 2. Ziel wie eben: Leinenstoff, 1, 50s, "
          .. "„Ziel setzen“. 3. Breiter Knopf zeigt „Preis anfragen …“: Mausrad drehen. 4. In der Zielliste beim Leinenstoff "
          .. "„X“ (Ziel weg). 5. „Mausrad“ anklicken (wieder GRÜN).",
      expect = "Es wird NICHTS gekauft (kein „Gekauft:“ im Chat). Kosten: kein Gold, 1 Min." },
    { id = "POST-WS", title = "Zu billig: trotzdem einstellen", since = "0.65.305",
      todo = "Wo: Auktionshaus. 1. Oben „Verkaufen“, dann „Einstellen“. 2. Links „Leinenstoff“ anklicken. 3. „Menge“: 1. "
          .. "4. „Preis/Stück“: 1c (1 Kupfer, absichtlich zu billig). 5. „Einstellen“. 6. Im Fenster „Warnschutz“: „Trotzdem einstellen“.",
      expect = "Warnung „Achtung: …“, danach Chat „Eingestellt: 1x Leinenstoff …“, keine zweite Warnung. "
          .. "Kosten: 1 Leinenstoff (wird wohl gekauft)." },
    { id = "POST-TEUER", title = "Zu teuer: Preis anpassen", since = "0.65.305",
      todo = "Wo: Auktionshaus, „Verkaufen“ > „Einstellen“. 1. Links „Leinenstoff“. 2. „Menge“: 1. 3. „Preis/Stück“: 50g. "
          .. "4. „Einstellen“. 5. Im Fenster „Warnschutz“: „Preis anpassen (…)“. 6. „Einstellen“. 7. Oben „Meine Auktionen“, "
          .. "beim Leinenstoff „X“ (abbrechen).",
      expect = "Warnung „Achtung: … über …“, Preis danach knapp unter dem günstigsten Angebot, „Eingestellt: …“ ohne neue "
          .. "Warnung. Kosten: Gebühr unter 1 Silber." },
    { id = "HAENDLER-GOLD", title = "Graue Items beim Händler", since = "0.65.305",
      todo = "Wo: bei einem Händler, graue Items in der Tasche. 1. Händler ansprechen. 2. Maus auf den Knopf „Verkaufen: n Items (…)“ "
          .. "über dem Händlerfenster: die Liste zeigt, was verkauft wird (steht etwas zum Behalten dort: NICHT klicken). 3. Klicken.",
      expect = "Die Items sind weg, Gold steigt um den Betrag. Kosten: keine (Rückkauf beim Händler möglich)." },
}

-- HILFE-GRP-1: nach "/ahs hilfe" (A.helpShown: Gruppen und doppelte Befehle der gezeigten Liste) und "/ahs einstellungen"
-- (A.optViaCmd) -> erledigt; zu wenig Gruppen oder Doppelte -> Fehler; sonst offen (nil)
function P.HelpAuto()
    local h = A.helpShown
    if not h then return nil end
    if h.groups < 3 or h.dup > 0 then
        return false, string.format("Hilfe: %d Gruppen (mind. 3: Alltag, Einstellungen, Hilfe), %d Befehle doppelt", h.groups, h.dup)
    end
    if not A.optViaCmd then return nil end
    return true, string.format("Hilfe: %d Gruppen, %d Befehle, nichts doppelt; /ahs einstellungen öffnete die Optionen", h.groups, h.cmds)
end
function P:HelpCheck()
    local ok, r, info = pcall(P.HelpAuto)
    if not ok then return nil end
    if r == true then return self:Hit("HILFE-GRP", info) end
    if r == false then return self:Fail("HILFE-GRP", info) end
    return nil
end

-- an, wenn AHSentinel im Entwicklermodus ist und der gemeinsame Baustein da ist (GoldSentinelDev entscheidet dort selbst)
function P:On()
    return A:IsDev() and type(_G.GoldSentinelPruefliste) == "table" or false
end
-- die Liste (einmal angelegt, sobald der Entwicklermodus an ist); nil ohne Entwicklermodus
function P:List()
    if not self:On() then return nil end
    local G = _G.GoldSentinelPruefliste
    local l = self.list
    if l and G:Get(self.ADDON) == l then return l end
    local reg = G:Register(self.ADDON, {
        db = function() return P.testDB or A.db end,          -- Testroutine: eigene Ersatz-Daten (nie die echten)
        version = A.version,
        points = self.POINTS,
    })
    if G:Get(self.ADDON) ~= reg then return nil end              -- GoldSentinelDev sagt nein: wirkungslose Liste, nichts merken
    self.list = reg
    return reg
end
-- 0.65.305: gibt es den Punkt (noch)? Entfernte Punkte (z. B. VOLLSCAN, jetzt in "testroutine alles") lösen keine Messung mehr aus -
-- List:State meldet für unbekannte Punkte "offen", darum vor jeder teuren Messung hier fragen
function P:Has(id)
    local l = self:List()
    return (l and l.byId and l.byId[id] ~= nil) and true or false
end
-- NP-MK-1 (a) (0.65.306) + NP306-1 (0.65.307, keine Sperre ohne Zeitlimit): Testkäufe der Prüfliste zählen nie als Empfehlung
-- "snipe" – aber NUR genau diese: Item HAND_ITEM (Leinenstoff, wie im Text) mit dem Höchstpreis HAND_MAX (50s), solange ein
-- Sniper-Handpunkt offen ist und höchstens HAND_HOURS Std. nach dem Öffnen der Prüfliste bzw. der letzten Änderung eines
-- Sniper-Handpunkts. Alles andere zählt wie immer.
P.HAND_SNIPER = { "SN-BTN1", "SN-RAD-B", "SN-RAD-A" }
P.HAND_ITEM, P.HAND_MAX, P.HAND_HOURS = 2589, 5000, 24
function P:HandTest(itemID, maxPrice, now)
    if itemID ~= self.HAND_ITEM or maxPrice ~= self.HAND_MAX then return false end
    if not self:On() then return false end
    local l = self:List()
    if not l then return false end
    now = now or time()
    local db = self.testDB or A.db
    local last = db and db.plOpenT or 0
    local open = false
    for _, id in ipairs(self.HAND_SNIPER) do
        if l.byId and l.byId[id] then
            local st, e = l:State(id)
            if st ~= "auto" and st ~= "ok" then open = true end
            if e and e.t and e.t > last then last = e.t end
        end
    end
    return open and now - last <= self.HAND_HOURS * 3600
end
-- die Testroutine löst nichts aus (ihre Ereignisse sind nachgespielt); fromTR = Meldung der Testroutine selbst
local function Quiet(fromTR)
    local TR = A.TestRoutine
    return not fromTR and TR and TR.running and not P.testAllow
end
function P:Hit(id, note, fromTR)
    if Quiet(fromTR) then return false end
    local l = self:List()
    if not l then return false end
    -- SN-RAD (e) (Ingame-Test 16.11.): ein vom Addon erkannter Fehler verschwindet nie still - erst "Zurücksetzen" im Fenster
    if l:State(id) == "fehler" then
        if not (self.keptNote and self.keptNote[id]) then
            self.keptNote = self.keptNote or {}
            self.keptNote[id] = true
            A:Print("|cffff5544" .. "Prüfliste: " .. id .. " bleibt Fehler – erst im Fenster „Zurücksetzen“, dann neu prüfen.|r")
        end
        return false
    end
    local ok, r = pcall(l.Hit, l, id, note)
    return ok and r or false
end
-- vom Addon erkannter Fehler -> Zustand "Fehler (erkannt)" mit Notiz (ein OK des Spielers bleibt)
function P:Fail(id, note, fromTR)
    if Quiet(fromTR) then return false end
    local l = self:List()
    if not l then return false end
    local s = l:State(id)
    if s == "ok" then return false end
    local ok, r = pcall(l.Set, l, id, "fehler", note)
    if ok and r then
        A:Print("|cffff5544" .. "Prüfliste: " .. id .. " Fehler (erkannt)|r" .. (note and (" – " .. tostring(note)) or ""))
        if l.frame and l.frame:IsShown() then pcall(l.Refresh, l) end
    end
    return ok and r or false
end
function P:Open()
    local l = self:List()
    if not l then
        A:Print("Prüfliste: nur im Entwicklermodus (GoldSentinelDev erkennt dich nicht).")
        return false
    end
    local db = self.testDB or A.db
    if db then db.plOpenT = time() end                 -- NP306-1: Beginn des 24-Std.-Fensters für Testkäufe
    return l:Open()
end
-- Zeilen für den Testbericht (leer ohne Entwicklermodus)
function P:ReportLines()
    local l = self:List()
    if not l then return {} end
    local ok, lines = pcall(l.ReportLines, l)
    return ok and lines or {}
end
