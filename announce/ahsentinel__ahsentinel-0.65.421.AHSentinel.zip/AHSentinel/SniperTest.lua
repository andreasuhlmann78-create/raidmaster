if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - SniperTest.lua
-- SN1951-ABNAHME (Entscheid des Nutzers 13.11. 20:31): "/ahs testroutine sniper" prüft den Sniper am OFFENEN
-- Auktionshaus im echten Spiel - was die Sandbox nicht kann:
--   S4 echter Mausrad-Kauf von 1 Stück bis 5c - NUR nach "Ja" des Spielers in einem eigenen Fenster, gekauft wird nur
--      durch die Raste/Taste des Spielers (Tastendruck). Läuft VOR der Testroutine (ausserhalb der Sandbox), damit der
--      echte Kauf echt gebucht bleibt. Ohne Ja (oder ohne Angebot <= 5c) wird S4 übersprungen.
--   danach die Testroutine, Teil "sniper" (Sandbox, Kaufen gesperrt):
--   S1 Treffer bleiben stehen (Ziel Leinenstoff o. ä., 2 Min. beobachten, nichts verschwindet ohne Grund)
--   S2 Zähler/Budget nur bestätigte Käufe (gesendet -> Fehler -> Bestätigung, an einem Testziel in der echten Anzeige)
--   S3 Pause sichtbar in Zielzeile und Status, "fortsetzen" wirkt sofort
--   S5 Ruckeln: Bilder/s, längster Frame, Sync-Warteschlange während der Beobachtung
--   S6 Reaktionszeit: Abstand der Suchen je Ziel + Suchdauer = spätestens sichtbar nach
-- SN-TEST2 (Auftrag 18:54): beobachtet die Ziele des Spielers (ohne eigene Ziele ein Testziel) und misst dazu
--   S7 Takt, S8 reihum, S9 Treffer richtig, S10 Geld-Sicherheit, S11 Pausen, S12 verpasst, S13 Ruckeln (≤ 33 ms);
--   oben im Bericht das Ergebnis in 3–4 einfachen Sätzen. Nachbildung T735–T742.
-- Keine Spielernamen, kein Chat-Eingabefeld, keine ersetzte Blizzard-Funktion.
-- ============================================================
local A = AHAnalyzerPro
local string = A.SafeString or string          -- AHS-OVF1: string.format ohne 32-Bit-Überlauf (gleicher Text darunter)
local CreateFrame, C_Timer = A.OwnCreateFrame or CreateFrame, A.OwnTimer or C_Timer      -- VS-BILD-2 (0.65.320): eigene Skripte/Zeitgeber je Bild messen (nur während einer Vollscan-Messung)
local L = A.L
local SPT = {}
A.SniperTest = SPT

SPT.OBSERVE = 120          -- Sekunden Beobachtung (S1, S5, S7–S13; S6 nur ohne eigene Ziele)
SPT.S6_OBS = 60            -- S6 A (Supervisor 16.11. 21:58): eigene Phase NUR mit dem Test-Ziel, eigene Ziele so lange pausiert
SPT.S6_GRACE = 15          -- spätestens S6_OBS + S6_GRACE s nach dem Start sind die eigenen Ziele wieder aktiv (Zeitlimit)
SPT.CHEAP_MAX = 5          -- S4: Höchstpreis in Kupfer
SPT.S4_WAIT = 60           -- S4: so lange wartet der Testkauf auf die Raste (TB188-6: Gesamtlauf ≤ 5 Min.)
SPT.ASK_MAX = 30           -- TB188-6: Frage S4 ohne Antwort -> nach 30 s "Nein" (übersprungen), Routine läuft weiter
SPT.ITEMS = { 2589, 2592, 4306, 2996, 2840 }   -- S1: günstige, viel gehandelte Waren (Leinen-, Wollstoff …)

local function Now() return GetTime() end

-- ------------------------------------------------------------
-- Einstieg: /ahs testroutine sniper
-- ------------------------------------------------------------
function SPT:Begin()
    if not A:IsAHOpen() then A:Print(L["Sniper-Abnahme: bitte zuerst das Auktionshaus öffnen."]); return false end
    if A:InCombat() then A:Print(L["Im Kampf kann die Testroutine nicht starten."]); return false end
    local TR = A.TestRoutine
    if TR and TR.running then A:Print(L["Selbsttest läuft schon ..."]); return false end
    if A:IsScanning() then A:Print(L["Erst den laufenden Markt-Scan abwarten, dann die Testroutine starten."]); return false end   -- TB188-7
    self.s4 = nil
    self:AskS4()
    return true
end

-- eigenes kleines Fenster (kein Blizzard-Popup verändert)
function SPT:AskS4()
    local f = self.ask
    if not f then
        f = CreateFrame("Frame", nil, UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
        f:SetSize(420, 130)
        f:SetPoint("CENTER", 0, 120)
        f:SetFrameStrata("DIALOG")
        if f.SetBackdrop then
            f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
            f:SetBackdropColor(0.06, 0.06, 0.08, 0.95)
            f:SetBackdropBorderColor(0, 0.82, 0.82, 1)
        end
        f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        f.text:SetPoint("TOP", 0, -16)
        f.text:SetWidth(390)
        f.text:SetText(string.format(L["Sniper-Abnahme S4: echter Testkauf von 1 Stück bis %s erlaubt? Gekauft wird nur mit deiner Mausrad-Raste bzw. Taste."],
            A:FormatMoney(self.CHEAP_MAX)))
        local UI = A.UI
        f.yes = UI:Button(f, L["Ja"], 120, 24, function() f:Hide(); SPT:S4Answer(true) end, "primary")
        f.yes:SetPoint("BOTTOMLEFT", 70, 14)
        f.no = UI:Button(f, L["Nein"], 120, 24, function() f:Hide(); SPT:S4Answer(false) end)
        f.no:SetPoint("BOTTOMRIGHT", -70, 14)
        self.ask = f
    end
    f:Show()
    -- TB188-6: nie hängen - ohne Antwort nach ASK_MAX s weiter (S4 übersprungen)
    local token = {}
    self.askToken = token
    if C_Timer and C_Timer.After then
        C_Timer.After(self.ASK_MAX, function()
            if SPT.askToken ~= token or not (f.IsShown and f:IsShown()) then return end
            f:Hide()
            SPT.askToken = nil
            SPT.s4 = { status = "SKIP", detail = string.format(L["keine Antwort auf die Frage in %d s – Testkauf übersprungen"], SPT.ASK_MAX) }
            A:Print(L["Sniper-Abnahme S4: "] .. SPT.s4.detail)
            SPT:StartRoutine()
        end)
    end
end

-- günstigstes frisches Angebot <= CHEAP_MAX aus dem letzten Scan
function SPT:CheapItem()
    local best, bestP
    local maxAge = (A.PRICE_OLD_HOURS or 6) * 3600
    for id in pairs(A.db and A.db.marketData or {}) do
        local p, _, t = A:GetCurrent(id)
        if p and p > 0 and p <= self.CHEAP_MAX and t and time() - t <= maxAge and (not bestP or p < bestP) then best, bestP = id, p end
    end
    return best, bestP
end

function SPT:S4Answer(yes)
    self.askToken = nil
    if not yes then
        self.s4 = { status = "SKIP", detail = L["Spieler hat den Testkauf nicht erlaubt (Nein)"] }
        return self:StartRoutine()
    end
    local Sn = A.Sniper
    local id, p = self:CheapItem()
    if not (Sn and id) then
        self.s4 = { status = "SKIP", detail = string.format(L["kein Angebot bis %s im letzten Scan"], A:FormatMoney(self.CHEAP_MAX)) }
        return self:StartRoutine()
    end
    local key = "i:" .. id
    local db = A.db.sniper
    local prev = db.targets[key]
    local wasArmed = db.armed
    local ok = Sn:SetTarget(tostring(id), self.CHEAP_MAX, 1, self.CHEAP_MAX)
    if not ok then
        self.s4 = { status = "SKIP", detail = "Testziel ließ sich nicht anlegen" }
        return self:StartRoutine()
    end
    local t = db.targets[key]
    local sent0 = self.sendCount or 0
    self.s4run = { id = id, key = key, prev = prev, wasArmed = wasArmed, t = t, t0 = Now(), price = p, sent0 = sent0,
        money0 = GetMoney and GetMoney() or nil }       -- SN-TEST2 S10: Gold vorher
    if not wasArmed then Sn:SetArmed(true) end
    A:Print(string.format(L["Sniper-Abnahme S4: Ziel %s bis %s, 1 Stück. Sobald „Treffer“ erscheint: EINE Mausrad-Raste bzw. Taste (höchstens %d s)."],
        A:GetItemName(id), A:FormatMoney(self.CHEAP_MAX), self.S4_WAIT))
    self:PollS4()
    return true
end

-- Sendungen zählen (Einzelkauf und Warenkauf), nur gelesen über die Sniper-Felder
function SPT:Sends()
    local Sn = A.Sniper
    local n = 0
    for _ in ipairs(Sn.itemBuys or {}) do n = n + 1 end
    if Sn.inFlight then n = n + 1 end
    return n
end

function SPT:PollS4()
    local r = self.s4run
    if not r then return end
    local t = r.t
    local done = t and (t.bought or 0) >= 1
    local timeout = Now() - r.t0 > self.S4_WAIT
    local Sn0 = A.Sniper
    -- SN-TEST2 S12: Treffer sichtbar -> Zeit bis zum bestätigten Kauf (Reaktion des Spielers)
    if not r.hitAt and Sn0 and Sn0.HitMarked and Sn0:HitMarked(r.key) then r.hitAt = Now() end
    if done and not r.doneAt then r.doneAt = Now() end
    -- SN-TEST2 S10: nach dem Kauf 1,5 s warten, dann Gold nachher lesen
    if not (done or timeout) or (done and Now() - r.doneAt < 1.5) then
        if not done then r.maxOpen = math.max(r.maxOpen or 0, self:Sends()) end
        C_Timer.After(0.5, function() SPT:PollS4() end)
        return
    end
    -- Bestätigung abwarten, dann aufräumen
    local Sn = A.Sniper
    local bought, spent = t and t.bought or 0, t and t.spent or 0
    if done then
        local okOne = bought == 1 and spent <= self.CHEAP_MAX and (r.maxOpen or 0) <= 1
        self.s4 = { status = okOne and "PASS" or "FAIL", detail = string.format("gekauft %d für %s · höchstens %d gleichzeitig gesendet · nach %.0f s",
            bought, A:FormatMoney(spent), r.maxOpen or 0, Now() - r.t0) }
        self.s4.bought, self.s4.hit = bought, true
        self.s4.react = r.hitAt and (r.doneAt - r.hitAt) or nil
        -- SN-B8: Gold anderer, im selben Fenster gezählter Käufe (z. B. noch offene Sniper-Käufe davor) gehört nicht zum Testkauf
        local other = A.Sniper.SpentSince and (A.Sniper:SpentSince(r.t0) - spent) or 0
        self.s4.gold = { m0 = r.money0, m1 = GetMoney and GetMoney() or nil, spent = spent, other = math.max(0, other) }
    else
        self.s4 = { status = "SKIP", detail = string.format("kein Kauf in %d s (keine Raste oder kein Treffer)", self.S4_WAIT), bought = 0, hit = r.hitAt ~= nil }
    end
    local db = A.db.sniper
    if r.prev then db.targets[r.key] = r.prev else db.targets[r.key] = nil end
    if not r.wasArmed then Sn:SetArmed(false) end
    if Sn.result and Sn.result.key == r.key then Sn.result = nil end
    A:Fire("SNIPER_CHANGED")
    self.s4run = nil
    A:Print(L["Sniper-Abnahme S4: "] .. self.s4.status .. " – " .. self.s4.detail)
    C_Timer.After(1, function() SPT:StartRoutine() end)
end

-- TB188-7: läuft gerade ein echter Scan (z. B. während der Frage S4 gestartet), erst warten (höchstens 120 s), dann starten
SPT.SCAN_WAIT_MAX = 120
function SPT:StartRoutine()
    local TR = A.TestRoutine
    if not TR then return end
    if A:IsScanning() then
        if not self.scanWaitT then
            self.scanWaitT = Now()
            A:Print(L["Sniper-Abnahme: wartet, bis der laufende Markt-Scan fertig ist ..."])
        end
        if Now() - self.scanWaitT < self.SCAN_WAIT_MAX and C_Timer and C_Timer.After then
            C_Timer.After(1, function() SPT:StartRoutine() end)
            return
        end
        self.scanWaitT = nil
        A:Print(L["Sniper-Abnahme abgebrochen: der Markt-Scan läuft länger als 2 Minuten."])
        return
    end
    self.scanWaitT = nil
    TR:Start("sniper")
end

-- ------------------------------------------------------------
-- Testroutine Teil "sniper" (Sandbox: Kaufen gesperrt, Daten danach zurück)
-- ------------------------------------------------------------
-- Beobachtung: je Änderung der Sniper-Anzeige die sichtbaren Treffer; verschwindet einer, obwohl die neueste Antwort
-- des Servers ihn noch enthält (und er nicht gekauft/weg ist), ist das ein Fehler (S1)
function SPT:Visible(Sn, t)
    local r = Sn.result
    local set = {}
    if not (r and t and r.key == t.key) then return set, r end
    for _, l in ipairs(r.listings or {}) do
        -- Waren haben keine auctionID: Preis und Menge als Schlüssel
        local k = l.auctionID or (tostring(l.price) .. "x" .. tostring(l.qty))
        if not l.gone and not l.own and not l.bait and l.price and l.price <= (t.maxPrice or 0) then set[k] = l end
    end
    return set, r
end

-- ------------------------------------------------------------
-- SN-TEST2 (Auftrag 18:54): Messungen S7–S13 während der Beobachtung. Alle Auswertungen sind reine Funktionen auf dem
-- Beobachtungs-Protokoll o (dieselben Funktionen prüft die Nachbildung T735–T742).
-- ------------------------------------------------------------
SPT.FRAME_MAX = 33          -- S13: kein Frame länger als 33 ms
SPT.RESUME_MAX = 5          -- S11: nach einer Pause spätestens 5 s bis zur nächsten Suche
SPT.ROUND_FACTOR = 1.5      -- S8: jedes Ziel spätestens nach Ziele × Ø Abstand × 1,5
-- E/T729 (0.65.325, Ingametest 17.11. "5 Ziele je 31× · längste Lücke 10–13 s > Grenze 5,3 s"): "spieler" (GSL3-2: der Spieler benutzt
-- das AH selbst, der Sniper wartet absichtlich bis USER_PAUSE) fehlte hier - diese Wartezeit zählte als Lücke jedes Ziels.
SPT.PAUSE_WHY = { scan = true, vollscan = true, buy = true, seller = true, treffer = true, spieler = true }   -- GSL1-1: Treffer-Halt ist eine Pause
SPT.S_IDS = { { "S1", "T613" }, { "S2", "T614" }, { "S3", "T615" }, { "S4", "T616" }, { "S5", "T617" }, { "S6", "T618" }, { "S7", "T728" },
    { "S8", "T729" }, { "S9", "T730" }, { "S10", "T731" }, { "S11", "T732" }, { "S12", "T733" }, { "S13", "T734" } }

local function OfferKey(l, commodity)
    if l.auctionID then return l.auctionID end
    if commodity then return tostring(l.price) end                 -- Waren: je Preis eine Zeile (Menge ändert sich)
    return tostring(l.price) .. "x" .. tostring(l.qty)
end

-- S7/S8/S11: eine Suche des Snipers beginnt
function SPT:NoteSearch(o, key, now)
    -- SN-EIGEN (Auftrag 19.11. 10:55): w = bisherige Wartezeit auf den Server (Antwort/Drossel) in aktiver Zeit, für T729
    o.all[#o.all + 1] = { k = key, t = now, a = o.act or 0, ap = o.pauseFlag, w = o.srvA or 0 }        -- TB188-9: erste Suche nach einer Pause
    o.pauseFlag = nil
    if key == o.key then o.searches[#o.searches + 1] = now end
    for _, p in ipairs(o.pauses or {}) do
        if p.t1 and not p.resume then p.resume = math.max(0, now - p.t1) end
    end
end

-- S9/S12: neue Antwort des Servers für Ziel t. Treffer = Angebot ≤ Max (Stückpreis); verpasst = Treffer, der in einer
-- späteren Antwort fehlt (von anderen gekauft), mit der Zeit vom Erkennen bis weg. Rückgabe: Antwort hat einen Kauf geplant
function SPT:NoteResult(o, t, r, now)
    o.hit9 = o.hit9 or { n = 0, checked = 0, bad = 0, gold = 0 }
    o.hitSeen, o.missed, o.hitNew = o.hitSeen or {}, o.missed or {}, o.hitNew or 0
    local seen = o.hitSeen[t.key] or {}
    local cur, planned = {}, false
    local max = t.maxPrice or 0
    for _, l in ipairs(r.listings or {}) do
        local k = OfferKey(l, r.commodity)
        if not l.gone then cur[k] = true end
        if l.planned and l.planned > 0 and not l.bait then
            planned = true
            o.hit9.checked = o.hit9.checked + 1
            local per = (not r.commodity and l.buyout and l.qty and l.qty > 0) and (l.buyout / l.qty) or l.price
            local pmax = l.planMax or max                     -- SN-B5: Max zur Planungszeit (Max während des Tests geändert)
            if not per or per > pmax + 0.5 then
                o.hit9.bad = o.hit9.bad + 1
                o.hit9.badTxt = string.format("%s Stückpreis %s > Max %s", tostring(k), tostring(per), tostring(pmax))
            end
        end
        if not l.gone and not l.own and not l.bait and l.pass ~= false and l.price and l.price <= max and not seen[k] then
            seen[k] = now
            o.hitNew = o.hitNew + 1
        end
    end
    for k, t0 in pairs(seen) do
        if not cur[k] then o.missed[#o.missed + 1] = now - t0; seen[k] = nil end
    end
    o.hitSeen[t.key] = seen
    if planned then o.hit9.n = o.hit9.n + 1 end
    return planned
end

-- S13 (und S5): ein Bild
function SPT:NoteFrame(o, ms, fps)
    o.frames = (o.frames or 0) + 1
    if o.frames > 5 then
        if ms > (o.frameMax or 0) then o.frameMax = ms end
        if ms > self.FRAME_MAX then o.over33 = (o.over33 or 0) + 1 end
    end
    if fps then
        o.fpsSum, o.fpsN = (o.fpsSum or 0) + fps, (o.fpsN or 0) + 1
        if not o.fpsMin or fps < o.fpsMin then o.fpsMin = fps end
    end
end

-- SN-TEST2-1 (Prüfung 0.65.176): Ursache eines langen Bildes. Reihenfolge: Hintergrund-Aufgabe von AHSentinel im
-- selben Bild, Ereignis eines AHSentinel-Moduls (A:TimeFrame, z. B. Sniper-Auswertung), Sync-Warteschlange hat gesendet,
-- sonst ausserhalb von AHSentinel (Spiel oder anderes Addon). Höchstens 10 Bilder je Beobachtung, dazu Zähler je Ursache.
SPT.LONG_MAX = 10
function SPT:FrameCause(now, q, lastQ, jf, se)
    if jf and jf.t and now - jf.t <= 0.1 and (jf.d or 0) > 16 then
        return string.format("AHSentinel Hintergrund %s %.0f ms%s", tostring(jf.job), jf.d, jf.at and (" (" .. tostring(jf.at) .. ")") or ""), "ahs"
    end
    if se and se.t and now - se.t <= 0.1 then
        return string.format("AHSentinel %s/%s %.0f ms", tostring(se.at), tostring(se.ev), se.ms or 0), (se.at == "Sniper") and "sniper" or "ahs"
    end
    if lastQ and q and q < lastQ then
        local GSS = _G.GoldSentinelSync
        local mix = (A.Sync and A.Sync.QueueMix) and select(2, pcall(A.Sync.QueueMix, A.Sync)) or nil
        return "Sync gesendet (Warteschlange " .. tostring(lastQ) .. (mix and (", " .. tostring(mix)) or "") .. ")", "sync"
    end
    return "nicht AHSentinel (Spiel oder anderes Addon)", "fremd"
end
function SPT:NoteLongFrame(o, ms, now, q)
    local txt, kind = self:FrameCause(now, q, o.lastQ, A.lastJobFrame, A.lastSlowEvent)
    o.longBy = o.longBy or {}
    o.longBy[kind] = (o.longBy[kind] or 0) + 1
    -- SN-TR-1 (c): AHSentinel-Ursachen EINZELN zählen (Aufgabe bzw. Modul/Ereignis, Anzahl, längstes Bild)
    if kind == "ahs" or kind == "sniper" then
        local jf, se = A.lastJobFrame, A.lastSlowEvent
        local key = (jf and jf.t and now - jf.t <= 0.1 and (jf.d or 0) > 16) and ("Aufgabe " .. tostring(jf.job))
            or (se and (tostring(se.at) .. "/" .. tostring(se.ev))) or "?"
        o.longAhs = o.longAhs or {}
        local e = o.longAhs[key]
        if not e then e = { n = 0, max = 0 }; o.longAhs[key] = e end
        e.n = e.n + 1
        if ms > e.max then e.max = ms end
    end
    o.longFrames = o.longFrames or {}
    if #o.longFrames < self.LONG_MAX then o.longFrames[#o.longFrames + 1] = string.format("%.0f ms: %s", ms, txt) end
end
function SPT:LongText(o)
    if not o.longFrames or #o.longFrames == 0 then return "" end
    local by = {}
    for _, k in ipairs({ "sniper", "ahs", "sync", "fremd" }) do
        if (o.longBy or {})[k] then by[#by + 1] = string.format("%s %d", ({ sniper = "Sniper", ahs = "AHSentinel", sync = "Sync", fremd = "fremd" })[k], o.longBy[k]) end
    end
    local each = {}
    for k, e in pairs(o.longAhs or {}) do each[#each + 1] = { k = k, n = e.n, max = e.max } end
    table.sort(each, function(a, b) if a.n ~= b.n then return a.n > b.n end return a.k < b.k end)
    local et = {}
    for i = 1, math.min(8, #each) do et[#et + 1] = string.format("%s ×%d (bis %.0f ms)", each[i].k, each[i].n, each[i].max) end
    if #each > 8 then et[#et + 1] = string.format("+%d weitere", #each - 8) end
    return " · Ursachen: " .. table.concat(by, ", ") .. (#et > 0 and (" · AHSentinel einzeln: " .. table.concat(et, ", ")) or "")
        .. " (" .. table.concat(o.longFrames, "; ") .. ")"
end
-- SN-TR-1 (a) (Ingame-Test 16.11.: Ø 6 Bilder/s, WoW lief im Hintergrund): WoW drosselt im Hintergrund die Bildrate
-- (CVar maxFPSBk). Liegt der Schnitt nahe dieser Grenze (oder unter 12 Bilder/s, wenn sie unbekannt ist), sind Ruckeln,
-- Reaktion, reihum und Pausen nicht messbar -> SKIP mit Grund statt FEHLER. Rückgabe: Text oder nil.
SPT.BG_FPS = 12
SPT.BG_TOL = 1.1          -- SN-BG2: Schnitt bis 10 % über der Hintergrund-Grenze gilt als gedrosselt
function SPT:BackgroundText(o)
    local avg = o and (o.fpsN or 0) > 0 and o.fpsSum / o.fpsN or nil
    if not avg then return nil end
    local bk
    local GC = A:Global("GetCVar")
    if GC then local ok, v = pcall(GC, "maxFPSBk"); bk = ok and tonumber(v) or nil end
    -- SN-BG2 (Ingametest 19.11. 10:00, Laptop Unterstadt: Ø 31 / min 23 Bilder/s bei Hintergrund-Grenze 30 -> T617/T729/T734 FEHLER, um
    -- 06:35 mit Ø 30 noch SKIP): eine gedrosselte Bildrate schwankt um die Grenze, der Schnitt liegt oft 1 darüber. Toleranz jetzt
    -- 10 % über der Grenze (30 -> bis 33,5), statt 0,5. Ebenso eine Vordergrund-Grenze (maxFPS) bis 33: dann ist jedes Bild >= 30 ms
    -- und "kein Bild > 33 ms" nicht prüfbar.
    local bg = (bk and bk > 0 and avg <= bk * self.BG_TOL + 0.5 and avg >= bk * 0.6) or ((not bk or bk <= 0) and avg < self.BG_FPS)
    if not bg then
        local fg
        if GC then local ok, v = pcall(GC, "maxFPS"); fg = ok and tonumber(v) or nil end
        if fg and fg > 0 and fg <= 33 and avg <= fg * self.BG_TOL + 0.5 then
            return string.format("Bildrate auf %d begrenzt (Einstellung maxFPS, Ø %.0f Bilder/s) – Ruckeln und Tempo hier nicht bewertbar. Bitte ohne Begrenzung (oder > 60) wiederholen.", fg, avg)
        end
        return nil
    end
    return string.format("WoW lief vermutlich im Hintergrund (Ø %.0f Bilder/s%s) – Ruckeln und Tempo hier nicht bewertbar. Bitte mit WoW im Vordergrund wiederholen.",
        avg, bk and bk > 0 and string.format(", Hintergrund-Grenze %d", bk) or "")
end

-- S7 Takt: Suchen je Minute (Ø und höchste in 60 s), Abstand (Ø/max), Anteil Warten auf den Server, Vergleich mit H2
function SPT:Takt(o, tEnd)
    local ts = {}
    for _, s in ipairs(o.all or {}) do ts[#ts + 1] = s.t end
    local n = #ts
    local dur = math.max(1, (tEnd or Now()) - (o.t0 or 0))
    local mx, j = 0, 1
    for i = 1, n do
        while ts[i] - ts[j] >= 60 do j = j + 1 end
        if i - j + 1 > mx then mx = i - j + 1 end
    end
    local gs, gMax = 0, 0
    for i = 2, n do
        local g = ts[i] - ts[i - 1]
        gs = gs + g
        if g > gMax then gMax = g end
    end
    local limit = A.QUERY_LIMIT or 90
    local ans, thr = (o.waitAns or 0) / dur * 100, (o.waitThr or 0) / dur * 100
    local allMax = o.qMax
    local ok = n >= 2 and mx <= limit and (allMax == nil or allMax <= limit)
    return { n = n, dur = dur, avg = n / (dur / 60), max = mx, gapAvg = n > 1 and gs / (n - 1) or nil, gapMax = gMax,
        ansPct = ans, thrPct = thr, waitPct = ans + thr, limit = limit, allMax = allMax, ok = ok }
end

-- S8 reihum: je Ziel Suchen und längste Lücke (Spielzeit ohne Pausen, inkl. Beginn und Ende der Beobachtung)
-- E/T729 (0.65.325, Ingametest 17.11.: 5 Ziele je 31×, längste Lücke 10,1/10,8/11,5/12,2/13,0 s – genau 0,7 s Abstand in der
-- Reihenfolge der Ziele, Takt-Abstand max 0,8 s): die "Lücke" war die Zeit vom Beginn der Beobachtung bis zur ERSTEN Suche (~10 s),
-- nicht das Reihum. Jetzt zählen die Lücken ab der ersten Suche; die Zeit bis zur ersten Suche steht getrennt im Bericht (start).
function SPT:Reihum(o)
    local per, keys = {}, o.keyList or {}
    local first = o.all and o.all[1]
    local a0 = first and first.a or 0
    -- SN-EIGEN (Auftrag 19.11. 10:55, Ingametest 10:00 "Lücke 8,2 s", Warten auf Server 92 %): je Lücke den Anteil "Warten auf den
    -- Server" (Antwort offen bzw. Drossel/Freigabe, aktive Zeit) abziehen; bewertet wird die eigene Lücke, ausgewiesen beides
    local w0 = first and first.w or 0
    for _, k in ipairs(keys) do per[k] = { n = 0, last = a0, lastW = w0, maxGap = 0, maxOwn = 0, maxSrv = 0 } end
    local gs, gn, prevA = 0, 0, nil
    -- TB188-9 (S8 mit EINEM Ziel rot, 1,2 s gegen 1,1 s): Lücken über eine Pause (Vollscan, AH-Klick …) hinweg zählen nicht –
    -- weder als Lücke eines Ziels noch im Ø Abstand. Mit nur einem Ziel gibt es kein "reihum": nur "gesucht" zählt.
    local pc = 0                                       -- Zahl der Pausen bisher
    for _, s in ipairs(o.all or {}) do
        if s.ap then pc = pc + 1 end
        local p = per[s.k]
        if p then
            p.n = p.n + 1
            if (p.pc or 0) == pc then
                local gap, srv = s.a - p.last, math.max(0, (s.w or 0) - (p.lastW or 0))
                if gap > p.maxGap then p.maxGap = gap end
                local own = math.max(0, gap - srv)
                if own > p.maxOwn then p.maxOwn, p.maxSrv = own, srv end
            end
            p.last, p.lastW, p.pc = s.a, s.w or 0, pc
        end
        if prevA and not s.ap then gs, gn = gs + (s.a - prevA), gn + 1 end
        prevA = s.a
    end
    local aEnd = o.actEnd or o.act or 0
    local worst, ok, parts = 0, true, {}
    local wEnd = o.srvAEnd or o.srvA
    local srvAny = false
    for _, k in ipairs(keys) do
        local p = per[k]
        if aEnd - p.last > p.maxGap then p.maxGap = aEnd - p.last end
        local srvE = wEnd and math.max(0, wEnd - (p.lastW or 0)) or 0
        local ownE = math.max(0, aEnd - p.last - srvE)
        if ownE > p.maxOwn then p.maxOwn, p.maxSrv = ownE, srvE end
        if not wEnd then p.maxOwn = p.maxGap end                    -- ohne Server-Messung (alte Daten/Nachbildung): wie bisher
        if p.maxOwn > worst then worst = p.maxOwn end
        if p.n == 0 then ok = false end
        if p.maxSrv > 0.05 then srvAny = true end
        parts[#parts + 1] = string.format("%s %d×/%.1f s%s", tostring(k), p.n, p.maxGap,
            (wEnd and p.maxGap - p.maxOwn > 0.05) and string.format(" (eigen %.1f, Server %.1f)", p.maxOwn, p.maxGap - p.maxOwn) or "")
    end
    local gAvg = gn > 0 and gs / gn or nil
    local limit = gAvg and #keys * gAvg * self.ROUND_FACTOR or nil
    if #keys == 1 then
        limit = nil                                   -- ein Ziel: reihum nicht anwendbar (Lücken = Takt, S7)
    elseif not limit or worst > limit then ok = false end
    return { nKeys = #keys, per = per, gapAvg = gAvg, limit = limit, worst = worst, ok = ok and #keys > 0, text = table.concat(parts, " · "),
        start = first and first.a or nil, srvAny = srvAny }
end

-- S11 Pausen: jede beendete Pause muss in RESUME_MAX s zur nächsten Suche führen; Drossel -> langsamer, dann wieder schnell
function SPT:Pauses(o, tEnd)
    local n, bad, worst, list = 0, 0, 0, {}
    for _, p in ipairs(o.pauses or {}) do
        if p.t1 then
            local r = p.resume
            if not r and tEnd - p.t1 > self.RESUME_MAX then r = tEnd - p.t1 end
            if r then
                n = n + 1
                if not p.resume or r > self.RESUME_MAX then bad = bad + 1 end
                if r > worst then worst = r end
                local why = ""
                if p.block then                    -- TB188-1: Ursachen der Wartezeit (meiste zuerst)
                    local b = {}
                    for k, v in pairs(p.block) do b[#b + 1] = { k = k, v = v } end
                    table.sort(b, function(x, y) return x.v > y.v end)
                    local t = {}
                    for i = 1, math.min(3, #b) do t[#t + 1] = string.format("%s %.1f s", b[i].k, b[i].v) end
                    if #t > 0 then why = " (hielt auf: " .. table.concat(t, ", ") .. ")" end
                end
                list[#list + 1] = string.format("%s %.0f s -> %s %.1f s%s", p.why, p.t1 - p.t0, p.resume and "weiter nach" or "KEINE Suche seit", r, why)
            end
        end
    end
    local throttled = (o.err1 or 0) > (o.err0 or 0)
    local fastAgain = (o.gap1 or 0) <= math.max(o.gap0 or 0, A.GAP_MIN_FIXED or 0.2) * 1.5 + 0.05
    return { n = n, bad = bad, worst = worst, list = list, throttled = throttled, fastAgain = fastAgain,
        ok = bad == 0 and (not throttled or fastAgain) }
end

-- S12 verpasst
function SPT:Missed(o)
    local m = o.missed or {}
    local s, mn = 0, nil
    for _, v in ipairs(m) do s = s + v; if not mn or v < mn then mn = v end end
    return { n = #m, avg = #m > 0 and s / #m or nil, min = mn }
end

-- S13 Ruckeln
-- SN-EIGEN (Auftrag 19.11. 10:55, E-Regel 18.11. 19:30; Nutzer 10:49: "ich lasse wow immer im hintergrund laufen"): eigene
-- Rechenzeit von AHSentinel je Bild (A.frameOwn: Aufgaben, gemessene Ereignisse wie Kern/ITEM_SEARCH_RESULTS_UPDATED, Skripte,
-- Zeitgeber) - Massstab für T617/T734 statt der Bildlänge, die bei 30 Bildern/s (Hintergrund) immer ~33 ms ist.
SPT.OWN_KEYS = { "job", "ev", "upd", "item", "read", "gc" }
-- AHS-I6 (BELEGT, Ingametest 0.65.385/0.65.387 "max 108.3 / 105.3 ms, Aufgaben 0, Ereignisse 0, Skripte 108/105"): fo.item ist eine
-- ANZAHL (Vollscan.lua: Antworten GET_ITEM_INFO_RECEIVED/ITEM_DATA_LOAD_RESULT, +1 je Antwort), keine Zeit - sie wurde als ms zur
-- eigenen Arbeit gezählt (105 Antworten in einem Bild + 0,3 ms Skripte = "105.3 ms"). fo.read ist ein Teil von fo.job (Lesezeit in
-- Aufgaben, Vollscan "davon Lesen") - doppelt gezählt. Eigene Arbeit = Aufgaben + Ereignisse + Skripte/Zeitgeber; Item-Antworten als Anzahl.
SPT.OWN_MS = { job = true, ev = true, upd = true }
function SPT:OwnFrame(o)
    local fo = A.frameOwn
    if not fo then o.foLast = nil; return nil end
    -- AHS-I6: langsamster eigener Skript-Aufruf dieses Bilds (Stelle beim Einhüllen gemerkt, debugstack) - Bild-Werte zurück
    o.fSlowAt, o.fSlowMs, o.fSlowGC, o.fSlowN = nil, nil, nil, nil
    if A.OwnFrameReset then o.fSlowAt, o.fSlowMs, o.fSlowGC, o.fSlowN = A.OwnFrameReset(fo) end
    local cur = {}
    for _, k in ipairs(self.OWN_KEYS) do cur[k] = tonumber(fo[k]) or 0 end
    local last = o.foLast
    o.foLast = cur
    if not last then return nil end
    local d, tot = {}, 0
    for _, k in ipairs(self.OWN_KEYS) do
        local x = cur[k] - last[k]
        if x < 0 then x = cur[k] end                         -- zurückgesetzt (z. B. Vollscan-Messung): seitdem
        d[k] = x
        if self.OWN_MS[k] then tot = tot + x end
    end
    -- SN-GC: Zeit eigener Aufrufe, in denen eine Speicherbereinigung lief, ist nicht eigene Rechenzeit (eigener Zähler, Auskunft)
    local gc = math.min(d.gc or 0, tot)
    if gc > 0 then
        o.gcFrames = (o.gcFrames or 0) + 1
        if gc > (o.gcMax or 0) then o.gcMax = gc end
    end
    tot = tot - gc
    self:NoteOwn(o, tot, d)
    return tot
end
function SPT:NoteOwn(o, ms, d)
    o.ownN = (o.ownN or 0) + 1
    if ms > (o.ownMax or 0) then
        o.ownMax = ms
        local ls = A.lastSlowEvent
        local sl = A.frameOwn and A.frameOwn.slow
        o.ownMaxAt = (sl and GetTime() - (sl.t or 0) < 0.2) and string.format("%s %.0f ms%s", tostring(sl.at), sl.ms, sl.gc and " mit Bereinigung" or "") or nil
        -- AHS-I6: Stelle aus DIESEM Bild (vorher nur der grösste Aufruf der ganzen Messung - im Spiel fehlte sie darum)
        if o.fSlowAt then
            o.ownMaxAt = string.format("%s %.0f ms%s, %d eigene Aufrufe im Bild", tostring(o.fSlowAt), o.fSlowMs or 0, o.fSlowGC and " mit Bereinigung" or "", o.fSlowN or 0)
        end
        o.ownMaxWhat = d and string.format("Aufgaben %.0f, Ereignisse %.0f, Skripte %.0f%s%s%s", d.job or 0, d.ev or 0, d.upd or 0,
            (d.item or 0) > 0 and string.format(", Item-Antworten %d (Anzahl)", d.item) or "",
            (d.gc or 0) > 0 and string.format(", ohne %.0f ms Bereinigung", d.gc) or "",
            (ls and ls.t and GetTime() - ls.t < 0.2) and (" · " .. tostring(ls.at) .. "/" .. tostring(ls.ev)) or "") or nil
    end
    if ms > self.FRAME_MAX then
        o.ownOver33 = (o.ownOver33 or 0) + 1
        -- AHS-I6: Stelle des langsamsten Skripts je Bild über 33 ms zählen (welche Stelle wiederholt sich?)
        if o.fSlowAt then
            o.slowWhere = o.slowWhere or {}
            local e = o.slowWhere[o.fSlowAt] or { n = 0, max = 0 }
            e.n = e.n + 1
            if (o.fSlowMs or 0) > e.max then e.max = o.fSlowMs end
            o.slowWhere[o.fSlowAt] = e
        end
    end
    if ms > 50 then o.ownOver50 = (o.ownOver50 or 0) + 1 end
end
function SPT:SlowWhereText(o)
    if not o.slowWhere then return "" end
    local rows = {}
    for at, e in pairs(o.slowWhere) do rows[#rows + 1] = { at = at, n = e.n, max = e.max } end
    table.sort(rows, function(a, b) if a.n ~= b.n then return a.n > b.n end return a.at < b.at end)
    local parts = {}
    for i = 1, math.min(3, #rows) do parts[#parts + 1] = string.format("%s %d× bis %.0f ms", rows[i].at, rows[i].n, rows[i].max) end
    return " [Stellen: " .. table.concat(parts, ", ") .. (#rows > 3 and string.format(", +%d weitere", #rows - 3) or "") .. "]"
end
function SPT:OwnText(o)
    if not (o.ownN and o.ownN > 0) then return nil end
    -- AHS-I6: die Stellen stehen direkt hinter der Zahl der Bilder über 33 ms (sonst in der Prüfzeile abgeschnitten); der ganze
    -- Text kommt zusätzlich als Feld sniper_eigen in den Testbericht (Felder werden aufgeteilt, nicht gekürzt)
    local txt = string.format("eigene Arbeit je Bild max %.1f ms%s · Bilder mit eigener Arbeit > %d ms: %d%s%s", o.ownMax or 0,
        o.ownMaxWhat and (" (" .. o.ownMaxWhat .. (o.ownMaxAt and (", langsamstes Skript " .. o.ownMaxAt) or "") .. ")") or "", self.FRAME_MAX, o.ownOver33 or 0,
        self:SlowWhereText(o),
        (o.gcFrames or 0) > 0 and string.format(" · %d Bilder mit Speicherbereinigung in eigenem Aufruf (bis %.0f ms; eigener Anteil darin nicht trennbar, nicht bewertet)", o.gcFrames, o.gcMax or 0) or "")
    self.lastOwnFull = txt
    return txt
end

function SPT:Smooth(o)
    local avg = (o.fpsN or 0) > 0 and o.fpsSum / o.fpsN or nil
    return { fpsAvg = avg, fpsMin = o.fpsMin, frameMax = o.frameMax or 0, over = o.over33 or 0, ok = (o.frameMax or 0) <= self.FRAME_MAX }
end

-- S10/S4: Gold vorher − nachher = gebuchter Preis
function SPT:GoldCheck(m0, m1, spent, other)
    return m0 ~= nil and m1 ~= nil and spent ~= nil and (m0 - m1 - (other or 0)) == spent
end

-- ERGEBNIS OBEN: 3–4 einfache Sätze, danach S1–S13 mit OK/FEHLER
function SPT:TopLines(rows, last, s4)
    last, s4 = last or self.last, s4 or self.s4
    local st = {}
    for _, r in ipairs(rows or {}) do
        local id = tostring(r.group or ""):match("(T%d+)$")
        if id then st[id] = r.status end
    end
    local fails, parts = {}, {}
    for _, m in ipairs(self.S_IDS) do
        local s = st[m[2]]
        local txt = (s == "PASS" and "OK") or (s == "FAIL" and "FEHLER") or (s == "SKIP" and "SKIP") or (s and tostring(s)) or "-"
        if s == "FAIL" then fails[#fails + 1] = m[1] end
        parts[#parts + 1] = m[1] .. " " .. txt
    end
    local out = { "ERGEBNIS Sniper-Abnahme:" }
    local tail = #fails == 0 and "Alles OK." or ("FEHLER bei: " .. table.concat(fails, ", ") .. ".")
    if last and last.bg then tail = tail .. " " .. last.bg end            -- SN-TR-1 (a)
    if not last then
        out[#out + 1] = "Beobachtung nicht gelaufen (Auktionshaus nicht offen oder kein Ziel mit Preis). " .. tail
    else
        local tk, rr = last.takt, last.reihum
        out[#out + 1] = string.format("Der Sniper prüfte %d %s reihum, Ø %.0f Suchen/Min. (Server erlaubt %d).", rr.nKeys, rr.nKeys == 1 and "Ziel" or "Ziele", tk.avg, tk.limit)
        out[#out + 1] = string.format("Jedes Ziel spätestens alle %.0f s.", rr.worst or 0)
        local bought = s4 and s4.bought or 0
        local hits = (last.hitsN or 0) + (s4 and s4.hit and 1 or 0)
        out[#out + 1] = string.format("%d Treffer, %d gekauft, %d verpasst.", hits, bought, last.missedN or 0)
        local sm = last.smooth
        local ruck = (sm.frameMax or 0) <= self.FRAME_MAX and "Kein Ruckeln." or string.format("Ruckeln: längster Frame %.0f ms (Ziel ≤ %d ms).", sm.frameMax, self.FRAME_MAX)
        out[#out + 1] = ruck .. " " .. tail
    end
    out[#out + 1] = "Einzeln: " .. table.concat(parts, " · ")
    -- TB188-2: Abnahme-Zeilen IMMER - aus der laufenden Spiel-Sitzung, sonst aus der letzten gespeicherten echten Sitzung
    local gl, bt = self:BuyLines()
    local saved = A.db and A.db.sniper and A.db.sniper.lastBuySummary
    local when = saved and saved.t and date("%d.%m. %H:%M", saved.t) or nil
    if #gl > 0 then
        out[#out + 1] = "Geld je Ziel (seit dem ersten Kauf, diese Spiel-Sitzung): " .. table.concat(gl, " | ")
    elseif saved and saved.gold and #saved.gold > 0 then
        out[#out + 1] = string.format("Geld je Ziel: keine Käufe in dieser Spiel-Sitzung · letzte echte Sitzung (%s): %s", when, table.concat(saved.gold, " | "))
    else
        out[#out + 1] = "Geld je Ziel: keine Käufe in dieser Spiel-Sitzung und keine gespeicherte Sitzung mit Käufen"
    end
    if bt then
        out[#out + 1] = bt
    elseif saved and saved.stat then
        out[#out + 1] = string.format("Einzelkäufe: keine in dieser Spiel-Sitzung · letzte echte Sitzung (%s): %s", when, saved.stat)
    else
        out[#out + 1] = "Einzelkäufe: keine gesendet in dieser Spiel-Sitzung und keine gespeicherte Sitzung"
    end
    -- P190-1: Suchen sofort neu gesendet (TB188-8) je Grund, dazu wie oft die Grenze griff
    local rt = A.Sniper and A.Sniper.retry or {}
    out[#out + 1] = string.format("Suchen neu gesendet (diese Spiel-Sitzung): vom Server verworfen %d · ohne Antwort %d (Wartezeit %.1f s) · durch andere Suche ersetzt %d · Grenze %d in %d s erreicht %d",
        rt.dropped or 0, rt.timeout or 0, A.Sniper and A.Sniper.SearchTimeout and A.Sniper:SearchTimeout() or 0, rt.replaced or 0, A.Sniper and A.Sniper.RETRY_MAX or 0, A.Sniper and A.Sniper.RETRY_WINDOW or 0, rt.limited or 0)
    return out
end
-- SN-B10 / TB188-2: je Ziel Zähler, Summe der Preise, Gold-Abgang seit dem ersten Kauf, Differenz; dazu die Quote der
-- Einzelkäufe (SN-B11 a). Zurück: Liste der Ziel-Zeilen, Text der Einzelkäufe (oder nil)
function SPT:BuyLines()
    local Sn = A.Sniper
    local money = Sn and Sn.Money and Sn:Money()
    local gl = {}
    for key, g in pairs(Sn and Sn.goldStart or {}) do
        local t = Sn:GetTarget(key)
        if t and money and money ~= math.huge and g.money then
            local drop = g.money - money
            local spent = (t.spent or 0) - (g.spent or 0)
            gl[#gl + 1] = string.format("%s: %d gekauft, Preise %s, Gold-Abgang %s, Differenz %s", A:GetItemName(t.itemID) or key, t.bought or 0,
                A:FormatMoney(spent), A:FormatMoney(math.max(0, drop)), A:FormatMoney(math.abs(drop - spent)))
        end
    end
    table.sort(gl)
    local bt = Sn and Sn.BuyStatText and Sn:BuyStatText()
    return gl, bt
end
-- TB188-2: beim Ende einer echten Sniper-Sitzung (Ausschalten) die Abnahme-Zeilen speichern - für den nächsten Testbericht
function SPT:SaveBuySummary()
    if A.InTestRoutine and A:InTestRoutine() then return end
    local db = A.db and A.db.sniper
    if not db then return end
    local gl, bt = self:BuyLines()
    if #gl == 0 and not bt then return end
    db.lastBuySummary = { t = time(), gold = gl, stat = bt }
end

-- Ziele der Beobachtung: offene eigene Ziele des Spielers; ohne eigene Ziele ein Testziel aus SPT.ITEMS
function SPT:PlayerTargets()
    local Sn, db = A.Sniper, A.db.sniper
    local list = {}
    for key, t in pairs(db.targets or {}) do
        if type(t) == "table" and not t.watch and not Sn:IsDone(t) and not Sn:ItemPaused(t.itemID) then list[#list + 1] = key end
    end
    table.sort(list)
    return list
end

-- Test-Ware: erste aus SPT.ITEMS mit aktuellem Preis, für die der Spieler KEIN Ziel hat (auch kein erfülltes/pausiertes) -
-- sein Ziel wird so nie überschrieben. Höchstpreis = günstigstes Angebot (Treffer erwartet).
function SPT:TestItem()
    local targets = A.db.sniper.targets or {}
    for _, x in ipairs(self.ITEMS) do
        local cur = A:GetCurrent(x)
        if cur and cur > 0 and targets["i:" .. x] == nil then return x, cur end
    end
    return nil
end

-- s6 = true: S6-Phase (Supervisor 16.11. 21:58, Vorschlag A) - nur das Test-Ziel, eigene Ziele befristet pausiert
function SPT:StartObserve(TR, s6)
    local Sn = A.Sniper
    local db = A.db.sniper
    local keys = s6 and {} or self:PlayerTargets()
    local paused = s6 and #self:PlayerTargets() or 0
    local created, key, prevT
    if #keys == 0 then
        local id, p = self:TestItem()
        if not id then return false, "keine Test-Ware ohne eigenes Ziel mit aktuellem Preis (erst scannen)" end
        key = "i:" .. id
        prevT = db.targets[key]
        local ok = Sn:SetTarget(tostring(id), p, 1000, p * 1000)
        if not ok then return false, "Testziel ließ sich nicht anlegen" end
        keys, created = { key }, true
    else
        key = keys[1]
    end
    if s6 then
        -- eigene Ziele nur pausieren (Filter im Arbeitsspeicher, Zeitlimit); Chatzeile davor und danach
        Sn:OnlyTargets({ [key] = true }, self.S6_OBS + self.S6_GRACE,
            paused > 0 and string.format(L["Sniper-Test: deine Ziele sind wieder aktiv (%d)."], paused) or nil)
        if paused > 0 then A:Print(string.format(L["Sniper-Test: deine Ziele %d s pausiert (Reaktionszeit nur mit dem Test-Ziel)."], self.S6_OBS)) end
        if C_Timer and C_Timer.After then C_Timer.After(self.S6_OBS + self.S6_GRACE + 1, function() Sn:OnlyActive() end) end
    end
    local tByKey, before = {}, {}
    for _, k in ipairs(keys) do
        local t = db.targets[k]
        if t and not t.key then t.key = k end
        tByKey[k] = t
        before[k] = { t and t.bought or 0, t and t.spent or 0 }
    end
    local t = tByKey[key]
    local prevArmed = db.armed
    db.armed = true
    Sn.lastSearch = -100
    local pace = A.pace or {}
    SPT.lastOwnFull = nil                                    -- AHS-I6: Feld sniper_eigen nur aus dieser Beobachtung
    local o = { id = t and t.itemID, t = t, t0 = Now(), seen = {}, vanished = 0, vanishedIDs = {}, shownN = 0, searches = {}, searchDur = {},
        fpsSum = 0, fpsN = 0, fpsMin = nil, frameMax = 0, queueMax = 0, frames = 0, key = key, prevT = prevT, prevArmed = prevArmed,
        created = created, keyList = keys, tByKey = tByKey, before = before, all = {}, pauses = {}, act = 0, waitAns = 0, waitThr = 0,
        qMax = A:QueryLimit() and 0 or nil, err0 = pace.errors or 0, gap0 = A:QueryGap(), gapMax = A:QueryGap(), sendsMax = 0, sends0 = SPT:Sends(),
        s6 = s6 and true or nil, paused = paused }
    self.obs = o
    -- SN-EIGEN: eigene Rechenzeit je Bild zählen (wie in der Vollscan-Messung); nur anlegen, wenn niemand sonst misst
    if not A.frameOwn and debugprofilestop then
        A.frameOwn = { job = 0, ev = 0, evN = 0, item = 0, upd = 0, read = 0, kb = 0, kbLost = 0 }
        o.foMine = A.frameOwn
    end
    local prevBy, lastKey = {}, nil
    o.onChange = function()
        local r = Sn.result
        local now = Now()
        local rt = r and tByKey[r.key]
        if rt and r ~= o.lastR then
            o.lastR = r
            o.checked = (o.checked or 0) + #(r.listings or {})
            for _, l in ipairs(r.listings or {}) do
                if l.price and l.price > (rt.maxPrice or 0) then o.tooDear = (o.tooDear or 0) + 1
                elseif l.own then o.ownN = (o.ownN or 0) + 1
                elseif l.bait then o.baitN = (o.baitN or 0) + 1
                elseif l.gone then o.goneN = (o.goneN or 0) + 1 end
            end
            local planned = SPT:NoteResult(o, rt, r, now)
            if planned and Sn:HitMarked(r.key) then o.hit9.gold = o.hit9.gold + 1 end
        end
        -- S1 je Ziel: verschwindet ein sichtbarer Treffer, obwohl die neueste Antwort ihn noch enthält -> Fehler
        -- SN-B7: bewusst geleert (neu suchen, Ziel geändert, Treffer weg) ist kein "ohne Grund verschwunden"
        if r == nil and Sn.clearedAt and Now() - Sn.clearedAt < 0.5 and lastKey then prevBy[lastKey] = {} end
        if r == nil and lastKey and next(prevBy[lastKey] or {}) ~= nil then
            -- Liste geleert, bevor neue Ergebnisse da sind (SN1951c) - zählt als ohne Grund verschwunden
            for aid in pairs(prevBy[lastKey]) do o.vanished = o.vanished + 1; o.vanishedIDs[#o.vanishedIDs + 1] = tostring(aid) .. "(geleert)" end
            prevBy[lastKey] = {}
        end
        if not rt then return end
        local vis = SPT:Visible(Sn, rt)
        for aid in pairs(vis) do
            local sk = r.key .. ":" .. tostring(aid)
            if not o.seen[sk] then o.seen[sk] = now; o.shownN = o.shownN + 1 end
        end
        for aid in pairs(prevBy[r.key] or {}) do
            if not vis[aid] then
                for _, l in ipairs(r.listings or {}) do
                    local k = l.auctionID or (tostring(l.price) .. "x" .. tostring(l.qty))
                    if k == aid and not l.gone and not (l.used and l.used > 0) then
                        o.vanished = o.vanished + 1
                        o.vanishedIDs[#o.vanishedIDs + 1] = tostring(aid)
                    end
                end
            end
        end
        prevBy[r.key], lastKey = vis, r.key
    end
    A:On("SNIPER_CHANGED", function() if SPT.obs == o and o.onChange then pcall(o.onChange) end end)
    local lastStart
    o.frame = o.frame or CreateFrame("Frame")
    -- S11: eigene Suche des Spielers im Auktionshaus (Ergebnis kommt, ohne dass ein Modul von uns sucht) = Pause "AH-Klick"
    for _, ev in ipairs({ "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED", "COMMODITY_SEARCH_RESULTS_UPDATED", "ITEM_SEARCH_RESULTS_UPDATED" }) do
        pcall(o.frame.RegisterEvent, o.frame, ev)
    end
    o.frame:SetScript("OnEvent", function()
        if SPT.obs ~= o then return end
        local now = Now()
        if Sn.search or now - (o.lastSearchEnd or o.t0) < 2 or now - (o.lastClick or -100) < 1 then return end
        if A:IsScanning(true) or (A.Watcher and A.Watcher:IsBusy()) or (A.Seller and A.Seller:IsBusy()) or (A.Buy and A.Buy:Blocks()) then return end
        o.lastClick = now
        o.pauses[#o.pauses + 1] = { why = "AH-Klick", t0 = now, t1 = now }
    end)
    o.frame:SetScript("OnUpdate", function(_, elapsed)
        if SPT.obs ~= o then o.frame:SetScript("OnUpdate", nil); return end
        local now = Now()
        local dt = now - (o.lastT or now)
        o.lastT = now
        local ms = (elapsed or 0) * 1000
        local gf = _G.GetFramerate
        SPT:NoteFrame(o, ms, gf and gf() or nil)
        if o.frames <= 5 then o.foLast = nil end                 -- SN-EIGEN: die ersten 5 Bilder nur vormerken (wie NoteFrame)
        SPT:OwnFrame(o)
        local GSS = _G.GoldSentinelSync
        local q = GSS and GSS.queue and #GSS.queue or 0
        -- SN-TEST2-1: je langem Bild (> 33 ms, nach den ersten 5) festhalten, wer es verursacht hat
        if o.frames > 5 and ms > SPT.FRAME_MAX then SPT:NoteLongFrame(o, ms, GetTime(), q) end
        o.lastQ = q
        if q > o.queueMax then
            o.queueMax = q
            if A.Sync and A.Sync.QueueMix then local okQ, mix = pcall(A.Sync.QueueMix, A.Sync); if okQ then o.queueMixMax = mix end end
        end
        local ls = A.longStep
        if ls and ms > o.frameMax - 0.001 and ms > 16 then o.slowAt = string.format("%.0f ms bis %s (%s)", ls.ms, tostring(ls.at), tostring(ls.job)) end
        -- S11: Pausen (Markt-Scan, Vollscan, Einkauf, Preisprüfung) und Spielzeit ohne Pausen
        local why = Sn.waitReason
        local pause = why and SPT.PAUSE_WHY[why] and why or nil
        if pause and not o.curPause then
            o.curPause = { why = pause, t0 = now }
            o.pauses[#o.pauses + 1] = o.curPause
        elseif not pause and o.curPause then
            o.curPause.t1, o.curPause = now, nil
            o.pauseFlag = true
        end
        if not pause then
            o.act = o.act + dt
            -- SN-EIGEN (T729): Warten auf den Server in aktiver Zeit (Antwort offen bzw. Freigabe/Drossel)
            if Sn.search or not A:CanQueryNow("sniper") then o.srvA = (o.srvA or 0) + dt end
        end
        -- TB188-1: während einer offenen "AH-Klick"-Pause messen, was den Sniper aufhält (Sekunden je Ursache)
        local lp = o.pauses[#o.pauses]
        if lp and lp.why == "AH-Klick" and not lp.resume and Sn.BlockReason then
            local okB, br = pcall(Sn.BlockReason, Sn)
            br = okB and br or "?"
            lp.block = lp.block or {}
            lp.block[br] = (lp.block[br] or 0) + dt
        end
        -- S7: Warten auf die Antwort bzw. auf die Freigabe des Servers (Drossel, H2)
        if Sn.search then o.waitAns = o.waitAns + dt
        elseif not A:CanQueryNow("sniper") then o.waitThr = o.waitThr + dt end
        if o.qMax then local nq = A:QueriesLastMinute(); if nq > o.qMax then o.qMax = nq end end
        local g = A:QueryGap()
        if g > o.gapMax then o.gapMax = g end
        -- S10: in der Beobachtung wird nichts gesendet (Kaufen gesperrt)
        local sn = SPT:Sends() - o.sends0
        if sn > o.sendsMax then o.sendsMax = sn end
        local s = Sn.search
        if s and s ~= lastStart then
            lastStart = s
            SPT:NoteSearch(o, s.targetKey, now)
            s.__sptStart = now
        end
        if lastStart and not Sn.search and lastStart.__sptStart and not lastStart.__sptDone then
            lastStart.__sptDone = true
            o.searchDur[#o.searchDur + 1] = now - lastStart.__sptStart
            o.lastSearchEnd = now
        end
    end)
    return true
end

function SPT:StopObserve()
    local o = self.obs
    if o and o.frame then
        o.frame:SetScript("OnUpdate", nil)
        o.frame:SetScript("OnEvent", nil)
        pcall(o.frame.UnregisterAllEvents, o.frame)
    end
    self.obs = nil
    if o then
        local db, Sn = A.db.sniper, A.Sniper
        o.tEnd, o.actEnd = Now(), o.act
        o.srvAEnd = o.srvA or 0
        if o.foMine and A.frameOwn == o.foMine then A.frameOwn = nil end          -- SN-EIGEN: eigene Zählung wieder aus
        if o.curPause then o.curPause.t1, o.curPause = o.tEnd, nil end
        local pace = A.pace or {}
        o.err1, o.gap1 = pace.errors or 0, A:QueryGap()
        -- S10: Zähler der Ziele unverändert (in der Beobachtung wird nichts gekauft)
        o.changed = {}
        for k, b in pairs(o.before or {}) do
            local t = db.targets[k]
            if t and ((t.bought or 0) ~= b[1] or (t.spent or 0) ~= b[2]) then o.changed[#o.changed + 1] = k end
        end
        -- Testziel und Modus selbst zurück (Teil "sniper" erlaubt Änderungen unter db.sniper, die echte Suchen machen)
        if o.created then db.targets[o.key] = o.prevT end
        db.armed = o.prevArmed
        if o.s6 then Sn:EndOnly("fertig") end                 -- S6 A: eigene Ziele wieder aktiv (auch bei Abbruch über TR:Finish)
        if Sn.result and o.tByKey and o.tByKey[Sn.result.key] then Sn.result = nil end
        if Sn.search and o.tByKey and o.tByKey[Sn.search.targetKey] then Sn.search = nil end
        A:Fire("SNIPER_CHANGED")
    end
    return o
end

SPT.S6_NAME = "SN1951-S6 Reaktionszeit: neues Angebot spätestens nach < 5 s sichtbar (Abstand der Suchen + Suchdauer, nur das Test-Ziel)"
function SPT:S6Check(o, Chk)
    Chk("T618", "J", self.S6_NAME, function()
        if o.ahClosed then return "SKIP", string.format("Auktionshaus während der S6-Phase geschlossen (nach %.0f s) – eigene Ziele wieder aktiv", o.ahClosed) end
        local bg = SPT:BackgroundText(o)
        if bg then return "SKIP", bg end
        local r, g, d = SPT:Reaction(o)
        SPT.lastReaction = r                                   -- PS: für "/ahs testroutine tempo"
        local ph = o.s6 and string.format(", eigene Phase %d s, %d eigene Ziele pausiert", SPT.S6_OBS, o.paused or 0) or ", ohne eigene Ziele"
        if not r then return false, string.format("zu wenige Suchen (%d%s)", #o.searches, ph), "< 5 s" end
        return r < 5, string.format("spätestens nach %.1f s (Abstand %.1f s + Suche %.1f s, %d Suchen%s)", r, g, d or 0, #o.searches, ph), "< 5 s"
    end)
end

-- Reaktionszeit (S6): ein neues Angebot ist spätestens nach "Abstand zweier Suchen + Suchdauer" sichtbar
function SPT:Reaction(o)
    local gaps = {}
    for i = 2, #o.searches do gaps[#gaps + 1] = o.searches[i] - o.searches[i - 1] end
    local function avg(t) local s = 0; for _, v in ipairs(t) do s = s + v end; return #t > 0 and s / #t or nil end
    local g, d = avg(gaps), avg(o.searchDur)
    if not g then return nil, g, d end
    return g + (d or 0), g, d
end

SPT.OBS_IDS = { { "T613", "S1 Treffer bleiben stehen" }, { "T617", "S5 Ruckeln und Sync-Warteschlange" }, { "T618", "S6 Reaktionszeit" },
    { "T728", "S7 Takt" }, { "T729", "S8 reihum" }, { "T730", "S9 Treffer richtig" }, { "T731", "S10 Geld-Sicherheit" },
    { "T732", "S11 Pausen" }, { "T733", "S12 verpasst" }, { "T734", "S13 Ruckeln" } }

-- S7–S13 nach der Beobachtung (echtes Spiel)
function SPT:ObsChecks(o, Chk, Skp)
    local tk, rr, pz, ms, sm = self:Takt(o, o.tEnd), self:Reihum(o), self:Pauses(o, o.tEnd), self:Missed(o), self:Smooth(o)
    local h9 = o.hit9 or { n = 0, checked = 0, bad = 0, gold = 0 }
    local bg = self:BackgroundText(o)
    self.last = { takt = tk, reihum = rr, hitsN = o.hitNew or 0, missedN = ms.n, smooth = sm, bg = bg }
    Chk("T728", "J", "SN-TEST2-S7 Takt: Suchen/Min. (Ø, höchste in 60 s) ≤ Server-Grenze 90, Abstand, Anteil Warten auf den Server", function()
        return tk.ok, string.format("%d Suchen in %.0f s · Ø %.1f/Min. · höchste %d in 60 s%s · Abstand Ø %s / max %.1f s · Warten auf Server %.0f %% (Antwort %.0f %%, Freigabe/Drossel %.0f %%)",
            tk.n, tk.dur, tk.avg, tk.max, tk.allMax and string.format(" (alle Module zusammen %d)", tk.allMax) or "",
            tk.gapAvg and string.format("%.1f", tk.gapAvg) or "?", tk.gapMax, tk.waitPct, tk.ansPct, tk.thrPct), string.format("höchstens %d/Min.", tk.limit)
    end)
    Chk("T729", "J", "SN-TEST2-S8 reihum: jedes Ziel gesucht, längste eigene Lücke ≤ Ziele × Ø Abstand × 1,5 (ohne Pausen und ohne Warten auf den Server)", function()
        -- SN-EIGEN (Auftrag 19.11. 10:55): auch im Hintergrund bewertet - Lücken aus "Warten auf den Server" (Antwort/Drossel) zählen
        -- nicht als eigene Lücke, stehen aber im Ergebnis; ohne Server-Messung (o.srvAEnd fehlt) wie bisher mit SKIP im Hintergrund
        if bg and not o.srvAEnd then return "SKIP", bg end
        -- E/T729 (0.65.325): Pausen je Grund (Sekunden) dazu - so zeigt der Bericht, ob eine Lücke in einer Pause lag
        local pw, pl = {}, {}
        for _, p in ipairs(o.pauses or {}) do pw[p.why] = (pw[p.why] or 0) + math.max(0, (p.t1 or o.tEnd or p.t0) - p.t0) end
        for k, v in pairs(pw) do pl[#pl + 1] = string.format("%s %.0f s", tostring(k), v) end
        table.sort(pl)
        return rr.ok, string.format("%d Ziele · %s · Ø Abstand %s s · Grenze %s s · erste Suche nach %s s · Pausen: %s", rr.nKeys, rr.text,
            rr.gapAvg and string.format("%.1f", rr.gapAvg) or "?", rr.limit and string.format("%.1f", rr.limit) or "?",
            rr.start and string.format("%.1f", rr.start) or "-", #pl > 0 and table.concat(pl, ", ") or "keine"), "jedes Ziel ≥ 1× · Lücke ≤ Grenze (ab der ersten Suche)"
    end)
    Chk("T730", "J", "SN-TEST2-S9 Treffer richtig: geplanter Kauf nur bei Stückpreis ≤ Max, Treffer golden markiert", function()
        if h9.n == 0 then
            return "SKIP", string.format("kein Treffer in der Beobachtung (%d Angebote geprüft, über Max %d) – Nachbildung T737", o.checked or 0, o.tooDear or 0)
        end
        return h9.bad == 0 and h9.gold == h9.n, string.format("%d Antworten mit Treffer · %d geplante Angebote geprüft · über Max %d%s · golden markiert %d/%d",
            h9.n, h9.checked, h9.bad, h9.badTxt and (" (" .. h9.badTxt .. ")") or "", h9.gold, h9.n), "über Max 0 · golden = Treffer"
    end)
    Chk("T731", "J", "SN-TEST2-S10 Geld-Sicherheit: Beobachtung sendet nichts, Zähler unverändert; S4 Gold vorher − nachher = gebuchter Preis", function()
        local s4 = self.s4 or {}
        local g = s4.gold
        local goldTxt, goldOK = "S4 ohne Kauf", true
        if g then
            goldOK = self:GoldCheck(g.m0, g.m1, g.spent, g.other)
            goldTxt = string.format("S4 Gold %s -> %s (−%s) · gebucht %s · andere gezählte Käufe im Fenster %s", tostring(g.m0), tostring(g.m1),
                tostring(g.m0 and g.m1 and g.m0 - g.m1), tostring(g.spent), tostring(g.other or 0))
        end
        local ok = o.sendsMax == 0 and #o.changed == 0 and goldOK
        return ok, string.format("gesendet %d · Zähler geändert %d%s · %s", o.sendsMax, #o.changed, #o.changed > 0 and (" (" .. table.concat(o.changed, ",") .. ")") or "", goldTxt),
            "gesendet 0 · geändert 0 · Gold = gebucht"
    end)
    Chk("T732", "J", "SN-TEST2-S11 Pausen: nach Markt-Scan/Vollscan/Einkauf/AH-Klick sucht der Sniper von selbst weiter (≤ 5 s); Drossel -> langsamer, dann wieder schnell", function()
        if bg then return "SKIP", bg end
        local drossel = pz.throttled and string.format("Drossel: Abstand %.2f -> höchstens %.2f -> %.2f s (%s)", o.gap0 or 0, o.gapMax or 0, o.gap1 or 0,
            pz.fastAgain and "wieder schnell" or "NICHT wieder schnell") or "keine Drossel"
        if pz.n == 0 and not pz.throttled then
            return "SKIP", "keine Pause und keine Drossel während der Beobachtung (Nachbildung T739)"
        end
        return pz.ok, string.format("%d Pausen%s · längste bis zur nächsten Suche %.1f s · %s", pz.n, #pz.list > 0 and (" (" .. table.concat(pz.list, "; ", 1, math.min(4, #pz.list)) .. ")") or "",
            pz.worst, drossel), "weiter nach ≤ 5 s · wieder schnell"
    end)
    Chk("T733", "J", "SN-TEST2-S12 verpasst: Treffer, die vor dem Kauf weg waren, Zeit vom Erkennen bis weg; Ø Reaktion des Spielers", function()
        local st = A.Sniper:Stats()
        local react = (st.reactN or 0) > 0 and string.format("%.1f s (heute, %d Käufe)", st.reactSum / st.reactN, st.reactN) or "-"
        local s4 = self.s4 or {}
        local s4r = s4.react and string.format(" · S4 Treffer bis Kauf %.1f s", s4.react) or ""
        -- SN-B2 (c): Zeit vom Treffer bis zur Bestätigung und je Abschnitt (seit dem Laden)
        local acc = A.Sniper.phaseAcc
        local ph = {}
        for _, k in ipairs({ "Treffer>bestätigt (erster Versuch)", "Treffer>bestätigt (nachgefasst)", "Treffer>Reserv.", "Reserv.>bereit", "bereit>bestätigt" }) do
            if acc and acc.cnt[k] then ph[#ph + 1] = string.format("%s Ø %d ms (%d)", k, math.floor(acc.sums[k] / acc.cnt[k] + 0.5), acc.cnt[k]) end
        end
        s4r = s4r .. (#ph > 0 and (" · " .. table.concat(ph, ", ")) or "")
        -- SN-B4 (3): Rasten je Kauf und nicht gekauft je Grund
        if acc and acc.pressN then s4r = s4r .. string.format(" · Rasten je Kauf Ø %.1f, höchstens %d (Ziel ≤ 2)", acc.presses / acc.pressN, acc.pressMax or 0) end
        if acc and acc.missBy then
            local mb = {}
            for _, k in ipairs({ "andere schneller", "keine Raste", "Preis gestiegen", "eigener Ablauf" }) do if acc.missBy[k] then mb[#mb + 1] = k .. " " .. acc.missBy[k] end end
            if #mb > 0 then s4r = s4r .. " · nicht gekauft: " .. table.concat(mb, ", ") end
        end
        if (o.hitNew or 0) == 0 then return "SKIP", "kein Treffer in der Beobachtung · Ø Reaktion " .. react .. s4r end
        return true, string.format("%d Treffer · %d verpasst (Kaufen in der Beobachtung gesperrt)%s · Ø Reaktion %s%s", o.hitNew, ms.n,
            ms.n > 0 and string.format(" · weg nach Ø %.1f s, schnellstens %.1f s", ms.avg, ms.min) or "", react, s4r), "gemessen"
    end)
    Chk("T734", "J", "SN-TEST2-S13 Ruckeln: eigene Arbeit von AHSentinel je Bild ≤ 33 ms über die ganze Beobachtung (Bilder/s und längster Frame zur Auskunft)", function()
        -- SN-EIGEN (Auftrag 19.11. 10:55): bewertet wird die eigene Rechenzeit je Bild, auch im Hintergrund; ohne Messung wie bisher
        local own = SPT:OwnText(o)
        local info = string.format("Ø %s / min %s Bilder/s · längster Frame %.0f ms · Frames > %d ms: %d%s", sm.fpsAvg and string.format("%.0f", sm.fpsAvg) or "?",
            sm.fpsMin and string.format("%.0f", sm.fpsMin) or "?", sm.frameMax, self.FRAME_MAX, sm.over, (o.slowAt and (" · längster Schritt " .. o.slowAt) or "") .. SPT:LongText(o))
        if own then
            return (o.ownMax or 0) <= self.FRAME_MAX, own .. (bg and " · Hintergrund (Bildlänge nur Auskunft)" or "") .. " · " .. info, "eigene Arbeit ≤ 33 ms je Bild"
        end
        if bg then return "SKIP", bg end
        return sm.ok, info, "kein Frame > 33 ms"
    end)
end

-- ------------------------------------------------------------
-- Nachbildung S7–S13 und Ergebnis oben (läuft in der normalen Testroutine und im Teil "sniper"; ändert nichts Echtes)
-- ------------------------------------------------------------
function SPT:SimChecks(Chk)
    local Sn = A.Sniper
    Chk("T735", "M", "T-SN-TEST2-S7 Takt (Nachbildung): 90 Suchen in 2 Min. -> Ø 45/Min., höchste 60 in 60 s, OK; 100 in 1 Min. -> FEHLER", function()
        local o = { t0 = 0, all = {}, waitAns = 30, waitThr = 12 }
        for i = 0, 59 do o.all[#o.all + 1] = { k = "a", t = i, a = i } end
        for i = 0, 29 do o.all[#o.all + 1] = { k = "a", t = 60 + i * 2, a = 60 + i * 2 } end
        local a = SPT:Takt(o, 120)
        local o2 = { t0 = 0, all = {} }
        for i = 0, 99 do o2.all[#o2.all + 1] = { k = "a", t = i * 0.5, a = i * 0.5 } end
        local b = SPT:Takt(o2, 60)
        local got = string.format("Ø %.0f · höchste %d · Abstand %.1f/%.1f · Warten %.0f %% · %s | höchste %d · %s", a.avg, a.max, a.gapAvg, a.gapMax, a.waitPct, tostring(a.ok), b.max, tostring(b.ok))
        local want = "Ø 45 · höchste 60 · Abstand 1.3/2.0 · Warten 35 % · true | höchste 100 · false"
        return got == want, got, want
    end)
    Chk("T736", "M", "T-SN-TEST2-S8 reihum (Nachbildung): 3 Ziele abwechselnd -> Lücke 3 s ≤ 4,5 s OK; ein Ziel nur einmal -> FEHLER", function()
        local keys = { "a", "b", "c" }
        local o = { keyList = keys, all = {}, actEnd = 30 }
        for i = 0, 29 do o.all[#o.all + 1] = { k = keys[i % 3 + 1], t = i, a = i } end
        local r = SPT:Reihum(o)
        local o2 = { keyList = keys, all = {}, actEnd = 30 }
        for i = 0, 29 do
            local k = keys[i % 3 + 1]
            if k ~= "c" or i == 2 then o2.all[#o2.all + 1] = { k = k, t = i, a = i } end
        end
        local r2 = SPT:Reihum(o2)
        local got = string.format("%d/%d/%d · Lücke %.0f · Grenze %.1f · %s | c-Lücke %.0f · %s", r.per.a.n, r.per.b.n, r.per.c.n, r.worst, r.limit, tostring(r.ok), r2.per.c.maxGap, tostring(r2.ok))
        local want = "10/10/10 · Lücke 3 · Grenze 4.5 · true | c-Lücke 28 · false"
        return got == want, got, want
    end)
    -- E/T729 (0.65.325): Fall aus dem Ingametest 17.11. nachgebildet - erste Suche nach 10,1 s, dann 5 Ziele reihum alle 0,7 s
    Chk("T898", "M", "E/T729 S8 (Nachbildung Ingametest 17.11.): erste Suche erst nach 10 s, dann 5 Ziele reihum alle 0,7 s -> längste Lücke 4,2 s (5 Takte bzw. Ende) ≤ Grenze 5,2 s OK, Zeit bis zur ersten Suche getrennt; ein Ziel 10 s ausgelassen -> FEHLER", function()
        local keys = { "i:7048", "i:14580", "i:2589", "i:4251", "i:6611" }
        local o = { keyList = keys, all = {}, actEnd = 120 }
        for i = 0, 155 do
            local a = 10.1 + i * 0.7
            if a <= 120 then o.all[#o.all + 1] = { k = keys[i % 5 + 1], t = a, a = a } end
        end
        local r = SPT:Reihum(o)
        local o2 = { keyList = keys, all = {}, actEnd = 120 }
        for i = 0, 155 do
            local a = 10.1 + i * 0.7
            local k = keys[i % 5 + 1]
            if a <= 120 and not (k == "i:2589" and a > 50 and a < 62) then o2.all[#o2.all + 1] = { k = k, t = a, a = a } end
        end
        local r2 = SPT:Reihum(o2)
        local got = string.format("Lücke %.1f · Grenze %.1f · erste Suche %.1f · %s | ausgelassen: Lücke %.1f · %s", r.worst, r.limit or -1, r.start or -1, tostring(r.ok), r2.worst, tostring(r2.ok))
        local want = "Lücke 4.2 · Grenze 5.2 · erste Suche 10.1 · true | ausgelassen: Lücke 14.0 · false"
        return got == want, got, want
    end)
    Chk("T770", "M", "TB188-9 S8 (Nachbildung): ein Ziel -> reihum nicht anwendbar (OK, wenn gesucht); Lücke über eine Pause hinweg zählt nicht", function()
        local o1 = { keyList = { "a" }, all = { { k = "a", a = 0 }, { k = "a", a = 1 }, { k = "a", a = 2.2 }, { k = "a", a = 3 } }, actEnd = 3 }
        local r1 = SPT:Reihum(o1)
        local o2 = { keyList = { "a", "b" }, all = {}, actEnd = 12 }
        for i = 0, 5 do o2.all[#o2.all + 1] = { k = (i % 2 == 0) and "a" or "b", a = i } end
        o2.all[#o2.all + 1] = { k = "a", a = 11, ap = true }                 -- erste Suche nach einer Pause
        o2.all[#o2.all + 1] = { k = "b", a = 12 }
        local r2 = SPT:Reihum(o2)
        local got = string.format("1 Ziel: %s (Grenze %s) | 2 Ziele mit Pause: %s · Lücke a %.0f", tostring(r1.ok), tostring(r1.limit), tostring(r2.ok), r2.per.a.maxGap)
        local want = "1 Ziel: true (Grenze nil) | 2 Ziele mit Pause: true · Lücke a 2"
        return got == want, got, want
    end)
    Chk("T737", "M", "T-SN-TEST2-S9 Treffer richtig (Nachbildung): nur Stückpreis ≤ Max geplant, \"22\" = 22c, Ausrüstung 1 Stück, Standard 5g/1000, golden markiert", function()
        local key, ID = "i:990197301", 990197301
        local t = { key = key, kind = "item", itemID = ID, maxPrice = 100, qty = 10, budget = 10000, bought = 0, spent = 0 }
        local sv = { getT = Sn.GetTarget, des = Sn.DEStale, buys = Sn.itemBuys, fl = Sn.inFlight, res = Sn.result, hp = Sn.hasPlan, ic = A.IsCommodityItem }
        local res = { pcall(function()
            Sn.GetTarget = function(self, k) if k == key then return t end return sv.getT(self, k) end
            Sn.DEStale = function() return false end
            Sn.itemBuys, Sn.inFlight = {}, nil
            local r = { key = key, itemID = ID, commodity = false, time = Now(), listings = {
                { auctionID = 990197311, price = 110, qty = 1, buyout = 110, pass = true }, { auctionID = 990197312, price = 90, qty = 1, buyout = 90, pass = true } } }
            Sn.result = r
            local plan = Sn:PlanNext()
            Sn.hasPlan = plan ~= nil
            local o = {}
            SPT:NoteResult(o, t, r, 0)
            local marked = Sn:HitMarked(key)
            local o2 = {}
            SPT:NoteResult(o2, t, { key = key, listings = { { auctionID = 3, price = 120, qty = 1, buyout = 120, pass = true, planned = 1 } } }, 0)
            A.IsCommodityItem = function() return false end
            local qEquip = Sn:DefaultQty(ID, "", 100, 50000)
            A.IsCommodityItem = function() return true end
            local qWare = Sn:DefaultQty(ID, "", 100, 50000)
            local dq, db = Sn:NewTargetDefaults(nil, nil, nil)
            return string.format("Plan %s %s · geprüft %d, über Max %d · golden %s · falsch geplant erkannt %d · 22 -> %s · Ausrüstung %d, Ware %d · Standard %d/%d",
                tostring(plan and plan.listing and plan.listing.auctionID), tostring(plan and plan.total), o.hit9.checked, o.hit9.bad, tostring(marked), o2.hit9.bad,
                tostring(A:ParseMoney("22", "copper")), qEquip, qWare, dq, db)
        end) }
        Sn.GetTarget, Sn.DEStale, Sn.itemBuys, Sn.inFlight, Sn.result, Sn.hasPlan, A.IsCommodityItem = sv.getT, sv.des, sv.buys, sv.fl, sv.res, sv.hp, sv.ic
        if not res[1] then error(res[2], 0) end
        local want = "Plan 990197312 90 · geprüft 1, über Max 0 · golden true · falsch geplant erkannt 1 · 22 -> 22 · Ausrüstung 1, Ware 500 · Standard 1000/50000"
        return res[2] == want, res[2], want
    end)
    Chk("T738", "M", "T-SN-TEST2-S10 Geld-Sicherheit (Nachbildung): Menge und Budget stoppen genau, kein Kauf ohne Raste/Taste, nie über Max, Gold-Abgleich", function()
        if (GetMoney and GetMoney() or 0) < 1000 then return "SKIP", "weniger als 10s Gold – Planung durch das Gold begrenzt" end
        local key, ID = "i:990197302", 990197302
        local t = { key = key, kind = "item", itemID = ID, maxPrice = 12, qty = 7, budget = 1000, bought = 0, spent = 0 }
        local sv = { getT = Sn.GetTarget, des = Sn.DEStale, buys = Sn.itemBuys, fl = Sn.inFlight, res = Sn.result, trig = Sn.inTrigger }
        local res = { pcall(function()
            Sn.GetTarget = function(self, k) if k == key then return t end return sv.getT(self, k) end
            Sn.DEStale = function() return false end
            Sn.itemBuys, Sn.inFlight, Sn.inTrigger = {}, nil, nil
            local function R() return { key = key, itemID = ID, commodity = true, time = Now(), listings = {
                { price = 10, qty = 10, pass = true }, { price = 12, qty = 10, pass = true }, { price = 13, qty = 50, pass = true } } } end
            Sn.result = R()
            local p1 = Sn:PlanNext()
            t.qty, t.budget = 100, 65
            Sn.result = R()
            local p2 = Sn:PlanNext()
            local okBuy = Sn:Buy({ kind = "commodity", key = key, itemID = ID, qty = 1, total = 10 })
            return string.format("Menge %d/%d · Budget %d/%d · ohne Taste %s · über Max %s, = Max %s · Gold %s/%s",
                p1 and p1.qty or -1, p1 and p1.total or -1, p2 and p2.qty or -1, p2 and p2.total or -1, tostring(okBuy),
                tostring((Sn:PriceOK({ maxPrice = 100 }, 2, 202))), tostring((Sn:PriceOK({ maxPrice = 100 }, 1, 100))),
                tostring(SPT:GoldCheck(1000, 995, 5)), tostring(SPT:GoldCheck(1000, 990, 5)))
        end) }
        Sn.GetTarget, Sn.DEStale, Sn.itemBuys, Sn.inFlight, Sn.result, Sn.inTrigger = sv.getT, sv.des, sv.buys, sv.fl, sv.res, sv.trig
        if not res[1] then error(res[2], 0) end
        local want = "Menge 7/70 · Budget 6/60 · ohne Taste false · über Max false, = Max true · Gold true/false"
        return res[2] == want, res[2], want
    end)
    Chk("T739", "M", "T-SN-TEST2-S11 Pausen (Nachbildung): Markt-Scan und Vollscan pausieren, danach sucht der Sniper von selbst weiter; Drossel -> langsamer, dann wieder schnell", function()
        local pace = A.pace
        local sv = { sc = A.IsScanning, fs = Sn.FullScanRunning, cn = Sn.CheckNext, ia = Sn.IsArmed, hw = Sn.HitWaiting, mr = Sn.MaybeRemind, mf = Sn.MeterFlush,
            hot = Sn.HasOwnTargets, s = Sn.search, p = Sn.pending, ls = Sn.lastSearch, wr = Sn.waitReason, ws = Sn.waitSince, nsa = Sn.nextSearchAt, bn = Sn.blockNoted,
            bb = A.Buy and A.Buy.Blocks, sh = A.Seller and A.Seller.HasWork, wb = A.Watcher and A.Watcher.IsBusy,
            gap = pace and pace.gap, err = pace and pace.errors, ans = pace and pace.answers,
            errT = pace and pace.errT, gb = pace and pace.gapBefore, why = pace and pace.errWhy, okS = pace and pace.okStreak }
        local scanning, full, calls = false, false, 0
        local res = { pcall(function()
            A.IsScanning = function() return scanning end
            Sn.FullScanRunning = function() return full end
            Sn.CheckNext = function() calls = calls + 1; Sn.lastSearch = -100; return true end
            Sn.IsArmed, Sn.HitWaiting, Sn.MaybeRemind, Sn.MeterFlush, Sn.HasOwnTargets = function() return true end, function() return false end, function() end, function() end, function() return true end
            if A.Buy then A.Buy.Blocks = function() return false end end
            if A.Seller then A.Seller.HasWork = function() return false end end
            if A.Watcher then A.Watcher.IsBusy = function() return false end end
            Sn.search, Sn.pending, Sn.lastSearch = nil, nil, -100
            local steps = {}
            scanning = true; Sn:Tick(); steps[#steps + 1] = tostring(Sn.waitReason) .. " " .. calls
            scanning = false; Sn:Tick(); steps[#steps + 1] = "weiter " .. calls
            full = true; Sn:Tick(); steps[#steps + 1] = tostring(Sn.waitReason) .. " " .. calls
            full = false; Sn:Tick(); steps[#steps + 1] = "weiter " .. calls
            local o = { pauses = { { why = "scan", t0 = 0, t1 = 10, resume = 0.4 }, { why = "AH-Klick", t0 = 20, t1 = 20, resume = 1.2 } } }
            local pa = SPT:Pauses(o, 60)
            o.pauses[#o.pauses + 1] = { why = "vollscan", t0 = 30, t1 = 40 }
            local pb = SPT:Pauses(o, 60)
            local drossel = "-"
            if pace then
                pace.gap = nil
                local g0 = A:QueryGap()
                A:QueryError()
                local g1 = A:QueryGap()
                for _ = 1, 40 do A:QueryAnswered() end
                local g2 = A:QueryGap()
                drossel = string.format("langsamer %s, wieder schnell %s", tostring(g1 > g0), tostring(g2 <= math.max(g0, A.GAP_MIN_FIXED or 0.2) * 1.5 + 0.05))
            end
            return table.concat(steps, " · ") .. string.format(" · Pausen ok %s, ohne Suche erkannt %d · %s", tostring(pa.ok), pb.bad, drossel)
        end) }
        A.IsScanning, Sn.FullScanRunning, Sn.CheckNext, Sn.IsArmed, Sn.HitWaiting, Sn.MaybeRemind, Sn.MeterFlush, Sn.HasOwnTargets = sv.sc, sv.fs, sv.cn, sv.ia, sv.hw, sv.mr, sv.mf, sv.hot
        Sn.search, Sn.pending, Sn.lastSearch, Sn.waitReason, Sn.waitSince, Sn.nextSearchAt, Sn.blockNoted = sv.s, sv.p, sv.ls, sv.wr, sv.ws, sv.nsa, sv.bn
        if A.Buy then A.Buy.Blocks = sv.bb end
        if A.Seller then A.Seller.HasWork = sv.sh end
        if A.Watcher then A.Watcher.IsBusy = sv.wb end
        if pace then pace.gap, pace.errors, pace.answers, pace.errT, pace.gapBefore, pace.errWhy, pace.okStreak = sv.gap, sv.err, sv.ans, sv.errT, sv.gb, sv.why, sv.okS end
        if not res[1] then error(res[2], 0) end
        local want = "scan 0 · weiter 1 · vollscan 1 · weiter 2 · Pausen ok true, ohne Suche erkannt 1 · langsamer true, wieder schnell true"
        return res[2] == want, res[2], want
    end)
    Chk("T740", "M", "T-SN-TEST2-S12 verpasst (Nachbildung): Treffer verschwindet nach 2 s bzw. 5 s -> 2 verpasst, Ø 3,5 s, schnellstens 2 s", function()
        local t = { key = "i:990197303", maxPrice = 100 }
        local o = {}
        SPT:NoteResult(o, t, { key = t.key, listings = { { auctionID = 1, price = 90, qty = 1 }, { auctionID = 2, price = 95, qty = 1 }, { auctionID = 3, price = 120, qty = 1 } } }, 0)
        SPT:NoteResult(o, t, { key = t.key, listings = { { auctionID = 2, price = 95, qty = 1 }, { auctionID = 3, price = 120, qty = 1 } } }, 2)
        SPT:NoteResult(o, t, { key = t.key, listings = { { auctionID = 3, price = 120, qty = 1 } } }, 5)
        local m = SPT:Missed(o)
        local got = string.format("Treffer %d · verpasst %d · Ø %.1f s · schnellstens %.1f s", o.hitNew, m.n, m.avg or -1, m.min or -1)
        local want = "Treffer 2 · verpasst 2 · Ø 3.5 s · schnellstens 2.0 s"
        return got == want, got, want
    end)
    Chk("T741", "M", "T-SN-TEST2-S13 Ruckeln (Nachbildung): ein Frame 40 ms -> FEHLER, alle ≤ 20 ms -> OK (erste 5 Bilder zählen nicht); Ursache je langem Bild (SN-TEST2-1)", function()
        local a, b = {}, {}
        for _ = 1, 10 do SPT:NoteFrame(a, 16, 60); SPT:NoteFrame(b, 20, 50) end
        SPT:NoteFrame(a, 40, 25)
        local sa, sb = SPT:Smooth(a), SPT:Smooth(b)
        -- SN-TEST2-1: Ursache je langem Bild
        local c1 = select(2, SPT:FrameCause(10, 0, 0, { t = 9.95, d = 40, job = "x" }, nil))
        local c2 = select(2, SPT:FrameCause(10, 0, 0, nil, { t = 9.99, at = "Sniper", ev = "E", ms = 30 }))
        local c3 = select(2, SPT:FrameCause(10, 2, 9, nil, nil))
        local c4 = select(2, SPT:FrameCause(10, 0, 0, { t = 5, d = 40 }, { t = 5, at = "Sniper" }))
        local got = string.format("%.0f ms, über 33: %d, %s | %.0f ms, %s | %s/%s/%s/%s", sa.frameMax, sa.over, tostring(sa.ok), sb.frameMax, tostring(sb.ok), c1, c2, c3, c4)
        local want = "40 ms, über 33: 1, false | 20 ms, true | ahs/sniper/sync/fremd"
        return got == want, got, want
    end)
    Chk("T745", "M", "SN-B1/SN-B2: Bremse nach Fehler nach 10 s weg, 5 Kauf-Fehler bremsen nicht, echte Drossel nach 2 Antworten wieder voll, Grund in Worten, 3 Ziele -2 gelöscht -> Rotation 1; alle Stück ≤ Max (30, nicht 70 – Nutzer 00:38 volle Menge), Preis gestiegen -> kleinere Menge ohne neue Suche", function()
        local pace = A.pace
        local db = A.db.sniper
        local sv = { ok = pace.okStreak, gap = pace.gap, err = pace.errors, errT = pace.errT, gb = pace.gapBefore, why = pace.errWhy, last = pace.last, lt = A.lastTradeT,
            targets = db.targets, extra = Sn.extra, credit = Sn.credit, armed = db.armed, getT = Sn.GetTarget, des = Sn.DEStale, buys = Sn.itemBuys,
            fl = Sn.inFlight, res = Sn.result, cap = Sn.retryCap, pr = A.Print, paused = Sn.ItemPaused }
        local res = { pcall(function()
            local out = {}
            -- SN-B1 Bremse (T745-Fix: Server-Bereitschaft/Budget im echten Spiel nicht mittesten)
            sv.qr, sv.qb = A.QueryReady, A.QueryBudgetFree
            A.QueryReady, A.QueryBudgetFree = function() return true end, function() return true end
            pace.gap, pace.errT, pace.gapBefore = nil, nil, nil
            local g0 = A:QueryGap()
            A:QueryError("Test")
            local g1 = A:QueryGap()
            local txt = A:QueryWaitText("sniper")
            A.QueryReady, A.QueryBudgetFree = sv.qr, sv.qb
            pace.errT = GetTime() - 11
            local g2 = A:QueryGap()
            out[#out + 1] = string.format("Bremse %s, Text %s, nach 10 s %s", tostring(g1 > g0), tostring(txt:find("Test", 1, true) ~= nil), tostring(g2 == g0))
            -- 5 Kauf-Fehler hintereinander: AH-Fehlermeldungen bremsen nie
            pace.gap, pace.errT, pace.gapBefore = nil, nil, nil
            local gA = A:QueryGap()
            local braked = 0
            for _ = 1, 5 do pace.last = GetTime(); A:NoteTrade(); if A:AHErrorIsThrottle() then braked = braked + 1; A:QueryError("x") end end
            out[#out + 1] = string.format("5 Kauf-Fehler: gebremst %d, Abstand gleich %s", braked, tostring(A:QueryGap() == gA))
            -- echte Drossel: langsamer, danach wieder voll (mit Drossel-Schnittstelle nach 2 Antworten, sonst nach 10 s)
            A:QueryError("verworfen")
            local gD = A:QueryGap()
            A:QueryAnswered(); A:QueryAnswered()
            if not A:HasThrottleAPI() then pace.errT = GetTime() - 11 end
            local gE = A:QueryGap()
            out[#out + 1] = string.format("Drossel langsamer %s (≤ %s s), wieder voll %s", tostring(gD > gA),
                tostring(gD <= (A:HasThrottleAPI() and A.GAP_MAX_THROTTLED or A.GAP_MAX)), tostring(gE <= gA))
            -- Rotation
            A.Print = function() end
            db.targets, Sn.extra, Sn.credit, db.armed = {}, {}, {}, true
            Sn.ItemPaused = function() return false end
            for i, id in ipairs({ 990197401, 990197402, 990197403 }) do
                db.targets["i:" .. id] = { kind = "item", itemID = id, key = "i:" .. id, maxPrice = 18, qty = 100, budget = 10000, bought = 0, spent = 0, added = i }
            end
            local n3 = #Sn:GetActiveTargets()
            Sn:RemoveTarget("i:990197401"); Sn:RemoveTarget("i:990197402")
            local act = Sn:GetActiveTargets()
            local picks = {}
            for _ = 1, 3 do picks[#picks + 1] = Sn:PickTarget(act).key end
            out[#out + 1] = string.format("Ziele %d -> %d, Runden %s", n3, #act, table.concat(picks, ","))
            -- SN-B2
            local key, ID = "i:990197404", 990197404
            local t = { key = key, kind = "item", itemID = ID, maxPrice = 18, qty = 1000, budget = 100000, bought = 0, spent = 0 }
            Sn.GetTarget = function(self, k) if k == key then return t end return sv.getT(self, k) end
            Sn.DEStale = function() return false end
            Sn.itemBuys, Sn.inFlight, Sn.retryCap = {}, nil, nil
            local function R() return { key = key, itemID = ID, commodity = true, time = Now(), listings = {
                { price = 18, qty = 10, pass = true }, { price = 18, qty = 20, pass = true }, { price = 25, qty = 40, pass = true } } } end
            Sn.result = R()
            local p1 = Sn:PlanNext()
            local q = Sn:SetRetryCap({ key = key, qty = p1 and p1.qty or 0 }, 18, 100000, 18)
            Sn.result = R()
            local p2 = Sn:PlanNext()
            local qNo = Sn:SetRetryCap({ key = key, qty = 10 }, 19, 100000, 18)
            out[#out + 1] = string.format("fragt %s an, gestiegen -> %s (Plan %s), erste Stufe über Max -> %s",
                tostring(p1 and p1.qty), tostring(q), tostring(p2 and p2.qty), tostring(qNo))
            return table.concat(out, " · ")
        end) }
        pace.gap, pace.errors, pace.errT, pace.gapBefore, pace.errWhy, pace.last, A.lastTradeT, pace.okStreak = sv.gap, sv.err, sv.errT, sv.gb, sv.why, sv.last, sv.lt, sv.ok
        if sv.qr then A.QueryReady = sv.qr end
        if sv.qb then A.QueryBudgetFree = sv.qb end
        db.targets, Sn.extra, Sn.credit, db.armed, Sn.GetTarget, Sn.DEStale, Sn.itemBuys = sv.targets, sv.extra, sv.credit, sv.armed, sv.getT, sv.des, sv.buys
        Sn.inFlight, Sn.result, Sn.retryCap, A.Print, Sn.ItemPaused = sv.fl, sv.res, sv.cap, sv.pr, sv.paused
        if not res[1] then error(res[2], 0) end
        local want = "Bremse true, Text true, nach 10 s true · 5 Kauf-Fehler: gebremst 0, Abstand gleich true · Drossel langsamer true (≤ true s), wieder voll true · Ziele 3 -> 1, Runden i:990197403,i:990197403,i:990197403 · fragt 30 an, gestiegen -> 15 (Plan 15), erste Stufe über Max -> nil"
        return res[2] == want, res[2], want
    end)
    Chk("T747", "M", "SN-B4/SN-B3: Raste während ein Kauf unterwegs ist -> übergangen (keine neue Preisprüfung); Kauf gescheitert -> nächste Raste kleinere Menge; Rasten je Kauf und Grund gezählt; Zutat -> neutraler Text", function()
        local Ke = A.Ketten
        local sv = { ah = A.IsAHOpen, fl = Sn.inFlight, pend = Sn.pending, lp = Sn.lastPress, pn = Sn.PlanNext, getT = Sn.GetTarget, cap = Sn.retryCap,
            pr = A.Print, ep = Sn.episode, acc = Sn.phaseAcc, res = Sn.result, tr = Ke and Ke.testRecipes, rc = Sn.reagentCache, rf = Sn.ReportFail }
        local res = { pcall(function()
            local out = {}
            A.Print = function() end
            A.IsAHOpen = function() return true end
            local planned = 0
            Sn.PlanNext = function() planned = planned + 1; return nil end
            Sn.pending, Sn.lastPress = nil, -100
            Sn.inFlight = { key = "i:990197501", itemID = 990197501, qty = 10, cost = 150, time = Now() }
            local ok, msg, soft = Sn:OnTrigger("sniper")
            out[#out + 1] = string.format("Raste im Kauf: %s/%s, Planung %d", tostring(ok), tostring(soft), planned)
            Sn.PlanNext = sv.pn
            local t = { key = "i:990197501", itemID = 990197501, maxPrice = 18, qty = 1000, budget = 100000, bought = 0, spent = 0 }
            Sn.GetTarget = function(self, k) if k == t.key then return t end return sv.getT(self, k) end
            Sn.ReportFail = function() end
            Sn.result, Sn.retryCap = nil, nil
            Sn:OnEvent("COMMODITY_PURCHASE_FAILED")
            out[#out + 1] = string.format("gescheitert -> nächste Raste %s Stück, Kauf frei %s", tostring(Sn.retryCap and Sn.retryCap.qty), tostring(Sn.inFlight == nil))
            Sn.phaseAcc = nil
            Sn.episode = { key = t.key, tHit = Now(), presses = 2 }
            Sn:MeterEnd("gekauft")
            Sn.episode = { key = t.key, tHit = Now(), presses = 1 }
            Sn:MeterEnd("weg")
            Sn.episode = { key = t.key, tHit = Now() }                       -- TB189-4: ohne Raste -> "keine Raste"
            Sn:MeterEnd("weg")
            Sn.episode = { key = t.key, tHit = Now() }
            Sn:MeterEnd("gestiegen")
            local acc = Sn.phaseAcc or {}
            out[#out + 1] = string.format("Rasten %s/%s, andere schneller %s, keine Raste %s, Preis gestiegen %s", tostring(acc.pressN), tostring(acc.pressMax),
                tostring(acc.missBy and acc.missBy["andere schneller"]), tostring(acc.missBy and acc.missBy["keine Raste"]), tostring(acc.missBy and acc.missBy["Preis gestiegen"]))
            if Ke then
                Ke.testRecipes = { [990197599] = { productID = 990197599, made = 1, reagents = { { 2589, 2 } } } }
                Sn.reagentCache = nil
                out[#out + 1] = string.format("Zutat %s/%s", tostring(Sn:IsReagent(2589)), tostring(Sn:IsReagent(2592)))
            end
            return table.concat(out, " · ")
        end) }
        A.IsAHOpen, Sn.inFlight, Sn.pending, Sn.lastPress, Sn.PlanNext, Sn.GetTarget, Sn.retryCap = sv.ah, sv.fl, sv.pend, sv.lp, sv.pn, sv.getT, sv.cap
        A.Print, Sn.episode, Sn.phaseAcc, Sn.result, Sn.reagentCache, Sn.ReportFail = sv.pr, sv.ep, sv.acc, sv.res, sv.rc, sv.rf
        if Ke then Ke.testRecipes = sv.tr end
        if not res[1] then error(res[2], 0) end
        local want = "Raste im Kauf: false/true, Planung 0 · gescheitert -> nächste Raste 5 Stück, Kauf frei true · Rasten 1/2, andere schneller 1, keine Raste 1, Preis gestiegen 1 · Zutat true/false"
        return res[2] == want, res[2], want
    end)
    Chk("T749", "M", "SN-H1/SN-B9: hängende Sperre (Sniper-Suche, Preisprüfung, angeklicktes Item, Wächter) -> Status nennt das Modul, nach ≤ 10 s gelöst und der Sniper sucht weiter", function()
        local Se, W = A.Seller, A.Watcher
        local sv = { ah = A.IsAHOpen, cq = A.CanQueryNow, sc = A.IsScanning, fs = Sn.FullScanRunning, s = Sn.search, p = Sn.pending, h = Sn.hold, hr = Sn.holdReleased,
            ses = Se and Se.search, seu = Se and Se.urgent, seq = Se and Se.queue, sey = Se and Se.yielded, wr = W and W.round, wt = Sn.WantsTurn, bb = A.Buy and A.Buy.Blocks }
        local res = { pcall(function()
            A.IsAHOpen, A.CanQueryNow, A.IsScanning = function() return true end, function() return true end, function() return false end
            Sn.FullScanRunning = function() return false end
            if A.Buy then A.Buy.Blocks = function() return false end end
            Sn.pending, Sn.hold = nil, nil
            local out = {}
            local function run(label, setup, check)
                setup()
                local _, msg = Sn:CanSearch()
                local named = tostring(msg):find(label, 1, true) ~= nil
                Sn.hold.since = Now() - 11
                Sn:CanSearch()
                out[#out + 1] = string.format("%s genannt %s gelöst %s", label, tostring(named), tostring(check()))
            end
            if Se then Se.urgent = nil end
            if W then W.round = nil end
            run(L["Sniper-Suche"], function() Sn.search = { targetKey = "x" } end, function() return Sn.search == nil end)
            if Se then
                run(L["Preisprüfung"], function() Se.search = { itemID = 1, started = Now() } end, function() return Se.search == nil end)
                run(L["angeklicktes Item"], function() Se.urgent = 7 end, function() return Se.urgent == nil end)
            end
            if W then run(L["Wächter"], function() W.round = { started = Now() } end, function() return W.round == nil end) end
            return table.concat(out, " · ")
        end) }
        A.IsAHOpen, A.CanQueryNow, A.IsScanning, Sn.FullScanRunning, Sn.search, Sn.pending, Sn.hold, Sn.holdReleased = sv.ah, sv.cq, sv.sc, sv.fs, sv.s, sv.p, sv.h, sv.hr
        if Se then Se.search, Se.urgent, Se.queue, Se.yielded = sv.ses, sv.seu, sv.seq, sv.sey end
        if Se and sv.sls ~= nil then Se.lastSearch = sv.sls end
        if sv.nls ~= nil then Sn.lastSearch = sv.nls end
        if W then W.round = sv.wr end
        Sn.WantsTurn = sv.wt
        if A.Buy then A.Buy.Blocks = sv.bb end
        if not res[1] then error(res[2], 0) end
        local want = string.format("%s genannt true gelöst true · %s genannt true gelöst true · %s genannt true gelöst true · %s genannt true gelöst true",
            L["Sniper-Suche"], L["Preisprüfung"], L["angeklicktes Item"], L["Wächter"])
        return res[2] == want, res[2], want
    end)
    Chk("T742", "M", "T-SN-TEST2 Ergebnis oben: 3–4 einfache Sätze (Ziele, Takt, Lücke, Treffer/gekauft/verpasst, Ruckeln), danach S1–S13 mit OK/FEHLER", function()
        local last = { takt = { avg = 45, limit = 90 }, reihum = { nKeys = 3, worst = 5 }, hitsN = 3, missedN = 3, smooth = { frameMax = 20 } }
        local s4 = { bought = 1, hit = true }
        local a = SPT:TopLines({ { group = "J T613", status = "PASS" } }, last, s4)
        local b = SPT:TopLines({ { group = "J T734", status = "FAIL" } }, { takt = { avg = 45, limit = 90 }, reihum = { nKeys = 1, worst = 2 }, hitsN = 0, missedN = 0, smooth = { frameMax = 48 } }, {})
        local got = table.concat({ a[2], a[3], a[4], a[5], b[5], a[6]:sub(1, 22) }, " | ")
        local want = "Der Sniper prüfte 3 Ziele reihum, Ø 45 Suchen/Min. (Server erlaubt 90). | Jedes Ziel spätestens alle 5 s. | 4 Treffer, 1 gekauft, 3 verpasst. | Kein Ruckeln. Alles OK. | Ruckeln: längster Frame 48 ms (Ziel ≤ 33 ms). FEHLER bei: S13. | Einzeln: S1 OK · S2 -"
        return got == want, got, want
    end)
end

function SPT:BuildSteps(TR, B, Chk, Skp)
    local Sn = A.Sniper
    local o
    self.last = nil
    -- S4 (vorher, ausserhalb der Sandbox)
    B(function()
        local s4 = self.s4 or { status = "SKIP", detail = "Teil ohne vorherige Abfrage gestartet (/ahs testroutine sniper)" }
        if s4.status == "SKIP" then return Skp("T616", "J", "SN1951-S4 echter Mausrad-Kauf: eine Raste = genau 1 Stück (≤ 5c, nur nach Ja)", s4.detail) end
        Chk("T616", "J", "SN1951-S4 echter Mausrad-Kauf: eine Raste = genau 1 Stück (≤ 5c, nur nach Ja)", function()
            return s4.status == "PASS", s4.detail, "gekauft 1 · höchstens 1 gesendet"
        end)
    end)
    -- S1/S5–S13: beobachten
    B(function()
        if not A:IsAHOpen() then
            for _, x in ipairs(SPT.OBS_IDS) do Skp(x[1], "J", "SN1951-" .. x[2], "Auktionshaus nicht offen") end
            return
        end
        local ok, why = self:StartObserve(TR)
        if not ok then
            for _, x in ipairs(SPT.OBS_IDS) do Skp(x[1], "J", "SN1951-" .. x[2], why) end
            return
        end
        A:Print(string.format(L["Sniper-Abnahme: beobachte den Sniper %d s (Kaufen ist gesperrt) ..."], self.OBSERVE))
        local t0 = Now()
        return "WAIT", function() return Now() - t0 >= SPT.OBSERVE or not A:IsAHOpen() end, self.OBSERVE + 10, function()
            o = SPT:StopObserve()
            if not o then return end
            Chk("T613", "J", "SN1951-S1 Treffer bleiben stehen, bis gekauft oder vom Server als weg gemeldet", function()
                -- TB119-3: 0 passende Angebote ist kein Fehler (Markt hatte nichts) -> SKIP mit Gründen
                if o.shownN == 0 and o.vanished == 0 then
                    return "SKIP", string.format("Markt hatte nichts Passendes: %d Angebote geprüft · über Max %d · eigene %d · Lockangebot %d · weg %d · Suchen %d",
                        o.checked or 0, o.tooDear or 0, o.ownN or 0, o.baitN or 0, o.goneN or 0, #o.all)
                end
                return o.shownN > 0 and o.vanished == 0, string.format("%d Treffer angezeigt · ohne Grund verschwunden %d%s · Suchen %d", o.shownN, o.vanished,
                    #o.vanishedIDs > 0 and (" (" .. table.concat(o.vanishedIDs, ",", 1, math.min(5, #o.vanishedIDs)) .. ")") or "", #o.all),
                    "≥ 1 Treffer · 0 ohne Grund verschwunden"
            end)
            Chk("T617", "J", "SN1951-S5 Ruckeln: Ø ≥ 30 Bilder/s, kein Frame > 50 ms, Sync-Warteschlange ≤ 10", function()
                local bg = SPT:BackgroundText(o)
                local own = SPT:OwnText(o)
                if bg and not own then return "SKIP", bg end
                local avg = o.fpsN > 0 and o.fpsSum / o.fpsN or nil
                -- SN-EIGEN (Auftrag 19.11. 10:55): mit Messung zählt die eigene Arbeit je Bild (≤ 50 ms); Ø Bilder/s nur im Vordergrund
                local okF = own and (o.ownMax or 0) <= 50 or (not own and o.frameMax <= 50)
                local ok2 = (bg or avg == nil or avg >= 30) and okF and o.queueMax <= 10
                local mix = (A.Sync and A.Sync.QueueMix) and select(2, pcall(A.Sync.QueueMix, A.Sync)) or "-"
                return ok2, string.format("%sØ %s / min %s Bilder/s%s · längster Frame %.0f ms · Sync-Warteschlange max %d (%s)%s", own and (own .. " · ") or "",
                    avg and string.format("%.0f", avg) or "?", o.fpsMin and string.format("%.0f", o.fpsMin) or "?", bg and " (Hintergrund, nur Auskunft)" or "",
                    o.frameMax, o.queueMax, tostring(o.queueMixMax or mix),
                    (o.slowAt and (" · längster Schritt " .. o.slowAt) or "") .. SPT:LongText(o)), own and "eigene Arbeit ≤ 50 ms je Bild · ≤ 10" or "≥ 30 · ≤ 50 ms · ≤ 10"
            end)
            if o.created then SPT:S6Check(o, Chk) end                -- ohne eigene Ziele: Beobachtung lief schon nur mit dem Test-Ziel
            SPT:ObsChecks(o, Chk, Skp)
        end
    end)
    -- S6 A (Supervisor 16.11.2026 21:58): mit eigenen Zielen eine eigene Phase von S6_OBS s NUR mit dem Test-Ziel
    B(function()
        if not o or o.created then return end                -- ohne Hauptbeobachtung (übersprungen) bzw. schon gemessen
        if not A:IsAHOpen() then return Skp("T618", "J", SPT.S6_NAME, "Auktionshaus nicht offen") end
        local ok, why = SPT:StartObserve(TR, true)
        if not ok then return Skp("T618", "J", SPT.S6_NAME, why) end
        local t0 = Now()
        return "WAIT", function() return Now() - t0 >= SPT.S6_OBS or not A:IsAHOpen() end, SPT.S6_OBS + 5, function()
            local closed = not A:IsAHOpen()
            local o6 = SPT:StopObserve()
            if o6 then o6.ahClosed = closed and (Now() - t0) or nil; SPT:S6Check(o6, Chk) end
        end
    end)
    -- S2/S3: an einem Testziel in der echten Anzeige (Ereignisse nachgespielt, Kaufen bleibt gesperrt)
    B(function()
        Chk("T614", "J", "SN1951-S2 Zielzeile = bestätigte Käufe: gesendet -> Fehler zählt nicht, Bestätigung zählt", function()
            local key = "i:990196501"
            local t = { key = key, kind = "item", itemID = 990196501, maxPrice = 100, qty = 10, budget = 1000, bought = 0, spent = 0 }
            local saved = { buys = Sn.itemBuys, getT = Sn.GetTarget, md = Sn.MarkDead, rf = Sn.ReportFail, pn = Sn.PlanNext, pr = A.Print, after = Sn.AfterPurchase,
                lbe = A.AH.lastBuyError, ls = Sn.lastSearch, lp = Sn.lastPurchase,
                cnt = Sn.itemCounted, late = Sn.itemLate, gl = Sn.goldLog, ids = Sn.sentIDs, bs = Sn.buyStat, gp = Sn.goldProv }
            local res = { pcall(function()
                -- SN-B6 (Ursache): itemCounted["2"] blieb vom letzten Lauf 5 Min. stehen -> die Bestätigung von Angebot 2 galt
                -- als "schon gezählt" und der Zähler blieb 0/10. Der Test startet jetzt mit leeren Listen und stellt sie zurück.
                Sn.itemCounted, Sn.itemLate, Sn.goldLog, Sn.sentIDs, Sn.goldProv = {}, {}, {}, {}, {}
                Sn.buyStat = { byOpen = {}, times = {}, sent = 0, ok = 0, rejected = 0, dup = 0 }
                Sn.itemBuys = {}
                Sn.GetTarget = function(self, k) if k == key then return t end return saved.getT(self, k) end
                Sn.MarkDead, Sn.ReportFail, Sn.PlanNext, A.Print, Sn.AfterPurchase = function() end, function() end, function() return nil end, function() end, function() end
                table.insert(Sn.itemBuys, { key = key, tgt = t, itemID = t.itemID, qty = 1, cost = 90, time = Now(), auctionID = 1 })
                table.insert(Sn.itemBuys, { key = key, tgt = t, itemID = t.itemID, qty = 1, cost = 95, time = Now(), auctionID = 2 })
                local p0 = Sn:ProgressText(t)
                A.AH.lastBuyError = { id = 1, msg = "Test", time = Now() }
                Sn:OnEvent("AUCTION_HOUSE_SHOW_ERROR", 1)
                Sn:OnEvent("AUCTION_HOUSE_PURCHASE_COMPLETED", 2)
                return A:PlainText(p0), A:PlainText(Sn:ProgressText(t)), t.bought, t.spent
            end) }
            Sn.itemBuys, Sn.GetTarget, Sn.MarkDead, Sn.ReportFail, Sn.PlanNext, A.Print, Sn.AfterPurchase = saved.buys, saved.getT, saved.md, saved.rf, saved.pn, saved.pr, saved.after
            A.AH.lastBuyError, Sn.lastSearch, Sn.lastPurchase = saved.lbe, saved.ls, saved.lp
            Sn.itemCounted, Sn.itemLate, Sn.goldLog, Sn.sentIDs, Sn.buyStat, Sn.goldProv = saved.cnt, saved.late, saved.gl, saved.ids, saved.bs, saved.gp
            if not res[1] then error(res[2], 0) end
            -- SN-B11 (c): statt "(+2 gesendet)" jetzt "2 warten auf Antwort"
            local ok = res[4] == 1 and res[5] == 95 and tostring(res[2]):find(string.format(L["%d warten auf Antwort"], 2), 1, true) ~= nil
            return ok, string.format("gesendet: \"%s\" · danach \"%s\"", tostring(res[2]), tostring(res[3])), "0/10 · 2 warten auf Antwort · danach 1/10, 95c"
        end)
        Chk("T615", "J", "SN1951-S3 Pause sichtbar (Zielzeile, Status) und \"fortsetzen\" wirkt sofort", function()
            local id = 990196502
            local saved = { ip = Sn.itemPause[id], pw = Sn.pauseWhy[id], fi = Sn.failIDs[id], hide = A.HideDeadOffer, nf = Sn.NoteFail, pr = A.Print, dead = Sn.dead, ls = Sn.lastSearch }
            local res = { pcall(function()
                A.HideDeadOffer, Sn.NoteFail, A.Print, Sn.dead = function() end, function() return false end, function() end, {}
                for i = 1, 3 do Sn:MarkDead({ auctionID = 99019650 + i, price = 1, qty = 1 }, id, "Test") end
                local txt = Sn:PauseText(id) or "-"
                local listed = false
                for _, x in ipairs(Sn:PausedItems()) do if x == id then listed = true end end
                Sn:ResumeItem(id)
                return txt, listed, Sn:ItemPaused(id)
            end) }
            A.HideDeadOffer, Sn.NoteFail, A.Print, Sn.dead, Sn.lastSearch = saved.hide, saved.nf, saved.pr, saved.dead, saved.ls
            Sn.itemPause[id], Sn.pauseWhy[id], Sn.failIDs[id] = saved.ip, saved.pw, saved.fi
            if not res[1] then error(res[2], 0) end
            local ok = res[2] ~= "-" and res[3] == true and res[4] == false
            return ok, string.format("\"%s\" · im Status %s · nach fortsetzen pausiert %s", res[2], tostring(res[3]), tostring(res[4])), "pausiert bis … · im Status · nicht mehr pausiert"
        end)
    end)
    -- SN-TEST2: Nachbildung S7–S13 und Ergebnis oben
    B(function() SPT:SimChecks(Chk) end)
end
