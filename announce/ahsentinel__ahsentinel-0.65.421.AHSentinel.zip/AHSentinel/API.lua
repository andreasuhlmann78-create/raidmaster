if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - API.lua
-- Öffentliche Schnittstelle AHSentinel.API, Version 1 (Vertrag: raidmaster shared/wissen/schnittstelle-ahsentinel-api.md,
-- Anweisung der Prüf-Sitzung 9. Nov. 16:50). Nur Weiterleitungen auf vorhandene Funktionen.
--   * global AHSentinel mit Feld API; Alias AHAnalyzerPro.API (dieselbe Tabelle)
--   * jede Funktion wirft nie einen Lua-Fehler (pcall), nil wenn nichts bekannt; Beträge in Kupfer (ganze Zahlen)
--   * neue Funktionen nur hinzufügen, nie Bedeutung oder Rückgabewerte ändern (sonst Version 2 mit neuem Feld)
-- Die alten öffentlichen Funktionen (RealPrice, RealValue, AuctionFee, AHFee, ForeverAuctionFee, GetMarketValue,
-- GetCurrent) bleiben unverändert.
-- ============================================================
local A = AHAnalyzerPro
local string = A.SafeString or string          -- AHS-OVF1: string.format ohne 32-Bit-Überlauf (gleicher Text darunter)
local CreateFrame, C_Timer = A.OwnCreateFrame or CreateFrame, A.OwnTimer or C_Timer      -- VS-BILD-2 (0.65.320): eigene Skripte/Zeitgeber je Bild messen (nur während einer Vollscan-Messung)

local API = { version = 1 }
-- Rückwärts: bis 0.65.49 war AHAnalyzerPro:API(name) eine interne Hilfsfunktion (jetzt A:Global). Wer sie noch so
-- aufruft, bekommt weiter dasselbe Ergebnis.
setmetatable(API, { __call = function(_, self, name) return A:Global(name) end })
A.API = API
_G.AHSentinel = _G.AHSentinel or {}
_G.AHSentinel.API = API

local function Int(v) return type(v) == "number" and math.floor(v + 0.5) or nil end

-- sicher aufrufen: nie ein Fehler, nil bei Fehler
-- E4 (Befund HOCH 21:45, Messung ProfessionSentinel: ~950 MB neue Tabellen in einem Testlauf bei 1,75 Mio. Fragen): die Hülle legte je
-- Aufruf eine Tabelle { pcall(...) } an. Jetzt ohne Tabelle (Rückgabewerte direkt durchgereicht, gleiche Werte).
local function Ret(ok, ...)
    if not ok then return nil end
    return ...
end
local function Safe(fn)
    return function(...) return Ret(pcall(fn, ...)) end
end

-- Preis je Stück, Quelle ("scan" / "market" / "vendor"), Alter in Sekunden
API.Price = Safe(function(itemID)
    if not itemID then return nil end
    local v, info = A:RealPrice(itemID)
    if v then
        local age = (info and info.currentTime) and math.max(0, time() - info.currentTime) or nil
        -- "scan" nur, wenn der Wert wirklich aus dem letzten Scan stammt (Ausreisser-Ersatz durch den Median: "market")
        -- Nachprüfung 08:40 Punkt 3: "scan" nur, wenn der Preis wirklich im letzten Scan war (inScan)
        return Int(v), (info and info.source == "ah" and info.inScan) and "scan" or "market", age
    end
    local vendor = A:GetVendorPrice(itemID)
    if type(vendor) == "number" and vendor > 0 then return Int(vendor), "vendor", nil end
    return nil
end)

-- Netto-Erlös gesamt für qty Stück (5 % bzw. 15 % neutral, erwarteter Einzahlungsverlust, mindestens Händlerwert);
-- 2. Wert { gross, cut, depositRisk, vendorWins }
API.NetSale = Safe(function(itemID, qty)
    if not itemID then return nil end
    qty = math.max(1, math.floor(tonumber(qty) or 1))
    local net, unit, info, vendorWins = A:RealValue(itemID, qty)
    if not net then return nil end
    local gross = unit and unit * qty or net
    local cut = unit and A:SaleFee(itemID, unit, qty) or 0
    local risk = (info and info.relistCost) or 0
    -- API-TAB-1 (Supervisor 22:45, Vertrag Version 1): eine zurückgegebene Tabelle wird NIE mehr geändert (Abnehmer wie
    -- ProfessionSentinel speichern sie roh). Gegen neue Tabellen je Aufruf (E4) sorgt der Zwischenspeicher unten: dieselbe Frage im
    -- selben Datenstand bekommt dieselbe (unveränderte) Tabelle; ein neuer Datenstand bekommt eine NEUE, die alte bleibt gültig.
    return Int(net), { gross = Int(gross), cut = Int(cut), depositRisk = Int(risk), vendorWins = vendorWins and true or false }
end)

-- Einzahlung (Blizzard-Wert, sonst Formel nach Regelwerk, Minimum gemessen statt fest)
API.Deposit = Safe(function(itemID, qty, hours)
    if not itemID then return nil end
    qty = math.max(1, math.floor(tonumber(qty) or 1))
    local size = math.max(1, A:AuctionSize(itemID, qty) or 1)
    local auctions = math.max(1, math.ceil(qty / size))
    local dep, src = A:ListingDeposit(itemID, qty, hours or 24, auctions)
    if src ~= "blizzard" then
        local vendor = A:GetVendorPrice(itemID)
        if not (type(vendor) == "number" and vendor > 0) then return nil end   -- unbekannt: kein Händlerpreis
    end
    return Int(dep)
end)

API.CutPct = Safe(function() return A:CutPct() end)

-- Kosten gesamt über den günstigsten Weg (wie Gewinn-Fenster, Cr:BestUnit); 2. Wert Liste je Zutat
API.MaterialCost = Safe(function(itemID, qty)
    local Cr = A.Crafting
    if not (itemID and Cr and Cr.RecipeIndex) then return nil end
    local rec = Cr:RecipeIndex(nil, true)[itemID]
    if not rec then return nil end
    qty = math.max(1, math.floor(tonumber(qty) or 1))
    local crafts = math.ceil(qty / math.max(rec.made or 1, 1))
    -- API-TAB-1: je Rechnung eine NEUE Liste, danach nie geändert (Zwischenspeicher unten gegen neue Tabellen je Wiederholung)
    local list = {}
    local total, n = 0, 0
    for _, re in ipairs(rec.reagents or {}) do
        local need = crafts * re[2]
        -- API-PM3: Preisleiter für die benötigte Menge (Cr:LadderCost), nicht günstigstes Einzelstück × Menge
        local c, how = Cr:LadderCost(re[1], need)
        if not c then return nil end
        local cost = Int(c)
        total = total + cost
        n = n + 1
        list[n] = { itemID = re[1], qty = need, source = how or "ah", cost = cost }
    end
    return Int(total), list
end)

-- Entzaubern: Wert brutto je Entzauberung, netto, Anzahl eigene Entzauberungen, Quelle ("own" / "table")
API.DisenchantValue = Safe(function(itemID)
    local D = A.Disenchant
    if not (itemID and D and D.Prior and D:Prior(itemID)) then return nil end
    local v, net, _, basis, n = D:DealValue(itemID)
    if not v then return nil end
    return Int(v), Int(net), n or 0, basis == "actual" and "own" or "table"
end)

-- bester Weg für ein Stück: "sell" oder "disenchant", Netto-Wert dieses Wegs
-- PS-DOCK1: Einkaufsliste für ein Rezept des offenen Berufsfensters (ProfessionSentinel ruft das auf) - dieselbe Rechnung wie
-- die Knöpfe "Materialien als Einkaufsliste" / "Nur was mir fehlt" (ESL1-Prüfungen gelten). Rückgabe: ok, Meldung, Listenname
API.ReagentsToList = Safe(function(spellID, n, onlyMissing)
    local Cr = A.Crafting
    if not (Cr and Cr.IndexForSpell) then return false, L["Berufsfenster ist nicht offen."] end
    local kind = Cr.kind or "trade"
    local idx = Cr:IndexForSpell(kind, spellID)
    if not idx then return false, L["Rezept nicht im offenen Berufsfenster gefunden."] end
    if onlyMissing then return Cr:MissingToList(kind, idx, n or 1) end
    return Cr:ReagentsToList(kind, idx, n or 1)
end)
-- T-AB5 (SN2115b): dieselbe Wahl wie Tooltip, Gewinn-Fenster, Beste Rezepte, Markt und Sniper (A:BestWay -> A:ChooseWay):
-- Entzaubern nur, wenn der Weg an ist (Optionen, Verzauberkunst) und das Hauptmaterial nicht veraltet; bei Gleichstand Entzaubern.
-- Händler zahlt mehr -> "sell" (wie bisher, Wert = Händlerpreis).
API.BestWay = Safe(function(itemID)
    if not itemID then return nil end
    local v, way = A:BestWay(itemID)
    if not v then return nil end
    return (way == "de") and "disenchant" or "sell", Int(v)
end)

-- Verkaufsdauer: "fast" / "slow" / "rare" / nil, Median-Stunden bis Verkauf, Absatz pro Tag am Markt
local SPEED = { schnell = "fast", langsam = "slow", kaum = "rare" }
API.SellSpeed = Safe(function(itemID)
    if not itemID then return nil end
    local Le = A.Ledger
    local r = Le and Le.SellSpeed and Le:SellSpeed(itemID)
    local okL, liq = pcall(A.GetLiquidity, A, itemID)
    local perDay = okL and liq and liq.perDay or nil
    if not r and not perDay then return nil end
    return r and SPEED[r.speed] or nil, r and r.hours or nil, perDay
end)

-- eingestellter Mindestgewinn in % (Entzaubern: DEBuy:DEMinRoi, mindestens 30 % - DE30) - dieselbe Grenze wie
-- "Lohnt bis" im Tooltip und der automatische Mindestpreis (offener Punkt 2a)
API.MinProfitPct = Safe(function()
    local Se = A.Seller
    local p = (Se and Se.MinProfitPct) and Se:MinProfitPct() or 0.20
    return math.floor(p * 100 + 0.5)
end)

-- Gold pro Stunde (H9, Zeitraum 30 Tage): Kupfer pro Stunde und gemessene Sekunden; nil, solange zu wenig gemessen
local GPH = { craft = "craft", disenchant = "de", flip = "flip" }
-- E1 (Befund HOCH 21:45: 75–93 ms je Aufruf, im Lauf bis 489 ms - Activity:Report("30") über die ganze Buchhaltung bei JEDEM Aufruf):
-- 0.65.334 merkte den Bericht, rechnete aber den ersten Aufruf je Datenstand (jede neue Buchung) noch am Stück (Nachbau 101 ms).
-- 0.65.335: Act:CachedReport - gemerkt je Buchungs-Stand, höchstens 60 s alt; neu gerechnet als Hintergrund-Aufgabe in Portionen.
-- Bis dahin kommt der letzte Bericht mit seiner Stand-Zeit (3. Wert, time()); vor dem allerersten Bericht nil (Rechnung angestossen).
API.GPH_KEEP = 60
local gphAH = {}
API.GoldPerHour = Safe(function(kind)
    local Act = A.Activity
    if not (Act and Act.CachedReport) then return nil end
    Act.REPORT_KEEP = API.GPH_KEEP
    local rows, total, t = Act:CachedReport("30")
    if not rows then return nil end
    local r
    if kind == "all" or kind == nil then r = total
    elseif kind == "ah" then
        local f, w = rows.flip, rows.raw
        r = gphAH                                        -- E4: keine neue Tabelle je Aufruf
        r.profit, r.seconds = f.profit + w.profit, (f.seconds or 0) + (w.seconds or 0)
        r.perHour = r.seconds >= Act.MIN_SECONDS and (r.profit / r.seconds * 3600) or nil
    elseif GPH[kind] then r = rows[GPH[kind]]
    end
    if not (r and r.perHour) then return nil end
    return Int(r.perHour), Int(r.seconds), t
end)

-- E2 (Befund HOCH 21:45: D:FindDeals ~150 ms am Stück, wenn ein anderes Addon es direkt aufruft): fertiges Ergebnis der letzten
-- Rechnung mit Stand-Zeit. Gerechnet wird als Hintergrund-Aufgabe in Portionen ("de:deals", nach jedem Scan und auf Anfrage, wenn
-- der Stand älter als DEALS_KEEP s ist). Rückgabe: Liste (nur lesen - dieselbe Tabelle bis zur nächsten Rechnung), Stand-Zeit;
-- nil, solange noch nie gerechnet wurde (die Aufgabe ist dann angestossen).
API.DEALS_KEEP = 300
local deals = {}
local function DealsJob()
    local D = A.Disenchant
    if not (A.Job and D and D.FindDeals) or A:HasJob("de:deals") then return end
    A:Job("de:deals", function()
        local ok, list = A:PCall(D.FindDeals, D)
        if ok and type(list) == "table" then deals.list, deals.t = list, time() end
    end)
end
-- FRAGE 18.11. 07:30 (ProfessionSentinel 0.9.68): nil der API heisst "unbekannt" ODER "lädt noch". Additiv (Version 1 bleibt):
-- API.Pending() -> true, solange die erste Rechnung der Lern-Faktoren nach dem Laden läuft (dann liefern NetSale/BestWay/WorthUpTo/
-- SellSpeed nil); sobald sie fertig ist, meldet Subscribe "settings". Ohne Lernen oder danach false.
API.Pending = Safe(function()
    local Ln = A.Learn
    return (Ln and Ln.FactorPending and Ln:FactorPending()) and true or false
end)

-- SYNC3 (Hinweis Supervisor 18.11. 15:43, GoldSentinelSync 3): Sync fragt <Addon>API.TestRunning() aller GoldSentinel-Addons und hält
-- während einer Testroutine Lernen aus Nachrichten und echtes Flüstern an. AHSentinel hatte kein AHSentinelAPI -> Schutz griff für die
-- eigene Testroutine nicht. Additiv: API.TestRunning() und der globale Name AHSentinelAPI (dieselbe Tabelle wie AHSentinel.API).
API.TestRunning = Safe(function()
    return (A.InTestRoutine and A:InTestRoutine()) and true or false
end)
_G.AHSentinelAPI = API

API.DisenchantDeals = Safe(function()
    if not deals.list or time() - (deals.t or 0) > API.DEALS_KEEP then DealsJob() end
    if not deals.list then return nil end
    return deals.list, deals.t
end)
A:On("SCAN_FINISHED", function() if deals.list then pcall(DealsJob) end end)

-- API-PM4 (Masterplan 4.4, Nachtschicht 16.11.): verkaufte Menge und Erlös eines Items aus der Buchhaltung seit `since`
-- (time(), Standard: letzte 30 Tage). Rückgabe: Menge, Erlös netto (nach AH-Anteil), Erlös brutto, Anzahl Verkäufe;
-- 0, 0, 0, 0 wenn nichts verkauft. Nur lesen. Zeit eines Verkaufs wie in der Buchhaltung (Post: Verkaufszeit = Ankunft − 1 Std.).
API.SOLD_DAYS = 30
API.Sold = Safe(function(itemID, since)
    itemID = tonumber(itemID)
    if not itemID then return nil end
    local Le = A.Ledger
    local db = A.db and A.db.ledger
    local entries = API.testEntries or (db and db.entries)              -- Testroutine: eigene Einträge, nie die echten
    if not (Le and type(entries) == "table") then return nil end
    since = tonumber(since) or (time() - API.SOLD_DAYS * 86400)
    local qty, net, gross, n = 0, 0, 0, 0
    for _, e in ipairs(entries) do
        if e.kind == "sale" and e.itemID == itemID then
            local t = Le.SaleTime and Le:SaleTime(e) or e.t
            if (t or 0) >= since then
                qty = qty + (e.qty or 0)
                gross = gross + (e.amount or 0)
                net = net + (e.amount or 0) - (e.cut or 0)
                n = n + 1
            end
        end
    end
    return qty, Int(net), Int(gross), n
end)

-- AHS-API2 (Supervisor 25.11. 15:13, für ProfessionSentinel PS-TQ1, Entscheid des Nutzers 13:47 "Echten Weg verfolgen"):
-- API.Disenchanted(itemID[, since]) -> { n, value, first, last } oder nil ohne Daten.
--   n     = eigene Entzauberungen dieses Items seit since (db.deLog: alle Charaktere des Kontos, auch Beute ausserhalb der Gruppen-Tabelle)
--   value = Wert der Beute gesamt in Kupfer: Material, das aus dem Entzaubern verkauft wurde (Buchungen "sale" mit Herkunft "de"), zählt mit
--           dem Netto-Erlös (nach AH-Anteil), zugeordnet der Reihe nach (älteste Entzauberung zuerst, nur Verkäufe NACH der Entzauberung);
--           nicht verkauftes Material mit dem Preis zum Zeitpunkt der Entzauberung (letzter bestätigter Preis des Preisverlaufs davor,
--           sonst heutiger Marktwert)
--   first/last = Zeit der ersten/letzten gezählten Entzauberung.
-- Nichts neu erfasst (nur deLog + Buchungen lesen). Index einmal je Datenstand (Länge/letzte Zeit von deLog und Buchungen), danach je Aufruf
-- nur die Entzauberungen dieses Items.
API.DE_DAYS = 30
local deIdx = { key = nil }
local function PriceAtTime(id, t)
    local okH, F, n = pcall(A.HF, A, id)
    if okH and F then
        for i = n, 1, -1 do
            local b = (i - 1) * 5
            if F[b + 1] <= t and (F[b + 2] or 0) > 0 and (F[b + 5] or 0) % 2 == 0 then return F[b + 2] end
        end
    end
    local mv = A:GetMarketValue(id)
    return (mv and mv > 0) and mv or 0
end
-- AHS-API2-b (Supervisor 25.11. 16:40: ProfessionSentinel fragt beim Einloggen und am Briefkasten je Item – Buchungen ändern sich dort laufend,
-- der Index (7,7 ms am Stück mit den echten Daten) würde oft im Bild neu gebaut): der Index wird jetzt als Hintergrund-Aufgaben in Portionen
-- gebaut (A:Pause alle DE_STEP Einträge). Solange er nicht zum Datenstand passt, gibt API.Disenchanted nil, "pending" zurück; ist er fertig,
-- meldet API.Notify("ledger") das den Abonnenten (dann neu fragen). Testdaten (API.testDeLog) rechnen sofort, ausser API.testAsync.
API.DE_STEP = 200
local function DESources()
    local dl = API.testDeLog or (A.db and A.db.deLog) or {}
    local BK = A.Books
    local bdb = API.testBooks or (BK and BK.Data and BK:Data())
    return dl, (bdb and bdb.log) or {}
end
-- Datenstand ohne neuen Text je Aufruf (PS fragt je Item): Längen, letzte Zeiten, Änderungszähler, Testdaten ja/nein
local function DEStateSame(idx, dl, blog)
    return idx.nDl == #dl and idx.tDl == (dl[#dl] and dl[#dl].t) and idx.nBl == #blog and idx.tBl == (blog[#blog] and blog[#blog].t)
        and idx.gen == (API.deGen or 0) and idx.test == (API.testDeLog ~= nil)
end
local function BuildDEIndex(dl, blog, pause)
    local state = { nDl = #dl, tDl = dl[#dl] and dl[#dl].t, nBl = #blog, tBl = blog[#blog] and blog[#blog].t, gen = API.deGen or 0, test = API.testDeLog ~= nil }
    local step = API.DE_STEP
    -- Verkäufe von Material aus dem Entzaubern, je Material in Zeitfolge
    local sales = {}
    for k, e in ipairs(blog) do
        if pause and k % step == 0 then A:Pause() end
        if e.k == "sale" and e.st ~= "x" and e.bt == "de" and e.id and (e.q or 0) > 0 then
            local L = sales[e.id]
            if not L then L = {}; sales[e.id] = L end
            L[#L + 1] = { t = e.t or 0, q = e.q, rev = e.rev or 0 }
        end
    end
    for _, L in pairs(sales) do table.sort(L, function(x, y) return x.t < y.t end) end
    if pause then A:Pause() end
    local order = {}
    for i, d in ipairs(dl) do if type(d) == "table" and d.itemID and type(d.loot) == "table" then order[#order + 1] = i end end
    table.sort(order, function(x, y) local ta, tb = dl[x].t or 0, dl[y].t or 0; if ta ~= tb then return ta < tb end return x < y end)
    local ptr, byItem = {}, {}
    for k, i in ipairs(order) do
        if pause and k % step == 0 then A:Pause() end
        local d = dl[i]
        local t = d.t or 0
        local val = 0
        for _, l in ipairs(d.loot) do
            local mat, left = l[1], l[2] or 1
            local L = sales[mat]
            local p = ptr[mat]
            if not p then p = { i = 1, rest = nil }; ptr[mat] = p end
            while L and left > 0 and p.i <= #L do
                local sl = L[p.i]
                if sl.t < t then
                    p.i, p.rest = p.i + 1, nil                        -- Verkauf vor dieser Entzauberung: stammt nicht aus ihr
                else
                    local rest = p.rest or sl.q
                    local take = math.min(rest, left)
                    val = val + sl.rev * take / sl.q
                    left, rest = left - take, rest - take
                    if rest <= 0 then p.i, p.rest = p.i + 1, nil else p.rest = rest end
                end
            end
            if left > 0 then val = val + left * PriceAtTime(mat, t) end
        end
        local it = byItem[d.itemID]
        if not it then it = {}; byItem[d.itemID] = it end
        it[#it + 1] = { t = t, v = val }
    end
    state.byItem = byItem
    return state
end
-- sync = true: sofort rechnen (Tests, Testbericht). Sonst: passt der Index nicht, Hintergrund-Aufgabe starten und nil zurück.
function API.DEIndex(sync)
    local dl, blog = DESources()
    if deIdx.byItem and DEStateSame(deIdx, dl, blog) then return deIdx end
    if sync or (API.testDeLog ~= nil and not API.testAsync) then
        deIdx = BuildDEIndex(dl, blog, false)
        return deIdx
    end
    if not A:HasJob("api:deindex") then
        A:Job("api:deindex", function()
            local dl2, blog2 = DESources()
            local t0 = debugprofilestop and debugprofilestop() or 0
            local idx = BuildDEIndex(dl2, blog2, true)
            deIdx = idx
            API.deLastBuildMs = (debugprofilestop and debugprofilestop() or 0) - t0
            API.Notify("ledger")                                  -- Abonnenten (ProfessionSentinel) fragen dann neu
        end)
    end
    return nil
end
function API.DEDirty() API.deGen = (API.deGen or 0) + 1 end
A:On("LEDGER_CHANGED", function() API.DEDirty() end)
A:On("DE_LOOT", function() API.DEDirty() end)
API.Disenchanted = Safe(function(itemID, since)
    itemID = tonumber(itemID)
    if not itemID then return nil end
    since = tonumber(since) or (time() - API.DE_DAYS * 86400)
    local idx = API.DEIndex()
    if not idx then return nil, "pending" end                    -- AHS-API2-b: Index wird im Hintergrund gebaut – später neu fragen
    local list = idx.byItem[itemID]
    if not list then return nil end                              -- nie entzaubert (bzw. nicht mehr im Protokoll): keine Daten
    local n, v, first, last = 0, 0, nil, nil
    for _, x in ipairs(list) do
        if x.t >= since then
            n, v = n + 1, v + x.v
            first = first and math.min(first, x.t) or x.t
            last = last and math.max(last, x.t) or x.t
        end
    end
    return { n = n, value = Int(v) or 0, first = first, last = last }   -- Item kennt Entzauberungen, keine seit since: n = 0, value = 0
end)

-- Wunsch ProfessionSentinel (Nacht-Prüfung 20:45): Sniper im Ruhemodus? true/false. Ohne Nebenwirkung (liest nur den Stand,
-- den der Sniper selbst führt - Sn:QuietOn setzt quietSince); PS liest so nicht mehr AHAnalyzerPro.Sniper.quietSince direkt.
API.QuietOn = Safe(function()
    local Sn = A.Sniper
    return (Sn and Sn.quietSince ~= nil) and true or false
end)

-- letzter Scan: Zeitpunkt (time()), Anzahl Items
API.LastScan = Safe(function()
    local db = A.db
    if not db or (db.lastScanTime or 0) == 0 then return nil end
    if API._countVersion ~= A.priceVersion or not API._count then
        local n = 0
        for _ in pairs(db.marketData or {}) do n = n + 1 end
        API._count, API._countVersion = n, A.priceVersion
    end
    return db.lastScanTime, API._count
end)

-- ------------------------------------------------------------
-- Ereignis: Subscribe(fn) -> fn(reason) mit "scan", "ledger", "settings"; gedrosselt (höchstens einmal je 2 s je Grund)
-- ------------------------------------------------------------
API.subscribers = {}
API.THROTTLE = 2
local pending = {}
local scheduled = false
API.Subscribe = Safe(function(fn)
    if type(fn) ~= "function" then return nil end
    API.subscribers[#API.subscribers + 1] = fn
    return true
end)

-- API-PM (für ProfessionSentinel PM4, 13.11.): "Lohnt bis" je Stück wie im Tooltip, Weg, Sicherheit ("sicher"/"unsicher").
-- Bis der Rechenkern (RK2) fertig ist: nur der Entzauber-Weg; nil, wenn nichts bekannt oder Preise veraltet.
API.WAY_NAMES = { ah = "resale", haendler = "vendor", de = "disenchant" }
-- AHS-API1 HOCH (Supervisor 27.11. 11:05): im Spiel 23,3 ms / +0,9 MB für EINEN kalten Aufruf (Wollcape), im Nachbau mit den Laptop-Daten
-- 27.11. 10:59 dieselben 20 Schneider-Produkte 0,2–1,7 ms / 2–18 KB (auch direkt nach dem Laden, nach Preis-, Scan- und Buchungsänderung).
-- Die Ursache ist also im Spiel zu messen: jeder kalte Aufruf zeichnet seine Teile auf (Zeit und Speicher je Schritt); ab API.SLOW_MS
-- schreibt die Hülle eine Zeile API-LANGSAM ins Protokoll (höchstens API.SLOW_MAX je Sitzung). Kostet je kaltem Aufruf ~10 Uhrzeit-Abfragen.
API.SLOW_MS, API.SLOW_MAX = 4, 20
API.slowCount = 0
local prof = {}
API.prof = prof
local function PClock() return debugprofilestop and debugprofilestop() or 0 end
-- 0.65.421 (Supervisor 13:00: Zeit wächst mit angelegtem Speicher, ~25–30 µs je KB): Teile gleichen Namens zusammengezählt (×n),
-- dazu Bereinigung erkennen: sinkt der Speicher zwischen zwei Messpunkten, lief darin ein Schritt der Speicherbereinigung (GC).
local profAgg = {}
API.profAgg = profAgg
API.gcLast, API.gcDrops, API.gcFreed = 0, 0, 0
local function PStep(name, t0, k0)
    if not API.profOn or not t0 then return end                          -- nur innerhalb eines kalten API-Aufrufs
    local now = collectgarbage("count")
    if now < API.gcLast then API.gcDrops, API.gcFreed = API.gcDrops + 1, API.gcFreed + (API.gcLast - now) end
    API.gcLast = now
    local a = profAgg[name]
    if not a then
        if #prof >= 30 then return end
        a = { 0, 0, 0 }
        profAgg[name] = a
        prof[#prof + 1] = name
    end
    a[1], a[2], a[3] = a[1] + (PClock() - t0), a[2] + (now - k0), a[3] + 1
end
local function ProfText()
    local out = {}
    for i = 1, #prof do
        local n = prof[i]
        local a = profAgg[n]
        out[#out + 1] = string.format("%s %.1f ms %+.0f KB%s", n, a[1], a[2], a[3] > 1 and (" ×" .. a[3]) or "")
    end
    return #out > 0 and table.concat(out, " · ") or "-"
end
API.PClock, API.PStep = PClock, PStep
-- Zeilen erst ins Protokoll, wenn keine Testroutine läuft (sonst landeten sie in deren Sandbox und gingen verloren)
API.slowPending = {}
function API.FlushSlow()
    local q = API.slowPending
    if #q == 0 or not A.Diag then return end
    local TR = A.TestRoutine
    if TR and (TR.running or TR.finishing) then
        if not API.slowRetry and C_Timer and C_Timer.After then            -- später nochmals (alle 10 s, bis die Routine fertig ist)
            API.slowRetry = true
            C_Timer.After(10, function() API.slowRetry = nil; API.FlushSlow() end)
        end
        return
    end
    for i = 1, #q do pcall(A.Diag.Add, A.Diag, "API-LANGSAM", q[i][1], q[i][2]); q[i] = nil end
end
A:On("READY", function() A.loadGT = GetTime and GetTime() or nil end)
API.WorthUpTo = Safe(function(itemID, qty)
    if not itemID then return nil end
    -- TB170-10 (S3 "eine Zahl"): ist der beste Weg nicht Entzaubern (AH, Händler), denselben Wert wie Tooltip/Anzeige liefern
    local Kn = A.Kern
    if Kn and Kn.LohntBis then
        local t0, k0 = PClock(), collectgarbage("count")
        local okL, b = pcall(Kn.LohntBis, Kn, itemID)
        PStep("Lohnt bis", t0, k0)
        if okL and b and b.per and b.way and b.way ~= "de" then
            local q = math.max(1, math.floor(tonumber(qty) or 1))
            return Int(b.per * q), API.WAY_NAMES[b.way] or b.way, "sicher", nil, Int(b.per)
        end
    end
    -- RK2-A: dieselbe Rechnung wie Tooltip, Markt, Sammelkauf und Sniper (A.Core:WorthUpTo)
    local MK = A.Core
    if MK and MK.WorthUpTo then
        local t0, k0 = PClock(), collectgarbage("count")
        local amt, way, safe, per, info = MK:WorthUpTo(itemID, qty)
        PStep("Kern-Wert", t0, k0)
        if not amt or (info and info.stale) then return nil end
        local TT = A.Tooltip
        if safe == "sicher" and TT and TT.MatsUnsure then
            t0, k0 = PClock(), collectgarbage("count")
            local ok, u = pcall(TT.MatsUnsure, TT, itemID)
            PStep("Materialien", t0, k0)
            if ok and u then safe = "unsicher" end
        end
        -- API-PM2: 4. Wert Sicherheit 0–1 (gemessene Trefferquote des Wegs, MA2; nil = lernt noch), 5. Wert Stückpreis
        local conf
        if MK.WayState and MK.Quote and MK:WayState("de") ~= "lernt" then
            local _, q = MK:Quote("de")
            conf = q and math.floor(q * 100 + 0.5) / 100 or nil
        end
        return Int(amt), way, safe, conf, Int(per)
    end
    local TT = A.Tooltip
    if not (TT and TT.DisenchantVerdict) then return nil end
    local r = TT:DisenchantVerdict(itemID)
    if not (r and r.limit) or r.stale then return nil end
    return Int(r.limit * (qty or 1)), "disenchant", r.unsure and "unsicher" or "sicher"
end)
-- Marktlage: "normal" / "aufkauf" / "flut" / "duenn" / "alt"; 2. Wert Band-Trend (Richtung, kommt mit RK/MA4 - bis dahin nil)
API.MarketState = Safe(function(itemID)
    if not itemID then return nil end
    -- MA4: 2. Wert = Richtung des Stufenbands (nur belegtes Band, sonst nil)
    local trend
    local W = A.Waves
    if W and W.ItemTrend then
        local okT, tr = pcall(W.ItemTrend, W, itemID)
        if okT then trend = tr end
    end
    local okB, bo = pcall(A.BuyoutInfo, A, itemID)
    if okB and bo then return "aufkauf", trend end
    local cur, qty, t = A:GetCurrent(itemID)
    if not cur then return nil, trend end
    if not t or time() - t > 6 * 3600 then return "alt", trend end
    local F, n = A:HF(itemID)
    local prev
    for i = n, 1, -1 do if F[(i - 1) * 5 + 1] <= time() - 20 * 3600 then prev = A.HistFlatRow(F, i); break end end
    if prev and prev.q and qty and prev.q > 0 and qty >= prev.q * 3 and cur <= (prev.p or cur) * 0.8 then return "flut", trend end
    if (qty or 0) < 5 then return "duenn", trend end
    return "normal", trend
end)

-- ------------------------------------------------------------
-- E4 (Befund HOCH 21:45: je API-Aufruf neue Tabellen, ~950 MB in einem Testlauf von ProfessionSentinel): NetSale, BestWay und WorthUpTo
-- je Item (und Menge) gemerkt, solange derselbe Datenstand gilt (Preis-Stand, letzter Scan, Anzahl Buchungen, Markt, Wege-Einstellungen,
-- Lernen an/aus) und höchstens MEMO_KEEP s - die Wiederholung legt keine Tabelle an und rechnet nichts. Nie während der Testroutine
-- (Prüfungen ersetzen Funktionen und brauchen die frische Rechnung).
-- ------------------------------------------------------------
API.MEMO_KEEP = 30
local memo = { v = {}, net = {}, way = {}, worth = {}, mat = {} }
local function Clear(t) for k in pairs(t) do t[k] = nil end end
local function MemoOn()
    if A.TestRoutine and A.TestRoutine.running and not API.memoInTest then return false end
    local db = A.db
    local led = db and db.ledger and db.ledger.entries
    local Ln = A.Learn
    local v = memo.v
    local now = GetTime and GetTime() or 0
    local a1, a2, a3, a4, a5, a6 = A.priceVersion, db and db.lastScanTime, led and #led, A.marketKey, A.waysVer, Ln and Ln.forceOff
    if v[1] ~= a1 or v[2] ~= a2 or v[3] ~= a3 or v[4] ~= a4 or v[5] ~= a5 or v[6] ~= a6 or now - (v.t or -1e9) > API.MEMO_KEEP then
        v[1], v[2], v[3], v[4], v[5], v[6], v.t = a1, a2, a3, a4, a5, a6, now
        Clear(memo.net); Clear(memo.way); Clear(memo.worth); Clear(memo.mat)
    end
    return true
end
API.MemoClear = function() memo.v.t = nil end
-- E3-Auflage (Supervisor 22:45, Punkt 3): solange die Lern-Faktoren beim Start noch als Hintergrund-Aufgabe laufen, wären NetSale,
-- BestWay, WorthUpTo und SellSpeed nur vorläufig (Absatz ohne gelernten Faktor) - die API liefert dann nil ("noch nicht bekannt",
-- Vertrag Version 1) statt eines Werts, der als endgültig gelten könnte. Dauer: die ersten Sekunden nach dem Laden.
local function Provisional()
    local Ln = A.Learn
    return Ln and Ln.FactorPending and Ln:FactorPending() or false
end
do
    local rawNet, rawWay, rawWorth, rawMat, rawSpeed = API.NetSale, API.BestWay, API.WorthUpTo, API.MaterialCost, API.SellSpeed
    API.SellSpeed = Safe(function(itemID)
        if Provisional() then return nil end
        return rawSpeed(itemID)
    end)
    API.NetSale = Safe(function(itemID, qty)
        if Provisional() then return nil end
        if not (itemID and MemoOn()) then return rawNet(itemID, qty) end
        local q = math.max(1, math.floor(tonumber(qty) or 1))
        local byQ = memo.net[itemID]
        local e = byQ and byQ[q]
        if not e then
            local net, d = rawNet(itemID, q)
            if not byQ then byQ = {}; memo.net[itemID] = byQ end
            e = net and { net, d } or false               -- d bleibt unverändert (API-TAB-1)
            byQ[q] = e
        end
        if not e then return nil end
        return e[1], e[2]
    end)
    -- MaterialCost: je Item und Menge gemerkt; gilt nur für dasselbe Rezept (Rezept-Verzeichnis neu gelesen -> neu gerechnet)
    API.MaterialCost = Safe(function(itemID, qty)
        if not (itemID and MemoOn()) then return rawMat(itemID, qty) end
        local Cr = A.Crafting
        local rec = Cr and Cr.RecipeIndex and Cr:RecipeIndex(nil, true)[itemID]
        if not rec then return rawMat(itemID, qty) end
        local q = math.max(1, math.floor(tonumber(qty) or 1))
        local byQ = memo.mat[itemID]
        local e = byQ and byQ[q]
        if not e or e[3] ~= rec then
            local total, list = rawMat(itemID, q)
            if not byQ then byQ = {}; memo.mat[itemID] = byQ end
            e = { total, list, rec }
            byQ[q] = e
        end
        return e[1], e[2]
    end)
    API.BestWay = Safe(function(itemID)
        if Provisional() then return nil end
        if not (itemID and MemoOn()) then return rawWay(itemID) end
        local e = memo.way[itemID]
        if e == nil then
            local w, v = rawWay(itemID)
            e = w and { w, v } or false
            memo.way[itemID] = e
        end
        if not e then return nil end
        return e[1], e[2]
    end)
    -- AHS-API1: jede echte Rechnung (mit und ohne Zwischenspeicher, auch während der Testroutine) messen
    local function MeasuredWorth(itemID, q)
        for i = #prof, 1, -1 do prof[i] = nil end
        for k in pairs(profAgg) do profAgg[k] = nil end
        API.gcDrops, API.gcFreed = 0, 0
        local Kn, Le = A.Kern, A.Ledger
        local ver0, ib0 = Kn and Kn.lohntVer, Le and Le.indexBuilds
        local t0, k0 = PClock(), collectgarbage("count")
        API.gcLast = k0
        API.profOn = true
        local okR, a, b, c, d, f = pcall(rawWorth, itemID, q)
        API.profOn = nil
        if not okR then error(a, 0) end
        local k1 = collectgarbage("count")
        if k1 < API.gcLast then API.gcDrops, API.gcFreed = API.gcDrops + 1, API.gcFreed + (API.gcLast - k1) end
        local ms, kb = PClock() - t0, k1 - k0
        API.lastCold = { id = itemID, ms = ms, kb = kb }
        if ms >= API.SLOW_MS and API.slowCount < API.SLOW_MAX then
            API.slowCount = API.slowCount + 1
            local cached = GetItemInfo and GetItemInfo(itemID) ~= nil
            local up = (GetTime and A.loadGT) and string.format("%.0f s nach dem Laden", GetTime() - A.loadGT) or "?"
            local TR = A.TestRoutine
            local inTR = TR and (TR.running or TR.finishing)
            API.slowPending[#API.slowPending + 1] = { string.format("WorthUpTo %s: %.1f ms %+.0f KB · Speicher vorher %.1f MB · Bereinigung im Aufruf %s · %s · Item im Client %s · Lohnt-Zwischenspeicher %s · Buchungs-Index neu %s · Aufgabe %s · Testroutine %s · Teile: %s",
                tostring(itemID), ms, kb, k0 / 1024, API.gcDrops > 0 and string.format("ja (%d×, %.0f KB frei)", API.gcDrops, API.gcFreed) or "nein",
                up, cached and "ja" or "nein", (Kn and Kn.lohntVer ~= ver0) and "neu" or "gleich",
                tostring(Le and ib0 and (Le.indexBuilds - ib0) or "?"), tostring(A.currentJob or "-"), inTR and "läuft" or "nein",
                ProfText()), ms }
        end
        API.FlushSlow()
        return a, b, c, d, f
    end
    API.WorthUpTo = Safe(function(itemID, qty)
        if Provisional() then return nil end
        if not (itemID and MemoOn()) then
            if not itemID then return rawWorth(itemID, qty) end
            return MeasuredWorth(itemID, qty)
        end
        local q = math.max(1, math.floor(tonumber(qty) or 1))
        local byQ = memo.worth[itemID]
        local e = byQ and byQ[q]
        if e == nil then
            local a, b, c, d, f = MeasuredWorth(itemID, q)
            if not byQ then byQ = {}; memo.worth[itemID] = byQ end
            e = (a ~= nil) and { a, b, c, d, f } or false
            byQ[q] = e
        end
        if not e then return nil end
        return e[1], e[2], e[3], e[4], e[5]
    end)
end

function API.Flush()
    scheduled = false
    local reasons = {}
    for _, r in ipairs({ "scan", "ledger", "settings" }) do
        if pending[r] then reasons[#reasons + 1] = r; pending[r] = nil end
    end
    for _, r in ipairs(reasons) do
        for _, fn in ipairs(API.subscribers) do pcall(fn, r) end
    end
end

function API.Notify(reason)
    if #API.subscribers == 0 then return end
    pending[reason] = true
    if scheduled then return end
    scheduled = true
    if C_Timer and C_Timer.After then C_Timer.After(API.THROTTLE, API.Flush) else API.Flush() end
end

A:On("SCAN_FINISHED", function() API.Notify("scan") end)
A:On("LEDGER_CHANGED", function() API.Notify("ledger") end)
A:On("SETTINGS_CHANGED", function() API.Notify("settings") end)
