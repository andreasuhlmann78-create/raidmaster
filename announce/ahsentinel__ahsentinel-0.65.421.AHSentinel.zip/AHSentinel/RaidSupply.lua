if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Vorräte vor Raid-Abenden (FREIGABE PHASE 8 Punkt 3, Nutzer 16.11.2026 14:10; wirtschaft-forever 8.2/8.6)
--
-- 3 bis 5 Tage vor einem Raid-Termin steht in "Heute tun" EIN Hinweis:
--   "Raid in n Tagen (…): Tränke/Essen jetzt kaufen – heute x % unter dem Raid-Tag-Preis (Item −x %, …)"
-- NUR wenn der Wochentag-Effekt gemessen ist (Stufe 2 L9: Preis je Wochentag aus gerader UND ungerader Woche, ab 21 Tagen),
-- und zwar in BEIDEN Wochen-Hälften mindestens 10 % (Ln.RHYTHM_DIFF) teurer am Raid-Wochentag als am heutigen Wochentag.
-- Sonst: "noch zu wenig Daten" (ehrlich, ohne Zahl). Kauft nie etwas - nur ein Hinweis.
--
-- Termine: (1) feste Ereignisse aus wirtschaft-forever 9 (9.12.2026: Onyxia, Hyjal-Gipfel, Barrow Deeps öffnen; Hearthproof),
-- (2) über die Schnittstelle eines anderen Addons, wenn vorhanden: _G.RaidMasterAPI.UpcomingRaids() -> { { t = Unix-Zeit,
-- name = "Onyxias Hort" }, ... }. Übernommen werden NUR Zeit und Raid-Name (gekürzt) - nie Spielernamen.
-- Ein einmaliges Ereignis (Öffnung) hat keinen eigenen gemessenen Effekt; gezeigt wird der gemessene Wochentag-Effekt.
-- Nur lesen: db.learn.rhythm (Stufe 2), Marktwert. Testroutine: RS.testEvents / RS.testRhythm / RS.testItems.
-- ============================================================
local A = AHAnalyzerPro
local string = A.SafeString or string          -- AHS-OVF1: string.format ohne 32-Bit-Überlauf (gleicher Text darunter)
if not (A and A.On) then return end
local L = A.L

local RS = {}
A.RaidSupply = RS

RS.DAYS_MIN, RS.DAYS_MAX = 3, 5
RS.MAX_ITEMS = 3
RS.NAME_MAX = 40
-- feste Termine (Datum Ortszeit); Name ist ein Locale-Schlüssel
RS.EVENTS = {
    { day = "2026-12-09", name = "Onyxia, Hyjal-Gipfel und Barrow Deeps öffnen" },
}
-- "Tränke/Essen": Verbrauchsgüter (classID 0) Trank 1, Elixier 2, Fläschchen 3, Essen & Trinken 5, Gegenstandsverbesserung 6
RS.SUBCLASS = { [1] = true, [2] = true, [3] = true, [5] = true, [6] = true }

local DAY = 86400
local function DayKey(t) return date("%Y-%m-%d", t) end
-- Wochentag 1 = Montag … 7 = Sonntag (wie Stufe 2 L9)
local function Wday(t)
    local wd = tonumber(date("%w", t)) or 0
    return (wd == 0) and 7 or wd
end

-- Termine der nächsten Tage: { { day = "JJJJ-MM-TT", name = "…" }, ... } (feste + Schnittstelle, ohne Doppel)
function RS:Events()
    if self.testEvents then return self.testEvents end
    local out, seen = {}, {}
    for _, e in ipairs(self.EVENTS) do
        out[#out + 1] = { day = e.day, name = L[e.name] }
        seen[e.day] = true
    end
    local api = A:Global("RaidMasterAPI")                                 -- TAINT-1 (0.65.330): Test ersetzt nur apiOverride
    local fn = type(api) == "table" and api.UpcomingRaids
    if type(fn) == "function" then
        local ok, list = pcall(fn)
        if ok and type(list) == "table" then
            for i = 1, math.min(#list, 20) do
                local e = list[i]
                local t = type(e) == "table" and tonumber(e.t)
                if t and t > 0 then
                    local day = DayKey(t)
                    local name = type(e.name) == "string" and e.name:sub(1, self.NAME_MAX) or L["Raid"]
                    if not seen[day] then
                        out[#out + 1] = { day = day, name = name }
                        seen[day] = true
                    end
                end
            end
        end
    end
    return out
end

-- nächster Termin in 3 bis 5 Tagen: Termin, Tage bis dahin, Wochentag des Termins
function RS:Next(now)
    now = now or time()
    local base = A:DayStart(now) + DAY / 2                     -- Mittag: Sommer-/Winterzeit verschiebt nie den Tag
    local byDay = {}
    for _, e in ipairs(self:Events()) do byDay[e.day] = byDay[e.day] or e end
    for k = self.DAYS_MIN, self.DAYS_MAX do
        local t = base + k * DAY
        local e = byDay[DayKey(t)]
        if e then return e, k, Wday(t), t end
    end
    return nil
end

-- gemessene Wochentag-Preise eines Items (gerade / ungerade Woche) oder nil
local function Slots(str)
    local t = {}
    local i = 0
    for x in ((str or "") .. ","):gmatch("([^,]*),") do i = i + 1; t[i] = tonumber(x) end
    return t
end
function RS:Week(itemID, now)
    local Ln = A.Learn
    if not (Ln and Ln:On()) then return nil end
    local str
    if self.testRhythm then str = self.testRhythm[itemID]
    else
        local db = Ln:Data()
        str = db and db.rhythm and db.rhythm[itemID]
    end
    if type(str) ~= "string" then return nil end
    local first, _, _, we, wo = str:match("^(%d*);([^;]*);([^;]*);([^;]*);([^;]*)$")
    first = tonumber(first)
    if not first or math.floor((now or time()) / DAY) - first < Ln.RHYTHM_DAYS then return nil end
    return Slots(we), Slots(wo)
end
-- Effekt "Raid-Wochentag teurer als heute": nur wenn in BEIDEN Wochen-Hälften ≥ RHYTHM_DIFF; Rückgabe Raid-Tag-Preis (Mittel)
function RS:Effect(itemID, wdRaid, wdToday, now)
    local we, wo = self:Week(itemID, now)
    if not we then return nil end
    local diff = A.Learn.RHYTHM_DIFF
    for _, h in ipairs({ we, wo }) do
        local r, d = h[wdRaid], h[wdToday]
        if not (r and d and r > 0 and d > 0) then return nil end
        if (r - d) / r < diff then return nil end
    end
    return math.floor((we[wdRaid] + wo[wdRaid]) / 2 + 0.5)
end

-- Items der Raid-Vorlage (/ahs raid, Comfort RAID_SETS) - werden im Rhythmus (L9) immer mitgemessen
function RS:TrackIDs()
    local K = A.Comfort
    local key = K and K.RaidSetKey and K:RaidSetKey()
    local set = key and K.RAID_SETS and K.RAID_SETS[key]
    local out = {}
    for _, e in ipairs(set or {}) do out[#out + 1] = e[1] end
    return out
end
-- in Frage kommende Items: Raid-Vorlage + Tränke/Essen mit Rhythmus-Daten
function RS:Items()
    if self.testItems then return self.testItems end
    local out, seen = {}, {}
    for _, id in ipairs(self:TrackIDs()) do if not seen[id] then seen[id] = true; out[#out + 1] = id end end
    local Ln = A.Learn
    local db = Ln and Ln:Data()
    if db and db.rhythm and GetItemInfo then
        for id in pairs(db.rhythm) do
            if not seen[id] then
                local ok, _, _, _, _, _, _, _, _, _, _, _, classID, sub = pcall(GetItemInfo, id)
                if ok and classID == 0 and self.SUBCLASS[sub] then seen[id] = true; out[#out + 1] = id end
            end
        end
    end
    table.sort(out)
    return out
end

-- Hinweis: nil (kein Termin in 3–5 Tagen) oder { text, items = { {id, pct, raidPrice, now} }, measured = true/false }
function RS:Hint(now)
    now = now or time()
    local e, k, wdRaid = self:Next(now)
    if not e then return nil end
    local wdToday = Wday(A:DayStart(now) + DAY / 2)
    local items = {}
    if wdRaid ~= wdToday then
        for _, id in ipairs(self:Items()) do
            local raidPrice = self:Effect(id, wdRaid, wdToday, now)
            local cur = raidPrice and A:GetMarketValue(id)
            if cur and cur > 0 and cur < raidPrice then
                items[#items + 1] = { id = id, pct = math.floor((raidPrice - cur) / raidPrice * 100 + 0.5), raidPrice = raidPrice, now = cur }
            end
        end
    end
    table.sort(items, function(a, b) if a.pct ~= b.pct then return a.pct > b.pct end return a.id < b.id end)
    for i = #items, self.MAX_ITEMS + 1, -1 do items[i] = nil end
    local when = string.format(L["Raid in %d Tagen (%s)"], k, e.name)
    if #items == 0 then
        return { measured = false, items = items, days = k, text = when .. ": " .. L["Tränke/Essen – noch zu wenig Daten (der Preis je Wochentag ist erst nach 3 Wochen gemessen)."] }
    end
    local parts = {}
    for _, it in ipairs(items) do
        parts[#parts + 1] = string.format("%s −%d %%", A:GetItemName(it.id) or ("#" .. it.id), it.pct)
    end
    return { measured = true, items = items, days = k,
        text = when .. ": " .. string.format(L["Tränke/Essen jetzt kaufen – heute %d %% unter dem Raid-Tag-Preis"], items[1].pct)
            .. " (" .. table.concat(parts, ", ") .. ")." }
end

-- Zeile für "Heute tun" (Hinweis ohne Knopf, steht unten)
function RS:TodayRow(now)
    local ok, h = pcall(self.Hint, self, now)
    if not (ok and h) then return nil end
    return { key = "raidsupply", kind = "raidsupply", gold = 0, capital = 0, tip = true, text = h.text, where = "",
        measured = h.measured }
end
