if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - G10 ECHTE VERKAUFSCHANCE (Auftrag des Nutzers 21.11.2026 16:35, Prio 1), Teil A: eigene Daten
--
-- Quelle ist der Post-Scan (Mailer.lua, Dauerregel 15:44): jeder Brief sagt sicher "verkauft", "abgelaufen" oder "abgebrochen".
-- Beim Einstellen merkt AHSentinel Preis und Preisabstand zum günstigsten fremden Angebot (frische Preisprüfung). Kommt der Brief,
-- wird er dem ältesten passenden Einstellen zugeordnet (verkauft: gleicher Stückpreis; zurück: ältestes Einstellen des Items).
-- "Verschwunden" aus Scans zählt hier nie als verkauft. Angezeigt wird erst ab MIN_CASES Fällen im selben Preisabstand.
-- Teil B (Gilde, verdichtet ohne Namen) folgt mit dem Sync.
-- ============================================================
AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local string = A.SafeString or string          -- AHS-OVF1: string.format ohne 32-Bit-Überlauf (gleicher Text darunter)
local L = A.L

local SO = {}
A.SaleOutcome = SO
SO.MIN_CASES = 5              -- erst ab so vielen Fällen im selben Preisabstand eine Aussage
SO.KEEP = 60                  -- Ergebnisse je Item (die neuesten)
SO.PENDING_DAYS = 4           -- Einstellen ohne Brief nach so vielen Tagen verwerfen (Laufzeit höchstens 48 Std. + Post)

function SO:Store()
    if A:InTestRoutine() and not self.testDB then return nil end
    local db = self.testDB or A.db
    if not db then return nil end
    db.saleObs = db.saleObs or { pending = {}, res = {} }
    db.saleObs.pending = db.saleObs.pending or {}
    db.saleObs.res = db.saleObs.res or {}
    return db.saleObs
end
local function Now() return (A.testNow) or time() end
-- Preisabstand in ganzen Prozent zum günstigsten fremden Angebot (nil = unbekannt)
function SO.Gap(unit, lo)
    if not (unit and lo and lo > 0) then return nil end
    return math.floor((unit / lo - 1) * 100 + 0.5)
end
-- Gruppen: am/unter dem günstigsten, 1–5 %, 6–15 %, über 15 % darüber
function SO.Bucket(gap)
    if gap == nil then return nil end
    if gap <= 0 then return 1 elseif gap <= 5 then return 2 elseif gap <= 15 then return 3 end
    return 4
end
SO.BUCKET_TEXT = { "am/unter dem günstigsten Angebot", "1–5 Prozent darüber", "6–15 Prozent darüber", "mehr als 15 Prozent darüber" }

-- G17-a (Messauftrag, Supervisor 23.11. 07:46): Einzahlung je Auktion beim Einstellen merken und mit der Verkaufs-Rechnung paaren
-- (Beleg Teilverkauf/Erstattung, wirtschaft-forever §1). Ergebnis nur im Testbericht (T997), höchstens DEP_KEEP Paare.
SO.DEP_KEEP = 200
function SO:NotePosted(itemID, unit, qty, lo, deposit, auctions)
    local st = self:Store()
    if not (st and itemID and unit and unit > 0) then return end
    local p = st.pending[itemID] or {}
    st.pending[itemID] = p
    local now = Now()
    -- alte Einträge ohne Brief verwerfen
    for k = #p, 1, -1 do if now - (p[k].t or 0) > self.PENDING_DAYS * 86400 then table.remove(p, k) end end
    p[#p + 1] = { t = now, u = unit, q = math.max(1, qty or 1), lo = lo,
        dep = (type(deposit) == "number" and deposit > 0) and deposit or nil, au = math.max(1, auctions or 1), q0 = math.max(1, qty or 1) }
end
-- Paare für den Testbericht: eingestellt (Einzahlung gesamt, Auktionen, Menge) gegen Rechnung (Einzahlung, Menge)
function SO:DepPairs()
    local st = self:Store()
    if not st then return {} end
    st.depPairs = st.depPairs or {}
    return st.depPairs
end
function SO:DepPairLines()
    local out, n, same, prop, other = {}, 0, 0, 0, 0
    for _, s in ipairs(self:DepPairs()) do
        local t, id, dep, au, q0, inv, cnt = s:match("^(%d+);(%d+);(%d+);(%d+);(%d+);(%d+);(%d+)$")
        if t then
            n = n + 1
            dep, au, q0, inv, cnt = tonumber(dep), tonumber(au), tonumber(q0), tonumber(inv), tonumber(cnt)
            local perAu = dep / au
            local propV = math.floor(dep * cnt / q0 + 0.5)
            if inv == math.floor(perAu + 0.5) or inv == dep then same = same + 1
            elseif math.abs(inv - propV) <= 1 then prop = prop + 1
            else other = other + 1; if #out < 8 then out[#out + 1] = string.format("Item %s: eingestellt %d (%d Auktionen, %d Stück), Rechnung %d bei %d Stück", id, dep, au, q0, inv, cnt) end end
        end
    end
    table.insert(out, 1, string.format("Einzahlung beim Einstellen vs. Rechnung (G17-a): %d Paare · gleich je Auktion %d · anteilig %d · anders %d", n, same, prop, other))
    return out
end

local function NameToID(st, name)
    if not name then return nil end
    for id in pairs(st.pending) do if A:GetItemName(id) == name then return id end end
    return nil
end
-- kind: "sold" | "expired" | "cancelled"; total = Gesamtpreis (nur verkauft)
function SO:NoteResult(kind, itemID, name, count, total, invDeposit)
    local st = self:Store()
    if not st then return end
    itemID = itemID or NameToID(st, name)
    if not itemID then return end
    count = math.max(1, count or 1)
    local unit = (kind == "sold" and total and total > 0) and math.floor(total / count + 0.5) or nil
    local p = st.pending[itemID] or {}
    local pick
    for k, e in ipairs(p) do
        if kind ~= "sold" or not unit or math.abs((e.u or 0) - unit) <= 1 then pick = k; break end
    end
    local e = pick and p[pick]
    local now = Now()
    local rec = { t = now, o = kind == "sold" and "v" or (kind == "expired" and "a" or "b"), n = count }
    if e then
        rec.g = SO.Gap(e.u, e.lo)
        rec.u = e.u
        if kind == "sold" then rec.d = now - (e.t or now) end
        if kind == "sold" and e.dep and type(invDeposit) == "number" then                    -- G17-a
            local dp = self:DepPairs()
            dp[#dp + 1] = string.format("%d;%d;%d;%d;%d;%d;%d", now, itemID, e.dep, e.au or 1, e.q0 or e.q or 1, math.floor(invDeposit), count)
            while #dp > self.DEP_KEEP do table.remove(dp, 1) end
        end
        e.q = (e.q or 1) - count
        if e.q <= 0 then table.remove(p, pick) end
    else
        rec.u = unit
    end
    local r = st.res[itemID] or {}
    st.res[itemID] = r
    r[#r + 1] = string.format("%d;%s;%d;%s;%s;%s", rec.t, rec.o, rec.n, rec.g and tostring(rec.g) or "", rec.d and tostring(rec.d) or "", rec.u and tostring(rec.u) or "")
    while #r > self.KEEP do table.remove(r, 1) end
end
local function Parse(s)
    local t, o, n, g, d, u = s:match("^(%d+);(%a);(%d+);(%-?%d*);(%d*);(%d*)$")
    if not t then return nil end
    return { t = tonumber(t), o = o, n = tonumber(n), g = tonumber(g), d = tonumber(d), u = tonumber(u) }
end
SO.Parse = Parse
-- Auswertung für einen Preis: gleiche Abstands-Gruppe; zurück nil (zu wenig Fälle) oder { n, sold, hours (Median), bucket }
function SO:Stats(itemID, unit, lo)
    local st = self:Store()
    local r = st and st.res[itemID]
    if not r then return nil end
    local b = SO.Bucket(SO.Gap(unit, lo))
    if not b then return nil end
    local n, sold, ds = 0, 0, {}
    for _, s in ipairs(r) do
        local x = Parse(s)
        if x and SO.Bucket(x.g) == b then
            n = n + x.n
            if x.o == "v" then sold = sold + x.n; if x.d then ds[#ds + 1] = x.d end end
        end
    end
    if n < self.MIN_CASES then return nil, n end
    table.sort(ds)
    local med = #ds > 0 and ds[math.floor((#ds + 1) / 2)] or nil
    return { n = n, sold = sold, hours = med and math.floor(med / 3600 + 0.5) or nil, hoursN = #ds, bucket = b }
end
function SO:Text(itemID, unit, lo)
    local s, n = self:Stats(itemID, unit, lo)
    if not s then return nil, n end
    local t = string.format(L["Bisher bei %s: %d von %d verkauft"], L[SO.BUCKET_TEXT[s.bucket]], s.sold, s.n)
    -- G10-b (Prüfung 23.11. 07:46, "schätzen verboten"): Median gemessener Fälle -> ohne "~", mit Fallzahl
    if s.hours then t = t .. string.format(L[", meist nach %d Std. (%d Fälle)"], s.hours, s.hoursN or 0) end
    if s.guild and s.guild > 0 then t = t .. string.format(L[" (davon Gilde %d)"], s.guild) end
    return t
end

-- ------------------------------------------------------------
-- G10 Teil B (Auftrag 21.11. 16:35): Verkaufschance der Gilde – verdichtet je Item und Abstands-Gruppe (Fälle, verkauft), ohne Namen
-- (Konto-Kennung wie G13), nur gleicher Markt (Markt-Tag), je Konto ersetzt (nie doppelt). Nachricht "V:<Zeit>:<Tag>:@konto;id,b,n,v;…".
-- Die Dauer bis zum Verkauf bleibt eigen (nur eigene Fälle zeigen "meist nach ~x Std." – nichts geschätzt).
-- ------------------------------------------------------------
SO.SHARE_DAYS = 30
SO.SHARE_MAX_AGE = 30 * 86400
function SO:Aggregate()
    local st = self:Store()
    local out = {}
    if not st then return out end
    local from = Now() - self.SHARE_DAYS * 86400
    for id, r in pairs(st.res) do
        for _, s in ipairs(r) do
            local x = Parse(s)
            local b = x and x.t >= from and SO.Bucket(x.g)
            if b then
                out[id] = out[id] or {}
                local c = out[id][b] or { n = 0, v = 0 }
                out[id][b] = c
                c.n = c.n + x.n
                if x.o == "v" then c.v = c.v + x.n end
            end
        end
    end
    return out
end
function SO:Broadcast()
    local S = A.Sync
    if not (S and S.IsEnabled and S:IsEnabled() and S:IsConnected() and S.SendNow and S.Enc and A.MarketTag) then return false end
    if A:InTestRoutine() then return false end
    local D = A.Disenchant
    local acc = D and D.AccountId and D:AccountId() or "0"
    pcall(self.BroadcastCal, self)                                          -- G10 Eichung: Zähler je Item-Gruppe
    -- PM1-c: Formatkennung "f2" als erster Teil jeder Nachricht (alte Clients überspringen den Teil, er passt in kein Muster)
    local head = "V:" .. S.Enc(time()) .. ":" .. A:MarketTag() .. ":@" .. acc .. ";" .. SO.FMT .. ";"
    local chunk, size, sent = {}, #head, 0
    for id, bs in pairs(self:Aggregate()) do
        for b, c in pairs(bs) do
            local p = S.Enc(id) .. "," .. b .. "," .. S.Enc(c.n) .. "," .. S.Enc(c.v)
            if size + #p + 1 > S.MAX_MSG and #chunk > 0 then
                S.SendNow(head .. table.concat(chunk, ";")); sent = sent + 1
                chunk, size = {}, #head
            end
            chunk[#chunk + 1] = p
            size = size + #p + 1
        end
    end
    if #chunk > 0 then S.SendNow(head .. table.concat(chunk, ";")); sent = sent + 1 end
    return sent > 0
end
-- PM1-c (Prüfung 23.11. 06:26): Versionen ≤ 0.65.375 senden Verkaufsfälle/Eichung mit der Menge aus Rechnungsfeld 10 (etaMin).
-- Sendungen ab 0.65.383 tragen die Formatkennung FMT; Sendungen ohne Kennung werden verworfen (kein Fehler, kein Mischen).
SO.FMT = "f2"
function SO.HasFmt(data)
    return type(data) == "string" and (";" .. data .. ";"):find(";" .. SO.FMT .. ";", 1, true) ~= nil
end
-- einmalig: gespeicherte Gilden-Daten ohne Kennung verwerfen (Verkaufsfälle, Eichung); Rechnungen: Mailer
function SO:DropOldShared()
    local db = A.db
    if not db then return 0, 0 end
    local n1, n2 = 0, 0
    for k, r in pairs(db.saleShared or {}) do if not (type(r) == "table" and r.f == SO.FMT) then db.saleShared[k] = nil; n1 = n1 + 1 end end
    for k, r in pairs(db.calShared or {}) do if not (type(r) == "table" and r.f == SO.FMT) then db.calShared[k] = nil; n2 = n2 + 1 end end
    self.calCache = nil
    return n1, n2
end
-- einmalig beim ersten Start ab 0.65.383: Eichungs-Beginn setzen (G10-a), alte Gilden-Daten ohne Kennung verwerfen (PM1-c)
A:On("READY", function()
    local db = A.db
    if not db or db.fixPM1c then return end
    db.calFrom = db.calFrom or time()
    local n1, n2 = SO:DropOldShared()
    local n3 = 0
    for k, r in pairs(db.invoiceShared or {}) do if not (type(r) == "table" and r.f == SO.FMT) then db.invoiceShared[k] = nil; n3 = n3 + 1 end end
    db.fixPM1c = 1
    local txt = string.format("Gilden-Daten ohne Formatkennung verworfen: Verkaufsfälle %d Konten, Eichung %d Konten, Rechnungen %d Konten · Eichung zählt ab %s",
        n1, n2, n3, date("%d.%m. %H:%M", db.calFrom))
    A:NoteFix("PM1c", txt, { verkaufsKonten = n1, eichungKonten = n2, rechnungKonten = n3 })
    if A.Diag then pcall(A.Diag.Add, A.Diag, "PM1C-BEREINIGT", txt) end
end)
-- Empfang: rest = "<Tag>:@konto;f2;…"
function SO:HandleShared(t, rest)
    local S = A.Sync
    local db = A.db
    if not (S and S.Dec and db and type(rest) == "string") then return 0 end
    local tag, body = rest:match("^(%w+):(.*)$")
    if not tag or tag ~= A:MarketTag() then return 0 end
    local acc, data = (body or ""):match("^@(%w+);(.*)$")
    if not acc then return 0 end
    if not SO.HasFmt(data) then return 0 end                                   -- PM1-c: alte Version
    local D = A.Disenchant
    if D and D.AccountId and acc == D:AccountId() then return 0 end
    local now = time()
    if not t or t > now + 300 or t < now - self.SHARE_MAX_AGE then return 0 end
    db.saleShared = db.saleShared or {}
    local rec = db.saleShared[acc]
    -- eine Sendung kann aus mehreren Nachrichten bestehen (gleiche Zeit t) -> neue Zeit ersetzt, gleiche Zeit ergänzt
    if not rec or (rec.t or 0) < t or rec.f ~= SO.FMT then rec = { t = t, items = {}, f = SO.FMT }; db.saleShared[acc] = rec
    elseif rec.t > t then return 0 end
    local taken = 0
    for part in data:gmatch("[^;]+") do
        local a, b, c, d = part:match("^(%w+),(%d),(%w+),(%w+)$")
        local id, bk, n, v = S.Dec(a or ""), tonumber(b), S.Dec(c or ""), S.Dec(d or "")
        if id and bk and bk >= 1 and bk <= 4 and n and v and n > 0 and n < 100000 and v >= 0 and v <= n then
            rec.items[id] = rec.items[id] or {}
            rec.items[id][bk] = { n = n, v = v }
            taken = taken + 1
        end
    end
    -- alte Konten vergessen
    for k, r in pairs(db.saleShared) do if (r.t or 0) < now - self.SHARE_MAX_AGE then db.saleShared[k] = nil end end
    return taken
end
-- Gilden-Fälle derselben Gruppe dazuzählen (Stats bleibt die eigene Auswertung)
local OwnStats = SO.Stats
function SO:Stats(itemID, unit, lo)
    local own, nOwn = OwnStats(self, itemID, unit, lo)
    local b = SO.Bucket(SO.Gap(unit, lo))
    local sh = (not self.testDB) and A.db and A.db.saleShared
    local gn, gv = 0, 0
    if b and sh then
        for _, rec in pairs(sh) do
            local c = rec.items and rec.items[itemID] and rec.items[itemID][b]
            if c then gn, gv = gn + c.n, gv + c.v end
        end
    end
    if own then
        if gn > 0 then own.n, own.sold, own.guild = own.n + gn, own.sold + gv, gn end
        return own
    end
    local total = (nOwn or 0) + gn
    if b and total >= self.MIN_CASES and gn > 0 then
        -- eigene Fälle (unter der Mindestzahl) und Gilde zusammen; Dauer nur aus eigenen Fällen -> hier keine
        local st = self:Store()
        local ov = 0
        for _, s in ipairs((st and st.res[itemID]) or {}) do
            local x = Parse(s)
            if x and SO.Bucket(x.g) == b and x.o == "v" then ov = ov + x.n end
        end
        return { n = total, sold = ov + gv, bucket = b, guild = gn }
    end
    return nil, total
end

-- 0.65.368 hatte Gildenauktionen (G12) gespeichert - Entscheid 21.11. 18:28 "nein": gespeicherte Reste entfernen
A:On("READY", function() if A.db then A.db.guildAuctions = nil end end)

-- ------------------------------------------------------------
-- G10 Eichung (Entscheid des Nutzers 21.11. 18:28): NUR EIN Wert sichtbar. Je Item-Gruppe (Fc:Group) rechnet AHS wie bisher
-- (VS:CancelFactor = Anteil "verkauft" der eigenen vorzeitig verschwundenen Auktionen aus den Vollscans), bis >= 30 echte Fälle
-- aus dem Post-Scan vorliegen (eigene + Gilde verdichtet). Dann nimmt genau diese Gruppe den Wert aus echten Verkäufen:
-- verkauft / (verkauft + abgebrochen), je Brief ein Fall (eine Auktion), letzte 30 Tage. Abgelaufen zählt nicht (der Faktor
-- sagt, wie viel von "vorzeitig weg" verkauft ist - abgelaufen ist nie vorzeitig weg). Grenzen wie bisher 0,2 .. 1.
-- Geteilt: "C:<Zeit>:<Markt-Tag>:@konto;Gruppe,verkauft,abgebrochen;…" (je Konto ersetzt, keine Namen, keine Items).
-- ------------------------------------------------------------
SO.CAL_MIN, SO.CAL_DAYS, SO.CAL_TTL = 30, 30, 600
-- G10-a (Prüfung 23.11. 07:46): Le:FixPM1 verwarf die Fälle "verkauft", liess "abgebrochen" stehen -> Eichung zu tief. Gezählt
-- werden nur Fälle ab db.calFrom (erster Start ab 0.65.383, also nach der PM1-Bereinigung) - alle Arten gleich, nichts gelöscht.
function SO:CalFrom()
    local db = self.testDB or A.db
    return db and tonumber(db.calFrom) or 0
end
function SO:OwnGroupCounts()
    local st = self:Store()
    local out = {}
    if not st then return out end
    local Fc = A.Forecast
    local from = math.max(Now() - self.CAL_DAYS * 86400, self:CalFrom())
    for id, r in pairs(st.res) do
        local g
        for _, s in ipairs(r) do
            local x = Parse(s)
            if x and x.t >= from and (x.o == "v" or x.o == "b") then
                g = g or (Fc and Fc.Group and Fc:Group(id)) or "misc"
                local c = out[g] or { s = 0, c = 0 }
                out[g] = c
                if x.o == "v" then c.s = c.s + 1 else c.c = c.c + 1 end
            end
        end
    end
    return out
end
function SO:CalShared()
    if self.calSharedTest then return self.calSharedTest end
    return A.db and A.db.calShared
end
function SO:BroadcastCal()
    local S = A.Sync
    if not (S and S.IsEnabled and S:IsEnabled() and S:IsConnected() and S.SendNow and S.Enc and A.MarketTag) then return false end
    if A:InTestRoutine() or (A.Simulated and A:Simulated()) then return false end
    local parts = {}
    for g, c in pairs(self:OwnGroupCounts()) do parts[#parts + 1] = g .. "," .. S.Enc(c.s) .. "," .. S.Enc(c.c) end
    if #parts == 0 then return false end
    local D = A.Disenchant
    S.SendNow("C:" .. S.Enc(time()) .. ":" .. A:MarketTag() .. ":@" .. (D and D.AccountId and D:AccountId() or "0") .. ";" .. SO.FMT .. ";" .. table.concat(parts, ";"))
    return true
end
function SO:HandleCal(t, rest)
    local S = A.Sync
    if not (S and S.Dec and type(rest) == "string") then return -1 end
    local tag, body = rest:match("^(%w+):(.*)$")
    if not tag or tag ~= A:MarketTag() then return -1 end
    local acc, data = (body or ""):match("^@(%w+);(.*)$")
    if not acc then return -1 end
    if not SO.HasFmt(data) then return -1 end                                  -- PM1-c / G10-a: Eichung alter Versionen verwerfen
    local D = A.Disenchant
    if D and D.AccountId and acc == D:AccountId() then return -1 end
    local now = time()
    if not t or t > now + 300 or t < now - self.CAL_DAYS * 86400 then return -1 end
    local sh = self.calSharedTest
    if not sh then
        if not A.db then return -1 end
        A.db.calShared = A.db.calShared or {}
        sh = A.db.calShared
    end
    local rec = sh[acc]
    if rec and rec.f == SO.FMT and (rec.t or 0) >= t then return 0 end     -- gleicher oder älterer Stand: nichts (eine Nachricht je Stand)
    rec = { t = t, g = {}, f = SO.FMT }
    local taken = 0
    for part in data:gmatch("[^;]+") do
        local g, a, b = part:match("^(%a[%w]*),(%w+),(%w+)$")
        local sv, cv = S.Dec(a or ""), S.Dec(b or "")
        if g and sv and cv and sv + cv < 100000 then rec.g[g] = { s = sv, c = cv }; taken = taken + 1 end
    end
    sh[acc] = rec
    for k, r in pairs(sh) do if (r.t or 0) < now - self.CAL_DAYS * 86400 then sh[k] = nil end end
    self.calCache = nil
    return taken
end
-- echter Faktor einer Gruppe: Faktor (nil unter CAL_MIN), Fälle, verkauft
function SO:RealCancelFactor(g)
    if self.CAL_OFF then return nil, 0, 0 end                      -- Vergleich vorher/nachher (Testroutine T958)
    local now = time()
    local c = self.calCache
    if not c or now - c.t > self.CAL_TTL or self.testDB or self.calSharedTest then
        c = { t = now, by = {} }
        for gg, x in pairs(self:OwnGroupCounts()) do c.by[gg] = { s = x.s, c = x.c } end
        for _, rec in pairs(self:CalShared() or {}) do
            for gg, x in pairs(rec.g or {}) do
                local y = c.by[gg] or { s = 0, c = 0 }
                c.by[gg] = y
                y.s, y.c = y.s + x.s, y.c + x.c
            end
        end
        if not (self.testDB or self.calSharedTest) then self.calCache = c end
    end
    local x = c.by[g or "misc"]
    local n = x and (x.s + x.c) or 0
    if n < self.CAL_MIN then return nil, n, x and x.s or 0 end
    return math.max(0.2, math.min(1, x.s / n)), n, x.s
end
