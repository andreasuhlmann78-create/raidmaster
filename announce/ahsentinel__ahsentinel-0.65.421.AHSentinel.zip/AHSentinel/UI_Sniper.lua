if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.9 - Tab "Sniper"
-- Ziele mit Preis, Menge, Budget, Seltenheit, Itemlevel und Stufe.
-- Sniper-Modus AN: sucht selbstständig, Kauf per Mausrad / eigener Taste.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local string = A.SafeString or string          -- AHS-OVF1: string.format ohne 32-Bit-Überlauf (gleicher Text darunter)
local CreateFrame, C_Timer = A.OwnCreateFrame or CreateFrame, A.OwnTimer or C_Timer      -- VS-BILD-2 (0.65.320): eigene Skripte/Zeitgeber je Bild messen (nur während einer Vollscan-Messung)
local L = A.L
local UI = A.UI
local C = UI.C

local function Num(edit)
    local n = tonumber((string.gsub(edit:GetText() or "", ",", ".")))
    if n then return math.floor(n) end
    return nil
end

-- ------------------------------------------------------------
-- Fenster "Taste drücken" (eigene Taste wählen)
-- ------------------------------------------------------------
local capture

local IGNORE_KEYS = {
    LSHIFT = true, RSHIFT = true, LCTRL = true, RCTRL = true, LALT = true, RALT = true,
    UNKNOWN = true, LMETA = true, RMETA = true,
}

local function Mods()
    local m = ""
    if IsAltKeyDown and IsAltKeyDown() then m = m .. "ALT-" end
    if IsControlKeyDown and IsControlKeyDown() then m = m .. "CTRL-" end
    if IsShiftKeyDown and IsShiftKeyDown() then m = m .. "SHIFT-" end
    return m
end

local function OpenCapture(onDone)
    if not capture then
        capture = CreateFrame("Frame", "AHAnalyzerProKeyCapture", UIParent)
        capture:SetSize(380, 130)
        capture:SetPoint("CENTER", 0, 120)
        capture:SetFrameStrata("FULLSCREEN_DIALOG")
        UI:Box(capture, C.panel, C.accent)
        local title = UI:Label(capture, L["Eigene Kauf-Taste wählen"], "GameFontNormalLarge", C.accent)
        title:SetPoint("TOP", 0, -14)
        capture.text = UI:Label(capture, L["Drücke jetzt eine Taste, die mittlere Maustaste,\nMaustaste 4/5 oder dreh das Mausrad.\nShift / Strg / Alt dazu ist möglich.  ESC = Abbrechen"], "GameFontHighlightSmall", C.text)
        capture.text:SetPoint("TOP", title, "BOTTOM", 0, -10)
        capture.text:SetJustifyH("CENTER")
        capture.error = UI:Label(capture, "", "GameFontHighlightSmall", C.red)
        capture.error:SetPoint("BOTTOM", 0, 12)

        capture:EnableKeyboard(true)
        capture:EnableMouse(true)
        capture:EnableMouseWheel(true)
        if capture.SetPropagateKeyboardInput then capture:SetPropagateKeyboardInput(false) end

        local function finish(key)
            capture:Hide()
            if key and capture.onDone then capture.onDone(key) end
        end

        capture:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then finish(nil) return end
            if IGNORE_KEYS[key] then return end
            finish(Mods() .. key)
        end)
        capture:SetScript("OnMouseWheel", function(self, delta)
            finish(Mods() .. "MOUSEWHEEL")
        end)
        capture:SetScript("OnMouseDown", function(self, button)
            if button == "LeftButton" or button == "RightButton" then
                self.error:SetText(L["Linke/rechte Maustaste geht nicht - bitte eine andere wählen."])
                return
            end
            local map = { MiddleButton = "BUTTON3", Button4 = "BUTTON4", Button5 = "BUTTON5" }
            if map[button] then finish(Mods() .. map[button]) end
        end)
    end
    capture.onDone = onDone
    capture.error:SetText("")
    capture:Show()
end
A.UI.OpenKeyCapture = OpenCapture

-- gefangene Taste -> Liste von Belegungen
local function KeyToBinds(key)
    local mods, base = key:match("^(.*%-)(.-)$")
    if not base or base == "" then mods, base = "", key end
    if base == "MOUSEWHEEL" then
        return { mods .. "MOUSEWHEELUP", mods .. "MOUSEWHEELDOWN" }
    end
    return { key }
end
A.UI.KeyToBinds = KeyToBinds

-- ------------------------------------------------------------
-- Tab
-- ------------------------------------------------------------
local function TargetTooltipLines(e, tt)          -- H4, D2, D3
    local Sn = A.Sniper
    local t = e.target
    if e.filter and e.filter ~= L["alle"] then tt:AddLine(L["Filter: "] .. e.filter, 0.8, 0.8, 0.8) end
    if t then tt:AddLine(Sn:ProgressText(t), 0.9, 0.9, 0.9, true) end                    -- TB189-3: ganze Zeile
    local wnT = t and Sn.WayNote and Sn:WayNote(t)                                         -- UI-CLEAN1 (D, 0.65.329): Weg-Hinweis hier
    if wnT then tt:AddLine(wnT, 0.6, 0.6, 0.6, true) end
    local ck = e.key and Sn.CheckedText and Sn:CheckedText(e.key)                        -- TB196-2: "geprüft vor …" im Tooltip
    if ck then tt:AddLine(ck, 0.6, 0.6, 0.6) end
    local cold = e.key and Sn.ColdText and Sn:ColdText(e.key)                            -- SN-RUHE1 (e)
    if cold then tt:AddLine(cold, 0.6, 0.6, 0.6, true) end
    -- SN2115d (Nutzer 21:21 "die Rechnerei interessiert keiner"): keine Rechen-Zeile "Mit … Budget kauft der
    -- Sniper höchstens …" mehr (Sn:BudgetPieces bleibt intern für Testbericht/Diagnose)
    if t and Sn:BudgetUsedUp(t) and (t.bought or 0) < (t.qty or 0) then
        tt:AddLine(Sn:BudgetText(t), 1, 0.8, 0, true)
    end
    if t and t.itemID and e.paused then                                                  -- SN1951b
        tt:AddLine(Sn:PauseText(t.itemID, true) or e.paused, 1, 0.6, 0.2, true)
        tt:AddLine(L["Knopf „jetzt fortsetzen“ sucht sofort wieder."], 0.8, 0.8, 0.8, true)
    end
    if e.overValue and e.reagent then
        tt:AddLine(L["Zutat für deine Rezepte – Gewinn siehe Gewinn-Fenster"], 0.6, 0.6, 0.6, true)             -- SN-B3
    elseif e.overValue then
        tt:AddLine(string.format(L["Max über Verkaufswert – jeder Kauf verliert ca. %s/Stück"], A:FormatMoney(e.overValue)), 1, 0.8, 0, true)
    elseif e.overLimit and t then
        local txt = Sn:OverLimitText(t, e.overLimit)                                      -- MU1-3
        if txt then
            tt:AddLine(txt, 1, 0.8, 0, true)
            tt:AddLine(L["Knopf „Max folgt Lohnt bis“ stellt das Ziel um."], 0.8, 0.8, 0.8, true)
        end
    end
    if e.overLimit and e.overValue then
        tt:AddLine(L["Knopf „Max folgt Lohnt bis“ stellt das Ziel um."], 0.8, 0.8, 0.8, true)               -- MU1-3
    end
    if (e.hitN or 0) > 0 then
        tt:AddLine(string.format(L["Treffer %d · gekauft %d (%d %%)"], e.hitN, e.boughtN or 0,
            math.floor((e.boughtN or 0) / e.hitN * 100 + 0.5)), 0.8, 0.8, 0.8)
    end
    if Sn:OthersFaster(e) then tt:AddLine(L["Hier sind andere schneller – anderes Ziel wählen?"], 1, 0.8, 0, true) end
end
UI.SniperTooltipLines = TargetTooltipLines   -- SN2115d: auch für den Test

local function BuildSniper(parent)
    local p = CreateFrame("Frame", nil, parent)
    local Sn = A.Sniper

    local function setMessage(ok, msg)
        if not msg then return end
        p.message:SetText(msg)
        p.message:SetTextColor(unpack(ok and C.textDim or C.red))
        p.messageT, p.messageHint = GetTime and GetTime() or 0, nil
    end

    -- ================= Linke Seite =================
    local head = UI:TabTitle(p, L["Sniper"], "sniper")
    local function SubText()
        if Sn.BuyWith and Sn:BuyWith() == "button" then return L["Zum Kaufen auf „Kaufen“ klicken – ein Klick, ein Kauf."] end   -- SN-BTN1 (d)
        return A:IsForever() and L["Zum Kaufen einfach weiterscrollen – jede Raste macht den nächsten Schritt."]
            or L["1. Ziel eintragen   2. Sniper-Modus AN   3. Mausrad drehen = kaufen"]
    end
    local sub = UI:Label(p, SubText(), "GameFontDisableSmall", C.textDim)
    p.subText, p.SubText = sub, SubText
    sub:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -4)

    p.listsBtn = UI:Button(p, L["Einkaufslisten"], 120, 22, function() UI:ShowLists() end)
    p.listsBtn:SetPoint("TOPLEFT", 326, 0)
    p.listsBtn.tooltip = L["Listen mit Items und Mengen - mit einem Klick als Sniper-Ziele übernehmen"]

    -- Zeile 1: Ziel und Menge
    p.item = UI:EditBox(p, 220, 24, L["Name, ID oder Suchwort"])
    p.item.tooltipText = L["Item-Name in jeder Sprache, Item-ID, Shift-Klick auf ein Item - oder ein Suchwort"]
    UI:AttachItemSearch(p.item, { onPick = function() p.max:SetFocus() end })
    p.item:SetPoint("TOPLEFT", 0, -46)
    p.qty = UI:EditBox(p, 60, 24, "1000")                -- SN-DEF1: leer = 1000
    p.qty:SetPoint("LEFT", p.item, "RIGHT", 6, 0)

    -- Zeile 2: Max-Preis pro Stück und Budget in Gold / Silber / Kupfer
    local maxLabel = UI:Label(p, L["Max/Stück:"], "GameFontHighlightSmall", C.textDim)
    maxLabel:SetPoint("TOPLEFT", 0, -82)
    p.max = UI:MoneyInput(p, nil, "buy")                   -- SN-EIN1: "22" = 22c
    p.max:SetPoint("TOPLEFT", 70, -76)
    if p.max.edit and p.max.edit.placeholder then
        p.max.edit.placeholder:SetText(L["Preis eingeben (z. B. 22c)"])
        if p.max.edit.FitPlaceholder then p.max.edit:FitPlaceholder() end     -- UI-CLEAN1 (D, 0.65.329): neuer Hinweis neu einpassen
    end
    p.max.tooltip = Sn.HelpDefaults()
    if p.max.edit then p.max.edit.tooltip = p.max.tooltip end
    local budgetLabel = UI:Label(p, L["Budget:"], "GameFontHighlightSmall", C.textDim)
    budgetLabel:SetPoint("TOPLEFT", 236, -82)
    p.budget = UI:MoneyInput(p)
    p.budget:SetPoint("TOPLEFT", 290, -76)
    if p.budget.edit and p.budget.edit.placeholder then p.budget.edit.placeholder:SetText("5g") end      -- SN-DEF1: leer = 5g
    p.budget.tooltip = Sn.HelpDefaults()
    if p.budget.edit then p.budget.edit.tooltip = p.budget.tooltip end

    -- Zeile 3: Filter (einklappbar)
    p.filterRow = CreateFrame("Frame", nil, p)
    p.filterRow:SetPoint("TOPLEFT", 0, -108)
    p.filterRow:SetSize(446, 24)
    local fr = p.filterRow

    -- Seltenheit: Aufklappmenü zum Anhaken
    p.qualPicker = UI:QualityPicker(fr, 164)
    p.qualPicker:SetPoint("TOPLEFT", 0, 0)

    p.ilvlMin = UI:EditBox(fr, 56, 24, L["iLvl ab"])          -- UI-CLEAN1 (D, 0.65.327): Hinweise ganz lesbar (Reihe 446 von 446 px mit "X")
    p.ilvlMin:SetPoint("LEFT", p.qualPicker, "RIGHT", 8, 0)
    p.ilvlMax = UI:EditBox(fr, 56, 24, L["iLvl bis"])
    p.ilvlMax:SetPoint("LEFT", p.ilvlMin, "RIGHT", 4, 0)
    p.lvlMin = UI:EditBox(fr, 58, 24, L["Stufe ab"])         -- TB184-U2: etwas breiter
    p.lvlMin:SetPoint("LEFT", p.ilvlMax, "RIGHT", 8, 0)
    p.lvlMax = UI:EditBox(fr, 58, 24, L["Stufe bis"])
    p.lvlMax:SetPoint("LEFT", p.lvlMin, "RIGHT", 4, 0)

    function p:UpdateQualityButtons()
        self.qualPicker:Refresh()
    end

    local allEdits = { p.item, p.qty, p.max.boxes[1], p.max.boxes[2], p.max.boxes[3],
        p.budget.boxes[1], p.budget.boxes[2], p.budget.boxes[3], p.ilvlMin, p.ilvlMax, p.lvlMin, p.lvlMax }

    local function clearForm()
        for _, e in ipairs(allEdits) do e:SetText(""); e:ClearFocus(); e:UpdatePlaceholder() end
        p.qualPicker:Reset()
    end

    local function setTarget()
        -- SN-EIN1 Selbstkontrolle (nur Eingabe des Spielers): Max > 50 × Marktwert -> erst beim zweiten Mal
        local warn = Sn.CheckHighMax and Sn:CheckHighMax(A:FindItemByName(UI:GetItemInput(p.item) or ""), p.max:GetCopper())
        if warn then setMessage(false, warn); return end
        local dq, db = Sn:NewTargetDefaults(Num(p.qty), p.budget:GetCopper(), p.max:GetCopper())      -- SN-DEF1: 1000 Stück / 5g
        local ok, msg = Sn:SetTarget(UI:GetItemInput(p.item), p.max:GetCopper(), dq, db, {
            quals = p.qualPicker:GetSet(),
            ilvlMin = Num(p.ilvlMin), ilvlMax = Num(p.ilvlMax),
            lvlMin = Num(p.lvlMin), lvlMax = Num(p.lvlMax),
        })
        setMessage(ok, msg)
        if ok then clearForm() end
    end
    for _, e in ipairs(allEdits) do e:SetScript("OnEnterPressed", setTarget) end

    p.setBtn = UI:Button(p, L["Ziel setzen"], 120, 24, setTarget, "primary")
    p.setBtn:SetPoint("LEFT", p.qty, "RIGHT", 6, 0)
    p.setBtn.tooltip = L["Ziel speichern.\nMenge leer = Ware: so viele, wie das Budget reicht; Ausrüstung: 1 Stück.\nBudget leer = Menge x Max-Preis.\nFilter (Seltenheit, Itemlevel, Stufe) gehören zum Ziel."]

    p.clearBtn = UI:Button(fr, "X", 24, 24, clearForm)
    p.clearBtn:SetPoint("LEFT", p.lvlMax, "RIGHT", 6, 0)
    p.clearBtn.tooltip = L["Alle Eingaben leeren"]
    UI:ChainEdits(allEdits)

    -- Zeile 3: Modus und Auslöser
    p.armBtn = UI:Button(p, "", 150, 26, function()
        if Sn:ArmLocked() then p:Refresh(); return end           -- SN-SCAN1: gesperrt, Grund im Tooltip
        Sn:ToggleArmed()
        p:Refresh()
    end, "primary")

    p.armBtn.tooltip = L["Sniper-Modus an/aus (auch /ahs sniper).\nNur aktiv, solange das Auktionshaus offen ist."]

    -- PL-T1 (b) (Rückmeldung des Nutzers 08:28): "Kaufen mit" direkt im Sniper - der Knopf "Mausrad" schaltet um:
    -- grün = Mausrad kauft (Mausrad + Knopf), grau = nur der Knopf „Kaufen“ kauft. Gleiche Einstellung wie in den Optionen.
    p.wheelBtn = UI:Button(p, L["Mausrad"], 80, 26, function()
        if Sn:BuyWith() == "button" then
            Sn:SetBuyWith("both")
            Sn:UseMouseWheel()
            setMessage(true, L["Kaufen mit dem Mausrad (hoch und runter)."])
        elseif Sn:IsMouseWheelBind() then
            Sn:SetBuyWith("button")
            setMessage(true, L["Nur der Knopf „Kaufen“ kauft – das Mausrad bleibt frei."])
        else
            Sn:UseMouseWheel()
            setMessage(true, L["Kaufen mit dem Mausrad (hoch und runter)."])
        end
        p:Refresh()
    end)
    p.wheelBtn:SetPoint("LEFT", p.armBtn, "RIGHT", 6, 0)
    p.wheelBtn.tooltip = L["Mausrad als Auslöser (beide Richtungen)"]
    function p:UpdateWheelBtn()
        local on = Sn:BuyWith() ~= "button" and Sn:IsMouseWheelBind()
        self.wheelBtn:SetText((on and "|cff33dd55" or "|cff888888") .. L["Mausrad"] .. "|r")
        self.wheelBtn.tooltip = on and L["Mausrad kauft (grün). Klick: aus – dann kauft nur der Knopf „Kaufen“ (gleich wie Optionen > Kaufen & Sniper)."]
            or L["Mausrad kauft nicht (grau). Klick: Mausrad kauft wieder (gleich wie Optionen > Kaufen & Sniper)."]
    end

    p.keyBtn = UI:Button(p, L["Eigene Taste"], 104, 26, function()
        OpenCapture(function(key)
            if Sn:BuyWith() == "button" then Sn:SetBuyWith("both") end      -- eigene Taste gewählt = Taste soll kaufen
            Sn:SetBinds(KeyToBinds(key))
            setMessage(true, L["Kaufen jetzt mit: "] .. Sn:GetBindsText())
        end)
    end)
    p.keyBtn:SetPoint("LEFT", p.wheelBtn, "RIGHT", 6, 0)
    p.keyBtn.tooltip = L["Eigene Taste oder Maustaste als Auslöser wählen"]

    p.filterBtn = UI:Button(p, "", 86, 26, function()
        A.db.settings.sniperFilters = not A.db.settings.sniperFilters
        p:Layout()
    end)
    p.filterBtn:SetPoint("LEFT", p.keyBtn, "RIGHT", 6, 0)
    p.filterBtn.tooltip = L["Filter ein-/ausblenden:\nSeltenheit (Grau bis Episch), Itemlevel, Stufe"]

    p.status = UI:Label(p, "", "GameFontHighlightSmall", C.text)
    p.status:SetWidth(440)

    -- Ziele
    p.targets = UI:Table(p, {
        columns = {
            { key = "name", title = L["Ziel"], width = 170 },                     -- TB196-2: Namen nicht abschneiden
            { key = "maxPrice", title = L["Max/St."], width = 62, align = "RIGHT" },
            -- SN2 (Anweisung 10.11.): Stand ganz lesbar ("50/100 gekauft · Budget 5g aufgebraucht"); Filter im Tooltip
            { key = "qty", title = L["Stand"], width = 184 },                     -- TB196-2: kurz "140/1000 · Rest 7g81"
        },
        rows = 8,
        rowHeight = 22,
        idKey = "key",
        sortKey = "name",
        cell = function(e, key)
            local done = e.done
            local function dim(s) return done and ("|cff777777" .. s .. "|r") or s end
            if key == "name" then
                local n = UI.ItemName(e)
                if Sn:OthersFaster(e) then n = "|cffffcc00!|r " .. n end      -- D3
                if e.watch then n = "|cff33dd55" .. L["[Wächter]"] .. "|r " .. n end
                if Sn.search and Sn.search.targetKey == e.key then n = "|cffffcc33> |r" .. n end
                -- SN-ALLE1: Zeile mit wartendem Treffer golden markiert
                if Sn:HitMarked(e.key) then n = "|cffffd100* " .. n .. "|r" end
                -- Antwort 1401 (NIEDRIG): Ziel auf einem Weg, der lernt oder gesperrt ist -> grau mit Hinweis
                -- UI-CLEAN1 (D, 0.65.329, Entscheid 18:10 "Zahlen nie gekürzt"): Weg-Hinweis ("lernt noch (10 von 20)") im Tooltip,
                -- in der Zeile bleibt der Name grau
                local wn = Sn:WayNote(e.target)
                if wn then return "|cff888888" .. n .. "|r" end
                return dim(n)
            end
            if key == "filter" then return dim(e.filter) end
            if key == "maxPrice" then
                if e.overValue and not e.reagent and not done then return "|cffffcc00" .. A:FormatMoney(e.maxPrice, true) .. "|r" end   -- H4
                if e.overLimit and not done then return "|cffffcc00" .. A:FormatMoney(e.maxPrice, true) .. "|r" end     -- MU1-3
                return dim(A:FormatMoney(e.maxPrice, true))
            end
            if key == "qty" then
                if e.paused and not done then return "|cffff9933" .. e.paused .. "|r" end        -- SN1951b
                local s = Sn:ProgressText(e.target, true)                                 -- TB189-3: kurz, lang im Tooltip
                if e.bought >= e.qty then return "|cff33dd55" .. s .. "|r" end
                if Sn:BudgetUsedUp(e.target) then return "|cffffcc00" .. s .. "|r" end
                return s
            end
            if key == "filter" then return dim(e.filter) end
        end,
        sortValue = function(e, key)
            if key == "name" or key == "filter" then return string.lower(e[key]) end
            if key == "qty" then return e.qtyLeft end
            if key == "budget" then return e.budgetLeft end
            return e[key]
        end,
        tooltipLines = TargetTooltipLines,
        onClick = function(e)
            p.selected = e.key
            local t = e.target
            -- Werte ins Formular übernehmen (zum Ändern)
            if t.kind == "item" then UI:SetItemInput(p.item, t.itemID) else p.item:SetText(t.text); p.item.itemID = nil end
            p.max:SetCopper(t.maxPrice)
            p.qty:SetText(tostring(t.qty))
            p.budget:SetCopper(t.budget)
            p.ilvlMin:SetText(t.ilvlMin and tostring(t.ilvlMin) or "")
            p.ilvlMax:SetText(t.ilvlMax and tostring(t.ilvlMax) or "")
            p.lvlMin:SetText(t.lvlMin and tostring(t.lvlMin) or "")
            p.lvlMax:SetText(t.lvlMax and tostring(t.lvlMax) or "")
            for _, ed in ipairs(allEdits) do ed:UpdatePlaceholder() end
            p.qualPicker:SetSet(Sn:QualSet(t))
            if Sn:FilterText(t) ~= L["alle"] and not A.db.settings.sniperFilters then
                A.db.settings.sniperFilters = true
                p:Layout()
            end
            if A:IsAHOpen() and not e.done then
                local ok, msg, soft = Sn:Search(e.key)
                if not soft then setMessage(ok, msg) end
            else
                setMessage(true, L["Ziel gewählt - Werte stehen oben zum Ändern."])
            end
            p:Refresh()
        end,
        action = {
            text = "X", width = 26,
            tooltip = L["Ziel entfernen"],
            onClick = function(e)
                setMessage(Sn:RemoveTarget(e.key))
            end,
        },
        emptyText = L["Noch keine Ziele.\nOben Item, Max-Preis, Menge und Budget eingeben."],
    })


    -- SN-BTN1 (Spieler-Wunsch, Nutzer 18:27/18:29): EIN klarer Haupt-Knopf über die ganze Spalte. Ein Klick = ein Kauf
    -- (gleicher Weg wie Raste/Taste: Sn:OnTrigger -> Max, Budget, ein Einzelkauf zur Zeit, Server bereit). Ohne Treffer grau
    -- mit Grund, kein versteckter Such-Schritt. Zustände ohne Blinken: bereit (Hauptfarbe), wartet (gedämpft), kein Treffer
    -- (grau), gekauft (kurz grün). Text eine Zeile, nur der Name wird gekürzt.
    p.buyBtn = UI:Button(p, L["Kein Treffer"], 440, 32, function()
        -- SN-BTN1-Nachtest (16.11., Verdacht, zu messen): Zustand beim Klick ins Diagnose-Protokoll (nur Entwickler)
        local st0, tx0 = p.buyBtn.buyState, p.buyBtn.buyText
        local r0 = Sn.result
        local ok, msg = Sn:OnTrigger("button")
        if A.IsDev and A:IsDev() and A.Diag then
            pcall(A.Diag.Add, A.Diag, "SNIPER-KNOPF", string.format("Klick bei %s (%s) · Treffer-Alter %s s · Ergebnis %s · %s",
                tostring(st0), A:PlainText(tostring(tx0 or "")), r0 and r0.time and string.format("%.1f", GetTime() - r0.time) or "-",
                tostring(ok), A:PlainText(tostring(msg or "keine Meldung"))))
        end
        setMessage(ok, msg)
        p:UpdateBuy(true)
    end, "primary")
    p.buyBtn:SetPoint("TOPLEFT", p.targets, "BOTTOMLEFT", 0, -8)
    if p.buyBtn.label.SetFontObject then p.buyBtn.label:SetFontObject("GameFontNormal") end
    if p.buyBtn.label.SetWordWrap then p.buyBtn.label:SetWordWrap(false) end
    p.buyBtn.label:SetWidth(424)
    local BUY_COLOR = { buy = "accent", ask = "accent", confirm = "accent", refill = "accent", wait = "dim", done = "green", none = "off" }
    function p:UpdateBuy(force)
        local b = self.buyBtn
        local okS, state, text, tip = pcall(Sn.ButtonState, Sn)
        if not okS then state, text, tip = "none", L["Kaufen"], nil end
        b.tooltip = tip
        -- PL-T2 (b): Grund am grauen Knopf auch als Text darunter (Meldungszeile), solange keine eigene Meldung jünger als 8 s ist
        local tNow = GetTime and GetTime() or 0
        if state == "none" and tip and (self.messageHint or not self.messageT or tNow - self.messageT > 8) then
            if self.messageHint ~= tip then
                self.message:SetText(tip)
                self.message:SetTextColor(unpack(C.textDim))
                self.messageHint = tip
            end
        elseif state ~= "none" and self.messageHint then
            self.message:SetText("")
            self.messageHint = nil
        end
        if not force and state == b.buyState and text == b.buyText then return end     -- kein Flackern: nur bei Änderung
        b.buyState, b.buyText = state, text
        b:SetText(text)
        local look = BUY_COLOR[state] or "off"
        b:SetActive(look == "accent" or look == "green")
        if b.__bg then
            local col = (look == "accent" and C.accent) or (look == "green" and { 0.16, 0.55, 0.25, 1 })
                or (look == "dim" and { 0.20, 0.24, 0.32, 1 }) or { 0.12, 0.12, 0.14, 1 }
            b.__bg:SetColorTexture(unpack(col))
            b.__base, b.__hover = col, col
        end
        b.label:SetTextColor(unpack((look == "green" and C.green) or (look == "accent" and C.text) or C.textDim))
    end
    local acc = 0
    p.buyBtn:HookScript("OnUpdate", function(_, dt)
        acc = acc + (dt or 0)
        if acc < 0.1 then return end
        acc = 0
        p:UpdateBuy()
    end)

    p.searchBtn = UI:Button(p, L["Jetzt suchen"], 130, 28, function()
        local ok, msg, soft = Sn:CheckNext()
        setMessage(ok or soft, msg)
        p:Refresh()
    end)
    p.searchBtn:SetPoint("TOPLEFT", p.buyBtn, "BOTTOMLEFT", 0, -6)
    p.searchBtn.tooltip = L["Nächstes offenes Ziel sofort suchen"]

    p.resetBtn = UI:Button(p, L["Zähler zurücksetzen"], 150, 28, function()
        if not p.selected then setMessage(false, L["Erst ein Ziel in der Liste anklicken."]) return end
        setMessage(Sn:ResetProgress(p.selected))
    end)
    p.resetBtn:SetPoint("LEFT", p.searchBtn, "RIGHT", 6, 0)
    p.resetBtn.tooltip = L["Gekaufte Menge und ausgegebenes Gold des gewählten Ziels auf 0 setzen"]

    -- MU1-3: gewähltes Ziel mit festem Max über "Lohnt bis" -> Knopf stellt es auf "Max folgt Lohnt bis" (t.de). Nur sichtbar,
    -- wenn es passt; nichts wird erzwungen.
    p.followBtn = UI:Button(p, L["Max folgt Lohnt bis"], 148, 28, function()
        if not p.selected then setMessage(false, L["Erst ein Ziel in der Liste anklicken."]) return end
        local okF, msgF = Sn:FollowLimit(p.selected)
        setMessage(okF, msgF)
        if okF and A.Pruefliste then A.Pruefliste:Hit("MU1-3", msgF) end         -- Prüfliste (nur Entwickler)
        p:Refresh()
    end)
    p.followBtn:SetPoint("LEFT", p.resetBtn, "RIGHT", 6, 0)
    p.followBtn.tooltip = L["Max dieses Ziels folgt ab jetzt „Lohnt bis“ (frische Preise) – wie bei Zielen aus Entzaubern."]
    p.followBtn:Hide()

    -- SN1951b: pausierte Items sofort wieder suchen (sichtbar nur, solange etwas pausiert ist)
    p.resumeBtn = UI:Button(p, L["jetzt fortsetzen"], 150, 24, function()
        local e = p.selected and Sn:GetTarget(p.selected)
        local id = e and e.itemID and Sn:ItemPaused(e.itemID) and e.itemID or nil
        setMessage(Sn:ResumeItem(id))
        p:Refresh()
    end)
    p.resumeBtn:SetPoint("TOPRIGHT", p.resetBtn, "BOTTOMRIGHT", 0, -4)
    p.resumeBtn.tooltip = L["Pausierte Items (3 Käufe gescheitert) sofort wieder suchen – gewähltes Ziel oder alle"]
    p.resumeBtn:Hide()

    p.message = UI:Label(p, "", "GameFontHighlightSmall", C.textDim)
    p.message:SetPoint("TOPLEFT", p.searchBtn, "BOTTOMLEFT", 0, -6)
    p.message:SetWidth(440)

    -- ================= Rechte Seite: Angebote =================
    local right = CreateFrame("Frame", nil, p)
    right:SetPoint("TOPLEFT", 456, 0)
    right:SetPoint("BOTTOMRIGHT", 0, 0)

    p.resultTitle = UI:Label(right, L["Noch nichts gesucht"], "GameFontNormalLarge", C.accent)
    p.resultTitle:SetPoint("TOPLEFT", 0, 0)
    p.resultTitle:SetWidth(470)
    p.resultInfo = UI:Label(right, "", "GameFontHighlightSmall", C.textDim)
    p.resultInfo:SetPoint("TOPLEFT", 0, -24)
    p.resultInfo:SetWidth(470)

    local function resultItem()
        return Sn.result and Sn.result.itemID
    end

    p.openBtn = UI:Button(right, L["Im Auktionshaus zeigen"], 170, 24, function()
        setMessage(Sn:OpenInAH(resultItem()))
    end)
    p.openBtn:SetPoint("TOPLEFT", 0, -44)      -- TB184-U2: Abstand zur Zeile "n Einträge" über der Tabelle (Fill -84)

    p.chartBtn = UI:Button(right, L["Preisverlauf"], 100, 24, function()
        local id = resultItem()
        if id then UI:OpenChart(id) end
    end)
    p.chartBtn:SetPoint("LEFT", p.openBtn, "RIGHT", 6, 0)

    local STATUS_COLOR = {
        ["kaufbar"] = "33dd55", ["gekauft"] = "33dd55", ["zu teuer"] = "888888", ["Filter"] = "888888",
        ["Fehler – nochmal"] = "ff9933", ["keine Antwort"] = "888888",                     -- SN-UI1 (b)
        ["Pause 30 s"] = "ff9933", ["Pause"] = "ff9933",                                     -- GSL2-1 (b)
        ["eigenes"] = "888888", ["Menge erreicht"] = "888888", ["Lockangebot"] = "ff9933", ["weg"] = "ff5544",
    }

    p.listings = UI:Table(right, {
        columns = {
            { key = "price", title = L["Preis/Stück"], width = 110, align = "RIGHT" },
            { key = "pct", title = L["% Markt"], width = 52, align = "RIGHT",
              tooltip = L["Preis in Prozent vom Marktwert (Median 14 Tage).\nGrün = günstig, Orange/Rot = teuer."] },
            { key = "qty", title = L["Menge"], width = 52, align = "RIGHT" },
            { key = "cost", title = L["Gesamt"], width = 100, align = "RIGHT" },
            { key = "ilvl", title = "iLvl", width = 40, align = "RIGHT" },
            { key = "status", title = "", width = 96 },
        },
        rows = 14,
        rowHeight = 22,
        itemTooltip = false,
        cell = function(l, key)
            if key == "price" then
                return l.status == "kaufbar" and ("|cff33dd55" .. A:FormatMoney(l.price) .. "|r") or A:FormatMoney(l.price)
            end
            if key == "pct" then
                local id = Sn.result and Sn.result.itemID
                return A:FormatMarketPercent(id and A:GetMarketPercent(id, l.price))
            end
            if key == "qty" then
                if l.planned and l.planned < l.qty then return l.planned .. L[" von "] .. l.qty end
                return tostring(l.qty)
            end
            if key == "cost" then return A:FormatMoney(l.price * l.qty) end
            if key == "ilvl" then return l.ilvl and tostring(l.ilvl) or "-" end
            if key == "status" then
                local s = l.status or ""
                if s == "" then return "" end
                return "|cff" .. (STATUS_COLOR[s] or "ff9933") .. L[s] .. "|r"     -- Status-Codes erst hier übersetzen
            end
        end,
        emptyText = L["Hier erscheinen die Angebote\nnach einer Suche."],
    })
    p.listings:Fill(0, -84, 0, 64)      -- darunter die Zusammenfassung; TB184-U2: "n Einträge" nicht unter "Preisverlauf"

    p.summary = UI:Label(right, "", "GameFontHighlight", C.text)
    p.summary:SetPoint("TOPLEFT", p.listings, "BOTTOMLEFT", 0, -8)
    p.summary:SetWidth(470)
    -- Gesamtmenge: was bei diesem Item insgesamt gekauft wird
    p.total = UI:Label(right, "", "GameFontHighlight", C.accent)
    p.total:SetPoint("TOPLEFT", p.summary, "BOTTOMLEFT", 0, -6)
    p.total:SetWidth(470)
    -- SN-UI1 (e): "gekauft n · weggeschnappt n · ohne Antwort n" (dieses Ziel, diese Spiel-Sitzung)
    p.rowSum = UI:Label(right, "", "GameFontHighlightSmall", C.textDim)
    p.rowSum:SetPoint("TOPLEFT", p.total, "BOTTOMLEFT", 0, -4)
    p.rowSum:SetWidth(470)
    -- SN-RUHE1 (f): "Ruhemodus: n Aufgaben pausiert" (Tooltip mit Liste)
    p.quietInfo = UI:Label(right, "", "GameFontHighlightSmall", C.textDim)
    p.quietInfo:SetPoint("TOPLEFT", p.rowSum, "BOTTOMLEFT", 0, -4)
    p.quietInfo:SetWidth(470)
    p.quietHit = CreateFrame("Frame", nil, right)
    p.quietHit:SetAllPoints(p.quietInfo)
    p.quietHit:EnableMouse(true)
    p.quietHit:SetScript("OnEnter", function(self2)
        local _, tip = Sn:QuietText()
        if not tip then return end
        GameTooltip:SetOwner(self2, "ANCHOR_TOP")
        GameTooltip:AddLine(L["Sniper-Ruhemodus"], 1, 0.82, 0)
        for _, l in ipairs(tip) do GameTooltip:AddLine(l, 0.9, 0.9, 0.9, true) end
        GameTooltip:Show()
    end)
    p.quietHit:SetScript("OnLeave", function() GameTooltip:Hide() end)
    function p:UpdateQuiet()
        local txt = Sn:QuietText()
        self.quietInfo:SetText(txt or "")
    end

    -- Anordnung je nachdem, ob die Filter sichtbar sind
    function p:Layout()
        -- Filterzeile (Seltenheit, Itemlevel, Stufe) ist immer sichtbar
        local open = true
        self.filterRow:Show()
        self.filterBtn:Hide()
        local y = open and -140 or -108
        self.armBtn:ClearAllPoints()
        self.armBtn:SetPoint("TOPLEFT", 0, y)
        self.status:ClearAllPoints()
        self.status:SetPoint("TOPLEFT", 0, y - 30)
        self.targets:FillColumn(0, y - 62, 448, 102)   -- SN-BTN1: +38 für den Haupt-Knopf "Kaufen"; zwei Zeilen Status (Kaufen mit … / Heute: …)    -- linke Spalte; darunter Knöpfe und Meldung
        self.filterBtn:SetText(open and L["Filter <<"] or L["Filter >>"])
    end

    -- Formular mit einem Item vorbefüllen (Rechtsklick-Menü "Als Sniper-Ziel")
    function p:Prefill(itemID)
        UI:SetItemInput(self.item, itemID)
        local price = A:GetCurrent(itemID)
        self.max:SetCopper(price)
        self.qty:SetText("")
        self.budget:Clear()
        for _, ed in ipairs(allEdits) do ed:UpdatePlaceholder() end
        self.max:SetFocus()
        setMessage(true, L["Max-Preis, Menge und Budget prüfen, dann 'Ziel setzen'. (Vorschlag = aktueller Preis)"])
    end

    function p:Refresh()
        local db = A.db.sniper
        self.armBtn:SetText(db.armed and L["Sniper-Modus: AN"] or L["Sniper-Modus: AUS"])
        -- SN-SCAN1: während des Vollscans grau, Tooltip mit Restzeit
        local lockText = Sn:ArmLocked()
        self.armBtn:SetActive(not lockText)
        self.armBtn.tooltip = lockText and (L["Gesperrt, bis der Scan fertig ist – "] .. lockText)
            or L["Sniper-Modus an/aus (auch /ahs sniper).\nNur aktiv, solange das Auktionshaus offen ist."]
        self.status:SetText(L["Kaufen mit: |cffffd700"] .. Sn:GetBindsText() .. L["|r     "] .. Sn:GetStatusText()
            .. "\n|cffaaaaaa" .. Sn:StatsText() .. "|r")
        self:UpdateQualityButtons()

        self.targets.selectedID = self.selected
        self.targets:SetData(Sn:GetTargets(), true)
        self:UpdateWheelBtn()                                                -- PL-T1 (b)
        local selT = self.selected and Sn:GetTarget(self.selected)
        if selT and not Sn:IsDone(selT) and Sn:MaxOverLimit(selT) then self.followBtn:Show() else self.followBtn:Hide() end   -- MU1-3
        if Sn.PausedItems and #Sn:PausedItems() > 0 then
            self.resumeBtn:Show(); self.message:SetWidth(270)
        else
            self.resumeBtn:Hide(); self.message:SetWidth(440)
        end

        self:UpdateBuy(true)                                   -- SN-BTN1
        if self.subText then self.subText:SetText(self.SubText()) end
        self.searchBtn:SetActive(not Sn.search)

        -- AHS-CF1-UI c): die Prüf-Suche des Wächters erscheint nicht im Sniper-Reiter (Angebote des Snipers bleiben stehen)
        local srchT = Sn.search and Sn:GetTarget(Sn.search.targetKey)
        if Sn.search and not (srchT and srchT.watch) then
            local t = srchT
            self.resultTitle:SetText(t and Sn:TargetName(t) or "?")
            self.resultInfo:SetText(L["|cffffcc33Suche läuft ...|r"])
            -- Gesamtzeile stehen lassen, solange der Treffer desselben Ziels noch gilt (Forever: ohne Vorab-Reservierung
            -- sucht der Sniper weiter, während der Treffer wartet)
            if self.total then
                local tq, tc, tn
                if Sn.result and Sn.result.key == Sn.search.targetKey and Sn:IsResultFresh() then tq, tc, tn = Sn:PlanTotal() end
                if tq then
                    local txt = string.format(L["Insgesamt: %d Stück für %s (Ø %s/Stück)"], tq, A:FormatMoney(tc), A:FormatMoney(math.floor(tc / math.max(1, tq) + 0.5)))
                    if tn and tn > 1 then txt = txt .. string.format(L["  -  %d Käufe"], tn) end
                    self.total:SetText(txt)
                else
                    self.total:SetText("")
                end
            end
            -- Angebote eines anderen Ziels nicht unter dem neuen Namen stehen lassen
            if not (Sn.result and Sn.result.key == Sn.search.targetKey) then
                self.listings:SetData({})
                if self.summary then self.summary:SetText("") end
                if self.rowSum then self.rowSum:SetText("") end
            end
            return
        end

        local r = Sn.result
        if not r then
            -- S2: im Sniper-Modus den Stand der Selbst-Suche statt "Noch nichts gesucht"
            local st = Sn:AutoStatus()
            self.resultTitle:SetText(st and L["Sniper-Modus an"] or L["Noch nichts gesucht"])
            if st then self.resultInfo:SetText(st)
            else self.resultInfo:SetText(A:IsAHOpen() and L["Sniper-Modus einschalten oder 'Jetzt suchen' klicken."] or L["|cffff5544Auktionshaus öffnen, um zu suchen.|r"]) end
            self.statusOnly = st ~= nil
            self.listings:SetData({})
            self.summary:SetText("")
            self.rowSum:SetText("")
            -- SN3: aufgebrauchtes Budget auch ohne Suchergebnis als Kopfzeile
            local sel = self.selected and Sn:GetTarget(self.selected)
            local cand = sel and { sel } or {}
            if not sel then for _, e in ipairs(Sn:GetTargets()) do cand[#cand + 1] = e.target end end
            for _, tt in ipairs(cand) do
                if tt and (tt.bought or 0) < (tt.qty or 0) and Sn:BudgetUsedUp(tt) then
                    self.summary:SetText("|cffffcc00" .. Sn:BudgetText(tt) .. "|r")
                    break
                end
            end
            self.total:SetText("")
            return
        end

        self.statusOnly = nil
        local t = Sn:GetTarget(r.key)
        self.resultTitle:SetText(r.itemID and A:GetItemName(r.itemID) or (t and Sn:TargetName(t) or "?"))
        local info = L["gesucht "] .. A:FormatAgo(r.stamp) .. "   |   " .. #r.listings .. L[" Angebote"]
        if t then
            local qLeft, bLeft = Sn:Remaining(t)
            info = info .. L["   |   noch "] .. math.max(0, qLeft) .. L[" Stück, "] .. A:FormatMoney(math.max(0, bLeft)) .. L[" Budget"]
        end
        if r.candidates and r.candidates > 1 then info = info .. "   |   " .. r.candidates .. L[" passende Items"] end
        local nq = Sn.QueuedHits and Sn:QueuedHits() or 0                               -- SM1
        if nq > 0 then info = info .. "   |   |cff33dd55" .. string.format(L["%d weitere Treffer warten"], nq) .. "|r" end
        local jk = A.Timing and r.itemID and A.Timing:InlineText(r.itemID, "any")     -- JK1
        if jk then info = info .. "   |   " .. jk end
        self.resultInfo:SetText(info)

        -- SN-Z2 (Befund 21.11. 20:08, belegt): das Ergebnis wurde nicht gemerkt - "elseif plan then" unten las eine nie gesetzte
        -- globale Variable (immer nil) -> bei einem kaufbaren Angebot stand "Nichts bis zu deinem Max-Preis", der Knopf bot den Kauf an
        local plan = Sn:PlanNext()   -- Status der Angebote aktualisieren
        self.listings:SetData(A:NoBait(Sn:VisibleListings(r.listings)))                -- SN-UI1: erledigte nach 1 s ausblenden
        -- SN-UI1 (e): je Ziel diese Spiel-Sitzung; Zahlen = Zähler des Sniper-Berichts
        local rs = r.key and Sn.rowStats[r.key]
        self.rowSum:SetText(rs and string.format(L["gekauft %d · weggeschnappt %d · ohne Antwort %d"], rs.got or 0, rs.gone or 0, rs.none or 0) or "")
        local tq, tc, tn = nil, nil, nil
        if Sn:IsResultFresh() then tq, tc, tn = Sn:PlanTotal() end
        if tq then
            local txt = string.format(L["Insgesamt: %d Stück für %s (Ø %s/Stück)"], tq, A:FormatMoney(tc), A:FormatMoney(math.floor(tc / math.max(1, tq) + 0.5)))
            if tn and tn > 1 then txt = txt .. string.format(L["  -  %d Käufe"], tn) end
            self.total:SetText(txt)
        else
            self.total:SetText("")
        end

        if Sn.pending then
            local pd = Sn.pending
            if pd.state == "ready" and pd.auto then
                self.summary:SetText(L["|cff33dd55Nächster Kauf: "] .. pd.qty .. L[" Stück für "] .. A:FormatMoney(pd.total or pd.expected) .. L["|r  ("] .. Sn:GetBindsText() .. ")")
            elseif pd.state == "ready" then
                self.summary:SetText(L["|cff33dd55Reserviert: "] .. pd.qty .. L[" Stück für "] .. A:FormatMoney(pd.total or pd.expected) .. " - " .. Sn:GetBindsText() .. L[" zum Bestätigen|r"])
            else
                self.summary:SetText(L["|cffffcc33Preis wird vom Server geprüft ...|r"])
            end
        elseif t and (t.bought or 0) < (t.qty or 0) and Sn:BudgetUsedUp(t) then
            -- SN3: Kopfzeile, solange das Budget aufgebraucht ist
            self.summary:SetText("|cffffcc00" .. Sn:BudgetText(t) .. "|r")
        elseif not Sn:IsResultFresh() then
            -- SN1: gekaufte Stück dieser Suche nennen
            local bn, bsum, missed = Sn:ResultBought(r)
            -- S7 (Befund 21.11. 07:00: "veraltet – neue Suche nötig" neben "Pause bis 07:09"): pausiertes Item -> eine Aussage: pausiert
            local pt = r.itemID and Sn:PauseText(r.itemID)
            if pt then
                self.summary:SetText("|cffaaaaaa" .. string.format(L["Item %s – keine Suche, kein Kauf (in dieser Suche gekauft: %d Stück für %s)."], pt, bn, A:FormatMoney(bsum)) .. "|r")
            elseif bn > 0 or missed > 0 then
                self.summary:SetText("|cffaaaaaa" .. string.format(L["Ergebnis ist veraltet – in dieser Suche gekauft: %d Stück für %s · verpasst %d – neue Suche nötig."],
                    bn, A:FormatMoney(bsum), missed) .. "|r")
            else
                self.summary:SetText(L["|cffaaaaaaErgebnis ist veraltet - neue Suche nötig.|r"])
            end
        elseif plan then
            self.summary:SetText(L["|cff33dd55Nächster Kauf: "] .. plan.qty .. L[" Stück für "] .. A:FormatMoney(plan.total) .. L["|r  ("] .. Sn:GetBindsText() .. ")")
        elseif #r.listings == 0 and Sn:HiddenNote(r) then
            self.summary:SetText(Sn:NothingText(r))
        elseif #r.listings == 0 then
            self.summary:SetText(r.itemID and L["|cffaaaaaaKeine Angebote gefunden.|r"] or L["|cffaaaaaaKein passendes Item unter deinem Max-Preis.|r"])
        else
            self.summary:SetText(Sn:NothingText(r))                -- S7: nur sichtbare Angebote, Hinweis "ausgeblendet"
        end
    end

    -- SN-TR-2 (Ingame-Test 16.11. 19:43 S5/S13 Ruckeln; Protokoll 0.65.265: "ui-refresh" ~20 ms jede Sekunde beim Snipen; Nachbau
    -- s266_sniper_tab_cost: 5,7 Neuaufbauten je Sekunde über drei Wege - Zeitgeber 0,5 s, SNIPER_CHANGED je Suche, Hintergrund-Aufgabe
    -- ui-refresh): die automatischen Wege laufen über RefreshAuto - höchstens alle REFRESH_GAP s ein Neuaufbau; was dazwischen kommt,
    -- wird am Ende der Lücke EINMAL nachgeholt (nichts geht verloren). Direkte Aufrufe (Klick, Test) bauen wie bisher sofort neu.
    p.REFRESH_GAP = 0.5
    -- Korrektur (Gesamtlauf 0.65.287, s10_quality_picker): gedrosselt wird NUR beim Snipen (Sniper an, AH offen) - sonst sofort,
    -- damit eine eigene Aktion (Ziel setzen, löschen, wählen) die Liste ohne Verzögerung zeigt
    function p:RefreshAuto()
        local now = GetTime()
        local busy = Sn:IsArmed() and A:IsAHOpen()
        if busy and self.lastFull and now - self.lastFull < self.REFRESH_GAP then self.refreshDue = true; return false end
        self.refreshDue = nil
        self:Refresh()
        return true
    end
    local realRefresh = p.Refresh
    function p:Refresh(...)
        self.lastFull = GetTime()
        return realRefresh(self, ...)
    end

    -- regelmäßig auffrischen, solange etwas läuft
    local elapsed = 0
    p:SetScript("OnUpdate", function(self, dt)
        elapsed = elapsed + (dt or 0)
        if self.refreshDue and GetTime() - (self.lastFull or 0) >= self.REFRESH_GAP then self:RefreshAuto() end
        if elapsed >= 0.5 then
            elapsed = 0
            -- SN-UI1: auch ohne Sniper-Modus, bis erledigte Zeilen ausgeblendet sind (kein eigener Zeitgeber, kein Rest nach AH zu)
            if Sn.search or Sn.pending or (A.db.sniper.armed and A:IsAHOpen()) or (Sn.doneUntil and GetTime() <= Sn.doneUntil + 0.6) then self:RefreshAuto() end
        end
    end)

    p:UpdateQualityButtons()
    p:Layout()
    return p
end

UI:RegisterTab("sniper", "Sniper", 3.5, BuildSniper)

-- nur die Reiter neu zeichnen, die den Sniper zeigen (sonst baut z.B. der Markt bei jeder Sniper-Suche neu auf)
A:On("SNIPER_CHANGED", function()
    if UI.activeTab == "sniper" or UI.activeTab == "watcher" then
        local clock = debugprofilestop                               -- GSL2-3: Zeit des Neuaufbaus messen (Sniper-Bericht)
        local t0 = clock and clock()
        -- SN-TR-2: Sniper-Reiter über RefreshAuto (höchstens alle 0,5 s, Rest nachgeholt); Wächter-Reiter wie bisher
        local tab = UI.activeTab == "sniper" and UI.GetTab and UI:GetTab("sniper")
        if tab and tab.panel and tab.panel.RefreshAuto and UI:IsVisible() then
            local ok, err = pcall(tab.panel.RefreshAuto, tab.panel)
            if not ok then A:PrintError("Aktualisieren sniper", err) end   -- ST1 C
            UI:UpdateStatus()
        else
            UI:RefreshActive()
        end
        if t0 and A.Sniper.NoteTime then A.Sniper:NoteTime("Fenster", clock() - t0) end
    end
end)

-- S2: Statuszeile der Selbst-Suche jede Sekunde nachführen (nur die Zeile, ohne Neuaufbau)
local statusTicker = CreateFrame("Frame")
local statusAcc = 0
statusTicker:SetScript("OnUpdate", function(_, dt)
    statusAcc = statusAcc + (dt or 0)
    if statusAcc < 1 then return end
    statusAcc = 0
    if UI.activeTab ~= "sniper" then return end
    local tab = UI.GetTab and UI:GetTab("sniper")
    local p = tab and tab.panel
    if p and p.statusOnly and p.resultInfo and p:IsVisible() then
        local st = A.Sniper:AutoStatus()
        if st then p.resultInfo:SetText(st) end
    end
    if p and p.UpdateQuiet and p:IsVisible() then p:UpdateQuiet() end              -- SN-RUHE1 (f)
end)

-- Beim Design-Wechsel das Tasten-Fenster neu bauen
A:On("THEME_CHANGED", function()
    if capture then capture:Hide(); capture = nil end
end)

-- SB: Abfrage "Budget auffüllen?" – "Ja" (Enter) füllt auf, "Nein" (Esc) ändert nichts. Kein Kauf aus diesem Fenster.
function A.Sniper:ShowRefill(t, text)
    local Sn = self
    local d = Sn.refillDlg
    if not d then
        d = UI:Dialog("AHSentinelSniperRefill", 440, 130, L["Sniper"])
        d.text = UI:Label(d, "", "GameFontHighlight")
        d.text:SetPoint("TOPLEFT", 14, -40); d.text:SetPoint("TOPRIGHT", -14, -40)
        if d.text.SetWordWrap then d.text:SetWordWrap(true) end
        d.yes = UI:Button(d, L["Ja"], 120, 24, function() d:Hide(); Sn:RefillAnswer(true) end, "primary")
        d.yes:SetPoint("BOTTOMLEFT", 14, 14)
        d.no = UI:Button(d, L["Nein"], 120, 24, function() d:Hide(); Sn:RefillAnswer(false) end)
        d.no:SetPoint("LEFT", d.yes, "RIGHT", 8, 0)
        if d.EnableKeyboard then
            d:EnableKeyboard(true)
            d:SetScript("OnKeyDown", function(self, key)
                if key == "ENTER" then self:SetPropagateKeyboardInput(false); self:Hide(); Sn:RefillAnswer(true)
                elseif key == "ESCAPE" then self:SetPropagateKeyboardInput(false); self:Hide(); Sn:RefillAnswer(false)
                else self:SetPropagateKeyboardInput(true) end
            end)
        end
        Sn.refillDlg = d
    end
    d.text:SetText(text)
    d:Show()
end
