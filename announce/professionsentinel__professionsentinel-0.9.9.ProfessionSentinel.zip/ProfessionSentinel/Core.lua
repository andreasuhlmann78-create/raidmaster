local ADDON, ns = ...
local L = ns.L

ns.ADDON = ADDON
ns.Recipes = {}        -- array of recipe tables
ns.BySpell = {}        -- spellID -> recipe
ns.ByProf = {}         -- skillLineID -> { recipes... }
ns.ByRecipeItem = {}   -- recipe itemID -> recipe
ns.ByOutput = {}       -- crafted itemID -> { recipes... }
ns.ByName = {}         -- lower-case name (de/en) -> recipe
ns.ProfById = {}
ns.Professions = ns.Professions or {}
ns.Items = ns.Items or {}
ns.NPCs = ns.NPCs or {}
ns.DataMeta = ns.DataMeta or {}

-- Source bits (must match gen_addon_data.py)
ns.SRC = { TRAINER = 1, AUTO = 2, VENDOR = 4, DROP = 8, WORLDDROP = 16, QUEST = 32, CONTAINER = 64, UNKNOWN = 128 }

-- Item quality colours: grey, white, green, blue, purple, legendary, artifact
ns.QUALITY_HEX = { [0] = "9d9d9d", [1] = "ffffff", [2] = "1eff00", [3] = "0070dd", [4] = "a335ee", [5] = "ff8000", [6] = "e6cc80" }

function ns.QualityRGB(q)
    local hex = ns.QUALITY_HEX[q or 1] or "ffffff"
    return tonumber(hex:sub(1, 2), 16) / 255, tonumber(hex:sub(3, 4), 16) / 255, tonumber(hex:sub(5, 6), 16) / 255
end

function ns.Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff3fc7ebProfession|r|cffffd100Sentinel|r: " .. tostring(msg))
end

function ns.FlavorName()
    if ns.IsForever then return L.FLAVOR_FOREVER end
    if ns.IsEra then return L.FLAVOR_ERA end
    if ns.IsRetail then return L.FLAVOR_RETAIL end
    return "?"
end

---------------------------------------------------------------------------
-- API compatibility helpers
---------------------------------------------------------------------------
function ns.GetItemIcon(itemID)
    if C_Item and C_Item.GetItemIconByID then
        local icon = C_Item.GetItemIconByID(itemID)
        if icon then return icon end
    end
    if GetItemIcon then return GetItemIcon(itemID) end
    return 134400 -- question mark
end

function ns.GetSpellIcon(spellID)
    if C_Spell and C_Spell.GetSpellTexture then
        local t = C_Spell.GetSpellTexture(spellID)
        if t then return t end
    end
    if GetSpellTexture then return GetSpellTexture(spellID) end
    return 134400
end

function ns.GetItemLink(itemID)
    if C_Item and C_Item.GetItemInfo then return (select(2, C_Item.GetItemInfo(itemID))) end
    if GetItemInfo then return (select(2, GetItemInfo(itemID))) end
end

function ns.GetItemCount(itemID)
    if C_Item and C_Item.GetItemCount then return C_Item.GetItemCount(itemID, true) or 0 end
    if GetItemCount then return GetItemCount(itemID, true) or 0 end
    return 0
end

-- Names: the data ships German names; on other clients prefer the live client name.
function ns.ItemName(itemID)
    local d = ns.Items[itemID]
    if not ns.isGerman then
        local name
        if C_Item and C_Item.GetItemNameByID then name = C_Item.GetItemNameByID(itemID)
        elseif GetItemInfo then name = GetItemInfo(itemID) end
        if name then return name end
    end
    return d and d[1] or ("Item " .. itemID)
end

function ns.ItemQuality(itemID)
    local d = ns.Items[itemID]
    return d and d[2] or 1
end

function ns.RecipeName(r)
    if ns.isGerman then return r.name end
    return (r.nameEN and r.nameEN ~= "") and r.nameEN or r.name
end

function ns.ProfName(profID)
    local p = ns.ProfById[profID]
    if not p then return "?" end
    if ns.isGerman then return p.name end
    if ns.ProfessionNamesEN[profID] then return ns.ProfessionNamesEN[profID] end
    -- Retail expansion lines: the client's own name in its language
    if C_TradeSkillUI and C_TradeSkillUI.GetProfessionInfoBySkillLineID then
        local ok, info = pcall(C_TradeSkillUI.GetProfessionInfoBySkillLineID, profID)
        if ok and type(info) == "table" and info.professionName and info.professionName ~= "" then return info.professionName end
    end
    return p.name
end

---------------------------------------------------------------------------
-- Learned state (single place, test mode can override it)
---------------------------------------------------------------------------
function ns.IsLearned(r)
    if ns.Sim and ns.Sim.known == "all" then return true end
    if ns.Sim and ns.Sim.known == "none" then return false end
    return ns.Scan and ns.Scan:IsKnown(r.spell) or false
end

---------------------------------------------------------------------------
-- Build lookup tables from the compact generated rows
---------------------------------------------------------------------------
local indexed = false
local function BuildIndex()
    if indexed or not ns.RecipeRows then return end
    indexed = true
    for _, p in ipairs(ns.Professions) do
        ns.ProfById[p.id] = p
        ns.ByProf[p.id] = {}
    end
    for i, row in ipairs(ns.RecipeRows) do
        local r = {
            spell = row[1], prof = row[2], name = row[3], nameEN = row[4], cat = row[5], catOrder = row[6],
            req = row[7], yellow = row[8], green = row[9], grey = row[10],
            out = row[11] ~= 0 and row[11] or nil, outMin = row[12], outMax = row[13],
            src = row[14], isNew = row[15] == 1, ench = row[16] == 1,
            reagents = row[17], recipeItems = row[18], skillUps = row[19] or 1, learnLevel = row[20], index = i,
        }
        -- Rarity: recipe item first, otherwise the crafted item.
        local q
        if r.recipeItems[1] then q = ns.ItemQuality(r.recipeItems[1].id) end
        if not q and r.out then q = ns.ItemQuality(r.out) end
        r.quality = q or 1
        r.searchText = (r.name .. " " .. (r.nameEN or "") .. " " .. (r.cat or "")):lower()
        ns.Recipes[#ns.Recipes + 1] = r
        ns.BySpell[r.spell] = r
        if ns.ByProf[r.prof] then table.insert(ns.ByProf[r.prof], r) end
        for _, ri in ipairs(r.recipeItems) do ns.ByRecipeItem[ri.id] = r end
        if r.out then
            ns.ByOutput[r.out] = ns.ByOutput[r.out] or {}
            table.insert(ns.ByOutput[r.out], r)
        end
        ns.ByReagent = ns.ByReagent or {}
        for k = 1, #r.reagents, 2 do
            local id = r.reagents[k]
            ns.ByReagent[id] = ns.ByReagent[id] or {}
            table.insert(ns.ByReagent[id], r)
        end
        ns.ByName[r.name:lower()] = r
        if r.nameEN and r.nameEN ~= "" then ns.ByName[r.nameEN:lower()] = r end
    end
    -- Sort like the client window: category order, then skill (highest first), then name.
    for _, list in pairs(ns.ByProf) do
        table.sort(list, function(a, b)
            if (a.cat or "") ~= (b.cat or "") then
                if a.catOrder ~= b.catOrder then return a.catOrder < b.catOrder end
                return (a.cat or "") < (b.cat or "")
            end
            if a.yellow ~= b.yellow then return a.yellow > b.yellow end
            return a.name < b.name
        end)
    end
end
ns.BuildIndex = BuildIndex

---------------------------------------------------------------------------
-- Saved variables
---------------------------------------------------------------------------
local DEFAULTS = {
    tooltip = true,
    lifeline = true,
    best = true,
    panelOpen = true,
    filters = { missing = false },
    collapsed = {},
    chars = {},
    vzMarkup = 20,      -- selling enchants: surcharge on the material cost in %
    vzMinProfit = 0,    -- selling enchants: at least this much profit per enchant (copper)
    deMargin = 20,      -- disenchanting: minimum margin in % for the sniper prices
    recipeAlert = true, -- alarm when a missing recipe is in the AH (AHSentinel scan)
    todayCrates = false, -- WoW Forever: best Waylaid Crate (gold per favor) in "craft today" (off by default)
    guildShare = true,  -- share known recipes and cooldowns with the guild
}

local function CopyDefaults(src, dst)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then dst[k] = {} end
            CopyDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

---------------------------------------------------------------------------
-- Reputation needed for a recipe item (fa = faction id, fr = standing 4 friendly .. 7 exalted)
---------------------------------------------------------------------------
-- returns: text "Argentumdämmerung – Wohlwollend", met (true/false/nil = unknown)
function ns.RepInfo(fa, fr)
    if not fa or fa == 0 then return nil end
    local name, standing
    if GetFactionInfoByID then
        local ok, n, _, st = pcall(GetFactionInfoByID, fa)
        if ok and n and n ~= "" then name, standing = n, st end
    end
    -- modern client (WoW Forever, Retail): C_Reputation.GetFactionDataByID; reaction uses the same scale
    -- as the old standingID (1 hated .. 8 exalted)
    if not standing and C_Reputation and C_Reputation.GetFactionDataByID then
        local ok, d = pcall(C_Reputation.GetFactionDataByID, fa)
        if ok and type(d) == "table" and d.name and d.name ~= "" then name, standing = d.name, d.reaction end
    end
    name = name or (ns.Factions and ns.Factions[fa]) or ("Faction " .. fa)
    local need = (fr or 0) + 1                       -- client standing id: 1 hated .. 8 exalted
    local label = _G["FACTION_STANDING_LABEL" .. need] or L["REP_" .. need] or tostring(need)
    local met = nil
    if standing then met = standing >= need end
    return name .. " – " .. label, met
end

function ns.RepLine(fa, fr)
    local text, met = ns.RepInfo(fa, fr)
    if not text then return nil end
    local col = met == true and "40c040" or met == false and "ff6060" or "ffd100"
    return "|cff" .. col .. L.REP_NEEDED .. ": " .. text .. "|r"
end

function ns.CharKey()
    local name = UnitName("player") or "?"
    local realm = GetRealmName and GetRealmName() or ""
    return name .. "-" .. realm
end

function ns.Char()
    return ns.db and ns.db.chars[ns.CharKey()]
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON then
        ProfessionSentinelDB = ProfessionSentinelDB or {}
        ns.db = ProfessionSentinelDB
        CopyDefaults(DEFAULTS, ns.db)
        BuildIndex()
    elseif event == "PLAYER_LOGIN" then
        if not ns.Flavor then
            ns.Print(string.format(L.UNSUPPORTED, ns.Interface or 0))
            return
        end
        local key = ns.CharKey()
        ns.db.chars[key] = ns.db.chars[key] or { known = {}, profs = {} }
        local c = ns.db.chars[key]
        c.known = c.known or {}
        c.profs = c.profs or {}
        local _, class = UnitClass("player")
        c.class = class
        c.faction = UnitFactionGroup("player")
        c.flavor = ns.Flavor
        if ns.Scan then ns.Scan:Init() end
    end
end)

-- Test mode and self-test only for the developer (GoldSentinelDev.lua: BattleTag check, same as AHSentinel)
function ns.IsDev()
    local D = _G.GoldSentinelDev
    return D and D.IsDev and D:IsDev() or false
end

local function RequireDev()
    local D = _G.GoldSentinelDev
    if D and D.Require then return D:Require("ProfessionSentinel") end
    return false
end

SLASH_PROFESSIONSENTINEL1 = "/ps"
SLASH_PROFESSIONSENTINEL2 = "/professionsentinel"
SlashCmdList.PROFESSIONSENTINEL = function(msg)
    msg = (msg or ""):lower():match("^%s*(.-)%s*$")
    if not ns.Flavor then
        ns.Print(string.format(L.UNSUPPORTED, ns.Interface or 0))
        return
    end
    if msg == "test" then
        if ns.TestMode and RequireDev() then ns.TestMode:Toggle() end
    elseif msg == "selftest" then
        if ns.TestMode and RequireDev() then ns.TestMode:RunSelfTest(true) end
    elseif msg == "autotest" or msg:match("^autotest%s") then
        if ns.AutoTest and RequireDev() then ns.AutoTest:Command(msg:match("^autotest%s+(.+)$")) end
    elseif msg == "line" then
        ns.db.lifeline = not ns.db.lifeline
        ns.Print(L.LL_OPTION .. ": " .. (ns.db.lifeline and "|cff40c040an/on|r" or "|cffff4040aus/off|r"))
        if ns.Lifeline then ns.Lifeline.RefreshBlizzard() end
        if ns.UI then ns.UI:Refresh() end
    elseif msg == "heute" or msg == "today" then
        ns.db.panelMode = "ranking"
        if ns.UI then
            if ns.UI.IsShown and ns.UI:IsShown() then ns.UI:Refresh() else ns.UI:Toggle() end
        end
    elseif msg == "alarm" then
        ns.db.recipeAlert = not (ns.db.recipeAlert ~= false)
        ns.Print(L.ALERT_OPTION .. ": " .. (ns.db.recipeAlert and "|cff40c040an/on|r" or "|cffff4040aus/off|r"))
    elseif msg == "kisten" or msg == "crates" then
        if ns.Favor and ns.Favor.Active() then ns.Favor.ToggleTodayCrates() else ns.Print(L.FAVOR_ONLY_FOREVER) end
    elseif msg == "ziel" or msg == "goal" then
        if ns.Disenchant then ns.Disenchant.AskGoal() end
    elseif msg == "help" or msg == "?" then
        ns.Print(ns.IsDev() and L.TEST_HELP or L.HELP)
    else
        if ns.UI then ns.UI:Toggle() end
    end
end
