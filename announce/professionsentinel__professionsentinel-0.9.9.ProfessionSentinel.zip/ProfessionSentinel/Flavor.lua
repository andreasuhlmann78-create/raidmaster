local _, ns = ...

-- Detects which game version is running and sets ns.Flavor:
--   "forever" = WoW Forever (modern client, project WOW_PROJECT_CAMELOT / interface 16000-19999)
--   "era"     = Classic Era / Hardcore (old API)
--   "retail"  = Retail (e.g. 120105 = 12.1.5 Midnight)
--   nil       = not supported (TBC, Wrath, Cata, MoP Classic: the addon stays idle and says so once)
-- The detection comes from GoldSentinelGame.lua, shared by all GoldSentinel addons (it loads before this file).
-- Without it (should never happen) the addon's own detection below is used, exactly as before.
-- Only the matching data file (Data_Forever.lua / Data_Era.lua / Data_Retail.lua) loads its tables.

local G = _G.GoldSentinelGame
local SUPPORTED = { forever = true, era = true, retail = true }

local flavor
if type(G) == "table" and G.flavor then
    ns.ClientVersion = G.gameVersion
    ns.ClientBuild = G.build
    ns.Interface = G.toc
    flavor = SUPPORTED[G.flavor] and G.flavor or nil
else
    -- own detection (fallback)
    local version, build, _, interface = GetBuildInfo()
    interface = tonumber(interface) or 0
    ns.ClientVersion = version
    ns.ClientBuild = build
    ns.Interface = interface
    if (WOW_PROJECT_CAMELOT and WOW_PROJECT_ID == WOW_PROJECT_CAMELOT) or (interface >= 16000 and interface < 17000) then
        flavor = "forever"
    elseif interface >= 11500 and interface < 11600 then
        flavor = "era"
    elseif interface >= 100000 or (WOW_PROJECT_MAINLINE and WOW_PROJECT_ID == WOW_PROJECT_MAINLINE) then
        flavor = "retail"
    end
end

ns.Flavor = flavor
ns.IsForever = flavor == "forever"
ns.IsEra = flavor == "era"
ns.IsRetail = flavor == "retail"

-- Which profession window / API the client uses: Forever runs on the modern client like Retail
if type(G) == "table" and G.IsModern ~= nil then
    ns.UsesModernProfessions = G.IsModern == true and flavor ~= nil
else
    ns.UsesModernProfessions = ns.IsForever or ns.IsRetail
end

-- Retail has no QuestieDB data: no vendor/drop/quest sources, no trainer locations
ns.HasSourceData = not ns.IsRetail
