-- ThreatSentinel - Sync.lua
-- Austausch zwischen Spielern mit ThreatSentinel: Rollen, Spotts, Abklingzeiten, Meldungen.

local ADDON, ns = ...
local L = ns.L

local S = {}
ns.Sync = S
table.insert(ns.modules, S)

local PREFIX = "ThreatSentinel"
local ROLE_TTL = 90
local CLAIM_TIME = 4

S.claims = {}  -- guid -> { name, t }
S.cd = {}      -- name -> Zeitpunkt, ab dem der Spott wieder bereit ist

local PALETTE = {
	{ 0.25, 0.65, 1 },
	{ 0.75, 0.35, 1 },
	{ 0.2, 0.9, 0.6 },
	{ 1, 0.45, 0.8 },
	{ 0.95, 0.95, 0.35 },
}

local lastHello = 0

local function Channel()
	if IsInRaid() then return "RAID" end
	if IsInGroup() then return "PARTY" end
end

function S:Send(msg)
	if not ns.db.sync then return end
	local ch = Channel()
	if not ch then return end
	if C_ChatInfo and C_ChatInfo.SendAddonMessage then
		C_ChatInfo.SendAddonMessage(PREFIX, msg, ch)
	elseif SendAddonMessage then
		SendAddonMessage(PREFIX, msg, ch)
	end
end

function S:Init()
	if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
		C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
	elseif RegisterAddonMessagePrefix then
		RegisterAddonMessagePrefix(PREFIX)
	end
end

function S:Login()
	C_Timer.NewTicker(20, function() S:Hello() end)
	C_Timer.After(3, function() S:Hello(true) end)
end

function S:Hello(force)
	local now = GetTime()
	if not force and now - lastHello < 5 then return end
	lastHello = now
	self:Send("H:" .. ns:MyRole() .. ":" .. ns.version)
end

-- Eigener Spott gewirkt: Ziel als übernommen melden, Abklingzeit mitsenden
function S:OnTaunt(guid)
	if not guid then return end
	C_Timer.After(0.2, function()
		local cd = math.floor(ns.SpellCD(ns.tauntSpell) + 0.5)
		S:Send("T:" .. guid .. ":" .. cd)
	end)
end

function S:IsFresh(name)
	local r = ns.syncRoles[name]
	return r and (GetTime() - r.t) < ROLE_TTL
end

function S:IsTank(name)
	if name == ns.playerName then return ns:IsTankStance() end
	local r = ns.syncRoles[name]
	return r and r.role == "TANK" and (GetTime() - r.t) < ROLE_TTL or false
end

function S:Tanks()
	local list = {}
	if ns:IsTankStance() then list[#list + 1] = ns.playerName end
	for name, r in pairs(ns.syncRoles) do
		if r.role == "TANK" and GetTime() - r.t < ROLE_TTL and ns:InGroupByName(name) then
			list[#list + 1] = name
		end
	end
	table.sort(list)
	return list
end

function S:NumTanks()
	if not ns.db.sync then return 0 end
	return #self:Tanks()
end

function S:TankColor(name)
	if not name then return nil end
	for i, n in ipairs(self:Tanks()) do
		if n == name then return PALETTE[((i - 1) % #PALETTE) + 1] end
	end
	if ns.testMode then return PALETTE[2] end
end

function S:OtherTankReady()
	if not ns.db.sync then return nil end
	local now = GetTime()
	for name, r in pairs(ns.syncRoles) do
		if r.role == "TANK" and now - r.t < ROLE_TTL and ns:InGroupByName(name)
			and not UnitIsDeadOrGhost(name) and (not self.cd[name] or self.cd[name] <= now) then
			return name
		end
	end
end

function S:Claim(guid)
	if not ns.db.sync or not guid then return nil end
	local c = self.claims[guid]
	if c and GetTime() - c.t < CLAIM_TIME then return c.name end
end

function S:Users()
	local list = {}
	for name, r in pairs(ns.syncRoles) do
		if GetTime() - r.t < ROLE_TTL and ns:InGroupByName(name) then
			list[#list + 1] = { name = name, role = r.role, ver = r.ver }
		end
	end
	table.sort(list, function(a, b) return a.name < b.name end)
	return list
end

ns:On("CHAT_MSG_ADDON", function(_, prefix, msg, _, sender)
	if prefix ~= PREFIX or not ns.db or not ns.db.sync then return end
	local name = Ambiguate(sender or "", "none")
	if name == ns.playerName then return end
	local cmd, rest = (msg or ""):match("^(%a):(.*)$")
	if not cmd then return end
	local now = GetTime()

	if cmd == "H" then
		local role, ver = rest:match("^(%u+):?(.*)$")
		if role then
			ns.syncRoles[name] = { role = role, t = now, ver = ver }
			ns:ClearRoleCache()
		end
	elseif cmd == "T" then
		local guid, cd = rest:match("^([^:]+):?(%d*)$")
		if guid then S.claims[guid] = { name = name, t = now } end
		S.cd[name] = now + (tonumber(cd) or 10)
		local r = ns.syncRoles[name]
		if not r then ns.syncRoles[name] = { role = "TANK", t = now } else r.t = now end
	elseif cmd == "R" then
		ns.Alerts:RemoteResist(name)
	elseif cmd == "X" then
		ns.Alerts:RemoteCC(name, rest)
	end
end)

ns:On("GROUP_ROSTER_UPDATE", function()
	C_Timer.After(2, function() S:Hello() end)
end)

ns:On("PLAYER_REGEN_ENABLED", function()
	local now = GetTime()
	for guid, c in pairs(S.claims) do
		if now - c.t > 30 then S.claims[guid] = nil end
	end
end)
