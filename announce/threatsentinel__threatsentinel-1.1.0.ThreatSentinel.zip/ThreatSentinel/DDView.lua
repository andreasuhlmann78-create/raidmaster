-- ThreatSentinel - DDView.lua
-- Kleiner Balken für Spieler, die nicht tanken: eigene Bedrohung auf dem Ziel, Warnung ab Schwelle.

local ADDON, ns = ...
local L = ns.L

local D = {}
ns.DD = D
table.insert(ns.modules, D)

local WHITE = "Interface\\Buttons\\WHITE8X8"

function D:Init()
	local f = CreateFrame("Frame", "ThreatSentinelDD", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	f:SetSize(190, 22)
	f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	f:SetBackdropColor(0.03, 0.04, 0.06, 0.6)
	f:SetBackdropBorderColor(0.25, 0.65, 1, 0.5)
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", function(self) self:StartMoving() end)
	f:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		local p, _, rp, x, y = self:GetPoint()
		ns.db.ddPoint = { p, "UIParent", rp, x, y }
	end)

	f.bar = CreateFrame("StatusBar", nil, f)
	f.bar:SetPoint("TOPLEFT", 2, -2)
	f.bar:SetPoint("BOTTOMRIGHT", -2, 2)
	f.bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
	f.bar:SetMinMaxValues(0, 100)
	f.text = f.bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	f.text:SetPoint("CENTER")
	f:Hide()
	self.f = f
	self:ApplySettings()
end

function D:ApplySettings()
	local f, db = self.f, ns.db
	local p = db.ddPoint
	f:ClearAllPoints()
	f:SetPoint(p[1], UIParent, p[3], p[4], p[5])
	f:SetScale(db.hudScale)
	f:EnableMouse(not db.hudLocked)
end

function D:Show(value, isTanking)
	local f, db = self.f, ns.db
	value = math.max(0, value or 0)
	f.bar:SetValue(math.min(value, 100))
	local r, g, b
	if isTanking then
		r, g, b = 1, 0.1, 0.1
		f.text:SetText(L.DD_AGGRO)
	else
		if value >= db.ddWarn then r, g, b = 1, 0.15, 0.15
		elseif value >= db.ddWarn * 0.75 then r, g, b = 1, 0.8, 0.1
		else r, g, b = 0.2, 0.85, 0.3 end
		f.text:SetText(string.format(L.DD_THREAT, math.floor(value + 0.5)))
	end
	f.bar:SetStatusBarColor(r, g, b)

	local warn = isTanking or value >= db.ddWarn
	if warn and not self.warned and db.ddSound and not ns.testMode then
		self.warned = true
		ns.Alerts:Play(db.soundDD, "ddWarn")
	elseif not warn and value < db.ddWarn - 10 then
		self.warned = false
	end
	f:Show()
end

function D:Tick()
	local f, db = self.f, ns.db
	if not f then return end

	if ns.testMode and db.ddView then
		local v = (math.sin(GetTime() * 0.8) * 0.5 + 0.5) * 105
		self:Show(v, v > 100)
		return
	end

	if not db.enabled or not db.ddView or ns:IsTankStance() then f:Hide() return end

	if not db.hudLocked and not UnitAffectingCombat("player") then
		f.bar:SetValue(0)
		f.text:SetText(L.DD_DRAG)
		f:Show()
		return
	end

	if not IsInGroup() or not UnitAffectingCombat("player") or not UnitCanAttack("player", "target") then
		f:Hide()
		return
	end

	local isTanking, status, scaled = UnitDetailedThreatSituation("player", "target")
	if not status and not scaled then f:Hide() return end
	self:Show(scaled or 0, isTanking)
end
