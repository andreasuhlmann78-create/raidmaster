-- ThreatSentinel - TestMode.lua
-- Spielt an sichtbaren Plaketten alle Zustände durch, damit man Farben und Deckkraft
-- ausserhalb eines Dungeons einstellen kann.

local ADDON, ns = ...
local L = ns.L

local TM = {}
ns.Test = TM
table.insert(ns.modules, TM)

local DEMO = { "HELD", "WARN", "LOOSE_DD", "LOOSE_HEALER", "OTHERTANK", "LOOSE_CLAIMED", "LOOSE_FAR" }
local PHASE_TIME = 4

function TM:Toggle(on)
	if on == nil then on = not ns.testMode end
	ns.testMode = on
	if on then
		self.start = GetTime()
		ns:Print(L.TEST_ON)
	else
		ns:Print(L.TEST_OFF)
		for unit, m in pairs(ns.mobs) do
			ns.Plates:Restore(unit)
			m.state, m.testKind, m.alerted = nil, nil, false
		end
		ns.Alerts:ClearCenter()
		ns.HUD:Update(nil, nil)
	end
	if ns.Options and ns.Options.RefreshTestButton then ns.Options:RefreshTestButton() end
end

local function DeficitText()
	if ns.class == "WARRIOR" then return L.DEFICIT_WARRIOR end
	if ns.class == "DRUID" then return L.DEFICIT_DRUID end
	return L.DEFICIT_OTHER
end

function TM:Tick(mobs)
	local phase = math.floor((GetTime() - (self.start or GetTime())) / PHASE_TIME)
	local units = {}
	for unit in pairs(mobs) do units[#units + 1] = unit end
	table.sort(units)

	local loose = {}
	for i, unit in ipairs(units) do
		local m = mobs[unit]
		local kind = DEMO[((i + phase - 1) % #DEMO) + 1]
		local prevKind = m.testKind
		m.name = UnitName(unit)
		m.sunder = (ns.class == "WARRIOR") and ((i + phase) % 6) or 0
		m.claimedBy, m.muted, m.far, m.hint, m.tauntCD = nil, false, false, nil, 0
		m.victim, m.victimRole, m.otherTank = nil, nil, nil

		if kind == "HELD" then
			m.state = "HELD"
		elseif kind == "WARN" then
			m.state = "WARN"
		elseif kind == "OTHERTANK" then
			m.state = "OTHERTANK"
			m.otherTank = "Grimbar"
		else
			m.state = "LOOSE"
			m.victim, m.victimRole = "Torben", "DAMAGER"
			if kind == "LOOSE_HEALER" then
				m.victim, m.victimRole = "Anna", "HEALER"
				m.hint = L.TAUNT_READY
			elseif kind == "LOOSE_CLAIMED" then
				m.claimedBy = "Grimbar"
				m.hint = string.format(L.CLAIMED, "Grimbar")
			elseif kind == "LOOSE_FAR" then
				m.far = true
				m.hint = L.TOO_FAR
			else
				m.hint = DeficitText()
			end
		end

		if prevKind and prevKind:find("LOOSE") and kind == "HELD" then ns.Plates:Flash(unit) end
		m.testKind = kind
		ns.Plates:Update(unit, m)
		if m.state == "LOOSE" and not m.claimedBy then loose[#loose + 1] = m end
	end

	local extras = {}
	if #units == 0 then extras[#extras + 1] = { text = L.TEST_NO_PLATES, c = { 1, 0.8, 0.2 } } end
	if ns.db.healerRange then extras[#extras + 1] = { text = string.format(L.HEALER_OOR, "Anna"), c = { 1, 0.8, 0.2 } } end
	if ns.db.aoeHint and phase % 3 == 2 then
		ns.Alerts:Center(string.format(L.AOE_HINT, ns.aoeSpell or L.AOE_GENERIC), { 1, 0.5, 0 }, 0.6, "aoe")
	end
	ns.HUD:Update(loose, extras)
end
