-- LevelPilot - Automatische Routenplanung
-- Ablauf:
--   1) Kandidaten: alle Quests im passenden Levelbereich fuer Volk/Klasse (bei Levelaufstieg neu)
--   2) Aufgaben: annehmbare Quests (Questgeber), offene Ziele, fertige Quests (Abgabe)
--   3) Fokus-Zone: Zone mit dem besten Verhaeltnis Nutzen / Reiseweg
--   4) Reihenfolge: naechster-Nachbar ueber Weglaengen, Annehmen/Abgeben bevorzugt
--   5) Reise: Zonenwechsel ueber das Wegenetz, lange Strecken per Flugpunkt
--   Speedrun: laesst langsame/ineffiziente Quests aus (EP pro Zeit), Klassenquests bleiben immer.
--   Dungeons: Dungeon-Quests werden mitgenommen, wenn man ohnehin beim Questgeber ist; der
--   Lauf selbst wird als ein Schritt eingeplant, sobald Level und Anzahl der Quests passen.

local _, LP = ...
local L = LP.L
local P = {}
LP:RegisterModule("Planner", P)

P.steps = {}
P.focus = nil
P.status = ""
local candidates = {}
local candLevel = -1
local MAX_STEPS = 12
local NOT_OFFERED_SECS = 900

------------------------------------------------------------------------
-- Status der Quests im Spiel
------------------------------------------------------------------------
local inLog = {}     -- [id] = { complete, index, title, objDone = {..} }

local function ScanLog()
    wipe(inLog)
    for _, q in ipairs(LP.API.Quests()) do
        local objs = LP.API.Objectives(q.index)
        local complete = q.complete
        if not complete and #objs == 0 then complete = true end
        local objDone = {}
        for o, ob in ipairs(objs) do objDone[o] = ob.finished end
        inLog[q.id] = { complete = complete, index = q.index, title = q.title, objDone = objDone, failed = q.failed }
    end
end
P.inLog = inLog

local function Done(id)
    if LP.char.turnedIn[id] then return true end
    return LP.API.IsQuestDone(id)
end
P.IsDone = Done

local function GreyRange(level)
    return LP.API.GreenRange(level)
end

------------------------------------------------------------------------
-- 1) Kandidaten
------------------------------------------------------------------------
-- 3.12.33 LP-D1: Kandidaten bei der naechsten Planung neu bestimmen (dort in Portionen)
function P:InvalidateCandidates() candLevel = -1 end

-- 3.12.34 PF-A-Rest: muessen vor der Planung erst Zwischenspeicher aufgebaut werden (Kandidaten, Dienst-NPCs)?
function P:Cold()
    local level = LP:PlayerLevel() or 1
    if level ~= candLevel then return true end
    local Q = LP.QuestDB
    return Q and Q.ServicesReady and not Q:ServicesReady() or false
end

function P:BuildCandidates()
    local level = LP:PlayerLevel() or 1
    wipe(candidates)
    local QDB = LP.QuestDB
    local f = LP:PlayerFaction() == "Horde" and "H" or "A"
    for ci, id in ipairs(QDB:AllIds()) do
        if ci % 20 == 0 then LP:Yield("plan") end
        local info = QDB:QuickInfo(id)
        if info then
            local ql = info.level or 0
            if ql <= 0 then ql = info.reqLevel or 1 end
            if (info.reqLevel or 0) <= level + 1 and ql <= level + 4 and ql >= level - 12 then
                local ok = true
                if info.faction and info.faction ~= f then ok = false end
                if ok then ok = QDB:RaceOk(info.races, info.raceSys) end
                if ok and info.classes and info.classes ~= 0 and QDB.classBit then
                    ok = LP.HasBit(info.classes, QDB.classBit)
                end
                if ok and info.specialFlags and LP.HasBit(info.specialFlags, 1) then ok = false end
                if ok and info.dungeon and not P:DungeonUsable(info.dungeon) then ok = false end
                if ok then candidates[#candidates + 1] = id end
            end
        end
    end
    candLevel = level
    self:BuildProtected()
end

------------------------------------------------------------------------
-- 2) Verfuegbarkeit einer Quest
------------------------------------------------------------------------
local function AllDone(list)
    if type(list) ~= "table" then return true end
    for _, id in ipairs(list) do if not Done(id) then return false end end
    return true
end

local function AnyDone(list)
    if type(list) ~= "table" or #list == 0 then return true end
    for _, id in ipairs(list) do if Done(id) then return true end end
    return false
end

local function NoneTaken(list)
    if type(list) ~= "table" then return true end
    for _, id in ipairs(list) do
        if Done(id) or inLog[id] then return false end
    end
    return true
end

-- Heimatgebiete der Fraktionen: Quests ohne Volksbeschraenkung, deren Questgeber oder Abgabe dort steht,
-- sind fuer die andere Fraktion praktisch nicht machbar (feindliche Wachen, feindliche NPCs).
-- Neutrale Orte (Beutebucht, Ratschet, Gadgetzan ...) liegen in umkaempften Zonen und sind nicht betroffen.
local HOME_ZONES = {
    Alliance = { [1429] = true, [1436] = true, [1433] = true, [1431] = true, [1426] = true, [1432] = true,
                 [1438] = true, [1439] = true, [1437] = true, [1453] = true, [1455] = true, [1457] = true },
    Horde    = { [1411] = true, [1412] = true, [1420] = true, [1421] = true, [1454] = true, [1456] = true, [1458] = true },
}
local BATTLEGROUNDS = { [1459] = true, [1460] = true, [1461] = true }   -- Alteractal, Warsongschlucht, Arathibecken

local function InEnemyHome(q)
    local mine = LP:PlayerFaction()
    local enemy = HOME_ZONES[mine == "Horde" and "Alliance" or "Horde"]
    for _, list in ipairs({ q.starts, q.ends }) do
        for _, p in ipairs(list or {}) do
            if enemy[p[1]] then return true end
        end
    end
    return false
end

local function OnBattleground(q)
    for _, list in ipairs({ q.starts, q.ends }) do
        for _, p in ipairs(list or {}) do if BATTLEGROUNDS[p[1]] then return true end end
    end
    for _, o in ipairs(q.objectives or {}) do
        for _, p in ipairs(o.spots or {}) do if BATTLEGROUNDS[p[1]] then return true end end
    end
    return false
end
P.InEnemyHome, P.OnBattleground = InEnemyHome, OnBattleground

-- Spenden und Kriegseinsatz (Stoffspenden, "Die Horde braucht ..."): Questlevel 55-60, aber ab Level 1-20
function P.IsDonation(q)
    local ql = q and q.level or 0
    return ql >= 55 and (q.reqLevel or 0) > 0 and q.reqLevel <= 20
end

P.QUEST_ABOVE = 2
function P:IsAvailable(q, level)
    local id = q.id
    if Done(id) or inLog[id] then return false end
    if LP.char.ignored[id] then return false end
    local no = LP.char.notOffered[id]
    if no and LP:Now() - no < NOT_OFFERED_SECS then return false end
    if (q.reqLevel or 0) > level then return false end
    local ql = q.level or 0
    -- 3.12.74 ROUTE-Q R2 (Supervisor 18:58): höchstens Stufe + P.QUEST_ABOVE (vorher + 3: orange Quests drei Stufen darüber)
    if ql > 0 and ql > level + P.QUEST_ABOVE then return false end
    if ql > 0 and ql < level - GreyRange(level) then return false end
    if not LP.QuestDB:FitsPlayer(q) then return false end
    if q.repeatable or q.itemStart then return false end
    if P.IsDonation(q) then return false end
    if #q.starts == 0 then return false end
    if q.pvp or OnBattleground(q) then return false end                -- Schlachtfelder: kein Questen
    if (q.races or 0) == 0 and InEnemyHome(q) then return false end   -- Gebiet der anderen Fraktion
    if q.skill or q.minRep then return false end
    if q.parent and q.parent ~= 0 and not inLog[q.parent] then return false end
    if not AllDone(q.pre) then return false end
    if not AnyDone(q.preAny) then return false end
    if not NoneTaken(q.exclusive) then return false end
    if q.nextInChain and q.nextInChain ~= 0 and (Done(q.nextInChain) or inLog[q.nextInChain]) then return false end
    return true
end

------------------------------------------------------------------------
-- Hilfen: Punkte & Entfernungen
------------------------------------------------------------------------
local function WorldOf(pt)
    if not pt then return nil end
    return LP.Geo:ToWorld(pt[1], pt[2], pt[3])
end

-- naechster Punkt einer Liste zum Bezugspunkt (Weltkoordinaten)
local function NearestPoint(points, inst, n, w)
    local best, bestD, bestW
    for _, pt in ipairs(points or {}) do
        local i, pn, pw = WorldOf(pt)
        if i then
            local d
            if i == inst then d = LP.Geo:Dist(n, w, pn, pw) else d = 1e6 end
            if not bestD or d < bestD then best, bestD, bestW = pt, d, { i, pn, pw } end
        end
    end
    return best, bestD, bestW
end

------------------------------------------------------------------------
-- 3) Aufgaben sammeln
------------------------------------------------------------------------
-- Wert einer Quest nach Abstand zum eigenen Level (gelb/orange am wertvollsten)
local function LevelWeight(qLevel, level)
    if not qLevel or qLevel <= 0 then return 0.8 end
    local d = qLevel - level
    if d >= 4 then return 0.4 end          -- rot: zu schwer
    if d >= 0 then return 1.5 end          -- gelb/orange
    if d >= -3 then return 1.0 end         -- gruen
    if d >= -6 then return 0.5 end         -- fast grau
    return 0.2
end
P.LevelWeight = LevelWeight

------------------------------------------------------------------------
-- Speedrun
------------------------------------------------------------------------
-- Strenge: Quests auslassen, die weniger als x der Grind-EP je Minute bringen
local SPEED_CUTOFF = { [1] = 0.3, [2] = 0.45, [3] = 0.6 }  -- locker / mittel / streng (nur klar langsame Quests)
local SPEED_HUB = 3          -- Questgeber-Ort mit so vielen Quests: keine davon auslassen
local SPEED_NAMES = { [1] = "locker", [2] = "mittel", [3] = "streng" }
P.SPEED_NAMES = SPEED_NAMES
local SPEED_LOW = 5         -- Quests ab 5 Stufen unter dem eigenen Level auslassen
local SPEED_DUNGEON_MIN = 3 -- Dungeon-Lauf im Speedrun erst ab 3 Quests
local RUN_SPEED = 7         -- Yards je Sekunde zu Fuss
local protected = {}
P.speedSkip = {}            -- [questID] = Grund (nur im Speedrun)

function P:IsSpeed() return LP.char.mode == "speed" end

function P:SetMode(mode)
    mode = mode == "speed" and "speed" or "normal"
    if LP.char.mode == mode then return end
    LP.char.mode = mode
    candLevel = -1
    LP:Reply(mode == "speed"       -- Antwort auf den Klick/Befehl des Spielers
        and L["|cffff7a3cSpeedrun|r aktiv: Quests, die weniger EP pro Minute bringen als Grinden, werden ausgelassen – Klassenquests bleiben."]
        or L["Normales Questen aktiv: alle passenden Quests werden eingeplant."])
    self:Replan()
    LP:Fire("MODE_CHANGED", mode)
end

function P:ToggleMode() self:SetMode(self:IsSpeed() and "normal" or "speed") end

local CLASS_LIST = { 1, 2, 4, 8, 16, 64, 128, 256, 1024 }
local function IsClassQuest(classes)
    if not classes or classes == 0 then return false end
    local c = 0
    for _, b in ipairs(CLASS_LIST) do if LP.HasBit(classes, b) then c = c + 1 end end
    return c > 0 and c <= 3
end
P.IsClassQuest = IsClassQuest

-- Klassenquests und alle ihre Vorquests sind im Speedrun geschuetzt
function P:BuildProtected()
    wipe(protected)
    local function mark(id, depth)
        if protected[id] or depth > 8 then return end
        protected[id] = true
        local q = LP.QuestDB:Get(id)
        if not q then return end
        for _, pid in ipairs(type(q.pre) == "table" and q.pre or {}) do mark(pid, depth + 1) end
        for _, pid in ipairs(type(q.preAny) == "table" and q.preAny or {}) do mark(pid, depth + 1) end
    end
    for _, id in ipairs(candidates) do
        local info = LP.QuestDB:QuickInfo(id)
        if info and IsClassQuest(info.classes) then mark(id, 0) end
    end
end

function P:IsProtected(id)
    if protected[id] then return true end
    local q = LP.QuestDB:Get(id)
    return q and IsClassQuest(q.classes) or false
end

-- Geschaetzte Zeit fuer eine Quest ab dem Questgeber: Ziele + Wege + Abgabe (Sekunden)
local SHARED_TRAVEL = 0.6      -- Anteil der Wege zu Zielen/Abgabe, den eine Quest allein traegt
local function QuestSeconds(q, partners)
    local secs = 20
    -- gebuendelt: die Suchzeit teilt man mit den anderen Quests im selben Gebiet
    local share = 1 / (1 + math.min(partners or 0, 3))
    local ci, cn, cw = nil, nil, nil
    if q.starts[1] then ci, cn, cw = LP.Geo:ToWorld(q.starts[1][1], q.starts[1][2], q.starts[1][3]) end
    local function hop(points)
        local best, bi, bn, bw
        for _, pt in ipairs(points or {}) do
            local i, pn, pw = LP.Geo:ToWorld(pt[1], pt[2], pt[3])
            if i then
                -- Wege im Questgebiet teilt man meist mit anderen Quests derselben Gegend
                local d = (ci and i == ci) and LP.Geo:Dist(cn, cw, pn, pw) / RUN_SPEED * SHARED_TRAVEL or 900
                if not best or d < best then best, bi, bn, bw = d, i, pn, pw end
            end
        end
        if best then secs = secs + best ci, cn, cw = bi, bn, bw end
    end
    for _, o in ipairs(q.objectives) do
        local c, _, search = P:ObjectiveCost(o.kind, o.elite, o)
        secs = secs + c - search * (1 - share)
        hop(o.spots)
    end
    hop(q.ends)
    if q.escort then secs = secs + 600 end
    return secs
end

-- EP einer Quest fuer dieses Level (Classic-Abzug fuer niedrige Quests)
-- Grund-EP: im Spiel gemessen (WoW Forever) vor Classic-Tabelle
P.QuestSeconds = function(q, partners) return QuestSeconds(q, partners) end

local function BaseXP(q)
    local ql = (q.level and q.level > 0) and q.level or nil
    if q.xpReal and q.xpRealLvl and (not ql or q.xpRealLvl <= ql + 4) then return q.xpReal, true end
    -- noch nicht selbst abgegeben: Classic-Wert mal dem gemessenen Forever-Faktor (falls schon bekannt)
    local f = LP.Calib and LP.Calib:QuestXPFactor()
    if q.xp and f then return q.xp * f, false end
    return q.xp, false
end
P.BaseXP = BaseXP

local function QuestXPFor(q, level)
    local base = BaseXP(q)
    if not base or base <= 0 then return nil end
    local ql = (q.level and q.level > 0) and q.level or level
    local mult = math.max(1, math.min(10, 2 * (ql - level) + 20)) / 10
    return base * mult
end

-- Monster-EP je Minute beim Grinden auf diesem Level (Classic: 45 + 5 x Level je Kill, ~2 Kills/Min)
-- EP pro Minute beim Grinden: Monster im eigenen Level (45 + 5 x Level EP), etwa 1,5 pro Minute mit Looten,
-- Essen/Trinken und Laufen zwischen den Gegnern
P.KILLS_PER_MIN = nil          -- fester Wert fuer die Testumgebung (sonst Klasse/Messung)
-- Startwerte je Klasse (Kills pro Minute mit Looten, Erholen, Laufen); gemessene Werte haben Vorrang
local CLASS_KPM = { HUNTER = 2.2, WARLOCK = 2.1, MAGE = 1.9, ROGUE = 1.8, WARRIOR = 1.7, PALADIN = 1.7,
                    SHAMAN = 1.8, DRUID = 1.8, PRIEST = 1.6 }
function P:KillsPerMin()
    if P.KILLS_PER_MIN then return P.KILLS_PER_MIN end
    local m = LP.Calib and LP.Calib:KillsPerMin()
    if m then return m end
    local _, class = UnitClass("player")
    return CLASS_KPM[class or ""] or 1.8
end
-- Dauer eines Questziels (Sekunden) und Kills dabei - ein Modell fuer Planung und virtuelle Reise
local OBJ_KILLS = { kill = 8, item = 10 }           -- Kills fuer ein Ziel (Gegenstaende: mit Dropchance)
local OBJ_SEARCH = { kill = 60, item = 90, object = 120, explore = 60 }
local DROP_DEFAULT = 0.5      -- angenommene Stueck je Kill, solange nichts gemessen ist
local SPARSE_SPAWNS = 6       -- weniger Spawnpunkte der Droppenden: man wartet auf das Wiederauftauchen
local SPARSE_FACTOR = 1.8
local ITEM_KILLS_MAX = 80
P.SLOW_KILLS = 25             -- ab so vielen erwarteten Kills fuer einen Gegenstand gilt die Quest als langsam

local spawnCache = {}
local function DropperSpawns(o)
    local key = o.item or 0
    if spawnCache[key] then return spawnCache[key] end
    local N = LevelPilotData and LevelPilotData.N
    local pts = 0
    for _, id in ipairs(o.ids or {}) do
        local npc = N and N[id]
        for _, sp in ipairs(npc and npc.s or {}) do pts = pts + (#sp - 1) / 2 end
    end
    spawnCache[key] = pts
    return pts
end

-- erwartete Kills fuer ein Gegenstands-Ziel: gemessene Droprate (eigene oder anderer Spieler) mal benoetigte
-- Anzahl; sonst Annahme, bei wenigen Spawnpunkten der Droppenden laenger. Zweiter Wert: gemessen?
function P:ItemKills(o, need)
    if not o or not o.item then return OBJ_KILLS.item, false end
    local Ca = LP.Calib
    need = need or (Ca and Ca:Need(o.item))
    local rate = Ca and Ca:DropRate(o.item)
    local kills, measured
    if rate then
        kills, measured = (need or OBJ_KILLS.item * DROP_DEFAULT) / rate, true
    else
        kills = need and need / DROP_DEFAULT or OBJ_KILLS.item
        local sp = DropperSpawns(o)
        if o.ids and #o.ids > 0 and sp > 0 and sp < SPARSE_SPAWNS then kills = kills * SPARSE_FACTOR end
    end
    return math.max(1, math.min(ITEM_KILLS_MAX, kills)), measured
end

-- Liefert Sekunden, Kills und den Anteil Suchzeit (den teilt man mit anderen Zielen im selben Gebiet).
-- o (optional): das Ziel aus der Questdatenbank, need (optional): benoetigte Anzahl aus dem Questlog
function P:ObjectiveCost(kind, elite, o, need)
    local kills = OBJ_KILLS[kind] or 0
    if kind == "item" and o then kills = self:ItemKills(o, need) end
    local search = OBJ_SEARCH[kind] or 120
    local secs = search + kills * 60 / self:KillsPerMin()
    if elite then secs = secs + 600 end
    return secs, kills, search
end

-- Gegenstaende, die selten fallen (Speedrun laesst solche Quests aus)
function P:SlowDrop(q)
    for _, o in ipairs(q and q.objectives or {}) do
        if o.kind == "item" and o.item and not o.elite then
            local k = self:ItemKills(o)
            if k >= self.SLOW_KILLS then return true, k end
        end
    end
    return false
end

------------------------------------------------------------------------
-- Questziele buendeln: liegen Ziele mehrerer Quests im selben Gebiet, erledigt man sie in einem Durchgang
-- (einmal hinlaufen, einmal suchen; Kills zaehlen fuer alle passenden Quests)
------------------------------------------------------------------------
local BUNDLE_R = 300          -- Yards
P.BUNDLE_R = BUNDLE_R
P.BUNDLE_CUT = 0.5      -- Speedrun: gebuendelte Quests erst ab halber Grenze auslassen
local function ObjPoints(o)
    if o._wp then return o._wp end
    local t = {}
    for _, sp in ipairs(o.spots or {}) do
        local i, n, w = LP.Geo:ToWorld(sp[1], sp[2], sp[3])
        if i then t[#t + 1] = { i, n, w } end
    end
    o._wp = t
    return t
end
P.ObjPoints = ObjPoints
local function CellKey(i, cn, cw) return i * 100000000 + (cn + 5000) * 10000 + (cw + 5000) end

-- Raster aller offenen, machbaren Ziele: entries = { {q = Quest, done = {[idx] = true} oder nil}, ... }
function P:BundleIndex(entries, level)
    local idx = {}
    for ei, e in ipairs(entries) do
        local q = e.q
        if ei % 10 == 0 then LP:Yield("plan") end
        for oi, o in ipairs(q.objectives or {}) do
            local ml = o.mobLevel and (o.mobLevel + (o.elite and LP.Danger.ELITE_BONUS or 0))
            local ok = not o.elite and not (e.done and e.done[o.idx or oi]) and (not ml or LP.Danger:OK(ml, level))
            if ok then
                for _, p in ipairs(ObjPoints(o)) do
                    local k = CellKey(p[1], math.floor(p[2] / BUNDLE_R), math.floor(p[3] / BUNDLE_R))
                    local c = idx[k]
                    if not c then c = {} idx[k] = c end
                    c[#c + 1] = { q.id, p[2], p[3] }
                end
            end
        end
    end
    return idx
end

-- andere Quests mit Zielen im Umkreis eines Punktes; liefert Menge {[questID] = true} und Anzahl
function P:BundleNear(idx, inst, n, w, skipId, out)
    out = out or {}
    local cn, cw = math.floor(n / BUNDLE_R), math.floor(w / BUNDLE_R)
    local r2 = BUNDLE_R * BUNDLE_R
    for dn = -1, 1 do
        for dw = -1, 1 do
            for _, e in ipairs(idx[CellKey(inst, cn + dn, cw + dw)] or {}) do
                if e[1] ~= skipId and not out[e[1]] then
                    local a, b = e[2] - n, e[3] - w
                    if a * a + b * b <= r2 then out[e[1]] = true end
                end
            end
        end
    end
    return out
end

-- Zahl der anderen Quests, deren Ziele bei mindestens einem Ziel dieser Quest liegen
function P:BundlePartners(idx, q)
    local set, c = {}, 0
    for _, o in ipairs(q.objectives or {}) do
        local pts = ObjPoints(o)
        for pi = 1, math.min(#pts, 6) do
            local p = pts[pi]
            self:BundleNear(idx, p[1], p[2], p[3], q.id, set)
        end
    end
    for _ in pairs(set) do c = c + 1 end
    return c, set
end

------------------------------------------------------------------------
-- EP je Kill nach Levelunterschied (ein Modell fuer Planung und virtuelle Reise)
--   gleich hoch: 45 + 5 x Spielerlevel; hoeher: +5 % je Level (hoechstens 4); tiefer: x (1 - Unterschied / ZD);
--   grau: 0. Classic-Formel. Auf WoW Forever geben gruene Monster zusaetzlich weniger (GreenXPFactor) - und
--   echte Messungen (Calib, je Levelunterschied) haben Vorrang.
------------------------------------------------------------------------
local ZD = { {7, 5}, {9, 6}, {11, 7}, {15, 8}, {19, 9}, {29, 11}, {39, 12}, {44, 13}, {49, 14}, {54, 15}, {60, 16} }
local function ZeroDiff(pl)
    for _, e in ipairs(ZD) do if pl <= e[1] then return e[2] end end
    return 16
end
P.ZeroDiff = ZeroDiff
-- hoechstes graues Monsterlevel (Classic): bis Level 5 nichts grau, dann Level - (Level/10 + 5) bzw. Level - (Level/5 + 1)
function P:GreyLevel(pl)
    if pl <= 5 then return 0 end
    if pl <= 39 then return pl - math.floor(pl / 10) - 5 end
    return pl - math.floor(pl / 5) - 1
end
-- reine Classic-Formel
function P:KillXPFormula(pl, ml)
    ml = ml or pl
    local base = 45 + 5 * pl
    if ml >= pl then return base * (1 + 0.05 * math.min(ml - pl, 4)) end
    if ml <= self:GreyLevel(pl) then return 0 end
    return math.max(0, base * (1 - (pl - ml) / ZeroDiff(pl)))
end
-- WoW Forever: gruene Monster (3 und mehr Level unter dir) geben weniger EP als in Classic.
-- SCHAETZUNG 0,85 (Guides: einige Prozent bis etwa ein Viertel je Kill), bis Messungen vorliegen.
P.FOREVER_GREEN = 0.85
P.GREEN_DIFF = 3
function P:GreenXPFactor(diff)
    local m = LP.Calib and LP.Calib:KillXPRatio(diff)
    if m then return m, true end
    if LP.API.Forever() and diff and diff <= -self.GREEN_DIFF then return self.FOREVER_GREEN, false end
    return 1, false
end
-- EP fuer einen Kill: Spielerlevel, Monsterlevel (nil = gleich hoch)
function P:KillXP(pl, ml)
    ml = ml and math.floor(ml + 0.5) or pl
    local f = self:GreenXPFactor(math.max(-5, math.min(4, ml - pl)))
    return self:KillXPFormula(pl, ml) * f
end
-- Monsterlevel einer Quest (fuer die Kills beim Questen): mittleres Level der Gegner, sonst das Questlevel
function P:QuestKillLevel(q, level)
    local sum, n = 0, 0
    for _, o in ipairs(q and q.objectives or {}) do
        if o.mobLevel then sum, n = sum + o.mobLevel, n + 1 end
    end
    if n > 0 then return sum / n end
    if q and q.level and q.level > 0 then return q.level end
    return level
end

local function GrindRate(level) return P:KillXP(level, level) * P:KillsPerMin() end
P.GrindRate = GrindRate

-- EP je Minute einer Quest inkl. Monster-EP beim Toeten (nil = unbekannt)
function P:Efficiency(q, level, partners)
    local xp = QuestXPFor(q, level)
    if not xp then return nil end
    local secs = QuestSeconds(q, partners)
    local tag = LP.API.QuestTag(q.id)
    if tag == 1 and not q.elite then secs = secs + 600 end      -- laut Spiel Gruppenquest
    local kills = 0
    for _, o in ipairs(q.objectives) do local _, k = P:ObjectiveCost(o.kind, o.elite, o) kills = kills + k end
    xp = xp + kills * P:KillXP(level, P:QuestKillLevel(q, level))   -- Monster beim Questen (Questlevel)
    return xp / (secs / 60)
end

-- Warum laesst der Speedrun diese Quest aus? (nil = behalten)
local function SpeedReason(q, level)
    if q.dungeon then return nil end                       -- Dungeons haben eigene Regeln
    local tag = LP.API.QuestTag(q.id)
    if tag == 62 or tag == 41 then return L["Schlachtzug/PvP"] end
    if q.escort or tag == 84 then return L["Eskorte"] end
    return nil
end

------------------------------------------------------------------------
-- Dungeons
------------------------------------------------------------------------
local DUNGEON_RETRY = 3          -- Stufen bis ein abgebrochener/uebersprungener Dungeon wiederkommt
local DUNGEON_LOG_FREE = 4       -- so viele Plaetze im Questlog bleiben fuer normale Quests frei
local PREP_RANGE = 2500          -- Yards: Dungeon-Quests in diesem Umkreis vor dem Lauf einsammeln

function P:DungeonUsable(area)
    if LP.db.dungeons == false then return false end
    return (LP.QuestDB:DungeonAllowed(area))
end

local function Round(v) return math.floor(v + 0.5) end

-- Questziele einer Dungeon-Quest, die wirklich draussen liegen. Die Questdaten projizieren Gegner
-- im Dungeon oft auf die Karte darueber - solche Orte nahe am Eingang zaehlen als "im Dungeon".
local INSIDE_RANGE = 600
local function OutsideSpots(area, spots)
    local d = LP.QuestDB:Dungeon(area)
    if not d then return spots end
    local ents = {}
    for _, e in ipairs(d.e or {}) do
        local i, en, ew = LP.Geo:ToWorld(e[1], e[2], e[3])
        if i then ents[#ents + 1] = { i, en, ew } end
    end
    local out = {}
    for _, sp in ipairs(spots) do
        local i, sn, sw = WorldOf(sp)
        if i then
            local inside = false
            for _, e in ipairs(ents) do
                if e[1] == i and LP.Geo:Dist(sn, sw, e[2], e[3]) < INSIDE_RANGE then inside = true break end
            end
            if not inside then out[#out + 1] = sp end
        end
    end
    return out
end
P.OutsideSpots = OutsideSpots

------------------------------------------------------------------------
-- 3.12.41 LP-N1 3: Ausweichorte, wenn eine Stelle abgegrast ist. Der Spieler steht am Ziel einer Töte-/Sammel-Quest,
-- STUCK_SECS lang ohne Fortschritt (nicht AFK) -> Hinweis "Andere Stelle"; auf Klick gilt die Stelle EXHAUST_SECS lang
-- als leer (Umkreis EXHAUST_R) und die Planung nimmt die naechste. Nie automatisch, der Spieler entscheidet.
------------------------------------------------------------------------
P.EXHAUST_R = 150             -- Yards um die leere Stelle
P.EXHAUST_SECS = 1200         -- so lange gilt sie als leer (Monster/Gegenstaende erscheinen wieder)
P.STUCK_SECS = 180            -- so lange ohne Fortschritt am Ziel, bis der Hinweis kommt
P.STUCK_NEAR = 120            -- Yards: "am Ziel"
P.exhausted = {}              -- [questID] = { { inst, n, w, bis }, ... }

local function Now() return GetTime and GetTime() or 0 end
-- Punkte ohne die (noch) leeren Stellen dieser Quest; sind alle leer, bleibt die Liste wie sie war (Quest nie verlieren)
function P:WithoutExhausted(id, points)
    local ex = self.exhausted[id]
    if not ex or not points or #points == 0 then return points end
    local t, keep, r2 = Now(), {}, P.EXHAUST_R * P.EXHAUST_R
    for i = #ex, 1, -1 do if ex[i][4] <= t then table.remove(ex, i) end end
    if #ex == 0 then self.exhausted[id] = nil return points end
    for _, pt in ipairs(points) do
        local i, n, w = WorldOf(pt)
        local empty = false
        for _, e in ipairs(ex) do
            if i and e[1] == i and (e[2] - n) ^ 2 + (e[3] - w) ^ 2 <= r2 then empty = true break end
        end
        if not empty then keep[#keep + 1] = pt end
    end
    return #keep > 0 and keep or points
end
function P:MarkExhausted(id, inst, n, w)
    if not (id and inst and n and w) then return end
    self.exhausted[id] = self.exhausted[id] or {}
    table.insert(self.exhausted[id], { inst, n, w, Now() + P.EXHAUST_SECS })
    self.stuck = nil
    self:Replan()
end

local function MakeTask(t, q, pt, wpos, value, text)
    return {
        t = t, id = q and q.id, q = q and q.name, level = q and q.level,
        map = pt and pt[1], x = pt and pt[2], y = pt and pt[3], npc = pt and pt[4],
        inst = wpos and wpos[1], n = wpos and wpos[2], w = wpos and wpos[3],
        value = value, text = text, isNew = q and q.isNew or nil,
        key = t .. ":" .. (q and q.id or (pt and (pt[1] .. ":" .. math.floor(pt[2]) .. ":" .. math.floor(pt[3])) or "?")),
    }
end

local GATHER = 400            -- Yards um den Spieler (Questannahmen im Umkreis einsammeln)
P.NEAR_TURNIN = 900           -- Yards: abgabebereite Quests so nah am Spieler kommen immer zuerst (3.12.7)
-- 3.12.8: Hauptstaedte haben in WoW Forever keine Elternzone (ParentUiMapID ist der Kontinent). Fuer die Wahl der
-- Fokus-Zone zaehlen sie zur Zone, in der sie liegen - die Reihenfolge entscheidet der Weg (Weltkoordinaten).
P.CITY_ZONE = { [1456] = 1412, [1454] = 1411, [1458] = 1420, [1453] = 1429, [1455] = 1426, [1457] = 1438 }
function P.ZoneOf(map) return map and (P.CITY_ZONE[map] or map) or map end
local ROUTE_SKIP = 150        -- Yards ab dem Spieler, die bei der Wegpruefung nicht zaehlen
local GRIND_RADIUS = 1500     -- Yards: so weit sucht LevelPilot eine Stelle zum Grinden
P.safeSkip = {}
P.mobSkip = {}       -- [questID] = Mob-Level (Pflichtregel: Mobs ab Spielerlevel + 3 sind tabu)
P.mobStats = { quest = 0, spots = 0, accept = 0, route = 0, path = 0, turnin = 0 }   -- Zaehler (Diagnose)
local MS = P.mobStats

-- Pflichtregel Mob-Level: effektives Level (Elite +2) der Gegner der noch offenen Ziele
local function ObjMobLevel(o)
    if not o.mobLevel then return nil end
    return o.mobLevel + (o.elite and LP.Danger.ELITE_BONUS or 0)
end
local function QuestMobLevel(q, objDone)
    local mx, any
    for oi, o in ipairs(q.objectives or {}) do
        if not (objDone and objDone[o.idx or oi]) then
            local lv = ObjMobLevel(o)
            if lv and (not mx or lv > mx) then mx = lv end
            if lv or o.kind == "object" or o.kind == "explore" then any = true end
        end
    end
    -- keine Angaben zu den Gegnern (z. B. Gegenstand von einem benannten Gegner): Questlevel als Schaetzung
    if not mx and not any and q.level and q.level > 0 and not q.dungeon then mx = q.level end
    return mx
end

P.QuestMobLevel = QuestMobLevel
-- nur Orte, an denen keine zu starken Mobs stehen
local function SafePoints(points, level)
    local D = LP.Danger
    if not D or not points then return points end
    local lim = D:Limit(level)
    local out = {}
    for _, pt in ipairs(points) do
        local i, n, w = WorldOf(pt)
        if not i or D:At(i, n, w) < lim then out[#out + 1] = pt end
    end
    return out
end
P.SafePoints = SafePoints
-- Sind alle Zielorte einer Quest zu gefaehrlich?
local function AllSpotsUnsafe(q, level)
    local all = {}
    for _, o in ipairs(q.objectives or {}) do for _, sp in ipairs(o.spots or {}) do all[#all + 1] = sp end end
    return #all > 0 and #SafePoints(all, level) == 0
end

function P:CollectTasks(inst, n, w, level)
    wipe(self.safeSkip)
    wipe(self.mobSkip)
    local tasks = {}
    local dq = {}        -- [Dungeon] = offene Dungeon-Quests im Log
    local logCount = 0
    for _ in pairs(inLog) do logCount = logCount + 1 end
    local maxLog = LP.API.MaxQuests()
    local turninBoost = logCount >= maxLog - 4 and 2 or 1
    local accepts = {}   -- annehmbare Quests (Speedrun filtert danach)
    local speed = self:IsSpeed()
    -- aktive Quests
    for id, st in pairs(inLog) do
        if not LP.char.ignored[id] and not st.failed then
            local q = LP.QuestDB:Get(id) or { id = id, name = st.title, starts = {}, ends = {}, objectives = {} }
            -- Titel aus dem Questlog nur, wenn kein Sprachpaket einen in der eingestellten Sprache kennt
            if LP.Names and LP.Names:Foreign() then q.name = LP.Names:Quest(id) or st.title or q.name
            else q.name = st.title or q.name end
            if st.complete then
                local ends = SafePoints(q.ends, level)
                if #ends == 0 and #(q.ends or {}) > 0 then
                    -- 3.12.7: steht die Abgabe ganz in der Naehe, gilt sie trotzdem (der Spieler ist schon dort)
                    local npt, nd = NearestPoint(q.ends, inst, n, w)
                    if npt and nd and nd <= P.NEAR_TURNIN then ends = { npt }
                    else self.mobSkip[id] = LP.Danger:Limit(level) MS.turnin = MS.turnin + 1 end
                end
                local pt, _, wp = NearestPoint(ends, inst, n, w)
                if pt or #(q.ends or {}) == 0 then
                    tasks[#tasks + 1] = MakeTask("TURNIN", q, pt, wp, (2 * LevelWeight(q.level, level) + 1) * turninBoost)
                end
            else
                -- naechster Ort eines noch offenen Ziels
                local spots = {}
                for oi, o in ipairs(q.objectives) do
                    local idx = o.idx or oi
                    if not st.objDone[idx] then
                        for _, s in ipairs(o.spots) do spots[#spots + 1] = s end
                    end
                end
                if #spots == 0 then
                    for _, o in ipairs(q.objectives) do
                        for _, s in ipairs(o.spots) do spots[#spots + 1] = s end
                    end
                end
                local area = q.dungeon
                if area then spots = OutsideSpots(area, spots) end
                -- Pflichtregel: keine Ziele mit Mobs ab Spielerlevel + 3 (ausser im Dungeon-Lauf mit Gruppe)
                local mobLv = not area and QuestMobLevel(q, st.objDone)
                local blocked = mobLv and not LP.Danger:OK(mobLv, level)
                if not area and not blocked then
                    local safe = SafePoints(spots, level)
                    if #safe == 0 and #spots > 0 then blocked = true mobLv = LP.Danger:Limit(level) MS.spots = MS.spots + 1 end
                    spots = safe
                end
                if blocked then self.mobSkip[id] = mobLv if not MS._spot then MS.quest = MS.quest + 1 end end
                if not blocked and not area then spots = self:WithoutExhausted(id, spots) end      -- 3.12.41 LP-N1 3
                local pt, _, wp
                if not blocked then pt, _, wp = NearestPoint(spots, inst, n, w) end
                if blocked then
                    -- spaeter, wenn das Level reicht
                elseif area and not pt then
                    -- Ziele liegen in der Instanz: gesammelt als ein Dungeon-Lauf
                    local grey = q.level and q.level > 0 and q.level < level - GreyRange(level)
                    if self:DungeonUsable(area) and not grey then
                        dq[area] = dq[area] or {}
                        table.insert(dq[area], q)
                    end
                else
                    local v = 1.5 * LevelWeight(q.level, level) + 0.5
                    -- Speedrun: angefangene langsame Quests nur noch nebenbei
                    if speed and not self:IsProtected(id) and (q.elite or q.escort) then v = v * 0.5 end
                    tasks[#tasks + 1] = MakeTask("COMPLETE", q, pt, wp, v)
                end
            end
        end
    end
    -- annehmbare Quests
    for ci, id in ipairs(candidates) do
        if ci % 5 == 0 then LP:Yield("plan") end
        if not inLog[id] then
            local q = LP.QuestDB:Get(id)
            if q and self:IsAvailable(q, level) then
                local d = q.dungeon and LP.QuestDB:Dungeon(q.dungeon)
                local pt, pd, wp = NearestPoint(SafePoints(q.starts, level), inst, n, w)
                -- Pflichtregel: Quest erst annehmen, wenn ihre Gegner machbar sind
                local mobLv = not d and QuestMobLevel(q)
                if pt and not d and not mobLv and AllSpotsUnsafe(q, level) then mobLv = LP.Danger:Limit(level) end
                if pt and mobLv and not LP.Danger:OK(mobLv, level) then
                    self.mobSkip[id] = mobLv
                    MS.accept = MS.accept + 1
                    pt = nil
                end
                local value = LevelWeight(q.level, level)
                -- Sicherer Modus: Elite und deutlich hoehere Gegner meiden (Klassenquests bleiben, mit Warnung)
                if pt and not d and LP.db.safeMode then
                    -- Sicherer Modus: vorsichtiger als die Pflichtregel (+3) - Elite und Gegner ab eigenem Level + 1
                    local danger = q.elite or (q.mobLevel and q.mobLevel >= level + 1)
                    if danger and not self:IsProtected(id) then
                        self.safeSkip[id] = q.elite and L["Elite"] or (L["Gegner Stufe "] .. q.mobLevel)
                        pt = nil
                    end
                end
                if d then
                    -- erst kurz vor dem passenden Level und nur mit Platz im Log mitnehmen
                    if not self:DungeonUsable(q.dungeon) or level < d.min - 2 or level > d.max
                       or logCount >= maxLog - DUNGEON_LOG_FREE then
                        pt = nil
                    else
                        value = value * (level >= d.min - 1 and 1.2 or 0.6)
                    end
                end
                if pt then
                    local t = MakeTask("ACCEPT", q, pt, wp, value)
                    t.dungeon = q.dungeon
                    accepts[#accepts + 1] = { t = t, q = q }
                end
            end
        end
    end
    self:SpeedFilter(accepts, tasks, level, inst, n, w)
    -- Pflichtregel auch fuer den Weg: fuehrt die gerade Strecke durch ein Gebiet mit zu starken Mobs, ist die
    -- Aufgabe weniger wert (der echte Weg des ersten Ziels wird nach der Reihenfolge genau geprueft)
    local Dg = LP.Danger
    if Dg and Dg.pathRule and inst then
        local lim = Dg:Limit(level)
        for _, t in ipairs(tasks) do
            if t.inst == inst and t.n and t.t ~= "DUNGEON" and Dg:Route(inst, n, w, t.n, t.w, ROUTE_SKIP, lim) >= lim then
                t.value = (t.value or 1) * 0.5
                MS.route = MS.route + 1
            end
        end
    end
    self:DungeonTasks(dq, tasks, inst, n, w, level)
    for i = #tasks, 1, -1 do if tasks[i].drop then table.remove(tasks, i) end end
    -- Gruppe: Quests, die auch Mitspieler haben, gemeinsam erledigen
    local shared = LP.Group and LP.Group:SharedQuests()
    if shared then
        for _, t in ipairs(tasks) do
            local c = t.id and shared[t.id]
            if c then t.value = t.value * (1 + 0.3 * math.min(c, 3)) t.shared = c end
        end
    end
    return tasks
end

-- Speedrun: langsame Quests auslassen, schnelle bevorzugen (Klassenquests bleiben)
local CROSS_SECS = 900          -- anderer Kontinent: Weg zu Schiff/Zeppelin, Warten, Fahrt (Sekunden)
local RUN_YPS = 7               -- Yards pro Sekunde zu Fuss
local HUB_SHARE = 250           -- Yards: Questgeber an einem Ort teilen sich den Weg

-- Raster der offenen Ziele im Questlog (und optional weiterer Quests)
function P:LogBundleIndex(level, extra)
    local entries = {}
    for id, st in pairs(self.inLog) do
        if not st.complete then
            local q = LP.QuestDB:Get(id)
            if q and not q.dungeon then entries[#entries + 1] = { q = q, done = st.objDone } end
        end
    end
    for _, q in ipairs(extra or {}) do entries[#entries + 1] = { q = q } end
    return self:BundleIndex(entries, level)
end

-- Anteil "Questen" an Questen + halbem Weg (mindestens 0,35); gleiche Formel wie travelF im Speedrun
function P.TravelFactor(secs, t, inst, n, w, hub)
    local travel = (t.inst == inst and t.n) and (P.WayDist(n, w, t.n, t.w, t.map) / RUN_YPS) or CROSS_SECS
    travel = travel / math.max(1, hub or 1)
    return math.max(0.35, secs / (secs + travel * 0.5))
end

function P:SpeedFilter(accepts, tasks, level, inst, n, w)
    wipe(self.speedSkip)
    -- Questgeber-Gruppen: der Weg dorthin teilt sich auf alle Quests, die man am selben Ort annimmt
    local function HubSize(a)
        if not a.t.n then return 1 end
        local c = 0
        for _, b in ipairs(accepts) do
            if b.t.inst == a.t.inst and b.t.n and LP.Geo:Dist(a.t.n, a.t.w, b.t.n, b.t.w) <= HUB_SHARE then c = c + 1 end
        end
        return math.max(1, c)
    end
    -- 3.12.65 LW-2b: Zeit statt nur Strecke auch im Normalmodus – Wert einer Annahme × travelF (Questdauer gegen den Weg
    -- dorthin mit Wegkosten LW-1, geteilt durch die Questgeber am selben Ort), wie im Speedrun. Ausgelassen wird im
    -- Normalmodus weiterhin nichts. Beleg: virtuelle Reise 1–60, 18 Charaktere (6 Völker × 3 Klassen): 15 schneller,
    -- 3 langsamer, Median −3 h 17 min (Bericht LW-2b). P.OPT.timeNormal = false: wie vor 3.12.65.
    if not self:IsSpeed() then
        if P.OPT.timeNormal and inst then
            for ai, a in ipairs(accepts) do
                if ai % 10 == 0 then LP:Yield("plan") end
                if not a.q.dungeon and a.t.n then
                    a.t.value = a.t.value * P.TravelFactor(QuestSeconds(a.q), a.t, inst, n, w, HubSize(a))
                end
            end
        end
        for _, a in ipairs(accepts) do tasks[#tasks + 1] = a.t end
        return
    end
    -- Buendeln: Ziele, die neben Zielen anderer Quests liegen (im Log oder hier annehmbar), teilen die Suche
    local extra = {}
    for _, a in ipairs(accepts) do if not a.q.dungeon then extra[#extra + 1] = a.q end end
    local bidx = self:LogBundleIndex(level, extra)
    for ai, a in ipairs(accepts) do
        if ai % 10 == 0 then LP:Yield("plan") end
        if not a.q.dungeon then
            a.bundle = self:BundlePartners(bidx, a.q)
            a.eff = self:Efficiency(a.q, level, a.bundle)
            -- der Weg zum Questgeber zaehlt fuer die Reihenfolge, nicht fuers Auslassen
            -- (sonst faellt in einer Stadt fern der Questgeber jede Quest durch und es wird endlos gegrindet)
            if a.eff and inst then
                local secs = QuestSeconds(a.q, a.bundle)
                local travel = (a.t.inst == inst and a.t.n) and (P.WayDist(n, w, a.t.n, a.t.w, a.t.map) / RUN_YPS) or CROSS_SECS
                travel = travel / HubSize(a)
                a.travelF = math.max(0.35, secs / (secs + travel * 0.5))
            end
        end
    end
    local med = GrindRate(level)
    local cut = SPEED_CUTOFF[LP.db.speedLevel or 3] or SPEED_CUTOFF[3]
    -- EP je Minute beim Questen (Median), fuer die Monster am Weg: nur mitnehmen, was mindestens so viel bringt
    local effs = {}
    for _, a in ipairs(accepts) do if a.eff then effs[#effs + 1] = a.eff end end
    table.sort(effs)
    self.questRate = #effs > 0 and effs[math.floor((#effs + 1) / 2)] or nil
    for _, a in ipairs(accepts) do
        local id = a.q.id
        local reason
        if not self:IsProtected(id) then
            reason = SpeedReason(a.q, level)
            -- Ziel: so schnell wie moeglich auf 60, ohne grosses Grinden. Darum bleiben Quests drin, die
            -- Folgequests freischalten (die Kette bringt mehr als die einzelne Quest) und Quests an einem Ort mit
            -- mehreren Questgebern (der Weg dorthin lohnt sich ohnehin). Ausgelassen wird nur, was klar langsam ist.
            local chain = a.q.nextInChain and a.q.nextInChain ~= 0
            -- gebuendelt (Ziele bei Zielen anderer Quests): steckt schon in a.eff (geteilte Suchzeit)
            local hub = HubSize(a) >= SPEED_HUB
            local low = a.q.level and a.q.level > 0 and a.q.level <= level - SPEED_LOW
            if not reason and low and not hub then reason = L["zu niedrig"] end
            -- Gegenstaende, die selten fallen: klar langsam, auch an einem Questgeber-Ort
            if not reason and not chain and self:SlowDrop(a.q) then reason = L["Gegenstände fallen selten"] end
            -- gebuendelt (Ziele bei Zielen anderer Quests): man ist ohnehin dort - nur auslassen, wenn sehr langsam
            local bcut = (a.bundle or 0) >= 1 and cut * P.BUNDLE_CUT or cut
            if not reason and not chain and not hub and a.eff and a.eff < med * bcut then reason = L["dauert zu lange"] end
        end
        if reason then
            self.speedSkip[id] = reason
        else
            if self:IsProtected(id) and IsClassQuest(a.q.classes) then a.t.value = a.t.value + 1 a.t.classQuest = true end
            if a.travelF then a.t.value = a.t.value * a.travelF end
            tasks[#tasks + 1] = a.t
        end
    end
end

-- Einen Dungeon-Lauf einplanen, wenn er sich jetzt lohnt.
-- Im passenden Level werden die Dungeon-Quests in Reichweite gezielt eingesammelt (auch ausserhalb
-- der Fokus-Zone), danach geht es in den Dungeon - so muss man nicht zweimal hin.
local SINGLE_RANGE = 1000        -- Yards: mit nur einer Quest nur, wenn man praktisch am Eingang ist
-- Zeit und Monster-EP eines Laufs
local DG_SEARCH, DG_RUN, DG_PER_QUEST = 900, 2700, 420   -- Gruppensuche, Lauf (Ersatzwert), je Quest (Sekunden)
local DG_KILLS = 60              -- Elite-Kills je Lauf (EP bereits auf 5 Spieler geteilt)
local DG_NEED = { normal = 0.55, speed = 0.9 } -- mindestens so viel EP/Minute wie x-mal Grinden

-- Monster-EP in Dungeons auf WoW Forever (VORLAEUFIG, Stand 2.11.2026): im September stark gesenkt (ohne Zahl,
-- Schaetzung -70 %), am 8.10.2026 um etwa 20 % gegenueber der Beta erhoeht -> 0,3 x 1,2 = 0,36.
-- Reihenfolge: Einstellung (%) -> im Dungeon gemessen (Calib) -> Schaetzung. Classic: 1,0.
P.FOREVER_DG_MOB = 0.36
function P:DungeonXPFactor()
    local pct = tonumber(LP.db.dungeonMobXP)
    if pct and pct > 0 then return pct / 100, "set" end
    if LP.API.Forever() then
        local m = LP.Calib and LP.Calib:DungeonXPRatio()
        if m then return m, "measured" end
        return self.FOREVER_DG_MOB, "auto"
    end
    return 1.0, "auto"
end

-- Quest-EP von Dungeon-Quests auf WoW Forever (VORLAEUFIG, Stand 2.11.2026): Beta +94 bis +138 %, am 1.10.2026
-- Bonus-Anteil um 50 % gekuerzt -> etwa +47 bis +69 %, Planung 1,5. Gemessene Quest-EP haben Vorrang (BaseXP).
P.FOREVER_DG_QUEST = 1.5
function P:DungeonQuestFactor()
    local pct = tonumber(LP.db.dungeonQuestXP)
    if pct and pct > 0 then return pct / 100, "set" end
    return LP.API.Forever() and self.FOREVER_DG_QUEST or 1.0, "auto"
end

-- EP je Minute eines Dungeon-Laufs mit diesen Quests (Quest-EP + Monster-EP)
function P:DungeonRate(quests, level, area)
    local xp = 0
    local qf = self:DungeonQuestFactor()
    for _, q in ipairs(quests) do
        local _, measured = BaseXP(q)
        -- gemessene Forever-EP enthalten den Dungeon-Bonus schon
        xp = xp + (QuestXPFor(q, level) or self:KillXP(level, level) * 10) * (measured and 1 or qf)   -- unbekannt: wie 10 Kills
    end
    xp = xp + self:KillXPFormula(level, level) * DG_KILLS * self:DungeonXPFactor()
    local d = area and LP.Dungeons[area]
    local secs = DG_SEARCH + (d and d.run and d.run * 60 or DG_RUN) + DG_PER_QUEST * #quests
    return xp / (secs / 60)
end
P.dungeonWorth = {}   -- [Dungeon] = Text fuer Anzeige/Diagnose
P.dungeonDead = {}    -- [questID] = true: Dungeon-Quest im Log, deren Lauf sich nicht lohnt

function P:DungeonTasks(dq, tasks, inst, n, w, level)
    local minQuests = LP.db.dungeonMin or 2
    if self:IsSpeed() then minQuests = math.max(minQuests, SPEED_DUNGEON_MIN) end
    local need = GrindRate(level) * (self:IsSpeed() and DG_NEED.speed or DG_NEED.normal)
    local worthArea = {}
    wipe(self.dungeonWorth)
    wipe(self.dungeonDead)
    local avail = {}
    for _, t in ipairs(tasks) do
        if t.t == "ACCEPT" and t.dungeon and t.inst == inst then
            avail[t.dungeon] = avail[t.dungeon] or {}
            table.insert(avail[t.dungeon], t)
        end
    end
    local areas = {}
    for a in pairs(dq) do areas[a] = true end
    for a in pairs(avail) do areas[a] = true end
    for area in pairs(areas) do
        local list, acc = dq[area] or {}, avail[area] or {}
        local d = LP.QuestDB:Dungeon(area)
        local last = LP.char.dungeonRun[area]
        if d and not (last and level < last + DUNGEON_RETRY) then
            local sum, cnt, value = 0, 0, 0
            local names = {}
            for _, q in ipairs(list) do
                if q.level and q.level > 0 then sum = sum + q.level cnt = cnt + 1 end
                value = value + 1.5 * LevelWeight(q.level, level) + 0.5
                names[#names + 1] = q.name
            end
            for _, t in ipairs(acc) do
                if t.level and t.level > 0 then sum = sum + t.level cnt = cnt + 1 end
            end
            local avg = cnt > 0 and sum / cnt or d.min
            -- Eingang: der naechste auf diesem Kontinent
            local pt, dist, wp = NearestPoint(d.e, inst, n, w)
            local ready = level >= math.max(d.min, Round(avg) - 3)
            -- lohnt sich der Lauf ueberhaupt? (alle Quests, die man bis dahin haben kann)
            -- gezaehlt werden nur Quests, die man wirklich zusammen haben kann: im Log + jetzt annehmbar in der Naehe
            local all, near = {}, {}
            for _, q in ipairs(list) do all[#all + 1] = q end
            for _, t in ipairs(acc) do
                if LP.Geo:Dist(n, w, t.n, t.w) < PREP_RANGE then
                    near[#near + 1] = t
                    local aq = LP.QuestDB:Get(t.id)
                    if aq then all[#all + 1] = aq end
                end
            end
            local rate = self:DungeonRate(all, level, area)
            local worth = rate >= need
            if worth then worthArea[area] = true end
            self.dungeonWorth[area] = string.format(L["%s: %d EP/Min (nötig %d)%s"], d.name, rate, need, worth and "" or L[" – lohnt nicht"])
            if not worth then
                -- Lauf lohnt nicht: Quests dafuer gar nicht erst annehmen (blockieren sonst den Questlog)
                for _, t in ipairs(acc) do t.drop = true end
                for _, q in ipairs(list) do self.dungeonDead[q.id] = true end
            end
            if pt and ready and worth then
                if #all >= minQuests then
                    for _, t in ipairs(near) do t.prep = true t.value = t.value + 1 end
                end
                local single = #list >= 1 and #near == 0 and dist and dist < SINGLE_RANGE
                -- laufen, sobald alles Erreichbare eingesammelt ist (oder die Quests im Log schon reichen)
                local collected = #near == 0 or self:DungeonRate(list, level, area) >= need
                if (#list >= minQuests or single) and collected then
                    local urgent = level >= Round(avg) + 2
                    value = value * 1.4 + 2 * self:DungeonXPFactor()   -- Monster-EP im Dungeon
                    if LP.QuestDB:DungeonHostile(area) then value = value * 0.6 end
                    if urgent then value = value * 1.5 end
                    tasks[#tasks + 1] = {
                        t = "DUNGEON", area = area, q = d.name, level = Round(avg), quests = names,
                        map = pt[1], x = pt[2], y = pt[3], inst = wp[1], n = wp[2], w = wp[3],
                        value = value, urgent = urgent, hostile = LP.QuestDB:DungeonHostile(area),
                        min = d.min, max = d.max, key = "DG:" .. area,
                    }
                end
            end
        end
    end
    -- Dungeon-Quests nur annehmen, wenn ihr Lauf sich gerade nachweislich lohnt
    for _, t in ipairs(tasks) do
        if t.t == "ACCEPT" and t.dungeon and not worthArea[t.dungeon] then t.drop = true end
    end
end

------------------------------------------------------------------------
-- 4) Fokus-Zone
------------------------------------------------------------------------

local OTHER_CONTINENT = 12000   -- Reisekosten (Yards) fuer einen Kontinentwechsel
local TRAVEL_SCALE = 900        -- je so viele Yards halbiert sich der Wert einer Zone
local DRAIN = 2.5               -- Restwert, ab dem eine Zone als "abgearbeitet" gilt
local SWITCH_NEAR = 500       -- Yards: alte Fokus-Zone gilt als verlassen
local CROSS_MIN_TASKS = 5     -- so viele Aufgaben braucht eine Zone auf einem anderen Kontinent
-- 3.12.84: Stufen-/Abstandsgrenzen für Kontinentwechsel (3.12.80: ab Stufe 30, alle 10 Stufen) entfallen – ersetzt durch "nur wenn daheim
-- kaum noch etwas zu tun ist" (P.CROSS_STARVE), siehe P:ChooseFocus
P.CROSS_STARVE = 2.5          -- 3.12.82: Restwert daheim, unter dem ein Kontinentwechsel immer erlaubt ist (= DRAIN)
local TURNIN_FOCUS = 0.3      -- Anteil einer Abgabe am Wert einer Zone bei der Wahl der Fokus-Zone
-- In der Zone bleiben (so wenig Zonenwechsel wie moeglich): die Fokus-Zone wird erst verlassen, wenn dort fast
-- nichts mehr zu tun ist - Abgaben zaehlen dafuer voll (sonst kommt man spaeter nur fuer die Abgaben zurueck).
-- Eine eben verlassene Zone lohnt sich erst wieder, wenn dort viel Neues wartet.
local STAY_MIN = 1.0          -- Restwert (Abgaben voll gezaehlt), bis zu dem man in der Fokus-Zone bleibt
local RETURN_LEVELS = 4       -- so viele Level gilt eine verlassene Zone als "eben verlassen"
local RETURN_PENALTY = 0.4    -- Abschlag fuer die Rueckkehr in eine eben verlassene Zone
local SIZE_BONUS = 12         -- groessere Pakete bevorzugen (bis zu doppelter Wert bei so vielen Aufgaben)
P.leftZones = {}              -- [Karte] = Level beim Verlassen
function P:LogCount()
    local c = 0
    for _ in pairs(self.inLog or {}) do c = c + 1 end
    return c
end
P.focusChanges, P.focusReturns = 0, 0
P.OPT = { stay = true, ret = true, size = true, collect = true, small = true, wayCost = true, exact = true, timeNormal = true }

-- 3.12.51 LW-1: Wegkosten statt Luftlinie. Faktor = gemessener Umweg der Wegsuche in der Zielzone (Graph:Detour, Median
-- über Paare bekannter Knoten, 1,0–1,8; bis gemessen 1,25). P.OPT.wayCost = false: reine Luftlinie wie vor 3.12.51
-- (Vorher/Nachher-Vergleich in der Testumgebung).
function P.WayFactor(map)
    local G = LP.Graph
    if not P.OPT.wayCost or not (G and G.Detour) then return 1 end
    return (G:Detour(map))
end
function P.WayDist(n1, w1, n2, w2, map) return LP.Geo:Dist(n1, w1, n2, w2) * P.WayFactor(map) end
local SMALL_FAR = 1500        -- Yards: so weit reist man hoechstens fuer eine Zone mit wenig zu tun   -- Schalter fuer die Testumgebung

-- 3.12.83 OPT-ROUTE 1b (Stufenband je Zone): aus dem Datenpaket – Questlevel der Quests, deren Geber in der Zone steht (erster Fundort),
-- nur Quests, die zum Charakter passen; Band = 20.–80. Perzentil, mind. 8 Quests. Einmal je Sitzung berechnet (in Portionen).
P.BAND_IN, P.BAND_OUT = 1.5, 0.6     -- Fokus-Wertung: Zone im Band ×1,5, ausserhalb ×0,6 (gemessen: Bewertung 1199 -> 1181)
local bandCache
function P:ZoneBands()
    if bandCache then return bandCache end
    local QDB = LP.QuestDB
    local per = {}
    for ci, id in ipairs(QDB:AllIds()) do
        if ci % 40 == 0 then LP:Yield("plan") end
        local q = QDB:Get(id)
        local p = q and q.level and q.level > 0 and q.starts and q.starts[1]
        if p and p[1] and QDB:FitsPlayer(q) then
            local z = per[p[1]] or {}
            per[p[1]] = z
            z[#z + 1] = q.level
        end
    end
    local out = {}
    for map, v in pairs(per) do
        if #v >= 8 then
            table.sort(v)
            out[map] = { v[math.floor(#v / 5) + 1], v[math.floor(#v * 4 / 5) + 1] }
        end
    end
    bandCache = out
    return out
end
function P.ResetBands() bandCache = nil end

function P:ChooseFocus(tasks, inst, n, w, curZone, excluded)
    if LP.char.focusZone then return P.ZoneOf(LP.char.focusZone) end
    excluded = excluded or {}
    curZone = P.ZoneOf(curZone)
    -- Dungeon, dessen Quests bald grau werden: jetzt hin
    for _, t in ipairs(tasks) do
        if t.t == "DUNGEON" and t.urgent and t.inst == inst then self.focusWhy = "dungeon" return P.ZoneOf(t.map) end
    end
    local zones = {}
    for _, t in ipairs(tasks) do
        local zk = P.ZoneOf(t.map)
        if zk and t.inst and not t.pathBlocked and not excluded[zk] then
            local z = zones[zk]
            if not z then
                z = { value = 0, cnt = 0, inst = t.inst, near = nil }
                zones[zk] = z
            end
            -- Abgaben erledigt man, wenn man ohnehin dort ist: fuer die Wahl der Zone zaehlen sie weniger
            -- (sonst zieht jede einzelne Abgabe in eine andere Zone)
            z.value = z.value + t.value * (t.t == "TURNIN" and TURNIN_FOCUS or 1)
            z.stay = (z.stay or 0) + t.value
            z.cnt = z.cnt + 1
            if t.t == "COMPLETE" then z.open = (z.open or 0) + 1 end
            local d = (t.inst == inst) and P.WayDist(n, w, t.n, t.w, t.map) or OTHER_CONTINENT   -- 3.12.51 LW-1
            if not z.near or d < z.near then z.near = d end
        end
    end
    self.lastZones = zones           -- Diagnose/Testroutine
    -- 3.12.13: offene (erreichbare, nicht zu schwere) Quests in der Zone, in der man steht (mit Stadt), zuerst.
    -- Abgaben anderswo sind kein Grund, die Zone zu verlassen - danach geht es gesammelt weiter.
    local stand = zones[curZone]
    if stand and (stand.open or 0) > 0 then
        self.focusWhy = "open " .. stand.open
        return curZone
    end
    -- 1) Bisherige Fokus-Zone erst fertig machen
    --    (ausser der Spieler ist sichtbar in eine andere lohnende Zone gewechselt)
    local cur = self.focus and zones[self.focus]
    local here = zones[curZone]
    -- (nur auf dem Weg durch eine Zone oder nach einem Flug: Fokus behalten; wechseln nur, wenn die Zone
    -- hier deutlich mehr bringt)
    -- 3.12.8: Fokus folgt dem Spieler - liegt die alte Fokus-Zone weit hinter ihm (doppelte Wechsel-Entfernung),
    -- genuegt es, dass es hier genug zu tun gibt
    local moved = here and curZone ~= self.focus and here.value >= DRAIN
                  and cur and cur.near > SWITCH_NEAR and here.cnt >= 3
                  and (cur.near > SWITCH_NEAR * 2 or here.value >= (P.OPT.stay and cur.stay or cur.value) * 1.5)
    if cur and not moved and (P.OPT.stay and cur.stay >= STAY_MIN or cur.value >= DRAIN) then return self.focus end
    local level = LP:PlayerLevel() or 1
    local function Recent(map) local l = P.OPT.ret and self.leftZones[map] return l and level - l < RETURN_LEVELS end
    -- 2) Zone, in der man steht, wenn es dort genug zu tun gibt (eben verlassen: nur mit viel Neuem)
    if here and here.value >= DRAIN * (Recent(curZone) and 2 or 1) then self.focusWhy = (moved and "moved " or "here ") .. string.format("%.1f", here.value) return curZone end
    -- 3) Sonst die lohnendste Zone; einzelne Aufgaben rechtfertigen keine weite Reise
    --    Ein anderer Kontinent (Schiff/Zeppelin, 10-15 min) lohnt sich nur fuer ein ganzes Paket Quests,
    --    und nur, wenn auf diesem Kontinent kaum noch etwas zu tun ist
    local homeValue = 0
    for _, z in pairs(zones) do if z.inst == inst and z.value > homeValue then homeValue = z.value end end
    local okB, bands = pcall(self.ZoneBands, self)
    if not okB then bands = nil end
    local best, bestScore
    for map, z in pairs(zones) do
        local sc = z.value / (1 + z.near / TRAVEL_SCALE)
        if z.cnt < 3 and z.near > 1500 then sc = sc * 0.4 end
        -- fuer eine einzelne kleine Aufgabe nicht weit reisen: lieber kurz in der Naehe Monster besiegen, bis
        -- mit dem naechsten Level neue Quests kommen (sonst springt die Route quer durch die Welt)
        if P.OPT.small and z.value < DRAIN and z.near > SMALL_FAR then sc = 0 end
        if P.OPT.size then sc = sc * (1 + math.min(z.cnt, SIZE_BONUS) / SIZE_BONUS) end
        if Recent(map) then sc = sc * RETURN_PENALTY end
        -- 3.12.83: Zonen im eigenen Stufenband bevorzugen (Zonenfolge nach Stufe statt nur nach Wert/Entfernung)
        local b = bands and bands[map]
        if b then sc = sc * ((level >= b[1] and level <= b[2]) and P.BAND_IN or P.BAND_OUT) end
        -- 3.12.82 GRIND-1 (Entscheid Supervisor 23:06, Fassung E): ist daheim kaum noch etwas zu tun (bester Restwert < P.CROSS_STARVE),
        -- gelten Stufen- und Abstandsgrenze nicht – Reisen ist dann besser als Grinden (Grinden vorher 42–53 % der Zeit)
        local starving = homeValue < P.CROSS_STARVE
        -- 3.12.84 OPT-ROUTE (Kontinent als Block): anderer Kontinent nur, wenn daheim kaum noch etwas zu tun ist (gemessen: Bewertung
        -- 1188 -> 1178; vorher zusätzlich "doppelter Wert" und Stufe 30)
        if z.inst ~= inst and (z.cnt < CROSS_MIN_TASKS or not starving) then sc = 0 end
        if sc > 0 and (not bestScore or sc > bestScore) then best, bestScore = map, sc end
    end
    self.focusWhy = best and string.format("best %.1f/%d cur %s", zones[best].value, zones[best].cnt, cur and string.format("%.1f", cur.stay) or "-") or "none"
    return best
end

------------------------------------------------------------------------
-- 5) Reihenfolge
------------------------------------------------------------------------
local TYPE_BONUS = { ACCEPT = 0.85, TURNIN = 0.85, COMPLETE = 1.0, DUNGEON = 1.2 }

-- Erst annehmen, dann questen: Alle annehmbaren Quests in der Naehe des Spielers (GATHER) werden
-- eingesammelt, bevor ein Questziel drankommt. Kommt die Route spaeter an einen Questgeber, werden
-- alle Questgeber im Umkreis (HUB) gleich mit besucht. Abgaben an denselben Orten laufen mit (sie
-- schaffen Platz im Log und schalten Folgequests frei). Nie mehr Quests, als ins Log passen.
local HUB = 250               -- Yards um einen Questgeber
local TURNIN_FAR = 800        -- Yards: einzelne Abgaben weiter weg werden gesammelt
local TURNIN_ALONE = 0.35     -- Wert einer einzelnen fernen Abgabe (kommt ans Ende, wenn nichts vorbeifuehrt)
P.GATHER, P.HUB = GATHER, HUB

function P:Order(tasks, inst, n, w)
    local out, used = {}, {}
    local cn, cw = n, w
    local logCount = 0
    for _ in pairs(inLog) do logCount = logCount + 1 end
    local free = LP.API.MaxQuests() - logCount
    local anchorN, anchorW, anchorR = n, w, GATHER      -- Sammelpunkt: zuerst der Spieler selbst
    local function inHub(t)
        return t.inst == inst and (t.t == "ACCEPT" or t.t == "TURNIN") and t.n
               and LP.Geo:Dist(anchorN, anchorW, t.n, t.w) <= anchorR
    end
    for _ = 1, math.min(#tasks, MAX_STEPS) do
        LP:Yield("plan")
        -- gibt es am Sammelpunkt noch etwas anzunehmen (und Platz im Log)? Dann nur das (+ Abgaben dort)
        local gather = false
        if anchorN and free > 0 then
            for i, t in ipairs(tasks) do
                if not used[i] and t.t == "ACCEPT" and inHub(t) then gather = true break end
            end
        end
        if not gather then anchorN = nil end
        local best, bestC
        for i, t in ipairs(tasks) do
            if not used[i] and (not gather or inHub(t)) then
                local c
                if t.inst == inst then
                    c = P.WayDist(cn, cw, t.n, t.w, t.map) * (TYPE_BONUS[t.t] or 1)     -- 3.12.51 LW-1
                elseif not t.inst then
                    c = 5000   -- Ort unbekannt: ans Ende
                else
                    c = 30000  -- anderer Kontinent: nur, wenn hier wirklich nichts Lohnendes mehr ist
                end
                c = c / (0.6 + 0.4 * math.min(t.value or 1, 1.5))
                -- Log voll: Annahmen erst, wenn wieder Platz ist (nach Abgaben)
                if t.t == "ACCEPT" and free <= 0 then c = c * 50 + 50000 end
                if not bestC or c < bestC then best, bestC = i, c end
            end
        end
        if not best then break end
        used[best] = true
        local t = tasks[best]
        out[#out + 1] = t
        if t.inst == inst then cn, cw = t.n, t.w end
        if t.t == "ACCEPT" then
            free = free - 1
            -- an einem Questgeber angekommen: dessen Umgebung mit einsammeln
            if not anchorN and t.inst == inst and t.n then anchorN, anchorW, anchorR = t.n, t.w, HUB end
        elseif t.t == "TURNIN" then
            free = free + 1
        end
    end
    self:TwoOpt(out, inst, n, w, LP.API.MaxQuests() - logCount)
    if P.OPT.exact then self:ExactOrder(out, inst, n, w, LP.API.MaxQuests() - logCount) end   -- 3.12.61 LW-2a
    return out
end

-- Reihenfolge nachbessern: Gesamtstrecke der Kette (nicht nur der jeweils naechste Schritt) mit 2-opt kuerzen.
-- Bedingungen: je Quest annehmen vor erledigen vor abgeben; der Questlog laeuft nie ueber.
local ORDER_RANK = { ACCEPT = 1, COMPLETE = 2, TURNIN = 3 }
local function LegCost(a, b)
    if not a or not b or not a.inst or not b.inst then return 0 end
    if a.inst ~= b.inst then return 30000 end
    return P.WayDist(a.n, a.w, b.n, b.w, b.map or a.map)                 -- 3.12.51 LW-1
end
local function Valid(list, free)
    local seen = {}
    for _, t in ipairs(list) do
        local r = ORDER_RANK[t.t]
        if r and t.id then
            if (seen[t.id] or 0) > r then return false end
            seen[t.id] = r
        end
        if t.t == "ACCEPT" then free = free - 1 if free < 0 then return false end
        elseif t.t == "TURNIN" then free = free + 1 end
    end
    return true
end
P.ValidOrder = Valid                -- Testroutine (T321)
function P:TwoOpt(list, inst, n, w, free)
    local m = #list
    if m < 4 then return end
    -- nur der Teil mit bekannten Orten auf diesem Kontinent (der Rest bleibt hinten)
    local k = 0
    while k < m and list[k + 1].inst == inst and list[k + 1].n do k = k + 1 end
    if k < 4 then return end
    local start = { inst = inst, n = n, w = w }
    local function at(i) return i == 0 and start or list[i] end
    local improved, passes = true, 0
    while improved and passes < 4 do
        improved = false
        passes = passes + 1
        for i = 2, k - 2 do   -- der erste Schritt bleibt (nach Wert und Naehe gewaehlt), der Rest wird kuerzer
            LP:Yield("plan")
            for j = i + 1, k do
                -- Kanten (i-1 -> i) und (j -> j+1) durch (i-1 -> j) und (i -> j+1) ersetzen = Abschnitt i..j umdrehen
                local a, b, c, d = at(i - 1), list[i], list[j], j < k and list[j + 1] or nil
                local delta = LegCost(a, c) + LegCost(b, d) - LegCost(a, b) - LegCost(c, d)
                if delta < -10 then
                    local lo, hi = i, j
                    while lo < hi do list[lo], list[hi] = list[hi], list[lo] lo, hi = lo + 1, hi - 1 end
                    if Valid(list, free) then
                        improved = true
                    else
                        lo, hi = i, j
                        while lo < hi do list[lo], list[hi] = list[hi], list[lo] lo, hi = lo + 1, hi - 1 end
                    end
                end
            end
        end
        -- Or-opt: Block von 1-3 Schritten an eine bessere Stelle verschieben (z. B. alle Ratchet-Schritte ans Ende)
        for len = 3, 1, -1 do
            for i = 2, k - len + 1 do
                LP:Yield("plan")
                local j = i + len - 1
                local prev, first, last, nxt = at(i - 1), list[i], list[j], j < k and list[j + 1] or nil
                local removeGain = LegCost(prev, first) + LegCost(last, nxt) - LegCost(prev, nxt)
                local bestPos, bestDelta
                for p = 1, k do
                    if p < i - 1 or p > j then
                        local A, B = at(p), p < k and list[p + 1] or nil
                        local delta = LegCost(A, first) + LegCost(last, B) - LegCost(A, B) - removeGain
                        if delta < -10 and (not bestDelta or delta < bestDelta) then bestPos, bestDelta = p, delta end
                    end
                end
                if bestPos then
                    local backup = {}
                    for x = 1, #list do backup[x] = list[x] end
                    local block = {}
                    for x = i, j do block[#block + 1] = list[x] end
                    for _ = i, j do table.remove(list, i) end
                    local ins = bestPos > j and bestPos - len or bestPos
                    for x = #block, 1, -1 do table.insert(list, ins + 1, block[x]) end
                    if Valid(list, free) then
                        improved = true
                    else
                        for x = 1, #backup do list[x] = backup[x] end
                    end
                end
            end
        end
    end
end

-- 3.12.61 LW-2a: exakte Reihenfolge der naechsten Schritte (Idee aus der Analyse: exakte Reihenfolge bis 8 Ziele).
-- Nach 2-opt/Or-opt: die Schritte 2..(1+EXACT_N) (bekannte Orte auf diesem Kontinent) werden exakt geordnet – kuerzeste
-- Kette vom ersten Schritt bis zum Schritt danach (Held-Karp, 2^m · m² Schritte, m <= 8: hoechstens 16 384), mit denselben
-- Regeln wie Valid (je Quest annehmen vor erledigen vor abgeben, Questlog laeuft nie ueber). Der erste Schritt bleibt
-- (nach Wert und Naehe gewaehlt). Uebernommen nur, wenn die Kette um mehr als 10 Yards kuerzer wird.
P.EXACT_N = 8
P.exactStats = { runs = 0, better = 0, saved = 0 }
function P:ExactOrder(list, inst, n, w, free)
    local k = 0
    while k < #list and list[k + 1].inst == inst and list[k + 1].n do k = k + 1 end
    local e = math.min(k, 1 + P.EXACT_N)
    local m = e - 1
    if m < 3 then return false end
    -- Zustand nach Schritt 1
    local free0 = free
    local first = list[1]
    if first.t == "ACCEPT" then free0 = free0 - 1 elseif first.t == "TURNIN" then free0 = free0 + 1 end
    local W = {}
    for i = 1, m do W[i] = list[i + 1] end
    local after = e < #list and list[e + 1] or nil
    if after and not (after.inst == inst and after.n) then after = nil end
    -- Kosten vorher berechnen (LegCost wie 2-opt: Wegkosten LW-1)
    local C0, Cend, C = {}, {}, {}
    for i = 1, m do
        C0[i] = LegCost(first, W[i])
        Cend[i] = after and LegCost(W[i], after) or 0
        C[i] = {}
        for j = 1, m do C[i][j] = (i ~= j) and LegCost(W[i], W[j]) or 0 end
    end
    -- Vorgaenger je Schritt (gleiche Quest, kleinerer Rang) als Bitmaske; Log-Wirkung je Schritt
    local pre, dlog = {}, {}
    for i = 1, m do
        local mask, ri = 0, ORDER_RANK[W[i].t]
        for j = 1, m do
            local rj = ORDER_RANK[W[j].t]
            if j ~= i and ri and rj and W[i].id and W[i].id == W[j].id and rj < ri then mask = mask + 2 ^ (j - 1) end
        end
        pre[i] = mask
        dlog[i] = (W[i].t == "ACCEPT" and -1) or (W[i].t == "TURNIN" and 1) or 0
    end
    -- Bits je Maske einmal vorberechnet (Lua 5.1 ohne Bit-Operatoren; math.floor je Abfrage war zu teuer, T155)
    local full = 2 ^ m - 1
    local bits, freeOf = { [0] = {} }, { [0] = free0 }
    local pow = {}
    for j = 1, m do pow[j] = 2 ^ (j - 1) end
    for mask = 1, full do
        local hb = 1
        while pow[hb + 1] and pow[hb + 1] <= mask do hb = hb + 1 end   -- hoechstes Bit
        local prev = bits[mask - pow[hb]]
        local t = {}
        for j = 1, m do t[j] = prev[j] end
        t[hb] = true
        bits[mask] = t
        freeOf[mask] = freeOf[mask - pow[hb]] + dlog[hb]
    end
    local preList = {}
    for i = 1, m do
        local l = {}
        for j = 1, m do if bits[pre[i]][j] then l[#l + 1] = j end end
        preList[i] = l
    end
    local dp, par = {}, {}
    for mask = 1, full do dp[mask], par[mask] = {}, {} end
    for i = 1, m do
        if pre[i] == 0 and (dlog[i] >= 0 or free0 > 0) then dp[pow[i]][i] = C0[i] end
    end
    for mask = 1, full do
        if mask % 32 == 0 then LP:Yield("plan") end
        local bm, fr, dm = bits[mask], freeOf[mask], dp[mask]
        for last = 1, m do
            local cur = dm[last]
            if cur then
                local Cl = C[last]
                for nx = 1, m do
                    if not bm[nx] and (dlog[nx] >= 0 or fr > 0) then
                        local okp = true
                        for _, j in ipairs(preList[nx]) do if not bm[j] then okp = false break end end
                        if okp then
                            local nm = mask + pow[nx]
                            local c = cur + Cl[nx]
                            local dn = dp[nm]
                            if not dn[nx] or c < dn[nx] then dn[nx], par[nm][nx] = c, last end
                        end
                    end
                end
            end
        end
    end
    local bestL, bestC
    for last = 1, m do
        local c = dp[full][last]
        if c then c = c + Cend[last] if not bestC or c < bestC then bestL, bestC = last, c end end
    end
    P.exactStats.runs = P.exactStats.runs + 1
    if not bestL then return false end
    -- bisherige Kette
    local old = C0[1] + Cend[m]
    for i = 1, m - 1 do old = old + C[i][i + 1] end
    if bestC >= old - 10 then return false end
    local seq, mask, last = {}, full, bestL
    while last do
        table.insert(seq, 1, last)
        local p = par[mask][last]
        mask = mask - pow[last]
        last = p
    end
    if #seq ~= m then return false end
    for i = 1, m do list[i + 1] = W[seq[i]] end
    if not Valid(list, free) then                         -- Sicherung: gleiche Regeln wie 2-opt, sonst wie vorher
        for i = 1, m do list[i + 1] = W[i] end
        return false
    end
    P.exactStats.better = P.exactStats.better + 1
    P.exactStats.saved = P.exactStats.saved + (old - bestC)
    return true, old, bestC
end

------------------------------------------------------------------------
-- Reise: Flugpunkte
------------------------------------------------------------------------
local function NearestTaxi(inst, n, w, maxD)
    local best, bestD
    for key in pairs(LP.char.taxiKnown) do
        local tx = LP.db.taxi[key] or (LP.Seed.taxi and LP.Seed.taxi[key])
        local _, _, _, i, tn, tw = LP.Geo:TaxiPoint(tx)
        if i then
            if i == inst then
                local d = LP.Geo:Dist(n, w, tn, tw)
                if d <= maxD and (not bestD or d < bestD) then best, bestD = tx, d end
            end
        end
    end
    return best, bestD
end

-- Unbekannter Flugmeister der eigenen Fraktion in der Naehe -> Flugpunkt mitnehmen
local FP_RANGE = 1000
P.FP_RANGE = FP_RANGE
function P:FlightPointTask(inst, n, w, curZone)
    local best, bestD
    for _, v in ipairs(LP.QuestDB:ServiceNPCs().flight or {}) do
        local key = (v.name or "?") .. ":" .. v.map
        if v.map == curZone and not LP.char.fpVisited[key] and not LP.char.doneKeys["FP:" .. key] then
            local i, vn, vw = LP.Geo:ToWorld(v.map, v.x, v.y)
            -- Pflichtregel: nicht zu Flugmeistern, an denen zu starke Mobs stehen
            if i == inst and LP.Danger and LP.Danger:At(i, vn, vw) >= LP.Danger:Limit() then i = nil end
            if i == inst then
                local d = LP.Geo:Dist(n, w, vn, vw)
                if d <= (P.FP_RANGE or FP_RANGE) and (not bestD or d < bestD) then best, bestD = v, d end
            end
        end
    end
    if not best then return nil end
    local i, vn, vw = LP.Geo:ToWorld(best.map, best.x, best.y)
    return { t = "FP", map = best.map, x = best.x, y = best.y, inst = i, n = vn, w = vw, npc = best.name,
             text = L["holen bei "] .. (best.name or L["Flugmeister"]), key = "FP:" .. (best.name or "?") .. ":" .. best.map }
end

------------------------------------------------------------------------
-- Ruhestein: benutzen, wenn das Ziel nahe am Bindeort und weit weg ist; binden in neuen Hauptzonen
------------------------------------------------------------------------
-- Ruhestein: Mindestweg (Yards), Bindeort hoechstens dieser Anteil des Weges vom Ziel, Gastwirt in der Naehe (Yards)
P.HEARTH = { min = 1200, gain = 0.5, bind = 600 }
local BIND_TASKS = 6          -- so viele Aufgaben in der Zone, damit sich das Binden lohnt
local BIND_TASKS_SPEED = 3    -- im Speedrun (weniger Quests je Zone, Ruhestein spart dort am meisten)

function P:HearthStep(target, inst, n, w)
    if not LP.db.useHearth or not target or not target.inst then return nil end
    local b = LP.char.bind
    if type(b) ~= "table" or not b.map or not LP.API.HearthReady() then return nil end
    local bi, bn, bw = LP.Geo:ToWorld(b.map, b.x, b.y)
    if not bi or bi ~= target.inst then return nil end
    if inst == bi and LP.Geo:Dist(n, w, bn, bw) < 300 then return nil end
    local dTarget = (target.inst == inst) and LP.Geo:Dist(n, w, target.n, target.w) or OTHER_CONTINENT
    local dBind = LP.Geo:Dist(bn, bw, target.n, target.w)
    if dTarget < P.HEARTH.min then return nil end
    -- 3.12.86 OPT-ROUTE H3 (Supervisor 03:58): Ruhestein auch, wenn der Reiseplan "Ruhestein + weiter (Flug, Schiff)" schneller
    -- rechnet als ohne – nicht nur, wenn das Ziel nahe am Bindeort liegt (Factoruide: Ruhestein in die Stadt, dann Flug).
    -- In einer Planungs-Portion (Jobs) direkt aufrufen: die Wegsuche gibt dort ab (LP:Yield), und das geht nicht durch pcall.
    if dBind > dTarget * P.HEARTH.gain then
        local okp, plan
        if LP.Jobs and LP.Jobs.Current and LP.Jobs.Current() then
            okp, plan = true, P.TravelPlan(self, inst, n, w, select(4, LP.Geo:Player()), target, P.PATH_CHECK_EXPAND)
        else
            okp, plan = pcall(P.TravelPlan, self, inst, n, w, select(4, LP.Geo:Player()), target, P.PATH_CHECK_EXPAND)
        end
        if not (okp and plan and plan.hearth) then return nil end
    end
    return { t = "HEARTH", text = b.name or "?", map = b.map, x = b.x, y = b.y, inst = bi, n = bn, w = bw,
             noNav = true, item = LP.API.HEARTHSTONE, key = "HEARTH:" .. (target.key or "?") }
end

function P:BindStep(selected, inst, n, w, focus)
    if not LP.db.useHearth or not focus then return nil end
    local b = LP.char.bind
    if type(b) == "table" and P.ZoneOf(b.map) == focus then return nil end
    local cnt = 0
    for _, t in ipairs(selected) do if P.ZoneOf(t.map) == focus then cnt = cnt + 1 end end
    if cnt < (self:IsSpeed() and BIND_TASKS_SPEED or BIND_TASKS) then return nil end
    local v, d = LP.QuestDB:NearestService("inn", function(x) return P.ZoneOf(x.map) == focus end)
    if not v or not d or d > P.HEARTH.bind then return nil end
    local vi, vn, vw = LP.Geo:ToWorld(v.map, v.x, v.y)
    return { t = "BIND", npc = v.name, text = LP.Geo:MapName(focus), map = v.map, x = v.x, y = v.y,
             inst = vi, n = vn, w = vw, key = "BIND:" .. focus }
end

local PATH_CHECK_MAX = 6000      -- Yards: noch weitere Wege uebernehmen Flug/Ruhestein (eigene Schritte)
P.PATH_CHECK_EXPAND = 1200     -- 3.12.24: hoechstens so viele Suchschritte je Pruefung
function P:CheckFirstPath(ordered, inst, n, w, curZone, level)
    local Dg = LP.Danger
    if not Dg or not Dg.pathRule or not inst or not LP.Graph then return end
    local lim = Dg:Limit(level)
    for _ = 1, 3 do
        local t = ordered[1]
        if not t or t.t == "DUNGEON" or t.inst ~= inst or not t.n then return end
        local d = LP.Geo:Dist(n, w, t.n, t.w)
        if d <= ROUTE_SKIP or d > PATH_CHECK_MAX then return end
        -- 3.12.24: in der Planung nur eine kurze Wegsuche (die Navigation sucht danach genau, in Portionen)
        local okp, path
        if LP.Jobs.Current() then okp, path = true, LP.Graph:Path(inst, n, w, curZone, t.inst, t.n, t.w, t.map, P.PATH_CHECK_EXPAND)
        else okp, path = pcall(LP.Graph.Path, LP.Graph, inst, n, w, curZone, t.inst, t.n, t.w, t.map, P.PATH_CHECK_EXPAND) end
        if not okp then return end
        local worst = Dg:PathDanger(path, ROUTE_SKIP, lim)
        if worst < lim then return end
        table.remove(ordered, 1)
        t.pathBlocked = true
        MS.path = MS.path + 1
        if t.id then self.mobSkip[t.id] = self.mobSkip[t.id] or worst end
    end
end

-- wann fliegen: Mindeststrecke, Suchradius der Flugmeister, Gewicht des Fusswegs, fester Aufschlag (Yards)
P.FLY_RULE = { min = 2000, from = 2500, to = 3000 }   -- ab dieser Luftlinie prüfen; Flugmeister so weit von Start/Ziel

-- 3.12.49 LW-3: Flug nach ZEIT statt nach Strecke. Laufen = Luftlinie × Umweg / Tempo; Fliegen = zum Flugmeister + Gespräch +
-- Flugzeit + vom Flugmeister. Flugzeit aus den eigenen gemessenen Flügen (Calib, ab 3 Flügen; Mitspieler ergänzen), sonst
-- Annahme (wie die virtuelle Reise). Tempo am Boden: gemessenes Reittier-Tempo (LevelPilotCharDB.mountYps, Laufweg-Messung),
-- sonst 7 Yards/s zu Fuss. Umweg 1,25 auf allen Fusswegen (Verdacht – kommt mit LW-1 aus Wegnetz und Geländekarte).
P.TRAVEL = { detour = 1.25, run = 7, fpHandling = 15, margin = 30, flyYps = 32, flyDetour = 1.3, flyStart = 30 }
function P.GroundYps()
    local m = LP.char and LP.char.mountYps
    if type(m) == "number" and m > P.TRAVEL.run then return m, "Reittier gemessen" end
    return P.TRAVEL.run, "zu Fuss"
end
function P.FlightSecs(dist)
    local s = LP.Calib and LP.Calib.FlightSecs and LP.Calib:FlightSecs(dist)
    if s then return s, "gemessen" end
    local T = P.TRAVEL
    return T.flyStart + dist * T.flyDetour / T.flyYps, "Annahme"
end
-- fliegen? (true, Sekunden laufen, Sekunden mit Flug) – nur, wenn der Flug mindestens margin Sekunden schneller ist
function P.FlyDecision(direct, d1, d2, flySecs, yps, detour)
    local T = P.TRAVEL
    detour = detour or T.detour                         -- 3.12.51 LW-1: Umweg der Zielzone (Graph:Detour)
    local walk = direct * detour / yps
    local fly = (d1 + d2) * detour / yps + T.fpHandling + flySecs
    return fly + T.margin < walk, walk, fly
end

function P:TravelSteps(target, inst, n, w)
    if not target or not target.inst then return {} end
    local steps = {}
    if target.inst ~= inst then return steps end          -- Kontinentwechsel: Schiff/Zeppelin ueber das Wegenetz
    local direct = LP.Geo:Dist(n, w, target.n, target.w)
    local F = P.FLY_RULE
    if direct < F.min then return steps end
    local fromFP, d1 = NearestTaxi(inst, n, w, F.from)
    local toFP, d2 = NearestTaxi(target.inst, target.n, target.w, F.to)
    if not (fromFP and toFP and fromFP ~= toFP) then return steps end
    local fm, fx, fy, fi, fn, fw = LP.Geo:TaxiPoint(fromFP)
    local _, _, _, ti, tn, tw = LP.Geo:TaxiPoint(toFP)
    if not (fi and ti and fi == ti) then return steps end
    local yps, ysrc = P.GroundYps()
    local fs, fsrc = P.FlightSecs(LP.Geo:Dist(fn, fw, tn, tw))
    local fly, walkS, flyS = P.FlyDecision(direct, d1, d2, fs, yps, P.OPT.wayCost and P.WayFactor(target.map) or nil)
    P.lastTravel = { walk = walkS, fly = flyS, took = fly, yps = yps, ysrc = ysrc, fsrc = fsrc, to = toFP.name }
    if fly then
        if d1 > 30 then
            steps[#steps + 1] = {
                t = "GOTO", map = fm, x = fx, y = fy, inst = fi, n = fn, w = fw,
                text = L["Zum Flugmeister: "] .. (fromFP.name or "?"), key = "FPGO:" .. (fromFP.name or ""),
            }
        end
        steps[#steps + 1] = {
            t = "FLY", text = toFP.name or "?", from = fromFP.name, map = fm, x = fx, y = fy,
            inst = fi, n = fn, w = fw, key = "FLY:" .. (toFP.name or ""),
        }
    end
    return steps
end

------------------------------------------------------------------------
-- 3.12.58 NAV-2: Reiseplan nach ZEIT – Kette aus Teilstuecken mit Sekunden je Teilstueck
------------------------------------------------------------------------
-- Laufen/Reiten: Weg aus dem Wegnetz (Graph:Path, Wegkosten wie LW-1) / Tempo (P.GroundYps). Flug: je Bodenstueck ab
-- FLY_RULE.min Luftlinie dieselbe Regel wie TravelSteps (FlyDecision, gemessene Flugzeit LW-3). Schiff/Zeppelin/
-- Tiefenbahn/Portal: Zeit der Kante (Data/Gateways.lua: halbe Taktzeit + Fahrt + Ladebildschirm). Ruhestein: wenn bereit
-- und der Plan ab dem Bindeort samt Zauberzeit (+ Ladebildschirm bei anderem Kontinent) um margin Sekunden schneller ist.
-- Zauberzeit 10 s (Spielregel), Ladebildschirm 20 s = Annahme (Verdacht, zu messen).
P.TRAVEL.hearthCast, P.TRAVEL.hearthLoad = 10, 20
P.NAV_EXPAND = 4000                  -- Suchschritte je Wegsuche des Reiseplans
local TRANSPORT = { boat = true, zep = true, tram = true, portal = true }
P.TRANSPORT = TRANSPORT

-- Bodenstueck -> Teilstuecke (laufen, oder: zum Flugmeister, Flug, vom Flugmeister)
local function GroundLegs(out, a, b, len, yps)
    if len <= 0 then return end
    local direct = (a[1] == b[1]) and LP.Geo:Dist(a[2], a[3], b[2], b[3]) or 0
    local F = P.FLY_RULE
    if direct >= F.min and LP.char and LP.char.taxiKnown and LP.db and LP.db.taxi then
        local fromFP, d1 = NearestTaxi(a[1], a[2], a[3], F.from)
        local toFP, d2 = NearestTaxi(b[1], b[2], b[3], F.to)
        if fromFP and toFP and fromFP ~= toFP then
            local _, _, _, fi, fn, fw = LP.Geo:TaxiPoint(fromFP)
            local _, _, _, ti, tn, tw = LP.Geo:TaxiPoint(toFP)
            if fi and fi == ti then
                local detour = len / direct
                local fs = P.FlightSecs(LP.Geo:Dist(fn, fw, tn, tw))
                local fly = P.FlyDecision(direct, d1, d2, fs, yps, detour)
                if fly then
                    if d1 > 30 then out[#out + 1] = { k = "walk", dist = d1 * detour, secs = d1 * detour / yps, to = fromFP.name } end
                    out[#out + 1] = { k = "fly", secs = P.TRAVEL.fpHandling + fs, to = toFP.name, from = fromFP.name }
                    if d2 > 30 then out[#out + 1] = { k = "walk", dist = d2 * detour, secs = d2 * detour / yps } end
                    return
                end
            end
        end
    end
    out[#out + 1] = { k = "walk", dist = len, secs = len / yps }
end

-- Plan ohne Ruhestein: Teilstuecke entlang des Wegnetzes
local function PlanPath(sInst, sn, sw, sZone, g, maxExpand)
    local path, kind = LP.Graph:Path(sInst, sn, sw, sZone, g.inst, g.n, g.w, g.map, maxExpand or P.NAV_EXPAND)
    if not path or #path < 1 then return nil end
    local yps = P.GroundYps()
    local legs, startPt, len, prev = {}, path[1], 0, path[1]
    for i = 2, #path do
        local pt = path[i]
        if TRANSPORT[pt.via] then
            GroundLegs(legs, startPt, prev, len, yps)
            legs[#legs + 1] = { k = pt.via, secs = tonumber(pt.secs) or 120, name = pt.name, zone = pt[4] }
            startPt, len = pt, 0
        elseif pt[1] == prev[1] then
            len = len + LP.Geo:Dist(prev[2], prev[3], pt[2], pt[3])
        else
            startPt, len = pt, 0          -- Sprung ohne Transportkante (sollte nicht vorkommen): neu ansetzen
        end
        prev = pt
    end
    GroundLegs(legs, startPt, prev, len, yps)
    local total = 0
    for _, l in ipairs(legs) do total = total + l.secs end
    -- 3.12.62 NAV-3: Gefahr auf dem Weg (Mobs ab Spielerlevel + 3). Die Wegsuche meidet solche Gebiete schon (Umweg, wenn es
    -- einen gibt); bleibt trotzdem etwas, steht es im Plan.
    local danger
    local Dg = LP.Danger
    if Dg and Dg.PathDanger and Dg.Limit then
        local lim = Dg:Limit()
        local worst, di, dn, dw = Dg:PathDanger(path, 0, lim)
        if worst and worst >= lim then danger = { level = worst, inst = di, n = dn, w = dw } end
    end
    return { legs = legs, total = total, kind = kind, danger = danger }
end
P.PlanPath = PlanPath

-- 3.12.66 LW-7 (d) "Tod als Reise" (Entscheid des Nutzers 16.11. 13:27, Schwelle 3 min Supervisor 13:57): nur im Speedrun,
-- nur bis Stufe 10, Schalter deathSkip (aus). Rechnung: Plan ab dem nächsten Friedhof (Datenpaket 1.6.2, D.GY) + Sterben 90 s
-- + Auferstehen 10 s (ANNAHMEN, ungünstig gewählt: der Hinweis soll auch dann klar lohnen) gegen den normalen Plan. Nur ein
-- Hinweis (Zeile im Reiseplan), nie ein Schritt. Kosten (Haltbarkeit, Nachwirkungen) in Forever noch nicht gemessen – darum
-- ohne Zahlen dazu.
P.DEATH = { maxLevel = 10, die = 90, res = 10, minGain = 180 }
local graveCache
function P.Graves()
    local d = _G.LevelPilotData
    local gy = type(d) == "table" and d.GY
    if type(gy) ~= "table" or #gy == 0 then return nil end
    if graveCache and graveCache.src == gy and graveCache.n == #gy then return graveCache.list end
    local list = {}
    for _, g in ipairs(gy) do
        local i, n, w = LP.Geo:ToWorld(g[1], g[2], g[3])
        if i then list[#list + 1] = { inst = i, n = n, w = w, map = g[1], x = g[2], y = g[3] } end
    end
    graveCache = { src = gy, n = #gy, list = list }
    return list
end
function P:DeathSkip(plan, sInst, sn, sw, g, maxExpand)
    local D = P.DEATH
    if not (plan and LP.db and LP.db.deathSkip and self:IsSpeed()) then return nil end
    if (LP:PlayerLevel() or 99) > D.maxLevel then return nil end
    local list = P.Graves()
    if not list then return nil end
    local best, bd
    for _, gr in ipairs(list) do
        if gr.inst == sInst then
            local d = LP.Geo:Dist(sn, sw, gr.n, gr.w)
            if not bd or d < bd then best, bd = gr, d end
        end
    end
    if not best or best.inst ~= g.inst then return nil end
    local sub = PlanPath(best.inst, best.n, best.w, best.map, g, maxExpand)
    if not sub then return nil end
    local total = D.die + D.res + sub.total
    local gain = plan.total - total
    if gain < D.minGain then return nil end
    return { gain = gain, total = total, map = best.map, x = best.x, y = best.y }
end

-- Reiseplan von (sInst, sn, sw, sZone) zum Ziel g = { inst, n, w, map }: { legs = {...}, total = Sekunden, kind, hearth }
function P:TravelPlan(sInst, sn, sw, sZone, g, maxExpand)
    if not (sInst and sn and g and g.inst and g.n) or not LP.Graph then return nil end
    local plan = PlanPath(sInst, sn, sw, sZone, g, maxExpand)
    local b = LP.char and LP.char.bind
    if LP.db and LP.db.useHearth and type(b) == "table" and b.map and LP.API.HearthReady() then
        local bi, bn, bw = LP.Geo:ToWorld(b.map, b.x, b.y)
        if bi and not (bi == sInst and LP.Geo:Dist(sn, sw, bn, bw) < 300) then
            local sub = PlanPath(bi, bn, bw, b.map, g, maxExpand)
            if sub then
                local T = P.TRAVEL
                local h = T.hearthCast + (bi ~= sInst and T.hearthLoad or 0)
                if not plan or h + sub.total + T.margin < plan.total then
                    table.insert(sub.legs, 1, { k = "hearth", secs = h, to = b.name })
                    sub.total, sub.hearth = sub.total + h, true
                    plan = sub
                end
            end
        end
    end
    if plan then plan.deathSkip = self:DeathSkip(plan, sInst, sn, sw, g, maxExpand) end
    return plan
end

local function MinSec(secs)
    secs = math.floor((secs or 0) + 0.5)
    return string.format("%d:%02d", math.floor(secs / 60), secs % 60)
end
P.MinSec = MinSec
local function LegName(k)
    if k == "boat" then return L["Schiff"] elseif k == "zep" then return L["Zeppelin"]
    elseif k == "tram" then return L["Tiefenbahn"] elseif k == "portal" then return L["Portal"] end
    return L["Fahrt"]
end
-- Text wie ein Navi: "Reise ~4:35: 300 yd laufen (0:43) → Flug nach X (2:10) → …"
function P.PlanText(plan)
    if not plan then return nil end
    local parts = {}
    for _, l in ipairs(plan.legs) do
        local t
        if l.k == "walk" then t = L("%s laufen", LP:FormatDist(l.dist or 0))
        elseif l.k == "fly" then
            -- 3.12.67: Preis aus der eigenen Messung (Flugmeister geöffnet), sonst "Preis unbekannt"
            local c = LP.Recorder and LP.Recorder.FlightCost and LP.Recorder.FlightCost(l.from, l.to)
            local price = c and LP.Session and LP.Session.Money and LP.Session.Money(c) or L["Preis unbekannt"]
            t = L("Flug nach %s", l.to or "?") .. ", " .. price
        elseif l.k == "hearth" then t = L("Ruhestein nach %s", l.to or "?")
        else t = LegName(l.k) .. (l.zone and (" → " .. (LP.Geo:MapName(l.zone) or "?")) or "") end   -- Name der Zone in der Sprache des Spiels
        parts[#parts + 1] = t .. " (" .. MinSec(l.secs) .. ")"
    end
    local txt = L("Reise ~%s: %s", MinSec(plan.total), table.concat(parts, " → "))
    if plan.danger then txt = txt .. "\n|cffff5555" .. L("Vorsicht: Gegner bis Stufe %d auf dem Weg", plan.danger.level) .. "|r" end
    if plan.deathSkip then
        local ds = plan.deathSkip
        txt = txt .. "\n|cffffb238" .. L("Speedrun-Trick: hier sterben und beim Geistheiler (%s %.0f, %.0f) auferstehen spart ~%d min – kostet Haltbarkeit",
            LP.Geo:MapName(ds.map) or "?", ds.x, ds.y, math.floor(ds.gain / 60)) .. "|r"
    end
    return txt
end

------------------------------------------------------------------------
-- Planung
------------------------------------------------------------------------
-- Zustand fuer Anzeige und Diagnose: "ok", "nodata", "noquests", "noposition", "error"
P.state = "start"
P.diag = {}

function P:Replan(verbose)
    if not LP.db then return end
    -- waehrend der virtuellen Reise plant nur die Reise selbst (Ereignisse des Spiels warten)
    if LP.Virtual and LP.Virtual.active and coroutine.running() ~= LP.yieldCo then return end
    local function failed(err)
        self.state = "error"
        self.status = L["Fehler bei der Planung"]
        LP:Error(L["Routenplanung"], err)
        LP:Fire("PLAN_CHANGED")
    end
    -- 3.12.24: automatische Neuplanung in Portionen (hoechstens 4 ms je Bild); ein Klick des Nutzers rechnet sofort.
    -- Laeuft schon eine, wird danach einmal nachgeplant.
    -- 3.12.34 PF-A-Rest: ein Klick (verbose) rechnet sofort – ausser die Zwischenspeicher sind kalt (neue Stufe, neue
    -- Sprache, neues Datenpaket): dann waere die Planung am Stueck bis ~26 ms (Nachbau) und laeuft ebenfalls in Portionen
    local cold = verbose and self:Cold()
    if (not verbose or cold) and LP.Jobs and not LP.Jobs.sync and not (LP.Virtual and LP.Virtual.active)
       and not LP.Jobs.Current() then
        if LP.Jobs.Running("replan") then self.replanPending = true return end
        LP.Jobs.Start("replan", "route", function() self:DoReplan(verbose) end, function(ok, err)
            if not ok then failed(err) end
            -- 3.12.25: bei Portionen zaehlt die laengste Portion (eine lange Planung in kleinen Portionen stockt nicht)
            if LP.Perf and not (LP.Act and LP.Act.dry) then
                LP.Perf.CheckSlice("route", LP.Jobs.lastMax or 0, LP.Perf.info and LP.Perf.info("route"))
            end
            if self.replanPending then
                self.replanPending = nil
                C_Timer.After(0.5, function() self:Replan() end)
            end
        end, { plan = true, graph = true })
        return
    end
    if LP.Jobs and LP.Jobs.Running("replan") then LP.Jobs.Cancel("replan") self.replanPending = nil end
    local ok, err = pcall(self.DoReplan, self, verbose)
    if not ok then failed(err) end
end

-- abgabebereite Quests (complete im Questlog) bis NEAR_TURNIN Yards vom Spieler an den Anfang: die naechste zuerst,
-- dann jeweils die naechste vom letzten Abgabeort aus (3.12.7, Befund aus Mulgore)
function P:NearTurninsFirst(steps, inst, n, w)
    if not (steps and inst and n and w) then return steps end
    local near = {}
    for i = #steps, 1, -1 do
        local s = steps[i]
        local st = s.t == "TURNIN" and s.id and self.inLog[s.id]
        if st and st.complete and s.inst == inst and s.n then
            local d = LP.Geo:Dist(n, w, s.n, s.w)
            if d <= P.NEAR_TURNIN then table.remove(steps, i) s.nearTurnin = true near[#near + 1] = s end
        end
    end
    for _, s in ipairs(steps) do s.nearTurnin = nil end
    local out, cn, cw = {}, n, w
    while #near > 0 do
        local bi, bd
        for k, s in ipairs(near) do
            local d = LP.Geo:Dist(cn, cw, s.n, s.w)
            if not bd or d < bd then bi, bd = k, d end
        end
        local s = table.remove(near, bi)
        out[#out + 1] = s
        cn, cw = s.n, s.w
    end
    for k = #out, 1, -1 do table.insert(steps, 1, out[k]) end
    return steps
end

------------------------------------------------------------------------
-- 3.12.71 ERA-1 (Nutzer 17:13): Startgebiete. Unter Stufe P.START_LEVEL bleibt die Route im Startgebiet, solange es dort
-- Aufgaben gibt – kein Ziel aus dem Dorf der Stufe 5–10 (Goldhain, Kharanos, Dolanaar, Klingenhügel, Brill, Bluthuf), auch
-- kein Binden und kein Flugpunkt. Startgebiet = alle Orte, die näher am Startpunkt des Volkes liegen als am nächsten Gasthaus
-- (die Grenze liegt so mitten zwischen Startplatz und erstem Dorf, ohne feste Yard-Zahl – passt für jede Kartengrösse).
-- Dazu nie weiter vom Startpunkt als das Gasthaus. Start-Gebiete anderer Völker sind unter Stufe 6 kein Ziel (vorher: Ork mit
-- Stufe 4 von Durotar nach Camp Narache, 6000 yd). Ab Stufe 6 gilt nichts davon (Messung: sonst Mensch 1–60 +15 h).
------------------------------------------------------------------------
P.START_LEVEL = 6
P.RACE_START = {
    Human = { 1429, 48.2, 42.9 }, Dwarf = { 1426, 29.9, 71.2 }, Gnome = { 1426, 29.9, 71.2 },
    NightElf = { 1438, 58.6, 44.6 }, Orc = { 1411, 43.3, 68.5 }, Troll = { 1411, 43.3, 68.5 },
    Scourge = { 1420, 30.2, 71.7 }, Tauren = { 1412, 44.2, 76.1 },
}
local startCache, startCacheKey
function P:StartAreas()
    -- 3.12.72 ORT-1: mit Ortsdaten (Datenpaket 1.6.3) = Gebiets-IDs aus den Spieldateien (LP.Orte.START), sonst die Mittellinie
    -- Startplatz–Gasthaus aus 3.12.71
    local O = LP.Orte
    if O and O.Available() then
        if startCache and startCacheKey == "orte" then return startCache end
        local byMap, list = {}, {}
        for race, st in pairs(P.RACE_START) do
            local ids = O.START[race]
            local key = ids and table.concat(ids, ",")
            if key then
                local a = byMap[key]
                if not a then
                    local i, n, w = LP.Geo:ToWorld(st[1], LP.Geo:FromData(st[1], st[2], st[3]))
                    a = { inst = i, n = n, w = w, map = st[1], races = {}, ids = {} }
                    for _, id in ipairs(ids) do a.ids[id] = true end
                    byMap[key] = a
                    if i then list[#list + 1] = a end
                end
                a.races[race] = true
            end
        end
        startCache, startCacheKey = list, "orte"
        return list
    end
    local inns = LP.QuestDB:ServiceNPCs().inn or {}
    if startCache and startCacheKey == inns then return startCache end
    local byPoint, list = {}, {}
    for race, st in pairs(P.RACE_START) do
        local key = st[1] .. ":" .. st[2] .. ":" .. st[3]
        local a = byPoint[key]
        if not a then
            local i, n, w = LP.Geo:ToWorld(st[1], LP.Geo:FromData(st[1], st[2], st[3]))
            local best, bi, bn, bw
            if i then
                for _, v in ipairs(inns) do
                    local vi, vn, vw = LP.Geo:ToWorld(v.map, v.x, v.y)
                    if vi == i then
                        local d = LP.Geo:Dist(n, w, vn, vw)
                        if not best or d < best then best, bn, bw = d, vn, vw end
                    end
                end
            end
            if best then
                a = { inst = i, n = n, w = w, innN = bn, innW = bw, r = best, map = st[1], races = {} }
                list[#list + 1] = a
            else
                a = { races = {} }      -- ohne Gasthaus nicht bestimmbar: kein Startgebiet
            end
            byPoint[key] = a
        end
        a.races[race] = true
    end
    startCache, startCacheKey = list, inns
    return list
end
function P.InStartArea(a, inst, n, w)
    if not (a and a.inst and inst == a.inst and n) then return false end
    if a.ids then
        local id = LP.Orte.AtWorld(a.map, inst, n, w)
        return id ~= nil and a.ids[id] == true
    end
    local d = LP.Geo:Dist(n, w, a.n, a.w)
    -- näher am Startpunkt als am Gasthaus UND innerhalb des Kreises Startpunkt–Gasthaus (sonst wäre es eine Halbebene)
    return d < a.r and d < LP.Geo:Dist(n, w, a.innN, a.innW)
end
function P:StartAreaAt(inst, n, w)
    if not inst then return nil end
    for _, a in ipairs(self:StartAreas()) do if P.InStartArea(a, inst, n, w) then return a end end
end
-- Aufgaben filtern; liefert die gefilterte Liste und das Startgebiet, in dem die Regel gerade gilt (oder nil)
function P:StartFilter(tasks, level, inst, n, w, race)
    if (level or 99) >= P.START_LEVEL then
        self.diag.startArea, self.diag.startForeign = nil, 0
        return tasks, nil
    end
    local here = self:StartAreaAt(inst, n, w)
    local rule = here
    local out, inside, foreign = {}, 0, 0
    for _, t in ipairs(tasks) do
        local a = t.n and t.inst and self:StartAreaAt(t.inst, t.n, t.w)
        if a and a ~= here and not (race and a.races[race]) then
            foreign = foreign + 1                     -- Startgebiet eines anderen Volkes
        else
            out[#out + 1] = t
            if rule and a == rule and not t.pathBlocked then inside = inside + 1 end
        end
    end
    local outside = 0
    if rule and inside > 0 then
        local keep = {}
        for _, t in ipairs(out) do
            -- 3.12.73 (ROUTE-Q R1, O5): ein Questgeber gleich am Weg (<= P.NEAR_ACCEPT) wird mitgenommen, auch knapp ausserhalb
            if not t.n or not t.inst or P.InStartArea(rule, t.inst, t.n, t.w)
               or (t.t == "ACCEPT" and t.inst == inst and LP.Geo:Dist(n, w, t.n, t.w) <= (P.NEAR_ACCEPT or 150)) then keep[#keep + 1] = t
            else outside = outside + 1 end
        end
        out = keep
    end
    self.diag.startArea = rule and (rule.map .. ":" .. inside .. "/" .. outside) or nil
    self.diag.startForeign = foreign
    return out, rule
end

-- 3.12.71 ERA-1 (Nutzer 17:13): im Startgebiet zuerst alle erreichbaren Questgeber annehmen, dann erledigen – Annahmen im
-- Startgebiet, die hinter dem ersten "Erledigen" stehen, kommen davor (Reihenfolge untereinander bleibt). Liefert die Anzahl.
function P.AcceptsFirst(ordered, area)
    local fc
    for i, t in ipairs(ordered) do if t.t == "COMPLETE" then fc = i break end end
    if not fc then return 0 end
    local moved = {}
    for i = #ordered, fc + 1, -1 do
        local t = ordered[i]
        if t.t == "ACCEPT" and P.InStartArea(area, t.inst, t.n, t.w) then table.insert(moved, 1, table.remove(ordered, i)) end
    end
    for k, t in ipairs(moved) do table.insert(ordered, fc + k - 1, t) end
    return #moved
end

-- 3.12.71 ERA-1 (Supervisor 17:15): Binden nur, wenn das Gasthaus AUF dem Weg liegt – Umweg gegenüber dem direkten Weg
-- zwischen zwei Routenschritten (bzw. Spieler -> erster Schritt) höchstens P.BIND_DETOUR Yards. Sonst kein Binden-Schritt
-- (jede neue Planung prüft wieder; kommt die Route am Gasthaus vorbei, wird gebunden).
P.BIND_DETOUR = 60
function P.InsertOnWay(steps, x, base, inst, n, w, maxDetour, earliest)
    if not (x.inst == inst and x.n) then return nil end
    local G = LP.Geo
    local pn, pw = n, w
    local bestPos, bestD
    for i = (base or 0) + 1, #steps + 1 do
        local s = steps[i]
        local det
        if s and s.inst == inst and s.n then
            det = G:Dist(pn, pw, x.n, x.w) + G:Dist(x.n, x.w, s.n, s.w) - G:Dist(pn, pw, s.n, s.w)
        elseif not s then
            det = G:Dist(pn, pw, x.n, x.w)          -- ans Ende: der ganze Weg dorthin ist Umweg
        end
        if det and (not bestD or det < bestD) then bestPos, bestD = i, det end
        -- 3.12.78 (O5): frueheste Stelle mit kleinem Umweg genuegt (Questgeber unterwegs gleich mitnehmen, nicht erst danach)
        if earliest and bestD and bestD <= (maxDetour or P.BIND_DETOUR) then break end
        if not (s and s.inst == inst and s.n) then break end     -- Reise/anderer Kontinent: dahinter nicht mehr vergleichen
        pn, pw = s.n, s.w
    end
    if not bestD or bestD > (maxDetour or P.BIND_DETOUR) then return nil, bestD end
    table.insert(steps, bestPos, x)
    return bestPos, bestD
end

-- 3.12.71 ERA-1: Schritt x vor den ersten Routenschritt (ab Stelle base + 1) setzen, der weiter vom Spieler weg ist als x
-- (oder auf einem anderen Kontinent / ohne Ort); sonst ans Ende. Die nahen Aufgaben kommen so zuerst.
function P.InsertByDistance(steps, x, base, inst, n, w)
    local dx = (x.inst == inst and x.n) and LP.Geo:Dist(n, w, x.n, x.w) or math.huge
    local pos = #steps + 1
    for i = (base or 0) + 1, #steps do
        local s = steps[i]
        local d = (s.inst == inst and s.n) and LP.Geo:Dist(n, w, s.n, s.w) or math.huge
        if d > dx then pos = i break end
    end
    table.insert(steps, pos, x)
    return pos
end

-- 3.12.73 ORT-1 (Nutzer 17:13/17:31 "im Ort zuerst alle Quests annehmen"), ROUTE-Q R1/R4: Liegt ein annehmbarer Questgeber
-- höchstens P.NEAR_ACCEPT Yards vom Spieler, kommt seine Annahme vor jedes Ziel, das weiter weg ist, und vor jeden Sonder-Schritt
-- (Binden, Flugpunkt, Ruhestein, Reise). Mehrere: nächster zuerst, dann jeweils der nächste von dort. Fehlt die Annahme in der
-- Route (Fokus/Wert), wird sie aus den Aufgaben geholt. Liefert die Anzahl vorgezogener Annahmen.
P.NEAR_ACCEPT = 150
local SPECIAL_STEP = { BIND = true, FP = true, HEARTH = true, FLY = true, GOTO = true }
-- 3.12.77 ORT-1 O2 ("im Ort zuerst alle Quests annehmen"): steht der Spieler in einem Ort (Teilgebiet mit Gebiets-ID aus den
-- Spieldaten), zählen auch Annahmen im selben Ort bis P.HUB_RADIUS Yards als "nah" (z. B. Späherkuppe, Kharanos).
P.HUB_RADIUS = 400
function P.HubOf(map, inst, n, w)
    local O = LP.Orte
    if not (O and O.Available() and map and n) then return nil end
    local id = O.AtWorld(map, inst, n, w)
    local parent = id and O.Info(id)
    if id and parent and parent ~= 0 then return id end
end
function P.NearAcceptsFirst(steps, tasks, inst, n, w, near, map)
    near = near or P.NEAR_ACCEPT
    local G = LP.Geo
    local hub = map and P.HubOf(map, inst, n, w)
    local function D(t)
        local d = (t.inst == inst and t.n) and G:Dist(n, w, t.n, t.w) or math.huge
        if hub and d > near and d <= P.HUB_RADIUS and t.map and P.HubOf(t.map, t.inst, t.n, t.w) == hub then return near end
        return d
    end
    local cand, seen = {}, {}
    for i = #steps, 1, -1 do
        local t = steps[i]
        if t.t == "ACCEPT" and not t.explicit and D(t) <= near then
            cand[#cand + 1] = table.remove(steps, i)
            seen[t.key] = true
        end
    end
    for _, t in ipairs(tasks or {}) do
        if t.t == "ACCEPT" and not seen[t.key] and not t.pathBlocked and D(t) <= near then
            cand[#cand + 1] = t
            seen[t.key] = true
        end
    end
    if #cand == 0 then return 0 end
    -- Kette: vom Spieler zum nächsten, von dort zum nächsten …
    local chain, cn, cw = {}, n, w
    while #cand > 0 do
        local bi, bd
        for i, t in ipairs(cand) do
            local d = G:Dist(cn, cw, t.n, t.w)
            if not bd or d < bd or (d == bd and t.key < cand[bi].key) then bi, bd = i, d end
        end
        local t = table.remove(cand, bi)
        chain[#chain + 1] = t
        cn, cw = t.n, t.w
    end
    -- Platz: nach den führenden nahen Schritten (<= near, kein Sonder-Schritt)
    -- 3.12.77: hier die echte Entfernung (nicht die Ort-Regel) – sonst blieb eine Abgabe 200 yd weit vor einem Questgeber in 100 yd
    local function DT(t) return (t.inst == inst and t.n) and G:Dist(n, w, t.n, t.w) or math.huge end
    local pos = 1
    while steps[pos] and not SPECIAL_STEP[steps[pos].t] and DT(steps[pos]) <= near do pos = pos + 1 end
    for k, t in ipairs(chain) do table.insert(steps, pos + k - 1, t) end
    return #chain, pos + #chain - 1          -- Anzahl, letzte Stelle der Kette
end

-- 3.12.78 ORT-1 O5 (Nutzer 17:34): Questgeber, die nicht im Ort, sondern unterwegs stehen (Wildnis, Lager, Turm), werden auf
-- dem Weg mitgenommen: Annahme, die zwischen zwei Routenschritten (oder Spieler -> erstem Schritt) höchstens P.ONWAY_DETOUR Yards
-- Umweg kostet, kommt an diese Stelle (P.InsertOnWay, wie Binden). Nur Annahmen bis P.ONWAY_RANGE Yards, die noch nicht in der
-- Route stehen; nie vor ein vom Spieler gewähltes Ziel.
P.ONWAY_DETOUR, P.ONWAY_RANGE = 60, 1500
function P.OnWayAccepts(steps, tasks, inst, n, w, after)
    local have, cnt = {}, 0
    for _, t in ipairs(steps) do if t.key then have[t.key] = true end end
    local base = math.max((steps[1] and steps[1].explicit) and 1 or 0, after or 0)
    -- Ausgangspunkt fuer den Umweg: das Ende der Kette (dort steht der Spieler dann)
    if base > 0 and steps[base] and steps[base].inst == inst and steps[base].n then n, w = steps[base].n, steps[base].w end
    -- Annahmen, die schon in der Route stehen, aber erst später: an die günstigste Stelle davor, wenn der Umweg dort klein ist
    -- 3.12.85: erst die Kandidaten sammeln, dann je Kandidat die aktuelle Stelle suchen. Vorher lief die Schleife über Stellen
    -- von hinten nach vorn; wurde eine Annahme nach vorn geholt, rückten die übrigen um eins nach hinten und die nächste Stelle
    -- war ein anderer Schritt – eine Annahme wurde übersprungen (ROUTE-Q O5: "Vereitelung der Kolkaraggression", "Arnak").
    local cands = {}
    for i = #steps, base + 2, -1 do
        local t = steps[i]
        if t.t == "ACCEPT" and not t.explicit and t.inst == inst and t.n then cands[#cands + 1] = t end
    end
    for _, t in ipairs(cands) do
        local i
        for k = base + 2, #steps do if steps[k] == t then i = k break end end
        if i then
            table.remove(steps, i)
            local pos = P.InsertOnWay(steps, t, base, inst, n, w, P.ONWAY_DETOUR, true)
            if not pos or pos > i then
                if pos then table.remove(steps, pos) end
                table.insert(steps, i, t)
            elseif pos < i then
                cnt = cnt + 1
            end
        end
    end
    for _, t in ipairs(tasks or {}) do
        if t.t == "ACCEPT" and not have[t.key] and not t.pathBlocked and t.inst == inst and t.n
           and LP.Geo:Dist(n, w, t.n, t.w) <= P.ONWAY_RANGE then
            if P.InsertOnWay(steps, t, base, inst, n, w, P.ONWAY_DETOUR, true) then
                have[t.key] = true
                cnt = cnt + 1
            end
        end
    end
    return cnt
end

-- 3.12.8: Vorrang-Ziel (Assistent: Trainer, Beruf, Haendler ...) an den Anfang, aber nie vor abgabebereite
-- Quests in der Naehe (die stehen nach NearTurninsFirst vorn)
function P.InsertPriority(steps, prio)
    local pos = 1
    -- 3.12.70 NAV-T1: ein Ziel, das der Spieler selbst gewählt hat (/lp navi, /lp weg, /lp suche, Kartenmarkierung, Schnittstelle),
    -- steht immer oben (Pfeil dorthin); Vorschläge des Assistenten kommen weiter nach nahen Abgaben
    if not prio.explicit then
        while steps[pos] and steps[pos].t == "TURNIN" and steps[pos].nearTurnin do pos = pos + 1 end
    end
    table.insert(steps, pos, prio)
    return steps
end

function P:DoReplan(verbose)
    local level = LP:PlayerLevel() or 1
    if level ~= candLevel then self:BuildCandidates() end
    ScanLog()
    self.diag.candidates = #candidates
    self.diag.level = level

    if LP.Engine and LP.Engine:InDungeon() then
        self:PlanInstance(level)
        return
    end

    local inst, n, w, curZone = LP.Geo:Player()
    self.diag.map = C_Map.GetBestMapForUnit("player")
    if not inst then
        self.state = "noposition"
        self.status = L["Position unbekannt"]
        self.diag.tasks = 0
        if #self.steps == 0 or self.steps[1].key == "NOPOS" then
            self.steps = { { t = "NOTE", key = "NOPOS",
                text = L["Deine Position ist gerade nicht bestimmbar (z. B. in einer Instanz oder beim Laden). Kurz bewegen – die Route wird dann automatisch geplant."] } }
        end
        LP:Fire("PLAN_CHANGED")
        return
    end

    local tasks = self:CollectTasks(inst, n, w, level)
    self.diag.tasks = #tasks
    self.lastTasks = tasks
    local _, race = UnitRace("player")
    local startRule
    tasks, startRule = self:StartFilter(tasks, level, inst, n, w, race)
    -- Fokus waehlen; bleibt nach der Wegpruefung in der Fokus-Zone nichts uebrig, die naechste Zone versuchen
    local excluded = {}
    local focus, ordered, selected
    for _ = 1, 3 do
        focus = self:ChooseFocus(tasks, inst, n, w, curZone, excluded)

        -- Aufgaben der Fokus-Zone + alles in der Naehe (300 Yards, Questannahmen 400) + fertige Quests ueberall
        -- + Dungeon-Quests, die fuer einen anstehenden Lauf eingesammelt werden
        selected = {}
        for _, t in ipairs(tasks) do
            local near = t.inst == inst and t.n and LP.Geo:Dist(n, w, t.n, t.w) < (t.t == "ACCEPT" and GATHER or 300)
            local tz = P.ZoneOf(t.map)
            if not t.pathBlocked and (tz == focus or near or t.prep or (t.t == "TURNIN" and tz == P.ZoneOf(curZone)) or not t.map) then
                selected[#selected + 1] = t
            end
        end

        -- Abgaben sammeln: eine einzelne Abgabe weit weg (kein Questgeber, keine weitere Abgabe dort, keine
        -- Folgequest) wartet, bis man ohnehin vorbeikommt oder das Questlog voll wird
        local logFull = self:LogCount() >= LP.API.MaxQuests() - 3
        for _, t in ipairs(selected) do
            if P.OPT.collect and t.t == "TURNIN" and t.n and t.inst == inst and not logFull and not t.collectChecked then
                t.collectChecked = true
                local q = LP.QuestDB:Get(t.id)
                local chain = q and q.nextInChain and q.nextInChain ~= 0
                if not chain and LP.Geo:Dist(n, w, t.n, t.w) > TURNIN_FAR then
                    local others = 0
                    for _, u in ipairs(selected) do
                        if u ~= t and u.inst == t.inst and u.n and LP.Geo:Dist(t.n, t.w, u.n, u.w) <= HUB then others = others + 1 end
                    end
                    if others == 0 then t.value = t.value * TURNIN_ALONE t.collected = true end
                end
            end
        end
        ordered = self:Order(selected, inst, n, w)
        -- Pflichtregel fuer den Weg: den echten Weg zum ersten Ziel pruefen (Wegenetz, Zonenuebergaenge);
        -- fuehrt er durch ein Gebiet mit zu starken Mobs, wird das Ziel zurueckgestellt
        self:CheckFirstPath(ordered, inst, n, w, curZone, level)
        if #ordered > 0 or not focus then break end
        excluded[focus] = true
    end
    if startRule then self.diag.acceptsFirst = P.AcceptsFirst(ordered, startRule) end
    -- Kontinent der Fokus-Zone merken (Kontinentwechsel nur alle paar Level)
    local fi = focus and LP.Geo:ToWorld(focus, 50, 50)
    if fi and fi ~= self.contInst then
        if self.contInst then self.contLevel = level end
        self.contInst = fi
    end
    if focus ~= self.focus then
        if self.focus then self.leftZones[self.focus] = level end
        if focus then
            self.focusChanges = self.focusChanges + 1
            if self.focusLog then self.focusLog[#self.focusLog + 1] = { focus, level, self.focusWhy } end
            if self.leftZones[focus] then self.focusReturns = self.focusReturns + 1 end
        end
    end
    self.focus = focus
    -- Dungeon-Quests in der Naehe zuerst einsammeln, dann in den Dungeon
    for i = #ordered, 1, -1 do
        local dg = ordered[i]
        if dg.t == "DUNGEON" then
            local lastAccept
            for j = i + 1, #ordered do
                if ordered[j].t == "ACCEPT" and ordered[j].dungeon == dg.area then lastAccept = j end
            end
            if lastAccept then
                table.remove(ordered, i)
                table.insert(ordered, lastAccept, dg)
            end
        end
    end
    local steps = {}
    local fp = not startRule and self:FlightPointTask(inst, n, w, curZone) or nil
    local bind = not startRule and self:BindStep(selected, inst, n, w, focus) or nil
    local hearth = ordered[1] and self:HearthStep(ordered[1], inst, n, w)
    if hearth then
        steps[#steps + 1] = hearth
    elseif ordered[1] and ordered[1].inst then
        for _, s in ipairs(self:TravelSteps(ordered[1], inst, n, w)) do steps[#steps + 1] = s end
    end
    local base = #steps
    for _, t in ipairs(ordered) do steps[#steps + 1] = t end
    -- 3.12.71 ERA-1: Flugpunkt holen und Binden nicht mehr vor ALLES (vorher: neuer Charakter in Nordhain -> "Binden" im
    -- Gasthaus Goldhain 600 yd zuerst, nahe Questgeber danach). Flugpunkt vor den ersten weiter entfernten Routenschritt,
    -- Binden nur auf dem Weg (InsertOnWay); im Startgebiet unter Stufe 6 beides nicht (StartFilter).
    if bind then P.InsertOnWay(steps, bind, base, inst, n, w) end
    if fp then P.InsertByDistance(steps, fp, base, inst, n, w) end
    -- 3.12.7: abgabebereite Quests in der Naehe immer zuerst (vor Flugmeister, Binden, Ruhestein und weiten Zielen)
    self:NearTurninsFirst(steps, inst, n, w)
    -- 3.12.73 ORT-1/ROUTE-Q R1+R4: annehmbare Questgeber in der Nähe (P.NEAR_ACCEPT) vor jedes weitere Ziel und vor Sonder-Schritte
    local nearN, nearEnd = P.NearAcceptsFirst(steps, tasks, inst, n, w, nil, curZone)
    self.diag.nearAccepts = nearN
    -- 3.12.78 ORT-1 O5: Questgeber am Weg (auch in der Wildnis) mitnehmen, wenn der Umweg <= P.ONWAY_DETOUR ist
    self.diag.onWayAccepts = P.OnWayAccepts(steps, tasks, inst, n, w)

    self.state = "ok"
    if #steps == 0 then
        if LP.QuestDB:Counts().total == 0 then
            self.state = "nodata"
            steps[1] = { t = "NOTE", key = "NODATA",
                text = L["Noch keine Questdaten vorhanden.\nInstalliere das Datenpaket \"LevelPilot Data\" (Ordner LevelPilot_Data in Interface\\AddOns) für alle Classic-Quests – oder nimm Quests an: LevelPilot lernt jede Quest."] }
        else
            self.state = "noquests"
            steps[1] = { t = "LEVEL", lvl = level + 1, key = "GRIND:" .. level,
                text = L["Keine passende Quest in der Nähe bekannt – Monster in deinem Level besiegen oder eine andere Zone wählen (Zentrale » Route)"] }
        end
    end

    -- Vorrang-Ziel des Assistenten (z.B. "Reparieren") an den Anfang
    if self.priority then
        if LP.char.doneKeys[self.priority.key] then
            LP.char.doneKeys[self.priority.key] = nil
            self.priority = nil
        else
            P.InsertPriority(steps, self.priority)
        end
    end

    -- manuell erledigte Reise-/Hinweisschritte ausblenden
    local final = {}
    for _, s in ipairs(steps) do
        if not LP.char.doneKeys[s.key] and not (LP.Engine and LP.Engine.IsLater and LP.Engine:IsLater(s.key)) then final[#final + 1] = s end
    end
    -- nie ohne Schritt dastehen
    if #final == 0 then
        self.state = "noquests"
        final[1] = { t = "LEVEL", lvl = level + 1, key = "GRIND:" .. level,
            text = L["Keine passende Quest in der Nähe bekannt – Monster in deinem Level besiegen oder eine andere Zone wählen (Zentrale » Route)"] }
    end
    if final[1].t == "LEVEL" and self:IsSpeed() and next(self.speedSkip) then
        final[1].text = L["Speedrun: Monster in deinem Level besiegen ist gerade schneller als die übrigen Quests hier. Ab dem nächsten Level geht es mit Quests weiter."]
    end
    -- Grinden: kurz und an einer passenden Stelle (Monster im eigenen Level, machbar, nicht grau)
    if final[1].t == "LEVEL" and LP.Danger and not final[1].map then
        local gi, gn, gw, glv = LP.Danger:GrindSpot(inst, n, w, level, GRIND_RADIUS)
        local gx, gy
        if gi then gx, gy = LP.Geo:ToMap(curZone, gi, gn, gw) end
        if gx and gx >= 0 and gx <= 100 and gy >= 0 and gy <= 100 then
            local st = final[1]
            st.map, st.x, st.y, st.inst, st.n, st.w = curZone, gx, gy, gi, gn, gw
            st.grindLevel = glv
            st.text = st.text .. "\n" .. L("Gute Stelle: Monster Stufe %d bei %.0f, %.0f – etwa 20 Minuten, dann neu planen.", glv, gx, gy)
        end
    end
    -- Buendeln: bei einem Questziel anzeigen, welche anderen Ziele im Log gleich dort liegen
    local bidx
    for si, st in ipairs(final) do
        if si > 12 then break end
        if st.t == "COMPLETE" and st.inst and st.n then
            bidx = bidx or self:LogBundleIndex(level)
            local set = self:BundleNear(bidx, st.inst, st.n, st.w, st.id)
            local also = {}
            for id in pairs(set) do
                local e = self.inLog[id]
                if e and #also < 3 then also[#also + 1] = e.title or ("#" .. id) end
            end
            table.sort(also)
            st.also = #also > 0 and also or nil
        end
    end
    -- 3.12.30 GR1: fertige Quests mit ferner Abgabe bleiben sichtbar ("Später abgeben")
    self:LaterTurnins(final, tasks)
    self.steps = final
    self.status = focus and LP.Geo:MapName(focus) or ""
    if verbose then
        LP:Reply(L["Route neu geplant: "] .. #final .. L[" Schritte"] .. (focus and (" in " .. LP.Geo:MapName(focus)) or ""))
    end
    LP:Fire("PLAN_CHANGED")
end

-- 3.12.30 GR1: Jede fertige Quest im Questlog (mit bekannter Abgabe, nicht ignoriert) bleibt sichtbar. Hat sie keinen
-- Abgabe-Schritt (Abgabe weit weg, ausserhalb der Fokus-Zone, oder der Weg dorthin ist gerade zu gefaehrlich), kommt
-- ein Hinweis "Spaeter abgeben: Quest (Zone)" in die letzte angezeigte Zeile. Die Grundregel (Protocol CheckRules)
-- zaehlt diesen Hinweis als Abgabe-Schritt (laterIds). Gibt den Hinweis zurueck (oder nil).
P.LATER_MAX = 4               -- so viele Quests stehen im Hinweis mit Namen, der Rest als "+n weitere"
function P:LaterTurnins(steps, tasks)
    local have = {}
    for _, s in ipairs(steps) do
        if s.t == "TURNIN" and s.id then have[s.id] = true end
    end
    local byId = {}
    for _, t in ipairs(tasks or {}) do if t.t == "TURNIN" and t.id then byId[t.id] = t end end
    local ids = {}
    for id, st in pairs(inLog) do
        if st.complete and not LP.char.ignored[id] and not have[id] then
            local q = LP.QuestDB:Get(id)
            if q and q.ends and #q.ends > 0 then ids[#ids + 1] = id end
        end
    end
    if #ids == 0 then return nil end
    table.sort(ids)
    local parts = {}
    for i, id in ipairs(ids) do
        if i > P.LATER_MAX then parts[#parts + 1] = L("+%d weitere", #ids - P.LATER_MAX) break end
        local t, q, st = byId[id], LP.QuestDB:Get(id), inLog[id]
        local e1 = q.ends[1]
        local map = (t and t.map) or (type(e1) == "table" and e1[1]) or nil
        local name = (t and t.q) or st.title or q.name or ("#" .. id)
        parts[#parts + 1] = map and (name .. " (" .. LP.Geo:MapName(map) .. ")") or name
    end
    local s = { t = "NOTE", key = "LATER:" .. table.concat(ids, ","), laterIds = ids,
                text = L["|cff3dd694Später abgeben|r: "] .. table.concat(parts, ", ") }
    local shown = math.max(2, tonumber(LP.db.stepsShown) or 5)
    table.insert(steps, math.min(#steps + 1, shown), s)
    return s
end

-- Uebersicht fuer die Zentrale: je Dungeon Zugang, Stufen, Quests (offen / im Log / erledigt), Rechnung
function P:DungeonOverview()
    local level = LP:PlayerLevel() or 1
    ScanLog()
    local byArea = {}
    for _, id in ipairs(LP.QuestDB:AllIds()) do
        local info = LP.QuestDB:QuickInfo(id)
        local area = info and info.dungeon
        if area then
            local q = LP.QuestDB:Get(id)
            if q and LP.QuestDB:FitsPlayer(q) and not q.repeatable then
                local e = byArea[area] or { open = 0, log = 0, done = 0 }
                byArea[area] = e
                if Done(id) then e.done = e.done + 1
                elseif inLog[id] then e.log = e.log + 1
                else e.open = e.open + 1 end
            end
        end
    end
    local out = {}
    for area, d in pairs(LP.Dungeons) do
        local info = LP.QuestDB:Dungeon(area)
        local allowed, why = LP.QuestDB:DungeonAllowed(area)
        local e = byArea[area] or { open = 0, log = 0, done = 0 }
        out[#out + 1] = { area = area, name = info and info.name or d.name, min = d.min, max = d.max, allowed = allowed, why = why,
                          hostile = LP.QuestDB:DungeonHostile(area), open = e.open, log = e.log, done = e.done,
                          worth = self.dungeonWorth[area], entrance = info and info.e and info.e[1],
                          now = level >= d.min - 2 and level <= d.max, last = LP.char.dungeonRun[area] }
    end
    table.sort(out, function(a, b) if a.min ~= b.min then return a.min < b.min end return a.name < b.name end)
    return out
end

-- Im Dungeon: die Ziele der Quests dieser Instanz
function P:PlanInstance(level)
    local area = LP.Engine:InDungeon()
    local d = LP.QuestDB:Dungeon(area)
    local steps = {}
    local name = d and d.name or (GetInstanceInfo and GetInstanceInfo()) or L["Dungeon"]
    for id, st in pairs(inLog) do
        if not st.complete and not st.failed then
            local q = LP.QuestDB:Get(id)
            local mine = q and q.dungeon == area
            if not mine and (not q or not q.dungeon) then
                -- unbekannte Zuordnung: Quests ohne Ziel in der Welt gehoeren wahrscheinlich hierher
                local world = false
                for _, o in ipairs(q and q.objectives or {}) do
                    local list = area and area ~= 0 and OutsideSpots(area, o.spots or {}) or (o.spots or {})
                    for _, sp in ipairs(list) do if WorldOf(sp) then world = true break end end
                end
                mine = not world
            end
            if mine then
                steps[#steps + 1] = { t = "COMPLETE", id = id, q = st.title or (q and q.name), level = q and q.level,
                                      key = "COMPLETE:" .. id, value = 1 }
            end
        end
    end
    table.sort(steps, function(a, b) return (a.level or 0) < (b.level or 0) end)
    if #steps == 0 then
        steps[1] = { t = "NOTE", key = "DGDONE",
            text = L["Alle Quests für diesen Dungeon erledigt.\nNach dem Verlassen der Instanz geht es mit den Abgaben weiter."] }
    end
    table.insert(steps, 1, { t = "DUNGEON", inside = true, area = area, q = name, key = "DGIN",
                             min = d and d.min, max = d and d.max })
    self:LaterTurnins(steps, self.lastTasks)    -- 3.12.30 GR1: auch im Dungeon keine fertige Quest aus den Augen verlieren
    self.state = "instance"
    self.focus = nil
    self.status = name
    self.diag.tasks = #steps - 1
    self.steps = steps
    LP:Fire("PLAN_CHANGED")
end

-- Diagnose im Chat
function P:DiagLines()
    local c = LP.QuestDB:Counts()
    local inst, n, w, map, x, y = LP.Geo:Player()
    local d = self.diag
    local lines = {
        L["Version "] .. LP.version .. L[" · Client: "] .. (LP.API.modern and L["modern"] or L["Classic"]) .. L[" · Server: "] .. (LP.API.Forever() and L["WoW Forever"] or L["Classic"]),
        LP.Game and LP.Game.Status() or L["GoldSentinelGame.lua fehlt"],
        L["Zustand: "] .. tostring(self.state) .. L[" · Fokus: "] .. (self.focus and LP.Geo:MapName(self.focus) or "–"),
        L["Position: "] .. (map and string.format("%s (%d) %.1f, %.1f", LP.Geo:MapName(map), map, x, y) or (L["unbekannt, Karte "] .. tostring(C_Map.GetBestMapForUnit("player")))),
        L["Datenpaket: "] .. (LP.QuestDB.pack and "|cff4ddb80" or "|cffff8c33") .. LP.QuestDB.packInfo .. "|r",
        L["QuestieDB: "] .. LP.QuestDB.questieInfo,
        string.format(L["Quests: Paket %d, Questie %d, Startdatenbank %d, eigene %d, andere %d"], c.pack, c.questie, c.seed, c.own, c.net),
        string.format(L["Level %s · passende Quests %s · Aufgaben %s · Schritte %d"], tostring(d.level), tostring(d.candidates), tostring(d.tasks), #self.steps),
        L["Questlog: "] .. LP.API.QuestCount() .. "/" .. LP.API.MaxQuests() .. ((tonumber(LP.db.questLogMax) or 0) > 0 and L[" (fest eingestellt)"] or L[" (automatisch)"]),
        L["Modus: "] .. (self:IsSpeed() and (L["Speedrun "] .. (SPEED_NAMES[LP.db.speedLevel or 3] or "") .. " (" .. (function() local c = 0 for _ in pairs(self.speedSkip) do c = c + 1 end return c end)() .. L[" Quests ausgelassen)"]) or L["Normal"]),
        L["Dungeons: "] .. (LP.db.dungeons == false and "aus" or (L["an, Lauf ab "] .. (LP.db.dungeonMin or 2) .. L[" Quests, Monster-EP "]
            .. math.floor(self:DungeonXPFactor() * 100 + 0.5) .. L[" %, Quest-EP "] .. math.floor(self:DungeonQuestFactor() * 100 + 0.5) .. " %"))
            .. (LP.char.inDungeon and (L[" · im Dungeon "] .. tostring(LP.char.inDungeon)) or ""),
        L("Höhlen und Tunnel bekannt: %d (selbst gelernt %d, von anderen %d)", LP.Caves:Count()),
        L["Geländeführung: "] .. (not LP.db.terrainPath and L["aus"] or (LP.Terrain:Available(map) and L["an (Geländekarte dieser Zone vorhanden)"] or L["keine Geländekarte für diese Zone"])),
        L["Sprachpakete: "] .. (LP.Names and LP.Names:StatusText() or "–"),
        LP.Calib and LP.Calib:StatusText() or "",
        L["Letzter Fehler: "] .. (LP.lastError or L["keiner"]),
    }
    -- Module, die beim Start einen Fehler hatten (3.12.6)
    for name, err in pairs(LP.initErrors or {}) do
        lines[#lines + 1] = L("Modul-Startfehler: %s – %s", tostring(name), tostring(err):sub(1, 120))
    end
    for _, txt in pairs(self.dungeonWorth) do table.insert(lines, #lines, "   " .. txt) end
    return lines
end

function P:Diagnose()
    local lines = self:DiagLines()
    LP:Reply(L["|cffffb238Diagnose|r"])
    for _, l in ipairs(lines) do LP:ReplyRaw("   " .. l) end
end

-- Zonen mit Aufgaben (fuer die Zentrale)
function P:ZoneSummary()
    -- Aufgaben der letzten Planung (neu rechnen nur, wenn es noch keine gibt: das ist so teuer wie eine Planung)
    local tasks = self.lastTasks
    if not tasks then
        local inst, n, w = LP.Geo:Player()
        if not inst then return {} end
        ScanLog()
        local level = LP:PlayerLevel() or 1
        if level ~= candLevel then self:BuildCandidates() end
        tasks = self:CollectTasks(inst, n, w, level)
    end
    local zones = {}
    for _, t in ipairs(tasks) do
        if t.map then
            local z = zones[t.map] or { map = t.map, accept = 0, active = 0 }
            zones[t.map] = z
            if t.t == "ACCEPT" then z.accept = z.accept + 1 else z.active = z.active + 1 end
        end
    end
    local list = {}
    for _, z in pairs(zones) do list[#list + 1] = z end
    table.sort(list, function(a, b) return (a.accept + a.active) > (b.accept + b.active) end)
    return list
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
function P:Init()
    local function soon() LP:Throttle("replan", 1.5, function() P:Replan() end) end
    LP:On("QUEST_LOG_UPDATE", soon)
    LP:On("QUEST_TURNED_IN", function(_, id)
        if id then LP.char.turnedIn[id] = true end
        soon()
    end)
    -- 3.12.33 LP-D1: Questauswertung beim Stufenaufstieg in der Neuplanung (Portionen) statt am Stück
    LP:On("PLAYER_LEVEL_UP", function() C_Timer.After(0.5, function() P:InvalidateCandidates() P:Replan() end) end)
    LP:On("ZONE_CHANGED_NEW_AREA", soon)
    LP:Listen("QDB_CHANGED", function() candLevel = -1 soon() end)
    LP:Listen("QUEST_RECORDED", function(_, isNew) if isNew then candLevel = -1 end soon() end)
    LP:On("PLAYER_ENTERING_WORLD", function() C_Timer.After(2, function() P:Replan() end) end)
    C_Timer.After(1, function() P:Replan() end)
    LP:Ticker("replan", 15, function() P:Replan() end)
    if LP.Advisor and LP.Advisor.AddProvider then LP.Advisor:AddProvider(function(add) P:CheckStuck(add) end) end
end

-- 3.12.41 LP-N1 3: am Ziel ohne Fortschritt? (laeuft mit dem Assistenten, alle 30 s und bei Ereignissen)
local function ProgressSig(id)
    local st = inLog[id]
    if not (st and st.index) then return nil end
    local parts = {}
    for _, o in ipairs(LP.API.Objectives(st.index) or {}) do parts[#parts + 1] = tostring(o.have) .. "/" .. tostring(o.text) end
    return table.concat(parts, "|")
end
P.ProgressSig = ProgressSig
function P:CheckStuck(add)
    if not LP.db.advGrind then self.stuck = nil return end
    local s = self.steps and self.steps[1]
    local S = LP.SafeValue
    if not (s and s.t == "COMPLETE" and s.id and s.inst) or (UnitIsAFK and S(UnitIsAFK("player"))) then self.stuck = nil return end
    local pi, pn, pw = LP.Geo:Player()
    if not pi or pi ~= s.inst or LP.Geo:Dist(pn, pw, s.n, s.w) > P.STUCK_NEAR then self.stuck = nil return end
    local sig = ProgressSig(s.id)
    local k = self.stuck
    if not k or k.id ~= s.id or k.sig ~= sig or k.n ~= s.n or k.w ~= s.w then
        self.stuck = { id = s.id, sig = sig, since = Now(), n = s.n, w = s.w }
        return
    end
    local secs = Now() - k.since
    if secs < P.STUCK_SECS then return end
    -- naechste andere Stelle (ohne die jetzige) – gibt es keine, kein Hinweis
    local q = LP.QuestDB:Get(s.id)
    local st = inLog[s.id]
    if not q then return end
    local spots = {}
    for oi, o in ipairs(q.objectives or {}) do
        if not (st and st.objDone[o.idx or oi]) then for _, sp in ipairs(o.spots or {}) do spots[#spots + 1] = sp end end
    end
    local saved = self.exhausted[s.id]
    self.exhausted[s.id] = { { s.inst, s.n, s.w, Now() + 1 } }
    for _, e in ipairs(saved or {}) do table.insert(self.exhausted[s.id], e) end
    local rest = self:WithoutExhausted(s.id, SafePoints(spots, LP:PlayerLevel() or 1))
    self.exhausted[s.id] = saved
    local pt, d = NearestPoint(rest, pi, pn, pw)
    if not pt or not d or d <= P.EXHAUST_R then return end
    local id, inst, n, w = s.id, s.inst, s.n, s.w
    add("grind", LP.Advisor.SEV_INFO,
        L("Seit %d Min. kein Fortschritt bei „%s“ – Stelle abgegrast? Nächste Stelle %s entfernt.", math.floor(secs / 60), s.q or "?", LP:FormatDist(d)),
        function() P:MarkExhausted(id, inst, n, w) end, L["Andere Stelle"])
    if LP.Pruefliste then LP.Pruefliste:Hit("T303", ("nach %d Min., nächste Stelle %d Yards"):format(math.floor(secs / 60), math.floor(d))) end   -- Prüfliste
end
