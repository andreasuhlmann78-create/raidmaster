# ProfessionSentinel – Änderungen

## 0.8.1
- Retail: Fehler „Attempt to register unknown event TRADE_SKILL_UPDATE“ beim Laden behoben – Berufs-Ereignisse werden nur noch angemeldet, wenn das Spiel sie kennt

## 0.8.0
- **Retail** (12.1.5 Midnight, Interface 120105): ProfessionSentinel läuft jetzt auch im normalen WoW – mit rund **10 170 Rezepten aller Erweiterungen** direkt aus dem Retail-Client
- In Retail ist **jede Erweiterung ein eigener Beruf mit eigener Stufe** wie im Berufsfenster (z. B. „Lederverarbeitung von Midnight“, „Klassische Lederverarbeitung“) – Rezepte, Lebenslinie, Rangliste, Levelplan bis zur Höchststufe der Erweiterung, Ruf, Rezept-Alarm und Material-Tooltip funktionieren dort
- Retail hat keine QuestieDB: keine Händler-, Drop- und Lehrer-Koordinaten (der Reiter „Lehrer“ ist dort ausgeblendet); Händlerware wie Fäden und Farbstoffe wird aus Classic übernommen, neue Händlerpreise liest AHSentinel beim Händlerbesuch
- Verzauberkunst in Retail: nur „VZ verkaufen“ – die Entzauberungstabellen gelten dort nicht
- Händlerpreise: wo die Daten keinen kennen, nimmt ProfessionSentinel den Preis, den AHSentinel beim Händler abgelesen hat (alle Spielversionen)

## 0.7.1
- Intern: automatischer Test im Spiel für den Entwickler (öffnet für jeden Beruf alle Reiter und Knöpfe, fängt Lua-Fehler ab und schreibt einen Bericht). Für Spieler ändert sich nichts

## 0.7.0
- **Levelplan** (neuer Reiter „Plan“): von deiner Fertigkeit bis 75/150/225/300 – welches Rezept wie oft, mit Einkaufsliste (fehlt nach Taschen und Bank). Ein Klick kauft beim offenen Händler genau das Fehlende, ein zweiter legt die AH-Zutaten in den Sniper von AHSentinel (Marktwert + 10 %)
- **Ruf-Rezepte:** im Tooltip steht, welcher Ruf auf welcher Stufe nötig ist – grün, wenn du ihn schon hast (auch neue Forever-Fraktionen wie Kirin Tor)
- **Rezept-Alarm:** liegt ein Rezept, das dir oder einem Twink fehlt, im AH (Scan mit AHSentinel), kommt eine Meldung mit Ton; im Reiter „Rezepte“ stehen sie oben, Klick = Sniper. Aus/an: `/ps alarm`
- **Gilde** (Daten aus GuildSentinel / RaidMaster): wer kann das Rezept herstellen (online zuerst), Gruppe „Kennt niemand in der Gilde“ und die **Abklingzeiten** (Transmutation, Mondstoff, Salzstreuer)
- **Rezepte in deinen Taschen:** wer sie noch braucht – oder keiner (dann verkaufen); **Material-Tooltip:** in wie vielen Rezepten ein Material gebraucht wird und welche davon du kennst (auch Raid-Material wie Lavakern)
- **VZ verkaufen:** Rechtsklick flüstert dem Kunden Material und Preis (auch mit seinem Material)
- Leveln: profitable Rezepte mit kleiner Chance gewinnen nicht mehr nur, weil viele Herstellungen viel Gewinn ergeben – Gewinn zählt pro Herstellung × Chance

## 0.6.5
- Verzauberkunst: Beim **ersten Einloggen** fragt ein Fenster nach deinem Ziel – **Gold machen** (Standard, vorgemerkt), **VZ verkaufen** oder **beides**. Das Fenster bleibt offen, bis du eins gewählt hast, und du schließt es selbst mit „Fertig“. Bis dahin gilt Gold machen. Später ändern: `/ps ziel` oder oben im Reiter „Verzauberer“

## 0.6.4
- Verzauberkunst: keine Frage mehr beim Einloggen – Standard ist **Gold machen**. Umstellen auf VZ verkaufen oder beides optional mit `/ps ziel` oder oben im Reiter „Verzauberer“; einmal pro Charakter kommt ein kurzer Hinweis im Chat

## 0.6.3
- Testmodus und Selbsttest (`/ps test`, `/ps selftest`) gibt es nur noch für den Entwickler – wie bei AHSentinel. Für alle anderen funktioniert das Addon genau gleich, nur ohne diese Werkzeuge

## 0.6.2
- Verzauberer: „Schnäppchen im AH“ zeigt nur noch Gegenstände, die deine **Mindestmarge beim Entzaubern** einhalten – genau die, die auch der Sniper kauft

## 0.6.1
- Nur für Verzauberer mit dem Ziel „Gold machen“ oder „beides“: **Mit dem Sniper kaufen** – ein Klick legt die Schnäppchen (Gegenstände billiger als entzaubert) oder die AH-Zutaten deiner besten Rezepte aus „Herstellen & Entzaubern“ als Ziele in den Sniper von AHSentinel. Max-Preis und Menge sind schon eingestellt, du stellst nur noch das Budget ein
- **Mindestmarge beim Entzaubern** (Standard 20 %) einstellbar: du zahlst höchstens 80 % dessen, was das Material nach AH-Kommission bringt
- Entzaubern gibt es nur noch im Reiter „Verzauberer“: „Gold verdienen“ in der Rangliste der anderen Berufe rechnet wieder nur mit dem Verkauf
- „Herstellen & Entzaubern“ umfasst jetzt die Rezepte **aller deiner Berufe**

## 0.6.0
- Verzauberkunst: Wer Verzauberkunst hat, wird einmal gefragt, wofür – **Gold machen**, **VZ verkaufen** oder **beides**. Das Addon richtet den Verzauberungsteil danach aus, alles andere bleibt gleich. Ändern jederzeit mit `/ps ziel` oder im neuen Reiter „Verzauberer“
- **Gold machen:** Entzauberungswert jedes herstellbaren Gegenstands (Material abzüglich 5 % AH-Kommission). „Gold verdienen“ nimmt Entzaubern, wenn es mehr bringt (DE); neue Gruppe **„Herstellen & Entzaubern“** – Material kaufen, herstellen, entzaubern, nach Gewinn sortiert
- Reiter „Verzauberer“: **Schnäppchen im AH**, die weniger kosten, als sie entzaubert bringen, und die **gelernten Dropchancen** im Vergleich zu den Startwerten
- Dropchancen lernen aus jeder Entzauberung – deiner und der aller Spieler mit AHSentinel. Startwerte bei grünen Teilen: 75 % Staub, 20 % Essenz, 5 % Splitter (Waffen umgekehrt)
- **VZ verkaufen:** alle deine Verzauberungen mit Materialkosten (AH- bzw. Händlerpreise) und deinem **Verkaufspreis** – Aufschlag in % und Mindestgewinn stellst du selbst ein
- Leveln rechnet weiter nur mit dem Verkauf
- Testmodus: Verzauberer simulieren und die drei Ziele durchschalten

## 0.5.1
- Gewinnrechnung zieht die 5 % AH-Kommission vom Verkaufspreis ab – Rangliste, Gold verdienen und Netto pro Punkt rechnen mit dem echten Erlös
- Lohnt sich der Händler nach Abzug der Kommission mehr, zählt der Händlerpreis
- Tooltip zeigt Verkauf im AH, AH-Kommission (5 %) und Erlös aus dem AH

## 0.5.0
- Gold in der Rangliste: „Leveln“ nach Gold pro Skillpunkt, neue Gruppe „Gold verdienen“ nach Netto-Gewinn pro Herstellung – auch graue Rezepte
- Materialkosten: Händlerware zum Händlerpreis, alles andere zum AH-Wert (auch selbst Gefarmtes); Produkt zum höheren Wert aus AH und Händler
- AH-Werte aus AHSentinel (sonst TSM oder Auctionator); ohne AH-Addon bleibt die Rangliste bei Material pro Skillpunkt
- Zeilen zeigen die Herkunft der Zutaten (AH / Händler / Farm) und „+10s 80c/Pkt“; der Tooltip schlüsselt jede Zutat mit Preis, Kosten, Verkaufswert und Netto auf
- Testmodus: „Testpreise“, um die Gold-Rangliste ohne AH-Scan auszuprobieren

## 0.4.0
- Rangliste zum Leveln: alle Rezepte, die bei deiner Fertigkeit Punkte bringen – gelernte und nicht gelernte – sortiert nach Material pro Skillpunkt (Material ÷ Chance auf einen Punkt)
- Neuer Reiter „Rangliste“ mit der ganzen Liste, Top 10 oben im Reiter „Rezepte“; noch nicht gelernte Rezepte mit [lernen] und Quelle
- Stern beim besten gelernten Rezept in Blizzards Rezeptliste, Hinweis mit Platz und Material pro Punkt am Berufsfenster (Klick wählt es aus)
- Rezepte weit über deiner Fertigkeit zählen nicht mehr als orange: fehlende Lernstufen werden geschätzt (WoW Forever über die Era-Stufe desselben Rezepts)
- Classic Era: Rezepte aus Season of Discovery entfernt (1267 echte Era-Rezepte)

## 0.3.0
- Neuer Reiter „Lehrer“: alle Lehrer des offenen Berufs nach Rang – Geselle (bis 150), Experte (bis 225), Fachmann (bis 300), Spezialisierungen – mit Zone, Koordinaten und Fraktion; dein nächster Rang ist markiert
- Händler und Drop-Gegner im Rezept-Tooltip jetzt mit Zone und Koordinaten
- Klick auf einen Lehrer setzt einen Wegpunkt, Rechtsklick auf ein Rezept einen Wegpunkt zum nächsten Händler (TomTom, sonst Kartenpin des Spiels)
- Zonennamen in der Sprache des Spiels; neue WoW-Forever-Gebiete (Insel Zephras, Flusslande) unterstützt
- Testmodus: Prüfungen für Lehrer und Wegpunkte, Knopf „Wegpunkt testen“

## 0.2.0
- Erkennt die Spielversion am Client und passt sich an: WoW Forever (eigene Rezepte und Fertigkeitsstufen – viele Rezepte werden früher grau) und Classic Era (klassisches Berufs- und Verzauberungsfenster)
- Lebenslinie: dünne Linie unter jedem Rezept (orange → gelb → grün → grau) mit Markierung deiner Fertigkeit und wie oft du bis zur nächsten Farbe herstellen musst – in Blizzards Rezeptliste und im Panel „Alle Rezepte“
- Tooltip zeigt Herstellungen bis Gelb, Grün und Grau
- Testmodus (/ps test): Diagnose, simulierte Fertigkeit, simuliert gelernt/nicht gelernt, Panel ohne Berufsfenster, Selbsttest (/ps selftest)
- /ps line schaltet die Lebenslinie an und aus
- Vertauschte Fertigkeitsstufen bei einzelnen Rezepten im Client korrigiert (z. B. Aufgeladene Schuppe von Onyxia)

## 0.1.0
- Erste Version für WoW Forever (Interface 16001)
- Knopf „Alle Rezepte“ im Berufsfenster, gegliedert wie die Kategorien im Spiel
- Gelernte Rezepte ausgegraut, fehlende in Seltenheitsfarbe
- Tooltips mit Fertigkeitsstufen, Reagenzien und Quelle (Lehrer, Händler, Drop, Quest)
- Tooltip bei Rezepten: gelernt oder nicht, auch für deine anderen Charaktere
- 2210 Rezepte, davon 934 neu in WoW Forever
