# GuildSentinel – Changelog

## 0.9.13
- **Language selectable for everyone**: Settings > General > "Language". On start GuildSentinel still uses the language of your game client; you can switch to German, English, French, Spanish (Spain/Mexico), Italian or Portuguese on any client (Russian, Korean and Chinese on a client in that language). GuildSentinel reloads after the change; "Same as the game client" goes back. Replaces the developer-only switch from 0.9.12.

## 0.9.12
- Developer only: under Settings > Test mode the language can be switched between German, English and the game client's language (for screenshots); GuildSentinel reloads after the change. Nothing changes for players – GuildSentinel always uses the language of the game client.

## 0.9.11
- **Bank character: stock to Discord** (optional, off by default): tick "Bank character (stock to Discord)" under Settings > General on your guild's bank character. Opening the bank, the mailbox or – where the game has one – the guild bank then reads bags, bank, mail attachments and guild bank tabs (read only, never in combat, in small steps). The RaidMaster uploader sends the stock with its next upload, and the RaidMaster bot shows it in #gildenbank and with /bank. Guilds without the RaidMaster bot notice nothing.
- **Alt notes with first and last names** (WoW Forever) on Korean and Chinese clients, where the name comes before the label ("Rokan Steinwacht의 부캐릭터"), are recognised again.
- **Changing the main** now removes the old alt label completely – with first and last name and in the client language ("Alt: First Last", "Reroll de …") – instead of leaving parts of it in the note.
- **Event sync**: one damaged entry no longer discards the other events of the same sync message.
- All game functions GuildSentinel needs are now chosen in one place (API.lua, modern API first, old one as fallback). Nothing changes for players.
- Developer test routine: real sends now count as an error in the report (T82), every action with consequences is checked to go through one place (T174), new cases for export, event announcements, first/last names and the bank character, and the cases that previously needed a replaced game function now run in the game too.

## 0.9.10
- **Alt notes in your client language**: notes that GuildSentinel writes itself ("Reroll de …", "… 的分身" and so on) are recognised again on French, Spanish, Italian, Portuguese, Korean and Chinese clients. Where the label would not fit into the short guild note (Russian), GuildSentinel writes the short form "Alt: Name".
- **AHSentinel** (formerly AH Analyzer Pro) is recognised under its new folder name (Addons page, market values).
- **Applicant whispers in combat** (WoW Forever): more than 30 whispers during one fight are now counted in the notice too instead of being dropped silently.
- More robust against damaged data: malformed event sync messages and broken event or thanks entries no longer cause errors.
- Test mode (developer only): no longer joins or leaves the server channel, sends nothing delayed after "Stop test mode" and leaves the real settings (last ad, free status, My week) untouched.
- New for the developer: `/gs testroutine` (button "Test everything" under Settings > Test mode) checks every feature and saves a report for the GoldSentinel review; the diagnosis shows the error counter. Nothing changes for players.

## 0.9.9
Fixes from the review:
- **Officer rights**: players who may only read officer notes no longer count as officers.
- **Applicant whispers in combat** (WoW Forever): if a message stays protected after combat, GuildSentinel reports once how many could not be read instead of losing them silently.
- **Player tooltip**: the combat lock applies to every modern client (WoW Forever, Retail).
- Absence and thanks messages from other players are only accepted when the sender matches exactly.

## 0.9.8
- Shared game-version detection (GoldSentinelGame.lua) updated to version 2: it also wins over early, withdrawn copies that other GoldSentinel addons briefly shipped, so loading several GoldSentinel addons together causes no errors. Nothing changes for players.

## 0.9.7
- Uses the shared game-version detection of all GoldSentinel addons (GoldSentinelGame.lua): Classic Era, WoW Forever and TBC are detected the same way everywhere, with the shared secret-value guard and first/last name comparison. `/gsgame` shows what was detected. Nothing changes for players.

## 0.9.5
- **WoW Forever hardening**: protection against secret values in combat (player tooltip, addon messages, cooldowns). Applicants who whisper during combat are added after combat instead of being lost.
- **First and last names** (WoW Forever): names are capitalised correctly, notes like "Alt of Rokan Steinwacht" are recognised, and a unique first name alone is enough for alts, thanks and mentors.
- Whispering a "First Last" name opens the whisper box for the full name.
- Modern APIs are used first (C_ChatInfo, C_GuildInfo, C_SpellBook), with the old ones as fallback.

## 0.9.4
- **Without a guild**: instead of empty pages the overview shows a hint – GuildSentinel is a guild tool, and members, events, board, polls, progress, professions, recruitment and the group finder appear once you are in a guild. My week, Addons and Settings stay available. Joining or leaving a guild takes effect right away.

## 0.9.3
- **Guild name**: the guild master can set a name for GuildSentinel under Leadership > Rank rights. It applies to everyone in the guild with the addon (ad, chronicle, rules, welcome guide, header). Empty = the name from the game. Only the guild master can change it.

## 0.9.2
- **Professions on WoW Forever**: GuildSentinel now also reads the new retail-style profession window. The game client decides the way: WoW Forever uses the new window, Classic Era and TBC the classic one as before. Linked professions, guild professions and NPC windows are not read.
- The "Open next profession" button opens the new window directly on WoW Forever if needed.

## 0.9.1
- Test mode is now developer-only: the Settings > Test mode tab and `/gs test` only appear for the developer account. Nothing else changes for players.

## 0.9.0
- **Who's free** (Group finder): one click flags you as free for dungeon, raid, quest group or PvP for 1, 2 or 4 hours. Everyone with GuildSentinel sees who is free, with level, item level and zone. Inside dungeons, raids and battlegrounds you automatically show as busy.
- After posting a group search, GuildSentinel tells you how many guild members are free for it right now.
- **Item level** with "I'll join": the searcher sees it in the replies and in chat.
- **Bulk actions** (Leadership, officers): remove inactive players by rule or promote several suggestions at once – always a checklist first, one step per click.
- **GRM import** (Leadership): alts, join dates and personal notes from Guild Roster Manager, with a preview.

## 0.8.3
- New **Support** button (PayPal link to copy) in the title bar and under Settings > General, also `/gs donate`. Opens only on click.

## 0.8.2
- Guild achievements: singular for the first weekly goal; names that are too long use a smaller font.
- Professions: old raw-material entries (e.g. Felweed as "Alchemy") are removed automatically.

## 0.8.1
- Settings > Features in three columns; probation advice follows the 40 % rule; overview counts departures like Leadership; My week markers and singulars; chronicle without duplicates; loot wishes preselect a dungeon; removing a question asks first; raw materials leave the watch list.

## 0.8.0
- All WoW client languages; Classic Era, WoW Forever and TBC Classic / Anniversary; Overview, Leadership, My week, loot wishes, questions, guild achievements, chronicle, weekly recap, welcome guide, features on/off.
