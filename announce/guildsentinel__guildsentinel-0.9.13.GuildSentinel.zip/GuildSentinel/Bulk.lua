-- GuildSentinel - Bulk.lua
-- Sammelaktionen für Offiziere und Import aus Guild Roster Manager (GRM).
--
-- Sammelaktionen: Inaktive nach einer Regel entfernen oder mehrere Beförderungs-Vorschläge auf einmal.
-- Immer zuerst eine Prüfliste: jeder Spieler ist einzeln an- oder abwählbar. Das Spiel lässt Entfernen und
-- Befördern nur auf einen Klick hin zu – darum führt jeder Klick auf "Nächster" genau einen Schritt aus.
--
-- GRM-Import: liest die gespeicherten Daten von Guild Roster Manager (das Addon muss dafür geladen sein):
-- Twinks (Alt-Gruppen mit Main), Beitrittsdaten und eigene GRM-Notizen. Vorher zeigt eine Vorschau,
-- was übernommen wird; vorhandene Angaben in GuildSentinel werden nicht überschrieben.

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local Bk = {}
ns.Bulk = Bk

Bk.DAYS = { 30, 60, 90, 180, 365 }

------------------------------------------------------------
-- Rechte
------------------------------------------------------------
function Bk:CanKick()
	if ns.Test and ns.Test:Active() then return true end
	if ns.API.CanGuildRemove then return ns.API.CanGuildRemove() and true or false end
	return ns.IsOfficer()
end

local function MyRankIndex()
	local me = ns.Roster.byName[ns.Me()]
	return me and me.ri or 0
end

------------------------------------------------------------
-- Prüflisten
------------------------------------------------------------
-- Inaktive: nicht online seit "days" (auch kein Twink), Rang unter meinem und mindestens "minRi"
-- (höhere Zahl = niedrigerer Rang), nicht abwesend gemeldet. keepMax: Höchststufe nie vorschlagen.
-- { { name, class, level, rank, ri, seen, days, main } }
function Bk:KickCandidates(days, minRi, keepMax)
	local out = {}
	local myRi = MyRankIndex()
	local now = ns.Now()
	for _, e in ipairs(ns.Roster:Inactive(days)) do
		if e.ri > myRi and e.ri >= (minRi or 0) and not (keepMax and e.level >= ns.Roster.MAX_LEVEL) and not ns.Same(e.name, ns.Me()) then
			out[#out + 1] = { name = e.name, class = e.class, level = e.level, rank = e.rank, ri = e.ri, seen = e.seen,
				days = math.floor((now - (e.seen or now)) / 86400), main = ns.Roster:MainOf(e.name) }
		end
	end
	table.sort(out, function(a, b) return (a.seen or 0) < (b.seen or 0) end)
	return out
end

-- Beförderungen: die Vorschläge nach den eigenen Regeln (Mitglieder > Befördern)
function Bk:PromoteCandidates()
	local out = {}
	for _, x in ipairs(ns.Promote:Candidates()) do
		out[#out + 1] = { name = x.name, class = x.class, level = x.level, rank = x.rank, to = x.to, days = x.days, active = x.active }
	end
	return out
end

------------------------------------------------------------
-- Ausführen: eine Warteschlange, ein Schritt pro Klick
------------------------------------------------------------
Bk.queue = nil   -- { mode = "kick"/"promote", names = { … }, done = 0, total }

function Bk:Start(mode, names)
	if #names == 0 then return false end
	if mode == "kick" and not self:CanKick() then ns:Print(L["Dein Rang darf niemanden aus der Gilde entfernen."]) return false end
	if mode == "promote" and not ns.CanPromote() then ns:Print(L["Dein Rang darf niemanden befördern."]) return false end
	local list = {}
	for _, n in ipairs(names) do list[#list + 1] = n end
	self.queue = { mode = mode, names = list, done = 0, total = #list }
	ns:Fire("GS_BULK")
	return true
end

function Bk:Next()
	local q = self.queue
	return q and q.names[1] or nil
end

function Bk:Remaining()
	return self.queue and #self.queue.names or 0
end

-- einen Schritt ausführen (muss aus einem Klick kommen)
function Bk:Step()
	local q = self.queue
	if not q or #q.names == 0 then return end
	local name = table.remove(q.names, 1)
	if q.mode == "kick" then
		local fn = GuildUninvite or (C_GuildInfo and C_GuildInfo.Uninvite)
		if fn and not ns.Blocked(L["Aus der Gilde entfernen"] .. ": " .. name) then ns.Act("GuildUninvite", fn, name) end
		if ns.Test and ns.Test:Active() then ns.Test:Kick(name) end
	else
		local fn = GuildPromote or (C_GuildInfo and C_GuildInfo.Promote)
		if fn and not ns.Blocked(L["Befördern"] .. ": " .. name) then ns.Act("GuildPromote", fn, name) end
		if ns.Test and ns.Test:Active() then ns.Test:Promote(name) end
	end
	q.done = q.done + 1
	if #q.names == 0 then
		ns:Print(string.format(q.mode == "kick" and L["Fertig: %d Spieler entfernt."] or L["Fertig: %d Spieler befördert."], q.done))
		self.queue = nil
	end
	if ns.GuildRoster then C_Timer.After(1, function() ns.GuildRoster() end) end
	ns:Fire("GS_BULK")
end

function Bk:Cancel()
	if not self.queue then return end
	self.queue = nil
	ns:Print(L["Sammelaktion abgebrochen."])
	ns:Fire("GS_BULK")
end

------------------------------------------------------------
-- Import aus Guild Roster Manager (GRM)
------------------------------------------------------------
local function Short(full)
	return type(full) == "string" and (full:match("^([^%-]+)") or full) or nil
end

-- GRM speichert die Gilde unter "Gildenname-Server" (Server ohne Leerzeichen und Bindestriche)
function Bk:GRMGuildKey()
	local gname = ns.GuildName()
	if not gname or type(GRM_GuildMemberHistory_Save) ~= "table" then return nil end
	local realm = (GetRealmName and GetRealmName() or ""):gsub("%-", ""):gsub("%s+", "")
	local key = gname .. "-" .. realm
	if GRM_GuildMemberHistory_Save[key] then return key end
	-- sonst: erste Gilde mit diesem Namen (z. B. anders geschriebener Server)
	for k in pairs(GRM_GuildMemberHistory_Save) do
		if type(k) == "string" and k:sub(1, #gname + 1) == gname .. "-" then return k end
	end
	return nil
end

function Bk:GRMLoaded()
	return type(GRM_GuildMemberHistory_Save) == "table"
end

-- Vorschau: { alts = { { name, main } }, joins = { { name, t } }, notes = { { name, text } }, guild = key }
function Bk:GRMPreview()
	local key = self:GRMGuildKey()
	if not key then return nil end
	local g = ns.G()
	local members = GRM_GuildMemberHistory_Save[key] or {}
	local groups = type(GRM_Alts) == "table" and GRM_Alts[key] or {}
	local res = { alts = {}, joins = {}, notes = {}, guild = key }
	-- Twinks: jede Gruppe mit festgelegtem Main
	for _, grp in pairs(groups) do
		if type(grp) == "table" then
			local main = Short(grp.main)
			if main and main ~= "" then
				for _, m in ipairs(grp) do
					local n = Short(type(m) == "table" and m.name)
					if n and n ~= main and ns.Roster.byName[n] then
						-- nur, wenn in GuildSentinel noch nichts von Hand festgelegt ist
						if not g.alts[n] and (ns.Roster:MainOf(n) or "") ~= main then res.alts[#res.alts + 1] = { name = n, main = main } end
					end
				end
			end
		end
	end
	-- Beitrittsdaten und Notizen
	for full, p in pairs(members) do
		local n = Short(full)
		if n and type(p) == "table" and ns.Roster.byName[n] then
			local jd = type(p.joinDateHist) == "table" and p.joinDateHist[1]
			local t = jd and tonumber(jd[4])
			if t and t > 946684800 and t < ns.Now() then
				local have = g.firstSeen[n]
				if not have or have <= 0 or t < have then res.joins[#res.joins + 1] = { name = n, t = t } end
			end
			local cn = type(p.customNote) == "table" and p.customNote[4]
			if type(cn) == "string" and ns.Trim(cn) ~= "" and (g.notes[n] or "") == "" then
				res.notes[#res.notes + 1] = { name = n, text = ns.Trim(cn):sub(1, 200) }
			end
		end
	end
	table.sort(res.alts, function(a, b) return a.name < b.name end)
	table.sort(res.joins, function(a, b) return a.name < b.name end)
	table.sort(res.notes, function(a, b) return a.name < b.name end)
	return res
end

-- übernehmen (was = { alts, joins, notes } jeweils true/false); Twinks gehen an die ganze Gilde
function Bk:GRMImport(what)
	local p = self:GRMPreview()
	if not p then ns:Print(L["Keine GRM-Daten für diese Gilde gefunden. Guild Roster Manager muss dafür aktiviert sein."]) return nil end
	local g = ns.G()
	local n1, n2, n3 = 0, 0, 0
	if what.alts and #p.alts > 0 then
		local e = {}
		for _, x in ipairs(p.alts) do
			g.alts[x.name] = { m = x.main, t = ns.Now(), by = ns.Me() }
			e[x.name] = g.alts[x.name]
			n1 = n1 + 1
		end
		ns.Comm:Send("ALT", { e = e })
	end
	if what.joins then
		for _, x in ipairs(p.joins) do g.firstSeen[x.name] = x.t; n2 = n2 + 1 end
	end
	if what.notes then
		for _, x in ipairs(p.notes) do g.notes[x.name] = x.text; n3 = n3 + 1 end
	end
	ns:Print(string.format(L["GRM-Import: %d Twinks, %d Beitrittsdaten, %d Notizen übernommen."], n1, n2, n3))
	ns:Fire("GS_ROSTER")
	ns:Fire("GS_LEAD")
	return n1, n2, n3
end
