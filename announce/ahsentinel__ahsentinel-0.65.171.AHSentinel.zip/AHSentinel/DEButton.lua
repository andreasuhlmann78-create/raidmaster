if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - DEButton.lua (DW-K1, Wunsch des Nutzers 14.11. 14:13/14:15)
-- Ein Knopf "Entzaubern (n)" am Berufsfenster öffnet das Entzauber-Fenster (DW:Show, im Kampf gesperrt wie bisher).
-- NUR dieser Knopf: kein automatisches Öffnen, kein anderer Weg. n = entzauberbare Teile in den Taschen nach den Regeln
-- des Entzauber-Fensters (DW:Queue: Sperrliste, Sets, Quest, grün–violett) - gezählt nur bei BAG_UPDATE_DELAYED bzw.
-- beim Öffnen des Berufsfensters (Zwischenspeicher, kein Rechnen beim Zeichnen). n = 0 -> grau.
-- Platz: links neben "Alle erstellen", wenn dort frei (kein Blizzard-Knopf, kein ProfessionSentinel); sonst unter dem
-- Berufsfenster (ausserhalb, verdeckt nichts). Selbstkontrolle SK1-j: Knopf sichtbar und frei, n = Zahl im Entzauber-Fenster.
-- ============================================================
local A = AHAnalyzerPro
if not (A and A.On) then return end
local L = A.L
local DB = {}
A.DEButton = DB

DB.W, DB.H = 116, 22
function DB:Count()
    local DW = A.DEWindow
    if not (DW and DW.Queue) then return 0 end
    local ok, q = pcall(DW.Queue, DW)
    return ok and type(q) == "table" and #q or 0
end
function DB:Recount()
    self.n = self:Count()
    self:Update()
end
-- Berufsfenster und "Alle erstellen" (alt: TradeSkillFrame/TradeSkillCreateAllButton; neu: ProfessionsFrame.CraftingPage)
function DB:Host()
    local PF = rawget(_G, "ProfessionsFrame")
    if type(PF) == "table" and PF.IsShown and PF:IsShown() then
        local page = PF.CraftingPage
        local all = page and (page.CreateAllButton or (page.SchematicForm and page.SchematicForm.CreateAllButton))
        return PF, all
    end
    local TF = rawget(_G, "TradeSkillFrame")
    if type(TF) == "table" and TF.IsShown and TF:IsShown() then return TF, rawget(_G, "TradeSkillCreateAllButton") end
    return nil
end
-- überlappt das Rechteck (l, r, b, t) einen sichtbaren Rahmen unter parent (ausser uns)?
local function Rect(f)
    if not (f and f.GetLeft and f.IsShown and f:IsShown()) then return nil end
    local l, r, b, t = f:GetLeft(), f:GetRight(), f:GetBottom(), f:GetTop()
    if not (l and r and b and t) then return nil end
    return l, r, b, t
end
function DB:Overlaps(btn, parent)
    local l, r, b, t = Rect(btn)
    if not l then return false end
    local hit
    local function scan(f, depth)
        if hit or depth > 4 or not (f and f.GetChildren) then return end
        for _, c in ipairs({ f:GetChildren() }) do
            if c ~= btn and c ~= parent then
                local cl, cr, cb, ct = Rect(c)
                if cl and (c.GetObjectType and (c:GetObjectType() == "Button" or c:GetObjectType() == "CheckButton" or c:GetObjectType() == "EditBox")) then
                    if cl < r - 1 and cr > l + 1 and cb < t - 1 and ct > b + 1 then hit = c; return end
                end
                scan(c, depth + 1)
            end
        end
    end
    pcall(scan, parent, 1)
    -- ProfessionSentinel (eigenes Fenster) ebenfalls nicht verdecken
    local PSF = rawget(_G, "ProfessionSentinelFrame") or rawget(_G, "ProfessionSentinelPanel")
    if not hit and PSF then
        local cl, cr, cb, ct = Rect(PSF)
        if cl and cl < r - 1 and cr > l + 1 and cb < t - 1 and ct > b + 1 then hit = PSF end
    end
    return hit ~= nil, hit
end
function DB:Build(parent)
    if self.btn then
        if self.btn:GetParent() ~= parent then self.btn:SetParent(parent) end
        return self.btn
    end
    local UI = A.UI
    local b = UI:Button(parent, "", self.W, self.H, function() DB:OnClick() end)
    b.tooltip = L["Öffnet das Entzauber-Fenster von AHSentinel (entzauberbare Teile in den Taschen)."]
    self.btn = b
    return b
end
function DB:Place(parent, all)
    local b = self.btn
    b:ClearAllPoints()
    self.where = nil
    if all and all.GetLeft and all:GetLeft() then
        b:SetPoint("RIGHT", all, "LEFT", -6, 0)
        local pl = parent.GetLeft and parent:GetLeft()
        local bl = b:GetLeft()
        local over = self:Overlaps(b, parent)
        if bl and pl and bl >= pl + 4 and not over then self.where = "neben Alle erstellen"; return end
        b:ClearAllPoints()
    end
    -- Rückfall: unter dem Berufsfenster, links bündig; verdeckt das etwas (TB168-7, z. B. Reiter unten), eine Zeile tiefer,
    -- sonst über dem Fenster
    local spots = { { "TOPLEFT", "BOTTOMLEFT", 16, -2, "unter dem Berufsfenster" }, { "TOPLEFT", "BOTTOMLEFT", 16, -30, "unter dem Berufsfenster" },
                    { "BOTTOMLEFT", "TOPLEFT", 16, 2, "über dem Berufsfenster" } }
    for i, sp in ipairs(spots) do
        b:ClearAllPoints()
        b:SetPoint(sp[1], parent, sp[2], sp[3], sp[4])
        self.where = sp[5]
        if not self:Overlaps(b, parent) then return end
        if i == #spots then b:ClearAllPoints(); b:SetPoint(spots[1][1], parent, spots[1][2], spots[1][3], spots[1][4]); self.where = spots[1][5] end
    end
end
-- Name des verdeckten Elements für die Selbstkontrolle (TB168-7)
function DB:HitName(hit)
    if not hit then return "-" end
    local n = hit.GetName and hit:GetName()
    if n then return n end
    local t = hit.GetText and hit:GetText()
    return (hit.GetObjectType and hit:GetObjectType() or "?") .. (t and (" \"" .. tostring(t) .. "\"") or "")
end
function DB:Update()
    local b = self.btn
    if not (b and b:IsShown()) then return end
    local n = self.n or 0
    b:SetText(string.format(L["Entzaubern (%d)"], n))
    if b.label then b.label:SetTextColor(unpack(n > 0 and A.UI.C.text or A.UI.C.textDim)) end
end
function DB:OnShowProfession()
    local parent, all = self:Host()
    if not parent then return end
    local b = self:Build(parent)
    b:Show()
    self:Place(parent, all)
    self:Recount()
    -- SK1-j: Knopf sichtbar und frei, n = Zahl des Entzauber-Fensters
    local SC = A.SelfCheck
    if SC and SC.Note and not (A.InTestRoutine and A:InTestRoutine()) then
        local over, hit = self:Overlaps(b, parent)
        local nDW = self:Count()
        pcall(SC.Note, SC, "j", b:IsShown() and not over and nDW == (self.n or 0),
            string.format("Knopf %s · %s · %s · n %d / Fenster %d", b:IsShown() and "sichtbar" or "weg", over and ("verdeckt " .. self:HitName(hit)) or "frei", tostring(self.where), self.n or 0, nDW))
    end
end
function DB:OnHideProfession()
    if self.btn then self.btn:Hide() end
end
function DB:OnClick()
    local DW = A.DEWindow
    if not DW then return end
    if InCombatLockdown and InCombatLockdown() then A:Print(L["Im Kampf gesperrt."]); return end
    DW:Show()
end

local ev = CreateFrame("Frame")
DB.evt = ev
for _, e in ipairs({ "TRADE_SKILL_SHOW", "TRADE_SKILL_CLOSE", "BAG_UPDATE_DELAYED" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, event)
    if event == "TRADE_SKILL_SHOW" then
        -- Blizzard baut das Fenster im selben Ereignis auf: einen Augenblick später platzieren
        if C_Timer and C_Timer.After then C_Timer.After(0.1, function() pcall(DB.OnShowProfession, DB) end) else pcall(DB.OnShowProfession, DB) end
    elseif event == "TRADE_SKILL_CLOSE" then pcall(DB.OnHideProfession, DB)
    elseif event == "BAG_UPDATE_DELAYED" and DB.btn and DB.btn:IsShown() then pcall(DB.Recount, DB) end
end)
