# LevelPilot 3.5.2 – Leveling-Begleiter für WoW Forever (Interface 16001)

Automatische Leveling-Route von Stufe 1 bis 60 für Allianz und Horde – mit Wegfindung,
Pfad auf der Minikarte, Questaufzeichnung, Datenaustausch zwischen Spielern und einem
Assistenten, der auf Ausrüstung, Taschen und mehr achtet.

## Installation
Ordner `LevelPilot` in den `Interface\AddOns\`-Ordner des WoW-Forever-Clients kopieren.

**Empfohlen (optional):** das Datenpaket **LevelPilot Data** zusätzlich installieren. Dann kennt
LevelPilot vom ersten Login an alle Classic-Quests. Ohne Datenpaket nutzt LevelPilot die
eigene Startdatenbank und lernt beim Spielen dazu. Alternativ wird auch QuestieDB gelesen.

## Datenquellen
In dieser Rangfolge – die erste, die etwas weiss, gewinnt bei Orten:
1. **Deine eigenen Beobachtungen** (jede Quest, die du annimmst, jeder Weg, den du läufst)
2. **Startdatenbank** – von LevelPilot-Spielern gesammelt, inklusive neuer Forever-Quests
3. **Daten anderer Spieler** über den Austausch
4. **LevelPilot Data** (separates Addon, optional)
5. **QuestieDB** (optional, nur ohne Datenpaket)

## Bedienung (komplett per Maus)
- **Minimap-Button**: Linksklick = Guide-Fenster, Rechtsklick = Zentrale, ziehen = verschieben
- **Guide-Fenster**: Zone, EP-Balken, die nächsten Schritte mit Entfernung und Questlevel,
  unten die Statusleiste (Haltbarkeit, Taschen, Munition, Hinweise).
  `↻` = neu planen, „Überspringen“ = Schritt/Quest ignorieren, Rechtsklick auf Schritt = überspringen.
- **Zentrale**: Route (Fokus-Zone wählen), Daten, Austausch, Assistent, Einstellungen.
- **Shift halten** pausiert automatisches Annehmen/Abgeben.

## Gesammelte Daten
- Aufgezeichnete und empfangene Quests, Wege, Händler und Flugpunkte lassen sich **nicht löschen** –
  sie sind die gemeinsame Grundlage aller Spieler. Einzelne Quests kann man weiterhin
  **überspringen** (Rechtsklick oder „Überspringen“); das betrifft nur die eigene Route, die Daten
  bleiben erhalten. „Ignorierte zurücksetzen“ in der Zentrale plant übersprungene Quests wieder ein.
- Die Daten liegen in `WTF\Account\<Account>\SavedVariables\LevelPilot.lua` und bleiben bei
  Updates erhalten.
- **Dreifacher Schutz:** automatische Zweitkopie im Charakter (stellt verlorene oder beschädigte
  Daten beim Start selbst wieder her), Sicherungsskripte für den PC in `Tools` (stündlich, auch in
  OneDrive/Dropbox) und „Daten sichern/laden“ als Text in der Zentrale. Details: `Tools\ANLEITUNG.md`.

## Questannahme: erst einsammeln, dann questen
- Bevor ein Questziel drankommt, nimmt die Route alle annehmbaren Quests im Umkreis von etwa 400 Yards an
  (nur Quests, die du vom Level her schon bekommst). Abgaben am selben Ort laufen mit.
- Kommt die Route später an einen Questgeber, werden alle Questgeber im Umkreis von etwa 250 Yards gleich mit besucht.
- Nie mehr Annahmen, als ins Questlog passen; ist es voll, kommen weitere Quests erst nach den nächsten Abgaben.

## Questfortschritt über den Gegnern (neu in 3.3)
- Über der Namensplakette eines Gegners, der für deine laufende Quest zählt, steht der Stand aus dem
  Questlog, z. B. „3/10“ – beim Töten und bei Gegenständen, die dieser Gegner fallen lässt.
- Standard: nur die Quest des aktuellen Guide-Schritts (im Dungeon alle Quests der Instanz).
  Zentrale → Einstellungen → Anzeige: auch für alle offenen Quests oder ganz aus.
- Funktioniert in jeder Spielsprache (Zuordnung über NPC-IDs und die Questziele des Spiels).
- Voraussetzung: Namensplaketten der Gegner sind im Spiel eingeschaltet (Taste V).

## Extras (neu in 3.4) – Zentrale → Reiter „Extras“
Jede Funktion lässt sich einzeln ein- und ausschalten.
- **Karte & Questgegenstände:** Questgebiete auf Karte und Minikarte, Symbole an den Fundstellen von
  Questgegenständen (Kisten, Kräuter, Gegenstände am Boden), Pfeil zur nächsten Fundstelle, kurzer
  Hinweis mit Ton, wenn ein Questgegenstand nah ist, „!“ für annehmbare Quests.
- **Tooltips:** Gegner zeigen ihren Questfortschritt, Gegenstände zeigen, für welche Quest sie sind
  oder welche Quest sie starten. Solche Gegenstände werden nie automatisch verkauft.
- **Vorräte & Taschen:** beim Händler Essen, Wasser (nicht für Magier), Munition und Tierfutter
  automatisch nachkaufen – immer die beste Stufe für dein Level, höchstens 25 % deines Goldes.
  Questbelohnungen, die ein Upgrade sind, werden angelegt. Hinweis auf Questgegenstände ohne offene Quest.
- **Zeit & Sitzung:** Gold pro Stunde (AFK-Zeit zählt nicht), Bestzeiten je Level über alle Charaktere,
  Zeit-Schätzung je Questziel und Zone nach deinem eigenen Tempo, Erholt-Bonus und Ruhestein in der
  Statuszeile, „Wo war ich?“ beim Einloggen, Erinnerung an offene Abgaben beim Zonenwechsel,
  Bilanz beim Ausloggen (`/lp bilanz`, optional im Gildenchat), Pfeil zur Leiche nach dem Tod.
- **Hinweise:** Klassenquests der nächsten Level, Klassen-Erinnerungen (Seelensplitter, Gift,
  Begleiter, Waffenmeister), Trainerkosten (lernt die echten Preise beim Trainer), Gold-Planung
  fürs Reittier ab Level 40, Erste Hilfe und Kochen in der Nähe.
- **Gruppe:** Quests mit einem Klick teilen (`/lp teilen`), fertiger Text für die Gruppensuche
  (`/lp gruppe`), Mitspieler mit derselben Elite-Quest in deiner Zone finden. Achtung: dabei sehen
  andere LevelPilot-Spieler deinen Charakternamen – abschaltbar.
- **Kompaktmodus** (`/lp kompakt`): der Guide als eine Zeile.
- **Einstellungen nur für diesen Charakter:** Schalter in Einstellungen; gesammelte Daten bleiben
  immer accountweit.

## Fehler-Protokoll (neu in 3.4.1)
LevelPilot schreibt beim normalen Spielen automatisch mit, was auffällt – der Spieler muss nichts tun:
Lua-Fehler, falsch erkannte Zonen, unbekannte Position, Planung in der falschen Zone, kein Weg zum Ziel,
minutenlang nicht näher ans Ziel, sehr lange Schritte, Tode mit Ort, langsame Planung sowie Ein- und
Ausloggen mit Pause. `/lp protokoll` (oder Zentrale → Daten → Fehler-Protokoll) zeigt alles als Text
zum Kopieren, `/lp protokoll leeren` leert es. Das Protokoll bleibt auf dem eigenen Computer und enthält
keine Namen oder Zugangsdaten. Abschaltbar unter Zentrale → Extras.

## Addon unterstützen
LevelPilot ist kostenlos. Wer es unterstützen möchte: Knopf **Unterstützen** in der Titelleiste des
Guide-Fensters, Zentrale → Einstellungen → „Addon unterstützen“ oder `/lp spenden`. Das Fenster zeigt den
PayPal-Link zum Kopieren und öffnet sich nie von selbst.

## Wegfindung & Gelände
- Wege werden über ein **Wegenetz** gesucht: Pässe, Tunnel, Brücken, Schiffe und Zeppeline
  als Grundnetz, dazu die Wege der Startdatenbank und **jeder Weg, den du läufst**.
- Zonenwechsel nur über bekannte Übergänge oder gelaufene Wege – nie quer durch Gebirge.
- Innerhalb einer Zone folgt der Weg ohne bekannte Wege der **Geländekarte** aus dem Datenpaket:
  Wo Kreaturen und Objekte stehen, ist begehbarer Boden, Patrouillenwege der Wachen sind meist
  Strassen, leere Flächen sind oft Berge, Felswände oder Wasser. Der Weg bevorzugt Strassen, meidet
  Unbekanntes und wird geglättet. Addons können das echte Gelände nicht auslesen – das ist die
  beste verfügbare Näherung; selbst gelaufene Wege gehen immer vor. Ohne Geländekarte wird die
  Luftlinie gezeigt (grau = unsicher). Abschalten: Zentrale → Einstellungen → Anzeige.
- **Höhlen, Minen, Tunnel** (neu in 3.2): Liegt ein Ziel in einer Höhle, führt der Weg zuerst zum
  Eingang und dann hinein; aus einer Höhle heraus zuerst zum Ausgang. LevelPilot lernt Eingänge
  selbst: Wechselt man von draussen nach drinnen (z. B. kein Reittier mehr möglich; Gasthäuser und
  Städte zählen nicht), wird die Stelle als Eingang gespeichert, der begangene Innenraum dazu. Ein
  zweiter Ausgang (Tunnel) wird ebenfalls erkannt. Gelernte Höhlen werden mit anderen Spielern
  geteilt, dreifach gesichert und vom Sammelwerkzeug in die Startdatenbank übernommen.
- Gelaufene Wege, Tunnel und Übergänge werden nicht mehr nachträglich „geglättet“ – sie bleiben,
  wie sie gelaufen wurden. Luftlinien quer über Berge sind in der Wegsuche teurer, damit bekannte
  Wege durch Tunnel und um Berge herum gewinnen.
- **Anzeige**: Pfeil folgt dem Pfad Wegpunkt für Wegpunkt; Pfadlinie auf Minikarte und Weltkarte.
  Blizzard erlaubt Addons nicht, direkt in die 3D-Spielwelt zu zeichnen.

## Komfort (neu in 3.0)
- **Aktionsleiste** neben dem Guide-Fenster (Shift + Ziehen verschiebt sie):
  „Ziel anvisieren“ visiert die Questgegner bzw. den Questgeber des aktuellen Schritts an und
  markiert sie mit einem Totenkopf; „Gegenstand“ benutzt den Questgegenstand (bzw. den Ruhestein).
  Beide auf Tasten legbar: Optionen → Tastenbelegung → LevelPilot.
- **Händler-Automatik:** graue Gegenstände verkaufen und automatisch reparieren.
- **Automatisch fliegen:** beim Flugmeister direkt zum geplanten Ziel.
- **Ruhestein:** LevelPilot schlägt vor, in Hauptzonen zu binden, und plant „Ruhestein benutzen“,
  wenn das nächste Ziel weit weg, aber nahe am Bindeort liegt.
- **Zeitanzeige:** EP pro Stunde, Zeit bis zum nächsten Level und geschätzt bis 60; Zeit je Level.
- **[NEU]-Markierung** für WoW-Forever-Quests, die es in Classic nicht gab.
- **Echte Forever-EP:** Die bei der Abgabe erhaltene EP wird aufgezeichnet, geteilt und im Planer
  (Speedrun, Dungeons) statt der Classic-Werte verwendet.
- **Gruppenmodus:** Fortschritt der Mitspieler unter dem Guide-Fenster (gleich / voraus /
  zurück); gemeinsame Quests werden bevorzugt.
- **Dungeon-Übersicht** (Zentrale → Dungeons): Stufen, Zugang, Quests offen / im Log /
  erledigt, Lohnt-sich-Rechnung; Klick führt zum Eingang.
- **Finde nächsten** (Zentrale → Komfort oder `/lp find …`): Reparatur, Händler, Klassentrainer,
  Gasthaus, Flugmeister, Bank, Auktionshaus, Briefkasten. Wegpunkt: `/lp way X Y`.
- **Sicherer Modus:** meidet Quests mit Elite- oder deutlich höheren Gegnern und warnt vor
  gefährlichen Gegnern auf dem Weg.
- **Sprache:** alle Sprachen der WoW-Clients – Deutsch, Englisch, Französisch, Spanisch (Europa und Lateinamerika),
  Portugiesisch, Italienisch, Russisch, Koreanisch, Chinesisch (vereinfacht und traditionell). Automatisch nach
  Spielsprache oder fest einstellbar (Zentrale → Komfort oder `/lp lang de|en|fr|es|mx|pt|it|ru|ko|cn|tw|auto`).
  Dungeonnamen kommen in der Spielsprache direkt vom Client. Quest- und NPC-Namen aus dem Datenpaket sind englisch,
  angenommene Quests zeigt das Spiel in seiner Sprache.

## English
LevelPilot calculates your leveling route 1–60 automatically (no hand-written guide), learns the new
WoW Forever quests while you play and shares them with other LevelPilot players. It includes a
terrain-aware path on the minimap and world map, an arrow, a speedrun mode, dungeon planning with
WoW Forever XP rules and faction locks, group mode, Hearthstone planning, vendor automation, a
target and quest item button, XP/hour tracking and a character assistant. The interface follows
your game language and supports every WoW client language (enUS/enGB, deDE, frFR, esES, esMX, ptBR, itIT, ruRU,
koKR, zhCN, zhTW). Switch it in the control center → Comfort or with `/lp lang <code>`.
New in 3.4 (control center → Extras): quest item locations with arrow and alert, quest tooltips,
automatic restocking of food/water/ammo/pet food, auto-equip of reward upgrades, gold per hour,
best level times, time estimates, rested/hearthstone status, class quest and trainer cost hints,
mount gold planning, quest sharing, group finder text, elite partner search, compact mode and
per-character settings.


### ☕ Support the addon

LevelPilot is free and made in my spare time. If it helps you, you can support it with a small donation – thank you so much!

**[Donate with PayPal](https://www.paypal.com/ncp/payment/46R68N2BF7BTY)**

In-game: the **Support** button in the addon window (or `/lp donate`).

## Speedrun auf 60
- Umschalten jederzeit: Knopf „Normal/Speedrun“ im Guide-Fenster, Zentrale → Route oder `/lp speed`
  bzw. `/lp normal`. Die Route wird sofort neu geplant, angefangene Quests bleiben erhalten.
- Der Speedrun bewertet jede Quest nach **EP pro Minute** (Quest-EP aus dem Datenpaket, geschätzte
  Zeit aus Zielen, Wegen und Abgabe) und lässt aus: Eskorten,
  Quests 5+ Stufen unter dir und jede Quest, die weniger EP pro Minute bringt als Monster grinden
  auf deinem Level. Elite-Gegner und weite Wege gehen als Zeitaufschlag in die Rechnung ein.
  Dungeons erst ab 3 Quests. Strenge (Zentrale → Einstellungen): 1 = locker (unter 60 % der
  Grind-EP), 2 = mittel (90 %), 3 = streng (120 %, Standard). Je strenger, desto mehr wird
  zwischendurch gegrindet.
- **Klassenquests und ihre Vorquests werden nie ausgelassen.**
- Ausgelassene Quests nimmt die Automatik nicht an (Shift gedrückt halten = selbst entscheiden).

## Dungeon-Quests
- Dungeon-Quests werden mitgenommen, wenn du ohnehin beim Questgeber bist – frühestens zwei Stufen
  vor dem Dungeon und nur, solange im Questlog Platz ist (4 Plätze bleiben frei; der Questlog
  hat auf WoW Forever 40 Plätze, im Classic-Client 20 – automatisch erkannt).
- Erreichst du das passende Level, sammelt LevelPilot die Dungeon-Quests in der Nähe gezielt ein und
  plant dann **einen** Schritt „Dungeon“: zum Eingang, Gruppe suchen, alle Quests in einem Lauf.
  Standard: ab 2 Quests (einstellbar). Mit nur einer Quest nur, wenn du direkt am Eingang bist.
- **Lohnt sich der Lauf?** LevelPilot rechnet Gruppensuche + Lauf gegen Quest-EP + Monster-EP.
  Auf WoW Forever gibt es in Dungeons ca. 70 % weniger Monster-EP als in Classic, dafür bringen
  Dungeon-Quests ca. 94–138 % mehr EP. Beides ist eingerechnet (automatisch Monster-EP 30 %,
  Quest-EP vorsichtig 200 %; einstellbar unter Zentrale → Einstellungen). Ein Lauf wird nur
  geplant, wenn er mindestens 55 % (Speedrun: 90 %) der EP pro Minute von Grinden bringt;
  `/lp diag` zeigt die Rechnung je Dungeon.
- Werden die Quests bald grau, hat der Dungeon Vorrang. Rechtsklick auf den Schritt stellt ihn für
  3 Stufen zurück.
- Im Dungeon zeigt der Guide die offenen Questziele. Nach dem Verlassen geht es mit den Abgaben weiter.
- **Fraktionssperren:** Das Verlies (Sturmwind) nur Allianz, der Flammenschlund (Orgrimmar) nur Horde.
  Eingänge in feindlichen Hauptstädten sind immer gesperrt. Liegt ein Eingang im Gebiet der anderen
  Fraktion (z. B. Gnomeregan, Todesminen für die Horde), weist der Guide darauf hin.
- Abschalten: Zentrale → Einstellungen → Dungeons. Die Regeln je Dungeon stehen in `Data\Dungeons.lua`.

## Assistent
Haltbarkeit (mit Weg zum nächsten Reparatur-Händler), Taschenplatz und Taschen-Upgrades,
Munition (Jäger), Talentpunkte (Classic), neue Fähigkeiten beim Trainer, mögliche
Ausrüstungs-Upgrades (Anlegen per Klick), Empfehlung bei Questbelohnungen, voller Questlog.

## Startdatenbank pflegen
Siehe `Tools\ANLEITUNG.md`: Aufzeichnungen der Testspieler einsammeln und mit
`Tools\Startdatenbank_erstellen.bat` zusammenführen.

## Lizenz
Siehe `LICENSE.txt`. LevelPilot enthält keine Daten oder keinen Code anderer Addons.
Das optionale Datenpaket „LevelPilot Data“ ist ein eigenständiges Addon unter GNU GPL v3.
