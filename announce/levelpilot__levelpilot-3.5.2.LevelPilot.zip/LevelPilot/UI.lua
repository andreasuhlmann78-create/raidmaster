-- LevelPilot - Hauptfenster
-- Kopf mit EP-Balken, geplante Schritte, Statusleiste (Haltbarkeit, Taschen, Munition),
-- Hinweis-Einblendungen, Minimap-Button.

local _, LP = ...
local L = LP.L
local UI = {}
LP:RegisterModule("UI", UI)

local C = LP.colors
local WHITE = "Interface\\Buttons\\WHITE8X8"
local BACKDROP_TEMPLATE = BackdropTemplateMixin and "BackdropTemplate" or nil

local WIDTH   = 350          -- Standardbreite
local MIN_W, MAX_W = 260, 900
local MIN_H, MAX_H = 150, 1000
local MAX_ROWS = 15
local HEADER  = 93           -- wird an die Textlaenge angepasst (Layout)
local STATUS  = 26           -- wird an die Textlaenge angepasst (Layout)
local STATUS_MIN = 26
local GAP     = 3
local MIN_ROW = 30

------------------------------------------------------------------------
-- Styling-Helfer
------------------------------------------------------------------------
function UI:Skin(f, bg, border)
    if not f.SetBackdrop then Mixin(f, BackdropTemplateMixin) end
    f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
    bg = bg or C.bg
    border = border or C.border
    f:SetBackdropColor(bg[1], bg[2], bg[3], bg[4] or 1)
    f:SetBackdropBorderColor(border[1], border[2], border[3], border[4] or 1)
end

-- alle Texte und Knoepfe von LevelPilot: beim Sprachwechsel sofort neu beschriften (ohne /reload)
UI.texts = {}           -- Texte werden im Spiel nie freigegeben, daher feste Liste
UI.buttons = {}

function UI:Text(parent, size, color, flags)
    local fs = parent:CreateFontString(nil, "OVERLAY")
    UI.texts[fs] = true
    LP:RegisterText(fs)
    fs:SetFont(LP.FONT, size or 12, flags or "")
    color = color or C.text
    fs:SetTextColor(color[1], color[2], color[3])
    fs:SetJustifyH("LEFT")
    fs:SetJustifyV("TOP")
    fs:SetWordWrap(true)
    return fs
end

-- Beschriftung in den Knopf einpassen: bei langen Woertern (andere Sprachen) kleinere Schrift statt "..."
function UI.FitLabel(b)
    local fs = b and b.label
    if not (fs and fs.GetStringWidth and fs.SetFont) then return end
    local w = (b:GetWidth() or 0) - 8
    if w <= 0 then return end
    for size = 11, 7, -1 do
        pcall(fs.SetFont, fs, LP.FONT, size, "")
        if (fs:GetStringWidth() or 0) <= w then return end
    end
end

function UI:Button(parent, label, w, h, onClick, tooltip)
    local b = CreateFrame("Button", nil, parent, BACKDROP_TEMPLATE)
    b:SetSize(w or 24, h or 20)
    UI:Skin(b, C.row, C.border)
    local fs = UI:Text(b, 11, C.text)
    fs:SetPoint("CENTER")
    fs:SetJustifyH("CENTER")
    fs:SetJustifyV("MIDDLE")
    fs:SetText(label)
    b.label = fs
    b.tip = tooltip
    UI.buttons[b] = true
    UI.FitLabel(b)
    b:SetScript("OnEnter", function(self)
        self:SetBackdropBorderColor(C.accent[1], C.accent[2], C.accent[3], 1)
        local tip = (rawget(self, "tipFn") and self.tipFn()) or rawget(self, "tip")
        if tip then
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:AddLine(tip, 1, 1, 1, true)
            GameTooltip:Show()
        end
    end)
    b:SetScript("OnLeave", function(self)
        self:SetBackdropBorderColor(C.border[1], C.border[2], C.border[3], 1)
        GameTooltip:Hide()
    end)
    b:SetScript("OnClick", onClick)
    return b
end

function UI:Gradient(tex)
    tex:SetTexture(WHITE)
    if tex.SetGradient and CreateColor then
        local ok = pcall(tex.SetGradient, tex, "HORIZONTAL",
            CreateColor(C.accent[1], C.accent[2], C.accent[3], 1),
            CreateColor(C.accent2[1], C.accent2[2], C.accent2[3], 1))
        if ok then return end
    end
    if tex.SetGradientAlpha then
        pcall(tex.SetGradientAlpha, tex, "HORIZONTAL",
            C.accent[1], C.accent[2], C.accent[3], 1, C.accent2[1], C.accent2[2], C.accent2[3], 1)
    else
        tex:SetVertexColor(C.accent[1], C.accent[2], C.accent[3])
    end
end

------------------------------------------------------------------------
-- Schritt-Texte
------------------------------------------------------------------------
local ICONS = {
    ACCEPT   = "Interface\\GossipFrame\\AvailableQuestIcon",
    TURNIN   = "Interface\\GossipFrame\\ActiveQuestIcon",
    COMPLETE = "Interface\\Icons\\INV_Sword_04",
    GOTO     = "Interface\\Icons\\INV_Misc_Map_01",
    FLY      = "Interface\\Minimap\\Tracking\\FlightMaster",
    FP       = "Interface\\Minimap\\Tracking\\FlightMaster",
    LEVEL    = "Interface\\Icons\\Spell_ChargePositive",
    NOTE     = "Interface\\Icons\\INV_Misc_Note_01",
    DUNGEON  = "Interface\\Icons\\INV_Misc_Key_03",
    HEARTH   = "Interface\\Icons\\INV_Misc_Rune_01",
    BIND     = "Interface\\Icons\\INV_Misc_Rune_01",
}

local LABELS = {
    ACCEPT   = "|cffffd24aAnnehmen|r",
    TURNIN   = "|cff3dd694Abgeben|r",
    COMPLETE = "|cffffa040Erledigen|r",
    GOTO     = "|cffffb238Gehe zu|r",
    FLY      = "|cff7fc8ffFliegen nach|r",
    FP       = "|cff7fc8ffFlugpunkt|r",
    LEVEL    = "|cff4ddb80Level|r",
    NOTE     = "",
    DUNGEON  = "|cffc890ffDungeon|r",
    HEARTH   = "|cff7fc8ffRuhestein|r",
    BIND     = "|cff7fc8ffRuhestein binden|r",
}

local MUTED = "|cff9c9ea6"

local function LevelTag(level)
    if not level or level <= 0 then return "" end
    local hex = "ffffff"
    if GetQuestDifficultyColor then
        local c = GetQuestDifficultyColor(level)
        if c then hex = string.format("%02x%02x%02x", c.r * 255, c.g * 255, c.b * 255) end
    end
    return " |cff" .. hex .. "[" .. level .. "]|r"
end

local function DistText(step, current)
    local d
    if current and LP.Nav then d = LP.Nav:RemainingDistance() end
    if not d and step.map and step.x then d = LP.Geo:DistToMapPoint(step.map, step.x, step.y) end
    if not d then return "" end
    return "  " .. MUTED .. LP:FormatDist(d) .. "|r"
end

function UI:ShortLabel(step)
    if not step then return "" end
    if step.q then return step.q end
    local t = step.text or ""
    t = t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    t = t:match("^[^\n]*") or ""
    if #t > 50 then t = t:sub(1, 48) .. "…" end
    return t
end

function UI:StepText(s, full)
    local head = L[LABELS[s.t] or ""]
    local extra = {}
    if s.t == "ACCEPT" or s.t == "TURNIN" or s.t == "COMPLETE" then
        head = head .. ": " .. (s.q or (L["Quest "] .. (s.id or "?"))) .. LevelTag(s.level)
        if s.isNew and LP.db.showNewTag then head = head .. L[" |cffb48cff["] .. LP.L["NEU"] .. "]|r" end
        if s.shared and full then extra[#extra + 1] = "|cff7fc8ff" .. LP.L("Auch in der Gruppe (%d)", s.shared) .. "|r" end
        if s.classQuest and full and not LP.Planner:IsSpeed() then extra[#extra + 1] = "|cffffb238" .. LP.L["Klassenquest"] .. "|r" end
        if s.npc and s.t ~= "COMPLETE" then extra[#extra + 1] = L["bei "] .. s.npc end
        if s.map and s.map ~= select(4, LP.Geo:Player()) then extra[#extra + 1] = LP.Geo:MapName(s.map) end
        if s.t == "COMPLETE" and full then
            local st = LP.Planner.inLog[s.id]
            if st then
                local objs = LP.API.Objectives(st.index)
                local tr = LP.Names and LP.Names:ObjectiveTexts(s.id, objs) or {}
                for ci, ob in ipairs(objs) do
                    local text = tr[ci] or ob.text
                    if text then extra[#extra + 1] = (ob.finished and "|cff4ddb80" or "") .. text .. (ob.finished and "|r" or "") end
                end
            end
            if not s.map then extra[#extra + 1] = L["Ort unbekannt – Questbeschreibung lesen"] end
            local eta = full and LP.Session and LP.Session:EtaText(s)
            if eta then extra[#extra + 1] = "|cff9c9ea6" .. eta .. "|r" end
        end
        if s.t == "ACCEPT" and not s.npc and full then extra[#extra + 1] = L["Questgeber an dieser Stelle"] end
        if s.classQuest and full then extra[#extra + 1] = L["|cffffb238Klassenquest – auch im Speedrun|r"] end
    elseif s.t == "FLY" then
        head = head .. ": " .. (s.text or "?")
        if full then extra[#extra + 1] = L["Sprich mit dem Flugmeister"] end
    elseif s.t == "LEVEL" then
        head = head .. ": " .. (s.lvl or "?")
        if s.text then extra[#extra + 1] = s.text end
    elseif s.t == "HEARTH" then
        head = head .. ": " .. (s.text or "?")
        if full then extra[#extra + 1] = LP.L["Ruhestein benutzen (Knopf neben dem Fenster) – spart den langen Weg"] end
    elseif s.t == "BIND" then
        head = head .. ": " .. (s.text or "?")
        if full then
            if s.npc then extra[#extra + 1] = LP.L("bei %s", s.npc) end
            extra[#extra + 1] = LP.L["Viele Aufgaben in dieser Zone – hier binden spart später Wege"]
        end
    elseif s.t == "DUNGEON" then
        head = head .. ": " .. (s.q or "?")
        if s.min then head = head .. " " .. MUTED .. L["(Stufe "] .. s.min .. "–" .. (s.max or "?") .. ")|r" end
        if s.inside then
            extra[#extra + 1] = L["Du bist im Dungeon – die offenen Questziele stehen darunter."]
        else
            local list = s.quests or {}
            extra[#extra + 1] = #list .. (#list == 1 and L[" Quest: "] or L[" Quests: "]) .. table.concat(list, ", ")
            if full then
                extra[#extra + 1] = L["Am Eingang eine Gruppe suchen (5 Spieler)."]
                if s.urgent then extra[#extra + 1] = L["|cffffb238Jetzt ideal – die Quests werden bald grau.|r"] end
                if s.hostile then extra[#extra + 1] = L["Eingang im Gebiet der anderen Fraktion – Vorsicht."] end
                extra[#extra + 1] = L["Rechtsklick = zurückstellen"]
            end
        end
    else
        local first = (s.text or ""):match("^[^\n]*") or ""
        head = (head ~= "" and (head .. ": ") or "") .. first
        local rest = (s.text or ""):match("^[^\n]*\n(.+)$")
        if rest then extra[#extra + 1] = rest end
    end
    if full and LP.db.safeMode and LP.Nav and LP.Nav.danger and s == LP.Engine:Current() then
        table.insert(extra, 1, "|cffff5555" .. LP.Nav.danger .. "|r")
    end
    local out = head .. DistText(s, full)
    if #extra > 0 then
        if full then
            out = out .. "\n" .. MUTED .. table.concat(extra, "\n") .. "|r"
        else
            out = out .. "\n" .. MUTED .. extra[1] .. "|r"
        end
    end
    return out
end

------------------------------------------------------------------------
-- Hauptfenster
------------------------------------------------------------------------
local frame, rows = nil, {}

local function CreateRow(i)
    local r = CreateFrame("Button", nil, frame.body, BACKDROP_TEMPLATE)
    r:SetHeight(MIN_ROW)
    if i == 1 then
        r:SetPoint("TOPLEFT", frame.body, "TOPLEFT", 0, 0)
        r:SetPoint("TOPRIGHT", frame.body, "TOPRIGHT", 0, 0)
    else
        r:SetPoint("TOPLEFT", rows[i - 1], "BOTTOMLEFT", 0, -GAP)
        r:SetPoint("TOPRIGHT", rows[i - 1], "BOTTOMRIGHT", 0, -GAP)
    end
    UI:Skin(r, C.row, { 0, 0, 0, 0 })
    r:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    local bar = r:CreateTexture(nil, "ARTWORK")
    bar:SetTexture(WHITE)
    bar:SetWidth(3)
    bar:SetPoint("TOPLEFT")
    bar:SetPoint("BOTTOMLEFT")
    r.bar = bar

    local icon = r:CreateTexture(nil, "ARTWORK")
    icon:SetSize(18, 18)
    icon:SetPoint("TOPLEFT", 10, -7)
    r.icon = icon

    local text = UI:Text(r, 11, C.text)
    text:SetPoint("TOPLEFT", icon, "TOPRIGHT", 8, 0)
    text:SetWidth(math.max(MIN_W, math.min(MAX_W, LP.db.frameW or WIDTH)) - 70)
    text:SetSpacing(2)
    r.text = text

    r:SetScript("OnClick", function(self, btn)
        if btn == "RightButton" and self.step then
            LP.Engine:Skip(self.step)
        end
    end)
    r:SetScript("OnEnter", function(self)
        if not self.step then return end
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine(UI:StepText(self.step, true), 1, 1, 1, true)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine(L["Rechtsklick: überspringen / Quest ignorieren"], 0.6, 0.6, 0.65)
        GameTooltip:Show()
    end)
    r:SetScript("OnLeave", function() GameTooltip:Hide() end)
    rows[i] = r
    return r
end

local sizing = false

local function Width() return math.max(MIN_W, math.min(MAX_W, LP.db.frameW or WIDTH)) end
local function ManualHeight() return (not LP.char.collapsed) and LP.db.frameH or nil end

-- Anzahl Zeilen: eingeklappt 1, feste Hoehe = so viele wie passen (max. MAX_ROWS), sonst Einstellung
local function RowCount()
    if LP.char.collapsed or LP.db.compactMode then return 1 end
    if ManualHeight() or sizing then return MAX_ROWS end
    return LP.db.stepsShown
end

local function EnsureRows()
    local n = RowCount()
    for i = 1, math.max(n, #rows) do
        local r = rows[i] or CreateRow(i)
        if i <= n then r:Show() else r:Hide() end
    end
end

-- Kopf und Statusleiste der Textlaenge anpassen (lange Texte umbrechen statt abschneiden)
local function Layout()
    if not frame or not frame.xtext then return end
    local xh = math.max(10, math.ceil(frame.xtext:GetStringHeight() or 10))
    frame.xbg:ClearAllPoints()
    frame.xbg:SetPoint("TOPLEFT", 10, -(70 + xh + 3))
    frame.xbg:SetPoint("TOPRIGHT", -10, -(70 + xh + 3))
    HEADER = 70 + xh + 3 + 4 + 6
    frame.body:ClearAllPoints()
    frame.body:SetPoint("TOPLEFT", 6, -HEADER)
    frame.body:SetPoint("TOPRIGHT", -6, -HEADER)
    local st = frame.status
    st.text:SetHeight(0)                        -- ohne feste Hoehe misst das Spiel die echte Texthoehe
    local sh = math.max(STATUS_MIN - 4, math.ceil(st.text:GetStringHeight() or 0) + 6)
    st:SetHeight(sh)
    st.text:SetHeight(sh)
    STATUS = sh + 4
end
UI.Layout = Layout

-- Breitenabhaengige Elemente anpassen
local function ApplyWidth()
    local w = Width()
    frame:SetWidth(w)
    -- schmales Fenster: Spenden-Knopf nur als Muenze, damit nichts ueberdeckt wird
    local b = frame.bSupport
    if b then
        if w < 330 then b.label:Hide() b.coin:Show() b:SetWidth(20)
        else b.label:Show() b.coin:Hide() b:SetWidth(b.fullW) end
    end
    frame.title:SetWidth(w - 24)
    frame.xtext:SetWidth(w - 20)
    frame.status.text:SetWidth(w - 34)       -- Platz fuer den Groessen-Griff unten rechts
    if frame.status.text.SetWordWrap then frame.status.text:SetWordWrap(true) end
    for _, r in ipairs(rows) do r.text:SetWidth(w - 70) end
    Layout()
end

-- Statusleiste
local function CreateStatus()
    local s = CreateFrame("Button", nil, frame)
    s:SetHeight(STATUS - 4)
    s:SetPoint("BOTTOMLEFT", 8, 4)
    s:SetPoint("BOTTOMRIGHT", -8, 4)
    s.text = UI:Text(s, 10, C.muted)
    s.text:SetPoint("LEFT", 0, 0)
    s.text:SetJustifyV("MIDDLE")
    s.text:SetWidth(WIDTH - 16)
    s:SetScript("OnClick", function() LP.Center:Toggle("assist") end)
    s:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine(L["Assistent"])
        local hints = LP.Advisor and LP.Advisor.hints or {}
        if #hints == 0 then GameTooltip:AddLine(L["Alles in Ordnung."], 0.5, 0.9, 0.6) end
        for _, h in ipairs(hints) do
            local c = h.sev == 3 and C.bad or (h.sev == 2 and C.warn or C.muted)
            GameTooltip:AddLine(h.text, c[1], c[2], c[3], true)
        end
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine(L["Klick: Zentrale öffnen"], 0.6, 0.6, 0.65)
        GameTooltip:Show()
    end)
    s:SetScript("OnLeave", function() GameTooltip:Hide() end)
    frame.status = s
end

function UI:Init()
    frame = CreateFrame("Frame", "LevelPilotFrame", UIParent, BACKDROP_TEMPLATE)
    UI.frame = frame
    frame:SetWidth(Width())
    frame:SetHeight(220)
    frame:SetScale(LP.db.scale or 1)
    frame:SetResizable(true)
    if frame.SetResizeBounds then
        frame:SetResizeBounds(MIN_W, MIN_H, MAX_W, MAX_H)
    else
        if frame.SetMinResize then frame:SetMinResize(MIN_W, MIN_H) end
        if frame.SetMaxResize then frame:SetMaxResize(MAX_W, MAX_H) end
    end
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetFrameStrata("MEDIUM")
    UI:Skin(frame, C.bg, C.border)
    if LP.db.framePos then
        local p = LP.db.framePos
        frame:SetPoint(p[1], UIParent, p[2], p[3], p[4])
    else
        frame:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -40, -220)
    end
    frame:SetScript("OnDragStart", function(self) if not LP.db.locked then self:StartMoving() end end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        LP.db.framePos = { p, rp, x, y }
    end)

    -- Kopf: Marke links, Akzentstreifen links (Fraktionsfarbe)
    local side = frame:CreateTexture(nil, "ARTWORK")
    side:SetTexture(WHITE)
    side:SetWidth(2)
    side:SetPoint("TOPLEFT", 1, -1)
    side:SetPoint("BOTTOMLEFT", 1, 1)
    local fc = LP:PlayerFaction() == "Horde" and C.horde or C.alliance
    side:SetVertexColor(fc[1], fc[2], fc[3], 0.9)

    local brand = UI:Text(frame, 10, C.muted)
    brand:SetPoint("TOPLEFT", 12, -9)
    brand:SetText("|cffffb238LEVEL|r|cff3dd694PILOT|r")

    local title = UI:Text(frame, 14, C.text)
    title:SetPoint("TOPLEFT", 12, -28)      -- eigene Zeile unter den Knoepfen: nichts wird abgeschnitten
    title:SetWidth(WIDTH - 24)
    title:SetWordWrap(false)
    frame.title = title

    local bClose = UI:Button(frame, "x", 20, 20, function() UI:Toggle() end, L["Ausblenden"])
    bClose:SetPoint("TOPRIGHT", -6, -6)
    local bCollapse = UI:Button(frame, "–", 20, 20, function()
        LP.char.collapsed = not LP.char.collapsed
        EnsureRows()
        UI:Refresh()
    end, L["Einklappen / Ausklappen"])
    bCollapse:SetPoint("RIGHT", bClose, "LEFT", -3, 0)
    local bCenter = UI:Button(frame, L["Zentrale"], 58, 20, function() LP.Center:Toggle() end, L["Route, Daten, Austausch, Assistent, Einstellungen"])
    bCenter:SetPoint("RIGHT", bCollapse, "LEFT", -3, 0)
    -- Spenden-Knopf (oeffnet nur auf Klick das Fenster mit dem PayPal-Link)
    local bSupport = LP.Donate.CreateButton(frame, 96, 20)
    bSupport:SetPoint("RIGHT", bCenter, "LEFT", -3, 0)
    local coin = bSupport:CreateTexture(nil, "OVERLAY")
    coin:SetSize(14, 14)
    coin:SetPoint("CENTER")
    coin:SetTexture("Interface\\Icons\\INV_Misc_Coin_01")
    coin:Hide()
    bSupport.coin, bSupport.fullW = coin, bSupport:GetWidth()
    frame.bSupport = bSupport
    -- Neu-planen-Knopf mit Pfeil-Grafik (das Zeichen ↻ fehlt in den Schriften des Spiels)
    local bPlan = UI:Button(frame, "", 20, 20, function() LP.Planner:Replan(true) end, L["Route neu planen"])
    bPlan:SetPoint("TOPRIGHT", -6, -46)
    local ptex = bPlan:CreateTexture(nil, "OVERLAY")
    ptex:SetSize(16, 16)
    ptex:SetPoint("CENTER")
    ptex:SetTexture("Interface\\Buttons\\UI-RotationRight-Button-Up")
    ptex:SetTexCoord(0.2, 0.8, 0.2, 0.8)
    local bSkip = UI:Button(frame, L["Überspringen"], 82, 20, function() LP.Engine:Skip() end, L["Aktuellen Schritt überspringen (Quest wird ignoriert)"])
    bSkip:SetPoint("RIGHT", bPlan, "LEFT", -3, 0)
    local bMode = UI:Button(frame, L["Normal"], 70, 20, function() LP.Planner:ToggleMode() end,
        L["Umschalten: Normal (alle passenden Quests) / Speedrun (nur Quests, die mehr bringen als Grinden – Klassenquests bleiben)"])
    bMode:SetPoint("RIGHT", bSkip, "LEFT", -3, 0)
    frame.bMode = bMode

    -- EP-Balken
    local xbg = frame:CreateTexture(nil, "ARTWORK")
    xbg:SetTexture(WHITE)
    xbg:SetVertexColor(1, 1, 1, 0.07)
    xbg:SetHeight(4)
    xbg:SetPoint("TOPLEFT", 10, -84)
    xbg:SetPoint("TOPRIGHT", -10, -84)
    local xfill = frame:CreateTexture(nil, "OVERLAY")
    xfill:SetHeight(4)
    xfill:SetPoint("TOPLEFT", xbg, "TOPLEFT")
    UI:Gradient(xfill)
    local xtext = UI:Text(frame, 9, C.muted)
    xtext:SetPoint("TOPLEFT", 10, -70)
    xtext:SetJustifyH("LEFT")
    if xtext.SetWordWrap then xtext:SetWordWrap(true) end
    frame.xbg, frame.xfill, frame.xtext = xbg, xfill, xtext

    local body = CreateFrame("Frame", nil, frame)
    body:SetPoint("TOPLEFT", 6, -HEADER)
    body:SetPoint("TOPRIGHT", -6, -HEADER)
    body:SetHeight(1)
    frame.body = body

    CreateStatus()
    EnsureRows()
    self:CreateSizeGrip()
    ApplyWidth()
    -- Strg + Mausrad: Gesamtgroesse (inkl. Schrift)
    frame:EnableMouseWheel(true)
    frame:SetScript("OnMouseWheel", function(_, delta)
        if not IsControlKeyDown() then return end
        local s = (LP.db.scale or 1) + delta * 0.05
        LP.db.scale = math.floor(math.max(0.6, math.min(1.6, s)) * 100 + 0.5) / 100
        UI:ApplySettings()
    end)
    self:CreateMinimapButton()
    self:CreateToasts()
    if LP.char.hidden then frame:Hide() end

    LP:Listen("PLAN_CHANGED", function() UI:Refresh() end)
    LP:Listen("TIMER_CHANGED", function() LP:Throttle("ui_timer", 2, function() UI:Refresh() end) end)
    LP:Listen("GROUP_CHANGED", function() LP:Throttle("ui_group", 1, function() UI:Refresh() end) end)
    LP:Listen("HINTS_CHANGED", function() UI:Refresh() end)
    LP:On("PLAYER_XP_UPDATE", function() UI:Refresh() end)
    C_Timer.NewTicker(1, function() UI:Refresh() end)
end

function UI:Toggle()
    if not frame then return end
    if frame:IsShown() then
        frame:Hide()
        LP.char.hidden = true
    else
        frame:Show()
        LP.char.hidden = false
        UI:Refresh()
    end
    if LP.Actions then LP.Actions:Update() end
end

function UI:IsShown()
    return frame and frame:IsShown() or false
end

------------------------------------------------------------------------
-- Groesse per Ziehgriff (unten rechts)
------------------------------------------------------------------------
function UI:CreateSizeGrip()
    local g = CreateFrame("Button", nil, frame)
    g:SetSize(16, 16)
    g:SetPoint("BOTTOMRIGHT", -2, 2)
    g:SetFrameLevel(frame:GetFrameLevel() + 10)
    g:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    g:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    g:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    g:RegisterForClicks("LeftButtonUp")
    g:SetScript("OnMouseDown", function(_, btn)
        if btn ~= "LeftButton" or LP.db.locked then return end
        sizing = true
        EnsureRows()
        frame:StartSizing("BOTTOMRIGHT")
    end)
    g:SetScript("OnMouseUp", function()
        if not sizing then return end
        frame:StopMovingOrSizing()
        sizing = false
        LP.db.frameW = math.floor(frame:GetWidth() + 0.5)
        if not LP.char.collapsed then LP.db.frameH = math.floor(frame:GetHeight() + 0.5) end
        local p, _, rp, x, y = frame:GetPoint()
        LP.db.framePos = { p, rp, x, y }
        EnsureRows()
        ApplyWidth()
        UI:Refresh()
    end)
    g:SetScript("OnDoubleClick", function()
        LP.db.frameW, LP.db.frameH = nil, nil
        EnsureRows()
        ApplyWidth()
        UI:Refresh()
        LP:Print(L["Fenstergrösse zurückgesetzt (automatische Höhe)."])
    end)
    g:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT")
        GameTooltip:AddLine(L["Grösse ändern"], 1, 1, 1)
        GameTooltip:AddLine(L["Ziehen: Breite und Höhe"], 0.7, 0.7, 0.75)
        GameTooltip:AddLine(L["Doppelklick: automatische Grösse"], 0.7, 0.7, 0.75)
        GameTooltip:AddLine(L["Strg + Mausrad über dem Fenster: alles grösser/kleiner"], 0.7, 0.7, 0.75)
        GameTooltip:Show()
    end)
    g:SetScript("OnLeave", function() GameTooltip:Hide() end)
    frame:SetScript("OnSizeChanged", function()
        if sizing then
            LP.db.frameW = math.floor(frame:GetWidth() + 0.5)
            ApplyWidth()
            UI:Refresh()
        end
    end)
    frame.grip = g
end

function UI:ApplySettings()
    if not frame then return end
    frame:SetScale(LP.db.scale or 1)
    EnsureRows()
    ApplyWidth()
    if UI.mmButton then UI.mmButton:SetShown(LP.db.showMinimapBtn and true or false) end
    UI:Refresh()
    if LP.Nav then LP.Nav:Refresh() end
end

local function StatusText()
    local A = LP.Advisor
    if not A then return "" end
    local parts = {}
    if A.durability then
        local c = A.durability <= 10 and "ff4d4d" or (A.durability <= LP.db.durWarn and "ff8c33" or "9c9ea6")
        parts[#parts + 1] = "|cff" .. c .. L["Haltbarkeit "] .. math.floor(A.durability) .. "%|r"
    end
    if A.bagFree then
        local c = A.bagFree <= LP.db.bagWarn and "ff8c33" or "9c9ea6"
        parts[#parts + 1] = "|cff" .. c .. L["Taschen "] .. A.bagFree .. "/" .. (A.bagTotal or 0) .. L[" frei|r"]
    end
    if A.ammo then
        local c = A.ammo <= LP.db.ammoWarn and "ff8c33" or "9c9ea6"
        parts[#parts + 1] = "|cff" .. c .. L["Munition "] .. A.ammo .. "|r"
    end
    local n = #(A.hints or {})
    if n > 0 then parts[#parts + 1] = "|cffffb238" .. n .. (n > 1 and L[" Hinweise"] or L[" Hinweis"]) .. "|r" end
    local extra = LP.Session and LP.Session:ExtraText()
    if extra then parts[#parts + 1] = "|cff9c9ea6" .. extra .. "|r" end
    return table.concat(parts, "   ")
end

function UI:Refresh()
    if not frame or not frame:IsShown() then return end
    local level = UnitLevel("player") or 1
    local focus = LP.Planner.focus
    local st = LP.Planner.state
    local title
    if st == "error" then title = L["|cffff5555Fehler bei der Planung|r"]
    elseif st == "nodata" then title = L["|cffff8c33Keine Questdaten|r"]
    elseif st == "noposition" then title = L["|cffff8c33Position unbekannt|r"]
    elseif focus then title = LP.Geo:MapName(focus)
    elseif st == "noquests" then title = LP.Geo:MapName(select(4, LP.Geo:Player()))
    else title = L["Route wird geplant …"] end
    frame.title:SetText(title)
    if LP.Planner:IsSpeed() then
        frame.bMode.label:SetText(L["|cffff7a3cSpeedrun|r"])
    else
        frame.bMode.label:SetText(L["Normal"])
    end

    local xp, xpMax = UnitXP("player") or 0, UnitXPMax("player") or 1
    local pct = xpMax > 0 and xp / xpMax or 0
    frame.xfill:SetWidth(math.max(0.1, frame.xbg:GetWidth() * pct))
    local active, ready = 0, 0
    for _, st in pairs(LP.Planner.inLog) do
        active = active + 1
        if st.complete then ready = ready + 1 end
    end
    local timer = LP.Comfort and LP.Comfort:TimerText()
    frame.xtext:SetText(L["Level "] .. level .. "  ·  " .. math.floor(pct * 100) .. L["% EP  ·  Questlog "]
        .. active .. "/" .. LP.API.MaxQuests() .. (ready > 0 and (L["  |cff3dd694("] .. ready .. L[" fertig)|r"]) or "")
        .. (timer and ("  ·  " .. timer) or ""))

    frame.status.text:SetText(StatusText())
    Layout()

    local steps = LP.Engine:Steps()
    local n = RowCount()
    local fixedH = sizing and frame:GetHeight() or ManualHeight()
    local room = fixedH and (fixedH - HEADER - STATUS - 8) or nil
    local used = 0
    for i = 1, n do
        local r = rows[i]
        local s = steps[i]
        if s then
            r.step = s
            r.icon:SetTexture(ICONS[s.t] or ICONS.NOTE)
            if LP.db.compactMode then
                -- eine Zeile: Schritt und Entfernung
                local line = (UI:StepText(s, false):match("^[^\n]*") or "")
                local d = LP.Nav and LP.Nav.RemainingDistance and LP.Nav:RemainingDistance()
                r.text:SetText(line .. (d and ("  |cff9c9ea6" .. LP:FormatDist(d) .. "|r") or ""))
            else
                r.text:SetText(UI:StepText(s, i == 1))
            end
            if i == 1 then
                r:SetBackdropColor(C.rowCur[1], C.rowCur[2], C.rowCur[3], C.rowCur[4])
                r.bar:SetVertexColor(C.accent[1], C.accent[2], C.accent[3], 1)
                r:SetAlpha(1)
            else
                r:SetBackdropColor(C.row[1], C.row[2], C.row[3], C.row[4])
                r.bar:SetVertexColor(C.accent2[1], C.accent2[2], C.accent2[3], 0.35)
                r:SetAlpha(math.max(0.5, 1 - (i - 1) * 0.12))
            end
            r:SetHeight(math.max(MIN_ROW, r.text:GetStringHeight() + 14))
        elseif room and i > 1 then
            r.step = nil
            r:SetHeight(MIN_ROW)
        else
            r.step = nil
            r.icon:SetTexture(nil)
            r.bar:SetVertexColor(0, 0, 0, 0)
            r:SetBackdropColor(C.row[1], C.row[2], C.row[3], 0.35)
            r.text:SetText(i == 1 and L["Keine Schritte geplant."] or "")
            r:SetHeight(MIN_ROW)
        end
    end
    -- feste Hoehe: nur Zeilen zeigen, die vollstaendig hineinpassen
    if room then
        for i = 1, n do
            local r = rows[i]
            local need = r:GetHeight() + GAP
            if r.step and used + need <= room or i == 1 then
                r:Show()
                used = used + need
            else
                r:Hide()
                room = -1   -- alle folgenden ausblenden
            end
        end
        if not sizing then frame:SetHeight(math.max(MIN_H, fixedH)) end
    else
        local h = HEADER + STATUS + 8
        for i = 1, n do h = h + rows[i]:GetHeight() + GAP end
        frame:SetHeight(h)
    end
end

------------------------------------------------------------------------
-- Hinweis-Einblendungen (Toasts)
------------------------------------------------------------------------
local toasts = {}
local TOAST_MAX = 3

function UI:CreateToasts()
    local anchor = CreateFrame("Frame", "LevelPilotToasts", UIParent)
    anchor:SetSize(320, 10)
    anchor:SetPoint("TOP", UIParent, "TOP", 0, -260)
    self.toastAnchor = anchor
end

local function LayoutToasts()
    local y = 0
    for _, t in ipairs(toasts) do
        t:ClearAllPoints()
        t:SetPoint("TOP", UI.toastAnchor, "TOP", 0, -y)
        y = y + t:GetHeight() + 6
    end
end

local function RemoveToast(t)
    for i, x in ipairs(toasts) do
        if x == t then table.remove(toasts, i) break end
    end
    t:Hide()
    -- Einblendungen werden nicht wiederverwendet: Texte nicht mehr beim Sprachwechsel mitfuehren
    if rawget(t, "txt") then UI.texts[t.txt] = nil end
    LayoutToasts()
end

-- alle Einblendungen schliessen (z. B. nach einem Sprachwechsel – sie stehen noch in der alten Sprache)
function UI:ClearToasts()
    while #toasts > 0 do RemoveToast(toasts[1]) end
end

function UI:Toast(hint)
    if not self.toastAnchor then return end
    if #toasts >= TOAST_MAX then RemoveToast(toasts[1]) end
    local t = CreateFrame("Button", nil, self.toastAnchor, BACKDROP_TEMPLATE)
    t:SetWidth(320)
    UI:Skin(t, C.panel, hint.sev == 3 and C.bad or (hint.sev == 2 and C.warn or C.border))
    local txt = UI:Text(t, 11, C.text)
    t.txt = txt
    txt:SetPoint("TOPLEFT", 10, -8)
    txt:SetWidth(hint.action and 220 or 290)
    txt:SetText(hint.text)
    local h = math.max(34, txt:GetStringHeight() + 16)
    t:SetHeight(h)
    if hint.action then
        local b = UI:Button(t, hint.actionLabel or L["Los"], 76, 22, function()
            hint.action()
            RemoveToast(t)
        end)
        b:SetPoint("RIGHT", -8, 0)
    end
    t:SetScript("OnClick", function() RemoveToast(t) end)
    toasts[#toasts + 1] = t
    LayoutToasts()
    t:Show()
    PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON or 856)
    C_Timer.After(hint.sev == 3 and 25 or 12, function() if t:IsShown() then RemoveToast(t) end end)
end

------------------------------------------------------------------------
-- Minimap-Button
------------------------------------------------------------------------
function UI:CreateMinimapButton()
    local b = CreateFrame("Button", "LevelPilotMinimapButton", Minimap)
    b:SetSize(31, 31)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    local icon = b:CreateTexture(nil, "BACKGROUND")
    icon:SetTexture("Interface\\Icons\\INV_Misc_Spyglass_02")
    icon:SetSize(20, 20)
    icon:SetPoint("TOPLEFT", 7, -5)
    icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    local border = b:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT")

    local function Place()
        local a = math.rad(LP.db.minimapAngle or 200)
        local r = (Minimap:GetWidth() / 2) + 10
        b:ClearAllPoints()
        b:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
    end
    Place()
    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local s = Minimap:GetEffectiveScale()
            LP.db.minimapAngle = math.deg(math.atan2(cy / s - my, cx / s - mx))
            Place()
        end)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    b:SetScript("OnClick", function(_, btn)
        if btn == "RightButton" then LP.Center:Toggle() else UI:Toggle() end
    end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("|cffffb238Level|r|cff3dd694Pilot|r")
        if LP.Planner.focus then GameTooltip:AddLine(L["Zone: "] .. LP.Geo:MapName(LP.Planner.focus), 1, 1, 1) end
        GameTooltip:AddLine(L["Linksklick: Guide ein/aus"], 0.7, 0.7, 0.75)
        GameTooltip:AddLine(L["Rechtsklick: Zentrale"], 0.7, 0.7, 0.75)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    UI.mmButton = b
    if not LP.db.showMinimapBtn then b:Hide() end
end

------------------------------------------------------------------------
-- Sprachwechsel ohne /reload: feste Beschriftungen von der alten in die neue Sprache uebersetzen.
-- Texte, die sich laufend aendern (Schritte, Status, Werte), schreibt die naechste Aktualisierung neu.
------------------------------------------------------------------------
-- Zuordnung Text -> deutscher Schluessel fuer eine Sprache. Bei Mehrdeutigkeit (zwei deutsche Texte
-- heissen in der anderen Sprache gleich) gewinnt ein Text, den die Oberflaeche wirklich benutzt.
local function ReverseMap(lang)
    local rev = {}
    local keys = {}
    for k in pairs(LP.Locales.en or {}) do keys[k] = true end
    for _, t in pairs(LP.Locales) do
        if type(t) == "table" then for k in pairs(t) do keys[k] = true end end
    end
    for pass = 1, 2 do
        for k in pairs(keys) do
            if (pass == 1) == (LP.usedKeys[k] == true) then
                local v = LP.LocaleLookup(lang, k)
                if type(v) == "string" and v ~= "" and rev[v] == nil then rev[v] = k end
                local v2 = type(v) == "string" and v:gsub("·", "-")
                if v2 and v2 ~= v and rev[v2] == nil then rev[v2] = k end
            end
        end
    end
    for k in pairs(keys) do if rev[k] == nil and lang == "de" then rev[k] = k end end
    return rev
end

-- Text in Bausteine zerlegen: { {k = Schluessel} | {raw = fester Text} }
local function Segments(rev, prefixes, text)
    if type(text) ~= "string" or text == "" then return nil end
    if rev[text] then return { { k = rev[text] } } end
    if text:find("\n", 1, true) then
        local segs, any, rest = {}, false, text
        while rest ~= "" do
            local line, nl = rest:match("^([^\n]*)(\n?)")
            if rev[line .. nl] and nl ~= "" then
                segs[#segs + 1] = { k = rev[line .. nl] } any = true
            elseif line ~= "" and rev[line] then
                segs[#segs + 1] = { k = rev[line] } any = true
                if nl ~= "" then segs[#segs + 1] = { raw = nl } end
            else
                segs[#segs + 1] = { raw = line .. nl }
            end
            if #line + #nl == 0 then break end
            rest = rest:sub(#line + #nl + 1)
        end
        if any then return segs end
    end
    for _, p in ipairs(prefixes) do
        if #text > #p.v and text:sub(1, #p.v) == p.v then return { { k = p.k }, { raw = text:sub(#p.v + 1) } } end
    end
    return nil
end

local function Render(segs, lang)
    local out = {}
    for _, sg in ipairs(segs) do out[#out + 1] = sg.k and LP.LocaleLookup(lang, sg.k) or sg.raw end
    return table.concat(out)
end
UI.RenderSegments = Render

-- Bausteine eines Texts: gemerkte, solange der Text unveraendert ist, sonst neu bestimmen
local function SegsFor(holder, field, text, oldLang, getRev)
    local segs = rawget(holder, field)
    if type(segs) == "table" then
        local r = Render(segs, oldLang)
        if r == text or r:gsub("·", "-") == text then return segs end
    end
    local rev, prefixes = getRev()
    segs = Segments(rev, prefixes, text)
    rawset(holder, field, segs)
    return segs
end

function UI:Relabel(oldLang)
    local rev, prefixes
    local function getRev()
        if not rev then
            rev = ReverseMap(oldLang)
            prefixes = {}
            for v, k in pairs(rev) do if #v >= 6 then prefixes[#prefixes + 1] = { v = v, k = k } end end
            table.sort(prefixes, function(a, b) return #a.v > #b.v end)
        end
        return rev, prefixes
    end
    local newLang = LP:Language()
    local n = 0
    for fs in pairs(UI.texts) do
        if fs.GetText then
            local text = fs:GetText()
            local segs = text and text ~= "" and SegsFor(fs, "_lpSegs", text, oldLang, getRev)
            if segs then
                local new = Render(segs, newLang)
                if new ~= text then fs:SetText(new) n = n + 1 end
            end
            -- Schrift der neuen Sprache (Kyrillisch, Koreanisch, Chinesisch)
            if fs.GetFont and fs.SetFont then
                local _, size, flags = fs:GetFont()
                pcall(fs.SetFont, fs, LP.FONT, size or 12, flags or "")
            end
        end
    end
    for b in pairs(UI.buttons) do
        UI.FitLabel(b)
        if type(rawget(b, "tip")) == "string" and not rawget(b, "tipFn") then
            local segs = SegsFor(b, "_lpTipSegs", b.tip, oldLang, getRev)
            if segs then b.tip = Render(segs, newLang) end
        end
    end
    return n
end

