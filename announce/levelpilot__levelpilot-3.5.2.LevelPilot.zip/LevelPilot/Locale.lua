-- LevelPilot - Sprache
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Texte stehen im Code auf Deutsch und werden mit L["..."] (oder L("...", werte...)) abgefragt.
-- Fuer jede Sprache der WoW-Clients gibt es eine Uebersetzungsdatei (Locale_xxXX.lua). Fehlt
-- dort ein Eintrag, gilt: Spanisch (Lateinamerika) -> Spanisch (Europa) -> Englisch -> Deutsch.
-- Sprache: automatisch nach Spielsprache oder fest in der Zentrale (wirkt nach /reload ganz).

local _, LP = ...

LP.LocaleEN = LP.LocaleEN or {}
LP.Locales = LP.Locales or {}
LP.Locales.en = LP.LocaleEN

-- Alle Sprachen der WoW-Clients: Kuerzel, Client-Locale(s), Name in der eigenen Sprache, Schrift
LP.LANGUAGES = {
    { code = "de", locales = { "deDE" },         name = "Deutsch" },
    { code = "en", locales = { "enUS", "enGB" }, name = "English" },
    { code = "fr", locales = { "frFR" },         name = "Français" },
    { code = "es", locales = { "esES" },         name = "Español (EU)" },
    { code = "mx", locales = { "esMX" },         name = "Español (AL)", fallback = "es" },
    { code = "pt", locales = { "ptBR", "ptPT" }, name = "Português" },
    { code = "it", locales = { "itIT" },         name = "Italiano" },
    { code = "ru", locales = { "ruRU" },         name = "Русский",  font = "Fonts\\FRIZQT___CYR.TTF" },
    { code = "ko", locales = { "koKR" },         name = "한국어",     font = "Fonts\\2002.TTF" },
    { code = "cn", locales = { "zhCN" },         name = "简体中文",   font = "Fonts\\ARKai_T.ttf" },
    { code = "tw", locales = { "zhTW" },         name = "繁體中文",   font = "Fonts\\bLEI00D.ttf" },
}
local BY_CODE, BY_LOCALE = {}, {}
for _, l in ipairs(LP.LANGUAGES) do
    BY_CODE[l.code] = l
    for _, loc in ipairs(l.locales) do BY_LOCALE[loc] = l.code end
    LP.Locales[l.code] = LP.Locales[l.code] or (l.code ~= "de" and {} or nil)
end
LP.LanguageInfo = BY_CODE

-- Sprache des Spielclients (als Kuerzel)
function LP:ClientLanguage()
    local loc = GetLocale and GetLocale() or "enUS"
    return BY_LOCALE[loc] or "en"
end

-- eingestellte Sprache ("auto" = Spielsprache)
function LP:Language()
    local s = LevelPilotDB and LevelPilotDB.language
    if s and BY_CODE[s] then return s end
    return self:ClientLanguage()
end

-- Text in einer bestimmten Sprache
local function Lookup(lang, k)
    if lang == "de" then return k end
    local t = LP.Locales[lang]
    local v = t and t[k]
    if v then return v end
    local fb = BY_CODE[lang] and BY_CODE[lang].fallback
    if fb then
        v = LP.Locales[fb] and LP.Locales[fb][k]
        if v then return v end
    end
    return LP.LocaleEN[k] or k
end
LP.LocaleLookup = Lookup

local cached
local function Lang()
    if cached then return cached end
    local l = LP:Language()
    if LevelPilotDB then cached = l end      -- erst nach dem Laden der Einstellungen festhalten
    return l
end
function LP:ResetLanguageCache() cached = nil end

-- welche Texte die Oberflaeche wirklich benutzt (fuer eindeutiges Umbeschriften beim Sprachwechsel)
LP.usedKeys = {}
LP.L = setmetatable({}, {
    __index = function(_, k)
        if type(k) == "string" then LP.usedKeys[k] = true end
        return Lookup(Lang(), k)
    end,
    __call = function(t, k, ...)
        local s = t[k]
        if select("#", ...) > 0 then return s:format(...) end
        return s
    end,
})

------------------------------------------------------------------------
-- Schrift: kyrillische und asiatische Zeichen brauchen eine passende Schrift.
-- Spricht man die Sprache des Clients, nimmt LevelPilot dessen Standardschrift (immer vorhanden).
------------------------------------------------------------------------
local fontOK = {}
local testString

function LP:FontWorks(path)
    if fontOK[path] ~= nil then return fontOK[path] end
    local ok = false
    if CreateFrame and UIParent then
        if not testString then
            local f = CreateFrame("Frame", nil, UIParent)
            f:Hide()
            testString = f:CreateFontString(nil, "OVERLAY")
        end
        local done = pcall(testString.SetFont, testString, path, 12, "")
        local got = done and testString.GetFont and testString:GetFont()
        ok = type(got) == "string" and got:lower():gsub("/", "\\") == path:lower():gsub("/", "\\")
    end
    fontOK[path] = ok
    return ok
end

local LATIN = "Fonts\\FRIZQT__.TTF"

-- Schrift fuer eine Sprache; zweiter Rueckgabewert false = passende Schrift fehlt vermutlich
function LP:FontFor(code)
    local client = self:ClientLanguage()
    local std = STANDARD_TEXT_FONT or LATIN
    local info = BY_CODE[code or ""] or BY_CODE[client]
    if info and info.font then
        -- Kyrillisch/Asiatisch: auf dem eigenen Client dessen Standardschrift, sonst die Schrift der Sprache
        if info.code == client then return std, true end
        if self:FontWorks(info.font) then return info.font, true end
        return std, false
    end
    -- lateinische Sprachen (mit Umlauten und Akzenten): FRIZQT, falls vorhanden, sonst Standardschrift
    if self:FontWorks(LATIN) then return LATIN, true end
    return std, true
end

-- Schrift fuer die eingestellte Sprache (vor dem Aufbau der Fenster gesetzt)
function LP:ApplyFont()
    local path, ok = self:FontFor(self:Language())
    self.FONT = path
    -- die kyrillische Schrift hat keinen Mittelpunkt "·" (wuerde als Kaestchen erscheinen)
    self.fontLacksDot = (self:Language() == "ru")
    return ok
end

-- Text an die Schrift anpassen: fehlende Zeichen ersetzen
function LP:FixText(t)
    if self.fontLacksDot and type(t) == "string" and t:find("·", 1, true) then
        t = t:gsub("·", "-")
    end
    return t
end

-- Schriftzeile von LevelPilot: Schrift der Sprache, fehlende Zeichen ersetzt, beim Sprachwechsel umgestellt
function LP:RegisterText(fs)
    if not fs or rawget(fs, "_lpWrapped") then return fs end
    rawset(fs, "_lpWrapped", true)
    local set = fs.SetText
    fs.SetText = function(self, t, ...) return set(self, LP:FixText(t), ...) end
    if LP.UI and LP.UI.texts then LP.UI.texts[fs] = true end
    return fs
end
