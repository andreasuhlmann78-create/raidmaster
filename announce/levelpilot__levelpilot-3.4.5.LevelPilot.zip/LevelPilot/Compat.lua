-- LevelPilot - Kompatibilitaet
-- WoW Forever nutzt die moderne Schnittstelle (C_QuestLog, C_Item, C_Container),
-- Classic Era die alten globalen Funktionen. Alle Module greifen nur hierueber zu.

local _, LP = ...
local API = {}
LP.API = API

local hasQuestLogInfo = C_QuestLog and C_QuestLog.GetInfo and true or false
API.modern = hasQuestLogInfo

------------------------------------------------------------------------
-- Questlog
------------------------------------------------------------------------
-- Anzahl Eintraege (inklusive Ueberschriften)
function API.NumEntries()
    if C_QuestLog and C_QuestLog.GetNumQuestLogEntries then
        return C_QuestLog.GetNumQuestLogEntries() or 0
    elseif GetNumQuestLogEntries then
        return GetNumQuestLogEntries() or 0
    end
    return 0
end

-- Eintrag an Position i: title, level, isHeader, complete, failed, questID
function API.Entry(i)
    if not i or i <= 0 then return nil end
    if hasQuestLogInfo then
        local info = C_QuestLog.GetInfo(i)
        if not info then return nil end
        local complete, failed = false, false
        if not info.isHeader and info.questID then
            if C_QuestLog.IsFailed and C_QuestLog.IsFailed(info.questID) then
                failed = true
            elseif C_QuestLog.IsComplete and C_QuestLog.IsComplete(info.questID) then
                complete = true
            end
        end
        return info.title, info.level, info.isHeader and true or false, complete, failed, info.questID
    elseif GetQuestLogTitle then
        local title, level, _, isHeader, _, isComplete, _, questID = GetQuestLogTitle(i)
        if not title then return nil end
        return title, level, isHeader and true or false, isComplete == 1 or isComplete == true, isComplete == -1, questID
    end
    return nil
end

-- Questziele eines Eintrags: { {text=, finished=, have=, need=}, ... }
function API.Objectives(i)
    local out = {}
    if hasQuestLogInfo and C_QuestLog.GetQuestObjectives then
        local info = C_QuestLog.GetInfo(i)
        if not info or info.isHeader or not info.questID then return out end
        for _, o in ipairs(C_QuestLog.GetQuestObjectives(info.questID) or {}) do
            out[#out + 1] = {
                text = o.text, finished = o.finished and true or false,
                have = o.numFulfilled or (o.finished and 1 or 0), need = o.numRequired,
                type = o.type,
            }
        end
        return out
    end
    if GetNumQuestLeaderBoards and GetQuestLogLeaderBoard then
        for o = 1, GetNumQuestLeaderBoards(i) or 0 do
            local text, _, finished = GetQuestLogLeaderBoard(o, i)
            local have, need = nil, nil
            if text then
                have, need = text:match("(%d+)%s*/%s*(%d+)")
                have, need = tonumber(have), tonumber(need)
            end
            out[#out + 1] = { text = text, finished = finished and true or false,
                              have = have or (finished and 1 or 0), need = need }
        end
    end
    return out
end

-- Anzahl Quests im Log (ohne Ueberschriften)
-- Quest-Art aus dem Spiel (Elite, Gruppe, Eskorte, Dungeon ...): Tag-ID oder nil
local tagCache = {}
function API.QuestTag(id)
    if not id then return nil end
    local c = tagCache[id]
    if c ~= nil then return c or nil end
    local tag
    if C_QuestLog and C_QuestLog.GetQuestTagInfo then
        local ok, info = pcall(C_QuestLog.GetQuestTagInfo, id)
        if ok and type(info) == "table" then tag = info.tagID end
    elseif GetQuestTagInfo then
        local ok, t = pcall(GetQuestTagInfo, id)
        if ok then tag = t end
    end
    if tag then tagCache[id] = tag end      -- nil nicht merken: die Abfrage liefert anfangs oft nichts
    return tag
end

-- Groesse des Questlogs: WoW Forever 40, Classic 20 (in den Einstellungen fest einstellbar)
function API.MaxQuests()
    local fixed = LP.db and tonumber(LP.db.questLogMax)
    if fixed and fixed > 0 then return fixed end
    return API.modern and 40 or 20
end

function API.QuestCount()
    local n = 0
    for i = 1, API.NumEntries() do
        local title, _, isHeader = API.Entry(i)
        if title and not isHeader then n = n + 1 end
    end
    return n
end

-- Alle Quests: Liste von { index, title, level, complete, failed, id }
function API.Quests()
    local list = {}
    for i = 1, API.NumEntries() do
        local title, level, isHeader, complete, failed, id = API.Entry(i)
        if title and not isHeader and id and id > 0 then
            list[#list + 1] = { index = i, title = title, level = level, complete = complete, failed = failed, id = id }
        end
    end
    return list
end

function API.LogIndexForQuest(id)
    if not id then return nil end
    if C_QuestLog and C_QuestLog.GetLogIndexForQuestID then
        local idx = C_QuestLog.GetLogIndexForQuestID(id)
        if idx and idx > 0 then return idx end
    end
    for i = 1, API.NumEntries() do
        local _, _, isHeader, _, _, qid = API.Entry(i)
        if not isHeader and qid == id then return i end
    end
    return nil
end

-- QUEST_ACCEPTED: Forever sendet nur die Quest-ID, Classic Logposition + ID
function API.AcceptedArgs(a, b)
    if b and b > 0 then return a, b end          -- Classic: Logposition, Quest-ID
    if a and a > 0 then return API.LogIndexForQuest(a), a end   -- Forever: nur Quest-ID
    return nil, nil
end

function API.IsQuestDone(id)
    if not id then return false end
    if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then
        return C_QuestLog.IsQuestFlaggedCompleted(id) and true or false
    elseif IsQuestFlaggedCompleted then
        return IsQuestFlaggedCompleted(id) and true or false
    end
    return false
end

-- Bereich, in dem Quests noch nicht grau sind
function API.GreenRange(level)
    if C_QuestLog and C_QuestLog.GetTrivialRange then
        local ok, r = pcall(C_QuestLog.GetTrivialRange)
        if ok and type(r) == "number" then return r end
    end
    if GetQuestGreenRange then
        local ok, r = pcall(GetQuestGreenRange, "player")
        if ok and type(r) == "number" then return r end
    end
    if level <= 5 then return 5 end
    if level <= 39 then return math.floor(level / 10) + 5 end
    return math.floor(level / 5) + 1
end

------------------------------------------------------------------------
-- Gegenstaende & Taschen
------------------------------------------------------------------------
function API.ItemInfo(item)
    if not item then return nil end
    if C_Item and C_Item.GetItemInfo then return C_Item.GetItemInfo(item) end
    if GetItemInfo then return GetItemInfo(item) end
    return nil
end

function API.IsEquippable(item)
    if not item then return false end
    if C_Item and C_Item.IsEquippableItem then return C_Item.IsEquippableItem(item) and true or false end
    if IsEquippableItem then return IsEquippableItem(item) and true or false end
    return false
end

function API.Equip(item)
    if C_Item and C_Item.EquipItemByName then return C_Item.EquipItemByName(item) end
    if EquipItemByName then return EquipItemByName(item) end
end

function API.BagSlots(bag)
    if C_Container and C_Container.GetContainerNumSlots then return C_Container.GetContainerNumSlots(bag) or 0 end
    if GetContainerNumSlots then return GetContainerNumSlots(bag) or 0 end
    return 0
end

function API.BagFree(bag)
    local free, family
    if C_Container and C_Container.GetContainerNumFreeSlots then
        free, family = C_Container.GetContainerNumFreeSlots(bag)
    elseif GetContainerNumFreeSlots then
        free, family = GetContainerNumFreeSlots(bag)
    end
    return free or 0, family or 0
end

function API.BagLink(bag, slot)
    if C_Container and C_Container.GetContainerItemLink then return C_Container.GetContainerItemLink(bag, slot) end
    if GetContainerItemLink then return GetContainerItemLink(bag, slot) end
    return nil
end

------------------------------------------------------------------------
-- Talente
------------------------------------------------------------------------
-- Freie Talentpunkte; nil = auf diesem Client nicht feststellbar
function API.TalentPoints()
    if UnitCharacterPoints then
        local ok, p = pcall(UnitCharacterPoints, "player")
        if ok and type(p) == "number" then return p end
    end
    if GetUnspentTalentPoints then
        local ok, p = pcall(GetUnspentTalentPoints)
        if ok and type(p) == "number" then return p end
    end
    return nil
end

------------------------------------------------------------------------
-- Gegenstaende: Anzahl, Abklingzeit, Taschen-Info, Verkaufen
------------------------------------------------------------------------
API.HEARTHSTONE = 6948

function API.ItemCount(id)
    if C_Item and C_Item.GetItemCount then return C_Item.GetItemCount(id) or 0 end
    if GetItemCount then return GetItemCount(id) or 0 end
    return 0
end

-- verbleibende Abklingzeit in Sekunden (0 = bereit)
function API.ItemCooldown(id)
    local start, duration
    if C_Container and C_Container.GetItemCooldown then start, duration = C_Container.GetItemCooldown(id)
    elseif GetItemCooldown then start, duration = GetItemCooldown(id) end
    if not start or not duration or duration == 0 then return 0 end
    return math.max(0, start + duration - GetTime())
end

function API.HearthReady()
    return API.ItemCount(API.HEARTHSTONE) > 0 and API.ItemCooldown(API.HEARTHSTONE) <= 0
end

-- Inhalt eines Taschenplatzes: { id, count, quality, link, noValue }
function API.BagItem(bag, slot)
    if C_Container and C_Container.GetContainerItemInfo then
        local info = C_Container.GetContainerItemInfo(bag, slot)
        if not info then return nil end
        return { id = info.itemID, count = info.stackCount, quality = info.quality, link = info.hyperlink, noValue = info.hasNoValue }
    elseif GetContainerItemInfo then
        local _, count, _, quality, _, _, link, _, noValue, id = GetContainerItemInfo(bag, slot)
        if not link then return nil end
        return { id = id, count = count, quality = quality, link = link, noValue = noValue }
    end
    return nil
end

function API.UseBagItem(bag, slot)
    if C_Container and C_Container.UseContainerItem then return C_Container.UseContainerItem(bag, slot) end
    if UseContainerItem then return UseContainerItem(bag, slot) end
end

-- Hat ein Gegenstand eine Benutzen-Wirkung?
function API.ItemSpell(id)
    if C_Item and C_Item.GetItemSpell then return C_Item.GetItemSpell(id) end
    if GetItemSpell then return GetItemSpell(id) end
    return nil
end

-- Verkaufspreis (Kupfer) eines Gegenstands
function API.SellPrice(id)
    local info = { (C_Item and C_Item.GetItemInfo or GetItemInfo)(id) }
    return info[11] or 0
end

------------------------------------------------------------------------
-- Gegenstandswerte und Tooltip (fuer die Upgrade-Bewertung)
------------------------------------------------------------------------
function API.ItemStats(link)
    if not link then return nil end
    local ok, t
    if C_Item and C_Item.GetItemStats then ok, t = pcall(C_Item.GetItemStats, link)
    elseif GetItemStats then ok, t = pcall(GetItemStats, link) end
    if ok and type(t) == "table" then return t end
    return nil
end

-- Tooltipzeilen eines Gegenstands: { {text, r, g, b}, ... }
local scanTip
function API.TooltipLines(link)
    if not link then return nil end
    local lines = {}
    if C_TooltipInfo and C_TooltipInfo.GetHyperlink then
        local ok, data = pcall(C_TooltipInfo.GetHyperlink, link)
        if ok and type(data) == "table" and type(data.lines) == "table" then
            for _, l in ipairs(data.lines) do
                local c = l.leftColor
                lines[#lines + 1] = { l.leftText or "", c and c.r or 1, c and c.g or 1, c and c.b or 1 }
                if l.rightText and l.rightText ~= "" then
                    local rc = l.rightColor
                    lines[#lines + 1] = { l.rightText, rc and rc.r or 1, rc and rc.g or 1, rc and rc.b or 1 }
                end
            end
            return lines
        end
    end
    if not CreateFrame or not GameTooltip then return nil end
    if not scanTip then
        scanTip = CreateFrame("GameTooltip", "LevelPilotScanTip", UIParent, "GameTooltipTemplate")
    end
    scanTip:SetOwner(WorldFrame or UIParent, "ANCHOR_NONE")
    scanTip:ClearLines()
    local ok = pcall(scanTip.SetHyperlink, scanTip, link)
    if not ok then return nil end
    for i = 1, scanTip:NumLines() or 0 do
        for _, side in ipairs({ "Left", "Right" }) do
            local fs = _G["LevelPilotScanTipText" .. side .. i]
            local text = fs and fs:GetText()
            if text and text ~= "" then
                local r, g, b = fs:GetTextColor()
                lines[#lines + 1] = { text, r or 1, g or 1, b or 1 }
            end
        end
    end
    scanTip:Hide()
    return lines
end

-- Kann der Spieler den Gegenstand benutzen? (rote Tooltipzeile = nein; "Klassen: ..." ohne eigene Klasse = nein)
-- liefert true/false, Grund
function API.CanUseItem(link)
    local lines = API.TooltipLines(link)
    if not lines then return true end           -- unbekannt: nicht blockieren
    local myClass = UnitClass and UnitClass("player")
    local classPattern
    if ITEM_CLASSES_ALLOWED then
        local esc = ITEM_CLASSES_ALLOWED:gsub("([%(%)%.%+%-%*%?%[%]%^%$])", "%%%1")
        classPattern = "^" .. esc:gsub("%%s", "(.+)") .. "$"
    end
    for i, l in ipairs(lines) do
        local text = l[1]
        if classPattern and myClass then
            local list = text:match(classPattern)
            if list then
                local found = false
                for c in list:gmatch("[^,]+") do
                    if c:gsub("^%s+", ""):gsub("%s+$", "") == myClass then found = true end
                end
                if not found then return false, "class", list end
            end
        end
        -- rote Zeile (nicht die erste = Name): Waffenart, Ruestungstyp, Level, Beruf oder Klasse passt nicht
        if i > 1 and l[2] > 0.9 and l[3] < 0.2 and l[4] < 0.2 then
            return false, "red", text
        end
    end
    return true
end
