-- LevelPilot - Hinweise: Klasse, Trainer, Reittier, Berufe
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- * Klassenquest-Vorwarnung: Klassenquests der naechsten zwei Level (aus den Questdaten)
-- * Klassen-Erinnerungen: Seelensplitter, Gift auf der Waffe, Begleiter, Waffenmeister
-- * Trainer: Besuch einplanen, wenn der Klassentrainer in der Naehe ist; Kosten der naechsten
--   Level (beim Trainer gelernt, sonst geschaetzt)
-- * Reittier: Gold-Ziel fuer Level 40, danach Weg zum Reitlehrer des eigenen Volkes
-- * Erste Hilfe und Kochen: Trainer in der Naehe, wenn noch nicht gelernt

local _, LP = ...
local L = LP.L
local H = {}
LP:RegisterModule("Hints", H)

local CLASS_EN = { WARRIOR = "Warrior", PALADIN = "Paladin", HUNTER = "Hunter", ROGUE = "Rogue", PRIEST = "Priest",
                   SHAMAN = "Shaman", MAGE = "Mage", WARLOCK = "Warlock", DRUID = "Druid" }
local TRAINER_NEAR = 400       -- Yards: Trainerbesuch einplanen
local PROF_NEAR = 300          -- Yards: Hinweis auf Erste-Hilfe-/Kochtrainer
-- Heimatgebiete der Reitlehrer je Volk (Reittiere des eigenen Volkes)
local RIDING_HOME = {
    Orc = { 1411, 1454 }, Troll = { 1411, 1454 }, Tauren = { 1412, 1456 }, Scourge = { 1420, 1458 },
    Human = { 1429, 1453 }, Dwarf = { 1426, 1455 }, Gnome = { 1426, 1455 }, NightElf = { 1438, 1457 },
}
local SOUL_SHARD, FIRST_AID, COOKING = 6265, 3273, 2550

local function Navigate(v, label, key)
    if not v then return end
    local i, n, w = LP.Geo:ToWorld(v.map, v.x, v.y)
    LP.Planner.priority = { t = "GOTO", map = v.map, x = v.x, y = v.y, inst = i, n = n, w = w,
                            text = label .. ": " .. (v.name or "?"), key = key }
    LP.Planner:Replan()
end

local function Known(spell)
    if IsSpellKnown then return IsSpellKnown(spell) end
    if IsPlayerSpell then return IsPlayerSpell(spell) end
    return true
end

------------------------------------------------------------------------
-- Klassenquest-Vorwarnung
------------------------------------------------------------------------
local upcoming, upcomingLevel = {}, nil

function H:UpcomingClassQuests()
    local level = UnitLevel("player") or 1
    if upcomingLevel == level then return upcoming end
    upcomingLevel = level
    wipe(upcoming)
    local QDB = LP.QuestDB
    for _, id in ipairs(QDB:AllIds()) do
        local info = QDB:QuickInfo(id)
        if info and info.classes and info.classes ~= 0 and LP.Planner.IsClassQuest(info.classes)
           and (info.reqLevel or 0) > level and (info.reqLevel or 0) <= level + 2
           and QDB:FitsPlayer(info) and not LP.API.IsQuestDone(id) then
            local q = QDB:Get(id)
            if q and q.starts and q.starts[1] and not q.itemStart then
                upcoming[#upcoming + 1] = { id = id, name = q.name, level = info.reqLevel, map = q.starts[1][1] }
            end
        end
    end
    table.sort(upcoming, function(a, b) if a.level ~= b.level then return a.level < b.level end return a.id < b.id end)
    while #upcoming > 3 do table.remove(upcoming) end
    return upcoming
end

local function ClassQuestHint(add)
    if not LP.db.hintClassQuests then return end
    for _, q in ipairs(H:UpcomingClassQuests()) do
        add("cq" .. q.id, LP.Advisor.SEV_INFO, L("Ab Level %d: Klassenquest „%s“ (%s)", q.level, q.name or "?", LP.Geo:MapName(q.map)))
    end
end

------------------------------------------------------------------------
-- Klassen-Erinnerungen
------------------------------------------------------------------------
local function ClassReminders(add)
    if not LP.db.hintClass then return end
    local _, class = UnitClass("player")
    local level = UnitLevel("player") or 1
    if class == "WARLOCK" and level >= 10 then
        local n = LP.API.ItemCount(SOUL_SHARD) or 0
        if n < 3 then add("shards", LP.Advisor.SEV_INFO, L("Nur %d Seelensplitter – Gegner mit Seelendieb erledigen.", n)) end
    end
    if class == "ROGUE" and level >= 20 and GetWeaponEnchantInfo and (Known(2842) or Known(8681)) then
        local hasMain = GetWeaponEnchantInfo()
        if not hasMain then add("poison", LP.Advisor.SEV_INFO, L["Kein Gift auf der Waffe – Gift auftragen."]) end
    end
    if class == "HUNTER" and level >= 10 then
        if UnitExists and not UnitExists("pet") then
            add("pet", LP.Advisor.SEV_INFO, L["Kein Begleiter aktiv – Tier rufen oder zähmen."])
        elseif GetPetHappiness then
            local happy = GetPetHappiness()
            if happy == 1 then add("pethappy", LP.Advisor.SEV_WARN, L["Dein Begleiter ist unglücklich – füttern (Tier füttern)."]) end
        end
    end
    if (class == "WARRIOR" or class == "ROGUE" or class == "HUNTER" or class == "PALADIN") and (level == 10 or level == 20)
       and (LP.char.weaponHint or 0) < level then
        local where = LP:PlayerFaction() == "Horde" and L["Orgrimmar, Unterstadt oder Donnerfels"] or L["Sturmwind, Eisenschmiede oder Darnassus"]
        add("weapons", LP.Advisor.SEV_INFO, L("Weitere Waffenarten lernst du beim Waffenmeister in %s.", where), function()
            LP.char.weaponHint = level
            LP.Advisor:Soon()
        end, L["Verstanden"])
    end
end

------------------------------------------------------------------------
-- Trainer: Kosten lernen und vorhersagen, Besuch einplanen
------------------------------------------------------------------------
-- beim Trainer: Kosten aller angezeigten Faehigkeiten je Stufe merken (auch kuenftige)
function H:LearnTrainerCosts()
    if not GetNumTrainerServices or not GetTrainerServiceCost then return end
    local _, class = UnitClass("player")
    LP.db.trainerCosts = LP.db.trainerCosts or {}
    local costs = {}
    for i = 1, GetNumTrainerServices() or 0 do
        local _, _, category = GetTrainerServiceInfo(i)
        if category == "available" or category == "unavailable" then
            local lvl = GetTrainerServiceLevelReq and GetTrainerServiceLevelReq(i) or 0
            local cost = GetTrainerServiceCost(i) or 0
            if lvl and lvl > 0 and cost > 0 then costs[lvl] = (costs[lvl] or 0) + cost end
        end
    end
    if next(costs) then
        local c = LP.db.trainerCosts[class] or {}
        LP.db.trainerCosts[class] = c
        for lvl, cost in pairs(costs) do c[lvl] = cost end
    end
end

-- Kosten fuer ein Level (Kupfer) und ob gelernt oder geschaetzt
function H:TrainerCost(level)
    local _, class = UnitClass("player")
    local c = LP.db.trainerCosts and LP.db.trainerCosts[class]
    if c and c[level] then return c[level], false end
    if level % 2 == 1 and level > 1 then return nil end
    return math.floor(72 * level * level), true          -- Erfahrungswert Classic (ca. 0,7 Gold auf 10, 26 Gold auf 60)
end

local function TrainerHints(add)
    if not LP.db.hintTrainer then return end
    local level = UnitLevel("player") or 1
    -- Kostenvorschau fuer das naechste Trainer-Level
    local nextLvl = level + (level % 2 == 0 and 2 or 1)
    if nextLvl <= 60 then
        local cost, guessed = H:TrainerCost(nextLvl)
        if cost and cost > 0 then
            local money = GetMoney and GetMoney() or 0
            if money < cost then
                add("traincost", LP.Advisor.SEV_INFO, L("Auf Level %d brauchst du %s%s beim Trainer – du hast %s.", nextLvl,
                    guessed and L["ca. "] or "", LP.Session.Money(cost), LP.Session.Money(money)))
            end
        end
    end
    -- Besuch einplanen: neue Faehigkeiten und der Trainer ist nah
    if level >= 2 and level % 2 == 0 and (LP.char.trainerLevel or 0) < level then
        local _, class = UnitClass("player")
        local want = CLASS_EN[class] and (CLASS_EN[class] .. " Trainer")
        local v, d = LP.QuestDB:NearestService("trainer", function(x) return x.sub == want end)
        local key = "PRIO:TRAIN:" .. level
        if v and d and d <= TRAINER_NEAR and not LP.Planner.priority and not LP.char.doneKeys[key] then
            Navigate(v, L["Klassentrainer"], key)
        end
    end
end

------------------------------------------------------------------------
-- Reittier
------------------------------------------------------------------------
local function HasMount()
    local info = C_Item and C_Item.GetItemInfoInstant or GetItemInfoInstant
    for bag = 0, 4 do
        for slot = 1, (LP.API.BagSlots(bag) or 0) do
            local it = LP.API.BagItem(bag, slot)
            if it and it.id and info then
                local classID, sub = select(6, info(it.id)), select(7, info(it.id))
                if classID == 15 and sub == 5 then return true end
            end
        end
    end
    return LP.char.hasMount or false
end
H.HasMount = HasMount

function H:RidingTrainer()
    local _, race = UnitRace("player")
    local home = RIDING_HOME[race]
    local function filter(v)
        if not v.sub or not v.sub:find("Riding") then return false end
        if not home then return true end
        for _, m in ipairs(home) do if v.map == m then return true end end
        return false
    end
    return LP.QuestDB:NearestService("trainer", filter)
end

local function MountHint(add)
    if not LP.db.hintMount then return end
    local level = UnitLevel("player") or 1
    if level < 35 or HasMount() then return end
    local goal = (LP.db.mountGold or 100) * 10000
    local money = GetMoney and GetMoney() or 0
    if money < goal then
        add("mountgold", level >= 40 and LP.Advisor.SEV_WARN or LP.Advisor.SEV_INFO,
            L("Reittier ab Level 40: %s von %s – es fehlen noch %s.", LP.Session.Money(money), LP.Session.Money(goal), LP.Session.Money(goal - money)))
    elseif level >= 40 then
        local v = H:RidingTrainer()
        add("mountgo", LP.Advisor.SEV_WARN, L["Genug Gold für das Reittier – ab zum Reitlehrer!"] ..
            (v and ("\n" .. (v.name or "?") .. ", " .. LP.Geo:MapName(v.map)) or ""),
            v and function() Navigate(v, L["Reitlehrer"], "PRIO:RIDE") end or nil, v and L["Hinführen"] or nil)
    end
end

------------------------------------------------------------------------
-- Erste Hilfe und Kochen
------------------------------------------------------------------------
local function ProfessionHints(add)
    if not LP.db.hintProfessions or (UnitLevel("player") or 1) < 5 then return end
    for _, p in ipairs({ { FIRST_AID, "First Aid Trainer", L["Erste Hilfe"] }, { COOKING, "Cooking Trainer", L["Kochen"] } }) do
        if not Known(p[1]) then
            local v, d = LP.QuestDB:NearestService("trainer", function(x) return x.sub == p[2] end)
            if v and d and d <= PROF_NEAR then
                add("prof" .. p[1], LP.Advisor.SEV_INFO, L("%s kannst du hier lernen: %s (%s)", p[3], v.name or "?", LP:FormatDist(d)),
                    function() Navigate(v, p[3], "PRIO:PROF" .. p[1]) end, L["Hinführen"])
            end
        end
    end
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
function H:Init()
    local A = LP.Advisor
    A:AddProvider(ClassQuestHint)
    A:AddProvider(ClassReminders)
    A:AddProvider(TrainerHints)
    A:AddProvider(MountHint)
    A:AddProvider(ProfessionHints)
    LP:On("TRAINER_SHOW", function()
        C_Timer.After(0.5, function() H:LearnTrainerCosts() end)
        local key = "PRIO:TRAIN:" .. (UnitLevel("player") or 0)
        local p = LP.Planner.priority
        if p and p.key and (p.key:find("^PRIO:TRAIN") or p.key == "PRIO:RIDE" or p.key:find("^PRIO:PROF")) then
            LP.char.doneKeys[key] = true
            LP.Planner.priority = nil
            LP.Planner:Replan()
        end
    end)
    LP:On("PLAYER_LEVEL_UP", function() upcomingLevel = nil end)
    LP:On("COMPANION_LEARNED", function() LP.char.hasMount = true end)
end
