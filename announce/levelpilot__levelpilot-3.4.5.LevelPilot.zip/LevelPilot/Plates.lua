-- LevelPilot - Questfortschritt ueber den Namensplaketten
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Ueber Gegnern, die fuer eine laufende Quest zaehlen, erscheint der Stand aus dem Questlog,
-- z.B. "3/10" (Toeten) oder "2/8" (Gegenstand, den dieser Gegner fallen laesst).
-- Standard: nur die Quest des aktuellen Guide-Schritts; in den Einstellungen auch alle offenen
-- Quests im Log. Voraussetzung im Spiel: Namensplaketten der Gegner sind eingeschaltet (Taste V).
--
-- Zuordnung (in jeder Spielsprache):
--   1) Name des Gegners steht im Questziel ("Ebereber getoetet: 3/10")
--   2) NPC-ID aus den Questdaten: Gegner fuer ein Toeten-Ziel bzw. Gegner, die den gesuchten
--      Gegenstand fallen lassen (der Gegenstandsname kommt vom Spiel, also in der Spielsprache)

local _, LP = ...
local Pl = {}
LP:RegisterModule("Plates", Pl)

local holders = {}            -- [Namensplakette] = Anzeige
local cand = {}               -- Quests fuer die Namensplaketten (Einstellung)
local candAll = {}            -- alle offenen Quests (fuer Tooltips)
local ICON = "Interface\\GossipFrame\\ActiveQuestIcon"

local function NpcId(unit)
    local guid = UnitGUID and UnitGUID(unit)
    if not guid then return nil end
    local kind, _, _, _, _, id = strsplit("-", guid)
    if kind == "Creature" or kind == "Vehicle" then return tonumber(id) end
    return nil
end

local function ItemName(id)
    if not id then return nil end
    if C_Item and C_Item.GetItemNameByID then
        local n = C_Item.GetItemNameByID(id)
        if n then return n end
    end
    if GetItemInfo then return (GetItemInfo(id)) end
    return nil
end

------------------------------------------------------------------------
-- Welche Quests, welche Ziele, welche Gegner
------------------------------------------------------------------------
local function BuildList(cand, all)
    wipe(cand)
    local P = LP.Planner
    local ids = {}
    if all then
        for id, st in pairs(P.inLog or {}) do
            if not st.complete and not st.failed then ids[#ids + 1] = id end
        end
    else
        local step = LP.Engine and LP.Engine:Current()
        if step and step.t == "COMPLETE" and step.id then ids[1] = step.id end
        -- im Dungeon: alle Quests dieser Instanz
        if LP.Engine and LP.Engine:InDungeon() then
            for _, s in ipairs(LP.Engine:Steps()) do
                if s.t == "COMPLETE" and s.id and s.id ~= ids[1] then ids[#ids + 1] = s.id end
            end
        end
    end
    for _, id in ipairs(ids) do
        local st = P.inLog[id]
        if st and st.index then
            local objs = LP.API.Objectives(st.index)
            local q = LP.QuestDB:Get(id)
            local byNpc = {}
            if q then
                -- Toeten-Ziele der Daten der Reihe nach den Toeten-Zielen des Spiels zuordnen
                local kills, items = {}, {}
                for _, o in ipairs(q.objectives or {}) do
                    if o.kind == "kill" and o.ids then kills[#kills + 1] = o
                    elseif o.kind == "item" and o.ids then items[#items + 1] = o end
                end
                local monsterIdx, itemIdx = {}, {}
                for oi, o in ipairs(objs) do
                    if o.type == "monster" then monsterIdx[#monsterIdx + 1] = oi
                    elseif o.type == "item" then itemIdx[#itemIdx + 1] = oi end
                end
                if #monsterIdx == 0 and #itemIdx == 0 then
                    -- aeltere Schnittstelle ohne Art: nur eindeutige Faelle
                    if #kills == #objs and #items == 0 then for oi = 1, #objs do monsterIdx[oi] = oi end end
                    if #items == #objs and #kills == 0 then for oi = 1, #objs do itemIdx[oi] = oi end end
                end
                for k, o in ipairs(kills) do
                    local oi = monsterIdx[k]
                    if oi then for _, nid in ipairs(o.ids) do byNpc[nid] = byNpc[nid] or {} byNpc[nid][oi] = true end end
                end
                for k, o in ipairs(items) do
                    -- Gegenstand ueber seinen Namen im Questziel finden, sonst nach Reihenfolge
                    local oi
                    local name = ItemName(o.item)
                    if name then
                        for i, co in ipairs(objs) do
                            if co.text and co.text:find(name, 1, true) then oi = i break end
                        end
                    end
                    oi = oi or itemIdx[k]
                    if oi then for _, nid in ipairs(o.ids) do byNpc[nid] = byNpc[nid] or {} byNpc[nid][oi] = true end end
                end
            end
            cand[#cand + 1] = { id = id, objs = objs, byNpc = byNpc, title = st.title }
        end
    end
end

local function Build()
    if LP.db.platesQuest then BuildList(cand, LP.db.platesAll) else wipe(cand) end
    BuildList(candAll, true)
end

-- Fortschritt fuer einen Gegner: Liste von { have, need, text, title, id }
-- all = true: alle offenen Quests (Tooltip), sonst die Auswahl fuer die Namensplaketten
function Pl:ForUnit(unit, all)
    if not unit or UnitIsPlayer(unit) then return nil end
    if UnitIsDead and UnitIsDead(unit) then return nil end
    local npc = NpcId(unit)
    local name = UnitName(unit)
    local out
    for _, c in ipairs(all and candAll or cand) do
        local map = npc and c.byNpc[npc]
        for oi, o in ipairs(c.objs) do
            if not o.finished and (o.need or 0) >= 1 then
                local hit = map and map[oi]
                if not hit and name and #name >= 3 and o.text and o.type ~= "item" then
                    hit = o.text:find(name, 1, true) ~= nil
                end
                if hit then
                    out = out or {}
                    out[#out + 1] = { have = o.have or 0, need = o.need or 1, text = o.text, title = c.title, id = c.id }
                end
            end
        end
    end
    return out
end

------------------------------------------------------------------------
-- Anzeige
------------------------------------------------------------------------
local function Holder(plate)
    local h = holders[plate]
    if h then return h end
    h = CreateFrame("Frame", nil, plate)
    h:SetSize(1, 1)
    h:SetPoint("BOTTOM", plate, "TOP", 0, 2)
    h.text = h:CreateFontString(nil, "OVERLAY")
    h.text:SetFont(LP.FONT, 12, "OUTLINE")
    h.text:SetPoint("BOTTOM", h, "BOTTOM", 8, 0)
    h.text:SetTextColor(1, 0.82, 0.29)
    h.icon = h:CreateTexture(nil, "OVERLAY")
    h.icon:SetTexture(ICON)
    h.icon:SetSize(14, 14)
    h.icon:SetPoint("RIGHT", h.text, "LEFT", -2, 0)
    holders[plate] = h
    return h
end

function Pl:UpdateUnit(unit)
    if not C_NamePlate or not C_NamePlate.GetNamePlateForUnit then return end
    local plate = C_NamePlate.GetNamePlateForUnit(unit)
    if not plate then return end
    local list = LP.db.platesQuest and self:ForUnit(unit, false)
    if not list then
        if holders[plate] then holders[plate]:Hide() end
        return
    end
    local parts = {}
    for _, e in ipairs(list) do parts[#parts + 1] = e.have .. "/" .. e.need end
    local h = Holder(plate)
    h.text:SetText(table.concat(parts, "  "))
    h:Show()
end

-- angezeigter Text auf einer Namensplakette (nil = nichts angezeigt)
function Pl:Shown(plate)
    local h = plate and holders[plate]
    if h and h:IsShown() then return h.text:GetText() end
    return nil
end

function Pl:UpdateAll()
    if not C_NamePlate or not C_NamePlate.GetNamePlates then return end
    for _, plate in ipairs(C_NamePlate.GetNamePlates() or {}) do
        local unit = plate.namePlateUnitToken or (plate.UnitFrame and plate.UnitFrame.unit)
        if unit then self:UpdateUnit(unit) elseif holders[plate] then holders[plate]:Hide() end
    end
end

-- alle offenen Questziele: { id, title, text, have, need, finished, type }
function Pl:OpenObjectives()
    local out = {}
    for _, c in ipairs(candAll) do
        for _, o in ipairs(c.objs) do
            out[#out + 1] = { id = c.id, title = c.title, text = o.text, have = o.have, need = o.need,
                              finished = o.finished, type = o.type }
        end
    end
    return out
end

Pl.NpcId = NpcId
Pl.ItemName = ItemName
function Pl:Refresh()
    Build()
    self:UpdateAll()
end

function Pl:Init()
    LP:On("NAME_PLATE_UNIT_ADDED", function(_, unit) Pl:UpdateUnit(unit) end)
    LP:On("NAME_PLATE_UNIT_REMOVED", function(_, unit)
        local plate = C_NamePlate and C_NamePlate.GetNamePlateForUnit and C_NamePlate.GetNamePlateForUnit(unit)
        if plate and holders[plate] then holders[plate]:Hide() end
    end)
    local function soon() LP:Throttle("plates", 0.5, function() Pl:Refresh() end) end
    LP:On("QUEST_LOG_UPDATE", soon)
    LP:On("UNIT_QUEST_LOG_CHANGED", soon)
    LP:On("GET_ITEM_INFO_RECEIVED", soon)
    LP:Listen("PLAN_CHANGED", soon)
    soon()
end
