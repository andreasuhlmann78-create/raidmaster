-- LevelPilot - Gruppe: Quests teilen, Text fuer die Gruppensuche, Mitspieler fuer Elite-Quests
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- * Quests teilen: bietet der Gruppe alle teilbaren Quests aus dem Log an (Mitspieler mit
--   LevelPilot, die eine Quest schon haben, werden uebersprungen)
-- * Gruppensuche: fertiger Text fuer Dungeon-Laeufe und Elite-Quests, wird ins Chatfenster
--   (Suche-nach-Gruppe-Kanal) geschrieben – senden mit Enter
-- * Elite-Partner: LevelPilot-Spieler in derselben Zone mit derselben Elite-Quest finden
--   (Nachricht "E" im Datenkanal: Zone, Level, Elite-Quests; nur wenn eingeschaltet)

local _, LP = ...
local L = LP.L
local So = {}
LP:RegisterModule("Social", So)

local SEND_EVERY = 120        -- Sekunden: eigene Elite-Quests melden
local EXPIRE = 360            -- Sekunden: Meldung gilt so lange
So.partners = {}              -- [Name] = { zone, level, ids = {[id]=true}, t }

------------------------------------------------------------------------
-- Quests teilen
------------------------------------------------------------------------
local function Pushable(id, index)
    if C_QuestLog and C_QuestLog.IsPushableQuest then return C_QuestLog.IsPushableQuest(id) end
    if SelectQuestLogEntry and GetQuestLogPushable then
        SelectQuestLogEntry(index)
        return GetQuestLogPushable()
    end
    return false
end

local function Push(id, index)
    if C_QuestLog and C_QuestLog.SetSelectedQuest then C_QuestLog.SetSelectedQuest(id)
    elseif SelectQuestLogEntry then SelectQuestLogEntry(index) end
    if QuestLogPushQuest then QuestLogPushQuest() end
end

-- Liste der Quests, die geteilt werden: { {id, index, title} }
function So:ShareList()
    local out = {}
    local members = LP.Group and LP.Group:Active() or {}
    for id, st in pairs(LP.Planner.inLog or {}) do
        if st.index and not st.failed then
            local all = #members > 0
            for _, m in ipairs(members) do
                if not (m.m.quests and m.m.quests[id]) then all = false end
            end
            -- nur wenn nicht alle (LevelPilot-)Mitspieler sie schon haben
            if not all and Pushable(id, st.index) then out[#out + 1] = { id = id, index = st.index, title = st.title } end
        end
    end
    table.sort(out, function(a, b) return a.index < b.index end)
    return out
end

function So:ShareQuests()
    if not (IsInGroup and IsInGroup()) then
        LP:Print(L["Du bist in keiner Gruppe."])
        return 0
    end
    local list = self:ShareList()
    if #list == 0 then LP:Print(L["Keine Quest zum Teilen."]) return 0 end
    local i = 0
    local function step()
        i = i + 1
        local e = list[i]
        if not e then return end
        Push(e.id, e.index)
        C_Timer.After(1.2, step)
    end
    step()
    LP:Print(L("Teile %d Quest(s) mit der Gruppe.", #list))
    return #list
end

------------------------------------------------------------------------
-- Text fuer die Gruppensuche
------------------------------------------------------------------------
local GROUP_WORDS = { "LookingForGroup", "SucheNachGruppe", "RechercheDeGroupe", "BuscarGrupo", "CercaGruppo",
                      "ProcurandoGrupo", "ПоискСпутников", "파티찾기", "寻求组队", "尋求組隊" }

function So:GroupChannel()
    if GetChannelList then
        local list = { GetChannelList() }
        for i = 1, #list, 3 do
            local num, name = list[i], list[i + 1]
            for _, w in ipairs(GROUP_WORDS) do
                if type(name) == "string" and name:find(w, 1, true) then return num end
            end
        end
    end
    return nil
end

function So:GroupText(step)
    step = step or (LP.Engine and LP.Engine:Current())
    if not step then return nil end
    local level = UnitLevel("player") or 1
    if step.t == "DUNGEON" and not step.inside then
        local quests = step.quests or {}
        return L("LFM %s – %d Quest(s): %s (L%d)", step.q or "?", #quests, table.concat(quests, ", "), level)
    end
    if step.id then
        local q = LP.QuestDB:Get(step.id)
        if q and q.elite then
            return L("LFG %s (Elite) – L%d", step.q or q.name or "?", level)
        end
    end
    return nil
end

function So:OpenGroupChat(step)
    local text = self:GroupText(step)
    if not text then return nil end
    local ch = self:GroupChannel()
    local line = (ch and ("/" .. ch .. " ") or "") .. text
    if ChatFrame_OpenChat then ChatFrame_OpenChat(line, DEFAULT_CHAT_FRAME) end
    self.lastGroupText = line
    return line
end

local function GroupHint(add)
    if not LP.db.groupFinderText then return end
    local step = LP.Engine and LP.Engine:Current()
    local text = step and So:GroupText(step)
    if not text or (IsInGroup and IsInGroup()) then return end
    add("lfg" .. (step.key or ""), LP.Advisor.SEV_INFO, L["Gruppe gesucht: "] .. text,
        function() So:OpenGroupChat(step) end, L["Text in den Chat"])
end

------------------------------------------------------------------------
-- Elite-Partner ueber den Datenkanal
------------------------------------------------------------------------
function So:MyEliteQuests()
    local out = {}
    for id, st in pairs(LP.Planner.inLog or {}) do
        if not st.complete and not st.failed then
            local q = LP.QuestDB:Get(id)
            if q and q.elite and not q.dungeon then out[#out + 1] = id end
        end
    end
    table.sort(out)
    return out
end

function So:Encode()
    local ids = self:MyEliteQuests()
    if #ids == 0 then return nil end
    local _, _, _, map = LP.Geo:Player()
    return table.concat({ "E", map or 0, UnitLevel("player") or 1, table.concat(ids, ",", 1, math.min(#ids, 10)) }, "\t")
end

function So:Announce()
    if not LP.db.findPartners or not LP.Comm then return end
    local msg = self:Encode()
    if msg then LP.Comm:Broadcast({ msg }) end
end

function So:OnMessage(parts, sender)
    if not LP.db.findPartners then return end
    local name = sender and (sender:match("^([^%-]+)") or sender)
    local zone, level = tonumber(parts[2]), tonumber(parts[3])
    if not name or not zone or not level or level < 1 or level > 63 then return end
    local ids = {}
    for id in (parts[4] or ""):gmatch("%d+") do ids[tonumber(id)] = true end
    self.partners[name] = { zone = zone, level = level, ids = ids, t = GetTime() }
    LP.Advisor:Soon()
end

-- Mitspieler mit derselben Quest: { [questID] = { {name, level}, ... } }
function So:Matches()
    local out = {}
    local _, _, _, map = LP.Geo:Player()
    local level = UnitLevel("player") or 1
    local now = GetTime()
    for _, id in ipairs(self:MyEliteQuests()) do
        for name, p in pairs(self.partners) do
            if now - p.t <= EXPIRE and p.ids[id] and p.zone == map and math.abs(p.level - level) <= 4
               and not (UnitInParty and UnitInParty(name)) then
                out[id] = out[id] or {}
                table.insert(out[id], { name = name, level = p.level })
            end
        end
    end
    return out
end

local function PartnerHint(add)
    if not LP.db.findPartners then return end
    for id, list in pairs(So:Matches()) do
        table.sort(list, function(a, b) return a.name < b.name end)
        local names = {}
        for i = 1, math.min(#list, 4) do names[#names + 1] = list[i].name .. " (L" .. list[i].level .. ")" end
        local st = LP.Planner.inLog[id]
        local first = list[1].name
        add("partner" .. id, LP.Advisor.SEV_INFO,
            L("Auch an „%s“: %s – zusammen spielen?", st and st.title or ("#" .. id), table.concat(names, ", ")),
            function()
                if C_PartyInfo and C_PartyInfo.InviteUnit then C_PartyInfo.InviteUnit(first)
                elseif InviteUnit then InviteUnit(first) end
            end, L("%s einladen", first))
    end
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
function So:Init()
    local A = LP.Advisor
    A:AddProvider(GroupHint)
    A:AddProvider(PartnerHint)
    C_Timer.NewTicker(SEND_EVERY, function() So:Announce() end)
    C_Timer.After(20, function() So:Announce() end)
    LP:Listen("PLAN_CHANGED", function() LP:Throttle("social_announce", 30, function() So:Announce() end) end)
end
