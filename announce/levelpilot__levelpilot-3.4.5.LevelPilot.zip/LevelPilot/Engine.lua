-- LevelPilot - Engine
-- Aktueller Schritt, Erkennung erledigter Schritte, Quest-Automatik

local _, LP = ...
local L = LP.L
local E = {}
LP:RegisterModule("Engine", E)

local REACH = 12          -- Yards: Ziel erreicht (Gehe-zu)

function E:Current()
    return LP.Planner.steps[1]
end

function E:Steps()
    return LP.Planner.steps
end

------------------------------------------------------------------------
-- Schritt ueberspringen
------------------------------------------------------------------------
function E:Skip(step)
    step = step or self:Current()
    if not step then return end
    if step.t == "LEVEL" or step.key == "NODATA" or step.key == "NOPOS" or step.key == "DGIN" then
        LP:Print(L["Dieser Hinweis lässt sich nicht überspringen – es gibt gerade keine passende Quest. Wähle in der Zentrale unter \"Route\" eine andere Zone oder besiege Monster in deinem Level."])
        return
    end
    if step.t == "DUNGEON" and step.area then
        -- Dungeon zurueckstellen: kommt nach ein paar Stufen wieder (oder sofort, wenn man ihn betritt)
        LP.char.dungeonRun[step.area] = UnitLevel("player") or 1
        LP:Print(L["Dungeon zurückgestellt: "] .. (step.q or "?") .. L[" – er wird in 3 Stufen wieder vorgeschlagen."])
    elseif step.id and (step.t == "ACCEPT" or step.t == "COMPLETE" or step.t == "TURNIN") then
        LP.char.ignored[step.id] = true
        LP:Print(L["Quest wird ignoriert: "] .. (step.q or step.id) .. L[" (zurücksetzen in der Zentrale)"])
    else
        LP.char.doneKeys[step.key] = true
        if step == LP.Planner.priority then LP.Planner.priority = nil end
    end
    LP.Planner:Replan()
end

function E:ResetIgnored()
    wipe(LP.char.ignored)
    wipe(LP.char.doneKeys)
    wipe(LP.char.notOffered)
    wipe(LP.char.dungeonRun)
    LP.Planner:Replan(true)
end

------------------------------------------------------------------------
-- Quest-Automatik
------------------------------------------------------------------------
local function Paused()
    return IsShiftKeyDown()
end

local function LogCount()
    return LP.API.QuestCount()
end

-- Soll eine angebotene Quest angenommen werden?
function E:WantQuest(id, title)
    if not id or id == 0 then return false end
    if LP.char.ignored[id] then return false end
    if LogCount() >= LP.API.MaxQuests() then
        LP:Print(L["Questlog voll – erledige oder verwirf zuerst eine Quest."])
        return false
    end
    local q = LP.QuestDB:Get(id)
    local level = UnitLevel("player") or 1
    -- Speedrun: Quests, die der Planer bewusst auslaesst, nicht automatisch annehmen
    if LP.Planner:IsSpeed() and LP.Planner.speedSkip[id] then return false end
    if q then
        if q.repeatable then return false end
        if q.dungeon then
            -- Dungeon-Quests nur, wenn Dungeons eingeplant werden und der Dungeon betretbar ist
            if not LP.Planner:DungeonUsable(q.dungeon) then return false end
            local d = LP.QuestDB:Dungeon(q.dungeon)
            if d and level > d.max then return false end
        end
        if q.level and q.level > 0 and q.level < level - LP.API.GreenRange(level) then
            return false
        end
    end
    -- unbekannte (z.B. neue Forever-)Quests werden angenommen und aufgezeichnet
    return true
end

local function HandleGossip()
    if not C_GossipInfo or not C_GossipInfo.GetActiveQuests then return end
    if LP.db.autoTurnin then
        for _, q in ipairs(C_GossipInfo.GetActiveQuests() or {}) do
            if q.isComplete and not LP.char.ignored[q.questID] then
                C_GossipInfo.SelectActiveQuest(q.questID)
                return
            end
        end
    end
    if LP.db.autoAccept then
        for _, q in ipairs(C_GossipInfo.GetAvailableQuests() or {}) do
            if not q.repeatable and E:WantQuest(q.questID, q.title) then
                C_GossipInfo.SelectAvailableQuest(q.questID)
                return
            end
        end
    end
end

local function HandleGreeting()
    if LP.db.autoTurnin then
        for i = 1, GetNumActiveQuests() do
            local _, isComplete = GetActiveTitle(i)
            if isComplete then SelectActiveQuest(i) return end
        end
    end
    if LP.db.autoAccept and GetNumAvailableQuests() > 0 and LogCount() < LP.API.MaxQuests() then
        -- ohne Quest-ID: die erste Quest oeffnen, die Detailseite entscheidet
        SelectAvailableQuest(1)
    end
end

------------------------------------------------------------------------
-- Erledigt-Erkennung fuer Reise-/Hinweisschritte
------------------------------------------------------------------------
function E:CheckSteps()
    local s = self:Current()
    if not s then return end
    if s.t == "GOTO" and s.inst then
        local pi, pn, pw = LP.Geo:Player()
        if pi == s.inst and LP.Geo:Dist(pn, pw, s.n, s.w) <= REACH then
            LP.char.doneKeys[s.key] = true
            LP.Planner:Replan()
        end
    elseif s.t == "FLY" and UnitOnTaxi("player") then
        LP.char.doneKeys[s.key] = true
        LP.Planner:Replan()
    elseif s.t == "LEVEL" and (UnitLevel("player") or 1) >= (s.lvl or 1) then
        LP.Planner:Replan()
    elseif s.t == "HEARTH" and s.inst then
        local pi, pn, pw = LP.Geo:Player()
        if pi == s.inst and LP.Geo:Dist(pn, pw, s.n, s.w) <= 250 then
            LP.char.doneKeys[s.key] = true
            LP.Planner:Replan()
        end
    end
end

------------------------------------------------------------------------
-- Dungeon betreten / verlassen
------------------------------------------------------------------------
-- Dungeon, in dem der Spieler gerade ist (AreaID, 0 = unbekannte Instanz) oder nil
function E:InDungeon()
    return LP.char.inDungeon or nil
end

function E:UpdateInstance()
    local inside, kind = false, nil
    if IsInInstance then inside, kind = IsInInstance() end
    if inside and (kind == "party" or kind == "raid") then
        local id = GetInstanceInfo and select(8, GetInstanceInfo())
        local area = id and LP.DungeonByInstance[id] or 0
        if LP.char.inDungeon ~= area then
            LP.char.inDungeon = area
            local d = LP.QuestDB:Dungeon(area)
            LP:Print(L["Dungeon betreten: "] .. (d and d.name or (GetInstanceInfo and GetInstanceInfo()) or L["Instanz"]) .. L[" – die Questziele stehen im Guide."])
        end
    elseif LP.char.inDungeon then
        local area = LP.char.inDungeon
        if area ~= 0 then LP.char.dungeonRun[area] = UnitLevel("player") or 1 end
        LP.char.inDungeon = false
        LP:Print(L["Dungeon verlassen – weiter mit den Abgaben."])
    else
        return
    end
    LP.Planner:Replan()
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
function E:Init()
    LP:On("QUEST_DETAIL", function()
        if Paused() or not LP.db.autoAccept then return end
        local id = GetQuestID and GetQuestID()
        if E:WantQuest(id, GetTitleText()) then
            AcceptQuest()
        end
    end)

    LP:On("QUEST_PROGRESS", function()
        if Paused() or not LP.db.autoTurnin then return end
        local id = GetQuestID and GetQuestID()
        if IsQuestCompletable() and not LP.char.ignored[id or 0] then CompleteQuest() end
    end)

    LP:On("QUEST_COMPLETE", function()
        if Paused() or not LP.db.autoTurnin then return end
        local choices = GetNumQuestChoices()
        if choices <= 1 then
            GetQuestReward(choices == 1 and 1 or 0)
        elseif LP.Advisor then
            LP.Advisor:RecommendReward()
        end
    end)

    LP:On("GOSSIP_SHOW", function()
        if not Paused() then HandleGossip() end
    end)

    LP:On("QUEST_GREETING", function()
        if not Paused() then HandleGreeting() end
    end)

    -- Flugkarte geoeffnet: Flugmeister in der Naehe gilt als besucht
    LP:On("TAXIMAP_OPENED", function()
        local s = E:Current()
        if s and s.t == "FP" then
            LP.char.doneKeys[s.key] = true
            LP.char.fpVisited[s.key:sub(4)] = true
        end
        local v, d = LP.QuestDB:NearestService("flight")
        if v and d and d < 40 then LP.char.fpVisited[(v.name or "?") .. ":" .. v.map] = true end
        LP.Planner:Replan()
    end)

    LP:On("PLAYER_ENTERING_WORLD", function() E:UpdateInstance() end)
    LP:On("ZONE_CHANGED_NEW_AREA", function() E:UpdateInstance() end)
    C_Timer.After(1, function() E:UpdateInstance() end)

    C_Timer.NewTicker(0.5, function() E:CheckSteps() end)
end
