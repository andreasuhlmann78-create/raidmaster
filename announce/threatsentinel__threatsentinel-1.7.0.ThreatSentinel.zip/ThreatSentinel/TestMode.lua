-- ThreatSentinel - TestMode.lua
-- Testzentrale: Jede Funktion lässt sich im Spiel einzeln testen, auch solo.
--   Demo          spielt alle Zustände an echten Plaketten und an Vorschau-Plaketten durch,
--                 dazu HUD, Aggrometer und DD-Ansicht mit Beispieldaten
--   Live-Test     echte Logik ohne Gruppe und ohne Tank-Haltung; Begleiter zählen als DD,
--                 so sieht man solo (z. B. mit Jäger- oder Hexer-Begleiter) echte Aggroverluste
--   Meldungen     jede Warnung und jeder Ton einzeln
--   Tank-Sync     ein zweiter Tank ("Grimbar") wird simuliert
--   Diagnose      zeigt live, was das Addon erkennt
-- Chat-Meldungen gehen während Tests nur an dich, nie in den Gruppenchat.

local ADDON, ns = ...
local L = ns.L

local TM = {}
ns.Test = TM
table.insert(ns.modules, TM)

local WHITE = "Interface\\Buttons\\WHITE8X8"
local BACKDROP = BackdropTemplateMixin and "BackdropTemplate" or nil
local ACCENT = { 0.25, 0.65, 1 }
local FAKE_TANK = "Grimbar"

local DEMO = { "HELD", "WARN", "LOOSE_DD", "LOOSE_HEALER", "OTHERTANK", "LOOSE_CLAIMED", "LOOSE_FAR" }
local PHASE_TIME = 4

ns.liveTest = false
ns.fakeNames = {}

------------------------------------------------------------
-- Hilfen
------------------------------------------------------------
function TM:IsTesting()
	return ns.testMode or ns.liveTest or (self.frame and self.frame:IsShown()) or false
end

function TM:Say(msg)
	ns:Print("|cffffd100[Test]|r " .. tostring(msg))
end

local function DeficitText()
	if ns.class == "WARRIOR" then return L.DEFICIT_WARRIOR end
	if ns.class == "DRUID" and not ns.isRetail then return L.DEFICIT_DRUID end
	return L.DEFICIT_OTHER
end

------------------------------------------------------------
-- Vorschau-Plaketten (funktionieren ohne Gegner in der Nähe)
------------------------------------------------------------
local PREVIEW_NAMES = { "Defias-Schläger", "Defias-Magier", "Kobold-Gräber", "Murloc-Jäger", "Gnoll-Wilderer", "Höhlenspinne", "Riesenbussard" }

function TM:CreatePreview()
	if self.preview then return end
	local holder = CreateFrame("Frame", "ThreatSentinelPreview", UIParent)
	holder:SetSize(1, 1)
	holder:SetPoint("TOP", UIParent, "TOP", 0, -150)
	holder:Hide()
	self.preview = { holder = holder, plates = {} }
	local n = #DEMO
	for i = 1, n do
		local uf = CreateFrame("Frame", nil, holder)
		uf:SetSize(120, 34)
		-- zwei Reihen, genug Abstand für vergrösserte (125 %) lose Plaketten
		local perRow = math.ceil(n / 2)
		local row = (i <= perRow) and 0 or 1
		local idx = (row == 0) and i or (i - perRow)
		local count = (row == 0) and perRow or (n - perRow)
		uf:SetPoint("TOP", holder, "TOP", (idx - (count + 1) / 2) * 230, -row * 80)
		local hb = CreateFrame("StatusBar", nil, uf)
		hb:SetSize(110, 10)
		hb:SetPoint("BOTTOM", uf, "BOTTOM", 0, 4)
		hb:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
		hb:SetStatusBarColor(0.85, 0.1, 0.1)
		hb:SetMinMaxValues(0, 100)
		hb:SetValue(100)
		local bg = hb:CreateTexture(nil, "BACKGROUND")
		bg:SetAllPoints()
		bg:SetTexture(WHITE)
		bg:SetVertexColor(0, 0, 0, 0.6)
		uf.healthBar = hb
		uf.name = uf:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		uf.name:SetPoint("BOTTOM", hb, "TOP", 0, 3)
		uf.name:SetText(PREVIEW_NAMES[i] or ("Mob " .. i))
		uf.m = { name = PREVIEW_NAMES[i] }
		uf.hp = 100 - i * 9
		self.preview.plates[i] = uf
	end
end

------------------------------------------------------------
-- Demo-Modus
------------------------------------------------------------
function TM:SetDemo(on)
	if on and ns.liveTest then
		self:SetLive(false)
		ns.Alerts:Center(L.TEST_LIVE_OFF, { 1, 0.8, 0.2 }, 2, "test")
	end
	ns.testMode = on and true or false
	self:CreatePreview()
	if on then
		self.start = GetTime()
		self.preview.holder:Show()
		self:Say(L.TEST_ON)
	else
		for unit, m in pairs(ns.mobs) do
			ns.Plates:Restore(unit)
			m.state, m.testKind, m.alerted = nil, nil, false
		end
		for _, uf in ipairs(self.preview.plates) do ns.Plates:RestoreFrame(uf) end
		self.preview.holder:Hide()
		ns.Alerts:ClearCenter()
		ns.HUD:Update(nil, nil)
		self:Say(L.TEST_OFF)
	end
	self:Refresh()
	if ns.Options and ns.Options.RefreshTestButton then ns.Options:RefreshTestButton() end
end

-- Für Minimap-Rechtsklick und /ts test: öffnet die Testzentrale
function TM:Toggle()
	self:ToggleWindow()
end

local DEMO_MARKS = { [3] = 8, [4] = 7 }   -- Totenkopf und Kreuz auf zwei losen Demo-Mobs

local function FillDemo(m, kind, i, phase, fake)
	m.sunder = (ns.class == "WARRIOR") and ((i + phase) % 6) or 0
	if fake then m.mark = DEMO_MARKS[i] end
	m.claimedBy, m.muted, m.far, m.hint, m.tauntCD = nil, false, false, nil, 0
	m.victim, m.victimRole, m.otherTank = nil, nil, nil
	if kind == "HELD" then
		m.state = "HELD"
	elseif kind == "WARN" then
		m.state = "WARN"
	elseif kind == "OTHERTANK" then
		m.state = "OTHERTANK"
		m.otherTank = FAKE_TANK
	else
		m.state = "LOOSE"
		m.victim, m.victimRole = "Torben", "DAMAGER"
		if kind == "LOOSE_HEALER" then
			m.victim, m.victimRole = "Anna", "HEALER"
			m.hint = L.TAUNT_READY
		elseif kind == "LOOSE_CLAIMED" then
			m.claimedBy = FAKE_TANK
			m.hint = string.format(L.CLAIMED, FAKE_TANK)
		elseif kind == "LOOSE_FAR" then
			m.far = true
			m.hint = L.TOO_FAR
		else
			m.hint = DeficitText()
		end
	end
end

function TM:Tick(mobs)
	local phase = math.floor((GetTime() - (self.start or GetTime())) / PHASE_TIME)
	local loose = {}

	-- echte Plaketten
	local units = {}
	for unit in pairs(mobs) do units[#units + 1] = unit end
	table.sort(units)
	for i, unit in ipairs(units) do
		local m = mobs[unit]
		local kind = DEMO[((i + phase - 1) % #DEMO) + 1]
		m.name = UnitName(unit)
		if m.testKind and m.testKind:find("LOOSE") and kind == "HELD" then ns.Plates:Flash(unit) end
		m.testKind = kind
		FillDemo(m, kind, i, phase)
		ns.Plates:Update(unit, m)
		if m.state == "LOOSE" and not m.claimedBy then loose[#loose + 1] = m end
	end

	-- Vorschau-Plaketten
	if self.preview and ns.db.testPreview then
		self.preview.holder:Show()
		for i, uf in ipairs(self.preview.plates) do
			local kind = DEMO[((i + phase - 1) % #DEMO) + 1]
			local m = uf.m
			if m.testKind and m.testKind:find("LOOSE") and kind == "HELD" then ns.Plates:FlashFrame(uf) end
			m.testKind = kind
			FillDemo(m, kind, i, phase, true)
			uf.hp = uf.hp - 0.6
			if uf.hp < 5 then uf.hp = 100 end
			uf.healthBar:SetValue(uf.hp)
			ns.Plates:Apply(uf, m)
			if m.state == "LOOSE" and not m.claimedBy then loose[#loose + 1] = m end
		end
	elseif self.preview then
		self.preview.holder:Hide()
	end

	local extras = {}
	if #units == 0 and not ns.db.testPreview then
		extras[#extras + 1] = { text = L.TEST_NO_PLATES, c = { 1, 0.8, 0.2 } }
	end
	if ns.db.healerRange then
		extras[#extras + 1] = { text = string.format(L.HEALER_OOR, "Anna"), c = { 1, 0.8, 0.2 } }
	end
	if ns.db.aoeHint and ns.aoeSpell and phase % 3 == 2 then
		ns.Alerts:Center(string.format(L.AOE_HINT, ns.aoeSpell or L.AOE_GENERIC), { 1, 0.5, 0 }, 0.6, "aoe")
	end
	table.sort(loose, ns.Threat.SortLoose)
	ns.HUD:Update(loose, extras)
end

------------------------------------------------------------
-- Live-Test (echte Logik, solo)
------------------------------------------------------------
function TM:SetLive(on)
	if on and ns.testMode then
		self:SetDemo(false)
		ns.Alerts:Center(L.TEST_OFF, { 1, 0.8, 0.2 }, 2, "test")
	end
	ns.liveTest = on and true or false
	ns:ClearRoleCache()
	self:Say(on and L.TEST_LIVE_ON or L.TEST_LIVE_OFF)
	self:Refresh()
end

------------------------------------------------------------
-- Einzelne Meldungen
------------------------------------------------------------
local function TargetName()
	return (UnitExists("target") and UnitName("target")) or L.TEST_TARGET
end

local function FlashAll()
	if TM.preview then
		for _, uf in ipairs(TM.preview.plates) do ns.Plates:FlashFrame(uf) end
	end
	for unit in pairs(ns.mobs) do ns.Plates:Flash(unit) end
end

TM.ACTIONS = {
	{ key = "T_LOOSE_DD", fn = function()
		ns.Alerts:Play(ns.db.soundDD, "testDD" .. GetTime())
		ns.Alerts:Center(string.format(L.ARROW, "Torben", L.DAMAGER), ns.db.colorDD, 1.5, "test")
	end },
	{ key = "T_LOOSE_HEALER", fn = function()
		ns.Alerts:Play(ns.db.soundHealer, "testHealer" .. GetTime())
		ns.Alerts:Center(string.format(L.ARROW, "Anna", L.HEALER), ns.db.colorHealer, 1.5, "test")
	end },
	{ key = "T_REGAIN", fn = function()
		ns.Alerts:Play(ns.db.soundRegain, "testRegain" .. GetTime())
		FlashAll()
	end },
	{ key = "T_RESIST", fn = function()
		ns.Alerts:OnResist(TargetName(), nil, true)
	end },
	{ key = "T_CC", fn = function()
		ns.Alerts:AnnounceCC(L.TEST_STUN, 4, true)
	end },
	{ key = "T_AOE", fn = function()
		ns.Alerts:Center(string.format(L.AOE_HINT, ns.aoeSpell or L.AOE_GENERIC), { 1, 0.5, 0 }, 2, "aoe")
	end },
	{ key = "T_EMERG", fn = function()
		ns.Alerts:Center(string.format(L.EMERGENCY, ns.defensives[1] or L.TEST_DEFENSIVE), { 1, 0.2, 0.2 }, 2, "emerg")
		ns.Alerts:Play(ns.db.soundEmergency, "testEmerg" .. GetTime())
	end },
	{ key = "T_HEALER_OOR", fn = function()
		ns.Alerts:Center(string.format(L.HEALER_OOR, "Anna"), { 1, 0.8, 0.2 }, 2, "test")
	end },
	{ key = "T_DDWARN", fn = function()
		ns.Alerts:Play(ns.db.soundDDWarn, "testDDW" .. GetTime())
		ns.Alerts:Center(string.format(L.DD_THREAT, 95), { 1, 0.15, 0.15 }, 2, "test")
	end },
}

-- Alle Meldungen nacheinander, je 2 Sekunden
function TM:PlayAll()
	if self.playing then return end
	self.playing = true
	for i, a in ipairs(self.ACTIONS) do
		C_Timer.After((i - 1) * 2, function()
			if TM.frame and TM.frame:IsShown() then
				ns.Alerts:ClearCenter()
				TM:Say(string.format("%d/%d: %s", i, #TM.ACTIONS, L[a.key]))
				a.fn()
			end
		end)
	end
	C_Timer.After(#self.ACTIONS * 2, function()
		TM.playing = false
		if ns.Guide and TM.frame and TM.frame:IsShown() then ns.Guide:Signal("allalerts") end
	end)
end

------------------------------------------------------------
-- Tank-Sync simulieren
------------------------------------------------------------
TM.SYNC = {
	{ key = "SY_HELLO", fn = function()
		ns.fakeNames[FAKE_TANK] = true
		ns.Sync:Handle(FAKE_TANK, "H:TANK:" .. ns.version)
		TM:Say(string.format(L.TEST_SYNC_HELLO, FAKE_TANK))
	end },
	{ key = "SY_TAUNT", fn = function()
		ns.fakeNames[FAKE_TANK] = true
		local guid = UnitGUID("target")
		if ns.IsSecret(guid, "guid") then guid = nil end
		ns.Sync:Handle(FAKE_TANK, "T:" .. (guid or "test") .. ":10")
		TM:Say(guid and string.format(L.TEST_SYNC_TAUNT, FAKE_TANK, TargetName()) or L.TEST_SYNC_NOTARGET)
	end },
	{ key = "SY_RESIST", fn = function()
		ns.fakeNames[FAKE_TANK] = true
		ns.Sync:Handle(FAKE_TANK, "R:")
	end },
	{ key = "SY_CC", fn = function()
		ns.fakeNames[FAKE_TANK] = true
		ns.Sync:Handle(FAKE_TANK, "X:" .. L.TEST_STUN)
	end },
	{ key = "SY_REMOVE", fn = function()
		ns.fakeNames[FAKE_TANK] = nil
		ns.syncRoles[FAKE_TANK] = nil
		ns.Sync.cd[FAKE_TANK] = nil
		for guid, c in pairs(ns.Sync.claims) do
			if c.name == FAKE_TANK then ns.Sync.claims[guid] = nil end
		end
		ns:ClearRoleCache()
		TM:Say(string.format(L.TEST_SYNC_REMOVED, FAKE_TANK))
	end },
}

------------------------------------------------------------
-- Diagnose
------------------------------------------------------------
local function YesNo(v)
	return v and ("|cff40ff40" .. L.YES .. "|r") or ("|cffff5050" .. L.NO .. "|r")
end

function TM:DiagText()
	local lines = {}
	local function add(label, value) lines[#lines + 1] = "|cff9fc8ff" .. label .. ":|r " .. tostring(value) end

	local ver, build, _, toc = GetBuildInfo()
	add(L.D_CLIENT, string.format("%s (%s) - Interface %s", ver or "?", build or "?", toc or "?"))
	add(L.D_CLASS, (UnitClass("player")) or "?")
	add(L.D_STANCE, YesNo(ns:IsTankStance()))

	local active = ns:IsActive()
	local why = ""
	if not active then
		if not ns.db.enabled then why = L.D_WHY_OFF
		elseif not IsInGroup() and not ns.db.activeSolo then why = L.D_WHY_SOLO
		elseif ns.db.activeOnlyTank and not ns:IsTankStance() then why = L.D_WHY_STANCE end
		why = " |cffaaaaaa(" .. why .. ")|r"
	end
	add(L.D_ACTIVE, YesNo(active) .. why)

	local cd = ns.SpellCD(ns.tauntSpell)
	local readyText = ns:TauntUsable() and (" |cff40ff40" .. L.TAUNT_READY .. "|r") or (" |cffff5050" .. L.HINT_NO_SEAL .. "|r")
	add(L.D_TAUNT, ns.tauntSpell and (ns.tauntSpell .. (cd > 0 and string.format(" |cffffd100(%.0f s)|r", cd) or readyText))
		or ("|cffff5050" .. L.NONE .. "|r"))
	if ns.tauntMode == "friendly" then
		add(L.D_TAUNTMODE, L.D_MODE_FRIENDLY)
	elseif ns.tauntMode == "seal" then
		add(L.D_TAUNTMODE, L.D_MODE_SEAL)
		add(L.D_SEAL, YesNo(ns:HasSealOfFury()) .. (ns.sealName and (" (" .. ns.sealName .. ")") or ""))
	end
	add(L.D_AOE, ns.aoeSpell or L.NONE)
	add(L.D_DEF, #ns.defensives > 0 and table.concat(ns.defensives, ", ") or L.NONE)

	local key = ns.Taunt:GetKey("taunt")
	add(L.D_KEY, key and ((GetBindingText and GetBindingText(key)) or key) or ("|cffff5050" .. L.O_KEY_NONE .. "|r"))

	if UnitExists("mouseover") and ns.Safe(UnitCanAttack("player", "mouseover"), false) then
		local r = ns.SpellInRange(ns.tauntSpell, "mouseover")
		add(L.D_MOUSE, (ns.Safe(UnitName("mouseover"), L.D_SECRET) or "?") .. " - " .. L.D_RANGE .. ": " ..
			(r == nil and "-" or YesNo(r)))
	else
		add(L.D_MOUSE, "-")
	end

	if UnitExists("target") and ns.Safe(UnitCanAttack("player", "target"), false) then
		local ok, isTanking, status, scaled = pcall(UnitDetailedThreatSituation, "player", "target")
		if not ok or ns.IsSecret(isTanking) or ns.IsSecret(status) then
			add(L.D_THREAT, "|cffffd100" .. L.D_SECRET .. "|r")
		elseif status and ns.IsSecret(scaled, "threatValues") then
			add(L.D_THREAT, YesNo(isTanking) .. " " .. L.D_TANKING .. " - |cffffd100" .. L.D_SECRET_VALUES .. "|r")
		elseif status then
			add(L.D_THREAT, string.format("%s - %s %.0f%%", YesNo(isTanking) .. " " .. L.D_TANKING, L.D_SCALED, scaled or 0))
		else
			add(L.D_THREAT, "|cffffd100" .. L.D_NOTHREAT .. "|r")
		end
	else
		add(L.D_THREAT, L.D_NOTARGET)
	end

	local n = 0
	for _ in pairs(ns.mobs) do n = n + 1 end
	add(L.D_PLATES, string.format("%d - %s %s", n, L.D_CVAR, YesNo(GetCVar("nameplateShowEnemies") == "1")))
	local grp = IsInRaid() and L.D_RAID or (IsInGroup() and L.D_PARTY or L.D_SOLO)
	add(L.D_GROUP, grp .. string.format(" - %s: %d", L.D_SYNC, #ns.Sync:Users()))
	return table.concat(lines, "\n")
end

------------------------------------------------------------
-- Forever-Schutz: Was läuft normal, was über einen Ersatzweg, was ist aus?
------------------------------------------------------------
local MODE_COLOR = { ok = "|cff40ff40", fallback = "|cffffd100", off = "|cffff5050" }

function TM:CompatLine(feat)
	local c = ns.compat[feat]
	local text
	if not c then
		text = "|cff888888" .. L.CP_UNTESTED .. "|r"
	elseif c.worst == "ok" then text = MODE_COLOR.ok .. L.CP_OK .. "|r"
	elseif c.worst == "fallback" then text = MODE_COLOR.fallback .. L["CPF_" .. feat] .. "|r"
	else text = MODE_COLOR.off .. L["CPO_" .. feat] .. "|r" end
	return "|cff9fc8ff" .. L["CP_" .. feat] .. ":|r " .. text
end

function TM:UpdateCompat()
	if not self.compatRows then return end
	for _, row in ipairs(self.compatRows) do row.text:SetText(self:CompatLine(row.feat)) end
	self.compatErr:SetText(ns.lastError and ("|cffff5050" .. string.format(L.CP_ERRORS, ns.errorCount) .. "|r") or "")
end

function TM:CompatText()
	local lines = {}
	for _, feat in ipairs(ns.COMPAT_ORDER) do
		local c = ns.compat[feat]
		local text
		if not c then
			text = "|cff888888" .. L.CP_UNTESTED .. "|r"
		else
			-- angezeigt wird der schlechteste Stand seit dem Start (bzw. seit "Zurücksetzen")
			local mode = c.worst
			if mode == "ok" then text = MODE_COLOR.ok .. L.CP_OK .. "|r"
			elseif mode == "fallback" then text = MODE_COLOR.fallback .. L["CPF_" .. feat] .. "|r"
			else text = MODE_COLOR.off .. L["CPO_" .. feat] .. "|r" end
		end
		lines[#lines + 1] = "|cff9fc8ff" .. L["CP_" .. feat] .. ":|r " .. text
	end
	if ns.lastError then
		lines[#lines + 1] = "|cffff5050" .. string.format(L.CP_ERRORS, ns.errorCount) .. "|r"
	end
	return table.concat(lines, "\n")
end

-- Bericht ohne Farben, zum Kopieren und Weitergeben
function TM:ReportText()
	local ver, build, _, toc = GetBuildInfo()
	-- Spezialisierung (Retail) und Gestalt/Haltung
	local spec = "-"
	if GetSpecialization and GetSpecializationInfo then
		local ok, idx = pcall(GetSpecialization)
		if ok and idx and not ns.IsSecret(idx) then
			local ok2, _, name, _, _, role = pcall(GetSpecializationInfo, idx)
			if ok2 and name and not ns.IsSecret(name) then spec = name .. " (" .. tostring(ns.Safe(role, "?")) .. ")" end
		end
	end
	local form = "-"
	if GetShapeshiftFormID then
		local ok, id = pcall(GetShapeshiftFormID)
		if ok and not ns.IsSecret(id) then form = tostring(id or 0) end
	end
	-- Name der aktiven Gestalt / Haltung dazu
	for i = 1, (GetNumShapeshiftForms and GetNumShapeshiftForms() or 0) do
		local ok, _, active, _, spellID = pcall(GetShapeshiftFormInfo, i)
		if ok and not ns.IsSecret(active) and active and not ns.IsSecret(spellID) then
			local n = spellID and ns.SpellName(spellID)
			if n then form = n .. " (" .. form .. ")" end
			break
		end
	end
	if form == "0" then form = "none (0)" end
	-- Umgebung: Blizzard schützt Werte in Instanzen strenger
	local inInst, instType = IsInInstance()
	local env = inInst and (instType or "instance") or "world"
	local group = IsInRaid() and ("raid " .. GetNumGroupMembers()) or (IsInGroup() and ("party " .. GetNumGroupMembers()) or "solo")
	local zone = GetRealZoneText and GetRealZoneText() or "?"
	local lines = {
		"ThreatSentinel " .. ns.version .. " - " .. (ver or "?") .. " (" .. (build or "?") .. ", Interface " .. (toc or "?") .. ")",
		"Date: " .. date("%Y-%m-%d %H:%M"),
		"Class: " .. (ns.class or "?") .. " - spec: " .. spec .. " - form: " .. form .. " - tank stance: " .. (ns:IsTankStance() and "yes" or "no"),
		"Taunt: " .. (ns.tauntSpell or "-") .. " (" .. (ns.tauntMode or "-") .. ")",
		"Environment: " .. env .. " - " .. zone .. " - group: " .. group .. " - in combat: " .. (UnitAffectingCombat("player") and "yes" or "no"),
		"Simulation: " .. (ns.simSecret and "on" or "off") .. " - live test: " .. (ns.liveTest and "on" or "off")
			.. " - tank unit: " .. ns:TankUnit(),
	}
	for _, feat in ipairs(ns.COMPAT_ORDER) do
		local c = ns.compat[feat]
		lines[#lines + 1] = feat .. ": " .. (c and (c.mode .. " (worst: " .. c.worst .. ")") or "untested")
	end
	if ns.Guide then
		for _, l in ipairs(ns.Guide:ReportLines()) do lines[#lines + 1] = l end
	end
	if ns.Log:Count() > 0 then
		lines[#lines + 1] = ""
		lines[#lines + 1] = ns.Log:SummaryText(true)
		lines[#lines + 1] = ""
	end
	lines[#lines + 1] = "Blocked: " .. ((ns.blocked and #ns.blocked > 0) and table.concat(ns.blocked, ", ") or "none")
	lines[#lines + 1] = "Errors: " .. ns.errorCount .. (ns.lastError and (" - last: " .. ns.lastError) or "")
	return table.concat(lines, "\n")
end

function TM:ShowReport()
	if not self.report then
		local r = CreateFrame("Frame", "ThreatSentinelReport", UIParent, BACKDROP)
		r:SetSize(560, 300)
		r:SetPoint("CENTER")
		r:SetFrameStrata("FULLSCREEN_DIALOG")
		r:EnableMouse(true)
		r:SetMovable(true)
		r:RegisterForDrag("LeftButton")
		r:SetScript("OnDragStart", r.StartMoving)
		r:SetScript("OnDragStop", r.StopMovingOrSizing)
		if r.SetBackdrop then
			r:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
			r:SetBackdropColor(0.05, 0.06, 0.08, 0.98)
			r:SetBackdropBorderColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.7)
		end
		tinsert(UISpecialFrames, "ThreatSentinelReport")
		local t = r:CreateFontString(nil, "OVERLAY", "GameFontNormal")
		t:SetPoint("TOPLEFT", 12, -10)
		t:SetText(L.CP_REPORT_TITLE)
		local close = CreateFrame("Button", nil, r, "UIPanelCloseButton")
		close:SetPoint("TOPRIGHT", -2, -2)
		local sf = CreateFrame("ScrollFrame", nil, r, "UIPanelScrollFrameTemplate")
		sf:SetPoint("TOPLEFT", 12, -34)
		sf:SetPoint("BOTTOMRIGHT", -32, 12)
		local eb = CreateFrame("EditBox", nil, sf)
		eb:SetMultiLine(true)
		eb:SetAutoFocus(false)
		eb:SetFontObject(ChatFontNormal or GameFontHighlightSmall)
		eb:SetWidth(500)
		eb:SetScript("OnEscapePressed", function() r:Hide() end)
		eb:SetScript("OnEditFocusGained", function(s) s:HighlightText() end)
		eb:SetScript("OnTextChanged", function(s, user) if user then s:SetText(TM.reportText or ""); s:HighlightText() end end)
		sf:SetScrollChild(eb)
		r.edit = eb
		self.report = r
	end
	self.reportText = self:ReportText()
	self.report:Show()
	self.report.edit:SetText(self.reportText)
	self.report.edit:SetFocus()
	self.report.edit:HighlightText()
end

function TM:SetSimulation(on)
	ns.simSecret = on and true or false
	ns:ResetCompat()
	self:Say(on and L.TEST_SIM_ON or L.TEST_SIM_OFF)
	self:Refresh()
end

------------------------------------------------------------
-- Fenster
------------------------------------------------------------
local function Button(parent, text, w, x, y, onClick)
	local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
	b:SetSize(w, 22)
	b:SetPoint("TOPLEFT", x, y)
	b:SetText(text)
	b:SetScript("OnClick", onClick)
	return b
end

local function Header(parent, text, x, y)
	local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	fs:SetPoint("TOPLEFT", x, y)
	fs:SetText(text)
	fs:SetTextColor(ACCENT[1], ACCENT[2], ACCENT[3])
	return fs
end

local function Small(parent, text, x, y, w)
	local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	fs:SetPoint("TOPLEFT", x, y)
	fs:SetWidth(w)
	fs:SetJustifyH("LEFT")
	fs:SetText(text)
	return fs
end

function TM:Build()
	local f = CreateFrame("Frame", "ThreatSentinelTest", UIParent, BACKDROP)
	f:SetSize(990, 570)
	f:SetPoint("CENTER", 0, 40)
	f:SetFrameStrata("DIALOG")
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:EnableMouse(true)
	if f.SetBackdrop then
		f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
		f:SetBackdropColor(0.05, 0.06, 0.08, 0.96)
		f:SetBackdropBorderColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.7)
	end
	f:Hide()
	tinsert(UISpecialFrames, "ThreatSentinelTest")

	local title = CreateFrame("Frame", nil, f, BACKDROP)
	title:SetPoint("TOPLEFT", 1, -1)
	title:SetPoint("TOPRIGHT", -1, -1)
	title:SetHeight(32)
	if title.SetBackdrop then
		title:SetBackdrop({ bgFile = WHITE })
		title:SetBackdropColor(0.09, 0.11, 0.15, 1)
	end
	title:EnableMouse(true)
	title:RegisterForDrag("LeftButton")
	title:SetScript("OnDragStart", function() f:StartMoving() end)
	title:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)
	local tt = title:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	tt:SetPoint("LEFT", 12, 0)
	tt:SetText("|cff3fa7ffThreat|rSentinel - " .. L.TEST_TITLE)
	local close = CreateFrame("Button", nil, title, "UIPanelCloseButton")
	close:SetPoint("RIGHT", -2, 0)
	close:SetScript("OnClick", function() f:Hide() end)

	-- linke Spalte: Modi und Meldungen
	local x, y = 14, -44
	Header(f, L.TEST_H_MODES, x, y)
	self.demoBtn = Button(f, "", 200, x, y - 20, function() TM:SetDemo(not ns.testMode) end)
	self.liveBtn = Button(f, "", 200, x + 206, y - 20, function() TM:SetLive(not ns.liveTest) end)
	local pv = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
	pv:SetSize(22, 22)
	pv:SetPoint("TOPLEFT", x, y - 46)
	if pv.text then pv.text:SetText("") end
	if pv.Text then pv.Text:SetText("") end
	local pvt = pv:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	pvt:SetPoint("LEFT", pv, "RIGHT", 2, 0)
	pvt:SetText(L.TEST_PREVIEW)
	pv:SetScript("OnClick", function(s) ns.db.testPreview = s:GetChecked() and true or false end)
	self.previewCheck = pv
	local pt = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
	pt:SetSize(22, 22)
	pt:SetPoint("TOPLEFT", x, y - 68)
	if pt.text then pt.text:SetText("") end
	if pt.Text then pt.Text:SetText("") end
	local ptt = pt:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	ptt:SetPoint("LEFT", pt, "RIGHT", 2, 0)
	ptt:SetText(L.TEST_PETTANK)
	pt:SetScript("OnClick", function(s)
		ns.db.testPetTank = s:GetChecked() and true or false
		ns:ClearRoleCache()
	end)
	self.petTankCheck = pt
	Button(f, L.GUIDE_START, 180, x + 226, y + 4, function() f:Hide(); ns.Guide:Start() end)
	Small(f, L.TEST_MODES_HELP, x, y - 94, 410)

	y = -214
	Header(f, L.TEST_H_ALERTS, x, y)
	self.allBtn = Button(f, L.TEST_ALL, 200, x + 210, y + 4, function() TM:PlayAll() end)
	for i, a in ipairs(self.ACTIONS) do
		local col, row = (i - 1) % 3, math.floor((i - 1) / 3)
		Button(f, L[a.key], 134, x + col * 138, y - 20 - row * 26, a.fn)
	end

	y = -334
	Header(f, L.TEST_H_SYNC, x, y)
	for i, a in ipairs(self.SYNC) do
		local col, row = (i - 1) % 3, math.floor((i - 1) / 3)
		Button(f, string.format(L[a.key], FAKE_TANK), 134, x + col * 138, y - 20 - row * 26, a.fn)
	end
	Small(f, string.format(L.TEST_SYNC_HELP, FAKE_TANK), x, y - 76, 410)

	y = -454
	Header(f, L.TEST_H_KEY, x, y)
	Small(f, L.TEST_KEY_HELP, x, y - 20, 410)
	Button(f, L.TEST_OPEN_OPTIONS, 200, x, y - 62, function() f:Hide(); ns.Options:Toggle() end)

	-- rechte Spalte: Diagnose
	local dx = 450
	Header(f, L.TEST_H_DIAG, dx, -44)
	local diagBg = CreateFrame("Frame", nil, f, BACKDROP)
	diagBg:SetPoint("TOPLEFT", dx - 4, -64)
	diagBg:SetPoint("BOTTOMRIGHT", -10, 12)
	if diagBg.SetBackdrop then
		diagBg:SetBackdrop({ bgFile = WHITE })
		diagBg:SetBackdropColor(0, 0, 0, 0.35)
	end
	self.diag = diagBg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	self.diag:SetPoint("TOPLEFT", 8, -8)
	self.diag:SetWidth(246)
	self.diag:SetJustifyH("LEFT")
	self.diag:SetSpacing(4)

	-- dritte Spalte: Forever-Schutz
	local cx = 726
	Header(f, L.TEST_H_COMPAT, cx, -44)
	local cpBg = CreateFrame("Frame", nil, f, BACKDROP)
	cpBg:SetPoint("TOPLEFT", cx - 4, -64)
	cpBg:SetPoint("BOTTOMRIGHT", -10, 128)
	if cpBg.SetBackdrop then
		cpBg:SetBackdrop({ bgFile = WHITE })
		cpBg:SetBackdropColor(0, 0, 0, 0.35)
	end
	-- eine Zeile pro Punkt; Maus darüber zeigt, wie man ihn prüft
	self.compatRows = {}
	for i, feat in ipairs(ns.COMPAT_ORDER) do
		local row = CreateFrame("Frame", nil, cpBg)
		row:SetSize(244, 25)
		row:SetPoint("TOPLEFT", 4, -4 - (i - 1) * 25)
		row:EnableMouse(true)
		row.feat = feat
		row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		row.text:SetPoint("TOPLEFT", 2, -1)
		row.text:SetWidth(240)
		row.text:SetJustifyH("LEFT")
		local hl = row:CreateTexture(nil, "HIGHLIGHT")
		hl:SetAllPoints()
		hl:SetTexture(WHITE)
		hl:SetVertexColor(1, 1, 1, 0.06)
		row:SetScript("OnEnter", function(r)
			GameTooltip:SetOwner(r, "ANCHOR_LEFT")
			GameTooltip:AddLine(L["CP_" .. feat], 1, 1, 1)
			GameTooltip:AddLine(L["CPH_" .. feat], 0.85, 0.85, 0.85, true)
			GameTooltip:Show()
		end)
		row:SetScript("OnLeave", function() GameTooltip:Hide() end)
		self.compatRows[i] = row
	end
	self.compatErr = cpBg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	self.compatErr:SetPoint("BOTTOMLEFT", 6, 4)
	self.simBtn = Button(f, "", 252, cx - 4, -424, function() TM:SetSimulation(not ns.simSecret) end)
	Button(f, L.TEST_COMPAT_RESET, 124, cx - 4, -450, function() ns:ResetCompat(); TM:Refresh() end)
	Button(f, L.TEST_COMPAT_REPORT, 124, cx + 124, -450, function() TM:ShowReport() end)
	Small(f, L.TEST_COMPAT_HELP, cx - 4, -478, 252)
	self.logBtn = Button(f, "", 150, cx - 4, -538, function() ns.Log:SetOn(not ns.Log.on) end)
	self.logCount = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	self.logCount:SetPoint("TOPLEFT", self.logBtn, "BOTTOMLEFT", 2, -2)
	Button(f, L.SUM_BUTTON, 98, cx + 150, -538, function() ns.Log:ShowSummary() end)

	local acc = 0
	f:SetScript("OnUpdate", function(_, e)
		acc = acc + e
		if acc < 0.3 then return end
		acc = 0
		TM.diag:SetText(TM:DiagText())
		TM:UpdateCompat()
		TM:RefreshLog()
	end)
	f:SetScript("OnShow", function() TM:Refresh() end)
	self.frame = f
end

function TM:Refresh()
	if not self.frame then return end
	self.demoBtn:SetText(ns.testMode and L.TEST_DEMO_STOP or L.TEST_DEMO_START)
	self.liveBtn:SetText(ns.liveTest and L.TEST_LIVE_STOP or L.TEST_LIVE_START)
	self.previewCheck:SetChecked(ns.db.testPreview)
	self.petTankCheck:SetChecked(ns.db.testPetTank)
	self.simBtn:SetText(ns.simSecret and L.TEST_SIM_STOP or L.TEST_SIM_START)
	self.diag:SetText(self:DiagText())
	self:UpdateCompat()
	self:RefreshLog()
end

function TM:RefreshLog()
	if not self.logBtn then return end
	self.logBtn:SetText(ns.Log.on and L.TEST_LOG_STOP or L.TEST_LOG_START)
	self.logCount:SetText(string.format(L.TEST_LOG_COUNT, ns.Log:Count()))
end

function TM:ToggleWindow()
	if not self.frame then self:Build() end
	self.frame:SetShown(not self.frame:IsShown())
end

function TM:Login()
	self:CreatePreview()
end
