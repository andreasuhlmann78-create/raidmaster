# ThreatSentinel – Changelog

## 1.7.0
- **Freely selectable sounds**: every sound (aggro lost to DPS / healer, early warning, resisted, regained, emergency, DPS view) has a picker with three groups: ThreatSentinel sounds, **sounds** (horn, double horn, foghorn, siren, alarm bell, bell, gong, whistle, drum, double beep, ping) and **WoW sounds** (raid warning, ready check, alarm, boss whisper, whisper, map ping …). Left click chooses and plays, right click only plays.
- **Own sound**: a WoW sound ID (number, e.g. from wowhead.com/sounds) or your own .ogg/.mp3 file in `Interface\AddOns\ThreatSentinel_Sounds` (kept on updates; restart the game once after adding files)
- New: own sound for the **early warning** (yellow border, off by default) and for the DPS view warning (previously the same sound as "aggro lost to DPS")
- **Dungeon check**: when you enter a dungeon as a tank, the test log runs automatically. When you leave the instance, the report appears (aggro losses and regains, nameplates, sounds, alerts, HUD, threat meter, taunts, errors, plus fights in tank stance and who you lost aggro to). Dying and running back as a ghost or /reload do not interrupt the check. If you did not tank, there is no report. Settings under "General" (raids too, screenshots, show last report).
- **Threat meter and DPS view** (own threat) can be moved freely and resized (size and width) – the small HUD too. New button "Move windows / change size" (Display tab) or `/ts move`: drag the windows, mouse wheel changes the size, right click resets to 100 %. Windows stay in place while resizing.
- Test report: the DPS view no longer counts as failed while tanking (it is hidden on purpose); taunts from the action bar count without the taunt key; after /reload the evaluation covers the whole session

## 1.6.1
- Test report: "Loose nameplate highlighted" no longer fails on Classic Era (the border was there; the check also required a visibility value that Classic reports differently). The log now records both `shown` and `visible`.
- Test assistant: the HUD step is checked automatically (test mobs often die before the question can be answered)
- Clearer wording of the aggro-loss line in the report

## 1.6.0
- New **test log** for unattended tests: `/ts log on | off | clear | status | report | shots` or the button in the test centre. Writes machine-readable lines to the SavedVariables (`ThreatSentinelDB.testlog`): session info (client, class, form, pet, all settings) and events – combat, mobs, state changes, threat, the **actual** nameplate state (alpha, scale, border, pulse, flash, hint, raid mark, cast bar), alerts, sounds, HUD, threat meter, DPS view, taunts, resists, crowd control, sync, key hint, errors, blocked actions, test assistant steps. Ring buffer of 5000 entries, only changes are written, protected values appear as SECRET. Off by default; when off it does nothing.
- **In-game test report**: when the test log is turned off (or the test assistant finishes), ThreatSentinel evaluates the log itself and shows a report: aggro losses and regains (with average time), held / loose nameplate appearance and colour, flash on regain, HUD, threat meter, DPS view, messages, sounds, taunt key, errors. `/ts log report` or "Evaluate" in the test centre shows it again; it is also included in the copyable report.
- The test assistant now turns the test log on at the start and off at the end
- Automatic screenshots while the test log is on (loose mob, aggro regained, each new alert type, first threat meter in combat), max. 1 per 2 s (test mobs often live only ~10 s) and 25 per session; `/ts log shots` toggles them

## 1.5.0
- New **test assistant** (`/ts guide` or the button in the test centre): guides you in-game step by step through all features, detects most steps automatically, asks yes/no for what only you can see, keeps its progress over /reload and adds the results to the report
- Live test option "pet is the tank" (hunter / warlock): your pet tanks, you are the DPS who pulls aggro; the taunt key makes the pet cast Growl / Torment
- Classic Era: interface numbers 11509 / 11510 added

## 1.4.5
- Slider input fields select their content when clicked, so typing replaces the value
- Test messages get a dark background while testing, so they are readable on top of the test centre
- The report shows the name of the active form / stance, not just its number
- The "… is enough" setting is labelled per class (warrior: Sunder, others: Threat)

## 1.4.4
- Retail: a Guardian druid only counts as tanking in bear form (not in cat, travel or caster form)
- Binding the taunt key now asks before replacing an existing key binding
- Options of other classes are hidden (e.g. Sunder Armor stacks only for warriors)
- Sliders have -/+ buttons and an input field for exact values
- Test centre: messages appear in front of the window; new button "Play all one after another"; every line in "WoW Forever protection" explains on mouseover how to check it; the report now includes date, specialisation, form, environment (world / dungeon / raid) and group
- Clearer wording: pets and NPC followers count as DPS in the live test

## 1.4.3
- Small HUD and threat meter now sit at the right screen edge by default instead of next to your character, so they no longer cover nameplates. Windows you moved yourself stay where they are.

## 1.4.2
- Fixed: on Retail (and WoW Forever) every login showed "ThreatSentinel has been blocked". The combat log is no longer registered on clients with protected values; resisted taunts are detected via threat instead.
- Blocked actions are now counted and listed in the test centre report
- Demo: preview mobs always appear in the HUD (also with real nameplates nearby); no AoE taunt hint for classes without one
- Test messages ("Show sample") now appear in front of the settings window
- Threat meter: title and lead no longer run into each other
- Switching between demo and live test is now shown on screen

## 1.4.1
- Loads on Retail (Midnight) as a test bed: Retail already has the addon restrictions that WoW Forever takes over. Tank detection there by tank specialisation; taunts for Death Knight, Demon Hunter, Monk and Paladin (Hand of Reckoning) added.

## 1.4.0
- Prepared for WoW Forever: the game can protect values in combat ("secrets"). ThreatSentinel never calculates with protected values and switches to a fallback instead of producing Lua errors:
  - Aggro: threat status instead of percentages; threat meter and DPS view let the game display the values
  - Cooldowns: timed by the addon from your own casts (learns the real duration)
  - Taunt resisted without combat log: checked via threat right after the taunt
  - Seal of Fury, Righteous Fury, Sunder Armor stacks and crowd-controlled mobs: tracked from your own / your group's spells
  - Mob identity without GUID: by nameplate; tank sync: other tanks recognised by their target
  - Emergency hint: shown via the game's own health percent where possible
- Errors in one part no longer stop the rest of the addon
- Test centre: new column "WoW Forever protection" (green / yellow / red per feature), "Simulate Forever restrictions" to try all fallbacks on other clients, and "Copy report"

## 1.3.0
- Held nameplates now default to 35 % opacity and 80 % size (adjustable). Raid markers and cast bars always stay fully visible.
- "Taunt resisted" now names the backup that is ready, e.g. "Taunt resisted » Mocking Blow!" (warrior: Mocking Blow, then Challenging Shout; druid: Challenging Roar)
- One-time hint when you first enter an instance with no taunt key bound
- Message in the middle: smaller, size and height adjustable, ordered by importance (an important message is no longer replaced by a less important one). "Aggro regained" only flashes the nameplate by default.
- New short sounds of its own, so they are not mixed up with DBM/BigWigs or ready checks
- Chat messages now go only to the other tanks by default (via sync). New option: party/raid during boss fights only.
- Threat meter: 100 % now always means "pulls aggro now" (110 % melee / 130 % ranged rule included); "About to pull!" instead of "Lead 0 %"
- Raid markers: skull before cross in the loose list, with icon
- Presets: Subtle, Standard, Loud
- Tank sync: a short initial (e.g. "G" for Grimbar) instead of "taken by Grimbar"

## 1.2.3
- Paladin taunt reworked (detected by spell ID, not by name):
  - TBC: Righteous Defense is cast on the ally the mob is attacking (mouseover mob, otherwise your target's target)
  - WoW Forever: Judgement only counts as a taunt with Seal of Fury active; without it the nameplate shows "Seal of Fury missing"
  - Removed Hand of Reckoning (does not exist before Wrath)
- Diagnostics show the paladin taunt type and whether Seal of Fury is active

## 1.2.2
- Fixed: the addon did not load in TBC Classic Anniversary 2.5.6 (unknown event stopped loading – /ts and the minimap button were missing). Unknown events are now skipped.
- Added interface 20506 (TBC Classic Anniversary 2.5.6), so the addon is no longer marked as out of date
- The arrow in "» Name (Role)" is now shown correctly (the old character was missing from the WoW font)
- Test centre: preview nameplates in two rows, no more overlapping
- Test messages stay visible when the demo is stopped

## 1.2.1
- New **Support** button (PayPal) in the title bar of the settings window and "Support the addon" on the General page. Also `/ts donate`. It never opens by itself.

## 1.2.0
- New **test centre** (right-click the minimap button or `/ts test`): demo with preview nameplates, solo live test, every alert on its own button, simulated tank sync and live diagnostics
- Runs on Classic Era / Anniversary and TBC Anniversary as well as WoW Forever

## 1.1.0
- First release: loose mobs light up, held mobs fade out, taunt on mouseover, threat meter, tank sync
