-- LevelPilot - Geo
-- Umrechnung Karten- <-> Weltkoordinaten, Spielerposition, Zonen.
-- Weltkoordinaten: n = Nord-Achse, w = West-Achse (Yards), inst = Kontinent/Instanz.

local _, LP = ...
local L = LP.L
local Geo = {}
LP:RegisterModule("Geo", Geo)

local boundsCache, contCache, nameCache = {}, {}, {}

local function WorldVec(map, x, y)
    local inst, pos = C_Map.GetWorldPosFromMapPos(map, CreateVector2D(x, y))
    if not pos then return nil end
    local n, w = pos:GetXY()
    return inst, n, w
end

-- Grenzen einer Karte in Weltkoordinaten
function Geo:Bounds(map)
    if not map then return nil end
    local b = boundsCache[map]
    if b ~= nil then return b or nil end
    local inst, top, left = WorldVec(map, 0, 0)
    local _, bottom, right = WorldVec(map, 1, 1)
    if not inst or not bottom or top == bottom or left == right then
        boundsCache[map] = false
        return nil
    end
    b = { inst = inst, top = top, left = left, bottom = bottom, right = right }
    boundsCache[map] = b
    return b
end

-- Kartenkoordinaten (0-100) -> Welt
function Geo:ToWorld(map, x, y)
    local b = self:Bounds(map)
    if not b or not x or not y then return nil end
    local n = b.top + (b.bottom - b.top) * (y / 100)
    local w = b.left + (b.right - b.left) * (x / 100)
    return b.inst, n, w
end

-- Welt -> Kartenkoordinaten (0-100) auf einer bestimmten Karte
function Geo:ToMap(map, inst, n, w)
    local b = self:Bounds(map)
    if not b or b.inst ~= inst then return nil end
    local x = (w - b.left) / (b.right - b.left) * 100
    local y = (n - b.top) / (b.bottom - b.top) * 100
    return x, y
end

function Geo:Dist(n1, w1, n2, w2)
    local dn, dw = n2 - n1, w2 - w1
    return math.sqrt(dn * dn + dw * dw)
end

function Geo:ContinentOf(map)
    if not map then return nil end
    local c = contCache[map]
    if c ~= nil then return c or nil end
    local info = C_Map.GetMapInfo(map)
    local guard = 0
    while info and info.mapType and info.mapType > Enum.UIMapType.Continent
          and info.parentMapID and info.parentMapID > 0 and guard < 10 do
        info = C_Map.GetMapInfo(info.parentMapID)
        guard = guard + 1
    end
    c = (info and info.mapType == Enum.UIMapType.Continent) and info.mapID or false
    contCache[map] = c
    return c or nil
end

function Geo:MapName(map)
    if not map then return "?" end
    local n = nameCache[map]
    if n then return n end
    n = LP.Names and LP.Names:Zone(map)            -- andere Sprache als das Spiel: Sprachpaket
    if not n then
        local info = C_Map.GetMapInfo(map)
        n = info and info.name or (L["Karte "] .. map)
    end
    nameCache[map] = n
    return n
end

function Geo:ResetNames() wipe(nameCache) end

------------------------------------------------------------------------
-- Spielerposition (pro Bildaufbau zwischengespeichert)
------------------------------------------------------------------------
local cache = { t = -1 }

function Geo:Player()
    local now = GetTime()
    if cache.t == now then return cache.inst, cache.n, cache.w, cache.map, cache.x, cache.y end
    cache.t = now
    cache.inst, cache.n, cache.w, cache.map, cache.x, cache.y = nil, nil, nil, nil, nil, nil
    local map = C_Map.GetBestMapForUnit("player")
    if not map then return nil end
    local inst, n, w, x, y
    -- 1) Kartenposition
    local pos = C_Map.GetPlayerMapPosition(map, "player")
    if pos then
        x, y = pos:GetXY()
        if x and not (x == 0 and y == 0) then
            x, y = x * 100, y * 100
            inst, n, w = self:ToWorld(map, x, y)
        end
    end
    -- 2) Weltposition direkt (falls die Kartenfunktion nichts liefert)
    if not inst and UnitPosition then
        local un, uw, _, uinst = UnitPosition("player")
        if un and uw and uinst then
            local b = self:Bounds(map)
            if b and b.inst == uinst then
                inst, n, w = uinst, un, uw
                x, y = self:ToMap(map, inst, n, w)
            end
        end
    end
    if not inst or not x then return nil end
    cache.inst, cache.n, cache.w, cache.map, cache.x, cache.y = inst, n, w, map, x, y
    return inst, n, w, map, x, y
end

-- Entfernung Spieler -> Punkt auf Karte
function Geo:DistToMapPoint(map, x, y)
    local pi, pn, pw = self:Player()
    local ti, tn, tw = self:ToWorld(map, x, y)
    if not pi or not ti or pi ~= ti then return nil end
    return self:Dist(pn, pw, tn, tw)
end

-- Richtung (Bogenmass, ab Norden gegen den Uhrzeigersinn) vom Spieler zu einem Weltpunkt
function Geo:Bearing(n, w)
    local _, pn, pw = self:Player()
    if not pn then return nil end
    return math.atan2(w - pw, n - pn)
end
