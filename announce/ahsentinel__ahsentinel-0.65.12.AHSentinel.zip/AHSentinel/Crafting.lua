if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.7 - Berufe: Gewinn pro Rezept
--
-- Neben dem Berufsfenster (Alchemie, Schmiedekunst, ... und
-- Verzauberkunst) erscheint ein kleines Fenster:
--   * gewähltes Rezept: Materialkosten, Wert des Ergebnisses, Gewinn
--     nach AH-Gebühr
--   * die besten Rezepte nach Gewinn (Klick wählt das Rezept)
--   * Materialien für N-mal herstellen als Einkaufsliste anlegen
-- Preise: Marktwert (Median 14 Tage) aus deinen Scans.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local Cr = {}
A.Crafting = Cr

local AH_CUT = 0.05

local function IDFromLink(link)
    return type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil
end

local function SafeCall(fn, ...)
    if not fn then return nil end
    local r = { pcall(fn, ...) }
    if not r[1] then
        if A.ReportOnce then A:ReportOnce(fn, "SafeCall:Berufe", r[2]) end
        return nil
    end
    return unpack(r, 2)
end

-- ------------------------------------------------------------
-- Zwei Arten von Berufsfenstern in Classic:
--   "trade" = Handwerk (TradeSkill-API), "craft" = Verzauberkunst (Craft-API)
-- ------------------------------------------------------------
local API = {
    trade = {
        num = function() return GetNumTradeSkills and SafeCall(GetNumTradeSkills) or 0 end,
        info = function(i)
            local name, kind = SafeCall(GetTradeSkillInfo, i)
            return name, kind
        end,
        link = function(i) return GetTradeSkillItemLink and SafeCall(GetTradeSkillItemLink, i) end,
        made = function(i)
            if not GetTradeSkillNumMade then return 1, 1 end
            local lo, hi = SafeCall(GetTradeSkillNumMade, i)
            return lo or 1, hi or lo or 1
        end,
        numReagents = function(i) return GetTradeSkillNumReagents and SafeCall(GetTradeSkillNumReagents, i) or 0 end,
        reagent = function(i, r)
            local name, _, count, have = SafeCall(GetTradeSkillReagentInfo, i, r)
            local link = GetTradeSkillReagentItemLink and SafeCall(GetTradeSkillReagentItemLink, i, r)
            return name, count, have, link
        end,
        selected = function() return GetTradeSkillSelectionIndex and SafeCall(GetTradeSkillSelectionIndex) end,
        select = function(i)
            if TradeSkillFrame_SetSelection then pcall(TradeSkillFrame_SetSelection, i) end
            if TradeSkillFrame_Update then pcall(TradeSkillFrame_Update) end
        end,
        title = function() return GetTradeSkillLine and SafeCall(GetTradeSkillLine) end,
        frame = function() return type(TradeSkillFrame) == "table" and TradeSkillFrame or nil end,
        -- aktuelle Nummer eines Rezepts (die Liste verschiebt sich durch Filter und zugeklappte Kategorien)
        find = function(r)
            for i = 1, (GetNumTradeSkills and SafeCall(GetNumTradeSkills) or 0) do
                local name, kind = SafeCall(GetTradeSkillInfo, i)
                if name == r.name and kind ~= "header" then return i end
            end
            return nil
        end,
        -- Suchtext und Filter zurücksetzen, alle Kategorien aufklappen (nur Blizzard-Funktionen aufrufen)
        reveal = function()
            if SetTradeSkillItemNameFilter then pcall(SetTradeSkillItemNameFilter, "") end
            if TradeSkillFrameEditBox and TradeSkillFrameEditBox.SetText then pcall(TradeSkillFrameEditBox.SetText, TradeSkillFrameEditBox, "") end
            if SetTradeSkillSubClassFilter then pcall(SetTradeSkillSubClassFilter, 0, 1, 1) end
            if SetTradeSkillInvSlotFilter then pcall(SetTradeSkillInvSlotFilter, 0, 1, 1) end
            if TradeSkillOnlyShowMakeable then pcall(TradeSkillOnlyShowMakeable, false) end
            if ExpandTradeSkillSubClass then pcall(ExpandTradeSkillSubClass, 0) end
        end,
        -- gewähltes Rezept in die Ansicht scrollen
        scrollTo = function(i)
            if TradeSkillListScrollFrame and FauxScrollFrame_SetOffset then
                pcall(FauxScrollFrame_SetOffset, TradeSkillListScrollFrame, math.max(0, i - 2))
                if TradeSkillListScrollFrameScrollBar and TradeSkillListScrollFrameScrollBar.SetValue and TRADE_SKILL_HEIGHT then
                    pcall(TradeSkillListScrollFrameScrollBar.SetValue, TradeSkillListScrollFrameScrollBar, math.max(0, i - 2) * TRADE_SKILL_HEIGHT)
                end
            end
            if TradeSkillFrame_Update then pcall(TradeSkillFrame_Update) end
        end,
    },
    craft = {
        num = function() return GetNumCrafts and SafeCall(GetNumCrafts) or 0 end,
        info = function(i)
            local name, _, kind = SafeCall(GetCraftInfo, i)
            return name, kind
        end,
        link = function(i) return GetCraftItemLink and SafeCall(GetCraftItemLink, i) end,
        made = function(i) return 1, 1 end,
        numReagents = function(i) return GetCraftNumReagents and SafeCall(GetCraftNumReagents, i) or 0 end,
        reagent = function(i, r)
            local name, _, count, have = SafeCall(GetCraftReagentInfo, i, r)
            local link = GetCraftReagentItemLink and SafeCall(GetCraftReagentItemLink, i, r)
            return name, count, have, link
        end,
        selected = function() return GetCraftSelectionIndex and SafeCall(GetCraftSelectionIndex) end,
        select = function(i)
            if CraftFrame_SetSelection then pcall(CraftFrame_SetSelection, i) end
            if CraftFrame_Update then pcall(CraftFrame_Update) end
        end,
        title = function() return GetCraftDisplaySkillLine and SafeCall(GetCraftDisplaySkillLine) end,
        frame = function() return type(CraftFrame) == "table" and CraftFrame or nil end,
        find = function(r)
            for i = 1, (GetNumCrafts and SafeCall(GetNumCrafts) or 0) do
                local name, _, kind = SafeCall(GetCraftInfo, i)
                if name == r.name and kind ~= "header" then return i end
            end
            return nil
        end,
        reveal = function()
            if ExpandCraftSkillLine then pcall(ExpandCraftSkillLine, 0) end
        end,
    },
}

-- ------------------------------------------------------------
-- Moderner Client (WoW Forever, Retail): C_TradeSkillUI statt der alten TradeSkill-Funktionen.
-- Über dieselben Zugriffe wie oben (Nummer i = i-tes gelerntes Rezept), damit der Rest gleich bleibt.
-- ------------------------------------------------------------
local TS = C_TradeSkillUI
local modernIDs, modernDirty, modernProf = {}, true, nil
local schemCache = {}
-- Liste der gelernten Rezepte nur neu lesen, wenn sie sich geändert haben kann (Fenster offen, Liste
-- aktualisiert). Die Schemata (Zutaten) gehören fest zur Rezept-ID: sie werden nur beim Wechsel der
-- Datenquelle bzw. des Berufs neu gelesen - sonst würde jedes Listen-Ereignis alles neu lesen (ruckelt).
function Cr:InvalidateModern(full)
    modernDirty = true
    if full then wipe(schemCache) end
end
local function ModernIDs()
    if not modernDirty then return modernIDs end
    modernDirty = false
    local base = TS and TS.GetBaseProfessionInfo and SafeCall(TS.GetBaseProfessionInfo)
    local prof = type(base) == "table" and (base.professionID or base.professionName) or nil
    if prof ~= modernProf then wipe(schemCache); modernProf = prof end
    modernIDs = {}
    local all = TS and TS.GetAllRecipeIDs and SafeCall(TS.GetAllRecipeIDs) or {}
    for _, id in ipairs(all) do
        local info = TS.GetRecipeInfo and SafeCall(TS.GetRecipeInfo, id)
        if type(info) == "table" and info.learned and not info.isDummyRecipe and not info.isRecraft then
            table.insert(modernIDs, id)
        end
    end
    return modernIDs
end
-- nur lesen (Testroutine T147/T148): i-te gelernte Rezept-ID und Grösse des Zwischenspeichers
function Cr:ModernRecipeID(i) return ModernIDs()[i or 1] end
function Cr:SchematicCacheSize()
    local n = 0
    for _ in pairs(schemCache) do n = n + 1 end
    return n
end
local function Schematic(i)
    local id = ModernIDs()[i]
    if not id then return nil end
    local sc = schemCache[id]
    if sc == nil then
        sc = TS.GetRecipeSchematic and SafeCall(TS.GetRecipeSchematic, id, false) or false
        schemCache[id] = sc
    end
    return sc or nil, id
end
-- nur die Pflicht-Zutaten (keine optionalen / Verfeinerungs-Zutaten)
local function BasicSlots(sc)
    local out = {}
    local basic = Enum and Enum.CraftingReagentType and Enum.CraftingReagentType.Basic
    for _, slot in ipairs(sc and sc.reagentSlotSchematics or {}) do
        local isBasic = (basic and slot.reagentType == basic) or (not basic and slot.required ~= false)
        if isBasic and (slot.quantityRequired or 0) > 0 and slot.reagents and slot.reagents[1] and slot.reagents[1].itemID then
            table.insert(out, slot)
        end
    end
    return out
end
local function CountItem(itemID)
    if C_Item and C_Item.GetItemCount then return SafeCall(C_Item.GetItemCount, itemID) or 0 end
    if GetItemCount then return SafeCall(GetItemCount, itemID) or 0 end
    return 0
end
API.modern = {
    num = function() return #ModernIDs() end,
    info = function(i)
        local id = ModernIDs()[i]
        local info = id and SafeCall(TS.GetRecipeInfo, id)
        if type(info) ~= "table" then return nil end
        return info.name, "optimal"
    end,
    link = function(i)
        local sc = Schematic(i)
        return sc and sc.outputItemID and ("item:" .. sc.outputItemID) or nil
    end,
    made = function(i)
        local sc = Schematic(i)
        if not sc then return 1, 1 end
        return sc.quantityMin or 1, sc.quantityMax or sc.quantityMin or 1
    end,
    numReagents = function(i) return #BasicSlots((Schematic(i))) end,
    reagent = function(i, r)
        local slot = BasicSlots((Schematic(i)))[r]
        if not slot then return nil end
        local itemID = slot.reagents[1].itemID
        return A:GetItemName(itemID), slot.quantityRequired, CountItem(itemID), "item:" .. itemID
    end,
    selected = function()
        -- gerade gewähltes Rezept im Berufsfenster (falls das Fenster es verrät)
        local f = ProfessionsFrame
        local form = f and f.CraftingPage and f.CraftingPage.SchematicForm
        local cur = form and (form.currentRecipeInfo or (form.GetRecipeInfo and SafeCall(form.GetRecipeInfo, form)))
        local rid = type(cur) == "table" and cur.recipeID
        if rid then Cr.lastModernRecipe = rid else rid = Cr.lastModernRecipe end
        if not rid then return nil end
        for i, id in ipairs(ModernIDs()) do if id == rid then return i end end
        return nil
    end,
    select = function(i)
        local id = ModernIDs()[i]
        if id then Cr.lastModernRecipe = id end
        if id and TS.OpenRecipe then pcall(TS.OpenRecipe, id) end
    end,
    find = function(r)
        local ids = ModernIDs()
        if r.recipeID then for i, id in ipairs(ids) do if id == r.recipeID then return i end end end
        return nil
    end,
    -- Suchtext und Filter des Berufsfensters zurücksetzen (nur über C_TradeSkillUI, keine Blizzard-Rahmen anfassen)
    reveal = function()
        local calls = { { "SetRecipeItemNameFilter", "" }, { "SetOnlyShowMakeableRecipes", false },
            { "SetOnlyShowSkillUpRecipes", false }, { "SetShowLearned", true }, { "SetShowUnlearned", true },
            { "ClearInventorySlotFilter" }, { "ClearRecipeCategoryFilter" }, { "ClearRecipeSourceTypeFilter" } }
        for _, c in ipairs(calls) do
            local fn = TS and TS[c[1]]
            if fn then if c[2] ~= nil then pcall(fn, c[2]) else pcall(fn) end end
        end
    end,
    title = function()
        local info = (TS.GetChildProfessionInfo and SafeCall(TS.GetChildProfessionInfo))
            or (TS.GetBaseProfessionInfo and SafeCall(TS.GetBaseProfessionInfo))
        return type(info) == "table" and (info.professionName or info.parentProfessionName) or nil
    end,
    frame = function()
        if type(ProfessionsFrame) == "table" then return ProfessionsFrame end
        return type(TradeSkillFrame) == "table" and TradeSkillFrame or nil
    end,
}
-- Welche Schnittstelle hat der Client? Alte Funktionen zuerst (Classic Era, TBC, Wrath, Cata, MoP),
-- sonst C_TradeSkillUI (WoW Forever, Retail)
function Cr:TradeKind()
    if A:API("GetNumTradeSkills") then return "trade" end      -- A:API: ohne Testroutine = GetNumTradeSkills
    local ts = A:API("C_TradeSkillUI")
    if ts and ts.GetAllRecipeIDs then return "modern" end
    return "trade"
end
Cr.API = API
Cr.kind = nil          -- gerade offenes Berufsfenster: "trade" / "craft" / nil

-- Preis eines Materials/Ergebnisses: Marktwert, sonst aktuelles Angebot
-- Materialien: beim Händler kaufen, wenn das billiger ist (Preis wird beim Händler gelesen)
function Cr:UnitPrice(itemID, isReagent)
    if not itemID then return nil end
    local mv = A:GetMarketValue(itemID)
    if not mv then
        local pr = A.Seller and A.Seller:GetPriceInfo(itemID)
        mv = pr and pr.lowestOther or nil
    end
    if isReagent then
        local buy = A:GetVendorBuyPrice(itemID)
        if buy and (not mv or buy < mv) then return buy, true end
    end
    return mv
end

-- ein Rezept vollständig lesen und bewerten
function Cr:ReadRecipe(kind, i)
    local api = API[kind]
    local name, skillType = api.info(i)
    if not name or skillType == "header" then return nil end
    local productID = IDFromLink(api.link(i))
    local lo, hi = api.made(i)
    local made = ((lo or 1) + (hi or lo or 1)) / 2
    local r = { index = i, name = name, productID = productID, made = made, reagents = {}, cost = 0, missing = 0, kind = kind,
                recipeID = kind == "modern" and ModernIDs()[i] or nil }
    for k = 1, api.numReagents(i) do
        local rname, count, have, link = api.reagent(i, k)
        local id = IDFromLink(link)
        local unit, atVendor = self:UnitPrice(id, true)
        table.insert(r.reagents, { itemID = id, name = rname or (id and A:GetItemName(id)) or "?", count = count or 1,
                                   have = have or 0, unit = unit, atVendor = atVendor })
        if unit then r.cost = r.cost + unit * (count or 1) else r.missing = r.missing + 1 end
    end
    local unitValue = productID and self:UnitPrice(productID)
    if unitValue then
        r.value = math.floor(unitValue * made + 0.5)
        r.net = math.floor(r.value * (1 - AH_CUT) + 0.5)
        if r.missing == 0 then r.profit = r.net - r.cost end
    end
    return r
end

function Cr:ReadAll(kind)
    kind = kind or self.kind
    local out = {}
    if not kind then return out end
    for i = 1, API[kind].num() do
        local r = self:ReadRecipe(kind, i)
        if r then table.insert(out, r) end
        A:Pause()
    end
    return out
end

-- die besten Rezepte (mit bekanntem Gewinn)
function Cr:Top(kind, n)
    local list = {}
    for _, r in ipairs(self:ReadAll(kind)) do
        if r.profit then table.insert(list, r) end
    end
    table.sort(list, function(a, b) return a.profit > b.profit end)
    local out = {}
    for k = 1, math.min(n or 10, #list) do out[k] = list[k] end
    return out, #list
end

-- Materialien für "times"-mal herstellen auf eine Einkaufsliste (Name = Beruf)
function Cr:ReagentsToList(kind, index, times)
    local r = self:ReadRecipe(kind, index)
    if not r then return false, L["Kein Rezept gewählt."] end
    times = math.max(1, math.floor(tonumber(times) or 1))
    local listName = API[kind].title() or L["Berufe"]
    if not A.Lists:Exists(listName) then A.Lists:Create(listName) end
    local added = 0
    for _, re in ipairs(r.reagents) do
        if re.itemID then
            A.Lists:AddItem(listName, tostring(re.itemID), re.count * times)
            added = added + 1
        end
    end
    if added == 0 then return false, L["Keine Materialien mit bekanntem Item gefunden."] end
    return true, string.format(L["Materialien für %dx %s auf die Liste '%s' gesetzt."], times, r.name, listName), listName
end

-- Nur was fehlt: Bedarf minus Bestand (Taschen, Bank, alle Twinks) auf die Einkaufsliste
function Cr:MissingToList(kind, index, times)
    local r = self:ReadRecipe(kind, index)
    if not r then return false, L["Kein Rezept gewählt."] end
    times = math.max(1, math.floor(tonumber(times) or 1))
    local listName = API[kind].title() or L["Berufe"]
    local added, complete = 0, 0
    for _, re in ipairs(r.reagents) do
        if re.itemID then
            local need = re.count * times
            local have = re.have or 0
            if A.Chars and A.Chars.ItemCounts then
                -- eigene Taschen live (re.have), dazu eigene Bank und alle Twinks
                for _, c in ipairs((A.Chars:ItemCounts(re.itemID))) do
                    if c.me then have = have + (c.bank or 0) else have = have + (c.bags or 0) + (c.bank or 0) end
                end
            end
            local missing = need - have
            if missing > 0 then
                if not A.Lists:Exists(listName) then A.Lists:Create(listName) end
                A.Lists:AddItem(listName, tostring(re.itemID), missing)
                added = added + 1
            else
                complete = complete + 1
            end
        end
    end
    if added == 0 then
        return true, string.format(L["Du hast schon alles für %dx %s (Taschen, Bank und Twinks)."], times, r.name)
    end
    return true, string.format(L["Fehlende Materialien für %dx %s auf die Liste '%s' gesetzt (%d schon vorhanden)."], times, r.name, listName, complete), listName
end

-- ------------------------------------------------------------
-- Fenster neben dem Berufsfenster
-- ------------------------------------------------------------
function Cr:Enabled()
    return not (A.db and A.db.settings.craftPanel == false)
end

-- Schnittstelle für andere Addons (ProfessionSentinel dockt rechts daran an): das sichtbare Gewinn-Fenster am
-- Berufsfenster oder nil. Stabil halten. Hinweis: Nach einem Design-Wechsel wird der Rahmen neu gebaut -
-- deshalb jedes Mal neu abfragen statt den Rahmen dauerhaft zu merken.
-- includeHidden = true: den Rahmen auch verborgen liefern (zum Einhängen in OnShow/OnHide), nil = noch nicht gebaut.
function Cr:GetDockFrame(includeHidden)
    local f = self.panel
    if not f then return nil end
    if includeHidden then return f end
    if f.IsShown and f:IsShown() then return f end
    return nil
end

function Cr:EnsurePanel()
    if self.panel then return self.panel end
    local UI = A.UI
    local C = UI.C
    local f = CreateFrame("Frame", "AHAnalyzerProCraftPanel", UIParent)
    f:SetSize(300, 456)
    f:SetFrameStrata("HIGH")
    f:EnableMouse(true)
    UI:Box(f, C.bg, C.frameEdge, UI:IsClassic() and 2 or 1)
    f:Hide()

    f.title = UI:Label(f, "|cff00d1d1AHSentinel|r  " .. L["Gewinn"], "GameFontNormal", C.accent)
    f.title:SetPoint("TOPLEFT", 12, -10)
    f.close = UI:CloseButton(f, function() f:Hide(); Cr.closedByUser = true end)
    f.close:SetPoint("TOPRIGHT", -4, -4)

    f.recipe = UI:Label(f, "", "GameFontNormalSmall", C.text)
    f.recipe:SetPoint("TOPLEFT", 12, -34)
    f.recipe:SetWidth(276)
    if f.recipe.SetWordWrap then f.recipe:SetWordWrap(false) end

    local function row(label, y)
        local l = UI:Label(f, label, "GameFontHighlightSmall", C.textDim)
        l:SetPoint("TOPLEFT", 12, y)
        local v = UI:Label(f, "-", "GameFontHighlightSmall", C.text)
        v:SetPoint("TOPRIGHT", -12, y)
        v:SetJustifyH("RIGHT")
        v:SetWidth(150)
        return v
    end
    f.cost = row(L["Materialkosten"], -54)
    f.value = row(L["Wert des Ergebnisses"], -70)
    f.cut = row(L["AH-Gebühr (5 %)"], -86)
    f.profit = row(L["Gewinn"], -104)
    f.note = UI:Label(f, "", "GameFontDisableSmall", C.textDim)
    f.note:SetPoint("TOPLEFT", 12, -122)
    f.note:SetWidth(276)

    f.times = UI:EditBox(f, 44, 22, "1")
    f.times:SetPoint("TOPLEFT", 12, -142)
    f.times:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    f.listBtn = UI:Button(f, L["Materialien als Einkaufsliste"], 226, 22, function()
        local idx = API[Cr.kind or "trade"].selected()
        local ok, msg, listName = Cr:ReagentsToList(Cr.kind, idx, tonumber(f.times:GetText()) or 1)
        A:Print(msg)
        if ok and A.UI.ShowLists then A.UI:ShowLists(listName) end
    end)
    f.listBtn:SetPoint("LEFT", f.times, "RIGHT", 6, 0)
    f.listBtn.tooltip = L["Legt die Materialien (x Anzahl links) als Einkaufsliste an.\nDort: Preise prüfen und als Sniper-Ziele kaufen."]
    f.missBtn = UI:Button(f, L["Nur was mir fehlt"], 226, 22, function()
        local idx = API[Cr.kind or "trade"].selected()
        local ok, msg, listName = Cr:MissingToList(Cr.kind, idx, tonumber(f.times:GetText()) or 1)
        A:Print(msg)
        if ok and listName and A.UI.ShowLists then A.UI:ShowLists(listName) end
    end, "primary")
    f.missBtn:SetPoint("TOPLEFT", f.listBtn, "BOTTOMLEFT", 0, -4)
    f.missBtn.tooltip = L["Wie oben, aber nur die fehlende Menge: Bedarf minus das,\nwas du in Taschen, Bank und bei deinen Twinks hast."]

    local th = UI:Label(f, L["Beste Rezepte (Gewinn)"], "GameFontNormalSmall", C.accent)
    th:SetPoint("TOPLEFT", 12, -202)
    f.top = UI:Table(f, {
        columns = {
            { key = "name", title = L["Rezept"], width = 150 },
            { key = "profit", title = L["Gewinn"], width = 98, align = "RIGHT" },
        },
        rows = 9,
        rowHeight = 20,
        itemTooltip = false,
        noMenu = true,
        idKey = "index",
        cell = function(r, key)
            if key == "name" then return r.name end
            local v = r.profit
            return v >= 0 and ("|cff33dd55" .. A:FormatMoney(v, true) .. "|r") or ("|cffff5544-" .. A:FormatMoney(-v, true) .. "|r")
        end,
        onClick = function(r) Cr:SelectRecipe(r) end,
        emptyText = L["Noch keine Preise.\nErst im Auktionshaus scannen."],
    })
    f.top:SetPoint("TOPLEFT", 10, -218)
    self.panel = f

    -- Auswahl im Berufsfenster verfolgen
    local last, acc = nil, 0
    f:SetScript("OnUpdate", function(_, dt)
        acc = acc + (dt or 0)
        if acc < 0.3 then return end
        acc = 0
        local idx = Cr.kind and API[Cr.kind].selected()
        if idx ~= last then last = idx; Cr:RefreshDetail() end
    end)
    return f
end

-- Oberer Teil (gewähltes Rezept): billig, sofort
function Cr:RefreshDetail()
    local f = self.panel
    if not f or not f:IsShown() or not self.kind then return end
    local api = API[self.kind]
    local idx = api.selected()
    local r = idx and self:ReadRecipe(self.kind, idx)
    if r then
        f.recipe:SetText(r.name .. ((r.made ~= 1) and string.format("  (x%g)", r.made) or ""))
        f.cost:SetText(r.missing > 0 and (A:FormatMoney(r.cost) .. " |cffff5544+?|r") or A:FormatMoney(r.cost))
        f.value:SetText(r.value and A:FormatMoney(r.value) or "-")
        f.cut:SetText(r.value and A:FormatMoney(r.value - r.net) or "-")
        if r.profit then
            f.profit:SetText(r.profit >= 0 and ("|cff33dd55" .. A:FormatMoney(r.profit) .. "|r") or ("|cffff5544-" .. A:FormatMoney(-r.profit) .. "|r"))
        else
            f.profit:SetText("-")
        end
        local notes = {}
        if not r.productID then table.insert(notes, L["Ergebnis ist kein Item (z.B. Verzauberung) - nur Kosten."])
        elseif not r.value then table.insert(notes, L["Für das Ergebnis gibt es noch keinen Preis."]) end
        if r.missing > 0 then table.insert(notes, string.format(L["%d Materialien ohne Preis (z.B. nur beim Händler)."], r.missing)) end
        f.note:SetText(table.concat(notes, "\n"))
    else
        f.recipe:SetText(L["Kein Rezept gewählt."])
        for _, v in ipairs({ f.cost, f.value, f.cut, f.profit }) do v:SetText("-") end
        f.note:SetText("")
    end
    -- Rangliste nur aus dem Zwischenspeicher zeichnen (die Zeilen behalten ihr Rezept, ein Klick geht nicht verloren)
    f.top.selectedID = idx
    f.top:Render()
end

-- Rangliste "Beste Rezepte": nur neu rechnen, wenn sich etwas geändert hat (Liste, Taschen, Preise), verteilt
-- über mehrere Frames (A:Job, höchstens A.FRAME_BUDGET ms pro Frame). Bis dahin bleibt die alte Liste stehen.
Cr.topBuilds = 0
function Cr:Refresh()
    local f = self.panel
    if not f or not f:IsShown() or not self.kind then return end
    self:RefreshDetail()
    if self.topKind ~= self.kind then self.topDirty = true end
    if not self.topDirty then return end
    self.topDirty = false
    local kind = self.kind
    self.topBuilding = true
    A:Job("craft-top", function()
        local top = Cr:Top(kind, 9)
        Cr.topBuilds = Cr.topBuilds + 1
        Cr.topBuilding = nil
        if Cr.kind ~= kind or not Cr.panel then return end
        Cr.topKind = kind
        Cr.panel.top.selectedID = API[kind].selected()
        Cr.panel.top:SetData(top, true)
    end)
end

-- Ereignisse sammeln: höchstens alle 0,4 s neu aufbauen
Cr.REFRESH_DELAY = 0.4
function Cr:RequestRefresh(dataChanged)
    if dataChanged then self.topDirty = true end
    if self.refreshPlanned then return end
    self.refreshPlanned = true
    C_Timer.After(self.REFRESH_DELAY, function()
        Cr.refreshPlanned = nil
        Cr:Refresh()
    end)
end

-- Klick auf ein Rezept: im Berufsfenster öffnen. Die Zeile trägt Name und Rezept-ID, die aktuelle Nummer wird beim
-- Klick neu gesucht (Filter und zugeklappte Kategorien verschieben die Liste). Klappt es nicht, werden Suchtext und
-- Filter zurückgesetzt bzw. Kategorien aufgeklappt und es wird noch einmal versucht; sonst eine Meldung im Chat.
function Cr:IsSelected(r)
    local api = API[r.kind]
    local idx = api and api.selected()
    if not idx then return false end
    if r.kind == "modern" then return ModernIDs()[idx] == r.recipeID end
    local name, kind = api.info(idx)
    return name == r.name and kind ~= "header"
end

function Cr:SelectRecipe(r)
    if not (r and r.kind and API[r.kind]) then return false end
    local api = API[r.kind]
    local function try()
        local idx = (api.find and api.find(r)) or (not api.find and r.index) or nil
        if not idx then return false end
        api.select(idx)
        if api.scrollTo then api.scrollTo(idx) end
        return true
    end
    self.pendingSelect = r
    local before = api.selected()
    local started = try()
    local after = api.selected()
    local function check(step)
        if Cr.pendingSelect ~= r then return end
        if Cr:IsSelected(r) then
            Cr.pendingSelect = nil
            Cr:RefreshDetail()
            return
        end
        -- inzwischen selbst ein anderes Rezept gewählt: nichts überschreiben
        local now = api.selected()
        if now ~= before and now ~= after then Cr.pendingSelect = nil; return end
        if step == 1 and api.reveal then
            pcall(api.reveal)
            try()
            after = api.selected()
            C_Timer.After(0.3, function() check(2) end)
            return
        end
        Cr.pendingSelect = nil
        A:Print(string.format(L["Rezept konnte im Berufsfenster nicht geöffnet werden: %s"], tostring(r.name)))
    end
    -- der moderne Weg wählt verzögert: kurz warten, dann prüfen
    C_Timer.After(started and 0.3 or 0, function() check(1) end)
    return true
end

-- Wie weit ragen sichtbare Teile des Berufsfensters rechts über seinen Rand hinaus? (z. B. die senkrechte
-- Reiterleiste der Berufe in WoW Forever). Liefert den Überstand in Bildschirm-Pixeln (0 = nichts).
-- Gesucht wird in den Kind-Rahmen des Fensters (bis 3 Ebenen tief), die neben dem Fenster liegen.
function Cr:RightOverhang(parent)
    if not (parent and parent.GetRight and parent.GetChildren) then return 0 end
    local okR, pr = pcall(parent.GetRight, parent)
    local okT, pt = pcall(parent.GetTop, parent)
    local okB, pb = pcall(parent.GetBottom, parent)
    if not (okR and pr and okT and pt and okB and pb) then return 0 end
    local ps = parent:GetEffectiveScale()
    local edge, top, bottom = pr * ps, pt * ps, pb * ps
    local best = 0
    local function scan(fr, depth)
        if depth > 3 then return end
        local kids = { pcall(fr.GetChildren, fr) }
        for i = 2, #kids do
            local c = kids[i]
            if type(c) == "table" and c ~= self.panel and c.IsShown and c:IsShown() then
                local ok1, r = pcall(c.GetRight, c)
                local ok2, l = pcall(c.GetLeft, c)
                local ok3, t = pcall(c.GetTop, c)
                local ok4, b = pcall(c.GetBottom, c)
                if ok1 and r and ok2 and l and ok3 and t and ok4 and b then
                    local cs = c:GetEffectiveScale()
                    r, l, t, b = r * cs, l * cs, t * cs, b * cs
                    -- rechts herausragend, neben dem Fenster (gleiche Höhe), nicht riesig (kein Vollbild-Rahmen)
                    if r > edge + 1 and l < edge + 80 and b < top and t > bottom and r - l < 200 then
                        if r - edge > best then best = r - edge end
                    end
                end
                if c.GetChildren then scan(c, depth + 1) end
            end
        end
    end
    pcall(scan, parent, 1)
    return best
end

-- Gewinn-Fenster rechts ans Berufsfenster - neben eine Reiterleiste, nie darüber
function Cr:Dock(f, parent)
    f = f or self.panel
    if not f then return end
    f:ClearAllPoints()
    if not parent then f:SetPoint("CENTER", 300, 0); return end
    local over = self:RightOverhang(parent)
    local x = -30                                         -- wie bisher: leicht über den Rahmen des Fensters
    if over > 0 then x = over / f:GetEffectiveScale() + 4 end
    f:SetPoint("TOPLEFT", parent, "TOPRIGHT", x, -12)
    self.dockOffset = x
end

function Cr:Open(kind)
    self.kind = kind
    pcall(self.Remember, self, kind)
    if not self:Enabled() or self.closedByUser then return end
    local f = self:EnsurePanel()
    local parent = API[kind].frame()
    self:Dock(f, parent)
    f:Show()
    self.topDirty = true
    self:Refresh()
    -- die Reiterleiste baut das Spiel teils erst nach dem Öffnen auf: kurz danach noch einmal ausrichten
    if parent and C_Timer and C_Timer.After then
        C_Timer.After(0.3, function()
            if Cr.panel and Cr.panel:IsShown() and Cr.kind == kind then Cr:Dock(Cr.panel, API[kind].frame()) end
        end)
    end
end

function Cr:Close(kind)
    if kind and self.kind ~= kind then return end
    self.kind = nil
    self.closedByUser = nil
    if self.panel then self.panel:Hide() end
end

-- ------------------------------------------------------------
-- Rezepte merken (für "Heute tun" ohne ProfessionSentinel)
-- Beim Öffnen des Berufsfensters werden die bekannten Rezepte pro Charakter gespeichert:
-- Ergebnis, Menge, Zutaten. Preise kommen später immer frisch aus den Scans.
-- ------------------------------------------------------------
local function RecipeDB()
    if not A.db then return nil end
    A.db.recipes = A.db.recipes or {}
    local key = A.Chars and A.Chars:Key() or ((UnitName and UnitName("player")) or "?")
    A.db.recipes[key] = A.db.recipes[key] or {}
    return A.db.recipes[key]
end

function Cr:Remember(kind)
    kind = kind or self.kind
    if not kind then return 0 end
    local db = RecipeDB()
    if not db then return 0 end
    local api = API[kind]
    local title = api.title() or kind
    local list = {}
    for i = 1, api.num() do
        local name, skillType = api.info(i)
        if name and skillType ~= "header" then
            local productID = IDFromLink(api.link(i))
            local lo, hi = api.made(i)
            local rec = { name = name, productID = productID, made = ((lo or 1) + (hi or lo or 1)) / 2, reagents = {} }
            local ok = productID ~= nil
            for k = 1, api.numReagents(i) do
                local _, count, _, link = api.reagent(i, k)
                local id = IDFromLink(link)
                if not id then ok = false; break end
                table.insert(rec.reagents, { id, count or 1 })
            end
            if ok and #rec.reagents > 0 then table.insert(list, rec) end
            if #list >= 500 then break end
        end
    end
    if #list > 0 then db[title] = { t = time(), list = list } end
    return #list
end

function Cr:KnownRecipes()
    local db = RecipeDB()
    local out = {}
    for prof, e in pairs(db or {}) do
        for _, r in ipairs(e.list or {}) do r.prof = prof; table.insert(out, r) end
    end
    return out
end

-- Herstellen, das sich heute lohnt (nur Rezepte, die dieser Charakter kann):
-- Ergebnis verkaufbar (verlässlicher Marktwert, verkauft sich), Erlös nach 5 % AH-Anteil
-- abzüglich Zutaten (Händler, wenn billiger) mindestens 10 % über den Kosten.
function Cr:TodaySuggestions(max)
    local out = {}
    for _, r in ipairs(self:KnownRecipes()) do
        A:Pause()
        local sale = A:GetSalePrice(r.productID)
        local reliable, l = A:IsReliable(r.productID)
        if sale and reliable and (l.perDay or 0) >= 0.5 then
            local cost, ok = 0, true
            local reagents = {}
            for _, re in ipairs(r.reagents) do
                local unit, atVendor = self:UnitPrice(re[1], true)
                if not unit then ok = false; break end
                cost = cost + unit * re[2]
                table.insert(reagents, { itemID = re[1], count = re[2], unit = unit, atVendor = atVendor })
            end
            if ok then
                local net = sale * (r.made or 1) * (1 - AH_CUT) - A:ExpectedDepositLoss(r.productID, 1)
                local profit = math.floor(net - cost)
                if profit > 0 and profit >= cost * 0.10 then
                    local count = math.max(1, math.min(5, math.floor((l.perDay or 1) * (A.MARKET_SHARE or 0.25) + 0.5)))
                    table.insert(out, { recipe = r, productID = r.productID, name = r.name, count = count, profit = profit,
                                        cost = math.floor(cost), reagents = reagents })
                end
            end
        end
    end
    table.sort(out, function(a, b) return a.profit * a.count > b.profit * b.count end)
    local res = {}
    for i = 1, math.min(max or 3, #out) do res[i] = out[i] end
    return res
end

-- Wie viele Stück eines Items hat man (Taschen, Bank, Twinks)?
function Cr:HaveCount(itemID)
    local have = A.Seller and A.Seller:CountInBags(itemID) or 0
    if A.Chars and A.Chars.ItemCounts then
        for _, c in ipairs((A.Chars:ItemCounts(itemID))) do
            if c.me then have = have + (c.bank or 0) else have = have + (c.bags or 0) + (c.bank or 0) end
        end
    end
    return have
end

-- Hat der Charakter einen Herstellungsberuf? (gemerkte Rezepte, sonst Fertigkeitenliste des Spiels)
local CRAFT_SKILLLINES = { [171] = true, [164] = true, [333] = true, [202] = true, [773] = true, [755] = true,
                           [165] = true, [197] = true, [185] = true }
local CRAFT_SPELLS = { 2259, 2018, 7411, 4036, 2108, 3908, 2550, 25229, 45357 }
function Cr:HasCraftProfession()
    local db = RecipeDB()
    if db and next(db) then return true end
    if GetProfessions and GetProfessionInfo then
        local ok, p1, p2, _, _, cook = pcall(GetProfessions)
        if ok then
            for _, idx in ipairs({ p1, p2, cook }) do
                if idx then
                    local line = select(7, GetProfessionInfo(idx))
                    if line and CRAFT_SKILLLINES[line] then return true end
                end
            end
        end
    end
    if GetNumSkillLines and GetSkillLineInfo then
        local names = {}
        for _, id in ipairs(CRAFT_SPELLS) do
            local n = (GetSpellInfo and SafeCall(GetSpellInfo, id)) or (C_Spell and C_Spell.GetSpellName and SafeCall(C_Spell.GetSpellName, id))
            if n then names[n] = true end
        end
        for i = 1, (SafeCall(GetNumSkillLines) or 0) do
            local name, isHeader = SafeCall(GetSkillLineInfo, i)
            if name and not isHeader and names[name] then return true end
        end
    end
    return false
end

local evt = CreateFrame("Frame")
Cr.evt = evt            -- für die Testroutine (Ereignisse mit Testargumenten nachspielen)
for _, e in ipairs({ "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE", "TRADE_SKILL_CLOSE", "CRAFT_SHOW", "CRAFT_UPDATE", "CRAFT_CLOSE",
                     "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_DATA_SOURCE_CHANGED" }) do
    pcall(evt.RegisterEvent, evt, e)
end
evt:SetScript("OnEvent", function(_, event)
    if event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_LIST_UPDATE" then Cr:InvalidateModern(false)
    elseif event == "TRADE_SKILL_DATA_SOURCE_CHANGED" then Cr:InvalidateModern(true) end
    -- gemerkte Auswahl gilt nur, solange dasselbe Berufsfenster offen ist
    if event == "TRADE_SKILL_CLOSE" or event == "TRADE_SKILL_DATA_SOURCE_CHANGED" then Cr.lastModernRecipe = nil end
    if event == "TRADE_SKILL_SHOW" then Cr:HookRecipeSelection(); Cr:Open(Cr:TradeKind())
    elseif event == "CRAFT_SHOW" then Cr:Open("craft")
    elseif event == "TRADE_SKILL_CLOSE" then Cr:Close(Cr.kind == "modern" and "modern" or "trade")
    elseif event == "CRAFT_CLOSE" then Cr:Close("craft")
    else
        -- neue Rezepte gelernt / Liste geladen: höchstens alle 5 Sekunden neu merken.
        -- Moderner Client: Kommt die Liste kurz nach dem Öffnen noch leer, gilt das nicht als "gemerkt" -
        -- sonst würde erst 5 Sekunden später neu gelesen. Alter Weg (TRADE_SKILL_UPDATE, CRAFT_UPDATE): wie bis 0.65.3.
        if Cr.kind and (not Cr.rememberedAt or GetTime() - Cr.rememberedAt > 5) then
            if Cr.kind == "modern" then
                local ok, n = pcall(Cr.Remember, Cr, Cr.kind)
                if ok and (n or 0) > 0 then Cr.rememberedAt = GetTime() end
            else
                Cr.rememberedAt = GetTime()
                pcall(Cr.Remember, Cr, Cr.kind)
            end
        end
        Cr:RequestRefresh(true)
    end
end)

-- Moderner Client: Auswahl im Berufsfenster über das Ereignis der Rezeptliste erfassen (Rückfall für den
-- Zutaten-Knopf, falls das Fenster das gewählte Rezept nicht selbst verrät). Fehlt das Ereignis: nichts gemerkt.
function Cr:OnRecipeSelected(recipeInfo)
    local rid = type(recipeInfo) == "table" and recipeInfo.recipeID or (type(recipeInfo) == "number" and recipeInfo) or nil
    if rid then self.lastModernRecipe = rid end
end
-- Blizzard löst das Ereignis unter dem ausgeschriebenen Namen aus:
--   EventRegistry:TriggerEvent("ProfessionsRecipeListMixin.Event.OnRecipeSelected", recipeInfo, list)
-- (ProfessionsRecipeListMixin.Event.OnRecipeSelected selbst ist nur "OnRecipeSelected" und passt nicht.)
-- EventRegistry nimmt auch noch unbekannte Ereignisse an: Anmelden geht schon beim Laden, bevor Blizzard_Professions
-- geladen ist. Ohne EventRegistry (ältere Clients) passiert nichts. Bei TRADE_SKILL_SHOW zur Sicherheit noch einmal.
Cr.RECIPE_SELECTED_EVENT = "ProfessionsRecipeListMixin.Event.OnRecipeSelected"
function Cr:HookRecipeSelection()
    if self.selectionHooked then return end
    if EventRegistry and EventRegistry.RegisterCallback then
        local ok = pcall(EventRegistry.RegisterCallback, EventRegistry, self.RECIPE_SELECTED_EVENT,
            function(_, recipeInfo) Cr:OnRecipeSelected(recipeInfo) end, Cr)
        if ok then self.selectionHooked = true end
    end
end
Cr:HookRecipeSelection()

A:On("DATA_CHANGED", function() Cr:RequestRefresh(true) end)
A:On("THEME_CHANGED", function()
    if Cr.panel then Cr.panel:Hide(); Cr.panel = nil end
    if Cr.kind then Cr:Open(Cr.kind) end
end)
