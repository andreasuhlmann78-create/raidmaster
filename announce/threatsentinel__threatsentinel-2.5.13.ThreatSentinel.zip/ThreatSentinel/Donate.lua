-- ============================================================
-- Donate.lua – Spenden-Knopf (PayPal) von GoldSentinel
-- Funktioniert in jeder WoW-Version (Retail, Classic, Anniversary, Era, WoW Forever),
-- ohne fremde Bibliotheken. WoW kann keine Webseiten öffnen: das Fenster zeigt den
-- Link markiert zum Kopieren (Strg+C), dann im Browser einfügen.
-- Öffnet sich nur auf Klick oder per Befehl - nie von selbst.
--
-- Nutzung im Addon:
--   ns.Donate.Show()                              Fenster öffnen
--   ns.Donate.CreateButton(parent, breite, höhe)  Knopf „Unterstützen“ (öffnet das Fenster)
--   ns.Donate.ICON = "Interface\\AddOns\\<Ordner>\\Media\\Icon"   (optional, eigenes Icon)
-- ============================================================

local ADDON_NAME, ns = ...
ns = ns or {}
local D = {}
ns.Donate = D

D.URL = "https://www.paypal.com/ncp/payment/46R68N2BF7BTY"
D.SIGN = "- GoldSentinel"
D.ICON = nil                         -- nil = Goldmünzen-Icon von Blizzard

local WHITE = "Interface\\Buttons\\WHITE8X8"
local ACCENT = { 0.25, 0.65, 1 }     -- Akzentfarbe von ThreatSentinel

-- Name des Addons aus der .toc (ohne Farbcodes)
local function AddonTitle()
	local API = ns.API or {}   -- ThreatSentinel: Blizzard-Funktionen über ns.API (API.lua)
	local AO = API.C_AddOns
	local get = (AO and AO.GetAddOnMetadata) or API.GetAddOnMetadata
	local t = get and get(ADDON_NAME, "Title") or ADDON_NAME
	return (tostring(t or ADDON_NAME):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
end

-- Texte in allen Client-Sprachen (%s = Name des Addons)
local TEXTS = {
	deDE = { title = "%s unterstützen", button = "Unterstützen",
	         thanks = "Danke, dass du %s unterstützt! Jede Spende hilft mir, mehr Zeit in neue Funktionen und schnelle Fehlerbehebungen zu stecken.",
	         hint = "Strg+C kopiert den PayPal-Link - dann im Browser einfügen." },
	enUS = { title = "Support %s", button = "Support",
	         thanks = "Thank you so much for supporting %s! Every donation helps me spend more time on new features and quick bug fixes.",
	         hint = "Ctrl+C copies the PayPal link - then paste it into your browser." },
	frFR = { title = "Soutenir %s", button = "Soutenir",
	         thanks = "Merci beaucoup de soutenir %s ! Chaque don m'aide à consacrer plus de temps aux nouvelles fonctions et aux corrections rapides.",
	         hint = "Ctrl+C copie le lien PayPal, puis colle-le dans ton navigateur." },
	esES = { title = "Apoyar %s", button = "Apoyar",
	         thanks = "¡Muchas gracias por apoyar %s! Cada donación me ayuda a dedicar más tiempo a nuevas funciones y correcciones rápidas.",
	         hint = "Ctrl+C copia el enlace de PayPal; pégalo luego en tu navegador." },
	itIT = { title = "Sostieni %s", button = "Sostieni",
	         thanks = "Grazie mille per sostenere %s! Ogni donazione mi aiuta a dedicare più tempo a nuove funzioni e correzioni rapide.",
	         hint = "Ctrl+C copia il link PayPal, poi incollalo nel browser." },
	ptBR = { title = "Apoiar %s", button = "Apoiar",
	         thanks = "Muito obrigado por apoiar %s! Cada doação me ajuda a dedicar mais tempo a novos recursos e correções rápidas.",
	         hint = "Ctrl+C copia o link do PayPal - depois cole no navegador." },
	ruRU = { title = "Поддержать %s", button = "Поддержать",
	         thanks = "Огромное спасибо за поддержку %s! Каждое пожертвование помогает мне уделять больше времени новым функциям и быстрым исправлениям.",
	         hint = "Ctrl+C копирует ссылку PayPal - вставь её в браузере." },
	koKR = { title = "%s 후원하기", button = "후원",
	         thanks = "%s 를 후원해 주셔서 정말 감사합니다! 모든 후원은 새 기능과 빠른 버그 수정에 더 많은 시간을 쓰는 데 도움이 됩니다.",
	         hint = "Ctrl+C로 PayPal 링크를 복사한 뒤 브라우저에 붙여넣으세요." },
	zhCN = { title = "支持 %s", button = "支持",
	         thanks = "非常感谢你支持 %s！每一笔捐助都能让我投入更多时间开发新功能和快速修复问题。",
	         hint = "按 Ctrl+C 复制 PayPal 链接，然后粘贴到浏览器中。" },
	zhTW = { title = "支持 %s", button = "支持",
	         thanks = "非常感謝你支持 %s！每一筆贊助都能讓我投入更多時間開發新功能和快速修復問題。",
	         hint = "按 Ctrl+C 複製 PayPal 連結，然後貼到瀏覽器中。" },
}
TEXTS.esMX = TEXTS.esES
TEXTS.enGB = TEXTS.enUS

local function T(key)
	local loc = (D.locale or (GetLocale and GetLocale()) or "enUS")
	local set = TEXTS[loc] or TEXTS.enUS
	return set[key] or TEXTS.enUS[key]
end
D.Text = T

local frame

-- Fenster im Design von ThreatSentinel (dunkel, flach, blaue Akzente)
local function Build()
	local f = CreateFrame("Frame", ADDON_NAME .. "DonateFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	f:SetSize(470, 210)
	f:SetPoint("CENTER")
	f:SetFrameStrata("FULLSCREEN_DIALOG")
	f:SetToplevel(true)
	f:SetClampedToScreen(true)
	f:EnableMouse(true)
	f:SetMovable(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", f.StartMoving)
	f:SetScript("OnDragStop", f.StopMovingOrSizing)
	if f.SetBackdrop then
		f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
		f:SetBackdropColor(0.05, 0.06, 0.08, 0.97)
		f:SetBackdropBorderColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.7)
	else
		local bg = f:CreateTexture(nil, "BACKGROUND")
		bg:SetAllPoints()
		bg:SetColorTexture(0.05, 0.06, 0.08, 0.97)
	end
	if UISpecialFrames then table.insert(UISpecialFrames, f:GetName()) end      -- Esc schließt

	-- Titelleiste
	local bar = f:CreateTexture(nil, "ARTWORK")
	bar:SetTexture(WHITE)
	bar:SetVertexColor(0.09, 0.11, 0.15, 1)
	bar:SetPoint("TOPLEFT", 1, -1)
	bar:SetPoint("TOPRIGHT", -1, -1)
	bar:SetHeight(32)

	f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	f.title:SetPoint("LEFT", bar, "LEFT", 12, 0)
	f.title:SetTextColor(ACCENT[1] + 0.15, ACCENT[2] + 0.1, 1)

	local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
	close:SetPoint("RIGHT", bar, "RIGHT", -2, 0)

	local icon = f:CreateTexture(nil, "ARTWORK")
	icon:SetSize(36, 36)
	icon:SetPoint("TOPLEFT", 20, -48)
	f.icon = icon

	f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	f.text:SetPoint("TOPLEFT", icon, "TOPRIGHT", 12, 0)
	f.text:SetPoint("RIGHT", f, "RIGHT", -20, 0)
	f.text:SetJustifyH("LEFT")
	if f.text.SetWordWrap then f.text:SetWordWrap(true) end

	local eb = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
	eb:SetSize(410, 24)
	eb:SetPoint("TOPLEFT", 32, -126)
	eb:SetAutoFocus(false)
	eb:SetFontObject(ChatFontNormal or GameFontHighlight)
	-- nur zum Kopieren: Änderungen sofort zurücknehmen
	eb:SetScript("OnTextChanged", function(self, user)
		if user and self:GetText() ~= D.URL then self:SetText(D.URL); self:HighlightText() end
	end)
	eb:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
	eb:SetScript("OnEscapePressed", function() f:Hide() end)
	eb:SetScript("OnEnterPressed", function() f:Hide() end)
	f.edit = eb

	f.hint = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	f.hint:SetPoint("TOPLEFT", eb, "BOTTOMLEFT", -4, -8)

	f.sign = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	f.sign:SetPoint("BOTTOMRIGHT", -20, 14)
	f.sign:SetText(D.SIGN)
	f:Hide()
	return f
end

function D.Show()
	frame = frame or Build()
	local title = AddonTitle()
	frame.title:SetText(string.format(T("title"), title))
	frame.text:SetText(string.format(T("thanks"), title))
	frame.hint:SetText(T("hint"))
	frame.icon:SetTexture(D.ICON or "Interface\\Icons\\INV_Misc_Coin_01")
	frame:Show()
	frame.edit:SetText(D.URL)
	frame.edit:SetFocus()
	frame.edit:HighlightText()
	return frame
end

function D.Toggle()
	if frame and frame:IsShown() then frame:Hide() else D.Show() end
end

-- Knopf „Unterstützen“ für Titelleiste, Optionen o. Ä.
function D.CreateButton(parent, width, height)
	local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
	b:SetSize(width or 100, height or 22)
	b:SetText(T("button"))
	b:SetScript("OnClick", function() D.Show() end)
	b:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
		GameTooltip:SetText(string.format(T("title"), AddonTitle()), 1, 1, 1)
		GameTooltip:AddLine("PayPal", 0.8, 0.8, 0.8)
		GameTooltip:Show()
	end)
	b:SetScript("OnLeave", function() GameTooltip:Hide() end)
	return b
end
