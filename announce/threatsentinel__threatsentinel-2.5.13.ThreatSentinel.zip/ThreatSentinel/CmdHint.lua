-- ThreatSentinel - CmdHint.lua
-- Befehlsliste beim Tippen (BL, Wunsch des Nutzers 13.11.2026). Baustein: AHSentinel CmdHint.lua (Stand 0.65.104,
-- CH1–CH5 von der Prüf-Sitzung abgenommen), angepasst an ThreatSentinel.
--
-- Tippt man im Chat "/ts" oder "/threatsentinel", erscheint über dem Eingabefeld die Liste SÄMTLICHER Befehle aus
-- ns.COMMANDS (dieselbe Tabelle, aus der der Slash-Handler ausführt, Core.lua) mit kurzer Beschreibung in der
-- Spielsprache. Jeder weitere Buchstabe filtert ("/ts l" = log …, "/ts te" = test, testroutine …); meistbenutzte oben
-- (Zähler ns.db.cmdUse). Entwickler-Befehle (Feld dev) nur, wenn GoldSentinelDev den Entwickler erkennt.
--
-- Bedienung (shared/vorlage/README.md "Befehlsliste beim Tippen"): Mausklick bzw. Tab WÄHLT einen Eintrag aus
-- (hervorgehoben, Kopf "Enter = /ts …"), Enter FÜHRT AUS – der Slash-Handler nimmt die frische Auswahl (≤ 10 s) statt
-- des unvollständigen Worts. Die Liste schliesst beim Fokusverlust erst verzögert und nicht, solange der Klick
-- ankommt; danach geht der Fokus mit SetFocus zurück ins Chatfeld. Pfeiltasten werden nicht eingehakt (das Chatfeld
-- nutzt sie für den Verlauf).
--
-- SICHERHEIT (Taint): Das Chat-Eingabefeld wird NIE beschrieben – kein SetText, kein Insert, kein eigenes
-- OnEnterPressed, keine ersetzte Blizzard-Funktion. Nur HookScript (lesen): OnTextChanged, OnEditFocusLost,
-- OnTabPressed, OnHide. Im Kampf keine Liste. Abschaltbar in den Einstellungen (ns.db.cmdHint).

local ADDON, ns = ...
local L = ns.L
local API = ns.API

local H = { MAX_ROWS = 10, ROW_H = 18, WIDTH = 420, SELECT_SECONDS = 10 }
ns.CmdHint = H
H.prefixes = { "/threatsentinel", "/ts" }   -- längster zuerst
H.display = "/ts"

local function Now() return (GetTime and GetTime()) or time() end
local function Words(s)
	local out = {}
	for w in tostring(s or ""):lower():gmatch("%S+") do out[#out + 1] = w end
	return out
end

------------------------------------------------------------
-- Logik (ohne Fenster – prüfbar)
------------------------------------------------------------
-- Text des Eingabefelds -> Rest nach dem Befehl ("" = nur "/ts"), nil = kein ThreatSentinel-Befehl
function H:Match(text)
	if type(text) ~= "string" or ns.IsSecret(text) then return nil end
	local t = text:lower()
	for _, p in ipairs(self.prefixes) do
		if t == p then return "" end
		if t:sub(1, #p + 1) == p .. " " then return (t:sub(#p + 2):gsub("^%s+", "")) end
	end
	return nil
end

function H:Commands() return ns.COMMANDS or {} end
function H:IsGerman() return ns.activeLocale == "deDE" end
function H:IsDev() return ns:IsDev() and true or false end
function H:Store()
	local db = ns.db
	if type(db) ~= "table" then return nil end
	if type(db.cmdUse) ~= "table" then db.cmdUse = {} end
	return db.cmdUse
end

-- Beschreibung eines Eintrags in der aktiven Sprache (mit %s für den Bereich der Testroutine)
function H:Describe(c)
	local text = L[c[3]] or c[3]
	if c.descArg then
		local ok, s = pcall(string.format, text, c.descArg)
		text = ok and s or text
	end
	return text
end

-- Zähler (L3): je Eintrag sein deutsches Wort
function H:Count(c)
	if type(c) ~= "table" or ns.routineRunning and not self.countInRoutine then return nil end
	local st = self:Store()
	if not st then return nil end
	st[c[1]] = (st[c[1]] or 0) + 1
	return c[1]
end

-- passt der getippte Rest zum Anfang eines der Wörter des Eintrags?
local function Hit(c, rest)
	if rest == "" then return true end
	local forms = { c[1], c[2] }
	for _, a in ipairs(c.alias or {}) do forms[#forms + 1] = a end
	for _, f in ipairs(forms) do
		if f:lower():sub(1, #rest) == rest then return true end
	end
	return false
end

-- Liste für den getippten Rest: { { cmd = "/ts log an", run = "log an", text = "...", uses = n, order = i, entry = c } }
function H:List(rest)
	rest = tostring(rest or ""):lower():gsub("^%s+", ""):gsub("%s+", " ")
	local german, dev = self:IsGerman(), self:IsDev()
	local st = self:Store() or {}
	local out = {}
	for i, c in ipairs(self:Commands()) do
		if (dev or not c.dev) and Hit(c, rest) then
			local word = german and c[1] or c[2]
			out[#out + 1] = { cmd = self.display .. " " .. word, run = word, text = self:Describe(c),
				uses = st[c[1]] or 0, order = i, entry = c }
		end
	end
	table.sort(out, function(a, b)
		if a.uses ~= b.uses then return a.uses > b.uses end
		return a.order < b.order
	end)
	return out
end

function H:Allowed()
	if not ns.db or ns.db.cmdHint == false then return false end
	if API.InCombatLockdown and API.InCombatLockdown() then return false end
	return true
end

-- Auswahl (10 s gültig). Danach den Fokus zurück ins Chatfeld (nur SetFocus, nie SetText/Insert).
function H:Select(item, byMouse)
	if not item then return end
	self.selected = { item = item, t = Now() }
	if byMouse then self.clickAt = Now() end
	self:Draw()
	local box = self.editBox or self.lastBox
	if box and box.SetFocus and box.IsShown and box:IsShown() then pcall(box.SetFocus, box) end
end
function H:Selection()
	local s = self.selected
	if s and Now() - s.t <= self.SELECT_SECONDS then return s end
	return nil
end
-- Enter schickt den getippten Text an den Slash-Handler: passt er zum Anfang der frischen Auswahl, gilt die Auswahl
function H:Resolve(msg)
	local s = self:Selection()
	if not s then return msg end
	local typed = tostring(msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
	local run = tostring(s.item.run or ""):lower()
	self.selected = nil
	if typed == "" or run:sub(1, #typed) == typed then return run end
	return msg
end
-- Tab wählt den nächsten Eintrag (Umschalt+Tab den vorigen)
function H:SelectNext(step)
	local items = self.items or {}
	if #items == 0 then return end
	local cur = 0
	local s = self:Selection()
	for i, it in ipairs(items) do if s and s.item == it then cur = i end end
	local nx = ((cur - 1 + (step or 1)) % #items) + 1
	self:Select(items[nx], false)
end

------------------------------------------------------------
-- Fenster
------------------------------------------------------------
function H:EnsureFrame()
	if self.frame then return self.frame end
	local f = CreateFrame("Frame", "ThreatSentinelCmdHint", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	f:SetFrameStrata("DIALOG")
	f:SetClampedToScreen(true)
	if f.SetBackdrop then
		f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
		f:SetBackdropColor(0.05, 0.07, 0.1, 0.95)
		f:SetBackdropBorderColor(0.25, 0.65, 1, 0.8)
	end
	f:EnableMouseWheel(true)
	f:SetScript("OnMouseWheel", function(_, delta)
		H.offset = math.max(0, math.min((H.offset or 0) - delta, math.max(0, #(H.items or {}) - H.MAX_ROWS)))
		H:Draw()
	end)
	f.rows = {}
	for i = 1, self.MAX_ROWS do
		local b = CreateFrame("Button", nil, f)
		b:SetHeight(self.ROW_H)
		b:SetPoint("TOPLEFT", 4, -4 - (i - 1) * self.ROW_H)
		b:SetPoint("TOPRIGHT", -4, -4 - (i - 1) * self.ROW_H)
		local hl = b:CreateTexture(nil, "HIGHLIGHT")
		hl:SetAllPoints()
		hl:SetColorTexture(0.25, 0.65, 1, 0.15)
		b.sel = b:CreateTexture(nil, "BACKGROUND")
		b.sel:SetAllPoints()
		b.sel:SetColorTexture(0.25, 0.65, 1, 0.30)
		b.sel:Hide()
		b.cmd = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		b.cmd:SetPoint("LEFT", 4, 0)
		b.cmd:SetWidth(170)
		b.cmd:SetJustifyH("LEFT")
		b.desc = b:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
		b.desc:SetPoint("LEFT", b.cmd, "RIGHT", 6, 0)
		b.desc:SetPoint("RIGHT", -4, 0)
		b.desc:SetJustifyH("LEFT")
		if b.desc.SetWordWrap then b.desc:SetWordWrap(false) end
		-- Klick = auswählen (nicht ausführen); Enter im Chat führt aus
		b:SetScript("OnClick", function(self) if self.item then H:Select(self.item, true) end end)
		f.rows[i] = b
	end
	f.empty = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	f.empty:SetPoint("TOPLEFT", 8, -6)
	f.head = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	f.head:SetPoint("BOTTOMLEFT", f, "TOPLEFT", 4, 2)
	f.head:SetText("")
	f:Hide()
	self.frame = f
	return f
end

function H:Draw()
	local f = self.frame
	if not f then return end
	local items = self.items or {}
	local n = math.min(#items, self.MAX_ROWS)
	for i, b in ipairs(f.rows) do
		local it = items[i + (self.offset or 0)]
		if i <= n and it then
			b.item = it
			b.cmd:SetText("|cff3fa7ff" .. it.cmd .. "|r")
			b.desc:SetText(it.text)
			local s = self:Selection()
			if s and s.item == it then b.sel:Show() else b.sel:Hide() end
			b:Show()
		else
			b.item = nil
			b:Hide()
		end
	end
	local s = self:Selection()
	f.head:SetText(s and string.format(L.CH_ENTER, s.item.cmd) or "")
	if #items == 0 then
		f.empty:SetText(L.CH_NOMATCH)
		f.empty:Show()
		f:SetHeight(self.ROW_H + 8)
	else
		f.empty:Hide()
		f:SetHeight(n * self.ROW_H + 8)
	end
end

function H:Show(editBox, rest)
	local f = self:EnsureFrame()
	self.items = self:List(rest)
	self.offset = 0
	self.editBox = editBox
	self.lastBox = editBox or self.lastBox
	f:ClearAllPoints()
	local w = math.max(self.WIDTH, (editBox and editBox.GetWidth and editBox:GetWidth()) or 0)
	f:SetWidth(w)
	if editBox then f:SetPoint("BOTTOMLEFT", editBox, "TOPLEFT", 0, 2)
	else f:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 120) end
	self:Draw()
	f:Show()
end

function H:Hide()
	if self.frame then self.frame:Hide() end
	self.editBox = nil
end

-- Fokusverlust schliesst erst verzögert und nicht, wenn gerade in der Liste geklickt wurde
function H:OnFocusLost(box)
	if self.editBox ~= box then return end
	local function close()
		if self.clickAt and Now() - self.clickAt < 0.5 then return end
		if self.frame and self.frame:IsShown() and self.frame.IsMouseOver and self.frame:IsMouseOver() then return end
		if self.editBox == box then self:Hide() end
	end
	if API.C_Timer and API.C_Timer.After and not self.instantClose then API.C_Timer.After(0.3, close) else close() end
end

-- Eingabefeld hat sich geändert (nur lesen)
function H:OnText(editBox)
	if not self:Allowed() then return self:Hide() end
	local ok, text = pcall(editBox.GetText, editBox)
	if not ok then return self:Hide() end
	local rest = self:Match(text)
	if not rest then return self:Hide() end
	self:Show(editBox, rest)
end

------------------------------------------------------------
-- Einhaken (nur HookScript, nie SetText/Insert/SetScript am Chatfeld)
------------------------------------------------------------
H.hooked = {}
function H:HookBox(box)
	if type(box) ~= "table" or not box.HookScript or self.hooked[box] then return end
	self.hooked[box] = true
	box:HookScript("OnTextChanged", function(b) pcall(H.OnText, H, b) end)
	box:HookScript("OnEditFocusLost", function(b) pcall(H.OnFocusLost, H, b) end)
	box:HookScript("OnTabPressed", function(b)
		if H.editBox == b and H.frame and H.frame:IsShown() then
			H:SelectNext(API.IsShiftKeyDown and API.IsShiftKeyDown() and -1 or 1)
		end
	end)
	box:HookScript("OnHide", function(b) if H.editBox == b then H:Hide() end end)
end

function H:HookAll()
	local n = NUM_CHAT_WINDOWS or 10
	for i = 1, n do self:HookBox(_G["ChatFrame" .. i .. "EditBox"]) end
	self:HookBox(_G.ChatFrameEditBox)            -- sehr alte Clients: ein gemeinsames Eingabefeld
end

ns:On("PLAYER_LOGIN", function() pcall(H.HookAll, H) end)
ns:On("PLAYER_REGEN_DISABLED", function() H:Hide() end)
