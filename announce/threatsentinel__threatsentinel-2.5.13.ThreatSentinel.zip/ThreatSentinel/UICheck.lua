-- ThreatSentinel - UICheck.lua
-- Prüfung der Oberfläche im echten Client (Testfälle T180–T185, Bereich K der Testroutine)
-- Übernommen aus der Vorlage (raidmaster/shared/vorlage/__ADDON__/UICheck.lua, dort T18–T23). Anpassungen:
--   * eigene Testnummern T180–T185 (T18–T23 sind in ThreatSentinel schon vergeben)
--   * ns.RegisterUI(frame, Name, "hud"): frei verschiebbare Kampfanzeigen (Aggrometer, HUD, Knöpfe …) docken an kein
--     Blizzard-Fenster an; sie werden auf "im Bildschirm", Tooltips und Beschriftungen geprüft, aber nicht auf Überlappen
--   * Fehlerschleife (T185): aus der Fehlerliste von GoldSentinelTest (ThreatSentinelDB.gsTest), ThreatSentinel hat
--     kein eigenes Diagnose-Protokoll
--   * Blizzard-Funktionen nur über ns.API
-- Copyright (c) 2026 GoldSentinel. All Rights Reserved.
--
-- Anlass (Live-Test 5. Nov. 2026): eigene Tooltips verdeckten Knöpfe, Fenster lagen übereinander, Anzeigen rechneten
-- mit falschen Spielwerten (Fertigkeit 0), ein Fehler kam 588×. Offline sieht man das nicht – darum prüft die
-- Testroutine es im Spiel selbst. Nur lesen, nichts verändern.
--
-- Benutzung im eigenen Code:
--   ns.RegisterUI(frame, "Name")                 -- jedes eigene Fenster anmelden (ThreatSentinel: Optionen, Testzentrale, Anzeigen …)
--   ns.Plausible("Fertigkeit", function() return skill > 0, skill, "> 0" end)   -- Spielwert-Prüfung für T184
-- Andere GoldSentinel-Addons melden ihre Fenster in der globalen Liste GoldSentinelUIFrames an (T181 prüft gegeneinander).

local ADDON, ns = ...

ns.uiFrames = ns.uiFrames or {}
ns.plausible = ns.plausible or {}
ns.UI_LOOP_LIMIT = 10                       -- dieselbe Fehlermeldung öfter -> Fehlerschleife (T185)

-- Blizzard-Fenster, an die GoldSentinel-Addons andocken (dürfen nicht überdeckt werden)
ns.UI_BLIZZARD = { "ProfessionsFrame", "TradeSkillFrame", "CraftFrame", "MerchantFrame", "AuctionHouseFrame",
                   "AuctionFrame", "MailFrame", "QuestLogFrame", "WorldMapFrame", "CharacterFrame" }

GoldSentinelUIFrames = GoldSentinelUIFrames or {}

function ns.RegisterUI(frame, name, kind)
    if not frame then return end
    for _, e in ipairs(ns.uiFrames) do if e.frame == frame then return end end
    local e = { frame = frame, name = name or (frame.GetName and frame:GetName()) or ADDON, hud = (kind == "hud") }
    ns.uiFrames[#ns.uiFrames + 1] = e
    -- Kampfanzeigen nicht in die gemeinsame Liste: andere Addons sollen sich nicht an ihnen stossen
    if not e.hud then
        GoldSentinelUIFrames[#GoldSentinelUIFrames + 1] = { frame = frame, name = e.name, addon = ADDON }
    end
end

function ns.Plausible(name, fn) ns.plausible[#ns.plausible + 1] = { name = name, fn = fn } end

local U = {}
ns.UICheck = U

-- Ist der echte Client da (Rechtecke, Kinder, Tooltip)? Sonst werden die Fälle ehrlich übersprungen.
function U.Available()
    local f = ns.uiFrames[1] and ns.uiFrames[1].frame
    return f and type(f.GetRect) == "function" and type(f.GetChildren) == "function"
        and type(GameTooltip) == "table" and type(GameTooltip.GetRect) == "function"
        and type(UIParent) == "table" and type(UIParent.GetRect) == "function" and true or false
end

function U.Rect(f)
    if not (f and f.GetRect) then return nil end
    local ok, l, b, w, h = pcall(f.GetRect, f)
    if not ok or not l or not w or w <= 0 or h <= 0 then return nil end
    local s = f.GetEffectiveScale and f:GetEffectiveScale() or 1
    return { l = l * s, b = b * s, r = (l + w) * s, t = (b + h) * s }
end

-- Fläche der Überschneidung (0 = keine). Ein Pixel Rand gilt als "angedockt", nicht als Überlappen.
function U.Overlap(a, c)
    if not (a and c) then return 0 end
    local w = math.min(a.r, c.r) - math.max(a.l, c.l) - 1
    local h = math.min(a.t, c.t) - math.max(a.b, c.b) - 1
    return (w > 0 and h > 0) and w * h or 0
end

local function Shown(f) return f and f.IsVisible and f:IsVisible() end

-- Beschriftung eines Elements: eigener Text oder der erste sichtbare Text darin (gekürzt)
local function Label(f)
    local t = f.GetText and f:GetText()
    if (type(t) ~= "string" or t == "") and f.GetRegions then
        for _, r in ipairs({ f:GetRegions() }) do
            if r.GetObjectType and r:GetObjectType() == "FontString" then
                local x = r:GetText()
                if type(x) == "string" and x ~= "" then t = x break end
            end
        end
    end
    if type(t) ~= "string" or t == "" then return nil end
    t = t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", ""):gsub("\n", " ")
    if #t > 30 then t = t:sub(1, 30) .. "…" end
    return t
end

-- Name eines Rahmens für die Meldung: eigener Name, sonst Pfad ab dem nächsten benannten Vorfahren,
-- Rahmenart, Beschriftung und Stelle im Fenster (T180 im Client: "Frame verdeckt 'G'" war nicht auffindbar)
local function Name(f)
    if not f then return "?" end
    local n = f.GetName and f:GetName()
    if n then return n end
    local anc
    local p = f
    for _ = 1, 10 do
        p = p.GetParent and p:GetParent()
        if not p then break end
        anc = p.GetName and p:GetName()
        if anc then break end
    end
    local kind = f.GetObjectType and f:GetObjectType() or "?"
    local t = Label(f)
    local where = ""
    local r = U.Rect(f)
    local base = anc and _G[anc] and U.Rect(_G[anc])
    if r and base then where = string.format(" @%d,%d", math.floor(r.l - base.l + 0.5), math.floor(base.t - r.t + 0.5)) end
    return (anc and (anc .. " > ") or "") .. kind .. (t and (" '" .. t .. "'") or "") .. where
end

-- Tooltip neben das ganze Fenster legen (verdeckt so keine Knöpfe desselben Fensters, T180); rechts, sonst links
function ns.TipBeside(owner, container)
    container = container or owner
    GameTooltip:SetOwner(owner, "ANCHOR_NONE")
    GameTooltip:ClearAllPoints()
    local right = container.GetRight and container:GetRight()
    local cs = container.GetEffectiveScale and container:GetEffectiveScale() or 1
    local us = UIParent.GetEffectiveScale and UIParent:GetEffectiveScale() or 1
    local sw = UIParent.GetWidth and UIParent:GetWidth() or 0
    if right and sw > 0 and (right * cs / us) + 320 > sw then
        GameTooltip:SetPoint("TOPRIGHT", container, "TOPLEFT", -4, 0)
    else
        GameTooltip:SetPoint("TOPLEFT", container, "TOPRIGHT", 4, 0)
    end
end

-- Fenster nicht über andere Fenster legen (T181): offene Blizzard-Fenster und sichtbare Fenster anderer
-- GoldSentinel-Addons (dieselbe Liste wie U.WindowsOverlapNothing; leere Anker zählen nicht, U.ReallyVisible).
-- Liegt es darauf, wird es rechts daneben gesetzt, sonst links daneben; höchstens 4 Versuche, dann bleibt die beste
-- Lage (am wenigsten Überdeckung). Nur für diese Anzeige, die gespeicherte Lage bleibt. Rückgabe: true, wenn verschoben.
local function Obstacles(frame)
    local list = {}
    for _, bn in ipairs(ns.UI_BLIZZARD) do
        local bf = _G[bn]
        if bf and bf ~= frame and bf.IsVisible and bf:IsVisible() then
            local r = U.Rect(bf)
            if r then list[#list + 1] = r end
        end
    end
    for _, o in ipairs(GoldSentinelUIFrames or {}) do
        if o.addon ~= ADDON and o.frame ~= frame and U.ReallyVisible and U.ReallyVisible(o.frame) then
            local r = U.Rect(o.frame)
            if r then list[#list + 1] = r end
        end
    end
    return list
end

local function Covered(rect, list)
    local sum, first = 0, nil
    for _, r in ipairs(list) do
        local a = U.Overlap(rect, r)
        if a > 0 then sum = sum + a; first = first or r end
    end
    return sum, first
end

function ns.UIAvoidBlizzard(frame)
    if not (frame and frame.IsVisible and frame:IsVisible() and frame.GetRect) then return false end
    local mine = U.Rect(frame)
    if not mine then return false end
    local list = Obstacles(frame)
    local us = UIParent.GetEffectiveScale and UIParent:GetEffectiveScale() or 1
    local sw = (UIParent.GetWidth and UIParent:GetWidth() or 0) * us
    local w = mine.r - mine.l
    local fs = frame:GetEffectiveScale() or 1
    local cur = { l = mine.l, r = mine.r, t = mine.t, b = mine.b }
    local covered, hit = Covered(cur, list)
    if covered == 0 then return false end
    local best, bestCover = { l = cur.l }, covered
    for _ = 1, 4 do
        if not hit then break end
        local x = (hit.r + 8 + w <= sw) and (hit.r + 8) or math.max(0, hit.l - 8 - w)
        cur = { l = x, r = x + w, t = mine.t, b = mine.b }
        covered, hit = Covered(cur, list)
        if covered < bestCover then best, bestCover = { l = x }, covered end
        if covered == 0 then break end
    end
    frame:ClearAllPoints()
    frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", best.l / fs, mine.t / fs)
    return true
end
ns.UIAvoidOthers = ns.UIAvoidBlizzard

-- Ist ein Rahmen wirklich zu sehen? Sichtbar, nicht durchsichtig, und mit sichtbarem Inhalt (Fläche, Text oder
-- sichtbarem Kind). Leere Ankerrahmen anderer Addons (z. B. BuffSentinelAnchor_*, gesperrt) zählen nicht (T181).
local function HasContent(f, depth)
    if f.GetRegions then
        for _, r in ipairs({ f:GetRegions() }) do
            if r.IsShown and r:IsShown() and (not r.GetAlpha or r:GetAlpha() > 0.05) then
                local kind = r.GetObjectType and r:GetObjectType()
                if kind == "Texture" then return true end
                if kind == "FontString" and r:GetText() and r:GetText() ~= "" then return true end
            end
        end
    end
    if f.GetBackdrop and f:GetBackdrop() then return true end
    if depth < 3 and f.GetChildren then
        for _, c in ipairs({ f:GetChildren() }) do
            if c.IsShown and c:IsShown() and HasContent(c, depth + 1) then return true end
        end
    end
    return false
end
function U.ReallyVisible(f)
    if not (f and f.IsVisible and f:IsVisible()) then return false end
    local a = f.GetEffectiveAlpha and f:GetEffectiveAlpha() or 1
    if a <= 0.05 then return false end
    return HasContent(f, 0)
end

-- alle sichtbaren Nachfahren eines Fensters
function U.Descendants(f, out)
    out = out or {}
    if not (f and f.GetChildren) then return out end
    for _, c in ipairs({ f:GetChildren() }) do
        if Shown(c) then out[#out + 1] = c; U.Descendants(c, out) end
    end
    return out
end

local function IsControl(f)
    return f.IsObjectType and (f:IsObjectType("Button") or f:IsObjectType("EditBox") or f:IsObjectType("CheckButton")
        or f:IsObjectType("Slider")) and true or false
end

-- T180: kein eigener Tooltip verdeckt einen Knopf desselben Fensters
function U.TooltipsCoverNothing()
    local problems, tested = {}, 0
    for _, e in ipairs(ns.uiFrames) do
        if Shown(e.frame) then
            local all = U.Descendants(e.frame)
            for _, el in ipairs(all) do
                local enter = el.GetScript and el:GetScript("OnEnter")
                if enter then
                    tested = tested + 1
                    pcall(enter, el)
                    local tip = Shown(GameTooltip) and U.Rect(GameTooltip)
                    if tip then
                        for _, other in ipairs(all) do
                            if other ~= el and IsControl(other) and U.Overlap(tip, U.Rect(other)) > 0 then
                                problems[#problems + 1] = Name(el) .. " verdeckt " .. Name(other)
                                break
                            end
                        end
                    end
                    local leave = el:GetScript("OnLeave")
                    if leave then pcall(leave, el) end
                    if GameTooltip.Hide then GameTooltip:Hide() end
                end
            end
        end
    end
    return problems, tested
end

-- T181: eigene sichtbare Fenster überdecken weder Blizzard-Fenster noch Fenster anderer GoldSentinel-Addons
function U.WindowsOverlapNothing()
    local problems, tested = {}, 0
    for _, e in ipairs(ns.uiFrames) do
        local mine = not e.hud and Shown(e.frame) and U.Rect(e.frame)
        if mine then
            for _, bn in ipairs(ns.UI_BLIZZARD) do
                local bf = _G[bn]
                if Shown(bf) then
                    tested = tested + 1
                    if U.Overlap(mine, U.Rect(bf)) > 0 then problems[#problems + 1] = e.name .. " überdeckt " .. bn end
                end
            end
            for _, o in ipairs(GoldSentinelUIFrames) do
                if o.addon ~= ADDON and U.ReallyVisible(o.frame) then
                    tested = tested + 1
                    if U.Overlap(mine, U.Rect(o.frame)) > 0 then
                        problems[#problems + 1] = e.name .. " überdeckt " .. o.name .. " (" .. o.addon .. ")"
                    end
                end
            end
        end
    end
    return problems, tested
end

-- T182: sichtbare Fenster liegen ganz im Bildschirm
function U.InsideScreen()
    local problems, tested, screen = {}, 0, U.Rect(UIParent)
    for _, e in ipairs(ns.uiFrames) do
        local r = Shown(e.frame) and U.Rect(e.frame)
        if r and screen then
            tested = tested + 1
            if r.l < screen.l - 1 or r.b < screen.b - 1 or r.r > screen.r + 1 or r.t > screen.t + 1 then
                problems[#problems + 1] = e.name .. " ragt aus dem Bildschirm"
            end
        end
    end
    return problems, tested
end

-- T183: Beschriftungen von Knöpfen sind nicht abgeschnitten (andere Texte nur als Hinweis)
function U.TextFits()
    local problems, hints, tested = {}, {}, 0
    for _, e in ipairs(ns.uiFrames) do
        if Shown(e.frame) then
            for _, el in ipairs(U.Descendants(e.frame)) do
                local fs = el.GetFontString and el:GetFontString()
                if fs and fs.IsTruncated then
                    tested = tested + 1
                    if fs:IsTruncated() then problems[#problems + 1] = Name(el) .. " Beschriftung abgeschnitten" end
                end
                for _, region in ipairs(el.GetRegions and { el:GetRegions() } or {}) do
                    if region.IsObjectType and region:IsObjectType("FontString") and region.IsTruncated and Shown(region) then
                        tested = tested + 1
                        if region:IsTruncated() then hints[#hints + 1] = Name(el) .. ": Text gekürzt" end
                    end
                end
            end
        end
    end
    return problems, tested, hints
end

-- T184: angezeigte Spielwerte plausibel (Prüfungen meldet das Addon mit ns.Plausible an)
function U.ValuesPlausible()
    local problems = {}
    for _, p in ipairs(ns.plausible) do
        local ok, good, got, want = pcall(p.fn)
        if not ok then problems[#problems + 1] = p.name .. ": Lua-Fehler " .. tostring(good)
        elseif good == false then problems[#problems + 1] = p.name .. ": " .. tostring(got) .. " (erwartet " .. tostring(want) .. ")" end
    end
    return problems, #ns.plausible
end

-- T185: keine Fehlerschleife – dieselbe Meldung höchstens UI_LOOP_LIMIT× in der Sitzung
-- (Fehlerliste von GoldSentinelTest; sie wird beim Ausloggen in einen Bericht verschoben)
function U.NoErrorLoops()
    local problems = {}
    local s = ThreatSentinelDB and ThreatSentinelDB.gsTest
    local list = (s and GoldSentinelTest and GoldSentinelTest.ErrorList) and GoldSentinelTest.ErrorList(s) or {}
    for _, e in ipairs(list) do
        if (e.count or 1) > ns.UI_LOOP_LIMIT then
            problems[#problems + 1] = (e.count or 1) .. "× " .. tostring(e.wo) .. ": " .. tostring(e.msg)
        end
    end
    return problems, #list
end

------------------------------------------------------------
-- Spielwerte, die ThreatSentinel liest und anzeigt (T184)
------------------------------------------------------------
local function secret(v) return ns.IsSecret and ns.IsSecret(v) end

ns.Plausible("Stufe des Charakters", function()
    local lvl = ns.API.UnitLevel and ns.API.UnitLevel("player")
    if type(lvl) ~= "number" or secret(lvl) then return true, "nicht lesbar" end
    return lvl >= 1 and lvl <= 100, lvl, "1–100"
end)

ns.Plausible("Klasse des Charakters", function()
    local _, class = ns.API.UnitClass("player")
    if secret(class) or not class then return true, "nicht lesbar" end
    return ns.class == class, tostring(ns.class), class
end)

ns.Plausible("Eigener Name ohne Realm", function()
    local n = ns.playerName
    if type(n) ~= "string" then return false, tostring(n), "Name" end
    return n ~= "" and not n:find("-", 1, true) and n == ns:FullName("player"), "<Name>", "<Name> ohne Realm, = FullName"
end)

ns.Plausible("Gruppe vollständig", function()
    local A = ns.API
    local want
    if A.IsInRaid() then want = A.GetNumGroupMembers() else want = 1 + (A.GetNumSubgroupMembers() or 0) end
    if secret(want) or type(want) ~= "number" then return true, "nicht lesbar" end
    ns:UpdateGroup()
    local players = 0
    for _, u in ipairs(ns.groupUnits or {}) do
        if not u:find("pet", 1, true) then players = players + 1 end
    end
    return players == want, players, want
end)

ns.Plausible("Bedrohungsmodus", function()
    local m = ns:ThreatMode()
    local okMode = m == "FULL" or m == "DISPLAY" or m == "OFF"
    -- alte API (Era, TBC): Bedrohung immer offen, Modus immer VOLL
    if okMode and not ns.isModern then return m == "FULL", m, "FULL (alte API)" end
    return okMode, m, "FULL, DISPLAY oder OFF"
end)

ns.Plausible("Spott gelernt", function()
    local spell, mode = ns.tauntSpell, ns.tauntMode
    -- eigener Spott (Einstellung) und Pet-Spott stehen nicht im eigenen Zauberbuch
    if not spell or mode == "pet" or (ns.db and ns.db.tauntOverride and ns.db.tauntOverride ~= "") then
        return true, "kein eigener Klassen-Spott"
    end
    local id = ns.spellIdByName and ns.spellIdByName[spell]
    local known = (id and ns:KnowsSpell(id)) or ns:SpellbookHas(spell)
    return known and true or false, tostring(spell) .. (known and " gelernt" or " nicht gelernt"), "gelernt"
end)
