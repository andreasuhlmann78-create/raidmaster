-- ThreatSentinel - TestRoutineTU.lua
-- Umfassende Tests (Bereich U), Anweisung der Prüf-Sitzung vom 13.11.2026 (auftraege/ThreatSentinel/
-- anweisung-tests-umfassend.txt, TU1–TU9) und Befehlsliste (BL, T-BL1–T-BL6).
--   /ts testroutine u      nur dieser Bereich (vollständig mit /ts testroutine: dann zählt auch TU6 alle Bereiche)
--
-- Bedrohung ist ein Kampf-Addon: Fehler treten in Kampflagen auf (Tankwechsel, Spott, geheime Werte), nicht in
-- Einzeltests. Darum laufen hier ganze Lagen durch ALLE betroffenen Teile (T:Tick = Auswertung, Plaketten, Meldungen,
-- Töne, HUD; Aggrometer; Sync) – mit einer Erwartung je Lage und Teil.
--   TU1 Lagen-Katalog          TU2 Abläufe wie ein Spieler     TU3 Standardwerte
--   TU4 Grundregeln mit Zufallsdaten (1000 Fälle, fester Startwert, 10 Portionen à 100, je Bild eine Portion)
--   TU5 echte Daten (Diagnose-Protokoll und Testprotokoll nur lesen; im Spiel prüft Threat.lua dieselben Regeln
--       live und schreibt "GRUNDREGEL VERLETZT …" ins Diagnose-Protokoll)
--   TU6 Regressionen (jeder Befund seit dem 3.11. -> sein bleibender Test; "Regressionen: n von m vorhanden")
--   TU7 Formen des Spiels (Forever/Era/TBC, geheime Werte, deDE/enUS, Skalierung)
--   TU8 Bericht: je Bereich "OK n · FEHLER n · SKIP n" (R:TULines, TestRoutine.lua R:Finish)
--   TU9 offline: dieselbe Routine läuft im nachgebauten Spiel (berichte/ThreatSentinel/offline/)
-- Regeln wie in TestRoutine.lua: keine Blizzard-Funktion wird ersetzt (nur ns.API-Einträge und eigene Felder),
-- Aktionen mit Folgen nur mitgeschrieben, Sandbox nach dem Bereich zurück.

local ADDON, ns = ...
local L = ns.L
local R = ns.Routine
local H = R.H
local C, K, CL = H.C, H.K, H.CL
local Swap, UnswapAll, Scene, WithAPI, NIL, Ret, SECRET = H.Swap, H.UnswapAll, H.Scene, H.WithAPI, H.NIL, H.Ret, H.SECRET
local S, Clean, Ms, Counter, Copy = H.S, H.Clean, H.Ms, H.Counter, H.Copy
local Area = H.Area

local TU_NAMES = {
	TU1 = "Lagen-Katalog", TU2 = "Abläufe wie ein Spieler", TU3 = "Standardwerte", TU4 = "Grundregeln (Zufall)",
	TU5 = "Echte Daten", TU6 = "Regressionen", TU7 = "Formen des Spiels",
}
local TU_ORDER = { "TU1", "TU2", "TU3", "TU4", "TU5", "TU6", "TU7" }
R.TU_SEED = 20261113
R.TU_CASES, R.TU_PORTION = 1000, 100

------------------------------------------------------------
-- Zählung je Bereich (TU8)
------------------------------------------------------------
function R:TUReset()
	self.tu = {}
	for _, k in ipairs(TU_ORDER) do self.tu[k] = { ok = 0, fehler = 0, skip = 0, why = {} } end
	self.tuDefaults, self.tuRandom, self.tuReg = nil, nil, nil
end
R:TUReset()

local function Bump(tu, kind, why)
	local t = R.tu and R.tu[tu]
	if not t then return end
	t[kind] = t[kind] + 1
	if why then t.why[#t.why + 1] = why end
end
-- Prüfung eines TU-Bereichs (Bereich "U" im Bericht)
local function TC(tu, id, name, fn)
	local ok = C(id, "U", tu .. " " .. name, fn)
	Bump(tu, ok and "ok" or "fehler")
	return ok
end
local function TK(tu, id, name, why)
	K(id, "U", tu .. " " .. name, why)
	Bump(tu, "skip", id .. ": " .. why)
end
local function TCL(tu, id, name, how)
	CL(id, "U", tu .. " " .. name, how)
	Bump(tu, "skip", id .. ": im Client prüfen")
end

-- TU8: Zeilen für den Bericht (und Felder im GSTEST1-Bericht)
function R:TULines(extra)
	local out = {}
	local ran = false
	for _, k in ipairs(TU_ORDER) do
		local t = self.tu and self.tu[k]
		if t and (t.ok + t.fehler + t.skip) > 0 then ran = true end
	end
	if not ran then return out end
	out[#out + 1] = "Umfassende Tests (TU8):"
	for _, k in ipairs(TU_ORDER) do
		local t = self.tu[k]
		local line = string.format("%s %s: OK %d · FEHLER %d · SKIP %d", k, TU_NAMES[k], t.ok, t.fehler, t.skip)
		if #t.why > 0 then line = line .. " (" .. table.concat(t.why, "; ") .. ")" end
		out[#out + 1] = "  " .. line
		if extra then extra[k:lower()] = string.format("OK %d · FEHLER %d · SKIP %d", t.ok, t.fehler, t.skip) end
	end
	out[#out + 1] = "  TU9 Offline: dieselbe Routine im nachgebauten Spiel (berichte/ThreatSentinel/offline/)"
	if self.tuReg then
		out[#out + 1] = "  " .. self.tuReg
		if extra then extra.regressionen = self.tuReg end
	end
	if self.tuRandom then
		out[#out + 1] = "  " .. self.tuRandom
		if extra then extra.zufall = self.tuRandom end
	end
	if self.tuDefaults and extra then extra.standardwerte = self.tuDefaults end
	return out
end

------------------------------------------------------------
-- Zufall mit festem Startwert (eigener Generator, math.random bleibt unberührt)
------------------------------------------------------------
local function NewRand(seed)
	local x = seed % 2147483647
	if x <= 0 then x = x + 2147483646 end
	return function(a, b)
		x = (x * 16807) % 2147483647
		if not a then return x / 2147483647 end
		return a + (x % (b - a + 1))
	end
end
R.NewRand = NewRand

------------------------------------------------------------
-- Lage = Kulisse + Schritte; nach jedem Schritt ein ganzer Durchlauf T:Tick (Modus VOLL, wie im Spiel).
-- Ergebnis: Zustände je Schritt, Meldungen (OnLoose/OnWarn/OnRegain), Töne, Mitte-Meldungen, HUD, Aggrometer.
------------------------------------------------------------
local function DbSet(map)
	local saved = {}
	for k, v in pairs(map) do saved[k] = { ns.db[k] }; ns.db[k] = v end
	return function() for k, box in pairs(saved) do ns.db[k] = box[1] end end
end

-- Ergebnis-Text einer Lage: "HELD,LOOSE>HELD | L1 W0 R1 T1 | Meter Anna"
local function RunLage(def)
	local sc = Scene.New(def.mobs or 1)
	if def.setup then def.setup(sc) end
	local errBefore, blockedBefore = ns.errorCount or 0, #(ns.blocked or {})
	local res = Scene.Run(sc, function()
		local restore = DbSet(def.db or {})
		local saveMode = ns.db.threatMode
		ns.db.threatMode = "AUTO"
		ns.simAccess = def.sim or "open"
		local ok, r = pcall(function()
			local loose = Counter(ns.Alerts, "OnLoose")
			local warn = Counter(ns.Alerts, "OnWarn")
			local regain = Counter(ns.Alerts, "OnRegain")
			if def.inside then def.inside(sc) end
			local seq = {}
			local steps = def.steps or { function() end }
			for i, step in ipairs(steps) do
				step(sc, i)
				ns.Threat:Tick()
				local st = {}
				for m = 1, sc.nMobs do st[m] = S(ns.mobs["tsfake" .. m] and ns.mobs["tsfake" .. m].state or "-") end
				seq[#seq + 1] = table.concat(st, ",")
			end
			local meter = ""
			if def.meter then
				local list = ns.Meter:Collect() or {}
				meter = " | Meter " .. S(list[1] and list[1].name)
			end
			local extra = def.extra and (" | " .. def.extra(sc)) or ""
			return string.format("%s | L%d W%d R%d T%d%s%s", table.concat(seq, ">"), loose.n, warn.n, regain.n, sc.plays, meter, extra)
		end)
		ns.db.threatMode = saveMode
		restore()
		if not ok then error(r, 0) end
		return r
	end)
	local errs = (ns.errorCount or 0) - errBefore
	local blocked = #(ns.blocked or {}) - blockedBefore
	if errs > 0 then res = res .. " | Lua-Fehler " .. errs end
	if blocked > 0 then res = res .. " | gesperrt " .. blocked end
	return res
end
R.RunLage = RunLage

-- Kulissen-Hilfen
local function Raid(sc, n)
	sc.raid = n
	sc.group = {}
	sc.alias.raid1 = "player"
	for i = 2, n do
		sc.units["raid" .. i] = { name = "Raider" .. i, player = true, class = (i % 4 == 0) and "PRIEST" or "MAGE",
			role = (i % 4 == 0) and "HEALER" or "DAMAGER", combat = true, power = 0 }
	end
	sc.units.raid2.role, sc.units.raid2.class, sc.units.raid2.power = "TANK", "WARRIOR", 1
end

-- Der Katalog: modern = Forever/Retail-API (geheime Werte möglich), sonst Era/TBC
local function Catalog(modern)
	local thr = 90
	local LAGEN = {
		{ id = "L01", name = "solo, ab Werk (nur in der Gruppe aktiv)",
			setup = function(sc) sc.group = {} end, want = "- | L0 W0 R0 T0" },
		{ id = "L02", name = "solo mit 'auch solo aktiv'",
			setup = function(sc) sc.group = {} end, db = { activeSolo = true }, want = "HELD | L0 W0 R0 T0" },
		{ id = "L03", name = "Gruppe: einer gehalten, DD und Heiler haben Aggro",
			mobs = 3, meter = true,
			setup = function(sc)
				sc.alias.target = "tsfake1"
				Scene.Hold(sc, "tsfake1", "player", { party1 = 40 })
				Scene.Hold(sc, "tsfake2", "party1")
				Scene.Hold(sc, "tsfake3", "party2")
			end,
			want = "HELD,LOOSE,LOOSE | L2 W0 R0 T2 | Meter Anna" },
		{ id = "L04", name = "Schlachtzug 40, 10 Mobs, 3 lose",
			mobs = 10,
			setup = function(sc)
				Raid(sc, 40)
				for i = 1, 10 do Scene.Hold(sc, "tsfake" .. i, "player") end
				Scene.Hold(sc, "tsfake2", "raid5"); Scene.Hold(sc, "tsfake5", "raid8"); Scene.Hold(sc, "tsfake9", "raid13")
				Scene.Hold(sc, "tsfake7", "raid2")      -- zweiter Tank
			end,
			want = "HELD,LOOSE,HELD,HELD,LOOSE,HELD,OTHERTANK,HELD,LOOSE,HELD | L3 W0 R0 T3" },
		{ id = "L05", name = "Tankwechsel: anderer Tank übernimmt und gibt zurück",
			steps = {
				function() end,
				function(sc) Scene.Hold(sc, "tsfake1", "party3") end,
				function(sc) Scene.Hold(sc, "tsfake1", "player") end,
			},
			want = "HELD>OTHERTANK>HELD | L0 W0 R0 T0" },
		{ id = "L06", name = "Spott: DD hat Aggro, Tank holt zurück",
			steps = {
				function(sc) Scene.Hold(sc, "tsfake1", "party1") end,
				function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = 100 }) end,
			},
			want = "LOOSE>WARN | L1 W0 R1 T1" },
		{ id = "L07", name = "Bedrohung zurücksetzen (Verblassen, Totstellen, Unsichtbarkeit) und Mob ohne Bedrohung",
			steps = {
				function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = 50 }) end,
				function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = 95 }) end,   -- bald Aggro
				function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = 0 }) end,    -- verblasst
				function(sc) Scene.Hold(sc, "tsfake1", "party1") end,                    -- DD hat Aggro
				function(sc) Scene.Hold(sc, "tsfake1", "player") end,                    -- DD totgestellt -> zum Tank
				function(sc) sc.threat.tsfake1 = {}; sc.alias.tsfake1target = nil end,   -- Mob setzt zurück
			},
			want = "HELD>WARN>HELD>LOOSE>HELD>IDLE | L1 W1 R1 T1" },
		{ id = "L08", name = "mehrere Ziele: gehalten, bald Aggro, lose, anderer Tank, Begleiter",
			mobs = 5,
			setup = function(sc)
				sc.units.pet = { name = "Wolf" }
				Scene.Hold(sc, "tsfake2", "player", { party1 = thr + 5 })
				Scene.Hold(sc, "tsfake3", "party2")
				Scene.Hold(sc, "tsfake4", "party3")
				Scene.Hold(sc, "tsfake5", "pet")
			end,
			db = { petsSafe = true },
			want = "HELD,WARN,LOOSE,OTHERTANK,PETHELD | L1 W0 R0 T1" },
		{ id = "L09", name = "Begleiter hält Mob, 'Begleiter sicher' aus",
			setup = function(sc) sc.units.pet = { name = "Wolf" }; Scene.Hold(sc, "tsfake1", "pet") end,
			db = { petsSafe = false },
			want = "LOOSE | L1 W0 R0 T1" },
		{ id = "L10", name = "Ziel wechselt schnell (3x DD, 3x zurück)",
			steps = (function()
				local t = {}
				for i = 1, 6 do
					t[i] = function(sc) Scene.Hold(sc, "tsfake1", (i % 2 == 1) and "party1" or "player") end
				end
				return t
			end)(),
			want = "LOOSE>HELD>LOOSE>HELD>LOOSE>HELD | L3 W0 R3 T3" },
		{ id = "L11", name = "Grenzen: 89 %, Warnschwelle 90 %, Nahkampf 109 % (unter 110), dann Aggro",
			steps = {
				function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = 89 }) end,
				function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = 90 }) end,
				function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = 109 }) end,
				function(sc) Scene.Hold(sc, "tsfake1", "party1", { player = 91 }) end,
			},
			db = { warnThreshold = 90 },
			want = "HELD>WARN>WARN>LOOSE | L1 W1 R0 T1" },
		{ id = "L12", name = "Mitspieler mit alter Version (Sync ohne Version / ohne Abklingzeit): Spott wird erkannt",
			setup = function(sc) Scene.Hold(sc, "tsfake1", "party1") end,
			inside = function(sc)
				ns.Sync:Handle("Grimbar", "H:TANK")                                   -- Version 1: ohne Version
				ns.Sync:Handle("Grimbar", "T:" .. sc.units.tsfake1.guid)              -- ohne Abklingzeit
			end,
			db = { sync = true },
			extra = function(sc)
				local m = ns.mobs.tsfake1
				local r = ns.syncRoles.Grimbar
				return "übernommen " .. S(m.claimedBy) .. ", Rolle " .. S(r and r.role)
			end,
			want = "LOOSE | L0 W0 R0 T0 | übernommen Grimbar, Rolle TANK" },
	}
	if modern then
		LAGEN[#LAGEN + 1] = { id = "L13", name = "Forever: Bedrohung im Kampf geheim -> Modus ANZEIGE, keine eigene Entscheidung",
			setup = function(sc) sc.secret = true; Scene.Hold(sc, "tsfake1", "party1") end,
			extra = function() return "Modus " .. ns:ThreatMode() end,
			want = "IDLE | L0 W0 R0 T0 | Modus DISPLAY" }
		LAGEN[#LAGEN + 1] = { id = "L14", name = "keine Bedrohungs-Schnittstelle (moderne API): ANZEIGE statt eigener Rechnung",
			setup = function(sc) Scene.Hold(sc, "tsfake1", "party1"); sc.noThreatApi = true end,
			extra = function() return "Modus " .. ns:ThreatMode() end,
			want = "IDLE | L0 W0 R0 T0 | Modus DISPLAY" }
	else
		LAGEN[#LAGEN + 1] = { id = "L14", name = "keine Bedrohungs-Schnittstelle (alte API): Ersatz über das Ziel des Mobs",
			setup = function(sc) Scene.Hold(sc, "tsfake1", "party1"); sc.noThreatApi = true end,
			extra = function() return "Modus " .. ns:ThreatMode() end,
			want = "LOOSE | L1 W0 R0 T1 | Modus FULL" }
	end
	return LAGEN
end
R.TUCatalog = Catalog

-- Lage ausführen (sc.noThreatApi: die Kulisse liefert keine Bedrohungs-Einträge, siehe unten)
local function RunOne(def) return RunLage(def) end

-- Scene.Map kennt noThreatApi nicht: Einträge nach dem Aufbau entfernen
do
	local origMap = Scene.Map
	Scene.Map = function(sc)
		local map = origMap(sc)
		if sc.noThreatApi then
			map.UnitDetailedThreatSituation = NIL
			map.UnitThreatSituation = NIL
		end
		return map
	end
end

local function CatalogCheck(tu, prefix, modern, label)
	local bad, n = {}, 0
	for _, def in ipairs(Catalog(modern)) do
		n = n + 1
		local ok, got = pcall(RunOne, def)
		got = ok and got or ("Lua: " .. tostring(got))
		if got ~= def.want then bad[#bad + 1] = def.id .. " " .. def.name .. ": ist '" .. got .. "', soll '" .. def.want .. "'" end
	end
	return #bad == 0, (#bad == 0) and (n .. " Lagen wie erwartet" .. (label and (" (" .. label .. ")") or "")) or Clean(table.concat(bad, " || ")),
		n .. " Lagen, jede wie in der Tabelle"
end

------------------------------------------------------------
-- TU1 Lagen-Katalog (jede Lage ein eigener Fall, damit der Bericht die Lage nennt)
------------------------------------------------------------
local function TU1()
	for _, def in ipairs(Catalog(ns.isModern)) do
		TC("TU1", "TU1-" .. def.id, def.name, function()
			local got = RunOne(def)
			return got == def.want, Clean(got), Clean(def.want)
		end)
	end
	TC("TU1", "TU1-L04t", "Schlachtzug 40 mit 40 Mobs: ein Durchlauf < 8 ms", function()
		local sc = Scene.New(40)
		Raid(sc, 40)
		for i = 1, 40, 3 do Scene.Hold(sc, "tsfake" .. i, "raid" .. (3 + i % 30)) end
		local v = Scene.Run(sc, function()
			ns.simAccess = "open"
			ns.Threat:Tick()
			return H.Time(10, function() ns.Threat:Tick() end)
		end)
		return v < 8, string.format("%.2f ms", v), "< 8 ms"
	end)
end

------------------------------------------------------------
-- TU2 Abläufe wie ein Spieler
------------------------------------------------------------
local function Flow(name, fn)
	local real0, err0, blk0 = R.realCalls or 0, ns.errorCount or 0, #(ns.blocked or {})
	local ok, a, b, c = pcall(fn)
	local real, errs, blk = (R.realCalls or 0) - real0, (ns.errorCount or 0) - err0, #(ns.blocked or {}) - blk0
	if not ok then return false, "Lua: " .. Clean(a), "kein Fehler" end
	local tail = string.format(" · echt %d, Fehler %d, gesperrt %d", real, errs, blk)
	if real > 0 or errs > 0 or blk > 0 then return false, S(b) .. tail, S(c) .. " · echt 0, Fehler 0, gesperrt 0" end
	return a, S(b) .. tail, S(c) .. " · echt 0, Fehler 0, gesperrt 0"
end

local function TU2()
	TC("TU2", "TU2-A1", "Kampf beginnt, während die Anzeigen verschoben werden", function()
		return Flow("A1", function()
			local MV = ns.Mover
			local was = ns.moveMode
			if not was then MV:Toggle() end
			local during = ns.moveMode
			-- das Spiel meldet den Kampfbeginn (alle Empfänger von PLAYER_REGEN_DISABLED wie im Spiel)
			MV:Stop()
			local after = ns.moveMode
			if was then MV:Toggle() end
			local got = "verschieben " .. S(during) .. " -> Kampf -> " .. S(after)
			return during == true and after == false, got, "verschieben true -> Kampf -> false"
		end)
	end)
	TC("TU2", "TU2-A2", "/reload mitten im Kampf: kein VOLL ohne Kampfbeginn, keine Meldung, kein Plakettenzugriff", function()
		return Flow("A2", function()
			local TA = ns.ThreatAccess
			local sc = Scene.New(2)
			Scene.Hold(sc, "tsfake1", "party1")
			local saveModern = ns.isModern
			ns.isModern = true
			local ok, res = pcall(Scene.Run, sc, function()
				ns.threatAccess, ns.simAccess = "unknown", nil
				TA.inFight, TA.openSeen, TA.secretSeen, TA.openVotes, TA.checked = false, false, false, 0, false
				local loose = Counter(ns.Alerts, "OnLoose")
				ns.Threat:Tick(); ns.Threat:Tick()
				return string.format("%s/%s, Meldungen %d", S(ns.threatAccess), ns:ThreatMode(), loose.n)
			end)
			ns.isModern = saveModern
			if not ok then error(res, 0) end
			return res == "unknown/DISPLAY, Meldungen 0", res, "unknown/DISPLAY, Meldungen 0"
		end)
	end)
	TC("TU2", "TU2-A3", "Gruppe verlassen mitten im Kampf: keine neuen Meldungen, kein Fehler", function()
		return Flow("A3", function()
			local sc = Scene.New(2)
			Scene.Hold(sc, "tsfake1", "party1")
			Scene.Hold(sc, "tsfake2", "party2")
			local res = Scene.Run(sc, function()
				ns.simAccess = "open"
				local loose = Counter(ns.Alerts, "OnLoose")
				ns.Threat:Tick()
				local a = loose.n
				-- Gruppe weg: die Mitspieler gibt es nicht mehr (die Kulisse antwortet wie das Spiel)
				local gone = function(u) return u == "player" or (type(u) == "string" and u:find("^tsfake")) and true or false end
				local b = WithAPI({ IsInGroup = Ret(false), GetNumSubgroupMembers = Ret(0), GetNumGroupMembers = Ret(0),
					UnitExists = function(u) return gone(u) end }, function()
					ns:UpdateGroup()
					ns.Threat:Tick(); ns.Threat:Tick()
					return loose.n
				end)
				return string.format("Meldungen vorher %d, danach %d, Gruppe %d", a, b, #ns.groupUnits)
			end)
			return res == "Meldungen vorher 2, danach 2, Gruppe 1", res, "Meldungen vorher 2, danach 2, Gruppe 1"
		end)
	end)
	TC("TU2", "TU2-A4", "Warnton: über der Schwelle, darunter, wieder darüber – kein Dauerton", function()
		return Flow("A4", function()
			local steps = {}
			local pcts = { 50, 95, 95, 95, 50, 50, 95, 95 }
			for i, p in ipairs(pcts) do steps[i] = function(sc) Scene.Hold(sc, "tsfake1", "player", { party1 = p }) end end
			local got = RunLage({ steps = steps, db = { soundWarn = "ts_regain", warnThreshold = 90 } })
			local want = "HELD>WARN>WARN>WARN>HELD>HELD>WARN>WARN | L0 W2 R0 T2"
			return got == want, got, want
		end)
	end)
	TC("TU2", "TU2-A5", "Spott, Mob bleibt lose (Spott verfehlt), dann geholt: genau eine Meldung, ein Zurück", function()
		return Flow("A5", function()
			local steps = {
				function(sc) Scene.Hold(sc, "tsfake1", "party2") end,
				function(sc) Scene.Hold(sc, "tsfake1", "party2") end,     -- Spott verfehlt, Heiler hat weiter Aggro
				function(sc) Scene.Hold(sc, "tsfake1", "party2") end,
				function(sc) Scene.Hold(sc, "tsfake1", "player") end,
			}
			local got = RunLage({ steps = steps })
			local want = "LOOSE>LOOSE>LOOSE>HELD | L1 W0 R1 T1"
			return got == want, got, want
		end)
	end)
end

------------------------------------------------------------
-- TU3 Standardwerte
------------------------------------------------------------
local function DefaultsList()
	local keys = {}
	for k in pairs(ns.defaults) do keys[#keys + 1] = k end
	table.sort(keys)
	local parts = {}
	for _, k in ipairs(keys) do
		local v = ns.defaults[k]
		if type(v) == "table" then
			local n = 0
			for _ in pairs(v) do n = n + 1 end
			parts[#parts + 1] = k .. "={" .. n .. "}"
		else
			parts[#parts + 1] = k .. "=" .. tostring(v)
		end
	end
	return parts
end

local function EnsureOptions()
	local O = ns.Options
	if not O.sliderSpec and O.Build and not O.frame then pcall(O.Build, O) end
	return O
end

local function TU3()
	TC("TU3", "TU3-D1", "Neuinstallation: jedes Feld hat seinen Standard (Liste im Bericht)", function()
		local fresh = {}
		ns._MergeDefaults(fresh, ns.defaults)
		local d = H.Diff(fresh, ns.defaults, "db")
		local parts = DefaultsList()
		R.tuDefaults = table.concat(parts, ", ")
		return d == nil, #parts .. " Felder mit Standard" .. (d and (", abweichend " .. d) or ""), "alle Felder = Standard"
	end)
	TC("TU3", "TU3-D2", "Leeres oder falsches Feld -> Standard (was der Spieler meint)", function()
		local bad = {}
		for k, v in pairs(ns.defaults) do
			for _, broken in ipairs({ "nil", "typ" }) do
				local t = Copy(ns.defaults)
				if broken == "nil" then t[k] = nil else t[k] = (type(v) == "string") and 5 or "kaputt" end
				ns._MergeDefaults(t, ns.defaults)
				if H.Diff(t[k], v, k) then bad[#bad + 1] = k .. "(" .. broken .. ")" end
			end
		end
		return #bad == 0, #bad == 0 and "alle Felder" or table.concat(bad, ", "), "jedes Feld leer/falsch -> Standard"
	end)
	TC("TU3", "TU3-D3", "Regler: Standardwert liegt im Bereich und auf dem Raster", function()
		local O = EnsureOptions()
		local spec = O.sliderSpec
		if not spec then return false, "keine Regler gefunden", "Regler der Einstellungen" end
		local bad, n = {}, 0
		for key, sp in pairs(spec) do
			n = n + 1
			local v = ns.defaults[key]
			if type(v) ~= "number" then bad[#bad + 1] = key .. " ohne Zahl"
			else
				if sp.pct then v = v * 100 end
				local onGrid = math.abs((v - sp.min) / sp.step - math.floor((v - sp.min) / sp.step + 0.5)) < 1e-6
				if v < sp.min - 1e-6 or v > sp.max + 1e-6 or not onGrid then
					bad[#bad + 1] = string.format("%s=%s (%s..%s/%s)", key, S(v), S(sp.min), S(sp.max), S(sp.step))
				end
			end
		end
		return #bad == 0 and n > 0, n .. " Regler" .. (#bad > 0 and (": " .. table.concat(bad, ", ")) or " im Bereich"), "alle Regler im Bereich"
	end)
	TC("TU3", "TU3-D4", "Eingabefeld leer oder Unsinn: Wert bleibt, nichts kaputt", function()
		local O = EnsureOptions()
		local spec = O.sliderSpec or {}
		local bad, n = {}, 0
		local fake = function(text) return { GetText = function() return text end, ClearFocus = function() end } end
		for key, sp in pairs(spec) do
			if sp.commit and ns.db[key] ~= nil then
				n = n + 1
				local before = ns.db[key]
				for _, input in ipairs({ "", "   ", "abc", "%s" }) do
					local ok = pcall(sp.commit, fake(input))
					if not ok or ns.db[key] ~= before then bad[#bad + 1] = key .. " '" .. input .. "'" end
					ns.db[key] = before
				end
			end
		end
		-- Textfeld Spott-Name: leer = automatisch (Klassen-Spott)
		local e = O.editSpec and O.editSpec.tauntOverride
		local save = ns.db.tauntOverride
		if e then
			Swap(ns, "UpdateSpells", function() end)
			Swap(O, "RefreshDetected", function() end)
			pcall(e.commit, fake("   "))
			if ns.db.tauntOverride ~= "" then bad[#bad + 1] = "tauntOverride '   ' -> '" .. S(ns.db.tauntOverride) .. "'" end
			UnswapAll()
		end
		ns.db.tauntOverride = save
		return #bad == 0 and n > 0, n .. " Regler-Felder" .. (#bad > 0 and (": " .. table.concat(bad, ", ")) or " unverändert, Spott-Name leer = automatisch"),
			"leer/Unsinn ändert nichts"
	end)
	TC("TU3", "TU3-D5", "Ab Werk in der Gruppe: Aggroverlust mit Ton, Vorwarnung ohne Ton, Sync an", function()
		local fresh = {}
		ns._MergeDefaults(fresh, ns.defaults)
		local saveDb = ns.db
		ns.db = fresh
		local ok, got = pcall(RunLage, { mobs = 2, setup = function(sc)
			Scene.Hold(sc, "tsfake1", "party1")
			Scene.Hold(sc, "tsfake2", "player", { party2 = 95 })
		end })
		local f = fresh
		ns.db = saveDb
		if not ok then error(got, 0) end
		got = got .. string.format(" | Sync %s, Ton %s, Aggro-Ton %s, Vorwarn-Ton %s", S(f.sync), S(f.sound),
			S(f.soundDD ~= "none" and f.soundHealer ~= "none"), S(f.soundWarn))
		local want = "LOOSE,WARN | L1 W0 R0 T1 | Sync true, Ton true, Aggro-Ton true, Vorwarn-Ton none"
		return got == want, got, want
	end)
end

------------------------------------------------------------
-- TU4 Grundregeln mit Zufallsdaten
------------------------------------------------------------
-- Was das Addon nach den Regeln tun MUSS (unabhängig vom Code berechnet)
local function Oracle(c)
	if c.dead then return "IDLE" end
	if c.secret then return "IDLE" end
	if not c.holder then return "IDLE" end
	if c.holder == "player" then
		local maxOther = 0
		for u, p in pairs(c.others) do
			local safe = (u == "party3") or (u == "pet" and c.petsSafe)
			if not safe and p > maxOther then maxOther = p end
		end
		return maxOther >= c.thr and "WARN" or "HELD"
	end
	if c.holder == "party3" then return "OTHERTANK" end
	if c.holder == "pet" then return c.petsSafe and "PETHELD" or "LOOSE" end
	return "LOOSE"
end
R.TUOracle = Oracle

local HOLDERS = { false, "player", "player", "player", "party1", "party2", "party3", "pet" }
local OTHERS = { "party1", "party2", "party3", "pet" }

local function NewCase(rnd, k)
	local c = { k = k, holder = HOLDERS[rnd(1, #HOLDERS)] or nil, others = {}, petsSafe = rnd(0, 1) == 1,
		dead = rnd(1, 20) == 1, thr = 50 + 5 * rnd(0, 10), secret = ns.isModern and rnd(1, 10) == 1 or false }
	for _, u in ipairs(OTHERS) do
		if u ~= c.holder and rnd(1, 3) > 1 then c.others[u] = rnd(0, 109) end
	end
	-- zweite Auswertung: neue Werte (Überschreiten der Schwelle)
	c.others2 = {}
	for u, p in pairs(c.others) do c.others2[u] = math.max(0, math.min(109, p + rnd(-30, 30))) end
	return c
end

local function CaseText(c)
	local o = {}
	for _, u in ipairs(OTHERS) do if c.others[u] then o[#o + 1] = u .. " " .. c.others[u] .. ">" .. c.others2[u] end end
	return string.format("Fall %d: Halter %s, %s, Schwelle %d, Begleiter sicher %s, tot %s, geheim %s", c.k, S(c.holder),
		#o > 0 and table.concat(o, " ") or "keine anderen", c.thr, S(c.petsSafe), S(c.dead), S(c.secret))
end

-- eine Portion Fälle in EINER Kulisse; liefert Verletzungen und Zeit
local function Portion(rnd, from, to)
	local bad = {}
	local sc = Scene.New(1)
	sc.units.pet = { name = "Wolf" }
	local t0 = Ms()
	Scene.Run(sc, function()
		local saveThr, savePets, saveMode = ns.db.warnThreshold, ns.db.petsSafe, ns.db.threatMode
		local saveWarned = ns.DD and ns.DD.warned
		ns.db.threatMode = "AUTO"
		local loose = Counter(ns.Alerts, "OnLoose", false)
		local warn = Counter(ns.Alerts, "OnWarn", false)
		local ok, err = pcall(function()
			for k = from, to do
				local c = NewCase(rnd, k)
				ns.db.warnThreshold, ns.db.petsSafe = c.thr, c.petsSafe
				ns.threatAccess, ns.simAccess = "open", "open"
				sc.secret, sc.units.tsfake1.dead = c.secret, c.dead
				Scene.Hold(sc, "tsfake1", c.holder or nil, c.others)
				wipe(ns.owners)
				local m = { unit = "tsfake1" }
				ns.mobs.tsfake1 = m
				loose.n, warn.n = 0, 0
				local errBefore = ns.errorCount or 0
				local okE, e = pcall(ns.Threat.Evaluate, ns.Threat, "tsfake1", m)
				local want = Oracle(c)
				local function fail(why) bad[#bad + 1] = CaseText(c) .. " -> " .. why end
				if not okE then fail("Lua: " .. tostring(e))
				elseif m.state ~= want then fail("ist " .. S(m.state) .. ", soll " .. want)
				elseif (want == "LOOSE") ~= (loose.n == 1) then fail("Meldungen " .. loose.n .. " bei " .. want)
				elseif type(m.maxOther) == "number" and m.maxOther < 0 then fail("Wert < 0")
				elseif ns.Threat:RuleViolation(m) then fail("Grundregel " .. S(ns.Threat:RuleViolation(m)))
				elseif (ns.errorCount or 0) ~= errBefore then fail("Fehlerzähler")
				else
					-- zweite Auswertung: Warnung GENAU beim Überschreiten der Schwelle
					if c.holder == "player" and not c.dead and not c.secret then
						Scene.Hold(sc, "tsfake1", "player", c.others2)
						local c2 = { holder = "player", others = c.others2, petsSafe = c.petsSafe, thr = c.thr }
						local want2 = Oracle(c2)
						warn.n = 0
						local okE2, e2 = pcall(ns.Threat.Evaluate, ns.Threat, "tsfake1", m)
						local crossed = (want == "HELD" and want2 == "WARN") and 1 or 0
						if not okE2 then fail("Lua (2.): " .. tostring(e2))
						elseif m.state ~= want2 then fail("2. ist " .. S(m.state) .. ", soll " .. want2)
						elseif warn.n ~= crossed then fail("Warnungen " .. warn.n .. ", soll " .. crossed)
						end
					end
					-- DD-Ansicht mit denselben Zahlen (auch geheim): nie ein Lua-Fehler
					local D = ns.DD
					if D and D.f and D.ShowSecret then
						local p = c.others.party1 or 0
						local okD, eD = pcall(WithAPI, {}, function()
							if c.secret then D:ShowSecret(p, SECRET, SECRET) else D:ShowSecret(p, (p >= 100) and 3 or 0, p >= 100) end
						end)
						if not okD then fail("DD-Ansicht: " .. tostring(eD)) end
					end
				end
				if ns.isModern and c.secret then ns.threatAccess = "open" end
			end
		end)
		ns.db.warnThreshold, ns.db.petsSafe, ns.db.threatMode = saveThr, savePets, saveMode
		if ns.DD then ns.DD.warned = saveWarned; if ns.DD.f then ns.DD.f:Hide() end end
		if not ok then bad[#bad + 1] = "Portion " .. from .. "–" .. to .. ": Lua " .. tostring(err) end
	end)
	return bad, Ms() - t0
end
R.TUPortion = Portion

-- Fortsetzung: je Aufruf (= je Bild) eine Portion; danach die Auswertung
local function TU4Continuation()
	local rnd = NewRand(R.TU_SEED)
	local k, bad, worst, portions = 1, {}, 0, 0
	local blk0, real0 = #(ns.blocked or {}), R.realCalls or 0
	return function()
		if k <= R.TU_CASES then
			local to = math.min(R.TU_CASES, k + R.TU_PORTION - 1)
			local b, ms = Portion(rnd, k, to)
			for _, x in ipairs(b) do if #bad < 5 then bad[#bad + 1] = x end end
			portions = portions + 1
			if ms > worst then worst = ms end
			k = to + 1
			return true
		end
		R.tuRandom = string.format("Zufall: Startwert %d, %d Fälle in %d Portionen, langsamste Portion %.1f ms",
			R.TU_SEED, R.TU_CASES, portions, worst)
		TC("TU4", "TU4-G1", "Grundregeln: Zustand, Meldung, Warnung beim Überschreiten, Werte >= 0, kein Lua-Fehler (" .. R.TU_CASES .. " Fälle)", function()
			return #bad == 0, #bad == 0 and (R.TU_CASES .. " Fälle ohne Verletzung") or Clean(table.concat(bad, " || ")),
				"0 Verletzungen (Startwert " .. R.TU_SEED .. ")"
		end)
		TC("TU4", "TU4-G2", "je Bild < 8 ms (Portion à " .. R.TU_PORTION .. " Fälle)", function()
			return worst < 8, string.format("langsamste Portion %.1f ms", worst), "< 8 ms"
		end)
		TC("TU4", "TU4-G3", "keine geschützte Aktion, nichts Echtes ausgeführt", function()
			local blk, real = #(ns.blocked or {}) - blk0, (R.realCalls or 0) - real0
			return blk == 0 and real == 0, string.format("gesperrt %d, echt %d", blk, real), "gesperrt 0, echt 0"
		end)
		return false
	end
end

------------------------------------------------------------
-- TU5 Echte Daten (nur lesen)
------------------------------------------------------------
local function DiagEntries()
	local d = ThreatSentinelDB and ThreatSentinelDB.diag
	return (type(d) == "table" and type(d.entries) == "table") and d.entries or {}
end

local function TU5()
	TC("TU5", "TU5-E1", "Diagnose-Protokoll: keine Namen, keine Lua-Fehler und keine verletzte Grundregel in dieser Version", function()
		local entries = DiagEntries()
		local names = {}
		if ns.playerName and ns.playerName ~= "" then names[#names + 1] = ns.playerName end
		for n in pairs(ns.groupNames or {}) do if type(n) == "string" and #n > 2 then names[#names + 1] = n end end
		local bad, fights, lesbar, rules = {}, 0, 0, 0
		for _, e in ipairs(entries) do
			local t = tostring(e.t or "")
			for _, n in ipairs(names) do
				if t:find(n, 1, true) then bad[#bad + 1] = "Name in " .. S(e.k) end
			end
			if e.v == ns.version then
				if e.k == "FEHLER" then bad[#bad + 1] = "FEHLER: " .. t:sub(1, 60) end
				if e.k == "GRUNDREGEL" then rules = rules + 1; bad[#bad + 1] = t:sub(1, 80) end
			end
			if e.k == "KAMPF" then fights = fights + (e.n or 1) end
			if e.k == "LESBAR-PLAKETTEN" or e.k == "LESBAR" then lesbar = lesbar + (e.n or 1) end
		end
		local got = string.format("%d Einträge, %d Kämpfe, %d LESBAR, Grundregel verletzt %d", #entries, fights, lesbar, rules)
		return #bad == 0, #bad == 0 and got or Clean(got .. ": " .. table.concat(bad, "; ")), "keine Namen, 0 Fehler, 0 Grundregel"
	end)
	local log = ThreatSentinelDB and ThreatSentinelDB.testlog
	local events = type(log) == "table" and type(log.events) == "table" and log.events or {}
	if #events == 0 then
		TK("TU5", "TU5-E2", "Testprotokoll eines echten Kampfs nachrechnen", "kein aufgezeichneter Kampf (Testprotokoll leer – /ts log an, dann kämpfen)")
	else
		TC("TU5", "TU5-E2", "Testprotokoll eines echten Kampfs nachrechnen", function()
			local bad, states, loose, lastT = {}, 0, 0, nil
			for i, line in ipairs(events) do
				local t, typ, rest = line:match("^([%d%.%-]+)|(%u+)|(.*)$")
				if t then
					t = tonumber(t)
					if typ == "META" then lastT = nil
					else
						if lastT and t and t + 0.01 < lastT then bad[#bad + 1] = "Zeit rückwärts in Zeile " .. i end
						lastT = t or lastT
					end
					if typ == "STATE" then
						states = states + 1
						local to = rest:match("to=([%u]+)")
						if to == "LOOSE" then
							loose = loose + 1
							local role = rest:match("role=([%u]+)")
							if not role or role == "NIL" then bad[#bad + 1] = "LOOSE ohne Rolle in Zeile " .. i end
						end
					elseif typ == "ERROR" then
						bad[#bad + 1] = "Lua-Fehler in Zeile " .. i
					end
				end
				if #bad >= 5 then break end
			end
			local got = string.format("%d Zeilen, %d Zustände, %d lose", #events, states, loose)
			return #bad == 0, #bad == 0 and got or (got .. ": " .. table.concat(bad, "; ")), "Zeit vorwärts, LOOSE mit Rolle, keine Lua-Fehler"
		end)
	end
	TC("TU5", "TU5-E3", "Grundregel-Wächter im Spiel: Verletzung -> 'GRUNDREGEL VERLETZT' im Diagnose-Protokoll, ohne Namen", function()
		local T = ns.Threat
		local written = {}
		Swap(ns, "Diag", function(kind, text) written[#written + 1] = tostring(kind) .. " " .. tostring(text) end)
		local saveSeen, saveMember = T.ruleSeen, ns.memberNow
		T.ruleSeen, ns.memberNow = {}, false
		local ok, res = pcall(function()
			local m = { state = "WARN", maxOther = 40, warnStatus = false, name = "Testmob 1" }
			local r1 = T:CheckRules(m)
			T:CheckRules(m)                                          -- zweimal: nur einmal je Kampf
			local r2 = T:CheckRules({ state = "HELD", maxOther = 95 })
			local r3 = T:CheckRules({ state = "LOOSE", alerted = false })
			local r4 = T:CheckRules({ state = "HELD", maxOther = 20 })
			return string.format("%s %s %s %s, Zeilen %d", S(r1), S(r2), S(r3), S(r4), #written)
		end)
		T.ruleSeen, ns.memberNow = saveSeen, saveMember
		UnswapAll()
		if not ok then error(res, 0) end
		local named = false
		for _, w in ipairs(written) do if w:find("Testmob", 1, true) then named = true end end
		local want = "G1 G2 G4 nil, Zeilen 3"
		return res == want and not named and written[1] and written[1]:find("^GRUNDREGEL VERLETZT G1") ~= nil,
			Clean(res .. (written[1] and (" · " .. written[1]) or "")), want .. " (einmal je Regel, ohne Namen)"
	end)
end

------------------------------------------------------------
-- TU6 Regressionen: jeder Befund seit dem 3.11. -> bleibender Test (Zuordnung; die Tests selbst stehen in A–K, U)
------------------------------------------------------------
R.REGRESSIONS = {
	{ "03.11-1 Zustand 'unknown' in Forever", { "T164", "T166", "T166b" } },
	{ "03.11-2 Modus ANZEIGE: keine eigenen Entscheidungen", { "T153", "T168", "T110" } },
	{ "03.11-3 Blizzard-Anzeigen bei 'immer nur Anzeige'", { "T170" } },
	{ "03.11-4 Selbsttest mit G.SetTestFlavor", { "T05" } },
	{ "03.11-5 Kampflog und Meter in alten Clients", { "T176", "T111" } },
	{ "2.4.4-1 Ladefehler 2.4.1–2.4.3", { "T01", "T-L1" } },
	{ "2.4.4-2 Nahtstelle ns.API", { "T104", "T106", "T155" } },
	{ "2.4.4-3 Stille Fehler melden", { "T141", "T142", "T143" } },
	{ "2.4.4-4 Fehler beim Zurücksetzen legt das Addon still", { "T-R4" } },
	{ "2.4.4-5a T131/T161 fehlten", { "T131", "T161" } },
	{ "2.4.4-5b Bildschirmfoto nicht über ns.Act", { "T-R5b" } },
	{ "2.4.4-5c Testroutine-Knöpfe für jeden Spieler", { "T-R5c" } },
	{ "2.4.5-1 Übersprungene Testfälle ('noch nicht')", { "T-R13", "T122", "T128" } },
	{ "2.4.5-2 T106 und die C_-Tabellen", { "T106" } },
	{ "Launch T22 Name ohne Realm", { "T22" } },
	{ "09.11 Aggrometer nach Aggro sortieren", { "T-A1", "T-A2", "T-A3", "T-A4", "T-A5" } },
	{ "2.5.2-1 Log-Auswertung nach /reload", { "T139b" } },
	{ "2.5.2-2 LESBAR misst leere Liste", { "T-A6b" } },
	{ "2.5.2-3 Stufe 3 (Schätzung) ohne Quelle in Forever", { "T-A3", "T-A8" } },
	{ "2.5.2-4 Kopf 'Reihenfolge: sicher' nur nach Rolle", { "T167", "T-A7" } },
	{ "09.11 Sync nicht über eigene Kanäle", { "T-SY2", "T76" } },
	{ "09.11 GoldSentinelTest 2", { "T-GT1", "T-GT2" } },
	{ "2.5.2 T153 Kulisse lesbar", { "T153" } },
	{ "2.5.2 T180/T181 Rahmenname, Testzentrale über Blizzard-Fenstern", { "T180", "T181" } },
	{ "P1 Modus springt im Kampf", { "T-P1", "T-P1b" } },
	{ "P3 Gruppe zählt Begleiter", { "T-P3" } },
	{ "T135 GoldSentinelGame Version 3", { "T132" } },
	{ "2.5.4-1 Sprachtest legt das Addon still", { "T-L1", "T-L2" } },
	{ "Q4 Aggro-Warnung mit lesbarem isTanking/Status", { "T-Q4", "T169" } },
	{ "2.5.4-3 'kein Weg' zählt als verworfen", { "T-SY2" } },
	{ "2.5.4-4 LESBAR misst Ziel des Mobs nicht", { "T-A6" } },
	{ "Q1 T144 falscher Alarm", { "T-Q1", "T144" } },
	{ "Q2 Simulationen ohne Ort", { "T-Q2" } },
	{ "Q3 Hinweiszeile", { "T-Q3" } },
	{ "Q5 Sync im Kampf nachholen", { "T-Q5" } },
	{ "2.5.6-1 'nachgeholt' zählt nicht Gesendetes", { "T-Q5" } },
	{ "2.5.8-1 T-K2 im Client immer FEHLER", { "T-K2" } },
	{ "2.5.8-2 T-G1 in Forever FEHLER", { "T-G1" } },
	{ "2.5.8-3 Spott-Grund ohne Filter", { "T-W1" } },
	{ "Sync-Anweisungen: nie eigener Kanal, geschützter Absender, alte Version", { "T-SY2", "T76", "TU1-L12" } },
	{ "14.11 SYNC gemeinsamer Sync (Senden nur Gruppe, Empfang, alte Version, kein Kanal, Netz)",
		{ "T-SYNC", "T-GS1", "T-GS2", "T-GS3", "T-GS4", "T-GS5", "T-N1", "T-N2", "T-N3", "T-N4" } },
	{ "2.5.11-2 T-MN2 konnte echte Marktdaten beschreiben", { "T-MN2" } },
	{ "BL Befehlsliste beim Tippen", { "T-BL1", "T-BL2", "T-BL3", "T-BL4", "T-BL5", "T-BL6" } },
}

local function TU6Check()
	TC("TU6", "TU6-R1", "Regressionen: jeder Befund hat seinen Test, der Test lief", function()
		local seen = R.seen or {}
		local full = seen.T01 ~= nil   -- Bereich A gelaufen = ganzer Lauf
		if not full then return true, "nur Bereich U gelaufen – Zählung mit /ts testroutine", "vollständiger Lauf" end
		local have, missing, failed, client = 0, {}, {}, {}
		for _, reg in ipairs(R.REGRESSIONS) do
			local ran, allOk = 0, true
			for _, id in ipairs(reg[2]) do
				local st = seen[id]
				if st == "OK" then ran = ran + 1
				elseif st == "FEHLER" then ran = ran + 1; allOk = false
				elseif st == "CLIENT" then client[#client + 1] = id
				elseif st == "SKIP" and (id == "T-K2" or id == "T180" or id == "T181" or id == "T-A7") then client[#client + 1] = id
				end
			end
			if ran > 0 or #client > 0 then have = have + 1 else missing[#missing + 1] = reg[1] end
			if not allOk then failed[#failed + 1] = reg[1] end
		end
		R.tuReg = string.format("Regressionen: %d von %d vorhanden", have, #R.REGRESSIONS)
		local got = R.tuReg .. (#client > 0 and (", nur im Client: " .. table.concat(client, " ")) or "")
		if #missing > 0 then got = got .. ", fehlt: " .. table.concat(missing, "; ") end
		if #failed > 0 then got = got .. ", Test FEHLER: " .. table.concat(failed, "; ") end
		return #missing == 0 and #failed == 0, Clean(got), "alle vorhanden, alle OK"
	end)
end

local function TU6Tests()
	TC("TU6", "T-R4", "Regression 2.4.4-4: Fehler in einem Schritt der Routine gibt das Addon frei", function()
		local save = { ns.routineRunning, ns.actLog, R.running, R.cont }
		ns.routineRunning, R.running = true, true
		R:OnStepError("TS-Test: Fehler beim Zurücksetzen", true)
		local got = string.format("routineRunning %s, actLog %s, running %s", S(ns.routineRunning), S(ns.actLog), S(R.running))
		ns.routineRunning, ns.actLog, R.running, R.cont = save[1], save[2], save[3], save[4]
		local want = "routineRunning false, actLog nil, running false"
		return got == want, got, want
	end)
	TC("TU6", "T-R5b", "Regression 2.4.4-5b: Bildschirmfoto läuft über ns.Act (im Test nur mitgeschrieben)", function()
		local LG, root = ns.Log, ThreatSentinelDB
		local save = { root.testlog, LG.on, LG.lastShot, LG.shotCount, LG.shotsBlocked, LG.auto }
		root.testlog = { on = true, shots = true, meta = {}, events = {} }
		LG.on, LG.lastShot, LG.shotCount, LG.shotsBlocked, LG.auto = true, -1000, 0, false, false
		local before = ns.actLog and ns.actLog.n.shot or 0
		local ok, err = pcall(LG.Shot, LG, "tu-test", nil)
		local after = ns.actLog and ns.actLog.n.shot or 0
		root.testlog, LG.on, LG.lastShot, LG.shotCount, LG.shotsBlocked, LG.auto = save[1], save[2], save[3], save[4], save[5], save[6]
		if not ok then error(err, 0) end
		if not Screenshot then return true, "kein Screenshot im Client", "-" end
		return after - before == 1, "mitgeschrieben " .. (after - before), "mitgeschrieben 1, echt 0"
	end)
	TC("TU6", "T-R5c", "Regression 2.4.4-5c: Knöpfe der Testroutine nur für den Entwickler", function()
		local TM = ns.Test
		local parent = R.tuDummy or CreateFrame("Frame", nil, UIParent)
		R.tuDummy = parent
		parent:Hide()
		local close = R.tuDummyClose or CreateFrame("Button", nil, parent)
		R.tuDummyClose = close
		Swap(ns, "IsDev", function() return false end)
		local a = TM:AddRoutineButtons(parent, close)
		UnswapAll()
		Swap(ns, "IsDev", function() return true end)
		local b = TM:AddRoutineButtons(parent, close)
		UnswapAll()
		local got = "Spieler " .. a .. ", Entwickler " .. b
		local want = "Spieler 0, Entwickler " .. (#R.AREAS + 1)
		return got == want, got, want
	end)
	TC("TU6", "T-R13", "Regression 2.4.5-1: kein Fall nur 'noch nicht automatisiert'", function()
		local run = R:RunObject()
		local n = 0
		for _, e in ipairs(run and run.results or {}) do
			if e.status == "SKIP" and tostring(e.grund or ""):find("noch nicht", 1, true) then n = n + 1 end
		end
		return n == 0 and (R.notAuto or 0) == 0, "nicht automatisiert " .. (R.notAuto or 0) .. ", 'noch nicht' " .. n, "0 / 0"
	end)
end

------------------------------------------------------------
-- TU7 Formen des Spiels
------------------------------------------------------------
local function TU7()
	local G = GoldSentinelGame
	for _, f in ipairs({ "forever", "era", "tbc" }) do
		TC("TU7", "TU7-F-" .. f, "Lagen-Katalog im Client " .. f, function()
			local saveAccess, saveChecked = ns.threatAccess, ns.ThreatAccess.checked
			local ok, a, b, c = pcall(H.WithFlavor, f, function()
				if not ns.isModern then ns.threatAccess = "open" end
				return CatalogCheck("TU7", f, ns.isModern, f)
			end)
			ns.threatAccess, ns.ThreatAccess.checked = saveAccess, saveChecked
			if not ok then error(a, 0) end
			return a, b, c
		end)
	end
	TC("TU7", "TU7-S1", "Sprachen deDE und enUS: Meldungen ohne Platzhalter-Fehler, Lagen gleich", function()
		local bad = {}
		local saveLoc = ns.activeLocale
		for _, code in ipairs({ "deDE", "enUS" }) do
			ns:ApplyLocale(code)
			local okC, a, b = pcall(CatalogCheck, "TU7", code, ns.isModern, code)
			if not okC then bad[#bad + 1] = code .. ": Lua " .. tostring(a)
			elseif not a then bad[#bad + 1] = code .. ": " .. tostring(b) end
			-- Meldungstexte mit Zahl/Name formatieren
			for _, key in ipairs({ "LOOSE", "TAUNT_CD", "CLAIMED", "OWNER", "AOE_HINT", "EMERGENCY", "SELF_AGGRO", "MSG_CC_DUR" }) do
				local fmt = L[key]
				if type(fmt) == "string" then
					local okF = pcall(string.format, fmt, 3, 4, 5)
					local okS = pcall(string.format, fmt, "x", "y", "z")
					if not okF and not okS then bad[#bad + 1] = code .. " " .. key end
				end
			end
		end
		ns:ApplyLocale(saveLoc)
		return #bad == 0, #bad == 0 and "deDE und enUS" or Clean(table.concat(bad, "; ")), "beide Sprachen wie erwartet"
	end)
	if H.Shown and ns.UICheck and ns.UICheck.Available and ns.UICheck.Available() then
		TC("TU7", "TU7-K1", "Skalierung 80 % und 150 %: HUD, Aggrometer und DD-Ansicht ganz im Bild", function()
			local U = ns.UICheck
			local bad = {}
			local save = { ns.db.hudScale, ns.db.meterScale, ns.db.ddScale }
			local shown = {}
			for _, k in ipairs({ "HUD", "Meter", "DD" }) do shown[k] = ns[k] and ns[k].f and ns[k].f:IsShown() end
			for _, sc in ipairs({ 0.8, 1.5 }) do
				ns.db.hudScale, ns.db.meterScale, ns.db.ddScale = sc, sc, sc
				ns:ApplySettings()
				for _, k in ipairs({ "HUD", "Meter", "DD" }) do
					local f = ns[k] and ns[k].f
					if f then
						f:Show()
						local r = U.Rect(f)
						local ur = U.Rect(UIParent)
						if r and ur and (r.l < ur.l - 1 or r.r > ur.r + 1 or r.b < ur.b - 1 or r.t > ur.t + 1) then
							bad[#bad + 1] = string.format("%s bei %d %%", k, sc * 100)
						end
					end
				end
			end
			ns.db.hudScale, ns.db.meterScale, ns.db.ddScale = save[1], save[2], save[3]
			ns:ApplySettings()
			for _, k in ipairs({ "HUD", "Meter", "DD" }) do
				local f = ns[k] and ns[k].f
				if f then if shown[k] then f:Show() else f:Hide() end end
			end
			return #bad == 0, #bad == 0 and "im Bild" or table.concat(bad, ", "), "alle ganz im Bild"
		end)
	else
		TCL("TU7", "TU7-K1", "Skalierung 80 % und 150 %: Anzeigen ganz im Bild", "/ts testroutine u im echten Client (Rechtecke)")
	end
end

------------------------------------------------------------
-- BL Befehlsliste (T-BL1–T-BL6)
------------------------------------------------------------
local function Entries(list)
	local out = {}
	for _, it in ipairs(list) do out[#out + 1] = it.entry[1] end
	return table.concat(out, ",")
end

local function BL()
	local CH = ns.CmdHint
	TC("TU6", "T-BL1", "Befehlsliste: jeder Befehl des Handlers steht in der Liste, der Handler führt genau ihn aus", function()
		Swap(ns, "IsDev", function() return true end)
		local list = CH:List("")
		local inList = {}
		for _, it in ipairs(list) do inList[it.entry] = true end
		local bad = {}
		local hits = {}
		for _, other in ipairs(ns.COMMANDS) do
			local me = other
			Swap(me, "run", function() hits[#hits + 1] = me end)
		end
		for _, c in ipairs(ns.COMMANDS) do
			if not inList[c] then bad[#bad + 1] = "nicht in der Liste: " .. c[1] end
			local forms = { c[1], c[2] }
			for _, a in ipairs(c.alias or {}) do forms[#forms + 1] = a end
			for _, form in ipairs(forms) do
				wipe(hits)
				SlashCmdList.THREATSENTINEL(form)
				if #hits ~= 1 or hits[1] ~= c then bad[#bad + 1] = "'" .. form .. "' -> " .. (hits[1] and hits[1][1] or "nichts") end
			end
		end
		UnswapAll()
		-- unbekannt / leer -> Einstellungen
		local opt = 0
		Swap(ns.Options, "Toggle", function() opt = opt + 1 end)
		SlashCmdList.THREATSENTINEL("")
		SlashCmdList.THREATSENTINEL("gibtsnicht")
		UnswapAll()
		if opt ~= 2 then bad[#bad + 1] = "leer/unbekannt -> Einstellungen " .. opt .. "x" end
		return #bad == 0, #bad == 0 and (#ns.COMMANDS .. " Befehle, Liste " .. #list) or table.concat(bad, "; "),
			"alle Befehle in der Liste, jede Form genau ihr Eintrag"
	end)
	TC("TU6", "T-BL2", "Befehlsliste: Filtern mit jedem Buchstaben, meistbenutzte oben", function()
		Swap(ns, "IsDev", function() return true end)
		local saveLoc, saveUse = ns.activeLocale, ns.db.cmdUse
		ns.activeLocale = "deDE"
		ns.db.cmdUse = {}
		local r = {}
		r[1] = Entries(CH:List("ver"))
		r[2] = #CH:List("te")
		r[3] = Entries(CH:List("lo"))
		r[4] = #CH:List("x")
		r[5] = #CH:List("")
		ns.db.cmdUse = { bedrohung = 5, spenden = 2 }
		local top = CH:List("")
		r[6] = top[1].entry[1] .. "," .. top[2].entry[1]
		ns.activeLocale = "enUS"
		r[7] = Entries(CH:List("thr"))
		UnswapAll()
		Swap(ns, "IsDev", function() return false end)
		ns.activeLocale = "deDE"
		ns.db.cmdUse = {}
		r[8] = Entries(CH:List(""))
		UnswapAll()
		ns.activeLocale, ns.db.cmdUse = saveLoc, saveUse
		local got = table.concat({ r[1], S(r[2]), r[3], S(r[4]), S(r[5]), r[6], r[7], r[8] }, " | ")
		local want = "verschieben | 17 | protokoll,log,log an,log aus,log bericht,log bilder,log leeren | 0 | " .. #ns.COMMANDS
			.. " | bedrohung,spenden | bedrohung | einstellungen,bedrohung,verschieben,protokoll,spenden,sync test"
		return got == want, got, want
	end)
	TC("TU6", "T-BL3", "Befehlsliste: Klick wählt (Kopf 'Enter = …'), Enter führt aus, Liste bleibt beim Klick offen", function()
		Swap(ns, "IsDev", function() return true end)
		local saveLoc, saveSel, saveClick, saveInstant = ns.activeLocale, CH.selected, CH.clickAt, CH.instantClose
		ns.activeLocale = "deDE"
		local moved = 0
		Swap(ns.Mover, "Toggle", function() moved = moved + 1 end)
		local opt = 0
		Swap(ns.Options, "Toggle", function() opt = opt + 1 end)
		local r = {}
		local ok, err = pcall(function()
			CH:Show(nil, "ver")
			local item = CH.items[1]
			CH:Select(item, true)                                 -- Mausklick
			r[1] = CH.frame.head:GetText() == string.format(L.CH_ENTER, "/ts verschieben")
			CH.instantClose = true
			CH.editBox = "box"
			CH:OnFocusLost("box")                                 -- Fokusverlust direkt nach dem Klick
			r[2] = CH.frame:IsShown()
			SlashCmdList.THREATSENTINEL("ver")                    -- Enter mit unvollständigem Wort
			r[3] = moved == 1 and opt == 0
			r[4] = CH:Selection() == nil
			-- alte Auswahl (> 10 s) gilt nicht mehr
			CH:Select(item, false)
			CH.selected.t = CH.selected.t - 11
			SlashCmdList.THREATSENTINEL("ver")
			r[5] = moved == 1 and opt == 1
			-- Tab wählt den nächsten
			CH:Show(nil, "log")
			CH.selected = nil
			CH:SelectNext(1); local a = CH:Selection().item.entry[1]
			CH:SelectNext(1); local b = CH:Selection().item.entry[1]
			r[6] = a .. ">" .. b
		end)
		CH:Hide()
		CH.selected, CH.clickAt, CH.instantClose, CH.editBox = saveSel, saveClick, saveInstant, nil
		ns.activeLocale = saveLoc
		UnswapAll()
		if not ok then error(err, 0) end
		local got = table.concat({ S(r[1]), S(r[2]), S(r[3]), S(r[4]), S(r[5]), S(r[6]) }, " ")
		local want = "true true true true true protokoll>log"
		return got == want, got, want .. " (Kopf, offen, ausgeführt, Auswahl weg, alte Auswahl verfällt, Tab)"
	end)
	TC("TU6", "T-BL4", "Befehlsliste: das Chatfeld wird nie beschrieben (nur HookScript, SetFocus)", function()
		local box = R.tuBox or CreateFrame("EditBox", nil, UIParent)
		R.tuBox = box
		box:Hide()
		local calls = { set = 0, insert = 0, script = 0, hook = 0, focus = 0 }
		local text = "/ts be"
		-- nur die eigene Test-Box bekommt Zähler (eigenes Objekt, kein Blizzard-Feld)
		box.GetText = function() return text end
		box.SetText = function() calls.set = calls.set + 1 end
		box.Insert = function() calls.insert = calls.insert + 1 end
		box.SetScript = function() calls.script = calls.script + 1 end
		box.SetFocus = function() calls.focus = calls.focus + 1 end
		box.IsShown = function() return true end
		local hooks = {}
		box.HookScript = function(_, ev, fn) calls.hook = calls.hook + 1; hooks[ev] = fn end
		local saveHooked = CH.hooked[box]
		CH.hooked[box] = nil
		local ok, err = pcall(function()
			CH:HookBox(box)
			hooks.OnTextChanged(box)
			local shown = CH.frame and CH.frame:IsShown()
			CH:Select(CH.items[1], true)
			hooks.OnTabPressed(box)
			CH.instantClose = true
			CH.clickAt = nil
			hooks.OnEditFocusLost(box)
			return shown
		end)
		CH.instantClose = nil
		CH:Hide()
		CH.selected = nil
		CH.hooked[box] = saveHooked
		for _, k in ipairs({ "GetText", "SetText", "Insert", "SetScript", "SetFocus", "IsShown", "HookScript" }) do box[k] = nil end
		if not ok then error(err, 0) end
		local got = string.format("Liste %s, SetText %d, Insert %d, SetScript %d, HookScript %d, SetFocus %d", S(err),
			calls.set, calls.insert, calls.script, calls.hook, calls.focus)
		local good = err == true and calls.set == 0 and calls.insert == 0 and calls.script == 0 and calls.hook == 4 and calls.focus >= 1
		return good, got, "Liste true, SetText 0, Insert 0, SetScript 0, HookScript 4, SetFocus >= 1"
	end)
	TC("TU6", "T-BL5", "Befehlsliste: Entwickler-Befehle nur für den Entwickler", function()
		local dev = 0
		for _, c in ipairs(ns.COMMANDS) do if c.dev then dev = dev + 1 end end
		Swap(ns, "IsDev", function() return false end)
		local a = CH:List("")
		local leak = 0
		for _, it in ipairs(a) do if it.entry.dev then leak = leak + 1 end end
		UnswapAll()
		Swap(ns, "IsDev", function() return true end)
		local b = #CH:List("")
		UnswapAll()
		local got = string.format("Spieler %d (davon Entwickler %d), Entwickler %d", #a, leak, b)
		local want = string.format("Spieler %d (davon Entwickler 0), Entwickler %d", #ns.COMMANDS - dev, #ns.COMMANDS)
		return got == want, got, want
	end)
	TC("TU6", "T-BL6", "Befehlsliste: alle Sprachen, Beschreibungen ohne Platzhalter-Fehler", function()
		local bad = {}
		for code, tbl in pairs(ns.LOCALES) do
			for _, c in ipairs(ns.COMMANDS) do
				local t = rawget(tbl, c[3])
				if type(t) ~= "string" or t == "" then bad[#bad + 1] = code .. " fehlt " .. c[3]
				else
					local n = select(2, t:gsub("%%s", ""))
					local want = c.descArg and 1 or 0
					if n ~= want then bad[#bad + 1] = code .. " " .. c[3] .. " %s " .. n end
					if c.descArg and not pcall(string.format, t, c.descArg) then bad[#bad + 1] = code .. " " .. c[3] .. " format" end
				end
			end
			for _, k in ipairs({ "CH_ENTER", "CH_NOMATCH", "O_CMDHINT" }) do
				if type(rawget(tbl, k)) ~= "string" then bad[#bad + 1] = code .. " fehlt " .. k end
			end
		end
		return #bad == 0, #bad == 0 and "deDE und enUS vollständig" or table.concat(bad, "; "), "alle Texte da, Platzhalter passen"
	end)
end

------------------------------------------------------------
-- SYNC: gemeinsame Datei GoldSentinelSync (T-SYNC, T-GS1–T-GS5, T-N1–T-N4). Ersetzt werden nur Einträge von
-- GoldSentinelSync.api und eigene Felder, nie Blizzard-Funktionen. Was ein Test in die Warteschlange der Datei legt,
-- nimmt er wieder heraus (es darf nichts wirklich gesendet werden).
------------------------------------------------------------
local function SYNC()
	local G = rawget(_G, "GoldSentinelSync")
	local Sy = ns.Sync
	if type(G) ~= "table" then
		C("T-SYNC", "U", "Sync über GoldSentinelSync: Senden und Empfangen", function() return false, "GoldSentinelSync fehlt", "geladen" end)
		return
	end
	-- Senden: echter Weg bis in die Warteschlange der Datei (ns.Act kurz echt), nur PARTY/RAID
	local function SendCase(inRaid)
		local q0, n0 = #G.queue, #G.netQueue
		local saveLog, saveSync = ns.actLog, ns.db.sync
		Swap(G.api, "inGuild", function() return true end)
		Swap(G.api, "inGroup", function() return true end)
		Swap(G.api, "inRaid", function() return inRaid end)
		Swap(G.api, "send", function() return false end)       -- falls doch etwas gepumpt würde: nichts geht raus
		ns.actLog, ns.db.sync = nil, true
		local ok, r = pcall(WithAPI, { IsInGroup = Ret(true), IsInRaid = Ret(inRaid), InCombatLockdown = Ret(false) },
			function() return Sy:Send("H:TANK:tu-test") end)
		ns.actLog, ns.db.sync = saveLog, saveSync
		local new = {}
		for i = #G.queue, q0 + 1, -1 do table.insert(new, 1, table.remove(G.queue, i)) end
		local netNew = #G.netQueue - n0
		for i = #G.netQueue, n0 + 1, -1 do table.remove(G.netQueue, i) end
		UnswapAll()
		if not ok then error(r, 0) end
		local d = {}
		for _, e in ipairs(new) do d[#d + 1] = S(e.dist) .. (e.prefix == Sy.PREFIX and "" or ("?" .. S(e.prefix))) end
		local first = new[1] and new[1].msg or ""
		return string.format("%s %s Netz %d Kopf %s", S(r), table.concat(d, "+"), netNew,
			S(first:match("^#S1:%w+:%w+:H:TANK:tu%-test$") ~= nil))
	end
	C("T-SYNC", "U", "Sync über GoldSentinelSync: Senden nur an Gruppe/Schlachtzug, Empfang über den Endpunkt", function()
		local a = SendCase(false)
		local b = SendCase(true)
		ns.syncRoles.Grimbar = nil
		Sy:OnReceive("H:TANK:2.5.13", "Grimbar", "PARTY")
		local r = ns.syncRoles.Grimbar
		local got = a .. " | " .. b .. " | empfangen " .. S(r and r.role)
		local want = "true PARTY Netz 0 Kopf true | true RAID Netz 0 Kopf true | empfangen TANK"
		return got == want, got, want .. " (keine GUILD, kein CHANNEL, kein WHISPER)"
	end)
	C("T-GS1", "U", "Senden geht über ep:Send (scope group), nie CHANNEL", function()
		local captured
		Swap(Sy.ep, "Send", function(_, msg, opts) captured = S(msg) .. " " .. S(opts and opts.scope); return true, 1 end)
		local saveLog, saveSync = ns.actLog, ns.db.sync
		ns.actLog, ns.db.sync = nil, true
		local ok, r = pcall(WithAPI, { IsInGroup = Ret(true), IsInRaid = Ret(false), InCombatLockdown = Ret(false) },
			function() return Sy:Send("T:-:8") end)
		ns.actLog, ns.db.sync = saveLog, saveSync
		UnswapAll()
		if not ok then error(r, 0) end
		local paths = {}
		for _, combo in ipairs({ { true, true, false }, { true, false, true }, { false, false, false } }) do
			Swap(G.api, "inGuild", function() return combo[1] end)
			Swap(G.api, "inRaid", function() return combo[2] end)
			Swap(G.api, "inGroup", function() return combo[3] or combo[2] end)
			local p = {}
			for _, x in ipairs(G.Paths({ scope = "group" })) do p[#p + 1] = x[1] end
			paths[#paths + 1] = #p > 0 and table.concat(p, "+") or "-"
			UnswapAll()
		end
		local got = S(captured) .. " | " .. table.concat(paths, ",")
		local want = "T:-:8 group | RAID,PARTY,-"
		return got == want, got, want
	end)
	C("T-GS2", "U", "Empfang über ep:OnMessage, fehlender Absender wird vertragen", function()
		local before = ns.errorCount or 0
		local st = { G.stats.received, Sy.ep.stats.received }
		ns.syncRoles.Grimbar = nil
		local ok, err = pcall(G.OnAddonMessage, Sy.PREFIX, "#S1:tuzz:1:H:TANK:2.5.13", "PARTY", nil)
		G.stats.received, Sy.ep.stats.received = st[1], st[2]
		if not ok then return false, "Lua: " .. tostring(err), "kein Fehler" end
		local got = string.format("Fehler +%d, übernommen %s", (ns.errorCount or 0) - before, S(ns.syncRoles.Grimbar ~= nil))
		return got == "Fehler +0, übernommen false", got, "Fehler +0, übernommen false (ohne Namen nichts zuordnen)"
	end)
	C("T-GS3", "U", "alte Nachricht ohne Kopf (ThreatSentinel bis 2.5.12) wird verstanden", function()
		local st = { G.stats.received, Sy.ep.stats.received }
		ns.syncRoles.Grimbar = nil
		local ok, err = pcall(G.OnAddonMessage, Sy.PREFIX, "H:TANK:2.5.12", "PARTY", "Grimbar-Realm")
		G.stats.received, Sy.ep.stats.received = st[1], st[2]
		if not ok then return false, "Lua: " .. tostring(err), "kein Fehler" end
		local r = ns.syncRoles.Grimbar
		local got = S(r and r.role) .. " " .. S(r and r.ver)
		return got == "TANK 2.5.12", got, "TANK 2.5.12"
	end)
	C("T-GS4", "U", "kein eigener Kanal: Endpunkt mit bisheriger Kennung, keine Kanal-Wege", function()
		local paths = {}
		for _, sc in ipairs({ "group", "guild", "all" }) do
			for _, x in ipairs(G.Paths({ scope = sc })) do if x[1] == "CHANNEL" then paths[#paths + 1] = sc end end
		end
		local got = string.format("Kennung %s, Endpunkt %s, Kanal-Wege %d", S(Sy.ep and Sy.ep.prefix), S(G.byAddon[ADDON] == Sy.ep), #paths)
		local want = "Kennung ThreatSentinel, Endpunkt true, Kanal-Wege 0"
		return got == want, got, want
	end)
	C("T-GS5", "U", "/ts sync test gibt eine Zeile aus", function()
		local lines = {}
		Swap(ns, "Print", function(_, t) lines[#lines + 1] = tostring(t) end)
		Swap(G, "Ping", function(_, cb) cb({ guild = 1, group = 2, total = 3 }) end)
		local ok, err = pcall(SlashCmdList.THREATSENTINEL, "sync test")
		UnswapAll()
		if not ok then error(err, 0) end
		local last = lines[#lines] or ""
		local want = string.format(L.SYNC_PING_RESULT, 3, 1, 2)
		return last == want, Clean(last), want
	end)
	C("T-N1", "U", "GoldSentinelSync Version 2 nach dem Laden", function()
		return (tonumber(G.VERSION) or 0) >= 2, "Version " .. S(G.VERSION), ">= 2"
	end)
	C("T-N2", "U", "ep:UseStorage: bekannte Mitspieler in ThreatSentinelDB.gsSync (oder bei einem anderen Addon)", function()
		local t = ThreatSentinelDB and ThreatSentinelDB.gsSync
		local got = string.format("gsSync %s, Speicher %s", S(type(t) == "table"), S(G.store ~= nil))
		return got == "gsSync true, Speicher true", got, "gsSync true, Speicher true"
	end)
	C("T-N3", "U", "Rollen und Spotts nie ins Flüster-Netz (scope group)", function()
		local n0 = #G.netQueue
		local a = SendCase(false)
		return #G.netQueue == n0 and a:find("Netz 0", 1, true) ~= nil, a, "Netz 0"
	end)
	C("T-N4", "U", "Diagnose: Zeilen der gemeinsamen Datei mit NETZ, ohne Spielernamen", function()
		local lines = ns.DiagExtra()
		local netz, named = false, false
		for _, l in ipairs(lines) do
			if l:find("^NETZ") then netz = true end
			if ns.playerName and ns.playerName ~= "" and l:find(ns.playerName, 1, true) then named = true end
		end
		return netz and not named, "NETZ " .. S(netz) .. ", Name " .. S(named), "NETZ true, Name false"
	end)
end

------------------------------------------------------------
-- MN4 Marktdaten-Netz (shared/GoldSentinelMarkt.lua): lädt mit/ohne Datei, Schalter aus, ohne AH-API
------------------------------------------------------------
local function MN()
	local GM = rawget(_G, "GoldSentinelMarkt")
	C("T-MN1", "U", "Marktdaten-Netz: Addon läuft mit und ohne die gemeinsame Datei", function()
		local with = type(GM) == "table" and GM.hosts and GM.hosts[ADDON] == ThreatSentinelDB
			and type(ThreatSentinelDB.gsMarkt) == "table"
		_G.GoldSentinelMarkt = nil
		local ok, a, line, extraOk = pcall(function()
			local r = ns:AttachMarket()
			ns:ApplyMarketShare()
			local okE = pcall(ns.DiagExtra)
			return r, ns:MarketLine(), okE
		end)
		_G.GoldSentinelMarkt = GM
		if not ok then return false, "Lua: " .. tostring(a), "kein Fehler" end
		local got = string.format("mit Datei %s · ohne: Anmelden %s, Zeile '%s', Diagnose %s", S(with), S(a), S(line), S(extraOk))
		local want = "mit Datei true · ohne: Anmelden false, Zeile 'MARKT-NETZ: nicht geladen', Diagnose true"
		return got == want, got, want
	end)
	if type(GM) ~= "table" then
		K("T-MN2", "U", "Marktdaten-Netz: Schalter aus -> kein Lesen, kein Annehmen", "GoldSentinelMarkt nicht geladen")
		K("T-MN3", "U", "Marktdaten-Netz: kein Lua-Fehler ohne Auktionshaus-API", "GoldSentinelMarkt nicht geladen")
	else
		C("T-MN2", "U", "Marktdaten-Netz: Schalter aus -> kein Lesen, kein Annehmen (Gegenprobe mit Schalter an)", function()
			local st = GM.Stats()
			-- Test-Item, das es nicht gibt; Eintrag vorher sichern und am Ende wiederherstellen (nie echte Daten verändern)
			local ID = 999991
			local function B36(n)
				n = math.floor(tonumber(n) or 0)
				if n == 0 then return "0" end
				local d, out = "0123456789abcdefghijklmnopqrstuvwxyz", ""
				while n > 0 do local r = n % 36; out = d:sub(r + 1, r + 1) .. out; n = (n - r) / 36 end
				return out
			end
			local fac = GM.api.faction()
			local store = GM.store
			local ftab = store and store.f and store.f[fac]
			local hadF = ftab ~= nil
			local savedItem = ftab and ftab.i and ftab.i[ID]
			local savedTn = ftab and ftab.tn
			local save = { ns.db.marketShare, ThreatSentinelDB.gsMarktAus, GM.lastEv, GM.readAt, GM.reader,
				st.dropped.aus, st.accepted, st.received, GM.outbox, GM.feedUntil, st.dropped.zeit }
			local ok, res = pcall(function()
				GM.outbox = {}
				local msg = "S:" .. fac .. ":" .. B36(GM.api.time()) .. ":" .. B36(ID) .. ",1,1,1"
				-- Gegenprobe: Schalter an -> die Nachricht wird angenommen
				ns.db.marketShare = true
				ns:ApplyMarketShare()
				local acc0 = st.accepted
				if GM.IsShareOn() then GM.OnMessage(msg, "Netz") end
				local onAcc = st.accepted - acc0
				local f2 = store and store.f and store.f[fac]
				if f2 and f2.i then f2.i[ID] = nil end
				-- Schalter aus
				ns.db.marketShare = false
				ns:ApplyMarketShare()
				local on = GM.IsShareOn()
				GM.lastEv, GM.readAt, GM.feedUntil = nil, nil, nil
				GM.OnReplicate()                                   -- ein Vollscan beginnt
				local read = GM.readAt ~= nil or GM.reader ~= nil
				local acc = st.accepted
				GM.OnMessage(msg, "Netz")                          -- fremde Daten kommen an
				local stored = f2 and f2.i and f2.i[ID] ~= nil
				return string.format("an: angenommen %d · aus: teilen %s, liest %s, angenommen %d, gespeichert %s",
					onAcc, S(on), S(read), st.accepted - acc, S(stored))
			end)
			-- echte Daten zurück
			local f3 = store and store.f and store.f[fac]
			if f3 then
				if f3.i then f3.i[ID] = savedItem end
				f3.tn = savedTn
				if not hadF then store.f[fac] = nil end
			end
			ns.db.marketShare, ThreatSentinelDB.gsMarktAus, GM.lastEv, GM.readAt, GM.reader = save[1], save[2], save[3], save[4], save[5]
			st.dropped.aus, st.accepted, st.received, GM.outbox, GM.feedUntil, st.dropped.zeit = save[6], save[7], save[8], save[9], save[10], save[11]
			ns:ApplyMarketShare()
			if not ok then return false, "Lua: " .. tostring(res), "kein Fehler" end
			local want = "an: angenommen 1 · aus: teilen false, liest false, angenommen 0, gespeichert false"
			-- ist das Teilen in einem anderen GoldSentinel-Addon aus, gibt es keine Gegenprobe
			if res:find("^an: angenommen 0") and not GM.IsShareOn() then
				want = "an: angenommen 0 · aus: teilen false, liest false, angenommen 0, gespeichert false"
			end
			return res == want, res, want
		end)
		C("T-MN3", "U", "Marktdaten-Netz: kein Lua-Fehler ohne Auktionshaus-API (alte Clients)", function()
			local st = GM.Stats()
			local save = { GM.lastEv, GM.readAt, GM.reader, GM.askAt, GM.answerAt, GM.outbox, st.aborted }
			Swap(GM.api, "ah", function() return nil end)
			if GM.api.ahs then Swap(GM.api, "ahs", function() return false end) end   -- v2: liest nicht, wenn AHSentinel geladen ist
			local saveFeed = GM.feedUntil
			GM.feedUntil = nil
			local ok, res = pcall(function()
				GM.askAt, GM.answerAt, GM.outbox = nil, nil, {}
				GM.lastEv, GM.readAt = nil, nil
				GM.OnReplicate()
				local wants = GM.IsShareOn() and GM.readAt ~= nil
				if GM.readAt then GM.readAt = 0 end
				GM.Tick()
				return string.format("Lesen vorgemerkt %s, Leser %s", S(wants or not GM.IsShareOn()), S(GM.reader ~= nil))
			end)
			UnswapAll()
			GM.feedUntil = saveFeed
			GM.lastEv, GM.readAt, GM.reader, GM.askAt, GM.answerAt, GM.outbox, st.aborted = save[1], save[2], save[3], save[4], save[5], save[6], save[7]
			if not ok then return false, "Lua: " .. tostring(res), "kein Fehler" end
			local want = "Lesen vorgemerkt true, Leser false"
			return res == want, res, want
		end)
	end
	C("T-MN4", "U", "Marktdaten-Netz: Zeile im Testbericht und in der Diagnose (ohne Namen)", function()
		local line = ns:MarketLine()
		local pat = "^MARKT%-NETZ: v%d+, [a-z]+, mitgelesene Scans %d+, gesendet %d+ / empfangen %d+, Speicher %d+ KB$"
		local inDiag = false
		for _, l in ipairs(ns.DiagExtra()) do if l == line then inDiag = true end end
		local named = ns.playerName and line:find(ns.playerName, 1, true)
		return line:match(pat) ~= nil and inDiag and not named, line .. (inDiag and " · in der Diagnose" or " · fehlt in der Diagnose"),
			"MARKT-NETZ: Version, an/aus, Scans, gesendet/empfangen, Speicher"
	end)
end

------------------------------------------------------------
-- Bereich U
------------------------------------------------------------
Area.U = function()
	TU1()
	TU2()
	TU3()
	TU5()
	TU6Tests()
	BL()
	MN()
	SYNC()
	TU7()
	local tu4 = TU4Continuation()
	-- zuerst die Zufalls-Portionen (je Bild eine), am Ende die Regressionszählung (braucht alle Ergebnisse)
	return function()
		if tu4() then return true end
		TU6Check()
		return false
	end
end
