-- ThreatSentinel - Options.lua
-- Einstellungsfenster (nur ausserhalb des Kampfs) und Minimap-Knopf. Alles per Maus bedienbar.

local ADDON, ns = ...
local API = ns.API   -- Blizzard-Funktionen nur über ns.API (API.lua)
local L = ns.L

local O = {}
ns.Options = O
table.insert(ns.modules, O)

local WHITE = "Interface\\Buttons\\WHITE8X8"
local BACKDROP = BackdropTemplateMixin and "BackdropTemplate" or nil
local ACCENT = { 0.25, 0.65, 1 }
local COL2 = 300

------------------------------------------------------------
-- Farbauswahl
------------------------------------------------------------
-- Übernehmen / Abbrechen für eine Farbe (getrennt, damit die Testroutine sie ohne Farbfenster prüfen kann)
local function ColorCallbacks(c, onChange, getRGB)
	local r, g, b = c[1], c[2], c[3]
	local function apply()
		local nr, ng, nb = getRGB()
		c[1], c[2], c[3] = nr, ng, nb
		onChange()
	end
	local function cancel()
		c[1], c[2], c[3] = r, g, b
		onChange()
	end
	return apply, cancel, r, g, b
end

local function OpenColor(c, onChange)
	local apply, cancel, r, g, b = ColorCallbacks(c, onChange, function() return ColorPickerFrame:GetColorRGB() end)
	if ColorPickerFrame.SetupColorPickerAndShow then
		ColorPickerFrame:SetupColorPickerAndShow({ r = r, g = g, b = b, hasOpacity = false, swatchFunc = apply, cancelFunc = cancel })
	else
		ColorPickerFrame:Hide()
		ColorPickerFrame.hasOpacity = false
		ColorPickerFrame.func = apply
		ColorPickerFrame.cancelFunc = cancel
		ColorPickerFrame.previousValues = { r, g, b }
		ColorPickerFrame:SetColorRGB(r, g, b)
		ColorPickerFrame:Show()
	end
end

O._ColorCallbacks = ColorCallbacks   -- Test-Zugang (Testroutine T91)

------------------------------------------------------------
-- Baukasten für die Bedienelemente
------------------------------------------------------------
local function NewBuilder(panel)
	local b = { panel = panel, x = 16, y = -14 }
	panel.refresh = panel.refresh or {}

	local function label(text, x, y, template, width)
		local fs = panel:CreateFontString(nil, "OVERLAY", template or "GameFontHighlight")
		fs:SetPoint("TOPLEFT", x, y)
		fs:SetJustifyH("LEFT")
		if width then fs:SetWidth(width) end
		fs:SetText(text)
		return fs
	end

	function b:Col(x) self.x = x; self.y = -14 end
	function b:Space(h) self.y = self.y - (h or 8) end

	function b:Header(text)
		local fs = label(text, self.x, self.y, "GameFontNormal")
		fs:SetTextColor(ACCENT[1], ACCENT[2], ACCENT[3])
		self.y = self.y - 22
		return fs
	end

	function b:Text(text, width)
		local fs = label(text, self.x, self.y, "GameFontHighlightSmall", width or 250)
		self.y = self.y - math.max(16, fs:GetStringHeight() + 6)
		return fs
	end

	function b:Check(text, key, onChange, getter, setter)
		local cb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
		cb:SetSize(24, 24)
		cb:SetPoint("TOPLEFT", self.x, self.y + 2)
		if cb.text then cb.text:SetText("") end
		if cb.Text then cb.Text:SetText("") end
		local fs = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
		fs:SetPoint("LEFT", cb, "RIGHT", 4, 0)
		fs:SetWidth(240)
		fs:SetJustifyH("LEFT")
		fs:SetText(text)
		cb:SetScript("OnClick", function(s)
			local v = s:GetChecked() and true or false
			if setter then setter(v) else ns.db[key] = v end
			if onChange then onChange(v) end
			ns:ApplySettings()
		end)
		table.insert(panel.refresh, function()
			if getter then cb:SetChecked(getter()) else cb:SetChecked(ns.db[key]) end
		end)
		self.y = self.y - math.max(26, fs:GetStringHeight() + 12)
		return cb
	end

	-- pct = true: gespeichert wird 0..1, angezeigt 0..100 %
	-- setter (optional): statt ns.db[key] zu schreiben (z. B. Grösse mit fester Mitte)
	function b:Slider(text, key, minv, maxv, step, fmt, pct, setter)
		local fs = label("", self.x, self.y, "GameFontHighlightSmall")
		local s = CreateFrame("Slider", nil, panel, BACKDROP)
		s:SetOrientation("HORIZONTAL")
		s:SetSize(150, 16)
		s:SetPoint("TOPLEFT", self.x + 2, self.y - 16)
		if s.SetBackdrop then
			s:SetBackdrop({
				bgFile = "Interface\\Buttons\\UI-SliderBar-Background",
				edgeFile = "Interface\\Buttons\\UI-SliderBar-Border",
				tile = true, tileSize = 8, edgeSize = 8,
				insets = { left = 3, right = 3, top = 6, bottom = 6 },
			})
		end
		s:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
		s:SetMinMaxValues(minv, maxv)
		s:SetValueStep(step)
		if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
		-- -/+ und Eingabefeld für exakte Werte
		local function setv(v)
			v = math.max(minv, math.min(maxv, v))
			s:SetValue(v)
		end
		local minus = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
		minus:SetSize(20, 18)
		minus:SetPoint("LEFT", s, "RIGHT", 4, 0)
		minus:SetText("-")
		minus:SetScript("OnClick", function() setv(s:GetValue() - step) end)
		local plus = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
		plus:SetSize(20, 18)
		plus:SetPoint("LEFT", minus, "RIGHT", 2, 0)
		plus:SetText("+")
		plus:SetScript("OnClick", function() setv(s:GetValue() + step) end)
		local eb = CreateFrame("EditBox", nil, panel, "InputBoxTemplate")
		eb:SetSize(40, 18)
		eb:SetPoint("LEFT", plus, "RIGHT", 8, 0)
		eb:SetAutoFocus(false)
		eb:SetJustifyH("CENTER")
		local function commit(e)
			local n = tonumber((e:GetText() or ""):gsub(",", "."):match("^%s*(%-?[%d%.]+)"))
			if n then setv(n) end
			e:ClearFocus()
		end
		eb:SetScript("OnEditFocusGained", function(e) e:HighlightText() end)
		eb:SetScript("OnEnterPressed", commit)
		eb:SetScript("OnEscapePressed", function(e) e:ClearFocus() end)
		eb:SetScript("OnEditFocusLost", function(e) e:SetText(string.format(fmt:gsub(" ?%%%%", ""), s:GetValue())) end)

		-- TU3 (Standardwerte): Bereich, Schritt und Eingabe für die Testroutine merken
		O.sliderSpec = O.sliderSpec or {}
		if key then O.sliderSpec[key] = { min = minv, max = maxv, step = step, pct = pct, commit = commit, slider = s } end

		local function show(v)
			fs:SetText(text .. ": " .. string.format(fmt, v))
			if not eb:HasFocus() then eb:SetText(string.format(fmt:gsub(" ?%%%%", ""), v)) end
		end
		s:SetScript("OnValueChanged", function(_, v)
			v = math.floor(v / step + 0.5) * step
			if setter then setter(pct and (v / 100) or v) else ns.db[key] = pct and (v / 100) or v end
			show(v)
			ns:ApplySettings()
		end)
		table.insert(panel.refresh, function()
			local v = ns.db[key]
			if pct then v = v * 100 end
			s:SetValue(v)
			show(v)
		end)
		self.y = self.y - 46
		return s
	end

	function b:Cycle(text, key, values, labelOf, testFn)
		label(text, self.x, self.y, "GameFontHighlightSmall")
		local btn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
		btn:SetSize(170, 22)
		btn:SetPoint("TOPLEFT", self.x, self.y - 15)
		btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
		local function index()
			for i, v in ipairs(values) do if v == ns.db[key] then return i end end
			return 1
		end
		local function update() btn:SetText(labelOf(values[index()])) end
		btn:SetScript("OnClick", function(_, mb)
			local i = index() + ((mb == "RightButton") and -1 or 1)
			if i < 1 then i = #values elseif i > #values then i = 1 end
			ns.db[key] = values[i]
			update()
			ns:ApplySettings()
		end)
		if testFn then
			local t = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
			t:SetSize(54, 22)
			t:SetPoint("LEFT", btn, "RIGHT", 4, 0)
			t:SetText(L.O_PLAY)
			t:SetScript("OnClick", function() testFn(ns.db[key]) end)
		end
		table.insert(panel.refresh, update)
		self.y = self.y - 46
		return btn
	end

	-- Ton wählen: Knopf öffnet die Auswahl (alle Töne, Geräusche, WoW-Töne, eigener Ton)
	function b:Sound(text, key)
		label(text, self.x, self.y, "GameFontHighlightSmall")
		local btn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
		btn:SetSize(190, 22)
		btn:SetPoint("TOPLEFT", self.x, self.y - 15)
		local function update()
			btn:SetText(ns:SoundLabel(ns.db[key]))
			local fs = btn:GetFontString()
			if fs then fs:SetWidth(176); if fs.SetWordWrap then fs:SetWordWrap(false) end end
		end
		btn:SetScript("OnClick", function() O:OpenSoundPicker(text, key, update) end)
		local t = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
		t:SetSize(54, 22)
		t:SetPoint("LEFT", btn, "RIGHT", 4, 0)
		t:SetText(L.O_PLAY)
		t:SetScript("OnClick", function() ns.Alerts:Play(ns.db[key], "test" .. GetTime(), true) end)
		table.insert(panel.refresh, update)
		self.y = self.y - 46
		return btn
	end

	function b:Color(text, key)
		local sw = CreateFrame("Button", nil, panel, BACKDROP)
		sw:SetSize(18, 18)
		sw:SetPoint("TOPLEFT", self.x + 3, self.y)
		if sw.SetBackdrop then
			sw:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
			sw:SetBackdropBorderColor(1, 1, 1, 0.8)
		end
		local fs = sw:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
		fs:SetPoint("LEFT", sw, "RIGHT", 8, 0)
		fs:SetText(text)
		local function update()
			local c = ns.db[key]
			if sw.SetBackdropColor then sw:SetBackdropColor(c[1], c[2], c[3], 1) end
		end
		sw:SetScript("OnClick", function()
			OpenColor(ns.db[key], function() update(); ns:ApplySettings() end)
		end)
		table.insert(panel.refresh, update)
		self.y = self.y - 26
		return sw
	end

	function b:Edit(text, key, onCommit)
		label(text, self.x, self.y, "GameFontHighlightSmall")
		local e = CreateFrame("EditBox", nil, panel, "InputBoxTemplate")
		e:SetSize(200, 20)
		e:SetPoint("TOPLEFT", self.x + 6, self.y - 16)
		e:SetAutoFocus(false)
		local function commit(s)
			local v = strtrim(s:GetText() or "")
			if ns.db[key] ~= v then
				ns.db[key] = v
				if onCommit then onCommit(v) end
			end
		end
		O.editSpec = O.editSpec or {}
		if key then O.editSpec[key] = { commit = commit } end
		e:SetScript("OnEnterPressed", function(s) commit(s); s:ClearFocus() end)
		e:SetScript("OnEscapePressed", function(s) s:SetText(ns.db[key] or ""); s:ClearFocus() end)
		e:SetScript("OnEditFocusLost", commit)
		table.insert(panel.refresh, function() e:SetText(ns.db[key] or "") end)
		self.y = self.y - 46
		return e
	end

	function b:Button(text, width, onClick)
		local btn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
		btn:SetSize(width or 170, 24)
		btn:SetPoint("TOPLEFT", self.x, self.y)
		btn:SetText(text)
		btn:SetScript("OnClick", onClick)
		self.y = self.y - 32
		return btn
	end

	-- mehrere kleine Knöpfe nebeneinander
	function b:ButtonRow(text, items)
		label(text, self.x, self.y, "GameFontHighlightSmall")
		local x = self.x
		for _, it in ipairs(items) do
			local btn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
			btn:SetSize(it.w or 80, 22)
			btn:SetPoint("TOPLEFT", x, self.y - 15)
			btn:SetText(it.text)
			btn:SetScript("OnClick", function()
				it.fn()
				O:RefreshAll()
			end)
			x = x + (it.w or 80) + 4
		end
		self.y = self.y - 46
	end

	function b:KeyBind(text, which)
		label(text, self.x, self.y, "GameFontHighlightSmall")
		local btn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
		btn:SetSize(250, 24)
		btn:SetPoint("TOPLEFT", self.x, self.y - 15)
		btn:RegisterForClicks("AnyUp")
		btn:EnableKeyboard(false)
		local function update()
			local k = ns.Taunt:GetKey(which)
			if k then
				btn:SetText((GetBindingText and GetBindingText(k)) or k)
			else
				btn:SetText(L.O_KEY_NONE)
			end
		end
		function btn:Done()
			self.waiting = false
			self:EnableKeyboard(false)
			update()
		end
		function btn:Bind(key)
			local mods = (IsAltKeyDown() and "ALT-" or "") .. (IsControlKeyDown() and "CTRL-" or "") .. (IsShiftKeyDown() and "SHIFT-" or "")
			local full = mods .. key
			local current = GetBindingAction and GetBindingAction(full) or ""
			self:Done()
			if current ~= "" and current ~= ns.Taunt.BIND[which] then
				-- schon belegt: erst nachfragen
				local name = _G["BINDING_NAME_" .. current] or current
				local text = (GetBindingText and GetBindingText(full)) or full
				local dlg = StaticPopup_Show("THREATSENTINEL_REBIND", text, name)
				if dlg then dlg.data = { which = which, key = full, refresh = update } end
				return
			end
			ns.Taunt:SetKey(which, full)
			update()
		end
		local MOUSE = { MiddleButton = "BUTTON3", Button4 = "BUTTON4", Button5 = "BUTTON5" }
		btn:SetScript("OnClick", function(s, mb)
			if API.InCombatLockdown() then return end
			if s.waiting then
				if MOUSE[mb] then s:Bind(MOUSE[mb]) else s:Done() end
				return
			end
			s.waiting = true
			s:SetText(L.O_KEY_PRESS)
			s:EnableKeyboard(true)
		end)
		btn:SetScript("OnKeyDown", function(s, key)
			if not s.waiting then return end
			if key == "LSHIFT" or key == "RSHIFT" or key == "LCTRL" or key == "RCTRL" or key == "LALT" or key == "RALT" then return end
			if key == "ESCAPE" then s:Done() return end
			if key == "DELETE" or key == "BACKSPACE" then ns.Taunt:SetKey(which, nil); s:Done() return end
			s:Bind(key)
		end)
		btn:SetScript("OnHide", function(s) if s.waiting then s:Done() end end)
		table.insert(panel.refresh, update)
		self.y = self.y - 50
		return btn
	end

	return b
end

------------------------------------------------------------
-- Seiten
------------------------------------------------------------
------------------------------------------------------------
-- Ton-Auswahl
------------------------------------------------------------
local PICK_COL_W, PICK_ROW_H = 180, 18

function O:OpenSoundPicker(title, key, onChange)
	local p = self.picker
	if not p then
		p = CreateFrame("Frame", "ThreatSentinelSoundPicker", self.frame or UIParent, BACKDROP)
		if ns.RegisterUI then ns.RegisterUI(p, "Tonauswahl") end   -- Oberflächen-Prüfung (UICheck.lua)
		p:SetFrameStrata("FULLSCREEN_DIALOG")
		p:SetClampedToScreen(true)
		p:EnableMouse(true)
		p:SetMovable(true)
		p:RegisterForDrag("LeftButton")
		p:SetScript("OnDragStart", p.StartMoving)
		p:SetScript("OnDragStop", p.StopMovingOrSizing)
		if p.SetBackdrop then
			p:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
			p:SetBackdropColor(0.05, 0.06, 0.08, 0.98)
			p:SetBackdropBorderColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.9)
		end
		tinsert(UISpecialFrames, "ThreatSentinelSoundPicker")
		p.title = p:CreateFontString(nil, "OVERLAY", "GameFontNormal")
		p.title:SetPoint("TOPLEFT", 12, -10)
		p.title:SetTextColor(ACCENT[1], ACCENT[2], ACCENT[3])
		p.help = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
		p.help:SetPoint("TOPLEFT", 12, -28)
		p.help:SetText(L.SP_HELP)
		local close = CreateFrame("Button", nil, p, "UIPanelCloseButton")
		close:SetPoint("TOPRIGHT", -2, -2)
		p.rows = {}

		local function row(col, y, text)
			local r = CreateFrame("Button", nil, p)
			r:SetSize(PICK_COL_W - 6, PICK_ROW_H)
			r:SetPoint("TOPLEFT", 10 + (col - 1) * PICK_COL_W, y)
			r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
			local hl = r:CreateTexture(nil, "HIGHLIGHT")
			hl:SetAllPoints()
			hl:SetTexture(WHITE)
			hl:SetVertexColor(1, 1, 1, 0.08)
			r.sel = r:CreateTexture(nil, "BACKGROUND")
			r.sel:SetAllPoints()
			r.sel:SetTexture(WHITE)
			r.sel:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.3)
			r.sel:Hide()
			r.text = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
			r.text:SetPoint("LEFT", 4, 0)
			r.text:SetPoint("RIGHT", -2, 0)
			r.text:SetJustifyH("LEFT")
			if r.text.SetWordWrap then r.text:SetWordWrap(false) end
			r.text:SetText(text)
			return r
		end

		local maxY = 0
		for col, g in ipairs(ns.SOUND_GROUPS) do
			local hdr = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
			hdr:SetPoint("TOPLEFT", 14 + (col - 1) * PICK_COL_W, -50)
			hdr:SetText(L["SG_" .. g])
			local y = -68
			for _, snd in ipairs(ns.SOUNDS) do
				if snd.group == g and ns:SoundAvailable(snd) then
					local r = row(col, y, L["SND_" .. snd.key] or snd.key)
					r.value = snd.key
					r:SetScript("OnClick", function(_, mb)
						if mb ~= "RightButton" then
							ns.db[p.key] = snd.key
							if p.onChange then p.onChange() end
							O:RefreshPicker()
						end
						ns.Alerts:Play(snd.key, "pick" .. GetTime(), true)
					end)
					p.rows[#p.rows + 1] = r
					y = y - PICK_ROW_H
				end
			end
			if g == "ts" then
				-- eigener Ton (WoW-Sound-ID oder Datei)
				y = y - 8
				local r = row(col, y, L.SND_CUSTOM)
				r.custom = true
				r:SetScript("OnClick", function(_, mb)
					local cur = ns.db[p.key]
					if mb == "RightButton" then
						if type(cur) == "string" and cur:sub(1, #ns.CUSTOM_PREFIX) == ns.CUSTOM_PREFIX then
							ns.Alerts:Play(cur, "pick" .. GetTime(), true)
						end
						return
					end
					-- Auswahl kurz ausblenden, damit sie das Eingabefeld nicht verdeckt;
					-- data als 4. Wert: steht schon in OnShow zur Verfügung
					p:Hide()
					StaticPopup_Show("THREATSENTINEL_CUSTOMSOUND", nil, nil, { key = p.key, reopen = true })
				end)
				p.rows[#p.rows + 1] = r
				p.customRow = r
				y = y - PICK_ROW_H
				p.customHelp = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
				p.customHelp:SetPoint("TOPLEFT", 14 + (col - 1) * PICK_COL_W, y - 4)
				p.customHelp:SetWidth(PICK_COL_W - 10)
				p.customHelp:SetJustifyH("LEFT")
				p.customHelp:SetText(L.SP_CUSTOM_HELP)
				y = y - 4 - p.customHelp:GetStringHeight()
			end
			maxY = math.min(maxY, y)
		end
		p:SetSize(20 + #ns.SOUND_GROUPS * PICK_COL_W, -maxY + 16)
		self.picker = p
	end
	p.key, p.onChange = key, onChange
	p.title:SetText(string.format(L.SP_TITLE, title))
	p:ClearAllPoints()
	p:SetPoint("CENTER", self.frame or UIParent, "CENTER", 0, 0)
	self:RefreshPicker()
	p:Show()
end

function O:RefreshPicker()
	local p = self.picker
	if not p or not p.key then return end
	local cur = ns.db[p.key]
	local isCustom = type(cur) == "string" and cur:sub(1, #ns.CUSTOM_PREFIX) == ns.CUSTOM_PREFIX
	for _, r in ipairs(p.rows) do
		local sel = (r.custom and isCustom) or (r.value ~= nil and r.value == cur)
		r.sel:SetShown(sel)
		if r.custom then
			r.text:SetText(isCustom and ns:SoundLabel(cur) or L.SND_CUSTOM)
		end
	end
end

local PAGES = {}

PAGES[1] = { title = "TAB_GENERAL", build = function(b, panel)
	b:Header(L.H_BEHAVIOR)
	b:Check(L.O_ENABLED, "enabled")
	b:Check(L.O_ONLYTANK, "activeOnlyTank")
	b:Check(L.O_SOLO, "activeSolo")
	b:Check(L.O_AUTONP, "autoEnableNameplates", function(v)
		if v and not API.InCombatLockdown() then ns:SetCVarSafe("nameplateShowEnemies", "1") end
	end)
	b:Check(L.O_SHARED, nil, nil,
		function() return ns:IsSharedProfile() end,
		function(v)
			local dlg = StaticPopup_Show("THREATSENTINEL_RELOAD")
			if dlg then dlg.data = v end
		end)
	b:Space(6)
	if ns:IsDev() then
		O.testButton = b:Button(L.O_TEST_CENTER, 190, function() O.frame:Hide(); ns.Test:ToggleWindow() end)
	end
	b:Button(L.O_DONATE, 190, function() ns.Donate.Show() end)
	-- Bedrohungsmodus (WoW Forever): Automatisch oder immer nur Anzeige. "Voll" lässt sich nicht erzwingen.
	if ns.isModern then
		b:Cycle(L.O_THREATMODE, "threatMode", { "AUTO", "DISPLAY" }, function(v)
			return v == "DISPLAY" and L.O_THREATMODE_DISPLAY or L.O_THREATMODE_AUTO
		end)
		b:Check(L.O_BLIZZTHREAT, "blizzThreat")
		b:Text(L.O_BLIZZTHREAT_NOTE, 250)
	end
	b:Button(L.O_THREATCHECK, 190, function() ns.ThreatAccess:Report() end)
	b:Check(L.O_DIAG, "diagSend")
	b:Check(L.O_MARKET, "marketShare")
	b:Check(L.O_CMDHINT, "cmdHint", function(v) if not v and ns.CmdHint then ns.CmdHint:Hide() end end)
	b:Button(L.O_DIAG_SHOW, 190, function() if ns.ShowDiag then ns.ShowDiag() end end)
	b:ButtonRow(L.H_PRESET, {
		{ text = L.PRESET_quiet, w = 78, fn = function() ns:ApplyPreset("quiet") end },
		{ text = L.PRESET_standard, w = 78, fn = function() ns:ApplyPreset("standard") end },
		{ text = L.PRESET_loud, w = 78, fn = function() ns:ApplyPreset("loud") end },
	})

	b:Col(COL2)
	b:Header(L.H_SPELLS)
	b:Cycle(L.O_MYROLE, "myRole", { "AUTO", "HEALER", "DAMAGER" }, function(v)
		if v == "AUTO" then return L.ROLE_AUTO end
		return L[v]
	end)
	b:Edit(L.O_TAUNTNAME, "tauntOverride", function() ns:UpdateSpells(); O:RefreshDetected() end)
	O.detectedText = b:Text("", 250)
	-- Ini-Prüfung: nur für den Entwickler
	if ns:IsDev() then
		b:Space(4)
		b:Header(L.H_DUNGEON)
		b:Check(L.O_DUNGEON, "dungeonCheck")
		b:Check(L.O_DUNGEON_RAID, "dungeonCheckRaid")
		b:Check(L.O_DUNGEON_SHOTS, "dungeonShots")
		b:Button(L.O_DUNGEON_LAST, 200, function() O.frame:Hide(); ns.Log:ShowSummary() end)
	end
end }

PAGES[2] = { title = "TAB_PLATES", build = function(b)
	b:Header(L.H_HELD)
	b:Slider(L.O_HELDALPHA, "heldPlateAlpha", 0, 100, 5, "%d %%", true)
	b:Slider(L.O_HELDHEALTH, "heldHealthAlpha", 0, 100, 5, "%d %%", true)
	b:Slider(L.O_HELDSCALE, "heldScale", 50, 100, 5, "%d %%", true)
	b:Cycle(L.O_OOC, "outOfCombatMode", { "normal", "faded" }, function(v)
		return v == "faded" and L.OOC_FADED or L.OOC_NORMAL
	end)
	b:Slider(L.O_WARN, "warnThreshold", 50, 100, 5, "%d %%")
	b:Check(L.O_WARNBLINK, "warnBlink")
	b:Header(L.H_LOOSE)
	b:Check(L.O_PULSE, "loosePulse")
	b:Check(L.O_FIRE, "looseFire")
	b:Slider(L.O_SCALE, "looseScale", 100, 150, 5, "%d %%", true)
	b:Slider(L.O_BORDER, "borderSize", 1, 6, 1, "%d")

	b:Col(COL2)
	b:Header(L.H_COLORS)
	b:Color(L.C_DD, "colorDD")
	b:Color(L.C_HEALER, "colorHealer")
	b:Color(L.C_WARN, "colorWarn")
	b:Color(L.C_REGAIN, "colorRegain")
	b:Color(L.C_CLAIMED, "colorClaimed")
	b:Header(L.H_EXTRA)
	b:Check(L.O_HINTS, "showHints")
	b:Slider(string.format(L.O_DEFICIT, ns:DeficitText()), "deficitThreshold", 50, 100, 5, "%d %%")
	if ns.class == "WARRIOR" then b:Check(L.O_SUNDER, "showSunder") end
	b:Check(L.O_STRIPE, "showTankStripe")
	b:Check(L.O_IGNORECC, "ignoreCC")
	b:Check(L.O_PETS, "petsSafe")
	b:Header(L.H_EFFECTS)
	b:Check(L.O_GLOW, "effectGlow")
	b:Slider(L.O_STRENGTH, "effectStrength", 50, 200, 10, "%d %%")
end }

PAGES[3] = { title = "TAB_SOUNDS", build = function(b)
	b:Header(L.TAB_SOUNDS)
	b:Check(L.O_SOUND, "sound")
	b:Sound(L.S_DD, "soundDD")
	b:Sound(L.S_HEALER, "soundHealer")
	b:Sound(L.S_WARN, "soundWarn")
	b:Sound(L.S_RESIST, "soundResist")
	b:Text(L.O_SOUND_HELP, 250)

	b:Col(COL2)
	b:Header(" ")
	b:Check(L.O_REGAINSOUND, "regainSound")
	b:Sound(L.S_REGAIN, "soundRegain")
	b:Sound(L.S_EMERG, "soundEmergency")
	b:Sound(L.S_DDWARN, "soundDDWarn")
	b:Cycle(L.O_CHANNEL_SOUND, "soundChannel", { "Master", "SFX", "Ambience", "Dialog" }, function(v) return v end)
end }

PAGES[4] = { title = "TAB_ALERTS", build = function(b)
	b:Header(L.H_CHAT)
	b:Cycle(L.O_CHAT, "chatChannel", { "TANKS", "BOSS", "GROUP", "SELF", "OFF" }, function(v) return L["CH_" .. v] end)
	b:Check(L.O_RESIST, "announceResist")
	b:Check(L.O_CC, "announceCC")
	b:Slider(L.O_CCMIN, "ccMinDuration", 0, 5, 0.5, "%.1f")
	b:Header(L.H_CENTER)
	b:Slider(L.O_CENTERSIZE, "centerSize", 12, 32, 1, "%d")
	b:Slider(L.O_CENTERY, "centerY", -200, 400, 10, "%d")
	b:Button(L.O_CENTERTEST, 170, function()
		ns.Alerts:Center(L.O_CENTERTEST, { 1, 0.6, 0.2 }, 2, "test")
	end)
	b:Check(L.O_REGAINTEXT, "regainText")

	b:Col(COL2)
	b:Header(L.H_HELPERS)
	b:Check(L.O_AOE, "aoeHint")
	b:Slider(L.O_AOETHR, "aoeThreshold", 2, 8, 1, "%d")
	b:Check(L.O_HEALERRANGE, "healerRange")
	b:Check(L.O_EMERG, "emergency")
	b:Slider(L.O_EMERGHP, "emergencyHP", 10, 60, 5, "%d %%")
	b:Check(L.O_HEURISTIC, "healerHeuristic")
end }

PAGES[5] = { title = "TAB_KEYS", build = function(b)
	b:Header(L.TAB_KEYS)
	b:KeyBind(L.O_KEY_TAUNT, "taunt")
	b:KeyBind(L.O_KEY_AOE, "aoe")
	b:Text(L.O_KEY_HELP, 520)
end }

PAGES[6] = { title = "TAB_SYNC", build = function(b)
	b:Header(L.TAB_SYNC)
	b:Check(L.O_SYNC, "sync")
	b:Slider(L.O_GRACE, "ownerGrace", 0, 6, 0.5, "%.1f")
	b:Text(L.O_SYNC_HELP, 520)

	b:Col(COL2)
	b:Header(L.O_SYNCUSERS)
	O.syncText = b:Text("", 250)
	b.y = b.y - 120
	b:Button(L.O_SYNC_REFRESH, 140, function() ns.Sync:Hello(true); O:RefreshSync() end)
end }

local function ScaleSetter(which) return function(v) ns.Mover:SetScale(which, v) end end

PAGES[7] = { title = "TAB_DISPLAY", build = function(b)
	b:Header(L.H_HUD)
	b:Check(L.O_HUD, "hud")
	b:Slider(L.O_HUDSCALE, "hudScale", 50, 250, 5, "%d %%", true, ScaleSetter("hud"))
	b:Slider(L.O_HUDROWS, "hudMaxRows", 1, 10, 1, "%d")
	b:Header(L.H_METER)
	b:Check(L.O_METER, "meter")
	b:Check(L.O_METER_ONLYTANK, "meterOnlyTank")
	b:Slider(L.O_METER_ROWS, "meterRows", 3, 12, 1, "%d")
	b:Slider(L.O_METERSCALE, "meterScale", 50, 250, 5, "%d %%", true, ScaleSetter("meter"))
	b:Slider(L.O_METERWIDTH, "meterWidth", 160, 400, 10, "%d")

	b:Col(COL2)
	b:Header(L.H_DD)
	b:Check(L.O_DD, "ddView")
	b:Slider(L.O_DDSCALE, "ddScale", 50, 250, 5, "%d %%", true, ScaleSetter("dd"))
	b:Slider(L.O_DDWIDTH, "ddWidth", 120, 400, 10, "%d")
	b:Slider(L.O_DDWARN, "ddWarn", 50, 100, 5, "%d %%")
	b:Check(L.O_DDSOUND, "ddSound")
	b:Header(L.H_MOVE)
	b:Button(L.O_MOVE, 220, function() ns.Mover:Start() end)
	b:Button(L.O_RESETPOS, 220, function() ns:ResetPositions() end)
	b:Text(L.O_METER_HELP, 250)
	b:Check(L.O_MINIMAP, "minimapShow")
end }

PAGES[8] = { title = "TAB_GROUP", build = function(b)
	b:Header(L.H_GROUP)
	b:Check(L.O_MEMBERVIEW, "memberView")
	b:Check(L.O_MEMBERWARN, "memberSelfWarn")
	b:Text(L.O_GROUP_HELP, 250)
	b:Header(L.H_ROLES)
	b:Check(L.O_SPECCHECK, "specCheck", function() ns:ClearRoleCache(); O:RefreshRoles() end)
	O.roleText = b:Text("", 260)

	b:Col(COL2)
	b:Header(L.H_DMG)
	b:Check(L.O_DMG, "dmgMeter")
	b:Check(L.O_DMG_GROUPONLY, "dmgMeterGroupOnly")
	b:Check(L.O_DMG_TANK, "dmgMeterTank")
	b:Slider(L.O_DMG_ROWS, "dmgRows", 3, 12, 1, "%d")
	b:Slider(L.O_DMG_SCALE, "dmgScale", 50, 250, 5, "%d %%", true, ScaleSetter("dmg"))
	b:Slider(L.O_DMG_WIDTH, "dmgWidth", 160, 400, 10, "%d")
	b:Text(ns.DmgMeter.allowed and L.O_DMG_HELP or L.O_DMG_NOLOG, 250)
end }

------------------------------------------------------------
-- Hauptfenster
------------------------------------------------------------
function O:Build()
	local f = CreateFrame("Frame", "ThreatSentinelOptions", UIParent, BACKDROP)
	if ns.RegisterUI then ns.RegisterUI(f, "Einstellungen") end   -- Oberflächen-Prüfung (UICheck.lua)
	f:SetSize(780, 540)
	f:SetPoint("CENTER")
	f:SetFrameStrata("DIALOG")
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:EnableMouse(true)
	if f.SetBackdrop then
		f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
		f:SetBackdropColor(0.05, 0.06, 0.08, 0.97)
		f:SetBackdropBorderColor(ACCENT[1], ACCENT[2], ACCENT[3], 0.7)
	end
	f:Hide()
	tinsert(UISpecialFrames, "ThreatSentinelOptions")

	-- Titelleiste
	local title = CreateFrame("Frame", nil, f, BACKDROP)
	title:SetPoint("TOPLEFT", 1, -1)
	title:SetPoint("TOPRIGHT", -1, -1)
	title:SetHeight(34)
	if title.SetBackdrop then
		title:SetBackdrop({ bgFile = WHITE })
		title:SetBackdropColor(0.09, 0.11, 0.15, 1)
	end
	title:EnableMouse(true)
	title:RegisterForDrag("LeftButton")
	title:SetScript("OnDragStart", function() f:StartMoving() end)
	title:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)
	local icon = title:CreateTexture(nil, "ARTWORK")
	icon:SetSize(22, 22)
	icon:SetPoint("LEFT", 10, 0)
	icon:SetTexture("Interface\\Icons\\Ability_Warrior_DefensiveStance")
	local tt = title:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	tt:SetPoint("LEFT", icon, "RIGHT", 8, 0)
	tt:SetText("|cff3fa7ffThreat|rSentinel  |cff808080v" .. ns.version .. "|r")
	local close = CreateFrame("Button", nil, title, "UIPanelCloseButton")
	close:SetPoint("RIGHT", -2, 0)
	close:SetScript("OnClick", function() f:Hide() end)
	local donate = ns.Donate.CreateButton(title, 96, 22)
	donate:SetPoint("RIGHT", close, "LEFT", -6, 0)

	-- Navigation links
	local nav = CreateFrame("Frame", nil, f, BACKDROP)
	nav:SetPoint("TOPLEFT", 1, -35)
	nav:SetPoint("BOTTOMLEFT", 1, 1)
	nav:SetWidth(180)
	if nav.SetBackdrop then
		nav:SetBackdrop({ bgFile = WHITE })
		nav:SetBackdropColor(0.07, 0.08, 0.11, 1)
	end

	-- Inhalt
	local content = CreateFrame("Frame", nil, f)
	content:SetPoint("TOPLEFT", nav, "TOPRIGHT", 8, -6)
	content:SetPoint("BOTTOMRIGHT", -8, 8)

	self.frame, self.panels, self.tabs = f, {}, {}

	for i, page in ipairs(PAGES) do
		local panel = CreateFrame("Frame", nil, content)
		panel:SetAllPoints()
		panel:Hide()
		panel.refresh = {}
		page.build(NewBuilder(panel), panel)
		self.panels[i] = panel

		local tab = CreateFrame("Button", nil, nav)
		tab:SetSize(178, 32)
		tab:SetPoint("TOPLEFT", 1, -8 - (i - 1) * 34)
		tab.bg = tab:CreateTexture(nil, "BACKGROUND")
		tab.bg:SetAllPoints()
		tab.bg:SetTexture(WHITE)
		tab.bg:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3], 0)
		tab.bar = tab:CreateTexture(nil, "ARTWORK")
		tab.bar:SetTexture(WHITE)
		tab.bar:SetPoint("TOPLEFT")
		tab.bar:SetPoint("BOTTOMLEFT")
		tab.bar:SetWidth(3)
		tab.bar:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3], 1)
		tab.bar:Hide()
		local hl = tab:CreateTexture(nil, "HIGHLIGHT")
		hl:SetAllPoints()
		hl:SetTexture(WHITE)
		hl:SetVertexColor(1, 1, 1, 0.06)
		tab.text = tab:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
		tab.text:SetPoint("LEFT", 16, 0)
		tab.text:SetText(L[page.title])
		tab:SetScript("OnClick", function() O:Select(i) end)
		self.tabs[i] = tab
	end

	f:SetScript("OnShow", function() O:RefreshAll() end)
	self:Select(1)
end

function O:Select(i)
	for k, panel in ipairs(self.panels) do
		local sel = (k == i)
		panel:SetShown(sel)
		local tab = self.tabs[k]
		tab.bg:SetVertexColor(ACCENT[1], ACCENT[2], ACCENT[3], sel and 0.18 or 0)
		tab.bar:SetShown(sel)
		if sel then tab.text:SetTextColor(1, 1, 1) else tab.text:SetTextColor(0.75, 0.75, 0.78) end
	end
	self.current = i
	self:RefreshAll()
end

function O:RefreshAll()
	if not self.panels then return end
	for _, panel in ipairs(self.panels) do
		for _, fn in ipairs(panel.refresh) do fn() end
	end
	self:RefreshDetected()
	self:RefreshSync()
	self:RefreshRoles()
	self:RefreshTestButton()
end

function O:RefreshDetected()
	if not self.detectedText then return end
	self.detectedText:SetText(string.format(L.O_DETECTED, ns.tauntSpell or L.NONE, ns.aoeSpell or L.NONE))
end

function O:RefreshSync()
	if not self.syncText then return end
	local lines = {}
	for _, u in ipairs(ns.Sync:Users()) do
		lines[#lines + 1] = string.format("%s - %s %s", u.name, L[u.role] or u.role, (u.ver and u.ver ~= "") and ("(v" .. u.ver .. ")") or "")
	end
	self.syncText:SetText(#lines > 0 and table.concat(lines, "\n") or L.NONE)
end

-- Erkannte Rollen in Gruppe / Schlachtzug (Einstellungen > Gruppe)
function O:RefreshRoles()
	if not self.roleText or not ns.Specs then return end
	ns:ClearRoleCache()
	self.roleText:SetText(ns.Specs:ListText(10))
end

function O:RefreshTestButton()
	if self.testButton then
		self.testButton:SetText(L.O_TEST_CENTER)
	end
end

-- Fenster öffnen und eine Seite wählen (z. B. 5 = Tasten)
function O:OpenPage(i)
	if API.InCombatLockdown() then ns:Print(L.NOT_IN_COMBAT) return end
	if not self.frame then self:Build() end
	self.frame:Show()
	self:Select(i)
end

function O:Toggle()
	if not self.frame then self:Build() end
	if self.frame:IsShown() then
		self.frame:Hide()
	elseif API.InCombatLockdown() then
		ns:Print(L.NOT_IN_COMBAT)
	else
		self.frame:Show()
		-- nicht über offene Blizzard-Fenster (Charakterfenster, Händler …) öffnen
		if ns.UIAvoidBlizzard then ns.UIAvoidBlizzard(self.frame) end
	end
end

------------------------------------------------------------
-- Minimap-Knopf
------------------------------------------------------------
function O:CreateMinimap()
	local b = CreateFrame("Button", "ThreatSentinelMinimapButton", Minimap)
	if ns.RegisterUI then ns.RegisterUI(b, "Minimap-Knopf", "hud") end   -- Oberflächen-Prüfung (UICheck.lua)
	b:SetSize(31, 31)
	b:SetFrameStrata("MEDIUM")
	b:SetFrameLevel(8)
	b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
	local bg = b:CreateTexture(nil, "BACKGROUND")
	bg:SetSize(20, 20)
	bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
	bg:SetPoint("TOPLEFT", 7, -5)
	local icon = b:CreateTexture(nil, "ARTWORK")
	icon:SetSize(17, 17)
	icon:SetTexture("Interface\\Icons\\Ability_Warrior_DefensiveStance")
	icon:SetPoint("TOPLEFT", 7, -6)
	local border = b:CreateTexture(nil, "OVERLAY")
	border:SetSize(53, 53)
	border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
	border:SetPoint("TOPLEFT")

	b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	b:RegisterForDrag("LeftButton")
	b:SetScript("OnClick", function(_, mb)
		if mb == "RightButton" and ns:IsDev() then ns.Test:ToggleWindow() else O:Toggle() end
	end)
	b:SetScript("OnDragStart", function(s)
		s:SetScript("OnUpdate", function()
			local mx, my = Minimap:GetCenter()
			local cx, cy = GetCursorPosition()
			local sc = Minimap:GetEffectiveScale()
			ns.db.minimapAngle = math.deg(math.atan2(cy / sc - my, cx / sc - mx))
			O:PlaceMinimap()
		end)
	end)
	b:SetScript("OnDragStop", function(s) s:SetScript("OnUpdate", nil) end)
	b:SetScript("OnEnter", function(s)
		GameTooltip:SetOwner(s, "ANCHOR_LEFT")
		GameTooltip:AddLine("|cff3fa7ffThreat|rSentinel")
		GameTooltip:AddLine(L.MM_TIP1, 1, 1, 1)
		if ns:IsDev() then GameTooltip:AddLine(L.MM_TIP2, 1, 1, 1) end
		GameTooltip:AddLine(L.MM_TIP3, 0.7, 0.7, 0.7)
		GameTooltip:Show()
	end)
	b:SetScript("OnLeave", function() GameTooltip:Hide() end)
	self.minimap = b
	self:UpdateMinimap()
end

function O:PlaceMinimap()
	local b = self.minimap
	if not b then return end
	local a = math.rad(ns.db.minimapAngle or 220)
	local r = (Minimap:GetWidth() / 2) + 10
	b:ClearAllPoints()
	b:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
end

function O:UpdateMinimap()
	if not self.minimap then return end
	self.minimap:SetShown(ns.db.minimapShow)
	self:PlaceMinimap()
end

------------------------------------------------------------
-- Start
------------------------------------------------------------
StaticPopupDialogs["THREATSENTINEL_REBIND"] = {
	text = L.KEY_REBIND,
	button1 = YES,
	button2 = NO,
	OnAccept = function(self)
		local d = self.data
		if d then
			ns.Taunt:SetKey(d.which, d.key)
			if d.refresh then d.refresh() end
		end
	end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
}

local function PopupEditBox(self)
	return self.editBox or self.EditBox or (self.GetEditBox and self:GetEditBox())
end

local function AcceptCustom(self)
	local eb = PopupEditBox(self)
	local d = self.data
	if not eb or not d then return end
	local text = strtrim(eb:GetText() or "")
	if text == "" then return end
	ns.db[d.key] = ns.CUSTOM_PREFIX .. text
	ns.Alerts:Play(ns.db[d.key], "pick" .. GetTime(), true)
	O:RefreshPicker()
	O:RefreshAll()
end

StaticPopupDialogs["THREATSENTINEL_CUSTOMSOUND"] = {
	text = L.SP_CUSTOM_PROMPT,
	button1 = OKAY,
	button2 = CANCEL,
	hasEditBox = true,
	maxLetters = 200,
	OnShow = function(self)
		local eb = PopupEditBox(self)
		if not eb then return end
		local cur = self.data and ns.db[self.data.key]
		if type(cur) == "string" and cur:sub(1, #ns.CUSTOM_PREFIX) == ns.CUSTOM_PREFIX then
			eb:SetText(cur:sub(#ns.CUSTOM_PREFIX + 1))
		else
			eb:SetText("")
		end
		eb:SetFocus()
		eb:HighlightText()
	end,
	OnAccept = AcceptCustom,
	EditBoxOnEnterPressed = function(eb)
		local parent = eb:GetParent()
		AcceptCustom(parent)
		parent:Hide()
	end,
	EditBoxOnEscapePressed = function(eb) eb:GetParent():Hide() end,
	-- danach die Ton-Auswahl wieder zeigen
	OnHide = function(self)
		if self.data and self.data.reopen and O.picker and O.frame and O.frame:IsShown() then
			O.picker:Show()
			O:RefreshPicker()
		end
	end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
}

StaticPopupDialogs["THREATSENTINEL_RELOAD"] = {
	text = L.O_RELOAD,
	button1 = YES,
	button2 = NO,
	OnAccept = function(self) ns:UseSharedProfile(self.data and true or false) end,
	OnCancel = function() O:RefreshAll() end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
}

function O:Login()
	self:CreateMinimap()
end

ns:On("PLAYER_REGEN_DISABLED", function()
	if O.frame and O.frame:IsShown() then O.frame:Hide() end
end)
