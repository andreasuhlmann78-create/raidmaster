local _, ns = ...
local L = ns.L

-- Levelling plan tab: target, steps and shopping list (Advisor.Plan / Advisor.Shopping),
-- buying the missing reagents at an open vendor and handing the AH reagents to AHSentinel's sniper.

local PL = {}
ns.Plan = PL

PL.CAPS = { 75, 150, 225, 300 }
PL.TOLERANCE = 10      -- sniper max price: market value + 10 %

-- target per profession (saved), otherwise the cap of the current rank
function PL.Target(prof, rank, maxRank)
    -- Retail: every expansion line has its own cap (e.g. 100) – that is the target
    if ns.IsRetail then return (maxRank and maxRank > (rank or 0)) and maxRank or math.max((rank or 0) + 1, maxRank or 0) end
    local pt = ns.db and ns.db.planTarget
    local t = type(pt) == "table" and pt[prof] or nil
    if type(t) == "number" and type(rank) == "number" and t > rank then return t end
    return ns.Advisor.DefaultTarget(rank, maxRank)
end

-- next cap above the current target (wraps to the first cap above your skill)
function PL.CycleTarget(prof, rank, maxRank)
    if ns.IsRetail then return end
    if type(ns.db.planTarget) ~= "table" then ns.db.planTarget = {} end
    local cur = PL.Target(prof, rank, maxRank)
    local nextT
    for _, c in ipairs(PL.CAPS) do
        if c > cur then nextT = c; break end
    end
    if not nextT then
        for _, c in ipairs(PL.CAPS) do if c > (rank or 0) then nextT = c; break end end
    end
    ns.db.planTarget[prof] = nextT or 300
    if ns.RefreshAll then ns.RefreshAll() end
end

-- current plan (computed when the tab is shown)
PL.current = nil

function PL.Build(prof, rank, maxRank)
    if not prof or not rank then PL.current = nil; return nil end
    local t0 = ns.DiagClock and ns.DiagClock()          -- diagnostic log: LANGSAM over 16 ms
    local target = PL.Target(prof, rank, maxRank)
    local plan = ns.Advisor.Plan(ns.ByProf[prof], rank, target)
    plan.list, plan.totals = ns.Advisor.Shopping(plan)
    plan.prof = prof
    PL.current = plan
    if t0 and ns.DiagSlow then ns.DiagSlow("Plan", t0) end
    return plan
end

---------------------------------------------------------------------------
-- Vendor: buy what is still missing (only what the open vendor sells)
---------------------------------------------------------------------------
-- Vendor access goes through PL.* (exported), so the test routine can check the buying logic with stubs
-- and never buys anything for real.
local function MerchantItemID(i)
    if ns.API.GetMerchantItemID then
        local ok, id = pcall(ns.API.GetMerchantItemID, i)
        if ok and id then return id end
    end
    if not ns.API.GetMerchantItemLink then return nil end
    local ok, link = pcall(ns.API.GetMerchantItemLink, i)
    return ok and type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil
end

-- price, stack per purchase, available (-1 = unlimited) of a vendor slot.
-- Old clients: GetMerchantItemInfo exactly as before; only where it is gone (modern client: WoW Forever,
-- Retail) C_MerchantFrame.GetItemInfo.
local function MerchantItemInfo(i)
    if ns.API.GetMerchantItemInfo then return ns.API.GetMerchantItemInfo(i) end      -- old clients: exactly as before
    if ns.API.MerchantGetItemInfo then
        local ok, info = pcall(ns.API.MerchantGetItemInfo, i)
        if ok and type(info) == "table" then return info.name, info.texture, info.price, info.stackCount, info.numAvailable end
    end
    return nil
end
PL.MerchantItemInfo = MerchantItemInfo
PL.MerchantItemID = MerchantItemID

local function MerchantNumItems()
    if ns.API.GetMerchantNumItems then return ns.API.GetMerchantNumItems() or 0 end
    if ns.API.MerchantGetNumItems then
        local ok, n = pcall(ns.API.MerchantGetNumItems)
        return ok and tonumber(n) or 0
    end
    return 0
end

-- buy n of a vendor slot: through ns.Act (BuyMerchantItem, in the modern client C_MerchantFrame.BuyItem
-- if the old function is gone)
local function BuyItem(i, n)
    return ns.Act("buy", i, n) and true or false
end
PL.MerchantNumItems = MerchantNumItems
PL.BuyItem = BuyItem
function PL.MerchantMaxStack(i) return GetMerchantItemMaxStack and GetMerchantItemMaxStack(i) or 20 end
function PL.Money() return GetMoney() end

function PL.MerchantOpen()
    return MerchantFrame and MerchantFrame.IsShown and MerchantFrame:IsShown() or false
end

function PL.BuyFromVendor()
    local plan = PL.current
    if not plan then return 0 end
    if ns.BlockedInCombat() then return 0 end
    if not PL.MerchantOpen() then ns.Print(L.PLAN_NO_MERCHANT); return 0 end
    local missing = {}
    for _, e in ipairs(plan.list or {}) do
        if e.missing > 0 then missing[e.id] = e.missing end
    end
    local bought, spent = 0, 0
    for i = 1, PL.MerchantNumItems() do
        local id = PL.MerchantItemID(i)
        local need = id and missing[id]
        if need and need > 0 then
            local _, _, price, stackCount, numAvailable = PL.MerchantItemInfo(i)
            stackCount = math.max(1, stackCount or 1)
            local maxStack = PL.MerchantMaxStack(i)
            if stackCount > 1 then
                -- sold in bundles: one purchase = one bundle
                local bundles = math.ceil(need / stackCount)
                if numAvailable and numAvailable >= 0 then bundles = math.min(bundles, numAvailable) end
                for _ = 1, bundles do
                    if PL.Money() < (price or 0) then break end
                    if not PL.BuyItem(i, 1) then break end
                    bought = bought + stackCount; spent = spent + (price or 0)
                end
            else
                local left = need
                if numAvailable and numAvailable >= 0 then left = math.min(left, numAvailable) end
                while left > 0 do
                    local n = math.min(left, math.max(1, maxStack))
                    if PL.Money() < (price or 0) * n then n = math.floor(PL.Money() / math.max(1, price or 1)) end
                    if n <= 0 then break end
                    if not PL.BuyItem(i, n) then break end
                    left = left - n
                    bought = bought + n; spent = spent + (price or 0) * n
                end
            end
        end
    end
    ns.Print(bought > 0 and string.format(L.PLAN_BOUGHT, bought, ns.Prices.MoneyPlain(spent)) or L.PLAN_VENDOR_NOTHING)
    if C_Timer then C_Timer.After(1, function() if ns.RefreshAll then ns.RefreshAll() end end) end
    return bought
end

---------------------------------------------------------------------------
-- AH: missing reagents (not sold by a vendor) into AHSentinel's sniper
-- max price = market value + tolerance, amount = what is missing
---------------------------------------------------------------------------
function PL.SniperTargets(list, tolerance)
    tolerance = tolerance or PL.TOLERANCE
    local out = {}
    for _, e in ipairs(list or {}) do
        if e.missing > 0 and e.origin ~= "vendor" and e.known and e.unit > 0 then
            out[#out + 1] = { id = e.id, maxPrice = math.max(1, math.floor(e.unit * (1 + tolerance / 100))), qty = e.missing }
        end
    end
    return out
end

function PL.ToSniper()
    local plan = PL.current
    if not plan then return 0 end
    if ns.BlockedInCombat() then return 0 end
    local targets = PL.SniperTargets(plan.list)
    if #targets == 0 then ns.Print(L.PLAN_SNIPE_NOTHING); return 0 end
    return ns.Disenchant.SendToSniper(targets, L.PLAN_SNIPE_WHAT, L.PLAN_SNIPE_DONE)
end

-- refresh the vendor button when a merchant opens or closes
local ev = ns.AddEventFrame(CreateFrame("Frame"), "Plan")
pcall(ev.RegisterEvent, ev, "MERCHANT_SHOW")
pcall(ev.RegisterEvent, ev, "MERCHANT_CLOSED")
ev:SetScript("OnEvent", function()
    if ns.db and ns.db.panelMode == "plan" and ns.UI and ns.UI.Refresh then ns.UI:Refresh() end
end)
