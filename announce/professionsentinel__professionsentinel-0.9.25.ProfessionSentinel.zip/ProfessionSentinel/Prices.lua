local _, ns = ...
local L = ns.L

-- Prices for the gold ranking.
--   Reagents:  sold by a vendor  -> the vendor price (fixed, from the game data)
--              everything else   -> the auction house value (also for farmed material: what you
--                                   could have sold it for)
--   Product:   the higher of auction house value minus the 5 % AH cut and vendor sell value
--              (× items per craft)
--   Disenchanting (Disenchant.lua, only with withDE = true – the enchanter tab): expected
--              material value minus the 5 % AH cut, as a separate value. The other professions'
--              rankings never count disenchanting.
-- AH values come from AHSentinel (GoldSentinel), otherwise TSM, otherwise Auctionator.
-- ns.Items[id] = { name, quality, vendorSell, vendorBuyPerPiece (0 = no vendor), farmable }

local P = {}
ns.Prices = P

-- Auction house cut: 5 % of the sale price is kept by the auction house
P.AH_CUT = 0.05

-- WoW Forever (rule of 9 Nov., replaces all earlier ones): there is ONE fee only – the AH fee
-- = max(5 % of the auction's sale price, 1 silver), per auction (per listed stack, not per piece), paid when
-- listing. No separate listing fee from the vendor value. Profit = sale price − AH fee − materials.
-- Other game versions (Era, TBC, Retail): unchanged – 5 % cut on the sale, the deposit comes back.
P.MIN_FEE = 100
P.FEE_RATE = 0.05

function P.FeeApplies()
    return ns.IsForever == true
end

function P.StackSize(itemID)
    -- old global first (exactly as before), C_Item.GetItemInfo in the modern client
    local ok, _, _, _, _, _, _, _, stack = pcall(ns.ItemInfo, itemID)
    if ok and type(stack) == "number" and stack > 0 then return stack end
    return 1
end

-- AH fee of ONE auction with this total sale price (copper). With AHSentinel its own function (same number in
-- both addons), otherwise max(5 %, 1s).
function P.AuctionFee(price)
    price = tonumber(price) or 0
    local A = _G.AHAnalyzerPro
    for _, fn in ipairs({ "AuctionFee", "AHFee" }) do
        if type(A) == "table" and type(A[fn]) == "function" then
            local ok, v = pcall(A[fn], A, price)
            if ok and type(v) == "number" and v >= 0 then return v end
        end
    end
    return math.max(P.MIN_FEE, math.floor(price * P.FEE_RATE))
end

-- WoW Forever: AH fee per piece when a full stack (1 piece if it does not stack) is listed as one auction.
-- unit = sale price per piece (default: the AH value). Other game versions: 0 (only the 5 % cut on the sale).
function P.FeePerPiece(itemID, unit)
    if not P.FeeApplies() or not itemID then return 0 end
    local stack = P.StackSize(itemID)
    unit = unit or P.AH(itemID) or 0
    return P.AuctionFee(unit * stack) / stack
end

---------------------------------------------------------------------------
-- Auction house value (copper) and which addon delivered it
---------------------------------------------------------------------------
function P.AH(itemID)
    if ns.Sim and ns.Sim.prices then
        local v = ns.Sim.prices[itemID]
        if v then return v, "Test" end
    end
    local A = _G.AHAnalyzerPro
    if A and A.GetMarketValue then
        local ok, v = pcall(A.GetMarketValue, A, itemID)
        if not ok then ns.CountError("AHSentinel:GetMarketValue", v) end
        if ok and type(v) == "number" and v > 0 then return v, "AHSentinel" end
    end
    if _G.TSM_API and TSM_API.GetCustomPriceValue then
        local ok, v = pcall(TSM_API.GetCustomPriceValue, "dbmarket", "i:" .. itemID)
        if not ok then ns.CountError("TSM", v) end
        if ok and type(v) == "number" and v > 0 then return v, "TSM" end
    end
    local AU = _G.Auctionator
    if AU and AU.API and AU.API.v1 and AU.API.v1.GetAuctionPriceByItemID then
        local ok, v = pcall(AU.API.v1.GetAuctionPriceByItemID, "ProfessionSentinel", itemID)
        if not ok then ns.CountError("Auctionator", v) end
        if ok and type(v) == "number" and v > 0 then return v, "Auctionator" end
    end
    return nil
end

function P.SourceName()
    if ns.Sim and ns.Sim.prices then return "Test" end
    if _G.AHAnalyzerPro and _G.AHAnalyzerPro.GetMarketValue then return "AHSentinel" end
    if _G.TSM_API and TSM_API.GetCustomPriceValue then return "TSM" end
    local AU = _G.Auctionator
    if AU and AU.API and AU.API.v1 then return "Auctionator" end
    return nil
end

function P.VendorBuy(itemID)
    local d = ns.Items[itemID]
    if d and d[4] and d[4] > 0 then return d[4] end
    -- AHSentinel reads what a vendor asks while you visit it (also new Retail vendor goods)
    local A = _G.AHAnalyzerPro
    if A and A.GetVendorBuyPrice then
        local ok, v = pcall(A.GetVendorBuyPrice, A, itemID)
        if not ok then ns.CountError("AHSentinel:GetVendorBuyPrice", v) end
        if ok and type(v) == "number" and v > 0 then return v end
    end
    return nil
end

function P.VendorSell(itemID)
    local d = ns.Items[itemID]
    local v = d and d[3]
    if not v or v == 0 then
        local ok, _, _, _, _, _, _, _, _, _, _, sell = pcall(ns.ItemInfo, itemID)
        if ok and type(sell) == "number" and sell > 0 then v = sell end
    end
    return v and v > 0 and v or nil
end

function P.IsFarmable(itemID)
    local d = ns.Items[itemID]
    return d and d[5] == 1 or false
end

---------------------------------------------------------------------------
-- Cost of one reagent: (copper per piece, origin "vendor" | "ah" | "farm", known)
---------------------------------------------------------------------------
function P.ReagentUnit(itemID)
    local vb = P.VendorBuy(itemID)
    if vb then return vb, "vendor", true end
    local ah = P.AH(itemID)
    local origin = P.IsFarmable(itemID) and "farm" or "ah"
    if ah then return ah, origin, true end
    return 0, origin, false
end

-- Full calculation for a recipe. Returns a table:
--   cost, value, net (per craft, copper), known (all prices found), parts = { {id, count, unit, origin, known} },
--   origins = { vendor = true, ah = true, farm = true }, valueSource "ah" | "vendor" | nil
function P.Recipe(r, withDE)
    local res = { cost = 0, value = 0, known = true, parts = {}, origins = {} }
    for i = 1, #(r.reagents or {}), 2 do
        local id, n = r.reagents[i], r.reagents[i + 1]
        local unit, origin, known = P.ReagentUnit(id)
        res.parts[#res.parts + 1] = { id = id, count = n, unit = unit, origin = origin, known = known }
        res.origins[origin] = true
        res.cost = res.cost + unit * n
        if not known then res.known = false end
    end
    if r.out then
        local count = ((r.outMin or 1) + (r.outMax or r.outMin or 1)) / 2
        local ah = P.AH(r.out)
        local vs = P.VendorSell(r.out)
        -- The auction house keeps 5 % of every sale: compare what actually lands in the mailbox
        local ahGross = ah and ah * count or nil
        -- WoW Forever: one AH fee (5 %, at least 1s per auction); elsewhere the 5 % cut
        local ahCut
        if ahGross then
            if P.FeeApplies() then ahCut = P.FeePerPiece(r.out, ah) * count else ahCut = ahGross * P.AH_CUT end
        end
        local ahNet = ahGross and (ahGross - ahCut) or nil
        local vend = vs and vs * count or nil
        if ahNet and (not vend or ahNet >= vend) then
            res.value, res.valueSource = ahNet, "ah"
        elseif vend then
            res.value, res.valueSource = vend, "vendor"
        end
        res.valueAH, res.valueAHNet, res.valueVendor = ahGross, ahNet, vend
        res.ahCut = ahCut
        res.ahFee = nil      -- no separate listing fee any more (rule of 9 Nov.)
        -- Disenchanting (materials are sold in the AH as well: minus the 5 % cut)
        local DE = ns.Disenchant
        if DE and withDE then
            local gross, complete, yield, own, shared, src = DE.Value(r.out)
            if gross then
                res.deGross = gross * count
                -- WoW Forever: the AH fee of the materials (expected pieces × fee per piece); elsewhere the 5 % cut
                if P.FeeApplies() and type(yield) == "table" and #yield > 0 then
                    local fee = 0
                    for _, y in ipairs(yield) do fee = fee + (y[2] or 0) * (y[3] or 0) * P.FeePerPiece(y[1]) end
                    res.deCut = fee * count
                else
                    -- no material list (only a total value): 5 % of it
                    res.deCut = res.deGross * P.AH_CUT
                end
                res.deFee = nil
                res.deValue = res.deGross - res.deCut
                res.deComplete, res.deYield, res.deOwn, res.deShared, res.deSource = complete, yield, own, shared, src
            end
        end
    end
    -- net = selling the product (AH or vendor); deNet = disenchanting it and selling the materials
    res.net = res.value - res.cost
    if res.deValue then res.deNet = res.deValue - res.cost end
    -- best way to use the product
    if res.deNet and (res.value <= 0 or res.deNet > res.net) then
        res.bestNet, res.bestVia = res.deNet, "de"
    else
        res.bestNet, res.bestVia = res.net, res.valueSource
    end
    return res
end

---------------------------------------------------------------------------
-- Money text: "+10s 80c", "−2s", "1g 5s"
---------------------------------------------------------------------------
function P.Money(copper, signed)
    if not copper then return "?" end
    local neg = copper < 0
    copper = math.floor(math.abs(copper) + 0.5)
    local g, s, c = math.floor(copper / 10000), math.floor((copper % 10000) / 100), copper % 100
    local parts = {}
    if g > 0 then parts[#parts + 1] = "|cffffd100" .. g .. "g|r" end
    if s > 0 then parts[#parts + 1] = "|cffc7c7cf" .. s .. "s|r" end
    if c > 0 or #parts == 0 then parts[#parts + 1] = "|cffc87533" .. c .. "c|r" end
    local txt = table.concat(parts, " ")
    if signed then txt = (neg and "−" or "+") .. txt elseif neg then txt = "−" .. txt end
    return txt
end

-- Plain version without colour codes (for compact hints)
function P.MoneyPlain(copper, signed)
    if not copper then return "?" end
    local neg = copper < 0
    copper = math.floor(math.abs(copper) + 0.5)
    local g, s, c = math.floor(copper / 10000), math.floor((copper % 10000) / 100), copper % 100
    local parts = {}
    if g > 0 then parts[#parts + 1] = g .. "g" end
    if s > 0 then parts[#parts + 1] = s .. "s" end
    if c > 0 or #parts == 0 then parts[#parts + 1] = c .. "c" end
    local txt = table.concat(parts, " ")
    if signed then txt = (neg and "−" or "+") .. txt elseif neg then txt = "−" .. txt end
    return txt
end

P.ORIGIN_COLOR = { ah = "d9a400", vendor = "9a9aa8", farm = "3aa83a" }
