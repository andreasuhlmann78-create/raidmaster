# GuildSentinel – Changelog

## 0.9.63
- For the developer (test routine, nothing changes in normal play):
  - A performance check over its limit only counts as "handling/environment possible" if the game was in the background, a loading screen ran or a garbage collection ran in that frame. "Rest of the frame larger than its own work" alone no longer counts (that is almost always the case and would hide real regressions).
  - "Memory per addon" also shows GuildSentinel after a full garbage collection – what GuildSentinel really holds (before it included the run's garbage).
  - The test routine never opens a game window itself (rank/guild window); new check T320.
  - The simulated whispers each run in a frame of their own (shorter portions).

## 0.9.62
- For the developer: the test routine recognises environment and handling (developer mode only, read only). It measures frames before, during and after the run, detects periods with the game in the background or a window switch (frame rate at the background limit or twice as slow as at rest), names for each frame over 40 ms its own work against the rest, loading screen and garbage collection, and once after the run the memory per addon. If a performance check is over its limit while the game was in the background, a loading screen ran or the rest of the frame was larger than its own work, it says "handling/environment possible" (note) instead of an error. Nothing changes in normal play.

## 0.9.61
- Window gets out of the way: if the GuildSentinel window covers another window when it opens (LevelPilot, AHSentinel, ProfessionSentinel, RaidMaster, ThreatSentinel, BuffSentinel, guild, friends or profession window), it docks next to it – right, left, below or above, the shortest way, fully on screen. If it fits nowhere, it shrinks as little as needed (at most to 95 %; at 16:9 (UI 1365 × 768 points) with LevelPilot in its default spot 99.4 %). If such a window opens later, GuildSentinel moves then. Your saved position stays; the next time you open it without the other window, GuildSentinel is back there.
- Group finder: the "Elite quest (LevelPilot)" button is inside the window again (it stuck out on the right); with LevelPilot the note field is narrow enough for both.
- Readability: the Shaman class colour is a little lighter on the dark window (was 3.7:1, now at least 4.6:1) – names in lists, "Where", composition, progress, leadership, rules. All other class colours stay exactly as in the game.
- Board (offers/wants) and crafting requests: an item's tooltip shows quantity and price (or OBO) right in the first line after the name, the game's details follow below.
- Performance: the "Online times" page builds its overview without a new table per measurement (test setup 1,196 KB → 42 KB per build) and only once per display (twice before).
- Shared file GoldSentinelTest 3 (a check returning nil counts as an error; texts are never cut in the middle of a character).
- For the developer: the test routine names the exact place of the longest portions ("in T…" = check running, "nach T…" = between checks) and whether a garbage collection ran in that frame; T21/T22 open the pages in portions of their own; the bank checks can pause in between.

## 0.9.60
- Raid readiness without estimates: "raid-ready in n weeks (from x players, y days measured)" instead of "at the current pace in ~n weeks". With fewer than 3 players with a measured pace or less than 7 days of measurement it says "not enough data yet" (no week count in the Discord report either). The pace is now divided by the days actually measured (at most 14; before always by 14).
- Level gain: the level a member joins with no longer counts as a level-up (new members had one level too many – ranking "levels in the last 7 days" and raid readiness).
- "First to max level": if the date only comes from the member list (no event of its own), it says "by <day> at the latest" instead of an exact time.
- Applicant tooltip: "First seen" now sits right under the name (before at the bottom).
- The log entry for merging guild data lists the entries per old key ("before 802 = 479 + 323").
- For the developer: the test routine checks L5 (main number on top in every tooltip with numbers, T317) instead of skipping it.

## 0.9.59
- Guild data without realm: on WoW Forever the game reports a different home realm per character – the same guild was stored under several keys (members, log, administration split). Now "faction + guild" is used. Old entries are merged once on login: nothing twice, earlier join time, newer states win; the old data stays as a backup (guildsOld), counts before/after in the log (/gs protokoll, line GILDE). "My week" shows the characters of all home realms.
- Members page: built in a frame of its own after the window opens, the first selection only fills it; the list's numbers are computed once per selection (before up to three times). A slow selection lists its parts in the log (read/filter/sort, rows, numbers, details).
- Recruitment: instead of the white block "Placeholders: {gilde} {fraktion} …" a small "Placeholders (?)" button – its tooltip lists every placeholder with its meaning (ad, automatic reply, welcome, rejection). "Leave empty = default text" is shown in grey in the empty ad field.
- Readability: the selected row of a list now has an accent stripe on the left and a fainter fill (grey and red text on it was too weak); brighter version number in the title bar; every column has a header.
- "Who's free": "Flag as free" and "No longer free" have their own row (they stuck out of the window in 6 of 10 languages); the rejection text has its hint and button below the field.
- Developer commands (sync test, protokoll, clienttest, debug) appear in help and the command list only in developer mode.
- Shared files: GoldSentinelSync 3 and GoldSentinelTakt 3.
- For the developer: the test routine first measures the environment for 10 s (location, ping, frames/s; line "Umgebung" in the report), also compares the shared data (sync address book, sync and market storage) before/after the run (SHARED) and checks readability L1–L8 (T311–T318) and controls inside the window (T319). Found and fixed: T293 created an empty slot in the real market storage.

## 0.9.58
- Performance: from 100 members GuildSentinel reads the member list as a task of the shared scheduler – only the reading in one go, the notes in portions, the comparison at the end. Before, everything ran in one frame (16 ms with 500 members in game, every 30 seconds). During the portions the main from the note stays (no flicker).
- Performance: notes like "Alt of X" whose main is no longer in the guild went through the whole list for every alt on every read. The result is now remembered per name (rebuilt with 500 members: 216 ms → 5 ms).
- Title bar on the right in the window's style: flat close X (instead of the Blizzard X), "Support" as a small coin icon with tooltip (instead of a grey button), guild info with spacing – all the same height and on one line.
- For the developer: the test routine checks the shared sync address book for test names (T308), the title bar (T309) and that every player feature is reachable without developer mode (T310); T138 measures the median of 3 runs and the longest frame in portions.

## 0.9.57
- New options modelled on AHSentinel (Settings > Options): sections on the left (General, Chat & tooltip, Announcements, Group finder, Recruitment, Data & sync, Features: community, Features: guild & raid, Leadership), only the options of the chosen section on the right in one column, no scrolling. A search box on top searches all sections (e.g. "sound"). Each row: a short label, an "on"/"off" button (or a row of buttons) on the right, the explanation in the tooltip. "Default" per section, rarely used options under "More".
- Every option appears exactly once. Switches that sit next to their own text (automatic reply, welcome, application questions, minimum age, advertising channels, group finder role, promotion, composition) stay there – in the options a link jumps right to them. The advertising reminder and "Delete old applications" moved from the Recruitment page into the options; an "Options" button there opens the Recruitment section (likewise on the Group finder page).
- Clicking a feature that is turned off opens its section in the options.
- All saved settings stay valid (same fields as before).
- For the developer: checklist point "OPT options on screen" (the right-click menu point, already done in game, was removed for it); the test routine checks every option (T307a–e) and reports which old game functions the client has (T306).

## 0.9.56
- Fix: the weekly review in guild chat announced first kills that never happened. Cause: GuildSentinel read RaidMaster's first kills while RaidMaster's test routine was running – and so its test data. Now GuildSentinel reads no data of other addons while another addon's test routine (or its own) is running. A first kill only counts with an entry in the raid log (boss kill with time); its date is the time from the log.
- One-time clean-up: first-kill milestones without proof in the raid log are removed at the next login (with RaidMaster) and noted with date in the log (/gs log); the copy on other computers of the guild removes them on sync too. A real later kill is added again.
- Announcements in guild chat are held back while another GoldSentinel addon runs its test routine.
- Singular/plural in the weekly review in all languages: "1 new member", "1 level", "1 new level-60 player" (Russian with three forms).
- New for other addons: GuildSentinelAPI.TestRunning().
- For the developer: the test routine no longer calls UpdateAddOnMemoryUsage (itself a 51.5 ms stutter in game); the report shows the memory allocated per area and the five largest checks instead. The diagnostic log computes the market network lines at most once a minute and not at all during the test routine (it went through all items of the market store on every call – in game a 45 ms frame in T188 and 43 ms in T198).

## 0.9.55
- More robust with damaged guild data: sync answers, events, thanks and online days skip broken entries instead of stopping with a Lua error (found because the test routine now runs in the scheduler and timers run in between). Broken thanks entries are removed on login.
- For the developer: the test routine no longer runs a full garbage collection (leistung.md build rule 2) and reports how long the memory measurement itself takes; T118 now also checks all timer and sync paths with broken data.

## 0.9.54
- Faster in large guilds: "Inactive" (leadership, overview, clean-up) was quadratic with many members – noticeable stutter with 500 members. Now one pass, same result.
- Settings: the language selection is wide enough for "same as the game client (English)".
- Edit boxes: if a text or hint is longer than the box, hovering shows the full text in a tooltip (before, the tooltip was on the border and almost never appeared).
- Guild achievements: long lines ("missing: …") in full in the tooltip.
- Selections and tables in longer languages: numbers are never cut off (loot wishes, attunements, clean-up, two-line overview tiles, recommendation for trial members, "Who is free"). "Keep max level" in clean-up is now below the selections. Korean: loot wish with the number first.
- Shared file GoldSentinelTakt (version 1, unchanged from shared/): the test routine now runs in the shared anti-stutter scheduler.
- For the developer: the test routine pauses between pages, tabs, features and situations (in game up to 355 ms in one piece); memory split into GuildSentinel and all addons; T82 counts shared files from the own folder with a held prefix as real and always lists what did not come from GuildSentinel; reports contain no names from the window.

## 0.9.53
- Tooltips in the main window now appear next to the window, at the height of the element (right, or left if there is no room). Before, they covered other buttons of the same window in lists and the side bar.
- Tables: columns grow to the width of their header and their numbers – numbers and times are never cut off any more (e.g. "free until 18:36" in "Who is free", "Level" in Russian, "Raid goal" in Italian). If a text cell is still too long, the row tooltip shows the full text.
- Spanish: "offline for … days" selection (management) wider; Russian: "%d days left" shorter, number first.
- For the developer: the test routine now pauses between steps in area K (in game it was 843.8 ms in one piece). Cause: a marker for test values stayed set after the first check using them and prevented every pause afterwards. Messages about tooltips and cut texts now name the button text instead of "Button in ?". T285 checks with a real edit box (no bug for players). T82 ("nothing sent") now names who sent (own file, shared building block or another addon, with prefix and channel, without content); only own sends are an error. During the test routine, messages of other addons in the shared queue now go out normally (before: held back and dropped). Several checks were red in Spanish and Chinese without a bug in the addon – fixed.

## 0.9.52
- Fix: as guild master (or officer) the right-click menu showed "Promote", "Demote", "Set rank …" and "Remove from guild" greyed out with "Not above your own rank …". Cause: GuildSentinel looked up your own rank only under the exact spelling of your name; if the guild roster spells it differently (case, spaces, first and last name in WoW Forever), your own rank stayed unknown. Your own entry is now found anyway, otherwise the rank comes directly from the game. If it really is not loaded yet, the menu says "Your own rank is not loaded yet – please try again in a moment." and the roster is requested again.
- The same affected the suggestions for removing inactive members (with an unknown rank, higher ranks were suggested too), the alt rank suggestions and the "guild master" detection. All now use the same way.
- Shared market file GoldSentinelMarkt updated to version 10 (unchanged from shared/: checks the time more often, no stutter when passing data on).
- "/gs log" shows a line "RANG eigener Rang: Weg=…" (without names) so it is visible how your own rank was found.
- For the developer: the test routine now reports Lua errors that a check causes on the side as a separate FEHLER line. Two checks (cleaning up old applications) caused Lua errors with the window open ("Roster.lua:124 … 'alts'") – a bug in the checks themselves, not in the addon; fixed.

## 0.9.51
- For the developer: "/gs testroutine alles" – all automatic checks at once (test routine and the measurable in-game check points), with progress in chat and one summary. The routine now runs in small portions over many frames instead of in one piece; "/gs testroutine stop" stops cleanly. Logging out or reloading during a run restores all test data first – before anything else is saved at logout.
- Checklist (/gs checklist): every point with "where", numbered steps, what you should see and what it costs.
- Nothing changes for players.

## 0.9.50
- For the developer: in-game checklist ("/gs checklist", developer mode only) using the shared building block GoldSentinelPruefliste (unchanged from shared/). 14 open check points with exact instructions; most tick themselves as soon as the feature was really used in game. Result also in "/gs log". Nothing changes for players.
- Developer tests: test/run_pruefliste.lua (every place that ticks a point, via the real path; no effect without developer mode), T303.

## 0.9.49
- Shared file GoldSentinelDev.lua updated to version 2 (unchanged from shared/): the developer detection no longer contains a character name in plain text. Nothing changes for players.

## 0.9.48
- /gs clienttest: the ban list check now always leaves exactly the state from before (even if there was no ban list yet). Nothing changes in normal play.
- Developer tests: test/run_clienttest.lua extended for this case.

## 0.9.47
- New: "/gs clienttest" – guided in-game test. It goes through the open check points of the last versions (ad texts, automatic reply limit, applicant list, ban list, returning members, note history, building pages later, stutter, tooltip, privacy), checks everything measurable by itself and only asks four short questions (OK / Not OK / Skip). Result: one line per point in "/gs log". The test sends no messages, changes no guild data and does not run in combat.
- Developer tests: test/run_clienttest.lua (all answers, Lua error in one point, no message, data unchanged).

## 0.9.46
- Faster first opening: the window now only builds the page you select – the others when you open them for the first time. Before, all pages were created at once when opening the window for the first time (over 800 window parts and 1300 texts/images in one frame); now it is 48 and 125 for the home page. In the offline model: first opening 14.8 ms -> 2.8 ms. Diagnostic log: "Seite bauen <page>" if a page takes longer than one frame.
- Developer tests: test/run_g4.lua extended (only the selected page built, each only once, with counter-check), measuring script test/perf_open.lua.

## 0.9.45
- New: returning members. If a member comes online after at least 30 days (and no other character of the same player was around), the history shows it ("is back after a long break – after N days"), and officers see "Returning: … – welcome them back?" in chat. Only during the session, not on the first read after logging in (otherwise everyone who played while you were away would be "back").
- New: note changes in the history (Members > History): "public note changed" and "officer note changed" with old → new. Officer notes only if you can read them.
- Developer tests: T300a–b, test/run_return.lua (11 checks with counter-checks).

## 0.9.44
- New: ban list (Leadership > Ban list, officers only). Enter a name and a reason; the list is only shared with officers who use GuildSentinel. GuildSentinel NEVER messages a banned player – it only warns your own leadership:
  - If they apply: they are recorded (status "banned") but get no automatic reply and no questions; a hint appears in chat (at most every 10 minutes).
  - Inviting through GuildSentinel is blocked (message with the reason).
  - If they join anyway: red warning in the officers' chat.
  - For officers the player tooltip shows "On the ban list: <reason>".
- Developer tests: T299a–d (with counter-checks), test/run_ban.lua (sync between officers, page). New test scripts now also count caught errors.

## 0.9.43
- Privacy: if an applicant states their age in a whisper or an answer ("ich bin 15", "17 Jahre", "I'm 16"), the number is made unreadable before it is stored ("I'm …"). Levels ("lvl 60", "level 52") and other numbers stay. The result of the age question ("16+ / under 16 / unclear") is stored as before.
- New option under Recruitment > Replies & welcome: "Delete closed applications after 90 days" (on by default, explained on hover). If anything is deleted, a line appears in your own chat.
- Developer tests: T297c, T298a–b (with counter-checks).

## 0.9.42
- New in the player tooltip for guild members: "In the guild since <date>" and "Last promoted/demoted: <date> (<rank>)" – as far as GuildSentinel knows (earliest known join, guild history).
- Closed applications (joined, declined, declined due to age) are deleted automatically 90 days after the last message. Open applications stay until an officer decides.
- Diagnostic log: building the window ("Fenster aufbauen") and reading the member list ("Mitgliederliste lesen") are measured; if it takes longer than one frame, a SLOW entry is written (to pin down rare stutters).
- Developer tests: T297a–b, test/run_g4.lua, measuring script test/perf_events.lua.

## 0.9.41
- Recruitment > applicants: anyone who was not contacted automatically because of the automatic reply limit (at most 5 in 10 minutes) now shows the status "whisper yourself" in the list; the tooltip explains why. As soon as you whisper them yourself, the mark goes away.
- If an applicant you already know writes the keyword again while the limit is full, your chat now shows a line for that too ("automatic reply paused …") – at most once per name in 10 minutes. Before, they got no reply and you got no hint.
- "Status" column of the applicant list a little wider so long entries are fully visible.
- Developer tests: T296d–e (with counter-checks), test/run_g3.lua extended.

## 0.9.40
- Protection against whisper floods (G-3): automatic replies and application questions to strangers go to at most 5 new contacts in 10 minutes (in addition to the limit "once per 10 minutes per name"). Beyond that nothing is sent automatically – your own chat shows "New applicant: <name> – automatic replies paused …, please whisper them yourself." All applicants are still recorded. The limit slides: as soon as a reply is older than 10 minutes, there is room again.
- Fix: an applicant you already knew who simply kept chatting got the fixed reply text again every 10 minutes. Now only when they write the keyword again. Answers to the application questions work as before.
- Market data network: shared file GoldSentinelMarkt.lua updated to version 7 (unchanged from shared/): passing on a scan now runs in portions and with much less memory (about 2.8 MB instead of up to 7.5 MB, same result) – without AHSentinel the old version would otherwise run with a long stutter.
- Developer tests (G-1): old tests run_v6/v7/v8 updated (12 red checks: online filter selection, no own group-finder channel since 0.9.20, language choice via uiLang). New script test/run_alle.sh runs all tests with a total and also counts red single checks (before only crashes). New: T296a–c, test/run_g3.lua (20 strangers in one minute).

## 0.9.39
- New (GS-W2): the "Choose suggestion" button on the recruitment page opens a list of ready-made ad texts: default text of the phase, short and simple, build-up, raid roster, friendly and cosy, with Discord tag, without Discord. Each entry shows its character count, and hovering shows the finished text. Suggestions that match the phase (build-up/raid) are at the top. Only a click replaces the text in the field.
- GS-W1: every suggestion (including the one with the Discord tag) ends again with "– whisper me: /w <name> guild", in every language with its own word. An own text without this part gets a yellow hint; "Apply" appends it – never unasked.
- Shortening to the chat length (255 characters): first the class list, then the Discord sentence, then the beginning of the text – the whisper part always stays whole.
- Fixes: Chinese – dropping the Discord tag in the bracket （…） removed the whole rest including the whisper part. Shortening could cut Chinese characters in half at the end. Portuguese: all texts now use "sussurre para mim".
- Market data network: shared file GoldSentinelMarkt.lua updated to version 4 (unchanged from shared/): export of the last 6 scans, at most 1.5 MB; turning "Share market data" off also stops an already planned reply to the guild.
- Developer tests: T295a–g (T-GSW1/T-GSW2), T247 adjusted, T291 requires version 3 or newer.

## 0.9.38
- Market data network: shared file GoldSentinelMarkt.lua updated to version 2. It no longer reads a full scan a second time when AHSentinel is loaded (AHSentinel hands its scan over instead) – version 1 made the game stutter during AHSentinel's full scan and in its sniper. Smaller send queue, guild summary at most hourly, sold-out items in the export.
- The "Share market data" tick now shows whether the network really runs: if another GoldSentinel addon has it turned off, the tick is off and a short hint says so.
- Developer tests: T291 extended (version 2, FeedStart/Feed), T294 (tick follows the network).

## 0.9.37
- New: market data network (shared file GoldSentinelMarkt.lua, same in all GoldSentinel addons). When any addon or the player runs a full auction house scan, it is read along in small portions (never in combat, never a scan of its own) – lowest unit price, quantity and number of auctions per item, plus measured sales between two scans. No names: owners, bidders and item names are never read. Shared anonymously with the guild and the GoldSentinel network, own faction only. On by default, no question asked; Settings > "Share market data (anonymous, prices only)" turns it off (then nothing is read or sent). Without the auction house interface (Era/TBC) it stays silent.
- Diagnostic log: lines "MARKT-NETZ" (version, on/off, scans read, sent/received, memory) – no names.
- Fix: Guild management > Invite (and the member menu) now also respects the age block – applicants "declined (age)" cannot be invited from there either.
- Developer tests: T291–T293 (MN4), T289f; offline load test with and without the market file.

## 0.9.36
- New (GA1): age question "How old are you?" for applicants. With a minimum age set (Recruitment > texts, default 16, 0 = off) it is ALWAYS asked as the last question, also with your own question list. Answer "17", "I'm 17", "17 years" -> continues normally. Below the minimum age: a friendly whisper ("Thanks for your interest in <guild>! Unfortunately we only accept players aged 16 and over. Have fun in Azeroth!" – text adjustable), status "declined (age)", "Invite to guild" blocked. No number or "soon 16" -> no automatic decline, status "age unclear" for an officer.
- Privacy: the exact age and the answer text are never stored, shared or logged – only "16+" / "under 16" / "unclear".
- New (GA2): in recruitment phase Build-up the default ad says so: "<guild> (faction) is being built up and is looking for players of all classes – relaxed, helpful, raid goal …". New placeholder {phase} ("being built up" / "almost raid-ready" / "raid-ready"). An own ad text without {wanted} or {phase} gets a yellow hint with an "Apply" button (takes the phase's default text). The finished chat text is shown right above the "Prepare ad" button.
- Developer tests: T289a–e (T-GA1a–e), T290a–c (T-GA2a–c); offline flow with ages 17 / 15 / "bald 16".

## 0.9.35
- The summary for the uploader and the Discord bot (GuildSentinelDB.raidReady, written on logout) now has the field "vorschlag": the recruitment phase GuildSentinel currently suggests ("build" / "trans" / "raid", same words as "phase"); missing when no suggestion is open or it was put off with "Later". No names. The bot can then post "GuildSentinel suggests phase … – confirm in the game".
- Developer test: T288 (T-RP-V).

## 0.9.34
- New: command list while typing. Type /gs (or /guildsentinel) in chat and a list of ALL commands with a short description appears above the input box. Every letter filters ("/gs w" = where, away, ad …), German and English command words both work, commands with an argument show it ("thanks <Name>"), the most used are on top. A mouse click or Tab selects an entry, Enter runs it. The chat input is never written to. Developer commands only for the developer. Settings > "Command list while typing /gs" turns it off.
- The command list and the /gs handler use one and the same command table, so the list always has every command.
- Building block taken unchanged from AHSentinel (CmdHint).
- Developer tests: T282–T287 (T-BL1–T-BL6). TU1 situation catalogue extended by group finder, events, polls and sync and by the situations "channel refuses addon messages", "member with an old version" and "guild changed" (11 functions x 9 situations).

## 0.9.33
- Fix: the button in the "Guild action" window (promote, demote, remove, leadership) did nothing when the option "Cast action keybinds on key down" (ActionButtonUseKeyDown) was off – the press set "waiting" and the release then blocked the command, so after 6 seconds it always said "Not carried out". GuildSentinel now only reacts in the phase in which the game runs the command (press or release, depending on the option); one click = exactly one command.
- Developer tests: T281 (T-GA1, both settings) in the test routine; offline test client with the setting on and off.

## 0.9.32
- Developer test routine (/gs testroutine) extended so that errors like the blocked guild invite cannot slip through again:
  - TU1 situation catalogue: 1 / 50 / 500 members, many offline, no rights / officer / Guild Master, first and last names with equal first names, no guild – each through ad text, applicant invite, guild management, member menu, member list, promotion, line-up/raid readiness and professions (T270).
  - TU2 player-like flows: applicant -> invite -> no system message / message -> remove; promote without answer, retry, confirmation; /reload in the middle; ad without a channel (T271).
  - TU3 default values: every field empty or as shipped gives what the player means (T272).
  - TU4 basic rules with 1000 random cases (fixed seed 4711, 10 portions): never a protected guild function directly, status only after the game confirms, rank steps never above your own rank, ad without "|", nothing real sent (T273a–T273j).
  - TU5 real data read only: duplicates, alts pointing to themselves, incomplete rank history – violations go to the diagnostic log without names (T275).
  - TU6 regressions: every finding since 1 Nov has a permanent test; report "Regressions: n of m" (T276). TU8 report line per area (T279). T280 for RV7.
- Protected guild functions that would run through ns.Act are now counted as an error in the routine as well.
- No changes for players.

## 0.9.31
- New: recruitment in phases (Members > Line-up). Build-up (default for every guild): {wanted} in the ad becomes "players of all classes" – the line-up is not used. Transition: "players of all classes, especially <up to 3 gaps>". Raid: the gaps of the line-up, as before. Your own ad texts stay; {wanted} follows the phase.
- The line-up targets are never deleted, converted or overwritten; the page says "the targets above apply from phase Raid". Only the Guild Master and officers can change them, every change is logged with name and time (last 50, in the game only).
- Raid readiness for a target raid (Onyxia's Lair 40, Molten Core 40, Barrow Deeps 10, Hyjal Summit 20 and more; TBC: Karazhan 10, Gruul 25 …): active mains (level ≥ line-up minimum and online in the last 14 days; alts only with "count alts") against raid size, plus tanks and healers (from the line-up, scaled to the raid size; otherwise size/10 and size/5). Shown on Line-up, Recruitment and Overview: "Raid-ready (Onyxia's Lair): 23 of 40 active at level 55+ · Tanks 2/4 · Healers 5/10 · Phase Build-up", with an estimate from the levelling race ("at the current pace in ~x weeks", or "still measuring" with less than 7 days of data).
- From 60 % officers get the suggestion "Transition", from 100 % "Raid" (in the window and once in officer chat, said by one only) with "Confirm" / "Later". Nothing switches automatically. Back only after 7 days below the threshold of the current phase.
- Chronicle milestone "Guild is raid-ready (<raid>)", optional guild chat announcement (Settings, on by default, said by one only).
- On logout a summary without names is stored for the uploader and the Discord bot (GuildSentinelDB.raidReady).
- Developer test routine: T261–T269 (T-RP1–T-RP9) new; T244/T246 now run in phase Raid.

## 0.9.30
- New: right-click menu on members (Members list, inactive list, Who is where, Applicants, Leadership lists): Whisper, Invite to group, Promote, Demote, Set rank …, Assign alt …, Edit note, Edit officer note, Enter absence, Say thanks, Assign mentor …, Remove from guild (with confirmation), Transfer guild leadership (Guild Master only, password protected). Entries your rank may not use are shown in grey with the reason; in combat "not in combat".
- Protected guild actions are never called directly any more (lesson from the invite fix in 0.9.29): promote, demote, remove and leadership transfer – from the menu, the Guild Management window, the promotion suggestions and the bulk actions – open the new "Guild action" window. You click its button and Blizzard's own command (/gpromote, /gdemote, /gremove, /gleader) carries it out. Names with spaces work.
- Set rank: every step is its own click ("Promote – 2 steps left to Officer"), never above your own rank and never to Guild Master.
- A step counts as done only when the game confirms it (system message or new rank in the roster); without confirmation after 6 seconds: "Not carried out" and the step can be repeated. Each confirmed rank change is kept in the rank history (who, whom, from -> to, time).
- Multi-select: Shift/Ctrl-click in the member list, then right-click: promote or demote all of them – one click per member ("3 of 5 done").
- Promotion: new option "Suggest the main's rank for alts" (only a suggestion, carried out step by step).
- Leadership > Rank rights: button "Edit ranks in the game" opens Blizzard's rank window.
- Developer test routine: T254–T260 (menu by rights, no protected call, name with spaces, rank steps, confirmation, alt suggestion, multi-select) new; T64, T174, T194, T195, T213 adapted. The offline test client now rejects protected guild functions like WoW Forever.

## 0.9.29
- Fix (WoW Forever): "Invite to guild" (Recruitment > Applicants and Guild management) no longer triggers "GuildSentinel has been blocked from an action only available to the Blizzard UI". The game forbids addons to invite into the guild directly, even on a mouse click. Now "/ginvite <name>" is put into the chat input and you press Enter – Blizzard's own command sends the invite. Names with spaces work as they are.
- The applicant only shows as "invited" once the game confirms the invite ("You have invited X to join your guild."), no longer right after the click.
- Your own ad texts with {tag} but without a dash: without a tag or Discord link, "(Tag {tag})" is removed with its brackets and a sentence of its own with {tag} is removed completely; otherwise only {tag} is emptied.
- Developer test routine: T253 (invite only via the chat input, status only after the confirmation) new; T174, T194 and T251 extended.

## 0.9.28
- Recruitment page: new "Suggestion 2" button – a second ad text that names your Discord server tag ("… Discord: <link> – you'll know us by the tag XY."). The default ad text is unchanged.
- New field "Server tag" next to the Discord link and new placeholder {tag}. Without a tag or without a Discord link the tag part is left out completely.
- Tip below the Discord link: use a permanent invite (never expires, unlimited uses); whoever clicks it sees the guild's server profile before joining.
- Developer test routine: T251 (suggestion 2 with/without link and tag, DE/EN/RU) and T252 (invite tip) new.

## 0.9.27
- Russian recruitment ad: "Пишите мне" now starts with a capital letter, also when the Discord part is left out.
- Developer test routine: T250 also checks the old default text in the client's language.

## 0.9.26
- Recruitment ad without Discord: the sentence after the removed Discord part now starts with a capital letter ("… helpful. Whisper me: …").
- If you had saved the old default ad text unchanged, it is replaced once by the new default (with the new {gesucht} it would read awkwardly). Your own, different texts stay.
- Developer test routine: T249 (counter "will be shortened") and T250 new; T248 renamed.

## 0.9.25
- **New default recruitment ad**: "{gilde} ({fraktion}) is looking for {gesucht} for dungeons and raids – relaxed and helpful. Discord: {discord} – whisper me: /w {name} guild" (in every language; the German one adds "deutschsprachig"). If you saved your own ad text, it stays as it is; an empty field uses the new default.
  - New placeholder **{fraktion}** ({faction}): Horde or Alliance in the language of the game.
  - **{gesucht}** is now just the list ("Healers, Warriors and Mages"); nothing missing: "new members". If your own text used "{gesucht}" on its own, write "Wanted:" in front yourself.
  - **{discord}**: without a Discord link, the whole "Discord: … – " part disappears. Right after "Discord:" it gives only the link; anywhere else (your own texts, reply, welcome) still "Discord: <link>" as before.
- The length counter counts before shortening and turns red with "will be shortened" when the ad is longer than 251 characters.
- Developer test routine: T244–T248 new.

## 0.9.24
- Recruitment ad: a long ad no longer gets cut off by the chat input and then never counts as posted. The ad text is limited to 251 characters (room for "/<channel> "), the counter shows "(n/251)", and the text in the chat input is exactly the one that counts once it appears in the channel. Umlauts and other special characters are never cut in half.
- Developer test routine: T242–T243 new.

## 0.9.23
- **Recruitment ad no longer blocked**: WoW Forever blocks addons from writing into chat channels ("action blocked"), even from a click. The button is now "Prepare ad": it puts "/<channel> <text>" into the chat input and you send it with Enter (all game versions). The ad only counts as posted (wait times, "last posted", reminder) once your text appears in the channel.
- Group finder: a guild search can only be closed by the searcher; for "whole server" searches the searcher's name in the data is enough (they arrive passed on through the network).
- Guild profession list: the diagnostic line now says why offline members were or were not shown (already on, no function, combat, guild window open, 5-minute lock …); if the list can no longer be read on the second read, the settings are still put back.
- Developer test routine: T239–T241 new.

## 0.9.22
- **Recipes of each member**: on the Professions page, click a member to see WHICH recipes they know for that profession – with a back button, item links and tooltips, and "Request craft" for the selected recipe.
  - **Filter bar by type**, only types that occur, with counts and "All" first: Blacksmithing, Leatherworking, Tailoring by slot (Head, Chest, Hands, Weapons …), Alchemy by Healing/Mana/Rejuvenation/Protection potions, Elixirs, Flasks, Oils, Transmutes, Reagents, Engineering by Explosives, Devices, Scopes, Enchanting by target slot, Cooking/First Aid by Food and Bandages. The bar wraps when space runs out.
  - The type is worked out on your own PC from the item (slot, class) or the recipe name – nothing new has to be sent, so data from older versions works too ("Other" if unknown).
  - On WoW Forever, Blizzard's recipe category is sent along as a new optional field; older versions simply ignore it.
  - The search box also filters a member's recipes; filter and search can be combined.
- Group finder "whole server": group changes and replies to questions now go to the group only; the whisper network gets a search only when it starts and when it ends.
- Developer test routine: T231–T238 new.

## 0.9.21
- **GoldSentinelSync 2 (whisper network)**: the shared sync file now also reaches players with GoldSentinel addons outside your guild and group, by whispering through other players who have it (throttled, no chat spam; "no player named … is online" is hidden).
  - **What goes into the network**: only the group finder for the whole server (new search and closing it). Everything else stays inside the guild (professions, events, board, polls, thanks, attunements …), in the group or in a whisper to one player.
  - Group finder: "whole server" is back – your search goes to the guild, your group and the network.
  - Known players of the network are kept across /reload (GuildSentinelDB.gsSync: names, times, version only; stays on your PC).
- **GoldSentinelTest 2**: share error reports with the developer (only with your consent, /gstest).
- Diagnostic log: new line "NETZ …" (no names).
- Developer test routine: T225–T230 new.

## 0.9.20
- **Addon messages for all game versions**: GuildSentinel now uses the shared GoldSentinel sync file. It sends only through the guild, your group/raid and whispers – never through a custom chat channel (WoW Forever does not deliver addon messages there). Messages from older GuildSentinel versions of other players are still understood. Players using 0.9.19 or older will no longer receive messages from 0.9.20 – please update.
  - The custom channel "GuildSentinelLFG" is no longer joined (it is left once if you are in it) – one chat channel slot is freed.
  - Group finder: "Guild and group" replaces "whole server" – your search goes to the guild and to your current group or raid. The setting "Searches from the whole server" is gone.
  - Recruitment ads: only Blizzard channels (General, Trade, LocalDefense, LookingForGroup …) can be selected; addon and player channels are hidden.
  - "/gs sync test" shows who answers ("N replies (guild a, group b)"); the settings show the number of players with GuildSentinel in the last hour.
- **Professions**: levelling up a profession with the window open no longer sends to the guild at every skill-up (at most every 5 minutes, and when you close the window); new recipes are still sent right away. The diagnostic log is no longer filled by it.
- Guild profession list with offline members: GuildSentinel now always waits for the game before reading and switching the setting back.
- Blizzard's guild recipes: opening the guild view restarts the queries at most every 10 minutes per profession, and no recipe is asked twice a day.
- Profession data received from other players is checked in depth; broken data can no longer cause an error in tooltips or craft requests.
- Diagnostic log: lines for addon messages (ways, players, sent/received/dropped, channel refused).
- Developer test routine: T214–T224 new; test names are placeholders only.

## 0.9.19
- **Professions arrive automatically in both directions**: a member's professions could get stuck on one side. Fixed:
  - GuildSentinel now always sends your own professions itself, also when RaidMaster is installed (before, it stayed silent and relied on RaidMaster).
  - Names are matched in one way everywhere (realm suffix, upper/lower case, first name alone on WoW Forever): data is stored and shown under the name from the guild roster. Older entries under another spelling are merged once (newer data wins).
  - Every member with GuildSentinel sends their own professions 10–60 seconds after logging in when they are new or older than 24 hours – no longer only through the one member who answers the sync.
- **Fully automatic** (no option, no button, never in combat):
  - The game's guild profession list is read with offline members too (the "Show offline members" setting is switched on briefly and set back).
  - New recipes are added right away when you learn them – no need to open the profession window.
  - Recipe check without the window: recipes your guild already knows are checked with the game's spell check, only if a test check gives the right answers.
  - Blizzard's guild recipes (who in the guild knows which recipe) are queried where the game allows it, once a day per profession; otherwise they are read when you open that view yourself.
- **Professions page**: a selected profession without known data now says how many members have it ("2 guild members have Alchemy …") instead of the general hint. The "Who" column shows "1 of 4"; members known only from the game's list appear with "Recipes unknown" and can be whispered; "+2 more according to the game" below the list.
- Guild list: opening collapsed professions happens at most every 5 minutes, and the update this causes no longer starts a new read (no loop).
- Promote from the activity list and the bulk actions now use the modern game function first (like guild management).
- Diagnostic log: lines for read, sent, received, shown and filtered professions (numbers only, no player names) and a summary.
- Developer test routine: T201–T213 new.

## 0.9.18
- **Professions of all members**: the game can send its guild profession list with collapsed professions, and then GuildSentinel found no names. It now opens collapsed professions briefly, reads them and closes them again (only outside combat and while Blizzard's guild window is closed). Where the game cannot do that, the Professions page shows how many members have each profession (e.g. "2/5": 2 known to GuildSentinel, 5 according to the game).
- **Guild management**: actions and rank names now always use the right game function on every client (Classic Era, TBC Anniversary, WoW Forever). The management button moves below the guild window while Blizzard's member details or rank window are open, so it never covers them.
- Developer test routine: T190 extended (collapsed professions), new T200 (old clients without C_GuildInfo); area K also checks Blizzard's guild pop-ups.

## 0.9.17
- **New window "Guild management"** for guild leadership and officers: button "Management (GuildSentinel)" next to Blizzard's guild window (J stays as it is) and `/gs verwaltung`.
  - Invite (name or current target), promote/demote (rank before -> after, never above your own rank), remove (with confirmation).
  - Hand over guild leadership: Guild Master only, locked until the password is entered, then two confirmations.
  - Every button follows your rights in the game. The Guild Master can add characters that may open the window on this computer (local list, never sent).
  - Password: set in the game (enter twice), stored only as a salted checksum on this computer, masked input, 3 failed attempts lock it for 5 minutes, change only with the old password. It is a protection against accidental clicks – the real protection are your rights in the game.
  - Actions only from your click, never in combat; in test mode nothing is executed. Option "Management button on the guild window".

## 0.9.16
- **Professions of all members, automatically**: where the game itself knows the guild's professions (guild profession list), GuildSentinel now reads the skill levels of every member – also of members without GuildSentinel. Recipes still come only from players with GuildSentinel (or RaidMaster) who have opened their profession window once; their own data always wins over the guild list.
- **New members**: whoever joins the guild while online now shares their professions right away instead of at the next login.

## 0.9.15
- **Diagnostic log**: GuildSentinel now records problems that only happen in the real game (slow pages, blocked actions with the calling place, error loops – never player, guild or realm names). Open it with `/gs protokoll` to copy it; after a logout or /reload it is also stored for the RaidMaster uploader, which sends it to the developer.
- Developer test routine: T188 (diagnostic log) and T189 (in the game).

## 0.9.14
Fixes from the in-game test run on WoW Forever launch night:
- **Big guilds**: the Overview and Leadership pages no longer stutter with hundreds of members (main/alt lookups are now done once per page build – about 25× faster with 500 members).
- **Professions button (WoW Forever)**: no more "action blocked" message. If the profession window does not open, GuildSentinel now asks you to open it yourself once instead of calling a protected function.
- **Achievements/Chronicle**: damaged profession data no longer breaks the page.
- **Event announcement** in test mode also works for characters without a guild (only "[Test]" in your chat, nothing is sent).
- Developer test routine: new area K checks the interface in the real client (tooltips covering buttons, overlapping windows, windows off screen, cut-off texts, plausible game values, error loops); clearer results for first/last names and slow pages.

## 0.9.13
- **Language selectable for everyone**: Settings > General > "Language". On start GuildSentinel still uses the language of your game client; you can switch to German, English, French, Spanish (Spain/Mexico), Italian or Portuguese on any client (Russian, Korean and Chinese on a client in that language). GuildSentinel reloads after the change; "Same as the game client" goes back. Replaces the developer-only switch from 0.9.12.

## 0.9.12
- Developer only: under Settings > Test mode the language can be switched between German, English and the game client's language (for screenshots); GuildSentinel reloads after the change. Nothing changes for players – GuildSentinel always uses the language of the game client.

## 0.9.11
- **Bank character: stock to Discord** (optional, off by default): tick "Bank character (stock to Discord)" under Settings > General on your guild's bank character. Opening the bank, the mailbox or – where the game has one – the guild bank then reads bags, bank, mail attachments and guild bank tabs (read only, never in combat, in small steps). The RaidMaster uploader sends the stock with its next upload, and the RaidMaster bot shows it in #gildenbank and with /bank. Guilds without the RaidMaster bot notice nothing.
- **Alt notes with first and last names** (WoW Forever) on Korean and Chinese clients, where the name comes before the label ("Testa Beispiel의 부캐릭터"), are recognised again.
- **Changing the main** now removes the old alt label completely – with first and last name and in the client language ("Alt: First Last", "Reroll de …") – instead of leaving parts of it in the note.
- **Event sync**: one damaged entry no longer discards the other events of the same sync message.
- All game functions GuildSentinel needs are now chosen in one place (API.lua, modern API first, old one as fallback). Nothing changes for players.
- Developer test routine: real sends now count as an error in the report (T82), every action with consequences is checked to go through one place (T174), new cases for export, event announcements, first/last names and the bank character, and the cases that previously needed a replaced game function now run in the game too.

## 0.9.10
- **Alt notes in your client language**: notes that GuildSentinel writes itself ("Reroll de …", "… 的分身" and so on) are recognised again on French, Spanish, Italian, Portuguese, Korean and Chinese clients. Where the label would not fit into the short guild note (Russian), GuildSentinel writes the short form "Alt: Name".
- **AHSentinel** (formerly AH Analyzer Pro) is recognised under its new folder name (Addons page, market values).
- **Applicant whispers in combat** (WoW Forever): more than 30 whispers during one fight are now counted in the notice too instead of being dropped silently.
- More robust against damaged data: malformed event sync messages and broken event or thanks entries no longer cause errors.
- Test mode (developer only): no longer joins or leaves the server channel, sends nothing delayed after "Stop test mode" and leaves the real settings (last ad, free status, My week) untouched.
- New for the developer: `/gs testroutine` (button "Test everything" under Settings > Test mode) checks every feature and saves a report for the GoldSentinel review; the diagnosis shows the error counter. Nothing changes for players.

## 0.9.9
Fixes from the review:
- **Officer rights**: players who may only read officer notes no longer count as officers.
- **Applicant whispers in combat** (WoW Forever): if a message stays protected after combat, GuildSentinel reports once how many could not be read instead of losing them silently.
- **Player tooltip**: the combat lock applies to every modern client (WoW Forever, Retail).
- Absence and thanks messages from other players are only accepted when the sender matches exactly.

## 0.9.8
- Shared game-version detection (GoldSentinelGame.lua) updated to version 2: it also wins over early, withdrawn copies that other GoldSentinel addons briefly shipped, so loading several GoldSentinel addons together causes no errors. Nothing changes for players.

## 0.9.7
- Uses the shared game-version detection of all GoldSentinel addons (GoldSentinelGame.lua): Classic Era, WoW Forever and TBC are detected the same way everywhere, with the shared secret-value guard and first/last name comparison. `/gsgame` shows what was detected. Nothing changes for players.

## 0.9.5
- **WoW Forever hardening**: protection against secret values in combat (player tooltip, addon messages, cooldowns). Applicants who whisper during combat are added after combat instead of being lost.
- **First and last names** (WoW Forever): names are capitalised correctly, notes like "Alt of Testa Beispiel" are recognised, and a unique first name alone is enough for alts, thanks and mentors.
- Whispering a "First Last" name opens the whisper box for the full name.
- Modern APIs are used first (C_ChatInfo, C_GuildInfo, C_SpellBook), with the old ones as fallback.

## 0.9.4
- **Without a guild**: instead of empty pages the overview shows a hint – GuildSentinel is a guild tool, and members, events, board, polls, progress, professions, recruitment and the group finder appear once you are in a guild. My week, Addons and Settings stay available. Joining or leaving a guild takes effect right away.

## 0.9.3
- **Guild name**: the guild master can set a name for GuildSentinel under Leadership > Rank rights. It applies to everyone in the guild with the addon (ad, chronicle, rules, welcome guide, header). Empty = the name from the game. Only the guild master can change it.

## 0.9.2
- **Professions on WoW Forever**: GuildSentinel now also reads the new retail-style profession window. The game client decides the way: WoW Forever uses the new window, Classic Era and TBC the classic one as before. Linked professions, guild professions and NPC windows are not read.
- The "Open next profession" button opens the new window directly on WoW Forever if needed.

## 0.9.1
- Test mode is now developer-only: the Settings > Test mode tab and `/gs test` only appear for the developer account. Nothing else changes for players.

## 0.9.0
- **Who's free** (Group finder): one click flags you as free for dungeon, raid, quest group or PvP for 1, 2 or 4 hours. Everyone with GuildSentinel sees who is free, with level, item level and zone. Inside dungeons, raids and battlegrounds you automatically show as busy.
- After posting a group search, GuildSentinel tells you how many guild members are free for it right now.
- **Item level** with "I'll join": the searcher sees it in the replies and in chat.
- **Bulk actions** (Leadership, officers): remove inactive players by rule or promote several suggestions at once – always a checklist first, one step per click.
- **GRM import** (Leadership): alts, join dates and personal notes from Guild Roster Manager, with a preview.

## 0.8.3
- New **Support** button (PayPal link to copy) in the title bar and under Settings > General, also `/gs donate`. Opens only on click.

## 0.8.2
- Guild achievements: singular for the first weekly goal; names that are too long use a smaller font.
- Professions: old raw-material entries (e.g. Felweed as "Alchemy") are removed automatically.

## 0.8.1
- Settings > Features in three columns; probation advice follows the 40 % rule; overview counts departures like Leadership; My week markers and singulars; chronicle without duplicates; loot wishes preselect a dungeon; removing a question asks first; raw materials leave the watch list.

## 0.8.0
- All WoW client languages; Classic Era, WoW Forever and TBC Classic / Anniversary; Overview, Leadership, My week, loot wishes, questions, guild achievements, chronicle, weekly recap, welcome guide, features on/off.
