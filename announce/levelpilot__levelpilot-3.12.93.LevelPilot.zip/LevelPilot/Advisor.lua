-- LevelPilot - Assistent
-- Prueft laufend den Zustand des Charakters und gibt Hinweise:
-- Haltbarkeit, Taschenplatz, Taschen-Upgrades, Munition, Talentpunkte, Trainer,
-- moegliche Ausruestungs-Upgrades, Empfehlung bei Questbelohnungen, voller Questlog.

local _, LP = ...
local L = LP.L
local A = {}
LP:RegisterModule("Advisor", A)

A.hints = {}        -- aktive Hinweise, sortiert nach Wichtigkeit
local shown = {}    -- [schluessel] = Stufe (Toast nur bei neuem/schlimmerem Zustand)

local SEV_INFO, SEV_WARN, SEV_BAD = 1, 2, 3
A.SEV_INFO, A.SEV_WARN, A.SEV_BAD = SEV_INFO, SEV_WARN, SEV_BAD

-- weitere Pruefungen aus anderen Modulen: fn(add) wie die Pruefungen unten
A.providers = {}
function A:AddProvider(fn) self.providers[#self.providers + 1] = fn end
function A:Soon() LP:Throttle("advisor", 2, function() A:Run() end) end

------------------------------------------------------------------------
-- Hilfen
------------------------------------------------------------------------
local API = LP.API
local ContainerSlots, ContainerFree, ContainerLink = API.BagSlots, API.BagFree, API.BagLink

local function NavigateTo(entry, label)
    if not entry then return end
    local i, n, w = LP.Geo:ToWorld(entry.map, entry.x, entry.y)
    LP.Planner.priority = {
        t = "GOTO", map = entry.map, x = entry.x, y = entry.y, inst = i, n = n, w = w,
        text = label .. ": " .. (entry.name or "?"), key = "PRIO:" .. (entry.name or "") .. entry.map,
    }
    LP.Planner:Replan()
end

local function ServiceAction(kind, label)
    local v, d = LP.QuestDB:NearestService(kind)
    if not v then return nil, nil end
    local where = (v.name or "?") .. ", " .. LP.Geo:MapName(v.map) .. " (" .. LP:FormatDist(d) .. ")"
    return where, function() NavigateTo(v, label) end
end

------------------------------------------------------------------------
-- Einzelne Pruefungen
------------------------------------------------------------------------
local DUR_SLOTS = { 1, 3, 5, 6, 7, 8, 9, 10, 16, 17, 18 }

local function CheckDurability(add)
    if not LP.db.advDurability or not GetInventoryItemDurability then return end
    local minPct, broken = 100, 0
    for _, slot in ipairs(DUR_SLOTS) do
        local cur, max = GetInventoryItemDurability(slot)
        if cur and max and max > 0 then
            local pct = cur / max * 100
            if pct < minPct then minPct = pct end
            if cur == 0 then broken = broken + 1 end
        end
    end
    if minPct <= LP.db.durWarn then
        local sev = (broken > 0 or minPct <= 10) and SEV_BAD or SEV_WARN
        local where, action = ServiceAction("repair", L["Reparieren"])
        local text = broken > 0 and (broken .. L[" Teil(e) kaputt – sofort reparieren!"])
            or string.format(L["Ausrüstung bei %d%% – bald reparieren"], minPct)
        if where then text = text .. L["\nNächster Reparatur-Händler: "] .. where end
        add("dur", sev, text, action, action and L["Hinführen"])
    end
    A.durability = minPct
end

local function RecommendedBagSize(level)
    if level < 10 then return 6 end
    if level < 20 then return 8 end
    if level < 30 then return 10 end
    if level < 40 then return 12 end
    return 14
end

local function CheckBags(add)
    if not LP.db.advBags then return end
    local free, total, equipped, smallest = 0, 0, 0, nil
    for bag = 0, 4 do
        local slots = ContainerSlots(bag)
        if slots and slots > 0 then
            local f, family = ContainerFree(bag)
            if family == 0 then free = free + f end
            total = total + slots
            if bag > 0 then
                equipped = equipped + 1
                if not smallest or slots < smallest then smallest = slots end
            end
        end
    end
    A.bagFree, A.bagTotal = free, total
    if free <= LP.db.bagWarn then
        local where, action = ServiceAction("vendor", L["Verkaufen"])
        local text = (free == 0 and L["Taschen voll!"] or (L["Nur noch "] .. free .. L[" Taschenplätze frei"])) .. L[" – graue Gegenstände verkaufen"]
        if where then text = text .. L["\nNächster Händler: "] .. where end
        add("bags", free == 0 and SEV_BAD or SEV_WARN, text, action, action and L["Hinführen"])
    end
    local level = LP:PlayerLevel() or 1
    if level >= 5 and equipped < 4 then
        add("bagslots", SEV_INFO, (4 - equipped) .. L[" Taschenplatz/-plätze leer – kaufe oder lege Taschen an"])
    elseif smallest and level >= 10 and smallest < RecommendedBagSize(level) then
        add("bagsize", SEV_INFO, L["Taschen-Upgrade empfohlen: deine kleinste Tasche hat nur "] .. smallest
            .. L[" Plätze (für dein Level sind "] .. RecommendedBagSize(level) .. L["+ üblich)"])
    end
end

local function CheckAmmo(add)
    if not LP.db.advAmmo then return end
    local _, classFile = UnitClass("player")
    if classFile ~= "HUNTER" then return end
    local ranged = GetInventoryItemLink("player", 18)
    if not ranged then return end
    local _, _, _, _, _, _, _, _, equipLoc = API.ItemInfo(ranged)
    if equipLoc == "INVTYPE_THROWN" then return end
    local count = GetInventoryItemCount and GetInventoryItemCount("player", 0) or 0
    A.ammo = count
    if count <= LP.db.ammoWarn then
        local where, action = ServiceAction("vendor", L["Munition kaufen"])
        local text = (count == 0 and L["Keine Munition!"] or (L["Nur noch "] .. count .. L[" Munition"])) .. L[" – nachkaufen"]
        if where then text = text .. L["\nNächster Händler: "] .. where end
        add("ammo", count == 0 and SEV_BAD or SEV_WARN, text, action, action and L["Hinführen"])
    end
end

-- 3.12.43 LP-N1 Punkt 1: naechster Punkt des eigenen Level-Builds (Data/TalentBuilds.lua).
-- 3.12.88 EULA: die Liste kennt nur Talent-NAMEN (de/en); die Lage im Baum sucht LevelPilot hier zur Laufzeit über GetTalentInfo.
-- Liefert Name, angestrebter Rang, Hoechstrang, Begruendung – oder nil und einen Grund ("sprache" = Client weder deutsch noch
-- englisch, "offen" = der naechste Eintrag hat in dieser Sprache noch keinen sicheren Namen bzw. steht nicht im Talentbaum).
function A.TalentLang()
    local loc = GetLocale and GetLocale() or "enUS"
    if loc == "deDE" then return "de" end
    if loc == "enUS" or loc == "enGB" then return "en" end
    return nil
end
function A:TalentNext()
    local list = LP.TalentBuilds and LP.TalentBuilds[select(2, UnitClass("player"))]
    if not (list and GetTalentInfo and GetNumTalents) then return nil end
    local lang = A.TalentLang()
    if not lang then return nil, nil, nil, nil, "sprache" end
    local S = LP.SafeValue
    -- alle Talente der eigenen Klasse einmal je Aufruf nach Namen (Sprache des Clients)
    local byName = {}
    local tabs = (GetNumTalentTabs and S(GetNumTalentTabs())) or 3
    for tab = 1, tabs or 3 do
        for i = 1, (S(GetNumTalents(tab)) or 0) do
            local name, _, _, _, rank, maxRank = GetTalentInfo(tab, i)
            if type(name) == "string" and name ~= "" and not byName[name] then byName[name] = { rank or 0, maxRank } end
        end
    end
    local want = {}
    for _, e in ipairs(list) do
        local name = not e.offen and e[lang] or nil
        local t = name and byName[name]
        if not t then return nil, nil, nil, nil, "offen" end
        want[name] = (want[name] or 0) + (e.r or 0)
        if t[1] < want[name] then return name, t[1] + 1, t[2], lang == "de" and e[1] or e[2] end
    end
    return nil
end

local function CheckTalents(add)
    if not LP.db.advTalents then return end
    local points = API.TalentPoints()
    if points and points > 0 then
        local text = points .. L[" Talentpunkt(e) frei – Talente verteilen (Taste N)"]
        local ok, name, rank, maxRank, why, grund = pcall(A.TalentNext, A)
        if ok and name then
            text = text .. "\n" .. L("Vorschlag (Level-Build von LevelPilot): %s %d/%d – %s", name, rank, maxRank or rank, why or "")
            if LP.Pruefliste then LP.Pruefliste:Hit("T305", ("Vorschlag %d/%d"):format(rank or 0, maxRank or rank or 0)) end   -- Prüfliste
        elseif ok and grund == "sprache" then
            text = text .. "\n" .. L["Talentvorschläge gibt es nur auf Deutsch und Englisch."]
        elseif ok and grund == "offen" then
            text = text .. "\n" .. L["Ab hier noch kein Vorschlag: der Name des nächsten Talents ist noch nicht bestätigt."]
        end
        add("talents", SEV_INFO, text)
    end
end

local function CheckTrainer(add)
    if not LP.db.advTrainer then return end
    local level = LP:PlayerLevel() or 1
    if level >= 2 and level % 2 == 0 and (LP.char.trainerLevel or 0) < level then
        add("trainer", SEV_INFO, L["Neue Fähigkeiten beim Klassentrainer verfügbar (Level "] .. level .. ")")
    end
end

-- 3.12.39 LP-N1: Pause ausserhalb von Gasthaus/Hauptstadt. Erholt-Bonus waechst nur dort (online) bzw. dort 4x so schnell
-- (offline); Erholt verdoppelt die EP fuer Monster. Hinweis nur, solange der Spieler "AFK" ist und nicht ausruht.
local function CheckRested(add)
    if not LP.db.advRested then return end
    local S = LP.SafeValue
    local level, maxLevel = LP:PlayerLevel() or 1, (GetMaxPlayerLevel and S(GetMaxPlayerLevel())) or 60
    if level >= (maxLevel or 60) then return end
    if not (UnitIsAFK and S(UnitIsAFK("player"))) then return end
    if IsResting and S(IsResting()) then return end
    if InCombatLockdown and InCombatLockdown() then return end
    local where, action = ServiceAction("inn", L["Gasthaus"])
    add("rested", SEV_INFO, L["Pause? Im Gasthaus oder in einer Hauptstadt ausloggen: dort wächst der Erholt-Bonus 4× so schnell (doppelte EP für Monster)."]
        .. (where and ("\n" .. where) or ""), action, action and L["Hinführen"])
    if LP.Pruefliste then LP.Pruefliste:Hit("T300", action and "mit Knopf Hinführen" or "ohne Gasthaus in der Nähe") end   -- Prüfliste
end

-- 3.12.39 LP-N1: Waffenfertigkeit der angelegten Waffe weit unter dem Hoechstwert (neue Waffe aus Quest/Handel):
-- niedrige Fertigkeit = mehr Fehlschlaege. Nur wenn der Name der Fertigkeit genau der Waffenart der Waffe entspricht.
A.WEAPON_GAP = 25
local function CheckWeaponSkill(add)
    if not LP.db.advWeapon then return end
    if not (GetNumSkillLines and GetSkillLineInfo and GetInventoryItemLink and GetItemInfo) then return end
    local S = LP.SafeValue
    local want = {}
    for _, slot in ipairs({ 16, 18 }) do
        local link = S(GetInventoryItemLink("player", slot))
        local sub = link and select(7, GetItemInfo(link))
        if type(sub) == "string" and sub ~= "" then want[sub] = true end
    end
    if not next(want) then return end
    for i = 1, (S(GetNumSkillLines()) or 0) do
        local name, isHeader, _, rank, _, _, maxRank = GetSkillLineInfo(i)
        if not isHeader and name and want[name] and rank and maxRank and maxRank > 1 and maxRank - rank >= A.WEAPON_GAP then
            add("weaponskill", SEV_INFO, L("Waffenfertigkeit %s: %d von %d – du verfehlst öfter. Mit dieser Waffe an leichteren Gegnern üben.",
                name, rank, maxRank))
            if LP.Pruefliste then LP.Pruefliste:Hit("T301", ("%d von %d"):format(rank, maxRank)) end   -- Prüfliste
            return
        end
    end
end

-- 3.12.40 LP-N1 4b: Waffenart noch nicht gelernt -> Waffenmeister. Waffenart = Unterklasse der Waffe (Klasse 2):
-- 0 Einhandaexte, 1 Zweihandaexte, 2 Bogen, 3 Schusswaffen, 4 Einhandstreitkolben, 5 Zweihandstreitkolben, 6 Stangenwaffen,
-- 7 Einhandschwerter, 8 Zweihandschwerter, 10 Staebe, 13 Faustwaffen, 15 Dolche, 16 Wurfwaffen, 18 Armbrueste.
-- Wer was lehrt und welche Klasse was lernen darf: warcrafttavern.com/forever/guides/weapon-trainers (WoW Forever, u. a.
-- Schurke Einhandaexte, Druide Stangenwaffen) und blizzardwatch.com (06.10.2026); Orte aus dem Datenpaket (NPC-IDs).
A.WEAPON_MASTERS = {
    [2704]  = { [2] = true, [0] = true, [10] = true, [16] = true, [1] = true },                                 -- Hanashi, Orgrimmar
    [11868] = { [2] = true, [15] = true, [13] = true, [0] = true, [10] = true, [16] = true, [1] = true },        -- Sayoc, Orgrimmar
    [11869] = { [3] = true, [4] = true, [10] = true, [5] = true },                                              -- Ansekhwa, Donnerfels
    [11870] = { [18] = true, [15] = true, [7] = true, [6] = true, [8] = true },                                 -- Archibald, Unterstadt
    [11867] = { [18] = true, [15] = true, [7] = true, [6] = true, [10] = true, [8] = true },                    -- Woo Ping, Sturmwind
    [11865] = { [13] = true, [3] = true, [0] = true, [4] = true, [1] = true, [5] = true },                      -- Buliwyf, Eisenschmiede
    [13084] = { [18] = true, [15] = true, [16] = true },                                                        -- Bixi, Eisenschmiede
    [11866] = { [2] = true, [15] = true, [13] = true, [10] = true, [16] = true },                               -- Ilyenia, Darnassus
}
local function Set(list) local t = {} for _, v in ipairs(list) do t[v] = true end return t end
A.CLASS_WEAPONS = {
    WARRIOR = Set({ 2, 18, 15, 13, 3, 0, 4, 7, 6, 10, 16, 1, 5, 8 }),
    PALADIN = Set({ 0, 4, 7, 6, 1, 5, 8 }),
    HUNTER  = Set({ 2, 18, 15, 13, 3, 0, 7, 6, 10, 16, 1, 8 }),
    ROGUE   = Set({ 2, 18, 15, 13, 3, 0, 4, 7, 16 }),
    PRIEST  = Set({ 15, 4, 10 }),
    SHAMAN  = Set({ 15, 13, 0, 4, 10, 1, 5 }),
    MAGE    = Set({ 15, 7, 10 }),
    WARLOCK = Set({ 15, 7, 10 }),
    DRUID   = Set({ 15, 13, 4, 6, 10, 5 }),
}
local function CheckWeaponMaster(add)
    if not LP.db.advWeapon then return end
    if not (GetNumSkillLines and GetSkillLineInfo and GetItemSubClassInfo) then return end
    if InCombatLockdown and InCombatLockdown() then return end
    local S = LP.SafeValue
    local info = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
    local class = select(2, UnitClass("player"))
    local allowed = A.CLASS_WEAPONS[class]
    if not (info and allowed) then return end
    local known = {}
    for i = 1, (S(GetNumSkillLines()) or 0) do
        local name, isHeader = GetSkillLineInfo(i)
        if name and not isHeader then known[name] = true end
    end
    -- Abgleich: Heissen Fertigkeit und Waffenart in dieser Sprache gleich? Belegt nur, wenn die Waffenart der angelegten
    -- Waffe als Fertigkeit vorkommt. Sonst still (nie ein falscher Hinweis "nicht gelernt").
    local mh = GetInventoryItemLink and S(GetInventoryItemLink("player", 16))
    local mhClass, mhSub = nil, nil
    if mh then mhClass, mhSub = select(6, info(mh)), select(7, info(mh)) end
    local mhName = mhClass == 2 and mhSub and GetItemSubClassInfo(2, mhSub)
    if not (mhName and known[mhName]) then return end
    local level = LP:PlayerLevel() or 1
    for bag = 0, 4 do
        for slot = 1, (API.BagSlots(bag) or 0) do
            local it = API.BagItem(bag, slot)
            if it and it.id and (it.quality or 0) >= 2 then
                local classID, sub = select(6, info(it.id)), select(7, info(it.id))
                local typeName = classID == 2 and sub and allowed[sub] and GetItemSubClassInfo(2, sub)
                if typeName and not known[typeName] and (sub ~= 6 or level >= 20) then
                    local teaches = function(x) return x.id and A.WEAPON_MASTERS[x.id] and A.WEAPON_MASTERS[x.id][sub] end
                    local v, d = LP.QuestDB:NearestService("trainer", teaches)
                    local where
                    if v then
                        where = (v.name or "?") .. ", " .. LP.Geo:MapName(v.map) .. " (" .. LP:FormatDist(d) .. ")"
                    else
                        -- auf einem anderen Kontinent: ersten passenden Waffenmeister der eigenen Fraktion nennen (ohne Weg)
                        for _, x in ipairs(LP.QuestDB:ServiceNPCs().trainer or {}) do
                            if teaches(x) then where = (x.name or "?") .. ", " .. LP.Geo:MapName(x.map) break end
                        end
                    end
                    where = where or L["Waffenmeister in einer Hauptstadt"]
                    local cost = sub == 6 and L["etwa 1 Gold"] or L["etwa 10 Silber"]
                    add("weaponmaster", SEV_INFO, L("%s in deiner Tasche: Waffenart „%s“ noch nicht gelernt. Lernen beim Waffenmeister (%s): %s",
                        it.link or "?", typeName, cost, where), v and function() NavigateTo(v, L["Waffenmeister"]) end, v and L["Hinführen"])
                    if LP.Pruefliste then LP.Pruefliste:Hit("T302", ("Waffenart %d, %s"):format(sub, v and "mit Weg" or "ohne Weg")) end   -- Prüfliste
                    return
                end
            end
        end
    end
end

A.CheckRested, A.CheckWeaponSkill, A.CheckWeaponMaster = CheckRested, CheckWeaponSkill, CheckWeaponMaster     -- Testroutine (T300–T302)
A.CheckTalents = CheckTalents                                                                     -- Testroutine (T309)

local function CheckQuestLog(add)
    -- Dungeon-Quests, deren Zeit vorbei ist (grau oder Dungeon nicht betretbar)
    local level = LP:PlayerLevel() or 1
    for _, q in ipairs(API.Quests()) do
        local area = not q.complete and LP.QuestDB:QuestDungeon(q.id)
        if area then
            local info = LP.QuestDB:Get(q.id)
            local ql = info and info.level or 0
            local grey = ql > 0 and ql < level - API.GreenRange(level)
            if grey or not LP.Planner:DungeonUsable(area) or LP.Planner.dungeonDead[q.id] then
                local d = LP.QuestDB:Dungeon(area)
                add("dgq" .. q.id, SEV_INFO, L["Dungeon-Quest \""] .. (q.title or "?") .. "\" (" .. (d and d.name or L["Dungeon"])
                    .. L[") lohnt sich nicht mehr – im Questlog abbrechen, um Platz zu schaffen"])
            end
        end
    end
    local n, max = API.QuestCount(), API.MaxQuests()
    if n >= max - 2 then
        add("questlog", n >= max and SEV_WARN or SEV_INFO, L["Questlog fast voll ("] .. n .. "/" .. max .. L[") – graue oder liegengebliebene Quests abbrechen"])
    end
end

------------------------------------------------------------------------
-- Ausruestungs-Upgrades
------------------------------------------------------------------------
local SLOT_OF = {
    INVTYPE_HEAD = { 1 }, INVTYPE_NECK = { 2 }, INVTYPE_SHOULDER = { 3 }, INVTYPE_CHEST = { 5 },
    INVTYPE_ROBE = { 5 }, INVTYPE_WAIST = { 6 }, INVTYPE_LEGS = { 7 }, INVTYPE_FEET = { 8 },
    INVTYPE_WRIST = { 9 }, INVTYPE_HAND = { 10 }, INVTYPE_FINGER = { 11, 12 }, INVTYPE_TRINKET = { 13, 14 },
    INVTYPE_CLOAK = { 15 }, INVTYPE_WEAPON = { 16, 17 }, INVTYPE_2HWEAPON = { 16 }, INVTYPE_WEAPONMAINHAND = { 16 },
    INVTYPE_WEAPONOFFHAND = { 17 }, INVTYPE_SHIELD = { 17 }, INVTYPE_HOLDABLE = { 17 },
    INVTYPE_RANGED = { 18 }, INVTYPE_RANGEDRIGHT = { 18 }, INVTYPE_THROWN = { 18 }, INVTYPE_RELIC = { 18 },
}

-- Ruestungsklassen: 1 Stoff, 2 Leder, 3 Schwere Ruestung, 4 Platte, 6 Schild
local ARMOR = {
    WARRIOR = { 1, 2, 3, 6, plate = 40 }, PALADIN = { 1, 2, 3, 6, plate = 40 },
    HUNTER = { 1, 2, mail = 40 }, SHAMAN = { 1, 2, 6, mail = 40 },
    ROGUE = { 1, 2 }, DRUID = { 1, 2 }, PRIEST = { 1 }, MAGE = { 1 }, WARLOCK = { 1 },
}

local function CanWearArmor(subclass)
    local _, classFile = UnitClass("player")
    local level = LP:PlayerLevel() or 1
    local a = ARMOR[classFile]
    if not a then return true end
    if subclass == 0 then return true end           -- Verschiedenes (Schmuck, Umhang)
    for _, s in ipairs(a) do if s == subclass then return true end end
    if subclass == 4 and a.plate and level >= a.plate then return true end
    if subclass == 3 and a.mail and level >= a.mail then return true end
    return false
end

-- Wertgewichte je Klasse (Leveln): was der Klasse etwas bringt. Intelligenz fuer Krieger = 0,
-- Staerke fuer Magier = 0 usw. Ruestung und Waffen-DPS gehen mit ein.
local W = {
    WARRIOR = { STR = 1.0, AGI = 0.6, STA = 0.8, INT = 0,   SPI = 0.05, AP = 0.5, ARMOR = 0.025, DPS = 2.2 },
    PALADIN = { STR = 1.0, AGI = 0.4, STA = 0.8, INT = 0.5, SPI = 0.2,  AP = 0.5, ARMOR = 0.02, DPS = 2.0, SP = 0.3, HEAL = 0.2 },
    HUNTER  = { STR = 0.2, AGI = 1.0, STA = 0.6, INT = 0.3, SPI = 0.1,  AP = 0.3, RAP = 0.5, ARMOR = 0.015, DPS = 0.6, RDPS = 2.4 },
    ROGUE   = { STR = 0.5, AGI = 1.0, STA = 0.6, INT = 0,   SPI = 0,    AP = 0.5, ARMOR = 0.015, DPS = 2.4 },
    PRIEST  = { STR = 0,   AGI = 0,   STA = 0.5, INT = 1.0, SPI = 0.9,  SP = 0.9, HEAL = 0.5, MP5 = 1.5, ARMOR = 0.005, WDPS = 1.2 },
    SHAMAN  = { STR = 0.6, AGI = 0.4, STA = 0.6, INT = 0.8, SPI = 0.3,  AP = 0.4, SP = 0.6, MP5 = 1.0, ARMOR = 0.015, DPS = 1.8 },
    MAGE    = { STR = 0,   AGI = 0,   STA = 0.5, INT = 1.0, SPI = 0.6,  SP = 1.0, MP5 = 1.2, ARMOR = 0.005, WDPS = 1.2 },
    WARLOCK = { STR = 0,   AGI = 0,   STA = 0.9, INT = 0.8, SPI = 0.6,  SP = 1.0, MP5 = 1.0, ARMOR = 0.005, WDPS = 1.2 },
    DRUID   = { STR = 0.6, AGI = 0.6, STA = 0.6, INT = 0.7, SPI = 0.4,  AP = 0.4, SP = 0.5, HEAL = 0.3, MP5 = 1.0, ARMOR = 0.015, DPS = 1.0 },
}
local STATKEY = {
    ITEM_MOD_STRENGTH_SHORT = "STR", ITEM_MOD_AGILITY_SHORT = "AGI", ITEM_MOD_STAMINA_SHORT = "STA",
    ITEM_MOD_INTELLECT_SHORT = "INT", ITEM_MOD_SPIRIT_SHORT = "SPI", RESISTANCE0_NAME = "ARMOR",
    ITEM_MOD_ATTACK_POWER_SHORT = "AP", ITEM_MOD_RANGED_ATTACK_POWER_SHORT = "RAP",
    ITEM_MOD_SPELL_POWER_SHORT = "SP", ITEM_MOD_SPELL_DAMAGE_DONE_SHORT = "SP", ITEM_MOD_SPELL_HEALING_DONE_SHORT = "HEAL",
    ITEM_MOD_HEALING_DONE_SHORT = "HEAL", ITEM_MOD_MANA_REGENERATION_SHORT = "MP5", ITEM_MOD_POWER_REGEN0_SHORT = "MP5",
    ITEM_MOD_DAMAGE_PER_SECOND_SHORT = "DPS",
}
A.WEIGHTS = W

-- Haupt-Ruestungstyp je Klasse (1 Stoff, 2 Leder, 3 Schwere Ruestung, 4 Platte); ab Level 40 hoeher
local MAIN_ARMOR = { WARRIOR = { 3, 4 }, PALADIN = { 3, 4 }, HUNTER = { 2, 3 }, SHAMAN = { 2, 3 },
                     ROGUE = { 2, 2 }, DRUID = { 2, 2 }, PRIEST = { 1, 1 }, MAGE = { 1, 1 }, WARLOCK = { 1, 1 } }
local LOWER_ARMOR = 0.7       -- leichtere Ruestung als der Haupttyp zaehlt weniger
local MIN_GAIN = 2            -- so viel besser muss ein Upgrade mindestens sein

-- Wertung eines Gegenstands fuer die eigene Klasse; liefert Wertung, Werte-Tabelle
function A:ItemScore(link, slot)
    local _, classFile = UnitClass("player")
    local w = W[classFile] or W.WARRIOR
    local stats = API.ItemStats(link)
    if not stats then return nil end
    local score, vals = 0, {}
    for key, v in pairs(stats) do
        local k = STATKEY[key]
        if k and type(v) == "number" then
            vals[k] = (vals[k] or 0) + v
            local weight
            if k == "DPS" then
                if slot == 18 then weight = w.RDPS or w.WDPS or 0.3 else weight = w.DPS or 0.3 end
            else
                weight = w[k] or 0
            end
            score = score + v * weight
        end
    end
    local _, _, _, _, _, _, _, _, equipLoc, _, _, classID, subclassID = API.ItemInfo(link)
    local main = MAIN_ARMOR[classFile]
    if main and classID == 4 and subclassID and subclassID >= 1 and subclassID <= 4 and equipLoc ~= "INVTYPE_CLOAK" then
        local want = (LP:PlayerLevel() or 1) >= 40 and main[2] or main[1]
        if subclassID < want then score = score * LOWER_ARMOR end
    end
    return score, vals
end

local SHOW = { "STR", "AGI", "STA", "INT", "SPI" }
local SHOWNAME = { STR = "ITEM_MOD_STRENGTH_SHORT", AGI = "ITEM_MOD_AGILITY_SHORT", STA = "ITEM_MOD_STAMINA_SHORT",
                   INT = "ITEM_MOD_INTELLECT_SHORT", SPI = "ITEM_MOD_SPIRIT_SHORT" }

-- Bewertung eines Gegenstands fuer den Spieler: Verbesserung der Klassen-Wertung (oder nil, Grund)
function A:UpgradeValue(link)
    if not link then return nil end
    local _, _, quality, ilvl, reqLevel, _, _, _, equipLoc, _, _, classID, subclassID = API.ItemInfo(link)
    if not ilvl or not equipLoc or not SLOT_OF[equipLoc] then return nil end
    if (reqLevel or 0) > (LP:PlayerLevel() or 1) then return nil, "level" end
    if classID == 4 and not CanWearArmor(subclassID) then return nil, "armor" end
    local usable, why = API.CanUseItem(link)
    if not usable then return nil, why end
    -- schlechtester belegter Platz (bei Ringen/Schmuck/Einhand den schwaecheren ersetzen)
    local worst, worstScore, worstIlvl
    for _, slot in ipairs(SLOT_OF[equipLoc]) do
        local cur = GetInventoryItemLink("player", slot)
        local sc, il = 0, 0
        if cur then
            sc = self:ItemScore(cur, slot) or 0
            il = select(4, API.ItemInfo(cur)) or 0
        end
        if not worstScore or sc < worstScore then worst, worstScore, worstIlvl = slot, sc, il end
    end
    local newScore, vals = self:ItemScore(link, worst)
    if not newScore then
        -- keine Werte bekannt (noch nicht im Zwischenspeicher): nur Itemlevel
        local delta = ilvl - (worstIlvl or 0)
        return delta >= 3 and delta or nil, nil, ilvl, worstIlvl, classID
    end
    -- nur, was der Klasse etwas bringt: deutlich bessere Wertung
    local gain = newScore - (worstScore or 0)
    if gain < math.max(MIN_GAIN, (worstScore or 0) * 0.05) then return nil, "worse" end
    return gain, vals, ilvl, worstIlvl, classID
end

function A:StatSummary(vals)
    if not vals then return "" end
    local parts = {}
    local _, classFile = UnitClass("player")
    local w = W[classFile] or W.WARRIOR
    for _, k in ipairs(SHOW) do
        if vals[k] and vals[k] ~= 0 and (w[k] or 0) > 0 then
            parts[#parts + 1] = "+" .. vals[k] .. " " .. (_G[SHOWNAME[k]] or k)
        end
    end
    if vals.DPS then parts[#parts + 1] = string.format("%.1f DPS", vals.DPS) end
    return table.concat(parts, ", ")
end

-- Gegenstaende, die beim Einloggen schon in der Tasche liegen, werden nie als Upgrade vorgeschlagen
-- (man hat sie meist absichtlich dabei); nur, was danach dazukommt (Beute, Kauf, Post)
local LOGIN_WINDOW = 20        -- Sekunden nach dem Einloggen: alles in der Tasche gilt als "schon da"
local atLogin, loginT = {}, nil
local function SnapshotBags()
    for bag = 0, 4 do
        for slot = 1, (ContainerSlots(bag) or 0) do
            local link = ContainerLink(bag, slot)
            if link then atLogin[link] = true end
        end
    end
end
A.SnapshotBags = SnapshotBags
function A:ResetLogin() wipe(atLogin) loginT = GetTime() end

local function CheckUpgrades(add)
    if not LP.db.advUpgrades then return end
    if not loginT then loginT = GetTime() end
    if GetTime() - loginT <= LOGIN_WINDOW then SnapshotBags() end
    for bag = 0, 4 do
        for slot = 1, (ContainerSlots(bag) or 0) do
            local link = ContainerLink(bag, slot)
            if link and not atLogin[link] and API.IsEquippable(link) then
                local gain, vals = A:UpgradeValue(link)
                if gain then
                    local sum = A:StatSummary(vals)
                    add("up:" .. link, SEV_INFO,
                        L["Mögliches Upgrade für deine Klasse: "] .. link .. (sum ~= "" and ("\n" .. sum) or ""),
                        function()
                            if InCombatLockdown and InCombatLockdown() then
                                LP:Reply(L["Im Kampf nicht möglich."])
                                return
                            end
                            LP.Act.Call("Equip", API.Equip, link)
                        end, L["Anlegen"])
                end
            end
        end
    end
end

------------------------------------------------------------------------
-- 3.12.42 LP-N1 2 Schritt 1: Upgrades im Haendlerfenster markieren (gruener Pfeil an der Ware). Gleiche Bewertung wie
-- "Moegliches Upgrade" (A:UpgradeValue: Klassen-Gewichte, Ruestungstyp, Level, benutzbar). Nur markieren, nichts kaufen.
------------------------------------------------------------------------
A.MERCHANT_ICON = "Interface\\Icons\\Spell_ChargePositive"     -- Plus-Zeichen (schon im Guide benutzt, im Client vorhanden)
function A.MerchantButton(i) return _G["MerchantItem" .. i .. "ItemButton"] end
-- Waren-Nummern (1..Anzahl) mit Upgrade
function A:MerchantUpgrades()
    local out = {}
    for i = 1, (API.MerchantCount() or 0) do
        local link = API.MerchantLink(i)
        if link and API.IsEquippable(link) and self:UpgradeValue(link) then out[i] = true end
    end
    return out
end
function A:MarkMerchant()
    local frame = MerchantFrame
    local on = LP.db.advUpgrades and frame and frame.IsShown and frame:IsShown() and (frame.selectedTab or 1) == 1
    local per = MERCHANT_ITEMS_PER_PAGE or 10
    local ups = on and self:MerchantUpgrades() or {}
    local page = frame and frame.page or 1
    local n = 0
    for i = 1, per do
        local btn = A.MerchantButton(i)
        if btn then
            local mark = btn.lpUpgrade
            local want = on and ups[(page - 1) * per + i] or false
            if want and not mark and btn.CreateTexture then
                mark = btn:CreateTexture(nil, "OVERLAY")
                mark:SetTexture(A.MERCHANT_ICON)
                mark:SetSize(18, 18)
                mark:SetPoint("TOPLEFT", btn, "TOPLEFT", -4, 4)
                btn.lpUpgrade = mark
            end
            if mark then if want then mark:Show() else mark:Hide() end end
            if want then n = n + 1 end
        end
    end
    A.merchantMarked = n
    if n > 0 and LP.Pruefliste then LP.Pruefliste:Hit("T304", ("%d Plus auf Seite %d"):format(n, page)) end   -- Prüfliste
    return n
end

------------------------------------------------------------------------
-- Questbelohnung empfehlen
------------------------------------------------------------------------
function A:RecommendReward()
    local n = GetNumQuestChoices()
    if n <= 1 then return end
    local best, bestScore, reason
    for i = 1, n do
        local link = GetQuestItemLink("choice", i)
        if link then
            local gain, vals = self:UpgradeValue(link)
            local sell = select(11, API.ItemInfo(link)) or 0
            local score, why
            if gain and gain > 0 then
                score = 100000 + gain * 1000 + sell
                local sum = self:StatSummary(vals)
                why = L["Upgrade für deine Klasse"] .. (sum ~= "" and (" (" .. sum .. ")") or "")
            else
                -- nichts Passendes: was sich am besten verkaufen laesst
                score = sell
                why = L["höchster Verkaufswert"]
            end
            if not bestScore or score > bestScore then best, bestScore, reason = i, score, why end
        end
    end
    if best then
        local link = GetQuestItemLink("choice", best)
        LP:Print(L["Belohnungs-Empfehlung: "] .. (link or "?") .. " – " .. reason)
        if LP.UI and LP.UI.Toast then
            LP.UI:Toast({ key = "reward", sev = SEV_INFO, text = L["Belohnung: "] .. (link or "?") .. "\n" .. reason })
        end
    end
end

-- einzelne Pruefungen (nur Testroutine)
A.Checks = { Durability = CheckDurability, Bags = CheckBags, Ammo = CheckAmmo, Talents = CheckTalents,
             Trainer = CheckTrainer, QuestLog = CheckQuestLog, Upgrades = CheckUpgrades }

------------------------------------------------------------------------
-- Gesamtpruefung
------------------------------------------------------------------------
function A:Run()
    -- 3.12.31 ML1: "Meldungen" aus -> keine Hinweise des Assistenten, keine Toasts
    if not LP:MessagesOn() then
        if #(self.hints or {}) > 0 then LP.msgStats.suppressed = LP.msgStats.suppressed + #self.hints end
        self.hints = {}
        LP:Fire("HINTS_CHANGED")
        return
    end
    local list = {}
    local function add(key, sev, text, action, actionLabel, action2, action2Label)
        list[#list + 1] = { key = key, sev = sev, text = text, action = action, actionLabel = actionLabel,
                            action2 = action2, action2Label = action2Label }
    end
    CheckDurability(add)
    CheckBags(add)
    CheckAmmo(add)
    CheckTalents(add)
    CheckTrainer(add)
    CheckQuestLog(add)
    CheckUpgrades(add)
    CheckRested(add)
    CheckWeaponSkill(add)
    CheckWeaponMaster(add)
    for _, fn in ipairs(self.providers) do
        local ok, err = pcall(fn, add)
        if not ok then LP:Debug("Hinweis-Pruefung: " .. tostring(err)) end
    end
    table.sort(list, function(a, b) return a.sev > b.sev end)
    self.hints = list

    -- Toast nur fuer neue oder schlimmer gewordene Hinweise
    local active = {}
    for _, h in ipairs(list) do
        active[h.key] = true
        if (shown[h.key] or 0) < h.sev then
            shown[h.key] = h.sev
            if LP.UI and LP.UI.Toast then LP.UI:Toast(h) end
        end
    end
    for k in pairs(shown) do if not active[k] then shown[k] = nil end end
    LP:Fire("HINTS_CHANGED")
end

function A:Init()
    local function soon() LP:Throttle("advisor", 2, function() A:Run() end) end
    for _, ev in ipairs({ "UPDATE_INVENTORY_DURABILITY", "BAG_UPDATE_DELAYED", "PLAYER_LEVEL_UP",
                          "CHARACTER_POINTS_CHANGED", "PLAYER_EQUIPMENT_CHANGED", "QUEST_LOG_UPDATE",
                          "UNIT_INVENTORY_CHANGED", "MERCHANT_CLOSED",
                          "PLAYER_FLAGS_CHANGED", "PLAYER_UPDATE_RESTING", "SKILL_LINES_CHANGED" }) do      -- 3.12.39 LP-N1
        LP:On(ev, soon)
    end
    LP:On("TRAINER_SHOW", function()
        LP.char.trainerLevel = LP:PlayerLevel() or 0
        soon()
    end)
    -- 3.12.42: Upgrades beim Haendler markieren (Seitenwechsel: Blizzard-Funktion nachher, falls vorhanden)
    local function mark() LP:Throttle("merchmark", 0.2, function() A:MarkMerchant() end) end
    for _, ev in ipairs({ "MERCHANT_SHOW", "MERCHANT_UPDATE", "GET_ITEM_INFO_RECEIVED", "MERCHANT_CLOSED" }) do LP:On(ev, mark) end
    if hooksecurefunc and type(_G.MerchantFrame_UpdateMerchantInfo) == "function" then
        pcall(hooksecurefunc, "MerchantFrame_UpdateMerchantInfo", mark)
    end
    LP:On("MERCHANT_SHOW", function()
        -- am Haendler: Navigationsziel "Reparieren/Verkaufen" ist erreicht
        local p = LP.Planner.priority
        if p and p.key and p.key:find("^PRIO:") then
            LP.Planner.priority = nil
            LP.Planner:Replan()
        end
    end)
    -- Einloggen / Neuladen: Tascheninhalt merken (wird nicht vorgeschlagen)
    LP:On("PLAYER_ENTERING_WORLD", function(_, isLogin, isReload)
        if isLogin or isReload then
            A:ResetLogin()
            C_Timer.After(3, SnapshotBags)
        end
    end)
    C_Timer.After(5, function() A:Run() end)
    LP:Ticker("advisor", 30, function() A:Run() end)
end
