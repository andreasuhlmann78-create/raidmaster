-- LevelPilot - Navigation
-- Weg zum aktuellen Schritt (ueber das Wegenetz), Pfeil der den Wegpunkten folgt,
-- Pfadlinie auf Minikarte und Weltkarte, Schritt-Marker auf der Weltkarte.
-- Hinweis: Addons koennen nicht in die 3D-Spielwelt zeichnen; der Pfeil auf dem
-- Bildschirm und die Linie auf der Minikarte sind die Live-Fuehrung im Spiel.

local _, LP = ...
local L = LP.L
local N = {}
LP:RegisterModule("Nav", N)

local C = LP.colors
local path, pathKind, pathIdx = nil, nil, 2
local pathTarget, lastCalc, lastPos = nil, 0, nil
local WAYPOINT_REACH = 14
local RECALC_SECS = 2.5
local OFF_MIN = 0.5           -- Sekunden: Mindestpause zwischen zwei Berechnungen, auch abseits des Weges
local OFFPATH = 45

------------------------------------------------------------------------
-- Ziel & Pfad
------------------------------------------------------------------------
local function TargetOf(step)
    if not step or step.noNav then return nil end
    if step.inst then return step end
    if step.map and step.x then
        local i, n, w = LP.Geo:ToWorld(step.map, step.x, step.y)
        if i then step.inst, step.n, step.w = i, n, w return step end
    end
    return nil
end

local function DistToSegment(pn, pw, a, b)
    local dn, dw = b[2] - a[2], b[3] - a[3]
    local len2 = dn * dn + dw * dw
    local t = len2 > 0 and ((pn - a[2]) * dn + (pw - a[3]) * dw) / len2 or 0
    t = math.max(0, math.min(1, t))
    return math.sqrt((pn - (a[2] + t * dn)) ^ 2 + (pw - (a[3] + t * dw)) ^ 2)
end

-- Ersatzziele (z.B. Leiche nach dem Tod, naechster Fundort eines Questgegenstands):
-- Module tragen eine Funktion ein, die { inst, n, w, map, key, label } oder nil liefert.
-- Die Liste ist nach Vorrang sortiert (erste mit Ergebnis gewinnt).
N.overrides = {}
function N:AddOverride(fn, prio)
    self.overrides[#self.overrides + 1] = { fn = fn, prio = prio or 0 }
    table.sort(self.overrides, function(a, b) return a.prio > b.prio end)
end
local function Override()
    for _, o in ipairs(N.overrides) do
        local ok, t = pcall(o.fn)
        if ok and t and t.inst then return t end
    end
    return nil
end
N.Override = Override

-- 3.12.7: Fuehrt ein Abschnitt ohne gelaufenen Weg als Luftlinie ueber ueberwiegend unbekanntes Gelaende (Gebirge,
-- Felsen, Wasser), wird keine Linie gezeichnet - nur der Pfeil zeigt die Richtung zum Ziel.
local BLOCK_SEG, BLOCK_SHARE = 150, 0.5
function N.Blocked(p)
    if not LP.Terrain or not LP.Terrain.Unknown then return false end
    for i = 2, #p do
        local a, b = p[i - 1], p[i]
        local map = (a[4] and b[4] and a[4] == b[4]) and a[4] or nil
        if map and a[1] == b[1] and not (LP.Terrain.Keep and LP.Terrain.Keep(a, b))
           and LP.Geo:Dist(a[2], a[3], b[2], b[3]) >= BLOCK_SEG and LP.Terrain:Unknown(map, a, b) >= BLOCK_SHARE then
            return true
        end
    end
    return false
end

-- 3.12.9: Linie nur ueber bekannte Wege (gelaufene/geteilte Kanten, Uebergaenge, Hoehlen). Luftlinie nur fuer das
-- erste und das letzte kurze Stueck (bis ARRIVE Yards). Sonst: keine Linie, nur Pfeil und "Weg unbekannt".
N.ARRIVE = 40
function N.Known(p)
    if type(p) ~= "table" or #p < 2 then return false end
    for i = 2, #p do
        local a, b = p[i - 1], p[i]
        if (b.via == nil or b.via == "v") and not (a.cave and b.cave) then
            local short = a[1] == b[1] and LP.Geo:Dist(a[2], a[3], b[2], b[3]) <= N.ARRIVE
            if not (short and (i == 2 or i == #p)) then return false end
        end
    end
    return true
end

------------------------------------------------------------------------
-- 3.12.10: Sackgassen (FEST). Gezaehlt wird nur reine Laufzeit: Die Uhr laeuft nur, solange sich der Spieler
-- wirklich bewegt (Position aendert sich) und nichts davon zutrifft: AFK, tot/Geist, Kampf, Flug, offenes
-- Haendler-/Post-/Auktions-/Berufs-/Lehrerfenster. Stehen haelt die Uhr nur an (setzt nichts in Gang), Luecken
-- (Ladebildschirm, /reload) zaehlen nicht. Nach 4 min Laufzeit ohne Annaeherung: FEST - die Kante, auf der der
-- Spieler war, wird gesperrt, und der Weg neu gesucht.
------------------------------------------------------------------------
N.STUCK_MOVE_SECS = 240       -- Laufzeit ohne Annaeherung bis FEST
N.STUCK_GAIN = 15             -- Yards, die als Annaeherung zaehlen
N.MOVE_MIN = 1.5              -- Yards je Sekunde: weniger gilt als Stehen
local STUCK_AREA = 400        -- im Questgebiet (Erledigen) unterwegs: kein FEST
local stuck = {}
local OPEN_FRAMES = { "MerchantFrame", "MailFrame", "AuctionFrame", "AuctionHouseFrame", "TradeSkillFrame",
                      "ClassTrainerFrame", "CraftFrame", "ProfessionsFrame" }
function N.Excluded()
    local S = LP.SafeValue
    if UnitIsAFK and S(UnitIsAFK("player")) then return "afk" end
    if UnitIsDeadOrGhost and S(UnitIsDeadOrGhost("player")) then return "tot" end
    if LP:InCombat() then return "kampf" end
    if UnitOnTaxi and S(UnitOnTaxi("player")) then return "flug" end
    for _, name in ipairs(OPEN_FRAMES) do
        local f = _G[name]
        if type(f) == "table" and f.IsShown and f:IsShown() then return "fenster" end
    end
    return nil
end
function N.ResetStuck() wipe(stuck) end
function N:StuckTick(now)
    local tgt = N.target
    local pi, pn, pw = LP.Geo:Player()
    if not tgt or not pi or tgt.inst ~= pi or not tgt.n then stuck.lastN = nil return end
    if stuck.key ~= tgt.key then
        wipe(stuck)
        stuck.key, stuck.moveSecs = tgt.key, 0
    end
    local d = LP.Geo:Dist(pn, pw, tgt.n, tgt.w)
    local dt = stuck.lastT and (now - stuck.lastT) or 0
    local moved = stuck.lastN and LP.Geo:Dist(stuck.lastN, stuck.lastW, pn, pw) >= N.MOVE_MIN * math.max(dt, 0.5)
    stuck.lastN, stuck.lastW, stuck.lastT = pn, pw, now
    if not stuck.best or d < stuck.best - N.STUCK_GAIN then stuck.best, stuck.moveSecs = d, 0 return end
    if dt <= 0 or dt > 3 or not moved or N.Excluded() then return end          -- Uhr steht
    if tostring(tgt.key):find("^COMPLETE:") and d < STUCK_AREA then stuck.moveSecs = 0 return end
    stuck.moveSecs = stuck.moveSecs + dt
    if stuck.moveSecs >= N.STUCK_MOVE_SECS and not stuck.fired and d > N.ARRIVE then
        stuck.fired = true
        N:OnStuck(tgt, d)
    end
end
N.stuck = stuck

function N:OnStuck(tgt, d)
    -- Kante sperren, auf der der Spieler unterwegs war (nur gelaufene/geteilte Kanten haben Knoten-IDs)
    local blocked = false
    local a, b = path and path[pathIdx - 1], path and path[pathIdx]
    if a and b and a.id and b.id and b.via and b.via ~= "v" then
        blocked = LP.Graph:Block(a.id, b.id, "FEST")
    end
    -- Vorrang-Ziel (Trainer, Beruf, Haendler ...): keine Linie mehr, nur der Pfeil
    if tostring(tgt.key):find("^PRIO:") or not blocked then N.stuckKey = tgt.key end
    N.stuckLog = N.stuckLog or {}
    N.stuckLog[#N.stuckLog + 1] = { key = tostring(tgt.key), t = time and time() or 0, blocked = blocked }
    -- fuer die Wegdaten (/lp wege, GSWEGE1): Ort und Zeit, 7 Tage, hoechstens 200 Eintraege
    local _, _, _, map, x, y = LP.Geo:Player()
    if map and type(LP.db.festLog) == "table" then
        local log = LP.db.festLog
        log[#log + 1] = { map = map, x = math.floor((x or 0) * 10 + 0.5) / 10, y = math.floor((y or 0) * 10 + 0.5) / 10,
                          t = time and time() or 0, blocked = blocked or nil }
        local cut = (time and time() or 0) - 7 * 86400
        while #log > 0 and ((log[1].t or 0) < cut or #log > 200) do table.remove(log, 1) end
    end
    if LP.Protocol and LP.Protocol.Stuck then
        pcall(LP.Protocol.Stuck, LP.Protocol, tgt, math.floor(stuck.moveSecs / 60), d, N.pathKind, blocked)
    end
    pcall(N.Recalc, N, true)
end

function N:Recalc(force)
    local step = LP.Engine:Current()
    local ov = Override()
    N.active = ov
    local tgt = ov or TargetOf(step)
    local pi, pn, pw, pmap = LP.Geo:Player()
    N.target = tgt
    if not tgt or not pi then
        path, pathKind, pathTarget = nil, nil, nil
        N.hasPath, N.pathKind = nil, nil
        return
    end
    local now = GetTime()
    local changed = pathTarget ~= tgt.key
    -- vom Weg abgekommen?
    local off = false
    if path and path[pathIdx] and path[pathIdx - 1] then
        off = DistToSegment(pn, pw, path[pathIdx - 1], path[pathIdx]) > OFFPATH
    end
    if not force and not changed and not off and now - lastCalc < RECALC_SECS then return end
    -- auch abseits des Weges hoechstens alle OFF_MIN Sekunden neu rechnen (A* kann teuer sein); auf Fluegen nie
    -- 3.12.24: abseits des Weges nach einer teuren Suche laenger warten (bis 10 s), damit nichts dauernd rechnet
    if not force and not changed and off and now - lastCalc < math.max(OFF_MIN, N.offWait or 0) then return end
    -- laeuft schon eine Wegsuche zu diesem Ziel, auf sie warten
    if not force and not changed and LP.Jobs.Running("navpath") then return end
    if not force and UnitOnTaxi and LP.SafeValue(UnitOnTaxi("player")) then return end
    if not force and not changed and not off and path then
        -- nur neu rechnen, wenn sich der Spieler deutlich bewegt hat
        if lastPos and LP.Geo:Dist(lastPos[1], lastPos[2], pn, pw) < 25 then return end
    end
    -- 3.12.75 ROUTE-Q R3W: gleiches Ziel, Spieler auf dem Weg, keine erzwungene Neuberechnung -> neuen Weg nur nehmen, wenn er
    -- deutlich kuerzer ist als der Rest des alten (N.KeepOld). Sonst sprang der Weg zwischen gleich guten Varianten hin und her.
    local mayKeep = not force and not changed and not off and path ~= nil
    lastCalc, lastPos = now, { pn, pw }
    N.recalcCount = (N.recalcCount or 0) + 1        -- nur zum Messen (Testroutine T152)
    pathTarget = tgt.key
    -- 3.12.24: Wegsuche in Portionen (LP.Jobs, hoechstens 4 ms je Bild); das Ergebnis kommt in einem spaeteren Bild
    -- 3.12.92: über den gemeinsamen Takt (GoldSentinelTakt, Plan 3.12.92 Punkt 3)
    local key = tgt.key
    LP.Jobs.StartTakt("navpath", "path", function()
        local p, kind = LP.Graph:Path(pi, pn, pw, pmap, tgt.inst, tgt.n, tgt.w, tgt.map)
        local known = p and N.Known(p)
        -- 3.12.35 UC-W1: Weg mit Luftlinien gefunden – gibt es einen ganz bekannten Weg (nur gelaufene/geteilte Kanten)?
        -- Dann diesen nehmen (Staedte mit mehreren Ebenen: Luftlinien queren Ebenen, der gelaufene Weg fuehrt hin).
        if p and not known and kind ~= "cave" and LP.Graph.PathKnown then
            local p2 = LP.Graph:PathKnown(pi, pn, pw, pmap, tgt.inst, tgt.n, tgt.w, tgt.map)
            if p2 and N.Known(p2) then p, kind, known = p2, "graph", true end
        end
        if p then
            -- lange Abschnitte ohne gelaufene Wege dem Gelaende anpassen
            local ok2, rp, refined = true, LP.Terrain:Refine(p)
            if ok2 and rp then
                p = rp
                if refined and kind == "direct" then kind = "terrain" end
            end
            -- 3.12.75 ROUTE-Q R3W: kein Umweg ueber einen Knoten neben dem Spieler (Graph.ShortcutStart)
            if LP.Graph.RemoveLoops then p = LP.Graph.RemoveLoops(p) end          -- 3.12.76: Haarnadeln im Weg
            if LP.Graph.ShortcutStart then p = LP.Graph.ShortcutStart(p) end
        end
        return p, kind, known
    end, function(ok, p, kind, known)
        if pathTarget ~= key then return end              -- Ziel hat inzwischen gewechselt
        -- Rechenzeit der Suche bestimmt die Wartezeit abseits des Weges (200 ms -> 4 s)
        local spent = LP.Jobs.lastCpu or 0
        N.lastPathMs = spent
        N.offWait = LP.Jobs.sync and 0 or math.min(10, spent / 1000 * 20)
        if mayKeep and ok and p and path and not N.Blocked(path) then
            local oldRem = N:RemainingDistance()
            local newRem = N.PathLength(p)
            if N.KeepOld(oldRem, newRem) then
                N.keptPaths = (N.keptPaths or 0) + 1      -- nur zum Messen
                -- 3.12.76: auch den behaltenen Rest am Anfang abkuerzen (Haarnadel kurz vor dem Spieler, ROUTE-Q R3W)
                N.TrimKept()
                return
            end
        end
        N:ApplyPath(ok, p, kind, known)
    end)
end

------------------------------------------------------------------------
-- W3D B5 (Entwurf, nur bei LP.W3D): ein Satz je Tor. Der Pfeil zeigt ohnehin auf den naechsten Wegpunkt (das Tor).
------------------------------------------------------------------------
local function SubOf(lv) return lv and lv:match("^[^|]*|[^|]*|(.*)$") or nil end
function N.GateText(e, toNode)
    local sub = SubOf(LP.Graph and LP.Graph.LvName and LP.Graph.LvName(toNode) or (toNode and toNode.lv))
    sub = (sub and sub ~= "") and sub or nil
    if sub and LP.Graph and LP.Graph.SubName then sub = LP.Graph.SubName(sub) end     -- 3.12.38: "#ID" -> Name
    if e.lift then return sub and L("Aufzug nehmen (nach %s)", sub) or L["Aufzug nehmen"] end
    if e.ow then return sub and L("Hier hinunterspringen (nach %s)", sub) or L["Hier hinunterspringen"] end
    return sub and L("Übergang nach %s", sub) or L["Übergang zur anderen Ebene"]
end
function N:GateHint()
    local G = LP.Graph
    if not (G and G.On and G.On()) or not path then return nil end
    local pi, pn, pw = LP.Geo:Player()
    -- falsche Ebene: der naechste Wegpunkt liegt drinnen auf einer anderen Ebene als der Spieler
    local nextP = path[pathIdx]
    local nd = nextP and nextP.id and G:NodeById(nextP.id)
    if nd and nd.k then
        local lv, indoors = G.LevelInfo()
        local me = indoors and lv or nil
        if me and me ~= nd.k and pi and pn then
            return L("Andere Ebene – zurück zum Übergang (%s)", LP:FormatDist(LP.Geo:Dist(pn, pw, nextP[2], nextP[3])))
        end
    end
    for i = math.max(2, pathIdx), #path do
        local a, b = path[i - 1], path[i]
        if a.id and b.id then
            local adj = G:Neighbors(a.id)
            local e = adj and adj[b.id]
            if e and e.g then
                local d = (pi and pn) and LP.Geo:Dist(pn, pw, a[2], a[3]) or 0
                return N.GateText(e, G:NodeById(b.id)) .. " · " .. LP:FormatDist(d)
            end
        end
    end
    return nil
end

function N:ApplyPath(ok, p, kind, known)
    N.pathUnknown = not (ok and p and known) or nil
    if ok and p then
        path, pathKind, pathIdx = p, kind, 2
        N.pathError = nil
    else
        path, pathKind, pathIdx = nil, nil, 2
        N.pathError = not ok and tostring(p) or nil
    end
    N.hasPath, N.pathKind = path ~= nil, pathKind
    N.pathBlocked = path and (N.pathUnknown or N.Blocked(path) or (N.stuckKey ~= nil and pathTarget == N.stuckKey)) or nil
    pcall(N.CheckDanger, N)
end

------------------------------------------------------------------------
-- Sicherer Modus: gefaehrliche Gegner am Weg (deutlich hoeher oder Elite)
------------------------------------------------------------------------
local DANGER_AHEAD = 500      -- Yards des Weges, die geprueft werden
local DANGER_RADIUS = 40      -- Yards Abstand zum Spawnpunkt
local mobIndex = {}           -- [Karte] = { {inst, n, w, name, lo, hi, elite}, ... }
function N:ResetNames() wipe(mobIndex) end   -- nach einem Sprachwechsel
N.danger = nil

local function MobsOf(map)
    local list = mobIndex[map]
    if list then return list end
    list = {}
    mobIndex[map] = list
    local d = _G.LevelPilotData
    if type(d) ~= "table" or type(d.N) ~= "table" then return list end
    local fac = LP:PlayerFaction() == "Horde" and "H" or "A"
    for nid, nn in pairs(d.N) do
        local friendly = nn.f and nn.f ~= "" and nn.f:find(fac)
        if not friendly and nn.lo and nn.s and not nn.v then
            for _, z in ipairs(nn.s) do
                if z[1] == map then
                    for i = 2, #z - 1, 2 do
                        local inst, wn, ww = LP.Geo:ToWorld(map, z[i], z[i + 1])
                        if inst then
                            list[#list + 1] = { inst, wn, ww, (LP.Names and LP.Names:Npc(nid)) or nn.n, nn.lo, nn.hi or nn.lo, nn.rk and nn.rk ~= 4 }
                        end
                    end
                end
            end
        end
    end
    return list
end

function N:CheckDanger()
    N.danger = nil
    if not LP.db.safeMode or not path then return end
    local pi, pn, pw, pmap = LP.Geo:Player()
    if not pi or not pmap then return end
    local level = LP:PlayerLevel() or 1
    local mobs = MobsOf(pmap)
    if #mobs == 0 then return end
    -- Punkte entlang des Weges alle 25 Yards
    local samples, walked = {}, 0
    local prev = { pi, pn, pw }
    for i = pathIdx, #path do
        local p = path[i]
        if p[1] ~= pi then break end
        local seg = LP.Geo:Dist(prev[2], prev[3], p[2], p[3])
        local steps = math.max(1, math.floor(seg / 25))
        for k = 1, steps do
            local t = k / steps
            samples[#samples + 1] = { prev[2] + (p[2] - prev[2]) * t, prev[3] + (p[3] - prev[3]) * t }
        end
        walked = walked + seg
        prev = p
        if walked > DANGER_AHEAD then break end
    end
    local worst, worstScore
    for _, m in ipairs(mobs) do
        local bad = m[5] >= level + 3 or (m[7] and m[5] >= level - 2)
        if bad and m[1] == pi then
            for _, sp in ipairs(samples) do
                if math.abs(sp[1] - m[2]) < DANGER_RADIUS and math.abs(sp[2] - m[3]) < DANGER_RADIUS
                   and LP.Geo:Dist(sp[1], sp[2], m[2], m[3]) < DANGER_RADIUS then
                    local score = m[5] + (m[7] and 5 or 0)
                    if not worstScore or score > worstScore then worst, worstScore = m, score end
                    break
                end
            end
        end
    end
    if worst then
        N.danger = LP.L("Vorsicht am Weg: %s (Stufe %d–%d%s)", worst[4] or "?", worst[5], worst[6], worst[7] and (", " .. LP.L["Elite"]) or "")
    end
end

-- naechster Wegpunkt, erreichte Punkte ueberspringen
local function CurrentWaypoint()
    if not path then return nil end
    local pi, pn, pw = LP.Geo:Player()
    if not pi then return nil end
    while path[pathIdx] do
        local wp = path[pathIdx]
        if pathIdx < #path and wp[1] == pi and (LP.Geo:Dist(pn, pw, wp[2], wp[3]) < WAYPOINT_REACH or N.Passed(path, pathIdx, pn, pw)) then
            pathIdx = pathIdx + 1
        else
            break
        end
    end
    return path[pathIdx]
end

-- 3.12.71 ERA-1 (b): Wegpunkt liegt hinter dem Spieler – er steht schon jenseits des Punktes in Richtung des nächsten
-- (Skalarprodukt > 0) und der nächste ist näher als vom Punkt aus. Dann nicht zurückschicken, sondern weiterschalten.
-- (Vorher: nach einer Neuberechnung hing der Weg an einem Strassenknoten HINTER dem Spieler -> Pfeil drehte um 180°.)
N.PASS_NEAR = 40
function N.Passed(p, idx, pn, pw)
    local wp, nx = p[idx], p[idx + 1]
    if not (wp and nx) or wp[1] ~= nx[1] then return false end
    local ax, ay = nx[2] - wp[2], nx[3] - wp[3]
    local bx, by = pn - wp[2], pw - wp[3]
    if ax * bx + ay * by <= 0 then return false end
    -- 3.12.81: nur in der Naehe des Wegpunkts (sonst "uebersprang" ein 120 yd entferntes Tor, weil das naechste Stueck 1500 yd lang
    -- ist und der Spieler dem Ende dadurch rechnerisch naeher war – Pfeil zeigte zurueck, "Land Ho!", ROUTE-Q R3W)
    if bx * bx + by * by > N.PASS_NEAR * N.PASS_NEAR then return false end
    return LP.Geo:Dist(pn, pw, nx[2], nx[3]) < LP.Geo:Dist(wp[2], wp[3], nx[2], nx[3])
end

-- 3.12.76: behaltenen Weg ab dem Spieler neu ansetzen und am Anfang abkuerzen (Graph.ShortcutStart)
function N.TrimKept()
    if not (path and path[pathIdx] and LP.Graph.ShortcutStart) then return end
    local pi, pn, pw, pmap = LP.Geo:Player()
    if not pi or path[pathIdx][1] ~= pi then return end
    local rest = { { pi, pn, pw, pmap } }
    for i = pathIdx, #path do rest[#rest + 1] = path[i] end
    local out, cut = LP.Graph.ShortcutStart(rest)
    if cut and cut > 0 then path, pathIdx = out, 2 end
end

-- 3.12.75: alten Weg behalten, solange der neue nicht um mindestens max(30 yd, 10 %) kuerzer ist
N.KEEP_MIN, N.KEEP_SHARE = 30, 0.1
function N.KeepOld(oldRem, newRem)
    if not oldRem or not newRem then return false end
    return newRem > oldRem - math.max(N.KEEP_MIN, oldRem * N.KEEP_SHARE)
end
function N.PathLength(p)
    local d = 0
    for i = 2, #p do
        local a, b = p[i - 1], p[i]
        if a[1] == b[1] then d = d + LP.Geo:Dist(a[2], a[3], b[2], b[3]) end
    end
    return d
end

function N:RemainingDistance()
    if not path then return nil end
    local pi, pn, pw = LP.Geo:Player()
    local wp = path[pathIdx]
    if not wp or wp[1] ~= pi then return nil end
    local d = LP.Geo:Dist(pn, pw, wp[2], wp[3])
    for i = pathIdx + 1, #path do
        local a, b = path[i - 1], path[i]
        if a[1] == b[1] then d = d + LP.Geo:Dist(a[2], a[3], b[2], b[3]) end
    end
    return d
end

------------------------------------------------------------------------
-- Pfeil
------------------------------------------------------------------------
local arrow

local function CreateArrow()
    arrow = CreateFrame("Button", "LevelPilotArrow", UIParent)
    arrow:SetSize(84, 100)
    arrow:SetMovable(true)
    arrow:EnableMouse(true)
    arrow:RegisterForDrag("LeftButton")
    arrow:RegisterForClicks("RightButtonUp")
    arrow:SetClampedToScreen(true)
    arrow:SetFrameStrata("MEDIUM")
    if LP.db.arrowPos then
        local p = LP.db.arrowPos
        arrow:SetPoint(p[1], UIParent, p[2], p[3], p[4])
    else
        arrow:SetPoint("TOP", UIParent, "TOP", 0, -130)
    end
    arrow:SetScript("OnDragStart", function(self) if not LP.db.locked then self:StartMoving() end end)
    arrow:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        LP.db.arrowPos = { p, rp, x, y }
    end)
    arrow:SetScript("OnClick", function()
        LP.db.showArrow = false
        arrow:Hide()
        LP:Reply(L["Pfeil ausgeblendet (einschalten in der Zentrale)."])
    end)

    local ring = arrow:CreateTexture(nil, "BACKGROUND")
    ring:SetTexture("Interface\\Buttons\\WHITE8X8")
    ring:SetSize(4, 4)
    ring:SetPoint("TOP", 0, -32)
    ring:SetVertexColor(0, 0, 0, 0)

    local tex = arrow:CreateTexture(nil, "ARTWORK")
    tex:SetTexture("Interface\\Minimap\\MinimapArrow")
    tex:SetSize(60, 60)
    tex:SetPoint("TOP", 0, -2)
    arrow.tex = tex

    local dist = arrow:CreateFontString(nil, "OVERLAY")
    dist:SetFont(LP.FONT, 13, "OUTLINE")
    LP:RegisterText(dist)
    dist:SetPoint("TOP", tex, "BOTTOM", 0, -1)
    arrow.dist = dist

    local label = arrow:CreateFontString(nil, "OVERLAY")
    label:SetFont(LP.FONT, 10, "OUTLINE")
    LP:RegisterText(label)
    label:SetPoint("TOP", dist, "BOTTOM", 0, -2)
    label:SetWidth(220)
    label:SetTextColor(C.muted[1], C.muted[2], C.muted[3])
    arrow.label = label

    arrow:SetScript("OnEnter", function(self)
        if LP.UI and LP.UI.TipAnchor then LP.UI.TipAnchor(self) else GameTooltip:SetOwner(self, "ANCHOR_BOTTOM") end
        GameTooltip:AddLine(L["LevelPilot – Navigation"])
        GameTooltip:AddLine(L["Der Pfeil folgt dem Weg Punkt für Punkt."], 1, 1, 1)
        GameTooltip:AddLine(L["Grau = Weg noch unbekannt (Luftlinie)."], 0.7, 0.7, 0.75)
        GameTooltip:AddLine(L["Ziehen = verschieben, Rechtsklick = ausblenden"], 0.7, 0.7, 0.75)
        GameTooltip:Show()
    end)
    arrow:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

-- Prüfliste UC-W1: in Unterstadt (Karte 1458) ein bekannter Weg über das Wegnetz, also nicht "Weg unbekannt" und nicht
-- Luftlinie. Ohne Testmodus endet die Prüfung bei M:List() (höchstens ein Versuch je 30 s), Geo:Player wird dann nicht gerufen.
function N.PLWeg(note, kind, remain)
    local PL = LP.Pruefliste
    if not (PL and note == "" and kind == "graph" and (remain or 0) > 30 and PL:List()) then return false end
    if select(4, LP.Geo:Player()) ~= 1458 then return false end
    return PL:Hit("UC-W1", ("Weg bekannt, %d Yards"):format(math.floor(remain)))
end

local function UpdateArrow()
    if not arrow then return end
    local step = LP.Engine:Current()
    local wp = CurrentWaypoint()
    if N.pathBlocked and path then wp = path[#path] end      -- ohne Linie: Pfeil direkt zum Ziel
    if not LP.db.showArrow or not (step or N.active) or not wp then arrow:Hide() return end
    local pi, pn, pw = LP.Geo:Player()
    arrow:Show()
    arrow.label:SetText((N.active and N.active.label) or (LP.UI and step and LP.UI:ShortLabel(step)) or "")
    if not pi or wp[1] ~= pi then
        arrow.tex:SetRotation(0)
        arrow.tex:SetVertexColor(C.muted[1], C.muted[2], C.muted[3])
        arrow.dist:SetText(L["anderer Kontinent"])
        return
    end
    local facing = LP.Facing()
    if facing then
        local target = math.atan2(wp[3] - pw, wp[2] - pn)
        local rel = target - facing
        arrow.tex:SetRotation(rel)
        local off = math.abs(((rel + math.pi) % (2 * math.pi)) - math.pi)
        local base = (pathKind == "graph" or pathKind == "terrain" or pathKind == "cave") and C.path or C.pathNew
        if off < 0.3 then
            arrow.tex:SetVertexColor(C.accent2[1], C.accent2[2], C.accent2[3])
        else
            local f = math.min(1, off / math.pi)
            arrow.tex:SetVertexColor(base[1], base[2] * (1 - 0.35 * f), base[3] * (1 - 0.5 * f))
        end
    end
    local remain = N:RemainingDistance()
    local note = ""
    if N.pathUnknown or N.pathBlocked then note = "  |cff9a9aa6(" .. L["Weg unbekannt"] .. ")|r"
    elseif pathKind == "direct" then note = L["  |cff9a9aa6(Luftlinie)|r"] end
    N.PLWeg(note, pathKind, remain)                     -- Prüfliste UC-W1 (nur Testmodus)
    -- W3D (nur eingeschaltet): Satz zum naechsten Uebergang zwischen Ebenen bzw. "falsche Ebene"
    local gate = N.GateHint and N:GateHint()
    if gate then note = note .. "\n|cff3dd694" .. gate .. "|r" end
    arrow.dist:SetText(LP:FormatDist(remain) .. note)
end

------------------------------------------------------------------------
-- Minikarte: Pfadlinie
------------------------------------------------------------------------
local mmFrame, mmLines = nil, {}
local RADIUS_OUT = { [0] = 233.3, [1] = 200, [2] = 166.7, [3] = 133.3, [4] = 100, [5] = 66.7 }
local RADIUS_IN  = { [0] = 150, [1] = 120, [2] = 90, [3] = 60, [4] = 40, [5] = 25 }

local function MinimapLine(i)
    local l = mmLines[i]
    if not l then
        l = mmFrame:CreateLine(nil, "OVERLAY")
        l:SetThickness(3)
        mmLines[i] = l
    end
    return l
end

-- Strecke auf Kreis mit Radius r begrenzen (Mittelpunkt 0,0)
local function ClipCircle(x1, y1, x2, y2, r)
    local dx, dy = x2 - x1, y2 - y1
    local a = dx * dx + dy * dy
    local in1 = x1 * x1 + y1 * y1 <= r * r
    local in2 = x2 * x2 + y2 * y2 <= r * r
    if in1 and in2 then return x1, y1, x2, y2 end
    if a == 0 then return nil end
    local b = 2 * (x1 * dx + y1 * dy)
    local c = x1 * x1 + y1 * y1 - r * r
    local disc = b * b - 4 * a * c
    if disc < 0 then return nil end
    local sq = math.sqrt(disc)
    local t1, t2 = (-b - sq) / (2 * a), (-b + sq) / (2 * a)
    local s, e = math.max(0, t1), math.min(1, t2)
    if s > e then return nil end
    return x1 + s * dx, y1 + s * dy, x1 + e * dx, y1 + e * dy
end

-- Weltpunkt -> Versatz auf der Minikarte (Pixel vom Mittelpunkt) und Kartenradius in Pixeln.
-- Fuer Symbole anderer Module (Fundstellen, Questgeber).
function N:MinimapProject(inst, n, w)
    local pi, pn, pw = LP.Geo:Player()
    if not pi or pi ~= inst or not Minimap then return nil end
    local zoom = Minimap:GetZoom()
    local radius = (LP.Indoors() and RADIUS_IN or RADIUS_OUT)[zoom] or 200
    local half = Minimap:GetWidth() / 2
    local scale = half / radius
    local e, nn = -(w - pw), n - pn
    local right, up = e, nn
    if GetCVar("rotateMinimap") == "1" then
        local f = LP.Facing() or 0
        local cf, sf = math.cos(f), math.sin(f)
        right, up = e * cf + nn * sf, -e * sf + nn * cf
    end
    return right * scale, up * scale, half
end

local function UpdateMinimapPath()
    -- virtuelle Reise: die Minikarte zeigt den echten Charakter, der gedachte Weg passt nicht dazu
    if LP.Virtual and LP.Virtual.active then
        for i = 1, #mmLines do mmLines[i]:Hide() end
        return
    end
    if not mmFrame then return end
    local used = 0
    local pi, pn, pw = LP.Geo:Player()
    if LP.db.showMinimapPath and path and pi and not N.pathBlocked then
        local zoom = Minimap:GetZoom()
        local radius = (LP.Indoors() and RADIUS_IN or RADIUS_OUT)[zoom] or 200
        local half = Minimap:GetWidth() / 2
        local scale = half / radius
        local rot = GetCVar("rotateMinimap") == "1"
        local f = rot and (LP.Facing() or 0) or 0
        local cf, sf = math.cos(f), math.sin(f)
        local function proj(p)
            local e, nn = -(p[3] - pw), p[2] - pn       -- Osten, Norden
            local right, up = e, nn
            if rot then right, up = e * cf + nn * sf, -e * sf + nn * cf end
            return right * scale, up * scale
        end
        local col = (pathKind == "graph" or pathKind == "terrain" or pathKind == "cave") and C.path or C.pathNew
        if pathKind == "watch" then col = C.accent end
        local prevX, prevY = 0, 0
        for i = pathIdx, #path do
            local p = path[i]
            if p[1] ~= pi then break end
            local x, y = proj(p)
            local cx1, cy1, cx2, cy2 = ClipCircle(prevX, prevY, x, y, half - 3)
            if cx1 then
                used = used + 1
                local l = MinimapLine(used)
                l:SetColorTexture(col[1], col[2], col[3], 0.9)
                l:SetStartPoint("CENTER", Minimap, cx1, cy1)
                l:SetEndPoint("CENTER", Minimap, cx2, cy2)
                l:Show()
            end
            if (x * x + y * y) > (half * half * 4) then break end
            prevX, prevY = x, y
        end
    end
    for i = used + 1, #mmLines do mmLines[i]:Hide() end
end

------------------------------------------------------------------------
-- Weltkarte: Pfadlinie und Schritt-Marker
------------------------------------------------------------------------
local wmLines, wmPins = {}, {}

local function Canvas()
    return WorldMapFrame and WorldMapFrame.ScrollContainer and WorldMapFrame.ScrollContainer.Child
end

local function MapLine(i, canvas)
    local l = wmLines[i]
    if not l then
        l = canvas:CreateLine(nil, "OVERLAY")
        wmLines[i] = l
    end
    return l
end

local function MapPin(i, canvas)
    local p = wmPins[i]
    if not p then
        p = CreateFrame("Frame", nil, canvas)
        p:SetSize(24, 24)
        p:EnableMouse(true)
        local t = p:CreateTexture(nil, "ARTWORK")
        t:SetAllPoints()
        t:SetTexture("Interface\\Minimap\\ObjectIcons")
        t:SetTexCoord(0.5, 0.625, 0, 0.25)
        p.tex = t
        local num = p:CreateFontString(nil, "OVERLAY")
        num:SetFont(LP.FONT, 11, "OUTLINE")
        LP:RegisterText(num)
        num:SetPoint("CENTER")
        p.num = num
        p:SetScript("OnEnter", function(self)
            if not self.step then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine("LevelPilot")
            GameTooltip:AddLine(LP.UI:StepText(self.step, true), 1, 1, 1, true)
            GameTooltip:Show()
        end)
        p:SetScript("OnLeave", function() GameTooltip:Hide() end)
        wmPins[i] = p
    end
    return p
end

local function UpdateWorldMap()
    local canvas = Canvas()
    if not canvas or not WorldMapFrame:IsShown() then return end
    local shown = WorldMapFrame:GetMapID()
    local w, h = canvas:GetWidth(), canvas:GetHeight()
    local scale = 1
    if WorldMapFrame.ScrollContainer.GetCanvasScale then
        scale = WorldMapFrame.ScrollContainer:GetCanvasScale() or 1
    end

    -- Pfad (virtuelle Reise beim Zuschauen: der gerade gelaufene Weg des gedachten Charakters)
    local used = 0
    local path, pathIdx, pathKind = path, pathIdx, pathKind
    local V = LP.Virtual
    local watching = V and V.active and V.watch and V.trail and #V.trail >= 2
    if watching then path, pathIdx, pathKind = V.trail, 2, "watch" end
    if (LP.db.showMapPath or watching) and path and shown and (watching or not N.pathBlocked) then
        local col = (pathKind == "graph" or pathKind == "terrain" or pathKind == "cave") and C.path or C.pathNew
        local prev
        local pi, pn, pw = LP.Geo:Player()
        local startPt = (not watching and pi) and { pi, pn, pw } or path[1]
        for i = pathIdx - 1, #path do
            local p = (i == pathIdx - 1 and startPt) or path[i]
            if p then
                local x, y = LP.Geo:ToMap(shown, p[1], p[2], p[3])
                if prev and x and prev[1] then
                    used = used + 1
                    local l = MapLine(used, canvas)
                    l:SetThickness((watching and 6 or 4) / scale)
                    l:SetColorTexture(col[1], col[2], col[3], 0.85)
                    l:SetStartPoint("TOPLEFT", canvas, prev[1] / 100 * w, -prev[2] / 100 * h)
                    l:SetEndPoint("TOPLEFT", canvas, x / 100 * w, -y / 100 * h)
                    l:Show()
                end
                prev = { x, y }
            end
        end
    end
    for i = used + 1, #wmLines do wmLines[i]:Hide() end
    N.wmLinesShown = used          -- Selbsttest / Testumgebung

    -- Marker der naechsten Schritte
    local count = 0
    for i, s in ipairs(LP.Engine:Steps()) do
        if count >= 8 then break end
        local tgt = TargetOf(s)
        if tgt and shown then
            local x, y = LP.Geo:ToMap(shown, tgt.inst, tgt.n, tgt.w)
            if x and x >= 0 and x <= 100 and y >= 0 and y <= 100 then
                count = count + 1
                local p = MapPin(count, canvas)
                p.step = s
                p:SetScale(1 / scale)
                p:ClearAllPoints()
                p:SetPoint("CENTER", canvas, "TOPLEFT", x / 100 * w * scale, -y / 100 * h * scale)
                if i == 1 then
                    p.tex:SetVertexColor(1, 1, 1)
                    p:SetSize(30, 30)
                    p.num:SetText("")
                else
                    p.tex:SetVertexColor(C.accent[1], C.accent[2], C.accent[3])
                    p:SetSize(22, 22)
                    p.num:SetText(i)
                end
                p:SetFrameLevel(canvas:GetFrameLevel() + 30 - count)
                p:Show()
            end
        end
    end
    for i = count + 1, #wmPins do wmPins[i]:Hide() end
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
function N:Refresh()
    self:Recalc(true)
    UpdateArrow()
    UpdateMinimapPath()
    UpdateWorldMap()
end

function N:PathInfo()
    return path, pathKind
end

function N:Init()
    CreateArrow()
    mmFrame = CreateFrame("Frame", nil, Minimap)
    mmFrame:SetAllPoints(Minimap)
    mmFrame:SetFrameLevel(Minimap:GetFrameLevel() + 5)

    local t = 0
    local driver = CreateFrame("Frame")
    LP.drivers = LP.drivers or {}
    LP.drivers.nav = driver                  -- Testroutine (T82)
    local st = 0
    LP:On("PLAYER_ENTERING_WORLD", function() N.ResetStuck() end)     -- Ladebildschirm, /reload
    driver:SetScript("OnUpdate", function(_, dt)
        t = t + dt
        st = st + dt
        if st >= 1 then st = 0 LP:Safe("nav_stuck", function() N:StuckTick(GetTime()) end) end
        if t < 0.05 then return end
        t = 0
        N:Recalc(false)
        UpdateArrow()
        UpdateMinimapPath()
    end)

    N.UpdateWorldMap = UpdateWorldMap      -- Testumgebung
    if WorldMapFrame then
        WorldMapFrame:HookScript("OnShow", UpdateWorldMap)
        local wt = 0
        WorldMapFrame:HookScript("OnUpdate", function(_, dt)
            wt = wt + dt
            if wt > 0.4 then wt = 0 UpdateWorldMap() end
        end)
    end
    LP:Listen("PLAN_CHANGED", function() N:Recalc(true) end)
    LP:Listen("GRAPH_CHANGED", function() lastCalc = 0 end)
end
