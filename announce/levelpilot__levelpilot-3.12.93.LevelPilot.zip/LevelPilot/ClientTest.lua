-- LevelPilot - Geführter Client-Test (/lp clienttest), LP-N2 (Supervisor 16.11. 00:19)
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Geht die "im Client prüfen"-Punkte T297–T306 der Reihe nach durch. Was im Spiel selbst messbar ist (Rahmen vorhanden?
-- API liefert Werte? Sprache passt?), prüft LevelPilot automatisch. Nur wo der Spieler hinschauen muss, fragt ein kleines
-- Fenster mit EINEM Satz und den Knöpfen "OK" / "Nicht OK" / "Überspringen". Ergebnis: eine Zeile je Punkt in der Diagnose
-- (/lp diag) und gespeichert in LevelPilotDB.clientTest.

local _, LP = ...
local L = LP.L
local CT = {}
LP:RegisterModule("ClientTest", CT)

local OK, BAD, NA = "OK", "FEHLER", "N/A"
local function S(v) return LP.SafeValue and LP.SafeValue(v) or v end

------------------------------------------------------------------------
-- Prüfpunkte: auto() -> Status, Text; ask() -> Frage (nil = keine Frage nötig)
------------------------------------------------------------------------
CT.STEPS = {
    { id = "T297", name = "Ebenen-Angabe (W3D B1)",
      auto = function()
          local G = LP.Graph
          if not (G and G.LevelInfo) then return BAD, "LevelInfo fehlt" end
          local lv = G.LevelInfo()
          local good = type(lv) == "string" and lv:find("^%d+|[do]|") ~= nil and lv:sub(1, 2) ~= "0|"
          return good and OK or BAD, tostring(lv)
      end },
    { id = "T298", name = "Startwegnetz",
      auto = function()
          local G = LP.Graph
          if not (G and G.SeedWegeAktiv) then return BAD, "fehlt" end
          if not G.SeedWegeAktiv() then return NA, "kein WoW-Forever-Client" end
          local st = G.seedWegeStat
          if not st then return BAD, "nicht geladen" end
          if not st.fertig then return NA, "wird noch geladen" end
          return (st.karten == 3 and (st.kanten or 0) > 600) and OK or BAD,
              ("Karten %d, Knoten %d (+%d eigene), Kanten %d"):format(st.karten or 0, st.knoten or 0, st.eigen or 0, st.kanten or 0)
      end },
    { id = "T299", name = "Unterzonen-Schlüssel aus dem Spiel",
      auto = function()
          local G = LP.Graph
          if not (G and G.SubKey) then return BAD, "SubKey fehlt" end
          if LP.AreaNames ~= nil then return BAD, "Tabelle aus den Spieldaten noch geladen" end
          local sub = GetSubZoneText and S(GetSubZoneText()) or ""
          local key = G.SubKey(sub)
          return key == sub and OK or BAD, ("hier „%s“ -> „%s“"):format(sub, tostring(key))
      end },
    { id = "T300", name = "Hinweis Erholt-Bonus",
      auto = function()
          if not (UnitIsAFK and IsResting) then return BAD, "UnitIsAFK/IsResting fehlen" end
          return OK, ("AFK %s, ausruhen %s"):format(tostring(S(UnitIsAFK("player"))), tostring(S(IsResting())))
      end,
      ask = function() return L["Gehe ausserhalb von Gasthaus/Hauptstadt und tippe /afk: Erscheint im Assistenten „Pause? Im Gasthaus …“?"] end },
    { id = "T301", name = "Waffenfertigkeit",
      auto = function()
          if not (GetNumSkillLines and GetSkillLineInfo) then return NA, "Fertigkeiten-API fehlt (Hinweis bleibt still)" end
          local link = GetInventoryItemLink and S(GetInventoryItemLink("player", 16))
          local sub = link and GetItemInfo and select(7, GetItemInfo(link))
          if not sub then return NA, "keine Waffe in der Haupthand" end
          for i = 1, (S(GetNumSkillLines()) or 0) do
              local name, isHeader = GetSkillLineInfo(i)
              if name == sub and not isHeader then return OK, ("„%s“ = Fertigkeit"):format(sub) end
          end
          return BAD, ("Waffenart „%s“ heisst als Fertigkeit anders"):format(sub)
      end },
    { id = "T302", name = "Waffenmeister",
      auto = function()
          local A = LP.Advisor
          if not (A and A.WEAPON_MASTERS and GetItemSubClassInfo) then return NA, "API fehlt (Hinweis bleibt still)" end
          local n = 0
          for _, x in ipairs(LP.QuestDB:ServiceNPCs().trainer or {}) do if x.id and A.WEAPON_MASTERS[x.id] then n = n + 1 end end
          return n > 0 and OK or BAD, ("%d Waffenmeister deiner Fraktion im Datenpaket"):format(n)
      end },
    { id = "T303", name = "Abgegraste Stelle",
      auto = function()
          local P = LP.Planner
          if not (P and P.CheckStuck and P.ProgressSig) then return BAD, "fehlt" end
          for id, st in pairs(P.inLog or {}) do
              if st.index and not st.complete then
                  local sig = P.ProgressSig(id)
                  if sig and sig ~= "" then return OK, ("Fortschritt lesbar (%s)"):format(sig:sub(1, 40)) end
              end
          end
          return NA, "keine offene Quest mit Zielen im Log"
      end },
    { id = "T304", name = "Händler-Upgrades",
      auto = function()
          local f = _G.MerchantFrame
          local b = _G.MerchantItem1ItemButton
          if not (f and b) then return BAD, "Händlerfenster/Knöpfe nicht gefunden" end
          return OK, ("Seiten %s, Reiter %s"):format(tostring(rawget(f, "page") or f.page), tostring(f.selectedTab))
      end,
      ask = function() return L["Öffne einen Händler mit Rüstung oder Waffen: Haben Upgrades für deine Klasse oben links ein Plus-Zeichen?"] end },
    { id = "T305", name = "Talent-Vorschlag",
      auto = function()
          local A = LP.Advisor
          if not (A and A.TalentNext and LP.TalentBuilds) then return BAD, "fehlt" end
          local list = LP.TalentBuilds[select(2, UnitClass("player"))]
          if not (list and GetNumTalents and GetTalentInfo) then return NA, "kein Build/keine Talent-API" end
          -- 3.12.88: Namen der eigenen Liste im Talentbaum des Clients suchen (bestätigt die Namensliste, v. a. die englische)
          local lang = A.TalentLang and A.TalentLang()
          if not lang then return NA, "Talentvorschläge nur deutsch/englisch" end
          local have = {}
          for tab = 1, (GetNumTalentTabs and S(GetNumTalentTabs())) or 3 do
              for i = 1, (S(GetNumTalents(tab)) or 0) do
                  local name = GetTalentInfo(tab, i)
                  if type(name) == "string" then have[name] = true end
              end
          end
          local miss, open = {}, 0
          for _, e in ipairs(list) do
              local nm = not e.offen and e[lang] or nil
              if not nm then open = open + 1
              elseif not have[nm] and not miss[nm] then miss[nm] = true miss[#miss + 1] = nm end
          end
          if #miss > 0 then return BAD, ("%d Namen nicht im Talentbaum: %s"):format(#miss, table.concat(miss, ", ", 1, math.min(6, #miss))) end
          CT.talentAsk = nil
          for _, e in ipairs(list) do if not e.offen and e[lang] then CT.talentAsk = { e[lang] } break end end
          return OK, ("alle Namen gefunden (%d Einträge, %d noch ohne Namen)"):format(#list, open)
      end,
      ask = function()
          local a = CT.talentAsk
          if not a then return nil end
          return L("Öffne das Talentfenster (Taste N): Gibt es dort das Talent „%s“?", a[1])
      end },
    { id = "T306", name = "LevelPilotAPI.NavigateTo",
      auto = function()
          local API = _G.LevelPilotAPI
          if not (API and API.NavigateTo) then return BAD, "fehlt" end
          local P = LP.Planner
          local saved, savedReplan = P.priority, P.Replan
          -- 3.12.93: auch keinen Reiseplan (Wegsuche) zu den Prüfzielen rechnen – geprüft wird nur die Rückgabe
          local C = LP.Comfort
          local savedPlan = C and C.PlanNavi
          P.Replan = function() end
          if C then C.PlanNavi = function() return false end end
          local ok, a, b = pcall(function() return API.NavigateTo(987654, 50, 50), API.NavigateTo(1411, 150, 50) end)
          P.priority, P.Replan = saved, savedReplan
          if C then C.PlanNavi = savedPlan end
          if not ok then return BAD, tostring(a) end
          return (a == false and b == false) and OK or BAD, ("unbekannte Karte %s, x=150 %s"):format(tostring(a), tostring(b))
      end },
}

------------------------------------------------------------------------
-- Ablauf
------------------------------------------------------------------------
CT.results = {}
CT.queue = {}

local function Line(r)
    return ("%s %s – %s: %s"):format(r.id, r.status, r.name, r.detail or "")
end

local function Save()
    local db = LP.db
    if not db then return end
    local lines = {}
    for _, r in ipairs(CT.results) do lines[#lines + 1] = Line(r) end
    db.clientTest = { version = LP.version, time = time and time() or 0, lines = lines }
end

-- Zusammenfassung: OK n · FEHLER n · N/A n · offen n
function CT:Summary()
    local c = { [OK] = 0, [BAD] = 0, [NA] = 0, offen = 0 }
    for _, r in ipairs(self.results) do
        if r.status == "?" then c.offen = c.offen + 1 else c[r.status] = (c[r.status] or 0) + 1 end
    end
    return ("OK %d · FEHLER %d · N/A %d · offen %d"):format(c[OK], c[BAD], c[NA], c.offen)
end

-- Diagnose-Zeilen (/lp diag): letzte Runde
function CT:DiagLines()
    local d = LP.db and LP.db.clientTest
    if type(d) ~= "table" or type(d.lines) ~= "table" then return { "CLIENTTEST: noch nicht gelaufen (/lp clienttest)" } end
    local out = { ("CLIENTTEST %s (%s):"):format(tostring(d.version), date and date("%d.%m. %H:%M", d.time or 0) or "?") }
    for _, l in ipairs(d.lines) do out[#out + 1] = "  " .. l end
    return out
end

function CT:Start()
    wipe(self.results)
    wipe(self.queue)
    for _, st in ipairs(self.STEPS) do
        local ok, status, detail = pcall(st.auto)
        if not ok then status, detail = BAD, tostring(status) end
        local r = { id = st.id, name = st.name, status = status, detail = detail }
        self.results[#self.results + 1] = r
        local q = (status == OK and st.ask) and st.ask() or nil
        if q then
            r.status, r.question = "?", q
            self.queue[#self.queue + 1] = r
        end
    end
    Save()
    self:Next()
end

-- naechste Frage zeigen oder fertig melden
function CT:Next()
    local r = self.queue[1]
    if not r then
        self:Hide()
        Save()
        LP:Reply(L("Client-Test fertig: %s – Ergebnis in /lp diag.", self:Summary()))
        if LP.Pruefliste then                                                               -- Prüfliste (CT-1)
            local bad = 0
            for _, x in ipairs(self.results) do if x.status == BAD then bad = bad + 1 end end
            LP.Pruefliste:Check("CT-1", bad == 0, self:Summary())
        end
        return
    end
    self:Show(r)
end

-- Antwort des Spielers: true = OK, false = nicht OK, nil = überspringen
function CT:Answer(good)
    local r = table.remove(self.queue, 1)
    if not r then return end
    if good == true then r.status = OK r.detail = (r.detail or "") .. " · gesehen"
    elseif good == false then r.status = BAD r.detail = (r.detail or "") .. " · vom Spieler: nicht OK"
    else r.status = NA r.detail = (r.detail or "") .. " · übersprungen" end
    Save()
    self:Next()
end

------------------------------------------------------------------------
-- Fenster: ein Satz, drei Knöpfe
------------------------------------------------------------------------
function CT:Frame()
    if self.frame then return self.frame end
    local UI = LP.UI
    local f = CreateFrame("Frame", "LevelPilotClientTest", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    f:SetSize(380, 130)
    f:SetPoint("CENTER", 0, 120)
    f:SetFrameStrata("DIALOG")
    if UI and UI.Skin then UI:Skin(f) end
    f.title = UI:Text(f, 13)
    f.title:SetPoint("TOPLEFT", 12, -10)
    f.text = UI:Text(f, 12)
    f.text:SetPoint("TOPLEFT", 12, -32)
    f.text:SetWidth(356)
    f.ok = UI:Button(f, L["OK"], 100, 22, function() CT:Answer(true) end)
    f.ok:SetPoint("BOTTOMLEFT", 12, 10)
    f.bad = UI:Button(f, L["Nicht OK"], 100, 22, function() CT:Answer(false) end)
    f.bad:SetPoint("BOTTOM", 0, 10)
    f.skip = UI:Button(f, L["Überspringen"], 100, 22, function() CT:Answer(nil) end)
    f.skip:SetPoint("BOTTOMRIGHT", -12, 10)
    self.frame = f
    return f
end

function CT:Show(r)
    local f = self:Frame()
    local done = #self.results - #self.queue
    f.title:SetText(("LevelPilot Client-Test %d/%d · %s"):format(done + 1, #self.results, r.id))
    f.text:SetText(r.question or "")
    f:Show()
end

function CT:Hide()
    if self.frame then self.frame:Hide() end
end

function CT:Init() end
