if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 5.7 - Buchhaltung (Logik)
--
-- Was wird gebucht?
--   * Verkäufe   - aus den Rechnungen im Briefkasten ("Auktion erfolgreich"):
--                  Verkaufspreis, AH-Anteil (5 %), zurückerstattete Einstellgebühr
--   * Käufe      - aus den Rechnungen im Briefkasten ("Auktion gewonnen")
--                  und sofort bei Käufen über den Sniper (doppelt wird nie gezählt)
--   * Einstellgebühren - sofort beim Einstellen über den Tab Verkaufen
-- Der Briefkasten muss dafür geöffnet werden - die Rechnungen liest das
-- Addon automatisch, du musst nichts abholen oder anklicken.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
-- Retail 12.x: die alten Item-/Zauber-Funktionen gibt es nur noch in C_Item / C_Spell
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local A = AHAnalyzerPro
local L = A.L

-- Briefkasten über A.Inbox (im Testmodus: Test-Briefkasten mit fiktiver Post)
local function GetInboxNumItems(...) return A.Inbox.GetInboxNumItems(...) end
local function GetInboxHeaderInfo(...) return A.Inbox.GetInboxHeaderInfo(...) end
local function GetInboxInvoiceInfo(...) return A.Inbox.GetInboxInvoiceInfo(...) end
local function GetInboxItem(...) return A.Inbox.GetInboxItem(...) end
local function GetInboxItemLink(...) return A.Inbox.GetInboxItemLink(...) end
local function TakeInboxMoney(...) return A.Inbox.TakeInboxMoney(...) end
local function TakeInboxItem(...) return A.Inbox.TakeInboxItem(...) end

local Le = {}
A.Ledger = Le

local KEEP_DAYS = 180          -- Buchungen älter als das werden gelöscht
local MAX_ENTRIES = 5000
local MATCH_WINDOW = 3 * 86400 -- Sniper-Kauf und Rechnung im Briefkasten gelten als derselbe Kauf
local AH_MAIL_DAYS = 30        -- so lange liegt Auktionspost im Briefkasten

local function DB()
    return A.db and A.db.ledger
end

-- ------------------------------------------------------------
-- Buchen
-- kind: "sale" (Verkauf, amount = Preis brutto, cut = AH-Anteil, refund = Einstellgebühr zurück)
--       "buy"  (Kauf, amount = bezahlter Preis)
--       "deposit" (Einstellgebühr, amount = Gebühr)
-- ------------------------------------------------------------
function Le:Add(e)
    local db = DB()
    if not db then return nil end
    e.t = e.t or time()
    e.qty = e.qty or 1
    e.amount = math.floor(e.amount or 0)
    if not e.name and e.itemID then e.name = A:GetItemName(e.itemID) end
    table.insert(db.entries, e)
    self:Prune()
    A:Fire("LEDGER_CHANGED")
    return e
end

function Le:Prune()
    local db = DB()
    local cutoff = time() - KEEP_DAYS * 86400
    local list = db.entries
    if #list > MAX_ENTRIES or (list[1] and list[1].t < cutoff) then
        local keep = {}
        for _, e in ipairs(list) do if e.t >= cutoff then table.insert(keep, e) end end
        while #keep > MAX_ENTRIES do table.remove(keep, 1) end
        db.entries = keep
    end
    for key, t in pairs(db.seen) do
        if t < time() - (AH_MAIL_DAYS + 5) * 86400 then db.seen[key] = nil end
    end
end

-- Item-ID aus dem Namen in der Rechnung (Name in der Sprache des Clients)
local function ResolveName(name)
    if not name or name == "" then return nil end
    if GetItemInfo then
        local ok, _, link = pcall(GetItemInfo, name)
        if ok and type(link) == "string" then
            local id = tonumber(link:match("item:(%d+)"))
            if id then return id end
        end
    end
    if A.Names then
        local id = A.Names:Resolve(name)
        if id then return id end
    end
    return nil
end

-- ------------------------------------------------------------
-- Briefkasten lesen
-- ------------------------------------------------------------
function Le:ScanInbox()
    local db = DB()
    if not db or not A.Inbox.Available() or not (_G.GetInboxInvoiceInfo or A:Simulated()) then return 0 end
    local n = GetInboxNumItems() or 0
    local added = 0
    local now = time()
    for i = 1, n do
        local okH, _, _, sender, subject, money, cod, daysLeft = pcall(GetInboxHeaderInfo, i)
        local okI, invoiceType, itemName, playerName, bid, buyout, deposit, consignment, _, _, count = pcall(GetInboxInvoiceInfo, i)
        if okH and okI and (invoiceType == "seller" or invoiceType == "buyer") and itemName then
            -- Ankunftszeit aus der Restlaufzeit (Auktionspost bleibt 30 Tage)
            local arrived = now - math.floor(((AH_MAIL_DAYS - (daysLeft or AH_MAIL_DAYS)) * 86400) + 0.5)
            local hour = math.floor(arrived / 3600)
            count = count or 1
            local price = (invoiceType == "seller") and (buyout or bid or 0) or (bid or buyout or 0)
            local base = table.concat({ invoiceType, itemName, tostring(playerName or ""), tostring(price), tostring(count) }, "|")
            local key = base .. "|" .. hour
            -- gleiche Rechnung beim nächsten Öffnen evtl. eine Stunde verschoben (Rundung)
            if not db.seen[key] and not db.seen[base .. "|" .. (hour - 1)] and not db.seen[base .. "|" .. (hour + 1)] then
                db.seen[key] = now
                local itemID = ResolveName(itemName)
                if invoiceType == "seller" then
                    if A:IsForever() then
                        -- L1 (Prüfung 11:55): in Forever ist die einzige Gebühr beim Einstellen schon gebucht. Erlös = Gold,
                        -- das die Post wirklich bringt; Anteil/Einzahlung der Rechnung nur merken, nicht verrechnen.
                        local got = (type(money) == "number" and money > 0) and money or (price - (consignment or 0))
                        self:Add({ kind = "sale", t = arrived, itemID = itemID, name = itemName, qty = count,
                                   amount = got, cut = 0, refund = 0, player = playerName, src = "mail",
                                   inv = { price = price, cut = consignment or 0, deposit = deposit or 0, money = money or 0 } })
                        if A.Diag then
                            A.Diag:Add("RECHNUNG", string.format("Item %s · Menge %d · Preis %d · consignment %d · deposit %d · Post-Gold %d",
                                tostring(itemID or "?"), count, price or 0, consignment or 0, deposit or 0, money or 0))
                        end
                    else
                        self:Add({ kind = "sale", t = arrived, itemID = itemID, name = itemName, qty = count,
                                   amount = price, cut = consignment or 0, refund = deposit or 0, player = playerName, src = "mail" })
                    end
                    added = added + 1
                else
                    -- schon über den Sniper gebucht?
                    local match = self:FindUnmatchedBuy(itemID, itemName, count, price, arrived)
                    if match then
                        match.mail = true
                        match.player = match.player or playerName
                    else
                        self:Add({ kind = "buy", t = arrived, itemID = itemID, name = itemName, qty = count,
                                   amount = price, player = playerName, src = "mail" })
                        added = added + 1
                    end
                end
            end
        end
    end
    if added > 0 then
        A:Print(added == 1 and L["Buchhaltung: 1 neue Rechnung aus dem Briefkasten gebucht."]
            or string.format(L["Buchhaltung: %d neue Rechnungen aus dem Briefkasten gebucht."], added))
    end
    return added
end

function Le:FindUnmatchedBuy(itemID, itemName, qty, amount, t)
    for _, e in ipairs(DB().entries) do
        if e.kind == "buy" and (e.src == "sniper" or e.src == "buy") and not e.mail and e.qty == qty and e.amount == amount
            and math.abs(e.t - t) <= MATCH_WINDOW and ((itemID and e.itemID == itemID) or e.name == itemName) then
            return e
        end
    end
    return nil
end

-- ------------------------------------------------------------
-- Auswertung
-- ------------------------------------------------------------
Le.PERIODS = {
    { key = "today", label = "Heute" },
    { key = "7", label = "7 Tage", days = 7 },
    { key = "30", label = "30 Tage", days = 30 },
    { key = "all", label = "Alles" },
}

function Le:PeriodStart(key)
    if key == "today" then
        local d = date("*t", time())
        return time({ year = d.year, month = d.month, day = d.day, hour = 0, min = 0, sec = 0 })
    end
    for _, p in ipairs(self.PERIODS) do
        if p.key == key and p.days then return time() - p.days * 86400 end
    end
    return 0
end

function Le:GetEntries(key)
    local from = self:PeriodStart(key)
    local out = {}
    for _, e in ipairs(DB().entries) do
        if e.t >= from then table.insert(out, e) end
    end
    return out
end

-- Summen: income (Verkäufe nach AH-Anteil), spent (Käufe), fees (Einstellgebühren minus Erstattungen), profit
function Le:Summary(key)
    local s = { income = 0, gross = 0, cut = 0, spent = 0, fees = 0, refunds = 0, sales = 0, buys = 0 }
    for _, e in ipairs(self:GetEntries(key)) do
        if e.kind == "sale" then
            s.gross = s.gross + e.amount
            s.cut = s.cut + (e.cut or 0)
            s.income = s.income + e.amount - (e.cut or 0)
            s.refunds = s.refunds + (e.refund or 0)
            s.sales = s.sales + 1
        elseif e.kind == "buy" then
            s.spent = s.spent + e.amount
            s.buys = s.buys + 1
        elseif e.kind == "deposit" then
            s.fees = s.fees + e.amount
        elseif e.kind == "refund" then
            s.refunds = s.refunds + (e.amount or 0)       -- Erstattung beim Abbrechen (L2)
        end
    end
    s.fees = s.fees - s.refunds
    s.profit = s.income - s.spent - s.fees
    return s
end

-- pro Item: verkauft, Erlös (nach AH-Anteil), gekauft, Kosten, Gebühren, Gewinn
function Le:ByItem(key)
    local by, list = {}, {}
    for _, e in ipairs(self:GetEntries(key)) do
        local id = e.itemID or e.name or "?"
        local r = by[id]
        if not r then
            r = { itemID = e.itemID, name = e.itemID and A:GetItemName(e.itemID) or e.name or "?", soldQty = 0, income = 0,
                  boughtQty = 0, spent = 0, fees = 0 }
            by[id] = r
            table.insert(list, r)
        end
        if e.kind == "sale" then
            r.soldQty = r.soldQty + e.qty
            r.income = r.income + e.amount - (e.cut or 0)
            r.fees = r.fees - (e.refund or 0)
        elseif e.kind == "buy" then
            r.boughtQty = r.boughtQty + e.qty
            r.spent = r.spent + e.amount
        elseif e.kind == "deposit" then
            r.fees = r.fees + e.amount
        elseif e.kind == "refund" then
            r.fees = r.fees - (e.amount or 0)
        end
    end
    for _, r in ipairs(list) do r.profit = r.income - r.spent - r.fees end
    return list
end

-- ------------------------------------------------------------
-- Statistik: Verkaufsquote und beste Verkaufszeit
-- ------------------------------------------------------------
-- Zeitpunkt des Verkaufs: Rechnungen kommen ca. 1 Std. nach dem Verkauf
function Le:SaleTime(e)
    if e.src == "mail" then return e.t - 3600 end
    return e.t
end

-- items: pro Item eingestellt / verkauft / Quote / Ø Preis
-- hours[0..23], weekdays[1..7] (1 = Montag): Anzahl Verkäufe und Erlös
function Le:Stats(key)
    local by, items = {}, {}
    local hours, weekdays = {}, {}
    for h = 0, 23 do hours[h] = { n = 0, income = 0 } end
    for d = 1, 7 do weekdays[d] = { n = 0, income = 0 } end
    for _, e in ipairs(self:GetEntries(key)) do
        if e.kind == "sale" or (e.kind == "deposit" and e.src == "post") then
            local id = e.itemID or e.name or "?"
            local r = by[id]
            if not r then
                r = { itemID = e.itemID, name = e.itemID and A:GetItemName(e.itemID) or e.name or "?", posted = 0, sold = 0, income = 0 }
                by[id] = r
                table.insert(items, r)
            end
            if e.kind == "sale" then
                r.sold = r.sold + e.qty
                r.income = r.income + e.amount - (e.cut or 0)
                local t = self:SaleTime(e)
                local h = tonumber(date("%H", t))
                local wd = tonumber(date("%w", t))       -- 0 = Sonntag
                wd = (wd == 0) and 7 or wd
                hours[h].n = hours[h].n + 1
                hours[h].income = hours[h].income + e.amount - (e.cut or 0)
                weekdays[wd].n = weekdays[wd].n + 1
                weekdays[wd].income = weekdays[wd].income + e.amount - (e.cut or 0)
            else
                r.posted = r.posted + e.qty
            end
        end
    end
    for _, r in ipairs(items) do
        r.rate = (r.posted > 0) and math.min(100, r.sold / r.posted * 100) or nil
        r.avg = (r.sold > 0) and math.floor(r.income / r.sold + 0.5) or nil
    end
    -- beste Stunden (nach Anzahl Verkäufe)
    local best = {}
    for h = 0, 23 do if hours[h].n > 0 then table.insert(best, h) end end
    table.sort(best, function(a, b) return hours[a].n > hours[b].n end)
    return { items = items, hours = hours, weekdays = weekdays, best = best }
end

-- Durchschnittlicher Einkaufspreis pro Stück (für die Gewinnrechnung beim Verkaufen)
-- wie oft wurde das Item in den letzten x Tagen verkauft (eigene Verkäufe)
function Le:SoldCount(itemID, days)
    local from = time() - (days or 30) * 86400
    local n = 0
    for _, e in ipairs(DB().entries) do
        if e.kind == "sale" and e.itemID == itemID and e.t >= from then n = n + 1 end
    end
    return n
end

-- Stück je Auktion der letzten n eigenen Einstellungen dieses Items (L5, für die Gebühr im Gewinn-Fenster)
function Le:PostSizes(itemID, n)
    local out = {}
    local entries = DB() and DB().entries or {}
    for i = #entries, 1, -1 do
        local e = entries[i]
        if e.kind == "deposit" and e.src == "post" and e.itemID == itemID and (e.qty or 0) > 0 then
            out[#out + 1] = math.max(1, math.floor((e.qty or 1) / math.max(1, e.auctions or 1) + 0.5))
            if #out >= (n or 10) then break end
        end
    end
    return out
end

-- Ø Verkaufspreis pro Stück (brutto) aus echten Verkäufen der letzten Tage
function Le:AverageSalePrice(itemID, days)
    local from = time() - (days or 14) * 86400
    local qty, sum = 0, 0
    for _, e in ipairs(DB().entries) do
        if e.kind == "sale" and e.itemID == itemID and e.t >= from and (e.qty or 0) > 0 then
            qty = qty + e.qty
            sum = sum + (e.amount or 0)
        end
    end
    if qty == 0 then return nil end
    return math.floor(sum / qty + 0.5), qty
end

function Le:AverageBuyPrice(itemID, days)
    local from = time() - (days or 30) * 86400
    local qty, cost = 0, 0
    for _, e in ipairs(DB().entries) do
        if e.kind == "buy" and e.itemID == itemID and e.t >= from then
            qty = qty + e.qty
            cost = cost + e.amount
        end
    end
    if qty == 0 then return nil end
    return math.floor(cost / qty + 0.5), qty
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
-- Einstellgebühr beim Einstellen über den Tab Verkaufen
-- (auch ohne Gebühr gebucht: zählt als "eingestellt" für die Verkaufsquote)
A:On("AUCTION_POSTED", function(p)
    if p and p.itemID then
        -- wirklich abgezogen (Gold vorher - nachher), sonst die erwartete Gebühr
        Le:Add({ kind = "deposit", itemID = p.itemID, qty = p.qty or 1, auctions = p.auctions or 1, amount = p.measured or p.deposit or 0, src = "post" })
    end
end)

-- L2: Erstattung beim Abbrechen (gemessen: Gold nachher - vorher) buchen
A:On("AUCTION_CANCELLED", function(c)
    if not (c and c.money) then return end
    local function book()
        local now = GetMoney and GetMoney() or 0
        local back = now - c.money
        if back > 0 and back < 100000000 then
            Le:Add({ kind = "refund", itemID = c.itemID, qty = c.qty or 1, amount = back, src = "cancel" })
        end
        if A.Diag then A.Diag:Add("ABBRUCH", string.format("Item %s · Menge %d · Erstattung %d", tostring(c.itemID or "?"), c.qty or 1, math.max(0, back))) end
    end
    if C_Timer and C_Timer.After then C_Timer.After(0.5, book) else book() end
end)

local evt = CreateFrame("Frame")
local function Reg(e) A:RegisterAHEvent(evt, e) end
Reg("MAIL_SHOW")
Reg("MAIL_INBOX_UPDATE")
Reg("AUCTION_HOUSE_PURCHASE_COMPLETED")
Reg("COMMODITY_PURCHASE_SUCCEEDED")

local scanPending = false
evt:SetScript("OnEvent", function(_, event)
    if event == "MAIL_SHOW" or event == "MAIL_INBOX_UPDATE" then
        -- mehrere Ereignisse kurz hintereinander: einmal lesen
        if scanPending then return end
        scanPending = true
        C_Timer.After(0.5, function()
            scanPending = false
            local ok, err = pcall(Le.ScanInbox, Le)
            if not ok then A:Print(L["Buchhaltung: Fehler beim Lesen der Post: "] .. tostring(err)) end
        end)
    elseif event == "AUCTION_HOUSE_PURCHASE_COMPLETED" or event == "COMMODITY_PURCHASE_SUCCEEDED" then
        -- Kauf über den Sniper: sofort buchen (die Rechnung im Briefkasten wird später zugeordnet)
        local lp = A.Sniper and A.Sniper.lastPurchase
        if lp and not lp.booked and GetTime() - lp.time < 15 then
            lp.booked = true
            local itemID = lp.itemID
            Le:Add({ kind = "buy", itemID = itemID, qty = lp.qty, amount = lp.cost, src = "sniper" })
        end
        -- Kauf im Reiter Einkauf
        local bp = A.Buy and A.Buy.lastPurchase
        if bp and not bp.booked and bp.cost and GetTime() - bp.time < 15 then
            bp.booked = true
            Le:Add({ kind = "buy", itemID = bp.itemID, qty = bp.qty, amount = bp.cost, src = "buy" })
        end
    end
end)

function Le:GetDebugText()
    local db = DB()
    if not db then return "-" end
    return #db.entries .. " Buchungen, Briefkasten-API=" .. ((_G.GetInboxInvoiceInfo and L["ja"]) or L["nein"])
end
