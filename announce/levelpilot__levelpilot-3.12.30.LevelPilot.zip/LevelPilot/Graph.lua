-- LevelPilot - Wegenetz & Wegfindung
-- Knoten: Weltpunkte (Kontinent, Nord, West, Zone). Kanten: gelaufene Wege (eigene
-- oder von anderen Spielern), Zonenuebergaenge, Schiffe. Suche: A*.
-- Regel fuer "nur moegliche Wege": Ohne bekannte Kante darf der Weg nur INNERHALB
-- einer Zone per Luftlinie verbunden werden. Zonenwechsel nur ueber Uebergaenge
-- oder gelaufene Wege.

local _, LP = ...
local L = LP.L
local Graph = {}
LP:RegisterModule("Graph", Graph)

local CELL       = 100    -- Rasterzelle fuer die Umgebungssuche (Yards)
local SNAP       = 10     -- Punkte naeher als das werden zusammengelegt
local VIRT_RANGE = 260    -- Luftlinien-Verbindung zu gelaufenen Knoten in dieser Reichweite
local VIRT_MULT  = 1.45   -- Luftlinie ist unsicher -> teurer
local RUN_SPEED  = 7      -- Yards pro Sekunde (fuer Schiffs-/Wartezeiten)
local MAX_NODES  = 40000
local MAX_NET_NODES = 30000
local MAX_EXPAND = 8000
local STATIC_BASE = 10000000   -- IDs der Startdatenbank-Wege (nicht gespeichert)

local G            -- gespeicherte Daten (LP.db.graph)
local adj = {}     -- [id] = { [nachbar] = kante }
local grid = {}    -- ["inst:cn:cw"] = { id, ... }
local nodes = {}   -- Laufzeit-Knoten (gespeicherte + Uebergaenge)
local gwByZone = {}
local gwEdges = {}
local staticCount, staticEdges = 0, 0

------------------------------------------------------------------------
-- Hilfen
------------------------------------------------------------------------
local function CellKey(inst, n, w)
    return inst .. ":" .. math.floor(n / CELL) .. ":" .. math.floor(w / CELL)
end

local virtCache, virtCount = {}, 0     -- 3.12.24: Luftlinien-Nachbarn je Knoten (leer bei jeder Aenderung)
local function GridAdd(id, nd)
    if virtCount > 0 then virtCache, virtCount = {}, 0 end
    local k = CellKey(nd[1], nd[2], nd[3])
    local list = grid[k]
    if not list then list = {} grid[k] = list end
    list[#list + 1] = id
end

local function EdgeKey(a, b)
    if a < b then return a .. ":" .. b end
    return b .. ":" .. a
end

local function Link(a, b, e)
    adj[a] = adj[a] or {}
    adj[b] = adj[b] or {}
    adj[a][b] = e
    adj[b][a] = e
end

local function Dist(a, b)
    local dn, dw = a[2] - b[2], a[3] - b[3]
    return math.sqrt(dn * dn + dw * dw)
end

------------------------------------------------------------------------
-- Aufbau
------------------------------------------------------------------------
function Graph:Init()
    LP.db.graph = LP.db.graph or {}
    G = LP.db.graph
    G.nodes = G.nodes or {}
    G.edges = G.edges or {}
    G.nextId = G.nextId or 1
    G.count = G.count or 0
    if type(G.blocked) ~= "table" then G.blocked = {} end      -- 3.12.10: gesperrte Kanten (Sackgassen) [Schluessel] = { t, why }
    G.netCount = G.netCount or 0

    wipe(adj) wipe(grid) wipe(nodes) wipe(gwByZone) wipe(gwEdges)
    for id, nd in pairs(G.nodes) do
        nodes[id] = nd
        GridAdd(id, nd)
    end
    for _, e in pairs(G.edges) do
        if nodes[e[1]] and nodes[e[2]] then Link(e[1], e[2], e) end
    end
    self:BuildGateways()
    self:LoadStatic(LP.Seed and LP.Seed.paths)
    -- 3.12.17 einmalig: lose Enden bestehender Wegstuecke an das Netz haengen (nichts geht verloren)
    -- 3.12.23 einmalig: lange gerade Stuecke aus aelteren Versionen in Stuecke <= 25 Yards teilen, danach nochmals
    -- lose Enden anhaengen
    -- 3.12.24: in Portionen im Hintergrund (vorher am Stueck beim Einloggen)
    -- 3.12.25: wer 3.12.23 schon gestartet hat (joinVer 2), bei dem sind auch Luecken von 25–80 Yards geteilt; diese
    -- Stuecke werden erkannt und als unsicher markiert (joinVer 3)
    local ver = G.joinVer or 0
    if ver < 3 then
        LP.Jobs.Start("graphfix", "graph", function()
            if ver < 2 then
                Graph:Densify()
                Graph:JoinLooseEnds()
            else
                Graph:MarkSplitGaps()
            end
        end, function(ok, err)
            if ok then G.joinVer = 3 else LP:Error(L["Wegnetz verbinden"], err) end
        end, { graph = true })
    end
end

-- 3.12.23: gespeicherte Kanten laenger als SEG_MAX Yards teilen. Die Kanten stammen aus gelaufenen Spuren, die
-- aeltere Versionen mit bis zu 6 Yards Abweichung zu geraden Stuecken vereinfacht haben; die Zwischenpunkte liegen
-- auf dieser Linie (kein neues Gelaende). Knoten nur bis 1000 unter der Hoechstzahl. Rueckgabe: geteilte Kanten.
Graph.SEG_MAX = 25
-- 3.12.24: geteilt werden nur Kanten ueber DENSIFY_MIN Yards. Laenger als die alte Sprunggrenze (80 Yards) kann
-- eine Kante nur durch die alte Vereinfachung gelaufener Spuren entstehen (bis 6 Yards Abweichung), nie durch eine
-- einzelne Luecke zwischen zwei Aufzeichnungen.
Graph.DENSIFY_MIN = 80
local DENSIFY_KINDS = { r = true, s = true, w = true }
function Graph:Densify(maxLen)
    maxLen = maxLen or self.SEG_MAX
    local list = {}
    for key, e in pairs(G.edges) do
        local a, b = nodes[e[1]], nodes[e[2]]
        if DENSIFY_KINDS[e[3]] and a and b and a[1] == b[1] and a[4] and a[4] == b[4]
           and LP.Geo:ContinentOf(a[4]) ~= a[4] then
            local len = math.sqrt((b[2] - a[2]) ^ 2 + (b[3] - a[3]) ^ 2)
            if len > maxLen + 0.5 then list[#list + 1] = { key = key, e = e, len = len } end
        end
    end
    table.sort(list, function(x, y) return x.key < y.key end)
    local split = 0
    for _, it in ipairs(list) do
        LP:Yield("graph")
        local e = it.e
        if G.edges[it.key] == e then                      -- sonst inzwischen geaendert
            local k = math.ceil(it.len / maxLen)
            if it.len <= self.DENSIFY_MIN then
                -- 3.12.24: 25–80 Yards kann auch eine Luecke zwischen zwei Aufzeichnungen sein (3.12.17–3.12.22):
                -- nicht teilen, nur als unsicher markieren (etwas teurer, bis der Weg nochmals gelaufen wird)
                e.u = 1
            elseif G.count + k > MAX_NODES - 1000 then
                break
            else
                local a, b = nodes[e[1]], nodes[e[2]]
                local fromNet = e[3] == "s"
                local cur, last = e, e[2]
                for j = 1, k - 1 do
                    -- 3.12.24: erst pruefen, dann den Knoten anlegen (kein verwaister Knoten)
                    if not cur or G.edges[EdgeKey(cur[1], cur[2])] ~= cur then break end
                    local t = j / k
                    local id = G.nextId
                    G.nextId = id + 1
                    local nd = { a[1], math.floor((a[2] + t * (b[2] - a[2])) * 10 + 0.5) / 10,
                                 math.floor((a[3] + t * (b[3] - a[3])) * 10 + 0.5) / 10, a[4], 1 }
                    if fromNet then nd.net = true G.netCount = G.netCount + 1 end
                    G.nodes[id], nodes[id] = nd, nd
                    G.count = G.count + 1
                    GridAdd(id, nd)
                    self:SplitEdge(cur, id)
                    cur = G.edges[EdgeKey(id, last)]
                end
                split = split + 1
            end
        end
    end
    if split > 0 then LP:Fire("GRAPH_CHANGED") end
    return split
end

-- 3.12.25: von 3.12.23 geteilte Luecken (25–80 Yards) wiederfinden: eine Kette aus Knoten mit genau zwei Kanten,
-- exakt auf einer Linie und in gleichen Abstaenden (so legt Densify die Punkte; gelaufene Punkte liegen nie so genau),
-- insgesamt 25–80 Yards lang. Ihre Kanten werden als unsicher markiert (nichts wird geloescht). Rueckgabe: Ketten.
local function Deg(id) local d = 0 for _ in pairs(adj[id] or {}) do d = d + 1 end return d end
local function Others(id, not1)
    for v in pairs(adj[id] or {}) do if v ~= not1 then return v end end
end
-- ist m ein von Densify gelegter Mittelpunkt zwischen a und b?
local function Mid(a, m, b)
    local A, M, B = nodes[a], nodes[m], nodes[b]
    if not (A and M and B) then return false end
    local d1 = math.sqrt((M[2] - A[2]) ^ 2 + (M[3] - A[3]) ^ 2)
    local d2 = math.sqrt((B[2] - M[2]) ^ 2 + (B[3] - M[3]) ^ 2)
    if d1 < 1 or math.abs(d1 - d2) > 0.3 then return false end
    -- Abstand von M zur Linie A–B
    local dn, dw = B[2] - A[2], B[3] - A[3]
    local len = math.sqrt(dn * dn + dw * dw)
    if len < 1 then return false end
    return math.abs((M[2] - A[2]) * dw - (M[3] - A[3]) * dn) / len <= 0.2
end
function Graph:MarkSplitGaps()
    local seen, chains = {}, 0
    local ids = {}
    for id in pairs(G.nodes) do ids[#ids + 1] = id end
    table.sort(ids)
    for _, id in ipairs(ids) do
        LP:Yield("graph")
        if not seen[id] and Deg(id) == 2 then
            local a = next(adj[id])
            local b = Others(id, a)
            if a and b and Mid(a, id, b) then
                -- Kette in beide Richtungen verlaengern, solange die Punkte gleich weit auf der Linie liegen
                local chain = { id }
                seen[id] = true
                local left, prevL = a, id
                while Deg(left) == 2 and not seen[left] do
                    local nx = Others(left, prevL)
                    if not nx or not Mid(prevL, left, nx) then break end
                    seen[left] = true
                    table.insert(chain, 1, left)
                    prevL, left = left, nx
                end
                local right, prevR = b, id
                while Deg(right) == 2 and not seen[right] do
                    local nx = Others(right, prevR)
                    if not nx or not Mid(prevR, right, nx) then break end
                    seen[right] = true
                    chain[#chain + 1] = right
                    prevR, right = right, nx
                end
                local A, B = nodes[left], nodes[right]
                local len = A and B and math.sqrt((B[2] - A[2]) ^ 2 + (B[3] - A[3]) ^ 2) or 0
                if len > self.SEG_MAX and len <= self.DENSIFY_MIN then
                    table.insert(chain, 1, left)
                    chain[#chain + 1] = right
                    for k = 2, #chain do
                        local e = G.edges[EdgeKey(chain[k - 1], chain[k])]
                        if e then e.u = 1 end
                    end
                    chains = chains + 1
                end
            end
        end
    end
    return chains
end

-- lose Enden (Knoten mit nur einer Kante) an die naechste Kante bis JOIN Yards haengen; Rueckgabe Anzahl
function Graph:JoinLooseEnds()
    local ends = {}
    for id in pairs(G.nodes) do
        local deg = 0
        for _ in pairs(adj[id] or {}) do deg = deg + 1 end
        if deg == 1 then ends[#ends + 1] = id end
    end
    table.sort(ends)
    local n = 0
    for _, id in ipairs(ends) do
        LP:Yield("graph")
        if nodes[id] and self:Join(id, { [id] = true }) then n = n + 1 end
    end
    if n > 0 then LP:Fire("GRAPH_CHANGED") end
    return n
end

-- Wege der Startdatenbank: { {inst, n1, w1, zone1, n2, w2, zone2, anzahl}, ... }
function Graph:LoadStatic(segments)
    staticCount, staticEdges = 0, 0
    if type(segments) ~= "table" then return end
    local nextId = STATIC_BASE
    local function node(inst, n, w, zone)
        local id = self:Nearest(inst, n, w, SNAP, zone, function(i) return i >= STATIC_BASE end)
        if id then return id end
        nextId = nextId + 1
        nodes[nextId] = { inst, n, w, zone ~= 0 and zone or nil, 1, static = true }
        GridAdd(nextId, nodes[nextId])
        staticCount = staticCount + 1
        return nextId
    end
    for _, s in ipairs(segments) do
        local a = node(s[1], s[2], s[3], s[4])
        local b = node(s[1], s[5], s[6], s[7])
        if a ~= b then
            Link(a, b, { a, b, "seed", s[8] or 1 })
            staticEdges = staticEdges + 1
        end
    end
end

-- Zonenuebergaenge als Laufzeit-Knoten (negative IDs, nicht gespeichert)
function Graph:BuildGateways()
    local faction = LP:PlayerFaction()
    local gid = -1
    for _, g in ipairs(LP.Gateways or {}) do
        local mapA, xA, yA, mapB, xB, yB, kind, secs, fac, name = unpack(g)
        if not fac or fac == faction then
            local iA, nA, wA = LP.Geo:ToWorld(mapA, xA, yA)
            local iB, nB, wB = LP.Geo:ToWorld(mapB, xB, yB)
            if iA and iB then
                local a, b = gid, gid - 1
                gid = gid - 2
                nodes[a] = { iA, nA, wA, mapA, 0, gw = true, name = name }
                nodes[b] = { iB, nB, wB, mapB, 0, gw = true, name = name }
                GridAdd(a, nodes[a]) GridAdd(b, nodes[b])
                gwByZone[mapA] = gwByZone[mapA] or {}
                gwByZone[mapB] = gwByZone[mapB] or {}
                table.insert(gwByZone[mapA], a)
                table.insert(gwByZone[mapB], b)
                local e = { a, b, kind == "walk" and "g" or kind, 1, secs = secs, name = name }
                gwEdges[#gwEdges + 1] = e
                Link(a, b, e)
            end
        end
    end
end

------------------------------------------------------------------------
-- Suche in der Umgebung
------------------------------------------------------------------------
function Graph:Near(inst, n, w, radius, zone)
    local out = {}
    local r = math.ceil(radius / CELL)
    local cn, cw = math.floor(n / CELL), math.floor(w / CELL)
    for dn = -r, r do
        for dw = -r, r do
            local list = grid[inst .. ":" .. (cn + dn) .. ":" .. (cw + dw)]
            if list then
                for i = 1, #list do
                    local id = list[i]
                    local nd = nodes[id]
                    if nd and (not zone or nd[4] == zone) then
                        local d = math.sqrt((nd[2] - n) ^ 2 + (nd[3] - w) ^ 2)
                        if d <= radius then out[#out + 1] = id end
                    end
                end
            end
        end
    end
    return out
end

-- 3.12.24: fuer Luftlinien in der Wegsuche je Rasterzelle (100 Yards) nur die naechsten VIRT_PER_CELL Knoten.
-- Bei dichten Wegnetzen (Punkte alle 12–25 Yards) lieferte Near() hunderte Knoten je Schritt der Suche, und jede
-- Luftlinie wurde gegen die Gelaendekarte geprueft – das liess das Spiel nach dem Einloggen einfrieren.
Graph.VIRT_PER_CELL = 2
function Graph:NearSparse(inst, n, w, radius, zone, out)
    out = out or {}
    local per = self.VIRT_PER_CELL
    local r = math.ceil(radius / CELL)
    local cn, cw = math.floor(n / CELL), math.floor(w / CELL)
    local r2 = radius * radius
    for dn = -r, r do
        for dw = -r, r do
            local list = grid[inst .. ":" .. (cn + dn) .. ":" .. (cw + dw)]
            if list then
                local b1, d1, b2, d2
                for i = 1, #list do
                    local id = list[i]
                    local nd = nodes[id]
                    if nd and (not zone or nd[4] == zone) then
                        local dd = (nd[2] - n) ^ 2 + (nd[3] - w) ^ 2
                        if dd <= r2 then
                            if not d1 or dd < d1 then b2, d2 = b1, d1 b1, d1 = id, dd
                            elseif per > 1 and (not d2 or dd < d2) then b2, d2 = id, dd end
                        end
                    end
                end
                if b1 then out[#out + 1] = b1 end
                if b2 and per > 1 then out[#out + 1] = b2 end
            end
        end
    end
    return out
end

function Graph:Nearest(inst, n, w, radius, zone, filter)
    local best, bestD
    for _, id in ipairs(self:Near(inst, n, w, radius, zone)) do
        local nd = nodes[id]
        if filter and not filter(id) then nd = nil end
        if nd then
        local d = math.sqrt((nd[2] - n) ^ 2 + (nd[3] - w) ^ 2)
        if not bestD or d < bestD then best, bestD = id, d end
        end
    end
    return best, bestD
end

------------------------------------------------------------------------
-- Hinzufuegen (aus Aufzeichnung oder vom Netzwerk)
------------------------------------------------------------------------
function Graph:AddNode(inst, n, w, zone, fromNet)
    local id = self:Nearest(inst, n, w, SNAP, zone, function(i) return i > 0 and i < STATIC_BASE end)
    if id then
        local nd = nodes[id]
        nd[5] = (nd[5] or 0) + 1
        return id, false
    end
    if G.count >= MAX_NODES then return nil end
    if fromNet and G.netCount >= MAX_NET_NODES then return nil end
    id = G.nextId
    G.nextId = id + 1
    local nd = { inst, math.floor(n * 10 + 0.5) / 10, math.floor(w * 10 + 0.5) / 10, zone, 1 }
    if fromNet then nd.net = true G.netCount = G.netCount + 1 end
    G.nodes[id] = nd
    nodes[id] = nd
    G.count = G.count + 1
    GridAdd(id, nd)
    return id, true
end

-- kind: "r" = selbst gelaufen, "s" = von anderen Spielern, "w" = geschwommen
-- consent: Urheber hat das Wegstueck fuer die Startdatenbank freigegeben
function Graph:AddEdge(a, b, kind, consent)
    if not a or not b or a == b then return false end
    local key = EdgeKey(a, b)
    local e = G.edges[key]
    if e then
        e[4] = (e[4] or 1) + 1
        e.u = nil                                         -- nochmals gelaufen: sicher
        if kind == "r" and e[3] == "s" then e[3] = "r" end
        if consent then e.c = true end
        return false
    end
    e = { a, b, kind, 1, c = consent or nil }
    G.edges[key] = e
    Link(a, b, e)
    return true
end

-- 3.12.17: Wegstuecke verbinden. Liegt ein neuer Knoten bis JOIN Yards neben einer bestehenden Kante (nicht an
-- ihrem Ende), wird die Kante dort geteilt und der Knoten eingehaengt – so haengen Anfang und Ende eines neuen
-- Wegstuecks und Kreuzungen am bestehenden Netz (vorher zerfiel das Netz einer Zone in viele Teile).
Graph.JOIN = 10
local JOIN_SEARCH = 70          -- Knoten in dieser Reichweite liefern die Kandidaten-Kanten

-- naechste gespeicherte Kante (gleiche Zone) zum Punkt, ohne Kanten an den Knoten in skip
function Graph:NearestEdge(inst, n, w, zone, radius, skip)
    local best, bestD, bestT
    local seen = {}
    for _, id in ipairs(self:Near(inst, n, w, JOIN_SEARCH, zone)) do
        if adj[id] and not (skip and skip[id]) then
            for v, e in pairs(adj[id]) do
                local key = (type(v) == "number" and v > 0 and id > 0) and EdgeKey(id, v) or nil
                if key and not seen[key] and G.edges[key] == e and not (skip and skip[v]) then
                    seen[key] = true
                    local a, b = nodes[e[1]], nodes[e[2]]
                    if a and b and a[4] == zone and b[4] == zone then
                        local dn, dw = b[2] - a[2], b[3] - a[3]
                        local len2 = dn * dn + dw * dw
                        if len2 > 0 then
                            local t = ((n - a[2]) * dn + (w - a[3]) * dw) / len2
                            if t > 0 and t < 1 then
                                local d = math.sqrt((a[2] + t * dn - n) ^ 2 + (a[3] + t * dw - w) ^ 2)
                                if d <= radius and (not bestD or d < bestD) then best, bestD, bestT = e, d, t end
                            end
                        end
                    end
                end
            end
        end
    end
    return best, bestD, bestT
end

-- Kante e am Knoten mid teilen: a–b wird a–mid und mid–b (Herkunft, Anzahl, Freigabe und Sperre bleiben)
function Graph:SplitEdge(e, mid)
    local a, b = e[1], e[2]
    if not mid or mid == a or mid == b then return false end
    local key = EdgeKey(a, b)
    if G.edges[key] ~= e then return false end
    G.edges[key] = nil
    if adj[a] then adj[a][b] = nil end
    if adj[b] then adj[b][a] = nil end
    local blocked = G.blocked and G.blocked[key]
    if blocked then G.blocked[key] = nil end
    for _, pair in ipairs({ { a, mid }, { mid, b } }) do
        local k = EdgeKey(pair[1], pair[2])
        local old = G.edges[k]
        if old then
            old[4] = math.max(old[4] or 1, e[4] or 1)
        else
            local ne = { pair[1], pair[2], e[3], e[4] or 1, c = e.c, u = e.u }
            G.edges[k] = ne
            Link(pair[1], pair[2], ne)
        end
        if blocked then G.blocked[k] = { t = blocked.t, why = blocked.why } end
    end
    return true
end

-- neuen Knoten an die naechste Kante haengen (skip: Knoten, deren Kanten nicht in Frage kommen)
function Graph:Join(id, skip)
    local nd = nodes[id]
    if not nd or not nd[4] then return false end
    local e = self:NearestEdge(nd[1], nd[2], nd[3], nd[4], self.JOIN, skip)
    if not e then return false end
    return self:SplitEdge(e, id)
end

-- Polylinie: { {inst, n, w, zone}, ... }
function Graph:AddPolyline(points, kind, fromNet, consent)
    local prev, added, joined = nil, 0, 0
    for _, p in ipairs(points) do
        local id, created = self:AddNode(p[1], p[2], p[3], p[4], fromNet)
        -- neuer Knoten: an eine bestehende Kante anhaengen (nicht an die eben gelegte)
        if id and created and self:Join(id, prev and { [prev] = true } or nil) then joined = joined + 1 end
        if prev and id and self:AddEdge(prev, id, kind, consent) then added = added + 1 end
        prev = id or prev
    end
    if added > 0 or joined > 0 then LP:Fire("GRAPH_CHANGED") end
    return added, joined
end

-- 3.12.10: Kante als Sackgasse sperren (gespeichert, wird bei der Wegsuche nicht mehr genommen)
function Graph:Block(a, b, why)
    if type(a) ~= "number" or type(b) ~= "number" or a == b then return false end
    G.blocked = type(G.blocked) == "table" and G.blocked or {}
    G.blocked[EdgeKey(a, b)] = { t = time and time() or 0, why = why or "FEST" }
    return true
end
function Graph:Unblock(a, b)
    if G.blocked and type(a) == "number" and type(b) == "number" then G.blocked[EdgeKey(a, b)] = nil end
end
function Graph:IsBlocked(a, b)
    return type(a) == "number" and type(b) == "number" and G.blocked and G.blocked[EdgeKey(a, b)] ~= nil or false
end

function Graph:Stats()
    local edges, yards = 0, 0
    for _, e in pairs(G.edges) do
        local a, b = nodes[e[1]], nodes[e[2]]
        if a and b then
            edges = edges + 1
            yards = yards + Dist(a, b)
        end
    end
    return { nodes = G.count, netNodes = G.netCount, edges = edges, yards = yards, gateways = #gwEdges,
             seedNodes = staticCount, seedEdges = staticEdges }
end

function Graph:NodeById(id) return nodes[id] end
function Graph:Count() return G.count or 0 end         -- 3.12.24: Anzahl Wegpunkte ohne Zaehlschleife
function Graph:Neighbors(id) return adj[id] end      -- Testroutine (T235)

------------------------------------------------------------------------
-- A*-Suche
------------------------------------------------------------------------
-- Binaerer Heap
local function HeapPush(h, item, prio)
    local n = #h + 1
    h[n] = { item, prio }
    while n > 1 do
        local p = math.floor(n / 2)
        if h[p][2] <= h[n][2] then break end
        h[p], h[n] = h[n], h[p]
        n = p
    end
end

local function HeapPop(h)
    local top = h[1]
    if not top then return nil end
    local last = h[#h]
    h[#h] = nil
    if #h > 0 then
        h[1] = last
        local n = 1
        while true do
            local l, r, s = n * 2, n * 2 + 1, n
            if h[l] and h[l][2] < h[s][2] then s = l end
            if h[r] and h[r][2] < h[s][2] then s = r end
            if s == n then break end
            h[s], h[n] = h[n], h[s]
            n = s
        end
    end
    return top[1], top[2]
end

local function EdgeCost(e, a, b)
    local d = Dist(a, b)
    local k = e[3]
    if k == "boat" or k == "zep" or k == "tram" or k == "portal" then
        return (e.secs or 120) * RUN_SPEED + d * 0.05
    elseif k == "w" then
        return d * 1.8
    elseif k == "s" then
        return d * 1.05
    elseif k == "seed" then
        return d * 0.98
    elseif k == "g" then
        return d
    end
    -- selbst gelaufen: oft gelaufene Wege leicht bevorzugen; unsichere Kante (moegliche Luecke) etwas teurer
    return d * ((e[4] or 1) >= 3 and 0.95 or 1.0) * (e.u and 1.25 or 1)
end

-- Luftlinie quer ueber unbekanntes Gelaende (Berge, Felsen, Wasser) ist teurer. So gewinnen
-- gelaufene Wege durch Tunnel, Paesse und um Berge herum. Werte zwischen festen Knoten werden
-- zwischengespeichert (die Gelaendekarte aendert sich nicht).
local TERRAIN_PENALTY = 1.6
local DANGER_MULT = 25        -- Wegstueck durch Gebiet mit zu starken Mobs: so viel teurer
local TERRAIN_MIN = 80        -- Yards: kuerzere Luftlinien ohne Pruefung (kurze Spruenge queren keinen Berg)
local unkCache, unkCount = {}, 0
local function VirtCost(a, b, zone, ka, kb)
    local d = Dist(a, b)
    local c = d * VIRT_MULT
    if d > TERRAIN_MIN and zone and LP.Terrain and LP.Terrain.Unknown then
        local key = (type(ka) == "number" and type(kb) == "number") and (ka < kb and ka .. ":" .. kb or kb .. ":" .. ka) or nil
        local u = key and unkCache[key]
        if not u then
            local ok, v = pcall(LP.Terrain.Unknown, LP.Terrain, zone, a, b)
            u = ok and v or 0
            if key then
                if unkCount > 60000 then wipe(unkCache) unkCount = 0 end
                unkCache[key] = u
                unkCount = unkCount + 1
            end
        end
        c = c * (1 + TERRAIN_PENALTY * u)
    end
    return c
end
function Graph:ClearTerrainCache() wipe(unkCache) unkCount = 0 end
-- 3.12.30 SP1: Groesse der Zwischenspeicher (Diagnose): Luftlinien-Nachbarn, Gelaende-Pruefungen
function Graph:CacheSizes() return virtCount, unkCount end

-- Liefert eine Liste von Punkten {inst, n, w, zone} und die Art ("graph"/"direct"/nil).
-- Jeder Punkt traegt in .via die Art der Kante, ueber die er erreicht wurde
-- ("v" = Luftlinie, sonst die Kantenart aus dem Wegenetz, "g" = Zonenuebergang).
function Graph:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone, maxExpand)
    local S = { sInst, sn, sw, sZone }
    local T = { gInst, gn, gw, gZone }

    -- Ziel direkt in derselben Zone und nah: Luftlinie genuegt
    if sInst == gInst and sZone == gZone and Dist(S, T) < 60 then
        return { S, { gInst, gn, gw, gZone, via = "v" } }, "direct", Dist(S, T)
    end

    local function nodeOf(id)
        if id == "S" then return S end
        if id == "T" then return T end
        return nodes[id]
    end

    local function heuristic(nd)
        if nd[1] ~= gInst then return 0 end
        return Dist(nd, T)
    end

    -- Pflichtregel: Wegstuecke durch Gebiete mit Mobs ab Spielerlevel + 3 meiden (Umweg, wenn es einen gibt)
    local Dg = LP.Danger
    local lim = Dg and Dg.pathRule and Dg.Limit and Dg:Limit()
    local function guarded(a, b, cost, kind)
        if not lim or a[1] ~= b[1] or kind == "boat" or kind == "zep" or kind == "tram" or kind == "portal" then return cost end
        if Dg:Segment(a[1], a[2], a[3], b[2], b[3]) >= lim then return cost * DANGER_MULT end
        return cost
    end

    local gScore = { S = 0 }
    local came = {}
    local via = {}
    local open = {}
    local closed = {}
    HeapPush(open, "S", heuristic(S))
    local expanded = 0

    local function relax(u, v, cost, kind)
        local tentative = gScore[u] + cost
        if gScore[v] == nil or tentative < gScore[v] then
            gScore[v] = tentative
            came[v] = u
            via[v] = kind
            HeapPush(open, v, tentative + heuristic(nodeOf(v)))
        end
    end

    -- Luftlinie: Gelaende nur pruefen, wenn sie ueberhaupt kuerzer sein kann als das Bekannte
    -- (die Pruefung macht sie nur teurer, nie billiger)
    local function relaxVirt(u, v, a, b, zone, ka, kb)
        local base = Dist(a, b) * VIRT_MULT
        local known = gScore[v]
        if known and gScore[u] + base >= known then return end
        relax(u, v, guarded(a, b, VirtCost(a, b, zone, ka, kb), "v"), "v")
    end

    while true do
        local u = HeapPop(open)
        if not u then break end
        if u == "T" then break end
        if not closed[u] then
            closed[u] = true
            expanded = expanded + 1
            if expanded > (maxExpand or MAX_EXPAND) then break end
            if expanded % 2 == 0 then LP:Yield("graph") end   -- teure Knoten (viele Nachbarn, Gelaende): oft pruefen
            local un = nodeOf(u)

            -- gespeicherte Kanten
            if u ~= "S" and adj[u] then
                for v, e in pairs(adj[u]) do
                    -- 3.12.10: als Sackgasse gesperrte Kanten nicht mehr nehmen
                    if not closed[v] and not (G.blocked and type(u) == "number" and type(v) == "number" and G.blocked[EdgeKey(u, v)]) then
                        relax(u, v, guarded(un, nodes[v], EdgeCost(e, un, nodes[v]), e[3]), e[3])
                    end
                end
            end

            -- Luftlinien nur innerhalb derselben Zone
            local zone, inst = un[4], un[1]
            if zone then
                local near = type(u) == "number" and virtCache[u]
                if not near then
                    near = self:NearSparse(inst, un[2], un[3], VIRT_RANGE, zone)
                    if type(u) == "number" then
                        if virtCount > 50000 then virtCache, virtCount = {}, 0 end
                        virtCache[u], virtCount = near, virtCount + 1
                    end
                end
                for _, v in ipairs(near) do
                    if v ~= u and not closed[v] then
                        relaxVirt(u, v, un, nodes[v], zone, u, v)
                    end
                end
                local gws = gwByZone[zone]
                if gws then
                    for _, v in ipairs(gws) do
                        if v ~= u and not closed[v] and nodes[v][1] == inst then
                            relaxVirt(u, v, un, nodes[v], zone, u, v)
                        end
                    end
                end
                if zone == gZone and inst == gInst and not closed["T"] then
                    relaxVirt(u, "T", un, T, zone)
                end
            end
        end
    end

    if gScore["T"] == nil then
        -- kein moeglicher Weg bekannt: Luftlinie als Notloesung
        if sInst == gInst then return { S, { gInst, gn, gw, gZone, via = "v" } }, "direct", Dist(S, T) end
        return nil
    end

    -- Kopien der Knoten (die gespeicherten Knoten bleiben unveraendert) mit Kantenart
    local path, cur = {}, "T"
    while cur do
        local nd = nodeOf(cur)
        local e = came[cur] and adj[came[cur]] and adj[came[cur]][cur]
        table.insert(path, 1, { nd[1], nd[2], nd[3], nd[4], via = via[cur], gw = nd.gw, name = nd.name, secs = e and e.secs,
                                id = type(cur) == "number" and cur or nil })
        cur = came[cur]
    end
    return path, "graph", gScore["T"]
end

------------------------------------------------------------------------
-- Hoehlen: Ziel drinnen -> erst zum Eingang, dann hinein; Start drinnen -> erst hinaus
------------------------------------------------------------------------
local function Mark(points, first)
    for i = first or 1, #points do points[i].cave = true end
    return points
end

local function Append(out, points, skipFirst)
    for i = skipFirst and 2 or 1, #points do out[#out + 1] = points[i] end
end

-- maxExpand: hoechstens so viele Suchschritte (je Suche, 3.12.25; vorher eine globale Variable)
function Graph:Path(sInst, sn, sw, sZone, gInst, gn, gw, gZone, maxExpand)
    local Caves = LP.Caves
    local sc = Caves and Caves.At and Caves:At(sInst, sn, sw, gn, gw, true)
    local tc = Caves and Caves.At and Caves:At(gInst, gn, gw, sn, sw)
    if (not sc and not tc) or (sc and tc and Caves:Same(sc, tc)) then
        return self:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone, maxExpand)
    end
    local out, total = {}, 0
    local ci, cn, cw, cz = sInst, sn, sw, sZone
    if sc then
        -- drinnen: auf dem Weg zum Eingang (Innenraum, keine Gelaendefuehrung)
        local p, _, c = self:PathRaw(ci, cn, cw, cz, sc.inst, sc.n, sc.w, sc.map or cz, maxExpand)
        if not p then return self:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone, maxExpand) end
        Mark(p, 1)
        p[#p].cave = nil                       -- der Eingang selbst liegt draussen
        Append(out, p, false)
        total = total + (c or 0)
        ci, cn, cw, cz = sc.inst, sc.n, sc.w, sc.map or cz
    end
    if tc then
        local p, _, c = self:PathRaw(ci, cn, cw, cz, tc.inst, tc.n, tc.w, tc.map or gZone, maxExpand)
        if not p then return self:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone, maxExpand) end
        Append(out, p, #out > 0)
        total = total + (c or 0)
        local inner, _, c2 = self:PathRaw(tc.inst, tc.n, tc.w, tc.map or gZone, gInst, gn, gw, gZone, maxExpand)
        if not inner then inner, c2 = { { tc.inst, tc.n, tc.w, tc.map }, { gInst, gn, gw, gZone, via = "v" } }, 0 end
        Mark(inner, 2)
        Append(out, inner, true)
        total = total + (c2 or 0)
    else
        local p, _, c = self:PathRaw(ci, cn, cw, cz, gInst, gn, gw, gZone, maxExpand)
        if not p then return self:PathRaw(sInst, sn, sw, sZone, gInst, gn, gw, gZone, maxExpand) end
        Append(out, p, #out > 0)
        total = total + (c or 0)
    end
    return out, "cave", total
end

------------------------------------------------------------------------
-- 3.12.12: Wegdaten zum Einsenden (/lp wege) und automatischer Versand (GSWEGE1, ueber die SavedVariables)
-- Inhalt: gelernte Kanten je Zone als Koordinatenfolgen (Zonenkarte, 1 Nachkommastelle, Punkte > 5 Yards
-- auseinander), Herkunft (selbst/geteilt), wie oft gelaufen; gesperrte Kanten; korrigierte NPC-Orte;
-- FEST-Ereignisse der letzten 7 Tage. Nie Spieler-, Charakter- oder Gildennamen.
------------------------------------------------------------------------
Graph.WEGE_PREFIX = "GSWEGE1"
Graph.WEGE_MAX = 200 * 1024             -- Zeichen in LevelPilotDB.wegeExport (aeltestes zuerst gekuerzt)
local WEGE_GAP = 5                      -- Yards: naehere Punkte werden ausgelassen
local FEST_DAYS = 7

local function R1(v) return math.floor((v or 0) * 10 + 0.5) / 10 end
local function MapXY(nd)
    local zone = nd[4]
    if not zone then return nil end
    local x, y = LP.Geo:ToMap(zone, nd[1], nd[2], nd[3])
    if not x then return nil end
    return R1(x), R1(y)
end

-- 3.12.17: Kontinentkarten (Flug, Schiff) gehoeren nicht zu den Wegdaten
local function IsContinent(map)
    return map ~= nil and LP.Geo:ContinentOf(map) == map
end
Graph.IsContinent = IsContinent

-- Ketten aus Kanten (gleiche Zone, gleiche Herkunft); filter(key, e) waehlt die Kanten aus
local function Chains(filter)
    local byZone = {}
    for key, e in pairs(G.edges or {}) do
        local a, b = G.nodes[e[1]], G.nodes[e[2]]
        if type(a) == "table" and type(b) == "table" and a[4] and a[4] == b[4] and not IsContinent(a[4])
           and (not filter or filter(key, e)) then
            local src = (e[3] == "s") and "geteilt" or "selbst"
            local z = byZone[a[4]] or {}
            byZone[a[4]] = z
            local g = z[src] or { adj = {}, edges = {} }
            z[src] = g
            g.adj[e[1]] = g.adj[e[1]] or {}
            g.adj[e[2]] = g.adj[e[2]] or {}
            g.adj[e[1]][e[2]] = e
            g.adj[e[2]][e[1]] = e
            g.edges[#g.edges + 1] = key
        end
    end
    local out = {}
    for zone, srcs in pairs(byZone) do
        local list = {}
        for src, g in pairs(srcs) do
            local used = {}
            local function deg(id) local n = 0 for _ in pairs(g.adj[id]) do n = n + 1 end return n end
            local function walk(start, nextId)
                local ids, cur, prev, runs = { start }, nextId, start, 0
                local e0 = g.adj[start][nextId]
                runs = e0[4] or 1
                used[EdgeKey(start, nextId)] = true
                while cur do
                    ids[#ids + 1] = cur
                    if deg(cur) ~= 2 then break end
                    local nx
                    for v in pairs(g.adj[cur]) do if v ~= prev and not used[EdgeKey(cur, v)] then nx = v end end
                    if not nx then break end
                    used[EdgeKey(cur, nx)] = true
                    runs = math.max(runs, g.adj[cur][nx][4] or 1)
                    prev, cur = cur, nx
                end
                -- Punkte: Zonenkarte, 1 Nachkommastelle, nur > WEGE_GAP Yards auseinander (Endpunkt immer)
                local pts, last = {}, nil
                for i, id in ipairs(ids) do
                    local nd = G.nodes[id]
                    if nd and (i == #ids or not last or Dist(last, nd) > WEGE_GAP) then
                        local x, y = MapXY(nd)
                        if x then pts[#pts + 1] = x pts[#pts + 1] = y last = nd end
                    end
                end
                if #pts >= 4 then list[#list + 1] = { p = pts, src = src, n = runs } end
            end
            for id in pairs(g.adj) do
                if deg(id) ~= 2 then
                    for v in pairs(g.adj[id]) do if not used[EdgeKey(id, v)] then walk(id, v) end end
                end
            end
            for id in pairs(g.adj) do            -- reine Ringe
                for v in pairs(g.adj[id]) do if not used[EdgeKey(id, v)] then walk(id, v) end end
            end
        end
        if #list > 0 then out[#out + 1] = { map = zone, name = LP.Geo:MapName(zone), edges = list } end
    end
    table.sort(out, function(a, b) return a.map < b.map end)
    return out
end

-- alle bzw. nur neue/geaenderte Daten seit dem letzten Versand (sent = LP.db.wegeSent)
function Graph:WegeData(sent, zoneFilter)
    local now = time and time() or 0
    local function edgeNew(key, e)
        if zoneFilter then
            local a = G.nodes[e[1]]
            if not (a and zoneFilter(a[4])) then return false end
        end
        return not sent or (sent.e[key] or 0) < (e[4] or 1)
    end
    local data = { zones = Chains(edgeNew), blocked = {}, npc = {}, fest = {} }
    for key, b in pairs(G.blocked or {}) do
        local ia, ib = key:match("^(%d+):(%d+)$")
        local a, c = G.nodes[tonumber(ia or "")], G.nodes[tonumber(ib or "")]
        if a and c and (not sent or not sent.b[key]) and (not zoneFilter or zoneFilter(a[4])) then
            local x1, y1 = MapXY(a)
            local x2, y2 = MapXY(c)
            if x1 and x2 then data.blocked[#data.blocked + 1] = { map = a[4], p = { x1, y1, x2, y2 }, why = tostring(b.why or "FEST"), t = b.t, key = key } end
        end
    end
    for id, r in pairs(type(LP.db.npcPos) == "table" and LP.db.npcPos or {}) do
        if type(r) == "table" and (not sent or (sent.n[id] or 0) < (r.t or 0)) and (not zoneFilter or zoneFilter(r[1])) then
            -- 3.12.17: old/new einheitlich [x, y] (Karte in map; liegt der Ort im Datenpaket auf einer anderen Karte,
            -- zusaetzlich oldMap). Ort im Datenpaket: der naechste Fundort auf derselben Karte (nicht der erste).
            -- nopack: NPC hat im Datenpaket keinen Ort (z. B. neue Forever-NPCs) – kein "nicht da".
            local o = LP.Recorder and LP.Recorder.PackSpawn and LP.Recorder.PackSpawn(id, { r[1], r[2] or 0, r[3] or 0 })
            if not o and type(r.o) == "table" then o = r.o end
            data.npc[#data.npc + 1] = { id = id, map = r[1], new = { R1(r[2]), R1(r[3]) },
                                        old = o and { R1(o[2]), R1(o[3]) } or nil,
                                        oldMap = o and o[1] ~= r[1] and o[1] or nil,
                                        nopack = not o or nil, t = r.t }
        end
    end
    table.sort(data.npc, function(a, b) return a.id < b.id end)
    for _, f in ipairs(type(LP.db.festLog) == "table" and LP.db.festLog or {}) do
        if type(f) == "table" and (f.t or 0) >= now - FEST_DAYS * 86400 and (not sent or (f.t or 0) > (sent.f or 0))
           and (not zoneFilter or zoneFilter(f.map)) then
            data.fest[#data.fest + 1] = { map = f.map, x = f.x, y = f.y, t = f.t, blocked = f.blocked and true or false }
        end
    end
    return data
end

-- Zone fuer "/lp wege <Zone>": UiMapID oder Teil des Namens
local function ZoneFilter(arg)
    if not arg or arg == "" then return nil end
    local id = tonumber(arg)
    if id then return function(m) return m == id end end
    arg = arg:lower()
    return function(m) local n = m and LP.Geo:MapName(m) return n and n:lower():find(arg, 1, true) ~= nil end
end

function Graph:WegeText(arg)
    local filter = ZoneFilter(arg)
    local d = self:WegeData(nil, filter)
    local out = {}
    local env = _G.GoldSentinelTest and _G.GoldSentinelTest.Env and _G.GoldSentinelTest.Env() or {}
    out[#out + 1] = string.format("LevelPilot %s – Wegdaten · %s · Client %s (%s)", LP.version, date("%d.%m.%Y %H:%M"),
        tostring(env.client), tostring(env.build))
    local edges = 0
    for _, z in ipairs(d.zones) do
        out[#out + 1] = string.format("Zone %d %s: %d Wege", z.map, tostring(z.name), #z.edges)
        for _, e in ipairs(z.edges) do
            edges = edges + 1
            local pts = {}
            for i = 1, #e.p, 2 do pts[#pts + 1] = string.format("%.1f,%.1f", e.p[i], e.p[i + 1]) end
            out[#out + 1] = "  " .. e.src .. " " .. e.n .. "x: " .. table.concat(pts, " ")
        end
    end
    out[#out + 1] = string.format("Gesperrt: %d", #d.blocked)
    for _, b in ipairs(d.blocked) do
        out[#out + 1] = string.format("  Zone %d: %.1f,%.1f %.1f,%.1f %s %s", b.map, b.p[1], b.p[2], b.p[3], b.p[4], b.why,
            b.t and date("%d.%m.%Y %H:%M", b.t) or "?")
    end
    out[#out + 1] = string.format("NPC-Orte: %d", #d.npc)
    for _, n in ipairs(d.npc) do
        out[#out + 1] = string.format("  NPC %d Zone %d: %s -> %.1f,%.1f", n.id, n.map,
            n.old and ((n.oldMap and ("Zone " .. n.oldMap .. " ") or "") .. string.format("%.1f,%.1f", n.old[1], n.old[2]))
                or L["nicht im Datenpaket"], n.new[1], n.new[2])
    end
    out[#out + 1] = string.format("FEST (7 Tage): %d", #d.fest)
    for _, f in ipairs(d.fest) do
        out[#out + 1] = string.format("  Zone %s: %.1f,%.1f %s%s", tostring(f.map), f.x or 0, f.y or 0,
            f.t and date("%d.%m.%Y %H:%M", f.t) or "?", f.blocked and " gesperrt" or "")
    end
    local text = table.concat(out, "\n")
    if #text > 120000 then
        text = text:sub(1, 120000) .. "\n… " .. L["gekürzt – /lp wege <Zone> zeigt eine einzelne Zone"]
    end
    return text, edges
end

function Graph:ShowWege(arg)
    local text = self:WegeText(arg)
    LP.Backup:ShowText(L["Wegdaten"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."]
        .. " " .. L["Wird auch automatisch gemeldet."], text)
end

-- beim Ausloggen und /reload: neue/geaenderte Wegdaten als GSWEGE1 in LevelPilotDB.wegeExport
function Graph:WegeExport()
    if not LP.db.wegeAuto then return false end
    if LP.Virtual and LP.Virtual.active then return false end
    local GT = _G.GoldSentinelTest
    if not (GT and GT.Encode) or type(LevelPilotDB) ~= "table" then return false end
    local sent = type(LP.db.wegeSent) == "table" and LP.db.wegeSent or {}
    sent.e = type(sent.e) == "table" and sent.e or {}
    sent.b = type(sent.b) == "table" and sent.b or {}
    sent.n = type(sent.n) == "table" and sent.n or {}
    local d = self:WegeData(sent)
    if #d.zones == 0 and #d.blocked == 0 and #d.npc == 0 and #d.fest == 0 then return false end
    -- Groesse begrenzen: Zonen nur so viele, wie unter die Grenze passen (der Rest kommt beim naechsten Mal)
    local list = type(LevelPilotDB.wegeExport) == "table" and LevelPilotDB.wegeExport or {}
    LevelPilotDB.wegeExport = list
    local rep = { f = 1, kind = "wege", addon = "LevelPilot", version = LP.version, time = time(),
                  id = string.format("LevelPilot-wege-%d-%06x", time(), math.random(0, 0xFFFFFF)),
                  env = GT.Env and GT.Env() or nil, zones = {}, blocked = {}, npc = d.npc, fest = d.fest }
    for _, b in ipairs(d.blocked) do rep.blocked[#rep.blocked + 1] = { map = b.map, p = b.p, why = b.why, t = b.t } end
    local budget = self.WEGE_MAX - 4096
    local function size() return #GT.Encode(rep) end
    local taken = {}
    for _, z in ipairs(d.zones) do
        rep.zones[#rep.zones + 1] = z
        if size() > budget then rep.zones[#rep.zones] = nil break end
        taken[#taken + 1] = z.map
    end
    local s = self.WEGE_PREFIX .. GT.Encode(rep)
    list[#list + 1] = s
    local total = 0
    for _, x in ipairs(list) do total = total + #x end
    while total > self.WEGE_MAX and #list > 1 do total = total - #table.remove(list, 1) end
    -- als versandt merken (nur, was im Bericht steht)
    local inZone = {}
    for _, m in ipairs(taken) do inZone[m] = true end
    for key, e in pairs(G.edges or {}) do
        local a = G.nodes[e[1]]
        if a and inZone[a[4]] then sent.e[key] = e[4] or 1 end
    end
    for _, b in ipairs(d.blocked) do sent.b[b.key] = true end
    for _, n in ipairs(d.npc) do sent.n[n.id] = n.t or 0 end
    for _, f in ipairs(d.fest) do if (f.t or 0) > (sent.f or 0) then sent.f = f.t end end
    LP.db.wegeSent = sent
    return true, #s
end

LP:On("PLAYER_LOGOUT", function() LP.Try("Wegdaten", Graph.WegeExport, Graph) end)
