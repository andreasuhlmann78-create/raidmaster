-- LevelPilot - Danger
-- Gefahrenkarte: hoechstes Level feindlicher Mobs je Gebiet (aus den Spawnpunkten des Datenpakets).
-- Pflichtregel: Die Route fuehrt nie zu Zielen und moeglichst nie ueber Wege, an denen Mobs 3 oder mehr
-- Level ueber dem Spielerlevel stehen. Elite-Mobs zaehlen 2 Level hoeher.

local _, LP = ...
local L = LP.L
local D = {}
LP:RegisterModule("Danger", D)

D.MAX_DIFF = 3            -- Mobs ab Spielerlevel + 3 sind tabu
D.ELITE_BONUS = 2         -- Elite zaehlt so viele Level mehr
local CELL = 100          -- Yards je Zelle
local SPREAD = 0          -- Nachbarzellen mitmarkieren (Mobs laufen umher, Aggro-Radius)
local ENTRANCE = 200      -- Yards um einen Dungeoneingang

local cells = nil         -- [inst] = { [key] = Level }
local segCache, segCount = {}, 0

local function Key(n, w) return math.floor(n / CELL) * 100000 + math.floor(w / CELL) end

local function MyCode() return LP:PlayerFaction() == "Horde" and "H" or "A" end

-- effektives Level eines Mobs (Elite hoeher); nil fuer freundliche NPCs
function D:MobLevel(npc)
    if type(npc) ~= "table" or not npc.lo then return nil end
    if npc.f and npc.f ~= "" and npc.f:find(MyCode(), 1, true) then return nil end
    if npc.v then return nil end                              -- Haendler, Lehrer, Flugmeister ...
    local elite = npc.rk == 1 or npc.rk == 3                  -- Elite, Boss (seltene zaehlen nicht)
    return npc.lo + (elite and self.ELITE_BONUS or 0)
end

-- Fuer die Gefahrenkarte: nur Mobs, die ein Gebiet besetzen (mehrere Spawnpunkte) oder Elite;
-- einzelne NPCs ohne Fraktion sind meist Questgeber, seltene Mobs wandern umher
local function Occupies(npc)
    if npc.rk == 2 or npc.rk == 4 then return false end
    if npc.rk == 1 or npc.rk == 3 then return true end
    local pts = 0
    for _, s in ipairs(npc.s or {}) do pts = pts + (#s - 1) / 2 end
    return pts >= 3
end

function D:Build()
    cells = {}
    wipe(segCache) segCount = 0
    local N = LevelPilotData and LevelPilotData.N
    if not N then return end
    local Geo = LP.Geo
    -- Dungeoneingaenge: Elite-Spawns dort sind Dungeon-Mobs (stehen drinnen, nicht draussen)
    local ents = {}
    for _, d in pairs(LevelPilotData.D or {}) do
        for _, e in ipairs(d.e or {}) do
            local i, n, w = Geo:ToWorld(e[1], e[2], e[3])
            if i then ents[#ents + 1] = { i, n, w } end
        end
    end
    local function AtEntrance(inst, n, w)
        for _, e in ipairs(ents) do
            if e[1] == inst and math.abs(e[2] - n) < ENTRANCE and math.abs(e[3] - w) < ENTRANCE then return true end
        end
        return false
    end
    for _, npc in pairs(N) do
        local lv = self:MobLevel(npc)
        if lv and lv > 1 and Occupies(npc) then
            for _, s in ipairs(npc.s or {}) do
                local map = s[1]
                if Geo:Bounds(map) then
                    for i = 2, #s - 1, 2 do
                        local inst, n, w = Geo:ToWorld(map, s[i], s[i + 1])
                        if inst and not ((npc.rk == 1 or npc.rk == 3) and AtEntrance(inst, n, w)) then
                            local t = cells[inst]
                            if not t then t = {} cells[inst] = t end
                            local cn, cw = math.floor(n / CELL), math.floor(w / CELL)
                            for dn = -SPREAD, SPREAD do
                                for dw = -SPREAD, SPREAD do
                                    local k = (cn + dn) * 100000 + (cw + dw)
                                    if (t[k] or 0) < lv then t[k] = lv end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

function D:Ready() return cells ~= nil end
function D:Reset() cells = nil wipe(segCache) segCount = 0 end

-- hoechstes Mob-Level an einem Weltpunkt (0 = nichts bekannt)
function D:At(inst, n, w)
    if not inst or not n then return 0 end
    if not cells then self:Build() end
    local t = cells and cells[inst]
    return t and t[Key(n, w)] or 0
end

function D:AtMap(map, x, y)
    local inst, n, w = LP.Geo:ToWorld(map, x, y)
    return self:At(inst, n, w)
end

-- hoechstes Mob-Level entlang einer Strecke, die ersten skip Yards ausgenommen (nicht zwischengespeichert)
function D:Route(inst, n1, w1, n2, w2, skip)
    if not inst then return 0 end
    if not cells then self:Build() end
    local t = cells and cells[inst]
    if not t then return 0 end
    local dn, dw = n2 - n1, w2 - w1
    local len = math.sqrt(dn * dn + dw * dw)
    if len <= (skip or 0) then return 0 end
    local steps = math.max(1, math.ceil(len / (CELL * 0.5)))
    local mx = 0
    for i = 0, steps do
        if len * i / steps >= (skip or 0) then
            local v = t[Key(n1 + dn * i / steps, w1 + dw * i / steps)]
            if v and v > mx then mx = v end
        end
    end
    return mx
end

-- hoechstes Mob-Level entlang einer Strecke (zwischengespeichert)
function D:Segment(inst, n1, w1, n2, w2)
    if not inst then return 0 end
    if not cells then self:Build() end
    local t = cells and cells[inst]
    if not t then return 0 end
    local ck = inst .. ":" .. math.floor(n1 / 40) .. ":" .. math.floor(w1 / 40) .. ":" .. math.floor(n2 / 40) .. ":" .. math.floor(w2 / 40)
    local c = segCache[ck]
    if c then return c end
    local dn, dw = n2 - n1, w2 - w1
    local steps = math.max(1, math.ceil(math.sqrt(dn * dn + dw * dw) / (CELL * 0.5)))
    local mx = 0
    for i = 0, steps do
        local v = t[Key(n1 + dn * i / steps, w1 + dw * i / steps)]
        if v and v > mx then mx = v end
    end
    if segCount > 50000 then wipe(segCache) segCount = 0 end
    segCache[ck] = mx
    segCount = segCount + 1
    return mx
end

-- Ist ein Mob dieses Levels fuer den Spieler erlaubt?
function D:OK(mobLevel, level)
    if not mobLevel then return true end
    return mobLevel < (level or LP:PlayerLevel() or 1) + self.MAX_DIFF
end

-- Level-Grenze (ab hier tabu)
function D:Limit(level) return (level or LP:PlayerLevel() or 1) + self.MAX_DIFF end

-- Gefahr entlang eines ganzen Weges (Punkte {inst, n, w, ...}). Die ersten skip Yards zaehlen nicht;
-- steht man schon in einem Gebiet mit zu starken Mobs (Level >= lim), zaehlt auch der Weg hinaus nicht
-- (hoechstens ESCAPE Yards) - entscheidend ist, nicht in ein solches Gebiet hineinzulaufen.
-- Liefert das hoechste Level und den Punkt (inst, n, w), an dem es auftritt.
local ESCAPE = 600
function D:PathDanger(path, skip, lim)
    if not path or #path < 2 then return 0 end
    if not cells then self:Build() end
    local walked, escaping = 0, lim ~= nil
    local mx, mi, mn, mw = 0, nil, nil, nil
    for i = 2, #path do
        local a, b = path[i - 1], path[i]
        local via = b.via
        if a[1] == b[1] and via ~= "boat" and via ~= "zep" and via ~= "tram" and via ~= "portal" then
            local t = cells and cells[a[1]]
            local dn, dw = b[2] - a[2], b[3] - a[3]
            local len = math.sqrt(dn * dn + dw * dw)
            local steps = math.max(1, math.ceil(len / (CELL * 0.5)))
            for k = 0, steps do
                local pos = walked + len * k / steps
                local n, w = a[2] + dn * k / steps, a[3] + dw * k / steps
                local v = t and t[Key(n, w)] or 0
                if escaping and (v < lim or pos > ESCAPE) then escaping = false end
                if pos >= (skip or 0) and not escaping and v > mx then mx, mi, mn, mw = v, a[1], n, w end
            end
            walked = walked + len
        end
    end
    return mx, mi, mn, mw
end

