local _, ns = ...
local L = ns.L

-- WoW Forever: recipes of the supply camps cost Merchant's Favor, not gold.
--   Horde:    Durotar Supply and Logistics (faction 2587), camp west of the Crossroads in the Barrens
--   Alliance: Azeroth Commerce Authority (faction 2586), camp at Three Corners
-- The data (ri.fv = favor, ri.fe = estimated, ri.fa/ri.fr = reputation) comes from public guides
-- (pipeline/favor_costs.json). The client tables do not carry vendor costs, so while a vendor is open
-- this module reads the real costs (GetMerchantItemCostInfo / GetMerchantItemCostItem) and stores them
-- in ProfessionSentinelDB.favor – those values win over the guide data.

local F = {}
ns.Favor = F

F.FACTION_HORDE = 2587
F.FACTION_ALLIANCE = 2586

-- reputation faction for this character: the data carries the Horde id, Alliance players get theirs
-- (group = "Horde" / "Alliance" for tests, otherwise the player's faction)
function F.Faction(fa, group)
    group = group or (UnitFactionGroup and UnitFactionGroup("player"))
    if fa == F.FACTION_HORDE and group == "Alliance" then
        return F.FACTION_ALLIANCE
    end
    return fa
end

local function DB()
    if not ns.db then return nil end
    ns.db.favor = ns.db.favor or { costs = {} }
    ns.db.favor.costs = ns.db.favor.costs or {}
    return ns.db.favor
end

-- cost of a recipe item: { n = amount, name = currency name or nil, learned = true/false, estimate = true/false }
-- nil if it is not paid with favor (then ri.bp is the gold price)
function F.Cost(ri)
    if not ri then return nil end
    local db = DB()
    local seen = db and db.costs[ri.id]
    if seen and seen.n then
        return { n = seen.n, name = seen.c, learned = true }
    end
    if ri.fv then
        return { n = ri.fv, estimate = ri.fe == 1, learned = false }
    end
    return nil
end

-- what the player owns (once the currency has been seen at a vendor)
function F.Balance()
    local db = DB()
    local id = db and db.currency
    if not (id and C_CurrencyInfo and C_CurrencyInfo.GetCurrencyInfo) then return nil end
    local ok, info = pcall(C_CurrencyInfo.GetCurrencyInfo, id)
    if ok and type(info) == "table" and info.quantity then return info.quantity end
    return nil
end

-- tooltip text: "120 Merchant's Favor (you have 80)" – with "estimated" or "seen at the vendor"
function F.CostText(ri)
    local c = F.Cost(ri)
    if not c then return nil end
    local name = c.name or L.FAVOR_NAME
    local s = "|cff66ccff" .. c.n .. " " .. name .. "|r"
    local have = F.Balance()
    if have then
        local col = have >= c.n and "40c040" or "ff6060"
        s = s .. " |cff" .. col .. "(" .. string.format(L.FAVOR_HAVE, have) .. ")|r"
    end
    if c.learned then
        s = s .. " |cff9d9d9d" .. L.FAVOR_SEEN .. "|r"
    elseif c.estimate then
        s = s .. " |cff9d9d9d" .. L.FAVOR_ESTIMATE .. "|r"
    else
        s = s .. " |cff9d9d9d" .. L.FAVOR_GUIDE .. "|r"
    end
    return s
end

---------------------------------------------------------------------------
-- Learning at the vendor: every item of the open vendor that teaches a recipe of our data
---------------------------------------------------------------------------
local function MerchantItemID(i)
    if GetMerchantItemID then
        local ok, id = pcall(GetMerchantItemID, i)
        if ok and id then return id end
    end
    local link = GetMerchantItemLink and GetMerchantItemLink(i)
    return link and tonumber(link:match("item:(%d+)"))
end

function F.LearnFromMerchant()
    local db = DB()
    if not (db and GetMerchantNumItems and GetMerchantItemCostInfo and GetMerchantItemCostItem) then return 0 end
    local learned = 0
    for i = 1, GetMerchantNumItems() or 0 do
        local id = MerchantItemID(i)
        if id and ns.ByRecipeItem and ns.ByRecipeItem[id] then
            local okN, count = pcall(GetMerchantItemCostInfo, i)
            if okN and type(count) == "number" and count > 0 then
                for j = 1, count do
                    local okC, _, value, link, currencyName = pcall(GetMerchantItemCostItem, i, j)
                    local currencyID = okC and type(link) == "string" and tonumber(link:match("currency:(%d+)"))
                    if okC and currencyID and value and value > 0 then
                        local old = db.costs[id]
                        if not (old and old.n == value) then learned = learned + 1 end
                        db.costs[id] = { n = value, c = currencyName, cur = currencyID, t = time and time() or 0 }
                        db.currency = db.currency or currencyID
                        break
                    end
                end
            end
        end
    end
    return learned
end

local ev = CreateFrame("Frame")
pcall(ev.RegisterEvent, ev, "MERCHANT_SHOW")
pcall(ev.RegisterEvent, ev, "MERCHANT_UPDATE")
ev:SetScript("OnEvent", function()
    if not ns.IsForever then return end
    local ok, n = pcall(F.LearnFromMerchant)
    if ok and n and n > 0 and ns.RefreshAll then ns.RefreshAll() end
end)
