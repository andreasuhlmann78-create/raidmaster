-- AHSentinel - Prüfliste im Spiel (nur Entwicklermodus)
-- Copyright (C) 2026 GoldSentinel
-- This file is part of AHSentinel. AHSentinel is free software: you can redistribute it and/or modify it under the terms
-- of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at
-- your option) any later version. See LICENSE.txt.
--
-- Entscheid des Nutzers 16.11.2026 06:47 (Supervisor 06:49): Für jeden Punkt "im Client prüfen" eine Prüfliste im Spiel mit dem
-- gemeinsamen Baustein GoldSentinelPruefliste.lua. Nur Entwicklermodus (/ahs entwickler an UND GoldSentinelDev), merkt selbst,
-- zeigt immer, was zu tun ist. Zuerst: Sniper-Abnahme 16.11. (vor dem CurseForge-Upload 18:00).
-- Ohne Entwicklermodus kostet nichts etwas: P:On() ist dann sofort false, Hit/Fail tun nichts.

local A = AHAnalyzerPro
local P = {}
A.Pruefliste = P

P.ADDON = "AHSentinel"
-- Punkte in der Reihenfolge, in der der Nutzer sie im Spiel macht (höchstens 14). "since" = Version, ab der der Punkt gilt;
-- kommt ein Punkt mit neuer Fassung, ist er wieder offen.
P.POINTS = {
    { id = "SN-TR", title = "Testroutine Sniper (S1–S6)", since = "0.65.259",
      todo = "Auktionshaus öffnen, keinen Markt-Scan laufen lassen. Im Sniper muss der Knopf „Mausrad“ GRÜN sein (sonst einmal anklicken). Im Chat: /ahs testroutine sniper. Die Frage nach dem Testkauf mit „Ja“ beantworten; sobald „Treffer“ erscheint, EINE Mausrad-Raste. Danach rund 2 Minuten nichts tun (der Sniper wird beobachtet).",
      expect = "Im Chat „Testroutine fertig: … 0 FEHLER …“, das Bericht-Fenster beginnt mit „ERGEBNIS Sniper-Abnahme“ in Sätzen, der Testkauf ist genau 1 Stück." },
    -- SN-BTN1 entfernt (Ingame-Test 16.11. 19:43: OK, 1 Klick = 1 Kauf) – Platz für WAECHTER-FUND (höchstens 14 Punkte)
    { id = "SN-RAD-A", title = "„nur Knopf“: Mausrad kauft nie", since = "0.65.262",
      todo = "Im Sniper (Kaufen > Sniper) den Knopf „Mausrad“ (rechts neben „Sniper-Modus“) anklicken, bis er GRAU ist = nur der Knopf „Kaufen“ kauft (dieselbe Einstellung steht auch in /ahs optionen). Warten, bis ein Treffer da ist, dann das Mausrad drehen – über dem AHSentinel-Fenster UND über der Spielwelt.",
      expect = "Es wird NICHTS gekauft (Kamera zoomt, Listen blättern). Die Prüfliste merkt die gesperrte Raste selbst." },
    { id = "SN-RAD-B", title = "Mausrad grün: eine Raste = ein Kauf", since = "0.65.262",
      todo = "Den Knopf „Mausrad“ wieder anklicken (GRÜN). Bei einem Treffer EINE Mausrad-Raste.",
      expect = "Genau ein Kauf (Chat „Gekauft: …“), die Zielzeile zählt 1 weiter." },
    { id = "SN-GRENZE", title = "Max und Budget werden eingehalten", since = "0.65.259",
      todo = "Sniper-Ziel mit kleinem Budget setzen, das für höchstens 2 Käufe reicht (z. B. Max 30s, Budget 50s, Menge 5), und kaufen, bis nichts mehr geht.",
      expect = "Kein Kauf über dem Max. Ist das Budget aufgebraucht, steht die Zielzeile gelb und der Knopf fragt „Budget auffüllen?“ – ohne Ja wird nichts mehr gekauft." },
    { id = "POST-WS", title = "Einstellen trotz Preiswarnung", since = "0.65.259",
      todo = "Verkaufen > Einstellen: ein billiges Item (Wert unter 10s) wählen, Preis absichtlich viel zu tief eintragen (rund 1/10 des Marktwerts), „Einstellen“. Im Fenster „Warnschutz“ auf „Trotzdem einstellen“.",
      expect = "Die Auktion steht danach unter Verkaufen > Meine Auktionen. Keine zweite Warnung, keine Meldung „blockiert“ oder „fehlgeschlagen“ (abbrechen darfst du sie danach)." },
    -- POST-FIX entfernt (Ingame-Test 16.11. 19:43: OK, erledigt) – Platz für WAECHTER-LAST (höchstens 14 Punkte)
    { id = "ESL1", title = "Einkaufsliste aus Materialien", since = "0.65.263",
      todo = "Berufsfenster öffnen (z. B. Schneiderei) und ein Rezept anklicken. Mit ProfessionSentinel im Chat /ahs fehlt eingeben (nur was fehlt) oder /ahs material (alle Materialien). Ohne ProfessionSentinel gehen auch die Knöpfe „Nur was mir fehlt“ / „Materialien als Einkaufsliste“ im AHSentinel-Teil neben dem Berufsfenster.",
      expect = "Die Einkaufsliste öffnet sich mit den Materialien (mindestens eine Zeile), im Chat „Materialien für … auf die Liste … gesetzt“. Hast du schon alles, sagt /ahs fehlt das." },
    -- OPT-1 entfernt (Supervisor 15:35: OK, ERLEDIGT) – Platz für HAENDLER-GOLD (höchstens 14 Punkte)
    -- Phase 8 (Nutzer 16.11. 14:10, Supervisor 15:15 "Nachtest im Spiel mit der Prüfliste")
    { id = "POST-TEUER", title = "Warnschutz bei zu teuer", since = "0.65.267",
      todo = "Verkaufen > Einstellen: ein billiges Item wählen, als Preis absichtlich rund das 3-fache des Marktwerts eintragen, „Einstellen“. Im Fenster „Warnschutz“ auf „Preis anpassen (…)“ (oder Enter), dann „Einstellen“.",
      expect = "Die Warnung sagt „… liegt n % über dem günstigsten Angebot“ (oder „über dem Marktwert“). Der angepasste Preis liegt knapp unter dem günstigsten Angebot, Einstellen geht ohne neue Warnung durch (abbrechen darfst du danach). Die Prüfliste merkt es selbst." },
    { id = "SCHN-ALARM", title = "Schnäppchen-Alarm nur bei Gesichertem", since = "0.65.268",
      todo = "Optionen > Kaufen & Sniper: Zeile „Schnäppchen-Alarm“ ist da (an/aus). Wächter einschalten (Kaufen > Wächter) und eine Weile laufen lassen.",
      expect = "Ein Ton + grüne Zeile „Schnäppchen (gesichert)“ nur, wenn der Weiterverkauf freigegeben ist; sonst nur eine graue Zeile mit Grund, ohne Ton. Je Item höchstens eine Meldung in 10 Minuten, nie ein Kauf ohne Klick. Eine grüne Meldung hakt den Punkt selbst ab; kommt nur Graues, mit „OK“ bestätigen, wenn die Gründe stimmen." },
    -- Nachtschicht 16.11. (Masterplan 4.5 Block 3 und 5.2 UI-CLEAN1 B): Messungen im Spiel
    -- VS-121 (0.65.283): Speicher jetzt „bleibend“ (Boden nach der Bereinigung) statt Stand am Ende; Notiz mit Schritt der Lücke
    { id = "VOLLSCAN", title = "Vollscan: Speicher und Ruckeln", since = "0.65.283",
      todo = "Zwei Vollscans hintereinander (Markt > Vollscan, zwischen beiden mindestens 15 Minuten, höchstens 6 Std.). Nichts weiter tun. Danach /ahs protokoll öffnen und die beiden Zeilen „VOLLSCAN Messung …“ mitschicken.",
      expect = "Die Prüfliste misst selbst: bleibender Speicher (tiefster Stand nach der Bereinigung) nach dem zweiten Scan höchstens 10 MB mehr als nach dem ersten, längste Lücke (Ruckler) höchstens 50 ms. Sonst „Fehler (erkannt)“ mit den Zahlen und dem Schritt der Lücke; Ursache und neu angelegter Speicher je Schritt stehen im Protokoll." },
    { id = "HAENDLER-GOLD", title = "Händlerpreis beim Verkauf gemessen", since = "0.65.275",
      todo = "Mit grauen Items (Schrott) in der Tasche einen Händler ansprechen und den AHSentinel-Knopf „Verkaufen: n Items (…)“ am Händlerfenster einmal anklicken.",
      expect = "Die Prüfliste misst selbst: Gold-Zuwachs je Item = Händlerpreis (± 1 Kupfer je Stück) -> erledigt. Weicht ein Item ab, steht im Chat „Händlerpreis stimmt nicht … Händler-Weg gesperrt“ und der Punkt zeigt die Zahlen." },
    -- WACH-1 (Ingame-Test 16.11. 19:43, Absturz „script ran too long“ im Wächter beim Öffnen der Optionen)
    { id = "WAECHTER-LAST", title = "Wächter 5 Min. ohne Absturz und Ruckeln", since = "0.65.282",
      todo = "AH offen lassen, Wächter einschalten (Kaufen > Wächter), mit „Entzaubern“-Prüfung, wenn du sie benutzt. Während er läuft einmal die Optionen öffnen (/ahs optionen) und wieder schliessen. Mindestens 5 Minuten so lassen.",
      expect = "Kein Lua-Fehler, kein Einfrieren. Die Prüfliste misst selbst: längste Rechenzeit des Wächters in einem Bild höchstens 50 ms -> erledigt; sonst „Fehler (erkannt)“ mit den Zahlen (Runden, Entzauber-Prüfungen, ms). Kommt ein Lua-Fehler, „Fehler“ setzen und den Text in die Notiz." },
    -- WACH-2 (Nutzer 20:43 "kamen keine Meldungen"): sieht man, wo die Angebote hängen bleiben?
    { id = "WAECHTER-FUND", title = "Wächter: Hürden je Runde sichtbar", since = "0.65.287",
      todo = "AH offen, Wächter einschalten (Kaufen > Wächter), mindestens 10 Minuten laufen lassen. Einstellungen NICHT ändern.",
      expect = "Unter „Runden … geprüft …“ steht eine Zeile „Letzte Runde: n Angebote – …“ mit der Hürde, an der alles hängen bleibt (oder „x Kandidaten“). Nach mindestens 3 Runden und 10 Minuten hakt sich der Punkt selbst ab; die Zeile steht in der Notiz. Alle Zahlen je Runde: /ahs protokoll, Zeilen WAECHTER-HUERDEN." },
    { id = "UI-TEST", title = "Oberflächen-Prüfung (alle Reiter)", since = "0.65.273",
      todo = "Im Chat /ahs testroutine ui – einmal mit Schriftgrösse 100 %, einmal mit 130 % (Optionen > Allgemein), je einmal im Design Modern und Klassisch.",
      expect = "Im Chat „Testroutine fertig: … 0 FEHLER …“. Die Prüfliste hakt sich beim ersten Lauf ohne FEHLER selbst ab; Fehler stehen mit Zahl in der Liste und im Testbericht." },
    { id = "HILFE-GRP", title = "Befehlsliste in Gruppen", since = "0.65.270",
      todo = "Im Chat /ahs hilfe eingeben. Danach /ahs einstellungen.",
      expect = "Die Befehle stehen in den Gruppen Alltag, Einstellungen, Hilfe (im Entwicklermodus dazu Entwickler), nichts doppelt. /ahs einstellungen öffnet die Optionen. „OK“ = so lassen." },
}

-- an, wenn AHSentinel im Entwicklermodus ist und der gemeinsame Baustein da ist (GoldSentinelDev entscheidet dort selbst)
function P:On()
    return A:IsDev() and type(_G.GoldSentinelPruefliste) == "table" or false
end
-- die Liste (einmal angelegt, sobald der Entwicklermodus an ist); nil ohne Entwicklermodus
function P:List()
    if not self:On() then return nil end
    local G = _G.GoldSentinelPruefliste
    local l = self.list
    if l and G:Get(self.ADDON) == l then return l end
    local reg = G:Register(self.ADDON, {
        db = function() return P.testDB or A.db end,          -- Testroutine: eigene Ersatz-Daten (nie die echten)
        version = A.version,
        points = self.POINTS,
    })
    if G:Get(self.ADDON) ~= reg then return nil end              -- GoldSentinelDev sagt nein: wirkungslose Liste, nichts merken
    self.list = reg
    return reg
end
-- die Testroutine löst nichts aus (ihre Ereignisse sind nachgespielt); fromTR = Meldung der Testroutine selbst
local function Quiet(fromTR)
    local TR = A.TestRoutine
    return not fromTR and TR and TR.running and not P.testAllow
end
function P:Hit(id, note, fromTR)
    if Quiet(fromTR) then return false end
    local l = self:List()
    if not l then return false end
    -- SN-RAD (e) (Ingame-Test 16.11.): ein vom Addon erkannter Fehler verschwindet nie still - erst "Zurücksetzen" im Fenster
    if l:State(id) == "fehler" then
        if not (self.keptNote and self.keptNote[id]) then
            self.keptNote = self.keptNote or {}
            self.keptNote[id] = true
            A:Print("|cffff5544" .. "Prüfliste: " .. id .. " bleibt Fehler – erst im Fenster „Zurücksetzen“, dann neu prüfen.|r")
        end
        return false
    end
    local ok, r = pcall(l.Hit, l, id, note)
    return ok and r or false
end
-- vom Addon erkannter Fehler -> Zustand "Fehler (erkannt)" mit Notiz (ein OK des Spielers bleibt)
function P:Fail(id, note, fromTR)
    if Quiet(fromTR) then return false end
    local l = self:List()
    if not l then return false end
    local s = l:State(id)
    if s == "ok" then return false end
    local ok, r = pcall(l.Set, l, id, "fehler", note)
    if ok and r then
        A:Print("|cffff5544" .. "Prüfliste: " .. id .. " Fehler (erkannt)|r" .. (note and (" – " .. tostring(note)) or ""))
        if l.frame and l.frame:IsShown() then pcall(l.Refresh, l) end
    end
    return ok and r or false
end
function P:Open()
    local l = self:List()
    if not l then
        A:Print("Prüfliste: nur im Entwicklermodus (GoldSentinelDev erkennt dich nicht).")
        return false
    end
    return l:Open()
end
-- Zeilen für den Testbericht (leer ohne Entwicklermodus)
function P:ReportLines()
    local l = self:List()
    if not l then return {} end
    local ok, lines = pcall(l.ReportLines, l)
    return ok and lines or {}
end
