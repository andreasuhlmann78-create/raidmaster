-- ThreatSentinel - Log.lua
-- Testprotokoll für Tests ohne Zuschauer: schreibt maschinenlesbar in die SavedVariables
-- (ThreatSentinelDB.testlog), was das Addon tut - und den TATSÄCHLICHEN Zustand der Frames.
-- Schwerpunkt: Aggro-Management (gehalten / knapp / lose / zurück) und was der Tank dabei sieht.
-- Am Ende wertet das Addon das Protokoll selbst aus und zeigt im Spiel einen Testbericht.
--
--   /ts log an | aus | leeren | status | bilder | bericht
--
-- Format: ThreatSentinelDB.testlog = { on, shots, meta = { {...}, ... }, events = { "...", ... } }
-- Jede Zeile: "<t>|<TYP>|schluessel=wert;schluessel=wert"
--   t = Sekunden seit Sitzungsstart (2 Nachkommastellen); Zahlen mit 2 Nachkommastellen;
--   | ; = in Werten werden ersetzt; geschützte (auch simuliert geschützte) Werte stehen als SECRET.
-- Regeln: Das Protokoll liest nur und hängt an. Jeder Protokollaufruf läuft in pcall.
-- Ist es aus, kehren alle Aufrufe nach einer einzigen Prüfung zurück; Ereignisse für
-- Zauber werden nur angemeldet, solange es läuft.

local ADDON, ns = ...
local L = ns.L

local LG = {}
ns.Log = LG
table.insert(ns.modules, LG)

local MAX_EVENTS = 5000
local TRIM_AT = 5500          -- erst bei 5500 auf 5000 kürzen (nicht bei jeder Zeile verschieben)
local MAX_META = 50
local MAX_SHOTS = 25
local SHOT_GAP = 2            -- Mobs leben im Test oft nur ~10 s: Verlust und Rückholung liegen dicht beieinander

local WHITE = "Interface\\Buttons\\WHITE8X8"
local BACKDROP = BackdropTemplateMixin and "BackdropTemplate" or nil

LG.on = false
LG.start = 0
LG.epoch = 0                  -- steigt bei jedem Einschalten (Zustandswechsel neu schreiben)
LG.shotCount = 0
LG.lastShot = 0
LG.seen = {}
LG.alertKeys = {}
LG.last = {}

local issecret = issecretvalue or function() return false end

------------------------------------------------------------
-- Formatierung
------------------------------------------------------------
-- cat: Kategorie der simulierten Sperren (z. B. "threatValues") - dann auch simuliert SECRET
local function Val(v, cat)
	if issecret(v) then return "SECRET" end
	if cat and ns.IsSecret(v, cat) then return "SECRET" end
	if v == nil then return "-" end
	local t = type(v)
	if t == "boolean" then return v and "1" or "0" end
	if t == "number" then
		if v == math.floor(v) and math.abs(v) < 1e9 then return tostring(v) end
		return string.format("%.2f", v)
	end
	if t == "table" then
		local a, b, c = v[1], v[2], v[3]
		if issecret(a) or issecret(b) or issecret(c) then return "SECRET" end
		if a ~= nil and b ~= nil and c ~= nil then return Val(a) .. "," .. Val(b) .. "," .. Val(c) end
		return "table"
	end
	local s = tostring(v)
	if issecret(s) then return "SECRET" end
	s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", "")
	s = s:gsub("|", "/"):gsub(";", ","):gsub("=", ":"):gsub("\n", " ")
	return s
end
LG.Val = Val

-- Speicher (nur anlegen, wenn wirklich gebraucht)
local function DB(create)
	local root = ThreatSentinelDB
	local t = root and root.testlog
	if type(t) ~= "table" then
		if not create then return nil end
		ThreatSentinelDB = ThreatSentinelDB or {}
		t = { on = false, shots = true, meta = {}, events = {} }
		ThreatSentinelDB.testlog = t
	end
	t.meta = t.meta or {}
	t.events = t.events or {}
	if t.shots == nil then t.shots = true end
	return t
end

local function Append(line)
	local ev = DB(true).events
	ev[#ev + 1] = line
	if #ev > TRIM_AT then
		local drop = #ev - MAX_EVENTS
		local n = #ev
		for i = 1, n - drop do ev[i] = ev[i + drop] end
		for i = n, n - drop + 1, -1 do ev[i] = nil end
	end
end

local function Build(...)
	local n = select("#", ...)
	local parts = {}
	for i = 1, n, 2 do
		local k, v = select(i, ...)
		parts[#parts + 1] = k .. "=" .. Val(v)
	end
	return table.concat(parts, ";")
end

local function Stamp()
	return string.format("%.2f", GetTime() - LG.start)
end

-- Event schreiben: LG:E("STATE", "id", id, "from", from, ...)
function LG:E(typ, ...)
	if not self.on then return end
	local ok = pcall(function(...) Append(Stamp() .. "|" .. typ .. "|" .. Build(...)) end, ...)
	if not ok then self.internalErrors = (self.internalErrors or 0) + 1 end
end

-- Nur schreiben, wenn sich die Signatur geändert hat. sig = Vergleichswert (gerundet),
-- die Zeile selbst enthält die genauen Werte.
function LG:Changed(key, sig, typ, ...)
	if not self.on then return end
	local ok = pcall(function(...)
		if self.last[key] == sig then return end
		self.last[key] = sig
		Append(Stamp() .. "|" .. typ .. "|" .. Build(...))
	end, ...)
	if not ok then self.internalErrors = (self.internalErrors or 0) + 1 end
end

-- Kurze Mob-ID: NPC-ID + letzte 4 Stellen der GUID, P<n> für eine Plakette, SECRET wenn geschützt
function LG:Id(key)
	if key == nil then return "-" end
	if issecret(key) then return "SECRET" end
	if type(key) ~= "string" then return "?" end
	local plate = key:match("^plate:nameplate(%d+)$")
	if plate then return "P" .. plate end
	local npc, spawn = key:match("^%a+%-%d+%-%d+%-%d+%-%d+%-(%d+)%-(%x+)$")
	if npc then return npc .. ":" .. spawn:sub(-4) end
	return key:sub(-8)
end

-- GUID ohne Nebenwirkungen (MobKey würde den Forever-Schutz-Status verändern)
local function RawId(unit)
	local g = UnitGUID(unit)
	if issecret(g) or ns.IsSecret(g, "guid") then return "SECRET" end
	return LG:Id(g)
end

------------------------------------------------------------
-- Sitzung
------------------------------------------------------------
local function ClientName(toc)
	if toc >= 110000 then return "Retail" end
	if toc >= 16000 and toc < 17000 then return "Forever" end
	if toc >= 20000 and toc < 30000 then return "Anniversary" end
	if toc >= 11000 and toc < 12000 then return "Era" end
	return "?"
end

local function PetInfo()
	if not UnitExists("pet") then return "-", "-", "-" end
	return Val(UnitName("pet")), Val(UnitCreatureFamily and UnitCreatureFamily("pet")), Val(UnitLevel("pet"))
end

function LG:WriteMeta()
	if not self.on then return end
	pcall(function()
		local db = ns.db
		local ver, build, _, toc = GetBuildInfo()
		local hardcore = "?"
		if C_GameRules and C_GameRules.IsHardcoreActive then
			local ok, hc = pcall(C_GameRules.IsHardcoreActive)
			if ok and not issecret(hc) then hardcore = hc and "ja" or "nein" end
		end
		local petName, petFamily, petLevel = PetInfo()
		local function pt(p) return p and (tostring(p[1]) .. " " .. tostring(p[3]) .. " " .. Val(p[4]) .. " " .. Val(p[5])) or "-" end
		local meta = {
			date = date("%Y-%m-%d %H:%M:%S"),
			addonVersion = ns.version,
			build = tostring(ver or "?") .. " (" .. tostring(build or "?") .. ")",
			interface = toc,
			client = ClientName(toc or 0),
			hardcore = hardcore,
			class = ns.class,
			form = ns:FormName(),
			spec = ns:SpecName(),
			tankUnit = ns:TankUnit(),
			petName = petName, petFamily = petFamily, petLevel = petLevel,
			taunt = (ns.tauntSpell or "-") .. " (" .. (ns.tauntMode or "-") .. ")",
			heldPlateAlpha = db.heldPlateAlpha, heldHealthAlpha = db.heldHealthAlpha, heldScale = db.heldScale,
			looseScale = db.looseScale, borderSize = db.borderSize, loosePulse = db.loosePulse and "ja" or "nein",
			warnThreshold = db.warnThreshold,
			colorDD = Val(db.colorDD), colorHealer = Val(db.colorHealer), colorWarn = Val(db.colorWarn),
			colorRegain = Val(db.colorRegain), colorClaimed = Val(db.colorClaimed),
			sound = db.sound and "ja" or "nein",
			soundHealer = db.soundHealer, soundDD = db.soundDD, soundRegain = db.soundRegain,
			soundResist = db.soundResist, soundEmergency = db.soundEmergency, soundChannel = db.soundChannel,
			chatChannel = db.chatChannel, centerSize = db.centerSize, centerY = db.centerY,
			hudPoint = pt(db.hudPoint), meterPoint = pt(db.meterPoint), ddPoint = pt(db.ddPoint),
			simSecret = ns.simSecret and "ja" or "nein", liveTest = ns.liveTest and "ja" or "nein",
			testPetTank = db.testPetTank and "ja" or "nein",
			screenshots = DB(true).shots and "ja" or "nein",
		}
		local m = DB(true).meta
		m[#m + 1] = meta
		while #m > MAX_META do table.remove(m, 1) end
		self:E("META", "date", meta.date, "client", meta.client, "version", ns.version)
		self:Mode()
	end)
end

-- Testumgebung (Live-Test, Simulation, Pet als Tank) - auch bei jeder Änderung
function LG:Mode()
	if not self.on then return end
	self:E("MODE", "live", ns.liveTest, "sim", ns.simSecret, "petTank", ns.db.testPetTank,
		"tankUnit", ns:TankUnit(), "demo", ns.testMode)
end

------------------------------------------------------------
-- Ein / aus
------------------------------------------------------------
local castFrame = CreateFrame("Frame")

local function RegisterCasts()
	castFrame:RegisterUnitEvent("UNIT_SPELLCAST_SUCCEEDED", "player", "pet")
	castFrame:RegisterUnitEvent("UNIT_SPELLCAST_FAILED", "player", "pet")
end

function LG:SetOn(on)
	local t = DB(true)
	t.on = on and true or false
	if on then
		if not self.on then
			self.on = true
			self.start = GetTime()
			self.epoch = self.epoch + 1
			self.shotCount, self.lastShot, self.shotsBlocked, self.meterShot = 0, 0, false, false
			wipe(self.seen); wipe(self.alertKeys); wipe(self.last)
			RegisterCasts()
			self:WriteMeta()
		end
		ns:Print(string.format(L.LOG_ON, MAX_EVENTS))
	else
		local wasOn = self.on
		if self.on then
			self:E("LOG", "on", 0)
			self.on = false
			castFrame:UnregisterAllEvents()
		end
		ns:Print(L.LOG_OFF)
		-- Rapport im Spiel, sobald der Test beendet wird
		if wasOn then self:ShowSummary() end
	end
	if ns.Test and ns.Test.RefreshLog then ns.Test:RefreshLog() end
end

function LG:Clear()
	local t = DB()
	if t then wipe(t.events); wipe(t.meta) end
	wipe(self.last)
	if self.on then self:WriteMeta() end
	ns:Print(L.LOG_CLEARED)
	if ns.Test and ns.Test.RefreshLog then ns.Test:RefreshLog() end
end

function LG:Count()
	local t = DB()
	return t and #t.events or 0
end

function LG:Status()
	local t = DB()
	ns:Print(string.format(L.LOG_STATUS, self.on and L.LOG_STATE_ON or L.LOG_STATE_OFF,
		t and #t.events or 0, MAX_EVENTS, t and #t.meta or 0, self.shotCount,
		(not t or t.shots) and L.LOG_STATE_ON or L.LOG_STATE_OFF))
end

function LG:Command(arg)
	arg = ((arg or ""):lower()):match("^%s*(.-)%s*$")
	if arg == "an" or arg == "on" then self:SetOn(true)
	elseif arg == "aus" or arg == "off" then self:SetOn(false)
	elseif arg == "leeren" or arg == "clear" then self:Clear()
	elseif arg == "bericht" or arg == "report" then self:ShowSummary()
	elseif arg == "bilder" or arg == "shots" then
		local t = DB(true)
		t.shots = not t.shots
		ns:Print(t.shots and L.LOG_SHOTS_ON or L.LOG_SHOTS_OFF)
	else self:Status() end
end

------------------------------------------------------------
-- Screenshots (gedrosselt)
------------------------------------------------------------
function LG:Shot(reason, delay)
	if not self.on then return end
	local t = DB()
	if not t or not t.shots then return end
	local function take()
		if not LG.on then return end
		local now = GetTime()
		if LG.shotsBlocked or not Screenshot or LG.shotCount >= MAX_SHOTS or now - LG.lastShot < SHOT_GAP then
			LG:E("SHOT", "reason", reason, "nr", "skip",
				"why", LG.shotsBlocked and "blocked" or (not Screenshot and "noapi") or (LG.shotCount >= MAX_SHOTS and "max") or "throttle")
			return
		end
		LG.lastShot = now
		LG.pendingShot = true
		local ok = pcall(Screenshot)
		-- ein geblockter Aufruf löst keinen Lua-Fehler aus, sondern ADDON_ACTION_BLOCKED (siehe unten)
		C_Timer.After(0, function() LG.pendingShot = false end)
		if ok and not LG.shotsBlocked then
			LG.shotCount = LG.shotCount + 1
			LG:E("SHOT", "reason", reason, "nr", LG.shotCount, "clock", date("%H:%M:%S"))
		else
			LG:E("SHOT", "reason", reason, "nr", "skip", "why", ok and "blocked" or "error")
		end
	end
	if delay and delay > 0 then
		C_Timer.After(delay, function() pcall(take) end)
	else
		pcall(take)
	end
end

------------------------------------------------------------
-- Aufrufe aus den anderen Teilen (alle über pcall)
------------------------------------------------------------
local function StateImpl(self, unit, m, prev, via)
	local id = self:Id(m.key)
	local to = m.state
	if to == "IDLE" then to = "NONE" end
	if to == "LOOSE" and m.claimedBy then to = "CLAIMED" end
	self:E("STATE", "id", id, "unit", unit, "from", prev or "NONE", "to", to,
		"victim", m.victim, "role", m.victimRole, "via", via)
	-- Plakette: im nächsten Bild (nachdem sie gezeichnet wurde), nach 0.2 s und nach 0.6 s
	C_Timer.After(0, function() if ns.mobs[unit] == m then pcall(LG.Plate, LG, unit, "state") end end)
	C_Timer.After(0.2, function() if ns.mobs[unit] == m then pcall(LG.Plate, LG, unit, "0.2s") end end)
	C_Timer.After(0.6, function() if ns.mobs[unit] == m then pcall(LG.Plate, LG, unit, "0.6s") end end)
	-- Bilder
	if m.state == "LOOSE" and not m.claimedBy then
		local first = not self.seen[id]
		self.seen[id] = true
		self:Shot(first and "loose-first+0.3s" or "loose+0.3s", 0.3)
	elseif prev == "LOOSE" and (m.state == "HELD" or m.state == "WARN") then
		self:Shot("regain+0.1s", 0.1)
	end
end

-- Zustandswechsel eines Mobs (aus Threat.lua)
function LG:State(unit, m, prev, via)
	if not self.on then return end
	pcall(StateImpl, self, unit, m, prev, via)
end

-- Kontrolleffekt erkannt (aus Threat.lua), egal ob ignoriert oder nicht
function LG:CC(unit, m, spell)
	if not self.on then return end
	pcall(function()
		local sig = tostring(spell)
		if m.loggedCC == sig and m.loggedCCEpoch == self.epoch then return end
		m.loggedCC, m.loggedCCEpoch = sig, self.epoch
		self:E("CC", "id", self:Id(m.key), "spell", spell, "ignored", ns.db.ignoreCC)
	end)
end

-- Plakette: tatsächlicher Frame-Zustand
function LG:Plate(unit, reason)
	if not self.on then return end
	local m = ns.mobs[unit]
	local ok, info = pcall(ns.Plates.Inspect, ns.Plates, unit)
	if not ok or not info then return end
	local args = {}
	local function add(k, v) args[#args + 1] = k; args[#args + 1] = Val(v) end
	add("reason", reason); add("id", self:Id(m and m.key)); add("unit", unit); add("state", m and m.state)
	add("alpha", info.alpha); add("hpAlpha", info.hpAlpha); add("scale", info.scale); add("effScale", info.effScale)
	add("border", info.border); add("borderRGB", info.borderRGB); add("pulse", info.pulse); add("flash", info.flash)
	add("hint", info.hint); add("tag", info.tag); add("mark", info.mark); add("markAlpha", info.markAlpha)
	add("castAlpha", info.castAlpha); add("strata", info.strata); add("shown", info.shown)
	if reason == "periodic" then
		-- Vergleich ohne "reason", damit nur echte Änderungen geschrieben werden
		local sig = table.concat(args, ";", 3)
		self:Changed("plate:" .. unit, sig, "PLATE", unpack(args))
	else
		self.last["plate:" .. unit] = table.concat(args, ";", 3)
		self:E("PLATE", unpack(args))
	end
end

------------------------------------------------------------
-- Regelmässig: Bedrohung, HUD, Aggrometer, DD-Ansicht, Plaketten
------------------------------------------------------------
local function Round(v, step)
	if v == nil or issecret(v) or ns.IsSecret(v, "threatValues") or type(v) ~= "number" then return "x" end
	return tostring(math.floor(v / step + 0.5) * step)
end

function LG:PollThreat()
	local tank = ns:TankUnit()
	for unit, m in pairs(ns.mobs) do
		if m.state and m.state ~= "IDLE" then
			local id = self:Id(m.key)
			local units = { tank }
			if tank ~= "player" then units[2] = "player" end
			for _, u in ipairs(units) do
				local ok, isT, status, pct, raw = pcall(UnitDetailedThreatSituation, u, unit)
				local who = (u == tank) and "tank" or "player"
				if ok then
					local sT = issecret(isT) and "S" or tostring(isT)
					local sS = issecret(status) and "S" or tostring(status)
					-- Vergleich gerundet (5-%-Schritte), damit der Puffer nicht überläuft
					local sig = sT .. ":" .. sS .. ":" .. Round(pct, 5)
					self:Changed("thr:" .. unit .. ":" .. who, sig, "THREAT", "id", id, "unit", who,
						"tanking", isT, "status", status, "pct", Val(pct, "threatValues"), "raw", Val(raw, "threatValues"))
				end
			end
		end
	end
end

function LG:PollFrames()
	-- HUD
	local h = ns.HUD and ns.HUD.f
	if h then
		local rows, first = 0, {}
		for _, l in ipairs(h.lines or {}) do
			if l:IsShown() then
				rows = rows + 1
				if #first < 3 then first[#first + 1] = Val(l:GetText()) end
			end
		end
		local hdr = h.header and Val(h.header:GetText()) or "-"
		local sig = tostring(h:IsVisible()) .. hdr .. rows .. table.concat(first, "/")
		self:Changed("hud", sig, "HUD", "shown", h:IsVisible(), "header", hdr, "rows", rows, "first", table.concat(first, "/"))
	end
	-- Aggrometer (Zahlen gerundet verglichen)
	local mt = ns.Meter and ns.Meter.f
	if mt then
		local rows, sigRows = {}, {}
		for _, r in ipairs(mt.rows or {}) do
			if r:IsShown() then
				local name, value = Val(r.name:GetText()), Val(r.value:GetText())
				rows[#rows + 1] = name .. ":" .. value
				local n = tonumber((value:match("^(%d+)")))
				sigRows[#sigRows + 1] = name .. ":" .. (n and tostring(math.floor(n / 10) * 10) or value)
			end
		end
		local shown = mt:IsVisible()
		local title, lead = Val(mt.title:GetText()), Val(mt.lead:GetText())
		local sig = tostring(shown) .. title .. (lead:gsub("%d+", "#")) .. table.concat(sigRows, "/")
		self:Changed("meter", sig, "METER", "shown", shown, "title", title, "lead", lead, "rows", table.concat(rows, "/"))
		if shown and UnitAffectingCombat("player") and not self.meterShot then
			self.meterShot = true
			self:Shot("meter-first")
		end
	end
	-- DD-Ansicht
	local dd = ns.DD and ns.DD.f
	if dd then
		local r, g, b = dd.bar:GetStatusBarColor()
		local rgb = (issecret(r) or issecret(g) or issecret(b)) and "SECRET" or string.format("%.2f,%.2f,%.2f", r or 0, g or 0, b or 0)
		local text = Val(dd.text:GetText())
		local sig = tostring(dd:IsVisible()) .. rgb .. (text:gsub("%d+", function(d) return tostring(math.floor(tonumber(d) / 10) * 10) end))
		self:Changed("dd", sig, "DD", "shown", dd:IsVisible(), "text", text, "rgb", rgb)
	end
end

function LG:Tick()
	if not self.on then return end
	pcall(self.PollFrames, self)
	if UnitAffectingCombat("player") then
		pcall(self.PollThreat, self)
		self.plateAcc = (self.plateAcc or 0) + 1
		if self.plateAcc >= 2 then   -- jede Sekunde, nur Änderungen
			self.plateAcc = 0
			for unit in pairs(ns.mobs) do pcall(self.Plate, self, unit, "periodic") end
		end
	end
end

------------------------------------------------------------
-- Eingriffe in andere Teile (nur lesen, nie das Verhalten ändern)
------------------------------------------------------------
local function Wrap(obj, name, before, after)
	local orig = obj and obj[name]
	if type(orig) ~= "function" then return end
	obj[name] = function(...)
		local ctx
		if LG.on and before then
			local ok, r = pcall(before, ...)
			if ok then ctx = r end
		end
		local res = { n = 0 }
		local function pack(...) res.n = select("#", ...); for i = 1, res.n do res[i] = (select(i, ...)) end end
		pack(orig(...))
		if LG.on and after then pcall(after, ctx, res[1], ...) end
		return unpack(res, 1, res.n)
	end
end

function LG:Init()
	local t = DB()
	self.on = t and t.on and true or false
	if self.on then
		self.start = GetTime()
		self.epoch = 1
		RegisterCasts()
	end
end

function LG:Login()
	if self.on then
		self.start = GetTime()
		self:WriteMeta()
	end

	-- Meldung in der Mitte: Zustand im nächsten Bild lesen (Deckkraft nach dem Einblenden)
	Wrap(ns.Alerts, "Center",
		function(self)
			local f = self.center
			local prev = (f and f:IsShown() and (f.expire or 0) > GetTime()) and f.key or nil
			return { prev = prev }
		end,
		function(ctx, _, self, text, c, duration, key)
			local f = self.center
			if not f then return end
			local shownNow = f:IsShown() and f.key == key
			local replaced = (ctx and ctx.prev and ctx.prev ~= key and shownNow) and ctx.prev or "-"
			local blockedBy = (not shownNow and ctx and ctx.prev) or "-"
			C_Timer.After(0, function()
				pcall(function()
					local _, size = f.text:GetFont()
					LG:E("ALERT", "key", key, "text", text, "rgb", c, "size", size,
						"shown", shownNow and f:IsVisible(), "alpha", f:GetAlpha(), "strata", f:GetFrameStrata(),
						"bg", f.bg and f.bg:IsShown(), "replaced", replaced, "blockedBy", blockedBy)
				end)
			end)
			if shownNow and key and not LG.alertKeys[key] then
				LG.alertKeys[key] = true
				LG:Shot("alert-" .. key, 0.1)
			end
		end)

	-- Ton (Play liefert played)
	Wrap(ns.Alerts, "Play", nil, function(_, played, self, key)
		if played ~= nil then LG:E("SOUND", "key", key, "file", ns.Alerts.lastSoundFile, "played", played) end
	end)

	-- Tank-Sync (Send liefert true, wenn wirklich gesendet)
	Wrap(ns.Sync, "Send", nil, function(_, sent, self, msg)
		if sent ~= nil then LG:E("SYNC", "dir", "out", "msg", msg, "sent", sent) end
	end)
	Wrap(ns.Sync, "Handle", nil, function(_, _, self, name, msg) LG:E("SYNC", "dir", "in", "msg", msg, "from", name) end)

	-- Fehler
	Wrap(ns, "ReportError", nil, function(_, _, self, err)
		local first = tostring(err):match("^[^\n]*") or "?"
		LG:E("ERROR", "where", first:match("^([^:]+:%d+)") or "?", "msg", first, "count", ns.errorCount)
	end)

	-- Testassistent
	if ns.Guide then
		Wrap(ns.Guide, "Finish",
			function() return ns.db.guide and ns.db.guide.step end,
			function(step, _, self, result)
				local s = step and ns.Guide.STEPS[step]
				LG:E("GUIDE", "step", step, "id", s and s.id, "result", result)
			end)
	end

	-- Testumgebung
	for _, fn in ipairs({ "SetLive", "SetSimulation", "SetDemo" }) do
		Wrap(ns.Test, fn, nil, function() LG:Mode() end)
	end

	C_Timer.NewTicker(0.5, function() if LG.on then LG:Tick() end end)
end

------------------------------------------------------------
-- Eigene Ereignisse (nur aktiv, wenn das Protokoll läuft)
------------------------------------------------------------
local function Guarded(fn)
	return function(...)
		if not LG.on then return end
		pcall(fn, ...)
	end
end

ns:On("PLAYER_REGEN_DISABLED", Guarded(function() LG:E("COMBAT", "on", 1) end))
ns:On("PLAYER_REGEN_ENABLED", Guarded(function() LG:E("COMBAT", "on", 0) end))

ns:On("UNIT_PET", Guarded(function(_, unit)
	if unit ~= "player" then return end
	local name, family, lvl = PetInfo()
	LG:E("PET", "name", name, "family", family, "lvl", lvl)
	LG:Mode()
end))

ns:On("NAME_PLATE_UNIT_ADDED", Guarded(function(_, unit)
	LG:E("MOB", "act", "add", "unit", unit, "name", UnitName(unit), "lvl", UnitLevel(unit), "id", RawId(unit))
end))
ns:On("NAME_PLATE_UNIT_REMOVED", Guarded(function(_, unit)
	local m = ns.mobs[unit]
	LG:E("MOB", "act", "remove", "unit", unit, "id", LG:Id(m and m.key),
		"dead", UnitIsDead(unit), "lastState", m and m.state)
	LG.last["plate:" .. unit] = nil
end))

local function OnBlocked(kind)
	return Guarded(function(_, addon, func)
		if addon ~= ADDON then return end
		LG:E("BLOCKED", "func", func, "kind", kind)
		-- geblockter Screenshot: keine Nummer vergeben, keine weiteren Versuche
		if LG.pendingShot or tostring(func):find("Screenshot") then
			LG.shotsBlocked = true
			if LG.pendingShot and LG.shotCount > 0 then LG.shotCount = LG.shotCount - 1 end
			LG:E("SHOT", "reason", "blocked", "nr", "skip")
		end
	end)
end
ns:On("ADDON_ACTION_BLOCKED", OnBlocked("blocked"))
ns:On("ADDON_ACTION_FORBIDDEN", OnBlocked("forbidden"))

-- Spott: Tastendruck (aus TauntButton.lua) und Ergebnis
function LG:OnTauntPress()
	if not self.on then return end
	local mode = ns.tauntMode
	local result = "press"
	if mode == "pet" and not UnitExists("pet") then result = "nopet"
	elseif ns.tauntSpell and ns.SpellCD(ns.tauntSpell) > 0 then result = "cd" end
	local mo, tg, range
	if ns.Safe(UnitExists("mouseover"), false) then
		mo = UnitName("mouseover")
		range = ns.SpellInRange(ns.tauntSpell, "mouseover")
	end
	if ns.Safe(UnitExists("target"), false) then tg = UnitName("target") end
	self:E("TAUNT", "src", "key", "macro", ns.Taunt.taunt and ns.Taunt.taunt:GetAttribute("macrotext"),
		"mouseover", mo, "target", tg, "inRange", range, "result", result)
	self.pressAt = GetTime()
end

castFrame:SetScript("OnEvent", function(_, event, unit, _, spellID)
	if not LG.on then return end
	pcall(function()
		if issecret(unit) or issecret(spellID) then return end
		local name = ns.SpellName(spellID)
		if not name or name ~= ns.tauntSpell then return end
		local src = (GetTime() - (LG.pressAt or 0) < 1.5) and "key" or "auto"
		LG:E("TAUNT", "src", src, "caster", unit, "result", event == "UNIT_SPELLCAST_SUCCEEDED" and "cast" or "fail")
	end)
end)

------------------------------------------------------------
-- Auswertung: Rapport im Spiel
-- Liest die Zeilen der letzten Sitzung (ab dem letzten META) und prüft das Aggro-Management.
-- Ergebnis je Prüfung: OK / FEHLER / nicht geprüft (keine passenden Daten).
------------------------------------------------------------
local function Parse(line)
	local t, typ, rest = line:match("^([%d%.%-]+)|(%u+)|(.*)$")
	if not t then return nil end
	local f = {}
	for pair in (rest .. ";"):gmatch("([^;]*);") do
		local k, v = pair:match("^([^=]+)=(.*)$")
		if k then f[k] = v end
	end
	return tonumber(t), typ, f
end

local function Near(a, b, tol)
	a, b = tonumber(a), tonumber(b)
	return a and b and math.abs(a - b) <= tol
end

local function SameColor(rgb, c, tol)
	if not rgb or rgb == "-" or rgb == "SECRET" or not c then return nil end
	local r, g, b = rgb:match("^([%d%.]+),([%d%.]+),([%d%.]+)$")
	if not r then return nil end
	return Near(r, c[1], tol) and Near(g, c[2], tol) and Near(b, c[3], tol)
end

function LG:Analyze()
	local t = DB()
	if not t or #t.events == 0 then return nil end
	local db = ns.db
	-- Sitzung: ab dem letzten META
	local from = 1
	for i = #t.events, 1, -1 do
		if t.events[i]:find("|META|", 1, true) then from = i break end
	end

	local c = {
		mobs = 0, dead = 0, deadLoose = 0, loose = 0, regain = 0, regainTimes = {}, warn = 0,
		heldPlates = 0, heldOK = 0, loosePlates = 0, looseOK = 0, looseColorOK = 0, looseColorChecked = 0,
		pulseOK = 0, flashSeen = 0, regainPlates = 0,
		alerts = 0, alertsShown = 0, alertsBlocked = 0,
		sounds = 0, soundsPlayed = 0,
		hudLoose = 0, meterShown = 0, ddShown = 0,
		tauntKey = 0, tauntCast = 0, tauntKeyCast = 0, tauntFail = 0,
		resist = 0, errors = 0, blocked = 0, shots = 0, secret = 0, combats = 0,
		viaPct = 0, viaStatus = 0, viaFallback = 0,
	}
	local looseAt = {}      -- id -> Zeit des Aggroverlusts
	local regainAt = {}     -- id -> Zeit der Rückholung (für das Aufblitzen)
	local lastState = {}

	for i = from, #t.events do
		local line = t.events[i]
		if line:find("SECRET", 1, true) then c.secret = c.secret + 1 end
		local tm, typ, f = Parse(line)
		if typ == "COMBAT" and f.on == "1" then c.combats = c.combats + 1
		elseif typ == "MOB" then
			if f.act == "add" then c.mobs = c.mobs + 1
			elseif f.dead == "1" then
				c.dead = c.dead + 1
				if f.lastState == "LOOSE" then c.deadLoose = c.deadLoose + 1 end
			end
		elseif typ == "STATE" then
			local id = f.id
			if f.via == "pct" then c.viaPct = c.viaPct + 1
			elseif f.via == "status" then c.viaStatus = c.viaStatus + 1
			elseif f.via == "fallback" then c.viaFallback = c.viaFallback + 1 end
			if f.to == "LOOSE" then
				c.loose = c.loose + 1
				looseAt[id] = tm
			elseif (f.to == "HELD" or f.to == "WARN") and f.from == "LOOSE" then
				c.regain = c.regain + 1
				if looseAt[id] then c.regainTimes[#c.regainTimes + 1] = tm - looseAt[id] end
				regainAt[id] = tm
			end
			if f.to == "WARN" then c.warn = c.warn + 1 end
			lastState[id] = f.to
		elseif typ == "PLATE" and (f.reason == "0.2s" or f.reason == "0.6s") then
			if f.state == "HELD" then
				c.heldPlates = c.heldPlates + 1
				if Near(f.alpha, db.heldPlateAlpha, 0.06) and f.border ~= "1" then c.heldOK = c.heldOK + 1 end
			elseif f.state == "LOOSE" and f.reason == "0.2s" then
				c.loosePlates = c.loosePlates + 1
				if f.border == "1" and f.shown == "1" then c.looseOK = c.looseOK + 1 end
				if not db.loosePulse or f.pulse == "1" then c.pulseOK = c.pulseOK + 1 end
				local ok1 = SameColor(f.borderRGB, db.colorDD, 0.06)
				local ok2 = SameColor(f.borderRGB, db.colorHealer, 0.06)
				local ok3 = SameColor(f.borderRGB, db.colorClaimed, 0.06)
				if ok1 ~= nil then
					c.looseColorChecked = c.looseColorChecked + 1
					if ok1 or ok2 or ok3 then c.looseColorOK = c.looseColorOK + 1 end
				end
			end
		elseif typ == "PLATE" and f.reason == "state" and regainAt[f.id] and tm - regainAt[f.id] < 0.5 then
			c.regainPlates = c.regainPlates + 1
			if f.flash == "1" then c.flashSeen = c.flashSeen + 1 end
		elseif typ == "ALERT" then
			c.alerts = c.alerts + 1
			if f.shown == "1" then c.alertsShown = c.alertsShown + 1 end
			if f.blockedBy and f.blockedBy ~= "-" then c.alertsBlocked = c.alertsBlocked + 1 end
		elseif typ == "SOUND" then
			c.sounds = c.sounds + 1
			if f.played == "1" then c.soundsPlayed = c.soundsPlayed + 1 end
		elseif typ == "HUD" then
			local n = tonumber(f.header and f.header:match("(%d+)"))
			if f.shown == "1" and n and n > 0 then c.hudLoose = c.hudLoose + 1 end
		elseif typ == "METER" and f.shown == "1" and f.rows and f.rows ~= "" then c.meterShown = c.meterShown + 1
		elseif typ == "DD" and f.shown == "1" then c.ddShown = c.ddShown + 1
		elseif typ == "TAUNT" then
			if f.src == "key" and f.result == "press" then c.tauntKey = c.tauntKey + 1 end
			if f.result == "cast" then
				c.tauntCast = c.tauntCast + 1
				if f.src == "key" then c.tauntKeyCast = c.tauntKeyCast + 1 end
			end
			if f.result == "fail" then c.tauntFail = c.tauntFail + 1 end
		elseif typ == "RESIST" then c.resist = c.resist + 1
		elseif typ == "ERROR" then c.errors = c.errors + 1
		elseif typ == "BLOCKED" then c.blocked = c.blocked + 1
		elseif typ == "SHOT" and f.nr and f.nr ~= "skip" then c.shots = c.shots + 1
		end
	end

	-- Prüfungen: { Text, Ergebnis ("ok" / "fail" / "na"), Detail }
	local R = {}
	local function check(label, result, detail) R[#R + 1] = { label = label, result = result, detail = detail } end
	local function ratio(okN, n) return string.format("%d/%d", okN, n) end

	check(L.SUM_FIGHT, c.mobs > 0 and "ok" or "na", string.format(L.SUM_FIGHT_D, c.combats, c.mobs, c.dead))
	check(L.SUM_LOOSE, c.loose > 0 and "ok" or "na", string.format(L.SUM_LOOSE_D, c.loose,
		c.viaPct, c.viaStatus, c.viaFallback))
	local avg
	if #c.regainTimes > 0 then
		local s = 0
		for _, v in ipairs(c.regainTimes) do s = s + v end
		avg = s / #c.regainTimes
	end
	check(L.SUM_REGAIN, c.loose == 0 and "na" or (c.regain > 0 and "ok" or "fail"),
		string.format(L.SUM_REGAIN_D, c.regain, avg and string.format("%.1f", avg) or "-", c.deadLoose))
	check(L.SUM_WARN, c.warn > 0 and "ok" or "na", string.format(L.SUM_COUNT, c.warn))
	check(L.SUM_HELDPLATE, c.heldPlates == 0 and "na" or (c.heldOK == c.heldPlates and "ok" or "fail"),
		string.format(L.SUM_HELDPLATE_D, ratio(c.heldOK, c.heldPlates), math.floor((db.heldPlateAlpha or 0) * 100 + 0.5)))
	check(L.SUM_LOOSEPLATE, c.loosePlates == 0 and "na" or (c.looseOK == c.loosePlates and "ok" or "fail"),
		string.format(L.SUM_LOOSEPLATE_D, ratio(c.looseOK, c.loosePlates), ratio(c.pulseOK, c.loosePlates)))
	check(L.SUM_COLOR, c.looseColorChecked == 0 and "na" or (c.looseColorOK == c.looseColorChecked and "ok" or "fail"),
		ratio(c.looseColorOK, c.looseColorChecked))
	check(L.SUM_FLASH, c.regainPlates == 0 and "na" or (c.flashSeen > 0 and "ok" or "fail"),
		ratio(c.flashSeen, c.regainPlates))
	check(L.SUM_HUD, c.loose == 0 and "na" or (c.hudLoose > 0 and "ok" or "fail"), string.format(L.SUM_COUNT, c.hudLoose))
	check(L.SUM_METER, c.combats == 0 and "na" or (c.meterShown > 0 and "ok" or "fail"), string.format(L.SUM_COUNT, c.meterShown))
	check(L.SUM_DD, c.combats == 0 and "na" or (c.ddShown > 0 and "ok" or "fail"), string.format(L.SUM_COUNT, c.ddShown))
	check(L.SUM_ALERTS, c.alerts == 0 and "na" or (c.alertsShown > 0 and "ok" or "fail"),
		string.format(L.SUM_ALERTS_D, c.alertsShown, c.alerts, c.alertsBlocked))
	check(L.SUM_SOUNDS, c.sounds == 0 and "na" or (c.soundsPlayed == c.sounds and "ok" or "fail"),
		ratio(c.soundsPlayed, c.sounds))
	check(L.SUM_TAUNT, c.tauntKey == 0 and "na" or (c.tauntKeyCast > 0 and "ok" or "fail"),
		string.format(L.SUM_TAUNT_D, c.tauntKey, c.tauntKeyCast, c.tauntCast, c.tauntFail, c.resist))
	check(L.SUM_ERRORS, (c.errors == 0 and c.blocked == 0) and "ok" or "fail",
		string.format(L.SUM_ERRORS_D, c.errors, c.blocked))
	check(L.SUM_SECRET, "info", string.format(L.SUM_SECRET_D, c.secret))
	check(L.SUM_SHOTS, "info", string.format(L.SUM_COUNT, c.shots))
	return R, c
end

function LG:SummaryText(plain)
	local R = self:Analyze()
	if not R then return L.SUM_EMPTY end
	local okN, failN, naN = 0, 0, 0
	local lines = {}
	for _, r in ipairs(R) do
		local tag
		if r.result == "ok" then okN = okN + 1; tag = plain and "[OK]" or "|cff40ff40OK|r"
		elseif r.result == "fail" then failN = failN + 1; tag = plain and "[FEHLER]" or ("|cffff5050" .. L.SUM_FAIL .. "|r")
		elseif r.result == "na" then naN = naN + 1; tag = plain and "[-]" or ("|cff888888" .. L.SUM_NA .. "|r")
		else tag = plain and "[i]" or "|cff9fc8ffi|r" end
		lines[#lines + 1] = tag .. "  " .. r.label .. (r.detail and (": " .. r.detail) or "")
	end
	local head = string.format(L.SUM_HEAD, okN, failN, naN)
	return head .. "\n\n" .. table.concat(lines, "\n")
end

function LG:ShowSummary()
	if not self.sumFrame then
		local f = CreateFrame("Frame", "ThreatSentinelSummary", UIParent, BACKDROP)
		f:SetSize(560, 440)
		f:SetPoint("CENTER")
		f:SetFrameStrata("FULLSCREEN_DIALOG")
		f:EnableMouse(true)
		f:SetMovable(true)
		f:RegisterForDrag("LeftButton")
		f:SetScript("OnDragStart", f.StartMoving)
		f:SetScript("OnDragStop", f.StopMovingOrSizing)
		if f.SetBackdrop then
			f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
			f:SetBackdropColor(0.05, 0.06, 0.08, 0.97)
			f:SetBackdropBorderColor(0.25, 0.65, 1, 0.8)
		end
		tinsert(UISpecialFrames, "ThreatSentinelSummary")
		local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
		title:SetPoint("TOPLEFT", 12, -10)
		title:SetText("|cff3fa7ffThreat|rSentinel - " .. L.SUM_TITLE)
		local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
		close:SetPoint("TOPRIGHT", -2, -2)
		f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
		f.text:SetPoint("TOPLEFT", 14, -40)
		f.text:SetWidth(530)
		f.text:SetJustifyH("LEFT")
		f.text:SetSpacing(3)
		local copy = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
		copy:SetSize(150, 22)
		copy:SetPoint("BOTTOMLEFT", 12, 10)
		copy:SetText(L.SUM_COPY)
		copy:SetScript("OnClick", function()
			-- Testbericht der Testzentrale zeigt den kopierbaren Text (inkl. Auswertung)
			if ns.Test and ns.Test.ShowReport then ns.Test:ShowReport() end
		end)
		local hint = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
		hint:SetPoint("BOTTOMRIGHT", -12, 14)
		hint:SetText(L.SUM_HINT)
		self.sumFrame = f
	end
	local f = self.sumFrame
	f.text:SetText(self:SummaryText(false))
	f:SetHeight(math.max(240, (f.text:GetStringHeight() or 300) + 90))
	f:Show()
end
