if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Ketten.lua (Herstellungs-Ketten, S3b/S3-2, Vorgaben des Nutzers 14.11. 14:51, BR-W1)
--   (1) Berufe/Rezepte je Figur: gemerkte Rezepte (Crafting.lua Cr:KnownRecipes, beim Öffnen des Berufsfensters gelesen)
--   (2) Ketten je Figur gespeichert (A.db.chains[Figur]), nach jedem Scan neu gerechnet (Hintergrund-Arbeit), nie beim Öffnen
--   (3) je Kette: Produkt, Weg (verkaufen / entzaubern), Gewinn als Zahl, Einkaufsliste (einkaufbare Zutaten)
--   (4) NUR was Gold bringt: Verlust oder unter dem Mindestgewinn (20 %) fällt heraus und wird nur gezählt (Ursache)
-- Zutaten-Kosten = Preis, zu dem die Menge für eine Serie (SERIES Herstellungen) wirklich kaufbar ist (Preis-Leiter, BR-W1),
-- Händlerware zum Händlerpreis, Zwischenprodukte aus bekannten Rezepten (mehrstufig, Kreise verhindert, Tiefe DEPTH).
-- Produkt = realistischer Wert aus der einen Preisfunktion (A:RealValue, nach Gebühren) bzw. Entzauber-Wert (Cr).
-- FREIGABE (Nutzer 14:09 "alles 3 mal geprüft"): bis zur Freigabe durch den Supervisor NUR im Testbericht
-- ("MARKT-KERN Ketten"), nicht in Tooltip/Markt (Ke.LIVE = false).
-- KETTE-K1 (Nutzer 15.11. 07:12 "soweit, dass wir releasen können"): Release-Kandidat mit Ke.LIVE = true – "Heute tun" zeigt
-- "Stelle n× … her (+x je Stück)" mit derselben Zahl wie "Beste Rezepte" (Cr:EvalRecipe). Geht nur nach der Prüfung des
-- Supervisors auf CurseForge; findet er einen Fehler, wird LIVE im nächsten Kandidaten wieder false.
-- ============================================================
local A = AHAnalyzerPro
local CreateFrame, C_Timer = A.OwnCreateFrame or CreateFrame, A.OwnTimer or C_Timer      -- VS-BILD-2 (0.65.320): eigene Skripte/Zeitgeber je Bild messen (nur während einer Vollscan-Messung)
if not (A and A.On) then return end
-- FOREVER-API (Hinweis Prüf-Sitzung 18.11. 10:30): im Forever-Client 1.60.1 gibt es nur C_Item.GetItemInfo/GetItemCount - Weiche
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local GetItemCount = GetItemCount or (C_Item and C_Item.GetItemCount)
local Ke = {}
A.Ketten = Ke

Ke.LIVE = true
Ke.SERIES, Ke.DEPTH, Ke.MIN_GAIN, Ke.MAX_RECIPES = 20, 3, 0.20, 400

local function CharKey() return A.Chars and A.Chars:Key() or ((UnitName and UnitName("player")) or "?") end

-- Rezepte dieser Figur: [productID] = { made, reagents = { {id, n}, ... }, name, prof }. Testroutine: Ke.testRecipes
Ke.RECIPE_TTL = 300
function Ke:Recipes()
    if self.testRecipes then return self.testRecipes end
    -- TB170-2 (T373 cache:today 18,8 ms): Rezeptliste höchstens alle RECIPE_TTL Sekunden neu (Cr:Remember verwirft sie)
    local c = self.recipeCache
    if c and time() - c.t < self.RECIPE_TTL then return c.map end
    local map = {}
    local Cr = A.Crafting
    if not (Cr and Cr.KnownRecipes) then return map end
    local ok, list = pcall(Cr.KnownRecipes, Cr)
    for i, r in ipairs(ok and list or {}) do
        if i > self.MAX_RECIPES then break end
        if r.productID and not map[r.productID] then map[r.productID] = r end
        if i % 50 == 0 and A.Pause then A:Pause() end
    end
    self.recipeCache = { t = time(), map = map }
    return map
end

-- Preise (Nahtstellen für die Testroutine: Ke.testPrice = { [id] = { ah = Stückpreis, ladder = {{p,q},...}, vendor = Kaufpreis,
-- sell = Wert nach Gebühren je Stück, de = Entzauber-Wert je Stück } })
function Ke:VendorBuy(id)
    if self.testPrice then local p = self.testPrice[id]; return p and p.vendor end
    local ok, v = pcall(A.GetVendorBuyPrice, A, id)
    return ok and type(v) == "number" and v > 0 and v or nil
end
function Ke:Ladder(id)
    if self.testPrice then local p = self.testPrice[id]; return p and p.ladder end
    local ok, l = pcall(A.OfferLadder, A, id)
    return ok and type(l) == "table" and #l > 0 and l or nil
end
function Ke:AHUnit(id)
    if self.testPrice then local p = self.testPrice[id]; return p and p.ah end
    local ok, v = pcall(A.RealPrice, A, id)
    return ok and type(v) == "number" and v > 0 and v or nil
end
-- Kosten für qty Stück im AH über die Preisleiter (nicht billigstes Einzelstück × Menge, BR-W1). Geschätzte Stufen (3. Feld)
-- nicht unter dem letzten echten Preis. Was die Leiter nicht hergibt: teuerster bekannter Preis. Zurück: Kosten oder nil
function Ke:AHCost(id, qty)
    local unit = self:AHUnit(id)
    local ladder = self:Ladder(id)
    if not ladder then return unit and unit * qty or nil end
    local left, cost, last = qty, 0, unit or 0
    for _, st in ipairs(ladder) do
        if left <= 0 then break end
        local p, q = st[1], st[2] or 0
        if p and q > 0 then
            local take = math.min(left, q)
            cost, left, last = cost + take * p, left - take, math.max(last, p)
        end
    end
    if left > 0 then
        if last <= 0 then return nil end
        cost = cost + left * last
    end
    return cost
end

-- günstigster Weg für qty Stück einer Zutat: Kosten, Weg ("vendor"/"ah"/"craft"), Einkaufsliste {id -> Menge}, Grund (nil)
-- visiting: Kreise verhindern (A aus B, B aus A)
function Ke:ReagentCost(id, qty, recipes, depth, visiting)
    local best, how, buy = nil, nil, nil
    local v = self:VendorBuy(id)
    if v then best, how, buy = v * qty, "vendor", { [id] = qty } end
    local ah = self:AHCost(id, qty)
    if ah and (not best or ah < best) then best, how, buy = ah, "ah", { [id] = qty } end
    local rec = recipes[id]
    if rec and depth < self.DEPTH and not visiting[id] then
        visiting[id] = true
        local crafts = math.ceil(qty / math.max(rec.made or 1, 1))
        local sum, list, ok = 0, {}, true
        for _, re in ipairs(rec.reagents or {}) do
            local c, _, b = self:ReagentCost(re[1], crafts * (re[2] or 1), recipes, depth + 1, visiting)
            if not c then ok = false; break end
            sum = sum + c
            for k, n in pairs(b) do list[k] = (list[k] or 0) + n end
        end
        visiting[id] = nil
        if ok and (not best or sum < best) then best, how, buy = sum, "craft", list end
    elseif rec and visiting[id] then
        self.cycles = (self.cycles or 0) + 1
    end
    if not best then return nil, nil, nil, "Preis fehlt" end
    return best, how, buy
end

-- Wert des Produkts (für made Stück): bester Weg (verkaufen nach Gebühren / entzaubern), Weg. Für Anzeigen ausserhalb der
-- Kette; die Kette selbst rechnet mit Cr:EvalRecipe (eine Zahl mit "Beste Rezepte").
function Ke:ProductValue(pid, made)
    local sell, de
    if self.testPrice then
        local p = self.testPrice[pid] or {}
        sell, de = p.sell and p.sell * made, p.de and p.de * made
    else
        local ok, rv = pcall(A.RealValue, A, pid, made)
        sell = ok and type(rv) == "number" and rv or nil
        local Cr = A.Crafting
        if Cr and Cr.DisenchantValue then
            local okD, d = pcall(Cr.DisenchantValue, Cr, pid, made)
            de = okD and d or nil
        end
    end
    if de and (not sell or de > sell) then return de, "de" end
    if sell then return sell, "sell" end
    return nil
end

-- Testroutine: Ke.testPrice auf die Bewertung von Crafting legen (nur eigene Funktionen, für die Dauer von fn)
function Ke:WithTestPrices(fn)
    local tp = self.testPrice
    if not tp then return fn() end
    local Cr = A.Crafting
    local sv = { up = Cr.UnitPrice, su = Cr.SeriesUnit, dv = Cr.DisenchantValue, rv = A.RealValue, ns = A.NetSale, sf = A.SaleFee, ld = A.ListingDeposit }
    Cr.UnitPrice = function(_, id, isReagent)
        local p = tp[id]
        if not p then return nil end
        if isReagent and p.vendor and (not p.ah or p.vendor < p.ah) then return p.vendor, true end
        return p.ah or p.sellUnit, false
    end
    Cr.SeriesUnit = function(_, id, n, unit)
        local p = tp[id]
        local ladder = p and p.ladder
        if not (ladder and n and n > 0) then return nil end
        local left, cost, last = n, 0, unit or 0
        for _, st in ipairs(ladder) do
            if left <= 0 then break end
            local take = math.min(left, st[2] or 0)
            cost, left, last = cost + take * st[1], left - take, math.max(last, st[1])
        end
        if left > 0 then cost = cost + left * last end
        return cost / n
    end
    Cr.DisenchantValue = function(_, id, made) local p = tp[id]; return p and p.de and math.floor(p.de * (made or 1) + 0.5) or nil end
    A.RealValue = function(_, id, made) local p = tp[id]; return p and p.sell and p.sell * (made or 1) or nil end
    A.NetSale = function(_, id, unit, made) return (unit or 0) * (made or 1) end
    A.SaleFee = function() return 0 end
    A.ListingDeposit = nil
    -- Produkt mit Verkaufswert braucht einen Stückpreis, damit EvalRecipe den Verkauf rechnet
    for _, p in pairs(tp) do if p.sell and not p.ah then p.sellUnit = p.sell end end
    local r = { pcall(fn) }
    Cr.UnitPrice, Cr.SeriesUnit, Cr.DisenchantValue, A.RealValue, A.NetSale, A.SaleFee, A.ListingDeposit = sv.up, sv.su, sv.dv, sv.rv, sv.ns, sv.sf, sv.ld
    for _, p in pairs(tp) do p.sellUnit = nil end
    if not r[1] then error(r[2], 0) end
    return unpack(r, 2, table.maxn(r))
end

-- KETTE-K1: Item-Daten (Qualität, Stufe) geladen? Ohne sie ist kein Entzauber-Wert rechenbar (Befund: Hose fehlte, Handschuhe
-- "verk." statt "ent."). Fehlt etwas, Laden anstossen und die Kette als "Daten fehlen" zählen (Neuberechnung folgt)
function Ke:ItemReady(pid)
    if self.testPrice then return true end
    local name = GetItemInfo and GetItemInfo(pid)
    if name then return true end
    if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, pid) end
    return false
end

-- Taschen-Bestand einer Zutat (wie "Beste Rezepte": eigene Materialien zum Verkaufswert)
function Ke:Have(id)
    if self.testPrice then return 0 end
    local n = GetItemCount and GetItemCount(id) or 0
    return tonumber(n) or 0
end

-- (2) Nachrechen-Zeile: Zutaten mit Menge × Preis (Quelle), Zwischenprodukte, Werte je Weg, gewählter Weg, Gewinn
local SRC = { ah = "AH", vendor = "Händler", craft = "selbst hergestellt" }
function Ke:CalcText(r, rec, recipes)
    local Cr = A.Crafting
    local parts = {}
    for _, g in ipairs(r.reagents or {}) do
        local unit = g.count > 0 and (g.cost or 0) / g.count or 0
        local src = g.via == "craft" and "craft" or (g.atVendor and "vendor" or "ah")
        local txt = string.format("%g× %d à %.1f (%s%s) = %d", g.count, g.itemID or 0, unit, SRC[src], (g.own or 0) > 0 and string.format(", %d eigene", g.own) or "",
            math.floor((g.cost or 0) + 0.5))
        if g.via == "craft" and g.rec then
            local sub = {}
            for _, re in ipairs(g.rec.reagents or {}) do
                local u = Cr:BestUnit(re[1], 1, nil, recipes)
                sub[#sub + 1] = string.format("%g× %d à %.1f", re[2] or 1, re[1], u or 0)
            end
            txt = txt .. " [aus " .. table.concat(sub, " + ") .. string.format(" für %g Stück]", g.rec.made or 1)
        end
        parts[#parts + 1] = txt
    end
    local vendor = 0
    if not self.testPrice and GetItemInfo then
        local sp = select(11, GetItemInfo(r.productID))
        vendor = (tonumber(sp) or 0) * (r.made or 1)
    end
    return string.format("Zutaten: %s · Kosten %d · Werte: verk. %s, ent. %s, Händler %d · Weg %s · Gewinn %+d (%d %%)", table.concat(parts, "; "),
        math.floor(r.cost + 0.5), r.net and tostring(r.net) or "-", r.deNet and tostring(r.deNet) or "-", vendor, r.best == "de" and "ent." or "verk.",
        math.floor((r.profit or 0) + 0.5), r.cost > 0 and math.floor((r.profit or 0) / r.cost * 100 + 0.5) or 0)
end

-- eine Kette rechnen. KETTE-K1 (Entscheid "eine Zahl"): Kosten, Wert und Weg aus Cr:EvalRecipe - dieselbe Rechnung wie
-- "Beste Rezepte" (Zwischenprodukte aus den gemerkten Rezepten der Figur). Einkaufsliste für eine Serie (Ke.SERIES).
function Ke:Chain(pid, recipes)
    local rec = recipes[pid]
    if not rec then return nil, "kein Rezept" end
    local Cr = A.Crafting
    if not (Cr and Cr.EvalRecipe) then return nil, "Bewertung fehlt" end
    if not self:ItemReady(pid) then return nil, "Daten fehlen" end
    return self:WithTestPrices(function()
        local list = {}
        for _, re in ipairs(rec.reagents or {}) do list[#list + 1] = { id = re[1], count = re[2] or 1, have = self:Have(re[1]) } end
        local made = rec.made or 1
        local r = Cr:EvalRecipe(pid, made, list, recipes)
        if r.missing > 0 then return nil, "Preis fehlt" end
        if not r.profit then return nil, "Produkt ohne Preis" end
        local n = self.SERIES
        local buy = {}
        for _, g in ipairs(r.reagents) do Cr:ExpandNeed(g.itemID, g.count * n, buy, 0, recipes) end
        local value = r.best == "de" and r.deNet or r.net
        local profit = math.floor(r.profit + 0.5)
        local c = { pid = pid, name = rec.name, way = r.best, cost = math.floor(r.cost + 0.5), value = math.floor((value or 0) + 0.5), profit = profit,
                    pct = r.cost > 0 and profit / r.cost or nil, buy = buy, series = n, calc = self:CalcText(r, rec, recipes) }
        if profit <= 0 then return c, "Verlust" end
        if not c.pct or c.pct < self.MIN_GAIN then return c, "unter Mindestgewinn" end
        return c
    end)
end

-- alle Ketten dieser Figur rechnen; zurück: Liste (nur Gewinn ≥ Mindestgewinn, absteigend), Ausschluss-Zähler
function Ke:Build()
    local recipes = self:Recipes()
    local list, out = {}, {}
    self.cycles = 0
    local Cr = A.Crafting
    if Cr then Cr.cycles = 0 end
    for pid in pairs(recipes) do
        if A.Pause then A:Pause() end
        local c, why = self:Chain(pid, recipes)
        if c and not why then list[#list + 1] = c
        else out[why or "?"] = (out[why or "?"] or 0) + 1 end
    end
    local cyc = self.cycles + ((Cr and Cr.cycles) or 0)
    if cyc > 0 then out["Kreis verhindert"] = cyc end
    table.sort(list, function(a, b) return a.profit > b.profit end)
    return list, out
end

function Ke:Store()
    if self.testDB then return self.testDB end
    if not A.db or (A.InTestRoutine and A:InTestRoutine()) then return nil end
    A.db.chains = type(A.db.chains) == "table" and A.db.chains or {}
    return A.db.chains
end
-- nach dem Scan: rechnen und je Figur merken (nur Zahlen und Item-IDs; höchstens 30 Ketten)
function Ke:Refresh()
    local st = self:Store()
    if not st then return end
    local list, out = self:Build()
    local keep = {}
    for i = 1, math.min(30, #list) do
        local c = list[i]
        keep[i] = { pid = c.pid, way = c.way, cost = c.cost, value = c.value, profit = c.profit, pct = c.pct, buy = c.buy, series = c.series,
                    calc = i <= 8 and c.calc or nil }
    end
    st[CharKey()] = { t = time(), list = keep, out = out }
    -- KETTE-K1: fehlten Item-Daten, in 5 s einmal neu rechnen (der Client lädt sie inzwischen)
    if (out["Daten fehlen"] or 0) > 0 and not self.retryAt and C_Timer and C_Timer.After and not self.testDB then
        self.retryAt = time()
        C_Timer.After(5, function()
            Ke.retryAt = nil
            if A.Job then A:Job("ketten:refresh", function() Ke:Refresh() end) end
        end)
    end
    return keep
end
function Ke:Saved()
    local st = self.testDB or (A.db and A.db.chains)
    return st and st[CharKey()] or nil
end

-- Selbstkontrolle (SK1-l): vorhergesagter Gewinn je Stück beim Herstellen merken; verkauft -> realisiert aus den Buchungen.
-- Stimmig, wenn eine Kette mit Gewinn auch realisiert Gewinn bringt.
function Ke:NotePrediction(pid)
    local st = self:Store()
    local sv = self:Saved()
    if not (st and sv) then return end
    for _, c in ipairs(sv.list or {}) do
        if c.pid == pid then
            st.pred = st.pred or {}
            st.pred[pid] = { t = time(), p = c.profit }
            return true
        end
    end
end
function Ke:Realized(days)
    local st = self.testDB or (A.db and A.db.chains)
    local pred = st and st.pred or {}
    local BK = A.Books
    local db = BK and BK:Data()
    local since = time() - (days or 30) * 86400
    local n, ok, ex = 0, 0, {}
    -- KETTE-K1 (3): Weg Herstellen -> Entzaubern -> Verkauf der Materialien. Entzaubertes Kettenprodukt (Buchung "de") öffnet
    -- den Weg; danach zählen Verkäufe von Material aus dem Entzaubern (Herkunft "de") - ihr Einstand enthält die Herstellkosten
    local deFrom, deN, matN, matGain = nil, 0, 0, 0
    for _, e in ipairs(db and db.log or {}) do
        local p = e.id and pred[e.id]
        if p and e.k == "sale" and e.st ~= "x" and (e.t or 0) >= math.max(since, p.t) and (e.q or 0) > 0 then
            local real = ((e.rev or 0) - (e.cost or 0)) / e.q
            n = n + 1
            if real > 0 then ok = ok + 1
            elseif #ex < 3 then ex[#ex + 1] = string.format("Item %d: vorhergesagt %+d, realisiert %+d", e.id, p.p, math.floor(real)) end
        elseif p and e.k == "de" and (e.t or 0) >= math.max(since, p.t) then
            deN = deN + 1
            deFrom = deFrom and math.min(deFrom, e.t or 0) or (e.t or 0)
        elseif e.k == "sale" and e.bt == "de" and deFrom and (e.t or 0) >= deFrom and e.st ~= "x" and (e.q or 0) > 0 then
            local real = (e.rev or 0) - (e.cost or 0)
            matN, matGain = matN + 1, matGain + real
            n = n + 1
            if real > 0 then ok = ok + 1
            elseif #ex < 3 then ex[#ex + 1] = string.format("Material %d aus Entzaubern: realisiert %+d", e.id or 0, math.floor(real)) end
        end
    end
    self.lastDE = { de = deN, sales = matN, gain = math.floor(matGain + 0.5) }
    return n, ok, ex
end

-- Testbericht "MARKT-KERN Ketten" (bis zur Freigabe nur hier)
function Ke:ReportLines(out, fields)
    local sv = self:Saved()
    if not sv then
        out[#out + 1] = "  MARKT-KERN Ketten (nur Testbericht, Freigabe offen): noch nicht gerechnet (kein Scan oder keine Rezepte gemerkt)"
        return
    end
    local tops, calcs = {}, {}
    for i, c in ipairs(sv.list or {}) do
        if i > 8 then break end
        tops[#tops + 1] = string.format("%d %s +%d (%d %%, Kosten %d, Wert %d)", c.pid, c.way == "de" and "entz." or "verk.", c.profit, math.floor((c.pct or 0) * 100 + 0.5), c.cost, c.value)
        if c.calc then calcs[#calcs + 1] = string.format("    Nachrechnung %d: %s", c.pid, c.calc) end
    end
    local outs = {}
    for k, v in pairs(sv.out or {}) do outs[#outs + 1] = k .. " " .. v end
    table.sort(outs)
    out[#out + 1] = string.format("  MARKT-KERN Ketten (" .. (self.LIVE and "eingeschaltet" or "nur Testbericht, Freigabe offen") .. ", Serie %d): %d mit Gewinn ≥ %d %% · %s · nicht gezeigt: %s · gerechnet %s",
        self.SERIES, #(sv.list or {}), self.MIN_GAIN * 100, #tops > 0 and table.concat(tops, " | ") or "-", #outs > 0 and table.concat(outs, ", ") or "-",
        sv.t and date("%d.%m. %H:%M", sv.t) or "-")
    for _, l in ipairs(calcs) do out[#out + 1] = l end                 -- KETTE-K1 (2)
    local n, ok, ex = self:Realized(30)
    local d = self.lastDE or {}
    out[#out + 1] = string.format("  SK1-l Weg Herstellen -> Entzaubern -> Verkauf: %d Kettenteile entzaubert · %d Material-Verkäufe · realisiert %+d",
        d.de or 0, d.sales or 0, d.gain or 0)
    out[#out + 1] = string.format("  SK1-l Ketten vorhergesagt/realisiert: %d Verkäufe · %d mit Gewinn · %d ohne%s", n, ok, n - ok,
        #ex > 0 and (" (" .. table.concat(ex, " | ") .. ")") or "")
    if fields then fields.kern_ketten = string.format("%d/%d/%d", #(sv.list or {}), n, ok) end
end

A:On("SCAN_FINISHED", function()
    if A.Job and not (A.InTestRoutine and A:InTestRoutine()) then A:Job("ketten:refresh", function() Ke:Refresh() end) end
end)
A:On("CRAFT_DONE", function(pid)
    if not (A.InTestRoutine and A:InTestRoutine()) then pcall(Ke.NotePrediction, Ke, pid) end
end)
