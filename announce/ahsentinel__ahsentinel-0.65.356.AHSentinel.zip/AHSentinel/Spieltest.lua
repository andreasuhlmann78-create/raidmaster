if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Spieltest: die Checkliste im Spiel selbst prüfen (ab 0.65.23, Bereich S)
--
-- /ahs spieltest an | aus | bericht   (Standard aus; nach dem Einschalten bis /reload bzw. 2 Stunden aktiv)
--
-- Der Spieltest ruft NIE selbst geschützte Funktionen auf (Fenster öffnen, kaufen, einstellen, herstellen).
-- Er prüft, sobald der Spieler die Lage herstellt, und meldet nur, was NICHT stimmt (eine Chat-Zeile je Prüfung).
-- Jede Prüfung einmal je Lage: OK / FEHLER / offen, mit Messwert und Erwartung
--   -> Diagnose-Protokoll (Eintrag SPIELTEST) und Testbericht (GSTEST1, kind "test", Bereich "S").
-- Keine Namen im Bericht. Im Kampf keine Prüfung, die die Oberfläche anfasst (danach weiter).
--
--  S1 Gebühr im Verkaufen-Reiter       S5 Gewinn-Fenster überdeckt nichts (UICheck)
--  S2 Gebühr echt (Gold vorher/nachher) S6 Händler-Knopf
--  S3 Gewinn-Fenster: Gebühr und Gewinn S7 Neuaufbau beim Herstellen von 5 Gegenständen
--  S4 Entzaubern im Tooltip             S8 kein ADDON_ACTION_BLOCKED/FORBIDDEN mit AHSentinel
--  S9 Hauptfenster öffnet/schliesst mit dem Auktionshaus
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local CreateFrame, C_Timer = A.OwnCreateFrame or CreateFrame, A.OwnTimer or C_Timer      -- VS-BILD-2 (0.65.320): eigene Skripte/Zeitgeber je Bild messen (nur während einer Vollscan-Messung)
local L = A.L

local P = A.Spieltest or {}
A.Spieltest = P

P.DURATION = 2 * 3600        -- so lange bleibt der Spieltest nach dem Einschalten aktiv
P.CRAFTS = 5                 -- S7: nach so vielen hergestellten Gegenständen auswerten
P.SLOW_MS = 16

-- Prüfungen: Kennung, Name, Lage (was der Spieler dafür tun muss)
P.CHECKS = {
    { id = "S1", name = "Gebühr im Verkaufen-Reiter = 5 % vom Preis, Einzahlung in eigener Zeile",
      need = "Auktionshaus öffnen, Reiter Verkaufen, ein Item wählen" },
    { id = "S2", name = "Gebühr echt: abgezogen = angezeigte Gebühr",
      need = "ein Item im Auktionshaus einstellen" },
    { id = "S3", name = "Gewinn-Fenster: Gebühr nach derselben Regel, Gewinn = Wert - Gebühr - Material",
      need = "Berufsfenster öffnen und ein Rezept mit Preis wählen" },
    { id = "S4", name = "Entzaubern im Tooltip - Summe der Anteile = Ø-Wert, \"tatsächlich\" nur mit Entzauberungen",
      need = "mit der Maus über ein entzauberbares Item (grün/blau/episch) fahren" },
    { id = "S5", name = "Gewinn-Fenster überdeckt Berufsfenster und andere Addons nicht",
      need = "Berufsfenster öffnen (Gewinn-Fenster sichtbar)" },
    { id = "S6", name = "Händler-Knopf: verdeckt keinen Reiter, unsichtbar ohne Ware, aus mit LevelPilot-Verkauf",
      need = "einen Händler ansprechen" },
    { id = "S7", name = "Neuaufbau beim Herstellen: höchstens 1 AUFBAU je 2 s, kein LANGSAM über 16 ms",
      need = "5 Gegenstände herstellen" },
    { id = "S8", name = "kein ADDON_ACTION_BLOCKED/FORBIDDEN mit AHSentinel",
      need = "eine Weile normal spielen, dann /ahs spieltest bericht" },
    { id = "S9", name = "Hauptfenster öffnet und schliesst mit dem Auktionshaus (war es vorher offen, bleibt es offen)",
      need = "Auktionshaus öffnen und wieder schliessen" },
    { id = "S10", name = "Einzahlung von AHSentinel = Blizzards \"Einzahlen\" bei gleicher Menge",
      need = "ein Item im Auktionshaus einstellen" },
}
P.BY_ID = {}
for i, c in ipairs(P.CHECKS) do c.order = i; P.BY_ID[c.id] = c end

P.results = P.results or {}     -- [id] = { status = "OK"/"FEHLER", ist, soll, t }
P.warned = P.warned or {}

local function Now() return GetTime and GetTime() or time() end
local function InCombat() return InCombatLockdown and InCombatLockdown() and true or false end

-- ------------------------------------------------------------
-- Auswertungen (reine Funktionen: Daten rein, ok, ist, soll raus) - offline testbar (TestRoutine T204+)
-- ------------------------------------------------------------
local E = {}
P.Eval = E

-- S1 d = { forever, unit, qty, auctions, cut, depositShown }
-- Gebühren wie im klassischen WoW (auch Forever, Anweisung 14:30): AH-Gebühr = 5 % vom Verkaufspreis,
-- die Einzahlung steht in einer eigenen Zeile (sie kommt beim Verkauf zurück)
function E.S1(d)
    local auctions = math.max(1, d.auctions or 1)
    local soll = math.floor(d.unit * d.qty * (d.cutPct or 0.05))
    local ok = d.cut == soll
    return ok, string.format(L["Gebühr %s%s (Preis %d × %d, %d Auktion(en))"], tostring(d.cut), "", d.unit, d.qty, auctions),
        string.format(L["Gebühr %d%s"], soll, "")
end

-- S2 d = { measured, shown }
function E.S2(d)
    return d.measured == d.shown, string.format(L["abgezogen %s"], tostring(d.measured)), string.format(L["angezeigt %s (±0)"], tostring(d.shown))
end

-- S3 d = { forever, value, made, stack, net, cost, profit, depositShown }
function E.S3(d)
    local made = (d.made and d.made > 0) and d.made or 1
    local unit = d.value / made
    -- 5 % (alle Versionen); in Forever kommt der erwartete Einzahlungsverlust dazu (d.depositLoss, aus dem Fenster)
    local fee = d.value * (d.cutPct or 0.05) + (d.depositLoss or 0)
    local sollNet = d.value - math.floor(fee + 0.5)
    local okNet = math.abs((d.net or 0) - sollNet) <= 1
    local okProfit = d.profit == nil or d.profit == d.net - d.cost
    local ok = okNet and okProfit and not (d.forever and d.depositShown)
    return ok, string.format(L["Wert %d, netto %s, Material %d, Gewinn %s%s"], d.value, tostring(d.net), d.cost or 0, tostring(d.profit),
        (d.forever and d.depositShown) and L[", Zeile Einstellgebühr sichtbar"] or ""),
        string.format(L["netto %d (±1), Gewinn = netto - Material"], sollNet)
end

-- S4 d = { estSum, estValue, actualShown, n, nCombined }
function E.S4(d)
    local okSum = d.estValue == nil or math.abs((d.estSum or 0) - d.estValue) <= 1
    local okShown = (d.actualShown == true) == ((d.nCombined or 0) > 0)
    local okN = (d.nCombined or 0) == 0 or d.n == d.nCombined
    return okSum and okShown and okN, string.format(L["Summe Anteile %s, Ø %s, tatsächlich %s (N %s, Entzauberungen %s)"],
        tostring(d.estSum and math.floor(d.estSum + 0.5)), tostring(d.estValue), d.actualShown and L["ja"] or L["nein"], tostring(d.n),
        tostring(d.nCombined)), L["Summe = Ø (±1c), tatsächlich nur mit N > 0, N = eigene + geteilte"]
end

-- S5 d = { problems = { "...", ... }, tested }
function E.S5(d)
    if (d.tested or 0) == 0 then return nil end
    local n = #(d.problems or {})
    return n == 0, n == 0 and string.format(L["geprüft %d"], d.tested) or table.concat(d.problems, "; "), L["nichts überdeckt"]
end

-- S6 d = { shown, candidates, enabled, lpSells, ownSetting, overlapTab }
function E.S6(d)
    local problems = {}
    if d.shown then
        if d.overlapTab then problems[#problems + 1] = string.format(L["verdeckt %s"], d.overlapTab) end
        if (d.candidates or 0) == 0 then problems[#problems + 1] = L["sichtbar ohne Ware"] end
        if d.lpSells and d.ownSetting == nil then problems[#problems + 1] = L["sichtbar, obwohl LevelPilot graue Items verkauft"] end
        if d.ownSetting == false then problems[#problems + 1] = L["sichtbar, obwohl ausgeschaltet"] end
    elseif (d.candidates or 0) > 0 and d.enabled then
        problems[#problems + 1] = L["fehlt (Ware da, Knopf an)"]
    end
    return #problems == 0, #problems == 0 and string.format(L["%s, %d Items, LevelPilot-Verkauf %s"], d.shown and L["sichtbar"] or L["unsichtbar"],
        d.candidates or 0, d.lpSells and L["an"] or L["aus"]) or table.concat(problems, "; "),
        L["verdeckt keinen Reiter, ohne Ware unsichtbar, mit LevelPilot-Verkauf aus"]
end

-- S7 d = { builds = { Zeitpunkte s }, slow = { ms, ... }, crafts }
function E.S7(d)
    local b = d.builds or {}
    table.sort(b)
    local maxIn2 = 0
    for i = 1, #b do
        local n = 0
        for j = i, #b do if b[j] - b[i] < 2 then n = n + 1 else break end end
        if n > maxIn2 then maxIn2 = n end
    end
    local slowest = 0
    for _, ms in ipairs(d.slow or {}) do if ms > slowest then slowest = ms end end
    local ok = maxIn2 <= 1 and #(d.slow or {}) == 0
    return ok, string.format(L["%d hergestellt, %d AUFBAU, höchstens %d je 2 s, LANGSAM %d (max %d ms)"], d.crafts or 0, #b, maxIn2,
        #(d.slow or {}), slowest), L["höchstens 1 AUFBAU je 2 s, kein LANGSAM über 16 ms"]
end

-- S9 d = { open, option, before, visible, combat }  before = vor dem Öffnen des AH sichtbar
-- S10 d = { blizzard, shown, qty }  Blizzards Wert "Einzahlen" (C_AuctionHouse.Calculate...Deposit) gegen AHSentinel
function E.S10(d)
    return d.blizzard == d.shown, string.format(L["Einzahlen %s, AHSentinel %s (Menge %s)"], tostring(d.blizzard), tostring(d.shown), tostring(d.qty)),
        L["gleich"]
end

function E.S9(d)
    if d.combat then return nil end
    local soll
    if d.open then soll = d.before or d.option
    else
        if not d.option then return nil end
        soll = d.before
    end
    return d.visible == (soll and true or false), string.format(L["AH %s, Fenster %s (vorher %s, Option %s)"], d.open and L["auf"] or L["zu"],
        d.visible and L["offen"] or L["zu"], d.before and L["offen"] or L["zu"], d.option and L["an"] or L["aus"]),
        string.format(L["Fenster %s"], soll and L["offen"] or L["zu"])
end

-- S8 d = { blocked = { "Funktion", ... } }
function E.S8(d)
    local n = #(d.blocked or {})
    return n == 0, n == 0 and L["keins"] or (n .. "×: " .. table.concat(d.blocked, ", ")), L["keins"]
end

-- ------------------------------------------------------------
-- Ein- und Ausschalten
-- ------------------------------------------------------------
function P:IsActive()
    if not self.activeUntil then return false end
    if Now() > self.activeUntil then
        self.activeUntil = nil
        A:Print(L["Spieltest beendet (2 Stunden um). Bericht: /ahs spieltest bericht"])
        return false
    end
    return true
end

function P:Start()
    self.activeUntil = Now() + self.DURATION
    self.started = time()
    self.results, self.warned = {}, {}
    self.builds, self.slow, self.crafts, self.craftStart = {}, {}, 0, nil
    self.blocked = {}
    self.s4done, self.s5pending, self.s6pending = nil, nil, nil
    self.saved = nil
    A:Print(L["Spieltest an: AHSentinel prüft die Checkliste, sobald du die Lage herstellst (bis /reload oder 2 Stunden). Gemeldet wird nur, was nicht stimmt."])
    self:Ticker(true)
    return true
end

function P:Stop()
    if not self.activeUntil then return false end
    self.activeUntil = nil
    self:Ticker(false)
    self:Save()
    A:Print(L["Spieltest aus. Bericht: /ahs spieltest bericht"])
    return true
end

-- ------------------------------------------------------------
-- Ergebnis festhalten: einmal je Lage; FEHLER -> eine Chat-Zeile je Prüfung
-- ------------------------------------------------------------
function P:Result(id, ok, ist, soll)
    if ok == nil then return end                    -- Lage nicht verwertbar: bleibt offen
    local prev = self.results[id]
    if prev and prev.status == "FEHLER" then return end     -- ein Fehler bleibt stehen
    if prev and ok then return end                          -- schon OK: einmal je Lage reicht
    -- (ein späterer FEHLER in einer neuen Lage, z. B. beim nächsten Einstellen, ersetzt ein OK)
    local status = ok and "OK" or "FEHLER"
    self.results[id] = { status = status, ist = ist, soll = soll, t = time() }
    self.saved = nil
    if A.Diag then A.Diag:Add("SPIELTEST", string.format("%s %s · ist: %s · soll: %s", id, status, tostring(ist), tostring(soll))) end
    if not ok and not self.warned[id] then
        self.warned[id] = true
        A:Print(string.format(L["|cffff5544Spieltest %s FEHLER:|r %s (ist: %s, soll: %s)"], id, L[self.BY_ID[id].name], tostring(ist), tostring(soll)))
    end
end

-- sichere Auswertung: Fehler im Spieltest selbst nie nach außen
function P:Run(id, fn, ...)
    if not self:IsActive() then return end
    local res = { pcall(fn, ...) }
    if not res[1] then
        self:Result(id, false, "Lua: " .. tostring(res[2]), "kein Fehler")
        return
    end
    self:Result(id, res[2], res[3], res[4])
end

-- ------------------------------------------------------------
-- Haken (werden von den Modulen aufgerufen, nur wenn aktiv)
-- ------------------------------------------------------------
-- S1: Verkaufen-Reiter hat die Zusammenfassung gerechnet
function P:OnSellSummary(d)
    if not self:IsActive() or self.results.S1 then return end
    self:Run("S1", E.S1, d)
end

-- S2: nach dem Einstellen gemessen (Seller.lua RecordDeposit)
function P:OnPostMeasured(p, measured)
    if not self:IsActive() or not (p and p.deposit) then return end
    if p.apiDeposit and not p.apiEstimate then
        self:Run("S10", E.S10, { blizzard = p.apiDeposit, shown = p.deposit, qty = p.qty })
    end
    if measured then self:Run("S2", E.S2, { measured = measured, shown = p.deposit }) end
end

-- S3: Gewinn-Fenster zeigt ein Rezept mit Preis und vollständigem Material
function P:OnCraftDetail(r, depositShown)
    if not self:IsActive() or self.results.S3 then return end
    if not (r and r.value and r.net and r.missing == 0 and r.productID) then return end
    local loss = A:IsForever() and A:ExpectedDepositLoss(r.productID, r.made or 1) or 0
    self:Run("S3", E.S3, { forever = A:IsForever(), value = r.value, made = r.made, stack = A:AuctionSize(r.productID),
        net = r.net, cost = r.cost, profit = r.profit, depositShown = depositShown, depositLoss = loss })
    -- S5 kurz danach (Fenster steht dann)
    self.s5pending = self.s5pending or (Now() + 0.5)
end

-- S4: Tooltip eines entzauberbaren Items
function P:OnDETooltip(itemID, lines)
    if not self:IsActive() or self.results.S4 then return end
    local D = A.Disenchant
    if not (D and itemID) then return end
    local v = D:GetValue(itemID)
    if not v then return end
    local _, key = D:Prior(itemID)
    local nOwn, nShared = D:Combined(key)
    local sum = 0
    for _, r in ipairs(D:EstimateRows(itemID) or {}) do sum = sum + (r.share or 0) end
    local _, _, n = D:ActualValue(itemID)
    local actualShown = false
    local label = L["Entzaubern tatsächlich (Ø aus %d)"]:gsub("%%d.*$", "")
    for _, l in ipairs(lines or {}) do if type(l[1]) == "string" and l[1]:find(label, 1, true) == 1 then actualShown = true end end
    self:Run("S4", E.S4, { estSum = sum, estValue = v, actualShown = actualShown, n = n, nCombined = nOwn + nShared })
end

-- S9: Auktionshaus auf/zu (UI_Main.lua, Ereignis AH_STATE) - geprüft 1 s später (Fenster steht dann)
function P:OnAHState(open, before)
    if not self:IsActive() then return end
    if open then self.s9before = before end
    self.s9pending = { t = Now() + 1, open = open, before = open and before or self.s9before }
end
function P:CheckS9()
    local d = self.s9pending
    self.s9pending = nil
    if not (d and A.UI) then return end
    if not d.open then self.s9before = nil end
    self:Run("S9", E.S9, { open = d.open, before = d.before, option = A.UI.OpenWithAHEnabled and A.UI:OpenWithAHEnabled() or false,
        visible = A.UI:IsVisible(), combat = InCombat() })
end

-- S7: Diagnose-Einträge mitzählen, solange hergestellt wird
function P:OnDiag(kind, ms)
    if not self.activeUntil or not self.craftStart then return end
    if kind == "AUFBAU" then table.insert(self.builds, Now())
    elseif kind == "LANGSAM" and ms and ms > self.SLOW_MS then table.insert(self.slow, ms) end
end

-- ------------------------------------------------------------
-- Lagen, die nur das Spiel herstellt: Berufsfenster (S5), Händler (S6), Herstellen (S7), blockierte Aufrufe (S8)
-- ------------------------------------------------------------
-- S5 prüft NUR das Gewinn-Fenster gegen das Berufsfenster und ProfessionSentinel (Auftrag). Andere Fenster
-- (Hauptfenster im Auktionshaus, LevelPilot, unsichtbare Anker anderer Addons) gehören nicht dazu (Befund 9. Nov. 08:12).
P.S5_BLIZZARD = { "ProfessionsFrame", "TradeSkillFrame", "CraftFrame" }
P.S5_ADDONS = { ProfessionSentinel = true }
function P:S5Data(panel)
    local U = A.UIC and A.UIC.UICheck
    if not (U and panel) then return nil end
    local mine = U.Rect(panel)
    if not mine then return nil end
    local function visible(f) return f and f.IsVisible and f:IsVisible() end
    local problems, tested = {}, 0
    for _, bn in ipairs(self.S5_BLIZZARD) do
        local bf = _G[bn]
        if visible(bf) then
            tested = tested + 1
            if U.Overlap(mine, U.Rect(bf, true)) > 0 then problems[#problems + 1] = string.format(L["Gewinn-Fenster überdeckt %s"], bn) end
        end
    end
    for _, o in ipairs(_G.GoldSentinelUIFrames or {}) do
        if self.S5_ADDONS[o.addon] and visible(o.frame) then
            tested = tested + 1
            if U.Overlap(mine, U.Rect(o.frame)) > 0 then
                problems[#problems + 1] = string.format(L["Gewinn-Fenster überdeckt %s (%s)"], tostring(o.name), o.addon)
            end
        end
    end
    return { problems = problems, tested = tested }
end

function P:CheckS5()
    local panel = A.Crafting and A.Crafting.panel
    if not (panel and panel.IsVisible and panel:IsVisible()) then return end
    local d = self:S5Data(panel)
    if d then self:Run("S5", E.S5, d) end
end

function P:CheckS6()
    local UI, X = A.UI, A.Extras
    if not (UI and X and UI.VendorButtonEnabled) then return end
    local b = UI.vendorButton
    local shown = b and b.IsShown and b:IsShown() or false
    local list = X:VendorCandidates()
    local st = A.db and A.db.settings
    self:Run("S6", E.S6, { shown = shown, candidates = #list, enabled = UI:VendorButtonEnabled(), lpSells = UI:LevelPilotSellsGrey(),
        ownSetting = st and st.vendorButton, overlapTab = shown and UI:VendorButtonOverlap(b) or nil })
end

function P:FinishS7()
    self:Run("S7", E.S7, { builds = self.builds, slow = self.slow, crafts = self.crafts })
    self.craftStart = nil
end

-- regelmäßig (1×/s, nur solange aktiv): verzögerte Prüfungen, nie im Kampf
function P:Tick()
    if not self:IsActive() then self:Ticker(false); return end
    if InCombat() then return end
    local t = Now()
    if self.s5pending and t >= self.s5pending then self.s5pending = nil; if not self.results.S5 then self:CheckS5() end end
    if self.s6pending and t >= self.s6pending then self.s6pending = nil; if not self.results.S6 then self:CheckS6() end end
    if self.s9pending and t >= self.s9pending.t then self:CheckS9() end
    -- S7: 5 Gegenstände hergestellt und 2 s Ruhe -> auswerten
    if self.craftStart and self.crafts >= self.CRAFTS and t - (self.lastCraft or 0) >= 2 then self:FinishS7() end
end

local ticker = CreateFrame("Frame")
ticker:Hide()
local acc = 0
ticker:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    if acc < 1 then return end
    acc = 0
    pcall(P.Tick, P)
end)
function P:Ticker(on) if on then ticker:Show() else ticker:Hide() end end

local evt = CreateFrame("Frame")
for _, e in ipairs({ "MERCHANT_SHOW", "ADDON_ACTION_BLOCKED", "ADDON_ACTION_FORBIDDEN", "UNIT_SPELLCAST_SUCCEEDED",
                     "TRADE_SKILL_SHOW", "PLAYER_LOGOUT" }) do
    pcall(evt.RegisterEvent, evt, e)
end
-- Ist spellID ein Rezept des offenen Berufs? Modern: Rezept-ID = Zauber-ID; alte Clients: Zaubername = Rezeptname.
function P:IsCraftSpell(spellID)
    if not spellID then return false end
    local ts = A:Global("C_TradeSkillUI")
    if ts and ts.GetRecipeInfo then
        local ok, info = pcall(ts.GetRecipeInfo, spellID)
        -- SK1-m (Befund 19:08 Punkt 8 "Herstellen ohne Rezept: Zauber 836", 16:46/18:46/18:50): 836 ist kein Rezept (im Classic-Client
        -- der Anmelde-Effekt "LOGINEFFECT" beim Einloggen/Neuladen - Verdacht, im Spiel über SK1-m mit Namen zu bestätigen). Der Client
        -- liefert für solche Zauber offenbar trotzdem eine Tabelle; als Herstellen zählt nur eine Tabelle, die wirklich dieses Rezept
        -- beschreibt (recipeID = dieser Zauber).
        if not (ok and type(info) == "table" and info.recipeID == spellID) then return false end
        -- SK1-M3 (Ingametest 18.11. 14:40: "Zauber 3100 (Schmiedekunst)" um 13:49 = Rang-Zauber des Berufs, öffnet das Berufsfenster):
        -- Herstellen nur, wenn der Zauber ein Rezept der Liste des Berufsfensters ist (GetAllRecipeIDs). Liste zuletzt offen bis 60 s
        -- gemerkt (laufende Serie nach dem Schliessen). Ohne GetAllRecipeIDs (alter Weg) wie bisher.
        if ts.GetAllRecipeIDs then
            local okL, list = pcall(ts.GetAllRecipeIDs)
            local now = GetTime()
            if okL and type(list) == "table" and #list > 0 then
                self.recipeList, self.recipeListT = list, now
            elseif not (self.recipeListT and now - self.recipeListT < 60) then
                self.recipeList = nil
            end
            local L2 = self.recipeList
            if not L2 then return false end
            for _, rid in ipairs(L2) do if rid == spellID then return true end end
            return false
        end
        return true
    end
    local gsi, num, info = A:Global("GetSpellInfo"), A:Global("GetNumTradeSkills"), A:Global("GetTradeSkillInfo")
    if not (gsi and num and info) then return false end
    local name = gsi(spellID)
    if not name then return false end
    for i = 1, num() or 0 do
        local n, kind = info(i)
        if n == name and kind ~= "header" then return true end
    end
    return false
end

evt:SetScript("OnEvent", function(_, event, a1, a2, a3)
    if event == "PLAYER_LOGOUT" then
        if P.activeUntil then pcall(P.Save, P) end
        return
    end
    if not P:IsActive() then return end
    if event == "MERCHANT_SHOW" then
        P.s6pending = Now() + 0.5
    elseif event == "TRADE_SKILL_SHOW" then
        P.s5pending = Now() + 0.5
    elseif event == "ADDON_ACTION_BLOCKED" or event == "ADDON_ACTION_FORBIDDEN" then
        local G = _G.GoldSentinelGame
        if G and G.IsSecret and (G.IsSecret(a1) or G.IsSecret(a2)) then return end
        local who = tostring(a1 or "")
        if who:find("AHSentinel", 1, true) or who:find("AHAnalyzerPro", 1, true) then
            table.insert(P.blocked, event:gsub("^ADDON_ACTION_", "") .. " " .. tostring(a2 or "?"))
            P:Result("S8", E.S8({ blocked = P.blocked }))
        end
    elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
        -- geschützte Werte (WoW Forever) nie vergleichen
        local G = _G.GoldSentinelGame
        if G and G.AnySecret and G.AnySecret(a1, a3) then return end
        if a1 ~= "player" then return end
        -- Herstellen: nur Zauber, die ein Rezept des offenen Berufs sind (offener Punkt 6)
        local panel = A.Crafting and A.Crafting.panel
        if not (panel and panel.IsVisible and panel:IsVisible()) or P.results.S7 then return end
        if not P:IsCraftSpell(a3) then return end
        if not P.craftStart then P.craftStart, P.crafts, P.builds, P.slow = Now(), 0, {}, {} end
        P.crafts = P.crafts + 1
        P.lastCraft = Now()
    end
end)

-- ------------------------------------------------------------
-- Bericht: Chat-Liste und Testbericht (GSTEST1, Bereich S)
-- ------------------------------------------------------------
function P:Lines()
    local out, counts = {}, { ok = 0, fehler = 0, offen = 0 }
    for _, c in ipairs(self.CHECKS) do
        local r = self.results[c.id]
        if r then
            if r.status == "OK" then counts.ok = counts.ok + 1 else counts.fehler = counts.fehler + 1 end
            out[#out + 1] = { id = c.id, status = r.status, name = c.name, ist = r.ist, soll = r.soll }
        else
            counts.offen = counts.offen + 1
            out[#out + 1] = { id = c.id, status = "offen", name = c.name, need = c.need }
        end
    end
    return out, counts
end

-- S8 zählt erst beim Bericht als OK (bis dahin könnte noch etwas kommen)
function P:CloseS8()
    if self.started and not self.results.S8 and time() - self.started >= 60 then
        self:Result("S8", E.S8({ blocked = self.blocked or {} }))
    end
end

function P:Save()
    if self.saved or not self.started then return end
    local GT = _G.GoldSentinelTest
    if not (GT and GT.Begin and A.db) then return end
    local run = GT.Begin("AHSentinel", A.version, A.db)
    for _, l in ipairs(self:Lines()) do
        if l.status == "OK" then run:Add("OK", l.id, "S", l.name, { ergebnis = l.ist })
        elseif l.status == "FEHLER" then run:Add("FEHLER", l.id, "S", l.name, { ergebnis = l.ist, erwartet = l.soll })
        else run:Client(l.id, "S", l.name, l.need) end
    end
    pcall(run.Finish, run, { spieltest = true })
    self.saved = true
end

function P:Report()
    self:CloseS8()
    local lines, c = self:Lines()
    A:Print(string.format(L["|cffffd100Spieltest|r: OK %d · FEHLER %d · offen %d"], c.ok, c.fehler, c.offen))
    for _, l in ipairs(lines) do
        if l.status == "OK" then
            print(string.format("   |cff33dd55OK|r %s %s", l.id, L[l.name]))
        elseif l.status == "FEHLER" then
            print(string.format("   |cffff5544FEHLER|r %s %s (ist: %s, soll: %s)", l.id, L[l.name], tostring(l.ist), tostring(l.soll)))
        else
            print(string.format("   |cff999999%s|r %s %s - %s", L["offen"], l.id, L[l.name], string.format(L["noch: %s"], L[l.need])))
        end
    end
    self:Save()
    return lines, c
end

-- /ahs spieltest [an|aus|bericht]
function P:Command(arg)
    arg = (arg or ""):lower()
    if arg == "an" or arg == "on" or arg == "start" then return self:Start()
    elseif arg == "aus" or arg == "off" or arg == "stop" then return self:Stop()
    elseif arg == "bericht" or arg == "report" then return self:Report()
    end
    if self:IsActive() then return self:Report() end
    A:Print(L["Spieltest: /ahs spieltest an | aus | bericht"])
end
