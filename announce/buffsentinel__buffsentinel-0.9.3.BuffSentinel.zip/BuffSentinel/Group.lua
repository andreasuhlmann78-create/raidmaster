-- BuffSentinel - Group.lua
-- Gruppen-/Raid-Buffs: wer hat welchen Buff nicht? + klickbares Buff-Raster (jedes Feld = Buff-Button)

local ADDON, BS = ...

-- Klassen ohne Mana (für Intelligenz-/Willenskraft-Buffs); Jäger nutzen ab Cataclysm Fokus
local NO_MANA = { WARRIOR = true, ROGUE = true, DEATHKNIGHT = true, DEMONHUNTER = true }
if (BS.expansion or 1) >= 4 then NO_MANA.HUNTER = true end
local CELL, NAMEW, ROWH = 24, 120, 26

------------------------------------------------------------------------
-- Gruppenmitglieder
------------------------------------------------------------------------
function BS:GetGroupUnits()
    local units = {}
    local inRaid = (IsInRaid and IsInRaid()) or (GetNumRaidMembers and GetNumRaidMembers() > 0) or false
    if inRaid then
        local n = (GetNumGroupMembers and GetNumGroupMembers()) or GetNumRaidMembers()
        for i = 1, n do tinsert(units, "raid" .. i) end
    else
        tinsert(units, "player")
        local n = (GetNumSubgroupMembers and GetNumSubgroupMembers())
               or (GetNumPartyMembers and GetNumPartyMembers()) or 0
        for i = 1, n do tinsert(units, "party" .. i) end
    end
    return units, inRaid
end

function BS:GroupEntries()
    local list = {}
    for _, e in ipairs(self.entries) do
        if e.kind == "buff" and e.data.group and e.known then tinsert(list, e) end
    end
    return list
end

------------------------------------------------------------------------
-- Alle 0,5 s: fehlende Buffs pro Eintrag ermitteln
------------------------------------------------------------------------
function BS:RefreshGroup()
    if not self.ready then return end
    if self:CombatLocked() then return end   -- Forever/Retail: Auren im Kampf geheim
    local units, inRaid = self:GetGroupUnits()
    self.groupUnits = units
    self.unitAuras = self.unitAuras or {}
    self.unitInfo = {}

    local entries = self:GroupEntries()
    if #entries == 0 then
        wipe(self.groupMissing)
        if self.raster and self.raster:IsShown() then self:UpdateRaster() end
        return
    end

    for i, u in ipairs(units) do
        local exists = UnitExists(u)
        local ok = exists and not UnitIsDeadOrGhost(u) and UnitIsConnected(u)
        local t = self.unitAuras[u] or {}
        self.unitAuras[u] = t
        if ok then BS.ScanAuras(u, t) else wipe(t) end
        local sub = 1
        if inRaid and GetRaidRosterInfo then
            local _, _, sg = GetRaidRosterInfo(i)
            sub = sg or 1
        end
        local class = exists and select(2, UnitClass(u)) or nil
        -- geheimer Name: nicht speichern/verketten (GoldSentinelGame.Short liefert dann nil)
        local uname = exists and UnitName(u) or nil
        if GoldSentinelGame then uname = GoldSentinelGame.Short(uname) elseif BS.IsSecret(uname) then uname = nil end
        uname = uname or "?"
        if BS.IsSecret(class) then class = nil end
        self.unitInfo[u] = { ok = ok, exists = exists, sub = sub, name = uname, class = class }
    end

    for _, e in ipairs(entries) do
        local miss = self.groupMissing[e.key] or {}
        wipe(miss)
        self.groupMissing[e.key] = miss
        local subCount = {}
        for _, u in ipairs(units) do
            local info = self.unitInfo[u]
            local relevant = info.ok and not (e.data.manaOnly and NO_MANA[info.class or ""])
            if relevant and not BS.HasAny(self.unitAuras[u], e.auraNames) then
                local inRange = BS.InRange(e.spellName, u)
                if inRange == nil then inRange = UnitIsVisible(u) and true or false end
                tinsert(miss, { unit = u, name = info.name, inRange = inRange, sub = info.sub })
                subCount[info.sub] = (subCount[info.sub] or 0) + 1
            end
        end
        for _, m in ipairs(miss) do m.groupCount = subCount[m.sub] end
        table.sort(miss, function(a, b)
            if a.inRange ~= b.inRange then return a.inRange end
            return a.unit < b.unit
        end)
    end

    if self.raster and self.raster:IsShown() then self:UpdateRaster() end
end

------------------------------------------------------------------------
-- Buff-Raster (Fenster): Zeilen = Spieler, Spalten = Buffs, jedes Feld ist ein Buff-Button
------------------------------------------------------------------------
local function CreateRaster()
    local f = CreateFrame("Frame", "BuffSentinelRaster", UIParent)
    f:SetSize(260, 120)
    f:SetFrameStrata("MEDIUM")
    BS:RegisterWindow(f, "raster", { "LEFT", "LEFT", 40, 60 }, true)

    local bg = f:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.07, 0.08, 0.10, 0.92)
    local bar = f:CreateTexture(nil, "BORDER")
    bar:SetPoint("TOPLEFT"); bar:SetPoint("TOPRIGHT"); bar:SetHeight(26)
    bar:SetColorTexture(0.13, 0.14, 0.18, 1)

    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.title:SetPoint("TOPLEFT", 10, -7)
    f.title:SetText("Gruppen-Buffs")

    local close = CreateFrame("Button", nil, f)
    close:SetSize(22, 22)
    close:SetPoint("TOPRIGHT", -3, -2)
    close.text = close:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    close.text:SetPoint("CENTER")
    close.text:SetText("×")
    close:SetScript("OnClick", function() BS:ToggleRaster() end)

    f.hint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.hint:SetPoint("BOTTOMLEFT", 10, 6)
    f.hint:SetText("Klick auf ein rotes Feld = buffen")
    f.hint:SetTextColor(0.6, 0.6, 0.65)

    f.cells, f.names, f.heads = {}, {}, {}
    f:Hide()
    return f
end

local function GetCell(f, i)
    local c = f.cells[i]
    if c then return c end
    c = CreateFrame("Button", "BuffSentinelRasterCell" .. i, f, "SecureActionButtonTemplate")
    c:SetSize(CELL - 2, CELL - 2)
    local useDown = GetCVar and GetCVar("ActionButtonUseKeyDown") ~= nil
    if useDown then c:RegisterForClicks("AnyUp", "AnyDown") else c:RegisterForClicks("AnyUp") end
    c.icon = c:CreateTexture(nil, "ARTWORK")
    c.icon:SetAllPoints()
    c.icon:SetTexCoord(0.1, 0.9, 0.1, 0.9)
    c.tint = c:CreateTexture(nil, "OVERLAY")
    c.tint:SetAllPoints()
    local hl = c:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.25)
    c:SetScript("OnEnter", function(self)
        if not self.unit then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine((UnitName(self.unit) or "?") .. " – " .. (self.spell or "?"), 1, 0.82, 0)
        GameTooltip:AddLine(self.state or "", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    c:SetScript("OnLeave", function() GameTooltip:Hide() end)
    f.cells[i] = c
    return c
end

local function GetName(f, i)
    local fs = f.names[i]
    if not fs then
        fs = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        fs:SetWidth(NAMEW - 6)
        fs:SetJustifyH("LEFT")
        f.names[i] = fs
    end
    return fs
end

local function GetHead(f, i)
    local t = f.heads[i]
    if not t then
        t = f:CreateTexture(nil, "ARTWORK")
        t:SetSize(CELL - 4, CELL - 4)
        t:SetTexCoord(0.1, 0.9, 0.1, 0.9)
        f.heads[i] = t
    end
    return t
end

function BS:ToggleRaster()
    if InCombatLockdown() then BS.Print("Im Kampf nicht möglich.") return end
    if not self.raster then self.raster = CreateRaster() end
    if self.raster:IsShown() then
        self.raster:Hide()
    else
        if #self:GroupEntries() == 0 then
            BS.Print("Deine Klasse/Skillung hat keine Gruppen-Buffs.")
            return
        end
        self.raster:Show()
        self:RefreshGroup()
        self:UpdateRaster(true)
    end
end

-- rebuild = true: Zellen neu zuordnen (nur ausserhalb des Kampfes)
function BS:UpdateRaster(rebuild)
    local f = self.raster
    if not f or not f:IsShown() then return end
    local units = self.groupUnits or self:GetGroupUnits()
    local entries = self:GroupEntries()

    local sig = table.concat(units, ",") .. "|" .. #entries
    if sig ~= f.sig then rebuild = true end

    if rebuild and not InCombatLockdown() then
        f.sig = sig
        for _, c in ipairs(f.cells) do c:Hide(); c.unit = nil end
        for _, n in ipairs(f.names) do n:Hide() end
        for _, h in ipairs(f.heads) do h:Hide() end

        for j, e in ipairs(entries) do
            local h = GetHead(f, j)
            h:SetTexture(e.icon)
            h:ClearAllPoints()
            h:SetPoint("TOPLEFT", f, "TOPLEFT", NAMEW + (j - 1) * CELL + 2, -32)
            h:Show()
        end

        local idx = 0
        for i, u in ipairs(units) do
            local fs = GetName(f, i)
            fs:ClearAllPoints()
            fs:SetPoint("LEFT", f, "TOPLEFT", 10, -32 - i * ROWH - (CELL - 2) / 2)
            fs:Show()
            for j, e in ipairs(entries) do
                idx = idx + 1
                local c = GetCell(f, idx)
                c:ClearAllPoints()
                c:SetPoint("TOPLEFT", f, "TOPLEFT", NAMEW + (j - 1) * CELL + 1, -32 - i * ROWH)
                c.unit, c.entry, c.spell = u, e, e.spellName
                c.icon:SetTexture(e.icon)
                c:SetAttribute("type", "spell")
                c:SetAttribute("spell", e.spellName)
                c:SetAttribute("unit", u)
                c:Show()
            end
        end
        f:SetSize(math.max(240, NAMEW + #entries * CELL + 16), 32 + (#units + 1) * ROWH + 18)
    end

    -- Farben aktualisieren (auch im Kampf erlaubt)
    for i, u in ipairs(units) do
        local info = self.unitInfo and self.unitInfo[u]
        local fs = f.names[i]
        if fs and info then
            local color = info.class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[info.class]
            fs:SetText(info.name or "?")
            if color then fs:SetTextColor(color.r, color.g, color.b) else fs:SetTextColor(1, 1, 1) end
            if not info.ok then fs:SetTextColor(0.5, 0.5, 0.5) end
        end
    end
    for _, c in ipairs(f.cells) do
        if c:IsShown() and c.unit and c.entry then
            local info = self.unitInfo and self.unitInfo[c.unit]
            local e = c.entry
            local has = BS.HasAny(self.unitAuras and self.unitAuras[c.unit], e.auraNames)
            local skip = info and e.data.manaOnly and NO_MANA[info.class or ""]
            if not info or not info.ok then
                c.tint:SetColorTexture(0, 0, 0, 0.75); c.state = "tot / offline"
            elseif skip then
                c.tint:SetColorTexture(0, 0, 0, 0.6); c.state = "braucht diesen Buff nicht"
            elseif has then
                c.tint:SetColorTexture(0.1, 0.8, 0.2, 0.30); c.state = "hat den Buff"
            else
                local inRange = BS.InRange(e.spellName, c.unit)
                if inRange == false then
                    c.tint:SetColorTexture(0.4, 0.4, 0.4, 0.6); c.state = "fehlt – ausser Reichweite"
                else
                    c.tint:SetColorTexture(0.95, 0.1, 0.1, 0.45); c.state = "fehlt – Klick zum Buffen"
                end
            end
        end
    end
end
