local ADDON, ns = ...

-- Ranks of profession trainers (Befund 21.11. 20:45: "Snarl" was shown as expert trainer – in the game he offers only
-- journeyman). The rank of a trainer is NEVER taken from the title (in WoW Forever the titles do not match). Sources, best first:
--   1. measured in the game: the ranks the trainer window offered (ns.db.trainerSeen[npcID], when opened),
--   2. the reference pages per profession (Data_TrainerRef.lua, goldgoblin "<beruf>-forever"),
--   3. otherwise "rank unknown" (0) – never guessed.
-- A trainer that teaches several ranks is listed under each of them. Only WoW Forever (other versions: no reference yet,
-- their data stay as they are – see the report 0.9.75).
local TR = {}
ns.TrainerRanks = TR

TR.WORDS = {
    { 4, { "fachmann", "artisan" } },
    { 3, { "experte", "expert" } },
    { 2, { "geselle", "journeyman" } },
    { 1, { "lehrling", "apprentice" } },
}

-- the rank of a trainer service by its name and sub text (nil: not a profession rank)
function TR.RankOfService(name, sub)
    local t = ((name or "") .. " " .. (sub or "")):lower()
    for _, w in ipairs(TR.WORDS) do
        for _, word in ipairs(w[2]) do
            if t:find(word, 1, true) then return w[1] end
        end
    end
    return nil
end

-- ranks of a trainer: list of keys (sorted) and the source ("gemessen" | "referenz" | nil = unknown)
function TR.RanksOf(prof, id)
    local seen = ns.db and ns.db.trainerSeen and ns.db.trainerSeen[id]
    if seen and seen.r and next(seen.r) then
        local l = {}
        for k in pairs(seen.r) do l[#l + 1] = k end
        table.sort(l)
        return l, "gemessen"
    end
    local ref = ns.TrainerRef and ns.TrainerRef[prof]
    local n = ns.NPCs and ns.NPCs[id]
    local mm = ref and n and ref[n[1]]
    if mm then
        local l = {}
        for k = mm[1], mm[2] do l[#l + 1] = k end
        return l, "referenz"
    end
    return nil
end

-- ns.Trainers rebuilt from the raw list: {id, rank} per rank taught, {id, 0} when unknown
function TR.Rebuild()
    if not ns.TrainerRef or not ns.Trainers then return false end
    TR.raw = TR.raw or ns.Trainers
    local out = {}
    for prof, list in pairs(TR.raw) do
        local l, seenId = {}, {}
        for _, e in ipairs(list) do
            local id = e[1]
            if not seenId[id] then
                seenId[id] = true
                local ranks = TR.RanksOf(prof, id)
                if ranks then
                    for _, k in ipairs(ranks) do l[#l + 1] = { id, k } end
                else
                    l[#l + 1] = { id, 0 }
                end
            end
        end
        out[prof] = l
    end
    ns.Trainers = out
    return true
end

-- the trainer window: note which profession ranks this trainer offers (also "already known" ones)
function TR.OnTrainerShow()
    if not (ns.db and TR.raw) then return end
    local A = ns.API
    if not (A.UnitGUID and A.GetNumTrainerServices and A.GetTrainerServiceInfo) then return end
    local guid = A.UnitGUID("npc")
    local id = guid and tonumber(guid:match("^%a+%-%d+%-%d+%-%d+%-%d+%-(%d+)%-"))
    if not id then return end
    local known = false
    for _, list in pairs(TR.raw) do
        for _, e in ipairs(list) do if e[1] == id then known = true end end
    end
    if not known then return end
    local found = {}
    for i = 1, (A.GetNumTrainerServices() or 0) do
        local name, sub = A.GetTrainerServiceInfo(i)
        local k = TR.RankOfService(name, sub)
        if k then found[k] = true end
    end
    if not next(found) then return end
    ns.db.trainerSeen = ns.db.trainerSeen or {}
    local e = ns.db.trainerSeen[id] or { r = {} }
    -- several visits: what one visit showed stays (a filter of the window may hide a rank)
    for k in pairs(found) do e.r[k] = true end
    e.t = time and time() or 0
    ns.db.trainerSeen[id] = e
    TR.Rebuild()
    if ns.Diag then ns.Diag("LEHRER", "gemessen " .. id) end
end

---------------------------------------------------------------------------
-- PS-SK1 (Supervisor 27.11. 13:10/13:12, note of the user 13:06): in the WoW Forever client data many trainer recipes have no
-- learn level (req 1) -> the plan showed "Skill ?". The learn level is read where it is certain: the trainer window gives it for
-- every recipe it offers (GetTrainerServiceSkillReq: skill name, rank, hasReq). Kept account-wide per recipe spell in
-- ns.db.trainerReq[spell] = rank (any trainer of any profession, every visit; also TRAINER_UPDATE when the filter changes).
-- The recipe is found by its name in the language of the client (both names of the data), within the trainer's profession;
-- a name that fits several recipes is left out (never guessed). The estimate of the data (learnLevel) is never shown.
---------------------------------------------------------------------------
local nameIndex
local function NameIndex()
    if nameIndex then return nameIndex end
    nameIndex = {}
    for _, r in ipairs(ns.Recipes or {}) do
        for _, n in ipairs({ r.name, r.nameEN }) do
            if type(n) == "string" and n ~= "" then
                local k = n:lower()
                local l = nameIndex[k]
                if not l then l = {}; nameIndex[k] = l end
                if l[#l] ~= r then l[#l + 1] = r end
            end
        end
    end
    return nameIndex
end
function TR.ForgetNames() nameIndex = nil end      -- test routine

-- the recipe of a trainer service: by name, within the profession of its skill requirement (when the name of the skill fits one)
function TR.RecipeOfService(name, skillName)
    if type(name) ~= "string" then return nil end
    local list = NameIndex()[name:lower()]
    if not list then return nil end
    local prof
    if type(skillName) == "string" and ns.ProfName then
        for _, r in ipairs(list) do
            if ns.ProfName(r.prof) == skillName then prof = r.prof end
        end
    end
    local found
    for _, r in ipairs(list) do
        if prof == nil or r.prof == prof then
            if found and found ~= r then return nil end      -- the name fits several recipes: left out
            found = r
        end
    end
    return found
end

-- read the learn levels the trainer window shows; returns the number of recipes noted, how many were new, how many changed.
-- PS-SK2 (Supervisor 27.11. 21:12): also which recipes a trainer of a profession OFFERED (ns.db.trainerOffered[spell] = true)
-- and that a trainer of this profession was read (ns.db.trainerProfRead[prof] = time; .full when the window also showed
-- "unavailable" ones = recipes still too high, so the list is complete for what this trainer teaches) – for the reason
-- shown at a recipe without a learn level ("not offered by the trainer you visited").
function TR.ReadLearnLevels()
    local A = ns.API
    if not (ns.db and A.GetNumTrainerServices and A.GetTrainerServiceInfo and A.GetTrainerServiceSkillReq) then return 0, 0, 0 end
    local n, new, changed = 0, 0, 0
    local profs, full = {}, false
    for i = 1, (A.GetNumTrainerServices() or 0) do
        local name, _, category = A.GetTrainerServiceInfo(i)
        if category == "unavailable" then full = true end
        local skillName, rank = A.GetTrainerServiceSkillReq(i)
        rank = tonumber(rank)
        local r = name and TR.RecipeOfService(name, skillName)
        if r then
            ns.db.trainerOffered = ns.db.trainerOffered or {}
            ns.db.trainerOffered[r.spell] = true
            profs[r.prof] = true
            if rank and rank > 0 then
                ns.db.trainerReq = ns.db.trainerReq or {}
                local old = ns.db.trainerReq[r.spell]
                if old == nil then new = new + 1 elseif old ~= rank then changed = changed + 1 end
                ns.db.trainerReq[r.spell] = rank
                n = n + 1
            end
        end
    end
    if next(profs) then
        ns.db.trainerProfRead = ns.db.trainerProfRead or {}
        for prof in pairs(profs) do
            local e = ns.db.trainerProfRead[prof] or {}
            e.t = time and time() or 0
            if full then e.full = true end
            ns.db.trainerProfRead[prof] = e
        end
    end
    if n > 0 and ns.Diag then
        -- Supervisor 21:10: how many were new and how many recipes of the plan still have no learn level (count, without a picture)
        local open = TR.PlanWithoutLevel and TR.PlanWithoutLevel() or nil
        ns.Diag("LEHRER", string.format("Lernstufen gelesen %d (neu %d, geändert %d)%s", n, new, changed,
            open and string.format("; im Plan ohne Lernstufe %d", open) or ""))
    end
    return n, new, changed
end

-- the recipes to learn in the current skill plan (Plan.lua PL.current) without a learn level; nil when no plan was built
function TR.PlanWithoutLevel()
    local plan = ns.Plan and ns.Plan.current
    if not (plan and plan.steps) then return nil end
    local seen, n = {}, 0
    for _, st in ipairs(plan.steps) do
        local r = st.recipe
        if r and not st.learned and not seen[r] then
            seen[r] = true
            if not ns.LearnReq(r) then n = n + 1 end
        end
    end
    return n
end

-- PS-SK2 (b): why a recipe has no learn level – nil (has one), "unread" (no trainer of this profession read yet) or "notOffered"
-- (a trainer of this profession was read with the full list and did not offer it: another / higher trainer teaches it)
function TR.NoLevelReason(r)
    if not r or ns.LearnReq(r) then return nil end
    local pr = ns.db and ns.db.trainerProfRead and ns.db.trainerProfRead[r.prof]
    if not pr then return "unread" end
    local offered = ns.db.trainerOffered and ns.db.trainerOffered[r.spell]
    if pr.full and not offered then return "notOffered" end
    return "unread"
end

-- the learn level of a recipe from certain sources: the data (req > 1), else read at a trainer; nil = unknown
function ns.LearnReq(r)
    if not r then return nil end
    if (r.req or 0) > 1 then return r.req end
    local t = ns.db and ns.db.trainerReq and ns.db.trainerReq[r.spell]
    return (type(t) == "number" and t > 0) and t or nil
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("TRAINER_SHOW")
f:RegisterEvent("TRAINER_UPDATE")
f:SetScript("OnEvent", function(_, ev)
    if ev == "PLAYER_LOGIN" then TR.Rebuild(); return end
    if ev == "TRAINER_SHOW" then TR.OnTrainerShow() end
    local ok, err = pcall(TR.ReadLearnLevels)
    if not ok and ns.CountError then ns.CountError("TrainerRanks.ReadLearnLevels", err) end
end)
