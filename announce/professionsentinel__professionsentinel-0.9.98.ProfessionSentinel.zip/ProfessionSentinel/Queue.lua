local _, ns = ...
local L = ns.L

-- Queue and ONE shopping list (UI rework 2, step 3, question F5 "what do I need for it?"; model Skillet / CraftSim).
-- Recipes are put into a queue with a count; the queue stays after logging out (ProfessionSentinelDB.queue).
-- The shopping list adds up the materials of all queued recipes (made-cheaper intermediates broken down like the plan,
-- P.ExpandNeed) against what is in the bags and the bank. Buying only happens on a click of the player:
--   vendor: buys exactly what is missing at the open vendor (Plan.BuyFromVendor, through ns.Act);
--   AH: AHSentinel's sniper with a "buy up to" price per material (order B3): the highest unit price at which the queued
--       recipe still earns the minimum profit – the sniper never buys above the profit threshold, and never above 1.25 × the
--       market price (PS52-1: the sale price is an estimate). Without a profit (skill recipes) the market price + 10 %.
-- A craft of a queued recipe (UNIT_SPELLCAST_SUCCEEDED) counts the queue down.

local Q = {}
ns.Queue = Q

Q.MAX_ENTRIES = 30
Q.FALLBACK_MARKUP = 1.10      -- no profit known: market price + 10 % (as "craft today" and the plan)
Q.SNIPER_CAP = 1.25           -- PS52-1: the sniper never gets more than 1.25 × the market price (the sale price is an estimate)

local function DB()
    if not ns.db then return {} end
    if type(ns.db.queue) ~= "table" then ns.db.queue = {} end
    return ns.db.queue
end

-- the entries with their recipe (entries of an unknown recipe are skipped, never an error)
function Q.Entries()
    local out = {}
    for i, e in ipairs(DB()) do
        local r = type(e) == "table" and ns.BySpell[e.spell]
        if r and (tonumber(e.count) or 0) > 0 then out[#out + 1] = { index = i, recipe = r, count = math.floor(e.count) } end
    end
    return out
end

function Q.Count()
    local n = 0
    for _, e in ipairs(Q.Entries()) do n = n + e.count end
    return n, #Q.Entries()
end

local function Changed()
    if ns.UI and ns.UI.UpdateQueueBar then ns.UI.UpdateQueueBar() end
    if ns.UI and ns.UI.PanelVisible and ns.UI.PanelVisible() and ns.UI.RequestRefresh then ns.UI.RequestRefresh("Warteschlange") end
end
Q.Changed = Changed

-- put a recipe into the queue (the same recipe again: the count goes up)
function Q.Add(r, n)
    if not (r and r.spell) then return false end
    n = math.max(1, math.floor(tonumber(n) or 1))
    local db = DB()
    for _, e in ipairs(db) do
        if type(e) == "table" and e.spell == r.spell then
            e.count = (tonumber(e.count) or 0) + n
            Changed()
            if ns.PLHit then ns.PLHit("VORMERKEN", "+" .. n .. "×") end
            return true
        end
    end
    if #db >= Q.MAX_ENTRIES then ns.Print(L.Q_FULL); return false end
    db[#db + 1] = { spell = r.spell, count = n }
    ns.Print(string.format(L.Q_ADDED, n, ns.RecipeName(r)))
    Changed()
    if ns.PLHit then ns.PLHit("VORMERKEN", n .. "×") end
    return true
end

function Q.Remove(spell, n)
    local db = DB()
    for i, e in ipairs(db) do
        if type(e) == "table" and e.spell == spell then
            if n then e.count = (tonumber(e.count) or 0) - n end
            if not n or e.count <= 0 then table.remove(db, i) end
            Changed()
            return true
        end
    end
    return false
end

function Q.Clear()
    if ns.db then ns.db.queue = {} end
    Changed()
end

-- an own craft: one less of this recipe in the queue
function Q.OnCraft(r)
    if not (r and r.spell) then return end
    for _, e in ipairs(DB()) do
        if type(e) == "table" and e.spell == r.spell then
            Q.Remove(r.spell, 1)
            return
        end
    end
end

-- what we have: bags and bank (the bank only counts where the client knows it)
function Q.Have(id)
    local n = ns.GetItemCount(id, true)
    if not n or n == 0 then n = ns.GetItemCount(id, false) end
    return n or 0
end

-- "buy up to" for the materials of one recipe (B3): factor on the unit price so that the recipe still earns the minimum
-- profit. nil when the recipe has no secured profit (then the fallback markup applies).
function Q.LimitFactor(r)
    local P, PS = ns.Prices, ns.PriceSource
    if not (P and P.SourceName and P.SourceName()) then return nil end
    local pr = P.Recipe(r, true)
    if not (pr and pr.known and pr.cost and pr.cost > 0 and pr.net and not pr.flag) then return nil end
    local pct = PS and PS.MinProfitPct and PS.MinProfitPct() or 20
    -- with factor f on every material: net' = net - (f - 1) * cost; net' must stay >= cost * f * pct / 100
    -- => f <= (net + cost) / (cost * (1 + pct / 100))
    local f = (pr.net + pr.cost) / (pr.cost * (1 + pct / 100))
    if f < 1 then return nil end      -- does not even earn the minimum at market prices: no "buy up to" above the market
    return f
end

-- the ONE shopping list: { id, need, have, missing, origin, unit, maxPrice } sorted by origin (vendor first) and name
function Q.ShoppingList()
    local P = ns.Prices
    local need, limit = {}, {}
    for _, e in ipairs(Q.Entries()) do
        local r = e.recipe
        local f = Q.LimitFactor(r)
        for i = 1, #(r.reagents or {}), 2 do
            local id, n = r.reagents[i], (r.reagents[i + 1] or 1) * e.count
            for _, x in ipairs(P.ExpandNeed(id, n)) do
                local t = need[x.id]
                if not t then t = { id = x.id, need = 0, origin = x.origin, unit = x.unit, known = x.known }; need[x.id] = t end
                t.need = t.need + x.count
                -- the lowest limit of all recipes that use the material (never above any recipe's threshold)
                local cap = (f or Q.FALLBACK_MARKUP)
                if not limit[x.id] or cap < limit[x.id] then limit[x.id] = cap end
            end
        end
    end
    local out = {}
    for id, t in pairs(need) do
        t.have = Q.Have(id)
        t.missing = math.max(0, t.need - t.have)
        -- limitPrice: up to where the recipe still pays (shown); maxPrice: what the sniper may pay at most (PS52-1)
        t.limitPrice = (t.unit and t.unit > 0) and math.floor(t.unit * limit[id]) or nil
        t.maxPrice = (t.unit and t.unit > 0) and math.floor(t.unit * math.min(limit[id], Q.SNIPER_CAP)) or nil
        out[#out + 1] = t
    end
    table.sort(out, function(a, b)
        if (a.origin == "vendor") ~= (b.origin == "vendor") then return a.origin == "vendor" end
        return ns.ItemName(a.id) < ns.ItemName(b.id)
    end)
    return out
end

-- the line of the bar: "Queue 3 · missing: 12× Linen Cloth, 4× Coarse Thread"
function Q.BarText()
    local n = Q.Count()
    if n == 0 then return L.Q_EMPTY end
    local miss = {}
    for _, t in ipairs(Q.ShoppingList()) do
        if t.missing > 0 then miss[#miss + 1] = t.missing .. "× " .. ns.ItemName(t.id) end
    end
    local text = string.format(L.Q_BAR, n)
    if #miss == 0 then return text .. " · " .. L.Q_ALL_THERE end
    if #miss > 2 then miss = { miss[1], miss[2], "…" } end
    return text .. " · " .. string.format(L.Q_MISSING, table.concat(miss, ", "))
end

-- click: buy the missing vendor materials at the open vendor
function Q.BuyVendor()
    local PL = ns.Plan
    if not (PL and PL.MerchantOpen()) then ns.Print(L.PLAN_NO_MERCHANT); return 0 end
    local list = {}
    for _, t in ipairs(Q.ShoppingList()) do
        if t.origin == "vendor" and t.missing > 0 then list[#list + 1] = { id = t.id, missing = t.missing, origin = "vendor" } end
    end
    if #list == 0 then return 0 end
    local saved = PL.current
    PL.current = { list = list }
    local n = PL.BuyFromVendor()
    PL.current = saved
    Changed()
    if ns.PLHit and (n or 0) > 0 then ns.PLHit("HAENDLER", n .. " gekauft") end
    return n
end

-- click: the missing AH materials into AHSentinel's sniper, each with its "buy up to" price
function Q.ToSniper()
    local targets = {}
    for _, t in ipairs(Q.ShoppingList()) do
        if t.origin ~= "vendor" and t.missing > 0 and t.maxPrice and t.maxPrice > 0 then
            targets[#targets + 1] = { id = t.id, maxPrice = t.maxPrice, qty = t.missing }
        end
    end
    if #targets == 0 then return 0 end
    return ns.Disenchant.SendToSniper(targets, L.Q_TITLE, L.PLAN_SNIPE_DONE)
end
