local _, ns = ...
local L = ns.L

-- Price broker (instruction of the review, 9 Nov. 16:50, "Werte aus AHSentinel und anderen AH-Addons"):
-- ONE place through which ProfessionSentinel gets every value. Order (per value; if a source lacks a value, the
-- next one is asked):
--   1. AHSentinel.API (contract version 1, raidmaster shared/wissen/schnittstelle-ahsentinel-api.md);
--      until AHSentinel publishes it: its existing public functions (global AHAnalyzerPro: RealPrice, RealValue,
--      AuctionFee(total, itemID, qty), CutPct, ListingDeposit, MinDeposit, GetCurrent, GetMarketValue)
--   2. auxForever – AuxForeverAPI.GetLatestPrice(item) -> price, age in days (docs/api.md and core/api.lua of aux)
--   3. Auctionator – Auctionator.API.v1.GetAuctionPriceByItemID(callerID, itemID) (Source/API/v1)
--   4. Auctioneer (Forever) – Auctioneer:Statistics(itemID) -> stats, stat:Best() (Auctioneer/API.md);
--      disenchanting values from Enchantrix.Storage.GetItemDisenchantTotals(link) (EnxStorage.lua)
--   5. TSM (Retail only, no Forever version) – TSM_API.GetCustomPriceValue("dbmarket", "i:<id>")
--   6. no AH addon: own calculation by the rule book (vendor price, data pack)
-- Sources 2-5 give prices only; fee, cheapest material way and disenchanting value are then computed here by the
-- same formulas as AHSentinel (rule book sections 1 and 4). Every call is guarded (pcall + type check); a missing
-- function is never guessed: the source is left out and the diagnostic log gets "PREISQUELLE <addon>: Funktion
-- nicht gefunden" (once per session).
--
-- Fee rule (rule book section 1, measured in the game 9 Nov.): when selling 5 % of the sale price (neutral AH 15 %);
-- the deposit (vendor price × quantity × 5 % per 2 h, minimum per auction measured, 1s on 9 Nov., announced 1c)
-- comes back on a sale and is lost when the auction runs out: expected cost = deposit × (1 - p) / p.
-- Era/TBC/Retail: unchanged (5 % cut, deposit comes back).

local PS = {}
ns.PriceSource = PS

PS.CALLER = "ProfessionSentinel"
PS.CUT_PCT = 0.05                -- faction AH (rule book: belegt)
PS.DEPOSIT_PCT_PER_2H = 0.05     -- deposit = vendor price × qty × 5 % per 2 h (belegt: 1s / 1s 60c / 4s 80c)
PS.MIN_DEPOSIT = 100             -- Forever, 9 Nov. (belegt); announced to become 1c – AHSentinel measures it
PS.HOURS = 24
PS.SELL_DAYS = 2                 -- recommend at most what sells in ~2 days
PS.MIN_PROFIT_PCT = 20
PS.CRAFT_DEPTH = 2               -- cheapest way: craft intermediate products, at most 2 levels

---------------------------------------------------------------------------
-- Diagnostic: each problem of a source once per session
---------------------------------------------------------------------------
local reported = {}
PS.errors = {}
function PS.Report(source, what)
    local key = source .. "|" .. tostring(what)
    if reported[key] then return end
    reported[key] = true
    local text = (what == "missing") and (source .. ": Funktion nicht gefunden")
        or (source .. ": Fehler " .. tostring(what))
    PS.lastReport = text
    if ns.Diag then pcall(ns.Diag, "PREISQUELLE", text) end
end
function PS.ResetReports() reported = {}; PS.lastReport = nil; PS.paused, PS.burst, PS.skipped = {}, {}, {} end

-- pcall with error report; returns the function's values or nothing
-- all return values are passed on, also behind a nil (PS58-1: WorthUpTo returns 5 values, the 4th may be nil)
local function Pack(...) return { n = select("#", ...), ... } end
-- PS-RUN-1: a function of another addon that fails again and again is paused for a while instead of being asked thousands of
-- times (every failing call costs the error path; a view asks thousands of prices): after PAUSE_AFTER errors in a row it is
-- not asked for PAUSE_SEC seconds (the calculation goes on without it, as without the addon), then tried again.
PS.PAUSE_AFTER = 10
PS.PAUSE_SEC = 30
PS.paused, PS.burst, PS.skipped = {}, {}, {}
local function Clock() return GetTime and GetTime() or 0 end
local function Call(source, fn, ...)
    return PS.CallCounted(source, nil, fn, ...)
end

-- Nachbau with the real AHSentinel and its real data (Ingametest 0.9.66 point 2, leistung.md M4/rule 4): one test run asked
-- AHSentinel 773 943× for a vendor price, 208 815× NetSale, 186 780× Price … – 11.5 s and about 950 MB of new tables inside
-- AHSentinel, which the garbage collector then cleans up in long frames. Prices only change with a scan or a booking:
-- answers of these read-only functions are kept per function and arguments until AHSentinel reports a change
-- (PS.OnChanged), for at most PS.VALUE_MAX_AGE seconds, at most PS.VALUE_MAX entries (then emptied). Errors are never kept.
PS.VALUE_MAX_AGE = 60
PS.NIL_MAX_AGE = 5
PS.VALUE_MAX = 30000
PS.CACHEABLE = {
    ["AHSentinel.API.Price"] = true, ["AHSentinel.API.NetSale"] = true, ["AHSentinel.API.WorthUpTo"] = true,
    ["AHSentinel.API.BestWay"] = true, ["AHSentinel.API.MarketState"] = true, ["AHSentinel.API.SellSpeed"] = true,
    ["AHSentinel.API.DisenchantValue"] = true, ["AHSentinel.API.CutPct"] = true, ["AHSentinel.API.MaterialCost"] = true,
    ["AHSentinel.API.MinProfitPct"] = true, ["AHSentinel.API.Deposit"] = true,
    ["AHAnalyzerPro.GetVendorBuyPrice"] = true,          -- GetVendorCost (Händlergunst) is always asked fresh
    ["AHSentinel:RealPrice"] = true, ["AHSentinel:RealValue"] = true, ["AHSentinel:GetMarketValue"] = true,
}
PS.valueCache, PS.valueCount, PS.valueAt = {}, 0, nil
PS.valueHits, PS.valueMisses = 0, 0
local NILKEY = {}
function PS.ClearValues()
    PS.valueCache, PS.valueCount, PS.valueAt = {}, 0, nil
end
-- the slot for fn and up to 4 arguments (nested tables, unrolled: a question that is kept allocates nothing – no strings,
-- no tables; leistung.md rule 3)
local function Step(t, k, create)
    if k == nil then k = NILKEY end
    local u = t[k]
    if not u and create then u = {}; t[k] = u end
    return u
end
local function Slot(fn, a1, a2, a3, a4, create)
    local t = PS.valueCache[fn]
    if not t then
        if not create then return nil end
        t = {}; PS.valueCache[fn] = t
    end
    t = Step(t, a1, create); if not t then return nil end
    t = Step(t, a2, create); if not t then return nil end
    t = Step(t, a3, create); if not t then return nil end
    return Step(t, a4, create)
end
-- BEFUND API-TAB-1 (review 17 Nov. 22:45): AHSentinel 0.65.334 reused its returned tables – a kept answer then changed under
-- us (ingredients of another item). Every table of a kept answer is therefore COPIED when it is kept (up to 3 levels deep);
-- what we keep can never change afterwards, whatever the source does with its own tables. Only on a miss (allocation then is
-- normal), never on a hit.
local function CopyValue(v, depth)
    if type(v) ~= "table" or depth > 3 then return v end
    local t = {}
    for k, x in pairs(v) do t[k] = CopyValue(x, depth + 1) end
    return t
end
PS.CopyValue = CopyValue
local CallRaw
function PS.CallCounted(source, countAs, fn, ...)
    if not PS.CACHEABLE[source] or select("#", ...) > 4 then return CallRaw(source, countAs, fn, ...) end
    local now = (GetTime and GetTime()) or 0
    if not PS.valueAt or now - PS.valueAt >= PS.VALUE_MAX_AGE or now < PS.valueAt or PS.valueCount >= PS.VALUE_MAX then
        PS.ClearValues()
        PS.valueAt = now
    end
    -- a click that moves gold (ns.FreshPrices): in this frame always asked again, the fresh answer is kept
    local fresh = PS.fresh ~= nil
    local slot = not fresh and Slot(fn, ...)
    local v = slot and slot.v
    -- a kept nil ("not known") only counts for PS.NIL_MAX_AGE seconds
    if v and v.nilAt and (now - v.nilAt >= PS.NIL_MAX_AGE or now < v.nilAt) then v = nil end
    if v then PS.valueHits = PS.valueHits + 1; return unpack(v, 1, v.n) end
    PS.valueMisses = PS.valueMisses + 1
    PS.lastFailed = false
    local res = Pack(CallRaw(source, countAs, fn, ...))
    -- an error (or a paused source) is never kept. nil as first value means "not known (yet)" – also while AHSentinel still
    -- computes its market factors after loading (review 17 Nov. 23:40): it is kept only PS.NIL_MAX_AGE seconds and dropped
    -- with every change AHSentinel reports ("settings" when its factors are ready). Never keeping it at all made every unknown
    -- item a new question: Nachbau echt with AHSentinel 0.65.341 997 738 questions instead of about 85 000.
    if not PS.lastFailed then
        local a1, a2, a3, a4 = ...
        local kept = { n = res.n }
        for i = 1, res.n do kept[i] = CopyValue(res[i], 1) end
        if res[1] == nil then kept.nilAt = now end
        Slot(fn, a1, a2, a3, a4, true).v = kept
        PS.valueCount = PS.valueCount + 1
        return unpack(kept, 1, kept.n)
    end
    return unpack(res, 1, res.n)
end

-- the call itself; an error is also counted as an error of the addon under `countAs` (ns.CountError, as before)
CallRaw = function(source, countAs, fn, ...)
    local untilT = PS.paused[source]
    if untilT then
        if Clock() < untilT then PS.skipped[source] = (PS.skipped[source] or 0) + 1; PS.lastFailed = true; return nil end
        PS.paused[source] = nil
    end
    -- Ingametest 0.9.72 (HOCH 1): what the price addon allocates for us, in the memory meter of the panel
    local mem = ns.UI and ns.UI.Mem
    if mem then mem.Begin("Preisabfrage " .. tostring(source)) end
    -- PS-P1 Teil 2: inside a measured piece of a background job the time of each foreign call (the report names the longest)
    local J = ns.Jobs
    local inPiece = J and J.InPiece and J.InPiece()
    local c0 = inPiece and J.Clock()
    local res = Pack(pcall(fn, ...))
    if c0 then
        local c1 = J.Clock()
        if c1 then J.PieceCall(source, c1 - c0) end
    end
    if mem then mem.End() end
    if not res[1] then
        PS.lastFailed = true
        PS.errors[source] = (PS.errors[source] or 0) + 1
        PS.Report(source, res[2])
        if countAs and ns.CountError then ns.CountError(countAs, res[2]) end
        local n = (PS.burst[source] or 0) + 1
        PS.burst[source] = n
        if n >= PS.PAUSE_AFTER then
            PS.burst[source] = nil
            PS.paused[source] = Clock() + PS.PAUSE_SEC
            if ns.Diag then pcall(ns.Diag, "PREISQUELLE", string.format("%s: %d Fehler hintereinander – %d s pausiert", source, n, PS.PAUSE_SEC)) end
        end
        return nil
    end
    if PS.burst[source] then PS.burst[source] = nil end
    return unpack(res, 2, res.n)
end
PS.Call = Call

local function Num(v) return type(v) == "number" and v == v and v or nil end
local function Pos(v) v = Num(v); return v and v > 0 and v or nil end
local function Now() return (time and time()) or 0 end


---------------------------------------------------------------------------
-- Sources
---------------------------------------------------------------------------
-- AHSentinel.API (version >= 1) – global AHSentinel.API, alias AHAnalyzerPro.API
function PS.API()
    local t = ns.Foreign("AHSentinel")
    local api = type(t) == "table" and t.API or nil
    if type(api) ~= "table" then
        local A = ns.Foreign("AHAnalyzerPro")
        api = type(A) == "table" and A.API or nil
    end
    if type(api) == "table" and (tonumber(api.version) or 0) >= 1 then return api end
    return nil
end

-- AHSentinel before the API (global AHAnalyzerPro, methods)
function PS.Legacy()
    local A = ns.Foreign("AHAnalyzerPro")
    return type(A) == "table" and A or nil
end

-- function of the API (dot call), or nil + report when AHSentinel's API lacks it
local function ApiFn(name)
    local api = PS.API()
    if not api then return nil end
    local fn = api[name]
    if type(fn) == "function" then return fn end
    PS.Report("AHSentinel.API." .. name, "missing")
    return nil
end

-- method of the old AHSentinel, or nil (no report: the old names are optional)
local function LegacyFn(name)
    local A = PS.Legacy()
    local fn = A and A[name]
    if type(fn) == "function" then return fn, A end
    return nil
end

local function AddonLoaded(name)
    local fn = (C_AddOns and C_AddOns.IsAddOnLoaded) or _G.IsAddOnLoaded
    if type(fn) ~= "function" then return false end
    local ok, v = pcall(fn, name)
    return ok and v and true or false
end

-- the price sources in their order: { key, label, available(), price(itemID) -> price, kind, ageSeconds }
PS.SOURCES = {
    {
        key = "AHSentinel", label = "AHSentinel",
        available = function()
            local api = PS.API()
            if api and type(api.Price) == "function" then return true end
            local A = PS.Legacy()
            if not A then return false end
            if type(A.RealPrice) == "function" or type(A.GetMarketValue) == "function" then return true end
            PS.Report("AHSentinel", "missing")
            return false
        end,
        price = function(itemID)
            local fn = ApiFn("Price")
            if fn then
                local p, kind, age = Call("AHSentinel.API.Price", fn, itemID)
                -- "vendor" is the vendor's buying price, no AH price: the next source is asked, the vendor value
                -- comes only through VendorSell / VendorBuy (review 0.9.33, point 1)
                if Pos(p) and kind ~= "vendor" then return p, kind or "scan", Num(age) end
                return nil
            end
            local real, A = LegacyFn("RealPrice")
            if real then
                local p, info = Call("AHSentinel:RealPrice", real, A, itemID)
                if Pos(p) then
                    local kind = (type(info) == "table" and info.source == "ah") and "scan" or "market"
                    local t = type(info) == "table" and Num(info.currentTime)
                    return p, kind, t and (Now() - t) or nil
                end
                return nil
            end
            local mv
            mv, A = LegacyFn("GetMarketValue")
            if mv then
                local p = Call("AHSentinel:GetMarketValue", mv, A, itemID)
                if Pos(p) then return p, "market" end
            end
            return nil
        end,
    },
    {
        key = "aux", label = "auxForever",
        available = function()
            local X = ns.Foreign("AuxForeverAPI")
            if type(X) == "table" then
                if type(X.GetLatestPrice) == "function" then return true end
                PS.Report("auxForever", "missing")
                return false
            end
            if AddonLoaded("auxForever") then PS.Report("auxForever", "missing") end
            return false
        end,
        price = function(itemID)
            local X = ns.Foreign("AuxForeverAPI")
            if type(X.IsReady) == "function" and not Call("auxForever", X.IsReady) then return nil end
            local p, age = Call("auxForever", X.GetLatestPrice, itemID)
            if Pos(p) then return p, "scan", Num(age) and age * 86400 or nil end
            return nil
        end,
    },
    {
        key = "Auctionator", label = "Auctionator",
        available = function()
            local AU = ns.Foreign("Auctionator")
            if type(AU) ~= "table" then return false end
            local v1 = type(AU.API) == "table" and AU.API.v1
            if type(v1) == "table" and type(v1.GetAuctionPriceByItemID) == "function" then return true end
            PS.Report("Auctionator", "missing")
            return false
        end,
        price = function(itemID)
            local p = Call("Auctionator", ns.Foreign("Auctionator").API.v1.GetAuctionPriceByItemID, PS.CALLER, itemID)
            if Pos(p) then return p, "scan" end
            return nil
        end,
    },
    {
        key = "Auctioneer", label = "Auctioneer",
        available = function()
            local AC = ns.Foreign("Auctioneer")
            if type(AC) ~= "table" then return false end
            if type(AC.Statistics) == "function" then return true end
            PS.Report("Auctioneer", "missing")
            return false
        end,
        price = function(itemID)
            local AC = ns.Foreign("Auctioneer")
            local stats = Call("Auctioneer", AC.Statistics, AC, itemID)
            if type(stats) ~= "table" then return nil end
            for _, st in ipairs(stats) do
                if type(st) == "table" and type(st.Best) == "function" then
                    local p = Call("Auctioneer", st.Best, st)
                    if Pos(p) then return p, "market" end
                end
            end
            return nil
        end,
    },
    {
        key = "TSM", label = "TSM",
        available = function()
            return type(ns.Foreign("TSM_API")) == "table" and type(ns.Foreign("TSM_API").GetCustomPriceValue) == "function"
        end,
        price = function(itemID)
            local p = Call("TSM", ns.Foreign("TSM_API").GetCustomPriceValue, "dbmarket", "i:" .. itemID)
            if Pos(p) then return p, "market" end
            return nil
        end,
    },
}

-- label of the first available source (what the panel and tooltip show), nil = own calculation only
function PS.SourceName()
    for _, s in ipairs(PS.SOURCES) do
        if s.available() then return s.label end
    end
    return nil
end

function PS.HasAHS() return PS.API() ~= nil or PS.Legacy() ~= nil end

-- what the panel shows: "Prices: AHSentinel" / "own"
function PS.SourceText()
    return string.format(L.PRICE_SOURCE, (ns.Sim and ns.Sim.prices and "Test") or PS.SourceName() or L.PRICES_OWN)
end

---------------------------------------------------------------------------
-- Price per piece (the value to calculate with = cheapest offer of the last scan; rule book section 3)
-- returns price, source label, kind ("scan" | "market" | "vendor"), age in seconds
---------------------------------------------------------------------------
function PS.Price(itemID)
    if not itemID then return nil end
    for _, s in ipairs(PS.SOURCES) do
        if s.available() then
            local p, kind, age = s.price(itemID)
            if p then return p, s.label, kind, age end
        end
    end
    return nil
end

---------------------------------------------------------------------------
-- Fee and deposit (rule book section 1)
---------------------------------------------------------------------------
function PS.CutPct()
    local fn = PS.API() and ApiFn("CutPct")
    if fn then
        local v = Num(Call("AHSentinel.API.CutPct", fn))
        if v and v >= 0 and v < 1 then return v end
    end
    local m, A = LegacyFn("CutPct")
    if m then
        local v = Num(Call("AHSentinel:CutPct", m, A))
        if v and v >= 0 and v < 1 then return v end
    end
    return PS.CUT_PCT
end

-- the AH share of a sale of this total (copper), rounded DOWN: the three invoices measured on 9 Nov. (rule book
-- section 1) are 202 of 4042, 837 of 16744 and 313 of 6279 – rounding to the nearest copper would give 314 for the
-- last one, rounding down matches all three exactly
function PS.Cut(total)
    return math.floor((tonumber(total) or 0) * PS.CutPct() + 1e-9)
end

function PS.MinDeposit()
    local m, A = LegacyFn("MinDeposit")
    if m then
        local v = Num(Call("AHSentinel:MinDeposit", m, A))
        if v and v >= 1 then return v end
    end
    return PS.MIN_DEPOSIT
end

-- own deposit formula for ONE auction of qty pieces (Forever: at least the measured minimum)
function PS.OwnDeposit(itemID, qty, hours)
    qty, hours = math.max(1, qty or 1), hours or PS.HOURS
    local vendor = ns.Prices and ns.Prices.VendorSell(itemID) or 0
    local dep = math.floor(vendor * qty * PS.DEPOSIT_PCT_PER_2H * hours / 2)
    if ns.IsForever == true then dep = math.max(dep, PS.MinDeposit()) end
    return dep
end

-- deposit of ONE auction: AHSentinel (Blizzard's value with the AH open, else its formula), else own formula
function PS.Deposit(itemID, qty, hours)
    qty, hours = math.max(1, qty or 1), hours or PS.HOURS
    local fn = PS.API() and ApiFn("Deposit")
    if fn then
        local v = Num(Call("AHSentinel.API.Deposit", fn, itemID, qty, hours))
        if v and v >= 0 then return v end
    end
    local m, A = LegacyFn("ListingDeposit")
    if m then
        local v = Num(Call("AHSentinel:ListingDeposit", m, A, itemID, qty, hours, 1))
        if v and v >= 0 then return v end
    end
    return PS.OwnDeposit(itemID, qty, hours)
end

-- expected loss of deposits per sale: deposit × (1 - p) / p (p = chance to sell per listing). Without measured
-- data p = 1 (like AHSentinel: no relisting expected) -> 0. Only Forever; elsewhere unchanged.
function PS.DepositRisk(itemID, qty, p)
    if ns.IsForever ~= true then return 0 end
    p = Num(p) or 1
    if p >= 1 then return 0 end
    p = math.max(0.1, p)
    return math.floor(PS.Deposit(itemID, qty) * (1 - p) / p + 0.5)
end

---------------------------------------------------------------------------
-- Net sale (total for qty pieces after the cut and the expected deposit loss, at least the vendor value)
-- returns total, { gross, cut, depositRisk, vendorWins, kind, source }
---------------------------------------------------------------------------
function PS.OwnNetSale(itemID, qty, price, sellChance)
    qty = qty or 1
    local vendor = (ns.Prices and ns.Prices.VendorSell(itemID) or 0) * qty
    if not price then
        if vendor > 0 then return vendor, { gross = 0, cut = 0, depositRisk = 0, vendorWins = true } end
        return nil
    end
    local gross = price * qty
    local cut = PS.Cut(gross)
    local risk = PS.DepositRisk(itemID, qty, sellChance)
    local net = gross - cut - risk
    local info = { gross = gross, cut = cut, depositRisk = risk, vendorWins = false }
    if vendor > net then net, info.vendorWins = vendor, true end
    return net, info
end

function PS.NetSale(itemID, qty)
    qty = qty or 1
    if not itemID then return nil end
    -- test mode: fixed prices, own formulas
    if ns.Sim and ns.Sim.prices and ns.Sim.prices[itemID] then
        local net, info = PS.OwnNetSale(itemID, qty, ns.Sim.prices[itemID])
        if info then info.source, info.kind = "Test", "scan" end
        return net, info
    end
    local fn = PS.API() and ApiFn("NetSale")
    local pending
    if fn then
        PS.lastFailed = false
        local net, info = Call("AHSentinel.API.NetSale", fn, itemID, qty)
        local failed = PS.lastFailed
        if Num(net) then
            info = type(info) == "table" and info or {}
            return net, { gross = Num(info.gross) or 0, cut = Num(info.cut) or 0, depositRisk = Num(info.depositRisk) or 0,
                vendorWins = info.vendorWins and true or false, source = "AHSentinel", kind = "scan" }
        end
        -- the API is there and says nil = "not known (yet)" (contract; e.g. its market factors are still being computed after
        -- loading, or the item has no market data): NEVER the internal A:RealValue (provisional in that time, no contract –
        -- review 17 Nov. 23:40 / 18 Nov. 00:10). The own formula below (price of the next source, vendor value as floor –
        -- what ProfessionSentinel does without AHSentinel) gives the value, marked "pending"; AHSentinel is asked again
        -- after PS.NIL_MAX_AGE s or its next change. (Returning nothing at all lost the vendor floor of items without AH
        -- data: Nachbau echt T37 "Gold: X,Z".) An error of the API likewise goes on to the own formula.
        pending = not failed
    end
    -- only an old AHSentinel WITHOUT the API: its methods
    local rv, A
    if not fn then rv, A = LegacyFn("RealValue") end
    if rv then
        local net, price, info, vendorWins = Call("AHSentinel:RealValue", rv, A, itemID, qty)
        if Num(net) then
            local gross = (Num(price) or 0) * qty
            local kind = (type(info) == "table" and info.source == "ah") and "scan" or "market"
            return net, { gross = gross, cut = Pos(price) and PS.Cut(gross) or 0,
                depositRisk = type(info) == "table" and Num(info.relistCost) or 0,
                vendorWins = vendorWins and true or false, source = "AHSentinel", kind = kind }
        end
    end
    local p, label, kind = ns.Prices.AH(itemID)      -- (memo of the pass: each price asked once)
    local net, info = PS.OwnNetSale(itemID, qty, p)
    if info then info.source, info.kind, info.pending = label, kind, pending or nil end
    return net, info
end

-- net value of one piece when sold in a full stack (materials of disenchanting are sold in stacks)
function PS.NetPiece(itemID)
    local stack = ns.Prices and ns.Prices.StackSize(itemID) or 1
    local net = PS.NetSale(itemID, stack)
    return net and net / stack or nil
end

---------------------------------------------------------------------------
-- Material cost over the cheapest way: AH (last scan), vendor, crafting from a known recipe (<= 2 levels, no loops)
-- returns cost per piece, way ("ah" | "vendor" | "craft"), known, kind ("scan"/"market"), via = { itemIDs }
---------------------------------------------------------------------------
local function OwnUnit(itemID, depth, seen)
    local P = ns.Prices
    local best, way, kind, via, recipe
    local vb = P.VendorBuy(itemID)
    if vb then best, way = vb, "vendor" end
    local ah, akind = P.BuyAH(itemID)
    if ah and (not best or ah < best) then best, way, kind = ah, "ah", akind end
    -- crafting: only recipes the player knows, no loops, at most CRAFT_DEPTH levels
    if depth < PS.CRAFT_DEPTH and ns.ByOutput then
        seen[itemID] = true
        for _, r in ipairs(ns.ByOutput[itemID] or {}) do
            if r.reagents and #r.reagents > 0 and ns.IsLearned(r) then
                local made = ((r.outMin or 1) + (r.outMax or r.outMin or 1)) / 2
                local cost, ok, ids = 0, true, {}
                for i = 1, #r.reagents, 2 do
                    local id, n = r.reagents[i], r.reagents[i + 1] or 1
                    if seen[id] then ok = false; break end
                    local u = OwnUnit(id, depth + 1, seen)
                    if not u then ok = false; break end
                    cost = cost + u * n
                    ids[#ids + 1] = id
                end
                if ok and made > 0 then
                    local unit = cost / made
                    if not best or unit < best then best, way, kind, via, recipe = unit, "craft", nil, ids, r end
                end
            end
        end
        seen[itemID] = nil
    end
    return best, way, kind, via, recipe
end

-- (AHSentinel.API.MaterialCost(itemID) is the cost to CRAFT itemID – not the price of a reagent; review 0.9.33,
-- point 2. The cheapest way of each reagent is computed here with the prices of the source.)
-- 6th value: the recipe it is made with (for "craft": the shopping lists buy its materials)
function PS.MaterialUnit(itemID)
    if not itemID then return nil end
    local unit, way, kind, via, recipe = OwnUnit(itemID, 0, {})
    if not unit then return nil end
    return unit, way, true, kind, via, recipe
end

---------------------------------------------------------------------------
-- AHSentinel-only values (no own copy: nil without AHSentinel)
---------------------------------------------------------------------------
-- gross per disenchant, net, own disenchants of the group, source ("own"/"table")
function PS.DisenchantValue(itemID)
    local fn = itemID and PS.API() and ApiFn("DisenchantValue")
    if not fn then return nil end
    local gross, net, own, src = Call("AHSentinel.API.DisenchantValue", fn, itemID)
    if not Num(gross) then return nil end
    return gross, Num(net) or gross, Num(own) or 0, src
end

-- PS-TQ1 (AHS-API2, additive, may not exist yet): own disenchants of itemID since `since` over all own characters ->
-- n, value (copper, loot in total), first, last; nil without the function or without data. Asked fresh (not kept), silent
-- when the function is missing (an older AHSentinel is no error).
-- PS-TQ1-b: AHSentinel 0.65.403+ builds its index in the background; while it is not ready it answers nil, "pending" ->
-- here nil, "pending" (ask again later, the note stays open). "never disenchanted" = nil without a second value.
function PS.Disenchanted(itemID, since)
    local api = itemID and PS.API()
    local fn = api and api.Disenchanted
    if type(fn) ~= "function" then return nil end
    local t, why = Call("AHSentinel.API.Disenchanted", fn, itemID, since)
    if t == nil and why == "pending" then return nil, "pending" end
    if type(t) ~= "table" or not Num(t.n) or t.n <= 0 then return nil end
    return t.n, Num(t.value) or 0, Num(t.first), Num(t.last)
end

-- Enchantrix (with Auctioneer): gross value per disenchant (median of the materials); nil if unknown
function PS.EnchantrixValue(itemID)
    local E = ns.Foreign("Enchantrix")
    if type(E) ~= "table" or type(E.Storage) ~= "table" then return nil end
    local fn = E.Storage.GetItemDisenchantTotals
    if type(fn) ~= "function" then PS.Report("Enchantrix", "missing"); return nil end
    local ok, _, link = pcall(ns.ItemInfo, itemID)
    if not ok or type(link) ~= "string" then return nil end
    local _, median = Call("Enchantrix", fn, link)
    return Pos(median)
end

-- "sell" | "disenchant", net value of that way (per piece)
function PS.BestWay(itemID)
    local fn = itemID and PS.API() and ApiFn("BestWay")
    if not fn then return nil end
    local way, net = Call("AHSentinel.API.BestWay", fn, itemID)
    if (way == "sell" or way == "disenchant") and Num(net) then return way, net end
    return nil
end

-- "fast" | "slow" | "rare" | nil, median hours to sell, sales per day at the market
function PS.SellSpeed(itemID)
    local fn = itemID and PS.API() and ApiFn("SellSpeed")
    if not fn then return nil end
    local state, hours, perDay = Call("AHSentinel.API.SellSpeed", fn, itemID)
    return state, Num(hours), Num(perDay)
end

-- how many to make at most (what sells in ~2 days); 0 = hardly sells (no profit recommendation); nil = unknown
function PS.SellCap(itemID)
    local state, _, perDay = PS.SellSpeed(itemID)
    if state == "rare" then return 0 end
    if perDay and perDay > 0 then return math.max(1, math.floor(perDay * PS.SELL_DAYS + 0.5)) end
    return nil
end

function PS.MinProfitPct()
    local fn = PS.API() and ApiFn("MinProfitPct")
    if fn then
        local v = Num(Call("AHSentinel.API.MinProfitPct", fn))
        if v and v >= 0 then return v, "AHSentinel" end
    end
    local own = ns.db and tonumber(ns.db.vzMarkup)
    return own or PS.MIN_PROFIT_PCT, "own"
end

-- copper per hour and measured seconds; only from AHSentinel (we do not measure it ourselves)
-- Nachbau with the real AHSentinel and its real data (Ingametest 0.9.66 point 2): ONE call of AHSentinel.API.GoldPerHour takes
-- 77–93 ms (it sums up 30 days of bookings) and the panel asked for it in every build (price line) – one frame over 40 ms per
-- view. Now: kept for PS.GPH_MAX_AGE seconds (dropped when AHSentinel reports a booking change), never asked inside the
-- panel build: a missing / old value is fetched in a frame of its own after the build, the line shows the kept value
-- meanwhile. The test routine and clients without a timer ask at once (as before).
PS.GPH_MAX_AGE = 600
PS.gphCache = {}
local function FetchGPH(kind)
    local fn = PS.API() and ApiFn("GoldPerHour")
    if not fn then return nil end
    local gph, secs = Call("AHSentinel.API.GoldPerHour", fn, kind)
    local c = { at = (GetTime and GetTime()) or 0 }
    if Num(gph) then c.v, c.secs = gph, Num(secs) end
    PS.gphCache[kind] = c
    PS.gphFetches = (PS.gphFetches or 0) + 1
    return c
end
-- AHSentinel >= 0.65.343: API.Pending() = its market values are still being computed after loading (contract). Older
-- versions without it: nil -> no hint.
function PS.Pending()
    local fn = PS.API() and ApiFn("Pending")
    if not fn then return false end
    local ok, v = pcall(fn)
    return ok and v and true or false
end

function PS.GoldPerHour(kind)
    kind = kind or "craft"
    local fn = PS.API() and ApiFn("GoldPerHour")
    if not fn then return nil end
    local now = (GetTime and GetTime()) or 0
    local c = PS.gphCache[kind]
    local fresh = c and now - c.at < PS.GPH_MAX_AGE and now >= c.at
    if not fresh then
        local sync = not (ns.API and ns.API.TimerAfter) or (ns.Jobs and ns.Jobs.Sync and ns.Jobs.Sync())
        -- never inside a portioned build (also not while the test routine warms the views up)
        if sync and ns.UI and ns.UI.InBuild and ns.UI.InBuild() and ns.API and ns.API.TimerAfter then sync = false end
        if sync then
            c = FetchGPH(kind)
        elseif not PS.gphPending then
            PS.gphPending = true
            -- a frame of its own, after the current build (one AHSentinel call cannot be split by us)
            ns.API.TimerAfter(0, function()
                PS.gphPending = nil
                if ns.UI and ns.UI.Building and ns.UI.Building() then
                    ns.API.TimerAfter(0.2, function() PS.GoldPerHour(kind) end)
                    return
                end
                local c2 = FetchGPH(kind)
                -- a new value: the visible panel shows it with its next (portioned) build
                if c2 and c2.v and ns.UI and ns.UI.PanelVisible and ns.UI.PanelVisible() and ns.UI.RequestRefresh then
                    ns.UI.RequestRefresh("Gold je Stunde")
                end
            end)
        end
    end
    if c and c.v then return c.v, c.secs end
    return nil
end

---------------------------------------------------------------------------
-- Subscription: after a scan / booking AHSentinel calls us (at most every 2 s); values again, throttled
---------------------------------------------------------------------------
PS.subscribed = false
function PS.OnChanged(reason)
    PS.changes = (PS.changes or 0) + 1
    PS.changedAt = (GetTime and GetTime()) or 0
    PS.ClearValues()                   -- new scan / booking / setting: every kept answer of AHSentinel is asked again
    -- PS-P1/PS-P2 (b): kept WorthUpTo answers too, with the reason in the log. EXCEPT "ledger" while ProfessionSentinel waits for
    -- AHSentinel's disenchant index (MK.dePending, PS-TQ1-b): that "ledger" only says "index ready" (no booking, no price) –
    -- AHSentinel.API.DEIndex sends it after building the index from the same data (API.lua: Notify("ledger") after BuildDEIndex)
    local P = ns.Prices
    if P and P.ForgetWorth then
        local MK = ns.Market
        if reason == "ledger" and MK and MK.dePending then
            if P.NoteKeptWorth then P.NoteKeptWorth("ledger (Entzauber-Index fertig)") end
        else
            P.ForgetWorth(reason)
        end
    end
    if reason == "ledger" or reason == "settings" then PS.gphCache = {} end      -- gold per hour comes from the bookings
    if ns.Advisor and ns.Advisor.Invalidate then ns.Advisor.Invalidate() end
    if ns.UI and ns.UI.RequestRefresh and ns.UI.PanelVisible and ns.UI.PanelVisible() then
        ns.UI.RequestRefresh("AHSentinel:" .. tostring(reason))
    end
    -- the basic rules on the real data after a scan (Market.lua TU5, at most every 10 minutes, in portions)
    if reason == "scan" and ns.Market and ns.Market.CheckReal then pcall(ns.Market.CheckReal) end
    -- PS-TQ1-b: AHSentinel's disenchant index is ready ("ledger" after "pending"): the open notes asked again (throttled)
    if reason == "ledger" and ns.Market and ns.Market.OnLedger then pcall(ns.Market.OnLedger) end
end

function PS.Subscribe()
    if PS.subscribed then return true end
    local fn = PS.API() and ApiFn("Subscribe")
    if not fn then return false end
    local ok = pcall(fn, function(reason) pcall(PS.OnChanged, reason) end)
    PS.subscribed = ok and true or false
    return PS.subscribed
end

local f = ns.AddEventFrame and ns.AddEventFrame(CreateFrame("Frame"), "PriceSource") or CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
-- at a vendor AHSentinel learns vendor prices: kept answers are asked again
f:RegisterEvent("MERCHANT_SHOW")
f:RegisterEvent("MERCHANT_CLOSED")
f:SetScript("OnEvent", function(_, event)
    if event == "MERCHANT_SHOW" or event == "MERCHANT_CLOSED" then
        PS.ClearValues()
        if ns.Prices and ns.Prices.ForgetWorth then ns.Prices.ForgetWorth(event) end     -- the vendor way of "worth up to"
        return
    end
    PS.Subscribe()
    -- AHSentinel may set up its API a little later
    if ns.API and ns.API.TimerAfter then ns.API.TimerAfter(5, function() PS.Subscribe() end) end
end)
