# LevelPilot changelog

## 3.12.97
- Smoother game: many calculations now yield to the game more often (path network, path search, replanning, sharing paths, service
  NPCs, assistant). The assistant checks in the background in portions; the list of dungeon quests and the path network statistics are
  remembered instead of recounted whenever the hub opens; terrain maps are unpacked faster.
- Player sync: shared file GoldSentinelSync 3 (during a test routine Sync learns nothing from messages and sends no real whispers;
  offline messages are recognised in other spellings too).
- Test mode: T261 breaks down the CPU time of the first 60 s by task and says whether it was a first or second login; T155 shows the
  median, the longest plan and the memory per plan; T340 and T355 without long frames; new test T360.

## 3.12.96
- Important: the test routine could put test names (e.g. "LPWeiter-Test") into the shared address book of the GoldSentinel addons.
  The whisper network then sent real whispers to these made-up names ("No player named … is currently playing").
  Fixed: tests now leave the address book exactly as it was, and LevelPilot removes these test names (only these) when loading –
  the diagnosis log shows "Sync address book cleaned: n test names".
- The data backup starts one minute after login (faster login) and stops if a virtual journey starts meanwhile (it would otherwise
  have saved the journey's data); logging out saves as always.
- Detour cache: the key of a zone's path network now also includes which waypoints are connected (each zone is measured once again).

## 3.12.95
- Faster login: the detour factor per zone (how much longer the real path is than the straight line) is saved and reused at the
  next login as long as the zone's path network is unchanged (before: measured again every time, 88–263 ms per zone in tests).
- The data backup at login runs in small portions in the background (before: in one go, 85 ms in one frame in game).
- "/lp log" only measures the memory of all addons with "/lp log mem" – this measurement briefly pauses the game (93 ms in game).
  The command list says so.
- Weapon skill: the hint for a low skill of the equipped weapon now also works in WoW Forever (it read the weapon type through an
  old game function that does not exist there and stayed silent).
- Tasks that come up during a test routine are started afterwards instead of being dropped (before, e.g. a zone's detour
  measurement stayed at the default until the next rebuild).
- Test mode: T275 checks one game version per run in rotation (Forever, Era, TBC); T157 no longer measures the memory of all
  addons; the line "frames over 40 ms in which memory dropped" shows where garbage collection lengthens a frame. New tests T354–T356.

## 3.12.94
- Test mode: more heavy checks run in portions (T26, T224–T227, T263, T319 and others); a language switch changes fonts in smaller
  steps.
- Test mode: the intentional test error (T142, T159) no longer opens the game's error window.
- Test mode: T261 shows the computing time of the first 60 s per area (sum, calls, longest call).

## 3.12.93
- Test mode: /lp testroutine no longer freezes the game. The whole routine runs as one task of the shared scheduler
  (GoldSentinelTakt, at most 4 ms per frame) and yields between checks and at safe points inside heavy checks – never while a
  check has substitute values in place. Backup, restore and comparison of the real data also run in portions (before: up to
  2.4 s in one frame).
- Test mode: the "Portions" line also shows "frames over 40 ms"; the report contains the scheduler's measurement.
- Faster: language switch (labels) and vendors/service NPCs (terrain maps unpacked only once per map); path data export encodes
  each zone only once. Results unchanged (checked against the previous version).
- Route: the level band per zone (zones in your own level band preferred) was not calculated in the background planning after
  login (an error in portions, silently caught) – now calculated first in the planning; recalculated after switching "use data
  pack" off/on.

## 3.12.92
- Less stutter: the path network is loaded in small portions at login (shared scheduler GoldSentinelTakt, at most 4 ms per
  frame). While it loads (a fraction of a second), navigation honestly shows the straight line.
- Navigation route search runs on the same scheduler; long own paths are also computed in portions the first time.
- Test data stays in LevelPilot: during tests LevelPilot does not share its own recordings with guild, group or network.
  New interface LevelPilotAPI.TestRunning() for other addons.
- Test routine: T151 measures route search in portions. New tests T351, T352.

## 3.12.91
- Name search (/lp navi): upper/lower case for umlauts and Cyrillic no longer depends on the computer's language settings.
- Test routine: tests never write to the game's global variables any more (protection against "tainted" game functions until
  /reload); new test T350 checks this, in game also for important Blizzard functions.
- Test routine: T220, T221, T249, T293 now check correctly with own quest data, large path data, another GoldSentinel addon or a
  closed guide window in the game. Help text of T346 complete again.

## 3.12.90
- Faster route search with many own paths: points in the middle of a walked path are followed in one go. On a network with
  about 19,000 own points the route search is about four times faster, and the routes are just as good.
- At login this preparation runs in small portions in the background.
- Virtual journey: with a hearthstone location set, a journey from your current position stopped at the start, and parts of
  the guide stayed redirected until the next /reload. Fixed; the journey now checks by itself that everything is restored.
- Test routine: report line on portions (frames, longest frame, steps over 16 ms) and computing time per area. T151 now really
  measures Orgrimmar -> Crossroads. T279 and T303 without test errors. New tests T348, T349.

## 3.12.89
- Test mode: when a checklist item ticks itself off during normal play (or an error is detected), a small test report is
  created for it. It is sent with the next upload, even if the chat line was missed.
- Test routine: new test T347.

## 3.12.88
- No more data from the game files, part 2: the road network has been removed. The route uses the paths walked by players and
  direct lines; otherwise it stays the same.
- Test mode: /lp testroutine alles runs every automatic check in one go, shows progress and ends with one line
  "Result: … of … passed …". /lp testroutine stopp cancels. The run never waits for you.
- Test mode: the checklist describes each point with place, numbered steps, what you should see and the cost; new point
  "measure map frames".
- No more data from the game files, part 3: the list of area names has been removed (names now come from the game itself);
  lift waiting times are a single estimate until they are measured in game.
- Talent suggestions: the next talent is now looked up by its name in the talent window instead of a fixed position.
  Talent suggestions are only available in German and English; other languages show a hint. Where the name of a talent is
  not confirmed yet, the suggestion stops there with a hint.
- Shared module GoldSentinelMarkt version 10.
- Test routine: new tests T344 (map frames), T345, T346 (talent tree); T299 and T305 renewed.

## 3.12.87 (data pack 1.6.4)
- No more data from the game files: places (subzones) now come from the quest givers in the quest data – several quest givers close
  together form a place (e.g. Sentinel Hill, Lakeshire). The starting area again reaches halfway to the first inn. Data pack 1.6.4
  no longer contains a places file.
- Recorded quest order (only with your consent): the zone is stored instead of the area ID.
- Test mode: new command /lp kartenrahmen measures the map frames in the game (for testing LevelPilot).
- Test routine: test T334 renewed, new test T344.

## 3.12.86
- Smarter hearthstone: the guide now also suggests the hearthstone when "hearthstone, then onward by flight or boat" is faster – not
  only when the target is close to the inn.
- Test routine: new test T343.

## 3.12.85
- Quest givers on the way: when two quest givers lay one after another on the way, one of them was sometimes skipped (the arrow passed
  close by and came back later). Now all of them are picked up.
- Test routine: test T339 extended.

## 3.12.84
- Continent as a block: the guide changes continent only when there are hardly any fitting quests left on yours – but then without a
  level limit. Slightly faster in the virtual journey 1–60.
- Test routine: test T341 adapted.

## 3.12.83
- Zones fitting your level: LevelPilot now knows the level range of each zone's quests (from the quest data) and prefers zones that fit
  your level.
- Test routine: new test T342.

## 3.12.82
- Less grinding: if there are hardly any fitting quests left on your continent, the guide sends you to the other continent instead
  of letting you kill monsters (also below level 30). In the virtual journey 1–60 the grinding share drops from about half to
  13–19 % of the play time.
- Test routine: test T341 extended.

## 3.12.81
- Fix: before a long leg (e.g. across a zone transition to a ship) the arrow could skip a waypoint still 100 yards ahead of you and
  then point back. A waypoint now only counts as passed when you are near it.
- Test routine: test T332 extended.

## 3.12.80
- Fewer continent changes: below level 30 the route stays on your continent, afterwards it changes at most every 10 levels. In the
  virtual journey 1–60: 3 instead of 11–13 continent changes, about a third less walking and 3.9 % less play time.
- Test routine: new test T341.

## 3.12.79
- Way data (only if sending way data is switched on): LevelPilot also records the order in which you accept and turn in quests (quest
  number, level, time, place – no names). We use it to check the route against real play.
- Test routine: new test T340.

## 3.12.78
- Quest givers on the way: if a quest giver with a quest for you stands on the way to the next target (at most 60 yards detour,
  also in the wild, at a camp or tower), the guide takes him along.
- Test routine: new test T339.

## 3.12.77
- All quest givers of a place first: if you stand in a village or camp (place as shown at the minimap), the guide first shows all
  quest givers there with a quest for you (up to 400 yards), only then targets outside.
- Test routine: new test T338.

## 3.12.76
- Path without hairpins: if the path goes a bit forward and back the same way, that piece is dropped – also in the middle of the
  path and while following the kept path.
- Test routine: test T337 extended.

## 3.12.75
- Calmer arrow and path: while walking, the path only changes when the new one is clearly shorter (at least 30 yards or 10 %).
  Before, it jumped between equally good variants – the distance rose briefly, the arrow turned.
- No more detour via a waypoint next to you: if a road passes close by, the path leads straight onto it instead of first to a
  node and then back.
- Test routine: new test T337.

## 3.12.74
- Quests at most 2 levels above you (before 3): no more orange quests that send you into a too high area. In the virtual
  journey 1–60 this is also slightly faster.
- Test routine: new test T336.

## 3.12.73
- Nearby quest givers first: if a quest giver with an available quest is at most 150 yards away, the guide shows him first –
  before targets farther away and before binding, flight point or hearthstone. He is also taken along just outside the starting
  area.
- Test routine: new test T335.

## 3.12.72
- Places from the game files (data pack 1.6.3): LevelPilot now knows for every point of the map the place shown at the minimap
  (Northshire Valley, Goldshire, Valley of Trials …) – separately for Classic Era and WoW Forever. The starting area is now exactly
  this place (e.g. Northshire Valley with Echo Ridge Mine and the vineyards) instead of a calculated border.
- Test routine: new test T334.

## 3.12.71
- Starting area (Classic Era and WoW Forever): below level 6 the route stays in the starting area (Northshire, Coldridge Valley,
  Shadowglen, Valley of Trials, Deathknell, Camp Narache) as long as there is something to do there – no target in the first
  village, no binding, no flight point before. Starting areas of other races are no longer targets (before, e.g. an orc went to
  Mulgore at level 4).
- Binding at an inn only when it lies on the way (at most 60 yards detour). Before, "Bind" in Northshire was step 1, before all
  nearby quest givers (inn of Goldshire).
- Fix: the path jumped between two variants while walking (distance rose, arrow turned) when a straight line grazed the corner of
  an area with too strong monsters. Areas are now checked without gaps.
- The arrow moves on past a waypoint that is already behind you.
- Test routine: new tests T332 and T333.

## 3.12.70
- Fix: a target you chose yourself (/lp navi, /lp way, /lp find, map pin, another addon) now always stands at the top of the guide
  and the arrow points there – before, a finished quest nearby came first. Suggestions of the assistant still come after nearby
  turn-ins.
- Test routine: new test T331.

## 3.12.69
- Fix: the navi search and /lp find now ignore upper/lower case also for umlauts, accented letters and Cyrillic ("/lp navi 50 50
  ödland" finds the Badlands in German, Russian names in any case).
- Fix: /lp protocol line REISE showed "(nil)" instead of the source of the speed, and a dot instead of a comma.
- Test routine: new test T330.

## 3.12.68
- Starter path network for 6 more zones (LW-4), from the paths LevelPilot players walked and sent in (no names): Durotar,
  Tirisfal Glades, Silverpine Forest, Hillsbrad Foothills, Thousand Needles, Stonetalon Mountains (before: Mulgore, The Barrens,
  Thunder Bluff). New characters get real paths there at once. WoW Forever only. In the virtual journey 1–60 the share of the way
  without a known path drops from about 80 % to about 67 %.
- Benchmark (LW-7 e): the virtual journey report compares each level with your best time of all your characters (no names).
- Test routine: new test T329.

## 3.12.67
- Flight prices (LW-8): when you open a flight master's map, LevelPilot notes the price the game shows for every reachable
  destination. The travel plan then shows it ("Flight to X, 1s 20c (2:10)"); without a measurement "price unknown". Prices are
  your own measurement, kept per game version.
- Test routine: new test T328.

## 3.12.66
- Speedrun up to level 10 (LW-7 d, off by default): if dying and resurrecting at the spirit healer near the target is clearly
  faster than walking (at least 3 minutes, even with a slow death), the travel plan shows a yellow hint "Speedrun trick: …
  saves ~X min – costs durability". Only a hint, never a route step. Switch: Settings, "Speedrun: suggest death as travel".
- Data pack 1.6.2: graveyards (spirit healers) from Questie (GPL), also converted for Classic Era.
- Test routine: new test T327.

## 3.12.65
- Route (LW-2b): in normal mode quests are now also weighed by time, not only by distance – a quest far away for a short task
  counts less, like in speedrun mode. Nothing is skipped in normal mode. Measured with the virtual journey 1–60 for 18
  characters (6 races × 3 classes): 15 faster, 3 slower, median 3 h 17 min less, less walking for 17 of 18.
- Classic Era (LW-5 E1/E5): LevelPilot and LevelPilot Data now load in the Classic Era client (interface 16001 and 11509 in
  one .toc, measured: WoW Forever and Classic Era both accept it, nothing "out of date"). Classic Era is new – please report
  anything that looks wrong there. The in-game check list (/lp prüfliste, test mode only) has its own 6 points in Classic Era.
- Test routine: new tests T325, T326.

## 3.12.64
- Kill objectives (LW-7a): near the area of a kill objective with 3 or more enemy spawn groups, the arrow ("Enemies – round")
  now leads from group to group – always to the nearest one not yet visited (visited at 30 yards). When all are visited the
  round starts again (enemies respawn). Quest item spots keep priority. Switch: "Arrow to the nearest location".
- Test routine: new test T324.

## 3.12.63
- Navigator and route together (NAV-4): the travel plan by time now also appears under the next route step when it is far
  away (1500 yards or more, or another continent) – one calculation for navi and route. After a replan the same step keeps
  its plan (no flicker).
- Interface for other addons, version 2 (LevelPilotAPI): NavigateToNearest(kind), StopNavigation() (only targets set by an
  addon, never the player's own), GetNavigation() (a copy: map, coordinates, title, travel time, plan text) and
  TravelTime(map, x, y, callback). NavigateTo now also shows the travel plan. LevelPilot never changes other addons' data.
- Test routine: new test T323.

## 3.12.62
- Navigator on the way (NAV-3): if the way to a navi target still passes enemies of your level + 3 or higher (the path search
  already avoids such areas where it can), the travel plan shows a red line "Caution: enemies up to level X on the way".
  Reaching a navi target (/lp navi, /lp way, /lp find, map pin) now says "Navi: arrived – back to the route."
- Test routine: new test T322.

## 3.12.61
- Route (LW-2a): the next 8 steps after the first are now put in the exactly shortest order (by way cost), keeping the rules
  (accept before complete before turn-in, the quest log never overflows). Before, a fast improvement method (2-opt) did this;
  it was already close to the best in the measured examples, the exact order saves a little more where it can.
- Test routine: new test T321.

## 3.12.60
- Navigator, world map (NAV-1c): set a pin on the world map (the game's map pin) and LevelPilot guides there, with the travel
  plan under the target. Removing the pin ends this navigation; "/lp navi off" ends it too. Switch: Settings, "Navi to the pin
  on the world map" (on). In a client without map pins nothing happens.
- Test routine: new test T320.

## 3.12.59
- Navigator, search by name (NAV-1b): "/lp navi gornek", "/lp navi ragefire", "/lp navi barrens" – NPCs (quest givers,
  vendors, also monsters), dungeon entrances and zones, in the game's language, LevelPilot's language or English. NPCs of the
  other faction are left out; for each NPC the nearest spawn counts. One match: LevelPilot guides there at once. Several: the
  5 fastest with travel time ("/lp navi 2" picks number 2). The name list is built once on first use, in small portions.
- Fix: "/lp navi vendor" / "händler" and "trainer" were not recognised (since 3.12.54).
- Test routine: new test T319.

## 3.12.58
- Navigator, step 2 (NAV-2): travel plan by TIME. For every guide-to target (/lp navi, /lp way, /lp find) LevelPilot now
  works out the whole chain with seconds per part: walking/riding along the path network, flight (when it is faster, measured
  flight times), boat, zeppelin, tram, and the hearthstone when it is ready and faster. The guide shows it under the target,
  for example "Trip ~6:36: walk 20 yards (0:03) → Zeppelin → Tirisfal Glades (6:30) → walk 21 yards (0:03)", recalculated
  every 10 seconds (time left). Calculated in small portions, no stutter.
- Assumption to be measured: loading screen after the hearthstone to another continent 20 seconds.
- Test routine: new test T318.

## 3.12.57
- Classic Era, step 4 (LW-5 E4, prepared – not yet tested in the Era client): the parts that only make sense on WoW Forever
  now follow the game version. In another client (Classic Era) the switch "WoW Forever server" is not shown (it has no effect
  there), the data page no longer talks about new WoW Forever quests, quests are not marked NEW, and the self test no longer
  warns about Classic Era. WoW Forever is unchanged.
- Checked as well, no change needed: starter database (empty), data pack (Classic data, converted back since 3.12.55), starter
  path network and Forever roads (Forever client only), Forever rules (quest log 40, dungeon XP) already follow the game version.
- Test routine: new test T317.

## 3.12.56
- Classic Era, step 3 (LW-5 E3, prepared – not yet tested in the Era client): in the Classic Era client LevelPilot keeps its
  account-wide collected data separate from WoW Forever (walked routes, learned quests, flight points, vendors,
  calibration, data exchange and settings) – otherwise an Era character would get the Forever routes and the new Forever quests.
  Shared stay: diagnosis log, route export, test reports, check list, market data. WoW Forever
  keeps reading and writing exactly the same data as before; nothing is moved or lost.
- Test routine: new test T316.

## 3.12.55
- Classic Era, step 2 (LW-5 E2, prepared – not yet tested in the Era client): the data pack and LevelPilot's own data use the
  WoW Forever map frames. Four zones have different map borders in Forever (Mulgore, Eastern Plaguelands, Redridge, Stormwind).
  In the Classic Era client LevelPilot now converts them back once when loading (NPCs, objects, explore targets, dungeon
  entrances, mailboxes; zone transitions, terrain maps and the virtual journey's start points as well). Checked against
  Questie's original values: median deviation 0.04 % of the map. WoW Forever is unchanged.
- Test routine: new test T315.
- Classic Era roads now come from the real Classic Era client 1.15.9 (99.6–99.99 % the same as before from Anniversary).

## 3.12.54
- Navigator, first step (NAV-1a): one command /lp navi. "/lp navi 45 60 Barrens" guides to coordinates, also in another zone
  (zone name in the game's or LevelPilot's language, the beginning is enough); "/lp navi mailbox" (inn, flight, bank, auction,
  vendor, repair, trainer) to the nearest service; "/lp navi off" ends it and the route continues.
- The nearest service is now chosen by way cost (detour of the zone), not by straight line.
- Fix: the English word "repair" was not recognised by /lp find.
- Test routine: new test T314.

## 3.12.53
- Roads for Classic Era too (ST-5): a road network for the base world (Kalimdor, Eastern Kingdoms), read with our own tool from
  the Anniversary client (same world, 93–96 % of its roads match WoW Forever). LevelPilot loads the roads of its own game
  version and frees the other. Note: LevelPilot itself does not run on Classic Era yet (comes with LW-5).
- The diagnostic log names the version: "STRASSEN (Forever) …".

## 3.12.52
- Correction to 3.12.51: the detour factor per zone is now measured on KNOWN ways (walked ways, starting network, roads). In
  3.12.51 it was measured on the way search's own route, which goes straight across open land – about 1.0, while players'
  walked ways are about 1.5 times the straight line (measured on 5445 pairs of the submitted ways). Pairs are now taken
  around each other (300–2000 yards), so even large zones get enough pairs. Until measured: 1.25 as before.

## 3.12.51
- Route planning with real way costs instead of straight lines (LW-1): LevelPilot measures for each zone how much longer the
  way search's route is than the straight line (roads, walked ways, terrain; median of up to 12 pairs, in the background,
  1.0–1.8, until measured 1.25). Order of steps, focus zone, the speedrun time factor and the flight decision use it. Zones
  with mountains and gorges (Thousand Needles, Alterac) no longer look closer than they are. The diagnostic log shows
  "UMWEG je Zone …".
- Test routine: new test T313.

## 3.12.50
- Roads from the game files (WoW Forever): LevelPilot now knows the roads of Kalimdor and the Eastern Kingdoms (made from the
  ground textures of the Forever client with our own tool, about 200 000 yards). The way search follows them like walked
  ways; they are loaded in small portions only for the continent you are on. Not saved, not shared. The diagnostic log shows
  "STRASSEN …".
- Test routine: new test T312.

## 3.12.49
- Flights by time instead of distance (LW-3): LevelPilot compares walking time with the time via flight master (walk there, talk,
  flight, walk on) and only flies when it is at least 30 seconds faster. Flight time comes from your own measured flights (from 3
  flights, other players' flights help), otherwise an estimate. Ground speed: your measured mount speed, otherwise on foot.
  The diagnostic log shows the last comparison ("REISE …").
- Test routine: new test T311.

## 3.12.48
- Measurement of the walking routes (basis for better routes, LW-6): per step the straight-line distance, the distance
  actually walked until arrival, time on the way and time at the target, the kind of path (way network / terrain / straight
  line / unknown); replans with a change of direction; idle time without a target; XP per hour for each level. Only sums per
  zone and per level are kept (per character). AFK, death, flights, teleports, the virtual journey and the test routine do
  not count. Result: "LAUFWEG" and "EP/h je Level" lines in the diagnostic log (/lp protokoll).
- Test routine: new test T310.
- Shared file GoldSentinelDev.lua (version 2, checksums instead of names) is now included: the in-game checklist (test mode)
  works without other GoldSentinel addons.

## 3.12.47
- Test mode only (invisible for players): in-game checklist /lp checklist (also /lp prüfliste) with the shared GoldSentinel
  component GoldSentinelPruefliste. 14 open "check in the client" points in a sensible order; the window always shows what to
  do and what you must see for the next open point. Most points notice by themselves when they are done (hint shown,
  plus sign set at a merchant, measurement taken); only "look and confirm" needs "OK" / "Not OK". Test runs and the virtual
  journey never mark anything. The result is included in the diagnostic log.
- Test routine: new test T309.

## 3.12.46
- New command /lp wegmessung: a guided way measurement for the test tool GSWegMess (Undercity auction house -> Magic Quarter
  and back, Undercity lifts, Thunder Bluff lift, a cave). A small window says which way to walk and when to mark; "Mark & next"
  writes a note into GSWegMess, the arrow points to known targets. GSWegMess itself is unchanged; without it LevelPilot says
  where to get it.
- Test routine: new test T308.

## 3.12.45
- New command /lp clienttest: a guided test of the latest features in the game (level info, starting way network, language-
  independent levels, rested hint, weapon skill, weapon master, farmed-out spot, merchant upgrades, talent suggestion,
  interface for other addons). Everything measurable in the game is checked automatically; a small window only asks where you
  have to look (one sentence, buttons "OK" / "Not OK" / "Skip"). Result: one line per point in /lp diag.
- Test routine: new test T307.

## 3.12.44
- New interface for other addons: LevelPilotAPI.NavigateTo(uiMapID, x, y, title) – LevelPilot guides you to that place like
  to its own targets (arrow, path, flights). ProfessionSentinel uses it for "next trainer – show the way". See README.
- Test routine: new test T306.

## 3.12.43
- Talent suggestion: the hint "talent point(s) free" now also names the next point of LevelPilot's own leveling build for
  your class, with one sentence why (e.g. "Heroic Strike costs less rage, so you can use it more often"). One build per
  class (51 points), checked against the WoW Forever talent trees; weapon-dependent talents follow your equipped weapon.
  Only a suggestion – nothing is learned automatically; the talent window stays untouched. Reasons in German and English.
- Test routine: new test T305.

## 3.12.42
- Merchant window: wares that would be an upgrade for your class get a plus sign in the top left corner (same rating as
  "Possible upgrade": class stat weights, armour type, level, usable). Only marking – nothing is bought. Buy tab only,
  follows page changes. Switch: Center » Assistant » "Equipment upgrades".
- Test routine: new test T304.

## 3.12.41
- Farmed-out spot: if you stand at the target of a kill or collect quest for 3 minutes without any progress (not AFK),
  the assistant asks whether the spot is farmed out and shows how far the next spot is. "Other spot" marks this spot as
  empty for 20 minutes and LevelPilot plans the next one. Nothing happens on its own – you decide. Switch: Center »
  Assistant » "Farmed-out spot".
- Test routine: new test T303.

## 3.12.40
- New assistant hint: if a weapon (green or better) of a type you have not learned yet is in your bags, LevelPilot names
  the weapon master who teaches it (own faction, nearest first) with "Guide me" – about 10 silver (polearms from level 20,
  about 1 gold). Only weapon types your class can learn on WoW Forever; switch: Center » Assistant » "Weapon skill".
- Test routine: new test T302.

## 3.12.39
- Two new assistant hints (wishes of players from comparable leveling guides; both can be switched off under
  Center » Assistant):
  - Rested bonus: if you go AFK outside an inn or capital, LevelPilot suggests logging out in an inn – rested bonus grows
    4× as fast there (double XP from monsters). Includes "Guide me" to the nearest inn.
  - Weapon skill: if the skill of your equipped weapon is 25 or more below its maximum (e.g. a new quest weapon), you
    miss more often – LevelPilot tells you so you can practise on easier enemies.
- Test routine: new tests T300 and T301.

## 3.12.38
- Preparation for guidance across floors (switched off until measured): the level of a way point is now stored in a
  language-independent way. Sub zone names (e.g. "Magieviertel", "Das Magieviertel", "Magic Quarter") are mapped to one key
  via a small table of all 11 client languages (public area tables, branch WoW Forever; only cities with several levels).
  Already stored level information is converted when loading. Hints still show the name in your game language.
- Test routine: new test T299.

## 3.12.37
- Starting way network for Mulgore, The Barrens and Thunder Bluff: LevelPilot now ships its own coordinate lists of
  walked ways (from way data submitted by LevelPilot players, without names; no game files, no map images). New
  characters get routes along real paths there right away instead of only straight lines. Ways you walk yourself are
  used together with it; the starting network is never saved and never shared. Only on the WoW Forever client (the
  maps of Classic Era/TBC differ); loaded in small portions after login (no stutter).
- Test routine: new test T298 (starting way network loaded, nothing saved).

## 3.12.36
- Preparation for better guidance in cities with several floors and in caves (Undercity, Thunder Bluff): while you walk,
  LevelPilot now also stores on which level a way point lies (map, indoors/outdoors and sub zone, e.g. "Magic Quarter").
  Each level name is stored only once; the way point only keeps its number, so the saved data stays small. The shared way
  data (export) contains this level information per point.
- The guidance itself is unchanged: the new level separation, lifts (with waiting time), drop-down spots (only downwards)
  and hints like "Take the lift (to …)" are built in but switched off until measurements in the game confirm that the
  sub zone really separates the levels.
- GoldSentinelMarkt.lua version 7 (unchanged from the shared folder).
- Test routine: new test T297 (level information is stored, guidance unchanged).

## 3.12.35
- Undercity: no more "path unknown" when a walked path to the target exists. In the multi-level city the path search took
  short straight lines across levels – such paths count as unknown. If the normal search only finds such a path,
  LevelPilot now searches a path over walked and shared ways only and uses it (e.g. from the auction house to Bethor
  Iceshard in the Magic Quarter). Applies everywhere, not only in Undercity.
- Test routine: new test T296 (with your own way network); offline routine: check with the submitted Undercity way data.

## 3.12.34
- No more stutter every 5 minutes: LevelPilot asked the game every 5 minutes to measure the memory of ALL addons
  (UpdateAddOnMemoryUsage) – with many addons this can take hundreds of milliseconds. The 5-minute timer now only reads
  the total Lua memory (cheap). LevelPilot's own memory is measured only when you open the error log; the diagnosis shows
  how long that measurement took.
- Diagnosis: "SPEICHER Lua gesamt (all addons, every 5 min)" and "SPEICHER LevelPilot (measured when opening the log)";
  each session now shows total Lua memory. The assistant check (every 30 s) now appears in the time measurement.
- Clicking "replan" right after a level up or language change calculates in small portions instead of all at once
  (before up to about 26 ms in one frame).
- GoldSentinelMarkt.lua version 6 (unchanged from the shared folder).
- Test routine: new tests T294 (5-minute timer without the expensive measurement) and T295 (click with cold caches).

## 3.12.33
- Correct time measurement: when a calculation runs in small portions over several frames, the waiting time in between no
  longer counts as calculation time. That caused "quest evaluation 495 ms" after login – only a few ms were calculated.
  In the diagnosis a peak above 16 ms is now followed by "(über 16 ms)" (red where colours are shown).
- Quest evaluation on level up and after switching "WoW Forever server" or "plan dungeon quests" now also runs in portions
  instead of all at once.
- Compact mode (one row): if there are quests to turn in later, "+n turn in later" appears in green after the step; the
  tooltip shows the quest names.
- The line "MESSAGES: …" in diagnosis and test report appears in the selected language.
- Test routine: new tests T292 (time measurement with portions, quest evaluation level 31) and T293 (compact mode).

## 3.12.32
- Route planning much faster: checking whether the way to a task leads through areas with too strong enemies took almost
  the whole planning time. It now checks the same points without detours and stops as soon as the limit is reached. In
  Elwynn Forest (Alliance, level 10) one planning run drops from about 26 ms to about 4 ms – no more stutter.
- Test routine: new test T291 (fast check = previous check on 2000 routes); T150 now also checks the peak (below 33 ms).

## 3.12.31
- New switch "Messages" (center → Settings, top). Off = LevelPilot no longer reports anything on its own: no chat hints,
  nothing in the middle of the screen, no sound, no pop-ups, no assistant hints (e.g. "you can learn First Aid here",
  trainer, mount, open turn-ins, "Where was I?", summary on logout, quest item nearby). Answers to your own commands and
  clicks (e.g. /lp diag, /lp find, "Not possible in combat.") still appear. The guide with steps, arrow and path stays.
  Default: on.
- All messages go through one single gate; test report and diagnosis show "MELDUNGEN: on/off · suppressed n · leaked n".
- GoldSentinelMarkt.lua version 4 (unchanged from the shared folder).
- Test routine: new test T290 ("Messages" switch).

## 3.12.30
- Completed quests stay visible: when the turn-in is far away (outside the zone you are questing in), the list shows
  "Turn in later: quest (zone)" in the last visible row, also inside dungeons. The rule check counts it as a turn-in
  step (before, the diagnosis reported "quest … complete but no turn-in step"). Skipping or postponing does not remove it.
- Diagnosis (/lp diag): memory after login, current and peak, plus the memory each module allocated since login and the
  size of the caches. Also per session in the session list.
- GoldSentinelMarkt.lua version 3 (unchanged from the shared folder).
- Test routine: new tests T288 (completed quest with distant turn-in) and T289 (memory measurement). T220 wrongly reported
  an ERROR on Alliance characters (Horde quest) and is now "not testable" there.
- Offline test routine for the review in the repo (berichte/LevelPilot/offline/run_offline.py).

## 3.12.29
- GoldSentinelMarkt.lua version 2 (unchanged from the shared folder): when AHSentinel is loaded, the file no longer reads
  its full scans a second time – no more stutter during the full scan and in the sniper. Sold-out items in the export.
- Test routine: T283 also saves and restores "another addon is passing on a scan" (feedUntil) and no longer depends on
  whether AHSentinel is loaded; new regression test T287.

## 3.12.28
Market data network (shared with all GoldSentinel addons).
- New: GoldSentinelMarkt.lua (unchanged from the shared folder). When any addon makes a full auction house scan,
  LevelPilot silently reads along (lowest unit price, quantity, number of auctions per item) and shares the prices
  anonymously with guild and network. No names, no prompt, LevelPilot never starts a scan itself. Runs only once per
  client, however many GoldSentinel addons are installed. Without the auction house API (Era, TBC) it stays off.
- Switch "Share market data (anonymous, prices only)" in the center under Sharing, on by default.
- Test report and diagnosis: line "MARKT-NETZ: version, on/off, scans read, sent/received, storage".
- Center: the switch "Command list while typing /lp" sat on the same spot as "Settings only for this character" and
  now has its own row.
- Test routine: new cases T282–T286 (with/without the file, switch off, no auction house API, report line, switch spots).
- Correction for 3.12.26: TU1–TU8 are done. The offline routine (TU9) follows in its own version.

## 3.12.27
Command list while typing.
- Type /lp (or /levelpilot) in the chat: above the input field the list of ALL LevelPilot commands appears with a
  short description in your language. Each further letter filters ("/lp w" -> weg, wege …); most used commands on top.
- Click or Tab selects an entry, Enter executes it. The chat input is never written to. Switch off in the center
  (Display: "Command list while typing /lp").
- The slash handler and the list use one command table – every command the handler knows is in the list; developer
  commands only for the developer.
- Test routine: new cases T276–T281 (T-BL1–T-BL6).

## 3.12.26
Comprehensive tests (TU1–TU8; TU9 offline routine follows) so that errors found in the game do not come back.
- TU1 situations: every race and class of your faction with levels 1, 12, 30 and 58 runs through quest availability
  (faction, class, race, level, start area); quest states done / in the log / failed / abandoned (T269).
- TU2 flows like a player: /reload on the way, switching plan mode, death -> spirit healer -> continue, automatic
  turn-in with one or several rewards; at the end no Lua error and nothing real executed (T270).
- TU3 defaults: every option as installed, list in the test report (T271).
- TU4 basic rules with 1000 random cases (fixed seed, in portions): no way over terrain the terrain map marks as not
  walkable, never an automatic reward with several choices, time estimates 0–6 h, no protected action in combat (T272).
- TU5 real data (read only): every 10 minutes the quest log and measured values are checked against the plan;
  violations go into the diagnosis log as "GRUNDREGEL VERLETZT …" (T274).
- TU6 regressions: every finding since 1 November has a lasting test; report line "Regressionen: n von m vorhanden"
  (T273).
- TU7 game variants: Forever, Era, TBC, German and English, window at 80 % scale (T275).
- TU8: the test report shows one line per area TU1–TU7.

## 3.12.25
- Emergency brake of the route planning: for planning in background portions only the longest portion counts (over
  50 ms), not the total – a long planning in small portions no longer pauses the route. A planning requested during
  a pause is done once after the pause instead of being dropped.
- The step limit of the short path check in the planning applies only to that search (before: a global value that
  could stay at 1200 after an aborted planning – long path searches then found no way until /reload).
- LANGSAM entries of the emergency brake are no longer removed by the planning's own slow entries.
- Way network: if 3.12.23 already split gaps of 25–80 yards, these pieces are found once (points exactly on a line in
  equal distances) and marked as uncertain; nothing is deleted.
- Background work: a portion may start a new job safely.
- Diagnosis log: calls dropped during a pause are counted ("ZEIT in Pausen verworfen").
- Test routine: new cases T266–T268, T262 extended.

## 3.12.24
Fix: the game could freeze after logging in on a character with a large recorded way network (CPU over 100 %).
- Cause: the path search connected every step of the search with hundreds of nearby way points by a straight line
  and checked each line against the terrain map. With the denser way network (points every 12–25 yards, split old
  pieces in 3.12.23) one search took several hundred milliseconds. It ran again after each planning, off the path
  every 0.5 s, and every received quest from guild mates also emptied the search cache.
- The path search now takes at most two way points per 100-yard cell for straight lines and keeps them; received quests
  no longer empty the cache (the terrain map comes from the data pack).
- Heavy work runs in portions in the background (at most 4 ms per frame): path search, terrain guidance, automatic
  route planning and the one-time way network fix-up. A click of yours still plans at once.
- Emergency brake: if a part needs more than 50 ms at once or more than 1 s within 5 s, it pauses for 60 s – one chat
  line and a LANGSAM entry in the diagnosis log (part, time, number of targets and way points, zone).
- Off the path, LevelPilot waits longer after an expensive search (up to 10 s) instead of searching every 0.5 s.
- Planning checks the first path with a short search only.
- Diagnosis log: computing time per part (route, path search, way network, network receive, quests, display …), the
  first 60 s after logging in separately. On logout the log is written as GSDIAG1 into the saved variables (for the
  test reports, no names; LevelPilotDB.diagSend = false switches it off).
- Way network: only pieces over 80 yards are split (25–80 yards may be a gap between two recordings – marked as
  uncertain until walked again); no orphaned point if splitting fails.
- Test routine: new cases T261–T265 (T-LAG1–T-LAG4), T148 measures the portions.

## 3.12.23
- Zone requests and partner-finder messages without the sender checksum (LevelPilot up to 3.12.21) are no longer
  accepted – a relaying player could bring them into his guild under his own name. Players with 3.12.21 get no zone
  answers and no partner hints from others until they update.
- Way recording: positions every 0.5 s; a gap of more than 25 yards between two positions (lag, teleport, very fast)
  splits the way instead of storing it as a straight line.
- Once after the update, long straight way pieces from older versions are split into pieces of at most 25 yards (on
  the walked line), then loose ends are joined again.
- Test routine: new cases T259, T260; T254 extended.

## 3.12.22
- Sharing settings are kept exactly: guild, group and whisper network only when switched on. The network goes along
  only when guild and group are both on (GoldSentinelSync has no "network only" yet).
- Zone requests and the elite partner finder go only to guild and group, and carry a checksum of the sender's name.
  Messages passed on through the network (sender = the player who passed it on) are ignored – no answer to the wrong
  player, no wrong name in the partner hint.
- Zone replies have at most 25 messages (the rest with the next request) and are only sent while the shared send queue
  of all GoldSentinel addons is almost empty.
- Recordings that could not be sent (no way) are sent again later in the same session.
- Test routine: uses its own empty send queues; messages of other addons are no longer sent during the test.
- Diagnosis log: no "step active for 25 min" while you stand in a capital (bank, auction house, mail) or are in a
  dungeon; no focus warning while the current step is in your zone; no zone warning in caves without their own map.
- Test routine: new cases T254–T258, T243 extended.

## 3.12.21
Data exchange over the shared GoldSentinelSync (version 2) instead of an own chat channel.
- In WoW Forever addon messages in own chat channels never arrive. LevelPilot no longer joins the channel
  "LevelPilotNet" and leaves it once (frees a channel slot).
- Sent over guild, group/raid and the new whisper network of GoldSentinelSync 2 (reaches all players with LevelPilot
  across guilds): recorded quests, ways, caves, flights, zone requests and hello. Only guild and group: loot and mob
  values (frequent) and the group mode (level, step, quests – group only). The elite partner finder (if switched on)
  goes into the network as before over the channel. Zone replies go by whisper to the asking player.
- Older LevelPilot versions of other players are still understood (same message prefix).
- Known players of the network are kept over /reload (LevelPilotDB.gsSync, names and times only, local only).
  Former sender names in the saved data are now stored as checksums only.
- /lp sync test: "N replies (guild a, group b)". Diagnosis log: SYNC/NETZ lines (no names), NOT_ALLOWED_IN_CHANNEL counted.
- Center, sharing tab: "Through the whisper network" instead of the addon channel, players online instead of
  channel status.
- GoldSentinelTest 2: share error reports with the developer (only with consent, /gstest).
- Test routine: new cases T242–T253; T92, T108, T111, T169 adapted.

## 3.12.20
- Shared file GoldSentinelGame.lua version 3 (comments only, no player names in the examples).
- No real character names in LevelPilot's own files: tests use "Testa Beispiel", the developer character is only
  stored as a checksum.

## 3.12.19
- More game queries are checked for protected values before use: facing (arrow, minimap), indoors (caves, map
  radius), resting, movement speed and the player's and pet's level. A protected level falls back to the last
  readable level.
- Test routine: new case T241. T128 now checks old saved data without your own measurements (before it showed
  "measured true" in the game). Intentional test errors of T158–T163 no longer raise the error counter in the
  report.

## 3.12.18
- LevelPilot's own tooltips no longer cover its buttons (Support, Center, Normal, Skip …). They appear next to the
  window the button belongs to – on the right, if there is no room on the left, otherwise below – at the height of
  the button. Applies to the guide window, step list, assistant line, size grip, action bar and arrow.
- Test routine: new case T240.

## 3.12.17
Better way data (from the evaluation of the submitted way data).
- New way pieces are joined to the existing network: if the start, end or a crossing lies within 10 yards of a known
  way, that way is split there and connected. Existing loose ends are joined once after the update (nothing is lost).
- Way points are stored at least every 25 yards and at every change of direction over 30° (before, straight pieces
  of several hundred yards had no point in between).
- No ways are recorded or sent on the continent map (flight, ship).
- Way data (/lp wege, GSWEGE1): quest giver positions old/new both as [x, y], "oldMap" if the data pack has the NPC on
  another map, the data pack position is the nearest one on the same map (not the first), "nopack" for NPCs without a
  position in the data pack.
- Data pack 1.6.1: positions of Gordo (10666, Tirisfal Glades) and Bluff Runner Windstrider (10881, Thunder Bluff)
  corrected for WoW Forever.
- Test routine: new cases T235–T239.

## 3.12.16
Grey items are sold automatically, without a button.
- When a vendor window opens, LevelPilot sells all grey items with a sell value on its own (out of combat, one item
  every 0.2 s, stops when the vendor window closes or combat begins). Locked items and items needed for a quest
  stay. Afterwards one chat line: "Sold N grey items for …" – no line if nothing was sold.
- Option "Sell grey items at vendors" (on by default) in the center, or /lp grau (/lp grey) to toggle.
- LevelPilot puts nothing on or next to the vendor window. Note: the button "Sell: 0 items (0)" at the vendor
  window comes from AHSentinel, not from LevelPilot.
- Test routine: new cases T230–T234 (option on/off, only quality 0, stop on MERCHANT_CLOSED, nothing in combat,
  only logged during the test). Cases that cannot be checked in the current situation (e.g. level 60, no data pack,
  no target) now count as "skipped" with a reason instead of "OK".

## 3.12.15
Test routine checks the interface (from the GoldSentinel template).
- New file UICheck.lua: all LevelPilot windows are registered (guide window, center, backup, group panel, virtual
  playthrough, donation, step menu, action bar, arrow).
- New area K in /lp testroutine (T224–T229): own tooltips cover no buttons, no overlap with Blizzard or other
  GoldSentinel windows, windows fully on screen, button labels not cut off, values plausible, no error loops
  (no Lua error more than 10 times per session).
- Plausibility: the number of finished quests in the quest log matches the number of "Turn in" steps in the list;
  quest count, level and map position are checked too. T224–T227 run only in the real client.

## 3.12.14
- Fixed: Lua error "attempt to perform boolean test on a secret boolean value" (Session.lua, hundreds of times on WoW
  Forever). UnitIsAFK sometimes returns a protected value there; then only LevelPilot's own idle timer counts.
- All other queries returning a truth or number value (flight, dead/ghost, combat, vehicle, unit exists, player
  position, XP and rested bonus) are checked for protected values before use.
- Test routine: new case T223 (protected truth values from UnitIsAFK & co.).

## 3.12.13
Exception during the pause (decided by the user): finish the zone first.
- If you still have open quests in the zone you are in (including its capital), planning stays there. Only then does
  the route continue to the next zone, collected. Turn-ins in another zone are no longer a reason to leave the zone.
  Quests that are too dangerous for your level or unreachable are the exception.
- Test routine: new case T222 (open quests in Mulgore before turn-ins in the Barrens).

## 3.12.12
Accurate ways, step 4 (exception during the pause, decided by the user): way data for submission.
- New command /lp wege (or /lp wege <zone>): shows the learned ways per zone as coordinate lists (origin own/shared,
  how often walked), blocked stretches, corrected quest giver positions and STUCK events of the last 7 days as
  selectable text – without player, character or guild names.
- Automatic: on logout and /reload LevelPilot puts new and changed way data (tag GSWEGE1, at most 200 KB) into its
  saved data; the RaidMaster uploader can pick it up like the test reports. Can be switched off in the control
  center under Sharing ("Send way data automatically", on by default).
- Test routine: new case T221 (text, GSWEGE1, only new data, can be switched off, no names).

## 3.12.11
Accurate ways, step 3 (exception during the pause, decided by the user): real positions of quest givers.
- When you talk to a quest giver (accepting, turning in, gossip), LevelPilot remembers its real position and uses it
  instead of the coordinates from the data package – wrong targets in changed Forever zones are corrected this way.
  The positions are backed up in the character like all collected data.
- Learning ways (every walked stretch), sharing ways and caves with group and guild, and flights for long distances
  already existed and stay unchanged.
- Test routine: new case T220 (real position of a quest giver, protected values).

## 3.12.10
Accurate ways, step 2 (exception during the pause, decided by the user): learning from dead ends.
- "STUCK" now only counts pure walking time: the clock only runs while you really move. Standing pauses it (it does
  not start anything); AFK, dead/ghost, combat, flight, open merchant, mail, auction, profession and trainer windows,
  loading screens and /reload never count. Only after 4 minutes of walking without getting closer is a way STUCK.
- On STUCK, LevelPilot remembers the stretch as blocked and looks for another way; if none is known, only the arrow
  shows the direction.
- Test routine: new case T219 (10 min AFK, 2 min standing and 1 min walking, 4 min in a circle, blocked edge).

## 3.12.9
Accurate ways, step 1 (exception during the pause, decided by the user): way network instead of straight lines.
- The route is only drawn along known ways: walked or shared stretches, zone transitions and caves. Only the first
  and the last short piece (up to 40 yards) may be a straight line.
- If no way is known, LevelPilot no longer draws a line – the arrow shows the direction to the target with the note
  "unknown way". Better no line than a wrong one (never across mountains again).
- The way network grows from walked ways; own coordinate lists for Mulgore, the Barrens and Thunder Bluff follow
  once enough has been recorded.
- Test routine: new case T218 (Mulgore case 1 and 2, target without network, Thunder Bluff with elevator).

## 3.12.8
Exception during the pause (decided by the user): route in Thunder Bluff and Mulgore.
- Capital cities belong to their zone for planning (Thunder Bluff – Mulgore, Orgrimmar – Durotar, Undercity –
  Tirisfal, Stormwind – Elwynn, Ironforge – Dun Morogh, Darnassus – Teldrassil). On WoW Forever the cities have no
  parent zone, so the focus often was on the wrong map. Tasks on both maps are ordered by the way.
- The focus follows the player: if the old focus zone is far behind you, it switches to the zone you are in.
- The focus guard in the error log replans by itself instead of writing the message again and again; it reports only
  once if that does not help.
- Priority targets (trainer, profession, vendor …) never come before quests ready to turn in nearby. If you do not
  get closer to a priority target for minutes (e.g. a trainer up in Thunder Bluff), LevelPilot only shows the arrow.
- Test routine: new case T217 (Thunder Bluff and Mulgore, focus guard, priority target after nearby turn-ins).

## 3.12.7
Exception during the pause (decided by the user): route in Mulgore and a Lua error in the error log.
- Quests ready to turn in nearby (up to 900 yards) now always come first – before flight masters, binding, hearthstone
  and distant targets; the nearest first. A turn-in right nearby is planned even if the danger map rates the place as
  too dangerous (you are already there).
- Recorded places (own, start database, from other players) only take precedence over the data package if they match
  it; if they are far off, LevelPilot uses the places from the data package. Recorded vendors and innkeepers without
  walkable ground around them (e.g. in the middle of the mountains) are no longer offered.
- If a part of the way is a straight line over mostly unknown terrain (mountains, rocks), LevelPilot no longer draws
  a line; the arrow then points straight towards the target.
- Error log: no more Lua error caused by protected values (movement/speed) on WoW Forever ("attempt to compare a
  secret number value").
- Test routine: new cases T214 (nearby turn-ins first, Mulgore case 1 and 2), T215 (no target and no line in the
  mountains) and T216 (error log with protected values).

## 3.12.6
Open points of the review of 3 November 2026 (re-check of 3.12.5).
- More accurate drop rates on WoW Forever: a kill now counts at the monster XP message (dead target), even if the
  corpse has no loot – the rate is no longer too high. Pieces count only when the item really arrives in your bags
  (loot message); anything left behind with full bags counts only when you pick it up later. Each corpse counts once,
  protected values are never used.
- Profession and class hints: if the first spell query answers "not known", LevelPilot asks the others as well
  (IsPlayerSpell) – no more wrong hint about First Aid/Cooking.
- Reward hint: if the item info is not loaded yet when the reward opens, LevelPilot checks again after one second.
- Damaged saved entries (wrong type) are skipped or replaced on load instead of causing Lua errors; valid collected
  data stays unchanged.
- Protected values: XP display, time to 60, group status and the rested hint never calculate with protected XP;
  tooltips, measurement and enemy lines check protected units.
- Errors that were caught silently so far (virtual journey, backup at logout, protocol checks) are now reported to the
  GoldSentinel review. The diagnosis shows module start errors.
- Planning time of the virtual journey only counts computing time (no longer the pauses between frames).
- Test routine (test mode): all test cases automated (96 placeholders before), "not automated" count in the report,
  new client cases T171, T195 and T213 (profession spells), long journeys with /lp testroutine reise.
  The copy window says "It is also reported automatically." (all languages).

## 3.12.5
Defaults decided by the user, open points of the review of 3 November 2026 and the new test routine.
- Defaults: automatic repair and auto-flight are on again by default; restocking at merchants and equipping quest
  rewards stay off. Existing settings are not changed – if you installed 3.12.4 fresh, switch repair and auto-flight
  on in the control center (Comfort).
- New one-time hints: at the first merchant where LevelPilot would restock (restocking off), and at the first quest
  reward that is an upgrade (equipping off), LevelPilot shows once that the option exists, with "Settings" and
  "Remind me later" (at the earliest 3 levels later). Nothing is bought, chosen or equipped; never in combat, never
  once the option is on. The "Where was I?" greeting shows a one-time tip as well.
- Drop rates on WoW Forever: reopening the same corpse (bag full, window closed) no longer counts kills or pieces
  twice; a window with a protected loot link is skipped instead of counting a kill without loot; pickpocketing (the
  target is still alive) no longer counts as a kill.
- Class hints: when no spell function answers, LevelPilot no longer claims that First Aid/Cooking is missing.
- Detection: when GoldSentinelGame reports "not modern", LevelPilot follows it (own detection only without it).
- All timers run protected via LP:Ticker (replanning, assistant, social, data exchange, journey).
- Missing translation of the protocol entry "data package outdated" added (all languages).
- Robustness: missing game functions (repair cost, durability, ammo count, greeting quests, item info) no longer
  cause Lua errors.
- Actions with real consequences (buying, selling, repairing, equipping, quests, flights, sending, inviting, reload)
  run through one place (LP.Act); in normal play nothing changes.
- New test routine for the developer (test mode): /lp testroutine [a–j] and the button "Test everything"; sandbox
  for your data, actions are only recorded. /lp test (for everyone) now writes a machine-readable report.
  Reports and Lua errors are stored for the GoldSentinel review (GoldSentinelTest.lua, no names).

## 3.12.4
The rest of the strict review of 2 November 2026.
- Drop rates on WoW Forever: without a combat log LevelPilot now counts while looting – every looted corpse of a
  monster that drops a needed quest item counts as a kill, the pieces come straight from the loot window
  (GetLootSourceInfo, outside combat, protected values left out). Corpses without loot are not opened, so the rate
  may come out slightly high. Classic clients keep the old way (combat log and loot message).
- Actions with real consequences are off by default for new players: buying supplies at merchants, automatic
  repair, automatic flight and equipping quest rewards. Existing settings stay as they are; switch them on in the
  centre.

## 3.12.3
From the strict review of 2 November 2026 – ready for the WoW Forever launch.
- Fixed: /lp reise bericht gave a Lua error (missing L in Core.lua).
- Protected values of the modern client ("secret values") are checked before use: hearthstone cooldown (shows
  the last readable value), quest giver and merchant names, object tooltips, loot messages, addon messages
  (data exchange and group mode).
- Fallbacks for the modern client: ChatFrameUtil.OpenChat (group finder text), removing the data channel from chat
  windows via the chat frame, UnitQuestTrivialLevelRange (green quest range), C_SpellBook.IsSpellKnown (class
  hints; without any of these functions no hint instead of a wrong one). The self-test lists game functions that
  are not available.
- WoW Forever is recognised via GoldSentinelGame (client 1.60.x); the own detection stays as fallback, the setting
  still has priority. Corrected comment: Forever is not a 1.15.x client.
- The data package must be at least 1.6.0; an older one still works but shows a hint once.
- Performance: away from the path the route is recalculated at most every 0.5 s, never during flights.
- Robustness: all timers run protected (an error no longer repeats every second), protocol entries with damaged
  fields no longer stop the error log, garbage collection step protected, quest-completed check unified.

## 3.12.2
Time model adjusted to WoW Forever (from the review of 2 November 2026).
- XP per kill by level difference instead of always the full value: same level 45 + 5 × level, higher +5 % per
  level (at most 4), lower × (1 − difference / ZD), grey 0 (Classic formula). One function for planning and the
  virtual journey (monsters on the way with their average level, quest kills with the level of the quest's
  enemies).
- WoW Forever: green monsters (3 or more levels below you) give less XP than in Classic – estimate 0.85 until
  measured.
- Dungeon values for WoW Forever (provisional, status 2.11.2026): mob XP 36 % (September cut, +20 % on 8 October),
  dungeon quest XP ×1.5 (bonus share cut by 50 % on 1 October). The setting "dungeon mob XP %" still has priority.
- Real XP per kill is measured while playing (only via your XP, never the chat text): per level difference against
  the formula, separately inside dungeons. Not counted with rested XP, in a group, or when the enemy's level is
  unknown or protected. From 20 measurements per step the measured value replaces the estimate.
  The status line shows "XP per kill: measured n · green x %".
- WoW Forever: group hints note that a much higher group member can cause everyone to get 0 XP.
- "Time to 60" says that it comes from your XP of the last hour and applies to every mode.
- Virtual journey (test mode): "both modes" runs 1–60 once normal and once speedrun and shows both times; the report
  says whether kills per minute, XP per kill and dungeon factors are measured, set or estimated.

## 3.12.1
Test mode for the developer only, and ready for the modern WoW Forever client.
- Test mode (virtual journey, self-test with journey, /lp debug) is only unlocked for the developer (recognised by
  Battle.net account; character list as fallback). /lp reise stop always works. Self-test, error log and
  /lp messen stay available for everyone.
- GoldSentinelGame.lua (shared game version detection of all GoldSentinel addons) included unchanged; /lp diag,
  /lp messen and the self-test show the game version. Protected values of the modern client ("secret values",
  e.g. GUID, level or name of units in combat) are checked before use: nameplates, target, measurement, quest giver.
- Modern client: the combat log is closed to addons there, so LevelPilot no longer registers for it on WoW Forever
  (drop rates are then not counted from kills). Merchant offers, item count, links and purchases via C_MerchantFrame when the old functions are missing, guild summary
  via C_ChatInfo.SendChatMessage when available, item names via C_Item.
- Own character recognised via GoldSentinelGame.SameName (WoW Forever: first and last name).

## 3.12.0
Fewer zone changes, faster speedrun.
- Staying in the zone: the focus zone is only left when almost nothing is left to do there – turn-ins count fully
  for that (otherwise you come back later just for them). A zone you just left is only chosen again when a lot
  of new work waits there. Larger quest packages are preferred.
- No long trips for one small task: a zone with little to do further than 1500 yards away is skipped; instead you
  defeat monsters nearby for a short while until the next level brings new quests. Fewer zone changes
  (in the virtual journey about 90–110 instead of 130–180 up to level 60), less walking.
- Collecting turn-ins: a single turn-in far away (no quest giver and no other turn-in there, no follow-up quest)
  waits until you pass by or the quest log is nearly full.
- Hearthstone used more often: binding also at an inn up to 600 yards away (new zone's quest hub), used from
  1200 yards of way when the bind point is clearly closer to the target.
- Virtual journey 1–60 (test environment): speedrun 8–18 hours faster for most races; more grinding instead of
  long trips (about 16–31 hours). Mob rule targets 0, flights only via discovered flight points.
- Journey report: focus zone changes and returns to zones already visited.

## 3.11.0
Speedrun as fast as possible to 60, and a measurement routine for the test environment.
- Speedrun reworked: it goes straight for the next quests and only takes the monsters that lie on the way anyway
  and still give XP (not grey, at most 2 levels above you). Grinding only when no quest is left in reach.
  Quests are only dropped when they are clearly slow; quests in a chain and quests at a hub with 3 or more
  quests stay in (one trip covers several). Low quests stay in at such a hub.
  Virtual journey 1–60: the speedrun is now faster than the normal route for every race (about 4–8 %);
  without the monsters on the way it would be 14–24 hours slower.
- New command /lp messen (/lp measure): reads everything that can be checked standing still and shows it as text to
  copy – position with map ID, danger map at your spot and the grinding spot, target and nameplates (real mob
  level against the data package, deviations marked), quest log with objectives and the planned mob level,
  the first 10 route steps, deferred quests (mob rule), flight points with their zone position, all zone maps
  with their bounds, hearthstone, learned values and level times. It only reads – nothing is changed or sent.
- Quest objectives are bundled: when objectives of several quests lie in the same area (within 300 yards), they
  are done in one pass – one search, kills of the same monsters count for every matching quest. The guide shows
  "Do at the same time: …" at the step; the speedrun keeps such quests (one trip covers several). Elite objectives
  and objectives with monsters 3 or more levels above you are never bundled.
- Drop rates are learned while you play: kills of the monsters that drop a quest item (your hits or your pet's)
  against the items you loot, and the amount the quest needs. From 10 kills on, planning uses the real rate;
  before that an estimate (longer when the droppers have few spawn points). The speedrun skips quests whose items
  drop clearly rarely ("items drop rarely").
- Real mob levels: LevelPilot notes monsters whose level on WoW Forever is higher than in the data package
  (nameplates and target). The danger map and the mob rule use the higher level – never a lower one.
- Exchange with other LevelPilot players now also carries drop rates, differing mob levels (used from two
  reports) and flight times – sums only, senders are stored as numbers, implausible values are rejected.
- The learned values are part of the character backup and are healed from it like quests and flight points.
- Upgrade hints ("Possible upgrade for your class … Equip") are no longer shown for items that are already in your
  bags when you log in or reload – only for items you get afterwards (loot, purchase, mail). The option stays on
  by default. Quest reward recommendations stay.
- Journey report: time split (walking, ship/zeppelin, flying, objectives, monsters on the way, grinding, dungeons)
  and the number of bundled objectives.
- Flight times are learned from real flights (straight line from take-off to landing against the measured time,
  used from 3 flights on; never during a journey). The virtual journey then uses the learned time.
- The journey report shows the learned flight time next to kills per minute and the quest XP factor.
- Flight points have to be discovered first (walk to the flight master and talk to him): flights are only planned
  between points this character has discovered. The virtual journey checks this for every flight and the report
  shows "flight points discovered: X · flights via undiscovered flight points: 0 (goal 0)".

## 3.10.1
From GoldSentinel's reference "real game world" (Horde, WoW Forever).
- Alliance ships (Rut'theran–Auberdine, Auberdine–Menethil, Menethil–Theramore) are no longer planned for the Horde
  – they go through Alliance harbours.
- Zeppelins and ships take realistic time: average waiting time (half a cycle) + ride + loading screen (zeppelin
  about 6.5 min, ship about 6 min); the virtual journey now counts that time instead of a flat 2.4 minutes.
- Flights take time by distance (about 32 yards/s, flight routes 30 % longer than the straight line, plus take-off
  and landing) instead of a flat 2 minutes.
- Towns of the other faction (elite guards or NPCs from level 45) are blocked areas for every level and appear in
  the report as "town of the other faction" instead of "mob 63/65". Other NPCs of that faction (e.g. the
  farmers of Hillsbrad, quest targets for the Horde) count with their own level.
- Safety: skipping a step during a journey never writes into the real character.

## 3.10.0
Learning from the real game, and a virtual journey closer to it.
- New module Calib.lua learns from your play (numbers only, stored account-wide, never during a journey):
  kills per minute of your class (time between monster XP messages, breaks over 2 minutes excluded; used from
  20 measurements on) and the WoW Forever quest XP factor (your real quest XP against the Classic values of the
  data package; median, used from 5 quests on). /lp diag and the journey report show both.
- One time model for planning and the virtual journey: a kill objective takes kills ÷ kills per minute plus search
  time (before: 150 s in planning, 420 s in the journey). Starting values per class (hunter 2.2, warrior 1.7 …).
  Monster XP while questing counts fully; ways inside a quest area count 60 % (shared with other quests there);
  the way to a quest giver is shared among all quests taken there.
- Grinding only as a short gap and at a good spot: the step leads to the nearest place with monsters of your
  level (from the danger map), about 20 minutes, then replanning. The journey walks there.
- Virtual journey: rested XP and the real hearthstone cooldown are taken over ("journey from here"); rested XP
  doubles monster XP until used up.
- Sandbox check: a fingerprint of your real data (quests, waypoints, path sections, flight points, vendors,
  caves, ignored and turned-in quests, backup) before and after every journey; any difference is an error in the
  report and the error log. Journeys are logged as "REISE", not as play sessions.
- Report: comparison with your real level times (per level and average deviation, goal below 15 %).
- Speedrun default is now "medium" (a saved "strict" from the old default is switched once; choosing "strict"
  again keeps it).

## 3.9.1
From the in-game test report of 3.9.0.
- Fixed (data loss): all recorded flight points could be lost. "Journey from here" did its heavy setup inside the
  chat command; when the game aborted it ("script ran too long") halfway through, Stop set the flight point list
  to nothing, and the next backup copied the empty list. Now: the real data is remembered first, restoring never
  sets anything to nil, an overlay left behind is recognised and unwrapped, and the heavy setup runs inside the
  journey in small slices.
- Fixed (data safety): the character backup is now its own copy (not the same tables as the account), and before
  every backup update missing entries are restored from the old backup (only adds, never deletes).
- Fixed: the virtual journey wrote quest progress positions into the real quest database (qdb[7734]).
- Right-click on a step opens a menu (postpone 30 min / ignore quest / cancel) instead of ignoring at once;
  /lp zurück brings back the last ignored quest.
- Text windows (report, log, self-test) no longer keep the keyboard: Enter ends input, so the next chat command
  works with the first Enter (/lp reise bericht seemed to do nothing).
- Danger map: NPCs of the other faction count only as a group (guards), without the elite bonus – single quest
  givers and battleground NPCs (e.g. "mob 63" at the Alterac pass, "mob 62" at the Rebel Camp) no longer count.
- Watch mode draws the trail of the last steps (thicker, accent colour); the journey report places dangerous
  spots in the zone that contains them (no more y > 100).
- Lua errors inside the journey also go to the error log (up to 5 per journey).
- Finer slices in planning and the danger map against "script ran too long".
- Compact guide shows one distance; the current step shows the path length everywhere (no more 725 vs 755).
- /lp lang without a code shows the current language and only displayable languages; /lp weg confirms the
  waypoint; "Nearest – inn: …" wording.
- Chinese/Korean: the en dash "–" is replaced (no boxes); shorter labels for Portuguese ("Troca") and Russian
  ("Авто"); switching languages back and forth stays clean.

## 3.9.0
From the in-game test report of 3.8.1.
- New mandatory rule: the route never leads to targets where mobs are 3 or more levels above you (elite counts
  2 levels higher). New module Danger.lua builds a danger map from the data package (highest hostile mob level
  per 100-yard cell; dungeon elites at entrances and rare mobs excluded). Quests are accepted and done only when
  their mobs are doable; target spots, quest givers, turn-ins and flight masters in dangerous areas are skipped.
  Paths through such areas cost 25× in the path search (detour if one is known); the real path to the first
  target is checked and the target deferred if it leads through danger. Applies to normal play, speedrun and the
  virtual journey (with the journey's level). The journey report has a new section "Mobs ≥ +3".
- Step order: the chain is shortened with 2-opt and or-opt (accept before complete before turn-in, quest log
  never overflows) – e.g. Ratchet steps now come after the targets around the Crossroads. Accepts and turn-ins
  no longer get a strong distance bonus.
- Fewer zone hops: passing through a zone or landing after a flight no longer moves the focus there; single
  turn-ins count less when choosing a zone; a continent change at most every 3 levels; donation and war effort
  quests ("A Donation of Wool", "The Horde Needs …") are no longer planned.
- Speedrun: grind rate 1.5 kills per minute (was 2.2, too optimistic) so more quests pay off; hearthstone bind
  from 3 tasks in a zone.
- Flight points are always placed at their flight master's zone (no "Kalimdor" as a zone after flights).
- "script ran too long": the path search hands control back to the game every 5 expansions during the journey.
- Control center opens faster (zone overview reuses the last plan instead of recalculating everything).
- Watch mode: shows the path just walked on the world map and pauses 2 s after each finished step.
- Journey report: long straight lines show the start of the section in its own zone's coordinates.
- Safe mode is now stricter than the mandatory rule: avoids elites and mobs from your level + 1.

## 3.8.1
Found with GoldSentinel's real saved data (LevelPilot.lua from the WTF folder).
- Fixed: flights. The game stores flight points on the flight map (e.g. map 1464), which can't always be
  converted to world positions – then LevelPilot never planned a flight (0 flights in the in-game test).
  LevelPilot now calibrates the flight map itself: zone names in the flight point names plus the flight
  masters from the data package give shift and scale; each flight point gets its flight master's position.
  All 19 recorded Horde flight points in Kalimdor are located (within 40 yards). The flight point you stand
  at when opening the flight map is stored as an exact reference.
- Self-test: new check "Flights" (how many flight points are located and known).
- Error log: entries from 3.4–3.6 were stored in the language set at that time. Solved zone messages are
  removed, the others are converted and shown in the current language. "Not getting closer" is no longer
  reported while you hunt within 400 yards of a quest target.

## 3.8.0
Fixes from the in-game test report of 3.7.0. Route and path changes apply to normal play, not only to the
virtual journey.
- Route: quests in the other faction's home zones that are open to everyone (e.g. Westfall for the Horde),
  PvP quests and battleground quests (Alterac Valley, Warsong Gulch, Arathi Basin) are no longer planned.
- Route: fewer zone and continent hops. Below level 12 you stay on your own continent; a zone on another
  continent only becomes the focus with at least 5 tasks and clearly more value than anything left here.
- Speedrun: the way to a quest giver now only affects the order, not whether a quest is skipped – before,
  standing in a capital far from quest givers could leave you grinding for hours (L28–50 in Thunder Bluff).
- WoW Forever is the default: quest log 40, dungeon monster XP about 30 %, dungeon quest XP about ×2
  (setting "WoW Forever server" under Settings » Server & dungeons).
- Zone check: "Das Brachland" and "Brachland" count as the same zone (no more ZONE entries).
- Virtual journey: planning is spread over several frames ("script ran too long" is gone), Stop ends it at
  once, it uses flight paths and its own hearthstone cooldown, quest levels are coloured by the journey's
  level, "Journey from here" takes over your real quest log, the window shows the result after the end.
- Data safety: logging out or /reload during a virtual journey restores your real flight paths and
  character data first, so nothing virtual is ever saved.
- Error log: entries are stored as keys and shown in the current language, sorted newest first; the
  self-test shows log entries as a hint instead of OK. Obsolete "language pack MISSING" entries are removed.
- Display: settings hint no longer overlaps "Support the addon"; objective names instead of "?"; the time
  estimate includes the remaining path.

## 3.7.0
- New: self-test (/lp test or control center » Data » Self-test) checks all functions in the game – modules,
  data package, language and names, position and zone, planning, path to the current step, display, map,
  nameplates, target button, comfort, sharing, error log – and shows a report to copy.
- New: virtual journey 1–60 (/lp reise, or "Journey from here" with /lp reise hier). An imaginary character
  runs LevelPilot's whole route with the game's real map and path data: accepts, completes and turns in
  quests, earns XP by Classic rules, flies and uses the hearthstone. Your character does not move; nothing
  is recorded or shared. "Watch" shows every path on the world map, "Fast" computes straight through.
  The report lists missing paths, long straight lines per zone, stuck plans, levels and zones.
- Fixed: Searing Gorge had no zone transition – found by the virtual journey; it is now connected to the
  Burning Steppes through Blackrock Mountain.

## 3.6.0
- Fixed: translated quest, NPC, item, object and zone names did not appear in the game, because WoW only
  detects new AddOn folders after a full restart. The names are now part of the data package itself
  (LevelPilot Data 1.6.0, Data/Names_*.lua) – a /reload is enough, and there are only two folders again.
- Languages your game can't display are released from memory at login.
- Target button: uses the enemy names of your game's language (before, non-English games got the
  English names and /targetexact found nothing).
- The separate folders LevelPilot_Data_deDE … from 3.5.x are no longer needed and can be deleted.

## 3.5.3
- Changed: the language selection only offers languages your game can display. LevelPilot measures it:
  a missing font draws every character as an identical box, so if all sample characters of a language
  are as wide as a surely missing character, that language is hidden. On European and Russian clients
  Korean and Chinese are hidden; on clients that have those fonts everything stays available.
- A saved language that can't be displayed falls back to "Automatic"; /lp lang refuses it with a reason.
- Fixed: language buttons keep their own script font (e.g. "Русский" no longer turned into boxes).

## 3.5.2
- Fixed: no more language mix. Vendor, innkeeper and flight master names, enemy names in the safe mode
  warning, the navigation arrow, nameplate texts and time units (h/min) now follow the chosen language.
  Hint pop-ups in the old language are closed when you switch.
- Fixed: buttons shrink their font instead of cutting off long words (e.g. Russian "Automatic").
- Fixed: the status bar measures its real text height, so long status lines are no longer cut off.
- Fixed: Russian font has no middle dot "·" – it is replaced, no more empty boxes.
- New: if a language pack can't be loaded, LevelPilot says why (most often: WoW must be fully restarted
  once after new AddOn folders were added – /reload is not enough). /lp diag shows the language packs.

## 3.5.1
- Packaging: one single download (LevelPilot.zip) now contains the addon, the data package and all
  language packs. Extract everything into Interface/AddOns.

## 3.5.0
- New: quest, NPC, item, object and zone names follow the language you choose in LevelPilot – no longer
  the language of your game client. Translations come from QuestieDB (GPLv3) as language packs in the
  data package (LevelPilot Data 1.5.0: LevelPilot_Data_deDE, _frFR, _esES, _esMX, _ptBR, _ruRU, _koKR,
  _zhCN, _zhTW). Only the packs that are needed are loaded. English uses the names of the data package;
  Italian has no Questie translation and shows English names.
- Quest objectives from the quest log are shown in the chosen language as well ("Name: 3/7").
- In your game's own language, the titles the game shows are kept; quests not yet in your log no longer
  appear in English.
- Target macros keep the names the game knows, so targeting still works in any language.

## 3.4.5
- Fixed: switching the language now updates every label in the guide window and the control center
  immediately – no /reload needed – and switching back restores everything. Words that share one
  translation (e.g. German "Austausch" and "Teilen" are both "Compartir" in Spanish) no longer come
  back wrong. Steps, hints and data source info are rebuilt in the new language as well.

## 3.4.4
- Changed: vendors now get every grey item – weapons, armour and junk. Items whose data the game had
  not loaded yet (often weapons from earlier sessions) used to stay in the bags; they are now sold too.
  Only items needed for a running quest or that start a quest are kept. The chat message shows the
  real amount earned.

## 3.4.3
- Fixed: the guide window header no longer cuts off text. The zone name has its own line across the
  full width, the "Normal / Skip / Replan" buttons moved to a separate row, and the XP line wraps
  instead of being hidden behind the buttons.
- Fixed: the status bar grows with its text and keeps clear of the resize grip.
- Fixed: the replan button showed an empty box (the ↻ glyph is missing in the game fonts) – it now uses
  an arrow icon. Arrows "→" in texts were replaced by "»" for the same reason.

## 3.4.2
- New: **Support** button in the guide window's title bar (a coin icon when the window is narrow), a
  "Support the addon" line in Settings and `/lp donate` (also `/lp spenden`, `/lp support`). It shows the
  PayPal link to copy – it never opens on its own and never posts anything in chat.

## 3.4.1
- New: error log for testers. LevelPilot quietly notes Lua errors, wrongly detected zones, unknown
  position, planning in the wrong zone, missing paths, being stuck, very long steps, deaths, slow
  planning and login/logout. `/lp protokoll` shows it as text to copy; it stays on your computer and
  contains no names or login data. Can be switched off under Extras.

## 3.4.0
- New control center tab "Extras": quest item locations with arrow and alert, quest tooltips, automatic
  restocking of food/water/ammo/pet food, auto-equip of reward upgrades, gold per hour, best level times,
  time estimates, rested/hearthstone status, "where was I?" on login, turn-in reminders, logout summary,
  corpse arrow, class quest and trainer cost hints, mount gold planning, quest sharing, group finder
  text, elite partner search, compact mode and per-character settings.
- Fixed: corpse arrow position, gold per hour counting.
