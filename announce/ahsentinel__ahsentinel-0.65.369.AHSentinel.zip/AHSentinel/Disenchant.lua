if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 0.63 - Entzauberungswert (Classic), lernt mit und teilt
--
-- Erwarteter Wert beim Entzaubern eines grünen, blauen oder epischen
-- Rüstungs- oder Waffenteils: Summe aus Wahrscheinlichkeit x Ø Menge
-- x Marktwert des Materials. Startwerte sind die bekannten
-- Classic-Richtwerte. Jede eigene Entzauberung wird erkannt und
-- gespeichert - die Werte nähern sich so immer mehr der Realität
-- auf deinem Server an. Über den Preis-Sync teilen alle Spieler mit
-- AHSentinel ihre Ergebnisse - so kommen schnell genug Daten zusammen.
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
-- Retail 12.x: die alten Item-/Zauber-Funktionen gibt es nur noch in C_Item / C_Spell
local GetItemInfo = GetItemInfo or (C_Item and C_Item.GetItemInfo)
local GetSpellInfo = GetSpellInfo or (C_Spell and C_Spell.GetSpellName)
local A = AHAnalyzerPro
local CreateFrame, C_Timer = A.OwnCreateFrame or CreateFrame, A.OwnTimer or C_Timer      -- VS-BILD-2 (0.65.320): eigene Skripte/Zeitgeber je Bild messen (nur während einer Vollscan-Messung)
local L = A.L

local D = {}
A.Disenchant = D

-- Material
local STRANGE, SOUL, VISION, DREAM, ILLUSION = 10940, 11083, 11137, 11176, 16204
local LMAGIC, GMAGIC, LASTRAL, GASTRAL = 10938, 10939, 10998, 11082
local LMYSTIC, GMYSTIC, LNETHER, GNETHER, LETERNAL, GETERNAL = 11134, 11135, 11174, 11175, 16202, 16203
local SGLIMMER, LGLIMMER, SGLOW, LGLOW = 10978, 11084, 11138, 11139
local SRADIANT, LRADIANT, SBRILLIANT, LBRILLIANT, NEXUS = 11177, 11178, 14343, 14344, 20725

-- ------------------------------------------------------------
-- Entzauber-Tabelle nach Disenchantry 1.1.2 (DisenchantResults.lua), MIT-Lizenz, Copyright (c) 2026 x_Raven_x
-- (Lizenztext: LICENSE-Disenchantry.txt). Quelle dort: warcraft.wiki.gg "Disenchanting tables" (Classic,
-- Itemstufe vor dem Squish). Gruppen nach ITEMSTUFE (nicht nach benötigter Stufe) - wie Disenchantry und die Tabelle.
-- Forever: grüne Waffen Itemstufe 21-30 geben Grosse Magieessenz (Wowhead-Forever-Daten, laut Disenchantry).
-- ------------------------------------------------------------
-- Grün: { bis Itemlevel, Staub, Ø Staub, Essenz, Ø Essenz, Splitter, Staub min, max, Essenz min, max }
local UNCOMMON = {
    { 15, STRANGE, 1.5, LMAGIC, 1.5, SGLIMMER, 1, 2, 1, 2 },
    { 20, STRANGE, 2.5, GMAGIC, 1.5, SGLIMMER, 2, 3, 1, 2 },
    { 25, STRANGE, 5.0, LASTRAL, 1.5, SGLIMMER, 4, 6, 1, 2 },
    { 30, SOUL, 1.5, GASTRAL, 1.5, LGLIMMER, 1, 2, 1, 2 },
    { 35, SOUL, 3.5, LMYSTIC, 1.5, SGLOW, 2, 5, 1, 2 },
    { 40, VISION, 1.5, GMYSTIC, 1.5, LGLOW, 1, 2, 1, 2 },
    { 45, VISION, 3.5, LNETHER, 1.5, SRADIANT, 2, 5, 1, 2 },
    { 50, DREAM, 1.5, GNETHER, 1.5, LRADIANT, 1, 2, 1, 2 },
    { 55, DREAM, 3.5, LETERNAL, 1.5, SBRILLIANT, 2, 5, 1, 2 },
    { 60, ILLUSION, 1.5, GETERNAL, 1.5, LBRILLIANT, 1, 2, 1, 2 },
    { 65, ILLUSION, 3.5, GETERNAL, 2.5, LBRILLIANT, 2, 5, 2, 3 },
}
-- Blau: { bis Itemlevel, Splitter }
local RARE = {
    { 25, SGLIMMER }, { 30, LGLIMMER }, { 35, SGLOW }, { 40, LGLOW },
    { 45, SRADIANT }, { 50, LRADIANT }, { 55, SBRILLIANT }, { 80, LBRILLIANT },
}
-- Episch: { ab, bis Itemlevel, Material, Ø Menge }
local EPIC = {
    { 40, 45, SRADIANT, 3, 2, 4 }, { 46, 50, LRADIANT, 3, 2, 4 }, { 51, 55, SBRILLIANT, 3, 2, 4 },
    { 56, 60, NEXUS, 1, 1, 1 }, { 61, 88, NEXUS, 1.5, 1, 2 },
}

-- Verhältnis bei grünen Items (Rüstung): Staub / Essenz / Splitter (Standard; je Stufe siehe GREEN_P)
D.GREEN_DUST, D.GREEN_ESSENCE, D.GREEN_SHARD = 0.75, 0.20, 0.05

-- Chancen je grüner Stufe (Quelle: warcraft.wiki.gg "Disenchanting tables", Classic; Befund im Spiel 9. Nov. 09:04:
-- Itemstufe bis 15 gibt KEINEN Splitter). a = Rüstung, w = Waffe: { Staub, Essenz, Splitter }
D.GREEN_P = {
    [1] = { a = { 0.80, 0.20, 0 },    w = { 0.20, 0.80, 0 } },       -- bis 15: nur Staub / Essenz
    [3] = { a = { 0.75, 0.15, 0.10 }, w = { 0.15, 0.75, 0.10 } },    -- 21-25: 10 % Splitter
    [9] = { a = { 0.75, 0.20, 0.05 }, w = { 0.22, 0.75, 0.03 } },    -- 51-55
    [10] = { a = { 0.75, 0.20, 0.05 }, w = { 0.22, 0.75, 0.03 } },   -- 56-60
    [11] = { a = { 0.75, 0.20, 0.05 }, w = { 0.22, 0.75, 0.03 } },   -- 61-65
}
-- Startwerte einer grünen Stufe k (Tabellenzeile b), Waffe ja/nein
-- Forever (Entscheid des Nutzers 10.11. 08:17, Anweisung C1-C6): Startwerte nach dem Forever-Leitfaden
-- (wow-professions.com/forever/disenchanting-guide): Rüstung 75/20/5, Waffe 20/75/5 für alle grünen Stufen mit
-- Splitter; "bis 15" (kein Splitter, im Spiel bestätigt) bleibt 80/20. Eigene Ergebnisse wiegen wie bisher stärker.
-- Andere Versionen: Tabelle warcraft.wiki.gg (GREEN_P) unverändert.
D.GREEN_P_FOREVER = { a = { 0.75, 0.20, 0.05 }, w = { 0.20, 0.75, 0.05 } }
function D:GreenTable(k)
    if A:IsForever() and k ~= 1 then return self.GREEN_P_FOREVER, "forever" end
    return self.GREEN_P[k], "wiki"
end

function D:GreenPrior(k, b, weapon)
    local p = self:GreenTable(k)
    local c = p and (weapon and p.w or p.a) or (weapon and { D.GREEN_ESSENCE, D.GREEN_DUST, D.GREEN_SHARD } or { D.GREEN_DUST, D.GREEN_ESSENCE, D.GREEN_SHARD })
    -- Forever: grüne Waffen Itemstufe 21-30 (Stufen 3 und 4) geben Grosse Magieessenz (Disenchantry)
    local ess = b[4]
    if weapon and (k == 3 or k == 4) and A:IsForever() then ess = GMAGIC end
    -- { itemID, Chance, Ø Menge, Menge min, Menge max }
    local out = { { b[2], c[1], b[3], b[7], b[8] }, { ess, c[2], b[5], b[9], b[10] } }
    if c[3] > 0 and b[6] then table.insert(out, { b[6], c[3], 1, 1, 1 }) end
    return out
end

-- nicht entzauberbar, obwohl Rüstung
local NOT_DE = { INVTYPE_BODY = true, INVTYPE_TABARD = true, INVTYPE_BAG = true, INVTYPE_AMMO = true, INVTYPE_QUIVER = true, [""] = true }

-- Startwerte aus der Tabelle: Ertrag { { itemID, Chance (0-1), Ø Menge }, ... }, Gruppe, oder nil.
-- Gruppe = Qualität : Itemlevel-Stufe : Waffe/Rüstung - alle Items einer Gruppe
-- geben laut Tabelle dieselben Materialien und lernen deshalb gemeinsam.
D.NEVER_CLASSES = { ["2:19"] = true }        -- Waffe / Zauberstab
-- Punkt 3 (offen 11.11.): gelernte Sperre nur je Item-ID. Eine ganze Klasse erst, wenn mindestens NEVER_CLASS_MIN
-- VERSCHIEDENE Items derselben Klasse gescheitert sind (ein Sonderfall sperrt nicht alle Lederrüstungen). Ältere
-- Klassen-Einträge ohne diese Zählung bleiben gespeichert, wirken aber nicht mehr.
D.NEVER_CLASS_MIN = 3
function D:NeverClassCount(ck)
    local n = A.db and A.db.deNever
    local c = 0
    for _ in pairs(n and n.classFails and n.classFails[ck] or {}) do c = c + 1 end
    return c
end
function D:NeverClassActive(ck)
    local n = A.db and A.db.deNever
    return n and n.classes and n.classes[ck] and self:NeverClassCount(ck) >= self.NEVER_CLASS_MIN or false
end
function D:IsNeverDE(itemID, classID, subClassID)
    local ck = tostring(classID) .. ":" .. tostring(subClassID)
    if self.NEVER_CLASSES[ck] then return true end
    local n = A.db and A.db.deNever
    if n and n.items and n.items[itemID] then return true end
    if n and n.classes and n.classes[ck] and self:NeverClassActive(ck) then return true end
    return false
end
-- dauerhaft merken (neue Tabelle db.deNever, nur zusätzlich) + Protokoll DE-NICHT-MOEGLICH
-- Klasse/Unterklasse eines Items (eigene Funktion, Seam für Tests)
function D:ItemClass(itemID)
    local ok, _, _, _, _, _, _, _, _, _, _, _, classID, subClassID = pcall(GetItemInfo, itemID)
    if ok and classID then return classID, subClassID end
    return nil
end
function D:MarkNever(itemID)
    if not (A.db and itemID) then return end
    local classID, subClassID = self:ItemClass(itemID)
    local ok = classID ~= nil
    local n = A.db.deNever or { items = {}, classes = {} }
    A.db.deNever = n
    n.items = n.items or {}
    n.classes = n.classes or {}
    n.items[itemID] = true
    local ck = (ok and classID) and (tostring(classID) .. ":" .. tostring(subClassID)) or nil
    local cnt = 0
    if ck then
        n.classFails = n.classFails or {}
        n.classFails[ck] = n.classFails[ck] or {}
        n.classFails[ck][itemID] = true
        cnt = self:NeverClassCount(ck)
        if cnt >= self.NEVER_CLASS_MIN then n.classes[ck] = true end
    end
    if A.Diag then pcall(A.Diag.Add, A.Diag, "DE-NICHT-MOEGLICH", string.format("Item %d · Klasse/Unterklasse %s (%d Items gescheitert%s)", itemID,
        tostring(ck or "?"), cnt, (ck and self:NeverClassActive(ck)) and ", Klasse gesperrt" or "")) end
    A:Fire("DATA_CHANGED")
end
-- gesperrte "nicht entzauberbar"-Einträge: { { itemID = id } | { class = "4:2", n = 3 } }
function D:NeverList()
    local out = {}
    local n = A.db and A.db.deNever
    if not n then return out end
    local ids = {}
    for id, on in pairs(n.items or {}) do if on then ids[#ids + 1] = id end end
    table.sort(ids)
    for _, id in ipairs(ids) do out[#out + 1] = { itemID = id } end
    local cls = {}
    for ck in pairs(n.classes or {}) do if self:NeverClassActive(ck) then cls[#cls + 1] = ck end end
    table.sort(cls)
    for _, ck in ipairs(cls) do out[#out + 1] = { class = ck, n = self:NeverClassCount(ck) } end
    return out
end
-- freigeben: ein Item (auch aus der Klassen-Zählung) bzw. eine Klasse
function D:ReleaseNever(itemID)
    local n = A.db and A.db.deNever
    if not (n and itemID) then return false end
    local had = n.items and n.items[itemID]
    if n.items then n.items[itemID] = nil end
    for ck, set in pairs(n.classFails or {}) do
        if set[itemID] then
            set[itemID] = nil
            if n.classes and self:NeverClassCount(ck) < self.NEVER_CLASS_MIN then n.classes[ck] = nil end
        end
    end
    A:Fire("DATA_CHANGED")
    return had and true or false
end
function D:ReleaseNeverClass(ck)
    local n = A.db and A.db.deNever
    if not (n and ck) then return false end
    if n.classes then n.classes[ck] = nil end
    if n.classFails then n.classFails[ck] = nil end
    A:Fire("DATA_CHANGED")
    return true
end
-- alles freigeben (/ahs entzaubern freigeben); zurück: Anzahl freigegebener Einträge
function D:ClearNever()
    local n = A.db and A.db.deNever
    if not n then return 0 end
    local c = #self:NeverList()
    n.items, n.classes, n.classFails = {}, {}, {}
    A:Fire("DATA_CHANGED")
    return c
end

-- DE-WIN1: warum D:Prior für ein Teil nil liefert (für die Zeile DE-LEER und den Hinweis im Fenster) - nil = Prior vorhanden
function D:PriorReason(itemID)
    if not itemID then return "keine ID" end
    if self:Prior(itemID) then return nil end
    if not GetItemInfo then return "GetItemInfo fehlt" end
    local ok, name, _, quality, ilvl, _, _, _, _, equipLoc, _, _, classID, subClassID = pcall(GetItemInfo, itemID)
    if not ok or not name then return "Iteminfo noch nicht geladen" end
    if not quality or quality < 2 or quality > 4 then return "Qualität" end
    if classID ~= 2 and classID ~= 4 then return "keine Waffe/Rüstung" end
    if self:IsNeverDE(itemID, classID, subClassID) then return "nie entzauberbar" end
    if NOT_DE[equipLoc or ""] then return "Platz " .. tostring(equipLoc) end
    return "Stufe " .. tostring(ilvl)
end
-- WACH-1b (Supervisor 20:35: 15 000 Zeilen -> längstes Bild 26 ms durch Speicherbereinigung): Prior legt je Aufruf neue Tabellen an
-- (gemessen 2,8 KB je Zeile der Wächter-Prüfung, mehrere Aufrufe je Zeile). Während einer Kandidaten-Prüfung (D.matCache aktiv,
-- höchstens MAT_CACHE_S) je Item nur einmal rechnen; die Tabellen werden von allen Aufrufern nur gelesen.
-- S28-LECK (Ingametest 18.11. 17:01 S28: Item 4251 "Lohnt bis" 1004, Markt-Zeile 1003): D.matCache galt GLOBAL, solange die
-- Kandidaten-Prüfung (Hintergrund-Aufgabe mit Pausen) lief - auch für Tooltip, Markt und Prüfungen in den Bildern dazwischen, bis
-- zu MAT_CACHE_S alt. Jetzt gilt er nur für seinen Besitzer: die Aufgabe, die ihn angelegt hat (während sie läuft), bzw. ohne
-- Aufgabe nur im selben Bild. Alle anderen rechnen frisch - damit liefern alle Stellen denselben Wert.
function D:MatCacheOn()
    local mc = self.matCache
    if not mc then return nil end
    local now = GetTime()
    if now - mc.t > self.MAT_CACHE_S then return nil end
    if mc.job then
        if not (A.yieldOK and A.currentJob == mc.job) then return nil end
    elseif now ~= mc.t then
        return nil
    end
    return mc
end
function D:Prior(itemID)
    local mc = self:MatCacheOn()
    if mc and itemID then
        mc.pr = mc.pr or {}
        local c = mc.pr[itemID]
        if c == nil then
            local prior, key = self:PriorRaw(itemID)
            c = prior and { prior, key } or false
            mc.pr[itemID] = c
        end
        if c then return c[1], c[2] end
        return nil
    end
    return self:PriorRaw(itemID)
end
function D:PriorRaw(itemID)
    if not GetItemInfo or not itemID then return nil end
    if A.ItemInfoAllowed and not A:ItemInfoAllowed(itemID) then return nil end              -- GSL8-1
    -- TB138b-3: ohne Hilfstabelle (wird je Vollscan für jedes Item aufgerufen)
    local ok, name, _, quality, ilvl, _, _, _, _, equipLoc, _, _, classID, subClassID = pcall(GetItemInfo, itemID)
    if not ok or not name then return nil end
    if not quality or quality < 2 or quality > 4 or not ilvl then return nil end
    if classID ~= 2 and classID ~= 4 then return nil end
    -- a2 (Hinweis des Nutzers 10.11. 16:44): Zauberstäbe lassen sich in WoW Forever nicht entzaubern; dazu alles, was
    -- beim Entzaubern mit "kann nicht entzaubert werden" scheiterte (Item oder Klasse/Unterklasse, D:MarkNever)
    if self:IsNeverDE(itemID, classID, subClassID) then return nil end
    if NOT_DE[equipLoc or ""] then return nil end
    local weapon = (classID == 2)
    if quality == 2 then
        if ilvl < 5 then return nil end
        for k, b in ipairs(UNCOMMON) do
            if ilvl <= b[1] then
                -- Chancen je Stufe (GREEN_P): bis 15 nur Staub/Essenz (80/20), sonst 75/20/5 bzw. 75/15/10;
                -- Waffen gespiegelt
                return self:GreenPrior(k, b, weapon), "2:" .. k .. ":" .. (weapon and "w" or "a")
            end
        end
        return nil
    elseif quality == 3 then
        if ilvl < 1 then return nil end            -- Disenchantry: blau ab Itemstufe 1
        for k, b in ipairs(RARE) do
            if ilvl <= b[1] then
                if b[2] == LBRILLIANT and ilvl >= 56 then
                    return { { LBRILLIANT, 0.995, 1, 1, 1 }, { NEXUS, 0.005, 1, 1, 1 } }, "3:" .. k
                end
                return { { b[2], 1, 1, 1, 1 } }, "3:" .. k
            end
        end
        return nil
    else
        for k, b in ipairs(EPIC) do
            if ilvl >= b[1] and ilvl <= b[2] then return { { b[3], 1, b[4], b[5], b[6] } }, "4:" .. k end
        end
        return nil
    end
end

-- ------------------------------------------------------------
-- Lernen aus eigenen Entzauberungen
-- Die Tabelle zählt wie PRIOR_WEIGHT gedachte Entzauberungen. Jede echte
-- Entzauberung verschiebt Chance und Menge Richtung deiner Ergebnisse:
--   Chance = (Tabelle x W + gesehen) / (W + Anzahl Entzauberungen)
--   Menge  = (Tabelle x W x Chance + Summe) / (W x Chance + gesehen)
-- Nach 10 eigenen Entzauberungen zählen deine Ergebnisse zur Hälfte,
-- nach 50 zu 83 %, nach 100 zu 91 %.
-- ------------------------------------------------------------
D.PRIOR_WEIGHT = 10

local function Stats() return A.db and A.db.deStats end

-- alle Materialien, die beim Entzaubern herauskommen können
local MATERIALS = {}
for _, b in ipairs(UNCOMMON) do MATERIALS[b[2]] = true; MATERIALS[b[4]] = true; if b[6] then MATERIALS[b[6]] = true end end
for _, b in ipairs(RARE) do MATERIALS[b[2]] = true end
for _, b in ipairs(EPIC) do MATERIALS[b[3]] = true end
MATERIALS[NEXUS] = true
function D:IsMaterial(id) return MATERIALS[id] == true end
D.MATERIALS = MATERIALS

-- Startwerte einer Gruppe (für Übersichten ohne konkretes Item)
--   "2:k:a" / "2:k:w" grün Rüstung/Waffe, "3:k" blau, "4:k" episch
function D:PriorForKey(key)
    if type(key) ~= "string" then return nil end
    local q, k, w = key:match("^(%d):(%d+):?([aw]?)$")
    q, k = tonumber(q), tonumber(k)
    if q == 2 then
        local b = UNCOMMON[k]
        if not b or w == "" then return nil end
        return self:GreenPrior(k, b, w == "w")
    elseif q == 3 then
        local b = RARE[k]
        if not b or w ~= "" then return nil end
        if b[2] == LBRILLIANT then return { { LBRILLIANT, 0.995, 1, 1, 1 }, { NEXUS, 0.005, 1, 1, 1 } } end
        return { { b[2], 1, 1, 1, 1 } }
    elseif q == 4 then
        local b = EPIC[k]
        if not b or w ~= "" then return nil end
        return { { b[3], 1, b[4], b[5], b[6] } }
    end
    return nil
end

-- Bereich einer Gruppe für Anzeigen: Qualität, Itemlevel von, bis, Waffe?
function D:KeyInfo(key)
    local q, k, w = (key or ""):match("^(%d):(%d+):?([aw]?)$")
    q, k = tonumber(q), tonumber(k)
    local from, to
    if q == 2 and UNCOMMON[k] then from, to = (k == 1) and 5 or UNCOMMON[k - 1][1] + 1, UNCOMMON[k][1]
    elseif q == 3 and RARE[k] then from, to = (k == 1) and 11 or RARE[k - 1][1] + 1, RARE[k][1]
    elseif q == 4 and EPIC[k] then from, to = EPIC[k][1], EPIC[k][2] end
    return q, from, to, w == "w"
end

-- Ergebnisse einer Gruppe: eigene + von anderen Spielern geteilte
-- zurück: n eigene, n geteilt, mats = { [itemID] = { times, total } } (zusammengezählt)
function D:Combined(key)
    local own = Stats() and Stats()[key]
    local nOwn, nShared, mats = own and own.n or 0, 0, {}
    local allowed = self.AllowedMats and self:AllowedMats(key)
    local function add(src)
        for id, m in pairs(src or {}) do
            if allowed and not allowed[id] then
                -- unplausibel für diese Gruppe (z. B. Splitter aus Itemstufe bis 15): nicht mitzählen
            else
            local t = mats[id]
            if not t then t = { times = 0, total = 0 }; mats[id] = t end
            t.times = t.times + (m.times or 0)
            t.total = t.total + (m.total or 0)
            end
        end
    end
    if own then add(own.mats) end
    local shared = A.db and A.db.deShared
    if shared then
        for _, rec in pairs(shared) do
            local g = rec.g and rec.g[key]
            if g and (g.n or 0) > 0 then
                nShared = nShared + g.n
                add(g.mats)
            end
        end
    end
    return nOwn, nShared, mats
end

-- Startwerte mit Ergebnissen verrechnen
function D:Blend(prior, nTotal, mats)
    if nTotal <= 0 then return prior end
    local W, n = self.PRIOR_WEIGHT, nTotal
    local out, seen = {}, {}
    for _, e in ipairs(prior) do
        local m = mats[e[1]]
        local times, total = m and m.times or 0, m and m.total or 0
        local chance = (e[2] * W + times) / (W + n)
        local den = e[2] * W + times
        local avg = (den > 0) and ((e[2] * W * e[3] + total) / den) or e[3]
        table.insert(out, { e[1], chance, avg, e[4], e[5] })
        seen[e[1]] = true
    end
    -- Material, das die Tabelle nicht kennt, aber herauskam
    for id, m in pairs(mats) do
        if not seen[id] and m.times > 0 then
            table.insert(out, { id, m.times / (W + n), m.total / m.times })
        end
    end
    return out
end

-- Ertrag (Tabelle + eigene + geteilte Ergebnisse), Gruppe, Anzahl eigener, Anzahl geteilter Entzauberungen
function D:Yield(itemID)
    local prior, key = self:Prior(itemID)
    if not prior then return nil end
    local nOwn, nShared, mats = self:Combined(key)
    return self:Blend(prior, nOwn + nShared, mats), key, nOwn, nShared
end

-- Quelle der Chancen für den Tooltip (C5 / Hinweis a-b): Text, Gruppe, Anzahl eingerechneter eigener/geteilter Ergebnisse
function D:ChanceSource(itemID)
    local prior, key = self:Prior(itemID)
    if not prior then return nil end
    local nOwn, nShared = self:Combined(key)
    local q = self:KeyInfo(key)
    local k = tonumber((key or ""):match("^%d:(%d+)"))          -- Stufe der Tabelle (KeyInfo liefert Itemstufen)
    local base
    if q == 2 and k and select(2, self:GreenTable(k)) == "forever" then
        base = L["Chancen: Forever-Leitfaden (wow-professions.com), Rüstung 75/20/5, Waffe 20/75/5"]
    else
        base = L["Chancen: Tabelle warcraft.wiki.gg (Classic)"]
    end
    return base, key, (nOwn or 0) + (nShared or 0), nOwn or 0, nShared or 0
end

-- Ertrag einer Gruppe (für Übersichten)
function D:YieldForKey(key)
    local prior = self:PriorForKey(key)
    if not prior then return nil end
    local nOwn, nShared, mats = self:Combined(key)
    return self:Blend(prior, nOwn + nShared, mats), prior, nOwn, nShared
end

-- alle Gruppen mit eigenen oder geteilten Ergebnissen: { { key, nOwn, nShared }, ... }
function D:Groups()
    local keys = {}
    for key in pairs(Stats() or {}) do keys[key] = true end
    for _, rec in pairs((A.db and A.db.deShared) or {}) do
        for key in pairs(rec.g or {}) do keys[key] = true end
    end
    local out = {}
    for key in pairs(keys) do
        if self:PriorForKey(key) then
            local nOwn, nShared = self:Combined(key)
            if nOwn + nShared > 0 then table.insert(out, { key = key, own = nOwn, shared = nShared }) end
        end
    end
    table.sort(out, function(a, b)
        local qa, fa = self:KeyInfo(a.key)
        local qb, fb = self:KeyInfo(b.key)
        if qa ~= qb then return qa < qb end
        if fa ~= fb then return (fa or 0) < (fb or 0) end
        return a.key < b.key
    end)
    return out
end

-- Protokoll der eigenen Entzauberungen (Entzauber-Fenster: Statistik, Buchhaltung: Abrechnung E4).
-- Ein Teil aus dem Sammelkauf (A.db.deBuys) wird dabei abgehakt: gleiche ItemID, gekauft höchstens
-- DE_MATCH_DAYS Tage vorher, das älteste offene zuerst.
D.DE_MATCH_DAYS = 14
function D:LogResult(itemID, loot, t)
    if not A.db then return end
    t = t or time()
    A.db.deLog = A.db.deLog or {}
    local copy = {}
    for _, l in ipairs(loot or {}) do copy[#copy + 1] = { l[1], l[2] or 1 } end
    local e = { t = t, itemID = itemID, loot = copy }
    for _, b in ipairs(A.db.deBuys or {}) do
        if not b.done and b.itemID == itemID and (b.t or 0) <= t and t - (b.t or 0) <= self.DE_MATCH_DAYS * 86400 then
            b.done = t
            e.paid = b.paid
            break
        end
    end
    table.insert(A.db.deLog, e)
    while #A.db.deLog > 2000 do table.remove(A.db.deLog, 1) end
    A:Fire("DE_LOOT", itemID, copy)                 -- Buchhaltung neu (BP3): Kostenbasis -> Materialien
    if A.Activity and not (A.Activity.Paused and A.Activity.Paused()) then pcall(A.Activity.Touch, A.Activity, "de") end   -- H9
    return e
end

-- ein Ergebnis speichern. loot = { { itemID, Menge }, ... }
function D:Record(itemID, loot)
    local prior, key = self:Prior(itemID)
    local db = Stats()
    if not prior or not db or type(loot) ~= "table" or #loot == 0 then return false end
    local sums = {}
    for _, l in ipairs(loot) do
        -- Z2 (Befund 09:00): nicht mehr still verwerfen - nicht in deStats zählen, aber in deLog (abgelehnt=Grund) und
        -- Protokoll DE-ABGELEHNT, damit echte Forever-Abweichungen sichtbar werden
        local why
        if not MATERIALS[l[1]] then why = "kein Entzauber-Material"
        else
            local allowed = self:AllowedMats(key)
            if allowed and not allowed[l[1]] then why = "nicht in der Tabelle der Gruppe" end
        end
        if why then
            local e = self:LogResult(itemID, loot)
            if e then e.rejected = why end
            if A.Diag then
                local okI, _, _, _, ilvl = pcall(GetItemInfo, itemID)
                pcall(A.Diag.Add, A.Diag, "DE-ABGELEHNT", string.format("Item %d · Itemstufe %s · Gruppe %s · Beute %s · %s", itemID,
                    tostring(okI and ilvl or "?"), tostring(key), self:LootText(loot), why))
            end
            return false, why
        end
        sums[l[1]] = (sums[l[1]] or 0) + (l[2] or 1)
    end
    local st = db[key]
    if not st then st = { n = 0, mats = {} }; db[key] = st end
    st.n = st.n + 1
    st.updated = time()
    for id, qty in pairs(sums) do
        local m = st.mats[id]
        if not m then m = { times = 0, total = 0 }; st.mats[id] = m end
        m.times = m.times + 1
        m.total = m.total + qty
    end
    self.lastRecord = { itemID = itemID, key = key, loot = loot }
    self:LogResult(itemID, loot)
    -- teilen nach 10 neuen Entzauberungen ODER spätestens 2 Minuten nach der letzten (und beim Ausloggen)
    self.unshared = (self.unshared or 0) + 1
    self.lastRecordAt = GetTime and GetTime() or time()
    if self.unshared >= self.SHARE_EVERY then self:BroadcastStats()
    elseif C_Timer and C_Timer.After then
        local mark = self.lastRecordAt
        C_Timer.After(self.SHARE_AFTER, function() D:ShareIfQuiet(mark) end)
    end
    A:Fire("DE_LEARNED", itemID, key)
    A:Fire("DATA_CHANGED")
    return true
end

function D:LootText(loot)
    local t = {}
    for _, l in ipairs(loot or {}) do t[#t + 1] = string.format("%d×%d", l[1], l[2] or 1) end
    return table.concat(t, ",")
end

-- Z3: Zähler je Tag (gezählt / verpasst) für die Statistik im Entzauber-Fenster
-- SANDBOX-1 (Ingame-Test 16.11. 19:43, UI-Testroutine "3 Pfade wiederhergestellt: deCount.day, deCount.counted, deCount.since"):
-- ohne field (nur ANZEIGEN, DEWindow:StatsText beim Zeichnen) legte der Aufruf am ersten Tag ohne Zählung einen neuen Tages-Zähler
-- an und schrieb ihn in die echten Daten. Jetzt schreibt nur das Zählen (field); Anzeigen liefert eine leere Kopie für heute.
function D:CountToday(field)
    if not A.db then return end
    local day = A:DayStart(time())
    local c = A.db.deCount
    if not field then
        if c and c.day == day then return c end
        return { day = day, counted = 0, missed = 0 }
    end
    -- W5: since = Beginn der Zählung (die Zählkontrolle vergleicht nur Verlauf-Einträge ab hier)
    if not c or c.day ~= day then c = { day = day, counted = 0, missed = 0, since = time() }; A.db.deCount = c end
    if field then c[field] = (c[field] or 0) + 1 end
    return c
end

function D:Missed(why)
    if A.TestRoutine and A.TestRoutine.running and not self.testCount then return end
    self:CountToday("missed")
    if A.Diag then pcall(A.Diag.Add, A.Diag, "DE-VERPASST", "Entzaubern gewirkt, kein Item zugeordnet: " .. tostring(why)) end
end

function D:TotalLearned()
    local groups, n = 0, 0
    for _, st in pairs(Stats() or {}) do groups = groups + 1; n = n + (st.n or 0) end
    return n, groups
end

-- geteilte Ergebnisse anderer Spieler: Entzauberungen gesamt, Anzahl Spieler
function D:TotalShared()
    local n, players = 0, 0
    for _, rec in pairs((A.db and A.db.deShared) or {}) do
        local any = false
        for _, g in pairs(rec.g or {}) do n = n + (g.n or 0); any = true end
        if any then players = players + 1 end
    end
    return n, players
end

-- Schutz der echten Entzauber-Daten (Entscheid des Nutzers 10.11. 09:25): vor dem Löschen eine Sicherung mit Datum
-- (db.deBackup, die letzten 3). deLog und deBuys bleiben (Verlauf und Abrechnung).
function D:Reset()
    if not A.db then return end
    local n = self:TotalLearned()
    A.db.deBackup = A.db.deBackup or {}
    table.insert(A.db.deBackup, { t = time(), n = n, deStats = A.db.deStats, deShared = A.db.deShared })
    while #A.db.deBackup > 3 do table.remove(A.db.deBackup, 1) end
    A.db.deStats = {}; A.db.deShared = {}
    if A.Diag then pcall(A.Diag.Add, A.Diag, "DE-ZURÜCKGESETZT", string.format("%d Ergebnisse gesichert (db.deBackup)", n)) end
    A:Fire("DATA_CHANGED")
end

-- letzte Sicherung zurückholen
function D:RestoreBackup()
    local b = A.db and A.db.deBackup and A.db.deBackup[#A.db.deBackup]
    if not b then return false end
    A.db.deStats, A.db.deShared = b.deStats or {}, b.deShared or {}
    table.remove(A.db.deBackup)
    A:Fire("DATA_CHANGED")
    return true, b.n
end

-- ------------------------------------------------------------
-- Teilen mit allen Spielern, die AHSentinel haben (über den Preis-Sync)
--   E:<Zeit>:<Gruppe>~<n>~<id>,<mal>,<Summe>,<id>,<mal>,<Summe>;<Gruppe>~...
--   Q:<Zeit>   Bitte um die Ergebnisse der anderen (nach dem Einloggen)
-- Jeder schickt immer seine kompletten eigenen Zahlen - der Empfänger
-- ersetzt die Zahlen dieses Spielers, nichts wird doppelt gezählt.
-- Schutz vor Unsinn: nur bekannte Materialien, höchstens SHARE_MAX_N
-- Entzauberungen pro Spieler und Gruppe, Mengen höchstens 20 pro Mal.
-- ------------------------------------------------------------
D.SHARE_MAX_N = 1000
D.SHARE_MAX_AGE = 90 * 86400
local SHARE_RESPOND_GAP = 30 * 60

-- Text für die eigenen Zahlen (Liste von Teilstücken je Gruppe)
function D:EncodeStats()
    local Enc = A.Sync and A.Sync.Enc
    if not Enc then return {} end
    local parts = {}
    for key, st in pairs(Stats() or {}) do
        if (st.n or 0) > 0 and self:PriorForKey(key) then
            local mats = {}
            for id, m in pairs(st.mats or {}) do
                if (m.times or 0) > 0 then table.insert(mats, Enc(id) .. "," .. Enc(m.times) .. "," .. Enc(m.total)) end
            end
            table.insert(parts, key:gsub(":", ".") .. "~" .. Enc(math.min(st.n, D.SHARE_MAX_N)) .. "~" .. table.concat(mats, ","))
        end
    end
    return parts
end

-- Absender nie mit Namen speichern: nur ein Kürzel ("#" + Prüfsumme), 9. Nov. 08:44
function D:SenderKey(sender)
    local s = tostring(sender or ""):lower()
    local h = 5381
    for i = 1, #s do h = (h * 33 + s:byte(i)) % 4294967296 end
    local digits, out = "0123456789abcdefghijklmnopqrstuvwxyz", ""
    repeat local r = h % 36; out = digits:sub(r + 1, r + 1) .. out; h = math.floor(h / 36) until h == 0
    return "#" .. out
end

-- alte Einträge (bis 0.65.25 mit Namen) auf Kürzel umstellen
function D:MigrateShared(sh)
    sh = sh or (A.db and A.db.deShared)
    if type(sh) ~= "table" then return end
    local rename = {}
    for k in pairs(sh) do if type(k) ~= "string" or k:sub(1, 1) ~= "#" then rename[#rename + 1] = k end end
    for _, k in ipairs(rename) do
        local hk = self:SenderKey(k)
        if not sh[hk] then sh[hk] = sh[k] end
        sh[k] = nil
    end
end

-- Ist der Absender einer der eigenen Charaktere (Twink)? Die zählen schon als "eigene" (gemeinsame deStats)
function D:IsOwnChar(sender)
    local chars = A.db and A.db.chars
    if type(chars) ~= "table" or not sender then return false end
    local s = tostring(sender)
    local name = s:match("^([^%-]+)") or s
    for key, c in pairs(chars) do
        if key == s or (type(c) == "table" and c.name == name and (not s:find("-", 1, true) or key == s)) then return true end
    end
    return false
end

-- Material passt zur Gruppe (Qualität/Itemlevel): nur Materialien aus der Tabelle dieser Gruppe
function D:AllowedMats(key)
    local prior = self:PriorForKey(key)
    if not prior then return nil end
    local ok = {}
    for _, e in ipairs(prior) do if e[1] then ok[e[1]] = true end end
    return ok
end

-- Schutz vor Unsinn beim Annehmen (9. Nov. 08:44)
D.SHARE_MSGS_PER_MIN = 1       -- Sendungen je Absender und Minute (alle Teilstücke einer Sendung = gleiche Zeit t zählen als 1)
D.SHARE_PARTS_MAX = 40          -- höchstens so viele Teilstücke je Sendung
D.SHARE_N_PER_MIN = 30         -- so viele neue Entzauberungen je Absender und Minute (gegenüber seiner letzten Meldung)
D.SHARE_MAX_QTY = 5            -- Menge je Entzauberung 1-5
D.rate = D.rate or {}

-- Teilstücke eines anderen Spielers prüfen und übernehmen (er schickt immer seine kompletten Zahlen:
-- der Empfänger ersetzt sie, nichts wird doppelt gezählt)
function D:HandleShared(sender, t, payload)
    local Dec = A.Sync and A.Sync.Dec
    if not (A.db and Dec and sender and type(payload) == "string") then return 0 end
    local now = time()
    if not t or t > now + 300 or t < now - D.SHARE_MAX_AGE then return 0 end
    if self:IsOwnChar(sender) then return 0 end                 -- eigener Twink: zählt schon als eigen
    local sk = self:SenderKey(sender)
    -- G13: Konto-Kennung "@id" vorn -> unter dem Konto führen; den alten Eintrag dieses Charakters (vor 0.65.366) entfernen
    local acc = payload:match("^@(%w+);")
    if acc then
        payload = payload:sub(#acc + 3)
        if A.db.deShared then A.db.deShared[sk] = nil end
        if acc == self:AccountId() then return 0 end           -- eigenes Konto (anderer Rechner): zählt schon als eigen
        sk = "@" .. acc
    end
    -- Mengenlimit (offener Punkt 9): höchstens SHARE_MSGS_PER_MIN Sendungen je Absender und Minute. Eine Sendung =
    -- alle Teilstücke mit derselben Zeit t (D:BroadcastStats teilt grosse Statistiken auf) - sie zählen als eine.
    local r = self.rate[sk]
    if not r or now - r.t0 >= 60 then r = { t0 = now, n = 0, sends = {} }; self.rate[sk] = r end
    r.sends = r.sends or {}
    if not r.sends[t] then
        r.n = r.n + 1
        if r.n > self.SHARE_MSGS_PER_MIN then return 0 end
        r.sends[t] = 0
    end
    r.sends[t] = r.sends[t] + 1
    if r.sends[t] > self.SHARE_PARTS_MAX then return 0 end
    A.db.deShared = A.db.deShared or {}
    local rec = A.db.deShared[sk]
    if not rec then rec = { t = 0, g = {} }; A.db.deShared[sk] = rec end
    -- doppelte Meldung (gleicher Inhalt): nur einmal
    if rec.last == payload then return 0 end
    local minutes = (rec.t and rec.t > 0) and math.max(0, (now - rec.t) / 60) or nil
    local taken = 0
    for part in payload:gmatch("[^;]+") do
        local k, nEnc, matStr = part:match("^([%d%.aw]+)~(%w+)~([%w,]*)$")
        local key = k and k:gsub("%.", ":")
        local n = Dec(nEnc)
        local allowed = key and self:AllowedMats(key)
        if key and n and n > 0 and n <= D.SHARE_MAX_N and allowed then
            local mats, ok, nums = {}, true, {}
            for x in matStr:gmatch("[^,]+") do table.insert(nums, Dec(x)) end
            if #nums % 3 ~= 0 then ok = false end
            for i = 1, #nums - 2, 3 do
                local id, times, total = nums[i], nums[i + 1], nums[i + 2]
                if not (id and times and total and allowed[id] and times >= 1 and times <= n and total >= times
                    and total <= times * D.SHARE_MAX_QTY) then
                    ok = false; break
                end
                mats[id] = { times = times, total = total }
            end
            -- zu schnell gewachsen gegenüber der letzten Meldung dieses Absenders?
            local prev = rec.g[key]
            if ok and prev and minutes and n - (prev.n or 0) > D.SHARE_N_PER_MIN * (minutes + 1) then ok = false end
            if ok then
                rec.g[key] = { n = n, mats = mats }
                taken = taken + 1
            end
        end
    end
    if taken > 0 then
        rec.t = now
        rec.last = payload
        A:Fire("DATA_CHANGED")
    end
    return taken
end

-- alte Daten von Spielern, die man lange nicht gehört hat, vergessen
function D:PruneShared()
    self:MigrateShared()
    local limit = time() - D.SHARE_MAX_AGE
    for name, rec in pairs((A.db and A.db.deShared) or {}) do
        if (rec.t or 0) < limit then A.db.deShared[name] = nil end
    end
end

D.SHARE_EVERY = 10          -- nach so vielen neuen Entzauberungen teilen
D.SHARE_AFTER = 120         -- oder spätestens so viele Sekunden nach der letzten

-- 2 Minuten nach der letzten Entzauberung: teilen, wenn seitdem keine neue kam und noch etwas offen ist
function D:ShareIfQuiet(mark)
    if (self.unshared or 0) > 0 and self.lastRecordAt == mark then return self:BroadcastStats() end
    return false
end

function D:AccountId()
    local db = A.db
    if not db then return "0" end
    if not db.accountId then
        local seed = (time() % 100000) * 1000 + math.floor(((GetTime and GetTime()) or 0) * 1000) % 1000
        local x, out, digits = seed + math.random(1, 2147483), "", "0123456789abcdefghijklmnopqrstuvwxyz"
        repeat local r = x % 36; out = digits:sub(r + 1, r + 1) .. out; x = math.floor(x / 36) until x == 0
        db.accountId = out
    end
    return db.accountId
end
-- immediate = true: sofort senden (beim Ausloggen), nicht über die Warteschlange
function D:BroadcastStats(immediate)
    local S = A.Sync
    if not (S and S.IsEnabled and S:IsEnabled() and S:IsConnected() and S.Enqueue) then return false end
    local send = (immediate and S.SendNow) or S.Enqueue
    local parts = self:EncodeStats()
    self.unshared = 0
    if #parts == 0 then return false end
    self.lastShared = time()
    -- G13 (Auftrag 21.11. 16:35): Konto-Kennung (zufällig, keine Namen) vorn in jedem Teilstück - alle Charaktere eines Kontos
    -- schicken dieselben Konto-Zahlen; der Empfänger führt sie unter EINER Kennung (vorher je Charakter -> doppelt gezählt)
    local head = "E:" .. S.Enc(time()) .. ":@" .. self:AccountId() .. ";"
    local chunk, size = {}, #head
    for _, p in ipairs(parts) do
        if #head + #p <= S.MAX_MSG then
            if size + #p + 1 > S.MAX_MSG and #chunk > 0 then
                send(head .. table.concat(chunk, ";"))
                chunk, size = {}, #head
            end
            table.insert(chunk, p)
            size = size + #p + 1
        end
    end
    if #chunk > 0 then send(head .. table.concat(chunk, ";")) end
    return true
end

-- nach dem Einloggen: die anderen um ihre Ergebnisse bitten
function D:RequestShared()
    local S = A.Sync
    if not (S and S.Enqueue and S:IsEnabled() and S:IsConnected()) then return end
    self:PruneShared()
    S.Enqueue("Q:" .. S.Enc(time()))
end

-- auf eine Bitte antworten (zufällig verzögert, höchstens alle 30 Minuten)
function D:HandleRequest()
    if self.pendingShare or (self:TotalLearned()) == 0 then return end
    if self.lastShared and time() - self.lastShared < SHARE_RESPOND_GAP then return end
    self.pendingShare = true
    C_Timer.After(5 + math.random() * 25, function()
        D.pendingShare = false
        D:BroadcastStats()
    end)
end

-- ------------------------------------------------------------
-- Entzaubern erkennen:
--   1. Item wird angeklickt, während ein Zauber auf ein Ziel wartet -> Kandidat
--   2. der Zauber "Entzaubern" ist erfolgreich -> Kandidat wird entzaubert
--   3. das Beute-Fenster öffnet sich -> Materialien lesen und speichern
-- ------------------------------------------------------------
local DE_SPELL = 13262
local candidate, pending
local WINDOW = 10            -- Sekunden zwischen den Schritten
D.LOOT_WINDOW = 5            -- Beute muss so schnell nach dem Entzaubern kommen (sonst andere Beute)

local function ItemAt(bag, slot)
    if C_Container and C_Container.GetContainerItemInfo then
        local info = C_Container.GetContainerItemInfo(bag, slot)
        return info and info.itemID
    elseif GetContainerItemLink then
        local link = GetContainerItemLink(bag, slot)
        return link and tonumber(link:match("item:(%d+)"))
    end
end

local function OnItemTargeted(bag, slot)
    if not (SpellIsTargeting and SpellIsTargeting()) then return end
    local id = ItemAt(bag, slot)
    if id and D:Prior(id) then candidate = { itemID = id, t = GetTime(), way = "Hook" } end
end

-- Entzauber-Fenster (DEWindow.lua): der sichere Knopf entzaubert per Makro - die Hooks oben sehen das nicht,
-- darum meldet das Fenster das Teil vor dem Klick selbst
function D:NoteCandidate(itemID)
    if itemID and self:Prior(itemID) then candidate = { itemID = itemID, t = GetTime(), way = "Fenster" } end
end

-- Z1 (Befund 09:00): Ersatz-Erkennung über die Taschen - Makros/andere Addons (/use Tasche Platz) rufen
-- UseContainerItem nicht auf. Beim Beginn des Zaubers die entzauberbaren Items der Taschen zählen; nach dem Plündern
-- das Item bestimmen, dessen Anzahl um 1 gesunken ist. Eindeutig -> zählen; sonst DE-VERPASST "nicht eindeutig".
local function BagSlotCount(bag, slot)
    if C_Container and C_Container.GetContainerItemInfo then
        local info = C_Container.GetContainerItemInfo(bag, slot)
        if info then return info.itemID, info.stackCount or 1 end
        return nil
    elseif GetContainerItemLink then
        local link = GetContainerItemLink(bag, slot)
        local id = link and tonumber(link:match("item:(%d+)"))
        local n                                         -- Nachtrag 06:50: "x and f()" liefert nur den ERSTEN Wert
        if GetContainerItemInfo then local _, c = GetContainerItemInfo(bag, slot); n = c end
        return id, n or 1
    end
end
function D:BagDECounts()
    local out = {}
    local nslots = (C_Container and C_Container.GetContainerNumSlots) or GetContainerNumSlots
    if not nslots then return out end
    for bag = 0, (NUM_BAG_SLOTS or 4) do
        for slot = 1, (nslots(bag) or 0) do
            local ok, id, n = pcall(BagSlotCount, bag, slot)
            if ok and id and self:Prior(id) then out[id] = (out[id] or 0) + (n or 1) end
        end
    end
    return out
end
-- Unterschied vorher/nachher: genau ein Item um 1 weniger -> itemID; sonst nil, Grund
function D:BagDiff(before, after)
    local found, many
    for id, n in pairs(before or {}) do
        local d = n - ((after or {})[id] or 0)
        if d >= 1 then
            if found or d > 1 then many = true end
            found = id
        end
    end
    if many then return nil, "nicht eindeutig" end
    if not found then return nil, "kein Item weniger" end
    return found
end
D.bagSnap = nil

local function IsDisenchant(spellID)
    if spellID == DE_SPELL then return true end
    if GetSpellInfo and spellID then
        local a, b = GetSpellInfo(spellID), GetSpellInfo(DE_SPELL)
        return a ~= nil and a == b
    end
    return false
end

function D:ReadLoot()
    if not (GetNumLootItems and GetLootSlotLink) then return nil end
    local out = {}
    for i = 1, GetNumLootItems() or 0 do
        local link = GetLootSlotLink(i)
        local id = link and tonumber(link:match("item:(%d+)"))
        local qty = 1
        if GetLootSlotInfo then
            local _, _, q = GetLootSlotInfo(i)
            if type(q) == "number" and q > 0 then qty = q end
        end
        if id then table.insert(out, { id, qty }) end
    end
    return out
end

local hooked = false
local function Hook()
    if hooked or not hooksecurefunc then return end
    hooked = true
    if C_Container and C_Container.UseContainerItem then pcall(hooksecurefunc, C_Container, "UseContainerItem", OnItemTargeted) end
    if C_Container and C_Container.PickupContainerItem then pcall(hooksecurefunc, C_Container, "PickupContainerItem", OnItemTargeted) end
    if UseContainerItem then pcall(hooksecurefunc, "UseContainerItem", OnItemTargeted) end
    if PickupContainerItem then pcall(hooksecurefunc, "PickupContainerItem", OnItemTargeted) end
end

local evt = CreateFrame("Frame")
D.evt = evt            -- für die Testroutine (Ereignisse mit Testargumenten nachspielen)
for _, e in ipairs({ "UNIT_SPELLCAST_SUCCEEDED", "UNIT_SPELLCAST_START", "LOOT_OPENED", "LOOT_READY", "PLAYER_LOGOUT", "BAG_UPDATE_DELAYED" }) do
    pcall(evt.RegisterEvent, evt, e)
end

-- Ergebnis zählen (alle Wege) mit Protokoll DE-GEZÄHLT (Z3)
function D:Counted(itemID, loot, way)
    -- Prognose-Journal: Vorhersage VOR dem Lernen dieses Ergebnisses
    local Fc = A.Forecast
    local okP, pred = false, nil
    if Fc then okP, pred = pcall(Fc.DEPrediction, Fc, itemID) end
    local ok, why = self:Record(itemID, loot)
    if ok then
        if Fc then pcall(Fc.OnDisenchant, Fc, itemID, loot, okP and pred or nil) end
        if not (A.TestRoutine and A.TestRoutine.running and not self.testCount) then self:CountToday("counted") end
        if A.Diag then
            local okI, _, _, _, ilvl = pcall(GetItemInfo, itemID)
            local _, key = self:Prior(itemID)
            pcall(A.Diag.Add, A.Diag, "DE-GEZÄHLT", string.format("Item %d · Itemstufe %s · Gruppe %s · Weg %s · Beute %s", itemID,
                tostring(okI and ilvl or "?"), tostring(key), tostring(way or "?"), self:LootText(loot)))
        end
        local n = select(3, D:Yield(itemID)) or 0
        if n > 0 and n % 10 == 0 then
            A:Print(string.format(L["Entzaubern: %d eigene Ergebnisse in dieser Gruppe - Werte angepasst."], n))
        end
    end
    return ok, why
end

-- Taschen-Weg: nach dem Plündern auf die Taschen warten (höchstens WINDOW s)
function D:ResolveBags()
    local p = self.bagPending
    if not p then return end
    local itemID, why = self:BagDiff(p.before, self:BagDECounts())
    if itemID then
        self.bagPending = nil
        return self:Counted(itemID, p.loot, "Taschen")
    end
    if why == "nicht eindeutig" or GetTime() - p.t > WINDOW then
        self.bagPending = nil
        self:Missed(why)
    end
end
evt:SetScript("OnEvent", function(_, event, a1, a2, a3)
    if event == "PLAYER_LOGOUT" then
        -- noch nicht geteilte Entzauberungen beim Ausloggen sofort senden
        if (D.unshared or 0) > 0 then pcall(D.BroadcastStats, D, true) end
        return
    end
    if event == "BAG_UPDATE_DELAYED" then
        if D.bagPending and D.bagPending.loot then pcall(D.ResolveBags, D) end
        return
    end
    if event == "UNIT_SPELLCAST_START" then
        local G = _G.GoldSentinelGame
        if G and G.AnySecret and (G.AnySecret(a1) or G.AnySecret(a3)) then return end
        if a1 == "player" and IsDisenchant(a3) then
            local ok, snap = pcall(D.BagDECounts, D)
            D.bagSnap = ok and { counts = snap, t = GetTime() } or nil
        end
        return
    end
    if event == "UNIT_SPELLCAST_SUCCEEDED" then
        local G = _G.GoldSentinelGame
        if G and G.AnySecret and G.AnySecret(a1) then return end          -- geschützter Wert (WoW Forever)
        if a1 ~= "player" then return end
        if G and G.AnySecret and G.AnySecret(a3) then
            pending = nil; candidate = nil
            return
        end
        if IsDisenchant(a3) and candidate and GetTime() - candidate.t < WINDOW then
            pending = { itemID = candidate.itemID, t = GetTime(), way = candidate.way }
        elseif IsDisenchant(a3) and D.bagSnap and GetTime() - D.bagSnap.t < WINDOW then
            pending = { bags = D.bagSnap.counts, t = GetTime(), way = "Taschen" }      -- Z1: Makro / anderes Addon
        elseif IsDisenchant(a3) then
            pending = nil
            D:Missed("kein Kandidat")
        else
            pending = nil      -- anderer Zauber: nichts zuordnen
        end
        candidate = nil
        D.bagSnap = nil
    elseif (event == "LOOT_OPENED" or event == "LOOT_READY") and pending then
        if GetTime() - pending.t < D.LOOT_WINDOW then
            local loot = D:ReadLoot()
            -- E6 (Anweisung Testroutine Entzaubern): Beute ganz ohne Entzauber-Material (Mob, Kiste, Kürschnern) ist kein
            -- Entzaubern - nicht zuordnen, nichts ablehnen; das wartende Entzaubern verfällt
            local anyMat = false
            for _, l in ipairs(loot or {}) do if MATERIALS[l[1]] then anyMat = true end end
            if loot and #loot > 0 and not anyMat then
                pending = nil
                D:Missed("Beute ohne Entzauber-Material")
                return
            end
            if loot and #loot > 0 then
                local p = pending
                pending = nil
                if p.itemID then
                    D:Counted(p.itemID, loot, p.way or "Hook")
                else
                    D.bagPending = { before = p.bags, loot = loot, t = GetTime() }
                    if C_Timer and C_Timer.After then
                        C_Timer.After(0.5, function() pcall(D.ResolveBags, D) end)
                        C_Timer.After(WINDOW + 0.5, function() pcall(D.ResolveBags, D) end)
                    else
                        D:ResolveBags()
                    end
                end
            end
        else
            pending = nil
        end
    end
end)
A:On("READY", Hook)

-- a2/T-ME9: Spielmeldung "kann nicht entzaubert werden" -> das zuletzt gewählte Teil (bzw. seine Klasse) nie mehr vorschlagen
D.NEVER_TEXTS = { "kann nicht entzaubert werden", "cannot be disenchanted", "ne peut pas être désenchanté", "no se puede desencantar",
    "non può essere disincantat", "não pode ser desencantado" }
function D:OnUIError(msg)
    if type(msg) ~= "string" then return false end
    local hit = (_G.ERR_CANT_BE_DISENCHANTED and msg == _G.ERR_CANT_BE_DISENCHANTED)
        or (_G.SPELL_FAILED_CANT_BE_DISENCHANTED and msg == _G.SPELL_FAILED_CANT_BE_DISENCHANTED)
    if not hit then
        local low = msg:lower()
        for _, t in ipairs(self.NEVER_TEXTS) do if low:find(t, 1, true) then hit = true; break end end
    end
    if not hit then return false end
    local c = candidate
    local id = (c and GetTime() - c.t < 10 and c.itemID) or (A.DEWindow and A.DEWindow.lastClick and A.DEWindow.lastClick.itemID)
    if id then self:MarkNever(id) end
    candidate, pending = nil, nil
    return id ~= nil
end
local errFrame = CreateFrame("Frame")
pcall(errFrame.RegisterEvent, errFrame, "UI_ERROR_MESSAGE")
errFrame:SetScript("OnEvent", function(_, _, a1, a2)
    local G = _G.GoldSentinelGame
    if G and G.AnySecret and (G.AnySecret(a1) or G.AnySecret(a2)) then return end
    pcall(D.OnUIError, D, type(a2) == "string" and a2 or a1)
end)

-- erwarteter Wert in Kupfer (Marktwert des Materials), nil wenn nicht entzauberbar oder ohne Preise
-- complete = false, wenn für ein Material noch kein Preis bekannt ist; learned = eigene Entzauberungen,
-- shared = geteilte Entzauberungen anderer Spieler. Vor dem Verkauf im AH gehen noch 5 % ab.
function D:GetValue(itemID)
    local y, _, learned, shared = self:Yield(itemID)
    if not y then return nil end
    local value, complete, any = 0, true, false
    for _, e in ipairs(y) do
        local p = self:MatPrice(e[1])
        if p then value = value + e[2] * e[3] * p; any = true
        elseif e[2] >= 0.05 then complete = false end
    end
    if not any then return nil end
    return math.floor(value + 0.5), complete, y, learned or 0, shared or 0
end

-- Items, die im Auktionshaus gerade billiger sind als ihr Entzauberungswert
-- (nach AH-Gebühr beim Verkauf des Materials, auf WoW Forever auch nach der Einstellgebühr
-- von mind. 1 Silber pro Auktion - anteilig pro Stück, das Material wird im Stapel verkauft),
-- nur aktuelle Preise

-- Einstellgebühr für das erwartete Material eines Entzauberns (0 außerhalb von Forever)
-- Forever: 5 % + erwarteter Einzahlungsverlust je Stück (A:FeePerPiece; die Mindest-Einzahlung verteilt sich auf den Stapel)
function D:MaterialFee(yield)
    if not (yield and A:IsForever()) then return 0 end
    local fee = 0
    for _, e in ipairs(yield) do
        local p = self:MatPrice(e[1])
        if p then fee = fee + (e[2] or 0) * (e[3] or 0) * A:FeePerPiece(e[1], p) end
    end
    return math.floor(fee + 0.5)
end
-- Wert nach Gebühren: Forever Wert - (5 % + Einzahlungsverlust je Material), sonst Wert - 5 %
function D:NetValue(v, yield)
    if A:IsForever() then return v - self:MaterialFee(yield) end
    return math.floor(v * (1 - A:CutPct()) + 0.5)
end
-- ------------------------------------------------------------
-- Tatsächlicher Durchschnitt (nur echte Entzauberungen der Gruppe, eigene + geteilte)
--   Ø = Σ (tatsächlich erhaltene Menge je Material × aktueller AH-Preis aus dem letzten Scan) ÷ N
-- ------------------------------------------------------------
D.FEW_DATA = 10          -- unter so vielen Entzauberungen: "(wenig Daten)"

-- Preis eines Materials: zuerst der aktuelle Preis aus dem letzten Scan, sonst der Marktwert
-- zurück: Preis, Alter in Sekunden (nil = Marktwert), Marktwert
-- Preis eines Materials: EIN Wert für Materialblock UND Summe (Befund 9. Nov. 10:31): der reale Wert (A:PriceInfo:
-- eigener Verkauf -> Sofortpreis knapp unter dem günstigsten Angebot, höchstens Median -> Median), Ausreisser
-- (unter 10 % / über 300 % des Medians) zählen nicht.
-- zurück: Preis, Alter in Sekunden (nur bei Quelle "ah"), Marktwert, Quelle ("sale"/"ah"/"market"), unsicher
-- H8/H9 + Entscheid "aktueller Markt" (10.11. 15:54): Materialpreis = realistischer Verkaufspreis aus der AKTUELLEN
-- Preisleiter und dem Absatz (A:ResalePrice), nie über dem aktuellen Scan; kein Deckel und kein Mischen mit dem
-- Marktwert. Der Marktwert ist nur Warnlampe (A:PriceHints: frisch gestiegen / eingebrochen / alt / geschätzt).
-- Quelle ehrlich: "ah" nur mit Scan-Wert, "market" nur ohne jeden Scan.
-- Rückgaben: Wert, Alter, Median, Quelle, unsicher, gesenkt, Zusatz { scan, qty, mv, perDay, ladder, hints }
D.UNSURE_GAP = 0.5
-- WACH-1: Zwischenspeicher NUR für die Dauer einer Kandidaten-Prüfung (DEBuy:Candidates setzt D.matCache und räumt ihn ab;
-- höchstens MAT_CACHE_S gültig, falls die Prüfung abbricht). Sonst rechnet MatPrice wie bisher jedes Mal neu.
D.MAT_CACHE_S = 30
function D:MatPrice(id)
    local mc = self:MatCacheOn()
    if mc then
        local c = mc.m[id]
        if c then return unpack(c, 1, c.n) end
        c = { self:MatPriceRaw(id) }
        c.n = 0
        for k in pairs(c) do if type(k) == "number" and k > c.n then c.n = k end end
        mc.m[id] = c
        return unpack(c, 1, c.n)
    end
    return self:MatPriceRaw(id)
end
function D:MatPriceRaw(id)
    local i = A:PriceInfo(id)
    if not i then return nil end
    local age = (i.source == "ah" and i.currentTime) and math.max(0, time() - i.currentTime) or nil
    local mv = A:GetMarketValue(id)
    local cur = A:GetCurrent(id)
    local F, nF = A:HF(id)
    local last = nF > 0 and A.HistFlatRow(F, nF) or nil
    local extra = { scan = cur, mv = mv, qty = last and not last.u and last.q or nil }
    local v, source, capped, unsure = i.value, i.source, false, i.unsure
    if self.REALISTIC ~= false then
        local lp, _, perDay, lsrc = self:RealisticCap(id)
        extra.perDay, extra.ladder = perDay, lsrc == "leiter"
        -- nie über dem aktuellen Scan (die Angebotsliste kann älter sein als der Scan) - X1 (Befund 0.65.86): aber nur mit
        -- dem BEREINIGTEN Scan-Wert (A:PriceInfo: Ausreisser unter dem Marktwert aussortiert), nie mit dem rohen Minimum.
        -- Ein einzelnes Angebot weit unter der Preisleiter (2c gegen 300c) ist ein Lockangebot oder eine Fehleinstellung:
        -- das kauft ein Sniper sofort weg, es bestimmt nicht unseren Verkaufspreis.
        local clean = (i.source == "ah") and i.value or nil
        if clean and lp and clean < lp * (A.OUTLIER_LOW or 0.1) then clean = nil end
        if lp and clean and lp > clean then lp = clean end
        extra.clean = clean
        if lp and lp > 0 then
            -- ohne Preisleiter gilt der Scan-Wert aus A:PriceInfo (letzter Scan, Lockangebote/Ausreisser schon aussortiert)
            if lsrc == "leiter" then
                if clean then
                    v, source = lp, "ah"
                    if i.value and v < i.value then capped = true end
                else
                    -- ohne bereinigten Scan-Wert: Leiter-Wert ohne Deckel, Quelle "market", unsicher
                    v, source, unsure = lp, "market", true
                end
            end
        end
    end
    if not cur and source == "ah" then source = "market" end
    local okH, hints = pcall(A.PriceHints, A, id)
    extra.hints = okH and hints or {}
    if extra.hints.fresh then source = (source == "ah") and "ah" or source end
    if mv and mv > 0 and cur and math.abs(cur - mv) / mv > self.UNSURE_GAP then unsure = true end
    -- D6: Aufkauf erkannt -> für Kauf-Rechnungen höchstens der Preis vor dem Aufkauf (Verkaufen bleibt beim aktuellen Preis)
    local bo = extra.hints.buyout
    if bo and v and bo.p0 and v > bo.p0 then
        extra.buyout, extra.beforeBuyout = bo, v
        -- AB4b: im Testlog beide Preise (je Item höchstens 1-mal je Stunde)
        self.boLogged = self.boLogged or {}
        if A.Diag and (not self.boLogged[id] or time() - self.boLogged[id] > 3600) then
            self.boLogged[id] = time()
            pcall(A.Diag.Add, A.Diag, "AUFKAUF", string.format("Item %d: Kauf-Rechnung mit %d statt %d (Preis vor dem Aufkauf)", id, bo.p0, v))
        end
        v, capped, unsure = bo.p0, true, true
    end
    return v, age, i.median, source, unsure, capped, extra
end

-- ------------------------------------------------------------
-- TT1317: nach jedem Scan je Entzauber-Material Quelle, Alter und Grund für "unsicher" ins Diagnose-Protokoll
-- (nur Item-IDs und Zahlen). Gründe: kein bestätigter Scan-Preis (unbestätigt/Lockangebot), Preis älter als der Scan,
-- Ausreisser unter dem Marktwert, Scan und Marktwert > 50 % auseinander, Aufkauf.
-- ------------------------------------------------------------
function D:MatReason(id)
    local v, age, _, source, unsure, _, extra = self:MatPrice(id)
    if not v then return nil end
    local why = {}
    local F, nF = A:HF(id)
    if nF > 0 and not A.HUsable(F, nF) then why[#why + 1] = "letzter Scan unbestätigt" end
    local i = A:PriceInfo(id)
    if i and not i.inScan then why[#why + 1] = "nicht im letzten Scan" end
    if i and i.unsure then why[#why + 1] = "Ausreisser unter Marktwert" end
    local mv, cur = extra and extra.mv, extra and extra.scan
    if mv and mv > 0 and cur and math.abs(cur - mv) / mv > self.UNSURE_GAP then
        why[#why + 1] = string.format("Scan %d / Marktwert %d", cur, mv)
    end
    if extra and extra.buyout then why[#why + 1] = "Aufkauf" end
    if unsure and source ~= "ah" and extra and not extra.clean then why[#why + 1] = "kein bereinigter Scan-Wert" end
    return string.format("Item %d · Quelle %s · Alter %s · %s%s", id, tostring(source),
        age and (math.floor(age / 60) .. " Min.") or "-", unsure and "unsicher" or "sicher",
        #why > 0 and (": " .. table.concat(why, ", ")) or "")
end
function D:MatDiag(pause)
    if not A.Diag then return 0 end
    local n = 0
    for id in pairs(MATERIALS) do
        if pause then A:Pause() end
        local ok, line = pcall(self.MatReason, self, id)
        if ok and line then pcall(A.Diag.Add, A.Diag, "MATERIAL-PREIS", line); n = n + 1 end
    end
    return n
end
A:On("SCAN_FINISHED", function()
    if A.TestRoutine and A.TestRoutine.running then return end
    -- 0.65.110 (Ruckeln): in einer Hintergrund-Aufgabe, je Material eine Portion
    A:Job("de:matdiag", function() A:PCall(D.MatDiag, D, true) end)
end)

-- ------------------------------------------------------------
-- E4a (Anweisung Markt-Entzaubern 10.11.): Verzauberkunst-Fertigkeit des Charakters und nötige Fertigkeit je Teil
-- ------------------------------------------------------------
D.ENCHANT_NAMES = { ["Enchanting"] = true, ["Verzauberkunst"] = true, ["Enchantement"] = true, ["Encantamiento"] = true,
    ["Incantamento"] = true, ["Encantamento"] = true, ["Наложение чар"] = true, ["마법부여"] = true, ["附魔"] = true }
-- Fertigkeit oder nil (unbekannt); 0 = kein Verzauberer
function D:EnchantSkill()
    local nLines = _G.GetNumSkillLines
    local info = _G.GetSkillLineInfo
    if nLines and info then
        local okN, n = pcall(nLines)
        local any = false
        for i = 1, (okN and tonumber(n) or 0) do
            local ok, name, header, _, rank = pcall(info, i)
            if ok and name then
                any = true
                if not header and self.ENCHANT_NAMES[name] then return tonumber(rank) or 0 end
            end
        end
        if any then return 0 end
    end
    local prof = _G.GetProfessions
    local pinfo = _G.GetProfessionInfo
    if prof and pinfo then
        local ok, a, b = pcall(prof)
        if ok then
            for _, idx in ipairs({ a, b }) do
                if idx then
                    local okI, name, _, rank = pcall(pinfo, idx)
                    if okI and name and self.ENCHANT_NAMES[name] then return tonumber(rank) or 0 end
                end
            end
            return 0
        end
    end
    return nil
end
-- nötige Fertigkeit zum Entzaubern (Classic-Tabelle nach Itemstufe)
D.SKILL_STEPS = { { 20, 1 }, { 25, 25 }, { 30, 50 }, { 35, 75 }, { 40, 100 }, { 45, 125 }, { 50, 150 }, { 55, 175 }, { 60, 200 },
    { 65, 225 }, { 99, 275 }, { 999, 300 } }
function D:RequiredSkill(ilvl)
    -- V1f KORREKTUR 2 (Nutzer 21.11. 08:47): in WoW Forever entzaubert man mit Verzauberkunst ab Fertigkeit 1 alles
    if A.IsForever and A:IsForever() then return 1 end
    ilvl = tonumber(ilvl) or 1
    for _, st in ipairs(self.SKILL_STEPS) do if ilvl <= st[1] then return st[2] end end
    return 300
end
-- RK4: Verzauberkunst über alle Figuren, die dieses Auktionshaus erreichen (gleicher Server/Fraktion; Characters c.enchant,
-- gemerkt beim Einloggen und bei Fertigkeits-Änderung). nil = nirgends bekannt (dann nichts verstecken). 30 s gemerkt.
D.ACC_SKILL_TTL = 30
function D:AccountEnchantSkill()
    local now = time()
    if self.accSkillT and now - self.accSkillT < self.ACC_SKILL_TTL then return self.accSkill end
    local best = self:EnchantSkill()
    local Ch = A.Chars
    local db = A.db and A.db.chars
    local me = Ch and Ch.Me and Ch:Me()
    for _, c in pairs(type(db) == "table" and db or {}) do
        if type(c) == "table" and type(c.enchant) == "number" and (not me or ((c.realm == nil or c.realm == me.realm)
            and (c.faction == nil or me.faction == nil or c.faction == me.faction))) then
            if best == nil or c.enchant > best then best = c.enchant end
        end
    end
    self.accSkill, self.accSkillT = best, now
    return best
end
-- Weg Entzaubern für dieses Item möglich? (Häkchen in den Einstellungen und Verzauberkunst irgendeiner eigenen Figur)
-- Testroutine: Fertigkeit nicht prüfen (läuft auf jeder Figur), ausser ein Test setzt D.testSkill.
function D:WayDE(itemID)
    if A.WayOn and not A:WayOn("de") then return false end
    local skill = self.testSkill
    if skill == nil then
        if A.InTestRoutine and A:InTestRoutine() then return true end
        skill = self:AccountEnchantSkill()
    end
    if skill == nil then return true end
    if skill <= 0 then return false end
    if not itemID then return true end
    local ok, _, _, _, ilvl = pcall(GetItemInfo, itemID)
    return skill >= self:RequiredSkill(ok and ilvl or 1)
end
-- V1f (Befund 21.11. 08:45, Nutzer 08:43–08:47): wer kann dieses Item entzaubern? "self" = dieser Charakter, "twink" = nur ein
-- anderer Charakter auf dem Konto (gleicher Server/Fraktion), nil = keiner (dann fallen die Entzauber-FUNKTIONEN weg; der Tooltip
-- zeigt die Entzauber-Angaben weiter als Information)
function D:DEWho(itemID)
    if not self:WayDE(itemID) then return nil end
    if self.testSkill == nil and A.InTestRoutine and A:InTestRoutine() then return "self" end
    local own = self.testOwnSkill
    if own == nil then own = self:EnchantSkill() end
    if own == nil then return "self" end                  -- unbekannt: nichts verstecken
    local ok, _, _, _, ilvl = pcall(GetItemInfo, itemID or 0)
    if own > 0 and own >= self:RequiredSkill(ok and ilvl or 1) then return "self" end
    return "twink"
end
function D:CanDisenchant(itemID)
    local skill = self:EnchantSkill()
    if skill == nil then return true end                  -- unbekannt: nicht verstecken
    if skill <= 0 then return false end
    local ok, _, _, _, ilvl = pcall(GetItemInfo, itemID)
    return skill >= self:RequiredSkill(ok and ilvl or 1)
end

-- ------------------------------------------------------------
-- H8 (Befund 10.11.): realistischer Materialwert und eigene Menge
--   RealisticCap: A:ResalePrice ohne Kauf (Angebotsliste, Absatz/Tag), 30 s zwischengespeichert
--   QtyPrice: liegt die eigene Materialmenge über Absatz × 2 Tage, je weitere Tagesmenge eine Stufe tiefer
--             (nächstbilligere Stufe der Angebotsliste, ohne Liste −5 %), höchstens 6 Stufen
--   BatchNet: Netto-Wert je Teil, wenn nParts Teile gekauft und entzaubert werden
-- ------------------------------------------------------------
D.RESALE_TTL = 30
D.QTY_DAYS = 2
D.QTY_MAX_STEPS = 6
D.QTY_STEP = 0.95
D.resaleCache = D.resaleCache or {}
function D:RealisticCap(id)
    local now = time()
    local c = self.resaleCache[id]
    if c and now - c.t < self.RESALE_TTL then return c.p, c.ladder, c.perDay, c.src end
    c = nil
    local p, ladder, perDay
    if A.ResalePrice and A.OfferLadder and A.ResaleBasis then
        local okL, l = pcall(A.OfferLadder, A, id)
        ladder = okL and l or nil
        local okB, pd, h = pcall(A.ResaleBasis, A, id)
        perDay = okB and pd or nil
        local ok, rp, src = pcall(A.ResalePrice, A, id, nil, nil, ladder, perDay, okB and h or 24, true)
        if ok and type(rp) == "number" then p = math.floor(rp); c = src end
    end
    self.resaleCache[id] = { t = now, p = p, ladder = ladder, perDay = perDay, src = c }
    return p, ladder, perDay, c
end

-- Stückpreis bei matQty eigenen Stück: Preis, Stufen tiefer
function D:QtyPrice(id, matQty)
    local p = self:MatPrice(id)
    if not p then return nil end
    if not matQty or matQty <= 0 then return p, 0 end
    local _, ladder, perDay = self:RealisticCap(id)
    if not perDay or perDay <= 0 then return p, 0 end
    local over = matQty - perDay * self.QTY_DAYS
    if over <= 0 then return p, 0 end
    local k = math.min(self.QTY_MAX_STEPS, math.ceil(over / perDay - 1e-9))
    local lower, seen = {}, {}
    for _, st in ipairs(ladder or {}) do
        local q = (st[1] or 0) - 1
        if q >= 1 and q < p and not seen[q] then seen[q] = true; lower[#lower + 1] = q end
    end
    table.sort(lower, function(a, b) return a > b end)
    local price = p
    for s = 1, k do
        if lower[s] then price = lower[s] else price = math.max(1, math.floor(price * self.QTY_STEP + 0.5)) end
    end
    return price, k
end

-- Material je Teil: { { id = , per = Ø-Menge je Teil, chance = } }, "actual"/"estimate"
function D:PerPartMats(itemID)
    local av, acomplete, n, rows = self:ActualValue(itemID)
    local out = {}
    if av and acomplete and n and n >= self.FEW_DATA then
        for _, r in ipairs(rows or {}) do out[#out + 1] = { id = r.id, per = r.total / n, chance = r.times / n } end
        return out, "actual"
    end
    local y = self:Yield(itemID)
    if not y then return nil end
    for _, e in ipairs(y) do
        if (e[2] or 0) > 0 then out[#out + 1] = { id = e[1], per = e[2] * e[3], chance = e[2] } end
    end
    return out, "estimate"
end

-- Netto-Wert je Teil bei nParts Teilen: netto, brutto, vollständig, Stufen tiefer (höchste)
-- D3 / X4: EINE Funktion für den Wert je Teil bei einer geplanten Kaufmenge (Markt "Entzaubern", Sammelkauf, Tooltip):
-- Netto je Teil aus D:DealValue, bei mehr als einem Teil höchstens D:BatchNet (eigene Materialmenge senkt den Preis)
-- MP2 (Befund 11.11. 19:45): das Material mit dem grössten Anteil am Entzauberwert; zu alt (> 6 Std., oder ohne
-- aktuellen Preis) = keine Kauf-Entscheidung. Zurück: veraltet?, Material, Alter in Std. (nil = kein aktueller Preis)
D.STALE_HOURS = 6
D.STALE_SHARE = 0.25
function D:StaleMain(itemID)
    local mats = self:PerPartMats(itemID)
    if not mats or #mats == 0 then return false end
    local main, best, total = nil, -1, 0
    local shares = {}
    for i, m in ipairs(mats) do
        local okP, p = pcall(self.MatPrice, self, m.id)
        local share = (okP and p or 0) * (m.per or 0)
        shares[i] = share
        total = total + share
        if share > best then main, best = m.id, share end
    end
    if not main then return false end
    -- AB5: nicht nur das Hauptmaterial - jedes Material mit >= 25 % Anteil am Wert muss frisch sein
    local worst, worstH = nil, nil
    for i, m in ipairs(mats) do
        if m.id == main or (total > 0 and shares[i] / total >= self.STALE_SHARE) then
            local _, _, t = A:GetCurrent(m.id)
            if not t then return true, m.id, nil end
            local h = (time() - t) / 3600
            if not worstH or h > worstH then worst, worstH = m.id, h end
        end
    end
    return worstH > self.STALE_HOURS, worst, math.floor(worstH + 0.5)
end

-- WACH-1: während einer Kandidaten-Prüfung (D.matCache aktiv) je Entzauber-Gruppe und Menge nur einmal rechnen - der Wert hängt nur
-- an der Gruppe (Prior-Schlüssel: Ergebnisse, Chancen, Korrektur) und den Materialpreisen, nicht am einzelnen Item
function D:PlannedValue(itemID, nParts)
    local mc = self:MatCacheOn()
    if mc then
        local _, key = self:Prior(itemID)
        if key then
            mc.pv = mc.pv or {}
            local k = key .. ":" .. tostring(nParts)
            local c = mc.pv[k]
            if not c then c = { self:PlannedValueRaw(itemID, nParts) }; c.n = 4; mc.pv[k] = c end
            return unpack(c, 1, c.n)
        end
    end
    return self:PlannedValueRaw(itemID, nParts)
end
function D:PlannedValueRaw(itemID, nParts)
    local v, net, complete, basis, n = self:DealValue(itemID)
    if not (v and complete and net and net > 0) then return nil end
    -- MP2: nie mit veralteten Materialpreisen kaufen (Markt "Entzaubern", Sammelkauf)
    local okS, stale = pcall(self.StaleMain, self, itemID)
    if okS and stale then return nil, "stale" end
    if nParts and nParts > 1 then
        local okB, bn = pcall(self.BatchNet, self, itemID, nParts)
        if okB and bn and bn < net then net = bn end
    end
    if net <= 0 then return nil end
    return net, basis, n, v
end

-- ST2 (anweisung-strategie-entzaubern-grenzen): "Lohnt bis" je Teil mit frischen Preisen (nil, wenn veraltet/unbekannt)
function D:WorthLimit(itemID)
    local net, _, n = self:PlannedValue(itemID, 1)
    if not net then return nil end
    local MK = A.Core
    if MK and MK.LimitFromNet then return MK:LimitFromNet(net, n, itemID) end     -- RK2-A: eine Rechnung
    local DEB = A.DEBuy
    local pct = (DEB and DEB.DEMinRoi and DEB:DEMinRoi(itemID)) or A.DE_MIN_GAIN or 30
    return math.floor(net / (1 + pct / 100))
end
-- RK2-A: Kaufgrenze im Markt "Entzaubern" (dieselbe Rechnung wie FindDeals, für den Selbsttest)
function D:DealLimit(itemID)
    local v, net, _, _, n = self:DealValue(itemID)
    if not (v and net) then return nil end
    local MK = A.Core
    if MK then return MK:LimitFromNet(net, n, itemID) end           -- RK4/S2-B3: nil bleibt nil (nie ersatzweise netto)
    return net
end
-- "[Entzaubern lohnt]" nur, wenn der Preis höchstens "Lohnt bis" ist (frische Preise)
function D:WorthMark(itemID, price)
    local lim = price and self:WorthLimit(itemID)
    return lim ~= nil and price <= lim
end

-- ST1: unabhängige Nachrechnung einer Gruppe aus den Scan-Preisen (günstigstes − 1c) × Chance × Ø Menge;
-- Vergleich mit dem Wert, den Tooltip/Markt/Sniper verwenden (D:MatPrice). Zurück: Tabelle { ref, ours, dev, worst, mats }
function D:ReferenceCheck(key)
    local y = self:YieldForKey(key) or self:PriorForKey(key)
    if not y then return nil end
    local ref, ours, mats, oldest = 0, 0, {}, 0
    for _, e in ipairs(y) do
        local id, ch, avg = e[1], e[2] or 0, e[3] or 1
        if ch > 0 then
            local cur, _, t = A:GetCurrent(id)
            local p, age, _, src = self:MatPrice(id)
            if cur then ref = ref + ch * avg * math.max(0, cur - 1) end
            if p then ours = ours + ch * avg * p end
            local a = t and (time() - t) or nil
            if a and a > oldest then oldest = a end
            mats[#mats + 1] = { id = id, cur = cur, p = p, src = src, age = a, dev = (cur and p and cur > 1) and (p / (cur - 1) - 1) or nil }
        end
    end
    if ref <= 0 then return nil end
    table.sort(mats, function(a, b) return math.abs(a.dev or 0) > math.abs(b.dev or 0) end)
    local net = math.floor(ref * (1 - A:CutPct()) + 0.5)
    local DEB = A.DEBuy
    local pct = (DEB and DEB.DEMinRoi and DEB:DEMinRoi()) or A.DE_MIN_GAIN or 30
    return { ref = math.floor(ref + 0.5), ours = math.floor(ours + 0.5), dev = ours / ref - 1, worst = mats[1], mats = mats,
        net = net, limit = (A.Core and A.Core.LimitFromNet) and A.Core:LimitFromNet(net, nil) or math.floor(net / (1 + pct / 100)), oldest = oldest }   -- RK2-B (c)
end

function D:BatchNet(itemID, nParts)
    nParts = math.max(1, math.floor(nParts or 1))
    local mats = self:PerPartMats(itemID)
    if not mats or #mats == 0 then return nil end
    local gross, fee, complete, steps, any = 0, 0, true, 0, false
    local forever = A:IsForever()
    for _, m in ipairs(mats) do
        local p, k = self:QtyPrice(m.id, m.per * nParts)
        if p then
            any = true
            gross = gross + m.per * p
            fee = fee + m.per * (forever and A:FeePerPiece(m.id, p) or p * A:CutPct())
            if (k or 0) > steps then steps = k end
        elseif (m.chance or 0) >= 0.05 then complete = false end
    end
    if not any then return nil end
    local f = self:CorrectionFor(itemID)                  -- 0.65.111 S1: erzielbarer Preis
    if f < 1 then gross, fee = gross * f, fee * f end
    return math.floor(gross - fee + 0.5), math.floor(gross + 0.5), complete, steps
end

-- tatsächlicher Ø-Wert: v, complete, N, rows, nOwn, nShared (nil, wenn N = 0)
-- rows: { id, times, total, price, age, mv, share } (share = Anteil am Ø in Kupfer)
function D:ActualValue(itemID)
    local _, key = self:Prior(itemID)
    if not key then return nil end
    local nOwn, nShared, mats = self:Combined(key)
    local n = nOwn + nShared
    if n <= 0 then return nil end
    local rows, value, complete = {}, 0, true
    for id, m in pairs(mats) do
        if (m.times or 0) > 0 then
            local price, age, mv, src, unsure, _, extra = self:MatPrice(id)
            local share = price and (m.total * price / n) or nil
            if share then value = value + share else complete = false end
            table.insert(rows, { id = id, times = m.times, total = m.total, price = price, age = age, mv = mv, share = share,
                source = src, unsure = unsure, extra = extra })
        end
    end
    table.sort(rows, function(a, b) return (a.share or 0) > (b.share or 0) end)
    return math.floor(value + 0.5), complete, n, rows, nOwn, nShared
end

-- nach Gebühren für den tatsächlichen Ø: Forever je Material 5 % + Einzahlungsrisiko je Stück (A:FeePerPiece), sonst 5 %
function D:ActualNet(v, rows, n)
    if not A:IsForever() then return math.floor(v * (1 - A:CutPct()) + 0.5) end
    local fee = 0
    for _, r in ipairs(rows or {}) do
        if r.price then fee = fee + (r.total / n) * A:FeePerPiece(r.id, r.price) end
    end
    return v - math.floor(fee + 0.5)
end

-- Aufschlüsselung des geschätzten Werts (Tabelle verrechnet mit Ergebnissen): je Material
-- { id, chance, avg, price, age, mv, share } mit share = Chance × Ø-Menge × Marktwert (genau wie D:GetValue)
function D:EstimateRows(itemID)
    local y = self:Yield(itemID)
    if not y then return nil end
    local rows = {}
    for _, e in ipairs(y) do
        if e[2] > 0 then
            local price, age, mv, src, unsure, _, extra = self:MatPrice(e[1])
            table.insert(rows, { id = e[1], chance = e[2], avg = e[3], min = e[4], max = e[5], price = price, age = age, mv = mv, source = src, unsure = unsure, extra = extra,
                share = price and (e[2] * e[3] * price) or nil })
        end
    end
    table.sort(rows, function(a, b) return (a.share or 0) > (b.share or 0) end)
    return rows
end

-- Wert für Schnäppchen: tatsächlich, wenn genug Daten (N >= 10) und alle Preise da sind, sonst geschätzt
-- zurück: Wert, netto, vollständig, "actual"/"estimate", N
-- 0.65.111 S1 (TB110, Entscheid des Nutzers 15:25): ERZIELBARER Materialpreis. Gemessen: Beute/Vorhersage 2:4:a 0,60 =
-- Chance 1,05 × Menge 1,00 × Preis 0,57 - die angenommenen Materialpreise (tiefstes Angebot) liegen ~43 % über dem, was
-- die Entzauberungen tatsächlich einbringen. Korrektur je Gruppe = gemessener Preis-Faktor (Median Beute/Vorhersage
-- geteilt durch Chance × Menge), nur nach unten, ab 20 Fällen, höchstens bis 0,30; ab 0,90 keine Korrektur.
-- Die Vorhersagen im Prognose-Journal bleiben UNKORRIGIERT (raw), sonst misst die Korrektur sich selbst.
D.CORR_MIN_N, D.CORR_FLOOR, D.CORR_OK = 30, 0.30, 0.90   -- KF2: ab 30 Fällen
D.EXTRA_MIN_N, D.EXTRA_MAX = 100, 1.10                       -- MR1-V: Hochrechnung ab 100 eigenen Entzauberungen, höchstens +10 %
D.corrCache = D.corrCache or {}
function D:PriceCorrection(key)
    if not key then return 1, nil end
    if self.corrTest and self.corrTest[key] then return self.corrTest[key], "korrigiert" end
    local c = self.corrCache[key]
    if c and time() - c.t < 300 then return c.f, c.src end
    local f, src = 1, nil
    local Fc = A.Forecast
    local ready = false
    if Fc and Fc.EvalCached and Fc.DEFactors then
        local ok, R = pcall(Fc.EvalCached, Fc)
        ready = ok and R ~= nil
        local x = ok and R and R.D and R.D[key]
        -- KF2: Faktor = Summe Beute / Summe Vorhersage (ab CORR_MIN_N Fällen), nie Median über Zufallsbeute
        if x and (x.n or 0) >= self.CORR_MIN_N and (x.sEv or 0) > 0 then
            local pf = (x.sLv or 0) / x.sEv
            if pf < self.CORR_OK then f, src = math.max(self.CORR_FLOOR, pf), "korrigiert" end
        elseif ok and R and R.D then
            -- MR1-V (Entscheid des Nutzers 16:28): ungemessene Gruppe -> HOCHGERECHNET aus den gemessenen Gruppen
            -- (Summe Beute / Summe Vorhersage über alle Gruppen mit ≥ CORR_MIN_N Fällen, Summe/Summe), begrenzt auf
            -- [CORR_FLOOR, EXTRA_MAX]; erst ab EXTRA_MIN_N eigenen Entzauberungen insgesamt
            local sLv, sEv, nAll = 0, 0, 0
            for _, g in pairs(R.D) do
                if type(g) == "table" and (g.n or 0) >= self.CORR_MIN_N and (g.sEv or 0) > 0 then
                    sLv, sEv, nAll = sLv + (g.sLv or 0), sEv + g.sEv, nAll + g.n
                end
            end
            if sEv > 0 and nAll >= self.EXTRA_MIN_N then
                f, src = math.max(self.CORR_FLOOR, math.min(self.EXTRA_MAX, sLv / sEv)), "hochgerechnet"
                self.extraN = nAll
            end
        end
    end
    -- erst merken, wenn die Auswertung da ist (sonst gälte 5 Min. lang "keine Korrektur")
    if ready then self.corrCache[key] = { t = time(), f = f, src = src } end
    return f, src
end
function D:CorrectionFor(itemID)
    local _, key = self:Prior(itemID)
    return self:PriceCorrection(key)
end
function D:DealValue(itemID, raw)
    local av, acomplete, n, rows = self:ActualValue(itemID)
    local v, net, complete, basis
    if av and acomplete and n >= self.FEW_DATA then
        v, net, complete, basis = av, self:ActualNet(av, rows, n), true, "actual"
    else
        local yield
        v, complete, yield = self:GetValue(itemID)
        if not v then return nil end
        net, basis, n = self:NetValue(v, yield), "estimate", n or 0
    end
    if raw then return v, net, complete, basis, n end
    local f, src = self:CorrectionFor(itemID)
    -- MR1-V: hochgerechnet nur für Schätzungen (ungemessene Gruppe), dann auch nach oben; sonst nur nach unten (KF2)
    if (f < 1) or (src == "hochgerechnet" and basis == "estimate" and f ~= 1) then
        v, net = math.floor(v * f + 0.5), math.floor(net * f + 0.5)
        if src == "hochgerechnet" and basis == "estimate" then basis = "hochgerechnet" end
    end
    return v, net, complete, basis, n, f
end

function D:FindDeals()
    local out = {}
    local Ln = A.Learn
    if not A.db then return out end
    local fresh = time() - A.FRESH_SECONDS
    local MK = A.Core
    if MK and MK.BeginBatch then MK:BeginBatch() end
    for itemID in pairs(A.db.marketData) do
        A:Pause()           -- F3 (10.11.): 5400 Items ohne Pause = 160-390 ms in einem Frame ("Heute tun")
        local price, qty, t = A:GetCurrent(itemID)
        if price and t and t >= fresh then
            local v, net, complete, basis, n = self:DealValue(itemID)
            A:Pause()           -- TB138b-5 (längster Schritt 10,4 ms hier): Wert und Kaufgrenze in getrennten Portionen
            -- Stufe 2 L7: Kaufgrenze = erwarteter Netto-Wert × (1 − Marge)
            -- RK2-A: Kaufgrenze aus der EINEN Rechnung "Lohnt bis" (A.Core:LimitFromNet)
            local limit = net
            if v and MK then limit = MK:LimitFromNet(net, n, itemID) or 0          -- RK4/S2-B3: ohne "Lohnt bis" kein Angebot
            elseif v and Ln and Ln.BuyLimit then limit = Ln:BuyLimit(net, "d") or net end
            -- H8: eigene Menge senkt den Materialpreis (alle Angebote dieses Items) - nur für Kandidaten rechnen
            if v and complete and limit > price and (qty or 1) > 1 then
                A:Pause()
                local bn = self:BatchNet(itemID, qty)
                if bn and bn < net then
                    net = bn
                    if MK then limit = MK:LimitFromNet(net, n, itemID) or 0
                    else limit = (Ln and Ln.BuyLimit) and (Ln:BuyLimit(net, "d") or net) or net end
                end
            end
            if v and complete and limit > price then
                table.insert(out, { itemID = itemID, name = A:GetItemName(itemID), price = price, value = v, basis = basis, n = n,
                                    net = net, profit = net - price, pct = (net - price) / net * 100, quantity = qty or 1, limit = limit })
            end
        end
    end
    if MK and MK.EndBatch then MK:EndBatch() end
    return out
end


-- ============================================================
-- MP1 (Befund 11.11. 19:45): Materialpreise "alt (vor 25 Std.)" trotz Scan vor 2 Min. Der Schnell-Vollscan liefert
-- Waren (Staub, Essenzen, Splitter) je nach Client nicht mit. Darum: am offenen AH die Preise der Entzauber-
-- Materialien frisch holen, wenn sie älter als 30 Min. sind (eine Waren-Suche je Item über die Preisprüfung, höchstens
-- 15 Items, je Item höchstens alle 30 Min.). Protokoll PREIS-ALT mit Scan-Art, Waren im Vollscan und Alter.
-- ============================================================
D.MAT_REFRESH_AGE = 30 * 60
D.MAT_REFRESH_MAX = 15
D.matRefreshAt = D.matRefreshAt or {}
function D:MatIDs()
    local w = {}
    for _, st in pairs(A.db and A.db.deStats or {}) do
        for id, m in pairs(st.mats or {}) do w[id] = (w[id] or 0) + (m.times or 0) end
    end
    local out = {}
    for id, n in pairs(w) do out[#out + 1] = { id = id, n = n } end
    table.sort(out, function(a, b) return a.n > b.n end)
    return out
end
function D:RefreshMats(why)
    if not (A:IsAHOpen() and A.Seller) or A:Simulated() then return 0 end
    local now, n, ages = time(), 0, {}
    for _, m in ipairs(self:MatIDs()) do
        if n >= self.MAT_REFRESH_MAX then break end
        local _, _, t = A:GetCurrent(m.id)
        local age = t and (now - t) or nil
        if #ages < 3 then ages[#ages + 1] = string.format("%d: %s", m.id, age and string.format("%.1f Std.", age / 3600) or "nie") end
        if (not age or age > self.MAT_REFRESH_AGE) and now - (self.matRefreshAt[m.id] or 0) > self.MAT_REFRESH_AGE then
            self.matRefreshAt[m.id] = now
            if A.Seller.CheckPriceBg then A.Seller:CheckPriceBg(m.id) else A.Seller:CheckPrice(m.id, nil, true) end   -- AB1: hinten an
            n = n + 1
        end
    end
    if A.Diag and #ages > 0 then
        local VS = A.FullScan
        pcall(A.Diag.Add, A.Diag, "PREIS-ALT", string.format("%s · letzter Scan %s · Waren im Vollscan %s · Hauptmaterialien %s · %d frisch geholt",
            tostring(why or "-"), A.lastScanKind or "-", VS and tostring(VS.lastCommodities or "-") or "-",
            table.concat(ages, ", "), n))
    end
    return n
end
A:On("SCAN_FINISHED", function()
    if C_Timer and C_Timer.After then C_Timer.After(3, function() pcall(D.RefreshMats, D, "nach Scan") end) end
end)
A:On("AH_STATE", function()
    if A:IsAHOpen() and C_Timer and C_Timer.After then C_Timer.After(5, function() pcall(D.RefreshMats, D, "AH offen") end) end
end)
