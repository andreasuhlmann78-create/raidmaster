if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - Sammelkauf zum Entzaubern (ab 0.65.34, Anweisung "Sammelkauf zum Entzaubern", bewusst einfach)
--
-- Reiter Kaufen -> Einkauf: Knopf "Entzaubern lohnt" zeigt aus der letzten Suche nur Teile (Rüstung/Waffen, nicht
-- stapelbar), deren Entzauberungswert den Kaufpreis um mindestens die Mindestrendite übersteigt (Standard 20 %),
-- und mindestens 10c Gewinn je Teil. Sortiert nach Gewinn; Spalten Gewinn und Rendite %.
-- Kaufen wie beim Sniper: jede Mausrad-Raste über der Liste bzw. ein Klick auf "Nächstes kaufen" kauft das nächste
-- Teil von oben. Vor jedem Kauf: Angebot noch da, Preis nicht höher - sonst überspringen. In WoW Forever muss jeder
-- Einzelkauf aus einem Tastendruck kommen: eine Raste je Teil (erste Raste lädt die Angebote, falls nötig).
-- Grenzen: "höchstens X Gold" (Standard 5g), "Mindestrendite %" (Standard 20 %), fest 10c Gewinn je Teil.
-- Stopp bei Grenze, vollen Taschen oder Kampf. Unter 10 echten Entzauberungen der Gruppe: Wert minus 10 %.
-- Nur auf Klick/Raste, nie automatisch; Protokoll KAUF (ohne Namen). Kein Fertigkeits-Filter (Forever: ab
-- Verzauberkunst 1 ist alles entzauberbar).
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local DB = A.DEBuy or {}
A.DEBuy = DB

DB.MIN_PROFIT = 10              -- fest: mindestens 10c Gewinn je Teil
DB.SAFETY = 0.10                -- Abschlag unter 10 echten Entzauberungen
DB.SCAN_ROW_MAX_AGE = 1800      -- S8: Scan-Zeilen ("~") höchstens 30 Min. alt
DB.MAX_STEPS = { 10000, 50000, 100000, 200000, 500000 }   -- 1g, 5g, 10g, 20g, 50g
DB.ROI_STEPS = { 10, 20, 30, 50, 100 }

DB.session = DB.session or { bought = 0, paid = 0, expected = 0 }
DB.skipped = DB.skipped or {}   -- [itemID] = true: in dieser Sitzung übersprungen (weg/teurer)

local function Settings() return A.db and A.db.settings or {} end
function DB:MaxGold()
    local v = Settings().deBuyMax
    return (type(v) == "number" and v > 0) and v or 50000
end
function DB:MinRoi()
    local v = Settings().deBuyRoi
    return (type(v) == "number" and v >= 0) and v or 20
end
-- DE30 (Nutzer 22:57): Mindestgewinn für den Weg ENTZAUBERN nie unter A.DE_MIN_GAIN (30 %); die allgemeine
-- Einstellung (Verkaufs-Untergrenze u. a.) bleibt davon unberührt
function DB:DEMinRoi()
    local floor = A.DE_MIN_GAIN or 30
    return math.max(self:MinRoi(), floor)
end
local function Cycle(list, cur)
    local idx = 1
    for i, v in ipairs(list) do if v == cur then idx = i end end
    return list[idx % #list + 1]
end
function DB:CycleMax() A.db.settings.deBuyMax = Cycle(self.MAX_STEPS, self:MaxGold()); return A.db.settings.deBuyMax end
function DB:CycleRoi() A.db.settings.deBuyRoi = Cycle(self.ROI_STEPS, self:MinRoi()); return A.db.settings.deBuyRoi end

-- Entzauberungswert für den Kauf (nach Gebühren), mit Sicherheitsabschlag unter 10 echten Entzauberungen
-- H8: nParts = so viele Teile kauft der Sammelkauf höchstens (eigene Materialmenge senkt den Preis)
function DB:Value(itemID, nParts)
    local D = A.Disenchant
    if not (D and D.PlannedValue) then return nil end
    local net, basis, n = D:PlannedValue(itemID, nParts)          -- D3: dieselbe Funktion wie der Markt
    if not net then return nil end
    -- Stufe 2 L7: Sicherheitsmarge aus dem gemessenen Fehler (mind. 10 %, unter 20 Käufen 20 %) statt des festen Abschlags
    -- RK2-A: "Lohnt bis" aus der EINEN Rechnung (Mindestrendite und gelernte Sicherheitsmarge, die strengere gilt)
    local MK = A.Core
    if MK and MK.LimitFromNet then return MK:LimitFromNet(net, n), basis, n, net end
    local Ln = A.Learn
    if Ln and Ln.On and Ln:On() then
        local okM, lim = pcall(Ln.BuyLimit, Ln, net, "d")
        if okM and lim then return lim, basis, n end
    end
    if (n or 0) < (D.FEW_DATA or 10) then net = math.floor(net * (1 - self.SAFETY) + 0.5) end
    return net, basis, n
end

-- Rechnung für ein Teil zum Preis price: Gewinn, Rendite in %, ok (über beiden Grenzen)
-- nParts (H8): Standard = so viele Teile, wie das Budget (Höchstens) zu diesem Preis hergibt
function DB:PartsFor(price)
    if not (price and price > 0) then return 1 end
    return math.max(1, math.floor(self:MaxGold() / price))
end
-- X4 (Befund 0.65.86): ohne Angabe gilt die tatsächlich geplante Kaufmenge der letzten Kandidatenliste (lastPlanned),
-- nicht Budget / Preis eines einzelnen Teils
function DB:Judge(itemID, price, nParts)
    local value = self:Value(itemID, nParts or self.lastPlanned or 1)
    if not (value and price and price > 0) then return nil end
    local profit = value - price
    local roi = profit / price * 100
    -- RK2-A: value ist schon "Lohnt bis" (Mindestrendite eingerechnet) - nicht ein zweites Mal abziehen
    if A.Core and A.Core.LimitFromNet then return profit, roi, profit >= self.MIN_PROFIT, value end
    return profit, roi, profit >= self.MIN_PROFIT and roi >= self:DEMinRoi(), value
end

-- Kandidaten aus der letzten Suche im Einkauf (B.results): nur nicht stapelbare, entzauberbare Teile
function DB:Candidates(rows)
    rows = rows or (A.Buy and A.Buy.results) or {}
    local out = {}
    local D = A.Disenchant
    -- X4: geplante Kaufmenge = Teile mit Preis <= Wert (für 1 Teil), billigste zuerst, solange das Budget reicht.
    -- Der Sammelkauf kauft von oben nach unten und stoppt - nur diese Menge senkt den Wert der Materialien.
    local eligible, pre = {}, {}
    for _, r in ipairs(rows) do
        local id = r.itemID
        -- S8: "~"-Zeilen aus dem Scan, älter als 30 Min., zählen nicht (nur grau in der Liste)
        local stale = r.fromScan and time() - r.fromScan > self.SCAN_ROW_MAX_AGE
        if id and r.price and r.price > 0 and not stale and not self.skipped[id] and not A:IsCommodityItem(id) and D and D:Prior(id) then
            eligible[#eligible + 1] = r
            local v1 = self:Value(id, 1)
            if v1 and r.price <= v1 then pre[#pre + 1] = r.price end
        end
    end
    table.sort(pre)
    local planned, sum = 0, 0
    for _, price in ipairs(pre) do
        if sum + price > self:MaxGold() then break end
        sum, planned = sum + price, planned + 1
    end
    self.lastPlanned = math.max(1, planned)
    for _, r in ipairs(eligible) do
        local id = r.itemID
        do
            local profit, roi, ok, value = self:Judge(id, r.price, self.lastPlanned)
            if ok then
                out[#out + 1] = { itemID = id, itemKey = r.itemKey, name = r.name or A:GetItemName(id), price = r.price,
                    qty = r.qty, quality = r.quality, profit = profit, roi = roi, value = value }
            end
        end
    end
    table.sort(out, function(a, b)
        if a.profit ~= b.profit then return a.profit > b.profit end
        return a.itemID < b.itemID
    end)
    return out
end

local function FreeSlots()
    if A.Mailer and A.Mailer.FreeSlots then return A.Mailer.FreeSlots() end
    return 1
end

-- billigstes kaufbares Einzelangebot (fremd, Sofortkauf, nicht schon gekauft)
local function BestListing(listings)
    local best
    for _, l in ipairs(listings or {}) do
        if l.auctionID and l.buyout and l.buyout > 0 and not l.own and not l.used and (l.qty or 1) == 1 then
            if not best or l.buyout < best.buyout then best = l end
        end
    end
    return best
end

-- Ein Tastendruck / eine Raste / ein Klick: das nächste Teil von oben
-- Rückgabe: ok, Meldung, Zustand ("loading", "bought", "skipped", "stop", "empty")
function DB:Next()
    if not A:IsAHOpen() then return false, L["Bitte zuerst das Auktionshaus öffnen."], "stop" end
    if A:InCombat() then return false, L["Im Kampf wird nichts gekauft."], "stop" end
    local B = A.Buy
    local list = self:Candidates()
    local top = list[1]
    if not top then return false, L["Nichts, was sich zum Entzaubern lohnt (Mindestrendite, mind. 10c Gewinn)."], "empty" end
    if self.inFlight and GetTime() - self.inFlight.t > 15 then self.inFlight = nil end      -- keine Antwort: vergessen
    if self.inFlight then return false, L["Kauf läuft noch - gleich nochmal."], "loading" end
    if self.session.paid + top.price > self:MaxGold() then
        return false, string.format(L["Grenze erreicht: höchstens %s."], A:FormatMoney(self:MaxGold())), "stop"
    end
    -- Stufe 2 L7: Tagesbudget Entzaubern, solange die Trefferquote unter 60 % liegt
    local Ln = A.Learn
    if Ln and Ln.BudgetLeft then
        local okB, left = pcall(Ln.BudgetLeft, Ln, "d")
        if okB and left and left < top.price then
            return false, string.format(L["Tagesbudget Entzaubern erreicht (%s) - die Trefferquote ist noch unter 60 %%."], A:FormatMoney(left)), "stop"
        end
    end
    if FreeSlots() <= 0 then return false, L["Taschen voll."], "stop" end
    -- Angebote des Teils laden (erste Raste), danach kaufen
    local d = B and B.detail
    if not (d and d.itemID == top.itemID and not d.loading and d.listings) then
        if B.search or (B.wanted and B.wanted.kind == "items") then return false, L["Angebote werden geladen - gleich nochmal."], "loading" end
        B:Open(top.itemKey or top.itemID, top.name)
        return true, string.format(L["Angebote für %s werden geladen - nochmal drehen/klicken zum Kaufen."], top.name or "?"), "loading"
    end
    local l = BestListing(d.listings)
    -- Angebot weg oder teurer als gelistet: überspringen
    if not l or l.buyout > top.price then
        self.skipped[top.itemID] = true
        self:Log("ÜBERSPRUNGEN", top.itemID, l and l.buyout or 0, top.value)
        return false, string.format(L["Übersprungen: %s (Angebot weg oder teurer)."], top.name or "?"), "skipped"
    end
    local profit, roi, ok, value = self:Judge(top.itemID, l.buyout)
    if not ok then
        self.skipped[top.itemID] = true
        return false, string.format(L["Übersprungen: %s (lohnt nicht mehr)."], top.name or "?"), "skipped"
    end
    -- offener Punkt 4: erst merken ("ausstehend"), gezählt wird bei der Bestätigung des Servers (BUY_PURCHASE_RESULT)
    self.inFlight = { t = GetTime(), itemID = top.itemID, paid = l.buyout, value = value, profit = profit, roi = roi, name = top.name }
    local okB, msg = B:BuyItem(l)
    if not okB then self.inFlight = nil; return false, msg, "stop" end
    -- kein weiteres Angebot zu diesem Preis: Teil ist erledigt, die nächste Raste nimmt das nächste Teil
    local nxt = BestListing(d.listings)
    if not nxt or nxt.buyout > top.price then self.skipped[top.itemID] = true end
    A:Fire("DEBUY_CHANGED")
    return true, string.format(L["Kauf gesendet: %s für %s (erwartet +%s, %d %%)."], top.name or "?", A:FormatMoney(l.buyout),
        A:FormatMoney(profit), math.floor(roi + 0.5)), "bought"
end

-- Antwort des Servers auf den Kauf (Buy.lua): erst jetzt zählen, eintragen und protokollieren
function DB:OnPurchaseResult(ok)
    local f = self.inFlight
    if not f then return end
    self.inFlight = nil
    if ok then
        self.session.bought = self.session.bought + 1
        self.session.paid = self.session.paid + f.paid
        self.session.expected = self.session.expected + f.profit
        -- für das Entzauber-Fenster (zuerst gekaufte Teile) und die Abrechnung in der Buchhaltung
        A.db.deBuys = A.db.deBuys or {}
        table.insert(A.db.deBuys, { t = time(), itemID = f.itemID, paid = f.paid, value = f.value })
        while #A.db.deBuys > 500 do table.remove(A.db.deBuys, 1) end
        self:Log("KAUF", f.itemID, f.paid, f.value)
    else
        self.skipped[f.itemID] = true
    end
    A:Fire("DEBUY_CHANGED")
end
A:On("BUY_PURCHASE_RESULT", function(ok) DB:OnPurchaseResult(ok) end)

-- ------------------------------------------------------------
-- E1 Entzauber-Wächter (ab 0.65.36): der Wächter sucht jede zweite Runde Waffen/Rüstung und meldet, wenn sich
-- neue Teile zum Entzaubern lohnen (dieselben Grenzen). Chat + Bildschirm, höchstens einmal pro Minute, nie im
-- Kampf, abschaltbar. Kauft NIE selbst.
-- ------------------------------------------------------------
DB.WATCH_GAP = 60
DB.seen = DB.seen or {}         -- [itemID] = Preis, schon gemeldet
DB.lastAlert = DB.lastAlert or -1000

function DB:WatchEnabled()
    return Settings().deWatch ~= false
end
function DB:ToggleWatch()
    A.db.settings.deWatch = not self:WatchEnabled()
    A:Fire("DEBUY_CHANGED")
    return self:WatchEnabled()
end

local function Clock() local f = A:Global("GetTime"); return f and f() or 0 end

-- rows: { itemID, itemKey, price } aus einer Wächter-Runde. Rückgabe: gemeldeter Text oder nil
function DB:WatchCheck(rows)
    if not self:WatchEnabled() then return nil end
    if A:InCombat() then return nil end
    local list = self:Candidates(rows)
    self.watchList = list
    for _, c in ipairs(list) do
        local old = self.seen[c.itemID]
        if not old or c.price < old then self.pending = true end
        self.seen[c.itemID] = (old and old < c.price) and old or c.price
    end
    if not self.pending or #list == 0 then return nil end
    local now = Clock()
    if now - self.lastAlert < self.WATCH_GAP then return nil end
    self.pending = false
    self.lastAlert = now
    local msg = string.format(L["Entzaubern lohnt: %d Teile mit über %d %% Rendite verfügbar (Kaufen -> Entzaubern lohnt)."],
        #list, self:DEMinRoi())
    A:Print(msg)
    if A.ScreenMessage then A:ScreenMessage(msg, 0.64, 0.4, 1.0, true) end
    if A.Diag then A.Diag:Add("WÄCHTER", string.format("Entzaubern lohnt · %d Teile · ab %d %%", #list, self:DEMinRoi())) end
    return msg
end

function DB:Log(kind, itemID, price, value)
    if A.Diag then
        A.Diag:Add(kind == "KAUF" and "KAUF" or "KAUF", string.format("Entzaubern-Sammelkauf %s · Item %d · Preis %d · Wert %d",
            kind == "KAUF" and "gekauft" or "übersprungen", itemID or 0, price or 0, value or 0))
    end
end

function DB:StatusText()
    local s = self.session
    return string.format(L["Gekauft %d · %s · erwartet +%s"], s.bought, A:FormatMoney(s.paid), A:FormatMoney(s.expected))
end

function DB:Reset()
    self.session = { bought = 0, paid = 0, expected = 0 }
    self.skipped = {}
    self.inFlight = nil
    self.seen = {}
    self.pending = false
    A:Fire("DEBUY_CHANGED")
end
