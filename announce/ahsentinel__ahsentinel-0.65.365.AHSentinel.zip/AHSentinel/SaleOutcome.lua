if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel - G10 ECHTE VERKAUFSCHANCE (Auftrag des Nutzers 21.11.2026 16:35, Prio 1), Teil A: eigene Daten
--
-- Quelle ist der Post-Scan (Mailer.lua, Dauerregel 15:44): jeder Brief sagt sicher "verkauft", "abgelaufen" oder "abgebrochen".
-- Beim Einstellen merkt AHSentinel Preis und Preisabstand zum günstigsten fremden Angebot (frische Preisprüfung). Kommt der Brief,
-- wird er dem ältesten passenden Einstellen zugeordnet (verkauft: gleicher Stückpreis; zurück: ältestes Einstellen des Items).
-- "Verschwunden" aus Scans zählt hier nie als verkauft. Angezeigt wird erst ab MIN_CASES Fällen im selben Preisabstand.
-- Teil B (Gilde, verdichtet ohne Namen) folgt mit dem Sync.
-- ============================================================
AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local SO = {}
A.SaleOutcome = SO
SO.MIN_CASES = 5              -- erst ab so vielen Fällen im selben Preisabstand eine Aussage
SO.KEEP = 60                  -- Ergebnisse je Item (die neuesten)
SO.PENDING_DAYS = 4           -- Einstellen ohne Brief nach so vielen Tagen verwerfen (Laufzeit höchstens 48 Std. + Post)

function SO:Store()
    if A:InTestRoutine() and not self.testDB then return nil end
    local db = self.testDB or A.db
    if not db then return nil end
    db.saleObs = db.saleObs or { pending = {}, res = {} }
    db.saleObs.pending = db.saleObs.pending or {}
    db.saleObs.res = db.saleObs.res or {}
    return db.saleObs
end
local function Now() return (A.testNow) or time() end
-- Preisabstand in ganzen Prozent zum günstigsten fremden Angebot (nil = unbekannt)
function SO.Gap(unit, lo)
    if not (unit and lo and lo > 0) then return nil end
    return math.floor((unit / lo - 1) * 100 + 0.5)
end
-- Gruppen: am/unter dem günstigsten, 1–5 %, 6–15 %, über 15 % darüber
function SO.Bucket(gap)
    if gap == nil then return nil end
    if gap <= 0 then return 1 elseif gap <= 5 then return 2 elseif gap <= 15 then return 3 end
    return 4
end
SO.BUCKET_TEXT = { "am/unter dem günstigsten Angebot", "1–5 Prozent darüber", "6–15 Prozent darüber", "mehr als 15 Prozent darüber" }

function SO:NotePosted(itemID, unit, qty, lo)
    local st = self:Store()
    if not (st and itemID and unit and unit > 0) then return end
    local p = st.pending[itemID] or {}
    st.pending[itemID] = p
    local now = Now()
    -- alte Einträge ohne Brief verwerfen
    for k = #p, 1, -1 do if now - (p[k].t or 0) > self.PENDING_DAYS * 86400 then table.remove(p, k) end end
    p[#p + 1] = { t = now, u = unit, q = math.max(1, qty or 1), lo = lo }
end

local function NameToID(st, name)
    if not name then return nil end
    for id in pairs(st.pending) do if A:GetItemName(id) == name then return id end end
    return nil
end
-- kind: "sold" | "expired" | "cancelled"; total = Gesamtpreis (nur verkauft)
function SO:NoteResult(kind, itemID, name, count, total)
    local st = self:Store()
    if not st then return end
    itemID = itemID or NameToID(st, name)
    if not itemID then return end
    count = math.max(1, count or 1)
    local unit = (kind == "sold" and total and total > 0) and math.floor(total / count + 0.5) or nil
    local p = st.pending[itemID] or {}
    local pick
    for k, e in ipairs(p) do
        if kind ~= "sold" or not unit or math.abs((e.u or 0) - unit) <= 1 then pick = k; break end
    end
    local e = pick and p[pick]
    local now = Now()
    local rec = { t = now, o = kind == "sold" and "v" or (kind == "expired" and "a" or "b"), n = count }
    if e then
        rec.g = SO.Gap(e.u, e.lo)
        rec.u = e.u
        if kind == "sold" then rec.d = now - (e.t or now) end
        e.q = (e.q or 1) - count
        if e.q <= 0 then table.remove(p, pick) end
    else
        rec.u = unit
    end
    local r = st.res[itemID] or {}
    st.res[itemID] = r
    r[#r + 1] = string.format("%d;%s;%d;%s;%s;%s", rec.t, rec.o, rec.n, rec.g and tostring(rec.g) or "", rec.d and tostring(rec.d) or "", rec.u and tostring(rec.u) or "")
    while #r > self.KEEP do table.remove(r, 1) end
end
local function Parse(s)
    local t, o, n, g, d, u = s:match("^(%d+);(%a);(%d+);(%-?%d*);(%d*);(%d*)$")
    if not t then return nil end
    return { t = tonumber(t), o = o, n = tonumber(n), g = tonumber(g), d = tonumber(d), u = tonumber(u) }
end
SO.Parse = Parse
-- Auswertung für einen Preis: gleiche Abstands-Gruppe; zurück nil (zu wenig Fälle) oder { n, sold, hours (Median), bucket }
function SO:Stats(itemID, unit, lo)
    local st = self:Store()
    local r = st and st.res[itemID]
    if not r then return nil end
    local b = SO.Bucket(SO.Gap(unit, lo))
    if not b then return nil end
    local n, sold, ds = 0, 0, {}
    for _, s in ipairs(r) do
        local x = Parse(s)
        if x and SO.Bucket(x.g) == b then
            n = n + x.n
            if x.o == "v" then sold = sold + x.n; if x.d then ds[#ds + 1] = x.d end end
        end
    end
    if n < self.MIN_CASES then return nil, n end
    table.sort(ds)
    local med = #ds > 0 and ds[math.floor((#ds + 1) / 2)] or nil
    return { n = n, sold = sold, hours = med and math.floor(med / 3600 + 0.5) or nil, bucket = b }
end
function SO:Text(itemID, unit, lo)
    local s, n = self:Stats(itemID, unit, lo)
    if not s then return nil, n end
    local t = string.format(L["Bisher bei %s: %d von %d verkauft"], L[SO.BUCKET_TEXT[s.bucket]], s.sold, s.n)
    if s.hours then t = t .. string.format(L[", meist nach ~%d Std."], s.hours) end
    return t
end
