-- GuildSentinel - PagesHome.lua
-- Seite "Übersicht" (Startseite): Gilden-Gesundheit auf einen Blick.
--   * aktive Spieler diese Woche gegenüber dem Schnitt der vier Wochen davor
--   * Neuzugänge und Abgänge (30 Tage), wer bald inaktiv wird, offene Bewerber, fällige Probezeiten
--   * "Für dich": Termine ohne Antwort, offene Umfragen, Herstellungswünsche, die du erfüllen kannst, offene Fragen
-- Ein Klick auf eine Kachel öffnet die passende Seite.

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local UI = ns.UI

local GREEN, GRAY, GOLD, ORANGE, RED = "|cff40d860", "|cff8a8f99", "|cffffd100", "|cffff9933", "|cffff5555"
local function Gray(t) return GRAY .. tostring(t) .. "|r" end
local function WhenShown(key, fn)
	return function(...) if UI:IsPageShown(key) then fn(...) end end
end

local H = { key = "home", feature = "home", order = 5, icon = "Interface\\Icons\\INV_Misc_Spyglass_03", noGuild = "always" }
H.title = N["Übersicht"]

------------------------------------------------------------
-- Kennzahlen
------------------------------------------------------------
local Health = {}
ns.Health = Health

-- Mains, die an einem Tag im Bereich [from, to] (Tag-Nummern) online waren
local function ActiveMains(from, to)
	local g = ns.G()
	local set, n = {}, 0
	for _, e in ipairs(ns.Roster.list) do
		local m = ns.Roster:MainOf(e.name) or e.name
		if not set[m] then
			for d in pairs(g.days[e.name] or {}) do
				if d >= from and d <= to then set[m] = true; n = n + 1 break end
			end
		end
	end
	return n
end

function Health:Compute()
	local now = ns.Now()
	local today = math.floor(now / 86400)
	local g = ns.G()
	local h = {}
	h.active = ActiveMains(today - 6, today)
	local sum = 0
	for w = 1, 4 do sum = sum + ActiveMains(today - 6 - w * 7, today - w * 7) end
	h.activeBefore = sum / 4
	local _, online, mains, mainsOnline = ns.Roster:Stats()
	h.online, h.mains, h.mainsOnline = online, mains, mainsOnline
	h.joins, h.leaves = 0, 0
	-- Abgänge: Verlauf und Abgangsliste zusammen, jeder Name einmal (wie Leitung > Abgänge)
	local gone = {}
	for _, x in ipairs(g.log or {}) do
		if x.t >= now - 30 * 86400 then
			if x.k == "join" then h.joins = h.joins + 1
			elseif (x.k == "leave" or x.k == "kick") and x.n and not ns.Roster.byName[x.n] then gone[x.n] = true end
		end
	end
	for name, x in pairs(g.gone or {}) do
		if (x.t or 0) >= now - 30 * 86400 and not ns.Roster.byName[name] then gone[name] = true end
	end
	for _ in pairs(gone) do h.leaves = h.leaves + 1 end
	-- bald inaktiv: 10–13 Tage nicht online (kein Charakter), nicht abwesend gemeldet
	-- in einem Durchgang: jüngstes "zuletzt online" je Main (online = math.huge); früher je Main die ganze Liste
	-- erneut durchsucht – bei 500 Mitgliedern spürbare Ruckler (T143)
	h.soon = {}
	local newestOf, order = {}, {}
	for _, x in ipairs(ns.Roster.list) do
		local m = ns.Roster:MainOf(x.name) or x.name
		local cur = newestOf[m]
		if cur == nil then cur = 0; order[#order + 1] = m end
		if x.online then cur = math.huge elseif (x.seen or 0) > cur then cur = x.seen end
		newestOf[m] = cur
	end
	for _, m in ipairs(order) do
		local newest = newestOf[m]
		local off = newest > 0 and newest < math.huge and (now - newest) / 86400 or 0
		if off >= 10 and off < 14 and not ns.Social:IsAway(m) then
			h.soon[#h.soon + 1] = { name = m, days = math.floor(off) }
		end
	end
	table.sort(h.soon, function(a, b) return a.days > b.days end)
	h.apps = 0
	for _, a in pairs(g.apps or {}) do if a.st == "new" then h.apps = h.apps + 1 end end
	h.probDue = 0
	if ns.IsOfficer() and ns.Feature("lead") then
		for _, x in ipairs(ns.Lead:Probation()) do if x.due then h.probDue = h.probDue + 1 end end
	end
	-- für mich
	h.events = ns.Feature("events") and ns.Events:OpenCount() or 0
	h.polls = ns.Feature("poll") and (ns.Poll:OpenUnvoted() or 0) or 0
	h.crafts = 0
	if ns.Feature("prof") then
		for _, r in pairs(g.creq or {}) do
			if not r.done and not r.del and not r.taker and not ns.Same(r.by, ns.Me()) and ns.Craft:CanICraft(r.i, r.n) then h.crafts = h.crafts + 1 end
		end
	end
	h.questions = (ns.Ask and ns.Feature("ask")) and ns.Ask:OpenCount() or 0
	h.gear = (ns.Gear and ns.Feature("gear")) and #ns.Gear:Mine() or 0
	-- Wochenziel
	if ns.Feature("goals") then
		h.goalDone, h.goalTarget = ns.Goals:WeekLevels(), ns.Goals:Target()
	end
	-- nächster Termin
	if ns.Feature("events") then
		for _, e in ipairs(ns.Events:Upcoming(true)) do
			if e.t > now then h.nextEvent = e break end
		end
	end
	return h
end

------------------------------------------------------------
-- Kacheln
------------------------------------------------------------
local function Tile(parent, onClick)
	local t = CreateFrame("Button", nil, parent, UI.BACKDROP)
	t:SetSize(186, 84)
	UI.Box(t, 0.07, 0.08, 0.11, 1, 0.18, 0.2, 0.25, 1)
	t.value = UI:Label(t, "", "GameFontNormalHuge")
	t.value:SetPoint("TOPLEFT", 12, -10)
	t.label = UI:Label(t, "", "GameFontHighlight")
	t.label:SetPoint("TOPLEFT", t.value, "BOTTOMLEFT", 0, -4)
	t.sub = UI:Label(t, "", "GameFontDisableSmall")
	t.sub:SetPoint("TOPLEFT", t.label, "BOTTOMLEFT", 0, -3)
	t.sub:SetPoint("RIGHT", -8, 0)
	t.sub:SetJustifyH("LEFT")
	t.sub:SetWordWrap(false)
	local hl = t:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.04)
	t:SetScript("OnClick", onClick)
	return t
end

function H.build(root)
	H.panel = root
	-- ohne Gilde: nur ein Hinweis, was GuildSentinel ist und was schon geht
	H.noGuildView = CreateFrame("Frame", nil, root)
	H.noGuildView:SetAllPoints()
	H.noGuildView:Hide()
	local nh = UI:Header(H.noGuildView, L["Du bist in keiner Gilde"])
	nh:SetPoint("TOPLEFT", 0, 0)
	local nt = UI:Label(H.noGuildView, L["GuildSentinel ist ein Gildentool. Mitglieder, Termine, Brett, Umfragen, Fortschritt, Berufe, Rekrutierung und die Gruppensuche erscheinen, sobald du in einer Gilde bist – dann gleichen sich die Daten mit allen in der Gilde ab, die das Addon haben."], "GameFontHighlight")
	nt:SetPoint("TOPLEFT", nh, "BOTTOMLEFT", 0, -10)
	nt:SetWidth(720)
	nt:SetJustifyH("LEFT")
	local nt2 = UI:Label(H.noGuildView, L["Ohne Gilde verfügbar: Meine Woche (Raid-Sperren und Raid-Vorbereitung), Addons und Einstellungen."], "GameFontHighlightSmall")
	nt2:SetPoint("TOPLEFT", nt, "BOTTOMLEFT", 0, -12)
	nt2:SetWidth(720)
	nt2:SetJustifyH("LEFT")
	local p = CreateFrame("Frame", nil, root)
	p:SetAllPoints()
	H.main = p
	local head = UI:Header(p, L["Gilden-Gesundheit"])
	head:SetPoint("TOPLEFT", 0, 0)
	H.date = UI:Label(p, "", "GameFontDisableSmall")
	H.date:SetPoint("TOPRIGHT", 0, -4)
	local defs = {
		{ key = "active", page = "members", arg = "online" },
		{ key = "online", page = "members", arg = "where" },
		{ key = "joins", page = "members", arg = "log" },
		{ key = "soon", page = "members", arg = "inactive" },
		{ key = "apps", page = "recruit", arg = "apps" },
		{ key = "prob", page = "lead", arg = "prob" },
		{ key = "goal", page = "progress", arg = "goals" },
		{ key = "event", page = "events" },
	}
	H.tiles, H.order = {}, {}
	for i, d in ipairs(defs) do
		local t = Tile(p, function() UI:Open(d.page, d.arg) end)
		t:SetPoint("TOPLEFT", ((i - 1) % 4) * 196, -28 - math.floor((i - 1) / 4) * 94)
		H.tiles[d.key] = t
		H.order[i] = t
	end
	local h2 = UI:Header(p, L["Für dich"])
	h2:SetPoint("TOPLEFT", 0, -222)
	H.todo = UI:ScrollText(p, 382, 300)
	H.todo:SetPoint("TOPLEFT", h2, "BOTTOMLEFT", 0, -6)
	H.todo:SetPoint("BOTTOMLEFT", 0, 0)
	local h3 = UI:Header(p, L["Bald inaktiv"])
	h3:SetPoint("TOPLEFT", 400, -222)
	H.soon = UI:ScrollText(p, 382, 300)
	H.soon:SetPoint("TOPLEFT", h3, "BOTTOMLEFT", 0, -6)
	H.soon:SetPoint("BOTTOMRIGHT", 0, 0)
end

local function Set(t, value, label, sub)
	t.value:SetText(value)
	t.label:SetText(label)
	t.sub:SetText(sub or "")
end

function H:Refresh()
	if not self.panel or not self.panel:IsShown() then return end
	local inGuild = ns.InGuild()
	self.noGuildView:SetShown(not inGuild)
	self.main:SetShown(inGuild)
	if not inGuild then return end
	local h = Health:Compute()
	self.date:SetText(ns.Date(ns.Now()))
	local T = self.tiles
	-- aktive Spieler mit Trend
	local diff = h.active - h.activeBefore
	local trend = math.abs(diff) < 0.5 and Gray(L["wie im Vormonat"])
		or (diff > 0 and (GREEN .. string.format(L["+%d gegenüber Vormonat"], math.floor(diff + 0.5)) .. "|r")
		or (RED .. string.format(L["%d gegenüber Vormonat"], math.floor(diff - 0.5)) .. "|r"))
	Set(T.active, tostring(h.active), L["Aktive Spieler (7 Tage)"], trend)
	Set(T.online, tostring(h.mainsOnline), L["Spieler online"], string.format(L["von %d Spielern"], h.mains))
	Set(T.joins, (h.joins > 0 and GREEN or "") .. "+" .. h.joins .. "|r / " .. (h.leaves > 0 and ORANGE or "") .. "-" .. h.leaves .. "|r", L["Zu- und Abgänge (30 Tage)"], "")
	Set(T.soon, (#h.soon > 0 and ORANGE or GREEN) .. #h.soon .. "|r", L["Bald inaktiv"], L["10–13 Tage nicht online"])
	Set(T.apps, (h.apps > 0 and GOLD or "") .. h.apps .. "|r", L["Offene Bewerber"], "")
	T.apps:SetShown(ns.Feature("recruit"))
	Set(T.prob, (h.probDue > 0 and GOLD or "") .. h.probDue .. "|r", L["Probezeit fällig"], L["nur für die Leitung"])
	T.prob:SetShown(ns.IsOfficer() and ns.Feature("lead"))
	if h.goalTarget then
		local pct = math.floor(math.min(1, h.goalDone / math.max(1, h.goalTarget)) * 100)
		Set(T.goal, pct .. "%", L["Wochenziel"], string.format(L["%d von %d Stufen"], h.goalDone, h.goalTarget))
	else
		Set(T.goal, "–", L["Wochenziel"], Gray(L["aus"]))
	end
	if h.nextEvent then
		Set(T.event, date("%H:%M", h.nextEvent.t), L["Nächster Termin"], ns.Date(h.nextEvent.t):sub(1, 6) .. " · " .. h.nextEvent.title)
	else
		Set(T.event, "–", L["Nächster Termin"], Gray(L["keiner geplant"]))
	end
	-- sichtbare Kacheln ohne Lücke anordnen
	local n = 0
	for _, t in ipairs(self.order) do
		if t:IsShown() then
			t:ClearAllPoints()
			t:SetPoint("TOPLEFT", (n % 4) * 196, -28 - math.floor(n / 4) * 94)
			n = n + 1
		end
	end
	-- für dich
	local todo = {}
	if h.events > 0 then todo[#todo + 1] = GOLD .. "• |r" .. string.format(L["%d Termin(e) ohne deine Antwort"], h.events) end
	if h.polls > 0 then todo[#todo + 1] = GOLD .. "• |r" .. string.format(L["%d Umfrage(n), bei denen du noch nicht abgestimmt hast"], h.polls) end
	if h.crafts > 0 then todo[#todo + 1] = GOLD .. "• |r" .. string.format(L["%d Herstellungswunsch/-wünsche, die du erfüllen kannst"], h.crafts) end
	if h.questions > 0 then todo[#todo + 1] = GOLD .. "• |r" .. string.format(L["%d offene Frage(n) an die Gilde"], h.questions) end
	if h.apps > 0 and ns.IsOfficer() then todo[#todo + 1] = GOLD .. "• |r" .. string.format(L["%d Bewerber warten auf Antwort"], h.apps) end
	if h.probDue > 0 then todo[#todo + 1] = GOLD .. "• |r" .. string.format(L["%d Probezeit(en) abgelaufen – befördern oder Gespräch"], h.probDue) end
	if #todo == 0 then todo[1] = GREEN .. L["Alles erledigt – nichts offen."] .. "|r" end
	self.todo:SetText(table.concat(todo, "\n"))
	local soon = {}
	for _, x in ipairs(h.soon) do soon[#soon + 1] = string.format(L["%s – seit %d Tagen nicht online"], x.name, x.days) end
	if #soon == 0 then soon[1] = Gray(L["Niemand – alle waren in den letzten 10 Tagen online."]) end
	self.soon:SetText(table.concat(soon, "\n"))
end

H.onShow = function() H:Refresh() end
for _, ev in ipairs({ "GS_ROSTER", "GS_EVENTS", "GS_POLL", "GS_CRAFT", "GS_APPS", "GS_GOALS", "GS_LEAD", "GS_ASK", "GS_GEAR", "GS_SOCIAL" }) do
	ns:Listen(ev, WhenShown("home", function() H:Refresh() end))
end
UI:AddPage(H)
