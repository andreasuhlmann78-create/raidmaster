-- GuildSentinel - Roster.lua
-- Mitgliederliste: liest die Gilde, merkt sich "zuletzt online", erkennt Twinks und führt den Verlauf
-- (beigetreten, verlassen, entfernt, befördert, degradiert, Maximalstufe erreicht).

local ADDON, ns = ...
local L = ns.L
local R = {}
ns.Roster = R

R.list = {}          -- aktuelle Mitglieder (für die Anzeige)
R.byName = {}
R.MAX_LEVEL = ns.Game.MAX_LEVEL
R.LOG_MAX = 400

------------------------------------------------------------
-- Verlauf
------------------------------------------------------------
-- k: join, leave, kick, promote, demote, maxlevel, rejoin
function R:Log(kind, name, extra, t)
	local g = ns.guild
	if not g then return end
	table.insert(g.log, 1, { t = t or ns.Now(), k = kind, n = name, x = extra })
	while #g.log > R.LOG_MAX do table.remove(g.log) end
	ns:Fire("GS_LOG")
end

------------------------------------------------------------
-- Twinks
------------------------------------------------------------
-- Name nach dem Stichwort: bis zu zwei Wörter (WoW Forever: "Twink von Testa Beispiel").
-- Erst wird "Wort Wort" in der Gilde gesucht, dann nur das erste Wort.
local NAME = "([^%s,;%.%(%)]+[ ]?[^%s,;%.%(%)]*)"
local NOTE_PATTERNS = {
	"twink%s*von%s*" .. NAME,
	"twink%s*[:%-=]%s*" .. NAME,
	"alt%s*of%s*" .. NAME,
	"alt%s*[:%-=]%s*" .. NAME,
	"main%s*[:%-=]%s*" .. NAME,
}

-- Main aus der öffentlichen Notiz ("Twink von Testa", "Alt: Testa", "Main: Testa")
-- dazu die Kennzeichnung in der Sprache des Clients, wie GuildSentinel sie selbst in Notizen schreibt
-- (Social:NoteWithMain mit L["Twink von %s"], z. B. französisch "Reroll de …") – sonst würde sie nicht wieder erkannt
local localPattern, localLang
local function LocalPattern()
	if localLang == ns.lang then return localPattern end
	localLang, localPattern = ns.lang, nil
	local fmt = L["Twink von %s"]
	if type(fmt) == "string" and fmt ~= "Twink von %s" and fmt ~= "Alt of %s" then
		local a, b = fmt:lower():match("^(.-)%%s(.*)$")
		local function Esc(x) return (ns.Trim(x):gsub("([%%%(%)%.%+%-%*%?%[%]%^%$])", "%%%1"):gsub("%s+", "%%s*")) end
		if a and ns.Trim(a) ~= "" then
			localPattern = Esc(a) .. "%s*" .. NAME                                  -- "Reroll de Testa"
		elseif b and ns.Trim(b) ~= "" then
			localPattern = NAME .. "%s*" .. Esc(b)                                  -- "Testa Beispiel의 부캐릭터", "Testa 的分身"
		end
	end
	return localPattern
end

function R:MainFromNote(name, note)
	if type(note) ~= "string" or note == "" then return nil end
	local low = note:lower()
	local patterns = NOTE_PATTERNS
	local lp = LocalPattern()
	if lp then
		patterns = { lp }
		for _, p in ipairs(NOTE_PATTERNS) do patterns[#patterns + 1] = p end
	end
	for _, p in ipairs(patterns) do
		local m = low:match(p)
		if m then
			m = ns.Trim(m)
			local e = self.byName[ns.Proper(m)]
			if not e then
				-- ein Wort: das erste ("Twink von Testa Heiler") oder – wenn der Name vor der Kennzeichnung steht
				-- ("xyz Testa의 부캐릭터") – das letzte
				local first, last = m:match("^(%S+)"), m:match("(%S+)$")
				e = first and (self.byName[ns.Proper(first)] or ns.FindMember(first))
				if not e and last and last ~= first then e = self.byName[ns.Proper(last)] or ns.FindMember(last) end
			end
			if e and not ns.Same(e.name, name) then return e.name end
		end
	end
	return nil
end

-- Main eines Charakters (nil = ist selbst Main oder unbekannt)
-- Reihenfolge: RaidMaster (Twinks aus Discord /twink), dann GuildSentinel, dann die Notiz
-- Zwischenspeicher für den Aufbau einer Seite (R:Memo): MainOf und AltsOf werden dort pro Name nur einmal
-- berechnet (bei 500 Mitgliedern sonst O(n²) – Ruckler, T143). Ausserhalb von R:Memo wird nichts gespeichert.
local memo
function R:Memo(fn, ...)
	if memo then return fn(...) end          -- schon in einem Aufbau
	memo = { main = {}, alts = nil }
	local ok, a, b, c = pcall(fn, ...)
	memo = nil
	if not ok then error(a, 0) end
	return a, b, c
end
-- Daten haben sich geändert: Zwischenspeicher leeren
function R:Forget()
	if memo then memo.main = {}; memo.alts = nil end
end
local NONE = {}

function R:MainOf(name)
	if memo and name ~= nil then
		local v = memo.main[name]
		if v == nil then
			v = self:MainOfRaw(name) or NONE
			memo.main[name] = v
		end
		if v == NONE then return nil end
		return v
	end
	return self:MainOfRaw(name)
end

function R:MainOfRaw(name)
	local rm = ns.RMI:MainOf(name)
	if rm and not ns.Same(rm, name) then return rm end
	local g = ns.G()
	local a = g.alts[name]
	if a and a.m and a.m ~= "" and not ns.Same(a.m, name) then return a.m end
	if a and a.m == "" then return nil end   -- ausdrücklich als Main markiert
	local e = self.byName[name]
	if e and e.noteMain then return e.noteMain end
	return nil
end

function R:IsAlt(name)
	return self:MainOf(name) ~= nil
end

function R:AltsOf(main)
	local out = {}
	if memo then
		-- Index Main -> Twinks einmal je Aufbau
		if not memo.alts then
			local idx = {}
			for _, e in ipairs(self.list) do
				local m = self:MainOf(e.name)
				if m then idx[m] = idx[m] or {}; idx[m][#idx[m] + 1] = e.name end
			end
			for _, l in pairs(idx) do table.sort(l) end
			memo.alts = idx
		end
		for i, n in ipairs(memo.alts[main] or NONE) do out[i] = n end
		return out
	end
	for _, e in ipairs(self.list) do
		if self:MainOf(e.name) == main then out[#out + 1] = e.name end
	end
	table.sort(out)
	return out
end

-- Main setzen (main = nil oder "" heißt: ist selbst ein Main) und an die Gilde schicken
function R:SetMain(name, main, quiet)
	local g = ns.guild
	if not g or not name then return end
	if main and main ~= "" then
		local found = ns.FindMember(main)
		main = found and found.name or ns.Proper(main)
	else
		main = ""
	end
	if ns.Same(main, name) then main = "" end
	g.alts[name] = { m = main, t = ns.Now(), by = ns.Me() }
	self:Forget()
	if not quiet then
		ns.Comm:Send("ALT", { e = { [name] = g.alts[name] } })
		if main == "" then ns:Print(string.format(L["%s ist jetzt als Main eingetragen."], name))
		else ns:Print(string.format(L["%s ist jetzt als Twink von %s eingetragen."], name, main)) end
	end
	-- auch in RaidMaster eintragen (dort zählt "Main vor Twink" beim Bieten); geht nur mit Offiziersrechten
	if ns.RMI:Active() and (ns.RMI:MainOf(name) or "") ~= main then
		if not ns.RMI:SetMain(name, main ~= "" and main or nil) and ns.RMI:MainOf(name) and not quiet then
			ns:Print(string.format(L["%s ist in RaidMaster als Twink von %s eingetragen (Discord: /twink). Ändern können das Offiziere."], name, ns.RMI:MainOf(name)))
		end
	end
	ns:Fire("GS_ROSTER")
end

-- Meine eigenen Charaktere: alle als Twinks meines Mains
function R:SetMyMain(main)
	local g = ns.guild
	if not g then return end
	g.myMain = main
	local e = {}
	for ch in pairs(g.mine) do
		g.alts[ch] = { m = (ch == main) and "" or main, t = ns.Now(), by = ns.Me() }
		R:Forget()
		e[ch] = g.alts[ch]
	end
	ns.Comm:Send("ALT", { e = e })
	ns:Fire("GS_ROSTER")
end

ns.Comm:Register("ALT", function(sender, d)
	local g = ns.guild
	if not g or type(d.e) ~= "table" then return end
	local changed
	for ch, v in pairs(d.e) do
		if type(ch) == "string" and type(v) == "table" and type(v.t) == "number" then
			local old = g.alts[ch]
			if not old or (old.t or 0) < v.t then
				g.alts[ch] = { m = type(v.m) == "string" and v.m or "", t = v.t, by = v.by or sender }
				R:Forget()
				changed = true
			end
		end
	end
	if changed then ns:Fire("GS_ROSTER") end
end)

------------------------------------------------------------
-- Gilde lesen
------------------------------------------------------------
local function OfflineSeconds(i, LastOnline)
	LastOnline = LastOnline or GetGuildRosterLastOnline
	if not LastOnline then return nil end
	local y, m, d, h = LastOnline(i)
	if not y and not m and not d and not h then return nil end
	return (((y or 0) * 365 + (m or 0) * 30 + (d or 0)) * 24 + (h or 0)) * 3600
end

function R:Scan()
	local g = ns.guild
	if not g or not ns.InGuild() then return end
	-- im Testmodus kommt die Liste aus der erfundenen Testgilde
	local Info, LastOnline = GetGuildRosterInfo, GetGuildRosterLastOnline
	local total
	if ns.Test and ns.Test:Active() then
		total, Info, LastOnline = ns.Test:RosterAPI()
	else
		total = GetNumGuildMembers and GetNumGuildMembers() or 0
	end
	if total == 0 then return end
	local now = ns.Now()
	local list, byName = {}, {}
	for i = 1, total do
		local name, rank, rankIndex, level, _, zone, note, onote, online, status, classFile = Info(i)
		name = ns.Short(name)
		if name then
			local e = {
				name = name, rank = rank, ri = rankIndex, level = level or 0, class = classFile,
				zone = zone, note = note or "", onote = onote or "", online = online and true or false,
				status = status, index = i,
			}
			if online then
				e.seen = now
			else
				local off = OfflineSeconds(i, LastOnline)
				local old = g.roster[name]
				e.seen = off and (now - off) or (old and old.seen) or 0
				-- Stunden-Genauigkeit vom Server: den besseren eigenen Wert behalten
				if old and old.seen and off and old.seen > e.seen and old.seen - e.seen < 3600 then e.seen = old.seen end
			end
			list[#list + 1] = e
			byName[name] = e
		end
	end
	-- unvollständige Liste (kommt beim Einloggen vor): nicht vergleichen
	if #list < total * 0.9 then return end
	self.list, self.byName = list, byName
	for _, e in ipairs(list) do e.noteMain = self:MainFromNote(e.name, e.note) end
	self:Forget()
	self:Compare(byName)
	self.scans = (self.scans or 0) + 1
	-- eigenen Charakter auf dem Laufenden halten
	local me = byName[ns.Me()]
	if me then g.mine[me.name] = { c = me.class, l = me.level } end
	ns:Fire("GS_ROSTER")
end

-- Unterschiede zum letzten Stand: Wer ist neu, wer fehlt, wer wurde befördert?
function R:Compare(now)
	local g = ns.guild
	local old = g.roster
	local first = next(old) == nil
	local t = ns.Now()
	if not first then
		for name, e in pairs(now) do
			local o = old[name]
			if not o then
				if not self.liveJoin or not self.liveJoin[name] then self:Log("join", name, nil, t) end
			else
				if o.ri and e.ri and o.ri ~= e.ri and not (self.liveRank and self.liveRank[name]) then
					self:Log(e.ri < o.ri and "promote" or "demote", name, e.rank, t)
				end
				if (o.l or 0) < R.MAX_LEVEL and e.level >= R.MAX_LEVEL then self:Log("maxlevel", name, e.level, t) end
			end
		end
		for name, o in pairs(old) do
			if not now[name] and not (self.liveLeave and self.liveLeave[name]) then self:Log("leave", name, nil, t) end
		end
	end
	local snap = {}
	for name, e in pairs(now) do
		local o = old[name]
		snap[name] = {
			c = e.class, l = e.level, r = e.rank, ri = e.ri, z = e.zone, seen = e.seen,
			first = (o and o.first) or (first and 0) or t,
		}
	end
	g.roster = snap
	self.liveJoin, self.liveLeave, self.liveRank = nil, nil, nil
	-- Stufen (Leveling-Rennen), Online-Tage (Beförderung) und Beitritt (Jubiläen)
	local today = math.floor(t / 86400)
	for name, e in pairs(now) do
		local lv = g.levels[name]
		if not lv then
			lv = {}
			g.levels[name] = lv
			lv[e.level] = first and 0 or t
		end
		local o = old[name]
		local before = o and o.l
		if before and e.level > before then
			for l = before + 1, e.level do if not lv[l] then lv[l] = t end end
			-- live (nicht der Abgleich beim Einloggen) und gerade online: Meilenstein ansagen
			ns:Fire("GS_LEVEL", name, before, e.level, (self.scans or 0) >= 1 and e.online)
		elseif not lv[e.level] then
			lv[e.level] = 0
		end
		if e.online then
			g.days[name] = g.days[name] or {}
			g.days[name][today] = true
		end
		local f = snap[name].first
		if f and f > 0 and (not g.firstSeen[name] or f < g.firstSeen[name]) then g.firstSeen[name] = f end
	end
	-- Bewerber, die jetzt in der Gilde sind
	for name, a in pairs(g.apps) do
		if now[name] and a.st ~= "joined" then a.st = "joined"; a.tj = t end
	end
end

local scanPending
ns:On("GUILD_ROSTER_UPDATE", function()
	if scanPending then return end
	scanPending = true
	C_Timer.After(0.5, function()
		scanPending = false
		R:Scan()
	end)
end)

-- regelmäßig neu anfragen, damit "online" stimmt (der Server schickt höchstens alle 10 s)
C_Timer.NewTicker(30, function()
	if IsInGuild() and ns.GuildRoster then ns.GuildRoster() end
end)

------------------------------------------------------------
-- Systemmeldungen: live beigetreten, verlassen, entfernt, befördert
------------------------------------------------------------
local function ToPattern(fmt)
	if type(fmt) ~= "string" then return nil end
	fmt = fmt:gsub("%%%d%$s", "\001"):gsub("%%s", "\001")
	fmt = fmt:gsub("([%%%(%)%.%+%-%*%?%[%]%^%$])", "%%%1")
	fmt = fmt:gsub("\001", "(.+)")
	return "^" .. fmt .. "$"
end

local P_JOIN = ToPattern(ERR_GUILD_JOIN_S)
local P_LEAVE = ToPattern(ERR_GUILD_LEAVE_S)
local P_KICK = ToPattern(ERR_GUILD_REMOVE_SS)
local P_PROMOTE = ToPattern(ERR_GUILD_PROMOTE_SSS)
local P_DEMOTE = ToPattern(ERR_GUILD_DEMOTE_SSS)

ns:On("CHAT_MSG_SYSTEM", function(msg)
	if not ns.guild or type(msg) ~= "string" or ns.IsSecret(msg) then return end
	local a, b, c
	a = P_JOIN and msg:match(P_JOIN)
	if a then
		a = ns.Short(a)
		R.liveJoin = R.liveJoin or {}
		R.liveJoin[a] = true
		local old = ns.guild.roster[a]
		R:Log("join", a)
		ns:Fire("GS_JOINED", a, old ~= nil)
		if ns.GuildRoster then ns.GuildRoster() end
		return
	end
	a = P_LEAVE and msg:match(P_LEAVE)
	if a then
		a = ns.Short(a)
		R.liveLeave = R.liveLeave or {}
		R.liveLeave[a] = true
		R:Log("leave", a)
		return
	end
	if P_KICK then a, b = msg:match(P_KICK) end
	if a then
		a = ns.Short(a)
		R.liveLeave = R.liveLeave or {}
		R.liveLeave[a] = true
		R:Log("kick", a, ns.Short(b))
		return
	end
	if P_PROMOTE then a, b, c = msg:match(P_PROMOTE) end
	if a then
		b = ns.Short(b)
		R.liveRank = R.liveRank or {}
		R.liveRank[b] = true
		R:Log("promote", b, c)
		return
	end
	if P_DEMOTE then a, b, c = msg:match(P_DEMOTE) end
	if a then
		b = ns.Short(b)
		R.liveRank = R.liveRank or {}
		R.liveRank[b] = true
		R:Log("demote", b, c)
	end
end)

------------------------------------------------------------
-- Abfragen für die Anzeige
------------------------------------------------------------
function R:Ranks()
	local out, seen = {}, {}
	for _, e in ipairs(self.list) do
		if e.rank and not seen[e.ri] then
			seen[e.ri] = true
			out[#out + 1] = { ri = e.ri, name = e.rank }
		end
	end
	table.sort(out, function(a, b) return a.ri < b.ri end)
	return out
end

function R:Classes()
	local out, seen = {}, {}
	for _, e in ipairs(self.list) do
		if e.class and not seen[e.class] then
			seen[e.class] = true
			out[#out + 1] = e.class
		end
	end
	table.sort(out, function(a, b) return ns.ClassName(a) < ns.ClassName(b) end)
	return out
end

-- Zahlen für die Kopfzeile
function R:Stats()
	local total, online, mains, mainsOnline, max = #self.list, 0, 0, 0, 0
	local seenMain = {}
	for _, e in ipairs(self.list) do
		if e.online then online = online + 1 end
		if e.level >= R.MAX_LEVEL then max = max + 1 end
		local m = self:MainOf(e.name) or e.name
		if not seenMain[m] then seenMain[m] = { on = false }; mains = mains + 1 end
		if e.online then seenMain[m].on = true end
	end
	for _, v in pairs(seenMain) do if v.on then mainsOnline = mainsOnline + 1 end end
	return total, online, mains, mainsOnline, max
end

-- Ist der Spieler (oder einer seiner Charaktere) gerade online?
function R:OnlineChar(name)
	local main = self:MainOf(name) or name
	local e = self.byName[main]
	if e and e.online then return main end
	for _, alt in ipairs(self:AltsOf(main)) do
		local a = self.byName[alt]
		if a and a.online then return alt end
	end
	return nil
end

-- Gefilterte und sortierte Liste
-- f = { text, online, class, ri, alts, sort, desc }
function R:Filtered(f)
	f = f or {}
	local text = (f.text or ""):lower()
	local out = {}
	local g = ns.G()
	for _, e in ipairs(self.list) do
		local ok = true
		if f.online and not e.online then ok = false end
		if ok and f.class and e.class ~= f.class then ok = false end
		if ok and f.ri and e.ri ~= f.ri then ok = false end
		if ok and f.alts == false and self:IsAlt(e.name) then ok = false end
		if ok and text ~= "" then
			local hay = (e.name .. " " .. (e.note or "") .. " " .. (e.zone or "") .. " " .. (g.notes[e.name] or "") .. " " .. (self:MainOf(e.name) or "")):lower()
			if not hay:find(text, 1, true) then ok = false end
		end
		if ok then out[#out + 1] = e end
	end
	local key, desc = f.sort or "name", f.desc
	table.sort(out, function(a, b)
		local x, y
		if key == "level" then x, y = a.level, b.level
		elseif key == "rank" then x, y = a.ri, b.ri
		elseif key == "class" then x, y = ns.ClassName(a.class), ns.ClassName(b.class)
		elseif key == "seen" then
			x, y = (a.online and math.huge or a.seen or 0), (b.online and math.huge or b.seen or 0)
		elseif key == "zone" then x, y = (a.zone or ""), (b.zone or "")
		else x, y = a.name, b.name end
		if x == y then return a.name < b.name end
		if desc then return x > y end
		return x < y
	end)
	return out
end

function R:Inactive(days)
	local limit = ns.Now() - days * 86400
	local out = {}
	for _, e in ipairs(self.list) do
		if not e.online and (e.seen or 0) > 0 and e.seen < limit and not (ns.Social and ns.Social:IsAway(e.name)) then
			-- nur wenn kein Charakter des Spielers neuer ist
			local main = self:MainOf(e.name) or e.name
			local newest = e.seen
			for _, x in ipairs(self.list) do
				if (self:MainOf(x.name) or x.name) == main and (x.online or (x.seen or 0) > newest) then newest = x.online and math.huge or x.seen end
			end
			if newest < limit then out[#out + 1] = e end
		end
	end
	table.sort(out, function(a, b) return (a.seen or 0) < (b.seen or 0) end)
	return out
end
