# GuildSentinel – Changelog

## 0.9.19
- **Professions arrive automatically in both directions**: a member's professions could get stuck on one side. Fixed:
  - GuildSentinel now always sends your own professions itself, also when RaidMaster is installed (before, it stayed silent and relied on RaidMaster).
  - Names are matched in one way everywhere (realm suffix, upper/lower case, first name alone on WoW Forever): data is stored and shown under the name from the guild roster. Older entries under another spelling are merged once (newer data wins).
  - Every member with GuildSentinel sends their own professions 10–60 seconds after logging in when they are new or older than 24 hours – no longer only through the one member who answers the sync.
- **Fully automatic** (no option, no button, never in combat):
  - The game's guild profession list is read with offline members too (the "Show offline members" setting is switched on briefly and set back).
  - New recipes are added right away when you learn them – no need to open the profession window.
  - Recipe check without the window: recipes your guild already knows are checked with the game's spell check, only if a test check gives the right answers.
  - Blizzard's guild recipes (who in the guild knows which recipe) are queried where the game allows it, once a day per profession; otherwise they are read when you open that view yourself.
- **Professions page**: a selected profession without known data now says how many members have it ("2 guild members have Alchemy …") instead of the general hint. The "Who" column shows "1 of 4"; members known only from the game's list appear with "Recipes unknown" and can be whispered; "+2 more according to the game" below the list.
- Guild list: opening collapsed professions happens at most every 5 minutes, and the update this causes no longer starts a new read (no loop).
- Promote from the activity list and the bulk actions now use the modern game function first (like guild management).
- Diagnostic log: lines for read, sent, received, shown and filtered professions (numbers only, no player names) and a summary.
- Developer test routine: T201–T213 new.

## 0.9.18
- **Professions of all members**: the game can send its guild profession list with collapsed professions, and then GuildSentinel found no names. It now opens collapsed professions briefly, reads them and closes them again (only outside combat and while Blizzard's guild window is closed). Where the game cannot do that, the Professions page shows how many members have each profession (e.g. "2/5": 2 known to GuildSentinel, 5 according to the game).
- **Guild management**: actions and rank names now always use the right game function on every client (Classic Era, TBC Anniversary, WoW Forever). The management button moves below the guild window while Blizzard's member details or rank window are open, so it never covers them.
- Developer test routine: T190 extended (collapsed professions), new T200 (old clients without C_GuildInfo); area K also checks Blizzard's guild pop-ups.

## 0.9.17
- **New window "Guild management"** for guild leadership and officers: button "Management (GuildSentinel)" next to Blizzard's guild window (J stays as it is) and `/gs verwaltung`.
  - Invite (name or current target), promote/demote (rank before -> after, never above your own rank), remove (with confirmation).
  - Hand over guild leadership: Guild Master only, locked until the password is entered, then two confirmations.
  - Every button follows your rights in the game. The Guild Master can add characters that may open the window on this computer (local list, never sent).
  - Password: set in the game (enter twice), stored only as a salted checksum on this computer, masked input, 3 failed attempts lock it for 5 minutes, change only with the old password. It is a protection against accidental clicks – the real protection are your rights in the game.
  - Actions only from your click, never in combat; in test mode nothing is executed. Option "Management button on the guild window".

## 0.9.16
- **Professions of all members, automatically**: where the game itself knows the guild's professions (guild profession list), GuildSentinel now reads the skill levels of every member – also of members without GuildSentinel. Recipes still come only from players with GuildSentinel (or RaidMaster) who have opened their profession window once; their own data always wins over the guild list.
- **New members**: whoever joins the guild while online now shares their professions right away instead of at the next login.

## 0.9.15
- **Diagnostic log**: GuildSentinel now records problems that only happen in the real game (slow pages, blocked actions with the calling place, error loops – never player, guild or realm names). Open it with `/gs protokoll` to copy it; after a logout or /reload it is also stored for the RaidMaster uploader, which sends it to the developer.
- Developer test routine: T188 (diagnostic log) and T189 (in the game).

## 0.9.14
Fixes from the in-game test run on WoW Forever launch night:
- **Big guilds**: the Overview and Leadership pages no longer stutter with hundreds of members (main/alt lookups are now done once per page build – about 25× faster with 500 members).
- **Professions button (WoW Forever)**: no more "action blocked" message. If the profession window does not open, GuildSentinel now asks you to open it yourself once instead of calling a protected function.
- **Achievements/Chronicle**: damaged profession data no longer breaks the page.
- **Event announcement** in test mode also works for characters without a guild (only "[Test]" in your chat, nothing is sent).
- Developer test routine: new area K checks the interface in the real client (tooltips covering buttons, overlapping windows, windows off screen, cut-off texts, plausible game values, error loops); clearer results for first/last names and slow pages.

## 0.9.13
- **Language selectable for everyone**: Settings > General > "Language". On start GuildSentinel still uses the language of your game client; you can switch to German, English, French, Spanish (Spain/Mexico), Italian or Portuguese on any client (Russian, Korean and Chinese on a client in that language). GuildSentinel reloads after the change; "Same as the game client" goes back. Replaces the developer-only switch from 0.9.12.

## 0.9.12
- Developer only: under Settings > Test mode the language can be switched between German, English and the game client's language (for screenshots); GuildSentinel reloads after the change. Nothing changes for players – GuildSentinel always uses the language of the game client.

## 0.9.11
- **Bank character: stock to Discord** (optional, off by default): tick "Bank character (stock to Discord)" under Settings > General on your guild's bank character. Opening the bank, the mailbox or – where the game has one – the guild bank then reads bags, bank, mail attachments and guild bank tabs (read only, never in combat, in small steps). The RaidMaster uploader sends the stock with its next upload, and the RaidMaster bot shows it in #gildenbank and with /bank. Guilds without the RaidMaster bot notice nothing.
- **Alt notes with first and last names** (WoW Forever) on Korean and Chinese clients, where the name comes before the label ("Testa Beispiel의 부캐릭터"), are recognised again.
- **Changing the main** now removes the old alt label completely – with first and last name and in the client language ("Alt: First Last", "Reroll de …") – instead of leaving parts of it in the note.
- **Event sync**: one damaged entry no longer discards the other events of the same sync message.
- All game functions GuildSentinel needs are now chosen in one place (API.lua, modern API first, old one as fallback). Nothing changes for players.
- Developer test routine: real sends now count as an error in the report (T82), every action with consequences is checked to go through one place (T174), new cases for export, event announcements, first/last names and the bank character, and the cases that previously needed a replaced game function now run in the game too.

## 0.9.10
- **Alt notes in your client language**: notes that GuildSentinel writes itself ("Reroll de …", "… 的分身" and so on) are recognised again on French, Spanish, Italian, Portuguese, Korean and Chinese clients. Where the label would not fit into the short guild note (Russian), GuildSentinel writes the short form "Alt: Name".
- **AHSentinel** (formerly AH Analyzer Pro) is recognised under its new folder name (Addons page, market values).
- **Applicant whispers in combat** (WoW Forever): more than 30 whispers during one fight are now counted in the notice too instead of being dropped silently.
- More robust against damaged data: malformed event sync messages and broken event or thanks entries no longer cause errors.
- Test mode (developer only): no longer joins or leaves the server channel, sends nothing delayed after "Stop test mode" and leaves the real settings (last ad, free status, My week) untouched.
- New for the developer: `/gs testroutine` (button "Test everything" under Settings > Test mode) checks every feature and saves a report for the GoldSentinel review; the diagnosis shows the error counter. Nothing changes for players.

## 0.9.9
Fixes from the review:
- **Officer rights**: players who may only read officer notes no longer count as officers.
- **Applicant whispers in combat** (WoW Forever): if a message stays protected after combat, GuildSentinel reports once how many could not be read instead of losing them silently.
- **Player tooltip**: the combat lock applies to every modern client (WoW Forever, Retail).
- Absence and thanks messages from other players are only accepted when the sender matches exactly.

## 0.9.8
- Shared game-version detection (GoldSentinelGame.lua) updated to version 2: it also wins over early, withdrawn copies that other GoldSentinel addons briefly shipped, so loading several GoldSentinel addons together causes no errors. Nothing changes for players.

## 0.9.7
- Uses the shared game-version detection of all GoldSentinel addons (GoldSentinelGame.lua): Classic Era, WoW Forever and TBC are detected the same way everywhere, with the shared secret-value guard and first/last name comparison. `/gsgame` shows what was detected. Nothing changes for players.

## 0.9.5
- **WoW Forever hardening**: protection against secret values in combat (player tooltip, addon messages, cooldowns). Applicants who whisper during combat are added after combat instead of being lost.
- **First and last names** (WoW Forever): names are capitalised correctly, notes like "Alt of Testa Beispiel" are recognised, and a unique first name alone is enough for alts, thanks and mentors.
- Whispering a "First Last" name opens the whisper box for the full name.
- Modern APIs are used first (C_ChatInfo, C_GuildInfo, C_SpellBook), with the old ones as fallback.

## 0.9.4
- **Without a guild**: instead of empty pages the overview shows a hint – GuildSentinel is a guild tool, and members, events, board, polls, progress, professions, recruitment and the group finder appear once you are in a guild. My week, Addons and Settings stay available. Joining or leaving a guild takes effect right away.

## 0.9.3
- **Guild name**: the guild master can set a name for GuildSentinel under Leadership > Rank rights. It applies to everyone in the guild with the addon (ad, chronicle, rules, welcome guide, header). Empty = the name from the game. Only the guild master can change it.

## 0.9.2
- **Professions on WoW Forever**: GuildSentinel now also reads the new retail-style profession window. The game client decides the way: WoW Forever uses the new window, Classic Era and TBC the classic one as before. Linked professions, guild professions and NPC windows are not read.
- The "Open next profession" button opens the new window directly on WoW Forever if needed.

## 0.9.1
- Test mode is now developer-only: the Settings > Test mode tab and `/gs test` only appear for the developer account. Nothing else changes for players.

## 0.9.0
- **Who's free** (Group finder): one click flags you as free for dungeon, raid, quest group or PvP for 1, 2 or 4 hours. Everyone with GuildSentinel sees who is free, with level, item level and zone. Inside dungeons, raids and battlegrounds you automatically show as busy.
- After posting a group search, GuildSentinel tells you how many guild members are free for it right now.
- **Item level** with "I'll join": the searcher sees it in the replies and in chat.
- **Bulk actions** (Leadership, officers): remove inactive players by rule or promote several suggestions at once – always a checklist first, one step per click.
- **GRM import** (Leadership): alts, join dates and personal notes from Guild Roster Manager, with a preview.

## 0.8.3
- New **Support** button (PayPal link to copy) in the title bar and under Settings > General, also `/gs donate`. Opens only on click.

## 0.8.2
- Guild achievements: singular for the first weekly goal; names that are too long use a smaller font.
- Professions: old raw-material entries (e.g. Felweed as "Alchemy") are removed automatically.

## 0.8.1
- Settings > Features in three columns; probation advice follows the 40 % rule; overview counts departures like Leadership; My week markers and singulars; chronicle without duplicates; loot wishes preselect a dungeon; removing a question asks first; raw materials leave the watch list.

## 0.8.0
- All WoW client languages; Classic Era, WoW Forever and TBC Classic / Anniversary; Overview, Leadership, My week, loot wishes, questions, guild achievements, chronicle, weekly recap, welcome guide, features on/off.
