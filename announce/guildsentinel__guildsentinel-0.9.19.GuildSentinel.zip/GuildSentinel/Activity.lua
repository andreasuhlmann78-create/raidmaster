-- GuildSentinel - Activity.lua
-- Online-Zeiten: Alle 5 Minuten zählt GuildSentinel, wie viele Spieler (Mains, Twinks zählen nicht extra)
-- online sind, und merkt sich das je halbe Stunde. Daraus entsteht eine Übersicht nach Wochentag und Uhrzeit
-- (wann sind die meisten da – gut für Raidtermine). Die Messungen gleichen sich in der Gilde ab.
-- Beförderung: Vorschläge nach Regeln, die die Gildenleitung je Rang festlegt (Tage in der Gilde, Stufe,
-- an wie vielen der letzten 14 Tage online).
--
--   G.act[Halbstunden-Nr.] = Spieler online    (Halbstunden-Nr. = Serverzeit / 1800)
--   G.days[Name][Tag-Nr.] = true                 (Tag-Nr. = Serverzeit / 86400)
--   G.promo[Rang-Index] = { on, days, level, active }

local ADDON, ns = ...
local L = ns.L
local N = ns.N

local A = {}
ns.Activity = A

A.SLOT = 1800
A.KEEP_SLOTS = 35 * 86400
A.KEEP_DAYS = 60

-- Spieler online (ein Spieler mit mehreren Charakteren zählt einmal)
function A:OnlinePlayers()
	local seen, n = {}, 0
	for _, e in ipairs(ns.Roster.list) do
		if e.online then
			local m = ns.Roster:MainOf(e.name) or e.name
			if not seen[m] then seen[m] = true; n = n + 1 end
		end
	end
	return n
end

function A:Sample()
	local g = ns.guild
	if not g or not next(ns.Roster.byName) then return end
	local now = ns.Now()
	local slot = math.floor(now / self.SLOT)
	local n = self:OnlinePlayers()
	if not g.act[slot] or n > g.act[slot] then g.act[slot] = n end
	-- aufräumen
	local oldest = math.floor((now - self.KEEP_SLOTS) / self.SLOT)
	for s in pairs(g.act) do if s < oldest then g.act[s] = nil end end
end

C_Timer.NewTicker(300, function() A:Sample() end)
ns:Listen("GS_ROSTER", function()
	if not A.first then A.first = true; A:Sample() end
end)

-- Übersicht: grid[Wochentag 1=Mo..7=So][Stunde 0..23] = { sum, n, avg }, dazu das Maximum
function A:Grid()
	local grid = {}
	for d = 1, 7 do
		grid[d] = {}
		for h = 0, 23 do grid[d][h] = { sum = 0, n = 0, avg = 0 } end
	end
	local max = 0
	for slot, count in pairs(ns.G().act) do
		local t = date("*t", slot * self.SLOT)
		local wd = ((t.wday + 5) % 7) + 1       -- Lua: 1 = Sonntag -> 1 = Montag
		local c = grid[wd][t.hour]
		c.sum = c.sum + count
		c.n = c.n + 1
	end
	for d = 1, 7 do
		for h = 0, 23 do
			local c = grid[d][h]
			if c.n > 0 then
				c.avg = c.sum / c.n
				if c.avg > max then max = c.avg end
			end
		end
	end
	return grid, max
end

-- beste Zeiten (mindestens 2 Messungen): { { wd, h, avg, n } }
function A:Best(count)
	local grid = self:Grid()
	local out = {}
	for d = 1, 7 do
		for h = 0, 23 do
			local c = grid[d][h]
			if c.n >= 2 then out[#out + 1] = { wd = d, h = h, avg = c.avg, n = c.n } end
		end
	end
	table.sort(out, function(a, b) if a.avg == b.avg then return a.n > b.n end return a.avg > b.avg end)
	local res = {}
	for i = 1, math.min(count or 3, #out) do res[i] = out[i] end
	return res
end

function A:Measurements()
	return ns.Count(ns.G().act)
end

local DAYS = { N["Mo"], N["Di"], N["Mi"], N["Do"], N["Fr"], N["Sa"], N["So"] }
A.WEEKDAYS = setmetatable({}, { __index = function(_, i) return DAYS[i] and L[DAYS[i]] end })

-- an wie vielen der letzten span Tage war der Spieler (oder einer seiner Charaktere) online?
function A:ActiveDays(name, span)
	span = span or 14
	local g = ns.G()
	local today = math.floor(ns.Now() / 86400)
	local main = ns.Roster:MainOf(name) or name
	local chars = { main }
	for _, alt in ipairs(ns.Roster:AltsOf(main)) do chars[#chars + 1] = alt end
	local days = {}
	for _, ch in ipairs(chars) do
		for d in pairs(g.days[ch] or {}) do
			if d > today - span then days[d] = true end
		end
	end
	return ns.Count(days)
end

-- alte Online-Tage aufräumen
ns:Listen("GS_LOGIN", function()
	local g = ns.guild
	if not g then return end
	local limit = math.floor(ns.Now() / 86400) - A.KEEP_DAYS
	for name, set in pairs(g.days) do
		for d in pairs(set) do if d < limit then set[d] = nil end end
		if not next(set) then g.days[name] = nil end
	end
end)

-- wer GuildSentinel nutzt, war heute online (auch wenn ich es nicht gesehen habe)
ns:Listen("GS_USERS", function()
	local g = ns.guild
	if not g then return end
	local today = math.floor(ns.Now() / 86400)
	for name, u in pairs(ns.Comm.users) do
		if u.t and math.floor(u.t / 86400) == today then
			g.days[name] = g.days[name] or {}
			g.days[name][today] = true
		end
	end
end)

------------------------------------------------------------
-- Beförderung
------------------------------------------------------------
local P = {}
ns.Promote = P

P.DEFAULT = { on = false, days = 14, level = 0, active = 5 }

function P:Rule(ri)
	local r = ns.G().promo[ri]
	if not r then return ns.Copy(self.DEFAULT) end
	return r
end

function P:SetRule(ri, field, value)
	local g = ns.guild
	if not g then return end
	local r = g.promo[ri] or ns.Copy(self.DEFAULT)
	r[field] = value
	g.promo[ri] = r
	ns:Fire("GS_PROMO")
end

-- Ränge, die befördert werden können (nicht der Gildenmeister, nicht direkt unter mir oder höher)
function P:Ranks()
	local out = {}
	local me = ns.Roster.byName[ns.Me()]
	local myRi = me and me.ri or 0
	local ranks = ns.Roster:Ranks()
	local names = {}
	for _, r in ipairs(ranks) do names[r.ri] = r.name end
	for _, r in ipairs(ranks) do
		if r.ri > myRi + 1 then
			out[#out + 1] = { ri = r.ri, name = r.name, to = names[r.ri - 1] or ("#" .. (r.ri - 1)) }
		end
	end
	return out
end

function P:DaysInGuild(name)
	local join = ns.Jubilee:JoinDate(name)
	if not join then return nil end
	return math.floor((ns.Now() - join) / 86400)
end

-- Vorschläge: { { name, class, level, rank, to, days, active } }
function P:Candidates()
	local out = {}
	local allowed = {}
	for _, r in ipairs(self:Ranks()) do allowed[r.ri] = r.to end
	for _, e in ipairs(ns.Roster.list) do
		local rule = ns.G().promo[e.ri]
		if rule and rule.on and allowed[e.ri] and not ns.Social:IsAway(e.name) then
			local days = self:DaysInGuild(e.name)
			local active = ns.Activity:ActiveDays(e.name, 14)
			if days and days >= (rule.days or 0) and e.level >= (rule.level or 0) and active >= (rule.active or 0) then
				out[#out + 1] = { name = e.name, class = e.class, level = e.level, rank = e.rank, to = allowed[e.ri], days = days, active = active, online = e.online }
			end
		end
	end
	table.sort(out, function(a, b) if a.days == b.days then return a.name < b.name end return a.days > b.days end)
	return out
end

function P:Promote(name)
	if not ns.CanPromote() then ns:Print(L["Dein Rang darf niemanden befördern."]) return end
	local fn = ns.GuildFn("GuildPromote")      -- über ns.API, moderner Weg zuerst
	if fn and not ns.Blocked(L["Befördern"] .. ": " .. name) then ns.Act("GuildPromote", fn, name) end
	if ns.GuildRoster then C_Timer.After(1, function() ns.GuildRoster() end) end
end
