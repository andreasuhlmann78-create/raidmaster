-- GuildSentinel - Group.lua
-- Gruppensuche in der Gilde: "Suche Gruppe für Schwarzfelstiefen, brauche Heiler".
-- Die Suche geht an alle mit GuildSentinel – nur in der Gilde oder auf dem ganzen Server (über einen eigenen,
-- im Chat ausgeblendeten Kanal, auch an Spieler anderer Gilden). Wer von Stufe und Rolle passt, bekommt einen
-- Hinweis im Chat und meldet sich mit einem Klick ("Ich komme mit"). Der Suchende lädt mit einem Klick ein.
--
--   G.lfg[id] = { id, by, c = Klasse, l = Stufe, act = Aktivität, note, roles = { tank, heal, dps }, need = Plätze,
--                 scope = "guild"/"server", gn = Gilde des Suchenden, t, exp, closed,
--                 joins = { [Name] = { r = Rolle, l, c, t } } }

local ADDON, ns = ...
local L = ns.L
local N = ns.N
local G = {}
ns.Group = G

G.DURATION = 3600         -- eine Suche läuft 60 Minuten
G.CHANNEL = "GuildSentinelLFG"   -- eigener Kanal für die Suche auf dem ganzen Server

-- Dungeons (Classic) mit Stufenbereich; Namen wie im deutschen Spiel
G.ACTIVITIES = {
	{ key = "rfc", n = N["Ragefireabgrund"], min = 13, max = 18 },
	{ key = "wc", n = N["Höhlen des Wehklagens"], min = 17, max = 24 },
	{ key = "dm", n = N["Die Todesminen"], min = 17, max = 26 },
	{ key = "sfk", n = N["Burg Schattenfang"], min = 22, max = 30 },
	{ key = "bfd", n = N["Tiefschwarze Grotte"], min = 24, max = 32 },
	{ key = "stocks", n = N["Das Verlies"], min = 24, max = 32 },
	{ key = "gnomer", n = N["Gnomeregan"], min = 29, max = 38 },
	{ key = "rfk", n = N["Kral der Klingenhauer"], min = 29, max = 38 },
	{ key = "smgy", n = N["Scharlachrotes Kloster: Friedhof"], min = 30, max = 37 },
	{ key = "smlib", n = N["Scharlachrotes Kloster: Bibliothek"], min = 33, max = 40 },
	{ key = "smarm", n = N["Scharlachrotes Kloster: Waffenkammer"], min = 35, max = 42 },
	{ key = "smcath", n = N["Scharlachrotes Kloster: Kathedrale"], min = 38, max = 45 },
	{ key = "rfd", n = N["Hügel der Klingenhauer"], min = 37, max = 46 },
	{ key = "ulda", n = N["Uldaman"], min = 41, max = 51 },
	{ key = "zf", n = N["Zul'Farrak"], min = 44, max = 54 },
	{ key = "mara", n = N["Maraudon"], min = 46, max = 55 },
	{ key = "st", n = N["Tempel von Atal'Hakkar"], min = 50, max = 56 },
	{ key = "brd", n = N["Schwarzfelstiefen"], min = 52, max = 60 },
	{ key = "lbrs", n = N["Untere Schwarzfelsspitze"], min = 55, max = 60 },
	{ key = "ubrs", n = N["Obere Schwarzfelsspitze"], min = 55, max = 60 },
	{ key = "dme", n = N["Düsterbruch"], min = 55, max = 60 },
	{ key = "strat", n = N["Stratholme"], min = 58, max = 60 },
	{ key = "scholo", n = N["Scholomance"], min = 58, max = 60 },
	-- in TBC kommen hier die Dungeons der Scherbenwelt dazu
	{ key = "quest", n = N["Quests / Elitequests"] },
	{ key = "pvp", n = N["PvP"] },
	{ key = "farm", n = N["Farmen"] },
	{ key = "other", n = N["Sonstiges"] },
}
if ns.Game.FOREVER then
	-- neue Forever-Dungeons nach Stufe einsortieren; Quests, PvP, Farmen, Sonstiges bleiben am Ende
	local dungeons, rest = {}, {}
	for _, a in ipairs(G.ACTIVITIES) do
		if a.min then dungeons[#dungeons + 1] = a else rest[#rest + 1] = a end
	end
	for i, a in ipairs(ns.Game.FOREVER_DUNGEONS) do a.order = 1000 + i; dungeons[#dungeons + 1] = a end
	for i, a in ipairs(dungeons) do a.order = a.order or i end
	table.sort(dungeons, function(x, y)
		if (x.raid ~= nil) ~= (y.raid ~= nil) then return y.raid ~= nil end
		if x.min ~= y.min then return x.min < y.min end
		return x.order < y.order
	end)
	G.ACTIVITIES = dungeons
	for _, a in ipairs(rest) do G.ACTIVITIES[#G.ACTIVITIES + 1] = a end
end
if ns.Game.TBC then
	local pos = 1
	for i, a in ipairs(G.ACTIVITIES) do if a.key == "quest" then pos = i break end end
	for i, a in ipairs(ns.Game.TBC_DUNGEONS) do table.insert(G.ACTIVITIES, pos + i - 1, a) end
end
G.BY_KEY = {}
for _, a in ipairs(G.ACTIVITIES) do G.BY_KEY[a.key] = a end

G.ROLES = { "tank", "heal", "dps" }

function G:RoleName(r)
	if r == "tank" then return L["Tank"] end
	if r == "heal" then return L["Heiler"] end
	return L["Schaden"]
end

-- eigene Rolle: gewählt (Einstellungen) oder nach Klasse vermutet
local HEALERS = { PRIEST = true, DRUID = true, SHAMAN = true, PALADIN = true }
function G:MyRole()
	local g = ns.G()
	local m = g.mine[ns.Me()]
	if m and m.role then return m.role end
	local _, cf = UnitClass("player")
	return HEALERS[cf] and "heal" or "dps"
end

function G:SetMyRole(r)
	local g = ns.guild
	if not g then return end
	g.mine[ns.Me()] = g.mine[ns.Me()] or {}
	g.mine[ns.Me()].role = r
	if ns.Comp then ns.Comp:ShareRole() end
end

function G:ActivityName(s)
	local a = G.BY_KEY[s.act]
	return a and L[a.n] or tostring(s.act or "?")
end

function G:Range(s)
	local a = G.BY_KEY[s.act]
	if a and a.min then return a.min, a.max end
	return nil
end

function G:IsOpen(s)
	return s and not s.closed and (s.exp or 0) > ns.Now()
end

-- passt die Suche zu mir? (Stufe im Bereich ±2, eine meiner Rollen gesucht)
function G:Fits(s, level, role)
	if not self:IsOpen(s) or ns.Same(s.by, ns.Me()) then return false end
	level = level or UnitLevel("player")
	local min, max = self:Range(s)
	if min and (level < min - 2 or level > max + 2) then return false end
	local roles = s.roles or {}
	if not roles.tank and not roles.heal and not roles.dps then return true end
	return roles[role or self:MyRole()] and true or false
end

------------------------------------------------------------
-- Suchen anlegen, beenden, mitmachen
------------------------------------------------------------
local counter = 0

function G:Post(act, roles, need, note, scope)
	local g = ns.guild
	if not g or not ns.InGuild() then ns:Print(L["Du bist in keiner Gilde."]) return end
	counter = counter + 1
	local now = ns.Now()
	local _, cf = UnitClass("player")
	local s = {
		id = ns.Me() .. now .. counter, by = ns.Me(), c = cf, l = UnitLevel("player"), act = act or "other",
		note = ns.Trim(note), roles = { tank = roles.tank and true or nil, heal = roles.heal and true or nil, dps = roles.dps and true or nil },
		need = math.max(1, math.min(39, tonumber(need) or 1)), t = now, exp = now + self.DURATION, joins = {},
		scope = (scope == "server") and "server" or "guild", gn = ns.GuildName(), z = G:MyZone(),
	}
	-- nur eine eigene offene Suche gleichzeitig
	for id, o in pairs(g.lfg) do
		if ns.Same(o.by, ns.Me()) and self:IsOpen(o) then self:Close(id, true) end
	end
	g.lfg[s.id] = s
	ns.Comm:Send("LFG", self:Wire(s), "GUILD", nil, true)
	if s.scope == "server" then self:SendServer("LFG", self:Wire(s)) end
	ns:Fire("GS_LFG")
	return s
end

-- was über die Leitung geht (ohne Meldungen)
function G:Wire(s)
	return { id = s.id, by = s.by, c = s.c, l = s.l, act = s.act, note = s.note, roles = s.roles, need = s.need, t = s.t, exp = s.exp,
		closed = s.closed, scope = s.scope, gn = s.gn, z = s.z }
end

-- eigene Zone (wird mit der Suche und beim Mitkommen verschickt)
function G:MyZone()
	local z = GetRealZoneText and GetRealZoneText() or ""
	return (z or ""):sub(1, 40)
end

-- Zone eines Spielers: bei Gildenmitgliedern, die online sind, die aktuelle aus der Gildenliste,
-- sonst die mitgeschickte (Stand bei Suche bzw. Meldung)
function G:ZoneOf(name, sent)
	local ch = ns.Roster:OnlineChar(name) or name
	local e = ns.Roster.byName[ch]
	if e and e.online and e.zone and e.zone ~= "" then return e.zone end
	if ns.Same(name, ns.Me()) then return self:MyZone() end
	return (type(sent) == "string" and sent ~= "") and sent or nil
end

function G:Close(id, quiet)
	local s = ns.G().lfg[id]
	if not s then return end
	s.closed = true
	ns.Comm:Send("LFGX", { id = id }, "GUILD", nil, true)
	if s.scope == "server" then self:SendServer("LFGX", { id = id }) end
	if not quiet then ns:Fire("GS_LFG") end
end

function G:Join(id, role)
	local s = ns.G().lfg[id]
	if not self:IsOpen(s) then return end
	role = role or self:MyRole()
	local any = s.roles and (s.roles.tank or s.roles.heal or s.roles.dps)
	if any and not s.roles[role] then
		ns:Print(string.format(L["Hinweis: Gesucht sind %s – du meldest dich als %s."], self:RolesText(s), self:RoleName(role)))
	end
	local _, cf = UnitClass("player")
	s.myJoin = role
	ns.Comm:Send("LFGJ", { id = id, r = role, l = UnitLevel("player"), c = cf, z = self:MyZone(), il = ns.ItemLevel and ns.ItemLevel() or nil }, "WHISPER", s.by, true)
	ns:Print(string.format(L["%s weiß Bescheid, dass du mitkommst (%s)."], s.by, self:RoleName(role)))
	ns:Fire("GS_LFG")
end

function G:Invite(name)
	ns.InviteParty(name)
	for _, s in pairs(ns.G().lfg) do
		if ns.Same(s.by, ns.Me()) and s.joins and s.joins[name] then s.joins[name].inv = true end
	end
	ns:Fire("GS_LFG")
end

function G:Notify(s)
	if not ns.db.lfgNotify then return end
	local roles = {}
	for _, r in ipairs(self.ROLES) do if s.roles and s.roles[r] then roles[#roles + 1] = self:RoleName(r) end end
	local zone = self:ZoneOf(s.by, s.z)
	ns:Print(string.format(L["%s sucht für %s: %s. Mitkommen: /gs gruppe"], ns.Colored(s.by, s.c), self:ActivityName(s),
		#roles > 0 and table.concat(roles, ", ") or L["alle Rollen"]) .. (zone and ("  |cff8a8f99(" .. zone .. ")|r") or ""))
	if ns.db.lfgSound and PlaySound then
		local kit = SOUNDKIT and (SOUNDKIT.TELL_MESSAGE or SOUNDKIT.RAID_WARNING)
		if kit then pcall(ns.Act, "PlaySound", PlaySound, kit) end
	end
end

-- Suchen empfangen
function G:Store(d)
	local g = ns.guild
	if not g or type(d.id) ~= "string" or type(d.by) ~= "string" then return nil end
	local old = g.lfg[d.id]
	local s = {
		id = d.id, by = d.by, c = d.c, l = tonumber(d.l) or 0, act = d.act, note = type(d.note) == "string" and d.note or "",
		roles = type(d.roles) == "table" and d.roles or {}, need = tonumber(d.need) or 1, t = tonumber(d.t) or ns.Now(),
		exp = tonumber(d.exp) or (ns.Now() + self.DURATION), closed = (d.closed or (old and old.closed)) and true or nil,
		scope = d.scope == "server" and "server" or "guild", gn = type(d.gn) == "string" and d.gn or nil,
		joins = old and old.joins or {}, myJoin = old and old.myJoin,
		z = type(d.z) == "string" and d.z:sub(1, 40) or nil,
	}
	g.lfg[d.id] = s
	return s, old
end

ns.Comm:Register("LFG", function(sender, d, channel)
	-- über den Server-Kanal nur Suchen, die auch für den Server gedacht sind, und nur vom Suchenden selbst
	if channel == "CHANNEL" and (d.scope ~= "server" or not ns.Same(d.by, sender)) then return end
	local s, old = G:Store(d)
	if not s then return end
	if not old and G:Fits(s) then G:Notify(s) end
	ns:Fire("GS_LFG")
end)

ns.Comm:Register("LFGX", function(sender, d)
	local s = type(d.id) == "string" and ns.G().lfg[d.id]
	if s and ns.Same(s.by, sender) then s.closed = true; ns:Fire("GS_LFG") end
end)

ns.Comm:Register("LFGJ", function(sender, d, channel)
	local s = type(d.id) == "string" and ns.G().lfg[d.id]
	if not s or not ns.Same(s.by, ns.Me()) or channel ~= "WHISPER" then return end
	local role = (d.r == "tank" or d.r == "heal") and d.r or "dps"
	local isNew = not s.joins[sender]
	s.joins[sender] = { r = role, l = tonumber(d.l) or 0, c = d.c, t = ns.Now(), z = type(d.z) == "string" and d.z:sub(1, 40) or nil, il = tonumber(d.il) }
	if isNew then
		local il = tonumber(d.il)
		ns:Print(string.format(L["%s (%s, Stufe %d) kommt mit – Einladen: /gs gruppe"], ns.Colored(sender, d.c), G:RoleName(role), tonumber(d.l) or 0)
			.. (il and ("  |cff8a8f99" .. string.format(L["Gegenstandsstufe %d"], il) .. "|r") or ""))
		if ns.db.lfgSound and PlaySound and SOUNDKIT and SOUNDKIT.TELL_MESSAGE then pcall(ns.Act, "PlaySound", PlaySound, SOUNDKIT.TELL_MESSAGE) end
	end
	ns:Fire("GS_LFG")
end)

------------------------------------------------------------
-- Abfragen
------------------------------------------------------------
function G:Open()
	local out = {}
	for _, s in pairs(ns.G().lfg) do
		if self:IsOpen(s) then out[#out + 1] = s end
	end
	table.sort(out, function(a, b)
		local am, bm = ns.Same(a.by, ns.Me()), ns.Same(b.by, ns.Me())
		if am ~= bm then return am end
		return (a.t or 0) > (b.t or 0)
	end)
	return out
end

function G:Mine()
	for _, s in pairs(ns.G().lfg) do
		if ns.Same(s.by, ns.Me()) and self:IsOpen(s) then return s end
	end
	return nil
end

function G:Joins(s)
	local out = {}
	for name, j in pairs(s and s.joins or {}) do out[#out + 1] = { name = name, r = j.r, l = j.l, c = j.c, t = j.t, inv = j.inv, z = self:ZoneOf(name, j.z), il = j.il } end
	table.sort(out, function(a, b) return (a.t or 0) < (b.t or 0) end)
	return out
end

function G:RolesText(s)
	local t = {}
	for _, r in ipairs(self.ROLES) do if s.roles and s.roles[r] then t[#t + 1] = self:RoleName(r) end end
	return #t > 0 and table.concat(t, ", ") or L["alle Rollen"]
end

------------------------------------------------------------
-- Suche für den ganzen Server: eigener Kanal (im Chat ausgeblendet)
------------------------------------------------------------
function G:ChannelId()
	local id = GetChannelName and GetChannelName(self.CHANNEL) or 0
	return (id and id > 0) and id or nil
end

function G:SendServer(msgType, data)
	if not self:ChannelId() then return false end
	ns.Comm:Send(msgType, data, "CHANNEL", self.CHANNEL, true)
	return true
end

-- Kanal in allen Chatfenstern ausblenden (die Nachrichten sind nur für das Addon)
function G:HideChannel()
	if not ChatFrame_RemoveChannel then return end
	for i = 1, (NUM_CHAT_WINDOWS or 10) do
		local cf = _G["ChatFrame" .. i]
		if cf then pcall(ChatFrame_RemoveChannel, cf, self.CHANNEL) end
	end
end

function G:JoinChannel()
	if not ns.db.lfgServer or not ns.Feature("group") then return end
	-- Testmodus: keinen echten Kanal betreten (nur anzeigen)
	if ns.Test and ns.Test:Active() then ns.Test:Log("CHANNEL", self.CHANNEL, L["Kanal betreten"]) return end
	if not self:ChannelId() then
		local join = JoinTemporaryChannel or JoinChannelByName
		if join then pcall(ns.Act, "JoinChannel", join, self.CHANNEL) end
	end
	C_Timer.After(2, function()
		self:HideChannel()
		-- wer schon sucht, schickt seine Suche noch einmal (dann sieht man sie auch als Neuer)
		if self:ChannelId() then ns.Comm:Send("LFGQ", {}, "CHANNEL", self.CHANNEL) end
	end)
end

-- Gruppensuche aus- oder eingeschaltet: Kanal verlassen bzw. wieder betreten
ns:Listen("GS_FEATURES", function(key, on)
	if key ~= "group" then return end
	if on then G:JoinChannel() else G:LeaveChannel() end
end)

function G:LeaveChannel()
	if ns.Test and ns.Test:Active() then ns.Test:Log("CHANNEL", self.CHANNEL, L["Kanal verlassen"]) return end
	if self:ChannelId() and LeaveChannelByName then pcall(ns.Act, "LeaveChannelByName", LeaveChannelByName, self.CHANNEL) end
end

ns.Comm:Register("LFGQ", function(sender, d, channel)
	local s = G:Mine()
	if channel ~= "CHANNEL" or not s or s.scope ~= "server" then return end
	if G.lastQ and GetTime() - G.lastQ < 30 then return end
	G.lastQ = GetTime()
	ns.Later(1 + math.random() * 4, function() G:SendServer("LFG", G:Wire(s)) end)
end)

ns:Listen("GS_LOGIN", function() C_Timer.After(10, function() G:JoinChannel() end) end)
ns:On("CHANNEL_UI_UPDATE", function()
	if G:ChannelId() then G:HideChannel() end
end)

-- alte Suchen aufräumen
ns:Listen("GS_LOGIN", function()
	local g = ns.guild
	if not g then return end
	local limit = ns.Now() - 86400
	for id, s in pairs(g.lfg) do if (s.exp or 0) < limit then g.lfg[id] = nil end end
end)
C_Timer.NewTicker(60, function()
	if ns.guild then ns:Fire("GS_LFG_TICK") end
end)
