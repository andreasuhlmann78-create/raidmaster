local ADDON, ns = ...
local L = ns.L

-- Test routine (/ps testroutine, developer only): ONE routine that checks the whole addon in the running game
-- and reports through GoldSentinelTest.lua (ProfessionSentinelDB.gsTest -> RaidMasterUploader -> #testberichte).
--   /ps testroutine            every case except the [api] cases
--   /ps testroutine a … j      one area (A load/detect, B every function, C Forever special cases, D old clients,
--                              E saved data, F languages, G other addons, H performance, I error counting,
--                              J regression tests)
--   /ps testroutine api        only the [api] cases: they replace entries of the addon's own table ns.API for a
--                              moment (a missing or different client function is simulated there); no Blizzard
--                              function or C_ table is ever replaced. /reload afterwards is still recommended.
--   /ps testroutine stop | bericht | ok T42 (confirm a "check in client" case)
-- Every test case T01 … T211 is exactly one result: OK / FEHLER / ÜBERSPRUNGEN (reason) / IM CLIENT PRÜFEN.
-- The IDs never change; new cases get new numbers from T212, removed cases stay as "entfällt seit <version>".
-- Safety: nothing with real consequences happens (no buying or selling, no chat, no mail, no crafting, no sniper
-- targets, no raid marks, no gold moved). Actions are replaced by stubs and counted; watchers count real calls.
-- The saved variables are copied before and restored in place afterwards (except gsTest, autotest, testConfirm).
-- Every replacement goes onto a rollback stack and is undone in reverse order – also after errors or an abort.
-- Data protection: no player, guild, realm or chat names in the report (T158).

local TR = {}
ns.TestRoutine = TR

local STEP_DELAY = 0.05
local LAUNCH_DAY = "20261105"         -- WoW Forever live (Thursday, 5 November 2026)
local RANKS = { 1, 75, 150, 225, 300 }
local MAX_ROWS = 12

local runs = {}                       -- stack of runs (main run + sub-runs of T20/T110)
local function Active() return runs[#runs] end
local cases, byId = {}, {}
local lastText

---------------------------------------------------------------------------
-- Small helpers
---------------------------------------------------------------------------
local function Now() return debugprofilestop and debugprofilestop() or (GetTime and GetTime() * 1000) or 0 end

local function DeepCopy(v, seen)
    if type(v) ~= "table" then return v end
    seen = seen or {}
    if seen[v] then return seen[v] end
    local t = {}
    seen[v] = t
    for k, x in pairs(v) do t[DeepCopy(k, seen)] = DeepCopy(x, seen) end
    return t
end
TR.DeepCopy = DeepCopy

-- first differing key path (nil = equal)
local function Diff(a, b, path)
    path = path or ""
    if type(a) ~= type(b) then return path ~= "" and path or "(Wurzel)" end
    if type(a) ~= "table" then
        if a ~= b then return path ~= "" and path or "(Wurzel)" end
        return nil
    end
    for k, v in pairs(a) do
        local d = Diff(v, b[k], path .. "." .. tostring(k))
        if d then return d end
    end
    for k in pairs(b) do
        if a[k] == nil then return path .. "." .. tostring(k) end
    end
    return nil
end
TR.Diff = Diff

local function Plain(s)
    s = tostring(s or "")
    s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", ""):gsub("|H.-|h(.-)|h", "%1"):gsub("|n", " ")
    return s
end
TR.Plain = Plain

local function Count(t) local n = 0; for _ in pairs(t or {}) do n = n + 1 end return n end

local function Median3(fn)
    local list = {}
    for i = 1, 3 do
        local t = Now()
        fn()
        list[i] = Now() - t
    end
    table.sort(list)
    return list[2]
end

local function Today() return date and date("%Y%m%d") or "20000101" end
local function AfterLaunch() return Today() >= LAUNCH_DAY end

local function ObjType(f)
    if type(f) ~= "table" or not f.GetObjectType then return nil end
    local ok, t = pcall(f.GetObjectType, f)
    return ok and t or nil
end

local function Children(f)
    if type(f) ~= "table" or not f.GetChildren then return {} end
    local ok, a = pcall(function() return { f:GetChildren() } end)
    return ok and a or {}
end

local function Regions(f)
    if type(f) ~= "table" or not f.GetRegions then return {} end
    local ok, a = pcall(function() return { f:GetRegions() } end)
    return ok and a or {}
end

local function Descendants(f, out)
    out = out or {}
    for _, k in ipairs(Children(f)) do
        out[#out + 1] = k
        Descendants(k, out)
    end
    return out
end

local function Shown(f)
    if type(f) ~= "table" or not f.IsVisible then return false end
    local ok, v = pcall(f.IsVisible, f)
    return ok and v or false
end

local function Text(f)
    if type(f) == "table" and f.GetText then
        local ok, s = pcall(f.GetText, f)
        if ok and type(s) == "string" then return s end
    end
    return ""
end

---------------------------------------------------------------------------
-- Result markers and aggregation
---------------------------------------------------------------------------
local function SKIP(reason) return { __tr = "skip", reason = reason } end
local function CLIENT(how) return { __tr = "client", how = how } end
local function WAIT(sec, fn) return { __tr = "wait", sec = sec, fn = fn } end
local function DEFER(fn) return { __tr = "defer", fn = fn } end
local function Marker(v, kind) return type(v) == "table" and v.__tr == kind end

-- collects sub-checks of one test case: "12 Berufe, 1 Fehler: Schneiderei – Titel leer"
local Agg = {}
Agg.__index = Agg
local function NewAgg() return setmetatable({ n = 0, bad = 0, first = nil, notes = {} }, Agg) end
function Agg:Ok(cond, label)
    self.n = self.n + 1
    if not cond then
        self.bad = self.bad + 1
        if not self.first then self.first = Plain(label) end
    end
    return cond
end
function Agg:Note(s) self.notes[#self.notes + 1] = Plain(s) end
function Agg:Result(what)
    local notes = #self.notes > 0 and (" · " .. table.concat(self.notes, " · ")) or ""
    -- honest counting: a case that checked nothing is never OK (it counts as "not automated")
    if self.n == 0 then return SKIP("nicht automatisiert – keine Prüfung lief" .. notes) end
    local base = string.format("%d %s", self.n, what or "Prüfungen")
    if self.bad == 0 then return true, base .. notes end
    return false, string.format("%s, %d Fehler: %s%s", base, self.bad, self.first or "?", notes), "0 Fehler"
end
TR.NewAgg = NewAgg

---------------------------------------------------------------------------
-- Rollback stack: every replacement is undone in reverse order (finally), also after errors
---------------------------------------------------------------------------
local function Push(entry)
    local r = Active()
    if r then r.stack[#r.stack + 1] = entry end
    return entry
end

-- replace t[k] by v for the current test case (or the whole run)
local function Stub(t, k, v, label)
    if type(t) ~= "table" then return end
    local had = rawget(t, k) ~= nil
    local e = { t = t, k = k, orig = rawget(t, k), had = had, label = label or tostring(k), newFn = type(v) == "function" }
    Push(e)
    t[k] = v
    if ns.Advisor and ns.Advisor.Invalidate then ns.Advisor.Invalidate() end      -- cached results depend on it
    if ns.UI and ns.UI.InvalidateRecipeMap then ns.UI.InvalidateRecipeMap() end
    return e.orig
end
TR.Stub = Stub

local function OnUndo(fn, label) Push({ fn = fn, label = label }) end

local function Unwind(run, mark)
    mark = mark or 0
    while #run.stack > mark do
        local e = table.remove(run.stack)
        if e.fn then
            local ok, err = pcall(e.fn)
            if not ok then run.undoErrors[#run.undoErrors + 1] = (e.label or "?") .. ": " .. tostring(err) end
        else
            if e.had then e.t[e.k] = e.orig else rawset(e.t, e.k, nil) end
            run.done[#run.done + 1] = e
        end
    end
    if ns.Advisor and ns.Advisor.Invalidate then ns.Advisor.Invalidate() end      -- back to the real inputs
    if ns.UI and ns.UI.InvalidateRecipeMap then ns.UI.InvalidateRecipeMap() end
end

---------------------------------------------------------------------------
-- Test helpers (all with rollback)
---------------------------------------------------------------------------
local function G() return _G.GoldSentinelGame end

local function SetDB(k, v) Stub(ns.db, k, v) end
local function SetSim(t) Stub(ns, "Sim", t) end

-- capture ns.Print (nothing reaches the chat)
local function Capture()
    local list = {}
    Stub(ns, "Print", function(msg) list[#list + 1] = Plain(msg) end)
    return list
end
local function Has(list, text)
    text = Plain(text)
    for _, m in ipairs(list) do if m:find(text, 1, true) then return true end end
    return false
end
local function Times(list, text)
    local n = 0
    text = Plain(text)
    for _, m in ipairs(list) do if m:find(text, 1, true) then n = n + 1 end end
    return n
end

-- simulate a game version: GoldSentinelGame + the addon's switches (data files are NOT reloaded)
local function Flavor(f)
    local GG = G()
    OnUndo(function()
        GG.SetTestFlavor(nil)
        ns.ApplyFlavor(GG)
    end, "Flavor")
    GG.SetTestFlavor(f)
    ns.ApplyFlavor(GG)
end

-- a test copy of the saved variables (ns.db is switched for the duration of the case)
local function TestDB(db)
    db = ns.InitDB(db or {})
    ns.InitChar(db, ns.CharKey())
    local c = db.chars[ns.CharKey()]
    c.flavor = ns.Flavor
    Stub(ns, "db", db)
    return db, c
end

-- protected value for tests: arithmetic, concatenation and comparison raise "secret (Test)"
local SECRET
do
    local function boom() error("secret (Test)", 2) end
    SECRET = setmetatable({}, { __add = boom, __sub = boom, __mul = boom, __div = boom, __concat = boom,
        __lt = boom, __le = boom, __len = boom, __unm = boom, __call = boom, __index = boom, __newindex = boom,
        __tostring = function() return "<SECRET>" end })
end
-- G.IsSecret / G.Safe know SECRET while the case runs; asked counts the questions about it
local function SecretMode()
    local GG = G()
    local st = { asked = 0 }
    local origIs, origSafe = GG.IsSecret, GG.Safe
    Stub(GG, "IsSecret", function(v)
        if rawequal(v, SECRET) then st.asked = st.asked + 1; return true end
        return origIs(v)
    end)
    Stub(GG, "Safe", function(v)
        if rawequal(v, SECRET) then return nil end
        return origSafe(v)
    end)
    return st
end

-- the intercepted original of an action (see INTERCEPT)
local function Orig(mod, key)
    local r = runs[1]
    local s = r and r.orig[mod .. "." .. key]
    return s or (ns[mod] and ns[mod][key])
end

local function Intercepted(label)
    local r = Active()
    return r and r.intercepted[label] or 0
end

local function GuardTotal(run)
    local n = 0
    for _, v in pairs((run or Active()).guards) do n = n + v end
    return n
end

local function Confirmed(id)
    local c = ns.db and type(ns.db.testConfirm) == "table" and ns.db.testConfirm[id]
    return type(c) == "table" and c or nil
end

-- addon metadata (C_AddOns in the modern client, the old global as fallback; both through ns.API)
local function Meta(field)
    local get = ns.API.AddOnsGetAddOnMetadata or ns.API.GetAddOnMetadata
    if not get then return nil end
    local ok, v = pcall(get, ADDON, field)
    return ok and v or nil
end

-- professions with data (as in the test mode)
local function ProfList()
    local list = {}
    for _, p in ipairs(ns.Professions or {}) do
        if ns.ByProf[p.id] and #ns.ByProf[p.id] > 3 then list[#list + 1] = p end
    end
    return list
end

local function BiggestProf()
    local best, n = nil, 0
    for _, p in ipairs(ProfList()) do
        if #ns.ByProf[p.id] > n then best, n = p.id, #ns.ByProf[p.id] end
    end
    return best
end

-- leatherworking (Retail: the Classic leatherworking line)
local function LWProf()
    if ns.IsRetail then
        local flb = ns.BySpell[2158]
        return flb and flb.prof or BiggestProf()
    end
    return ns.ByProf[165] and 165 or BiggestProf()
end

local function FirstRecipe(pred, prof)
    for _, r in ipairs(prof and (ns.ByProf[prof] or {}) or ns.Recipes) do
        if pred(r) then return r end
    end
end

-- test prices: every item 4× its vendor sell value (at least 1s) – like the test mode button
local function TestPrices()
    return setmetatable({}, { __index = function(_, id)
        local d = ns.Items[id]
        if not d then return nil end
        return math.max((d[3] or 0) * 4, 100)
    end })
end

---------------------------------------------------------------------------
-- Panel parts (found without changing UI.lua)
---------------------------------------------------------------------------
local function Panel() return _G.ProfessionSentinelPanel end

local function ActiveHost()
    if ns.UsesModernProfessions then
        return ProfessionsFrame and ProfessionsFrame:IsShown() and ProfessionsFrame or nil
    end
    if CraftFrame and CraftFrame:IsShown() then return CraftFrame end
    if TradeSkillFrame and TradeSkillFrame:IsShown() then return TradeSkillFrame end
end

local function SearchBox()
    for _, f in ipairs(Children(Panel())) do if ObjType(f) == "EditBox" then return f end end
end
local function MissingCheck()
    for _, f in ipairs(Children(Panel())) do if ObjType(f) == "CheckButton" then return f end end
end
local function Tabs()
    local p, out = Panel(), {}
    for _, f in ipairs(Children(p)) do
        if ObjType(f) == "Button" and f ~= (p and p.CloseButton) and f:GetScript("OnClick") then out[#out + 1] = f end
    end
    return out
end
local function TabFor(label)
    for _, t in ipairs(Tabs()) do
        if Plain(Text(t)):find(Plain(label), 1, true) then return t end
    end
end
local function ScrollBox()
    for _, f in ipairs(Descendants(Panel())) do
        if f.GetDataProvider and f.GetFrames then return f end
    end
end
local function PanelTitle()
    local p = Panel()
    if not p then return "" end
    local t = p.TitleText
    if type(t) ~= "table" and type(p.TitleContainer) == "table" then t = p.TitleContainer.TitleText end
    if type(t) == "table" and t.GetText then return Plain(t:GetText()) end
    if p.GetTitle then local ok, s = pcall(p.GetTitle, p); if ok then return Plain(s) end end
    return ""
end
local function PanelTexts()
    local out = {}
    for _, r in ipairs(Regions(Panel())) do out[#out + 1] = Plain(Text(r)) end
    return out
end

local function RowCount()
    local sb = ScrollBox()
    if not sb then return nil end
    local ok, dp = pcall(sb.GetDataProvider, sb)
    if not ok or not dp then return 0 end
    if dp.GetSize then
        local ok2, n = pcall(dp.GetSize, dp, true)
        if ok2 and type(n) == "number" then return n end
    end
    return 0
end

-- all node data of the current view (walks the tree data provider)
local function ViewData()
    local out = {}
    local sb = ScrollBox()
    local dp = sb and sb:GetDataProvider()
    if not dp then return out end
    local function walk(node)
        local kids = node.GetNodes and node:GetNodes() or node.nodes or {}
        for _, k in ipairs(kids) do
            if k.GetData then out[#out + 1] = k:GetData() end
            walk(k)
        end
    end
    local root = dp.GetRootNode and dp:GetRootNode()
    if root then
        walk(root)
    elseif dp.Enumerate then
        for a, b in dp:Enumerate() do
            local node = (type(b) == "table" and b.GetData) and b or a
            if type(node) == "table" and node.GetData then out[#out + 1] = node:GetData() end
        end
    end
    return out
end

local function GroupKeys()
    local keys = {}
    for _, d in ipairs(ViewData()) do
        if type(d) == "table" and d.header and d.key then keys[d.key] = true end
    end
    return keys
end

local function VisibleRows()
    local sb = ScrollBox()
    if not sb then return {}, {} end
    local ok, frames = pcall(sb.GetFrames, sb)
    if not ok or type(frames) ~= "table" then return {}, {} end
    local rows, headers = {}, {}
    for _, f in ipairs(frames) do
        if Shown(f) then
            if ObjType(f) == "CheckButton" then headers[#headers + 1] = f else rows[#rows + 1] = f end
        end
    end
    return rows, headers
end

local function Refresh()
    local t = Now()
    if ns.RefreshAll then ns.RefreshAll() elseif ns.UI then ns.UI:Refresh() end
    return Now() - t
end

-- tooltip lines (real client: GameTooltipTextLeftN)
local function TooltipLines(tt)
    tt = tt or GameTooltip
    local out = {}
    local n = tt:NumLines() or 0
    local name = tt.GetName and tt:GetName() or "GameTooltip"
    for i = 1, n do
        local fs = _G[name .. "TextLeft" .. i]
        out[#out + 1] = Plain(fs and Text(fs) or "")
    end
    return out
end
local function LinesWith(lines, text)
    local n = 0
    text = Plain(text)
    for _, l in ipairs(lines) do if l:find(text, 1, true) then n = n + 1 end end
    return n
end

local function ItemTooltip(id)
    GameTooltip:SetOwner(UIParent, "ANCHOR_NONE")
    GameTooltip:SetItemByID(id)
    local lines = TooltipLines()
    GameTooltip:Hide()
    return lines
end

-- hover and click rows of the current view (everything dangerous is intercepted)
local function HoverRows(a, what)
    local rows = VisibleRows()
    for i = 1, math.min(#rows, MAX_ROWS) do
        local r = rows[i]
        local enter, leave = r:GetScript("OnEnter"), r:GetScript("OnLeave")
        if enter then
            local ok, err = pcall(enter, r)
            a:Ok(ok, what .. ": Tooltip – " .. tostring(err))
            if leave then pcall(leave, r) end
        end
    end
end
local function ClickRows(a, what)
    local rows = VisibleRows()
    for i = 1, math.min(#rows, MAX_ROWS) do
        local r = rows[i]
        local onClick = r:GetScript("OnClick")
        if onClick then
            local ok1, e1 = pcall(onClick, r, "LeftButton")
            local ok2, e2 = pcall(onClick, r, "RightButton")
            a:Ok(ok1 and ok2, what .. ": Klick – " .. tostring(e1 or e2))
        end
    end
end
local function ToggleFirstHeader(a, what)
    local sb = ScrollBox()
    local frames = sb and sb:GetFrames() or {}
    local list = {}
    for _, f in ipairs(frames) do if Shown(f) then list[#list + 1] = f end end
    table.sort(list, function(x, y)
        local tx = x.GetTop and select(2, pcall(x.GetTop, x)) or 0
        local ty = y.GetTop and select(2, pcall(y.GetTop, y)) or 0
        return (tonumber(tx) or 0) > (tonumber(ty) or 0)
    end)
    local h
    for i, f in ipairs(list) do
        local nxt = list[i + 1]
        if ObjType(f) == "CheckButton" and nxt and ObjType(nxt) ~= "CheckButton" then h = f; break end
    end
    if not h or not h:GetScript("OnClick") then return end
    local label = Text(h.label)
    local before = RowCount() or 0
    h:Click()
    local _, headers = VisibleRows()
    for _, x in ipairs(headers) do
        if Text(x.label) == label then x:Click(); break end
    end
    local after = RowCount() or 0
    a:Ok(after == before, what .. ": Gruppe zu/auf " .. before .. " -> " .. after)
end

---------------------------------------------------------------------------
-- Registration of test cases
---------------------------------------------------------------------------
-- opts: api = replaces Blizzard functions; errors = the case produces counted errors on purpose (they are removed
-- again); selftest = part of /ps selftest
local function Case(id, area, name, opts, fn)
    if type(opts) == "function" then fn, opts = opts, {} end
    local c = { id = id, area = area, name = name, fn = fn, api = opts.api, errors = opts.errors, selftest = opts.selftest,
                final = opts.final }
    cases[#cases + 1] = c
    byId[id] = c
    return c
end
TR.cases = cases

-- shared values for the cases
local S = {
    SKIP = SKIP, CLIENT = CLIENT, WAIT = WAIT, NewAgg = NewAgg, Stub = Stub, OnUndo = OnUndo, SetDB = SetDB,
    SetSim = SetSim, Capture = Capture, Has = Has, Times = Times, Flavor = Flavor, TestDB = TestDB, SECRET = SECRET,
    SecretMode = SecretMode, Orig = Orig, Intercepted = Intercepted, GuardTotal = GuardTotal, Meta = Meta,
    ProfList = ProfList, BiggestProf = BiggestProf, LWProf = LWProf, FirstRecipe = FirstRecipe, TestPrices = TestPrices,
    Panel = Panel, ActiveHost = ActiveHost, SearchBox = SearchBox, MissingCheck = MissingCheck, Tabs = Tabs,
    TabFor = TabFor, ScrollBox = ScrollBox, PanelTitle = PanelTitle, PanelTexts = PanelTexts, RowCount = RowCount,
    ViewData = ViewData, GroupKeys = GroupKeys, VisibleRows = VisibleRows, Refresh = Refresh,
    TooltipLines = TooltipLines, LinesWith = LinesWith, ItemTooltip = ItemTooltip, HoverRows = HoverRows,
    ClickRows = ClickRows, ToggleFirstHeader = ToggleFirstHeader, Median3 = Median3, AfterLaunch = AfterLaunch,
    Confirmed = Confirmed, Count = Count, Plain = Plain, Text = Text, Children = Children, Regions = Regions,
    Descendants = Descendants, Shown = Shown, ObjType = ObjType, DeepCopy = DeepCopy, Diff = Diff, Now = Now,
    RANKS = RANKS, Active = Active, Case = Case,
}
TR.S = S

-- BEGIN KEYS_USED (generated by tests/gen_locale_keys.py – do not edit by hand)
TR.KEYS_USED = {
    "AH_CUT", "AH_FEE", "ALERT_CLICK", "ALERT_EXPLAIN", "ALERT_GROUP", "ALERT_HEAD", "ALERT_LINE", "ALERT_MORE",
    "ALERT_OPTION", "ALERT_SNIPE_DONE", "ALERT_WHO", "ALL_RECIPES", "ALREADY_LEARNED", "AT_RUN_AGAIN",
    "AT_SELECT_ALL", "BAG_EXPLAIN", "BAG_GROUP", "BAG_NEEDED", "BAG_NOBODY", "BEST_CRAFTABLE", "BEST_HINT",
    "BEST_NO_MATS", "BEST_USE", "BEST_WHY", "CD_DAYS", "CD_EXPLAIN", "CD_GROUP", "CD_HOURS", "CD_MINUTES", "CD_READY",
    "COST", "CREATES", "DATA_INFO", "DE_ARMOR", "DE_BASED_ON", "DE_CHANCE", "DE_CHANCES", "DE_CHANCES_EXPLAIN",
    "DE_CHANCE_VS", "DE_COUNT", "DE_CUT", "DE_DEALS", "DE_DEALS_EXPLAIN", "DE_DEAL_LINE", "DE_DEAL_PRICE",
    "DE_EXPLAIN", "DE_GROUP", "DE_ILVL", "DE_MARGIN_ASK", "DE_MARGIN_EXPLAIN", "DE_MARGIN_ROW", "DE_NEED_AHS",
    "DE_NETVALUE", "DE_NONE", "DE_NO_RESULTS", "DE_SOURCE_AHS", "DE_START_VALUES", "DE_SUMMARY", "DE_SUMMARY_NOAHS",
    "DE_TAB", "DE_VALUE", "DE_VALUE_OWN", "DE_VALUE_SHARED", "DE_WEAPON", "DG_CLICK", "DG_CLIENT", "DG_CLOSE",
    "DG_DOCK", "DG_DOCK_AHS", "DG_DOCK_FREE", "DG_EMPTY", "DG_ERRORS", "DG_HEAD", "DG_HINT", "DG_NO", "DG_NONE",
    "DG_OVERLAP_AHS", "DG_OVERLAP_NOROOM", "DG_PANEL", "DG_PENDING", "DG_PRICE", "DG_REFRESH", "DG_REQUESTS",
    "DG_SECTION_DIAG", "DG_SECTION_ENTRIES", "DG_SESSIONS", "DG_SETTINGS", "DG_TITLE", "DG_YES", "DIAG_ERRORS",
    "DIAG_LAST_REPORT", "DIAG_PENDING", "ENCHANT", "FAVOR_BALANCE_UNKNOWN", "FAVOR_CLICK_REMOVE", "FAVOR_COST",
    "FAVOR_COSTS_UNREADABLE", "FAVOR_CRATES", "FAVOR_CRATES_EXPLAIN", "FAVOR_CRATE_AH", "FAVOR_CRATE_BEST",
    "FAVOR_CRATE_BUNDLES", "FAVOR_CRATE_FAVOR", "FAVOR_CRATE_GIVES", "FAVOR_CRATE_PLUS_AH", "FAVOR_CRATE_READY",
    "FAVOR_DIAG_READABLE", "FAVOR_ENOUGH", "FAVOR_ESTIMATE", "FAVOR_GUIDE", "FAVOR_GUILD_NOBODY", "FAVOR_HAVE",
    "FAVOR_HAVE_LINE", "FAVOR_HAVE_SHORT", "FAVOR_MISSING", "FAVOR_NAME", "FAVOR_ONLY_FOREVER", "FAVOR_PER_POINT",
    "FAVOR_PLAN", "FAVOR_PLAN_EMPTY", "FAVOR_PLAN_EXPLAIN", "FAVOR_PLAN_TOTAL", "FAVOR_RECIPES",
    "FAVOR_RECIPES_EXPLAIN", "FAVOR_SEEN", "FAVOR_TAB", "FAVOR_TODAY_CLICK", "FAVOR_TODAY_EXPLAIN",
    "FAVOR_TODAY_OPTION", "FAVOR_WISH_OFF", "FAVOR_WISH_ON", "FLAVOR_ERA", "FLAVOR_FOREVER", "FLAVOR_RETAIL",
    "F_MISSING", "F_NEW", "GOAL_BOTH", "GOAL_BOTH_TIP", "GOAL_CHOSEN", "GOAL_CLICK", "GOAL_CURRENT",
    "GOAL_DEFAULT_TAG", "GOAL_DONE", "GOAL_GOLD", "GOAL_GOLD_TIP", "GOAL_HEADER", "GOAL_PICK", "GOAL_QUESTION",
    "GOAL_SELL", "GOAL_SELL_TIP", "GOAL_SET", "GOLD_EXPLAIN", "GOLD_GROUP", "GOLD_NONE", "GUILD_CRAFTERS",
    "GUILD_NOBODY", "GUILD_NOBODY_EXPLAIN", "GUILD_NOBODY_GROUP", "HELP", "KNOWN", "KNOWN_BY", "LEARN_WHY", "LEVEL",
    "LEVEL_EXPLAIN", "LEVEL_MAT_EXPLAIN", "LEVEL_MAT_GROUP", "LEVEL_MAT_NOTLEARNED", "LEVEL_TOP", "LL_FROM",
    "LL_ISGREY", "LL_OPTION", "LL_TIP_EXACT", "LL_TITLE", "LL_TO", "LL_TO_APPROX", "MAT_COST", "MAX_RANK",
    "MINIMAP_DRAG", "MINIMAP_HIDDEN", "MINIMAP_LEFT", "MINIMAP_OPTION", "MINIMAP_RIGHT", "MINIMAP_SHOWN",
    "MISSING_BY", "MORE", "NET_CRAFT", "NET_DE", "NET_FEE_PART", "NET_POINT", "NEW_TAG", "NEXT_RANK", "NOT_IN_COMBAT",
    "NOT_LEARNED_YET", "NO_PRICE", "OFF", "ON", "OPEN_PROF_FIRST", "OPTIONS_HEAD", "OPTIONS_LINE", "ORIGIN_AH",
    "ORIGIN_CRAFT", "ORIGIN_FARM", "ORIGIN_VENDOR", "OTHER_FACTION", "PER_PIECE", "PER_POINT", "PLAN_BOUGHT",
    "PLAN_COST", "PLAN_EXPLAIN", "PLAN_HAVE_ALL", "PLAN_HEADER", "PLAN_ITEM_LINE", "PLAN_MISSING", "PLAN_NO_MERCHANT",
    "PLAN_SHOPPING", "PLAN_SHOPPING_EXPLAIN", "PLAN_SNIPE_BTN", "PLAN_SNIPE_DETAIL", "PLAN_SNIPE_DONE",
    "PLAN_SNIPE_NOTHING", "PLAN_SNIPE_TIP", "PLAN_SNIPE_WHAT", "PLAN_STEPS", "PLAN_STUCK", "PLAN_STUCK_HINT",
    "PLAN_SUMMARY", "PLAN_TAB", "PLAN_TARGET_CLICK", "PLAN_TARGET_RETAIL", "PLAN_TARGET_ROW", "PLAN_VENDOR_BTN",
    "PLAN_VENDOR_DETAIL", "PLAN_VENDOR_NOTHING", "PRICE_NONE", "PRICE_SOURCE", "RANKING_EXPLAIN", "RANKING_NONE",
    "RANKING_PLACE", "RANKING_SUMMARY", "RANKING_TAB", "RANKING_TOP", "RANK_0", "RANK_PER_POINT", "RANK_REQ",
    "REAGENTS", "REAGENT_USED", "REAGENT_YOU_KNOW", "RECIPES_TAB", "REP_7", "REP_NEEDED", "REQ", "SEARCH",
    "SECONDARY_NOTE", "SELECT_FAIL", "SELL_AH", "SELL_AH_NET", "SELL_EXPLAIN", "SELL_GROUP", "SELL_SUMMARY",
    "SELL_VENDOR", "SKILL_LEVELS", "SKILL_UNKNOWN", "SNIPE_BUDGET", "SNIPE_DONE", "SNIPE_EXPLAIN", "SNIPE_HEADER",
    "SNIPE_ITEMS_BTN", "SNIPE_ITEMS_DETAIL", "SNIPE_ITEMS_TIP", "SNIPE_MATS_BTN", "SNIPE_MATS_DETAIL",
    "SNIPE_MATS_TIP", "SNIPE_NEED_AHS", "SNIPE_NOTHING", "SNIPE_NOTHING_MATS", "SNIPE_WHAT_ITEMS", "SNIPE_WHAT_MATS",
    "SOURCES", "SRC_AUTO", "SRC_CONTAINER", "SRC_DROP", "SRC_QUEST", "SRC_RETAIL", "SRC_TRAINER", "SRC_TRAINER_AT",
    "SRC_UNKNOWN", "SRC_VENDOR", "SRC_WORLDDROP", "SUBTITLE", "TAG_LEARN", "TEST_ACTIVE", "TEST_ALL", "TEST_DIAG",
    "TEST_ENCHANTER", "TEST_FAIL", "TEST_HELP", "TEST_KNOWN", "TEST_KNOWN_ALL", "TEST_KNOWN_NONE", "TEST_KNOWN_REAL",
    "TEST_OPEN_PANEL", "TEST_PASS", "TEST_PRICES", "TEST_PROF", "TEST_RELOAD_NEEDED", "TEST_REPORT_SAVED",
    "TEST_RESET", "TEST_RUN", "TEST_SIM", "TEST_SKILL", "TEST_SKILL_OFF", "TEST_TITLE", "TEST_WAYPOINT", "TITLE",
    "TODAY_CLICK", "TODAY_EXPLAIN", "TODAY_GROUP", "TODAY_NEED_AHS", "TODAY_NONE", "TODAY_NOT_FOUND",
    "TODAY_PER_CRAFT", "TODAY_STEP_AH", "TODAY_STEP_CRAFT", "TODAY_STEP_GOVENDOR", "TODAY_STEP_OPENPROF",
    "TODAY_STEP_SELL", "TODAY_STEP_VENDOR", "TRAINERS", "TR_ABORTED_COMBAT", "TR_API_WARN", "TR_CLIENT_LIST_CONFIRM",
    "TR_CLIENT_LIST_HEAD", "TR_CLIENT_LIST_HINT", "TR_CLIENT_LIST_NONE", "TR_COMBAT", "TR_DONE", "TR_ERROR_SOON",
    "TR_MISSING_DEPS", "TR_NOT_AUTOMATED", "TR_NOT_RUNNING", "TR_NO_REPORT", "TR_PROGRESS", "TR_REPORT_HINT",
    "TR_REPORT_TITLE", "TR_RUNNING", "TR_SHOP_OPEN", "TR_START", "TR_STOPPED", "UNSUPPORTED", "VIA_AH", "VIA_DE",
    "VIA_VENDOR", "VZ_MARKUP_ASK", "VZ_MARKUP_ROW", "VZ_MIN_ASK", "VZ_MIN_ROW", "VZ_NO_CUSTOMER", "VZ_NO_PRICE",
    "VZ_OFFER", "VZ_OFFER_PRICE", "VZ_PRICE", "VZ_PRICE_EXPLAIN", "VZ_PRICE_OWNMATS", "VZ_PRICE_SHORT",
    "VZ_SURCHARGE", "VZ_WHISPER_HINT", "WP_CHAT", "WP_CLICK", "WP_NO_COORDS", "WP_RIGHTCLICK", "WP_RIGHTCLICK_DROP",
    "WP_SET", "YOUR_SKILL",
}
-- END KEYS_USED

---------------------------------------------------------------------------
-- A. Loading and detection
---------------------------------------------------------------------------
Case("T01", "A", "Alle Dateien und Module geladen", { selftest = true }, function()
    if not ns.Flavor then return SKIP("nicht unterstützt") end
    local a = NewAgg()
    for _, m in ipairs({ "L", "Scan", "Lifeline", "Waypoint", "Prices", "Favor", "Disenchant", "Plan", "Alerts", "Guild",
        "Today", "Advisor", "UI", "Minimap", "TestMode", "AutoTest", "ReagentLines" }) do
        a:Ok(ns[m] ~= nil, "ns." .. m .. " fehlt")
    end
    a:Ok(#ns.Recipes > 0, "ns.Recipes leer")
    a:Ok(type(SlashCmdList.PROFESSIONSENTINEL) == "function", "Slash-Befehl fehlt")
    a:Ok(SLASH_PROFESSIONSENTINEL1 == "/ps" and SLASH_PROFESSIONSENTINEL2 == "/professionsentinel", "Slash-Namen")
    return a:Result("Module")
end)

Case("T02", "A", "Version .toc = Code", { selftest = true }, function()
    local toc = Meta("Version")
    return toc == ns.VERSION, "toc " .. tostring(toc) .. " / Code " .. tostring(ns.VERSION), "gleich"
end)

Case("T05", "A", "Datenpaket passt zum Client", { selftest = true }, function()
    local m = ns.DataMeta or {}
    local a = NewAgg()
    a:Ok(m.flavor == ns.Flavor, "DataMeta.flavor " .. tostring(m.flavor) .. " ≠ " .. tostring(ns.Flavor))
    a:Ok(m.count == #ns.Recipes, "DataMeta.count " .. tostring(m.count) .. " ≠ " .. #ns.Recipes)
    a:Ok(type(m.build) == "string" and m.build ~= "", "build leer")
    a:Ok(#(ns.RecipeRows or {}) == #ns.Recipes, "mehr als ein Datensatz geladen")
    local ok, res = a:Result("Prüfungen")
    return ok, res .. " · " .. tostring(m.flavor) .. " " .. #ns.Recipes .. " Rezepte, Build " .. tostring(m.build)
end)

Case("T06", "A", "Interface-Nummer akzeptiert", {}, function()
    local iface = select(4, GetBuildInfo())
    local reason
    if C_AddOns and C_AddOns.GetAddOnInfo then
        local ok, _, _, _, _, r = pcall(C_AddOns.GetAddOnInfo, ADDON)
        if ok then reason = r end
    elseif GetAddOnInfo then
        local ok, _, _, _, _, r = pcall(GetAddOnInfo, ADDON)
        if ok then reason = r end
    end
    if reason == "INTERFACE_VERSION" then return false, "veraltet (Interface " .. tostring(iface) .. ")", "akzeptiert" end
    if ns.IsForever and AfterLaunch() and not Confirmed("T06") then
        return CLIENT("Launch: /dump select(4, GetBuildInfo()) – die Nummer muss in allen 4 TOCs stehen (Client "
            .. tostring(iface) .. ")")
    end
    return true, "Interface " .. tostring(iface)
end)

Case("T07", "A", "GoldSentinelGame Version 2 und gleich erkannt", { selftest = true }, function()
    local GG = G()
    if not GG then return false, "GoldSentinelGame fehlt", "vorhanden" end
    local a = NewAgg()
    a:Ok(type(GG.version) == "number" and GG.version == 2, "G.version " .. tostring(GG.version))
    a:Ok(GG.apiVersion == 2, "G.apiVersion " .. tostring(GG.apiVersion))
    for _, f in ipairs({ "IsSecret", "AnySecret", "Safe", "InCombat", "Short", "CleanName", "SameName", "Status", "SetTestFlavor" }) do
        a:Ok(type(GG[f]) == "function", "G." .. f .. " fehlt")
    end
    if ns.Flavor then a:Ok(GG.flavor == ns.Flavor, "G.flavor " .. tostring(GG.flavor) .. " ≠ " .. tostring(ns.Flavor)) end
    a:Ok(GG.IsModern == ns.UsesModernProfessions, "G.IsModern ≠ UsesModernProfessions")
    return a:Result("Prüfungen")
end)

local function FlavorSnapshot()
    return { Flavor = ns.Flavor, IsForever = ns.IsForever, IsEra = ns.IsEra, IsRetail = ns.IsRetail,
        UsesModernProfessions = ns.UsesModernProfessions, HasSourceData = ns.HasSourceData, Interface = ns.Interface }
end
S.FlavorSnapshot = FlavorSnapshot

Case("T08", "A", "Weichen simuliert: forever", { selftest = true }, function()
    Active().flavorSnap = Active().flavorSnap or FlavorSnapshot()
    Flavor("forever")
    local a = NewAgg()
    a:Ok(ns.Flavor == "forever", "Flavor " .. tostring(ns.Flavor))
    a:Ok(ns.IsForever == true, "IsForever")
    a:Ok(ns.UsesModernProfessions == true, "UsesModernProfessions")
    a:Ok(ns.HasSourceData == true, "HasSourceData")
    a:Ok(ns.Favor.Active() == true, "Favor.Active")
    a:Ok(ns.Prices.FeeApplies() == true, "FeeApplies")
    a:Ok(ns.FlavorName() == L.FLAVOR_FOREVER, "FlavorName")
    return a:Result("Weichen")
end)

Case("T09", "A", "Weichen simuliert: era", { selftest = true }, function()
    Active().flavorSnap = Active().flavorSnap or FlavorSnapshot()
    Flavor("era")
    local a = NewAgg()
    a:Ok(ns.Flavor == "era", "Flavor " .. tostring(ns.Flavor))
    a:Ok(ns.UsesModernProfessions == false, "UsesModernProfessions")
    a:Ok(ns.HasSourceData == true, "HasSourceData")
    a:Ok(ns.Favor.Active() == false, "Favor.Active")
    a:Ok(ns.Prices.FeeApplies() == false, "FeeApplies")
    a:Ok(ns.FlavorName() == L.FLAVOR_ERA, "FlavorName")
    return a:Result("Weichen")
end)

Case("T10", "A", "Weichen simuliert: tbc und retail", { selftest = true }, function()
    Active().flavorSnap = Active().flavorSnap or FlavorSnapshot()
    local a = NewAgg()
    local shownBefore = ns.UI:IsShown() and true or false
    do
        local mark = #Active().stack
        Flavor("tbc")
        local out = Capture()
        a:Ok(ns.Flavor == nil, "tbc: Flavor " .. tostring(ns.Flavor))
        a:Ok(ns.UsesModernProfessions == false, "tbc: UsesModernProfessions")
        SlashCmdList.PROFESSIONSENTINEL("")
        a:Ok(Has(out, string.format(L.UNSUPPORTED, ns.Interface or 0)), "tbc: /ps ohne Hinweis")
        a:Ok((ns.UI:IsShown() and true or false) == shownBefore, "tbc: /ps hat das Panel umgeschaltet")
        Unwind(Active(), mark)
    end
    Flavor("retail")
    a:Ok(ns.Flavor == "retail", "retail: Flavor")
    a:Ok(ns.UsesModernProfessions == true, "retail: modern")
    a:Ok(ns.HasSourceData == false, "retail: HasSourceData")
    a:Ok(ns.Favor.Active() == false, "retail: Favor.Active")
    a:Ok(ns.Prices.FeeApplies() == false, "retail: FeeApplies")
    return a:Result("Weichen")
end)

Case("T11", "A", "Weichen wieder echt", { selftest = true }, function()
    local GG = G()
    GG.SetTestFlavor(nil)
    ns.ApplyFlavor(GG)
    local snap = Active().flavorSnap or FlavorSnapshot()
    local d = Diff(snap, FlavorSnapshot())
    local status = GG.Status()
    local testTag = "[" .. GG.Text("test") .. "]"
    if d then return false, "abweichend: " .. d, "identisch" end
    if status:find(testTag, 1, true) then return false, "G.Status enthält " .. testTag, "ohne [Test]" end
    return true, tostring(ns.Flavor)
end)

---------------------------------------------------------------------------
-- B. Every function – slash commands, core, scan, lifeline, waypoints, prices, plan
---------------------------------------------------------------------------
local function Slash(msg) SlashCmdList.PROFESSIONSENTINEL(msg) end

Case("T12", "B", "/ps help mit und ohne Entwickler", {}, function()
    local out = Capture()
    Slash("help")
    local dev = Has(out, L.TEST_HELP)
    local D = _G.GoldSentinelDev
    Stub(D, "IsDev", function() return false end)
    local out2 = Capture()
    Slash("help")
    local plain = Has(out2, L.HELP) and not Has(out2, L.TEST_HELP)
    return dev and plain, (dev and "Entwickler: TEST_HELP" or "Entwickler: falsch") .. " · " .. (plain and "Spieler: HELP" or "Spieler: falsch"), "richtig"
end)

Case("T13", "B", "/ps und /professionsentinel (Panel umschalten)", {}, function()
    if ActiveHost() then return SKIP("Berufsfenster offen – Fall gilt nur ohne Berufsfenster") end
    local a = NewAgg()
    ns.UI:Hide()
    SetSim(nil)
    local out = Capture()
    Slash("")
    a:Ok(Has(out, L.OPEN_PROF_FIRST), "ohne Beruf: kein Hinweis OPEN_PROF_FIRST")
    a:Ok(not ns.UI:IsShown(), "ohne Beruf: Panel offen")
    SetSim({ prof = LWProf() })
    SlashCmdList.PROFESSIONSENTINEL("")
    a:Ok(ns.UI:IsShown(), "mit Sim.prof: Panel zu")
    _G.SlashCmdList.PROFESSIONSENTINEL("")
    a:Ok(not ns.UI:IsShown(), "zweites /ps: Panel offen")
    a:Ok(_G["SLASH_PROFESSIONSENTINEL2"] == "/professionsentinel", "/professionsentinel nicht registriert")
    return a:Result("Schritte")
end)

Case("T14", "B", "/ps line", {}, function()
    Capture()
    local l0 = ns.db.lifeline
    Slash("line"); local l1 = ns.db.lifeline
    Slash("line"); local l2 = ns.db.lifeline
    return l1 == not l0 and l2 == l0, tostring(l0) .. " -> " .. tostring(l1) .. " -> " .. tostring(l2), "kippt und zurück"
end)

Case("T15", "B", "/ps heute", {}, function()
    Capture()
    ns.UI:Hide()
    SetSim({ prof = LWProf() })
    SetDB("panelMode", ns.db.panelMode)
    Slash("heute")
    local keys = GroupKeys()
    local ok = ns.db.panelMode == "ranking" and ns.UI:IsShown() and keys.today == true
    ns.UI:Hide()
    return ok, "Modus " .. tostring(ns.db.panelMode) .. ", Gruppe today " .. tostring(keys.today == true), "ranking + today"
end)

Case("T16", "B", "/ps alarm", {}, function()
    Capture()
    local a0 = ns.db.recipeAlert ~= false
    Slash("alarm"); local a1 = ns.db.recipeAlert ~= false
    Slash("alarm"); local a2 = ns.db.recipeAlert ~= false
    return a1 == not a0 and a2 == a0, tostring(a0) .. " -> " .. tostring(a1) .. " -> " .. tostring(a2), "kippt und zurück"
end)

Case("T17", "B", "/ps kisten", {}, function()
    local out = Capture()
    local t0 = ns.db.todayCrates
    if ns.IsForever then
        Slash("kisten"); local t1 = ns.db.todayCrates
        Slash("kisten"); local t2 = ns.db.todayCrates
        return t1 == not t0 and t2 == t0, tostring(t0) .. " -> " .. tostring(t1) .. " -> " .. tostring(t2), "kippt und zurück"
    end
    Slash("kisten")
    return Has(out, L.FAVOR_ONLY_FOREVER) and ns.db.todayCrates == t0, "Hinweis " .. tostring(Has(out, L.FAVOR_ONLY_FOREVER)), "nur Hinweis"
end)

Case("T18", "B", "/ps ziel", {}, function()
    local n0 = Intercepted("Fenster Ziel Verzauberkunst")
    Slash("ziel")
    local n1 = Intercepted("Fenster Ziel Verzauberkunst")
    return n1 == n0 + 1, "Zielfrage abgefangen ×" .. (n1 - n0), "×1"
end)

Case("T19", "B", "/ps test, selftest, autotest, testroutine ohne Freigabe", {}, function()
    local a = NewAgg()
    local D = _G.GoldSentinelDev
    local w = _G.ProfessionSentinelTestMode
    local wasShown = w and w:IsShown() or false
    do
        local mark = #Active().stack
        local origReq = D.Require
        local blocked = 0
        Stub(D, "IsDev", function() return false end)
        Stub(D, "Require", function(self, addon)
            local r = origReq(self, addon)
            if not r then blocked = blocked + 1 end
            return r
        end)
        local before = #runs
        for _, cmd in ipairs({ "test", "selftest", "autotest", "autotest bericht", "testroutine", "tr" }) do Slash(cmd) end
        a:Ok(blocked == 6, "gesperrt " .. blocked .. "/6")
        local w2 = _G.ProfessionSentinelTestMode
        a:Ok(not (w2 and w2:IsShown() and not wasShown), "Testmodus-Fenster ohne Freigabe geöffnet")
        a:Ok(#runs == before, "Testroutine ohne Freigabe gestartet")
        Unwind(Active(), mark)
    end
    -- with the developer unlock: window opens and closes, report / history without errors
    Capture()
    Slash("test")
    local w3 = _G.ProfessionSentinelTestMode
    a:Ok(w3 and w3:IsShown() ~= wasShown, "Testmodus-Fenster nicht umgeschaltet")
    Slash("test")
    a:Ok(not w3 or w3:IsShown() == wasShown, "Testmodus-Fenster nicht zurück")
    local ok1 = pcall(Slash, "autotest verlauf")
    local ok2 = pcall(Slash, "autotest bericht")
    a:Ok(ok1 and ok2, "Bericht/Verlauf mit Fehler")
    local rep = _G.ProfessionSentinelAutoTestReport
    if rep and rep:IsShown() then rep:Hide() end
    local okST, res = pcall(ns.TestMode.RunSelfTest, ns.TestMode, false)
    a:Ok(okST and res ~= nil, "Selbsttest ohne Rückgabe")
    return a:Result("Befehle")
end)

Case("T20", "B", "Testroutine: Doppelstart und Stopp", {}, function()
    local a = NewAgg()
    local out = Capture()
    local before = #runs
    TR:Command("")
    a:Ok(#runs == before, "zweiter Lauf gestartet")
    a:Ok(Has(out, (L.TR_RUNNING:gsub("%%d.*$", ""))), "kein Hinweis TR_RUNNING")
    -- sub-run (area F only), stopped after the first case
    local localeBefore = Plain(L.TITLE) .. Plain(L.SEARCH)
    local sub = TR:RunSub({ filter = "F" }, function(r, step)
        if step == 1 then TR:Stop() end
    end)
    a:Ok(sub and sub.aborted ~= nil, "Unterlauf nicht abgebrochen")
    a:Ok(sub and sub.report and sub.report.counts.uebersprungen >= 1, "Rest nicht übersprungen")
    a:Ok(sub and sub.sandboxOK, "Sandbox im Unterlauf: " .. tostring(sub and sub.sandboxText))
    a:Ok(Plain(L.TITLE) .. Plain(L.SEARCH) == localeBefore, "Sprache nicht zurück")
    return a:Result("Schritte")
end)

Case("T21", "B", "Indizes", { selftest = true }, function()
    local bad, first = 0, nil
    local function fail(s) bad = bad + 1; first = first or s end
    for _, r in ipairs(ns.Recipes) do
        if ns.BySpell[r.spell] ~= r and not (ns.BySpell[r.spell] and ns.BySpell[r.spell].spell == r.spell) then fail("BySpell " .. r.spell) end
        for _, ri in ipairs(r.recipeItems) do if not ns.ByRecipeItem[ri.id] then fail("ByRecipeItem " .. ri.id) end end
        if r.out then
            local found = false
            for _, x in ipairs(ns.ByOutput[r.out] or {}) do if x == r then found = true end end
            if not found then fail("ByOutput " .. r.out) end
        end
        if not ns.ByName[r.name:lower()] then fail("ByName " .. r.name) end
        for k = 1, #r.reagents, 2 do if not ns.ByReagent[r.reagents[k]] then fail("ByReagent " .. r.reagents[k]) end end
    end
    for prof, list in pairs(ns.ByProf) do
        for i = 2, #list do
            local x, y = list[i - 1], list[i]
            if (x.cat or "") == (y.cat or "") then
                if x.yellow < y.yellow or (x.yellow == y.yellow and x.name > y.name) then fail("ByProf-Sortierung " .. prof) break end
            elseif x.catOrder > y.catOrder then fail("ByProf-Kategorie " .. prof) break end
        end
    end
    return bad == 0, #ns.Recipes .. " Rezepte, " .. bad .. " Abweichungen" .. (first and (": " .. first) or ""), "0 Abweichungen"
end)

Case("T22", "B", "Charakterdatensatz", { selftest = true }, function()
    local c = ns.Char()
    if not c then return false, "kein Charakterdatensatz", "vorhanden" end
    local a = NewAgg()
    a:Ok(type(c.known) == "table" and type(c.profs) == "table", "known/profs keine Tabellen")
    a:Ok(type(c.class) == "string", "class fehlt")
    a:Ok(c.faction ~= nil, "faction fehlt")
    a:Ok(c.flavor == ns.Flavor, "flavor " .. tostring(c.flavor))
    a:Ok(ns.CharKey() == ns.CharKey(), "CharKey nicht stabil")
    return a:Result("Felder")
end)

Case("T23", "B", "Namen und Sprache", { selftest = true }, function()
    local a = NewAgg()
    a:Ok(ns.isGerman == (GetLocale() == "deDE"), "isGerman")
    local p = LWProf()
    a:Ok(ns.ProfName(p) ~= "?", "ProfName " .. tostring(p))
    a:Ok(ns.ProfName(999999) == "?", "ProfName(999999)")
    local r = ns.Recipes[1]
    local want = ns.isGerman and r.name or ((r.nameEN and r.nameEN ~= "") and r.nameEN or r.name)
    a:Ok(ns.RecipeName(r) == want, "RecipeName")
    local nm = ns.ItemName(1)
    a:Ok(type(nm) == "string" and nm ~= "", "ItemName ohne Daten")
    return a:Result("Prüfungen")
end)

Case("T24", "B", "Berufs-Aliasse und Zuordnung", { selftest = true }, function()
    local a = NewAgg()
    a:Ok(ns.ResolveProf(nil) == nil, "ResolveProf(nil)")
    if ns.IsRetail then
        a:Ok(ns.ResolveProf(2915) == 2915, "ResolveProf(2915)")
    else
        a:Ok(ns.ResolveProf(2945) == 165, "ResolveProf(2945)")
        a:Ok(ns.ResolveProf(165) == 165, "ResolveProf(165)")
        local p = ns.ProfById[165]
        a:Ok(p and ns.MatchProfession(p.name) == 165, "MatchProfession(DE)")
        a:Ok(ns.MatchProfession(ns.ProfessionNamesEN[165]) == 165, "MatchProfession(EN)")
    end
    return a:Result("Prüfungen")
end)

Case("T25", "B", "Gelernt-Zustand", { selftest = true }, function()
    local r = ns.Recipes[1]
    SetSim({ known = "all" }); local all = ns.IsLearned(r)
    SetSim({ known = "none" }); local none = ns.IsLearned(r)
    SetSim(nil); local real = ns.IsLearned(r) == (ns.Scan:IsKnown(r.spell) and true or false)
    return all == true and none == false and real, "all " .. tostring(all) .. " · none " .. tostring(none) .. " · echt " .. tostring(real), "true/false/Scan"
end)

Case("T26", "B", "Scan-Funktionen", {}, function()
    local c = ns.Char()
    if not c or not next(c.profs) then return SKIP("keine Berufe") end
    local before = Count(c.profs)
    ns.Scan:UpdateProfessions()
    ns.Scan:ScanTradeSkill()
    ns.Scan:PassiveCheck()
    local p = next(c.profs)
    local rk = p and ns.Scan:Rank(p)
    local after = Count(ns.Char().profs)
    return after >= before and (rk == nil or type(rk) == "number"), before .. " -> " .. after .. " Berufe", "nicht weniger"
end)

Case("T27", "B", "Charaktere je Rezept (Scan:CharsFor)", {}, function()
    local r = FirstRecipe(function(x) return x.recipeItems[1] ~= nil end, LWProf())
    local db = TestDB({ chars = {
        ["Testa-Testrealm"] = { flavor = ns.Flavor, known = { [r.spell] = true }, profs = { [r.prof] = { rank = 1, max = 75 } } },
        ["Testb-Testrealm"] = { flavor = ns.Flavor, known = {}, profs = { [r.prof] = { rank = 1, max = 75 } } },
        ["Testc-Testrealm"] = { flavor = "andere", known = { [r.spell] = true }, profs = { [r.prof] = { rank = 1, max = 75 } } },
    } })
    db.chars[ns.CharKey()].profs = {}
    local knownBy, missingBy = ns.Scan:CharsFor(r.spell, r.prof)
    return #knownBy == 1 and #missingBy == 1, "kennen " .. #knownBy .. ", fehlt " .. #missingBy, "1 / 1 (andere Version zählt nicht)"
end)

-- Lifeline
Case("T28", "B", "Lebenslinie-Mathematik", { selftest = true }, function()
    local LL = ns.Lifeline
    local A = { req = 65, yellow = 95, green = 110, grey = 125, skillUps = 1 }
    local a = NewAgg()
    local c80 = LL.Calc(A, 80)
    a:Ok(c80 and c80.state == "orange" and c80.target == "yellow" and c80.crafts == 15 and c80.exact, "80 -> 15× bis Gelb")
    local c95 = LL.Calc(A, 95)
    a:Ok(c95 and c95.state == "yellow" and c95.target == "green" and (c95.crafts or 0) >= 15, "95 -> bis Grün")
    local c115 = LL.Calc(A, 115)
    a:Ok(c115 and c115.state == "green" and c115.target == "grey", "115 -> bis Grau")
    a:Ok(LL.Calc(A, 125) and LL.Calc(A, 125).state == "grey", "125 grau")
    a:Ok(LL.Calc(A, 50) and LL.Calc(A, 50).state == "red", "50 rot")
    local Z = { req = 35, yellow = 40, green = 40, grey = 40, skillUps = 1 }
    local z36 = LL.Calc(Z, 36)
    a:Ok(z36 and z36.target == "grey" and z36.crafts == 4, "35/40/40/40: 36 -> 4× bis Grau")
    local frac, pos = LL.Layout(A, 80)
    a:Ok(math.abs(frac[1] + frac[2] + frac[3] + frac[4] - 1) < 0.001 and pos and pos >= 0 and pos <= 1, "Layout-Summe")
    a:Ok(LL.Chance(A, 95) == 1 and LL.Chance(A, 110) < 1 and LL.Chance(A, 125) == 0, "Chance fällt")
    return a:Result("Fälle")
end)

Case("T29", "B", "Farbstufen je Version", { selftest = true }, function()
    local flb = ns.BySpell[2158]
    if not flb then return false, "Feine Lederstiefel (2158) fehlen", "vorhanden" end
    local s = flb.yellow .. "/" .. flb.green .. "/" .. flb.grey
    if ns.IsForever then return flb.grey == 125, s, "grau 125" end
    if ns.IsEra then return flb.grey == 150, s, "grau 150" end
    local p = ns.ProfById[flb.prof]
    return p ~= nil and p.parent == 165, "Linie " .. tostring(flb.prof), "Classic-Linie (parent 165)"
end)

Case("T30", "B", "Lebenslinien-Widget und Hooks", {}, function()
    local LL = ns.Lifeline
    local a = NewAgg()
    local w = LL.Create(UIParent, 2)
    LL.Update(w, { req = 65, yellow = 95, green = 110, grey = 125, skillUps = 1 }, 80)
    a:Ok(w:IsShown(), "Widget nicht sichtbar")
    LL.Update(w, { yellow = 0, green = 0, grey = 0 }, 80)
    a:Ok(not w:IsShown(), "Widget bei gelb 0 sichtbar")
    w:Hide()
    a:Ok(pcall(LL.RefreshBlizzard), "RefreshBlizzard")
    local host = ActiveHost()
    if not host then
        local ok, res = a:Result("Prüfungen")
        if not ok then return false, res end
        if Confirmed("T30") then return true, res .. " · Hook bestätigt" end
        return CLIENT("Berufsfenster öffnen, dann /ps testroutine b (Widget automatisch OK)")
    end
    if ns.UsesModernProfessions then a:Ok(LL.foreverHooked, "foreverHooked")
    else a:Ok(LL.tsHooked or LL.craftHooked, "tsHooked/craftHooked") end
    return a:Result("Prüfungen")
end)

-- Waypoints / trainers
Case("T31", "B", "Lehrer und Fundorte", { selftest = true }, function()
    if ns.HasSourceData == false then return SKIP("keine Quellendaten (Retail)") end
    local WP = ns.Waypoint
    local a = NewAgg()
    local lw = ns.Trainers and ns.Trainers[165] or {}
    a:Ok(#lw > 5, "Lehrer Lederverarbeitung " .. #lw)
    local una
    for _, e in ipairs(lw) do if e[1] == 3007 then una = e end end
    local n = ns.NPCs[3007]
    a:Ok(una and una[2] == 4 and n and n[6] and n[7] and n[8], "Una 3007 Rang 4 mit Koordinaten")
    local valid = true
    for _, list in pairs(ns.Trainers or {}) do
        for _, e in ipairs(list) do if not ns.NPCs[e[1]] or e[2] < 0 or e[2] > 5 then valid = false end end
    end
    a:Ok(valid, "ungültiger Lehrer")
    local n1, n2, n3 = WP.NextRank(70, 75), WP.NextRank(210, 225), WP.NextRank(300, 300)
    a:Ok(n1 and n1.key == 2 and n2 and n2.key == 4 and n3 == nil, "NextRank")
    local vendor
    for _, r in ipairs(ns.Recipes) do if r.nameEN == "Murloc Scale Belt" then vendor = WP.BestSourceNPC(r) end end
    a:Ok(vendor ~= nil and WP.Has(vendor), "Murlocschuppengürtel -> Händler")
    local av = WP.Available()
    a:Ok(av == "TomTom" or av == "map" or av == nil, "WP.Available " .. tostring(av))
    return a:Result("Prüfungen")
end)

Case("T32", "B", "Wegpunkt ohne Koordinaten und über TomTom-Attrappe", {}, function()
    if ns.HasSourceData == false then return SKIP("keine Quellendaten (Retail)") end
    local set = Orig("Waypoint", "Set")
    local a = NewAgg()
    local noCoords, withCoords
    for id, n in pairs(ns.NPCs) do
        if not (n[6] and n[7] and n[8]) then noCoords = noCoords or id else withCoords = withCoords or id end
        if noCoords and withCoords then break end
    end
    local out = Capture()
    if noCoords then
        a:Ok(set(noCoords) == false and Has(out, L.WP_NO_COORDS), "ohne Koordinaten")
    else
        a:Note("alle NPCs mit Koordinaten")
    end
    local added = 0
    Stub(_G, "TomTom", { AddWaypoint = function() added = added + 1; return {} end })
    local pins = Active().guards["C_Map.SetUserWaypoint"] or 0
    a:Ok(set(withCoords) == true and added == 1, "TomTom-Attrappe ×" .. added)
    a:Ok((Active().guards["C_Map.SetUserWaypoint"] or 0) == pins, "Kartenpin gesetzt")
    return a:Result("Prüfungen")
end)

-- Prices / ranking / plan
local function PriceRecipe()
    return { name = "G", req = 1, yellow = 100, green = 110, grey = 120, skillUps = 1, src = 1, recipeItems = {},
        reagents = { 2318, 3, 2320, 2 }, out = 4239, outMin = 1, outMax = 1 }
end
S.PriceRecipe = PriceRecipe

Case("T33", "B", "Preisrechnung", { selftest = true }, function()
    local P = ns.Prices
    SetSim({ prices = { [2318] = 800, [4239] = 3500 } })
    local a = NewAgg()
    local pr = P.Recipe(PriceRecipe())
    local F = P.FeePerPiece(4239)
    a:Ok(P.VendorBuy(2320) == 10, "Händlerware 10c: " .. tostring(P.VendorBuy(2320)))
    a:Ok(pr.known and pr.cost == 2420, "Kosten 24s 20c: " .. tostring(pr.cost))
    -- 35s: 5 % = 1s 75c (WoW Forever: AH fee max(5 %, 1s) = 1s 75c; elsewhere the 5 % cut) – the same 33s 25c
    a:Ok(F == (ns.IsForever and 175 or 0), "AH-Gebühr je Stück " .. tostring(F))
    a:Ok(pr.value == 3325 and pr.valueSource == "ah" and pr.ahCut == 175, "Gebühr 5 %: " .. tostring(pr.value))
    a:Ok(pr.net == 905, "Netto +9s 5c: " .. tostring(pr.net))
    local vs = P.VendorSell(4239) or 0
    if vs >= 40 then
        ns.Sim.prices[4239] = vs + 1
        local prV = P.Recipe(PriceRecipe())
        a:Ok(prV.valueSource == "vendor" and prV.value == vs, "Händler schlägt AH nach Kommission")
    end
    return a:Result("Fälle")
end)

Case("T34", "B", "Preisquelle und Reihenfolge", {}, function()
    local P = ns.Prices
    local a = NewAgg()
    SetSim(nil)
    Stub(_G, "AHAnalyzerPro", { GetMarketValue = function() return 111 end })
    Stub(_G, "TSM_API", { GetCustomPriceValue = function() return 222 end })
    Stub(_G, "Auctionator", { API = { v1 = { GetAuctionPriceByItemID = function() return 333 end } } })
    SetSim({ prices = { [2318] = 50 } })
    local v, src = P.AH(2318)
    a:Ok(v == 50 and src == "Test" and P.SourceName() == "Test", "Sim.prices zuerst")
    SetSim(nil)
    v, src = P.AH(2318)
    a:Ok(v == 111 and src == "AHSentinel" and P.SourceName() == "AHSentinel", "AHSentinel")
    Stub(_G, "AHAnalyzerPro", nil)
    v, src = P.AH(2318)
    a:Ok(v == 222 and src == "TSM" and P.SourceName() == "TSM", "TSM")
    Stub(_G, "TSM_API", nil)
    v, src = P.AH(2318)
    a:Ok(v == 333 and src == "Auctionator" and P.SourceName() == "Auctionator", "Auctionator")
    Stub(_G, "Auctionator", nil)
    a:Ok(P.AH(2318) == nil and P.SourceName() == nil, "ohne Quelle nil")
    return a:Result("Quellen")
end)

Case("T35", "B", "AH-Gebühr WoW Forever: max(5 %, 1s) pro Auktion (Regel vom 9. Nov.)", { selftest = true }, function()
    local P = ns.Prices
    if not ns.IsForever then
        local fee = P.FeePerPiece(2318, 1000)
        return fee == 0, tostring(fee), "0 (ausserhalb von WoW Forever nur die 5 % beim Verkauf)"
    end
    local a = NewAgg()
    Stub(_G, "AHAnalyzerPro", nil)      -- own calculation (with AHSentinel its function is used)
    a:Ok(P.AuctionFee(390) == 100, "5 × 78c = 3s 90c -> 1s: " .. tostring(P.AuctionFee(390)))
    a:Ok(P.AuctionFee(200) == 100, "2s -> 1s: " .. tostring(P.AuctionFee(200)))
    a:Ok(P.AuctionFee(10000) == 500, "1g -> 5s: " .. tostring(P.AuctionFee(10000)))
    -- a stack of 20 at 1c: ONE auction, ONE fee of 1s (5c per piece), not 20 × 1s
    Stub(P, "StackSize", function() return 20 end)
    local per = P.FeePerPiece(2318, 1)
    a:Ok(math.abs(per * 20 - 100) < 1e-9, "Stapel 20 × 1c -> einmal 1s: " .. tostring(per * 20))
    -- no separate listing fee from the vendor value any more
    local pr = P.Recipe({ name = "G", req = 1, yellow = 1, green = 2, grey = 3, skillUps = 1, src = 1, recipeItems = {},
        reagents = {}, out = 4239, outMin = 1, outMax = 1 })
    a:Ok(pr.ahFee == nil, "eigene Einstellgebühr noch berechnet")
    -- AHSentinel's function wins (same number in both addons)
    Stub(_G, "AHAnalyzerPro", { AuctionFee = function(_, price) return 123 end })
    a:Ok(P.AuctionFee(10000) == 123, "AHSentinel-Funktion nicht benutzt")
    return a:Result("Prüfungen")
end)

Case("T36", "B", "Geldtexte", { selftest = true }, function()
    local P = ns.Prices
    local a = NewAgg()
    a:Ok(P.MoneyPlain(0) == "0c", "0")
    a:Ok(P.MoneyPlain(12345) == "1g 23s 45c", "12345: " .. P.MoneyPlain(12345))
    a:Ok(P.MoneyPlain(-250, true) == "−2s 50c", "-250: " .. P.MoneyPlain(-250, true))
    a:Ok(P.MoneyPlain(nil) == "?", "nil")
    a:Ok(Plain(P.Money(12345)) == "1g 23s 45c", "Money: " .. Plain(P.Money(12345)))
    return a:Result("Texte")
end)

Case("T37", "B", "Ranglisten", { selftest = true }, function()
    local AD = ns.Advisor
    local a = NewAgg()
    local function R(name, y, g, gr, reag, req) return { name = name, req = req or 1, yellow = y, green = g, grey = gr, skillUps = 1, reagents = reag, src = 1, recipeItems = {} } end
    local list = { R("A", 100, 110, 120, { 1, 4 }), R("B", 95, 105, 115, { 2, 2 }), R("C", 85, 100, 115, { 3, 1 }),
        R("D", 70, 80, 90, { 4, 1 }), R("E", 130, 140, 150, { 5, 1 }, 120) }
    local learned = { A = true, B = true }
    local ranking = AD.Ranking(list, 90, function(r) return learned[r.name] end, function() return 0 end)
    local order = {}
    for _, e in ipairs(ranking) do order[#order + 1] = e.recipe.name end
    a:Ok(table.concat(order, ",") == "C,B,A", "Material je Punkt: " .. table.concat(order, ","))
    SetSim({ prices = { [2318] = 800, [4239] = 3500 } })
    local function RP(name, reag, out, y) return { name = name, req = 1, yellow = y or 100, green = (y or 100) + 10, grey = (y or 100) + 20, skillUps = 1, src = 1, recipeItems = {}, reagents = reag, out = out, outMin = 1, outMax = 1 } end
    local X, Y, Z = RP("X", { 2318, 1 }, 4239), RP("Y", { 2318, 6 }, 2320), RP("Z", { 2318, 2 }, 4239, 40)
    local lv, gd = {}, {}
    for _, e in ipairs(AD.Ranking({ X, Y, Z }, 90, function() return true end, function() return 0 end)) do lv[#lv + 1] = e.recipe.name end
    for _, e in ipairs(AD.GoldRanking({ X, Y, Z }, 90, function() return true end, function() return 0 end)) do gd[#gd + 1] = e.recipe.name end
    a:Ok(table.concat(lv, ",") == "X,Y", "Leveln: " .. table.concat(lv, ","))
    a:Ok(table.concat(gd, ",") == "X,Z,Y", "Gold: " .. table.concat(gd, ","))
    SetSim(nil)
    local lwp = LWProf()
    local real = AD.Ranking(ns.ByProf[lwp] or {}, 80, function() return false end, function() return 0 end, false)
    local sorted = true
    for i = 2, #real do if real[i].perPoint + 1e-9 < real[i - 1].perPoint then sorted = false end end
    a:Ok(#real > 0 and sorted, "echte Daten bei 80: " .. #real)
    return a:Result("Ranglisten")
end)

Case("T38", "B", "Advisor-Hilfen", {}, function()
    local AD = ns.Advisor
    local a = NewAgg()
    local prof = LWProf()
    SetSim({ prof = prof, prices = TestPrices() })
    local c = AD.Update(prof, 80)
    a:Ok(c.prof == prof and c.rank == 80, "AD.Update")
    local e = c.ranking[1]
    if not e then return SKIP("keine Rangliste bei 80") end
    a:Ok(AD.Reachable(e.recipe, 80) ~= nil, "Reachable")
    for _, fn in ipairs({ "Reason", "Value", "ValueColored", "OriginDots" }) do
        local ok, s = pcall(AD[fn], e)
        a:Ok(ok and type(s) == "string", fn)
    end
    a:Ok(type(AD.NetColored(1234)) == "string", "NetColored")
    a:Ok(AD.Entry(e.recipe) == e, "Entry")
    a:Ok(pcall(AD.GoldEntry, e.recipe) and pcall(AD.DEEntry, e.recipe), "Gold/DEEntry")
    a:Ok(type(AD.IsBest(e.recipe.spell)) == "boolean", "IsBest")
    SetSim({ prof = prof })
    AD.Update(prof, 80)
    local e2 = AD.current.ranking[1]
    a:Ok(e2 == nil or (pcall(AD.Reason, e2) and pcall(AD.ValueColored, e2)), "ohne Preise")
    AD.Update(nil, nil)
    return a:Result("Hilfen")
end)

Case("T39", "B", "Levelplan und Einkaufsliste", { selftest = true }, function()
    local AD = ns.Advisor
    local a = NewAgg()
    SetSim({ prices = { [2318] = 800, [4239] = 3500 } })
    local X = { name = "X", req = 1, yellow = 100, green = 110, grey = 120, skillUps = 1, src = 1, recipeItems = {}, reagents = { 2318, 1 }, out = 4239, outMin = 1, outMax = 1 }
    a:Ok(AD.LevelScore(1000, 0.25) == 250 and AD.LevelScore(-1000, 0.5) == -2000, "LevelScore")
    local plan = AD.Plan({ X }, 90, 100, function() return true end)
    a:Ok(#plan.steps == 1 and plan.steps[1].crafts == 10 and plan.reagents[2318] == 10, "Plan 90->100 10×")
    local shop = AD.Shopping(plan, function() return 4 end)
    a:Ok(shop[1] and shop[1].missing == 6, "fehlt 6")
    local st = ns.Plan.SniperTargets(shop, 10)
    a:Ok(st[1] and st[1].maxPrice == 880 and st[1].qty == 6, "Sniper 8s 80c ×6")
    a:Ok(type(AD.DefaultTarget(80, 150)) == "number", "DefaultTarget")
    return a:Result("Fälle")
end)

Case("T40", "B", "Planziel umschalten", {}, function()
    local PL = ns.Plan
    SetDB("planTarget", nil)
    Stub(ns, "RefreshAll", function() end)
    if ns.IsRetail then
        PL.CycleTarget(165, 80, 150)
        return ns.db.planTarget == nil and PL.Target(165, 80, 150) == 150, "Ziel " .. tostring(PL.Target(165, 80, 150)), "maxRank, unverändert"
    end
    local seq = {}
    for _ = 1, 3 do
        PL.CycleTarget(165, 80, 150)
        seq[#seq + 1] = PL.Target(165, 80, 150)
    end
    local s = table.concat(seq, ",")
    return s == "225,300,150", s, "225,300,150"
end)

Case("T41", "B", "Plan bauen", {}, function()
    local PL = ns.Plan
    local prof = LWProf()
    SetSim({ prof = prof, prices = TestPrices() })
    Stub(PL, "current", PL.current)
    local plan = PL.Build(prof, 80, 150)
    local a = NewAgg()
    a:Ok(plan and type(plan.list) == "table" and type(plan.totals) == "table" and plan.prof == prof, "Plan unvollständig")
    a:Ok(PL.MerchantOpen() == false or (MerchantFrame and MerchantFrame:IsShown()), "MerchantOpen ohne Händler")
    local ok = true
    for _, t in ipairs(PL.SniperTargets(plan and plan.list or {})) do
        local e
        for _, x in ipairs(plan.list) do if x.id == t.id then e = x end end
        if not e or e.origin == "vendor" or not e.known then ok = false end
    end
    a:Ok(ok, "Sniper-Ziel mit Händlerware oder ohne Preis")
    return a:Result("Prüfungen")
end)

Case("T42", "B", "Echter Kartenpin (halbautomatisch)", {}, function()
    if ns.HasSourceData == false then return SKIP("keine Quellendaten (Retail)") end
    local c = Confirmed("T42")
    if c then return true, "bestätigt " .. tostring(c.date) end
    return CLIENT("Rechtsklick im Panel auf ein fehlendes Rezept mit Händler: Pin muss gesetzt werden, danach selbst entfernen; bestätigen mit /ps testroutine ok T42")
end)

---------------------------------------------------------------------------
-- B. Every function – craft today, API, vendor buying, favor, enchanting, alarm, guild
---------------------------------------------------------------------------
local function TodayRecipe()
    -- one vendor reagent (Grober Faden, 10c) and one AH reagent (Leichtes Leder via Sim.prices)
    return { name = "Testrezept", nameEN = "Test recipe", prof = LWProf(), spell = 999001, out = 4239, outMin = 1, outMax = 1,
        reagents = { 2320, 2, 2318, 3 }, recipeItems = {}, req = 1, yellow = 100, green = 110, grey = 120, skillUps = 1, src = 1 }
end

Case("T43", "B", "Kandidaten", {}, function()
    local TD = ns.Today
    local a = NewAgg()
    SetSim({ prof = LWProf(), known = "all", prices = TestPrices() })
    local list = TD.Candidates(function() return 0 end)
    a:Ok(#list <= TD.MAX_ROWS, "mehr als 6 Zeilen")
    local money = GetMoney and GetMoney() or 0
    for i, e in ipairs(list) do
        if i > 1 then a:Ok(list[i - 1].net >= e.net, "nicht nach net sortiert") end
        a:Ok(e.count <= TD.TODAY_MAX, "count > 5")
        if money > 0 then a:Ok(e.count <= math.floor(money * TD.ITEM_SHARE / e.price.cost), "count > 20 % des Goldes") end
    end
    SetSim({ prof = LWProf(), known = "all" })
    Stub(_G, "AHAnalyzerPro", nil); Stub(_G, "TSM_API", nil); Stub(_G, "Auctionator", nil)
    a:Ok(#TD.Candidates() == 0, "ohne Preisquelle nicht leer")
    local ok, res = a:Result("Prüfungen")
    return ok, res .. " · " .. #list .. " Kandidaten"
end)

Case("T44", "B", "Nächster Schritt (TD.Plan / StepText)", {}, function()
    local TD, PL = ns.Today, ns.Plan
    local a = NewAgg()
    SetSim({ prices = { [2318] = 800, [4239] = 3500 } })
    local r = TodayRecipe()
    local merchant, openProf = false, nil
    Stub(PL, "MerchantOpen", function() return merchant end)
    Stub(TD, "OpenProfession", function() return openProf end)
    local function plan(counts, m, op)
        merchant, openProf = m, op
        local e = { recipe = r, count = 2 }
        TD.Plan(e, function(id) return counts[id] or 0 end)
        return e
    end
    local cases = {
        { "sell", { [4239] = 2 }, false, nil },
        { "vendor", { [2318] = 6 }, true, nil },
        { "ah", { [2320] = 4 }, false, nil },
        { "goVendor", { [2318] = 6 }, false, nil },
        { "craft", { [2318] = 6, [2320] = 4 }, false, r.prof },
        { "openProf", { [2318] = 6, [2320] = 4 }, false, nil },
    }
    for _, c in ipairs(cases) do
        local e = plan(c[2], c[3], c[4])
        a:Ok(e.step == c[1], "erwartet " .. c[1] .. ", ist " .. tostring(e.step))
        local txt = TD.StepText(e)
        a:Ok(type(txt) == "string" and txt ~= "" and not txt:find("%%[sd]"), c[1] .. ": StepText")
    end
    return a:Result("Schritte")
end)

Case("T45", "B", "Klick auf „Heute herstellen“ ohne echte Folge", {}, function()
    local TD = ns.Today
    local a = NewAgg()
    local out = Capture()
    local r = TodayRecipe()
    local g0 = GuardTotal()
    for _, step in ipairs({ "vendor", "ah", "craft", "sell", "goVendor", "openProf" }) do
        local mark = #Active().stack
        Stub(TD, "Plan", function(e) e.step = step; e.missing = e.missing or {}; e.have = 0; return e end)
        local labels = { vendor = "Today.BuyVendor", ah = "Today.BuyAH", craft = "Today.Craft", sell = "Today.Sell" }
        local n0 = labels[step] and Intercepted(labels[step]) or 0
        local ok = pcall(TD.Run, { recipe = r, count = 1, missing = {} })
        a:Ok(ok, step .. ": Lua-Fehler")
        if labels[step] then a:Ok(Intercepted(labels[step]) == n0 + 1, step .. ": nicht abgefangen") end
        Unwind(Active(), mark)
    end
    a:Ok(Has(out, L.TODAY_STEP_GOVENDOR), "goVendor ohne Hinweis")
    a:Ok(GuardTotal() == g0, "Wächter haben eine echte Aktion gezählt")
    return a:Result("Schritte")
end)

Case("T46", "B", "ProfessionSentinelAPI (für AHSentinel „Heute tun“)", { errors = true }, function()
    local API = _G.ProfessionSentinelAPI
    local a = NewAgg()
    a:Ok(type(API) == "table" and API.version == 1, "API.version")
    SetSim({ prof = LWProf(), known = "all", prices = TestPrices() })
    local list = API.TodayCrafts(2)
    a:Ok(type(list) == "table" and #list <= 2, "TodayCrafts(2)")
    for _, e in ipairs(list) do
        for _, k in ipairs({ "itemID", "recipeName", "count", "gold", "perCraft", "cost", "capital", "step", "stepText" }) do
            a:Ok(e[k] ~= nil, "Feld " .. k .. " fehlt")
        end
        a:Ok(type(e.run) == "function", "run fehlt")
        local n0 = 0
        for _, v in pairs(Active().intercepted) do n0 = n0 + v end
        Capture()
        pcall(e.run)
        local n1 = 0
        for _, v in pairs(Active().intercepted) do n1 = n1 + v end
        a:Ok(n1 >= n0, "run() nicht abgefangen")
    end
    Stub(ns.Today, "Candidates", function() error("Testfehler Candidates (absichtlich)") end)
    local empty = API.TodayCrafts(2)
    a:Ok(type(empty) == "table" and #empty == 0, "Fehler -> nicht {}")
    local errs = ProfessionSentinelDB.gsTest and ProfessionSentinelDB.gsTest.errors or {}
    local found = false
    for _, e in pairs(errs) do if type(e) == "table" and e.wo == "API.TodayCrafts" then found = true end end
    a:Ok(found, "kein Eintrag wo=API.TodayCrafts in gsTest.errors")
    local ok, res = a:Result("Prüfungen")
    return ok, res .. " · " .. #list .. " Einträge"
end)

-- vendor buying: only stubs, never a real purchase
local function VendorStubs(price, stackCount, numAvailable, money)
    local PL = ns.Plan
    local calls = {}
    Stub(PL, "current", { list = { { id = 2320, missing = 7, origin = "vendor" } } })
    Stub(PL, "MerchantOpen", function() return true end)
    Stub(PL, "MerchantNumItems", function() return 1 end)
    Stub(PL, "MerchantItemID", function() return 2320 end)
    Stub(PL, "MerchantItemInfo", function() return "Grober Faden", 0, price, stackCount, numAvailable end)
    Stub(PL, "MerchantMaxStack", function() return 20 end)
    Stub(PL, "Money", function() return money end)
    Stub(PL, "BuyItem", function(i, n) calls[#calls + 1] = i .. "," .. n; return true end)
    return calls
end

Case("T47", "B", "Kauf-Logik Einzelstücke", {}, function()
    local out = Capture()
    local calls = VendorStubs(10, 1, -1, 100000)
    local g0 = Active().guards.BuyMerchantItem or 0
    Orig("Plan", "BuyFromVendor")()
    local s = table.concat(calls, " ")
    return s == "1,7" and (Active().guards.BuyMerchantItem or 0) == g0 and Has(out, (L.PLAN_BOUGHT:gsub("%%.*$", ""))),
        "Aufrufe: " .. s, "1,7 (einmal)"
end)

Case("T48", "B", "Kauf-Logik Bündel und Begrenzung", {}, function()
    local a = NewAgg()
    local buy = Orig("Plan", "BuyFromVendor")
    local out = Capture()
    local mark = #Active().stack
    local c1 = VendorStubs(10, 5, -1, 100000); buy()
    a:Ok(table.concat(c1, " ") == "1,1 1,1", "Bündel 5: " .. table.concat(c1, " "))
    Unwind(Active(), mark)
    local c2 = VendorStubs(10, 1, 1, 100000); buy()
    a:Ok(table.concat(c2, " ") == "1,1", "verfügbar 1: " .. table.concat(c2, " "))
    Unwind(Active(), mark)
    local c3 = VendorStubs(500, 1, -1, 100); buy()
    a:Ok(#c3 == 0 and Has(out, L.PLAN_VENDOR_NOTHING), "zu teuer: " .. #c3 .. " Käufe")
    return a:Result("Fälle")
end)

-- Favor (WoW Forever only)
local function OnlyForever() if not ns.IsForever then return SKIP("nur WoW Forever") end end
local function FavorItem()
    local r = ns.ByRecipeItem[250364]
    return r and r.recipeItems[1], r
end

Case("T49", "B", "Favor-Kosten, Reihenfolge", { selftest = true }, function()
    local sk = OnlyForever(); if sk then return sk end
    local FV = ns.Favor
    local ri = FavorItem()
    local a = NewAgg()
    a:Ok(ri and ri.fv == 180 and ri.bp == nil and ri.fr == 5, "Elixier der Gerissenheit 180/kein bp/Ruf 5")
    if not ri then return a:Result("Prüfungen") end
    local db = TestDB({ favor = { costs = { [250364] = { n = 150, c = "Test" } } } })
    Stub(_G, "AHAnalyzerPro", { GetVendorCost = function() return { costs = { { kind = "currency", id = 1, name = "Merchant's Favor", amount = 170 } } } end })
    a:Ok(FV.Cost(ri).n == 150 and FV.Cost(ri).learned, "gelernt 150 zuerst")
    db.favor.costs = {}
    a:Ok(FV.Cost(ri).n == 170 and FV.Cost(ri).learned, "AHSentinel 170")
    Stub(_G, "AHAnalyzerPro", nil)
    a:Ok(FV.Cost(ri).n == 180 and not FV.Cost(ri).learned, "Guide 180")
    Stub(_G, "AHAnalyzerPro", { GetVendorCost = function() return { costs = { { kind = "currency", id = 4444, name = "Honor", amount = 99 } } } end })
    a:Ok(FV.Cost(ri).n == 180, "andere Währung übernommen")
    return a:Result("Fälle")
end)

Case("T50", "B", "Favor-Stand", {}, function()
    local sk = OnlyForever(); if sk then return sk end
    local ok, b = pcall(ns.Favor.Balance)
    if not ok then return false, "Lua: " .. tostring(b) end
    if b == nil then
        if Confirmed("T50") then return true, "Stand bestätigt " .. tostring(Confirmed("T50").date) end
        return CLIENT("Handelslager-Händler öffnen (Favor-Stand unbekannt), dann /ps testroutine b")
    end
    return type(b) == "number", "Stand " .. tostring(b)
end)

Case("T51", "B", "Kostentext", {}, function()
    local sk = OnlyForever(); if sk then return sk end
    local FV = ns.Favor
    local a = NewAgg()
    TestDB({ favor = { costs = { [999990] = { n = 77, c = "Merchant's Favor" } } } })
    Stub(_G, "AHAnalyzerPro", nil)
    Stub(FV, "Balance", function() return nil end)
    local seen = FV.CostText({ id = 999990, fv = 100 })
    local est = FV.CostText({ id = 999991, fv = 100, fe = 1 })
    local guide = FV.CostText({ id = 999992, fv = 100 })
    a:Ok(seen and seen:find(L.FAVOR_SEEN, 1, true), "gelernt ohne FAVOR_SEEN")
    a:Ok(est and est:find(L.FAVOR_ESTIMATE, 1, true), "geschätzt ohne FAVOR_ESTIMATE")
    a:Ok(guide and guide:find(L.FAVOR_GUIDE, 1, true), "Guide ohne FAVOR_GUIDE")
    a:Ok(not guide:find("|cff40c040(", 1, true) and not guide:find("|cffff6060(", 1, true), "ohne Stand trotzdem „du hast“")
    Stub(FV, "Balance", function() return 999 end)
    a:Ok(FV.CostText({ id = 999992, fv = 100 }):find("|cff40c040(", 1, true), "999 nicht grün")
    Stub(FV, "Balance", function() return 1 end)
    a:Ok(FV.CostText({ id = 999992, fv = 100 }):find("|cffff6060(", 1, true), "1 nicht rot")
    return a:Result("Texte")
end)

Case("T52", "B", "Favor-Rezepte je Beruf", {}, function()
    local sk = OnlyForever(); if sk then return sk end
    local FV = ns.Favor
    local a = NewAgg()
    local total = 0
    for _, p in ipairs(ProfList()) do
        local list = FV.Recipes(p.id)
        total = total + #list
        for i, e in ipairs(list) do
            a:Ok(e.ri.fv ~= nil, ns.ProfName(p.id) .. ": Rezept ohne fv")
            a:Ok(FV.RecipeItem(e.recipe) == e.ri, "RecipeItem")
            if i > 1 then
                local x = list[i - 1]
                a:Ok((x.ri.rs or 0) < (e.ri.rs or 0) or ((x.ri.rs or 0) == (e.ri.rs or 0) and ns.RecipeName(x.recipe) <= ns.RecipeName(e.recipe)), "Sortierung")
            end
        end
    end
    local ok, res = a:Result("Prüfungen")
    return ok and total > 0, res .. " · " .. total .. " Favor-Rezepte"
end)

Case("T53", "B", "Favor-Planer", {}, function()
    local sk = OnlyForever(); if sk then return sk end
    local FV = ns.Favor
    local a = NewAgg()
    TestDB({ favor = { costs = {}, wish = { [250364] = true }, goals = { kodo = true } } })
    Stub(_G, "AHAnalyzerPro", nil)
    Stub(ns, "RefreshAll", function() end)
    Stub(FV, "Balance", function() return 1000 end)
    local pl = FV.Plan()
    a:Ok(pl.total == 6180 and #pl.items == 2, "180 + 6000 = " .. tostring(pl.total))
    a:Ok(pl.missing == 5180, "fehlt " .. tostring(pl.missing))
    SetSim({ known = "all" })
    a:Ok(FV.Plan().total == 6000, "gelerntes Rezept nicht herausgefallen")
    SetSim(nil)
    local w0, g0 = FV.IsWished(250364), FV.IsGoal("kodo")
    FV.ToggleWish(250364); FV.ToggleWish(250364)
    FV.ToggleGoal("kodo"); FV.ToggleGoal("kodo")
    a:Ok(FV.IsWished(250364) == w0 and FV.IsGoal("kodo") == g0, "Toggle nicht zurück")
    return a:Result("Fälle")
end)

Case("T54", "B", "Kistenrechner", { selftest = true }, function()
    local sk = OnlyForever(); if sk then return sk end
    local FV = ns.Favor
    local a = NewAgg()
    a:Ok(#(ns.Crates or {}) == 30, "Kisten " .. #(ns.Crates or {}))
    local crate, ingots
    for _, c in ipairs(ns.Crates or {}) do
        if c.id == 248683 then crate = c end
        if c.id == 248703 then ingots = c end
    end
    SetSim({ prices = { [2770] = 10, [2771] = 30, [248683] = 50 } })
    local cv = crate and FV.CrateValue(crate, function() return 0 end)
    a:Ok(cv and cv.best and cv.best.id == 2770 and cv.total == 250 and cv.perFavor == 50, "Erz Lehrling 50c je Gunst")
    SetSim({ prices = { [2840] = 100, [2770] = 20, [3576] = 500, [2771] = 500, [2841] = 500, [248703] = 0 } })
    local iv = ingots and FV.CrateValue(ingots, function() return 0 end)
    a:Ok(iv and iv.best and iv.best.origin == "craft" and iv.best.cost == 400, "Barren selbst verhütten 400")
    SetSim({ prices = TestPrices() })
    local bag = ns.Crates[1].id
    local list = FV.Crates(function(id) return id == bag and 1 or 0 end)
    a:Ok(list[1] and list[1].crate.id == bag, "Kiste in den Taschen nicht zuerst")
    local seenUnknown = false
    for i = 2, #list do
        local x, e = list[i - 1], list[i]
        if e.inBags == 0 and x.inBags == 0 then
            if x.perFavor == nil then seenUnknown = true end
            a:Ok(not (seenUnknown and e.perFavor ~= nil), "unbekannte nicht zuletzt")
            if x.perFavor and e.perFavor then a:Ok(x.perFavor <= e.perFavor, "perFavor nicht aufsteigend") end
        end
    end
    return a:Result("Fälle")
end)

-- guild stubs: RaidMaster.db.prof and GuildSentinel's record (via GU.GuildRecord, no Blizzard function replaced)
local function GuildStub(prof, opts)
    opts = opts or {}
    Stub(_G, "RaidMaster", { db = { prof = prof or {} } })
    Stub(ns.Guild, "GuildRecord", function() return opts.record end)
    ns.Guild.Invalidate()
    OnUndo(function() ns.Guild.Invalidate() end)
end
S.GuildStub = GuildStub

local function GuildEntry(r, t, rank)
    return { t = t or 1, c = "WARRIOR", p = { [ns.ProfName(r.prof)] = { r = rank or 300, m = 300, n = { r.name }, i = { r.out or 0 } } } }
end

Case("T55", "B", "Gildenblick Favor", {}, function()
    local sk = OnlyForever(); if sk then return sk end
    local FV = ns.Favor
    local _, r = FavorItem()
    if not r then return false, "Favor-Rezept 250364 fehlt" end
    GuildStub({})
    local without = FV.GuildKnows(r)
    GuildStub({ ["Testa-Testrealm"] = GuildEntry(r, 1) })
    local with = FV.GuildKnows(r)
    return without == nil and type(with) == "table" and #with == 1, "ohne " .. tostring(without) .. " · mit " .. tostring(with and #with), "nil / 1"
end)

Case("T56", "B", "Händlergunst in anderen Versionen aus", {}, function()
    if ns.IsForever then return SKIP("nur Classic Era / Retail") end
    local a = NewAgg()
    a:Ok(ns.Favor.Active() == false, "Favor.Active")
    SetSim({ prof = LWProf() })
    ns.UI:Show(nil)
    local tab = TabFor(L.FAVOR_TAB)
    a:Ok(tab == nil or not tab:IsShown(), "Reiter Gunst sichtbar")
    ns.UI:Hide()
    local r = FirstRecipe(function(x) return x.recipeItems[1] ~= nil end, LWProf())
    if r then a:Ok(LinesWith(ItemTooltip(r.recipeItems[1].id), L.FAVOR_COST) == 0, "Favor-Zeile im Tooltip") end
    local out = Capture()
    ns.Favor.OnMerchantEvent("MERCHANT_SHOW")
    a:Ok(#out == 0, "OnMerchantEvent druckt etwas")
    return a:Result("Prüfungen")
end)

-- Enchanting
Case("T57", "B", "Ziel und Rolle", {}, function()
    local DE = ns.Disenchant
    local a = NewAgg()
    local _, c = TestDB({})
    Capture()
    Stub(ns, "RefreshAll", function() end)
    SetSim({ enchanter = false }); a:Ok(not DE.IsEnchanter() and not DE.WantsGold() and not DE.WantsSell(), "kein Verzauberer")
    SetSim({ enchanter = true, goal = "gold" }); a:Ok(DE.WantsGold() and not DE.WantsSell(), "gold")
    SetSim({ enchanter = true, goal = "sell" }); a:Ok(DE.WantsSell() and not DE.WantsGold(), "sell")
    SetSim({ enchanter = true, goal = "both" }); a:Ok(DE.WantsGold() and DE.WantsSell(), "both")
    SetSim({ enchanter = true })
    a:Ok(DE.Goal() == (ns.IsRetail and "sell" or "gold"), "ohne Wahl " .. tostring(DE.Goal()))
    SetSim(nil)
    DE.SetGoal("both")
    a:Ok(c.enchantGoal == "both", "SetGoal schreibt nicht")
    return a:Result("Fälle")
end)

Case("T58", "B", "Entzauberungswert", {}, function()
    local DE, P = ns.Disenchant, ns.Prices
    local a = NewAgg()
    SetSim({ prices = { [2318] = 800, [4239] = 3500 }, de = { [4239] = 5000, [2320] = false }, enchanter = true, goal = "gold" })
    Stub(_G, "AHAnalyzerPro", nil)
    local prD = P.Recipe(PriceRecipe(), true)
    if ns.IsRetail then
        SetSim({ enchanter = true })
        return DE.Goal() == "sell" and DE.Value(4239) == nil, "Retail: Ziel " .. tostring(DE.Goal()), "sell, kein Wert"
    end
    a:Ok(prD.deGross == 5000 and prD.deValue == 4750, "47s 50c: " .. tostring(prD.deValue))
    a:Ok(prD.deNet == 2330 and prD.bestVia == "de", "deNet 23s 30c: " .. tostring(prD.deNet))
    a:Ok(DE.IsDisenchantable(4239) == true and DE.IsDisenchantable(2320) == false, "IsDisenchantable (Sim)")
    SetSim({ enchanter = true, goal = "gold" })
    local green
    for id, d in pairs(ns.Items) do
        if d[2] == 2 then
            local _, _, q, ilvl, _, _, _, _, loc, _, _, class = ns.ItemInfo(id)
            if q == 2 and ilvl and ilvl >= 5 and (class == 2 or class == 4) and loc and loc ~= "" and loc ~= "INVTYPE_BAG" then green = id; break end
        end
    end
    if green then a:Ok(DE.Prior(green) ~= nil, "Prior für grünes Item " .. green)
    else a:Note("kein grünes Item im Cache (Prior übersprungen)") end
    return a:Result("Fälle")
end)

Case("T59", "B", "VZ-Preis, Marge, Sniper-Ziele", { selftest = true }, function()
    local DE, AD = ns.Disenchant, ns.Advisor
    local a = NewAgg()
    SetDB("vzMarkup", 20); SetDB("vzMinProfit", 0)
    local fd = DE.FilterDeals({ { itemID = 1, price = 3800, net = 4750 }, { itemID = 2, price = 4300, net = 4750 } }, 0.2)
    a:Ok(#fd == 1 and fd[1].itemID == 1, "FilterDeals")
    local it = DE.ItemTargets({ { itemID = 4239, net = 4750, quantity = 3 } }, 0.2)
    a:Ok(it[1] and it[1].maxPrice == 3800 and it[1].qty == 10, "ItemTargets 38s ×10")
    if not ns.IsRetail then
        SetSim({ prices = { [2318] = 800, [4239] = 3500 }, de = { [4239] = 5000, [2320] = false }, enchanter = true, goal = "gold" })
        Stub(_G, "AHAnalyzerPro", nil)
        local function RP(name, reag, out, y) return { name = name, req = 1, yellow = y or 100, green = (y or 100) + 10, grey = (y or 100) + 20, skillUps = 1, src = 1, recipeItems = {}, reagents = reag, out = out, outMin = 1, outMax = 1 } end
        local deList = AD.DERanking({ RP("X", { 2318, 1 }, 4239), RP("Y", { 2318, 6 }, 2320), RP("Z", { 2318, 2 }, 4239, 40) }, 90, function() return true end, function() return 0 end)
        local mt, used = DE.ReagentTargets(deList, 0.2, 5, 10)
        a:Ok(used == 2 and mt[1] and mt[1].id == 2318 and mt[1].maxPrice == 800 and mt[1].qty == 30, "ReagentTargets 8s ×30")
    end
    local tight = DE.ReagentTargets({ { learned = true, price = { deValue = 1000, known = true,
        parts = { { id = 2318, count = 1, unit = 800, origin = "ah" }, { id = 2320, count = 2, unit = 10, origin = "vendor" } } } } }, 0.2, 5, 10)
    a:Ok(tight[1] and tight[1].maxPrice == 780, "knappe Marge 7s 80c")
    a:Ok(DE.SellPrice(2420) == 3000, "VK-Preis 30s")
    SetDB("vzMinProfit", 1000)
    a:Ok(DE.SellPrice(2420) == 3500, "mit Mindestgewinn 35s")
    a:Ok(DE.ParseMoney("1g 20s") == 12000 and DE.ParseMoney("1,5") == 15000 and DE.ParseMoney("50s") == 5000, "ParseMoney")
    return a:Result("Fälle")
end)

Case("T60", "B", "Angebot flüstern ohne echtes Flüstern", {}, function()
    local DE = ns.Disenchant
    local a = NewAgg()
    local best
    for _, r in ipairs(ns.Recipes) do
        if r.ench and (not best or #r.reagents > #best.reagents) then best = r end
    end
    best = best or ns.Recipes[1]
    local txt = DE.OfferText(best)
    a:Ok(type(txt) == "string" and txt ~= "", "OfferText leer")
    local items = {}
    for i = 1, 40 do items[i] = i .. "x Seltsamer Staub Nummer " .. i end
    local msg = "Verzauberung: " .. table.concat(items, ", ")
    local parts = DE.SplitMessage(msg, 250)
    local maxLen = 0
    for _, p in ipairs(parts) do maxLen = math.max(maxLen, #p) end
    a:Ok(#parts > 1 and maxLen <= 255, "Teile > 255 Byte: " .. maxLen)
    a:Ok(table.concat(parts, ", ") == msg, "zusammengesetzt ungleich")
    local n0 = Intercepted("VZ-Angebot flüstern")
    local g0 = Active().guards.SendChatMessage or 0
    DE.WhisperOffer(best)
    a:Ok(Intercepted("VZ-Angebot flüstern") == n0 + 1, "WhisperOffer nicht abgefangen")
    a:Ok((Active().guards.SendChatMessage or 0) == g0, "SendChatMessage gezählt")
    return a:Result("Prüfungen")
end)

Case("T61", "B", "Kunde ermitteln", {}, function()
    local DE = ns.Disenchant
    local a = NewAgg()
    a:Ok(DE.CustomerFrom("Handel", "Ziel", "Realm", "Fluester") == "Handel", "Handelspartner zuerst")
    a:Ok(DE.CustomerFrom(nil, "Ziel", "Realm", "Fluester") == "Ziel-Realm", "Ziel mit Realm")
    a:Ok(DE.CustomerFrom(nil, "Ziel", "", "Fluester") == "Ziel", "Ziel ohne Realm")
    a:Ok(DE.CustomerFrom(nil, nil, nil, "Fluester") == "Fluester", "letzter Flüsterpartner")
    a:Ok(DE.CustomerFrom(nil, nil, nil, nil) == nil and DE.CustomerFrom("", "", "", "") == nil, "alles leer -> nil")
    return a:Result("Regeln")
end)

Case("T62", "B", "Zielfenster", {}, function()
    local DE = ns.Disenchant
    local a = NewAgg()
    local _, c = TestDB({})
    Capture()
    Stub(ns, "RefreshAll", function() end)
    SetSim(nil)
    Orig("Disenchant", "AskGoal")()
    local f = _G.ProfessionSentinelGoalFrame
    a:Ok(f and f:IsShown(), "Fenster nicht sichtbar")
    if not f then return a:Result("Prüfungen") end
    local done
    local goals = {}
    for _, b in ipairs(Descendants(f)) do
        if ObjType(b) == "Button" and b:GetScript("OnClick") then
            if Plain(Text(b)) == Plain(L.GOAL_DONE) then done = b
            else
                b:Click()
                goals[#goals + 1] = tostring(c.enchantGoal)
            end
        end
    end
    a:Ok(table.concat(goals, ",") == "gold,sell,both", "Knöpfe -> " .. table.concat(goals, ","))
    a:Ok(done ~= nil, "Knopf Fertig fehlt")
    if done then done:Click() end
    a:Ok(not f:IsShown(), "Fertig schließt nicht")
    if f:IsShown() then f:Hide() end
    if ns.IsRetail then
        local n0 = Intercepted("Fenster Ziel Verzauberkunst")
        DE.CheckAsk()
        a:Ok(Intercepted("Fenster Ziel Verzauberkunst") == n0, "Retail fragt von selbst")
    end
    return a:Result("Prüfungen")
end)

Case("T63", "B", "Eingabefenster Aufschlag, Mindestgewinn, Marge", {}, function()
    local a = NewAgg()
    Stub(ns, "RefreshAll", function() end)
    SetDB("vzMarkup", 20); SetDB("vzMinProfit", 0); SetDB("deMargin", 20)
    local function accept(fnName, key, input)
        Orig("Disenchant", fnName)()
        local d = StaticPopupDialogs and StaticPopupDialogs[key]
        a:Ok(d ~= nil and d.hasEditBox, key .. " fehlt")
        -- Blizzard formats the popup text (text_arg1/text_arg2): a lone "%" breaks it (0.9.13 in the game)
        if d then
            local okF, shown = pcall(string.format, d.text or "", "", "")
            a:Ok(okF, key .. ": Text bricht string.format (" .. tostring(shown) .. ")")
        end
        if d and d.OnAccept then
            d.OnAccept({ editBox = { GetText = function() return input end } })
        end
        if StaticPopup_Hide then pcall(StaticPopup_Hide, key) end
    end
    accept("EditMarkup", "PROFESSIONSENTINEL_VZ_MARKUP", "25%"); a:Ok(ns.db.vzMarkup == 25, "25% -> " .. tostring(ns.db.vzMarkup))
    accept("EditMarkup", "PROFESSIONSENTINEL_VZ_MARKUP", "2000"); a:Ok(ns.db.vzMarkup == 25, "2000 nicht ignoriert")
    accept("EditMinProfit", "PROFESSIONSENTINEL_VZ_MIN", "1g 20s"); a:Ok(ns.db.vzMinProfit == 12000, "1g 20s -> " .. tostring(ns.db.vzMinProfit))
    accept("EditMargin", "PROFESSIONSENTINEL_DE_MARGIN", "100"); a:Ok(ns.db.deMargin == 20, "100 nicht ignoriert")
    accept("EditMargin", "PROFESSIONSENTINEL_DE_MARGIN", "15,5"); a:Ok(ns.db.deMargin == 15.5, "15,5 -> " .. tostring(ns.db.deMargin))
    return a:Result("Eingaben")
end)

local function AHSDisenchant(fail)
    local function f(v) return function() if fail then error("AHSentinel-Testfehler (absichtlich)") end return v end end
    return {
        GetValue = f(nil), Prior = f({ { 10940, 1, 1 } }),
        Groups = f({ { key = "g20", own = 3, shared = 9 } }),
        YieldForKey = function() if fail then error("AHSentinel-Testfehler (absichtlich)") end return { { 10940, 0.75, 1.5 } }, { { 10940, 0.75 } } end,
        KeyInfo = function() if fail then error("AHSentinel-Testfehler (absichtlich)") end return 2, 16, 20, false end,
        TotalLearned = f(12), TotalShared = function() if fail then error("AHSentinel-Testfehler (absichtlich)") end return 30, 4 end,
        FindDeals = f({ { itemID = 4239, price = 100, net = 4750, profit = 4650 } }),
    }
end
S.AHSDisenchant = AHSDisenchant

Case("T64", "B", "AHSentinel-Daten für den Verzauberer-Reiter", {}, function()
    if ns.IsRetail then return SKIP("Retail: kein Entzaubern") end
    local DE = ns.Disenchant
    local a = NewAgg()
    Stub(_G, "AHAnalyzerPro", { Disenchant = AHSDisenchant(false) })
    SetDB("deMargin", 20)
    a:Ok(type(DE.Deals()) == "table" and #DE.Deals() == 1, "Deals")
    local g = DE.Groups()
    a:Ok(type(g) == "table" and #g == 1 and #g[1].rows == 1, "Groups")
    local own, shared, players = DE.Totals()
    a:Ok(own == 12 and shared == 30 and players == 4, "Totals")
    Stub(_G, "AHAnalyzerPro", nil)
    a:Ok(DE.Deals() == nil and DE.Groups() == nil and DE.Totals() == nil, "ohne AHSentinel nicht nil")
    return a:Result("Prüfungen")
end)

Case("T65", "B", "Sniper übergeben", {}, function()
    local send = Orig("Disenchant", "SendToSniper")
    local a = NewAgg()
    local out = Capture()
    local set, sel = 0, 0
    Stub(_G, "AHAnalyzerPro", { Sniper = { SetTarget = function() set = set + 1 end },
        UI = { Show = function() end, SelectTab = function() sel = sel + 1 end } })
    local made = send({ { id = 2318, maxPrice = 800, qty = 10 }, { id = 2320, maxPrice = 10, qty = 5 } }, "Test")
    a:Ok(made == 2 and set == 2 and sel == 1, "made " .. tostring(made) .. ", SetTarget " .. set .. ", SelectTab " .. sel)
    Stub(_G, "AHAnalyzerPro", nil)
    a:Ok(send({ { id = 1, maxPrice = 1, qty = 1 } }) == 0 and Has(out, L.SNIPE_NEED_AHS), "ohne Sniper")
    return a:Result("Prüfungen")
end)

-- Recipe alarm
local function AlarmDB()
    local r = FirstRecipe(function(x) return x.recipeItems[1] ~= nil end, LWProf())
    local _, me = TestDB({ chars = {
        ["Testa-Testrealm"] = { flavor = ns.Flavor, known = {}, profs = { [r.prof] = { rank = 1, max = 75 } } },
        ["Testc-Testrealm"] = { flavor = "andere", known = {}, profs = { [r.prof] = { rank = 1, max = 75 } } },
    } })
    me.profs = { [r.prof] = { rank = 1, max = 75 } }
    SetSim({ known = "none" })
    return r
end

Case("T66", "B", "Wer braucht welches Rezept", {}, function()
    local r = AlarmDB()
    local need = ns.Alerts.Needed()
    local e = need[r.recipeItems[1].id]
    return e ~= nil and #e.names == 2, "Namen " .. tostring(e and #e.names), "2 (ich + gleiche Version)"
end)

Case("T67", "B", "Alarm nach Scan", {}, function()
    local AL = ns.Alerts
    local a = NewAgg()
    local r = AlarmDB()
    local id = r.recipeItems[1].id
    Stub(AL, "PlaySound", function() end)
    Stub(ns, "RefreshAll", function() end)
    Stub(AL, "found", AL.found)
    AL.ResetAnnounced()
    OnUndo(function() AL.ResetAnnounced() end)
    local out = Capture()
    SetDB("recipeAlert", true)
    AL.OnScan({ [id] = { price = 1000, qty = 1 } })
    a:Ok(Times(out, (L.ALERT_HEAD:gsub("%%d.*$", ""))) == 1 and #AL.found == 1, "erster Treffer")
    AL.OnScan({ [id] = { price = 1000, qty = 1 } })
    a:Ok(Times(out, (L.ALERT_HEAD:gsub("%%d.*$", ""))) == 1, "gleicher Preis erneut gemeldet")
    AL.OnScan({ [id] = { price = 500, qty = 1 } })
    a:Ok(Times(out, (L.ALERT_HEAD:gsub("%%d.*$", ""))) == 2, "tieferer Preis nicht gemeldet")
    SetDB("recipeAlert", false)
    AL.OnScan({ [id] = { price = 100, qty = 1 } })
    a:Ok(Times(out, (L.ALERT_HEAD:gsub("%%d.*$", ""))) == 2, "recipeAlert aus meldet")
    SetDB("recipeAlert", true)
    a:Ok(pcall(AL.OnScan, "kaputt"), "best keine Tabelle")
    return a:Result("Fälle")
end)

Case("T68", "B", "Alarm aus aktuellen Preisen", {}, function()
    local AL = ns.Alerts
    local r = AlarmDB()
    local id = r.recipeItems[1].id
    local calls = 0
    local now = time()
    Stub(AL, "found", {})
    Stub(_G, "AHAnalyzerPro", { GetCurrent = function(_, itemID)
        calls = calls + 1
        if itemID == id then return 900, 1, now end
        return 500, 1, now - 3 * 3600
    end })
    AL.ResetCurrent()
    OnUndo(function() AL.ResetCurrent() end)
    local f1 = AL.FromCurrent()
    local c1 = calls
    local f2 = AL.FromCurrent()
    local fresh = #f1 >= 1 and f1[1].itemID == id
    for _, f in ipairs(f1) do if f.price == 500 then fresh = false end end
    return fresh and f2 == f1 and calls == c1, #f1 .. " frisch, Cache " .. tostring(f2 == f1), "nur frische, zweiter Aufruf aus dem Cache"
end)

Case("T69", "B", "Rezepte in den Taschen", {}, function()
    local AL = ns.Alerts
    local list = AL.BagRecipes()
    if type(list) ~= "table" then return false, "keine Tabelle" end
    for i, e in ipairs(list) do
        if not (e.itemID and e.recipe and e.count and type(e.who) == "table") then return false, "Eintrag unvollständig" end
        if i > 1 and #list[i - 1].who == 0 and #e.who > 0 then return false, "„gebraucht“ nicht zuerst" end
    end
    if #list == 0 then
        if Confirmed("T69") then return true, "bestätigt " .. tostring(Confirmed("T69").date) end
        return CLIENT("ein Rezept-Item in die Taschen legen, dann /ps testroutine b")
    end
    return true, #list .. " Rezepte in den Taschen"
end)

Case("T70", "B", "Anbindung an den AHSentinel-Scan", {}, function()
    local A = _G.AHAnalyzerPro
    if not (A and A.On) then return SKIP("AHSentinel nicht geladen") end
    if Confirmed("T70") then return true, "bestätigt " .. tostring(Confirmed("T70").date) end
    return CLIENT("mit AHSentinel einen AH-Scan machen: Rezept-Alarm bzw. Gruppe „alerts“ im Panel erscheint (angemeldet: "
        .. tostring(ns.Alerts.registered == true) .. ")")
end)

-- Guild
Case("T71", "B", "Gildendaten zusammenführen", {}, function()
    local GU = ns.Guild
    local r = FirstRecipe(function(x) return x.out ~= nil end, LWProf())
    GuildStub({ ["Testa-Testrealm"] = GuildEntry(r, 10), ["Testb-Testrealm"] = GuildEntry(r, 5) },
        { record = { prof = { ["Testa-Testrealm"] = GuildEntry(r, 20), ["Testb-Testrealm"] = GuildEntry(r, 1) } } })
    local p = GU.Profs()
    local ok = p["Testa-Testrealm"] and p["Testa-Testrealm"].t == 20 and p["Testb-Testrealm"] and p["Testb-Testrealm"].t == 5
    return ok and GU.Available(), "neuer gewinnt: " .. tostring(ok) .. ", Available " .. tostring(GU.Available()), "beide richtig"
end)

Case("T72", "B", "Wer kann was", {}, function()
    local GU = ns.Guild
    local a = NewAgg()
    local r = FirstRecipe(function(x) return x.out ~= nil end, LWProf())
    local prof = {}
    for i = 1, 8 do prof["Test" .. string.char(96 + i) .. "-Testrealm"] = GuildEntry(r, i) end
    GuildStub(prof)
    local list = GU.Crafters(r)
    a:Ok(list and #list == 8, "Crafters " .. tostring(list and #list))
    a:Ok(Plain(GU.CraftersText(list, 6)):find(Plain((L.MORE:gsub("%%d", "2"))), 1, true) ~= nil, "CraftersText ohne MORE")
    a:Ok(GU.MemberCount() == 8, "MemberCount")
    local nobody = GU.NobodyKnows(r.prof)
    a:Ok(type(nobody) == "table", "NobodyKnows ab 2 Mitgliedern")
    _G.RaidMaster.db.prof = {}
    a:Ok(#(GU.Crafters(r) or {}) == 8, "Index-Cache nicht genutzt")
    GU.Invalidate()
    a:Ok(GU.Crafters(r) == nil, "nach Invalidate nicht neu")
    GuildStub({ ["Testa-Testrealm"] = GuildEntry(r, 1) })
    a:Ok(GU.NobodyKnows(r.prof) == nil, "NobodyKnows mit 1 Mitglied")
    return a:Result("Prüfungen")
end)

Case("T73", "B", "Abklingzeiten", {}, function()
    local GU = ns.Guild
    local a = NewAgg()
    local now = GetServerTime and GetServerTime() or time()
    GuildStub({}, { record = { cds = {
        ["Testa-Testrealm"] = { t = 1, k = { transmute = 0, mooncloth = now + 7200 } },
        ["Testb-Testrealm"] = { t = 1, k = { saltshaker = now + 90 } },
    } } })
    local all = GU.Cooldowns()
    a:Ok(type(all) == "table" and #all == 3, "drei Abklingzeiten: " .. tostring(all and #all))
    local lw = GU.Cooldowns(165)
    a:Ok(lw and #lw == 1 and lw[1].key == "saltshaker", "Lederverarbeitung: Salzstreuer")
    a:Ok(GU.LeftText(0):find(L.CD_READY, 1, true) ~= nil, "bereit")
    a:Ok(GU.LeftText(90) == string.format(L.CD_MINUTES, 1), "90 s")
    a:Ok(GU.LeftText(5 * 3600) == string.format(L.CD_HOURS, 5, 0), "5 h")
    a:Ok(GU.LeftText(30 * 3600) == string.format(L.CD_DAYS, 1, 6), "30 h")
    GuildStub({}, { record = nil })
    a:Ok(GU.Cooldowns() == nil, "ohne Gilde nicht nil")
    return a:Result("Prüfungen")
end)

Case("T74", "B", "Online-Liste", {}, function()
    local GU = ns.Guild
    local a = NewAgg()
    GU.InvalidateOnline()
    OnUndo(function() GU.InvalidateOnline() end)
    local o1 = GU.Online()
    a:Ok(type(o1) == "table", "keine Tabelle")
    if not (IsInGuild and IsInGuild()) then a:Ok(next(o1) == nil, "ohne Gilde nicht leer") end
    a:Ok(GU.Online() == o1, "Cache 20 s nicht genutzt")
    local cache = {}
    GU.AddOnline(cache, "Vorname Nachname-Realm", true)
    GU.AddOnline(cache, "Offline-Realm", false)
    a:Ok(cache["Vorname Nachname"] == true and cache.Offline == nil, "AddOnline")
    return a:Result("Prüfungen")
end)

---------------------------------------------------------------------------
-- B. Every function – tooltips, panel, options, test mode, events, data
---------------------------------------------------------------------------
local PS_TAG = "ProfessionSentinel:"

-- a recipe item of a profession the (test) character has, with a rank
local function TooltipRecipe()
    local r = FirstRecipe(function(x) return x.recipeItems[1] ~= nil and (x.yellow or 0) > 0 end, LWProf())
    local _, c = TestDB({})
    c.profs = { [r.prof] = { rank = 80, max = 150 } }
    return r, r.recipeItems[1].id
end

Case("T75", "B", "Item-Tooltip Rezept", {}, function()
    local a = NewAgg()
    local r, id = TooltipRecipe()
    SetDB("tooltip", false)
    local base = #ItemTooltip(id)
    if base == 0 then return SKIP("Item " .. id .. " nicht im Cache") end
    SetDB("tooltip", true)
    SetSim({ known = "all" })
    local learned = ItemTooltip(id)
    a:Ok(#learned > base, "keine Zeilen vom Addon (" .. base .. " -> " .. #learned .. ")")
    a:Ok(LinesWith(learned, L.ALREADY_LEARNED) == 1, "„bereits gelernt“ fehlt")
    SetSim({ known = "none" })
    local missing = ItemTooltip(id)
    a:Ok(LinesWith(missing, L.NOT_LEARNED_YET) == 1, "„noch nicht gelernt“ fehlt")
    a:Ok(LinesWith(missing, L.LL_TITLE) >= 1, "Lebenslinien-Zeile fehlt")
    return a:Result("Prüfungen")
end)

Case("T76", "B", "Item-Tooltip Material", {}, function()
    local a = NewAgg()
    SetDB("tooltip", true)
    SetDB("reagentTooltip", true)
    local lines = ItemTooltip(2318)
    if #lines == 0 then return SKIP("Item 2318 nicht im Cache") end
    local head = Plain((L.REAGENT_USED:gsub("%%.*$", "")))
    a:Ok(LinesWith(lines, head) == 1, "Zeile REAGENT_USED fehlt")
    SetDB("reagentTooltip", false)
    a:Ok(LinesWith(ItemTooltip(2318), head) == 0, "reagentTooltip aus: Zeile da")
    SetDB("reagentTooltip", true)
    GameTooltip:SetOwner(UIParent, "ANCHOR_NONE")
    GameTooltip:SetItemByID(2318)
    local n1 = GameTooltip:NumLines()
    ns.TooltipAddLines(GameTooltip, 2318)
    local n2 = GameTooltip:NumLines()
    GameTooltip:Hide()
    a:Ok(n1 == n2, "doppelte Zeilen " .. n1 .. " -> " .. n2)
    return a:Result("Prüfungen")
end)

Case("T77", "B", "Panel-Tooltips", {}, function()
    local a = NewAgg()
    local UI = ns.UI
    local function tip(label, r, rank, de)
        if not r then a:Note(label .. ": kein Beispiel"); return end
        local ok, err = pcall(UI.ShowRecipeTooltip, UI, UIParent, r, rank, de)
        local n = GameTooltip:NumLines() or 0
        GameTooltip:Hide()
        a:Ok(ok and n > 3, label .. ": " .. (ok and (n .. " Zeilen") or tostring(err)))
    end
    local prof = LWProf()
    tip("Rezept mit Produkt", FirstRecipe(function(x) return x.out ~= nil end, prof), 80)
    tip("Verzauberung", FirstRecipe(function(x) return x.ench end), 80)
    tip("Reagenz ohne Preis", FirstRecipe(function(x) return #x.reagents > 0 end, prof), nil)
    SetSim({ prices = TestPrices(), enchanter = true, goal = "gold" })
    tip("mit Test-Preisen", FirstRecipe(function(x) return x.out ~= nil end, prof), 80)
    tip("deMode", FirstRecipe(function(x) return x.out ~= nil end, prof), 80, true)
    SetSim(nil)
    if ns.IsForever then
        local _, fr = FavorItem()
        tip("Favor-Rezept", fr, 80)
    end
    return a:Result("Tooltips")
end)

Case("T78", "B", "Nur ein Tooltip-Weg aktiv", {}, function()
    local r, id = TooltipRecipe()
    SetDB("tooltip", true)
    local lines = ItemTooltip(id)
    if #lines == 0 then return SKIP("Item " .. id .. " nicht im Cache") end
    local n = LinesWith(lines, PS_TAG)
    local way = (TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall) and "TooltipDataProcessor" or "OnTooltipSetItem"
    return n == 1, way .. ": " .. n .. "× ProfessionSentinel-Zeile", "genau 1"
end)

-- panel per profession (one step per profession: the UI can draw in between)
local function PerProf(label, fn)
    return function()
        local profs = ProfList()
        local a = NewAgg()
        local i = 0
        local function nextProf()
            i = i + 1
            local p = profs[i]
            if not p then
                ns.UI:Hide()
                return a:Result(label)
            end
            local mark = #Active().stack
            local ok, err = pcall(fn, a, p)
            a:Ok(ok, ns.ProfName(p.id) .. ": Lua " .. tostring(err))
            Unwind(Active(), mark)
            return WAIT(STEP_DELAY, nextProf)
        end
        return nextProf()
    end
end

local function OpenPanel(prof, mode, sim)
    local s = sim or {}
    s.prof = prof
    SetSim(s)
    SetDB("panelMode", mode or "recipes")
    ns.UI:Show(nil)
    local sb = SearchBox()
    if sb and Text(sb) ~= "" then sb:SetText("") end
    return Refresh()
end
S.OpenPanel = OpenPanel

local function Modes()
    local m = { "recipes", "ranking", "plan" }
    if ns.HasSourceData ~= false then m[#m + 1] = "trainers" end
    m[#m + 1] = "disenchant"
    if ns.Favor.Active() then m[#m + 1] = "favor" end
    return m
end
S.Modes = Modes

Case("T79", "B", "Panel je Beruf", {}, PerProf("Berufe", function(a, p)
    local name = ns.ProfName(p.id)
    OpenPanel(p.id, "recipes")
    a:Ok(ns.UI:IsShown(), name .. ": Panel nicht sichtbar")
    a:Ok(PanelTitle():find(Plain(name), 1, true) ~= nil, name .. ": Titel „" .. PanelTitle() .. "“")
    a:Ok((RowCount() or 0) > 0, name .. ": keine Zeilen")
    local pn = Panel()
    if pn and pn.CloseButton then pn.CloseButton:Click() else ns.UI:Hide() end
    a:Ok(not ns.UI:IsShown(), name .. ": X schließt nicht")
end))

Case("T80", "B", "Reiter", {}, function()
    local a = NewAgg()
    OpenPanel(LWProf(), "recipes", { enchanter = true })
    local seen = {}
    for _, b in ipairs(Tabs()) do
        if b:IsShown() then
            b:Click()
            seen[ns.db.panelMode or "?"] = true
        end
    end
    for _, m in ipairs(Modes()) do a:Ok(seen[m], "Reiter " .. m .. " nicht erreichbar") end
    a:Ok(not (ns.HasSourceData == false and seen.trainers), "Lehrer-Reiter in Retail")
    a:Ok(not (not ns.Favor.Active() and seen.favor), "Gunst-Reiter außerhalb Forever")
    SetSim({ prof = LWProf(), enchanter = false })
    Refresh()
    local de = TabFor(L.DE_TAB)
    a:Ok(not (de and de:IsShown()), "Verzauberer-Reiter ohne Verzauberkunst sichtbar")
    ns.UI:Hide()
    return a:Result("Reiter")
end)

Case("T81", "B", "Jede Ansicht aufbauen und bedienen", {}, PerProf("Berufe × Ansichten", function(a, p)
    local name = ns.ProfName(p.id)
    local collapsedBefore = DeepCopy(ns.db.collapsed)
    Stub(ns.db, "favor", DeepCopy(ns.db.favor))
    for _, mode in ipairs(Modes()) do
        OpenPanel(p.id, mode, { enchanter = mode == "disenchant" or nil })
        a:Ok(RowCount() ~= nil, name .. "/" .. mode .. ": nicht aufgebaut")
        HoverRows(a, name .. "/" .. mode)
        ClickRows(a, name .. "/" .. mode)
        OpenPanel(p.id, mode, { enchanter = mode == "disenchant" or nil })
        ToggleFirstHeader(a, name .. "/" .. mode)
        local sb = ScrollBox()
        a:Ok(pcall(function() if sb.ScrollToEnd then sb:ScrollToEnd() end if sb.ScrollToBegin then sb:ScrollToBegin() end end), name .. "/" .. mode .. ": scrollen")
    end
    a:Ok(Diff(collapsedBefore, ns.db.collapsed) == nil, name .. ": collapsed verändert")
end))

Case("T82", "B", "Suche und Filter „nur fehlend“", {}, PerProf("Berufe", function(a, p)
    local name = ns.ProfName(p.id)
    OpenPanel(p.id, "recipes", { known = "all" })
    local all = RowCount() or 0
    local mc = MissingCheck()
    a:Ok(mc ~= nil, name .. ": Häkchen fehlt")
    if mc then
        SetDB("filters", { missing = false })
        mc:SetChecked(false)
        mc:Click()
        a:Ok(ns.db.filters.missing == true, name .. ": Filter nicht gesetzt")
        Refresh()
        a:Ok((RowCount() or 0) < all, name .. ": alles gelernt + fehlend -> nicht weniger")
        mc:Click()
        a:Ok(ns.db.filters.missing == false, name .. ": Filter nicht aus")
    end
    local sb = SearchBox()
    if not sb then a:Ok(false, name .. ": Suchfeld fehlt"); return end
    SetSim({ prof = p.id })
    sb:SetText(""); Refresh()
    all = RowCount() or 0
    local r = ns.ByProf[p.id][math.floor(#ns.ByProf[p.id] / 2) + 1]
    sb:SetText(ns.RecipeName(r):lower()); Refresh()
    local hit = RowCount() or 0
    sb:SetText("zzqx-gibtsnicht"); Refresh()
    local none = RowCount() or 0
    sb:SetText(""); Refresh()
    a:Ok(hit > 0 and hit <= all, name .. ": Suche findet nichts")
    a:Ok(none < all, name .. ": Unsinn-Suche")
    a:Ok((RowCount() or 0) == all, name .. ": Suche leeren")
end))

Case("T83", "B", "Fertigkeits- und Gelernt-Simulation", {}, PerProf("Berufe", function(a, p)
    local name = ns.ProfName(p.id)
    for _, rank in ipairs(RANKS) do
        OpenPanel(p.id, "recipes", { rank = rank })
        a:Ok((RowCount() or 0) > 0, name .. " bei " .. rank .. ": keine Zeilen")
        HoverRows(a, name .. " " .. rank)
    end
    for _, k in ipairs({ "all", "none" }) do
        OpenPanel(p.id, "recipes", { known = k })
        a:Ok((RowCount() or 0) > 0, name .. " known=" .. k)
    end
end))

Case("T84", "B", "Panel ohne Beruf", {}, function()
    if ActiveHost() then return SKIP("Berufsfenster offen") end
    SetSim(nil)
    ns.UI:Show(nil)
    local title = PanelTitle()
    local hint = false
    for _, t in ipairs(PanelTexts()) do if t:find(Plain(L.OPEN_PROF_FIRST), 1, true) then hint = true end end
    local rows = RowCount() or 0
    ns.UI:Hide()
    return title == Plain(L.TITLE) and hint and rows == 0, "Titel „" .. title .. "“, Hinweis " .. tostring(hint) .. ", Zeilen " .. rows, "TITLE, OPEN_PROF_FIRST, 0"
end)

Case("T85", "B", "Andocken und Hinweis „bester Rezept“", {}, function()
    local host = ActiveHost()
    if not host then
        if Confirmed("T85") then return true, "bestätigt " .. tostring(Confirmed("T85").date) end
        return CLIENT("Berufsfenster öffnen (Addons dürfen das nicht selbst), dann /ps testroutine b")
    end
    local a = NewAgg()
    SetSim(nil)
    ns.UI:Show(host)
    local _, rel = Panel():GetPoint(1)
    a:Ok(rel == host, "Panel nicht am Berufsfenster")
    local hasButton = false
    for _, b in ipairs(Children(host)) do
        if ObjType(b) == "Button" and Plain(Text(b)) == Plain(L.ALL_RECIPES) then hasButton = true end
    end
    a:Ok(hasButton, "Knopf „Alle Rezepte“ fehlt")
    a:Ok((RowCount() or 0) > 0, "keine Zeilen")
    return a:Result("Prüfungen")
end)

Case("T86", "B", "Jede Option an/aus", {}, function()
    local a = NewAgg()
    local prof = LWProf()
    Stub(ns.db, "favor", DeepCopy(ns.db.favor))
    -- tooltip / reagentTooltip
    local r, id = TooltipRecipe()
    SetDB("tooltip", false)
    a:Ok(LinesWith(ItemTooltip(id), PS_TAG) == 0, "tooltip aus: Zeile da")
    SetDB("tooltip", true)
    SetDB("reagentTooltip", false)
    a:Ok(LinesWith(ItemTooltip(2318), Plain((L.REAGENT_USED:gsub("%%.*$", "")))) == 0, "reagentTooltip aus: Zeile da")
    SetDB("reagentTooltip", true)
    -- lifeline: no line in the recipe rows (ranking rows always show theirs)
    SetDB("best", false)
    SetDB("lifeline", false)
    OpenPanel(r.prof, "recipes", { rank = 80 })
    local lineShown = false
    for _, row in ipairs(VisibleRows()) do if row.line and row.line:IsShown() then lineShown = true end end
    a:Ok(not lineShown, "lifeline aus: Linie sichtbar")
    SetDB("lifeline", true)
    -- best: no "ranking-top" group
    SetDB("best", false)
    OpenPanel(prof, "recipes", { rank = 80 })
    a:Ok(not GroupKeys()["ranking-top"], "best aus: Gruppe ranking-top da")
    SetDB("best", true)
    OpenPanel(prof, "recipes", { rank = 80 })
    a:Ok(GroupKeys()["ranking-top"] == true, "best an: Gruppe ranking-top fehlt")
    -- recipeAlert: no "alerts" group
    SetDB("recipeAlert", false)
    OpenPanel(prof, "recipes")
    a:Ok(not GroupKeys().alerts, "recipeAlert aus: Gruppe alerts da")
    SetDB("recipeAlert", true)
    -- todayCrates (Forever)
    if ns.IsForever then
        SetSim({ prices = TestPrices() })
        SetDB("todayCrates", false); a:Ok(ns.Favor.BestCrate() == nil, "todayCrates aus: Kiste")
        SetDB("todayCrates", true); a:Ok(ns.Favor.BestCrate() ~= nil, "todayCrates an: keine Kiste")
        SetDB("todayCrates", false)
    end
    -- vzMarkup / vzMinProfit / deMargin
    SetDB("vzMarkup", 20); SetDB("vzMinProfit", 0)
    local p1 = ns.Disenchant.SellPrice(2420)
    SetDB("vzMarkup", 50)
    a:Ok(ns.Disenchant.SellPrice(2420) ~= p1, "vzMarkup ohne Wirkung")
    SetDB("vzMinProfit", 100000)
    a:Ok(ns.Disenchant.SellPrice(2420) >= 102420, "vzMinProfit ohne Wirkung")
    SetDB("deMargin", 20)
    local t1 = ns.Disenchant.ItemTargets({ { itemID = 1, net = 10000 } })[1].maxPrice
    SetDB("deMargin", 50)
    a:Ok(ns.Disenchant.ItemTargets({ { itemID = 1, net = 10000 } })[1].maxPrice < t1, "deMargin ohne Wirkung")
    -- guildShare: documented without effect (the addon sends nothing)
    local g0 = (Active().guards.SendAddonMessage or 0) + (Active().guards.SendChatMessage or 0)
    SetDB("guildShare", not ns.db.guildShare)
    Refresh()
    a:Ok((Active().guards.SendAddonMessage or 0) + (Active().guards.SendChatMessage or 0) == g0, "guildShare sendet")
    a:Note("guildShare ohne Wirkung (nur Lesen), panelOpen nur mit Berufsfenster prüfbar, planTarget siehe T40")
    ns.UI:Hide()
    return a:Result("Optionen")
end)

Case("T87", "B", "Testmodus-Fenster", {}, function()
    local TM = ns.TestMode
    local a = NewAgg()
    local w = _G.ProfessionSentinelTestMode
    local wasShown = w and w:IsShown() or false
    if not wasShown then TM:Toggle() end
    w = _G.ProfessionSentinelTestMode
    a:Ok(w and w:IsShown(), "Fenster nicht offen")
    if not w then return a:Result("Prüfungen") end
    Stub(ns.db, "favor", DeepCopy(ns.db.favor))
    Capture()
    local n = 0
    for _, f in ipairs(Descendants(w)) do
        local t = ObjType(f)
        if (t == "Button" or t == "CheckButton") and f ~= w.CloseButton and f ~= w.testAllButton and Shown(f) and f:GetScript("OnClick") then
            local ok, err = pcall(f.Click, f)
            a:Ok(ok, "Knopf: " .. tostring(err))
            n = n + 1
        end
    end
    a:Ok(n >= 10, "nur " .. n .. " Knöpfe")
    local diag = TM:Diagnostics()
    a:Ok(#Plain(diag) > 50, "Diagnose zu kurz")
    a:Ok(diag:find(G().Status(), 1, true) ~= nil, "Diagnose ohne G.Status()")
    if ns.Favor.Active() then a:Ok(diag:find(L.FAVOR_DIAG_READABLE, 1, true) ~= nil, "Diagnose ohne FAVOR_DIAG_READABLE") end
    TM:Reset()
    a:Ok(ns.Sim == nil, "Reset lässt ns.Sim stehen")
    if w:IsShown() ~= wasShown then TM:Toggle() end
    if ns.UI:IsShown() then ns.UI:Hide() end
    local ok, res = a:Result("Prüfungen")
    return ok, res .. " · " .. n .. " Knöpfe"
end)

Case("T88", "B", "Alter Selbsttest unverändert sauber", { selftest = true }, function()
    local sim, ahs, favor = ns.Sim, _G.AHAnalyzerPro, ns.db.favor
    local mk, mp = ns.db.vzMarkup, ns.db.vzMinProfit
    local ok, results = ns.TestMode:RunSelfTest(false)
    local fails = {}
    for i = 2, #(results or {}) do
        local line = Plain(results[i])
        if line:find(Plain(L.TEST_FAIL), 1, true) then fails[#fails + 1] = (line:gsub("^%S+%s+", "")) end
    end
    local clean = rawequal(ns.Sim, sim) and rawequal(_G.AHAnalyzerPro, ahs) and rawequal(ns.db.favor, favor)
        and ns.db.vzMarkup == mk and ns.db.vzMinProfit == mp
    if not ok then return false, #fails .. " Fehler: " .. tostring(fails[1]), "0" end
    return clean, (#(results or {}) - 1) .. " Prüfungen, Zustand " .. (clean and "sauber" or "verändert"), "sauber"
end)

Case("T89", "B", "Autotest-Befehle", {}, function()
    local AT = ns.AutoTest
    local a = NewAgg()
    TestDB({})
    local out = Capture()
    AT:History()
    a:Ok(#out >= 1, "Verlauf ohne Hinweis")
    local rep = _G.ProfessionSentinelAutoTestReport
    local shown = rep and rep:IsShown()
    a:Ok(pcall(AT.ShowLast, AT), "ShowLast")
    rep = _G.ProfessionSentinelAutoTestReport
    if rep and rep:IsShown() and not shown then rep:Hide() end
    a:Ok(pcall(AT.Command, AT, "verlauf"), "Command verlauf")
    local h = ProfessionSentinelDB.autotest and ProfessionSentinelDB.autotest.history
    a:Ok(h == nil or #h <= 10, "Verlauf > 10")
    return a:Result("Befehle")
end)

-- events: typical arguments straight into every handler
local EVENTS = {
    { "ADDON_LOADED", "SomeOtherAddon" }, { "PLAYER_LOGIN" }, { "MERCHANT_SHOW" }, { "MERCHANT_UPDATE" },
    { "MERCHANT_CLOSED" }, { "GET_ITEM_INFO_RECEIVED", 1, true }, { "TRADE_SKILL_LIST_UPDATE" }, { "TRADE_SKILL_UPDATE" },
    { "SKILL_LINES_CHANGED" }, { "NEW_RECIPE_LEARNED", 1 }, { "CRAFT_UPDATE" }, { "LEARNED_SPELL_IN_TAB", 1 },
}
local function FireAll(a)
    for _, e in ipairs(ns.EventFrames) do
        local f = e.frame
        local fn = f:GetScript("OnEvent")
        for _, ev in ipairs(EVENTS) do
            if fn and (f:IsEventRegistered(ev[1]) or ev[1] == "ADDON_LOADED") then
                local ok, err = pcall(fn, f, ev[1], ev[2], ev[3])
                a:Ok(ok, e.label .. "/" .. ev[1] .. ": " .. tostring(err))
            end
        end
    end
end
S.FireAll = FireAll

local function InterceptedTotal()
    local n = 0
    for _, v in pairs(Active().intercepted) do n = n + v end
    return n
end
S.InterceptedTotal = InterceptedTotal

Case("T90", "B", "Ereignis-Handler", {}, function()
    local a = NewAgg()
    Capture()
    local c = ns.Char()
    local known1 = c and c.known[1]
    local i0 = InterceptedTotal()
    FireAll(a)
    a:Ok(not (c and c.known[1] and not known1), "unbekannter Zauber als gelernt markiert")
    a:Ok(InterceptedTotal() == i0, "Ereignis hat eine Aktion ausgelöst")
    local ok, res = a:Result("Aufrufe")
    return ok, res .. " · " .. #ns.EventFrames .. " Frames"
end)

Case("T91", "B", "Entprellung des Scans", {}, function()
    local f = ns.Scan.frame
    if not f then return false, "Scan-Frame fehlt" end
    local ev
    for _, e in ipairs({ "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_UPDATE", "SKILL_LINES_CHANGED" }) do
        if f:IsEventRegistered(e) then ev = e; break end
    end
    if not ev then return false, "kein Berufs-Ereignis angemeldet" end
    -- wait for a debounce that may still be pending from earlier cases
    return WAIT(0.7, function()
        local n = 0
        local orig = ns.Scan.UpdateProfessions
        Stub(ns.Scan, "UpdateProfessions", function(self, ...) n = n + 1; return orig(self, ...) end)
        Stub(ns.Disenchant, "CheckAsk", function() end)
        Stub(ns.Scan, "InQuiet", function() return false end)      -- the quiet time after an earlier scan (T205) is not tested here
        local fn = f:GetScript("OnEvent")
        for _ = 1, 20 do fn(f, ev) end
        return WAIT(0.7, function()
            return n == 1, "20× " .. ev .. " -> " .. n .. "× UpdateProfessions", "1×"
        end)
    end)
end)

Case("T92", "B", "Datenpakete inhaltlich", { selftest = true }, function()
    local bad, first = 0, nil
    local function fail(s) bad = bad + 1; first = first or s end
    for _, r in ipairs(ns.Recipes) do
        if r.yellow > 0 and not (r.yellow <= r.green and r.green <= r.grey) then fail("Stufen " .. r.spell) end
        if not ns.ByProf[r.prof] then fail("Beruf " .. r.spell) end
        if #r.reagents % 2 ~= 0 then fail("Reagenzien " .. r.spell) end
        for _, ri in ipairs(r.recipeItems) do if type(ri.id) ~= "number" then fail("recipeItem " .. r.spell) end end
    end
    for prof, list in pairs(ns.Trainers or {}) do
        for _, e in ipairs(list) do if not ns.NPCs[e[1]] then fail("Lehrer " .. tostring(e[1])) end end
    end
    if ns.IsForever then
        if not (ns.Factions and ns.Factions[2586] and ns.Factions[2587]) then fail("Fraktionen 2586/2587") end
        if #(ns.Crates or {}) ~= 30 then fail("Kisten " .. #(ns.Crates or {})) end
        for _, c in ipairs(ns.Crates or {}) do
            if #(c.b or {}) % 2 ~= 0 or not (c.favor and c.favor > 0) then fail("Kiste " .. c.id) end
        end
    end
    if ns.IsRetail then
        for _, p in ipairs(ns.Professions) do if not p.parent then fail("Linie ohne parent " .. p.id) end end
    end
    return bad == 0, bad .. " Abweichungen" .. (first and (": " .. first) or ""), "0"
end)

Case("T93", "B", "Keine Addon-Kommunikation", {}, function()
    local n = Active().guards.SendAddonMessage or 0
    local reg = C_ChatInfo and C_ChatInfo.IsAddonMessagePrefixRegistered and C_ChatInfo.IsAddonMessagePrefixRegistered("ProfessionSentinel") or false
    return n == 0 and not reg, "SendAddonMessage ×" .. n .. ", Präfix " .. tostring(reg), "0, nicht registriert"
end)

-- Minimap button (0.9.13, anweisung-professionsentinel-minimap-button.txt). Every case changes only ns.db through
-- SetDB (rollback) and puts the button back to the saved state at the end (OnUndo first = undone last).
local function MinimapButton()
    local MM = ns.Minimap
    local b = MM and _G[MM.NAME]
    if b then OnUndo(function() MM.Update() end, "Minimap-Button zurück") end
    return MM, b
end

local function NoButton()
    if not _G.Minimap then return SKIP("keine Minimap in diesem Client") end
    return false, "kein Button", "Button da"
end

local function Near(a, b) return type(a) == "number" and type(b) == "number" and math.abs(a - b) < 0.5 end

Case("T182", "B", "Minimap-Button da und sichtbar", {}, function()
    local MM, b = MinimapButton()
    if not MM then return false, "ns.Minimap fehlt", "Modul geladen" end
    if not _G.Minimap then return SKIP("keine Minimap in diesem Client") end
    if not b then return false, "kein Frame " .. tostring(MM.NAME), "Button nach dem Laden da" end
    local a = NewAgg()
    local real = ns.db.minimapButton
    a:Ok(ns.DEFAULTS.minimapButton == true and ns.DEFAULTS.minimapAngle == 200, "Standard nicht an / 200°")
    a:Ok(ObjType(b) == "Button", "Typ " .. tostring(ObjType(b)))
    a:Ok(b:GetParent() == _G.Minimap, "nicht an der Minimap")
    a:Ok(Near(b:GetWidth(), 31) and Near(b:GetHeight(), 31), "Grösse " .. tostring(b:GetWidth()) .. "x" .. tostring(b:GetHeight()))
    a:Ok(not (b.IsProtected and b:IsProtected()), "geschützt")
    a:Ok(b:GetScript("OnClick") ~= nil and b:GetScript("OnDragStart") ~= nil and b:GetScript("OnEnter") ~= nil, "Skripte fehlen")
    SetDB("minimapButton", true)
    MM.Update()
    a:Ok(b:IsShown(), "Standard an: nicht sichtbar")
    a:Note("eigene Einstellung: " .. (real == false and "aus" or "an"))
    return a:Result("Prüfungen")
end)

Case("T183", "B", "Minimap-Button aus- und einblenden (/ps minimap)", {}, function()
    local MM, b = MinimapButton()
    if not (MM and b) then return NoButton() end
    local a = NewAgg()
    SetDB("minimapButton", true)
    MM.Update()
    local out = Capture()
    Slash("minimap")
    a:Ok(not b:IsShown(), "aus: noch sichtbar")
    a:Ok(ns.db.minimapButton == false, "aus: DB " .. tostring(ns.db.minimapButton))
    a:Ok(Has(out, L.MINIMAP_HIDDEN), "aus: keine Meldung")
    Slash("minimap")
    a:Ok(b:IsShown(), "ein: nicht sichtbar")
    a:Ok(ns.db.minimapButton == true, "ein: DB " .. tostring(ns.db.minimapButton))
    a:Ok(Has(out, L.MINIMAP_SHOWN), "ein: keine Meldung")
    a:Ok(Plain(L.HELP):find("/ps minimap", 1, true) ~= nil, "/ps minimap fehlt in der Hilfe")
    a:Ok(Plain(L.TEST_HELP):find("/ps minimap", 1, true) ~= nil, "/ps minimap fehlt in der Entwickler-Hilfe")
    -- ausgeblendet bleibt es auch nach dem Aktualisieren (z. B. nach /reload)
    SetDB("minimapButton", false)
    MM.Update()
    a:Ok(not b:IsShown(), "aus + Update: sichtbar")
    return a:Result("Schritte")
end)

Case("T184", "B", "Minimap-Winkel: gespeichert, nach /reload gleich, Ziehen, Reparatur", {}, function()
    local MM, b = MinimapButton()
    if not (MM and b) then return NoButton() end
    local a = NewAgg()
    local map = _G.Minimap
    SetDB("minimapButton", true)
    -- saved angle -> position (what the button does after /reload)
    for _, deg in ipairs({ 90, 200, 0 }) do
        SetDB("minimapAngle", deg)
        MM.Update()
        local p, rel, rp, x, y = b:GetPoint(1)
        local ex, ey = MM.Offset(deg, map)
        a:Ok(p == "CENTER" and rel == map and rp == "CENTER", deg .. "°: Anker " .. tostring(p) .. "/" .. tostring(rp))
        a:Ok(Near(x, ex) and Near(y, ey), string.format("%d°: Position %s/%s statt %.1f/%.1f", deg, tostring(x), tostring(y), ex, ey))
    end
    local rx, ry = MM.Offset(90, map)
    a:Ok(Near(rx, 0) and ry > 60, string.format("90° nicht oben (%.1f/%.1f)", rx, ry))
    -- simulated /reload: the saved variables go through ns.InitDB again
    a:Ok(ns.InitDB({ minimapAngle = 45 }).minimapAngle == 45, "45° nicht behalten")
    a:Ok(ns.InitDB({}).minimapAngle == 200 and ns.InitDB({}).minimapButton == true, "Neuinstallation nicht 200° / an")
    a:Ok(ns.InitDB({ minimapButton = false }).minimapButton == false, "aus nicht behalten")
    -- damaged values are repaired
    local d = ns.InitDB({ minimapAngle = "abc", minimapButton = "ja" })
    a:Ok(d.minimapAngle == 200 and d.minimapButton == true, "Text nicht repariert: " .. tostring(d.minimapAngle) .. "/" .. tostring(d.minimapButton))
    a:Ok(ns.InitDB({ minimapAngle = 0 / 0 }).minimapAngle == 200, "NaN nicht repariert")
    a:Ok(ns.InitDB({ minimapAngle = math.huge }).minimapAngle == 200, "unendlich nicht repariert")
    a:Ok(ns.InitDB({ minimapAngle = {} }).minimapAngle == 200, "Tabelle nicht repariert")
    a:Ok(ns.InitDB({ minimapAngle = 450 }).minimapAngle == 90, "450° nicht auf 90°")
    -- drag: cursor below the minimap's centre -> 270°; the cursor is read through ns.API
    local mx, my = map:GetCenter()
    mx, my = tonumber(mx) or 0, tonumber(my) or 0
    local s = tonumber((map:GetEffectiveScale())) or 1
    Stub(ns.API, "GetCursorPosition", function() return mx * s, (my - 100) * s end)
    SetDB("minimapAngle", 200)
    local start, stop = b:GetScript("OnDragStart"), b:GetScript("OnDragStop")
    a:Ok(start ~= nil and stop ~= nil, "Zieh-Skripte fehlen")
    if start and stop then
        start(b)
        local upd = b:GetScript("OnUpdate")
        a:Ok(upd ~= nil, "beim Ziehen kein OnUpdate")
        if upd then upd(b, 0.02) end
        stop(b)
        a:Ok(b:GetScript("OnUpdate") == nil, "OnUpdate nach dem Ziehen noch aktiv")
        a:Ok(Near(ns.db.minimapAngle, 270), "Ziehen: Winkel " .. tostring(ns.db.minimapAngle) .. " statt 270")
        local _, _, _, x, y = b:GetPoint(1)
        local ex, ey = MM.Offset(270, map)
        a:Ok(Near(x, ex) and Near(y, ey), "Ziehen: Position nicht nachgeführt")
    end
    return a:Result("Prüfungen")
end)

Case("T185", "B", "Minimap-Klicks und Tooltip (über die Funktionen)", {}, function()
    if ActiveHost() then return SKIP("Berufsfenster offen – Fall gilt nur ohne Berufsfenster") end
    local MM, b = MinimapButton()
    if not (MM and b) then return NoButton() end
    local a = NewAgg()
    local click = b:GetScript("OnClick")
    if not click then return false, "kein OnClick", "OnClick da" end
    ns.UI:Hide()
    -- without a profession: the same hint as /ps
    SetSim(nil)
    local out = Capture()
    click(b, "LeftButton")
    a:Ok(not ns.UI:IsShown() and Has(out, L.OPEN_PROF_FIRST), "ohne Beruf: nicht wie /ps")
    -- with a profession: first click opens, second click closes
    SetSim({ prof = LWProf() })
    click(b, "LeftButton")
    a:Ok(ns.UI:IsShown(), "Linksklick: Fenster nicht offen")
    click(b, "LeftButton")
    a:Ok(not ns.UI:IsShown(), "zweiter Linksklick: Fenster noch offen")
    -- right-click: options with state and command, the panel stays as it is
    out = Capture()
    click(b, "RightButton")
    a:Ok(not ns.UI:IsShown(), "Rechtsklick öffnet das Fenster")
    a:Ok(Has(out, L.OPTIONS_HEAD), "Rechtsklick: keine Optionen")
    a:Ok(Has(out, "/ps minimap") and Has(out, L.MINIMAP_OPTION), "Rechtsklick: Minimap-Option fehlt")
    a:Ok(Has(out, "/ps line") and Has(out, "/ps alarm"), "Rechtsklick: Optionen fehlen")
    -- tooltip in both languages
    local enter = b:GetScript("OnEnter")
    for _, loc in ipairs({ "enUS", "deDE" }) do
        local restore = ns.SwapLocaleForTest(loc)
        OnUndo(restore, "Sprache " .. loc)
        local ok, err = pcall(function()
            if enter then enter(b) end
            local lines = TooltipLines(GameTooltip)
            a:Ok(LinesWith(lines, L.TITLE) >= 1, loc .. ": Titel fehlt")
            a:Ok(LinesWith(lines, L.MINIMAP_LEFT) == 1 and LinesWith(lines, L.MINIMAP_RIGHT) == 1
                and LinesWith(lines, L.MINIMAP_DRAG) == 1, loc .. ": Erklärung fehlt")
            local leave = b:GetScript("OnLeave")
            if leave then leave(b) end
        end)
        restore()
        a:Ok(ok, loc .. ": " .. tostring(err))
    end
    ns.UI:Hide()
    return a:Result("Schritte")
end)

Case("T186", "B", "Minimap-Button im Spiel", {}, function()
    if Confirmed("T186") then return true, "bestätigt " .. tostring(Confirmed("T186").date) end
    return CLIENT("Buch-Symbol an der Minimap sichtbar, Tooltip in der Sprache des Clients, Ziehen verschiebt ihn, nach "
        .. "/reload am selben Ort, Linksklick wie /ps, Rechtsklick listet die Optionen; bestätigen mit /ps testroutine ok T186")
end)

Case("T187", "B", "Kein Überlappen am Berufsfenster (mit und ohne AHSentinel)", {}, function()
    local UI = ns.UI
    if not (UI and UI.DockPlacement and UI.GetAHSDockFrame and UI.Overlap) then
        return false, "UI.DockPlacement / UI.GetAHSDockFrame fehlt", "Andocken vorhanden"
    end
    local a = NewAgg()
    local W, H = 420, 560
    local function check(name, host, dock, sw, sh, wantRel, wantPoint)
        local point, rel, relPoint, x, y, r = UI.DockPlacement(host, dock, W, H, sw, sh)
        a:Ok(r ~= nil, name .. ": kein Rechteck")
        if not r then return end
        a:Ok(not UI.Overlap(r, host), name .. ": überdeckt das Berufsfenster")
        a:Ok(not (dock and UI.Overlap(r, dock)), name .. ": überdeckt AHSentinel")
        a:Ok(r.l >= 0 and r.r <= sw and r.b >= 0 and r.t <= sh, name .. ": ausserhalb des Bildschirms")
        a:Ok(rel == wantRel and point == wantPoint, name .. ": " .. tostring(point) .. " an " .. tostring(rel) .. " " .. tostring(relPoint)
            .. ", erwartet " .. wantPoint .. " an " .. wantRel)
    end
    local host = { l = 20, r = 700, t = 900, b = 200 }
    local dock = { l = 702, r = 1000, t = 900, b = 400 }
    check("mit AHSentinel", host, dock, 1920, 1080, "dock", "TOPLEFT")
    check("ohne AHSentinel", host, nil, 1920, 1080, "host", "TOPLEFT")
    check("rechter Rand, unter AHSentinel", host, { l = 702, r = 1000, t = 900, b = 700 }, 1300, 1080, "dock", "TOPLEFT")
    check("rechter Rand, links ausweichen", { l = 800, r = 1400, t = 900, b = 200 }, nil, 1600, 1080, "host", "TOPRIGHT")

    -- Interface of AHSentinel: only AHAnalyzerPro.Crafting:GetDockFrame(), never a frame search
    local shown = true
    local fake = { IsShown = function() return shown end }
    Stub(_G, "AHAnalyzerPro", { Crafting = { GetDockFrame = function(self) return fake end } })
    a:Ok(UI.GetAHSDockFrame() == fake, "sichtbares AHSentinel-Fenster nicht erkannt")
    shown = false
    a:Ok(UI.GetAHSDockFrame() == nil, "verstecktes AHSentinel-Fenster genommen")
    Stub(_G, "AHAnalyzerPro", { GetMarketValue = function() return 1 end })
    a:Ok(UI.GetAHSDockFrame() == nil, "ältere AHSentinel-Version ohne GetDockFrame")
    Stub(_G, "AHAnalyzerPro", { Crafting = { GetDockFrame = function() error("AHSentinel-Testfehler (absichtlich)") end } })
    a:Ok(UI.GetAHSDockFrame() == nil, "Fehler in GetDockFrame nicht abgefangen")
    Stub(_G, "AHAnalyzerPro", nil)
    a:Ok(UI.GetAHSDockFrame() == nil, "ohne AHSentinel")
    return a:Result("Prüfungen")
end)

Case("T188", "B", "Berufsfenster mit AHSentinel im Spiel", {}, function()
    if Confirmed("T188") then return true, "bestätigt " .. tostring(Confirmed("T188").date) end
    return CLIENT("Berufsfenster mit AHSentinel öffnen: ProfessionSentinel steht rechts neben dem AHSentinel-Gewinn-Fenster, "
        .. "nichts verdeckt; AHSentinel-Fenster schliessen -> Panel rückt ans Berufsfenster; bestätigen mit /ps testroutine ok T188 "
        .. "(braucht AHSentinel mit AHAnalyzerPro.Crafting:GetDockFrame)")
end)

Case("T189", "B", "Fertigkeit im modernen Client: echter Wert statt 0, Plan und Lebenslinie folgen", {}, function()
    local UI, LL, PL = ns.UI, ns.Lifeline, ns.Plan
    if not (UI and UI.ForeverProfession and UI.BestRank and LL and LL.Calc and PL and PL.Build) then
        return false, "UI.ForeverProfession / UI.BestRank fehlt", "Fertigkeit robust gelesen"
    end
    if not ns.UsesModernProfessions then return SKIP("nur moderner Client (WoW Forever, Retail)") end
    -- a profession of this data with a recipe that is still orange at 110 and 111
    local prof, rec
    for _, p in ipairs(ns.Professions or {}) do
        if ns.ResolveProf(p.id) == p.id then
            for _, r in ipairs(ns.ByProf[p.id] or {}) do
                if (r.yellow or 0) > 115 and (r.grey or 0) > r.yellow and (r.req or 0) <= 110 then prof, rec = p.id, r; break end
            end
        end
        if prof then break end
    end
    if not prof then return SKIP("kein passendes Rezept in den Daten") end
    local a = NewAgg()
    Stub(ns, "Sim", nil)
    local child = { professionID = prof, skillLevel = 0, maxSkillLevel = 0 }      -- 0.9.14 in Forever: child info 0
    local base = { professionID = prof, skillLevel = 110, maxSkillLevel = 150 }
    Stub(ns.API, "TradeSkillGetChildProfessionInfo", function() return child end)
    Stub(ns.API, "TradeSkillGetBaseProfessionInfo", function() return base end)
    Stub(ns.API, "TradeSkillGetProfessionInfoBySkillLineID", nil)
    Stub(ns.Scan, "Rank", function() return nil end)
    Stub(PL, "current", PL.current)      -- PL.Build sets it: back afterwards
    local p1, r1, m1 = UI.ForeverProfession()
    a:Ok(p1 == prof and r1 == 110 and m1 == 150, "Kind 0 / Basis 110: gelesen " .. tostring(r1) .. "/" .. tostring(m1))
    local plan = PL.Build(prof, r1, m1)
    a:Ok(plan ~= nil and plan.from == 110, "Plan beginnt bei " .. tostring(plan and plan.from))
    local c0 = LL.Calc(rec, r1)
    base.skillLevel = 111
    local _, r2 = UI.ForeverProfession()
    local c1 = LL.Calc(rec, r2)
    a:Ok(r2 == 111, "+1 nicht gelesen: " .. tostring(r2))
    a:Ok(c0 and c1 and c0.crafts and c1.crafts and c1.crafts < c0.crafts,
        "N× bis Gelb sinkt nicht: " .. tostring(c0 and c0.crafts) .. " -> " .. tostring(c1 and c1.crafts))
    -- stale low value in one source: the higher one wins
    child.skillLevel, child.maxSkillLevel = 33, 75
    local _, r3 = UI.ForeverProfession()
    a:Ok(r3 == 111, "veralteter Wert 33 gewinnt: " .. tostring(r3))
    -- GetProfessionInfo as fallback
    child.skillLevel, base.skillLevel = 0, 0
    Stub(ns.Scan, "Rank", function() return 114, 150 end)
    local _, r4 = UI.ForeverProfession()
    a:Ok(r4 == 114, "Rückfall GetProfessionInfo: " .. tostring(r4))
    -- nothing valid: unknown, never 0
    Stub(ns.Scan, "Rank", function() return 0, 0 end)
    local _, r5 = UI.ForeverProfession()
    a:Ok(r5 == nil, "kein gültiger Wert, trotzdem " .. tostring(r5))
    a:Ok(type(L.SKILL_UNKNOWN) == "string" and L.SKILL_UNKNOWN ~= "", "Text 'Fertigkeit unbekannt' fehlt")
    return a:Result("Prüfungen")
end)

Case("T190", "B", "AHSentinel-Fenster erscheint nach dem Panel: Haken, neu andocken, kein Überlappen", {}, function()
    local UI = ns.UI
    if not (UI and UI.HookAHSDock and UI.CheckDock and UI.Redock and UI.DockPlacement and UI.Overlap) then
        return false, "UI.HookAHSDock / UI.CheckDock fehlt", "Andocken an spät erscheinendes AHSentinel-Fenster"
    end
    local a = NewAgg()
    local shown = false
    local hooks, nHooks = {}, 0
    local fake = {
        IsShown = function() return shown end,
        HookScript = function(_, script, fn) hooks[script] = fn; nHooks = nHooks + 1 end,
    }
    local asked
    -- AHSentinel 0.65.11+: GetDockFrame(true) returns the frame even while hidden
    Stub(_G, "AHAnalyzerPro", { Crafting = { GetDockFrame = function(_, all) asked = all; if all or shown then return fake end end } })
    local host = { l = 20, r = 700, t = 900, b = 200 }
    -- 1. the panel opens first: no visible AHSentinel window -> right of the profession window
    a:Ok(UI.GetAHSDockFrame() == nil, "verborgenes Fenster als sichtbar genommen")
    local _, rel0 = UI.DockPlacement(host, nil, 420, 560, 1920, 1080)
    a:Ok(rel0 == "host", "ohne AHSentinel nicht am Berufsfenster: " .. tostring(rel0))
    -- 2. the hidden frame is hooked once (also when asked again on Refresh / TRADE_SKILL_SHOW)
    a:Ok(UI.HookAHSDock() == fake and asked == true, "GetDockFrame(true) nicht gefragt")
    UI.HookAHSDock()      -- (CheckDock is not called here: it would move a real, open panel)
    a:Ok(hooks.OnShow == UI.Redock and hooks.OnHide == UI.Redock and hooks.OnSizeChanged == UI.Redock,
        "OnShow/OnHide/OnSizeChanged nicht auf Neu-Andocken gehakt")
    a:Ok(nHooks == 3, "Haken nicht genau einmal gesetzt (" .. nHooks .. " Aufrufe)")
    -- 3. AHSentinel's window appears AFTER the panel -> dock right of it, no overlap
    shown = true
    a:Ok(UI.GetAHSDockFrame() == fake, "erschienenes Fenster nicht erkannt")
    local dock = { l = 702, r = 1000, t = 900, b = 400 }
    local _, rel1, _, _, _, r1 = UI.DockPlacement(host, dock, 420, 560, 1920, 1080)
    a:Ok(rel1 == "dock" and r1 and not UI.Overlap(r1, dock) and not UI.Overlap(r1, host),
        "nach dem Erscheinen nicht rechts daneben: " .. tostring(rel1))
    -- 4. older AHSentinel without the argument: only the visible frame, no error
    shown = false
    Stub(_G, "AHAnalyzerPro", { Crafting = { GetDockFrame = function() if shown then return fake end end } })
    local okOld, resOld = pcall(UI.HookAHSDock)
    a:Ok(okOld and resOld == nil, "ältere AHSentinel-Version: " .. tostring(resOld))
    Stub(_G, "AHAnalyzerPro", nil)
    a:Ok(UI.HookAHSDock() == nil, "ohne AHSentinel")
    return a:Result("Prüfungen")
end)

Case("T191", "C", "Rangliste Leveln: Material pro Skillpunkt, gelernte zuerst, grau fehlt", {}, function()
    local AD = ns.Advisor
    if not (AD and AD.MatRanking and AD.BaseMats and AD.ColourPoints) then
        return false, "AD.MatRanking fehlt", "Leveln nach Material pro Skillpunkt"
    end
    local a = NewAgg()
    local BAR, PART = 990001, 990002      -- made-up item IDs (no real recipe makes them)
    local function R(name, y, g, gr, reagents, learned)
        return { name = name, nameEN = name, prof = 164, spell = 0, src = 0, yellow = y, green = g, grey = gr,
            reagents = reagents, learnedT = learned }
    end
    local rank = 50
    local A = R("A orange 2 Barren", 60, 70, 80, { BAR, 2 }, true)      -- 2 / 1   = 2
    local B = R("B gelb 1 Barren", 40, 60, 80, { BAR, 1 }, true)        -- 1 / 0.5 = 2
    local C = R("C ungelernt 1 Barren", 60, 70, 80, { BAR, 1 }, false)  -- 1 / 1   = 1, but not learned
    local D = R("D grau", 20, 30, 45, { BAR, 1 }, true)                 -- grey: left out
    local F = R("F Zwischenprodukt", 10, 20, 30, { BAR, 3 }, true)      -- makes PART from 3 bars
    F.out, F.outMin, F.outMax = PART, 1, 1
    local E = R("E 2 Zwischenprodukte", 60, 70, 80, { PART, 2 }, true)  -- 2 × 3 bars = 6
    Stub(ns.ByOutput, PART, { F })
    local list = AD.MatRanking({ A, B, C, D, E }, rank, function(r) return r.learnedT end, function() return 0 end)
    local names = {}
    for _, e in ipairs(list) do names[#names + 1] = e.recipe.name end
    local got = table.concat(names, " | ")
    a:Ok(#list == 4, "4 Rezepte erwartet: " .. got)
    a:Ok(list[1] and list[1].recipe == A and list[2] and list[2].recipe == B, "Gleichstand A/B nicht stabil: " .. got)
    a:Ok(list[1] and math.abs(list[1].matValue - 2) < 1e-9 and list[2] and math.abs(list[2].matValue - 2) < 1e-9,
        "Werte A/B nicht 2")
    a:Ok(list[3] and list[3].recipe == E and math.abs(list[3].matValue - 6) < 1e-9,
        "Zwischenprodukt nicht als Grundmaterial (6): " .. got)
    a:Ok(list[4] and list[4].recipe == C, "ungelerntes Rezept nicht unter allen gelernten: " .. got)
    for _, e in ipairs(list) do a:Ok(e.recipe ~= D, "graues Rezept in der Liste") end
    a:Ok(AD.ColourPoints(B, rank) == 0.5 and AD.ColourPoints(R("g", 30, 40, 80, { BAR, 1 }), rank) == 0.25,
        "Punkte gelb 0,5 / grün 0,25")
    return a:Result("Prüfungen")
end)

Case("T192", "B", "Ereignisse gesammelt: 20 in 1 s -> höchstens 3 Neuaufbauten", {}, function()
    local UI = ns.UI
    if not (UI and UI.RequestRefresh and UI.RunPendingRefresh) then return false, "UI.RequestRefresh fehlt", "Neuaufbau gesammelt" end
    local a = NewAgg()
    local now, queue = 0, {}
    Stub(ns.API, "TimerAfter", function(delay, fn) queue[#queue + 1] = { due = now + delay, fn = fn } end)
    local runs = 0
    Stub(UI, "Refresh", function() runs = runs + 1 end)
    if ns.Lifeline then Stub(ns.Lifeline, "RefreshBlizzard", function() end) end
    local function fire(upTo)
        local i = 1
        while i <= #queue do
            if queue[i].due <= upTo then local q = table.remove(queue, i); q.fn() else i = i + 1 end
        end
    end
    UI.RunPendingRefresh()      -- a refresh already planned before the test: run it now (stubbed)
    runs = 0
    for k = 0, 19 do
        now = k * 0.05
        fire(now)
        UI.RequestRefresh()
    end
    now = 2; fire(now)
    a:Ok(runs >= 1 and runs <= 3, "Neuaufbauten bei 20 Ereignissen in 1 s: " .. runs)
    a:Ok(#queue == 0, "Neuaufbau bleibt hängen")
    a:Ok((UI.REFRESH_DELAY or 0) >= 0.2 and (UI.REFRESH_DELAY or 0) <= 0.5, "Abstand " .. tostring(UI.REFRESH_DELAY))
    -- results are cached: drawing again does not compute again
    local AD = ns.Advisor
    if AD and AD.UpdateCached and ns.Professions and ns.Professions[1] then
        local p = ns.Professions[1].id
        AD.Invalidate()
        local before = AD.computeCount or 0
        AD.UpdateCached(p, 100); AD.UpdateCached(p, 100); AD.UpdateCached(p, 100)
        a:Ok((AD.computeCount or 0) - before == 1, "Zwischenspeicher: " .. ((AD.computeCount or 0) - before) .. "× gerechnet")
        AD.Invalidate()
    end
    return a:Result("Prüfungen")
end)

Case("T193", "B", "Klick während des Neuaufbaus öffnet das Rezept", {}, function()
    local UI = ns.UI
    if not (UI and UI.SelectInBlizzard and UI.ROW_CLICKS) then return false, "UI.SelectInBlizzard fehlt", "Klick robust" end
    local a = NewAgg()
    a:Ok(UI.ROW_CLICKS[1] == "LeftButtonDown", "Linksklick nicht beim Drücken: " .. tostring(UI.ROW_CLICKS[1]))
    local r = ns.BySpell and next(ns.BySpell) and ns.BySpell[next(ns.BySpell)]
    if not r then return SKIP("keine Rezeptdaten") end
    -- a rebuild is planned (not run yet) while the click comes
    Stub(ns.API, "TimerAfter", function() end)
    Stub(UI, "Refresh", function() end)
    UI.RequestRefresh()
    local opened
    if ns.UsesModernProfessions then
        Stub(ns.API, "TradeSkillOpenRecipe", function(id) opened = id end)
        Stub(ns.API, "TradeSkillGetRecipeInfo", function(id) if id == r.spell then return { recipeID = id, name = r.name } end end)
        Stub(UI, "BlizzardRecipeList", function() return nil end)
        a:Ok(UI.SelectInBlizzard(r) == true and opened == r.spell, "Rezept nicht geöffnet: " .. tostring(opened))
    else
        Stub(ns.API, "GetNumTradeSkills", function() return 1 end)
        Stub(ns.API, "GetTradeSkillInfo", function() return r.name end)
        Stub(UI, "ApplyTradeSkillSelection", function(i) opened = i end)
        a:Ok(UI.SelectInBlizzard(r) == true and opened == 1, "Rezept nicht gewählt: " .. tostring(opened))
    end
    UI.RunPendingRefresh()      -- the planned rebuild (stubbed) – nothing stays pending after the test
    return a:Result("Prüfungen")
end)

Case("T194", "B", "Suchtext im Berufsfenster: Klick öffnet trotzdem das richtige Rezept", {}, function()
    local UI = ns.UI
    if not (UI and UI.SelectInBlizzard) then return false, "UI.SelectInBlizzard fehlt", "Klick robust" end
    local a = NewAgg()
    local r = ns.BySpell and next(ns.BySpell) and ns.BySpell[next(ns.BySpell)]
    if not r then return SKIP("keine Rezeptdaten") end
    local out = Capture()
    if ns.UsesModernProfessions then
        local text = "abc"
        local box = { GetText = function() return text end, SetText = function(_, t) text = t end }
        Stub(UI, "BlizzardRecipeList", function() return { SearchBox = box } end)
        Stub(ns.API, "TradeSkillGetRecipeInfo", function(id) if id == r.spell then return { recipeID = id, name = r.name } end end)
        local opened, textAtOpen
        Stub(ns.API, "TradeSkillOpenRecipe", function(id) opened = id; textAtOpen = text end)
        a:Ok(UI.SelectInBlizzard(r) and opened == r.spell, "nicht geöffnet")
        a:Ok(textAtOpen == "", "Suchtext vor dem Öffnen nicht geleert: '" .. tostring(textAtOpen) .. "'")
        -- the open fails: a message instead of silence
        Stub(ns.API, "TradeSkillOpenRecipe", function() error("Testfehler (absichtlich)") end)
        a:Ok(UI.SelectInBlizzard(r) == false and #out > 0, "keine Meldung bei Fehlschlag")
    else
        local filtered = true
        Stub(ns.API, "GetNumTradeSkills", function() return filtered and 0 or 2 end)
        Stub(ns.API, "GetTradeSkillInfo", function(i) return i == 2 and r.name or "Anderes" end)
        Stub(ns.API, "SetTradeSkillItemNameFilter", function() filtered = false end)
        Stub(ns.API, "ExpandTradeSkillSubClass", function() end)
        Stub(UI, "EraSearchBox", function() return nil end)
        local sel
        Stub(UI, "ApplyTradeSkillSelection", function(i) sel = i end)
        a:Ok(UI.SelectInBlizzard(r) and sel == 2, "nach dem Leeren der Suche nicht gewählt: " .. tostring(sel))
        filtered = true
        Stub(ns.API, "SetTradeSkillItemNameFilter", function() end)
        a:Ok(UI.SelectInBlizzard(r) == false and #out > 0, "keine Meldung bei Fehlschlag")
    end
    return a:Result("Prüfungen")
end)

Case("T195", "B", "Zugeklappte Kategorie: Rezept wird geöffnet; Hintergrund nimmt keine Klicks", {}, function()
    local UI = ns.UI
    if not (UI and UI.SelectInBlizzard) then return false, "UI.SelectInBlizzard fehlt", "Klick robust" end
    local a = NewAgg()
    local p = UI.PanelFrame and UI.PanelFrame()
    if p and p.Inset and p.Inset.IsMouseEnabled then
        a:Ok(not p.Inset:IsMouseEnabled(), "Hintergrund (Inset) nimmt Mausklicks an")
    end
    if ns.UsesModernProfessions then
        a:Note("moderner Client: OpenRecipe klappt die Kategorie selbst auf (T193/T194)")
        return a:Result("Prüfungen")
    end
    local r = ns.BySpell and next(ns.BySpell) and ns.BySpell[next(ns.BySpell)]
    if not r then return SKIP("keine Rezeptdaten") end
    local expanded = false
    Stub(ns.API, "GetNumTradeSkills", function() return expanded and 3 or 1 end)
    Stub(ns.API, "GetTradeSkillInfo", function(i) if i == 3 then return r.name end return "Kategorie", "header" end)
    Stub(ns.API, "SetTradeSkillItemNameFilter", function() end)
    Stub(ns.API, "ExpandTradeSkillSubClass", function(i) if i == 0 then expanded = true end end)
    Stub(UI, "EraSearchBox", function() return nil end)
    local sel
    Stub(UI, "ApplyTradeSkillSelection", function(i) sel = i end)
    a:Ok(UI.SelectInBlizzard(r) and sel == 3, "Kategorie nicht aufgeklappt: " .. tostring(sel))
    return a:Result("Prüfungen")
end)

Case("T196", "B", "Klick öffnet das Rezept mit der Rezept-ID des modernen Clients (Zauber-ID -> RecipeID)", {}, function()
    local UI = ns.UI
    if not (UI and UI.ModernRecipeID and UI.SelectInBlizzard) then return false, "UI.ModernRecipeID fehlt", "Zuordnung Zauber-ID -> RecipeID" end
    local a = NewAgg()
    -- one click = one action: left on press only, never press and release
    local downs, ups = 0, 0
    for _, c in ipairs(UI.ROW_CLICKS or {}) do
        if c == "LeftButtonDown" then downs = downs + 1 elseif c == "LeftButtonUp" or c == "AnyUp" or c == "AnyDown" then ups = ups + 1 end
    end
    a:Ok(downs == 1 and ups == 0, "Linksklick würde doppelt auslösen")
    if not ns.UsesModernProfessions then
        a:Note("alter Client: Auswahl über den Namen (T193–T195)")
        return a:Result("Prüfungen")
    end
    local r = { spell = 3320, name = "Grober Schleifstein", nameEN = "Rough Sharpening Stone" }
    -- the window knows the recipe under another ID (WoW Forever)
    local window = {
        [70001] = { recipeID = 70001, name = "Grobes Gewichtsband" },
        [70002] = { recipeID = 70002, name = "Grober Schleifstein", learned = true },
        [70003] = { recipeID = 70003, name = "Grober Schleifstein", isRecraft = true },
    }
    Stub(ns.API, "TradeSkillGetAllRecipeIDs", function() return { 70001, 70003, 70002 } end)
    Stub(ns.API, "TradeSkillGetRecipeInfo", function(id) return window[id] end)
    a:Ok(UI.ModernRecipeID(r) == 70002, "falsche RecipeID: " .. tostring(UI.ModernRecipeID(r)))
    local opened
    Stub(ns.API, "TradeSkillOpenRecipe", function(id) opened = id end)
    Stub(UI, "BlizzardRecipeList", function() return nil end)
    local out = Capture()
    a:Ok(UI.SelectInBlizzard(r) == true and opened == 70002 and #out == 0, "nicht mit 70002 geöffnet: " .. tostring(opened))
    -- English client name
    window[70002].name = "Rough Sharpening Stone"
    UI.InvalidateRecipeMap()
    a:Ok(UI.ModernRecipeID(r) == 70002, "englischer Name nicht erkannt")
    -- not in the window's list, but the window knows the spell ID: its recipe ID
    window = { [3320] = { recipeID = 3320, name = "Anderer Name" } }
    Stub(ns.API, "TradeSkillGetAllRecipeIDs", function() return {} end)
    UI.InvalidateRecipeMap()
    a:Ok(UI.ModernRecipeID(r) == 3320, "Rückfall auf die Zauber-ID des Fensters nicht genommen")
    -- not in this window: message, nothing opened
    window, opened = {}, nil
    UI.InvalidateRecipeMap()
    a:Ok(UI.SelectInBlizzard(r) == false and opened == nil and #out > 0, "fehlendes Rezept ohne Meldung")
    return a:Result("Prüfungen")
end)

Case("T197", "B", "Klick ohne vorherigen AHSentinel-Klick: sofort die Rezept-ID des Fensters (Befund 5. Nov.)", {}, function()
    local UI = ns.UI
    if not (UI and UI.RecipeMap and UI.SelectInBlizzard) then return false, "UI.RecipeMap fehlt", "eigene Rezept-ID-Tabelle" end
    if not ns.UsesModernProfessions then return SKIP("nur moderner Client (WoW Forever, Retail)") end
    local a = NewAgg()
    Stub(_G, "AHAnalyzerPro", nil)      -- no AHSentinel at all
    local r = { spell = 2660, name = "Grobes Kupferarmband", nameEN = "Rough Copper Bracers", out = 2853 }
    -- the window also answers for the spell ID (same name), but lists the recipe under its own ID 80002
    local window = {
        [2660] = { recipeID = 2660, name = "Grobes Kupferarmband" },
        [80001] = { recipeID = 80001, name = "Kupferkettengürtel", learned = true },
        [80002] = { recipeID = 80002, name = "Grobes Kupferarmband", learned = true },
    }
    Stub(ns.API, "TradeSkillGetAllRecipeIDs", function() return { 80001, 80002 } end)
    Stub(ns.API, "TradeSkillGetRecipeInfo", function(id) return window[id] end)
    local timers = 0
    Stub(ns.API, "TimerAfter", function() timers = timers + 1 end)
    local opened
    Stub(ns.API, "TradeSkillOpenRecipe", function(id) opened = id end)
    Stub(UI, "BlizzardRecipeList", function() return nil end)
    Stub(UI, "ShownModernRecipe", function() return opened end)      -- the window shows what was opened
    local out = Capture()
    a:Ok(UI.SelectInBlizzard(r) == true and opened == 80002, "nicht die ID des Fensters: " .. tostring(opened))
    a:Ok(timers == 0, "Klick wartet auf einen Timer (" .. timers .. ")")
    local c = UI.lastClick
    a:Ok(c and c.ok and c.recipeID == 80002 and (c.ms or 0) < 500, "Auswahl nicht sofort bestätigt: "
        .. tostring(c and c.ms) .. " ms")
    a:Ok(#out == 0, "Meldung trotz Erfolg")
    -- by result item when the names differ (other client language)
    window[80002].name = "Bracelets de cuivre grossiers"
    Stub(ns.API, "TradeSkillGetRecipeSchematic", function(id) return { outputItemID = id == 80002 and 2853 or 1 } end)
    UI.InvalidateRecipeMap()
    a:Ok(UI.ModernRecipeID(r) == 80002, "Ergebnis-Item nicht zugeordnet: " .. tostring(UI.ModernRecipeID(r)))
    return a:Result("Prüfungen")
end)

-- sandbox for the diagnostic log: an empty db.diag, writing switched on for this case only
local function DiagSandbox()
    local D = ns.Diagnose
    if not (D and ns.Diag) then return nil end
    SetDB("diag", { entries = {}, sessions = 0, seenErr = {} })
    Stub(D, "testSink", true)
    return D
end

Case("T198", "J", "Diagnose-Protokoll: KLICK, AUFBAU, LANGSAM, ÜBERLAPPT, FEHLER", {}, function()
    local D = DiagSandbox()
    if not D then return false, "Diagnose.lua fehlt", "Protokoll vorhanden" end
    local a = NewAgg()
    D.Click({ spell = 2660, recipeID = 80002, way = "OpenRecipe", ok = true, ms = 3.2 }, { spell = 2660, name = "Testrezept" })
    D.Build("TRADE_SKILL_LIST_UPDATE", 7, 4.5)
    ns.Diag("LANGSAM", "AD.Update", 21.7)
    D.Overlap("Panel überdeckt Testfenster")
    ns.DiagError("Test", "Testfehler (absichtlich)")
    local kinds = {}
    for _, e in ipairs(ns.db.diag.entries) do kinds[e.k] = true end
    for _, k in ipairs(D.KINDS) do a:Ok(kinds[k], "Art fehlt: " .. k) end
    local text = D.Text()
    a:Ok(text:find("80002", 1, true) and text:find("TRADE_SKILL_LIST_UPDATE", 1, true) and text:find("21.7", 1, true),
        "Einträge nicht im Text")
    -- the same error again only counts (no flooding)
    ns.DiagError("Test", "Testfehler (absichtlich)")
    local n = 0
    for _, e in ipairs(ns.db.diag.entries) do if e.k == "FEHLER" then n = n + 1; a:Ok(e.n == 2, "Fehler nicht gezählt: " .. tostring(e.n)) end end
    a:Ok(n == 1, "gleicher Fehler doppelt eingetragen")
    -- a click from the panel is written as KLICK (the real way, recipe opening stubbed)
    if ns.UI and ns.UI.SelectInBlizzard and ns.BySpell and next(ns.BySpell) then
        local r = ns.BySpell[next(ns.BySpell)]
        Stub(ns.API, "TradeSkillOpenRecipe", function() end)
        Stub(ns.API, "TradeSkillGetRecipeInfo", function(id) if id == r.spell then return { recipeID = id, name = r.name } end end)
        Stub(ns.UI, "BlizzardRecipeList", function() return nil end)
        Stub(ns.UI, "ApplyTradeSkillSelection", function() end)
        Stub(ns.API, "GetNumTradeSkills", function() return 1 end)
        Stub(ns.API, "GetTradeSkillInfo", function() return r.name end)
        Capture()
        ns.UI.SelectInBlizzard(r)
        a:Ok(ns.db.diag.entries[1] and ns.db.diag.entries[1].k == "KLICK", "Klick im Panel nicht protokolliert")
    end
    return a:Result("Prüfungen")
end)

Case("T199", "J", "Diagnose-Protokoll: Ringpuffer und Testlauf schreibt nicht ins echte Protokoll", {}, function()
    local D = ns.Diagnose
    if not (D and ns.Diag) then return false, "Diagnose.lua fehlt", "Protokoll vorhanden" end
    local a = NewAgg()
    SetDB("diag", { entries = {}, sessions = 0, seenErr = {} })
    a:Ok(ns.Diag("KLICK", "ohne Freigabe") == nil and #ns.db.diag.entries == 0, "Testlauf schreibt ins Protokoll")
    Stub(D, "testSink", true)
    for k = 1, (ns.DIAG_MAX or 200) + 25 do ns.Diag("AUFBAU", "Ereignis " .. k, 1) end
    a:Ok(#ns.db.diag.entries == (ns.DIAG_MAX or 200), "Ringpuffer: " .. #ns.db.diag.entries)
    a:Ok(ns.db.diag.entries[1].t == "Ereignis " .. ((ns.DIAG_MAX or 200) + 25), "neueste nicht zuerst")
    -- a damaged log is repaired, never a Lua error
    SetDB("diag", "kaputt")
    a:Ok(pcall(ns.Diag, "FEHLER", "nach Reparatur") and type(ns.db.diag) == "table", "beschädigtes Protokoll")
    return a:Result("Prüfungen")
end)

Case("T200", "J", "GSDIAG1: Kopfzeile, Grösse, keine Namen (Köderwerte)", {}, function()
    local D = DiagSandbox()
    if not D then return false, "Diagnose.lua fehlt", "Protokoll vorhanden" end
    local a = NewAgg()
    -- bait values: player, realm, guild and a saved character must never appear
    Stub(ns, "PlayerName", function() return "Koederheld" end)
    Stub(ns.API, "GetRealmName", function() return "Koederreich" end)
    Stub(ns.API, "GetGuildInfo", function() return "Koedergilde" end)
    SetDB("chars", { ["Koedertwink-Koederreich"] = { known = {}, profs = {} } })
    ns.DiagError("Test", "Fehler bei Koederheld in Koedergilde auf Koederreich, Twink Koedertwink")
    local s = D.Export()
    local head = s:match("^[^\n]+") or ""
    a:Ok(head:find("^GSDIAG1|ProfessionSentinel|") ~= nil, "Kopfzeile: " .. head)
    for _, bait in ipairs({ "Koederheld", "Koederreich", "Koedergilde", "Koedertwink" }) do
        a:Ok(not s:find(bait, 1, true), "Name im Export: " .. bait)
    end
    a:Ok(s:find("<Name>", 1, true) ~= nil, "Namen nicht ersetzt")
    a:Ok(#s <= (ns.DIAG_EXPORT_MAX or 24000), "Export zu gross: " .. #s)
    -- written on logout, but never during the test routine
    a:Ok(D.OnLogout() == false, "Export während der Testroutine geschrieben")
    return a:Result("Prüfungen")
end)

Case("T201", "J", "/ps protokoll öffnet das Fenster mit markierbarem Text", {}, function()
    local D = DiagSandbox()
    if not D then return false, "Diagnose.lua fehlt", "Protokoll vorhanden" end
    local a = NewAgg()
    local before = D.Frame() and D.Frame():IsShown()
    SlashCmdList.PROFESSIONSENTINEL("protokoll")
    local f = D.Frame()
    a:Ok(f and f:IsShown(), "Fenster nicht offen")
    a:Ok(f and f.eb and (f.eb:GetText() or ""):find(L.DG_SECTION_DIAG, 1, true), "Text fehlt")
    if f and not before then f:Hide() end
    return a:Result("Prüfungen")
end)

Case("T202", "J", "Ehrliche Zählung, Fälle aus dem Spiel, Liste im Client prüfen", {}, function()
    local a = NewAgg()
    -- a case that checked nothing is never OK
    local empty = NewAgg()
    empty:Note("nur ein Hinweis")
    local r1 = empty:Result("Prüfungen")
    a:Ok(Marker(r1, "skip"), "Fall ohne Prüfung zählt als OK")
    -- every error from the game has its own case (5 Nov.): popup %, docking, skill 0, AHSentinel window late,
    -- click without AHSentinel / no waiting, diagnostic log
    for _, id in ipairs({ "T63", "T187", "T189", "T190", "T193", "T196", "T197", "T198" }) do
        a:Ok(byId[id] ~= nil, "Fall aus dem Spiel fehlt: " .. id)
    end
    -- the fixed list for the player: printed from the last run
    SetDB("autotest", { clientList = { { id = "T999", name = "Testfall", how = "im Spiel ansehen" } } })
    local out = Capture()
    a:Ok(TR:ClientList() == 1 and Has(out, "T999"), "Liste im Client prüfen nicht ausgegeben")
    SetDB("autotest", {})
    a:Ok(TR:ClientList() == 0, "leere Liste")
    a:Ok(type(L.TR_NOT_AUTOMATED) == "string" and L.TR_NOT_AUTOMATED:find("%d", 1, true), "Text 'nicht automatisiert' fehlt")
    return a:Result("Prüfungen")
end)

Case("T203", "B", "Klick wählt über die Liste des Fensters (wie AHSentinel), OpenRecipe nur als Rückfall", {}, function()
    local UI = ns.UI
    if not (UI and UI.SelectInBlizzard and UI.BlizzardRecipeList) then return false, "UI.SelectInBlizzard fehlt", "Auswahl über die Liste" end
    if not ns.UsesModernProfessions then return SKIP("nur moderner Client (WoW Forever, Retail)") end
    local a = NewAgg()
    local r = { spell = 2660, name = "Grobes Kupferarmband", nameEN = "Rough Copper Bracers" }
    local window = { [80002] = { recipeID = 80002, name = "Grobes Kupferarmband", learned = true } }
    Stub(ns.API, "TradeSkillGetAllRecipeIDs", function() return { 80002 } end)
    Stub(ns.API, "TradeSkillGetRecipeInfo", function(id) return window[id] end)
    local selected, scroll, opened
    local list = { SelectRecipe = function(self, info, toView) selected, scroll = info, toView end }
    Stub(UI, "BlizzardRecipeList", function() return list end)
    Stub(ns.API, "TradeSkillOpenRecipe", function(id) opened = id end)
    Stub(UI, "ShownModernRecipe", function() return selected and selected.recipeID end)      -- the list reports it at once
    Capture()
    a:Ok(UI.SelectInBlizzard(r) == true, "Klick schlägt fehl")
    a:Ok(selected == window[80002] and scroll == true, "nicht über RecipeList:SelectRecipe(info, true) gewählt")
    a:Ok(opened == nil, "OpenRecipe trotz Auswahl über die Liste")
    local c = UI.lastClick
    a:Ok(c and c.way == "Liste" and c.ok and c.shown == 80002, "Auswahl nicht im selben Frame gemeldet")
    -- the list cannot select (error): OpenRecipe as fallback
    selected = nil
    list.SelectRecipe = function() error("Testfehler (absichtlich)") end
    a:Ok(UI.SelectInBlizzard(r) == true and opened == 80002 and UI.lastClick.way == "OpenRecipe", "kein Rückfall auf OpenRecipe")
    return a:Result("Prüfungen")
end)

Case("T204", "B", "20 Listen-Ereignisse: Rezept-ID-Tabelle höchstens 1× neu gebaut", {}, function()
    local UI = ns.UI
    if not (UI and UI.OnProfessionEvent and UI.RecipeMap) then return false, "UI.OnProfessionEvent fehlt", "Tabelle zwischengespeichert" end
    local a = NewAgg()
    Stub(ns.API, "TimerAfter", function() end)
    Stub(UI, "Refresh", function() end)
    if ns.Lifeline then Stub(ns.Lifeline, "RefreshBlizzard", function() end) end
    Stub(ns.API, "TradeSkillGetAllRecipeIDs", function() return { 1 } end)
    Stub(ns.API, "TradeSkillGetRecipeInfo", function(id) return { recipeID = id, name = "Test" } end)
    UI.OnProfessionEvent("TRADE_SKILL_SHOW")
    local before = UI.recipeMapBuilds or 0
    for _ = 1, 20 do
        UI.OnProfessionEvent("TRADE_SKILL_LIST_UPDATE")
        UI.RecipeMap()      -- a click after every event
    end
    local built = (UI.recipeMapBuilds or 0) - before
    a:Ok(built <= 1, "Tabelle " .. built .. "× neu gebaut")
    -- window opened again / profession switched: built again
    UI.OnProfessionEvent("TRADE_SKILL_DATA_SOURCE_CHANGED")
    local b2 = UI.recipeMapBuilds or 0
    UI.RecipeMap()
    a:Ok((UI.recipeMapBuilds or 0) == b2 + 1, "Berufswechsel baut die Tabelle nicht neu")
    UI.RunPendingRefresh()      -- nothing stays pending after the test
    return a:Result("Prüfungen")
end)

Case("T205", "B", "Ereignis-Sturm: 100 Listen-Ereignisse ohne Änderung -> kein Neuaufbau (Diagnose 0.9.22)", {}, function()
    local Scan, UI = ns.Scan, ns.UI
    if not (Scan and Scan.OnEvent and Scan.RunPending and Scan.Fingerprint) then return false, "Scan.OnEvent fehlt", "Schutz vor Ereignis-Sturm" end
    local a = NewAgg()
    local now, queue = 100, {}
    Stub(Scan, "Now", function() return now end)
    Stub(ns.API, "TimerAfter", function(delay, fn) queue[#queue + 1] = { due = now + delay, fn = fn } end)
    local function fire(upTo)
        local i = 1
        while i <= #queue do
            if queue[i].due <= upTo then local q = table.remove(queue, i); q.fn() else i = i + 1 end
        end
    end
    -- the scan itself is stubbed (no real recipe reading); the refreshes are counted
    Stub(Scan, "UpdateProfessions", function() end)
    Stub(Scan, "ScanTradeSkill", function() end)
    Stub(Scan, "PassiveCheck", function() end)
    local full, light = 0, 0
    Stub(UI, "Refresh", function() full = full + 1 end)
    if ns.Lifeline then Stub(ns.Lifeline, "RefreshBlizzard", function() end) end
    if ns.Disenchant then Stub(ns.Disenchant, "CheckAsk", function() end) end
    Stub(UI, "PanelVisible", function() return false end)
    Stub(UI, "RequestRefresh", function() light = light + 1 end)
    -- window opens: one full refresh
    Scan.OnEvent("TRADE_SKILL_SHOW")
    now = now + 0.6; fire(now)
    local afterShow = full
    a:Ok(afterShow == 1, "Öffnen: " .. afterShow .. " volle Neuaufbauten")
    -- 100 list events over 50 s (the game sends them again after every read), nothing changes
    for k = 1, 100 do
        now = now + 0.5
        Scan.OnEvent("TRADE_SKILL_LIST_UPDATE")
        fire(now)
    end
    now = now + 2; fire(now)
    a:Ok(full == afterShow, "Sturm ohne Änderung: " .. (full - afterShow) .. " volle Neuaufbauten")
    a:Ok(light == 0, "verborgenes Panel neu gezeichnet: " .. light)
    a:Ok((Scan.ignored or 0) > 0, "Ereignisse direkt nach dem eigenen Scan nicht verworfen")
    -- a real change (skill up) still refreshes fully
    Scan.OnEvent("CHAT_MSG_SKILL")
    now = now + 0.6; fire(now)
    a:Ok(full == afterShow + 1, "Skillpunkt löst keinen Neuaufbau aus")
    -- UI side: list events never rebuild a hidden panel
    Stub(UI, "RequestRefresh", function() light = light + 1 end)
    light = 0
    UI.OnProfessionEvent("TRADE_SKILL_LIST_UPDATE")
    a:Ok(light == 0, "Listen-Ereignis baut verborgenes Panel neu")
    return a:Result("Prüfungen")
end)

---------------------------------------------------------------------------
-- K. Oberfläche im echten Client (UICheck.lua, aus der Vorlage): nur lesen, nichts verändern.
-- Ohne echten Client (Rechtecke, Tooltip) ehrlich übersprungen, nie als OK gezählt.
---------------------------------------------------------------------------
local function UICase(id, name, fn, always, needPanel)
    Case(id, "K", name, {}, function()
        local U = ns.UICheck
        if not U then return false, "UICheck.lua fehlt", "UICheck geladen" end
        if not always and not U.Available() then return SKIP("nur im echten Client (Fenster, Rechtecke, Tooltip)") end
        if needPanel and not (ns.UI and ns.UI.PanelVisible and ns.UI.PanelVisible()) then
            return SKIP("HALB: Berufsfenster und ProfessionSentinel-Panel öffnen, dann /ps testroutine k")
        end
        local problems, tested, hints = fn(U)
        local info = (#problems == 0 and "keine" or table.concat(problems, "; ")) .. " · geprüft " .. tostring(tested)
            .. (hints and #hints > 0 and (" · Hinweise: " .. table.concat(hints, "; ")) or "")
        if (tested or 0) == 0 and #problems == 0 then return SKIP("nicht automatisiert – nichts zu prüfen (" .. info .. ")") end
        return #problems == 0, info, "keine"
    end)
end

UICase("T206", "Eigene Tooltips verdecken keine Knöpfe", function(U) return U.TooltipsCoverNothing() end, false, true)
UICase("T207", "Kein Überlappen mit Berufsfenster, AHSentinel und anderen GoldSentinel-Fenstern", function(U)
    local problems, tested = U.WindowsOverlapNothing()
    -- AHSentinel's profit window (CraftPanel) – also when AHSentinel does not register it
    local dock = ns.UI and ns.UI.GetAHSDockFrame and ns.UI.GetAHSDockFrame()
    local p = ns.UI and ns.UI.PanelFrame and ns.UI.PanelFrame()
    if dock and p and p:IsVisible() then
        tested = tested + 1
        if U.Overlap(U.Rect(p), U.Rect(dock)) > 0 then problems[#problems + 1] = "Panel überdeckt das AHSentinel-Gewinn-Fenster" end
    end
    return problems, tested
end, false, true)
UICase("T208", "Fenster ganz im Bildschirm", function(U) return U.InsideScreen() end, false, true)
UICase("T209", "Beschriftungen von Knöpfen nicht abgeschnitten", function(U) return U.TextFits() end, false, true)
UICase("T210", "Angezeigte Spielwerte plausibel (Fertigkeit > 0, Plan beginnt bei der Fertigkeit)", function(U) return U.ValuesPlausible() end, true)
UICase("T211", "Keine Fehlerschleife (gleiche Meldung > 10×)", function(U) return U.NoErrorLoops() end, true)

---------------------------------------------------------------------------
-- C. WoW Forever special cases (simulated, run on every client)
---------------------------------------------------------------------------
-- (1) protected values
Case("T94", "C", "Gelerntes Rezept mit geschütztem Argument", {}, function()
    local st = SecretMode()
    local f = ns.Scan.frame
    if not f then return false, "Scan-Frame fehlt" end
    Stub(ns.Disenchant, "CheckAsk", function() end)
    local c = ns.Char()
    local before = Count(c and c.known)
    local ok, err = pcall(f:GetScript("OnEvent"), f, "NEW_RECIPE_LEARNED", SECRET)
    local after = Count(ns.Char() and ns.Char().known)
    return ok and before == after and st.asked > 0, ok and ("known " .. before .. " -> " .. after .. ", IsSecret gefragt ×" .. st.asked) or ("Lua: " .. tostring(err)), "kein Fehler, unverändert, gefragt"
end)

Case("T95", "C", "Tooltip mit geschützter Item-ID", {}, function()
    SecretMode()
    GameTooltip:SetOwner(UIParent, "ANCHOR_NONE")
    local n0 = GameTooltip:NumLines()
    local ok1, id = pcall(ns.TooltipItemID, GameTooltip, { id = SECRET })
    local ok2, err = pcall(ns.TooltipAddLines, GameTooltip, SECRET)
    local n1 = GameTooltip:NumLines()
    GameTooltip:Hide()
    return ok1 and ok2 and id == nil and n0 == n1, (ok1 and ok2) and ("ID " .. tostring(id) .. ", Zeilen " .. n0 .. " -> " .. n1) or ("Lua: " .. tostring(err)), "nil, keine Zeilen"
end)

Case("T96", "C", "Eigener Name und Fraktion im Kampf", {}, function()
    SecretMode()
    local key, name = ns.CharKey(), ns.PlayerName()
    local ok, k2 = pcall(ns.CharKeyFrom, SECRET, GetRealmName and GetRealmName() or "")
    local same = ok and k2 == key and ns.PlayerName() == name
    return same, ok and ("Schlüssel " .. (k2 == key and "gleich" or "anders")) or ("Lua: " .. tostring(k2)), "gleicher Schlüssel"
end)

Case("T97", "C", "Kunde mit geschütztem Ziel-Namen", {}, function()
    SecretMode()
    local DE = ns.Disenchant
    local ok, who = pcall(DE.CustomerFrom, nil, SECRET, nil, nil)
    local out = Capture()
    Stub(DE, "Customer", function() return DE.CustomerFrom(nil, SECRET, nil, nil) end)
    local r = FirstRecipe(function(x) return x.ench end) or ns.Recipes[1]
    local ok2, sent = pcall(Orig("Disenchant", "WhisperOffer"), r)
    return ok and who == nil and ok2 and sent == false and Has(out, L.VZ_NO_CUSTOMER), "Kunde " .. tostring(who) .. ", gesendet " .. tostring(sent), "nil, VZ_NO_CUSTOMER"
end)

Case("T98", "C", "Gildenliste mit geschütztem Namen", {}, function()
    SecretMode()
    local cache = {}
    local ok, added = pcall(ns.Guild.AddOnline, cache, SECRET, true)
    return ok and added == false and next(cache) == nil, ok and ("übernommen " .. tostring(added)) or ("Lua: " .. tostring(added)), "übersprungen"
end)

Case("T99", "C", "Chat-Ereignis mit geschütztem Argument", {}, function()
    SecretMode()
    Stub(ns.Disenchant, "CheckAsk", function() end)
    local f = ns.Scan.frame
    if not f then return false, "Scan-Frame fehlt" end
    local ok, err = pcall(f:GetScript("OnEvent"), f, "CHAT_MSG_SKILL", SECRET)
    return ok, ok and "kein Fehler" or ("Lua: " .. tostring(err))
end)

-- (2) missing old functions [api]: only entries of the addon's own table ns.API are switched off (the addon
-- calls the Blizzard API only through ns.API). Blizzard globals and C_ tables are never replaced (taint).
local function Without(names)
    for _, n in ipairs(names) do Stub(ns.API, n, nil, "ns.API." .. n) end
end

Case("T100", "C", "GetItemInfo fehlt [api]", { api = true }, function()
    if not ns.API.ItemGetItemInfo then return SKIP("kein C_Item.GetItemInfo in diesem Client") end
    local P, DE = ns.Prices, ns.Disenchant
    SetSim({ enchanter = true, goal = "gold" })
    local before = { fee = P.FeePerPiece(2318), sell = P.VendorSell(4239), name = ns.ItemName(2318),
        link = ns.GetItemLink(2318), prior = DE.Prior(4239) and true or false }
    Without({ "GetItemInfo" })
    local a = NewAgg()
    a:Ok(P.FeePerPiece(2318) == before.fee, "FeePerPiece")
    a:Ok(P.VendorSell(4239) == before.sell, "VendorSell")
    a:Ok((DE.Prior(4239) and true or false) == before.prior, "DE.Prior")
    a:Ok(ns.ItemName(2318) == before.name, "ItemName")
    a:Ok(ns.GetItemLink(2318) == before.link, "GetItemLink (Shift-Klick)")
    a:Ok(ns.ItemInfo(2318) ~= nil, "ns.ItemInfo")
    return a:Result("Pfade")
end)

Case("T101", "C", "Symbol- und Zählfunktionen fehlen [api]", { api = true }, function()
    local before = { icon = ns.GetItemIcon(2318), spell = ns.GetSpellIcon(2158), count = ns.GetItemCount(2318), bag = ns.Favor.BagCount(2318) }
    Without({ "GetItemIcon", "GetSpellTexture", "GetItemCount" })
    local a = NewAgg()
    a:Ok(ns.GetItemIcon(2318) == before.icon, "GetItemIcon")
    a:Ok(ns.GetSpellIcon(2158) == before.spell, "GetSpellIcon")
    a:Ok(ns.GetItemCount(2318) == before.count, "GetItemCount")
    a:Ok(ns.Favor.BagCount(2318) == before.bag, "BagCount")
    return a:Result("Funktionen")
end)

Case("T102", "C", "Taschen-Funktionen fehlen [api]", { api = true }, function()
    local AL = ns.Alerts
    local n0 = #AL.BagRecipes()
    Without({ "GetContainerNumSlots", "GetContainerItemID" })
    local n1 = #AL.BagRecipes()
    Without({ "ContainerGetContainerNumSlots", "ContainerGetContainerItemID" })
    local ok, list = pcall(AL.BagRecipes)
    return n1 == n0 and ok and #list == 0, "vorher " .. n0 .. ", nur C_Container " .. n1 .. ", ganz ohne " .. tostring(ok and #list), "gleich / 0"
end)

Case("T103", "C", "Alte Berufe-API fehlt [api]", { api = true }, function()
    Without({ "GetTradeSkillLine", "GetTradeSkillInfo", "GetNumTradeSkills", "GetTradeSkillRecipeLink", "GetNumCrafts",
        "GetCraftInfo", "GetCraftDisplaySkillLine", "DoTradeSkill" })
    local a = NewAgg()
    a:Ok(pcall(ns.Scan.ScanTradeSkill, ns.Scan), "ScanTradeSkill")
    a:Ok(pcall(ns.Lifeline.RefreshBlizzard), "RefreshBlizzard")
    local out = Capture()
    local r = FirstRecipe(function(x) return x.out ~= nil end, LWProf())
    Stub(ns.Today, "OpenProfession", function() return r.prof end)
    Stub(ns, "UsesModernProfessions", false)
    local ok, res = pcall(Orig("Today", "Craft"), { recipe = r, count = 1 })
    a:Ok(ok and res == false and Has(out, L.TODAY_NOT_FOUND), "TD.Craft ohne TODAY_NOT_FOUND")
    return a:Result("Pfade")
end)

Case("T104", "C", "Berufsliste fehlt [api]", { api = true }, function()
    local c = ns.Char()
    if not c then return false, "kein Charakter" end
    local before = DeepCopy(c.profs)
    Without({ "GetProfessions", "GetProfessionInfo", "GetNumSkillLines", "GetSkillLineInfo" })
    local ok, err = pcall(ns.Scan.UpdateProfessions, ns.Scan)
    local same = Diff(before, ns.Char().profs) == nil
    return ok and same, ok and (same and "Berufe erhalten" or "Berufe verändert") or ("Lua: " .. tostring(err)), "kein Fehler, erhalten"
end)

Case("T105", "C", "C_TradeSkillUI unvollständig [api]", { api = true }, function()
    if not ns.UsesModernProfessions or not ns.API.TradeSkillGetAllRecipeIDs then return SKIP("C_TradeSkillUI wird hier nicht benutzt") end
    if ActiveHost() then return SKIP("Berufsfenster offen") end
    Without({ "TradeSkillGetChildProfessionInfo", "TradeSkillGetBaseProfessionInfo", "TradeSkillGetRecipeInfo" })
    SetSim(nil)
    local a = NewAgg()
    local ok, prof = pcall(ns.UI.CurrentProfession)
    a:Ok(ok and prof == nil, "CurrentProfession " .. tostring(prof))
    a:Ok(pcall(ns.Scan.ScanTradeSkill, ns.Scan), "ScanTradeSkill")
    a:Ok(pcall(ns.Lifeline.RefreshBlizzard), "RefreshBlizzard")
    return a:Result("Pfade")
end)

Case("T106", "C", "Währungs-API fehlt [api]", { api = true }, function()
    local sk = (not ns.IsForever) and SKIP("nur WoW Forever"); if sk then return sk end
    local FV = ns.Favor
    local ri = FavorItem()
    Without({ "CurrencyGetCurrencyInfo", "CurrencyGetCurrencyListSize", "CurrencyGetCurrencyListInfo" })
    TestDB({})
    Stub(_G, "AHAnalyzerPro", nil)
    local a = NewAgg()
    a:Ok(FV.Balance() == nil, "Balance nicht nil")
    local t = ri and FV.CostText(ri) or ""
    a:Ok(not t:find("|cff40c040(", 1, true) and not t:find("|cffff6060(", 1, true), "„du hast“ ohne Stand")
    OpenPanel(LWProf(), "favor")
    local found = false
    for _, s in ipairs(PanelTexts()) do if s:find(Plain(L.FAVOR_BALANCE_UNKNOWN), 1, true) then found = true end end
    for _, d in ipairs(ViewData()) do if type(d.detail) == "string" and Plain(d.detail):find(Plain(L.FAVOR_BALANCE_UNKNOWN), 1, true) then found = true end end
    a:Ok(found, "Planer ohne FAVOR_BALANCE_UNKNOWN")
    ns.UI:Hide()
    return a:Result("Prüfungen")
end)

Case("T107", "C", "Addon-Info-Funktionen fehlen [api]", { api = true }, function()
    if not ns.API.AddOnsGetAddOnMetadata then return SKIP("kein C_AddOns in diesem Client") end
    Without({ "GetAddOnMetadata", "IsAddOnLoaded", "GetAddOnMemoryUsage" })
    local v = Meta("Version")
    return v == ns.VERSION, "Version " .. tostring(v), ns.VERSION
end)

Case("T108", "C", "Alter Tooltip-Weg", {}, function()
    return SKIP("nur im alten Client prüfbar – siehe T120")
end)

-- (3) combat lock: GoldSentinelGame.InCombat -> true
Case("T109", "C", "Start im Kampf verweigert", {}, function()
    Stub(G(), "InCombat", function() return true end)
    local out = Capture()
    local before = #runs
    TR:Command("")
    ns.AutoTest:Command("")
    return #runs == before and Times(out, L.TR_COMBAT) == 2, "Hinweis ×" .. Times(out, L.TR_COMBAT) .. ", Läufe " .. (#runs - before), "2× verweigert"
end)

Case("T110", "C", "Kampfbeginn bricht ab", {}, function()
    local a = NewAgg()
    local localeBefore = Plain(L.TITLE) .. Plain(L.SEARCH)
    local sub = TR:RunSub({ filter = "F" }, function(r, step) if step == 1 then TR.OnCombat() end end)
    a:Ok(sub and sub.aborted ~= nil, "nicht abgebrochen")
    a:Ok(sub and sub.report and sub.report.counts.uebersprungen >= 1, "Rest nicht übersprungen")
    a:Ok(sub and sub.sandboxOK, "Sandbox: " .. tostring(sub and sub.sandboxText))
    a:Ok(sub and #sub.stack == 0, "Rückbau-Stapel nicht leer")
    a:Ok(Plain(L.TITLE) .. Plain(L.SEARCH) == localeBefore, "Sprache nicht zurück")
    return a:Result("Prüfungen")
end)

Case("T111", "C", "Keine Aktionen im Kampf", {}, function()
    Stub(G(), "InCombat", function() return true end)
    local out = Capture()
    local g0 = GuardTotal()
    local a = NewAgg()
    local r = FirstRecipe(function(x) return x.out ~= nil end, LWProf())
    Stub(ns.Plan, "current", { list = { { id = 2320, missing = 1, origin = "vendor" } } })
    a:Ok(ns.Today.Run({ recipe = r, count = 1, missing = {} }) == false, "TD.Run")
    a:Ok(Orig("Plan", "BuyFromVendor")() == 0, "BuyFromVendor")
    a:Ok(Orig("Disenchant", "WhisperOffer")(r, "Test") == false, "WhisperOffer")
    a:Ok(Orig("Disenchant", "SendToSniper")({ { id = 1, maxPrice = 1, qty = 1 } }) == 0, "SendToSniper")
    local npc = ns.Trainers and ns.Trainers[165] and ns.Trainers[165][1] and ns.Trainers[165][1][1]
    if npc then a:Ok(Orig("Waypoint", "Set")(npc) == false, "WP.Set") end
    a:Ok(Times(out, L.NOT_IN_COMBAT) >= 4, "Hinweis NOT_IN_COMBAT ×" .. Times(out, L.NOT_IN_COMBAT))
    a:Ok(GuardTotal() == g0, "Wächter haben gezählt")
    return a:Result("Aktionen")
end)

Case("T112", "C", "Keine geschützten Frames", {}, function()
    local a = NewAgg()
    local n = 0
    for _, name in ipairs({ "ProfessionSentinelPanel", "ProfessionSentinelTestMode", "ProfessionSentinelGoalFrame", "ProfessionSentinelAutoTestReport",
        "ProfessionSentinelMinimapButton" }) do
        local f = _G[name]
        if f and f.IsProtected then
            n = n + 1
            a:Ok(not f:IsProtected(), name .. " geschützt")
        end
    end
    local ok, res = a:Result("Frames")
    return ok, res .. " (" .. n .. " vorhanden, keine Secure-Vorlage im Addon)"
end)

Case("T113", "C", "Panel und Tooltip im echten Kampf", {}, function()
    if Confirmed("T113") then return true, "bestätigt " .. tostring(Confirmed("T113").date) end
    return CLIENT("Panel offen und Rezept in den Taschen überfahren, dann einen Kampf beginnen und Tooltips ansehen: kein Lua-Fehler, kein ADDON_ACTION_BLOCKED")
end)

-- (4) combat log
Case("T114", "C", "Kampflog nicht registriert", {}, function()
    for _, e in ipairs(ns.EventFrames) do
        if e.frame:IsEventRegistered("COMBAT_LOG_EVENT_UNFILTERED") then return false, e.label .. " hat das Kampflog", "keiner" end
    end
    return true, #ns.EventFrames .. " Frames ohne Kampflog"
end)

---------------------------------------------------------------------------
-- D. Old clients (the same routine in the Era client; TBC only stays idle)
---------------------------------------------------------------------------
local function OnlyEra() if not ns.IsEra then return SKIP("nur Classic Era") end end

Case("T115", "D", "Berufe auf dem alten Weg", {}, function()
    local sk = OnlyEra(); if sk then return sk end
    local host = ActiveHost()
    if not host then
        if Confirmed("T115") then return true, "bestätigt " .. tostring(Confirmed("T115").date) end
        return CLIENT("Handwerksfenster und Verzauberkunst-Fenster öffnen, dann /ps testroutine d")
    end
    local c = ns.Char()
    local n0 = Count(c and c.known)
    local ok = pcall(ns.Scan.ScanTradeSkill, ns.Scan)
    SetSim(nil)
    ns.UI:Show(host)
    local prof, rank = ns.UI.CurrentProfession()
    return ok and Count(ns.Char().known) >= n0 and prof ~= nil and rank ~= nil,
        "Beruf " .. tostring(prof and ns.ProfName(prof)) .. " Rang " .. tostring(rank), "Beruf und Rang erkannt"
end)

local function MerchantInfoOrder()
    local calls = {}
    Stub(ns.API, "GetMerchantItemInfo", function() calls[#calls + 1] = "alt"; return "X", 0, 10, 1, -1 end)
    Stub(ns.API, "MerchantGetItemInfo", function()
        calls[#calls + 1] = "neu"; return { name = "X", price = 10, stackCount = 1, numAvailable = -1 }
    end)
    local _, _, price = ns.Plan.MerchantItemInfo(1)
    return table.concat(calls, ","), price
end

Case("T116", "D", "Händlerweg alt [api]", { api = true }, function()
    local sk = OnlyEra(); if sk then return sk end
    local calls, price = MerchantInfoOrder()
    return calls == "alt" and price == 10, "gerufen: " .. calls, "nur GetMerchantItemInfo"
end)

Case("T117", "D", "Händlergunst und Gebühr aus", {}, function()
    local sk = OnlyEra(); if sk then return sk end
    local a = NewAgg()
    a:Ok(not ns.Favor.Active(), "Favor.Active")
    OpenPanel(LWProf(), "recipes")
    local tab = TabFor(L.FAVOR_TAB)
    a:Ok(not (tab and tab:IsShown()), "Reiter Gunst sichtbar")
    ns.UI:Hide()
    local out = Capture()
    SlashCmdList.PROFESSIONSENTINEL("kisten")
    a:Ok(Has(out, L.FAVOR_ONLY_FOREVER), "/ps kisten ohne Hinweis")
    a:Ok(ns.Prices.FeePerPiece(2318) == 0, "Einstellgebühr")
    return a:Result("Prüfungen")
end)

local function TabLayout()
    OpenPanel(LWProf(), "recipes", { enchanter = true })
    local out = {}
    for _, t in ipairs(Tabs()) do
        out[#out + 1] = { tab = t, w = t:GetWidth(), n = t.GetNumPoints and t:GetNumPoints() or 1, shown = t:IsShown(),
            rel = select(2, t:GetPoint(1)) }
    end
    ns.UI:Hide()
    return out
end

Case("T118", "D", "Reiter-Layout wie früher", {}, function()
    if ns.IsForever then return SKIP("nur Classic Era / Retail") end
    local a = NewAgg()
    local list = TabLayout()
    a:Ok(#list >= 5, "Reiter " .. #list)
    for i, t in ipairs(list) do
        a:Ok(math.abs((t.w or 0) - 76) < 0.5, "Breite " .. tostring(t.w))
        a:Ok(t.n == 1, "Anker " .. tostring(t.n))
        if i == 1 then a:Ok(t.rel == Panel(), "erster Reiter nicht am Panel") end
    end
    return a:Result("Prüfungen")
end)

Case("T119", "D", "Lebenslinie im Blizzard-Fenster alt", {}, function()
    local sk = OnlyEra(); if sk then return sk end
    if not (TradeSkillFrame and TradeSkillFrame:IsShown()) and not (CraftFrame and CraftFrame:IsShown()) then
        if Confirmed("T119") then return true, "bestätigt " .. tostring(Confirmed("T119").date) end
        return CLIENT("Handwerksfenster öffnen, dann /ps testroutine d")
    end
    ns.Lifeline.RefreshBlizzard()
    local n = 0
    for i = 1, 30 do
        local b = _G["TradeSkillSkill" .. i] or _G["Craft" .. i]
        if b and b:IsShown() and b.psLine then n = n + 1 end
    end
    return n > 0, n .. " Zeilen mit Lebenslinie", "> 0"
end)

Case("T120", "D", "Tooltip-Weg im alten Client", {}, function()
    local sk = OnlyEra(); if sk then return sk end
    local r, id = TooltipRecipe()
    SetDB("tooltip", false)
    local base = #ItemTooltip(id)
    if base == 0 then return SKIP("Item " .. id .. " nicht im Cache") end
    SetDB("tooltip", true)
    local lines = ItemTooltip(id)
    local n = LinesWith(lines, PS_TAG)
    local hook = (TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall) and "TooltipDataProcessor" or "OnTooltipSetItem"
    return n == 1 and #lines > base, hook .. ": " .. n .. "× ProfessionSentinel-Zeile", "genau 1"
end)

Case("T121", "D", "TBC bleibt untätig", {}, function()
    return SKIP("kein TBC-Client in diesem Lauf (simuliert in T10/T172)")
end)

Case("T122", "D", "Retail-Eigenheiten", {}, function()
    if not ns.IsRetail then return SKIP("nur Retail") end
    local a = NewAgg()
    local mid = ns.ProfById[2915]
    a:Ok(mid and mid.parent == 165 and #(ns.ByProf[2915] or {}) > 10, "Erweiterungslinie 2915")
    OpenPanel(2915, "trainers")
    a:Ok(not PanelTitle():find(Plain(L.TRAINERS), 1, true), "Modus trainers nicht auf recipes")
    local tab = TabFor(L.TRAINERS)
    a:Ok(not (tab and tab:IsShown()), "Lehrer-Reiter sichtbar")
    ns.UI:Hide()
    SetSim({ enchanter = true })
    a:Ok(ns.Disenchant.Goal() == "sell", "Ziel nicht sell")
    SetSim(nil)
    local r = ns.ByProf[2915] and ns.ByProf[2915][1]
    if r then
        ns.UI:ShowRecipeTooltip(UIParent, r, 10)
        local lines = TooltipLines()
        GameTooltip:Hide()
        a:Ok(LinesWith(lines, L.SRC_RETAIL) >= 1 or #r.recipeItems == 0, "SRC_RETAIL fehlt")
    end
    return a:Result("Prüfungen")
end)

---------------------------------------------------------------------------
-- E. Saved data
---------------------------------------------------------------------------
local function BuildViews(a, label)
    for _, mode in ipairs(Modes()) do
        local ok, err = pcall(OpenPanel, LWProf(), mode, { enchanter = mode == "disenchant" or nil })
        a:Ok(ok, label .. "/" .. mode .. ": " .. tostring(err))
    end
    ns.UI:Hide()
end

Case("T123", "E", "Neuinstallation", {}, function()
    local a = NewAgg()
    local db = ns.InitDB({})
    for k, v in pairs(ns.DEFAULTS) do
        a:Ok(db[k] ~= nil and type(db[k]) == type(v), "Standard " .. k)
    end
    local c = ns.InitChar(db, "Test-Realm")
    a:Ok(type(c.known) == "table" and type(c.profs) == "table", "InitChar")
    TestDB({})
    BuildViews(a, "neu")
    a:Ok(pcall(ItemTooltip, 2318), "Tooltip")
    a:Ok(pcall(ns.Favor.Plan), "F.Plan")
    a:Ok(pcall(ns.Alerts.Needed), "AL.Needed")
    return a:Result("Prüfungen")
end)

Case("T124", "E", "Migration aus 0.8.x", {}, function()
    local a = NewAgg()
    local key = ns.CharKey()
    local db = TestDB({ tooltip = true, lifeline = false, filters = { missing = true }, collapsed = { ["Leder"] = true },
        chars = { [key] = { known = { [2158] = true }, profs = { [165] = { rank = 80, max = 150 } } } } })
    a:Ok(db.lifeline == false, "lifeline überschrieben")
    a:Ok(db.todayCrates == false, "todayCrates")
    a:Ok(db.deMargin == 20, "deMargin")
    local f = ns.Favor.DB()
    a:Ok(type(f.costs) == "table" and type(f.wish) == "table" and type(f.goals) == "table", "F.DB legt nicht an")
    db.chars[key].flavor = nil
    a:Ok(next(ns.Alerts.Needed()) ~= nil or ns.ByProf[165] == nil, "alter Charakter ohne flavor zählt nicht")
    local kb = ns.Scan:CharsFor(2158, 165)
    a:Ok(#kb >= 1 or not ns.BySpell[2158], "CharsFor ohne flavor")
    return a:Result("Prüfungen")
end)

Case("T125", "E", "Migration aus 0.9.2 (Favor ohne Wunschliste)", {}, function()
    local sk = (not ns.IsForever) and SKIP("nur WoW Forever"); if sk then return sk end
    TestDB({ favor = { costs = { [250364] = { n = 150, c = "Merchant's Favor" } } } })
    local f = ns.Favor.DB()
    local ri = FavorItem()
    local c = ri and ns.Favor.Cost(ri)
    return type(f.wish) == "table" and type(f.goals) == "table" and c and c.n == 150 and c.learned,
        "wish/goals " .. tostring(type(f.wish)) .. ", Kosten " .. tostring(c and c.n), "ergänzt, 150 gelernt"
end)

Case("T126", "E", "Beschädigte Einträge", {}, function()
    local a = NewAgg()
    local key = ns.CharKey()
    local broken = { filters = "x", collapsed = 5, chars = { ["A-B"] = 7, ["C-D"] = { known = "x", profs = 3 }, [key] = { known = {}, profs = { [165] = "kaputt" } } },
        favor = { costs = { [250364] = 5 }, wish = "x" }, planTarget = { [165] = "abc" }, vzMarkup = "20", deMargin = -5,
        autotest = { history = "x" } }
    local ok, err = pcall(TestDB, broken)
    a:Ok(ok, "InitDB: " .. tostring(err))
    if not ok then return a:Result("Prüfungen") end
    for _, fn in ipairs({
        { "AL.Needed", function() return ns.Alerts.Needed() end },
        { "Scan:CharsFor", function() return ns.Scan:CharsFor(2158, 165) end },
        { "F.Cost", function() return ns.Favor.Cost({ id = 250364, fv = 180 }) end },
        { "F.Plan", function() return ns.Favor.Plan() end },
        { "PL.Target", function() return ns.Plan.Target(165, 80, 150) end },
        { "DE.SellPrice", function() return ns.Disenchant.SellPrice(1000) end },
        { "DE.Margin", function() return ns.Disenchant.Margin() end },
        { "AT:History", function() Capture(); return ns.AutoTest:History() end },
    }) do
        local okF, e2 = pcall(fn[2])
        a:Ok(okF, fn[1] .. ": " .. tostring(e2))
    end
    a:Ok(ns.Disenchant.Margin() == 0.2, "deMargin -5 nicht verworfen")
    a:Ok(ns.db.vzMarkup == 20, "vzMarkup „20“ nicht als Zahl")
    a:Ok(ns.db.chars["A-B"] == nil, "kaputter Charakter nicht verworfen")
    BuildViews(a, "kaputt")
    return a:Result("Prüfungen")
end)

Case("T127", "E", "Gelernte Kosten mit Zeitstempel", {}, function()
    local sk = (not ns.IsForever) and SKIP("nur WoW Forever"); if sk then return sk end
    local a = NewAgg()
    for _, t in ipairs({ false, 0, time() + 86400 * 365 }) do
        TestDB({ favor = { costs = { [250364] = { n = 140, c = "Merchant's Favor", t = t or nil } } } })
        local ok, c = pcall(ns.Favor.Cost, { id = 250364, fv = 180 })
        a:Ok(ok and c and c.n == 140, "t=" .. tostring(t))
    end
    return a:Result("Zeitstempel")
end)

---------------------------------------------------------------------------
-- F. Languages (EN default + deDE)
---------------------------------------------------------------------------
local DYNAMIC_KEYS = { "GOAL_GOLD", "GOAL_SELL", "GOAL_BOTH", "GOAL_GOLD_TIP", "GOAL_SELL_TIP", "GOAL_BOTH_TIP",
    "LL_YELLOW", "LL_GREEN", "LL_GREY", "FAVOR_GOAL_KODO", "FAVOR_GOAL_MULE", "FAVOR_GOAL_CERT", "FAVOR_GOAL_TABARD",
    "FAVOR_GOAL_KODO_NEED", "FAVOR_GOAL_MULE_NEED", "FAVOR_GOAL_CERT_NEED", "FAVOR_GOAL_TABARD_NEED",
    "CD_TRANSMUTE", "CD_MOONCLOTH", "CD_SALTSHAKER" }
for i = 1, 8 do DYNAMIC_KEYS[#DYNAMIC_KEYS + 1] = "REP_" .. i end
for i = 0, 5 do DYNAMIC_KEYS[#DYNAMIC_KEYS + 1] = "RANK_" .. i end

Case("T128", "F", "Alle benutzten Schlüssel vorhanden", {}, function()
    local missing = {}
    local n = 0
    for _, list in ipairs({ TR.KEYS_USED or {}, DYNAMIC_KEYS }) do
        for _, k in ipairs(list) do
            n = n + 1
            if L[k] == nil then missing[#missing + 1] = k end
        end
    end
    return #missing == 0, n .. " Schlüssel, fehlend " .. #missing .. (missing[1] and (": " .. table.concat(missing, ", ", 1, math.min(5, #missing))) or ""), "0 fehlend"
end)

local function Placeholders(s)
    local out = {}
    for p in tostring(s):gmatch("%%[%d%.]*[sdf]") do out[#out + 1] = p:sub(-1) end
    return table.concat(out)
end

Case("T129", "F", "Platzhalter gleich", {}, function()
    local bad, first, n = 0, nil, 0
    local de = {}
    for k, v in pairs(ns.L_EN) do de[k] = v end
    ns.ApplyGerman(de)
    for k, en in pairs(ns.L_EN) do
        if type(en) == "string" then
            n = n + 1
            local d = de[k]
            if type(d) == "string" and Placeholders(d) ~= Placeholders(en) then bad = bad + 1; first = first or k end
            for _, s in ipairs({ en, d }) do
                -- only real format strings (a "%" in plain text such as "in % (e.g. 20)" is never formatted)
                local rest = type(s) == "string" and s:gsub("%%%%", ""):gsub("%%[%d%.]*[sdf]", "") or ""
                if type(s) == "string" and Placeholders(s) ~= "" and not rest:find("%%") then
                    local args = {}
                    for c in Placeholders(s):gmatch(".") do args[#args + 1] = (c == "s") and "x" or 1 end
                    local ok = pcall(string.format, s, unpack(args))
                    if not ok then bad = bad + 1; first = first or k end
                end
            end
        end
    end
    return bad == 0, n .. " Schlüssel, " .. bad .. " Abweichungen" .. (first and (": " .. first) or ""), "0"
end)

Case("T130", "F", "Jede Sprache einmal aktiv", {}, function()
    local a = NewAgg()
    for _, loc in ipairs({ "enUS", "deDE" }) do
        local restore = ns.SwapLocaleForTest(loc)
        OnUndo(restore, "Sprache " .. loc)
        local ok, err = pcall(function()
            BuildViews(a, loc)
            OpenPanel(LWProf(), "recipes")
            a:Ok(PanelTitle() ~= "", loc .. ": Titel leer")
            ns.UI:Hide()
            local TM = ns.TestMode
            local w = _G.ProfessionSentinelTestMode
            local was = w and w:IsShown()
            TM:Toggle(); TM:Toggle()
            w = _G.ProfessionSentinelTestMode
            if w and w:IsShown() ~= was then w:SetShown(was) end
            Capture()
            Orig("Disenchant", "AskGoal")()
            local g = _G.ProfessionSentinelGoalFrame
            if g then g:Hide() end
            if ns.AutoTest.ShowReport then
                ns.AutoTest.ShowReport("Test " .. loc, L.TR_REPORT_TITLE, L.TR_REPORT_HINT)
                local rw = _G.ProfessionSentinelAutoTestReport
                if rw then rw:Hide() end
            end
        end)
        a:Ok(ok, loc .. ": " .. tostring(err))
        restore()
    end
    return a:Result("Prüfungen")
end)

---------------------------------------------------------------------------
-- G. Other addons
---------------------------------------------------------------------------
Case("T131", "G", "Gemeinsame Dateien", {}, function()
    local a = NewAgg()
    local GT = _G.GoldSentinelTest
    a:Ok(G() and G().version == 2, "GoldSentinelGame.version")
    a:Ok(_G.GoldSentinelDev and _G.GoldSentinelDev.version == 1, "GoldSentinelDev.version")
    a:Ok(GT and (GT.version or 0) >= 1, "GoldSentinelTest.version")
    a:Ok(GT and GT.registry[ADDON] and rawequal(GT.registry[ADDON].db, ProfessionSentinelDB), "registry.db ≠ ProfessionSentinelDB")
    local others = {}
    local isLoaded = ns.API.AddOnsIsAddOnLoaded or ns.API.IsAddOnLoaded
    local get = ns.API.AddOnsGetAddOnMetadata or ns.API.GetAddOnMetadata
    for _, n in ipairs({ "RaidMaster", "AHSentinel", "GuildSentinel", "ThreatSentinel", "BuffSentinel", "LevelPilot" }) do
        local ok, loaded = pcall(isLoaded or function() return false end, n)
        if ok and loaded then
            local okV, v = pcall(get or function() end, n, "Version")
            others[#others + 1] = n .. " " .. tostring(okV and v or "?")
        end
    end
    local ok, res = a:Result("Prüfungen")
    return ok, res .. " · andere: " .. (#others > 0 and table.concat(others, ", ") or "keine")
end)

local ALLOWED_GLOBALS = { ProfessionSentinelDB = true, ProfessionSentinelAPI = true, SLASH_PROFESSIONSENTINEL1 = true,
    SLASH_PROFESSIONSENTINEL2 = true, ProfessionSentinelPanel = true, ProfessionSentinelTestMode = true,
    ProfessionSentinelGoalFrame = true, ProfessionSentinelAutoTestReport = true, ProfessionSentinelAutoTestScroll = true,
    ProfessionSentinelMinimapButton = true }

Case("T132", "G", "Keine globalen Namen überschrieben", {}, function()
    local a = NewAgg()
    local own = { L = ns.L, UI = ns.UI, TD = ns.Today, F = ns.Favor, P = ns.Prices, DE = ns.Disenchant, GU = ns.Guild,
        AL = ns.Alerts, PL = ns.Plan, LL = ns.Lifeline, WP = ns.Waypoint, AD = ns.Advisor, AT = ns.AutoTest, TM = ns.TestMode,
        Scan = ns.Scan, TR = ns.TestRoutine }
    for k, v in pairs(own) do a:Ok(not rawequal(rawget(_G, k), v), "_G." .. k .. " ist eine eigene Tabelle") end
    local extra = {}
    for k in pairs(_G) do
        if type(k) == "string" and (k:find("ProfessionSentinel", 1, true) or k:find("PROFESSIONSENTINEL", 1, true))
            and not ALLOWED_GLOBALS[k] then extra[#extra + 1] = k end
    end
    table.sort(extra)
    a:Ok(#extra == 0, "nicht erlaubt: " .. table.concat(extra, ", "))
    return a:Result("Prüfungen")
end)

Case("T133", "G", "Ohne AHSentinel", {}, function()
    local a = NewAgg()
    Stub(_G, "AHAnalyzerPro", nil); Stub(_G, "TSM_API", nil); Stub(_G, "Auctionator", nil)
    SetSim(nil)
    local P = ns.Prices
    a:Ok(P.AH(2318) == nil, "P.AH nicht nil")
    a:Ok(P.VendorBuy(2320) == 10, "VendorBuy aus den Daten")
    if ns.IsForever then
        local ri = FavorItem()
        local c = ri and ns.Favor.Cost(ri)
        a:Ok(c and not c.learned, "F.Cost nicht Guide")
    end
    a:Ok(ns.Disenchant.AHS() == nil, "DE.AHS")
    a:Ok(pcall(ns.Alerts.FromCurrent), "AL.FromCurrent")
    a:Ok(#ns.Today.Candidates() == 0, "TD.Candidates")
    local out = Capture()
    a:Ok(Orig("Disenchant", "SendToSniper")({ { id = 1, maxPrice = 1, qty = 1 } }) == 0 and Has(out, L.SNIPE_NEED_AHS), "SendToSniper")
    BuildViews(a, "ohne AHSentinel")
    return a:Result("Prüfungen")
end)

local function BrokenAHS()
    local function boom() error("AHSentinel-Testfehler (absichtlich)") end
    return { GetMarketValue = boom, GetVendorCost = boom, GetVendorBuyPrice = boom, GetCurrent = boom, On = boom,
        Disenchant = AHSDisenchant(true), Sniper = { SetTarget = boom },
        UI = { Show = boom, SelectTab = boom, GetTab = boom }, Today = { QuickBuy = boom, QuickSell = boom } }
end

Case("T134", "G", "Mit fehlerhaftem AHSentinel", { errors = true }, function()
    local a = NewAgg()
    Stub(_G, "AHAnalyzerPro", BrokenAHS())
    SetSim({ enchanter = true, goal = "gold" })
    Capture()
    Stub(ns.Alerts, "found", {})
    ns.Alerts.ResetCurrent()
    OnUndo(function() ns.Alerts.ResetCurrent() end)
    local r = FirstRecipe(function(x) return x.out ~= nil end, LWProf())
    for _, t in ipairs({
        { "P.AH", function() return ns.Prices.AH(2318) end },
        { "P.VendorBuy", function() return ns.Prices.VendorBuy(999999) end },
        { "F.Cost", function() return ns.Favor.Cost({ id = 250364, fv = 180 }) end },
        { "DE.Value", function() return ns.Disenchant.Value(4239) end },
        { "DE.IsDisenchantable", function() return ns.Disenchant.IsDisenchantable(4239) end },
        { "DE.Groups", function() return ns.Disenchant.Groups() end },
        { "DE.Totals", function() return ns.Disenchant.Totals() end },
        { "DE.Deals", function() return ns.Disenchant.Deals() end },
        { "AL.FromCurrent", function() return ns.Alerts.FromCurrent() end },
        { "SendToSniper", function() return Orig("Disenchant", "SendToSniper")({ { id = 1, maxPrice = 1, qty = 1 } }) end },
        { "TD.BuyAH", function() return Orig("Today", "BuyAH")({ recipe = r, missing = { { id = 2318, count = 1, origin = "ah", unit = 10 } } }) end },
        { "TD.Sell", function() return Orig("Today", "Sell")({ recipe = r, have = 1 }) end },
    }) do
        local ok, err = pcall(t[2])
        a:Ok(ok, t[1] .. ": " .. tostring(err))
    end
    BuildViews(a, "fehlerhaft")
    return a:Result("Aufrufe")
end)

Case("T135", "G", "Mit echtem AHSentinel", {}, function()
    local A = _G.AHAnalyzerPro
    if not A then return SKIP("AHSentinel nicht geladen") end
    local a = NewAgg()
    if A.GetMarketValue then
        local ok, v = pcall(A.GetMarketValue, A, 2318)
        a:Ok(ok and (v == nil or type(v) == "number"), "GetMarketValue")
    end
    if A.GetVendorCost then
        local ok, v = pcall(A.GetVendorCost, A, 250364)
        a:Ok(ok and (v == nil or (type(v) == "table" and type(v.costs) == "table")), "GetVendorCost")
    end
    a:Ok(type(A.On) == "function", "A.On fehlt")
    a:Ok(ns.Alerts.registered == true, "Rezept-Alarm nicht angemeldet")
    return a:Result("Prüfungen")
end)

Case("T136", "G", "GuildSentinel und RaidMaster mit/ohne", {}, function()
    local GU = ns.Guild
    local a = NewAgg()
    local r = FirstRecipe(function(x) return x.out ~= nil and x.recipeItems[1] ~= nil end, LWProf())
    Stub(_G, "RaidMaster", nil)
    Stub(GU, "GuildRecord", function() return nil end)
    GU.Invalidate()
    OnUndo(function() GU.Invalidate() end)
    a:Ok(GU.Available() == false and GU.Crafters(r) == nil, "ohne Daten")
    a:Ok(LinesWith(ItemTooltip(r.recipeItems[1].id), L.GUILD_CRAFTERS) == 0, "Gildenzeile ohne Daten")
    GuildStub({ ["Testa-Testrealm"] = GuildEntry(r, 1) })
    a:Ok(#(GU.Crafters(r) or {}) == 1, "gültiges Beispiel")
    GuildStub({ ["Testa-Testrealm"] = { t = 1, p = "x" }, ["Testb-Testrealm"] = { t = 1, p = { X = { n = "x", i = 5 } } },
        ["Testc-Testrealm"] = { t = 1, p = { X = { r = 1, n = { 5, r.name } } } } },
        { record = { prof = { ["Testd-Testrealm"] = "x" }, cds = { ["Teste-Testrealm"] = { k = "x" } } } })
    local ok, err = pcall(function() GU.Crafters(r); GU.Cooldowns(); GU.NobodyKnows(r.prof) end)
    a:Ok(ok, "kaputtes Beispiel: " .. tostring(err))
    return a:Result("Prüfungen")
end)

Case("T137", "G", "TSM, Auctionator, TomTom", {}, function()
    local P = ns.Prices
    local a = NewAgg()
    SetSim(nil)
    Stub(_G, "AHAnalyzerPro", nil)
    Stub(_G, "Auctionator", nil)
    Stub(_G, "TSM_API", { GetCustomPriceValue = function(src, key) return (src == "dbmarket" and key == "i:2318") and 77 or nil end })
    local v, s = P.AH(2318)
    a:Ok(v == 77 and s == "TSM", "TSM")
    Stub(_G, "TSM_API", nil)
    Stub(_G, "Auctionator", { API = { v1 = { GetAuctionPriceByItemID = function(caller, id) return caller == "ProfessionSentinel" and id == 2318 and 88 or nil end } } })
    v, s = P.AH(2318)
    a:Ok(v == 88 and s == "Auctionator", "Auctionator")
    Stub(_G, "TomTom", { AddWaypoint = function() return {} end })
    a:Ok(ns.Waypoint.Available() == "TomTom", "TomTom")
    return a:Result("Quellen")
end)

Case("T138", "G", "AHSentinel „Heute tun“ zeigt Herstellungen", {}, function()
    local A = _G.AHAnalyzerPro
    if not (A and A.Today) then return SKIP("AHSentinel ohne „Heute tun“ nicht geladen") end
    if Confirmed("T138") then return true, "bestätigt " .. tostring(Confirmed("T138").date) end
    return CLIENT("AHSentinel „Heute tun“ öffnen: Zeilen von ProfessionSentinel erscheinen dort")
end)

---------------------------------------------------------------------------
-- H. Performance (median of 3; limits for the biggest profession list of the client)
---------------------------------------------------------------------------
local function Perf(id, ms, limit)
    local r = Active()
    r.perf[id] = math.max(r.perf[id] or 0, ms)
    return ms < limit
end

Case("T139", "H", "Panel-Aufbau je Ansicht", {}, function()
    local a = NewAgg()
    local prof = BiggestProf()
    local slow = 0
    for _, mode in ipairs(Modes()) do
        OpenPanel(prof, mode, { enchanter = mode == "disenchant" or nil, rank = 150 })
        local ms = Median3(function() ns.UI:Refresh() end)
        slow = math.max(slow, ms)
        a:Ok(Perf("T139", ms, 16), string.format("%s %.1f ms", mode, ms))
    end
    ns.UI:Hide()
    local ok, res = a:Result("Ansichten")
    return ok, res .. string.format(" · langsamste %.1f ms (%s)", slow, ns.ProfName(prof)), "< 16 ms"
end)

Case("T140", "H", "Bestes Rezept bei jedem Berufs-Ereignis", {}, function()
    local prof = BiggestProf()
    SetSim({ prof = prof, rank = 150 })
    local ms = Median3(function() ns.UI:UpdateBest() end)
    local ms2 = Median3(function() ns.Advisor.Update(prof, 150) end)
    ns.Advisor.Update(nil, nil)
    local m = math.max(ms, ms2)
    return Perf("T140", m, 16), string.format("%.1f ms", m), "< 16 ms"
end)

Case("T141", "H", "Tooltips", {}, function()
    local r = FirstRecipe(function(x) return x.recipeItems[1] ~= nil end, LWProf())
    GameTooltip:SetOwner(UIParent, "ANCHOR_NONE")
    local t1 = Median3(function() GameTooltip.__psItem = nil; ns.TooltipAddLines(GameTooltip, r.recipeItems[1].id) end)
    local t2 = Median3(function() GameTooltip.__psItem = nil; ns.ReagentLines(GameTooltip, 2318) end)
    GameTooltip:Hide()
    local t3 = Median3(function() ns.UI:ShowRecipeTooltip(UIParent, r, 80) end)
    GameTooltip:Hide()
    local ok = Perf("T141", math.max(t1, t2), 2) and Perf("T141", t3, 16)
    return ok, string.format("Rezept %.2f ms, Material %.2f ms, Panel %.1f ms", t1, t2, t3), "< 2 / < 16 ms"
end)

Case("T142", "H", "Passiver Rezept-Abgleich", {}, function()
    local ms = Median3(function() ns.Scan:PassiveCheck() end)
    local limit = ns.IsRetail and 40 or 16
    return Perf("T142", ms, limit), string.format("%.1f ms (%d Zauber)", ms, Count(ns.BySpell)), "< " .. limit .. " ms"
end)

Case("T143", "H", "Teure Rechnungen", {}, function()
    local a = NewAgg()
    local prof = BiggestProf()
    SetSim({ prof = prof, known = "all", prices = TestPrices() })
    local function m(label, fn, limit)
        local ms = Median3(fn)
        a:Ok(Perf("T143", ms, limit), string.format("%s %.1f ms", label, ms))
    end
    m("TD.Candidates", function() ns.Today.Candidates() end, 16)
    if ns.IsForever then m("F.Crates", function() ns.Favor.Crates() end, 16) end
    m("AD.Plan 1->300", function() ns.Advisor.Plan(ns.ByProf[prof], 1, 300) end, 16)
    local chars = {}
    local p2 = ProfList()[2] and ProfList()[2].id or prof
    for i = 1, 50 do chars["Test" .. i .. "-Testrealm"] = { flavor = ns.Flavor, known = {}, profs = { [prof] = { rank = 1, max = 75 }, [p2] = { rank = 1, max = 75 } } } end
    TestDB({ chars = chars })
    SetSim({ prof = prof, known = "all", prices = TestPrices() })
    m("AL.Needed (50 Charaktere)", function() ns.Alerts.Needed() end, 16)
    local r = ns.ByProf[prof][1]
    local members = {}
    for i = 1, 300 do members["Mitglied" .. i .. "-Testrealm"] = GuildEntry(r, i) end
    GuildStub(members)
    m("Gilden-Index (300)", function() ns.Guild.Invalidate(); ns.Guild.Crafters(r) end, 16)
    if ns.IsForever then m("F.Recipes", function() ns.Favor.Recipes(prof) end, 2) end
    return a:Result("Rechnungen")
end)

Case("T144", "H", "Lebenslinie im Blizzard-Fenster", {}, function()
    if not ActiveHost() then
        if Confirmed("T144") then return true, "bestätigt " .. tostring(Confirmed("T144").date) end
        return CLIENT("Berufsfenster öffnen, dann /ps testroutine h")
    end
    local ms = Median3(function() ns.Lifeline.RefreshBlizzard() end)
    return Perf("T144", ms, 2 * 25), string.format("%.1f ms", ms), "< 2 ms je Zeile"
end)

-- Measurement (0.9.12, Nachprüfung 0.9.11 Punkt 3): warm-up of 20 refreshes (lazy caches), then 20 refreshes,
-- each value after two full GC cycles; for the whole run the engine releases the run's own copies first
-- (rollback entries, snapshot) and also runs two full cycles. The offline growth of 0.9.11 (+1700..+2000 KB)
-- came from LuaJIT: its compiled traces are counted by collectgarbage("count"). The WoW client runs plain
-- Lua 5.1 without a JIT; with the JIT off (tests/wowmock.lua) the run grows by about +250..+350 KB.
local T145_RUN_LIMIT = 1024
Case("T145", "H", "Speicher", {}, function()
    -- warm-up first (item names, rankings and lazy caches are built once), then 20 refreshes: only a leak grows
    OpenPanel(LWProf(), "recipes")
    for _ = 1, 20 do ns.UI:Refresh() end
    collectgarbage("collect"); collectgarbage("collect")
    local before = collectgarbage("count")
    for _ = 1, 20 do ns.UI:Refresh() end
    collectgarbage("collect"); collectgarbage("collect")
    local grow = collectgarbage("count") - before
    ns.UI:Hide()
    Perf("T145", grow, 256)
    -- the growth over the whole run is only known after the rollback: the engine finishes this case at the end
    return DEFER(function(total)
        return grow < 256 and total < T145_RUN_LIMIT, string.format("20× Refresh: %+.0f KB · nach dem Lauf: %+.0f KB", grow, total),
            "< 256 KB / < " .. T145_RUN_LIMIT .. " KB"
    end)
end)

---------------------------------------------------------------------------
-- I. Error counting and diagnostics
---------------------------------------------------------------------------
local function ErrorEntries(where)
    local out = {}
    local s = ProfessionSentinelDB.gsTest
    for key, e in pairs(s and s.errors or {}) do
        if type(e) == "table" and (where == nil or e.wo == where) then out[key] = e end
    end
    return out
end

Case("T146", "I", "Fehlerzählung angemeldet", {}, function()
    local GT = _G.GoldSentinelTest
    local reg = GT and GT.registry[ADDON]
    local p = GT and GT.Pending(ProfessionSentinelDB)
    return reg ~= nil and reg.version == ns.VERSION and type(p) == "number", "registry " .. tostring(reg ~= nil) .. ", offen " .. tostring(p), "angemeldet"
end)

Case("T147", "I", "Abgefangener Fehler wird gezählt", { errors = true }, function()
    ns.Try("Testroutine:I", function() error("ProfessionSentinel Testfehler (absichtlich)") end)
    local found
    for _, e in pairs(ErrorEntries("Testroutine:I")) do found = e end
    local diag = ns.TestMode:Diagnostics()
    return found ~= nil and (found.count or 0) >= 1 and diag:find(L.DIAG_ERRORS, 1, true) ~= nil,
        found and ("gezählt ×" .. tostring(found.count)) or "nicht gezählt", "Eintrag wo=Testroutine:I"
end)

local function RaiseTestError() error("ProfessionSentinel Testfehler (absichtlich)") end

Case("T148", "I", "Ungefangener Fehler wird gezählt", { errors = true }, function()
    local GT = _G.GoldSentinelTest
    if not (GT and _G.GoldSentinelTestHooked) and not _G.GoldSentinelTestBG then return SKIP("Fehler-Abgriff von GoldSentinelTest nicht aktiv") end
    ns.Print(L.TR_ERROR_SOON)
    C_Timer.After(0, RaiseTestError)
    return WAIT(0.2, function()
        local found
        for _, e in pairs(ErrorEntries("Lua")) do
            if tostring(e.msg):find("Testfehler (absichtlich)", 1, true) and tostring(e.msg):find("AddOns[\\/]ProfessionSentinel[\\/]") then found = e end
        end
        return found ~= nil, found and "gezählt (wo=Lua)" or "nicht gezählt", "Eintrag wo=Lua mit Pfad"
    end)
end)

Case("T149", "I", "Diagnose vollständig", {}, function()
    local a = NewAgg()
    local d = ns.TestMode:Diagnostics()
    a:Ok(d:find(G().Status(), 1, true) ~= nil, "G.Status()")
    a:Ok(d:find(L.DIAG_ERRORS, 1, true) ~= nil, "Fehler im Spiel")
    a:Ok(d:find(L.DIAG_PENDING, 1, true) ~= nil, "offene Berichte")
    a:Ok(d:find(L.DIAG_LAST_REPORT, 1, true) ~= nil, "letzter Bericht")
    if ns.IsForever then a:Ok(d:find(L.FAVOR_DIAG_READABLE, 1, true) ~= nil, "Händler-Kosten lesbar") end
    return a:Result("Teile")
end)

-- T180: every action with real consequences goes through ns.Act (nachtrag-testroutinen Punkt 2).
-- The client cannot read source files: the routine calls every action path of the addon (the real module
-- functions, not the intercepted ones) and checks that each one arrived at ns.Act and that no Blizzard
-- action function was called (watchers, hooked with hooksecurefunc). A direct call outside ns.Act would
-- reach the Blizzard function and be counted -> FEHLER. Offline, tests/check_actions.py also checks the
-- source code (the action functions only appear inside ns.Act).
Case("T180", "I", "Aktionen nur über ns.Act", {}, function()
    local a = NewAgg()
    a:Ok(type(ns.Act) == "function" and type(ns.CanAct) == "function", "ns.Act fehlt")
    a:Ok(type(ns.ActRecord) == "function", "ns.Act schreibt im Lauf nicht nur mit")
    local rec = {}
    Stub(ns, "ActRecord", function(kind) rec[#rec + 1] = kind; return true end)
    Capture()
    local g0 = GuardTotal()
    local function got(kind)
        for _, k in ipairs(rec) do if k == kind then return true end end
        return false
    end
    local ways = 0
    -- buy at the vendor
    if ns.CanAct("buy") then
        ways = ways + 1
        Orig("Plan", "BuyItem")(1, 1)
        a:Ok(got("buy"), "PL.BuyItem nicht über ns.Act")
    else
        a:Note("kein Kauf-Weg")
    end
    -- whisper (enchanting offer)
    if ns.CanAct("whisper") then
        ways = ways + 1
        local r = FirstRecipe(function(x) return x.ench end) or ns.Recipes[1]
        Orig("Disenchant", "WhisperOffer")(r, "Testa")
        a:Ok(got("whisper"), "DE.WhisperOffer nicht über ns.Act")
    else
        a:Note("kein Flüster-Weg")
    end
    -- craft in the open profession window (modern: CraftRecipe, old: DoTradeSkill)
    local r = FirstRecipe(function(x) return x.out ~= nil end, LWProf())
    if r then
        Stub(ns.Today, "OpenProfession", function() return r.prof end)
        local want
        if ns.UsesModernProfessions and ns.CanAct("craft") then want = "craft"
        elseif ns.CanAct("tradeskill") then
            want = "tradeskill"
            Stub(ns, "UsesModernProfessions", false)
            Stub(ns.API, "GetNumTradeSkills", function() return 1 end)
            Stub(ns.API, "GetTradeSkillInfo", function() return r.name end)
        end
        if want then
            ways = ways + 1
            Orig("Today", "Craft")({ recipe = r, count = 1 })
            a:Ok(got(want), "TD.Craft nicht über ns.Act (" .. want .. ")")
        else
            a:Note("kein Herstell-Weg")
        end
    end
    -- map pin (TomTom is another addon and no action of the game: switched off here)
    local npc
    for id, n in pairs(ns.NPCs) do if n[6] and n[7] and n[8] then npc = id; break end end
    if npc and ns.CanAct("waypoint") then
        ways = ways + 1
        Stub(_G, "TomTom", nil)
        Stub(ns.API, "MapCanSetUserWaypointOnMap", function() return true end)
        Orig("Waypoint", "Set")(npc)
        a:Ok(got("waypoint"), "WP.Set nicht über ns.Act")
    else
        a:Note("kein Kartenpin-Weg")
    end
    a:Ok(GuardTotal() == g0, "echte Aktion ausserhalb von ns.Act (Wächter ×" .. (GuardTotal() - g0) .. ")")
    local run = Active()
    local total = 0
    for _, v in pairs(run.acts or {}) do total = total + v end
    a:Note(ways .. " Aktionswege, im Lauf " .. total .. " Aktionen mitgeschrieben")
    return a:Result("Prüfungen")
end)

---------------------------------------------------------------------------
-- J. Regression tests (every earlier finding is one case)
---------------------------------------------------------------------------
Case("T150", "J", "GoldSentinelGame unverändert, kein eigener Nachbau", {}, function()
    local GG = G()
    local before = {}
    for k, v in pairs(GG) do if type(v) == "function" then before[k] = v end end
    ns.ApplyFlavor(GG)
    local changed
    for k, v in pairs(before) do if not rawequal(GG[k], v) then changed = k end end
    return type(GG.version) == "number" and GG.version == 2 and not changed, "Version " .. tostring(GG.version) .. (changed and (", verändert: " .. changed) or ""), "2, keine Funktion überschrieben"
end)

Case("T151", "J", "Versionserkennung aus GoldSentinelGame", {}, function()
    local GG = G()
    local real = S.FlavorSnapshot()
    OnUndo(function() ns.ApplyFlavor(GG) end)
    ns.ApplyFlavor(nil)
    local own = S.FlavorSnapshot()
    ns.ApplyFlavor(GG)
    local d = Diff(real, own)
    return d == nil, d and ("abweichend: " .. d) or ("beide " .. tostring(real.Flavor)), "gleich"
end)

local function OnlyF() if not ns.IsForever then return SKIP("nur WoW Forever") end end

Case("T152", "J", "Favor-Rezepte ohne Goldpreis", {}, function()
    local sk = OnlyF(); if sk then return sk end
    local n, badFa, withBp = 0, 0, 0
    for _, r in ipairs(ns.Recipes) do
        for _, ri in ipairs(r.recipeItems) do
            if ri.fv then
                n = n + 1
                if ri.fa ~= nil and ri.fa ~= 2587 then badFa = badFa + 1 end      -- 130 recipes need no reputation
                if ri.bp then withBp = withBp + 1 end
            end
        end
    end
    local fac = ns.Factions and ns.Factions[2586] and ns.Factions[2587]
    return n >= 300 and n <= 320 and badFa == 0 and withBp == 0 and fac ~= nil,
        string.format("%d Favor-Rezepte, Ruf ≠ 2587: %d, mit Goldpreis: %d, Fraktionen %s", n, badFa, withBp, tostring(fac ~= nil)), "300–320, 0, 0, ja"
end)

Case("T153", "J", "Panel-Tooltip zeigt Favor statt Gold", {}, function()
    local sk = OnlyF(); if sk then return sk end
    local ri, r = FavorItem()
    if not r then return false, "Rezept 250364 fehlt" end
    TestDB({})
    Stub(_G, "AHAnalyzerPro", nil)
    ns.UI:ShowRecipeTooltip(UIParent, r, 80)
    local lines = TooltipLines()
    GameTooltip:Hide()
    local favor = LinesWith(lines, L.FAVOR_GUIDE)
    local rep = LinesWith(lines, L.REP_NEEDED)
    local cost = ns.Favor.CostText(ri)
    local money = 0
    for _, l in ipairs(lines) do if l:match("^%s*%d+g") or l:match("^%s*%d+s %d+c$") then money = money + 1 end end
    return favor >= 1 and rep >= 1 and money == 0 and cost ~= nil, string.format("Favor-Zeilen %d, Ruf %d, Münz-Zeilen %d", favor, rep, money), "Favor + Ruf, keine Münzen"
end)

Case("T154", "J", "Allianz bekommt ihre Fraktion", {}, function()
    local sk = OnlyF(); if sk then return sk end
    local FV = ns.Favor
    return FV.Faction(2587, "Alliance") == 2586 and FV.Faction(2587, "Horde") == 2587, "A " .. tostring(FV.Faction(2587, "Alliance")) .. ", H " .. tostring(FV.Faction(2587, "Horde")), "2586 / 2587"
end)

-- merchant stubs for the favor vendor (one favor recipe in slot 1)
local function FavorMerchant(withCosts)
    Stub(ns.API, "GetMerchantNumItems", nil)
    Stub(ns.API, "MerchantGetNumItems", function() return 1 end)
    Stub(ns.API, "GetMerchantItemID", function() return 250364 end)
    if withCosts then
        Stub(ns.API, "GetMerchantItemCostInfo", function() return 1 end)
        Stub(ns.API, "GetMerchantItemCostItem", function() return 134400, 175, "|cffffffff|Hcurrency:3333|h[Merchant's Favor]|h|r", "Merchant's Favor" end)
    else
        Stub(ns.API, "GetMerchantItemCostInfo", nil)
        Stub(ns.API, "GetMerchantItemCostItem", nil)
    end
end

Case("T155", "J", "Händler-Artikelzahl ohne GetMerchantNumItems [api]", { api = true }, function()
    local sk = OnlyF(); if sk then return sk end
    TestDB({})
    FavorMerchant(true)
    local n = ns.Favor.LearnFromMerchant()
    local c = ns.db.favor and ns.db.favor.costs[250364]
    return n == 1 and c and c.n == 175, "gelernt " .. tostring(n) .. ", Kosten " .. tostring(c and c.n), "1 / 175"
end)

Case("T156", "J", "Weitere Händler-Funktionen ohne alte Globals [api]", { api = true }, function()
    if not ns.UsesModernProfessions then return SKIP("nur moderner Client (WoW Forever, Retail)") end
    local PL = ns.Plan
    Without({ "GetMerchantItemInfo", "GetMerchantItemLink", "GetMerchantItemID" })
    Stub(ns.API, "MerchantGetItemInfo", function() return { name = "X", texture = 1, price = 12, stackCount = 5, numAvailable = 3 } end)
    local _, _, price, stack, avail = PL.MerchantItemInfo(1)
    local ok, id = pcall(PL.MerchantItemID, 1)
    return price == 12 and stack == 5 and avail == 3 and ok and id == nil, string.format("Preis %s, Stapel %s, verfügbar %s, ID %s", tostring(price), tostring(stack), tostring(avail), tostring(id)), "12/5/3, nil ohne Fehler"
end)

Case("T157", "J", "Reihenfolge der Kosten", {}, function()
    local sk = OnlyF(); if sk then return sk end
    local ri = FavorItem()
    local db = TestDB({ favor = { costs = { [250364] = { n = 150, c = "Merchant's Favor" } } } })
    Stub(_G, "AHAnalyzerPro", { GetVendorCost = function() return { costs = { { kind = "currency", id = 3333, name = "Merchant's Favor", amount = 170 } } } end })
    local s = {}
    s[1] = ns.Favor.Cost(ri).n
    db.favor.costs = {}
    s[2] = ns.Favor.Cost(ri).n
    Stub(_G, "AHAnalyzerPro", nil)
    s[3] = ns.Favor.Cost(ri).n
    local r = table.concat(s, ",")
    return r == "150,170,180", r, "150,170,180"
end)

Case("T159", "J", "AHSentinel nur aufrufen, wenn vorhanden, in pcall", { errors = true }, function()
    local sk = OnlyF(); if sk then return sk end
    local ri = FavorItem()
    TestDB({})
    local a = NewAgg()
    for _, A in ipairs({ {}, { GetVendorCost = function() error("AHSentinel-Testfehler (absichtlich)") end },
        { GetVendorCost = function() return nil end }, { GetVendorCost = function() return { costs = {} } end } }) do
        Stub(_G, "AHAnalyzerPro", A)
        local ok, c = pcall(ns.Favor.Cost, ri)
        a:Ok(ok and c and c.n == 180 and not c.learned, "Variante ergibt " .. tostring(c and c.n))
    end
    return a:Result("Varianten")
end)

Case("T160", "J", "Währungs-ID von AHSentinel für den Stand", {}, function()
    local sk = OnlyF(); if sk then return sk end
    local ri = FavorItem()
    local db = TestDB({})
    Stub(_G, "AHAnalyzerPro", { GetVendorCost = function() return { costs = { { kind = "currency", id = 3333, name = "Merchant's Favor", amount = 170 } } } end })
    ns.Favor.Cost(ri)
    -- F.Balance asks this id (through ns.API; nothing is replaced here, only called)
    local ok, bal = pcall(ns.Favor.Balance)
    return db.favor.currency == 3333 and ok and (bal == nil or type(bal) == "number"), "currency " .. tostring(db.favor.currency) .. ", Stand " .. tostring(bal), "3333"
end)

Case("T161", "J", "Ruf im modernen Client [api]", { api = true }, function()
    if ns.IsEra then
        local text, met = ns.RepInfo(529, 4)
        if not ns.API.GetFactionInfoByID then return false, "GetFactionInfoByID fehlt", "alter Weg" end
        return text ~= nil, "alter Weg: " .. tostring(text) .. ", erfüllt " .. tostring(met), "Text"
    end
    if not ns.UsesModernProfessions then return SKIP("nicht unterstützt") end
    local a = NewAgg()
    Without({ "GetFactionInfoByID" })
    local reaction = 5
    Stub(ns.API, "ReputationGetFactionDataByID", function() return { name = "Test", reaction = reaction } end)
    local _, m1 = ns.RepInfo(2587, 4)
    reaction = 4
    local _, m2 = ns.RepInfo(2587, 4)
    Stub(ns.API, "ReputationGetFactionDataByID", nil)
    local _, m3 = ns.RepInfo(2587, 4)
    a:Ok(m1 == true, "reaction 5 nicht grün")
    a:Ok(m2 == false, "reaction 4 nicht rot")
    a:Ok(m3 == nil, "ohne API nicht gelb")
    return a:Result("Fälle")
end)

Case("T162", "J", "Nur Händlergunst von AHSentinel", {}, function()
    local sk = OnlyF(); if sk then return sk end
    local ri = FavorItem()
    local a = NewAgg()
    local db = TestDB({})
    local cost = { id = 4444, name = "Honor" }
    Stub(_G, "AHAnalyzerPro", { GetVendorCost = function() return { costs = { { kind = "currency", id = cost.id, name = cost.name, amount = 170 } } } end })
    local c1 = ns.Favor.Cost(ri)
    a:Ok(c1.n == 180 and db.favor.currency == nil, "Honor übernommen")
    cost.id, cost.name = 3333, "Händlergunst"
    local c2 = ns.Favor.Cost(ri)
    a:Ok(c2.n == 170 and db.favor.currency == 3333, "Händlergunst nicht übernommen")
    cost.name = "X"
    a:Ok(ns.Favor.Cost(ri).n == 170, "über die ID nicht übernommen")
    cost.id = 5555
    a:Ok(ns.Favor.Cost(ri).n == 180, "fremde ID übernommen")
    return a:Result("Fälle")
end)

Case("T163", "J", "Kosten nicht lesbar: Hinweis einmal je Besuch [api]", { api = true }, function()
    local sk = OnlyF(); if sk then return sk end
    local FV = ns.Favor
    local out = Capture()
    FavorMerchant(false)
    OnUndo(function() FV.OnMerchantEvent("MERCHANT_CLOSED") end)
    FV.OnMerchantEvent("MERCHANT_CLOSED")
    FV.OnMerchantEvent("MERCHANT_SHOW")
    FV.OnMerchantEvent("MERCHANT_SHOW")
    local n1 = Times(out, L.FAVOR_COSTS_UNREADABLE)
    FV.OnMerchantEvent("MERCHANT_CLOSED")
    FV.OnMerchantEvent("MERCHANT_SHOW")
    local n2 = Times(out, L.FAVOR_COSTS_UNREADABLE)
    local diag = ns.TestMode:Diagnostics()
    local no = diag:find(L.FAVOR_DIAG_READABLE .. ": |cffff6060", 1, true) ~= nil
    return n1 == 1 and n2 == 2 and no, string.format("Hinweise %d / %d, Diagnose „nein“ %s", n1, n2, tostring(no)), "1 / 2, nein"
end)

Case("T164", "J", "Hergestellte Kisten: günstiger von Kaufen und Herstellen", {}, function()
    local sk = OnlyF(); if sk then return sk end
    local FV = ns.Favor
    local a = NewAgg()
    local ingots
    for _, c in ipairs(ns.Crates or {}) do if c.id == 248703 then ingots = c end end
    if not ingots then return false, "Kiste 248703 fehlt" end
    SetSim({ prices = { [2840] = 100, [2770] = 20, [3576] = 500, [2771] = 500, [2841] = 500, [248703] = 0 } })
    local iv = FV.CrateValue(ingots, function() return 0 end)
    a:Ok(iv.best and iv.best.origin == "craft" and iv.best.cost == 400, "Herstellen billiger")
    SetSim({ prices = { [2840] = 5, [2770] = 2000, [3576] = 5, [2771] = 2000, [2841] = 5, [248703] = 0 } })
    local iv2 = FV.CrateValue(ingots, function() return 0 end)
    a:Ok(iv2.best and iv2.best.origin ~= "craft", "Kaufen billiger: " .. tostring(iv2.best and iv2.best.origin))
    SetSim({ prof = LWProf(), prices = { [2840] = 100, [2770] = 20, [3576] = 500, [2771] = 500, [2841] = 500, [248703] = 0 } })
    SetDB("panelMode", "favor")
    ns.UI:Show(nil)
    Refresh()
    local craftTip = false
    for _, d in ipairs(ViewData()) do
        if d.itemID == 248703 and type(d.tip) == "table" then
            for _, l in ipairs(d.tip) do
                local s = type(l) == "table" and tostring(l[2]) or tostring(l)
                if Plain(s):find(Plain(L.ORIGIN_CRAFT), 1, true) then craftTip = true end
            end
        end
    end
    ns.UI:Hide()
    a:Ok(craftTip, "Kisten-Tooltip ohne ORIGIN_CRAFT")
    return a:Result("Fälle")
end)

Case("T165", "J", "Beste Kiste in „Heute herstellen“ nur mit Option", {}, function()
    local sk = OnlyF(); if sk then return sk end
    local FV = ns.Favor
    local a = NewAgg()
    a:Ok(ns.InitDB({}).todayCrates == false, "Standard nicht aus")
    SetSim({ prof = LWProf(), prices = TestPrices() })
    local function todayRows()
        SetDB("panelMode", "ranking")
        ns.UI:Show(nil)
        Refresh()
        local n, crate = 0, false
        for _, d in ipairs(ViewData()) do
            if d.info and d.itemID then
                for _, c in ipairs(ns.Crates) do if c.id == d.itemID then crate = true end end
            end
        end
        return crate
    end
    SetDB("todayCrates", false)
    a:Ok(FV.BestCrate() == nil and not todayRows(), "aus: Kiste da")
    SetDB("todayCrates", true)
    a:Ok(FV.BestCrate() ~= nil and todayRows(), "an: keine Kiste")
    ns.UI:Hide()
    return a:Result("Fälle")
end)

Case("T166", "J", "Händlerweg alter Clients exakt wie früher [api]", { api = true }, function()
    local calls, price = MerchantInfoOrder()
    return calls == "alt" and price == 10, "gerufen: " .. calls, "nur GetMerchantItemInfo"
end)

Case("T167", "J", "Reiter-Verteilung nur in Forever", {}, function()
    local a = NewAgg()
    local list = TabLayout()
    if ns.IsForever then
        -- the visible tabs form one chain without gaps: one at the panel, every other one at a visible tab
        local shownSet, atPanel, targets = {}, 0, {}
        for _, t in ipairs(list) do if t.shown then shownSet[t.tab] = true end end
        for _, t in ipairs(list) do
            if t.shown then
                a:Ok((t.w or 0) <= 76, "Breite " .. tostring(t.w))
                if t.rel == Panel() then atPanel = atPanel + 1
                else a:Ok(shownSet[t.rel] == true, "Lücke: " .. Plain(Text(t.tab)) .. " hängt an einem versteckten Reiter") end
                a:Ok(not targets[t.rel], "zwei Reiter am selben Anker")
                targets[t.rel] = true
            end
        end
        a:Ok(atPanel == 1, "Reiter am Panel: " .. atPanel)
    else
        for _, t in ipairs(list) do a:Ok(math.abs((t.w or 0) - 76) < 0.5 and t.n == 1, "Anker/Breite verändert") end
    end
    return a:Result("Reiter")
end)

Case("T168", "J", "Favor-Kosten im Item-Tooltip", {}, function()
    local sk = OnlyF(); if sk then return sk end
    TestDB({})
    Stub(_G, "AHAnalyzerPro", nil)
    SetDB("tooltip", true)
    local lines = ItemTooltip(250364)
    if #lines == 0 then return SKIP("Item 250364 nicht im Cache") end
    local cost, rep = LinesWith(lines, L.FAVOR_COST), LinesWith(lines, L.REP_NEEDED)
    SetDB("tooltip", false)
    local off = LinesWith(ItemTooltip(250364), L.FAVOR_COST)
    return cost == 1 and rep >= 1 and off == 0, string.format("Kosten %d, Ruf %d, aus %d", cost, rep, off), "1, ≥1, 0"
end)

Case("T169", "J", "Interface-Nummer nach dem Launch", {}, function()
    local sk = OnlyF(); if sk then return sk end
    if not AfterLaunch() then return SKIP("vor Launch (5.11.2026)") end
    if Confirmed("T169") then return true, "bestätigt " .. tostring(Confirmed("T169").date) end
    return CLIENT("/dump select(4, GetBuildInfo()) – Nummer in allen 4 TOCs (Client " .. tostring(select(4, GetBuildInfo())) .. ")")
end)

Case("T170", "J", "Daten aus dem Live-Build", {}, function()
    local sk = OnlyF(); if sk then return sk end
    if not AfterLaunch() then return SKIP("vor Launch (5.11.2026)") end
    local b = ns.DataMeta.build
    local _, cb = GetBuildInfo()
    local client = tostring(select(1, GetBuildInfo())) .. "." .. tostring(cb)
    return b ~= "1.60.1.70707" or b == client, "Daten " .. tostring(b) .. ", Client " .. client, "nicht Beta 70707"
end)

local CANDIDATE_EVENTS = { "TRADE_SKILL_SHOW", "TRADE_SKILL_UPDATE", "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_DATA_SOURCE_CHANGED",
    "CRAFT_SHOW", "CRAFT_UPDATE", "NEW_RECIPE_LEARNED", "LEARNED_SPELL_IN_TAB", "SKILL_LINES_CHANGED", "CHAT_MSG_SKILL",
    "ADDON_LOADED", "PLAYER_LOGIN", "MERCHANT_SHOW", "MERCHANT_UPDATE", "MERCHANT_CLOSED", "GET_ITEM_INFO_RECEIVED",
    "PLAYER_REGEN_DISABLED" }

Case("T171", "J", "Nur bekannte Ereignisse angemeldet", {}, function()
    if not (C_EventUtils and C_EventUtils.IsEventValid) then return SKIP("C_EventUtils.IsEventValid fehlt in diesem Client") end
    local n, bad = 0, {}
    for _, e in ipairs(ns.EventFrames) do
        for _, ev in ipairs(CANDIDATE_EVENTS) do
            if e.frame:IsEventRegistered(ev) then
                n = n + 1
                if not C_EventUtils.IsEventValid(ev) then bad[#bad + 1] = e.label .. ":" .. ev end
            end
        end
    end
    return #bad == 0, n .. " Anmeldungen" .. (#bad > 0 and (", ungültig: " .. table.concat(bad, ", ")) or ""), "alle gültig"
end)

Case("T172", "J", "Nicht unterstützte Versionen sagen es einmal", {}, function()
    local a = NewAgg()
    Flavor("tbc")
    local db = TestDB({})
    db.chars = {}
    local out = Capture()
    local r = ns.OnLogin()
    a:Ok(r == false, "OnLogin läuft weiter")
    a:Ok(Times(out, (L.UNSUPPORTED:gsub("%%.*$", ""))) == 1, "Hinweis nicht genau einmal")
    a:Ok(next(db.chars) == nil, "Charakter angelegt")
    for _, e in ipairs(ns.EventFrames) do
        if e.label == "Tooltip" then
            local fn = e.frame:GetScript("OnEvent")
            a:Ok(pcall(fn, e.frame, "PLAYER_LOGIN"), "Tooltip-Login")
        end
    end
    return a:Result("Prüfungen")
end)

Case("T173", "J", "Nichts in den Gildenkanal, nur lesen", {}, function()
    local a = NewAgg()
    local r = FirstRecipe(function(x) return x.out ~= nil end, LWProf())
    local prof = { ["Testa-Testrealm"] = GuildEntry(r, 1), ["Testb-Testrealm"] = GuildEntry(r, 2) }
    local rec = { prof = { ["Testc-Testrealm"] = GuildEntry(r, 3) }, cds = { ["Testa-Testrealm"] = { t = 1, k = { transmute = 0 } } } }
    local before = DeepCopy({ prof, rec })
    GuildStub(prof, { record = rec })
    ns.Guild.Crafters(r); ns.Guild.NobodyKnows(r.prof); ns.Guild.Cooldowns(); ns.Guild.Profs()
    a:Ok(Diff(before, { prof, rec }) == nil, "Gildendaten verändert")
    local sent = 0
    for k, v in pairs(Active().guards) do if k:find("^SendChatMessage") then sent = sent + v end end
    a:Ok(sent == 0, "SendChatMessage ×" .. sent)
    return a:Result("Prüfungen")
end)

Case("T174", "J", "Echte Aktionen nur nach Klick", {}, function()
    local a = NewAgg()
    Capture()
    local i0 = S.InterceptedTotal()
    S.FireAll(a)
    a:Ok(S.InterceptedTotal() == i0, "Ereignis hat eine Aktion ausgelöst")
    return a:Result("Aufrufe")
end)

Case("T175", "J", "Berufsfenster wird nie selbst geöffnet", {}, function()
    local out = Capture()
    local g = Active().guards
    local c0 = (g.CastSpellByName or 0) + (g["C_TradeSkillUI.OpenTradeSkill"] or 0)
    local r = FirstRecipe(function(x) return x.out ~= nil end, LWProf())
    Stub(ns.Today, "Plan", function(e) e.step = "openProf"; return e end)
    ns.Today.Run({ recipe = r, count = 1, missing = {} })
    local c1 = (g.CastSpellByName or 0) + (g["C_TradeSkillUI.OpenTradeSkill"] or 0)
    local hint = Has(out, (L.TODAY_STEP_OPENPROF:gsub("%%s.*$", "")))
    return c1 == c0 and hint, "Hinweis " .. tostring(hint) .. ", Öffnen ×" .. (c1 - c0), "nur Hinweis"
end)

Case("T176", "J", "Vor- und Nachnamen in Forever", {}, function()
    local a = NewAgg()
    local r = FirstRecipe(function(x) return x.out ~= nil and x.recipeItems[1] ~= nil end, LWProf())
    TestDB({ chars = {
        ["Vorname Nachname-Testrealm"] = { flavor = ns.Flavor, known = { [r.spell] = true }, profs = { [r.prof] = { rank = 1, max = 75 } } },
        ["Erika Muster-Testrealm"] = { flavor = ns.Flavor, known = {}, profs = { [r.prof] = { rank = 1, max = 75 } } },
    } })
    local kb, mb = ns.Scan:CharsFor(r.spell, r.prof)
    a:Ok(kb[1] == "Vorname Nachname" and #mb >= 1, "CharsFor kürzt falsch")
    local e = ns.Alerts.Needed()[r.recipeItems[1].id]
    local spaced = false
    for _, n in ipairs(e and e.names or {}) do if n == "Erika Muster" then spaced = true end end
    a:Ok(spaced, "AL.Needed kürzt falsch")
    GuildStub({ ["Vorname Nachname-Testrealm"] = GuildEntry(r, 1) })
    local c = ns.Guild.Crafters(r)
    a:Ok(c and c[1] and c[1].name == "Vorname Nachname", "GU.Crafters kürzt falsch")
    return a:Result("Prüfungen")
end)

Case("T177", "J", "Gildenblick bleibt leer, solange RaidMaster in Forever nichts einliest", {}, function()
    local sk = OnlyF(); if sk then return sk end
    local r = FirstRecipe(function(x) return x.out ~= nil and x.recipeItems[1] ~= nil end, LWProf())
    GuildStub({})
    local ok, list = pcall(ns.Guild.Crafters, r)
    local lines = ItemTooltip(r.recipeItems[1].id)
    if not (ok and list == nil and LinesWith(lines, L.GUILD_CRAFTERS) == 0) then
        return false, ok and "Gildenzeilen trotz leerer Daten" or ("Lua: " .. tostring(list)), "keine Gildenzeilen"
    end
    if Confirmed("T177") then return true, "bestätigt " .. tostring(Confirmed("T177").date) end
    return CLIENT("automatisch OK; nach dem RaidMaster-Fix: Gildenblick zeigt Einträge")
end)

Case("T178", "J", "Händlerpreise bei Lücke in AHSentinel", { errors = true }, function()
    local P = ns.Prices
    local a = NewAgg()
    Stub(_G, "AHAnalyzerPro", { GetVendorBuyPrice = function() return 999 end })
    a:Ok(P.VendorBuy(2320) == 10, "Daten nicht zuerst")
    Stub(_G, "AHAnalyzerPro", { GetVendorBuyPrice = function() return nil end })
    a:Ok(P.VendorBuy(2320) == 10, "nil-Rückgabe")
    Stub(_G, "AHAnalyzerPro", { GetVendorBuyPrice = function() error("AHSentinel-Testfehler (absichtlich)") end })
    local ok, v = pcall(P.VendorBuy, 2320)
    a:Ok(ok and v == 10, "Fehler in AHSentinel")
    return a:Result("Fälle")
end)

Case("T179", "J", "/gsgame zeigt die richtige API", {}, function()
    local GG = G()
    local s = GG.Status()
    local want = GG.Text((ns.IsForever or ns.IsRetail) and "modern" or "old")
    if not s:find(want, 1, true) then return false, s, want end
    if ns.IsForever then
        if GG.HasSecrets then
            return s:find(GG.Text("secrets") .. ": " .. GG.Text("yes"), 1, true) ~= nil, s, "Geschützte Werte: ja"
        end
        if Confirmed("T179") then return true, "bestätigt " .. tostring(Confirmed("T179").date) end
        return CLIENT("/gsgame: „Geschützte Werte: ja“ erwartet (Client meldet keine geschützten Werte)")
    end
    return true, s
end)

-- Nachprüfung 0.9.11 Punkt 5: realms with a hyphen (Retail "Azjol-Nerub") – the own name is cut at the
-- FIRST hyphen (like CharsFor), otherwise the own character showed up among the other characters.
Case("T181", "J", "Realm mit Bindestrich", { selftest = true }, function()
    local a = NewAgg()
    a:Ok(ns.NameFromKey("Thrall-Azjol-Nerub") == "Thrall", "Thrall-Azjol-Nerub -> " .. tostring(ns.NameFromKey("Thrall-Azjol-Nerub")))
    a:Ok(ns.NameFromKey("Testa-Testrealm") == "Testa", "Testa-Testrealm")
    a:Ok(ns.NameFromKey("Vorname Nachname-Test-Realm") == "Vorname Nachname", "Vor- und Nachname")
    a:Ok(ns.NameFromKey("?-") == nil and ns.NameFromKey(nil) == nil, "unbekannt")
    -- the same short name as CharsFor uses for the tooltip list
    local key = "Thrall-Azjol-Nerub"
    a:Ok((key:match("^[^-]+") or key) == ns.NameFromKey(key), "anders als CharsFor")
    local okN, raw = pcall(UnitName, "player")
    if okN and not ns.IsSecret(raw) and type(raw) == "string" and ns.PlayerName() then
        a:Ok(ns.PlayerName() == raw, "eigener Name ≠ UnitName(\"player\")")
    end
    return a:Result("Fälle")
end)

---------------------------------------------------------------------------
-- Final cases (run by the engine after the rollback, in this order: T158, T04, T03)
---------------------------------------------------------------------------
Case("T158", "J", "Keine Namen im Bericht", { final = true }, function() return true end)
Case("T04", "A", "Sandbox: echte Daten unverändert", { final = true, selftest = true }, function() return true end)
Case("T03", "A", "Wächter: keine echte Folge im ganzen Lauf", { final = true, selftest = true }, function() return true end)

---------------------------------------------------------------------------
-- Engine
---------------------------------------------------------------------------
-- actions with real consequences: replaced for the whole run, only counted
local INTERCEPT = {
    { "Plan", "BuyFromVendor", "Beim Händler kaufen", 0 },
    { "Plan", "ToSniper", "Plan -> Sniper (AHSentinel)", 0 },
    { "Plan", "BuyItem", "Händler-Kauf (PL.BuyItem)", false },
    { "Disenchant", "SendToSniper", "Sniper-Ziele anlegen (AHSentinel)", 0 },
    { "Disenchant", "WhisperOffer", "VZ-Angebot flüstern", false },
    { "Disenchant", "AskGoal", "Fenster Ziel Verzauberkunst", nil },
    { "Disenchant", "EditMarkup", "Eingabe Aufschlag", nil },
    { "Disenchant", "EditMinProfit", "Eingabe Mindestgewinn", nil },
    { "Disenchant", "EditMargin", "Eingabe Marge", nil },
    { "Alerts", "ToSniper", "Rezept-Alarm -> Sniper", 0 },
    { "Waypoint", "Set", "Wegpunkt setzen", false },
    { "Today", "BuyVendor", "Today.BuyVendor", false },
    { "Today", "BuyAH", "Today.BuyAH", false },
    { "Today", "Craft", "Today.Craft", false },
    { "Today", "Sell", "Today.Sell", false },
}

-- watchers: count real calls during a run (never prevent them); hooked once with hooksecurefunc
local GUARDS = {
    { nil, "BuyMerchantItem" }, { "C_MerchantFrame", "BuyItem" }, { nil, "PickupMerchantItem" },
    { nil, "SendChatMessage", true }, { "C_ChatInfo", "SendChatMessage", true, "SendChatMessage (C_ChatInfo)" },
    { "C_ChatInfo", "SendAddonMessage", false, "SendAddonMessage" },
    { "C_TradeSkillUI", "CraftRecipe" }, { nil, "DoTradeSkill" }, { "C_TradeSkillUI", "OpenTradeSkill" },
    { nil, "CastSpellByName" }, { "C_AuctionHouse", "PostItem" }, { "C_AuctionHouse", "PostCommodity" },
    { "C_AuctionHouse", "PlaceBid" }, { "C_AuctionHouse", "StartCommoditiesPurchase" },
    { "C_AuctionHouse", "ConfirmCommoditiesPurchase" }, { nil, "PostAuction" }, { nil, "StartAuction" },
    { nil, "PlaceAuctionBid" }, { nil, "SendMail" }, { nil, "SetRaidTarget" }, { "C_Map", "SetUserWaypoint" },
}
local guardsInstalled = false
local function InstallGuards()
    if guardsInstalled or not hooksecurefunc then return end
    guardsInstalled = true
    for _, g in ipairs(GUARDS) do
        local tname, fname, perChannel, label = g[1], g[2], g[3], g[4]
        local t = tname and _G[tname] or _G
        label = label or (tname and (tname .. "." .. fname) or fname)
        if type(t) == "table" and type(t[fname]) == "function" then
            local ok = pcall(function()
                local function count(_, channel)
                    if #runs == 0 then return end
                    for _, r in ipairs(runs) do
                        r.guards[label] = (r.guards[label] or 0) + 1
                        if perChannel and type(channel) == "string" then
                            local k = label .. ":" .. channel
                            r.guards[k] = (r.guards[k] or 0) + 1
                        end
                    end
                end
                if tname then
                    hooksecurefunc(t, fname, function(a, b) count(a, b) end)
                else
                    -- SendChatMessage(msg, chatType, ...): the channel is the second argument
                    hooksecurefunc(fname, function(a, b) count(a, b) end)
                end
            end)
            if not ok then guardsInstalled = guardsInstalled end
        end
    end
end

local EXCLUDED = { gsTest = true, autotest = true, testConfirm = true }

local function Snapshot(db)
    local s = {}
    for k, v in pairs(db) do if not EXCLUDED[k] then s[k] = DeepCopy(v) end end
    return s
end

-- restore in place: same tables stay the same tables (UI keeps references, e.g. collapsed)
local function RestoreInPlace(live, saved, top)
    for k in pairs(live) do
        if saved[k] == nil and not (top and EXCLUDED[k]) then live[k] = nil end
    end
    for k, v in pairs(saved) do
        if type(v) == "table" and type(live[k]) == "table" then RestoreInPlace(live[k], v, false)
        else live[k] = DeepCopy(v) end
    end
end

local function NewRun(opts, sub)
    local GT = _G.GoldSentinelTest
    local run = {
        opts = opts or {}, sub = sub, sync = sub, stack = {}, done = {}, undoErrors = {}, intercepted = {}, guards = {}, acts = {},
        perf = {}, warnings = {}, qi = 0, statuses = {}, t0 = Now(), deferred = {},
        T = GT.Begin(ADDON, ns.VERSION, sub and {} or ProfessionSentinelDB),
    }
    run.orig = sub and runs[1] and runs[1].orig or {}
    -- queue
    local f = run.opts.filter
    local list = {}
    for _, c in ipairs(cases) do
        if not c.final then
            local take
            if f == nil then take = not c.api              -- [api] only with /ps testroutine api
            elseif f == "API" then take = c.api
            elseif f == "SELFTEST" then take = c.selftest and not c.api
            else take = (c.area == f) and not c.api end
            if take then list[#list + 1] = c end
        end
    end
    local function num(c) return tonumber(c.id:match("%d+")) or 0 end
    table.sort(list, function(a, b)
        if (a.api and true or false) ~= (b.api and true or false) then return not a.api end   -- [api] at the end
        return num(a) < num(b)
    end)
    run.queue = list
    run.api = false
    for _, c in ipairs(list) do if c.api then run.api = true end end
    -- state before the run
    run.snapshot = Snapshot(ProfessionSentinelDB)
    run.me = ns.CharKey()
    run.sim = ns.Sim
    run.ui = {
        panelShown = ns.UI and ns.UI:IsShown() or false, host = ActiveHost(),
        search = Text(SearchBox()), testShown = _G.ProfessionSentinelTestMode and _G.ProfessionSentinelTestMode:IsShown() or false,
        goalShown = _G.ProfessionSentinelGoalFrame and _G.ProfessionSentinelGoalFrame:IsShown() or false,
    }
    run.flavor = ns.Flavor
    -- memory baseline (T145) after a warm-up: windows and row pools that every normal use creates once are no
    -- leak. The warm-up runs after the snapshot, so the sandbox puts back whatever it touched.
    if not sub then pcall(TR.WarmUp) end
    -- twice: the first cycle only finalises some objects (weak tables, userdata), the second frees them
    collectgarbage("collect"); collectgarbage("collect")
    run.mem0 = collectgarbage("count")
    return run
end

function TR.WarmUp()
    local sim, mode, shown = ns.Sim, ns.db.panelMode, ns.UI:IsShown()
    if not shown then
        -- every view of every profession once (as T81 does): row pools, frames and caches that WoW never
        -- frees are built here, so T145 only sees what the run itself keeps
        for _, p in ipairs(ProfList()) do
            for _, m in ipairs(S.Modes()) do
                ns.Sim = { prof = p.id, enchanter = true, rank = 150 }
                ns.db.panelMode = m
                ns.UI:Show(nil)
            end
        end
        ns.UI:Hide()
    end
    ns.Sim, ns.db.panelMode = sim, mode
    if not _G.ProfessionSentinelTestMode and ns.TestMode then ns.TestMode:Toggle(); ns.TestMode:Toggle() end
    if not _G.ProfessionSentinelAutoTestReport and ns.AutoTest.ShowReport then
        ns.AutoTest.ShowReport(" ", L.TR_REPORT_TITLE, L.TR_REPORT_HINT)
        _G.ProfessionSentinelAutoTestReport:Hide()
    end
end

local function InstallIntercepts(run)
    -- ns.Act (the addon's single place for actions with consequences) only writes down during the run
    Stub(ns, "ActRecord", function(kind)
        for _, r in ipairs(runs) do
            r.acts[kind] = (r.acts[kind] or 0) + 1
            local label = "ns.Act " .. tostring(kind)
            r.intercepted[label] = (r.intercepted[label] or 0) + 1
        end
        return true
    end, "ns.Act mitschreiben")
    for _, def in ipairs(INTERCEPT) do
        local mod, key, label, ret = def[1], def[2], def[3], def[4]
        local t = ns[mod]
        if t and type(t[key]) == "function" then
            run.orig[mod .. "." .. key] = t[key]
            Stub(t, key, function()
                local r = Active()
                if r then r.intercepted[label] = (r.intercepted[label] or 0) + 1 end
                return ret
            end, "Abfangen " .. mod .. "." .. key)
        end
    end
end

local function ErrorsSnapshot()
    local s = ProfessionSentinelDB and ProfessionSentinelDB.gsTest
    return s and DeepCopy(s.errors or {}) or nil
end
local function ErrorsRestore(snap)
    local s = ProfessionSentinelDB and ProfessionSentinelDB.gsTest
    if s and snap then s.errors = snap end
end

local function Record(run, c, res)
    local T = run.T
    local ok, a, b, cc = res[1], res[2], res[3], res[4]
    local status
    if not ok then
        local msg = tostring(a):match("^[^\n]+") or tostring(a)
        T:Check(c.id, c.area, c.name, function() error(msg, 0) end)
        status = "FEHLER"
    elseif Marker(a, "skip") then
        T:Skip(c.id, c.area, c.name, a.reason or "ohne Grund")
        status = "SKIP"
    elseif Marker(a, "defer") then
        run.deferred[#run.deferred + 1] = { c = c, fn = a.fn }
        status = "DEFER"
    elseif Marker(a, "client") then
        local conf = Confirmed(c.id)
        if conf then T:Check(c.id, c.area, c.name, function() return true, "bestätigt " .. tostring(conf.date) end); status = "OK"
        else T:Client(c.id, c.area, c.name, a.how); status = "CLIENT" end
    elseif a == nil then
        T:Check(c.id, c.area, c.name, function() return false, "keine Rückgabe (Fehler im Testfall)", "ok, ergebnis" end)
        status = "FEHLER"
    else
        local r1 = a and true or false
        T:Check(c.id, c.area, c.name, function() return r1, b ~= nil and Plain(b) or nil, cc ~= nil and Plain(cc) or nil end)
        status = r1 and "OK" or "FEHLER"
    end
    run.statuses[c.id] = status
end

local function Traceback(e)
    return tostring(e)
end

local Tick                       -- forward
local function EndCase(run)
    local cur = run.cur
    if not cur then return end
    run.cur = nil
    Unwind(run, cur.mark)
    if cur.errs then ErrorsRestore(cur.errs) end
    if GameTooltip and GameTooltip:IsShown() then GameTooltip:Hide() end
end

local function Execute(run, c, fn)
    local res = { xpcall(fn, Traceback) }
    if res[1] and Marker(res[2], "wait") then
        local w = res[2]
        if run.sync then return Execute(run, c, w.fn) end
        run.waiting = true
        C_Timer.After(w.sec or STEP_DELAY, function()
            if run.finished or run.cur == nil or run.cur.c ~= c then return end
            run.waiting = false
            if run.aborted then
                Record(run, c, { true, SKIP(run.aborted) })
                EndCase(run)
            else
                Execute(run, c, w.fn)
                if not run.waiting then EndCase(run) end
            end
            if not run.waiting then Tick(run) end
        end)
        return
    end
    Record(run, c, res)
end

local function StartCase(run, c)
    run.cur = { c = c, mark = #run.stack, errs = c.errors and ErrorsSnapshot() or nil }
    -- every case starts from the same simulation and gets it back afterwards
    Stub(ns, "Sim", ns.Sim, "ns.Sim")
    Execute(run, c, c.fn)
    if not run.waiting then EndCase(run) end
end

local Finish                     -- forward

local function StepOnce(run)
    if run.finished or run.waiting then return end
    if run.aborted then Finish(run); return end
    run.qi = run.qi + 1
    local c = run.queue[run.qi]
    if not c then Finish(run); return end
    StartCase(run, c)
    if not run.sub and (run.qi % 10 == 0 or run.qi == #run.queue) then
        ns.Print(string.format(L.TR_PROGRESS, run.qi, #run.queue, c.id .. " " .. c.name))
    end
end

local inTick, again = false, false
Tick = function(run)
    if run.sync then return end
    if inTick then again = true; return end
    inTick = true
    repeat
        again = false
        StepOnce(run)
        if not run.finished and not run.waiting then C_Timer.After(STEP_DELAY, function() Tick(run) end) end
    until not again
    inTick = false
end

---------------------------------------------------------------------------
-- Finish: rollback, sandbox (T04), watchers (T03), names (T158), report
---------------------------------------------------------------------------
local function RestoreUI(run)
    local u = run.ui
    ns.Sim = run.sim
    local sb = SearchBox()
    if sb and Text(sb) ~= (u.search or "") then sb:SetText(u.search or "") end
    local mc = MissingCheck()
    if mc and ns.db and ns.db.filters then mc:SetChecked(ns.db.filters.missing) end
    local tw = _G.ProfessionSentinelTestMode
    if tw and tw:IsShown() ~= u.testShown then tw:SetShown(u.testShown) end
    local gf = _G.ProfessionSentinelGoalFrame
    if gf and gf:IsShown() ~= u.goalShown then gf:SetShown(u.goalShown) end
    for i = 1, 4 do
        local f = _G["StaticPopup" .. i]
        if f and f:IsShown() and tostring(f.which or ""):find("^PROFESSIONSENTINEL") then f:Hide() end
    end
    if ns.UI then
        if u.panelShown then ns.UI:Show(ActiveHost()) else ns.UI:Hide() end
    end
    if GameTooltip then GameTooltip:Hide() end
    if ns.RefreshAll then pcall(ns.RefreshAll) end
end

local function Sandbox(run)
    local db = ProfessionSentinelDB
    local snap = run.snapshot
    -- allowed: real game events during the run (new learned recipes, rank changes of this character)
    local real = 0
    local liveC = db.chars and db.chars[run.me]
    local snapC = snap.chars and snap.chars[run.me]
    local newKnown, liveProfs = {}, nil
    if type(liveC) == "table" and type(snapC) == "table" then
        for spell, v in pairs(liveC.known or {}) do
            if v == true and not (snapC.known and snapC.known[spell]) then newKnown[#newKnown + 1] = spell end
        end
        if Diff(snapC.profs, liveC.profs) then liveProfs = DeepCopy(liveC.profs) end
    end
    RestoreInPlace(db, snap, true)
    if type(db.chars) == "table" and type(db.chars[run.me]) == "table" then
        local c = db.chars[run.me]
        for _, s in ipairs(newKnown) do c.known[s] = true; real = real + 1 end
        if liveProfs then c.profs = liveProfs; real = real + 1 end
    end
    run.realChanges = real
    -- compare (the allowed changes applied to the snapshot)
    local want = DeepCopy(snap)
    if type(want.chars) == "table" and type(want.chars[run.me]) == "table" then
        for _, s in ipairs(newKnown) do want.chars[run.me].known[s] = true end
        if liveProfs then want.chars[run.me].profs = DeepCopy(liveProfs) end
    end
    local d = Diff(want, Snapshot(db))
    -- every replaced reference is the original one again
    local first = {}
    for _, e in ipairs(run.done) do
        first[e.t] = first[e.t] or {}
        first[e.t][e.k] = e
    end
    local badRef
    -- references only (globals, module fields, functions); data fields are compared through the saved variables
    local function isRef(e)
        if rawequal(e.t, ProfessionSentinelDB) then return false end
        return e.t == _G or e.t == ns or type(e.orig) == "function" or e.newFn
    end
    for t, keys in pairs(first) do
        for k, e in pairs(keys) do
            if isRef(e) then
                local now = rawget(t, k)
                if e.had and not rawequal(now, e.orig) then badRef = e.label
                elseif not e.had and now ~= nil then badRef = e.label end
            end
        end
    end
    if #run.stack > 0 then badRef = badRef or "Rückbau-Stapel nicht leer" end
    if #run.undoErrors > 0 then badRef = badRef or run.undoErrors[1] end
    local G2 = G()
    if G2 and G2.flavor ~= run.flavor and run.flavor then badRef = badRef or "Spielversion nicht zurück" end
    if ns.Flavor ~= run.flavor then badRef = badRef or "ns.Flavor nicht zurück" end
    run.sandboxOK = d == nil and badRef == nil
    run.sandboxText = run.sandboxOK and "OK" or ("FEHLER: " .. tostring(d or badRef))
    return run.sandboxOK
end

local function ReplacePlain(s, find, repl)
    local out, i = {}, 1
    while true do
        local a, b = s:find(find, i, true)
        if not a then break end
        out[#out + 1] = s:sub(i, a - 1)
        out[#out + 1] = repl
        i = b + 1
    end
    out[#out + 1] = s:sub(i)
    return table.concat(out)
end

local TEST_NAMES = { "Testa", "Testb", "Testc", "Testd", "Teste", "Vorname Nachname", "Erika Muster", "Mitglied1" }
local function PrivateNames()
    local out = {}
    local function add(n) if not ns.IsSecret(n) and type(n) == "string" and #n >= 3 then out[#out + 1] = n end end
    local okN, raw = pcall(UnitName, "player")
    if okN then add(raw) end
    add(ns.PlayerName())
    add(GetRealmName and GetRealmName() or nil)
    if IsInGuild and IsInGuild() and GetGuildInfo then add((GetGuildInfo("player"))) end
    for _, n in ipairs(TEST_NAMES) do add(n) end
    return out
end

local function Extra(run)
    local ab = {}
    for k, v in pairs(run.intercepted) do ab[#ab + 1] = k .. " ×" .. v end
    table.sort(ab)
    collectgarbage("collect")
    local mem1 = collectgarbage("count")
    local addonKB
    collectgarbage("collect")
    if UpdateAddOnMemoryUsage then pcall(UpdateAddOnMemoryUsage) end
    local getMem = ns.API.GetAddOnMemoryUsage or ns.API.AddOnsGetAddOnMemoryUsage
    if getMem then local ok, kb = pcall(getMem, ADDON); if ok then addonKB = kb end end
    local perf = {}
    for id, ms in pairs(run.perf) do perf[id] = math.floor(ms * 10 + 0.5) / 10 end
    return {
        sandbox = run.sandboxText, abgefangen = ab, waechter = run.guards, leistung = perf,
        speicher = { vorher_kb = math.floor(run.mem0), nachher_kb = math.floor(mem1), addon_kb = addonKB and math.floor(addonKB) or nil },
        warnungen = run.warnings, api_simulation = run.api and "ja" or "nein", modus = run.opts.filter or "alles",
        abgebrochen = run.aborted, echte_aenderungen = run.realChanges,
    }, mem1
end

local function FinalCases(run)
    local T = run.T
    -- deferred cases (T145): memory after the rollback, with the run's own copies released first
    -- (rollback entries with their saved originals, the snapshot of the saved variables, the error snapshot
    -- of the last case), then two full cycles
    if #run.deferred > 0 then
        run.done, run.snapshot, run.cur = {}, nil, nil
        for k in pairs(run.perfSamples or {}) do run.perfSamples[k] = nil end
        if GameTooltip and GameTooltip.ClearLines then GameTooltip:ClearLines() end
        collectgarbage("collect"); collectgarbage("collect")
        local total = collectgarbage("count") - (run.mem0 or 0)
        for _, d in ipairs(run.deferred) do
            local ok, a, b, c = pcall(d.fn, total)
            Record(run, d.c, { ok, a, b, c })
        end
    end
    -- T158: no names in the report (checked on a preview of the finished report)
    local names = PrivateNames()
    local extra = Extra(run)
    local okP, preview = pcall(T.Report, T, extra)
    local GT = _G.GoldSentinelTest
    local hit
    if okP then
        local text = T:Text(preview) .. "\n" .. GT.Encode(preview)
        for _, n in ipairs(names) do if text:find(n, 1, true) then hit = true end end
    end
    T:Check("T158", "J", byId.T158.name, function()
        if not okP then return false, "Vorschau nicht möglich", "Bericht ohne Namen" end
        return not hit, hit and "Name im Bericht gefunden (wird ersetzt)" or ("geprüft gegen " .. #names .. " Namen"), "keine Namen"
    end)
    -- T04 sandbox
    T:Check("T04", "A", byId.T04.name, function()
        return run.sandboxOK, run.sandboxText .. (run.realChanges and run.realChanges > 0 and (" · echte Änderungen durch das Spiel: " .. run.realChanges) or ""), "OK"
    end)
    -- T03 watchers (last case of every run)
    T:Check("T03", "A", byId.T03.name, function()
        local list = {}
        for k, v in pairs(run.guards) do if v > 0 and not k:find(":", 1, true) then list[#list + 1] = k .. " ×" .. v end end
        table.sort(list)
        return #list == 0, #list == 0 and (#GUARDS .. " Wächter, alle 0") or table.concat(list, ", "), "alle 0"
    end)
    return names
end

local function Header()
    local m = ns.DataMeta or {}
    return string.format("ProfessionSentinel %s · Sprache %s · Daten %s Build %s · %s", tostring(ns.VERSION),
        tostring(GetLocale and GetLocale() or "?"), tostring(m.flavor), tostring(m.build), date and date("%d.%m.%Y %H:%M") or "?")
end

local function ExtraText(run, extra)
    local out = {}
    if run.aborted then out[#out + 1] = "ABGEBROCHEN: " .. run.aborted end
    out[#out + 1] = "Abgefangene Aktionen: " .. (#extra.abgefangen > 0 and table.concat(extra.abgefangen, " · ") or "keine")
    local g = {}
    for k, v in pairs(run.guards) do if not k:find(":", 1, true) then g[#g + 1] = k .. " " .. v end end
    table.sort(g)
    out[#out + 1] = "Wächter: " .. (#g > 0 and table.concat(g, " · ") or (#GUARDS .. " Funktionen, keine Aufrufe"))
    local p = {}
    for id, ms in pairs(extra.leistung) do p[#p + 1] = id .. " " .. ms .. " ms" end
    table.sort(p)
    out[#out + 1] = "Leistung (langsamster Wert): " .. (#p > 0 and table.concat(p, " · ") or "–")
    out[#out + 1] = string.format("Speicher: vorher %d KB · nachher %d KB%s", extra.speicher.vorher_kb, extra.speicher.nachher_kb,
        extra.speicher.addon_kb and (" · Addon " .. extra.speicher.addon_kb .. " KB") or "")
    if #run.warnings > 0 then out[#out + 1] = "Warnungen: " .. table.concat(run.warnings, " · ") end
    out[#out + 1] = "API-Simulation: " .. extra.api_simulation .. " · Modus: " .. extra.modus
    return table.concat(out, "\n")
end

Finish = function(run)
    if run.finished then return end
    run.finished = true
    local reason = run.aborted
    -- the case in progress and the rest of the queue: skipped with the reason
    if run.cur then
        Record(run, run.cur.c, { true, SKIP(reason or "abgebrochen") })
        EndCase(run)
    end
    if reason then
        for i = run.qi + 1, #run.queue do
            local c = run.queue[i]
            run.T:Skip(c.id, c.area, c.name, reason)
            run.statuses[c.id] = "SKIP"
        end
    end
    -- rollback of everything, then the real data and the UI
    Unwind(run, 0)
    pcall(RestoreUI, run)          -- first the UI (a refresh may create lazy tables such as favor), then the data
    Sandbox(run)
    if run.combatFrame then run.combatFrame:UnregisterAllEvents() end
    local names = FinalCases(run)
    local extra = Extra(run)
    local text, rep = run.T:Finish(extra)
    run.report = rep
    -- safety net: names never stay in the report
    if not run.sub then
        local s = ProfessionSentinelDB.gsTest
        local last = s and s.reports and #s.reports
        for _, n in ipairs(names) do
            text = ReplacePlain(text, n, "<Name>")
            if last and last > 0 and s.reports[last]:find(n, 1, true) then s.reports[last] = ReplacePlain(s.reports[last], n, "<Name>") end
        end
    end
    text = Header() .. "\n" .. text .. "\n" .. ExtraText(run, extra)
    run.text = text
    -- pop the run
    for i = #runs, 1, -1 do if runs[i] == run then table.remove(runs, i) end end
    if run.sub then return end
    lastText = text
    local db = ProfessionSentinelDB
    if type(db.gsTest) == "table" then db.gsTest.lastTest = time and time() or 0 end
    db.autotest = type(db.autotest) == "table" and db.autotest or {}
    db.autotest.last = text
    db.autotest.history = type(db.autotest.history) == "table" and db.autotest.history or {}
    local c = rep.counts
    table.insert(db.autotest.history, 1, { date = date("%Y-%m-%d %H:%M"), verdict = reason and "ABGEBROCHEN" or (c.fehler == 0 and "BESTANDEN" or "FEHLER GEFUNDEN"),
        ok = c.ok, fail = c.fehler, errors = #(rep.errors or {}), version = ns.VERSION, flavor = ns.Flavor,
        secs = math.floor((rep.dur_ms or 0) / 100 + 0.5) / 10 })
    while #db.autotest.history > 10 do table.remove(db.autotest.history) end
    if reason then ns.Print(reason == "Kampf" and L.TR_ABORTED_COMBAT or L.TR_STOPPED) end
    ns.Print(string.format(L.TR_DONE, c.ok, c.fehler, c.uebersprungen, c.client))
    -- honest counting: everything that did not run automatically, and the fixed list for the player
    ns.Print(string.format(L.TR_NOT_AUTOMATED, (c.uebersprungen or 0) + (c.client or 0)))
    local list = {}
    for _, e in ipairs(rep.results or {}) do
        if e.status == "CLIENT" then list[#list + 1] = { id = e.id, name = e.name, how = e.anleitung } end
    end
    db.autotest.clientList = list
    if #list > 0 then ns.Print(string.format(L.TR_CLIENT_LIST_HINT, #list)) end
    ns.Print(L.TEST_REPORT_SAVED)
    ns.Print(L.TEST_RELOAD_NEEDED)                -- after every run (nachtrag-testroutinen Punkt 1)
    if run.opts.filter ~= "SELFTEST" and ns.AutoTest and ns.AutoTest.ShowReport then
        ns.AutoTest.ShowReport(text, L.TR_REPORT_TITLE, L.TR_REPORT_HINT)
    elseif run.opts.filter == "SELFTEST" then
        for _, e in ipairs(rep.results) do
            if e.status == "FEHLER" then ns.Print("|cffff4040" .. L.TEST_FAIL .. "|r " .. tostring(e.id) .. " " .. tostring(e.name) .. (e.ergebnis and (" – " .. e.ergebnis) or "") .. (e.lua and (" – " .. e.lua) or "")) end
        end
    end
end

---------------------------------------------------------------------------
-- Public
---------------------------------------------------------------------------
local combatFrame = CreateFrame("Frame")
combatFrame:SetScript("OnEvent", function() TR.OnCombat() end)

function TR.OnCombat()
    local r = Active()
    if r and not r.finished then r.aborted = "Kampf" end
end

function TR:IsRunning() return #runs > 0 end

function TR:Start(opts)
    if ns.InCombat() then ns.Print(L.TR_COMBAT); return end
    if #runs > 0 then
        local r = runs[1]
        ns.Print(string.format(L.TR_RUNNING, r.qi, #r.queue))
        return
    end
    if not ns.IsDev() then return end
    if not (ns.UI and ns.db and _G.GoldSentinelTest and ProfessionSentinelDB) then ns.Print(L.TR_MISSING_DEPS); return end
    InstallGuards()
    local run = NewRun(opts, false)
    runs[1] = run
    InstallIntercepts(run)
    run.combatFrame = combatFrame
    pcall(combatFrame.RegisterEvent, combatFrame, "PLAYER_REGEN_DISABLED")
    if (MerchantFrame and MerchantFrame:IsShown()) or (AuctionHouseFrame and AuctionHouseFrame:IsShown())
        or (AuctionFrame and AuctionFrame:IsShown()) then
        ns.Print(L.TR_SHOP_OPEN)
    end
    if run.api then ns.Print("|cffff8000" .. L.TR_API_WARN .. "|r") end
    ns.Print(string.format(L.TR_START, #run.queue + 3))
    Tick(run)
end

-- a synchronous sub-run inside a test case (T20, T110): its report goes to a throw-away table
function TR:RunSub(opts, hook)
    local run = NewRun(opts, true)
    runs[#runs + 1] = run
    local guard = 0
    while not run.finished and guard < 500 do
        guard = guard + 1
        StepOnce(run)
        if hook and not run.finished then hook(run, run.qi) end
    end
    if not run.finished then Finish(run) end
    return run
end

function TR:Stop()
    local r = Active()
    if not r then ns.Print(L.TR_NOT_RUNNING); return end
    r.aborted = "gestoppt"
    if not r.sync and not r.waiting and not inTick then Finish(r) end
end

function TR:ShowLast()
    local text = lastText or (ns.db and ns.db.autotest and ns.db.autotest.last)
    if not text then ns.Print(L.TR_NO_REPORT); return end
    if ns.AutoTest and ns.AutoTest.ShowReport then ns.AutoTest.ShowReport(text, L.TR_REPORT_TITLE, L.TR_REPORT_HINT) end
end

-- fixed list "check in the client" of the last run: what the player has to try in the game, and how to confirm it
function TR:ClientList()
    local list = ns.db and type(ns.db.autotest) == "table" and ns.db.autotest.clientList
    if type(list) ~= "table" or #list == 0 then ns.Print(L.TR_CLIENT_LIST_NONE); return 0 end
    ns.Print(string.format(L.TR_CLIENT_LIST_HEAD, #list))
    for _, e in ipairs(list) do
        ns.Print("|cffffd100" .. tostring(e.id) .. "|r " .. tostring(e.name) .. (e.how and (" – " .. tostring(e.how)) or ""))
    end
    ns.Print(L.TR_CLIENT_LIST_CONFIRM)
    return #list
end

-- /ps testroutine [a-j | api | stop | bericht | liste | ok <ID>]
function TR:Command(arg)
    arg = strtrim and strtrim(tostring(arg or "")) or tostring(arg or "")
    local low = arg:lower()
    if low == "" or low == "alles" or low == "all" then self:Start({})
    elseif low == "stop" then self:Stop()
    elseif low == "bericht" or low == "report" then self:ShowLast()
    elseif low == "liste" or low == "list" then self:ClientList()
    elseif low == "api" then self:Start({ filter = "API" })
    elseif low == "selftest" then self:Start({ filter = "SELFTEST" })
    elseif low:match("^[a-k]$") then self:Start({ filter = low:upper() })
    elseif low:match("^ok%s+t%d+$") then
        local id = "T" .. low:match("(%d+)$")
        if #id == 2 then id = "T0" .. id:sub(2) end
        if not byId[id] then ns.Print("? " .. id); return end
        ns.db.testConfirm = type(ns.db.testConfirm) == "table" and ns.db.testConfirm or {}
        ns.db.testConfirm[id] = { date = date("%Y-%m-%d") }
        ns.Print(id .. " – " .. byId[id].name .. ": OK")
    else
        ns.Print(L.TEST_HELP)
    end
end
