-- LevelPilot - oeffentliche Schnittstelle fuer andere Addons (LevelPilotAPI)
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- 3.12.44 (Wunsch ProfessionSentinel, Supervisor 15.11. 23:48):
--   LevelPilotAPI.NavigateTo(uiMapID, x, y, titel) -> true / false
--     uiMapID: Karte (C_Map), x/y: Kartenkoordinaten in Prozent (0-100), titel: Text des Schritts (optional).
--     LevelPilot fuehrt hin wie bei eigenen Zielen (Pfeil, Weg, Fluege/Schiffe; Ziel steht oben im Guide).
--     false, wenn die Angaben ungueltig sind oder LevelPilot fuer die Karte keine Weltkoordinaten kennt.
--   LevelPilotAPI.version: Nummer der Schnittstelle (1)

local _, LP = ...

local API = _G.LevelPilotAPI or {}
_G.LevelPilotAPI = API
API.version = 1

function API.NavigateTo(map, x, y, title)
    map, x, y = tonumber(map), tonumber(x), tonumber(y)
    if not (map and x and y) or x < 0 or x > 100 or y < 0 or y > 100 then return false end
    if not (LP.Geo and LP.Planner and LP.Planner.Replan) then return false end
    local i, n, w = LP.Geo:ToWorld(map, x, y)
    if not i then return false end
    local text = (type(title) == "string" and title ~= "") and title or LP.Geo:MapName(map)
    LP.Planner.priority = { t = "GOTO", map = map, x = x, y = y, inst = i, n = n, w = w, text = text,
                            key = ("PRIO:API:%d:%.1f:%.1f"):format(map, x, y) }
    LP.Planner:Replan()
    return true
end
