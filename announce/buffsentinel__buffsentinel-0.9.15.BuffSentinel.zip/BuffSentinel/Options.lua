-- BuffSentinel - Options.lua
-- Einstellungsfenster (komplett per Maus) und Minimap-Button

local ADDON, BS = ...
local L = BS.L
local C = BS.COLORS

local PAGES = {
    { key = "skill", label = L.SPEC_2 },
    { key = "proc",  label = "Procs" },
    { key = "buff",  label = "Buffs" },
    { key = "cd",    label = "Cooldowns" },
    { key = "dispel",label = L.DISPEL },
    { key = "opt",   label = L.OPTIONS },
    { key = "rec",   label = L.RECORDER },
}

local ZONE_LABELS = {
    { "world",     L.OPEN_WORLD },
    { "dungeon",   L.DUNGEONS },
    { "raid",      L.RAIDS },
    { "pvp",       L.BATTLEGROUNDS },
    { "resting",   L.CAPITAL_CITIES_INNS },
    { "sanctuary", L.SANCTUARIES },
}

local CONTENT_W = 560

------------------------------------------------------------------------
-- Kleine UI-Bausteine
------------------------------------------------------------------------
local function Tex(parent, layer, r, g, b, a)
    local t = parent:CreateTexture(nil, layer or "BACKGROUND")
    t:SetColorTexture(r, g, b, a or 1)
    return t
end

local function SetShownSafe(w, on)
    if on then w:Show() else w:Hide() end
end

local function FlatButton(parent, w, h, label)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(w, h)
    b.bg = Tex(b, "BACKGROUND", 0.18, 0.19, 0.24, 1)
    b.bg:SetAllPoints()
    b.hl = Tex(b, "HIGHLIGHT", 1, 0.65, 0.2, 0.20)
    b.hl:SetAllPoints()
    b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    b.text:SetPoint("CENTER")
    b.text:SetText(label or "")
    function b:SetLabel(t) self.text:SetText(t) end
    function b:SetActive(on)
        if on then self.bg:SetColorTexture(0.55, 0.33, 0.08, 1) else self.bg:SetColorTexture(0.18, 0.19, 0.24, 1) end
    end
    return b
end

local function CheckBox(parent)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(20, 20)
    b.box = Tex(b, "ARTWORK", 0.22, 0.23, 0.28, 1)
    b.box:SetAllPoints()
    b.check = b:CreateTexture(nil, "OVERLAY")
    b.check:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
    b.check:SetSize(26, 26)
    b.check:SetPoint("CENTER")
    local hl = Tex(b, "HIGHLIGHT", 1, 0.65, 0.2, 0.25)
    hl:SetAllPoints()
    function b:SetChecked(on) SetShownSafe(self.check, on) end
    function b:SetUsable(on) self:SetAlpha(on and 1 or 0.35) end
    return b
end

------------------------------------------------------------------------
-- Seiten mit Widget-Pool (wird bei jeder Aktualisierung neu befüllt)
------------------------------------------------------------------------
local function NewPage(parent, key)
    local scroll = CreateFrame("ScrollFrame", "BuffSentinelPage_" .. key, parent, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 14, -12)
    scroll:SetPoint("BOTTOMRIGHT", -32, 12)
    local child = CreateFrame("Frame", nil, scroll)
    child:SetSize(CONTENT_W, 10)
    scroll:SetScrollChild(child)
    scroll.child = child
    scroll.pool, scroll.used, scroll.y, scroll.toggles = {}, {}, 0, {}
    scroll:Hide()
    return scroll
end

local function ResetPage(p)
    p.y = 0
    p.toggles = {}
    for t, list in pairs(p.pool) do
        for _, w in ipairs(list) do w:Hide(); w:ClearAllPoints() end
        p.used[t] = 0
    end
end

local function Acquire(p, t, create)
    p.used[t] = (p.used[t] or 0) + 1
    p.pool[t] = p.pool[t] or {}
    local w = p.pool[t][p.used[t]]
    if not w then
        w = create(p.child)
        p.pool[t][p.used[t]] = w
    end
    w:Show()
    return w
end

local function FinishPage(p)
    p.child:SetHeight(math.max(10, p.y + 20))
end

local function AddHeader(p, text)
    local fs = Acquire(p, "header", function(parent)
        local f = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        f:SetJustifyH("LEFT")
        return f
    end)
    p.y = p.y + (p.y > 0 and 10 or 0)
    fs:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
    fs:SetText(text)
    fs:SetTextColor(C.accent[1], C.accent[2], C.accent[3])
    p.y = p.y + 26
end

local function AddText(p, text, color, indent)
    local fs = Acquire(p, "text", function(parent)
        local f = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        f:SetJustifyH("LEFT")
        if f.SetWordWrap then f:SetWordWrap(true) end
        return f
    end)
    indent = indent or 0
    fs:SetWidth(CONTENT_W - indent)
    fs:SetPoint("TOPLEFT", p.child, "TOPLEFT", indent, -p.y)
    fs:SetText(text)
    color = color or C.text
    fs:SetTextColor(color[1], color[2], color[3])
    p.y = p.y + math.max(14, fs:GetStringHeight()) + 6
end

local function AddButton(p, label, w, onClick, x, keepY)
    local b = Acquire(p, "button", function(parent) return FlatButton(parent, 120, 24, "") end)
    b:SetSize(w or 160, 24)
    b:SetLabel(label)
    b:SetActive(false)
    b:SetPoint("TOPLEFT", p.child, "TOPLEFT", x or 0, -p.y)
    b:SetScript("OnClick", onClick)
    if not keepY then p.y = p.y + 30 end
    return b
end

-- enabled (optional): Funktion; liefert sie false, ist der Schalter ausgegraut und nicht klickbar
local function AddToggle(p, label, get, set, indent, enabled)
    local row = Acquire(p, "toggle", function(parent)
        local r = CreateFrame("Button", nil, parent)
        r:SetSize(CONTENT_W, 22)
        r.cb = CheckBox(r)
        r.cb:SetPoint("LEFT", 0, 0)
        r.cb:EnableMouse(false)
        r.text = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        r.text:SetPoint("LEFT", r.cb, "RIGHT", 10, 0)
        local hl = Tex(r, "HIGHLIGHT", 1, 1, 1, 0.04)
        hl:SetAllPoints()
        return r
    end)
    row:SetPoint("TOPLEFT", p.child, "TOPLEFT", indent or 0, -p.y)
    row.text:SetText(label)
    row.cb:SetChecked(get())
    local on = not enabled or enabled() ~= false
    row:SetAlpha(on and 1 or 0.45)
    row:SetScript("OnClick", function()
        if enabled and enabled() == false then return end
        set(not get())
        row.cb:SetChecked(get())
    end)
    row.get = get
    row.enabled = on
    -- für die Testroutine: alle Schalter der Seite (wird bei jedem Neuaufbau geleert)
    p.toggles[#p.toggles + 1] = { row = row, label = label }
    p.y = p.y + 26
end

-- Zeile für einen Buff/Proc/Cooldown-Eintrag
local function CreateEntryRow(parent)
    local r = CreateFrame("Frame", nil, parent)
    r:SetSize(CONTENT_W, 46)
    r.bg = Tex(r, "BACKGROUND", 1, 1, 1, 0.035)
    r.bg:SetAllPoints()
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(34, 34)
    r.icon:SetPoint("LEFT", 6, 0)
    r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    r.name:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 10, -2)
    r.name:SetJustifyH("LEFT")
    r.status = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    r.status:SetPoint("BOTTOMLEFT", r.icon, "BOTTOMRIGHT", 10, 2)
    r.status:SetJustifyH("LEFT")
    r.status:SetWidth(300)
    r.cb = CheckBox(r)
    r.cb:SetPoint("RIGHT", -12, 0)
    r.mode = FlatButton(r, 96, 22, "")
    r.mode:SetPoint("RIGHT", r.cb, "LEFT", -14, 0)
    -- eigene Klingel für diesen Eintrag
    r.bell = FlatButton(r, 62, 22, "")
    r.bell:SetScript("OnEnter", function(self)
        BS.TipBeside(self, BS.optionsFrame or self)       -- neben dem Fenster: verdeckt keine Zeile (T140)
        GameTooltip:AddLine(L.BELL, 1, 0.82, 0)
        GameTooltip:AddLine(L.OWN_SOUND_FOR_THIS_ENTRY, 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end)
    r.bell:SetScript("OnLeave", function() GameTooltip:Hide() end)
    -- "Auto": manuelle Änderung verwerfen, zurück zur automatischen Auswahl nach Skillung
    r.auto = FlatButton(r, 52, 22, "Auto")
    r.auto:SetScript("OnEnter", function(self)
        BS.TipBeside(self, BS.optionsFrame or self)
        GameTooltip:AddLine(L.BACK_TO_DEFAULT, 1, 0.82, 0)
        GameTooltip:AddLine(L.BUFFSENTINEL_DECIDES_AGAIN_BASED_ON, 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    r.auto:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return r
end

local function AddEntryRow(p, e)
    local r = Acquire(p, "entry", CreateEntryRow)
    r:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
    r.icon:SetTexture(e.icon)
    r.icon:SetDesaturated(not e.known)

    local tags = ""
    if e.data.forever then tags = tags .. "  |cff66ccff[Forever]|r" end
    if e.data.group then tags = tags .. L.GROUP_3 end
    if e.data.spellBySpec and e.spellName and e.data.label then
        tags = tags .. "  |cffaaaaaa» " .. e.spellName .. "|r"
    end
    r.name:SetText(e.label .. tags)
    r.name:SetTextColor(e.known and 1 or 0.55, e.known and 1 or 0.55, e.known and 1 or 0.6)

    local status = e.status or ""
    if e.manual then status = status .. L.MANUAL_PREFIX .. (e.enabled and L.ON or L.OFF) .. ")|r" end
    r.status:SetText(status)
    local col = e.statusColor or C.dim
    r.status:SetTextColor(col[1], col[2], col[3])

    r.cb:SetChecked(e.enabled)
    r.cb:SetUsable(e.known)
    r.cb:SetScript("OnClick", function()
        if not e.known then return end
        BS:SetEntrySetting(e.key, "enabled", not e.enabled)
    end)

    if e.kind == "buff" then
        r.mode:Show()
        r.mode:SetLabel(e.mode == "combat" and L.COMBAT_ONLY or L.ALWAYS)
        r.mode:SetScript("OnClick", function()
            BS:SetEntrySetting(e.key, "mode", e.mode == "combat" and "always" or "combat")
        end)
    else
        r.mode:Hide()
    end

    r.bell:ClearAllPoints()
    r.bell:SetPoint("RIGHT", (e.kind == "buff") and r.mode or r.cb, "LEFT", -10, 0)
    r.bell:SetLabel(e.bell and L.SOUND_ON or L.SOUND_OFF)
    r.bell:SetActive(e.bell)
    r.bell:SetScript("OnClick", function() BS:SetEntrySetting(e.key, "bell", not e.bell) end)

    r.auto:ClearAllPoints()
    r.auto:SetPoint("RIGHT", r.bell, "LEFT", -8, 0)
    if e.manual then
        r.auto:Show()
        r.auto:SetScript("OnClick", function() BS:SetEntrySetting(e.key, "enabled", nil) end)
    else
        r.auto:Hide()
    end
    p.y = p.y + 50
end

------------------------------------------------------------------------
-- Seiteninhalte
------------------------------------------------------------------------
local Fill = {}

function Fill.skill(p)
    AddHeader(p, L.DETECTED_SPEC)
    AddText(p, "|cffffffff" .. BS:SpecText() .. "|r   |cff888888" .. (BS.FLAVOR_NAMES[BS.flavor] or BS.flavor) .. "|r", C.text)
    if BS.isRetail then
        AddText(p, L.RETAIL_MIDNIGHT_BLIZZARD_MAKES_BUFFS ..
            L.PROCS_AND_COOLDOWNS_IN_COMBAT, C.yellow)
    end

    local data = BS.ClassData[BS.class]
    for tab = 1, (BS.family == "classic") and 3 or 0 do
        local pts = BS.points[tab] or 0
        local bar = Acquire(p, "bar", function(parent)
            local f = CreateFrame("Frame", nil, parent)
            f:SetSize(CONTENT_W, 18)
            f.bg = Tex(f, "BACKGROUND", 0.16, 0.17, 0.21, 1)
            f.bg:SetPoint("LEFT", 130, 0); f.bg:SetSize(300, 12)
            f.fill = Tex(f, "ARTWORK", 1, 0.65, 0.2, 1)
            f.fill:SetPoint("LEFT", f.bg, "LEFT"); f.fill:SetHeight(12)
            f.name = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            f.name:SetPoint("LEFT", 0, 0)
            f.val = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            f.val:SetPoint("LEFT", f.bg, "RIGHT", 10, 0)
            return f
        end)
        bar:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
        bar.name:SetText(BS:SpecName(tab) or (L.TREE .. tab))
        bar.fill:SetWidth(math.max(1, 300 * math.min(pts, 51) / 51))
        if tab == BS.mainSpec then bar.fill:SetColorTexture(1, 0.65, 0.2, 1) else bar.fill:SetColorTexture(0.5, 0.5, 0.55, 1) end
        bar.val:SetText(pts .. L.POINTS .. (tab == BS.mainSpec and L.MAIN_TREE or ""))
        p.y = p.y + 22
    end
    if BS.family == "modern" then
        AddText(p, L.TALENTS_ARE_CHECKED_BY_THEIR, C.dim)
    elseif not BS.talentsReadable then
        AddText(p, L.TALENTS_COULD_NOT_BE_READ, C.yellow)
    end

    local c = BS:CountActive()
    AddHeader(p, L.ADJUSTED_AUTOMATICALLY)
    AddText(p, string.format(L.ACTIVE_FOR_THIS_SPEC_PROCS ..
        L.THE_BUTTONS_ARE_SWITCHED_AUTOMATICALLY, c.proc, c.buff, c.cd), C.text)
    local overrides = BS:CountOverrides()
    if overrides > 0 then
        AddText(p, overrides .. L.ENTRIES_WERE_CHANGED_MANUALLY_FOR, C.dim)
        AddButton(p, L.RESTORE_RECOMMENDATION, 220, function() BS:ResetEntrySettings() end)
    end
    AddButton(p, L.RE_READ_SPEC, 220, function() BS:FullScan() end)

    -- Talente, auf die BuffSentinel reagiert
    local shown = false
    for _, e in ipairs(BS.entries) do
        local d = e.data
        local list = d.talents or e.enableList
        local spellList = d.talentSpell or d.enableIfTalentSpell
        if not list and spellList then
            if not shown then AddHeader(p, L.TALENTS_THAT_AFFECT_THE_BUTTONS); shown = true end
            local what = d.talentSpell and L.UNLOCKS or L.ALSO_ENABLES
            local match = d.talentSpell and e.talentMatch or e.viaTalent
            local first = type(spellList) == "table" and spellList[1] or spellList
            if match then
                AddText(p, "|TInterface\\RaidFrame\\ReadyCheck-Ready:14:14|t  " .. match .. "  –  " .. what .. e.label, C.text, 6)
            else
                AddText(p, "–  " .. ((BS.SpellInfo(first)) or ("Talent " .. first)) .. L.NOT_LEARNED_2 .. what .. e.label, C.dim, 6)
            end
        end
        if list then
            if not shown then AddHeader(p, L.TALENTS_THAT_AFFECT_THE_BUTTONS); shown = true end
            local match = BS:HasTalent(list)
            local what = d.talents and L.UNLOCKS or L.ALSO_ENABLES
            if match then
                AddText(p, "|TInterface\\RaidFrame\\ReadyCheck-Ready:14:14|t  " .. match .. "  –  " .. what .. e.label, C.text, 6)
            else
                local loc = BS:ResolveTalentList(list) or list[1]
                AddText(p, "–  " .. loc .. L.NOT_LEARNED_2 .. what .. e.label, C.dim, 6)
            end
        end
    end

    -- Namen in der Client-Sprache (gelernt, geteilt oder manuell zugeordnet)
    local lists = BS.nameIndex and BS.nameIndex.lists[BS.class]
    if lists and #lists > 0 and BS.talentsReadable then
        AddHeader(p, L.TALENT_AND_ABILITY_NAMES)
        AddText(p, L.IF_A_NAME_IS_ONLY ..
            L.ON_THE_SERVER_IF_NOBODY, C.dim)
        for _, item in ipairs(lists) do
            local en = item.names[1]
            local loc, how, _, from = BS:ResolveTalentList(item.names)
            if not loc and item.what == L.ABILITY then
                local sp = BS:LocalSpellName(en)
                if sp then loc, how = sp, L.SPELL_ID end
            end
            local line
            if loc and how == "direkt" then
                line = "|TInterface\\RaidFrame\\ReadyCheck-Ready:14:14|t  " .. loc .. "  |cff888888(" .. item.what .. L.FOUND_IN_THE_CLIENT
            elseif loc then
                local howText = (how == "gelernt" and L.HOW_LEARNED) or (how == "manuell" and L.HOW_MANUAL) or how
                local src = howText .. (from and (L.FROM_ .. from) or "")
                line = "|TInterface\\RaidFrame\\ReadyCheck-Ready:14:14|t  " .. en .. " = |cffffffff" .. loc .. "|r  |cff888888(" .. src .. ")|r"
            else
                line = "|cffffd040?|r  " .. en .. "  |cff888888(" .. item.what .. L.STILL_UNKNOWN
            end
            AddText(p, line, C.text, 6)
            p.y = p.y - 6
            if not loc or how == "manuell" then
                if how == "manuell" then
                    AddButton(p, L.REMOVE_ASSIGNMENT, 170, function() BS:UnassignTalent(en) end, 380, true)
                else
                    local open = BS.assigning == en
                    local b = AddButton(p, open and L.CANCEL or L.ASSIGN, 170, function()
                        BS.assigning = (BS.assigning ~= en) and en or nil
                        BS:RefreshOptions()
                    end, 380, true)
                    b:SetActive(open)
                end
                p.y = p.y + 28
            else
                p.y = p.y + 8
            end
            if BS.assigning == en then
                AddText(p, L.WHICH_TALENT_IN_YOUR_CLIENT .. en .. "\"?", C.yellow, 12)
                for tab = 1, 3 do
                    local col = 0
                    local any = false
                    for _, t in ipairs(BS.allTalents) do
                        if t.tab == tab then
                            if not any then
                                AddText(p, "|cffffa733" .. (BS:SpecName(tab) or (L.TREE .. tab)) .. "|r", C.text, 12)
                                any = true
                            end
                            local pos = t.pos
                            AddButton(p, t.name, 176, function() BS:AssignTalent(en, pos) end, 12 + col * 182, true)
                            col = col + 1
                            if col == 3 then col = 0; p.y = p.y + 28 end
                        end
                    end
                    if col > 0 then p.y = p.y + 28 end
                end
                p.y = p.y + 6
            end
        end
    end

    local nt, ns = BS:CountLearned()
    AddText(p, string.format(L.LEARNED_NAMES_ALL_CHARACTERS_TALENTS,
        nt, ns,
        BS:SyncStatusText(),
        BS.gdb.shareNames and ("|cff66dd77" .. L.ON .. "|r") or ("|cffff5555" .. L.OFF .. "|r")), C.dim)

    AddHeader(p, L.ALL_LEARNED_TALENTS)
    if #BS.talentList == 0 then
        AddText(p, BS.isRetail and L.IN_RETAIL_TALENTS_ARE_CHECKED or L.NO_TALENT_POINTS_SPENT_YET, C.dim)
    elseif BS.family == "modern" then
        local parts = {}
        for _, t in ipairs(BS.talentList) do tinsert(parts, t.name) end
        AddText(p, table.concat(parts, ",  "), C.text)
    else
        for tab = 1, 3 do
            local parts = {}
            for _, t in ipairs(BS.talentList) do
                if t.tab == tab then tinsert(parts, t.name .. " " .. t.rank .. "/" .. t.maxRank) end
            end
            if #parts > 0 then
                AddText(p, "|cffffa733" .. (BS:SpecName(tab) or (L.TREE .. tab)) .. ":|r  " .. table.concat(parts, ",  "), C.text)
            end
        end
    end
    if not data then
        AddText(p, L.THERE_IS_NO_PREPARED_DATA, C.yellow)
    end
end

local KIND_TEXT = {
    proc = L.A_PROC_BUTTON_APPEARS_IN,
    buff = L.WHEN_A_BUFF_RUNS_OUT,
    cd   = L.THE_COOLDOWN_BAR_SHOWS_YOUR,
}

local function FillEntries(p, kind)
    if BS.isRetail and kind ~= "buff" then
        AddHeader(p, L.NOT_AVAILABLE_IN_RETAIL)
        AddText(p, L.SINCE_MIDNIGHT_12_0_BUFFS ..
            L.AND_IN_WOW_FOREVER, C.yellow)
        return
    end
    AddText(p, KIND_TEXT[kind], C.dim)
    if BS:Locked() and not BS.isRetail and kind ~= "buff" then
        -- WoW Forever: im Kampf keine Anzeige, Reinigen-Raster aus, Procs werden nicht gelernt
        AddText(p, BS:LockedText(), C.yellow)
    end
    -- Einteilung "aktiv / weitere" einfrieren, solange die Seite offen ist: ein Häkchen soll den Eintrag
    -- nicht wegspringen lassen (sonst trifft der nächste Klick einen anderen Eintrag).
    -- Neu sortiert wird beim Seitenwechsel oder erneuten Öffnen.
    BS.listFreeze = BS.listFreeze or {}
    local freeze = BS.listFreeze[kind]
    if not freeze or freeze.spec ~= BS.mainSpec or freeze.class ~= BS.class then
        freeze = { spec = BS.mainSpec, class = BS.class, keys = {} }
        for _, e in ipairs(BS.entries) do
            if e.kind == kind then freeze.keys[e.key] = e.enabled end
        end
        BS.listFreeze[kind] = freeze
    end
    local active, other = {}, {}
    for _, e in ipairs(BS.entries) do
        if e.kind == kind and not e.data.enemyDispel then
            local inActive = freeze.keys[e.key]
            if inActive == nil then inActive = e.enabled end
            if inActive then tinsert(active, e) else tinsert(other, e) end
        end
    end
    AddHeader(p, L.ACTIVE_FOR .. (BS:SpecName(BS.mainSpec) or L.YOUR_SPEC))
    if #active == 0 then AddText(p, L.NO_ENTRIES_ACTIVE, C.dim) end
    for _, e in ipairs(active) do AddEntryRow(p, e) end
    if #other > 0 then
        AddHeader(p, L.MORE_NOT_ACTIVE)
        for _, e in ipairs(other) do AddEntryRow(p, e) end
    end
    if kind == "proc" and not BS:Locked() then
        AddText(p, L.BUFFSENTINEL_LEARNS_NEW_PROCS_E, C.dim)
    end
    -- Locked (WoW Forever): der Hinweis BS:LockedText() steht schon oben auf der Seite (auch "Procs werden nicht
    -- automatisch gelernt") – nicht ein zweites Mal wiederholen.
    if kind == "buff" and #BS:GroupEntries() > 0 then
        AddButton(p, L.OPEN_GROUP_GRID, 220, function() BS:ToggleRaster() end)
    end
end

function Fill.dispel(p)
    local db = BS.db
    AddHeader(p, L.DISPEL_GROUP_MEMBERS)
    if BS:Locked() and not BS.isRetail then
        AddText(p, BS:LockedText(), C.yellow)
        return
    end
    if BS.isRetail then
        AddText(p, L.IN_RETAIL_MIDNIGHT_DEBUFFS_ARE, C.yellow)
        return
    end
    AddText(p, L.IF_A_GROUP_MEMBER_HAS ..
        L.EACH_DISPEL_SPELL_IS_ON, C.dim)
    AddToggle(p, L.SHOW_DISPEL_BAR, function() return db.dispel.friendly end,
        function(v) db.dispel.friendly = v; BS:SettingsChanged() end)
    AddToggle(p, L.ALERT_SOUND_FOR_A_NEW, function() return (BS:SoundSetting("dispel")) end,
        function(v) BS:SetSoundSetting("dispel", "on", v) end)

    local lines = BS:DispelSummary()
    if #lines == 0 then
        AddText(p, L.YOUR_CLASS_SPEC_CANNOT_DISPEL, C.dim)
    else
        AddText(p, L.YOUR_DISPEL_SPELLS .. (BS:SpecName(BS.mainSpec) or "") .. "):", C.text)
        for _, l in ipairs(lines) do AddText(p, "•  " .. l, C.text, 10) end
    end
    AddText(p, L.IMPORTANT_RAID_DEBUFFS_E_G ..
        L.VAMPIRIC_TOUCH_MUTATING_INJECTION_ARE, C.dim)
    AddText(p, L.MOVE_ARRANGE_BUTTON_AT_THE, C.dim)

    AddHeader(p, L.PURGE_ENEMIES)
    AddText(p, L.IF_YOUR_TARGET_HAS_A ..
        L.THEREFORE_ALSO_WORKS_IN_THE, C.dim)
    local any = false
    for _, e in ipairs(BS.entries) do
        if e.data.enemyDispel then AddEntryRow(p, e); any = true end
    end
    if not any then
        AddText(p, L.YOUR_CLASS_HAS_NO_ABILITY, C.dim)
    end
end

function Fill.proc(p) FillEntries(p, "proc") end
function Fill.buff(p) FillEntries(p, "buff") end
function Fill.cd(p)   FillEntries(p, "cd") end

------------------------------------------------------------------------
-- Warntöne: Auswahlfenster mit allen Tönen
------------------------------------------------------------------------
local picker
local function ShowSoundPicker(kind)
    if not picker then
        local f = CreateFrame("Frame", "BuffSentinelSoundPicker", BS.optionsFrame)
        f:SetFrameStrata("FULLSCREEN_DIALOG")
        f:SetSize(600, 470)
        f:SetPoint("CENTER", BS.optionsFrame, "CENTER", 60, 0)
        f:EnableMouse(true)
        local bg = Tex(f, "BACKGROUND", 0.06, 0.07, 0.09, 0.98); bg:SetAllPoints()
        local line = Tex(f, "BORDER", 1, 0.65, 0.2, 1)
        line:SetPoint("TOPLEFT"); line:SetPoint("TOPRIGHT"); line:SetHeight(2)
        f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        f.title:SetPoint("TOPLEFT", 12, -10)
        f.hint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        f.hint:SetPoint("TOPLEFT", 12, -32)
        f.hint:SetText(L.LEFT_CLICK_SELECT_AND_LISTEN)
        f.hint:SetTextColor(0.7, 0.7, 0.75)
        local close = FlatButton(f, 26, 26, "×")
        close:SetPoint("TOPRIGHT", -6, -6)
        close:SetScript("OnClick", function() f:Hide() end)
        local scroll = CreateFrame("ScrollFrame", "BuffSentinelSoundPickerScroll", f, "UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT", 12, -52)
        scroll:SetPoint("BOTTOMRIGHT", -32, 12)
        f.child = CreateFrame("Frame", nil, scroll)
        f.child:SetSize(550, 10)
        scroll:SetScrollChild(f.child)
        f.buttons, f.heads = {}, {}
        tinsert(UISpecialFrames, "BuffSentinelSoundPicker")
        picker = f
    end
    local f = picker
    f.kind = kind
    BS.soundListCache = nil   -- neu einlesen (LibSharedMedia-Töne anderer Addons)
    local def = BS.SOUND_KIND_BY_KEY[kind]
    f.title:SetText(L.SOUND_FOR .. (def and def.name or kind))
    local _, cur = BS:SoundSetting(kind)
    for _, b in ipairs(f.buttons) do b:Hide() end
    for _, h in ipairs(f.heads) do h:Hide() end
    local GROUP_NAMES = { Spiel = L.GAME_SOUNDS, Datei = L.BELLS_DRUMS_EFFECTS,
        SharedMedia = L.LIBSHAREDMEDIA_OTHER_ADDONS, Eigener = L.CUSTOM_FILE }
    local y, col, lastGroup, nb, nh = 0, 0, nil, 0, 0
    for _, item in ipairs(BS:SoundList()) do
        if item.group ~= lastGroup then
            if col > 0 then y = y + 26; col = 0 end
            nh = nh + 1
            local h = f.heads[nh]
            if not h then h = f.child:CreateFontString(nil, "OVERLAY", "GameFontNormal"); f.heads[nh] = h end
            h:ClearAllPoints(); h:SetPoint("TOPLEFT", 0, -y - 4)
            h:SetText(GROUP_NAMES[item.group] or item.group); h:Show()
            y = y + 24
            lastGroup = item.group
        end
        nb = nb + 1
        local b = f.buttons[nb]
        if not b then
            b = FlatButton(f.child, 176, 22, "")
            b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
            f.buttons[nb] = b
        end
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", col * 184, -y)
        b:SetLabel(item.name)
        b:SetActive(item.key == cur)
        local key = item.key
        b:SetScript("OnClick", function(_, button)
            if key == "custom" then
                local _, _, custom = BS:SoundSetting(f.kind)
                BS:SetSoundSetting(f.kind, "sound", "custom", custom)
                f:Hide()
                return
            end
            BS:PreviewSound(key)
            if button ~= "RightButton" then
                BS:SetSoundSetting(f.kind, "sound", key)
                ShowSoundPicker(f.kind)
            end
        end)
        b:Show()
        col = col + 1
        if col == 3 then col = 0; y = y + 26 end
    end
    if col > 0 then y = y + 26 end
    f.child:SetHeight(y + 10)
    f:Show()
end

local function AddSoundRow(p, def)
    local on, sound, custom, changed = BS:SoundSetting(def.key)
    local r = Acquire(p, "soundrow", function(parent)
        local f = CreateFrame("Frame", nil, parent)
        f:SetSize(CONTENT_W, 28)
        f.bg = Tex(f, "BACKGROUND", 1, 1, 1, 0.035); f.bg:SetAllPoints()
        f.cb = CheckBox(f); f.cb:SetPoint("LEFT", 6, 0)
        f.name = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        f.name:SetPoint("LEFT", 34, 0); f.name:SetWidth(250); f.name:SetJustifyH("LEFT")
        if f.name.SetWordWrap then f.name:SetWordWrap(false) end
        f.pick = FlatButton(f, 176, 22, "")
        f.pick:SetPoint("LEFT", 290, 0)
        f.test = FlatButton(f, 70, 22, L.LISTEN)
        f.test:SetPoint("RIGHT", -6, 0)
        return f
    end)
    r:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
    r.cb:SetChecked(on)
    r.cb:SetScript("OnClick", function() BS:SetSoundSetting(def.key, "on", not on) end)
    r.name:SetText(def.name .. (changed and "  |cffffcc33•|r" or ""))
    r.name:SetTextColor(on and 1 or 0.6, on and 1 or 0.6, on and 1 or 0.65)
    local label = BS:SoundName(sound, custom)
    if #label > 24 then label = label:sub(1, 22) .. "…" end
    r.pick:SetLabel(label)
    r.pick:SetScript("OnClick", function() ShowSoundPicker(def.key) end)
    r.test:SetScript("OnClick", function() BS:PreviewSound(sound, custom) end)
    p.y = p.y + 32
    -- eigene Sounddatei: Eingabefeld darunter
    if sound == "custom" then
        local e = Acquire(p, "soundedit", function(parent)
            local f = CreateFrame("Frame", nil, parent)
            f:SetSize(CONTENT_W, 26)
            f.lbl = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            f.lbl:SetPoint("LEFT", 34, 0)
            f.lbl:SetText(L.FILE_OR_ID)
            f.edit = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
            f.edit:SetSize(330, 20); f.edit:SetPoint("LEFT", 120, 0); f.edit:SetAutoFocus(false)
            f.edit:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
            return f
        end)
        e:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
        e.edit:SetText(custom or "")
        e.edit:SetScript("OnEnterPressed", function(s)
            s:ClearFocus()
            local v = strtrim(s:GetText() or "")
            BS:SetSoundSetting(def.key, "sound", "custom", v)
            if v ~= "" then BS:PreviewSound("custom", v) end
        end)
        p.y = p.y + 30
    end
end

function Fill.opt(p)
    local db = BS.db
    local className = (UnitClass and UnitClass("player")) or BS.class
    if BS.testClass then className = BS.testClass end

    if BS:Locked() and not BS.isRetail then
        AddHeader(p, L.NOTE)
        AddText(p, BS:LockedText(), C.yellow)
    end
    AddHeader(p, L.ALERT_SOUNDS)
    AddText(p, string.format(L.APPLIES_TO_EACH_SPEC_CAN,
        tostring(className), BS:SpecName(BS.mainSpec) or L.NO_SPEC), C.dim)
    for _, def in ipairs(BS.SOUND_KINDS) do AddSoundRow(p, def) end

    local hornBtn = AddButton(p, L.REPEAT_HORN_EVERY .. (db.hornEvery or 5) .. " s", 220, function()
        local steps = { 3, 5, 8, 10, 15, 20, 30, 60 }
        local nextV = steps[2]
        for i, v in ipairs(steps) do if v == (db.hornEvery or 5) then nextV = steps[i % #steps + 1] end end
        db.hornEvery = nextV
        BS:RefreshOptions()
    end, 0, true)
    hornBtn:SetActive(false)
    local chName = L.MASTER
    for _, c in ipairs(BS.SOUND_CHANNELS) do if c[1] == (db.soundChannel or "Master") then chName = c[2] end end
    AddButton(p, L.SOUND_CHANNEL .. chName, 200, function()
        local list, nextC = BS.SOUND_CHANNELS, BS.SOUND_CHANNELS[1][1]
        for i, c in ipairs(list) do if c[1] == (db.soundChannel or "Master") then nextC = list[i % #list + 1][1] end end
        db.soundChannel = nextC
        BS:RefreshOptions()
    end, 230)
    AddButton(p, L.APPLY_ALL_SOUNDS_TO_ALL, 300, function() BS:SoundApplyToAll() end, 0, true)
    AddButton(p, L.RESET_SPEC_TO_DEFAULT, 170, function() BS:SoundResetSpec() end, 310, true)
    AddButton(p, L.RESET_ALL, 70, function() BS:SoundResetAll() end, 490)
    AddText(p, L.THE_SOUND_CHANNEL_DECIDES_WHICH ..
        L.ONCE_ENTRIES_WITH_SOUND_ON ..
        L.CUSTOM_SOUND_PATH_HINT, C.dim)

    AddHeader(p, L.WHERE_SHOULD_BUFFSENTINEL_BE_ACTIVE)
    local ok, ctx = BS:GetContext()
    AddText(p, L.CURRENT .. (BS.CONTEXT_NAMES[ctx] or ctx) .. " – " ..
        (ok and "|cff66dd77aktiv|r" or "|cffff5555pausiert|r"), C.text)
    for _, z in ipairs(ZONE_LABELS) do
        AddToggle(p, z[2], function() return db.zones[z[1]] end,
            function(v) db.zones[z[1]] = v; BS:Refresh() end)
    end
    AddText(p, L.WHILE_FLYING_AS_A_GHOST, C.dim)

    AddHeader(p, L.COOLDOWNS_DISPEL)
    AddToggle(p, L.COOLDOWN_BAR_IN_THE_OPEN, function() return db.cdWorldCombatOnly end,
        function(v) db.cdWorldCombatOnly = v end)
    AddToggle(p, L.SHOW_REMAINING_TIME_ON_COOLDOWNS, function() return db.cdTimer end,
        function(v) db.cdTimer = v end)
    AddToggle(p, L.SHOW_DISPEL_BAR_FOR_GROUP, function() return db.dispel.friendly end,
        function(v) db.dispel.friendly = v; BS:SettingsChanged() end)

    AddHeader(p, L.AUTOMATIC_LEARNING)
    AddToggle(p, L.ADD_NEW_PROCS_AND_ABILITIES,
        function() return BS.gdb.auto.enabled end, function(v) BS:SetAutoLearn(v) end)
    AddToggle(p, L.SHARE_DISCOVERIES_WITH_OTHER_BUFFSENTINEL,
        function() return BS.gdb.auto.share end, function(v) BS.gdb.auto.share = v end)
    AddText(p, L.OVERVIEW_AND_REMOVAL_ON_THE, C.dim)

    local dev = BS:IsDev()
    AddHeader(p, L.DISPLAY_ARRANGE)
    AddText(p, L.ARRANGE_BUTTONS_SHOWS_ALL_YOUR ..
        L.THE_BAR_AT_THE_TOP, C.dim)
    local arrBtn = AddButton(p, BS.arrangeMode and L.STOP_ARRANGING or L.ARRANGE_BUTTONS, 170, function()
        BS:ToggleArrangeMode()
    end, 0, true)
    arrBtn:SetActive(BS.arrangeMode)
    local resetX = 180
    if dev then
        local testBtn = AddButton(p, (BS.testMode and not BS.arrangeMode) and L.STOP_TEST_MODE or L.TEST_MODE_DEV, 170, function()
            BS:ToggleTestMode()
        end, 180, true)
        testBtn:SetActive(BS.testMode and not BS.arrangeMode)
        resetX = 360
    end
    AddButton(p, L.RESET_ALL_POSITIONS, 200, function() BS:ResetPositions() end, resetX)
    if dev and BS.RunTestRoutine then
        -- Testroutine (nur Entwickler): prüft das Addon und speichert einen Bericht für die Prüfung
        AddButton(p, L.TEST_EVERYTHING, 170, function() BS:RunTestRoutine("") end)
    end
    AddText(p, L.ALSO_VIA_THE_ARRANGE_BUTTON, C.dim)

    AddText(p, L.BUTTON_SIZE_EACH_GROUP_SEPARATELY, C.dim)
    local function Pct(v) return math.floor((v or 1) * 100 + 0.5) end
    local function SizeRow(text, kind)
        AddButton(p, "–", 36, function() BS:ChangeScale(kind, -0.1) end, 0, true)
        AddButton(p, "+", 36, function() BS:ChangeScale(kind, 0.1) end, 42, true)
        p.y = p.y + 5
        AddText(p, text, C.text, 90)
        p.y = p.y + 5
    end
    SizeRow(string.format(L.ALL_BUTTONS, Pct(db.scale)), nil)
    for _, g in ipairs({ { "proc", "Procs" }, { "buff", "Buffs" }, { "cd", "Cooldowns" }, { "dispel", L.DISPEL } }) do
        SizeRow(string.format("%s: |cffffffff%d %%|r  |cff888888(%d px)|r", g[2], Pct(db.groupScale[g[1]]), BS:GroupSize(g[1])), g[1])
    end
    AddButton(p, L.RESET_SIZES, 200, function() BS:ResetScales() end)

    AddToggle(p, L.SHOW_MINIMAP_BUTTON, function() return not db.minimap.hide end,
        function(v) db.minimap.hide = not v; BS:UpdateMinimapButton() end)

    AddHeader(p, L.SUPPORT_THE_ADDON)
    AddText(p, L.BUFFSENTINEL_IS_FREE_AND_MADE, C.dim)
    local donate = AddButton(p, L.SUPPORT_PAYPAL, 200, function() if BS.Donate then BS.Donate.Show() end end)
    donate:SetActive(false)
    AddText(p, L.ALSO_BY_COMMAND_BSEN_DONATE, C.dim)

    AddHeader(p, L.SHARE_NAMES)
    -- Gilde/Gruppe ist der Hauptschalter: Das Flüster-Netz von GoldSentinelSync schliesst Gilde/Gruppe immer ein,
    -- einen reinen Netz-Weg gibt es nicht (Befund 1, Nachprüfung 0.9.14) – darum Netz nur mit Gilde/Gruppe.
    AddToggle(p, L.EXCHANGE_WITH_GUILD_AND_GROUP,
        function() return BS.gdb.shareNames end,
        function(v) BS.gdb.shareNames = v; if v then BS:RequestNames() end; BS:RefreshOptions() end)
    AddToggle(p, L.EXCHANGE_WITH_ALL_BUFFSENTINEL_USERS,
        function() return BS.gdb.shareServer end,
        function(v) BS:SetShareServer(v) end, 20,
        function() return BS.gdb.shareNames == true end)
    AddText(p, L.RUNS_OVER_THE_HIDDEN_CHANNEL ..
        L.BLIZZARD_SEPARATES_CHAT_CHANNELS_BY, C.dim, 30)
    AddText(p, L.SERVER_CHANNEL .. BS:SyncStatusText(), C.text)
    AddText(p, L.ONLY_TALENT_POSITIONS_AND_SPELL, C.dim)
end

local function AutoRow(p, item)
    local row = Acquire(p, "autorow", function(parent)
        local f = CreateFrame("Frame", nil, parent)
        f:SetSize(CONTENT_W, 30)
        f.bg = Tex(f, "BACKGROUND", 1, 1, 1, 0.035); f.bg:SetAllPoints()
        f.icon = f:CreateTexture(nil, "ARTWORK"); f.icon:SetSize(24, 24); f.icon:SetPoint("LEFT", 4, 0)
        f.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.text:SetPoint("LEFT", f.icon, "RIGHT", 8, 0)
        f.text:SetWidth(CONTENT_W - 150); f.text:SetJustifyH("LEFT")
        f.btn = FlatButton(f, 100, 22, L.REMOVE); f.btn:SetPoint("RIGHT", -6, 0)
        return f
    end)
    row:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
    local r = item.rec
    local icon
    if item.kind == "proc" then
        local _, ic = BS.SpellInfo(r.auraId); icon = ic or r.icon
    else
        local _, ic = BS.SpellInfo(r.id); icon = ic
    end
    row.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")
    local what
    if item.kind == "proc" then
        what = "Proc  » " .. (r.spell or "?")
    else
        what = "Cooldown" .. (r.cd and (" " .. BS.AutoCdText(r.cd)) or "")
    end
    local src = (r.src == "net") and (L.FROM_PREFIX .. (r.from or "?")) or L.LEARNED_BY_YOU
    local specs = (r.specs and #r.specs > 0) and (BS:SpecList(r.specs) .. "  ·  ") or ""
    row.text:SetText(string.format("%s  |cff888888%s  ·  %s%s|r", item.name, what, specs, src))
    row.btn:SetScript("OnClick", function() BS:AutoRemove(item.kind, item.name) end)
    p.y = p.y + 34
end

function Fill.rec(p)
    local r = BS.gdb.recorder
    local auto = BS.gdb.auto
    AddHeader(p, L.AUTOMATIC_LEARNING)
    if BS.isRetail then
        AddText(p, L.IN_RETAIL_MIDNIGHT_BUFFS_AND, C.yellow)
    else
        AddText(p, L.IF_BUFFSENTINEL_MEETS_A_PROC ..
            BS.AUTO_PROC_MIN_HITS .. L.TIMES_BY_CASTING_THE_SAME ..
            L.AS_SOON_AS_YOU_CAST, C.dim, nil)
        AddToggle(p, L.ADD_NEW_PROCS_AND_ABILITIES,
            function() return auto.enabled end, function(v) BS:SetAutoLearn(v) end)
        AddToggle(p, L.SHARE_DISCOVERIES_WITH_OTHER_BUFFSENTINEL_2,
            function() return auto.share end, function(v) auto.share = v end)

        local list, cands, nIgnore = BS:AutoList()
        AddHeader(p, L.LEARNED_AUTOMATICALLY_2 .. #list .. ")")
        if #list == 0 then AddText(p, L.NOTHING_LEARNED_YET, C.dim) end
        for _, item in ipairs(list) do AutoRow(p, item) end
        AddText(p, L.TURN_ON_AND_OFF_LIKE, C.dim)
        if #cands > 0 then
            local parts = {}
            for i, cnd in ipairs(cands) do
                if i > 6 then break end
                tinsert(parts, string.format("%s (%d/%d%s)", cnd.name, cnd.hits, BS.AUTO_PROC_MIN_HITS,
                    cnd.spell and (" » " .. cnd.spell) or ""))
            end
            AddText(p, L.BEING_WATCHED .. table.concat(parts, ",  "), C.text)
        end
        if nIgnore > 0 then
            AddButton(p, L.ALLOW_REMOVED_AGAIN .. nIgnore .. ")", 260, function() BS:AutoResetIgnore() end)
        end
    end

    AddHeader(p, L.RECORDING_MODE)
    AddText(p, L.LOGS_EVERY_NEW_BUFF_PROC, C.dim)
    local b = AddButton(p, r.enabled and L.STOP_RECORDING or L.START_RECORDING, 180, function()
        BS:SetRecorder(not r.enabled); BS:RefreshOptions()
    end, 0, true)
    b:SetActive(r.enabled)
    AddButton(p, L.CLEAR_LIST, 140, function() BS:ClearRecorder(); BS:RefreshOptions() end, 190)

    AddHeader(p, L.RECORDED .. #r.list .. ")")
    if #r.list == 0 then AddText(p, L.NOTHING_RECORDED_YET, C.dim) end
    for _, name in ipairs(r.list) do
        local rec = r.seen[name]
        if rec then
            local row = Acquire(p, "recrow", function(parent)
                local f = CreateFrame("Frame", nil, parent)
                f:SetSize(CONTENT_W, 30)
                f.bg = Tex(f, "BACKGROUND", 1, 1, 1, 0.035); f.bg:SetAllPoints()
                f.icon = f:CreateTexture(nil, "ARTWORK"); f.icon:SetSize(24, 24); f.icon:SetPoint("LEFT", 4, 0)
                f.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
                f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.text:SetPoint("LEFT", f.icon, "RIGHT", 8, 0)
                f.btn = FlatButton(f, 120, 22, ""); f.btn:SetPoint("RIGHT", -6, 0)
                return f
            end)
            row:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
            row.icon:SetTexture(rec.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
            row.text:SetText(string.format("%s  |cff888888ID %s  ·  %dx|r", rec.name, tostring(rec.id or "?"), rec.count or 0))
            if BS:HasCustom(name) then
                row.btn:SetLabel(L.ADDED); row.btn:SetActive(true)
                row.btn:SetScript("OnClick", nil)
            else
                row.btn:SetLabel(L.AS_PROC); row.btn:SetActive(false)
                row.btn:SetScript("OnClick", function() BS:AddCustomFromRecord(name) end)
            end
            p.y = p.y + 34
        end
    end

    AddHeader(p, L.OWN_PROCS)
    if #BS.db.custom == 0 then AddText(p, L.NO_OWN_PROCS_YET, C.dim) end
    for i, c in ipairs(BS.db.custom) do
        local row = Acquire(p, "customrow", function(parent)
            local f = CreateFrame("Frame", nil, parent)
            f:SetSize(CONTENT_W, 34)
            f.bg = Tex(f, "BACKGROUND", 1, 1, 1, 0.035); f.bg:SetAllPoints()
            f.icon = f:CreateTexture(nil, "ARTWORK"); f.icon:SetSize(24, 24); f.icon:SetPoint("LEFT", 4, 0)
            f.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
            f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); f.text:SetPoint("LEFT", f.icon, "RIGHT", 8, 0)
            f.text:SetWidth(150); f.text:SetJustifyH("LEFT")
            f.lbl = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall"); f.lbl:SetPoint("LEFT", 196, 0)
            f.lbl:SetText(L.CLICK_CASTS)
            f.edit = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
            f.edit:SetSize(160, 20); f.edit:SetPoint("LEFT", 270, 0); f.edit:SetAutoFocus(false)
            f.edit:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
            f.del = FlatButton(f, 90, 22, L.REMOVE); f.del:SetPoint("RIGHT", -6, 0)
            return f
        end)
        row:SetPoint("TOPLEFT", p.child, "TOPLEFT", 0, -p.y)
        local _, icon = BS.SpellInfo(c.auraId)
        row.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")
        row.text:SetText(c.aura)
        row.edit:SetText(c.spell or "")
        row.edit:SetScript("OnEnterPressed", function(s) s:ClearFocus(); BS:SetCustomSpell(i, s:GetText()) end)
        row.del:SetScript("OnClick", function() BS:RemoveCustom(i) end)
        p.y = p.y + 38
    end
    AddText(p, L.ENTER_A_SPELL_NAME_AND, C.dim)
end

------------------------------------------------------------------------
-- Hauptfenster
------------------------------------------------------------------------
-- Für die Testroutine: Verweis auf die Seiten-Funktionen (keine eigene Logik)
BS._test = BS._test or {}
BS._test.Fill = Fill

function BS:CreateOptions()
    local f = CreateFrame("Frame", "BuffSentinelOptions", UIParent)
    if BS.RegisterUI then BS.RegisterUI(f, "BuffSentinelOptions") end
    f:SetSize(800, 560)
    f:SetFrameStrata("DIALOG")
    self:RegisterWindow(f, "options", { "CENTER", "CENTER", 0, 0 })
    tinsert(UISpecialFrames, "BuffSentinelOptions")

    local bg = Tex(f, "BACKGROUND", 0.07, 0.08, 0.10, 0.97); bg:SetAllPoints()
    local header = Tex(f, "BORDER", 0.12, 0.13, 0.17, 1)
    header:SetPoint("TOPLEFT"); header:SetPoint("TOPRIGHT"); header:SetHeight(44)
    local line = Tex(f, "ARTWORK", 1, 0.65, 0.2, 1)
    line:SetPoint("TOPLEFT", 0, -44); line:SetPoint("TOPRIGHT", 0, -44); line:SetHeight(2)

    local data = self.ClassData[self.class]
    local logo = f:CreateTexture(nil, "ARTWORK")
    logo:SetSize(28, 28); logo:SetPoint("TOPLEFT", 12, -8)
    logo:SetTexture((data and data.icon) or "Interface\\Icons\\Ability_Warrior_BattleShout")
    logo:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", logo, "TOPRIGHT", 10, 1)
    title:SetText("BuffSentinel  |cff888888v" .. self.version .. "|r")
    local flavor = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    flavor:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -2)
    flavor:SetText(self.FLAVOR_NAMES[self.flavor] or self.flavor)
    flavor:SetTextColor(0.55, 0.55, 0.6)

    f.spec = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f.spec:SetPoint("RIGHT", f, "TOPRIGHT", -48, -22)

    local close = FlatButton(f, 30, 30, "×")
    close:SetPoint("TOPRIGHT", -8, -7)
    close.text:SetFontObject("GameFontHighlightLarge")
    close:SetScript("OnClick", function() f:Hide() end)
    f.close = close

    f.test = FlatButton(f, 100, 26, L.TEST_MODE)
    f.test:SetPoint("RIGHT", close, "LEFT", -10, 0)
    f.test:SetScript("OnClick", function() BS:ToggleTestMode() end)
    -- "Anordnen": eigene Buttons verschieben, Grösse, Abstand und Richtung einstellen
    f.arrange = FlatButton(f, 96, 26, L.ARRANGE)
    f.arrange:SetPoint("RIGHT", f.test, "LEFT", -8, 0)
    f.arrange:SetScript("OnClick", function() BS:ToggleArrangeMode() end)
    -- Spenden-Knopf links neben "Anordnen" (öffnet nur auf Klick)
    if self.Donate then
        f.donate = self.Donate.CreateButton(f, 104, 26)
        f.donate:SetPoint("RIGHT", f.arrange, "LEFT", -8, 0)
    end
    f.spec:ClearAllPoints()
    f.spec:SetPoint("RIGHT", f.donate or f.arrange, "LEFT", -12, 0)
    f.spec:SetWidth(180)
    f.spec:SetJustifyH("RIGHT")
    if f.spec.SetWordWrap then f.spec:SetWordWrap(false) end

    local side = Tex(f, "BORDER", 0.10, 0.11, 0.14, 1)
    side:SetPoint("TOPLEFT", 0, -46); side:SetPoint("BOTTOMLEFT"); side:SetWidth(170)

    local content = CreateFrame("Frame", nil, f)
    content:SetPoint("TOPLEFT", 170, -46)
    content:SetPoint("BOTTOMRIGHT")

    f.pages, f.tabs = {}, {}
    for i, pg in ipairs(PAGES) do
        local tab = FlatButton(f, 150, 32, pg.label)
        tab:SetPoint("TOPLEFT", 10, -56 - (i - 1) * 38)
        tab.text:ClearAllPoints(); tab.text:SetPoint("LEFT", 14, 0)
        tab:SetScript("OnClick", function() BS:ShowPage(pg.key) end)
        f.tabs[pg.key] = tab
        f.pages[pg.key] = NewPage(content, pg.key)
    end

    local foot = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    foot:SetPoint("BOTTOMLEFT", 14, 12)
    foot:SetWidth(150); foot:SetJustifyH("LEFT")
    foot:SetText(L.RIGHT_CLICK_ON_THE_MINIMAP)
    foot:SetTextColor(0.5, 0.5, 0.55)

    f:Hide()
    self.optionsFrame = f
    self.currentPage = "skill"
end

function BS:ShowPage(key)
    if key == "zones" then key = "opt" end   -- alter Name der Seite
    if key ~= self.currentPage then self.listFreeze = nil end   -- Seitenwechsel: Listen neu sortieren
    self.currentPage = key
    self:RefreshOptions()
end

function BS:RefreshOptions()
    local f = self.optionsFrame
    if not f or not f:IsShown() then return end
    f.spec:SetText(L.SPEC_3 .. self:SpecText() .. "|r")
    -- Testmodus-Knopf nur für den Entwickler; sonst rückt "Anordnen" neben das Schliessen-Kreuz
    local dev = self:IsDev()
    f.arrange:ClearAllPoints()
    if dev then
        f.test:Show()
        f.arrange:SetPoint("RIGHT", f.test, "LEFT", -8, 0)
    else
        f.test:Hide()
        f.arrange:SetPoint("RIGHT", f.close, "LEFT", -10, 0)
    end
    f.test:SetActive(self.testMode and not self.arrangeMode)
    f.test:SetLabel((self.testMode and not self.arrangeMode) and L.STOP_TEST or L.TEST_MODE)
    f.arrange:SetActive(self.arrangeMode)
    f.arrange:SetLabel(self.arrangeMode and L.DONE or L.ARRANGE)
    for key, page in pairs(f.pages) do
        local on = key == self.currentPage
        f.tabs[key]:SetActive(on)
        if on then
            page:Show()
            ResetPage(page)
            local ok, err = pcall(Fill[key], page)
            if not ok then
                AddText(page, L.ERROR_2 .. tostring(err), C.red)
                BS:CountError(L.OPTIONS_2 .. key, err)
            end
            FinishPage(page)
        else
            page:Hide()
        end
    end
end

function BS:ToggleOptions()
    if not self.optionsFrame then self:CreateOptions() end
    if self.optionsFrame:IsShown() then
        self.optionsFrame:Hide()
    else
        self.listFreeze = nil                                      -- neu geöffnet: Listen neu sortieren
        self.optionsFrame:Show()
        self:RefreshOptions()
    end
end

------------------------------------------------------------------------
-- Minimap-Button (Linksklick: Optionen, Rechtsklick: Gruppen-Raster, ziehen: verschieben)
------------------------------------------------------------------------
function BS:UpdateMinimapButton()
    local b = self.minimapButton
    if not b then return end
    if self.db.minimap.hide then b:Hide() return end
    b:Show()
    local angle = math.rad(self.db.minimap.angle or 220)
    local radius = (Minimap:GetWidth() / 2) + 6
    b:ClearAllPoints()
    b:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

function BS:CreateMinimapButton()
    local b = CreateFrame("Button", "BuffSentinelMinimapButton", Minimap)
    b:SetSize(31, 31)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    local data = self.ClassData[self.class]
    local icon = b:CreateTexture(nil, "BACKGROUND")
    icon:SetTexture((data and data.icon) or "Interface\\Icons\\Ability_Warrior_BattleShout")
    icon:SetSize(20, 20)
    icon:SetPoint("TOPLEFT", 7, -6)
    icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    local border = b:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT")

    b:SetScript("OnClick", function(_, button)
        if button == "RightButton" then
            BS:ToggleRaster()
        elseif IsShiftKeyDown() and BS:IsDev() then
            BS:ToggleTestMode()
        elseif IsShiftKeyDown() or (IsControlKeyDown and IsControlKeyDown()) then
            BS:ToggleArrangeMode()
        else
            BS:ToggleOptions()
        end
    end)
    b:SetScript("OnDragStart", function(s)
        s:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            cx, cy = cx / scale, cy / scale
            BS.db.minimap.angle = math.deg(math.atan2(cy - my, cx - mx))
            BS:UpdateMinimapButton()
        end)
    end)
    b:SetScript("OnDragStop", function(s) s:SetScript("OnUpdate", nil) end)
    b:SetScript("OnEnter", function(s)
        GameTooltip:SetOwner(s, "ANCHOR_LEFT")
        GameTooltip:AddLine("BuffSentinel", 1, 0.65, 0.2)
        GameTooltip:AddLine(L.SPEC_4 .. BS:SpecText(), 1, 1, 1)
        GameTooltip:AddLine(L.LEFT_CLICK_SETTINGS, 0.8, 0.8, 0.8)
        if BS:IsDev() then
            GameTooltip:AddLine(L.SHIFT_LEFT_CLICK_TEST_MODE, 0.8, 0.8, 0.8)
            GameTooltip:AddLine(L.CTRL_LEFT_CLICK_ARRANGE_BUTTONS, 0.8, 0.8, 0.8)
        else
            GameTooltip:AddLine(L.SHIFT_LEFT_CLICK_ARRANGE_BUTTONS, 0.8, 0.8, 0.8)
        end
        GameTooltip:AddLine(L.RIGHT_CLICK_GROUP_BUFFS, 0.8, 0.8, 0.8)
        GameTooltip:AddLine(L.DRAG_MOVE, 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)

    self.minimapButton = b
    self:UpdateMinimapButton()
end
