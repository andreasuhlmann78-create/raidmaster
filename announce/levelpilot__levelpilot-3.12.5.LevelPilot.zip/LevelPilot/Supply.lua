-- LevelPilot - Vorraete, Questbelohnungen, Taschen
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- * Beim Haendler: Essen, Wasser (Klassen mit Mana), Munition (Jaeger) und Tierfutter passend
--   zum Level nachkaufen, bis die eingestellte Menge erreicht ist (hoechstens ein Teil des Goldes)
-- * Questbelohnung, die ein Upgrade fuer die Klasse ist, nach der Abgabe automatisch anlegen
-- * Taschen aufraeumen: Gegenstaende ohne Nutzen (grau, Questgegenstaende erledigter Quests)

local _, LP = ...
local L = LP.L
local Su = {}
LP:RegisterModule("Supply", Su)

-- Classic-Haendlerware: { Item-ID, ab Level }
Su.FOOD = {
    Bread  = { { 4540, 1 }, { 4541, 5 }, { 4542, 15 }, { 4544, 25 }, { 4601, 35 }, { 8950, 45 } },
    Meat   = { { 117, 1 }, { 2287, 5 }, { 3770, 15 }, { 3771, 25 }, { 4599, 35 }, { 8952, 45 } },
    Cheese = { { 2070, 1 }, { 414, 5 }, { 422, 15 }, { 1707, 25 }, { 3927, 35 }, { 8932, 45 } },
    Fruit  = { { 4536, 1 }, { 4537, 5 }, { 4538, 15 }, { 4539, 25 }, { 4602, 35 }, { 8953, 45 } },
    Fungus = { { 4604, 1 }, { 4605, 5 }, { 4606, 15 }, { 4607, 25 }, { 4608, 35 }, { 8948, 45 } },
    Fish   = { { 787, 1 }, { 4592, 5 }, { 4593, 15 }, { 4594, 25 }, { 21552, 35 }, { 8957, 45 } },
}
Su.WATER = { { 159, 1 }, { 1179, 5 }, { 1205, 15 }, { 1708, 25 }, { 1645, 35 }, { 8766, 45 } }
Su.ARROWS = { { 2512, 1 }, { 2515, 10 }, { 3030, 25 }, { 11285, 40 } }
Su.BULLETS = { { 2516, 1 }, { 2519, 10 }, { 3033, 25 }, { 11284, 40 } }
-- Tierfutter-Arten (GetPetFoodTypes kann englische oder uebersetzte Namen liefern)
local DIET = {
    Meat = "Meat", Fleisch = "Meat", Viande = "Meat", Carne = "Meat", ["Мясо"] = "Meat",
    Fish = "Fish", Fisch = "Fish", Poisson = "Fish", Pescado = "Fish", Pesce = "Fish", Peixe = "Fish", ["Рыба"] = "Fish",
    Bread = "Bread", Brot = "Bread", Pain = "Bread", Pan = "Bread", Pane = "Bread", ["Pão"] = "Bread", ["Хлеб"] = "Bread",
    Cheese = "Cheese", ["Käse"] = "Cheese", Fromage = "Cheese", Queso = "Cheese", Formaggio = "Cheese", Queijo = "Cheese", ["Сыр"] = "Cheese",
    Fruit = "Fruit", ["Obst"] = "Fruit", Fruta = "Fruit", Frutta = "Fruit", ["Фрукты"] = "Fruit",
    Fungus = "Fungus", Pilze = "Fungus", Champignon = "Fungus", Hongo = "Fungus", Fungo = "Fungus", ["Грибы"] = "Fungus",
}

local function ItemIDOf(link) return link and tonumber(link:match("item:(%d+)")) or nil end

local function CountOf(list)
    local n = 0
    for _, e in ipairs(list) do n = n + (LP.API.ItemCount(e[1]) or 0) end
    return n
end

local function Usable(list, level)
    local set = {}
    for _, e in ipairs(list) do if e[2] <= level then set[e[1]] = e[2] end end
    return set
end

------------------------------------------------------------------------
-- Was wird gebraucht? { list, amount, level, label }
------------------------------------------------------------------------
function Su:Needs()
    local level = LP:PlayerLevel() or 1
    local _, class = UnitClass("player")
    local needs = {}
    if LP.db.restockFood then
        local all = {}
        for _, list in pairs(self.FOOD) do for _, e in ipairs(list) do all[#all + 1] = e end end
        needs[#needs + 1] = { list = all, amount = LP.db.foodAmount or 20, level = level, label = "food" }
    end
    local mana = UnitPowerType and UnitPowerType("player") == 0
    if LP.db.restockWater and mana and (class ~= "MAGE" or LP.db.restockWaterMage) then
        needs[#needs + 1] = { list = self.WATER, amount = LP.db.waterAmount or 20, level = level, label = "water" }
    end
    if LP.db.restockAmmo and class == "HUNTER" then
        local link = GetInventoryItemLink and GetInventoryItemLink("player", 18)
        local instant = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
        local sub = link and instant and select(7, instant(link))
        local list = (sub == 3) and self.BULLETS or ((sub == 2 or sub == 18) and self.ARROWS or nil)
        if list then needs[#needs + 1] = { list = list, amount = LP.db.ammoAmount or 1000, level = level, label = "ammo" } end
    end
    if LP.db.restockPetFood and class == "HUNTER" and UnitExists and UnitExists("pet") and GetPetFoodTypes then
        local petLevel = UnitLevel("pet") or level
        local seen = {}
        for _, t in ipairs({ GetPetFoodTypes() }) do
            local key = DIET[t]
            if key and self.FOOD[key] and not seen[key] then
                seen[key] = true
                needs[#needs + 1] = { list = self.FOOD[key], amount = LP.db.petFoodAmount or 20, level = petLevel, label = "pet", diet = key }
                break   -- eine Futterart genuegt
            end
        end
    end
    return needs
end

------------------------------------------------------------------------
-- Einkauf beim Haendler
------------------------------------------------------------------------
-- Einkaufsliste fuer den offenen Haendler: { { index, id, purchases, perBuy, price, name } }
function Su:Plan()
    if not LP.API.MerchantAvailable() then return {} end
    local plan = {}
    local money = GetMoney and GetMoney() or 0
    local budget = math.floor(money * (LP.db.restockMaxPct or 25) / 100)
    local spent = 0
    for _, need in ipairs(self:Needs()) do
        local ok = Usable(need.list, need.level)
        -- bestes Angebot dieses Haendlers (hoechste passende Stufe)
        local best, bestLvl
        for i = 1, LP.API.MerchantCount() do
            local id = ItemIDOf(LP.API.MerchantLink(i))
            local lvl = id and ok[id]
            if lvl and (not bestLvl or lvl > bestLvl) then best, bestLvl = i, lvl end
        end
        if best then
            -- Vorrat: alles aus der Liste ab der gekauften Stufe zaehlt (aeltere Stufen werden zuerst verbraucht)
            local have, seen = 0, {}
            for _, e in ipairs(need.list) do
                if not seen[e[1]] and e[2] >= bestLvl - 10 then seen[e[1]] = true have = have + (LP.API.ItemCount(e[1]) or 0) end
            end
            local missing = need.amount - have
            if missing > 0 then
                local name, price, perBuy, avail = LP.API.MerchantItem(best)
                perBuy = math.max(1, perBuy or 1)
                local purchases = math.ceil(missing / perBuy)
                if avail and avail >= 0 then purchases = math.min(purchases, avail) end
                local cost = (price or 0) * purchases
                if price and price > 0 and spent + cost > budget then purchases = math.floor((budget - spent) / price) end
                if purchases > 0 then
                    spent = spent + (price or 0) * purchases
                    plan[#plan + 1] = { index = best, id = ItemIDOf(LP.API.MerchantLink(best)), purchases = purchases,
                                        perBuy = perBuy, price = price or 0, name = name, label = need.label }
                end
            end
        end
    end
    return plan, spent
end

function Su:Restock()
    if not LP.db.restock then
        -- ab Werk aus: einmal zeigen, dass LevelPilot hier nachkaufen koennte (es wird nichts gekauft)
        self:CheckRestockHint(self:Plan())
        return
    end
    local plan, spent = self:Plan()
    if #plan == 0 then return end
    local queue, bought = {}, {}
    for _, p in ipairs(plan) do
        for _ = 1, p.purchases do queue[#queue + 1] = p end
        bought[#bought + 1] = (p.purchases * p.perBuy) .. "× " .. (p.name or "?")
    end
    local i = 0
    local function step()
        i = i + 1
        local p = queue[i]
        if not p or not (MerchantFrame and MerchantFrame:IsShown()) then return end
        LP.Act.Call("MerchantBuy", LP.API.MerchantBuy, p.index, 1)
        C_Timer.After(0.2, step)
    end
    step()
    LP:Print(L("Vorräte gekauft: %s (%s)", table.concat(bought, ", "), GetCoinTextureString and GetCoinTextureString(spent) or tostring(spent)))
    self.lastPlan = plan
end

------------------------------------------------------------------------
-- Questbelohnung automatisch anlegen
------------------------------------------------------------------------
local pending, pendingUntil = {}, 0

function Su:RememberRewards()
    wipe(pending)
    local links = {}
    for _, kind in ipairs({ "choice", "reward" }) do
        local n = (kind == "choice" and GetNumQuestChoices or GetNumQuestRewards) and (kind == "choice" and GetNumQuestChoices() or GetNumQuestRewards()) or 0
        for i = 1, n do
            local link = GetQuestItemLink(kind, i)
            local id = ItemIDOf(link)
            if id then pending[id] = true links[#links + 1] = link end
        end
    end
    pendingUntil = GetTime() + 15
    -- ab Werk aus: einmal zeigen, dass LevelPilot Upgrades anlegen koennte (nichts wird gewaehlt oder angelegt)
    if not LP.db.autoEquipRewards and #links > 0 then pcall(self.CheckRewardHint, self, links) end
end

------------------------------------------------------------------------
-- Einmalige Hinweise auf die ab Werk ausgeschalteten Optionen (Entscheid des Nutzers 3.12.5)
-- Nachkaufen (restock) beim ersten Haendler, bei dem LevelPilot etwas kaufen wuerde; Belohnung anlegen
-- (autoEquipRewards) bei der ersten Questbelohnung, die ein Upgrade ist. Je Hinweis hoechstens einmal pro Charakter;
-- "Später erinnern" zeigt ihn frueestens nach 3 Levels wieder. Ist die Option an, nie. Nicht im Kampf.
-- Gezeigt ueber den Assistenten (Hinweisfenster), nie im Chat anderer Spieler. Es wird nichts gekauft, gewaehlt
-- oder angelegt.
------------------------------------------------------------------------
local OPT = {
    restock   = { setting = "restock",          page = "extras" },
    autoEquip = { setting = "autoEquipRewards", page = "extras" },
}
Su.OPT_REMIND_LEVELS = 3
Su.optPending = {}           -- [restock/autoEquip] = { text = … } (in dieser Sitzung zu zeigen)

local function OptState(key)
    local c = LP.char
    if not c then return nil end
    if type(c.optHints) ~= "table" then c.optHints = {} end
    return c.optHints[key]
end

-- darf der Hinweis (noch) gezeigt werden?
function Su:OptHintDue(key)
    local o = OPT[key]
    if not o or LP.db[o.setting] then return false end
    local st = OptState(key)
    if st == nil then return true end
    if type(st) == "number" then return (LP:PlayerLevel() or 1) >= st end
    return false
end

function Su:CheckRestockHint(plan)
    if type(plan) ~= "table" or #plan == 0 or not self:OptHintDue("restock") then return false end
    local list = {}
    for _, p in ipairs(plan) do list[#list + 1] = ((p.purchases or 1) * (p.perBuy or 1)) .. "× " .. (p.name or "?") end
    local text = L("LevelPilot kann hier Essen, Trinken und Munition automatisch nachkaufen (höchstens %d %% deines Goldes). Einschalten: Zentrale » Extras » Vorräte & Taschen » Beim Händler Vorräte nachkaufen.",
        LP.db.restockMaxPct or 25)
    text = text .. "\n" .. L("Würde kaufen: %s", table.concat(list, ", "))
    self.optPending.restock = { text = text }
    if LP.Advisor and LP.Advisor.Soon then LP.Advisor:Soon() end
    return true
end

-- links: Gegenstaende der Belohnung (Auswahl und feste Belohnung)
function Su:CheckRewardHint(links)
    if not self:OptHintDue("autoEquip") or type(links) ~= "table" then return false end
    local up
    for _, link in ipairs(links) do
        local gain = LP.Advisor and LP.Advisor:UpgradeValue(link)
        if gain and gain > 0 then up = link break end
    end
    if not up then return false end
    self.optPending.autoEquip = { text = L["Diese Belohnung wäre ein Upgrade. LevelPilot kann Upgrades automatisch anlegen. Einschalten: Zentrale » Extras » Vorräte & Taschen » Questbelohnung anlegen."]
        .. "\n" .. tostring(up) }
    if LP.Advisor and LP.Advisor.Soon then LP.Advisor:Soon() end
    return true
end

function Su:OptHintOpen(key)
    local o = OPT[key]
    if LP:InCombat() then LP:Print(L["Im Kampf nicht möglich."]) return end
    local page = o and o.page or "extras"
    local f = _G.LevelPilotCenter
    if f and f:IsShown() then
        LP.Center:Select(page)
    elseif LP.Center and LP.Center.Toggle then
        LP.Center:Toggle(page)
    end
end

function Su:OptHintLater(key)
    if not LP.char then return end
    if type(LP.char.optHints) ~= "table" then LP.char.optHints = {} end
    LP.char.optHints[key] = (LP:PlayerLevel() or 1) + Su.OPT_REMIND_LEVELS
    self.optPending[key] = nil
    if LP.Advisor and LP.Advisor.Soon then LP.Advisor:Soon() end
end

local function OptHints(add)
    if LP:InCombat() then return end
    for key, p in pairs(Su.optPending) do
        local o = OPT[key]
        if not o or LP.db[o.setting] then
            Su.optPending[key] = nil                       -- inzwischen eingeschaltet: nie mehr
        else
            -- als gezeigt merken (ein Hinweis je Charakter), solange nicht "Später erinnern" gewaehlt wird
            local st = OptState(key)
            if st == nil or type(st) == "number" then LP.char.optHints[key] = true end
            add("opt:" .. key, LP.Advisor.SEV_INFO, p.text,
                function() Su:OptHintOpen(key) end, L["Einstellungen"],
                function() Su:OptHintLater(key) end, L["Später erinnern"])
        end
    end
end
Su.OptHintsProvider = OptHints

function Su:EquipRewards()
    if not LP.db.autoEquipRewards or not next(pending) or GetTime() > pendingUntil then return end
    if InCombatLockdown and InCombatLockdown() then return end
    for bag = 0, 4 do
        for slot = 1, (LP.API.BagSlots(bag) or 0) do
            local link = LP.API.BagLink(bag, slot)
            local id = ItemIDOf(link)
            if id and pending[id] and LP.API.IsEquippable(link) then
                pending[id] = nil
                local gain = LP.Advisor:UpgradeValue(link)
                if gain and gain > 0 then
                    LP.Act.Call("Equip", LP.API.Equip, link)
                    LP:Print(L("Belohnung angelegt: %s", link))
                end
            end
        end
    end
end

------------------------------------------------------------------------
-- Taschen aufraeumen
------------------------------------------------------------------------
-- alle Quests, die den Gegenstand brauchen oder mit ihm beginnen, sind abgeschlossen
function Su.AllDone(info)
    if not info then return false end
    local done = C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted
    if not done then return false end
    for _, list in ipairs({ info.needs or {}, info.starts or {} }) do
        for _, qid in ipairs(list) do if not done(qid) then return false end end
    end
    return true
end

-- { { bag, slot, link, kind = "grey"/"quest", value } }
function Su:Junk()
    local out = {}
    local info = C_Item and C_Item.GetItemInfoInstant or GetItemInfoInstant
    for bag = 0, 4 do
        for slot = 1, (LP.API.BagSlots(bag) or 0) do
            local it = LP.API.BagItem(bag, slot)
            if it and it.id and not (LP.Tooltips and LP.Tooltips:IsProtected(it.id)) then
                local classID = info and select(6, info(it.id))
                local value = (LP.API.SellPrice(it.id) or 0) * (it.count or 1)
                if it.quality == 0 and value > 0 then
                    out[#out + 1] = { bag = bag, slot = slot, link = it.link, kind = "grey", value = value }
                elseif classID == 12 and Su.AllDone(LP.QuestDB:ItemQuests(it.id)) then
                    -- Questgegenstand, dessen Quests alle abgeschlossen sind
                    out[#out + 1] = { bag = bag, slot = slot, link = it.link, kind = "quest", value = value }
                end
            end
        end
    end
    return out
end

local function JunkHint(add)
    if not LP.db.bagCleanup then return end
    local list = Su:Junk()
    local quest = {}
    for _, e in ipairs(list) do if e.kind == "quest" then quest[#quest + 1] = e.link or "?" end end
    if #quest == 0 then return end
    add("junk", LP.Advisor.SEV_INFO, L("Taschen aufräumen: %d Questgegenstand/-gegenstände ohne offene Quest – kann weg: %s", #quest, table.concat(quest, ", ")))
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
function Su:Init()
    LP:On("MERCHANT_SHOW", function() C_Timer.After(0.6, function() Su:Restock() end) end)
    LP:On("QUEST_COMPLETE", function() Su:RememberRewards() end)
    LP:On("BAG_UPDATE_DELAYED", function() C_Timer.After(0.3, function() Su:EquipRewards() end) end)
    LP:On("PLAYER_REGEN_ENABLED", function() Su:EquipRewards() end)
    if LP.Advisor and LP.Advisor.AddProvider then
        LP.Advisor:AddProvider(JunkHint)
        LP.Advisor:AddProvider(OptHints)
    end
end
