-- LevelPilot - Automatische Routenplanung
-- Ablauf:
--   1) Kandidaten: alle Quests im passenden Levelbereich fuer Volk/Klasse (bei Levelaufstieg neu)
--   2) Aufgaben: annehmbare Quests (Questgeber), offene Ziele, fertige Quests (Abgabe)
--   3) Fokus-Zone: Zone mit dem besten Verhaeltnis Nutzen / Reiseweg
--   4) Reihenfolge: naechster-Nachbar ueber Weglaengen, Annehmen/Abgeben bevorzugt
--   5) Reise: Zonenwechsel ueber das Wegenetz, lange Strecken per Flugpunkt
--   Speedrun: laesst langsame/ineffiziente Quests aus (EP pro Zeit), Klassenquests bleiben immer.
--   Dungeons: Dungeon-Quests werden mitgenommen, wenn man ohnehin beim Questgeber ist; der
--   Lauf selbst wird als ein Schritt eingeplant, sobald Level und Anzahl der Quests passen.

local _, LP = ...
local L = LP.L
local P = {}
LP:RegisterModule("Planner", P)

P.steps = {}
P.focus = nil
P.status = ""
local candidates = {}
local candLevel = -1
local MAX_STEPS = 12
local NOT_OFFERED_SECS = 900

------------------------------------------------------------------------
-- Status der Quests im Spiel
------------------------------------------------------------------------
local inLog = {}     -- [id] = { complete, index, title, objDone = {..} }

local function ScanLog()
    wipe(inLog)
    for _, q in ipairs(LP.API.Quests()) do
        local objs = LP.API.Objectives(q.index)
        local complete = q.complete
        if not complete and #objs == 0 then complete = true end
        local objDone = {}
        for o, ob in ipairs(objs) do objDone[o] = ob.finished end
        inLog[q.id] = { complete = complete, index = q.index, title = q.title, objDone = objDone, failed = q.failed }
    end
end
P.inLog = inLog

local function Done(id)
    if LP.char.turnedIn[id] then return true end
    return LP.API.IsQuestDone(id)
end
P.IsDone = Done

local function GreyRange(level)
    return LP.API.GreenRange(level)
end

------------------------------------------------------------------------
-- 1) Kandidaten
------------------------------------------------------------------------
function P:BuildCandidates()
    local level = LP:PlayerLevel() or 1
    wipe(candidates)
    local QDB = LP.QuestDB
    local f = LP:PlayerFaction() == "Horde" and "H" or "A"
    for ci, id in ipairs(QDB:AllIds()) do
        if ci % 20 == 0 then LP:Yield("plan") end
        local info = QDB:QuickInfo(id)
        if info then
            local ql = info.level or 0
            if ql <= 0 then ql = info.reqLevel or 1 end
            if (info.reqLevel or 0) <= level + 1 and ql <= level + 4 and ql >= level - 12 then
                local ok = true
                if info.faction and info.faction ~= f then ok = false end
                if ok then ok = QDB:RaceOk(info.races, info.raceSys) end
                if ok and info.classes and info.classes ~= 0 and QDB.classBit then
                    ok = LP.HasBit(info.classes, QDB.classBit)
                end
                if ok and info.specialFlags and LP.HasBit(info.specialFlags, 1) then ok = false end
                if ok and info.dungeon and not P:DungeonUsable(info.dungeon) then ok = false end
                if ok then candidates[#candidates + 1] = id end
            end
        end
    end
    candLevel = level
    self:BuildProtected()
end

------------------------------------------------------------------------
-- 2) Verfuegbarkeit einer Quest
------------------------------------------------------------------------
local function AllDone(list)
    if type(list) ~= "table" then return true end
    for _, id in ipairs(list) do if not Done(id) then return false end end
    return true
end

local function AnyDone(list)
    if type(list) ~= "table" or #list == 0 then return true end
    for _, id in ipairs(list) do if Done(id) then return true end end
    return false
end

local function NoneTaken(list)
    if type(list) ~= "table" then return true end
    for _, id in ipairs(list) do
        if Done(id) or inLog[id] then return false end
    end
    return true
end

-- Heimatgebiete der Fraktionen: Quests ohne Volksbeschraenkung, deren Questgeber oder Abgabe dort steht,
-- sind fuer die andere Fraktion praktisch nicht machbar (feindliche Wachen, feindliche NPCs).
-- Neutrale Orte (Beutebucht, Ratschet, Gadgetzan ...) liegen in umkaempften Zonen und sind nicht betroffen.
local HOME_ZONES = {
    Alliance = { [1429] = true, [1436] = true, [1433] = true, [1431] = true, [1426] = true, [1432] = true,
                 [1438] = true, [1439] = true, [1437] = true, [1453] = true, [1455] = true, [1457] = true },
    Horde    = { [1411] = true, [1412] = true, [1420] = true, [1421] = true, [1454] = true, [1456] = true, [1458] = true },
}
local BATTLEGROUNDS = { [1459] = true, [1460] = true, [1461] = true }   -- Alteractal, Warsongschlucht, Arathibecken

local function InEnemyHome(q)
    local mine = LP:PlayerFaction()
    local enemy = HOME_ZONES[mine == "Horde" and "Alliance" or "Horde"]
    for _, list in ipairs({ q.starts, q.ends }) do
        for _, p in ipairs(list or {}) do
            if enemy[p[1]] then return true end
        end
    end
    return false
end

local function OnBattleground(q)
    for _, list in ipairs({ q.starts, q.ends }) do
        for _, p in ipairs(list or {}) do if BATTLEGROUNDS[p[1]] then return true end end
    end
    for _, o in ipairs(q.objectives or {}) do
        for _, p in ipairs(o.spots or {}) do if BATTLEGROUNDS[p[1]] then return true end end
    end
    return false
end
P.InEnemyHome, P.OnBattleground = InEnemyHome, OnBattleground

-- Spenden und Kriegseinsatz (Stoffspenden, "Die Horde braucht ..."): Questlevel 55-60, aber ab Level 1-20
function P.IsDonation(q)
    local ql = q and q.level or 0
    return ql >= 55 and (q.reqLevel or 0) > 0 and q.reqLevel <= 20
end

function P:IsAvailable(q, level)
    local id = q.id
    if Done(id) or inLog[id] then return false end
    if LP.char.ignored[id] then return false end
    local no = LP.char.notOffered[id]
    if no and LP:Now() - no < NOT_OFFERED_SECS then return false end
    if (q.reqLevel or 0) > level then return false end
    local ql = q.level or 0
    if ql > 0 and ql > level + 3 then return false end
    if ql > 0 and ql < level - GreyRange(level) then return false end
    if not LP.QuestDB:FitsPlayer(q) then return false end
    if q.repeatable or q.itemStart then return false end
    if P.IsDonation(q) then return false end
    if #q.starts == 0 then return false end
    if q.pvp or OnBattleground(q) then return false end                -- Schlachtfelder: kein Questen
    if (q.races or 0) == 0 and InEnemyHome(q) then return false end   -- Gebiet der anderen Fraktion
    if q.skill or q.minRep then return false end
    if q.parent and q.parent ~= 0 and not inLog[q.parent] then return false end
    if not AllDone(q.pre) then return false end
    if not AnyDone(q.preAny) then return false end
    if not NoneTaken(q.exclusive) then return false end
    if q.nextInChain and q.nextInChain ~= 0 and (Done(q.nextInChain) or inLog[q.nextInChain]) then return false end
    return true
end

------------------------------------------------------------------------
-- Hilfen: Punkte & Entfernungen
------------------------------------------------------------------------
local function WorldOf(pt)
    if not pt then return nil end
    return LP.Geo:ToWorld(pt[1], pt[2], pt[3])
end

-- naechster Punkt einer Liste zum Bezugspunkt (Weltkoordinaten)
local function NearestPoint(points, inst, n, w)
    local best, bestD, bestW
    for _, pt in ipairs(points or {}) do
        local i, pn, pw = WorldOf(pt)
        if i then
            local d
            if i == inst then d = LP.Geo:Dist(n, w, pn, pw) else d = 1e6 end
            if not bestD or d < bestD then best, bestD, bestW = pt, d, { i, pn, pw } end
        end
    end
    return best, bestD, bestW
end

------------------------------------------------------------------------
-- 3) Aufgaben sammeln
------------------------------------------------------------------------
-- Wert einer Quest nach Abstand zum eigenen Level (gelb/orange am wertvollsten)
local function LevelWeight(qLevel, level)
    if not qLevel or qLevel <= 0 then return 0.8 end
    local d = qLevel - level
    if d >= 4 then return 0.4 end          -- rot: zu schwer
    if d >= 0 then return 1.5 end          -- gelb/orange
    if d >= -3 then return 1.0 end         -- gruen
    if d >= -6 then return 0.5 end         -- fast grau
    return 0.2
end
P.LevelWeight = LevelWeight

------------------------------------------------------------------------
-- Speedrun
------------------------------------------------------------------------
-- Strenge: Quests auslassen, die weniger als x der Grind-EP je Minute bringen
local SPEED_CUTOFF = { [1] = 0.3, [2] = 0.45, [3] = 0.6 }  -- locker / mittel / streng (nur klar langsame Quests)
local SPEED_HUB = 3          -- Questgeber-Ort mit so vielen Quests: keine davon auslassen
local SPEED_NAMES = { [1] = "locker", [2] = "mittel", [3] = "streng" }
P.SPEED_NAMES = SPEED_NAMES
local SPEED_LOW = 5         -- Quests ab 5 Stufen unter dem eigenen Level auslassen
local SPEED_DUNGEON_MIN = 3 -- Dungeon-Lauf im Speedrun erst ab 3 Quests
local RUN_SPEED = 7         -- Yards je Sekunde zu Fuss
local protected = {}
P.speedSkip = {}            -- [questID] = Grund (nur im Speedrun)

function P:IsSpeed() return LP.char.mode == "speed" end

function P:SetMode(mode)
    mode = mode == "speed" and "speed" or "normal"
    if LP.char.mode == mode then return end
    LP.char.mode = mode
    candLevel = -1
    LP:Print(mode == "speed"
        and L["|cffff7a3cSpeedrun|r aktiv: Quests, die weniger EP pro Minute bringen als Grinden, werden ausgelassen – Klassenquests bleiben."]
        or L["Normales Questen aktiv: alle passenden Quests werden eingeplant."])
    self:Replan()
    LP:Fire("MODE_CHANGED", mode)
end

function P:ToggleMode() self:SetMode(self:IsSpeed() and "normal" or "speed") end

local CLASS_LIST = { 1, 2, 4, 8, 16, 64, 128, 256, 1024 }
local function IsClassQuest(classes)
    if not classes or classes == 0 then return false end
    local c = 0
    for _, b in ipairs(CLASS_LIST) do if LP.HasBit(classes, b) then c = c + 1 end end
    return c > 0 and c <= 3
end
P.IsClassQuest = IsClassQuest

-- Klassenquests und alle ihre Vorquests sind im Speedrun geschuetzt
function P:BuildProtected()
    wipe(protected)
    local function mark(id, depth)
        if protected[id] or depth > 8 then return end
        protected[id] = true
        local q = LP.QuestDB:Get(id)
        if not q then return end
        for _, pid in ipairs(type(q.pre) == "table" and q.pre or {}) do mark(pid, depth + 1) end
        for _, pid in ipairs(type(q.preAny) == "table" and q.preAny or {}) do mark(pid, depth + 1) end
    end
    for _, id in ipairs(candidates) do
        local info = LP.QuestDB:QuickInfo(id)
        if info and IsClassQuest(info.classes) then mark(id, 0) end
    end
end

function P:IsProtected(id)
    if protected[id] then return true end
    local q = LP.QuestDB:Get(id)
    return q and IsClassQuest(q.classes) or false
end

-- Geschaetzte Zeit fuer eine Quest ab dem Questgeber: Ziele + Wege + Abgabe (Sekunden)
local SHARED_TRAVEL = 0.6      -- Anteil der Wege zu Zielen/Abgabe, den eine Quest allein traegt
local function QuestSeconds(q, partners)
    local secs = 20
    -- gebuendelt: die Suchzeit teilt man mit den anderen Quests im selben Gebiet
    local share = 1 / (1 + math.min(partners or 0, 3))
    local ci, cn, cw = nil, nil, nil
    if q.starts[1] then ci, cn, cw = LP.Geo:ToWorld(q.starts[1][1], q.starts[1][2], q.starts[1][3]) end
    local function hop(points)
        local best, bi, bn, bw
        for _, pt in ipairs(points or {}) do
            local i, pn, pw = LP.Geo:ToWorld(pt[1], pt[2], pt[3])
            if i then
                -- Wege im Questgebiet teilt man meist mit anderen Quests derselben Gegend
                local d = (ci and i == ci) and LP.Geo:Dist(cn, cw, pn, pw) / RUN_SPEED * SHARED_TRAVEL or 900
                if not best or d < best then best, bi, bn, bw = d, i, pn, pw end
            end
        end
        if best then secs = secs + best ci, cn, cw = bi, bn, bw end
    end
    for _, o in ipairs(q.objectives) do
        local c, _, search = P:ObjectiveCost(o.kind, o.elite, o)
        secs = secs + c - search * (1 - share)
        hop(o.spots)
    end
    hop(q.ends)
    if q.escort then secs = secs + 600 end
    return secs
end

-- EP einer Quest fuer dieses Level (Classic-Abzug fuer niedrige Quests)
-- Grund-EP: im Spiel gemessen (WoW Forever) vor Classic-Tabelle
P.QuestSeconds = function(q, partners) return QuestSeconds(q, partners) end

local function BaseXP(q)
    local ql = (q.level and q.level > 0) and q.level or nil
    if q.xpReal and q.xpRealLvl and (not ql or q.xpRealLvl <= ql + 4) then return q.xpReal, true end
    -- noch nicht selbst abgegeben: Classic-Wert mal dem gemessenen Forever-Faktor (falls schon bekannt)
    local f = LP.Calib and LP.Calib:QuestXPFactor()
    if q.xp and f then return q.xp * f, false end
    return q.xp, false
end
P.BaseXP = BaseXP

local function QuestXPFor(q, level)
    local base = BaseXP(q)
    if not base or base <= 0 then return nil end
    local ql = (q.level and q.level > 0) and q.level or level
    local mult = math.max(1, math.min(10, 2 * (ql - level) + 20)) / 10
    return base * mult
end

-- Monster-EP je Minute beim Grinden auf diesem Level (Classic: 45 + 5 x Level je Kill, ~2 Kills/Min)
-- EP pro Minute beim Grinden: Monster im eigenen Level (45 + 5 x Level EP), etwa 1,5 pro Minute mit Looten,
-- Essen/Trinken und Laufen zwischen den Gegnern
P.KILLS_PER_MIN = nil          -- fester Wert fuer die Testumgebung (sonst Klasse/Messung)
-- Startwerte je Klasse (Kills pro Minute mit Looten, Erholen, Laufen); gemessene Werte haben Vorrang
local CLASS_KPM = { HUNTER = 2.2, WARLOCK = 2.1, MAGE = 1.9, ROGUE = 1.8, WARRIOR = 1.7, PALADIN = 1.7,
                    SHAMAN = 1.8, DRUID = 1.8, PRIEST = 1.6 }
function P:KillsPerMin()
    if P.KILLS_PER_MIN then return P.KILLS_PER_MIN end
    local m = LP.Calib and LP.Calib:KillsPerMin()
    if m then return m end
    local _, class = UnitClass("player")
    return CLASS_KPM[class or ""] or 1.8
end
-- Dauer eines Questziels (Sekunden) und Kills dabei - ein Modell fuer Planung und virtuelle Reise
local OBJ_KILLS = { kill = 8, item = 10 }           -- Kills fuer ein Ziel (Gegenstaende: mit Dropchance)
local OBJ_SEARCH = { kill = 60, item = 90, object = 120, explore = 60 }
local DROP_DEFAULT = 0.5      -- angenommene Stueck je Kill, solange nichts gemessen ist
local SPARSE_SPAWNS = 6       -- weniger Spawnpunkte der Droppenden: man wartet auf das Wiederauftauchen
local SPARSE_FACTOR = 1.8
local ITEM_KILLS_MAX = 80
P.SLOW_KILLS = 25             -- ab so vielen erwarteten Kills fuer einen Gegenstand gilt die Quest als langsam

local spawnCache = {}
local function DropperSpawns(o)
    local key = o.item or 0
    if spawnCache[key] then return spawnCache[key] end
    local N = LevelPilotData and LevelPilotData.N
    local pts = 0
    for _, id in ipairs(o.ids or {}) do
        local npc = N and N[id]
        for _, sp in ipairs(npc and npc.s or {}) do pts = pts + (#sp - 1) / 2 end
    end
    spawnCache[key] = pts
    return pts
end

-- erwartete Kills fuer ein Gegenstands-Ziel: gemessene Droprate (eigene oder anderer Spieler) mal benoetigte
-- Anzahl; sonst Annahme, bei wenigen Spawnpunkten der Droppenden laenger. Zweiter Wert: gemessen?
function P:ItemKills(o, need)
    if not o or not o.item then return OBJ_KILLS.item, false end
    local Ca = LP.Calib
    need = need or (Ca and Ca:Need(o.item))
    local rate = Ca and Ca:DropRate(o.item)
    local kills, measured
    if rate then
        kills, measured = (need or OBJ_KILLS.item * DROP_DEFAULT) / rate, true
    else
        kills = need and need / DROP_DEFAULT or OBJ_KILLS.item
        local sp = DropperSpawns(o)
        if o.ids and #o.ids > 0 and sp > 0 and sp < SPARSE_SPAWNS then kills = kills * SPARSE_FACTOR end
    end
    return math.max(1, math.min(ITEM_KILLS_MAX, kills)), measured
end

-- Liefert Sekunden, Kills und den Anteil Suchzeit (den teilt man mit anderen Zielen im selben Gebiet).
-- o (optional): das Ziel aus der Questdatenbank, need (optional): benoetigte Anzahl aus dem Questlog
function P:ObjectiveCost(kind, elite, o, need)
    local kills = OBJ_KILLS[kind] or 0
    if kind == "item" and o then kills = self:ItemKills(o, need) end
    local search = OBJ_SEARCH[kind] or 120
    local secs = search + kills * 60 / self:KillsPerMin()
    if elite then secs = secs + 600 end
    return secs, kills, search
end

-- Gegenstaende, die selten fallen (Speedrun laesst solche Quests aus)
function P:SlowDrop(q)
    for _, o in ipairs(q and q.objectives or {}) do
        if o.kind == "item" and o.item and not o.elite then
            local k = self:ItemKills(o)
            if k >= self.SLOW_KILLS then return true, k end
        end
    end
    return false
end

------------------------------------------------------------------------
-- Questziele buendeln: liegen Ziele mehrerer Quests im selben Gebiet, erledigt man sie in einem Durchgang
-- (einmal hinlaufen, einmal suchen; Kills zaehlen fuer alle passenden Quests)
------------------------------------------------------------------------
local BUNDLE_R = 300          -- Yards
P.BUNDLE_R = BUNDLE_R
P.BUNDLE_CUT = 0.5      -- Speedrun: gebuendelte Quests erst ab halber Grenze auslassen
local function ObjPoints(o)
    if o._wp then return o._wp end
    local t = {}
    for _, sp in ipairs(o.spots or {}) do
        local i, n, w = LP.Geo:ToWorld(sp[1], sp[2], sp[3])
        if i then t[#t + 1] = { i, n, w } end
    end
    o._wp = t
    return t
end
P.ObjPoints = ObjPoints
local function CellKey(i, cn, cw) return i * 100000000 + (cn + 5000) * 10000 + (cw + 5000) end

-- Raster aller offenen, machbaren Ziele: entries = { {q = Quest, done = {[idx] = true} oder nil}, ... }
function P:BundleIndex(entries, level)
    local idx = {}
    for ei, e in ipairs(entries) do
        local q = e.q
        if ei % 10 == 0 then LP:Yield("plan") end
        for oi, o in ipairs(q.objectives or {}) do
            local ml = o.mobLevel and (o.mobLevel + (o.elite and LP.Danger.ELITE_BONUS or 0))
            local ok = not o.elite and not (e.done and e.done[o.idx or oi]) and (not ml or LP.Danger:OK(ml, level))
            if ok then
                for _, p in ipairs(ObjPoints(o)) do
                    local k = CellKey(p[1], math.floor(p[2] / BUNDLE_R), math.floor(p[3] / BUNDLE_R))
                    local c = idx[k]
                    if not c then c = {} idx[k] = c end
                    c[#c + 1] = { q.id, p[2], p[3] }
                end
            end
        end
    end
    return idx
end

-- andere Quests mit Zielen im Umkreis eines Punktes; liefert Menge {[questID] = true} und Anzahl
function P:BundleNear(idx, inst, n, w, skipId, out)
    out = out or {}
    local cn, cw = math.floor(n / BUNDLE_R), math.floor(w / BUNDLE_R)
    local r2 = BUNDLE_R * BUNDLE_R
    for dn = -1, 1 do
        for dw = -1, 1 do
            for _, e in ipairs(idx[CellKey(inst, cn + dn, cw + dw)] or {}) do
                if e[1] ~= skipId and not out[e[1]] then
                    local a, b = e[2] - n, e[3] - w
                    if a * a + b * b <= r2 then out[e[1]] = true end
                end
            end
        end
    end
    return out
end

-- Zahl der anderen Quests, deren Ziele bei mindestens einem Ziel dieser Quest liegen
function P:BundlePartners(idx, q)
    local set, c = {}, 0
    for _, o in ipairs(q.objectives or {}) do
        local pts = ObjPoints(o)
        for pi = 1, math.min(#pts, 6) do
            local p = pts[pi]
            self:BundleNear(idx, p[1], p[2], p[3], q.id, set)
        end
    end
    for _ in pairs(set) do c = c + 1 end
    return c, set
end

------------------------------------------------------------------------
-- EP je Kill nach Levelunterschied (ein Modell fuer Planung und virtuelle Reise)
--   gleich hoch: 45 + 5 x Spielerlevel; hoeher: +5 % je Level (hoechstens 4); tiefer: x (1 - Unterschied / ZD);
--   grau: 0. Classic-Formel. Auf WoW Forever geben gruene Monster zusaetzlich weniger (GreenXPFactor) - und
--   echte Messungen (Calib, je Levelunterschied) haben Vorrang.
------------------------------------------------------------------------
local ZD = { {7, 5}, {9, 6}, {11, 7}, {15, 8}, {19, 9}, {29, 11}, {39, 12}, {44, 13}, {49, 14}, {54, 15}, {60, 16} }
local function ZeroDiff(pl)
    for _, e in ipairs(ZD) do if pl <= e[1] then return e[2] end end
    return 16
end
P.ZeroDiff = ZeroDiff
-- hoechstes graues Monsterlevel (Classic): bis Level 5 nichts grau, dann Level - (Level/10 + 5) bzw. Level - (Level/5 + 1)
function P:GreyLevel(pl)
    if pl <= 5 then return 0 end
    if pl <= 39 then return pl - math.floor(pl / 10) - 5 end
    return pl - math.floor(pl / 5) - 1
end
-- reine Classic-Formel
function P:KillXPFormula(pl, ml)
    ml = ml or pl
    local base = 45 + 5 * pl
    if ml >= pl then return base * (1 + 0.05 * math.min(ml - pl, 4)) end
    if ml <= self:GreyLevel(pl) then return 0 end
    return math.max(0, base * (1 - (pl - ml) / ZeroDiff(pl)))
end
-- WoW Forever: gruene Monster (3 und mehr Level unter dir) geben weniger EP als in Classic.
-- SCHAETZUNG 0,85 (Guides: einige Prozent bis etwa ein Viertel je Kill), bis Messungen vorliegen.
P.FOREVER_GREEN = 0.85
P.GREEN_DIFF = 3
function P:GreenXPFactor(diff)
    local m = LP.Calib and LP.Calib:KillXPRatio(diff)
    if m then return m, true end
    if LP.API.Forever() and diff and diff <= -self.GREEN_DIFF then return self.FOREVER_GREEN, false end
    return 1, false
end
-- EP fuer einen Kill: Spielerlevel, Monsterlevel (nil = gleich hoch)
function P:KillXP(pl, ml)
    ml = ml and math.floor(ml + 0.5) or pl
    local f = self:GreenXPFactor(math.max(-5, math.min(4, ml - pl)))
    return self:KillXPFormula(pl, ml) * f
end
-- Monsterlevel einer Quest (fuer die Kills beim Questen): mittleres Level der Gegner, sonst das Questlevel
function P:QuestKillLevel(q, level)
    local sum, n = 0, 0
    for _, o in ipairs(q and q.objectives or {}) do
        if o.mobLevel then sum, n = sum + o.mobLevel, n + 1 end
    end
    if n > 0 then return sum / n end
    if q and q.level and q.level > 0 then return q.level end
    return level
end

local function GrindRate(level) return P:KillXP(level, level) * P:KillsPerMin() end
P.GrindRate = GrindRate

-- EP je Minute einer Quest inkl. Monster-EP beim Toeten (nil = unbekannt)
function P:Efficiency(q, level, partners)
    local xp = QuestXPFor(q, level)
    if not xp then return nil end
    local secs = QuestSeconds(q, partners)
    local tag = LP.API.QuestTag(q.id)
    if tag == 1 and not q.elite then secs = secs + 600 end      -- laut Spiel Gruppenquest
    local kills = 0
    for _, o in ipairs(q.objectives) do local _, k = P:ObjectiveCost(o.kind, o.elite, o) kills = kills + k end
    xp = xp + kills * P:KillXP(level, P:QuestKillLevel(q, level))   -- Monster beim Questen (Questlevel)
    return xp / (secs / 60)
end

-- Warum laesst der Speedrun diese Quest aus? (nil = behalten)
local function SpeedReason(q, level)
    if q.dungeon then return nil end                       -- Dungeons haben eigene Regeln
    local tag = LP.API.QuestTag(q.id)
    if tag == 62 or tag == 41 then return L["Schlachtzug/PvP"] end
    if q.escort or tag == 84 then return L["Eskorte"] end
    return nil
end

------------------------------------------------------------------------
-- Dungeons
------------------------------------------------------------------------
local DUNGEON_RETRY = 3          -- Stufen bis ein abgebrochener/uebersprungener Dungeon wiederkommt
local DUNGEON_LOG_FREE = 4       -- so viele Plaetze im Questlog bleiben fuer normale Quests frei
local PREP_RANGE = 2500          -- Yards: Dungeon-Quests in diesem Umkreis vor dem Lauf einsammeln

function P:DungeonUsable(area)
    if LP.db.dungeons == false then return false end
    return (LP.QuestDB:DungeonAllowed(area))
end

local function Round(v) return math.floor(v + 0.5) end

-- Questziele einer Dungeon-Quest, die wirklich draussen liegen. Die Questdaten projizieren Gegner
-- im Dungeon oft auf die Karte darueber - solche Orte nahe am Eingang zaehlen als "im Dungeon".
local INSIDE_RANGE = 600
local function OutsideSpots(area, spots)
    local d = LP.QuestDB:Dungeon(area)
    if not d then return spots end
    local ents = {}
    for _, e in ipairs(d.e or {}) do
        local i, en, ew = LP.Geo:ToWorld(e[1], e[2], e[3])
        if i then ents[#ents + 1] = { i, en, ew } end
    end
    local out = {}
    for _, sp in ipairs(spots) do
        local i, sn, sw = WorldOf(sp)
        if i then
            local inside = false
            for _, e in ipairs(ents) do
                if e[1] == i and LP.Geo:Dist(sn, sw, e[2], e[3]) < INSIDE_RANGE then inside = true break end
            end
            if not inside then out[#out + 1] = sp end
        end
    end
    return out
end
P.OutsideSpots = OutsideSpots

local function MakeTask(t, q, pt, wpos, value, text)
    return {
        t = t, id = q and q.id, q = q and q.name, level = q and q.level,
        map = pt and pt[1], x = pt and pt[2], y = pt and pt[3], npc = pt and pt[4],
        inst = wpos and wpos[1], n = wpos and wpos[2], w = wpos and wpos[3],
        value = value, text = text, isNew = q and q.isNew or nil,
        key = t .. ":" .. (q and q.id or (pt and (pt[1] .. ":" .. math.floor(pt[2]) .. ":" .. math.floor(pt[3])) or "?")),
    }
end

local GATHER = 400            -- Yards um den Spieler (Questannahmen im Umkreis einsammeln)
local ROUTE_SKIP = 150        -- Yards ab dem Spieler, die bei der Wegpruefung nicht zaehlen
local GRIND_RADIUS = 1500     -- Yards: so weit sucht LevelPilot eine Stelle zum Grinden
P.safeSkip = {}
P.mobSkip = {}       -- [questID] = Mob-Level (Pflichtregel: Mobs ab Spielerlevel + 3 sind tabu)
P.mobStats = { quest = 0, spots = 0, accept = 0, route = 0, path = 0, turnin = 0 }   -- Zaehler (Diagnose)
local MS = P.mobStats

-- Pflichtregel Mob-Level: effektives Level (Elite +2) der Gegner der noch offenen Ziele
local function ObjMobLevel(o)
    if not o.mobLevel then return nil end
    return o.mobLevel + (o.elite and LP.Danger.ELITE_BONUS or 0)
end
local function QuestMobLevel(q, objDone)
    local mx, any
    for oi, o in ipairs(q.objectives or {}) do
        if not (objDone and objDone[o.idx or oi]) then
            local lv = ObjMobLevel(o)
            if lv and (not mx or lv > mx) then mx = lv end
            if lv or o.kind == "object" or o.kind == "explore" then any = true end
        end
    end
    -- keine Angaben zu den Gegnern (z. B. Gegenstand von einem benannten Gegner): Questlevel als Schaetzung
    if not mx and not any and q.level and q.level > 0 and not q.dungeon then mx = q.level end
    return mx
end

P.QuestMobLevel = QuestMobLevel
-- nur Orte, an denen keine zu starken Mobs stehen
local function SafePoints(points, level)
    local D = LP.Danger
    if not D or not points then return points end
    local lim = D:Limit(level)
    local out = {}
    for _, pt in ipairs(points) do
        local i, n, w = WorldOf(pt)
        if not i or D:At(i, n, w) < lim then out[#out + 1] = pt end
    end
    return out
end
P.SafePoints = SafePoints
-- Sind alle Zielorte einer Quest zu gefaehrlich?
local function AllSpotsUnsafe(q, level)
    local all = {}
    for _, o in ipairs(q.objectives or {}) do for _, sp in ipairs(o.spots or {}) do all[#all + 1] = sp end end
    return #all > 0 and #SafePoints(all, level) == 0
end

function P:CollectTasks(inst, n, w, level)
    wipe(self.safeSkip)
    wipe(self.mobSkip)
    local tasks = {}
    local dq = {}        -- [Dungeon] = offene Dungeon-Quests im Log
    local logCount = 0
    for _ in pairs(inLog) do logCount = logCount + 1 end
    local maxLog = LP.API.MaxQuests()
    local turninBoost = logCount >= maxLog - 4 and 2 or 1
    local accepts = {}   -- annehmbare Quests (Speedrun filtert danach)
    local speed = self:IsSpeed()
    -- aktive Quests
    for id, st in pairs(inLog) do
        if not LP.char.ignored[id] and not st.failed then
            local q = LP.QuestDB:Get(id) or { id = id, name = st.title, starts = {}, ends = {}, objectives = {} }
            -- Titel aus dem Questlog nur, wenn kein Sprachpaket einen in der eingestellten Sprache kennt
            if LP.Names and LP.Names:Foreign() then q.name = LP.Names:Quest(id) or st.title or q.name
            else q.name = st.title or q.name end
            if st.complete then
                local ends = SafePoints(q.ends, level)
                if #ends == 0 and #(q.ends or {}) > 0 then self.mobSkip[id] = LP.Danger:Limit(level) MS.turnin = MS.turnin + 1 end
                local pt, _, wp = NearestPoint(ends, inst, n, w)
                if pt or #(q.ends or {}) == 0 then
                    tasks[#tasks + 1] = MakeTask("TURNIN", q, pt, wp, (2 * LevelWeight(q.level, level) + 1) * turninBoost)
                end
            else
                -- naechster Ort eines noch offenen Ziels
                local spots = {}
                for oi, o in ipairs(q.objectives) do
                    local idx = o.idx or oi
                    if not st.objDone[idx] then
                        for _, s in ipairs(o.spots) do spots[#spots + 1] = s end
                    end
                end
                if #spots == 0 then
                    for _, o in ipairs(q.objectives) do
                        for _, s in ipairs(o.spots) do spots[#spots + 1] = s end
                    end
                end
                local area = q.dungeon
                if area then spots = OutsideSpots(area, spots) end
                -- Pflichtregel: keine Ziele mit Mobs ab Spielerlevel + 3 (ausser im Dungeon-Lauf mit Gruppe)
                local mobLv = not area and QuestMobLevel(q, st.objDone)
                local blocked = mobLv and not LP.Danger:OK(mobLv, level)
                if not area and not blocked then
                    local safe = SafePoints(spots, level)
                    if #safe == 0 and #spots > 0 then blocked = true mobLv = LP.Danger:Limit(level) MS.spots = MS.spots + 1 end
                    spots = safe
                end
                if blocked then self.mobSkip[id] = mobLv if not MS._spot then MS.quest = MS.quest + 1 end end
                local pt, _, wp
                if not blocked then pt, _, wp = NearestPoint(spots, inst, n, w) end
                if blocked then
                    -- spaeter, wenn das Level reicht
                elseif area and not pt then
                    -- Ziele liegen in der Instanz: gesammelt als ein Dungeon-Lauf
                    local grey = q.level and q.level > 0 and q.level < level - GreyRange(level)
                    if self:DungeonUsable(area) and not grey then
                        dq[area] = dq[area] or {}
                        table.insert(dq[area], q)
                    end
                else
                    local v = 1.5 * LevelWeight(q.level, level) + 0.5
                    -- Speedrun: angefangene langsame Quests nur noch nebenbei
                    if speed and not self:IsProtected(id) and (q.elite or q.escort) then v = v * 0.5 end
                    tasks[#tasks + 1] = MakeTask("COMPLETE", q, pt, wp, v)
                end
            end
        end
    end
    -- annehmbare Quests
    for ci, id in ipairs(candidates) do
        if ci % 5 == 0 then LP:Yield("plan") end
        if not inLog[id] then
            local q = LP.QuestDB:Get(id)
            if q and self:IsAvailable(q, level) then
                local d = q.dungeon and LP.QuestDB:Dungeon(q.dungeon)
                local pt, pd, wp = NearestPoint(SafePoints(q.starts, level), inst, n, w)
                -- Pflichtregel: Quest erst annehmen, wenn ihre Gegner machbar sind
                local mobLv = not d and QuestMobLevel(q)
                if pt and not d and not mobLv and AllSpotsUnsafe(q, level) then mobLv = LP.Danger:Limit(level) end
                if pt and mobLv and not LP.Danger:OK(mobLv, level) then
                    self.mobSkip[id] = mobLv
                    MS.accept = MS.accept + 1
                    pt = nil
                end
                local value = LevelWeight(q.level, level)
                -- Sicherer Modus: Elite und deutlich hoehere Gegner meiden (Klassenquests bleiben, mit Warnung)
                if pt and not d and LP.db.safeMode then
                    -- Sicherer Modus: vorsichtiger als die Pflichtregel (+3) - Elite und Gegner ab eigenem Level + 1
                    local danger = q.elite or (q.mobLevel and q.mobLevel >= level + 1)
                    if danger and not self:IsProtected(id) then
                        self.safeSkip[id] = q.elite and L["Elite"] or (L["Gegner Stufe "] .. q.mobLevel)
                        pt = nil
                    end
                end
                if d then
                    -- erst kurz vor dem passenden Level und nur mit Platz im Log mitnehmen
                    if not self:DungeonUsable(q.dungeon) or level < d.min - 2 or level > d.max
                       or logCount >= maxLog - DUNGEON_LOG_FREE then
                        pt = nil
                    else
                        value = value * (level >= d.min - 1 and 1.2 or 0.6)
                    end
                end
                if pt then
                    local t = MakeTask("ACCEPT", q, pt, wp, value)
                    t.dungeon = q.dungeon
                    accepts[#accepts + 1] = { t = t, q = q }
                end
            end
        end
    end
    self:SpeedFilter(accepts, tasks, level, inst, n, w)
    -- Pflichtregel auch fuer den Weg: fuehrt die gerade Strecke durch ein Gebiet mit zu starken Mobs, ist die
    -- Aufgabe weniger wert (der echte Weg des ersten Ziels wird nach der Reihenfolge genau geprueft)
    local Dg = LP.Danger
    if Dg and Dg.pathRule and inst then
        local lim = Dg:Limit(level)
        for _, t in ipairs(tasks) do
            if t.inst == inst and t.n and t.t ~= "DUNGEON" and Dg:Route(inst, n, w, t.n, t.w, ROUTE_SKIP) >= lim then
                t.value = (t.value or 1) * 0.5
                MS.route = MS.route + 1
            end
        end
    end
    self:DungeonTasks(dq, tasks, inst, n, w, level)
    for i = #tasks, 1, -1 do if tasks[i].drop then table.remove(tasks, i) end end
    -- Gruppe: Quests, die auch Mitspieler haben, gemeinsam erledigen
    local shared = LP.Group and LP.Group:SharedQuests()
    if shared then
        for _, t in ipairs(tasks) do
            local c = t.id and shared[t.id]
            if c then t.value = t.value * (1 + 0.3 * math.min(c, 3)) t.shared = c end
        end
    end
    return tasks
end

-- Speedrun: langsame Quests auslassen, schnelle bevorzugen (Klassenquests bleiben)
local CROSS_SECS = 900          -- anderer Kontinent: Weg zu Schiff/Zeppelin, Warten, Fahrt (Sekunden)
local RUN_YPS = 7               -- Yards pro Sekunde zu Fuss
local HUB_SHARE = 250           -- Yards: Questgeber an einem Ort teilen sich den Weg

-- Raster der offenen Ziele im Questlog (und optional weiterer Quests)
function P:LogBundleIndex(level, extra)
    local entries = {}
    for id, st in pairs(self.inLog) do
        if not st.complete then
            local q = LP.QuestDB:Get(id)
            if q and not q.dungeon then entries[#entries + 1] = { q = q, done = st.objDone } end
        end
    end
    for _, q in ipairs(extra or {}) do entries[#entries + 1] = { q = q } end
    return self:BundleIndex(entries, level)
end

function P:SpeedFilter(accepts, tasks, level, inst, n, w)
    wipe(self.speedSkip)
    if not self:IsSpeed() then
        for _, a in ipairs(accepts) do tasks[#tasks + 1] = a.t end
        return
    end
    -- Questgeber-Gruppen: der Weg dorthin teilt sich auf alle Quests, die man am selben Ort annimmt
    local function HubSize(a)
        if not a.t.n then return 1 end
        local c = 0
        for _, b in ipairs(accepts) do
            if b.t.inst == a.t.inst and b.t.n and LP.Geo:Dist(a.t.n, a.t.w, b.t.n, b.t.w) <= HUB_SHARE then c = c + 1 end
        end
        return math.max(1, c)
    end
    -- Buendeln: Ziele, die neben Zielen anderer Quests liegen (im Log oder hier annehmbar), teilen die Suche
    local extra = {}
    for _, a in ipairs(accepts) do if not a.q.dungeon then extra[#extra + 1] = a.q end end
    local bidx = self:LogBundleIndex(level, extra)
    for ai, a in ipairs(accepts) do
        if ai % 10 == 0 then LP:Yield("plan") end
        if not a.q.dungeon then
            a.bundle = self:BundlePartners(bidx, a.q)
            a.eff = self:Efficiency(a.q, level, a.bundle)
            -- der Weg zum Questgeber zaehlt fuer die Reihenfolge, nicht fuers Auslassen
            -- (sonst faellt in einer Stadt fern der Questgeber jede Quest durch und es wird endlos gegrindet)
            if a.eff and inst then
                local secs = QuestSeconds(a.q, a.bundle)
                local travel = (a.t.inst == inst and a.t.n) and (LP.Geo:Dist(n, w, a.t.n, a.t.w) / RUN_YPS) or CROSS_SECS
                travel = travel / HubSize(a)
                a.travelF = math.max(0.35, secs / (secs + travel * 0.5))
            end
        end
    end
    local med = GrindRate(level)
    local cut = SPEED_CUTOFF[LP.db.speedLevel or 3] or SPEED_CUTOFF[3]
    -- EP je Minute beim Questen (Median), fuer die Monster am Weg: nur mitnehmen, was mindestens so viel bringt
    local effs = {}
    for _, a in ipairs(accepts) do if a.eff then effs[#effs + 1] = a.eff end end
    table.sort(effs)
    self.questRate = #effs > 0 and effs[math.floor((#effs + 1) / 2)] or nil
    for _, a in ipairs(accepts) do
        local id = a.q.id
        local reason
        if not self:IsProtected(id) then
            reason = SpeedReason(a.q, level)
            -- Ziel: so schnell wie moeglich auf 60, ohne grosses Grinden. Darum bleiben Quests drin, die
            -- Folgequests freischalten (die Kette bringt mehr als die einzelne Quest) und Quests an einem Ort mit
            -- mehreren Questgebern (der Weg dorthin lohnt sich ohnehin). Ausgelassen wird nur, was klar langsam ist.
            local chain = a.q.nextInChain and a.q.nextInChain ~= 0
            -- gebuendelt (Ziele bei Zielen anderer Quests): steckt schon in a.eff (geteilte Suchzeit)
            local hub = HubSize(a) >= SPEED_HUB
            local low = a.q.level and a.q.level > 0 and a.q.level <= level - SPEED_LOW
            if not reason and low and not hub then reason = L["zu niedrig"] end
            -- Gegenstaende, die selten fallen: klar langsam, auch an einem Questgeber-Ort
            if not reason and not chain and self:SlowDrop(a.q) then reason = L["Gegenstände fallen selten"] end
            -- gebuendelt (Ziele bei Zielen anderer Quests): man ist ohnehin dort - nur auslassen, wenn sehr langsam
            local bcut = (a.bundle or 0) >= 1 and cut * P.BUNDLE_CUT or cut
            if not reason and not chain and not hub and a.eff and a.eff < med * bcut then reason = L["dauert zu lange"] end
        end
        if reason then
            self.speedSkip[id] = reason
        else
            if self:IsProtected(id) and IsClassQuest(a.q.classes) then a.t.value = a.t.value + 1 a.t.classQuest = true end
            if a.travelF then a.t.value = a.t.value * a.travelF end
            tasks[#tasks + 1] = a.t
        end
    end
end

-- Einen Dungeon-Lauf einplanen, wenn er sich jetzt lohnt.
-- Im passenden Level werden die Dungeon-Quests in Reichweite gezielt eingesammelt (auch ausserhalb
-- der Fokus-Zone), danach geht es in den Dungeon - so muss man nicht zweimal hin.
local SINGLE_RANGE = 1000        -- Yards: mit nur einer Quest nur, wenn man praktisch am Eingang ist
-- Zeit und Monster-EP eines Laufs
local DG_SEARCH, DG_RUN, DG_PER_QUEST = 900, 2700, 420   -- Gruppensuche, Lauf (Ersatzwert), je Quest (Sekunden)
local DG_KILLS = 60              -- Elite-Kills je Lauf (EP bereits auf 5 Spieler geteilt)
local DG_NEED = { normal = 0.55, speed = 0.9 } -- mindestens so viel EP/Minute wie x-mal Grinden

-- Monster-EP in Dungeons auf WoW Forever (VORLAEUFIG, Stand 2.11.2026): im September stark gesenkt (ohne Zahl,
-- Schaetzung -70 %), am 8.10.2026 um etwa 20 % gegenueber der Beta erhoeht -> 0,3 x 1,2 = 0,36.
-- Reihenfolge: Einstellung (%) -> im Dungeon gemessen (Calib) -> Schaetzung. Classic: 1,0.
P.FOREVER_DG_MOB = 0.36
function P:DungeonXPFactor()
    local pct = tonumber(LP.db.dungeonMobXP)
    if pct and pct > 0 then return pct / 100, "set" end
    if LP.API.Forever() then
        local m = LP.Calib and LP.Calib:DungeonXPRatio()
        if m then return m, "measured" end
        return self.FOREVER_DG_MOB, "auto"
    end
    return 1.0, "auto"
end

-- Quest-EP von Dungeon-Quests auf WoW Forever (VORLAEUFIG, Stand 2.11.2026): Beta +94 bis +138 %, am 1.10.2026
-- Bonus-Anteil um 50 % gekuerzt -> etwa +47 bis +69 %, Planung 1,5. Gemessene Quest-EP haben Vorrang (BaseXP).
P.FOREVER_DG_QUEST = 1.5
function P:DungeonQuestFactor()
    local pct = tonumber(LP.db.dungeonQuestXP)
    if pct and pct > 0 then return pct / 100, "set" end
    return LP.API.Forever() and self.FOREVER_DG_QUEST or 1.0, "auto"
end

-- EP je Minute eines Dungeon-Laufs mit diesen Quests (Quest-EP + Monster-EP)
function P:DungeonRate(quests, level, area)
    local xp = 0
    local qf = self:DungeonQuestFactor()
    for _, q in ipairs(quests) do
        local _, measured = BaseXP(q)
        -- gemessene Forever-EP enthalten den Dungeon-Bonus schon
        xp = xp + (QuestXPFor(q, level) or self:KillXP(level, level) * 10) * (measured and 1 or qf)   -- unbekannt: wie 10 Kills
    end
    xp = xp + self:KillXPFormula(level, level) * DG_KILLS * self:DungeonXPFactor()
    local d = area and LP.Dungeons[area]
    local secs = DG_SEARCH + (d and d.run and d.run * 60 or DG_RUN) + DG_PER_QUEST * #quests
    return xp / (secs / 60)
end
P.dungeonWorth = {}   -- [Dungeon] = Text fuer Anzeige/Diagnose
P.dungeonDead = {}    -- [questID] = true: Dungeon-Quest im Log, deren Lauf sich nicht lohnt

function P:DungeonTasks(dq, tasks, inst, n, w, level)
    local minQuests = LP.db.dungeonMin or 2
    if self:IsSpeed() then minQuests = math.max(minQuests, SPEED_DUNGEON_MIN) end
    local need = GrindRate(level) * (self:IsSpeed() and DG_NEED.speed or DG_NEED.normal)
    local worthArea = {}
    wipe(self.dungeonWorth)
    wipe(self.dungeonDead)
    local avail = {}
    for _, t in ipairs(tasks) do
        if t.t == "ACCEPT" and t.dungeon and t.inst == inst then
            avail[t.dungeon] = avail[t.dungeon] or {}
            table.insert(avail[t.dungeon], t)
        end
    end
    local areas = {}
    for a in pairs(dq) do areas[a] = true end
    for a in pairs(avail) do areas[a] = true end
    for area in pairs(areas) do
        local list, acc = dq[area] or {}, avail[area] or {}
        local d = LP.QuestDB:Dungeon(area)
        local last = LP.char.dungeonRun[area]
        if d and not (last and level < last + DUNGEON_RETRY) then
            local sum, cnt, value = 0, 0, 0
            local names = {}
            for _, q in ipairs(list) do
                if q.level and q.level > 0 then sum = sum + q.level cnt = cnt + 1 end
                value = value + 1.5 * LevelWeight(q.level, level) + 0.5
                names[#names + 1] = q.name
            end
            for _, t in ipairs(acc) do
                if t.level and t.level > 0 then sum = sum + t.level cnt = cnt + 1 end
            end
            local avg = cnt > 0 and sum / cnt or d.min
            -- Eingang: der naechste auf diesem Kontinent
            local pt, dist, wp = NearestPoint(d.e, inst, n, w)
            local ready = level >= math.max(d.min, Round(avg) - 3)
            -- lohnt sich der Lauf ueberhaupt? (alle Quests, die man bis dahin haben kann)
            -- gezaehlt werden nur Quests, die man wirklich zusammen haben kann: im Log + jetzt annehmbar in der Naehe
            local all, near = {}, {}
            for _, q in ipairs(list) do all[#all + 1] = q end
            for _, t in ipairs(acc) do
                if LP.Geo:Dist(n, w, t.n, t.w) < PREP_RANGE then
                    near[#near + 1] = t
                    local aq = LP.QuestDB:Get(t.id)
                    if aq then all[#all + 1] = aq end
                end
            end
            local rate = self:DungeonRate(all, level, area)
            local worth = rate >= need
            if worth then worthArea[area] = true end
            self.dungeonWorth[area] = string.format(L["%s: %d EP/Min (nötig %d)%s"], d.name, rate, need, worth and "" or L[" – lohnt nicht"])
            if not worth then
                -- Lauf lohnt nicht: Quests dafuer gar nicht erst annehmen (blockieren sonst den Questlog)
                for _, t in ipairs(acc) do t.drop = true end
                for _, q in ipairs(list) do self.dungeonDead[q.id] = true end
            end
            if pt and ready and worth then
                if #all >= minQuests then
                    for _, t in ipairs(near) do t.prep = true t.value = t.value + 1 end
                end
                local single = #list >= 1 and #near == 0 and dist and dist < SINGLE_RANGE
                -- laufen, sobald alles Erreichbare eingesammelt ist (oder die Quests im Log schon reichen)
                local collected = #near == 0 or self:DungeonRate(list, level, area) >= need
                if (#list >= minQuests or single) and collected then
                    local urgent = level >= Round(avg) + 2
                    value = value * 1.4 + 2 * self:DungeonXPFactor()   -- Monster-EP im Dungeon
                    if LP.QuestDB:DungeonHostile(area) then value = value * 0.6 end
                    if urgent then value = value * 1.5 end
                    tasks[#tasks + 1] = {
                        t = "DUNGEON", area = area, q = d.name, level = Round(avg), quests = names,
                        map = pt[1], x = pt[2], y = pt[3], inst = wp[1], n = wp[2], w = wp[3],
                        value = value, urgent = urgent, hostile = LP.QuestDB:DungeonHostile(area),
                        min = d.min, max = d.max, key = "DG:" .. area,
                    }
                end
            end
        end
    end
    -- Dungeon-Quests nur annehmen, wenn ihr Lauf sich gerade nachweislich lohnt
    for _, t in ipairs(tasks) do
        if t.t == "ACCEPT" and t.dungeon and not worthArea[t.dungeon] then t.drop = true end
    end
end

------------------------------------------------------------------------
-- 4) Fokus-Zone
------------------------------------------------------------------------

local OTHER_CONTINENT = 12000   -- Reisekosten (Yards) fuer einen Kontinentwechsel
local TRAVEL_SCALE = 900        -- je so viele Yards halbiert sich der Wert einer Zone
local DRAIN = 2.5               -- Restwert, ab dem eine Zone als "abgearbeitet" gilt
local SWITCH_NEAR = 500       -- Yards: alte Fokus-Zone gilt als verlassen
local CROSS_MIN_TASKS = 5     -- so viele Aufgaben braucht eine Zone auf einem anderen Kontinent
local CROSS_MIN_LEVEL = 12    -- darunter kein Kontinentwechsel fuer neue Fokus-Zonen
local CONT_MIN_LEVELS = 3     -- so viele Level zwischen zwei Kontinentwechseln
local TURNIN_FOCUS = 0.3      -- Anteil einer Abgabe am Wert einer Zone bei der Wahl der Fokus-Zone
-- In der Zone bleiben (so wenig Zonenwechsel wie moeglich): die Fokus-Zone wird erst verlassen, wenn dort fast
-- nichts mehr zu tun ist - Abgaben zaehlen dafuer voll (sonst kommt man spaeter nur fuer die Abgaben zurueck).
-- Eine eben verlassene Zone lohnt sich erst wieder, wenn dort viel Neues wartet.
local STAY_MIN = 1.0          -- Restwert (Abgaben voll gezaehlt), bis zu dem man in der Fokus-Zone bleibt
local RETURN_LEVELS = 4       -- so viele Level gilt eine verlassene Zone als "eben verlassen"
local RETURN_PENALTY = 0.4    -- Abschlag fuer die Rueckkehr in eine eben verlassene Zone
local SIZE_BONUS = 12         -- groessere Pakete bevorzugen (bis zu doppelter Wert bei so vielen Aufgaben)
P.leftZones = {}              -- [Karte] = Level beim Verlassen
function P:LogCount()
    local c = 0
    for _ in pairs(self.inLog or {}) do c = c + 1 end
    return c
end
P.focusChanges, P.focusReturns = 0, 0
P.OPT = { stay = true, ret = true, size = true, collect = true, small = true }
local SMALL_FAR = 1500        -- Yards: so weit reist man hoechstens fuer eine Zone mit wenig zu tun   -- Schalter fuer die Testumgebung

function P:ChooseFocus(tasks, inst, n, w, curZone, excluded)
    if LP.char.focusZone then return LP.char.focusZone end
    excluded = excluded or {}
    -- Dungeon, dessen Quests bald grau werden: jetzt hin
    for _, t in ipairs(tasks) do
        if t.t == "DUNGEON" and t.urgent and t.inst == inst then self.focusWhy = "dungeon" return t.map end
    end
    local zones = {}
    for _, t in ipairs(tasks) do
        if t.map and t.inst and not t.pathBlocked and not excluded[t.map] then
            local z = zones[t.map]
            if not z then
                z = { value = 0, cnt = 0, inst = t.inst, near = nil }
                zones[t.map] = z
            end
            -- Abgaben erledigt man, wenn man ohnehin dort ist: fuer die Wahl der Zone zaehlen sie weniger
            -- (sonst zieht jede einzelne Abgabe in eine andere Zone)
            z.value = z.value + t.value * (t.t == "TURNIN" and TURNIN_FOCUS or 1)
            z.stay = (z.stay or 0) + t.value
            z.cnt = z.cnt + 1
            local d = (t.inst == inst) and LP.Geo:Dist(n, w, t.n, t.w) or OTHER_CONTINENT
            if not z.near or d < z.near then z.near = d end
        end
    end
    -- 1) Bisherige Fokus-Zone erst fertig machen
    --    (ausser der Spieler ist sichtbar in eine andere lohnende Zone gewechselt)
    local cur = self.focus and zones[self.focus]
    local here = zones[curZone]
    -- (nur auf dem Weg durch eine Zone oder nach einem Flug: Fokus behalten; wechseln nur, wenn die Zone
    -- hier deutlich mehr bringt)
    local moved = here and curZone ~= self.focus and here.value >= DRAIN
                  and cur and cur.near > SWITCH_NEAR and here.cnt >= 3
                  and here.value >= (P.OPT.stay and cur.stay or cur.value) * 1.5
    if cur and not moved and (P.OPT.stay and cur.stay >= STAY_MIN or cur.value >= DRAIN) then return self.focus end
    local level = LP:PlayerLevel() or 1
    local function Recent(map) local l = P.OPT.ret and self.leftZones[map] return l and level - l < RETURN_LEVELS end
    -- 2) Zone, in der man steht, wenn es dort genug zu tun gibt (eben verlassen: nur mit viel Neuem)
    if here and here.value >= DRAIN * (Recent(curZone) and 2 or 1) then self.focusWhy = (moved and "moved " or "here ") .. string.format("%.1f", here.value) return curZone end
    -- 3) Sonst die lohnendste Zone; einzelne Aufgaben rechtfertigen keine weite Reise
    --    Ein anderer Kontinent (Schiff/Zeppelin, 10-15 min) lohnt sich nur fuer ein ganzes Paket Quests,
    --    und nur, wenn auf diesem Kontinent kaum noch etwas zu tun ist
    local homeValue = 0
    for _, z in pairs(zones) do if z.inst == inst and z.value > homeValue then homeValue = z.value end end
    local lowLevel = (LP:PlayerLevel() or 1) < CROSS_MIN_LEVEL   -- Startgebiete: auf dem eigenen Kontinent bleiben
    local best, bestScore
    for map, z in pairs(zones) do
        local sc = z.value / (1 + z.near / TRAVEL_SCALE)
        if z.cnt < 3 and z.near > 1500 then sc = sc * 0.4 end
        -- fuer eine einzelne kleine Aufgabe nicht weit reisen: lieber kurz in der Naehe Monster besiegen, bis
        -- mit dem naechsten Level neue Quests kommen (sonst springt die Route quer durch die Welt)
        if P.OPT.small and z.value < DRAIN and z.near > SMALL_FAR then sc = 0 end
        if P.OPT.size then sc = sc * (1 + math.min(z.cnt, SIZE_BONUS) / SIZE_BONUS) end
        if Recent(map) then sc = sc * RETURN_PENALTY end
        if z.inst ~= inst and (z.cnt < CROSS_MIN_TASKS or z.value < homeValue * 2 or lowLevel) then sc = 0 end
        -- Kontinentwechsel hoechstens alle CONT_MIN_LEVELS Level (ausser hier ist gar nichts mehr zu tun)
        if z.inst ~= inst and homeValue > 0 and self.contLevel and (LP:PlayerLevel() or 1) - self.contLevel < CONT_MIN_LEVELS then sc = 0 end
        if sc > 0 and (not bestScore or sc > bestScore) then best, bestScore = map, sc end
    end
    self.focusWhy = best and string.format("best %.1f/%d cur %s", zones[best].value, zones[best].cnt, cur and string.format("%.1f", cur.stay) or "-") or "none"
    return best
end

------------------------------------------------------------------------
-- 5) Reihenfolge
------------------------------------------------------------------------
local TYPE_BONUS = { ACCEPT = 0.85, TURNIN = 0.85, COMPLETE = 1.0, DUNGEON = 1.2 }

-- Erst annehmen, dann questen: Alle annehmbaren Quests in der Naehe des Spielers (GATHER) werden
-- eingesammelt, bevor ein Questziel drankommt. Kommt die Route spaeter an einen Questgeber, werden
-- alle Questgeber im Umkreis (HUB) gleich mit besucht. Abgaben an denselben Orten laufen mit (sie
-- schaffen Platz im Log und schalten Folgequests frei). Nie mehr Quests, als ins Log passen.
local HUB = 250               -- Yards um einen Questgeber
local TURNIN_FAR = 800        -- Yards: einzelne Abgaben weiter weg werden gesammelt
local TURNIN_ALONE = 0.35     -- Wert einer einzelnen fernen Abgabe (kommt ans Ende, wenn nichts vorbeifuehrt)
P.GATHER, P.HUB = GATHER, HUB

function P:Order(tasks, inst, n, w)
    local out, used = {}, {}
    local cn, cw = n, w
    local logCount = 0
    for _ in pairs(inLog) do logCount = logCount + 1 end
    local free = LP.API.MaxQuests() - logCount
    local anchorN, anchorW, anchorR = n, w, GATHER      -- Sammelpunkt: zuerst der Spieler selbst
    local function inHub(t)
        return t.inst == inst and (t.t == "ACCEPT" or t.t == "TURNIN") and t.n
               and LP.Geo:Dist(anchorN, anchorW, t.n, t.w) <= anchorR
    end
    for _ = 1, math.min(#tasks, MAX_STEPS) do
        LP:Yield("plan")
        -- gibt es am Sammelpunkt noch etwas anzunehmen (und Platz im Log)? Dann nur das (+ Abgaben dort)
        local gather = false
        if anchorN and free > 0 then
            for i, t in ipairs(tasks) do
                if not used[i] and t.t == "ACCEPT" and inHub(t) then gather = true break end
            end
        end
        if not gather then anchorN = nil end
        local best, bestC
        for i, t in ipairs(tasks) do
            if not used[i] and (not gather or inHub(t)) then
                local c
                if t.inst == inst then
                    c = LP.Geo:Dist(cn, cw, t.n, t.w) * (TYPE_BONUS[t.t] or 1)
                elseif not t.inst then
                    c = 5000   -- Ort unbekannt: ans Ende
                else
                    c = 30000  -- anderer Kontinent: nur, wenn hier wirklich nichts Lohnendes mehr ist
                end
                c = c / (0.6 + 0.4 * math.min(t.value or 1, 1.5))
                -- Log voll: Annahmen erst, wenn wieder Platz ist (nach Abgaben)
                if t.t == "ACCEPT" and free <= 0 then c = c * 50 + 50000 end
                if not bestC or c < bestC then best, bestC = i, c end
            end
        end
        if not best then break end
        used[best] = true
        local t = tasks[best]
        out[#out + 1] = t
        if t.inst == inst then cn, cw = t.n, t.w end
        if t.t == "ACCEPT" then
            free = free - 1
            -- an einem Questgeber angekommen: dessen Umgebung mit einsammeln
            if not anchorN and t.inst == inst and t.n then anchorN, anchorW, anchorR = t.n, t.w, HUB end
        elseif t.t == "TURNIN" then
            free = free + 1
        end
    end
    self:TwoOpt(out, inst, n, w, LP.API.MaxQuests() - logCount)
    return out
end

-- Reihenfolge nachbessern: Gesamtstrecke der Kette (nicht nur der jeweils naechste Schritt) mit 2-opt kuerzen.
-- Bedingungen: je Quest annehmen vor erledigen vor abgeben; der Questlog laeuft nie ueber.
local ORDER_RANK = { ACCEPT = 1, COMPLETE = 2, TURNIN = 3 }
local function LegCost(a, b)
    if not a or not b or not a.inst or not b.inst then return 0 end
    if a.inst ~= b.inst then return 30000 end
    return LP.Geo:Dist(a.n, a.w, b.n, b.w)
end
local function Valid(list, free)
    local seen = {}
    for _, t in ipairs(list) do
        local r = ORDER_RANK[t.t]
        if r and t.id then
            if (seen[t.id] or 0) > r then return false end
            seen[t.id] = r
        end
        if t.t == "ACCEPT" then free = free - 1 if free < 0 then return false end
        elseif t.t == "TURNIN" then free = free + 1 end
    end
    return true
end
function P:TwoOpt(list, inst, n, w, free)
    local m = #list
    if m < 4 then return end
    -- nur der Teil mit bekannten Orten auf diesem Kontinent (der Rest bleibt hinten)
    local k = 0
    while k < m and list[k + 1].inst == inst and list[k + 1].n do k = k + 1 end
    if k < 4 then return end
    local start = { inst = inst, n = n, w = w }
    local function at(i) return i == 0 and start or list[i] end
    local improved, passes = true, 0
    while improved and passes < 4 do
        improved = false
        passes = passes + 1
        for i = 2, k - 2 do   -- der erste Schritt bleibt (nach Wert und Naehe gewaehlt), der Rest wird kuerzer
            LP:Yield("plan")
            for j = i + 1, k do
                -- Kanten (i-1 -> i) und (j -> j+1) durch (i-1 -> j) und (i -> j+1) ersetzen = Abschnitt i..j umdrehen
                local a, b, c, d = at(i - 1), list[i], list[j], j < k and list[j + 1] or nil
                local delta = LegCost(a, c) + LegCost(b, d) - LegCost(a, b) - LegCost(c, d)
                if delta < -10 then
                    local lo, hi = i, j
                    while lo < hi do list[lo], list[hi] = list[hi], list[lo] lo, hi = lo + 1, hi - 1 end
                    if Valid(list, free) then
                        improved = true
                    else
                        lo, hi = i, j
                        while lo < hi do list[lo], list[hi] = list[hi], list[lo] lo, hi = lo + 1, hi - 1 end
                    end
                end
            end
        end
        -- Or-opt: Block von 1-3 Schritten an eine bessere Stelle verschieben (z. B. alle Ratchet-Schritte ans Ende)
        for len = 3, 1, -1 do
            for i = 2, k - len + 1 do
                LP:Yield("plan")
                local j = i + len - 1
                local prev, first, last, nxt = at(i - 1), list[i], list[j], j < k and list[j + 1] or nil
                local removeGain = LegCost(prev, first) + LegCost(last, nxt) - LegCost(prev, nxt)
                local bestPos, bestDelta
                for p = 1, k do
                    if p < i - 1 or p > j then
                        local A, B = at(p), p < k and list[p + 1] or nil
                        local delta = LegCost(A, first) + LegCost(last, B) - LegCost(A, B) - removeGain
                        if delta < -10 and (not bestDelta or delta < bestDelta) then bestPos, bestDelta = p, delta end
                    end
                end
                if bestPos then
                    local backup = {}
                    for x = 1, #list do backup[x] = list[x] end
                    local block = {}
                    for x = i, j do block[#block + 1] = list[x] end
                    for _ = i, j do table.remove(list, i) end
                    local ins = bestPos > j and bestPos - len or bestPos
                    for x = #block, 1, -1 do table.insert(list, ins + 1, block[x]) end
                    if Valid(list, free) then
                        improved = true
                    else
                        for x = 1, #backup do list[x] = backup[x] end
                    end
                end
            end
        end
    end
end

------------------------------------------------------------------------
-- Reise: Flugpunkte
------------------------------------------------------------------------
local function NearestTaxi(inst, n, w, maxD)
    local best, bestD
    for key in pairs(LP.char.taxiKnown) do
        local tx = LP.db.taxi[key] or (LP.Seed.taxi and LP.Seed.taxi[key])
        local _, _, _, i, tn, tw = LP.Geo:TaxiPoint(tx)
        if i then
            if i == inst then
                local d = LP.Geo:Dist(n, w, tn, tw)
                if d <= maxD and (not bestD or d < bestD) then best, bestD = tx, d end
            end
        end
    end
    return best, bestD
end

-- Unbekannter Flugmeister der eigenen Fraktion in der Naehe -> Flugpunkt mitnehmen
local FP_RANGE = 1000
P.FP_RANGE = FP_RANGE
function P:FlightPointTask(inst, n, w, curZone)
    local best, bestD
    for _, v in ipairs(LP.QuestDB:ServiceNPCs().flight or {}) do
        local key = (v.name or "?") .. ":" .. v.map
        if v.map == curZone and not LP.char.fpVisited[key] and not LP.char.doneKeys["FP:" .. key] then
            local i, vn, vw = LP.Geo:ToWorld(v.map, v.x, v.y)
            -- Pflichtregel: nicht zu Flugmeistern, an denen zu starke Mobs stehen
            if i == inst and LP.Danger and LP.Danger:At(i, vn, vw) >= LP.Danger:Limit() then i = nil end
            if i == inst then
                local d = LP.Geo:Dist(n, w, vn, vw)
                if d <= (P.FP_RANGE or FP_RANGE) and (not bestD or d < bestD) then best, bestD = v, d end
            end
        end
    end
    if not best then return nil end
    local i, vn, vw = LP.Geo:ToWorld(best.map, best.x, best.y)
    return { t = "FP", map = best.map, x = best.x, y = best.y, inst = i, n = vn, w = vw, npc = best.name,
             text = L["holen bei "] .. (best.name or L["Flugmeister"]), key = "FP:" .. (best.name or "?") .. ":" .. best.map }
end

------------------------------------------------------------------------
-- Ruhestein: benutzen, wenn das Ziel nahe am Bindeort und weit weg ist; binden in neuen Hauptzonen
------------------------------------------------------------------------
-- Ruhestein: Mindestweg (Yards), Bindeort hoechstens dieser Anteil des Weges vom Ziel, Gastwirt in der Naehe (Yards)
P.HEARTH = { min = 1200, gain = 0.5, bind = 600 }
local BIND_TASKS = 6          -- so viele Aufgaben in der Zone, damit sich das Binden lohnt
local BIND_TASKS_SPEED = 3    -- im Speedrun (weniger Quests je Zone, Ruhestein spart dort am meisten)

function P:HearthStep(target, inst, n, w)
    if not LP.db.useHearth or not target or not target.inst then return nil end
    local b = LP.char.bind
    if type(b) ~= "table" or not b.map or not LP.API.HearthReady() then return nil end
    local bi, bn, bw = LP.Geo:ToWorld(b.map, b.x, b.y)
    if not bi or bi ~= target.inst then return nil end
    if inst == bi and LP.Geo:Dist(n, w, bn, bw) < 300 then return nil end
    local dTarget = (target.inst == inst) and LP.Geo:Dist(n, w, target.n, target.w) or OTHER_CONTINENT
    local dBind = LP.Geo:Dist(bn, bw, target.n, target.w)
    if dTarget < P.HEARTH.min or dBind > dTarget * P.HEARTH.gain then return nil end
    return { t = "HEARTH", text = b.name or "?", map = b.map, x = b.x, y = b.y, inst = bi, n = bn, w = bw,
             noNav = true, item = LP.API.HEARTHSTONE, key = "HEARTH:" .. (target.key or "?") }
end

function P:BindStep(selected, inst, n, w, focus)
    if not LP.db.useHearth or not focus then return nil end
    local b = LP.char.bind
    if type(b) == "table" and b.map == focus then return nil end
    local cnt = 0
    for _, t in ipairs(selected) do if t.map == focus then cnt = cnt + 1 end end
    if cnt < (self:IsSpeed() and BIND_TASKS_SPEED or BIND_TASKS) then return nil end
    local v, d = LP.QuestDB:NearestService("inn", function(x) return x.map == focus end)
    if not v or not d or d > P.HEARTH.bind then return nil end
    local vi, vn, vw = LP.Geo:ToWorld(v.map, v.x, v.y)
    return { t = "BIND", npc = v.name, text = LP.Geo:MapName(focus), map = v.map, x = v.x, y = v.y,
             inst = vi, n = vn, w = vw, key = "BIND:" .. focus }
end

local PATH_CHECK_MAX = 6000      -- Yards: noch weitere Wege uebernehmen Flug/Ruhestein (eigene Schritte)
function P:CheckFirstPath(ordered, inst, n, w, curZone, level)
    local Dg = LP.Danger
    if not Dg or not Dg.pathRule or not inst or not LP.Graph then return end
    local lim = Dg:Limit(level)
    for _ = 1, 3 do
        local t = ordered[1]
        if not t or t.t == "DUNGEON" or t.inst ~= inst or not t.n then return end
        local d = LP.Geo:Dist(n, w, t.n, t.w)
        if d <= ROUTE_SKIP or d > PATH_CHECK_MAX then return end
        local path = LP.Graph:Path(inst, n, w, curZone, t.inst, t.n, t.w, t.map)
        local worst = Dg:PathDanger(path, ROUTE_SKIP, lim)
        if worst < lim then return end
        table.remove(ordered, 1)
        t.pathBlocked = true
        MS.path = MS.path + 1
        if t.id then self.mobSkip[t.id] = self.mobSkip[t.id] or worst end
    end
end

-- wann fliegen: Mindeststrecke, Suchradius der Flugmeister, Gewicht des Fusswegs, fester Aufschlag (Yards)
P.FLY_RULE = { min = 2000, from = 2500, to = 3000, walk = 1.25, extra = 300 }
function P:TravelSteps(target, inst, n, w)
    if not target or not target.inst then return {} end
    local steps = {}
    if target.inst ~= inst then return steps end          -- Kontinentwechsel: Schiff/Zeppelin ueber das Wegenetz
    local direct = LP.Geo:Dist(n, w, target.n, target.w)
    local F = P.FLY_RULE
    if direct < F.min then return steps end
    local fromFP, d1 = NearestTaxi(inst, n, w, F.from)
    local toFP, d2 = NearestTaxi(target.inst, target.n, target.w, F.to)
    -- nur fliegen, wenn Fussweg zum und vom Flugmeister deutlich kuerzer ist als der ganze Weg
    if fromFP and toFP and fromFP ~= toFP and (d1 + d2) * F.walk + F.extra < direct then
        local fm, fx, fy, fi, fn, fw = LP.Geo:TaxiPoint(fromFP)
        if d1 > 30 then
            steps[#steps + 1] = {
                t = "GOTO", map = fm, x = fx, y = fy, inst = fi, n = fn, w = fw,
                text = L["Zum Flugmeister: "] .. (fromFP.name or "?"), key = "FPGO:" .. (fromFP.name or ""),
            }
        end
        steps[#steps + 1] = {
            t = "FLY", text = toFP.name or "?", from = fromFP.name, map = fm, x = fx, y = fy,
            inst = fi, n = fn, w = fw, key = "FLY:" .. (toFP.name or ""),
        }
    end
    return steps
end

------------------------------------------------------------------------
-- Planung
------------------------------------------------------------------------
-- Zustand fuer Anzeige und Diagnose: "ok", "nodata", "noquests", "noposition", "error"
P.state = "start"
P.diag = {}

function P:Replan(verbose)
    if not LP.db then return end
    -- waehrend der virtuellen Reise plant nur die Reise selbst (Ereignisse des Spiels warten)
    if LP.Virtual and LP.Virtual.active and coroutine.running() ~= LP.yieldCo then return end
    local ok, err = pcall(self.DoReplan, self, verbose)
    if not ok then
        self.state = "error"
        self.status = L["Fehler bei der Planung"]
        LP:Error(L["Routenplanung"], err)
        LP:Fire("PLAN_CHANGED")
    end
end

function P:DoReplan(verbose)
    local level = LP:PlayerLevel() or 1
    if level ~= candLevel then self:BuildCandidates() end
    ScanLog()
    self.diag.candidates = #candidates
    self.diag.level = level

    if LP.Engine and LP.Engine:InDungeon() then
        self:PlanInstance(level)
        return
    end

    local inst, n, w, curZone = LP.Geo:Player()
    self.diag.map = C_Map.GetBestMapForUnit("player")
    if not inst then
        self.state = "noposition"
        self.status = L["Position unbekannt"]
        self.diag.tasks = 0
        if #self.steps == 0 or self.steps[1].key == "NOPOS" then
            self.steps = { { t = "NOTE", key = "NOPOS",
                text = L["Deine Position ist gerade nicht bestimmbar (z. B. in einer Instanz oder beim Laden). Kurz bewegen – die Route wird dann automatisch geplant."] } }
        end
        LP:Fire("PLAN_CHANGED")
        return
    end

    local tasks = self:CollectTasks(inst, n, w, level)
    self.diag.tasks = #tasks
    self.lastTasks = tasks
    -- Fokus waehlen; bleibt nach der Wegpruefung in der Fokus-Zone nichts uebrig, die naechste Zone versuchen
    local excluded = {}
    local focus, ordered, selected
    for _ = 1, 3 do
        focus = self:ChooseFocus(tasks, inst, n, w, curZone, excluded)

        -- Aufgaben der Fokus-Zone + alles in der Naehe (300 Yards, Questannahmen 400) + fertige Quests ueberall
        -- + Dungeon-Quests, die fuer einen anstehenden Lauf eingesammelt werden
        selected = {}
        for _, t in ipairs(tasks) do
            local near = t.inst == inst and t.n and LP.Geo:Dist(n, w, t.n, t.w) < (t.t == "ACCEPT" and GATHER or 300)
            if not t.pathBlocked and (t.map == focus or near or t.prep or (t.t == "TURNIN" and t.map == curZone) or not t.map) then
                selected[#selected + 1] = t
            end
        end

        -- Abgaben sammeln: eine einzelne Abgabe weit weg (kein Questgeber, keine weitere Abgabe dort, keine
        -- Folgequest) wartet, bis man ohnehin vorbeikommt oder das Questlog voll wird
        local logFull = self:LogCount() >= LP.API.MaxQuests() - 3
        for _, t in ipairs(selected) do
            if P.OPT.collect and t.t == "TURNIN" and t.n and t.inst == inst and not logFull and not t.collectChecked then
                t.collectChecked = true
                local q = LP.QuestDB:Get(t.id)
                local chain = q and q.nextInChain and q.nextInChain ~= 0
                if not chain and LP.Geo:Dist(n, w, t.n, t.w) > TURNIN_FAR then
                    local others = 0
                    for _, u in ipairs(selected) do
                        if u ~= t and u.inst == t.inst and u.n and LP.Geo:Dist(t.n, t.w, u.n, u.w) <= HUB then others = others + 1 end
                    end
                    if others == 0 then t.value = t.value * TURNIN_ALONE t.collected = true end
                end
            end
        end
        ordered = self:Order(selected, inst, n, w)
        -- Pflichtregel fuer den Weg: den echten Weg zum ersten Ziel pruefen (Wegenetz, Zonenuebergaenge);
        -- fuehrt er durch ein Gebiet mit zu starken Mobs, wird das Ziel zurueckgestellt
        self:CheckFirstPath(ordered, inst, n, w, curZone, level)
        if #ordered > 0 or not focus then break end
        excluded[focus] = true
    end
    -- Kontinent der Fokus-Zone merken (Kontinentwechsel nur alle paar Level)
    local fi = focus and LP.Geo:ToWorld(focus, 50, 50)
    if fi and fi ~= self.contInst then
        if self.contInst then self.contLevel = level end
        self.contInst = fi
    end
    if focus ~= self.focus then
        if self.focus then self.leftZones[self.focus] = level end
        if focus then
            self.focusChanges = self.focusChanges + 1
            if self.focusLog then self.focusLog[#self.focusLog + 1] = { focus, level, self.focusWhy } end
            if self.leftZones[focus] then self.focusReturns = self.focusReturns + 1 end
        end
    end
    self.focus = focus
    -- Dungeon-Quests in der Naehe zuerst einsammeln, dann in den Dungeon
    for i = #ordered, 1, -1 do
        local dg = ordered[i]
        if dg.t == "DUNGEON" then
            local lastAccept
            for j = i + 1, #ordered do
                if ordered[j].t == "ACCEPT" and ordered[j].dungeon == dg.area then lastAccept = j end
            end
            if lastAccept then
                table.remove(ordered, i)
                table.insert(ordered, lastAccept, dg)
            end
        end
    end
    local steps = {}
    local fp = self:FlightPointTask(inst, n, w, curZone)
    if fp then steps[#steps + 1] = fp end
    local bind = self:BindStep(selected, inst, n, w, focus)
    if bind then steps[#steps + 1] = bind end
    local hearth = ordered[1] and self:HearthStep(ordered[1], inst, n, w)
    if hearth then
        steps[#steps + 1] = hearth
    elseif ordered[1] and ordered[1].inst then
        for _, s in ipairs(self:TravelSteps(ordered[1], inst, n, w)) do steps[#steps + 1] = s end
    end
    for _, t in ipairs(ordered) do steps[#steps + 1] = t end

    self.state = "ok"
    if #steps == 0 then
        if LP.QuestDB:Counts().total == 0 then
            self.state = "nodata"
            steps[1] = { t = "NOTE", key = "NODATA",
                text = L["Noch keine Questdaten vorhanden.\nInstalliere das Datenpaket \"LevelPilot Data\" (Ordner LevelPilot_Data in Interface\\AddOns) für alle Classic-Quests – oder nimm Quests an: LevelPilot lernt jede Quest."] }
        else
            self.state = "noquests"
            steps[1] = { t = "LEVEL", lvl = level + 1, key = "GRIND:" .. level,
                text = L["Keine passende Quest in der Nähe bekannt – Monster in deinem Level besiegen oder eine andere Zone wählen (Zentrale » Route)"] }
        end
    end

    -- Vorrang-Ziel des Assistenten (z.B. "Reparieren") an den Anfang
    if self.priority then
        if LP.char.doneKeys[self.priority.key] then
            LP.char.doneKeys[self.priority.key] = nil
            self.priority = nil
        else
            table.insert(steps, 1, self.priority)
        end
    end

    -- manuell erledigte Reise-/Hinweisschritte ausblenden
    local final = {}
    for _, s in ipairs(steps) do
        if not LP.char.doneKeys[s.key] and not (LP.Engine and LP.Engine.IsLater and LP.Engine:IsLater(s.key)) then final[#final + 1] = s end
    end
    -- nie ohne Schritt dastehen
    if #final == 0 then
        self.state = "noquests"
        final[1] = { t = "LEVEL", lvl = level + 1, key = "GRIND:" .. level,
            text = L["Keine passende Quest in der Nähe bekannt – Monster in deinem Level besiegen oder eine andere Zone wählen (Zentrale » Route)"] }
    end
    if final[1].t == "LEVEL" and self:IsSpeed() and next(self.speedSkip) then
        final[1].text = L["Speedrun: Monster in deinem Level besiegen ist gerade schneller als die übrigen Quests hier. Ab dem nächsten Level geht es mit Quests weiter."]
    end
    -- Grinden: kurz und an einer passenden Stelle (Monster im eigenen Level, machbar, nicht grau)
    if final[1].t == "LEVEL" and LP.Danger and not final[1].map then
        local gi, gn, gw, glv = LP.Danger:GrindSpot(inst, n, w, level, GRIND_RADIUS)
        local gx, gy
        if gi then gx, gy = LP.Geo:ToMap(curZone, gi, gn, gw) end
        if gx and gx >= 0 and gx <= 100 and gy >= 0 and gy <= 100 then
            local st = final[1]
            st.map, st.x, st.y, st.inst, st.n, st.w = curZone, gx, gy, gi, gn, gw
            st.grindLevel = glv
            st.text = st.text .. "\n" .. L("Gute Stelle: Monster Stufe %d bei %.0f, %.0f – etwa 20 Minuten, dann neu planen.", glv, gx, gy)
        end
    end
    -- Buendeln: bei einem Questziel anzeigen, welche anderen Ziele im Log gleich dort liegen
    local bidx
    for si, st in ipairs(final) do
        if si > 12 then break end
        if st.t == "COMPLETE" and st.inst and st.n then
            bidx = bidx or self:LogBundleIndex(level)
            local set = self:BundleNear(bidx, st.inst, st.n, st.w, st.id)
            local also = {}
            for id in pairs(set) do
                local e = self.inLog[id]
                if e and #also < 3 then also[#also + 1] = e.title or ("#" .. id) end
            end
            table.sort(also)
            st.also = #also > 0 and also or nil
        end
    end
    self.steps = final
    self.status = focus and LP.Geo:MapName(focus) or ""
    if verbose then
        LP:Print(L["Route neu geplant: "] .. #final .. L[" Schritte"] .. (focus and (" in " .. LP.Geo:MapName(focus)) or ""))
    end
    LP:Fire("PLAN_CHANGED")
end

-- Uebersicht fuer die Zentrale: je Dungeon Zugang, Stufen, Quests (offen / im Log / erledigt), Rechnung
function P:DungeonOverview()
    local level = LP:PlayerLevel() or 1
    ScanLog()
    local byArea = {}
    for _, id in ipairs(LP.QuestDB:AllIds()) do
        local info = LP.QuestDB:QuickInfo(id)
        local area = info and info.dungeon
        if area then
            local q = LP.QuestDB:Get(id)
            if q and LP.QuestDB:FitsPlayer(q) and not q.repeatable then
                local e = byArea[area] or { open = 0, log = 0, done = 0 }
                byArea[area] = e
                if Done(id) then e.done = e.done + 1
                elseif inLog[id] then e.log = e.log + 1
                else e.open = e.open + 1 end
            end
        end
    end
    local out = {}
    for area, d in pairs(LP.Dungeons) do
        local info = LP.QuestDB:Dungeon(area)
        local allowed, why = LP.QuestDB:DungeonAllowed(area)
        local e = byArea[area] or { open = 0, log = 0, done = 0 }
        out[#out + 1] = { area = area, name = info and info.name or d.name, min = d.min, max = d.max, allowed = allowed, why = why,
                          hostile = LP.QuestDB:DungeonHostile(area), open = e.open, log = e.log, done = e.done,
                          worth = self.dungeonWorth[area], entrance = info and info.e and info.e[1],
                          now = level >= d.min - 2 and level <= d.max, last = LP.char.dungeonRun[area] }
    end
    table.sort(out, function(a, b) if a.min ~= b.min then return a.min < b.min end return a.name < b.name end)
    return out
end

-- Im Dungeon: die Ziele der Quests dieser Instanz
function P:PlanInstance(level)
    local area = LP.Engine:InDungeon()
    local d = LP.QuestDB:Dungeon(area)
    local steps = {}
    local name = d and d.name or (GetInstanceInfo and GetInstanceInfo()) or L["Dungeon"]
    for id, st in pairs(inLog) do
        if not st.complete and not st.failed then
            local q = LP.QuestDB:Get(id)
            local mine = q and q.dungeon == area
            if not mine and (not q or not q.dungeon) then
                -- unbekannte Zuordnung: Quests ohne Ziel in der Welt gehoeren wahrscheinlich hierher
                local world = false
                for _, o in ipairs(q and q.objectives or {}) do
                    local list = area and area ~= 0 and OutsideSpots(area, o.spots or {}) or (o.spots or {})
                    for _, sp in ipairs(list) do if WorldOf(sp) then world = true break end end
                end
                mine = not world
            end
            if mine then
                steps[#steps + 1] = { t = "COMPLETE", id = id, q = st.title or (q and q.name), level = q and q.level,
                                      key = "COMPLETE:" .. id, value = 1 }
            end
        end
    end
    table.sort(steps, function(a, b) return (a.level or 0) < (b.level or 0) end)
    if #steps == 0 then
        steps[1] = { t = "NOTE", key = "DGDONE",
            text = L["Alle Quests für diesen Dungeon erledigt.\nNach dem Verlassen der Instanz geht es mit den Abgaben weiter."] }
    end
    table.insert(steps, 1, { t = "DUNGEON", inside = true, area = area, q = name, key = "DGIN",
                             min = d and d.min, max = d and d.max })
    self.state = "instance"
    self.focus = nil
    self.status = name
    self.diag.tasks = #steps - 1
    self.steps = steps
    LP:Fire("PLAN_CHANGED")
end

-- Diagnose im Chat
function P:DiagLines()
    local c = LP.QuestDB:Counts()
    local inst, n, w, map, x, y = LP.Geo:Player()
    local d = self.diag
    local lines = {
        L["Version "] .. LP.version .. L[" · Client: "] .. (LP.API.modern and L["modern"] or L["Classic"]) .. L[" · Server: "] .. (LP.API.Forever() and L["WoW Forever"] or L["Classic"]),
        LP.Game and LP.Game.Status() or L["GoldSentinelGame.lua fehlt"],
        L["Zustand: "] .. tostring(self.state) .. L[" · Fokus: "] .. (self.focus and LP.Geo:MapName(self.focus) or "–"),
        L["Position: "] .. (map and string.format("%s (%d) %.1f, %.1f", LP.Geo:MapName(map), map, x, y) or (L["unbekannt, Karte "] .. tostring(C_Map.GetBestMapForUnit("player")))),
        L["Datenpaket: "] .. (LP.QuestDB.pack and "|cff4ddb80" or "|cffff8c33") .. LP.QuestDB.packInfo .. "|r",
        L["QuestieDB: "] .. LP.QuestDB.questieInfo,
        string.format(L["Quests: Paket %d, Questie %d, Startdatenbank %d, eigene %d, andere %d"], c.pack, c.questie, c.seed, c.own, c.net),
        string.format(L["Level %s · passende Quests %s · Aufgaben %s · Schritte %d"], tostring(d.level), tostring(d.candidates), tostring(d.tasks), #self.steps),
        L["Questlog: "] .. LP.API.QuestCount() .. "/" .. LP.API.MaxQuests() .. ((tonumber(LP.db.questLogMax) or 0) > 0 and L[" (fest eingestellt)"] or L[" (automatisch)"]),
        L["Modus: "] .. (self:IsSpeed() and (L["Speedrun "] .. (SPEED_NAMES[LP.db.speedLevel or 3] or "") .. " (" .. (function() local c = 0 for _ in pairs(self.speedSkip) do c = c + 1 end return c end)() .. L[" Quests ausgelassen)"]) or L["Normal"]),
        L["Dungeons: "] .. (LP.db.dungeons == false and "aus" or (L["an, Lauf ab "] .. (LP.db.dungeonMin or 2) .. L[" Quests, Monster-EP "]
            .. math.floor(self:DungeonXPFactor() * 100 + 0.5) .. L[" %, Quest-EP "] .. math.floor(self:DungeonQuestFactor() * 100 + 0.5) .. " %"))
            .. (LP.char.inDungeon and (L[" · im Dungeon "] .. tostring(LP.char.inDungeon)) or ""),
        L("Höhlen und Tunnel bekannt: %d (selbst gelernt %d, von anderen %d)", LP.Caves:Count()),
        L["Geländeführung: "] .. (not LP.db.terrainPath and L["aus"] or (LP.Terrain:Available(map) and L["an (Geländekarte dieser Zone vorhanden)"] or L["keine Geländekarte für diese Zone"])),
        L["Sprachpakete: "] .. (LP.Names and LP.Names:StatusText() or "–"),
        LP.Calib and LP.Calib:StatusText() or "",
        L["Letzter Fehler: "] .. (LP.lastError or L["keiner"]),
    }
    for _, txt in pairs(self.dungeonWorth) do table.insert(lines, #lines, "   " .. txt) end
    return lines
end

function P:Diagnose()
    local lines = self:DiagLines()
    LP:Print(L["|cffffb238Diagnose|r"])
    for _, l in ipairs(lines) do DEFAULT_CHAT_FRAME:AddMessage("   " .. l) end
end

-- Zonen mit Aufgaben (fuer die Zentrale)
function P:ZoneSummary()
    -- Aufgaben der letzten Planung (neu rechnen nur, wenn es noch keine gibt: das ist so teuer wie eine Planung)
    local tasks = self.lastTasks
    if not tasks then
        local inst, n, w = LP.Geo:Player()
        if not inst then return {} end
        ScanLog()
        local level = LP:PlayerLevel() or 1
        if level ~= candLevel then self:BuildCandidates() end
        tasks = self:CollectTasks(inst, n, w, level)
    end
    local zones = {}
    for _, t in ipairs(tasks) do
        if t.map then
            local z = zones[t.map] or { map = t.map, accept = 0, active = 0 }
            zones[t.map] = z
            if t.t == "ACCEPT" then z.accept = z.accept + 1 else z.active = z.active + 1 end
        end
    end
    local list = {}
    for _, z in pairs(zones) do list[#list + 1] = z end
    table.sort(list, function(a, b) return (a.accept + a.active) > (b.accept + b.active) end)
    return list
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
function P:Init()
    local function soon() LP:Throttle("replan", 1.5, function() P:Replan() end) end
    LP:On("QUEST_LOG_UPDATE", soon)
    LP:On("QUEST_TURNED_IN", function(_, id)
        if id then LP.char.turnedIn[id] = true end
        soon()
    end)
    LP:On("PLAYER_LEVEL_UP", function() C_Timer.After(0.5, function() P:BuildCandidates() P:Replan() end) end)
    LP:On("ZONE_CHANGED_NEW_AREA", soon)
    LP:Listen("QDB_CHANGED", function() candLevel = -1 soon() end)
    LP:Listen("QUEST_RECORDED", function(_, isNew) if isNew then candLevel = -1 end soon() end)
    LP:On("PLAYER_ENTERING_WORLD", function() C_Timer.After(2, function() P:Replan() end) end)
    C_Timer.After(1, function() P:Replan() end)
    LP:Ticker("replan", 15, function() P:Replan() end)
end
