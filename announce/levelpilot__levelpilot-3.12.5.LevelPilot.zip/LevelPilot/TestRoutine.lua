-- LevelPilot - Testroutine (/lp testroutine), Bericht über GoldSentinelTest
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Nur im Testmodus (LP:DevOnly). Läuft in Häppchen (höchstens 8 ms je Bild), nur ausserhalb des Kampfes.
-- Echte Daten: Sicherung vorher, Wiederherstellung in place nachher, Vergleich je Hauptschlüssel ("Sandbox").
-- Aktionen mit Folgen (Kaufen, Reparieren, Anlegen, Quests, Flug, Senden …) laufen über LP.Act und werden
-- während des Laufs nur mitgeschrieben (LP.Act.dry). Es wird keine Blizzard-Funktion ersetzt: Simulationen
-- laufen über setfenv auf eigene Funktionen, über eigene Tabellen (LP.API, LP.Game) und Köderwerte.
-- Ergebnisse nur über T:Check / T:Skip / T:Client. Testfall-IDs wie in testroutine-levelpilot.txt.

local _, LP = ...
local L = LP.L
local TR = {}
LP.TestRoutine = TR

local NOT_YET = "noch nicht automatisiert (3.12.5) – folgt"
local ONLY_FOREVER = "LevelPilot nur für WoW Forever"

------------------------------------------------------------------------
-- Testfälle (ID, Bereich, Name) – über alle Versionen gleich
------------------------------------------------------------------------
TR.IDS = {
    { "T01", "A", "alle Module gestartet" },
    { "T02", "A", "Dateien ohne Modul geladen" },
    { "T03", "A", "Version .toc = Code" },
    { "T04", "A", "Version Datenpaket .toc = Code" },
    { "T05", "A", "Interface-Nummer passt zum Client" },
    { "T06", "A", "GoldSentinelGame Version 2" },
    { "T07", "A", "GoldSentinelTest geladen und angemeldet" },
    { "T08", "A", "echte Erkennung" },
    { "T09", "A", "Weichen mit SetTestFlavor(\"forever\")" },
    { "T10", "A", "Weichen mit SetTestFlavor(\"era\")" },
    { "T11", "A", "Weichen mit SetTestFlavor(\"tbc\")" },
    { "T12", "A", "Weichen mit SetTestFlavor(\"retail\")" },
    { "T13", "A", "SetTestFlavor(nil) stellt alles zurück" },
    { "T14", "A", "ohne GoldSentinelGame" },
    { "T15", "A", "Reihenfolge in der .toc" },
    { "T16", "B", "Fenster-Befehle" },
    { "T17", "B", "Modus-Befehle" },
    { "T18", "B", "Wegpunkt und Suche" },
    { "T19", "B", "Sprache per Befehl" },
    { "T20", "B", "Teilen, Gruppe, Bilanz" },
    { "T21", "B", "Protokoll, Diagnose, Messung, Selbsttest" },
    { "T22", "B", "Reise-Befehle" },
    { "T23", "B", "Debug, Zurück, Reset" },
    { "T24", "B", "unbekannter Befehl" },
    { "T25", "B", "Guide-Fenster LevelPilotFrame" },
    { "T26", "B", "Schritt-Menü LevelPilotStepMenu" },
    { "T27", "B", "Hinweise oben (Toasts) LevelPilotToasts" },
    { "T28", "B", "Minimap-Button LevelPilotMinimapButton" },
    { "T29", "B", "Pfeil LevelPilotArrow" },
    { "T30", "B", "Zentrale LevelPilotCenter, alle 8 Reiter" },
    { "T31", "B", "jede Option der Zentrale einmal an und aus" },
    { "T32", "B", "alle 12 Stepper" },
    { "T33", "B", "Sprachknöpfe" },
    { "T34", "B", "Zentrale » Daten: Knöpfe" },
    { "T35", "B", "Fenster der virtuellen Reise LevelPilotVirtualFrame" },
    { "T36", "B", "Gruppen-Panel LevelPilotGroupPanel" },
    { "T37", "B", "Aktionsleiste und Tastenbelegung" },
    { "T38", "B", "Spenden-Fenster" },
    { "T39", "B", "Planung" },
    { "T40", "B", "Planner:KillXPFormula – Werte" },
    { "T41", "B", "Planner:GreyLevel" },
    { "T42", "B", "Planner:GreenXPFactor / KillXP ohne Messung" },
    { "T43", "B", "Dungeon-Faktoren" },
    { "T44", "B", "Questlevel bei Quest-Kills" },
    { "T45", "B", "Speedrun-Filter" },
    { "T46", "B", "Dungeon-Übersicht" },
    { "T47", "B", "Diagnose" },
    { "T48", "B", "Engine-Funktionen" },
    { "T49", "B", "Automatik Annehmen/Abgeben/Gossip" },
    { "T50", "B", "Navigation" },
    { "T51", "B", "Wegenetz Graph" },
    { "T52", "B", "Gelände Terrain" },
    { "T53", "B", "Höhlen Caves" },
    { "T54", "B", "Gefahr Danger" },
    { "T55", "B", "Geo" },
    { "T56", "B", "QuestDB" },
    { "T57", "B", "Namen" },
    { "T58", "B", "Recorder (Aufzeichnung)" },
    { "T59", "B", "Comm: Kodieren und Empfangen" },
    { "T60", "B", "Comm: Begrenzung je Absender" },
    { "T61", "B", "Comm: Senden" },
    { "T62", "B", "Comm: Zonen-Abgleich" },
    { "T63", "B", "Gruppe (LvPilotG)" },
    { "T64", "B", "Social (Teilen, Gruppensuche, Partner)" },
    { "T65", "B", "Session" },
    { "T66", "B", "Comfort" },
    { "T67", "B", "Supply (Vorräte, Belohnung anlegen)" },
    { "T68", "B", "Advisor (Assistent)" },
    { "T69", "B", "Hints" },
    { "T70", "B", "Pins (Karte, Fundstellen)" },
    { "T71", "B", "Plates (Namensplaketten)" },
    { "T72", "B", "Tooltips" },
    { "T73", "B", "Calib (Lernwerte)" },
    { "T74", "B", "Calib: EP-Messung je Kill" },
    { "T75", "B", "Protocol (Fehler-Protokoll)" },
    { "T76", "B", "Backup (Sichern/Laden)" },
    { "T77", "B", "Measure (/lp messen)" },
    { "T78", "B", "Sprache: Hilfsfunktionen" },
    { "T79", "B", "Core-Hilfen" },
    { "T80", "B", "alle Ereignisse einmal" },
    { "T81", "B", "alle Ticker einmal" },
    { "T82", "B", "OnUpdate-Treiber" },
    { "T83", "B", "virtuelle Reise kurz" },
    { "T84", "B", "virtuelle Reise 1–60, beide Modi" },
    { "T85", "B", "Reise abbrechen" },
    { "T86", "B", "Datenpaket-Inhalt" },
    { "T87", "B", "Werkzeuge ausserhalb des Spiels (Tools/: Sicherung.ps1, Wiederherstellen.ps1, lp_sammeln.py …)" },
    { "T88", "C", "API.ItemCooldown mit geschützten start/duration (Ruhestein)" },
    { "T89", "C", "Recorder:RecordService mit geschütztem UnitName(\"npc\")" },
    { "T90", "C", "Tooltip-Hook OnShow mit geschütztem GameTooltipTextLeft1:GetText() und geschütztem tt:GetUnit()" },
    { "T91", "C", "Calib:OnLoot mit geschütztem Beute-Text" },
    { "T92", "C", "CHAT_MSG_ADDON mit geschütztem prefix/msg/sender (Comm und Group)" },
    { "T93", "C", "Plates:ForUnit mit geschütztem UnitName/UnitGUID" },
    { "T94", "C", "Calib:ReadTarget / OnXPUpdate mit geschütztem UnitLevel/UnitXP" },
    { "T95", "C", "Measure-Zeile mit geschütztem UnitClassification" },
    { "T96", "C", "Calib:ObserveUnit mit geschützter GUID und geschütztem Level" },
    { "T97", "C", "Namensvergleich mit geschütztem Namen" },
    { "T98", "C", "EP-Anzeige mit geschütztem UnitXP/UnitXPMax (UI-Ticker im Kampf)" },
    { "T99", "C", "geschützte Werte im echten Kampf" },
    { "T100", "C", "Questlog-Funktionen" },
    { "T101", "C", "API.GreenRange ohne C_QuestLog.GetTrivialRange und GetQuestGreenRange" },
    { "T102", "C", "Händler" },
    { "T103", "C", "Gegenstände" },
    { "T104", "C", "Taschen" },
    { "T105", "C", "Talentpunkte" },
    { "T106", "C", "Hints Known ohne IsSpellKnown/IsPlayerSpell" },
    { "T107", "C", "Gruppensuche ohne ChatFrame_OpenChat" },
    { "T108", "C", "Addon-Kanal ohne ChatFrame_RemoveChannel" },
    { "T109", "C", "Jäger ohne GetPetHappiness/GetPetFoodTypes" },
    { "T110", "C", "Metadaten und AddOns" },
    { "T111", "C", "Senden ohne C_ChatInfo" },
    { "T112", "C", "weitere alte Globals ohne Prüfung" },
    { "T113", "C", "Names: collectgarbage wirft" },
    { "T114", "C", "Aktionsleiste im Kampf" },
    { "T115", "C", "Belohnung anlegen und Hinweis-Knöpfe im Kampf" },
    { "T116", "C", "Testroutine und Kampf" },
    { "T117", "C", "ADDON_ACTION_BLOCKED für LevelPilot" },
    { "T118", "C", "Kampflog nicht angemeldet" },
    { "T119", "D", "Laden in Classic Era" },
    { "T120", "D", "Hinweis \"für WoW Forever gebaut\"" },
    { "T121", "D", "Weichen auf dem alten Weg" },
    { "T122", "D", "TBC und Retail" },
    { "T123", "E", "Neuinstallation (leere SavedVariables)" },
    { "T124", "E", "Migration Speedrun-Strenge (3.10)" },
    { "T125", "E", "Migration Sprache" },
    { "T126", "E", "Migration Protokoll" },
    { "T127", "E", "Überlagerung der Flugpunkte nach einem Abbruch" },
    { "T128", "E", "alte Fassung (Beispieldaten im Test)" },
    { "T129", "E", "beschädigte Einträge (nil, falscher Typ)" },
    { "T130", "E", "Datenpaket fehlt, falsches Format, zu alt" },
    { "T131", "E", "QuestieDB vorhanden, aber zu alt oder unvollständig" },
    { "T132", "E", "Einstellungen pro Charakter" },
    { "T133", "F", "Schlüssel in jeder Sprache vorhanden" },
    { "T134", "F", "Formatplatzhalter" },
    { "T135", "F", "Format mit Werten" },
    { "T136", "F", "jede Sprache aktivieren, Hauptfenster öffnen" },
    { "T137", "F", "Sprachen ohne Schrift" },
    { "T138", "F", "Namen je Sprache" },
    { "T139", "F", "Texte von GoldSentinelGame" },
    { "T140", "G", "gemeinsame Dateien mit anderen GoldSentinel-Addons" },
    { "T141", "G", "keine globalen Namen überschrieben" },
    { "T142", "G", "Fehler-Handler-Kette" },
    { "T143", "G", "Schnittstellen zu anderen GoldSentinel-Addons" },
    { "T144", "G", "Questie mit und ohne" },
    { "T145", "G", "Addon-Präfixe angemeldet" },
    { "T146", "H", "UI:Refresh (Ticker 1 s)" },
    { "T147", "H", "Engine:CheckSteps (Ticker 0,5 s)" },
    { "T148", "H", "Navigations-Treiber (OnUpdate alle 0,05 s: Nav:Recalc(false), Pfeil, Minikarte)" },
    { "T149", "H", "Pins-Treiber und Weltkarte" },
    { "T150", "H", "Planner:Replan(true) (Ticker 15 s und bei Ereignissen)" },
    { "T151", "H", "Graph:Path für eine lange Route (Orgrimmar -> Wegkreuz)" },
    { "T152", "H", "Drosselung bei \"vom Weg ab\"" },
    { "T153", "H", "Plaketten, Tooltip und Beobachtung je Einheit" },
    { "T154", "H", "Comm" },
    { "T155", "H", "Planung je Reiseschritt" },
    { "T156", "H", "alle 1-s-Ticker zusammen (ui, caves, recorder, session)" },
    { "T157", "H", "Speicher" },
    { "T158", "I", "absichtlicher Fehler über LP:Safe" },
    { "T159", "I", "Lua-Fehler ausserhalb eines pcall" },
    { "T160", "I", "Fehler in einem Ereignis-Handler" },
    { "T161", "I", "Fehler in einem LP:Fire-Listener" },
    { "T162", "I", "Modul-Startfehler in der Diagnose" },
    { "T163", "I", "Ticker-Fehler" },
    { "T164", "I", "Fehler der virtuellen Reise" },
    { "T165", "I", "Bericht gespeichert und datenschutzkonform" },
    { "T166", "I", "Testfall-IDs eindeutig und vollständig" },
    { "T167", "J", "[V Schritt 1] GoldSentinelGame unverändert und vor allen eigenen Dateien" },
    { "T168", "J", "[V Schritt 1] G.Status() in der Diagnose" },
    { "T169", "J", "[V Schritt 1] Namensvergleiche über G.SameName" },
    { "T170", "J", "[V Schritt 2.1] Datenpaket-Version passt" },
    { "T171", "J", "[V Launch] Interface-Nummer in beiden .toc" },
    { "T172", "J", "[Z1a] EP je Kill nach Levelunterschied" },
    { "T173", "J", "[Z1b] Abschlag für grüne Monster nur in Forever" },
    { "T174", "J", "[Z1c] Weg-Kills mit mittlerem Monsterlevel" },
    { "T175", "J", "[Z1d] Quest-Kills mit Questlevel" },
    { "T176", "J", "[Z2] Dungeon-Werte Forever 0,36 / 1,5, Classic 1,0" },
    { "T177", "J", "[Z3] Messung EP je Kill: geschützt, erholt, Gruppe" },
    { "T178", "J", "[Z4] Gruppen-EP-Hinweis in Forever" },
    { "T179", "J", "[Z5a] \"Zeit bis 60\" klar beschriftet" },
    { "T180", "J", "[Z5b] beide Modi vergleichen, echter Modus bleibt" },
    { "T181", "J", "[Z5c] Reisebericht nennt die Herkunft der Werte" },
    { "T182", "J", "[Z NICHT ÄNDERN] EP-Tabelle und Regeln unverändert" },
    { "T183", "J", "[Z Test 1] Zeiten 1–60 Normal und Speedrun" },
    { "T184", "J", "[K1] /lp reise bericht ohne Lua-Fehler (global L)" },
    { "T185", "J", "[K2] Ruhestein-Abklingzeit mit geschützten Werten" },
    { "T186", "J", "[K3] Recorder: geschützter NPC-Name" },
    { "T187", "J", "[K4] Tooltip-Titel und GetUnit geschützt" },
    { "T188", "J", "[K5] Calib:OnLoot geschützt" },
    { "T189", "J", "[K6] CHAT_MSG_ADDON geschützt (Comm und Group)" },
    { "T190", "J", "[K7] collectgarbage in Names mit pcall" },
    { "T191", "J", "[K8] Hints Known ohne Rückgabe true" },
    { "T192", "J", "[K9] Gruppen-Text ohne ChatFrame_OpenChat" },
    { "T193", "J", "[K10] Kanal ausblenden ohne ChatFrame_RemoveChannel" },
    { "T194", "J", "[K11] GreenRange mit UnitQuestTrivialLevelRange" },
    { "T195", "J", "[K12] Talent- und Jägerfunktionen" },
    { "T196", "J", "[K13] Dropraten ohne Kampflog" },
    { "T197", "J", "[K14] Navigation: 0,5 s Mindestpause auch bei \"off\", nicht neu rechnen auf Flügen" },
    { "T198", "J", "[K15] alle Ticker in LP:Safe" },
    { "T199", "J", "[K16] Protokoll mit beschädigtem Eintrag startet" },
    { "T200", "J", "[K17] Measure: UnitClassification geschützt" },
    { "T201", "J", "[K18] Tooltips nutzen LP.API.IsQuestDone" },
    { "T202", "J", "[K19] eigene Erkennung auf LP.Game umgeleitet" },
    { "T203", "J", "[K20] Mindestversion des Datenpakets" },
    { "T204", "J", "[K Frage] Standardwerte mit echten Folgen" },
    { "T205", "J", "[R] Datenpaket nur in der gemeinsamen ZIP" },
    -- 3.12.5: Grundeinstellung der Automatiken und einmalige Hinweise (anweisung-levelpilot-automatiken.txt)
    { "T206", "J", "[A1] Neuinstallation: Reparieren/Flug an, Nachkaufen/Belohnung aus" },
    { "T207", "J", "[A1] Bestehende Einstellungen bleiben" },
    { "T208", "J", "[A2a] Hinweis Nachkaufen einmal, nichts gekauft" },
    { "T209", "J", "[A2b] Hinweis Belohnung einmal, nichts gewählt oder angelegt" },
    { "T210", "J", "[A2c] Option an -> kein Hinweis" },
    { "T211", "J", "[A2d] Im Kampf -> kein Hinweis" },
    { "T212", "J", "[3.12.5-1] Drop-Messung: erneut geöffnete Leiche zählt nicht doppelt" },
}
TR.SHORT = { T01 = true, T02 = true, T03 = true, T04 = true, T06 = true, T07 = true, T08 = true, T39 = true,
             T50 = true, T56 = true, T133 = true }

------------------------------------------------------------------------
-- Hilfen
------------------------------------------------------------------------
local IMPL, SKIP, CLIENT = {}, {}, {}
TR.IMPL, TR.SKIP, TR.CLIENT = IMPL, SKIP, CLIENT

local function G() return LP.Game end
local function Count(t) local n = 0 for _ in pairs(type(t) == "table" and t or {}) do n = n + 1 end return n end
local function Near(a, b, eps) return type(a) == "number" and math.abs(a - b) <= (eps or 0.01) end
local function Ms() return debugprofilestop and debugprofilestop() or (GetTime() * 1000) end
local function S(v) return tostring(v) end

-- body ausführen, danach restore() – auch im Fehlerfall – und den Fehler weitergeben
local function Guard(body, restore)
    local ok, a, b, c = pcall(body)
    restore()
    if not ok then error(a, 0) end
    return a, b, c
end

-- Simulierte Spielversion (GoldSentinelGame.SetTestFlavor), immer zurück
local function WithFlavor(fl, body)
    local g = G()
    if not g or not g.SetTestFlavor then error("GoldSentinelGame fehlt", 0) end
    g.SetTestFlavor(fl)
    return Guard(body, function() g.SetTestFlavor(nil) end)
end

-- Einstellung vorübergehend setzen (über LP.db), immer zurück
local function WithSetting(map, body)
    local old = {}
    for k, v in pairs(map) do old[k] = { LP.db[k] } LP.db[k] = v end
    return Guard(body, function() for k, o in pairs(old) do LP.db[k] = o[1] end end)
end

-- calib.killxp / dungeonxp leer (gemessene Werte ausblenden), immer zurück
local function WithEmptyCalib(body)
    local c = LevelPilotDB and type(LevelPilotDB.calib) == "table" and LevelPilotDB.calib
    if not c then return body() end
    local kx, dx = c.killxp, c.dungeonxp
    c.killxp, c.dungeonxp = {}, nil
    return Guard(body, function() c.killxp, c.dungeonxp = kx, dx end)
end

-- Umgebung eigener Funktionen umleiten (setfenv). fake[k] == false bedeutet nil. _G wird nie beschrieben.
local function WithEnv(funcs, fake, body)
    local proxy = setmetatable({}, {
        __index = function(_, k)
            local v = fake[k]
            if v ~= nil then if v == false then return nil end return v end
            return _G[k]
        end,
        __newindex = function(_, k, v) _G[k] = v end,
    })
    local saved = {}
    for i, f in ipairs(funcs) do
        if type(f) == "function" then saved[i] = getfenv(f) setfenv(f, proxy) end
    end
    return Guard(body, function()
        for i, f in ipairs(funcs) do if saved[i] then setfenv(f, saved[i]) end end
    end)
end
TR.WithEnv = WithEnv

-- flache Kopie einer C_-Tabelle ohne bestimmte Felder (für WithEnv)
local function Without(tbl, ...)
    if type(tbl) ~= "table" then return false end
    local t = {}
    for k, v in pairs(tbl) do t[k] = v end
    for i = 1, select("#", ...) do t[(select(i, ...))] = nil end
    return t
end

-- Köderwerte: gelten innerhalb von body als geschützt (nur LP.Game, synchron, immer zurück)
local function WithSecret(baits, body)
    local g = G()
    if not g then error("GoldSentinelGame fehlt", 0) end
    local set = {}
    for _, v in ipairs(baits) do set[v] = true end
    local orig = g.IsSecret
    g.IsSecret = function(v) return (v ~= nil and set[v] == true) or orig(v) end
    return Guard(body, function() g.IsSecret = orig end)
end

-- simulierter Kampf über LP:InCombat
local function WithCombat(state, body)
    local old = LP.testCombat
    LP.testCombat = state
    return Guard(body, function() LP.testCombat = old end)
end

local function Act() return LP.Act end
local function ActMark() return #LP.Act.log end
local function ActSince(mark, name)
    local n = 0
    for i = mark + 1, #LP.Act.log do if not name or LP.Act.log[i].name == name then n = n + 1 end end
    return n
end

local function Meta(addon, field)
    local f = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
    if not f then return nil end
    local ok, v = pcall(f, addon, field)
    return ok and v or nil
end

------------------------------------------------------------------------
-- A. Laden und Erkennung
------------------------------------------------------------------------
local MODULES = { "Actions", "Advisor", "Backup", "Calib", "Caves", "Center", "Comfort", "Comm", "Danger", "Engine", "Geo",
    "Graph", "Group", "Hints", "Measure", "Names", "Nav", "Pins", "Planner", "Plates", "Protocol", "QuestDB", "Recorder",
    "SelfTest", "Session", "Social", "Supply", "Terrain", "Tooltips", "UI", "Virtual" }

IMPL.T01 = function()
    local have, missing = {}, {}
    for _, m in ipairs(LP.modules) do have[m.name] = true end
    for _, n in ipairs(MODULES) do if not have[n] then missing[#missing + 1] = n end end
    local init = {}
    for n in pairs(LP.initErrors or {}) do init[#init + 1] = n end
    if #missing > 0 or #init > 0 or #LP.modules ~= #MODULES then
        return false, string.format("%d Module, fehlend: %s, Startfehler: %s", #LP.modules, table.concat(missing, ","),
            table.concat(init, ",")), #MODULES .. " Module, keine Startfehler"
    end
    return true, #LP.modules .. " Module"
end

IMPL.T02 = function()
    local miss = {}
    for _, k in ipairs({ "API", "Act", "Donate", "Seed", "Dungeons", "Gateways", "CaveSeed", "CaveForeverMaps", "LocaleEN" }) do
        if type(LP[k]) ~= "table" then miss[#miss + 1] = k end
    end
    local n = 0
    for _, c in ipairs({ "en", "fr", "es", "mx", "pt", "it", "ru", "ko", "cn", "tw" }) do if type(LP.Locales[c]) == "table" then n = n + 1 end end
    if #miss > 0 or n ~= 10 or _G.LevelPilot ~= LP then
        return false, "fehlend: " .. table.concat(miss, ",") .. " · Übersetzungen " .. n, "alle Tabellen, 10 Übersetzungen"
    end
    return true, "10 Übersetzungen"
end

IMPL.T03 = function()
    local toc = Meta("LevelPilot", "Version")
    return toc == LP.version, S(toc), LP.version
end

IMPL.T04 = function()
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return true, "LevelPilot_Data nicht geladen" end
    local toc = Meta("LevelPilot_Data", "Version")
    return toc == d.version and d.format == 1, S(toc) .. " / " .. S(d.version) .. " / Format " .. S(d.format), "gleich, Format 1"
end
CLIENT.T05 = "/dump select(4, GetBuildInfo()) – steht die Zahl in beiden .toc? Addon-Liste: LevelPilot nicht 'veraltet'"

IMPL.T06 = function()
    local g = _G.GoldSentinelGame
    if type(g) ~= "table" then return false, "fehlt", "Version 2" end
    local miss = {}
    for _, k in ipairs({ "IsSecret", "AnySecret", "Safe", "InCombat", "Short", "CleanName", "SameName", "Status", "SetTestFlavor", "Recalc" }) do
        if type(g[k]) ~= "function" then miss[#miss + 1] = k end
    end
    local ok = g.version == 2 and LP.Game == g and #miss == 0 and g.flavor ~= nil and type(SlashCmdList.GOLDSENTINELGAME) == "function"
    return ok, "Version " .. S(g.version) .. (#miss > 0 and (" fehlt: " .. table.concat(miss, ",")) or ""), "Version 2, alles vorhanden"
end

IMPL.T07 = function()
    local GT = _G.GoldSentinelTest
    if type(GT) ~= "table" then return false, "fehlt", "geladen" end
    local reg = GT.registry and GT.registry.LevelPilot
    local ok = (GT.version or 0) >= 1 and reg and reg.db == LevelPilotDB and type(LevelPilotDB.gsTest) == "table"
    return ok and true or false, "Version " .. S(GT.version) .. (reg and " angemeldet" or " nicht angemeldet"), "angemeldet mit LevelPilotDB"
end

IMPL.T08 = function()
    local g = G()
    if not g then return false, "GoldSentinelGame fehlt", "vorhanden" end
    if g.flavor == "forever" then
        local ok = g.IsModern and g.HasSecrets and not g.IsOldAPI and LP.API.modern == true and LP.API.Forever() == true
        return ok and true or false, g.Status(), "Forever, modern"
    end
    if g.flavor == "era" then
        local ok = g.IsOldAPI and LP.API.modern == false
        return ok and true or false, g.Status(), "Era, alte API"
    end
    return true, g.Status()
end

local function FlavorBlock(fl)
    return function()
        return WithEmptyCalib(function()
            return WithSetting({ questLogMax = 0, dungeonMobXP = 0, dungeonQuestXP = 0, forever = true }, function()
                return WithFlavor(fl, function()
                    local g, P = G(), LP.Planner
                    local f, mq = LP.API.Forever(), LP.API.MaxQuests()
                    local dg, dq, gr = P:DungeonXPFactor(), P:DungeonQuestFactor(), P:GreenXPFactor(-3)
                    local note = LP.Social.ForeverGroupNote("x")
                    local got = string.format("Forever %s, Questlog %d, Dungeon %.2f/%.2f, grün %.2f", S(f), mq, dg, dq, gr)
                    if fl == "forever" then
                        return f == true and mq == 40 and Near(dg, 0.36) and Near(dq, 1.5) and Near(gr, 0.85) and note ~= "x", got,
                            "Forever true, 40, 0.36/1.50, 0.85, Gruppenhinweis"
                    elseif fl == "retail" then
                        return g.IsModern and not g.IsForever and f == false and mq == 20, got, "modern, nicht Forever, 20"
                    else
                        local okT = (fl ~= "tbc") or g.IsTBC
                        return okT and g.IsOldAPI and f == false and mq == 20 and Near(dg, 1) and Near(dq, 1) and Near(gr, 1) and note == "x",
                            got, "alt, Forever false, 20, 1/1, 1"
                    end
                end)
            end)
        end)
    end
end
local flavorBefore
IMPL.T09 = function() flavorBefore = G() and G().flavor return FlavorBlock("forever")() end
IMPL.T10 = FlavorBlock("era")
IMPL.T11 = FlavorBlock("tbc")
IMPL.T12 = FlavorBlock("retail")
IMPL.T13 = function()
    local g = G()
    if not g then return false, "GoldSentinelGame fehlt", "vorhanden" end
    local st = g.Status()
    return (flavorBefore == nil or g.flavor == flavorBefore) and not st:find("%[Test%]"), g.flavor .. " · " .. st, S(flavorBefore)
end

IMPL.T14 = function()
    local saved = LP.Game
    LP.Game = nil
    return Guard(function()
        local a = LP.SafeValue(5) == 5
        local b = LP.SameName("Rokan-Realm", "Rokan") == true and LP.SameName("Rokan-Realm", "rokan") == false
        return a and b, "SafeValue " .. S(a) .. ", SameName " .. S(b), "beide true"
    end, function() LP.Game = saved end)
end
SKIP.T15 = "wird von addon-check geprüft"

------------------------------------------------------------------------
-- B. Funktionen
------------------------------------------------------------------------
local function Slash(msg) SlashCmdList.LEVELPILOT(msg) end

IMPL.T17 = function()
    local real = LP.char.mode
    return Guard(function()
        Slash("speed")
        local a = LP.char.mode == "speed" and LP.Planner:IsSpeed()
        Slash("normal")
        local b = LP.char.mode == "normal" and not LP.Planner:IsSpeed()
        return a and b, "speed " .. S(a) .. ", normal " .. S(b), "beide true"
    end, function() LP.Planner:SetMode(real) end)
end

IMPL.T19 = function()
    local before = LP.db.language
    return Guard(function()
        local r1 = LP:SetLanguage(nil)
        local r2 = LP:SetLanguage("xx")
        return r1 == false and r2 == false, "ohne Kürzel " .. S(r1) .. ", xx " .. S(r2), "false, false"
    end, function() LP.db.language = before LP:ResetLanguageCache() end)
end

IMPL.T23 = function()
    local mark = ActMark()
    local pos = { LP.db.framePos, LP.db.arrowPos, LP.db.centerPos }
    return Guard(function()
        Slash("reset")
        local n = ActSince(mark, "ReloadUI")
        return n == 1, "ReloadUI mitgeschrieben: " .. n, "1 (nicht ausgeführt)"
    end, function() LP.db.framePos, LP.db.arrowPos, LP.db.centerPos = pos[1], pos[2], pos[3] end)
end

IMPL.T24 = function()
    local was = LP.UI:IsShown()
    Slash("xyz") Slash("xyz")
    return LP.UI:IsShown() == was, S(LP.UI:IsShown()), S(was)
end

IMPL.T27 = function()
    LP.UI:Toast({ key = "test", sev = 1, text = "Test" })
    LP.UI:ClearToasts()
    return true
end

IMPL.T30 = function()
    local f = _G.LevelPilotCenter
    local wasShown = f and f:IsShown()
    return Guard(function()
        if not wasShown then LP.Center:Toggle() end
        for _, k in ipairs({ "route", "dungeons", "data", "share", "assist", "comfort", "extras", "settings" }) do LP.Center:Select(k) end
        local esc = false
        for _, n in ipairs(UISpecialFrames or {}) do if n == "LevelPilotCenter" then esc = true end end
        return esc, "8 Reiter, Escape " .. S(esc), "Escape schliesst"
    end, function() if f and not wasShown then f:Hide() end end)
end

IMPL.T38 = function()
    local t = LP.Donate.AddonTitle()
    return t == "LevelPilot", S(t), "LevelPilot"
end

IMPL.T39 = function()
    if (UnitLevel("player") or 1) >= 60 then return true, "Level 60" end
    LP.Planner:BuildCandidates()
    LP.Planner:Replan(true)
    local st, cur = LP.Engine:Steps(), LP.Engine:Current()
    return #st > 0 and cur and cur.key ~= nil and cur.t ~= nil, #st .. " Schritte, Zustand " .. S(LP.Planner.state), "> 0 Schritte"
end

local KXP = { { 20, 20, 145 }, { 20, 22, 159.5 }, { 20, 24, 174 }, { 20, 25, 174 }, { 20, 17, 105.45 }, { 20, 14, 65.91 },
              { 20, 13, 0 }, { 5, 1, 14 }, { 60, 60, 345 }, { 60, 64, 414 }, { 60, 48, 86.25 }, { 60, 47, 0 } }
IMPL.T40 = function()
    local bad = {}
    for _, e in ipairs(KXP) do
        local v = LP.Planner:KillXPFormula(e[1], e[2])
        if not Near(v, e[3], 0.01) then bad[#bad + 1] = string.format("(%d,%d)=%.2f statt %.2f", e[1], e[2], v, e[3]) end
    end
    return #bad == 0, #bad == 0 and "12 Werte" or table.concat(bad, "; "), "alle 12 Werte"
end

IMPL.T41 = function()
    local P, bad = LP.Planner, {}
    for _, e in ipairs({ { 5, 0 }, { 6, 1 }, { 10, 4 }, { 39, 31 }, { 40, 31 }, { 60, 47 } }) do
        if P:GreyLevel(e[1]) ~= e[2] then bad[#bad + 1] = e[1] .. "->" .. S(P:GreyLevel(e[1])) end
    end
    return #bad == 0, table.concat(bad, ", "), "5->0, 6->1, 10->4, 39->31, 40->31, 60->47"
end

IMPL.T42 = function()
    return WithEmptyCalib(function()
        return WithSetting({ forever = true }, function()
            return WithFlavor("forever", function()
                local P = LP.Planner
                local g3, g2 = P:GreenXPFactor(-3), P:GreenXPFactor(-2)
                local k17, k18 = P:KillXP(20, 17), P:KillXP(20, 18)
                return Near(g3, 0.85) and Near(g2, 1) and Near(k17, 89.64) and Near(k18, 118.64),
                    string.format("%.2f %.2f %.2f %.2f", g3, g2, k17, k18), "0.85 1.00 89.64 118.64"
            end)
        end)
    end)
end

IMPL.T43 = function()
    return WithEmptyCalib(function()
        return WithFlavor("forever", function()
            local P = LP.Planner
            local r = {}
            WithSetting({ dungeonMobXP = 0, forever = true }, function() r[1], r[2] = P:DungeonXPFactor() end)
            WithSetting({ dungeonMobXP = 50, forever = true }, function() r[3], r[4] = P:DungeonXPFactor() end)
            WithSetting({ dungeonQuestXP = 200, forever = true }, function() r[5], r[6] = P:DungeonQuestFactor() end)
            local ok = Near(r[1], 0.36) and r[2] == "auto" and Near(r[3], 0.5) and r[4] == "set" and Near(r[5], 2) and r[6] == "set"
            return ok, string.format("%.2f %s · %.2f %s · %.2f %s", r[1], S(r[2]), r[3], S(r[4]), r[5], S(r[6])), "0.36 auto · 0.50 set · 2.00 set"
        end)
    end)
end

IMPL.T44 = function()
    local P = LP.Planner
    local a, b = P:QuestKillLevel({ level = 18 }, 20), P:QuestKillLevel({}, 20)
    return a == 18 and b == 20, S(a) .. ", " .. S(b), "18, 20"
end

IMPL.T47 = function()
    local txt = table.concat(LP.Planner:DiagLines(), "\n")
    local ok = txt:find("Version " .. LP.version, 1, true) or txt:find(LP.version, 1, true)
    return ok and (not G() or txt:find(G().Status(), 1, true)) and true or false, "Diagnose " .. #txt .. " Zeichen", "Version und G.Status()"
end

IMPL.T50 = function()
    LP.Nav:Recalc(true)
    if not LP.Nav.target then return true, "kein Ziel (Schritt ohne Ort)" end
    local d = LP.Nav.RemainingDistance and LP.Nav:RemainingDistance()
    if not LP.Nav.hasPath then return false, S(LP.Nav.pathError), "Weg gefunden" end
    return type(d) == "number" and d >= 0, "Weg " .. (d and LP:FormatDist(d) or "?"), "Zahl >= 0"
end

IMPL.T55 = function()
    local Geo = LP.Geo
    local i, n, w = Geo:ToWorld(1411, 0.5, 0.5)
    local cont = Geo.ContinentOf and Geo:ContinentOf(1411)
    local name = Geo:MapName(1411)
    return i ~= nil and type(name) == "string" and name ~= "" and (cont == nil or cont == 1414),
        "Kontinent " .. S(cont) .. ", Name " .. S(name), "1414, Name"
end

IMPL.T56 = function()
    local c = LP.QuestDB:Counts()
    local q = LP.QuestDB:Get(844) or LP.QuestDB:Get(7)
    local ok = type(c) == "table" and type(c.pack) == "number" and type(c.seed) == "number" and type(c.own) == "number"
    return ok and (q == nil or q.name ~= nil), string.format("Paket %s, Start %s, eigene %s", S(c.pack), S(c.seed), S(c.own)), "Zahlen"
end

IMPL.T57 = function()
    local st = LP.Names:StatusText()
    return type(st) == "string" and st ~= "", st, "nicht leer"
end

IMPL.T60 = function()
    local rate = LP.Comm.RateOk
    if not rate then return false, "Comm.RateOk fehlt", "zugänglich" end
    local who = "LPTest-" .. tostring(math.random(100000, 999999))
    local r80, r81
    for i = 1, 81 do local r = rate(who) if i == 80 then r80 = r elseif i == 81 then r81 = r end end
    return r80 == true and r81 == false, "80: " .. S(r80) .. ", 81: " .. S(r81), "80: true, 81: false"
end

IMPL.T63 = function()
    local Gp = LP.Group
    local who = "LPTester-Test"
    local saved = Gp.members[who:match("^([^%-]+)")]
    return Guard(function()
        Gp:OnMessage("S\t5\t10\tGOTO\t0\ttext", who)
        local m = Gp.members["LPTester"]
        local ok = m and m.level == 5 and m.pct == 10 and m.text == "text"
        return ok and true or false, ok and "Mitglied erkannt" or "nicht erkannt", "level 5, pct 10, text"
    end, function() Gp.members["LPTester"] = saved end)
end

IMPL.T65 = function()
    local M = LP.Session.Money
    local a, b, c = M(12345), M(250), M(5)
    local sum = LP.Session:SummaryText()
    return a == "1g 23s" and b == "2s 50c" and c == "5c" and type(sum) == "string", a .. " · " .. b .. " · " .. c, "1g 23s · 2s 50c · 5c"
end

IMPL.T66 = function()
    local D = LP.Comfort.Dur
    local a, b = D(59), D(nil)
    local mark = ActMark()
    -- Reparieren mit simuliertem Händler: nur mitschreiben
    WithSetting({ autoRepair = true }, function()
        WithEnv({ LP.Comfort.Repair }, { CanMerchantRepair = function() return true end,
            GetRepairAllCost = function() return 100, true end, GetMoney = function() return 100000 end }, function()
            LP.Comfort:Repair()
        end)
    end)
    local n = ActSince(mark, "RepairAllItems")
    return b == "?" and type(a) == "string" and n == 1, "Dur(59) " .. a .. ", Reparieren mitgeschrieben " .. n, "?, 1"
end

IMPL.T67 = function()
    local needs = LP.Supply:Needs()
    local mark = ActMark()
    local pend = LP.Supply.EquipRewards
    -- Nachkaufen mit simuliertem Händler: nur API.MerchantBuy im Protokoll (über LP.Act)
    WithSetting({ restock = true }, function()
        local plan = { { index = 1, id = 4540, purchases = 1, perBuy = 5, price = 25, name = "Test" } }
        local origPlan = LP.Supply.Plan
        LP.Supply.Plan = function() return plan, 25 end
        Guard(function()
            WithEnv({ LP.Supply.Restock }, { MerchantFrame = { IsShown = function() return true end } }, function()
                LP.Supply:Restock()
            end)
        end, function() LP.Supply.Plan = origPlan end)
    end)
    local n = ActSince(mark, "MerchantBuy")
    return type(needs) == "table" and n >= 1 and pend ~= nil, #needs .. " Bedarf, Kauf mitgeschrieben " .. n, ">= 1 mitgeschrieben"
end

IMPL.T68 = function()
    LP.Advisor:Run()
    return type(LP.Advisor.hints) == "table", #LP.Advisor.hints .. " Hinweis(e)", "Liste"
end

IMPL.T73 = function()
    local t = LP.Calib:KillXPText()
    return type(t) == "string" and t ~= "", t, "Text"
end

IMPL.T75 = function()
    local Pr = LP.Protocol
    local n0 = Pr:Count()
    Pr:Add("error", "LP-Testroutine Protokoll")
    Pr:Add("error", "LP-Testroutine Protokoll")
    local n1 = Pr:Count()
    -- Eintrag wieder entfernen (Sandbox stellt am Ende ohnehin alles zurück)
    local entries = Pr:Entries()
    for i = #entries, 1, -1 do
        local e = entries[i]
        if type(e) == "table" and type(e.msg) == "string" and e.msg:find("LP-Testroutine", 1, true) then table.remove(entries, i) end
    end
    return n1 - n0 <= 1, "neu: " .. (n1 - n0), "höchstens 1 (gleiche Meldung zusammengefasst)"
end

IMPL.T77 = function()
    local t = LP.Measure:Text()
    return type(t) == "string" and (not G() or t:find(G().Status(), 1, true) ~= nil), #t .. " Zeichen (Text nicht im Bericht)", "enthält G.Status()"
end

IMPL.T79 = function()
    local a = LP.HasBit(2 ^ 32 + 1, 2 ^ 32) == true and LP.HasBit(5, 2) == false and LP.HasBit(0, 1) == false
    local b = LP:SameZoneName("Das Brachland", "Brachland") == true and LP:SameZoneName("Durotar", "Mulgore") == false
    local c = LP:FormatDist(2000) == "1.8 km" and LP.TagHash("Ab c#1") == LP.TagHash("abc#1")
    -- LP:Fire: ein fehlerhafter Zuhörer bricht nicht ab
    local ran = false
    local key = "LP_TEST_FIRE"
    LP.callbacks[key] = { function() error("LP-Testfehler Fire") end, function() ran = true end }
    local before = LP.errorCount
    LP:Fire(key)
    LP.callbacks[key] = nil
    LP.errorCount = before
    return a and b and c and ran, string.format("Bits %s, Zonen %s, Format %s, Fire %s", S(a), S(b), S(c), S(ran)), "alle true"
end

IMPL.T81 = function()
    local names, bad = {}, {}
    for _, t in ipairs(LP.tickers or {}) do
        names[#names + 1] = t.name
        if t.name ~= "journey" then
            local ok, err = pcall(t.fn)
            if not ok then bad[#bad + 1] = t.name .. ": " .. tostring(err) end
        end
    end
    return #bad == 0 and #names > 0, #names .. " Ticker" .. (#bad > 0 and (" – " .. table.concat(bad, "; ")) or ""), "kein Fehler"
end

IMPL.T86 = function()
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return true, "kein Datenpaket" end
    local ok = type(d.Q) == "table" and type(d.N) == "table" and next(d.Q) ~= nil
    return ok, "Quests " .. Count(d.Q), "Tabellen gefüllt"
end
SKIP.T87 = "ausserhalb des Spiels"

------------------------------------------------------------------------
-- C. Forever-Sonderfälle (Köder, fehlende Funktionen, Kampfsperre)
------------------------------------------------------------------------
local BAIT_N1, BAIT_N2 = 987654.25, 987655.25

IMPL.T88 = function()
    local fakeC = Without(C_Container, "GetItemCooldown") or {}
    fakeC.GetItemCooldown = function() return BAIT_N1, BAIT_N2 end
    return WithSecret({ BAIT_N1, BAIT_N2 }, function()
        return WithEnv({ LP.API.ItemCooldown }, { C_Container = fakeC, GetItemCooldown = false }, function()
            local v = LP.API.ItemCooldown(LP.API.HEARTHSTONE or 6948)
            return type(v) == "number" and v >= 0, "Rückgabe " .. S(v), "Zahl >= 0 (letzter lesbarer Wert oder 0)"
        end)
    end)
end

IMPL.T91 = function()
    local item = 999001
    local s = LevelPilotDB.calib or {}
    LevelPilotDB.calib = s
    s.drops = type(s.drops) == "table" and s.drops or {}
    local savedDrop = s.drops[item]
    s.drops[item] = { k = 1, g = 0 }
    local msg = "Ihr bekommt Beute: |cffffffff|Hitem:" .. item .. "::::::::|h[x]|h|r"
    local savedW = LP.Calib.testWanted
    LP.Calib.testWanted = { [item] = { npc = { [1] = true } } }
    return Guard(function()
        WithSecret({ msg }, function() LP.Calib:OnLoot(msg) end)
        return s.drops[item].g == 0, "Stück " .. S(s.drops[item].g), "0 (Köder nicht verarbeitet)"
    end, function() s.drops[item] = savedDrop LP.Calib.testWanted = savedW end)
end
IMPL.T188 = IMPL.T91

IMPL.T97 = function()
    local bait = "LPTestKoeder Name"
    return WithSecret({ bait }, function()
        local a = LP.SameName(bait, "x")
        local b = G().Short(bait)
        return a == false and b == nil, "SameName " .. S(a) .. ", Short " .. S(b), "false, nil"
    end)
end

IMPL.T101 = function()
    local fakeQ = Without(C_QuestLog, "GetTrivialRange") or false
    return WithEnv({ LP.API.GreenRange }, { C_QuestLog = fakeQ, GetQuestGreenRange = false, UnitQuestTrivialLevelRange = false }, function()
        local R = LP.API.GreenRange
        local a, b, c, d = R(5), R(20), R(45), R(60)
        return a == 5 and b == 7 and c == 10 and d == 13, a .. "," .. b .. "," .. c .. "," .. d, "5,7,10,13"
    end)
end
IMPL.T194 = IMPL.T101

IMPL.T102 = function()
    local API = LP.API
    return WithEnv({ API.MerchantCount, API.MerchantAvailable, API.MerchantLink, API.MerchantBuy, API.MerchantItem },
        { GetMerchantNumItems = false, C_MerchantFrame = false, GetMerchantItemLink = false, BuyMerchantItem = false,
          GetMerchantItemInfo = false }, function()
        local ok = API.MerchantCount() == 0 and API.MerchantAvailable() == false and API.MerchantLink(1) == nil
            and API.MerchantBuy(1, 1) == false and API.MerchantItem(1) == nil
        return ok, ok and "alle Rückfälle" or "falscher Rückfall", "0/false/nil/false/nil"
    end)
end

IMPL.T103 = function()
    local API = LP.API
    return WithEnv({ API.ItemInfo, API.IsEquippable, API.SellPrice, API.ItemSpell },
        { C_Item = false, GetItemInfo = false, IsEquippableItem = false, GetItemSpell = false }, function()
        local ok = API.ItemInfo(6948) == nil and API.IsEquippable(6948) == false and API.SellPrice(6948) == 0 and API.ItemSpell(6948) == nil
        return ok, ok and "alle Rückfälle" or "falscher Rückfall", "nil/false/0/nil"
    end)
end

IMPL.T104 = function()
    local API = LP.API
    return WithEnv({ API.BagSlots, API.BagFree, API.BagLink, API.BagItem, API.UseBagItem },
        { C_Container = false, GetContainerNumSlots = false, GetContainerNumFreeSlots = false, GetContainerItemLink = false,
          GetContainerItemInfo = false, UseContainerItem = false }, function()
        local f1, f2 = API.BagFree(0)
        local ok = API.BagSlots(0) == 0 and f1 == 0 and f2 == 0 and API.BagLink(0, 1) == nil and API.BagItem(0, 1) == nil
            and API.UseBagItem(0, 1) == nil
        return ok, ok and "alle Rückfälle" or "falscher Rückfall", "0/0,0/nil/nil/nil"
    end)
end

IMPL.T106 = function()
    local known = LP.Hints.Known
    if not known then return false, "Hints.Known fehlt", "zugänglich" end
    return WithEnv({ known }, { C_SpellBook = false, IsSpellKnown = false, IsPlayerSpell = false }, function()
        local r = known(3273)
        return r == nil, "Rückgabe " .. S(r), "nil (unbekannt – kein Hinweis)"
    end)
end
IMPL.T191 = IMPL.T106

IMPL.T107 = function()
    local mark = ActMark()
    local So = LP.Social
    local origText = So.GroupText
    So.GroupText = function() return "LFG Test" end
    return Guard(function()
        local line = WithEnv({ So.OpenGroupChat }, { ChatFrame_OpenChat = false }, function() return So:OpenGroupChat({}) end)
        local n = ActSince(mark, "OpenChat")
        local hasUtil = ChatFrameUtil and ChatFrameUtil.OpenChat
        return line ~= nil and (n == 1 or not hasUtil), "Zeile " .. S(line ~= nil) .. ", mitgeschrieben " .. n, "Zeile, OpenChat mitgeschrieben"
    end, function() So.GroupText = origText end)
end
IMPL.T192 = IMPL.T107

IMPL.T115 = function()
    local mark = ActMark()
    WithSetting({ autoEquipRewards = true }, function()
        WithEnv({ LP.Supply.EquipRewards }, { InCombatLockdown = function() return true end }, function() LP.Supply:EquipRewards() end)
    end)
    local n = ActSince(mark, "Equip")
    return n == 0, "mitgeschrieben " .. n, "0"
end

IMPL.T116 = function()
    local r = WithCombat(true, function() return TR:CanStart(true) end)
    return r == false, "Start erlaubt: " .. S(r), "false"
end

IMPL.T117 = function()
    local Pr = LP.Protocol
    local list = LP.handlers.ADDON_ACTION_BLOCKED
    if not list then return false, "kein Handler", "Handler angemeldet" end
    local n0 = Pr:Count()
    for _, fn in ipairs(list) do pcall(fn, "ADDON_ACTION_BLOCKED", "LevelPilot", "LPTestAktion") end
    local n1 = Pr:Count()
    local entries = Pr:Entries()
    for i = #entries, 1, -1 do
        local e = entries[i]
        local txt = type(e) == "table" and (tostring(e.msg or "") .. tostring(e.a1 or "") .. tostring(e.args and e.args[1] or ""))
        if txt and txt:find("LPTestAktion", 1, true) then table.remove(entries, i) end
    end
    return n1 > n0, "neu: " .. (n1 - n0), "Eintrag 'blocked'"
end

IMPL.T118 = function()
    local g = G()
    local reg = LP.eventFrame:IsEventRegistered("COMBAT_LOG_EVENT_UNFILTERED") and true or false
    if g and g.IsModern then
        return LP.handlers.COMBAT_LOG_EVENT_UNFILTERED == nil and not reg, "angemeldet " .. S(reg), "nicht angemeldet (Forever)"
    end
    return reg, "angemeldet " .. S(reg), "angemeldet (alter Client)"
end
CLIENT.T99 = "/lp testroutine kampf, dann allein einen Gegner töten – Fehlerzähler vorher/nachher gleich"

------------------------------------------------------------------------
-- D. Alte Clients
------------------------------------------------------------------------
CLIENT.T119 = "Classic Era mit 'Veraltete AddOns laden' starten, dann /lp testroutine – keine Lua-Fehler beim Laden, T01 OK"
IMPL.T120 = function()
    local g = G()
    if not g then return false, "GoldSentinelGame fehlt", "vorhanden" end
    return true, g.Status() .. (g.IsForever and "" or " – LevelPilot ist für WoW Forever gebaut, alter Client nur Ladeprüfung")
end
IMPL.T121 = function()
    local g = G()
    local want = g and (g.IsModern and true or false) or (C_QuestLog and C_QuestLog.GetInfo ~= nil)
    return LP.API.modern == want, "API.modern " .. S(LP.API.modern), S(want) .. " (laut GoldSentinelGame)"
end
SKIP.T122 = ONLY_FOREVER

------------------------------------------------------------------------
-- E. Daten (Testtabellen über LP:LoadSaved, danach wieder die echten Tabellen)
------------------------------------------------------------------------
local function WithLoad(acc, char, body)
    return Guard(function() LP:LoadSaved(acc, char) return body(acc, char) end,
        function() LP:LoadSaved(LevelPilotDB, LevelPilotCharDB) end)
end

IMPL.T123 = function()
    return WithLoad({}, {}, function(acc, char)
        local miss = {}
        for k in pairs(LP.DEFAULTS) do if acc[k] == nil and LP.DEFAULTS[k] ~= nil then miss[#miss + 1] = k end end
        for k in pairs(LP.CHAR_DEFAULTS) do if char[k] == nil then miss[#miss + 1] = "char." .. k end end
        local ok = #miss == 0 and acc.speedLevelV2 == true and acc.language == "auto"
        return ok, #miss == 0 and "alle Standardwerte" or ("fehlend: " .. table.concat(miss, ",")), "alle Standardwerte"
    end)
end
IMPL.T206 = function()
    return WithLoad({}, {}, function(acc)
        local ok = acc.autoRepair == true and acc.autoFly == true and acc.restock == false and acc.autoEquipRewards == false
        return ok, string.format("autoRepair %s, autoFly %s, restock %s, autoEquipRewards %s", S(acc.autoRepair), S(acc.autoFly),
            S(acc.restock), S(acc.autoEquipRewards)), "true, true, false, false"
    end)
end
IMPL.T207 = function()
    return WithLoad({ autoRepair = false, autoFly = false, restock = true }, {}, function(acc)
        local ok = acc.autoRepair == false and acc.autoFly == false and acc.restock == true
        return ok, string.format("autoRepair %s, autoFly %s, restock %s", S(acc.autoRepair), S(acc.autoFly), S(acc.restock)), "false, false, true"
    end)
end
IMPL.T204 = function()
    local D = LP.DEFAULTS
    local ok = D.autoRepair == true and D.autoFly == true and D.restock == false and D.autoEquipRewards == false
    return ok, string.format("restock %s, autoEquipRewards %s, autoRepair %s, autoFly %s", S(D.restock), S(D.autoEquipRewards),
        S(D.autoRepair), S(D.autoFly)), "false, false, true, true (Entscheid des Nutzers 3.12.5)"
end

IMPL.T124 = function()
    local a, b
    WithLoad({ speedLevel = 3 }, {}, function(acc) a = acc.speedLevel end)
    WithLoad({ speedLevel = 3, speedLevelV2 = true }, {}, function(acc) b = acc.speedLevel end)
    return a == 2 and b == 3, S(a) .. ", " .. S(b), "2, 3"
end
IMPL.T125 = function()
    local a
    WithLoad({ language = "xx" }, {}, function(acc) a = acc.language end)
    return a == "auto", S(a), "auto"
end
IMPL.T126 = function()
    local M = LP.Protocol.Migrate
    if not M then return false, "Protocol.Migrate fehlt", "vorhanden" end
    local r = M({ k = "zone", msg = "… Das Brachland (1413), Brachland" })
    return r == "drop", S(r), "drop"
end
IMPL.T132 = function()
    local acc = { autoAccept = true }
    return WithLoad(acc, {}, function()
        LP.db.ownSettings = true
        LP.db.autoAccept = false
        local a = acc.autoAccept == true and LP.db.autoAccept == false
        LP.db.ownSettings = false
        local b = LP.db.autoAccept == true
        return a and b, "Charakter " .. S(a) .. ", Konto wieder " .. S(b), "true, true"
    end)
end
IMPL.T199 = function()
    local Pr = LP.Protocol
    local s = LevelPilotDB.protocolLog
    if type(s) ~= "table" then return true, "kein Protokoll" end
    local entries = s.entries
    entries[#entries + 1] = { k = nil, msg = 5 }
    return Guard(function() Pr:LoadEntries() return true, "Laden ohne Fehler" end,
        function() for i = #entries, 1, -1 do if entries[i] and entries[i].msg == 5 then table.remove(entries, i) end end end)
end
IMPL.T203 = function()
    local Q = LP.QuestDB
    return Q.OlderThan("1.5.0", Q.MIN_PACK) == true and Q.OlderThan("1.6.0", Q.MIN_PACK) == false,
        "Mindestversion " .. S(Q.MIN_PACK), "1.5.0 zu alt, 1.6.0 ok"
end
IMPL.T170 = function()
    local d = _G.LevelPilotData
    if type(d) ~= "table" then return true, "kein Datenpaket" end
    return LP.QuestDB.OlderThan(d.version, "1.6.0") == false, S(d.version), ">= 1.6.0"
end

------------------------------------------------------------------------
-- F. Sprachen
------------------------------------------------------------------------
local CODES = { "en", "fr", "es", "mx", "pt", "it", "ru", "ko", "cn", "tw" }
local function Placeholders(s)
    local out = {}
    for p in tostring(s):gsub("%%%%", ""):gmatch("%%[%-%+ #0]*%d*%.?%d*[sdif]") do out[#out + 1] = p:sub(-1) end
    return table.concat(out)
end

IMPL.T133 = function()
    local res, bad = {}, 0
    for _, code in ipairs(CODES) do
        local t = LP.Locales[code]
        local fb = LP.LanguageInfo[code] and LP.LanguageInfo[code].fallback
        local miss, ex = 0, nil
        for k in pairs(LP.usedKeys or {}) do
            if k ~= "" and not k:find("^%s*$") and not ((t and t[k]) or (fb and LP.Locales[fb] and LP.Locales[fb][k])) then
                miss = miss + 1 ex = ex or k
            end
        end
        if miss > 0 then bad = bad + 1 res[#res + 1] = code .. " " .. miss .. " (" .. tostring(ex):sub(1, 30) .. ")" end
    end
    return bad == 0, bad == 0 and (Count(LP.usedKeys) .. " benutzte Schlüssel in allen Sprachen") or table.concat(res, "; "), "0 fehlend"
end

IMPL.T134 = function()
    local res = {}
    for _, code in ipairs(CODES) do
        for k, v in pairs(LP.Locales[code] or {}) do
            if type(k) == "string" and type(v) == "string" and Placeholders(k) ~= Placeholders(v) then
                res[#res + 1] = code .. ": " .. k:sub(1, 30)
            end
        end
    end
    return #res == 0, #res == 0 and "keine Abweichung" or (#res .. ": " .. table.concat(res, "; "):sub(1, 200)), "0 Abweichungen"
end

IMPL.T135 = function()
    local bad = {}
    local VAL = { s = "x", d = 3, i = 3, f = 1.5 }
    for _, code in ipairs(CODES) do
        for k in pairs(LP.Locales[code] or {}) do
            if type(k) == "string" and k:find("%", 1, true) then
                local args = {}
                for c in Placeholders(k):gmatch(".") do args[#args + 1] = VAL[c] end
                -- nur echte Formattexte (der deutsche Schlüssel selbst lässt sich formatieren)
                if pcall(string.format, k, unpack(args)) then
                    local ok = pcall(string.format, LP.LocaleLookup(code, k), unpack(args))
                    if not ok then bad[#bad + 1] = code .. ": " .. k:sub(1, 30) end
                end
            end
        end
    end
    return #bad == 0, #bad == 0 and "alle formatierbar" or table.concat(bad, "; "):sub(1, 200), "kein Formatfehler"
end

IMPL.T137 = function()
    local bad = {}
    for _, l in ipairs(LP.LANGUAGES) do
        if not LP:CanDisplay(l.code) then
            local before = LP.db.language
            local r = LP:SetLanguage(l.code)
            LP.db.language = before
            LP:ResetLanguageCache()
            if r ~= false then bad[#bad + 1] = l.code end
        end
    end
    return #bad == 0, #bad == 0 and "ok" or table.concat(bad, ","), "SetLanguage gibt false zurück"
end

IMPL.T139 = function()
    local g = G()
    if not g or not g.Text then return true, "keine Texte" end
    local t = g.Text("game")
    return type(t) == "string" and t ~= "", S(t), "Text"
end

------------------------------------------------------------------------
-- G. Zusammenspiel
------------------------------------------------------------------------
IMPL.T140 = function()
    local loaded = {}
    local f = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
    for _, a in ipairs({ "GuildSentinel", "RaidMaster", "ThreatSentinel", "BuffSentinel", "ProfessionSentinel", "AHSentinel" }) do
        if f and f(a) then loaded[#loaded + 1] = a end
    end
    local GT, g = _G.GoldSentinelTest, _G.GoldSentinelGame
    local ok = g and g.version >= 2 and GT and GT.version >= 1 and LP.Game == g and GT.registry.LevelPilot ~= nil
    return ok and true or false, "geladen: " .. (#loaded > 0 and table.concat(loaded, ", ") or "keine"), "gemeinsame Dateien ok"
end
IMPL.T141 = function()
    local ok = _G.LevelPilot == LP and SLASH_LEVELPILOT1 == "/lp" and type(SlashCmdList.LEVELPILOT) == "function"
    return ok, ok and "ok" or "überschrieben", "eigene Namen"
end
SKIP.T143 = "keine Schnittstelle – LevelPilot nutzt keine anderen GoldSentinel-Addons"
IMPL.T145 = function()
    local f = C_ChatInfo and C_ChatInfo.IsAddonMessagePrefixRegistered
    if not f then return true, "keine Abfrage möglich" end
    local a, b = f("LvPilot2"), f("LvPilotG")
    return a and b and true or false, S(a) .. ", " .. S(b), "true, true"
end

------------------------------------------------------------------------
-- H. Leistung (je 20 Aufrufe, Median und Höchstwert)
------------------------------------------------------------------------
local function Bench(fn, n)
    local t = {}
    for i = 1, n or 20 do local a = Ms() fn() t[i] = Ms() - a end
    table.sort(t)
    return t[math.floor(#t / 2) + 1], t[#t]
end
local function BenchCheck(fn, limit, n)
    return function()
        local med, max = Bench(fn, n)
        return med < limit, string.format("Median %.2f ms, Höchstwert %.2f ms", med, max), string.format("Median < %g ms", limit)
    end
end
IMPL.T146 = BenchCheck(function() LP.UI:Refresh() end, 2)
IMPL.T147 = BenchCheck(function() LP.Engine:CheckSteps() end, 2)
IMPL.T150 = BenchCheck(function() LP.Planner:Replan(true) end, 16, 5)
IMPL.T157 = function()
    collectgarbage("collect")
    local kb = collectgarbage("count")
    local grow = TR.memStart and (kb - TR.memStart) or 0
    return grow < 1024, string.format("Zuwachs %.0f KB", grow), "< 1024 KB"
end

------------------------------------------------------------------------
-- I. Fehlerzählung
------------------------------------------------------------------------
IMPL.T158 = function()
    local n0 = LP.errorCount
    local msg = "LP-Testfehler Safe " .. tostring(math.random(1000, 9999))
    local r = LP:Safe("Testroutine", function() error(msg, 0) end)
    local inErr = LP.errors[msg] == true
    local gt = false
    local s = LevelPilotDB.gsTest
    if s and type(s.errors) == "table" then
        for k, e in pairs(s.errors) do if type(e) == "table" and e.wo == "Testroutine" then gt = true s.errors[k] = nil end end
    end
    local ok = r == false and LP.errorCount == n0 + 1 and inErr and (gt or not LP.trackingErrors)
    LP.errors[msg] = nil
    return ok, string.format("Rückgabe %s, Zähler +%d, GoldSentinelTest %s", S(r), LP.errorCount - n0, S(gt)), "false, +1, true"
end
IMPL.T160 = function()
    local list = LP.handlers.PLAYER_XP_UPDATE
    if not list then return true, "kein Handler" end
    local n0, ran = LP.errorCount, false
    table.insert(list, 1, function() error("LP-Testfehler Ereignis", 0) end)
    table.insert(list, function() ran = true end)
    return Guard(function()
        LP.eventFrame:GetScript("OnEvent")(LP.eventFrame, "PLAYER_XP_UPDATE", "player")
        return LP.errorCount == n0 + 1 and ran, "Zähler +" .. (LP.errorCount - n0) .. ", übrige liefen " .. S(ran), "+1, true"
    end, function()
        table.remove(list, 1) table.remove(list)
        LP.errors["LP-Testfehler Ereignis"] = nil
    end)
end
IMPL.T161 = function()
    local n0, ran = LP.errorCount, false
    local key = "LP_TEST_FIRE2"
    LP.callbacks[key] = { function() error("LP-Testfehler Fire", 0) end, function() ran = true end }
    LP:Fire(key)
    LP.callbacks[key] = nil
    return LP.errorCount == n0 + 1 and ran, "Zähler +" .. (LP.errorCount - n0) .. ", nächster lief " .. S(ran), "+1, true"
end
IMPL.T163 = function()
    local n0 = LP.errorCount
    local msg = "LP-Testfehler Ticker"
    LP:Safe("ticker-test", function() error(msg, 0) end)
    LP:Safe("ticker-test", function() error(msg, 0) end)
    local ok = LP.errorCount == n0 + 2
    LP.errors[msg] = nil
    return ok, "Zähler +" .. (LP.errorCount - n0), "+2 (Chatmeldung nur einmal)"
end
IMPL.T198 = function()
    local n = 0
    for _, t in ipairs(LP.tickers or {}) do if t.name ~= "journey" then n = n + 1 end end
    return n == 13, n .. " Ticker über LP:Ticker", "13 (ohne Reise)"
end
SKIP.T205 = "vor dem Push mit addon-check"
SKIP.T196 = "Kills beim Plündern über LOOT_OPENED umgesetzt (3.12.4/3.12.5) – Verzerrung im Client prüfen (T212, offen-Punkt 2)"

------------------------------------------------------------------------
-- J. Regressionstests (wiederverwendete Prüfungen unter eigener ID)
------------------------------------------------------------------------
IMPL.T167 = IMPL.T06
IMPL.T168 = IMPL.T47
IMPL.T172 = IMPL.T40
IMPL.T173 = function()
    local P = LP.Planner
    return P.FOREVER_GREEN == 0.85 and P.GREEN_DIFF == 3, S(P.FOREVER_GREEN) .. " / " .. S(P.GREEN_DIFF), "0.85 / 3"
end
IMPL.T175 = IMPL.T44
IMPL.T176 = function()
    local P = LP.Planner
    return P.FOREVER_DG_MOB == 0.36 and P.FOREVER_DG_QUEST == 1.5, S(P.FOREVER_DG_MOB) .. " / " .. S(P.FOREVER_DG_QUEST), "0.36 / 1.5"
end
IMPL.T178 = function()
    return WithSetting({ forever = true }, function()
        return WithFlavor("forever", function()
            local t = LP.Social.ForeverGroupNote("x")
            local want = L["Ein viel höheres Gruppenmitglied kann dafür sorgen, dass alle 0 EP bekommen."]
            return t:sub(-#want) == want, "Hinweis " .. S(t ~= "x"), "endet mit dem Gruppen-EP-Hinweis"
        end)
    end)
end
IMPL.T182 = function()
    local f = LP.Comfort.XPNeed
    if not f then return false, "Comfort.XPNeed fehlt", "zugänglich" end
    local sum, n = 0, 0
    for l = 1, 59 do local v = f(l) if v then sum, n = sum + v, n + 1 end end
    return sum == 4084700 and n == 59, sum .. " in " .. n .. " Einträgen", "4084700 in 59"
end
IMPL.T185 = IMPL.T88
IMPL.T202 = function()
    local g = G()
    if not g then return true, "ohne GoldSentinelGame: Einstellung" end
    return WithSetting({ forever = true }, function()
        local a = WithFlavor("forever", function() return LP.API.Forever() end)
        local b = WithFlavor("era", function() return LP.API.Forever() end)
        return a == true and b == false, "forever " .. S(a) .. ", era " .. S(b), "true, false"
    end)
end

------------------------------------------------------------------------
-- J. 3.12.5: einmalige Hinweise auf Nachkaufen und Belohnung anlegen
------------------------------------------------------------------------
local PLAN = { { index = 1, id = 4540, purchases = 1, perBuy = 5, price = 25, name = "Test" } }

-- Hinweis-Zustand des Charakters vorübergehend leeren
local function WithOptState(body)
    local Su = LP.Supply
    local savedHints, savedPending = LP.char.optHints, Su.optPending
    LP.char.optHints, Su.optPending = {}, {}
    return Guard(body, function() LP.char.optHints, Su.optPending = savedHints, savedPending end)
end
-- Hinweise des Anbieters abfragen (ohne den Assistenten laufen zu lassen)
local function OptHintsShown()
    local list = {}
    LP.Supply.OptHintsProvider(function(key, sev, text, action, label, action2)
        list[#list + 1] = { key = key, action = action, action2 = action2 }
    end)
    return list
end

IMPL.T208 = function()
    return WithOptState(function()
        return WithSetting({ restock = false }, function()
            local mark = ActMark()
            local first = LP.Supply:CheckRestockHint(PLAN)
            local shown1 = #OptHintsShown()
            LP.Supply.optPending = {}                 -- Händler geschlossen, Sitzung geht weiter
            local second = LP.Supply:CheckRestockHint(PLAN)
            local bought = ActSince(mark, "MerchantBuy")
            return first == true and shown1 == 1 and second == false and bought == 0,
                string.format("erster Besuch %s (%d Hinweis), zweiter %s, gekauft %d", S(first), shown1, S(second), bought),
                "true (1), false, 0"
        end)
    end)
end

IMPL.T209 = function()
    local link = "|cff1eff00|Hitem:999002::::::::|h[Test]|h|r"
    local A = LP.Advisor
    local orig = A.UpgradeValue
    A.UpgradeValue = function(_, l) if l == link then return 10 end return orig(A, l) end
    return Guard(function()
        return WithOptState(function()
            return WithSetting({ autoEquipRewards = false }, function()
                local mark = ActMark()
                local first = LP.Supply:CheckRewardHint({ link })
                local shown = #OptHintsShown()
                LP.Supply.optPending = {}
                local second = LP.Supply:CheckRewardHint({ link })
                local acted = ActSince(mark, "Equip") + ActSince(mark, "GetQuestReward")
                return first == true and shown == 1 and second == false and acted == 0,
                    string.format("erste %s (%d Hinweis), zweite %s, gewählt/angelegt %d", S(first), shown, S(second), acted),
                    "true (1), false, 0"
            end)
        end)
    end, function() A.UpgradeValue = orig end)
end

IMPL.T210 = function()
    return WithOptState(function()
        return WithSetting({ restock = true, autoEquipRewards = true }, function()
            local a = LP.Supply:CheckRestockHint(PLAN)
            LP.Supply.optPending.restock = { text = "x" }          -- schon vorgemerkt, dann eingeschaltet
            local shown = #OptHintsShown()
            return a == false and shown == 0, "Hinweis " .. S(a) .. ", gezeigt " .. shown, "false, 0"
        end)
    end)
end

IMPL.T211 = function()
    return WithOptState(function()
        return WithSetting({ restock = false }, function()
            LP.Supply:CheckRestockHint(PLAN)
            local inCombat = WithCombat(true, function() return #OptHintsShown() end)
            local later = WithCombat(false, function() return #OptHintsShown() end)
            return inCombat == 0 and later == 1, "im Kampf " .. inCombat .. ", danach " .. later, "0, 1"
        end)
    end)
end

-- 3.12.5 offen-Punkt 1: dieselbe Leiche zweimal öffnen zählt Kill und Stück nur einmal
IMPL.T212 = function()
    local Ca = LP.Calib
    if not Ca.ResetLooted then return false, "Calib.ResetLooted fehlt", "zugänglich" end
    local item, npc = 999003, 99901
    local guid = "Creature-0-1-1-1-" .. npc .. "-0000ABCDEF"
    local s = LevelPilotDB.calib or {}
    LevelPilotDB.calib = s
    s.drops = type(s.drops) == "table" and s.drops or {}
    local saved, savedW = s.drops[item], Ca.testWanted
    s.drops[item] = nil
    Ca.testWanted = { [item] = { npc = { [npc] = true } } }
    local fake = {
        GetNumLootItems = function() return 1 end,
        GetLootSlotLink = function() return "|cffffffff|Hitem:" .. item .. "::::::::|h[x]|h|r" end,
        GetLootSourceInfo = function() return guid, 2 end,
        UnitExists = function() return false end,
    }
    return Guard(function()
        WithEnv({ Ca.OnLootOpened, Ca.IsPickpocket }, fake, function()
            Ca:OnLootOpened()
            Ca:OnLootOpened()          -- erneut geöffnet (Tasche voll)
        end)
        local d = s.drops[item] or { k = 0, g = 0 }
        return d.k == 1 and d.g == 2, "Kills " .. d.k .. ", Stück " .. d.g, "Kills 1, Stück 2"
    end, function() s.drops[item] = saved Ca.testWanted = savedW Ca.ResetLooted(guid) end)
end

------------------------------------------------------------------------
-- Ablauf
------------------------------------------------------------------------
local function GT() return _G.GoldSentinelTest end
local AREAS = "abcdefghij"

function TR:CanStart(silent)
    if LP:InCombat() then
        if not silent then LP:Print(L["Testroutine nur ausserhalb des Kampfes."]) end
        return false
    end
    if LP.Virtual and LP.Virtual.active then
        if not silent then LP:Print(L["Testroutine: Es läuft gerade eine virtuelle Reise."]) end
        return false
    end
    if self.running then
        if not silent then LP:Print(L["Testroutine läuft bereits."]) end
        return false
    end
    if not GT() then
        if not silent then LP:Print(L["GoldSentinelTest.lua fehlt – keine Testroutine möglich."]) end
        return false
    end
    return true
end

-- eine Prüfung eintragen
local function RunOne(T, e)
    local id, area, name = e[1], e[2], e[3]
    if IMPL[id] then
        local fn = IMPL[id]
        -- erster Rückgabewert immer als true/false (nil aus "a and b" darf nicht als OK gelten)
        T:Check(id, area, name, function()
            local a, b, c = fn()
            if a then return true, b end
            return false, b, c
        end)
    elseif CLIENT[id] then T:Client(id, area, name, CLIENT[id])
    elseif SKIP[id] then T:Skip(id, area, name, SKIP[id])
    else T:Skip(id, area, name, NOT_YET) end
end

-- Sandbox: echte Daten sichern / in place zurückschreiben / vergleichen
local function Copy(v) return LP.Backup.DeepCopy(v) end
local function RestoreInto(cur, saved)
    for k in pairs(cur) do if saved[k] == nil then cur[k] = nil end end
    for k, v in pairs(saved) do
        if type(v) == "table" and type(cur[k]) == "table" and getmetatable(cur[k]) == nil then RestoreInto(cur[k], v)
        else cur[k] = v end
    end
end

local function Snapshot()
    local sb = { acc = {}, char = Copy(LevelPilotCharDB), enc = {}, encChar = nil }
    for k, v in pairs(LevelPilotDB) do if k ~= "gsTest" then sb.acc[k] = Copy(v) end end
    sb.debug, sb.mode = LP.debug, LP.char.mode
    local P = LP.Planner
    sb.focus, sb.priority, sb.leftZones = P.focus, P.priority, P.leftZones and Copy(P.leftZones)
    sb.queue = LP.Comm.QueueSnapshot and LP.Comm:QueueSnapshot() or nil
    sb.language = LP.db.language
    return sb
end

local function Restore(sb)
    local accSaved = {}
    for k, v in pairs(sb.acc) do accSaved[k] = Copy(v) end
    accSaved.gsTest = LevelPilotDB.gsTest                       -- der neue Bericht bleibt stehen
    RestoreInto(LevelPilotDB, accSaved)
    RestoreInto(LevelPilotCharDB, Copy(sb.char))
    LP:LoadSaved(LevelPilotDB, LevelPilotCharDB)
    LP.debug = sb.debug
    local P = LP.Planner
    P.focus, P.priority = sb.focus, sb.priority
    if sb.leftZones then P.leftZones = sb.leftZones end
end

local function Diff(sb, yield)
    local Enc = GT().Encode
    local bad = {}
    local keys = {}
    for k in pairs(sb.acc) do keys[k] = true end
    for k in pairs(LevelPilotDB) do if k ~= "gsTest" then keys[k] = true end end
    for k in pairs(keys) do
        if Enc(sb.acc[k]) ~= Enc(LevelPilotDB[k]) then bad[#bad + 1] = tostring(k) end
        yield()
    end
    if Enc(sb.char) ~= Enc(LevelPilotCharDB) then bad[#bad + 1] = "LevelPilotCharDB" end
    if LP.char ~= LevelPilotCharDB then bad[#bad + 1] = "LP.char" end
    if type(LevelPilotDB.taxi) == "table" and getmetatable(LevelPilotDB.taxi) ~= nil then bad[#bad + 1] = "taxi (Überlagerung)" end
    if LP.db.language ~= sb.language then bad[#bad + 1] = "language" end
    table.sort(bad)
    return #bad == 0 and "OK" or ("FEHLER: " .. table.concat(bad, ", "))
end

-- Beobachtung echter Spielereignisse während des Laufs
local watch = CreateFrame("Frame")
local WATCH = { PLAYER_REGEN_DISABLED = "Kampf begonnen", QUEST_TURNED_IN = "echtes Spielereignis während des Tests",
                PLAYER_LEVEL_UP = "echtes Spielereignis während des Tests", QUEST_ACCEPTED = "echtes Spielereignis während des Tests",
                TAXIMAP_OPENED = "echtes Spielereignis während des Tests" }
watch:SetScript("OnEvent", function(_, ev) if TR.running and not TR.abort then TR.abort = WATCH[ev] end end)

-- direkte Aufrufe an LP.Act vorbei zählen (nur während des Laufs; hooksecurefunc ersetzt nichts)
local hooked = false
TR.direct = 0
local function InstallHooks()
    if hooked or not hooksecurefunc then return end
    hooked = true
    local function count() if TR.running then TR.direct = TR.direct + 1 end end
    for _, n in ipairs({ "BuyMerchantItem", "RepairAllItems", "TakeTaxiNode", "AcceptQuest", "CompleteQuest", "GetQuestReward",
                         "EquipItemByName", "QuestLogPushQuest" }) do
        if type(_G[n]) == "function" then pcall(hooksecurefunc, n, count) end
    end
end

function TR:Run(area)
    if not LP:DevOnly() or not self:CanStart() then return end
    area = area and area:upper() or nil
    if area and not AREAS:upper():find(area, 1, true) then area = nil end
    local A = LP.Act
    self.running, self.abort, self.direct = true, nil, 0
    LP.testGen = LP.testGen + 1
    A.dry, A.log, A.dryCount = true, {}, 0
    local realBefore = A.real
    InstallHooks()
    for ev in pairs(WATCH) do pcall(watch.RegisterEvent, watch, ev) end
    local errBefore = LP.errorCount
    local T = GT().Begin("LevelPilot", LP.version, LevelPilotDB)
    LP:Print(L["Testroutine läuft – bitte stillstehen …"])
    local sb = Snapshot()
    collectgarbage("collect")
    self.memStart = collectgarbage("count")          -- nach der Sicherung (die Kopie zählt nicht als Zuwachs)

    local sliceStart = Ms()
    local co
    local function yield()
        if Ms() - sliceStart > 8 then coroutine.yield() end
    end
    local function body()
        for _, e in ipairs(self.IDS) do
            if (not area or e[2] == area) and e[1] ~= "T165" and e[1] ~= "T166" then
                if self.abort then T:Skip(e[1], e[2], e[3], self.abort)
                else RunOne(T, e) end
                yield()
            end
        end
        -- Sandbox zurück und vergleichen
        local ok, err = pcall(Restore, sb)
        local sandbox = ok and Diff(sb, yield) or ("FEHLER: " .. tostring(err))
        -- Testfehler aus der Fehlerliste von GoldSentinelTest entfernen (sonst gelten sie als echte Fehler)
        local s = LevelPilotDB.gsTest
        if s and type(s.errors) == "table" then
            for k, v in pairs(s.errors) do
                local m = type(v) == "table" and tostring(v.msg) or ""
                if m:find("LP-Testfehler", 1, true) or (type(v) == "table" and v.wo == "Testroutine") then s.errors[k] = nil end
            end
        end
        pcall(LP.Protocol.LoadEntries, LP.Protocol)
        -- T166: IDs eindeutig und vollständig
        if not area or area == "I" then
            T:Check("T166", "I", "Testfall-IDs eindeutig und vollständig", function()
                local seen, dup, miss = {}, {}, {}
                for _, r in ipairs(T.results) do
                    if seen[r.id] then dup[#dup + 1] = r.id end
                    seen[r.id] = true
                end
                for _, e in ipairs(self.IDS) do
                    if (not area or e[2] == area) and e[1] ~= "T165" and e[1] ~= "T166" and not seen[e[1]]
                       and not (#T.results >= GT().MAX_RESULTS) then miss[#miss + 1] = e[1] end
                end
                return #dup == 0 and #miss == 0, "doppelt: " .. table.concat(dup, ",") .. " fehlend: " .. table.concat(miss, ","), "keine"
            end)
        end
        local extra = { sandbox = sandbox, sprache = LP:Language(), spielsprache = GetLocale(), fehlerzaehler = LP.errorCount,
                        fehlerEindeutig = Count(LP.errors), initFehler = Count(LP.initErrors),
                        datenpaket = _G.LevelPilotData and _G.LevelPilotData.version, modus = LP.char.mode,
                        bereich = area or "alle", echteAktionen = (A.real - realBefore) + self.direct }
        -- T165: Bericht ohne Namen (vor Finish geprüft)
        if not area or area == "I" then
            T:Check("T165", "I", "Bericht gespeichert und datenschutzkonform", function()
                local enc = GT().Encode(T:Report(extra))
                local me = UnitName("player")
                local guild = GetGuildInfo and GetGuildInfo("player")
                local leak = (type(me) == "string" and me ~= "" and enc:find(me, 1, true)) or
                             (type(guild) == "string" and guild ~= "" and enc:find(guild, 1, true))
                local acts = (A.real - realBefore) + self.direct
                return not leak and acts == 0, "Namen im Bericht: " .. S(leak and true or false) .. ", echte Aktionen: " .. acts,
                    "keine Namen, 0 echte Aktionen"
            end)
        end
        local text = T:Finish(extra)
        text = text .. "\n" .. string.format("Sprache: %s (Spiel %s) · Datenpaket: %s", LP:Language(), tostring(GetLocale()),
            _G.LevelPilotData and tostring(_G.LevelPilotData.version) or "fehlt")
        text = text .. "\n" .. string.format("Fehlerzähler LevelPilot: %d (vor dem Test %d, eindeutig %d), Modulstartfehler: %d",
            LP.errorCount, errBefore, Count(LP.errors), Count(LP.initErrors))
        text = text .. "\n" .. (sandbox == "OK" and "echte Daten unverändert: OK" or ("echte Daten unverändert: " .. sandbox:gsub("^FEHLER: ", "FEHLER – ")))
        text = text .. "\n" .. string.format("mitgeschriebene Aktionen: %d · echte Aktionen: %d", A.dryCount, (A.real - realBefore) + self.direct)
        text = text .. "\n" .. "Bitte /reload"
        self.lastText = text
        LP.testGen = LP.testGen + 1
        for ev in pairs(WATCH) do pcall(watch.UnregisterEvent, watch, ev) end
        -- Nachlauf: Trockenlauf noch 5 s, dann Warteschlange von Comm auf den Stand vor dem Test
        C_Timer.After(5, function()
            A.dry = false
            if sb.queue and LP.Comm.QueueRestore then LP.Comm:QueueRestore(sb.queue) end
            self.running = false
        end)
        pcall(LP.ResetLanguageCache, LP)
        pcall(LP.Planner.BuildCandidates, LP.Planner)
        pcall(LP.Planner.Replan, LP.Planner, true)
        pcall(LP.Nav.Recalc, LP.Nav, true)
        pcall(LP.UI.Refresh, LP.UI)
        pcall(LP.Center.Refresh, LP.Center)
        LP.Backup:ShowText(L["Testroutine"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."], text)
        LP:Print(L["Bericht gespeichert – wird beim nächsten /reload oder Ausloggen an die Prüfung gemeldet"])
    end
    co = coroutine.create(body)
    local ticker
    ticker = C_Timer.NewTicker(0.05, function()
        sliceStart = Ms()
        local ok, err = coroutine.resume(co)
        if not ok then
            ticker:Cancel()
            A.dry = false
            pcall(Restore, sb)
            self.running = false
            LP.testGen = LP.testGen + 1
            for ev in pairs(WATCH) do pcall(watch.UnregisterEvent, watch, ev) end
            LP:Error("Testroutine", err)
        elseif coroutine.status(co) == "dead" then
            ticker:Cancel()
        end
    end)
end

-- Kurztest für alle Spieler (/lp test): nur lesende Prüfungen, gleicher Bericht
function TR:Short()
    if not GT() then LP.SelfTest:Run() return end
    local T = GT().Begin("LevelPilot", LP.version, LevelPilotDB)
    for _, e in ipairs(self.IDS) do if self.SHORT[e[1]] then RunOne(T, e) end end
    local text = T:Finish({ bereich = "kurz", sprache = LP:Language(), spielsprache = GetLocale(), fehlerzaehler = LP.errorCount,
        datenpaket = _G.LevelPilotData and _G.LevelPilotData.version })
    text = text .. "\n" .. string.format("Sprache: %s (Spiel %s) · Datenpaket: %s", LP:Language(), tostring(GetLocale()),
        _G.LevelPilotData and tostring(_G.LevelPilotData.version) or "fehlt")
    text = text .. "\n" .. string.format("Fehlerzähler LevelPilot: %d (eindeutig %d), Modulstartfehler: %d", LP.errorCount,
        Count(LP.errors), Count(LP.initErrors))
    LP.Backup:ShowText(L["Selbsttest"], L["Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot)."], text)
    return text
end

-- Halbautomatische Beobachtung (Launch-Abend): 2 Minuten, Aktionen mit Folgen nur mitgeschrieben (haendler, quest, flug)
local OBSERVE = { kampf = false, haendler = true, quest = true, flug = true, trainer = false, gruppe = false }
function TR:Observe(kind)
    if not LP:DevOnly() then return end
    if self.running then LP:Print(L["Testroutine läuft bereits."]) return end
    local A = LP.Act
    local dry = OBSERVE[kind]
    self.running = true
    local err0, mark = LP.errorCount, #A.log
    if dry then A.dry = true end
    LP:Print(L("Beobachtung „%s“ läuft 2 Minuten – jetzt die Aktion im Spiel ausführen.", kind))
    C_Timer.After(120, function()
        if dry then A.dry = false end
        self.running = false
        local names = {}
        for i = mark + 1, #A.log do names[#names + 1] = tostring(A.log[i].name) end
        LP:Print(L("Beobachtung „%s“ beendet: neue Fehler %d, mitgeschriebene Aktionen: %s", kind, LP.errorCount - err0,
            #names > 0 and table.concat(names, ", ") or "–"))
    end)
end

function TR:Command(arg)
    arg = arg and arg:lower():gsub("^%s+", ""):gsub("%s+$", "") or ""
    if arg == "" then return self:Run(nil) end
    if #arg == 1 and AREAS:find(arg, 1, true) then return self:Run(arg) end
    if OBSERVE[arg] ~= nil then return self:Observe(arg) end
    if arg == "reise" or arg == "journey" then
        LP:Print(L["Lange Reisen (T84, T180, T183) sind in der Testroutine noch nicht automatisiert – bitte /lp reise vergleich."])
        return
    end
    LP:Print(L["Testroutine: /lp testroutine [a–j | kampf | haendler | quest | flug | trainer | gruppe]"])
end
