# LevelPilot – Änderungen (Deutsch)

Ältere Versionen stehen in CHANGELOG.md (Englisch).

## 3.12.5
Grundeinstellung nach Entscheid des Nutzers, offene Punkte der Prüfung vom 3. November 2026 und neue Testroutine.
- Grundeinstellung: Automatisch reparieren und Auto-Flug sind ab Werk wieder an; Vorräte nachkaufen und
  Questbelohnung anlegen bleiben aus. Bestehende Einstellungen ändern sich nicht – wer 3.12.4 neu installiert hat,
  schaltet Reparieren und Auto-Flug in der Zentrale ein (Komfort).
- Neue einmalige Hinweise: beim ersten Händler, bei dem LevelPilot nachkaufen würde (Nachkaufen aus), und bei der
  ersten Questbelohnung, die ein Upgrade ist (Anlegen aus), zeigt LevelPilot einmal, dass es die Option gibt – mit
  „Einstellungen“ und „Später erinnern“ (frühestens 3 Level später). Es wird nichts gekauft, gewählt oder angelegt;
  nie im Kampf, nie mehr, sobald die Option an ist. Auch die Begrüssung „Wo war ich?“ zeigt einmal einen Tipp.
- Dropraten auf WoW Forever: Wird dieselbe Leiche erneut geöffnet (Tasche voll, Fenster geschlossen), zählen Kill und
  Stückzahl nicht doppelt; ein Beutefenster mit geschütztem Link wird ausgelassen statt einen Kill ohne Beute zu
  zählen; Taschendiebstahl (Ziel lebt noch) zählt nicht als Kill.
- Klassenhinweise: Antwortet keine Zauber-Funktion, behauptet LevelPilot nicht mehr, Erste Hilfe/Kochen fehle.
- Erkennung: Meldet GoldSentinelGame „nicht modern“, folgt LevelPilot dem (eigene Erkennung nur ohne GoldSentinelGame).
- Alle Zeitgeber laufen geschützt über LP:Ticker (Neuplanung, Assistent, Partnersuche, Datenaustausch, Reise).
- Fehlende Übersetzung des Protokolleintrags „Datenpaket veraltet“ ergänzt (alle Sprachen).
- Robustheit: Fehlende Spielfunktionen (Reparaturkosten, Haltbarkeit, Munition, Questgeber-Begrüssung,
  Gegenstandsinfo) führen nicht mehr zu Lua-Fehlern.
- Aktionen mit echten Folgen (Kaufen, Verkaufen, Reparieren, Anlegen, Quests, Flug, Senden, Einladen, Neuladen)
  laufen über eine Stelle (LP.Act); im normalen Spiel ändert sich nichts.
- Neue Testroutine für den Entwickler (Testmodus): /lp testroutine [a–j] und Knopf „Alles testen“; Sandbox für
  deine Daten, Aktionen werden nur mitgeschrieben. /lp test (für alle) schreibt jetzt einen maschinenlesbaren
  Bericht. Berichte und Lua-Fehler werden für die GoldSentinel-Prüfung gespeichert (GoldSentinelTest.lua, ohne Namen).
