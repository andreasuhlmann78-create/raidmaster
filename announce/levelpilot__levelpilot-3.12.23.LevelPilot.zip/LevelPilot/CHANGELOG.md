# LevelPilot changelog

## 3.12.23
- Zone requests and partner-finder messages without the sender checksum (LevelPilot up to 3.12.21) are no longer
  accepted – a relaying player could bring them into his guild under his own name. Players with 3.12.21 get no zone
  answers and no partner hints from others until they update.
- Way recording: positions every 0.5 s; a gap of more than 25 yards between two positions (lag, teleport, very fast)
  splits the way instead of storing it as a straight line.
- Once after the update, long straight way pieces from older versions are split into pieces of at most 25 yards (on
  the walked line), then loose ends are joined again.
- Test routine: new cases T259, T260; T254 extended.

## 3.12.22
- Sharing settings are kept exactly: guild, group and whisper network only when switched on. The network goes along
  only when guild and group are both on (GoldSentinelSync has no "network only" yet).
- Zone requests and the elite partner finder go only to guild and group, and carry a checksum of the sender's name.
  Messages passed on through the network (sender = the player who passed it on) are ignored – no answer to the wrong
  player, no wrong name in the partner hint.
- Zone replies have at most 25 messages (the rest with the next request) and are only sent while the shared send queue
  of all GoldSentinel addons is almost empty.
- Recordings that could not be sent (no way) are sent again later in the same session.
- Test routine: uses its own empty send queues; messages of other addons are no longer sent during the test.
- Diagnosis log: no "step active for 25 min" while you stand in a capital (bank, auction house, mail) or are in a
  dungeon; no focus warning while the current step is in your zone; no zone warning in caves without their own map.
- Test routine: new cases T254–T258, T243 extended.

## 3.12.21
Data exchange over the shared GoldSentinelSync (version 2) instead of an own chat channel.
- In WoW Forever addon messages in own chat channels never arrive. LevelPilot no longer joins the channel
  "LevelPilotNet" and leaves it once (frees a channel slot).
- Sent over guild, group/raid and the new whisper network of GoldSentinelSync 2 (reaches all players with LevelPilot
  across guilds): recorded quests, ways, caves, flights, zone requests and hello. Only guild and group: loot and mob
  values (frequent) and the group mode (level, step, quests – group only). The elite partner finder (if switched on)
  goes into the network as before over the channel. Zone replies go by whisper to the asking player.
- Older LevelPilot versions of other players are still understood (same message prefix).
- Known players of the network are kept over /reload (LevelPilotDB.gsSync, names and times only, local only).
  Former sender names in the saved data are now stored as checksums only.
- /lp sync test: "N replies (guild a, group b)". Diagnosis log: SYNC/NETZ lines (no names), NOT_ALLOWED_IN_CHANNEL counted.
- Center, sharing tab: "Through the whisper network" instead of the addon channel, players online instead of
  channel status.
- GoldSentinelTest 2: share error reports with the developer (only with consent, /gstest).
- Test routine: new cases T242–T253; T92, T108, T111, T169 adapted.

## 3.12.20
- Shared file GoldSentinelGame.lua version 3 (comments only, no player names in the examples).
- No real character names in LevelPilot's own files: tests use "Testa Beispiel", the developer character is only
  stored as a checksum.

## 3.12.19
- More game queries are checked for protected values before use: facing (arrow, minimap), indoors (caves, map
  radius), resting, movement speed and the player's and pet's level. A protected level falls back to the last
  readable level.
- Test routine: new case T241. T128 now checks old saved data without your own measurements (before it showed
  "measured true" in the game). Intentional test errors of T158–T163 no longer raise the error counter in the
  report.

## 3.12.18
- LevelPilot's own tooltips no longer cover its buttons (Support, Center, Normal, Skip …). They appear next to the
  window the button belongs to – on the right, if there is no room on the left, otherwise below – at the height of
  the button. Applies to the guide window, step list, assistant line, size grip, action bar and arrow.
- Test routine: new case T240.

## 3.12.17
Better way data (from the evaluation of the submitted way data).
- New way pieces are joined to the existing network: if the start, end or a crossing lies within 10 yards of a known
  way, that way is split there and connected. Existing loose ends are joined once after the update (nothing is lost).
- Way points are stored at least every 25 yards and at every change of direction over 30° (before, straight pieces
  of several hundred yards had no point in between).
- No ways are recorded or sent on the continent map (flight, ship).
- Way data (/lp wege, GSWEGE1): quest giver positions old/new both as [x, y], "oldMap" if the data pack has the NPC on
  another map, the data pack position is the nearest one on the same map (not the first), "nopack" for NPCs without a
  position in the data pack.
- Data pack 1.6.1: positions of Gordo (10666, Tirisfal Glades) and Bluff Runner Windstrider (10881, Thunder Bluff)
  corrected for WoW Forever.
- Test routine: new cases T235–T239.

## 3.12.16
Grey items are sold automatically, without a button.
- When a vendor window opens, LevelPilot sells all grey items with a sell value on its own (out of combat, one item
  every 0.2 s, stops when the vendor window closes or combat begins). Locked items and items needed for a quest
  stay. Afterwards one chat line: "Sold N grey items for …" – no line if nothing was sold.
- Option "Sell grey items at vendors" (on by default) in the center, or /lp grau (/lp grey) to toggle.
- LevelPilot puts nothing on or next to the vendor window. Note: the button "Sell: 0 items (0)" at the vendor
  window comes from AHSentinel, not from LevelPilot.
- Test routine: new cases T230–T234 (option on/off, only quality 0, stop on MERCHANT_CLOSED, nothing in combat,
  only logged during the test). Cases that cannot be checked in the current situation (e.g. level 60, no data pack,
  no target) now count as "skipped" with a reason instead of "OK".

## 3.12.15
Test routine checks the interface (from the GoldSentinel template).
- New file UICheck.lua: all LevelPilot windows are registered (guide window, center, backup, group panel, virtual
  playthrough, donation, step menu, action bar, arrow).
- New area K in /lp testroutine (T224–T229): own tooltips cover no buttons, no overlap with Blizzard or other
  GoldSentinel windows, windows fully on screen, button labels not cut off, values plausible, no error loops
  (no Lua error more than 10 times per session).
- Plausibility: the number of finished quests in the quest log matches the number of "Turn in" steps in the list;
  quest count, level and map position are checked too. T224–T227 run only in the real client.

## 3.12.14
- Fixed: Lua error "attempt to perform boolean test on a secret boolean value" (Session.lua, hundreds of times on WoW
  Forever). UnitIsAFK sometimes returns a protected value there; then only LevelPilot's own idle timer counts.
- All other queries returning a truth or number value (flight, dead/ghost, combat, vehicle, unit exists, player
  position, XP and rested bonus) are checked for protected values before use.
- Test routine: new case T223 (protected truth values from UnitIsAFK & co.).

## 3.12.13
Exception during the pause (decided by the user): finish the zone first.
- If you still have open quests in the zone you are in (including its capital), planning stays there. Only then does
  the route continue to the next zone, collected. Turn-ins in another zone are no longer a reason to leave the zone.
  Quests that are too dangerous for your level or unreachable are the exception.
- Test routine: new case T222 (open quests in Mulgore before turn-ins in the Barrens).

## 3.12.12
Accurate ways, step 4 (exception during the pause, decided by the user): way data for submission.
- New command /lp wege (or /lp wege <zone>): shows the learned ways per zone as coordinate lists (origin own/shared,
  how often walked), blocked stretches, corrected quest giver positions and STUCK events of the last 7 days as
  selectable text – without player, character or guild names.
- Automatic: on logout and /reload LevelPilot puts new and changed way data (tag GSWEGE1, at most 200 KB) into its
  saved data; the RaidMaster uploader can pick it up like the test reports. Can be switched off in the control
  center under Sharing ("Send way data automatically", on by default).
- Test routine: new case T221 (text, GSWEGE1, only new data, can be switched off, no names).

## 3.12.11
Accurate ways, step 3 (exception during the pause, decided by the user): real positions of quest givers.
- When you talk to a quest giver (accepting, turning in, gossip), LevelPilot remembers its real position and uses it
  instead of the coordinates from the data package – wrong targets in changed Forever zones are corrected this way.
  The positions are backed up in the character like all collected data.
- Learning ways (every walked stretch), sharing ways and caves with group and guild, and flights for long distances
  already existed and stay unchanged.
- Test routine: new case T220 (real position of a quest giver, protected values).

## 3.12.10
Accurate ways, step 2 (exception during the pause, decided by the user): learning from dead ends.
- "STUCK" now only counts pure walking time: the clock only runs while you really move. Standing pauses it (it does
  not start anything); AFK, dead/ghost, combat, flight, open merchant, mail, auction, profession and trainer windows,
  loading screens and /reload never count. Only after 4 minutes of walking without getting closer is a way STUCK.
- On STUCK, LevelPilot remembers the stretch as blocked and looks for another way; if none is known, only the arrow
  shows the direction.
- Test routine: new case T219 (10 min AFK, 2 min standing and 1 min walking, 4 min in a circle, blocked edge).

## 3.12.9
Accurate ways, step 1 (exception during the pause, decided by the user): way network instead of straight lines.
- The route is only drawn along known ways: walked or shared stretches, zone transitions and caves. Only the first
  and the last short piece (up to 40 yards) may be a straight line.
- If no way is known, LevelPilot no longer draws a line – the arrow shows the direction to the target with the note
  "unknown way". Better no line than a wrong one (never across mountains again).
- The way network grows from walked ways; own coordinate lists for Mulgore, the Barrens and Thunder Bluff follow
  once enough has been recorded.
- Test routine: new case T218 (Mulgore case 1 and 2, target without network, Thunder Bluff with elevator).

## 3.12.8
Exception during the pause (decided by the user): route in Thunder Bluff and Mulgore.
- Capital cities belong to their zone for planning (Thunder Bluff – Mulgore, Orgrimmar – Durotar, Undercity –
  Tirisfal, Stormwind – Elwynn, Ironforge – Dun Morogh, Darnassus – Teldrassil). On WoW Forever the cities have no
  parent zone, so the focus often was on the wrong map. Tasks on both maps are ordered by the way.
- The focus follows the player: if the old focus zone is far behind you, it switches to the zone you are in.
- The focus guard in the error log replans by itself instead of writing the message again and again; it reports only
  once if that does not help.
- Priority targets (trainer, profession, vendor …) never come before quests ready to turn in nearby. If you do not
  get closer to a priority target for minutes (e.g. a trainer up in Thunder Bluff), LevelPilot only shows the arrow.
- Test routine: new case T217 (Thunder Bluff and Mulgore, focus guard, priority target after nearby turn-ins).

## 3.12.7
Exception during the pause (decided by the user): route in Mulgore and a Lua error in the error log.
- Quests ready to turn in nearby (up to 900 yards) now always come first – before flight masters, binding, hearthstone
  and distant targets; the nearest first. A turn-in right nearby is planned even if the danger map rates the place as
  too dangerous (you are already there).
- Recorded places (own, start database, from other players) only take precedence over the data package if they match
  it; if they are far off, LevelPilot uses the places from the data package. Recorded vendors and innkeepers without
  walkable ground around them (e.g. in the middle of the mountains) are no longer offered.
- If a part of the way is a straight line over mostly unknown terrain (mountains, rocks), LevelPilot no longer draws
  a line; the arrow then points straight towards the target.
- Error log: no more Lua error caused by protected values (movement/speed) on WoW Forever ("attempt to compare a
  secret number value").
- Test routine: new cases T214 (nearby turn-ins first, Mulgore case 1 and 2), T215 (no target and no line in the
  mountains) and T216 (error log with protected values).

## 3.12.6
Open points of the review of 3 November 2026 (re-check of 3.12.5).
- More accurate drop rates on WoW Forever: a kill now counts at the monster XP message (dead target), even if the
  corpse has no loot – the rate is no longer too high. Pieces count only when the item really arrives in your bags
  (loot message); anything left behind with full bags counts only when you pick it up later. Each corpse counts once,
  protected values are never used.
- Profession and class hints: if the first spell query answers "not known", LevelPilot asks the others as well
  (IsPlayerSpell) – no more wrong hint about First Aid/Cooking.
- Reward hint: if the item info is not loaded yet when the reward opens, LevelPilot checks again after one second.
- Damaged saved entries (wrong type) are skipped or replaced on load instead of causing Lua errors; valid collected
  data stays unchanged.
- Protected values: XP display, time to 60, group status and the rested hint never calculate with protected XP;
  tooltips, measurement and enemy lines check protected units.
- Errors that were caught silently so far (virtual journey, backup at logout, protocol checks) are now reported to the
  GoldSentinel review. The diagnosis shows module start errors.
- Planning time of the virtual journey only counts computing time (no longer the pauses between frames).
- Test routine (test mode): all test cases automated (96 placeholders before), "not automated" count in the report,
  new client cases T171, T195 and T213 (profession spells), long journeys with /lp testroutine reise.
  The copy window says "It is also reported automatically." (all languages).

## 3.12.5
Defaults decided by the user, open points of the review of 3 November 2026 and the new test routine.
- Defaults: automatic repair and auto-flight are on again by default; restocking at merchants and equipping quest
  rewards stay off. Existing settings are not changed – if you installed 3.12.4 fresh, switch repair and auto-flight
  on in the control center (Comfort).
- New one-time hints: at the first merchant where LevelPilot would restock (restocking off), and at the first quest
  reward that is an upgrade (equipping off), LevelPilot shows once that the option exists, with "Settings" and
  "Remind me later" (at the earliest 3 levels later). Nothing is bought, chosen or equipped; never in combat, never
  once the option is on. The "Where was I?" greeting shows a one-time tip as well.
- Drop rates on WoW Forever: reopening the same corpse (bag full, window closed) no longer counts kills or pieces
  twice; a window with a protected loot link is skipped instead of counting a kill without loot; pickpocketing (the
  target is still alive) no longer counts as a kill.
- Class hints: when no spell function answers, LevelPilot no longer claims that First Aid/Cooking is missing.
- Detection: when GoldSentinelGame reports "not modern", LevelPilot follows it (own detection only without it).
- All timers run protected via LP:Ticker (replanning, assistant, social, data exchange, journey).
- Missing translation of the protocol entry "data package outdated" added (all languages).
- Robustness: missing game functions (repair cost, durability, ammo count, greeting quests, item info) no longer
  cause Lua errors.
- Actions with real consequences (buying, selling, repairing, equipping, quests, flights, sending, inviting, reload)
  run through one place (LP.Act); in normal play nothing changes.
- New test routine for the developer (test mode): /lp testroutine [a–j] and the button "Test everything"; sandbox
  for your data, actions are only recorded. /lp test (for everyone) now writes a machine-readable report.
  Reports and Lua errors are stored for the GoldSentinel review (GoldSentinelTest.lua, no names).

## 3.12.4
The rest of the strict review of 2 November 2026.
- Drop rates on WoW Forever: without a combat log LevelPilot now counts while looting – every looted corpse of a
  monster that drops a needed quest item counts as a kill, the pieces come straight from the loot window
  (GetLootSourceInfo, outside combat, protected values left out). Corpses without loot are not opened, so the rate
  may come out slightly high. Classic clients keep the old way (combat log and loot message).
- Actions with real consequences are off by default for new players: buying supplies at merchants, automatic
  repair, automatic flight and equipping quest rewards. Existing settings stay as they are; switch them on in the
  centre.

## 3.12.3
From the strict review of 2 November 2026 – ready for the WoW Forever launch.
- Fixed: /lp reise bericht gave a Lua error (missing L in Core.lua).
- Protected values of the modern client ("secret values") are checked before use: hearthstone cooldown (shows
  the last readable value), quest giver and merchant names, object tooltips, loot messages, addon messages
  (data exchange and group mode).
- Fallbacks for the modern client: ChatFrameUtil.OpenChat (group finder text), removing the data channel from chat
  windows via the chat frame, UnitQuestTrivialLevelRange (green quest range), C_SpellBook.IsSpellKnown (class
  hints; without any of these functions no hint instead of a wrong one). The self-test lists game functions that
  are not available.
- WoW Forever is recognised via GoldSentinelGame (client 1.60.x); the own detection stays as fallback, the setting
  still has priority. Corrected comment: Forever is not a 1.15.x client.
- The data package must be at least 1.6.0; an older one still works but shows a hint once.
- Performance: away from the path the route is recalculated at most every 0.5 s, never during flights.
- Robustness: all timers run protected (an error no longer repeats every second), protocol entries with damaged
  fields no longer stop the error log, garbage collection step protected, quest-completed check unified.

## 3.12.2
Time model adjusted to WoW Forever (from the review of 2 November 2026).
- XP per kill by level difference instead of always the full value: same level 45 + 5 × level, higher +5 % per
  level (at most 4), lower × (1 − difference / ZD), grey 0 (Classic formula). One function for planning and the
  virtual journey (monsters on the way with their average level, quest kills with the level of the quest's
  enemies).
- WoW Forever: green monsters (3 or more levels below you) give less XP than in Classic – estimate 0.85 until
  measured.
- Dungeon values for WoW Forever (provisional, status 2.11.2026): mob XP 36 % (September cut, +20 % on 8 October),
  dungeon quest XP ×1.5 (bonus share cut by 50 % on 1 October). The setting "dungeon mob XP %" still has priority.
- Real XP per kill is measured while playing (only via your XP, never the chat text): per level difference against
  the formula, separately inside dungeons. Not counted with rested XP, in a group, or when the enemy's level is
  unknown or protected. From 20 measurements per step the measured value replaces the estimate.
  The status line shows "XP per kill: measured n · green x %".
- WoW Forever: group hints note that a much higher group member can cause everyone to get 0 XP.
- "Time to 60" says that it comes from your XP of the last hour and applies to every mode.
- Virtual journey (test mode): "both modes" runs 1–60 once normal and once speedrun and shows both times; the report
  says whether kills per minute, XP per kill and dungeon factors are measured, set or estimated.

## 3.12.1
Test mode for the developer only, and ready for the modern WoW Forever client.
- Test mode (virtual journey, self-test with journey, /lp debug) is only unlocked for the developer (recognised by
  Battle.net account; character list as fallback). /lp reise stop always works. Self-test, error log and
  /lp messen stay available for everyone.
- GoldSentinelGame.lua (shared game version detection of all GoldSentinel addons) included unchanged; /lp diag,
  /lp messen and the self-test show the game version. Protected values of the modern client ("secret values",
  e.g. GUID, level or name of units in combat) are checked before use: nameplates, target, measurement, quest giver.
- Modern client: the combat log is closed to addons there, so LevelPilot no longer registers for it on WoW Forever
  (drop rates are then not counted from kills). Merchant offers, item count, links and purchases via C_MerchantFrame when the old functions are missing, guild summary
  via C_ChatInfo.SendChatMessage when available, item names via C_Item.
- Own character recognised via GoldSentinelGame.SameName (WoW Forever: first and last name).

## 3.12.0
Fewer zone changes, faster speedrun.
- Staying in the zone: the focus zone is only left when almost nothing is left to do there – turn-ins count fully
  for that (otherwise you come back later just for them). A zone you just left is only chosen again when a lot
  of new work waits there. Larger quest packages are preferred.
- No long trips for one small task: a zone with little to do further than 1500 yards away is skipped; instead you
  defeat monsters nearby for a short while until the next level brings new quests. Fewer zone changes
  (in the virtual journey about 90–110 instead of 130–180 up to level 60), less walking.
- Collecting turn-ins: a single turn-in far away (no quest giver and no other turn-in there, no follow-up quest)
  waits until you pass by or the quest log is nearly full.
- Hearthstone used more often: binding also at an inn up to 600 yards away (new zone's quest hub), used from
  1200 yards of way when the bind point is clearly closer to the target.
- Virtual journey 1–60 (test environment): speedrun 8–18 hours faster for most races; more grinding instead of
  long trips (about 16–31 hours). Mob rule targets 0, flights only via discovered flight points.
- Journey report: focus zone changes and returns to zones already visited.

## 3.11.0
Speedrun as fast as possible to 60, and a measurement routine for the test environment.
- Speedrun reworked: it goes straight for the next quests and only takes the monsters that lie on the way anyway
  and still give XP (not grey, at most 2 levels above you). Grinding only when no quest is left in reach.
  Quests are only dropped when they are clearly slow; quests in a chain and quests at a hub with 3 or more
  quests stay in (one trip covers several). Low quests stay in at such a hub.
  Virtual journey 1–60: the speedrun is now faster than the normal route for every race (about 4–8 %);
  without the monsters on the way it would be 14–24 hours slower.
- New command /lp messen (/lp measure): reads everything that can be checked standing still and shows it as text to
  copy – position with map ID, danger map at your spot and the grinding spot, target and nameplates (real mob
  level against the data package, deviations marked), quest log with objectives and the planned mob level,
  the first 10 route steps, deferred quests (mob rule), flight points with their zone position, all zone maps
  with their bounds, hearthstone, learned values and level times. It only reads – nothing is changed or sent.
- Quest objectives are bundled: when objectives of several quests lie in the same area (within 300 yards), they
  are done in one pass – one search, kills of the same monsters count for every matching quest. The guide shows
  "Do at the same time: …" at the step; the speedrun keeps such quests (one trip covers several). Elite objectives
  and objectives with monsters 3 or more levels above you are never bundled.
- Drop rates are learned while you play: kills of the monsters that drop a quest item (your hits or your pet's)
  against the items you loot, and the amount the quest needs. From 10 kills on, planning uses the real rate;
  before that an estimate (longer when the droppers have few spawn points). The speedrun skips quests whose items
  drop clearly rarely ("items drop rarely").
- Real mob levels: LevelPilot notes monsters whose level on WoW Forever is higher than in the data package
  (nameplates and target). The danger map and the mob rule use the higher level – never a lower one.
- Exchange with other LevelPilot players now also carries drop rates, differing mob levels (used from two
  reports) and flight times – sums only, senders are stored as numbers, implausible values are rejected.
- The learned values are part of the character backup and are healed from it like quests and flight points.
- Upgrade hints ("Possible upgrade for your class … Equip") are no longer shown for items that are already in your
  bags when you log in or reload – only for items you get afterwards (loot, purchase, mail). The option stays on
  by default. Quest reward recommendations stay.
- Journey report: time split (walking, ship/zeppelin, flying, objectives, monsters on the way, grinding, dungeons)
  and the number of bundled objectives.
- Flight times are learned from real flights (straight line from take-off to landing against the measured time,
  used from 3 flights on; never during a journey). The virtual journey then uses the learned time.
- The journey report shows the learned flight time next to kills per minute and the quest XP factor.
- Flight points have to be discovered first (walk to the flight master and talk to him): flights are only planned
  between points this character has discovered. The virtual journey checks this for every flight and the report
  shows "flight points discovered: X · flights via undiscovered flight points: 0 (goal 0)".

## 3.10.1
From GoldSentinel's reference "real game world" (Horde, WoW Forever).
- Alliance ships (Rut'theran–Auberdine, Auberdine–Menethil, Menethil–Theramore) are no longer planned for the Horde
  – they go through Alliance harbours.
- Zeppelins and ships take realistic time: average waiting time (half a cycle) + ride + loading screen (zeppelin
  about 6.5 min, ship about 6 min); the virtual journey now counts that time instead of a flat 2.4 minutes.
- Flights take time by distance (about 32 yards/s, flight routes 30 % longer than the straight line, plus take-off
  and landing) instead of a flat 2 minutes.
- Towns of the other faction (elite guards or NPCs from level 45) are blocked areas for every level and appear in
  the report as "town of the other faction" instead of "mob 63/65". Other NPCs of that faction (e.g. the
  farmers of Hillsbrad, quest targets for the Horde) count with their own level.
- Safety: skipping a step during a journey never writes into the real character.

## 3.10.0
Learning from the real game, and a virtual journey closer to it.
- New module Calib.lua learns from your play (numbers only, stored account-wide, never during a journey):
  kills per minute of your class (time between monster XP messages, breaks over 2 minutes excluded; used from
  20 measurements on) and the WoW Forever quest XP factor (your real quest XP against the Classic values of the
  data package; median, used from 5 quests on). /lp diag and the journey report show both.
- One time model for planning and the virtual journey: a kill objective takes kills ÷ kills per minute plus search
  time (before: 150 s in planning, 420 s in the journey). Starting values per class (hunter 2.2, warrior 1.7 …).
  Monster XP while questing counts fully; ways inside a quest area count 60 % (shared with other quests there);
  the way to a quest giver is shared among all quests taken there.
- Grinding only as a short gap and at a good spot: the step leads to the nearest place with monsters of your
  level (from the danger map), about 20 minutes, then replanning. The journey walks there.
- Virtual journey: rested XP and the real hearthstone cooldown are taken over ("journey from here"); rested XP
  doubles monster XP until used up.
- Sandbox check: a fingerprint of your real data (quests, waypoints, path sections, flight points, vendors,
  caves, ignored and turned-in quests, backup) before and after every journey; any difference is an error in the
  report and the error log. Journeys are logged as "REISE", not as play sessions.
- Report: comparison with your real level times (per level and average deviation, goal below 15 %).
- Speedrun default is now "medium" (a saved "strict" from the old default is switched once; choosing "strict"
  again keeps it).

## 3.9.1
From the in-game test report of 3.9.0.
- Fixed (data loss): all recorded flight points could be lost. "Journey from here" did its heavy setup inside the
  chat command; when the game aborted it ("script ran too long") halfway through, Stop set the flight point list
  to nothing, and the next backup copied the empty list. Now: the real data is remembered first, restoring never
  sets anything to nil, an overlay left behind is recognised and unwrapped, and the heavy setup runs inside the
  journey in small slices.
- Fixed (data safety): the character backup is now its own copy (not the same tables as the account), and before
  every backup update missing entries are restored from the old backup (only adds, never deletes).
- Fixed: the virtual journey wrote quest progress positions into the real quest database (qdb[7734]).
- Right-click on a step opens a menu (postpone 30 min / ignore quest / cancel) instead of ignoring at once;
  /lp zurück brings back the last ignored quest.
- Text windows (report, log, self-test) no longer keep the keyboard: Enter ends input, so the next chat command
  works with the first Enter (/lp reise bericht seemed to do nothing).
- Danger map: NPCs of the other faction count only as a group (guards), without the elite bonus – single quest
  givers and battleground NPCs (e.g. "mob 63" at the Alterac pass, "mob 62" at the Rebel Camp) no longer count.
- Watch mode draws the trail of the last steps (thicker, accent colour); the journey report places dangerous
  spots in the zone that contains them (no more y > 100).
- Lua errors inside the journey also go to the error log (up to 5 per journey).
- Finer slices in planning and the danger map against "script ran too long".
- Compact guide shows one distance; the current step shows the path length everywhere (no more 725 vs 755).
- /lp lang without a code shows the current language and only displayable languages; /lp weg confirms the
  waypoint; "Nearest – inn: …" wording.
- Chinese/Korean: the en dash "–" is replaced (no boxes); shorter labels for Portuguese ("Troca") and Russian
  ("Авто"); switching languages back and forth stays clean.

## 3.9.0
From the in-game test report of 3.8.1.
- New mandatory rule: the route never leads to targets where mobs are 3 or more levels above you (elite counts
  2 levels higher). New module Danger.lua builds a danger map from the data package (highest hostile mob level
  per 100-yard cell; dungeon elites at entrances and rare mobs excluded). Quests are accepted and done only when
  their mobs are doable; target spots, quest givers, turn-ins and flight masters in dangerous areas are skipped.
  Paths through such areas cost 25× in the path search (detour if one is known); the real path to the first
  target is checked and the target deferred if it leads through danger. Applies to normal play, speedrun and the
  virtual journey (with the journey's level). The journey report has a new section "Mobs ≥ +3".
- Step order: the chain is shortened with 2-opt and or-opt (accept before complete before turn-in, quest log
  never overflows) – e.g. Ratchet steps now come after the targets around the Crossroads. Accepts and turn-ins
  no longer get a strong distance bonus.
- Fewer zone hops: passing through a zone or landing after a flight no longer moves the focus there; single
  turn-ins count less when choosing a zone; a continent change at most every 3 levels; donation and war effort
  quests ("A Donation of Wool", "The Horde Needs …") are no longer planned.
- Speedrun: grind rate 1.5 kills per minute (was 2.2, too optimistic) so more quests pay off; hearthstone bind
  from 3 tasks in a zone.
- Flight points are always placed at their flight master's zone (no "Kalimdor" as a zone after flights).
- "script ran too long": the path search hands control back to the game every 5 expansions during the journey.
- Control center opens faster (zone overview reuses the last plan instead of recalculating everything).
- Watch mode: shows the path just walked on the world map and pauses 2 s after each finished step.
- Journey report: long straight lines show the start of the section in its own zone's coordinates.
- Safe mode is now stricter than the mandatory rule: avoids elites and mobs from your level + 1.

## 3.8.1
Found with GoldSentinel's real saved data (LevelPilot.lua from the WTF folder).
- Fixed: flights. The game stores flight points on the flight map (e.g. map 1464), which can't always be
  converted to world positions – then LevelPilot never planned a flight (0 flights in the in-game test).
  LevelPilot now calibrates the flight map itself: zone names in the flight point names plus the flight
  masters from the data package give shift and scale; each flight point gets its flight master's position.
  All 19 recorded Horde flight points in Kalimdor are located (within 40 yards). The flight point you stand
  at when opening the flight map is stored as an exact reference.
- Self-test: new check "Flights" (how many flight points are located and known).
- Error log: entries from 3.4–3.6 were stored in the language set at that time. Solved zone messages are
  removed, the others are converted and shown in the current language. "Not getting closer" is no longer
  reported while you hunt within 400 yards of a quest target.

## 3.8.0
Fixes from the in-game test report of 3.7.0. Route and path changes apply to normal play, not only to the
virtual journey.
- Route: quests in the other faction's home zones that are open to everyone (e.g. Westfall for the Horde),
  PvP quests and battleground quests (Alterac Valley, Warsong Gulch, Arathi Basin) are no longer planned.
- Route: fewer zone and continent hops. Below level 12 you stay on your own continent; a zone on another
  continent only becomes the focus with at least 5 tasks and clearly more value than anything left here.
- Speedrun: the way to a quest giver now only affects the order, not whether a quest is skipped – before,
  standing in a capital far from quest givers could leave you grinding for hours (L28–50 in Thunder Bluff).
- WoW Forever is the default: quest log 40, dungeon monster XP about 30 %, dungeon quest XP about ×2
  (setting "WoW Forever server" under Settings » Server & dungeons).
- Zone check: "Das Brachland" and "Brachland" count as the same zone (no more ZONE entries).
- Virtual journey: planning is spread over several frames ("script ran too long" is gone), Stop ends it at
  once, it uses flight paths and its own hearthstone cooldown, quest levels are coloured by the journey's
  level, "Journey from here" takes over your real quest log, the window shows the result after the end.
- Data safety: logging out or /reload during a virtual journey restores your real flight paths and
  character data first, so nothing virtual is ever saved.
- Error log: entries are stored as keys and shown in the current language, sorted newest first; the
  self-test shows log entries as a hint instead of OK. Obsolete "language pack MISSING" entries are removed.
- Display: settings hint no longer overlaps "Support the addon"; objective names instead of "?"; the time
  estimate includes the remaining path.

## 3.7.0
- New: self-test (/lp test or control center » Data » Self-test) checks all functions in the game – modules,
  data package, language and names, position and zone, planning, path to the current step, display, map,
  nameplates, target button, comfort, sharing, error log – and shows a report to copy.
- New: virtual journey 1–60 (/lp reise, or "Journey from here" with /lp reise hier). An imaginary character
  runs LevelPilot's whole route with the game's real map and path data: accepts, completes and turns in
  quests, earns XP by Classic rules, flies and uses the hearthstone. Your character does not move; nothing
  is recorded or shared. "Watch" shows every path on the world map, "Fast" computes straight through.
  The report lists missing paths, long straight lines per zone, stuck plans, levels and zones.
- Fixed: Searing Gorge had no zone transition – found by the virtual journey; it is now connected to the
  Burning Steppes through Blackrock Mountain.

## 3.6.0
- Fixed: translated quest, NPC, item, object and zone names did not appear in the game, because WoW only
  detects new AddOn folders after a full restart. The names are now part of the data package itself
  (LevelPilot Data 1.6.0, Data/Names_*.lua) – a /reload is enough, and there are only two folders again.
- Languages your game can't display are released from memory at login.
- Target button: uses the enemy names of your game's language (before, non-English games got the
  English names and /targetexact found nothing).
- The separate folders LevelPilot_Data_deDE … from 3.5.x are no longer needed and can be deleted.

## 3.5.3
- Changed: the language selection only offers languages your game can display. LevelPilot measures it:
  a missing font draws every character as an identical box, so if all sample characters of a language
  are as wide as a surely missing character, that language is hidden. On European and Russian clients
  Korean and Chinese are hidden; on clients that have those fonts everything stays available.
- A saved language that can't be displayed falls back to "Automatic"; /lp lang refuses it with a reason.
- Fixed: language buttons keep their own script font (e.g. "Русский" no longer turned into boxes).

## 3.5.2
- Fixed: no more language mix. Vendor, innkeeper and flight master names, enemy names in the safe mode
  warning, the navigation arrow, nameplate texts and time units (h/min) now follow the chosen language.
  Hint pop-ups in the old language are closed when you switch.
- Fixed: buttons shrink their font instead of cutting off long words (e.g. Russian "Automatic").
- Fixed: the status bar measures its real text height, so long status lines are no longer cut off.
- Fixed: Russian font has no middle dot "·" – it is replaced, no more empty boxes.
- New: if a language pack can't be loaded, LevelPilot says why (most often: WoW must be fully restarted
  once after new AddOn folders were added – /reload is not enough). /lp diag shows the language packs.

## 3.5.1
- Packaging: one single download (LevelPilot.zip) now contains the addon, the data package and all
  language packs. Extract everything into Interface/AddOns.

## 3.5.0
- New: quest, NPC, item, object and zone names follow the language you choose in LevelPilot – no longer
  the language of your game client. Translations come from QuestieDB (GPLv3) as language packs in the
  data package (LevelPilot Data 1.5.0: LevelPilot_Data_deDE, _frFR, _esES, _esMX, _ptBR, _ruRU, _koKR,
  _zhCN, _zhTW). Only the packs that are needed are loaded. English uses the names of the data package;
  Italian has no Questie translation and shows English names.
- Quest objectives from the quest log are shown in the chosen language as well ("Name: 3/7").
- In your game's own language, the titles the game shows are kept; quests not yet in your log no longer
  appear in English.
- Target macros keep the names the game knows, so targeting still works in any language.

## 3.4.5
- Fixed: switching the language now updates every label in the guide window and the control center
  immediately – no /reload needed – and switching back restores everything. Words that share one
  translation (e.g. German "Austausch" and "Teilen" are both "Compartir" in Spanish) no longer come
  back wrong. Steps, hints and data source info are rebuilt in the new language as well.

## 3.4.4
- Changed: vendors now get every grey item – weapons, armour and junk. Items whose data the game had
  not loaded yet (often weapons from earlier sessions) used to stay in the bags; they are now sold too.
  Only items needed for a running quest or that start a quest are kept. The chat message shows the
  real amount earned.

## 3.4.3
- Fixed: the guide window header no longer cuts off text. The zone name has its own line across the
  full width, the "Normal / Skip / Replan" buttons moved to a separate row, and the XP line wraps
  instead of being hidden behind the buttons.
- Fixed: the status bar grows with its text and keeps clear of the resize grip.
- Fixed: the replan button showed an empty box (the ↻ glyph is missing in the game fonts) – it now uses
  an arrow icon. Arrows "→" in texts were replaced by "»" for the same reason.

## 3.4.2
- New: **Support** button in the guide window's title bar (a coin icon when the window is narrow), a
  "Support the addon" line in Settings and `/lp donate` (also `/lp spenden`, `/lp support`). It shows the
  PayPal link to copy – it never opens on its own and never posts anything in chat.

## 3.4.1
- New: error log for testers. LevelPilot quietly notes Lua errors, wrongly detected zones, unknown
  position, planning in the wrong zone, missing paths, being stuck, very long steps, deaths, slow
  planning and login/logout. `/lp protokoll` shows it as text to copy; it stays on your computer and
  contains no names or login data. Can be switched off under Extras.

## 3.4.0
- New control center tab "Extras": quest item locations with arrow and alert, quest tooltips, automatic
  restocking of food/water/ammo/pet food, auto-equip of reward upgrades, gold per hour, best level times,
  time estimates, rested/hearthstone status, "where was I?" on login, turn-in reminders, logout summary,
  corpse arrow, class quest and trainer cost hints, mount gold planning, quest sharing, group finder
  text, elite partner search, compact mode and per-character settings.
- Fixed: corpse arrow position, gold per hour counting.
