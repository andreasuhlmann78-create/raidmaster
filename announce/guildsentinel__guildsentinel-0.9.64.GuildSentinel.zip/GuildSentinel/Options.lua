-- GuildSentinel – Optionen (OPT-ALLE, Entscheid des Nutzers 18.11.2026 10:27: "nach Vorbild AHSentinel")
-- Links die Bereiche (Themen), rechts nur die Optionen des gewählten Bereichs: EINE Spalte, höchstens 12 Zeilen, kein Scrollen.
-- Oben ein Suchfeld über alle Bereiche. Jede Zeile: kurze Beschriftung, rechts der Schalter, die Erklärung nur im Tooltip.
-- an/aus = ein Knopf ("an"/"aus"), Auswahl = Knopfreihe (lange Listen wie Sprache/Main: Auswahlfeld). Jede Option genau EINMAL;
-- Schalter, die bei ihrem eigenen Text stehen (Antwort, Begrüssung, Fragen …), bleiben dort – hier steht ein Verweis, der hinspringt.
-- Gespeichert wird unverändert in denselben Feldern wie vorher (ns.db.*, Funktionen, Marktnetz, Bank-Charakter): alte Spielstände
-- und alte Clients bleiben gültig. Zeilen werden erst gebaut, wenn sie zum ersten Mal sichtbar werden (Leistung, OPT (i)).
local ADDON, ns = ...
local L = ns.L
local N = ns.N
local UI = ns.UI

local O = {}
ns.Options = O

local GREEN, GRAY, GOLD = "|cff40d860", "|cff8a8f99", "|cffffd100"
local function Gray(t) return GRAY .. tostring(t) .. "|r" end

O.NAV_W, O.CONTENT_X, O.ROW_H, O.MAX_LINES = 170, 186, 30, 12
O.LABEL_W, O.CTRL_X = 250, 260
-- Breite einer Zeile: Inhalt des Hauptfensters (980 - Navigation 176 - Ränder 24 = 780) minus linke Bereichsleiste (186) minus Rand
O.ROW_W = 590

-- Bereiche (Reihenfolge = häufig gebraucht zuerst)
O.SECTIONS = {
	{ id = "allgemein", label = N["Allgemein"] },
	{ id = "chat", label = N["Chat & Tooltip"] },
	{ id = "ansagen", label = N["Ansagen"], long = N["Ansagen im Gildenchat"] },
	{ id = "gruppe", label = N["Gruppensuche"] },
	{ id = "rekrut", label = N["Rekrutierung"] },
	{ id = "daten", label = N["Daten & Abgleich"] },
	{ id = "funk1", label = N["Funktionen: Gemeinschaft"] },
	{ id = "funk2", label = N["Funktionen: Gilde & Raid"] },
	{ id = "leitung", label = N["Leitung"] },
}
-- Funktionen (ns.FEATURES) auf zwei Bereiche verteilt (je höchstens 12); eine neue Funktion ohne Eintrag landet in funk2
O.FEATURE_SEC = {
	home = "funk1", myweek = "funk1", group = "funk1", events = "funk1", board = "funk1", poll = "funk1",
	thanks = "funk1", ask = "funk1", where = "funk1", away = "funk1", times = "funk1", chronicle = "funk1",
	race = "funk2", attune = "funk2", goals = "funk2", prof = "funk2", cooldowns = "funk2", gear = "funk2",
	comp = "funk2", recruit = "funk2", mentor = "funk2", promo = "funk2", lead = "funk2", addons = "funk2",
}

------------------------------------------------------------
-- Zeilen (Definitionen; gebaut wird erst beim Zeigen)
-- kind: toggle | choice | dropdown | button | link | info
-- key = gespeichertes Feld (für die Bestandsliste und den Test), def = Standardwert (für den Knopf "Standard"), more = unter "Weitere"
------------------------------------------------------------
local function DB() return ns.db or {} end
local function Flag(field, defTrue)
	-- Felder mit Standard "an", die bisher mit "~= false" gelesen wurden, bleiben so (nil = an)
	if defTrue then return function() return DB()[field] ~= false end end
	return function() return DB()[field] and true or false end
end
local function SetFlag(field, after) return function(v) DB()[field] = v and true or false; if after then after(v) end end end

local ROWS = {}
O.ROWS = ROWS
local function Row(r) ROWS[#ROWS + 1] = r; return r end

-- Allgemein
Row({ id = "lang", sec = "allgemein", kind = "dropdown", label = N["Sprache"], key = "uiLang", w = 220, maxW = 326,
	-- die Sprache des Clients steht im Tooltip (mit Klammer passte "wie der Spiel-Client (Español (México))" bei Schrift 130 % nicht)
	tip = function()
		return L["Sprache von GuildSentinel. Ab Werk die des Spiel-Clients; nach dem Wechsel lädt GuildSentinel neu."]
			.. "\n" .. L["wie der Spiel-Client"] .. ": " .. ns.LangName(ns.ClientLang())
	end,
	items = function()
		local out = { { value = false, text = L["wie der Spiel-Client"] } }
		for _, x in ipairs(ns.LangChoices()) do out[#out + 1] = { value = x[1], text = x[2] } end
		return out
	end,
	get = function() return DB().uiLang or false end, set = function(v) ns.SetUiLang(v or nil) end })
Row({ id = "main", sec = "allgemein", kind = "dropdown", label = N["Mein Main"], key = "guild.myMain", w = 220, maxW = 326,
	tip = N["Alle deine Charaktere in dieser Gilde, mit denen du GuildSentinel geladen hast, werden als Twinks dieses Mains angezeigt – bei allen in der Gilde."],
	items = function()
		local out = { { value = false, text = Gray(L["nicht festgelegt"]) } }
		local list = {}
		for name in pairs((ns.G and ns.G().mine) or {}) do list[#list + 1] = name end
		table.sort(list)
		for _, n in ipairs(list) do out[#out + 1] = { value = n, text = ns.Colored(n, ns.G().mine[n].c) } end
		return out
	end,
	get = function() return (ns.G and ns.G().myMain) or false end, set = function(v) if v then ns.Roster:SetMyMain(v) end end })
Row({ id = "minimap", sec = "allgemein", kind = "toggle", label = N["Minimap-Knopf"], key = "minimapShow", def = true,
	tip = N["Knopf an der Minikarte: Linksklick öffnet GuildSentinel."],
	get = Flag("minimapShow"), set = SetFlag("minimapShow", function() UI:UpdateMinimap() end) })
Row({ id = "cmdhint", sec = "allgemein", kind = "toggle", label = N["Befehlsliste beim Tippen"], key = "cmdHint", def = true, more = true,
	tip = N["Beim Tippen von /gs im Chat erscheint eine Liste der Befehle."],
	get = Flag("cmdHint", true), set = SetFlag("cmdHint", function(v) if not v and ns.CmdHint then ns.CmdHint:Hide() end end) })
Row({ id = "donate", sec = "allgemein", kind = "button", label = N["Addon unterstützen"], more = true, action = true,
	text = N["Unterstützen"], tip = N["Öffnet das Fenster mit den Möglichkeiten, GuildSentinel zu unterstützen."],
	run = function() if ns.Donate and ns.Donate.Show then ns.Donate.Show() end end })

-- Chat & Tooltip
Row({ id = "tooltip", sec = "chat", kind = "toggle", label = N["Infos im Spieler-Tooltip"], key = "tooltip", def = true,
	tip = N["Rang, Main und Berufe im Tooltip eines Gildenmitglieds."],
	get = Flag("tooltip"), set = SetFlag("tooltip") })
Row({ id = "chatmain", sec = "chat", kind = "toggle", label = N["Main hinter Twinks (Chat)"], key = "chatMain", def = true,
	tip = N["Im Gildenchat steht hinter dem Namen eines Twinks der Name seines Mains."],
	get = Flag("chatMain"), set = SetFlag("chatMain") })
Row({ id = "onlinemain", sec = "chat", kind = "toggle", label = N["'ist online' mit Main"], key = "onlineMain", def = true,
	tip = N["Bei der Meldung 'ist online' steht der Main dabei."],
	get = Flag("onlineMain"), set = SetFlag("onlineMain") })
Row({ id = "rulespopup", sec = "chat", kind = "toggle", label = N["Neue Gildenregeln zeigen"], key = "rulesPopup", def = true,
	tip = N["Neue Gildenregeln beim Einloggen zeigen"],
	get = Flag("rulesPopup"), set = SetFlag("rulesPopup") })

-- Ansagen im Gildenchat
local ANN_TIP = N["Haben mehrere das Addon, sagt nur einer an. Twinks werden nicht angesagt."]
Row({ id = "annlevels", sec = "ansagen", kind = "toggle", label = N["Stufen-Meilensteine"], key = "annLevels", def = true,
	tip = function() return string.format(L["Stufen %s"], table.concat(ns.Game.MILESTONES, ", ")) .. "\n" .. L[ANN_TIP] end,
	get = Flag("annLevels"), set = SetFlag("annLevels") })
Row({ id = "annfirst", sec = "ansagen", kind = "toggle", label = N["Erster auf Höchststufe"], key = "annFirst", def = true,
	tip = function() return string.format(L["Erstes Gildenmitglied auf Stufe %d"], ns.Roster.MAX_LEVEL) .. "\n" .. L[ANN_TIP] end,
	get = Flag("annFirst"), set = SetFlag("annFirst") })
Row({ id = "annjubilee", sec = "ansagen", kind = "toggle", label = N["Jubiläen"], key = "annJubilee", def = true,
	tip = function() return L["Jubiläen (1, 3, 6 Monate, 1 und 2 Jahre)"] .. "\n" .. L[ANN_TIP] end,
	get = Flag("annJubilee"), set = SetFlag("annJubilee") })
Row({ id = "annmiles", sec = "ansagen", kind = "toggle", label = N["Wochenziel und Meilensteine"], key = "annMiles+annGoal", def = true,
	tip = function() return L["Wochenziel und Gilden-Meilensteine"] .. "\n" .. L[ANN_TIP] end,
	get = Flag("annMiles"), set = function(v) DB().annMiles = v and true or false; DB().annGoal = v and true or false end })
Row({ id = "annreview", sec = "ansagen", kind = "toggle", label = N["Wochenrückblick"], key = "annReview", def = true,
	tip = function() return L["Wochenrückblick (nach dem Reset am Mittwoch)"] .. "\n" .. L[ANN_TIP] end,
	get = Flag("annReview", true), set = SetFlag("annReview") })
Row({ id = "annraid", sec = "ansagen", kind = "toggle", label = N["Gilde ist raidfähig"], key = "annRaidReady", def = true,
	tip = function() return L["Gilde ist raidfähig (Ziel-Raid)"] .. "\n" .. L[ANN_TIP] end,
	get = Flag("annRaidReady", true), set = SetFlag("annRaidReady") })

-- Gruppensuche
Row({ id = "lfgnotify", sec = "gruppe", kind = "toggle", label = N["Hinweis bei passender Suche"], key = "lfgNotify", def = true,
	tip = N["Hinweis, wenn eine passende Suche kommt"],
	get = Flag("lfgNotify"), set = SetFlag("lfgNotify") })
Row({ id = "lfgsound", sec = "gruppe", kind = "toggle", label = N["Hinweis mit Ton"], key = "lfgSound", def = true,
	tip = N["Der Hinweis auf eine passende Suche kommt mit Ton."],
	get = Flag("lfgSound"), set = SetFlag("lfgSound") })
Row({ id = "role", sec = "gruppe", kind = "link", label = N["Meine Rolle"], key = "Gruppe: Rolle",
	tip = N["Deine Rolle für die Gruppensuche wählst du direkt bei der Suche (Gruppensuche > Suchen)."],
	open = { "group", "search" } })

-- Rekrutierung
Row({ id = "adremind", sec = "rekrut", kind = "toggle", label = N["Werbung: erinnern"], key = "adRemind", def = true,
	tip = N["Erinnern, wenn die Werbung wieder fällig ist – alle"],
	get = Flag("adRemind"), set = SetFlag("adRemind") })
Row({ id = "adinterval", sec = "rekrut", kind = "choice", label = N["Erinnern alle (Minuten)"], key = "adInterval", def = 15,
	tip = N["Wie lange nach dem letzten Werben die Erinnerung kommt."],
	choices = { 10, 15, 20, 30, 45, 60 }, choiceText = function(v) return tostring(v) end,
	get = function() return DB().adInterval or 15 end, set = function(v) DB().adInterval = v end })
Row({ id = "appspurge", sec = "rekrut", kind = "toggle", label = N["Alte Bewerbungen löschen"], key = "appsPurge", def = true,
	tip = N["Beigetreten, abgelehnt oder abgelehnt wegen Alter: 90 Tage nach der letzten Nachricht werden sie beim Einloggen gelöscht. Offene Bewerbungen bleiben immer."],
	get = Flag("appsPurge", true), set = SetFlag("appsPurge") })
Row({ id = "adchannels", sec = "rekrut", kind = "link", label = N["Werbe-Kanäle"], key = "adTargets",
	tip = N["In welchen Kanälen geworben wird, wählst du bei der Werbung."], open = { "recruit", "ad" } })
Row({ id = "autoreply", sec = "rekrut", kind = "link", label = N["Automatische Antwort"], key = "autoReply",
	tip = N["Ein- und ausschalten bei ihrem Text (Rekrutierung > Antworten & Begrüßung)."], open = { "recruit", "texts" } })
Row({ id = "welcome", sec = "rekrut", kind = "link", label = N["Begrüssung neuer Mitglieder"], key = "welcome",
	tip = N["Ein- und ausschalten bei ihrem Text (Rekrutierung > Antworten & Begrüßung)."], open = { "recruit", "texts" } })
Row({ id = "askquestions", sec = "rekrut", kind = "link", label = N["Bewerbungsfragen"], key = "askQuestions",
	tip = N["Ein- und ausschalten bei ihrem Text (Rekrutierung > Antworten & Begrüßung)."], open = { "recruit", "texts" } })
Row({ id = "minage", sec = "rekrut", kind = "link", label = N["Mindestalter"], key = "minAge",
	tip = N["Ein- und ausschalten bei ihrem Text (Rekrutierung > Antworten & Begrüßung)."], open = { "recruit", "texts" } })

-- Daten & Abgleich
Row({ id = "market", sec = "daten", kind = "toggle", label = N["Marktdaten teilen"], key = "GoldSentinelMarkt (GuildSentinel)", def = true,
	tip = function()
		local _, why = ns.MarketShareState()
		return L["Marktdaten teilen (anonym, nur Preise)"] .. (why and ("\n" .. why) or "")
	end,
	get = function() local on = ns.MarketShareState() return on end,
	set = function(v)
		local GM = _G.GoldSentinelMarkt
		if GM and GM.SetShare then GM.SetShare("GuildSentinel", v and true or false) end
	end })
Row({ id = "bank", sec = "daten", kind = "toggle", label = N["Bank-Charakter"], key = "bankChars[Charakter]", def = false,
	tip = N["Bank-Charakter (Bestand an Discord)"],
	get = function() return ns.Bank and ns.Bank.IsBankChar() and true or false end,
	set = function(v) if ns.Bank then ns.Bank.SetBankChar(v and true or false) end end })
Row({ id = "sync", sec = "daten", kind = "button", label = N["Abgleich in der Gilde"], action = true, text = N["Jetzt abgleichen"],
	tip = function() return O.UsersText() end,
	run = function() ns.Sync:Request(); ns:Print(L["Abgleich angefragt."]) end })
Row({ id = "raidmaster", sec = "daten", kind = "info", label = N["RaidMaster"], action = true,
	tip = function() return O.RaidMasterText(true) end, info = function() return O.RaidMasterText(false) end })

-- Leitung (Schalter bei ihrem Inhalt)
Row({ id = "altrank", sec = "leitung", kind = "link", label = N["Twinks: Rang des Mains"], key = "altRank",
	tip = N["Twinks bekommen den Rang ihres Mains vorgeschlagen"], open = { "members", "promo" } })
Row({ id = "compalts", sec = "leitung", kind = "link", label = N["Aufstellung: Twinks zählen"], key = "guild.comp.alts",
	tip = N["Twinks mitzählen"], open = { "members", "comp" } })
Row({ id = "adminbtn", sec = "leitung", kind = "link", label = N["Verwaltungsknopf"], key = "admin.showButton",
	tip = N["Verwaltungsknopf auf der Gildenseite"], run = function() if ns.Admin and ns.Admin.Open then ns.Admin:Open() end end })

-- Funktionen (aus ns.FEATURES, Reihenfolge wie dort)
for _, f in ipairs(ns.FEATURES or {}) do
	local key = f.key
	Row({ id = "feat_" .. key, sec = O.FEATURE_SEC[key] or "funk2", kind = "toggle", label = f.n, key = "features." .. key, def = true,
		feature = key, tip = function() return L[f.d] .. "\n" .. L["Was aus ist, verschwindet aus dem Fenster, sendet nichts mehr und nimmt nichts an. Die Einstellung gilt für dich (alle deine Charaktere)."] end, get = function() return ns.Feature(key) end, set = function(v) ns.SetFeature(key, v and true or false) end })
end

-- Reihenfolge innerhalb der Bereiche = Reihenfolge oben
for i, r in ipairs(ROWS) do r.order = i end

------------------------------------------------------------
-- Texte für Info-Zeilen
------------------------------------------------------------
function O.UsersText()
	local lines = { L["Abgleich in der Gilde"] }
	local list = {}
	for name, u in pairs((ns.Comm and ns.Comm.users) or {}) do list[#list + 1] = { name = name, v = u.v } end
	table.sort(list, function(a, b) return a.name < b.name end)
	for i, u in ipairs(list) do
		if i > 8 then lines[#lines + 1] = string.format(L["… und %d weitere"], #list - 8) break end
		local r = ns.RosterEntry(u.name)
		lines[#lines + 1] = ns.Colored(u.name, r and r.c) .. Gray(" v" .. tostring(u.v or "?"))
	end
	if #list == 0 then lines[#lines + 1] = L["Gerade niemand sonst mit GuildSentinel online."] end
	if ns.Comm and ns.Comm.Peers then
		lines[#lines + 1] = string.format(L["Mitspieler mit GuildSentinel (letzte Stunde): %d"], ns.Comm:Peers(3600))
	end
	local best, newer = ns.Comm and ns.Comm.NewestVersion and ns.Comm:NewestVersion()
	if newer then lines[#lines + 1] = GOLD .. string.format(L["Neue Version %s verfügbar!"], best) .. "|r" end
	return table.concat(lines, "\n")
end

function O.RaidMasterText(long)
	if ns.Test and ns.Test.Active and ns.Test:Active() then
		return long and L["Testmodus: Daten aus RaidMaster werden gerade nicht verwendet (die Testgilde ist erfunden)."] or Gray(L["Testmodus"])
	end
	if ns.RMI and ns.RMI:Active() then
		if long then
			return string.format(L["RaidMaster %s erkannt."], tostring(ns.RMI:Version() or "")) .. "\n"
				.. L["Berufe und Twinks kommen auch aus RaidMaster. Deine Berufe schickt GuildSentinel selbst. Twinks, die ein Offizier hier festlegt, landen auch in RaidMaster."]
		end
		return GREEN .. string.format(L["RaidMaster %s erkannt."], tostring(ns.RMI:Version() or "")) .. "|r"
	end
	if long then return L["RaidMaster ist nicht installiert. GuildSentinel liest und teilt Berufe und Twinks selbst."] end
	return Gray(L["nicht installiert"])
end

------------------------------------------------------------
-- Hilfen
------------------------------------------------------------
local function Text(x) if type(x) == "function" then return x() end return x and L[x] or "" end
function O.RowLabel(r) return L[r.label] end
function O.RowTip(r) return Text(r.tip) end
function O.SectionOf(id) for _, s in ipairs(O.SECTIONS) do if s.id == id then return s end end end
function O.RowsOf(sec)
	local out = {}
	for _, r in ipairs(ROWS) do if r.sec == sec then out[#out + 1] = r end end
	return out
end
-- Bereich einer Funktion (für "Diese Funktion ist ausgeschaltet" und den Aufruf aus anderen Seiten)
function O.SectionOfFeature(key) return O.FEATURE_SEC[key] or "funk2" end

-- Suchtext einer Zeile: Beschriftung, Erklärung, Bereich (klein geschrieben)
local function Lower(s) return string.lower(tostring(s or "")) end
function O.Matches(r, q)
	if q == "" then return true end
	local ok, tip = pcall(O.RowTip, r)
	local s = Lower(O.RowLabel(r)) .. " " .. Lower(ok and tip or "") .. " " .. Lower(L[O.SectionOf(r.sec).label])
	return s:find(q, 1, true) ~= nil
end

------------------------------------------------------------
-- Bau
------------------------------------------------------------
local function OnOff(b, on)
	b:SetText(on and (GREEN .. L["an"] .. "|r") or Gray(L["aus"]))
end

-- Beschriftung auf höchstens zwei Zeilen einpassen (lange Sprachen: kleinere Schrift statt abschneiden)
local function FitLabel(fs, text)
	fs:SetFontObject(GameFontHighlight)
	fs:SetText(text)
	local sw = fs:GetStringWidth()
	if type(sw) == "number" and not ns.IsSecret(sw) and sw > O.LABEL_W then fs:SetFontObject(GameFontHighlightSmall) end
end

-- Bereichs-Knopf: zu langer Name (andere Sprachen) erst kleiner, dann auf zwei Zeilen – nie abgeschnitten
function O.FitNav(b)
	local t = b.text
	local avail = (b:GetWidth() or O.NAV_W) - 16
	t:SetFontObject(GameFontHighlight)
	t:SetWordWrap(false)
	if t.SetMaxLines then t:SetMaxLines(1) end
	local sw = t:GetStringWidth()
	if type(sw) ~= "number" or ns.IsSecret(sw) or sw <= avail then return end
	t:SetFontObject(GameFontHighlightSmall)
	sw = t:GetStringWidth()
	if type(sw) == "number" and not ns.IsSecret(sw) and sw > avail then
		t:SetWordWrap(true)
		if t.SetMaxLines then t:SetMaxLines(2) end
	end
end

-- eine Zeile bauen (einmal; danach nur Refresh)
function O:BuildRow(r)
	if r.f then return r.f end
	local w = self.root
	local f = CreateFrame("Frame", nil, w)
	f:SetSize(O.ROW_W, O.ROW_H - 2)
	f:Hide()
	f:EnableMouse(true)
	local l = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	l:SetPoint("LEFT", 0, 0)
	l:SetWidth(O.LABEL_W)
	l:SetJustifyH("LEFT")
	if l.SetMaxLines then l:SetMaxLines(2) end
	l:SetWordWrap(true)
	f.label = l
	local function Tip(owner)
		UI.TipOwner(owner, "ANCHOR_RIGHT")
		GameTooltip:AddLine(O.RowLabel(r), 1, 1, 1)
		local t = O.RowTip(r)
		if t and t ~= "" then GameTooltip:AddLine(t, 0.8, 0.8, 0.8, true) end
		if r.kind == "link" then GameTooltip:AddLine(L["Klick: dorthin wechseln"], 0.4, 0.85, 1, true) end
		GameTooltip:Show()
	end
	f:SetScript("OnEnter", function(self) Tip(self) end)
	f:SetScript("OnLeave", function() GameTooltip:Hide() end)
	local c
	if r.kind == "toggle" then
		c = UI:Button(f, "", 70, 22, function()
			r.set(not r.get())
			O:Refresh()
		end)
		c.Refresh = function() OnOff(c, r.get()) end
	elseif r.kind == "choice" then
		c = CreateFrame("Frame", nil, f)
		c:SetSize(10, 22)
		c.btns = {}
		local x = 0
		for i, v in ipairs(r.choices) do
			local b = UI:Button(c, r.choiceText(v), 42, 22, function() r.set(v); O:Refresh() end)
			b:SetPoint("LEFT", x, 0)
			x = x + 46
			b.value = v
			c.btns[i] = b
			b:HookScript("OnEnter", function(self) Tip(self) end)
			b:HookScript("OnLeave", function() GameTooltip:Hide() end)
		end
		c:SetWidth(x)
		c.Refresh = function()
			local cur = r.get()
			for _, b in ipairs(c.btns) do
				local t = r.choiceText(b.value)
				b:SetText(b.value == cur and (GREEN .. "● " .. t .. "|r") or t)
			end
		end
	elseif r.kind == "dropdown" then
		c = UI:Dropdown(f, r.w or 200, r.items, r.get, function(v) r.set(v); O:Refresh() end)
		c.maxW = r.maxW
		if r.id == "lang" and ns.SettingsPage then ns.SettingsPage.langDD = c end
		if r.id == "main" and ns.SettingsPage then ns.SettingsPage.mainDD = c end
	elseif r.kind == "button" then
		c = UI:Button(f, L[r.text], 150, 22, function() r.run() end)
		c.Refresh = function() end
	elseif r.kind == "link" then
		c = UI:Button(f, L["Öffnen"] .. " >", 110, 22, function()
			if r.run then r.run() return end
			UI:Open(r.open[1], r.open[2])
		end)
		c.Refresh = function() end
	elseif r.kind == "info" then
		c = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		c:SetWidth(300)
		c:SetJustifyH("LEFT")
		c:SetWordWrap(false)
		c.Refresh = function() c:SetText(r.info()) end
	end
	c:SetPoint("LEFT", f, "LEFT", O.CTRL_X, 0)
	if c.HookScript and r.kind ~= "choice" then
		c:HookScript("OnEnter", function(self) Tip(self) end)
		c:HookScript("OnLeave", function() GameTooltip:Hide() end)
	end
	f.ctrl = c
	r.f = f
	O.builtRows = O.builtRows + 1
	FitLabel(l, O.RowLabel(r))
	return f
end

function O:Build(root)
	self.root = root
	self.sec = self.sec or "allgemein"
	self.more = {}
	-- links: Bereiche
	self.nav = {}
	for i, s in ipairs(O.SECTIONS) do
		local b = UI:Button(root, "", O.NAV_W - 6, 26, function()
			self.sec = s.id
			if self.search then self.search:SetText(""); self.search:ClearFocus() end
			self:Layout()
		end)
		b:SetPoint("TOPLEFT", 0, -(i - 1) * 30)
		b.text:SetPoint("LEFT", 10, 0)
		b.text:SetPoint("RIGHT", -6, 0)
		b.text:SetJustifyH("LEFT")
		b.text:SetWordWrap(false)
		b.secId = s.id
		b:HookScript("OnEnter", function(self2)
			UI.TipOwner(self2, "ANCHOR_RIGHT")
			GameTooltip:AddLine(L[s.long or s.label], 1, 1, 1)
			GameTooltip:Show()
		end)
		b:HookScript("OnLeave", function() GameTooltip:Hide() end)
		self.nav[i] = b
	end
	-- oben: Suche über alle Bereiche
	self.search = UI:Edit(root, 260, 24, L["Suchen (z. B. Ton, Ansage, Tooltip)"])
	self.search:SetPoint("TOPLEFT", O.CONTENT_X, 0)
	self.search.onChange = function() O:Layout() end
	self.searchInfo = root:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	self.searchInfo:SetPoint("LEFT", self.search, "RIGHT", 10, 0)
	self.searchInfo:SetWidth(300)
	self.searchInfo:SetJustifyH("LEFT")
	-- Überschriften (Bereichsname bei Suchtreffern) und "Weitere"
	self.headers = {}
	self.moreBtn = UI:Button(root, "", 160, 22, function()
		self.more[self.sec] = not self.more[self.sec]
		self:Layout()
	end)
	self.moreBtn:Hide()
	-- unten: Standard für den Bereich
	self.stdBtn = UI:Button(root, L["Standard"], 120, 24, function()
		local sec = O.SectionOf(self.sec)
		UI:Confirm(string.format(L["Alle Optionen im Bereich '%s' auf Standard setzen?"], L[sec.label]), function() O:Defaults(self.sec) end)
	end)
	self.stdBtn:SetPoint("TOPLEFT", O.CONTENT_X, -(32 + O.MAX_LINES * O.ROW_H + 10))
	UI.Tip(self.stdBtn, L["Standard"], L["Setzt die Optionen dieses Bereichs auf die Werte ab Werk."])
	self.hint = root:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	self.hint:SetPoint("LEFT", self.stdBtn, "RIGHT", 12, 0)
	self.hint:SetWidth(440)
	self.hint:SetJustifyH("LEFT")
	self.hint:SetText(Gray(L["- Befehle: /gs, /gs gruppe, /gs termine, /gs brett, /gs wo, /gs umfrage, /gs danke <Name>, /gs weg <Tage>, /gs spenden"]))
end

local function Header(self, i)
	local h = self.headers[i]
	if not h then
		h = self.root:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
		h:SetWidth(O.LABEL_W + 300)
		h:SetJustifyH("LEFT")
		self.headers[i] = h
	end
	return h
end

-- Optionen sichtbar? (Zeilen von Funktionen, die es in dieser Version nicht gibt, gibt es nicht: alle FEATURES sind überall)
local function Visible(r) return true end

-- Leistung (OPT (i)): Zeit eines Aufbaus mit neu gebauten Zeilen; längster Wert für den Bericht der Testroutine
O.buildMs, O.builtRows = 0, 0
local function Ms() return debugprofilestop and debugprofilestop() or 0 end

function O:Layout()
	if not self.root then return end
	local t0, built0 = Ms(), O.builtRows
	local q = Lower((self.search and self.search:GetText() or ""):gsub("^%s+", ""):gsub("%s+$", ""))
	for _, r in ipairs(ROWS) do if r.f then r.f:Hide() end end
	for _, h in ipairs(self.headers) do h:Hide() end
	self.moreBtn:Hide()
	local y, lines, shown, hits = -32, 0, {}, {}
	local function Place(r)
		local f = self:BuildRow(r)
		f:ClearAllPoints()
		f:SetPoint("TOPLEFT", self.root, "TOPLEFT", O.CONTENT_X, y)
		f:Show()
		y, lines = y - O.ROW_H, lines + 1
		shown[#shown + 1] = r
	end
	local cut = 0
	if q == "" then
		local list, extra = {}, {}
		for _, r in ipairs(ROWS) do
			if r.sec == self.sec and Visible(r) then
				if r.more then extra[#extra + 1] = r else list[#list + 1] = r end
			end
		end
		for _, r in ipairs(list) do if lines < O.MAX_LINES then Place(r) else cut = cut + 1 end end
		if #extra > 0 then
			local open = self.more[self.sec]
			self.moreBtn:SetText((open and "v " or "> ") .. string.format(L["Weitere (%d)"], #extra))
			self.moreBtn:ClearAllPoints()
			self.moreBtn:SetPoint("TOPLEFT", self.root, "TOPLEFT", O.CONTENT_X, y - 2)
			self.moreBtn:Show()
			y, lines = y - O.ROW_H, lines + 1
			if open then for _, r in ipairs(extra) do if lines < O.MAX_LINES then Place(r) else cut = cut + 1 end end end
		end
		self.searchInfo:SetText("")
		self.stdBtn:Show()
	else
		local nh, total = 0, 0
		for _, s in ipairs(O.SECTIONS) do
			local list = {}
			for _, r in ipairs(ROWS) do if r.sec == s.id and Visible(r) and O.Matches(r, q) then list[#list + 1] = r end end
			hits[s.id] = #list
			total = total + #list
			if #list > 0 then
				if lines < O.MAX_LINES - 1 then
					nh = nh + 1
					local h = Header(self, nh)
					h:ClearAllPoints()
					h:SetPoint("TOPLEFT", self.root, "TOPLEFT", O.CONTENT_X, y - 6)
					h:SetText(L[s.label])
					h:Show()
					y, lines = y - 22, lines + 0.75
					for _, r in ipairs(list) do if lines < O.MAX_LINES then Place(r) else cut = cut + 1 end end
				else
					cut = cut + #list
				end
			end
		end
		local info = total == 0 and L["Nichts gefunden."] or string.format(L["%d Treffer"], total)
		if cut > 0 then info = info .. " · " .. string.format(L["%d weitere – genauer suchen"], cut) end
		self.searchInfo:SetText(info)
		self.stdBtn:Hide()
	end
	for _, b in ipairs(self.nav) do
		local s = O.SectionOf(b.secId)
		local active = q == "" and b.secId == self.sec
		local n = hits[b.secId]
		b:SetText((active and (GOLD .. "> ") or "") .. L[s.label] .. ((q ~= "" and n and n > 0) and (" (" .. n .. ")") or "") .. (active and "|r" or ""))
		O.FitNav(b)
	end
	self.shown, self.cut = shown, cut
	self:Refresh()
	if O.builtRows > built0 then
		local dt = Ms() - t0
		if dt > O.buildMs then O.buildMs = dt end
	end
end

function O:Refresh()
	for _, r in ipairs(self.shown or {}) do
		if r.f and r.f.ctrl and r.f.ctrl.Refresh then pcall(r.f.ctrl.Refresh) end
	end
end

-- Bereich öffnen (aus anderen Seiten: ns.UI:Open("settings", "opt:<bereich>") bzw. "feat:<funktion>")
function O:ShowSection(id)
	if not O.SectionOf(id) then id = "allgemein" end
	self.sec = id
	if self.search then self.search:SetText(""); self.search:ClearFocus() end
	self:Layout()
end

-- Standard je Bereich: nur Zeilen mit Standardwert (Sprache, Main, Verweise und Knöpfe bleiben)
function O:Defaults(sec)
	local n = 0
	for _, r in ipairs(ROWS) do
		if r.sec == sec and r.def ~= nil and r.set then r.set(r.def); n = n + 1 end
	end
	self:Layout()
	return n
end

-- kleiner Knopf "Optionen" für andere Seiten (OPT (e)): öffnet den passenden Bereich
function O.Button(parent, sec)
	local b = UI:Button(parent, L["Optionen"], 90, 22, function() UI:Open("settings", "opt:" .. sec) end)
	local s = O.SectionOf(sec)
	UI.Tip(b, L["Optionen"], s and L[s.label] or nil)
	return b
end

------------------------------------------------------------
-- Einstellungsfenster des Spiels (Hinweis "Spieler ohne Testbefehle", Entscheid 18.11. 11:10; OPT (e)): kleine Seite mit
-- Titel und Knopf, der die Optionen von GuildSentinel öffnet. Moderne Clients: Settings-API; alte: InterfaceOptions.
------------------------------------------------------------
function O.BuildGamePanel()
	if O.gamePanel then return O.gamePanel end
	local p = CreateFrame("Frame")
	p.name = "GuildSentinel"
	local title = p:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 16, -16)
	title:SetText("GuildSentinel " .. tostring(ns.version or ""))
	local btn = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
	btn:SetSize(200, 24)
	btn:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -12)
	btn:SetText(L["Optionen öffnen"])
	btn:SetScript("OnClick", function()
		if HideUIPanel then
			if SettingsPanel and SettingsPanel.IsShown and SettingsPanel:IsShown() then HideUIPanel(SettingsPanel) end
			if InterfaceOptionsFrame and InterfaceOptionsFrame.IsShown and InterfaceOptionsFrame:IsShown() then HideUIPanel(InterfaceOptionsFrame) end
		end
		UI:Open("settings", "gen")
	end)
	p.openBtn = btn
	local hint = p:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
	hint:SetPoint("TOPLEFT", btn, "BOTTOMLEFT", 0, -10)
	hint:SetWidth(520)
	hint:SetJustifyH("LEFT")
	hint:SetText(L["Auch: /gs optionen oder im Fenster von GuildSentinel links „Einstellungen“."])
	local ok = pcall(function()
		if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
			local cat = Settings.RegisterCanvasLayoutCategory(p, "GuildSentinel")
			Settings.RegisterAddOnCategory(cat)
			O.gameCategory = cat
		elseif InterfaceOptions_AddCategory then
			InterfaceOptions_AddCategory(p)
		end
	end)
	O.gamePanelOk = ok
	O.gamePanel = p
	return p
end
ns:On("PLAYER_LOGIN", function() O.BuildGamePanel() end)
