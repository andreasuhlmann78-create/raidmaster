-- GuildSentinel - Pruefliste.lua
-- Prüfliste im Spiel (Entscheid des Nutzers 16.11.2026 06:47, Auftrag der Prüf-Sitzung 06:49): die offenen Punkte
-- "IM CLIENT PRÜFEN" als Liste, die selbst merkt, was erledigt ist. Nur im Entwicklermodus (GoldSentinelDev);
-- sonst gibt der gemeinsame Baustein eine leere Liste zurück (Spieler sehen nichts, keine Kosten).
-- Befehl: /gs prüfliste (auch /gs pruefliste). Reihenfolge = wie man sie im Spiel am besten nacheinander macht.
-- Erledigt wird ein Punkt über ns.PLHit("ID", "Messwert") an der Stelle, wo die Funktion wirklich benutzt wurde,
-- über auto() bei Messbarem, sonst mit OK / Nicht OK.

local ADDON, ns = ...
-- Texte bewusst nur Deutsch: die Prüfliste sieht nur der Entwickler (Entwicklermodus), wie der Baustein selbst.

local function AllPagesBuilt()  -- (nicht mehr als Automatik genutzt: SEITEN ist eine Sichtprüfung)
	local UI = ns.UI
	if not UI or not UI.frame then return nil end
	local built, on = 0, 0
	for i, p in ipairs(UI.pages) do
		if UI:PageOn(p) then
			on = on + 1
			if UI.panels[i] and UI.panels[i].built then built = built + 1 end
		end
	end
	if built == on then return true, string.format("%d von %d Seiten", built, on) end
	return nil
end

-- TR-ALLE (Entscheid 17.11. 07:36): alles Automatische macht "/gs testroutine alles". Hier bleiben nur Punkte, die eine
-- echte Hand oder einen Blick brauchen. Jeder Punkt: Wo / nummerierte Schritte (ein Handgriff je Schritt, Namen wie im
-- Spiel) / was du siehst (wörtlich) / was es kostet. Danach hakt sich der Punkt selbst ab oder du klickst OK / Nicht OK.
ns.PL_POINTS = {
	{ id = "TESTROUTINE", since = "0.9.51", title = "Alles Automatische auf einmal",
		todo = "Wo: irgendwo, nicht im Kampf.\n  1. Tippe in den Chat: /gs testroutine alles  (Enter)\n  2. Warte, bis im Chat „Zusammenfassung: …“ steht. Nichts anklicken.\n  (Abbrechen geht jederzeit mit: /gs testroutine stop)",
		expect = "Im Chat nacheinander „Testroutine: Bereich 1 von 11 …“ bis „11 von 11“, dann „Zusammenfassung: … bestanden …“ und „echte Daten unverändert: OK“. Der Punkt hakt sich selbst ab.\nKosten: kein Gold, ca. 1 Minute." },
	{ id = "SEITEN", since = "0.9.51", title = "Alle Seiten ansehen",
		todo = "Wo: irgendwo.\n  1. Tippe in den Chat: /gs  (Enter) – das Fenster GuildSentinel öffnet sich.\n  2. Klicke links nacheinander jeden Eintrag einmal an (Übersicht, Mitglieder, Rekrutierung …).\n  3. Schau dir jede Seite kurz an.",
		expect = "Auf jeder Seite Text, Listen oder Knöpfe – keine leere Seite, nichts überlappt, kein Text abgeschnitten. Dann hier „OK“ (sonst „Nicht OK“ und in die Zeile schreiben, welche Seite).\nKosten: kein Gold, ca. 2 Minuten." },
	{ id = "OPT", since = "0.9.57", title = "Optionen am Bild",
		todo = "Wo: irgendwo.\n  1. Tippe: /gs  (Enter) und klicke links auf „Einstellungen“ – oben steht der Reiter „Optionen“.\n  2. Klicke links nacheinander jeden Bereich an (Allgemein, Chat & Tooltip, Ansagen … Leitung).\n  3. Tippe oben ins Suchfeld: ton\n  4. Klicke bei „Hinweis mit Ton“ auf den Knopf „an“/„aus“ und gleich nochmals.",
		expect = "Links die Bereiche, rechts nur die Optionen des gewählten Bereichs in EINER Spalte, ohne Scrollen, nichts überlappt oder ist abgeschnitten. Jede Zeile: kurze Beschriftung, rechts der Knopf; die Erklärung steht im Tooltip. Bei „ton“ erscheinen die Treffer mit Bereichsname. Der Knopf wechselt zwischen „an“ und „aus“. Dann hier „OK“ (sonst „Nicht OK“ und in die Zeile schreiben, was nicht passt).\nKosten: kein Gold, ca. 2 Minuten." },
	{ id = "GSW2", since = "0.9.39", title = "Werbetext-Vorschlag wählen",
		todo = "Wo: irgendwo.\n  1. Tippe: /gs werbung  (Enter) – die Seite Rekrutierung, Reiter „Werbung“ öffnet sich.\n  2. Klicke auf den Knopf „Vorschlag wählen“.\n  3. Klicke in der Liste auf einen Eintrag, z. B. „Kurz und knapp“.",
		expect = "Die Liste zeigt hinter jedem Vorschlag „… Zeichen“. Nach dem Klick steht der Text im Feld und endet mit „– flüstert mir: /w <dein Name> gilde“. Der Punkt hakt sich selbst ab.\nKosten: kein Gold, unter 1 Minute." },
	{ id = "GSW1", since = "0.9.39", title = "Flüster-Teil anhängen",
		todo = "Wo: Rekrutierung, Reiter „Werbung“ (wie vorher).\n  1. Klicke ins Textfeld und lösche den Text.\n  2. Schreibe: Wir suchen Mitspieler\n  3. Klicke auf den Knopf „Übernehmen“ (unter dem gelben Hinweis).",
		expect = "Vor dem Klick gelber Hinweis „Dein Text sagt nicht, wie man sich meldet – „/w {name} gilde“ anhängen?“. Danach steht „– flüstert mir: /w <dein Name> gilde“ am Ende. Der Punkt hakt sich selbst ab.\nKosten: kein Gold, unter 1 Minute." },
	{ id = "WERBUNG", since = "0.9.29", title = "Werbung wirklich posten",
		todo = "Wo: in einer Hauptstadt (dort gibt es den Kanal „Handel“).\n  1. Rekrutierung, Reiter „Werbung“: Klicke auf „Werbung vorbereiten“.\n  2. Im Chat-Eingabefeld steht jetzt der Text. Drücke Enter.",
		expect = "Dein Text erscheint im Kanal. KEIN Fenster „Aktion blockiert“. Auf der Seite steht danach „Zuletzt gepostet: …“ mit „gerade eben“ oder wenigen Sekunden. Der Punkt hakt sich selbst ab.\nKosten: kein Gold, unter 1 Minute (die Werbung ist echt im Kanal)." },
	-- MENU (Rechtsklick-Menü) entfernt in 0.9.57: im Spiel erledigt (auto 17.11. 16:48); Platz für OPT (höchstens 14 Punkte)
	{ id = "RANG", since = "0.9.33", title = "Befördern über „Gilden-Aktion“",
		todo = "Wo: irgendwo, nicht im Kampf. Du brauchst einen eigenen Twink in der Gilde.\n  1. /gs, links „Mitglieder“: Rechtsklick auf deinen Twink.\n  2. Klicke im Menü auf „Befördern“.\n  3. Im Fenster „Gilden-Aktion“: klicke einmal auf den grossen Knopf.\n  4. Danach genauso „Degradieren“, damit der Twink wieder seinen alten Rang hat.",
		expect = "Kein Fenster „Aktion blockiert“. Der Rang ändert sich genau um eine Stufe, das Fenster zeigt „Erledigt: Befördern <Name>“. Der Punkt hakt sich selbst ab.\nKosten: kein Gold, ca. 1 Minute." },
	{ id = "EINLADEN", since = "0.9.29", title = "Bewerber einladen",
		todo = "Wo: irgendwo. Du brauchst einen Zweitcharakter, der NICHT in der Gilde ist und dir „gilde“ geflüstert hat.\n  1. /gs, links „Rekrutierung“, oben Reiter „Bewerber“: klicke den Bewerber an.\n  2. Klicke auf „In die Gilde einladen“.\n  3. Im Chat-Eingabefeld steht „/ginvite <Name>“: drücke Enter.",
		expect = "Keine Meldung „geblockt“. Der Status des Bewerbers wechselt auf „eingeladen“. Der Punkt hakt sich selbst ab.\nKosten: kein Gold, ca. 2 Minuten (Zweitcharakter einloggen)." },
	{ id = "ALTER", since = "0.9.36", title = "Altersfrage mit Zweitcharakter",
		todo = "Wo: irgendwo. Zweitcharakter (nicht in der Gilde), zweites Spielfenster oder abwechselnd einloggen.\n  1. Mit dem Zweitcharakter dir flüstern: gilde\n  2. Die Fragen beantworten, die kommen. Bei „Wie alt bist du?“ antworte: 17",
		expect = "In der Bewerberliste steht beim Zweitcharakter „16+“ (antwortest du „15“: höfliche Absage und „abgelehnt (Alter)“). Gespeichert wird nur 16+ / unter 16 / unklar. Der Punkt hakt sich selbst ab.\nKosten: kein Gold, ca. 3 Minuten." },
	{ id = "SPERRLISTE", since = "0.9.44", title = "Sperrliste: sperren und entfernen",
		todo = "Wo: irgendwo (nur als Offizier).\n  1. Tippe: /gs  (Enter), klicke links auf „Leitung“ und oben auf den Reiter „Sperrliste“.\n  2. Ins Feld „Name“ schreiben: Testname\n  3. Ins Feld „Grund (nur für Offiziere)“ schreiben: Test\n  4. Klicke auf „Sperren“.\n  5. Klicke den Eintrag „Testname“ in der Liste an, dann auf „Von der Sperrliste nehmen“ und bestätige.",
		expect = "Im Chat „Testname steht jetzt auf der Sperrliste.“, der Eintrag erscheint; danach „Testname ist nicht mehr auf der Sperrliste.“ und der Eintrag ist weg. Der Punkt hakt sich selbst ab.\nKosten: kein Gold, ca. 1 Minute." },
	{ id = "TOOLTIP", since = "0.9.42", title = "Tooltip „In der Gilde seit“",
		todo = "Wo: irgendwo.\n  1. Öffne die Gildenliste des Spiels (Taste J oder O).\n  2. Fahre mit der Maus über einen Namen (nicht klicken).",
		expect = "Im Tooltip steht eine Zeile „In der Gilde seit <Datum>“ (bei manchen zusätzlich „Zuletzt befördert: <Datum> (<Rang>)“). Der Punkt hakt sich selbst ab.\nKosten: kein Gold, unter 1 Minute." },
	{ id = "NOTIZ", since = "0.9.45", title = "Notiz ändern -> Verlauf",
		todo = "Wo: irgendwo.\n  1. Öffne die Gildenliste des Spiels (Taste J oder O) und klicke deinen eigenen Namen an.\n  2. Ändere die öffentliche Notiz (z. B. ein Wort anhängen) und bestätige.\n  3. Warte 20 Sekunden.",
		expect = "Unter /gs, links „Mitglieder“, Reiter „Verlauf“ steht „öffentliche Notiz geändert“ mit „alt“ → „neu“. Der Punkt hakt sich selbst ab. (Danach darfst du die Notiz zurückändern.)\nKosten: kein Gold, ca. 1 Minute." },
	{ id = "MARKT", since = "0.9.38", title = "Haken „Marktdaten teilen“",
		todo = "Wo: irgendwo.\n  1. Tippe: /gs  (Enter) und klicke links auf „Einstellungen“.\n  2. Suche den Haken „Marktdaten teilen“ und lies den grauen Satz daneben.",
		expect = "Haken und grauer Satz sind ganz lesbar, nichts überlappt oder ist abgeschnitten. Dann hier „OK“ (sonst „Nicht OK“ und schreiben, was falsch aussieht).\nKosten: kein Gold, unter 1 Minute." },
	{ id = "TIPPEN", since = "0.9.34", title = "Befehlsliste beim Tippen",
		todo = "Wo: irgendwo.\n  1. Klicke ins Chat-Eingabefeld.\n  2. Tippe: /gs  und danach ein Leerzeichen (noch kein Enter).",
		expect = "Über dem Eingabefeld erscheint eine Liste aller Befehle. Ein Klick auf einen Befehl übernimmt ihn, Enter führt ihn aus. Dann hier „OK“.\nKosten: kein Gold, unter 1 Minute." },
}

ns.PL = GoldSentinelPruefliste and GoldSentinelPruefliste:Register("GuildSentinel", {
	db = function() return GuildSentinelDB end,
	version = function() return ns.version end,
	points = ns.PL_POINTS,
})

-- Testbericht (/gs protokoll): eine Kopfzeile und eine Zeile je Punkt
function ns.PLReportLines()
	if ns.PL and ns.PL.ReportLines then
		local ok, lines = pcall(ns.PL.ReportLines, ns.PL)
		if ok and type(lines) == "table" then return lines end
	end
	return {}
end

-- Speicherplatz gleich nach dem Laden anlegen (der Baustein legt ihn sonst beim ersten Lesen an – z. B. mitten in der
-- Testroutine, deren Sandbox das als Änderung sähe). Ohne Entwicklermodus: leere Liste, nichts angelegt.
ns:Listen("GS_LOGIN", function()
	if ns.PL and ns.PL.Store then pcall(ns.PL.Store, ns.PL) end
end)
