-- GuildSentinel - ClientTest.lua
-- GS-N3 (Idee Supervisor, freigegeben 19:58 am 15.11.2026): geführter Test im Spiel, "/gs clienttest".
-- Geht die offenen Punkte "IM CLIENT PRÜFEN" der Versionen 0.9.39–0.9.46 der Reihe nach durch. Was im Spiel messbar ist,
-- prüft er selbst; gefragt wird nur, wo der Spieler hinschauen muss (je Frage ein Satz, Knöpfe OK / Nicht OK /
-- Überspringen). Ergebnis: eine Zeile je Punkt in GuildSentinelDB.clientTest und im Diagnose-Protokoll (/gs protokoll).
--
-- Grundsätze: Er schickt NIE eine Nachricht (kein Flüstern, kein Gildenchat, keine Addon-Nachricht), ändert keine
-- Gildendaten (alles, was er für eine Prüfung braucht, wird vorher gemerkt und danach genau zurückgesetzt) und läuft
-- nicht im Kampf. Ein Lua-Fehler in einer Prüfung ergibt FEHLER für diesen Punkt, nicht für den ganzen Test.

local ADDON, ns = ...
local L, N = ns.L, ns.N

local CT = {}
ns.ClientTest = CT

local GREEN, RED, GOLD, GRAY = "|cff40d860", "|cffff6060", "|cffffd100", "|cff8a8f99"

-- vorübergehend ersetzen und sicher zurücksetzen (auch bei einem Fehler)
local function With(list, fn)
	local saved = {}
	for i, x in ipairs(list) do saved[i] = { x[1], x[2], rawget(x[1], x[2]) }; x[1][x[2]] = x[3] end
	local r = { pcall(fn) }
	for i = #saved, 1, -1 do local s = saved[i]; s[1][s[2]] = s[3] end
	if not r[1] then error(r[2], 0) end
	return r[2], r[3]
end
CT.With = With

local function MsNow()
	if debugprofilestop then return debugprofilestop() end
	return (GetTime and GetTime() or 0) * 1000
end

-- Die Prüfpunkte. auto(): true/false/nil (nil = nicht anwendbar) und ein kurzer Text mit Messwerten.
-- ask: Frage an den Spieler (nur gestellt, wenn die Automatik OK ist); prep(): vorher das Richtige anzeigen.
CT.POINTS = {
	{ id = "C1", name = N["Werbetexte: jeder Vorschlag mit /w, höchstens 251 Zeichen"], since = "0.9.39",
		auto = function()
			local Rc, bad = ns.Recruit, 0
			local list = Rc:Suggestions()
			for _, sg in ipairs(list) do
				local t = With({ { ns.db, "adText", Rc:SuggestionText(sg) or Rc:DefaultAd() } }, function() return Rc:AdText() end)
				if #t > Rc.AD_MAX or not t:find("/w ", 1, true) then bad = bad + 1 end
			end
			return bad == 0, string.format("%d Vorschläge, %d fehlerhaft", #list, bad)
		end,
		ask = N["Rekrutierung > Werbung: Zeigt der Knopf „Vorschlag wählen“ eine Liste mit Zeichenzahlen?"],
		prep = function() if ns.UI then ns.UI:Open("recruit", "ad") end end },
	{ id = "C2", name = N["Grenze für automatische Antworten (5 in 10 Minuten)"], since = "0.9.40",
		auto = function()
			local Rc = ns.Recruit
			local t0 = 100000
			local full, free = With({ { Rc, "autoLog", {} } }, function()
				for i = 1, Rc.AUTO_MAX do Rc.AutoUse(t0 + i) end
				return not Rc.AutoAllowed(t0 + Rc.AUTO_MAX + 1), Rc.AutoAllowed(t0 + 1 + Rc.AUTO_WINDOW)
			end)
			return full and free, string.format("Grenze %d in %d s, voll %s, danach frei %s", Rc.AUTO_MAX, Rc.AUTO_WINDOW, tostring(full), tostring(free))
		end },
	{ id = "C3", name = N["Bewerberliste: „selbst anschreiben“ und „auf Sperrliste“"], since = "0.9.41",
		auto = function()
			local pg = CT.Page("recruit")
			if not (pg and pg.AppRender) then return false, "Seite Rekrutierung ohne Anzeige" end
			local row = pg.AppRender({ name = "GSTestBewerber", a = { st = "new", t = ns.Now(), noAuto = true } })
			local ok = (row[6] or ""):find(L["selbst anschreiben"], 1, true) ~= nil
			return ok, ok and "Status-Spalte zeigt den Text" or ("Status: " .. tostring(row[6]))
		end },
	{ id = "C4", name = N["Sperrliste: Bewerbung, Einladen, Tooltip"], since = "0.9.44",
		auto = function()
			if not ns.IsOfficer() then return nil, "nur für Offiziere" end
			local g = ns.guild
			if not g then return nil, "keine Gilde" end
			local key = "Gstestgesperrt"
			-- Nachprüfung 04:59: auch eine fehlende Tabelle g.ban genau so zurücklassen (nach dem Laden der Gilde ist sie
			-- über ns.guildDefaults immer da; trotzdem exakt)
			local hadBan = type(g.ban) == "table"
			local before = hadBan and g.ban[key] or nil
			local ok, msg = With({ { ns.Lead, "SendOfficers", function() end }, { ns, "Print", function() end } }, function()
				local entry = { t = ns.Now(), by = "Test", r = "Test" }
				g.ban = g.ban or {}
				g.ban[key] = entry
				local banned = ns.Lead:Banned("gstestgesperrt") ~= nil
				local inv = With({ { ns, "Act", function() end } }, function() return ns.OpenGuildInvite("Gstestgesperrt") end)
				local tip = table.concat(ns.Tooltip:Lines("Gstestgesperrt") or {}, " "):find(string.format(L["Auf der Sperrliste: %s"], "Test"), 1, true) ~= nil
				if hadBan then g.ban[key] = before else g.ban = nil end
				return banned and inv == false and tip, string.format("erkannt %s, Einladen gesperrt %s, Tooltip %s", tostring(banned), tostring(inv == false), tostring(tip))
			end)
			if hadBan then g.ban[key] = before else g.ban = nil end
			return ok, msg
		end,
		ask = N["Leitung > Sperrliste: Ist der Reiter da (Namensfeld, Grund, Knopf „Sperren“)?"],
		prep = function() if ns.UI then ns.UI:Open("lead") end end },
	{ id = "C5", name = N["Rückkehrer: Daten für „wieder online nach 30 Tagen“"], since = "0.9.45",
		auto = function()
			local R = ns.Roster
			local snap = ns.G().roster or {}
			local n, seen = 0, 0
			for _, o in pairs(snap) do if type(o) == "table" then n = n + 1; if type(o.seen) == "number" and o.seen > 0 then seen = seen + 1 end end end
			if n == 0 then return nil, "Gildenliste noch leer" end
			return R.RETURN_DAYS == 30 and seen > 0, string.format("%d Mitglieder, %d mit „zuletzt online“, %d. Durchlauf", n, seen, (R.scans or 0) + 1)
		end },
	{ id = "C6", name = N["Notiz-Verlauf: öffentliche und Offiziersnotizen"], since = "0.9.45",
		auto = function()
			local snap = ns.G().roster or {}
			local n, pn, on = 0, 0, 0
			for _, o in pairs(snap) do
				if type(o) ~= "table" then o = {} end   -- 0.9.64 (GS-R1): beschädigter Eintrag
				n = n + 1
				if type(o.n) == "string" then pn = pn + 1 end
				if type(o.on) == "string" then on = on + 1 end
			end
			if n == 0 then return nil, "Gildenliste noch leer" end
			return pn == n, string.format("%d Mitglieder, öffentliche Notiz gemerkt %d, Offiziersnotiz gemerkt %d", n, pn, on)
		end },
	{ id = "C7", name = N["Fenster: Seiten erst beim Anwählen bauen"], since = "0.9.46",
		auto = function()
			local UI = ns.UI
			if not UI or not UI.frame then return nil, "Fenster noch nie geöffnet" end
			local built, on, maxMs, maxKey = 0, 0, 0, "-"
			for i, p in ipairs(UI.pages) do
				if UI:PageOn(p) then
					on = on + 1
					local panel = UI.panels[i]
					if not panel.built then
						local t0 = MsNow()
						UI:EnsureBuilt(i)
						local ms = MsNow() - t0
						if ms > maxMs then maxMs, maxKey = ms, p.key end
					end
					if panel.built then built = built + 1 end
				end
			end
			return built == on, string.format("%d/%d Seiten gebaut, längster Aufbau jetzt %.1f ms (%s)", built, on, maxMs, maxKey)
		end,
		ask = N["Klicke jede Seite links einmal an: Ist überall Inhalt zu sehen?"],
		prep = function() if ns.UI then ns.UI:Open("home") end end },
	{ id = "C8", name = N["Ruckler: LANGSAM-Einträge im Protokoll"], since = "0.9.42",
		auto = function()
			local d = GuildSentinelDB and GuildSentinelDB.diag
			local list = {}
			for _, e in ipairs(d and d.entries or {}) do
				if e.k == "LANGSAM" and (e.t:find("^Fenster aufbauen") or e.t:find("^Seite bauen") or e.t:find("^Mitgliederliste lesen") or e.t:find("^Seite ")) then
					list[#list + 1] = string.format("%s %s ms ×%d", e.t, tostring(e.ms or "?"), e.n or 1)
				end
			end
			return true, #list == 0 and "keine (nichts länger als ein Bild)" or table.concat(list, "; ", 1, math.min(#list, 4))
		end },
	{ id = "C9", name = N["Tooltip: „In der Gilde seit“ und letzter Rangwechsel"], since = "0.9.42",
		auto = function()
			-- GS-RANG-1 (0.9.52): der eigene Eintrag über ns.MyEntry (bis 0.9.51 nur der genaue Name: "nicht in einer
			-- Gilde", obwohl in einer Gilde). Der Grund nennt jetzt, was wirklich fehlt.
			if not ns.guild then return nil, "nicht in einer Gilde" end
			local e, how = ns.MyEntry()
			if not e then return nil, "eigener Eintrag in der Gildenliste nicht gefunden (" .. tostring(how) .. ")" end
			local lines = ns.Tooltip:Lines(e.name)
			if not lines then return false, "keine Tooltip-Zeilen für den eigenen Eintrag" end
			return true, string.format("%d Zeilen für dich", #lines)
		end,
		ask = N["Fahr mit der Maus über ein Gildenmitglied: Steht im Tooltip „In der Gilde seit …“?"] },
	{ id = "C10", name = N["Datenschutz: Alters-Angaben unkenntlich"], since = "0.9.43",
		auto = function()
			local a = ns.Recruit.MaskAge("ich bin 15")
			local b = ns.Recruit.MaskAge("lvl 60 hexer")
			return a == "ich bin …" and b == "lvl 60 hexer", a .. " | " .. b
		end },
}

function CT.Page(key)
	local UI = ns.UI
	if not UI then return nil end
	if not UI.frame then UI:Build() end
	local i = UI:PageIndex(key)
	if not i then return nil end
	UI:EnsureBuilt(i)
	return UI.pages[i]
end

-- ein Punkt automatisch; Lua-Fehler -> FEHLER
function CT.RunAuto(p)
	local ok, res, text = pcall(p.auto)
	if not ok then return false, "Lua-Fehler: " .. tostring(res):sub(1, 120) end
	return res, text
end

local function Line(p, st, text)
	return string.format("%s %s – %s: %s", p.id, st, L[p.name], tostring(text or ""))
end

-- Fragefenster (ein Satz, drei Knöpfe). fn(answer) mit "ok" / "bad" / "skip".
function CT.AskUI(question, fn)
	local UI = ns.UI
	local f = CT.frame
	if not f then
		f = CreateFrame("Frame", "GuildSentinelClientTest", UIParent, UI.BACKDROP)
		f:SetSize(460, 130)
		f:SetPoint("TOP", 0, -140)
		f:SetFrameStrata("DIALOG")
		if UI.Box then UI.Box(f, 0.06, 0.07, 0.09, 0.97, 0.35, 0.38, 0.45, 1) end
		f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
		f.title:SetPoint("TOPLEFT", 14, -12)
		f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
		f.text:SetPoint("TOPLEFT", 14, -34)
		f.text:SetPoint("RIGHT", -14, 0)
		f.text:SetJustifyH("LEFT")
		f.ok = UI:Button(f, L["OK"], 110, 24, function() CT.Answer("ok") end, true)
		f.ok:SetPoint("BOTTOMLEFT", 14, 12)
		f.bad = UI:Button(f, L["Nicht OK"], 110, 24, function() CT.Answer("bad") end)
		f.bad:SetPoint("LEFT", f.ok, "RIGHT", 8, 0)
		f.skip = UI:Button(f, L["Überspringen"], 110, 24, function() CT.Answer("skip") end)
		f.skip:SetPoint("LEFT", f.bad, "RIGHT", 8, 0)
		CT.frame = f
	end
	CT.pending = fn
	f.title:SetText(ns.TITLE .. " – " .. string.format(L["Client-Test %d/%d"], CT.pos or 0, #CT.POINTS))
	f.text:SetText(question)
	f:Show()
end

function CT.Answer(a)
	local fn = CT.pending
	CT.pending = nil
	if CT.frame then CT.frame:Hide() end
	if fn then fn(a) end
end

-- Test starten. ask(question, fn) kann im Nachbau ersetzt werden (Standard: Fragefenster).
function CT:Start(ask)
	if ns.InCombat() then ns:Print(L["Im Kampf nicht möglich – bitte nach dem Kampf noch einmal."]) return false end
	if self.running then ns:Print(L["Der Client-Test läuft schon."]) return false end
	ask = ask or CT.AskUI
	self.running, self.pos, self.lines = true, 0, {}
	self.counts = { ok = 0, bad = 0, na = 0 }
	local function Finish()
		self.running = false
		GuildSentinelDB = GuildSentinelDB or {}
		GuildSentinelDB.clientTest = { v = ns.version, t = ns.Now(), lines = self.lines }
		local c = self.counts
		ns:Print(string.format(L["Client-Test fertig: %d OK, %d FEHLER, %d nicht anwendbar – Ergebnis in /gs protokoll."], c.ok, c.bad, c.na))
		ns:Fire("GS_CLIENTTEST")
	end
	local function Record(p, st, text)
		self.lines[#self.lines + 1] = Line(p, st, text)
		if st == "OK" then self.counts.ok = self.counts.ok + 1 elseif st == "FEHLER" then self.counts.bad = self.counts.bad + 1 else self.counts.na = self.counts.na + 1 end
	end
	local function Next()
		self.pos = self.pos + 1
		local p = CT.POINTS[self.pos]
		if not p then Finish() return end
		local res, text = CT.RunAuto(p)
		if res == nil then Record(p, "N/A", text) return Next() end
		if res == false or not p.ask then Record(p, res and "OK" or "FEHLER", text) return Next() end
		if p.prep then pcall(p.prep) end
		ask(L[p.ask], function(a)
			if a == "ok" then Record(p, "OK", text)
			elseif a == "bad" then Record(p, "FEHLER", tostring(text) .. " · " .. L["im Spiel: Nicht OK"])
			else Record(p, "N/A", tostring(text) .. " · " .. L["übersprungen"]) end
			Next()
		end)
	end
	ns:Print(string.format(L["Client-Test: %d Punkte. Automatisch, was messbar ist; bei %d Punkten fragt ein kleines Fenster."], #CT.POINTS, CT.Questions()))
	Next()
	return true
end

function CT.Questions()
	local n = 0
	for _, p in ipairs(CT.POINTS) do if p.ask then n = n + 1 end end
	return n
end

-- Zeilen für das Diagnose-Protokoll
function CT.DiagLines()
	local r = GuildSentinelDB and GuildSentinelDB.clientTest
	if type(r) ~= "table" or type(r.lines) ~= "table" then return {} end
	local out = { string.format("CLIENTTEST v%s (%s):", tostring(r.v), date("%d.%m. %H:%M", r.t or 0)) }
	for _, l in ipairs(r.lines) do out[#out + 1] = "  " .. l end
	return out
end
