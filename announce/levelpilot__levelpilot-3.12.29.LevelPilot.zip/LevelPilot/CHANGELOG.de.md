# LevelPilot – Änderungen (Deutsch)

Ältere Versionen stehen in CHANGELOG.md (Englisch).

## 3.12.29
- GoldSentinelMarkt.lua Version 2 (unverändert aus der gemeinsamen Ablage): Ist AHSentinel geladen, liest die Datei
  dessen Vollscans nicht ein zweites Mal – kein Ruckeln mehr beim Vollscan und im Sniper. Ausverkaufte Items im Export.
- Testroutine: T283 stellt den Zustand „ein anderes Addon gibt gerade einen Scan weiter“ (feedUntil) mit zurück und hängt
  nicht davon ab, ob AHSentinel geladen ist; neuer Regressionstest T287.

## 3.12.28
Marktdaten-Netz (gemeinsam mit allen GoldSentinel-Addons).
- Neu dabei: GoldSentinelMarkt.lua (unverändert aus der gemeinsamen Ablage). Macht irgendein Addon im Auktionshaus einen
  Vollscan, liest LevelPilot ihn still mit (tiefster Stückpreis, Menge, Anzahl Auktionen je Item) und teilt die Preise
  anonym mit Gilde und Netz. Keine Namen, keine Abfrage, LevelPilot startet selbst nie einen Scan. Läuft je Client nur
  einmal, egal wie viele GoldSentinel-Addons installiert sind. Ohne Auktionshaus-API (Era, TBC) bleibt es still aus.
- Schalter „Marktdaten teilen (anonym, nur Preise)“ in der Zentrale unter Austausch, Standard an.
- Testbericht und Diagnose: Zeile „MARKT-NETZ: Version, an/aus, mitgelesene Scans, gesendet/empfangen, Speicher“.
- Zentrale: Der Schalter „Befehlsliste beim Tippen von /lp“ lag auf derselben Stelle wie „Einstellungen nur für diesen
  Charakter“ und hat eigene Zeile bekommen.
- Testroutine: neue Fälle T282–T286 (mit/ohne Datei, Schalter aus, ohne Auktionshaus-API, Berichtzeile, Schalter-Stellen).
- Richtigstellung zu 3.12.26: umgesetzt sind TU1–TU8. Die Offline-Routine (TU9) folgt in einer eigenen Version.

## 3.12.27
Befehlsliste beim Tippen.
- Tippst du /lp (oder /levelpilot) in den Chat, erscheint über dem Eingabefeld die Liste ALLER LevelPilot-Befehle mit
  kurzer Beschreibung in deiner Sprache. Jeder weitere Buchstabe filtert („/lp w“ -> weg, wege …); meistbenutzte oben.
- Klick oder Tab wählt einen Eintrag aus, Enter führt ihn aus. Das Chatfeld wird nie beschrieben. Ausschalten in der
  Zentrale (Anzeige: „Befehlsliste beim Tippen von /lp“).
- Slash-Handler und Liste benutzen eine Befehlstabelle – jeder Befehl, den der Handler kennt, steht in der Liste;
  Entwickler-Befehle nur für den Entwickler.
- Testroutine: neue Fälle T276–T281 (T-BL1–T-BL6).

## 3.12.26
Umfassende Tests (TU1–TU8; TU9 Offline-Routine folgt), damit im Spiel gefundene Fehler nicht wiederkommen.
- TU1 Lagen: jedes Volk und jede Klasse deiner Fraktion mit Stufe 1, 12, 30 und 58 läuft durch die Questauswahl
  (Fraktion, Klasse, Volk, Stufe, Startgebiet); Queststand erledigt / im Log / fehlgeschlagen / abgebrochen (T269).
- TU2 Abläufe wie ein Spieler: /reload unterwegs, Planmodus wechseln, Tod -> Geistheiler -> weiter, automatische
  Abgabe mit einer oder mehreren Belohnungen; am Ende keine Lua-Fehler und nichts Echtes ausgeführt (T270).
- TU3 Standardwerte: jede Option ab Werk, Liste im Testbericht (T271).
- TU4 Grundregeln mit 1000 Zufallsfällen (fester Startwert, in Portionen): kein Weg über Gelände, das die
  Geländekarte als unbegehbar kennt, nie automatisch eine Belohnung bei mehreren zur Wahl, Zeitschätzungen 0–6 h,
  keine geschützte Aktion im Kampf (T272).
- TU5 echte Daten (nur lesen): alle 10 Minuten werden Questlog und gemessene Werte gegen den Plan geprüft;
  Verletzungen stehen im Diagnose-Protokoll als „GRUNDREGEL VERLETZT …“ (T274).
- TU6 Regressionen: jeder Befund seit dem 1. November hat einen bleibenden Test; Zeile „Regressionen: n von m
  vorhanden“ (T273).
- TU7 Formen des Spiels: Forever, Era, TBC, Deutsch und Englisch, Fenster bei 80 % Skalierung (T275).
- TU8: Der Testbericht zeigt je Bereich TU1–TU7 eine Zeile.

## 3.12.25
- Notbremse der Routenplanung: Bei Planung in Portionen im Hintergrund zählt nur die längste Portion (über 50 ms),
  nicht die Summe – eine lange Planung in kleinen Portionen pausiert die Route nicht mehr. Eine während einer Pause
  gewünschte Planung wird danach einmal nachgeholt, statt verworfen.
- Die Suchschritt-Grenze der kurzen Wegprüfung in der Planung gilt nur für diese Suche (vorher ein globaler Wert, der
  nach einer abgebrochenen Planung auf 1200 stehen bleiben konnte – lange Wegsuchen fanden dann bis /reload keinen Weg).
- LANGSAM-Einträge der Notbremse werden von den eigenen Planungs-Einträgen nicht mehr gelöscht.
- Wegnetz: Hat 3.12.23 schon Lücken von 25–80 Yards geteilt, werden diese Stücke einmal erkannt (Punkte genau auf
  einer Linie in gleichen Abständen) und als unsicher markiert; gelöscht wird nichts.
- Hintergrund-Arbeit: Eine Portion darf sicher einen neuen Auftrag starten.
- Diagnose-Protokoll: In einer Pause verworfene Aufrufe werden gezählt („ZEIT in Pausen verworfen“).
- Testroutine: neue Fälle T266–T268, T262 erweitert.

## 3.12.24
Behoben: Das Spiel konnte nach dem Einloggen auf einem Charakter mit grossem aufgezeichnetem Wegnetz einfrieren
(CPU über 100 %).
- Ursache: Die Wegsuche verband jeden Suchschritt per Luftlinie mit hunderten Wegpunkten in der Nähe und prüfte jede
  Linie gegen die Geländekarte. Mit dem dichteren Wegnetz (Punkte alle 12–25 Yards, geteilte alte Stücke in 3.12.23)
  dauerte eine Suche mehrere hundert Millisekunden. Sie lief nach jeder Planung erneut, abseits des Weges alle 0,5 s,
  und jede von Gildenmitgliedern empfangene Quest leerte zudem den Zwischenspeicher der Suche.
- Die Wegsuche nimmt für Luftlinien jetzt höchstens zwei Wegpunkte je 100-Yards-Feld und merkt sie sich; empfangene
  Quests leeren den Zwischenspeicher nicht mehr (die Geländekarte kommt aus dem Datenpaket).
- Schwere Arbeit läuft in Portionen im Hintergrund (höchstens 4 ms je Bild): Wegsuche, Geländeführung, automatische
  Routenplanung und die einmalige Aufbereitung des Wegnetzes. Ein Klick von dir plant weiterhin sofort.
- Notbremse: Braucht ein Teil mehr als 50 ms am Stück oder mehr als 1 s in 5 s, pausiert er 60 s – eine Chatzeile und
  ein Eintrag LANGSAM im Diagnose-Protokoll (Teil, Zeit, Anzahl Ziele und Wegpunkte, Zone).
- Abseits des Weges wartet LevelPilot nach einer teuren Suche länger (bis 10 s), statt alle 0,5 s zu suchen.
- Die Planung prüft den ersten Weg nur mit einer kurzen Suche.
- Diagnose-Protokoll: Rechenzeit je Teil (Route, Wegsuche, Wegnetz, Netz-Empfang, Quests, Anzeige …), die ersten 60 s
  nach dem Einloggen getrennt. Beim Ausloggen wird das Protokoll als GSDIAG1 in die Speicherdatei geschrieben (für die
  Testberichte, ohne Namen; LevelPilotDB.diagSend = false schaltet es ab).
- Wegnetz: geteilt werden nur Stücke über 80 Yards (25–80 Yards kann eine Lücke zwischen zwei Aufzeichnungen sein –
  als unsicher markiert, bis es nochmals gelaufen wird); kein verwaister Punkt, wenn das Teilen scheitert.
- Testroutine: neue Fälle T261–T265 (T-LAG1–T-LAG4), T148 misst die Portionen.

## 3.12.23
- Zonen-Anfragen und Mitspielersuche ohne Prüfsumme des Absenders (LevelPilot bis 3.12.21) werden nicht mehr
  angenommen – ein Weitergeber konnte sie unter seinem Namen in seine Gilde bringen. Spieler mit 3.12.21 bekommen bis
  zu ihrem Update keine Zonen-Antworten und keine Mitspieler-Hinweise von anderen.
- Wegaufzeichnung: Position alle 0,5 s; eine Lücke über 25 Yards zwischen zwei Positionen (Ruckler, Teleport, sehr
  schnell) trennt den Weg, statt sie als gerade Linie zu speichern.
- Einmal nach dem Update werden lange gerade Wegstücke älterer Versionen in Stücke von höchstens 25 Yards geteilt
  (auf der gelaufenen Linie), danach werden lose Enden nochmals verbunden.
- Testroutine: neue Fälle T259, T260; T254 erweitert.

## 3.12.22
- Die Austausch-Einstellungen werden genau eingehalten: Gilde, Gruppe und Flüster-Netz nur, wenn eingeschaltet. Das
  Netz geht nur mit, wenn Gilde und Gruppe beide an sind (GoldSentinelSync kennt noch kein „nur Netz“).
- Zonen-Anfragen und die Mitspielersuche für Elite-Quests gehen nur an Gilde und Gruppe und tragen eine Prüfsumme des
  Absendernamens. Übers Netz weitergegebene Nachrichten (Absender = Weitergeber) werden nicht beachtet – keine Antwort
  an den Falschen, kein falscher Name im Mitspieler-Hinweis.
- Zonen-Antworten haben höchstens 25 Nachrichten (der Rest bei der nächsten Anfrage) und gehen nur, wenn die
  gemeinsame Warteschlange aller GoldSentinel-Addons fast leer ist.
- Aufzeichnungen, die nicht gesendet werden konnten (kein Weg), gehen später in derselben Sitzung noch hinaus.
- Testroutine: eigene leere Warteschlangen; Nachrichten anderer Addons werden während des Tests nicht mehr gesendet.
- Diagnose-Protokoll: kein „Schritt seit 25 min aktiv“ mehr, solange du in einer Hauptstadt stehst (Bank,
  Auktionshaus, Post) oder im Dungeon bist; keine Fokus-Meldung, wenn der aktuelle Schritt in deiner Zone liegt; keine
  Zonen-Meldung in Höhlen ohne eigene Karte.
- Testroutine: neue Fälle T254–T258, T243 erweitert.

## 3.12.21
Datenaustausch über die gemeinsame Datei GoldSentinelSync (Version 2) statt über einen eigenen Chat-Kanal.
- In WoW Forever kommen Addon-Nachrichten in eigenen Chat-Kanälen nie an. LevelPilot betritt den Kanal
  „LevelPilotNet“ nicht mehr und verlässt ihn einmal (frei werdender Kanalplatz).
- Gesendet wird über Gilde, Gruppe/Schlachtzug und das neue Flüster-Netz von GoldSentinelSync 2 (erreicht alle Spieler
  mit LevelPilot über die Gilden hinaus): aufgezeichnete Quests, Wege, Höhlen, Flüge, Zonen-Anfragen und Lebenszeichen.
  Nur Gilde und Gruppe: Beute- und Gegnerwerte (häufig) und der Gruppenmodus (Stufe, Schritt, Quests – nur die Gruppe).
  Die Mitspielersuche für Elite-Quests (falls eingeschaltet) geht wie bisher über den Kanal jetzt ins Netz.
  Zonen-Antworten gehen per Flüstern an den Fragenden.
- Ältere LevelPilot-Versionen anderer Spieler werden weiter verstanden (gleiche Kennung).
- Bekannte Mitspieler des Netzes bleiben über /reload erhalten (LevelPilotDB.gsSync, nur Namen und Zeiten, nur lokal).
  Frühere Absendernamen in der Speicherdatei stehen jetzt nur noch als Prüfsumme.
- /lp sync test: „N Antworten (Gilde a, Gruppe b)“. Diagnose-Protokoll: SYNC-/NETZ-Zeilen (ohne Namen),
  NOT_ALLOWED_IN_CHANNEL wird gezählt.
- Zentrale, Reiter Austausch: „Über das Flüster-Netz“ statt Addon-Kanal, Mitspieler online statt Kanalstatus.
- GoldSentinelTest 2: Fehlerberichte an den Entwickler teilen (nur mit Zustimmung, /gstest).
- Testroutine: neue Fälle T242–T253; T92, T108, T111, T169 angepasst.

## 3.12.20
- Gemeinsame Datei GoldSentinelGame.lua Version 3 (nur Kommentare, keine Spielernamen in den Beispielen).
- Keine echten Charakternamen in den eigenen Dateien: Tests verwenden „Testa Beispiel“, der Entwickler-Charakter
  steht nur noch als Prüfsumme im Code.

## 3.12.19
- Weitere Abfragen werden vor der Benutzung auf geschützte Werte geprüft: Blickrichtung (Pfeil, Minikarte), drinnen
  (Höhlen, Kartenradius), Erholung, Laufgeschwindigkeit sowie die Stufe von Spieler und Begleiter. Eine geschützte
  Stufe fällt auf die zuletzt lesbare zurück.
- Testroutine: neuer Fall T241. T128 prüft alte Daten jetzt ohne die eigenen Messungen (im Spiel stand vorher
  „gemessen true“). Absichtliche Testfehler von T158–T163 erhöhen den Fehlerzähler im Bericht nicht mehr.

## 3.12.18
- Die eigenen Tooltips verdecken die Knöpfe nicht mehr (Unterstützen, Zentrale, Normal, Überspringen …). Sie stehen
  neben dem Fenster, zu dem der Knopf gehört – rechts, ohne Platz links, sonst darunter – auf Höhe des Knopfs. Gilt
  für Leitfenster, Schrittliste, Assistent-Zeile, Grössen-Griff, Aktionsleiste und Pfeil.
- Testroutine: neuer Fall T240.

## 3.12.17
Bessere Wegdaten (aus der Auswertung der eingesandten Wegdaten).
- Neue Wegstücke werden ans bestehende Netz gehängt: liegen Anfang, Ende oder eine Kreuzung bis 10 Yards neben einem
  bekannten Weg, wird dieser dort geteilt und verbunden. Lose Enden bestehender Wege werden nach dem Update einmal
  verbunden (es geht nichts verloren).
- Wegpunkte werden mindestens alle 25 Yards und bei jeder Richtungsänderung über 30° gespeichert (vorher hatten
  gerade Stücke von einigen hundert Yards keinen Punkt dazwischen).
- Auf der Kontinentkarte (Flug, Schiff) werden keine Wege aufgezeichnet oder gesendet.
- Wegdaten (/lp wege, GSWEGE1): Orte der Questgeber alt/neu beide als [x, y], "oldMap", wenn das Datenpaket den NPC
  auf einer anderen Karte hat, als Ort im Datenpaket der nächste auf derselben Karte (nicht der erste), "nopack" für
  NPCs ohne Ort im Datenpaket.
- Datenpaket 1.6.1: Orte von Gordo (10666, Tirisfal) und Bluff Runner Windstrider (10881, Thunder Bluff) für WoW
  Forever korrigiert.
- Testroutine: neue Fälle T235–T239.

## 3.12.16
Graue Gegenstände werden automatisch verkauft, ohne Knopf.
- Öffnet sich ein Händlerfenster, verkauft LevelPilot alle grauen Gegenstände mit Verkaufswert von selbst (ausserhalb
  des Kampfes, ein Gegenstand alle 0,2 s, Stopp beim Schliessen des Händlerfensters oder bei Kampfbeginn). Gesperrte
  Gegenstände und solche, die eine Quest braucht, bleiben. Danach eine Chatzeile: „N graue Gegenstände verkauft für …“
  – keine Zeile, wenn nichts verkauft wurde.
- Option „Graue Gegenstände beim Händler verkaufen“ (ab Werk an) in der Zentrale, oder /lp grau zum Umschalten.
- LevelPilot legt nichts auf oder neben das Händlerfenster. Hinweis: der Knopf „Verkaufen: 0 Items (0)“ am
  Händlerfenster stammt von AHSentinel, nicht von LevelPilot.
- Testroutine: neue Fälle T230–T234 (Option an/aus, nur Qualität 0, Abbruch bei MERCHANT_CLOSED, im Kampf nichts,
  im Test nur mitgeschrieben). Fälle, die in der aktuellen Lage nicht prüfbar sind (z. B. Level 60, kein Datenpaket,
  kein Ziel), zählen jetzt als „übersprungen“ mit Grund statt als „OK“.

## 3.12.15
Die Testroutine prüft die Oberfläche (aus der GoldSentinel-Vorlage).
- Neue Datei UICheck.lua: alle LevelPilot-Fenster sind angemeldet (Leitfenster, Zentrale, Sicherung, Gruppenfeld,
  virtueller Durchlauf, Spenden, Schrittmenü, Aktionsleiste, Pfeil).
- Neuer Bereich K in /lp testroutine (T224–T229): eigene Tooltips verdecken keine Knöpfe, kein Überlappen mit
  Blizzard- oder anderen GoldSentinel-Fenstern, Fenster ganz im Bildschirm, Knopfbeschriftungen nicht abgeschnitten,
  Werte plausibel, keine Fehlerschleifen (kein Lua-Fehler öfter als 10-mal je Sitzung).
- Plausibilität: die Anzahl fertiger Quests im Questlog stimmt mit der Anzahl „Abgeben“-Schritte in der Liste
  überein; auch Questanzahl, Stufe und Kartenposition werden geprüft. T224–T227 laufen nur im echten Client.

## 3.12.14
- Behoben: Lua-Fehler „attempt to perform boolean test on a secret boolean value“ (Session.lua, in WoW Forever
  hundertfach). UnitIsAFK liefert dort zeitweise einen geschützten Wert; dann zählt nur noch der eigene Leerlauf.
- Alle übrigen Abfragen mit Wahrheits- oder Zahlenwert (Flug, tot/Geist, Kampf, Fahrzeug, Ziel vorhanden,
  Spielerposition, EP und Erholt-Bonus) werden vor der Benutzung auf geschützte Werte geprüft.
- Testroutine: neuer Fall T223 (geschützte Wahrheitswerte aus UnitIsAFK & Co.).

## 3.12.13
Ausnahme während der Pause (Entscheid des Nutzers): erst die Zone fertig machen.
- Hast du in der Zone, in der du stehst (mit ihrer Hauptstadt), noch offene Quests, bleibt die Planung dort. Erst
  danach geht es gesammelt in die nächste Zone. Abgaben in einer anderen Zone sind kein Grund mehr, die Zone zu
  verlassen. Ausgenommen sind Quests, die für dein Level zu gefährlich oder nicht erreichbar sind.
- Testroutine: neuer Fall T222 (offene Quests in Mulgore vor Abgaben im Brachland).

## 3.12.12
Genaue Wege, Schritt 4 (Ausnahme während der Pause, Entscheid des Nutzers): Wegdaten zum Einsenden.
- Neuer Befehl /lp wege (oder /lp wege <Zone>): zeigt die gelernten Wege je Zone als Koordinatenfolgen (Herkunft
  selbst/geteilt, wie oft gelaufen), gesperrte Wegstücke, korrigierte Orte von Questgebern und FEST-Ereignisse der
  letzten 7 Tage als markierbaren Text – ohne Spieler-, Charakter- oder Gildennamen.
- Automatisch: Beim Ausloggen und /reload legt LevelPilot neue und geänderte Wegdaten (Kennung GSWEGE1, höchstens
  200 KB) in seinen gespeicherten Daten bereit; der RaidMaster-Uploader kann sie wie die Testberichte mitnehmen.
  Abschaltbar in der Zentrale unter Austausch („Wegdaten automatisch senden“, ab Werk an).
- Testroutine: neuer Fall T221 (Text, GSWEGE1, nur Neues, abschaltbar, keine Namen).

## 3.12.11
Genaue Wege, Schritt 3 (Ausnahme während der Pause, Entscheid des Nutzers): echte Orte der Questgeber.
- Sprichst du einen Questgeber an (Quest annehmen, abgeben, Gespräch), merkt sich LevelPilot seinen echten Ort und
  nimmt ihn künftig statt der Koordinaten aus dem Datenpaket – falsche Ziele in veränderten Forever-Zonen werden so
  korrigiert. Die Orte sind wie alle gesammelten Daten im Charakter gesichert.
- Wege lernen (jede gelaufene Strecke), Wege und Höhlen mit Gruppe und Gilde teilen und Flüge bei langen Strecken
  waren schon vorhanden und bleiben unverändert.
- Testroutine: neuer Fall T220 (echter Ort eines Questgebers, geschützte Werte).

## 3.12.10
Genaue Wege, Schritt 2 (Ausnahme während der Pause, Entscheid des Nutzers): aus Sackgassen lernen.
- „FEST“ zählt nur noch reine Laufzeit: Die Uhr läuft nur, solange du dich wirklich bewegst. Stehen hält sie an
  (setzt nichts in Gang); AFK, tot/Geist, Kampf, Flug, offene Händler-, Post-, Auktions-, Berufs- und Lehrerfenster,
  Ladebildschirm und /reload zählen nie. Erst nach 4 Minuten Laufen ohne Annäherung ans Ziel gilt ein Weg als FEST.
- Bei FEST merkt sich LevelPilot das Wegstück als gesperrt und sucht einen anderen Weg; ist keiner bekannt, zeigt nur
  noch der Pfeil die Richtung.
- Testroutine: neuer Fall T219 (10 min AFK, 2 min stehen und 1 min laufen, 4 min im Kreis, gesperrte Kante).

## 3.12.9
Genaue Wege, Schritt 1 (Ausnahme während der Pause, Entscheid des Nutzers): Wegnetz statt Luftlinie.
- Die Route wird nur noch über bekannte Wege gezeichnet: gelaufene oder geteilte Wegstücke, Zonenübergänge und
  Höhlen. Als Luftlinie gilt nur das erste und das letzte kurze Stück (bis 40 Yards).
- Ist kein Weg bekannt, zeichnet LevelPilot keine Linie mehr – der Pfeil zeigt die Richtung zum Ziel mit dem Hinweis
  „Weg unbekannt“. Lieber keine Linie als eine falsche (nie mehr übers Gebirge).
- Das Wegnetz wächst aus gelaufenen Wegen; eigene Koordinatenlisten für Mulgore, Brachland und Thunder Bluff
  folgen, sobald genug aufgezeichnet ist.
- Testroutine: neuer Fall T218 (Mulgore Fall 1 und 2, Ziel ohne Netz, Thunder Bluff mit Aufzug).

## 3.12.8
Ausnahme während der Pause (Entscheid des Nutzers): Route in Thunder Bluff und Mulgore.
- Hauptstädte gehören für die Planung zu ihrer Zone (Thunder Bluff – Mulgore, Orgrimmar – Durotar, Undercity –
  Tirisfal, Stormwind – Elwynn, Ironforge – Dun Morogh, Darnassus – Teldrassil). In WoW Forever haben die Städte
  keine Elternzone; bisher lag der Fokus darum oft in der falschen Karte. Die Reihenfolge der Aufgaben beider Karten
  richtet sich nach dem Weg.
- Der Fokus folgt dem Spieler: liegt die alte Fokus-Zone weit hinter dir, wechselt er in die Zone, in der du stehst.
- Der Fokus-Wächter im Fehler-Protokoll plant selbst neu, statt die Meldung immer wieder zu schreiben; gemeldet wird
  nur noch einmal, wenn das nicht hilft.
- Vorrang-Ziele (Trainer, Beruf, Händler …) stehen nie mehr vor abgabebereiten Quests in der Nähe. Kommt man einem
  Vorrang-Ziel minutenlang nicht näher (z. B. Trainer oben in Thunder Bluff), zeigt LevelPilot nur noch den Pfeil.
- Testroutine: neuer Fall T217 (Thunder Bluff und Mulgore, Fokus-Wächter, Vorrang-Ziel nach nahen Abgaben).

## 3.12.7
Ausnahme während der Pause (Entscheid des Nutzers): Route in Mulgore und Lua-Fehler im Fehler-Protokoll.
- Abgabebereite Quests in der Nähe (bis 900 Yards) kommen jetzt immer zuerst – vor Flugmeister, Binden, Ruhestein
  und weiten Zielen; die nächste zuerst. Eine Abgabe ganz in der Nähe wird auch dann geplant, wenn die Gefahrenkarte
  den Ort als zu gefährlich einstuft (du stehst schon dort).
- Aufgezeichnete Orte (eigene, Startdatenbank, von anderen Spielern) gelten nur noch vor dem Datenpaket, wenn sie dazu
  passen; liegen sie weit daneben, nimmt LevelPilot die Orte aus dem Datenpaket. Aufgezeichnete Händler und Gastwirte
  ohne begehbaren Boden in der Umgebung (z. B. mitten im Gebirge) werden nicht mehr angeboten.
- Führt ein Wegstück als Luftlinie über überwiegend unbekanntes Gelände (Gebirge, Felsen), zeichnet LevelPilot keine
  Linie mehr; der Pfeil zeigt dann direkt die Richtung zum Ziel.
- Fehler-Protokoll: kein Lua-Fehler mehr durch geschützte Werte (Bewegung/Tempo) in WoW Forever („attempt to compare
  a secret number value“).
- Testroutine: neue Fälle T214 (Abgaben in der Nähe zuerst, Mulgore Fall 1 und 2), T215 (kein Ziel und keine Linie
  im Gebirge) und T216 (Protokoll mit geschützten Werten).

## 3.12.6
Offene Punkte der Prüfung vom 3. November 2026 (Nachprüfung 3.12.5).
- Dropraten auf WoW Forever genauer: Der Kill zählt jetzt schon bei der Monster-EP-Meldung (totes Ziel), auch wenn
  die Leiche keine Beute hat – die Rate fällt dadurch nicht mehr zu hoch aus. Stückzahlen zählen erst, wenn der
  Gegenstand wirklich in der Tasche ankommt (Beute-Meldung); bleibt etwas bei voller Tasche liegen, zählt es erst
  beim späteren Aufheben. Jede Leiche zählt nur einmal, geschützte Werte werden nie benutzt.
- Berufs- und Klassenhinweise: Antwortet die erste Zauber-Abfrage mit „nicht bekannt“, fragt LevelPilot auch die
  übrigen (IsPlayerSpell) – kein falscher Hinweis zu Erste Hilfe/Kochen mehr.
- Belohnungs-Hinweis: Ist die Gegenstandsinfo beim Öffnen der Belohnung noch nicht geladen, prüft LevelPilot nach
  einer Sekunde noch einmal.
- Beschädigte gespeicherte Einträge (falscher Typ) werden beim Laden übersprungen oder ersetzt statt Lua-Fehler zu
  verursachen; gültige gesammelte Daten bleiben unverändert.
- Geschützte Werte: EP-Anzeige, Zeit bis 60, Gruppenstand und Erholt-Hinweis rechnen nie mit geschützten EP;
  Tooltips, Messung und Gegner-Zeilen prüfen geschützte Einheiten.
- Fehler, die bisher still abgefangen wurden (virtuelle Reise, Sicherung beim Ausloggen, Protokoll-Prüfungen), werden
  jetzt an die GoldSentinel-Prüfung gemeldet. Die Diagnose zeigt Modul-Startfehler.
- Planungszeit der virtuellen Reise zählt nur noch die Rechenzeit (Pausen zwischen den Bildern nicht mehr).
- Testroutine (Testmodus): alle Testfälle automatisiert (vorher 96 Platzhalter), Zählung „nicht automatisiert“ im
  Bericht, neue Client-Fälle T171, T195 und T213 (Berufszauber), lange Reisen mit /lp testroutine reise.
  Im Kopierfenster der Hinweis „Wird auch automatisch gemeldet.“ (alle Sprachen).

## 3.12.5
Grundeinstellung nach Entscheid des Nutzers, offene Punkte der Prüfung vom 3. November 2026 und neue Testroutine.
- Grundeinstellung: Automatisch reparieren und Auto-Flug sind ab Werk wieder an; Vorräte nachkaufen und
  Questbelohnung anlegen bleiben aus. Bestehende Einstellungen ändern sich nicht – wer 3.12.4 neu installiert hat,
  schaltet Reparieren und Auto-Flug in der Zentrale ein (Komfort).
- Neue einmalige Hinweise: beim ersten Händler, bei dem LevelPilot nachkaufen würde (Nachkaufen aus), und bei der
  ersten Questbelohnung, die ein Upgrade ist (Anlegen aus), zeigt LevelPilot einmal, dass es die Option gibt – mit
  „Einstellungen“ und „Später erinnern“ (frühestens 3 Level später). Es wird nichts gekauft, gewählt oder angelegt;
  nie im Kampf, nie mehr, sobald die Option an ist. Auch die Begrüssung „Wo war ich?“ zeigt einmal einen Tipp.
- Dropraten auf WoW Forever: Wird dieselbe Leiche erneut geöffnet (Tasche voll, Fenster geschlossen), zählen Kill und
  Stückzahl nicht doppelt; ein Beutefenster mit geschütztem Link wird ausgelassen statt einen Kill ohne Beute zu
  zählen; Taschendiebstahl (Ziel lebt noch) zählt nicht als Kill.
- Klassenhinweise: Antwortet keine Zauber-Funktion, behauptet LevelPilot nicht mehr, Erste Hilfe/Kochen fehle.
- Erkennung: Meldet GoldSentinelGame „nicht modern“, folgt LevelPilot dem (eigene Erkennung nur ohne GoldSentinelGame).
- Alle Zeitgeber laufen geschützt über LP:Ticker (Neuplanung, Assistent, Partnersuche, Datenaustausch, Reise).
- Fehlende Übersetzung des Protokolleintrags „Datenpaket veraltet“ ergänzt (alle Sprachen).
- Robustheit: Fehlende Spielfunktionen (Reparaturkosten, Haltbarkeit, Munition, Questgeber-Begrüssung,
  Gegenstandsinfo) führen nicht mehr zu Lua-Fehlern.
- Aktionen mit echten Folgen (Kaufen, Verkaufen, Reparieren, Anlegen, Quests, Flug, Senden, Einladen, Neuladen)
  laufen über eine Stelle (LP.Act); im normalen Spiel ändert sich nichts.
- Neue Testroutine für den Entwickler (Testmodus): /lp testroutine [a–j] und Knopf „Alles testen“; Sandbox für
  deine Daten, Aktionen werden nur mitgeschrieben. /lp test (für alle) schreibt jetzt einen maschinenlesbaren
  Bericht. Berichte und Lua-Fehler werden für die GoldSentinel-Prüfung gespeichert (GoldSentinelTest.lua, ohne Namen).
