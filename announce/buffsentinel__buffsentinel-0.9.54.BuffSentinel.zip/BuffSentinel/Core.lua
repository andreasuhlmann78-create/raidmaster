-- BuffSentinel - Core.lua
-- Grundgerüst: Versionserkennung, Datenbank, API-Hilfen, Skillungs-/Zauberbuch-Erkennung, Zonen-Logik, Events

local ADDON, BS = ...
local L = BS.L
_G.BuffSentinel = BS

-- Schnittstelle für andere GoldSentinel-Addons (Hinweis 18.11.2026 "Testdaten nie zu anderen Addons", Regel 1):
-- TestRunning() ist true, solange die Testroutine läuft – dann steht in BuffSentinelDB die Sandbox mit Testdaten.
-- Andere Addons lesen in dieser Zeit NICHTS aus BuffSentinel (weder BuffSentinelDB noch BuffSentinel.*).
_G.BuffSentinelAPI = {
    TestRunning = function() return (BS.Selftest ~= nil and BS.Selftest.running == true) end,
}

BS.version        = "0.9.54"
BS.ClassData      = BS.ClassData or {}
BS.pools          = { buff = {}, proc = {}, cd = {} }
BS.entries        = {}
BS.known          = {}
BS.talents        = {}
BS.talentList     = {}
BS.allTalents     = {}
BS.talentByName   = {}
BS.talentByPos    = {}
BS.talentSig      = ""
BS.points         = { 0, 0, 0 }
BS.mainSpec       = 0
BS.playerAuras    = {}
BS.playerAuraInfo = {}
BS.groupMissing   = {}
BS.triggers       = {}
BS.GCD_LIMIT      = 1.6

BS.COLORS = {
    accent = { 1.00, 0.65, 0.20 },
    green  = { 0.40, 0.85, 0.45 },
    yellow = { 1.00, 0.82, 0.25 },
    red    = { 0.95, 0.35, 0.35 },
    dim    = { 0.55, 0.55, 0.60 },
    text   = { 0.90, 0.90, 0.92 },
}

------------------------------------------------------------------------
-- Versionserkennung
--   expansion: 1 Classic Era/SoD/Hardcore + WoW Forever, 2 TBC, 3 Wrath/Titan, 4 Cata, 5 MoP, 12 Retail
--   family:    "classic" = Talentbäume (Era bis Cata, Forever), "modern" = Spezialisierungen (MoP, Retail)
------------------------------------------------------------------------
-- Erkennung kommt aus der gemeinsamen Datei GoldSentinelGame.lua (alle GoldSentinel-Addons gleich).
-- Die eigene Erkennung bleibt als Rückfall, falls die Datei fehlt oder "unknown" meldet.
local FLAVOR_EXP = { era = 1, forever = 1, tbc = 2, wrath = 3, titan = 3, cata = 4, mists = 5, retail = 12 }
BS.FLAVOR_EXP = FLAVOR_EXP

-- Beim Laden einmal aufgerufen; der Selbsttest ruft sie nach G.SetTestFlavor erneut auf.
-- testNoGame (nur Testroutine): so rechnen, als fehlte GoldSentinelGame.lua (Rückfall prüfen).
function BS:DetectFlavor()
    local G = (not self.testNoGame) and GoldSentinelGame or nil
    local build = (G and G.toc and G.toc > 0 and G.toc) or select(4, GetBuildInfo()) or 0
    self.interface = build
    local exp, flavor
    if G and FLAVOR_EXP[G.flavor] then
        flavor, exp = G.flavor, FLAVOR_EXP[G.flavor]
    elseif build >= 100000 then exp, flavor = 12, "retail"
    elseif build >= 50000 then  exp, flavor = 5,  "mists"
    elseif build >= 40000 then  exp, flavor = 4,  "cata"
    elseif build >= 38000 then  exp, flavor = 3,  "titan"
    elseif build >= 30000 then  exp, flavor = 3,  "wrath"
    elseif build >= 20000 then  exp, flavor = 2,  "tbc"
    elseif build >= 16000 then  exp, flavor = 1,  "forever"
    else                        exp, flavor = 1,  "era"
    end
    self.expansion = exp
    self.flavor    = flavor
    self.family    = (exp >= 5) and "modern" or "classic"
    self.isForever = flavor == "forever"
    self.isRetail  = flavor == "retail"
    -- WoW Forever und Retail laufen auf dem modernen Client mit denselben Addon-Sperren:
    -- kein Kampflog, im Kampf "geheime Werte" (Auren, Namen, Lebenspunkte, Abklingzeiten).
    -- G.IsModern: Forever/Retail oder ein Client, der geheime Werte kennt
    if G then self.restricted = G.IsModern == true else self.restricted = self.isRetail or self.isForever end
end
BS:DetectFlavor()

-- Kampflog nur auf den alten Clients (Forever und Retail sperren es für Addons)
function BS:WantsCombatLog()
    return not self.restricted
end

-- Sperren wirklich aktiv? Eingeschränkter Client UND das Spiel kennt geheime Werte (Weiche über die Funktion,
-- nicht nur über die Versionsnummer). Classic Era, TBC, Wrath, Cata, MoP Classic: immer false.
function BS:Locked()
    local hasSecrets
    if GoldSentinelGame then hasSecrets = GoldSentinelGame.HasSecrets else hasSecrets = type(issecretvalue) == "function" end
    -- Testroutine: simulierte geheime Werte (BS.testSecrets) zählen wie ein Client mit geheimen Werten
    if self.testSecrets then hasSecrets = true end
    return self.restricted == true and hasSecrets == true
end

-- Kampfsperre: InCombatLockdown() oder (nur Testroutine) BS.testLockdown. Der Test kann eine Sperre nur hinzufügen.
function BS:Lockdown()
    return InCombatLockdown() or self.testLockdown == true
end

function BS:CombatLocked()
    return self:Locked() and (self:Lockdown() or UnitAffectingCombat("player") or self.testCombat == true) and true or false
end

-- Auren lesen erlaubt? (nur Forever/Retail mit geheimen Werten eingeschränkt; alte Clients: immer ja)
-- Der moderne Client wirft bei GetAuraDataByIndex einen Fehler ("Auras cannot be accessed when secret while
-- tainted"), sobald Auren geschützt sind – nicht nur im Kampf, auch kurz nach dem Kampf und bei Gruppenmitgliedern
-- bzw. Zielen, die selbst kämpfen. Deshalb: vorher prüfen und den Aufruf zusätzlich absichern (BS.AuraByIndex).
function BS:AuraBlocked(unit)
    if not self:Locked() then return false end
    if self.testAuraBlock then return true end
    if self:Lockdown() or UnitAffectingCombat("player") or self.testCombat == true then return true end
    local now = GetTime()
    if (self.auraHoldUntil or 0) > now then return true end
    if unit and unit ~= "player" and BS.API.UnitAffectingCombat then
        local c = BS.API.UnitAffectingCombat(unit)
        if BS.IsSecret(c) or c == true then return true end
    end
    local CS = BS.API.C_Secrets
    if CS and CS.ShouldAurasBeSecret then
        local ok, sec = pcall(CS.ShouldAurasBeSecret)
        if ok and sec == true then return true end
    end
    return false
end

-- Eine Aura lesen, abgesichert. Rückgabe: Auradaten (oder nil) und false, wenn der Zugriff verweigert wurde.
-- Ein verweigerter Zugriff ist kein Addon-Fehler: kurz pausieren (2 s) und einmal im Chat erklären.
function BS.AuraByIndex(unit, i, filter)
    local f = BS.API.C_UnitAuras and BS.API.C_UnitAuras.GetAuraDataByIndex
    if not f then return nil, true end
    local ok, a = pcall(f, unit, i, filter)
    if ok then return a, true end
    BS.auraDenied = (BS.auraDenied or 0) + 1
    BS.auraHoldUntil = GetTime() + 2
    if BS.Diag then BS.Diag("GESPERRT", "GetAuraDataByIndex " .. tostring(unit):gsub("%d+$", "N")) end
    if BS.NoteSecret then BS:NoteSecret() end
    return nil, false
end

-- Forever/Retail: was im Kampf nicht angezeigt wird (für Changelog, Optionen und Diagnose)
function BS:LockedText()
    return (BS.FLAVOR_NAMES[self.flavor] or L.THIS_CLIENT) .. L.NO_DISPLAY_OF_PROCS_COOLDOWNS ..
        L.BUFF_REMINDERS_WORK_BEFORE_THE
end

-- Einmaliger Hinweis, wenn im Kampf keine Daten kommen (pro Sitzung)
function BS:NoteSecret()
    if self.secretNoted then return end
    self.secretNoted = true
    BS.Print(L.IN_COMBAT .. (BS.FLAVOR_NAMES[self.flavor] or L.THIS_CLIENT_2) .. L.GIVES_ADDONS_NO_BUFF_OR)
end

BS.FLAVOR_NAMES = {
    era = "Classic Era / SoD / Hardcore", forever = "WoW Forever", tbc = "Burning Crusade Classic",
    wrath = "Wrath of the Lich King Classic", titan = "Titan Reforged", cata = "Cataclysm Classic",
    mists = "Mists of Pandaria Classic", retail = "Retail (Midnight)",
}

------------------------------------------------------------------------
-- Ausgabe
------------------------------------------------------------------------
function BS.Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cffffa733BuffSentinel|r: " .. tostring(msg))
end

------------------------------------------------------------------------
-- Spiel-Funktionen über eine eigene Tabelle (nur lesen)
--   BS.API.UnitBuff liefert im Spiel genau _G.UnitBuff. Nur die Testroutine setzt BS.apiOverride, um fehlende
--   alte Funktionen oder geschützte Werte nachzustellen – Blizzard-Funktionen selbst werden nie ersetzt.
------------------------------------------------------------------------
BS.NIL = {}            -- Platzhalter in BS.apiOverride: "diese Funktion fehlt"
BS.apiOverride = nil
BS.API = setmetatable({}, { __index = function(_, k)
    local o = BS.apiOverride
    if o then
        local v = o[k]
        if v ~= nil then
            if v == BS.NIL then return nil end
            return v
        end
    end
    return _G[k]
end })
local API = BS.API

-- Name einer Einheit nur dann als Text, wenn er nicht geschützt ist (sonst nil) – zum Verketten in Tooltips
function BS.SafeUnitName(raw)
    if BS.IsSecret(raw) or type(raw) ~= "string" then return nil end
    return raw
end

-- Tooltip-Zeile mit einem geschützten Namen: nur weiterreichen, nie verketten (Köderwerte der Testroutine auslassen)
function BS.TooltipRawName(raw, r, g, b)
    if BS.testSecrets then return end
    GameTooltip:AddLine(raw, r, g, b)
end

------------------------------------------------------------------------
-- API-Hilfen (funktionieren mit alter und neuer Client-API)
------------------------------------------------------------------------
-- Retail (Midnight) liefert im Kampf "geheime Werte", mit denen Addons nicht rechnen dürfen.
-- BS.testSecrets (nur Testroutine): Köderwerte, die wie geheime Werte behandelt werden.
function BS.IsSecret(v)
    if BS.testSecrets and v ~= nil and BS.testSecrets[v] then return true end
    if GoldSentinelGame then return GoldSentinelGame.IsSecret(v) end
    return issecretvalue ~= nil and v ~= nil and issecretvalue(v) == true
end

function BS.SpellInfo(spell)
    if spell == nil then return end
    if API.C_Spell and API.C_Spell.GetSpellInfo then
        local info = API.C_Spell.GetSpellInfo(spell)
        if info then return info.name, info.iconID, info.spellID end
        return
    end
    if API.GetSpellInfo then
        local name, _, icon, _, _, _, id = API.GetSpellInfo(spell)
        return name, icon, id
    end
end

function BS.GetCooldown(spell)
    if not spell then return 0, 0 end
    if API.C_Spell and API.C_Spell.GetSpellCooldown then
        local cd = API.C_Spell.GetSpellCooldown(spell)
        if cd and (BS.IsSecret(cd.startTime) or BS.IsSecret(cd.duration)) then
            return 0, 0, true          -- geheim: nicht "bereit" melden, Aufrufer prüft den 3. Wert
        end
        if cd then return cd.startTime or 0, cd.duration or 0 end
        return 0, 0
    end
    if API.GetSpellCooldown then
        local s, d = API.GetSpellCooldown(spell)
        return s or 0, d or 0
    end
    return 0, 0
end

function BS.IsUsable(spell)
    if not spell then return false, false end
    if API.C_Spell and API.C_Spell.IsSpellUsable then
        local usable, noMana = API.C_Spell.IsSpellUsable(spell)
        if BS.IsSecret(usable) then return false, false end
        return usable and true or false, noMana and true or false
    end
    if API.IsUsableSpell then
        local usable, noMana = API.IsUsableSpell(spell)
        return usable and true or false, noMana and true or false
    end
    return true, false
end

-- true = in Reichweite, false = ausser Reichweite, nil = keine Prüfung möglich
function BS.InRange(spell, unit)
    if not spell or not unit then return nil end
    local r
    if API.C_Spell and API.C_Spell.IsSpellInRange then
        r = API.C_Spell.IsSpellInRange(spell, unit)
    elseif API.IsSpellInRange then
        r = API.IsSpellInRange(spell, unit)
    end
    if r == nil or BS.IsSecret(r) then return nil end
    return (r == true or r == 1)
end

function BS.IsReady(spell)
    local s, d, secret = BS.GetCooldown(spell)
    if secret then return false end
    if not s or s == 0 or d <= BS.GCD_LIMIT then return true end
    return (s + d - GetTime()) <= 0.05
end

function BS.KnowsSpellID(id)
    if type(id) ~= "number" then return false end
    if API.IsPlayerSpell and API.IsPlayerSpell(id) then return true end
    if API.IsSpellKnown and API.IsSpellKnown(id) then return true end
    return false
end

-- Gegenstände (Gifte u. ä.)
function BS.ItemCount(id)
    if API.C_Item and API.C_Item.GetItemCount then return API.C_Item.GetItemCount(id) or 0 end
    if API.GetItemCount then return API.GetItemCount(id) or 0 end
    return 0
end

function BS.ItemIcon(id)
    if API.C_Item and API.C_Item.GetItemIconByID then return API.C_Item.GetItemIconByID(id) end
    if API.GetItemIcon then return API.GetItemIcon(id) end
end

function BS.ItemName(id)
    if API.C_Item and API.C_Item.GetItemNameByID then return API.C_Item.GetItemNameByID(id) end
    if API.GetItemInfo then return (API.GetItemInfo(id)) end
end

function BS.HasOffhandWeapon()
    if API.OffhandHasWeapon then return API.OffhandHasWeapon() and true or false end
    local link = API.GetInventoryItemLink and API.GetInventoryItemLink("player", 17)
    if not link then return false end
    local info = (API.C_Item and API.C_Item.GetItemInfoInstant) or API.GetItemInfoInstant
    if info then
        local classID = select(6, info(link))
        return classID == 2
    end
    return true
end

-- Füllt out[name] = spellId (oder true) für alle hilfreichen Auren einer Einheit
-- Forever/Retail: Auren gesperrt -> letzte bekannte Werte behalten (sonst gälten alle Buffs als fehlend)
local scanTmp = {}
function BS.ScanAuras(unit, out)
    out = out or {}
    if BS:AuraBlocked(unit) then return out end
    wipe(scanTmp)
    if not API.UnitExists(unit) then wipe(out); return out end
    for i = 1, 40 do
        if API.C_UnitAuras and API.C_UnitAuras.GetAuraDataByIndex then
            local a, allowed = BS.AuraByIndex(unit, i, "HELPFUL")
            if not allowed then return out end
            if not a then break end
            if a.name and not BS.IsSecret(a.name) then
                scanTmp[a.name] = (not BS.IsSecret(a.spellId) and a.spellId) or true
            end
        elseif API.UnitBuff then
            local name, _, _, _, _, _, _, _, _, spellId = API.UnitBuff(unit, i)
            if not name then break end
            scanTmp[name] = spellId or true
        else
            break
        end
    end
    wipe(out)
    for k, v in pairs(scanTmp) do out[k] = v end
    return out
end

function BS.HasAny(auras, names)
    if not auras or not names then return false end
    for n in pairs(names) do
        if auras[n] then return true end
    end
    return false
end

function BS.FormatTime(sec)
    if sec >= 60 then return string.format("%dm", math.floor(sec / 60 + 0.5)) end
    if sec < 3 then return string.format("%.1f", sec) end
    return string.format("%d", math.floor(sec + 0.5))
end

-- Grossbuchstaben inkl. Umlaute (strupper wandelt nur A-Z um: aus "stärke" würde sonst "STäRKE")
local UMLAUT_UPPER = { ["ä"] = "Ä", ["ö"] = "Ö", ["ü"] = "Ü", ["é"] = "É", ["è"] = "È", ["à"] = "À", ["ç"] = "Ç" }
function BS.Upper(text)
    text = strupper(text or "")
    for lower, upper in pairs(UMLAUT_UPPER) do text = text:gsub(lower, upper) end
    return text
end

function BS.Contains(list, value)
    if not list then return false end
    for _, v in ipairs(list) do
        if v == value then return true end
    end
    return false
end

-- Testmodus (alle Klassen durchschalten) nur für den Entwickler – siehe GoldSentinelDev.lua.
-- "Anordnen" (eigene Buttons verschieben) bleibt für alle.
function BS:IsDev()
    return GoldSentinelDev ~= nil and GoldSentinelDev:IsDev() == true
end

function BS:InCombat()
    return self:Lockdown() or UnitAffectingCombat("player") or self.testCombat == true
end

------------------------------------------------------------------------
-- Datenbank
------------------------------------------------------------------------
local DEFAULTS = {
    zones = {
        world     = true,   -- Offene Welt
        dungeon   = true,
        raid      = true,
        pvp       = true,   -- Schlachtfelder / Arena
        resting   = false,  -- Hauptstädte & Gasthäuser
        sanctuary = false,  -- Schutzgebiete
    },
    cdWorldCombatOnly = true,
    cdTimer = true,
    -- Töne standardmässig aus; einzelne Einträge können eine eigene Klingel haben (z. B. Schlachtruf)
    sound   = { buff = false, proc = false, cooldown = false, dispel = false },
    hornSelfBuff = true,   -- alt (bis 0.8.6), wird nach soundBase übernommen
    hornEvery    = 5,      -- Sekunden zwischen zwei Hupern
    soundBase    = {},     -- Warntöne: Standard für alle Skillungen (Sounds.lua)
    soundSpecs   = {},     -- Warntöne: Abweichungen pro Skillung
    soundChannel = "Master",
    dispel  = { friendly = true },   -- Reinigungsleiste für Mitspieler
    locked  = true,
    scale   = 1.0,
    groupScale = { proc = 1.0, buff = 1.0, cd = 1.0, dispel = 1.0 },   -- Grösse pro Gruppe (x Gesamtgrösse)
    minimap = { angle = 220, hide = false },
    pos     = {},   -- Position der Gruppen (Procs, Buffs, Cooldowns, Reinigen)
    btnPos  = {},   -- frei platzierte einzelne Buttons
    winPos  = {},   -- Fenster (Einstellungen, Gruppen-Raster, Test- und Anordnen-Leiste)
    -- Anordnung pro Gruppe: senkrecht statt waagrecht, zusätzlicher Abstand in Pixeln
    groupLayout = { proc = { vertical = false, gap = 0 }, buff = { vertical = false, gap = 0 }, cd = { vertical = false, gap = 0 } },
    specs   = {},   -- Einstellungen pro Skillung
    custom  = {},   -- eigene Procs aus der Aufnahme
}

BS.DEFAULTS = DEFAULTS   -- Testroutine (TU3 Standardwerte): nur lesen

-- BP-2026-11-13-1: Verzauberungs-IDs auf der Waffe. "foreign" = gemessen als fremde Verzauberung (z. B. Waffen-Totem),
-- "own" = gemessen als eigene. LEER, bis die Messung im Client (Diagnose-Zeilen "WAFFE …") vorliegt – nichts raten.
BS.WEAPON_ENCHANT = { own = {}, foreign = {} }
function BS.IsForeignWeaponEnchant(id)
    if type(id) ~= "number" or BS.IsSecret(id) then return false end
    local W = BS.WEAPON_ENCHANT
    return W.foreign[id] == true and not W.own[id]
end

-- Messung für BP-2026-11-13-1 (nur Schamane): Verzauberungs-IDs Haupt-/Nebenhand und aktive Totems ins
-- Diagnose-Protokoll, sobald sich etwas ändert (Fall a nur Imbue, b nur Totem, c beides). Keine Namen von Spielern.
function BS:MeasureWeaponEnchant()
    if self.class ~= "SHAMAN" or not BS.Diag then return end
    local ok, hasMH, _, _, mhID, hasOH, _, _, ohID = pcall(API.GetWeaponEnchantInfo)
    if not ok then return end
    local function v(has, id)
        if BS.IsSecret(has) or BS.IsSecret(id) then return "?" end
        if not has then return "-" end
        return tostring(id or "?")
    end
    local totems = {}
    if API.GetTotemInfo then
        for slot = 1, 4 do
            local okT, have, name = pcall(API.GetTotemInfo, slot)
            if okT and have and type(name) == "string" and not BS.IsSecret(name) and name ~= "" then totems[#totems + 1] = name end
        end
    end
    local line = string.format("mh=%s oh=%s totem=%s", v(hasMH, mhID), v(hasOH, ohID),
        #totems > 0 and table.concat(totems, "+") or "-")
    if line ~= self.lastWeaponLine then
        self.lastWeaponLine = line
        BS.Diag("WAFFE", line)
        -- Prüfliste: alle drei Fälle gesehen (nur Waffe, nur Totem, beides) -> Punkt WAFFE erledigt
        local mh, tot = v(hasMH, mhID) ~= "-", #totems > 0
        self.weaponCases = self.weaponCases or {}
        if mh and not tot then self.weaponCases.w = line end
        if tot and not mh then self.weaponCases.t = line end
        if mh and tot then self.weaponCases.b = line end
        local c = self.weaponCases
        if c.w and c.t and c.b then BS.PLHit("WAFFE", c.w .. " | " .. c.t .. " | " .. c.b) end
    end
end


-- Marktdaten-Netz (GoldSentinelMarkt, MN2/MN3). BuffSentinel liest selbst keine Auktionsdaten; die gemeinsame Datei
-- liest nur Vollscans mit, die ein anderes Addon oder der Spieler auslöst. Ohne die Datei: alles still aus.
function BS:MarketShareOn()
    local GM = GoldSentinelMarkt
    local db = GM and GM.hosts and GM.hosts.BuffSentinel
    if not db then return false end
    return not db.gsMarktAus
end

-- Ist das ganze Marktnetz an? (alle Schalter aller GoldSentinel-Addons, GoldSentinelMarkt.IsShareOn)
function BS:MarketNetOn()
    local GM = GoldSentinelMarkt
    if not (GM and GM.IsShareOn) then return false end
    local ok, on = pcall(GM.IsShareOn)
    return ok and on == true
end

function BS:SetMarketShare(on)
    local GM = GoldSentinelMarkt
    if GM and GM.SetShare then GM.SetShare("BuffSentinel", on and true or false) end
end

-- Zeile für Testbericht und Diagnose: Version, an/aus, mitgelesene Scans, gesendet/empfangen, Speicher (Items)
function BS:MarketLine()
    local GM = GoldSentinelMarkt
    if type(GM) ~= "table" or not GM.Stats then return "MARKT-NETZ: " .. L.MARKET_NOT_LOADED end
    local s = GM.Stats() or {}
    local items = 0
    local db = GM.hosts and GM.hosts.BuffSentinel
    for _, f in pairs((db and db.gsMarkt and db.gsMarkt.f) or {}) do
        for _ in pairs(f.i or {}) do items = items + 1 end
    end
    -- MN3a: eigener Schalter UND Netz-Zustand (ist er in einem anderen GoldSentinel-Addon aus, ist das Netz aus)
    local state = self:MarketShareOn() and L.ON or L.OFF
    if self:MarketShareOn() and not self:MarketNetOn() then state = L.ON .. " (" .. L.MARKET_NET_OFF_OTHER .. ")" end
    return string.format("MARKT-NETZ: v%s · %s · %s %d · %s %d/%d · %s %d", tostring(GM.VERSION),
        state, L.MARKET_SCANS, tonumber(s.scans) or 0,
        L.MARKET_SENT_RECEIVED, tonumber(s.sent) or 0, tonumber(s.received) or 0, L.MARKET_STORED_ITEMS, items)
end

-- Fehlende Werte ergänzen; Werte mit falschem Typ (beschädigte SavedVariables) durch den Standard ersetzen
local function CopyDefaults(src, dst)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then dst[k] = {} end
            CopyDefaults(v, dst[k])
        elseif dst[k] == nil or type(dst[k]) ~= type(v) then
            dst[k] = v
        end
    end
end

local function Tab(t, k)
    if type(t[k]) ~= "table" then t[k] = {} end
    return t[k]
end

-- Positionen { Punkt, Punkt, x, y }: unvollständige Einträge entfernen (sonst Fehler bei SetPoint)
local function CleanPositions(map)
    for k, p in pairs(map) do
        if type(p) ~= "table" or type(p[1]) ~= "string" or type(p[2]) ~= "string"
           or type(p[3]) ~= "number" or type(p[4]) ~= "number" then
            map[k] = nil
        end
    end
end

-- Beschädigte Einträge entfernen (nur Einträge mit falschem Typ – gültige Daten bleiben unverändert)
local function CleanProfile(db)
    CleanPositions(db.pos); CleanPositions(db.btnPos); CleanPositions(db.winPos)
    for k, v in pairs(db.groupScale) do if type(v) ~= "number" then db.groupScale[k] = 1.0 end end
    for k, store in pairs(db.specs) do
        if type(store) ~= "table" then db.specs[k] = nil
        else for key, e in pairs(store) do if type(e) ~= "table" then store[key] = nil end end end
    end
    for i = #db.custom, 1, -1 do
        local c = db.custom[i]
        if type(c) ~= "table" or type(c.aura) ~= "string" then tremove(db.custom, i) end
    end
    for k, v in pairs(db.soundBase) do if type(v) ~= "table" then db.soundBase[k] = nil end end
    for k, v in pairs(db.soundSpecs) do if type(v) ~= "table" then db.soundSpecs[k] = nil end end
end

local function CleanGlobal(g)
    for class, map in pairs(g.learned.talents) do
        if type(map) ~= "table" then g.learned.talents[class] = nil
        else for n, m in pairs(map) do if type(m) ~= "table" or type(m.pos) ~= "string" then map[n] = nil end end end
    end
    for n, m in pairs(g.learned.spells) do
        if type(m) ~= "table" or type(m.id) ~= "number" then g.learned.spells[n] = nil end
    end
    for class, c in pairs(g.auto.classes) do
        if type(c) ~= "table" then g.auto.classes[class] = nil
        else
            for _, f in ipairs({ "procs", "cds", "ignore", "cand" }) do
                local t = Tab(c, f)
                if f ~= "ignore" then for n, r in pairs(t) do if type(r) ~= "table" then t[n] = nil end end end
            end
        end
    end
    for i = #g.recorder.list, 1, -1 do
        if type(g.recorder.list[i]) ~= "string" then tremove(g.recorder.list, i) end
    end
    for n, r in pairs(g.recorder.seen) do
        if type(r) ~= "table" then g.recorder.seen[n] = nil end
    end
end

-- Profil pro Charakter ("Name-Realm"; nie in Testberichte schreiben)
function BS:ProfileKey()
    return (UnitName("player") or "?") .. "-" .. (GetRealmName() or "?")
end

function BS:InitDB()
    if type(BuffSentinelDB) ~= "table" then BuffSentinelDB = {} end
    local g = BuffSentinelDB
    Tab(g, "profiles")
    local rec = Tab(g, "recorder")
    Tab(rec, "list")
    Tab(rec, "seen")
    if type(rec.enabled) ~= "boolean" then rec.enabled = false end
    -- Gelernte Namen gelten für alle Charaktere des Accounts
    local learned = Tab(g, "learned")
    Tab(learned, "talents")
    Tab(learned, "spells")
    if type(g.shareNames) ~= "boolean" then g.shareNames = true end     -- Gilde + Gruppe
    if type(g.shareServer) ~= "boolean" then g.shareServer = true end   -- alle Nutzer auf dem Server (Sync-Kanal)
    if type(g.cmdHint) ~= "boolean" then g.cmdHint = true end           -- Befehlsliste beim Tippen (CmdHint.lua)
    if type(g.readyCheck) ~= "boolean" then g.readyCheck = true end     -- Zeile beim Bereitschaftscheck (BS-N1 Punkt 5)
    if type(g.restock) ~= "boolean" then g.restock = false end          -- Nachkaufen-Knopf beim Händler (BS-E1), Standard AUS
    if type(g.restockLimit) ~= "number" then g.restockLimit = 10000 end  -- Obergrenze je Kauf in Kupfer (Standard 1g)
    if type(g.rfHint) ~= "boolean" then g.rfHint = true end             -- Hinweis Zorn der Gerechtigkeit ohne Tank-Rolle (Paladin)
    if type(g.cmdUse) ~= "table" then g.cmdUse = {} end                 -- Zähler je Befehl (meistbenutzte oben)
    -- Automatisch gelernte Procs und Fähigkeiten (pro Klasse, für alle Charaktere des Accounts)
    local auto = Tab(g, "auto")
    Tab(auto, "classes")
    if type(auto.enabled) ~= "boolean" then auto.enabled = true end
    if type(auto.share) ~= "boolean" then auto.share = true end
    -- g.gsTest (Testberichte, GoldSentinelTest.lua) bleibt unangetastet
    CleanGlobal(g)

    local key = self:ProfileKey()
    if type(g.profiles[key]) ~= "table" then g.profiles[key] = {} end
    CopyDefaults(DEFAULTS, g.profiles[key])
    CleanProfile(g.profiles[key])

    self.gdb = g
    self.db  = g.profiles[key]
    -- 0.8.4: Töne neu standardmässig aus (einmalig auch für bestehende Profile)
    if not self.db.soundV2 then
        for k in pairs(self.db.sound) do self.db.sound[k] = false end
        self.db.soundV2 = true
    end
    if self.MigrateSounds then self:MigrateSounds() end
end

------------------------------------------------------------------------
-- Fenster: verschiebbar, Position wird gespeichert
------------------------------------------------------------------------
BS.windows = {}

function BS:PlaceWindow(key)
    local w = self.windows[key]
    if not w or not self.db then return end
    if self:Lockdown() and w.secure then return end
    local p = self.db.winPos[key] or w.default
    w.frame:ClearAllPoints()
    w.frame:SetPoint(p[1], UIParent, p[2], p[3], p[4])
end

-- default = { Punkt, UIParent-Punkt, x, y }; secure = Fenster mit Klick-Buttons (im Kampf gesperrt)
function BS:RegisterWindow(f, key, default, secure)
    self.windows[key] = { frame = f, default = default, secure = secure }
    f:SetMovable(true)
    f:EnableMouse(true)
    f:SetClampedToScreen(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(s)
        if not (secure and BS:Lockdown()) then s:StartMoving() end
    end)
    f:SetScript("OnDragStop", function(s)
        s:StopMovingOrSizing()
        if s.SetUserPlaced then s:SetUserPlaced(false) end
        local p1, _, p2, x, y = s:GetPoint()
        if p1 then BS.db.winPos[key] = { p1, p2, x, y } end
    end)
    self:PlaceWindow(key)
end

function BS:ResetWindows()
    wipe(self.db.winPos)
    for key in pairs(self.windows) do self:PlaceWindow(key) end
end

-- Jede Skillung hat eigene Einstellungen
function BS:EntryStore()
    -- Testmodus mit fremder Klasse: eigene Einstellungen nicht verändern
    if self.testClass then
        self.testStore = self.testStore or {}
        return self.testStore
    end
    local k = "spec" .. tostring(self.mainSpec or 0)
    self.db.specs[k] = self.db.specs[k] or {}
    return self.db.specs[k]
end

function BS:CountOverrides()
    local n = 0
    for _, s in pairs(self:EntryStore()) do
        if s.enabled ~= nil then n = n + 1 end
    end
    return n
end

function BS:ResetEntrySettings()
    wipe(self:EntryStore())
    self:SettingsChanged()
end

function BS:SetEntrySetting(key, field, value)
    local store = self:EntryStore()
    store[key] = store[key] or {}
    store[key][field] = value
    self:SettingsChanged()
end

------------------------------------------------------------------------
-- Zauberbuch
------------------------------------------------------------------------
-- known:       alle Zaubernamen im Zauberbuch (auch Allgemein/Volk)
-- classSpells: aktive Klassenzauber (ohne Allgemein, ohne passive, ohne andere Spezialisierungen) -> Spell-ID
-- Noch nicht erlernte Zauber (Cata/MoP/Retail zeigen sie grau im Zauberbuch) zählen nicht.
local function IsPassiveSlot(i, book, id)
    if API.IsPassiveSpell then
        local ok, p = pcall(API.IsPassiveSpell, i, book)
        if ok and p then return true end
    end
    if id and API.C_Spell and API.C_Spell.IsSpellPassive then
        local ok, p = pcall(API.C_Spell.IsSpellPassive, id)
        if ok and p then return true end
    end
    return false
end

function BS:ScanSpellbook()
    local known, classSpells, count = {}, {}, 0
    if API.C_SpellBook and API.C_SpellBook.GetNumSpellBookSkillLines then
        local bank = (Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player) or 0
        local FUTURE = Enum and Enum.SpellBookItemType and Enum.SpellBookItemType.FutureSpell
        for line = 1, API.C_SpellBook.GetNumSpellBookSkillLines() do
            local info = API.C_SpellBook.GetSpellBookSkillLineInfo(line)
            if info and not info.shouldHide and not (info.offSpecID and info.offSpecID ~= 0) then
                for i = info.itemIndexOffset + 1, info.itemIndexOffset + info.numSpellBookItems do
                    local name = API.C_SpellBook.GetSpellBookItemName(i, bank)
                    local item = API.C_SpellBook.GetSpellBookItemInfo and API.C_SpellBook.GetSpellBookItemInfo(i, bank)
                    local future = item and FUTURE and item.itemType == FUTURE
                    if name and not future then
                        known[name] = true; count = count + 1
                        if line > 1 and item and type(item.spellID) == "number" and not item.isPassive then
                            classSpells[name] = item.spellID
                        end
                    end
                end
            end
        end
    elseif API.GetNumSpellTabs then
        local book = BOOKTYPE_SPELL or "spell"
        for tab = 1, API.GetNumSpellTabs() do
            local _, _, offset, num, _, offSpec = API.GetSpellTabInfo(tab)
            if offset and num and not (offSpec and offSpec ~= 0) then
                for i = offset + 1, offset + num do
                    local name
                    if API.GetSpellBookItemName then
                        name = API.GetSpellBookItemName(i, book)
                    elseif API.GetSpellName then
                        name = API.GetSpellName(i, "spell")
                    end
                    local stype, sid
                    if API.GetSpellBookItemInfo then stype, sid = API.GetSpellBookItemInfo(i, book) end
                    if name and stype ~= "FUTURESPELL" then
                        known[name] = true; count = count + 1
                        if tab > 1 and type(sid) == "number" and stype ~= "FLYOUT" and not IsPassiveSlot(i, book, sid) then
                            classSpells[name] = sid
                        end
                    end
                end
            end
        end
    end
    self.known = known
    self.classSpells = classSpells
    self.spellbookOK = count > 0
end

function BS:IsKnown(name)
    if not name then return false end
    if self.testClass then return true end   -- Testmodus mit fremder Klasse: alles "gelernt"
    if not self.spellbookOK then return true end -- Fallback: Zauberbuch nicht lesbar
    return self.known[name] == true
end

------------------------------------------------------------------------
-- Talente / Spezialisierung
------------------------------------------------------------------------
-- Classic-Familie (Era, Forever, TBC, Wrath, Titan, Cata): Talentbäume.
-- Die Position (Baum:Reihe:Spalte) ist in jeder Client-Sprache gleich und dient zum Lernen der Namen.
function BS:ScanTalentTrees()
    local talents, list, points, sig = {}, {}, { 0, 0, 0 }, {}
    local all, byName, byPos = {}, {}, {}
    local tabs = 0
    -- Zweitskillung: ausdrücklich die aktive Talentgruppe lesen
    local group = nil
    if API.GetActiveTalentGroup then
        local ok, g = pcall(API.GetActiveTalentGroup, false, false)
        if ok and type(g) == "number" then group = g end
    end
    if API.GetNumTalentTabs and API.GetTalentInfo then
        tabs = API.GetNumTalentTabs() or 0
        for tab = 1, tabs do
            points[tab] = points[tab] or 0
            for i = 1, (API.GetNumTalents(tab) or 0) do
                local name, icon, tier, column, rank, maxRank
                if group then
                    name, icon, tier, column, rank, maxRank = API.GetTalentInfo(tab, i, false, false, group)
                else
                    name, icon, tier, column, rank, maxRank = API.GetTalentInfo(tab, i)
                end
                if type(name) == "string" then
                    rank = rank or 0
                    local t = {
                        name = name, icon = icon, rank = rank, maxRank = maxRank or rank, tab = tab,
                        tier = tier or 0, column = column or 0,
                        pos = tab .. ":" .. (tier or 0) .. ":" .. (column or 0),
                    }
                    tinsert(all, t)
                    byName[strlower(name)] = t
                    byPos[t.pos] = t
                    if rank > 0 then
                        talents[strlower(name)] = rank
                        points[tab] = points[tab] + rank
                        tinsert(list, t)
                        tinsert(sig, name .. rank)
                    end
                end
            end
        end
    end
    local main, best = 0, 0
    for tab = 1, 3 do
        if (points[tab] or 0) > best then best = points[tab]; main = tab end
    end
    -- Nur Cataclysm hat einen gewählten Hauptbaum. Andere Clients (z. B. TBC Anniversary) kennen die
    -- Funktion teils auch, liefern dort aber keinen sinnvollen Wert -> dort zählt der Baum mit den meisten Punkten.
    if self.expansion == 4 and API.GetPrimaryTalentTree then
        local ok, primary = pcall(API.GetPrimaryTalentTree)
        if ok and type(primary) == "number" and primary > 0 then main = primary end
    end
    self.talents, self.talentList, self.points, self.mainSpec = talents, list, points, main
    self.allTalents, self.talentByName, self.talentByPos = all, byName, byPos
    self.talentsReadable = tabs > 0
    self.talentSig = main .. "|" .. table.concat(sig, ",")
end

-- Moderne Familie (MoP, Retail): Spezialisierung + Talente werden über Zauber-IDs geprüft
function BS:ScanSpecialization()
    local spec = (API.GetSpecialization and API.GetSpecialization()) or 0
    spec = spec or 0
    local list, talents = {}, {}

    -- MoP Classic: gewählte Talente (je Reihe eines) für die Anzeige auslesen
    if not self.isRetail and API.GetTalentInfo then
        local group = (API.GetActiveSpecGroup and API.GetActiveSpecGroup()) or 1
        for tier = 1, 6 do
            for col = 1, 3 do
                local ok, a, b, c, d = pcall(API.GetTalentInfo, tier, col, group)
                if ok and type(a) == "number" and type(b) == "string" and d then
                    tinsert(list, { name = b, icon = c, rank = 1, maxRank = 1, tab = 1, tier = tier, column = col })
                    talents[strlower(b)] = 1
                end
            end
        end
        if #list == 0 then
            -- alte Signatur: API.GetTalentInfo(index) -> name, icon, tier, column, selected
            for i = 1, 18 do
                local ok, name, icon, tier, col, selected = pcall(API.GetTalentInfo, i)
                if ok and type(name) == "string" and selected then
                    tinsert(list, { name = name, icon = icon, rank = 1, maxRank = 1, tab = 1, tier = tier, column = col })
                    talents[strlower(name)] = 1
                end
            end
        end
    end

    -- Signatur aus Spezialisierung + allen in den Daten genutzten Talent-Zaubern
    local bits = {}
    local data = self.ClassData[self.class]
    if data then
        for _, d in ipairs(data.entries) do
            for _, field in ipairs({ "talentSpell", "enableIfTalentSpell" }) do
                local v = d[field]
                if type(v) == "number" then v = { v } end
                if type(v) == "table" then
                    for _, id in ipairs(v) do tinsert(bits, BS.KnowsSpellID(id) and "1" or "0") end
                end
            end
        end
    end
    for _, t in ipairs(list) do tinsert(bits, t.name) end

    self.mainSpec = spec
    self.points = { 0, 0, 0 }
    self.talents, self.talentList = talents, list
    self.allTalents, self.talentByName, self.talentByPos = {}, {}, {}
    self.talentsReadable = false   -- keine Talentbäume -> keine Namens-Zuordnung nötig
    self.talentSig = "spec" .. spec .. "|" .. table.concat(bits, ",")
end

function BS:ScanTalents()
    if self.family == "modern" then
        self:ScanSpecialization()
    else
        self:ScanTalentTrees()
    end
end

-- Gibt den (lokalen) Namen des ersten geskillten Talents aus der Liste zurück (oder nil).
-- Englische Namen werden über gelernte Zuordnungen in die Client-Sprache übersetzt.
function BS:HasTalent(list)
    if not list then return nil end
    for _, n in ipairs(list) do
        if self.talents[strlower(n)] then return n end
        local loc = self.LocalTalentName and self:LocalTalentName(n)
        if loc and self.talents[strlower(loc)] then return loc end
    end
    return nil
end

-- Talent über Zauber-ID (MoP/Retail – sprachunabhängig)
function BS:HasTalentSpell(list)
    if not list then return nil end
    if type(list) ~= "table" then list = { list } end
    for _, id in ipairs(list) do
        if BS.KnowsSpellID(id) then return (BS.SpellInfo(id)) or tostring(id) end
    end
    return nil
end

function BS:SpecName(index)
    if not index or index == 0 then return nil end
    if self.family == "modern" and GetSpecializationInfo and not self.testClass then
        local ok, _, name = pcall(GetSpecializationInfo, index)
        if ok and type(name) == "string" then return name end
    end
    local data = self.ClassData[self.class]
    if not data then return nil end
    local names = (self.family == "modern" and data.specNamesModern) or data.specNames
    return names and names[index] or nil
end

function BS:SpecText()
    local name = self:SpecName(self.mainSpec) or L.NO_SPECIALIZATION_YET
    if self.family == "modern" then return name end
    local p = self.points
    return string.format("%s (%d/%d/%d)", name, p[1] or 0, p[2] or 0, p[3] or 0)
end

------------------------------------------------------------------------
-- Einträge der Klasse auflösen (Version, Namen, Icons, bekannt, empfohlen)
------------------------------------------------------------------------
-- Gilt ein Eintrag für die laufende WoW-Version?
--   v = "classic" (Standard) | "modern" | "all";  min/max = Erweiterung;  forever / noForever;  retail = true
function BS:EntryAvailable(d)
    local v = d.v or "classic"
    if v ~= "all" and v ~= self.family then return false end
    -- alsoForever: gibt es erst ab Erweiterung "min", in WoW Forever aber schon (z. B. Hot Streak)
    if d.min and self.expansion < d.min and not (d.alsoForever and self.isForever) then return false end
    if d.max and self.expansion > d.max then return false end
    if d.forever and not self.isForever then return false end
    if d.noForever and self.isForever then return false end
    if self.isRetail then
        -- Retail: Buffs und Procs sind im Kampf für Addons unlesbar -> nur Buff-Erinnerungen ausserhalb des Kampfes
        if d.kind ~= "buff" then return false end
        if not d.retail then return false end
    elseif d.retailOnly then
        return false
    end
    return true
end

function BS:ResolveSpell(spell)
    if type(spell) == "table" then
        local firstName, firstIcon
        for _, s in ipairs(spell) do
            local name, icon = self:ResolveSpell(s)
            if name then
                if not firstName then firstName, firstIcon = name, icon end
                if self:IsKnown(name) then return name, icon end
            end
        end
        return firstName, firstIcon
    end
    if type(spell) == "string" and self.LocalSpellName then
        local loc = self:LocalSpellName(spell)
        local name, icon = BS.SpellInfo(loc or spell)
        return name or loc or spell, icon
    end
    local name, icon = BS.SpellInfo(spell)
    if not name and type(spell) == "string" then name = spell end
    return name, icon
end

local function NameOf(spell)
    if type(spell) == "number" then
        local n = BS.SpellInfo(spell)
        return n
    end
    if type(spell) == "string" and BS.LocalSpellName then
        return BS:LocalSpellName(spell) or spell
    end
    return spell
end

function BS:SpecList(specs)
    local t = {}
    for _, s in ipairs(specs) do tinsert(t, self:SpecName(s) or (L.TREE .. s)) end
    return table.concat(t, "/")
end

local function FirstTalentName(d)
    if d.talents then return d.talents[1] end
    local ts = d.talentSpell
    if type(ts) == "table" then ts = ts[1] end
    if ts then return (BS.SpellInfo(ts)) or ("Talent " .. ts) end
    return "?"
end

-- Status-Text, warum ein Eintrag aktiv/inaktiv ist (wird im Optionsfenster angezeigt)
function BS:EntryStatus(e)
    local d, C = e.data, BS.COLORS
    if not e.known then
        if d.forever then return L.NOT_LEARNED_WOW_FOREVER_ONLY, C.dim end
        return L.NOT_LEARNED, C.dim
    end
    if d.auto then
        local src = (d.auto.src == "net") and (L.SHARED_BY .. (d.auto.from or "?")) or L.LEARNED_AUTOMATICALLY
        if d.specs and not e.specOK then
            return src .. L.MEANT_FOR .. self:SpecList(d.specs) .. L.CAN_BE_ENABLED_MANUALLY, C.dim
        end
        return src, C.green
    end
    if d.custom then
        if d.alertOnly then return L.OWN_PROC_ALERT_ONLY, C.green end
        return L.OWN_PROC_CLICK_CASTS .. (e.spellName or "?"), C.green
    end
    if d.supply then
        return string.format(L.SUPPLY_STATUS, d.supply.low or 0), C.green
    end
    if d.durability then
        return string.format(L.DURA_STATUS, d.durability.low or 0), C.green
    end
    if d.pet then
        if e.petSkip then return L.PET_STATUS_SKIP, C.dim end
        return L.PET_STATUS, C.green
    end
    if d.items then
        if e.itemName then return L.POISON_ITEM .. e.itemName, C.green end
        return L.NO_MATCHING_ITEM_IN_YOUR, C.yellow
    end
    if d.talents or d.talentSpell then
        if e.talentMatch then return L.TALENT_LEARNED .. e.talentMatch, C.green end
        if d.talents then
            local loc = self.ResolveTalentList and self:ResolveTalentList(d.talents)
            if not loc and self.talentsReadable then
                return L.UNKNOWN_TALENT_NAME .. d.talents[1] .. L.ASSIGN_IT_ON_THE_SPEC, C.yellow
            end
            return L.TALENT_NOT_LEARNED .. (loc or d.talents[1]) .. L.CAN_BE_ENABLED_MANUALLY_2, C.yellow
        end
        return L.TALENT_NOT_LEARNED .. FirstTalentName(d) .. L.CAN_BE_ENABLED_MANUALLY_2, C.yellow
    end
    if e.viaTalent and not e.specOK then return L.ACTIVE_THROUGH_TALENT .. e.viaTalent, C.green end
    if d.optional then return L.OPTIONAL_CAN_BE_ENABLED_MANUALLY, C.dim end
    if d.specs then
        if self.mainSpec == 0 then return L.NO_SPECIALIZATION_YET_ACTIVE_FOR, C.yellow end
        if e.specOK then return L.RECOMMENDED_FOR .. (self:SpecName(self.mainSpec) or "?"), C.green end
        return L.MEANT_FOR_2 .. self:SpecList(d.specs) .. L.CAN_BE_ENABLED_MANUALLY_2, C.dim
    end
    return L.FOR_ALL_SPECS, C.green
end

-- Gestalten des Druiden: Position in der Gestaltleiste (ändert sich nur, wenn eine Gestalt dazugelernt wird)
local FORM_IDS = { cat = { 768 }, bear = { 5487, 9634 } }
function BS:ShapeshiftIndex(form)
    local ids = FORM_IDS[form]
    if not ids or not GetNumShapeshiftForms or not GetShapeshiftFormInfo then return nil end
    local names = {}
    for _, id in ipairs(ids) do local n = BS.SpellInfo(id); if n then names[n] = true end end
    for i = 1, (GetNumShapeshiftForms() or 0) do
        local r = { GetShapeshiftFormInfo(i) }
        local sid = r[4]
        if type(sid) == "number" then
            for _, id in ipairs(ids) do if sid == id then return i end end
            local n = BS.SpellInfo(sid)
            if n and names[n] then return i end
        end
        -- ältere Clients: zweiter Rückgabewert ist der Name
        if type(r[2]) == "string" and names[r[2]] then return i end
    end
    return nil
end

-- Bestes vorhandenes Item aus einer Liste (z. B. höchster Giftrang in den Taschen)
function BS:BestItem(items)
    for _, id in ipairs(items) do
        if BS.ItemCount(id) > 0 then return id end
    end
    return nil
end

------------------------------------------------------------------------
-- Vorrat (BS-N1, 0.9.23): Munition des Jägers, Seelensplitter des Hexenmeisters (Classic bis Wrath)
--   Gezählt wird nur bei Taschen-/Ausrüstungs-Ereignissen und beim Neuaufbau (BS:UpdateSupply), nie je Bild.
--   Die Anzeige liest nur den gespeicherten Zähler (BS.supplyCount) und erscheint nur ausserhalb des Kampfes.
------------------------------------------------------------------------
-- Haltbarkeit (BS-N1 Punkt 4): nur in Hauptstadt/Gasthaus/Schutzgebiet (dort kann man reparieren), unabhängig von der
-- Zonen-Einstellung der Buffs; Prozent des am stärksten beschädigten Gegenstands, gelesen nur beim Ereignis
BS.COMMON_ENTRIES = {
    { key = "durability", kind = "buff", v = "all", retail = true, alertOnly = true, durability = { low = 30 },
      label = L.DURA_LABEL, alert = L.ALERT_DURA, icon = "Interface\\Icons\\Trade_BlackSmithing" },
    -- Getränke für Manaklassen (Spieldaten BuffSentinelVorratDaten.lua <zweig>.getraenke = Items mit Benutz-Zauber "Trinken"),
    -- unter 10 -> Warnung; ab Stufe 10 (vorher trinkt man kaum); Classic bis Wrath
    { key = "drinks", kind = "buff", v = "classic", max = 3, alertOnly = true, iconItem = 159,
      classes = { MAGE = true, PRIEST = true, WARLOCK = true, DRUID = true, SHAMAN = true, PALADIN = true, HUNTER = true },
      label = L.SUPPLY_DRINKS, alert = L.ALERT_DRINKS, supply = { drinks = true, low = 10, minLevel = 10, hint = L.SUPPLY_HINT_DRINKS } },
}
BS.duraPct = nil

-- Zweig der Spieldaten für die aktuelle Spielversion (BuffSentinelVorratDaten): forever -> wowf, era -> era, tbc -> tbc,
-- wrath/titan -> wrath; sonst nil (keine Daten -> keine Getränke-Erinnerung)
BS.DATA_BRANCH = { forever = "wowf", era = "era", tbc = "tbc", wrath = "wrath", titan = "wrath" }
function BS:DrinkSet()
    local D = BuffSentinelVorratDaten
    local b = D and BS.DATA_BRANCH[self.flavor or ""]
    local list = b and D[b] and D[b].getraenke
    if type(list) ~= "table" then return nil end
    if self.drinkSetFor ~= b then
        local set = {}
        for _, id in ipairs(list) do set[id] = true end
        self.drinkSet, self.drinkSetFor = set, b
    end
    return self.drinkSet
end

function BS:UpdateDurability()
    local f = API.GetInventoryItemDurability
    if not f then self.duraPct = nil; return end
    local minPct
    for slot = 1, 18 do
        local ok, cur, max = pcall(f, slot)
        if ok and type(cur) == "number" and type(max) == "number" and not BS.IsSecret(cur) and not BS.IsSecret(max)
            and max > 0 then
            local p = math.floor(cur / max * 100)
            if not minPct or p < minPct then minPct = p end
        end
    end
    self.duraPct = minPct
end

BS.PET_GRACE = 3           -- Sekunden ohne Begleiter, bevor die Erinnerung kommt (Absteigen, Landen, Zonenwechsel)
BS.AMMO_SUBCLASS = { [2] = true, [3] = true, [18] = true }   -- Bogen, Schusswaffe, Armbrust (Waffenklasse 2)
BS.supplyCount = {}

-- Zähler für einen Vorrat; nil = gilt gerade nicht (z. B. Jäger mit Wurfwaffe oder Zauberstab, Funktion fehlt)
function BS:SupplyCount(sp)
    if type(sp) ~= "table" then return nil end
    if sp.ammo then
        local ranged = API.GetInventoryItemID and API.GetInventoryItemID("player", 18)
        if not ranged then return nil end
        local info = (API.C_Item and API.C_Item.GetItemInfoInstant) or API.GetItemInfoInstant
        if not info then return nil end
        local ok, _, _, _, _, _, classID, subID = pcall(info, ranged)
        if not ok or classID ~= 2 or not BS.AMMO_SUBCLASS[subID] then return nil end
        -- Gibt es im Client überhaupt einen Munitionsplatz? Sonst nichts melden (kein Fehlalarm "leer")
        local okSlot, slot = pcall(API.GetInventorySlotInfo or error, "AMMOSLOT")
        if not okSlot or slot ~= 0 then return nil end
        -- leerer Munitionsplatz = keine Munition mehr
        if not API.GetInventoryItemID("player", 0) then return 0 end
        local n = API.GetInventoryItemCount and API.GetInventoryItemCount("player", 0)
        if BS.IsSecret(n) then return nil end
        return tonumber(n) or 0
    end
    -- Irgendeiner von mehreren Gegenständen (z. B. alle Gesundheitssteine aller Ränge und Talentstufen, BS-N1 Punkt 3):
    -- Summe über alle IDs der Liste (shared/wissen/daten/gesundheitssteine.md, Vereinigung aller Spielzweige; IDs, die es im
    -- Zweig nicht gibt, zählen 0)
    if sp.petfood then return BS:PetFoodCount() end
    if sp.shardSpace then return BS:ShardSpace() end
    if sp.poisons then
        -- alle Waffengifte des Zweigs (BuffSentinelGifte.lua, alle Typen und Ränge, auch "saison") zusammen
        local G = BuffSentinelGifte
        local br = G and BS.DATA_BRANCH[BS.flavor or ""]
        local tab = br and G[br]
        if type(tab) ~= "table" then return nil end
        local set = {}
        for _, list in pairs(tab) do for _, id in ipairs(list) do set[id] = true end end
        local total = 0
        if not BS.ForEachBagItem(function(id, count) if set[id] then total = total + count end end) then return nil end
        return total
    end
    if sp.drinks then
        local set = BS:DrinkSet()
        if not set then return nil end
        local total = 0
        if not BS.ForEachBagItem(function(id, count) if set[id] then total = total + count end end) then return nil end
        return total
    end
    if sp.anyOf then
        local total = 0
        for _, id in ipairs(sp.anyOf) do
            local n = BS.ItemCount(id)
            if BS.IsSecret(n) then return nil end
            total = total + (tonumber(n) or 0)
        end
        return total
    end
    -- Reagenz nach dem HÖCHSTEN gelernten Rang (Tabelle shared/wissen/daten/reagenzien-gruppenbuffs.md, wago.tools):
    -- ranks = { { Zauber-ID, Item-ID }, … } vom höchsten zum tiefsten Rang
    local item = sp.item
    if sp.ranks then
        item = nil
        for _, r in ipairs(sp.ranks) do
            if BS.KnowsSpellID(r[1]) then item = r[2]; break end
        end
    end
    if item then
        local n = BS.ItemCount(item)
        if BS.IsSecret(n) then return nil end
        return tonumber(n) or 0, item
    end
    return nil
end

-- Jeden Gegenstand in den Taschen 0–4 einmal melden: fn(itemID, Anzahl). Neue (C_Container) und alte Schnittstelle.
function BS.ForEachBagItem(fn)
    local CC = API.C_Container
    local numSlots = (CC and CC.GetContainerNumSlots) or API.GetContainerNumSlots
    local itemID = (CC and CC.GetContainerItemID) or API.GetContainerItemID
    if not numSlots or not itemID then return false end
    for bag = 0, 4 do
        local n = tonumber(numSlots(bag)) or 0
        for slot = 1, n do
            local id = itemID(bag, slot)
            if id then
                local count
                if CC and CC.GetContainerItemInfo then
                    local info = CC.GetContainerItemInfo(bag, slot)
                    count = type(info) == "table" and info.stackCount or nil
                elseif API.GetContainerItemInfo then
                    local _, c = API.GetContainerItemInfo(bag, slot)
                    count = c
                end
                fn(id, tonumber(count) or 1)
            end
        end
    end
    return true
end

-- Freie Plätze für Seelensplitter (Spieldaten bs-n1-rest.md Abschnitt 1: Item 6265 hat BagFamily 4 in allen Zweigen):
-- Taschen 0–4 mit bagType 0 (normale Tasche) oder mit Bit 4 (Seelentasche). nil = Spiel-Funktion fehlt.
function BS:ShardSpace()
    local CC = API.C_Container
    local f = (CC and CC.GetContainerNumFreeSlots) or API.GetContainerNumFreeSlots
    if not f then return nil end
    local free = 0
    for bag = 0, 4 do
        local ok, n, bagType = pcall(f, bag)
        if ok and type(n) == "number" then
            bagType = tonumber(bagType) or 0
            if bagType == 0 or math.floor(bagType / 4) % 2 == 1 then free = free + n end
        end
    end
    return free
end

-- Tierfutter (nur WoW Forever – nur dort stehen die Futterarten in den Spieldaten, BuffSentinelVorratDaten.lua):
-- Futter in den Taschen, das der aktuelle Begleiter frisst (GetPetFoodTypes, Namen deDE/enUS laut Daten)
function BS:PetFoodCount()
    local D = BuffSentinelVorratDaten
    local tab = D and D.wowf and D.wowf.futter
    if type(tab) ~= "table" or not API.GetPetFoodTypes or not API.UnitExists("pet") then return nil end
    local lang = (BS.locale == "deDE") and "deDE" or ((BS.locale == "enUS" or BS.locale == "enGB") and "enUS" or nil)
    local names = lang and D.futterNamen and D.futterNamen[lang]
    if type(names) ~= "table" then return nil end
    local index = {}
    for i, n in ipairs(names) do index[n] = i end
    local res = { pcall(API.GetPetFoodTypes) }
    if not res[1] then return nil end
    local want, any = {}, false
    for i = 2, #res do
        local id = type(res[i]) == "string" and index[res[i]]
        if id then want[id] = true; any = true end
    end
    if not any then return nil end
    local total = 0
    local ok = BS.ForEachBagItem(function(id, count)
        local t = tab[id]
        if t and want[t] then total = total + count end
    end)
    if not ok then return nil end
    return total
end

-- Seelenstein in der Gruppe (Spieldaten bs-vorrat-naechste-punkte.md Abschnitt 4): hat irgendein Gruppenmitglied (auch man
-- selbst) die Aura "Seelenstein-Auferstehung"? Nur über Zauber-IDs, nie über Namen. Ergebnis BS.soulstoneState:
--   nil = nicht anwendbar/unbekannt (allein, im Kampf, Aura ohne ID) -> keine Anzeige · true = vorhanden · false = fehlt
BS.SOULSTONE_AURAS = { [20707] = true, [20762] = true, [20763] = true, [20764] = true, [20765] = true, [27239] = true, [47883] = true }
local soulTmp = {}
function BS:CheckSoulstone()
    if self:CombatLocked() or API.UnitAffectingCombat("player") then self.soulstoneState = nil; return end
    local units = self:GetGroupUnits()
    if type(units) ~= "table" or #units <= 1 then self.soulstoneState = nil; return end
    local unknown = false
    for _, u in ipairs(units) do
        if API.UnitExists(u) then
            BS.ScanAuras(u, soulTmp)
            for _, id in pairs(soulTmp) do
                if id == true then unknown = true
                elseif BS.SOULSTONE_AURAS[id] then self.soulstoneState = true; return end
            end
        end
    end
    -- Auren ohne Zauber-ID (nicht prüfbar) -> lieber nichts melden als falsch "fehlt"
    if unknown then self.soulstoneState = nil else self.soulstoneState = false end
end

-- Zorn der Gerechtigkeit ohne Tank-Rolle (Paladin, Spieldaten bs-n1-rest.md Abschnitt 5, Vorgaben Supervisor 22:48):
-- in einer Gruppe, Skillung bekannt und NICHT Schutz (2), keine Tank-Rolle (UnitGroupRolesAssigned) und kein Haupttank
-- (GetPartyAssignment), Aura aktiv (nur Zauber-IDs) -> EINE Zeile im eigenen Chat, einmal je Gruppe. Schalter gdb.rfHint.
BS.RF_AURAS = { [25780] = true, [25781] = true, [20450] = true, [407627] = true, [407628] = true }
function BS:CheckRighteousFury()
    if self.class ~= "PALADIN" or not self.gdb or self.gdb.rfHint == false then return end
    local units = self:GetGroupUnits()
    if type(units) ~= "table" or #units <= 1 then self.rfHinted = nil; return end      -- Gruppe verlassen -> wieder scharf
    if self.rfHinted then return end
    if (self.mainSpec or 0) == 0 or self.mainSpec == 2 then return end
    if API.UnitGroupRolesAssigned then
        local ok, role = pcall(API.UnitGroupRolesAssigned, "player")
        if not ok or BS.IsSecret(role) or role == "TANK" then return end
    end
    if API.GetPartyAssignment then
        local ok, mt = pcall(API.GetPartyAssignment, "MAINTANK", "player")
        if not ok or BS.IsSecret(mt) or mt then return end
    end
    local active = false
    for _, a in pairs(self.playerAuraInfo or {}) do
        if type(a) == "table" and type(a.id) == "number" and BS.RF_AURAS[a.id] then active = true; break end
    end
    if not active then return end
    self.rfHinted = true
    BS.Print(L.RF_HINT)
    BS.PLHit("RF", "Skillung " .. tostring(self.mainSpec))
end

-- Totems im Gepäck (Schamane, Spieldaten bs-n1-rest.md Abschnitt 4 + BuffSentinelTotems.lua): Element gilt als nötig, wenn ein
-- Zauber des Elements gelernt ist; vorhanden, wenn das Totem-Item ODER ein Meistertotem (Kategorie 21, nur TBC/Wrath) in den Taschen
-- liegt oder im Relikt-Platz angelegt ist (Relikt-Platz: Verdacht, im Client prüfen). Ergebnis: Liste der fehlenden Elemente.
BS.TOTEM_ELEMENTS = { { key = "erde", item = 5175 }, { key = "feuer", item = 5176 }, { key = "wasser", item = 5177 }, { key = "luft", item = 5178 } }
BS.TOTEM_MASTERS = { tbc = { 1500 }, wrath = { 1500, 22345, 22395, 22396, 23005, 23199 } }
function BS:TotemMissing()
    local T = BuffSentinelTotems
    local b = BS.DATA_BRANCH[self.flavor or ""]
    local spells = T and b and T[b]
    if type(spells) ~= "table" then return nil end
    local master = false
    for _, id in ipairs(BS.TOTEM_MASTERS[b] or {}) do
        if BS.ItemCount(id) > 0 then master = true; break end
    end
    if not master and API.GetInventoryItemID then
        local relic = API.GetInventoryItemID("player", 18)
        for _, id in ipairs(BS.TOTEM_MASTERS[b] or {}) do if relic == id then master = true; break end end
    end
    local missing = {}
    for _, el in ipairs(BS.TOTEM_ELEMENTS) do
        local need = false
        for _, sid in ipairs(spells[el.key] or {}) do if BS.KnowsSpellID(sid) then need = true; break end end
        if need and not master and BS.ItemCount(el.item) <= 0 then missing[#missing + 1] = el.key end
    end
    return missing
end

-- Alle Vorrats-Einträge neu zählen (Ereignisse BAG_UPDATE_DELAYED, UNIT_INVENTORY_CHANGED, Neuaufbau)
function BS:UpdateSupply()
    local t, items = {}, {}
    for _, e in ipairs(self.entries or {}) do
        local sp = e.data and e.data.supply
        if sp then
            local ok, n, item = pcall(self.SupplyCount, self, sp)
            if ok then t[e.key] = n; items[e.key] = item or sp.item end
        end
    end
    self.supplyCount, self.supplyItem = t, items
    -- Totems (eigener Baustein, gleicher Takt)
    self.totemMissing = nil
    for _, e in ipairs(self.entries or {}) do
        if e.data and e.data.totems and e.enabled then
            local okT, list = pcall(self.TotemMissing, self)
            if okT then self.totemMissing = list end
        end
    end
    -- Reagenzien für Gruppenbuffs nur in einer Gruppe (BS-N1 Punkt 1); neu gezählt beim Gruppenwechsel (Layout)
    local ok, units = pcall(self.GetGroupUnits, self)
    self.supplyInGroup = ok and type(units) == "table" and #units > 1 or false
end

function BS:ResolveEntries()
    wipe(self.entries)
    self.autoCoveredCache = nil
    local data  = self.ClassData[self.class]
    local store = self:EntryStore()

    local list = {}
    if data then
        for _, d in ipairs(data.entries) do
            if self:EntryAvailable(d) then tinsert(list, d) end
        end
        -- Einträge für alle Klassen (z. B. Haltbarkeit, BS-N1 Punkt 4); classes = nur für diese Klassen
        for _, d in ipairs(BS.COMMON_ENTRIES) do
            if self:EntryAvailable(d) and (not d.classes or d.classes[self.class]) then tinsert(list, d) end
        end
    end
    if not self.isRetail and not self.testClass then
        for _, c in ipairs(self.db.custom) do
            local spell = (c.spell and c.spell ~= "") and c.spell or nil
            tinsert(list, {
                key = "custom:" .. c.aura, kind = "proc", custom = c, v = "all",
                spell = spell, procAuras = { c.aura }, iconSpell = c.auraId,
                alertOnly = (spell == nil), label = c.aura,
            })
        end
        -- Automatisch gelernte Procs und Fähigkeiten (AutoLearn.lua)
        if self.AutoEntries then
            for _, d in ipairs(self:AutoEntries()) do tinsert(list, d) end
        end
    end

    for _, d in ipairs(list) do
        local e = { data = d, key = d.key, kind = d.kind }

        -- Skillungsabhängiger Zauber (z. B. Freizauber: Arkan -> Arkane Geschosse, Feuer -> Feuerball)
        local spell = d.spell
        if d.spellBySpec and d.spellBySpec[self.mainSpec] then spell = d.spellBySpec[self.mainSpec] end
        if spell then e.spellName, e.icon = self:ResolveSpell(spell) end
        -- Zauber je nach Gestalt (z. B. Freizauber: Katze -> Schreddern, Bär -> Zermalmen)
        local fs = d.formSpellsBySpec and d.formSpellsBySpec[self.mainSpec]
        if fs and not self.testClass then
            e.formMap = {}
            for _, form in ipairs({ "cat", "bear" }) do
                local idx = fs[form] and self:ShapeshiftIndex(form)
                local n = idx and self:ResolveSpell(fs[form])
                if n and self:IsKnown(n) then e.formMap[idx] = n end
            end
            if not next(e.formMap) then e.formMap = nil end
        end

        if d.items then
            e.itemID = self:BestItem(d.items)
            e.itemName = e.itemID and BS.ItemName(e.itemID) or nil
            e.icon = (e.itemID and BS.ItemIcon(e.itemID)) or BS.ItemIcon(d.items[#d.items]) or d.icon
        end
        if not e.icon and d.iconSpell then local _, ic = BS.SpellInfo(d.iconSpell); e.icon = ic end
        if not e.icon and d.iconItem then e.icon = BS.ItemIcon(d.iconItem) end
        if not e.icon and d.procAuras then local _, ic = BS.SpellInfo(d.procAuras[1]); e.icon = ic end
        e.icon = e.icon or d.icon or "Interface\\Icons\\INV_Misc_QuestionMark"

        if d.kind == "buff" and not d.weapon then
            e.auraNames = {}
            local auraList = d.auras or (type(d.spell) == "table" and d.spell) or { d.spell }
            for _, a in ipairs(auraList) do
                local n = NameOf(a)
                if n then e.auraNames[n] = true end
            end
            if d.groupSpell then
                local gName = NameOf(d.groupSpell)
                if gName then e.auraNames[gName] = true end
                e.groupSpellName = self:ResolveSpell(d.groupSpell)
                e.groupSpellKnown = e.groupSpellName and self:IsKnown(e.groupSpellName) or false
            end
        end

        if d.procAuras then
            e.procAuraNames = {}
            for _, a in ipairs(d.procAuras) do
                local n = NameOf(a)
                if n then e.procAuraNames[n] = true end
            end
        end

        -- Skillungsprüfung
        if d.items then
            e.known = true
        elseif d.totems then
            e.known = true          -- gelernt wird je Element geprüft (BS:TotemMissing)
        elseif d.soulstone then
            e.known = false
            for _, id in ipairs(d.soulstone.needAny) do if BS.KnowsSpellID(id) then e.known = true; break end end
        elseif d.supply and d.supply.needAny then
            -- irgendein Zauber der Liste gelernt (z. B. irgendein "Gesundheitsstein herstellen")
            e.known = false
            for _, id in ipairs(d.supply.needAny) do if BS.KnowsSpellID(id) then e.known = true; break end end
        elseif d.supply and d.supply.ranks then
            -- Reagenz: irgendein Rang des Zaubers gelernt
            e.known = false
            for _, r in ipairs(d.supply.ranks) do if BS.KnowsSpellID(r[1]) then e.known = true; break end end
        elseif d.supply then
            -- Vorrat: kein Zauber zum Klicken; nötig ist nur, dass der Zauber, der den Vorrat braucht, gelernt ist
            local need = d.supply.needSpell and self:ResolveSpell(d.supply.needSpell)
            e.known = (not d.supply.needSpell) or (need ~= nil and self:IsKnown(need)) or false
        elseif d.pet then
            -- Begleiter (BS-N1 Punkt 2): Beschwörungszauber gelernt; mit dem ausgenommenen Talent (z. B. Dämonische
            -- Opferung) gilt der Eintrag als nicht passend -> nie Fehlalarm, wenn der Dämon absichtlich geopfert wird
            local need = d.pet.need and self:ResolveSpell(d.pet.need)
            e.known = (need ~= nil and self:IsKnown(need)) or false
            e.petSkip = d.pet.noTalent and self:HasTalentSpell(d.pet.noTalent) ~= nil or false
        else
            e.known = (d.alertOnly or (e.spellName ~= nil and self:IsKnown(e.spellName))) and true or false
        end
        -- Talente, die nur in WoW Forever existieren (z. B. Bloodthrill, Vanguard), gelten nur dort
        e.enableList = d.enableIfTalent
        if self.isForever and d.enableIfTalentForever then e.enableList = d.enableIfTalentForever end
        e.talentMatch = self:HasTalent(d.talents) or self:HasTalentSpell(d.talentSpell)
        e.viaTalent   = self:HasTalent(e.enableList) or self:HasTalentSpell(d.enableIfTalentSpell)
        e.specOK      = (not d.specs) or self.mainSpec == 0 or BS.Contains(d.specs, self.mainSpec)
        if self.testClass and (d.talents or d.talentSpell) and not e.talentMatch and e.specOK then
            e.talentMatch = FirstTalentName(d)   -- Testmodus: Talent-Procs der gewählten Skillung zeigen
        end

        if d.talents or d.talentSpell then
            e.recommended = e.known and e.talentMatch ~= nil
        else
            e.recommended = e.known and not d.optional and (e.specOK or e.viaTalent ~= nil)
        end

        local s = store[d.key]
        if s and s.enabled ~= nil then
            e.enabled = s.enabled and e.known
            e.manual  = true
        else
            e.enabled = e.recommended
        end
        e.mode  = (s and s.mode) or d.mode or "always"
        -- eigene Klingel für diesen Eintrag (unabhängig von den allgemeinen Tönen)
        if s and s.bell ~= nil then e.bell = s.bell else e.bell = d.bell and true or false end
        -- Procs über einen Buff heissen nach dem Buff (z. B. "Schattentrance"), damit gleiche Zauber unterscheidbar sind
        local procName = d.procAuras and not d.custom and NameOf(d.procAuras[1]) or nil
        if type(procName) ~= "string" then procName = nil end
        e.label = d.label or procName or e.spellName or d.key
        if d.kind == "proc" and d.procAuras and not d.custom and not d.label and procName then
            -- Proc über einen Buff: gross die Quelle (z. B. "SCHATTENTRANCE!"), darunter der Zauber
            e.alertText = BS.Upper(procName) .. "!"
        elseif d.kind == "buff" or d.kind == "proc" then
            e.alertText = d.alert or (BS.Upper(e.label) .. "!")
        end
        -- Zauber, den der Klick auslöst, wenn er anders heisst als die Beschriftung (Zeile unter dem Button)
        if d.kind == "proc" and e.spellName and not d.alertOnly and e.spellName ~= e.label then
            e.actionText = e.spellName
        end
        e.status, e.statusColor = self:EntryStatus(e)
        tinsert(self.entries, e)
    end
end

function BS:CountActive()
    local c = { buff = 0, proc = 0, cd = 0 }
    for _, e in ipairs(self.entries) do
        if e.enabled then c[e.kind] = c[e.kind] + 1 end
    end
    return c
end

------------------------------------------------------------------------
-- Zonen-Logik
------------------------------------------------------------------------
BS.CONTEXT_NAMES = {
    world = L.OPEN_WORLD, dungeon = "Dungeon", raid = "Raid", pvp = L.BATTLEGROUND,
    resting = L.CAPITAL_CITY_INN, sanctuary = L.SANCTUARY, instance = L.INSTANCE,
    dead = L.DEAD, taxi = L.FLIGHT_PATH,
}

function BS:GetContext()
    -- über BS.API: die Testroutine stellt Tod, Flug und Zonen nach (TU1)
    if API.UnitIsDeadOrGhost("player") then return false, "dead" end
    if API.UnitOnTaxi("player") then return false, "taxi" end
    local z = self.db.zones
    local inInstance, itype = API.IsInInstance()
    if inInstance then
        if itype == "raid" then return z.raid, "raid" end
        if itype == "party" or itype == "scenario" then return z.dungeon, "dungeon" end
        if itype == "pvp" or itype == "arena" then return z.pvp, "pvp" end
        return true, "instance"
    end
    local pvpType
    if API.C_PvP and API.C_PvP.GetZonePVPInfo then
        pvpType = API.C_PvP.GetZonePVPInfo()
    elseif API.GetZonePVPInfo then
        pvpType = API.GetZonePVPInfo()
    end
    if pvpType == "sanctuary" then return z.sanctuary, "sanctuary" end
    if API.IsResting() then return z.resting, "resting" end
    return z.world, "world"
end

------------------------------------------------------------------------
-- Scans / Layout auslösen
------------------------------------------------------------------------
-- Fehler beim Einlesen zählen (erster Fehler im Chat, alle in /bsen fehler und im Testbericht)
local function SafeCall(func, ...)
    local ok, err = pcall(func, ...)
    if not ok then BS:CountError("Scan", err) end
end

function BS:AnnounceSpec()
    local c = self:CountActive()
    if self.isRetail then
        BS.Print(string.format(L.SPECIALIZATION_DETECTED_BUFF_REMINDERS_ACTIVE,
            self:SpecText(), c.buff))
        return
    end
    BS.Print(string.format(L.SPEC_DETECTED_ADJUSTED_BUFFS_PROCS,
        self:SpecText(), c.buff, c.proc, c.cd))
end

function BS:FullScan()
    -- Testmodus mit fremder Klasse: nicht neu einlesen, nur neu aufbauen
    if self.testClass then
        SafeCall(self.Layout, self)
        return
    end
    local oldSig = self.talentSig
    SafeCall(self.ScanSpellbook, self)
    SafeCall(self.ScanTalents, self)
    if self.LearnFromClient then SafeCall(self.LearnFromClient, self) end
    if self.AutoSpellbookCheck then SafeCall(self.AutoSpellbookCheck, self) end
    SafeCall(self.Layout, self)
    if self.talentSig ~= oldSig and self.talentSig ~= "" and self.mainSpec ~= 0 then
        self:AnnounceSpec()
    end
    if self.optionsFrame and self.optionsFrame:IsShown() then
        SafeCall(self.RefreshOptions, self)
    end
end

function BS:FullScanSoon()
    if self.scanQueued then return end
    self.scanQueued = true
    local function run()
        self.scanQueued = false
        if self:Lockdown() then
            self.pendingScan = true
        else
            self:FullScan()
        end
    end
    if C_Timer and C_Timer.After then C_Timer.After(0.5, run) else run() end
end

function BS:SettingsChanged()
    if self:Lockdown() then
        self.pendingLayout = true
        BS.Print(L.THE_CHANGE_WILL_BE_APPLIED)
    else
        self:Layout()
    end
    if self.optionsFrame and self.optionsFrame:IsShown() then
        self:RefreshOptions()
    end
end

------------------------------------------------------------------------
-- Events
------------------------------------------------------------------------
local frame = CreateFrame("Frame")
BS.frame = frame
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function(_, event, ...)
    local handler = BS[event]
    if handler then
        -- Leistung (BS-N2): im Kampf und bei Taschen-Ereignissen die Zeit des Handlers messen
        local P = BS.perf
        local measure = BS.Clock and ((P and P.active) or event == "BAG_UPDATE_DELAYED")
        local t0 = measure and BS.Clock() or nil
        local ok, err = pcall(handler, BS, ...)
        if t0 then
            local ms = BS.Clock() - t0
            if P and P.active then BS.PerfAdd(event, ms) end
            if event == "BAG_UPDATE_DELAYED" then BS.BagPerfAdd(ms) end
        end
        if not ok then
            -- jeden Fehler zählen (Diagnose /bsen fehler), im Chat nur den ersten zeigen
            BS:TallyError("Event " .. event, err)
            if not BS.errShownEvent then
                BS.errShownEvent = true
                BS.Print(L.ERROR_IN .. event .. ": " .. tostring(err))
            end
        end
    end
end)

-- Kennt der Client das Ereignis? (C_EventUtils.IsEventValid, wo vorhanden; sonst versuchen und pcall)
function BS.EventValid(ev)
    local EU = BS.API.C_EventUtils
    if EU and EU.IsEventValid then
        local ok, valid = pcall(EU.IsEventValid, ev)
        if ok and valid ~= nil then return valid == true end
    end
    return true
end
BS.EVENTS = nil   -- wird unten gesetzt (Testroutine T29)

local EVENTS = {
    "PLAYER_ENTERING_WORLD", "SPELLS_CHANGED", "LEARNED_SPELL_IN_TAB", "LEARNED_SPELL_IN_SKILL_LINE",
    "CHARACTER_POINTS_CHANGED", "PLAYER_TALENT_UPDATE", "ACTIVE_TALENT_GROUP_CHANGED",
    "PLAYER_SPECIALIZATION_CHANGED", "TRAIT_CONFIG_UPDATED",
    "GROUP_ROSTER_UPDATE", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED",
    "UNIT_AURA", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_INVENTORY_CHANGED", "BAG_UPDATE_DELAYED",
    "UPDATE_INVENTORY_DURABILITY", "READY_CHECK", "UNIT_PET", "MERCHANT_SHOW", "MERCHANT_CLOSED", "MERCHANT_UPDATE", "PLAYER_MONEY",
    "PLAYER_LOGOUT",
    -- Addon-Nachrichten und Kanal-Hinweise empfängt GoldSentinelSync (gemeinsame Datei) und gibt sie an BuffSentinel
}

BS.EVENTS = EVENTS

function BS:PLAYER_LOGIN()
    self:InitDB()
    if BS.DiagSession then BS.DiagSession() end
    if BS.SetupCmdHint then pcall(BS.SetupCmdHint, BS) end
    if BS.SetupPruefliste then pcall(BS.SetupPruefliste, BS) end      -- Prüfliste im Spiel (nur Entwicklermodus wirksam)
    -- Marktdaten-Netz (gemeinsame Datei GoldSentinelMarkt, Auftrag MN1): Daten in BuffSentinelDB.gsMarkt
    if GoldSentinelMarkt and GoldSentinelMarkt.Attach then pcall(GoldSentinelMarkt.Attach, "BuffSentinel", BuffSentinelDB) end
    -- Lua-Fehler und gezählte Fehler an die Prüfung melden (accountweite DB, eine Datei für den Uploader)
    if GoldSentinelTest then GoldSentinelTest.TrackErrors("BuffSentinel", BS.version, BuffSentinelDB) end
    self.class = select(2, UnitClass("player"))
    self.playerGUID = UnitGUID("player")
    -- nur anmelden, was der Client kennt (Forever: LEARNED_SPELL_IN_SKILL_LINE statt LEARNED_SPELL_IN_TAB)
    self.eventsUnknown = {}
    for _, ev in ipairs(EVENTS) do
        local ok = BS.EventValid(ev) and pcall(frame.RegisterEvent, frame, ev)
        if not ok then self.eventsUnknown[ev] = true end
    end
    -- Kampflog: in Retail (Midnight) für Addons gesperrt
    -- Forever und Retail: Kampflog für Addons gesperrt -> nicht registrieren
    self.hasCombatLog = self:WantsCombatLog()
    if self.hasCombatLog then pcall(frame.RegisterEvent, frame, "COMBAT_LOG_EVENT_UNFILTERED") end

    BS.Print(L.LOADED_FOR .. (BS.FLAVOR_NAMES[self.flavor] or self.flavor) ..
        (self.isRetail and L.RETAIL_MODE_BUFF_REMINDERS_OUT or "."))

    if self.InitNames then self:InitNames() end
    self:CreateDisplay()
    self:CreateMinimapButton()
    self.ready = true
    self:FullScan()
    if not self.ClassData[self.class] then
        BS.Print(L.THERE_IS_NO_DATA_FOR)
    end

    local acc, gacc = 0, 0
    frame:SetScript("OnUpdate", function(_, dt)
        acc, gacc = acc + dt, gacc + dt
        if acc >= 0.1 then
            acc = 0
            local ok, err = pcall(BS.Timed, "Refresh", BS.Refresh, BS)
            if not ok then BS:CountError(L.DISPLAY, err) end
        end
        if gacc >= 0.5 then
            gacc = 0
            local ok, err = pcall(BS.Timed, "RefreshGroup", BS.RefreshGroup, BS)
            if not ok then BS:CountError(L.GROUP, err) end
            -- Zorn der Gerechtigkeit ohne Tank-Rolle (nur Paladin, höchstens eine Chat-Zeile je Gruppe)
            if BS.class == "PALADIN" then
                local okr, errr = pcall(BS.CheckRighteousFury, BS)
                if not okr then BS:CountError(L.GROUP, errr) end
            end
            -- Seelenstein in der Gruppe (nur wenn der Eintrag aktiv ist, nur ausserhalb des Kampfes)
            if BS.hasSoulstoneEntry then
                local oks, errs = pcall(BS.CheckSoulstone, BS)
                if not oks then BS:CountError(L.GROUP, errs) end
            end
            -- BP-2026-11-13-1: Waffen-Verzauberung messen (nur Schamane, nur bei Änderung ein Eintrag)
            if BS.class == "SHAMAN" then pcall(BS.MeasureWeaponEnchant, BS) end
            -- Sync: alle 10 Minuten eine Zeile ins Diagnose-Protokoll (Senden selbst taktet GoldSentinelSync)
            BS.syncDiagAt = BS.syncDiagAt or (GetTime() + 600)
            if GetTime() >= BS.syncDiagAt then
                BS.syncDiagAt = GetTime() + 600
                local okc, errc = pcall(BS.SyncDiagTick, BS)
                if not okc then BS:CountError("Komm", errc) end
            end
        end
    end)
end

-- Fehler zählen (ohne Chat) und an GoldSentinelTest melden – gemeinsam für CountError und die Event-Handler.
-- Gibt die Anzahl der Fehler in diesem Bereich zurück.
function BS:TallyError(area, err)
    self.errors = self.errors or { count = 0, byArea = {}, last = nil }
    local E = self.errors
    E.count = E.count + 1
    E.byArea[area] = (E.byArea[area] or 0) + 1
    E.last = area .. ": " .. tostring(err)
    if BS.Diag then BS.Diag("FEHLER", E.last) end
    if GoldSentinelTest then GoldSentinelTest.Error("BuffSentinel", area, err) end
    return E.byArea[area]
end

-- Fehler zählen statt still abbrechen: erster Fehler pro Bereich im Chat, alle in der Diagnose (/bsen fehler)
function BS:CountError(area, err)
    if self:TallyError(area, err) == 1 then BS.Print(L.ERROR .. area .. "): " .. tostring(err)) end
end

function BS:ErrorSummary()
    local E = self.errors
    if not E or E.count == 0 then return L.NO_ERRORS end
    local parts = {}
    for area, n in pairs(E.byArea) do tinsert(parts, area .. " " .. n .. "x") end
    table.sort(parts)
    return string.format(L.ERRORS_LAST, E.count, table.concat(parts, ", "), E.last or "?")
end

function BS:PLAYER_ENTERING_WORLD()         self:FullScanSoon() end
function BS:SPELLS_CHANGED()                self:FullScanSoon() end
function BS:LEARNED_SPELL_IN_TAB()          self:FullScanSoon() end
function BS:LEARNED_SPELL_IN_SKILL_LINE()   self:FullScanSoon() end
function BS:CHARACTER_POINTS_CHANGED()      self:FullScanSoon() end
function BS:PLAYER_TALENT_UPDATE()          self:FullScanSoon() end
function BS:ACTIVE_TALENT_GROUP_CHANGED()   self:FullScanSoon() end
function BS:PLAYER_SPECIALIZATION_CHANGED(unit)
    if unit == nil or unit == "player" then self:FullScanSoon() end
end
function BS:TRAIT_CONFIG_UPDATED()          self:FullScanSoon() end

-- Gifte in den Taschen / Waffenwechsel -> Item-Buttons neu zuordnen
function BS:BAG_UPDATE_DELAYED()
    if self.hasSupplyEntries then self:UpdateSupply() end
    if self.merchantOpen and self.RestockAfterBags then self:RestockAfterBags() end     -- Nachkaufen-Knopf wieder frei (BS-E1)
    if self.hasItemEntries then
        if self:Lockdown() then self.pendingLayout = true else self:Layout() end
    end
end
-- Bereitschaftscheck (BS-N1 Punkt 5): EINE Chat-Zeile, was gerade fehlt – aus den Knöpfen, die die letzte Aktualisierung
-- (alle 0,1 s) gezeigt hat; nichts neu ausgewertet. Wo Buff-Erinnerungen nicht ausgewertet werden (Zonen-Einstellung), keine
-- Zeile – sonst stünde dort fälschlich "alles bereit".
function BS:ReadyCheckLine()
    if not self.ctxOK then return nil end
    local missing = {}
    for _, b in ipairs((self.pools and self.pools.buff) or {}) do
        local e = b.entry
        if e and b.wasShown then
            local extra = b.count and b.count.GetText and b.count:GetText() or ""
            if BS.IsSecret(extra) or type(extra) ~= "string" then extra = "" end
            local name = e.label or e.key
            if BS.IsSecret(name) or type(name) ~= "string" then name = tostring(e.key) end
            missing[#missing + 1] = name .. (extra ~= "" and (" (" .. extra .. ")") or "")
        end
    end
    if #missing == 0 then return L.READY_ALL_OK end
    return string.format(L.READY_MISSING, table.concat(missing, ", "))
end

function BS:READY_CHECK()
    if self.gdb and self.gdb.readyCheck == false then return end
    local ok, line = pcall(self.ReadyCheckLine, self)
    if ok and line then
        BS.Print(line)
        BS.PLHit("READY", line == L.READY_ALL_OK and "alles bereit" or "fehlt: …")
    end
end

-- Begleiter gewechselt/gerufen: Tierfutter neu zählen (die Futterarten hängen vom Begleiter ab)
function BS:UNIT_PET(unit)
    if unit == "player" and self.hasSupplyEntries then self:UpdateSupply() end
end

function BS:UPDATE_INVENTORY_DURABILITY()
    if self.hasDuraEntries then self:UpdateDurability() end
end
function BS:UNIT_INVENTORY_CHANGED(unit)
    if unit == "player" and self.hasSupplyEntries then self:UpdateSupply() end
    if unit == "player" and self.hasItemEntries and not self:Lockdown() then self:Layout() end
end

function BS:GROUP_ROSTER_UPDATE()
    if self:Lockdown() then self.pendingLayout = true else self:Layout() end
    if self.OnGroupChanged then self:OnGroupChanged() end
end

-- Kurz vor der Kampfsperre: alle erlaubten Buttons "scharf" machen
function BS:PLAYER_REGEN_DISABLED()
    -- Leistung im Kampf messen (BS-N2); nicht während der Testroutine (deren Kampf ist nachgestellt)
    if not (BS.Selftest and BS.Selftest.running) then BS.PerfStart() end
    -- Kampf beginnt: Testmodus beenden, damit alle Buttons wieder echte Zauber wirken
    if self.testMode then self:StopTestMode() end
    if self:Locked() then
        -- Forever/Retail: im Kampf zeigt BuffSentinel nichts an. Alle Klick-Buttons jetzt (noch erlaubt)
        -- verstecken, damit keine unsichtbaren Buttons im Kampf Klicks abfangen.
        if self.HideAllForCombat then self:HideAllForCombat() end
        self:NoteSecret()
        return
    end
    self:Arm()
end

function BS:PLAYER_REGEN_ENABLED()
    if not (BS.Selftest and BS.Selftest.running) then BS.PerfStop() end   -- Zeile LEISTUNG ins Protokoll (BS-N2)
    -- Verstecken war im Kampf nicht möglich (z. B. Sperre schon aktiv): jetzt nachholen
    if self.hidePending and self.HideAllForCombat then
        self.hidePending = false
        self:HideAllForCombat()
    end
    -- Testroutine im Kampf beendet: Positionen/Grösse/Fenster der echten Daten jetzt anwenden (TR-ALLE)
    if self.pendingApplyAll then
        self.pendingApplyAll = false
        pcall(self.ApplyPositions, self)
        pcall(self.ApplyScale, self)
        for key in pairs(self.windows or {}) do pcall(self.PlaceWindow, self, key) end
        self.pendingLayout = true
    end
    if self.pendingScan then
        self.pendingScan = false
        self:FullScan()
    elseif self.pendingLayout then
        self:Layout()
    end
    if self:Locked() then
        -- Forever/Retail: Auren sind direkt nach dem Kampf noch kurz geschützt -> verzögert lesen
        self.auraHoldUntil = GetTime() + 0.5
        local T = API.C_Timer
        if T and T.After then
            local tries = 0
            local function later()
                tries = tries + 1
                if BS:AuraBlocked("player") then
                    if tries < 4 then T.After(1, later) end      -- noch geschützt: bis zu 3× je 1 s später
                    return
                end
                local ok, err = pcall(BS.ScanPlayerAuras, BS)
                if not ok then BS:CountError(L.DISPLAY, err) end
            end
            T.After(0.6, later)
        end
    end
    self:Refresh()
end

------------------------------------------------------------------------
-- Selbsttest der Versionsweiche (nur Entwickler): simuliert WoW Forever und kehrt zurück
------------------------------------------------------------------------
function BS:FlavorLine()
    local G = GoldSentinelGame
    return string.format("%s · restricted: %s · Locked: %s", G and G.Status() or L.WITHOUT_GOLDSENTINELGAME,
        self.restricted and L.YES or L.NO, self:Locked() and L.YES or L.NO)
end

function BS:SelfTestFlavor(quiet)
    if not (GoldSentinelDev and GoldSentinelDev:Require("BuffSentinel")) then return nil end
    local G = GoldSentinelGame
    local lines = {}
    local function out(s) lines[#lines + 1] = s; if not quiet then BS.Print(s) end end
    if not (G and G.SetTestFlavor) then
        out(L.SELF_TEST_GOLDSENTINELGAME_SETTESTFLAVOR_IS)
        return lines
    end
    local ok, err = pcall(function()
        G.SetTestFlavor("forever"); self:DetectFlavor()
        out(L.SELF_TEST_SIMULATING_WOW_FOREVER .. self:FlavorLine())
    end)
    G.SetTestFlavor(nil); self:DetectFlavor()
    if not ok then out(L.SELF_TEST_ERROR .. tostring(err)) end
    out(L.SELF_TEST_BACK_TO_REAL .. self:FlavorLine())
    return lines
end

------------------------------------------------------------------------
-- Chat-Befehl (nur als Notlösung, alles geht auch per Maus)
------------------------------------------------------------------------
SLASH_BUFFSENTINEL1 = "/buffsentinel"
SLASH_BUFFSENTINEL2 = "/bsen"
-- EINE Befehlstabelle für den Slash-Handler UND die Befehlsliste beim Tippen (CmdHint.lua, Auftrag BL1):
-- de/en = angezeigtes Wort je Sprache, words = alle Wörter, die der Handler versteht (erstes Wort der Eingabe bzw. die
-- ganze Eingabe bei mehrteiligen Befehlen), desc = Schlüssel in Locales.lua, dev = nur für den Entwickler.
local function ShowErrors()
    if GoldSentinelGame then BS.Print(GoldSentinelGame.Status()) end
    BS.Print(L.DIAGNOSTICS .. BS:ErrorSummary() .. L.RESTRICTIONS_SECRET_VALUES ..
        (BS:Locked() and L.YES or L.NO) .. L.COMBAT_LOG .. (BS.hasCombatLog and L.YES or L.NO) ..
        L.OPEN_REPORTS .. (GoldSentinelTest and GoldSentinelTest.Pending(BuffSentinelDB) or 0))
end

BS.COMMANDS = {
    { de = "optionen",       en = "options",        words = { "optionen", "options", "config" }, desc = "CMD_OPTIONS",
      run = function() BS:ToggleOptions() end },
    { de = "anordnen",       en = "move",           words = { "anordnen", "verschieben", "move", "arrange" }, desc = "CMD_MOVE",
      run = function() BS:ToggleArrangeMode() end },
    { de = "fehler",         en = "errors",         words = { "fehler", "errors", "diag" }, desc = "CMD_ERRORS", run = ShowErrors },
    { de = "protokoll",      en = "log",            words = { "protokoll", "log", "diagnose" }, desc = "CMD_LOG",
      run = function() if BS.ShowDiag then BS.ShowDiag() end end },
    { de = "protokoll aus",  en = "log off",        words = { "protokoll aus", "log off", "diagnose aus", "protokoll off", "log aus" }, desc = "CMD_LOG_OFF",
      run = function() BS.SetDiagSend(false); BS.Print(L.DIAG_SEND_OFF) end },
    { de = "protokoll an",   en = "log on",         words = { "protokoll an", "log on", "diagnose an", "protokoll on", "log an" }, desc = "CMD_LOG_ON",
      run = function() BS.SetDiagSend(true); BS.Print(L.DIAG_SEND_ON) end },
    { de = "sync test",      en = "sync test",      words = { "sync test", "sync" }, desc = "CMD_SYNC",
      run = function() if BS.SyncTest then BS:SyncTest() end end },
    { de = "befehlsliste aus", en = "cmdlist off",  words = { "befehlsliste aus", "cmdlist off" }, desc = "CMD_HINT_OFF",
      run = function() BS.gdb.cmdHint = false; BS.Print(L.CMD_HINT_IS_OFF) end },
    { de = "befehlsliste an", en = "cmdlist on",    words = { "befehlsliste an", "cmdlist on" }, desc = "CMD_HINT_ON",
      run = function() BS.gdb.cmdHint = true; BS.Print(L.CMD_HINT_IS_ON) end },
    { de = "spenden",        en = "donate",         words = { "spenden", "donate", "support" }, desc = "CMD_DONATE",
      run = function() if BS.Donate then BS.Donate.Show() end end },
    { de = "hilfe",          en = "help",           words = { "hilfe", "help", "?" }, desc = "CMD_HELP",
      run = function() BS:PrintHelp() end },
    { de = "test",           en = "test",           words = { "test" }, desc = "CMD_TEST", dev = true,
      run = function() BS:ToggleTestMode() end },
    { de = "selbsttest",     en = "selftest",       words = { "selbsttest", "selftest" }, desc = "CMD_SELFTEST", dev = true,
      run = function() BS:SelfTestFlavor() end },
    { de = "testroutine",    en = "testroutine",    words = { "testroutine" }, desc = "CMD_TESTROUTINE", dev = true, takesArg = true,
      run = function(arg) if BS.RunTestRoutine then BS:RunTestRoutine(arg) end end },
    { de = "prüfliste",      en = "checklist",      words = { "prüfliste", "pruefliste", "checklist" }, desc = "CMD_CHECKLIST", dev = true,
      run = function() if BS.OpenPruefliste then BS:OpenPruefliste() end end },
    { de = "testroutine kampf", en = "testroutine kampf", words = { "testroutine kampf" }, desc = "CMD_TESTROUTINE_COMBAT", dev = true,
      run = function() if BS.RunTestRoutine then BS:RunTestRoutine("kampf") end end },
    { de = "testroutine alles", en = "testroutine all", words = { "testroutine alles", "testroutine all" }, desc = "CMD_TESTROUTINE_ALL", dev = true,
      run = function() if BS.RunTestRoutine then BS:RunTestRoutine("alles") end end },
    { de = "testroutine stopp", en = "testroutine stop", words = { "testroutine stopp", "testroutine stop", "testroutine abbrechen" },
      desc = "CMD_TESTROUTINE_STOP", dev = true, run = function() if BS.RunTestRoutine then BS:RunTestRoutine("stopp") end end },
}

-- Befehl zur Eingabe finden: zuerst die ganze Eingabe (mehrteilige Befehle), dann das erste Wort
function BS.FindCommand(msg)
    msg = strlower(strtrim(msg or ""))
    if msg == "" then return BS.COMMANDS[1], "" end
    local first, arg = msg:match("^(%S+)%s*(.-)$")
    local byFirst
    for _, c in ipairs(BS.COMMANDS) do
        for _, w in ipairs(c.words) do
            if w == msg then return c, "" end
            if w == first and not byFirst then byFirst = c end
        end
    end
    if byFirst then return byFirst, arg end
    return nil, msg
end

function BS:PrintHelp()
    BS.Print(L.HELP_HEADER)
    local dev = self:IsDev()
    -- Befehlswort in der GERADE aktiven Sprache (nicht nur der Client-Sprache): nach BS.ApplyLocale("enUS") englische Wörter
    -- (0.9.46: das neue Wort "prüfliste" fiel im Test T98 unter enUS auf)
    local LS = BS.LOCALES
    local german = LS and LS.deDE and LS.enUS and L.HELP_HEADER == LS.deDE.HELP_HEADER and LS.deDE.HELP_HEADER ~= LS.enUS.HELP_HEADER
    if german == nil then german = BS.isGerman end
    for _, c in ipairs(BS.COMMANDS) do
        if dev or not c.dev then
            BS.Print("/bsen " .. (german and c.de or c.en) .. " – " .. tostring(L[c.desc]))
        end
    end
    BS.Print(L.HELP_GSGAME)
end

SlashCmdList.BUFFSENTINEL = function(msg)
    -- frische Auswahl aus der Befehlsliste (Klick/Tab, ≤ 10 s) statt des unvollständig getippten Worts
    if BS.CmdHint and BS.CmdHint.Resolve then msg = BS.CmdHint:Resolve(msg) end
    if BS.CmdHint and BS.CmdHint.Count and BS.gdb then pcall(BS.CmdHint.Count, BS.CmdHint, msg) end
    local c, arg = BS.FindCommand(msg)
    if c and c.dev and not BS:IsDev() then
        -- Entwickler-Befehle: wie bisher über GoldSentinelDev (Testmodus fällt für alle anderen auf "Anordnen" zurück)
        if c.de == "test" then return c.run(arg) end
        if GoldSentinelDev then GoldSentinelDev:Require("BuffSentinel") end
        return
    end
    if c then return c.run(arg) end
    BS:ToggleOptions()                                   -- unbekannt: wie bisher die Optionen
end
