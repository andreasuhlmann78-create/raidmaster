-- AHSentinel - Prüfliste im Spiel (nur Entwicklermodus)
-- Copyright (C) 2026 GoldSentinel
-- This file is part of AHSentinel. AHSentinel is free software: you can redistribute it and/or modify it under the terms
-- of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at
-- your option) any later version. See LICENSE.txt.
--
-- Entscheid des Nutzers 16.11.2026 06:47 (Supervisor 06:49): Für jeden Punkt "im Client prüfen" eine Prüfliste im Spiel mit dem
-- gemeinsamen Baustein GoldSentinelPruefliste.lua. Nur Entwicklermodus (/ahs entwickler an UND GoldSentinelDev), merkt selbst,
-- zeigt immer, was zu tun ist. Zuerst: Sniper-Abnahme 16.11. (vor dem CurseForge-Upload 18:00).
-- Ohne Entwicklermodus kostet nichts etwas: P:On() ist dann sofort false, Hit/Fail tun nichts.

local A = AHAnalyzerPro
local P = {}
A.Pruefliste = P

P.ADDON = "AHSentinel"
-- Punkte in der Reihenfolge, in der der Nutzer sie im Spiel macht (höchstens 14). "since" = Version, ab der der Punkt gilt;
-- kommt ein Punkt mit neuer Fassung, ist er wieder offen.
P.POINTS = {
    { id = "SN-TR", title = "Testroutine Sniper (S1–S6)", since = "0.65.259",
      todo = "Auktionshaus öffnen, keinen Markt-Scan laufen lassen. Im Sniper muss der Knopf „Mausrad“ GRÜN sein (sonst einmal anklicken). Im Chat: /ahs testroutine sniper. Die Frage nach dem Testkauf mit „Ja“ beantworten; sobald „Treffer“ erscheint, EINE Mausrad-Raste. Danach rund 2 Minuten nichts tun (der Sniper wird beobachtet).",
      expect = "Im Chat „Testroutine fertig: … 0 FEHLER …“, das Bericht-Fenster beginnt mit „ERGEBNIS Sniper-Abnahme“ in Sätzen, der Testkauf ist genau 1 Stück." },
    { id = "SN-BTN1", title = "Kauf-Knopf: ein Klick = ein Kauf", since = "0.65.261",
      todo = "Kaufen > Sniper: Ziel mit einem billigen Item setzen (z. B. Leinenstoff), Max pro Stück knapp ÜBER dem billigsten Angebot, Menge 2. „Sniper-Modus: AN“. Der Kauf-Knopf ist der BREITE Knopf direkt unter der Zielliste. Steht dort „Kein Treffer“: Max erhöhen oder „Jetzt suchen“ klicken (der Grund steht in der Zeile darunter). Zeigt er „Kaufen: 1× … für …“, ihn EINMAL anklicken.",
      expect = "Genau ein Kauf: Chat „Gekauft: …“, der Knopf ist kurz grün „Gekauft“, die Zielzeile zählt 1 weiter." },
    { id = "SN-RAD", title = "Mausrad kauft nur, wenn eingeschaltet", since = "0.65.261",
      todo = "Im Sniper (Kaufen > Sniper) den Knopf „Mausrad“ (rechts neben „Sniper-Modus“) anklicken, bis er GRAU ist = nur der Knopf „Kaufen“ kauft (dieselbe Einstellung steht auch in /ahs optionen, rechte Spalte, „Sniper: Kaufen mit“). Bei einem Treffer das Mausrad drehen – über der Spielwelt UND über dem AHSentinel-Fenster. Danach „Mausrad“ wieder anklicken (GRÜN) und bei einem Treffer EINE Raste.",
      expect = "Grau: das Mausrad kauft NIE (Kamera zoomt, Listen blättern). Grün: eine Raste kauft genau einen Treffer." },
    { id = "SN-GRENZE", title = "Max und Budget werden eingehalten", since = "0.65.259",
      todo = "Sniper-Ziel mit kleinem Budget setzen, das für höchstens 2 Käufe reicht (z. B. Max 30s, Budget 50s, Menge 5), und kaufen, bis nichts mehr geht.",
      expect = "Kein Kauf über dem Max. Ist das Budget aufgebraucht, steht die Zielzeile gelb und der Knopf fragt „Budget auffüllen?“ – ohne Ja wird nichts mehr gekauft." },
    { id = "MU1-3", title = "Max über „Lohnt bis“: gelb + Knopf", since = "0.65.259",
      todo = "Ein Teil aus Markt > Entzaubern als Sniper-Ziel mit Max deutlich ÜBER „Lohnt bis“ setzen (Kaufen > Sniper, Max von Hand). Maus auf die Zielzeile, dann die Zeile anklicken und „Max folgt Lohnt bis“ drücken.",
      expect = "Vorher: Max-Zelle gelb, Tooltip „Max über Lohnt bis (…) – …“. Nach dem Knopf: Max = „Lohnt bis“, Zelle normal, der Knopf ist weg." },
    { id = "POST-WS", title = "Einstellen trotz Preiswarnung", since = "0.65.259",
      todo = "Verkaufen > Einstellen: ein billiges Item (Wert unter 10s) wählen, Preis absichtlich viel zu tief eintragen (rund 1/10 des Marktwerts), „Einstellen“. Im Fenster „Warnschutz“ auf „Trotzdem einstellen“.",
      expect = "Die Auktion steht danach unter Verkaufen > Meine Auktionen. Keine zweite Warnung, keine Meldung „blockiert“ oder „fehlgeschlagen“ (abbrechen darfst du sie danach)." },
    { id = "POST-FIX", title = "Preis anpassen ohne neue Warnung", since = "0.65.259",
      todo = "Wie oben zu tief einstellen, aber im Warnschutz „Preis anpassen (…)“ (oder Enter), dann „Einstellen“.",
      expect = "Das Preisfeld zeigt den vorgeschlagenen Preis, Einstellen geht ohne neue Warnung durch, die Auktion steht unter Meine Auktionen." },
    { id = "ESL1", title = "Einkaufsliste aus Materialien", since = "0.65.259",
      todo = "Berufsfenster öffnen (z. B. Schneiderei), ein Rezept wählen. Im AHSentinel-Teil daneben „Nur was mir fehlt“ oder „Materialien als Einkaufsliste“ klicken.",
      expect = "Die Einkaufsliste öffnet sich mit den Materialien (mindestens eine Zeile), im Chat „Materialien für … auf die Liste … gesetzt“." },
    -- Entscheid des Nutzers 16.11. 07:10: am Bild entscheiden (nur OK / Nicht OK + Notiz, nichts gebaut bis zur Antwort)
    { id = "MR4", title = "Markt-Kopf: Zeile je Stufenband gut?", since = "0.65.260",
      todo = "Markt-Reiter öffnen (/ahs, Reiter Markt) und die erste Kopfzeile ansehen: „Stufen 1-25 … · 26-45 … · 46-60 …“ (farbige Abschnitte statt Kacheln). Maus darüber zeigt das Wochentag-Muster.",
      expect = "Deine Entscheidung: gefällt dir die Zeile so? „OK“ = so lassen. „Nicht OK“ = echte Kacheln bauen – dann dem Supervisor sagen, was anders sein soll." },
    { id = "MR-SEITE", title = "Markt-Reiter als EINE Seite?", since = "0.65.260",
      todo = "Im Markt-Reiter die Ansichten Heute, Mein Lager und Entzaubern nacheinander ansehen. Frage: wäre EINE Seite besser – Lage oben, Mein Lager in der Mitte, Chancen unten?",
      expect = "Deine Entscheidung: „OK“ = ja, als eine Seite bauen. „Nicht OK“ = nein, Ansichten so lassen." },
}

-- an, wenn AHSentinel im Entwicklermodus ist und der gemeinsame Baustein da ist (GoldSentinelDev entscheidet dort selbst)
function P:On()
    return A:IsDev() and type(_G.GoldSentinelPruefliste) == "table" or false
end
-- die Liste (einmal angelegt, sobald der Entwicklermodus an ist); nil ohne Entwicklermodus
function P:List()
    if not self:On() then return nil end
    local G = _G.GoldSentinelPruefliste
    local l = self.list
    if l and G:Get(self.ADDON) == l then return l end
    local reg = G:Register(self.ADDON, {
        db = function() return P.testDB or A.db end,          -- Testroutine: eigene Ersatz-Daten (nie die echten)
        version = A.version,
        points = self.POINTS,
    })
    if G:Get(self.ADDON) ~= reg then return nil end              -- GoldSentinelDev sagt nein: wirkungslose Liste, nichts merken
    self.list = reg
    return reg
end
-- die Testroutine löst nichts aus (ihre Ereignisse sind nachgespielt); fromTR = Meldung der Testroutine selbst
local function Quiet(fromTR)
    local TR = A.TestRoutine
    return not fromTR and TR and TR.running and not P.testAllow
end
function P:Hit(id, note, fromTR)
    if Quiet(fromTR) then return false end
    local l = self:List()
    if not l then return false end
    local ok, r = pcall(l.Hit, l, id, note)
    return ok and r or false
end
-- vom Addon erkannter Fehler -> Zustand "Fehler (erkannt)" mit Notiz (ein OK des Spielers bleibt)
function P:Fail(id, note, fromTR)
    if Quiet(fromTR) then return false end
    local l = self:List()
    if not l then return false end
    local s = l:State(id)
    if s == "ok" then return false end
    local ok, r = pcall(l.Set, l, id, "fehler", note)
    if ok and r then
        A:Print("|cffff5544" .. "Prüfliste: " .. id .. " Fehler (erkannt)|r" .. (note and (" – " .. tostring(note)) or ""))
        if l.frame and l.frame:IsShown() then pcall(l.Refresh, l) end
    end
    return ok and r or false
end
function P:Open()
    local l = self:List()
    if not l then
        A:Print("Prüfliste: nur im Entwicklermodus (GoldSentinelDev erkennt dich nicht).")
        return false
    end
    return l:Open()
end
-- Zeilen für den Testbericht (leer ohne Entwicklermodus)
function P:ReportLines()
    local l = self:List()
    if not l then return {} end
    local ok, lines = pcall(l.ReportLines, l)
    return ok and lines or {}
end
