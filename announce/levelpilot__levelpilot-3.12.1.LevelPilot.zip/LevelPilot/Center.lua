-- LevelPilot - Zentrale
-- Tabs: Route, Dungeons, Daten, Austausch, Assistent, Komfort, Einstellungen

local _, LP = ...
local L = LP.L
local Ce = {}
LP:RegisterModule("Center", Ce)

local C = LP.colors
local BACKDROP_TEMPLATE = BackdropTemplateMixin and "BackdropTemplate" or nil
local W, H = 720, 560

local frame, tabs, pages = nil, {}, {}
local pageToggles, pageSteppers = {}, {}   -- [seite] = { ... }
local active = "route"

------------------------------------------------------------------------
-- Bausteine
------------------------------------------------------------------------
local function Page(key)
    local p = CreateFrame("Frame", nil, frame, BACKDROP_TEMPLATE)
    p:SetPoint("TOPLEFT", 14, -76)
    p:SetPoint("BOTTOMRIGHT", -14, 14)
    LP.UI:Skin(p, C.panel, C.border)
    p:Hide()
    pages[key] = p
    return p
end

local function Toggle(parent, x, y, key, label, onChange)
    local b = CreateFrame("Button", nil, parent, BACKDROP_TEMPLATE)
    b:SetSize(18, 18)
    b:SetPoint("TOPLEFT", x, y)
    LP.UI:Skin(b, { 0, 0, 0, 0.4 }, C.border)
    local tick = b:CreateTexture(nil, "OVERLAY")
    tick:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
    tick:SetPoint("CENTER")
    tick:SetSize(20, 20)
    local fs = LP.UI:Text(parent, 11, C.text)
    fs:SetPoint("LEFT", b, "RIGHT", 8, 0)
    fs:SetJustifyV("MIDDLE")
    fs:SetText(label)
    b:SetScript("OnClick", function()
        LP.db[key] = not LP.db[key]
        tick:SetShown(LP.db[key] and true or false)
        if onChange then onChange() end
        LP.UI:ApplySettings()
    end)
    local function update() tick:SetShown(LP.db[key] and true or false) end
    pageToggles[parent] = pageToggles[parent] or {}
    table.insert(pageToggles[parent], update)
    return b
end

local function Stepper(parent, x, y, label, get, set, step, min, max, fmt)
    local fs = LP.UI:Text(parent, 11, C.text)
    fs:SetPoint("TOPLEFT", x, y)
    fs:SetText(label)
    local minus = LP.UI:Button(parent, "–", 22, 20, function()
        set(math.max(min, get() - step)) LP.UI:ApplySettings() Ce:Refresh()
    end)
    minus:SetPoint("TOPLEFT", x + 200, y + 3)
    local val = LP.UI:Text(parent, 11, C.accent)
    val:SetPoint("LEFT", minus, "RIGHT", 8, 0)
    val:SetWidth(44)
    val:SetJustifyH("CENTER")
    local plus = LP.UI:Button(parent, "+", 22, 20, function()
        set(math.min(max, get() + step)) LP.UI:ApplySettings() Ce:Refresh()
    end)
    plus:SetPoint("LEFT", val, "RIGHT", 8, 0)
    pageSteppers[parent] = pageSteppers[parent] or {}
    table.insert(pageSteppers[parent], function() val:SetText(string.format(fmt, get())) end)
end

local function Heading(parent, x, y, text)
    local fs = LP.UI:Text(parent, 13, C.accent)
    fs:SetPoint("TOPLEFT", x, y)
    fs:SetText(text)
    return fs
end

local function Info(parent, x, y, width)
    local fs = LP.UI:Text(parent, 11, C.text)
    fs:SetPoint("TOPLEFT", x, y)
    fs:SetWidth(width or 300)
    fs:SetSpacing(3)
    return fs
end

------------------------------------------------------------------------
-- Tab: Route
------------------------------------------------------------------------
local zoneRows = {}

local function BuildRoute()
    local p = Page("route")
    Heading(p, 16, -14, L["Fokus-Zone"])
    local mNormal = LP.UI:Button(p, L["Normal"], 64, 20, function() LP.Planner:SetMode("normal") Ce:Refresh() end,
        L["Alle passenden Quests einplanen"])
    mNormal:SetPoint("TOPLEFT", 186, -10)
    local mSpeed = LP.UI:Button(p, L["Speedrun"], 76, 20, function() LP.Planner:SetMode("speed") Ce:Refresh() end,
        L["Möglichst schnell auf 60: lässt Quests aus, die weniger bringen als Grinden (und Eskorten), Klassenquests bleiben"])
    mSpeed:SetPoint("LEFT", mNormal, "RIGHT", 4, 0)
    p.mNormal, p.mSpeed = mNormal, mSpeed
    p.focus = Info(p, 16, -36, 320)
    local auto = LP.UI:Button(p, L["Automatisch"], 100, 22, function()
        LP.char.focusZone = false
        LP.Planner:Replan(true)
        Ce:Refresh()
    end, L["LevelPilot wählt die beste Zone selbst"])
    auto:SetPoint("TOPLEFT", 16, -60)
    local reset = LP.UI:Button(p, L["Ignorierte zurücksetzen"], 160, 22, function()
        LP.Engine:ResetIgnored()
        Ce:Refresh()
    end, L["Alle übersprungenen Quests und Schritte wieder einplanen"])
    reset:SetPoint("LEFT", auto, "RIGHT", 8, 0)

    Heading(p, 16, -96, L["Zonen mit Aufgaben (Klick = als Fokus wählen)"])
    p.zoneHost = CreateFrame("Frame", nil, p)
    p.zoneHost:SetPoint("TOPLEFT", 16, -118)
    p.zoneHost:SetSize(320, 300)

    Heading(p, 360, -14, L["Geplante Schritte"])
    p.plan = Info(p, 360, -36, 320)
    p.plan:SetMaxLines(26)
end

local function RefreshRoute()
    local p = pages.route
    local focus = LP.Planner.focus
    local speed = LP.Planner:IsSpeed()
    p.mNormal.label:SetText(speed and L["Normal"] or L["|cff3dd694Normal|r"])
    p.mSpeed.label:SetText(speed and L["|cffff7a3cSpeedrun|r"] or L["Speedrun"])
    p.focus:SetText((focus and LP.Geo:MapName(focus) or "–")
        .. (LP.char.focusZone and L["  |cffffb238(manuell)|r"] or L["  |cff9c9ea6(automatisch)|r"])
        .. L["\n|cff9c9ea6Ignorierte Quests: "] .. (function() local n = 0 for _ in pairs(LP.char.ignored) do n = n + 1 end return n end)()
        .. (speed and (L["  ·  Speedrun lässt "] .. (function() local n = 0 for _ in pairs(LP.Planner.speedSkip) do n = n + 1 end return n end)() .. L[" Quests aus"]) or "") .. "|r")
    local zones = LP.Planner:ZoneSummary()
    for i, z in ipairs(zones) do
        if i > 12 then break end
        local r = zoneRows[i]
        if not r then
            r = LP.UI:Button(p.zoneHost, "", 320, 22)
            r:SetPoint("TOPLEFT", 0, -(i - 1) * 24)
            r.label:ClearAllPoints()
            r.label:SetPoint("LEFT", 8, 0)
            r.label:SetJustifyH("LEFT")
            zoneRows[i] = r
        end
        r.map = z.map
        r.label:SetText(LP.Geo:MapName(z.map) .. "  |cff9c9ea6" .. z.accept .. L[" annehmbar, "] .. z.active .. L[" aktiv|r"])
        r:SetScript("OnClick", function(self)
            LP.char.focusZone = self.map
            LP.Planner:Replan(true)
            Ce:Refresh()
        end)
        r:Show()
    end
    for i = #zones + 1, #zoneRows do zoneRows[i]:Hide() end

    local lines = {}
    for i, s in ipairs(LP.Engine:Steps()) do
        lines[#lines + 1] = i .. ".  " .. (LP.UI:StepText(s, false):match("^[^\n]*") or "")
    end
    p.plan:SetText(#lines > 0 and table.concat(lines, "\n") or L["Keine Schritte."])
end

------------------------------------------------------------------------
-- Tab: Daten
------------------------------------------------------------------------
local function BuildData()
    local p = Page("data")
    Heading(p, 16, -14, L["Questdaten"])
    p.quests = Info(p, 16, -36, 330)
    local recon = LP.UI:Button(p, L["Datenquellen neu laden"], 160, 22, function()
        LP.QuestDB:Reconnect()
        Ce:Refresh()
    end, L["Nach Installation oder Update von LevelPilot Data oder QuestieDB"])
    recon:SetPoint("TOPLEFT", 16, -176)
    local diag = LP.UI:Button(p, L["Diagnose"], 80, 22, function() LP.Planner:Diagnose() end, L["Zustand der Routenplanung im Chat ausgeben"])
    diag:SetPoint("LEFT", recon, "RIGHT", 8, 0)
    local proto = LP.UI:Button(p, L["Fehler-Protokoll"], 116, 22, function() LP.Protocol:Show() end,
        L["Was LevelPilot beim Spielen aufgefallen ist – als Text zum Kopieren und Weiterschicken"])
    proto:SetPoint("LEFT", diag, "RIGHT", 8, 0)
    local test = LP.UI:Button(p, L["Selbsttest"], 90, 22, function() LP.SelfTest:Show(false) end,
        L["Prüft alle Funktionen (Daten, Sprache, Position, Planung, Wege, Anzeige, Komfort) und zeigt einen Bericht zum Kopieren"])
    test:SetPoint("TOPLEFT", 16, -204)
    local trip = LP.UI:Button(p, L["Virtuelle Reise 1–60"], 140, 22, function()
        if LP.Virtual.active then LP.Virtual:ShowWindow() else LP.Virtual:Start("start") end
    end, L["Ein gedachter Charakter läuft die ganze Route von Level 1 bis 60 – dein Charakter bewegt sich nicht, es wird nichts aufgezeichnet. Prüft Wege, Zonen und Planung."])
    trip:SetPoint("LEFT", test, "RIGHT", 8, 0)
    local trip2 = LP.UI:Button(p, L["Reise ab hier"], 100, 22, function()
        if not LP.Virtual.active then LP.Virtual:Start("here") end
    end, L["Wie die virtuelle Reise, aber ab deinem Level und Ort"])
    trip2:SetPoint("LEFT", trip, "RIGHT", 8, 0)
    -- virtuelle Reise nur im Testmodus (Entwickler)
    local function DevButtons()
        local dev = LP:IsDev()
        trip:SetShown(dev)
        trip2:SetShown(dev)
    end
    DevButtons()
    p:HookScript("OnShow", DevButtons)

    Heading(p, 360, -14, L["Wegenetz"])
    p.graph = Info(p, 360, -36, 320)
    -- Gesammelte Daten (Wege, Quests, Haendler) lassen sich bewusst nicht loeschen: sie sind die
    -- Grundlage fuer alle Spieler und werden ueber den Austausch und die Startdatenbank weitergegeben.
    local bSave = LP.UI:Button(p, L["Daten sichern"], 110, 22, function() LP.Backup:ShowExport() end,
        L["Alle gesammelten Daten als Text anzeigen – in eine Datei kopieren und sicher aufbewahren"])
    bSave:SetPoint("TOPLEFT", 360, -150)
    local bLoad = LP.UI:Button(p, L["Daten laden"], 100, 22, function() LP.Backup:ShowImport() end,
        L["Gesicherten Text einfügen – ergänzt die Daten, löscht nichts"])
    bLoad:SetPoint("LEFT", bSave, "RIGHT", 8, 0)

    local note = Info(p, 16, -236, 660)
    note:SetTextColor(C.muted[1], C.muted[2], C.muted[3])
    note:SetText(L["So entsteht die Datenbank:\n"]
        .. L["• Kern ist die LevelPilot-Startdatenbank: von Spielern gesammelte Quests, Wege und Händler – inklusive der neuen WoW-Forever-Quests.\n"]
        .. L["• Optional ergänzt das Addon \"LevelPilot Data\" (oder QuestieDB) alle Classic-Quests. Eigene Beobachtungen haben immer Vorrang.\n"]
        .. L["• Jede Quest, die du annimmst, wird aufgezeichnet: Questgeber, Ort, Level, Zielorte und Abgabe – so kommen auch die neuen WoW-Forever-Quests hinein.\n"]
        .. L["• Jeder Weg, den du läufst, wird als sicherer Weg gespeichert. Stirbst du kurz danach (z. B. Sturz), wird das Stück verworfen.\n"]
        .. L["• Graue Pfadlinie = Weg noch unbekannt (Luftlinie innerhalb einer Zone). Zonenwechsel nur über Pässe, Tunnel, Schiffe oder gelaufene Wege."])
end

local function RefreshData()
    local p = pages.data
    local c = LP.QuestDB:Counts()
    local function state(ok, info) return (ok and "|cff4ddb80" or "|cff9c9ea6") .. info .. "|r" end
    p.quests:SetText(L["Startdatenbank: "] .. c.seed .. L[" Quests"] .. (LP.Seed.version and (L[" (Stand "] .. L[tostring(LP.Seed.version)] .. ")") or "")
        .. L["\nSelbst aufgezeichnet: "] .. c.own
        .. L["\nVon anderen Spielern: "] .. c.net
        .. L["\nLevelPilot Data: "] .. state(LP.QuestDB.pack, LP.QuestDB.packInfo)
        .. L["\nQuestieDB: "] .. state(LP.QuestDB.questie, LP.QuestDB.questieInfo)
        .. (c.questie > 0 and (" – " .. c.questie .. L[" Quests"]) or "")
        .. L["\nBekannte Händler/Gasthäuser: "] .. (function() local n = 0 for _ in pairs(LP.db.vendors) do n = n + 1 end return n end)()
        .. L["\nBekannte Flugpunkte: "] .. (function() local n = 0 for _ in pairs(LP.db.taxi or {}) do n = n + 1 end return n end)())
    local s = LP.Graph:Stats()
    p.graph:SetText(L["Startdatenbank: "] .. s.seedEdges .. L[" Wegstücke"]
        .. L["\nEigene Wegpunkte: "] .. s.nodes .. L["  (davon empfangen: "] .. s.netNodes .. ")"
        .. L["\nWegstücke: "] .. s.edges
        .. L["\nGesamtlänge: "] .. LP:FormatDist(s.yards)
        .. L["\nZonenübergänge im Grundnetz: "] .. s.gateways
        .. L["\nAufzeichnung: "] .. (LP.db.recordPaths and L["|cff4ddb80an|r"] or L["|cffff8c33aus|r"])
        .. "\n" .. LP.Backup:Info())
end

------------------------------------------------------------------------
-- Tab: Austausch
------------------------------------------------------------------------
local function BuildShare()
    local p = Page("share")
    Heading(p, 16, -14, L["Daten mit anderen LevelPilot-Spielern teilen"])
    Toggle(p, 16, -42, "shareGroup", L["In der Gruppe / im Schlachtzug"])
    Toggle(p, 16, -68, "shareGuild", L["In der Gilde"])
    Toggle(p, 16, -94, "shareChannel", L["Über den gemeinsamen Addon-Kanal (alle Spieler mit LevelPilot)"], function() LP.Comm:Rejoin() end)
    Toggle(p, 16, -120, "shareSeed", L["Meine Aufzeichnungen für die LevelPilot-Startdatenbank freigeben"],
        function() LP.db.shareSeedAsked = true end)
    local sync = LP.UI:Button(p, L["Zone jetzt abgleichen"], 150, 22, function()
        LP.Comm:RequestZone(C_Map.GetBestMapForUnit("player"), true)
        LP:Print(L["Abgleich angefragt – Antworten kommen in den nächsten Sekunden."])
    end, L["Andere Spieler nach ihren Daten zu deiner aktuellen Zone fragen"])
    sync:SetPoint("TOPLEFT", 16, -150)
    p.stats = Info(p, 16, -184, 660)
    local note = Info(p, 16, -290, 660)
    note:SetTextColor(C.muted[1], C.muted[2], C.muted[3])
    note:SetText(L["Der Austausch läuft automatisch: Neue Aufzeichnungen werden sofort geteilt, und beim Betreten einer Zone fragt LevelPilot andere Spieler nach deren Daten zu dieser Zone.\n"]
        .. L["Geteilt werden nur Questdaten (Questgeber, Abgabe, Zielorte, Level) und gelaufene Wege – keine Namen, Gegenstände oder Chatinhalte.\n"]
        .. L["Empfangene Daten werden geprüft und ergänzen nur, was dir fehlt. Deine eigenen Beobachtungen haben immer Vorrang."])
end

local function RefreshShare()
    local s = LP.Comm:Stats()
    pages.share.stats:SetText(L["Gesendet: "] .. s.sent .. L["   Empfangen: "] .. s.recv
        .. L["\nBekannte Spieler mit LevelPilot: "] .. s.peers .. L["  (in der letzten Stunde: "] .. s.recent .. ")"
        .. L["\nAddon-Kanal: "] .. (s.channel and L["|cff4ddb80verbunden|r"] or L["|cff9c9ea6nicht verbunden|r"])
        .. L["   Warteschlange: "] .. s.queued
        .. L["\nDurch Austausch gelernt: "] .. s.newQuests .. L[" Quests, "] .. s.newPaths .. L[" Wegstücke"]
        .. L["\nZonen-Abgleich: "] .. s.zoneRequests .. L[" Anfragen gestellt, "] .. s.zoneReplies .. L[" beantwortet"]
        .. L["\nFreigabe für die Startdatenbank: "] .. (LP.db.shareSeed and L["|cff4ddb80ja|r"] or L["|cff9c9ea6nein|r"]))
end

------------------------------------------------------------------------
-- Tab: Assistent
------------------------------------------------------------------------
local hintRows = {}

local function BuildAssist()
    local p = Page("assist")
    Heading(p, 16, -14, L["Aktuelle Hinweise"])
    p.hintHost = CreateFrame("Frame", nil, p)
    p.hintHost:SetPoint("TOPLEFT", 16, -38)
    p.hintHost:SetSize(400, 400)
    p.none = Info(p, 16, -40, 380)

    Heading(p, 440, -14, L["Prüfungen"])
    Toggle(p, 440, -40, "advDurability", L["Haltbarkeit"])
    Toggle(p, 440, -64, "advBags", L["Taschen & Taschen-Upgrades"])
    Toggle(p, 440, -88, "advUpgrades", L["Ausrüstungs-Upgrades"])
    Toggle(p, 440, -112, "advAmmo", L["Munition (Jäger)"])
    Toggle(p, 440, -136, "advTalents", L["Talentpunkte"])
    Toggle(p, 440, -160, "advTrainer", L["Klassentrainer"])
    Stepper(p, 440, -196, L["Haltbarkeit warnen ab %"], function() return LP.db.durWarn end,
        function(v) LP.db.durWarn = v end, 5, 5, 80, "%d")
    Stepper(p, 440, -224, L["Taschen warnen ab frei"], function() return LP.db.bagWarn end,
        function(v) LP.db.bagWarn = v end, 1, 0, 20, "%d")
    Stepper(p, 440, -252, L["Munition warnen ab"], function() return LP.db.ammoWarn end,
        function(v) LP.db.ammoWarn = v end, 50, 0, 2000, "%d")
end

local function RefreshAssist()
    local p = pages.assist
    local hints = LP.Advisor.hints or {}
    p.none:SetText(#hints == 0 and L["|cff4ddb80Alles in Ordnung.|r"] or "")
    local y = 0
    for i, h in ipairs(hints) do
        if i > 8 then break end
        local r = hintRows[i]
        if not r then
            r = CreateFrame("Frame", nil, p.hintHost, BACKDROP_TEMPLATE)
            r:SetWidth(400)
            LP.UI:Skin(r, C.row, C.border)
            r.text = LP.UI:Text(r, 11, C.text)
            r.text:SetPoint("TOPLEFT", 8, -6)
            r.text:SetWidth(300)
            r.btn = LP.UI:Button(r, "", 76, 20)
            r.btn:SetPoint("TOPRIGHT", -6, -5)
            hintRows[i] = r
        end
        local col = h.sev == 3 and C.bad or (h.sev == 2 and C.warn or C.border)
        r:SetBackdropBorderColor(col[1], col[2], col[3], 1)
        r.text:SetText(h.text)
        r:SetHeight(math.max(30, r.text:GetStringHeight() + 12))
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", 0, -y)
        y = y + r:GetHeight() + 4
        if h.action then
            r.btn.label:SetText(h.actionLabel or L["Los"])
            r.btn:SetScript("OnClick", function() h.action() Ce:Refresh() end)
            r.btn:Show()
        else
            r.btn:Hide()
        end
        r:Show()
    end
    for i = math.min(#hints, 8) + 1, #hintRows do hintRows[i]:Hide() end
end

------------------------------------------------------------------------
-- Tab: Einstellungen
------------------------------------------------------------------------
local function BuildSettings()
    local p = Page("settings")
    Heading(p, 16, -14, L["Automatik"])
    Toggle(p, 16, -40, "autoAccept", L["Quests automatisch annehmen"])
    Toggle(p, 16, -64, "autoTurnin", L["Quests automatisch abgeben (bei einer Belohnung)"])
    Toggle(p, 16, -88, "usePack", L["Datenpaket \"LevelPilot Data\" nutzen, wenn installiert"], function() LP.QuestDB:Reconnect() end)
    Toggle(p, 16, -112, "useQuestie", L["QuestieDB nutzen, wenn installiert (ohne Datenpaket)"], function() LP.QuestDB:Reconnect() end)

    Heading(p, 16, -148, L["Aufzeichnung"])
    Toggle(p, 16, -174, "recordQuests", L["Quests aufzeichnen"])
    Toggle(p, 16, -198, "recordPaths", L["Gelaufene Wege aufzeichnen"])

    Heading(p, 16, -232, L["Server & Dungeons"])
    Toggle(p, 16, -258, "forever", L["Server WoW Forever (Questlog 40, Dungeon-EP angepasst)"], function()
        LP.Planner:BuildCandidates() LP.Planner:Replan()
    end)
    Toggle(p, 16, -282, "dungeons", L["Dungeon-Quests einplanen (nur betretbare Dungeons)"], function()
        LP.Planner:BuildCandidates() LP.Planner:Replan()
    end)
    Stepper(p, 16, -334, L["Dungeon-Monster-EP % (0 = auto)"], function() return LP.db.dungeonMobXP or 0 end,
        function(v) LP.db.dungeonMobXP = v LP.Planner:Replan() end, 10, 0, 100, "%d")
    Stepper(p, 16, -310, L["Dungeon-Lauf ab Quests"], function() return LP.db.dungeonMin or 2 end,
        function(v) LP.db.dungeonMin = v LP.Planner:Replan() end, 1, 1, 6, "%d")
    Toggle(p, 360, -306, "platesQuest", L["Questfortschritt über den Gegnern (Namensplaketten)"], function() LP.Plates:Refresh() end)
    Toggle(p, 360, -354, "compactMode", L["Kompakter Guide (eine Zeile)"])
    Toggle(p, 360, -378, "ownSettings", L["Einstellungen nur für diesen Charakter"], function() Ce:Refresh() end)
    Toggle(p, 360, -330, "platesAll", L["… für alle offenen Quests (statt nur den aktuellen Schritt)"], function() LP.Plates:Refresh() end)
    Stepper(p, 360, -274, L["Speedrun-Strenge (1–3)"], function() return LP.db.speedLevel or 3 end,
        function(v) LP.db.speedLevel = v LP.Planner:Replan() end, 1, 1, 3, "%d")
    Stepper(p, 360, -246, L["Questlog-Grösse (0 = auto)"], function() return LP.db.questLogMax or 0 end,
        function(v) LP.db.questLogMax = v LP.Planner:Replan() end, 5, 0, 50, "%d")

    Heading(p, 360, -14, L["Anzeige"])
    Toggle(p, 360, -40, "showArrow", L["Navigationspfeil"])
    Toggle(p, 360, -64, "showMinimapPath", L["Pfadlinie auf der Minikarte"])
    Toggle(p, 360, -88, "showMapPath", L["Pfadlinie und Marker auf der Weltkarte"])
    Toggle(p, 360, -160, "terrainPath", L["Weg dem Gelände anpassen (Strassen, Täler)"], function() LP.Nav:Recalc(true) end)
    Toggle(p, 360, -112, "showMinimapBtn", L["Minimap-Button"])
    Toggle(p, 360, -136, "locked", L["Fenster fixieren"])
    Stepper(p, 360, -188, L["Fenstergrösse"], function() return LP.db.scale end,
        function(v) LP.db.scale = math.floor(v * 100 + 0.5) / 100 end, 0.05, 0.6, 1.6, "%.2f")
    Stepper(p, 360, -214, L["Angezeigte Schritte"], function() return LP.db.stepsShown end,
        function(v) LP.db.stepsShown = v end, 1, 1, 10, "%d")

    Stepper(p, 16, -358, L["Dungeon-Quest-EP % (0 = auto)"], function() return LP.db.dungeonQuestXP or 0 end,
        function(v) LP.db.dungeonQuestXP = v LP.Planner:Replan() end, 10, 0, 300, "%d")

    -- Addon unterstuetzen (nur auf Klick)
    local sup = LP.UI:Text(p, 12, C.text)
    sup:SetPoint("TOPLEFT", 360, -410)          -- rechte Spalte, unter den Einstellungen
    sup:SetText(L["Addon unterstützen"])
    local bSup = LP.Donate.CreateButton(p, 96, 22)
    bSup:SetPoint("LEFT", sup, "RIGHT", 12, 0)
    p.support = bSup
    local hint = Info(p, 16, -394, 330)          -- linke Spalte, ueberlappt nichts
    hint:SetTextColor(C.muted[1], C.muted[2], C.muted[3])
    hint:SetText(L["Shift gedrückt halten pausiert das automatische Annehmen und Abgeben.\n"]
        .. L["Rechtsklick auf einen Schritt im Guide-Fenster überspringt ihn."])
end

------------------------------------------------------------------------
-- Tab: Dungeons
------------------------------------------------------------------------
local dgRows = {}

local function BuildDungeons()
    local p = Page("dungeons")
    Heading(p, 16, -14, LP.L["Dungeons (Klick = zum Eingang)"])
    p.note = Info(p, 300, -14, 380)
    p.note:SetTextColor(C.muted[1], C.muted[2], C.muted[3])
    p.host = CreateFrame("Frame", nil, p)
    p.host:SetPoint("TOPLEFT", 16, -36)
    p.host:SetSize(660, 380)
end

local function RefreshDungeons()
    local p = pages.dungeons
    local L = LP.L
    p.note:SetText(L["Grün = jetzt passend · Rot = gesperrt · Quests: offen / im Log / erledigt"])
    local list = LP.Planner:DungeonOverview()
    for i, d in ipairs(list) do
        local r = dgRows[i]
        if not r then
            r = LP.UI:Button(p.host, "", 660, 18)
            r:SetPoint("TOPLEFT", 0, -(i - 1) * 19)
            r.label:ClearAllPoints()
            r.label:SetPoint("LEFT", 6, 0)
            r.label:SetJustifyH("LEFT")
            r.label:SetWidth(650)
            r.label:SetWordWrap(false)
            dgRows[i] = r
        end
        local col = not d.allowed and "|cffff5555" or (d.now and "|cff4ddb80" or "|cffd0d0d8")
        local status = not d.allowed and (L["gesperrt"] .. " (" .. L[d.why or "?"] .. ")")
            or (d.hostile and L["Feindgebiet"] or "")
        local worth = d.worth and d.worth:gsub("^[^:]*: ", "") or ""
        r.label:SetText(string.format("%s%s|r  |cff9c9ea6%d–%d|r   %d / %d / %d   |cff9c9ea6%s %s|r", col, d.name, d.min, d.max,
            d.open, d.log, d.done, status, worth))
        r.entry = d
        r:SetScript("OnClick", function(self)
            local e = self.entry
            if e.entrance and e.allowed then
                LP.Comfort.Navigate(e.entrance[1], e.entrance[2], e.entrance[3], L("Dungeon-Eingang: %s", e.name), "PRIO:DG:" .. e.area)
            end
        end)
        r:Show()
    end
    for i = #list + 1, #dgRows do dgRows[i]:Hide() end
end

------------------------------------------------------------------------
-- Tab: Komfort
------------------------------------------------------------------------
local langButtons = {}

local function BuildComfort()
    local p = Page("comfort")
    local L = LP.L
    Heading(p, 16, -14, L["Automatik"])
    Toggle(p, 16, -40, "autoSellGrey", L["Graue Gegenstände beim Händler verkaufen"])
    Toggle(p, 16, -64, "autoRepair", L["Beim Händler automatisch reparieren"])
    Toggle(p, 16, -88, "autoFly", L["Automatisch zum geplanten Flugziel fliegen"])
    Toggle(p, 16, -112, "useHearth", L["Ruhestein einplanen (binden und benutzen)"], function() LP.Planner:Replan() end)
    Heading(p, 16, -148, L["Anzeige & Gruppe"])
    Toggle(p, 16, -174, "showActionBar", L["Knöpfe „Ziel anvisieren“ und „Questgegenstand“"], function() LP.Actions:Update() end)
    Toggle(p, 16, -198, "showTimer", L["EP pro Stunde und Zeit bis zum nächsten Level"])
    Toggle(p, 16, -222, "showNewTag", L["Neue WoW-Forever-Quests markieren"])
    Toggle(p, 16, -246, "groupSync", L["Gruppenmodus (Fortschritt teilen)"], function() LP.Group:Refresh() LP.Planner:Replan() end)
    Toggle(p, 16, -270, "safeMode", L["Sicherer Modus: Elite und deutlich höhere Gegner meiden"], function() LP.Planner:Replan() LP.Nav:Recalc(true) end)
    Heading(p, 16, -306, L["Sprache"])
    -- alle Sprachen der WoW-Clients; jeder Knopf in der Schrift seiner Sprache (Kyrillisch, Hangul, Hanzi)
    local function langBtn(i, code, label)
        local b = LP.UI:Button(p, label, 80, 22, function()
            LP:SetLanguage(code)
            Ce:Refresh()
        end)
        b:SetPoint("TOPLEFT", 16 + ((i - 1) % 4) * 84, -330 - math.floor((i - 1) / 4) * 26)
        if code ~= "auto" then
            local path = LP:FontFor(code)
            pcall(b.label.SetFont, b.label, path, 11, "")
            rawset(b.label, "_lpFixedFont", path)   -- Name der Sprache bleibt in ihrer eigenen Schrift
            rawset(b, "fontPath", path)
        end
        b.label:SetWordWrap(false)
        b.label:SetWidth(76)
        langButtons[#langButtons + 1] = { button = b, code = code }
    end
    -- nur Sprachen, die dieses Spiel anzeigen kann (sonst stuenden dort nur Kaestchen)
    langBtn(1, "auto", L["Automatisch"])
    local n = 1
    for _, l in ipairs(LP.LANGUAGES) do
        if LP:CanDisplay(l.code) then n = n + 1 langBtn(n, l.code, l.name) end
    end

    Heading(p, 360, -14, L["Finde nächsten"])
    for i, k in ipairs(LP.Comfort.KINDS) do
        local b = LP.UI:Button(p, L[k.label], 150, 22, function() LP.Comfort:Find(k.key) end)
        b:SetPoint("TOPLEFT", 360 + ((i - 1) % 2) * 158, -40 - math.floor((i - 1) / 2) * 26)
    end
    Heading(p, 360, -160, L["Zeit"])
    p.timer = Info(p, 360, -184, 320)
end

local function RefreshComfort()
    local p = pages.comfort
    local L = LP.L
    for _, e in ipairs(langButtons) do
        local on = (LP.db.language or "auto") == e.code
        e.button.label:SetTextColor(on and 1 or C.muted[1], on and 1 or C.muted[2], on and 1 or C.muted[3])
    end
    local Co = LP.Comfort
    local rate = Co:XPPerHour()
    local lines = {
        L("EP pro Stunde: %s", rate and string.format("%.0f", rate) or L["noch zu wenig gespielt"]),
        L("Bis zum nächsten Level: %s", rate and Co.Dur(Co:TimeToLevel()) or "–"),
        L("Bis Level 60 (Schätzung): %s", rate and Co.Dur(Co:TimeTo60()) or "–"),
    }
    local lt = Co:LevelTimesText()
    if lt ~= "" then lines[#lines + 1] = "\n" .. L["Zeit je Level:"] .. "\n" .. lt end
    p.timer:SetText(table.concat(lines, "\n"))
end

------------------------------------------------------------------------
-- Fenster
------------------------------------------------------------------------
------------------------------------------------------------------------
-- Tab: Extras
------------------------------------------------------------------------
local function BuildExtras()
    local p = Page("extras")
    local L = LP.L
    local function nav() LP.Nav:Recalc(true) if LP.Pins then LP.Pins:Refresh() end end
    Heading(p, 16, -12, L["Karte & Questgegenstände"])
    Toggle(p, 16, -36, "mapAreas", L["Questgebiete auf Karte und Minikarte"], nav)
    Toggle(p, 16, -58, "mapAvailable", L["„!“ für annehmbare Quests"], nav)
    Toggle(p, 16, -80, "objPins", L["Fundstellen von Questgegenständen"], nav)
    Toggle(p, 16, -102, "objArrow", L["Pfeil zur nächsten Fundstelle"], nav)
    Toggle(p, 16, -124, "objAlert", L["Hinweis, wenn ein Questgegenstand nah ist"])
    Toggle(p, 16, -146, "tooltips", L["Tooltip-Hinweise (Gegner, Gegenstände, Objekte)"])
    Heading(p, 16, -176, L["Vorräte & Taschen"])
    Toggle(p, 16, -200, "restock", L["Beim Händler Vorräte nachkaufen"])
    Toggle(p, 16, -222, "restockFood", L["… Essen"])
    Toggle(p, 16, -244, "restockWater", L["… Wasser (Klassen mit Mana)"])
    Toggle(p, 16, -266, "restockAmmo", L["… Munition (Jäger)"])
    Toggle(p, 16, -288, "restockPetFood", L["… Tierfutter (Jäger)"])
    Toggle(p, 16, -310, "autoEquipRewards", L["Questbelohnung anlegen, wenn sie ein Upgrade ist"])
    Toggle(p, 16, -332, "bagCleanup", L["Hinweis: Gegenstände ohne Nutzen"])
    local b1 = LP.UI:Button(p, L["Quests teilen"], 104, 22, function() LP.Social:ShareQuests() end)
    b1:SetPoint("TOPLEFT", 16, -364)
    local b2 = LP.UI:Button(p, L["Gruppen-Text"], 104, 22, function()
        if not LP.Social:OpenGroupChat() then LP:Print(L["Für den aktuellen Schritt wird keine Gruppe gebraucht."]) end
    end)
    b2:SetPoint("TOPLEFT", 126, -364)
    local b3 = LP.UI:Button(p, L["Bilanz"], 104, 22, function() LP.Session:Summary(false) end)
    b3:SetPoint("TOPLEFT", 236, -364)
    Stepper(p, 16, -398, L["Gold fürs Reittier (Level 40)"], function() return LP.db.mountGold or 100 end,
        function(v) LP.db.mountGold = v end, 10, 10, 1000, "%dg")

    Heading(p, 360, -12, L["Zeit & Sitzung"])
    Toggle(p, 360, -36, "showEta", L["Zeit-Schätzung je Ziel und Zone"])
    Toggle(p, 360, -58, "showRested", L["Erholt-Bonus anzeigen"])
    Toggle(p, 360, -80, "showHearthCD", L["Ruhestein-Abklingzeit anzeigen"])
    Toggle(p, 360, -102, "welcomeSummary", L["„Wo war ich?“ beim Einloggen"])
    Toggle(p, 360, -124, "turninReminder", L["Hinweis auf offene Abgaben beim Zonenwechsel"])
    Toggle(p, 360, -146, "logoutSummary", L["Bilanz beim Ausloggen"])
    Toggle(p, 360, -168, "summaryGuild", L["… auch im Gildenchat"])
    Heading(p, 360, -198, L["Hinweise"])
    Toggle(p, 360, -222, "hintClassQuests", L["Klassenquests der nächsten Level"])
    Toggle(p, 360, -244, "hintClass", L["Klassen-Erinnerungen"])
    Toggle(p, 360, -266, "hintTrainer", L["Trainer-Besuche und Kosten"])
    Toggle(p, 360, -288, "hintMount", L["Reittier-Planung"])
    Toggle(p, 360, -310, "hintProfessions", L["Erste Hilfe und Kochen"])
    Heading(p, 360, -340, L["Gruppe"])
    Toggle(p, 360, -364, "groupFinderText", L["Text für die Gruppensuche anbieten"])
    Toggle(p, 360, -386, "findPartners", L["Mitspieler für Elite-Quests finden (zeigt anderen deinen Namen)"])
    Toggle(p, 360, -408, "protocol", L["Fehler-Protokoll mitschreiben (bleibt auf deinem Computer)"])
end

local TABS = {
    { "route", "Route" }, { "dungeons", "Dungeons" }, { "data", "Daten" }, { "share", "Austausch" },
    { "assist", "Assistent" }, { "comfort", "Komfort" }, { "extras", "Extras" }, { "settings", "Einstellungen" },
}

function Ce:Init()
    frame = CreateFrame("Frame", "LevelPilotCenter", UIParent, BACKDROP_TEMPLATE)
    frame:SetSize(W, H)
    frame:SetFrameStrata("HIGH")
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    LP.UI:Skin(frame, C.bg, C.border)
    if LP.db.centerPos then
        local p = LP.db.centerPos
        frame:SetPoint(p[1], UIParent, p[2], p[3], p[4])
    else
        frame:SetPoint("CENTER")
    end
    frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        LP.db.centerPos = { p, rp, x, y }
    end)
    frame:Hide()
    tinsert(UISpecialFrames, "LevelPilotCenter")

    local top = frame:CreateTexture(nil, "ARTWORK")
    top:SetHeight(2)
    top:SetPoint("TOPLEFT", 1, -1)
    top:SetPoint("TOPRIGHT", -1, -1)
    LP.UI:Gradient(top)

    local title = LP.UI:Text(frame, 16, C.text)
    title:SetPoint("TOPLEFT", 14, -12)
    title:SetText(L["|cffffb238Level|r|cff3dd694Pilot|r  |cff9c9ea6Zentrale · v"] .. LP.version .. "|r")
    local close = LP.UI:Button(frame, "x", 22, 22, function() frame:Hide() end)
    close:SetPoint("TOPRIGHT", -8, -8)

    for i, t in ipairs(TABS) do
        local b = LP.UI:Button(frame, LP.L[t[2]], 84, 24, function() Ce:Select(t[1]) end)
        b:SetPoint("TOPLEFT", 14 + (i - 1) * 87, -40)
        tabs[t[1]] = b
    end

    BuildRoute()
    BuildDungeons()
    BuildComfort()
    BuildData()
    BuildShare()
    BuildAssist()
    BuildSettings()
    BuildExtras()

    LP:Listen("PLAN_CHANGED", function() if frame:IsShown() then Ce:Refresh() end end)
    LP:Listen("HINTS_CHANGED", function() if frame:IsShown() then Ce:Refresh() end end)
end

function Ce:Select(key)
    active = key
    self:Refresh()
end

function Ce:Toggle(key)
    if not frame then return end
    if frame:IsShown() and (not key or key == active) then
        frame:Hide()
        return
    end
    if key then active = key end
    frame:Show()
    self:Refresh()
end

function Ce:Refresh()
    if not frame or not frame:IsShown() then return end
    for key, b in pairs(tabs) do
        if key == active then
            b:SetBackdropColor(C.accent[1] * 0.45, C.accent[2] * 0.45, C.accent[3] * 0.45, 1)
            b.label:SetTextColor(1, 1, 1)
        else
            b:SetBackdropColor(C.row[1], C.row[2], C.row[3], C.row[4])
            b.label:SetTextColor(C.muted[1], C.muted[2], C.muted[3])
        end
    end
    for key, p in pairs(pages) do
        p:SetShown(key == active)
        if key == active then
            for _, t in ipairs(pageToggles[p] or {}) do t() end
            for _, s in ipairs(pageSteppers[p] or {}) do s() end
        end
    end
    if active == "route" then RefreshRoute()
    elseif active == "data" then RefreshData()
    elseif active == "share" then RefreshShare()
    elseif active == "assist" then RefreshAssist()
    elseif active == "dungeons" then RefreshDungeons()
    elseif active == "comfort" then RefreshComfort() end
end
