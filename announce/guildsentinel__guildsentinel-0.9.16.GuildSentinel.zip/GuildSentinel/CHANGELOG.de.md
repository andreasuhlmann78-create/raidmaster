# GuildSentinel – Änderungen

## 0.9.16
Wunsch des Nutzers: Berufe der Mitglieder und neuer Mitglieder automatisch einlesen.
- **Berufe aller Mitglieder automatisch**: Wo das Spiel die Berufe der Gilde selbst kennt (Gilden-Berufsliste, GetGuildTradeSkillInfo – über ns.API, fehlt sie, passiert nichts), liest GuildSentinel die Stufen aller Mitglieder, auch ohne GuildSentinel. Höchstens alle 5 Minuten, nicht im Kampf nötig, nur lesen. Rezepte kommen weiter nur von Spielern mit GuildSentinel bzw. RaidMaster, die ihr Berufsfenster geöffnet haben; deren Angaben gehen immer vor (Einträge aus der Gildenliste: t = 0, g = true).
- **Neue Mitglieder**: Wer der Gilde beitritt, während er online ist, schickt seine Berufe sofort (bisher erst beim nächsten Einloggen).
- Diagnose-Protokoll: einmal je Sitzung "Gilden-Berufsliste: n Zeilen, … Mitglieder" – so zeigt sich, ob die Spielversion die Liste liefert.
- Testroutine: T190 (Gildenliste über ns.API nachgestellt), T191 (im Spiel).

## 0.9.15
Empfehlung der Prüf-Sitzung (Nachricht vom 9. Nov.): Diagnose-Protokoll wie in der Vorlage.
- **Diagnose-Protokoll** (Diag.lua): GuildSentinel schreibt Probleme mit, die nur im echten Spiel auftreten – langsame Seiten (über 16 ms), blockierte Aktionen mit Aufrufort (debugstack bei ADDON_ACTION_BLOCKED/FORBIDDEN), Fehler (gleiche nur gezählt). Keine Spieler-, Gilden- oder Realmnamen. `/gs protokoll` zeigt es zum Kopieren; beim Ausloggen bzw. /reload liegt es als GSDIAG1 in GuildSentinelDB.diagExport (Uploader -> #testberichte). Im Testmodus und während der Testroutine wird nichts geschrieben.
- Testroutine: T188 (Protokoll: Einträge, Zähler, Export, keine Namen), T189 (im Spiel).
- Zum Befund "4× ADDON_ACTION_BLOCKED UNKNOWN() mit 0.9.13": Der Aufrufort stand schon im Testbericht (Professions.lua:346 OpenModern <- Pages.lua:1505, Timer nach dem Berufe-Knopf) und ist seit 0.9.14 behoben.

## 0.9.14
Befunde aus der Testroutine im Spiel (Launch-Abend WoW Forever, offen-guildsentinel.txt Punkt 3) und
anweisung-testroutine-oberflaeche.txt:
- **T143 Grosse Gilden**: Übersicht und Leitung ruckeln nicht mehr bei Hunderten Mitgliedern. Main/Twink wird je Seitenaufbau nur einmal berechnet (Roster:Memo), die Übersicht gruppiert in einem Durchgang – mit 500 Mitgliedern etwa 25× schneller.
- **Berufe-Knopf (WoW Forever)**: kein "Aktion blockiert" mehr (Fehlerbericht vom Launch). Geht das Berufsfenster nicht auf, kommt ein Hinweis, statt die geschützte Funktion C_TradeSkillUI.OpenTradeSkill aus einem Timer aufzurufen.
- **T118 Chronik/Erfolge**: kaputte Berufsdaten lassen die Seite nicht mehr abstürzen (Typprüfung, Prof:All überspringt kaputte Einträge).
- **T45 Termin ansagen**: im Testmodus auch ohne echte Gilde nur "[Test]" im Chat (ns.Announce nutzt ns.InGuild); gesendet wird weiterhin nichts.
- **T154**: Der Fall läuft unabhängig von den Einstellungen des Spielers (Funktion "Danke" aus, schon gedankt) und zeigt im Ergebnis, was GuildSentinel ausgibt.
- Testroutine: neuer Bereich K "Oberfläche im echten Client" (T182 Tooltips verdecken keine Knöpfe, T183 kein Überlappen mit anderen Fenstern, T184 im Bildschirm, T185 Texte passen, T186 Spielwerte plausibel, T187 keine Fehlerschleifen); T143 nennt die langsamste Seite.

## 0.9.13
- **Sprache für alle wählbar**: Einstellungen > Allgemein > "Sprache". Beim Start nimmt GuildSentinel weiter die Sprache des Spiel-Clients; wählbar sind auf jedem Client Deutsch, Englisch, Französisch, Spanisch (Spanien/Mexiko), Italienisch und Portugiesisch (Russisch, Koreanisch und Chinesisch auf einem Client in dieser Sprache). GuildSentinel lädt nach der Wahl neu; "Wie der Spiel-Client" stellt zurück. Ersetzt die Wahl nur für den Entwickler aus 0.9.12.
- Testroutine: T122 beachtet die gewählte Sprache, T127 prüft jetzt im Spiel alle geladenen Sprachen auf Vollständigkeit.

## 0.9.12
- Nur für den Entwickler: Unter Einstellungen > Testmodus lässt sich die Sprache zwischen Deutsch, Englisch und der Sprache des Spiel-Clients umschalten (für Screenshots); GuildSentinel lädt danach neu. Für Spieler ändert sich nichts – GuildSentinel nimmt immer die Sprache des Spiel-Clients.

## 0.9.11
Aufträge der Prüf-Sitzung (offen-guildsentinel.txt, anweisung-guildsentinel-gildenbank.txt):
- **Bank-Charakter: Bestand an Discord** (freiwillig, ab Werk aus): Auf dem Bank-Charakter der Gilde unter Einstellungen > Allgemein "Bank-Charakter (Bestand an Discord)" anhaken. Beim Öffnen von Bank, Briefkasten und – wo es sie gibt – Gildenbank liest GuildSentinel dann Taschen, Bank, Post-Anhänge und Gildenbankfächer (nur lesen, nie im Kampf, in kleinen Schritten). Der RaidMaster-Uploader schickt den Bestand mit dem nächsten Upload mit, der RaidMaster-Bot zeigt ihn in #gildenbank und bei /bank. Gilden ohne RaidMaster-Bot merken nichts davon.
- **Twink-Notizen mit Vor- und Nachnamen** (WoW Forever) auf koreanischen und chinesischen Clients, bei denen der Name vor der Kennzeichnung steht ("Rokan Steinwacht의 부캐릭터"), werden wieder erkannt.
- **Main wechseln** entfernt die alte Kennzeichnung jetzt ganz – mit Vor- und Nachnamen und in der Sprache des Clients ("Alt: Vorname Nachname", "Reroll de …") –, statt Reste in der Notiz stehen zu lassen.
- **Termin-Abgleich**: Ein kaputter Eintrag verwirft nicht mehr die übrigen Termine desselben Pakets.
- Alle Spielfunktionen, die GuildSentinel braucht, werden jetzt an einer Stelle gewählt (API.lua, moderne API zuerst, alte als Rückfall). Für Spieler ändert sich nichts.
- Testroutine (Entwickler): echte Sendungen sind im Bericht jetzt ein FEHLER (T82), jede Aktion mit Folgen wird auf den einen Weg über ns.Act geprüft (T174), neue Fälle für Export, Termin-Ansage, Vor- und Nachnamen und den Bank-Charakter (T31, T45, T154, T175–T181); die Fälle, die früher eine Blizzard-Funktion ersetzt hätten (T92, T93b, T96b, T97b, T99, T114, T159, T161, T166), laufen jetzt auch im Spiel – über ns.API.

## 0.9.10
- **Twink-Notizen in der Sprache des Clients**: Notizen, die GuildSentinel selbst schreibt ("Reroll de …", "… 的分身" usw.), werden auf französischen, spanischen, italienischen, portugiesischen, koreanischen und chinesischen Clients wieder erkannt. Wo die Kennzeichnung nicht in die kurze Gildennotiz passt (Russisch), schreibt GuildSentinel die Kurzform "Alt: Name".
- **AHSentinel** (früher AH Analyzer Pro) wird unter dem neuen Ordnernamen erkannt (Seite Addons, Marktwerte).
- **Bewerber-Flüstern im Kampf** (WoW Forever): Mehr als 30 Flüsternachrichten in einem Kampf werden jetzt im Hinweis mitgezählt, statt still wegzufallen.
- Robuster bei beschädigten Daten: fehlerhafte Termin-Abgleiche und kaputte Termin- oder Danke-Einträge lösen keine Fehler mehr aus.
- Testmodus (nur Entwickler): betritt oder verlässt den Server-Kanal nicht mehr, sendet nach "Testmodus beenden" nichts Verzögertes mehr und lässt die echten Einstellungen (letzte Werbung, Frei-Meldung, Meine Woche) unberührt.
- Neu für den Entwickler: `/gs testroutine` (Knopf "Alles testen" unter Einstellungen > Testmodus) prüft alle Funktionen und speichert einen Bericht für die Prüfung von GoldSentinel; die Diagnose zeigt den Fehlerzähler. Für Spieler ändert sich nichts.

Ältere Versionen: siehe LIESMICH.txt.
