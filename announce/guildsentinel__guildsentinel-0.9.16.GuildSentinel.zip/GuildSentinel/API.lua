-- GuildSentinel - API.lua
-- Zugriff auf die Spiel-API an EINER Stelle (Vorbild: raidmaster/shared/vorlage/__ADDON__/API.lua).
--
-- ns.API: Jede Blizzard-Funktion, die hier steht, wird beim Laden einmal ausgewählt – die moderne C_*-Funktion
-- (WoW Forever) und die alte Funktion (Classic Era, TBC Anniversary) stehen als eigene Einträge daneben. Der übrige
-- Code ruft nur ns.API.X auf (oder eine Hilfsfunktion unten).
-- Vorteile:
--   * GuildSentinel ersetzt nie eine Blizzard-Funktion (kein "taint").
--   * Die Testroutine (TestRoutine.lua) kann einzelne Einträge DIESER Tabelle kurz durch nil oder eine Attrappe
--     ersetzen und so alte bzw. moderne Clients nachstellen – im echten Spiel, ohne Folgen für andere Addons.
-- Aktionen mit Folgen (Chat, Einladen, Notizen …) laufen zusätzlich über ns.Act (Core.lua).

local ADDON, ns = ...

local API = {}
ns.API = API

-- erste vorhandene Funktion
local function pick(...)
	for i = 1, select("#", ...) do
		local f = select(i, ...)
		if type(f) == "function" then return f end
	end
	return nil
end
API.pick = pick

------------------------------------------------------------
-- Geschützte Werte (WoW Forever: "secret values")
------------------------------------------------------------
-- über GoldSentinelGame (gemeinsam mit allen GoldSentinel-Addons); ohne die Datei direkt über issecretvalue
local GSG = _G.GoldSentinelGame
if GSG and type(GSG.IsSecret) == "function" then
	API.IsSecret = GSG.IsSecret
elseif type(issecretvalue) == "function" then
	local isv = issecretvalue
	API.IsSecret = function(v)
		if v == nil then return false end
		local ok, r = pcall(isv, v)
		return ok and r == true
	end
end

------------------------------------------------------------
-- Gilde und Rechte
------------------------------------------------------------
API.IsInGuild = pick(IsInGuild)
API.IsGuildLeader = pick(IsGuildLeader)
API.C_CanEditOfficerNote = pick(C_GuildInfo and C_GuildInfo.CanEditOfficerNote)   -- moderner Client
API.CanEditOfficerNote = pick(CanEditOfficerNote)                                 -- alter Weg
API.CanGuildRemove = pick(CanGuildRemove)
API.CanGuildPromote = pick(CanGuildPromote)
API.CanGuildInvite = pick(CanGuildInvite)

------------------------------------------------------------
-- Zaubernamen und Quests
------------------------------------------------------------
API.C_GetSpellName = pick(C_Spell and C_Spell.GetSpellName)                       -- moderner Client
API.GetSpellInfo = pick(GetSpellInfo)                                             -- alter Weg
API.C_IsQuestFlaggedCompleted = pick(C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted)
API.IsQuestFlaggedCompleted = pick(IsQuestFlaggedCompleted)

------------------------------------------------------------
-- Chat (gesendet wird nur über ns.Chat -> ns.Act)
------------------------------------------------------------
API.C_SendChatMessage = pick(C_ChatInfo and C_ChatInfo.SendChatMessage)           -- moderner Client
API.SendChatMessage = pick(SendChatMessage)                                       -- alter Weg

------------------------------------------------------------
-- Gegenstände, Taschen, Bank, Post, Gildenbank (Bank-Charakter, Bank.lua)
------------------------------------------------------------
API.GetItemInfo = pick(C_Item and C_Item.GetItemInfo, GetItemInfo)
API.GetMoney = pick(GetMoney)
API.C_GetContainerNumSlots = pick(C_Container and C_Container.GetContainerNumSlots)
API.C_GetContainerItemInfo = pick(C_Container and C_Container.GetContainerItemInfo)
API.GetContainerNumSlots = pick(GetContainerNumSlots)
API.GetContainerItemInfo = pick(GetContainerItemInfo)
API.GetContainerItemLink = pick(GetContainerItemLink)
API.GetInboxNumItems = pick(GetInboxNumItems)
API.GetInboxItem = pick(GetInboxItem)
API.GetInboxItemLink = pick(GetInboxItemLink)
API.GetNumGuildBankTabs = pick(GetNumGuildBankTabs)
API.GetGuildBankItemLink = pick(GetGuildBankItemLink)
API.GetGuildBankItemInfo = pick(GetGuildBankItemInfo)
API.GetGuildBankMoney = pick(GetGuildBankMoney)
API.QueryGuildBankTab = pick(QueryGuildBankTab)

------------------------------------------------------------
-- Gilden-Berufsliste des Spiels (nur wo es sie gibt, vermutlich WoW Forever): Berufe aller Mitglieder ohne Addon
------------------------------------------------------------
API.GetNumGuildTradeSkill = pick(GetNumGuildTradeSkill)
API.GetGuildTradeSkillInfo = pick(GetGuildTradeSkillInfo)

------------------------------------------------------------
-- Hilfsfunktionen (moderner Weg zuerst, alter Weg als Rückfall)
------------------------------------------------------------
-- Zaubername zu einer ID (nil, wenn unbekannt oder keine API da ist)
function ns.SpellName(id)
	if API.C_GetSpellName then return API.C_GetSpellName(id) end
	if API.GetSpellInfo then return (API.GetSpellInfo(id)) end
	return nil
end

-- Quest schon erledigt?
function ns.QuestDone(id)
	if API.C_IsQuestFlaggedCompleted then return API.C_IsQuestFlaggedCompleted(id) and true or false end
	if API.IsQuestFlaggedCompleted then return API.IsQuestFlaggedCompleted(id) and true or false end
	return false
end

-- Funktion zum Senden einer Chat-Nachricht (moderner Weg zuerst)
function ns.ChatSender()
	return API.C_SendChatMessage or API.SendChatMessage
end

-- Behälter: Anzahl Fächer
function ns.ContainerSlots(bag)
	if API.C_GetContainerNumSlots then return API.C_GetContainerNumSlots(bag) or 0 end
	if API.GetContainerNumSlots then return API.GetContainerNumSlots(bag) or 0 end
	return 0
end

-- Behälter: Link, Anzahl, Symbol eines Fachs (nil, wenn leer)
function ns.ContainerSlot(bag, slot)
	if API.C_GetContainerItemInfo then
		local info = API.C_GetContainerItemInfo(bag, slot)
		if type(info) == "table" then return info.hyperlink, info.stackCount or 1, info.iconFileID end
		return nil
	end
	if API.GetContainerItemInfo then
		local icon, count, _, _, _, _, link = API.GetContainerItemInfo(bag, slot)
		if not link and API.GetContainerItemLink then link = API.GetContainerItemLink(bag, slot) end
		return link, count or 1, icon
	end
	return nil
end
