-- LevelPilot - Automatische Routenplanung
-- Ablauf:
--   1) Kandidaten: alle Quests im passenden Levelbereich fuer Volk/Klasse (bei Levelaufstieg neu)
--   2) Aufgaben: annehmbare Quests (Questgeber), offene Ziele, fertige Quests (Abgabe)
--   3) Fokus-Zone: Zone mit dem besten Verhaeltnis Nutzen / Reiseweg
--   4) Reihenfolge: naechster-Nachbar ueber Weglaengen, Annehmen/Abgeben bevorzugt
--   5) Reise: Zonenwechsel ueber das Wegenetz, lange Strecken per Flugpunkt
--   Speedrun: laesst langsame/ineffiziente Quests aus (EP pro Zeit), Klassenquests bleiben immer.
--   Dungeons: Dungeon-Quests werden mitgenommen, wenn man ohnehin beim Questgeber ist; der
--   Lauf selbst wird als ein Schritt eingeplant, sobald Level und Anzahl der Quests passen.

local _, LP = ...
local L = LP.L
local P = {}
LP:RegisterModule("Planner", P)

P.steps = {}
P.focus = nil
P.status = ""
local candidates = {}
local candLevel = -1
local MAX_STEPS = 12
local NOT_OFFERED_SECS = 900

------------------------------------------------------------------------
-- Status der Quests im Spiel
------------------------------------------------------------------------
local inLog = {}     -- [id] = { complete, index, title, objDone = {..} }

local function ScanLog()
    wipe(inLog)
    for _, q in ipairs(LP.API.Quests()) do
        local objs = LP.API.Objectives(q.index)
        local complete = q.complete
        if not complete and #objs == 0 then complete = true end
        local objDone = {}
        for o, ob in ipairs(objs) do objDone[o] = ob.finished end
        inLog[q.id] = { complete = complete, index = q.index, title = q.title, objDone = objDone, failed = q.failed }
    end
end
P.inLog = inLog

local function Done(id)
    if LP.char.turnedIn[id] then return true end
    return LP.API.IsQuestDone(id)
end
P.IsDone = Done

local function GreyRange(level)
    return LP.API.GreenRange(level)
end

------------------------------------------------------------------------
-- 1) Kandidaten
------------------------------------------------------------------------
function P:BuildCandidates()
    local level = LP:PlayerLevel() or 1
    wipe(candidates)
    local QDB = LP.QuestDB
    local f = LP:PlayerFaction() == "Horde" and "H" or "A"
    for ci, id in ipairs(QDB:AllIds()) do
        if ci % 200 == 0 then LP:Yield("plan") end
        local info = QDB:QuickInfo(id)
        if info then
            local ql = info.level or 0
            if ql <= 0 then ql = info.reqLevel or 1 end
            if (info.reqLevel or 0) <= level + 1 and ql <= level + 4 and ql >= level - 12 then
                local ok = true
                if info.faction and info.faction ~= f then ok = false end
                if ok then ok = QDB:RaceOk(info.races, info.raceSys) end
                if ok and info.classes and info.classes ~= 0 and QDB.classBit then
                    ok = LP.HasBit(info.classes, QDB.classBit)
                end
                if ok and info.specialFlags and LP.HasBit(info.specialFlags, 1) then ok = false end
                if ok and info.dungeon and not P:DungeonUsable(info.dungeon) then ok = false end
                if ok then candidates[#candidates + 1] = id end
            end
        end
    end
    candLevel = level
    self:BuildProtected()
end

------------------------------------------------------------------------
-- 2) Verfuegbarkeit einer Quest
------------------------------------------------------------------------
local function AllDone(list)
    if type(list) ~= "table" then return true end
    for _, id in ipairs(list) do if not Done(id) then return false end end
    return true
end

local function AnyDone(list)
    if type(list) ~= "table" or #list == 0 then return true end
    for _, id in ipairs(list) do if Done(id) then return true end end
    return false
end

local function NoneTaken(list)
    if type(list) ~= "table" then return true end
    for _, id in ipairs(list) do
        if Done(id) or inLog[id] then return false end
    end
    return true
end

-- Heimatgebiete der Fraktionen: Quests ohne Volksbeschraenkung, deren Questgeber oder Abgabe dort steht,
-- sind fuer die andere Fraktion praktisch nicht machbar (feindliche Wachen, feindliche NPCs).
-- Neutrale Orte (Beutebucht, Ratschet, Gadgetzan ...) liegen in umkaempften Zonen und sind nicht betroffen.
local HOME_ZONES = {
    Alliance = { [1429] = true, [1436] = true, [1433] = true, [1431] = true, [1426] = true, [1432] = true,
                 [1438] = true, [1439] = true, [1437] = true, [1453] = true, [1455] = true, [1457] = true },
    Horde    = { [1411] = true, [1412] = true, [1420] = true, [1421] = true, [1454] = true, [1456] = true, [1458] = true },
}
local BATTLEGROUNDS = { [1459] = true, [1460] = true, [1461] = true }   -- Alteractal, Warsongschlucht, Arathibecken

local function InEnemyHome(q)
    local mine = LP:PlayerFaction()
    local enemy = HOME_ZONES[mine == "Horde" and "Alliance" or "Horde"]
    for _, list in ipairs({ q.starts, q.ends }) do
        for _, p in ipairs(list or {}) do
            if enemy[p[1]] then return true end
        end
    end
    return false
end

local function OnBattleground(q)
    for _, list in ipairs({ q.starts, q.ends }) do
        for _, p in ipairs(list or {}) do if BATTLEGROUNDS[p[1]] then return true end end
    end
    for _, o in ipairs(q.objectives or {}) do
        for _, p in ipairs(o.spots or {}) do if BATTLEGROUNDS[p[1]] then return true end end
    end
    return false
end
P.InEnemyHome, P.OnBattleground = InEnemyHome, OnBattleground

function P:IsAvailable(q, level)
    local id = q.id
    if Done(id) or inLog[id] then return false end
    if LP.char.ignored[id] then return false end
    local no = LP.char.notOffered[id]
    if no and LP:Now() - no < NOT_OFFERED_SECS then return false end
    if (q.reqLevel or 0) > level then return false end
    local ql = q.level or 0
    if ql > 0 and ql > level + 3 then return false end
    if ql > 0 and ql < level - GreyRange(level) then return false end
    if not LP.QuestDB:FitsPlayer(q) then return false end
    if q.repeatable or q.itemStart then return false end
    if #q.starts == 0 then return false end
    if q.pvp or OnBattleground(q) then return false end                -- Schlachtfelder: kein Questen
    if (q.races or 0) == 0 and InEnemyHome(q) then return false end   -- Gebiet der anderen Fraktion
    if q.skill or q.minRep then return false end
    if q.parent and q.parent ~= 0 and not inLog[q.parent] then return false end
    if not AllDone(q.pre) then return false end
    if not AnyDone(q.preAny) then return false end
    if not NoneTaken(q.exclusive) then return false end
    if q.nextInChain and q.nextInChain ~= 0 and (Done(q.nextInChain) or inLog[q.nextInChain]) then return false end
    return true
end

------------------------------------------------------------------------
-- Hilfen: Punkte & Entfernungen
------------------------------------------------------------------------
local function WorldOf(pt)
    if not pt then return nil end
    return LP.Geo:ToWorld(pt[1], pt[2], pt[3])
end

-- naechster Punkt einer Liste zum Bezugspunkt (Weltkoordinaten)
local function NearestPoint(points, inst, n, w)
    local best, bestD, bestW
    for _, pt in ipairs(points or {}) do
        local i, pn, pw = WorldOf(pt)
        if i then
            local d
            if i == inst then d = LP.Geo:Dist(n, w, pn, pw) else d = 1e6 end
            if not bestD or d < bestD then best, bestD, bestW = pt, d, { i, pn, pw } end
        end
    end
    return best, bestD, bestW
end

------------------------------------------------------------------------
-- 3) Aufgaben sammeln
------------------------------------------------------------------------
-- Wert einer Quest nach Abstand zum eigenen Level (gelb/orange am wertvollsten)
local function LevelWeight(qLevel, level)
    if not qLevel or qLevel <= 0 then return 0.8 end
    local d = qLevel - level
    if d >= 4 then return 0.4 end          -- rot: zu schwer
    if d >= 0 then return 1.5 end          -- gelb/orange
    if d >= -3 then return 1.0 end         -- gruen
    if d >= -6 then return 0.5 end         -- fast grau
    return 0.2
end
P.LevelWeight = LevelWeight

------------------------------------------------------------------------
-- Speedrun
------------------------------------------------------------------------
-- Strenge: Quests auslassen, die weniger als x der Grind-EP je Minute bringen
local SPEED_CUTOFF = { [1] = 0.6, [2] = 0.9, [3] = 1.2 }   -- locker / mittel / streng
local SPEED_NAMES = { [1] = "locker", [2] = "mittel", [3] = "streng" }
P.SPEED_NAMES = SPEED_NAMES
local SPEED_LOW = 5         -- Quests ab 5 Stufen unter dem eigenen Level auslassen
local SPEED_DUNGEON_MIN = 3 -- Dungeon-Lauf im Speedrun erst ab 3 Quests
local RUN_SPEED = 7         -- Yards je Sekunde zu Fuss
local OBJ_SECS = { kill = 150, item = 240, object = 90, explore = 40, rec = 150 }
local protected = {}
P.speedSkip = {}            -- [questID] = Grund (nur im Speedrun)

function P:IsSpeed() return LP.char.mode == "speed" end

function P:SetMode(mode)
    mode = mode == "speed" and "speed" or "normal"
    if LP.char.mode == mode then return end
    LP.char.mode = mode
    candLevel = -1
    LP:Print(mode == "speed"
        and L["|cffff7a3cSpeedrun|r aktiv: Quests, die weniger EP pro Minute bringen als Grinden, werden ausgelassen – Klassenquests bleiben."]
        or L["Normales Questen aktiv: alle passenden Quests werden eingeplant."])
    self:Replan()
    LP:Fire("MODE_CHANGED", mode)
end

function P:ToggleMode() self:SetMode(self:IsSpeed() and "normal" or "speed") end

local CLASS_LIST = { 1, 2, 4, 8, 16, 64, 128, 256, 1024 }
local function IsClassQuest(classes)
    if not classes or classes == 0 then return false end
    local c = 0
    for _, b in ipairs(CLASS_LIST) do if LP.HasBit(classes, b) then c = c + 1 end end
    return c > 0 and c <= 3
end
P.IsClassQuest = IsClassQuest

-- Klassenquests und alle ihre Vorquests sind im Speedrun geschuetzt
function P:BuildProtected()
    wipe(protected)
    local function mark(id, depth)
        if protected[id] or depth > 8 then return end
        protected[id] = true
        local q = LP.QuestDB:Get(id)
        if not q then return end
        for _, pid in ipairs(type(q.pre) == "table" and q.pre or {}) do mark(pid, depth + 1) end
        for _, pid in ipairs(type(q.preAny) == "table" and q.preAny or {}) do mark(pid, depth + 1) end
    end
    for _, id in ipairs(candidates) do
        local info = LP.QuestDB:QuickInfo(id)
        if info and IsClassQuest(info.classes) then mark(id, 0) end
    end
end

function P:IsProtected(id)
    if protected[id] then return true end
    local q = LP.QuestDB:Get(id)
    return q and IsClassQuest(q.classes) or false
end

-- Geschaetzte Zeit fuer eine Quest ab dem Questgeber: Ziele + Wege + Abgabe (Sekunden)
local function QuestSeconds(q)
    local secs = 20
    local ci, cn, cw = nil, nil, nil
    if q.starts[1] then ci, cn, cw = LP.Geo:ToWorld(q.starts[1][1], q.starts[1][2], q.starts[1][3]) end
    local function hop(points)
        local best, bi, bn, bw
        for _, pt in ipairs(points or {}) do
            local i, pn, pw = LP.Geo:ToWorld(pt[1], pt[2], pt[3])
            if i then
                local d = (ci and i == ci) and LP.Geo:Dist(cn, cw, pn, pw) / RUN_SPEED or 900
                if not best or d < best then best, bi, bn, bw = d, i, pn, pw end
            end
        end
        if best then secs = secs + best ci, cn, cw = bi, bn, bw end
    end
    for _, o in ipairs(q.objectives) do
        secs = secs + (OBJ_SECS[o.kind] or 150) + (o.elite and 600 or 0)
        hop(o.spots)
    end
    hop(q.ends)
    if q.escort then secs = secs + 600 end
    return secs
end

-- EP einer Quest fuer dieses Level (Classic-Abzug fuer niedrige Quests)
-- Grund-EP: im Spiel gemessen (WoW Forever) vor Classic-Tabelle
P.QuestSeconds = function(q) return QuestSeconds(q) end

local function BaseXP(q)
    local ql = (q.level and q.level > 0) and q.level or nil
    if q.xpReal and q.xpRealLvl and (not ql or q.xpRealLvl <= ql + 4) then return q.xpReal, true end
    return q.xp, false
end
P.BaseXP = BaseXP

local function QuestXPFor(q, level)
    local base = BaseXP(q)
    if not base or base <= 0 then return nil end
    local ql = (q.level and q.level > 0) and q.level or level
    local mult = math.max(1, math.min(10, 2 * (ql - level) + 20)) / 10
    return base * mult
end

-- Monster-EP je Minute beim Grinden auf diesem Level (Classic: 45 + 5 x Level je Kill, ~2 Kills/Min)
local function GrindRate(level) return (45 + 5 * level) * 2 end
P.GrindRate = GrindRate

-- EP je Minute einer Quest inkl. Monster-EP beim Toeten (nil = unbekannt)
function P:Efficiency(q, level)
    local xp = QuestXPFor(q, level)
    if not xp then return nil end
    local secs = QuestSeconds(q)
    local tag = LP.API.QuestTag(q.id)
    if tag == 1 and not q.elite then secs = secs + 600 end      -- laut Spiel Gruppenquest
    local killSecs = 0
    for _, o in ipairs(q.objectives) do if o.kind == "kill" or o.kind == "item" then killSecs = killSecs + (OBJ_SECS[o.kind] or 0) end end
    xp = xp + killSecs / 60 * GrindRate(level) * 0.8
    return xp / (secs / 60)
end

-- Warum laesst der Speedrun diese Quest aus? (nil = behalten)
local function SpeedReason(q, level)
    if q.dungeon then return nil end                       -- Dungeons haben eigene Regeln
    local tag = LP.API.QuestTag(q.id)
    if tag == 62 or tag == 41 then return L["Schlachtzug/PvP"] end
    if q.escort or tag == 84 then return L["Eskorte"] end
    if q.level and q.level > 0 and q.level <= level - SPEED_LOW then return L["zu niedrig"] end
    return nil
end

------------------------------------------------------------------------
-- Dungeons
------------------------------------------------------------------------
local DUNGEON_RETRY = 3          -- Stufen bis ein abgebrochener/uebersprungener Dungeon wiederkommt
local DUNGEON_LOG_FREE = 4       -- so viele Plaetze im Questlog bleiben fuer normale Quests frei
local PREP_RANGE = 2500          -- Yards: Dungeon-Quests in diesem Umkreis vor dem Lauf einsammeln

function P:DungeonUsable(area)
    if LP.db.dungeons == false then return false end
    return (LP.QuestDB:DungeonAllowed(area))
end

local function Round(v) return math.floor(v + 0.5) end

-- Questziele einer Dungeon-Quest, die wirklich draussen liegen. Die Questdaten projizieren Gegner
-- im Dungeon oft auf die Karte darueber - solche Orte nahe am Eingang zaehlen als "im Dungeon".
local INSIDE_RANGE = 600
local function OutsideSpots(area, spots)
    local d = LP.QuestDB:Dungeon(area)
    if not d then return spots end
    local ents = {}
    for _, e in ipairs(d.e or {}) do
        local i, en, ew = LP.Geo:ToWorld(e[1], e[2], e[3])
        if i then ents[#ents + 1] = { i, en, ew } end
    end
    local out = {}
    for _, sp in ipairs(spots) do
        local i, sn, sw = WorldOf(sp)
        if i then
            local inside = false
            for _, e in ipairs(ents) do
                if e[1] == i and LP.Geo:Dist(sn, sw, e[2], e[3]) < INSIDE_RANGE then inside = true break end
            end
            if not inside then out[#out + 1] = sp end
        end
    end
    return out
end
P.OutsideSpots = OutsideSpots

local function MakeTask(t, q, pt, wpos, value, text)
    return {
        t = t, id = q and q.id, q = q and q.name, level = q and q.level,
        map = pt and pt[1], x = pt and pt[2], y = pt and pt[3], npc = pt and pt[4],
        inst = wpos and wpos[1], n = wpos and wpos[2], w = wpos and wpos[3],
        value = value, text = text, isNew = q and q.isNew or nil,
        key = t .. ":" .. (q and q.id or (pt and (pt[1] .. ":" .. math.floor(pt[2]) .. ":" .. math.floor(pt[3])) or "?")),
    }
end

P.safeSkip = {}

function P:CollectTasks(inst, n, w, level)
    wipe(self.safeSkip)
    local tasks = {}
    local dq = {}        -- [Dungeon] = offene Dungeon-Quests im Log
    local logCount = 0
    for _ in pairs(inLog) do logCount = logCount + 1 end
    local maxLog = LP.API.MaxQuests()
    local turninBoost = logCount >= maxLog - 4 and 2 or 1
    local accepts = {}   -- annehmbare Quests (Speedrun filtert danach)
    local speed = self:IsSpeed()
    -- aktive Quests
    for id, st in pairs(inLog) do
        if not LP.char.ignored[id] and not st.failed then
            local q = LP.QuestDB:Get(id) or { id = id, name = st.title, starts = {}, ends = {}, objectives = {} }
            -- Titel aus dem Questlog nur, wenn kein Sprachpaket einen in der eingestellten Sprache kennt
            if LP.Names and LP.Names:Foreign() then q.name = LP.Names:Quest(id) or st.title or q.name
            else q.name = st.title or q.name end
            if st.complete then
                local pt, _, wp = NearestPoint(q.ends, inst, n, w)
                tasks[#tasks + 1] = MakeTask("TURNIN", q, pt, wp, (2 * LevelWeight(q.level, level) + 1) * turninBoost)
            else
                -- naechster Ort eines noch offenen Ziels
                local spots = {}
                for oi, o in ipairs(q.objectives) do
                    local idx = o.idx or oi
                    if not st.objDone[idx] then
                        for _, s in ipairs(o.spots) do spots[#spots + 1] = s end
                    end
                end
                if #spots == 0 then
                    for _, o in ipairs(q.objectives) do
                        for _, s in ipairs(o.spots) do spots[#spots + 1] = s end
                    end
                end
                local area = q.dungeon
                if area then spots = OutsideSpots(area, spots) end
                local pt, _, wp = NearestPoint(spots, inst, n, w)
                if area and not pt then
                    -- Ziele liegen in der Instanz: gesammelt als ein Dungeon-Lauf
                    local grey = q.level and q.level > 0 and q.level < level - GreyRange(level)
                    if self:DungeonUsable(area) and not grey then
                        dq[area] = dq[area] or {}
                        table.insert(dq[area], q)
                    end
                else
                    local v = 1.5 * LevelWeight(q.level, level) + 0.5
                    -- Speedrun: angefangene langsame Quests nur noch nebenbei
                    if speed and not self:IsProtected(id) and (q.elite or q.escort) then v = v * 0.5 end
                    tasks[#tasks + 1] = MakeTask("COMPLETE", q, pt, wp, v)
                end
            end
        end
    end
    -- annehmbare Quests
    for ci, id in ipairs(candidates) do
        if ci % 25 == 0 then LP:Yield("plan") end
        if not inLog[id] then
            local q = LP.QuestDB:Get(id)
            if q and self:IsAvailable(q, level) then
                local pt, _, wp = NearestPoint(q.starts, inst, n, w)
                local value = LevelWeight(q.level, level)
                local d = q.dungeon and LP.QuestDB:Dungeon(q.dungeon)
                -- Sicherer Modus: Elite und deutlich hoehere Gegner meiden (Klassenquests bleiben, mit Warnung)
                if pt and not d and LP.db.safeMode then
                    local danger = q.elite or (q.mobLevel and q.mobLevel >= level + 3)
                    if danger and not self:IsProtected(id) then
                        self.safeSkip[id] = q.elite and L["Elite"] or (L["Gegner Stufe "] .. q.mobLevel)
                        pt = nil
                    end
                end
                if d then
                    -- erst kurz vor dem passenden Level und nur mit Platz im Log mitnehmen
                    if not self:DungeonUsable(q.dungeon) or level < d.min - 2 or level > d.max
                       or logCount >= maxLog - DUNGEON_LOG_FREE then
                        pt = nil
                    else
                        value = value * (level >= d.min - 1 and 1.2 or 0.6)
                    end
                end
                if pt then
                    local t = MakeTask("ACCEPT", q, pt, wp, value)
                    t.dungeon = q.dungeon
                    accepts[#accepts + 1] = { t = t, q = q }
                end
            end
        end
    end
    self:SpeedFilter(accepts, tasks, level, inst, n, w)
    self:DungeonTasks(dq, tasks, inst, n, w, level)
    for i = #tasks, 1, -1 do if tasks[i].drop then table.remove(tasks, i) end end
    -- Gruppe: Quests, die auch Mitspieler haben, gemeinsam erledigen
    local shared = LP.Group and LP.Group:SharedQuests()
    if shared then
        for _, t in ipairs(tasks) do
            local c = t.id and shared[t.id]
            if c then t.value = t.value * (1 + 0.3 * math.min(c, 3)) t.shared = c end
        end
    end
    return tasks
end

-- Speedrun: langsame Quests auslassen, schnelle bevorzugen (Klassenquests bleiben)
local CROSS_SECS = 900          -- anderer Kontinent: Weg zu Schiff/Zeppelin, Warten, Fahrt (Sekunden)
local RUN_YPS = 7               -- Yards pro Sekunde zu Fuss

function P:SpeedFilter(accepts, tasks, level, inst, n, w)
    wipe(self.speedSkip)
    if not self:IsSpeed() then
        for _, a in ipairs(accepts) do tasks[#tasks + 1] = a.t end
        return
    end
    for _, a in ipairs(accepts) do
        if not a.q.dungeon then
            a.eff = self:Efficiency(a.q, level)
            -- der Weg zum Questgeber zaehlt fuer die Reihenfolge, nicht fuers Auslassen
            -- (sonst faellt in einer Stadt fern der Questgeber jede Quest durch und es wird endlos gegrindet)
            if a.eff and inst then
                local secs = QuestSeconds(a.q)
                local travel = (a.t.inst == inst and a.t.n) and (LP.Geo:Dist(n, w, a.t.n, a.t.w) / RUN_YPS) or CROSS_SECS
                a.travelF = math.max(0.35, secs / (secs + travel * 0.5))
            end
        end
    end
    local med = GrindRate(level)
    local cut = SPEED_CUTOFF[LP.db.speedLevel or 3] or SPEED_CUTOFF[3]
    for _, a in ipairs(accepts) do
        local id = a.q.id
        local reason
        if not self:IsProtected(id) then
            reason = SpeedReason(a.q, level)
            if not reason and a.eff and a.eff < med * cut then reason = L["dauert zu lange"] end
        end
        if reason then
            self.speedSkip[id] = reason
        else
            if self:IsProtected(id) and IsClassQuest(a.q.classes) then a.t.value = a.t.value + 1 a.t.classQuest = true end
            if a.travelF then a.t.value = a.t.value * a.travelF end
            tasks[#tasks + 1] = a.t
        end
    end
end

-- Einen Dungeon-Lauf einplanen, wenn er sich jetzt lohnt.
-- Im passenden Level werden die Dungeon-Quests in Reichweite gezielt eingesammelt (auch ausserhalb
-- der Fokus-Zone), danach geht es in den Dungeon - so muss man nicht zweimal hin.
local SINGLE_RANGE = 1000        -- Yards: mit nur einer Quest nur, wenn man praktisch am Eingang ist
-- Zeit und Monster-EP eines Laufs
local DG_SEARCH, DG_RUN, DG_PER_QUEST = 900, 2700, 420   -- Gruppensuche, Lauf (Ersatzwert), je Quest (Sekunden)
local DG_KILLS = 60              -- Elite-Kills je Lauf (EP bereits auf 5 Spieler geteilt)
local DG_NEED = { normal = 0.55, speed = 0.9 } -- mindestens so viel EP/Minute wie x-mal Grinden

-- Monster-EP in Dungeons: auf WoW Forever ca. 70 % weniger als in Classic (einstellbar)
function P:DungeonXPFactor()
    local pct = tonumber(LP.db.dungeonMobXP)
    if pct and pct > 0 then return pct / 100 end
    return LP.API.Forever() and 0.3 or 1.0
end

-- Quest-EP von Dungeon-Quests: auf WoW Forever ca. 94-138 % mehr als in Classic (Planung vorsichtig x2)
function P:DungeonQuestFactor()
    local pct = tonumber(LP.db.dungeonQuestXP)
    if pct and pct > 0 then return pct / 100 end
    return LP.API.Forever() and 2.0 or 1.0
end

-- EP je Minute eines Dungeon-Laufs mit diesen Quests (Quest-EP + Monster-EP)
function P:DungeonRate(quests, level, area)
    local xp = 0
    local qf = self:DungeonQuestFactor()
    for _, q in ipairs(quests) do
        local _, measured = BaseXP(q)
        -- gemessene Forever-EP enthalten den Dungeon-Bonus schon
        xp = xp + (QuestXPFor(q, level) or (45 + 5 * level) * 10) * (measured and 1 or qf)   -- unbekannt: wie 10 Kills
    end
    xp = xp + (45 + 5 * level) * DG_KILLS * self:DungeonXPFactor()
    local d = area and LP.Dungeons[area]
    local secs = DG_SEARCH + (d and d.run and d.run * 60 or DG_RUN) + DG_PER_QUEST * #quests
    return xp / (secs / 60)
end
P.dungeonWorth = {}   -- [Dungeon] = Text fuer Anzeige/Diagnose
P.dungeonDead = {}    -- [questID] = true: Dungeon-Quest im Log, deren Lauf sich nicht lohnt

function P:DungeonTasks(dq, tasks, inst, n, w, level)
    local minQuests = LP.db.dungeonMin or 2
    if self:IsSpeed() then minQuests = math.max(minQuests, SPEED_DUNGEON_MIN) end
    local need = GrindRate(level) * (self:IsSpeed() and DG_NEED.speed or DG_NEED.normal)
    local worthArea = {}
    wipe(self.dungeonWorth)
    wipe(self.dungeonDead)
    local avail = {}
    for _, t in ipairs(tasks) do
        if t.t == "ACCEPT" and t.dungeon and t.inst == inst then
            avail[t.dungeon] = avail[t.dungeon] or {}
            table.insert(avail[t.dungeon], t)
        end
    end
    local areas = {}
    for a in pairs(dq) do areas[a] = true end
    for a in pairs(avail) do areas[a] = true end
    for area in pairs(areas) do
        local list, acc = dq[area] or {}, avail[area] or {}
        local d = LP.QuestDB:Dungeon(area)
        local last = LP.char.dungeonRun[area]
        if d and not (last and level < last + DUNGEON_RETRY) then
            local sum, cnt, value = 0, 0, 0
            local names = {}
            for _, q in ipairs(list) do
                if q.level and q.level > 0 then sum = sum + q.level cnt = cnt + 1 end
                value = value + 1.5 * LevelWeight(q.level, level) + 0.5
                names[#names + 1] = q.name
            end
            for _, t in ipairs(acc) do
                if t.level and t.level > 0 then sum = sum + t.level cnt = cnt + 1 end
            end
            local avg = cnt > 0 and sum / cnt or d.min
            -- Eingang: der naechste auf diesem Kontinent
            local pt, dist, wp = NearestPoint(d.e, inst, n, w)
            local ready = level >= math.max(d.min, Round(avg) - 3)
            -- lohnt sich der Lauf ueberhaupt? (alle Quests, die man bis dahin haben kann)
            -- gezaehlt werden nur Quests, die man wirklich zusammen haben kann: im Log + jetzt annehmbar in der Naehe
            local all, near = {}, {}
            for _, q in ipairs(list) do all[#all + 1] = q end
            for _, t in ipairs(acc) do
                if LP.Geo:Dist(n, w, t.n, t.w) < PREP_RANGE then
                    near[#near + 1] = t
                    local aq = LP.QuestDB:Get(t.id)
                    if aq then all[#all + 1] = aq end
                end
            end
            local rate = self:DungeonRate(all, level, area)
            local worth = rate >= need
            if worth then worthArea[area] = true end
            self.dungeonWorth[area] = string.format(L["%s: %d EP/Min (nötig %d)%s"], d.name, rate, need, worth and "" or L[" – lohnt nicht"])
            if not worth then
                -- Lauf lohnt nicht: Quests dafuer gar nicht erst annehmen (blockieren sonst den Questlog)
                for _, t in ipairs(acc) do t.drop = true end
                for _, q in ipairs(list) do self.dungeonDead[q.id] = true end
            end
            if pt and ready and worth then
                if #all >= minQuests then
                    for _, t in ipairs(near) do t.prep = true t.value = t.value + 1 end
                end
                local single = #list >= 1 and #near == 0 and dist and dist < SINGLE_RANGE
                -- laufen, sobald alles Erreichbare eingesammelt ist (oder die Quests im Log schon reichen)
                local collected = #near == 0 or self:DungeonRate(list, level, area) >= need
                if (#list >= minQuests or single) and collected then
                    local urgent = level >= Round(avg) + 2
                    value = value * 1.4 + 2 * self:DungeonXPFactor()   -- Monster-EP im Dungeon
                    if LP.QuestDB:DungeonHostile(area) then value = value * 0.6 end
                    if urgent then value = value * 1.5 end
                    tasks[#tasks + 1] = {
                        t = "DUNGEON", area = area, q = d.name, level = Round(avg), quests = names,
                        map = pt[1], x = pt[2], y = pt[3], inst = wp[1], n = wp[2], w = wp[3],
                        value = value, urgent = urgent, hostile = LP.QuestDB:DungeonHostile(area),
                        min = d.min, max = d.max, key = "DG:" .. area,
                    }
                end
            end
        end
    end
    -- Dungeon-Quests nur annehmen, wenn ihr Lauf sich gerade nachweislich lohnt
    for _, t in ipairs(tasks) do
        if t.t == "ACCEPT" and t.dungeon and not worthArea[t.dungeon] then t.drop = true end
    end
end

------------------------------------------------------------------------
-- 4) Fokus-Zone
------------------------------------------------------------------------

local OTHER_CONTINENT = 12000   -- Reisekosten (Yards) fuer einen Kontinentwechsel
local TRAVEL_SCALE = 900        -- je so viele Yards halbiert sich der Wert einer Zone
local DRAIN = 2.5               -- Restwert, ab dem eine Zone als "abgearbeitet" gilt
local SWITCH_NEAR = 500       -- Yards: alte Fokus-Zone gilt als verlassen
local CROSS_MIN_TASKS = 5     -- so viele Aufgaben braucht eine Zone auf einem anderen Kontinent
local CROSS_MIN_LEVEL = 12    -- darunter kein Kontinentwechsel fuer neue Fokus-Zonen

function P:ChooseFocus(tasks, inst, n, w, curZone)
    if LP.char.focusZone then return LP.char.focusZone end
    -- Dungeon, dessen Quests bald grau werden: jetzt hin
    for _, t in ipairs(tasks) do
        if t.t == "DUNGEON" and t.urgent and t.inst == inst then return t.map end
    end
    local zones = {}
    for _, t in ipairs(tasks) do
        if t.map and t.inst then
            local z = zones[t.map]
            if not z then
                z = { value = 0, cnt = 0, inst = t.inst, near = nil }
                zones[t.map] = z
            end
            z.value = z.value + t.value
            z.cnt = z.cnt + 1
            local d = (t.inst == inst) and LP.Geo:Dist(n, w, t.n, t.w) or OTHER_CONTINENT
            if not z.near or d < z.near then z.near = d end
        end
    end
    -- 1) Bisherige Fokus-Zone erst fertig machen
    --    (ausser der Spieler ist sichtbar in eine andere lohnende Zone gewechselt)
    local cur = self.focus and zones[self.focus]
    local here = zones[curZone]
    local moved = here and curZone ~= self.focus and here.value >= DRAIN
                  and cur and cur.near > SWITCH_NEAR
    if cur and cur.value >= DRAIN and not moved then return self.focus end
    -- 2) Zone, in der man steht, wenn es dort genug zu tun gibt
    if here and here.value >= DRAIN then return curZone end
    -- 3) Sonst die lohnendste Zone; einzelne Aufgaben rechtfertigen keine weite Reise
    --    Ein anderer Kontinent (Schiff/Zeppelin, 10-15 min) lohnt sich nur fuer ein ganzes Paket Quests,
    --    und nur, wenn auf diesem Kontinent kaum noch etwas zu tun ist
    local homeValue = 0
    for _, z in pairs(zones) do if z.inst == inst and z.value > homeValue then homeValue = z.value end end
    local lowLevel = (LP:PlayerLevel() or 1) < CROSS_MIN_LEVEL   -- Startgebiete: auf dem eigenen Kontinent bleiben
    local best, bestScore
    for map, z in pairs(zones) do
        local sc = z.value / (1 + z.near / TRAVEL_SCALE)
        if z.cnt < 3 and z.near > 1500 then sc = sc * 0.4 end
        if z.inst ~= inst and (z.cnt < CROSS_MIN_TASKS or z.value < homeValue * 2 or lowLevel) then sc = 0 end
        if sc > 0 and (not bestScore or sc > bestScore) then best, bestScore = map, sc end
    end
    return best
end

------------------------------------------------------------------------
-- 5) Reihenfolge
------------------------------------------------------------------------
local TYPE_BONUS = { ACCEPT = 0.6, TURNIN = 0.6, COMPLETE = 1.0, DUNGEON = 1.2 }

-- Erst annehmen, dann questen: Alle annehmbaren Quests in der Naehe des Spielers (GATHER) werden
-- eingesammelt, bevor ein Questziel drankommt. Kommt die Route spaeter an einen Questgeber, werden
-- alle Questgeber im Umkreis (HUB) gleich mit besucht. Abgaben an denselben Orten laufen mit (sie
-- schaffen Platz im Log und schalten Folgequests frei). Nie mehr Quests, als ins Log passen.
local GATHER = 400            -- Yards um den Spieler
local HUB = 250               -- Yards um einen Questgeber
P.GATHER, P.HUB = GATHER, HUB

function P:Order(tasks, inst, n, w)
    local out, used = {}, {}
    local cn, cw = n, w
    local logCount = 0
    for _ in pairs(inLog) do logCount = logCount + 1 end
    local free = LP.API.MaxQuests() - logCount
    local anchorN, anchorW, anchorR = n, w, GATHER      -- Sammelpunkt: zuerst der Spieler selbst
    local function inHub(t)
        return t.inst == inst and (t.t == "ACCEPT" or t.t == "TURNIN") and t.n
               and LP.Geo:Dist(anchorN, anchorW, t.n, t.w) <= anchorR
    end
    for _ = 1, math.min(#tasks, MAX_STEPS) do
        LP:Yield("plan")
        -- gibt es am Sammelpunkt noch etwas anzunehmen (und Platz im Log)? Dann nur das (+ Abgaben dort)
        local gather = false
        if anchorN and free > 0 then
            for i, t in ipairs(tasks) do
                if not used[i] and t.t == "ACCEPT" and inHub(t) then gather = true break end
            end
        end
        if not gather then anchorN = nil end
        local best, bestC
        for i, t in ipairs(tasks) do
            if not used[i] and (not gather or inHub(t)) then
                local c
                if t.inst == inst then
                    c = LP.Geo:Dist(cn, cw, t.n, t.w) * (TYPE_BONUS[t.t] or 1)
                elseif not t.inst then
                    c = 5000   -- Ort unbekannt: ans Ende
                else
                    c = 30000  -- anderer Kontinent: nur, wenn hier wirklich nichts Lohnendes mehr ist
                end
                c = c / (0.6 + 0.4 * math.min(t.value or 1, 1.5))
                -- Log voll: Annahmen erst, wenn wieder Platz ist (nach Abgaben)
                if t.t == "ACCEPT" and free <= 0 then c = c * 50 + 50000 end
                if not bestC or c < bestC then best, bestC = i, c end
            end
        end
        if not best then break end
        used[best] = true
        local t = tasks[best]
        out[#out + 1] = t
        if t.inst == inst then cn, cw = t.n, t.w end
        if t.t == "ACCEPT" then
            free = free - 1
            -- an einem Questgeber angekommen: dessen Umgebung mit einsammeln
            if not anchorN and t.inst == inst and t.n then anchorN, anchorW, anchorR = t.n, t.w, HUB end
        elseif t.t == "TURNIN" then
            free = free + 1
        end
    end
    return out
end

------------------------------------------------------------------------
-- Reise: Flugpunkte
------------------------------------------------------------------------
local function NearestTaxi(inst, n, w, maxD)
    local best, bestD
    for key in pairs(LP.char.taxiKnown) do
        local tx = LP.db.taxi[key] or (LP.Seed.taxi and LP.Seed.taxi[key])
        local _, _, _, i, tn, tw = LP.Geo:TaxiPoint(tx)
        if i then
            if i == inst then
                local d = LP.Geo:Dist(n, w, tn, tw)
                if d <= maxD and (not bestD or d < bestD) then best, bestD = tx, d end
            end
        end
    end
    return best, bestD
end

-- Unbekannter Flugmeister der eigenen Fraktion in der Naehe -> Flugpunkt mitnehmen
local FP_RANGE = 1000
function P:FlightPointTask(inst, n, w, curZone)
    local best, bestD
    for _, v in ipairs(LP.QuestDB:ServiceNPCs().flight or {}) do
        local key = (v.name or "?") .. ":" .. v.map
        if v.map == curZone and not LP.char.fpVisited[key] and not LP.char.doneKeys["FP:" .. key] then
            local i, vn, vw = LP.Geo:ToWorld(v.map, v.x, v.y)
            if i == inst then
                local d = LP.Geo:Dist(n, w, vn, vw)
                if d <= FP_RANGE and (not bestD or d < bestD) then best, bestD = v, d end
            end
        end
    end
    if not best then return nil end
    local i, vn, vw = LP.Geo:ToWorld(best.map, best.x, best.y)
    return { t = "FP", map = best.map, x = best.x, y = best.y, inst = i, n = vn, w = vw, npc = best.name,
             text = L["holen bei "] .. (best.name or L["Flugmeister"]), key = "FP:" .. (best.name or "?") .. ":" .. best.map }
end

------------------------------------------------------------------------
-- Ruhestein: benutzen, wenn das Ziel nahe am Bindeort und weit weg ist; binden in neuen Hauptzonen
------------------------------------------------------------------------
local HEARTH_MIN = 1500       -- Yards: kuerzere Wege laeuft man
local HEARTH_GAIN = 0.4       -- Bindeort muss deutlich naeher am Ziel liegen
local BIND_NEAR = 250         -- Yards: Gastwirt in der Naehe
local BIND_TASKS = 6          -- so viele Aufgaben in der Zone, damit sich das Binden lohnt

function P:HearthStep(target, inst, n, w)
    if not LP.db.useHearth or not target or not target.inst then return nil end
    local b = LP.char.bind
    if type(b) ~= "table" or not b.map or not LP.API.HearthReady() then return nil end
    local bi, bn, bw = LP.Geo:ToWorld(b.map, b.x, b.y)
    if not bi or bi ~= target.inst then return nil end
    if inst == bi and LP.Geo:Dist(n, w, bn, bw) < 300 then return nil end
    local dTarget = (target.inst == inst) and LP.Geo:Dist(n, w, target.n, target.w) or OTHER_CONTINENT
    local dBind = LP.Geo:Dist(bn, bw, target.n, target.w)
    if dTarget < HEARTH_MIN or dBind > dTarget * HEARTH_GAIN then return nil end
    return { t = "HEARTH", text = b.name or "?", map = b.map, x = b.x, y = b.y, inst = bi, n = bn, w = bw,
             noNav = true, item = LP.API.HEARTHSTONE, key = "HEARTH:" .. (target.key or "?") }
end

function P:BindStep(selected, inst, n, w, focus)
    if not LP.db.useHearth or not focus then return nil end
    local b = LP.char.bind
    if type(b) == "table" and b.map == focus then return nil end
    local cnt = 0
    for _, t in ipairs(selected) do if t.map == focus then cnt = cnt + 1 end end
    if cnt < BIND_TASKS then return nil end
    local v, d = LP.QuestDB:NearestService("inn", function(x) return x.map == focus end)
    if not v or not d or d > BIND_NEAR then return nil end
    local vi, vn, vw = LP.Geo:ToWorld(v.map, v.x, v.y)
    return { t = "BIND", npc = v.name, text = LP.Geo:MapName(focus), map = v.map, x = v.x, y = v.y,
             inst = vi, n = vn, w = vw, key = "BIND:" .. focus }
end

function P:TravelSteps(target, inst, n, w)
    if not target or not target.inst then return {} end
    local steps = {}
    if target.inst ~= inst then return steps end          -- Kontinentwechsel: Schiff/Zeppelin ueber das Wegenetz
    local direct = LP.Geo:Dist(n, w, target.n, target.w)
    if direct < 2000 then return steps end
    local fromFP, d1 = NearestTaxi(inst, n, w, 2500)
    local toFP, d2 = NearestTaxi(target.inst, target.n, target.w, 3000)
    -- nur fliegen, wenn Fussweg zum und vom Flugmeister deutlich kuerzer ist als der ganze Weg
    if fromFP and toFP and fromFP ~= toFP and (d1 + d2) * 1.25 + 300 < direct then
        local fm, fx, fy, fi, fn, fw = LP.Geo:TaxiPoint(fromFP)
        if d1 > 30 then
            steps[#steps + 1] = {
                t = "GOTO", map = fm, x = fx, y = fy, inst = fi, n = fn, w = fw,
                text = L["Zum Flugmeister: "] .. (fromFP.name or "?"), key = "FPGO:" .. (fromFP.name or ""),
            }
        end
        steps[#steps + 1] = {
            t = "FLY", text = toFP.name or "?", map = fm, x = fx, y = fy,
            inst = fi, n = fn, w = fw, key = "FLY:" .. (toFP.name or ""),
        }
    end
    return steps
end

------------------------------------------------------------------------
-- Planung
------------------------------------------------------------------------
-- Zustand fuer Anzeige und Diagnose: "ok", "nodata", "noquests", "noposition", "error"
P.state = "start"
P.diag = {}

function P:Replan(verbose)
    if not LP.db then return end
    -- waehrend der virtuellen Reise plant nur die Reise selbst (Ereignisse des Spiels warten)
    if LP.Virtual and LP.Virtual.active and coroutine.running() ~= LP.yieldCo then return end
    local ok, err = pcall(self.DoReplan, self, verbose)
    if not ok then
        self.state = "error"
        self.status = L["Fehler bei der Planung"]
        LP:Error(L["Routenplanung"], err)
        LP:Fire("PLAN_CHANGED")
    end
end

function P:DoReplan(verbose)
    local level = LP:PlayerLevel() or 1
    if level ~= candLevel then self:BuildCandidates() end
    ScanLog()
    self.diag.candidates = #candidates
    self.diag.level = level

    if LP.Engine and LP.Engine:InDungeon() then
        self:PlanInstance(level)
        return
    end

    local inst, n, w, curZone = LP.Geo:Player()
    self.diag.map = C_Map.GetBestMapForUnit("player")
    if not inst then
        self.state = "noposition"
        self.status = L["Position unbekannt"]
        self.diag.tasks = 0
        if #self.steps == 0 or self.steps[1].key == "NOPOS" then
            self.steps = { { t = "NOTE", key = "NOPOS",
                text = L["Deine Position ist gerade nicht bestimmbar (z. B. in einer Instanz oder beim Laden). Kurz bewegen – die Route wird dann automatisch geplant."] } }
        end
        LP:Fire("PLAN_CHANGED")
        return
    end

    local tasks = self:CollectTasks(inst, n, w, level)
    self.diag.tasks = #tasks
    self.lastTasks = tasks
    local focus = self:ChooseFocus(tasks, inst, n, w, curZone)
    self.focus = focus

    -- Aufgaben der Fokus-Zone + alles in der Naehe (300 Yards, Questannahmen 400) + fertige Quests ueberall
    -- + Dungeon-Quests, die fuer einen anstehenden Lauf eingesammelt werden
    local selected = {}
    for _, t in ipairs(tasks) do
        local near = t.inst == inst and t.n and LP.Geo:Dist(n, w, t.n, t.w) < (t.t == "ACCEPT" and GATHER or 300)
        if t.map == focus or near or t.prep or (t.t == "TURNIN" and t.map == curZone) or not t.map then
            selected[#selected + 1] = t
        end
    end

    local ordered = self:Order(selected, inst, n, w)
    -- Dungeon-Quests in der Naehe zuerst einsammeln, dann in den Dungeon
    for i = #ordered, 1, -1 do
        local dg = ordered[i]
        if dg.t == "DUNGEON" then
            local lastAccept
            for j = i + 1, #ordered do
                if ordered[j].t == "ACCEPT" and ordered[j].dungeon == dg.area then lastAccept = j end
            end
            if lastAccept then
                table.remove(ordered, i)
                table.insert(ordered, lastAccept, dg)
            end
        end
    end
    local steps = {}
    local fp = self:FlightPointTask(inst, n, w, curZone)
    if fp then steps[#steps + 1] = fp end
    local bind = self:BindStep(selected, inst, n, w, focus)
    if bind then steps[#steps + 1] = bind end
    local hearth = ordered[1] and self:HearthStep(ordered[1], inst, n, w)
    if hearth then
        steps[#steps + 1] = hearth
    elseif ordered[1] and ordered[1].inst then
        for _, s in ipairs(self:TravelSteps(ordered[1], inst, n, w)) do steps[#steps + 1] = s end
    end
    for _, t in ipairs(ordered) do steps[#steps + 1] = t end

    self.state = "ok"
    if #steps == 0 then
        if LP.QuestDB:Counts().total == 0 then
            self.state = "nodata"
            steps[1] = { t = "NOTE", key = "NODATA",
                text = L["Noch keine Questdaten vorhanden.\nInstalliere das Datenpaket \"LevelPilot Data\" (Ordner LevelPilot_Data in Interface\\AddOns) für alle Classic-Quests – oder nimm Quests an: LevelPilot lernt jede Quest."] }
        else
            self.state = "noquests"
            steps[1] = { t = "LEVEL", lvl = level + 1, key = "GRIND:" .. level,
                text = L["Keine passende Quest in der Nähe bekannt – Monster in deinem Level besiegen oder eine andere Zone wählen (Zentrale » Route)"] }
        end
    end

    -- Vorrang-Ziel des Assistenten (z.B. "Reparieren") an den Anfang
    if self.priority then
        if LP.char.doneKeys[self.priority.key] then
            LP.char.doneKeys[self.priority.key] = nil
            self.priority = nil
        else
            table.insert(steps, 1, self.priority)
        end
    end

    -- manuell erledigte Reise-/Hinweisschritte ausblenden
    local final = {}
    for _, s in ipairs(steps) do
        if not LP.char.doneKeys[s.key] then final[#final + 1] = s end
    end
    -- nie ohne Schritt dastehen
    if #final == 0 then
        self.state = "noquests"
        final[1] = { t = "LEVEL", lvl = level + 1, key = "GRIND:" .. level,
            text = L["Keine passende Quest in der Nähe bekannt – Monster in deinem Level besiegen oder eine andere Zone wählen (Zentrale » Route)"] }
    end
    if final[1].t == "LEVEL" and self:IsSpeed() and next(self.speedSkip) then
        final[1].text = L["Speedrun: Monster in deinem Level besiegen ist gerade schneller als die übrigen Quests hier. Ab dem nächsten Level geht es mit Quests weiter."]
    end
    self.steps = final
    self.status = focus and LP.Geo:MapName(focus) or ""
    if verbose then
        LP:Print(L["Route neu geplant: "] .. #final .. L[" Schritte"] .. (focus and (" in " .. LP.Geo:MapName(focus)) or ""))
    end
    LP:Fire("PLAN_CHANGED")
end

-- Uebersicht fuer die Zentrale: je Dungeon Zugang, Stufen, Quests (offen / im Log / erledigt), Rechnung
function P:DungeonOverview()
    local level = LP:PlayerLevel() or 1
    ScanLog()
    local byArea = {}
    for _, id in ipairs(LP.QuestDB:AllIds()) do
        local info = LP.QuestDB:QuickInfo(id)
        local area = info and info.dungeon
        if area then
            local q = LP.QuestDB:Get(id)
            if q and LP.QuestDB:FitsPlayer(q) and not q.repeatable then
                local e = byArea[area] or { open = 0, log = 0, done = 0 }
                byArea[area] = e
                if Done(id) then e.done = e.done + 1
                elseif inLog[id] then e.log = e.log + 1
                else e.open = e.open + 1 end
            end
        end
    end
    local out = {}
    for area, d in pairs(LP.Dungeons) do
        local info = LP.QuestDB:Dungeon(area)
        local allowed, why = LP.QuestDB:DungeonAllowed(area)
        local e = byArea[area] or { open = 0, log = 0, done = 0 }
        out[#out + 1] = { area = area, name = info and info.name or d.name, min = d.min, max = d.max, allowed = allowed, why = why,
                          hostile = LP.QuestDB:DungeonHostile(area), open = e.open, log = e.log, done = e.done,
                          worth = self.dungeonWorth[area], entrance = info and info.e and info.e[1],
                          now = level >= d.min - 2 and level <= d.max, last = LP.char.dungeonRun[area] }
    end
    table.sort(out, function(a, b) if a.min ~= b.min then return a.min < b.min end return a.name < b.name end)
    return out
end

-- Im Dungeon: die Ziele der Quests dieser Instanz
function P:PlanInstance(level)
    local area = LP.Engine:InDungeon()
    local d = LP.QuestDB:Dungeon(area)
    local steps = {}
    local name = d and d.name or (GetInstanceInfo and GetInstanceInfo()) or L["Dungeon"]
    for id, st in pairs(inLog) do
        if not st.complete and not st.failed then
            local q = LP.QuestDB:Get(id)
            local mine = q and q.dungeon == area
            if not mine and (not q or not q.dungeon) then
                -- unbekannte Zuordnung: Quests ohne Ziel in der Welt gehoeren wahrscheinlich hierher
                local world = false
                for _, o in ipairs(q and q.objectives or {}) do
                    local list = area and area ~= 0 and OutsideSpots(area, o.spots or {}) or (o.spots or {})
                    for _, sp in ipairs(list) do if WorldOf(sp) then world = true break end end
                end
                mine = not world
            end
            if mine then
                steps[#steps + 1] = { t = "COMPLETE", id = id, q = st.title or (q and q.name), level = q and q.level,
                                      key = "COMPLETE:" .. id, value = 1 }
            end
        end
    end
    table.sort(steps, function(a, b) return (a.level or 0) < (b.level or 0) end)
    if #steps == 0 then
        steps[1] = { t = "NOTE", key = "DGDONE",
            text = L["Alle Quests für diesen Dungeon erledigt.\nNach dem Verlassen der Instanz geht es mit den Abgaben weiter."] }
    end
    table.insert(steps, 1, { t = "DUNGEON", inside = true, area = area, q = name, key = "DGIN",
                             min = d and d.min, max = d and d.max })
    self.state = "instance"
    self.focus = nil
    self.status = name
    self.diag.tasks = #steps - 1
    self.steps = steps
    LP:Fire("PLAN_CHANGED")
end

-- Diagnose im Chat
function P:DiagLines()
    local c = LP.QuestDB:Counts()
    local inst, n, w, map, x, y = LP.Geo:Player()
    local d = self.diag
    local lines = {
        L["Version "] .. LP.version .. L[" · Client: "] .. (LP.API.modern and L["modern"] or L["Classic"]) .. L[" · Server: "] .. (LP.API.Forever() and L["WoW Forever"] or L["Classic"]),
        L["Zustand: "] .. tostring(self.state) .. L[" · Fokus: "] .. (self.focus and LP.Geo:MapName(self.focus) or "–"),
        L["Position: "] .. (map and string.format("%s (%d) %.1f, %.1f", LP.Geo:MapName(map), map, x, y) or (L["unbekannt, Karte "] .. tostring(C_Map.GetBestMapForUnit("player")))),
        L["Datenpaket: "] .. (LP.QuestDB.pack and "|cff4ddb80" or "|cffff8c33") .. LP.QuestDB.packInfo .. "|r",
        L["QuestieDB: "] .. LP.QuestDB.questieInfo,
        string.format(L["Quests: Paket %d, Questie %d, Startdatenbank %d, eigene %d, andere %d"], c.pack, c.questie, c.seed, c.own, c.net),
        string.format(L["Level %s · passende Quests %s · Aufgaben %s · Schritte %d"], tostring(d.level), tostring(d.candidates), tostring(d.tasks), #self.steps),
        L["Questlog: "] .. LP.API.QuestCount() .. "/" .. LP.API.MaxQuests() .. ((tonumber(LP.db.questLogMax) or 0) > 0 and L[" (fest eingestellt)"] or L[" (automatisch)"]),
        L["Modus: "] .. (self:IsSpeed() and (L["Speedrun "] .. (SPEED_NAMES[LP.db.speedLevel or 3] or "") .. " (" .. (function() local c = 0 for _ in pairs(self.speedSkip) do c = c + 1 end return c end)() .. L[" Quests ausgelassen)"]) or L["Normal"]),
        L["Dungeons: "] .. (LP.db.dungeons == false and "aus" or (L["an, Lauf ab "] .. (LP.db.dungeonMin or 2) .. L[" Quests, Monster-EP "]
            .. math.floor(self:DungeonXPFactor() * 100 + 0.5) .. L[" %, Quest-EP "] .. math.floor(self:DungeonQuestFactor() * 100 + 0.5) .. " %"))
            .. (LP.char.inDungeon and (L[" · im Dungeon "] .. tostring(LP.char.inDungeon)) or ""),
        L("Höhlen und Tunnel bekannt: %d (selbst gelernt %d, von anderen %d)", LP.Caves:Count()),
        L["Geländeführung: "] .. (not LP.db.terrainPath and L["aus"] or (LP.Terrain:Available(map) and L["an (Geländekarte dieser Zone vorhanden)"] or L["keine Geländekarte für diese Zone"])),
        L["Sprachpakete: "] .. (LP.Names and LP.Names:StatusText() or "–"),
        L["Letzter Fehler: "] .. (LP.lastError or L["keiner"]),
    }
    for _, txt in pairs(self.dungeonWorth) do table.insert(lines, #lines, "   " .. txt) end
    return lines
end

function P:Diagnose()
    local lines = self:DiagLines()
    LP:Print(L["|cffffb238Diagnose|r"])
    for _, l in ipairs(lines) do DEFAULT_CHAT_FRAME:AddMessage("   " .. l) end
end

-- Zonen mit Aufgaben (fuer die Zentrale)
function P:ZoneSummary()
    local inst, n, w = LP.Geo:Player()
    if not inst then return {} end
    ScanLog()
    local level = LP:PlayerLevel() or 1
    if level ~= candLevel then self:BuildCandidates() end
    local tasks = self:CollectTasks(inst, n, w, level)
    local zones = {}
    for _, t in ipairs(tasks) do
        if t.map then
            local z = zones[t.map] or { map = t.map, accept = 0, active = 0 }
            zones[t.map] = z
            if t.t == "ACCEPT" then z.accept = z.accept + 1 else z.active = z.active + 1 end
        end
    end
    local list = {}
    for _, z in pairs(zones) do list[#list + 1] = z end
    table.sort(list, function(a, b) return (a.accept + a.active) > (b.accept + b.active) end)
    return list
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
function P:Init()
    local function soon() LP:Throttle("replan", 1.5, function() P:Replan() end) end
    LP:On("QUEST_LOG_UPDATE", soon)
    LP:On("QUEST_TURNED_IN", function(_, id)
        if id then LP.char.turnedIn[id] = true end
        soon()
    end)
    LP:On("PLAYER_LEVEL_UP", function() C_Timer.After(0.5, function() P:BuildCandidates() P:Replan() end) end)
    LP:On("ZONE_CHANGED_NEW_AREA", soon)
    LP:Listen("QDB_CHANGED", function() candLevel = -1 soon() end)
    LP:Listen("QUEST_RECORDED", function(_, isNew) if isNew then candLevel = -1 end soon() end)
    LP:On("PLAYER_ENTERING_WORLD", function() C_Timer.After(2, function() P:Replan() end) end)
    C_Timer.After(1, function() P:Replan() end)
    C_Timer.NewTicker(15, function() P:Replan() end)
end
