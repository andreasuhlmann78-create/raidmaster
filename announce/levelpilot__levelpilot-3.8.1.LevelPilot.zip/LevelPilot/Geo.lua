-- LevelPilot - Geo
-- Umrechnung Karten- <-> Weltkoordinaten, Spielerposition, Zonen.
-- Weltkoordinaten: n = Nord-Achse, w = West-Achse (Yards), inst = Kontinent/Instanz.

local _, LP = ...
local L = LP.L
local Geo = {}
LP:RegisterModule("Geo", Geo)

local boundsCache, contCache, nameCache = {}, {}, {}

local function WorldVec(map, x, y)
    local inst, pos = C_Map.GetWorldPosFromMapPos(map, CreateVector2D(x, y))
    if not pos then return nil end
    local n, w = pos:GetXY()
    return inst, n, w
end

-- Grenzen einer Karte in Weltkoordinaten
function Geo:Bounds(map)
    if not map then return nil end
    local b = boundsCache[map]
    if b ~= nil then return b or nil end
    local inst, top, left = WorldVec(map, 0, 0)
    local _, bottom, right = WorldVec(map, 1, 1)
    if not inst or not bottom or top == bottom or left == right then
        boundsCache[map] = false
        return nil
    end
    b = { inst = inst, top = top, left = left, bottom = bottom, right = right }
    boundsCache[map] = b
    return b
end

-- Kartenkoordinaten (0-100) -> Welt
function Geo:ToWorld(map, x, y)
    local b = self:Bounds(map)
    if not b or not x or not y then return nil end
    local n = b.top + (b.bottom - b.top) * (y / 100)
    local w = b.left + (b.right - b.left) * (x / 100)
    return b.inst, n, w
end

-- Welt -> Kartenkoordinaten (0-100) auf einer bestimmten Karte
function Geo:ToMap(map, inst, n, w)
    local b = self:Bounds(map)
    if not b or b.inst ~= inst then return nil end
    local x = (w - b.left) / (b.right - b.left) * 100
    local y = (n - b.top) / (b.bottom - b.top) * 100
    return x, y
end

function Geo:Dist(n1, w1, n2, w2)
    local dn, dw = n2 - n1, w2 - w1
    return math.sqrt(dn * dn + dw * dw)
end

function Geo:ContinentOf(map)
    if not map then return nil end
    local c = contCache[map]
    if c ~= nil then return c or nil end
    local info = C_Map.GetMapInfo(map)
    local guard = 0
    while info and info.mapType and info.mapType > Enum.UIMapType.Continent
          and info.parentMapID and info.parentMapID > 0 and guard < 10 do
        info = C_Map.GetMapInfo(info.parentMapID)
        guard = guard + 1
    end
    c = (info and info.mapType == Enum.UIMapType.Continent) and info.mapID or false
    contCache[map] = c
    return c or nil
end

function Geo:MapName(map)
    if not map then return "?" end
    local n = nameCache[map]
    if n then return n end
    n = LP.Names and LP.Names:Zone(map)            -- andere Sprache als das Spiel: Sprachpaket
    if not n then
        local info = C_Map.GetMapInfo(map)
        n = info and info.name or (L["Karte "] .. map)
    end
    nameCache[map] = n
    return n
end

function Geo:ResetNames() wipe(nameCache) end

------------------------------------------------------------------------
-- Spielerposition (pro Bildaufbau zwischengespeichert)
------------------------------------------------------------------------
local cache = { t = -1 }

function Geo:Player()
    local now = GetTime()
    if cache.t == now then return cache.inst, cache.n, cache.w, cache.map, cache.x, cache.y end
    cache.t = now
    cache.inst, cache.n, cache.w, cache.map, cache.x, cache.y = nil, nil, nil, nil, nil, nil
    local map = C_Map.GetBestMapForUnit("player")
    if not map then return nil end
    local inst, n, w, x, y
    -- 1) Kartenposition
    local pos = C_Map.GetPlayerMapPosition(map, "player")
    if pos then
        x, y = pos:GetXY()
        if x and not (x == 0 and y == 0) then
            x, y = x * 100, y * 100
            inst, n, w = self:ToWorld(map, x, y)
        end
    end
    -- 2) Weltposition direkt (falls die Kartenfunktion nichts liefert)
    if not inst and UnitPosition then
        local un, uw, _, uinst = UnitPosition("player")
        if un and uw and uinst then
            local b = self:Bounds(map)
            if b and b.inst == uinst then
                inst, n, w = uinst, un, uw
                x, y = self:ToMap(map, inst, n, w)
            end
        end
    end
    if not inst or not x then return nil end
    cache.inst, cache.n, cache.w, cache.map, cache.x, cache.y = inst, n, w, map, x, y
    return inst, n, w, map, x, y
end

-- Entfernung Spieler -> Punkt auf Karte
function Geo:DistToMapPoint(map, x, y)
    local pi, pn, pw = self:Player()
    local ti, tn, tw = self:ToWorld(map, x, y)
    if not pi or not ti or pi ~= ti then return nil end
    return self:Dist(pn, pw, tn, tw)
end

-- Richtung (Bogenmass, ab Norden gegen den Uhrzeigersinn) vom Spieler zu einem Weltpunkt
function Geo:Bearing(n, w)
    local _, pn, pw = self:Player()
    if not pn then return nil end
    return math.atan2(w - pw, n - pn)
end

------------------------------------------------------------------------
-- Flugpunkte: Position eines aufgezeichneten Knotens
-- Die Knoten werden in Koordinaten der Flugkarte gespeichert (z. B. Karte 1464). Nicht jede Flugkarte
-- laesst sich vom Spiel in Weltkoordinaten umrechnen. Dann eicht LevelPilot die Flugkarte selbst:
-- Zonenname im Knotennamen ("Crossroads, Brachland") + Flugmeister aus dem Datenpaket ergeben Eichpunkte,
-- daraus Verschiebung und Massstab der Karte. Jeder Knoten bekommt so die Zonenposition seines Flugmeisters
-- (tx.zmap, tx.zx, tx.zy). Der Knoten, an dem man beim Oeffnen der Flugkarte steht, ist ein exakter Eichpunkt.
------------------------------------------------------------------------
local TAXI_MATCH = 150      -- Yards: so nah muss ein Flugmeister an der berechneten Stelle stehen
local taxiTried = {}        -- [Flugkarte] = true (diese Sitzung schon geeicht)

local function Fit(a, b)
    local n, sa, sb, saa, sab = #a, 0, 0, 0, 0
    for i = 1, n do sa, sb, saa, sab = sa + a[i], sb + b[i], saa + a[i] * a[i], sab + a[i] * b[i] end
    local den = n * saa - sa * sa
    if n < 2 or math.abs(den) < 1e-6 then return nil end
    local k = (n * sab - sa * sb) / den
    return (sb - k * sa) / n, k
end

-- Flugmeister der eigenen Fraktion mit Weltposition
local function FlightMasters()
    local out = {}
    local list = LP.QuestDB and LP.QuestDB.ServiceNPCs and LP.QuestDB:ServiceNPCs().flight or {}
    for _, v in ipairs(list) do
        local i, n, w = Geo:ToWorld(v.map, v.x, v.y)
        if i then out[#out + 1] = { v = v, inst = i, n = n, w = w } end
    end
    return out
end

-- Teile des Knotennamens, die eine Zone oder Stadt nennen ("Orgrimmar, Durotar" -> Orgrimmar, Durotar)
local function NameParts(name)
    local parts = {}
    for p in tostring(name or ""):gmatch("[^,]+") do parts[#parts + 1] = (p:gsub("^%s+", ""):gsub("%s+$", "")) end
    return parts
end

function Geo:CalibrateTaxi(map)
    if not map or taxiTried[map] then return end
    taxiTried[map] = true
    local db = (LP.Virtual and LP.Virtual.RealTaxi and LP.Virtual:RealTaxi()) or (LP.db and LP.db.taxi)
    if not db then taxiTried[map] = nil return end
    local fms = FlightMasters()
    if #fms == 0 then taxiTried[map] = nil return end   -- Datenpaket noch nicht bereit: spaeter nochmal
    -- Eichpunkte: Knoten mit Zonenposition, sonst eindeutiger Flugmeister in der genannten Zone
    local anchors = {}
    for _, tx in pairs(db) do
        if type(tx) == "table" and tx.map == map and tx.x and tx.y then
            local ai, an, aw
            if tx.zmap then
                ai, an, aw = self:ToWorld(tx.zmap, tx.zx, tx.zy)
            else
                local cand
                for _, part in ipairs(NameParts(tx.name)) do
                    local found = {}
                    for _, f in ipairs(fms) do
                        if LP:SameZoneName(self:MapName(f.v.map), part) and self:MapName(f.v.map) ~= "?" then found[#found + 1] = f end
                    end
                    if #found == 1 then cand = found[1] break end
                end
                if cand then ai, an, aw = cand.inst, cand.n, cand.w end
            end
            if ai then anchors[#anchors + 1] = { inst = ai, x = tx.x, y = tx.y, n = an, w = aw } end
        end
    end
    -- haeufigster Kontinent unter den Eichpunkten
    local cnt, inst = {}, nil
    for _, a in ipairs(anchors) do cnt[a.inst] = (cnt[a.inst] or 0) + 1 if not inst or cnt[a.inst] > cnt[inst] then inst = a.inst end end
    if not inst then return end
    local X, Y, N, W = {}, {}, {}, {}
    for _, a in ipairs(anchors) do
        if a.inst == inst then X[#X + 1], Y[#Y + 1], N[#N + 1], W[#W + 1] = a.x, a.y, a.n, a.w end
    end
    local w0, wk = Fit(X, W)
    local n0, nk = Fit(Y, N)
    if not w0 or not n0 then return end
    -- Ausreisser (falsch zugeordnete Eichpunkte) entfernen und neu rechnen
    local X2, Y2, N2, W2 = {}, {}, {}, {}
    for i = 1, #X do
        if self:Dist(n0 + nk * Y[i], w0 + wk * X[i], N[i], W[i]) < TAXI_MATCH * 2 then
            X2[#X2 + 1], Y2[#Y2 + 1], N2[#N2 + 1], W2[#W2 + 1] = X[i], Y[i], N[i], W[i]
        end
    end
    local a0, ak = Fit(X2, W2)
    local b0, bk = Fit(Y2, N2)
    if a0 and b0 then w0, wk, n0, nk = a0, ak, b0, bk end
    -- jeden Knoten seinem Flugmeister zuordnen
    for _, tx in pairs(db) do
        if type(tx) == "table" and tx.map == map and tx.x and tx.y and not tx.zmap then
            local n, w = n0 + nk * tx.y, w0 + wk * tx.x
            local best, bd
            for _, f in ipairs(fms) do
                if f.inst == inst then
                    local d = self:Dist(n, w, f.n, f.w)
                    if not bd or d < bd then best, bd = f, d end
                end
            end
            if best and bd <= TAXI_MATCH then tx.zmap, tx.zx, tx.zy = best.v.map, best.v.x, best.v.y end
        end
    end
end

-- Position eines Flugpunkts: map, x, y (Zone des Flugmeisters, wenn bekannt) und inst, n, w
function Geo:TaxiPoint(tx)
    if type(tx) ~= "table" or not tx.map then return nil end
    if not tx.zmap and not self:Bounds(tx.map) then self:CalibrateTaxi(tx.map) end
    if tx.zmap then
        local i, n, w = self:ToWorld(tx.zmap, tx.zx, tx.zy)
        if i then return tx.zmap, tx.zx, tx.zy, i, n, w end
    end
    local i, n, w = self:ToWorld(tx.map, tx.x, tx.y)
    if i then return tx.map, tx.x, tx.y, i, n, w end
    return nil
end

-- Wie viele Flugpunkte lassen sich verorten? (Selbsttest)
function Geo:TaxiUsable()
    local all, ok = 0, 0
    local db = (LP.Virtual and LP.Virtual.RealTaxi and LP.Virtual:RealTaxi()) or (LP.db and LP.db.taxi) or {}
    for _, tx in pairs(db) do
        if type(tx) == "table" then
            all = all + 1
            if self:TaxiPoint(tx) then ok = ok + 1 end
        end
    end
    return ok, all
end

function Geo:ResetTaxi() wipe(taxiTried) end
