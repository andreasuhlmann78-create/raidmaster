if AHSentinel_Blocked then return end   -- altes "AH Analyzer Pro" noch geladen (siehe OldAddonGuard.lua)
-- ============================================================
-- AHSentinel 0.59.33 - Komfort
--   * Alt-Klick auf ein Item (Taschen, Chat-Link): Preisverlauf / Einkauf öffnen
--   * Verkaufschance im Tooltip (aus der eigenen Buchhaltung)
--   * Erinnerung bei ablaufenden Auktionen
--   * Gold-Ziel
--   * Gildenbank lesen und bewerten
--   * Raid-Vorrat als Einkaufsliste
--   * Favoriten im Einkauf
-- ============================================================

AHAnalyzerPro = AHAnalyzerPro or {}
local A = AHAnalyzerPro
local L = A.L

local K = {}
A.Comfort = K

local function S() return A.db and A.db.settings or {} end

-- ============================================================
-- 1. Alt-Klick auf ein Item: Preisverlauf (oder Einkauf, wenn das Auktionshaus offen ist)
--    (Shift ist schon belegt: Stapel teilen und Links in den Chat)
-- ============================================================
function K:AltClickEnabled() return S().altClick ~= false end

function K:OnModifiedClick(link)
    if not self:AltClickEnabled() or type(link) ~= "string" then return end
    if not (IsAltKeyDown and IsAltKeyDown()) then return end
    if (IsShiftKeyDown and IsShiftKeyDown()) or (IsControlKeyDown and IsControlKeyDown()) then return end
    local id = tonumber(link:match("item:(%d+)"))
    if not id then return end
    local UI = A.UI
    if A:IsAHOpen() and UI.OpenBuyFor then
        UI:OpenBuyFor(id)
    elseif UI.OpenChart then
        UI:OpenChart(id)
    end
    return true
end

if hooksecurefunc and HandleModifiedItemClick then
    pcall(hooksecurefunc, "HandleModifiedItemClick", function(link) K:OnModifiedClick(link) end)
end

-- ============================================================
-- 2. Verkaufschance: wie viel von dem, was du eingestellt hast, wurde verkauft (60 Tage)
--    und wie lange es typischerweise gedauert hat
-- ============================================================
K.CHANCE_DAYS = 60
local chanceCache, chanceTime = nil, 0

local function Median(list)
    if #list == 0 then return nil end
    table.sort(list)
    local m = math.floor((#list + 1) / 2)
    if #list % 2 == 1 then return list[m] end
    return (list[m] + list[m + 1]) / 2
end

function K:BuildChances()
    local out = {}
    local entries = A.db and A.db.ledger and A.db.ledger.entries or {}
    local from = time() - self.CHANCE_DAYS * 86400
    local posts = {}           -- [itemID] = { Zeitpunkte }
    for _, e in ipairs(entries) do
        if e.itemID and e.t >= from then
            local r = out[e.itemID]
            if not r then r = { posted = 0, sold = 0, delays = {} }; out[e.itemID] = r end
            if e.kind == "deposit" and e.src == "post" then
                r.posted = r.posted + (e.qty or 1)
                posts[e.itemID] = posts[e.itemID] or {}
                table.insert(posts[e.itemID], e.t)
            elseif e.kind == "sale" then
                r.sold = r.sold + (e.qty or 1)
                local st = (A.Ledger and A.Ledger.SaleTime) and A.Ledger:SaleTime(e) or e.t
                -- letztes Einstellen davor
                local best
                for _, pt in ipairs(posts[e.itemID] or {}) do
                    if pt <= st and (not best or pt > best) then best = pt end
                end
                if best and st - best < 3 * 86400 then table.insert(r.delays, st - best) end
            end
        end
    end
    for id, r in pairs(out) do
        if r.posted > 0 then
            r.rate = math.min(100, r.sold / r.posted * 100)
            r.delay = Median(r.delays)
        end
    end
    return out
end

-- Rückgabe: { rate = %, posted, sold, delay = Sek. } oder nil (zu wenig Daten)
function K:SellChance(itemID)
    if not itemID then return nil end
    if not chanceCache or GetTime() - chanceTime > 60 then
        chanceCache, chanceTime = self:BuildChances(), GetTime()
    end
    local r = chanceCache[itemID]
    if not r or not r.rate or r.posted < 3 then return nil end
    return r
end

function K:InvalidateChances() chanceCache = nil end
A:On("LEDGER_CHANGED", function() K:InvalidateChances() end)

function K:FormatDelay(sec)
    if not sec then return nil end
    if sec < 3600 then return L["unter 1 Std."] end
    if sec < 86400 then return string.format(L["ca. %d Std."], math.floor(sec / 3600 + 0.5)) end
    return string.format(L["ca. %d Tage"], math.floor(sec / 86400 + 0.5))
end

function K:ChanceText(itemID)
    local r = self:SellChance(itemID)
    if not r then return nil end
    local color = (r.rate >= 70 and "33dd55") or (r.rate >= 40 and "ffcc33") or "ff5544"
    local text = string.format("|cff%s%d %%|r (%d/%d)", color, math.floor(r.rate + 0.5), r.sold, r.posted)
    local d = self:FormatDelay(r.delay)
    if d then text = text .. ", " .. d end
    return text
end

-- ============================================================
-- 3. Ablaufende Auktionen
-- ============================================================
function K:ExpiryEnabled() return S().expiryReminder ~= false end

local function EndsDB()
    if not A.db then return {} end
    A.db.ownedEnds = A.db.ownedEnds or {}
    return A.db.ownedEnds
end

-- NP160-1: Ware verschwundener eigener Auktionen kann ab min(Ende, jetzt) im Briefkasten liegen (A.db.ownedLeft,
-- Item -> Zeit; älter als 30 Tage fällt weg). Nur echte Daten, nie während der Testroutine.
function K:NoteOwnedLeft(list, gone, now)
    if not A.db or (A.InTestRoutine and A:InTestRoutine()) then return end
    local left = type(A.db.ownedLeft) == "table" and A.db.ownedLeft or {}
    for _, e in ipairs(list or {}) do
        if e.itemID and gone(e) then
            local t = math.min(now, e.endsAt or now)
            if t > (left[e.itemID] or 0) then left[e.itemID] = t end
        end
    end
    for id, t in pairs(left) do if t < now - 30 * 86400 then left[id] = nil end end
    A.db.ownedLeft = left
end
-- nach jedem Lesen der eigenen Auktionen: Endzeiten merken, bald ablaufende melden
function K:OnOwnedRead(owned)
    -- Testroutine: Server-Schritte lesen die eigenen Auktionen - die echten Ablaufzeiten erst nach dem Lauf neu schreiben
    -- (Sandbox, Befund 22:25 "ownedEnds"); T69 schreibt in eine Ersatztabelle (K.testEnds)
    if A.TestRoutine and A.TestRoutine.running and not self.testEnds then return end
    local now = time()
    local ends = {}
    local soon = {}
    self.warned = self.warned or {}
    for _, o in ipairs(owned or {}) do
        if not o.sold and o.itemID and o.timeLeft then
            table.insert(ends, { itemID = o.itemID, qty = o.qty or 1, endsAt = now + o.timeLeft, buyout = o.buyout, aid = o.auctionID })   -- LG1: Angebotspreis
            if o.timeLeft <= 1800 and not self.warned[o.auctionID] then
                self.warned[o.auctionID] = true
                table.insert(soon, o)
            end
        end
    end
    if A.db then
        -- NP160-1: verschwundene Auktionen (abgelaufen, abgebrochen, verkauft) -> Ware kann ab jetzt im Briefkasten liegen;
        -- Zeitpunkt der Lesung dauerhaft merken (nicht in der Testroutine-Ersatztabelle)
        if not self.testEnds then
            local nowAid, nowItem = {}, {}
            for _, e in ipairs(ends) do
                if e.aid then nowAid[e.aid] = true end
                nowItem[e.itemID] = true
            end
            K:NoteOwnedLeft(A.db.ownedEnds, function(e) if e.aid then return not nowAid[e.aid] end return not nowItem[e.itemID] end, now)
            A.db.ownedSeenT = now
        end
        A.db.ownedEnds = ends
    end
    if #soon > 0 and self:ExpiryEnabled() then
        local names, cheapest = {}, 0
        for k, o in ipairs(soon) do
            if k <= 4 then table.insert(names, (o.qty or 1) .. "x " .. (o.name or A:GetItemName(o.itemID))) end
            if o.status == "günstigstes" or o.status == "gleich" then cheapest = cheapest + 1 end
        end
        if #soon > 4 then table.insert(names, "...") end
        local msg = string.format(L["|cffffcc33%d Auktionen laufen in weniger als 30 Min. ab:|r %s"], #soon, table.concat(names, ", "))
        if cheapest > 0 then
            msg = msg .. "  " .. string.format(L["(%d davon noch günstigstes Angebot - nach der Rückkehr per Post mit 'Neu einstellen' wieder rein)"], cheapest)
        end
        A:Print(msg)
    end
end

-- beim Einloggen: was ist seit dem letzten Besuch abgelaufen, was läuft bald ab?
function K:LoginExpiryCheck()
    if not self:ExpiryEnabled() then return end
    local now = time()
    local expired, soon, keep = 0, 0, {}
    K:NoteOwnedLeft(EndsDB(), function(e) return e.endsAt <= now end, now)
    for _, e in ipairs(EndsDB()) do
        if e.endsAt <= now then
            expired = expired + 1
        else
            if e.endsAt - now <= 2 * 3600 then soon = soon + 1 end
            table.insert(keep, e)
        end
    end
    if A.db then A.db.ownedEnds = keep end
    if expired > 0 then
        A:Print(string.format(L["Seit deinem letzten Besuch sind %d Auktionen abgelaufen - am Briefkasten abholen, dann 'Neu einstellen' (Reiter Auktionen)."], expired))
    end
    if soon > 0 then
        A:Print(string.format(L["%d Auktionen laufen in den nächsten 2 Std. ab."], soon))
    end
end

-- verkauft: nicht mehr als "abgelaufen" zählen
function K:ForgetOne(itemID)
    local list = EndsDB()
    for i, e in ipairs(list) do
        if e.itemID == itemID then table.remove(list, i); return end
    end
end

-- ============================================================
-- 4. Gold-Ziel (alle Charaktere zusammen)
-- ============================================================
function K:GoldGoal() return S().goldGoal end

function K:SetGoldGoal(copper)
    if not A.db then return end
    if copper and copper > 0 then
        A.db.settings.goldGoal = math.floor(copper)
        A.db.settings.goldGoalReached = nil
        self:CheckGoldGoal()
    else
        A.db.settings.goldGoal = nil
        A.db.settings.goldGoalReached = nil
    end
    A:Fire("GOLDGOAL_CHANGED")
end

function K:GoldProgress()
    local goal = self:GoldGoal()
    if not goal then return nil end
    local total = A.Chars and A.Chars:TotalMoney() or (GetMoney and GetMoney()) or 0
    return total, goal, math.min(100, total / goal * 100)
end

function K:GoldGoalText()
    local total, goal, pct = self:GoldProgress()
    if not total then return nil end
    return string.format(L["Gold-Ziel: %s von %s (%d %%)"], A:FormatMoney(total), A:FormatMoney(goal), math.floor(pct))
end

function K:CheckGoldGoal()
    local total, goal = self:GoldProgress()
    if not total or S().goldGoalReached then return false end
    if total >= goal then
        A.db.settings.goldGoalReached = true
        A:Print(string.format(L["|cff33dd55Gold-Ziel erreicht!|r Alle Charaktere zusammen: %s (Ziel %s)."], A:FormatMoney(total), A:FormatMoney(goal)))
        if PlaySound then pcall(PlaySound, 888) end      -- Stufenaufstieg-Klang
        A:Fire("GOLDGOAL_CHANGED")
        return true
    end
    return false
end

-- /ahs ziel 5000  |  /ahs ziel aus  |  /ahs ziel
function K:GoalCommand(arg)
    arg = (arg or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if arg == "" then
        A:Print(self:GoldGoalText() or L["Kein Gold-Ziel gesetzt. Beispiel: /ahs ziel 5000"])
        return
    end
    local low = arg:lower()
    if low == "aus" or low == "off" or low == "0" then
        self:SetGoldGoal(nil)
        A:Print(L["Gold-Ziel gelöscht."])
        return
    end
    local g = tonumber((arg:gsub("[gG]$", ""):gsub("[%.']", ""):gsub(",", ".")))
    if not g or g <= 0 then
        A:Print(L["Kein Gold-Ziel gesetzt. Beispiel: /ahs ziel 5000"])
        return
    end
    self:SetGoldGoal(g * 10000)
    A:Print(self:GoldGoalText())
end

-- ============================================================
-- 5. Gildenbank (ab TBC): Inhalt lesen und bewerten
-- ============================================================
local function GuildName()
    if not GetGuildInfo then return nil end
    local ok, name = pcall(GetGuildInfo, "player")
    return ok and name or nil
end

function K:GuildBankSupported()
    return GetNumGuildBankTabs ~= nil and GetGuildBankItemLink ~= nil
end

local function GuildDB()
    if not A.db then return {} end
    A.db.guildBank = A.db.guildBank or {}
    return A.db.guildBank
end

function K:ScanGuildBank()
    if not self:GuildBankSupported() then return false end
    local guild = GuildName()
    if not guild then return false end
    local db = GuildDB()
    local g = db[guild] or { tabs = {} }
    db[guild] = g
    local nTabs = GetNumGuildBankTabs() or 0
    local slots = MAX_GUILDBANK_SLOTS_PER_TAB or 98
    local read = 0
    for tab = 1, nTabs do
        local okT, _, _, isViewable = pcall(GetGuildBankTabInfo, tab)
        if okT and isViewable ~= false then
            local items, any = {}, false
            for slot = 1, slots do
                local link = GetGuildBankItemLink(tab, slot)
                if link then
                    local id = tonumber(link:match("item:(%d+)"))
                    local _, count = GetGuildBankItemInfo(tab, slot)
                    if id then items[id] = (items[id] or 0) + (count or 1); any = true end
                end
            end
            -- leere Antwort (Fach noch nicht geladen) nicht über alte Daten schreiben
            if any or not g.tabs[tab] then g.tabs[tab] = items; read = read + 1 end
        end
    end
    for tab in pairs(g.tabs) do if tab > nTabs then g.tabs[tab] = nil end end
    if GetGuildBankMoney then local okM, m = pcall(GetGuildBankMoney); if okM and m then g.money = m end end
    g.time = time()
    A:Fire("GUILDBANK_CHANGED")
    return read > 0
end

function K:GuildBankData()
    local guild = GuildName()
    return guild and GuildDB()[guild] or nil, guild
end

-- wie Extras:InventoryValue, nur für die Gildenbank
function K:GuildBankValue()
    local g, guild = self:GuildBankData()
    local rows = {}
    if not g then return rows, { market = 0, vendor = 0, gold = 0, guild = guild } end
    local byID = {}
    for _, items in pairs(g.tabs or {}) do
        for id, n in pairs(items) do byID[id] = (byID[id] or 0) + n end
    end
    local totalMV, totalVendor = 0, 0
    for id, n in pairs(byID) do
        local mv = A:RealPrice(id)
        local vp = A:GetVendorPrice(id)
        local r = { itemID = id, count = n, bags = 0, bank = 0, alts = 0, guild = n, unit = mv,
                    value = mv and math.floor(mv * n) or 0, vendorValue = vp and vp * n or 0 }
        r.best = math.max(mv and A:NetSale(id, mv, n) or 0, r.vendorValue)
        if r.value > 0 or r.vendorValue > 0 then
            r.name = A:GetItemName(id)
            totalMV = totalMV + r.value
            totalVendor = totalVendor + r.vendorValue
            table.insert(rows, r)
        end
    end
    return rows, { market = totalMV, vendor = totalVendor, gold = g.money or 0, guild = guild, time = g.time }
end

-- ============================================================
-- 6. Raid-Vorrat: Tränke, Fläschchen und Buff-Food für eine Raidwoche
-- ============================================================
K.RAID_SETS = {
    classic = {
        { 13446, 10 }, -- Erheblicher Heiltrank
        { 13444, 10 }, -- Erheblicher Manatrank
        { 13510, 1 },  -- Fläschchen der Titanen
        { 13452, 4 },  -- Elixier des Mungos
        { 9206, 4 },   -- Elixier der Riesen
        { 13454, 4 },  -- Großes arkanes Elixier
        { 20007, 4 },  -- Magiebluttrank
        { 3825, 4 },   -- Elixier der Seelenstärke
        { 13457, 5 },  -- Großer Feuerschutztrank
        { 5634, 2 },   -- Trank der freien Aktion
        { 20452, 10 }, -- Geräucherte Wüstenknödel
    },
    tbc = {
        { 22829, 10 }, -- Super-Heiltrank
        { 22832, 10 }, -- Super-Manatrank
        { 22854, 2 },  -- Fläschchen des unerbittlichen Angriffs
        { 22861, 2 },  -- Fläschchen des blendenden Lichts
        { 22851, 2 },  -- Fläschchen der Stärkung
        { 22853, 2 },  -- Fläschchen der mächtigen Wiederherstellung
        { 22838, 4 },  -- Hasttrank
        { 22839, 4 },  -- Zerstörungstrank
        { 27667, 10 }, -- Würziger Flusskrebs
    },
    wrath = {
        { 33447, 10 }, -- Runenheiltrank
        { 33448, 10 }, -- Runenmanatrank
        { 46377, 2 },  -- Fläschchen der endlosen Wut
        { 46376, 2 },  -- Fläschchen des Frostwyrms
        { 46379, 2 },  -- Fläschchen des Steinbluts
        { 40211, 4 },  -- Trank der Schnelligkeit
        { 40212, 4 },  -- Trank der wilden Magie
        { 43015, 2 },  -- Fischfest
    },
}

function K:RaidSetKey()
    -- WoW Forever (moderner Client, Classic-Inhalte: Barrow Deeps, Hyjalgipfel, Onyxia): Classic-Vorrat.
    -- Vorläufig – Classic-Liste, Abgleich mit den Forever-Raids nach dem Launch: prüfen, ob alle Item-IDs
    -- der Liste in Forever existieren, bei Bedarf RAID_SETS.forever anlegen und hier zurückgeben.
    if A.IsForever and A:IsForever() then return "classic" end
    local p = WOW_PROJECT_ID
    if p == (WOW_PROJECT_CLASSIC or 2) then return "classic" end
    if p == (WOW_PROJECT_BURNING_CRUSADE_CLASSIC or 5) then return "tbc" end
    if p == (WOW_PROJECT_WRATH_CLASSIC or 11) then return "wrath" end
    -- alte Clients ohne WOW_PROJECT_ID (z.B. private Server)
    if not p then
        local build = GetBuildInfo and select(4, GetBuildInfo()) or 0
        if build < 20000 then return "classic" elseif build < 30000 then return "tbc" elseif build < 40000 then return "wrath" end
    end
    return nil
end

function K:CreateRaidList(weeks)
    local key = self:RaidSetKey()
    local set = key and self.RAID_SETS[key]
    if not set then return false, L["Die Raid-Vorlage gibt es für Classic, TBC und Wrath."] end
    weeks = math.max(1, math.floor(tonumber(weeks) or 1))
    local Li = A.Lists
    local name = L["Raid-Vorrat"]
    if not Li:Exists(name) then Li:Create(name) end
    for _, e in ipairs(set) do
        local qty = e[2] * weeks
        local items = A.db.lists and A.db.lists.items and A.db.lists.items[name]
        if items and items.entries[e[1]] then Li:SetQty(name, e[1], qty) else Li:AddItem(name, tostring(e[1]), qty) end
    end
    local cost = Li.TotalCost and Li:TotalCost(name)
    local msg = string.format(L["Einkaufsliste '%s' mit %d Items angelegt (Mengen für eine Raidwoche, anpassbar)."], name, #set)
    if type(cost) == "number" and cost > 0 then msg = msg .. "  " .. string.format(L["Kosten zum aktuellen Preis: %s"], A:FormatMoney(cost)) end
    return true, msg, name
end

-- ============================================================
-- 7. Favoriten im Einkauf (gespeicherte Suchen)
-- ============================================================
local function FavDB()
    if not A.db then return {} end
    A.db.buyFavorites = A.db.buyFavorites or {}
    return A.db.buyFavorites
end
K.FavDB = FavDB
K.MAX_FAVS = 12

function K:FavLabel(q)
    local parts = {}
    if q.text and q.text ~= "" then table.insert(parts, '"' .. q.text .. '"') end
    if q.cat and q.cat ~= "all" and A.Buy then table.insert(parts, A.Buy:CatLabel(q.cat)) end
    if q.minLevel or q.maxLevel then table.insert(parts, L["St. "] .. (q.minLevel or "") .. "-" .. (q.maxLevel or "")) end
    if q.minIlvl or q.maxIlvl then table.insert(parts, "iLvl " .. (q.minIlvl or "") .. "-" .. (q.maxIlvl or "")) end
    if q.quals then
        local min
        for k = 0, 5 do if q.quals[k] then min = k; break end end
        local names = { [0] = "Grau", "Weiß", "Grün", "Blau", "Episch", "Legendär" }
        if min and names[min] then table.insert(parts, L["ab "] .. L[names[min]]) end
    end
    if #parts == 0 then return L["Alle"] end
    return table.concat(parts, ", ")
end

function K:AddFavorite(q)
    if not q then return false, L["Erst eine Suche starten."] end
    local list = FavDB()
    local copy = { text = q.text or "", cat = q.cat or "all", minLevel = q.minLevel, maxLevel = q.maxLevel,
                   minIlvl = q.minIlvl, maxIlvl = q.maxIlvl }
    if q.quals then copy.quals = {}; for k, v in pairs(q.quals) do copy.quals[k] = v end end
    copy.label = self:FavLabel(copy)
    for _, f in ipairs(list) do
        if f.label == copy.label then return false, L["Diese Suche ist schon ein Favorit."] end
    end
    if #list >= self.MAX_FAVS then return false, string.format(L["Höchstens %d Favoriten."], self.MAX_FAVS) end
    table.insert(list, copy)
    A:Fire("FAVORITES_CHANGED")
    return true, L["Favorit gespeichert: "] .. copy.label
end

function K:RemoveFavorite(index)
    local list = FavDB()
    if not list[index] then return false end
    table.remove(list, index)
    A:Fire("FAVORITES_CHANGED")
    return true
end

-- ------------------------------------------------------------
-- Ereignisse
-- ------------------------------------------------------------
local evt = CreateFrame("Frame")
K.evt = evt            -- für die Testroutine (Ereignisse mit Testargumenten nachspielen)
for _, e in ipairs({ "PLAYER_MONEY", "GUILDBANKFRAME_OPENED", "GUILDBANKBAGSLOTS_CHANGED", "GUILDBANK_UPDATE_MONEY", "GUILDBANKFRAME_CLOSED" }) do
    pcall(evt.RegisterEvent, evt, e)
end
local gbDirty, gbAcc = false, 0
evt:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_MONEY" then
        -- Charaktere zuerst aktualisieren lassen
        if C_Timer and C_Timer.After then C_Timer.After(0.2, function() K:CheckGoldGoal() end) else K:CheckGoldGoal() end
    elseif event == "GUILDBANKFRAME_OPENED" then
        K.gbOpen = true
        if QueryGuildBankTab and GetNumGuildBankTabs then
            for tab = 1, (GetNumGuildBankTabs() or 0) do pcall(QueryGuildBankTab, tab) end
        end
        gbDirty = true
    elseif event == "GUILDBANKFRAME_CLOSED" then
        if gbDirty then K:ScanGuildBank(); gbDirty = false end
        K.gbOpen = false
    else
        gbDirty = true
    end
end)
evt:SetScript("OnUpdate", function(_, dt)
    if not gbDirty then return end
    gbAcc = gbAcc + (dt or 0)
    if gbAcc < 1 then return end
    gbAcc, gbDirty = 0, false
    K:ScanGuildBank()
end)

A:On("READY", function()
    -- eigene Auktionen beobachten
    local Se = A.Seller
    if Se and not Se.__comfortHooked then
        Se.__comfortHooked = true
        local read = Se.ReadOwned
        Se.ReadOwned = function(self, ...)
            local r = read(self, ...)
            pcall(K.OnOwnedRead, K, self.owned)
            return r
        end
        local sold = Se.OnSold
        Se.OnSold = function(self, name, ...)
            local o = self.FindOwnedByName and self:FindOwnedByName(name)
            local id = (o and o.itemID) or (A.FindItemByName and A:FindItemByName(name))
            if id then K:ForgetOne(id) end
            return sold(self, name, ...)
        end
    end
    if C_Timer and C_Timer.After then
        C_Timer.After(10, function() pcall(K.LoginExpiryCheck, K); pcall(K.CheckGoldGoal, K) end)
    end
end)

-- ============================================================
-- "Heute tun": die Aktionen, die gerade am meisten Gold bringen
-- Jede Aktion: { gold = geschätzter Gewinn, text, where, run = function() ... end }
-- Gewinn ist immer netto (AH-Anteil, erwartete Einstellgebühr) und nur bei verlässlichem
-- Marktwert (keine Mondpreise, Ware, die sich wirklich verkauft).
-- ============================================================
local function OpenTab(tab)
    if not A.UI then return end
    A.UI:Show()
    A.UI:SelectTab(tab)
end

-- Kapitalschutz: höchstens 20 % des Golds pro Kauf-Vorschlag, alle Käufe zusammen höchstens 50 %
K.TODAY_ITEM_SHARE = 0.10           -- FL-1/RK4: höchstens 10 % des Golds je Item (vorher 20 %)
K.PROBE_SHARE = 0.10                -- FL-1: Weg ohne eigene Fälle ("lernt noch") -> nur eine Probe = 10 % des Item-Budgets
K.TODAY_TOTAL_SHARE = 0.25          -- K1 (Entscheid 10.11. 15:59): Standard 25 %; wirksam ist K:TotalShare() (Option)
-- K1: alle Kaufvorschläge im Markt zusammen höchstens dieser Anteil des aktuellen Golds (Option, Standard 25 %, nie über 50 %)
function K:TotalShare()
    return A:MarketCapitalPct() / 100
end

-- Befund 20:15 A3 ("Heute tun" 314 ms bei 5220 Items): Ergebnis zwischenspeichern, bei neuem Datenstand im
-- Hintergrund neu rechnen (A:CachedValue). fresh = true: sofort rechnen (Testroutine, Selbsttest).
K.todayVersion = 0
for _, ev in ipairs({ "WATCHLIST_CHANGED", "SETTINGS_CHANGED", "LISTS_CHANGED" }) do
    A:On(ev, function() K.todayVersion = K.todayVersion + 1 end)
end
-- RK7: Sicherheit eines Wegs = Trefferquote aus dem Kern (MK:Quote); lernt der Weg noch: Freigabe-Schwelle (vorsichtig)
K.WAY_OF_KIND = { flip = "flip", quick = "flip", bid = "flip", de = "de", desell = "de", vendor = "vendor" }
function K:WaySafety(kind, cache)
    local MK = A.Core
    local way = self.WAY_OF_KIND[kind or ""]
    if not (way and MK and MK.Quote) then return 1 end
    if cache and cache[way] ~= nil then return cache[way] end
    local okQ, n, q = pcall(MK.Quote, MK, way)
    local v = (okQ and n and q and n >= (MK.FREE_MIN or 0)) and q or (MK.FREE_PCT or 0.5)
    if cache then cache[way] = v end
    return v
end
-- RK7: Gold je Tag je 1g Einsatz × Sicherheit (für die Verteilung des Budgets; ohne Einsatz = math.huge)
function K:RankScore(r, cache)
    if (r.capital or 0) <= 0 then return math.huge end
    return (r.gold / r.capital) / math.max(r.days or 1, 0.25) * self:WaySafety(r.kind, cache)
end
function K:TodayActions(max, fresh, async)
    local money = GetMoney and GetMoney() or 0
    local Ln = A.Learn
    local version = table.concat({ A:DataVersion(), math.floor(money / 10000), self.todayVersion,
        math.floor(time() / 300), _G.ProfessionSentinelAPI and 1 or 0, tostring(max),
        (Ln and Ln.forceOff) and "F" or "" }, "|")            -- FW1: Stand mit/ohne Lernen nie vermischen
    local packedV, ready = A:CachedValue("today:" .. tostring(max), version, function()
        return { self:ComputeTodayActions(max) }
    end, fresh, async)
    local packed = packedV or {}
    -- Aufträge anderer Addons (A.Today:QuickBuy / QuickSell) stehen oben - immer aktuell, nicht zwischengespeichert
    local res = {}
    for _, r in ipairs(packed[1] or {}) do res[#res + 1] = r end
    -- MH1310: Freigaben (Teil D) und Ü3 auch in "Heute tun" - nicht freigegebene Wege nie als Empfehlung
    if A.Core and A.Core.ApplyTodayRelease then
        local okR, r2 = pcall(A.Core.ApplyTodayRelease, A.Core, res)
        if okR and r2 then res = r2 end
    end
    -- TB171-1 (Entscheid: nur zeigen, was Gold bringt): Zeilen, deren Prüfung "nicht mehr lohnend" ergab, fallen weg
    if A.Today and A.Today.State then
        local keep = {}
        for _, r in ipairs(res) do
            local okS, st = pcall(A.Today.State, A.Today, r)
            if not (okS and st and st.step == "stale") then keep[#keep + 1] = r end
        end
        res = keep
    end
    if A.Today and A.Today.ExtraRows then
        local extra = A.Today:ExtraRows()
        for i = #extra, 1, -1 do table.insert(res, 1, extra[i]) end
    end
    return res, packed[2], packed[3], ready
end

-- vorab im Hintergrund rechnen (nach dem Einloggen und nach jedem Scan), dann ist "Heute tun" sofort da
local function WarmToday()
    if A.Job then A:Job("cache:warm-today", function() K:TodayActions(10) end) end
end
A:On("SCAN_FINISHED", WarmToday)
A:On("READY", function() if C_Timer and C_Timer.After then C_Timer.After(15, WarmToday) end end)

-- FW1 (Diagnose 0.65.110, Item 12184 "Liste bis 184 · Detail bis 107", 8 s später umgekehrt): Ursache - die Flip-Liste
-- (X:GetFlipDeals) läuft in Portionen über viele Frames; die Grenze der Zeile stammte aus einem älteren Stand als die
-- Detail-Prüfung im selben Moment (gelernte Marge geändert bzw. Lernen kurz aus durch die Testroutine, Ln.forceOff).
-- Jetzt: die Zeile wird unmittelbar vor dem Vergleich mit DERSELBEN Rechnung (A:FlipCheck) neu bestimmt - Liste und Detail
-- rechnen im selben Augenblick mit demselben Stand. Lohnt es sich nach dem neuen Stand nicht mehr: still weg (kein Widerspruch).
function K:FlipRowCheck(d)
    local okR, fokR, frR = pcall(A.FlipCheck, A, d.itemID, d.price)
    if not (okR and frR) then return false end
    if not fokR then return false end
    d.limit, d.ref = frR.limit, frR.resale
    if frR.net then d.profit = math.floor(frR.net - d.price) end
    return A.MarketView:FlipConsistent(d.itemID, d.limit, d.ref)
end

K.PS_EVERY = 900
function K:PSCrafts(PS)
    local c = self.psCache
    if c and time() - c.t < self.PS_EVERY then return c.ok, c.v end
    local t0 = debugprofilestop and debugprofilestop() or 0
    local ok, v = A:PCall(PS.TodayCrafts, 5)
    local ms = debugprofilestop and (debugprofilestop() - t0) or 0
    self.psCache = { t = time(), ok = ok, v = v, ms = ms }
    return ok, v
end
-- MH-1 (Nutzer 16:16 "Markt und Tipps prüfe den Vorschlag"): "Heute tun" darf dem eigenen besten Weg nicht widersprechen.
-- Zutaten (auch Zwischenprodukte) einer Herstellungs-Kette mit Gewinn ≥ Mindestgewinn werden nicht zum Verkauf
-- vorgeschlagen. Zurück: use[itemID] = Produkt der Kette, chains = { {c = Kette, n = mit den Taschen herstellbar} }
-- bag: { {itemID, count}, ... } aus Se:GetBagItems
function K:ChainUse(bag)
    local Ke = A.Ketten
    local use, chains = {}, {}
    if not Ke then return use, chains end
    local recipes = Ke:Recipes()
    local list = Ke.testList or (Ke:Saved() and Ke:Saved().list) or {}
    local have = {}
    for _, e in ipairs(bag or {}) do have[e.itemID] = (have[e.itemID] or 0) + (e.count or 0) end
    local function mark(id, pid, depth)
        local rec = recipes[id]
        if not rec or depth > Ke.DEPTH then return end
        for _, re in ipairs(rec.reagents or {}) do
            if not use[re[1]] then use[re[1]] = pid end
            mark(re[1], pid, depth + 1)
        end
    end
    for _, c in ipairs(list) do
        if c.pid and (c.profit or 0) > 0 then
            mark(c.pid, c.pid, 1)
            local rec = recipes[c.pid]
            local n
            for _, re in ipairs(rec and rec.reagents or {}) do
                local k = math.floor((have[re[1]] or 0) / math.max(1, re[2] or 1))
                n = n and math.min(n, k) or k
            end
            chains[#chains + 1] = { c = c, n = (n or 0) * math.max(1, math.floor((rec and rec.made) or 1)) }
        end
    end
    return use, chains
end
-- Entzauber-Wert je Stück (nach Gebühren) oder nil; Testroutine: K.testDE
function K:DEUnit(itemID)
    if self.testDE then return self.testDE[itemID] end
    local Cr = A.Crafting
    if not (Cr and Cr.DisenchantValue) then return nil end
    local ok, v = pcall(Cr.DisenchantValue, Cr, itemID, 1)
    return ok and v or nil
end
-- Einstand je Lager-Posten für count Stück (Gewinn statt Erlös in der Spalte "Zahl")
function K:StockCost(itemID, count)
    local BK = A.Books
    if not (BK and BK.Position) then return 0 end
    local ok, q, c = pcall(BK.Position, BK, itemID)
    if not ok or (q or 0) <= 0 or (c or 0) <= 0 then return 0 end
    -- Eröffnungsbestand (bt "open"): bewertet zum Marktwert beim Neustart, nicht bezahlt -> für den Vorschlag kein Einstand
    local db = BK.Data and BK:Data()
    local p = db and db.cb and db.cb[BK:CharKey()] and db.cb[BK:CharKey()][itemID]
    if p and p.bt == "open" then return 0 end
    return math.floor(c * math.min(count, q) / q + 0.5)
end
function K:ComputeTodayActions(max)
    local out = {}
    -- RK4: abgewählte Wege erscheinen nicht (Kauf-/Herstell-Vorschläge; eigene Ware verkaufen bleibt)
    local WAY_OF = { flip = "flip", quick = "flip", de = "de", desell = "de", vendor = "vendor", craft = "craft", owncraft = "craft", chaincraft = "craft" }
    local function add(gold, text, where, run, kind, capital)
        local w = WAY_OF[kind or ""]
        if w and not A:WayOn(w) then return end
        if gold and gold > 0 then
            table.insert(out, { gold = math.floor(gold), text = text, where = where, run = run, kind = kind, capital = capital or 0 })
        end
    end
    local money = GetMoney and GetMoney() or 0
    local itemCap = money * self.TODAY_ITEM_SHARE
    -- Menge für einen Kauf: höchstens 1 Tag Absatz, höchstens 20 % des Golds, mindestens 1
    local function buyQty(price, perDay, available)
        local q = math.max(1, math.floor(perDay or 1))
        if available and available > 0 then q = math.min(q, available) end
        if price and price > 0 then q = math.min(q, math.floor(itemCap / price)) end
        return q
    end
    local name = function(id) return A:GetItemName(id) end

    A:Pause()                                          -- D3: jeder Abschnitt eigene Portion
    -- 1. Unter Händlerpreis: kaufen und beim Händler verkaufen (kein AH-Anteil, Händler kauft alles)
    --    Quelle: letzter Scan oder aktuelle Suche, ab Mindestgewinn (Standard 10 Silber), die besten 10
    local okV, vendor = A:PCall(A.VendorFlipOffers, A, nil, 10)
    if okV then
        for _, d in ipairs(vendor) do
            A:Pause()                                  -- X5: kleinere Portionen
            -- Kapitalschutz: höchstens 20 % des Golds je Vorschlag
            local qty = d.qty
            if d.price > 0 then qty = math.min(qty, math.floor(itemCap / d.price)) end
            if qty > 0 then
                local gold = (qty == d.qty) and d.profit or (d.vendor - d.price) * qty
                if gold >= A:VendorFlipMin() then
                    add(gold, string.format(L["Unter Händlerpreis: kaufen und beim Händler verkaufen - %dx %s ab %s, Händler zahlt %s"],
                        qty, d.name or ("#" .. d.itemID), A:FormatMoney(d.price), A:FormatMoney(d.vendor)),
                        L["Einkauf"], function() A.UI:OpenBuyFor(d.itemID) end, "vendor", d.price * qty)
                    if out[#out] and out[#out].kind == "vendor" then
                        -- gekauft wird jedes Angebot unter dem Händlerpreis, nie teurer, nie mehr als qty
                        out[#out].itemID, out[#out].maxUnit, out[#out].qty, out[#out].vendor = d.itemID, d.vendor - 1, qty, d.vendor
                        -- K1: kürzbar (Menge, Kapital, Gewinn und Text für weniger Stück)
                        out[#out].price, out[#out].unitGold = d.price, (d.vendor - d.price)
                        out[#out].retext = function(q) return string.format(L["Unter Händlerpreis: kaufen und beim Händler verkaufen - %dx %s ab %s, Händler zahlt %s"],
                            q, d.name or ("#" .. d.itemID), A:FormatMoney(d.price), A:FormatMoney(d.vendor)) end
                    end
                end
            end
        end
    end

    A:Pause()                                          -- D3: jeder Abschnitt eigene Portion
    -- 2. Flips: günstig kaufen, wieder einstellen - nach Gewinn pro Tag
    local okF, flips = A:PCall(A.Extras.GetFlipDeals, A.Extras, 20)
    if okF then
        local n = 0
        local Ln = A.Learn
        local flipLeft = (Ln and Ln.BudgetLeft) and Ln:BudgetLeft("e") or nil
        for _, d in ipairs(flips) do
            A:Pause()                                  -- X5: kleinere Portionen
            -- Stufe 2 L7: Flip nur unter der Kaufgrenze (Netto beim Wiederverkauf × (1 − Marge)) und im Tagesbudget
            local learnOK = true
            if Ln and Ln.On and Ln:On() and d.ref then
                local lim = Ln:BuyLimit(math.floor(d.ref * (1 - A:CutPct())), "e")
                if lim and d.price > lim then learnOK = false end
                if flipLeft and flipLeft < d.price then learnOK = false end
            end
            -- H3: nur, wenn der Detailbereich für dasselbe Item auch "kaufen" sagt (gleiche Funktion, gleiche Zahlen)
            if learnOK and A.MarketView and A.MarketView.FlipConsistent then
                -- H3/F3: Liste = Detail (gleiche Rechnung), sonst verwerfen + FLIP-WIDERSPRUCH
                A:Pause()                              -- TB172-1 (18 ms bis Comfort.lua:791): Prüfung, Absatz und Menge getrennt
                if not self:FlipRowCheck(d) then learnOK = false end
            end
            A:Pause()
            if learnOK and A:IsReliable(d.itemID) then
                local l = {}
                A:Pause()
                l.perDay, l.src = A:PerDayInfo(d.itemID)                   -- K2: plausibel, Quelle ehrlich
                local qty = buyQty(d.price, l.perDay, d.quantity)
                if d.qtyMax then qty = math.min(qty, d.qtyMax) end          -- H4: Absatz × Laufzeit × eigener Anteil
                if qty >= 1 and d.price * qty <= itemCap then
                    add(d.profit * qty, string.format(L["Kaufe %dx %s bis %s, wieder einstellen um %s (verkauft sich ~%s/Tag, %s)"], qty, d.name,
                        A:FormatMoney(d.price), A:FormatMoney(d.ref), l.perDay and string.format("%.1f", l.perDay) or "?", l.src or "?"),
                        L["Einkauf"], function() A.UI:OpenBuyFor(d.itemID) end, "flip", d.price * qty)
                    if out[#out] and out[#out].kind == "flip" then
                        out[#out].itemID, out[#out].maxUnit, out[#out].qty, out[#out].unit = d.itemID, d.price, qty, A:GetSalePrice(d.itemID)
                        out[#out].price, out[#out].unitGold = d.price, d.profit
                        out[#out].retext = function(q) return string.format(L["Kaufe %dx %s bis %s, wieder einstellen um %s (verkauft sich ~%s/Tag, %s)"], q, d.name,
                            A:FormatMoney(d.price), A:FormatMoney(d.ref), l.perDay and string.format("%.1f", l.perDay) or "?", l.src or "?") end
                    end
                    n = n + 1
                    if n >= 3 then break end
                end
            end
        end
    end

    A:Pause()                                          -- D3: jeder Abschnitt eigene Portion
    -- 3. Eigene Auktionen unterboten
    local Se = A.Seller
    if Se and Se.owned then
        local n, value = 0, 0
        for _, o in ipairs(Se.owned) do
            A:Pause()                                  -- X5: kleinere Portionen
            if o.status == "unterboten" then n = n + 1; value = value + (o.buyout or 0) end
        end
        if n > 0 then
            add(math.max(1, value * 0.1), string.format(L["%d deiner Auktionen sind unterboten - abbrechen und günstiger neu einstellen"], n),
                L["Meine Auktionen"], function() OpenTab("auctions") end, "undercut")
        end
    end

    A:Pause()                                          -- D3: jeder Abschnitt eigene Portion
    -- 4. Zurückgekommene Ware neu einstellen
    if A.Extras and A.Extras.RepostItems then
        local value, n = 0, 0
        for id in pairs(A.Extras:RepostItems()) do
            A:Pause()
            n = n + 1
            local have = Se and Se:CountInBags(id) or 1
            value = value + A:NetSale(id, A:RealPrice(id) or 0, have)
        end
        if n > 0 then
            add(value, string.format(L["%d zurückgekommene Items neu einstellen"], n), L["Meine Auktionen"], function() OpenTab("auctions") end, "repost")
        end
    end

    A:Pause()                                          -- D3: jeder Abschnitt eigene Portion
    -- 5. Was in den Taschen liegt und sich gut verkauft
    -- Preis = was man heute bekommt: höchstens Marktwert und höchstens 5 % über dem günstigsten Angebot.
    -- Ist der Preis gerade eingebrochen und der Händler zahlt mehr, lieber beim Händler verkaufen.
    if Se and Se.GetBagItems then
        local okB, bag = A:PCall(Se.GetBagItems, Se, true)
        if okB then
            local cands, vend, des = {}, {}, {}
            local okU, chainUse, chains = pcall(self.ChainUse, self, bag)
            if not okU then chainUse, chains = {}, {} end
            self.lastChainUse = chainUse
            for _, e in ipairs(bag) do
                A:Pause()
                local deU = self:DEUnit(e.itemID)
                local ahTotal = 0
                if deU and deU > 0 then
                    A:Pause()                                   -- TB170-2: Entzauber-Wert und AH-Wert in getrennten Portionen
                    local okRV, rv = pcall(A.RealValue, A, e.itemID, e.count)
                    ahTotal = (okRV and type(rv) == "number") and rv or 0
                end
                if chainUse[e.itemID] then
                    -- MH-1: Zutat einer lohnenden Kette -> nicht verkaufen (die Kette bringt mehr)
                elseif deU and deU > 0 and deU >= (A:GetVendorPrice(e.itemID) or 0) and deU * e.count > ahTotal then
                    -- MH-1: Entzaubern bringt mehr als AH und Händler -> Vorschlag "entzaubern", kein Verkauf
                    table.insert(des, { e = e, gold = deU * e.count - self:StockCost(e.itemID, e.count), de = deU })
                else
                A:Pause()                                       -- TB170-2
                local mv = A:GetMarketValue(e.itemID)
                local sale = A:GetSalePrice(e.itemID)
                local reliable, l = A:IsReliable(e.itemID)
                local vendor = A:GetVendorPrice(e.itemID) or 0
                if mv and sale and reliable and (l.perDay or 0) >= 0.5 then
                    -- H1 (Befund 07:35): die ganze Menge als EINE Einstellung (Waren im modernen AH), dieselbe Rechnung wie
                    -- Tooltip/Gewinn-Fenster (A:RealValue: 5 %, Einzahlungsrisiko mit Angebot und Absatz, Händler als Untergrenze)
                    local okV, total, _, _, vendorWins = pcall(A.RealValue, A, e.itemID, e.count)
                    local unit = (okV and total) and (total / e.count) or 0
                    local gain = (unit - vendor) * e.count      -- was das AH mehr bringt als der Händler
                    if gain > 0 and not vendorWins then table.insert(cands, { e = e, gold = unit * e.count, gain = gain, mv = sale })
                    elseif A:IsForever() and vendor > 0 and vendorWins and sale * (1 - A:CutPct()) > vendor then
                        -- WoW Forever: mit nur 5 % wäre das AH besser - mit der verlorenen Einzahlung zahlt der Händler mehr
                        table.insert(vend, { e = e, gold = vendor * e.count, fee = true })
                    end
                elseif mv and sale and vendor > 0 and mv > vendor * 1.5 and sale * (1 - A:CutPct()) <= vendor * 1.05 then
                    -- sonst ein AH-Item, gerade aber kaum mehr wert als beim Händler
                    table.insert(vend, { e = e, gold = vendor * e.count })
                end
                end
            end
            -- MH-1: je Zeile EINE Zahl = Gewinn (Erlös − Einstand), nicht der Erlös
            for _, c in ipairs(cands) do c.gold = c.gold - self:StockCost(c.e.itemID, c.e.count) end
            for _, c in ipairs(vend) do c.gold = c.gold - self:StockCost(c.e.itemID, c.e.count) end
            table.sort(cands, function(a, b) return a.gold > b.gold end)
            for i = 1, math.min(3, #cands) do
                local c = cands[i]
                add(c.gold, string.format(L["Verkaufe %dx %s (ca. %s pro Stück)"], c.e.count, c.e.name or name(c.e.itemID), A:FormatMoney(c.mv)),
                    L["Verkaufen"], function()
                        OpenTab("sell")
                        local tab = A.UI:GetTab("sell")
                        if tab and tab.panel and tab.panel.Select then tab.panel:Select(c.e.itemID) end
                    end, "sell")
                out[#out].itemID, out[#out].unit, out[#out].count = c.e.itemID, c.mv, c.e.count
                out[#out].help = L["Gewinn: Erlös nach Gebühren minus dem, was dich die Ware gekostet hat."]
            end
            table.sort(des, function(a, b) return a.gold > b.gold end)
            for i = 1, math.min(2, #des) do
                local c = des[i]
                add(c.gold, string.format(L["Entzaubere %dx %s (Material ca. %s je Stück)"], c.e.count, c.e.name or name(c.e.itemID), A:FormatMoney(math.floor(c.de))),
                    L["Entzaubern"], function() if A.DEWindow and A.DEWindow.Show then A.DEWindow:Show() end end, "desell")
                if out[#out] and out[#out].kind == "desell" then
                    out[#out].itemID = c.e.itemID
                    out[#out].help = L["Gewinn: Wert des Materials nach Gebühren minus dem, was dich die Teile gekostet haben."]
                end
            end
            -- MH-1: Herstellen aus der Kette (gleiche Zahl wie die Kette) - erst nach der Freigabe der Ketten (Ke.LIVE)
            local Ke = A.Ketten
            if Ke and (Ke.LIVE or self.testChainLive) then
                for _, ch in ipairs(chains) do
                    if ch.n >= 1 then
                        add(ch.c.profit * ch.n, string.format(L["Stelle %dx %s her (+%s je Stück)"], ch.n, A:GetItemName(ch.c.pid) or ("#" .. ch.c.pid), A:FormatMoney(ch.c.profit)),
                            L["Herstellen"], nil, "chaincraft", 0)
                        if out[#out] and out[#out].kind == "chaincraft" then
                            out[#out].itemID, out[#out].key = ch.c.pid, "chain:" .. ch.c.pid
                            out[#out].help = L["Gewinn je Stück: Wert des Ergebnisses minus Kosten der Zutaten (wie Beste Rezepte)."]
                        end
                    end
                end
            end
            table.sort(vend, function(a, b) return a.gold > b.gold end)
            if vend[1] and vend[1].gold > 0 then
                local c = vend[1]
                local text = c.fee and L["Verkaufe %dx %s beim Händler (mit dem Einzahlungsrisiko zahlt der Händler mehr)"]
                    or L["Verkaufe %dx %s beim Händler (AH-Preis gerade eingebrochen)"]
                add(c.gold, string.format(text, c.e.count, c.e.name or name(c.e.itemID)),
                    L["Händler"], function() end, "vendorsell")
            end
        end
    end

    A:Pause()                                          -- D3: jeder Abschnitt eigene Portion
    -- 6. Unter Entzauberwert
    if A.Disenchant and A.Disenchant.FindDeals then
        local okD, de = A:PCall(A.Disenchant.FindDeals, A.Disenchant)
        if okD and de[1] then
            table.sort(de, function(a, b) return (a.profit or 0) > (b.profit or 0) end)
            local d = de[1]
            if d.price and d.price <= itemCap then add(d.profit, string.format(L["Kaufe %s für %s und entzaubere es (Wert ca. %s)"], d.name, A:FormatMoney(d.price), A:FormatMoney(d.net)),
                L["Einkauf"], function() A.UI:OpenBuyFor(d.itemID) end, "de", d.price)
                if out[#out] and out[#out].kind == "de" then
                    out[#out].itemID, out[#out].maxUnit, out[#out].qty = d.itemID, d.price, 1
                end
            end
        end
    end

    A:Pause()                                          -- D3: jeder Abschnitt eigene Portion
    -- 7. Gebote weit unter Wert (nur verlässliche)
    local okG, bids = A:PCall(A.GetBidDeals, A, 40)
    if okG then
        table.sort(bids, function(a, b) return (a.profit or 0) > (b.profit or 0) end)
        for _, d in ipairs(bids) do
            A:Pause()                                  -- X5: kleinere Portionen
            local cost = d.nextBid or d.price or 0
            local _, bl = A:IsReliable(d.itemID)
            if bl.conf == "hoch" and not A:IsOddPrice(d.ref) and cost <= itemCap then
                add(d.profit * 0.5, string.format(L["Biete auf %s: Gebot %s, Wert ca. %s (gewinnt erst am Ende)"], d.name,
                    A:FormatMoney(cost), A:FormatMoney(d.ref)), L["Einkauf"], function() A.UI:OpenBuyFor(d.itemID) end, "bid", cost)
                if out[#out] and out[#out].kind == "bid" then
                    local q = math.max(1, d.quantity or 1)
                    out[#out].itemID, out[#out].maxUnit, out[#out].qty = d.itemID, math.ceil(cost / q), q
                end
                break
            end
        end
    end

    -- Stufe 2 L8: Verlustgrenze - gekaufte Ware, deren Marktwert seit dem Kauf um mehr als 25 % fiel (je Kauf einmal)
    if A.Learn and A.Learn.LossWarnings then
        local okW, warns = A:PCall(A.Learn.LossWarnings, A.Learn)
        if okW then
            local shown = 0
            for i = 1, #warns do
                local w = warns[i]
                -- TB174-1: nur mit Nutzen (jetzt verkaufen bringt mehr als warten, mindestens 1s) - sonst keine Zeile
                if shown >= 2 then break end
                if (w.sellNow or 0) >= 100 and (w.sellNow or 0) > (w.waitValue or 0) then
                shown = shown + 1
                local text = string.format(L["Preis gefallen: %dx %s (Marktwert %s statt %s beim Kauf) - jetzt verkaufen bringt %s, warten erwartet %s"],
                    w.qty, name(w.itemID), A:FormatMoney(w.mv), A:FormatMoney(w.mv0), A:FormatMoney(w.sellNow or 0), A:FormatMoney(w.waitValue or 0))
                add(math.max(1, w.sellNow or 1), text, L["Verkaufen"], function()
                    pcall(A.Learn.LossWarnings, A.Learn, nil, true)          -- gesehen: nicht noch einmal
                    OpenTab("sell")
                    local tab = A.UI:GetTab("sell")
                    if tab and tab.panel and tab.panel.Select then tab.panel:Select(w.itemID) end
                end, "lossguard")
                if out[#out] and out[#out].kind == "lossguard" then out[#out].itemID = w.itemID end
                end
            end
        end
    end

    A:Pause()                                          -- D3: jeder Abschnitt eigene Portion
    -- 8. Herstellen (ProfessionSentinel): Zutaten kaufen -> herstellen -> einstellen, Schritt für Schritt
    local PS = _G.ProfessionSentinelAPI
    if PS and PS.version == 1 and PS.TodayCrafts then
        -- TB157-1 (Testbericht 0.65.157: ein Schritt 153 ms hier): PS.TodayCrafts rechnet in ProfessionSentinel ohne Pause.
        -- Ergebnis höchstens alle PS_EVERY Sekunden neu holen (sonst bei jedem Scan/Neuaufbau), dazwischen das gemerkte
        local okC, crafts = self:PSCrafts(PS)
        if okC and type(crafts) == "table" then
            for _, c in ipairs(crafts) do
                A:Pause()                                  -- X5: kleinere Portionen
                local dupe = false
                for _, r in ipairs(out) do if r.kind == "chaincraft" and r.itemID and r.itemID == c.itemID then dupe = true end end
                if not dupe and type(c) == "table" and c.gold and c.recipeName and (tonumber(c.capital) or 0) <= itemCap then
                    add(c.gold, string.format(L["Stelle %dx %s her (+%s je Stück)"], c.count or 1, c.recipeName, A:FormatMoney(c.perCraft or 0)),
                        L["Herstellen"], c.run, "craft", c.capital)
                    if out[#out] and out[#out].kind == "craft" then
                        out[#out].itemID, out[#out].stepText, out[#out].key = c.itemID, c.stepText, "craft:" .. tostring(c.itemID or c.recipeName)
                    end
                end
            end
        end
    end

    A:Pause()                                          -- D3: jeder Abschnitt eigene Portion
    -- 9. Ohne ProfessionSentinel: einfache eigene Herstell-Vorschläge aus den gemerkten Rezepten dieses Charakters
    local hasPS = PS and PS.version == 1 and PS.TodayCrafts
    if not hasPS and A.Crafting and A.Crafting.TodaySuggestions then
        local okO, own = A:PCall(A.Crafting.TodaySuggestions, A.Crafting, 3)
        if okO then
            for _, c in ipairs(own) do
                A:Pause()                                  -- X5: kleinere Portionen
                local capital = c.cost * c.count
                local sp = A.Ledger and A.Ledger.SellSpeed and c.productID and A.Ledger:SellSpeed(c.productID)
                if capital <= itemCap and not (sp and sp.speed == "kaum") then
                    add(c.profit * c.count, string.format(L["Stelle %dx %s her (+%s je Stück)"], c.count, c.name, A:FormatMoney(c.profit)),
                        L["Herstellen"], nil, "owncraft", capital)
                    if out[#out] and out[#out].kind == "owncraft" then
                        local r = out[#out]
                        r.itemID, r.craft, r.count, r.key = c.productID, c, c.count, "owncraft:" .. tostring(c.productID)
                    end
                end
            end
        end
    end

    -- K1 (Entscheid 10.11.): alle Käufe zusammen höchstens TotalShare des Golds (Standard 25 %); beste Gewinn/Gold zuerst;
    -- passt ein Vorschlag nicht ganz, wird seine Menge gekürzt (sonst fällt er weg)
    -- RK7 (anweisung-markt-reiter): EINE Rangfolge für alle Wege = Gold je Tag je 1g Einsatz (Gewinn/Einsatz ÷ Tage bis Verkauf)
    -- × Sicherheit (Trefferquote des Wegs aus dem Kern, MA2). Ohne Einsatz (eigene Ware) zuerst. Lernt der Weg noch (zu wenige
    -- Fälle), gilt die Freigabe-Schwelle als vorsichtige Annahme. Tage: r.days (falls bekannt), sonst 1 (Kaufmenge = 1 Tag Absatz).
    local safeCache = {}
    local function ratio(r)
        if (r.capital or 0) <= 0 then return math.huge end
        r.rank = self:RankScore(r, safeCache)
        return r.rank
    end
    for _, r in ipairs(out) do ratio(r) end
    table.sort(out, function(a, b)
        local ra, rb = ratio(a), ratio(b)
        if ra ~= rb then return ra > rb end
        return a.gold > b.gold
    end)
    local res, used = {}, 0
    local totalCap = money * self:TotalShare()
    for _, r in ipairs(out) do
        if #res >= (max or 10) then break end
        if r.capital <= 0 or used + r.capital <= totalCap then
            used = used + r.capital
            table.insert(res, r)
        elseif r.price and r.price > 0 and r.qty and r.retext then
            local q = math.floor((totalCap - used) / r.price)
            if q >= 1 and q < r.qty then
                r.qty, r.capital = q, r.price * q
                r.gold = math.floor((r.unitGold or 0) * q)
                r.text = r.retext(q)
                if r.gold > 0 then
                    used = used + r.capital
                    table.insert(res, r)
                end
            end
        end
    end
    table.sort(res, function(a, b) return a.gold > b.gold end)
    -- Tipp ganz unten: wer einen Herstellungsberuf hat, aber ProfessionSentinel nicht, erfährt davon (ausblendbar)
    local st = A.db and A.db.settings
    if not hasPS and st and not st.psHintHidden and A.Crafting and A.Crafting.HasCraftProfession then
        local okH, has = A:PCall(A.Crafting.HasCraftProfession, A.Crafting)
        if okH and has then
            table.insert(res, { key = "pshint", kind = "pshint", gold = 0, capital = 0, tip = true,
                text = L["ProfessionSentinel zeigt hier auch, was sich herzustellen lohnt - mit fehlenden Rezepten, Händlern und Drops, Schritt für Schritt (CurseForge, Discord)."],
                where = "" })
        end
    end
    return res, used, money
end
