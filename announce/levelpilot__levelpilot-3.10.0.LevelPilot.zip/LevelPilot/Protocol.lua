-- LevelPilot - Fehler-Protokoll fuer Tester
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Schreibt beim normalen Spielen automatisch mit, was auffaellt – ohne dass der Spieler etwas tun muss:
-- * Lua-Fehler von LevelPilot (eigene Fehlermeldungen, Fehler im Spiel, blockierte Aktionen)
-- * Zone falsch erkannt (LevelPilot-Karte <> Zonenname des Spiels) oder Position unbekannt
-- * Planung in der falschen Zone (Fokus woanders, obwohl hier Aufgaben warten)
-- * Navigation: kein Weg gefunden, Spieler kommt dem Ziel minutenlang nicht naeher
-- * Schritt dauert sehr lange, Tod (mit Ort und Schritt), langsame Planung, keine Route
-- * Sitzungen: Ein- und Ausloggen, Pause dazwischen, Speicherbedarf
-- Alles bleibt lokal in der Speicherdatei. /lp protokoll zeigt den Text zum Kopieren
-- (nur dann verlaesst er den Computer – wenn der Spieler ihn selbst weitergibt).

local _, LP = ...
local L = LP.L
local Pr = {}
LP:RegisterModule("Protocol", Pr)

local MAX_ENTRIES = 300
local MAX_SESSIONS = 40
local ZONE_CHECK = 5          -- Sekunden
local STUCK_SECS = 240        -- aktive Sekunden ohne Annaeherung ans Ziel
local STUCK_AREA = 400        -- Yards: so nah am Questziel gilt man als im Questgebiet
local STILL_YARDS = 5         -- weniger Bewegung gilt als Stillstehen
local STILL_SECS = 60         -- so lange stillstehen: kein "kommt nicht naeher"
local STUCK_GAIN = 15         -- Yards, die als Annaeherung zaehlen
local NOPATH_SECS = 20
local STEP_LONG = 1500        -- aktive Sekunden fuer einen Schritt (25 min)
local SLOW_MS = 300           -- Planung langsamer als das wird notiert

-- Arten: Code (stabil, fuer die Auswertung) und ob es ein Problem ist
Pr.KINDS = {
    error   = { code = "FEHLER",  problem = true },
    blocked = { code = "BLOCK",   problem = true },
    zone    = { code = "ZONE",    problem = true },
    nopos   = { code = "POSITION", problem = true },
    focus   = { code = "FOKUS",   problem = true },
    nopath  = { code = "KEINWEG", problem = true },
    stuck   = { code = "FEST",    problem = true },
    step    = { code = "SCHRITT", problem = true },
    noroute = { code = "ROUTE",   problem = true },
    slow    = { code = "LANGSAM", problem = true },
    death   = { code = "TOD",     problem = false },
    session = { code = "SITZUNG", problem = false },
    journey = { code = "REISE",   problem = false },     -- virtuelle Reise (keine echte Sitzung)
    sandbox = { code = "SANDBOX", problem = true },      -- Reise hat echte Daten veraendert
}

local pending = {}            -- Eintraege vor dem Laden der Speicherdatei
local index = {}              -- [Art .. Text] = Eintrag

local function Store()
    if not LP.db or not LevelPilotDB then return nil end
    local s = LevelPilotDB.protocolLog
    if type(s) ~= "table" then
        s = { entries = {}, sessions = {}, seen = 0 }
        LevelPilotDB.protocolLog = s
    end
    s.entries = s.entries or {}
    s.sessions = s.sessions or {}
    return s
end

local function Round(v) return v and math.floor(v * 10 + 0.5) / 10 or nil end

local function Ctx()
    local c = { v = LP.version, l = UnitLevel and UnitLevel("player") or nil }
    local ok, _, _, _, map, x, y = pcall(LP.Geo.Player, LP.Geo)
    if ok and map then c.m, c.x, c.y = map, Round(x), Round(y) end
    if GetRealZoneText then c.z = GetRealZoneText() end
    if GetSubZoneText then local s = GetSubZoneText() if s and s ~= "" then c.s = s end end
    local step = LP.Engine and LP.Engine.Current and LP.Engine:Current()
    if step then c.st = step.key end
    return c
end

-- Eintrag hinzufuegen; gleiche Art und gleicher Text werden zusammengefasst (Anzahl, letzter Zeitpunkt)
function Pr:Add(kind, text, extra)
    if LP.db and LP.db.protocol == false and kind ~= "session" then return end
    text = tostring(text or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):sub(1, 400)
    local s = Store()
    if not s then
        if #pending < 50 then pending[#pending + 1] = { kind, text, extra } end
        return
    end
    local key = kind .. "\1" .. text
    local now = time()
    local e = index[key]
    if e then
        e.n = (e.n or 1) + 1
        e.last = now
        e.c = Ctx()
        if extra then e.x = tostring(extra):sub(1, 600) end
        return e
    end
    e = { k = kind, msg = text, t = now, last = now, n = 1, c = Ctx(), x = extra and tostring(extra):sub(1, 600) or nil }
    table.insert(s.entries, e)
    index[key] = e
    while #s.entries > MAX_ENTRIES do
        local old = table.remove(s.entries, 1)
        index[old.k .. "\1" .. old.msg] = nil
    end
    LP:Fire("PROTOCOL_CHANGED")
    return e
end

-- wie Add, aber als Textschluessel + Werte: das Protokoll zeigt den Eintrag spaeter in der jeweils
-- eingestellten Sprache (nicht in der Sprache, die beim Eintragen eingestellt war)
function Pr:AddL(kind, key, ...)
    local args = { ... }
    for i = 1, select("#", ...) do args[i] = tostring(args[i]) end
    local e = self:Add(kind, key .. "\2" .. table.concat(args, "\2"))
    if e then e.key, e.args = key, args end
    return e
end

-- Text eines Eintrags in der aktuellen Sprache
function Pr:EntryText(e)
    if e.key then
        local ok, t = pcall(L, e.key, unpack(e.args or {}))
        if ok and t then return t end
    end
    return (tostring(e.msg or ""):gsub("\2", " "))
end

function Pr:Entries() local s = Store() return s and s.entries or {} end

-- Anzahl der Probleme (ohne Tod und Sitzungen); seit = nur neue seit dem letzten Anzeigen
function Pr:Count(sinceSeen)
    local s = Store()
    if not s then return 0 end
    local n = 0
    for _, e in ipairs(s.entries) do
        local k = self.KINDS[e.k]
        if k and k.problem and (not sinceSeen or (e.last or e.t) > (s.seen or 0)) then n = n + 1 end
    end
    return n
end

function Pr:Clear()
    local s = Store()
    if not s then return end
    wipe(s.entries)
    wipe(index)
    s.seen = time()
    LP:Print(L["Fehler-Protokoll geleert."])
    LP:Fire("PROTOCOL_CHANGED")
end

------------------------------------------------------------------------
-- Pruefungen
------------------------------------------------------------------------
local function Active()
    if LP.Session and LP.Session.Clock then return LP.Session:Clock() end
    return GetTime()
end
local function AFK() return LP.Session and LP.Session.IsAFK and LP.Session:IsAFK() end
local function Busy()
    if UnitOnTaxi and UnitOnTaxi("player") then return true end
    if UnitIsDeadOrGhost and UnitIsDeadOrGhost("player") then return true end
    local inInst = IsInInstance and IsInInstance()
    return inInst and true or false
end

-- uebergeordnete Zone einer (Unter-)Karte, z. B. Hoehle oder Stadtteil -> Zone
local function ZoneOf(map)
    if not (map and C_Map and C_Map.GetMapInfo) then return nil end
    local info = C_Map.GetMapInfo(map)
    for _ = 1, 8 do
        if not info or not info.mapType or info.mapType <= 3 or not info.parentMapID or info.parentMapID == 0 then break end
        info = C_Map.GetMapInfo(info.parentMapID)
    end
    return info
end
Pr.ZoneOf = ZoneOf

local zoneBad, posBad = 0, 0
function Pr:CheckZone()
    if LP.Virtual and LP.Virtual.active then return end   -- virtuelle Reise: eigene Pruefungen
    if Busy() then zoneBad, posBad = 0, 0 return end
    local _, _, _, map = LP.Geo:Player()
    if not map then
        posBad = posBad + 1
        if posBad == 6 then
            self:AddL("nopos", "Position unbekannt (Karte des Spiels: %s)", tostring(C_Map.GetBestMapForUnit("player")))
        end
        return
    end
    posBad = 0
    local real = GetRealZoneText and GetRealZoneText()
    local info = ZoneOf(map)
    if not real or real == "" or not info or not info.name then return end
    if not LP:SameZoneName(info.name, real) then
        zoneBad = zoneBad + 1
        if zoneBad == 2 then
            self:AddL("zone", "LevelPilot erkennt %s (%d), das Spiel zeigt %s", info.name, info.mapID or map, real)
        end
    else
        zoneBad = 0
    end
end

local lastFocus = 0
function Pr:CheckFocus()
    if LP.Virtual and LP.Virtual.active then return end   -- virtuelle Reise: eigene Pruefungen
    if Busy() or GetTime() - lastFocus < 30 then return end
    lastFocus = GetTime()
    local P = LP.Planner
    local _, _, _, map = LP.Geo:Player()
    local info = ZoneOf(map)
    if not (P and P.focus and info and info.mapID) or P.focus == info.mapID then return end
    local here = 0
    for _, t in ipairs(P.lastTasks or {}) do
        if t.map == info.mapID then here = here + 1 end
    end
    if here > 0 then
        self:AddL("focus", "Planung in %s, obwohl %d Aufgabe(n) in %s warten", LP.Geo:MapName(P.focus), here, info.name or tostring(info.mapID))
    end
end

local nav = { key = nil, best = nil, bestT = 0, noPathT = nil, logged = {} }
function Pr:CheckNav()
    if LP.Virtual and LP.Virtual.active then return end   -- virtuelle Reise: eigene Pruefungen
    local N = LP.Nav
    local tgt = N and N.target
    if not tgt or Busy() or AFK() then nav.noPathT = nil return end
    local pi, pn, pw = LP.Geo:Player()
    if not pi then return end
    local now = Active()
    if nav.key ~= tgt.key then
        nav.key, nav.best, nav.bestT, nav.noPathT = tgt.key, nil, now, nil
    end
    -- bewegt sich der Spieler ueberhaupt? Wer Bewegungstasten drueckt, laeuft (auch gegen eine Wand);
    -- wer nur steht - Testen, Handeln, im Chat -, haengt nicht fest
    local pressing = (IsPlayerMoving and IsPlayerMoving()) or (GetUnitSpeed and (GetUnitSpeed("player") or 0) > 0)
    if pressing or not nav.lastN or nav.lastI ~= pi or LP.Geo:Dist(nav.lastN, nav.lastW, pn, pw) > STILL_YARDS then
        nav.lastI, nav.lastN, nav.lastW, nav.lastMove = pi, pn, pw, now
    end
    -- kein Weg
    if N.hasPath == false then
        nav.noPathT = nav.noPathT or now
        if now - nav.noPathT >= NOPATH_SECS and not nav.logged["np" .. tostring(tgt.key)] then
            nav.logged["np" .. tostring(tgt.key)] = true
            local e = self:AddL("nopath", "Kein Weg zu „%s“ (%s)", tgt.label or tostring(tgt.key), tostring(tgt.key))
            if e and N.pathError then e.x = tostring(N.pathError):sub(1, 600) end
        end
    else
        nav.noPathT = nil
    end
    -- kommt nicht naeher
    if tgt.inst ~= pi then return end
    local d = LP.Geo:Dist(pn, pw, tgt.n, tgt.w)
    if not nav.best or d < nav.best - STUCK_GAIN then nav.best, nav.bestT = d, now return end
    -- steht seit einer Minute still: kein Haengen
    if now - (nav.lastMove or now) > STILL_SECS then nav.bestT = now return end
    -- im Questgebiet unterwegs (Gegner jagen, Gegenstaende suchen): kein Haengen
    if tostring(tgt.key):find("^COMPLETE:") and d < STUCK_AREA then nav.bestT = now return end
    if d > 40 and now - nav.bestT >= STUCK_SECS and not nav.logged["st" .. tostring(tgt.key)] then
        nav.logged["st" .. tostring(tgt.key)] = true
        self:AddL("stuck", "Seit %d min nicht näher an „%s“ (noch %d Yards, Weg: %s)", math.floor((now - nav.bestT) / 60),
            tgt.label or tostring(tgt.key), math.floor(d), tostring(N.pathKind or "?"))
    end
end

local stepT = { key = nil, t = 0, logged = {} }
function Pr:CheckStep()
    if LP.Virtual and LP.Virtual.active then return end   -- virtuelle Reise: eigene Pruefungen
    local step = LP.Engine and LP.Engine:Current()
    local now = Active()
    if not step then
        local level = UnitLevel and UnitLevel("player") or 1
        if level < 60 and not Busy() and LP.Planner and LP.Planner.state and LP.Planner.state ~= "instance" then
            stepT.none = stepT.none or now
            if now - stepT.none > 60 and not stepT.logged.none then
                stepT.logged.none = true
                self:AddL("noroute", "Keine Route auf Level %d (Zustand %s)", level, tostring(LP.Planner.state))
            end
        end
        return
    end
    stepT.none = nil
    if stepT.key ~= step.key then stepT.key, stepT.t = step.key, now return end
    if now - stepT.t >= STEP_LONG and not stepT.logged[step.key] then
        stepT.logged[step.key] = true
        local text = LP.UI and LP.UI.StepText and select(2, pcall(LP.UI.StepText, LP.UI, step, false)) or step.q
        self:AddL("step", "Schritt seit %d min aktiv: %s", math.floor((now - stepT.t) / 60), (tostring(text or step.key):gsub("\n", " / ")))
    end
end

-- Planung messen
local slowMax = 0
local function WrapReplan()
    local P = LP.Planner
    if not P or P._protoWrapped or not debugprofilestop then return end
    P._protoWrapped = true
    local orig = P.Replan
    P.Replan = function(self, ...)
        local t0 = debugprofilestop()
        local r = { orig(self, ...) }
        local ms = debugprofilestop() - t0
        if ms > SLOW_MS and ms > slowMax * 1.25 then
            slowMax = ms
            local s = Store()
            if s then
                for i = #s.entries, 1, -1 do
                    if s.entries[i].k == "slow" then index["slow\1" .. s.entries[i].msg] = nil table.remove(s.entries, i) end
                end
            end
            Pr:Add("slow", L("Planung dauerte bis zu %d ms", math.floor(ms)))
        end
        return unpack(r)
    end
end

-- Fehler abfangen (eigene Meldungen sofort, auch vor dem Laden der Speicherdatei)
local origError = LP.Error
LP.Error = function(self, where, err)
    pcall(Pr.Add, Pr, "error", tostring(where) .. ": " .. tostring(err), debugstack and debugstack(2, 6, 0) or nil)
    return origError(self, where, err)
end

local function HookErrorHandler()
    if not (geterrorhandler and seterrorhandler) then return end
    local prev = geterrorhandler()
    seterrorhandler(function(msg, ...)
        if type(msg) == "string" and msg:find("LevelPilot", 1, true) then
            pcall(Pr.Add, Pr, "error", msg, debugstack and debugstack(2, 8, 0) or nil)
        end
        if prev then return prev(msg, ...) end
    end)
end

------------------------------------------------------------------------
-- Sitzungen
------------------------------------------------------------------------
local memPeak = 0
local function Memory()
    local upd = UpdateAddOnMemoryUsage
    local get = (C_AddOns and C_AddOns.GetAddOnMemoryUsage) or GetAddOnMemoryUsage
    if not (upd and get) then return end
    pcall(upd)
    local ok, kb = pcall(get, "LevelPilot")
    if ok and kb and kb > memPeak then memPeak = kb end
end

local function StartSession()
    local s = Store()
    if not s then return end
    local _, class = UnitClass("player")
    local _, race = UnitRace("player")
    local sess = { t = time(), l = UnitLevel("player"), c = class, r = race, v = LP.version }
    local lastOut = LP.char and LP.char.lastLogout
    if lastOut then sess.gap = time() - lastOut end
    table.insert(s.sessions, sess)
    while #s.sessions > MAX_SESSIONS do table.remove(s.sessions, 1) end
    Pr.session = sess
end

local function EndSession()
    local sess = Pr.session
    if not sess then return end
    sess.e = time()
    sess.le = UnitLevel("player")
    sess.a = math.floor(Active())
    sess.mem = memPeak > 0 and math.floor(memPeak) or nil
    if LP.char then LP.char.lastLogout = time() end
end

------------------------------------------------------------------------
-- Text zum Kopieren
------------------------------------------------------------------------
local function Plain(s) return (tostring(s or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", "")) end
local function When(t) return t and date("%d.%m. %H:%M", t) or "?" end
local function Dur(sec)
    sec = math.floor(sec or 0)
    if sec >= 3600 then return string.format("%dh %02dmin", math.floor(sec / 3600), math.floor(sec / 60) % 60) end
    return string.format("%dmin", math.floor(sec / 60))
end

function Pr:Text()
    local s = Store() or { entries = {}, sessions = {} }
    local out = {}
    local function add(l) out[#out + 1] = Plain(l) end
    local build = GetBuildInfo and select(1, GetBuildInfo()) or "?"
    local _, class = UnitClass("player")
    local _, race = UnitRace("player")
    add("LevelPilot-Protokoll v" .. LP.version .. " · " .. date("%d.%m.%Y %H:%M"))
    add("Client " .. tostring(GetLocale and GetLocale()) .. " " .. tostring(build) .. " · Sprache " .. tostring(LP.Language and LP:Language())
        .. " · " .. (LP.API and LP.API.modern and "modern" or "classic"))
    add("Charakter L" .. tostring(UnitLevel("player")) .. " " .. tostring(race) .. " " .. tostring(class) .. " " .. tostring(LP.PlayerFaction and LP:PlayerFaction()))
    add("Datenpaket: " .. tostring(LP.QuestDB and LP.QuestDB.packInfo))
    -- Sitzungen
    -- laufende Sitzung mit aktuellen Werten
    if Pr.session and not Pr.session.e then
        Pr.session.a = math.floor(Active())
        Pr.session.le = UnitLevel("player")
    end
    local total = 0
    for _, se in ipairs(s.sessions) do total = total + (se.a or 0) end
    add(string.format("Sitzungen: %d · aktiv gespielt %s · Speicher max %s", #s.sessions, Dur(total),
        memPeak > 0 and string.format("%.1f MB", memPeak / 1024) or "?"))
    for i = math.max(1, #s.sessions - 9), #s.sessions do
        local se = s.sessions[i]
        add(string.format("  %s L%s»%s %s %s%s", When(se.t), tostring(se.l), tostring(se.le or "…"), tostring(se.c), Dur(se.a or 0),
            se.gap and (" · Pause " .. Dur(se.gap)) or ""))
    end
    -- geaenderte Einstellungen
    if LP.DEFAULTS then
        local ch = {}
        for k, v in pairs(LP.DEFAULTS) do
            if type(v) ~= "table" and not k:find("Pos$") and LP.db[k] ~= v then ch[#ch + 1] = k .. "=" .. tostring(LP.db[k]) end
        end
        table.sort(ch)
        add("Einstellungen geändert: " .. (#ch > 0 and table.concat(ch, ", ") or "keine") .. (LP.db.ownSettings and " (pro Charakter)" or ""))
    end
    -- Diagnose
    add("")
    add("== Diagnose")
    if LP.Planner and LP.Planner.DiagLines then
        local ok, lines = pcall(LP.Planner.DiagLines, LP.Planner)
        if ok then for _, l in ipairs(lines) do add("  " .. l) end end
    end
    -- Eintraege
    add("")
    add(string.format("== Einträge (%d, neueste zuerst)", #s.entries))
    local sorted = {}
    for _, e in ipairs(s.entries) do sorted[#sorted + 1] = e end
    table.sort(sorted, function(a, b) return (a.last or a.t or 0) > (b.last or b.t or 0) end)
    for _, e in ipairs(sorted) do
        local k = self.KINDS[e.k] or { code = e.k }
        local c = e.c or {}
        local where = c.m and string.format("%s(%d) %.1f,%.1f", LP.Geo:MapName(c.m) or "?", c.m, c.x or 0, c.y or 0) or "?"
        add(string.format("[%s] %s%s L%s %s | %s%s", When(e.last or e.t), k.code, (e.n or 1) > 1 and (" ×" .. e.n) or "",
            tostring(c.l or "?"), where, Pr:EntryText(e), c.z and (" | Spiel: " .. c.z .. (c.s and (" / " .. c.s) or "")) or ""))
        if c.st then add("      Schritt " .. tostring(c.st) .. (c.v and c.v ~= LP.version and (" · v" .. c.v) or "")) end
        if e.x then
            for line in tostring(e.x):gmatch("[^\n]+") do add("      " .. line) end
        end
    end
    return table.concat(out, "\n")
end

function Pr:Show()
    local s = Store()
    if s then s.seen = time() end
    local n = self:Count()
    LP.Backup:ShowText(L["Fehler-Protokoll"],
        L("%d Auffälligkeit(en). Strg+A, dann Strg+C drücken und den Text an GoldSentinel schicken (Discord #levelpilot). Es stehen keine Namen und keine Zugangsdaten darin.", n),
        self:Text())
    LP:Fire("PROTOCOL_CHANGED")
end

------------------------------------------------------------------------
-- Init
------------------------------------------------------------------------
-- Eintraege aus 3.4-3.6 (ohne Schluessel, in der damals eingestellten Sprache gespeichert):
-- erledigte Zonen-Meldungen entfernen, die uebrigen in Schluessel umwandeln (Anzeige in der aktuellen Sprache)
function Pr.Migrate(e)
    if e.key or type(e.msg) ~= "string" or e.msg:find("\2") then return end
    local m, c = e.msg, e.c or {}
    if e.k == "zone" or (e.k == "error" and m:find("%(%d+%), ")) then
        -- "... Das Brachland (1413), ... Brachland": gleiche Zone nach heutigem Vergleich -> erledigt
        local pre, id = m:match("^(.-) %((%d+)%), ")
        local real = c.z or m:match("([^,]+)$")
        if pre and real then
            real = real:gsub("^%s+", "")
            local tail = pre:match("(%S+%s*%S*)$") or pre
            if pre:find(real, 1, true) or LP:SameZoneName(tail, real) then return "drop" end
        end
        return
    end
    local nums = {}
    for d in m:gmatch("%d+") do nums[#nums + 1] = d end
    if e.k == "stuck" and #nums >= 2 and tostring(c.st or ""):find("^COMPLETE:") and tonumber(nums[#nums]) < STUCK_AREA then
        return "drop"                      -- im Questgebiet unterwegs: wird seit 3.8 nicht mehr gemeldet
    elseif e.k == "stuck" and #nums >= 2 then
        e.key = "Seit %d min nicht näher an „%s“ (noch %d Yards, Weg: %s)"
        e.args = { nums[1], tostring(c.st or "?"), nums[#nums], m:match("(%a+)%)%s*$") or "?" }
    elseif e.k == "session" and m:find("L%d+") and #nums >= 3 then
        e.key = "Virtuelle Reise L%d–%d: %d Auffälligkeit(en)"
        e.args = { nums[1], nums[2], nums[3] }
    else
        return
    end
    e.msg = e.key .. "\2" .. table.concat(e.args, "\2")
end

function Pr:Init()
    local s = Store()
    if s then
        wipe(index)
        for i = #s.entries, 1, -1 do
            local e = s.entries[i]
            local m = tostring(e.msg or "")
            if m:find("^Sprachpaket ") or m:find("^Namen %a%a%a%a: ") or Pr.Migrate(e) == "drop" then table.remove(s.entries, i) end
        end
        for _, e in ipairs(s.entries) do index[e.k .. "\1" .. e.msg] = e end
        for _, p in ipairs(pending) do self:Add(p[1], p[2], p[3]) end
        wipe(pending)
    end
    HookErrorHandler()
    StartSession()
    WrapReplan()
    LP:On("PLAYER_LOGOUT", function() pcall(EndSession) end)
    LP:On("PLAYER_DEAD", function()
        local step = LP.Engine and LP.Engine:Current()
        local tgt = LP.Nav and LP.Nav.target
        pcall(Pr.AddL, Pr, "death", "Tod bei „%s“", tostring(step and (step.q or step.key) or "–"))
    end)
    local function blocked(_, addon, func)
        if addon == "LevelPilot" then pcall(Pr.AddL, Pr, "blocked", "Aktion blockiert: %s", tostring(func)) end
    end
    LP:On("ADDON_ACTION_BLOCKED", blocked)
    LP:On("ADDON_ACTION_FORBIDDEN", blocked)
    C_Timer.NewTicker(ZONE_CHECK, function()
        pcall(Pr.CheckZone, Pr)
        pcall(Pr.CheckFocus, Pr)
        pcall(Pr.CheckNav, Pr)
        pcall(Pr.CheckStep, Pr)
    end)
    C_Timer.NewTicker(300, function() pcall(Memory) end)
    C_Timer.After(30, function()
        pcall(Memory)
        local n = Pr:Count(true)
        if n > 0 and LP.db.protocol ~= false then
            LP:Print(L("Das Fehler-Protokoll hat %d neue Auffälligkeit(en). /lp protokoll zeigt den Text zum Kopieren – bitte an GoldSentinel schicken.", n))
        end
    end)
end
