﻿# Gemeinsame Hilfen fuer die LevelPilot-Sicherung
$ErrorActionPreference = 'Stop'
$CfgDir  = Join-Path $env:APPDATA 'LevelPilot'
$CfgFile = Join-Path $CfgDir 'sicherung.cfg'
$Keep    = 30

function Get-DefaultTarget {
    if ($env:OneDrive -and (Test-Path $env:OneDrive)) { return (Join-Path $env:OneDrive 'LevelPilot-Sicherung') }
    return (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'LevelPilot-Sicherung')
}

function Get-Target {
    if (Test-Path $CfgFile) {
        $line = Get-Content $CfgFile -Encoding UTF8 | Where-Object { $_ -like 'Ziel=*' } | Select-Object -First 1
        if ($line) { return $line.Substring(5) }
    }
    return (Get-DefaultTarget)
}

function Set-Target([string]$path) {
    New-Item -ItemType Directory -Force -Path $CfgDir | Out-Null
    Set-Content -Path $CfgFile -Value ("Ziel=" + $path) -Encoding UTF8
}

# WoW-Ordner: vom Tools-Ordner nach oben bis zum Ordner mit "WTF"
function Get-WtfDir {
    $dir = Get-Item $PSScriptRoot
    while ($dir -ne $null) {
        $wtf = Join-Path $dir.FullName 'WTF'
        if (Test-Path $wtf) { return $wtf }
        $dir = $dir.Parent
    }
    throw "Der WoW-Ordner (mit WTF) wurde nicht gefunden. Liegt LevelPilot in Interface\AddOns?"
}

# alle LevelPilot-Datendateien (Account und Charaktere)
function Get-DataFiles([string]$wtf) {
    Get-ChildItem -Path $wtf -Recurse -File -Filter 'LevelPilot.lua' -ErrorAction SilentlyContinue |
        Where-Object { $_.DirectoryName -match '\\SavedVariables$' }
}

function Get-StateHash($files) {
    $parts = foreach ($f in ($files | Sort-Object FullName)) { (Get-FileHash -Algorithm SHA256 -Path $f.FullName).Hash + $f.FullName }
    $bytes = [Text.Encoding]::UTF8.GetBytes(($parts -join '|'))
    $sha = [Security.Cryptography.SHA256]::Create()
    return ([BitConverter]::ToString($sha.ComputeHash($bytes)) -replace '-', '')
}

# Sicherung anlegen; liefert den Dateinamen oder $null (nichts geaendert)
function New-LPBackup([switch]$Force) {
    $wtf = Get-WtfDir
    $target = Get-Target
    New-Item -ItemType Directory -Force -Path $target | Out-Null
    $files = @(Get-DataFiles $wtf)
    if ($files.Count -eq 0) { throw "Noch keine LevelPilot-Daten gefunden (erst einmal mit LevelPilot spielen und ausloggen)." }
    $hash = Get-StateHash $files
    $stamp = Join-Path $target 'letzter_stand.txt'
    if (-not $Force -and (Test-Path $stamp) -and ((Get-Content $stamp -Raw).Trim() -eq $hash)) { return $null }
    $tmp = Join-Path $env:TEMP ('LevelPilot_' + [Guid]::NewGuid().ToString('N'))
    try {
        foreach ($f in $files) {
            $rel = $f.FullName.Substring($wtf.Length).TrimStart('\')
            $dst = Join-Path $tmp $rel
            New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
            Copy-Item -LiteralPath $f.FullName -Destination $dst
        }
        $name = 'LevelPilot_' + (Get-Date -Format 'yyyy-MM-dd_HH-mm-ss') + '.zip'
        $zip = Join-Path $target $name
        Compress-Archive -Path (Join-Path $tmp '*') -DestinationPath $zip -Force
        Set-Content -Path $stamp -Value $hash
    } finally {
        if (Test-Path $tmp) { Remove-Item -LiteralPath $tmp -Recurse -Force }
    }
    # nur die aeltesten eigenen Sicherungen entfernen, die neuesten $Keep bleiben
    Get-ChildItem -Path $target -Filter 'LevelPilot_*.zip' | Sort-Object Name -Descending |
        Select-Object -Skip $Keep | Remove-Item -Force
    return $name
}

function Test-WowRunning {
    return [bool](Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match '^(Wow|WowClassic|WoW|World of Warcraft)' })
}
