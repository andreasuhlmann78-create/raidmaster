﻿# LevelPilot - Sicherung zurueckspielen
. (Join-Path $PSScriptRoot 'LevelPilot_Sicherung_Basis.ps1')
try {
    if (Test-WowRunning) { throw "World of Warcraft läuft noch. Bitte zuerst das Spiel beenden." }
    $wtf = Get-WtfDir
    $target = Get-Target
    $list = @(Get-ChildItem -Path $target -Filter 'LevelPilot_*.zip' -ErrorAction SilentlyContinue | Sort-Object Name -Descending)
    if ($list.Count -eq 0) { throw "Im Sicherungsordner $target gibt es noch keine Sicherung." }
    Write-Host "Vorhandene Sicherungen (neueste zuerst):"
    for ($i = 0; $i -lt $list.Count; $i++) {
        Write-Host ("  {0,2}) {1}   {2:N0} KB" -f ($i + 1), $list[$i].Name, ($list[$i].Length / 1KB))
    }
    $pick = Read-Host "Nummer der Sicherung (Enter = neueste, 0 = abbrechen)"
    if ($pick -eq '0') { Write-Host "Abgebrochen."; exit 0 }
    $idx = 0
    if ($pick -ne '') { $idx = [int]$pick - 1 }
    if ($idx -lt 0 -or $idx -ge $list.Count) { throw "Ungültige Nummer." }
    # aktuellen Stand vorher sichern, damit nichts verloren geht
    $before = New-LPBackup -Force
    if ($before) { Write-Host "Aktueller Stand vorher gesichert: $before" -ForegroundColor Green }
    Expand-Archive -Path $list[$idx].FullName -DestinationPath $wtf -Force
    Write-Host ("Zurückgespielt: " + $list[$idx].Name) -ForegroundColor Green
    Write-Host "Beim nächsten Login ergänzt LevelPilot zusätzlich alles, was in der Sicherung im Charakter neuer ist."
} catch {
    Write-Host ("Fehler: " + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
