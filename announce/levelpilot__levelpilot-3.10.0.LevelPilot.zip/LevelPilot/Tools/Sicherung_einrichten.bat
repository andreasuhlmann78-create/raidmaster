@echo off
title LevelPilot - automatische Sicherung einrichten
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Sicherung_einrichten.ps1"
echo.
pause
