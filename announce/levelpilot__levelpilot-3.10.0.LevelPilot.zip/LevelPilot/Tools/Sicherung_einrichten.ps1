﻿# LevelPilot - automatische Sicherung einrichten (stuendlich, ohne Administratorrechte)
. (Join-Path $PSScriptRoot 'LevelPilot_Sicherung_Basis.ps1')
$TaskName = 'LevelPilot Sicherung'
try {
    $wtf = Get-WtfDir
    Write-Host "WoW-Daten gefunden: $wtf"
    $current = Get-Target
    Write-Host ""
    Write-Host "Sicherungsordner (Tipp: ein Ordner in OneDrive/Dropbox liegt zusätzlich ausserhalb des PCs)"
    $in = Read-Host "Ordner [Enter = $current]"
    if ($in -ne '') { $current = $in.Trim('"') }
    New-Item -ItemType Directory -Force -Path $current | Out-Null
    Set-Target $current
    $script = Join-Path $PSScriptRoot 'Sicherung.ps1'
    $arg = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $script + '" -Leise'
    $action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $arg
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Hours 1) -RepetitionDuration (New-TimeSpan -Days 3650)
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopIfGoingOnBatteries -AllowStartIfOnBatteries
    Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -Description 'Sichert die LevelPilot-Daten (nur wenn sich etwas geändert hat)' -Force | Out-Null
    Write-Host ""
    Write-Host "Eingerichtet: stündliche Sicherung nach $current" -ForegroundColor Green
    $name = New-LPBackup
    if ($name) { Write-Host "Erste Sicherung angelegt: $name" -ForegroundColor Green }
    Write-Host "Entfernen: in der Windows-Aufgabenplanung die Aufgabe '$TaskName' löschen."
} catch {
    Write-Host ("Fehler: " + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
