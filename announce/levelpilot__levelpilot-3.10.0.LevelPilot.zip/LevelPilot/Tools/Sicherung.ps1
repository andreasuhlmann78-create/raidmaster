﻿# LevelPilot - Sicherung der gesammelten Daten
# Kopiert alle LevelPilot-Datendateien (WTF\...\SavedVariables\LevelPilot.lua) als ZIP mit Datum
# in den Sicherungsordner. Neuer Stand nur, wenn sich etwas geaendert hat; die letzten 30 bleiben.
param([switch]$Leise)
. (Join-Path $PSScriptRoot 'LevelPilot_Sicherung_Basis.ps1')
try {
    $name = New-LPBackup
    if (-not $Leise) {
        if ($name) { Write-Host "Gesichert: $name" -ForegroundColor Green }
        else { Write-Host "Keine Änderungen seit der letzten Sicherung." -ForegroundColor Yellow }
        Write-Host ("Sicherungsordner: " + (Get-Target))
    }
} catch {
    if (-not $Leise) { Write-Host ("Fehler: " + $_.Exception.Message) -ForegroundColor Red }
    exit 1
}
