@echo off
title LevelPilot - Sicherung
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Sicherung.ps1"
echo.
pause
