# Daten sichern

Die gesammelten LevelPilot-Daten (Quests, Wege, Händler, Flugpunkte) sind wertvoll. Sie sind
dreifach geschützt:

1. **Zweitkopie im Charakter (automatisch, im Addon):** Beim Ausloggen legt LevelPilot alle Daten
   zusätzlich in der Charakter-Datei ab. Fehlen die Accountdaten beim nächsten Start oder sind sie
   beschädigt, stellt LevelPilot sie automatisch wieder her. Eine Kopie wird nie durch einen
   deutlich kleineren Stand ersetzt.
2. **Sicherung auf dem PC (diese Skripte, Windows 10/11, ohne Zusatzprogramme):**
   - `Sicherung_einrichten.bat` – einmal doppelklicken: Ordner wählen (Tipp: ein Ordner in
     OneDrive/Dropbox liegt zusätzlich ausserhalb des PCs) und stündliche Sicherung einrichten.
     Keine Administratorrechte nötig.
   - `Sicherung.bat` – sofort sichern. Ein neuer Stand entsteht nur, wenn sich etwas geändert hat;
     die letzten 30 Stände bleiben erhalten.
   - `Wiederherstellen.bat` – einen Stand auswählen und zurückspielen (WoW vorher beenden). Der
     aktuelle Stand wird vorher automatisch gesichert, damit nichts verloren geht.
   Die Einstellung (Sicherungsordner) liegt in `%APPDATA%\LevelPilot` und bleibt bei Updates
   des Addons erhalten.
3. **Sichern als Text (im Spiel):** Zentrale → Daten → „Daten sichern“ zeigt alle Daten als Text
   (Strg+A, Strg+C, in eine Datei einfügen). „Daten laden“ fügt sie wieder ein – auch auf einem
   anderen PC. Beim Laden wird nur ergänzt, nie gelöscht.

Gesammelte Daten lassen sich im Addon nicht löschen. Einzelne Quests kann man überspringen –
das ändert nur die eigene Route.

# Startdatenbank erstellen

Die Startdatenbank (`Data\Seed.lua`) ist der Kern von LevelPilot: Quests, Wege, Händler und
Flugpunkte, die LevelPilot-Spieler selbst beobachtet haben – inklusive der neuen
WoW-Forever-Quests. Sie wird mit jeder neuen LevelPilot-Version ausgeliefert.

## 1. Daten sammeln
Du und deine Testspieler spielt ganz normal mit LevelPilot. Wichtig:
- In der Zentrale unter **Einstellungen** müssen „Quests aufzeichnen" und
  „Gelaufene Wege aufzeichnen" an sein (Standard).
- Nach dem Spielen das Spiel beenden oder `/reload` eingeben – erst dann schreibt WoW die Datei.

## 2. Dateien einsammeln
Jeder Testspieler schickt dir seine Datei:

`World of Warcraft\_<Version>_\WTF\Account\<KONTONAME>\SavedVariables\LevelPilot.lua`

Benenne sie beim Speichern um (z. B. `Anna.lua`, `Ben.lua`), damit sie sich nicht überschreiben.

**Hol dir das Einverständnis deiner Testspieler**, dass ihre Aufzeichnungen in LevelPilot
einfliessen und damit veröffentlicht werden. Ein Vorschlag für den Text:

> „Ich bin einverstanden, dass meine LevelPilot-Aufzeichnungen (Quests, Wege, Händler)
> in die LevelPilot-Startdatenbank übernommen und mit dem Addon veröffentlicht werden.
> Die Rechte an der zusammengeführten Datenbank liegen bei GoldSentinel."

## 3. Zusammenführen
Voraussetzung: [Python](https://www.python.org) ist installiert (bei der Installation
„Add Python to PATH" anhaken).

Am einfachsten: Alle `.lua`-Dateien gleichzeitig auf **`Startdatenbank_erstellen.bat`**
ziehen. Die bisherige Startdatenbank wird automatisch übernommen und ergänzt.

Oder in der Eingabeaufforderung im Ordner `Tools`:

```
python lp_sammeln.py Anna.lua Ben.lua --seed ..\Data\Seed.lua
```

Optionen:
- `--min-wege 2` – Wegstücke nur übernehmen, wenn mindestens 2 Spieler sie gelaufen sind
  (sicherer, sobald genug Daten da sind)
- `--min-quest 2` – Quests nur übernehmen, wenn mindestens 2 Spieler sie gesehen haben
- `--out Pfad` – andere Ausgabedatei

## Was übernommen wird – und was nicht
- **Ja:** selbst angenommene Quests (Name, Level, Fraktion, Questgeber, Abgabe, Zielorte),
  selbst gelaufene Wege, besuchte Händler/Reparatur/Gasthäuser, Flugpunkte.
- **Nein:** Daten, die ein Spieler von anderen empfangen hat, Daten aus „LevelPilot Data"
  oder QuestieDB, Spielernamen und alle Einstellungen.

Mehrere Beobachtungen derselben Quest werden zusammengefasst (der häufigste Ort gewinnt,
Ausreisser fallen weg). So wird die Startdatenbank mit jeder Runde genauer.
