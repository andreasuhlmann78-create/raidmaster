#!/usr/bin/env python3
"""LevelPilot - Sammelwerkzeug

Fuehrt die Aufzeichnungen mehrerer LevelPilot-Spieler zur Startdatenbank zusammen.

Eingabe:  eine oder mehrere Speicherdateien "LevelPilot.lua"
          (WTF\\Account\\<Kontoname>\\SavedVariables\\LevelPilot.lua)
          optional die bisherige Startdatenbank (Data\\Seed.lua), damit Daten erhalten bleiben
Ausgabe:  Data\\Seed.lua (eigene Startdatenbank von LevelPilot)

Uebernommen werden:
  - selbst beobachtete Daten (Quests ohne "net"-Kennung, selbst gelaufene Wege,
    besuchte Haendler und Flugpunkte)
  - von anderen Spielern empfangene Daten NUR, wenn deren Urheber sie in LevelPilot fuer
    die Startdatenbank freigegeben haben (Kennung "c"); abschaltbar mit --ohne-freigaben
Nicht uebernommen: Daten aus dem Datenpaket oder QuestieDB, Spielernamen, Einstellungen.

Aufruf:
    python lp_sammeln.py Datei1.lua Datei2.lua ... [--seed Data/Seed.lua] [--out Data/Seed.lua]
                         [--min-wege 1] [--min-quest 1]
"""
import argparse
import datetime
import math
import os
import re
import sys
from collections import Counter, defaultdict

# --------------------------------------------------------------------------
# Lua-Tabellen lesen (Format der WoW-Speicherdateien)
# --------------------------------------------------------------------------
class LuaParser:
    def __init__(self, text):
        self.s = text
        self.i = 0
        self.n = len(text)

    def error(self, msg):
        line = self.s.count("\n", 0, self.i) + 1
        raise ValueError(f"{msg} (Zeile {line})")

    def skip(self):
        s, n = self.s, self.n
        while self.i < n:
            c = s[self.i]
            if c in " \t\r\n,;":
                self.i += 1
            elif s.startswith("--[[", self.i):
                j = s.find("]]", self.i)
                self.i = n if j < 0 else j + 2
            elif s.startswith("--", self.i):
                j = s.find("\n", self.i)
                self.i = n if j < 0 else j + 1
            else:
                break

    def value(self):
        self.skip()
        if self.i >= self.n:
            self.error("unerwartetes Dateiende")
        c = self.s[self.i]
        if c == "{":
            return self.table()
        if c in "\"'":
            return self.string()
        if c == "[" and self.s.startswith("[[", self.i):
            j = self.s.find("]]", self.i + 2)
            v = self.s[self.i + 2:j]
            self.i = j + 2
            return v
        m = re.compile(r"-?(0[xX][0-9a-fA-F]+|\d+\.?\d*(?:[eE][-+]?\d+)?|\.\d+(?:[eE][-+]?\d+)?)").match(self.s, self.i)
        if m:
            self.i = m.end()
            t = m.group(0)
            if "x" in t.lower():
                return int(t, 16)
            if re.fullmatch(r"-?\d+", t):
                return int(t)
            return float(t)
        for word, val in (("true", True), ("false", False), ("nil", None)):
            if self.s.startswith(word, self.i):
                self.i += len(word)
                return val
        self.error("unbekannter Wert")

    def string(self):
        q = self.s[self.i]
        self.i += 1
        out = []
        s = self.s
        while self.i < self.n:
            c = s[self.i]
            if c == q:
                self.i += 1
                return "".join(out)
            if c == "\\":
                self.i += 1
                e = s[self.i]
                if e == "n": out.append("\n")
                elif e == "t": out.append("\t")
                elif e == "r": out.append("\r")
                elif e.isdigit():
                    m = re.compile(r"\d{1,3}").match(s, self.i)
                    out.append(chr(int(m.group(0))))
                    self.i = m.end() - 1
                elif e == "\n": out.append("\n")
                else: out.append(e)
                self.i += 1
            else:
                out.append(c)
                self.i += 1
        self.error("Zeichenkette nicht beendet")

    def table(self):
        self.i += 1
        result = {}
        idx = 1
        while True:
            self.skip()
            if self.i >= self.n:
                self.error("Tabelle nicht beendet")
            if self.s[self.i] == "}":
                self.i += 1
                break
            if self.s[self.i] == "[" and not self.s.startswith("[[", self.i):
                self.i += 1
                key = self.value()
                self.skip()
                if self.s[self.i] != "]":
                    self.error("] erwartet")
                self.i += 1
                self.skip()
                if self.s[self.i] != "=":
                    self.error("= erwartet")
                self.i += 1
                result[key] = self.value()
                continue
            m = re.compile(r"([A-Za-z_][A-Za-z0-9_]*)\s*=(?!=)").match(self.s, self.i)
            if m:
                self.i = m.end()
                result[m.group(1)] = self.value()
                continue
            result[idx] = self.value()
            idx += 1
        return result


def parse_assignments(text):
    """Liest 'Name = {...}'-Zuweisungen einer Speicherdatei oder Seed.lua."""
    out = {}
    for m in re.finditer(r"(?m)^\s*([A-Za-z_][A-Za-z0-9_.]*)\s*=\s*(?=\{)", text):
        p = LuaParser(text)
        p.i = m.end()
        out[m.group(1)] = p.value()
    return out


def read_seed(text):
    """Liest eine von diesem Werkzeug geschriebene Seed.lua (Kopf + Bloecke 'T[...]=...')."""
    head = parse_assignments(text).get("LP.Seed")
    if not isinstance(head, dict):
        return None
    seed = {"version": head.get("version"), "contributors": head.get("contributors") or 0,
            "quests": {}, "vendors": [], "taxi": {}, "paths": [], "caves": []}
    target = None
    for line in text.splitlines():
        m = re.match(r"\s*;?\(function\(\) local T = S\.(\w+)", line)
        if m:
            target = m.group(1)
            continue
        if line.startswith("end)()"):
            target = None
            continue
        if not target:
            continue
        m = re.match(r"T\[#T\+1\]=(.*)$", line)
        if m:
            p = LuaParser(m.group(1))
            seed[target].append(p.value())
            continue
        m = re.match(r"T\[(.+?)\]=(\{.*)$", line)
        if m:
            key = LuaParser(m.group(1)).value()
            seed[target][key] = LuaParser(m.group(2)).value()
    return seed


def as_list(t):
    """Lua-Tabelle mit Zahlenschluesseln 1..n als Python-Liste."""
    if isinstance(t, list):
        return t
    if not isinstance(t, dict):
        return []
    out, i = [], 1
    while i in t:
        out.append(t[i])
        i += 1
    return out

# --------------------------------------------------------------------------
# Pruefen
# --------------------------------------------------------------------------
def num(v, lo, hi):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and lo <= v <= hi and v == v


def point(p):
    p = as_list(p)
    if len(p) >= 3 and num(p[0], 1, 5000) and num(p[1], 0, 100) and num(p[2], 0, 100):
        npc = p[3] if len(p) > 3 and isinstance(p[3], str) and len(p[3]) <= 80 else None
        return (int(p[0]), float(p[1]), float(p[2]), npc)
    return None


def clean_name(s):
    if not isinstance(s, str):
        return None
    s = re.sub(r"[\x00-\x1f|]", "", s).strip()
    return s if 2 <= len(s) <= 80 else None

# --------------------------------------------------------------------------
# Zusammenfuehren
# --------------------------------------------------------------------------
def cluster_points(points, radius=3.0):
    """Waehlt den groessten Haufen von Punkten (gleiche Karte, Abstand <= radius) und
    liefert dessen Median. points: [(map, x, y, npc, gewicht)]"""
    if not points:
        return None
    best, best_w = None, -1
    for p in points:
        members = [q for q in points if q[0] == p[0] and math.hypot(q[1] - p[1], q[2] - p[2]) <= radius]
        w = sum(q[4] for q in members)
        if w > best_w:
            best, best_w = members, w
    xs = sorted(q[1] for q in best)
    ys = sorted(q[2] for q in best)
    npcs = Counter(q[3] for q in best if q[3])
    mid = len(xs) // 2
    return (best[0][0], round(xs[mid], 1), round(ys[mid], 1), npcs.most_common(1)[0][0] if npcs else None)


def merge_hotspots(spots, limit=5, radius=3.0):
    """spots: [(map, x, y, gewicht)] -> bis zu 'limit' gewichtete Orte"""
    groups = []
    for m, x, y, w in sorted(spots, key=lambda s: -s[3]):
        for g in groups:
            if g[0] == m and math.hypot(g[1] - x, g[2] - y) <= radius:
                total = g[3] + w
                g[1] = (g[1] * g[3] + x * w) / total
                g[2] = (g[2] * g[3] + y * w) / total
                g[3] = total
                break
        else:
            groups.append([m, x, y, w])
    groups.sort(key=lambda g: -g[3])
    return [(g[0], round(g[1], 1), round(g[2], 1), min(int(g[3]), 50)) for g in groups[:limit]]


class Collector:
    def __init__(self):
        self.quests = defaultdict(lambda: {"n": Counter(), "l": Counter(), "f": Counter(), "s": [], "e": [],
                                           "o": defaultdict(list), "item": 0, "who": set(),
                                           "x": Counter(), "dg": Counter()})
        self.vendors = {}
        self.taxi = {}
        self.edges = Counter()          # ((inst, cellA), (inst, cellB)) -> Anzahl Mitwirkende
        self.cells = {}                 # (inst, gn, gw) -> [n, w, zone, gewicht]
        self.edge_who = defaultdict(set)
        self.caves = []                 # Hoehleneingaenge: {i, en, ew, m, cn, cw, r, who:set, w}
        self.files = 0
        self.skipped_net = 0
        self.seed_contributors = 0
        self.use_consented = True
        self.taken_consented = 0

    # Wege: Punkte auf ein 8-Yard-Raster legen, damit gleiche Wege mehrerer Spieler zusammenfallen
    def cell(self, inst, n, w, zone, weight=1):
        key = (int(inst), int(round(n / 8.0)), int(round(w / 8.0)))
        c = self.cells.get(key)
        if c:
            total = c[3] + weight
            c[0] = (c[0] * c[3] + n * weight) / total
            c[1] = (c[1] * c[3] + w * weight) / total
            c[3] = total
            if not c[2] and zone:
                c[2] = zone
        else:
            self.cells[key] = [n, w, zone or 0, weight]
        return key

    def add_edge(self, who, inst, a, b):
        ka = self.cell(inst, a[0], a[1], a[2])
        kb = self.cell(inst, b[0], b[1], b[2])
        if ka == kb:
            return
        k = (ka, kb) if ka < kb else (kb, ka)
        if who not in self.edge_who[k]:
            self.edge_who[k].add(who)
            self.edges[k] += 1

    def add_db(self, db, who):
        self.files += 1
        # Quests
        for qid, e in (db.get("qdb") or {}).items():
            if not isinstance(qid, int) or not 0 < qid < 300000 or not isinstance(e, dict):
                continue
            if e.get("net"):
                c = e.get("c") or 0
                if not (self.use_consented and num(c, 1, 100000)):
                    self.skipped_net += 1
                    continue
                self.taken_consented += 1
                q = self.quests[qid]
                q["who"].update(f"{who}:frei{i}" for i in range(min(int(c), 20)))
            else:
                q = self.quests[qid]
                q["who"].add(who)
            name = clean_name(e.get("n"))
            if name: q["n"][name] += 1
            if num(e.get("l"), 1, 63): q["l"][int(e["l"])] += 1
            if e.get("f") in ("A", "H"): q["f"][e["f"]] += 1
            if e.get("item"): q["item"] += 1
            if num(e.get("x"), 1, 100000) and num(e.get("xl"), 1, 63): q["x"][(int(e["x"]), int(e["xl"]))] += 1
            if num(e.get("dg"), 1, 20000): q["dg"][int(e["dg"])] += 1
            s, en = point(e.get("s")), point(e.get("e"))
            if s: q["s"].append(s + (1,))
            if en: q["e"].append(en + (1,))
            for idx, lst in (e.get("o") or {}).items():
                if not isinstance(idx, int) or not 1 <= idx <= 10:
                    continue
                for h in as_list(lst):
                    h = as_list(h)
                    if len(h) >= 3 and num(h[0], 1, 5000) and num(h[1], 0, 100) and num(h[2], 0, 100):
                        w = h[3] if len(h) > 3 and num(h[3], 1, 1000) else 1
                        q["o"][idx].append((int(h[0]), float(h[1]), float(h[2]), w))
        # Haendler, Reparatur, Gasthaus
        for key, v in (db.get("vendors") or {}).items():
            if not isinstance(v, dict) or not num(v.get("map"), 1, 5000):
                continue
            if not (num(v.get("x"), 0, 100) and num(v.get("y"), 0, 100)):
                continue
            name = clean_name(v.get("name"))
            if not name:
                continue
            k = f"{name}@{int(v['map'])}"
            cur = self.vendors.setdefault(k, {"name": name, "map": int(v["map"]), "xs": [], "ys": [], "f": Counter(),
                                               "vendor": False, "repair": False, "inn": False})
            cur["xs"].append(float(v["x"]))
            cur["ys"].append(float(v["y"]))
            if v.get("f") in ("A", "H"): cur["f"][v["f"]] += 1
            for flag in ("vendor", "repair", "inn"):
                if v.get(flag): cur[flag] = True
        # Flugpunkte
        for key, t in (db.get("taxi") or {}).items():
            if isinstance(t, dict) and num(t.get("map"), 1, 5000) and num(t.get("x"), 0, 100) and num(t.get("y"), 0, 100):
                name = clean_name(t.get("name") or key)
                if name:
                    self.taxi[name] = {"name": name, "map": int(t["map"]), "x": round(float(t["x"]), 1), "y": round(float(t["y"]), 1)}
        # Hoehlen und Tunnel (nur selbst beobachtet)
        for c in (db.get("caves") or {}).values():
            if isinstance(c, dict) and not c.get("net"):
                self.add_cave(who, c)
        # Wege (nur selbst gelaufen)
        graph = db.get("graph") or {}
        nodes = graph.get("nodes") or {}
        edge_flags = {}
        edge_list = []
        for raw in (graph.get("edges") or {}).values():
            if isinstance(raw, dict):
                lst = as_list(raw)
                edge_flags[id(lst)] = bool(raw.get("c"))
                edge_list.append(lst)
        for e in edge_list:
            if not isinstance(e, list) or len(e) < 3:
                continue
            consented = False
            if e[2] == "s":
                consented = self.use_consented and bool(edge_flags.get(id(e)))
                if not consented:
                    continue
            elif e[2] not in ("r", "w"):
                continue
            a, b = nodes.get(e[0]), nodes.get(e[1])
            if not (isinstance(a, dict) and isinstance(b, dict)):
                continue
            if (a.get("net") or b.get("net")) and not consented:
                continue
            la, lb = as_list(a), as_list(b)
            if len(la) < 3 or len(lb) < 3 or la[0] != lb[0]:
                continue
            if not (num(la[1], -40000, 40000) and num(la[2], -40000, 40000) and num(lb[1], -40000, 40000) and num(lb[2], -40000, 40000)):
                continue
            if math.hypot(la[1] - lb[1], la[2] - lb[2]) > 150:
                continue
            za = la[3] if len(la) > 3 and isinstance(la[3], int) else 0
            zb = lb[3] if len(lb) > 3 and isinstance(lb[3], int) else 0
            self.add_edge(who, int(la[0]), (float(la[1]), float(la[2]), za), (float(lb[1]), float(lb[2]), zb))

    def add_cave(self, who, c, weight=1):
        """Hoehleneingang einordnen: Eingaenge naeher als 30 Yards sind derselbe."""
        try:
            i = int(c["i"]); en = float(c["en"]); ew = float(c["ew"]); cn = float(c["cn"]); cw = float(c["cw"])
            r = float(c.get("r") or 60)
        except (KeyError, TypeError, ValueError):
            return
        if not (num(en, -40000, 40000) and num(ew, -40000, 40000) and num(cn, -40000, 40000) and num(cw, -40000, 40000)):
            return
        if math.hypot(en - cn, ew - cw) > 400 or not (20 <= r <= 300):
            return
        m = c.get("m") if isinstance(c.get("m"), int) else None
        for o in self.caves:
            if o["i"] == i and math.hypot(o["en"] - en, o["ew"] - ew) < 30:
                k = o["w"]
                for f, v in (("en", en), ("ew", ew), ("cn", cn), ("cw", cw)):
                    o[f] = (o[f] * k + v * weight) / (k + weight)
                o["r"] = max(o["r"], r)
                o["w"] = k + weight
                o["who"].add(who)
                if m and not o["m"]:
                    o["m"] = m
                return
        self.caves.append({"i": i, "en": en, "ew": ew, "m": m, "cn": cn, "cw": cw, "r": r, "w": weight, "who": {who}})

    def add_seed(self, seed):
        """Bisherige Startdatenbank als eigene Mitwirkende uebernehmen."""
        who = "seed"
        weight = max(1, int(seed.get("contributors") or 1))
        for qid, e in (seed.get("quests") or {}).items():
            if not isinstance(qid, int) or not isinstance(e, dict):
                continue
            q = self.quests[qid]
            c = max(1, int(e.get("c") or 1))
            q["who"].update(f"seed{i}" for i in range(c))
            name = clean_name(e.get("n"))
            if name: q["n"][name] += c
            if num(e.get("l"), 1, 63): q["l"][int(e["l"])] += c
            if e.get("f") in ("A", "H"): q["f"][e["f"]] += c
            if e.get("item"): q["item"] += c
            if num(e.get("x"), 1, 100000) and num(e.get("xl"), 1, 63): q["x"][(int(e["x"]), int(e["xl"]))] += c
            if num(e.get("dg"), 1, 20000): q["dg"][int(e["dg"])] += c
            s, en = point(e.get("s")), point(e.get("e"))
            if s: q["s"].append(s + (c,))
            if en: q["e"].append(en + (c,))
            for idx, lst in (e.get("o") or {}).items():
                if isinstance(idx, int):
                    for h in as_list(lst):
                        h = as_list(h)
                        if len(h) >= 3 and num(h[1], 0, 100) and num(h[2], 0, 100):
                            q["o"][idx].append((int(h[0]), float(h[1]), float(h[2]), h[3] if len(h) > 3 and num(h[3], 1, 1000) else 1))
        for v in as_list(seed.get("vendors")):
            if isinstance(v, dict) and num(v.get("map"), 1, 5000) and num(v.get("x"), 0, 100) and num(v.get("y"), 0, 100):
                name = clean_name(v.get("name"))
                if not name:
                    continue
                k = f"{name}@{int(v['map'])}"
                cur = self.vendors.setdefault(k, {"name": name, "map": int(v["map"]), "xs": [], "ys": [], "f": Counter(),
                                                   "vendor": False, "repair": False, "inn": False})
                cur["xs"] += [float(v["x"])] * weight
                cur["ys"] += [float(v["y"])] * weight
                if v.get("f") in ("A", "H"): cur["f"][v["f"]] += weight
                for flag in ("vendor", "repair", "inn"):
                    if v.get(flag): cur[flag] = True
        for name, t in (seed.get("taxi") or {}).items():
            if isinstance(t, dict) and num(t.get("map"), 1, 5000):
                self.taxi.setdefault(name, {"name": name, "map": int(t["map"]), "x": float(t["x"]), "y": float(t["y"])})
        for c in as_list(seed.get("caves")):
            if isinstance(c, dict):
                self.add_cave("seed", c, max(1, int(c.get("c") or 1)))
        for s in as_list(seed.get("paths")):
            s = as_list(s)
            if len(s) >= 7:
                c = int(s[7]) if len(s) > 7 and num(s[7], 1, 100000) else 1
                ka = self.cell(int(s[0]), float(s[1]), float(s[2]), int(s[3] or 0), c)
                kb = self.cell(int(s[0]), float(s[4]), float(s[5]), int(s[6] or 0), c)
                if ka != kb:
                    k = (ka, kb) if ka < kb else (kb, ka)
                    self.edges[k] += c
                    for i in range(c):
                        self.edge_who[k].add(f"seed{i}")

    def build(self, min_quest=1, min_path=1):
        quests = {}
        for qid, q in sorted(self.quests.items()):
            if len(q["who"]) < min_quest or not q["n"]:
                continue
            e = {"n": q["n"].most_common(1)[0][0], "c": len(q["who"])}
            if q["l"]: e["l"] = q["l"].most_common(1)[0][0]
            if q["f"]: e["f"] = q["f"].most_common(1)[0][0]
            if q["item"] * 2 >= len(q["who"]): e["item"] = True
            if q["x"]:
                # bevorzugt Werte ohne Abzug (Spieler hoechstens 4 Stufen ueber der Quest)
                lvl = e.get("l") or 0
                full = [(k, c) for k, c in q["x"].items() if not lvl or k[1] <= lvl + 4]
                pick = max(full or list(q["x"].items()), key=lambda kc: (kc[1], kc[0][0]))[0]
                e["x"], e["xl"] = pick[0], pick[1]
            if q["dg"]: e["dg"] = q["dg"].most_common(1)[0][0]
            s, en = cluster_points(q["s"]), cluster_points(q["e"])
            if s: e["s"] = [p for p in s if p is not None]
            if en: e["e"] = [p for p in en if p is not None]
            objs = {}
            for idx, spots in q["o"].items():
                merged = merge_hotspots(spots)
                if merged:
                    objs[idx] = [list(m) for m in merged]
            if objs: e["o"] = objs
            quests[qid] = e
        vendors = []
        for k in sorted(self.vendors):
            v = self.vendors[k]
            xs, ys = sorted(v["xs"]), sorted(v["ys"])
            entry = {"name": v["name"], "map": v["map"], "x": round(xs[len(xs) // 2], 1), "y": round(ys[len(ys) // 2], 1)}
            if v["f"]: entry["f"] = v["f"].most_common(1)[0][0]
            for flag in ("vendor", "repair", "inn"):
                if v[flag]: entry[flag] = True
            vendors.append(entry)
        paths = []
        for (ka, kb), count in sorted(self.edges.items()):
            if count < min_path:
                continue
            a, b = self.cells[ka], self.cells[kb]
            paths.append([ka[0], round(a[0]), round(a[1]), int(a[2] or 0), round(b[0]), round(b[1]), int(b[2] or 0), count])
        caves = []
        for o in sorted(self.caves, key=lambda o: (o["i"], o["en"], o["ew"])):
            e = {"i": o["i"], "en": round(o["en"]), "ew": round(o["ew"]), "cn": round(o["cn"]), "cw": round(o["cw"]),
                 "r": round(o["r"]), "c": len(o["who"])}
            if o["m"]: e["m"] = o["m"]
            caves.append(e)
        return quests, vendors, dict(sorted(self.taxi.items())), paths, caves

# --------------------------------------------------------------------------
# Seed.lua schreiben
# --------------------------------------------------------------------------
def lua(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        return ("%.1f" % v).rstrip("0").rstrip(".") if v != int(v) else str(int(v))
    if isinstance(v, str):
        return '"' + v.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'
    if isinstance(v, (list, tuple)):
        return "{" + ",".join(lua(x) for x in v) + "}"
    if isinstance(v, dict):
        parts = []
        for k in sorted(v, key=lambda x: (isinstance(x, str), str(x))):
            if isinstance(k, str) and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", k):
                parts.append(f"{k}={lua(v[k])}")
            else:
                parts.append(f"[{lua(k)}]={lua(v[k])}")
        return "{" + ",".join(parts) + "}"
    return "nil"


def write_seed(path, quests, vendors, taxi, paths, contributors, caves=()):
    stamp = datetime.date.today().isoformat()
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write("-- LevelPilot - Startdatenbank\n")
        f.write("-- Erzeugt mit Tools\\lp_sammeln.py aus den Aufzeichnungen von LevelPilot-Spielern.\n")
        f.write("-- Enthaelt nur selbst beobachtete Daten. Nicht von Hand bearbeiten.\n")
        f.write("-- Copyright (c) 2026 GoldSentinel. Alle Rechte vorbehalten.\n\n")
        f.write("local _, LP = ...\n")
        f.write(f'LP.Seed = {{ version = "{stamp}", contributors = {contributors}, quests = {{}}, vendors = {{}}, taxi = {{}}, paths = {{}}, caves = {{}} }}\n')
        f.write("local S = LP.Seed\n")

        def chunks(items, size):
            for i in range(0, len(items), size):
                yield items[i:i + size]

        for block in chunks(list(quests.items()), 600):
            f.write(";(function() local T = S.quests\n")
            for qid, e in block:
                f.write(f"T[{qid}]={lua(e)}\n")
            f.write("end)()\n")
        for block in chunks(vendors, 800):
            f.write(";(function() local T = S.vendors\n")
            for v in block:
                f.write(f"T[#T+1]={lua(v)}\n")
            f.write("end)()\n")
        f.write(";(function() local T = S.taxi\n")
        for name, t in taxi.items():
            f.write(f"T[{lua(name)}]={lua(t)}\n")
        f.write("end)()\n")
        for block in chunks(paths, 2000):
            f.write(";(function() local T = S.paths\n")
            for p in block:
                f.write(f"T[#T+1]={lua(p)}\n")
            f.write("end)()\n")
        if caves:
            f.write(";(function() local T = S.caves\n")
            for c in caves:
                f.write(f"T[#T+1]={lua(c)}\n")
            f.write("end)()\n")


def main():
    ap = argparse.ArgumentParser(description="LevelPilot - Aufzeichnungen zur Startdatenbank zusammenfuehren")
    ap.add_argument("dateien", nargs="+", help="LevelPilot.lua-Speicherdateien der Spieler")
    ap.add_argument("--seed", help="bisherige Data/Seed.lua (wird uebernommen)")
    ap.add_argument("--out", help="Ausgabedatei (Standard: Data/Seed.lua neben diesem Werkzeug)")
    ap.add_argument("--min-wege", type=int, default=1, help="Wegstueck nur uebernehmen, wenn so viele Spieler es gelaufen sind")
    ap.add_argument("--min-quest", type=int, default=1, help="Quest nur uebernehmen, wenn so viele Spieler sie gesehen haben")
    ap.add_argument("--ohne-freigaben", action="store_true", help="freigegebene Daten anderer Spieler nicht uebernehmen")
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    out = args.out or os.path.join(here, "..", "Data", "Seed.lua")
    col = Collector()
    col.use_consented = not args.ohne_freigaben

    if args.seed:
        text = open(args.seed, encoding="utf-8", errors="replace").read()
        seed = read_seed(text)
        if seed:
            col.seed_contributors = int(seed.get("contributors") or 0)
            col.add_seed(seed)
            print(f"Bisherige Startdatenbank: {len(seed.get('quests') or {})} Quests, {len(as_list(seed.get('paths')))} Wegstuecke")

    for i, path in enumerate(args.dateien, 1):
        try:
            text = open(path, encoding="utf-8", errors="replace").read()
            db = parse_assignments(text).get("LevelPilotDB")
        except (OSError, ValueError) as err:
            print(f"!! {path}: {err}")
            continue
        if not isinstance(db, dict):
            print(f"!! {path}: keine LevelPilot-Daten gefunden")
            continue
        col.add_db(db, f"datei{i}")
        print(f"Gelesen: {path}")

    if col.files == 0 and not args.seed:
        print("Keine verwertbaren Dateien.")
        return 1

    quests, vendors, taxi, paths, caves = col.build(args.min_quest, args.min_wege)
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    contributors = col.files + col.seed_contributors
    write_seed(out, quests, vendors, taxi, paths, contributors, caves)
    print()
    print(f"Startdatenbank geschrieben: {os.path.abspath(out)}")
    print(f"  Quests:      {len(quests)}")
    print(f"  Haendler:    {len(vendors)}")
    print(f"  Hoehlen:     {len(caves)}")
    print(f"  Flugpunkte:  {len(taxi)}")
    print(f"  Wegstuecke:  {len(paths)}")
    print(f"  Freigegebene Quests anderer Spieler uebernommen: {col.taken_consented}")
    print(f"  Uebersprungen (empfangen, ohne Freigabe): {col.skipped_net}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
