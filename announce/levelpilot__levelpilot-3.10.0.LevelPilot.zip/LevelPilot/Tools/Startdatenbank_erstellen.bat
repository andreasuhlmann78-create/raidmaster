@echo off
rem LevelPilot - Startdatenbank erstellen
rem Speicherdateien (LevelPilot.lua) einfach auf diese Datei ziehen.
rem Die bisherige Startdatenbank wird automatisch uebernommen.
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
    echo Python ist nicht installiert. Bitte von https://www.python.org installieren.
    pause
    exit /b 1
)
if "%~1"=="" (
    echo Bitte LevelPilot.lua-Dateien auf diese Datei ziehen.
    pause
    exit /b 1
)
python lp_sammeln.py %* --seed "..\Data\Seed.lua"
pause
