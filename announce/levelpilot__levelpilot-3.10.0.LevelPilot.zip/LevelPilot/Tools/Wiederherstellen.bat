@echo off
title LevelPilot - Sicherung zurueckspielen
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Wiederherstellen.ps1"
echo.
pause
