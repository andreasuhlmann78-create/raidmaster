-- LevelPilot - Startdatenbank
-- Diese Datei wird mit dem Sammelwerkzeug (Tools\lp_sammeln.py) aus den Aufzeichnungen
-- von LevelPilot-Spielern erzeugt. Sie enthaelt nur selbst beobachtete Daten.
-- Copyright (c) 2026 GoldSentinel. Alle Rechte vorbehalten.

local _, LP = ...
LP.Seed = {
    version = "leer",
    contributors = 0,
    quests = {},
    vendors = {},
    taxi = {},
    paths = {},
    caves = {},
}
