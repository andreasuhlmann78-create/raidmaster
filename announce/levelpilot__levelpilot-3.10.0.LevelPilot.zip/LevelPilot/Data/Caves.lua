-- LevelPilot - Hoehlen und Minen (Startwerte)
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Hoehlen, Minen und Tunnel lernt LevelPilot selbst: Geht ein Spieler von draussen nach drinnen
-- (das Spiel meldet "drinnen", z.B. kein Reittier), wird die Stelle als Eingang gespeichert und
-- der begangene Innenraum dazu. Die gelernten Eingaenge werden mit anderen Spielern geteilt und
-- ueber die Startdatenbank verteilt. Diese Liste sind nur Startwerte fuer die ersten Hoehlen.
--
-- Format: { uiMapID, Eingang x, y, Innenraum-Mitte x, y, Radius in Karten-%, Name }
-- Koordinaten in Classic-Kartenkoordinaten (Umrechnung fuer WoW Forever beim Laden).

local _, LP = ...

LP.CaveSeed = {
    { 1429, 47.5, 31.9, 48.9, 28.4, 3.6, "Echo Ridge Mine" },        -- Nordhain: Kobold-Arbeiter
    { 1429, 39.0, 82.0, 40.7, 79.4, 2.6, "Fargodeep Mine" },         -- unterer Eingang
    { 1429, 61.2, 53.4, 61.0, 50.6, 1.9, "Jasperlode Mine" },
}

-- Zonen mit geaenderten Kartengrenzen auf WoW Forever: x' = sx * x + ox, y' = sy * y + oy
LP.CaveForeverMaps = {
    [1412] = { 0.8348002068, 7.0074531087, 0.8349418225, 13.1538732772 },  -- Mulgore
    [1423] = { 0.8997577709, -1.6464926382, 0.9004358591, -3.7790494664 }, -- Oestliche Pestlaender
    [1433] = { 0.9999996626, -5.0863745842, 1.0000000000, 0 },             -- Rotkammgebirge
    [1453] = { 0.7736792385, 19.6804496463, 0.7738268670, 24.4332878075 }, -- Sturmwind
}
