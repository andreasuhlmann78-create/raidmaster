-- LevelPilot - Dungeons (eigene Daten)
-- Copyright (C) 2026 GoldSentinel. Alle Rechte vorbehalten.
--
-- Je Dungeon (Schluessel = AreaID der Instanz):
--   name   deutscher Name, en englischer Name (Anzeige je nach Sprache)
--   min/max  empfohlener Stufenbereich
--   run    typische Dauer eines Laufs in Minuten (ohne Gruppensuche)
--   inst   Instanz-ID (GetInstanceInfo, 8. Rueckgabewert)
--   alt    weitere AreaIDs, unter denen Quests dieser Instanz gefuehrt werden
--   e      Eingaenge { {uiMapID, x, y}, ... } in WoW-Forever-Koordinaten (Ersatz, falls
--          das Datenpaket keine genaueren kennt)
--   only   "A"/"H": nur fuer diese Fraktion betretbar (Eingang in deren Hauptstadt)
--   land   "A"/"H": Eingang liegt im Gebiet dieser Fraktion (fuer die andere nur mit Umweg/Risiko)
-- Gilt fuer WoW Forever eine andere Regel, genuegt eine Aenderung hier.

local _, LP = ...

LP.Dungeons = {
    [2437] = { name = "Der Flammenschlund", en = "Ragefire Chasm",          min = 13, max = 18, run = 30, inst = 389, only = "H",
               e = { { 1454, 52.6, 49.0 } } },                                   -- Orgrimmar
    [718]  = { name = "Die Höhlen des Wehklagens", en = "Wailing Caverns",   min = 17, max = 24, run = 50, inst = 43,
               e = { { 1413, 46.0, 36.5 } } },                                   -- Brachland
    [1581] = { name = "Die Todesminen", en = "The Deadmines",              min = 17, max = 26, run = 50, inst = 36,  land = "A", alt = { 10029 },
               e = { { 1436, 42.5, 71.7 } } },                                   -- Westfall
    [209]  = { name = "Burg Schattenfang", en = "Shadowfang Keep",           min = 22, max = 30, run = 45, inst = 33,  land = "H",
               alt = { 10014, 10015, 10016, 10017, 10018, 10019 },
               e = { { 1421, 44.8, 67.8 } } },                                   -- Silberwald
    [719]  = { name = "Die Tiefschwarze Grotte", en = "Blackfathom Deeps",     min = 24, max = 32, run = 50, inst = 48,  alt = { 10020, 10021 },
               e = { { 1440, 14.5, 14.2 } } },                                   -- Eschental
    [717]  = { name = "Das Verlies", en = "The Stockade",                 min = 24, max = 32, run = 30, inst = 34,  only = "A",
               e = { { 1453, 52.4, 70.0 } } },                                   -- Sturmwind
    [721]  = { name = "Gnomeregan", en = "Gnomeregan",                  min = 29, max = 38, run = 60, inst = 90,  land = "A",
               alt = { 133, 10030, 10031, 10032 },
               e = { { 1426, 24.3, 39.8 } } },                                   -- Dun Morogh
    [491]  = { name = "Der Kral der Klingenhauer", en = "Razorfen Kraul",   min = 29, max = 38, run = 50, inst = 47,  alt = { 1717 },
               e = { { 1413, 42.9, 90.2 } } },                                   -- Brachland (Sueden)
    [796]  = { name = "Das Scharlachrote Kloster", en = "Scarlet Monastery",   min = 34, max = 45, run = 40, inst = 189, land = "H",
               alt = { 6109, 6386, 10008, 10009, 10010 },
               e = { { 1420, 82.6, 33.8 } } },                                   -- Tirisfal
    [722]  = { name = "Die Hügel der Klingenhauer", en = "Razorfen Downs",  min = 37, max = 46, run = 50, inst = 129,
               e = { { 1413, 49.0, 93.9 } } },                                   -- Brachland (Sueden)
    [1337] = { name = "Uldaman", en = "Uldaman",                     min = 41, max = 51, run = 60, inst = 70,  alt = { 1517, 10033 },
               e = { { 1418, 44.6, 12.1 }, { 1418, 65.2, 43.5 } } },             -- Oedland
    [1176] = { name = "Zul'Farrak", en = "Zul'Farrak",                  min = 44, max = 54, run = 50, inst = 209, alt = { 978 },
               e = { { 1446, 38.7, 20.1 } } },                                   -- Tanaris
    [2100] = { name = "Maraudon", en = "Maraudon",                    min = 46, max = 55, run = 60, inst = 349, alt = { 10000 },
               e = { { 1443, 29.1, 62.5 } } },                                   -- Desolace
    [1477] = { name = "Der Tempel von Atal'Hakkar", en = "The Temple of Atal'Hakkar",  min = 50, max = 56, run = 60, inst = 109, alt = { 1417 },
               e = { { 1435, 69.9, 53.5 } } },                                   -- Suempfe des Elends
    [1584] = { name = "Die Schwarzfelstiefen", en = "Blackrock Depths",       min = 52, max = 60, run = 90, inst = 230, alt = { 1585 },
               e = { { 1427, 34.8, 85.3 }, { 1428, 29.4, 38.3 } } },             -- Sengende Schlucht / Brennende Steppe
    [2557] = { name = "Düsterbruch", en = "Dire Maul",                 min = 55, max = 60, run = 50, inst = 429,
               alt = { 10022, 10023, 10024, 10025, 10026, 10027 },
               e = { { 1444, 59.2, 45.1 } } },                                   -- Feralas
    [1583] = { name = "Die Schwarzfelsspitze", en = "Blackrock Spire",       min = 55, max = 60, run = 75, inst = 229,
               alt = { 10003, 10004, 10005, 10006, 10007 },
               e = { { 1427, 34.8, 85.3 }, { 1428, 29.4, 38.3 } } },
    [2057] = { name = "Scholomance", en = "Scholomance",                 min = 58, max = 60, run = 75, inst = 289, alt = { 10011, 10012, 10013 },
               e = { { 1422, 69.7, 73.2 } } },                                   -- Westliche Pestlaender
    [2017] = { name = "Stratholme", en = "Stratholme",                  min = 58, max = 60, run = 75, inst = 329, alt = { 10001 },
               e = { { 1423, 26.5, 10.4 }, { 1423, 41.5, 17.7 } } },             -- Oestliche Pestlaender
}

-- Nachschlagetabellen: alternative AreaID -> Dungeon, Instanz-ID -> Dungeon
LP.DungeonByArea, LP.DungeonByInstance = {}, {}
for area, d in pairs(LP.Dungeons) do
    d.area = area
    LP.DungeonByArea[area] = area
    for _, a in ipairs(d.alt or {}) do LP.DungeonByArea[a] = area end
    if d.inst then LP.DungeonByInstance[d.inst] = area end
end
