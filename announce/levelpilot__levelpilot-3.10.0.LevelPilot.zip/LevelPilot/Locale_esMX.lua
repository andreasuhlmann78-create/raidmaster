-- LevelPilot - Spanish (Latin America) – only entries that differ from esES translations (German text -> esMX)
-- Copyright (C) 2026 GoldSentinel. All rights reserved.
-- Keys are the German texts used in the code. Missing entries fall back to English (esMX: to esES).
local _, LP = ...
local T = LP.Locales["mx"]
if not T then return end
;(function()
T[" Plätze (für dein Level sind "] = " espacios (a tu nivel "
T[" Taschenplatz/-plätze leer – kaufe oder lege Taschen an"] = " espacio(s) de bolsa vacío(s) – compra o equipa bolsas"
T[" Taschenplätze frei"] = " espacios de bolsa libres"
T[" · im Dungeon "] = " · en calabozo "
T[") lohnt sich nicht mehr – im Questlog abbrechen, um Platz zu schaffen"] = ") ya no compensa – abandónala para liberar un espacio en el registro"
T["Alle Quests für diesen Dungeon erledigt.\nNach dem Verlassen der Instanz geht es mit den Abgaben weiter."] = "Todas las misiones de este calabozo están hechas.\nAl salir de la instancia, LevelPilot continúa con las entregas."
T["Du bist im Dungeon – die offenen Questziele stehen darunter."] = "Estás en el calabozo – los objetivos pendientes aparecen abajo."
T["Dungeon"] = "Calabozo"
T["Dungeon betreten: "] = "Calabozo iniciado: "
T["Dungeon verlassen – weiter mit den Abgaben."] = "Saliste del calabozo – continuamos con las entregas."
T["Dungeon zurückgestellt: "] = "Calabozo aplazado: "
T["Dungeon-Eingang: %s"] = "Entrada del calabozo: %s"
T["Dungeon-Lauf ab Quests"] = "Ir al calabozo a partir de misiones"
T["Dungeon-Monster-EP % (0 = auto)"] = "EXP de monstruos en calabozos % (0 = auto)"
T["Dungeon-Quest \""] = "Misión de calabozo \""
T["Dungeon-Quest-EP % (0 = auto)"] = "EXP de misiones de calabozo % (0 = auto)"
T["Dungeon-Quests einplanen (nur betretbare Dungeons)"] = "Planificar misiones de calabozo (solo calabozos accesibles)"
T["Dungeons"] = "Calabozos"
T["Dungeons (Klick = zum Eingang)"] = "Calabozos (clic = ir a la entrada)"
T["Dungeons: "] = "Calabozos: "
T["Einstellungen"] = "Configuración"
T["Gesicherten Text einfügen (Strg+V) und „Laden“ drücken. Es wird nur ergänzt – vorhandene Daten bleiben erhalten."] = "Pega el texto de copia (Ctrl+V) y presiona «Cargar». Los datos solo se añaden – los existentes se conservan."
T["Route, Daten, Austausch, Assistent, Einstellungen"] = "Ruta, calabozos, datos, compartir, asistente, comodidad, configuración"
T["Strg+A, dann Strg+C drücken und den Text in eine Datei einfügen (z. B. LevelPilot-Sicherung.txt). "] = "Presiona Ctrl+A, luego Ctrl+C y pega el texto en un archivo (p. ej. LevelPilot-Backup.txt). "
T["Taschen & Taschen-Upgrades"] = "Bolsas y mejores bolsas"
T["Taschen warnen ab frei"] = "Avisar con espacios de bolsa libres"
T["in den Einstellungen ausgeschaltet"] = "desactivado en los configuración"
T["|cffc890ffDungeon|r"] = "|cffc890ffCalabozo|r"
end)()
