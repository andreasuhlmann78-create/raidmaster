-- LevelPilot - Calib
-- Aus dem echten Spiel lernen, damit Planung und virtuelle Reise der Wirklichkeit naeher kommen:
--  * Kills pro Minute der eigenen Klasse (Abstand zwischen Monster-EP-Meldungen, Pausen ausgenommen)
--  * Quest-EP-Faktor von WoW Forever (echte EP bei der Abgabe gegen die Classic-Werte des Datenpakets)
--  * Abgleich der Level-Zeiten (echt gegen virtuelle Reise)
-- Gespeichert accountweit in LevelPilotDB.calib (nur Zahlen, keine Namen). Die virtuelle Reise schreibt nichts.

local _, LP = ...
local L = LP.L
local Ca = {}
LP:RegisterModule("Calib", Ca)

local KILL_GAP = 120          -- Sekunden: laengere Abstaende sind Pausen (Questgeber, Stadt, AFK), nicht Grinden
local KILL_MIN_SAMPLES = 20   -- erst ab so vielen Messungen den Messwert benutzen
local KPM_MIN, KPM_MAX = 0.6, 3.0
local XP_MIN_QUESTS = 5       -- erst ab so vielen abgegebenen Quests den Forever-Faktor benutzen
local XP_MIN, XP_MAX = 0.5, 3.0

local function Store()
    if type(LevelPilotDB) ~= "table" then return nil end
    LevelPilotDB.calib = type(LevelPilotDB.calib) == "table" and LevelPilotDB.calib or {}
    return LevelPilotDB.calib
end

local function ClassKey()
    local _, class = UnitClass("player")
    return class or "?"
end

------------------------------------------------------------------------
-- Kills pro Minute
------------------------------------------------------------------------
local lastKill
function Ca:OnKill()
    if LP.Virtual and LP.Virtual.active then return end
    local now = GetTime()
    if lastKill and now - lastKill <= KILL_GAP and now - lastKill >= 2 then
        local s = Store()
        if s then
            s.kills = type(s.kills) == "table" and s.kills or {}
            local k = s.kills[ClassKey()] or { n = 0, sum = 0 }
            k.n, k.sum = k.n + 1, k.sum + (now - lastKill)
            -- gleitend: alte Messungen verlieren mit der Zeit an Gewicht (Ausruestung und Level aendern sich)
            if k.n > 400 then k.sum, k.n = k.sum * 0.5, k.n * 0.5 end
            s.kills[ClassKey()] = k
        end
    end
    lastKill = now
end

-- gemessene Kills pro Minute (nil = noch zu wenig Messungen)
function Ca:KillsPerMin()
    local s = Store()
    local k = s and type(s.kills) == "table" and s.kills[ClassKey()]
    if not k or k.n < KILL_MIN_SAMPLES or k.sum <= 0 then return nil, k and k.n or 0 end
    local kpm = 60 / (k.sum / k.n)
    return math.max(KPM_MIN, math.min(KPM_MAX, kpm)), k.n
end

------------------------------------------------------------------------
-- Quest-EP-Faktor (echt gegen Datenpaket)
------------------------------------------------------------------------
local factorCache, factorN
function Ca:QuestXPFactor()
    if factorCache ~= nil then return factorCache or nil, factorN end
    local ratios = {}
    for id, e in pairs(LP.db and LP.db.qdb or {}) do
        if type(e) == "table" and e.x and e.xl then
            local q = LP.QuestDB and LP.QuestDB:Get(id)
            local ql = q and q.level and q.level > 0 and q.level
            -- nur Abgaben ohne Abschlag (Spieler hoechstens 5 Level ueber der Quest) und mit Classic-Wert
            if q and q.xp and q.xp > 0 and ql and e.xl <= ql + 5 then
                ratios[#ratios + 1] = e.x / q.xp
            end
        end
    end
    factorN = #ratios
    if #ratios < XP_MIN_QUESTS then factorCache = false return nil, factorN end
    table.sort(ratios)
    local med = ratios[math.floor((#ratios + 1) / 2)]
    if #ratios % 2 == 0 then med = (ratios[#ratios / 2] + ratios[#ratios / 2 + 1]) / 2 end
    factorCache = math.max(XP_MIN, math.min(XP_MAX, med))
    return factorCache, factorN
end
function Ca:Invalidate() factorCache = nil end

------------------------------------------------------------------------
-- Level-Zeiten: echt gegen virtuelle Reise
------------------------------------------------------------------------
-- Liefert Zeilen { level, real, sim } fuer alle Level, die es in beiden gibt, und die mittlere Abweichung (%)
function Ca:CompareLevelTimes(levelAt, realTimes)
    local rows, sumDev, n = {}, 0, 0
    realTimes = realTimes or (LP.Virtual and LP.Virtual:RealChar() or LP.char or {}).levelTimes or {}
    for l = 1, 59 do
        local a, b = levelAt[l], levelAt[l + 1]
        local real = realTimes[l]
        if a and b and real and real > 60 then
            local sim = b.t - a.t
            rows[#rows + 1] = { level = l, real = real, sim = sim }
            sumDev = sumDev + math.abs(sim - real) / real
            n = n + 1
        end
    end
    return rows, n > 0 and math.floor(sumDev / n * 100 + 0.5) or nil
end

------------------------------------------------------------------------
-- Diagnose-Text
------------------------------------------------------------------------
function Ca:StatusText()
    local kpm, kn = self:KillsPerMin()
    local f, fn = self:QuestXPFactor()
    return L("Kills pro Minute: %s (%d Messungen) · Quest-EP-Faktor: %s (%d Quests)",
        kpm and string.format("%.2f", kpm) or L["Annahme"], kn or 0, f and string.format("%.2f", f) or L["Annahme"], fn or 0)
end

function Ca:Init()
    LP:On("CHAT_MSG_COMBAT_XP_GAIN", function() Ca:OnKill() end)
    LP:On("QUEST_TURNED_IN", function() Ca:Invalidate() end)
end
