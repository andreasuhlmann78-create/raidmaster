-- Umrechnung Classic-Era -> WoW-Forever-Kartenkoordinaten fuer Zonen mit geaenderten Kartengrenzen.
-- Berechnet aus den Kartengrenzen (Weltkoordinaten) beider Clients: x' = sx * x + ox, y' = sy * y + oy
return {
    [1412] = { 0.8348002068, 7.0074531087, 0.8349418225, 13.1538732772 }, -- Mulgore
    [1423] = { 0.8997577709, -1.6464926382, 0.9004358591, -3.7790494664 }, -- Eastern Plaguelands
    [1433] = { 0.9999996626, -5.0863745842, 1.0000000000, -0.0000000000 }, -- Redridge Mountains
    [1453] = { 0.7736792385, 19.6804496463, 0.7738268670, 24.4332878075 }, -- Stormwind City
}
