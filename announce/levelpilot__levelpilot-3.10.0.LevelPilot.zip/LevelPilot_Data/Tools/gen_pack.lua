-- Generator fuer das Datenpaket "LevelPilot Data" (GPLv3)
-- Quelle: Questie v11.38.0 (Commit 454b9d07), lizenziert unter GNU GPL v3.
-- Aufruf: luatex --luaonly gen_pack.lua <QuestieOrdner> <AusgabeOrdner> <ForeverUmrechnung.lua>
local SRC, OUT, CONV = arg[1], arg[2], arg[3]
loadstring = loadstring or load
unpack = unpack or table.unpack

------------------------------------------------------------------------
-- Umgebung fuer die Questie-Dateien
------------------------------------------------------------------------
local FACTION = "Alliance"
local modules = {}
local function autoTable()
    return setmetatable({}, { __index = function(t, k) local v = autoTable() rawset(t, k, v) return v end })
end
QuestieLoader = {
    CreateModule = function(_, name) modules[name] = modules[name] or {} return modules[name] end,
    ImportModule = function(_, name) modules[name] = modules[name] or {} return modules[name] end,
}
WOW_PROJECT_ID, WOW_PROJECT_CLASSIC, WOW_PROJECT_BURNING_CRUSADE_CLASSIC = 2, 2, 5
WOW_PROJECT_WRATH_CLASSIC, WOW_PROJECT_CATACLYSM_CLASSIC, WOW_PROJECT_MISTS_CLASSIC, WOW_PROJECT_MAINLINE = 11, 14, 19, 1
function UnitFactionGroup() return FACTION end
function UnitClassBase() return "WARRIOR" end
function UnitClass() return "Warrior", "WARRIOR", 1 end
function UnitRace() return "Human", "Human", 1 end
function GetLocale() return "enUS" end
function GetBuildInfo() return "1.15.7", "60000", "Jan 1 2026", 11507 end
C_Seasons = { HasActiveSeason = function() return false end, GetActiveSeason = function() return 0 end }
C_GameRules = { IsHardcoreActive = function() return false end }
Questie = setmetatable({ IsClassic = true, IsEra = true, IsSoD = false, IsHardcore = false, IsTBC = false, IsWotlk = false,
    IsCata = false, IsMoP = false, IsTitanReforged = false, IsAnniversary = false, db = autoTable(),
    Debug = function() end, Warning = function() end, Error = function() end },
    { __index = function(_, k) if type(k) == "string" and k:match("^Is") then return false end return function() end end })
bit = {
    band = function(a, b) return a & b end, bor = function(a, b, ...) local r = a | b for _, c in ipairs({ ... }) do r = r | c end return r end,
    bxor = function(a, b) return a ~ b end, bnot = function(a) return ~a end,
    lshift = function(a, n) return a << n end, rshift = function(a, n) return a >> n end,
}
strsplit = function(sep, s) local out = {} for p in (s .. sep):gmatch("(.-)" .. sep) do out[#out + 1] = p end return unpack(out) end
wipe = function(t) for k in pairs(t) do t[k] = nil end return t end
tinsert, tremove = table.insert, table.remove
CreateFrame = function() return setmetatable({}, { __index = function() return function() end end }) end
GetRealmName = function() return "Realm" end
UnitName = function() return "Tester" end
UnitLevel = function() return 60 end
GetTime = function() return 0 end
time = os.time
date = os.date
-- unbekannte Spiel-Funktionen: aufrufbar und indizierbar, liefern nil
local magic
magic = setmetatable({}, { __index = function() return magic end, __call = function() return nil end })
setmetatable(_G, { __index = function(_, k) return magic end })
modules.ZoneDB = { private = {} }
modules.QuestieCorrections = autoTable()
modules.QuestieDB = { private = {} }
modules.l10n = setmetatable({}, { __call = function(_, s) return s end })

local function load(path)
    local f, err = loadfile(SRC .. "/" .. path)
    if not f then error(err) end
    f("Questie", {})
end

load("Modules/Expansions.lua")
load("Database/Zones/data/zoneIds.lua")
load("Database/Zones/data/areaIdToUiMapId.lua")
load("Database/Zones/data/dungeons.lua")
load("Database/Constants.lua")
load("Database/QuestieDB.lua")
for _, f in ipairs({ "questDB", "npcDB", "objectDB", "itemDB" }) do load("Database/" .. f .. ".lua") end
load("Modules/QuestieProfessions.lua")
load("Modules/Phasing.lua")
load("Database/Corrections/BlacklistFilter.lua")
load("Database/Corrections/ContentPhases/ContentPhases.lua")
for _, f in ipairs({ "classicQuestDB", "classicNpcDB", "classicObjectDB", "classicItemDB" }) do
    load("Database/Classic/" .. f .. ".lua")
end
for _, f in ipairs({ "classicQuestFixes", "classicNPCFixes", "classicObjectFixes", "classicItemFixes",
                     "QuestieQuestBlacklist", "QuestieNPCBlacklist" }) do
    load("Database/Corrections/" .. f .. ".lua")
end
load("Database/Corrections/Automatic/classicQuestReputationFixes.lua")
load("Database/QuestXP/DB/xpDB-classic.lua")
load("Database/Corrections/questTagInfoCorrections.lua")
modules.QuestieDB.private.InitializeQuestTagInfoCorrections()
local questXP = modules.QuestXP.db or {}
local questTags = modules.QuestieDB.private.questTagCorrections or {}

local QDB = modules.QuestieDB
local ZoneDB = modules.ZoneDB
local areaToUi = loadstring(ZoneDB.private.areaIdToUiMapId)()
local quests  = loadstring(QDB.questData)()
local npcs    = loadstring(QDB.npcData)()
local objects = loadstring(QDB.objectData)()
local items   = loadstring(QDB.itemData)()
local qk, nk, ok_, ik = QDB.questKeys, QDB.npcKeys, QDB.objectKeys, QDB.itemKeys

------------------------------------------------------------------------
-- Korrekturen anwenden (wie Questie)
------------------------------------------------------------------------
local function apply(db, fixes, noNew)
    local n = 0
    for id, data in pairs(fixes) do
        if not db[id] and not noNew then db[id] = {} end
        if db[id] then
            for key, value in pairs(data) do db[id][key] = value n = n + 1 end
        end
    end
    return n
end
local counts = {}
counts.rep  = apply(quests, modules.QuestieClassicQuestReputationFixes:Load())
counts.q    = apply(quests, modules.QuestieQuestFixes:Load())
counts.n    = apply(npcs, modules.QuestieNPCFixes:Load())
counts.o    = apply(objects, modules.QuestieObjectFixes:Load())
counts.i    = apply(items, modules.QuestieItemFixes:Load())

-- Fraktionsabhaengige Korrekturen getrennt aufheben
local factionFix = {}
for _, fac in ipairs({ "Alliance", "Horde" }) do
    FACTION = fac
    factionFix[fac] = {
        q = modules.QuestieQuestFixes:LoadFactionFixes() or {},
        n = modules.QuestieNPCFixes:LoadFactionFixes() or {},
        o = modules.QuestieObjectFixes:LoadFactionFixes() or {},
    }
end

-- Sperrlisten (nicht im Spiel, Duplikate)
local hidden = modules.BlacklistFilter.filterExpansion(modules.QuestieQuestBlacklist:Load())
local hiddenNpc = modules.BlacklistFilter.filterExpansion(modules.QuestieNPCBlacklist:Load())
local removed = 0
for id, v in pairs(hidden) do if v == true and quests[id] then quests[id] = nil removed = removed + 1 end end

------------------------------------------------------------------------
-- Forever-Koordinaten (vier Zonen mit geaenderten Kartengrenzen)
------------------------------------------------------------------------
local transforms = dofile(CONV)   -- [uiMapID] = { sx, ox, sy, oy }
local function conv(ui, x, y)
    local t = transforms[ui]
    if not t then return x, y end
    return t[1] * x + t[2], t[3] * y + t[4]
end

------------------------------------------------------------------------
-- Auswahl & Kompaktierung
------------------------------------------------------------------------
local MAX_SPAWNS = 14
local function r1(v) return math.floor(v * 10 + 0.5) / 10 end

-- spawns {[areaId] = {{x,y},...}} -> { uiMap, x, y, x, y, ... } pro Zone
local function packSpawns(spawns, limit)
    if type(spawns) ~= "table" then return nil end
    local out = {}
    local zones = {}
    for areaId in pairs(spawns) do zones[#zones + 1] = areaId end
    table.sort(zones)
    for _, areaId in ipairs(zones) do
        local list = spawns[areaId]
        local ui = areaToUi[areaId]
        if ui and type(list) == "table" then
            local valid = {}
            for _, c in ipairs(list) do
                if type(c) == "table" and type(c[1]) == "number" and c[1] >= 0 and c[2] >= 0 then valid[#valid + 1] = c end
            end
            if #valid > 0 then
                local z = { ui }
                local step = math.max(1, #valid / limit)
                local i = 1
                while i <= #valid and #z < limit * 2 + 1 do
                    local c = valid[math.floor(i)]
                    local x, y = conv(ui, c[1], c[2])
                    z[#z + 1] = r1(x)
                    z[#z + 1] = r1(y)
                    i = i + step
                end
                out[#out + 1] = z
            end
        end
    end
    return #out > 0 and out or nil
end

local needNpc, needObj, needItem = {}, {}, {}
local outQ = {}
local function ids(t) if type(t) == "table" and #t > 0 then return t end return nil end

for id, q in pairs(quests) do
    if q[qk.name] then
        local sb, fb, ob = q[qk.startedBy] or {}, q[qk.finishedBy] or {}, q[qk.objectives] or {}
        for _, l in ipairs({ sb[1], fb[1] }) do for _, n in ipairs(l or {}) do needNpc[n] = true end end
        for _, l in ipairs({ sb[2], fb[2] }) do for _, o in ipairs(l or {}) do needObj[o] = true end end
        for _, o in ipairs(ob[1] or {}) do needNpc[o[1]] = true end
        for _, o in ipairs(ob[2] or {}) do needObj[o[1]] = true end
        for _, o in ipairs(ob[3] or {}) do needItem[o[1]] = true end
        for _, o in ipairs(ob[5] or {}) do for _, n in ipairs(o[1] or {}) do needNpc[n] = true end end
        local obj = {}
        if ob[1] then obj.k = {} for _, o in ipairs(ob[1]) do obj.k[#obj.k + 1] = { o[1], o[2] } end end
        if ob[2] then obj.o = {} for _, o in ipairs(ob[2]) do obj.o[#obj.o + 1] = { o[1], o[2] } end end
        if ob[3] then obj.i = {} for _, o in ipairs(ob[3]) do obj.i[#obj.i + 1] = { o[1], o[2] } end end
        if ob[5] then obj.c = {} for _, o in ipairs(ob[5]) do obj.c[#obj.c + 1] = { o[1], o[3] } end end
        local trig = q[qk.triggerEnd]
        if type(trig) == "table" and type(trig[2]) == "table" then
            local spots = packSpawns(trig[2], 4)
            if spots then obj.e = { trig[1], spots } end
        end
        outQ[id] = {
            n = q[qk.name], l = q[qk.questLevel], rl = q[qk.requiredLevel],
            r = q[qk.requiredRaces], c = q[qk.requiredClasses],
            sn = ids(sb[1]), so = ids(sb[2]), si = ids(sb[3]),
            en = ids(fb[1]), eo = ids(fb[2]),
            ob = next(obj) and obj or nil,
            pg = ids(q[qk.preQuestGroup]), ps = ids(q[qk.preQuestSingle]),
            ex = ids(q[qk.exclusiveTo]), nx = q[qk.nextQuestInChain],
            pa = q[qk.parentQuest], sf = q[qk.specialFlags],
            sk = q[qk.requiredSkill], rp = q[qk.requiredMinRep],
            d = type(q[qk.objectivesText]) == "table" and q[qk.objectivesText][1] or nil,
            x = questXP[id] and questXP[id][2] or nil,
            su = (type(q[qk.sourceItemId]) == "number" and q[qk.sourceItemId] > 0) and q[qk.sourceItemId] or nil,
            rs = ids(q[qk.requiredSourceItems]),
            tg = questTags[id] and questTags[id][1] or nil,
        }
        local txt = outQ[id].d or ""
        if txt:find("[Ee]scort") then outQ[id].es = 1 end
    end
end

-- Dungeons: Eingaenge und Zuordnung Quest -> Dungeon
------------------------------------------------------------------------
-- Instanzen fuer Stufe 1-60 (Schlachtzuege bleiben aussen vor)
local LEVELING = { 2437, 718, 1581, 209, 719, 717, 721, 491, 796, 722, 1337, 1176, 2100, 1477, 1584, 2557, 1583, 2057, 2017 }
local dsrc = ZoneDB.private.dungeons
local dMain, outD = {}, {}
for _, main in ipairs(LEVELING) do
    local d = dsrc[main]
    if d then
        dMain[main] = main
        for _, alt in ipairs(d[2] or {}) do dMain[alt] = main end
        local ent = {}
        for _, e in ipairs(d[4] or {}) do
            local ui = areaToUi[e[1]]
            if ui then
                local x, y = conv(ui, e[2], e[3])
                ent[#ent + 1] = { ui, r1(x), r1(y) }
            end
        end
        outD[main] = { n = d[1], e = ent }
    end
end
-- Dungeon nach Spawn-Orten: alle bekannten Orte liegen in genau einer Instanz
local function spawnDungeon(spawns, acc)
    if type(spawns) ~= "table" then return end
    for areaId in pairs(spawns) do
        local m = dMain[areaId]
        if m then acc.d[m] = true else acc.out = true end
    end
end
local function questDungeon(q)
    local zs = q[qk.zoneOrSort]
    if type(zs) == "number" and zs > 0 and dMain[zs] then return dMain[zs] end
    local ob = q[qk.objectives] or {}
    local acc = { d = {}, out = false }
    for _, o in ipairs(ob[1] or {}) do local n = npcs[o[1]] if n then spawnDungeon(n[nk.spawns], acc) end end
    for _, o in ipairs(ob[2] or {}) do local x = objects[o[1]] if x then spawnDungeon(x[ok_.spawns], acc) end end
    for _, o in ipairs(ob[3] or {}) do
        local it = items[o[1]]
        if it then
            for _, n in ipairs(it[ik.npcDrops] or {}) do local nn = npcs[n] if nn then spawnDungeon(nn[nk.spawns], acc) end end
            for _, x in ipairs(it[ik.objectDrops] or {}) do local xx = objects[x] if xx then spawnDungeon(xx[ok_.spawns], acc) end end
        end
    end
    if acc.out then return nil end
    local found
    for m in pairs(acc.d) do
        if found then return nil end   -- mehrere Instanzen: nicht eindeutig
        found = m
    end
    return found
end
local nDQ = 0
for id, e in pairs(outQ) do
    local z = questDungeon(quests[id])
    if z then e.z = z nDQ = nDQ + 1 end
end

-- Faction-Korrekturen in Paketform
local function packQuestFix(fix)
    local out = {}
    for id, data in pairs(fix) do
        local e = {}
        if data[qk.startedBy] then
            local sb = data[qk.startedBy]
            e.sn, e.so = ids(sb[1]), ids(sb[2])
            for _, n in ipairs(sb[1] or {}) do needNpc[n] = true end
            for _, o in ipairs(sb[2] or {}) do needObj[o] = true end
        end
        if data[qk.finishedBy] then
            local fb = data[qk.finishedBy]
            e.en, e.eo = ids(fb[1]), ids(fb[2])
            for _, n in ipairs(fb[1] or {}) do needNpc[n] = true end
            for _, o in ipairs(fb[2] or {}) do needObj[o] = true end
        end
        if data[qk.nextQuestInChain] then e.nx = data[qk.nextQuestInChain] end
        if data[qk.preQuestSingle] then e.ps = ids(data[qk.preQuestSingle]) or false end
        if data[qk.preQuestGroup] then e.pg = ids(data[qk.preQuestGroup]) or false end
        if data[qk.exclusiveTo] then e.ex = ids(data[qk.exclusiveTo]) or false end
        if data[qk.requiredRaces] then e.r = data[qk.requiredRaces] end
        if next(e) then out[id] = e end
    end
    return out
end
local outFix = {}
for _, fac in ipairs({ "Alliance", "Horde" }) do
    outFix[fac] = { q = packQuestFix(factionFix[fac].q) }
    for id, data in pairs(factionFix[fac].n) do
        if data[nk.spawns] and npcs[id] then needNpc[id] = true end
    end
end

-- Gegenstaende: Beute von NPCs/Objekten
local outI = {}
for id in pairs(needItem) do
    local it = items[id]
    if it then
        local nd, od = ids(it[ik.npcDrops]), ids(it[ik.objectDrops])
        outI[id] = { n = it[ik.name], dn = nd, dob = od }
        for _, n in ipairs(nd or {}) do needNpc[n] = true end
        for _, o in ipairs(od or {}) do needObj[o] = true end
    end
end

-- Dienst-NPCs (Haendler, Reparatur, Flugmeister, Gasthaus), freundlich zu einer Fraktion
local nf = QDB.npcFlags or {}
local SERVICE = (nf.VENDOR or 128) + (nf.REPAIR or 4096) + (nf.FLIGHT_MASTER or 8192) + (nf.INNKEEPER or 65536)
local EXTRA = { { nf.TRAINER or 16, 16 }, { nf.BANKER or 131072, 32 }, { nf.AUCTIONEER or 2097152, 64 } }
local function hasBit(m, b) return math.floor(m / b) % 2 == 1 end
for id, n in pairs(npcs) do
    local flags = n[nk.npcFlags] or 0
    local fr = n[nk.friendlyToFaction]
    if flags > 0 and type(fr) == "string" and fr ~= "" then
        local extra = false
        for _, e in ipairs(EXTRA) do if hasBit(flags, e[1]) then extra = true end end
        if hasBit(flags, nf.REPAIR or 4096) or hasBit(flags, nf.FLIGHT_MASTER or 8192) or hasBit(flags, nf.INNKEEPER or 65536)
           or hasBit(flags, nf.VENDOR or 128) or extra then
            needNpc[id] = true
        end
    end
end

local outN, outO = {}, {}
for id in pairs(needNpc) do
    local n = npcs[id]
    if n and not hiddenNpc[id] then
        local flags = n[nk.npcFlags] or 0
        local svc = 0
        if hasBit(flags, nf.VENDOR or 128) then svc = svc + 1 end
        if hasBit(flags, nf.REPAIR or 4096) then svc = svc + 2 end
        if hasBit(flags, nf.FLIGHT_MASTER or 8192) then svc = svc + 4 end
        if hasBit(flags, nf.INNKEEPER or 65536) then svc = svc + 8 end
        for _, e in ipairs(EXTRA) do if hasBit(flags, e[1]) then svc = svc + e[2] end end
        outN[id] = { n = n[nk.name], s = packSpawns(n[nk.spawns], MAX_SPAWNS), f = n[nk.friendlyToFaction],
                     v = svc > 0 and svc or nil, lo = n[nk.minLevel], hi = n[nk.maxLevel],
                     rk = (n[nk.rank] or 0) > 0 and n[nk.rank] or nil,
                     sb = (svc and hasBit(svc, 16)) and n[nk.subName] or nil }
    end
end
for id in pairs(needObj) do
    local o = objects[id]
    if o then outO[id] = { n = o[ok_.name], s = packSpawns(o[ok_.spawns], MAX_SPAWNS) } end
end

------------------------------------------------------------------------
-- Ausgabe (in Bloecken, damit Lua 5.1 nicht an Konstanten-Grenzen stoesst)
------------------------------------------------------------------------
local function ser(v)
    local t = type(v)
    if t == "number" then
        if v == math.floor(v) then return string.format("%d", v) end
        return (string.format("%.1f", v):gsub("%.0$", ""))
    elseif t == "string" then
        return string.format("%q", v):gsub("\\\n", "\\n")
    elseif t == "boolean" then
        return tostring(v)
    elseif t == "table" then
        local parts, n = {}, #v
        for i = 1, n do parts[#parts + 1] = ser(v[i]) end
        local keys = {}
        for k in pairs(v) do
            if not (type(k) == "number" and k >= 1 and k <= n and k == math.floor(k)) then keys[#keys + 1] = k end
        end
        table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)
        for _, k in ipairs(keys) do
            if type(k) == "string" and k:match("^[%a_][%w_]*$") then
                parts[#parts + 1] = k .. "=" .. ser(v[k])
            else
                parts[#parts + 1] = "[" .. ser(k) .. "]=" .. ser(v[k])
            end
        end
        return "{" .. table.concat(parts, ",") .. "}"
    end
    return "nil"
end

local HEADER = [[
-- LevelPilot Data - Datenpaket
-- Diese Datei ist automatisch erzeugt und Teil des Addons "LevelPilot Data".
-- Die Daten stammen aus Questie (https://github.com/Questie/Questie), Version v11.38.0
-- (Commit 454b9d072965ee8f1a881429260fcf1fac8d60f7), veroeffentlicht unter der
-- GNU General Public License Version 3. Fuer LevelPilot gekuerzt, umgeformt und fuer
-- WoW Forever umgerechnet. Dieses Paket steht ebenfalls unter der GNU GPL v3 (siehe LICENSE.txt).
]]

local function writeTable(file, name, tbl, chunk)
    local f = assert(io.open(OUT .. "/" .. file, "w"))
    f:write(HEADER, "\nlocal D = LevelPilotData\nD.", name, " = D.", name, " or {}\n")
    local keys = {}
    for k in pairs(tbl) do keys[#keys + 1] = k end
    table.sort(keys)
    local count = 0
    for i, k in ipairs(keys) do
        if (i - 1) % chunk == 0 then
            if i > 1 then f:write("end)()\n") end
            f:write(";(function() local T = D.", name, "\n")
        end
        f:write("T[", k, "]=", ser(tbl[k]), "\n")
        count = count + 1
    end
    if #keys > 0 then f:write("end)()\n") end
    f:close()
    return count
end

------------------------------------------------------------------------
-- Gelaendekarte: wo Kreaturen/Objekte stehen, ist begehbar; Patrouillenwege sind meist Strassen
-- Je Zone ein Gitter 100 x 100 (1 % der Karte je Zelle): 0 unbekannt, 1 begehbar, 2 Strasse
------------------------------------------------------------------------
local GRID = 100
local terrain = {}
local function cellSet(ui, x, y, v)
    if x < 0 or y < 0 or x >= 100 or y >= 100 then return end
    local g = terrain[ui]
    if not g then g = {} terrain[ui] = g end
    local cx, cy = math.floor(x * GRID / 100), math.floor(y * GRID / 100)
    local k = cy * GRID + cx
    if (g[k] or 0) < v then g[k] = v end
end
local function addSpawns(spawns)
    if type(spawns) ~= "table" then return end
    for areaId, list in pairs(spawns) do
        local ui = areaToUi[areaId]
        if ui and not dMain[areaId] and type(list) == "table" then
            for _, c in ipairs(list) do
                if type(c) == "table" and type(c[1]) == "number" and c[1] >= 0 and c[2] >= 0 then
                    local x, y = conv(ui, c[1], c[2])
                    -- Spawnpunkt + direkte Nachbarn (Kreaturen bewegen sich um ihren Punkt)
                    for dx = -1, 1 do for dy = -1, 1 do cellSet(ui, x + dx, y + dy, 1) end end
                end
            end
        end
    end
end
local function addWaypoints(wps)
    if type(wps) ~= "table" then return end
    for areaId, lines in pairs(wps) do
        local ui = areaToUi[areaId]
        if ui and not dMain[areaId] and type(lines) == "table" then
            for _, line in ipairs(lines) do
                if type(line) == "table" then
                    local px, py
                    for _, c in ipairs(line) do
                        if type(c) == "table" and type(c[1]) == "number" and c[1] >= 0 then
                            local x, y = conv(ui, c[1], c[2])
                            if px then
                                local steps = math.max(1, math.ceil(math.max(math.abs(x - px), math.abs(y - py)) * 2))
                                if steps < 400 then
                                    for i = 0, steps do
                                        cellSet(ui, px + (x - px) * i / steps, py + (y - py) * i / steps, 2)
                                    end
                                end
                            end
                            px, py = x, y
                        end
                    end
                end
            end
        end
    end
end
for _, n in pairs(npcs) do
    addSpawns(n[nk.spawns])
    addWaypoints(n[nk.waypoints])
end
for _, o in pairs(objects) do addSpawns(o[ok_.spawns]) end
-- kodieren: 2 Bit je Zelle, 3 Zellen je Zeichen
local B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local outT, nT = {}, 0
for ui, g in pairs(terrain) do
    local cnt = 0
    for _ in pairs(g) do cnt = cnt + 1 end
    if cnt >= 200 then
        local chars = {}
        for i = 0, GRID * GRID - 1, 3 do
            local v = (g[i] or 0) + (g[i + 1] or 0) * 4 + (g[i + 2] or 0) * 16
            chars[#chars + 1] = B64:sub(v + 1, v + 1)
        end
        outT[ui] = table.concat(chars)
        nT = nT + 1
    end
end

local nQ = writeTable("Quests.lua", "Q", outQ, 800)
local nN = writeTable("Npcs.lua", "N", outN, 800)
local nO = writeTable("Objects.lua", "O", outO, 800)
local nI = writeTable("Items.lua", "I", outI, 1500)
local f = assert(io.open(OUT .. "/Fixes.lua", "w"))
f:write(HEADER, "\nlocal D = LevelPilotData\nD.F = ", ser(outFix), "\n")
f:close()
-- Briefkaesten
local outMB = {}
for _, o in pairs(objects) do
    if o[ok_.name] == "Mailbox" and type(o[ok_.spawns]) == "table" then
        for areaId, list in pairs(o[ok_.spawns]) do
            local ui = areaToUi[areaId]
            if ui and not dMain[areaId] and type(list) == "table" then
                for _, c in ipairs(list) do
                    if type(c) == "table" and type(c[1]) == "number" and c[1] >= 0 then
                        local x, y = conv(ui, c[1], c[2])
                        outMB[#outMB + 1] = { ui, r1(x), r1(y) }
                    end
                end
            end
        end
    end
end
table.sort(outMB, function(a, b) if a[1] ~= b[1] then return a[1] < b[1] end if a[2] ~= b[2] then return a[2] < b[2] end return a[3] < b[3] end)
f = assert(io.open(OUT .. "/Services.lua", "w"))
f:write(HEADER, "\nlocal D = LevelPilotData\nD.MB = ", ser(outMB), "\n")
f:close()
print("Briefkaesten " .. #outMB)
f = assert(io.open(OUT .. "/Terrain.lua", "w"))
f:write(HEADER, "\nlocal D = LevelPilotData\nD.TG = ", GRID, "\nD.T = D.T or {}\n")
local tkeys = {}
for k in pairs(outT) do tkeys[#tkeys + 1] = k end
table.sort(tkeys)
for _, k in ipairs(tkeys) do f:write("D.T[", k, "]=\"", outT[k], "\"\n") end
f:close()
print("Gelaendekarten " .. nT)
f = assert(io.open(OUT .. "/Dungeons.lua", "w"))
f:write(HEADER, "\nlocal D = LevelPilotData\nD.D = ", ser(outD), "\n")
f:close()
print("Dungeonquests " .. nDQ)

print(string.format("Quests %d, NPCs %d, Objekte %d, Gegenstaende %d, entfernt %d, Korrekturen q=%d n=%d o=%d i=%d rep=%d",
    nQ, nN, nO, nI, removed, counts.q, counts.n, counts.o, counts.i, counts.rep))
