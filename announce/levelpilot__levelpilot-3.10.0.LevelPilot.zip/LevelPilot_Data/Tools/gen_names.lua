-- Erzeugt die Sprachpakete LevelPilot_Data_<Sprache> aus den Uebersetzungen von QuestieDB (GPLv3).
-- Aufruf: lua51 gen_names.lua <QuestieDB-l10n-Ordner> <Zonen-Ordner> <packids.txt> <Ausgabeordner>
local L10N, ZONES, IDS, OUT = arg[1], arg[2], arg[3], arg[4]
local LOCALES = { "deDE", "frFR", "esES", "esMX", "ptBR", "ruRU", "koKR", "zhCN", "zhTW" }

-- IDs aus dem Datenpaket
local want = { Q = {}, N = {}, O = {}, I = {} }
for line in io.lines(IDS) do
    local k, id = line:match("^(%a) (%d+)$")
    if k then want[k][tonumber(id)] = true end
end

-- Questie-Dateien mit Platzhaltern laden
local function LoadLookup(file, loc, field)
    local f = io.open(file) if not f then return {} end
    f:close()
    local l10n = { questLookup = {}, npcNameLookup = {}, itemLookup = {}, objectLookup = {} }
    local env = setmetatable({
        GetLocale = function() return loc end,
        QuestieLoader = { ImportModule = function() return l10n end },
        loadstring = loadstring,
    }, { __index = _G })
    local chunk = assert(loadfile(file))
    setfenv(chunk, env)
    chunk()
    local v = l10n[field][loc]
    if type(v) == "function" then v = v() end
    return v or {}
end

-- Zonen: englischer Name -> Uebersetzung (WoW Forever basiert auf Classic Era)
local zoneTr = {}
for _, f in ipairs({ "EasternKingdoms", "Kalimdor" }) do
    local l10n = { translations = {} }
    local env = setmetatable({
        QuestieLoader = { ImportModule = function(_, name)
            if name == "Expansions" then return { Current = 1, Era = 1 } end
            return l10n
        end },
    }, { __index = _G })
    local chunk = assert(loadfile(ZONES .. "/" .. f .. ".lua"))
    setfenv(chunk, env)
    chunk()
    for en, t in pairs(l10n.translations) do zoneTr[en] = t end
end
-- uiMapIDs der Classic-Zonen (englische Namen wie bei Questie)
local ZONE_EN = {
    [1411] = "Durotar", [1412] = "Mulgore", [1413] = "The Barrens", [1416] = "Alterac Mountains",
    [1417] = "Arathi Highlands", [1418] = "Badlands", [1419] = "Blasted Lands", [1420] = "Tirisfal Glades",
    [1421] = "Silverpine Forest", [1422] = "Western Plaguelands", [1423] = "Eastern Plaguelands",
    [1424] = "Hillsbrad Foothills", [1425] = "The Hinterlands", [1426] = "Dun Morogh", [1427] = "Searing Gorge",
    [1428] = "Burning Steppes", [1429] = "Elwynn Forest", [1430] = "Deadwind Pass", [1431] = "Duskwood",
    [1432] = "Loch Modan", [1433] = "Redridge Mountains", [1434] = "Stranglethorn Vale", [1435] = "Swamp of Sorrows",
    [1436] = "Westfall", [1437] = "Wetlands", [1438] = "Teldrassil", [1439] = "Darkshore", [1440] = "Ashenvale",
    [1441] = "Thousand Needles", [1442] = "Stonetalon Mountains", [1443] = "Desolace", [1444] = "Feralas",
    [1445] = "Dustwallow Marsh", [1446] = "Tanaris", [1447] = "Azshara", [1448] = "Felwood", [1449] = "Un'Goro Crater",
    [1450] = "Moonglade", [1451] = "Silithus", [1452] = "Winterspring", [1453] = "Stormwind City",
    [1454] = "Orgrimmar", [1455] = "Ironforge", [1456] = "Thunder Bluff", [1457] = "Darnassus", [1458] = "Undercity",
}

local function q(s) return string.format("%q", s):gsub("\\\n", "\\n") end

local missingZones = {}
for _, loc in ipairs(LOCALES) do
    local data = { Q = {}, N = {}, O = {}, I = {}, Z = {} }
    local counts = { Q = 0, N = 0, O = 0, I = 0, Z = 0 }
    for _, src in ipairs({ "Forever", "Classic" }) do   -- Forever zuerst, Classic ergaenzt fehlende
        local qs = LoadLookup(L10N .. "/" .. src .. "/lookupQuests/" .. loc .. ".lua", loc, "questLookup")
        for id, e in pairs(qs) do
            local title = type(e) == "table" and e[1] or nil
            if type(title) == "string" and title ~= "" and not data.Q[id] then data.Q[id] = title counts.Q = counts.Q + 1 end
        end
        local ns = LoadLookup(L10N .. "/" .. src .. "/lookupNpcs/" .. loc .. ".lua", loc, "npcNameLookup")
        for id, e in pairs(ns) do
            local name = type(e) == "table" and e[1] or e
            if want.N[id] and type(name) == "string" and name ~= "" and not data.N[id] then data.N[id] = name counts.N = counts.N + 1 end
        end
        local is = LoadLookup(L10N .. "/" .. src .. "/lookupItems/" .. loc .. ".lua", loc, "itemLookup")
        for id, name in pairs(is) do
            if want.I[id] and type(name) == "string" and name ~= "" and not data.I[id] then data.I[id] = name counts.I = counts.I + 1 end
        end
        local os_ = LoadLookup(L10N .. "/" .. src .. "/lookupObjects/" .. loc .. ".lua", loc, "objectLookup")
        for id, name in pairs(os_) do
            if want.O[id] and type(name) == "string" and name ~= "" and not data.O[id] then data.O[id] = name counts.O = counts.O + 1 end
        end
    end
    for map, en in pairs(ZONE_EN) do
        local t = zoneTr[en]
        local v = t and t[loc]
        if v == true then v = en end
        if type(v) == "string" then data.Z[map] = v counts.Z = counts.Z + 1
        else missingZones[#missingZones + 1] = loc .. ":" .. en end
    end
    -- Ausgabe: eine Datei im Datenpaket je Sprache. Die Daten liegen in einer Funktion, die LevelPilot erst
    -- aufruft, wenn die Sprache gebraucht wird (sonst belegen die Tabellen keinen Speicher).
    local f = io.open(OUT .. "/Names_" .. loc .. ".lua", "w")
    f:write("-- LevelPilot Data - Namen auf " .. loc .. " (Quests, NPCs, Gegenstaende, Objekte, Zonen)\n")
    f:write("-- Automatisch erzeugt (Tools/gen_names.lua). Die Namen stammen aus QuestieDB\n")
    f:write("-- (https://github.com/Questie/QuestieDB), veroeffentlicht unter der GNU General Public License\n")
    f:write("-- Version 3. Diese Datei steht ebenfalls unter der GNU GPL v3 (siehe LICENSE.txt).\n")
    f:write("-- Format: LevelPilotNamesLoad[Sprache]() liefert { Q = {[questID] = Titel}, N = {[npcID] = Name},\n")
    f:write("--   I = {[itemID] = Name}, O = {[objektID] = Name}, Z = {[uiMapID] = Zonenname} }\n")
    f:write("LevelPilotNamesLoad = LevelPilotNamesLoad or {}\n")
    f:write("LevelPilotNamesLoad[" .. q(loc) .. "] = function()\n")
    f:write("local D = { Q = {}, N = {}, I = {}, O = {}, Z = {} }\n")
    for _, k in ipairs({ "Q", "N", "I", "O", "Z" }) do
        local ids = {}
        for id in pairs(data[k]) do ids[#ids + 1] = id end
        table.sort(ids)
        for n = 1, #ids, 400 do       -- in Bloecken (Lua-Grenze fuer Konstanten je Funktion)
            f:write(";(function() local T = D." .. k .. "\n")
            for i = n, math.min(n + 399, #ids) do f:write("T[" .. ids[i] .. "]=" .. q(data[k][ids[i]]) .. "\n") end
            f:write("end)()\n")
        end
    end
    f:write("return D\nend\n")
    f:close()
    print(string.format("%s  Quests %d  NPCs %d  Gegenstände %d  Objekte %d  Zonen %d", loc, counts.Q, counts.N, counts.I, counts.O, counts.Z))
end
if #missingZones > 0 then print("Zonen ohne Übersetzung: " .. table.concat(missingZones, ", ")) end
