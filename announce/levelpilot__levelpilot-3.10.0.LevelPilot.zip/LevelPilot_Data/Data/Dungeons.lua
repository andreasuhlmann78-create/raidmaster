-- LevelPilot Data - Datenpaket
-- Diese Datei ist automatisch erzeugt und Teil des Addons "LevelPilot Data".
-- Die Daten stammen aus Questie (https://github.com/Questie/Questie), Version v11.38.0
-- (Commit 454b9d072965ee8f1a881429260fcf1fac8d60f7), veroeffentlicht unter der
-- GNU General Public License Version 3. Fuer LevelPilot gekuerzt, umgeformt und fuer
-- WoW Forever umgerechnet. Dieses Paket steht ebenfalls unter der GNU GPL v3 (siehe LICENSE.txt).

local D = LevelPilotData
D.D = {[1176]={e={{1446,38.7,20.1}},n="Zul'Farrak"},[1337]={e={{1418,44.6,12.1},{1418,65.2,43.5}},n="Uldaman"},[1477]={e={{1435,69.9,53.5}},n="The Temple of Atal'Hakkar"},[1581]={e={{1436,42.5,71.7}},n="The Deadmines"},[1583]={e={{1427,34.8,85.3},{1428,29.4,38.3}},n="Blackrock Spire"},[1584]={e={{1427,34.8,85.3},{1428,29.4,38.3}},n="Blackrock Depths"},[2017]={e={{1423,26.5,10.4},{1423,41.5,17.7}},n="Stratholme"},[2057]={e={{1422,69.7,73.2}},n="Scholomance"},[209]={e={{1421,44.8,67.8}},n="Shadowfang Keep"},[2100]={e={{1443,29.1,62.5}},n="Maraudon"},[2437]={e={{1454,52.6,49}},n="Ragefire Chasm"},[2557]={e={{1444,59.2,45.1}},n="Dire Maul"},[491]={e={{1413,42.9,90.2}},n="Razorfen Kraul"},[717]={e={{1453,52.4,70}},n="The Stockade"},[718]={e={{1413,46,36.5}},n="Wailing Caverns"},[719]={e={{1440,14.5,14.2}},n="Blackfathom Deeps"},[721]={e={{1426,24.3,39.8}},n="Gnomeregan"},[722]={e={{1413,49,93.9}},n="Razorfen Downs"},[796]={e={{1420,82.6,33.8}},n="Scarlet Monastery"}}
